-----------------------------------------------------
Simple Talk (http://www.simple-talk.com)
Centralizing and Analyzing SQL Backup Pro Backup and Restore Data
Rodney Landrum
-----------------------------------------------------

This solution uses a database called DBA_Rep which is hardcoded along with localhost in the connection manager object DBA_REP in the SSIS package. To create the database along with all of the tables for the solution, simply run the script Create_Database_and_Data_Tables.sql in this zip file. The four tables you will need are:

ServerList_SSIS
RG_Backup
RG_Restore
RG_Backup_Stage
RG_Restore_Stage

You will need to populate the Serverlist_SSIS table with valid SQL Server/instance names as well as a 0 or 1 in the Connect column.
A 1 tells the SSIS package to connect to the server. You may, for whatever reason, decide that you do not want to connect to a 
specific server. You can change the Connect value to 0 if that is the case and leave the server in the Serverlist_SSIS table
in case you want to connect to it again at some point in the future. The other columns, Version, DMZ, LocationID and Online are not used for this solution and can be left NULL.
Below is a sample ServerList_SSIS record.

Server	Connect	Version	DMZ	LocationID	Online
Server2	1	NULL	NULL	NULL		NULL
 
I assume that the connections you make to the SQL Servers will use Windows (Trusted) connections, not SQL authentication.
If you require SQL authentication you will need to save the password in the MultiServer connection in the SSIS package,
which will require that you remove the variable from the expression for long enough to enter as valid server name user and 
password and save the package. 

With valid server data, all that is required is that you load the SSIS package "Redgate_SQL_Backup_Reporting.dtsx" in VSDT (Visual Studio Data Tools) for SQL Server 2012 in an existing solution and change the DBA_REP conneciton manager object if you are not running against localhost and the DBA_Rep database. To execute the package you will need to load the dtsx in an existing solution. 

If you have any issues you can not get past feel free to contact me at rodneylandrum @ hotmail . com. 




Rodney Landrum, December 6th,th, 2012



