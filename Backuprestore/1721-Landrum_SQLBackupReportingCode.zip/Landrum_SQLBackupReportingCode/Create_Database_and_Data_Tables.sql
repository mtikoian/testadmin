USE [master]
GO

/****** Object:  Database [DBA_Rep]    Script Date: 12/3/2012 3:47:32 PM ******/
CREATE DATABASE [DBA_Rep]
 CONTAINMENT = NONE
 ON  PRIMARY 
( NAME = N'DBA_Rep', FILENAME = N'C:\Temp\DBA_Rep.mdf' , SIZE = 675776KB , MAXSIZE = UNLIMITED, FILEGROWTH = 1024KB )
 LOG ON 
( NAME = N'DBA_Rep_log', FILENAME = N'C:\Temp\DBA_Rep.LDF' , SIZE = 149696KB , MAXSIZE = 2048GB , FILEGROWTH = 10%)
GO

USE [DBA_Rep]
GO
/****** Object:  Table [dbo].[RG_Backup]    Script Date: 12/3/2012 3:50:56 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[RG_Backup](
	[Server] [nvarchar](60) NOT NULL,
	[Entry_Type] [int] NULL,
	[Code] [int] NULL,
	[Message] [nvarchar](1024) NULL,
	[Backup_Start] [datetime] NULL,
	[Backup_End] [datetime] NULL,
	[Backup_type] [nvarchar](3) NULL,
	[DBName] [nvarchar](128) NULL,
	[Compression_Level] [int] NULL,
	[Duration] [int] NULL,
	[Size] [bigint] NULL,
	[Compressed_Size] [bigint] NULL,
	[Speed] [real] NULL,
	[UserName] [nvarchar](128) NULL,
	[Path] [nvarchar](260) NULL,
	[FileName] [nvarchar](100) NULL
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[RG_Backup_Stage]    Script Date: 12/3/2012 3:50:56 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[RG_Backup_Stage](
	[Server] [nvarchar](60) NOT NULL,
	[Entry_Type] [int] NULL,
	[Code] [int] NULL,
	[Message] [nvarchar](1024) NULL,
	[Backup_Start] [datetime] NULL,
	[Backup_End] [datetime] NULL,
	[Backup_type] [nvarchar](3) NULL,
	[DBName] [nvarchar](128) NULL,
	[Compression_Level] [int] NULL,
	[Duration] [int] NULL,
	[Size] [bigint] NULL,
	[Compressed_Size] [bigint] NULL,
	[Speed] [real] NULL,
	[UserName] [nvarchar](128) NULL,
	[Path] [nvarchar](260) NULL,
	[FileName] [nvarchar](100) NULL
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[RG_Restore]    Script Date: 12/3/2012 3:50:56 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[RG_Restore](
	[Server] [nvarchar](60) NOT NULL,
	[Entry_Type] [int] NULL,
	[Code] [int] NULL,
	[Message] [nvarchar](1024) NULL,
	[Restore_Start] [datetime] NULL,
	[Restore_End] [datetime] NULL,
	[Restore_type] [nvarchar](3) NULL,
	[DBName] [nvarchar](128) NULL,
	[Compression_Level] [int] NULL,
	[Duration] [int] NULL,
	[Size] [bigint] NULL,
	[Compressed_Size] [bigint] NULL,
	[Speed] [real] NULL,
	[UserName] [nvarchar](128) NULL,
	[Path] [nvarchar](260) NULL,
	[FileName] [nvarchar](100) NULL
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[RG_Restore_Stage]    Script Date: 12/3/2012 3:50:56 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[RG_Restore_Stage](
	[Server] [nvarchar](60) NOT NULL,
	[Entry_Type] [int] NULL,
	[Code] [int] NULL,
	[Message] [nvarchar](1024) NULL,
	[Restore_Start] [datetime] NULL,
	[Restore_End] [datetime] NULL,
	[Restore_type] [nvarchar](3) NULL,
	[DBName] [nvarchar](128) NULL,
	[Compression_Level] [int] NULL,
	[Duration] [int] NULL,
	[Size] [bigint] NULL,
	[Compressed_Size] [bigint] NULL,
	[Speed] [real] NULL,
	[UserName] [nvarchar](128) NULL,
	[Path] [nvarchar](260) NULL,
	[FileName] [nvarchar](100) NULL
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[ServerList_SSIS]    Script Date: 12/3/2012 3:50:56 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ServerList_SSIS](
	[Server] [nvarchar](60) NOT NULL,
	[Connect] [smallint] NOT NULL,
	[Version] [smallint] NULL,
	[DMZ] [smallint] NULL,
	[LocationID] [smallint] NULL,
	[Online] [smallint] NULL
) ON [PRIMARY] 

GO


