Thanks to everyone who attend my session at SQL Saturday Indianapolis.

PowerShell scripts (all three PowerShell scripts need to exist on the server you are running the PowerShell command from)
Test-DatabaseRestore.ps1 - The function code to build and execute Restore-SqlDatabase commands for each valid backup file for a database
Get-RelocateFile.ps1 - The function code to build the -RelocateFile parameter for the Restore-SqlDatabase commands if -BackupInstance and -RestoreInstance are different.  
Microsoft.PowerShellISE_profile.ps1 - A PowerShell profile file containing both functions listed above.  If you already have a profile file, you can paste the code from Test-DatabaseRestore.ps1 and Get-RelocateFile.ps1 into it.  If you don't have one, or aren't sure, you can use the instructoins here to create one.  

http://www.howtogeek.com/126469/how-to-create-a-powershell-profile/

Once the profile file is created, you can paste the code from Test-DatabaseRestore.ps1 and Get-RelocateFile.ps1 into it and these functions will be loaded when PowerShell starts.

T-SQL Scripts
GetRestoreFiles.sql - Executes the SSMS script to identify the valid backup files for the database input to Test-DatabaseRestore.ps1. This procedure defaults to creation in master and must exist on the instance the backup files are coming from.
Both table creation scripts must exist on the instance the databases are being restored to.
CreateRestoreDurationTotalTable.sql - Creates the table to hold total duration information for the restore process.
CreateRestoreDurationItemTable - Creates the table to hold duration information for each restore.

The way that the process is currently coded, it will only work for databases that contain data files, log files, or in-memory objects.  Databases that include full-text files cannot currently be processed.  This is on my to-do list.  Databases with multiple data files will process, but the additional physical data file names will be in the following format:  DatabaseName_#_Data.mdf, with # being the number of the file.

I will be uploading these scripts to my blog next week and plan on providing updates to the process.  You can find my blog at www.skreebydba.com.  If you are interested in being notified when updates are posted, you can subscribe.  

Thanks for attending my session and supporting SQL Saturday Indianapolis.
