﻿function Test-DatabaseRestore {
<#
.SYNOPSIS
For the database input, restores the most recent FULL backup, all DIFF backup since the most recent FULL, and all LOG backups
since the most recent DIFF 
.DESCRIPTION
This function identifies the most recent FULL backup file for a database, any DIFF backup files that have been generated since the 
last FULL backup for that database, and any LOG backup files since the most recent DIFF
It then runs the Restore-SQLDatabase cmdlet for each file, setting the -norecovery flag for each file except the last one which runs
WITH RECOVERY
.EXAMPLE
Test-DatabaseRestore -databasename YourDatabase -backupinstance YourBackupInstance -restoreinstance YourRestoreInstance -noexec 0
Description
-----------
This example will identify the valid backup files for YourDatabase on YourBackupInstance and restore those files to YourRestoreInstance
.EXAMPLE
Test-DatabaseRestore -databasename YourDatabase -backupinstance YourBackupInstance -restoreinstance YourRestoreInstance -restorepath C:\YourRestorePath -noexec 0
Description
-----------
This example will identify the valid backup files for YourDatabase on YourBackupInstance and restore those files to YourRestoreInstance
If -backupinstance and -restoreinstance are not equal, all backup files will be copied to C:\YourRestorePath on YourRestoreInstance
.EXAMPLE
Test-DatabaseRestore -databasename YourDatabase -backupinstance YourBackupInstance -restoreinstance YourRestoreInstance -restorepath C:\YourRestorePath -stopatdate "2016-06-05 12:59:31" -noexec 0
Description
-----------
This example will identify the valid backup files for YourDatabase on YourBackupInstance before "2016-06-05 12:59:31" and copy those files to C:\YourRestorePath on YourRestoreInstance
The -stopatdate value will be used in the last log restore
.EXAMPLE
Test-DatabaseRestore -databasename YourDatabase -backupinstance YourBackupInstance -restoreinstance YourRestoreInstance -restorepath C:\YourRestorePath -stopatdate "2016-06-05 12:59:31" -noexec 0
Description
-----------
This example will identify the valid backup files for YourDatabase on YourBackupInstance before "2016-06-05 12:59:31" and copy those files to C:\YourRestorePath on YourRestoreInstance
The -stopatdate value will be used in the last log restore
.EXAMPLE
Test-DatabaseRestore -databasename YourDatabase -backupinstance YourBackupInstance -restoreinstance YourRestoreInstance -restorepath C:\YourRestorePath -noexec 1
Description
-----------
This example will identify the valid backup files for YourDatabase on YourBackupInstance and copy those files to C:\YourRestorePath on YourRestoreInstance
The Restore-SqlDatabase commands will be generated and written to file C:\YourRestorePath\restore.sql
.PARAMETER databasename
The database to test restores for
#>
[CmdletBinding()]
param
(
[Parameter(Mandatory=$True,
Position = 1,
ValueFromPipeline=$True,
ValueFromPipelineByPropertyName=$True,
    HelpMessage='What database do you want to test restores for?')]
[Alias('database')]
[string]$databasename,

[Parameter(Mandatory=$True,
Position = 2,
ValueFromPipeline=$True,
ValueFromPipelineByPropertyName=$True,
    HelpMessage='What instance do you want to query for the backup file list?')]
[Alias('backupinst')]
[string]$backupinstance,

[Parameter(Mandatory=$True,
Position = 3,
ValueFromPipeline=$True,
ValueFromPipelineByPropertyName=$True,
    HelpMessage='What instance do you want to restore the backups to?')]
[Alias('restoreinst')]
[string]$restoreinstance,

[Parameter(Mandatory=$True,
Position = 4,
ValueFromPipeline=$True,
ValueFromPipelineByPropertyName=$True,
    HelpMessage='What path do you want to copy the backup files to?')]
[Alias('rp')]
[string]$restorepath,

[Parameter(Mandatory=$False,
Position = 5,
ValueFromPipeline=$True,
ValueFromPipelineByPropertyName=$True,
    HelpMessage='What is the stop at date you want to use for your restores?')]
[Alias('stopat')]
[string]$stopatdate,

    [Parameter(Mandatory=$True,
Position = 6,
ValueFromPipeline=$True,
ValueFromPipelineByPropertyName=$True,
    HelpMessage='Set to 1 if you want to execute the database restore.  Otherwise ')]
[Alias('dontrun')]
[string]$noexec 
)

process {

    cls;

    $rfl = $null;

    <# The $noexec parm must be set to 0 to execute the restore commands #>
    if ($noexec -gt 1)
    {
        "The `$noexec parm was set to {0}. `$noexec must be set to 0 to execute the restore commands. Rerun your call to Test-DatabaseRestore." -f $noexec;
        $noexec = 1;
    }
                
    if($noexec -eq 0)
    {
        <# Insert a dummy row into the restoredurationtotal table to build a restoreid for the set #>
        $query = "INSERT INTO restoredurationtotal DEFAULT VALUES";
        Invoke-Sqlcmd -Query $query -ServerInstance $restoreinstance -database "master";
        $query = "SELECT MAX(restoresetid) AS MaxValue FROM restoredurationtotal";
        <# Store the restoreid from the previous insert in $maxvalue #>
        $maxrestore = Invoke-Sqlcmd -Query $query -ServerInstance $restoreinstance -database "master";
        $maxvalue = ($maxrestore.MaxValue);
    }

    <# A restore path is required if the backup instance and restore instance are not the same #>
    if (($backupinstance -ne $restoreinstance) -and (!$restorepath))
    {
        Throw "You have entered backup instance {0} and restore instance {1}.  Because the instances are different, a restorepath muct be specified." -f $restoreinstance, $backupinstance;
    }

    <# If a $stopatdate value has been passed in, pass it to the stored procedure #> 
    if (!$stopatdate)
    {
        [string]$querystring = "EXEC master.dbo.GetRestoreFiles @db_name = '$databasename'";
    } 
    else
    {
        [string]$querystring = "EXEC master.dbo.GetRestoreFiles @db_name = '$databasename', @stopat = '$stopatdate'";
    }

    <# Execute the stored procedure and pass the result set to variable `$filelist #>
    $filelist = @(Invoke-Sqlcmd -Query $querystring -ServerInstance $backupinstance -database "master")

    <# If no files are returned, throw an error #>
    if ($filelist.Length -eq 0)
    {
        Throw "No valid backup files exist for database {0}.  If you have provided a `$stopatdate, rerun Test-DatabaseRestore without the @stopatdate value and set @noexec to 1 to see the list of valid backup files." -f $databasename
    }
        
    <# Initialize the loop counter and loop limit #>
    if($filelist.Length)
    {
        $filecount = 0;
        $filelimit = ($filelist.Length - 1)
        $array = 1;
    }
    else
    {
        $filecount = 0;
        $filelimit = 1;
        $array = 0;
    }

    <# If either instance is not default, set $restoreserver to the server name #>
    if ($restoreinstance.Contains("\"))
    {
        $restoreserver = $restoreinstance.Substring(0,($restoreinstance.IndexOf("\")));
    }
    else
    {
        $restoreserver = $restoreinstance;
    }

    if ($backupinstance.Contains("\"))
    {
        $backupserver = $backupinstance.Substring(0,($backupinstance.IndexOf("\")));
    }
    else
    {
        $backupserver = $backupinstance;
    }

    <# Build a UNC path to copy the restore files to #>
    $restoreunc = "\\" + $restoreserver + "\" + $restorepath.Replace(":","$");

    <# Test that the restore path exists. If it doesn't, error #>
    $exists = Test-Path $restoreunc;

    if ($exists -eq $false)
    {
        Throw "The restore path provided {0} does not exist.  Please validate the restore path and resubmit." -f $restorepath;
    }

    <# Build a file for the restore commands to be written to #>
    $outfile = $restoreunc +"\restore.ps1";
    
    if (Test-Path $outfile)
    {
        Remove-Item $outfile;
    }
    
    <# Instantiate the $totalts variable to use to track restore duration #>    
    $totalts = New-TimeSpan -Start $(Get-Date) -End $(Get-Date);

    <# Loop through each backup file and build Restore-SqlDatabase commands #>
    while($filecount -le $filelimit)
    {
        <# If multiple files are returned, reference array elements, otherwise reference string object #>
        if($array -eq 0)
        {
            $file = $filelist.physical_device_name;
            $type = $filelist[$filecount].type;
            $filecount = 2;
        }
        else
        {
            $file = $filelist[$filecount].physical_device_name;
            $type = $filelist[$filecount].type;
        }

        <# Build backup file path for copy #>
        $backupunc = "\\" + $backupserver + "\" + $file.Replace(":","$")

        <# If the backup instance is not the same as the restore instance, get the RelocateFile for the restore instance #>
        if ($backupinstance -ne $restoreinstance)
        {
            <# Copy backup files to the restore instance and set the backup file to the new location #>
            Copy-Item $backupunc -Destination $restoreunc;
            $file = $restorepath + "\" + $file.Substring(($file.LastIndexOf("\") + 1),($file.Length - (($file.LastIndexOf("\") + 1))));       

            <# If you are processing a FULL backup, call Get-RelocateFile to build the -RelocateFile #>
            if ($type -eq "D")
                {
                    $rfl = Get-RelocateFile -databasename $databasename -restoreinstance $restoreinstance -backupfile $file;
                }
                else
                {
                    $rfl = $null
                }           
        }

        <# If it is not the last file, use the -Noreplace flag #>
        if ($filecount -lt $filelimit)
        {
            <# If `$noexec is 1, write the commands out #>
            if ($noexec -eq 1)
            {
                <# If it is a log backup, set the -RestoreAction Log flag #>
                if ($type -eq "L")
                {
                    Write-Output "Restore-SqlDatabase -ServerInstance  '$restoreinstance'  -database $databasename -RestoreAction Log -BackupFile $file -ReplaceDatabase -NoRecovery;" | Out-File -FilePath $outfile -Append
                }
                else
                {
                    <# If it is a FULL backup and a RelocateFile parm exists, set the -RelocateFile parm #>
                    if(($type -eq "D") -and ($rfl))
                    {
                        Write-Output "Restore-SqlDatabase -ServerInstance  '$restoreinstance'  -database $databasename -BackupFile $file -RelocateFile $rfl -ReplaceDatabase -NoRecovery;"  | Out-File -FilePath $outfile -Append
                    }
                    else
                    {
                        Write-Output "Restore-SqlDatabase -ServerInstance  '$restoreinstance'  -database $databasename -BackupFile $file -ReplaceDatabase -NoRecovery;"  | Out-File -FilePath $outfile -Append
                    }
                }
            }
            <# If the `$noexec flag is not set, execute the Restore-SqlDatabase commands #>
            else
            {
                <# If it is a LOG backup, use the -RestoreAction Log parm #>
                if ($type -eq "L")
                {

                    $restorestart = Get-Date;
                    $startdateformat = Get-Date -Format yyyy-MM-dd-HH:mm:ss.ms;

                    Restore-SqlDatabase -ServerInstance $restoreinstance  -database $databasename -RestoreAction Log -BackupFile $file -ReplaceDatabase -NoRecovery;

                    $restoreend = Get-Date;
                    $enddateformat = Get-Date -Format yyyy-MM-dd-HH:mm:ss.ms;
                    if($startdateformat -eq $enddateformat)
                    {
                        $startdateformat += $filecount;
                    }

                    $restoreduration = New-TimeSpan -Start $restorestart -End $restoreend;

                    $query = "INSERT INTO dbo.restoredurationitem VALUES ('$maxvalue','$startdateformat','$enddateformat','$file','$type','$restoreduration')";
                    
                    Invoke-Sqlcmd -Query $query -ServerInstance $restoreinstance -database "master" 

                    $logdur = "Log Duration " + $restoreduration.Hours.ToString("00") + ":" + $restoreduration.Minutes.ToString("00") + ":" +  $restoreduration.Seconds.ToString("00") + "." +  $restoreduration.Milliseconds.ToString("000");

                    $totalts = $restoreduration + $totalts;

                }
                else
                {
                    <# If it is a FULL backup and a RestoreFile parm exists, use the -RestoreLocation parm #>
                    if(($type -eq "D") -and ($rfl))
                    {

                        $restorestart = Get-Date;
                        $startdateformat = Get-Date -Format yyyy-MM-dd-HH:mm:ss.ms;

                        Restore-SqlDatabase -ServerInstance $restoreinstance  -database $databasename -BackupFile $file -RelocateFile $rfl -ReplaceDatabase -NoRecovery;

                        $restoreend = Get-Date;
                        $enddateformat = Get-Date -Format yyyy-MM-dd-HH:mm:ss.ms;

                        <# Calculate the $restoreduration for the restore #>
                        $restoreduration = New-TimeSpan -Start $restorestart -End $restoreend;

                        <# Insert a row into the restoredurationitem table #>
                        $query = "INSERT INTO dbo.restoredurationitem VALUES ('$maxvalue','$startdateformat','$enddateformat','$file','$type','$restoreduration')";

                        Invoke-Sqlcmd -Query $query -ServerInstance $restoreinstance -database "master" 

                        <# Add the restore duration to the $totalts #>
                        $totalts = $restoreduration + $totalts;

                    }
                    else
                    {
                        
                        <# Run restore and calculat restore duration#>   
                        $restorestart = Get-Date;
                        $startdateformat = Get-Date -Format yyyy-MM-dd-HH:mm:ss.ms;

                        Restore-SqlDatabase -ServerInstance $restoreinstance  -database $databasename -BackupFile $file -ReplaceDatabase -NoRecovery;

                        $restoreend = Get-Date;

                        <# Format the end date and increment by the filecount if values are identical #>
                        $enddateformat = Get-Date -Format yyyy-MM-dd-HH:mm:ss.ms;

                        if($startdateformat -eq $enddateformat)
                        {
                            $startdateformat += $filecount;
                        }

                        <# Calculate duration for the restore #>
                        $restoreduration = New-TimeSpan -Start $restorestart -End $restoreend;

                        <# Insert duration into the restoredurationitem table #>
                        $query = "INSERT INTO dbo.restoredurationitem VALUES ('$maxvalue','$startdateformat','$enddateformat','$file','$type','$restoreduration')";

                        Invoke-Sqlcmd -Query $query -ServerInstance $restoreinstance -database "master" 

                        <# Increment $totalts #>
                        $totalts = $restoreduration + $totalts;

                    }
                }
                    
            }
        }
        <# If it is the last backup file in the list, do not use the -Norecovery flag #>
        else
        {

            <# If `$noexec is 1, write the commands out #>
            if ($noexec -eq 1)
            {
                <# If it is a log backup, set the -RestoreAction Log flag #>
                if ($type -eq "L")
                {
                    if($stopatdate)
                    {
                        Write-Output "Restore-SqlDatabase -ServerInstance  '$restoreinstance'  -database $databasename -RestoreAction Log -BackupFile $file -ReplaceDatabase -ToPointInTime '$stopatdate';" | Out-File -FilePath $outfile -Append;
                    }
                    else
                    {
                        Write-Output "Restore-SqlDatabase -ServerInstance  '$restoreinstance'  -database $databasename -RestoreAction Log -BackupFile $file -ReplaceDatabase;" | Out-File -FilePath $outfile -Append;
                    }

                }
                else
                {
                    <# If it is a FULL backup and a RestoreFile parm exists, use the -RestoreLocation parm #>
                    if(($type -eq "D") -and ($rfl))
                    {
                        Write-Output "Restore-SqlDatabase -ServerInstance  '$restoreinstance'  -database $databasename -BackupFile $file -RelocateFile $rfl -ReplaceDatabase;"  | Out-File -FilePath $outfile -Append
                    }
                    else
                    {
                        Write-Output "Restore-SqlDatabase -ServerInstance  '$restoreinstance'  -database $databasename -BackupFile $file -ReplaceDatabase;"  | Out-File -FilePath $outfile -Append
                    }
                }
            }
            <# If the `$noexec flag is not set, execute the Restore-SqlDatabase commands #>
            else
            {
                <# If it is a LOG backup, use the -RestoreAction Log parm #>
                if ($type -eq "L")
                {
                    if($stopatdate)
                    {
                        Restore-SqlDatabase -ServerInstance  $restoreinstance  -database $databasename -RestoreAction Log -BackupFile $file -ReplaceDatabase -ToPointInTime "$stopatdate";
                    }
                    else
                    {
                        
                        $restorestart = Get-Date;
                        $startdateformat = Get-Date -Format yyyy-MM-dd-HH:mm:ss.ms;

                        Restore-SqlDatabase -ServerInstance $restoreinstance  -database $databasename -RestoreAction Log -BackupFile $file -ReplaceDatabase;

                        $restoreend = Get-Date;
                        $enddateformat = Get-Date -Format yyyy-MM-dd-HH:mm:ss.ms;
                        if($startdateformat -eq $enddateformat)
                        {
                            $startdateformat += $filecount;
                        }

                        $restoreduration = New-TimeSpan -Start $restorestart -End $restoreend;

                        $query = "INSERT INTO dbo.restoredurationitem VALUES ('$maxvalue','$startdateformat','$enddateformat','$file','$type','$restoreduration')";

                        Invoke-Sqlcmd -Query $query -ServerInstance $restoreinstance -database "master" 

                        $totalts = $restoreduration + $totalts;

                    }
                }
                <# If it is a FULL backup and a RestoreFile parm exists, use the -RestoreLocation parm #>
                else
                {
                    if(($type -eq "D") -and ($rfl))
                    {

                        $restorestart = Get-Date;
                        $startdateformat = Get-Date -Format yyyy-MM-dd-HH:mm:ss.ms;

                        Restore-SqlDatabase -ServerInstance $restoreinstance  -database $databasename -BackupFile $file -ReplaceDatabase;

                        $restoreend = Get-Date;
                        $enddateformat = Get-Date -Format yyyy-MM-dd-HH:mm:ss.ms;
                        if($startdateformat -eq $enddateformat)
                        {
                            $startdateformat += $filecount;
                        }

                        $restoreduration = New-TimeSpan -Start $restorestart -End $restoreend;

                        $query = "INSERT INTO dbo.restoredurationitem VALUES ('$maxvalue','$startdateformat','$enddateformat','$file','$type','$restoreduration')";

                        Invoke-Sqlcmd -Query $query -ServerInstance $restoreinstance -database "master" 

                        $totalts = $restoreduration + $totalts;

                    }
                    else
                    {

                        $restorestart = Get-Date;
                        $startdateformat = Get-Date -Format yyyy-MM-dd-HH:mm:ss.ms;

                        Restore-SqlDatabase -ServerInstance $restoreinstance  -database $databasename -BackupFile $file -ReplaceDatabase;

                        $restoreend = Get-Date;
                        $enddateformat = Get-Date -Format yyyy-MM-dd-HH:mm:ss.ms;
                        if($startdateformat -eq $enddateformat)
                        {
                            $startdateformat += $filecount;
                        }

                        $restoreduration = New-TimeSpan -Start $restorestart -End $restoreend;

                        $query = "INSERT INTO dbo.restoredurationitem VALUES ('$maxvalue','$startdateformat','$enddateformat','$file','$type','$restoreduration')";

                        Invoke-Sqlcmd -Query $query -ServerInstance $restoreinstance -database "master" 

                        $totalts = $restoreduration + $totalts;
                    }
                }
                    
            }

        }

        $filecount += 1;

    }  

    <# Update the dummy row inserted to the restoredurationtotal table with the actual duration #>
    $query = "UPDATE RestoreDurationTotal SET RestoreDatabase = '$databasename', RestoreDuration = '$totalts' WHERE RestoreSetID = '$maxvalue'"
    
    Invoke-Sqlcmd -Query $query -ServerInstance $restoreinstance -database "master";

}
}