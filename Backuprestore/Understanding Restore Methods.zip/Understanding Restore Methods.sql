/* 
Understanding Restore Methods to Ensure Database Recovery 
Copyright Jes Borland, 2015 
*/

		/* Create ClientA and ClientB databases */
		--Database A
		CREATE DATABASE ClientA;
		GO 

		USE ClientA; 
		GO

		CREATE TABLE Products 
		(ProductID INT IDENTITY PRIMARY KEY, 
		ProductName VARCHAR(100), 
		Price FLOAT) 

		INSERT INTO Products 
		VALUES ('Thingamajig', 1.00), ('Gizmo', 2.00), ('Widget', 3.00) 

		CREATE TABLE OrdersClientA 
		(OrderID INT IDENTITY PRIMARY KEY, 
		OrderDate DATETIME2, 
		ClientID INT, 
		ProductID INT FOREIGN KEY REFERENCES Products(ProductID), 
		Quantity INT) 

		INSERT INTO OrdersClientA 
		VALUES ('1/15/2014', 75, 2, 10), ('2/1/2014', 89, 1, 100), ('2/7/2014', 65, 2, 5) 

		SELECT * 
		FROM ClientA.dbo.Products; 

		SELECT * 
		FROM ClientA.dbo.OrdersClientA; 

		--Database B 
		CREATE DATABASE ClientB;
		GO

		USE ClientB; 
		GO

		CREATE TABLE Products 
		(ProductID INT IDENTITY PRIMARY KEY, 
		ProductName VARCHAR(100), 
		Price FLOAT);

		INSERT INTO Products 
		VALUES ('Thingamajig', 1.00), ('Gizmo', 2.00), ('Widget', 3.00);

		CREATE TABLE OrdersClientB 
		(OrderID INT IDENTITY PRIMARY KEY, 
		OrderDate DATETIME2, 
		ClientID INT, 
		ProductID INT FOREIGN KEY REFERENCES Products(ProductID), 
		Quantity INT); 

		INSERT INTO OrdersClientB
		VALUES ('1/28/2014', 87, 3, 25), ('2/4/2014', 87, 1, 10), ('3/9/2014', 23, 2, 16); 

		SELECT * 
		FROM ClientB.dbo.Products; 

		SELECT * 
		FROM ClientB.dbo.OrdersClientB; 
		
		/* Full backups */
		--BACKUP DATABASE ClientA TO DISK = 'D:\SQL Backups\ClientA\ClientA_Full.bak';
	 --   BACKUP DATABASE ClientB TO DISK = 'D:\SQL Backups\ClientB\ClientB_Full.bak';

		/*Create a database with multiple filegroups and files */

		CREATE DATABASE OrganizeMyLego
		ON PRIMARY
		(NAME = OrganizeMyLego_data,
		 FILENAME = 'C:\Program Files\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\OrganizeMyLego_data.mdf'),
		FILEGROUP LargeLego
		(NAME = LargeLego_1,
		 FILENAME = 'D:\SQL files\LargeLego_1.mdf')
		LOG ON
		(NAME = OrganizeMyLego_log,
		 FILENAME = 'C:\Program Files\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\OrganizeMyLego_log.ldf');

		ALTER DATABASE OrganizeMyLego
		ADD FILE
		(NAME = LargeLego_2,
		 FILENAME = 'D:\SQL files\LargeLego_2.mdf')
		TO FILEGROUP LargeLego;

		ALTER DATABASE OrganizeMyLego
		ADD FILEGROUP MediumLego; 

		ALTER DATABASE OrganizeMyLego
		ADD FILE
		(NAME = MediumLego_1,
		 FILENAME = 'D:\SQL files\MediumLego_1.mdf'), 
		(NAME = MediumLego_2,
		 FILENAME = 'D:\SQL files\MediumLego_2.mdf')
		TO FILEGROUP MediumLego; 

		ALTER DATABASE OrganizeMyLego 
		ADD FILEGROUP SmallLego;

		ALTER DATABASE OrganizeMyLego 
		ADD FILE
		(NAME = SmallLego_1,
		 FILENAME = 'D:\SQL files\SmallLego_1.mdf'),  
		(NAME = SmallLego_2,
		 FILENAME = 'D:\SQL files\SmallLego_2.mdf')
		TO FILEGROUP SmallLego; 

		ALTER DATABASE OrganizeMyLego 
		ADD FILEGROUP ArchiveLego;

		ALTER DATABASE OrganizeMyLego 
		ADD FILE
		( NAME = LegoArchive_1,
		 FILENAME = 'D:\SQL files\LegoArchive_1.mdf')
		TO FILEGROUP ArchiveLego;

		/* Populate the database. */ 

		/* Archive table*/
		USE OrganizeMyLego;
		GO
		CREATE TABLE LegoSold 
			(ID INT IDENTITY, 
			DateSold DATETIME2, 
			SizeOfLego VARCHAR(25), 
			Color VARCHAR(25), 
			Quantity INT, 
			Price MONEY)
		ON ArchiveLego; 

		INSERT INTO LegoSold 
		VALUES ('2014/02/17', '32x32', 'Green', 10, 5.00);

		/* Large Lego */
		CREATE TABLE Large32x32 
			(ID INT IDENTITY, 
			Color VARCHAR(25), 
			Quantity INT) 
		ON LargeLego; 

		CREATE NONCLUSTERED INDEX IX_Large32x32_Color ON dbo.Large32x32(Color)
			ON MediumLego;

		INSERT INTO Large32x32 
		VALUES ('Green', 28), 
				('Gray', 5); 

		/* Medium Lego */
		CREATE TABLE Medium8x2 
			(ID INT IDENTITY, 
			Color VARCHAR(25), 
			Quantity INT) 
		ON MediumLego; 

		INSERT INTO Medium8x2 
		VALUES ('Blue', 137), 
				('Red', 222), 
				('White', 143); 

		/* Small Lego */
		CREATE TABLE Small4x2 
			(ID INT IDENTITY, 
			Color VARCHAR(25), 
			Quantity INT) 
		ON SmallLego; 

		INSERT INTO Small4x2 
		VALUES ('Black', 98), 
				('Red', 178), 
				('Yellow', 166); 

		/* Full backup */
		BACKUP DATABASE OrganizeMyLego TO DISK = 'D:\SQL Backups\OrganizeMyLego\OrganizeMyLego_FullBackup.bak' 
		WITH NOINIT, COMPRESSION; 

--------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------

/* Point in time restores */

/* Using STOPAT */

		--MSSQLSERVER 
		SELECT * 
		FROM dbo.Large32x32; 
		--Make change 
		USE OrganizeMyLego; 
		GO
		UPDATE dbo.Large32x32 
		SET Quantity = 0 
		WHERE ID=2; 
		SELECT GETDATE(); --> 2015-06-09 17:10:51.010

		DELETE 
		FROM dbo.Large32x32 
		WHERE ID = 1;
		SELECT GETDATE(); --> 2015-06-09 17:11:13.763

		--OOOPS! 
		USE OrganizeMyLego; 
		GO
		DELETE 
		FROM dbo.Large32x32 
		--WHERE ID IN (3, 4, 5);
		SELECT GETDATE(); --> 2015-06-09 17:12:15.827

		SELECT * 
		FROM dbo.Large32x32; 

		--Log backup 
		BACKUP LOG OrganizeMyLego TO DISK = 'D:\SQL Backups\OrganizeMyLego\OrganizeMyLego_Log1.trn';

		--Connect to SQL02 
		--Restore full 
		RESTORE FILELISTONLY FROM DISK = 'D:\SQL Backups\OrganizeMyLego\OrganizeMylego_FullBackup.bak' 

		RESTORE DATABASE OrganizeMyLego FROM DISK = 'D:\SQL Backups\OrganizeMyLego\OrganizeMylego_FullBackup.bak' 
			WITH NORECOVERY, 
			REPLACE, 
			MOVE 'OrganizeMyLego_data' TO 'C:\Program Files\Microsoft SQL Server\MSSQL12.SQL02\MSSQL\DATA\OrganizeMyLego.mdf', 
			MOVE 'LargeLego_1' TO 'C:\Program Files\Microsoft SQL Server\MSSQL12.SQL02\MSSQL\DATA\LargeLego_1.mdf', 
			MOVE 'LargeLego_2' TO 'C:\Program Files\Microsoft SQL Server\MSSQL12.SQL02\MSSQL\DATA\LargeLego_2.mdf', 
			MOVE 'MediumLego_1' TO 'C:\Program Files\Microsoft SQL Server\MSSQL12.SQL02\MSSQL\DATA\MediumLego_1.mdf', 
			MOVE 'MediumLego_2' TO 'C:\Program Files\Microsoft SQL Server\MSSQL12.SQL02\MSSQL\DATA\MediumLego_2.mdf', 
			MOVE 'SmallLego_1' TO 'C:\Program Files\Microsoft SQL Server\MSSQL12.SQL02\MSSQL\DATA\SmallLego_1.mdf', 
			MOVE 'SmallLego_2' TO 'C:\Program Files\Microsoft SQL Server\MSSQL12.SQL02\MSSQL\DATA\SmallLego_2.mdf', 
			MOVE 'LegoArchive_1' TO 'C:\Program Files\Microsoft SQL Server\MSSQL12.SQL02\MSSQL\DATA\LegoArchive_1.mdf', 
			MOVE 'OrganizeMyLego_log' TO 'C:\Program Files\Microsoft SQL Server\MSSQL12.SQL02\MSSQL\DATA\OrganizeMyLego_log.ldf'; 

		--Restore log with STOPAT 2nd change 
		RESTORE LOG OrganizeMyLego FROM DISK = 'D:\SQL Backups\OrganizeMyLego\OrganizeMyLego_Log1.trn' 
			WITH NORECOVERY, 
			STOPAT = '2015-06-09 17:12:10';

		--Restore with recovery 
		RESTORE DATABASE OrganizeMyLego 
			WITH RECOVERY; 

		USE OrganizeMyLego;
		GO 
		SELECT * 
		FROM dbo.Large32x32; 

		/* If I didn't know exactly when the transaction occurred, how could I find it? */
		SELECT [Current LSN], Operation, Context, AllocUnitName, [Page ID], [Begin Time], [Transaction Name] 
		FROM fn_dblog(NULL, NULL);

		/* On SQL02 */
		USE master;
		GO
		DROP DATABASE OrganizeMyLego; 
		GO 
		/* End STOPAT command */

/* Connect to MSSQLSERVER */
/* Marked transaction */
		--ClientA 
		--ClientB 
		--Each DB is for a separate client's sales. We have a shared product table. Prices need to be updated across them. 

		/* MUST have full backup of each database in place for marked transactions to work. */
			BACKUP DATABASE ClientA TO DISK = N'D:\SQL Backups\ClientA\ClientA.bak' 
			WITH NOINIT;
			BACKUP DATABASE ClientB TO DISK = N'D:\SQL Backups\ClientB\ClientB.bak' 
			WITH NOINIT;

		--Current state 
		SELECT * 
		FROM ClientA.dbo.Products; 

		SELECT * 
		FROM ClientA.dbo.OrdersClientA; 

		SELECT * 
		FROM ClientB.dbo.Products; 

		SELECT * 
		FROM ClientB.dbo.OrdersClientB; 

		--Marked transaction to update prices of products 
		DECLARE @VariableName varchar(5)
		Set @VariableName='ABC'
		BEGIN TRAN UpdateProductPrices 
			WITH MARK @VariableName --ABC

			UPDATE ClientA.dbo.Products
			SET Price = Price * 1.1; 
			UPDATE ClientB.dbo.Products
			SET Price = Price * 1.1; 

		COMMIT TRANSACTION UpdateProductPrices

		--Additional activity in each database 
		BEGIN TRANSACTION 
		INSERT INTO ClientB.dbo.OrdersClientB
		VALUES ('4/2/2014', 97, 1, 25);
		COMMIT TRANSACTION

		BEGIN TRANSACTION
		INSERT INTO ClientA.dbo.OrdersClientA
		VALUES ('4/2/2014', 44, 2, 1);
		COMMIT TRANSACTION

		--Transaction log backup 
		BACKUP LOG ClientA TO DISK = N'D:\SQL Backups\ClientA\ClientAWithMark.trn';
		BACKUP LOG ClientB TO DISK = N'D:\SQL Backups\ClientB\ClientBWithMark.trn';

		SELECT [Current LSN], Operation, Context, AllocUnitName, [Page ID], [Begin Time], [Transaction Name] 
		FROM fn_dblog(NULL, NULL);

		--Drop databases 
		USE master;
		GO
		DROP DATABASE ClientA;
		DROP DATABASE ClientB; 

		--Restore ClientA 
		RESTORE DATABASE ClientA FROM DISK = N'D:\SQL Backups\ClientA\ClientA.bak'
			WITH NORECOVERY;
		RESTORE LOG ClientA FROM DISK = N'D:\SQL Backups\ClientA\ClientAWithMark.trn' 
			WITH NORECOVERY, 
			STOPBEFOREMARK = 'UpdateProductPrices';
			--STOPATMARK = 'UpdateProductPrices';
		RESTORE DATABASE ClientA 
			WITH RECOVERY; 

		--Restore ClientB 
		RESTORE DATABASE ClientB FROM DISK = N'D:\SQL Backups\ClientB\ClientB.bak'
			WITH NORECOVERY;
		RESTORE LOG ClientB FROM DISK = N'D:\SQL Backups\ClientB\ClientBWithMark.trn' 
			WITH NORECOVERY, 
			STOPBEFOREMARK = 'UpdateProductPrices'; 
			--STOPATMARK = 'UpdateProductPrices'; 
		RESTORE DATABASE ClientB 
			WITH RECOVERY; 

		--Current state 
		SELECT * 
		FROM ClientA.dbo.Products; 

		SELECT * 
		FROM ClientA.dbo.OrdersClientA; 

		SELECT * 
		FROM ClientB.dbo.Products; 

		SELECT * 
		FROM ClientB.dbo.OrdersClientB; 

		/* Could use STOPATMARK instead of STOPBEFOREMARK */
		/* Could use LSN instead of named transaction */

		/* Using msdb.dbo.logmarkhistory */
		SELECT *
		FROM msdb.dbo.logmarkhistory;
		/* End marked transaction */

		/* 
		Clean up
		Drop databases 
		Delete backup files 
		*/
		USE master;
		GO
		DROP DATABASE ClientA;
		DROP DATABASE ClientB;

---------------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------

/* Page restore */
		/* Create database */
		RESTORE DATABASE CorruptMe
			FROM DISK=N'D:\Software Downloads\Adventure Works 2014 Full Database Backup\AdventureWorks2014.bak'
			WITH MOVE 'AdventureWorks2014_Data' to 'C:\Program Files\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\CorruptMe_Data.mdf',
			MOVE 'AdventureWorks2014_Log' to 'C:\Program Files\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\CorruptMe_log.ldf';

		ALTER DATABASE CorruptMe SET RECOVERY FULL;
		GO 

		/* Back up database */
		BACKUP DATABASE CorruptMe to DISK=N'D:\SQL Backups\CorruptMe_Full.bak' 
			WITH COMPRESSION;
		GO

		/* Pick a table with a Clustered index and a Nonclustered index */ 
		USE CorruptMe; 
		GO 
		SELECT *
		FROM Purchasing.ShipMethod;
		GO 

		/* Back up log */
		BACKUP LOG CorruptMe TO DISK=N'D:\SQL Backups\CorruptMe_Log1.trn' 
			WITH COMPRESSION;
		GO

		/* Update table */ 
		UPDATE Purchasing.ShipMethod 
		SET Name = 'JACK JACK EXPRESS' 
		WHERE ShipMethodID = 1; 

		CHECKPOINT
		GO 

		/* Demo 1 - clustered index */ 
		/* Find page number 
		The sys.dm_db_database_page_allocations method will only work in SQL server 2012 + */
		--Purchasing.ShipMethod IndexID=1 (clustered index)
		
		SELECT allocated_page_page_id 
		FROM sys.dm_db_database_page_allocations(DB_ID('CorruptMe'), OBJECT_ID('Purchasing.ShipMethod'), 1, NULL, 'detailed')
		WHERE page_type_desc='DATA_PAGE'
			AND is_allocated = 1
		ORDER BY allocated_page_page_id ASC;
		GO
		/* Page = 820 */

		/* Prior to SQL Server 2012, use DBCC IND */ 
		DBCC IND ('CorruptMe', 'Purchasing.ShipMethod', 1); 
		/* Choose a page number, based on PageType of 1 or 2 */ 

		/* Take the database offline */ 
		USE master;
		GO
		ALTER DATABASE CorruptMe SET OFFLINE;
		GO

		/* 
				Navigate to D:\Software Downloads\xvi32
				Start xvi32 with elevated permissions (Right click -> Run as Administrator)

				Inside xvi32, open the file 'C:\Program Files\Microsoft SQL Server\MSSQL11.MSSQLSERVER\MSSQL\DATA\CorruptMe_Data.mdf'

				Address > Goto 
				Use decimal 

				Offset = pageid * 8192
				For page 820 = 820 * 8192 = 6717440
				Change data 
				Save and close the file 
		*/ 

		/* Bring database online */ 
		ALTER DATABASE CorruptMe SET ONLINE;
		GO

		/* Try to view data */ 
		USE CorruptMe;
		GO

		SELECT * 
		FROM Person.Person; 
		GO 

		SELECT * 
		FROM Purchasing.ShipMethod;
		GO 

		SELECT Name 
		FROM Purchasing.ShipMethod;
		GO 

		/* Suspect pages - only show up here after you try to read the pages */
		select *
		from msdb.dbo.suspect_pages;

		/* Review SQL Server error log */ 

		/* Detecting corruption */  
		DBCC CHECKDB ('CorruptMe');
		GO

		DBCC CHECKDB ('CorruptMe') WITH NO_INFOMSGS;
		GO 

		/* Fixing corruption */ 
		/* What object is that on? */ 
		SELECT OBJ.object_id, OBJ.name, OBJ.type_desc, IND.index_id, IND.name 
		FROM sys.objects OBJ 
			INNER JOIN sys.indexes IND ON IND.object_id = OBJ.object_id 
		WHERE OBJ.object_id=78623323; 

		/* Clustered index  - Restore the page */ 
		/* This example uses an OFFLINE restore, which is applicable to all versions of SQL Server. 
		Enterprise Edition allows you to do an ONLINE restore, which is a demo for a different day. */ 
		USE master; 
		GO 

		/* This makes the database "offline" - you don't actually set it OFFLINE */ 
		/* No, this isn't confusing at all, I know. */ 
		BACKUP LOG CorruptMe TO Disk=N'D:\SQL Backups\CorruptMe_Log2.trn'
			WITH NORECOVERY;
		GO 

		/* Restore full backup with PAGE */ 
		RESTORE DATABASE CorruptMe 
			PAGE='1:820' --Have multiple? Separate with commmas. 
			FROM DISK=N'D:\SQL Backups\CorruptMe_Full.bak' 
			WITH NORECOVERY; 

		/* Restore log backups */ 
		RESTORE LOG CorruptMe FROM Disk=N'D:\SQL Backups\CorruptMe_Log1.trn' 
			WITH NORECOVERY; 

		RESTORE LOG CorruptMe FROM Disk=N'D:\SQL Backups\CorruptMe_Log2.trn' 
			WITH NORECOVERY;

		RESTORE DATABASE CorruptMe 
			WITH RECOVERY; 

		/* Is it fixed? */
		USE CorruptMe; 
		GO
		SELECT * 
		FROM Purchasing.ShipMethod;
		GO 

		DBCC CHECKDB ('CorruptMe') WITH NO_INFOMSGS;
		GO 

		/* What if you didn't have a recent full and/or log backup? */ 
		/* End clustered index */ 

		/* Non-clustered index */ 
		/* Find page number */
		--Purchasing.ShipMethod IndexID=2 (nonclustered index) AK_ShipMethod_Name
		SELECT allocated_page_page_id
		FROM sys.dm_db_database_page_allocations(DB_ID('CorruptMe'), OBJECT_ID('Purchasing.ShipMethod'), 2, NULL, 'detailed')
		WHERE page_type_desc='INDEX_PAGE' 
			AND is_allocated = 1
		ORDER BY allocated_page_page_id ASC;
		GO 
		/* Page = 5258 */ 

		/* Take the database offline */ 
		USE master;
		GO
		ALTER DATABASE CorruptMe SET OFFLINE;
		GO

		/* 
				Navigate to D:\Software Downloads\xvi32
				Start xvi32 with elevated permissions (Right click -> Run as Administrator)

				Inside xvi32, open the file 'C:\Program Files\Microsoft SQL Server\MSSQL11.MSSQLSERVER\MSSQL\DATA\CorruptMe_Data.mdf'

				Address > Goto 
				Use decimal 

				Offset = pageid * 8192
					For page 5258 = 5258 * 8192 = 43073536
				Change data 
				Save and close the file 
		*/ 

		/* Bring database online */ 
		ALTER DATABASE CorruptMe SET ONLINE;
		GO

		select *
		from msdb.dbo.suspect_pages;

		/* Try to view data */ 
		USE CorruptMe;
		GO

		SELECT * 
		FROM Person.Person; 
		GO 

		SELECT * 
		FROM Purchasing.ShipMethod;
		GO

		SELECT Name 
		FROM Purchasing.ShipMethod;
		GO 

		/* Review SQL Server error log */ 

		/* Detecting corruption */  
		DBCC CHECKDB ('CorruptMe') WITH NO_INFOMSGS;
		GO 

		/* Fixing corruption */ 
		/* What object is that on? */ 
		SELECT OBJ.object_id, OBJ.name, OBJ.type_desc, IND.index_id, IND.name 
		FROM sys.objects OBJ 
		INNER JOIN sys.indexes IND ON IND.object_id = OBJ.object_id 
		WHERE OBJ.object_id=78623323 and IND.index_id=2; 

		/* Try rebuild - does this work? */
		ALTER INDEX AK_ShipMethod_Name ON Purchasing.ShipMethod 
		REBUILD; 
		GO 

		/* Tray Disable / Rebuild */ 
		ALTER INDEX AK_ShipMethod_Name ON Purchasing.ShipMethod 
		DISABLE; 
		ALTER INDEX AK_ShipMethod_Name ON Purchasing.ShipMethod 
		REBUILD; 
		GO 

		/* Try to view data */ 
		SELECT * 
		FROM Purchasing.ShipMethod;
		GO

		SELECT Name 
		FROM Purchasing.ShipMethod;
		GO 

		DBCC CHECKDB ('CorruptMe') WITH NO_INFOMSGS;
		GO 
		/* End nonclustered index */ 

		/* Clean up */
		USE master;
		GO 
		DROP DATABASE CorruptMe;
		GO

		/* Delete backup files! */

-----------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------

/* Piecemeal restore */

		/* Check setup */
		/* Filegroups and files */
		USE OrganizeMyLego;
		GO 
		SELECT FG.name as FilegroupName, 
			DF.name as [FileName] 
		FROM sys.database_files DF 
			INNER JOIN sys.filegroups FG ON FG.data_space_id = DF.data_space_id; 

		/* Query sys.filegroups. Which is default? */
		USE OrganizeMyLego;
		SELECT name, data_space_id, [type], type_desc, is_default, filegroup_guid, log_filegroup_id, is_read_only 
		FROM sys.filegroups
		WHERE is_default=1;

		/* Objects on filegroups */
		USE OrganizeMyLego;
		GO 
		SELECT FG.name AS FilegroupName, 
			OBJ.name AS ObjectName, 
			OBJ.type_desc AS ObjectType, 
			PA.index_id AS IndexID 
		FROM sys.filegroups FG
			INNER JOIN sys.allocation_units AU ON AU.data_space_id = FG.data_space_id
			INNER JOIN sys.partitions PA ON PA.partition_id = AU.container_id 
			INNER JOIN sys.objects OBJ ON OBJ.object_id = PA.object_id
		WHERE OBJ.type_desc NOT IN ('SYSTEM_TABLE', 'INTERNAL_TABLE')
		ORDER BY FG.name;

		/* DB must be (FULL recovery) OR (SIMPLE recovery AND read-only) */
		ALTER DATABASE OrganizeMyLego SET RECOVERY FULL;

		/* Mark ArchiveLego read-only */
		ALTER DATABASE OrganizeMyLego SET RESTRICTED_USER WITH ROLLBACK IMMEDIATE;
		ALTER DATABASE OrganizeMyLego MODIFY FILEGROUP ArchiveLego READONLY;
		ALTER DATABASE OrganizeMyLego SET MULTI_USER;

		/* Full backup. */
		BACKUP DATABASE OrganizeMyLego TO DISK = N'D:\SQL Backups\OrganizeMyLego\OrganizeMyLego_FullBackup.bak'
		WITH INIT; 

		/* Add record. */
		USE OrganizeMyLego;
		INSERT INTO dbo.Large32x32
		VALUES  ('Blue', 2); 

		/* Transaction log backup. */
		USE master;
		BACKUP LOG OrganizeMyLego TO DISK = N'D:\SQL Backups\OrganizeMyLego\OrganizeMyLego_Log1.trn'
			WITH INIT ; 

		/* Add record. */
		USE OrganizeMyLego;
		INSERT INTO dbo.Medium8x2
		VALUES  ('Orange', 45);

		--Back up tail of the log. 
		USE master;
		BACKUP LOG OrganizeMyLego TO DISK = N'D:\SQL Backups\OrganizeMyLego\OrganizeMyLego_LogTail.trn' 
			WITH NORECOVERY, 
			INIT, 
			NO_TRUNCATE;

		/* DISASTER! */ 
		USE master;
		DROP DATABASE OrganizeMyLego;

		/* This is a "partial-restore sequence". 
		   First restore must include PRIMARY filegroup. 
		   Must include WITH PARTIAL. 
		   All restores must include logs if in FULL. */
		RESTORE DATABASE OrganizeMyLego 
		FILEGROUP = 'Primary'
		FROM DISK = N'D:\SQL Backups\OrganizeMyLego\OrganizeMyLego_FullBackup.bak'
			WITH PARTIAL, 
			NORECOVERY; 
		RESTORE LOG OrganizeMyLego 
		FROM DISK = N'D:\SQL Backups\OrganizeMyLego\OrganizeMyLego_Log1.trn' 
			WITH NORECOVERY; 
		RESTORE LOG OrganizeMyLego 
		FROM DISK = N'D:\SQL Backups\OrganizeMyLego\OrganizeMyLego_LogTail.trn' 
			WITH NORECOVERY;
		RESTORE DATABASE OrganizeMyLego
			WITH RECOVERY;

		/* Check file state. */
		SELECT [name], [state_desc] 
		FROM OrganizeMyLego.sys.database_files;

		/* Try to select from the Large32x32 table. */
		USE OrganizeMyLego; 
		GO
		SELECT Color, Quantity
		FROM dbo.Large32x32;

		/* Restore LargeLego
		   NOTE: no "PARTIAL" here. 
		   "Filegroup-restore sequence". */
		USE master;
		RESTORE DATABASE OrganizeMyLego 
		FILEGROUP = 'LargeLego'
		FROM DISK = N'D:\SQL Backups\OrganizeMyLego\OrganizeMyLego_FullBackup.bak' 
			WITH NORECOVERY;
		RESTORE LOG OrganizeMyLego 
		FROM DISK = N'D:\SQL Backups\OrganizeMyLego\OrganizeMyLego_Log1.trn' 
			WITH NORECOVERY; 
		RESTORE LOG OrganizeMyLego 
		FROM DISK = N'D:\SQL Backups\OrganizeMyLego\OrganizeMyLego_LogTail.trn' 
		WITH NORECOVERY;
		RESTORE DATABASE OrganizeMyLego
			WITH RECOVERY;

		/* Try to select from the Large32x32 table again. */
		USE OrganizeMyLego; 
		GO
		SELECT Color, Quantity
		FROM dbo.Large32x32;

		/* Try to insert into Large32x32 table 
		   Remember, both clustered and non-clustered indexes. */
		INSERT INTO dbo.Large32x32
		VALUES  ('White', 2); 

		/* Try to select from Medium8x2 */
		SELECT Color, Quantity 
		FROM dbo.Medium8x2;

		/* Restore MediumLego. */
		USE master;
		RESTORE DATABASE OrganizeMyLego 
		FILEGROUP = 'MediumLego'
		FROM DISK = N'D:\SQL Backups\OrganizeMyLego\OrganizeMyLego_FullBackup.bak' 
			WITH NORECOVERY; 
		RESTORE LOG OrganizeMyLego 
		FROM DISK = N'D:\SQL Backups\OrganizeMyLego\OrganizeMyLego_Log1.trn' 
			WITH NORECOVERY; 
		RESTORE LOG OrganizeMyLego 
		FROM DISK = N'D:\SQL Backups\OrganizeMyLego\OrganizeMyLego_LogTail.trn' 
			WITH NORECOVERY;
		RESTORE DATABASE OrganizeMyLego
			WITH RECOVERY;

		/* Try to insert into Large32x32  
		   Remember, both clustered and non-clustered indexes. */
		USE OrganizeMyLego;
		GO
		INSERT INTO dbo.Large32x32
		VALUES  ('White', 2); 

		/* Try to select from Medium8x2 */
		SELECT Color, Quantity 
		FROM dbo.Medium8x2;

		/* Try to insert into Medium 8x2 */
		INSERT INTO Medium8x2 
		VALUES ('Yellow', 55);

		/* Try to select from LegoSold */
		SELECT ID, DateSold, Quantity 
		FROM dbo.LegoSold; 

		/* Restore ArchiveLego. 
		   Because this is a read-only filegroup, no log restores necessary. */
		USE master;
		RESTORE DATABASE OrganizeMyLego
		FILEGROUP = 'ArchiveLego'
		FROM DISK = N'D:\SQL Backups\OrganizeMyLego\OrganizeMyLego_FullBackup.bak' 
			WITH NORECOVERY;
		RESTORE DATABASE OrganizeMyLego
			WITH RECOVERY; 

		/* Try to select from LegoSold */
		USE OrganizeMyLego; 
		GO 
		SELECT ID, DateSold, Quantity 
		FROM dbo.LegoSold; 



		/* Check file state. */
		SELECT [name], [state_desc] 
		FROM OrganizeMyLego.sys.database_files;



		/* Cleanup! */
		USE master;
		DROP DATABASE OrganizeMyLego; 

		/* Delete backups */ 