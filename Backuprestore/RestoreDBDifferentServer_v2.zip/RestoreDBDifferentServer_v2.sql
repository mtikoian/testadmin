Use DBA;
GO

IF OBJECT_ID('dbo.RestoreDBDiffServer','P') IS NULL  
    EXECUTE ('CREATE PROCEDURE dbo.RestoreDBDiffServer AS SELECT 1');
GO
Alter Procedure dbo.RestoreDBDiffServer 
	@DbSourceServer	varchar(128) = N'someserver',
	@DBName varchar(128) = 'SomeDB',
	@RestoreDate datetime,
	@RestoreDBAs	varchar(128) = NULL

/*
Generate Restore script, given only DBName and Point-in-time timestamp
Works in >= SQL 2008 databases!!

Script for generating restore script for full backup: Michael Valentine Jones, SQLTeam.com

Adapted to Restore to different Server dynamically (e.g. warehouse or Report server): Jason Brimhall


*/

As
SET NOCOUNT ON;

/*
-- This is the name of the source server to be used in the linked server
DECLARE
  @DbSourceServer	varchar(128) = N'someserver'
*/
  If Not Exists (select 1 from sys.servers where name = 'BACKUP')
	EXEC master.sys.sp_addlinkedserver @server = N'BACKUP', @srvproduct=N'', @provider=N'SQLOLEDB', @datasrc=@DbSourceServer
	EXEC master.sys.sp_addlinkedsrvlogin @rmtsrvname = N'BACKUP', @locallogin = NULL , @useself = N'True';
	

/*
--uncomment this section if looking to create a linked server as part of the restore process
Execute dbo.CreateLinkedServer @DbSourceServer;
*/
DECLARE
  @Filename varchar(256),
  @tab varchar(1) = char(9),
  @cr varchar(2) = char(13)+char(10),
  @Full_BackupStartDate datetime,
  @SQL nvarchar(max) = '',
  @Version	varchar(2),
  @ProdVer	varchar(20)
 -- 	@DBName varchar(128) = 'AdminDB',
	--@RestoreDate datetime = getdate() +1

DECLARE @Default_Data_Path VARCHAR(1024),   
        @Default_Log_Path VARCHAR(1024)
       ;

--Get the default data path
--to only be used when the db does not already exist
--limitation of this is that it will only work with 1 data file
with presel as (
	Select LEFT(physical_name,LEN(physical_name)-CHARINDEX('\',REVERSE(physical_name))+1) as DefPath,type
			,row_number() over (partition by [type] order by count(type) desc) as RowNum
		From sys.master_files
		Group By type,LEFT(physical_name,LEN(physical_name)-CHARINDEX('\',REVERSE(physical_name))+1)
)
SELECT @Default_Data_Path = (select defpath  from presel where type = 0 and rownum = 1)
	,@Default_Log_Path  = (select defpath from presel where type = 1 and rownum = 1)

Select @ProdVer = Convert(varchar(20),SERVERPROPERTY('productversion'))

Set @Version = Left(@ProdVer,2)
  -->Create a Linked server for use to restore on a different Server


BEGIN TRY
  --> Performing some checks
  IF NOT EXISTS (SELECT 1 FROM [backup].[msdb].[dbo].backupset WHERE database_name = @DBName AND type = 'D' AND backup_start_date < @RestoreDate)
    RAISERROR(N'No backup exists after the specified RestoreDate', 16, 1)

  --> Getting the filename and the date of the last full backup prior to the RestoreDate
  SELECT TOP 1
    @Filename = b.physical_device_name,
    @Full_BackupStartDate = backup_start_date
  FROM [backup].[msdb].[dbo].backupset a
    INNER JOIN [backup].[msdb].[dbo].backupmediafamily b
      ON a.media_set_id = b.media_set_id
  WHERE a.database_name = @DBName
    AND a.type = 'D'
    AND a.backup_start_date  < @RestoreDate
	Order By a.backup_start_date desc

	-->Create temp-tables for file header information

  DECLARE @header2012 table (
    BackupName nvarchar(128),
    BackupDescription nvarchar(255),
    BackupType smallint,
    ExpirationDate datetime,
    Compressed bit,
    Position smallint,
    DeviceType tinyint,
    UserName nvarchar(128),
    ServerName nvarchar(128),
    DatabaseName nvarchar(128),
    DatabaseVersion int,
    DatabaseCreationDate datetime,
    BackupSize numeric(20,0),
    FirstLSN numeric(25,0),
    LastLSN numeric(25,0),
    CheckpointLSN numeric(25,0),
    DatabaseBackupLSN numeric(25,0),
    BackupStartDate datetime,
    BackupFinishDate datetime,
    SortOrder smallint,
    CodePage smallint,
    UnicodeLocaleId int,
    UnicodeComparisonStyle int,
    CompatibilityLevel tinyint,
    SoftwareVendorId int,
    SoftwareVersionMajor int,
    SoftwareVersionMinor int,
    SoftwareVersionBuild int,
    MachineName nvarchar(128),
    Flags  int,
    BindingID uniqueidentifier,
    RecoveryForkID uniqueidentifier,
    Collation nvarchar(128),
    FamilyGUID uniqueidentifier,
    HasBulkLoggedData bit,
    IsSnapshot bit,
    IsReadOnly bit,
    IsSingleUser bit,
    HasBackupChecksums bit,
    IsDamaged bit,
    BeginsLogChain bit,
    HasIncompleteMetaData bit,
    IsForceOffline bit,
    IsCopyOnly bit,
    FirstRecoveryForkID uniqueidentifier,
    ForkPointLSN numeric(25,0) NULL,
    RecoveryModel nvarchar(60),
    DifferentialBaseLSN numeric(25,0) NULL,
    DifferentialBaseGUID uniqueidentifier,
    BackupTypeDescription nvarchar(60),
    BackupSetGUID uniqueidentifier NULL,
    CompressedBackupSize bigint,
	Containment int,
    Seq int NOT NULL identity(1,1) Primary Key Clustered
    )

  DECLARE @header table (
    BackupName nvarchar(128),
    BackupDescription nvarchar(255),
    BackupType smallint,
    ExpirationDate datetime,
    Compressed bit,
    Position smallint,
    DeviceType tinyint,
    UserName nvarchar(128),
    ServerName nvarchar(128),
    DatabaseName nvarchar(128),
    DatabaseVersion int,
    DatabaseCreationDate datetime,
    BackupSize numeric(20,0),
    FirstLSN numeric(25,0),
    LastLSN numeric(25,0),
    CheckpointLSN numeric(25,0),
    DatabaseBackupLSN numeric(25,0),
    BackupStartDate datetime,
    BackupFinishDate datetime,
    SortOrder smallint,
    CodePage smallint,
    UnicodeLocaleId int,
    UnicodeComparisonStyle int,
    CompatibilityLevel tinyint,
    SoftwareVendorId int,
    SoftwareVersionMajor int,
    SoftwareVersionMinor int,
    SoftwareVersionBuild int,
    MachineName nvarchar(128),
    Flags  int,
    BindingID uniqueidentifier,
    RecoveryForkID uniqueidentifier,
    Collation nvarchar(128),
    FamilyGUID uniqueidentifier,
    HasBulkLoggedData bit,
    IsSnapshot bit,
    IsReadOnly bit,
    IsSingleUser bit,
    HasBackupChecksums bit,
    IsDamaged bit,
    BeginsLogChain bit,
    HasIncompleteMetaData bit,
    IsForceOffline bit,
    IsCopyOnly bit,
    FirstRecoveryForkID uniqueidentifier,
    ForkPointLSN numeric(25,0) NULL,
    RecoveryModel nvarchar(60),
    DifferentialBaseLSN numeric(25,0) NULL,
    DifferentialBaseGUID uniqueidentifier,
    BackupTypeDescription nvarchar(60),
    BackupSetGUID uniqueidentifier NULL,
    CompressedBackupSize bigint,
    Seq int NOT NULL identity(1,1) Primary Key Clustered
    )

  --> Create temp-table for db file information
  DECLARE @filelist TABLE  (
    LogicalName nvarchar(128),
    PhysicalName nvarchar(260),
    Type char(1),
    FileGroupName nvarchar(128),
    Size numeric(20,0),
    MaxSize numeric(20,0),
    FileID bigint,
    CreateLSN numeric(25,0),
    DropLSN numeric(25,0) NULL,
    UniqueID uniqueidentifier,
    ReadOnlyLSN numeric(25,0) NULL,
    ReadWriteLSN numeric(25,0) NULL,
    BackupSizeInBytes bigint,
    SourceBlockSize int,
    FileGroupID int,
    LogGroupGUID uniqueidentifier NULL,
    DifferentialBaseLSN numeric(25,0) NULL,
    DifferentialBaseGUID uniqueidentifier,
    IsReadOnly bit,
    IsPresent bit,
    TDEThumbprint varbinary(32),
    Seq int NOT NULL identity(1,1) Primary Key Clustered
    )

  --> Get header and filelist information from the backup file
If @Version = 11
Begin
  INSERT INTO @header2012
  EXEC ('RESTORE HeaderOnly FROM DISK = ''' + @Filename + '''')
END
Else
Begin
  INSERT INTO @header
  EXEC ('RESTORE HeaderOnly FROM DISK = ''' + @Filename + '''')
END

  INSERT INTO @filelist
  EXEC ('RESTORE FilelistOnly FROM DISK = ''' + @Filename + '''')


If @Version <> 11
	Begin
		Insert Into @header2012 (BackupName,BackupDescription, BackupType, ExpirationDate, Compressed, Position, DeviceType,
							UserName, ServerName, DatabaseName, DatabaseVersion, DatabaseCreationDate, BackupSize, FirstLSN,
							LastLSN, CheckpointLSN, DatabaseBackupLSN, BackupStartDate, BackupFinishDate, SortOrder, CodePage,
							UnicodeLocaleId,UnicodeComparisonStyle, CompatibilityLevel, SoftwareVendorId, SoftwareVersionMajor,
							SoftwareVersionMinor, SoftwareVersionBuild, MachineName, Flags, BindingID, RecoveryForkID,
							Collation, FamilyGUID, HasBulkLoggedData, IsSnapshot, IsReadOnly, IsSingleUser,HasBackupChecksums,
							IsDamaged, BeginsLogChain, HasIncompleteMetaData, IsForceOffline, IsCopyOnly, FirstRecoveryForkID,
							ForkPointLSN, RecoveryModel, DifferentialBaseLSN, DifferentialBaseGUID, BackupTypeDescription,
							BackupSetGUID, CompressedBackupSize)
			Select BackupName,BackupDescription, BackupType, ExpirationDate, Compressed, Position, DeviceType,
					UserName, ServerName, DatabaseName, DatabaseVersion, DatabaseCreationDate, BackupSize, FirstLSN,
					LastLSN, CheckpointLSN, DatabaseBackupLSN, BackupStartDate, BackupFinishDate, SortOrder, CodePage,
					UnicodeLocaleId,UnicodeComparisonStyle, CompatibilityLevel, SoftwareVendorId, SoftwareVersionMajor,
					SoftwareVersionMinor, SoftwareVersionBuild, MachineName, Flags, BindingID, RecoveryForkID,
					Collation, FamilyGUID, HasBulkLoggedData, IsSnapshot, IsReadOnly, IsSingleUser,HasBackupChecksums,
					IsDamaged, BeginsLogChain, HasIncompleteMetaData, IsForceOffline, IsCopyOnly, FirstRecoveryForkID,
					ForkPointLSN, RecoveryModel, DifferentialBaseLSN, DifferentialBaseGUID, BackupTypeDescription,
					BackupSetGUID, CompressedBackupSize
				From @header
	END

/* dump db file paths into table variable */
DECLARE @filepath TABLE  (
    LogicalName NVARCHAR(256),
    PhysicalName VARCHAR(2048),
    FileExtension varchar(4),
    FileID Bigint,
    Seq int NOT NULL Primary Key Clustered
)
   
INSERT INTO @filepath (LogicalName,PhysicalName,FileExtension,FileID,Seq) 
  SELECT a.LogicalName,
    case 
		when (isnull(mf.physical_name,'0') = '0' OR isnull(@RestoreDBAs,'0') <> '0') and a.Type = 'D' and a.FileID <= 2
			then @Default_Data_Path + @RestoreDBAs + RIGHT(a.PhysicalName,4)
		when (isnull(mf.physical_name,'0') = '0' OR isnull(@RestoreDBAs,'0') <> '0') and a.Type = 'L' and a.FileID <= 2
			then @Default_Log_Path  + @RestoreDBAs + '_log' + RIGHT(a.PhysicalName,4)
		when (isnull(mf.physical_name,'0') = '0' OR isnull(@RestoreDBAs,'0') <> '0') and a.Type = 'D' and a.FileID > 2
			then @Default_Data_Path + @RestoreDBAs + '_' + cast(a.FileID as varchar) + RIGHT(a.PhysicalName,4)
		when (isnull(mf.physical_name,'0') = '0' OR isnull(@RestoreDBAs,'0') <> '0') and a.Type = 'L' and a.FileID > 2
			then @Default_Log_Path  + @RestoreDBAs + '_log_' + cast(a.FileID as varchar) + RIGHT(a.PhysicalName,4)
			else mf.physical_name end 
     ,RIGHT(a.PhysicalName,4)
     ,a.FileID
	,a.Seq
  FROM
    @filelist a
	LEFT OUTER Join sys.master_files mf
		On a.LogicalName = mf.name 
    CROSS JOIN
      (SELECT Seq = MAX(b1.Seq) FROM @filelist b1 ) b
	Where database_id = DB_ID(@DBName)
	Order by a.Seq
	
  --> Generate the full backup restore script
  SELECT
    @SQL = @SQL +
      CASE
        WHEN a.Seq = 1 THEN
          @cr + 'RESTORE DATABASE [' + ISNULL(@RestoreDBAs,c.DatabaseName) + ']' + @cr
        ELSE ''
      END
  FROM
    @filelist a
    CROSS JOIN
      (SELECT DatabaseName = MAX(c1.DatabaseName) FROM @header2012 c1) c
  ORDER BY
    a.Seq

  SELECT
    @SQL = @SQL +
      CASE
        WHEN a.Seq = 1 and b1.family_sequence_number = 1 THEN
			'' + @tab + ' FROM DISK ='+ @tab + '''' +
			b1.physical_device_name + '''' + @cr
		When a.seq = 1 and b1.family_sequence_number > 1 Then
			'' + @tab + ',DISK ='+ @tab + '''' +
			b1.physical_device_name + '''' + @cr
        ELSE ''
      END
  FROM
    @filelist a
	CROSS JOIN
		(Select b.physical_device_name,family_sequence_number
			From [backup].[msdb].[dbo].backupset a
				INNER JOIN [backup].[msdb].[dbo].backupmediafamily b
					ON a.media_set_id = b.media_set_id
			Where a.database_name = @DBName
				And a.type = 'D'
				And a.backup_start_date = @Full_BackupStartDate
		) b1
  ORDER BY
    a.Seq,b1.family_sequence_number

 SELECT
    @SQL = @SQL + 'WITH'

  SELECT
    @SQL = @SQL + 
	@cr + @tab + 'MOVE ''' + a.LogicalName + ''' TO ''' + a.PhysicalName + ''','
      +
      CASE
        WHEN a.Seq = b.Seq THEN
          @cr + @tab + 'REPLACE, STATS = 5, RECOVERY;'
        ELSE ''
      END
  FROM @filepath a
    CROSS JOIN
      (SELECT Seq = MAX(b1.Seq) FROM @filelist b1 ) b
	Order by a.Seq

  --SELECT @SQL = @SQL + @cr + 'GO' + @cr + @cr

 -- PRINT @SQL;

  --EXEC master.dbo.sp_dropserver @server=N'BACKUP', @droplogins='droplogins';

  Execute (@SQL);

END TRY
BEGIN CATCH
  PRINT ERROR_MESSAGE()
END CATCH

Set @SQL = ''

Set @SQL = '
ALTER AUTHORIZATION
	ON DATABASE::' + @DBName + ' TO sa;'

Execute (@SQL);