USE [msdb]
GO

--Backup System databases
EXECUTE [dbo].[DatabaseBackup] 
	@Databases = 'SYSTEM_DATABASES', 
	@Directory = 'I:\Backups', 
	@BackupType = 'FULL',  
	@LogToTable = 'Y';

-- System backup log table
SELECT [ID]
      ,[StartTime]
      ,[DatabaseName]
      ,[Command]
      ,[CommandType]
      ,[EndTime]
  FROM [msdb].[dbo].[CommandLog]
  ORDER BY [StartTime] DESC;

---------------------------------------------------------------
--Scenario 1 (Backup Locations & Backup Encryption)
-- Backup Finance DB to UNC w/ Encryption & 10 files
-- Backup HR DB to UNC w/ Encryption & 2 files
-- Backup everything else to normal location

EXECUTE dbo.DatabaseBackup @Databases = 'Finance',
	@Directory = '\\FinanceData\FinanceDB',
	@BackupType = 'FULL',
	@Compress = 'Y',
	@Encrypt = 'Y',
	@EncryptionAlgorithm = 'AES_256',
	@ServerCertificate = 'SQLBACKUP_DBBackupCert',
	@BufferCount = 300,
	@NumberOfFiles = 10;

EXECUTE dbo.DatabaseBackup @Databases = 'HR',
	@Directory = '\\BackupServer\HR',
	@BackupType = 'FULL',
	@Compress = 'Y',
	@Encrypt = 'Y',
	@EncryptionAlgorithm = 'AES_256',
	@ServerCertificate = 'SQLBACKUP_DBBackupCert',
	@BufferCount = 100,
	@NumberOfFiles = 2;

EXECUTE dbo.DatabaseBackup @Databases = 'USER_DATABASES,-Finance,-HR',
	@Directory = 'I:\Backups',
	@BackupType = 'FULL',
	@Compress = 'Y';

-------------------------------------------------------------------
--Scenario 2 (Backup Schedules)
-- Log Backup Finance DB every 15min
-- Log Backup HR DB hourly
-- Diff Backup HR & Finance DB 3x daily
-- Diff Backup everything else at noon daily
-- Full Backup everything nightly

-- Job #1 (15min)
	EXECUTE dbo.DatabaseBackup @Databases = 'Finance',
		@Directory = '\\FinanceData\FinanceDB',
		@BackupType = 'LOG',
		@Compress = 'Y',
		@Encrypt = 'Y',
		@EncryptionAlgorithm = 'AES_256',
		@ServerCertificate = 'SQLBACKUP_DBBackupCert';

-- Job #2 (Hourly)
	EXECUTE dbo.DatabaseBackup @Databases = 'HR',
		@Directory = '\\BackupServer\HR',
		@BackupType = 'LOG',
		@Compress = 'Y',
		@Encrypt = 'Y',
		@EncryptionAlgorithm = 'AES_256',
		@ServerCertificate = 'SQLBACKUP_DBBackupCert';

-- Job #3 (7AM, 12PM, 5PM)
	EXECUTE dbo.DatabaseBackup @Databases = 'Finance,HR',
		@Directory = '\\FinanceData\FinanceDB',
		@BackupType = 'DIFF',
		@Compress = 'Y',
		@Encrypt = 'Y',
		@EncryptionAlgorithm = 'AES_256',
		@ServerCertificate = 'SQLBACKUP_DBBackupCert';

-- Job #4 (12PM)
	EXECUTE dbo.DatabaseBackup @Databases = 'USER_DATABASES,-Finance,-HR',
		@Directory = 'I:\Backups',
		@BackupType = 'DIFF',
		@Compress = 'Y';
		
-- Job #5 (10PM)
	EXECUTE dbo.DatabaseBackup @Databases = 'Finance',
		@Directory = '\\FinanceData\FinanceDB',
		@BackupType = 'FULL',
		@Compress = 'Y',
		@Encrypt = 'Y',
		@EncryptionAlgorithm = 'AES_256',
		@ServerCertificate = 'SQLBACKUP_DBBackupCert'
		@BufferCount = 300,
		@NumberOfFiles = 10;;
	EXECUTE dbo.DatabaseBackup @Databases = 'HR',
		@Directory = '\\BackupServer\HR',
		@BackupType = 'FULL',
		@Compress = 'Y',
		@Encrypt = 'Y',
		@EncryptionAlgorithm = 'AES_256',
		@ServerCertificate = 'SQLBACKUP_DBBackupCert'
		@BufferCount = 100,
		@NumberOfFiles = 2;
	EXECUTE dbo.DatabaseBackup @Databases = 'USER_DATABASES,-Finance,-HR',
		@Directory = 'I:\Backups',
		@BackupType = 'FULL',
		@Compress = 'Y';
		
		
		
		
		
		
		
		
		