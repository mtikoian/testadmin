USE [Mgmt]
GO

-- Backup Databases
EXEC Minion.BackupMaster 
	@DBType = 'User',		-- System or User
	@BackupType = 'Full',	-- Full, Diff or Log
	@Include = 'Finance',	-- DB Name, RegEx
	@Exclude = 'HR%',		-- DB Name, RegEx
	@ReadOnly = 1,			-- Include/Exclude/Only R/O DBs
	@StmtOnly = 1,			-- Generate backup statements
	@TestDateTime = '2017-06-01 22:00:00' -- Scenario/Date testing

-- Backup Locations & Retention
SELECT [DBName],[BackupType],[BackupDrive],
	[BackupPath],[Filename],[FileExtension],[RetHrs]
FROM [Mgmt].[Minion].[BackupSettingsPath]
ORDER BY [DBName];

-- Backup Schedule
SELECT [DBType],[BackupType],[Day],[ReadOnly],[BeginTime],[EndTime]
      ,[MaxForTimeframe],[FrequencyMins],[NumConcurrentBackups]
      ,[Include],[Exclude],[BatchPreCode],[BatchPostCode]
FROM [Mgmt].[Minion].[BackupSettingsServer];

-- Tuning Thresholds
SELECT [DBName],[BackupType],[ThresholdMeasure],[ThresholdValue]
      ,[NumberOfFiles],[Buffercount],[MaxTransferSize],[Compression]
      ,[BlockSize],[BeginTime],[EndTime],[DayOfWeek]
FROM [Mgmt].[Minion].[BackupTuningThresholds];

SELECT [DBName],[BackupType],[SizeInMB],[NumberOfFiles]
	,[Buffercount],[BackupTimeInSecs],[MBPerSec]
FROM [Mgmt].[Minion].[BackupLogDetails]
WHERE [BackupType] = 'Full'
	AND [ExecutionDateTime] BETWEEN '2017-03-06 11:20:00' AND '2017-03-06 11:31:00'
ORDER BY [ExecutionDateTime];	

-- Restore Database  (BackupRestoreSettingsPath & BackupRestoreTuningThresholds)
EXEC [Mgmt].[Minion].[BackupRestoreDB]
	@ServerName = '.',
	@DBName = 'Finance',
	@BackupType = 'Full',
	@BackupLoc = 'Backup',
	@RestoreDBName = 'Finance_Test',
	@StmtOnly = 1;

-- Last Backup Log Details
SELECT [ExecutionDateTime], [Status], [PctComplete], [DBName], 
	[IsInAG], [IsPrimaryReplica], [DBType], [BackupType], 
	[BackupTimeInSecs], [SizeInMB], [FileList], [IsEncryptedBackup]
FROM [Mgmt].[Minion].[BackupLogDetailsCurrent]
	
--Backup Job Execution Log (Last 5 User Backups Size & Duration)
SELECT [ExecutionDateTime],[DBType],[BackupType],
		[TotalBackupSizeInMB],[ExecutionRunTimeInSecs]
  FROM [Mgmt].[Minion].[BackupLog]
  WHERE [ExecutionDateTime] IN 
			(SELECT [ExecutionDateTime]
				FROM (SELECT [ExecutionDateTime],[BackupType], RANK() 
							OVER (PARTITION BY [BackupType]
								ORDER BY [ExecutionDateTime] DESC ) AS Rank
						FROM [Mgmt].[Minion].[BackupLog]
						WHERE [DBType] = 'User'
						) rs WHERE Rank <= 5)
		AND [BackupType] IS NOT NULL
ORDER BY [BackupType], [ExecutionDateTime] DESC;

-- Backup Log Details (DB Growth, etc)
SELECT TOP(10) [ExecutionDateTime],[DBName],[BackupType],
	[BackupTimeInSecs], [SizeInMB],*
	FROM [Mgmt].[Minion].[BackupLogDetails]
	WHERE [DBName] = 'Finance'
		AND [BackupType] = 'Full';
