/*
******************************************************************************************************
sp_dp_db_backup_history Dynamic Management Procedure and Template
Created by Tim Ford aka SQLAgentMan
http://thesqlagentman.com and http://sqlcruise.com

As always test in your environment before releasing into the wild in production.  This version
is configured to run from the master database but can easily be altered to run from a dedicated
administrative database used in your environment.  Enjoy!  Perhaps we'll meet on a future SQL Cruise!
******************************************************************************************************

SYNTAX: EXEC [dbo].[sp_dp_db_backup_history] @Backup_Type, @Latest_Flag = 1, @Database_Name = NULL 

EXAMPLES:
	EXEC sp_dp_db_backup_history 'D';	--most-recent full backup for all databases
	EXEC sp_dp_db_backup_history @Backup_Type = 'I', @Database_Name = '<database__name, , FOO>';	--most-recent differential backup for a specific database
	EXEC sp_dp_db_backup_history @Backup_Type = 'L', @Latest_Flag = 0;	--log backup history for a all databases
*/


EXEC dbo.sp_dp_db_backup_history @Backup_Type = '<backup__type, , D>', @Latest_Flag = <latest__flag, , 1>, @Database_Name = '<database__name, , FOO>';

EXEC dbo.sp_dp_db_backup_history @Backup_Type = '<backup__type, , D>', @Latest_Flag = <latest__flag, , 1>;
