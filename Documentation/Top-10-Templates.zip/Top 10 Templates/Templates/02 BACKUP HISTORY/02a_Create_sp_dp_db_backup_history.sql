CREATE PROCEDURE dbo.sp_dp_db_backup_history @Backup_Type CHAR(1), @Latest_Flag BIT = 1, @Database_Name sysname = NULL AS

/*
******************************************************************************************************
sp_dp_db_backup_history Dynamic Management Procedure and Template
Created by Tim Ford aka SQLAgentMan
http://thesqlagentman.com and http://sqlcruise.com

As always test in your environment before releasing into the wild in production.  This version
is configured to run from the master database but can easily be altered to run from a dedicated
administrative database used in your environment.  Enjoy!  Perhaps we'll meet on a future SQL Cruise!
******************************************************************************************************
*/

IF @Latest_Flag = 1

	BEGIN

		IF @Database_Name IS NULL
			BEGIN
    
				SELECT 
					BS.server_name, 
					BS.database_name, 
					FB.backup_finish_date,
					BMF.physical_device_name,
					'\\' + @@servername + '\' + LEFT(BMF.physical_device_name, 1) + '$' + RIGHT(BMF.physical_device_name, LEN(BMF.physical_device_name) - 2) AS UNC, 
					BMF.logical_device_name AS [backup_device_name]
				FROM 
		
					(
						SELECT 
							ROW_NUMBER() OVER(PARTITION BY database_name ORDER BY database_name ASC, backup_finish_date DESC) AS [Row Number],
							database_name, 
							backup_set_id,
							backup_finish_date
						FROM msdb.dbo.[backupset] 
						WHERE [type] = @Backup_Type
					) FB  
					 INNER JOIN msdb.dbo.[backupset] BS ON FB.backup_set_id = BS.backup_set_id
					 INNER JOIN msdb.dbo.backupmediafamily BMF ON BS.media_set_id = BMF.media_set_id
				WHERE FB.[Row Number] = 1
				ORDER BY FB.database_name;
			END
	
		ELSE

			BEGIN
    
				SELECT 
					BS.server_name, 
					BS.database_name, 
					FB.backup_finish_date,
					BMF.physical_device_name,
					'\\' + @@servername + '\' + LEFT(BMF.physical_device_name, 1) + '$' + RIGHT(BMF.physical_device_name, LEN(BMF.physical_device_name) - 2) AS UNC, 
					BMF.logical_device_name AS [backup_device_name]
				FROM 
		
					(
						SELECT 
							ROW_NUMBER() OVER(PARTITION BY database_name ORDER BY database_name ASC, backup_finish_date DESC) AS [Row Number],
							database_name, 
							backup_set_id,
							backup_finish_date
						FROM msdb.dbo.[backupset] 
						WHERE [type] = @Backup_Type
							AND database_name = @Database_Name
					) FB  
					 INNER JOIN msdb.dbo.[backupset] BS ON FB.backup_set_id = BS.backup_set_id
					 INNER JOIN msdb.dbo.backupmediafamily BMF ON BS.media_set_id = BMF.media_set_id
				WHERE FB.[Row Number] = 1
				ORDER BY FB.database_name;
			END

	END

ELSE

	BEGIN

		IF @Database_Name IS NULL
			BEGIN
    
				SELECT 
					BS.server_name, 
					BS.database_name, 
					FB.backup_finish_date,
					BMF.physical_device_name,
					'\\' + @@servername + '\' + LEFT(BMF.physical_device_name, 1) + '$' + RIGHT(BMF.physical_device_name, LEN(BMF.physical_device_name) - 2) AS UNC, 
					BMF.logical_device_name AS [backup_device_name]
				FROM 
		
					(
						SELECT 
							ROW_NUMBER() OVER(PARTITION BY database_name ORDER BY database_name ASC, backup_finish_date DESC) AS [Row Number],
							database_name, 
							backup_set_id,
							backup_finish_date
						FROM msdb.dbo.[backupset] 
						WHERE [type] = @Backup_Type
					) FB  
					 INNER JOIN msdb.dbo.[backupset] BS ON FB.backup_set_id = BS.backup_set_id
					 INNER JOIN msdb.dbo.backupmediafamily BMF ON BS.media_set_id = BMF.media_set_id
	--			WHERE FB.[Row Number] = 1
				ORDER BY FB.database_name, FB.[Row Number];
			END
	
		ELSE

			BEGIN
    
				SELECT 
					BS.server_name, 
					BS.database_name, 
					FB.backup_finish_date,
					BMF.physical_device_name,
					'\\' + @@servername + '\' + LEFT(BMF.physical_device_name, 1) + '$' + RIGHT(BMF.physical_device_name, LEN(BMF.physical_device_name) - 2) AS UNC, 
					BMF.logical_device_name AS [backup_device_name]
				FROM 
		
					(
						SELECT 
							ROW_NUMBER() OVER(PARTITION BY database_name ORDER BY database_name ASC, backup_finish_date DESC) AS [Row Number],
							database_name, 
							backup_set_id,
							backup_finish_date
						FROM msdb.dbo.[backupset] 
						WHERE [type] = @Backup_Type
							AND database_name = @Database_Name
					) FB  
					 INNER JOIN msdb.dbo.[backupset] BS ON FB.backup_set_id = BS.backup_set_id
					 INNER JOIN msdb.dbo.backupmediafamily BMF ON BS.media_set_id = BMF.media_set_id
	--			WHERE FB.[Row Number] = 1
				ORDER BY FB.database_name, FB.[Row Number];
			END
	END
GO
