SELECT * FROM msdb.dbo.backupfile;
SELECT * FROM msdb.dbo.backupfilegroup;
SELECT * FROM msdb.dbo.backupmediafamily;
SELECT * FROM msdb.dbo.backupmediaset;
SELECT * FROM msdb.dbo.backupset;
SELECT * FROM msdb.sys.backup_devices
