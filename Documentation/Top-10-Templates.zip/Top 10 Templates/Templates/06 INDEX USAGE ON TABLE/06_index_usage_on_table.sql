DECLARE @start_date DATETIME
DECLARE @days_up INT
DECLARE @object_id INT

SELECT @start_date = DB.create_date FROM master.sys.databases DB WHERE DB.name = 'tempdb'
SELECT @days_up = DATEDIFF(dd, @start_date, GETDATE())


SELECT 
	OBJECT_SCHEMA_NAME(T.object_id) AS [schema_name]
	, T.name AS table_name
	, I.name AS index_name
	, I.type_desc AS index_type
	, ixU.index_id
	, ixU.user_seeks 
	, ixU.user_scans
	, ixU.user_lookups
	, ixU.user_updates
	, CASE @days_up
		WHEN 0 THEN (ixU.user_scans + ixU.user_seeks + ixU.user_lookups)
		ELSE (ixU.user_scans + ixU.user_seeks + ixU.user_lookups) / @days_up
	END AS avg_daily_user_reads
	, CASE @days_up
		WHEN 0 THEN user_updates
		ELSE ixU.user_updates / @days_up
	END AS avg_daily_user_writes
	, CASE ixU.user_updates
		WHEN 0 THEN 100
		ELSE (ixU.user_scans + ixU.user_seeks + ixU.user_lookups) / ixU.user_updates * 100.0
	END AS percent_user_reads_to_user_writes
	, @days_up AS metadata_days
FROM sys.tables T
	INNER JOIN sys.indexes I ON T.object_id = I.object_id
	INNER JOIN sys.dm_db_index_usage_stats ixU ON I.object_id = ixU.object_id AND I.index_id = ixU.index_id
WHERE T.[name] = '<table__name, , FOO>'
ORDER BY 12 ASC;
