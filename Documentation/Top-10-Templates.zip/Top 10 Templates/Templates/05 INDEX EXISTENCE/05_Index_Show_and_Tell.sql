--What indexes are on this table?

SELECT object_name(I.[object_id]) AS [object_name], I.[name] AS index_name, IC.[index_column_id],
	 [AC].[name] AS column_name, IC.[is_descending_key], IC.[is_included_column],
	 I.[type_desc] AS index_type, I.[is_primary_key], I.[is_unique], I.[is_unique_constraint]
FROM sys.[indexes] I 
	INNER JOIN sys.[index_columns] IC
		ON I.[index_id] = [IC].[index_id]
			AND I.[object_id] = IC.[object_id]
	INNER JOIN sys.[all_columns] AC
		ON [IC].[object_id] = [AC].[object_id]
			AND IC.[column_id] = [AC].[column_id]
WHERE I.object_id = object_id('<table__name,, FOO>')
ORDER BY I.[is_primary_key] desc, I.name, [IC].[is_included_column], [IC].[index_column_id];