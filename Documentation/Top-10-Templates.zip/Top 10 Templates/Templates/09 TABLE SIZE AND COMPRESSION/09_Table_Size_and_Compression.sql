CREATE TABLE #table_metadata (
	[row_ranking] SMALLINT NOT NULL,
	[TableName]  VARCHAR (100) NOT NULL,
	[RowCount] BIGINT NOT NULL,
	[Reserved] BIGINT NOT NULL,
	[Data] BIGINT NOT NULL,
	[IndexSize] BIGINT NOT NULL,
	[Unused] BIGINT NOT NULL,
	[PageCompressionCommand] VARCHAR(1000),
	[is_ms_shipped] BIT
--		, [data_compression_desc] sysname
	);
		
INSERT INTO #table_metadata (row_ranking, [TableName],[RowCount],[Reserved],[Data], [IndexSize],[Unused], [PageCompressionCommand], [is_ms_shipped])
SELECT 	(row_number() over(order by (A.reserved + ISNULL(B.reserved,0)) desc))%2 as l1,
			Obj.name AS [Tablename],
			A.rows as [RowCount],
			(A.reserved + ISNULL(B.reserved,0))* 8 AS [Reserved(KB)],
			A.data * 8 AS [Data(KB)],
			(CASE 
				WHEN (A.used + ISNULL(B.used,0)) > A.data 
					THEN (A.used + ISNULL(B.used,0)) - A.data 
					ELSE 0 END) * 8 AS [IndexSize(KB)],
			(CASE 
				WHEN (A.reserved + ISNULL(B.reserved,0)) > A.used 
					THEN (A.reserved + ISNULL(B.reserved,0)) - A.used 
					ELSE 0 END) * 8 AS [Unused(KB)],
			'ALTER TABLE [' + Obj.[name] + '] REBUILD WITH (ONLINE=ON, DATA_COMPRESSION=PAGE, MAXDOP = <max_dop, tinyint,2>);' AS command_text,
			obj.[is_ms_shipped]
--				, P.[data_compression_desc]
FROM (
	SELECT PartStat.object_id,
			SUM (CASE
					WHEN (PartStat.index_id < 2) THEN row_count
					ELSE 0
					END) AS [rows],
			SUM (PartStat.reserved_page_count) AS reserved,
			SUM (CASE
				WHEN (PartStat.index_id < 2) 
					THEN (PartStat.in_row_data_page_count + PartStat.lob_used_page_count + PartStat.row_overflow_used_page_count)
				ELSE (PartStat.lob_used_page_count + PartStat.row_overflow_used_page_count)
				END) AS data,
			SUM (PartStat.used_page_count) AS used
	FROM sys.dm_db_partition_stats PartStat
				GROUP BY PartStat.object_id) AS A
	LEFT OUTER JOIN
		(SELECT Tab.parent_id,
			SUM(PartStat.reserved_page_count) AS reserved,
			SUM(PartStat.used_page_count) AS used
		FROM sys.dm_db_partition_stats PartStat
			INNER JOIN sys.internal_tables Tab ON (Tab.object_id = PartStat.object_id)
		WHERE Tab.internal_type IN (202,204)
			GROUP BY Tab.parent_id) AS B ON (B.parent_id = A.object_id)
		INNER JOIN sys.all_objects Obj  ON ( A.object_id = Obj.object_id )
			WHERE Obj.type <> N'S' 
				AND Obj.type <> N'IT' 
				AND Obj.Name NOT LIKE 'tmp%'
				AND A.rows > 0
			ORDER BY Obj.name;

SELECT [TableName],[RowCount],[Reserved] AS [Reserved(KB)],[Data] AS [Data(KB)],[IndexSize] AS [IndexSize(KB)],[Unused] AS [Unused(KB)], [PageCompressionCommand], [is_ms_shipped] 
	FROM #table_metadata
	WHERE [is_ms_shipped] = 0
		ORDER BY [Reserved] DESC; 

DROP TABLE #table_metadata;
