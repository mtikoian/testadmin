USE master;
GO

CREATE PROCEDURE dbo.sp_dp_db_log_bloat AS 

/*
******************************************************************************************************
sp_dp_db_log_bloat Dynamic Management Procedure and Template
Created by Tim Ford aka SQLAgentMan
http://thesqlagentman.com and http://sqlcruise.com

As always test in your environment before releasing into the wild in production.  This version
is configured to run from the master database but can easily be altered to run from a dedicated
administrative database used in your environment.  Enjoy!  Perhaps we'll meet on a future SQL Cruise!

PURPOSE:  Will compare transaction log backup history file sizes with the file size of your transaction
	log to determine if perhaps you transaction log is sized larger than it needs to be.
******************************************************************************************************
*/

--+-----------------------------------------------
--Create necessary temp table for results
--+-----------------------------------------------
IF EXISTS 
	( 
		SELECT name
        FROM tempdb.sys.[tables]
        WHERE name LIKE '#trx_log_size%' 
	) 

DROP TABLE #trx_log_size;

CREATE TABLE #trx_log_size
   (
    database_name NVARCHAR(128) NOT NULL
  , [name] NVARCHAR(128) NOT NULL
  , physical_name NVARCHAR(260) NOT NULL
  , size_mb INT NOT NULL
   )
 
--+-----------------------------------------------
--Populate temp table with current log file sizes 
--+-----------------------------------------------
EXEC [dbo].[sp_foreachdb] 
 @command = 'INSERT INTO [#trx_log_size] ([database_name], [name], 
                    [physical_name], [size_mb]) 
                    SELECT N''?'', name, physical_name, size*8/1024 
                    FROM [?].sys.database_files WHERE type = 1;',
  @suppress_quotename = 1;

SELECT
	L.[database_name], 
	L.[physical_name], 
	L.[size_mb], 
	MAX(CEILING(BF.[backup_size]/1024/1024)) AS max_backup_file_size_mb,
	L.[size_mb] - MAX(CEILING(BF.[backup_size]/1024/1024)) AS file_excess_mb
FROM msdb.dbo.[backupfile] BF 
	INNER JOIN msdb.dbo.[backupset] BS ON [BF].[backup_set_id] = [BS].[backup_set_id]
	INNER JOIN [#trx_log_size] L ON [BS].[database_name] = L.[database_name]
	INNER JOIN master.sys.[databases] SD ON L.[database_name] = SD.[name]
WHERE BS.[type] = 'L'
	AND SD.[recovery_model_desc] = 'FULL'
GROUP BY SD.[name]
	, L.[database_name]
	, L.[physical_name]
	, L.[size_mb]
HAVING  L.[size_mb] > MAX(CEILING(BF.[backup_size]/1024/1024))
ORDER BY L.[size_mb] - MAX(CEILING(BF.[backup_size]/1024/1024)) DESC;

--+-----------------------------------------------
--Clean up your messes when you're done!
--+-----------------------------------------------
IF EXISTS 
	( 
		SELECT   name
        FROM     tempdb.sys.[tables]
        WHERE    name LIKE '#trx_log_size%' 
	) 
DROP TABLE #trx_log_size;
