/*
*****************************************************************************************************
sp_dp_db_log_bloat Dynamic Management Procedure and Template
Created by Tim Ford aka SQLAgentMan
http://thesqlagentman.com and http://sqlcruise.com

As always test in your environment before releasing into the wild in production.  This version
is configured to run from the master database but can easily be altered to run from a dedicated
administrative database used in your environment.  Enjoy!  Perhaps we'll meet on a future SQL Cruise!
******************************************************************************************************

SYNTAX: EXEC [dbo].[sp_dp_db_log_bloat]; 

EXAMPLES:
	EXEC sp_dp_db_log_bloat;
*/



EXEC sp_dp_db_log_bloat;