USE Aegis;

SELECT * FROM sys.database_files;

SELECT * FROM sys.master_files WHERE db_name(database_id) = 'Aegis';

EXEC sp_dp_db_sizing 1, 'Aegis';

EXEC sp_dp_db_sizing 0, 'Aegis';
