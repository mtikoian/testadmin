/*
******************************************************************************************************
sp_dp_db_sizing Dynamic Management Procedure and Template
Created by Tim Ford aka SQLAgentMan
http://thesqlagentman.com and http://sqlcruise.com

As always test in your environment before releasing into the wild in production.  This version
is configured to run from the master database but can easily be altered to run from a dedicated
administrative database used in your environment.  Enjoy!  Perhaps we'll meet on a future SQL Cruise!
******************************************************************************************************

SYNTAX: EXEC [dbo].[sp_dp_db_sizing] @file_detail_level BIT = 0, @Database_Name sysname = NULL 

OUTCOMES:
	EXEC sp_dp_db_sizing 0, NULL;	--Database-level granularity for all databases

	EXEC sp_dp_db_sizing 1, '<database__name, , FOO>';	--File-level granularity for all databases

	EXEC sp_dp_db_sizing 0, NULL;	--Database-level granularity for a specific database

	EXEC sp_dp_db_sizing 1, '<database__name, , FOO>';	--File-level granularity for a specific database

EXAMPLES:
	EXEC sp_dp_db_sizing 0, NULL;

	EXEC sp_dp_db_sizing 1, 'Aegis';

	EXEC sp_dp_db_sizing 0, NULL;

	EXEC sp_dp_db_sizing 1, 'Aegis';

*/


EXEC sp_dp_db_sizing <file_detail_level_BIT, ,1>, NULL;

EXEC sp_dp_db_sizing <file_detail_level_BIT, ,1>, '<database__name, , FOO>';