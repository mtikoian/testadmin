/*
*****************************************************************************************************
Column Lookup Template
Created by Tim Ford aka SQLAgentMan
http://thesqlagentman.com and http://sqlcruise.com

As always test in your environment before releasing into the wild in production.  This version
is configured to run from the master database but can easily be altered to run from a dedicated
administrative database used in your environment.  Enjoy!  Perhaps we'll meet on a future SQL Cruise!
******************************************************************************************************

DIRECTIONS:  
	Replace template parameter by using on of the following methods:
		1. Control + Shift + M 
		2. Query\Specify Values for Template Parameters from SSMS Menu
	Hit F5 and enjoy!
*/

SELECT OBJECT_SCHEMA_NAME(TB.object_id) AS schema__name
	, TB.name AS object__name
	, AC.name AS column__name
	, TB.is_ms_shipped AS is_system_object
	, type_desc AS object_type 
	, TY.name AS data__type
	, TY.is_nullable
	, TY.max_length
	, TY.precision
	, TY.scale
	, TY.collation_name
FROM sys.all_columns AC 
	LEFT JOIN sys.tables TB ON AC.object_id = TB.object_id
	INNER JOIN sys.types TY ON AC.system_type_id = TY.system_type_id
WHERE name = '<column_name,,foo>'
ORDER BY 1,2