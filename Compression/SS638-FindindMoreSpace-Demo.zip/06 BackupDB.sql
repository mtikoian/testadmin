use testme
------------
declare @fn varchar(200), @type smallint=1, @compress bit=0, @txt char(3);
if @compress=0 set @txt='' else set @txt='cp_';
declare @path varchar(200)='C:\Users\Chiu\Documents\Thom\SQL Sat\SQL Sat 638 Philadelphia\backup\testme_';
declare @dt varchar(20)=+RTRIM(CONVERT(CHAR,YEAR(GETDATE())))+RIGHT('0'+RTRIM(CONVERT(CHAR,MONTH(GETDATE()))),2)
+RIGHT('0'+RTRIM(CONVERT(CHAR,DAY(GETDATE()))),2)+'_'++RIGHT('0'+RTRIM(CONVERT(CHAR,DATEPART(hh,GETDATE()))),2)+
+RIGHT('0'+RTRIM(CONVERT(CHAR,DATEPART(mi,GETDATE()))),2)++RIGHT('0'+RTRIM(CONVERT(CHAR,DATEPART(ss,GETDATE()))),2)

if @type=1 set @fn=@path+'full_'+@txt+@dt+'.bak'
if @type=3 set @fn=@path+'tlog_'+@txt+@dt+'.trn'

if @compress=0
	begin
	if @type=1 backup database testme to disk=@fn with init, stats=10;
	if @type=3 backup log testme to disk=@fn with init, stats=25;
	end
	else begin
	if @type=1 backup database testme to disk=@fn with init, stats=10, DESCRIPTION='Is compressed', compression;
	if @type=3 backup log testme to disk=@fn with init, stats=25, DESCRIPTION='Is compressed', compression;
	end
--	select count(*) from dbo.Orders
------------
restore database testme from
disk='C:\Users\Chiu\Documents\Thom\SQL Sat\SQL Sat 638 Philadelphia\backup\testme_full_cp_20170602_225501.bak'
with stats=20;
