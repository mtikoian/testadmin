USE TestMe
GO
DECLARE @dbid int;
SELECT @dbid=DB_ID();
PRINT @dbid

SELECT DB_NAME(database_id) dbname, idx.[name] index_name, ips.index_id, obj.[name] table_name, ips.index_type_desc, 
ips.alloc_unit_type_desc, ips.index_depth, /*ips.index_level, */CONVERT(NUMERIC(10,6), ips.avg_fragmentation_in_percent) AvgFragPct, 
ips.page_count, ips.page_count/128.0 Size_MB, idx.fill_factor,
'ALTER INDEX ['+idx.name+ '] ON ['+sch.name+'].['+obj.name+'] REBUILD WITH (FILLFACTOR=96, ONLINE=ON, MAXDOP=2);' comm_Rebuild,
'ALTER INDEX ['+idx.name+ '] ON ['+sch.name+'].['+obj.name+'] REORGANIZE;' comm_Reorg
FROM sys.dm_db_index_physical_stats (@dbid, NULL, NULL, NULL, 'LIMITED') as ips
INNER JOIN sys.objects obj ON obj.[object_id] = ips.object_id
INNER JOIN sys.indexes idx ON idx.object_id = ips.object_id AND idx.index_id = ips.index_id
INNER JOIN sys.schemas sch ON sch.schema_id = obj.schema_id
WHERE index_type_desc != 'HEAP' AND ips.avg_fragmentation_in_percent >= 5 AND page_count > 5
--	AND idx.name = 'PK__ReportedOwner__0BC6C43E'
ORDER BY ips.page_count ASC
--	ORDER BY index_name
--	ORDER BY avg_fragmentation_in_percent DESC
--	ORDER BY table_name, index_name

--	EXEC sys.sp_updatestats
--	sp_who2
