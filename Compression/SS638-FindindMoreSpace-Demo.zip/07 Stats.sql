use testme

----	Histogram show 200 values
dbcc show_statistics ('Orders', 'PK_Orders');

dbcc show_statistics ('Orders', 'IX01_Orders');
dbcc show_statistics ('Orders', 'IX02_Orders');
