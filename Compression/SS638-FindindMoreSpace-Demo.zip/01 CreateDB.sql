use master
IF DB_ID('TestMe') IS NOT NULL
	BEGIN
	PRINT 'Dropping database.';
	ALTER DATABASE [TestMe] SET  SINGLE_USER WITH ROLLBACK IMMEDIATE;
	DROP DATABASE [TestMe];
	END

CREATE DATABASE [TestMe] ON PRIMARY (NAME=N'TestMe',SIZE=10MB, MAXSIZE=UNLIMITED, FILEGROWTH=10MB,
FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL11.MSSQLSERVER\MSSQL\DATA\TestMe.mdf' 
) LOG ON ( NAME = N'TestMe_log',SIZE=10MB,MAXSIZE=2048GB, FILEGROWTH=10MB,
FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL11.MSSQLSERVER\MSSQL\DATA\TestMe_log.ldf')
GO

ALTER DATABASE TestMe SET RECOVERY FULL;
--------------------------------
USE [TestMe];

--Got from Kendra Little in Brent Ozar presentation
--Create a tally table with ~4 million rows, we'll use this to populate test tables
--This general method attributed to Itzik Ben-Gan
;WITH    Pass0 AS ( SELECT   1 AS C UNION ALL SELECT   1), 
	Pass1 AS ( SELECT   1 AS C FROM     Pass0 AS A , Pass0 AS B),
	Pass2 AS ( SELECT   1 AS C FROM     Pass1 AS A , Pass1 AS B),
	Pass3 AS ( SELECT   1 AS C FROM     Pass2 AS A , Pass2 AS B),
	Pass4 AS ( SELECT   1 AS C FROM     Pass3 AS A , Pass3 AS B),
	Pass5 AS ( SELECT   1 AS C FROM     Pass4 AS A , Pass4 AS B),
	tally AS ( SELECT   row_number() OVER ( Order BY C ) AS N FROM Pass5 )
SELECT N INTO dbo.tally FROM tally WHERE N <= 500000;
GO
--------------------------------	TRUNCATE TABLE Orders
CREATE TABLE Orders (
	OrderId int IDENTITY(1,1) NOT NULL,
	OrderName nvarchar(256) NOT NULL,
	OrderDate datetime NOT NULL,
	ShipDate datetime NULL
) ON [PRIMARY];

INSERT Orders(OrderDate, OrderName) 
SELECT DATEADD(ss, t.N, DATEADD(dd,-3,CAST(CAST(SYSDATETIME() AS DATE) AS DATETIME2(0)))) AS OrderDate,
	CASE WHEN t.N % 3 = 0 THEN 'robot' WHEN t.N % 4 = 0 THEN 'badger' WHEN t.N % 5 = 0 THEN 'roger'
	ELSE 'Pen'+ RTRIM(CONVERT(char, Datepart(ms, getdate())))+'_'+CONVERT(char, floor(t.N*1.1)) END AS OrderName
FROM dbo.tally AS t
WHERE N < = 20000;
--
INSERT Orders(OrderDate, OrderName) 
SELECT DATEADD(ss, t.N, DATEADD(dd,-3,CAST(CAST(SYSDATETIME() AS DATE) AS DATETIME2(0)))) AS OrderDate,
	CASE WHEN t.N % 5 = 0 THEN 'bot' WHEN t.N % 4 = 0 THEN 'danger'  ELSE 'penny' END AS OrderName
FROM dbo.tally AS t
WHERE N < = 30000;
--
INSERT Orders(OrderDate, OrderName) 
SELECT DATEADD(ss, t.N, DATEADD(dd,-3,CAST(CAST(SYSDATETIME() AS DATE) AS DATETIME2(0)))) AS OrderDate,
	CASE WHEN t.N % 12=0 THEN 'flybot' WHEN t.N % 7=0 THEN 'german '--+CONVERT(char, t.N) 
	WHEN t.N % 5=0 THEN 'pencilbot' WHEN t.N % 4=0 THEN 'gerfly manbot' 
	WHEN t.N % 3=0 THEN 'bad daniel'ELSE 'Penn State' END AS OrderName
FROM dbo.tally AS t
WHERE N < = 50000;

INSERT Orders(OrderDate, OrderName) 
SELECT DATEADD(ss, t.N, DATEADD(dd,-3,CAST(CAST(SYSDATETIME() AS DATE) AS DATETIME2(0)))) AS OrderDate,
	CASE WHEN (t.N % 22=0 or t.N % 21=0) THEN 'botterman' WHEN t.N % 15=0 THEN 'fly man'  
	WHEN (t.N % 12=0) THEN 'car '+CONVERT(char, t.N%2) WHEN t.N % 9=0 THEN 'cilla kung' 
	WHEN t.N % 7=0 THEN 'manmade'+CONVERT(char, t.N) WHEN t.N % 5=0 THEN 'Pencil box'
	WHEN t.N % 4=0 THEN 'Wefly bottle' WHEN t.N % 3=0 THEN 'carmax'ELSE 'state bad dan' END AS OrderName
FROM dbo.tally AS t
WHERE N < = 400000;

select * from dbo.Orders
----
alter table dbo.Orders add constraint PK_Orders primary key clustered (OrderId);
create index IX01_Orders on dbo.Orders (OrderName);
create index IX02_Orders on dbo.Orders (OrderDate);
