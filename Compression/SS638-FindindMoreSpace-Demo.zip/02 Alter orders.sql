select * from dbo.orders where [OrderName] like 'ba%'
select * from dbo.orders where [OrderName] like 'pe%'
select * from dbo.orders where OrderId > 499000

select * from dbo.orders where OrderId <= 110

update dbo.orders set orderdate=OrderDate+1  where OrderId <= 10

select max(orderdate) from orders

select * from dbo.orders  where OrderDate >= '20170603 15:00'

update dbo.orders set orderdate=OrderDate+2 where OrderDate >= '20170603 15:00'
update dbo.orders set orderdate=OrderDate+5 where OrderDate >= '20170603 15:00'
update dbo.orders set orderdate=OrderDate+5 where OrderDate >= '20170603 15:00'

update dbo.orders set orderdate=OrderDate-10 where OrderDate >= '20170603 15:00'
--
select * from dbo.tally where N < 100
0.009399116483050

