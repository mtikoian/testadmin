use TestMe
----	Compression
ALTER TABLE [dbo].[tally] REBUILD WITH (DATA_COMPRESSION=PAGE, ONLINE=ON, MAXDOP=1);
ALTER INDEX [IX02_Orders] ON [dbo].[Orders] REBUILD WITH (DATA_COMPRESSION=PAGE, ONLINE=ON, MAXDOP=1, FILLFACTOR=98);
ALTER INDEX [IX01_Orders] ON [dbo].[Orders] REBUILD WITH (DATA_COMPRESSION=PAGE, ONLINE=ON, MAXDOP=1, FILLFACTOR=98);
ALTER INDEX [PK_Orders] ON [dbo].[Orders] REBUILD WITH (DATA_COMPRESSION=ROW, ONLINE=ON, MAXDOP=1, FILLFACTOR=98);

----	Shrink Datafile
SELECT name, size/128., * FROM sys.database_files

DBCC shrinkfile ('TestMe', 40);
----	Fragmentation
ALTER INDEX [IX02_Orders] ON [dbo].[Orders] REBUILD WITH (FILLFACTOR=96, ONLINE=ON, MAXDOP=2);
ALTER INDEX [PK_Orders] ON [dbo].[Orders] REBUILD WITH (FILLFACTOR=96, ONLINE=ON, MAXDOP=2);
----	Update Statistcs
EXEC sys. sp_updatestats;
