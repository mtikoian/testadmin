USE TestMe

DECLARE @min_estim_size_mb SMALLINT =1, @estim CHAR(3) ='011'	-- Estimate position None,Row,Page
DECLARE @object_name VARCHAR(100), @schema_name VARCHAR(50), @index_id INT, @partition_number INT, @sqltext VARCHAR(MAX);

IF @estim!='000'
	BEGIN
	IF CONVERT(SMALLINT, SUBSTRING(@estim,1,1))=1
		DECLARE @saveN TABLE ([object_name] VARCHAR(100),[schema_name] VARCHAR(50),[index_id] INT
		,[partition_number] INT,[size_with_current_compression_setting(KB)] NUMERIC(18,0)
		,[size_with_requested_compression_setting(KB)] NUMERIC(18,0)
		,[sample_size_with_current_compression_setting(KB)] NUMERIC(18,0)
		,[sample_size_with_requested_compression_setting(KB)] NUMERIC(18,0));
	IF CONVERT(SMALLINT, SUBSTRING(@estim,2,1))=1
		DECLARE @saveR TABLE ([object_name] VARCHAR(100),[schema_name] VARCHAR(50),[index_id] INT
		,[partition_number] INT,[size_with_current_compression_setting(KB)] NUMERIC(18,0)
		,[size_with_requested_compression_setting(KB)] NUMERIC(18,0)
		,[sample_size_with_current_compression_setting(KB)] NUMERIC(18,0)
		,[sample_size_with_requested_compression_setting(KB)] NUMERIC(18,0));
	IF CONVERT(SMALLINT, SUBSTRING(@estim,3,1))=1
		DECLARE @saveP TABLE ([object_name] VARCHAR(100),[schema_name] VARCHAR(50),[index_id] INT
		,[partition_number] INT,[size_with_current_compression_setting(KB)] NUMERIC(18,0)
		,[size_with_requested_compression_setting(KB)] NUMERIC(18,0)
		,[sample_size_with_current_compression_setting(KB)] NUMERIC(18,0)
		,[sample_size_with_requested_compression_setting(KB)] NUMERIC(18,0));

	DECLARE Cur1 CURSOR FOR
		SELECT SCHEMA_NAME(o.schema_id) sname, o.name, i.index_id, p.partition_number--, i.type_desc
		FROM sys.objects o JOIN sys.indexes i ON i.object_id = o.object_id
		JOIN sys.partitions p ON p.object_id = o.object_id AND p.index_id = i.index_id
		JOIN sys.dm_db_partition_stats ps ON ps.partition_id = p.partition_id
		WHERE o.type = 'U' AND ps.used_page_count >= 128*@min_estim_size_mb
--		AND SCHEMA_NAME(o.schema_id)='z'
	OPEN Cur1
	FETCH Cur1 INTO @schema_name, @object_name, @index_id, @partition_number
	WHILE @@FETCH_STATUS >= 0
		BEGIN
		SET @sqltext='EXEC sys.sp_estimate_data_compression_savings '''+ @schema_name+ ''', '''+ @object_name+ ''', ' 
			+ RTRIM(CONVERT(CHAR, @index_id))+', '+	RTRIM(CONVERT(CHAR, @partition_number));
		IF CONVERT(SMALLINT, SUBSTRING(@estim,1,1))=1 INSERT INTO @saveN EXEC (@sqltext+', ''NONE''');
		IF CONVERT(SMALLINT, SUBSTRING(@estim,2,1))=1 INSERT INTO @saveR EXEC (@sqltext+', ''ROW''');
		IF CONVERT(SMALLINT, SUBSTRING(@estim,3,1))=1 INSERT INTO @saveP EXEC (@sqltext+', ''PAGE''');
		FETCH Cur1 INTO @schema_name, @object_name, @index_id, @partition_number;
		END;
	CLOSE Cur1;
	DEALLOCATE Cur1;
	END;
--------------------------------------------------------------------------------
WITH partit_cte AS (
SELECT o.object_id, i.index_id, p.partition_number, '['+s.name+'].['+o.name+']' oname, i.name iname, 
i.fill_factor, i.type_desc, p.data_compression_desc, ps.used_page_count/128. size_MB, 

ios.range_scan_count+ ios.leaf_insert_count+ ios.leaf_delete_count+ ios.leaf_update_count+ ios.leaf_page_merge_count+ 
ios.singleton_lookup_count total_count, ios.leaf_update_count, ios.range_scan_count,

COALESCE(sn.[size_with_current_compression_setting(KB)],sr.[size_with_current_compression_setting(KB)],
sp.[size_with_current_compression_setting(KB)])/1024. curr_size_mb, sn.[size_with_requested_compression_setting(KB)]/1024. none_size_mb,
sr.[size_with_requested_compression_setting(KB)]/1024. row_size_mb, sp.[size_with_requested_compression_setting(KB)]/1024. page_size_mb, 

CASE WHEN (ios.range_scan_count+ ios.leaf_insert_count+ ios.leaf_delete_count+ ios.leaf_update_count+ ios.leaf_page_merge_count+ ios.singleton_lookup_count)= 0 
THEN -1 ELSE ios.leaf_update_count * 100.0 / (ios.range_scan_count+ ios.leaf_insert_count+ ios.leaf_delete_count+ ios.leaf_update_count+ ios.leaf_page_merge_count+ ios.singleton_lookup_count) END [UpdPct],
CASE WHEN (ios.range_scan_count+ ios.leaf_insert_count+ ios.leaf_delete_count+ ios.leaf_update_count+ ios.leaf_page_merge_count+ ios.singleton_lookup_count)= 0 
THEN -1 ELSE ios.range_scan_count * 100.0 / (ios.range_scan_count+ ios.leaf_insert_count+ ios.leaf_delete_count+ ios.leaf_update_count+ ios.leaf_page_merge_count+ ios.singleton_lookup_count) END  [ScanPct],


CASE i.index_id WHEN 0 THEN 'ALTER TABLE ['+SCHEMA_NAME(o.schema_id)+'].['+o.name+'] REBUILD WITH (DATA_COMPRESSION=PAGE, ONLINE=ON, MAXDOP=1);'
ELSE 'ALTER INDEX ['+i.name+'] ON ['+SCHEMA_NAME(o.schema_id)+'].['+o.name+'] REBUILD WITH (DATA_COMPRESSION=PAGE, ONLINE=ON, MAXDOP=1, FILLFACTOR=98);' END cmd

FROM sys.objects o JOIN sys.schemas s ON s.schema_id = o.schema_id
JOIN sys.indexes i ON i.object_id = o.object_id 
JOIN sys.partitions p ON p.object_id = o.object_id AND p.index_id = i.index_id
JOIN sys.dm_db_partition_stats ps ON ps.partition_id = p.partition_id

LEFT JOIN sys.dm_db_index_operational_stats (db_id(), NULL, NULL, NULL) ios 
	ON (ios.object_id = o.object_id AND ios.index_id = i.index_id AND ios.partition_number = p.partition_number)
LEFT JOIN @saveN sn ON (sn.schema_name=s.name AND sn.object_name=o.name AND sn.index_id=i.index_id AND sn.partition_number=p.partition_number)
LEFT JOIN @saveR sr ON (sr.schema_name=s.name AND sr.object_name=o.name AND sr.index_id=i.index_id AND sr.partition_number=p.partition_number)
LEFT JOIN @saveP sp ON (sp.schema_name=s.name AND sp.object_name=o.name AND sp.index_id=i.index_id AND sp.partition_number=p.partition_number)

WHERE o.type='U' --AND ps.used_page_count >= 1
--AND o.name = 'EventSQL'
--AND p.data_compression_desc!='PAGE'
--AND o.schema_id=SCHEMA_ID('z')

) 
SELECT object_id, index_id,partition_number,oname,iname,fill_factor,type_desc,
data_compression_desc data_compr, size_MB
curr_size_mb,none_size_mb,row_size_mb,page_size_mb,
CASE WHEN curr_size_mb=0 THEN -1 ELSE 100.*(curr_size_mb-row_size_mb)/curr_size_mb END [RowSavePct],
CASE WHEN curr_size_mb=0 THEN -1 ELSE 100.*(curr_size_mb-page_size_mb)/curr_size_mb END [PageSavePct],
--	CASE WHEN total_count= 0 THEN -1 ELSE 100.*leaf_update_count/total_count END [UpdPct],
--	CASE WHEN total_count= 0 THEN -1 ELSE 100.*range_scan_count/total_count END [ScanPct],
[UpdPct], [ScanPct],'' decision, cmd
FROM partit_cte
ORDER BY data_compression_desc, size_MB

--	SELECT OBJECT_ID('dbo.EventSQL')
--	SELECT * FROM sys.dm_db_index_operational_stats(DB_ID(), 261575970, NULL,NULL)
