USE TestMe
SELECT o.object_id, i.index_id, p.partition_number, '['+s.name+'].['+o.name+']' oname, i.name iname, 
i.fill_factor, i.type_desc, p.data_compression_desc, ps.used_page_count/128. size_MB, 

ios.range_scan_count+ ios.leaf_insert_count+ ios.leaf_delete_count+ ios.leaf_update_count+ ios.leaf_page_merge_count+ 
ios.singleton_lookup_count total_count, ios.leaf_update_count, ios.range_scan_count,

CASE WHEN (ios.range_scan_count+ ios.leaf_insert_count+ ios.leaf_delete_count+ ios.leaf_update_count+ ios.leaf_page_merge_count+ ios.singleton_lookup_count)= 0 
THEN -1 ELSE ios.leaf_update_count * 100.0 / (ios.range_scan_count+ ios.leaf_insert_count+ ios.leaf_delete_count+ ios.leaf_update_count+ ios.leaf_page_merge_count+ ios.singleton_lookup_count) END [UpdPct],
CASE WHEN (ios.range_scan_count+ ios.leaf_insert_count+ ios.leaf_delete_count+ ios.leaf_update_count+ ios.leaf_page_merge_count+ ios.singleton_lookup_count)= 0 
THEN -1 ELSE ios.range_scan_count * 100.0 / (ios.range_scan_count+ ios.leaf_insert_count+ ios.leaf_delete_count+ ios.leaf_update_count+ ios.leaf_page_merge_count+ ios.singleton_lookup_count) END  [ScanPct],

CASE i.index_id WHEN 0 THEN 'ALTER TABLE ['+SCHEMA_NAME(o.schema_id)+'].['+o.name+'] REBUILD WITH (DATA_COMPRESSION=PAGE, ONLINE=ON, MAXDOP=1);'
ELSE 'ALTER INDEX ['+i.name+'] ON ['+SCHEMA_NAME(o.schema_id)+'].['+o.name+'] REBUILD WITH (DATA_COMPRESSION=PAGE, ONLINE=ON, MAXDOP=1, FILLFACTOR=98);' END cmd

FROM sys.objects o JOIN sys.schemas s ON s.schema_id = o.schema_id
JOIN sys.indexes i ON i.object_id = o.object_id 
JOIN sys.partitions p ON p.object_id = o.object_id AND p.index_id = i.index_id
JOIN sys.dm_db_partition_stats ps ON ps.partition_id = p.partition_id
LEFT JOIN sys.dm_db_index_operational_stats (db_id(), NULL, NULL, NULL) ios 
	ON (ios.object_id = o.object_id AND ios.index_id = i.index_id AND ios.partition_number = p.partition_number)
WHERE o.type='U' and ps.used_page_count >= 5*128
--AND i.index_id=1
--AND SCHEMA_NAME(o.schema_id) = 'dbo' --AND o.name LIKE '%remit%'
ORDER BY p.data_compression_desc, size_MB
