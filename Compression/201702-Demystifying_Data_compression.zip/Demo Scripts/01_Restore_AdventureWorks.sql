USE master
GO
--Restore AdventureWorks three from the same backups
--We're going to compress two copies (ROW & PAGE), and leave one uncompressed

RESTORE DATABASE AdventureWorks2014
FROM DISK = 'D:\SQL\AdventureWorks2014.bak'
WITH MOVE 'AdventureWorks2014_Data' TO 'D:\SQL\MSSQL13.SQL2016\MSSQL\DATA\AdventureWorks2014_Data.mdf'
    ,MOVE 'AdventureWorks2014_Log' TO 'D:\SQL\MSSQL13.SQL2016\MSSQL\Log\AdventureWorks2014_Log.ldf'
    ,REPLACE;

RESTORE DATABASE AdventureWorks2014_ROW
FROM DISK = 'D:\SQL\AdventureWorks2014.bak'
WITH MOVE 'AdventureWorks2014_Data' TO 'D:\SQL\MSSQL13.SQL2016\MSSQL\DATA\AdventureWorks2014_ROW_Data.mdf'
    ,MOVE 'AdventureWorks2014_Log' TO 'D:\SQL\MSSQL13.SQL2016\MSSQL\Log\AdventureWorks2014_ROW_Log.ldf'
    ,REPLACE;


RESTORE DATABASE AdventureWorks2014_PAGE
FROM DISK = 'D:\SQL\AdventureWorks2014.bak'
WITH MOVE 'AdventureWorks2014_Data' TO 'D:\SQL\MSSQL13.SQL2016\MSSQL\DATA\AdventureWorks2014_PAGE_Data.mdf'
    ,MOVE 'AdventureWorks2014_Log' TO 'D:\SQL\MSSQL13.SQL2016\MSSQL\Log\AdventureWorks2014_PAGE_Log.ldf'
    ,REPLACE;

