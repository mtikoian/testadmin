--Estimate Space for Savings

USE AdventureWorksDW2012;
GO
EXEC sp_estimate_data_compression_savings 'DBO', 'FactInternetSales', NULL, NULL, 'ROW' ;

EXEC sp_estimate_data_compression_savings 'DBO', 'FactInternetSales', NULL, NULL, 'PAGE';


--Check for Candiates
use AdventureWorks2012
go

--Checks for Percentage of Update Statements

SELECT o.name AS [Table_Name], x.name AS [Index_Name],
       i.partition_number AS [Partition],
       i.index_id AS [Index_ID], x.type_desc AS [Index_Type],
       i.leaf_update_count * 100.0 /
           (i.range_scan_count + i.leaf_insert_count
            + i.leaf_delete_count + i.leaf_update_count
            + i.leaf_page_merge_count + i.singleton_lookup_count
           ) AS [Percent_Update]
FROM sys.dm_db_index_operational_stats (db_id(), NULL, NULL, NULL) i
JOIN sys.objects o ON o.object_id = i.object_id
JOIN sys.indexes x ON x.object_id = i.object_id AND x.index_id = i.index_id
WHERE (i.range_scan_count + i.leaf_insert_count
       + i.leaf_delete_count + leaf_update_count
       + i.leaf_page_merge_count + i.singleton_lookup_count) != 0
AND objectproperty(i.object_id,'IsUserTable') = 1
ORDER BY [Percent_Update] DESC

--Checks for Percentage of Scans

SELECT o.name AS [Table_Name], x.name AS [Index_Name],
       i.partition_number AS [Partition],
       i.index_id AS [Index_ID], x.type_desc AS [Index_Type],
       i.range_scan_count * 100.0 /
           (i.range_scan_count + i.leaf_insert_count
            + i.leaf_delete_count + i.leaf_update_count
            + i.leaf_page_merge_count + i.singleton_lookup_count
           ) AS [Percent_Scan]
FROM sys.dm_db_index_operational_stats (db_id(), NULL, NULL, NULL) i
JOIN sys.objects o ON o.object_id = i.object_id
JOIN sys.indexes x ON x.object_id = i.object_id AND x.index_id = i.index_id
WHERE (i.range_scan_count + i.leaf_insert_count
       + i.leaf_delete_count + leaf_update_count
       + i.leaf_page_merge_count + i.singleton_lookup_count) != 0
AND objectproperty(i.object_id,'IsUserTable') = 1
ORDER BY [Percent_Scan] DESC

--Compress Table and Indexes (USE GUI)

select *  into bigproduct_UC_new from bigproduct
select *  into bigproduct_row_new from bigproduct

select * into bigtransaction_UC from bigTransactionHistory;
select * into bigtransaction_row from bigTransactionHistory;

--Set stats on
use AdventureWorks2012;
Go
set statistics io on
set statistics time on

--Run Initial Query 

select productid, transactiondate, quantity, actualcost from 
bigtransaction_UC where Quantity > 70 and Quantity < 92 AND TransactionDate > '2008-01-01';

--Show and Capture Statistics

exec dbo.show_buffers;

--TurnOn Compression

USE [AdventureWorks2012]
ALTER TABLE [dbo].[bigTransactionHistory] REBUILD PARTITION = ALL
WITH 
(DATA_COMPRESSION = PAGE
)

USE [AdventureWorks2012]
ALTER INDEX [compression_index] ON [dbo].[bigTransactionHistory] 
REBUILD PARTITION = ALL WITH 
(PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, ONLINE = OFF, 
ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, DATA_COMPRESSION = PAGE)

ALTER TABLE [dbo].[bigTransaction_row] REBUILD PARTITION = ALL
WITH 
(DATA_COMPRESSION = ROW
)

ALTER INDEX [compression_index_row] ON [dbo].[bigTransactionHistory_row] 
REBUILD PARTITION = ALL WITH 
(PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, ONLINE = OFF, 
ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, DATA_COMPRESSION = ROW)

--Show Compression

select b.name, a.object_id, a.data_compression  from sys.partitions a, sys.objects b where 
a.data_compression <> 0 and a.object_id=b.object_id ;

/* Indicates the state of compression for each partition:
0 = NONE
1 = ROW
2 = PAGE
3 = COLUMNSTORE */



--Run Same Query Compressed

select TransactionID, productid, transactiondate, quantity, actualcost from 
dbo.bigTransactionHistory where Quantity > 70 and Quantity < 92 AND TransactionDate > '2008-01-01';

--Capture Statistics and Buffers

exec dbo.show_buffers;


--Show Cost of Update (Single Row)

set statistics io on
set statistics time on

update dbo.bigTransactionHistory set Quantity=89 where TransactionID=24018460;
update dbo.bigTransaction_row set Quantity=89 where TransactionID=24018460;
update dbo.bigtransaction_uc set Quantity=89 where TransactionID=24018460;


--Show Cost of Update (Bulk)

--Page Compressed

DBCC DROPCLEANBUFFERS
DBCC FREEPROCCACHE

update dbo.bigTransactionHistory set Quantity=92 where TransactionDate > '2008-01-01' and TransactionDate < '2008-01-14';
exec dbo.show_buffers;


--Row Compressed 

DBCC DROPCLEANBUFFERS
DBCC FREEPROCCACHE

update dbo.bigTransaction_row set Quantity=92 where TransactionDate > '2008-01-01' and TransactionDate < '2008-01-14';
exec dbo.show_buffers;


--Uncompressed

DBCC DROPCLEANBUFFERS
DBCC FREEPROCCACHE

update dbo.bigtransaction_uc set Quantity=92 where TransactionDate > '2008-01-01' and TransactionDate < '2008-01-14';
exec dbo.show_buffers;


--Show Index Rebuild
set statistics time on



ALTER INDEX [noncompression_index] ON [dbo].[big_TransactionHistory_UC] 
REBUILD PARTITION = ALL WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, 
SORT_IN_TEMPDB = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)


ALTER INDEX [compression_index] ON [dbo].[bigTransactionHistory] 
REBUILD PARTITION = ALL WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, 
SORT_IN_TEMPDB = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)

--Show Cost of Insert

use AdventureWorksDW2012

USE [AdventureWorksDW2012]
GO

/****** Object:  Table [dbo].[FactInternetSales]    Script Date: 5/8/2013 3:42:23 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[FactInternetSales_Compressed](
	[ProductKey] [int] NOT NULL,
	[OrderDateKey] [int] NOT NULL,
	[DueDateKey] [int] NOT NULL,
	[ShipDateKey] [int] NOT NULL,
	[CustomerKey] [int] NOT NULL,
	[PromotionKey] [int] NOT NULL,
	[CurrencyKey] [int] NOT NULL,
	[SalesTerritoryKey] [int] NOT NULL,
	[SalesOrderNumber] [nvarchar](20) NOT NULL,
	[SalesOrderLineNumber] [tinyint] NOT NULL,
	[RevisionNumber] [tinyint] NOT NULL,
	[OrderQuantity] [smallint] NOT NULL,
	[UnitPrice] [money] NOT NULL,
	[ExtendedAmount] [money] NOT NULL,
	[UnitPriceDiscountPct] [float] NOT NULL,
	[DiscountAmount] [float] NOT NULL,
	[ProductStandardCost] [money] NOT NULL,
	[TotalProductCost] [money] NOT NULL,
	[SalesAmount] [money] NOT NULL,
	[TaxAmt] [money] NOT NULL,
	[Freight] [money] NOT NULL,
	[CarrierTrackingNumber] [nvarchar](25) NULL,
	[CustomerPONumber] [nvarchar](25) NULL,
	[OrderDate] [datetime] NULL,
	[DueDate] [datetime] NULL,
	[ShipDate] [datetime] NULL,
 CONSTRAINT [PK_FactInternetSales_SalesOrderNumber_SalesOrderLineNumber_Compressed] PRIMARY KEY CLUSTERED 
(
	[SalesOrderNumber] ASC,
	[SalesOrderLineNumber] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, DATA_COMPRESSION = PAGE) ON [PRIMARY]
)  ON [PRIMARY]

GO


use AdventureWorksDW2012

USE [AdventureWorksDW2012]
GO

/****** Object:  Table [dbo].[FactInternetSales]    Script Date: 5/8/2013 3:42:23 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[FactInternetSales_UnCompressed](
	[ProductKey] [int] NOT NULL,
	[OrderDateKey] [int] NOT NULL,
	[DueDateKey] [int] NOT NULL,
	[ShipDateKey] [int] NOT NULL,
	[CustomerKey] [int] NOT NULL,
	[PromotionKey] [int] NOT NULL,
	[CurrencyKey] [int] NOT NULL,
	[SalesTerritoryKey] [int] NOT NULL,
	[SalesOrderNumber] [nvarchar](20) NOT NULL,
	[SalesOrderLineNumber] [tinyint] NOT NULL,
	[RevisionNumber] [tinyint] NOT NULL,
	[OrderQuantity] [smallint] NOT NULL,
	[UnitPrice] [money] NOT NULL,
	[ExtendedAmount] [money] NOT NULL,
	[UnitPriceDiscountPct] [float] NOT NULL,
	[DiscountAmount] [float] NOT NULL,
	[ProductStandardCost] [money] NOT NULL,
	[TotalProductCost] [money] NOT NULL,
	[SalesAmount] [money] NOT NULL,
	[TaxAmt] [money] NOT NULL,
	[Freight] [money] NOT NULL,
	[CarrierTrackingNumber] [nvarchar](25) NULL,
	[CustomerPONumber] [nvarchar](25) NULL,
	[OrderDate] [datetime] NULL,
	[DueDate] [datetime] NULL,
	[ShipDate] [datetime] NULL,
 CONSTRAINT [PK_FactInternetSales_SalesOrderNumber_SalesOrderLineNumber_UnCompressed] PRIMARY KEY CLUSTERED 
(
	[SalesOrderNumber] ASC,
	[SalesOrderLineNumber] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
)  ON [PRIMARY]

GO

set statistics io on
set statistics time on



insert into FactInternetSales_Compressed select * from FactInternetSales;

insert into FactInternetSales_UnCompressed select * from FactInternetSales;




 


--Create Columnstore Index
use AdventureWorks2012

DROP INDEX [NonClusteredColumnStoreIndex-20130318-100441] ON [dbo].[bigTransactionHistory]
GO

use AdventureWorks2012
go
CREATE NONCLUSTERED COLUMNSTORE INDEX [NonClusteredColumnStoreIndex-20130318-100441] ON [dbo].[bigTransactionHistory]
(
	[TransactionID],
	[ProductID],
	[TransactionDate],
	[Quantity],
	[ActualCost]
)WITH (DROP_EXISTING = OFF) ON [PRIMARY]
GO

CREATE NONCLUSTERED  INDEX [NonClusteredIndexbigtransactionhistory] ON [dbo].[bigTransactionHistory]
(
	[TransactionID],
	[ProductID],
	[TransactionDate],
	[Quantity],
	[ActualCost]
)WITH (DATA_COMPRESSION=PAGE, DROP_EXISTING = OFF) ON [PRIMARY]
GO



SELECT object_name(i.object_id) as table_name
,COALESCE(i.name, space(0)) as index_name
,ps.partition_number
,ps.row_count
,Cast((ps.reserved_page_count * 8)/1024. as decimal(12,2)) as size_in_mb
,COALESCE(ius.user_seeks,0) as user_seeks
,COALESCE(ius.user_scans,0) as user_scans
,COALESCE(ius.user_lookups,0) as user_lookups
,i.type_desc
FROM sys.all_objects t
INNER JOIN sys.indexes i ON t.object_id = i.object_id
INNER JOIN sys.dm_db_partition_stats ps ON i.object_id = ps.object_id AND i.index_id = ps.index_id
LEFT OUTER JOIN sys.dm_db_index_usage_stats ius ON ius.database_id = db_id() AND i.object_id = ius.object_id AND i.index_id = ius.index_id
where object_name(i.object_id)='bigTransactionHistory'
ORDER BY object_name(i.object_id), i.name

DROP INDEX [NonClusteredIndexbigtransactionhistory] ON [dbo].[bigTransactionHistory]
GO

--Run Columnstore Query

set statistics io on
set statistics time on
DBCC DROPCLEANBUFFERS
DBCC FREEPROCCACHE

select TransactionID, productid, transactiondate, quantity, actualcost from 
dbo.bigTransactionHistory where Quantity > 70 and Quantity < 92 AND TransactionDate > '2008-01-01';


select transactiondate, avg(actualcost) from 
dbo.bigTransactionHistory where  TransactionDate > '2001-01-01'
group by TransactionDate
order by transactionDate;

select sum(actualcost) from dbo.bigTransactionHistory

DROP INDEX [NonClusteredColumnStoreIndex-20130318-100441] ON [dbo].[bigTransactionHistory]
GO

select sum(actualcost) from dbo.bigTransactionHistory



--Capture Statistics and Buffers


exec dbo.show_buffers;






