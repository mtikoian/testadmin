-- =====================================================================================================
-- Demo data compression estimation and analysis queries accompanying my presentation
-- "Putting the Squeeze on Large Tables"
-- Runnable on SQL Server 2008 and later
-- May take some time to run, depending on your hardware infrastructure and table size
-- Justin Randall 
-- June 2015

-- Procedure sp_estimate_data_compression_savings_all was created by Chad Boyd as presented in 
-- this article http://www.mssqltips.com/sqlservertip/2219/estimating-data-compression-ratios-for-all/ 

-- Queries in Steps 2 - 6 adapted from Glenn Berry's Blog Post
-- Estimating Data Compression Savings in SQL Server 2012
-- http://www.sqlskills.com/blogs/glenn/estimating-data-compression-savings-in-sql-server-2012/

-- =====================================================================================================
USE SQLSentryCompression;
GO
-- ===============================================================================
-- Get Table names, row counts, and compression status for clustered index or heap
-- =============================================================================
SELECT 
    OBJECT_NAME(object_id) AS [ObjectName], 
    SUM(Rows) AS [RowCount], 
    data_compression_desc AS [CompressionType]
FROM sys.partitions WITH (NOLOCK)
WHERE index_id < 2 --ignore the partitions from the non-clustered index if any
AND OBJECT_NAME(object_id) NOT LIKE N'sys%'
AND OBJECT_NAME(object_id) NOT LIKE N'queue_%' 
AND OBJECT_NAME(object_id) NOT LIKE N'filestream_tombstone%' 
AND OBJECT_NAME(object_id) NOT LIKE N'fulltext%'
AND OBJECT_NAME(object_id) NOT LIKE N'ifts_comp_fragment%'
AND OBJECT_NAME(object_id) NOT LIKE N'filetable_updates%'
AND OBJECT_NAME(object_id) NOT LIKE N'xml_index_nodes%'
GROUP BY object_id, data_compression_desc
ORDER BY SUM(Rows) DESC OPTION (RECOMPILE);

-- =============================================================================
-- Execute sp_estimate_data_compression_savings
-- =============================================================================
EXEC sys.sp_estimate_data_compression_savings
	@schema_name = N'dbo',
	@object_name = N'PerformanceAnalysisDataDiskCounter',
	@partition_number = NULL,
	@index_id = NULL,
	@data_compression = N'ROW';

EXEC sys.sp_estimate_data_compression_savings
	@schema_name = N'dbo',
	@object_name = N'PerformanceAnalysisDataDiskCounter',
	@partition_number = NULL,
	@index_id = NULL,
	@data_compression = N'PAGE';

EXEC sys.sp_estimate_data_compression_savings
	@schema_name = N'dbo',
	@object_name = N'PerformanceAnalysisDataDiskCounter',
	@partition_number = NULL,
	@index_id = NULL,
	@data_compression = N'NONE';

EXEC sys.sp_estimate_data_compression_savings
	@schema_name = N'dbo',
	@object_name = N'eventsourcehistory',
	@partition_number = NULL,
	@index_id = NULL,
	@data_compression = N'ROW';

EXEC sys.sp_estimate_data_compression_savings
	@schema_name = N'dbo',
	@object_name = N'eventsourcehistory',
	@partition_number = NULL,
	@index_id = NULL,
	@data_compression = N'PAGE';

EXEC sys.sp_estimate_data_compression_savings
	@schema_name = N'dbo',
	@object_name = N'eventsourcehistory',
	@partition_number = NULL,
	@index_id = NULL,
	@data_compression = N'NONE';

-- =============================================================================
-- Execute sp_estimate_data_compression_savings_all
-- =============================================================================
EXEC dbo.sp_estimate_data_compression_savings_all2 
			 @opts = 3						-- Options that drive execution for the proc - set to 0 (zero) for no options...
												-- 1 bit -	If set, nonclustered indexes are included in the tests (by default, only heaps/clusters are included)
												-- 2 bit -	If set, we return information sorted by compression savings (MB) vs. object names...
			,@data_compression = 'ALL'		-- Type of compression to evaluate. Valid values are NONE, ROW, PAGE, or ALL
			,@minimum_mbs = 50				-- Limit testing to objects/indexes that exceed this number of MegaBytes in used space...
			,@object_name = NULL			-- Object to check - specify null/default to check all objects matching other parameters...
			,@cleanup = 1;					-- Delete or keep tables created in tempdb
												-- 0 - delete tables
												-- 1 - keep tables (be sure to clean up manually when you are done!)


-- ===============================================================================
-- Get reduced result set
-- ===============================================================================

SELECT 
	 cs.schemaName + '.' + cs.objectName AS NAME
	,cs.indexName + ' (' + CASE WHEN cs.indexId = 1	THEN 'CL'
								WHEN cs.indexId > 1	THEN 'NC'
								ELSE 'HP'
							END + ')' AS indexName
	,cs.currentCompressionState AS currentCompression
	,es.compressionState AS estimatedCompression
	,cs.totalRowCnt AS TotalRowCnt
	,(es.size_with_current_compression_setting / 1024) AS currentUsedSpaceMB
	,(es.size_with_requested_compression_setting / 1024) AS estimatedUsedSpaceMB
	,((es.size_with_current_compression_setting - es.size_with_requested_compression_setting) / 1024) AS estimatedSavingsMB
	,cast(cast(es.size_with_current_compression_setting AS NUMERIC(20, 2)) / cast(es.size_with_requested_compression_setting AS NUMERIC(20, 2)) AS NUMERIC(20, 2)) AS estimatedCompressionRatio
	,cast((((es.size_with_current_compression_setting - es.size_with_requested_compression_setting) / cast(es.size_with_current_compression_setting AS NUMERIC(20, 2))) * 100) AS NUMERIC(20, 2)) AS estimatedSavingsPercent
FROM tempdb..est_data_sizes cs
LEFT JOIN tempdb..est_data_comp_all_data es ON cs.schemaName = es.schemaName
	AND cs.objectName = es.objectName
	AND cs.indexId = es.indexId
	AND cs.partitionNumber = es.partitionNumber
WHERE cs.objectName IN ('PerformanceAnalysisData','PerformanceanalysisDataRollup2','PerformanceAnalysisDataRollup14',
						'PerformanceAnalysisDataDiskCounter','EventSourceHistory','EventSourceHistoryDetail')
ORDER BY 
	6 DESC,
	cs.objectName,
	cs.indexname,
	CASE WHEN es.compressionState = 'PAGE' THEN 1 
		 WHEN es.compressionState = 'NONE' THEN 2 
		 ELSE 3 
	END;

-- ==========================================================
-- Review Tables
-- ==========================================================

-- PerformanceAnalysisDataDiskCounter

exec sp_helpIndex @objname = 'dbo.PerformanceAnalysisDataDiskCounter'
go

SELECT 
	TABLE_NAME, 
	COLUMN_NAME, 
	DATA_TYPE, 
	CHARACTER_MAXIMUM_LENGTH, 
	NUMERIC_PRECISION, 
	IS_NULLABLE
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'PerformanceAnalysisDataDiskCounter'
ORDER BY ORDINAL_POSITION

--exec sys.sp_columns 
--	@table_name = 'PerformanceAnalysisData',
--	@table_owner = 'dbo'
--go

exec sp_spaceused N'PerformanceAnalysisDataDiskCounter', N'TRUE'
go

-- =================================
-- EventSourceHistory
-- ================================
exec sp_helpIndex @objname = 'dbo.EventSourceHistory'


SELECT 
	TABLE_NAME, 
	COLUMN_NAME, 
	DATA_TYPE, 
	CHARACTER_MAXIMUM_LENGTH, 
	NUMERIC_PRECISION, 
	IS_NULLABLE
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'EventSourceHistory'
	AND COLUMN_NAME IN ('ID','EventSourceID', 'Incomplete', 'Synchronized', 'ObjectID')
		--('RunStatus', 'ReviewState', 'NormalizedStartTime', 'EventSourceID','ObjectID')
ORDER BY ORDINAL_POSITION

SELECT TotalRows = COUNT(*) FROM dbo.EventSourceHistory;
SELECT RunStatusNullRows = COUNT(*) FROM dbo.EventSourceHistory WHERE RunStatus IS NULL;
SELECT NormalizedStartTimeRows = COUNT(*) FROM dbo.EventSourceHistory WHERE NormalizedStartTime IS NULL;

exec sp_spaceused N'EventSourceHistory', N'TRUE'
go

/*
USE Tempdb;
Drop TABLE dbo.est_data_comp_all_data
*/

-- =============================================================================
-- Implement Compression
-- =============================================================================

-- =================================================================
-- example 1 - large table with clustered index only
-- =================================================================

-- ROW COMPRESSION
exec sp_spaceused N'PerformanceAnalysisDataDiskCounter', N'TRUE'	--check space used

ALTER TABLE dbo.PerformanceAnalysisDataDiskCounter					--run compression
	REBUILD WITH (DATA_COMPRESSION = ROW); 

exec sp_spaceused N'PerformanceAnalysisDataDiskCounter', N'TRUE'	--re-check space used

--PAGE COMPRESSION
exec sp_spaceused N'PerformanceAnalysisDataDiskCounter', N'TRUE'	--check space used

ALTER TABLE dbo.PerformanceAnalysisDataDiskCounter				--run compression
	REBUILD WITH (DATA_COMPRESSION = PAGE); 

exec sp_spaceused N'PerformanceAnalysisDataDiskCounter', N'TRUE'	--re-check space used
go

-- UNCOMPRESS
ALTER TABLE dbo.PerformanceAnalysisDataDiskCounter	
	REBUILD WITH (DATA_COMPRESSION = NONE); 

-- =================================================================
-- example 2 - Index with low compression ratio
-- =================================================================
-- ROW COMPRESSION
exec sp_spaceused N'EventSourceHistory', N'TRUE'	--check space used

ALTER INDEX [IX_FailedObjectsInRange] 
	ON dbo.EventSourceHistory		
	REBUILD WITH (DATA_COMPRESSION =  ROW);

exec sp_spaceused N'EventSourceHistory', N'TRUE'	--re-check space used

--PAGE COMPRESSION
exec sp_spaceused N'EventSourceHistory', N'TRUE'	--check space used

ALTER INDEX [IX_FailedObjectsInRange] 
	ON dbo.EventSourceHistory		
	REBUILD WITH (DATA_COMPRESSION =  PAGE) ;

exec sp_spaceused N'EventSourceHistory', N'TRUE'	--re-check space used

-- UNCOMPRESS
ALTER INDEX [IX_FailedObjectsInRange] 
	ON dbo.EventSourceHistory		
	REBUILD WITH (DATA_COMPRESSION =  NONE); 

-- =============================================================================
-- Compare Index Rebuild
-- =============================================================================
USE SQLSentryCompression;
ALTER INDEX [IX_PerformanceAnalysisData_Wide] 
	ON [dbo].[PerformanceAnalysisData] REBUILD WITH (ONLINE = ON);


USE SQLSentryCompression2;
ALTER INDEX [IX_PerformanceAnalysisData_Wide] 
	ON [dbo].[PerformanceAnalysisData] REBUILD WITH (ONLINE = ON);

-- ======================================
-- Backup DB
-- =====================================
USE [Master];
GO

BACKUP DATABASE [SQLSentryCompression2] 
	TO DISK = N'D:\SQLBkup\OLTP\SQLSentryCompression2DemoCompressed.bak' 
	WITH NOFORMAT, NOINIT,  NAME = N'SQLSentryCompression-Full Database Backup', 
	SKIP, NOREWIND, NOUNLOAD, COMPRESSION,  STATS = 10
GO

