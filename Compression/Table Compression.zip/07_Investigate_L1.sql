USE AdventureWorks2012;
GO
SELECT ObjName = OBJECT_NAME(p.object_id)
		,IDXName = i.name
		,p.data_compression_desc
	FROM sys.partitions p
		INNER JOIN sys.indexes i
			ON i.object_id = p.object_id
			AND i.index_id = p.index_id
	WHERE data_compression > 0
		AND OBJECTPROPERTY(i.object_id,'IsUserTable') = 1;
GO