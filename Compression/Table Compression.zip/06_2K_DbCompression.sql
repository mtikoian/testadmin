SELECT *
	FROM sys.databases
	WHERE name = 'northwind';
GO


USE Northwind;
GO

SELECT @@VERSION

ALTER TABLE dbo.Employees REBUILD
WITH (DATA_COMPRESSION = PAGE);
GO

USE Northwind;
GO
SELECT TableName = OBJECT_NAME(object_id)
		,index_id
		,ROWS,data_compression_desc
		,object_id
	FROM sys.partitions
	WHERE OBJECT_NAME(object_id) = 'Employees';
GO

USE master;
GO

SELECT DB_NAME(database_ID),ObjName = O.name,IdxName = I.name,ps.index_depth,ps.compressed_page_count
	FROM sys.dm_db_index_physical_stats(DB_ID('Northwind'),NULL,NULL,NULL,'detailed') ps
		INNER JOIN Northwind.sys.objects O
			ON ps.object_id = o.object_id
		INNER JOIN Northwind.sys.indexes I
			ON ps.object_id = I.object_id
			AND ps.index_id = I.index_id 
	WHERE o.name = 'Employees';
GO

USE Northwind;
GO
ALTER TABLE dbo.Employees REBUILD
WITH (DATA_COMPRESSION = NONE);