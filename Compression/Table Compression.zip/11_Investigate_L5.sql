/* PIVOT the DATA FOR better use */

Insert Into AdminDB.dbo.DBCCPage_Pivot (DatabaseID,PageFID,PagePID,SlotNo,AllocUnitID,PartitionID,IndexID,ObjectID
							,RecordType,SlotCnt,PageCompressed)
Select @dbid,@PageFID,@PagePID,convert(int,ltrim(Substring(Object,5,CHARINDEX(',',object)-5))) as SlotNo
		,[Metadata: AllocUnitId],[Metadata: PartitionId]
		,[Metadata: IndexId],[Metadata: ObjectId],[Record Type],[m_slotCnt] as SlotsOnPage
		,[CI Header Flags] as PageCompressed
	From AdminDB.dbo.DBCCPage
		PIVOT   (
			max(Value)
			FOR Field IN ([Record Type])
		) PVT
	Cross apply (Select [Metadata: AllocUnitId],[Metadata: PartitionId]
							,[Metadata: IndexId],[Metadata: ObjectId],[m_slotCnt],[CI Header Flags]
					From AdminDB.dbo.DBCCPage
					PIVOT   (
						max(Value)
						FOR Field IN ([Metadata: AllocUnitId],[Metadata: PartitionId]
							,[Metadata: IndexId],[Metadata: ObjectId],[m_slotCnt],[CI Header Flags])
					) PVT
			Where ParentObject in ('PAGE HEADER:')
				And (Object like 'Page%' or Object like 'Compression%')
				) ca
	Where ParentObject in ('DATA:')
		And (Object like 'slot%')
	Order by SlotNo asc