USE AdventureWorks2012;
GO

select DB_NAME(db_id()) as DBNAME, OBJECT_NAME(ips.object_id) as OBJName
		,ips.index_id,alloc_unit_type_desc,index_depth,ips.partition_number,record_count,page_count,compressed_page_count
		,p.data_compression_desc
	From sys.dm_db_index_physical_stats(DB_ID('AdventureWorks2012'),null,null,null,'detailed') ips
		Inner Join sys.partitions p
			On ips.object_id = p.object_id
			And ips.index_id = p.index_id
			And ips.partition_number = p.partition_number
			And p.data_compression > 0;
GO