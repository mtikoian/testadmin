USE CompressTest;
GO

/* Examine the Compression Information (CI) Header within the page header */
/* This page is only Row compressed */
dbcc page ('CompressTest',1,171 ,1) with tableresults;
SELECT OBJECT_NAME(565577053);

/* Same object and the page is PAGE compressed */
dbcc page ('CompressTest',1,198 ,1) with tableresults;
SELECT OBJECT_NAME(565577053);

/* The Table with a CI - PAGE compressed page*/
dbcc page ('CompressTest',1,284 ,1) with tableresults;
SELECT OBJECT_NAME(533576939);

/* The Table with a CI - ROW compressed page*/
dbcc page ('CompressTest',1,404 ,1) with tableresults;
SELECT OBJECT_NAME(533576939);

/* Blob */
DBCC IND ('CompressTest','SomeBLOB',1);

/* FIRST PAGE IN the TABLE */
DBCC TRACEON (3604);

GO
dbcc page ('CompressTest',1,60608 ,3);

/* A linked blob page */
dbcc page ('CompressTest',1,10209 ,1) with tableresults;

dbcc page ('CompressTest',1,352 ,1) with tableresults;
SELECT OBJECT_NAME(645577338);

