USE CompressTest;
GO

ALTER TABLE dbo.SomeTable REBUILD
WITH (DATA_COMPRESSION = PAGE);
GO

USE CompressTest;
GO

/* SQL 2012 Version does not require dbcc page */
SELECT *
	FROM sys.dm_db_database_page_allocations(DB_ID(),OBJECT_ID('sometable'),1,NULL,'Detailed');
	/* allocated_page_file_id, allocated_page_page_id, page_type_desc, is_page_compressed */

ALTER TABLE dbo.SomeTable REBUILD
WITH (DATA_COMPRESSION = NONE);
GO

USE AdventureWorks2012;
GO

SELECT *
	FROM sys.dm_db_database_page_allocations(DB_ID(),OBJECT_ID('Person.Address'),1,NULL,'limited');