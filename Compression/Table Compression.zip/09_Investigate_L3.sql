USE master;
GO

DBCC IND ('CompressTest','SomeBLOB',1);
GO






















/* run dbcc ind for tables where compressed_page_count <> page_count
			get all page nums and file nums and insert that into another table
		*/
Declare dbccindC cursor static for
	Select Distinct DBName, objname
		From AdminDB.dbo.indexinfo
		Where compressed_page_count < page_count
		Group By DBName,OBJName

Declare @dbname sysname
		,@ObjName sysname

Open dbccindC
Fetch next from dbccindc
	Into @dbname,@objname;
	
While @@FETCH_STATUS = 0
	Begin
		Insert Into AdminDB.dbo.DBCCInd (PageFID, PagePID , IAMFID , IAMPID , ObjectID ,IndexID , PartitionNumber 
				,PartitionID,iam_chain_type ,PageType ,IndexLevel , NextPageFID , NextPagePID 
				,PrevPageFID , PrevPagePID)
		Exec ('DBCC IND ('+@dbname+', ' + @objname + ', 1);')