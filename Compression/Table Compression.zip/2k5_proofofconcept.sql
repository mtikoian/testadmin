/* SQL 2008 Row V Page Compression Scripts */

Declare @ControlFlow tinyint 

Set @ControlFlow = 0

If @ControlFlow = 0
	Begin
		/* insert these results into a table */
		Insert Into AdminDB.dbo.IndexInfo
		select DB_NAME(db_id()) as DBNAME, OBJECT_NAME(ips.object_id) as OBJName
				,ips.index_id,alloc_unit_type_desc,index_depth
				--,CASE ips.index_level
				--	WHEN 0 THEN 'Leaf-Level'
				--	ELSE 'Non-Leaf-Level'
				--	END AS Index_Level
				--,ips.index_level
				,ips.partition_number,record_count,page_count,compressed_page_count
				,p.data_compression_desc
			From sys.dm_db_index_physical_stats(DB_ID(),null,null,null,'sampled') ips
				Inner Join sys.partitions P
					On ips.object_id = p.object_id
					And ips.index_id = p.index_id
					And ips.partition_number = p.partition_number
					And p.data_compression > 0
					--AND OBJECT_NAME(ips.object_id) = 'SomeBLOB'
		
		Set @ControlFlow = 1
	End
--TRUNCATE TABLE AdminDB.dbo.dbccind
--TRUNCATE TABLE admindb.dbo.dbccpage
--TRUNCATE TABLE AdminDB.dbo.dbccpage_pivot

If @ControlFlow = 1
	Begin

		/* run dbcc ind for tables where compressed_page_count <> page_count
			get all page nums and file nums and insert that into another table
		*/
		Declare dbccindC cursor static for
			Select Distinct DBName, objname
				From AdminDB.dbo.indexinfo
				Where compressed_page_count < page_count
				Group By DBName,OBJName

		Declare @dbname sysname
				,@ObjName sysname

		Open dbccindC
		Fetch next from dbccindc
			Into @dbname,@objname;
			
		While @@FETCH_STATUS = 0
			Begin
				Insert Into AdminDB.dbo.DBCCInd (PageFID, PagePID , IAMFID , IAMPID , ObjectID ,IndexID , PartitionNumber 
						,PartitionID,iam_chain_type ,PageType ,IndexLevel , NextPageFID , NextPagePID 
						,PrevPageFID , PrevPagePID)
				Exec ('DBCC IND ('+@dbname+', ' + @objname + ', 1);')

				Update AdminDB.dbo.DBCCInd
					Set DatabaseName = @dbname
					Where DatabaseName is NULL

				Fetch next from dbccindc
					Into @dbname,@objname;
			End
		Close dbccindc
		deallocate dbccindc

		Set @ControlFlow = 2
	End
select * from AdminDB.dbo.DBCCInd

/* run dbcc page for each page returned from dbcc ind to determine which pages are not page compressed 
	loop based
	needs to pivot out record type (look to value column for compression) need slot num - slot 0=row 1
	Page dictionary entries required if page compressed - else if slot # says compressed it is row_compressed
		else not compressed
Field
	Metadata: AllocUnitId
	Metadata: PartitionId
	Metadata: IndexId
	Metadata: ObjectId
	Record Type
	
ParentObject
	Data
*/

If @ControlFlow = 2
	Begin

		/* stage and then trunc after ship to pivoted table*/
		Declare dbccPageC cursor static for
			Select Distinct db_id(DatabaseName), PageFID,PagePID
				From AdminDB.dbo.DBCCInd
				Where isProcessed = 0
				Group By DatabaseName, PageFID,PagePID

		Declare @dbid		Int
				,@PageFID	Int
				,@PagePID	BigInt

		Open dbccPageC
		Fetch next from dbccPageC
			Into @dbid,@PageFID,@PagePID;
			
		While @@FETCH_STATUS = 0
			Begin
				Truncate Table AdminDB.dbo.DBCCPage

				Insert Into AdminDB.dbo.DBCCPage
				Exec ('dbcc page ('+@dbid+','+ @PageFID +',' + @PagePID + ',1) with tableresults') --this should work for this exercise


		/* pivot data out to next table */


				Insert Into AdminDB.dbo.DBCCPage_Pivot (DatabaseID,PageFID,PagePID,SlotNo,AllocUnitID,PartitionID,IndexID,ObjectID
							,RecordType,SlotCnt,PageCompressed)
				Select @dbid,@PageFID,@PagePID,convert(int,ltrim(Substring(Object,5,CHARINDEX(',',object)-5))) as SlotNo
						,[Metadata: AllocUnitId],[Metadata: PartitionId]
						,[Metadata: IndexId],[Metadata: ObjectId],[Record Type],[m_slotCnt] as SlotsOnPage
						,[CI Header Flags] as PageCompressed
					From AdminDB.dbo.DBCCPage
						PIVOT   (
							max(Value)
							FOR Field IN ([Record Type])
						) PVT
					Cross apply (Select [Metadata: AllocUnitId],[Metadata: PartitionId]
											,[Metadata: IndexId],[Metadata: ObjectId],[m_slotCnt],[CI Header Flags]
									From AdminDB.dbo.DBCCPage
									PIVOT   (
										max(Value)
										FOR Field IN ([Metadata: AllocUnitId],[Metadata: PartitionId]
											,[Metadata: IndexId],[Metadata: ObjectId],[m_slotCnt],[CI Header Flags])
									) PVT
							Where ParentObject in ('PAGE HEADER:')
								And (Object like 'Page%' or Object like 'Compression%')
								) ca
					Where ParentObject in ('DATA:')
						And (Object like 'slot%')
					Order by SlotNo asc
			

			
			Update AdminDB.dbo.DBCCInd
				Set isProcessed = 1
				Where isProcessed = 0
					And db_id(DatabaseName) = @dbid
					And PageFID = @PageFID
					And PagePID = @PagePID
					
			Fetch Next From dbccPageC
			Into @dbid,@PageFID,@PagePID;
			End
			
		Close dbccPageC
		DEALLOCATE dbccPageC

		Set @ControlFlow = 4
	End
	
If @ControlFlow = 4
	BEGIN
		UPDATE P1
			SET P1.PageCompressed = P2.PageCompressed
				From AdminDB.dbo.DBCCPage_Pivot P1
					INNER JOIN AdminDB.dbo.DBCCPage_Pivot P2
						ON P1.DatabaseID = P2.DatabaseID
						AND P1.PageFID = P2.PageFID
						AND P1.PagePID = P2.PagePID
						AND P1.slotno = p2.slotno
						AND P2.AllocUnitID IS NULL;
						
		DELETE AdminDB.dbo.DBCCPage_Pivot
			WHERE AllocUnitID IS NULL;
			
		--SELECT * FROM AdminDB.dbo.DBCCPAGE;
		Select * from AdminDB.dbo.DBCCPage_Pivot P
			ORDER BY P.ObjectID,P.PagePID,P.SlotNo;
	End

/* row info ?? 
-- select rows from the table of interest
-- (as well as their physical location)
select top (10) 
	t.*,
	pl.file_id, pl.page_id, pl.slot_id
from PersonName as t
cross apply sys.fn_PhysLocCracker(t.%%physloc%%) as pl;

SELECT top 10
	sys.fn_PhysLocFormatter (%%physloc%%) AS [Physical RID], * FROM personname;
*/