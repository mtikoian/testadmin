USE CompressTest;
GO

ALTER TABLE dbo.SomeTable REBUILD
WITH (DATA_COMPRESSION = PAGE);
GO

ALTER TABLE dbo.SomeHeap REBUILD
WITH (DATA_COMPRESSION = PAGE);
GO

ALTER TABLE dbo.SomeBLOB REBUILD
WITH (DATA_COMPRESSION = PAGE);
GO

USE CompressTest;
GO
SELECT TableName = OBJECT_NAME(object_id)
		,index_id
		,ROWS,data_compression_desc
		,object_id
	FROM sys.partitions
	WHERE OBJECT_NAME(object_id) in ('SomeTable','SomeHeap','SomeBLOB');
GO

ALTER TABLE dbo.SomeTable REBUILD
WITH (DATA_COMPRESSION = NONE);
GO

USE PTTest;
GO
ALTER TABLE dbo.Attribute REBUILD
WITH (DATA_COMPRESSION = PAGE);
GO

USE PTTest;
GO
SELECT TableName = OBJECT_NAME(object_id)
		,index_id
		,ROWS,data_compression_desc
		,object_id
	FROM sys.partitions
	WHERE OBJECT_NAME(object_id) in ('Attribute');
GO