-- select rows from the table of interest
-- (as well as their physical location)
select --top (10) 
	t.*,
	pl.slot_id
from SomeTable as t
cross apply sys.fn_PhysLocCracker(t.%%physloc%%) as pl
	WHERE pl.FILE_ID = 1
		AND pl.page_id = 284;

SELECT --top 10
	sys.fn_PhysLocFormatter (%%physloc%%) AS [Physical RID], T.* 
	FROM dbo.SomeTable T
	WHERE sys.fn_PhysLocFormatter (%%physloc%%) like '(1:284:%)';
	
/* Look at the DATA ON those pages */
dbcc page ('CompressTest',1,404 ,3) with tableresults;
dbcc page ('CompressTest',1,284 ,3) with tableresults;

DBCC TRACEON (3604);

GO
dbcc page ('CompressTest',1,352 ,3);