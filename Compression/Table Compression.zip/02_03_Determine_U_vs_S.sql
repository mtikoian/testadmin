USE DBA_perf;
Go
/*
Create some activity in a second session - just in case
SELECT *
	FROM dbo.DBA_Blocking;
Go 5000;


UPDATE dbo.dba_PerfMonAgg
	SET StatsTime = StatsTime;
	
UPDATE dbo.DBA_blockingLog
	SET Blocking_spid = Blocking_spid;
		
*/

WITH presel AS (
SELECT o.name AS [Table_Name], x.name AS [Index_Name],
       i.partition_number AS [PartitionNumber],
       i.index_id AS [Index_ID], x.type_desc AS [Index_Type],
       i.leaf_update_count * 100.0 /
           (i.range_scan_count + i.leaf_insert_count
            + i.leaf_delete_count + i.leaf_update_count
            + i.leaf_page_merge_count + i.singleton_lookup_count
           ) AS [Percent_Update]
       ,scan.Percent_Scan
FROM sys.dm_db_index_operational_stats (db_id(), NULL, NULL, NULL) i
JOIN sys.objects o ON o.object_id = i.object_id
JOIN sys.indexes x ON x.object_id = i.object_id AND x.index_id = i.index_id
CROSS APPLY (SELECT o.name AS [Table_Name], x.name AS [Index_Name],
		   i.partition_number AS [Partition],
		   i.index_id AS [Index_ID], x.type_desc AS [Index_Type],
		   i.range_scan_count * 100.0 /
			   (i.range_scan_count + i.leaf_insert_count
				+ i.leaf_delete_count + i.leaf_update_count
				+ i.leaf_page_merge_count + i.singleton_lookup_count
			   ) AS [Percent_Scan]
	FROM sys.dm_db_index_operational_stats (db_id(), NULL, NULL, NULL) i
	JOIN sys.objects o ON o.object_id = i.object_id
	JOIN sys.indexes x ON x.object_id = i.object_id AND x.index_id = i.index_id
	WHERE (i.range_scan_count + i.leaf_insert_count
		   + i.leaf_delete_count + leaf_update_count
		   + i.leaf_page_merge_count + i.singleton_lookup_count) != 0
	AND objectproperty(i.object_id,'IsUserTable') = 1) scan
WHERE (i.range_scan_count + i.leaf_insert_count
       + i.leaf_delete_count + leaf_update_count
       + i.leaf_page_merge_count + i.singleton_lookup_count) != 0
       AND scan.Table_Name = o.name
       AND scan.Index_Name = x.name
       AND scan.Partition = i.partition_number
AND OBJECTPROPERTY(i.object_id,'IsUserTable') = 1
)

SELECT p.Table_Name,p.Index_Name,p.PartitionNumber,p.Index_Type
		,p.Percent_Update,p.Percent_Scan
		,CASE WHEN (p.percent_scan > p.percent_update AND p.percent_scan > 50) OR p.percent_update < 1
			THEN 'Consider Page Compression'
			ELSE 'Consider Row Compression'
			END AS CompressionToUse
	FROM Presel p
ORDER BY p.percent_update DESC, p.percent_scan DESC;
GO



