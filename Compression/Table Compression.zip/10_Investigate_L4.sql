USE master;
GO

DBCC TRACEON (3604);

GO
DBCC PAGE ('CompressTest',1,60608 ,3);

--OR

DBCC PAGE ('CompressTest',1,404 ,1) with tableresults;





















Declare dbccPageC cursor static for
Select Distinct db_id(DatabaseName), PageFID,PagePID
	From AdminDB.dbo.DBCCInd
	Where isProcessed = 0
	Group By DatabaseName, PageFID,PagePID

Declare @dbid		Int
	,@PageFID	Int
	,@PagePID	BigInt

Open dbccPageC
Fetch next from dbccPageC
Into @dbid,@PageFID,@PagePID;

While @@FETCH_STATUS = 0
Begin
	Truncate Table AdminDB.dbo.DBCCPage

	Insert Into AdminDB.dbo.DBCCPage
	Exec ('dbcc page ('+@dbid+','+ @PageFID +',' + @PagePID + ',1) with tableresults') --this should work for this exercise
