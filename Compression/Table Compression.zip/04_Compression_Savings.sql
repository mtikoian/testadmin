USE AdventureWorks2012;
GO
EXEC sp_estimate_data_compression_savings 'Production', 'WorkOrderRouting', NULL, NULL, 'ROW' ;
GO
EXEC sp_estimate_data_compression_savings 'Production', 'WorkOrderRouting', NULL, NULL, 'Page' ;
GO


SELECT @@version

/* Check compression savings for our tables in CompressTest*/
USE CompressTest;
GO
EXEC sp_estimate_data_compression_savings 'dbo', 'SomeTable', NULL, NULL, 'Page' ;
GO
EXEC sp_estimate_data_compression_savings 'dbo', 'SomeHeap', NULL, NULL, 'Page' ;
GO
EXEC sp_estimate_data_compression_savings 'dbo', 'SomeBLOB', NULL, NULL, 'Page' ;
GO
