--In-Memory Index Demo Script

--Table 1: no indexes except HASH PK
--Table 2: no indexes except Range PK (NONCLUSTERED)
--Table 3:  same as Table 1 except for ColumnStore Clustered Index

--make sure have clean version of AdventureWorks2012Big (this is for demo)
/*
USE [master]
ALTER DATABASE [AdventureWorks2012Big] SET SINGLE_USER WITH ROLLBACK IMMEDIATE
RESTORE DATABASE [AdventureWorks2012Big] FROM  DISK = N'E:\AdventureWorks2012_Big\AdventureWorks2012Big.bak' WITH  FILE = 1,  NOUNLOAD,  REPLACE,  STATS = 20
ALTER DATABASE [AdventureWorks2012Big] SET MULTI_USER
GO
ALTER AUTHORIZATION ON DATABASE::AdventureWorks2012Big TO sa;	--give ownership to sa; not me
GO
USE AdventureWorks2012Big
GO
--00:00:27
IF NOT EXISTS (SELECT * FROM sys.data_spaces WHERE TYPE='FX')
	ALTER DATABASE CURRENT ADD FILEGROUP [AdventureWorks2012Big_mod] 
		CONTAINS MEMORY_OPTIMIZED_DATA;
GO
IF NOT EXISTS (SELECT * 
				FROM sys.data_spaces ds 
				JOIN sys.database_files df 
				  ON ds.data_space_id=df.data_space_id 
				WHERE ds.TYPE='FX')
	ALTER DATABASE CURRENT 
		ADD FILE (name='AdventureWorks2012Big_mod',
				  filename='E:\Database\Data\AdventureWorks2012Big_mod') 
					TO FILEGROUP [AdventureWorks2012Big_mod];
GO
*/


IF OBJECT_ID(N'Sales.SalesOrderDetail_inmem1') IS NOT NULL DROP TABLE Sales.SalesOrderDetail_inmem1
GO
CREATE TABLE [Sales].[SalesOrderDetail_inmem1](
	[SalesOrderID] [int] NOT NULL ,
	[SalesOrderDetailID] [int]  NOT NULL IDENTITY(1,1),					--Identity property not available in first release of SS2014
	[CarrierTrackingNumber] [nvarchar](25) NULL,
	[OrderQty] [smallint] NOT NULL,
	[ProductID] [int] NOT NULL ,
	[SpecialOfferID] [int] NOT NULL,
	[UnitPrice] [money] NOT NULL,
	[UnitPriceDiscount] [money] NOT NULL ,
	[ModifiedDate] [datetime] NOT NULL ,

CONSTRAINT [im1PK_SalesOrderDetail_SalesOrderID_SalesOrderDetailID1] PRIMARY KEY NONCLUSTERED HASH	--Primary key Hash Index
(
[SalesOrderID],
[SalesOrderDetailID]
) WITH (BUCKET_COUNT=8388608)		--bucket count for hashing should be next biggest power of two

) WITH (MEMORY_OPTIMIZED=ON, DURABILITY=SCHEMA_AND_DATA);											--Discuss Schema and Data
GO

IF OBJECT_ID(N'Sales.SalesOrderDetail_inmem2') IS NOT NULL DROP TABLE Sales.SalesOrderDetail_inmem2
GO
CREATE TABLE [Sales].[SalesOrderDetail_inmem2](
	[SalesOrderID] [int] NOT NULL ,
	[SalesOrderDetailID] [int]  NOT NULL IDENTITY(1,1),
	[CarrierTrackingNumber] [nvarchar](25) NULL,
	[OrderQty] [smallint] NOT NULL,
	[ProductID] [int] NOT NULL ,
	[SpecialOfferID] [int] NOT NULL,
	[UnitPrice] [money] NOT NULL,
	[UnitPriceDiscount] [money] NOT NULL ,
	[ModifiedDate] [datetime] NOT NULL ,

CONSTRAINT [im2PK_SalesOrderDetail_SalesOrderID_SalesOrderDetailID1] PRIMARY KEY NONCLUSTERED HASH	--Primary key Range Index
(
[SalesOrderID],
[SalesOrderDetailID]
) WITH (BUCKET_COUNT=5000000)		--bucket count for hashing should be next biggest power of two

) WITH (MEMORY_OPTIMIZED=ON, DURABILITY=SCHEMA_AND_DATA);											--Discuss Schema and Data
GO


SET STATISTICS IO,TIME ON;
SET IDENTITY_INSERT Sales.SalesOrderDetail_inmem1 ON;
GO
INSERT Sales.SalesOrderDetail_inmem1
	(SalesOrderID,SalesOrderDetailID,CarrierTrackingNumber,OrderQty,ProductID,SpecialOfferID,UnitPrice,UnitPriceDiscount,ModifiedDate)
		SELECT SalesOrderID,SalesOrderDetailID,CarrierTrackingNumber,OrderQty,ProductID,SpecialOfferID,UnitPrice,UnitPriceDiscount,ModifiedDate
			FROM Sales.SalesOrderDetailBig			--4,973,997 rows
SET IDENTITY_INSERT Sales.SalesOrderDetail_inmem1 OFF;
GO
PRINT '************'
GO
SET STATISTICS IO,TIME ON;
SET IDENTITY_INSERT Sales.SalesOrderDetail_inmem2 ON;
GO
INSERT Sales.SalesOrderDetail_inmem2
	(SalesOrderID,SalesOrderDetailID,CarrierTrackingNumber,OrderQty,ProductID,SpecialOfferID,UnitPrice,UnitPriceDiscount,ModifiedDate)
		SELECT SalesOrderID,SalesOrderDetailID,CarrierTrackingNumber,OrderQty,ProductID,SpecialOfferID,UnitPrice,UnitPriceDiscount,ModifiedDate
			FROM Sales.SalesOrderDetailBig			--4,973,997 rows
SET IDENTITY_INSERT Sales.SalesOrderDetail_inmem2 OFF;
GO
PRINT '************'
GO

--Let's look at hash indexes and bucket count parameters
SELECT	object_name(hs.object_id) AS 'object name', 
		i.name as 'index name', 
		hs.total_bucket_count,
		hs.empty_bucket_count,
		floor((cast(empty_bucket_count as float)/total_bucket_count) * 100) AS 'empty_bucket_percent',
		hs.avg_chain_length, 
		hs.max_chain_length
	FROM sys.dm_db_xtp_hash_index_stats AS hs 
	JOIN sys.indexes AS i 
	  ON hs.object_id=i.object_id AND hs.index_id=i.index_id
	ORDER BY 1,2;

--so bucket count does round up to next power of 2


--now compare HASH PK to Range PK and ColumnStore
IF OBJECT_ID(N'Sales.SalesOrderDetail_inmem1') IS NOT NULL DROP TABLE Sales.SalesOrderDetail_inmem1
GO
CREATE TABLE [Sales].[SalesOrderDetail_inmem1](
	[SalesOrderID] [int] NOT NULL ,		
	[SalesOrderDetailID] [int]  NOT NULL IDENTITY(1,1),							
	[CarrierTrackingNumber] [nvarchar](25) NULL,
	[OrderQty] [smallint] NOT NULL,
	[ProductID] [int] NOT NULL ,				
	[SpecialOfferID] [int] NOT NULL,
	[UnitPrice] [money] NOT NULL,
	[UnitPriceDiscount] [money] NOT NULL ,
	[ModifiedDate] [datetime] NOT NULL ,

CONSTRAINT [im1PK_SalesOrderDetail_SalesOrderID_SalesOrderDetailID1] PRIMARY KEY NONCLUSTERED HASH	--Primary key Hash Index
(
[SalesOrderID],
[SalesOrderDetailID]
) WITH (BUCKET_COUNT=8388608)		--bucket count for hashing should be next biggest power of two

) WITH (MEMORY_OPTIMIZED=ON, DURABILITY=SCHEMA_AND_DATA);											--Discuss Schema and Data
GO

--create table 2 with Nonclustered Index (not hash)
IF OBJECT_ID(N'Sales.SalesOrderDetail_inmem2') IS NOT NULL DROP TABLE Sales.SalesOrderDetail_inmem2
GO
CREATE TABLE [Sales].[SalesOrderDetail_inmem2](
	[SalesOrderID] [int] NOT NULL ,
	[SalesOrderDetailID] [int]  NOT NULL IDENTITY(1,1),
	[CarrierTrackingNumber] [nvarchar](25) NULL,
	[OrderQty] [smallint] NOT NULL,
	[ProductID] [int] NOT NULL ,
	[SpecialOfferID] [int] NOT NULL,
	[UnitPrice] [money] NOT NULL,
	[UnitPriceDiscount] [money] NOT NULL ,
	[ModifiedDate] [datetime] NOT NULL ,

CONSTRAINT [im2PK_SalesOrderDetail_SalesOrderID_SalesOrderDetailID1] PRIMARY KEY NONCLUSTERED	--Primary key Nonclustered Index
(
[SalesOrderID],
[SalesOrderDetailID]
)

) WITH (MEMORY_OPTIMIZED=ON, DURABILITY=SCHEMA_AND_DATA);											--Discuss Schema and Data
GO

--let's create table 3 same as table 1 but with Clustered ColumnStore index
IF OBJECT_ID(N'Sales.SalesOrderDetail_inmem3') IS NOT NULL DROP TABLE Sales.SalesOrderDetail_inmem3
GO
CREATE TABLE [Sales].[SalesOrderDetail_inmem3](
	[SalesOrderID] [int] NOT NULL ,	
	[SalesOrderDetailID] [int]  NOT NULL IDENTITY(1,1),
	[CarrierTrackingNumber] [nvarchar](25) NULL,
	[OrderQty] [smallint] NOT NULL,
	[ProductID] [int] NOT NULL ,
	[SpecialOfferID] [int] NOT NULL,
	[UnitPrice] [money] NOT NULL,
	[UnitPriceDiscount] [money] NOT NULL ,
	[ModifiedDate] [datetime] NOT NULL ,

CONSTRAINT [im3PK_SalesOrderDetail_SalesOrderID_SalesOrderDetailID1] PRIMARY KEY NONCLUSTERED HASH	--Primary key Hash Index
(
[SalesOrderID],
[SalesOrderDetailID]
) WITH (BUCKET_COUNT=8388608)		--bucket count for hashing should be next biggest power of two

) WITH (MEMORY_OPTIMIZED=ON, DURABILITY=SCHEMA_AND_DATA);											--Discuss Schema and Data
GO

ALTER TABLE [Sales].[SalesOrderDetail_inmem3] ADD INDEX CIX_SalesOrderDetail_inmems3 CLUSTERED COLUMNSTORE;		--add ColumnStore index
GO



SET STATISTICS IO,TIME ON;
SET IDENTITY_INSERT Sales.SalesOrderDetail_inmem1 ON;
GO
INSERT Sales.SalesOrderDetail_inmem1
	(SalesOrderID,SalesOrderDetailID,CarrierTrackingNumber,OrderQty,ProductID,SpecialOfferID,UnitPrice,UnitPriceDiscount,ModifiedDate)
		SELECT SalesOrderID,SalesOrderDetailID,CarrierTrackingNumber,OrderQty,ProductID,SpecialOfferID,UnitPrice,UnitPriceDiscount,ModifiedDate
			FROM Sales.SalesOrderDetailBig			--4,973,997 rows
SET IDENTITY_INSERT Sales.SalesOrderDetail_inmem1 OFF;
GO
PRINT '************'
GO
SET STATISTICS IO,TIME ON;
SET IDENTITY_INSERT Sales.SalesOrderDetail_inmem2 ON;
GO
INSERT Sales.SalesOrderDetail_inmem2
	(SalesOrderID,SalesOrderDetailID,CarrierTrackingNumber,OrderQty,ProductID,SpecialOfferID,UnitPrice,UnitPriceDiscount,ModifiedDate)
		SELECT SalesOrderID,SalesOrderDetailID,CarrierTrackingNumber,OrderQty,ProductID,SpecialOfferID,UnitPrice,UnitPriceDiscount,ModifiedDate
			FROM Sales.SalesOrderDetailBig			--4,973,997 rows
SET IDENTITY_INSERT Sales.SalesOrderDetail_inmem2 OFF;
GO
PRINT '************'
GO
SET IDENTITY_INSERT Sales.SalesOrderDetail_inmem3 ON;
INSERT Sales.SalesOrderDetail_inmem3
	(SalesOrderID,SalesOrderDetailID,CarrierTrackingNumber,OrderQty,ProductID,SpecialOfferID,UnitPrice,UnitPriceDiscount,ModifiedDate)
		SELECT SalesOrderID,SalesOrderDetailID,CarrierTrackingNumber,OrderQty,ProductID,SpecialOfferID,UnitPrice,UnitPriceDiscount,ModifiedDate
			FROM Sales.SalesOrderDetailBig			--4,973,997 rows
SET IDENTITY_INSERT Sales.SalesOrderDetail_inmem3 OFF;
GO
PRINT '************'
GO

--CPU time = 7110 ms,   elapsed time = 7900 ms.  (Hash PK)
--CPU time = 13281 ms,  elapsed time = 14020 ms. (Range PK)
--CPU time = 7063 ms,   elapsed time = 8146 ms.
--is a difference between Hash PK and Range PK (almost factor of 3 in load performance; also more ram needed for range)


--table size script for in-memory tables
SELECT o.name [TABLE], memory_allocated_for_table_kb, memory_used_by_table_kb,memory_allocated_for_indexes_kb,memory_used_by_indexes_kb
	FROM sys.dm_db_xtp_table_memory_stats s
	JOIN sys.objects o
	ON o.object_id = s.object_id
	ORDER BY o.name

--TABLE						memory_allocated_for_table_kb	memory_used_by_table_kb	memory_allocated_for_indexes_kb	memory_used_by_indexes_kb
--SalesOrderDetail_inmem1	449472							447132					65536							65536
--SalesOrderDetail_inmem2	449472							447132					323328							83230
--SalesOrderDetail_inmem3	488640							485992					164992							164864

UPDATE STATISTICS Sales.SalesOrderDetail_inmem1
WITH FULLSCAN, NORECOMPUTE
--   CPU time = 6176 ms,  elapsed time = 2217 ms.
GO
UPDATE STATISTICS Sales.SalesOrderDetail_inmem2
WITH FULLSCAN, NORECOMPUTE
-- CPU time = 3622 ms,  elapsed time = 2026 ms. 
GO
UPDATE STATISTICS Sales.SalesOrderDetail_inmem3
WITH FULLSCAN, NORECOMPUTE
-- CPU time = 1500 ms,  elapsed time = 1501 ms. 
GO

--Let's look at hash indexes and bucket count parameters
SELECT	object_name(hs.object_id) AS 'object name', 
		i.name as 'index name', 
		hs.total_bucket_count,
		hs.empty_bucket_count,
		floor((cast(empty_bucket_count as float)/total_bucket_count) * 100) AS 'empty_bucket_percent',
		hs.avg_chain_length, 
		hs.max_chain_length
	FROM sys.dm_db_xtp_hash_index_stats AS hs 
	JOIN sys.indexes AS i 
	  ON hs.object_id=i.object_id AND hs.index_id=i.index_id
	ORDER BY 1,2;
--only consider first two rows; DMV is giving weird results (rows 3-5) for ColumnStore -- a couple of us in the community think it is an error (and it has been logged with Microsoft)
--object name				index name												total_bucket_count	empty_bucket_count	empty_bucket_percent	avg_chain_length	max_chain_length
--SalesOrderDetail_inmem1	im1PK_SalesOrderDetail_SalesOrderID_SalesOrderDetailID1	8388608				4635545				55						1					8
--SalesOrderDetail_inmem3	im3PK_SalesOrderDetail_SalesOrderID_SalesOrderDetailID3	8388608				4635545				55						1					8


--consider query with only first column of PK in WHERE clause (turn on actual query plan included; CTRL-M)
SELECT *
	FROM Sales.SalesOrderDetail_inmem1
	WHERE SalesOrderID = 1194757
--note table scan

--now try again where 2nd column of PK is included in WHERE clause	
SELECT *
	FROM Sales.SalesOrderDetail_inmem1
	WHERE SalesOrderID = 1194757
	  AND SalesOrderDetailID = 1685657
--note index seek


--now look at updates on 5m rows
SET STATISTICS IO,TIME ON;
GO
UPDATE Sales.SalesOrderDetail_inmem1
	SET UnitPrice = UnitPrice * 1.05;
PRINT '**************';
UPDATE Sales.SalesOrderDetail_inmem2
	SET UnitPrice = UnitPrice * 1.05;
PRINT '**************';
UPDATE Sales.SalesOrderDetail_inmem3
	SET UnitPrice = UnitPrice * 1.05;
GO
SET STATISTICS IO, TIME OFF
GO
--hash:		CPU time = 5407 ms,   elapsed time = 6718 ms.
--range:	CPU time = 5421 ms,   elapsed time = 6805 ms.
--hashcs:	CPU time = 15922 ms,  elapsed time = 17901 ms.	--cs takes longer to update (have to redo entire column)


--Look at another way with join
SET STATISTICS IO,TIME ON;
GO
UPDATE  sod 
	SET UnitPrice = UnitPrice * 1.05
	FROM Sales.SalesOrderDetail_inmem1 sod
	JOIN Production.Product p			--this is disk based table
	  ON p.ProductID = sod.ProductID
	WHERE p.Name = 'HL Mountain Tire'
	;
PRINT '**************';
UPDATE  sod 
	SET UnitPrice = UnitPrice * 1.05
	FROM Sales.SalesOrderDetail_inmem2 sod
	JOIN Production.Product p
	  ON p.ProductID = sod.ProductID
	WHERE p.Name = 'HL Mountain Tire'
	;
PRINT '**************';
UPDATE  sod 
	SET UnitPrice = UnitPrice * 1.05
	FROM Sales.SalesOrderDetail_inmem3 sod
	JOIN Production.Product p
	  ON p.ProductID = sod.ProductID
	WHERE p.Name = 'HL Mountain Tire'
	;
GO
SET STATISTICS IO, TIME OFF
GO
--hash:		CPU time = 734 ms,  elapsed time = 751 ms. 
--range:	CPU time = 657 ms,  elapsed time = 701 ms.
--hashcs:	CPU time = 890 ms,  elapsed time = 913 ms



--These are INTEROP queries
-- Ctrl-M (turn on actual execution plan)
SET STATISTICS IO,TIME ON;
GO
SELECT COUNT(*) FROM Sales.SalesOrderDetail_inmem1
PRINT '**************'
SELECT COUNT(*) FROM Sales.SalesOrderDetail_inmem2
PRINT '**************'
SELECT COUNT(*) FROM Sales.SalesOrderDetail_inmem3
PRINT '**************'
SET STATISTICS IO,TIME OFF;
GO
--hash:		CPU time = 984 ms,  elapsed time = 152 ms.;  query cost = 46%; table scan
--range:	CPU time = 1077 ms,  elapsed time = 172 ms.; query cost = 46%; table scan
--hashcs	CPU time = 0 ms,    elapsed time = 13 ms.;   query cost = 8%;  ColumnStore Index scan


--now look at specific points in PK
SET STATISTICS IO,TIME ON;
GO
SELECT * 
	FROM Sales.SalesOrderDetail_inmem1
	WHERE SalesOrderID IN (51172,51847,53057)
PRINT '**************'
SELECT * 
	FROM Sales.SalesOrderDetail_inmem2
	WHERE SalesOrderID IN (51172,51847,53057)
PRINT '**************'
SELECT * 
	FROM Sales.SalesOrderDetail_inmem3
	WHERE SalesOrderID IN (51172,51847,53057)
GO
SET STATISTICS IO,TIME OFF;
GO
--hash:		CPU time = 2358 ms,  elapsed time = 329 ms.	query cost 87%, table scan (not complete Hash value)
--range:	CPU time = 0 ms,     elapsed time = 113 ms.	query cost 0%, Index Seek
--hashcs:	CPU time = 31 ms,    elapsed time = 44 ms.	query cost 13%, Columnstore Index Scan


--range on Modified Date (right now there is no range index on ModifiedDate)
SET STATISTICS IO,TIME ON;
GO
SELECT * 
	FROM Sales.SalesOrderDetail_inmem1
	WHERE ModifiedDate BETWEEN '7/1/2007' AND '7/31/2007'
PRINT '**************'
SELECT * 
	FROM Sales.SalesOrderDetail_inmem2
	WHERE ModifiedDate BETWEEN '7/1/2007' AND '7/31/2007'
PRINT '**************'
SELECT * 
	FROM Sales.SalesOrderDetail_inmem3
	WHERE ModifiedDate BETWEEN '7/1/2007' AND '7/31/2007'
GO
SET STATISTICS IO,TIME OFF;
GO
--hash:		CPU time = 1891 ms,  elapsed time = 1189 ms.,	query cost 46%, table scan
--range:	CPU time = 1984 ms,  elapsed time = 1080 ms.,	query cost 47%, table scan
--hashcs:	CPU time = 172 ms,   elapsed time = 982 ms.,	query cost 7%, columnstore index scan (clustered)

--now go back and add in hash and range index on modified date

ALTER TABLE Sales.SalesOrderDetail_inmem1 ADD INDEX IX_ModifiedDate HASH (ModifiedDate) WITH (BUCKET_COUNT = 1200);		
ALTER TABLE Sales.SalesOrderDetail_inmem2 ADD INDEX IX_SalesOrderID NONCLUSTERED (ModifiedDate);		
--ALTER TABLE Sales.SalesOrderDetail_inmem3 ADD INDEX IX_SalesOrderID NONCLUSTERED (ModifiedDate);	--The operation 'ALTER TABLE' is not supported with memory optimized tables that have a column store index.

ALTER TABLE [Sales].[SalesOrderDetail_inmem3] DROP INDEX CIX_SalesOrderDetail_inmems3
ALTER TABLE Sales.SalesOrderDetail_inmem3 ADD INDEX IX_SalesOrderID NONCLUSTERED (ModifiedDate);
ALTER TABLE [Sales].[SalesOrderDetail_inmem3] ADD INDEX CIX_SalesOrderDetail_inmems3 CLUSTERED COLUMNSTORE;		--add ColumnStore index
GO


--now go back and rerun same query above
SET STATISTICS IO,TIME ON;
GO
SELECT * 
	FROM Sales.SalesOrderDetail_inmem1
	WHERE ModifiedDate BETWEEN '7/1/2007' AND '7/31/2007'
PRINT '**************'
SELECT * 
	FROM Sales.SalesOrderDetail_inmem2
	WHERE ModifiedDate BETWEEN '7/1/2007' AND '7/31/2007'
PRINT '**************'
SELECT * 
	FROM Sales.SalesOrderDetail_inmem3
	WHERE ModifiedDate BETWEEN '7/1/2007' AND '7/31/2007'
GO
SET STATISTICS IO,TIME OFF;
GO
--hash:		CPU time = 2125 ms,  elapsed time = 1341 ms.; query cost 67% (table scan)
--range:	CPU time = 203 ms,	 elapsed time = 1048 ms.; query cost 23% (Index seek)
--hashcs:	CPU time = 31 ms,    elapsed time = 955 ms.;  query cost 10% (still columnstore index scan)
   

-- so what happens when you try and add more than 8 indexes (don't run, takes too long for demo)
ALTER TABLE Sales.SalesOrderDetail_inmem1 ADD INDEX IX_SalesOrderID (SalesOrderID,SalesOrderDetailID);		--2nd column to reduce duplicates
GO
ALTER TABLE Sales.SalesOrderDetail_inmem1 ADD INDEX IX_CarrierTrackingNumber (CarrierTrackingNumber,SalesOrderDetailID);		--2nd column to reduce duplicates
GO
ALTER TABLE Sales.SalesOrderDetail_inmem1 ADD INDEX IX_ProductID (ProductID,SalesOrderDetailID);		--2nd column to reduce duplicates
GO
ALTER TABLE Sales.SalesOrderDetail_inmem1 ADD INDEX IX_SpecialOfferID (SpecialOfferID,SalesOrderDetailID);		--2nd column to reduce duplicates
GO
ALTER TABLE Sales.SalesOrderDetail_inmem1 ADD INDEX IX_OrderQty (OrderQty,SalesOrderDetailID);		--2nd column to reduce duplicates
GO
ALTER TABLE Sales.SalesOrderDetail_inmem1 ADD INDEX IX_ProductID2(ProductID,SalesOrderID,SalesOrderDetailID);		--2nd column to reduce duplicates
GO
ALTER TABLE Sales.SalesOrderDetail_inmem1 ADD INDEX IX_SpecialOfferID2 (SpecialOfferID,SalesOrderID,SalesOrderDetailID);		--2nd column to reduce duplicates
GO
--Msg 1910, Level 16, State 1, Line 450
--Could not create in-memory index 'IX_SpecialOfferID2' because it exceeds the maximum of 8 allowed per table or view.


IF OBJECT_ID(N'Sales.SalesOrderDetail_inmem1') IS NOT NULL DROP TABLE Sales.SalesOrderDetail_inmem1 -- clean up for next run
IF OBJECT_ID(N'Sales.SalesOrderDetail_inmem2') IS NOT NULL DROP TABLE Sales.SalesOrderDetail_inmem2 -- clean up for next run
IF OBJECT_ID(N'Sales.SalesOrderDetail_inmem3') IS NOT NULL DROP TABLE Sales.SalesOrderDetail_inmem3 -- clean up for next run
GO
