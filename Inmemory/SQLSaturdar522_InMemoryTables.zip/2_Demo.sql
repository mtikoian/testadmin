--� 2016 | ByrdNest Consulting

--make sure have clean version of AdventureWorks2012Big (this is for demo)
/*
USE [master]
ALTER DATABASE [AdventureWorks2012Big] SET SINGLE_USER WITH ROLLBACK IMMEDIATE
RESTORE DATABASE [AdventureWorks2012Big] FROM  DISK = N'E:\AdventureWorks2012_Big\AdventureWorks2012Big.bak' WITH  FILE = 1,  NOUNLOAD,  REPLACE,  STATS = 20
ALTER DATABASE [AdventureWorks2012Big] SET MULTI_USER
GO
ALTER AUTHORIZATION ON DATABASE::AdventureWorks2012Big TO sa;			--give ownership to sa; not me
GO
USE AdventureWorks2012Big
GO
--00:01:39
*/

--Look at SSMS AdventureWorks2012Big properties


--Step #1: Add MEMORY_OPTIMIZED_DATA filegroup to enable in-memory OLTP for your Database:

IF NOT EXISTS (SELECT * FROM sys.data_spaces WHERE TYPE='FX')
ALTER DATABASE CURRENT ADD FILEGROUP [AdventureWorks2012Big_mod] CONTAINS MEMORY_OPTIMIZED_DATA
GO
IF NOT EXISTS (SELECT * 
				FROM sys.data_spaces ds 
				JOIN sys.database_files df 
				  ON ds.data_space_id=df.data_space_id 
				WHERE ds.TYPE='FX')
	ALTER DATABASE CURRENT 
		ADD FILE (name='AdventureWorks2012Big_mod', 
					filename='E:\AdventureWorks2012_Big\AdventureWorks2012Big_mod') 
					TO FILEGROUP [AdventureWorks2012Big_mod]

--relook at SSMS

--Step #2: For memory-optimized tables, automatically map all lower isolation levels (including READ COMMITTED) to SNAPSHOT:

ALTER DATABASE CURRENT SET MEMORY_OPTIMIZED_ELEVATE_TO_SNAPSHOT = ON	--This setting is important when using transactions involving in-memory tables
																		-- and disk-based tables, the so-called "cross-container transactions".  This
																		-- elevates the isolation level for every cross-container transaction with lower
																		-- isolation level (read-committed).

--Step #3: Create your specific Table(s) to be Memory_Optimized:

--Notice the HASH, BUCKET_COUNT and MEMORY_OTIMIZED settings:
IF OBJECT_ID(N'Sales.SalesOrderDetail_inmem') IS NOT NULL DROP TABLE Sales.SalesOrderDetail_inmem
GO
CREATE TABLE [Sales].[SalesOrderDetail_inmem](
	[SalesOrderID] [int] NOT NULL INDEX IX_SalesOrderID HASH WITH (BUCKET_COUNT=4000000),			--Hash index on SalesOrderID
	[SalesOrderDetailID] [int]  NOT NULL IDENTITY(1,1),												--Identity property not available in first release of SS2014
	[CarrierTrackingNumber] [nvarchar](25) NULL,
	[OrderQty] [smallint] NOT NULL,
	[ProductID] [int] NOT NULL INDEX IX_ProductID HASH WITH (BUCKET_COUNT=25000),					--Hash Index on ProductID
	[SpecialOfferID] [int] NOT NULL,
	[UnitPrice] [money] NOT NULL,
	[UnitPriceDiscount] [money] NOT NULL ,
	[ModifiedDate] [datetime] NOT NULL INDEX IX__ModifiedDate NONCLUSTERED,							--NonClustered Index on Modified Date

CONSTRAINT [imPK_SalesOrderDetail_SalesOrderID_SalesOrderDetailID] PRIMARY KEY NONCLUSTERED HASH	--Primary key Hash Index
(
[SalesOrderID],
[SalesOrderDetailID]
) WITH (BUCKET_COUNT=10000000)

) WITH (MEMORY_OPTIMIZED=ON, DURABILITY=SCHEMA_AND_DATA);											--Discuss Schema and Data
GO

--Excellent article on determining correct bucket count at https://msdn.microsoft.com/en-us/library/dn494956(v=sql.120).aspx
--but general guidance is 1-2 times the number of distinct values in the index key.


ALTER TABLE [Sales].[SalesOrderDetail_inmem] ADD INDEX CIX_SalesOrderDetail_inmem CLUSTERED COLUMNSTORE;		--add ColumnStore index
GO

--Step #3 � Update statistics for memory-optimized tables:
UPDATE STATISTICS Sales.SalesOrderDetail_inmem
WITH FULLSCAN, NORECOMPUTE

--Step #4 - Create disk based table (just like MO table)
IF OBJECT_ID(N'Sales.SalesOrderDetail_disk') IS NOT NULL DROP TABLE Sales.SalesOrderDetail_disk;
GO
CREATE TABLE [Sales].[SalesOrderDetail_disk](
	[SalesOrderID] [int] NOT NULL,
	[SalesOrderDetailID] [int]  NOT NULL IDENTITY(1,1),
	[CarrierTrackingNumber] [nvarchar](25) NULL,
	[OrderQty] [smallint] NOT NULL,
	[ProductID] [int] NOT NULL,
	[SpecialOfferID] [int] NOT NULL,
	[UnitPrice] [money] NOT NULL,
	[UnitPriceDiscount] [money] NOT NULL ,
	[ModifiedDate] [datetime] NOT NULL ,
 CONSTRAINT [PK_tTemp] PRIMARY KEY CLUSTERED 
(
	[SalesOrderID] ASC,
	[SalesOrderDetailID] ASC
));

CREATE NONCLUSTERED INDEX IDX_SalesOrder_SalesOrderID ON [Sales].[SalesOrderDetail_disk] (SalesOrderID)
GO
CREATE NONCLUSTERED INDEX IDX_SalesOrder_Product ON [Sales].[SalesOrderDetail_disk] (ProductID)
GO
CREATE NONCLUSTERED INDEX IDX_SalesOrder_ModifiedDate ON [Sales].[SalesOrderDetail_disk] (ModifiedDate)
GO


--turn on Actual Execution Plan ON (CTRL-M)
--Step 4.5:  Let's try a BULK INSERT into each table
--	Have already created text file (tab delimited) from Sales.SalesOrderDetail; inserts 121,317 rows

SET STATISTICS IO,TIME ON;
BULK INSERT Sales.SalesOrderDetail_inmem
FROM 'E:\Temp\SQLSaturday\SQLSaturday461_Austin\SalesOrderDetailTabDelimited.txt'
WITH (	FIELDTERMINATOR = '\t',
		ROWTERMINATOR = '\n' );
PRINT '*****************'
BULK INSERT Sales.SalesOrderDetail_disk
FROM 'E:\Temp\SQLSaturday\SQLSaturday461_Austin\SalesOrderDetailTabDelimited.txt'
WITH (	FIELDTERMINATOR = '\t',
		ROWTERMINATOR = '\n' );
--Table 'SalesOrderDetail_disk'. Scan count 0, logical reads 12468, physical reads 0, read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.
--Table 'Worktable'. Scan count 3, logical reads 264639, physical reads 0, read-ahead reads 1601, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.
GO
SET STATISTICS IO,TIME OFF;
GO

/*
inmem:		CPU time = 328 ms,  elapsed time = 461 ms.
inmemCS:	CPU time = 391 ms,  elapsed time = 483 ms.
disk:		CPU time = 1406 ms,  elapsed time = 3224 ms.
*/

--empty tables for next demo
--SET STATISTICS IO,TIME ON;
DELETE Sales.SalesOrderDetail_inmem;			--look at DELETE performance down a couple more demos
--PRINT '*************';
DELETE Sales.SalesOrderDetail_disk;
--GO
--SET STATISTICS IO,TIME OFF;
GO

--Step 5:
--Let's try a larger insert into each table (485,268 rows)
SET STATISTICS IO,TIME ON;
GO
DECLARE @SalesOrderDetailID	INT = (SELECT TOP 1 SalesOrderDetailID FROM Sales.SalesOrderDetail ORDER BY 1 DESC);
SET IDENTITY_INSERT Sales.SalesOrderDetail_inmem ON;
INSERT Sales.SalesOrderDetail_inmem
	(SalesOrderID,SalesOrderDetailID,CarrierTrackingNumber,OrderQty,ProductID,SpecialOfferID,UnitPrice,UnitPriceDiscount,ModifiedDate)
		SELECT SalesOrderID,SalesOrderDetailID,CarrierTrackingNumber,OrderQty,ProductID,SpecialOfferID,UnitPrice,UnitPriceDiscount,ModifiedDate
			FROM Sales.SalesOrderDetail
		UNION ALL
		SELECT SalesOrderID,SalesOrderDetailID + @SalesOrderDetailID,CarrierTrackingNumber,OrderQty,ProductID,SpecialOfferID,UnitPrice,UnitPriceDiscount,DATEADD(mm,1,ModifiedDate)
			FROM Sales.SalesOrderDetail
		UNION ALL
		SELECT SalesOrderID,SalesOrderDetailID + 2*@SalesOrderDetailID,CarrierTrackingNumber,OrderQty,ProductID,SpecialOfferID,UnitPrice,UnitPriceDiscount,DATEADD(mm,2,ModifiedDate)
			FROM Sales.SalesOrderDetail
		UNION ALL
			SELECT SalesOrderID,SalesOrderDetailID + 3*@SalesOrderDetailID,CarrierTrackingNumber,OrderQty,ProductID,SpecialOfferID,UnitPrice,UnitPriceDiscount,DATEADD(mm,3,ModifiedDate)
		FROM Sales.SalesOrderDetail
SET IDENTITY_INSERT Sales.SalesOrderDetail_inmem OFF;
GO
SET STATISTICS IO,TIME OFF
GO

SET STATISTICS IO,TIME ON;
GO
DECLARE @SalesOrderDetailID	INT = (SELECT TOP 1 SalesOrderDetailID FROM Sales.SalesOrderDetail ORDER BY 1 DESC)
SET IDENTITY_INSERT Sales.SalesOrderDetail_Disk ON;
INSERT Sales.SalesOrderDetail_disk
	(SalesOrderID,SalesOrderDetailID,CarrierTrackingNumber,OrderQty,ProductID,SpecialOfferID,UnitPrice,UnitPriceDiscount,ModifiedDate)
		SELECT SalesOrderID,SalesOrderDetailID,CarrierTrackingNumber,OrderQty,ProductID,SpecialOfferID,UnitPrice,UnitPriceDiscount,ModifiedDate
			FROM Sales.SalesOrderDetail
		UNION ALL
		SELECT SalesOrderID,SalesOrderDetailID + @SalesOrderDetailID,CarrierTrackingNumber,OrderQty,ProductID,SpecialOfferID,UnitPrice,UnitPriceDiscount,DATEADD(mm,1,ModifiedDate)
			FROM Sales.SalesOrderDetail
		UNION ALL
		SELECT SalesOrderID,SalesOrderDetailID + 2*@SalesOrderDetailID,CarrierTrackingNumber,OrderQty,ProductID,SpecialOfferID,UnitPrice,UnitPriceDiscount,DATEADD(mm,2,ModifiedDate)
			FROM Sales.SalesOrderDetail
		UNION ALL
			SELECT SalesOrderID,SalesOrderDetailID + 3*@SalesOrderDetailID,CarrierTrackingNumber,OrderQty,ProductID,SpecialOfferID,UnitPrice,UnitPriceDiscount,DATEADD(mm,3,ModifiedDate)
		FROM Sales.SalesOrderDetail 
SET IDENTITY_INSERT Sales.SalesOrderDetail_Disk OFF;
GO
SET STATISTICS IO,TIME OFF;
GO

/*
inmem:		CPU Time = 1000ms, elapsed time = 1699ms.
inmemCS:	CPU time = 937 ms,  elapsed time = 1733 ms.
disk:		CPU time = 4671 ms,  elapsed time = 5555 ms.
*/


UPDATE STATISTICS Sales.SalesOrderDetail_inmem
WITH FULLSCAN, NORECOMPUTE
--00:00:00

UPDATE STATISTICS Sales.SalesOrderDetail_disk
WITH FULLSCAN, NORECOMPUTE
--00:00:00

--now look at updates
SET STATISTICS IO,TIME ON;
GO
UPDATE Sales.SalesOrderDetail_inmem
	SET UnitPrice = UnitPrice * 1.05;
PRINT '**************';
UPDATE Sales.SalesOrderDetail_Disk
	SET UnitPrice = UnitPrice * 1.05;
GO
SET STATISTICS IO, TIME OFF
GO

/*
inmem:		CPU time = 1047 ms,  elapsed time = 1563 ms.
inmemCS:	CPU time = 1031 ms,  elapsed time = 1641 ms.
disk:		CPU time = 609 ms,   elapsed time = 1401 ms.
*/

--ouch!  Slower???  Query plan???

--now look at deletes
SET STATISTICS IO,TIME ON;
GO
DELETE Sales.SalesOrderDetail_inmem
--00:00:00, CPU time = 172 ms,  elapsed time = 316 ms.

DELETE Sales.SalesOrderDetail_disk
--00:00:05, CPU time = 5375 ms,  elapsed time = 5609 ms.
GO
SET STATISTICS IO,TIME OFF;
GO

/*
inmem:		CPU time = 172 ms,  elapsed time = 316 ms.
inmemCS:	CPU time = 172 ms,  elapsed time = 341 ms.
disk:		CPU time = 5437 ms,  elapsed time = 5590 ms.
*/


--just to make sure I'm not blowing smoke!
select count(*) from Sales.SalesOrderDetail_inmem
select count(*) from Sales.SalesOrderDetail_disk


--reload tables (3,760,827 rows)
SET STATISTICS IO,TIME ON;
GO
SET IDENTITY_INSERT Sales.SalesOrderDetail_inmem ON;
INSERT Sales.SalesOrderDetail_inmem
	(SalesOrderID,SalesOrderDetailID,CarrierTrackingNumber,OrderQty,ProductID,SpecialOfferID,UnitPrice,UnitPriceDiscount,ModifiedDate)
		SELECT SalesOrderID,SalesOrderDetailID,CarrierTrackingNumber,OrderQty,ProductID,SpecialOfferID,UnitPrice,UnitPriceDiscount,ModifiedDate
			FROM Sales.SalesOrderDetailEnlarged			--3,760,827 rows
SET IDENTITY_INSERT Sales.SalesOrderDetail_inmem OFF;
GO
SET IDENTITY_INSERT Sales.SalesOrderDetail_Disk ON;
INSERT Sales.SalesOrderDetail_disk
	(SalesOrderID,SalesOrderDetailID,CarrierTrackingNumber,OrderQty,ProductID,SpecialOfferID,UnitPrice,UnitPriceDiscount,ModifiedDate)
		SELECT SalesOrderID,SalesOrderDetailID,CarrierTrackingNumber,OrderQty,ProductID,SpecialOfferID,UnitPrice,UnitPriceDiscount,ModifiedDate
			FROM Sales.SalesOrderDetailEnlarged
SET IDENTITY_INSERT Sales.SalesOrderDetail_Disk OFF;
SET STATISTICS IO,TIME OFF;
--00:01:40
--look at query cost from two inserts; optimizer does know about memory optimized tables for INSERTS! Also note physical reads on first query
-- notice index inserts in 2nd query plan

/*
inmem:		CPU time = 8,094 ms,   elapsed time = 41,047 ms. (note physical reads and read-aheads)
inmemCS:	CPU time = 8,094 ms,   elapsed time = 41,455 ms.
disk:		CPU time = 37,564 ms,  elapsed time = 58,568 ms.
*/


UPDATE STATISTICS Sales.SalesOrderDetail_inmem
WITH FULLSCAN, NORECOMPUTE
--00:00:03

UPDATE STATISTICS Sales.SalesOrderDetail_Disk
WITH FULLSCAN, NORECOMPUTE
--00:00:03

--you know, sometimes a demo query just doesn't return the performance you think it might.

--These are INTEROP queries
-- Ctrl-M (turn on actual execution plan)
SET STATISTICS IO,TIME ON;
GO
SELECT COUNT(*) FROM [Sales].[SalesOrderDetail_inmem]
PRINT '**************'
SELECT COUNT(*) FROM Sales.SalesOrderDetail_disk
GO
SET STATISTICS IO,TIME OFF;
GO
--note nonclustered index scan on SalesOrderDetail_Disk

/*
inmem:		CPU time = 843 ms,  elapsed time = 113 ms.	(this did a table scan)
inmemCS:	CPU time = 0 ms,  elapsed time = 4 ms.		(columnstore index scan)		--Wow!
disk:		CPU time = 688 ms,  elapsed time = 188 ms.	(nonclustered index scan)
*/


-- ok try one more time with query hint to use PK on disk table (force disk base to use Clustered index (primary key))
CHECKPOINT;
DBCC DROPCLEANBUFFERS;
GO
SET STATISTICS IO,TIME ON;
GO
SELECT COUNT(*) FROM [Sales].[SalesOrderDetail_inmem]
PRINT '**************'
SELECT COUNT(*) FROM Sales.SalesOrderDetail_disk WITH (INDEX(PK_tTemp))
GO
SET STATISTICS IO,TIME OFF;
GO
-- 

/*
inmem:		CPU time = 750 ms,   elapsed time = 110 ms.		(table scan)
inmemCS:	CPU time = 16 ms,    elapsed time = 4 ms.		(columnstore index scan)
disk:		CPU time = 1191 ms,  elapsed time = 5035 ms.	(clustered index scan)
*/


--found a recent article on in-memory tables and it showed great performance when using 
--only a few rows and a range of rows; so will try that (white paper has been removed):



--Look at specific rows
SET STATISTICS IO,TIME ON;
GO
SELECT * 
	FROM [Sales].[SalesOrderDetail_inmem]
	WHERE SalesOrderID IN (51172,51847,53057)
PRINT '**************'
SELECT * 
	FROM Sales.SalesOrderDetail_disk
	WHERE SalesOrderID IN (51172,51847,53057)
GO
SET STATISTICS IO,TIME OFF;
GO

/*
inmem:		CPU time = 0 ms,  elapsed time = 43 ms.
inmemCS:	CPU time = 0 ms,  elapsed time = 68 ms.
disk:		CPU time = 0 ms,  elapsed time = 118 ms.  (logical read, b-tree data retrieval latency??)
*/


SET STATISTICS IO,TIME ON;
GO
SELECT * 
	FROM [Sales].[SalesOrderDetail_inmem]
	WHERE ProductID = 717
PRINT '****************'
SELECT * 
	FROM Sales.SalesOrderDetail_disk
	WHERE ProductID = 717
GO
SET STATISTICS IO,TIME OFF;
GO

/*
inmem:		CPU time = 15 ms,  elapsed time = 121ms.
inmemCS:	CPU time = 31 ms,  elapsed time = 119 ms.
disk:		CPU time = 32 ms,  elapsed time = 518 ms.
*/


--range on Modified Date
SET STATISTICS IO,TIME ON;
GO
SELECT * 
	FROM [Sales].[SalesOrderDetail_inmem]
	WHERE ModifiedDate BETWEEN '7/1/2007' AND '7/31/2007'
--CPU time = 16 ms,  elapsed time = 781 ms.
PRINT '**************'
SELECT * 
	FROM Sales.SalesOrderDetail_disk
	WHERE ModifiedDate BETWEEN '7/1/2007' AND '7/31/2007'
--CPU time = 249 ms,  elapsed time = 839 ms.
GO
SET STATISTICS IO,TIME OFF;
GO

/*
inmem:		CPU time = 16 ms,   elapsed time = 781 ms.
inmemCS:	CPU time = 109 ms,  elapsed time = 815 ms.
disk:		CPU time = 248 ms,  elapsed time = 834 ms.
*/



--review memory optimization advisor for Sales.SalesOrderHeader table
IF OBJECT_ID(N'Sales.SalesOrderHeader_inmem') IS NOT NULL DROP TABLE Sales.SalesOrderHeader_inmem
GO
CREATE TABLE Sales.SalesOrderHeader_inmem(
	SalesOrderID int NOT NULL IDENTITY(1,1),
	RevisionNumber tinyint NOT NULL ,
	OrderDate datetime NOT NULL INDEX IX_OrderDate NONCLUSTERED ,
	DueDate datetime NOT NULL,
	ShipDate datetime NULL,
	[Status] tinyint NOT NULL ,
	OnlineOrderFlag BIT NOT NULL ,
	--SalesOrderNumber  AS (isnull(N'SO'+CONVERT(nvarchar(23),SalesOrderID),N'*** ERROR ***')),
	PurchaseOrderNumber NVARCHAR(25) NULL,
	AccountNumber NVARCHAR(15) NULL,
	CustomerID int NOT NULL  INDEX IX_SOH_CustomerID HASH WITH (BUCKET_COUNT=50000),
	SalesPersonID int NULL ,
	TerritoryID int NULL,
	BillToAddressID int NOT NULL,
	ShipToAddressID int NOT NULL,
	ShipMethodID int NOT NULL,
	CreditCardID int NULL,
	CreditCardApprovalCode varchar(15) NULL,
	CurrencyRateID int NULL,
	SubTotal money NOT NULL ,
	TaxAmt money NOT NULL ,
	Freight money NOT NULL ,
	--TotalDue  AS (isnull((SubTotal+TaxAmt)+Freight,(0))),
	Comment nvarchar(128) NULL,
	--rowguid uniqueidentifier ROWGUIDCOL  NOT NULL INDEX IX_SOH_rowguid HASH WITH (BUCKET_COUNT=10000000),
	ModifiedDate datetime NOT NULL ,
 CONSTRAINT PK_SalesOrderHeader_SalesOrderID_inmem PRIMARY KEY  NONCLUSTERED HASH
	(SalesOrderID) WITH (BUCKET_COUNT=4000000)
) WITH (MEMORY_OPTIMIZED=ON, DURABILITY=SCHEMA_AND_DATA)

GO

SET IDENTITY_INSERT Sales.SalesOrderHeader_inmem ON;
GO
INSERT Sales.SalesOrderHeader_inmem
	(SalesOrderID,RevisionNumber,OrderDate,DueDate,ShipDate,[Status],OnlineOrderFlag,PurchaseOrderNumber,
	 AccountNumber,CustomerID,SalesPersonID,TerritoryID,BillToAddressID,ShipToAddressID,ShipMethodID,
	 CreditCardID,CreditCardApprovalCode,CurrencyRateID,SubTotal,TaxAmt,Freight,Comment,ModifiedDate)
	 SELECT SalesOrderID,RevisionNumber,OrderDate,DueDate,ShipDate,[Status],OnlineOrderFlag,PurchaseOrderNumber,
			AccountNumber,CustomerID,SalesPersonID,TerritoryID,BillToAddressID,ShipToAddressID,ShipMethodID,
			CreditCardID,CreditCardApprovalCode,CurrencyRateID,SubTotal,TaxAmt,Freight,Comment,ModifiedDate
		FROM Sales.SalesOrderHeaderEnlarged;
GO
SET IDENTITY_INSERT Sales.SalesOrderHeader_inmem OFF;
GO

UPDATE STATISTICS Sales.SalesOrderHeader_inmem
WITH FULLSCAN, NORECOMPUTE
--00:00:01


--make sure include actual query plan ON
SET STATISTICS IO,TIME ON;
GO
SELECT soh.SalesOrderID, count(sod.SalesOrderDetailID)
	FROM Sales.SalesOrderHeader_inmem soh
	JOIN Sales.SalesOrderDetail_inmem sod
	  ON sod.SalesOrderID = soh.SalesOrderID
	WHERE soh.OrderDate BETWEEN '7/1/2007' AND '7/31/2007'
	GROUP BY soh.SalesOrderID
PRINT '*****************';
SELECT soh.SalesOrderID, count(sod.SalesOrderDetailID)
	FROM Sales.SalesOrderHeaderEnlarged soh
	JOIN Sales.SalesOrderDetailEnlarged sod
	  ON sod.SalesOrderID = soh.SalesOrderID
	WHERE soh.OrderDate BETWEEN '7/1/2007' AND '7/31/2007'
	GROUP BY soh.SalesOrderID;
GO
SET STATISTICS IO,TIME OFF;
GO

/*
inmem:		CPU time = 16 ms,   elapsed time = 65 ms.
inmemCS:	CPU time = 16 ms,   elapsed time = 110 ms. (only for SalesOrderDetail)
disk:		CPU time = 423 ms,  elapsed time = 3985 ms.
*/

--so inmem wins big here -- thanks to the nonclustered index on OrderDate


--*****************************************
--go to table size script (2b)
--*****************************************



--template code for a in-mem native sproc
IF OBJECT_ID(N'dbo.TestInsert_MOP') IS NOT NULL DROP PROCEDURE dbo.TestInsert_MOP
GO
CREATE PROCEDURE dbo.TestInsert_MOP
	WITH NATIVE_COMPILATION, SCHEMABINDING,EXECUTE AS OWNER
	AS
	BEGIN ATOMIC
		WITH (TRANSACTION ISOLATION LEVEL = SNAPSHOT, LANGUAGE = 'us_english')

		/*  TSQL code here */

	END
GO



--template to catch if there are concurrency issues for DML
--Need some error checking when transaction are not optimistic
CREATE PROCEDURE usp_my_procedure @param1 type1, @param2 type2, ...
AS
BEGIN
  -- number of retries � tune based on the workload
  DECLARE @retry INT = 10

  WHILE (@retry > 0)
  BEGIN
    BEGIN TRY

      -- exec usp_my_native_proc @param1, @param2, ...

      --       or

      -- BEGIN TRANSACTION
      --   �
      -- COMMIT TRANSACTION

      SET @retry = 0
    END TRY
    BEGIN CATCH
      SET @retry -= 1
  
      -- the error number for deadlocks (1205) does not need to be included for 
      -- transactions that do not access disk-based tables
      IF (@retry > 0 AND error_number() in (41302, 41305, 41325, 41301, 1205))
      BEGIN
        -- these error conditions are transaction dooming - rollback the transaction
        -- this is not needed if the transaction spans a single native proc execution
        --   as the native proc will simply rollback when an error is thrown 
        IF XACT_STATE() = -1
          ROLLBACK TRANSACTION

        -- use a delay if there is a high rate of write conflicts (41302)
        --   length of delay should depend on the typical duration of conflicting transactions
        -- WAITFOR DELAY '00:00:00.001'
      END
      ELSE
      BEGIN
        -- insert custom error handling for other error conditions here

        -- throw if this is not a qualifying error condition
        ;THROW
      END
    END CATCH
  END
END



--ok let's go back and try the read query as in-mem native sprocs (don't need error checking as this is not a DML procedure)
IF OBJECT_ID(N'dbo.Test_Inmen') IS NOT NULL DROP PROCEDURE dbo.Test_Inmen
GO
CREATE PROCEDURE dbo.Test_Inmen
	WITH NATIVE_COMPILATION, SCHEMABINDING,EXECUTE AS OWNER
	AS
	BEGIN ATOMIC
		WITH (TRANSACTION ISOLATION LEVEL = SNAPSHOT, LANGUAGE = 'us_english')

		SELECT soh.SalesOrderID, count(sod.SalesOrderDetailID)
			FROM Sales.SalesOrderHeader_inmem soh
			JOIN Sales.SalesOrderDetail_inmem sod
			  ON sod.SalesOrderID = soh.SalesOrderID
			WHERE soh.OrderDate BETWEEN '7/1/2007' AND '7/31/2007'
			GROUP BY soh.SalesOrderID

	END
GO

IF OBJECT_ID(N'dbo.Test_Disk') IS NOT NULL DROP PROCEDURE dbo.Test_Disk
GO
CREATE PROCEDURE dbo.Test_Disk
	AS
		SELECT soh.SalesOrderID, count(sod.SalesOrderDetailID)
			FROM Sales.SalesOrderHeaderEnlarged soh
			JOIN Sales.SalesOrderDetailEnlarged sod
			  ON sod.SalesOrderID = soh.SalesOrderID
			WHERE soh.OrderDate BETWEEN '7/1/2007' AND '7/31/2007'
			GROUP BY soh.SalesOrderID

GO


--Now test MOP and Disk based sprocs
SET STATISTICS IO,TIME ON;
GO
EXEC dbo.Test_Inmen;
PRINT '**************';
EXEC dbo.Test_Disk;
GO
SET STATISTICS IO,TIME OFF;
GO

/*
inmem:		CPU time = 0 ms,  elapsed time = 56 ms.
inmemCS:	CPU time = 15 ms,  elapsed time = 54 ms. (only for SalesOrderDetail)
disk:		CPU time = 140 ms,  elapsed time = 165 ms.
*/
--note:  no execution plan for in-memory sproc