--� 2016 | ByrdNest Consulting

--make sure have clean version of AdventureWorks2012 (this is for demo); also make sure using SSMS 2014
USE [master]
GO
ALTER DATABASE [AdventureWorks2012] SET SINGLE_USER WITH ROLLBACK IMMEDIATE
USE [master]
RESTORE DATABASE [AdventureWorks2012] FROM  DISK = N'E:\AdventureWorks2012_2014\AdventureWorks2012.bak' WITH  FILE = 1,  
	MOVE N'AdventureWorks2012_Data' TO N'E:\AdventureWorks2012_2014\Data\AdventureWorks2012_Data.mdf',  
	MOVE N'AdventureWorks2012_Log' TO N'E:\AdventureWorks2012_2014\Log\AdventureWorks2012_log.ldf',  
	NOUNLOAD,  REPLACE,  STATS = 20;
GO
GO
ALTER DATABASE [AdventureWorks2012] SET MULTI_USER
GO
ALTER AUTHORIZATION ON DATABASE::AdventureWorks2012 TO sa;			--give ownership to sa; not me
GO
--Change Database compatibility to SS2014
ALTER DATABASE [AdventureWorks2012] SET COMPATIBILITY_LEVEL = 120
GO
--00:00:10

--Step 1: enable your database for in-memory OLTP 
/*
We are going to add a filegroup for memory_optimized_data to our database, and add 
a container to this filegroup. This filegroup will be used to guarantee durability 
of memory-resident data in the event of a server crash or restart. During the crash 
recovery phase in server startup, the data is recovered from this filegroup and loaded 
back into memory.

When creating the container in the memory_optimized_data filegroup you must specify the 
storage location. In this example we picked the folder 
'E:\AdventureWorks2012_2014\Data' to store the in-memory data file. 
Make sure the folder exists before running the script. 
*/
USE MASTER
GO
ALTER DATABASE AdventureWorks2012 
	ADD FILEGROUP AdventureWorks2012_mod CONTAINS MEMORY_OPTIMIZED_DATA; 
ALTER DATABASE AdventureWorks2012 
	ADD FILE (name='AdventureWorks2012_mod1'
			, filename='E:\AdventureWorks2012_2014\Data\AdventureWorks2012_mod1') 
			TO FILEGROUP AdventureWorks2012_mod;
GO

--Now go to SSMS, and right click on Sales.SalesOrderHeader and select 'Memory Optimization Advisor'



--Hmmm, "Alle nicht in Ordnung"



--restore AdventureWorks2012 back to "clean" version and compatibility to 2012
USE [master]
GO
ALTER DATABASE [AdventureWorks2012] SET SINGLE_USER WITH ROLLBACK IMMEDIATE
RESTORE DATABASE [AdventureWorks2012] FROM  DISK = N'E:\Backups\Adventureworks2012.bak' WITH  FILE = 1,  
	MOVE N'AdventureWorks2012_Data' TO N'E:\AdventureWorks2012\Data\AdventureWorks2012Data.mdf',  
	MOVE N'AdventureWorks2012_Log' TO N'E:\AdventureWorks2012\Log\AdventureWorks2012Log.ldf',  
	NOUNLOAD,  REPLACE,  STATS = 20;
ALTER DATABASE [AdventureWorks2012] SET MULTI_USER
GO
ALTER AUTHORIZATION ON DATABASE::AdventureWorks2012 TO sa;			--give ownership to sa; not me
GO