--� 2016 | ByrdNest Consulting

USE AdventureWorks2012Big
GO

WITH table_space_usage
( schema_name, table_name, index_name, used, reserved, ind_rows, tbl_rows )
AS (
SELECT s.Name
		,o.Name
		,coalesce(i.Name,'HEAP')
		,p.used_page_count * 8
		,p.reserved_page_count * 8
		,p.row_count
		,case when i.index_id in (0,1) then p.row_count else 0 end
	FROM sys.dm_db_partition_stats p
	JOIN sys.objects as o
	  ON o.object_id = p.object_id
	JOIN sys.schemas as s
	  ON s.schema_id = o.schema_id
	LEFT JOIN sys.indexes as I
	  ON i.object_id = p.object_id and i.index_id = p.index_id
	WHERE o.type_desc = 'USER_TABLE'
	  AND o.is_ms_shipped = 0
)
SELECT ISNULL(t.schema_name,'Total') As Schema_Name
	,ISNULL(t.table_name,char(152)) as Table_Name
	,ISNULL(t.index_name, 'Subtotal') AS Index_Name
	,sum(t.used) as used_in_kb
	,sum(t.reserved) as reserved_in_kb
	,case grouping(t.index_name)
		WHEN 0 THEN sum(t.ind_rows)
		ELSE sum(t.tbl_rows) end as rows
	FROM table_space_usage as t
	WHERE t.schema_name = 'Sales'
	  AND t.table_name IN ('SalesOrderDetail_inmem','SalesOrderDetailEnlarged','SalesOrderHeader_inmem','SalesOrderHeaderEnlarged')
	GROUP BY t.schema_name, t.table_name, t.index_name
	WITH ROLLUP
	ORDER BY grouping(t.schema_name)
			,t.schema_name
			,grouping(t.table_name)
			,t.table_name
			,grouping(t.index_name)
			,t.index_name

--script for in-memory tables
SELECT o.name [TABLE], memory_allocated_for_table_kb, memory_used_by_table_kb,memory_allocated_for_indexes_kb,memory_used_by_indexes_kb
	FROM sys.dm_db_xtp_table_memory_stats s
	JOIN sys.objects o
	ON o.object_id = s.object_id


/*
								TotalReserved(kb)		Rows
	SalesOrderHeaderEnlarged:		304,048				975,415
	SalesOrderHeader_inmem:			245,952				975,415

	SalesOrderDetailEnlarged		720,792				3,760,827
	SalesOrderDetail_inmem			760,560				3,760,827
	SalesOrderDetail_inmemCS		1,220,736			3,760,827
*/



