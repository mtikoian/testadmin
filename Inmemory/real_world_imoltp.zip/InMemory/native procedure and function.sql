


CREATE PROCEDURE [dbo].[PreferredDealerPricesNative]
	@ReordLevel int,
	@Adjustment numeric(8,2),
	@MinCost money
WITH NATIVE_COMPILATION, SCHEMABINDING
AS
BEGIN ATOMIC WITH (TRANSACTION ISOLATION LEVEL = SNAPSHOT, LANGUAGE='us_english')
	
	DECLARE @Count INT

	SELECT @Count = Count(*)
	FROM dbo.ProductLive
	WHERE ReorderPoint >= @ReordLevel AND UnitCost <= @MinCost;

	IF @Count > 50
	BEGIN
	 	SELECT ProductKey, UnitCost, ListPrice, (DealerPrice * (1.0 - @Adjustment)) AS PreferredPrice, Class, Style
		FROM dbo.ProductLive
		WHERE ReorderPoint >= @ReordLevel AND UnitCost <= @MinCost;
	END
	ELSE
	BEGIN
		SELECT 'Not enough products qualify'
	END
	
END

GO


CREATE FUNCTION [dbo].[ColorCodeNative] 
(
	@color varchar(25),
	@prodline char(1)
)
RETURNS char(1)
WITH NATIVE_COMPILATION, SCHEMABINDING
AS
BEGIN ATOMIC WITH
(
	TRANSACTION ISOLATION LEVEL = SNAPSHOT, LANGUAGE = 'us_english'
)

	DECLARE @retval char(1)

	IF @ProdLine='S'
	BEGIN
		IF @color = 'Silver' SET @retval = 'S';
		IF @color = 'Grey' SET @retval = 'G';
		IF @color = 'Red' SET @retval = 'R';
		IF @color = 'Multi' SET @retval = 'V';
		IF @color = 'Black' SET @retval = 'X';
		IF @color = 'Blue' SET @retval = 'B';
		IF @color = 'Yellow' SET @retval = 'Y';
		IF @color = 'White' SET @retval = 'O';
		IF @color = 'NA' SET @retval = '-';
		IF @color = 'Silver/Black' SET @retval = 'X';
    END
	ELSE
	BEGIN
		set @retval = @color
	END
	
	RETURN @retval

END

GO



CREATE FUNCTION [dbo].[ColorCode]
(
	@Color varchar(25),
	@ProdLine varchar(1)
)
RETURNS char(1)
AS
BEGIN

	DECLARE @retval char(1)

	IF @ProdLine='S'
	BEGIN
		IF @color = 'Silver' SET @retval = 'S';
		IF @color = 'Grey' SET @retval = 'G';
		IF @color = 'Red' SET @retval = 'R';
		IF @color = 'Multi' SET @retval = 'V';
		IF @color = 'Black' SET @retval = 'X';
		IF @color = 'Blue' SET @retval = 'B';
		IF @color = 'Yellow' SET @retval = 'Y';
		IF @color = 'White' SET @retval = 'O';
		IF @color = 'NA' SET @retval = '-';
		IF @color = 'Silver/Black' SET @retval = 'X';
    END
	ELSE
	BEGIN
		set @retval = @color
	END

	RETURN @retval;

END

GO




CREATE PROCEDURE [dbo].[PreferredDealerPrices]
	@ReordLevel int,
	@Adjustment numeric(8,2),
	@MinCost money
AS
BEGIN 
	
	DECLARE @Count INT

	SELECT @Count = Count(*)
	FROM dbo.ProductLiveDisk
	WHERE ReorderPoint >= @ReordLevel AND UnitCost <= @MinCost;

	IF @Count > 50
	BEGIN
	 	SELECT ProductKey, UnitCost, ListPrice, (DealerPrice * (1.0 - @Adjustment)) AS PreferredPrice, Class, Style
		FROM dbo.ProductLiveDisk
		WHERE ReorderPoint >= @ReordLevel AND UnitCost <= @MinCost;
	END
	ELSE
	BEGIN
		SELECT 'Not enough products qualify'
	END
	
END

GO
