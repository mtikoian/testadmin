/* Template to create a filegroup and add a file */
USE AdventureWorksDW2012;
GO

ALTER DATABASE AdventureWorksDW2012 
ADD FILEGROUP InMemFG CONTAINS MEMORY_OPTIMIZED_DATA    
GO

ALTER DATABASE AdventureWorksDW2012 
ADD FILE
(NAME = InMemFile,      
 FILENAME = 
 'D:\Demos\SQLDATA\AW12MemFile.mdf') 
TO FILEGROUP InMemFG
GO    