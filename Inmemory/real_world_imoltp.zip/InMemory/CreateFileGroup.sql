/* Template to create a filegroup and add a file */
USE AdventureWorksDW2012;
GO

ALTER DATABASE AdventureWorksDW2012 
ADD FILEGROUP InMemFG               


ALTER DATABASE AdventureWorksDW2012 
ADD FILE
(NAME = InMemFile,      
 FILENAME = 
 'C:\Program Files\Microsoft SQL Server\MSSQL12.SQLJUDO\MSSQL\DATA\AW12MemFile.mdf') 
TO FILEGROUP InMemFG    