/* create memory optimized table for large scale row insert */
CREATE TABLE [dbo].[InsertTestMem]
(
[InsertKey] [int] NOT NULL,
[InsertVal] [varchar](25) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
CONSTRAINT [pk_InsertMem] PRIMARY KEY NONCLUSTERED 
(
[InsertKey] ASC
)
)WITH ( MEMORY_OPTIMIZED = ON , DURABILITY = SCHEMA_ONLY )
GO
/* create disk based table for large scale row insert */
CREATE TABLE [dbo].[InsertTestDisk](
[InsertKey] [int] NOT NULL,
[InsertVal] [varchar](25) NULL,
CONSTRAINT [pk_InsertDisk] PRIMARY KEY NONCLUSTERED 
(
[InsertKey] ASC
))
GO
/* create disk based table for set based insert test */
CREATE TABLE [dbo].[SelectIntoTest](
[InsertKey] [int] NOT NULL,
[InsertVal] [varchar](25) NULL,
CONSTRAINT [pk_InsertDisk2] PRIMARY KEY NONCLUSTERED 
(
[InsertKey] ASC
))
GO
/* create memory optimized table for large scale row insert with durability */
CREATE TABLE [dbo].[InsertTestMemD]
(
[InsertKey] [int] NOT NULL,
[InsertVal] [varchar](25) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
CONSTRAINT [pk_InsertMemD] PRIMARY KEY NONCLUSTERED 
(
[InsertKey] ASC
)
)WITH ( MEMORY_OPTIMIZED = ON , DURABILITY = SCHEMA_AND_DATA )
GO
  
