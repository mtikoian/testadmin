
/* sample code to create filegroup and logical file */

USE Abacos_MachineData
GO

ALTER DATABASE Abacos_MachineData
ADD FILEGROUP AWMemGroup CONTAINS MEMORY_OPTIMIZED_DATA
GO

ALTER DATABASE Abacos_MachineData
ADD FILE
( NAME = AWMemFile,
FILENAME = N'D:\Demos\SQLDATA\AWMemGroup')
TO FILEGROUP AWMemGroup
GO
  
