
DELETE InsertTestMem
TRUNCATE TABLE InsertTestDisk
TRUNCATE TABLE SelectIntoTest
GO

/* test 10,000 inserts into a non durable memory table */

DBCC DROPCLEANBUFFERS
GO

DECLARE @start DATETIME = GETDATE();
DECLARE @count INT = 1;

WHILE @count < 10000
BEGIN

  INSERT INTO InsertTestMem VALUES 
	(@count, 'stuff');

  SET @count = @count + 1;

END

SELECT DATEDIFF(s, @start, GETDATE()) AS [Memory Insert]
GO

/* compare 10,000 inserts into a disk based table */

DBCC DROPCLEANBUFFERS
GO

DECLARE @start DATETIME = GETDATE();
DECLARE @count INT = 1;

WHILE @count < 10000
BEGIN

  INSERT INTO InsertTestDisk VALUES 
	(@count, 'stuff');

  SET @count = @count + 1;

END

SELECT DATEDIFF(s, @start, GETDATE()) AS [Disk Insert]
GO

/* redo test with a 20,000 row insert from a set based statement into memory table */

DBCC DROPCLEANBUFFERS
GO
DELETE InsertTestMem
GO

DECLARE @start DATETIME = GETDATE();

  INSERT INTO InsertTestMem 
	SELECT InsertKey, InsertVal FROM InsertTestDisk
	UNION ALL
    SELECT insertKey+100000, InsertVal FROM InsertTestDisk

SELECT DATEDIFF(ms, @start, GETDATE()) AS [Set Based Memory Insert (ms)]
GO

/* compare disk based 200,000 row insert from set based statement */


DBCC DROPCLEANBUFFERS
GO
TRUNCATE TABLE SelectIntoTest
GO

DECLARE @start DATETIME = GETDATE();

  INSERT INTO SelectIntoTest 
	SELECT InsertKey, InsertVal FROM InsertTestDisk
	UNION ALL
    SELECT insertKey+100000, InsertVal FROM InsertTestDisk

SELECT DATEDIFF(ms, @start, GETDATE()) AS [Set Based Disk Insert (ms)]
GO