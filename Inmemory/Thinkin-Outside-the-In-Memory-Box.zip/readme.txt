Thank you very much for attending!

Scrips and demo applications are are included to companion materials of "Expert SQL Server In-Memory OLTP" book.

They are available for download from http://aboutsqlserver.com/publications page.

Please do not hesitate to contact me if you have any questions.

Sincerely,
Dmitri
dk@aboutsqlserver.com