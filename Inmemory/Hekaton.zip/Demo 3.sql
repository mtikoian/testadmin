
-- final demo3

USE Test
GO

DROP PROCEDURE test
DROP PROCEDURE test2
DROP TABLE TransactionHistoryArchive

CREATE TABLE TransactionHistoryArchive (
TransactionID int NOT NULL PRIMARY KEY NONCLUSTERED HASH WITH
(BUCKET_COUNT = 100000),
ProductID int NOT NULL,
ReferenceOrderID int NOT NULL,
ReferenceOrderLineID int NOT NULL,
TransactionDate datetime NOT NULL,
TransactionType nchar(1) NOT NULL,
Quantity int NOT NULL,
ActualCost money NOT NULL,
ModifiedDate datetime NOT NULL,
INDEX IX_ProductID NONCLUSTERED (ProductID)
) WITH (MEMORY_OPTIMIZED = ON)

-- indexes are created with the table and the table is empty
-- statistics need to be updated after data is loaded
SELECT * FROM sys.stats
WHERE object_id = OBJECT_ID('TransactionHistoryArchive')

DBCC SHOW_STATISTICS(TransactionHistoryArchive, IX_ProductID)
DBCC SHOW_STATISTICS(TransactionHistoryArchive, PK__Transact__55433A4A09C999E8)

DROP TABLE #temp
GO
SELECT * INTO #temp
FROM AdventureWorks2012.Production.TransactionHistoryArchive
GO
INSERT INTO TransactionHistoryArchive
SELECT * FROM #temp

-- no automatic update of statistics
UPDATE STATISTICS dbo.TransactionHistoryArchive WITH FULLSCAN, NORECOMPUTE
UPDATE STATISTICS dbo.TransactionHistoryArchive IX_ProductID WITH FULLSCAN, NORECOMPUTE

CREATE PROCEDURE test
WITH NATIVE_COMPILATION, 
SCHEMABINDING, 
EXECUTE AS OWNER
AS
BEGIN ATOMIC WITH (
TRANSACTION ISOLATION LEVEL = SNAPSHOT,
LANGUAGE = 'us_english')
SELECT TransactionID, ProductID, ReferenceOrderID
FROM dbo.TransactionHistoryArchive
WHERE ProductID = 780
END

-- show plan 
SET SHOWPLAN_XML ON
GO
EXEC test
GO
SET SHOWPLAN_XML OFF
GO

EXEC test

-- auto-create statistics works
SELECT * FROM sys.stats
WHERE object_id = OBJECT_ID('TransactionHistoryArchive')

SELECT TransactionID, ProductID, ReferenceOrderID
FROM dbo.TransactionHistoryArchive
WHERE Quantity = 780

DBCC SHOW_STATISTICS(TransactionHistoryArchive, _WA_Sys_00000007_21B6055D)

-- natively compiled stored procedures must be schema bound
-- you can't change the schema and make the plan invalid
DROP TABLE TransactionHistoryArchive

-- operators demo
USE Test
GO

DROP PROCEDURE test
DROP TABLE TransactionHistoryArchive

-- show operators
CREATE TABLE TransactionHistoryArchive (
TransactionID int NOT NULL PRIMARY KEY NONCLUSTERED HASH WITH
(BUCKET_COUNT = 2000000) IDENTITY(1,1),
ProductID int NOT NULL,
ReferenceOrderID int NOT NULL,
ReferenceOrderLineID int NOT NULL,
TransactionDate datetime NOT NULL,
TransactionType nchar(1) NOT NULL,
Quantity int NOT NULL,
ActualCost money NOT NULL,
ModifiedDate datetime NOT NULL
) WITH (MEMORY_OPTIMIZED = ON)

DROP TABLE #temp
GO
SELECT * INTO #temp
FROM AdventureWorks2012.Production.TransactionHistoryArchive
GO

INSERT INTO TransactionHistoryArchive
SELECT ProductID, ReferenceOrderID, ReferenceOrderLineID, TransactionDate, TransactionType,
	Quantity, ActualCost, ModifiedDate
FROM #temp
GO 11
-- 3 seconds

SELECT COUNT(*) FROM TransactionHistoryArchive

DROP TABLE TransactionHistoryArchive2

SELECT * INTO TransactionHistoryArchive2
FROM TransactionHistoryArchive

CREATE CLUSTERED INDEX IX_TransactionID ON TransactionHistoryArchive2(TransactionID)

-- T-SQL disk table
SELECT t1.ProductID
FROM TransactionHistoryArchive2 t1 JOIN TransactionHistoryArchive2 t2
ON t1.TransactionID = t2.TransactionID

-- memory table
CREATE PROCEDURE test
WITH NATIVE_COMPILATION, 
SCHEMABINDING, 
EXECUTE AS OWNER
AS
BEGIN ATOMIC WITH (
TRANSACTION ISOLATION LEVEL = SNAPSHOT,
LANGUAGE = 'us_english')
SELECT t1.ProductID
FROM dbo.TransactionHistoryArchive t1 JOIN dbo.TransactionHistoryArchive t2
ON t1.TransactionID = t2.TransactionID 
--OPTION (HASH JOIN)
END

SET SHOWPLAN_XML ON
GO
EXEC test
GO
SET SHOWPLAN_XML OFF
GO
EXEC test

DROP PROCEDURE test

-- no parameter sniffing
CREATE PROCEDURE test (@pid int)
WITH NATIVE_COMPILATION, 
SCHEMABINDING, 
EXECUTE AS OWNER
AS
BEGIN ATOMIC WITH (
TRANSACTION ISOLATION LEVEL = SNAPSHOT,
LANGUAGE = 'us_english')
SELECT TransactionID, ProductID, ReferenceOrderID
FROM dbo.TransactionHistoryArchive
WHERE ProductID = @pid
END

CREATE PROCEDURE test2 (@pid int)
WITH NATIVE_COMPILATION, 
SCHEMABINDING, 
EXECUTE AS OWNER
AS
BEGIN ATOMIC WITH (
TRANSACTION ISOLATION LEVEL = SNAPSHOT,
LANGUAGE = 'us_english')
SELECT TransactionID, ProductID, ReferenceOrderID
FROM dbo.TransactionHistoryArchive
WHERE ProductID = @pid
OPTION (OPTIMIZE FOR (@pid = 898))
END

EXEC test @pid = 898
EXEC test2 @pid = 870

-- show file system and files
SELECT name, description FROM sys.dm_os_loaded_modules
where description = 'XTP Native DLL'

DROP PROCEDURE test
DROP PROCEDURE test2
DROP TABLE TransactionHistoryArchive

-- extra, if time allows 
-- troubleshooting procedures

EXEC test

SELECT * FROM sys.dm_exec_procedure_stats 
WHERE object_id = OBJECT_ID('test')

EXEC [sys].[sp_xtp_control_proc_exec_stats] @new_collection_value = 1

-- run again
SELECT * FROM sys.dm_exec_procedure_stats 

EXEC [sys].[sp_xtp_control_proc_exec_stats] @new_collection_value = 0

-- troubleshooting queries

DBCC FREEPROCACHE
SELECT * FROM sys.dm_exec_query_stats
CROSS APPLY sys.dm_exec_sql_text(sql_handle)

EXEC [sys].[sp_xtp_control_query_exec_stats] @new_collection_value = 1

EXEC test

-- run again
SELECT * FROM sys.dm_exec_query_stats
CROSS APPLY sys.dm_exec_sql_text(sql_handle)

EXEC [sys].[sp_xtp_control_query_exec_stats] @new_collection_value = 0

