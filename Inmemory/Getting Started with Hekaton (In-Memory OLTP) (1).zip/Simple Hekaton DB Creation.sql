/*
Create and In-Memory OLTP database
Any database that will contain memory-optimized tables needs to have at 
least one MEMORY_OPTIMIZED_DATA filegroup

Currently indexes on memory-optimized tables can only be on columns 
using a Windows (non-SQL) BIN2 collation
*/
CREATE DATABASE HKDB 
	ON 
	PRIMARY(NAME = [HKDB_data], 
		FILENAME = 'C:\data\HKDB_data.mdf', size=50MB), 
	FILEGROUP [SampleDB_mod_fg] CONTAINS MEMORY_OPTIMIZED_DATA 
		(NAME = [HKDB_mod_dir], 
		FILENAME = 'C:\data\HKDB_mod_dir') 
	LOG ON (name = [SampleDB_log], Filename='C:\log\HKDB_log.ldf', size=5MB) 
	COLLATE Latin1_General_100_BIN2;


/*
Adding In-Memory OLTP to an existing database
*/
ALTER DATABASE AdventureWorks2012 
	ADD FILEGROUP hk_mod CONTAINS MEMORY_OPTIMIZED_DATA; 
GO 
ALTER DATABASE AdventureWorks2012 
	ADD FILE (NAME='hk_mod', FILENAME='c:\data\hk_mod') 
	TO FILEGROUP hk_mod; 
GO


/*
Table & SP Creation
MEMORY_OPTIMIZED = ON is required 
*/
-- Data & Schema Durability
-- Data will be PERSISTED
USE HKDB
GO
CREATE TABLE T1 
( 
	[Name] varchar(32) not null PRIMARY KEY NONCLUSTERED HASH WITH (BUCKET_COUNT = 100000), 
	[City] varchar(32) null, 
	[State] varchar(32) null, 
	[LastModified] datetime not null,
) WITH (MEMORY_OPTIMIZED = ON, DURABILITY = SCHEMA_AND_DATA);


-- Schema Durability
-- Data will be lost
CREATE TABLE T2 
( 
	[Name] varchar(32) not null PRIMARY KEY NONCLUSTERED HASH WITH (BUCKET_COUNT = 100000), 
	[City] varchar(32) not null, 
	[State] varchar(32) not null, 
	[LastModified] datetime not null, 
	INDEX T1_ndx_c2c3 NONCLUSTERED ([City],[State]) 
) WITH (MEMORY_OPTIMIZED = ON, DURABILITY = SCHEMA_ONLY);


-- Insert some data
INSERT T1 VALUES('Brian', 'Cleveland', 'OH', SYSDATETIME())
INSERT T1 VALUES('Allen', 'Cleveland', 'OH', SYSDATETIME())
INSERT T1 VALUES('Joe', 'Detroit', 'MI', SYSDATETIME())
INSERT T2 VALUES('Brian', 'Cleveland', 'OH', SYSDATETIME())
INSERT T2 VALUES('Allen', 'Cleveland', 'OH', SYSDATETIME())
INSERT T2 VALUES('Joe', 'Detroit', 'MI', SYSDATETIME())

-- Look at data
SELECT * FROM T1
GO

/*
Isolation hint is required for memory-optimized tables 
with SELECT/UPDATE/DELETE statements in explicit transactions
*/
BEGIN TRAN
	UPDATE T1 WITH (SNAPSHOT) SET [State] = 'MI' WHERE Name = 'Brian'
	UPDATE T1 WITH (SNAPSHOT) SET [State] = 'OH' WHERE Name = 'Joe'
COMMIT
GO

-- Look at data
SELECT * FROM T1
GO

-- Natively compiled SP
CREATE PROCEDURE dbo.usp_UpdateModified @Name VARCHAR(32)
WITH NATIVE_COMPILATION, SCHEMABINDING, EXECUTE AS OWNER
AS
BEGIN ATOMIC
WITH (TRANSACTION ISOLATION LEVEL = SNAPSHOT, LANGUAGE = N'us_english')
	UPDATE dbo.T1 SET LastModified = SYSDATETIME() WHERE Name = @Name
END
GO


-- Call Natively Compiled SP
EXEC usp_UpdateModified 'Brian'
GO

-- Verify Change
SELECT * FROM T1 WHERE Name = 'Brian'




/*
View Source Code
C:\Data\xtp\<<DB ID>>\
*/
SELECT DB_ID('HKDB') AS 'DB ID'
	, DB_NAME(DB_ID('HKDB')) AS 'DB Name'
	, SUBSTRING(physical_name, 0, LEN(physical_name) 
		- CHARINDEX('\', REVERSE(physical_name)) + 2) 
		+ 'xtp\' + LTRIM(STR(DB_ID('HKDB'))) 
		+ '\' AS 'Source Path'
	FROM HKDB.sys.database_files
	WHERE type = 2

/*
Name & Path of Loaded Modules
*/
SELECT o.Name AS 'Obj Name', Object_ID, Type_Desc, m.Name AS 'Mod Name'
FROM sys.all_objects o
JOIN sys.dm_os_loaded_modules m ON o.object_id = LEFT(RIGHT(m.name, CHARINDEX('_', REVERSE(m.name)) - 1), LEN(RIGHT(m.name, CHARINDEX('_', REVERSE(m.name)) - 1)) - 4)
WHERE is_ms_shipped = 0 AND type IN ('U', 'P') AND m.description = 'XTP Native DLL'
