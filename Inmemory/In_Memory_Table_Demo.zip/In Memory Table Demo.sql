
--<<< Demo and Compare Memory-Optimized Table Variables. >>>--

--Create creates a traditional table variable based on the above-mentioned table type, 
--inserts two rows and then deletes them. 
--When you execute the following in SQL Server management studio, EACH batch is repeated 1,000,000 times:

--<<< Set Up Working Environment >>>--

SET NOCOUNT ON;
GO

CREATE DATABASE MO_Table_Demo;
GO

USE MO_Table_Demo;

--<<<  [STOP]  >>>--

-- < Memory-Optimized Tables REQUIRE a separate FILEGROUP (Filestream) >--
ALTER DATABASE MO_Table_Demo
   ADD FILEGROUP [MO_Data] 
      CONTAINS MEMORY_OPTIMIZED_DATA;

--< Memory-Optimized Tables REQUIRE a separate data file >--
DECLARE @SQL nvarchar(max) = 
   N'ALTER DATABASE MO_Table_Demo
        ADD FILE ( name=''MO_Table_Demo1'', 
                   filename=' + QUOTENAME(cast(SERVERPROPERTY('InstanceDefaultDataPath') as nvarchar(max)) + db_name() + N'.mod', N'''') + ') 
           TO FILEGROUP [MO_Data];'
EXECUTE sp_executesql @SQL;

--<<<  [STOP]  >>>--

--<<< CREATE Memory-Optimized Table TYPE >>>--

-- < Without Index >--
CREATE TYPE dbo.TYPE_MemoryOptimizedTable AS TABLE
   (  Col1 int NOT NULL 
    , Col2 char(10) )
   WITH (MEMORY_OPTIMIZED = ON );
GO

--<<<  [STOP]  >>>--

-- < With PRIMARY KEY >--
CREATE TYPE dbo.TYPE_MemoryOptimizedTable AS TABLE
   (  Col1 int NOT NULL PRIMARY KEY
    , Col2 char(10) )
   WITH (MEMORY_OPTIMIZED = ON );
GO


--<<<  [STOP]  >>>--

-- < NC PRIMARY KEY >--
CREATE TYPE dbo.TYPE_MemoryOptimizedTable AS TABLE
   (  Col1 int NOT NULL PRIMARY KEY NONCLUSTERED
    , Col2 char(10) )
   WITH (MEMORY_OPTIMIZED = ON );
GO

-- < INDEX >--
CREATE TYPE dbo.TYPE_MemoryOptimizedTable_2 AS TABLE
   (  Col1 int NOT NULL INDEX ix_c1
    , Col2 char(10) )
   WITH (MEMORY_OPTIMIZED = ON );
GO

-- < IDENTITY, NC PRIMARY KEY >--
CREATE TYPE dbo.TYPE_MemoryOptimizedTable_3 AS TABLE
   (  Col1 int IDENTITY PRIMARY KEY NONCLUSTERED
    , Col2 char(10) )
   WITH (MEMORY_OPTIMIZED = ON );
GO

--<<< End Set Up >>>--

--<<<  [STOP]  >>>--

--<<< Using NC Primary Key with Memory-Optimized Table Variables >>>--

   -->> Test starts here
   DECLARE @TableVariable_MemoryOptimized dbo.TYPE_MemoryOptimizedTable;

   INSERT @TableVariable_MemoryOptimized VALUES ( 1, 'one' );
   INSERT @TableVariable_MemoryOptimized VALUES ( 2, 'two' );
   --<< Test Ends here

--<<<  [STOP]  >>>--

--<<< Using NC INDEX with Memory-Optimized Table Variables >>>--

   -->> Test starts here
   DECLARE @TableVariable_MemoryOptimized_2 dbo.TYPE_MemoryOptimizedTable_2;

   INSERT @TableVariable_MemoryOptimized_2 VALUES ( 1, 'one' );
   INSERT @TableVariable_MemoryOptimized_2 VALUES ( 2, 'two' );
   --<< Test Ends here

--<<<  [STOP]  >>>--

--<<< Using IDENTITY, NC PRIMARY KEY with Memory-Optimized Table Variables >>>--

   -->> Test starts here
   DECLARE @TableVariable_MemoryOptimized_3 dbo.TYPE_MemoryOptimizedTable_3;

   INSERT @TableVariable_MemoryOptimized_3 VALUES ( 'one' );
   INSERT @TableVariable_MemoryOptimized_3 VALUES ( 'two' );
   --<< Test Ends here

--<<<  [STOP]  >>>--

--<<< Extended Test Starts Here >>>--
--<<< Click on [Inclucde Execution Plan] >>>--

 PRINT ''
 PRINT '--<<< This is a test of 1,000,000 INSERT and 100,000 DELETE operations >>>--'
 PRINT '--<<< The Following is INSERT and DELETE. >>>--'
 PRINT ''

--<<< Using #TEMP table >>>--

DECLARE 
   @Counter1 int = 0
 , @RowId1 int = 1
 , @Started1 datetime2 = sysdatetime();

CREATE TABLE #TempTable1
   (  Col1 int NOT NULL PRIMARY KEY NONCLUSTERED
    , Col2 char(10) );

-->> Loop starts here
WHILE @Counter1 < 100000
   BEGIN

      INSERT #TempTable1 VALUES ( (@RowId1), 'one' );
      INSERT #TempTable1 VALUES ( (@RowId1 + 1), 'two' );
      INSERT #TempTable1 VALUES ( (@RowId1 + 2), 'three' );
      INSERT #TempTable1 VALUES ( (@RowId1 + 3), 'four' );
      INSERT #TempTable1 VALUES ( (@RowId1 + 4), 'five' );
      INSERT #TempTable1 VALUES ( (@RowId1 + 5), 'six' );
      INSERT #TempTable1 VALUES ( (@RowId1 + 6), 'seven' );
      INSERT #TempTable1 VALUES ( (@RowId1 + 7), 'eight' );
      INSERT #TempTable1 VALUES ( (@RowId1 + 8), 'nine' );
      INSERT #TempTable1 VALUES ( (@RowId1 + 9), 'ten' );

      DELETE FROM #TempTable1;
      SELECT 
         @Counter1 += 1
       , @RowId1 += 10
   END
--<< Loop Ends here

PRINT '   #Temp Table Elapsed Time = ' + CAST(DATEDIFF(MS, @Started1, sysdatetime()) AS varchar(10)) + ' milliseconds.';

--<<< Using Table Variable >>>--

DECLARE 
   @Counter2 int = 0
 , @RowId2 int = 1
 , @Started2 datetime2 = sysdatetime();

DECLARE @TableVariable1 table
   (  Col1 int NOT NULL PRIMARY KEY NONCLUSTERED
    , Col2 char(10) );

-->> Loop starts here
WHILE @Counter2 < 100000
   BEGIN
      INSERT @TableVariable1 VALUES ( (@RowId2), 'one' );
      INSERT @TableVariable1 VALUES ( (@RowId2 + 1), 'two' );
      INSERT @TableVariable1 VALUES ( (@RowId2 + 2), 'three' );
      INSERT @TableVariable1 VALUES ( (@RowId2 + 3), 'four' );
      INSERT @TableVariable1 VALUES ( (@RowId2 + 4), 'five' );
      INSERT @TableVariable1 VALUES ( (@RowId2 + 5), 'six' );
      INSERT @TableVariable1 VALUES ( (@RowId2 + 6), 'seven' );
      INSERT @TableVariable1 VALUES ( (@RowId2 + 7), 'eight' );
      INSERT @TableVariable1 VALUES ( (@RowId2 + 8), 'nine' );
      INSERT @TableVariable1 VALUES ( (@RowId2 + 9), 'ten' );

      DELETE FROM @TableVariable1;
      SELECT 
         @Counter2 += 1
       , @RowId2 += 10
   END
--<< Loop Ends here

PRINT '   Table Variable Elapsed Time = ' + CAST(DATEDIFF(MS, @Started2, sysdatetime()) AS varchar(10)) + ' milliseconds.';

--<<< Using Memory-Optimized Table Variable >>>--

DECLARE 
   @Counter3 int = 0
 , @RowId3 int = 1
 , @Started3 datetime2 = sysdatetime();

-->> Loop starts here
DECLARE @TableVariable_MemoryOptimized_1 dbo.TYPE_MemoryOptimizedTable;

WHILE @Counter3 < 100000
   BEGIN
      INSERT @TableVariable_MemoryOptimized_1 VALUES ( (@RowId3), 'one' );
      INSERT @TableVariable_MemoryOptimized_1 VALUES ( (@RowId3 + 1), 'two' );
      INSERT @TableVariable_MemoryOptimized_1 VALUES ( (@RowId3 + 2), 'three' );
      INSERT @TableVariable_MemoryOptimized_1 VALUES ( (@RowId3 + 3), 'four' );
      INSERT @TableVariable_MemoryOptimized_1 VALUES ( (@RowId3 + 4), 'five' );
      INSERT @TableVariable_MemoryOptimized_1 VALUES ( (@RowId3 + 5), 'six' );
      INSERT @TableVariable_MemoryOptimized_1 VALUES ( (@RowId3 + 6), 'seven' );
      INSERT @TableVariable_MemoryOptimized_1 VALUES ( (@RowId3 + 7), 'eight' );
      INSERT @TableVariable_MemoryOptimized_1 VALUES ( (@RowId3 + 8), 'nine' );
      INSERT @TableVariable_MemoryOptimized_1 VALUES ( (@RowId3 + 9), 'ten' );

      DELETE  FROM @TableVariable_MemoryOptimized_1;
      SELECT 
         @Counter3 += 1
       , @RowId3 += 10
   END
 --<< Loop Ends here

 PRINT '   Memory Optimized Table Elapsed Time = ' + CAST(DATEDIFF(MS, @Started3, sysdatetime()) AS varchar(10)) + ' milliseconds.';

 PRINT ''
 PRINT '--<<< This is a test of 1,000,000 INSERT operations (NO DELETEs >>>--'
 PRINT '--<<< The Following is INSERT ONLY >>>--'
 PRINT ''

 --<<< Using #TEMP table -WITHOUT DELETE >>>--

DECLARE 
   @Counter4 int = 0
 , @RowId4 int = 1
 , @Started4 datetime2 = sysdatetime();

CREATE TABLE #TempTable2
   (  Col1 int NOT NULL PRIMARY KEY NONCLUSTERED
    , Col2 char(10) );

-->> Loop starts here
WHILE @Counter4 < 100000
   BEGIN

      INSERT #TempTable2 VALUES ( (@RowId4), 'one' );
      INSERT #TempTable2 VALUES ( (@RowId4 + 1), 'two' );
      INSERT #TempTable2 VALUES ( (@RowId4 + 2), 'three' );
      INSERT #TempTable2 VALUES ( (@RowId4 + 3), 'four' );
      INSERT #TempTable2 VALUES ( (@RowId4 + 4), 'five' );
      INSERT #TempTable2 VALUES ( (@RowId4 + 5), 'six' );
      INSERT #TempTable2 VALUES ( (@RowId4 + 6), 'seven' );
      INSERT #TempTable2 VALUES ( (@RowId4 + 7), 'eight' );
      INSERT #TempTable2 VALUES ( (@RowId4 + 8), 'nine' );
      INSERT #TempTable2 VALUES ( (@RowId4 + 9), 'ten' );

      SELECT 
         @Counter4 += 1
       , @RowId4 += 10
   END
--<< Loop Ends here

PRINT '   #Temp Table Elapsed Time Without DELETE = ' + CAST(DATEDIFF(MS, @Started4, sysdatetime()) AS varchar(10)) + ' milliseconds.';

--<<< Using Table Variable -WITHOUT DELETE >>>--

DECLARE 
   @Counter5 int = 0
 , @RowId5 int = 1
 , @Started5 datetime2 = sysdatetime();

DECLARE @TableVariable2 table
   (  Col1 int NOT NULL PRIMARY KEY NONCLUSTERED
    , Col2 char(10) );

-->> Loop starts here
WHILE @Counter5 < 100000
   BEGIN
      INSERT @TableVariable2 VALUES ( (@RowId5), 'one' );
      INSERT @TableVariable2 VALUES ( (@RowId5 + 1), 'two' );
      INSERT @TableVariable2 VALUES ( (@RowId5 + 2), 'three' );
      INSERT @TableVariable2 VALUES ( (@RowId5 + 3), 'four' );
      INSERT @TableVariable2 VALUES ( (@RowId5 + 4), 'five' );
      INSERT @TableVariable2 VALUES ( (@RowId5 + 5), 'six' );
      INSERT @TableVariable2 VALUES ( (@RowId5 + 6), 'seven' );
      INSERT @TableVariable2 VALUES ( (@RowId5 + 7), 'eight' );
      INSERT @TableVariable2 VALUES ( (@RowId5 + 8), 'nine' );
      INSERT @TableVariable2 VALUES ( (@RowId5 + 9), 'ten' );

      SELECT 
         @Counter5 += 1
       , @RowId5 += 10
   END
--<< Loop Ends here

PRINT '   Table Variable Elapsed Time Without DELETE = ' + CAST(DATEDIFF(MS, @Started5, sysdatetime()) AS varchar(10)) + ' milliseconds.';

--<<< Using Memory-Optimized Table Variable -WITHOUT DELETE >>>--

DECLARE 
   @Counter6 int = 0
 , @RowId6 int = 1
 , @Started6 datetime2 = sysdatetime();

-->> Loop starts here
   DECLARE @TableVariable_MemoryOptimized_2 dbo.TYPE_MemoryOptimizedTable;

WHILE @Counter6 < 100000
   BEGIN
      INSERT @TableVariable_MemoryOptimized_2 VALUES ( (@RowId6), 'one' );
      INSERT @TableVariable_MemoryOptimized_2 VALUES ( (@RowId6 + 1), 'two' );
      INSERT @TableVariable_MemoryOptimized_2 VALUES ( (@RowId6 + 2), 'three' );
      INSERT @TableVariable_MemoryOptimized_2 VALUES ( (@RowId6 + 3), 'four' );
      INSERT @TableVariable_MemoryOptimized_2 VALUES ( (@RowId6 + 4), 'five' );
      INSERT @TableVariable_MemoryOptimized_2 VALUES ( (@RowId6 + 5), 'six' );
      INSERT @TableVariable_MemoryOptimized_2 VALUES ( (@RowId6 + 6), 'seven' );
      INSERT @TableVariable_MemoryOptimized_2 VALUES ( (@RowId6 + 7), 'eight' );
      INSERT @TableVariable_MemoryOptimized_2 VALUES ( (@RowId6 + 8), 'nine' );
      INSERT @TableVariable_MemoryOptimized_2 VALUES ( (@RowId6 + 9), 'ten' );

      DELETE  FROM @TableVariable_MemoryOptimized_2;
      SELECT 
         @Counter6 += 1
       , @RowId6 += 10
   END
--<< Loop Ends here

 PRINT '   Memory Optimized Table Elapsed Time Without DELETE = ' + CAST(DATEDIFF(MS, @Started6, sysdatetime()) AS varchar(10)) + ' milliseconds.';

 PRINT ''
 PRINT '--<<< Compare #Temp Table and Table Variable without PRIMARY KEY >>>--'
 PRINT ''

--<<< Compare both #TEMP Table and Table Variable WITHOUT Primary Key >>>--

DECLARE 
   @Counter9 int = 0
 , @RowId9 int = 1
 , @Started9 datetime2 = sysdatetime();

CREATE TABLE #TempTable3
   (  Col1 int NOT NULL 
    , Col2 char(10) );

-->> Loop starts here
WHILE @Counter9 < 100000
   BEGIN

      INSERT #TempTable3 VALUES ( (@RowId9), 'one' );
      INSERT #TempTable3 VALUES ( (@RowId9 + 1), 'two' );
      INSERT #TempTable3 VALUES ( (@RowId9 + 2), 'three' );
      INSERT #TempTable3 VALUES ( (@RowId9 + 3), 'four' );
      INSERT #TempTable3 VALUES ( (@RowId9 + 4), 'five' );
      INSERT #TempTable3 VALUES ( (@RowId9 + 5), 'six' );
      INSERT #TempTable3 VALUES ( (@RowId9 + 6), 'seven' );
      INSERT #TempTable3 VALUES ( (@RowId9 + 7), 'eight' );
      INSERT #TempTable3 VALUES ( (@RowId9 + 8), 'nine' );
      INSERT #TempTable3 VALUES ( (@RowId9 + 9), 'ten' );

      DELETE FROM #TempTable3;
      SELECT 
         @Counter9 += 1
       , @RowId9 += 10
   END

PRINT '   #Temp Table Elapsed Time -INSERT|DELETE with [NO] PRIMARY KEY = ' + CAST(DATEDIFF(MS, @Started9, sysdatetime()) AS varchar(10)) + ' milliseconds.';

DECLARE 
   @Counter8 int = 0
 , @RowId8 int = 1
 , @Started8 datetime2 = sysdatetime();

DECLARE @TempTable3 TABLE
   (  Col1 int NOT NULL 
    , Col2 char(10) );

-->> Loop starts here
WHILE @Counter8 < 100000
   BEGIN

      INSERT @TempTable3 VALUES ( (@RowId8), 'one' );
      INSERT @TempTable3 VALUES ( (@RowId8 + 1), 'two' );
      INSERT @TempTable3 VALUES ( (@RowId8 + 2), 'three' );
      INSERT @TempTable3 VALUES ( (@RowId8 + 3), 'four' );
      INSERT @TempTable3 VALUES ( (@RowId8 + 4), 'five' );
      INSERT @TempTable3 VALUES ( (@RowId8 + 5), 'six' );
      INSERT @TempTable3 VALUES ( (@RowId8 + 6), 'seven' );
      INSERT @TempTable3 VALUES ( (@RowId8 + 7), 'eight' );
      INSERT @TempTable3 VALUES ( (@RowId8 + 8), 'nine' );
      INSERT @TempTable3 VALUES ( (@RowId8 + 9), 'ten' );

      DELETE FROM @TempTable3;
      SELECT 
         @Counter8 += 1
       , @RowId8 += 10
   END

PRINT '   Table Variable Elapsed Time - INSERT|DELETE with [NO] PRIMARY KEY = ' + CAST(DATEDIFF(MS, @Started8, sysdatetime()) AS varchar(10)) + ' milliseconds.';

 --<<<  [STOP]  >>>--

PRINT ''
PRINT '--<<< Compare #Temp Table and Table Variable INSERT|DELETE WITH CLUSTERED PRIMARY KEY >>>--'
PRINT ''

--<<< Compare both #TEMP Table and Table Variable with CLUSTERED PRIMARY KEY >>>--

DECLARE 
   @Counter11 int = 0
 , @RowId11 int = 1
 , @Started11 datetime2 = sysdatetime();

CREATE TABLE #TempTable4
   (  Col1 int NOT NULL PRIMARY KEY
    , Col2 char(10) );

-->> Loop starts here
WHILE @Counter11 < 100000
   BEGIN

      INSERT #TempTable4 VALUES ( (@RowId11), 'one' );
      INSERT #TempTable4 VALUES ( (@RowId11 + 1), 'two' );
      INSERT #TempTable4 VALUES ( (@RowId11 + 2), 'three' );
      INSERT #TempTable4 VALUES ( (@RowId11 + 3), 'four' );
      INSERT #TempTable4 VALUES ( (@RowId11 + 4), 'five' );
      INSERT #TempTable4 VALUES ( (@RowId11 + 5), 'six' );
      INSERT #TempTable4 VALUES ( (@RowId11 + 6), 'seven' );
      INSERT #TempTable4 VALUES ( (@RowId11 + 7), 'eight' );
      INSERT #TempTable4 VALUES ( (@RowId11 + 8), 'nine' );
      INSERT #TempTable4 VALUES ( (@RowId11 + 9), 'ten' );

      DELETE FROM #TempTable4;
      SELECT 
         @Counter11 += 1
       , @RowId11 += 10
   END

PRINT '   #Temp Table Elapsed Time - INSERT|DELETE [CLUSTERED PRIMARY KEY] = ' + CAST(DATEDIFF(MS, @Started11, sysdatetime()) AS varchar(10)) + ' milliseconds.';

DECLARE 
   @Counter10 int = 0
 , @RowId10 int = 1
 , @Started10 datetime2 = sysdatetime();

DECLARE @TableVariable4 TABLE
   (  Col1 int NOT NULL PRIMARY KEY
    , Col2 char(10) );

-->> Loop starts here
WHILE @Counter10 < 100000
   BEGIN

      INSERT @TableVariable4 VALUES ( (@RowId10), 'one' );
      INSERT @TableVariable4 VALUES ( (@RowId10 + 1), 'two' );
      INSERT @TableVariable4 VALUES ( (@RowId10 + 2), 'three' );
      INSERT @TableVariable4 VALUES ( (@RowId10 + 3), 'four' );
      INSERT @TableVariable4 VALUES ( (@RowId10 + 4), 'five' );
      INSERT @TableVariable4 VALUES ( (@RowId10 + 5), 'six' );
      INSERT @TableVariable4 VALUES ( (@RowId10 + 6), 'seven' );
      INSERT @TableVariable4 VALUES ( (@RowId10 + 7), 'eight' );
      INSERT @TableVariable4 VALUES ( (@RowId10 + 8), 'nine' );
      INSERT @TableVariable4 VALUES ( (@RowId10 + 9), 'ten' );

      DELETE FROM @TableVariable4;
      SELECT 
         @Counter10 += 1
       , @RowId10 += 10
   END

PRINT '   Table Variable Elapsed Time -INSERT|DELETE [CLUSTERED PRIMARY KEY] = ' + CAST(DATEDIFF(MS, @Started10, sysdatetime()) AS varchar(10)) + ' milliseconds.';

PRINT ''
PRINT 'END'

--<<< Extended Test Ends Here >>>--

--<<<  [STOP]  >>>--


/* Clean up
   USE master;
   DROP DATABASE MO_Table_Demo;
   DROP TABLE #TempTable1;
   DROP TABLE #TempTable2;
   DROP TABLE #TempTable3;
   DROP TABLE #TempTable4;
*/





/* 
 -- Sample Results

--<<< This is a test of 1,000,000 INSERT and 100,000 DELETE operations >>>--
--<<< The Following is INSERT and DELETE. >>>--
 
   #Temp Table Elapsed Time = 17232 milliseconds.
   Table Variable Elapsed Time = 15854 milliseconds.
   Memory Optimized Table Elapsed Time = 4851 milliseconds.
 
--<<< This is a test of 1,000,000 INSERT operations (NO DELETEs >>>--
--<<< The Following is INSERT ONLY >>>--
 
   #Temp Table Elapsed Time Without DELETE = 10753 milliseconds.
   Table Variable Elapsed Time Without DELETE = 9519 milliseconds.
   Memory Optimized Table Elapsed Time Without DELETE = 4552 milliseconds.
 
--<<< Compare #Temp Table and Table Variable without PRIMARY KEY >>>--
 
   #Temp Table Elapsed Time -INSERT|DELETE with [NO] PRIMARY KEY = 10291 milliseconds.
   Table Variable Elapsed Time - INSERT|DELETE with [NO] PRIMARY KEY = 10847 milliseconds.
 
--<<< Compare #Temp Table and Table Variable INSERT|DELETE WITH CLUSTERED PRIMARY KEY >>>--
 
   #Temp Table Elapsed Time - INSERT|DELETE [CLUSTERED PRIMARY KEY] = 8435 milliseconds.
   Table Variable Elapsed Time -INSERT|DELETE [CLUSTERED PRIMARY KEY] = 9580 milliseconds.
 


*/



CREATE DATABASE MO_Table_Demo_X;
GO

USE MO_Table_Demo_X;

--<<<  [STOP]  >>>--

-- < Memory-Optimized Tables REQUIRE a separate FILEGROUP (Filestream) >--
ALTER DATABASE MO_Table_Demo_X
   ADD FILEGROUP [MO_DataX] 
      CONTAINS MEMORY_OPTIMIZED_DATA;

--< Memory-Optimized Tables REQUIRE a separate data file >--
DECLARE @SQL nvarchar(max) = 
   N'ALTER DATABASE MO_Table_Demo_X
        ADD FILE ( name=''MO_Table_DemoX'', 
                   filename=' + QUOTENAME(cast(SERVERPROPERTY('InstanceDefaultDataPath') as nvarchar(max)) + db_name() + N'X.mod', N'''') + ') 
           TO FILEGROUP [MO_DataX];'
EXECUTE sp_executesql @SQL;


CREATE TYPE dbo.TYPE_MemoryOptimizedTableX AS TABLE
   (  Col1 int NOT NULL PRIMARY KEY NONCLUSTERED
    , Col2 char(10) )
   WITH (MEMORY_OPTIMIZED = ON );
GO

CREATE TABLE #TempTable_X
   (  Col1 int NOT NULL PRIMARY KEY NONCLUSTERED
    , Col2 char(10) );

DECLARE @TableVariable_X table
   (  Col1 int NOT NULL PRIMARY KEY NONCLUSTERED
    , Col2 char(10) );

DECLARE @TableVariable_MemoryOptimized_X dbo.TYPE_MemoryOptimizedTableX;

BEGIN TRANSACTION

	INSERT #TempTable_X VALUES ( (101), 'one' );
	INSERT @TableVariable_X VALUES ( (10001), 'one' );
	INSERT @TableVariable_MemoryOptimized_X VALUES ( (10000001), 'one' ); 

	SELECT * FROM #TempTable_X;
	SELECT * FROM @TableVariable_X;
	SELECT * FROM @TableVariable_MemoryOptimized_X;

ROLLBACK TRANSACTION;

SELECT * FROM #TempTable_X;
SELECT * FROM @TableVariable_X;
SELECT * FROM @TableVariable_MemoryOptimized_X;
GO

USE master;
GO

DROP TABLE #TempTable_X;
DROP DATABASE MO_Table_Demo_X;


