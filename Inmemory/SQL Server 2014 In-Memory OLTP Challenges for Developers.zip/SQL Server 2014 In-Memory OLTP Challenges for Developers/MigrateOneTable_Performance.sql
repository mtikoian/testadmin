 -------------------------------------------------------------------------------------
-- SQL Saturday Slovenia, Ljubljana, 13.12.2014
-- ASP.NET Session State Server - Hekaton - TempResetTimeout
-- Dipl.-Ing. Milos Radivojevic, Data Architect, bwin.party
-- E: Milos.Radivojevic@bwinparty.com
-- W: http://www.bwinparty.com 
-- T: @MilosSQL
-------------------------------------------------------------------------------------
--This code example has been made by Jos de Bruijn (jodebrui@microsoft.com)
--Senior Program Manager in the SQL Server Database Systems team on TechEd North America 2014
--

IF OBJECT_ID('dbo.T1Disk') IS NOT NULL
DROP TABLE dbo.T1Disk
GO

CREATE TABLE dbo.T1Disk
(
[SalesOrderID] int identity NOT NULL primary key,
[OrderSequence] int NOT NULL,
[OrderDate] [datetime2](7) NOT NULL,
[Status] [tinyint] NOT NULL
)
GO

CREATE INDEX IX_OrderSequence ON dbo.T1Disk(OrderSequence);
GO
CREATE INDEX IX_Status ON dbo.T1Disk(Status);
GO
CREATE INDEX IX_OrderDate ON dbo.T1Disk(OrderDate);
GO

SET NOCOUNT ON
GO


DECLARE @i int = 0
BEGIN TRAN
WHILE @i < 262144
BEGIN
INSERT dbo.T1Disk (OrderSequence, OrderDate, [Status]) VALUES (@i, sysdatetime(), @i % 8)
SET @i += 1
END
COMMIT
GO
--It takes 5 seconds

--Let's create the same table with some hash indexes
IF OBJECT_ID('dbo.T1Hek') IS NOT NULL
DROP TABLE dbo.T1Hek
GO

CREATE TABLE dbo.T1Hek
(
SalesOrderID INT IDENTITY NOT NULL,
OrderSequence INT NOT NULL,
OrderDate DATETIME2 NOT NULL,
[Status] TINYINT NOT NULL,

PRIMARY KEY NONCLUSTERED HASH (SalesOrderID) WITH ( BUCKET_COUNT = 262144 ),
INDEX IX_OrderSequence HASH (OrderSequence) WITH ( BUCKET_COUNT = 20000),
INDEX IX_Status HASH ([Status]) WITH ( BUCKET_COUNT = 8),
INDEX IX_OrderDate NONCLUSTERED (OrderDate ASC),
)WITH ( MEMORY_OPTIMIZED = ON , DURABILITY = SCHEMA_AND_DATA )
GO

DECLARE @i int = 0
BEGIN TRAN
WHILE @i < 262144
BEGIN
INSERT dbo.T1Hek (OrderSequence, OrderDate, [Status]) VALUES (@i, sysdatetime(), @i % 8)
SET @i += 1
END
COMMIT
GO
--It takes about one minute

--Let's choose better indexes
IF OBJECT_ID('dbo.T1Hek') IS NOT NULL
DROP TABLE dbo.T1Hek
GO

CREATE TABLE dbo.T1Hek
(
SalesOrderID INT IDENTITY NOT NULL,
OrderSequence INT NOT NULL,
OrderDate DATETIME2 NOT NULL,
[Status] TINYINT NOT NULL,

PRIMARY KEY NONCLUSTERED HASH (SalesOrderID) WITH ( BUCKET_COUNT = 1000000 ),
INDEX IX_OrderSequence HASH (OrderSequence) WITH ( BUCKET_COUNT = 1000000),
INDEX IX_Status (Status),
INDEX IX_OrderDate NONCLUSTERED (OrderDate ASC),
)WITH ( MEMORY_OPTIMIZED = ON , DURABILITY = SCHEMA_AND_DATA )
GO

DECLARE @i INT = 0
BEGIN TRAN
WHILE @i < 262144
BEGIN
INSERT dbo.T1Hek (OrderSequence, OrderDate, [Status]) VALUES (@i, sysdatetime(), @i % 8)
SET @i += 1
END
COMMIT
GO

--It takes about two seconds!