----------------------------------------------------------------------
-- SQL Saturday Slovenia, Ljubljana, 13.12.2014
-- ASP.NET Session State Server - Hekaton - TempUpdateStateItemLong
-- Dipl.-Ing. Milos Radivojevic, Data Architect, bwin.party
-- E: Milos.Radivojevic@bwinparty.com
-- W: http://www.bwinparty.com 
-- T: @MilosSQL
---------------------------------------------------------------------

USE ASPStateInMemory
GO
----ASP.NET Session State Default SP Body
--CREATE PROCEDURE dbo.TempUpdateStateItemLong
--    @id         tSessionId,
--    @itemLong   tSessionItemLong,
--    @timeout    int,
--    @lockCookie int
--AS    
--    UPDATE [ASPState].dbo.ASPStateTempSessions
--    SET Expires = DATEADD(n, @timeout, GETUTCDATE()), 
--        SessionItemLong = @itemLong,
--        Timeout = @timeout,
--        Locked = 0
--    WHERE SessionId = @id AND LockCookie = @lockCookie

--    RETURN 0
--GO

--Hekaton Implementation

CREATE PROCEDURE dbo.TempUpdateStateItemLong
	@id tSessionId,
	@itemLong tSessionItemLong,
	@timeout INT,
	@lockCookie INT
AS
BEGIN
	DECLARE @Expires DATETIME
	DECLARE @updated INT

	SET @Expires = DATEADD(n, @Timeout, GETUTCDATE())
	
	DELETE FROM dbo.ASPStateSessionItemLong WHERE SessionID = @ID
	
	-- Redo until it comes back without exception
	-- IsDone will be set only if the Reset works.
	DECLARE @IsDone BIT = 0
	WHILE @IsDone = 0
	BEGIN
		BEGIN TRY
			UPDATE dbo.ASPStateTempSessions WITH (SNAPSHOT)
			SET
				Expires = @Expires,
				Timeout = @Timeout,
				Locked = 0,
				SessionItemLong = 1
			WHERE SessionId = @Id AND LockCookie = @lockCookie
			SELECT @updated = @@ROWCOUNT
			SET @IsDone = 1
		END TRY
		BEGIN CATCH
			IF ERROR_NUMBER() IN (41301, 41302)
				WAITFOR DELAY '00:00:00:001';
			ELSE
				THROW;
		END CATCH
	END		
	
	IF @updated > 0 
		EXEC dbo.SplitVarBinaryMax @id, @itemLong	

	RETURN 0
END
GO

CREATE PROCEDURE dbo.SplitVarBinaryMax
	@id NVARCHAR(88),
	@TheBlob VARBINARY(MAX)
AS
BEGIN
	DECLARE @Part INT = 0
	DECLARE @Chunk VARBINARY(7000)
	DECLARE @DL BIGINT = DATALENGTH(@TheBlob)
	WHILE @Part < @DL
	BEGIN
		SET @Chunk = SUBSTRING(@TheBlob, @Part+1, 7000)

		INSERT INTO dbo.ASPStateSessionItemLong(SessionID,TotalLength, SessionPart, SessionItemLong)
		VALUES (@Id, @DL, @Part, @Chunk)

		SET @Part = @Part + 7000
	END
END
GO

