-------------------------------------------------------------------------------------
-- SQL Saturday Slovenia, Ljubljana, 13.12.2014
-- ASP.NET Session State Server - Hekaton - TempResetTimeout
-- Dipl.-Ing. Milos Radivojevic, Data Architect, bwin.party
-- E: Milos.Radivojevic@bwinparty.com
-- W: http://www.bwinparty.com 
-- T: @MilosSQL
-------------------------------------------------------------------------------------

USE ASPStateInMemory
GO
----ASP.NET Session State Default SP Body
--CREATE PROCEDURE dbo.TempResetTimeout
--	@id  tSessionId
--AS
--	UPDATE [ASPState].dbo.ASPStateTempSessions
--	SET Expires = DATEADD(n, Timeout, GETUTCDATE())
--	WHERE SessionId = @id
--	RETURN 0
--GO

--Hekaton Implementation
CREATE PROCEDURE dbo.TempResetTimeout
	@id tSessionId
AS
BEGIN
	DECLARE @Expires DATETIME
	DECLARE @Timeout INT = 0

	SELECT @Timeout =[Timeout] FROM dbo.ASPStateTempSessions WITH (SNAPSHOT) WHERE SessionId = @id
	SET @Expires=DATEADD(n, @Timeout, GETUTCDATE())
	-- Redo until it comes back without exception
	-- IsDone will be set only if the Reset works.
	DECLARE @IsDone BIT = 0	
	WHILE @IsDone = 0
	BEGIN

		BEGIN TRY		
			UPDATE dbo.ASPStateTempSessions WITH (SNAPSHOT)
			SET Expires = DATEADD(n, @Timeout, GETUTCDATE())
			WHERE SessionId = @ID
				
			SET @IsDone = 1
		END TRY
		BEGIN CATCH
			IF ERROR_NUMBER() IN (41301,41302)
				WAITFOR DELAY '00:00:00:001';
			ELSE
				THROW;
		END CATCH
	END		
		
	RETURN 0
END
GO
