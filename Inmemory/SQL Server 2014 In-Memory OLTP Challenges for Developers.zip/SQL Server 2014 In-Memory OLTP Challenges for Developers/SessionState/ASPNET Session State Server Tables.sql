-------------------------------------------------------------------------------------
-- SQL Saturday Slovenia, Ljubljana, 13.12.2014
-- ASP.NET Session State Server - Hekaton - Create Tables
-- Dipl.-Ing. Milos Radivojevic, Data Architect, bwin.party
-- E: Milos.Radivojevic@bwinparty.com
-- W: http://www.bwinparty.com 
-- T: @MilosSQL
-------------------------------------------------------------------------------------

USE ASPStateInMemory
GO
CREATE TABLE dbo.ASPStateTempApplications(
	AppId INT NOT NULL,
	Appname CHAR(280) NOT NULL,
PRIMARY KEY CLUSTERED (AppId ASC)
)
GO

CREATE TABLE dbo.ASPStateTempSessions_Hekaton
(
	SessionId NVARCHAR(88) COLLATE Latin1_General_100_BIN2 NOT NULL PRIMARY KEY NONCLUSTERED HASH (SessionId) WITH (BUCKET_COUNT = 33554432),
	Created DATETIME NOT NULL,
	Expires DATETIME NOT NULL,
	LockDate DATETIME NOT NULL,
	LockDateLocal DATETIME NOT NULL,
	LockCookie INT NOT NULL,
	[Timeout] INT NOT NULL,
	Locked BIT NOT NULL,
	SessionItemShort VARBINARY(7000) NULL,
	SessionItemLong BIT NOT NULL,
	Flags INT NOT NULL
)
	WITH (MEMORY_OPTIMIZED = ON, DURABILITY = SCHEMA_ONLY)
GO

CREATE TABLE dbo.ASPStateSessionItemLong
(
	SessionId NVARCHAR(88) COLLATE Latin1_General_100_BIN2 NOT NULL,
	TotalLength INT NOT NULL,
	SessionPart INT NOT NULL,
	SessionItemLong VARBINARY(7000) NOT NULL,
	INDEX idx_hash NONCLUSTERED HASH (SessionID) WITH (BUCKET_COUNT = 16777216),
	CONSTRAINT PK_ASPStateSessionItemLong PRIMARY KEY NONCLUSTERED HASH (SessionID, SessionPart) WITH (BUCKET_COUNT = 16777216)
)
	WITH (MEMORY_OPTIMIZED = ON, DURABILITY = SCHEMA_ONLY)
GO

 