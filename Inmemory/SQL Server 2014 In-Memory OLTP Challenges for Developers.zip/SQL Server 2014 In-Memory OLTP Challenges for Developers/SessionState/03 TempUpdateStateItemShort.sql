----------------------------------------------------------------------
-- SQL Saturday Slovenia, Ljubljana, 13.12.2014
-- ASP.NET Session State Server - Hekaton - TempUpdateStateItemShort
-- Dipl.-Ing. Milos Radivojevic, Data Architect, bwin.party
-- E: Milos.Radivojevic@bwinparty.com
-- W: http://www.bwinparty.com 
-- T: @MilosSQL
---------------------------------------------------------------------

USE ASPStateInMemory
GO
----ASP.NET Session State Default SP Body
--CREATE PROCEDURE dbo.TempUpdateStateItemShort
--    @id         tSessionId,
--    @itemShort  tSessionItemShort,
--    @timeout    int,
--    @lockCookie int
--AS    
--    UPDATE [ASPState].dbo.ASPStateTempSessions
--    SET Expires = DATEADD(n, @timeout, GETUTCDATE()), 
--        SessionItemShort = @itemShort, 
--        [Timeout] = @timeout,
--        Locked = 0
--    WHERE SessionId = @id AND LockCookie = @lockCookie

--    RETURN 0 
--GO

--Hekaton Implementation

CREATE PROCEDURE dbo.TempUpdateStateItemShort
	@id tSessionId,
	@itemShort tSessionItemShort,
	@timeout int,
	@lockCookie int
AS
BEGIN
	DECLARE @Expires DATETIME

	SET @Expires = DATEADD(n, @timeout, GetUTCDate())
	
	DECLARE @IsDone bit=0
	WHILE @IsDone=0
	BEGIN
		BEGIN TRY
			UPDATE dbo.ASPStateTempSessions WITH (SNAPSHOT)
			SET
				Expires = @Expires,
				SessionItemShort = @ItemShort,
				[Timeout] = @Timeout,
				Locked = 0
			WHERE SessionId = @Id AND LockCookie = @LockCookie

			SET @IsDone=1
		END TRY
		BEGIN CATCH
			IF ERROR_NUMBER() IN (41301, 41302)
				WAITFOR DELAY '00:00:00:001';
			ELSE
				THROW;
		END CATCH
	END		
	
	RETURN 0
END

