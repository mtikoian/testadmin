----------------------------------------------------------------------
-- SQL Saturday Slovenia, Ljubljana, 13.12.2014
-- ASP.NET Session State Server - Hekaton - TempGetStateItem
-- Dipl.-Ing. Milos Radivojevic, Data Architect, bwin.party
-- E: Milos.Radivojevic@bwinparty.com
-- W: http://www.bwinparty.com 
-- T: @MilosSQL
---------------------------------------------------------------------
USE ASPStateInMemory
GO
----ASP.NET Session State Default SP Body
--CREATE PROCEDURE dbo.TempGetStateItem
--    @id         tSessionId,
--    @itemShort  tSessionItemShort OUTPUT,
--    @locked     bit OUTPUT,
--    @lockDate   datetime OUTPUT,
--    @lockCookie int OUTPUT
--AS
--    DECLARE @textptr AS tTextPtr
--    DECLARE @length AS int
--    DECLARE @now AS datetime
--    SET @now = GETUTCDATE()

--    UPDATE [ASPState].dbo.ASPStateTempSessions
--    SET Expires = DATEADD(n, Timeout, @now), 
--        @locked = Locked,
--        @lockDate = LockDateLocal,
--        @lockCookie = LockCookie,
--        @itemShort = CASE @locked
--            WHEN 0 THEN SessionItemShort
--            ELSE NULL
--            END,
--        @textptr = CASE @locked
--            WHEN 0 THEN TEXTPTR(SessionItemLong)
--            ELSE NULL
--            END,
--        @length = CASE @locked
--            WHEN 0 THEN DATALENGTH(SessionItemLong)
--            ELSE NULL
--            END
--    WHERE SessionId = @id
--    IF @length IS NOT NULL BEGIN
--        READTEXT [ASPState].dbo.ASPStateTempSessions.SessionItemLong @textptr 0 @length
--    END

--    RETURN 0
--GO

--Hekaton Implementation

CREATE PROCEDURE dbo.TempGetStateItem
    @id         tSessionId,
    @itemShort  tSessionItemShort OUTPUT,
    @locked     bit OUTPUT,
    @lockDate   datetime OUTPUT,
    @lockCookie int OUTPUT
AS
BEGIN
	DECLARE @FullImage varbinary(max)

	DECLARE @Count bigint=0
    DECLARE @now AS datetime = GETUTCDATE()
    Declare @Timeout int=0
    DECLARE @Expires datetime
    DECLARE @DoesLongItemExist bit=0
	DECLARE @error int

	SELECT @Timeout=Timeout FROM dbo.ASPStateTempSessions WITH (SNAPSHOT) WHERE SessionId=@id
		
	SET @Expires=DATEADD(n, @Timeout, @now)

	DECLARE @IsDone bit=0
	WHILE @IsDone=0
	BEGIN
		BEGIN TRY
			SELECT @count += 1 FROM dbo.ASPStateTempSessions WITH (SNAPSHOT) WHERE SessionID=@Id

			UPDATE dbo.ASPStateTempSessions WITH (SNAPSHOT)
			SET
				Expires=@Expires, 
				@Locked=Locked,
				@LockDate=LockDateLocal,
				@LockCookie=LockCookie,
				@itemShort=SessionItemShort,
				@DoesLongItemExist=SessionItemLong
			WHERE SessionId=@Id
	
			IF @Locked=1 SET @itemShort=null 

			SET @IsDone=1
		END TRY
		BEGIN CATCH
			SET @error = error_number()
			-- rpolasek 13-04-26
			-- according to M5 cookbook 41302 is thrown with concurrent write access. 
			if (@error = 41302 OR @error = 41301)
				WAITFOR DELAY '00:00:00:001'
			ELSE THROW
		END CATCH
	END		
		
	-- Only change things if session was found
	IF @Count>0 AND @Locked=0 AND @DoesLongItemExist=1
	BEGIN
		EXEC dbo.BuildVarBinaryMax
			@id,
			@FullImage OUTPUT
		SELECT @FullImage
	END
    RETURN 0                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   
END
GO
CREATE PROCEDURE dbo.BuildVarBinaryMax
	@ID NVARCHAR(88),
	@TheBlob VARBINARY(MAX) OUTPUT
AS
BEGIN
	DECLARE @Chunk varbinary(7000)
	DECLARE @Count int = 0
	DECLARE @Part int=0

	SET @TheBlob=CONVERT(VARBINARY(MAX), '')

	SELECT @Count=@Count+1 FROM dbo.ASPStateSessionItemLong with (SNAPSHOT) WHERE SessionID=@ID

	WHILE @Count>0
	BEGIN
		SELECT @Chunk=SessionItemLong FROM dbo.ASPStateSessionItemLong with (SNAPSHOT) 
		WHERE SessionID=@Id AND SessionPart=@Part
		
		SET @TheBlob=@TheBlob+CONVERT(VARBINARY(MAX), @Chunk)
		SET @Part+=7000
		SET @Count-=1
	END
END
GO

