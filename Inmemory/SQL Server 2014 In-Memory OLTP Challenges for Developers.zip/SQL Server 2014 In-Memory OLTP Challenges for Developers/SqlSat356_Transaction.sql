---------------------------------------------
--Disk Table
---------------------------------------------
IF OBJECT_ID('dbo.A1', 'U') IS NOT NULL DROP TABLE dbo.A1;
CREATE TABLE dbo.A1(
id INT NOT NULL PRIMARY KEY,
c1 INT NOT NULL
)
GO
INSERT INTO A1(id,c1) VALUES(1,1);
SELECT * FROM A1

--In-Memory Table
IF OBJECT_ID('dbo.A1_Hek', 'U') IS NOT NULL DROP TABLE dbo.A1_Hek;
CREATE TABLE dbo.A1_Hek(
id INT NOT NULL PRIMARY KEY NONCLUSTERED HASH with (BUCKET_COUNT=1024),
c1 INT NOT NULL
)WITH (MEMORY_OPTIMIZED = ON, DURABILITY = SCHEMA_ONLY) 
GO
INSERT INTO A1_Hek(id,c1) VALUES(1,1)
GO

---------------------------------------------
---Concurrency with disk tables
---------------------------------------------

--Conn1
BEGIN TRAN
	UPDATE dbo.A1 SET c1 = 10 WHERE id = 1;
	WAITFOR DELAY '00:00:05';
COMMIT

--Conn2
BEGIN TRAN
	UPDATE dbo.A1 SET c1 = 20 WHERE id = 1;
	WAITFOR DELAY '00:00:05';
COMMIT

---------------------------------------------
---Concurrency with Hekaton tables
---------------------------------------------

--Conn1
BEGIN TRAN
	UPDATE dbo.A1_Hek WITH (SNAPSHOT) SET c1 = 10 WHERE id = 1;
	WAITFOR DELAY '00:00:05';
COMMIT

--Conn2
BEGIN TRAN
	UPDATE dbo.A1_Hek WITH (SNAPSHOT) SET c1 = 20 WHERE id = 1;
	WAITFOR DELAY '00:00:05';
COMMIT

----------------------------------------------------------
---Concurrency with Hekaton tables - Error handling
----------------------------------------------------------
--Conn1
DECLARE @IsDone BIT = 0
WHILE @IsDone = 0
BEGIN
	BEGIN TRY
		UPDATE dbo.A1_Hek WITH (SNAPSHOT) SET c1 = 10 WHERE id = 1;
		WAITFOR DELAY '00:00:05';
		SET @IsDone = 1
		PRINT 'done'
	END TRY
	BEGIN CATCH
		IF ERROR_NUMBER() IN (41301, 41302)
		BEGIN
			WAITFOR DELAY '00:00:01';
			PRINT 'retry'
		END
		ELSE
			THROW;
	END CATCH
END
GO
--Conn2
DECLARE @IsDone BIT = 0
WHILE @IsDone = 0
BEGIN
	BEGIN TRY
		UPDATE dbo.A1_Hek WITH (SNAPSHOT) SET c1 = 20 WHERE id = 1;
		WAITFOR DELAY '00:00:05';
		SET @IsDone = 1
		PRINT 'done'
	END TRY
	BEGIN CATCH
		IF ERROR_NUMBER() IN (41301, 41302)
		BEGIN
			WAITFOR DELAY '00:00:01';
			PRINT 'retry'
		END
		ELSE
			THROW;
	END CATCH
END
GO

--Migration considerations (UPDLOCK does not work with Hekaton)
SELECT * FROM A1 WITH (UPDLOCK) WHERE id= 1;
--Result:
--1	1
SELECT * FROM A1_Hek WITH (UPDLOCK) WHERE id=6;
--Result:
--Msg 10794, Level 16, State 86, Line 105
--The table option 'updlock' is not supported with memory optimized tables.
