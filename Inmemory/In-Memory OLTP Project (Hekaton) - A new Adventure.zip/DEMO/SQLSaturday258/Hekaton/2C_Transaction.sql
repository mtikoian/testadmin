/*
---------------------------------------------------------------------
-  Event: PASS SQLSaturday #258, Istanbul 2013                      -
-  Title: Transaction Demo                                          -
-   Info: Select to updating table                                  -
- Script: 2C_Transaction.sql                                        -
- Author: Yigit Aktan                                               -
---------------------------------------------------------------------
*/





/* --STEP-1B: Open Transaction to update Disk-Based table----------------------- */
USE [HekatonDB2]
GO

SELECT * FROM PurchaseOrders_ondisk WHERE OrderID = 1005
/* ----------------------------------------------------------------------------- */





/* --STEP-2B: Open Transaction to update Memory Optimized Table----------------- */
USE [HekatonDB2]
GO

SELECT * FROM PurchaseOrders_inmem WHERE OrderID = 1005
/* ----------------------------------------------------------------------------- */