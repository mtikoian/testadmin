/*
-------------------------------------------------------------------------
-  Event: PASS SQLSaturday #258, Istanbul 2013                          -
-  Title: Performance of Natively Compiled Stored Procedures Demo       -
-   Info: Insert 500000 rows into the Memory Optimized Table with T-SQL -
- Script: 1D_Performance.sql                                            -
- Author: Yigit Aktan                                                   -
-------------------------------------------------------------------------
*/




/* --Create second Memory Optimized Table----------------------------------------- */
USE HekatonDB1
GO

CREATE TABLE dbo.T2_inmem
(
	c1 int NOT NULL PRIMARY KEY NONCLUSTERED HASH WITH (BUCKET_COUNT = 20000000), 
	c2 int NOT NULL INDEX IDX3 NONCLUSTERED HASH WITH (BUCKET_COUNT = 20000000),
	c3 DATETIME2 NOT NULL,
	c4 NCHAR(400)
) WITH (MEMORY_OPTIMIZED = ON)
GO
 /* ----------------------------------------------------------------------------- */




/* --Insert 500000 row into the Memory Optimized Table without using Native SP------- */
USE [HekatonDB1]
GO

DECLARE @i INT = 0
 WHILE @i < 500000
  BEGIN
   INSERT INTO dbo.T2_inmem VALUES (@i, @i/2, GETDATE(), N'my string')
  SET @i += 1
 END
 /* ----------------------------------------------------------------------------- */

