/*
---------------------------------------------------------------------
-  Event: PASS SQLSaturday #258, Istanbul 2013                      -
-  Title: Transaction Demo                                          -
-   Info: Open Transaction to update Disk-Based table               -
- Script: 2B_Transaction.sql                                        -
- Author: Yigit Aktan                                               -
---------------------------------------------------------------------
*/




/* --STEP-1A: Open Transaction to update Disk-Based table----------------------- */
USE [HekatonDB2]
GO

BEGIN TRAN
  UPDATE PurchaseOrders_ondisk
  SET Amount = 100
  WHERE OrderID = 1005
--COMMIT
/* ----------------------------------------------------------------------------- */





/* --STEP-2A: Open Transaction to update Disk-Based table----------------------- */
USE [HekatonDB2]
GO

BEGIN TRAN
  UPDATE PurchaseOrders_inmem WITH(SNAPSHOT)
  SET Amount = 100
  WHERE OrderID = 1005
--COMMIT
/* ----------------------------------------------------------------------------- */