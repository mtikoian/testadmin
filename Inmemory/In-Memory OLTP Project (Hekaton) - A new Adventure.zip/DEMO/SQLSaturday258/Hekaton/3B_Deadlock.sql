/*
----------------------------------------------------------------------------------------------
-  Event: PASS SQLSaturday #258, Istanbul 2013                                               -
-  Title: Deadlock Demo                                                                      -
-   Info: Open Transaction to try to occur deadlock on Disk-Based and Memory Optimized Table -
- Script: 3B_Deadlock.sql                                                                    -
- Author: Yigit Aktan                                                                        -
----------------------------------------------------------------------------------------------
*/




/* --DEMO-1B: Open Transaction-------------------------------------------------- */
USE [HekatonDB2]
GO

BEGIN TRAN
SELECT * FROM PurchaseOrders_ondisk WITH(REPEATABLEREAD) WHERE OrderID = 1003
/* ----------------------------------------------------------------------------- */





/* --DEMO-1D: Open Transaction-------------------------------------------------- */
USE [HekatonDB2]
GO

BEGIN TRAN
  UPDATE PurchaseOrders_ondisk
  SET Amount = 200
  WHERE OrderID = 1004
--COMMIT
/* ----------------------------------------------------------------------------- */





--************** MEMORY OPTIMIZED TABLE********************************************

/* --DEMO-2B: Open Transaction-------------------------------------------------- */
USE [HekatonDB2]
GO

BEGIN TRAN
SELECT * FROM PurchaseOrders_inmem WITH(REPEATABLEREAD) WHERE OrderID = 1003
/* ----------------------------------------------------------------------------- */





/* --DEMO-2D: Open Transaction-------------------------------------------------- */
USE [HekatonDB2]
GO

BEGIN TRAN
  UPDATE PurchaseOrders_inmem WITH(REPEATABLEREAD)
  SET Amount = 200
  WHERE OrderID = 1004
--COMMIT
/* ----------------------------------------------------------------------------- */