/*
------------------------------------------------------------------------------------------------------
-  Event: PASS SQLSaturday #258, Istanbul 2013                                                       -
-  Title: Performance of Natively Compiled Stored Procedures Demo                                    -
-   Info: Insert 500000 rows into the Memory Optimized Table with Natively Compiled Stored Procedure -
- Script: 1C_Performance.sql                                                                         -
- Author: Yigit Aktan                                                                                -
------------------------------------------------------------------------------------------------------
*/




/* --Create a Memory Optimized Table-------------------------------------------- */
USE HekatonDB1
GO

CREATE TABLE dbo.T1_inmem
(
	c1 int NOT NULL PRIMARY KEY NONCLUSTERED HASH WITH (BUCKET_COUNT = 20000000), 
	c2 int NOT NULL INDEX IDX2 NONCLUSTERED HASH WITH (BUCKET_COUNT = 20000000),
	c3 DATETIME2 NOT NULL,
	c4 NCHAR(400)
) WITH (MEMORY_OPTIMIZED = ON)
GO
/* ----------------------------------------------------------------------------- */




/********************************************************************/
/* GOTO 1D_Performance to insert 500000 row without using Native SP */
/********************************************************************/




/* --Create Natively Compiled Stored Procedure---------------------------------- */
USE [HekatonDB1]
GO

CREATE PROCEDURE usp_Insert500000Rows
WITH NATIVE_COMPILATION, EXECUTE AS OWNER, SCHEMABINDING
AS
BEGIN ATOMIC WITH (TRANSACTION ISOLATION LEVEL = SNAPSHOT, LANGUAGE = N'English')

DECLARE @i INT = 0
 WHILE @i < 500000
  BEGIN
   INSERT INTO dbo.T1_inmem VALUES (@i, @i/2, GETDATE(), N'my string')
  SET @i += 1
 END

END
GO
-- ALTER NOT SUPPORTED!
/* ----------------------------------------------------------------------------- */




/* --Finding Database ID-------------------------------------------------------- */
SELECT DB_ID()

-- Show generated Native SP files
-- C:\Program Files\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\xtp

-- Show Checkpoint files
-- C:\SQLSaturday258\Databases\HekatonDB1_MOD
/* ----------------------------------------------------------------------------- */




/* --Execute Natively Compiled Stored Procedure to insert 1 million data-------- */
EXEC [HekatonDB1].[dbo].[usp_Insert500000Rows]
/* ----------------------------------------------------------------------------- */




/* --Ensure that 500000 data were inserted-------------------------------------- */
SELECT COUNT(*) FROM dbo.T1_inmem
/* ----------------------------------------------------------------------------- */







/* ROLLBACK


USE [HekatonDB1]
GO
CREATE PROCEDURE usp_Insert500000Rows
GO

USE HekatonDB1
GO
DROP TABLE dbo.T1_inmem
GO

*/