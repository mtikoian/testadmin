/*
--------------------------------------------------------------------
-  Event: PASS SQLSaturday #258, Istanbul 2013                     -
-  Title: Performance of Natively Compiled Stored Procedures Demo  -
-   Info: Insert 500000 rows into the Disk-Based table with T-SQL  -
- Script: 1B_Performance.sql                                       -
- Author: Yigit Aktan                                              -
--------------------------------------------------------------------
*/




/* --Create a Disk-Based Table-------------------------------------------------- */
USE [HekatonDB1]
GO

CREATE TABLE dbo.T1_ondisk (
	c1 int NOT NULL PRIMARY KEY,
	c2 int NOT NULL INDEX IDX_C2 NONCLUSTERED,
	c3 DATETIME2 NOT NULL,
	c4 NCHAR(400)
)
GO
/* ----------------------------------------------------------------------------- */




/* --Insert 500000 into Disk-Based table-------------------------------------------- */
USE [HekatonDB1]
GO

DECLARE @i INT = 0
 WHILE @i < 500000
  BEGIN
   INSERT INTO dbo.T1_ondisk VALUES (@i, @i/2, GETDATE(), N'my string')
  SET @i += 1
 END
/* ----------------------------------------------------------------------------- */





/*
--ROLLBACK--

USE [HekatonDB1]
GO
DROP TABLE dbo.T1_ondisk
GO
*/