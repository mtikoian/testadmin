/*
--------------------------------------------------------------------
-  Event: PASS SQLSaturday #258, Istanbul 2013                     -
-  Title: Performance of Natively Compiled Stored Procedures Demo  -
-   Info: Create In-Memory OLTP Database                           -
- Script: 1A_Performance.sql                                       -
- Author: Yigit Aktan                                              -
--------------------------------------------------------------------
*/




/* --Enable filestream access--------------------------------------------------- */
USE [master]
GO

EXEC sys.sp_configure N'filestream access level', N'2'
GO
RECONFIGURE WITH OVERRIDE
GO
/* ----------------------------------------------------------------------------- */




/* --Create a Database that contains a file group of Memory Optimized Data------ */
USE [master]
GO

CREATE DATABASE [HekatonDB1]
 CONTAINMENT = NONE
 ON  PRIMARY 
( NAME = N'HekatonDB1', FILENAME = N'C:\SQLSaturday258\Databases\HekatonDB1.mdf' , SIZE = 5120KB , FILEGROWTH = 1024KB )
 LOG ON 
( NAME = N'HekatonDB1_log', FILENAME = N'C:\SQLSaturday258\Databases\HekatonDB1_log.ldf' , SIZE = 2048KB , FILEGROWTH = 10%)
GO
ALTER DATABASE [HekatonDB1] ADD FILEGROUP [HekatonDB1_MOD] CONTAINS MEMORY_OPTIMIZED_DATA 
GO
ALTER DATABASE [HekatonDB1] SET COMPATIBILITY_LEVEL = 110
GO

USE [HekatonDB1]
GO
IF NOT EXISTS (SELECT name FROM sys.filegroups WHERE is_default=1 AND name = N'PRIMARY') 
  ALTER DATABASE [HekatonDB1] MODIFY FILEGROUP [PRIMARY] DEFAULT
GO
/* ----------------------------------------------------------------------------- */




/* --Add a file to Hekaton filegroup-------------------------------------------- */
USE [master]
GO
ALTER DATABASE [HekatonDB1] 
ADD FILE (NAME = N'HekatonDB1_MOD', FILENAME = N'C:\SQLSaturday258\Databases\HekatonDB1_MOD') 
TO FILEGROUP [HekatonDB1_MOD]
GO
/* ----------------------------------------------------------------------------- */




/*
--ROLLBACK--

USE [master]
GO
DROP DATABASE [HekatonDB1]
GO

USE [master]
GO
EXEC sys.sp_configure N'filestream access level', N'0'
GO
RECONFIGURE WITH OVERRIDE
GO
*/