/*
----------------------------------------------------------------------------------------------
-  Event: PASS SQLSaturday #258, Istanbul 2013                                               -
-  Title: Deadlock Demo                                                                      -
-   Info: Open Transaction to try to occur deadlock on Disk-Based and Memory Optimized Table -
- Script: 3A_Deadlock.sql                                                                    -
- Author: Yigit Aktan                                                                        -
----------------------------------------------------------------------------------------------
*/




/* --DEMO-1A: Open Transaction-------------------------------------------------- */
USE [HekatonDB2]
GO

BEGIN TRAN
SELECT * FROM PurchaseOrders_ondisk WITH(REPEATABLEREAD) WHERE OrderID = 1004
/* ----------------------------------------------------------------------------- */





/* --DEMO-1C: Open Transaction-------------------------------------------------- */
USE [HekatonDB2]
GO

BEGIN TRAN
  UPDATE PurchaseOrders_ondisk
  SET Amount = 200
  WHERE OrderID = 1003
--COMMIT
/* ----------------------------------------------------------------------------- */





--************** MEMORY OPTIMIZED TABLE********************************************

/* --DEMO-2A: Open Transaction-------------------------------------------------- */
USE [HekatonDB2]
GO

BEGIN TRAN
SELECT * FROM PurchaseOrders_inmem WITH(REPEATABLEREAD) WHERE OrderID = 1004
/* ----------------------------------------------------------------------------- */





/* --DEMO-2C: Open Transaction-------------------------------------------------- */
USE [HekatonDB2]
GO

BEGIN TRAN
  UPDATE PurchaseOrders_inmem WITH(REPEATABLEREAD)
  SET Amount = 200
  WHERE OrderID = 1003
--COMMIT
/* ----------------------------------------------------------------------------- */