/*
---------------------------------------------------------------------------------
-  Event: PASS SQLSaturday #258, Istanbul 2013                                  -
-  Title: Transaction Demo                                                      -
-   Info: Create In-Memory OLTP Database, Disk-Based and Memory Optimized Table -
- Script: 2A_Transaction.sql                                                    -
- Author: Yigit Aktan                                                           -
---------------------------------------------------------------------------------
*/




/* --Enable filestream access--------------------------------------------------- */
USE [master]
GO

EXEC sys.sp_configure N'filestream access level', N'2'
GO
RECONFIGURE WITH OVERRIDE
GO
/* ----------------------------------------------------------------------------- */




/* --Create a Database that contains a file group of Memory Optimized Data------ */
USE [master]
GO

CREATE DATABASE [HekatonDB2]
 CONTAINMENT = NONE
 ON  PRIMARY 
( NAME = N'HekatonDB2', FILENAME = N'C:\SQLSaturday258\Databases\HekatonDB2.mdf' , SIZE = 5120KB , FILEGROWTH = 1024KB )
 LOG ON 
( NAME = N'HekatonDB2_log', FILENAME = N'C:\SQLSaturday258\Databases\HekatonDB2_log.ldf' , SIZE = 2048KB , FILEGROWTH = 10%)
GO
ALTER DATABASE [HekatonDB2] ADD FILEGROUP [HekatonDB2_MOD] CONTAINS MEMORY_OPTIMIZED_DATA 
GO
ALTER DATABASE [HekatonDB2] SET COMPATIBILITY_LEVEL = 110
GO

USE [HekatonDB2]
GO
IF NOT EXISTS (SELECT name FROM sys.filegroups WHERE is_default=1 AND name = N'PRIMARY') 
  ALTER DATABASE [HekatonDB2] MODIFY FILEGROUP [PRIMARY] DEFAULT
GO
/* ----------------------------------------------------------------------------- */




/* --Add a file to Hekaton filegroup-------------------------------------------- */
USE [master]
GO
ALTER DATABASE [HekatonDB2] 
ADD FILE (NAME = N'HekatonDB2_MOD', FILENAME = N'C:\SQLSaturday258\Databases\HekatonDB2_MOD') 
TO FILEGROUP [HekatonDB2_MOD]
GO
/* ----------------------------------------------------------------------------- */





/* --Create a Disk-Based Table-------------------------------------------------- */
USE HekatonDB2
GO

CREATE TABLE PurchaseOrders_ondisk 
( 
	 OrderID           INT
	,CustomerID        INT
	,OrderDate         DATETIME
	,Amount            MONEY
 )
GO
/* ----------------------------------------------------------------------------- */





/* --Create a Memory Optimized Table-------------------------------------------- */
USE HekatonDB2
GO

CREATE TABLE PurchaseOrders_inmem
(
	 OrderID           INT NOT NULL PRIMARY KEY NONCLUSTERED HASH WITH (BUCKET_COUNT = 20000000)
    ,CustomerID        INT NOT NULL INDEX IDX3 NONCLUSTERED HASH WITH (BUCKET_COUNT = 20000000)
    ,OrderDate         DATETIME
	,Amount            MONEY
) WITH (MEMORY_OPTIMIZED = ON)
GO
/* ----------------------------------------------------------------------------- */





/* --Insert Data into Disk-Based Table------------------------------------------ */
USE HekatonDB2
GO

INSERT PurchaseOrders_ondisk VALUES (1001, 1, DATEADD(MONTH, -1,  DATEADD(MONTH, DATEDIFF(MONTH, 0, GETDATE()), 0)), 23)
INSERT PurchaseOrders_ondisk VALUES (1002, 1, DATEADD(MONTH, -2,  DATEADD(MONTH, DATEDIFF(MONTH, 0, GETDATE()), 0)), 12)
INSERT PurchaseOrders_ondisk VALUES (1003, 2, DATEADD(MONTH, -3,  DATEADD(MONTH, DATEDIFF(MONTH, 0, GETDATE()), 0)), 54)
INSERT PurchaseOrders_ondisk VALUES (1004, 2, DATEADD(MONTH, -4,  DATEADD(MONTH, DATEDIFF(MONTH, 0, GETDATE()), 0)), 66)
INSERT PurchaseOrders_ondisk VALUES (1005, 3, DATEADD(MONTH, -5,  DATEADD(MONTH, DATEDIFF(MONTH, 0, GETDATE()), 0)), 25)
INSERT PurchaseOrders_ondisk VALUES (1006, 3, DATEADD(MONTH, -6,  DATEADD(MONTH, DATEDIFF(MONTH, 0, GETDATE()), 0)), 88)
INSERT PurchaseOrders_ondisk VALUES (1007, 4, DATEADD(MONTH, -7,  DATEADD(MONTH, DATEDIFF(MONTH, 0, GETDATE()), 0)), 13)
INSERT PurchaseOrders_ondisk VALUES (1008, 4, DATEADD(MONTH, -8,  DATEADD(MONTH, DATEDIFF(MONTH, 0, GETDATE()), 0)), 62)
INSERT PurchaseOrders_ondisk VALUES (1009, 5, DATEADD(MONTH, -9,  DATEADD(MONTH, DATEDIFF(MONTH, 0, GETDATE()), 0)), 11)
INSERT PurchaseOrders_ondisk VALUES (1010, 5, DATEADD(MONTH, -10, DATEADD(MONTH, DATEDIFF(MONTH, 0, GETDATE()), 0)), 28)
/* ----------------------------------------------------------------------------- */




/* --Insert Data into Disk-Based Table------------------------------------------ */
USE HekatonDB2
GO

INSERT PurchaseOrders_inmem VALUES (1001, 1, DATEADD(MONTH, -1,  DATEADD(MONTH, DATEDIFF(MONTH, 0, GETDATE()), 0)), 23)
INSERT PurchaseOrders_inmem VALUES (1002, 1, DATEADD(MONTH, -2,  DATEADD(MONTH, DATEDIFF(MONTH, 0, GETDATE()), 0)), 12)
INSERT PurchaseOrders_inmem VALUES (1003, 2, DATEADD(MONTH, -3,  DATEADD(MONTH, DATEDIFF(MONTH, 0, GETDATE()), 0)), 54)
INSERT PurchaseOrders_inmem VALUES (1004, 2, DATEADD(MONTH, -4,  DATEADD(MONTH, DATEDIFF(MONTH, 0, GETDATE()), 0)), 66)
INSERT PurchaseOrders_inmem VALUES (1005, 3, DATEADD(MONTH, -5,  DATEADD(MONTH, DATEDIFF(MONTH, 0, GETDATE()), 0)), 25)
INSERT PurchaseOrders_inmem VALUES (1006, 3, DATEADD(MONTH, -6,  DATEADD(MONTH, DATEDIFF(MONTH, 0, GETDATE()), 0)), 88)
INSERT PurchaseOrders_inmem VALUES (1007, 4, DATEADD(MONTH, -7,  DATEADD(MONTH, DATEDIFF(MONTH, 0, GETDATE()), 0)), 13)
INSERT PurchaseOrders_inmem VALUES (1008, 4, DATEADD(MONTH, -8,  DATEADD(MONTH, DATEDIFF(MONTH, 0, GETDATE()), 0)), 62)
INSERT PurchaseOrders_inmem VALUES (1009, 5, DATEADD(MONTH, -9,  DATEADD(MONTH, DATEDIFF(MONTH, 0, GETDATE()), 0)), 11)
INSERT PurchaseOrders_inmem VALUES (1010, 5, DATEADD(MONTH, -10, DATEADD(MONTH, DATEDIFF(MONTH, 0, GETDATE()), 0)), 28)
/* ----------------------------------------------------------------------------- */

