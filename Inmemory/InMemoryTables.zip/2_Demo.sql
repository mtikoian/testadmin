



--make sure have clean version of AdventureWorks2012 (this is for demo)
USE [master]
ALTER DATABASE [AdventureWorks2012] SET SINGLE_USER WITH ROLLBACK IMMEDIATE
RESTORE DATABASE [AdventureWorks2012] FROM  DISK = N'C:\Adventureworks2012\AdventureWorks2012.bak' WITH  FILE = 1,  NOUNLOAD,  REPLACE,  STATS = 5
ALTER DATABASE [AdventureWorks2012] SET MULTI_USER
GO

USE AdventureWorks2012
GO

--Look at SSMS AdventureWorks2012 properties


--Step #1: Add MEMORY_OPTIMIZED_DATA filegroup to enable in-memory OLTP for your Database:

IF NOT EXISTS (SELECT * FROM sys.data_spaces WHERE TYPE='FX')
ALTER DATABASE CURRENT ADD FILEGROUP [AdventureWorks2012_mod] CONTAINS MEMORY_OPTIMIZED_DATA
GO
IF NOT EXISTS (SELECT * FROM sys.data_spaces ds JOIN sys.database_files df ON ds.data_space_id=df.data_space_id WHERE ds.TYPE='FX')
ALTER DATABASE CURRENT ADD FILE (name='AdventureWorks2012_mod', filename='C:\Program Files\Microsoft SQL Server\MSSQL11.MSSQLSERVER\MSSQL\DATA\AdventureWorks2012_mod') TO FILEGROUP [AdventureWorks2012_mod]

--relook at SSMS

--Step #2: For memory-optimized tables, automatically map all lower isolation levels (including READ COMMITTED) to SNAPSHOT:

ALTER DATABASE CURRENT SET MEMORY_OPTIMIZED_ELEVATE_TO_SNAPSHOT = ON

--Step #3: Create your specific Table(s) to be Memory_Optimized:
--To use In-Memory OLTP, you define a heavily accessed table as memory optimized. You have to define the primary key settings advanced settings when you create the table (can�t be altered later).

--Notice the HASH, BUCKET_COUNT and MEMORY_OTIMIZED settings:
IF OBJECT_ID(N'Sales.SalesOrderDetail_inmem') IS NOT NULL DROP TABLE Sales.SalesOrderDetail_inmem
CREATE TABLE [Sales].[SalesOrderDetail_inmem](
	[SalesOrderID] [int] NOT NULL INDEX IX_SalesOrderID HASH WITH (BUCKET_COUNT=1000000),
	[SalesOrderDetailID] [int]  NOT NULL,
	[CarrierTrackingNumber] [nvarchar](25) NULL,
	[OrderQty] [smallint] NOT NULL,
	[ProductID] [int] NOT NULL INDEX IX_ProductID HASH WITH (BUCKET_COUNT=10000000),
	[SpecialOfferID] [int] NOT NULL,
	[UnitPrice] [money] NOT NULL,
	[UnitPriceDiscount] [money] NOT NULL ,
	[ModifiedDate] [datetime] NOT NULL ,

CONSTRAINT [imPK_SalesOrderDetail_SalesOrderID_SalesOrderDetailID] PRIMARY KEY NONCLUSTERED HASH
(
[SalesOrderID],
[SalesOrderDetailID]
) WITH (BUCKET_COUNT=10000000)

) WITH (MEMORY_OPTIMIZED=ON, DURABILITY=SCHEMA_AND_DATA)





--Step #3 � Update statistics for memory-optimized tables:
UPDATE STATISTICS Sales.SalesOrderDetail_inmem
WITH FULLSCAN, NORECOMPUTE

--Step #4 - Create disk based table (just like MO table)
IF OBJECT_ID(N'Sales.SalesOrderDetail_disk') IS NOT NULL DROP TABLE Sales.SalesOrderDetail_disk 
CREATE TABLE [Sales].[SalesOrderDetail_disk](
	[SalesOrderID] [int] NOT NULL,
	[SalesOrderDetailID] [int]  NOT NULL,
	[CarrierTrackingNumber] [nvarchar](25) NULL,
	[OrderQty] [smallint] NOT NULL,
	[ProductID] [int] NOT NULL,
	[SpecialOfferID] [int] NOT NULL,
	[UnitPrice] [money] NOT NULL,
	[UnitPriceDiscount] [money] NOT NULL ,
	[ModifiedDate] [datetime] NOT NULL ,
 CONSTRAINT [PK_tTemp] PRIMARY KEY CLUSTERED 
(
	[SalesOrderID] ASC,
	[SalesOrderDetailID] ASC
))

CREATE INDEX IDX_SalesOrder_SalesOrderID ON [Sales].[SalesOrderDetail_disk] (SalesOrderID)
GO
CREATE INDEX IDX_SalesOrder_Product ON [Sales].[SalesOrderDetail_disk] (ProductID)
--INCLUDE ([SalesOrderID],[UnitPrice])
GO


--Step 5:
--Let's try an insert into each table
SET STATISTICS TIME ON
SET STATISTICS IO ON
GO
DECLARE @SalesOrderDetailID	INT = (SELECT TOP 1 SalesOrderDetailID FROM Sales.SalesOrderDetail ORDER BY 1 DESC)
INSERT Sales.SalesOrderDetail_inmem
		SELECT SalesOrderID,SalesOrderDetailID,CarrierTrackingNumber,OrderQty,ProductID,SpecialOfferID,UnitPrice,UnitPriceDiscount,ModifiedDate
			FROM Sales.SalesOrderDetail
		UNION
		SELECT SalesOrderID,SalesOrderDetailID + @SalesOrderDetailID,CarrierTrackingNumber,OrderQty,ProductID,SpecialOfferID,UnitPrice,UnitPriceDiscount,DATEADD(mm,1,ModifiedDate)
			FROM Sales.SalesOrderDetail
		UNION ALL
		SELECT SalesOrderID,SalesOrderDetailID + 2*@SalesOrderDetailID,CarrierTrackingNumber,OrderQty,ProductID,SpecialOfferID,UnitPrice,UnitPriceDiscount,DATEADD(mm,2,ModifiedDate)
			FROM Sales.SalesOrderDetail
		UNION ALL
			SELECT SalesOrderID,SalesOrderDetailID + 3*@SalesOrderDetailID,CarrierTrackingNumber,OrderQty,ProductID,SpecialOfferID,UnitPrice,UnitPriceDiscount,DATEADD(mm,3,ModifiedDate)
		FROM Sales.SalesOrderDetail
--00:00:02
GO
SET STATISTICS TIME OFF
SET STATISTICS IO OFF
GO

SET STATISTICS TIME ON
SET STATISTICS IO ON
GO
DECLARE @SalesOrderDetailID	INT = (SELECT TOP 1 SalesOrderDetailID FROM Sales.SalesOrderDetail ORDER BY 1 DESC)
INSERT Sales.SalesOrderDetail_disk
		SELECT SalesOrderID,SalesOrderDetailID,CarrierTrackingNumber,OrderQty,ProductID,SpecialOfferID,UnitPrice,UnitPriceDiscount,ModifiedDate
			FROM Sales.SalesOrderDetail
		UNION ALL
		SELECT SalesOrderID,SalesOrderDetailID + @SalesOrderDetailID,CarrierTrackingNumber,OrderQty,ProductID,SpecialOfferID,UnitPrice,UnitPriceDiscount,DATEADD(mm,1,ModifiedDate)
			FROM Sales.SalesOrderDetail
		UNION ALL
		SELECT SalesOrderID,SalesOrderDetailID + 2*@SalesOrderDetailID,CarrierTrackingNumber,OrderQty,ProductID,SpecialOfferID,UnitPrice,UnitPriceDiscount,DATEADD(mm,2,ModifiedDate)
			FROM Sales.SalesOrderDetail
		UNION ALL
			SELECT SalesOrderID,SalesOrderDetailID + 3*@SalesOrderDetailID,CarrierTrackingNumber,OrderQty,ProductID,SpecialOfferID,UnitPrice,UnitPriceDiscount,DATEADD(mm,3,ModifiedDate)
		FROM Sales.SalesOrderDetail
--00:00:07
GO
SET STATISTICS TIME OFF
SET STATISTICS IO OFF
GO

--now look at deletes
SET STATISTICS TIME ON
SET STATISTICS IO ON
GO
DELETE Sales.SalesOrderDetail_inmem
--00:00:00
GO
SET STATISTICS TIME OFF
SET STATISTICS IO OFF
GO

SET STATISTICS TIME ON
SET STATISTICS IO ON
GO
DELETE Sales.SalesOrderDetail_disk
--00:00:08
GO
SET STATISTICS TIME OFF
SET STATISTICS IO OFF
GO

select count(*) from Sales.SalesOrderDetail_inmem
select count(*) from Sales.SalesOrderDetail_disk


--reload tables
INSERT Sales.SalesOrderDetail_inmem
		SELECT SalesOrderID,SalesOrderDetailID,CarrierTrackingNumber,OrderQty,ProductID,SpecialOfferID,UnitPrice,UnitPriceDiscount,ModifiedDate
			FROM Sales.SalesOrderDetail
GO
INSERT Sales.SalesOrderDetail_disk
		SELECT SalesOrderID,SalesOrderDetailID,CarrierTrackingNumber,OrderQty,ProductID,SpecialOfferID,UnitPrice,UnitPriceDiscount,ModifiedDate
			FROM Sales.SalesOrderDetail

--These are INTEROP queries
-- Ctrl-M (turn on actual execution plan)
SET STATISTICS IO ON;
SET STATISTICS TIME ON;
GO
SELECT COUNT(*) FROM [Sales].[SalesOrderDetail_inmem]
SELECT COUNT(*) FROM Sales.SalesOrderDetail_disk
GO
SET STATISTICS IO OFF;
SET STATISTICS TIME OFF;
GO

IF OBJECT_ID(N'Sales.SalesOrderHeader_inmem') IS NOT NULL DROP TABLE Sales.SalesOrderHeader_inmem
GO
CREATE TABLE Sales.SalesOrderHeader_inmem(
	SalesOrderID int NOT NULL ,
	RevisionNumber tinyint NOT NULL ,
	OrderDate datetime NOT NULL ,
	DueDate datetime NOT NULL,
	ShipDate datetime NULL,
	[Status] tinyint NOT NULL ,
	OnlineOrderFlag BIT NOT NULL ,
	--SalesOrderNumber  AS (isnull(N'SO'+CONVERT(nvarchar(23),SalesOrderID),N'*** ERROR ***')),
	PurchaseOrderNumber NVARCHAR(25) NULL,
	AccountNumber NVARCHAR(15) NULL,
	CustomerID int NOT NULL  INDEX IX_SOH_CustomerID HASH WITH (BUCKET_COUNT=10000000),
	SalesPersonID int NULL ,
	TerritoryID int NULL,
	BillToAddressID int NOT NULL,
	ShipToAddressID int NOT NULL,
	ShipMethodID int NOT NULL,
	CreditCardID int NULL,
	CreditCardApprovalCode varchar(15) NULL,
	CurrencyRateID int NULL,
	SubTotal money NOT NULL ,
	TaxAmt money NOT NULL ,
	Freight money NOT NULL ,
	--TotalDue  AS (isnull((SubTotal+TaxAmt)+Freight,(0))),
	Comment nvarchar(128) NULL,
	--rowguid uniqueidentifier ROWGUIDCOL  NOT NULL INDEX IX_SOH_rowguid HASH WITH (BUCKET_COUNT=10000000),
	ModifiedDate datetime NOT NULL ,
 CONSTRAINT PK_SalesOrderHeader_SalesOrderID_inmem PRIMARY KEY  NONCLUSTERED HASH
	(SalesOrderID) WITH (BUCKET_COUNT=10000000)
) WITH (MEMORY_OPTIMIZED=ON, DURABILITY=SCHEMA_AND_DATA)

GO

INSERT Sales.SalesOrderHeader_inmem
	(SalesOrderID,RevisionNumber,OrderDate,DueDate,ShipDate,[Status],OnlineOrderFlag,PurchaseOrderNumber,
	 AccountNumber,CustomerID,SalesPersonID,TerritoryID,BillToAddressID,ShipToAddressID,ShipMethodID,
	 CreditCardID,CreditCardApprovalCode,CurrencyRateID,SubTotal,TaxAmt,Freight,Comment,ModifiedDate)
	 SELECT SalesOrderID,RevisionNumber,OrderDate,DueDate,ShipDate,[Status],OnlineOrderFlag,PurchaseOrderNumber,
			AccountNumber,CustomerID,SalesPersonID,TerritoryID,BillToAddressID,ShipToAddressID,ShipMethodID,
			CreditCardID,CreditCardApprovalCode,CurrencyRateID,SubTotal,TaxAmt,Freight,Comment,ModifiedDate
		FROM Sales.SalesOrderHeader



--need to come up with better query to show in-memory tables perform better
SET STATISTICS IO ON;
SET STATISTICS TIME ON;
SELECT soh.SalesOrderID, soh.OrderDate,soh.SubTotal, sod.UnitPrice, p.Name
	FROM Sales.SalesOrderHeader_inmem soh
	JOIN Sales.SalesOrderDetail_inmem sod
	  ON sod.SalesOrderID = soh.SalesOrderID
	JOIN Production.Product p
	  ON p.ProductID = sod.ProductID
	WHERE p.ProductID = 870

SELECT soh.SalesOrderID, soh.OrderDate,soh.SubTotal, sod.UnitPrice, p.Name
	FROM Sales.SalesOrderHeader soh
	JOIN Sales.SalesOrderDetail_disk sod
	  ON sod.SalesOrderID = soh.SalesOrderID
	JOIN Production.Product p
	  ON p.ProductID = sod.ProductID
	WHERE p.ProductID = 870
SET STATISTICS IO OFF;
SET STATISTICS TIME OFF;
GO


--now apply missing index
CREATE NONCLUSTERED INDEX IX_SalesOrderDetail_ProductID
ON [Sales].[SalesOrderDetail_disk] ([ProductID])
INCLUDE ([SalesOrderID],[UnitPrice])
GO

--rerun above queries





IF OBJECT_ID(N'dbo.TestInsert_MOP') IS NOT NULL DROP PROCEDURE dbo.TestInsert_MOP
GO
CREATE PROCEDURE dbo.TestInsert_MOP
	WITH NATIVE_COMPILATION, SCHEMABINDING,EXECUTE AS OWNER
	AS
	BEGIN ATOMIC
		WITH (TRANSACTION ISOLATION LEVEL = SNAPSHOT, LANGUAGE = 'us_english')

	/*  TSQL code here */

	END
GO


--Need some error checking when transaction are not optimistic
CREATE PROCEDURE usp_my_procedure @param1 type1, @param2 type2, ...
AS
BEGIN
  -- number of retries � tune based on the workload
  DECLARE @retry INT = 10

  WHILE (@retry > 0)
  BEGIN
    BEGIN TRY

      -- exec usp_my_native_proc @param1, @param2, ...

      --       or

      -- BEGIN TRANSACTION
      --   �
      -- COMMIT TRANSACTION

      SET @retry = 0
    END TRY
    BEGIN CATCH
      SET @retry -= 1
  
      -- the error number for deadlocks (1205) does not need to be included for 
      -- transactions that do not access disk-based tables
      IF (@retry > 0 AND error_number() in (41302, 41305, 41325, 41301, 1205))
      BEGIN
        -- these error conditions are transaction dooming - rollback the transaction
        -- this is not needed if the transaction spans a single native proc execution
        --   as the native proc will simply rollback when an error is thrown 
        IF XACT_STATE() = -1
          ROLLBACK TRANSACTION

        -- use a delay if there is a high rate of write conflicts (41302)
        --   length of delay should depend on the typical duration of conflicting transactions
        -- WAITFOR DELAY '00:00:00.001'
      END
      ELSE
      BEGIN
        -- insert custom error handling for other error conditions here

        -- throw if this is not a qualifying error condition
        ;THROW
      END
    END CATCH
  END
END

