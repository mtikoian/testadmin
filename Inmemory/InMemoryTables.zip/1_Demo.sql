
--Step 1: enable your database for in-memory OLTP 
/*
We are going to add a filegroup for memory_optimized_data to our database, and add 
a container to this filegroup. This filegroup will be used to guarantee durability 
of memory-resident data in the event of a server crash or restart. During the crash 
recovery phase in server startup, the data is recovered from this filegroup and loaded 
back into memory.

When creating the container in the memory_optimized_data filegroup you must specify the 
storage location. In this example we picked the folder (same as where data file is already)
�C:\Program Files\Microsoft SQL Server\MSSQL11.MSSQLSERVER\MSSQL\DATA�. Make sure the 
folder exists before running the script. 
*/
USE MASTER
GO
ALTER DATABASE AdventureWorks2012 
	ADD FILEGROUP AdventureWorks2012_mod CONTAINS MEMORY_OPTIMIZED_DATA; 
ALTER DATABASE AdventureWorks2012 
	ADD FILE (name='AdventureWorks2012_mod1'
			, filename='C:\Program Files\Microsoft SQL Server\MSSQL11.MSSQLSERVER\MSSQL\DATA\AdventureWorks2012_mod1') 
			TO FILEGROUP AdventureWorks2012_mod;
GO

--Now go to SSMS, and right click on Sales.SalesOrderHeader and select 'Memory Optimization Advisor'



--Hmmm, "Alle nicht in Ordnung"