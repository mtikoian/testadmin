--make sure have clean version of AdventureWorks2012 (this is for demo)
USE [master]
ALTER DATABASE [AdventureWorks2012] SET SINGLE_USER WITH ROLLBACK IMMEDIATE
RESTORE DATABASE [AdventureWorks2012] FROM  DISK = N'C:\Adventureworks2012\AdventureWorks2012.bak' WITH  FILE = 1,  NOUNLOAD,  REPLACE,  STATS = 5
ALTER DATABASE [AdventureWorks2012] SET MULTI_USER
GO
ALTER AUTHORIZATION ON DATABASE::AdventureWorks2012 TO sa;			--give ownership to sa; not me (causes some compilation problems if use dbo schema)
GO
USE AdventureWorks2012
GO

--Look at SSMS AdventureWorks2012 properties


--Step #1: Add MEMORY_OPTIMIZED_DATA filegroup to enable in-memory OLTP for your Database:

IF NOT EXISTS (SELECT * FROM sys.data_spaces WHERE TYPE='FX')
ALTER DATABASE CURRENT ADD FILEGROUP [AdventureWorks2012_mod] CONTAINS MEMORY_OPTIMIZED_DATA
GO
IF NOT EXISTS (SELECT * FROM sys.data_spaces ds JOIN sys.database_files df ON ds.data_space_id=df.data_space_id WHERE ds.TYPE='FX')
ALTER DATABASE CURRENT ADD FILE (name='AdventureWorks2012_mod', filename='C:\Program Files\Microsoft SQL Server\MSSQL11.MSSQLSERVER\MSSQL\DATA\AdventureWorks2012_mod') TO FILEGROUP [AdventureWorks2012_mod]

--relook at SSMS

--Step #2: For memory-optimized tables, automatically map all lower isolation levels (including READ COMMITTED) to SNAPSHOT:

ALTER DATABASE CURRENT SET MEMORY_OPTIMIZED_ELEVATE_TO_SNAPSHOT = ON
GO

--drop all these sproc and table to start with a clean slate
IF OBJECT_ID(N'dbo.CreateSalesOrderDetail') IS NOT NULL DROP PROCEDURE dbo.CreateSalesOrderDetail
IF OBJECT_ID(N'dbo.UpdateSalesOrderDetail') IS NOT NULL DROP PROCEDURE dbo.UpdateSalesOrderDetail
IF OBJECT_ID(N'dbo.DeleteSalesOrderDetail') IS NOT NULL DROP PROCEDURE dbo.DeleteSalesOrderDetail
IF OBJECT_ID(N'CreateSalesOrderDetail_MOP') IS NOT NULL DROP PROCEDURE dbo.CreateSalesOrderDetail_MOP
IF OBJECT_ID(N'ReadSalesOrderDetail_MOP') IS NOT NULL DROP PROCEDURE dbo.ReadSalesOrderDetail_MOP
IF OBJECT_ID(N'UpdateSalesOrderDetail_MOP') IS NOT NULL DROP PROCEDURE dbo.UpdateSalesOrderDetail_MOP
IF OBJECT_ID(N'DeleteSalesOrderDetail_MOP') IS NOT NULL DROP PROCEDURE dbo.DeleteSalesOrderDetail_MOP
IF OBJECT_ID(N'ReadALLSalesOrderDetail_MOPForSalesOrderID') IS NOT NULL DROP PROCEDURE dbo.ReadALLSalesOrderDetail_MOPForSalesOrderID
IF OBJECT_ID(N'Sales.SalesOrderDetail_inmem') IS NOT NULL DROP TABLE Sales.SalesOrderDetail_inmem
GO

--create revised version of SalesOrderDetail for in-memory table
CREATE TABLE Sales.SalesOrderDetail_inmem(
	SalesOrderID INT NOT NULL INDEX IX_SalesOrderID HASH WITH (BUCKET_COUNT=10000000),
	SalesOrderDetailID INT NOT NULL IDENTITY(1,1),				--cannot use identidy; see create sproc
	CarrierTrackingNumber nvarchar(25) NULL,
	OrderQty SMALLINT NOT NULL,
	ProductID INT NOT NULL INDEX IX_ProductID HASH WITH (BUCKET_COUNT=10000000),
	SpecialOfferID INT NOT NULL,
	UnitPrice MONEY NOT NULL,
	UnitPriceDiscount MONEY NOT NULL ,
	LineTotal  MONEY NOT NULL,						--cannot use derived column; see create and update sproc
	rowguid UNIQUEIDENTIFIER NOT NULL ,				--cannot use ROWGUIDCOL for inmemory tables, see create sproc
	ModifiedDate datetime NOT NULL ,				--cannot use default, see create sproc
CONSTRAINT [imPK_SalesOrderDetail_SalesOrderID_SalesOrderDetailID] PRIMARY KEY NONCLUSTERED HASH
	([SalesOrderID],[SalesOrderDetailID]) WITH (BUCKET_COUNT=10000000)
) WITH (MEMORY_OPTIMIZED=ON, DURABILITY=SCHEMA_AND_DATA)
GO

IF OBJECT_ID(N'dbo.InmemErrorLog') IS NOT NULL DROP TABLE dbo.InmemErrorLog
GO
CREATE TABLE dbo.InmemErrorLog (
	InmemErrorLogID		INT NOT NULL IDENTITY(1,1) Primary Key,
	[Source]			VARCHAR(50) NOT NULL,
	ErrorNumber			INT NOT NULL,
	CreateDate			DATETIME)
GO

/*	--this code back from original in memory tables didn't allow identity property
IF OBJECT_ID(N'dbo.NextNumber') IS NOT NULL DROP TABLE dbo.NextNumber
GO
CREATE TABLE dbo.NextNumber ( [Table]	VARCHAR(50) NOT NULL PRIMARY KEY, NextNumber	INT)
INSERT dbo.NextNumber
	([Table], NextNumber)
	SELECT 'SalesOrderDetail_inmem' [Table],
			(SELECT TOP 1 SalesOrderDetailID+1 FROM Sales.SalesOrderDetail ORDER BY SalesOrderDetailID DESC) 
GO

IF OBJECT_ID(N'dbo.NextNumber_inmem') IS NOT NULL DROP TABLE dbo.NextNumber_inmem
GO
CREATE TABLE dbo.NextNumber_inmem ( 
	[Table]		VARCHAR(50) COLLATE Latin1_General_100_BIN2 NOT NULL, 
	NextNumber	INT,
CONSTRAINT [imPK_NextNumber_inmem_Table] PRIMARY KEY NONCLUSTERED HASH
	([Table]) WITH (BUCKET_COUNT=1000)
) WITH (MEMORY_OPTIMIZED=ON, DURABILITY=SCHEMA_AND_DATA)

--Populate dbo.NextNumber_inmem
INSERT dbo.NextNumber_inmem
	([Table], NextNumber)
	SELECT 'SalesOrderDetail_inmem' [Table],
			(SELECT TOP 1 SalesOrderDetailID+1 FROM Sales.SalesOrderDetail ORDER BY SalesOrderDetailID DESC) 
GO

IF OBJECT_ID(N'dbo.GetNextNumber') IS NOT NULL DROP PROCEDURE dbo.GetNextNumber;
GO
CREATE PROCEDURE dbo.GetNextNumber(@Table VARCHAR(50),@NextNumber	INT OUTPUT)
AS
	DECLARE @SQL			NVARCHAR(1000);
	DECLARE @ParmDefinition NVARCHAR(500);
	DECLARE @Error			INT;

	SET @SQL = N'UPDATE dbo.NextNumber SET @NextNumber = NextNumber, NextNumber = NextNumber + 1 WHERE [Table] =  '''+@Table + ''';';
	SET @ParmDefinition = N'@NextNumber	INT OUTPUT'
	--PRINT @SQL
	EXEC sp_executesql @SQL, @ParmDefinition, @NextNumber = @NextNumber OUTPUT;
	SET @Error = @@Error;
	RETURN @Error;
GO

IF OBJECT_ID(N'dbo.GetNextNumber_inmem') IS NOT NULL DROP PROCEDURE dbo.GetNextNumber_inmem;
GO
CREATE PROCEDURE dbo.GetNextNumber_inmem (@Table VARCHAR(50),@NextNumber	INT OUTPUT)		--cannot make inmem proc because EXEC statement not allowed :(
AS
	DECLARE @SQL			NVARCHAR(1000);
	DECLARE @ParmDefinition NVARCHAR(500);
	DECLARE @Error			INT;

	SET @SQL = N'UPDATE dbo.NextNumber_inmem SET @NextNumber = NextNumber, NextNumber = NextNumber + 1 WHERE [Table] =  '''+@Table + ''';';
	SET @ParmDefinition = N'@NextNumber	INT OUTPUT'
	--PRINT @SQL
	EXEC sp_executesql @SQL, @ParmDefinition, @NextNumber = @NextNumber OUTPUT;
	SET @Error = @@Error;
	RETURN @Error;
GO
*/
CREATE PROCEDURE CreateSalesOrderDetail_MOP (
	@SalesOrderID				INT,
	@SalesOrderDetailID			INT OUTPUT,
	@CarrierTrackingNumber		VARCHAR(25),
	@OrderQty					SMALLINT,
	@ProductID					INT,
	@SpecialOfferID				INT,
	@UnitPrice					MONEY,
	@UnitPriceDiscount			MONEY,
	@LineTotal					MONEY OUTPUT,
	@rowguid					UNIQUEIDENTIFIER OUTPUT,
	@ModifiedDate				DATETIME OUTPUT
	)
	WITH NATIVE_COMPILATION, SCHEMABINDING,EXECUTE AS OWNER
	AS
	BEGIN ATOMIC
		WITH (TRANSACTION ISOLATION LEVEL = SNAPSHOT, LANGUAGE = 'us_english')

		DECLARE @Error			INT = 0;
		SET @LineTotal			= ISNULL((@UnitPrice*((1.0)-@UnitPriceDiscount))*@OrderQty,0.0);
		SET @ModifiedDate		= ISNULL(@ModifiedDate,GETDATE());

		INSERT Sales.SalesOrderDetail_inmem
			(SalesOrderID,CarrierTrackingNumber, OrderQty, ProductID,					--SalesOrderDetailID has identity property
			 SpecialOfferID,UnitPrice,UnitPriceDiscount,LineTotal,rowguid,ModifiedDate)
			VALUES	(@SalesOrderID,@CarrierTrackingNumber, @OrderQty, @ProductID,
				@SpecialOfferID,@UnitPrice,@UnitPriceDiscount,@LineTotal,
				ISNULL(@rowguid,NewID()),@ModifiedDate);
		SET @SalesOrderDetailID = SCOPE_IDENTITY();

		RETURN;
	END
GO

CREATE PROCEDURE dbo.CreateSalesOrderDetail (
	@SalesOrderID				INT,
	@SalesOrderDetailID			INT OUTPUT,
	@CarrierTrackingNumber		VARCHAR(25),
	@OrderQty					SMALLINT,
	@ProductID					INT,
	@SpecialOfferID				INT,
	@UnitPrice					MONEY,
	@UnitPriceDiscount			MONEY,
	@LineTotal					MONEY OUTPUT,
	@rowguid					UNIQUEIDENTIFIER OUTPUT,
	@ModifiedDate				DATETIME OUTPUT	)
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @Error			INT;
	DECLARE @NextNumber		INT;

	-- number of retries � tune based on the workload
	DECLARE @retry INT = 10

	WHILE (@retry > 0)
		BEGIN
			BEGIN TRY

				EXEC CreateSalesOrderDetail_MOP	@SalesOrderID,				--note missing dbo schema -- not used in MOP
												@SalesOrderDetailID OUTPUT,
												@CarrierTrackingNumber,
												@OrderQty,
												@ProductID,
												@SpecialOfferID,
												@UnitPrice,
												@UnitPriceDiscount,
												@LineTotal OUTPUT,
												@rowguid OUTPUT,
												@ModifiedDate;

			END TRY
			BEGIN CATCH
				SET @retry -= 1
				SET @Error = error_number();
  
				-- the error number for deadlocks (1205) does not need to be included for 
				-- transactions that do not access disk-based tables
				IF (@retry > 0 AND @Error in (41302, 41305, 41325, 41301/*, 1205*/))
					BEGIN
						-- use a delay if there is a high rate of write conflicts (41302)
						--   length of delay should depend on the typical duration of conflicting transactions
						INSERT dbo.InmemErrorLog ([Source], ErrorNumber, CreateDate)		--this is just to see after putting in production if a concurrency issue may occur
							VALUES ('dbo.CreateSalesOrderDetail', @Error,GETDATE())
						WAITFOR DELAY '00:00:00.001'
					END
				-- throw if this is not a qualifying error condition
				;THROW
			END CATCH
		END
END;
GO

CREATE PROCEDURE UpdateSalesOrderDetail_MOP (
	@SalesOrderID				INT,
	@SalesOrderDetailID			INT,
	@CarrierTrackingNumber		VARCHAR(25),
	@OrderQty					SMALLINT,
	@ProductID					INT,
	@SpecialOfferID				INT,
	@UnitPrice					MONEY,
	@UnitPriceDiscount			MONEY,
	@LineTotal					MONEY OUTPUT,
	@rowguid					UNIQUEIDENTIFIER OUTPUT,
	@ModifiedDate				DATETIME OUTPUT
	)
	WITH NATIVE_COMPILATION, SCHEMABINDING,EXECUTE AS OWNER
	AS
	BEGIN ATOMIC
		WITH (TRANSACTION ISOLATION LEVEL = SNAPSHOT, LANGUAGE = 'us_english')

		DECLARE @Error			INT;
		SET @LineTotal			= ISNULL((@UnitPrice*((1.0)-@UnitPriceDiscount))*@OrderQty,0.0);
		SET @ModifiedDate		= ISNULL(@ModifiedDate,GETDATE());

		UPDATE Sales.SalesOrderDetail_inmem
			SET CarrierTrackingNumber	= @CarrierTrackingNumber, 
			    OrderQty				= @OrderQty, 
			    ProductID				= @ProductID,
			    SpecialOfferID			= @SpecialOfferID,
			    UnitPrice				= @UnitPrice,
			    UnitPriceDiscount		= @UnitPriceDiscount,
			    LineTotal				= @LineTotal,
			    rowguid					= ISNULL(@rowguid,NewID()),
			    ModifiedDate			= @ModifiedDate
			WHERE SalesOrderID			= @SalesOrderID
			  AND SalesOrderDetailID	= @SalesOrderDetailID;

		RETURN;
	END
GO

CREATE PROCEDURE dbo.UpdateSalesOrderDetail (
	@SalesOrderID				INT,
	@SalesOrderDetailID			INT,
	@CarrierTrackingNumber		VARCHAR(25),
	@OrderQty					SMALLINT,
	@ProductID					INT,
	@SpecialOfferID				INT,
	@UnitPrice					MONEY,
	@UnitPriceDiscount			MONEY,
	@LineTotal					MONEY OUTPUT,
	@rowguid					UNIQUEIDENTIFIER OUTPUT,
	@ModifiedDate				DATETIME OUTPUT	)
AS
BEGIN
	DECLARE @retry INT = 10;
	DECLARE @Error	INT = 0;
	SET NOCOUNT ON;

	-- number of retries � tune based on the workload

	WHILE (@retry > 0)
		BEGIN
			BEGIN TRY

				EXEC UpdateSalesOrderDetail_MOP	@SalesOrderID,
												@SalesOrderDetailID,
												@CarrierTrackingNumber,
												@OrderQty,
												@ProductID,
												@SpecialOfferID,
												@UnitPrice,
												@UnitPriceDiscount,
												@LineTotal OUTPUT,
												@rowguid OUTPUT,
												@ModifiedDate;

			END TRY
			BEGIN CATCH
				SET @retry -= 1
				SET @Error = error_number();
  
				-- the error number for deadlocks (1205) does not need to be included for 
				-- transactions that do not access disk-based tables
				IF (@retry > 0 AND @Error in (41302, 41305, 41325, 41301/*, 1205*/))
					BEGIN
						-- use a delay if there is a high rate of write conflicts (41302)
						--   length of delay should depend on the typical duration of conflicting transactions
						INSERT dbo.InmemErrorLog ([Source], ErrorNumber, CreateDate)		--this is just to see after putting in production if a concurrency issue may occur
							VALUES ('dbo.UpdateSalesOrderDetail', @Error,GETDATE())
						WAITFOR DELAY '00:00:00.001'
					END
				-- throw if this is not a qualifying error condition
				;THROW
			END CATCH
		END
END;
GO

CREATE PROCEDURE DeleteSalesOrderDetail_MOP (
	@SalesOrderID				INT,
	@SalesOrderDetailID			INT
	)
	WITH NATIVE_COMPILATION, SCHEMABINDING,EXECUTE AS OWNER
	AS
	BEGIN ATOMIC
		WITH (TRANSACTION ISOLATION LEVEL = SNAPSHOT, LANGUAGE = 'us_english')

		DECLARE @Error			INT;

		DELETE Sales.SalesOrderDetail_inmem
			WHERE SalesOrderID			= @SalesOrderID
			  AND SalesOrderDetailID	= @SalesOrderDetailID;

		RETURN;
	END
GO

CREATE PROCEDURE dbo.DeleteSalesOrderDetail (
	@SalesOrderID				INT,
	@SalesOrderDetailID			INT
	)
AS
BEGIN
	-- number of retries � tune based on the workload
	DECLARE @retry INT = 10;
	DECLARE @Error INT = 0;
	SET NOCOUNT ON;


	WHILE (@retry > 0)
		BEGIN
			BEGIN TRY

				EXEC DeleteSalesOrderDetail_MOP	@SalesOrderID,
												@SalesOrderDetailID;

			END TRY
			BEGIN CATCH
				SET @retry -= 1
				SET @Error = error_number();
  
				-- the error number for deadlocks (1205) does not need to be included for 
				-- transactions that do not access disk-based tables
				IF (@retry > 0 AND @Error in (41302, 41305, 41325, 41301/*, 1205*/))
					BEGIN
						-- use a delay if there is a high rate of write conflicts (41302)
						--   length of delay should depend on the typical duration of conflicting transactions
						INSERT dbo.InmemErrorLog ([Source], ErrorNumber, CreateDate)		--this is just to see after putting in production if a concurrency issue may occur
							VALUES ('dbo.DeleteSalesOrderDetail', @Error,GETDATE())
						WAITFOR DELAY '00:00:00.001'
					END
				-- throw if this is not a qualifying error condition
				;THROW
			END CATCH
		END
END;
GO

CREATE PROCEDURE ReadSalesOrderDetail_MOP (
	@SalesOrderID				INT,
	@SalesOrderDetailID			INT )
	WITH NATIVE_COMPILATION, SCHEMABINDING,EXECUTE AS OWNER
	AS
	BEGIN ATOMIC
		WITH (TRANSACTION ISOLATION LEVEL = SNAPSHOT, LANGUAGE = 'us_english')

		DECLARE @Error			INT = 0;
		DECLARE @RowCount		INt = 0;

		SELECT  SalesOrderID,
				SalesOrderDetailID,
				CarrierTrackingNumber,	
				OrderQty,
				ProductID,
				SpecialOfferID,
				UnitPrice,
				UnitPriceDiscount,
				LineTotal,
				rowguid,
				ModifiedDate
			FROM Sales.SalesOrderDetail_inmem
			WHERE SalesOrderID			= @SalesOrderID
			  AND SalesOrderDetailID	= @SalesOrderDetailID;
		SET @RowCount = @@ROWCOUNT;

		RETURN -@RowCount;
	END
GO


CREATE PROCEDURE dbo.ReadALLSalesOrderDetail_MOPForSalesOrderID (
	@SalesOrderID				INT )
	WITH NATIVE_COMPILATION, SCHEMABINDING,EXECUTE AS OWNER
	AS
	BEGIN ATOMIC
		WITH (TRANSACTION ISOLATION LEVEL = SNAPSHOT, LANGUAGE = 'us_english')

		SELECT  SalesOrderID,
				SalesOrderDetailID,
				CarrierTrackingNumber,	
				OrderQty,
				ProductID,
				SpecialOfferID,
				UnitPrice,
				UnitPriceDiscount,
				LineTotal,
				rowguid,
				ModifiedDate
			FROM Sales.SalesOrderDetail_inmem
			WHERE SalesOrderID			= @SalesOrderID

		RETURN
	END
GO

IF OBJECT_ID(N'dbo.ReadALLSalesOrderDetail_DISK_ForSalesOrderID') IS NOT NULL DROP PROCEDURE dbo.ReadALLSalesOrderDetail_DISK_ForSalesOrderID
GO
CREATE PROCEDURE dbo.ReadALLSalesOrderDetail_DISK_ForSalesOrderID (
	@SalesOrderID				INT )
	AS
	BEGIN

		SELECT  SalesOrderID,
				SalesOrderDetailID,
				CarrierTrackingNumber,	
				OrderQty,
				ProductID,
				SpecialOfferID,
				UnitPrice,
				UnitPriceDiscount,
				LineTotal,
				rowguid,
				ModifiedDate
			FROM Sales.SalesOrderDetail
			WHERE SalesOrderID			= @SalesOrderID

		RETURN
	END
GO


--Populate Sales.SalesOrderDetail_inmem
	SET IDENTITY_INSERT Sales.SalesOrderDetail_inmem ON;
GO
		INSERT Sales.SalesOrderDetail_inmem
			(SalesOrderID,SalesOrderDetailID,CarrierTrackingNumber, OrderQty, ProductID,
			 SpecialOfferID,UnitPrice,UnitPriceDiscount,LineTotal,rowguid,ModifiedDate)
			SELECT SalesOrderID,SalesOrderDetailID,CarrierTrackingNumber, OrderQty, ProductID,
			 SpecialOfferID,UnitPrice,UnitPriceDiscount,LineTotal,rowguid,ModifiedDate
				FROM Sales.SalesOrderDetail;
GO
	SET IDENTITY_INSERT Sales.SalesOrderDetail_inmem OFF;
GO

/*
SELECT SalesOrderID, count(SalesOrderDetailID) 
	from Sales.SalesOrderDetail_inmem
	GROUP BY SalesOrderID
	ORDER BY 2 DESC
*/

SET STATISTICS IO ON;
SET STATISTICS TIME ON;
GO
EXEC dbo.ReadALLSalesOrderDetail_DISK_ForSalesOrderID 51751
PRINT '********************************'
EXEC dbo.ReadALLSalesOrderDetail_MOPForSalesOrderID 51751
GO
SET STATISTICS IO ON;
SET STATISTICS TIME ON;
GO

--note no query plan for in-memory sproc

