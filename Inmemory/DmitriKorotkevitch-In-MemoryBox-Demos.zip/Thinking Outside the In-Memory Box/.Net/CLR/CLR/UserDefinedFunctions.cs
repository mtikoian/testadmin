/*****************************************************************************/
/*                    Thinking Outside the In-Memory Box                     */
/*                             PASS Summit 2015                              */
/*                                                                           */
/*                   Written by Dmitri V. Korotkevitch                       */
/*                       http://aboutsqlserver.com                           */
/*                         dk@aboutsqlserver.com                             */
/*****************************************************************************/
/*                Natively Compiled Stored Procedures vs. CLR                */
/*****************************************************************************/
using System;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using Microsoft.SqlServer.Server;

public partial class UserDefinedFunctions
{
    [Microsoft.SqlServer.Server.SqlFunction(
        IsDeterministic = true,
        IsPrecise = true,
        SystemDataAccess = SystemDataAccessKind.None
    )]
    public static SqlInt64 CalcFibonacciCLR(SqlInt32 N, SqlInt32 loopCnt)
    {
        Int64 result = 0, previous, tmp;

        if (N.IsNull || loopCnt.IsNull || N.Value < 0 || N.Value > 93)
            return SqlInt64.Null;
        for (int loop = 0; loop < loopCnt.Value; loop++)
        {
            if (N.Value > 1)
            {
                result = 1;
                previous = 0;
                for (int i = 2; i < N.Value; i++)
                {
                    tmp = result;
                    result += previous;
                    previous = tmp;
                }
            }
            else 
                result = 0;
        }
        return new SqlInt64(result);
    }

    [Microsoft.SqlServer.Server.SqlFunction(
        IsDeterministic = true,
        IsPrecise = false,
        SystemDataAccess = SystemDataAccessKind.None
    )]
    public static SqlDouble CalcDistanceCLR
    (
        SqlInt32 loopCnt,
        SqlDouble fromLat, SqlDouble fromLon,
        SqlDouble toLat, SqlDouble toLon
    )
    {
        double fromLatR, fromLonR, toLatR, toLonR, result = 0;

        for (int i = 0; i < loopCnt.Value; i++)
        {
            fromLatR = Math.PI / 180 * fromLat.Value;
            fromLonR = Math.PI / 180 * fromLon.Value;
            toLatR = Math.PI / 180 * toLat.Value;
            toLonR = Math.PI / 180 * toLon.Value;
            result =
                2 * Math.Asin(
                    Math.Sqrt(
                        Math.Pow(Math.Sin((fromLatR - toLatR) / 2.0), 2) +
                        (
                             Math.Cos(fromLatR) *
                            Math.Cos(toLatR) *
                            Math.Pow(Math.Sin((fromLonR - toLonR) / 2.0), 2)
                        )
                    )
                ) * 20001600.0 / Math.PI;
        };
        return new SqlDouble(result);
    }

}
