/*****************************************************************************/
/*                    Thinking Outside the In-Memory Box                     */
/*                             PASS Summit 2015                              */
/*                                                                           */
/*                   Written by Dmitri V. Korotkevitch                       */
/*                       http://aboutsqlserver.com                           */
/*                         dk@aboutsqlserver.com                             */
/*****************************************************************************/
/*                    Enforcing Uniqueness (Session 2)                       */
/*****************************************************************************/

set nocount on
go

use [InMemoryBoxDemo]
go

declare
	@ProductId int

exec dbo.InsertProduct
   'PASS Summit 2015 Sessions Recording'
    ,'Great Education Material!'
	,@ProductId output
