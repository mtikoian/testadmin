/*****************************************************************************/
/*                    Thinking Outside the In-Memory Box                     */
/*                             PASS Summit 2015                              */
/*                                                                           */
/*                   Written by Dmitri V. Korotkevitch                       */
/*                       http://aboutsqlserver.com                           */
/*                         dk@aboutsqlserver.com                             */
/*****************************************************************************/
/*  Comparing Performance of Memory-Optimized Table Variable in DW Use-Case  */
/*****************************************************************************/


set nocount on
go

use [InMemoryBoxDemo]
go

set statistics time on

update dw.FactSalesETLDisk set Quantity += 1;
update dw.FactSalesETLDisk set OrderNum += '1234567890';

update dw.FactSalesETLMem set Quantity += 1;
update dw.FactSalesETLMem set OrderNum += '1234567890';

set statistics time off

