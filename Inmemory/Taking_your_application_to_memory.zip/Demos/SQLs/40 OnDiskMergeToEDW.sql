USE Effektor

merge [EDW_OnDisk].[Sales] as target
using (select OrderQuantity, 
			  UnitPrice, 
			  DueDate, 
			  OrderDate, 
			  ShipDate, 
			  CarrierTrackingNumber, 
			  ProductKey, 
			  SalesTerritoryKey, 
			  CurrencyKey, 
			  SalesOrderLineNumber, 
			  SalesOrderNumber, 
			  EmployeeKey, 
			  ResellerKey
			FROM [DSA_OnDisk].[ERP_Sales]) DSA
		ON target.SalesOrderNumber = DSA.SalesOrderNumber
		AND target.SalesOrderNumber = DSA.SalesOrderNumber
WHEN MATCHED THEN
UPDATE 
	SET target.OrderQuantity = dsa.OrderQuantity, 
		target.UnitPrice = dsa.UnitPrice, 
		target.DueDate = dsa.DueDate, 
		target.OrderDate = dsa.OrderDate, 
		target.ShipDate = dsa.ShipDate, 
		target.CarrierTrackingNumber = dsa.CarrierTrackingNumber, 
		target.ProductOriginalKey = dsa.ProductKey, 
		target.SalesTerritoryOriginalKey = dsa.SalesTerritoryKey, 
		target.CurrencyOriginalKey = dsa.CurrencyKey, 
        target.EmployeeOriginalKey = dsa.EmployeeKey, 
		target.ResellerOriginalKey = dsa.ResellerKey
WHEN NOT MATCHED BY TARGET THEN
 INSERT (OrderQuantity, 
			  UnitPrice, 
			  DueDate, 
			  OrderDate, 
			  ShipDate, 
			  CarrierTrackingNumber, 
			  ProductOriginalKey, 
			  SalesTerritoryOriginalKey, 
			  CurrencyOriginalKey, 
			  SalesOrderLineNumber, 
			  SalesOrderNumber, 
			  EmployeeOriginalKey, 
			  ResellerOriginalKey)
	VALUES (dsa.OrderQuantity, 
			  dsa.UnitPrice, 
			  dsa.DueDate, 
			  dsa.OrderDate, 
			  dsa.ShipDate, 
			  dsa.CarrierTrackingNumber, 
			  dsa.ProductKey, 
			  dsa.SalesTerritoryKey, 
			  dsa.CurrencyKey, 
			  dsa.SalesOrderLineNumber, 
			  dsa.SalesOrderNumber, 
			  dsa.EmployeeKey, 
			  dsa.ResellerKey)
;