USE [AdventureWorks2012]
GO

-- ~120.000 rows

--Clear buffer
--Remember set showplan on...
CHECKPOINT; 
GO 
DBCC DROPCLEANBUFFERS; 
GO

SELECT s.[OrderQty]
      ,s.[ProductID]
      ,s.[UnitPrice]
	  ,p.Name
	 ,(([UnitPrice]*[OrderQty]) / cast(sum([UnitPrice]*[OrderQty]) over (partition by p.Name order by p.Name) as decimal)*100) as [Share of total product sales]
	 -- ,(([UnitPrice]*[OrderQty]) / cast(sum([UnitPrice]*[OrderQty]) over (partition by p.productid order by p.productid) as decimal)*100) as [Share of total product sales]
  --  FROM [Sales].[SalesOrderDetail_inmem2] s  join [Production].[Product_inmem] p
  --  FROM [Sales].[SalesOrderDetail_inmem] s join [Production].[Product_inmem] p
    FROM [Sales].[SalesOrderDetail] s join [Production].[Product] p
  on s.[ProductID] = p.[ProductID]
  --where p.ProductID In (712,1,879,3,2,877,316)
GO



  --which tables are optimized?
  select name, is_memory_optimized from sys.tables order by 2

  --lets take a look at the index'es, bucket counts and chain lenghts  
SELECT hs.object_id, object_name(hs.object_id) AS 'object name', i.name as 'index name', hs.*
FROM sys.dm_db_xtp_hash_index_stats AS hs 
JOIN sys.indexes AS i ON hs.object_id=i.object_id AND hs.index_id=i.index_id
where object_name(hs.object_id) = 'SalesOrderDetail_inmem';