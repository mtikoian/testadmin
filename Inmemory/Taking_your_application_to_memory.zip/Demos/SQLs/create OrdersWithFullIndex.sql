USE [hkNorthwind]
GO

/****** Object:  Table [dbo].[Orders]    Script Date: 10-10-2013 08:52:24 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[OrdersWithFullIndex]
(
	[OrderID] [int] NOT NULL,
	[CustomerID] [nchar](5) NOT NULL,
	[EmployeeID] [int] NOT NULL,
	[OrderDate] [datetime] NOT NULL,
	[RequiredDate] [datetime] NULL,
	[ShippedDate] [datetime] NOT NULL,
	[ShipVia] [int] NOT NULL,
	[Freight] [money] NULL,
	[ShipName] [nvarchar](40) NULL,
	[ShipAddress] [nvarchar](60) NULL,
	[ShipCity] [nvarchar](15) NULL,
	[ShipRegion] [nvarchar](15) NULL,
	[ShipPostalCode] [nvarchar](10) NOT NULL,
	[ShipCountry] [nvarchar](15) NULL
 PRIMARY KEY NONCLUSTERED HASH 
(
	[OrderID], [CustomerID], [EmployeeID], [OrderDate]
)WITH ( BUCKET_COUNT = 1048576)
)WITH ( MEMORY_OPTIMIZED = ON , DURABILITY = SCHEMA_AND_DATA )
;
GO
--Remember to update stats - no auto update in in-memory tables
  exec sp_updatestats;
  GO


