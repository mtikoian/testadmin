USE [Effektor]
GO

/****** Object:  StoredProcedure [NativeSPs].[ImportEmployee]    Script Date: 06-03-2014 10:20:51 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



CREATE PROCEDURE [NativeSPs].[ImportEmployee]

WITH NATIVE_COMPILATION, SCHEMABINDING, EXECUTE AS OWNER
AS BEGIN ATOMIC WITH
(
 TRANSACTION ISOLATION LEVEL = SNAPSHOT, LANGUAGE = N'us_english'
)

--declaring variables
declare @i int = 1, @max int
select @max = max(cast(BusinessKey as int)) from dsa.ERP_Employee

declare @DisplayName nvarchar(50), 
		@BusinessKey nvarchar(250),
		@ParentBusinessKey nvarchar(200) 

--starting the loop
while @i <= @max
begin

--filling variables with the values for the current row
select
	   @DisplayName = DisplayName
      ,@BusinessKey =  BusinessKey
	  ,@ParentBusinessKey = ParentBusinessKey 
FROM dsa.ERP_Employee
where cast(BusinessKey as int) = @i

--declaring variables for the exists
declare @LineExists bit = 0, @EDWID bigint, @EDWParentKey nvarchar(200)


--deciding if the row exits in the EDW
SELECT TOP 1 @LineExists = 1, @EDWID = Id, @EDWParentKey = ParentBusinessKey from edw.Employee
	WHERE BusinessKey = @BusinessKey

--If the row doesn't exist OR it exits but the parentkey has changes we insert the new row (type2)
IF (@LineExists = 0 OR (@LineExists = 1 AND IsNull(@EDWParentKey  COLLATE Latin1_General_100_BIN2,'NA'  COLLATE Latin1_General_100_BIN2) <> IsNull(@ParentBusinessKey  COLLATE Latin1_General_100_BIN2,'NA'  COLLATE Latin1_General_100_BIN2)))
BEGIN
	declare @NewID bigint = 0
	select @NewID = IsNull(max(id),0) from edw.Employee
	insert into edw.Employee ([ID], [ParentBusinessKey], [DisplayName], [ImportId], [IsCurrent], [StartDate], [BusinessKey])
					  values (@NewID+1,@ParentBusinessKey, @DisplayName,	0,	1, cast(getdate() as date),@BusinessKey )
END

--If the row exits but the parentkey is the same we update the displayname (type 1 change)
IF (@LineExists = 1 AND IsNull(@EDWParentKey  COLLATE Latin1_General_100_BIN2,'NA'  COLLATE Latin1_General_100_BIN2) = IsNull(@ParentBusinessKey  COLLATE Latin1_General_100_BIN2,'NA'  COLLATE Latin1_General_100_BIN2))
BEGIN
UPDATE edw.Employee
SET
	[DisplayName] = @DisplayName
WHERE Id = @EDWID
END

--If the row exits but the parentkey has changed we set the enddate for the old row (type2)
IF (@LineExists = 1 AND IsNull(@EDWParentKey  COLLATE Latin1_General_100_BIN2,'NA'  COLLATE Latin1_General_100_BIN2) <> IsNull(@ParentBusinessKey  COLLATE Latin1_General_100_BIN2,'NA'  COLLATE Latin1_General_100_BIN2))
BEGIN
UPDATE edw.Employee
SET
	[EndDate] = cast(getdate() as date)
WHERE Id = @EDWID
END

set @i = @i+1
END

END




GO


