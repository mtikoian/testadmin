 INSERT INTO EDW.Sales ( 
			  OrderQuantity, 
			  UnitPrice, 
			  DueDate, 
			  OrderDate, 
			  ShipDate, 
			  CarrierTrackingNumber, 
			  ProductOriginalKey, 
			  SalesTerritoryOriginalKey, 
			  CurrencyOriginalKey, 
			  SalesOrderLineNumber, 
			  SalesOrderNumber, 
			  EmployeeOriginalKey, 
			  ResellerOriginalKey,
			  EmployeeId,
			  ResellerId,
			  ProductId,
			  SalesTerritoryId,
			  CurrencyId
			 )
	SELECT 
			  dsa.OrderQuantity, 
			  dsa.UnitPrice, 
			  dsa.DueDate, 
			  dsa.OrderDate, 
			  dsa.ShipDate, 
			  dsa.CarrierTrackingNumber, 
			  dsa.ProductKey, 
			  dsa.SalesTerritoryKey, 
			  dsa.CurrencyKey, 
			  dsa.SalesOrderLineNumber, 
			  dsa.SalesOrderNumber, 
			  dsa.EmployeeKey, 
			  dsa.ResellerKey,
			  -1 AS EmployeeId,
			  -1 AS ResellerId,
			  -1 AS ProductId,
			  -1 AS SalesTerritoryId,
			  -1 AS CurrencyId
	FROM [DSA].[Sales]

;
UPDATE S
set EmployeeId = E.EmployeeId
FROM EDW.Sales S
INNER JOIN [edw].[Employee] E 
ON S.EmployeeKey = E.EmployeeKey and IsCurrent = 1