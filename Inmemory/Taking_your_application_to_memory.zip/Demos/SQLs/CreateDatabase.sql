
USE master
GO
if exists (select * from sys.databases where name='hkNorthwind2')
drop database hkNorthwind2
go

CREATE DATABASE hkNorthwind2 COLLATE Latin1_General_100_BIN2
GO

ALTER DATABASE hkNorthwind2 ADD FILEGROUP [hkNorthwind_mod2] CONTAINS MEMORY_OPTIMIZED_DATA
GO

ALTER DATABASE hkNorthwind2 ADD FILE(NAME = 'hkNorthwind_mod_dir2', FILENAME='c:\data\hkNorthwind_mod2') TO FILEGROUP [hkNorthwind_mod2]
go


SET QUOTED_IDENTIFIER ON
GO

USE hkNorthwind2


CREATE TABLE Employees (
EmployeeID int  NOT NULL , 
LastName nvarchar (20) NOT NULL INDEX IX_LastName HASH(LastName) WITH (BUCKET_COUNT=1024),
FirstName nvarchar (10) NOT NULL ,
Title nvarchar (30)  NULL ,
TitleOfCourtesy nvarchar (25)  NULL , 
BirthDate datetime  NULL , 
HireDate datetime  NULL , 
Address nvarchar (60)  NULL , 
City nvarchar (15)  NULL , 
Region nvarchar (15)  NULL , 
PostalCode nvarchar (10),
Country nvarchar (15)  NULL ,
HomePhone nvarchar (24) NULL ,
Extension nvarchar (4)  NULL ,
Photo bit NOT NULL , 
Notes nvarchar (2000)  NULL , 
ReportsTo int NULL ,
PhotoPath nvarchar (255) NULL ,
CONSTRAINT PK_Employees PRIMARY KEY NONCLUSTERED HASH(EmployeeID)  WITH (BUCKET_COUNT=1024)
)WITH ( MEMORY_OPTIMIZED = ON , DURABILITY = SCHEMA_AND_DATA )
GO