USE [AdventureWorks2012]
GO

--Show the query running while stress testing

SELECT [ProductID]
      ,sum([OrderQty]) as [OrderQty]
      ,sum(([UnitPrice]*(1-[UnitPriceDiscount]))*[OrderQty]) AS SalesPrProduct
  FROM [Sales].[SalesOrderDetail_inmem]
GROUP BY [ProductID]

select count(*)  FROM [Sales].[SalesOrderDetail_inmem]
