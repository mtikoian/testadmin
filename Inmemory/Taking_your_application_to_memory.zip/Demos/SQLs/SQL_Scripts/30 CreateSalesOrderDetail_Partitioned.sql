USE [AdventureWorks2012]
GO

/****** Object:  View [Sales].[SalesOrderDetail_Partitioned]    Script Date: 25-02-2014 15:37:48 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE view [Sales].[SalesOrderDetail_Partitioned]
as
SELECT [SalesOrderID]
      ,[SalesOrderDetailID]
      ,[CarrierTrackingNumber]
      ,[OrderQty]
      ,[ProductID]
      ,[SpecialOfferID]
      ,[UnitPrice]
      ,[UnitPriceDiscount]
      ,[ModifiedDate]
  FROM [Sales].[SalesOrderDetail_inmem50]
UNION ALL
SELECT [SalesOrderID]
      ,[SalesOrderDetailID]
      ,[CarrierTrackingNumber]
      ,[OrderQty]
      ,[ProductID]
      ,[SpecialOfferID]
      ,[UnitPrice]
      ,[UnitPriceDiscount]
      ,[ModifiedDate]
  FROM [Sales].[SalesOrderDetail_100]



GO


