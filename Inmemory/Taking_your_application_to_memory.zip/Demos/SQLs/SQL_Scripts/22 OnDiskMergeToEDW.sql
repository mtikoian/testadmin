USE Effektor

merge [EDW].[Sales] as target
using (select S.OrderQuantity, 
			  S.UnitPrice, 
			  S.DueDate, 
			  S.OrderDate, 
			  S.ShipDate, 
			  S.CarrierTrackingNumber, 
			  S.ProductKey, 
			  S.SalesTerritoryKey, 
			  S.CurrencyKey, 
			  S.SalesOrderLineNumber, 
			  S.SalesOrderNumber, 
			  S.EmployeeKey, 
			  S.ResellerKey,
			  IsNull(E.EmployeeId,-1) AS EmployeeId,
			  IsNull(R.ResellerId,-1) AS ResellerId,
			  IsNull(P.ProductId, -1) AS ProductId,
			  IsNull(ST.SalesTerritoryId,-1) AS SalesTerritoryId,
			  IsNull(C.CurrencyId,-1) AS CurrencyId
			FROM [DSA].[Sales] S
			LEFT JOIN [edw].[Employee] E ON S.EmployeeKey = E.EmployeeKey and IsCurrent = 1
			LEFT JOIN [edw].[Reseller] R ON S.ResellerKey = R.ResellerKey and IsCurrent = 1
			LEFT JOIN [edw].[Product] P ON S.ProductKey  = P.ProductKey and IsCurrent = 1
			LEFT JOIN [edw].[SalesTerritory] ST ON S.SalesTerritoryKey = ST.SalesTerritoryKey and IsCurrent = 1
			LEFT JOIN [edw].[Currency] C ON S.CurrencyKey = C.CurrencyKey and IsCurrent = 1
			) DSA
		ON target.SalesOrderNumber = DSA.SalesOrderNumber
		AND target.SalesOrderLineNumber = DSA.SalesOrderLineNumber
WHEN MATCHED THEN
UPDATE 
	SET target.OrderQuantity = dsa.OrderQuantity, 
		target.UnitPrice = dsa.UnitPrice, 
		target.DueDate = dsa.DueDate, 
		target.OrderDate = dsa.OrderDate, 
		target.ShipDate = dsa.ShipDate, 
		target.CarrierTrackingNumber = dsa.CarrierTrackingNumber, 
		target.ProductOriginalKey = dsa.ProductKey, 
		target.SalesTerritoryOriginalKey = dsa.SalesTerritoryKey, 
		target.CurrencyOriginalKey = dsa.CurrencyKey, 
        target.EmployeeOriginalKey = dsa.EmployeeKey, 
		target.ResellerOriginalKey = dsa.ResellerKey
		target.EmployeeId       = dsa.EmployeeId
		target.ResellerId		= dsa.ResellerId
		target.ProductId,		= dsa.ProductId,
		target.SalesTerritoryId	= dsa.SalesTerritoryId
		target.CurrencyId		= dsa.CurrencyId
WHEN NOT MATCHED BY TARGET THEN
 INSERT		 (OrderQuantity, 
			  UnitPrice, 
			  DueDate, 
			  OrderDate, 
			  ShipDate, 
			  CarrierTrackingNumber, 
			  ProductOriginalKey, 
			  SalesTerritoryOriginalKey, 
			  CurrencyOriginalKey, 
			  SalesOrderLineNumber, 
			  SalesOrderNumber, 
			  EmployeeOriginalKey, 
			  ResellerOriginalKey,
			  EmployeeId,
			  ResellerId,
			  ProductId,
			  SalesTerritoryId,
			  CurrencyId)
	VALUES (dsa.OrderQuantity, 
			  dsa.UnitPrice, 
			  dsa.DueDate, 
			  dsa.OrderDate, 
			  dsa.ShipDate, 
			  dsa.CarrierTrackingNumber, 
			  dsa.ProductKey, 
			  dsa.SalesTerritoryKey, 
			  dsa.CurrencyKey, 
			  dsa.SalesOrderLineNumber, 
			  dsa.SalesOrderNumber, 
			  dsa.EmployeeKey, 
			  dsa.ResellerKey,
			  dsa.EmployeeId,
			  dsa.ResellerId,
			  dsa.ProductId,
			  dsa.SalesTerritoryId,
			  dsa.CurrencyId)
;