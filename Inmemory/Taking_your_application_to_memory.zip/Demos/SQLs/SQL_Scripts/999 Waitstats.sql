USE [AdventureWorks2012]
GO

/*
DBCC SQLPERF ('sys.dm_os_wait_stats', CLEAR);
*/


select * from sys.dm_os_wait_stats 
where wait_type in ('IO_COMPLETION', 'ASYNC_IO_COMPLETION')