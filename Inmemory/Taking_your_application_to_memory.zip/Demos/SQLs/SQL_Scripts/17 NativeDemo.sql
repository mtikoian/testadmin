use [AdventureWorks2012];
;
--drop PROCEDURE dbo.NativeDemo;
--go 


CREATE PROCEDURE dbo.NativeDemo
WITH NATIVE_COMPILATION, SCHEMABINDING, EXECUTE AS OWNER
AS BEGIN ATOMIC WITH
(
 TRANSACTION ISOLATION LEVEL = SNAPSHOT, LANGUAGE = N'us_english'
)
SELECT [OrderQty]
      ,s.[ProductID]
      ,[UnitPrice]
	  ,p.Name
	  ,SUM(([UnitPrice]*[OrderQty]) / cast([UnitPrice]*[OrderQty] as decimal)*100) as [Share of total product sales]
  FROM [Sales].[SalesOrderDetail_inmem] s join [Production].[Product_inmem] p
  on s.[ProductID] = p.[ProductID]
  GROUP BY 
  [OrderQty]
      ,s.[ProductID]
      ,[UnitPrice]
	  ,p.Name
END
GO








--DBCC CHECKDB (AdventureWorks2012)