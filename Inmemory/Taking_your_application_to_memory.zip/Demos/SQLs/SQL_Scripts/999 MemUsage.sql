USE [AdventureWorks2012]
GO

select object_name(object_id), * from sys.dm_db_xtp_table_memory_stats