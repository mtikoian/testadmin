USE [AdventureWorks2012]
GO
--Clear buffer
DBCC FREEPROCCACHE;

--Activate Show plan

SELECT [OrderQty]
      ,s.[ProductID]
      ,[UnitPrice]
	  ,p.Name
	 ,(([UnitPrice]*[OrderQty]) / cast(sum([UnitPrice]*[OrderQty]) over (partition by p.Name order by p.Name) as decimal)*100) as [Share of total product sales]
	--   ,(([UnitPrice]*[OrderQty]) / cast(sum([UnitPrice]*[OrderQty]) over (partition by p.productid order by p.productid) as decimal)*100) as [Share of total product sales]
   FROM [Sales].[SalesOrderDetail_inmem] s join [Production].[Product_inmem] p
  --FROM [Sales].[SalesOrderDetail] s join [Production].[Product] p
  on s.[ProductID] = p.[ProductID]
  where p.ProductID In (712,1,879,3,2,877,316)
GO


