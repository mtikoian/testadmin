  use AdventureWorks2012;

  --which tables are optimized?
  select name, is_memory_optimized from sys.tables order by 2

  --DLLs
  SELECT name, description FROM sys.dm_os_loaded_modules 
	WHERE description = 'XTP Native DLL' 

 
--lets take a look at the index'es, bucket counts and chain lenghts  
SELECT hs.object_id, object_name(hs.object_id) AS 'object name', i.name as 'index name', hs.*
FROM sys.dm_db_xtp_hash_index_stats AS hs 
JOIN sys.indexes AS i ON hs.object_id=i.object_id AND hs.index_id=i.index_id
where object_name(hs.object_id) = 'SalesOrderHeader_inmem';