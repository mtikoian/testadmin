USE [hkNorthwind]
GO

/****** Object:  Table [dbo].[Orders]    Script Date: 10-10-2013 08:52:24 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
--DROP TABLE [dbo].[OrdersWithNonClusteredIndex];
CREATE TABLE [dbo].[OrdersWithNonClusteredIndex]
(
   -- [ID] bigint NOT NULL PRIMARY KEY NONCLUSTERED HASH WITH (BUCKET_COUNT=20000) DEFAULT (next value for [dbo].[Seq_OrderID]),
	[ID] uniqueidentifier  NOT NULL PRIMARY KEY NONCLUSTERED DEFAULT (NewID()),
	[OrderID] [int] NOT NULL index IX_OrderID NONCLUSTERED,
	[CustomerID] [nchar](5) NOT NULL index IX_CustomerID NONCLUSTERED,
	[EmployeeID] [int] NOT NULL index IX_EmployeeID NONCLUSTERED,
	[OrderDate] [datetime] NOT NULL index IX_OrderDateID NONCLUSTERED,
	[RequiredDate] [datetime] NULL,
	[ShippedDate] [datetime] NOT NULL,
	[ShipVia] [int] NOT NULL,
	[Freight] [money] NULL,
	[ShipName] [nvarchar](40) NULL,
	[ShipAddress] [nvarchar](60) NULL,
	[ShipCity] [nvarchar](15) NULL,
	[ShipRegion] [nvarchar](15) NULL,
	[ShipPostalCode] [nvarchar](10) NOT NULL,
	[ShipCountry] [nvarchar](15) NULL

)WITH ( MEMORY_OPTIMIZED = ON , DURABILITY = SCHEMA_AND_DATA )
;
GO
/*
insert into [dbo].[OrdersWithNonClusteredIndex]
(OrderID, CustomerID, EmployeeID, OrderDate, RequiredDate, ShippedDate, ShipVia, Freight, ShipName, ShipAddress, ShipCity, ShipRegion, ShipPostalCode, ShipCountry)
select 
OrderID, CustomerID, EmployeeID, OrderDate, RequiredDate, ShippedDate, ShipVia, Freight, ShipName, ShipAddress, ShipCity, ShipRegion, ShipPostalCode, ShipCountry
from dbo.Orders
CROSS JOIN master..spt_values AS a
WHERE
	a.type = 'p'
	AND a.number BETWEEN 0 AND 200
--Remember to update stats - no auto update in in-memory tables
  exec sp_updatestats;
  */


