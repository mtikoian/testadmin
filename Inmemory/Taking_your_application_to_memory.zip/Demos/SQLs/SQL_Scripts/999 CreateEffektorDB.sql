USE master
GO
if exists (select * from sys.databases where name='hkNorthwind2')
drop database hkNorthwind2
go

--create a database
CREATE DATABASE Effektor COLLATE Latin1_General_100_BIN2
GO

--add a filegroup to hold checkpoint files
ALTER DATABASE Effektor ADD FILEGROUP 
[xtpEffektor] CONTAINS MEMORY_OPTIMIZED_DATA
GO

--add a directory where the checkpoint files are kept
ALTER DATABASE Effektor ADD 
FILE(NAME = 'xtpEffektor', FILENAME='c:\data\xtpEffektor') 
TO FILEGROUP [xtpEffektor]
go


SET QUOTED_IDENTIFIER ON
GO

USE Effektor;
GO
create schema dsa;
GO
create schema edw;
GO
create schema NativeSPs;
GO
create schema DM;
GO
CREATE TABLE dsa.[Currency] (
    [CurrencyKey] int not null,
    [CurrencyName] nvarchar(50)
CONSTRAINT PK_CurrencyKey PRIMARY KEY NONCLUSTERED HASH(CurrencyKey)  WITH (BUCKET_COUNT=1024)
)WITH ( MEMORY_OPTIMIZED = ON , DURABILITY = SCHEMA_ONLY )
GO


CREATE TABLE dsa.[Reseller] (
    [ResellerKey] int not null,
    [ResellerName] nvarchar(50)
CONSTRAINT PK_Reseller PRIMARY KEY NONCLUSTERED HASH(ResellerKey)  WITH (BUCKET_COUNT=1024)
)WITH ( MEMORY_OPTIMIZED = ON , DURABILITY = SCHEMA_ONLY )
GO

CREATE TABLE dsa.[Product] (
    [ProductKey] int not null,
    [EnglishProductName] nvarchar(80)
CONSTRAINT PK_ProductKey PRIMARY KEY NONCLUSTERED HASH(ProductKey)  WITH (BUCKET_COUNT=1024)
)WITH ( MEMORY_OPTIMIZED = ON , DURABILITY = SCHEMA_ONLY )
GO

CREATE TABLE dsa.[Employee] (
    [EmployeeKey] int not null,
    [ParentEmployeeKey] int,
    [FuldName] nvarchar(200)
CONSTRAINT PK_EmployeeKey PRIMARY KEY NONCLUSTERED HASH(EmployeeKey)  WITH (BUCKET_COUNT=1024)
)WITH ( MEMORY_OPTIMIZED = ON , DURABILITY = SCHEMA_ONLY )
GO

CREATE TABLE dsa.[SalesTerritory] (
    [SalesTerritoryKey] int not null,
    [SalesTerritoryRegion] nvarchar(50)
CONSTRAINT PK_SalesTerritoryKey PRIMARY KEY NONCLUSTERED HASH(SalesTerritoryKey)  WITH (BUCKET_COUNT=1024)
)WITH ( MEMORY_OPTIMIZED = ON , DURABILITY = SCHEMA_ONLY )
GO

CREATE TABLE dsa.[Sales] (
    [ProductKey] int,
    [ResellerKey] int,
    [EmployeeKey] int,
    [CurrencyKey] int,
    [SalesTerritoryKey] int,
    [SalesOrderNumber] nvarchar(20),
    [SalesOrderLineNumber] tinyint,
    [OrderQuantity] smallint,
    [UnitPrice] money,
    [CarrierTrackingNumber] nvarchar(25),
    [OrderDate] datetime,
    [DueDate] datetime,
    [ShipDate] datetime,
    [SalesKey] int not null
CONSTRAINT PK_SalesKey PRIMARY KEY NONCLUSTERED HASH(SalesKey)  WITH (BUCKET_COUNT=2000000)
)WITH ( MEMORY_OPTIMIZED = ON , DURABILITY = SCHEMA_ONLY )
GO

--EDW
create table edw.Employee  (
	[ID] int not null, 
	[ParentID] INT,
	[ParentBusinessKey] int, 
	[DisplayName] nvarchar(255), 
	[ImportId] int, 
	[IsCurrent] bit, 
	[StartDate] date, 
	[EndDate] date,
	[BusinessKey] int not null
PRIMARY KEY NONCLUSTERED HASH
(
	ID
)  WITH (BUCKET_COUNT=1024),
INDEX [IX_EmployeeBusinessKey] NONCLUSTERED HASH 
(
	[BusinessKey]
)WITH ( BUCKET_COUNT = 1024)
)WITH ( MEMORY_OPTIMIZED = ON , DURABILITY = SCHEMA_AND_DATA )
GO

CREATE TABLE edw.[SalesTerritory] (
    [id] int not null,
    [BusinessKey] int not null,
	[IsCurrent] bit,
    [SalesTerritoryRegion] nvarchar(50)
PRIMARY KEY NONCLUSTERED HASH
(
	id
)  WITH (BUCKET_COUNT=1024),
INDEX [IX_SalesTerritoryBusinessKey] NONCLUSTERED HASH 
(
	[BusinessKey]
)WITH ( BUCKET_COUNT = 1024)
)WITH ( MEMORY_OPTIMIZED = ON , DURABILITY = SCHEMA_AND_DATA )
GO

CREATE TABLE edw.[Reseller] (
    [id] int not null,
    [BusinessKey] int not null,
	[IsCurrent] bit,
    [ResellerName] nvarchar(50)
PRIMARY KEY NONCLUSTERED HASH
(
	id
)  WITH (BUCKET_COUNT=1024),
INDEX [IX_ResellerBusinessKey] NONCLUSTERED HASH 
(
	[BusinessKey]
)WITH ( BUCKET_COUNT = 1024)
)WITH ( MEMORY_OPTIMIZED = ON , DURABILITY = SCHEMA_AND_DATA )
GO

CREATE TABLE edw.[Product] (
    [id] int not null,
    [BusinessKey] int not null,
	[IsCurrent] bit,
    [ProductName] nvarchar(50)
PRIMARY KEY NONCLUSTERED HASH
(
	id
)  WITH (BUCKET_COUNT=1024),
INDEX [IX_ProductBusinessKey] NONCLUSTERED HASH 
(
	[BusinessKey]
)WITH ( BUCKET_COUNT = 1024)
)WITH ( MEMORY_OPTIMIZED = ON , DURABILITY = SCHEMA_AND_DATA )
GO

CREATE TABLE edw.[Currency] (
    [id] int not null,
    [BusinessKey] int not null,
	[IsCurrent] bit,
    [CurrencyName] nvarchar(50)
PRIMARY KEY NONCLUSTERED HASH
(
	id
)  WITH (BUCKET_COUNT=1024),
INDEX [IX_CurrencyBusinessKey] NONCLUSTERED HASH 
(
	[BusinessKey]
)WITH ( BUCKET_COUNT = 1024)
)WITH ( MEMORY_OPTIMIZED = ON , DURABILITY = SCHEMA_AND_DATA )
GO

create table edw.Sales (
id int not null, 
StatusType int, 
ImportId int, 
OrderQuantity smallint, 
UnitPrice money, 
DueDate datetime, 
OrderDate datetime, 
ShipDate datetime, 
CarrierTrackingNumber nvarchar(25), 
ProductOriginalKey int, 
SalesTerritoryOriginalKey int, 
CurrencyOriginalKey int, 
SalesOrderLineNumber int not null, 
SalesOrderNumber nvarchar(20) not null, 
EmployeeOriginalKey int, 
ResellerOriginalKey int, 
EmployeeId int, 
ResellerId int, 
ProductId int, 
SalesTerritoryId int, 
CurrencyId int 
PRIMARY KEY NONCLUSTERED HASH
(
	id
)  WITH (BUCKET_COUNT=2000000),
INDEX [IX_SalesOrderInfo] NONCLUSTERED HASH 
(
	SalesOrderNumber, SalesOrderLineNumber
)WITH ( BUCKET_COUNT = 2000000)
)WITH ( MEMORY_OPTIMIZED = ON , DURABILITY = SCHEMA_AND_DATA )
GO

--NativeSPs
CREATE PROCEDURE [NativeSPs].[ImportEmployee]

WITH NATIVE_COMPILATION, SCHEMABINDING, EXECUTE AS OWNER
AS BEGIN ATOMIC WITH
(
 TRANSACTION ISOLATION LEVEL = SNAPSHOT, LANGUAGE = N'us_english'
)

--declaring variables
declare @i int = 1, @max int
select @max = max(cast(EmployeeKey as int)) from dsa.Employee

declare @DisplayName nvarchar(50), 
		@BusinessKey nvarchar(250),
		@ParentBusinessKey nvarchar(200) 

--starting the loop
while @i <= @max
begin

--filling variables with the values for the current row
select
	   @DisplayName = FuldName
      ,@BusinessKey =  EmployeeKey
	  ,@ParentBusinessKey = ParentEmployeeKey 
FROM dsa.Employee
where cast(EmployeeKey as int) = @i

--declaring variables for the exists
declare @LineExists bit = 0, @EDWID bigint, @EDWParentKey nvarchar(200)


--deciding if the row exits in the EDW
SELECT TOP 1 @LineExists = 1, @EDWID = ID, @EDWParentKey = ParentBusinessKey from edw.Employee
	WHERE BusinessKey = @BusinessKey

--If the row doesn't exist OR it exits but the parentkey has changes we insert the new row (type2)
IF (@LineExists = 0 OR (@LineExists = 1 AND IsNull(@EDWParentKey  COLLATE Latin1_General_100_BIN2,'NA'  COLLATE Latin1_General_100_BIN2) <> IsNull(@ParentBusinessKey  COLLATE Latin1_General_100_BIN2,'NA'  COLLATE Latin1_General_100_BIN2)))
BEGIN
	declare @NewID bigint = 0
	select @NewID = IsNull(max(ID),0) from edw.Employee
	insert into edw.Employee ([ID], [ParentBusinessKey], [DisplayName], [ImportId], [IsCurrent], [StartDate], [BusinessKey])
					  values (@NewID+1,@ParentBusinessKey, @DisplayName,	0,	1, cast(getdate() as date),@BusinessKey )
END

--If the row exits but the parentkey is the same we update the displayname (type 1 change)
IF (@LineExists = 1 AND IsNull(@EDWParentKey  COLLATE Latin1_General_100_BIN2,'NA'  COLLATE Latin1_General_100_BIN2) = IsNull(@ParentBusinessKey  COLLATE Latin1_General_100_BIN2,'NA'  COLLATE Latin1_General_100_BIN2))
BEGIN
UPDATE edw.Employee
SET
	[DisplayName] = @DisplayName
WHERE ID = @EDWID
END

--If the row exits but the parentkey has changed we set the enddate for the old row (type2)
IF (@LineExists = 1 AND IsNull(@EDWParentKey  COLLATE Latin1_General_100_BIN2,'NA'  COLLATE Latin1_General_100_BIN2) <> IsNull(@ParentBusinessKey  COLLATE Latin1_General_100_BIN2,'NA'  COLLATE Latin1_General_100_BIN2))
BEGIN
UPDATE edw.Employee
SET
	[EndDate] = cast(getdate() as date)
WHERE ID = @EDWID
END

set @i = @i+1
END

END

GO
CREATE PROCEDURE [NativeSPs].[ImportCurrency]

WITH NATIVE_COMPILATION, SCHEMABINDING, EXECUTE AS OWNER
AS BEGIN ATOMIC WITH
(
 TRANSACTION ISOLATION LEVEL = SNAPSHOT, LANGUAGE = N'us_english'
)

--declaring variables
declare @i int = 1, @max int
select @max = max(cast(CurrencyKey as int)) from [dsa].[Currency]

declare @EntityName nvarchar(50), 
		@BusinessKey nvarchar(250) 

--starting the loop
while @i <= @max
begin

--filling variables with the values for the current row
select
	   @EntityName = CurrencyName
      ,@BusinessKey =  CurrencyKey
FROM dsa.Currency
where CurrencyKey = @i

--declaring variables for the exists
declare @LineExists bit = 0, @EDWID bigint


--deciding if the row exits in the EDW
SELECT TOP 1 @LineExists = 1, @EDWID = id from edw.Currency
	WHERE BusinessKey = @BusinessKey

--If the row doesn't exist it is added
IF (@LineExists = 0)
BEGIN
	declare @NewID int = 0
	select @NewID = IsNull(max(id),0) from edw.Currency
	insert into edw.Currency ([id], [CurrencyName], [IsCurrent], [BusinessKey])
					  values (@NewID+1, @EntityName,  1, @BusinessKey )
END

--If the row exits it is updated
IF (@LineExists = 1 )
BEGIN
UPDATE edw.Currency
SET
	[CurrencyName] = @EntityName
WHERE id = @EDWID
END

set @i = @i+1
END

END

GO

CREATE PROCEDURE [NativeSPs].[ImportProduct]

WITH NATIVE_COMPILATION, SCHEMABINDING, EXECUTE AS OWNER
AS BEGIN ATOMIC WITH
(
 TRANSACTION ISOLATION LEVEL = SNAPSHOT, LANGUAGE = N'us_english'
)

--declaring variables
declare @i int = 1, @max int
select @max = max(cast(ProductKey as int)) from [dsa].[Product]

declare @EntityName nvarchar(50), 
		@BusinessKey nvarchar(250) 

--starting the loop
while @i <= @max
begin

--filling variables with the values for the current row
select
	   @EntityName = [EnglishProductName]
      ,@BusinessKey =  ProductKey
FROM dsa.Product
where ProductKey = @i

--declaring variables for the exists
declare @LineExists bit = 0, @EDWID bigint


--deciding if the row exits in the EDW
SELECT TOP 1 @LineExists = 1, @EDWID = id from edw.Product
	WHERE BusinessKey = @BusinessKey

--If the row doesn't exist it is added
IF (@LineExists = 0)
BEGIN
	declare @NewID int = 0
	select @NewID = IsNull(max(id),0) from edw.Product
	insert into edw.Product ([id], [ProductName], [IsCurrent], [BusinessKey])
					  values (@NewID+1, @EntityName,  1, @BusinessKey )
END

--If the row exits it is updated
IF (@LineExists = 1 )
BEGIN
UPDATE edw.Product
SET
	[ProductName] = @EntityName
WHERE id = @EDWID
END

set @i = @i+1
END

END

GO

CREATE PROCEDURE [NativeSPs].[ImportReseller]

WITH NATIVE_COMPILATION, SCHEMABINDING, EXECUTE AS OWNER
AS BEGIN ATOMIC WITH
(
 TRANSACTION ISOLATION LEVEL = SNAPSHOT, LANGUAGE = N'us_english'
)

--declaring variables
declare @i int = 1, @max int
select @max = max(cast(ResellerKey as int)) from [dsa].[Reseller]

declare @EntityName nvarchar(50), 
		@BusinessKey nvarchar(250) 

--starting the loop
while @i <= @max
begin

--filling variables with the values for the current row
select
	   @EntityName = ResellerName
      ,@BusinessKey =  ResellerKey
FROM dsa.Reseller
where ResellerKey = @i

--declaring variables for the exists
declare @LineExists bit = 0, @EDWID bigint


--deciding if the row exits in the EDW
SELECT TOP 1 @LineExists = 1, @EDWID = id from edw.Reseller
	WHERE BusinessKey = @BusinessKey

--If the row doesn't exist it is added
IF (@LineExists = 0)
BEGIN
	declare @NewID int = 0
	select @NewID = IsNull(max(id),0) from edw.Reseller
	insert into edw.Reseller ([id], [ResellerName], [IsCurrent], [BusinessKey])
					  values (@NewID+1, @EntityName,  1, @BusinessKey )
END

--If the row exits it is updated
IF (@LineExists = 1 )
BEGIN
UPDATE edw.Reseller
SET
	[ResellerName] = @EntityName
WHERE id = @EDWID
END

set @i = @i+1
END

END

GO
CREATE PROCEDURE [NativeSPs].[ImportSalesTerritory]

WITH NATIVE_COMPILATION, SCHEMABINDING, EXECUTE AS OWNER
AS BEGIN ATOMIC WITH
(
 TRANSACTION ISOLATION LEVEL = SNAPSHOT, LANGUAGE = N'us_english'
)

--declaring variables
declare @i int = 1, @max int
select @max = max(cast(SalesTerritoryKey as int)) from [dsa].[SalesTerritory]

declare @EntityName nvarchar(50), 
		@BusinessKey nvarchar(250) 

--starting the loop
while @i <= @max
begin

--filling variables with the values for the current row
select
	   @EntityName = SalesTerritoryRegion
      ,@BusinessKey =  SalesTerritoryKey
FROM dsa.SalesTerritory
where SalesTerritoryKey = @i

--declaring variables for the exists
declare @LineExists bit = 0, @EDWID bigint


--deciding if the row exits in the EDW
SELECT TOP 1 @LineExists = 1, @EDWID = id from edw.SalesTerritory
	WHERE BusinessKey = @BusinessKey

--If the row doesn't exist it is added
IF (@LineExists = 0)
BEGIN
	declare @NewID int = 0
	select @NewID = IsNull(max(id),0) from edw.SalesTerritory
	insert into edw.SalesTerritory ([id], [SalesTerritoryRegion], [IsCurrent], [BusinessKey])
					  values (@NewID+1, @EntityName,  1, @BusinessKey )
END

--If the row exits it is updated
IF (@LineExists = 1 )
BEGIN
UPDATE edw.SalesTerritory
SET
	[SalesTerritoryRegion] = @EntityName
WHERE id = @EDWID
END

set @i = @i+1
END

END

GO

CREATE PROCEDURE [NativeSPs].DeleteStaging

WITH NATIVE_COMPILATION, SCHEMABINDING, EXECUTE AS OWNER
AS BEGIN ATOMIC WITH
(
 TRANSACTION ISOLATION LEVEL = SNAPSHOT, LANGUAGE = N'us_english'
)

DELETE FROM [dsa].[Sales];

END


CREATE PROCEDURE [NativeSPs].[ImportSales]

WITH NATIVE_COMPILATION, SCHEMABINDING, EXECUTE AS OWNER
AS BEGIN ATOMIC WITH
(
 TRANSACTION ISOLATION LEVEL = SNAPSHOT, LANGUAGE = N'us_english'
)

--variable used to iterate over in the loop and max number of iterations
declare @i int = 1, @max int
select @max = max(SalesKey) from dsa.Sales

declare @MaxEDWID int
select @MaxEDWID = IsNull(max(id),0) from [edw].[Sales]

--declares variables
declare @ProductKey int 
      ,@ResellerKey int 
      ,@EmployeeKey int 
      ,@CurrencyKey int
      ,@SalesTerritoryKey int 
      ,@SalesOrderNumber nvarchar(20)
      ,@SalesOrderLineNumber tinyint
      ,@OrderQuantity smallint
      ,@UnitPrice money
      ,@CarrierTrackingNumber nvarchar(250)
      ,@OrderDate date
      ,@DueDate date
      ,@ShipDate date

--Starts loop
while @i <= @max
begin

--Findes next values from dsa table
select
	   @ProductKey = ProductKey
      ,@ResellerKey =  ResellerKey
      ,@EmployeeKey = EmployeeKey 
      ,@CurrencyKey = CurrencyKey 
      ,@SalesTerritoryKey = SalesTerritoryKey 
      ,@SalesOrderNumber = SalesOrderNumber 
      ,@SalesOrderLineNumber = SalesOrderLineNumber 
      ,@OrderQuantity = OrderQuantity 
      ,@UnitPrice = UnitPrice 
      ,@CarrierTrackingNumber = CarrierTrackingNumber 
      ,@OrderDate = OrderDate 
      ,@DueDate = DueDate 
      ,@ShipDate = ShipDate 
FROM dsa.Sales
where SalesKey = @i


--Dimension lookup values
	declare @EmployeeId int, @ResellerId int, @ProductId int, @SalesTerritoryId int, @CurrencyId int

	--Employee
		select @EmployeeId = ID from [edw].[Employee] where [BusinessKey] = @EmployeeKey and IsCurrent = 1
	--Reseller
		select @ResellerId = id from [edw].[Reseller] where [BusinessKey] = @ResellerKey and IsCurrent = 1
	--Product
		select @ProductId = id from [edw].[Product] where [BusinessKey] = @ProductKey and IsCurrent = 1
	--SalesTerritory
		select @SalesTerritoryId = id from [edw].[SalesTerritory] where [BusinessKey] = @SalesTerritoryKey and IsCurrent = 1
	--Currency
		select @CurrencyId = id from [edw].[Currency] where [BusinessKey] = @CurrencyKey and IsCurrent = 1


--variables used to specify if line already exits or not
declare @LineExists bit = 0, @EDWID int

--check edw tables to see if line allready exits based on SalesOrderNumber and SalesOrderLineNumber
SELECT TOP 1 @LineExists = 1, @EDWID = id from edw.Sales
	WHERE SalesOrderNumber = @SalesOrderNumber
	AND SalesOrderLineNumber = @SalesOrderLineNumber

--if line is determined not to exits it is added
IF @LineExists = 0
BEGIN
	declare @NewID int = @MaxEDWID + @i
	--select @NewID = IsNull(max(id),0) from edw.Sales
	insert into edw.Sales (id, StatusType, ImportId, OrderQuantity, UnitPrice, DueDate, OrderDate, ShipDate, CarrierTrackingNumber, ProductOriginalKey, SalesTerritoryOriginalKey, CurrencyOriginalKey, SalesOrderLineNumber, SalesOrderNumber, EmployeeOriginalKey, ResellerOriginalKey, EmployeeId, ResellerId, ProductId, SalesTerritoryId, CurrencyId )
	values (@NewID+1, 3,0, @OrderQuantity, @UnitPrice,  @DueDate, @OrderDate, @ShipDate, @CarrierTrackingNumber, @ProductKey, @SalesTerritoryKey, @CurrencyKey,  @SalesOrderLineNumber, @SalesOrderNumber, @EmployeeKey, @ResellerKey, IsNull(@EmployeeId,-1), IsNull(@ResellerId,-1), IsNull(@ProductId,-1), IsNull(@SalesTerritoryId,-1), IsNull(@CurrencyId,-1))
END

--If line already exits its values gets updated
IF @LineExists = 1
BEGIN
UPDATE edw.Sales
SET
	  OrderQuantity = @OrderQuantity
	, UnitPrice = @UnitPrice
	, DueDate =  @DueDate
	, OrderDate = @OrderDate
	, ShipDate = @ShipDate
	, CarrierTrackingNumber = @CarrierTrackingNumber
	, ProductOriginalKey = @ProductKey
	, SalesTerritoryOriginalKey = @SalesTerritoryKey
	, CurrencyOriginalKey = @CurrencyKey
	, EmployeeOriginalKey = @EmployeeKey
	, ResellerOriginalKey = @ResellerKey
	, EmployeeId = IsNull(@EmployeeId,-1)
	, ResellerId = IsNull(@ResellerId,-1)
	, ProductId = IsNull(@ProductId, -1)
	, SalesTerritoryId = IsNull(@SalesTerritoryId,-1)
	, CurrencyId = IsNull(@CurrencyId,-1)
WHERE id = @EDWID
END

--loop iterator increments by one and restarts
set @i = @i+1
END

END

--DM 
--Tables
create table DM.DimEmployee  (
	[ID] int not null, 
	[ParentID] INT, 
	[DisplayName] nvarchar(255), 
PRIMARY KEY NONCLUSTERED HASH
(
	ID
)  WITH (BUCKET_COUNT=1024),
)WITH ( MEMORY_OPTIMIZED = ON , DURABILITY = SCHEMA_ONLY )
GO

CREATE TABLE DM.[DimSalesTerritory] (
    [id] int not null,
    [SalesTerritoryRegion] nvarchar(50)
PRIMARY KEY NONCLUSTERED HASH
(
	id
)  WITH (BUCKET_COUNT=1024),
)WITH ( MEMORY_OPTIMIZED = ON , DURABILITY = SCHEMA_ONLY )
GO

CREATE TABLE DM.[DimReseller] (
    [id] int not null,
    [ResellerName] nvarchar(50)
PRIMARY KEY NONCLUSTERED HASH
(
	id
)  WITH (BUCKET_COUNT=1024),
)WITH ( MEMORY_OPTIMIZED = ON , DURABILITY = SCHEMA_ONLY )
GO

CREATE TABLE DM.[DimProduct] (
    [id] int not null,
    [ProductName] nvarchar(50)
PRIMARY KEY NONCLUSTERED HASH
(
	id
)  WITH (BUCKET_COUNT=1024),
)WITH ( MEMORY_OPTIMIZED = ON , DURABILITY = SCHEMA_AND_DATA )
GO

CREATE TABLE DM.[DimCurrency] (
    [id] int not null,
    [CurrencyName] nvarchar(50)
PRIMARY KEY NONCLUSTERED HASH
(
	id
)  WITH (BUCKET_COUNT=1024),
)WITH ( MEMORY_OPTIMIZED = ON , DURABILITY = SCHEMA_ONLY )
GO

create table [DM].[InternetSales_FactSales] (
id int not null, 
StatusType int, 
OrderQuantity smallint, 
UnitPrice money, 
DueDate datetime, 
OrderDate datetime, 
ShipDate datetime, 
CarrierTrackingNumber nvarchar(25), 
SalesOrderLineNumber int not null, 
SalesOrderNumber nvarchar(20) not null, 
EmployeeId int not null, 
ResellerId int not null, 
ProductId int not null, 
SalesTerritoryId int not null, 
CurrencyId int not null
PRIMARY KEY NONCLUSTERED HASH
(
	id
)  WITH (BUCKET_COUNT=2000000),
INDEX [IX_EmployeeId] NONCLUSTERED HASH 
(
	EmployeeId
)WITH ( BUCKET_COUNT = 1024),

INDEX [IX_ResellerId] NONCLUSTERED HASH 
(
	ResellerId
)WITH ( BUCKET_COUNT = 1024),
INDEX [IX_ProductId] NONCLUSTERED HASH 
(
	ProductId
)WITH ( BUCKET_COUNT = 1024),
INDEX [IX_SalesTerritoryId] NONCLUSTERED HASH 
(
	SalesTerritoryId
)WITH ( BUCKET_COUNT = 1024),
INDEX [IX_CurrencyId] NONCLUSTERED HASH 
(
	CurrencyId
)WITH ( BUCKET_COUNT = 1024)
)WITH ( MEMORY_OPTIMIZED = ON , DURABILITY = SCHEMA_ONLY )
GO
;
--SPs
CREATE PROCEDURE [NativeSPs].[InternetSales_FactSales]

WITH NATIVE_COMPILATION, SCHEMABINDING, EXECUTE AS OWNER
AS BEGIN ATOMIC WITH
(
 TRANSACTION ISOLATION LEVEL = SNAPSHOT, LANGUAGE = N'us_english'
)

--First all existing data is deleted
DELETE FROM [DM].[InternetSales_FactSales];

--Then the data is loaded
insert into [DM].[InternetSales_FactSales] (id, StatusType, UnitPrice, OrderQuantity, ShipDate, DueDate, OrderDate, CarrierTrackingNumber, ProductId, SalesTerritoryId, CurrencyId, SalesOrderLineNumber, SalesOrderNumber, EmployeeId, ResellerId)
select id, 1, UnitPrice, OrderQuantity, ShipDate, DueDate, OrderDate, CarrierTrackingNumber, ProductId, SalesTerritoryId, CurrencyId, SalesOrderLineNumber, SalesOrderNumber, EmployeeId, ResellerId
from [edw].[Sales] S

END;
 GO
CREATE PROCEDURE [NativeSPs].[DimCurrency]

WITH NATIVE_COMPILATION, SCHEMABINDING, EXECUTE AS OWNER
AS BEGIN ATOMIC WITH
(
 TRANSACTION ISOLATION LEVEL = SNAPSHOT, LANGUAGE = N'us_english'
)

--First all existing data is deleted
DELETE FROM [DM].[DimCurrency];

--then loads the data joined with datekeys
insert into [DM].[DimCurrency] (id, CurrencyName)
select id, CurrencyName
from [edw].[Currency] 

END;
 GO
CREATE PROCEDURE [NativeSPs].[DimEmployee]

WITH NATIVE_COMPILATION, SCHEMABINDING, EXECUTE AS OWNER
AS BEGIN ATOMIC WITH
(
 TRANSACTION ISOLATION LEVEL = SNAPSHOT, LANGUAGE = N'us_english'
)

--First all existing data is deleted
DELETE FROM [DM].[DimEmployee];

--then loads the data joined with datekeys
insert into [DM].[DimEmployee] (ID, ParentID, DisplayName)
select ID, ParentID, DisplayName
from [edw].[Employee]

END;
GO

CREATE PROCEDURE [NativeSPs].[DimProduct]

WITH NATIVE_COMPILATION, SCHEMABINDING, EXECUTE AS OWNER
AS BEGIN ATOMIC WITH
(
 TRANSACTION ISOLATION LEVEL = SNAPSHOT, LANGUAGE = N'us_english'
)

--First all existing data is deleted
DELETE FROM [DM].[DimProduct];

--then loads the data joined with datekeys
insert into [DM].[DimProduct] (id, ProductName)
select id, ProductName
from [edw].[Product]

END;
GO

CREATE PROCEDURE [NativeSPs].[DimReseller]

WITH NATIVE_COMPILATION, SCHEMABINDING, EXECUTE AS OWNER
AS BEGIN ATOMIC WITH
(
 TRANSACTION ISOLATION LEVEL = SNAPSHOT, LANGUAGE = N'us_english'
)

--First all existing data is deleted
DELETE FROM [DM].[DimReseller];

--then loads the data joined with datekeys
insert into [DM].[DimReseller] (id, ResellerName)
select id, ResellerName
from [edw].[Reseller]

END;
GO

CREATE PROCEDURE [NativeSPs].[DimSalesTerritory]

WITH NATIVE_COMPILATION, SCHEMABINDING, EXECUTE AS OWNER
AS BEGIN ATOMIC WITH
(
 TRANSACTION ISOLATION LEVEL = SNAPSHOT, LANGUAGE = N'us_english'
)

--First all existing data is deleted
DELETE FROM [DM].[DimSalesTerritory];

--then loads the data joined with datekeys
insert into [DM].[DimSalesTerritory] (id, SalesTerritoryRegion)
select id, SalesTerritoryRegion
from [edw].[SalesTerritory]

END;
GO
