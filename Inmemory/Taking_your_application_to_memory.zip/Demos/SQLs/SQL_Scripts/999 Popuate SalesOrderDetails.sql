delete from [Sales].[SalesOrderDetail_inmem];
insert into [Sales].[SalesOrderDetail_inmem]
(
SalesOrderID, SalesOrderDetailID, CarrierTrackingNumber, OrderQty, ProductID, SpecialOfferID, UnitPrice, UnitPriceDiscount, ModifiedDate
)
select
NEWID(), SalesOrderDetailID, CarrierTrackingNumber, OrderQty, ProductID, SpecialOfferID, UnitPrice, UnitPriceDiscount, ModifiedDate
from [Sales].[SalesOrderDetail]
;
	UPDATE STATISTICS [Sales].[SalesOrderDetail_inmem]
	WITH FULLSCAN, NORECOMPUTE