use [hkNorthwindschema];
--use [hkNorthwindNC];

set statistics time on
set statistics io on

--Clear buffer
CHECKPOINT; 
GO 
DBCC DROPCLEANBUFFERS; 
GO


SELECT o.OrderDate, ca.CategoryName, c.CompanyName, c.Region, e.FirstName collate Latin1_General_100_CI_AS + ' ' + e.LastName as SalesPerson, e.HireDate, t.TerritoryDescription, p.ProductName, p.QuantityPerUnit, p.UnitPrice, p.Discontinued, od.Quantity as SalesQuantity, od.UnitPrice as SalesUnitPrice, od.Discount as SalesDiscount
, Sum(CONVERT(money,(od.UnitPrice*od.Quantity*(1-od.Discount)/100))*100) over(partition by o.OrderID order by OrderDate) AS OrderSubtotal
, Sum(CONVERT(money,(od.UnitPrice*od.Quantity*(1-od.Discount)/100))*100) over(partition by o.CustomerID order by OrderDate) AS CustomerSubtotal
, Sum(CONVERT(money,(od.UnitPrice*od.Quantity*(1-od.Discount)/100))*100) over(partition by o.EmployeeID order by OrderDate) AS EmployeeSubtotal
, Sum(CONVERT(money,(od.UnitPrice*od.Quantity*(1-od.Discount)/100))*100) over(partition by et.TerritoryID order by OrderDate) AS TerritorySubtotal
, Sum(CONVERT(money,(od.UnitPrice*od.Quantity*(1-od.Discount)/100))*100) over(partition by o.OrderDate order by OrderDate) AS DateSubtotal
  FROM [dbo].[Orders] o
  join [dbo].[Customers] c
  on o.[CustomerID] = c.[CustomerID]
  join [dbo].[Employees] e 
  on o.[EmployeeID] = e.EmployeeID
  join [dbo].[EmployeeTerritories] et
  on e.EmployeeID = et.EmployeeID
  join [dbo].[Territories] t
  on et.TerritoryID = t.TerritoryID
  join [dbo].[Order Details] od 
  on o.OrderID = od.OrderID
  join [dbo].Products p 
  on od.ProductID = p.ProductID 
  join dbo.Categories ca
  ON p.CategoryID = ca.CategoryID


--Clear buffer
CHECKPOINT; 
GO 
DBCC DROPCLEANBUFFERS; 
GO

  --point & seek
      select * from  [dbo].[OrdersWithNonClusteredIndex]
	where [CustomerID] = 'FRANK'