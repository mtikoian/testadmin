use [AdventureWorks2012];

select  SalesOrderID,  s.ProductID,  OrderQty from [Sales].[SalesOrderDetail_inmem] S
INNER JOIN [Production].[Product] P
ON s.ProductID = p.ProductID
where p.Name = 'All-Purpose Bike Stand'
and SalesOrderID = 'CA41778D-8530-4A14-A253-337A1CFA2285'
;

update [Sales].[SalesOrderDetail_inmem]
set OrderQty = 7777
where SalesOrderID = 'CA41778D-8530-4A14-A253-337A1CFA2285'
and [ProductID] = 879
;

select  SalesOrderID,  s.ProductID,  OrderQty from [Sales].[SalesOrderDetail_inmem] S
INNER JOIN [Production].[Product] P
ON s.ProductID = p.ProductID
where p.Name = 'All-Purpose Bike Stand'
and SalesOrderID = 'CA41778D-8530-4A14-A253-337A1CFA2285'




/*
--Proactive caching query
select sum(UnitPrice*[OrderQty]) from [Sales].[SalesOrderDetail_inmem]
union all
select [SalesOrderDetailID] from [Sales].[SalesOrderDetail_inmem]
*/