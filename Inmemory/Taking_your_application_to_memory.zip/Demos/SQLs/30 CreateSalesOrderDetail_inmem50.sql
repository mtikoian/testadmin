USE [AdventureWorks2012]
GO

/****** Object:  Table [Sales].[SalesOrderDetail_inmem50]    Script Date: 25-02-2014 15:37:28 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [Sales].[SalesOrderDetail_inmem50]
(
	[SalesOrderID] [int] NOT NULL,
	[SalesOrderDetailID] [int] NOT NULL,
	[CarrierTrackingNumber] [nvarchar](25) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[OrderQty] [smallint] NOT NULL,
	[ProductID] [int] NOT NULL,
	[SpecialOfferID] [int] NOT NULL,
	[UnitPrice] [money] NOT NULL,
	[UnitPriceDiscount] [money] NOT NULL CONSTRAINT [IMDF_SalesOrderDetail_UnitPriceDiscount_inmem50]  DEFAULT ((0.0)),
	[ModifiedDate] [datetime2](7) NOT NULL

INDEX [IX_ProductID] NONCLUSTERED HASH 
(
	[ProductID]
)WITH ( BUCKET_COUNT = 16777216),
INDEX [IX_SalesOrderID] NONCLUSTERED HASH 
(
	[SalesOrderID]
)WITH ( BUCKET_COUNT = 1048576),
 PRIMARY KEY NONCLUSTERED HASH 
(
	[SalesOrderID],
	[SalesOrderDetailID]
)WITH ( BUCKET_COUNT = 16777216)
)WITH ( MEMORY_OPTIMIZED = ON , DURABILITY = SCHEMA_AND_DATA )

GO


