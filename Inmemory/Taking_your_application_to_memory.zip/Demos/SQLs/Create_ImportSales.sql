USE [Effektor]
GO

/****** Object:  StoredProcedure [NativeSPs].[ImportSales]    Script Date: 06-03-2014 10:34:45 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



CREATE PROCEDURE [NativeSPs].[ImportSales]

WITH NATIVE_COMPILATION, SCHEMABINDING, EXECUTE AS OWNER
AS BEGIN ATOMIC WITH
(
 TRANSACTION ISOLATION LEVEL = SNAPSHOT, LANGUAGE = N'us_english'
)

--variable used to iterate over in the loop and max number of iterations
declare @i int = 1, @max int
select @max = max(id) from dsa.erp_sales

declare @MaxEDWID bigint
select @MaxEDWID = IsNull(max(id),0) from [EDW].[Sales]

--declares variables
declare @ProductKey nvarchar(250) 
      ,@ResellerKey nvarchar(250) 
      ,@EmployeeKey nvarchar(250) 
      ,@CurrencyKey nvarchar(250) 
      ,@SalesTerritoryKey nvarchar(250) 
      ,@SalesOrderNumber nvarchar(250) 
      ,@SalesOrderLineNumber tinyint
      ,@OrderQuantity smallint
      ,@UnitPrice money
      ,@CarrierTrackingNumber nvarchar(250)
      ,@OrderDate date
      ,@DueDate date
      ,@ShipDate date

--Starts loop
while @i <= @max
begin

--Findes next values from dsa table
select
	   @ProductKey = ProductKey
      ,@ResellerKey =  ResellerKey
      ,@EmployeeKey = EmployeeKey 
      ,@CurrencyKey = CurrencyKey 
      ,@SalesTerritoryKey = SalesTerritoryKey 
      ,@SalesOrderNumber = SalesOrderNumber 
      ,@SalesOrderLineNumber = SalesOrderLineNumber 
      ,@OrderQuantity = OrderQuantity 
      ,@UnitPrice = UnitPrice 
      ,@CarrierTrackingNumber = CarrierTrackingNumber 
      ,@OrderDate = OrderDate 
      ,@DueDate = DueDate 
      ,@ShipDate = ShipDate 
FROM dsa.erp_sales
where id = @i


--Dimension lookup values
	declare @EmployeeId bigint, @ResellerId bigint, @ProductId bigint, @SalesTerritoryId bigint, @CurrencyId bigint

	--Employee
		select @EmployeeId = id from [EDW].[Employee] where [BusinessKey] = @EmployeeKey and IsCurrent = 1
	--Reseller
		select @ResellerId = id from [EDW].[Reseller] where [BusinessKey] = @ResellerKey and IsCurrent = 1
	--Product
		select @ProductId = id from [EDW].[Product] where [BusinessKey] = @ProductKey and IsCurrent = 1
	--SalesTerritory
		select @SalesTerritoryId = id from [EDW].[SalesTerritory] where [BusinessKey] = @SalesTerritoryKey and IsCurrent = 1
	--Currency
		select @CurrencyId = id from [EDW].[Currency] where [BusinessKey] = @CurrencyKey and IsCurrent = 1


--variables used to specify if line already exits or not
declare @LineExists bit = 0, @EDWID bigint
--check edw tables to see if line allready exits based on SalesOrderNumber and SalesOrderLineNumber
SELECT TOP 1 @LineExists = 1, @EDWID = Id from edw.Sales
	WHERE SalesOrderNumber = @SalesOrderNumber
	AND SalesOrderLineNumber = @SalesOrderLineNumber

--if line is determined not to exits it is added
IF @LineExists = 0
BEGIN
	declare @NewID bigint = @MaxEDWID + @i
	--select @NewID = IsNull(max(id),0) from edw.Sales
	insert into edw.Sales (ID, StatusType, ImportId, OrderQuantity, UnitPrice, DueDate, OrderDate, ShipDate, CarrierTrackingNumber, ProductOriginalKey, SalesTerritoryOriginalKey, CurrencyOriginalKey, SalesOrderLineNumber, SalesOrderNumber, EmployeeOriginalKey, ResellerOriginalKey, EmployeeId, ResellerId, ProductId, SalesTerritoryId, CurrencyId )
	values (@NewID+1, 3,0, @OrderQuantity, @UnitPrice,  @DueDate, @OrderDate, @ShipDate, @CarrierTrackingNumber, @ProductKey, @SalesTerritoryKey, @CurrencyKey,  @SalesOrderLineNumber, @SalesOrderNumber, @EmployeeKey, @ResellerKey, IsNull(@EmployeeId,-1), IsNull(@ResellerId,-1), IsNull(@ProductId,-1), IsNull(@SalesTerritoryId,-1), IsNull(@CurrencyId,-1))
END

--If line already exits its values gets updated
IF @LineExists = 1
BEGIN
UPDATE edw.Sales
SET
	  OrderQuantity = @OrderQuantity
	, UnitPrice = @UnitPrice
	, DueDate =  @DueDate
	, OrderDate = @OrderDate
	, ShipDate = @ShipDate
	, CarrierTrackingNumber = @CarrierTrackingNumber
	, ProductOriginalKey = @ProductKey
	, SalesTerritoryOriginalKey = @SalesTerritoryKey
	, CurrencyOriginalKey = @CurrencyKey
	, EmployeeOriginalKey = @EmployeeKey
	, ResellerOriginalKey = @ResellerKey
	, EmployeeId = IsNull(@EmployeeId,-1)
	, ResellerId = IsNull(@ResellerId,-1)
	, ProductId = IsNull(@ProductId, -1)
	, SalesTerritoryId = IsNull(@SalesTerritoryId,-1)
	, CurrencyId = IsNull(@CurrencyId,-1)
WHERE Id = @EDWID
END

--loop iterator increments by one and restarts
set @i = @i+1
END

END



GO


