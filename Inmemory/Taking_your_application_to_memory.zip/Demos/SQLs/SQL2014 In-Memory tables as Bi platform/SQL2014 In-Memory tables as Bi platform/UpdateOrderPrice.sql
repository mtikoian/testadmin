use hkNorthwind;

select * from [dbo].[Order Details]
where [OrderID] = 10380
and [ProductID] = 70
;

update [dbo].[Order Details]
set [UnitPrice] = 25
where [OrderID] = 10380
and [ProductID] = 70
;

select * from [dbo].[Order Details]
where [OrderID] = 10380
and [ProductID] = 70

/*
--Proactive caching query
select sum(UnitPrice*Quantity) from [dbo].[Order Details]
union all
select OrderID from [dbo].[Order Details]
*/