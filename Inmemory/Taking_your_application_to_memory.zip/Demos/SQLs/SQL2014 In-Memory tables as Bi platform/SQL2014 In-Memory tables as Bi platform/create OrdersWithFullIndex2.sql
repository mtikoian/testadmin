
DROP TABLE [dbo].[OrdersWithFullIndex];
GO


--constraint CustomerID primary key nonclustered
CREATE TABLE [dbo].[OrdersWithFullIndex]
(
	[OrderID] [int] NOT NULL ,
	[CustomerID] [nchar](5) NOT NULL,
	[EmployeeID] [int] NOT NULL,
	[OrderDate] [datetime] NOT NULL,
	[RequiredDate] [datetime] NULL,
	[ShippedDate] [datetime] NOT NULL,
	[ShipVia] [int] NOT NULL,
	[Freight] [money] NULL,
	[ShipName] [nvarchar](40) NULL,
	[ShipAddress] [nvarchar](60) NULL,
	[ShipCity] [nvarchar](15) NULL,
	[ShipRegion] [nvarchar](15) NULL,
	[ShipPostalCode] [nvarchar](10) NOT NULL,
	[ShipCountry] [nvarchar](15) NULL
 PRIMARY KEY NONCLUSTERED HASH 
(
	[OrderID]
)WITH ( BUCKET_COUNT = 1048576),

INDEX IX_JoinTables NONCLUSTERED
(
[CustomerID], [EmployeeID], [OrderDate]
)
)WITH ( MEMORY_OPTIMIZED = ON , DURABILITY = SCHEMA_AND_DATA )
;
GO

  insert into [OrdersWithFullIndex]
  select * from [dbo].[Orders]
;
GO
--Remember to update stats - no auto update in in-memory tables
  exec sp_updatestats;
  GO



