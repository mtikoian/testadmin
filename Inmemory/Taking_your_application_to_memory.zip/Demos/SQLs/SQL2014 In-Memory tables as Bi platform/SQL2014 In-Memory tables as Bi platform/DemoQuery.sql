use hkNorthwind;

set statistics time on
set statistics io on

--Clear buffer
CHECKPOINT; 
GO 
DBCC DROPCLEANBUFFERS; 
GO

--Speed comparison between memory-optimized and on disk table
--memory optimized
  SELECT o.OrderDate, ca.CategoryName, c.CompanyName, c.Region, e.FirstName collate Latin1_General_100_CI_AS + ' ' + e.LastName as SalesPerson, e.HireDate, t.TerritoryDescription, p.ProductName, p.QuantityPerUnit, p.UnitPrice, p.Discontinued, od.Quantity as SalesQuantity, od.UnitPrice as SalesUnitPrice, od.Discount as SalesDiscount
, Sum(CONVERT(money,(od.UnitPrice*od.Quantity*(1-od.Discount)/100))*100) over(partition by od.OrderID order by OrderDate) AS OrderSubtotal
, Sum(CONVERT(money,(od.UnitPrice*od.Quantity*(1-od.Discount)/100))*100) over(partition by o.CustomerID order by OrderDate) AS CustomerSubtotal
, Sum(CONVERT(money,(od.UnitPrice*od.Quantity*(1-od.Discount)/100))*100) over(partition by o.EmployeeID order by OrderDate) AS EmployeeSubtotal
, Sum(CONVERT(money,(od.UnitPrice*od.Quantity*(1-od.Discount)/100))*100) over(partition by et.TerritoryID order by OrderDate) AS TerritorySubtotal
, Sum(CONVERT(money,(od.UnitPrice*od.Quantity*(1-od.Discount)/100))*100) over(partition by o.OrderDate order by OrderDate) AS DateSubtotal
  FROM [dbo].[Orders] o
  join [dbo].[Customers] c
  on o.[CustomerID] = c.[CustomerID]
  join [dbo].[Employees] e 
  on o.[EmployeeID] = e.EmployeeID
  join [dbo].[EmployeeTerritories] et
  on e.EmployeeID = et.EmployeeID
  join [dbo].[Territories] t
  on et.TerritoryID = t.TerritoryID
  join [dbo].[Order Details] od 
  on o.OrderID = od.OrderID
  join [dbo].Products p 
  on od.ProductID = p.ProductID 
  join dbo.Categories ca
  ON p.CategoryID = ca.CategoryID

--orders table on disk
  SELECT o.OrderDate, ca.CategoryName, c.CompanyName, c.Region, e.FirstName  + ' ' + e.LastName as SalesPerson, e.HireDate, t.TerritoryDescription, p.ProductName, p.QuantityPerUnit, p.UnitPrice, p.Discontinued, od.Quantity as SalesQuantity, od.UnitPrice as SalesUnitPrice, od.Discount as SalesDiscount
, Sum(CONVERT(money,(od.UnitPrice*od.Quantity*(1-od.Discount)/100))*100) over(partition by od.OrderID order by OrderDate) AS OrderSubtotal
, Sum(CONVERT(money,(od.UnitPrice*od.Quantity*(1-od.Discount)/100))*100) over(partition by o.CustomerID order by OrderDate) AS CustomerSubtotal
, Sum(CONVERT(money,(od.UnitPrice*od.Quantity*(1-od.Discount)/100))*100) over(partition by o.EmployeeID order by OrderDate) AS EmployeeSubtotal
, Sum(CONVERT(money,(od.UnitPrice*od.Quantity*(1-od.Discount)/100))*100) over(partition by et.TerritoryID order by OrderDate) AS TerritorySubtotal
, Sum(CONVERT(money,(od.UnitPrice*od.Quantity*(1-od.Discount)/100))*100) over(partition by o.OrderDate order by OrderDate) AS DateSubtotal
  FROM [dbo].[OrdersOnDisk] o
  join [dbo].[Customers] c
  on o.[CustomerID] = c.[CustomerID]
  join [dbo].[Employees] e 
  on o.[EmployeeID] = e.EmployeeID
  join [dbo].[EmployeeTerritories] et
  on e.EmployeeID = et.EmployeeID
  join [dbo].[Territories] t
  on et.TerritoryID = t.TerritoryID
  join [dbo].[Order Details] od 
  on o.OrderID = od.OrderID
  join [dbo].Products p 
  on od.ProductID = p.ProductID 
  join dbo.Categories ca
  ON p.CategoryID = ca.CategoryID

  -- whole database on disk
  SELECT o.OrderDate, ca.CategoryName, c.CompanyName, c.Region, e.FirstName collate Latin1_General_100_CI_AS + ' ' + e.LastName as SalesPerson, e.HireDate, t.TerritoryDescription, p.ProductName, p.QuantityPerUnit, p.UnitPrice, p.Discontinued, od.Quantity as SalesQuantity, od.UnitPrice as SalesUnitPrice, od.Discount as SalesDiscount
, Sum(CONVERT(money,(od.UnitPrice*od.Quantity*(1-od.Discount)/100))*100) over(partition by od.OrderID order by OrderDate) AS OrderSubtotal
, Sum(CONVERT(money,(od.UnitPrice*od.Quantity*(1-od.Discount)/100))*100) over(partition by o.CustomerID order by OrderDate) AS CustomerSubtotal
, Sum(CONVERT(money,(od.UnitPrice*od.Quantity*(1-od.Discount)/100))*100) over(partition by o.EmployeeID order by OrderDate) AS EmployeeSubtotal
, Sum(CONVERT(money,(od.UnitPrice*od.Quantity*(1-od.Discount)/100))*100) over(partition by et.TerritoryID order by OrderDate) AS TerritorySubtotal
, Sum(CONVERT(money,(od.UnitPrice*od.Quantity*(1-od.Discount)/100))*100) over(partition by o.OrderDate order by OrderDate) AS DateSubtotal
  FROM [NORTHWND].[dbo].[Ordersondisk] o
  join [NORTHWND].[dbo].[Customers] c
  on o.[CustomerID] = c.[CustomerID]
  join [NORTHWND].[dbo].[Employees] e 
  on o.[EmployeeID] = e.EmployeeID
  join [NORTHWND].[dbo].[EmployeeTerritories] et
  on e.EmployeeID = et.EmployeeID
  join [NORTHWND].[dbo].[Territories] t
  on et.TerritoryID = t.TerritoryID
  join [NORTHWND].[dbo].[Order Details] od 
  on o.OrderID = od.OrderID
  join [NORTHWND].[dbo].Products p 
  on od.ProductID = p.ProductID 
  join [NORTHWND].dbo.Categories ca
  ON p.CategoryID = ca.CategoryID

  
  --Clear buffer
CHECKPOINT; 
GO 
DBCC DROPCLEANBUFFERS; 
GO

  SELECT o.OrderDate, ca.CategoryName, c.CompanyName, c.Region, e.FirstName  + ' ' + e.LastName as SalesPerson, e.HireDate, t.TerritoryDescription, p.ProductName, p.QuantityPerUnit, p.UnitPrice, p.Discontinued, od.Quantity as SalesQuantity, od.UnitPrice as SalesUnitPrice, od.Discount as SalesDiscount
  FROM [dbo].[Orders] o
  join [dbo].[Customers] c
  on o.[CustomerID] = c.[CustomerID]
  join [dbo].[Employees] e 
  on o.[EmployeeID] = e.EmployeeID
  join [dbo].[EmployeeTerritories] et
  on e.EmployeeID = et.EmployeeID
  join [dbo].[Territories] t
  on et.TerritoryID = t.TerritoryID
  join [dbo].[Order Details] od 
  on o.OrderID = od.OrderID
  join [dbo].Products p 
  on od.ProductID = p.ProductID 
  join dbo.Categories ca
  ON p.CategoryID = ca.CategoryID


  SELECT o.OrderDate, ca.CategoryName, c.CompanyName, c.Region, e.FirstName + ' ' + e.LastName as SalesPerson, e.HireDate, t.TerritoryDescription, p.ProductName, p.QuantityPerUnit, p.UnitPrice, p.Discontinued, od.Quantity as SalesQuantity, od.UnitPrice as SalesUnitPrice, od.Discount as SalesDiscount
  FROM [dbo].[OrdersOnDisk] o
  join [dbo].[Customers] c
  on o.[CustomerID] = c.[CustomerID]
  join [dbo].[Employees] e 
  on o.[EmployeeID] = e.EmployeeID
  join [dbo].[EmployeeTerritories] et
  on e.EmployeeID = et.EmployeeID
  join [dbo].[Territories] t
  on et.TerritoryID = t.TerritoryID
  join [dbo].[Order Details] od 
  on o.OrderID = od.OrderID
  join [dbo].Products p 
  on od.ProductID = p.ProductID 
  join dbo.Categories ca
  ON p.CategoryID = ca.CategoryID

  --which tables are optimized?
  select name, is_memory_optimized from sys.tables order by 2


    --Clear buffer
CHECKPOINT; 
GO 
DBCC DROPCLEANBUFFERS; 
GO

  select * from dbo.[Orders]
  select * from dbo.OrdersOnDisk

--What the hack'
  SELECT o.OrderDate, ca.CategoryName, c.CompanyName, c.Region, e.FirstName  + ' ' + e.LastName as SalesPerson, e.HireDate, t.TerritoryDescription, p.ProductName, p.QuantityPerUnit, p.UnitPrice, p.Discontinued, od.Quantity as SalesQuantity, od.UnitPrice as SalesUnitPrice, od.Discount as SalesDiscount
  FROM [dbo].[Orders] o
  join [dbo].[Customers] c
  on o.[CustomerID] = c.[CustomerID]
  join [dbo].[Employees] e 
  on o.[EmployeeID] = e.EmployeeID
  join [dbo].[EmployeeTerritories] et
  on e.EmployeeID = et.EmployeeID
  join [dbo].[Territories] t
  on et.TerritoryID = t.TerritoryID
  join [dbo].[Order Details] od 
  on o.OrderID = od.OrderID
  join [dbo].Products p 
  on od.ProductID = p.ProductID 
  join dbo.Categories ca
  ON p.CategoryID = ca.CategoryID

  --what if we take just the customer table
    select * from  [dbo].[Customers]

    SELECT  o.OrderDate, ca.CategoryName, c.CompanyName, c.Region, e.FirstName + ' ' + e.LastName as SalesPerson, e.HireDate, t.TerritoryDescription, p.ProductName, p.QuantityPerUnit, p.UnitPrice, p.Discontinued, od.Quantity as SalesQuantity, od.UnitPrice as SalesUnitPrice, od.Discount as SalesDiscount
  FROM [dbo].[Orders] o  with (index([PK__Orders__C3905BAE829EDD83]))
  join [dbo].[Customers] c with (index([PK__Customer__A4AE64B96F016025]))
  on o.[CustomerID] = c.[CustomerID]
  join [dbo].[Employees] e  with (index([PK_Employees]))
  on o.[EmployeeID] = e.EmployeeID
  join [dbo].[EmployeeTerritories] et  with (index([PK_EmployeeTerritories]))
  on e.EmployeeID = et.EmployeeID
  join [dbo].[Territories] t  with (index([PK__Territor__2BECD2E57935D683]))
  on et.TerritoryID = t.TerritoryID
  join [dbo].[Order Details] od  with (index([PK_Order_Details]))
  on o.OrderID = od.OrderID
  join [dbo].Products p  with (index([PK__Products__B40CC6EC0CED21B4]))
  on od.ProductID = p.ProductID 
  join dbo.Categories ca  with (index([PK__Categori__19093A2A37B1258A]))
  ON p.CategoryID = ca.CategoryID
 
 ---comparison

   SELECT o.OrderDate, ca.CategoryName, c.CompanyName, c.Region, e.FirstName + ' ' + e.LastName as SalesPerson, e.HireDate, t.TerritoryDescription, p.ProductName, p.QuantityPerUnit, p.UnitPrice, p.Discontinued, od.Quantity as SalesQuantity, od.UnitPrice as SalesUnitPrice, od.Discount as SalesDiscount
  FROM [dbo].[Orders] o
  join [dbo].[Customers] c
  on o.[CustomerID] = c.[CustomerID]
  join [dbo].[Employees] e 
  on o.[EmployeeID] = e.EmployeeID
  join [dbo].[EmployeeTerritories] et
  on e.EmployeeID = et.EmployeeID
  join [dbo].[Territories] t
  on et.TerritoryID = t.TerritoryID
  join [dbo].[Order Details] od 
  on o.OrderID = od.OrderID
  join [dbo].Products p 
  on od.ProductID = p.ProductID 
  join dbo.Categories ca
  ON p.CategoryID = ca.CategoryID

  
--lets take a look at the index'es, bucket counts and chain lenghts  
SELECT hs.object_id, object_name(hs.object_id) AS 'object name', i.name as 'index name', hs.*
FROM sys.dm_db_xtp_hash_index_stats AS hs 
JOIN sys.indexes AS i ON hs.object_id=i.object_id AND hs.index_id=i.index_id
where object_name(hs.object_id) = 'Customers';
  
  
  
  
/*Recommandation from SQL server team
�Re-create the index as type �nonclustered� [available in CTP2] instead of �nonclustered hash�. 
 The memory-optimized nonclustered index is ordered, and thus SQL Server can perform an index seek on the leading index key columns. 
 The resulting primary key definition for the example would be:

   constraint CustomerID primary key nonclustered

�Change the current index key to match the columns in the WHERE clause.
�Add a new hash index that matches with the columns in the WHERE clause of the query. 

 */  
  
     SELECT o.[CustomerID],  c.CompanyName
  FROM [dbo].[OrdersWithFullIndex] o
  join [dbo].[Customers] c
    on o.[CustomerID] = c.[CustomerID]

	   SELECT o.OrderDate, ca.CategoryName, c.CompanyName, c.Region, e.FirstName + ' ' + e.LastName as SalesPerson, e.HireDate, t.TerritoryDescription, p.ProductName, p.QuantityPerUnit, p.UnitPrice, p.Discontinued, od.Quantity as SalesQuantity, od.UnitPrice as SalesUnitPrice, od.Discount as SalesDiscount
  FROM [dbo].[OrdersWithFullIndex] o
  join [dbo].[Customers] c
  on o.[CustomerID] = c.[CustomerID]
  join [dbo].[Employees] e 
  on o.[EmployeeID] = e.EmployeeID
  join [dbo].[EmployeeTerritories] et
  on e.EmployeeID = et.EmployeeID
  join [dbo].[Territories] t
  on et.TerritoryID = t.TerritoryID
  join [dbo].[Order Details] od 
  on o.OrderID = od.OrderID
  join [dbo].Products p 
  on od.ProductID = p.ProductID 
  join dbo.Categories ca
  ON p.CategoryID = ca.CategoryID



  SELECT o.OrderDate, ca.CategoryName, c.CompanyName, c.Region, e.FirstName collate Latin1_General_100_CI_AS + ' ' + e.LastName as SalesPerson, e.HireDate, t.TerritoryDescription, p.ProductName, p.QuantityPerUnit, p.UnitPrice, p.Discontinued, od.Quantity as SalesQuantity, od.UnitPrice as SalesUnitPrice, od.Discount as SalesDiscount
, Sum(CONVERT(money,(od.UnitPrice*od.Quantity*(1-od.Discount)/100))*100) over(partition by od.OrderID order by OrderDate) AS OrderSubtotal
, Sum(CONVERT(money,(od.UnitPrice*od.Quantity*(1-od.Discount)/100))*100) over(partition by o.CustomerID order by OrderDate) AS CustomerSubtotal
, Sum(CONVERT(money,(od.UnitPrice*od.Quantity*(1-od.Discount)/100))*100) over(partition by o.EmployeeID order by OrderDate) AS EmployeeSubtotal
, Sum(CONVERT(money,(od.UnitPrice*od.Quantity*(1-od.Discount)/100))*100) over(partition by et.TerritoryID order by OrderDate) AS TerritorySubtotal
, Sum(CONVERT(money,(od.UnitPrice*od.Quantity*(1-od.Discount)/100))*100) over(partition by o.OrderDate order by OrderDate) AS DateSubtotal
  FROM [dbo].[OrdersWithFullIndex] o
  join [dbo].[Customers] c
  on o.[CustomerID] = c.[CustomerID]
  join [dbo].[Employees] e 
  on o.[EmployeeID] = e.EmployeeID
  join [dbo].[EmployeeTerritories] et
  on e.EmployeeID = et.EmployeeID
  join [dbo].[Territories] t
  on et.TerritoryID = t.TerritoryID
  join [dbo].[Order Details] od 
  on o.OrderID = od.OrderID
  join [dbo].Products p 
  on od.ProductID = p.ProductID 
  join dbo.Categories ca
  ON p.CategoryID = ca.CategoryID