select 
	DISTINCT
	sess.event_name, 	
	event_description, 
	e_col.column_name,
	column_type,
	type_name,
	column_description
	FROM (
			select
				 
				xse.event_name, xsea.action_name
			from sys.dm_xe_sessions s 
			join sys.dm_xe_session_events xse
					on xse.event_session_address = s.address
			join sys.dm_xe_session_event_actions xsea
				 on xse.event_session_address = xsea.event_session_address
				and xse.event_package_guid = xsea.event_package_guid
			where s.name = 'system_health'
		) sess
	JOIN 
		(
			SELECT 
				   o.name as event_name,
				   o.description as event_description,
				   oc.name AS column_name,
				   oc.column_type AS column_type,
				   oc.column_value AS column_value,
				   oc.description AS column_description,
				   oc.type_name 
			FROM sys.dm_xe_packages AS p
			JOIN sys.dm_xe_objects AS o 
				 ON p.guid = o.package_guid
			JOIN sys.dm_xe_object_columns AS oc 
				 ON o.name = oc.OBJECT_NAME 
				AND o.package_guid = oc.object_package_guid
			WHERE (p.capabilities IS NULL OR p.capabilities & 1 = 0)
			  AND (o.capabilities IS NULL OR o.capabilities & 1 = 0)
			  AND (oc.capabilities IS NULL OR oc.capabilities & 1 = 0)
			  AND o.object_type = 'event'
			  AND column_type = 'data'		
			
		) e_col
		ON sess.event_name = e_col.event_name


--SELECT oc.name AS column_name,
--       oc.column_type AS column_type,
--       oc.column_value AS column_value,
--       oc.description AS column_description
--FROM sys.dm_xe_packages AS p
--JOIN sys.dm_xe_objects AS o 
--     ON p.guid = o.package_guid
--JOIN sys.dm_xe_object_columns AS oc 
--     ON o.name = oc.OBJECT_NAME 
--    AND o.package_guid = oc.object_package_guid
--WHERE (p.capabilities IS NULL OR p.capabilities & 1 = 0)
--  AND (o.capabilities IS NULL OR o.capabilities & 1 = 0)
--  AND (oc.capabilities IS NULL OR oc.capabilities & 1 = 0)
--  AND o.object_type = 'event'
--  AND o.name = 'wait_info'