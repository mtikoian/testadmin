USE analysis
go
--Modified from Jonathan Kehayias <a href="http://www.sqlskills.com/blogs/jonathan/an-xevent-a-day-6-of-31-targets-week-asynchronous_file_target/">http://www.sqlskills.com/blogs/jonathan/an-xevent-a-day-6-of-31-targets-week-asynchronous_file_target/</a>
--NewCheck (new event session target data)

IF OBJECT_ID('DBCCNew') IS NOT NULL
	DROP TABLE DBCCNew;
IF OBJECT_ID('DBCCOld') IS NOT NULL
	DROP TABLE DBCCOld;
IF OBJECT_ID('DBCCCombined') IS NOT NULL
	DROP TABLE DBCCCombined;
GO

SELECT *
    INTO DBCCNew
    FROM (
            SELECT
                event_data.value('(event/@name)[1]', 'varchar(50)') AS event_name,
                event_data.value('(event/@timestamp)[1]', 'datetime2') AS event_timestamp,
                event_data.value('(event/data[@name="database_id"]/value)[1]', 'sysname') AS event_database_id,
                event_data.value('(event/action[@name="database_id"]/value)[1]', 'sysname') AS action_database_id,
                event_data.value('(event/data[@name="opcode"]/text)[1]', 'NVARCHAR(25)') AS opcode_text,
                event_data.value('(event/data[@name="call_duration"]/value)[1]', 'bigint') AS call_duration,
                event_data.value('(event/data[@name="is_remote"]/value)[1]', 'bit') AS is_remote,
                event_data.value('(event/data[@name="command_phase"]/text)[1]', 'nvarchar(100)') AS command_phase_text,
                event_data.value('(event/data[@name="logical_reads"]/value)[1]', 'bigint') AS logical_reads,
                event_data.value('(event/data[@name="physical_reads"]/value)[1]', 'bigint') AS physical_reads,
                event_data.value('(event/data[@name="run_ahead_reads"]/value)[1]', 'bigint') AS run_ahead_reads,
                event_data.value('(event/data[@name="total_page_io_latch_waits"]/value)[1]', 'bigint') AS total_page_io_latch_waits,
                event_data.value('(event/data[@name="page_io_latch_wait_time_in_ms"]/value)[1]', 'bigint') AS page_io_latch_wait_time_in_ms,
                event_data.value('(event/data[@name="total_page_latch_waits"]/value)[1]', 'bigint') AS total_page_latch_waits,
                event_data.value('(event/data[@name="page_latch_wait_time_in_ms"]/value)[1]', 'bigint') AS page_latch_wait_time_in_ms,
                event_data.value('(event/data[@name="messages_sent"]/value)[1]', 'int') AS messages_sent,
                event_data.value('(event/data[@name="messages_received"]/value)[1]', 'int') AS messages_received,
                event_data.value('(event/action[@name="database_name"]/value)[1]', 'sysname') AS database_name,
                CAST(SUBSTRING(event_data.value('(event/action[@name="attach_activity_id"]/value)[1]', 'varchar(50)'), 1, 36) AS uniqueidentifier) as activity_id,
                CAST(SUBSTRING(event_data.value('(event/action[@name="attach_activity_id"]/value)[1]', 'varchar(50)'), 38, 10) AS int) as event_sequence,
                CAST(SUBSTRING(event_data.value('(event/action[@name="attach_activity_id_xfer"]/value)[1]', 'varchar(50)'), 1, 36) AS uniqueidentifier) as activity_id_xfer,
				event_data
            FROM (
					SELECT CAST(event_data AS XML) AS event_data
					FROM sys.fn_xe_file_target_read_file('D:\event_sessions\DBCCNew*.xel', NULL, NULL, NULL)
				) a 
	) xedata  ;

GO

SELECT CAST(event_data AS XML) AS event_data
	into #temp_xml
FROM sys.fn_xe_file_target_read_file('D:\event_sessions\DBCCOld*.xel', NULL, NULL, NULL)
GO
--OldCheck (Old Session)
SELECT *
    INTO DBCCOld
    FROM (
            SELECT
                event_data.value('(event/@name)[1]', 'varchar(50)') AS event_name,
                event_data.value('(event/@timestamp)[1]', 'datetime2') AS event_timestamp,
                event_data.value('(event/data[@name="count"]/value)[1]', 'bigint') AS count,
				event_data.value('(event/data[@name="increment"]/value)[1]', 'bigint') AS increment,
                event_data.value('(event/data[@name="database_id"]/value)[1]', 'sysname') AS event_database_id,
                event_data.value('(event/action[@name="database_id"]/value)[1]', 'sysname') AS action_database_id,
                event_data.value('(event/action[@name="database_name"]/value)[1]', 'sysname') AS action_database_name,
                CAST(SUBSTRING(event_data.value('(event/action[@name="attach_activity_id"]/value)[1]', 'varchar(50)'), 1, 36) AS uniqueidentifier) as activity_id,
                CAST(SUBSTRING(event_data.value('(event/action[@name="attach_activity_id"]/value)[1]', 'varchar(50)'), 38, 10) AS int) as event_sequence,
                CAST(SUBSTRING(event_data.value('(event/action[@name="attach_activity_id_xfer"]/value)[1]', 'varchar(50)'), 1, 36) AS uniqueidentifier) as activity_id_xfer,
				event_data
			FROM #temp_xml
	) xedata    ;
    -- ORDER BY activity_id, event_sequence
GO

TRUNCATE TABLE #temp_xml;
GO

INSERT INTO #temp_xml
SELECT CAST(event_data AS XML) AS event_data
					FROM sys.fn_xe_file_target_read_file('D:\event_sessions\DBCCCombined*.xel', NULL, NULL, NULL)

SELECT *
    INTO DBCCCombined
    FROM (
            SELECT
                event_data.value('(event/@name)[1]', 'varchar(50)') AS event_name,
                event_data.value('(event/@timestamp)[1]', 'datetime2') AS event_timestamp,
                event_data.value('(event/data[@name="count"]/value)[1]', 'bigint') AS count,
				event_data.value('(event/data[@name="increment"]/value)[1]', 'bigint') AS increment,
                event_data.value('(event/data[@name="database_id"]/value)[1]', 'sysname') AS event_database_id,
                event_data.value('(event/action[@name="database_id"]/value)[1]', 'sysname') AS action_database_id,
                event_data.value('(event/action[@name="database_name"]/value)[1]', 'sysname') AS action_database_name,
				event_data.value('(event/data[@name="opcode"]/text)[1]', 'NVARCHAR(25)') AS opcode_text,
                event_data.value('(event/data[@name="call_duration"]/value)[1]', 'bigint') AS call_duration,
                event_data.value('(event/data[@name="is_remote"]/value)[1]', 'bit') AS is_remote,
                event_data.value('(event/data[@name="command_phase"]/text)[1]', 'nvarchar(100)') AS command_phase_text,
                event_data.value('(event/data[@name="logical_reads"]/value)[1]', 'bigint') AS logical_reads,
                event_data.value('(event/data[@name="physical_reads"]/value)[1]', 'bigint') AS physical_reads,
                event_data.value('(event/data[@name="run_ahead_reads"]/value)[1]', 'bigint') AS run_ahead_reads,
                event_data.value('(event/data[@name="total_page_io_latch_waits"]/value)[1]', 'bigint') AS total_page_io_latch_waits,
                event_data.value('(event/data[@name="page_io_latch_wait_time_in_ms"]/value)[1]', 'bigint') AS page_io_latch_wait_time_in_ms,
                event_data.value('(event/data[@name="total_page_latch_waits"]/value)[1]', 'bigint') AS total_page_latch_waits,
                event_data.value('(event/data[@name="page_latch_wait_time_in_ms"]/value)[1]', 'bigint') AS page_latch_wait_time_in_ms,
                event_data.value('(event/data[@name="messages_sent"]/value)[1]', 'int') AS messages_sent,
                event_data.value('(event/data[@name="messages_received"]/value)[1]', 'int') AS messages_received,
                event_data.value('(event/action[@name="database_name"]/value)[1]', 'sysname') AS database_name,
                CAST(SUBSTRING(event_data.value('(event/action[@name="attach_activity_id"]/value)[1]', 'varchar(50)'), 1, 36) AS uniqueidentifier) as activity_id,
                CAST(SUBSTRING(event_data.value('(event/action[@name="attach_activity_id"]/value)[1]', 'varchar(50)'), 38, 10) AS int) as event_sequence,
                CAST(SUBSTRING(event_data.value('(event/action[@name="attach_activity_id_xfer"]/value)[1]', 'varchar(50)'), 1, 36) AS uniqueidentifier) as activity_id_xfer,
				event_data
			FROM #temp_xml
	) xedata ;

GO

DROP TABLE #temp_xml;
GO

alter event session NewCheck on server
	state = stop;
alter event session CombinedCheck on server
	state = stop;
alter event session OldCheck on server
	state = stop;
GO


INSERT INTO event_timeline (event_name, event_timestamp, event_data)
SELECT event_name, event_timestamp, event_data
	from DBCCCombined;


SELECT * 
	from DBCCNew
order by event_timestamp;

SELECT * 
	from DBCCOld
order by event_timestamp;

SELECT * 
	FROM DBCCCombined
ORDER BY event_timestamp;