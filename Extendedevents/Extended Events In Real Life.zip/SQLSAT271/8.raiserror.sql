USE greek;
GO
DECLARE @DBID INT;
SET @DBID = DB_ID();

DECLARE @DBNAME NVARCHAR(128);
SET @DBNAME = DB_NAME();


BEGIN TRY
	SELECT CAST(morph as int) 
		FROM sblgnt_flat
END TRY
BEGIN CATCH	
	RAISERROR
		(N'Testing system_health errors database_id is:%d, the database name is: %s.',
		25, -- Severity.
		1, -- State.
		@DBID, -- First substitution argument.
		@DBNAME)	
		WITH LOG; -- Second substitution argument.
END CATCH

GO