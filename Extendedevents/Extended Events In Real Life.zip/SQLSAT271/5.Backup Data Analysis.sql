use analysis;
go
/*
	General overview of the backup process
*/
select
	stripe_count, 
	contention_type, 
	backup_type,
	backup_options,
	min(event_timestamp) backup_start, 
	max(event_timestamp) backup_finish,
	count(*) total_actions,
	DATEDIFF(MILLISECOND, MIN(event_timestamp),MAX(event_timestamp)) time_delta_ms,
	(count(*)*1.) / coalesce(DATEDIFF(MILLISECOND, MIN(event_timestamp),MAX(event_timestamp)),1) tasks_per_ms,
	SUM(increment)/1024. as kbytes_written,
	(SUM(increment)/1024.) / coalesce(DATEDIFF(MILLISECOND, MIN(event_timestamp),MAX(event_timestamp)),1) as kb_per_ms
	from analysis.dbo.BackupObservation
group by 
	stripe_count, 
	contention_type, 
	backup_type,
	backup_options
order by DATEDIFF(MILLISECOND, MIN(event_timestamp),MAX(event_timestamp)) asc;

/*
	Get a sense for the waits. 
		ASYNC_IO_COMPLETION: Waiting for IO to complete
		Backup Wait Types: BACKUPIO, BACKUPBUFFER, BACKUPTHREAD
*/

select 
	stripe_count, 
	contention_type, 
	backup_type,
	backup_options, 	
	wait_type, 
	sum(duration) time_waited
from BackupObservation
	where wait_type is not null
group by 
	stripe_count, 
	contention_type, 
	backup_type,
	backup_options, 	
	wait_type
order by stripe_count, contention_type desc, backup_type DESC, backup_options, sum(duration) desc;

/*
	Get the backup sizes
*/
select 
	backup_size/ 1024. / 1024,backup_start_date, backup_finish_date, *
from msdb.dbo.backupset 
/*
	Start with a good old SELECT * from the table holding your data 
	and look at some of the interesting things (note: many of these observations are 
	eminently available in Jonathan Kehayias' blog post(s) on the topic)
*/
select * 
	from BackupObservation
	where stripe_count = 1
		and contention_type = 'Minimal'
		and backup_type = 'Full'
		and backup_options = 'Default'
	order by event_timestamp, event_sequence;
/*
	Just for argument's sake, let's look at the non-default 
*/
select * 
	from BackupObservation
	where 
	stripe_count = 1
		--and contention_type = 'Minimal'
		--and backup_type = 'Full'
		and backup_options <> 'Default'
		and trace_print IS NOT NULL
	order by event_timestamp;
/* 
	Scroll down until you get beyond the 'BackupDatabase: Work estimates done' value for trace_print
	and find the first databases_backup_restore_throughput value after 'Backup:Copying data' (in trace_print)
	and get it's activity_id
	, also, notice that the actvitity that handed off to this task is the main backup task
	originating all the way back up at the sql_text of 'BACKUP DATABASE ...'

	So now let's look just at this little snapshot ...
*/

select *
	from BackupObservation a
	WHERE 
		stripe_count = 1 and contention_type = 'Minimal' and backup_type = 'Full' and backup_options = 'Default' and
		 EXISTS (
					select 1 
						from BackupObservation b
						where exists (
										select 1
										from BackupObservation s
										where trace_print like 'Started file%'
											and b.activity_id_xfer = s.activity_id_xfer
									)
							and a.activity_id = b.activity_id
					)
	order by event_timestamp

/*
	Isolate the events that occur as part of the actual write process and 
		cube the data such that we can see what the tasks did
*/

select 
	stripe_count, 
	contention_type,
	backup_type, 
	backup_options,
	activity_id,
	count(distinct activity_id) activities, 
	count(*) tasks,
	avg(increment) avg_bytes_written,
	case backup_options
		when 'Default' then 1048576-avg(increment)
		else (1048576*2) - avg(increment)
	end as bytes_delta,
	sum(increment) /1024. / 1024 mb_written
	from BackupObservation a 
	WHERE 
		stripe_count = 1 and contention_type = 'Minimal' and backup_type = 'Full' and backup_options = 'Default' and
		EXISTS (
					select 1 
						from BackupObservation b
						where exists (
										select 1
										from BackupObservation s
										where trace_print like 'Started file%'
											and b.activity_id_xfer = s.activity_id_xfer
									)
							and a.activity_id = b.activity_id
					)
	group by CUBE(
					stripe_count, 
					contention_type,
					backup_type, 
					backup_options,
					activity_id
	)
	order by COALESCE(stripe_count,9999), contention_type desc;
	
/*
	Take a look at the NULL mb_written
*/
select * 
	from BackupObservation where activity_id = 'DA7E6AC7-2DAF-4423-9967-A82D6BB19B84'

/*
	Base analytics query
*/
SELECT 
	stripe_count, 	
	contention_type, 
	backup_type, 
	backup_options,
	activity_id,
	lag(event_timestamp,1,null) over (partition by 
										stripe_count, 	
										contention_type, 
										backup_type, 
										backup_options,
										activity_id
							order by event_timestamp) as last_event_timestamp,
	lag(throughput,1,0) over (partition by 
										stripe_count, 	
										contention_type, 
										backup_type, 
										backup_options,
										activity_id
							order by event_timestamp) as last_throughput,
	event_timestamp,
	throughput,

	DATEDIFF(MILLISECOND,lag(event_timestamp,1,null) over (partition by 
										stripe_count, 	
										contention_type, 
										backup_type, 
										backup_options,
										activity_id
							order by event_timestamp), 

						event_timestamp) as delta_t

	,throughput - lag(throughput,1,0) over (partition by 
										stripe_count, 	
										contention_type, 
										backup_type, 
										backup_options,
										activity_id
							order by event_timestamp) as delta_x,
	(throughput - lag(throughput,1,0) over (partition by 
										stripe_count, 	
										contention_type, 
										backup_type, 
										backup_options,
										activity_id
							order by event_timestamp)) * 1. / (							
								DATEDIFF(MILLISECOND,lag(event_timestamp,1,null) over (partition by 
										stripe_count, 	
										contention_type, 
										backup_type, 
										backup_options,
										activity_id
							order by event_timestamp), 
						event_timestamp) 
		) as throughput_velocity_bytes_per_ms
	
	FROM (
			select 
				stripe_count, 
				contention_type, 
				backup_type, 
				backup_options,
				activity_id,
				event_timestamp,				
				sum(increment) throughput			
			from BackupObservation
			where event_name = 'databases_backup_restore_throughput'
			group by 
				stripe_count, 
				contention_type, 
				backup_type, 
				backup_options,
				activity_id,
				event_timestamp
		) base_agg
order by stripe_count,contention_type,backup_type,backup_options,event_timestamp,activity_id


/*
	Acceleration metrics
*/

select 
	stripe_count, contention_type, backup_type, backup_options, activity_id, count(*) as actions,	
	(max(throughput_velocity_bytes_per_ms) - min(throughput_velocity_bytes_per_ms))
		/ datediff(millisecond,min(event_timestamp),max(event_timestamp)) as average_acceleration,
	(sum(throughput) * 1.)/ datediff(millisecond,min(event_timestamp),max(event_timestamp)) as average_velocity
	from (
	SELECT 
	stripe_count, 	
	contention_type, 
	backup_type, 
	backup_options,
	activity_id,
	lag(event_timestamp,1,null) over (partition by 
										stripe_count, 	
										contention_type, 
										backup_type, 
										backup_options,
										activity_id
							order by event_timestamp) as last_event_timestamp,
	lag(throughput,1,0) over (partition by 
										stripe_count, 	
										contention_type, 
										backup_type, 
										backup_options,
										activity_id
							order by event_timestamp) as last_throughput,
	event_timestamp,
	throughput,

	DATEDIFF(MILLISECOND,lag(event_timestamp,1,null) over (partition by 
										stripe_count, 	
										contention_type, 
										backup_type, 
										backup_options,
										activity_id
							order by event_timestamp), 

						event_timestamp) as delta_t

	,throughput - lag(throughput,1,0) over (partition by 
										stripe_count, 	
										contention_type, 
										backup_type, 
										backup_options,
										activity_id
							order by event_timestamp) as delta_x,
	(throughput - lag(throughput,1,0) over (partition by 
										stripe_count, 	
										contention_type, 
										backup_type, 
										backup_options,
										activity_id
							order by event_timestamp)) * 1. / (							
								DATEDIFF(MILLISECOND,lag(event_timestamp,1,null) over (partition by 
										stripe_count, 	
										contention_type, 
										backup_type, 
										backup_options,
										activity_id
							order by event_timestamp), 
						event_timestamp) 
		) as throughput_velocity_bytes_per_ms
	
	FROM (
			select 
				stripe_count, 
				contention_type, 
				backup_type, 
				backup_options,
				activity_id,
				event_timestamp,				
				sum(increment) throughput			
			from BackupObservation
			where event_name = 'databases_backup_restore_throughput'
			group by 
				stripe_count, 
				contention_type, 
				backup_type, 
				backup_options,
				activity_id,
				event_timestamp
		) base_agg) agg
		group by stripe_count, contention_type, backup_type, backup_options, activity_id
		having count(*) > 1
		--order by stripe_count, contention_type desc, backup_options;
		order by (sum(throughput) * 1.)/ datediff(millisecond,min(event_timestamp),max(event_timestamp)) desc;

/*
	if we REALLY wanted to, we could find the significant stripes and then run the same analytics on them
*/

select stripe_count, contention_type, backup_type, backup_options, event_name, trace_print, activity_id
	from BackupObservation where stripe_count = 1 and contention_type = 'Minimal' and backup_options = 'Default' and backup_type = 'Full'
	order by event_timestamp, event_sequence

/*
	scroll down until we find in the trace where the file is started and then find the activity_id(s) associated with databases_backup_restore_throughput events
*/

select stripe_count, contention_type, backup_type, backup_options, event_name, trace_print, activity_id
	from BackupObservation where stripe_count = 2 and contention_type = 'Minimal' and backup_options = 'Default' and backup_type = 'Full'
	order by event_timestamp, event_sequence

/* 
	Now let's get some data for these events
*/
DECLARE @InterestingActivities TABLE (
	activity_id UNIQUEIDENTIFIER NOT NULL
)

insert into @InterestingActivities (activity_id) 
	VALUES ('3610D1DC-62CB-449A-9E03-175AC190D1E6'),('274B7616-782E-4850-B469-94370CB34B4B'),('C2E4F339-4CAB-4093-9B25-0AE2F0AB8589')

SELECT 
	stripe_count, 	
	contention_type, 
	backup_type, 
	backup_options,
	activity_id,
	lag(event_timestamp,1,null) over (partition by 
										stripe_count, 	
										contention_type, 
										backup_type, 
										backup_options,
										activity_id
							order by event_timestamp) as last_event_timestamp,
	lag(throughput,1,0) over (partition by 
										stripe_count, 	
										contention_type, 
										backup_type, 
										backup_options,
										activity_id
							order by event_timestamp) as last_throughput,
	event_timestamp,
	throughput,

	DATEDIFF(MILLISECOND,lag(event_timestamp,1,null) over (partition by 
										stripe_count, 	
										contention_type, 
										backup_type, 
										backup_options,
										activity_id
							order by event_timestamp), 

						event_timestamp) as delta_t

	,throughput - lag(throughput,1,0) over (partition by 
										stripe_count, 	
										contention_type, 
										backup_type, 
										backup_options,
										activity_id
							order by event_timestamp) as delta_x,
	(throughput - lag(throughput,1,0) over (partition by 
										stripe_count, 	
										contention_type, 
										backup_type, 
										backup_options,
										activity_id
							order by event_timestamp)) * 1. / (							
								DATEDIFF(MILLISECOND,lag(event_timestamp,1,null) over (partition by 
										stripe_count, 	
										contention_type, 
										backup_type, 
										backup_options,
										activity_id
							order by event_timestamp), 
						event_timestamp) 
		) as throughput_velocity_bytes_per_ms
	
	FROM (
			select 
				stripe_count, 
				contention_type, 
				backup_type, 
				backup_options,
				activity_id,
				event_timestamp,				
				sum(increment) throughput			
			from BackupObservation b
			where --event_name = 'databases_backup_restore_throughput'
				exists (select 1 from @InterestingActivities i where i.activity_id = b.activity_id)
			group by 
				stripe_count, 
				contention_type, 
				backup_type, 
				backup_options,
				activity_id,
				event_timestamp
		) base_agg
order by stripe_count,contention_type,backup_type,backup_options,event_timestamp,activity_id

/*
	and acceleration metrics
*/

select 
	base.stripe_count, base.contention_type, base.backup_type, base.backup_options, activity_id, count(*) as actions,	
	(max(throughput_velocity_bytes_per_ms) - min(throughput_velocity_bytes_per_ms))
		/ datediff(millisecond,min(event_timestamp),max(event_timestamp)) as average_acceleration,
	(sum(throughput) * 1.)/ datediff(millisecond,min(event_timestamp),max(event_timestamp)) as average_velocity,
	agg.total_actions, agg.time_delta_ms, agg.tasks_per_ms, agg.kbytes_written, agg.tasks_per_ms
	from (
SELECT 
	stripe_count, 	
	contention_type, 
	backup_type, 
	backup_options,
	activity_id,
	lag(event_timestamp,1,null) over (partition by 
										stripe_count, 	
										contention_type, 
										backup_type, 
										backup_options,
										activity_id
							order by event_timestamp) as last_event_timestamp,
	lag(throughput,1,0) over (partition by 
										stripe_count, 	
										contention_type, 
										backup_type, 
										backup_options,
										activity_id
							order by event_timestamp) as last_throughput,
	event_timestamp,
	throughput,

	DATEDIFF(MILLISECOND,lag(event_timestamp,1,null) over (partition by 
										stripe_count, 	
										contention_type, 
										backup_type, 
										backup_options,
										activity_id
							order by event_timestamp), 

						event_timestamp) as delta_t

	,throughput - lag(throughput,1,0) over (partition by 
										stripe_count, 	
										contention_type, 
										backup_type, 
										backup_options,
										activity_id
							order by event_timestamp) as delta_x,
	(throughput - lag(throughput,1,0) over (partition by 
										stripe_count, 	
										contention_type, 
										backup_type, 
										backup_options,
										activity_id
							order by event_timestamp)) * 1. / (							
								DATEDIFF(MILLISECOND,lag(event_timestamp,1,null) over (partition by 
										stripe_count, 	
										contention_type, 
										backup_type, 
										backup_options,
										activity_id
							order by event_timestamp), 
						event_timestamp) 
		) as throughput_velocity_bytes_per_ms
	
	FROM (
			select 
				stripe_count, 
				contention_type, 
				backup_type, 
				backup_options,
				activity_id,
				event_timestamp,				
				sum(increment) throughput			
			from BackupObservation b
			where --event_name = 'databases_backup_restore_throughput'
				exists (select 1 from @InterestingActivities i where i.activity_id = b.activity_id)
			group by 
				stripe_count, 
				contention_type, 
				backup_type, 
				backup_options,
				activity_id,
				event_timestamp
		) base_agg
		)base
		join (
			select
	stripe_count, 
	contention_type, 
	backup_type,
	backup_options,
	min(event_timestamp) backup_start, 
	max(event_timestamp) backup_finish,
	count(*) total_actions,
	DATEDIFF(MILLISECOND, MIN(event_timestamp),MAX(event_timestamp)) time_delta_ms,
	(count(*)*1.) / coalesce(DATEDIFF(MILLISECOND, MIN(event_timestamp),MAX(event_timestamp)),1) tasks_per_ms,
	SUM(increment)/1024. as kbytes_written,
	(SUM(increment)/1024.) / coalesce(DATEDIFF(MILLISECOND, MIN(event_timestamp),MAX(event_timestamp)),1) as kb_per_ms
	from analysis.dbo.BackupObservation
group by 
	stripe_count, 
	contention_type, 
	backup_type,
	backup_options
		) agg
		on base.stripe_count = agg.stripe_count
			and base.contention_type = agg.contention_type
			and base.backup_type = agg.backup_type
			and base.backup_options = agg.backup_options
group by base.stripe_count, base.contention_type, base.backup_type, base.backup_options, base.activity_id,agg.total_actions, agg.time_delta_ms, agg.tasks_per_ms, agg.kbytes_written, agg.tasks_per_ms


select
	stripe_count, 
	contention_type, 
	backup_type,
	backup_options,
	min(event_timestamp) backup_start, 
	max(event_timestamp) backup_finish,
	count(*) total_actions,
	DATEDIFF(MILLISECOND, MIN(event_timestamp),MAX(event_timestamp)) time_delta_ms,
	(count(*)*1.) / coalesce(DATEDIFF(MILLISECOND, MIN(event_timestamp),MAX(event_timestamp)),1) tasks_per_ms,
	SUM(increment)/1024. as kbytes_written,
	(SUM(increment)/1024.) / coalesce(DATEDIFF(MILLISECOND, MIN(event_timestamp),MAX(event_timestamp)),1) as kb_per_ms
	from analysis.dbo.BackupObservation
group by 
	stripe_count, 
	contention_type, 
	backup_type,
	backup_options
order by DATEDIFF(MILLISECOND, MIN(event_timestamp),MAX(event_timestamp)) desc;