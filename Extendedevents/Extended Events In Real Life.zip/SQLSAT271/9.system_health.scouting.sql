﻿/*
	 Yeah ... I meant to tell you that just before lunch 'the database was slow' but 
		I couldn't figure out how to use my phone and when I walked over you looked hung over and angry.
*/
use analysis
go

select * 
	from event_timeline
	where spsd_component is not null
order by event_timestamp

/*
	Get a sense for what you're looking at 
*/
select event_name, count(*)
	from system_health.system_health_xlat	
	group by event_name;

/*
*/
select * 
	from system_health.system_health_xlat	
	order by event_timestamp

/*
	Profile that hour
*/

select event_name, count(*)
	from system_health.system_health_xlat	
	where
	DATEADD(HOUR,-7,event_timestamp) >= '2014-01-16 11:00'
		and DATEADD(HOUR,-7,event_timestamp) < '2014-01-16 12:00'
	and event_name <> 'security_error_ring_buffer_recorded'	
	group by event_name;

/*
	Get a feel for the sequence in that hour
*/

select 
	event_name,
	DATEADD(HOUR,-7,event_timestamp) as event_timestamp, 
	spsd_component,
	spsd_component_state
	from system_health.system_health_xlat
where
	DATEADD(HOUR,-7,event_timestamp) >= '2014-01-16 11:00'
		and DATEADD(HOUR,-7,event_timestamp) < '2014-01-16 12:00'
	and event_name <> 'security_error_ring_buffer_recorded'	
order by event_timestamp, spsd_component

--deadlocks
select 
	event_name, 
	DATEADD(HOUR,-7,event_timestamp) as event_timestamp, 
	deadlock_graph, 
	event_data
from system_health.system_health_deadlocks	
order by event_timestamp

--system_health_ring_buffer

	select 
		rb.event_name, 
		rb.event_timestamp, 
		rb.process_utilization_pct_change, 
		base_agg.mean_procusage_change, 
		base_agg.stdev_procusage_change,
		rb.process_utilization,
		base_agg.mean_procusage,
		base_agg.stdev_procusage,
		n
	FROM (
	SELECT 
	event_name, 
	DATEADD(HOUR,-7,event_timestamp) as event_timestamp, 
	user_mode_time, 
	(user_mode_time * 1.  - LAG(user_mode_time,1,user_mode_time) OVER (ORDER BY event_timestamp)) / 
		COALESCE(NULLIF(LAG(user_mode_time,1,user_mode_time) OVER (ORDER BY event_timestamp),0),1)  * 100 
			as user_mode_pct_change,
	kernel_mode_time, 
	(kernel_mode_time * 1.  - LAG(kernel_mode_time,1,kernel_mode_time) OVER (ORDER BY event_timestamp)) / 
		COALESCE(NULLIF(LAG(kernel_mode_time,1,kernel_mode_time) OVER (ORDER BY event_timestamp),0),1) * 100 
			as kernel_mode_pct_change,
	memory_utilization, 
	(memory_utilization * 1.  - LAG(memory_utilization,1,memory_utilization) OVER (ORDER BY event_timestamp)) / 
		COALESCE(NULLIF(LAG(memory_utilization,1,memory_utilization) OVER (ORDER BY event_timestamp),0),1)  * 100 
			as memory_utilization_pct_change,
	page_faults, 
	(page_faults * 1.  - LAG(page_faults,1,page_faults) OVER (ORDER BY event_timestamp)) / 
		COALESCE(NULLIF(LAG(page_faults,1,page_faults) OVER (ORDER BY event_timestamp),0),1) * 100 
			as page_faults_pct_change,
	process_utilization, 
	(process_utilization * 1.  - LAG(process_utilization,1,process_utilization) OVER (ORDER BY event_timestamp)) / 
		COALESCE(NULLIF(LAG(process_utilization,1,process_utilization) OVER (ORDER BY event_timestamp),0),1)  * 100 
			as process_utilization_pct_change,
	system_idle,
	working_set_delta, 
	(working_set_delta * 1.  - LAG(working_set_delta,1,working_set_delta) OVER (ORDER BY event_timestamp)) / 
		COALESCE(NULLIF(LAG(working_set_delta,1,working_set_delta) OVER (ORDER BY event_timestamp),0),1) * 100 as working_set_delta_pct_change,
	COUNT(*) OVER () as n,
	event_data
	from system_health.system_health_ring_buffers ) rb
	JOIN (SELECT 
								event_name,
								AVG(user_mode_time) mean_umode_time, 
								AVG(user_mode_pct_change) mean_umode_change,
								AVG(kernel_mode_time) mean_kmode_time,
								AVG(kernel_mode_pct_change) mean_kmode_change,
								AVG(memory_utilization) mean_memusage, 
								AVG(memory_utilization_pct_change) mean_memusage_change,
								AVG(page_faults) mean_pagefaults,
								AVG(page_faults_pct_change) mean_pagefaults_change,
								AVG(process_utilization) mean_procusage, 
								AVG(process_utilization_pct_change) mean_procusage_change,
								AVG(working_set_delta) mean_ws_delta,
								AVG(working_set_delta_pct_change) mean_ws_delta_change,
								AVG(system_idle) mean_systemidle,
								STDEV(user_mode_time) stdev_umode_time, 
								STDEV(user_mode_pct_change) stdev_umode_change,
								STDEV(kernel_mode_time) stdev_kmode_time,
								STDEV(kernel_mode_pct_change) stdev_kmode_change,
								STDEV(memory_utilization) stdev_memusage, 
								STDEV(memory_utilization_pct_change) stdev_memusage_change,
								STDEV(page_faults) stdev_pagefaults,
								STDEV(page_faults_pct_change) stdev_pagefaults_change,
								STDEV(process_utilization) stdev_procusage, 
								STDEV(process_utilization_pct_change) stdev_procusage_change,
								STDEV(working_set_delta) stdev_ws_delta,
								STDEV(working_set_delta_pct_change) stdev_ws_delta_change,
								STDEV(system_idle) stdev_systemidle
							FROM 
							(
								select 
								event_name, 
								DATEADD(HOUR,-7,event_timestamp) as event_timestamp, 
								user_mode_time, 
								(user_mode_time * 1.  - LAG(user_mode_time,1,user_mode_time) OVER (ORDER BY event_timestamp)) / 
									COALESCE(NULLIF(LAG(user_mode_time,1,user_mode_time) OVER (ORDER BY event_timestamp),0),1)  * 100 
										as user_mode_pct_change,
								kernel_mode_time, 
								(kernel_mode_time * 1.  - LAG(kernel_mode_time,1,kernel_mode_time) OVER (ORDER BY event_timestamp)) / 
									COALESCE(NULLIF(LAG(kernel_mode_time,1,kernel_mode_time) OVER (ORDER BY event_timestamp),0),1) * 100 
										as kernel_mode_pct_change,
								memory_utilization, 
								(memory_utilization * 1.  - LAG(memory_utilization,1,memory_utilization) OVER (ORDER BY event_timestamp)) / 
									COALESCE(NULLIF(LAG(memory_utilization,1,memory_utilization) OVER (ORDER BY event_timestamp),0),1)  * 100 
										as memory_utilization_pct_change,
								page_faults, 
								(page_faults * 1.  - LAG(page_faults,1,page_faults) OVER (ORDER BY event_timestamp)) / 
									COALESCE(NULLIF(LAG(page_faults,1,page_faults) OVER (ORDER BY event_timestamp),0),1) * 100 
										as page_faults_pct_change,
								process_utilization, 
								(process_utilization * 1.  - LAG(process_utilization,1,process_utilization) OVER (ORDER BY event_timestamp)) / 
									COALESCE(NULLIF(LAG(process_utilization,1,process_utilization) OVER (ORDER BY event_timestamp),0),1)  * 100 
										as process_utilization_pct_change,
								system_idle,
								working_set_delta, 
								(working_set_delta * 1.  - LAG(working_set_delta,1,working_set_delta) OVER (ORDER BY event_timestamp)) / 
									COALESCE(NULLIF(LAG(working_set_delta,1,working_set_delta) OVER (ORDER BY event_timestamp),0),1) * 100 as working_set_delta_pct_change,
								event_data
								from system_health.system_health_ring_buffers
								where event_name = 'scheduler_monitor_system_health_ring_buffer_recorded'				
							) base
							group by event_name	
						) base_agg							
						ON ABS((base_agg.mean_procusage_change - rb.process_utilization_pct_change) / base_agg.stdev_procusage_change) >= 2 
							OR ABS((base_agg.mean_procusage - rb.process_utilization) / base_agg.stdev_procusage) >= 2 
		order by rb.event_timestamp


--order by event_timestamp

-- shrb_fine	
select 
	event_name, 
	DATEADD(HOUR,-7,event_timestamp) as event_timestamp, 
	user_mode_time, 
	(user_mode_time * 1.  - LAG(user_mode_time,1,user_mode_time) OVER (ORDER BY event_timestamp)) / 
		COALESCE(NULLIF(LAG(user_mode_time,1,user_mode_time) OVER (ORDER BY event_timestamp),0),1)  * 100 
			as user_mode_pct_change,
	kernel_mode_time, 
	(kernel_mode_time * 1.  - LAG(kernel_mode_time,1,kernel_mode_time) OVER (ORDER BY event_timestamp)) / 
		COALESCE(NULLIF(LAG(kernel_mode_time,1,kernel_mode_time) OVER (ORDER BY event_timestamp),0),1) * 100 
			as kernel_mode_pct_change,
	memory_utilization, 
	(memory_utilization * 1.  - LAG(memory_utilization,1,memory_utilization) OVER (ORDER BY event_timestamp)) / 
		COALESCE(NULLIF(LAG(memory_utilization,1,memory_utilization) OVER (ORDER BY event_timestamp),0),1)  * 100 
			as memory_use_pct_change,
	page_faults, 
	(page_faults * 1.  - LAG(page_faults,1,page_faults) OVER (ORDER BY event_timestamp)) / 
		COALESCE(NULLIF(LAG(page_faults,1,page_faults) OVER (ORDER BY event_timestamp),0),1) * 100 
			as page_faults_pct_change,
	process_utilization, 
	(process_utilization * 1.  - LAG(process_utilization,1,process_utilization) OVER (ORDER BY event_timestamp)) / 
		COALESCE(NULLIF(LAG(process_utilization,1,process_utilization) OVER (ORDER BY event_timestamp),0),1)  * 100 
			as process_use_pct_change,
	system_idle,
	working_set_delta, 
	(working_set_delta * 1.  - LAG(working_set_delta,1,working_set_delta) OVER (ORDER BY event_timestamp)) / 
		COALESCE(NULLIF(LAG(working_set_delta,1,working_set_delta) OVER (ORDER BY event_timestamp),0),1) * 100 as working_set_delta_pct_change,
	event_data
	from system_health.system_health_ring_buffers
	where event_name = 'scheduler_monitor_system_health_ring_buffer_recorded'
order by event_timestamp

--
--memory_broker_ring_buffer_recorded
select 
	event_name, 
	DATEADD(HOUR,-7,event_timestamp) as event_timestamp, 
	broker,
	notification, 
	delta_time, 
	memory_ratio, 
	new_target,
	overall,
	rate,
	currently_predicated,
	currently_allocated,
	previously_allocated,
	event_data
	from system_health.system_health_ring_buffers
	where event_name = 'memory_broker_ring_buffer_recorded'

order by event_timestamp

-- connectivity
select 	
	event_name, 
	DATEADD(HOUR,-7,event_timestamp) as event_timestamp, 
	call_stack,
	type, 
	source, 
	os_error,
	sni_error,
	sni_consumer_error,
	sni_provider,
	state,	
	local_host,
	local_port,
	remote_host,
	remote_port,
	tds_input_buffer_error,
	tds_output_buffer_error,
	tds_input_buffer_bytes,
	tds_flags_bin,
	tds_flags_text,
	total_login_time_ms,
	login_task_enqueued_ms,
	network_writes_ms,
	network_reads_ms,
	ssl_processing_ms,
	sspi_processing_ms,
	login_trigger_and_resource_governor_processing_ms,
	connection_id,
	connection_peer_id,
	event_data
from system_health.system_health_ring_buffers
	where event_name = 'connectivity_ring_buffer_recorded'
order by event_timestamp

-- errors during timeframe
select 	
	event_name,
	DATEADD(HOUR,-7,event_timestamp) as event_timestamp, 
	session_id,
	wait_type as error_number,
	severity,
	state,
	user_defined,
	category_id,
	category_desc,
	destination_id,
	destination_desc,
	callstack,
	database_id,
	tsql_stack,
	sql_text,
	event_data	
from system_health.system_health_errors
order by event_timestamp

/*
	diagnostics components results

	!!NOTE!!
	cpu intensive processes and pending tasks (in event_data)
*/
SELECT 
	event_name,
	DATEADD(HOUR,-7,event_timestamp) as event_timestamp, 
	component_group,
	spsd_component,
	spsd_component_state,	
	spinlockBackoffs spinlock_backoffs, 
	latchWarnings latch_warnings,
	((latchWarnings * 1.) - LAG(latchWarnings,1,latchWarnings) OVER (PARTITION BY component_group ORDER BY event_timestamp)) / 
		COALESCE(NULLIF(LAG(latchWarnings,1,NULL) OVER (PARTITION BY component_group ORDER BY event_timestamp),0),1) *100 as latch_warnings_pct_change,
	pageFaults page_faults, 
	((pageFaults * 1.) - LAG(pageFaults,1,pageFaults) OVER (PARTITION BY component_group ORDER BY event_timestamp)) / 
		COALESCE(NULLIF(LAG(pageFaults,1,NULL) OVER (PARTITION BY component_group ORDER BY event_timestamp),0),1)  *100 as page_faults_pct_Change,
	writeAccessViolationCount write_access_violations,
	((writeAccessViolationCount * 1.) - LAG(writeAccessViolationCount,1,writeAccessViolationCount) OVER (PARTITION BY component_group ORDER BY event_timestamp)) /
		 COALESCE(NULLIF(LAG(writeAccessViolationCount,1,NULL) OVER (PARTITION BY component_group ORDER BY event_timestamp),0),1)  *100 as write_access_violations_pct_change,	
	totalDumpRequests total_dump_requests,
	nonYieldingTasksReported nonyielding_tasks,	
	maxWorkers max_workers,
	((maxWorkers * 1.) - LAG(maxWorkers,1,maxWorkers) OVER (PARTITION BY component_group ORDER BY event_timestamp)) /
		 COALESCE(NULLIF(LAG(maxWorkers,1,NULL) OVER (PARTITION BY component_group ORDER BY event_timestamp),0),1)  *100 as max_schedulers_pct_change,	
	workersCreated workers_created,
	((workersCreated * 1.) - LAG(workersCreated,1,workersCreated) OVER (PARTITION BY component_group ORDER BY event_timestamp)) /
		 COALESCE(NULLIF(LAG(workersCreated,1,NULL) OVER (PARTITION BY component_group ORDER BY event_timestamp),0),1)  *100 as workers_created_pct_change,	
	workersIdle idle_workers,
	((workersIdle * 1.) - LAG(workersIdle,1,workersIdle) OVER (PARTITION BY component_group ORDER BY event_timestamp)) /
		 COALESCE(NULLIF(LAG(workersIdle,1,NULL) OVER (PARTITION BY component_group ORDER BY event_timestamp),0),1)  *100 as idle_workers_pct_change,	
	available_physical_memory,
	((available_physical_memory * 1.) - LAG(available_physical_memory,1,available_physical_memory) OVER (PARTITION BY component_group ORDER BY event_timestamp)) /
		 COALESCE(NULLIF(LAG(available_physical_memory,1,NULL) OVER (PARTITION BY component_group ORDER BY event_timestamp),0),1)  *100 as available_physical_memory_pct_change,	
	available_paging_file,
	((available_paging_file * 1.) - LAG(available_paging_file,1,available_paging_file) OVER (PARTITION BY component_group ORDER BY event_timestamp)) /
		 COALESCE(NULLIF(LAG(available_paging_file,1,NULL) OVER (PARTITION BY component_group ORDER BY event_timestamp),0),1)  *100 as available_paging_file_pct_change,	
	working_set,
	((working_set * 1.) - LAG(working_set,1,working_set) OVER (PARTITION BY component_group ORDER BY event_timestamp)) /
		 COALESCE(NULLIF(LAG(working_set,1,NULL) OVER (PARTITION BY component_group ORDER BY event_timestamp),0),1)  *100 as working_set_pct_change,	
	target_committed, 
	((target_committed * 1.) - LAG(target_committed,1,target_committed) OVER (PARTITION BY component_group ORDER BY event_timestamp)) /
		 COALESCE(NULLIF(LAG(target_committed,1,NULL) OVER (PARTITION BY component_group ORDER BY event_timestamp),0),1)  *100 as target_committed_pct_change,	
	current_committed, 
	((current_committed * 1.) - LAG(current_committed,1,current_committed) OVER (PARTITION BY component_group ORDER BY event_timestamp)) /
		 COALESCE(NULLIF(LAG(current_committed,1,NULL) OVER (PARTITION BY component_group ORDER BY event_timestamp),0),1)  *100 as current_committed_pct_change,	
	pages_allocated, 
	((pages_allocated * 1.) - LAG(pages_allocated,1,pages_allocated) OVER (PARTITION BY component_group ORDER BY event_timestamp)) /
		 COALESCE(NULLIF(LAG(pages_allocated,1,NULL) OVER (PARTITION BY component_group ORDER BY event_timestamp),0),1)  *100 as pages_allocated_pct_change,	
	
	tasksCompletedWithinInterval interval_completed_tasks,
	(tasksCompletedWithinInterval * 1.) / 
		COALESCE(NULLIF(
		DATEDIFF(SECOND,
			LAG(event_timestamp,1,event_timestamp) OVER (PARTITION BY component_group ORDER BY event_timestamp),
			event_timestamp)
		,0),1) as completed_tasks_per_second,	
	oldestPendingTaskWaitingTime pendingTasksCount,	
	npwaits_bycount,
	npwaits_byduration,
	pwaits_bycount,
	nwaits_byduration,
	cpuIntensiveRequests cpu_intensive_requests, 
	pendingTasks pending_tasks,
	lastNotification memory_notification, 
	outOfMemoryExceptions oom_exceptions,
	isAnyPoolOutOfMemory is_any_pool_oom, 
	processOutOfMemoryPeriod proc_oom_period, 	
	longestPendingRequests,
	event_data.query('/event/data[@name="data"]/value/queryProcessing/pendingTasks') pending_task,
	event_data
	FROM ( 
		SELECT 
			DENSE_RANK() OVER (ORDER BY spsd_component) as component_group
			, *
			FROM system_health.system_health_spsd f
		
		) base
order by event_timestamp, component_group

-- raw waits during timeframe
select 
	event_name, 
	DATEADD(HOUR,-7,event_timestamp) as event_timestamp, 
	DATEDIFF(SECOND,'2014-01-15 21:34:26.0300000',DATEADD(HOUR,-7,event_timestamp)),
	wait_type,
	opcode,
	wait_duration,
	session_id,
	sql_text,
	callstack,
	event_data
	from system_health.system_health_waits
order by event_timestamp

-- waits cube during timeframe
select 
	wait_type, 
	sql_text, 	
	count(*) waits,
	sum(wait_duration) duration
from system_health.system_health_waits
group by wait_type, sql_text with cube
order by sql_text;

select * 
	from system_health.system_health_waits
	where sql_text = N'EXECUTE GetConcordanceLines N''καὶ'''
order by event_timestamp