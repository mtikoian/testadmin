
use analysis;
go
IF OBJECT_ID('ModuleObservation') IS NOT NULL
	DROP TABLE ModuleObservation;
GO
SELECT 
 event_data.value('(event/@name)[1]', 'varchar(50)') AS event_name,
 event_data.value('(event/data[@name="object_name"]/value)[1]','sysname') as object_name,
 event_data.value('(event/data[@name="object_type"]/value)[1]','sysname') as object_type,
 event_data.value('(event/data[@name="duration"]/value)[1]','bigint') as duration,
 event_data.value('(event/@timestamp)[1]', 'datetime2') AS event_timestamp,
 event_data.value('(event/data[@name="statement"]/value)[1]','nvarchar(max)') as statement,        
 event_data.value('(event/data[@name="sql_text"]/value)[1]','nvarchar(max)') as sql_text,     
 event_data.value('(event/action[@name="username"]/value)[1]','sysname') as username,
	CAST(SUBSTRING(event_data.value('(event/action[@name="attach_activity_id"]/value)[1]', 'varchar(50)'), 1, 36) AS uniqueidentifier) as activity_id,
                CAST(SUBSTRING(event_data.value('(event/action[@name="attach_activity_id"]/value)[1]', 'varchar(50)'), 38, 10) AS int) as event_sequence,
                CAST(SUBSTRING(event_data.value('(event/action[@name="attach_activity_id_xfer"]/value)[1]', 'varchar(50)'), 1, 36) AS uniqueidentifier) as activity_id_xfer,
 event_data
into ModuleObservation
FROM (
SELECT
    CAST(event_data AS XML) AS event_data
FROM sys.fn_xe_file_target_read_file('D:\event_sessions\sql_module*.xel', NULL, NULL, NULL)

) xe

GO

INSERT INTO event_timeline (event_name, event_timestamp, event_data)
SELECT event_name, event_timestamp, event_data
	from ModuleObservation;

select * 
	from ModuleObservation
order by event_timestamp asc;

