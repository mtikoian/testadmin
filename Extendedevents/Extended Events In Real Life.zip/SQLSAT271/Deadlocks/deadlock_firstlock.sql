use greek
go
-- step 1

begin transaction
update concordance
	set sort_order = 100
where sort_order = 5
-- new query window

-- come back and run this
update wordriver
set chapter = 10000
where chapter = 2

--clean up
rollback