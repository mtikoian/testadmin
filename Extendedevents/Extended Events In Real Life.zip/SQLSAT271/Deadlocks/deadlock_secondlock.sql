use greek
go
begin transaction 
update wordriver
set chapter = 5000
where chapter = 1

update concordance
	set sort_order = -100
where sort_order = -5 

-- go back to the first query window and run the second update
rollback