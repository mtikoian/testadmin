use se_network
GO
--ALTER VIEW se_user_activity 
--AS 
--SELECT * 
--FROM (
--	select 
--		'DBA' as se_site,
--		u.user_display_name, 
--		u.user_email_hash,
--		post_type_id,		
--		post_view_count,
--		post_favorite_count,
--		post_answer_count,
--		post_comment_count,
--		post_score,
--		len(post_body) post_length		
--		from dba.dbo.Post p 
--		join dba.dbo.[User] u 
--			on p.post_owner_user_id = u.user_id
--		WHERE u.user_id <> -1
--UNION ALL
--select 
--		'SuperUser' as se_site,
--		u.user_display_name, 
--		u.user_email_hash,
--		post_type_id,		
--		post_view_count,
--		post_favorite_count,
--		post_answer_count,
--		post_comment_count,
--		post_score,
--		len(post_body) post_length		
--		from su.dbo.Post p 
--		join su.dbo.[User] u 
--			on p.post_owner_user_id = u.user_id
--		WHERE u.user_id <> -1
--UNION ALL
--select 
--		'ServerFault' as se_site,
--		u.user_display_name, 
--		u.user_email_hash,
--		post_type_id,		
--		post_view_count,
--		post_favorite_count,
--		post_answer_count,
--		post_comment_count,
--		post_score,
--		len(post_body) post_length		
--		from sf.dbo.Post p 
--		join sf.dbo.[User] u 
--			on p.post_owner_user_id = u.user_id
--		WHERE u.user_id <> -1
--	) base;

SET STATISTICS IO ON 
SET STATISTICS TIME ON
GO


dbcc freeproccache
go 
dbcc dropcleanbuffers
go


/*
CREATE procedure get_se_users -- <------------ hoping to catch execution of this object
as
	set nocount on ;
	select
		se_site, 
		user_display_name,
		post_type_id, 
		sum(coalesce(post_view_count,0)) post_views,
		sum(coalesce(post_favorite_count,0)) post_favorite_count,
		sum(coalesce(post_answer_count,0)) post_answer_count,
		sum(coalesce(post_comment_count,0)) post_comment_count, 
		sum(coalesce(post_score,0)) total_score,
		avg(post_length) avg_post_length
		from se_user_activity s	
	where user_display_name = 'swasheck'
		or user_display_name = 'Aaron Bertrand'
		or user_display_name = 'Mike Fal'
		or user_display_name = 'mrdenny'
		or user_display_name = 'billinkc'
		or user_display_name = 'mmarie'
	group by
		se_site, 
		user_display_name,
		post_type_id
	order by se_site, user_display_name;
*/

execute sp_executesql get_se_users;

-- ~5 minutes
create clustered index cix_user_user_id on dba.dbo.[User] (user_id);
GO
create clustered index cix_post_user_id on dba.dbo.[Post] (post_owner_user_id);
GO

create clustered index cix_user_user_id on sf.dbo.[User] (user_id);
GO
create clustered index cix_post_user_id on sf.dbo.[Post] (post_owner_user_id);
GO

create clustered index cix_user_user_id on su.dbo.[User] (user_id);
GO
create clustered index cix_post_user_id on su.dbo.[Post] (post_owner_user_id);
GO

dbcc freeproccache
go 
dbcc dropcleanbuffers
go


execute sp_executesql get_se_users;


