
/*
	Event Session DDL (except system_health)
*/

/*
	sql_module_execution
		EVENTS:
			module_start - 
			module_end - 			
		ACTIONS:
			sql_text 
			username - 
*/
CREATE EVENT SESSION sql_module_execution ON SERVER 
	ADD EVENT sqlserver.module_end(
		ACTION(				
				sqlserver.username,
				sqlserver.sql_text
			)
			WHERE ([sqlserver].[database_id]=(11))), 
	ADD EVENT sqlserver.module_start(
		ACTION(
				sqlserver.username,
				sqlserver.sql_text
			)
			WHERE ([sqlserver].[database_id]=(11)))
	--,ADD EVENT sqlserver.sql_statement_completed(
	--	ACTION(
	--			sqlserver.transaction_id,
	--			sqlserver.transaction_sequence,
	--			sqlserver.tsql_frame,
	--			sqlserver.tsql_stack,
	--			sqlserver.username
	--			)
	--		WHERE ([sqlserver].[database_id]=(11))),
	--ADD EVENT sqlserver.sql_statement_starting(
	--	ACTION(
	--			sqlserver.transaction_id,
	--			sqlserver.transaction_sequence,
	--			sqlserver.tsql_frame,
	--			sqlserver.tsql_stack,
	--			sqlserver.username
	--		)
	--		WHERE ([sqlserver].[database_id]=(11)))
	ADD TARGET package0.event_file(SET filename=N'D:\event_sessions\sql_module_execution.xel')
WITH (
	EVENT_RETENTION_MODE=ALLOW_SINGLE_EVENT_LOSS,		
	TRACK_CAUSALITY=ON)
GO
/*
	DBCC Event Descriptions

	OLD: 
	databases_dbcc_logical_scan - Databases DBCC logical scan

	NEW: 
	check_phase_tracing � Occurs when DBCC CHECK enters a new phase of the checking. 
		Use this event to trace the phases of DBCC CHECK process.
	check_thread_message_statistics � Occurs when a phase of DBCC CHECK is finished. 
		Use this event to collect the number of messages a 
			DBCC CHECK thread has sent or received.
	check_thread_page_io_statistics � Occurs when a phase of DBCC CHECK is finished. 
		Use this event to collect the number of logical, physical, 
			and read-ahead IOs a DBCC CHECK thread has performed.
	check_thread_page_latch_statistics � Occurs when a phase of DBCC CHECK is finished. 
		Use This event to collect the number and time of page latch and IO latch waits.

*/
CREATE EVENT SESSION NewCheck ON SERVER
    ADD EVENT sqlserver.check_phase_tracing(
        ACTION(
            sqlserver.database_name)),
    ADD EVENT sqlserver.check_thread_message_statistics(
        ACTION(
            sqlserver.database_name)),
    ADD EVENT sqlserver.check_thread_page_io_statistics(
        ACTION(
            sqlserver.database_name)),
    ADD EVENT sqlserver.check_thread_page_latch_statistics(
        ACTION(
            sqlserver.database_name))
    ADD TARGET package0.event_file(
		SET filename='D:\event_sessions\DBCCNewCheck.xel'
		--,metadatafile = 'D:\temp\DBCCNewCheck.xem') --2008 only
		)
	WITH (
		EVENT_RETENTION_MODE=ALLOW_SINGLE_EVENT_LOSS,		
		TRACK_CAUSALITY=ON);

GO

--Create the event session for the event that already exists 
CREATE EVENT SESSION OldCheck ON SERVER
    ADD EVENT sqlserver.databases_dbcc_logical_scan(
    ACTION(
         sqlserver.database_name))
ADD TARGET package0.event_file(
		SET filename='D:\event_sessions\DBCCOldCheck.xel'
		--,metadatafile = 'D:\temp\DBCCOldCheck.xem') --2008 only
		)
        WITH (MAX_DISPATCH_LATENCY=30 SECONDS,
        MAX_EVENT_SIZE=0 KB,
        TRACK_CAUSALITY=ON);
GO
-- How about a combined sessio?
CREATE EVENT SESSION CombinedCheck ON SERVER
    ADD EVENT sqlserver.check_phase_tracing(
        ACTION(
            sqlserver.database_name)),
    ADD EVENT sqlserver.check_thread_message_statistics(
        ACTION(
            sqlserver.database_name)),
    ADD EVENT sqlserver.check_thread_page_io_statistics(
        ACTION(
            sqlserver.database_name)),
    ADD EVENT sqlserver.check_thread_page_latch_statistics(
        ACTION(
            sqlserver.database_name)),
	ADD EVENT sqlserver.databases_dbcc_logical_scan(
		ACTION(
			 sqlserver.database_name))
    ADD TARGET package0.event_file(
		SET filename='D:\event_sessions\DBCCCombinedCheck.xel'
		--,metadatafile = 'D:\temp\DBCCCombinedCheck.xem') --2008 only
		)
	WITH (
		EVENT_RETENTION_MODE=ALLOW_SINGLE_EVENT_LOSS,		
		TRACK_CAUSALITY=ON);
GO

/*
	Backup Observation Event (Dynamic Creation: Execute in the session from which you'd like to take the backups)
*/
DECLARE @sql nvarchar(max); 

SET @sql = N'
CREATE EVENT SESSION BackupObservation
ON SERVER
	ADD EVENT sqlserver.sql_statement_starting
	( ACTION (sqlserver.database_id, sqlserver.sql_text)
	WHERE (sqlserver.session_id = !!!SESSIONID!!!)),
	ADD EVENT sqlserver.sql_statement_completed
	( ACTION (sqlserver.database_id, sqlserver.sql_text)
	WHERE (sqlserver.session_id = !!!SESSIONID!!!)),
	ADD EVENT sqlserver.databases_backup_restore_throughput
	( WHERE (sqlserver.session_id = !!!SESSIONID!!!)),
	ADD EVENT sqlos.wait_info
	( ACTION (sqlserver.database_id)
	WHERE (sqlserver.session_id = !!!SESSIONID!!! AND duration > 0)),
	ADD EVENT sqlos.wait_info_external
	( ACTION (sqlserver.database_id)
	WHERE (sqlserver.session_id = !!!SESSIONID!!! AND duration > 0)),
	ADD EVENT sqlserver.trace_print
	( WHERE (sqlserver.session_id = !!!SESSIONID!!!)),
	ADD EVENT sqlserver.file_read
	( WHERE (sqlserver.session_id = !!!SESSIONID!!!)),
	ADD EVENT sqlserver.file_read_completed
	( WHERE (sqlserver.session_id = !!!SESSIONID!!!)),
	ADD EVENT sqlserver.physical_page_read
	( WHERE (sqlserver.session_id = !!!SESSIONID!!!)),
	ADD EVENT sqlserver.databases_log_cache_read
	( WHERE (database_id = !!!DBID!!!)),
	ADD EVENT sqlserver.databases_log_cache_hit
	( WHERE (database_id = !!!DBID!!!)),
	ADD EVENT sqlserver.databases_log_flush
	( WHERE (database_id = !!!DBID!!!)),
	ADD EVENT sqlserver.checkpoint_begin
	( WHERE (database_id = !!!DBID!!!)),
	ADD EVENT sqlserver.checkpoint_end
	( WHERE (database_id = !!!DBID!!!))
	ADD TARGET package0.event_file(
	SET filename=''D:\event_sessions\backup\BackupObservation.xel''
	--,metadatafile = ''D:\event_sessions\backup\BackupObservation.xem'') --2008 only
)
WITH (TRACK_CAUSALITY = ON);
GO';

SET @sql = REPLACE(REPLACE(@sql,'!!!SESSIONID!!!',@@SPID),'!!!DBID!!!',DB_ID('AdventureWorks2012'))

PRINT @sql;