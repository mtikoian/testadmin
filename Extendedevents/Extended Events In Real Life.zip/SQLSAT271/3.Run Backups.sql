/*
	Clear up the history (this will help with future analysis)
*/
use msdb;
go
exec msdb.dbo.sp_delete_backuphistory '2014-01-21'

DBCC TRACEON(3004,3014,3213,-1)
GO
use master;
GO
--DROP EVENT SESSION BackupObservation
--	ON SERVER
--GO
DROP TABLE analysis.dbo.BackupObservation
GO
/*
	Database has been set (though you may need a different database), but don't forget to set your session 
	(unless you want file reads from multiple sessions, which you probably don't).

	PLEASE NOTE THAT THE SESSION IS GOING TO BE FOR THE SESSION RUNNING THE BACKUP!!
*/

DECLARE @sql nvarchar(max); 

SET @sql = N'
CREATE EVENT SESSION BackupObservation
ON SERVER
	ADD EVENT sqlserver.sql_statement_starting
	( ACTION (sqlserver.database_id, sqlserver.sql_text)
	WHERE (sqlserver.session_id = !!!SESSIONID!!!)),
	ADD EVENT sqlserver.sql_statement_completed
	( ACTION (sqlserver.database_id, sqlserver.sql_text)
	WHERE (sqlserver.session_id = !!!SESSIONID!!!)),
	ADD EVENT sqlserver.databases_backup_restore_throughput
	( WHERE (sqlserver.session_id = !!!SESSIONID!!!)),
	ADD EVENT sqlos.wait_info
	( ACTION (sqlserver.database_id)
	WHERE (sqlserver.session_id = !!!SESSIONID!!! AND duration > 0)),
	ADD EVENT sqlos.wait_info_external
	( ACTION (sqlserver.database_id)
	WHERE (sqlserver.session_id = !!!SESSIONID!!! AND duration > 0)),
	ADD EVENT sqlserver.trace_print
	( WHERE (sqlserver.session_id = !!!SESSIONID!!!)),
	ADD EVENT sqlserver.file_read
	( WHERE (sqlserver.session_id = !!!SESSIONID!!!)),
	ADD EVENT sqlserver.file_read_completed
	( WHERE (sqlserver.session_id = !!!SESSIONID!!!)),
	ADD EVENT sqlserver.physical_page_read
	( WHERE (sqlserver.session_id = !!!SESSIONID!!!)),
	ADD EVENT sqlserver.databases_log_cache_read
	( WHERE (database_id = !!!DBID!!!)),
	ADD EVENT sqlserver.databases_log_cache_hit
	( WHERE (database_id = !!!DBID!!!)),
	ADD EVENT sqlserver.databases_log_flush
	( WHERE (database_id = !!!DBID!!!)),
	ADD EVENT sqlserver.checkpoint_begin
	( WHERE (database_id = !!!DBID!!!)),
	ADD EVENT sqlserver.checkpoint_end
	( WHERE (database_id = !!!DBID!!!))
	ADD TARGET package0.event_file(
	SET filename=''D:\event_sessions\backups\BackupObservation.xel''
	--,metadatafile = ''D:\temp\BackupObservation.xem'') --2008 only
)
WITH (TRACK_CAUSALITY = ON);';

SET @sql = REPLACE(REPLACE(@sql,'!!!SESSIONID!!!',@@SPID),'!!!DBID!!!',DB_ID())

PRINT @sql;

EXECUTE sp_executesql @sql;
GO
alter event session BackupObservation on server
	state = start;
GO
BACKUP DATABASE greek
	TO DISK = N'greek.bak';
GO
alter event session BackupObservation on server
	state = stop;
GO

/*
	parse here
*/
select * 
	into #temp_xe
	from (
			SELECT
		CAST(event_data AS XML) AS event_data
		FROM sys.fn_xe_file_target_read_file('D:\event_sessions\backups\BackupObservation*.xel', NULL, NULL, NULL)
	) b

SELECT
1 as stripe_count,
'Minimal' contention_type,
'Full' backup_type,
CAST('Default' as sysname) backup_options,
event_data.value('(event/@name)[1]', 'varchar(50)') AS event_name,
event_data.value('(event/@package)[1]', 'varchar(50)') AS package_name,
event_data.value('(event/@timestamp)[1]', 'datetime2') AS event_timestamp,
COALESCE(event_data.value('(event/data[@name="database_id"]/value)[1]', 'int'),
event_data.value('(event/action[@name="database_id"]/value)[1]', 'int')) AS database_id,
event_data.value('(event/data[@name="message"]/value)[1]', 'nvarchar(4000)') AS trace_print,
event_data.value('(event/data[@name="count"]/value)[1]', 'bigint') AS [count],
event_data.value('(event/data[@name="increment"]/value)[1]', 'bigint') AS [increment],
event_data.value('(event/data[@name="wait_type"]/text)[1]', 'nvarchar(100)') AS wait_type,
event_data.value('(event/data[@name="opcode"]/text)[1]', 'nvarchar(10)') AS opcode,
event_data.value('(event/data[@name="duration"]/value)[1]', 'bigint') AS duration,
event_data.value('(event/data[@name="max_duration"]/value)[1]', 'bigint') AS max_duration,
event_data.value('(event/data[@name="total_duration"]/value)[1]', 'bigint') AS total_duration,
event_data.value('(event/data[@name="signal_duration"]/value)[1]', 'bigint') AS signal_duration,
event_data.value('(event/data[@name="completed_count"]/value)[1]', 'bigint') AS completed_count,
event_data.value('(event/data[@name="source_database_id"]/value)[1]', 'int') AS source_database_id,
event_data.value('(event/data[@name="object_id"]/value)[1]', 'int') AS OBJECT_ID,
event_data.value('(event/data[@name="object_type"]/value)[1]', 'int') AS object_type,
event_data.value('(event/data[@name="state"]/text)[1]', 'nvarchar(50)') AS state,
event_data.value('(event/data[@name="offset"]/value)[1]', 'bigint') AS offset,
event_data.value('(event/data[@name="offset_end"]/value)[1]', 'int') AS offset_end,
event_data.value('(event/data[@name="nest_level"]/value)[1]', 'int') AS nest_level,
event_data.value('(event/data[@name="cpu"]/value)[1]', 'int') AS cpu,
event_data.value('(event/data[@name="reads"]/value)[1]', 'bigint') AS reads,
event_data.value('(event/data[@name="writes"]/value)[1]', 'bigint') AS writes,
event_data.value('(event/data[@name="mode"]/text)[1]', 'nvarchar(50)') AS mmode,
event_data.value('(event/data[@name="file_id"]/value)[1]', 'int') AS FILE_ID,
event_data.value('(event/data[@name="page_id"]/value)[1]', 'int') AS page_id,
event_data.value('(event/data[@name="file_group_id"]/value)[1]', 'int') AS file_group_id,
event_data.value('(event/action[@name="sql_text"]/value)[1]', 'nvarchar(4000)') AS sql_text,
CAST(SUBSTRING(event_data.value('(event/action[@name="attach_activity_id"]/value)[1]', 'varchar(50)'), 1, 36) AS uniqueidentifier) as activity_id,
CAST(SUBSTRING(event_data.value('(event/action[@name="attach_activity_id"]/value)[1]', 'varchar(50)'), 38, 10) AS int) as event_sequence,
CAST(SUBSTRING(event_data.value('(event/action[@name="attach_activity_id_xfer"]/value)[1]', 'varchar(50)'), 1, 36) AS uniqueidentifier) as activity_id_xfer,
event_data
INTO analysis.dbo.BackupObservation
FROM #temp_xe

GO

DECLARE @DeleteDate DATETIME = GETDATE();
EXECUTE master.sys.xp_cmdshell 'del D:\event_sessions\backups\*.xel'
EXECUTE master.sys.xp_delete_file 0,N'C:\Program Files\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\Backup\','BAK',@DeleteDate,0;
GO
ALTER EVENT SESSION BackupObservation ON SERVER
	STATE = START
GO

BACKUP DATABASE greek
	TO	
		DISK = N'AW_1.BAK',
		DISK = N'AW_2.BAK';
GO

ALTER EVENT SESSION BackupObservation ON SERVER
	STATE = STOP;
GO

truncate table #temp_xe;
insert into #temp_xe
select * 	
	from (
			SELECT
		CAST(event_data AS XML) AS event_data
		FROM sys.fn_xe_file_target_read_file('D:\event_sessions\backups\BackupObservation*.xel', NULL, NULL, NULL)
	) b;

INSERT INTO analysis.dbo.BackupObservation
SELECT
2 as stripe_count,
'Minimal' contention_type,
'Full' backup_type,
'Default' backup_options,
event_data.value('(event/@name)[1]', 'varchar(50)') AS event_name,
event_data.value('(event/@package)[1]', 'varchar(50)') AS package_name,
event_data.value('(event/@timestamp)[1]', 'datetime2') AS event_timestamp,
COALESCE(event_data.value('(event/data[@name="database_id"]/value)[1]', 'int'),
event_data.value('(event/action[@name="database_id"]/value)[1]', 'int')) AS database_id,
event_data.value('(event/data[@name="message"]/value)[1]', 'nvarchar(4000)') AS trace_print,
event_data.value('(event/data[@name="count"]/value)[1]', 'bigint') AS [count],
event_data.value('(event/data[@name="increment"]/value)[1]', 'bigint') AS [increment],
event_data.value('(event/data[@name="wait_type"]/text)[1]', 'nvarchar(100)') AS wait_type,
event_data.value('(event/data[@name="opcode"]/text)[1]', 'nvarchar(10)') AS opcode,
event_data.value('(event/data[@name="duration"]/value)[1]', 'bigint') AS duration,
event_data.value('(event/data[@name="max_duration"]/value)[1]', 'bigint') AS max_duration,
event_data.value('(event/data[@name="total_duration"]/value)[1]', 'bigint') AS total_duration,
event_data.value('(event/data[@name="signal_duration"]/value)[1]', 'bigint') AS signal_duration,
event_data.value('(event/data[@name="completed_count"]/value)[1]', 'bigint') AS completed_count,
event_data.value('(event/data[@name="source_database_id"]/value)[1]', 'int') AS source_database_id,
event_data.value('(event/data[@name="object_id"]/value)[1]', 'int') AS OBJECT_ID,
event_data.value('(event/data[@name="object_type"]/value)[1]', 'int') AS object_type,
event_data.value('(event/data[@name="state"]/text)[1]', 'nvarchar(50)') AS state,
event_data.value('(event/data[@name="offset"]/value)[1]', 'bigint') AS offset,
event_data.value('(event/data[@name="offset_end"]/value)[1]', 'int') AS offset_end,
event_data.value('(event/data[@name="nest_level"]/value)[1]', 'int') AS nest_level,
event_data.value('(event/data[@name="cpu"]/value)[1]', 'int') AS cpu,
event_data.value('(event/data[@name="reads"]/value)[1]', 'bigint') AS reads,
event_data.value('(event/data[@name="writes"]/value)[1]', 'bigint') AS writes,
event_data.value('(event/data[@name="mode"]/text)[1]', 'nvarchar(50)') AS mmode,
event_data.value('(event/data[@name="file_id"]/value)[1]', 'int') AS FILE_ID,
event_data.value('(event/data[@name="page_id"]/value)[1]', 'int') AS page_id,
event_data.value('(event/data[@name="file_group_id"]/value)[1]', 'int') AS file_group_id,
event_data.value('(event/action[@name="sql_text"]/value)[1]', 'nvarchar(4000)') AS sql_text,
CAST(SUBSTRING(event_data.value('(event/action[@name="attach_activity_id"]/value)[1]', 'varchar(50)'), 1, 36) AS uniqueidentifier) as activity_id,
CAST(SUBSTRING(event_data.value('(event/action[@name="attach_activity_id"]/value)[1]', 'varchar(50)'), 38, 10) AS int) as event_sequence,
CAST(SUBSTRING(event_data.value('(event/action[@name="attach_activity_id_xfer"]/value)[1]', 'varchar(50)'), 1, 36) AS uniqueidentifier) as activity_id_xfer,
event_data

FROM #temp_xe;
GO

DECLARE @DeleteDate DATETIME = GETDATE();
EXECUTE master.sys.xp_cmdshell 'del D:\event_sessions\backups\*.xel'
EXECUTE master.sys.xp_delete_file 0,N'C:\Program Files\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\Backup\','BAK',@DeleteDate,0;
GO
ALTER EVENT SESSION BackupObservation ON SERVER
	STATE = START
GO

BACKUP DATABASE greek
	TO	
		DISK = N'D:\backups\AW_1.BAK';		
GO

ALTER EVENT SESSION BackupObservation ON SERVER
	STATE = STOP;
GO
truncate table #temp_xe;
insert into #temp_xe
select * 	
	from (
			SELECT
		CAST(event_data AS XML) AS event_data
		FROM sys.fn_xe_file_target_read_file('D:\event_sessions\backups\BackupObservation*.xel', NULL, NULL, NULL)
	) b;
INSERT INTO analysis.dbo.BackupObservation
SELECT
1 as stripe_count,
'Backup' contention_type,
'Full' backup_type,
'Default' backup_options,
event_data.value('(event/@name)[1]', 'varchar(50)') AS event_name,
event_data.value('(event/@package)[1]', 'varchar(50)') AS package_name,
event_data.value('(event/@timestamp)[1]', 'datetime2') AS event_timestamp,
COALESCE(event_data.value('(event/data[@name="database_id"]/value)[1]', 'int'),
event_data.value('(event/action[@name="database_id"]/value)[1]', 'int')) AS database_id,
event_data.value('(event/data[@name="message"]/value)[1]', 'nvarchar(4000)') AS trace_print,
event_data.value('(event/data[@name="count"]/value)[1]', 'bigint') AS [count],
event_data.value('(event/data[@name="increment"]/value)[1]', 'bigint') AS [increment],
event_data.value('(event/data[@name="wait_type"]/text)[1]', 'nvarchar(100)') AS wait_type,
event_data.value('(event/data[@name="opcode"]/text)[1]', 'nvarchar(10)') AS opcode,
event_data.value('(event/data[@name="duration"]/value)[1]', 'bigint') AS duration,
event_data.value('(event/data[@name="max_duration"]/value)[1]', 'bigint') AS max_duration,
event_data.value('(event/data[@name="total_duration"]/value)[1]', 'bigint') AS total_duration,
event_data.value('(event/data[@name="signal_duration"]/value)[1]', 'bigint') AS signal_duration,
event_data.value('(event/data[@name="completed_count"]/value)[1]', 'bigint') AS completed_count,
event_data.value('(event/data[@name="source_database_id"]/value)[1]', 'int') AS source_database_id,
event_data.value('(event/data[@name="object_id"]/value)[1]', 'int') AS OBJECT_ID,
event_data.value('(event/data[@name="object_type"]/value)[1]', 'int') AS object_type,
event_data.value('(event/data[@name="state"]/text)[1]', 'nvarchar(50)') AS state,
event_data.value('(event/data[@name="offset"]/value)[1]', 'bigint') AS offset,
event_data.value('(event/data[@name="offset_end"]/value)[1]', 'int') AS offset_end,
event_data.value('(event/data[@name="nest_level"]/value)[1]', 'int') AS nest_level,
event_data.value('(event/data[@name="cpu"]/value)[1]', 'int') AS cpu,
event_data.value('(event/data[@name="reads"]/value)[1]', 'bigint') AS reads,
event_data.value('(event/data[@name="writes"]/value)[1]', 'bigint') AS writes,
event_data.value('(event/data[@name="mode"]/text)[1]', 'nvarchar(50)') AS mmode,
event_data.value('(event/data[@name="file_id"]/value)[1]', 'int') AS FILE_ID,
event_data.value('(event/data[@name="page_id"]/value)[1]', 'int') AS page_id,
event_data.value('(event/data[@name="file_group_id"]/value)[1]', 'int') AS file_group_id,
event_data.value('(event/action[@name="sql_text"]/value)[1]', 'nvarchar(4000)') AS sql_text,
CAST(SUBSTRING(event_data.value('(event/action[@name="attach_activity_id"]/value)[1]', 'varchar(50)'), 1, 36) AS uniqueidentifier) as activity_id,
CAST(SUBSTRING(event_data.value('(event/action[@name="attach_activity_id"]/value)[1]', 'varchar(50)'), 38, 10) AS int) as event_sequence,
CAST(SUBSTRING(event_data.value('(event/action[@name="attach_activity_id_xfer"]/value)[1]', 'varchar(50)'), 1, 36) AS uniqueidentifier) as activity_id_xfer,
event_data

FROM #temp_xe;
GO


DECLARE @DeleteDate DATETIME = GETDATE();
EXECUTE master.sys.xp_cmdshell 'del D:\event_sessions\backups\*.xel'
EXECUTE master.sys.xp_delete_file 0,N'd:\backups\','BAK',@DeleteDate,0;
GO
ALTER EVENT SESSION BackupObservation ON SERVER
	STATE = START
GO

BACKUP DATABASE greek
	TO	
		DISK = N'D:\backups\AW_1.BAK',
		DISK = N'D:\backups\AW_2.BAK';		
GO

ALTER EVENT SESSION BackupObservation ON SERVER
	STATE = STOP;
GO

truncate table #temp_xe;
insert into #temp_xe
select * 	
	from (
			SELECT
		CAST(event_data AS XML) AS event_data
		FROM sys.fn_xe_file_target_read_file('D:\event_sessions\backups\BackupObservation*.xel', NULL, NULL, NULL)
	) b;

INSERT INTO analysis.dbo.BackupObservation
SELECT
2 as stripe_count,
'Backup' contention_type,
'Full' backup_type,
'Default' backup_options,
event_data.value('(event/@name)[1]', 'varchar(50)') AS event_name,
event_data.value('(event/@package)[1]', 'varchar(50)') AS package_name,
event_data.value('(event/@timestamp)[1]', 'datetime2') AS event_timestamp,
COALESCE(event_data.value('(event/data[@name="database_id"]/value)[1]', 'int'),
event_data.value('(event/action[@name="database_id"]/value)[1]', 'int')) AS database_id,
event_data.value('(event/data[@name="message"]/value)[1]', 'nvarchar(4000)') AS trace_print,
event_data.value('(event/data[@name="count"]/value)[1]', 'bigint') AS [count],
event_data.value('(event/data[@name="increment"]/value)[1]', 'bigint') AS [increment],
event_data.value('(event/data[@name="wait_type"]/text)[1]', 'nvarchar(100)') AS wait_type,
event_data.value('(event/data[@name="opcode"]/text)[1]', 'nvarchar(10)') AS opcode,
event_data.value('(event/data[@name="duration"]/value)[1]', 'bigint') AS duration,
event_data.value('(event/data[@name="max_duration"]/value)[1]', 'bigint') AS max_duration,
event_data.value('(event/data[@name="total_duration"]/value)[1]', 'bigint') AS total_duration,
event_data.value('(event/data[@name="signal_duration"]/value)[1]', 'bigint') AS signal_duration,
event_data.value('(event/data[@name="completed_count"]/value)[1]', 'bigint') AS completed_count,
event_data.value('(event/data[@name="source_database_id"]/value)[1]', 'int') AS source_database_id,
event_data.value('(event/data[@name="object_id"]/value)[1]', 'int') AS OBJECT_ID,
event_data.value('(event/data[@name="object_type"]/value)[1]', 'int') AS object_type,
event_data.value('(event/data[@name="state"]/text)[1]', 'nvarchar(50)') AS state,
event_data.value('(event/data[@name="offset"]/value)[1]', 'bigint') AS offset,
event_data.value('(event/data[@name="offset_end"]/value)[1]', 'int') AS offset_end,
event_data.value('(event/data[@name="nest_level"]/value)[1]', 'int') AS nest_level,
event_data.value('(event/data[@name="cpu"]/value)[1]', 'int') AS cpu,
event_data.value('(event/data[@name="reads"]/value)[1]', 'bigint') AS reads,
event_data.value('(event/data[@name="writes"]/value)[1]', 'bigint') AS writes,
event_data.value('(event/data[@name="mode"]/text)[1]', 'nvarchar(50)') AS mmode,
event_data.value('(event/data[@name="file_id"]/value)[1]', 'int') AS FILE_ID,
event_data.value('(event/data[@name="page_id"]/value)[1]', 'int') AS page_id,
event_data.value('(event/data[@name="file_group_id"]/value)[1]', 'int') AS file_group_id,
event_data.value('(event/action[@name="sql_text"]/value)[1]', 'nvarchar(4000)') AS sql_text,
CAST(SUBSTRING(event_data.value('(event/action[@name="attach_activity_id"]/value)[1]', 'varchar(50)'), 1, 36) AS uniqueidentifier) as activity_id,
CAST(SUBSTRING(event_data.value('(event/action[@name="attach_activity_id"]/value)[1]', 'varchar(50)'), 38, 10) AS int) as event_sequence,
CAST(SUBSTRING(event_data.value('(event/action[@name="attach_activity_id_xfer"]/value)[1]', 'varchar(50)'), 1, 36) AS uniqueidentifier) as activity_id_xfer,
event_data

FROM #temp_xe;
GO


DECLARE @DeleteDate DATETIME = GETDATE();
EXECUTE master.sys.xp_cmdshell 'del D:\event_sessions\backups\*.xel'
EXECUTE master.sys.xp_delete_file 0,N'd:\backups\','BAK',@DeleteDate,0;
GO

ALTER EVENT SESSION BackupObservation ON SERVER
	STATE = START
GO

BACKUP DATABASE greek
	TO	
		DISK = N'AW_1.BAK',
		DISK = N'D:\backups\AW_2.BAK';		
GO

ALTER EVENT SESSION BackupObservation ON SERVER
	STATE = STOP;
GO
truncate table #temp_xe;
insert into #temp_xe
select * 	
	from (
			SELECT
		CAST(event_data AS XML) AS event_data
		FROM sys.fn_xe_file_target_read_file('D:\event_sessions\backups\BackupObservation*.xel', NULL, NULL, NULL)
	) b;

INSERT INTO analysis.dbo.BackupObservation
SELECT
2 as stripe_count,
'Split' contention_type,
'Full' backup_type,
'Default' backup_options,
event_data.value('(event/@name)[1]', 'varchar(50)') AS event_name,
event_data.value('(event/@package)[1]', 'varchar(50)') AS package_name,
event_data.value('(event/@timestamp)[1]', 'datetime2') AS event_timestamp,
COALESCE(event_data.value('(event/data[@name="database_id"]/value)[1]', 'int'),
event_data.value('(event/action[@name="database_id"]/value)[1]', 'int')) AS database_id,
event_data.value('(event/data[@name="message"]/value)[1]', 'nvarchar(4000)') AS trace_print,
event_data.value('(event/data[@name="count"]/value)[1]', 'bigint') AS [count],
event_data.value('(event/data[@name="increment"]/value)[1]', 'bigint') AS [increment],
event_data.value('(event/data[@name="wait_type"]/text)[1]', 'nvarchar(100)') AS wait_type,
event_data.value('(event/data[@name="opcode"]/text)[1]', 'nvarchar(10)') AS opcode,
event_data.value('(event/data[@name="duration"]/value)[1]', 'bigint') AS duration,
event_data.value('(event/data[@name="max_duration"]/value)[1]', 'bigint') AS max_duration,
event_data.value('(event/data[@name="total_duration"]/value)[1]', 'bigint') AS total_duration,
event_data.value('(event/data[@name="signal_duration"]/value)[1]', 'bigint') AS signal_duration,
event_data.value('(event/data[@name="completed_count"]/value)[1]', 'bigint') AS completed_count,
event_data.value('(event/data[@name="source_database_id"]/value)[1]', 'int') AS source_database_id,
event_data.value('(event/data[@name="object_id"]/value)[1]', 'int') AS OBJECT_ID,
event_data.value('(event/data[@name="object_type"]/value)[1]', 'int') AS object_type,
event_data.value('(event/data[@name="state"]/text)[1]', 'nvarchar(50)') AS state,
event_data.value('(event/data[@name="offset"]/value)[1]', 'bigint') AS offset,
event_data.value('(event/data[@name="offset_end"]/value)[1]', 'int') AS offset_end,
event_data.value('(event/data[@name="nest_level"]/value)[1]', 'int') AS nest_level,
event_data.value('(event/data[@name="cpu"]/value)[1]', 'int') AS cpu,
event_data.value('(event/data[@name="reads"]/value)[1]', 'bigint') AS reads,
event_data.value('(event/data[@name="writes"]/value)[1]', 'bigint') AS writes,
event_data.value('(event/data[@name="mode"]/text)[1]', 'nvarchar(50)') AS mmode,
event_data.value('(event/data[@name="file_id"]/value)[1]', 'int') AS FILE_ID,
event_data.value('(event/data[@name="page_id"]/value)[1]', 'int') AS page_id,
event_data.value('(event/data[@name="file_group_id"]/value)[1]', 'int') AS file_group_id,
event_data.value('(event/action[@name="sql_text"]/value)[1]', 'nvarchar(4000)') AS sql_text,
CAST(SUBSTRING(event_data.value('(event/action[@name="attach_activity_id"]/value)[1]', 'varchar(50)'), 1, 36) AS uniqueidentifier) as activity_id,
CAST(SUBSTRING(event_data.value('(event/action[@name="attach_activity_id"]/value)[1]', 'varchar(50)'), 38, 10) AS int) as event_sequence,
CAST(SUBSTRING(event_data.value('(event/action[@name="attach_activity_id_xfer"]/value)[1]', 'varchar(50)'), 1, 36) AS uniqueidentifier) as activity_id_xfer,
event_data

FROM #temp_xe;
GO

DECLARE @DeleteDate DATETIME = GETDATE();
EXECUTE master.sys.xp_cmdshell 'del D:\event_sessions\backups\*.xel';
EXECUTE master.sys.xp_delete_file 0,N'd:\backups\','BAK',@DeleteDate,0;
EXECUTE master.sys.xp_delete_file 0,N'C:\Program Files\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\Backup\','BAK',@DeleteDate,0;
GO


ALTER EVENT SESSION BackupObservation ON SERVER
	STATE = START
GO

BACKUP DATABASE greek
	TO	
		DISK = N'AW_1.BAK'
	WITH DIFFERENTIAL
GO

ALTER EVENT SESSION BackupObservation ON SERVER
	STATE = STOP;
GO
truncate table #temp_xe;
insert into #temp_xe
select * 	
	from (
			SELECT
		CAST(event_data AS XML) AS event_data
		FROM sys.fn_xe_file_target_read_file('D:\event_sessions\backups\BackupObservation*.xel', NULL, NULL, NULL)
	) b;
INSERT INTO analysis.dbo.BackupObservation
SELECT
1 as stripe_count,
'Minimal' contention_type,
'Diff' backup_type,
'Default' backup_options,
event_data.value('(event/@name)[1]', 'varchar(50)') AS event_name,
event_data.value('(event/@package)[1]', 'varchar(50)') AS package_name,
event_data.value('(event/@timestamp)[1]', 'datetime2') AS event_timestamp,
COALESCE(event_data.value('(event/data[@name="database_id"]/value)[1]', 'int'),
event_data.value('(event/action[@name="database_id"]/value)[1]', 'int')) AS database_id,
event_data.value('(event/data[@name="message"]/value)[1]', 'nvarchar(4000)') AS trace_print,
event_data.value('(event/data[@name="count"]/value)[1]', 'bigint') AS [count],
event_data.value('(event/data[@name="increment"]/value)[1]', 'bigint') AS [increment],
event_data.value('(event/data[@name="wait_type"]/text)[1]', 'nvarchar(100)') AS wait_type,
event_data.value('(event/data[@name="opcode"]/text)[1]', 'nvarchar(10)') AS opcode,
event_data.value('(event/data[@name="duration"]/value)[1]', 'bigint') AS duration,
event_data.value('(event/data[@name="max_duration"]/value)[1]', 'bigint') AS max_duration,
event_data.value('(event/data[@name="total_duration"]/value)[1]', 'bigint') AS total_duration,
event_data.value('(event/data[@name="signal_duration"]/value)[1]', 'bigint') AS signal_duration,
event_data.value('(event/data[@name="completed_count"]/value)[1]', 'bigint') AS completed_count,
event_data.value('(event/data[@name="source_database_id"]/value)[1]', 'int') AS source_database_id,
event_data.value('(event/data[@name="object_id"]/value)[1]', 'int') AS OBJECT_ID,
event_data.value('(event/data[@name="object_type"]/value)[1]', 'int') AS object_type,
event_data.value('(event/data[@name="state"]/text)[1]', 'nvarchar(50)') AS state,
event_data.value('(event/data[@name="offset"]/value)[1]', 'bigint') AS offset,
event_data.value('(event/data[@name="offset_end"]/value)[1]', 'int') AS offset_end,
event_data.value('(event/data[@name="nest_level"]/value)[1]', 'int') AS nest_level,
event_data.value('(event/data[@name="cpu"]/value)[1]', 'int') AS cpu,
event_data.value('(event/data[@name="reads"]/value)[1]', 'bigint') AS reads,
event_data.value('(event/data[@name="writes"]/value)[1]', 'bigint') AS writes,
event_data.value('(event/data[@name="mode"]/text)[1]', 'nvarchar(50)') AS mmode,
event_data.value('(event/data[@name="file_id"]/value)[1]', 'int') AS FILE_ID,
event_data.value('(event/data[@name="page_id"]/value)[1]', 'int') AS page_id,
event_data.value('(event/data[@name="file_group_id"]/value)[1]', 'int') AS file_group_id,
event_data.value('(event/action[@name="sql_text"]/value)[1]', 'nvarchar(4000)') AS sql_text,
CAST(SUBSTRING(event_data.value('(event/action[@name="attach_activity_id"]/value)[1]', 'varchar(50)'), 1, 36) AS uniqueidentifier) as activity_id,
CAST(SUBSTRING(event_data.value('(event/action[@name="attach_activity_id"]/value)[1]', 'varchar(50)'), 38, 10) AS int) as event_sequence,
CAST(SUBSTRING(event_data.value('(event/action[@name="attach_activity_id_xfer"]/value)[1]', 'varchar(50)'), 1, 36) AS uniqueidentifier) as activity_id_xfer,
event_data

FROM #temp_xe;
GO

DECLARE @DeleteDate DATETIME = GETDATE();
EXECUTE master.sys.xp_cmdshell 'del D:\event_sessions\backups\*.xel';
EXECUTE master.sys.xp_delete_file 0,N'd:\backups\','BAK',@DeleteDate,0;
EXECUTE master.sys.xp_delete_file 0,N'C:\Program Files\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\Backup\','BAK',@DeleteDate,0;
GO


ALTER EVENT SESSION BackupObservation ON SERVER
	STATE = START
GO

BACKUP DATABASE greek
	TO	
		DISK = N'AW_1.BAK', 
		DISK = N'AW_2.BAK'
	WITH DIFFERENTIAL
GO

ALTER EVENT SESSION BackupObservation ON SERVER
	STATE = STOP;
GO
truncate table #temp_xe;
insert into #temp_xe
select * 	
	from (
			SELECT
		CAST(event_data AS XML) AS event_data
		FROM sys.fn_xe_file_target_read_file('D:\event_sessions\backups\BackupObservation*.xel', NULL, NULL, NULL)
	) b;


INSERT INTO analysis.dbo.BackupObservation
SELECT
2 as stripe_count,
'Minimal' contention_type,
'Diff' backup_type,
'Default' backup_options,
event_data.value('(event/@name)[1]', 'varchar(50)') AS event_name,
event_data.value('(event/@package)[1]', 'varchar(50)') AS package_name,
event_data.value('(event/@timestamp)[1]', 'datetime2') AS event_timestamp,
COALESCE(event_data.value('(event/data[@name="database_id"]/value)[1]', 'int'),
event_data.value('(event/action[@name="database_id"]/value)[1]', 'int')) AS database_id,
event_data.value('(event/data[@name="message"]/value)[1]', 'nvarchar(4000)') AS trace_print,
event_data.value('(event/data[@name="count"]/value)[1]', 'bigint') AS [count],
event_data.value('(event/data[@name="increment"]/value)[1]', 'bigint') AS [increment],
event_data.value('(event/data[@name="wait_type"]/text)[1]', 'nvarchar(100)') AS wait_type,
event_data.value('(event/data[@name="opcode"]/text)[1]', 'nvarchar(10)') AS opcode,
event_data.value('(event/data[@name="duration"]/value)[1]', 'bigint') AS duration,
event_data.value('(event/data[@name="max_duration"]/value)[1]', 'bigint') AS max_duration,
event_data.value('(event/data[@name="total_duration"]/value)[1]', 'bigint') AS total_duration,
event_data.value('(event/data[@name="signal_duration"]/value)[1]', 'bigint') AS signal_duration,
event_data.value('(event/data[@name="completed_count"]/value)[1]', 'bigint') AS completed_count,
event_data.value('(event/data[@name="source_database_id"]/value)[1]', 'int') AS source_database_id,
event_data.value('(event/data[@name="object_id"]/value)[1]', 'int') AS OBJECT_ID,
event_data.value('(event/data[@name="object_type"]/value)[1]', 'int') AS object_type,
event_data.value('(event/data[@name="state"]/text)[1]', 'nvarchar(50)') AS state,
event_data.value('(event/data[@name="offset"]/value)[1]', 'bigint') AS offset,
event_data.value('(event/data[@name="offset_end"]/value)[1]', 'int') AS offset_end,
event_data.value('(event/data[@name="nest_level"]/value)[1]', 'int') AS nest_level,
event_data.value('(event/data[@name="cpu"]/value)[1]', 'int') AS cpu,
event_data.value('(event/data[@name="reads"]/value)[1]', 'bigint') AS reads,
event_data.value('(event/data[@name="writes"]/value)[1]', 'bigint') AS writes,
event_data.value('(event/data[@name="mode"]/text)[1]', 'nvarchar(50)') AS mmode,
event_data.value('(event/data[@name="file_id"]/value)[1]', 'int') AS FILE_ID,
event_data.value('(event/data[@name="page_id"]/value)[1]', 'int') AS page_id,
event_data.value('(event/data[@name="file_group_id"]/value)[1]', 'int') AS file_group_id,
event_data.value('(event/action[@name="sql_text"]/value)[1]', 'nvarchar(4000)') AS sql_text,
CAST(SUBSTRING(event_data.value('(event/action[@name="attach_activity_id"]/value)[1]', 'varchar(50)'), 1, 36) AS uniqueidentifier) as activity_id,
CAST(SUBSTRING(event_data.value('(event/action[@name="attach_activity_id"]/value)[1]', 'varchar(50)'), 38, 10) AS int) as event_sequence,
CAST(SUBSTRING(event_data.value('(event/action[@name="attach_activity_id_xfer"]/value)[1]', 'varchar(50)'), 1, 36) AS uniqueidentifier) as activity_id_xfer,
event_data

FROM #temp_xe;
GO

DECLARE @DeleteDate DATETIME = GETDATE();
EXECUTE master.sys.xp_cmdshell 'del D:\event_sessions\backups\*.xel';
EXECUTE master.sys.xp_delete_file 0,N'd:\backups\','BAK',@DeleteDate,0;
EXECUTE master.sys.xp_delete_file 0,N'C:\Program Files\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\Backup\','BAK',@DeleteDate,0;
GO

ALTER EVENT SESSION BackupObservation ON SERVER
	STATE = START
GO

BACKUP DATABASE greek
	TO	
		DISK = N'D:\backups\AW_1.BAK'
		
	WITH DIFFERENTIAL
GO

ALTER EVENT SESSION BackupObservation ON SERVER
	STATE = STOP;
GO

truncate table #temp_xe;
insert into #temp_xe
select * 	
	from (
			SELECT
		CAST(event_data AS XML) AS event_data
		FROM sys.fn_xe_file_target_read_file('D:\event_sessions\backups\BackupObservation*.xel', NULL, NULL, NULL)
	) b;

INSERT INTO analysis.dbo.BackupObservation
SELECT
1 as stripe_count,
'Backup' contention_type,
'Diff' backup_type,
'Default' backup_options,
event_data.value('(event/@name)[1]', 'varchar(50)') AS event_name,
event_data.value('(event/@package)[1]', 'varchar(50)') AS package_name,
event_data.value('(event/@timestamp)[1]', 'datetime2') AS event_timestamp,
COALESCE(event_data.value('(event/data[@name="database_id"]/value)[1]', 'int'),
event_data.value('(event/action[@name="database_id"]/value)[1]', 'int')) AS database_id,
event_data.value('(event/data[@name="message"]/value)[1]', 'nvarchar(4000)') AS trace_print,
event_data.value('(event/data[@name="count"]/value)[1]', 'bigint') AS [count],
event_data.value('(event/data[@name="increment"]/value)[1]', 'bigint') AS [increment],
event_data.value('(event/data[@name="wait_type"]/text)[1]', 'nvarchar(100)') AS wait_type,
event_data.value('(event/data[@name="opcode"]/text)[1]', 'nvarchar(10)') AS opcode,
event_data.value('(event/data[@name="duration"]/value)[1]', 'bigint') AS duration,
event_data.value('(event/data[@name="max_duration"]/value)[1]', 'bigint') AS max_duration,
event_data.value('(event/data[@name="total_duration"]/value)[1]', 'bigint') AS total_duration,
event_data.value('(event/data[@name="signal_duration"]/value)[1]', 'bigint') AS signal_duration,
event_data.value('(event/data[@name="completed_count"]/value)[1]', 'bigint') AS completed_count,
event_data.value('(event/data[@name="source_database_id"]/value)[1]', 'int') AS source_database_id,
event_data.value('(event/data[@name="object_id"]/value)[1]', 'int') AS OBJECT_ID,
event_data.value('(event/data[@name="object_type"]/value)[1]', 'int') AS object_type,
event_data.value('(event/data[@name="state"]/text)[1]', 'nvarchar(50)') AS state,
event_data.value('(event/data[@name="offset"]/value)[1]', 'bigint') AS offset,
event_data.value('(event/data[@name="offset_end"]/value)[1]', 'int') AS offset_end,
event_data.value('(event/data[@name="nest_level"]/value)[1]', 'int') AS nest_level,
event_data.value('(event/data[@name="cpu"]/value)[1]', 'int') AS cpu,
event_data.value('(event/data[@name="reads"]/value)[1]', 'bigint') AS reads,
event_data.value('(event/data[@name="writes"]/value)[1]', 'bigint') AS writes,
event_data.value('(event/data[@name="mode"]/text)[1]', 'nvarchar(50)') AS mmode,
event_data.value('(event/data[@name="file_id"]/value)[1]', 'int') AS FILE_ID,
event_data.value('(event/data[@name="page_id"]/value)[1]', 'int') AS page_id,
event_data.value('(event/data[@name="file_group_id"]/value)[1]', 'int') AS file_group_id,
event_data.value('(event/action[@name="sql_text"]/value)[1]', 'nvarchar(4000)') AS sql_text,
CAST(SUBSTRING(event_data.value('(event/action[@name="attach_activity_id"]/value)[1]', 'varchar(50)'), 1, 36) AS uniqueidentifier) as activity_id,
CAST(SUBSTRING(event_data.value('(event/action[@name="attach_activity_id"]/value)[1]', 'varchar(50)'), 38, 10) AS int) as event_sequence,
CAST(SUBSTRING(event_data.value('(event/action[@name="attach_activity_id_xfer"]/value)[1]', 'varchar(50)'), 1, 36) AS uniqueidentifier) as activity_id_xfer,
event_data

FROM #temp_xe;
GO

DECLARE @DeleteDate DATETIME = GETDATE();
EXECUTE master.sys.xp_cmdshell 'del D:\event_sessions\backups\*.xel';
EXECUTE master.sys.xp_delete_file 0,N'd:\backups\','BAK',@DeleteDate,0;
EXECUTE master.sys.xp_delete_file 0,N'C:\Program Files\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\Backup\','BAK',@DeleteDate,0;
GO


ALTER EVENT SESSION BackupObservation ON SERVER
	STATE = START
GO

BACKUP DATABASE greek
	TO	
		DISK = N'D:\backups\AW_1.BAK', 
		DISK = N'D:\backups\AW_2.BAK'		
	WITH DIFFERENTIAL
GO

ALTER EVENT SESSION BackupObservation ON SERVER
	STATE = STOP;
GO
truncate table #temp_xe;
insert into #temp_xe
select * 	
	from (
			SELECT
		CAST(event_data AS XML) AS event_data
		FROM sys.fn_xe_file_target_read_file('D:\event_sessions\backups\BackupObservation*.xel', NULL, NULL, NULL)
	) b;
GO
INSERT INTO analysis.dbo.BackupObservation
SELECT
2 as stripe_count,
'Backup' contention_type,
'Diff' backup_type,
'Default' backup_options,
event_data.value('(event/@name)[1]', 'varchar(50)') AS event_name,
event_data.value('(event/@package)[1]', 'varchar(50)') AS package_name,
event_data.value('(event/@timestamp)[1]', 'datetime2') AS event_timestamp,
COALESCE(event_data.value('(event/data[@name="database_id"]/value)[1]', 'int'),
event_data.value('(event/action[@name="database_id"]/value)[1]', 'int')) AS database_id,
event_data.value('(event/data[@name="message"]/value)[1]', 'nvarchar(4000)') AS trace_print,
event_data.value('(event/data[@name="count"]/value)[1]', 'bigint') AS [count],
event_data.value('(event/data[@name="increment"]/value)[1]', 'bigint') AS [increment],
event_data.value('(event/data[@name="wait_type"]/text)[1]', 'nvarchar(100)') AS wait_type,
event_data.value('(event/data[@name="opcode"]/text)[1]', 'nvarchar(10)') AS opcode,
event_data.value('(event/data[@name="duration"]/value)[1]', 'bigint') AS duration,
event_data.value('(event/data[@name="max_duration"]/value)[1]', 'bigint') AS max_duration,
event_data.value('(event/data[@name="total_duration"]/value)[1]', 'bigint') AS total_duration,
event_data.value('(event/data[@name="signal_duration"]/value)[1]', 'bigint') AS signal_duration,
event_data.value('(event/data[@name="completed_count"]/value)[1]', 'bigint') AS completed_count,
event_data.value('(event/data[@name="source_database_id"]/value)[1]', 'int') AS source_database_id,
event_data.value('(event/data[@name="object_id"]/value)[1]', 'int') AS OBJECT_ID,
event_data.value('(event/data[@name="object_type"]/value)[1]', 'int') AS object_type,
event_data.value('(event/data[@name="state"]/text)[1]', 'nvarchar(50)') AS state,
event_data.value('(event/data[@name="offset"]/value)[1]', 'bigint') AS offset,
event_data.value('(event/data[@name="offset_end"]/value)[1]', 'int') AS offset_end,
event_data.value('(event/data[@name="nest_level"]/value)[1]', 'int') AS nest_level,
event_data.value('(event/data[@name="cpu"]/value)[1]', 'int') AS cpu,
event_data.value('(event/data[@name="reads"]/value)[1]', 'bigint') AS reads,
event_data.value('(event/data[@name="writes"]/value)[1]', 'bigint') AS writes,
event_data.value('(event/data[@name="mode"]/text)[1]', 'nvarchar(50)') AS mmode,
event_data.value('(event/data[@name="file_id"]/value)[1]', 'int') AS FILE_ID,
event_data.value('(event/data[@name="page_id"]/value)[1]', 'int') AS page_id,
event_data.value('(event/data[@name="file_group_id"]/value)[1]', 'int') AS file_group_id,
event_data.value('(event/action[@name="sql_text"]/value)[1]', 'nvarchar(4000)') AS sql_text,
CAST(SUBSTRING(event_data.value('(event/action[@name="attach_activity_id"]/value)[1]', 'varchar(50)'), 1, 36) AS uniqueidentifier) as activity_id,
CAST(SUBSTRING(event_data.value('(event/action[@name="attach_activity_id"]/value)[1]', 'varchar(50)'), 38, 10) AS int) as event_sequence,
CAST(SUBSTRING(event_data.value('(event/action[@name="attach_activity_id_xfer"]/value)[1]', 'varchar(50)'), 1, 36) AS uniqueidentifier) as activity_id_xfer,
event_data

FROM #temp_xe;
GO

DECLARE @DeleteDate DATETIME = GETDATE();
EXECUTE master.sys.xp_cmdshell 'del D:\event_sessions\backups\*.xel';
EXECUTE master.sys.xp_delete_file 0,N'd:\backups\','BAK',@DeleteDate,0;
EXECUTE master.sys.xp_delete_file 0,N'C:\Program Files\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\Backup\','BAK',@DeleteDate,0;
GO


ALTER EVENT SESSION BackupObservation ON SERVER
	STATE = START
GO

BACKUP DATABASE greek
	TO	
		DISK = N'AW_1.BAK', 
		DISK = N'D:\backups\AW_2.BAK'		
	WITH DIFFERENTIAL
GO

ALTER EVENT SESSION BackupObservation ON SERVER
	STATE = STOP;
GO
truncate table #temp_xe;
insert into #temp_xe
select * 	
	from (
			SELECT
		CAST(event_data AS XML) AS event_data
		FROM sys.fn_xe_file_target_read_file('D:\event_sessions\backups\BackupObservation*.xel', NULL, NULL, NULL)
	) b;
GO
INSERT INTO analysis.dbo.BackupObservation
SELECT
2 as stripe_count,
'Split' contention_type,
'Diff' backup_type,
'Default' backup_options,
event_data.value('(event/@name)[1]', 'varchar(50)') AS event_name,
event_data.value('(event/@package)[1]', 'varchar(50)') AS package_name,
event_data.value('(event/@timestamp)[1]', 'datetime2') AS event_timestamp,
COALESCE(event_data.value('(event/data[@name="database_id"]/value)[1]', 'int'),
event_data.value('(event/action[@name="database_id"]/value)[1]', 'int')) AS database_id,
event_data.value('(event/data[@name="message"]/value)[1]', 'nvarchar(4000)') AS trace_print,
event_data.value('(event/data[@name="count"]/value)[1]', 'bigint') AS [count],
event_data.value('(event/data[@name="increment"]/value)[1]', 'bigint') AS [increment],
event_data.value('(event/data[@name="wait_type"]/text)[1]', 'nvarchar(100)') AS wait_type,
event_data.value('(event/data[@name="opcode"]/text)[1]', 'nvarchar(10)') AS opcode,
event_data.value('(event/data[@name="duration"]/value)[1]', 'bigint') AS duration,
event_data.value('(event/data[@name="max_duration"]/value)[1]', 'bigint') AS max_duration,
event_data.value('(event/data[@name="total_duration"]/value)[1]', 'bigint') AS total_duration,
event_data.value('(event/data[@name="signal_duration"]/value)[1]', 'bigint') AS signal_duration,
event_data.value('(event/data[@name="completed_count"]/value)[1]', 'bigint') AS completed_count,
event_data.value('(event/data[@name="source_database_id"]/value)[1]', 'int') AS source_database_id,
event_data.value('(event/data[@name="object_id"]/value)[1]', 'int') AS OBJECT_ID,
event_data.value('(event/data[@name="object_type"]/value)[1]', 'int') AS object_type,
event_data.value('(event/data[@name="state"]/text)[1]', 'nvarchar(50)') AS state,
event_data.value('(event/data[@name="offset"]/value)[1]', 'bigint') AS offset,
event_data.value('(event/data[@name="offset_end"]/value)[1]', 'int') AS offset_end,
event_data.value('(event/data[@name="nest_level"]/value)[1]', 'int') AS nest_level,
event_data.value('(event/data[@name="cpu"]/value)[1]', 'int') AS cpu,
event_data.value('(event/data[@name="reads"]/value)[1]', 'bigint') AS reads,
event_data.value('(event/data[@name="writes"]/value)[1]', 'bigint') AS writes,
event_data.value('(event/data[@name="mode"]/text)[1]', 'nvarchar(50)') AS mmode,
event_data.value('(event/data[@name="file_id"]/value)[1]', 'int') AS FILE_ID,
event_data.value('(event/data[@name="page_id"]/value)[1]', 'int') AS page_id,
event_data.value('(event/data[@name="file_group_id"]/value)[1]', 'int') AS file_group_id,
event_data.value('(event/action[@name="sql_text"]/value)[1]', 'nvarchar(4000)') AS sql_text,
CAST(SUBSTRING(event_data.value('(event/action[@name="attach_activity_id"]/value)[1]', 'varchar(50)'), 1, 36) AS uniqueidentifier) as activity_id,
CAST(SUBSTRING(event_data.value('(event/action[@name="attach_activity_id"]/value)[1]', 'varchar(50)'), 38, 10) AS int) as event_sequence,
CAST(SUBSTRING(event_data.value('(event/action[@name="attach_activity_id_xfer"]/value)[1]', 'varchar(50)'), 1, 36) AS uniqueidentifier) as activity_id_xfer,
event_data

FROM #temp_xe;
GO

DECLARE @DeleteDate DATETIME = GETDATE();
EXECUTE master.sys.xp_cmdshell 'del D:\event_sessions\backups\*.xel';
EXECUTE master.sys.xp_delete_file 0,N'd:\backups\','BAK',@DeleteDate,0;
EXECUTE master.sys.xp_delete_file 0,N'C:\Program Files\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\Backup\','BAK',@DeleteDate,0;
GO

/*
	MaxTransferSize Tweaks
*/
ALTER EVENT SESSION BackupObservation ON SERVER
	STATE = START
GO

BACKUP DATABASE greek
	TO	
		DISK = N'AW_1.BAK'		
	WITH MAXTRANSFERSIZE=2097152
GO

ALTER EVENT SESSION BackupObservation ON SERVER
	STATE = STOP;
GO

truncate table #temp_xe;
insert into #temp_xe
select * 	
	from (
			SELECT
		CAST(event_data AS XML) AS event_data
		FROM sys.fn_xe_file_target_read_file('D:\event_sessions\backups\BackupObservation*.xel', NULL, NULL, NULL)
	) b;

INSERT INTO analysis.dbo.BackupObservation
SELECT
1 as stripe_count,
'Minimal' contention_type,
'Full' backup_type,
'MaxTransferSizex2' backup_options,
event_data.value('(event/@name)[1]', 'varchar(50)') AS event_name,
event_data.value('(event/@package)[1]', 'varchar(50)') AS package_name,
event_data.value('(event/@timestamp)[1]', 'datetime2') AS event_timestamp,
COALESCE(event_data.value('(event/data[@name="database_id"]/value)[1]', 'int'),
event_data.value('(event/action[@name="database_id"]/value)[1]', 'int')) AS database_id,
event_data.value('(event/data[@name="message"]/value)[1]', 'nvarchar(4000)') AS trace_print,
event_data.value('(event/data[@name="count"]/value)[1]', 'bigint') AS [count],
event_data.value('(event/data[@name="increment"]/value)[1]', 'bigint') AS [increment],
event_data.value('(event/data[@name="wait_type"]/text)[1]', 'nvarchar(100)') AS wait_type,
event_data.value('(event/data[@name="opcode"]/text)[1]', 'nvarchar(10)') AS opcode,
event_data.value('(event/data[@name="duration"]/value)[1]', 'bigint') AS duration,
event_data.value('(event/data[@name="max_duration"]/value)[1]', 'bigint') AS max_duration,
event_data.value('(event/data[@name="total_duration"]/value)[1]', 'bigint') AS total_duration,
event_data.value('(event/data[@name="signal_duration"]/value)[1]', 'bigint') AS signal_duration,
event_data.value('(event/data[@name="completed_count"]/value)[1]', 'bigint') AS completed_count,
event_data.value('(event/data[@name="source_database_id"]/value)[1]', 'int') AS source_database_id,
event_data.value('(event/data[@name="object_id"]/value)[1]', 'int') AS OBJECT_ID,
event_data.value('(event/data[@name="object_type"]/value)[1]', 'int') AS object_type,
event_data.value('(event/data[@name="state"]/text)[1]', 'nvarchar(50)') AS state,
event_data.value('(event/data[@name="offset"]/value)[1]', 'bigint') AS offset,
event_data.value('(event/data[@name="offset_end"]/value)[1]', 'int') AS offset_end,
event_data.value('(event/data[@name="nest_level"]/value)[1]', 'int') AS nest_level,
event_data.value('(event/data[@name="cpu"]/value)[1]', 'int') AS cpu,
event_data.value('(event/data[@name="reads"]/value)[1]', 'bigint') AS reads,
event_data.value('(event/data[@name="writes"]/value)[1]', 'bigint') AS writes,
event_data.value('(event/data[@name="mode"]/text)[1]', 'nvarchar(50)') AS mmode,
event_data.value('(event/data[@name="file_id"]/value)[1]', 'int') AS FILE_ID,
event_data.value('(event/data[@name="page_id"]/value)[1]', 'int') AS page_id,
event_data.value('(event/data[@name="file_group_id"]/value)[1]', 'int') AS file_group_id,
event_data.value('(event/action[@name="sql_text"]/value)[1]', 'nvarchar(4000)') AS sql_text,
CAST(SUBSTRING(event_data.value('(event/action[@name="attach_activity_id"]/value)[1]', 'varchar(50)'), 1, 36) AS uniqueidentifier) as activity_id,
CAST(SUBSTRING(event_data.value('(event/action[@name="attach_activity_id"]/value)[1]', 'varchar(50)'), 38, 10) AS int) as event_sequence,
CAST(SUBSTRING(event_data.value('(event/action[@name="attach_activity_id_xfer"]/value)[1]', 'varchar(50)'), 1, 36) AS uniqueidentifier) as activity_id_xfer,
event_data

FROM #temp_xe;
GO

DECLARE @DeleteDate DATETIME = GETDATE();
EXECUTE master.sys.xp_cmdshell 'del D:\event_sessions\backups\*.xel';
EXECUTE master.sys.xp_delete_file 0,N'd:\backups\','BAK',@DeleteDate,0;
EXECUTE master.sys.xp_delete_file 0,N'C:\Program Files\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\Backup\','BAK',@DeleteDate,0;
GO


ALTER EVENT SESSION BackupObservation ON SERVER
	STATE = START
GO

BACKUP DATABASE greek
	TO	
		DISK = N'AW_1.BAK',
		DISK = N'AW_2.BAK'		
	WITH MAXTRANSFERSIZE=2097152
GO

ALTER EVENT SESSION BackupObservation ON SERVER
	STATE = STOP;
GO

truncate table #temp_xe;
insert into #temp_xe
select * 	
	from (
			SELECT
		CAST(event_data AS XML) AS event_data
		FROM sys.fn_xe_file_target_read_file('D:\event_sessions\backups\BackupObservation*.xel', NULL, NULL, NULL)
	) b;

INSERT INTO analysis.dbo.BackupObservation
SELECT
2 as stripe_count,
'Minimal' contention_type,
'Full' backup_type,
'MaxTransferSizex2' backup_options,
event_data.value('(event/@name)[1]', 'varchar(50)') AS event_name,
event_data.value('(event/@package)[1]', 'varchar(50)') AS package_name,
event_data.value('(event/@timestamp)[1]', 'datetime2') AS event_timestamp,
COALESCE(event_data.value('(event/data[@name="database_id"]/value)[1]', 'int'),
event_data.value('(event/action[@name="database_id"]/value)[1]', 'int')) AS database_id,
event_data.value('(event/data[@name="message"]/value)[1]', 'nvarchar(4000)') AS trace_print,
event_data.value('(event/data[@name="count"]/value)[1]', 'bigint') AS [count],
event_data.value('(event/data[@name="increment"]/value)[1]', 'bigint') AS [increment],
event_data.value('(event/data[@name="wait_type"]/text)[1]', 'nvarchar(100)') AS wait_type,
event_data.value('(event/data[@name="opcode"]/text)[1]', 'nvarchar(10)') AS opcode,
event_data.value('(event/data[@name="duration"]/value)[1]', 'bigint') AS duration,
event_data.value('(event/data[@name="max_duration"]/value)[1]', 'bigint') AS max_duration,
event_data.value('(event/data[@name="total_duration"]/value)[1]', 'bigint') AS total_duration,
event_data.value('(event/data[@name="signal_duration"]/value)[1]', 'bigint') AS signal_duration,
event_data.value('(event/data[@name="completed_count"]/value)[1]', 'bigint') AS completed_count,
event_data.value('(event/data[@name="source_database_id"]/value)[1]', 'int') AS source_database_id,
event_data.value('(event/data[@name="object_id"]/value)[1]', 'int') AS OBJECT_ID,
event_data.value('(event/data[@name="object_type"]/value)[1]', 'int') AS object_type,
event_data.value('(event/data[@name="state"]/text)[1]', 'nvarchar(50)') AS state,
event_data.value('(event/data[@name="offset"]/value)[1]', 'bigint') AS offset,
event_data.value('(event/data[@name="offset_end"]/value)[1]', 'int') AS offset_end,
event_data.value('(event/data[@name="nest_level"]/value)[1]', 'int') AS nest_level,
event_data.value('(event/data[@name="cpu"]/value)[1]', 'int') AS cpu,
event_data.value('(event/data[@name="reads"]/value)[1]', 'bigint') AS reads,
event_data.value('(event/data[@name="writes"]/value)[1]', 'bigint') AS writes,
event_data.value('(event/data[@name="mode"]/text)[1]', 'nvarchar(50)') AS mmode,
event_data.value('(event/data[@name="file_id"]/value)[1]', 'int') AS FILE_ID,
event_data.value('(event/data[@name="page_id"]/value)[1]', 'int') AS page_id,
event_data.value('(event/data[@name="file_group_id"]/value)[1]', 'int') AS file_group_id,
event_data.value('(event/action[@name="sql_text"]/value)[1]', 'nvarchar(4000)') AS sql_text,
CAST(SUBSTRING(event_data.value('(event/action[@name="attach_activity_id"]/value)[1]', 'varchar(50)'), 1, 36) AS uniqueidentifier) as activity_id,
CAST(SUBSTRING(event_data.value('(event/action[@name="attach_activity_id"]/value)[1]', 'varchar(50)'), 38, 10) AS int) as event_sequence,
CAST(SUBSTRING(event_data.value('(event/action[@name="attach_activity_id_xfer"]/value)[1]', 'varchar(50)'), 1, 36) AS uniqueidentifier) as activity_id_xfer,
event_data

FROM #temp_xe;
GO

DECLARE @DeleteDate DATETIME = GETDATE();
EXECUTE master.sys.xp_cmdshell 'del D:\event_sessions\backups\*.xel';
EXECUTE master.sys.xp_delete_file 0,N'd:\backups\','BAK',@DeleteDate,0;
EXECUTE master.sys.xp_delete_file 0,N'C:\Program Files\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\Backup\','BAK',@DeleteDate,0;
GO


ALTER EVENT SESSION BackupObservation ON SERVER
	STATE = START
GO

BACKUP DATABASE greek
	TO	
		DISK = N'D:\backups\AW_1.BAK'		,
		DISK = N'D:\backups\AW_2.BAK'		
	WITH MAXTRANSFERSIZE=2097152
GO

ALTER EVENT SESSION BackupObservation ON SERVER
	STATE = STOP;
GO

truncate table #temp_xe;
insert into #temp_xe
select * 	
	from (
			SELECT
		CAST(event_data AS XML) AS event_data
		FROM sys.fn_xe_file_target_read_file('D:\event_sessions\backups\BackupObservation*.xel', NULL, NULL, NULL)
	) b;

INSERT INTO analysis.dbo.BackupObservation
SELECT
2 as stripe_count,
'Backup' contention_type,
'Full' backup_type,
'MaxTransferSizex2' backup_options,
event_data.value('(event/@name)[1]', 'varchar(50)') AS event_name,
event_data.value('(event/@package)[1]', 'varchar(50)') AS package_name,
event_data.value('(event/@timestamp)[1]', 'datetime2') AS event_timestamp,
COALESCE(event_data.value('(event/data[@name="database_id"]/value)[1]', 'int'),
event_data.value('(event/action[@name="database_id"]/value)[1]', 'int')) AS database_id,
event_data.value('(event/data[@name="message"]/value)[1]', 'nvarchar(4000)') AS trace_print,
event_data.value('(event/data[@name="count"]/value)[1]', 'bigint') AS [count],
event_data.value('(event/data[@name="increment"]/value)[1]', 'bigint') AS [increment],
event_data.value('(event/data[@name="wait_type"]/text)[1]', 'nvarchar(100)') AS wait_type,
event_data.value('(event/data[@name="opcode"]/text)[1]', 'nvarchar(10)') AS opcode,
event_data.value('(event/data[@name="duration"]/value)[1]', 'bigint') AS duration,
event_data.value('(event/data[@name="max_duration"]/value)[1]', 'bigint') AS max_duration,
event_data.value('(event/data[@name="total_duration"]/value)[1]', 'bigint') AS total_duration,
event_data.value('(event/data[@name="signal_duration"]/value)[1]', 'bigint') AS signal_duration,
event_data.value('(event/data[@name="completed_count"]/value)[1]', 'bigint') AS completed_count,
event_data.value('(event/data[@name="source_database_id"]/value)[1]', 'int') AS source_database_id,
event_data.value('(event/data[@name="object_id"]/value)[1]', 'int') AS OBJECT_ID,
event_data.value('(event/data[@name="object_type"]/value)[1]', 'int') AS object_type,
event_data.value('(event/data[@name="state"]/text)[1]', 'nvarchar(50)') AS state,
event_data.value('(event/data[@name="offset"]/value)[1]', 'bigint') AS offset,
event_data.value('(event/data[@name="offset_end"]/value)[1]', 'int') AS offset_end,
event_data.value('(event/data[@name="nest_level"]/value)[1]', 'int') AS nest_level,
event_data.value('(event/data[@name="cpu"]/value)[1]', 'int') AS cpu,
event_data.value('(event/data[@name="reads"]/value)[1]', 'bigint') AS reads,
event_data.value('(event/data[@name="writes"]/value)[1]', 'bigint') AS writes,
event_data.value('(event/data[@name="mode"]/text)[1]', 'nvarchar(50)') AS mmode,
event_data.value('(event/data[@name="file_id"]/value)[1]', 'int') AS FILE_ID,
event_data.value('(event/data[@name="page_id"]/value)[1]', 'int') AS page_id,
event_data.value('(event/data[@name="file_group_id"]/value)[1]', 'int') AS file_group_id,
event_data.value('(event/action[@name="sql_text"]/value)[1]', 'nvarchar(4000)') AS sql_text,
CAST(SUBSTRING(event_data.value('(event/action[@name="attach_activity_id"]/value)[1]', 'varchar(50)'), 1, 36) AS uniqueidentifier) as activity_id,
CAST(SUBSTRING(event_data.value('(event/action[@name="attach_activity_id"]/value)[1]', 'varchar(50)'), 38, 10) AS int) as event_sequence,
CAST(SUBSTRING(event_data.value('(event/action[@name="attach_activity_id_xfer"]/value)[1]', 'varchar(50)'), 1, 36) AS uniqueidentifier) as activity_id_xfer,
event_data

FROM #temp_xe;
GO

DECLARE @DeleteDate DATETIME = GETDATE();
EXECUTE master.sys.xp_cmdshell 'del D:\event_sessions\backups\*.xel';
EXECUTE master.sys.xp_delete_file 0,N'd:\backups\','BAK',@DeleteDate,0;
EXECUTE master.sys.xp_delete_file 0,N'C:\Program Files\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\Backup\','BAK',@DeleteDate,0;
GO


ALTER EVENT SESSION BackupObservation ON SERVER
	STATE = START
GO

BACKUP DATABASE greek
	TO	
		DISK = N'AW_1.BAK'		,
		DISK = N'D:\backups\AW_2.BAK'		
	WITH MAXTRANSFERSIZE=2097152
GO

ALTER EVENT SESSION BackupObservation ON SERVER
	STATE = STOP;
GO

truncate table #temp_xe;
insert into #temp_xe
select * 	
	from (
			SELECT
		CAST(event_data AS XML) AS event_data
		FROM sys.fn_xe_file_target_read_file('D:\event_sessions\backups\BackupObservation*.xel', NULL, NULL, NULL)
	) b;

INSERT INTO analysis.dbo.BackupObservation
SELECT
2 as stripe_count,
'Split' contention_type,
'Full' backup_type,
'MaxTransferSizex2' backup_options,
event_data.value('(event/@name)[1]', 'varchar(50)') AS event_name,
event_data.value('(event/@package)[1]', 'varchar(50)') AS package_name,
event_data.value('(event/@timestamp)[1]', 'datetime2') AS event_timestamp,
COALESCE(event_data.value('(event/data[@name="database_id"]/value)[1]', 'int'),
event_data.value('(event/action[@name="database_id"]/value)[1]', 'int')) AS database_id,
event_data.value('(event/data[@name="message"]/value)[1]', 'nvarchar(4000)') AS trace_print,
event_data.value('(event/data[@name="count"]/value)[1]', 'bigint') AS [count],
event_data.value('(event/data[@name="increment"]/value)[1]', 'bigint') AS [increment],
event_data.value('(event/data[@name="wait_type"]/text)[1]', 'nvarchar(100)') AS wait_type,
event_data.value('(event/data[@name="opcode"]/text)[1]', 'nvarchar(10)') AS opcode,
event_data.value('(event/data[@name="duration"]/value)[1]', 'bigint') AS duration,
event_data.value('(event/data[@name="max_duration"]/value)[1]', 'bigint') AS max_duration,
event_data.value('(event/data[@name="total_duration"]/value)[1]', 'bigint') AS total_duration,
event_data.value('(event/data[@name="signal_duration"]/value)[1]', 'bigint') AS signal_duration,
event_data.value('(event/data[@name="completed_count"]/value)[1]', 'bigint') AS completed_count,
event_data.value('(event/data[@name="source_database_id"]/value)[1]', 'int') AS source_database_id,
event_data.value('(event/data[@name="object_id"]/value)[1]', 'int') AS OBJECT_ID,
event_data.value('(event/data[@name="object_type"]/value)[1]', 'int') AS object_type,
event_data.value('(event/data[@name="state"]/text)[1]', 'nvarchar(50)') AS state,
event_data.value('(event/data[@name="offset"]/value)[1]', 'bigint') AS offset,
event_data.value('(event/data[@name="offset_end"]/value)[1]', 'int') AS offset_end,
event_data.value('(event/data[@name="nest_level"]/value)[1]', 'int') AS nest_level,
event_data.value('(event/data[@name="cpu"]/value)[1]', 'int') AS cpu,
event_data.value('(event/data[@name="reads"]/value)[1]', 'bigint') AS reads,
event_data.value('(event/data[@name="writes"]/value)[1]', 'bigint') AS writes,
event_data.value('(event/data[@name="mode"]/text)[1]', 'nvarchar(50)') AS mmode,
event_data.value('(event/data[@name="file_id"]/value)[1]', 'int') AS FILE_ID,
event_data.value('(event/data[@name="page_id"]/value)[1]', 'int') AS page_id,
event_data.value('(event/data[@name="file_group_id"]/value)[1]', 'int') AS file_group_id,
event_data.value('(event/action[@name="sql_text"]/value)[1]', 'nvarchar(4000)') AS sql_text,
CAST(SUBSTRING(event_data.value('(event/action[@name="attach_activity_id"]/value)[1]', 'varchar(50)'), 1, 36) AS uniqueidentifier) as activity_id,
CAST(SUBSTRING(event_data.value('(event/action[@name="attach_activity_id"]/value)[1]', 'varchar(50)'), 38, 10) AS int) as event_sequence,
CAST(SUBSTRING(event_data.value('(event/action[@name="attach_activity_id_xfer"]/value)[1]', 'varchar(50)'), 1, 36) AS uniqueidentifier) as activity_id_xfer,
event_data

FROM #temp_xe;
GO

DECLARE @DeleteDate DATETIME = GETDATE();
EXECUTE master.sys.xp_cmdshell 'del D:\event_sessions\backups\*.xel';
EXECUTE master.sys.xp_delete_file 0,N'd:\backups\','BAK',@DeleteDate,0;
EXECUTE master.sys.xp_delete_file 0,N'C:\Program Files\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\Backup\','BAK',@DeleteDate,0;
GO

drop table #temp_xe;


use analysis
go

INSERT INTO event_timeline (event_name, event_timestamp, backup_stripes, backup_contention, backup_type, backup_options, event_data)
	select event_name, event_timestamp, stripe_count, contention_type, backup_type, backup_options, event_data from dbo.BackupObservation