/*
*/
IF EXISTS (select 1 from dba.sys.indexes where name = 'cix_user_user_id')
	DROP INDEX cix_user_user_id on dba.dbo.[User];

IF EXISTS (select 1 from dba.sys.indexes where name = 'cix_post_user_id')
	DROP INDEX cix_post_user_id on dba.dbo.Post;

IF EXISTS (select 1 from sf.sys.indexes where name = 'cix_user_user_id')
	DROP INDEX cix_user_user_id on sf.dbo.[User];

IF EXISTS (select 1 from sf.sys.indexes where name = 'cix_post_user_id')
	DROP INDEX cix_post_user_id on sf.dbo.Post;


IF EXISTS (select 1 from su.sys.indexes where name = 'cix_user_user_id')
	DROP INDEX cix_user_user_id on su.dbo.[User];

IF EXISTS (select 1 from su.sys.indexes where name = 'cix_post_user_id')
	DROP INDEX cix_post_user_id on su.dbo.Post;
GO
truncate table analysis.dbo.event_timeline;
go
ALTER EVENT SESSION system_health ON SERVER
	STATE = STOP;
GO

DROP EVENT SESSION BackupObservation ON SERVER;
GO
DROP EVENT SESSION CombinedCheck ON SERVER;
GO
DROP EVENT SESSION NewCheck ON SERVER;
GO
DROP EVENT SESSION OldCheck ON SERVER;
GO
DROP EVENT SESSION sql_module_execution ON SERVER;
GO
/*
	CLEAN OLD FILES
*/

EXECUTE master.sys.xp_cmdshell 'del D:\event_sessions\backups\*.xel';
GO
EXECUTE master.sys.xp_cmdshell 'del D:\event_sessions\*.xel';
GO
EXECUTE master.sys.xp_cmdshell 'del "C:\Program Files\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\Log\*.xel"';
GO