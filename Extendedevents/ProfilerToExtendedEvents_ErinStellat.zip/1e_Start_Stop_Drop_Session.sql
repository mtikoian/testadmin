/*============================================================================
  File:     1e_Start_Stop_Drop_Session.sql

  SQL Server Versions: 2005 onwards
------------------------------------------------------------------------------
  Written by Erin Stellato, SQLskills.com
  
  (c) 2013, SQLskills.com. All rights reserved.

  For more scripts and sample code, check out 
    http://www.SQLskills.com

  You may alter this code for your own *non-commercial* purposes. You may
  republish altered code as long as you include this copyright and give due
  credit, but you must obtain prior permission before blogging this code.
  
  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
  TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
  PARTICULAR PURPOSE.
============================================================================*/

/*
	Check to see what exists
*/
SELECT * FROM [sys].[server_event_sessions];
GO

SELECT * FROM [sys].[fn_trace_getinfo](0);



/*
	Start
*/
ALTER EVENT SESSION [XE_NoFilter_Trace]
	ON SERVER
	STATE=START;
	GO

DECLARE @TraceID INT = 2;
EXEC sp_trace_setstatus @TraceID, 1;



/*
	What's running?
*/
SELECT
	[es].[name] AS [EventSession],
	[xe].[create_time] AS [SessionCreateTime],
	[xe].[total_buffer_size] AS [TotalBufferSize],
	[xe].[dropped_event_count] AS [DroppedEventCount]
FROM [sys].[server_event_sessions] [es]
LEFT OUTER JOIN [sys].[dm_xe_sessions] [xe] ON [es].[name] = [xe].[name]


SELECT 
	[id] AS [TraceID],
	CASE	
		WHEN [status] = 0 THEN 'Not running'
		WHEN [status] = 1 THEN 'Running'
	END AS [TraceStatus],
	[start_time] AS [TraceStartTime],
	[buffer_size] AS [BufferSize],
	[dropped_event_count] AS [DroppedEventCount]
FROM [sys].[traces] 
GO


/*
	Stop (run workload before stopping - remove filter)
*/
ALTER EVENT SESSION [XE_NoFilter_Trace]
	ON SERVER
	STATE=STOP;
	GO

DECLARE @TraceID INT = 2;
EXEC sp_trace_setstatus @TraceID, 0; 



/*
	Remove
*/
DROP EVENT SESSION [XE_NoFilter_Trace]
	ON SERVER;
	GO

DECLARE @TraceID INT = 2;
EXEC sp_trace_setstatus @TraceID, 2;


/*

SELECT
	[ses].[name] AS [Session],
	[sest].[name] AS [TargetName],
	[sesf].[name] AS [OptionName],
	[sesf].[value] AS [OptionValue]
FROM [sys].[server_event_sessions] [ses]
JOIN [sys].[server_event_session_targets] [sest] ON [ses].[event_session_id] = [sest].[event_session_id]
JOIN [sys].[server_event_session_fields] [sesf] ON [ses].[event_session_id] = [sesf].[event_session_id] AND [sest].[target_id] = [sesf].[object_id];
GO

SELECT 
	[traceid] AS [TraceID], 
	CASE
		WHEN [property] = 1 AND [value] = 0 THEN 'No trace file rollover'
		WHEN [property] = 1 AND [value] = 2 THEN 'Trace file rollover enabled'
		WHEN [property] = 1 AND [value] = 4 THEN 'Shut down on error'
		WHEN [property] = 1 AND [value] = 8 THEN 'Trace produce black box'
		WHEN [property] = 2 THEN 'Trace file name: ' + CAST(VALUE AS VARCHAR(50))
		WHEN [property] = 3 THEN 'Max file size: ' + CAST(VALUE AS VARCHAR(10)) + ' MB'
		WHEN [property] = 4 AND [value] IS NOT NULL THEN 'Trace stop time = ' + CAST(VALUE AS VARCHAR(20))
		WHEN [property] = 4 AND [value] IS NULL THEN 'No specified stop time'
		WHEN [property] = 5 AND [value] = 0 THEN 'Not running'
		WHEN [property] = 5 AND [value] = 1 THEN 'Running'
		ELSE ''
	END [TracePropertyValue]
FROM sys.fn_trace_getinfo(0);
GO
*/

