/***************************************************************
  Name: 1_XEBasicsAndSetup.sql
  Project/Ticket#: Summit 2017
  Date: October 2017
  Requester: PASS
  DBA: David M Maxwell
  Step: 1 of 5
  Server: USLTMAXWELL
  Notes: This script demonstrates the basics of capturing wait 
  statistics with Extended Events. It covers the default info
  captured with XE, constructing the session and reading the
  output. 
***************************************************************/

use [master]; 
go 

/***** Where to find the wait stats info. *****/

/* What events can we use to capture wait stats? */
select xp.name + '.' + xo.name as ObjectName, xo.Description 
from sys.dm_xe_objects xo
inner join sys.dm_xe_packages xp
	on xp.guid = xo.package_guid
where xo.object_type = 'event' 
  and xo.name like '%wait%'
order by xo.object_type, xo.name
;
go 

/* Events: What info is captured by default? (Other than timestamp.) */
select name, description 
from sys.dm_xe_object_columns 
where object_name = 'wait_info'
and column_type = 'data'
order by column_id;
go

/* Actions: What else can we capture? */
select xp.name + '.' + xo.name as ObjectName, xo.Description 
from sys.dm_xe_objects xo
inner join sys.dm_xe_packages xp
	on xp.guid = xo.package_guid
where xo.object_type = 'action' 
  and xp.name = 'sqlserver'
order by xo.object_type, xo.name
;
go

/* Targets: Where will we write this info to? */
select xp.name + '.' + xo.name as ObjectName, xo.Description 
from sys.dm_xe_objects xo
inner join sys.dm_xe_packages xp
	on xp.guid = xo.package_guid
where xo.object_type = 'target' 
  and xp.name = 'package0'
order by xo.object_type, xo.name
;
go

/* Creating the XE Session */
create event session WaitStatsBasic on server
add event sqlos.wait_info (  
	/* What else do we want to output? */
	action ( 
		sqlserver.database_name, 
		sqlserver.username, 
		sqlserver.client_app_name
		)
	)
/* Where are we going to write this information to? */
add target package0.event_file (
	set filename = 'C:\SQL\Scripts\xe_targets\WaitStatsBasic.xel'
	); 
go 

/* Start the session */
alter event session WaitStatsBasic on server
state = start;
go

/* Workload to run: Order Insert, 50 threads. */

/* Stop the session. */
alter event session WaitStatsBasic on server
state = stop;
go

/* Import file output to temp table */
create table #wstemp(
	id int identity(1,1) not null, 
	rowdata xml not null
);
go 

insert into #wstemp(rowdata)
select convert(xml,event_data) 
from sys.fn_xe_file_target_read_file(
	'C:\SQL\Scripts\xe_targets\WaitStatsBasic*.xel', 
	 null, null, null)
;
go

/* What's all that in the temp table? */
select * from #wstemp

/* xQuery time! Extract the XML data to a table. */  --NTS: Fix the data types.
select 
	 rowdata.value ('(/event/@timestamp)[1]', 'DATETIME') AS [DTime]
	,rowdata.value ('(/event/data[@name = ''wait_type'']/text)[1]','varchar(128)') as wait_type
	,rowdata.value ('(/event/data[@name = ''duration'']/value)[1]','int') as total_wait
	,rowdata.value ('(/event/data[@name = ''signal_duration'']/value)[1]','int') as signal_wait
	,rowdata.value ('(/event/data[@name = ''opcode'']/text)[1]','varchar(10)') as OpCode
	,rowdata.value ('(/event/action[@name = ''database_name'']/value)[1]','varchar(32)') as DBName
	,rowdata.value ('(/event/action[@name = ''username'']/value)[1]','varchar(64)') as UserName
	,rowdata.value ('(/event/action[@name = ''client_app_name'']/value)[1]','varchar(64)') as AppName
into #wsoutput
from #wstemp

/* Examine the output. */
select top 1000 * from #wsoutput;
go

/* Clean up. */
drop event session WaitStatsBasic on server; 
go

