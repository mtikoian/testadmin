﻿<######################################################

Script Name      : Multi-Server Wait Stats XE Sessions
Project / Ticket : Summit 2017
Date             : October 2017
Requester        : PASS
DBA              : David M Maxwell
Step             : 5 of 5
Server           : USLTMAXWELL
Notes            : This script starts a coordinated XE
                   trace across multiple instances. It
                   requires access to a common trace 
                   definition file. 

                   NOTE: Remember to start workloads 
                   before running this script. 

######################################################>
<# We need the sqlserver module for Invoke-Sqlcmd #>
Import-Module sqlserver

<# Select the instances to run this on, the session definition, and the duration in seconds. #>
$instances = @('usltmaxwell','usltmaxwell\dev2014')
$scriptname = 'C:\Users\DavidMaxwell\OneDrive\SQLSaturday\TargtingWSwithXE\XEWaitStats\XEWaitStats\5.1_SessionDefForAutomation.sql' 
$duration = 10 

<# Create and start the session on each server with the definition script. #>
foreach($inst in $instances){
    Invoke-Sqlcmd -ServerInstance $inst -InputFile $scriptname -Verbose
    }

<# Wait for $duration seconds... #>
Start-Sleep -Seconds $duration

<# Stop and drop the session on each server. #>
foreach($inst in $instances){
    Invoke-Sqlcmd -ServerInstance $inst -Query '
        alter event session WSQuickCapture on server 
        state = stop;
        
        drop event session WSQuickCapture on server;
        '
    }
