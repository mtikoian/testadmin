/***************************************************************
  Name: 5.2_MultiSessionAnalysis.sql
  Project/Ticket#: Summit 2017
  Date: October 2017
  Requester: PASS
  DBA: David M Maxwell
  Step: 5.2 of 5.2
  Server: USLTMAXWELL
  Notes: This script is the XE session definition required for 
  the automation demo. Run the appropriate PowerShell script 
  to use this definition across multiple instances. 
***************************************************************/
use [master]; 
go

/* Create temp table to import the xe files. */
if (select object_id('tempdb.dbo.#wsqtemp')) is not null
begin 
	drop table #wsqtemp
end

create table #wsqtemp (
	id int identity not null, 
	rowdata xml not null
)

/* Pull in all files... */
insert into #wsqtemp
select event_data
from sys.fn_xe_file_target_read_file (
	'C:\SQL\Scripts\xe_targets\WSQuickCapture*.xel',null,null,null
)

/* Shred the XML... */
select 
	 rowdata.value ('(/event/@timestamp)[1]', 'DATETIME') AS DTime
	,rowdata.value ('(/event/@name)[1]','varchar(23)') as EventType
	,rowdata.value ('(/event/data[@name = ''wait_type'']/text)[1]','varchar(128)') as wait_type
	,rowdata.value ('(/event/data[@name = ''duration'']/value)[1]','int') as duration
	,rowdata.value ('(/event/data[@name = ''signal_duration'']/value)[1]','int') as signal_wait
	,rowdata.value ('(/event/action[@name = ''session_id'']/value)[1]','int') as session_id
	,rowdata.value ('(/event/action[@name = ''server_instance_name'']/value)[1]','varchar(30)') as servername
	,rowdata.value ('(/event/action[@name = ''client_app_name'']/value)[1]','varchar(36)') as appname
	,rowdata.value ('(/event/action[@name = ''database_name'']/value)[1]','varchar(128)') as dbname
	,rowdata.value ('(/event/action[@name = ''username'']/value)[1]','varchar(36)') as username
	,rowdata.value ('(/event/data[@name = ''statement'']/value)[1]','varchar(2000)') as stmt
into #wsqoutput
from #wsqtemp
order by DTime;
go 

/* breakdown of wait including servername. Again, calculating total wait for 
   percentage.  */
declare @totalwait decimal(10,2)
select @totalwait = sum(duration) from #wsqoutput where EventType  = 'wait_info';

select 
	servername, 
	wait_type, 
	sum(duration) as total_wait,
	PctOfTotalWait = (sum(duration) / @totalwait) * 100
from #wsqoutput 
where EventType = 'wait_info'
group by servername, wait_type 
order by PctOfTotalWait desc;
go


/* Correlating waits with queries, but including server names this time. */
with waits as (
	select DTime, servername, session_id, wait_type, duration, signal_wait 
	from #wsqoutput
	where EventType = 'wait_info'
), stmts as (
	select DTime, servername, session_id, stmt 
	from #wsqoutput
	where EventType = 'sql_statement_completed'
)
select 
	count(*) as ExecutionCount, max(w.DTime) as StmtEnd, w.servername, w.session_id, w.wait_type, sum(w.duration) as WaitTime, s.stmt as Statement
from waits w
inner join stmts s
    on w.DTime = s.DTime 
where w.wait_type = 'WRITELOG'
group by w.servername, w.session_id, w.wait_type, s.stmt
order by StmtEnd;
go
