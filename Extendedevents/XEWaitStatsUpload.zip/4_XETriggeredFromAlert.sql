/***************************************************************
  Name: 4_XETriggeredFromAlert.sql
  Project/Ticket#: Summit 2017
  Date: October 2017
  Requester: PASS
  DBA: David M Maxwell
  Step: 4 of 5
  Server: USLTMAXWELL
  Notes: This script demonstrates setting up a SQL Agent Alert 
  to trigger a 30 second XE trace for a particular performance
  condition. 
***************************************************************/
use [master]; 
go 

/* Create XE Session definition to use in trace job. */

create event session WritelogAlert on server
add event sqlos.wait_info (
	action (sqlserver.database_name, 
		    sqlserver.client_app_name, 
			sqlserver.session_id, 
			sqlserver.username)
	where opcode = 1
	  and sqlserver.is_system = 0
	  and wait_type = 181
)
add target package0.event_file (
	set filename = 'C:\SQL\Scripts\xe_targets\WritelogAlert.xel'
);
go


/* Create job that will disable alert (so it won't fire the job twice)
   and then run the session for a predetermined duration. 
*/
USE [msdb]
GO

/****** Object:  Job [RunWaitStatXESession]    Script Date: 10/19/2017 12:04:03 AM ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 10/19/2017 12:04:03 AM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'RunWritelogAlertSession', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Start Session]    Script Date: 10/19/2017 12:04:04 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Start Session', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
exec msdb.dbo.sp_update_alert @name=N''TriggerWritelogAlertSession'', 
@enabled=0;
go 

alter event session WritelogAlert on server
state = start;
go', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Wait 10 seconds]    Script Date: 10/19/2017 12:04:04 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Wait 10 seconds', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'waitfor delay ''00:00:10'';', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Stop Session and Disable Alert]    Script Date: 10/19/2017 12:04:04 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Stop Session and Disable Alert', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'alter event session WritelogAlert on server
state = stop;
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO


/* Create the SQL Agent alert for a performance condition. */
USE [msdb]
GO

/* Grab the job ID... */
declare @jobid nvarchar(36)
select job_id from msdb.dbo.sysjobs
where name = 'RunWritelogAlertSession';


/****** Object:  Alert [TriggerXESessionOnSomething]    Script Date: 10/19/2017 12:01:25 AM ******/
EXEC msdb.dbo.sp_add_alert @name=N'TriggerWritelogAlertSession', 
		@message_id=0, 
		@severity=0, 
		@enabled=1, 
		@delay_between_responses=0, 
		@include_event_description_in=0, 
		@category_name=N'[Uncategorized]', 
		@performance_condition=N'Wait Statistics|Log write waits|Waits started per second|>|50', 
		@job_id='DD716787-4193-4666-BEAA-089D1A79E758'
GO

/* Run a workload that causes that condition. (Order insert, 10 threads will do.) */ 

/* Import the output of the XE Trace to a temp table. */
if (select object_id('tempdb.dbo.#wltemp')) is not null
begin
	drop table #wltemp
end

create table #wltemp (
	id int identity not null, 
	rowdata xml not null
);

insert into #wltemp (rowdata)
select event_data 
from sys.fn_xe_file_target_read_file (
	'C:\SQL\Scripts\xe_targets\WritelogAlert*.xel', null, null, null
);
go 

/* Shred that XML like iceberg lettuce. */
if (select object_id('tempdb.dbo.#wloutput')) is not null
begin
	drop table #wloutput
end

select 
	id, 
	rowdata.value ('(/event/data[@name=''duration'']/value)[1]','decimal(10,2)') as duration,
	rowdata.value ('(/event/data[@name=''signal_duration'']/value)[1]','decimal(10,2)') as signal_duration,
	rowdata.value ('(/event/action[@name=''username'']/value)[1]','varchar(36)') as username,
	rowdata.value ('(/event/action[@name=''client_app_name'']/value)[1]','varchar(100)') as appname,
	rowdata.value ('(/event/action[@name=''database_name'']/value)[1]','varchar(100)') as dbname
into #wloutput	 
from #wltemp

/* Calc the total amount of wait time captured to compare as a percentage. */
declare @totalwait decimal(10,2)
select @totalwait = sum(duration)
from #wloutput

/* Breakdown of waits by DB, app and user. */
select 
	dbname, 
	appname, 
	username, 
	sum(duration) as totalwait, 
	(sum(duration) / @totalwait) * 100 as PctOfTotal, 
	(sum(signal_duration) / sum (duration)) * 100 as PctSignalWait 
from #wloutput
group by dbname, appname, username
order by PctOfTotal desc

/* Clean up. */
drop event session WritelogAlert on server;
exec sp_delete_job @job_name = 'RunWritelogAlertSession'
exec sp_delete_alert @name = 'TriggerWritelogAlertSession'

