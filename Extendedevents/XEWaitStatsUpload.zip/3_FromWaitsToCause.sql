/***************************************************************
  Name: 3_FromWaitsToCause.sql
  Project/Ticket#: Summit 2017
  Date: October 2017
  Requester: PASS
  DBA: David M Maxwell
  Step: 3 of 5
  Server: USLTMAXWELL
  Notes: This script demonstrates how to work backwards from 
  the top wait stats recorded on the instance to the processes
  that are causing them. 
***************************************************************/
use [master]; 
go 

/* Create XE session to track both wait_info *and* statement completion
   to associate queries with wait stats.  Add both actions with similar 
   filters.
*/
if exists (select name from sys.server_event_sessions where name = 'MysteryWaits')
begin 
	drop event session MysteryWaits on server
end;
go 

create event session MysteryWaits on server
add event  sqlos.wait_info (
	action (sqlserver.session_id)
	where  (sqlserver.database_name = 'WideWorldImporters')
	  and  (opcode = 1)
	  and  (sqlserver.is_system = 0)
	  and  (sqlserver.username = 'sa')
	  ),
add event  sqlserver.rpc_completed (
	action (sqlserver.session_id)
	where  (sqlserver.database_name = 'WideWorldImporters')
	  and  (sqlserver.is_system = 0)
	  )
add target package0.event_file (
	set filename = 'C:\SQL\Scripts\xe_targets\MysteryWaits.xel'
);
		   

/* Start the session and let it run for about 10 seconds, 
   using the same workload as the last time. 

   	* Order Insert: 10 threads. 
	* Insert Main: 2x, 10 threads, 100 rows, on disk. 	

*/
alter event session MysteryWaits on server 
state = start;

waitfor delay '00:00:10';

alter event session MysteryWaits on server
state = stop;
go


/* How many waits did we capture? Good output for... automation, mybe? */
select cast(count(*) as varchar) + ' waits captured.' from sys.fn_xe_file_target_read_file (
	'C:\SQL\Scripts\xe_targets\MysteryWaits*.xel', null, null, null
); 
go
 

/* Import the output into a temp table, and aggreate the data. */
if (select object_id('tempdb.dbo.#wstempm')) is not null
begin
	drop table #wstempm
end;

create table #wstempm (
	id int identity(1,1) not null, 
	rowdata xml not null
);
go

insert into #wstempm (rowdata)
select cast(event_data as XML) 
from sys.fn_xe_file_target_read_file (
	'C:\SQL\Scripts\xe_targets\MysteryWaits*.xel', null, null, null
);
go

/* Sanity check: select * from #wstempm */

if (select object_id('tempdb.dbo.#wsoutputm')) is not null
begin
	drop table #wsoutputm
end;

select 
	 rowdata.value ('(/event/@timestamp)[1]', 'DATETIME') AS DTime
	,rowdata.value ('(/event/@name)[1]','varchar(23)') as EventType
	,rowdata.value ('(/event/data[@name = ''wait_type'']/text)[1]','varchar(128)') as wait_type
	,rowdata.value ('(/event/data[@name = ''duration'']/value)[1]','int') as duration
	,rowdata.value ('(/event/data[@name = ''signal_duration'']/value)[1]','int') as signal_wait
	,rowdata.value ('(/event/action[@name = ''session_id'']/value)[1]','int') as session_id
	,rowdata.value ('(/event/data[@name = ''object_name'']/value)[1]','varchar(200)') as sproc
	,rowdata.value ('(/event/data[@name = ''statement'']/value)[1]','varchar(2000)') as stmt
into #wsoutputm
from #wstempm
order by DTime;
go 

/* Sanity check: select * from #wsoutputm */


/* So where are those writelog waits coming from? */
with waits as (
	select DTime, session_id, wait_type, duration, signal_wait 
	from #wsoutputm
	where EventType = 'wait_info'
), stmts as (
	select DTime, session_id, sproc, stmt 
	from #wsoutputm
	where EventType = 'rpc_completed'
)
select 
	max(w.DTime) as StmtEnd, w.session_id, s.sproc, w.wait_type, sum(w.duration) as WaitTime, s.stmt as Statement
from waits w
inner join stmts s
	on w.session_id = s.session_id 
   and w.DTime = s.DTime 
where w.wait_type = 'WRITELOG'
group by w.session_id, w.wait_type, s.sproc, s.stmt
order by StmtEnd;
go

/* Let's take a quick look at that procedure... */
exec sp_helptext 'website.InsertCustomerOrders';
go


/* Clean up. */
drop event session MysteryWaits on server;
go
