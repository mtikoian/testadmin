/***************************************************************
  Name: 2_FilterLevels.sql
  Project/Ticket#: Summit 2017
  Date: October 2017
  Requester: PASS
  DBA: David M Maxwell
  Step: 2 of 5
  Server: USLTMAXWELL
  Notes: This script demonstrates capturing wait statistics
  at several different filter and breakdown levels such as... 

  Instance
  Database
  Application
  User

***************************************************************/
use [master]; 
go 

/* What XE columns can we filter on? */
select object_name, name, type_name 
from sys.dm_xe_object_columns
where object_name = 'wait_info'
  and column_type = 'data'; 
go

/* "wait_types" isn't a data type. What does it map to? */
select distinct name, map_key, map_value
from sys.dm_xe_map_values
where name = 'wait_types'
order by name, map_key;
go 

/* What wait types are prevalent here? (Glenn Berry DMV query for SQL 2016.) */
WITH [Waits] 
AS (SELECT wait_type, wait_time_ms/ 1000.0 AS [WaitS],
          (wait_time_ms - signal_wait_time_ms) / 1000.0 AS [ResourceS],
           signal_wait_time_ms / 1000.0 AS [SignalS],
           waiting_tasks_count AS [WaitCount],
           100.0 *  wait_time_ms / SUM (wait_time_ms) OVER() AS [Percentage],
           ROW_NUMBER() OVER(ORDER BY wait_time_ms DESC) AS [RowNum]
    FROM sys.dm_os_wait_stats WITH (NOLOCK)
    WHERE [wait_type] NOT IN (
        N'BROKER_EVENTHANDLER', N'BROKER_RECEIVE_WAITFOR', N'BROKER_TASK_STOP',
		N'BROKER_TO_FLUSH', N'BROKER_TRANSMITTER', N'CHECKPOINT_QUEUE',
        N'CHKPT', N'CLR_AUTO_EVENT', N'CLR_MANUAL_EVENT', N'CLR_SEMAPHORE',
        N'DBMIRROR_DBM_EVENT', N'DBMIRROR_EVENTS_QUEUE', N'DBMIRROR_WORKER_QUEUE',
		N'DBMIRRORING_CMD', N'DIRTY_PAGE_POLL', N'DISPATCHER_QUEUE_SEMAPHORE',
        N'EXECSYNC', N'FSAGENT', N'FT_IFTS_SCHEDULER_IDLE_WAIT', N'FT_IFTSHC_MUTEX',
        N'HADR_CLUSAPI_CALL', N'HADR_FILESTREAM_IOMGR_IOCOMPLETION', N'HADR_LOGCAPTURE_WAIT', 
		N'HADR_NOTIFICATION_DEQUEUE', N'HADR_TIMER_TASK', N'HADR_WORK_QUEUE',
        N'KSOURCE_WAKEUP', N'LAZYWRITER_SLEEP', N'LOGMGR_QUEUE', 
		N'MEMORY_ALLOCATION_EXT', N'ONDEMAND_TASK_QUEUE',
		N'PREEMPTIVE_HADR_LEASE_MECHANISM', N'PREEMPTIVE_SP_SERVER_DIAGNOSTICS',
		N'PREEMPTIVE_OS_LIBRARYOPS', N'PREEMPTIVE_OS_COMOPS', N'PREEMPTIVE_OS_CRYPTOPS',
		N'PREEMPTIVE_OS_PIPEOPS', N'PREEMPTIVE_OS_AUTHENTICATIONOPS',
		N'PREEMPTIVE_OS_GENERICOPS', N'PREEMPTIVE_OS_VERIFYTRUST',
		N'PREEMPTIVE_OS_FILEOPS', N'PREEMPTIVE_OS_DEVICEOPS', N'PREEMPTIVE_OS_QUERYREGISTRY',
		N'PREEMPTIVE_OS_WRITEFILE',
		N'PREEMPTIVE_XE_CALLBACKEXECUTE', N'PREEMPTIVE_XE_DISPATCHER',
		N'PREEMPTIVE_XE_GETTARGETSTATE', N'PREEMPTIVE_XE_SESSIONCOMMIT',
		N'PREEMPTIVE_XE_TARGETINIT', N'PREEMPTIVE_XE_TARGETFINALIZE',
        N'PWAIT_ALL_COMPONENTS_INITIALIZED', N'PWAIT_DIRECTLOGCONSUMER_GETNEXT',
		N'QDS_PERSIST_TASK_MAIN_LOOP_SLEEP',
		N'QDS_ASYNC_QUEUE',
        N'QDS_CLEANUP_STALE_QUERIES_TASK_MAIN_LOOP_SLEEP', N'REQUEST_FOR_DEADLOCK_SEARCH',
		N'RESOURCE_QUEUE', N'SERVER_IDLE_CHECK', N'SLEEP_BPOOL_FLUSH', N'SLEEP_DBSTARTUP',
		N'SLEEP_DCOMSTARTUP', N'SLEEP_MASTERDBREADY', N'SLEEP_MASTERMDREADY',
        N'SLEEP_MASTERUPGRADED', N'SLEEP_MSDBSTARTUP', N'SLEEP_SYSTEMTASK', N'SLEEP_TASK',
        N'SLEEP_TEMPDBSTARTUP', N'SNI_HTTP_ACCEPT', N'SP_SERVER_DIAGNOSTICS_SLEEP',
		N'SQLTRACE_BUFFER_FLUSH', N'SQLTRACE_INCREMENTAL_FLUSH_SLEEP', N'SQLTRACE_WAIT_ENTRIES',
		N'WAIT_FOR_RESULTS', N'WAITFOR', N'WAITFOR_TASKSHUTDOWN', N'WAIT_XTP_HOST_WAIT',
		N'WAIT_XTP_OFFLINE_CKPT_NEW_LOG', N'WAIT_XTP_CKPT_CLOSE', N'WAIT_XTP_RECOVERY',
		N'XE_BUFFERMGR_ALLPROCESSED_EVENT', N'XE_DISPATCHER_JOIN',
        N'XE_DISPATCHER_WAIT', N'XE_LIVE_TARGET_TVF', N'XE_TIMER_EVENT')
    AND waiting_tasks_count > 0)
SELECT
    MAX (W1.wait_type) AS [WaitType],
    CAST (MAX (W1.WaitS) AS DECIMAL (16,2)) AS [Wait_Sec],
    CAST (MAX (W1.ResourceS) AS DECIMAL (16,2)) AS [Resource_Sec],
    CAST (MAX (W1.SignalS) AS DECIMAL (16,2)) AS [Signal_Sec],
    MAX (W1.WaitCount) AS [Wait Count],
    CAST (MAX (W1.Percentage) AS DECIMAL (5,2)) AS [Wait Percentage],
    CAST ((MAX (W1.WaitS) / MAX (W1.WaitCount)) AS DECIMAL (16,4)) AS [AvgWait_Sec],
    CAST ((MAX (W1.ResourceS) / MAX (W1.WaitCount)) AS DECIMAL (16,4)) AS [AvgRes_Sec],
    CAST ((MAX (W1.SignalS) / MAX (W1.WaitCount)) AS DECIMAL (16,4)) AS [AvgSig_Sec]
FROM Waits AS W1
INNER JOIN Waits AS W2
ON W2.RowNum <= W1.RowNum
GROUP BY W1.RowNum
HAVING SUM (W2.Percentage) - MAX (W1.Percentage) < 99 -- percentage threshold
OPTION (RECOMPILE);
GO 


/* Create XE session with "inclusive" filter. */
create event session WSInclude on server
add event sqlos.wait_info (  
	/* What else do we want to output? */
	action ( 
		sqlserver.database_name, 
		sqlserver.username, 
		sqlserver.client_app_name
		)
	/* Here's where we filter stuff. Just a WHERE clause. */
	where sqlserver.is_system = 0
	  and opcode = 1 
	  and (
		  ((wait_type >= 1 and wait_type <= 21) and duration >= 10000)  /* LCK waits over 10s */
	   or (wait_type >= 48 and wait_type <= 69) /* PAGELATCH / PAGEIOLATCH waits. */
	   or (wait_type >= 97 and wait_type <= 99) /* IO waits. */
	   or (wait_type = 110) /* RESOURCE_SEMAPHORE */
	   or (wait_type = 112) /* OLEDB */
	   or (wait_type = 123) /* SOS_SCHEDULER_YIELD */
	   or (wait_type = 181) /* WRITELOG */
	   or (wait_type = 191) /* CXPACKET */
	   or (wait_type = 204) /* EXECSYNC */
	   or (wait_type = 216) /* LOGBUFFER */
		)
	)
add target package0.event_file (
	set filename = 'C:\SQL\Scripts\xe_targets\WSInclude.xel'
	); 
go 

/* Query map for "excluded" wait types */
select name, map_key, map_value, 
	'  and (wait_type <> ' + cast(map_key as varchar(4)) + ') /* ' + map_value + ' */' as FilterClause
from sys.dm_xe_map_values
where name = 'wait_types'
  and map_value IN (
        N'BROKER_EVENTHANDLER', N'BROKER_RECEIVE_WAITFOR', N'BROKER_TASK_STOP',
		N'BROKER_TO_FLUSH', N'BROKER_TRANSMITTER', N'CHECKPOINT_QUEUE',
        N'CHKPT', N'CLR_AUTO_EVENT', N'CLR_MANUAL_EVENT', N'CLR_SEMAPHORE',
        N'DBMIRROR_DBM_EVENT', N'DBMIRROR_EVENTS_QUEUE', N'DBMIRROR_WORKER_QUEUE',
		N'DBMIRRORING_CMD', N'DIRTY_PAGE_POLL', N'DISPATCHER_QUEUE_SEMAPHORE',
        N'EXECSYNC', N'FSAGENT', N'FT_IFTS_SCHEDULER_IDLE_WAIT', N'FT_IFTSHC_MUTEX',
        N'HADR_CLUSAPI_CALL', N'HADR_FILESTREAM_IOMGR_IOCOMPLETION', N'HADR_LOGCAPTURE_WAIT', 
		N'HADR_NOTIFICATION_DEQUEUE', N'HADR_TIMER_TASK', N'HADR_WORK_QUEUE',
        N'KSOURCE_WAKEUP', N'LAZYWRITER_SLEEP', N'LOGMGR_QUEUE', 
		N'MEMORY_ALLOCATION_EXT', N'ONDEMAND_TASK_QUEUE',
		N'PREEMPTIVE_HADR_LEASE_MECHANISM', N'PREEMPTIVE_SP_SERVER_DIAGNOSTICS',
		N'PREEMPTIVE_OS_LIBRARYOPS', N'PREEMPTIVE_OS_COMOPS', N'PREEMPTIVE_OS_CRYPTOPS',
		N'PREEMPTIVE_OS_PIPEOPS', N'PREEMPTIVE_OS_AUTHENTICATIONOPS',
		N'PREEMPTIVE_OS_GENERICOPS', N'PREEMPTIVE_OS_VERIFYTRUST',
		N'PREEMPTIVE_OS_FILEOPS', N'PREEMPTIVE_OS_DEVICEOPS', N'PREEMPTIVE_OS_QUERYREGISTRY',
		N'PREEMPTIVE_OS_WRITEFILE',
		N'PREEMPTIVE_XE_CALLBACKEXECUTE', N'PREEMPTIVE_XE_DISPATCHER',
		N'PREEMPTIVE_XE_GETTARGETSTATE', N'PREEMPTIVE_XE_SESSIONCOMMIT',
		N'PREEMPTIVE_XE_TARGETINIT', N'PREEMPTIVE_XE_TARGETFINALIZE',
        N'PWAIT_ALL_COMPONENTS_INITIALIZED', N'PWAIT_DIRECTLOGCONSUMER_GETNEXT',
		N'QDS_PERSIST_TASK_MAIN_LOOP_SLEEP',
		N'QDS_ASYNC_QUEUE',
        N'QDS_CLEANUP_STALE_QUERIES_TASK_MAIN_LOOP_SLEEP', N'REQUEST_FOR_DEADLOCK_SEARCH',
		N'RESOURCE_QUEUE', N'SERVER_IDLE_CHECK', N'SLEEP_BPOOL_FLUSH', N'SLEEP_DBSTARTUP',
		N'SLEEP_DCOMSTARTUP', N'SLEEP_MASTERDBREADY', N'SLEEP_MASTERMDREADY',
        N'SLEEP_MASTERUPGRADED', N'SLEEP_MSDBSTARTUP', N'SLEEP_SYSTEMTASK', N'SLEEP_TASK',
        N'SLEEP_TEMPDBSTARTUP', N'SNI_HTTP_ACCEPT', N'SP_SERVER_DIAGNOSTICS_SLEEP',
		N'SQLTRACE_BUFFER_FLUSH', N'SQLTRACE_INCREMENTAL_FLUSH_SLEEP', N'SQLTRACE_WAIT_ENTRIES',
		N'WAIT_FOR_RESULTS', N'WAITFOR', N'WAITFOR_TASKSHUTDOWN', N'WAIT_XTP_HOST_WAIT',
		N'WAIT_XTP_OFFLINE_CKPT_NEW_LOG', N'WAIT_XTP_CKPT_CLOSE', N'WAIT_XTP_RECOVERY',
		N'XE_BUFFERMGR_ALLPROCESSED_EVENT', N'XE_DISPATCHER_JOIN',
        N'XE_DISPATCHER_WAIT', N'XE_LIVE_TARGET_TVF', N'XE_TIMER_EVENT')
order by map_key;
go


/* Create event session with "Exclusive" filter. */
create event session WSExclude on server
add event sqlos.wait_info (  
	/* What else do we want to output? */
	action ( 
		sqlserver.database_name, 
		sqlserver.username, 
		sqlserver.client_app_name
		)
	/* Here's where we filter stuff. Just a WHERE clause. */
	where sqlserver.is_system = 0
	  and opcode = 1 
	  and (
		  (wait_type <> 100) /* SLEEP_BPOOL_FLUSH */
	  and (wait_type <> 101) /* CHKPT */
	  and (wait_type <> 102) /* SLEEP_DBSTARTUP */
	  and (wait_type <> 103) /* SLEEP_MASTERMDREADY */
	  and (wait_type <> 104) /* SLEEP_MASTERUPGRADED */
	  and (wait_type <> 105) /* SLEEP_MASTERDBREADY */
	  and (wait_type <> 106) /* SLEEP_TEMPDBSTARTUP */
	  and (wait_type <> 107) /* SLEEP_DCOMSTARTUP */
	  and (wait_type <> 108) /* SLEEP_TASK */
	  and (wait_type <> 109) /* SLEEP_SYSTEMTASK */
	  and (wait_type <> 114) /* RESOURCE_QUEUE */
	  and (wait_type <> 120) /* BROKER_RECEIVE_WAITFOR */
	  and (wait_type <> 121) /* DBMIRRORING_CMD */
	  and (wait_type <> 122) /* WAIT_FOR_RESULTS */
	  and (wait_type <> 129) /* ONDEMAND_TASK_QUEUE */
	  and (wait_type <> 130) /* LOGMGR_QUEUE */
	  and (wait_type <> 131) /* REQUEST_FOR_DEADLOCK_SEARCH */
	  and (wait_type <> 132) /* CHECKPOINT_QUEUE */
	  and (wait_type <> 141) /* DBMIRROR_DBM_EVENT */
	  and (wait_type <> 143) /* DBMIRROR_EVENTS_QUEUE */
	  and (wait_type <> 144) /* DBMIRROR_WORKER_QUEUE */
	  and (wait_type <> 160) /* KSOURCE_WAKEUP */
	  and (wait_type <> 163) /* SQLTRACE_WAIT_ENTRIES */
	  and (wait_type <> 165) /* SQLTRACE_INCREMENTAL_FLUSH_SLEEP */
	  and (wait_type <> 172) /* BROKER_TRANSMITTER */
	  and (wait_type <> 177) /* BROKER_EVENTHANDLER */
	  and (wait_type <> 202) /* WAITFOR */
	  and (wait_type <> 204) /* EXECSYNC */
	  and (wait_type <> 218) /* SLEEP_MSDBSTARTUP */
	  and (wait_type <> 230) /* CLR_SEMAPHORE */
	  and (wait_type <> 231) /* CLR_MANUAL_EVENT */
	  and (wait_type <> 232) /* CLR_AUTO_EVENT */
	  and (wait_type <> 382) /* FSAGENT */
	  and (wait_type <> 393) /* DISPATCHER_QUEUE_SEMAPHORE */
	  and (wait_type <> 404) /* XE_BUFFERMGR_ALLPROCESSED_EVENT */
	  and (wait_type <> 405) /* XE_DISPATCHER_JOIN */
	  and (wait_type <> 407) /* XE_TIMER_EVENT */
	  and (wait_type <> 409) /* XE_DISPATCHER_WAIT */
	  and (wait_type <> 413) /* BROKER_TO_FLUSH */
	  and (wait_type <> 427) /* PREEMPTIVE_OS_GENERICOPS */
	  and (wait_type <> 428) /* PREEMPTIVE_OS_AUTHENTICATIONOPS */
	  and (wait_type <> 450) /* PREEMPTIVE_OS_COMOPS */
	  and (wait_type <> 484) /* PREEMPTIVE_OS_CRYPTOPS */
	  and (wait_type <> 487) /* PREEMPTIVE_OS_DEVICEOPS */
	  and (wait_type <> 506) /* PREEMPTIVE_OS_FILEOPS */
	  and (wait_type <> 529) /* PREEMPTIVE_OS_WRITEFILE */
	  and (wait_type <> 531) /* PREEMPTIVE_OS_LIBRARYOPS */
	  and (wait_type <> 550) /* PREEMPTIVE_OS_PIPEOPS */
	  and (wait_type <> 563) /* PREEMPTIVE_OS_QUERYREGISTRY */
	  and (wait_type <> 604) /* PREEMPTIVE_XE_CALLBACKEXECUTE */
	  and (wait_type <> 605) /* PREEMPTIVE_XE_DISPATCHER */
	  and (wait_type <> 607) /* PREEMPTIVE_XE_GETTARGETSTATE */
	  and (wait_type <> 608) /* PREEMPTIVE_XE_SESSIONCOMMIT */
	  and (wait_type <> 609) /* PREEMPTIVE_XE_TARGETFINALIZE */
	  and (wait_type <> 610) /* PREEMPTIVE_XE_TARGETINIT */
	  and (wait_type <> 653) /* FT_IFTSHC_MUTEX */
	  and (wait_type <> 757) /* XE_LIVE_TARGET_TVF */
	  and (wait_type <> 758) /* PREEMPTIVE_SP_SERVER_DIAGNOSTICS */
	  and (wait_type <> 759) /* SP_SERVER_DIAGNOSTICS_SLEEP */
	  and (wait_type <> 781) /* HADR_CLUSAPI_CALL */
	  and (wait_type <> 789) /* HADR_WORK_QUEUE */
	  and (wait_type <> 821) /* DIRTY_PAGE_POLL */
	  and (wait_type <> 866) /* HADR_NOTIFICATION_DEQUEUE */
	  and (wait_type <> 884) /* HADR_LOGCAPTURE_WAIT */
	  and (wait_type <> 893) /* PREEMPTIVE_HADR_LEASE_MECHANISM */
	  and (wait_type <> 894) /* HADR_TIMER_TASK */
	  and (wait_type <> 1006) /* QDS_PERSIST_TASK_MAIN_LOOP_SLEEP */
	  and (wait_type <> 1041) /* QDS_CLEANUP_STALE_QUERIES_TASK_MAIN_LOOP_SLEEP */
	  and (wait_type <> 1055) /* PREEMPTIVE_OS_VERIFYTRUST */
	  and (wait_type <> 1100) /* MEMORY_ALLOCATION_EXT */
	  and (wait_type <> 1102) /* QDS_ASYNC_QUEUE */	)
	  )
add target package0.event_file (
	set filename = 'C:\SQL\Scripts\xe_targets\WSExclude.xel'
	); 
go 


/* Start sessions. */
alter event session WSInclude on server
state = start;
go 

alter event session WSExclude on server
state = start;
go


/* Run workloads. 
	* Order Insert: 10 threads. 
	* Insert Main: 2x, 10 threads, 100 rows, on disk. 	
*/


/* Stop sessions. */
alter event session WSInclude on server
state = stop;
go 

alter event session WSExclude on server
state = stop;
go

/* Create temp table and import data. Include first. */
create table #wstempi(
	id int identity(1,1) not null, 
	rowdata xml not null
);
go 

insert into #wstempi(rowdata)
select convert(xml,event_data) 
from sys.fn_xe_file_target_read_file(
	'C:\SQL\Scripts\xe_targets\WSInclude*.xel', 
	 null, null, null)
;
go

select 
	 rowdata.value ('(/event/@timestamp)[1]', 'DATETIME') AS [DTime]
	,rowdata.value ('(/event/action[@name = ''database_name'']/value)[1]','varchar(32)') as DBName
	,rowdata.value ('(/event/action[@name = ''username'']/value)[1]','varchar(64)') as UserName
	,rowdata.value ('(/event/action[@name = ''client_app_name'']/value)[1]','varchar(64)') as AppName
	,rowdata.value ('(/event/data[@name = ''wait_type'']/text)[1]','varchar(128)') as wait_type
	,rowdata.value ('(/event/data[@name = ''duration'']/value)[1]','int') as total_wait
	,rowdata.value ('(/event/data[@name = ''signal_duration'']/value)[1]','int') as signal_wait
into #wsoutputi
from #wstempi
go 

/* Now import and parse the exclude data. */
create table #wstempe(
	id int identity(1,1) not null, 
	rowdata xml not null
);
go 

insert into #wstempe(rowdata)
select convert(xml,event_data) 
from sys.fn_xe_file_target_read_file(
	'C:\SQL\Scripts\xe_targets\WSExclude*.xel', 
	 null, null, null)
;
go

select 
	 rowdata.value ('(/event/@timestamp)[1]', 'DATETIME') AS [DTime]
	,rowdata.value ('(/event/action[@name = ''database_name'']/value)[1]','varchar(32)') as DBName
	,rowdata.value ('(/event/action[@name = ''username'']/value)[1]','varchar(64)') as UserName
	,rowdata.value ('(/event/action[@name = ''client_app_name'']/value)[1]','varchar(64)') as AppName
	,rowdata.value ('(/event/data[@name = ''wait_type'']/text)[1]','varchar(128)') as wait_type
	,rowdata.value ('(/event/data[@name = ''duration'']/value)[1]','int') as total_wait
	,rowdata.value ('(/event/data[@name = ''signal_duration'']/value)[1]','int') as signal_wait
into #wsoutpute
from #wstempe
go 

/* A quick look at the top waits from each table, 
	to decide which table to use. 
*/
select count(*) as Include_Filter from #wsoutputi
select count(*) as Exclude_Filter from #wsoutpute
go 


with 
includedwaits as ( 
select wait_type, sum(total_wait) as wait_total_ms 
from #wsoutputi 
group by wait_type
), 
excludedwaits as (
select wait_type, sum(total_wait) as wait_total_ms 
from #wsoutpute 
group by wait_type
) 
select 
	e.wait_type,
	e.wait_total_ms as excl_waits_total,
	i.wait_total_ms as incl_waits_total
from excludedwaits e
left outer join includedwaits i
	on e.wait_type = i.wait_type
order by e.wait_total_ms desc;
go

/* The exclusion filter seems be better, as it caught a few
   extra waits that the inclusion filter did not. */
/* Breakdown By Database */
select
	DBName, 
	wait_type, 
	sum(total_wait) AS TotalWait, 
	sum(signal_wait) as SignalWait, 
	sum(total_wait) - sum(signal_wait) as ResourceWait,
	PctResourceWait = cast(((sum(total_wait) - sum(signal_wait)) / sum(total_wait * 1.0)) as decimal(5,2))
from #wsoutpute
where total_wait <> 0
group by DBName, wait_type
order by TotalWait desc;
go


/* Breakdown By Application Name for most resource consuming DB */
select
	DBName,
	AppName, 
	wait_type, 
	sum(total_wait) AS TotalWait, 
	sum(signal_wait) as SignalWait, 
	sum(total_wait) - sum(signal_wait) as ResourceWait,
	PctResourceWait = cast(((sum(total_wait) - sum(signal_wait)) / sum(total_wait * 1.0)) as decimal(5,2))
from #wsoutpute
where total_wait <> 0
group by DBName, AppName, wait_type
order by TotalWait desc;
go

/* Breakdown By DB and Username */
select
	DBName,
	UserName, 
	wait_type, 
	sum(total_wait) AS TotalWait, 
	sum(signal_wait) as SignalWait, 
	sum(total_wait) - sum(signal_wait) as ResourceWait,
	PctResourceWait = cast(((sum(total_wait) - sum(signal_wait)) / sum(total_wait * 1.0)) as decimal(5,2))
from #wsoutpute
where total_wait <> 0
group by DBName, UserName, wait_type
order by TotalWait desc;
go

/* Clean Up. */

drop event session WSInclude on server;
drop event session WSExclude on server;
go
