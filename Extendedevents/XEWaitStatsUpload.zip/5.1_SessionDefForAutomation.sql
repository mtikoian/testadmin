/***************************************************************
  Name: 5.1_SessionDefForAutomation.sql
  Project/Ticket#: Summit 2017
  Date: October 2017
  Requester: PASS
  DBA: David M Maxwell
  Step: 5.1 of 5.2
  Server: USLTMAXWELL
  Notes: This script is the XE session definition required for 
  the automation demo. Run the appropriate PowerShell script 
  to use this definition across multiple instances. 
***************************************************************/

set nocount on;

use [master]; 
go 


/* Create XE Session to captre waits and completed SQL statements. */
create event session WSQuickCapture on server
add event sqlos.wait_info (  
	action ( 
		sqlserver.server_instance_name, 
		sqlserver.database_name, 
		sqlserver.username, 
		sqlserver.client_app_name, 
		sqlserver.session_id
		)
	where sqlserver.is_system = 0
	  and opcode = 1 
	  and (
		  (wait_type <> 100) /* SLEEP_BPOOL_FLUSH */
	  and (wait_type <> 101) /* CHKPT */
	  and (wait_type <> 102) /* SLEEP_DBSTARTUP */
	  and (wait_type <> 103) /* SLEEP_MASTERMDREADY */
	  and (wait_type <> 104) /* SLEEP_MASTERUPGRADED */
	  and (wait_type <> 105) /* SLEEP_MASTERDBREADY */
	  and (wait_type <> 106) /* SLEEP_TEMPDBSTARTUP */
	  and (wait_type <> 107) /* SLEEP_DCOMSTARTUP */
	  and (wait_type <> 108) /* SLEEP_TASK */
	  and (wait_type <> 109) /* SLEEP_SYSTEMTASK */
	  and (wait_type <> 114) /* RESOURCE_QUEUE */
	  and (wait_type <> 120) /* BROKER_RECEIVE_WAITFOR */
	  and (wait_type <> 121) /* DBMIRRORING_CMD */
	  and (wait_type <> 122) /* WAIT_FOR_RESULTS */
	  and (wait_type <> 129) /* ONDEMAND_TASK_QUEUE */
	  and (wait_type <> 130) /* LOGMGR_QUEUE */
	  and (wait_type <> 131) /* REQUEST_FOR_DEADLOCK_SEARCH */
	  and (wait_type <> 132) /* CHECKPOINT_QUEUE */
	  and (wait_type <> 141) /* DBMIRROR_DBM_EVENT */
	  and (wait_type <> 143) /* DBMIRROR_EVENTS_QUEUE */
	  and (wait_type <> 144) /* DBMIRROR_WORKER_QUEUE */
	  and (wait_type <> 160) /* KSOURCE_WAKEUP */
	  and (wait_type <> 163) /* SQLTRACE_WAIT_ENTRIES */
	  and (wait_type <> 165) /* SQLTRACE_INCREMENTAL_FLUSH_SLEEP */
	  and (wait_type <> 172) /* BROKER_TRANSMITTER */
	  and (wait_type <> 177) /* BROKER_EVENTHANDLER */
	  and (wait_type <> 202) /* WAITFOR */
	  and (wait_type <> 204) /* EXECSYNC */
	  and (wait_type <> 218) /* SLEEP_MSDBSTARTUP */
	  and (wait_type <> 230) /* CLR_SEMAPHORE */
	  and (wait_type <> 231) /* CLR_MANUAL_EVENT */
	  and (wait_type <> 232) /* CLR_AUTO_EVENT */
	  and (wait_type <> 382) /* FSAGENT */
	  and (wait_type <> 393) /* DISPATCHER_QUEUE_SEMAPHORE */
	  and (wait_type <> 404) /* XE_BUFFERMGR_ALLPROCESSED_EVENT */
	  and (wait_type <> 405) /* XE_DISPATCHER_JOIN */
	  and (wait_type <> 407) /* XE_TIMER_EVENT */
	  and (wait_type <> 409) /* XE_DISPATCHER_WAIT */
	  and (wait_type <> 413) /* BROKER_TO_FLUSH */
	  and (wait_type <> 427) /* PREEMPTIVE_OS_GENERICOPS */
	  and (wait_type <> 428) /* PREEMPTIVE_OS_AUTHENTICATIONOPS */
	  and (wait_type <> 450) /* PREEMPTIVE_OS_COMOPS */
	  and (wait_type <> 484) /* PREEMPTIVE_OS_CRYPTOPS */
	  and (wait_type <> 487) /* PREEMPTIVE_OS_DEVICEOPS */
	  and (wait_type <> 506) /* PREEMPTIVE_OS_FILEOPS */
	  and (wait_type <> 529) /* PREEMPTIVE_OS_WRITEFILE */
	  and (wait_type <> 531) /* PREEMPTIVE_OS_LIBRARYOPS */
	  and (wait_type <> 550) /* PREEMPTIVE_OS_PIPEOPS */
	  and (wait_type <> 563) /* PREEMPTIVE_OS_QUERYREGISTRY */
	  and (wait_type <> 604) /* PREEMPTIVE_XE_CALLBACKEXECUTE */
	  and (wait_type <> 605) /* PREEMPTIVE_XE_DISPATCHER */
	  and (wait_type <> 607) /* PREEMPTIVE_XE_GETTARGETSTATE */
	  and (wait_type <> 608) /* PREEMPTIVE_XE_SESSIONCOMMIT */
	  and (wait_type <> 609) /* PREEMPTIVE_XE_TARGETFINALIZE */
	  and (wait_type <> 610) /* PREEMPTIVE_XE_TARGETINIT */
	  and (wait_type <> 653) /* FT_IFTSHC_MUTEX */
	  and (wait_type <> 757) /* XE_LIVE_TARGET_TVF */
	  and (wait_type <> 758) /* PREEMPTIVE_SP_SERVER_DIAGNOSTICS */
	  and (wait_type <> 759) /* SP_SERVER_DIAGNOSTICS_SLEEP */
	  and (wait_type <> 781) /* HADR_CLUSAPI_CALL */
	  and (wait_type <> 789) /* HADR_WORK_QUEUE */
	  and (wait_type <> 821) /* DIRTY_PAGE_POLL */
	  and (wait_type <> 866) /* HADR_NOTIFICATION_DEQUEUE */
	  and (wait_type <> 884) /* HADR_LOGCAPTURE_WAIT */
	  and (wait_type <> 893) /* PREEMPTIVE_HADR_LEASE_MECHANISM */
	  and (wait_type <> 894) /* HADR_TIMER_TASK */
	  and (wait_type <> 1006) /* QDS_PERSIST_TASK_MAIN_LOOP_SLEEP */
	  and (wait_type <> 1041) /* QDS_CLEANUP_STALE_QUERIES_TASK_MAIN_LOOP_SLEEP */
	  and (wait_type <> 1055) /* PREEMPTIVE_OS_VERIFYTRUST */
	  and (wait_type <> 1100) /* MEMORY_ALLOCATION_EXT */
	  and (wait_type <> 1102) /* QDS_ASYNC_QUEUE */	)
	  ),
add event  sqlserver.sql_statement_completed (
	action(sqlserver.server_instance_name, 
		sqlserver.database_name, 
		sqlserver.username, 
		sqlserver.client_app_name, 
		sqlserver.session_id)
	where  (sqlserver.is_system = 0)
	  )
add target package0.event_file (
	set filename = 'C:\SQL\Scripts\xe_targets\WSQuickCapture.xel'
	); 
go 

/* Start session... */
alter event session WSQuickCapture on server
state = start;
go 

