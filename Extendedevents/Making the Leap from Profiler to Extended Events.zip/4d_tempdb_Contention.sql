/*============================================================================
  File:     4d_tempdb_Contention.sql

  SQL Server Versions: 2012 onwards
------------------------------------------------------------------------------
  Written by Erin Stellato, SQLskills.com
  
  (c) 2013, SQLskills.com. All rights reserved.

  For more scripts and sample code, check out 
    http://www.SQLskills.com

  You may alter this code for your own *non-commercial* purposes. You may
  republish altered code as long as you include this copyright and give due
  credit, but you must obtain prior permission before blogging this code.
  
  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
  TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
  PARTICULAR PURPOSE.
============================================================================*/


DBCC TRACEON (3604);
GO

DBCC PAGE (tempdb, 1, 1, 3)
DBCC PAGE (tempdb, 1, 8088, 3)

DBCC PAGE(tempdb, 1, 24264, 3)

SELECT 24264/8088
SELECT 48528/8088

USE [tempdb];
GO

SELECT * FROM [tempdb].[sys].[database_files];

ALTER DATABASE [tempdb] 
	ADD FILE ( 
		NAME = N'tempdev2', 
		FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL11.SQL2012\MSSQL\DATA\tempdb2.ndf' , 
		SIZE = 8192KB , 
		FILEGROWTH = 512MB),
	( 
		NAME = N'tempdev3', 
		FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL11.SQL2012\MSSQL\DATA\tempdb3.ndf' , 
		SIZE = 8192KB , 
		FILEGROWTH = 512MB),
	( 
		NAME = N'tempdev4', 
		FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL11.SQL2012\MSSQL\DATA\tempdb4.ndf' , 
		SIZE = 8192KB , 
		FILEGROWTH = 512MB);
GO

SELECT * FROM [tempdb].[sys].[database_files];


USE [tempdb];
GO
DBCC SHRINKFILE('tempdev2', EMPTYFILE);
GO
DBCC SHRINKFILE('tempdev3', EMPTYFILE);
GO
DBCC SHRINKFILE('tempdev4', EMPTYFILE);
GO
USE [master];
GO
ALTER DATABASE [tempdb] REMOVE FILE tempdev2; 
GO
ALTER DATABASE [tempdb] REMOVE FILE tempdev3; 
GO
ALTER DATABASE [tempdb] REMOVE FILE tempdev4; 
GO


SELECT * FROM [tempdb].[sys].[database_files];