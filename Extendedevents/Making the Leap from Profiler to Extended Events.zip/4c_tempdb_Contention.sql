/*============================================================================
  File:     4c_tempdb_Contention.sql

  SQL Server Versions: 2012 onwards
------------------------------------------------------------------------------
  Written by Jonathan M. Kehayias, SQLskills.com
  
  (c) 2013, SQLskills.com. All rights reserved.

  For more scripts and sample code, check out 
    http://www.SQLskills.com

  You may alter this code for your own *non-commercial* purposes. You may
  republish altered code as long as you include this copyright and give due
  credit, but you must obtain prior permission before blogging this code.
  
  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
  TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
  PARTICULAR PURPOSE.
============================================================================*/

SELECT
   n.value('(value)[1]', 'bigint') AS page_id,
   n.value('(@count)[1]', 'bigint') AS wait_count
FROM
(  SELECT CAST(target_data AS XML) target_data
   FROM sys.dm_xe_sessions AS s
   INNER JOIN sys.dm_xe_session_targets AS t
       ON s.address = t.event_session_address
   WHERE s.name = N'SQLskills_MonitorTempdbContention'
   AND t.target_name = N'histogram' ) AS tab
CROSS APPLY target_data.nodes('HistogramTarget/Slot') AS q(n); 
