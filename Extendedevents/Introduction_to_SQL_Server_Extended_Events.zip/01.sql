use [WideWorldImporters]


-- Run this query few times while trace is running

select c.CustomerID, c.CustomerName, [Website].[CalculateCustomerPrice](c.CustomerID, 226, GETDATE()) as CustomerPrice
from Sales.Customers c
where c.DeliveryPostalCode = N'90683'


-- Stop the trace
exec sp_trace_setstatus 2, 0 -- Status: 0 - Stop, 1 - Start, 2 - Delete

-- View all traces
select * from sys.traces

exec sp_SQLskills_ConvertTraceToExtendedEvents 2, 'SqlSaturday538Demo1'



