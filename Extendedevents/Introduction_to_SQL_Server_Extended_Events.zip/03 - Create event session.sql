IF EXISTS (SELECT 1 FROM sys.server_event_sessions WHERE name = 'SqlSaturday538Demo1')
	DROP EVENT SESSION [SqlSaturday538Demo1] ON SERVER;
GO
CREATE EVENT SESSION [SqlSaturday538Demo1]
ON SERVER
ADD EVENT sqlserver.query_post_execution_showplan(
	ACTION 
	(
			  sqlserver.client_app_name	-- ApplicationName from SQLTrace
			, sqlserver.client_hostname	-- HostName from SQLTrace
			, sqlserver.client_pid	-- ClientProcessID from SQLTrace
			, sqlserver.database_id	-- DatabaseID from SQLTrace
			, package0.event_sequence	-- EventSequence from SQLTrace
			, sqlserver.is_system	-- IsSystem from SQLTrace
			, sqlserver.nt_username	-- NTDomainName from SQLTrace
			, sqlserver.request_id	-- RequestID from SQLTrace
			, sqlserver.server_instance_name	-- ServerName from SQLTrace
			, sqlserver.server_principal_name	-- LoginName from SQLTrace
			, sqlserver.server_principal_sid	-- LoginSid from SQLTrace
			, sqlserver.session_id	-- SPID from SQLTrace
			, sqlserver.session_resource_group_id	-- GroupID from SQLTrace
			, sqlserver.session_server_principal_name	-- SessionLoginName from SQLTrace
			, sqlserver.transaction_id	-- TransactionID from SQLTrace
			, sqlserver.transaction_sequence	-- XactSequence from SQLTrace
			, sqlserver.tsql_frame	-- LineNumber from SQLTrace
	)
),
ADD EVENT sqlserver.sql_statement_completed(
	ACTION 
	(
			  sqlserver.client_app_name	-- ApplicationName from SQLTrace
			, sqlserver.client_hostname	-- HostName from SQLTrace
			, sqlserver.client_pid	-- ClientProcessID from SQLTrace
			, sqlserver.database_id	-- DatabaseID from SQLTrace
			, sqlserver.database_name	-- DatabaseName from SQLTrace
			, package0.event_sequence	-- EventSequence from SQLTrace
			, sqlserver.is_system	-- IsSystem from SQLTrace
			, sqlserver.nt_username	-- NTUserName from SQLTrace
			, sqlserver.nt_username	-- NTDomainName from SQLTrace
			, sqlserver.request_id	-- RequestID from SQLTrace
			, sqlserver.server_instance_name	-- ServerName from SQLTrace
			, sqlserver.server_principal_name	-- LoginName from SQLTrace
			, sqlserver.server_principal_sid	-- LoginSid from SQLTrace
			, sqlserver.session_id	-- SPID from SQLTrace
			, sqlserver.session_resource_group_id	-- GroupID from SQLTrace
			, sqlserver.session_server_principal_name	-- SessionLoginName from SQLTrace
			, sqlserver.transaction_id	-- TransactionID from SQLTrace
			, sqlserver.transaction_sequence	-- XactSequence from SQLTrace
			, sqlserver.tsql_frame	-- LineNumber from SQLTrace
			, sqlserver.tsql_stack	-- NestLevel from SQLTrace
	)
	WHERE 
	(
			logical_reads >= 50
	)
)
ADD TARGET package0.event_file
(
	SET filename = 'D:\SQLSat538\SqlSaturday538Demo1.xel',
		max_file_size = 5,
		max_rollover_files = 1
)
