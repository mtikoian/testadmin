use [WideWorldImporters]


IF EXISTS(SELECT * FROM sys.server_event_sessions WHERE name='Merged Columns')  
	DROP EVENT session [Merged Columns]
	ON SERVER 
GO  

CREATE EVENT SESSION [Merged Columns]
ON SERVER 
ADD EVENT sqlserver.sql_batch_completed,
ADD EVENT sqlserver.sql_statement_completed
ADD TARGET package0.event_file
(
	SET filename = 'D:\SQLSat538\Merged Columns.xel',
		max_file_size = 5,
		max_rollover_files = 1
)
WITH (TRACK_CAUSALITY=ON)
GO


ALTER EVENT SESSION [Merged Columns]
ON SERVER
STATE = START


-- Execute these few times

select StockItemName, UnitPrice, [Website].[CalculateCustomerPrice](1060, StockItemID, '20161015') as CustomerPrice
from Warehouse.StockItems



ALTER EVENT SESSION [Merged Columns]
ON SERVER
STATE = STOP

DROP EVENT SESSION [Merged Columns]
ON SERVER
GO


