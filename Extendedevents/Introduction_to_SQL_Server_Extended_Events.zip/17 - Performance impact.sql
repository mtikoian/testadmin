use [WideWorldImporters]
set nocount on

-- Show SQLServer:SQL Statistics -> Batch requests per second performance counter
-- Run Histogram target session and then SqlSaturday538Demo1 session

update Sales.SpecialDeals set UnitPrice = null where SpecialDealID is null
go 10000000