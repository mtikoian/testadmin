use [WideWorldImporters]
GO

/*********************************************************************************************************************

Execute following queries in a new window and set Execution timeout to 1 second from Query -> Query Options dialog.
Get session_id of this window and update the predicate in create event session statement.

-- Light query
select CustomerName
from Sales.Customers
where CustomerID = 1060

-- Heavy query
waitfor delay '0:00:02'

*********************************************************************************************************************/



SELECT  --C.6
        p.name        AS [Package],
        o.name        AS [Target],
        c.name        AS [Parameter],
        c.type_name   AS [Parameter-Type],

        CASE c.capabilities_desc
            WHEN 'mandatory' THEN 'YES_Mandatory'
            ELSE 'Not_mandatory'
        END  AS [IsMandatoryYN],

        c.description AS [Parameter-Description],
		c.type_name
    FROM
              sys.dm_xe_objects   AS o
        JOIN  sys.dm_xe_packages  AS p

            ON  o.package_guid = p.guid

        LEFT OUTER JOIN  sys.dm_xe_object_columns  AS c

            ON  o.name        = c.object_name
            AND c.column_type = 'customizable'  -- !
    WHERE
        o.object_type = 'target'
        AND
        o.name     = 'pair_matching'    -- Target name here
    ORDER BY
        [Package],
        [Target],
        [IsMandatoryYN]  DESC,
        [Parameter];
GO



CREATE EVENT SESSION [Catch Query Timeouts]
ON SERVER
ADD EVENT sqlserver.sql_statement_starting
(
    ACTION(sqlserver.session_id, sqlserver.tsql_stack)
	WHERE (session_id = 55)
),
ADD EVENT sqlserver.sql_statement_completed
(
    ACTION(sqlserver.session_id, sqlserver.tsql_stack)
	WHERE (session_id = 55)
)
ADD TARGET package0.pair_matching
(
    SET begin_event = 'sqlserver.sql_statement_starting',
        begin_matching_actions = 'sqlserver.session_id, sqlserver.tsql_stack',
        end_event = 'sqlserver.sql_statement_completed',
        end_matching_actions = 'sqlserver.session_id, sqlserver.tsql_stack',
        respond_to_memory_pressure = 0
)
WITH (MAX_DISPATCH_LATENCY=5 SECONDS, TRACK_CAUSALITY=ON)
GO


ALTER EVENT SESSION [Catch Query Timeouts]
ON SERVER
STATE=START
GO


-- Create XML variable to hold Target Data
DECLARE @target_data XML
SELECT @target_data = 
    CAST(target_data AS XML)
FROM sys.dm_xe_sessions AS s 
JOIN sys.dm_xe_session_targets AS t 
    ON t.event_session_address = s.address
WHERE s.name = 'Catch Query Timeouts'
  AND t.target_name = 'pair_matching'

select @target_data

-- Query XML variable to get Target Execution information
SELECT 
    @target_data.value('(PairingTarget/@orphanCount)[1]', 'int') AS orphanCount,
    @target_data.value('(PairingTarget/@matchedCount)[1]', 'int') AS matchedCount,
    @target_data.value('(PairingTarget/@memoryPressureDroppedCount)[1]', 'int') AS memoryPressureDroppedCount

-- Query the XML variable to get the Target Data
SELECT 
    n.value('(event/@name)[1]', 'varchar(50)') AS event_name,
    n.value('(event/@package)[1]', 'varchar(50)') AS package_name,
    n.value('(event/@id)[1]', 'int') AS id,
    n.value('(event/@version)[1]', 'int') AS version,
    n.value('(event/@timestamp)[1]', 'datetime2') AS utc_timestamp,
    n.value('(event/data[@name="source_database_id"]/value)[1]', 'int') as [source_database_id],
    n.value('(event/data[@name="object_id"]/value)[1]', 'int') as [object_id],
    n.value('(event/data[@name="object_type"]/value)[1]', 'varchar(60)') as [object_type],
    n.value('(event/data[@name="state"]/text)[1]', 'varchar(50)') as [state],
    n.value('(event/data[@name="offset"]/value)[1]', 'int') as [offset],
    n.value('(event/data[@name="offset_end"]/value)[1]', 'int') as [offset_end],
    n.value('(event/data[@name="nest_level"]/value)[1]', 'int') as [nest_level],
    n.value('(event/data[@name="statement"]/value)[1]', 'nvarchar(max)') as statement,
    n.value('(event/action[@name="session_id"]/value)[1]', 'int') as session_id,
    n.value('(event/action[@name="attach_activity_id"]/value)[1]', 'varchar(50)') as activity_id    
FROM
(    SELECT td.query('.') as n
FROM @target_data.nodes('PairingTarget/event') AS q(td)
) as tab
ORDER BY session_id, activity_id
GO




ALTER EVENT SESSION [Catch Query Timeouts]
ON SERVER
STATE=STOP
GO

DROP EVENT SESSION [Catch Query Timeouts]
ON SERVER
GO

