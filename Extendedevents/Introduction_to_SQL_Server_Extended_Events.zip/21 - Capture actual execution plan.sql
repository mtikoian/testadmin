use [WideWorldImporters]

-- Get list of fields (optional filters for event)
-- Note which of them are part of the default payload
SELECT  -- C.4
        p.name         AS [Package],
        c.object_name  AS [Event],
        c.name         AS [Column-for-Predicate-Data],
        c.description  AS [Column-Description],
		case c.column_type
			when 'readonly' then 'Descriptor column'
			when 'data' then 'Default payload'
			when 'customizable' then 'Customizable column' -- These columns are collected similar to actions in the event session and have an added expense to the data collection. Because the cost to collect this data could affect performance, it is only collected when specified explicitly as a part of the event definition in the session.
			else 'Other - ' + c.column_type
		end as [Column-Type],
		c.type_name
    FROM
              sys.dm_xe_object_columns  AS c
        JOIN  sys.dm_xe_objects         AS o

            ON  o.name = c.object_name

        JOIN  sys.dm_xe_packages        AS p

            ON  p.guid = o.package_guid
    WHERE
        c.column_type in ('readonly', 'data', 'customizable')
        AND
        o.object_type = 'event'
        AND
        o.name        = 'query_post_execution_showplan'  -- Event name here
    ORDER BY
        [Package],
        [Event],
        [Column-for-Predicate-Data];
GO





CREATE EVENT SESSION [Capture Actual Execution Plan]
ON SERVER
ADD EVENT sqlserver.query_post_execution_showplan
-- In real life we should add some filters
--(
--	SET collect_database_name=(1)
--	WHERE 
--	(
--			source_database_id = 5 and package0.greater_than_max_int64(duration, 5000)
--	)
--)
ADD TARGET package0.event_file
(
	set filename = 'D:\SQLSat538\Capture Actual Execution Plan.xel',
		max_file_size = 5,
		max_rollover_files = 1
)


ALTER EVENT SESSION [Capture Actual Execution Plan]
ON SERVER
STATE = START
GO


select o.OrderDate, si.StockItemName, ol.Quantity
from Sales.Orders o
inner join Sales.OrderLines ol on ol.OrderID = o.OrderID
inner join Warehouse.StockItems si on si.StockItemID = ol.StockItemID
where o.CustomerID = 1060
order by o.OrderDate, si.StockItemName
GO


ALTER EVENT SESSION [Capture Actual Execution Plan]
ON SERVER
STATE = STOP
GO


DROP EVENT SESSION [Capture Actual Execution Plan]
ON SERVER
GO


select cast(event_data as XML) as event_data
from sys.fn_xe_file_target_read_file('D:\SQLSat538\Capture Actual Execution Plan*.xel', null, null, null)




select
	n.value('(@name)[1]', 'varchar(50)') as event_name,
    n.value('(@package)[1]', 'varchar(50)') AS package_name,
    n.value('(@timestamp)[1]', 'datetime2') AS [utc_timestamp],
    n.value('(data[@name="source_database_id"]/value)[1]', 'int') as source_database_id,
    n.value('(data[@name="object_type"]/value)[1]', 'int') as object_type_value,
    n.value('(data[@name="object_type"]/text)[1]', 'nvarchar(128)') as object_type_text,
    n.value('(data[@name="object_id"]/value)[1]', 'int') as object_id,
    n.value('(data[@name="nest_level"]/value)[1]', 'int') as nest_level,
    n.value('(data[@name="cpu_time"]/value)[1]', 'int') as cpu,
    n.value('(data[@name="duration"]/value)[1]', 'int') as duration,
    n.value('(data[@name="estimated_rows"]/value)[1]', 'int') as estimated_rows,
    n.value('(data[@name="estimated_cost"]/value)[1]', 'int') as estimated_cost,
    n.value('(data[@name="serial_ideal_memory_kb"]/value)[1]', 'int') as serial_ideal_memory_kb,
    n.value('(data[@name="requested_memory_kb"]/value)[1]', 'int') as requested_memory_kb,
    n.value('(data[@name="used_memory_kb"]/value)[1]', 'int') as used_memory_kb,
    n.value('(data[@name="ideal_memory_kb"]/value)[1]', 'int') as ideal_memory_kb,
    n.value('(data[@name="granted_memory_kb"]/value)[1]', 'int') as granted_memory_kb,
    n.value('(data[@name="dop"]/value)[1]', 'int') as dop,
    n.value('(data[@name="object_name"]/value)[1]', 'nvarchar(128)') as object_name,
	n.value('(data[@name="showplan_xml"]/value)[1]', 'nvarchar(max)') as showplan_xml, -- empty
	n.query('(data[@name="showplan_xml"]/value)[1]') as showplan_xml2, -- unwanted value node
	sp.n2.query('.') as showplan_xml3,
	n.value('(data[@name="database_name"]/value)[1]', 'nvarchar(128)') as database_name
from (select cast(event_data as XML) as event_data
from sys.fn_xe_file_target_read_file('D:\SQLSat538\Capture Actual Execution Plan*.xel', null, null, null)) ed
cross apply ed.event_data.nodes('event') as q(n)
cross apply ed.event_data.nodes('/event/data[@name="showplan_xml"]/value/*') as sp(n2)
GO