use [master]  

CREATE EVENT SESSION [Parse XML]
ON SERVER 
ADD EVENT sqlserver.sql_statement_completed
(
	ACTION (sqlserver.database_name)
)
ADD TARGET package0.ring_buffer,
ADD TARGET package0.event_file
(
	SET filename = 'D:\SQLSat538\ParseXML.xel',
		max_file_size = 5,
		max_rollover_files = 1
)
GO


ALTER EVENT SESSION [Parse XML]
ON SERVER
STATE = START
GO


-- Execute these few times

select * from sys.objects
GO

-- Read data from ring buffer - open XML result and keep it
DECLARE @target_data XML;
SELECT @target_data = CAST(target_data AS XML)
FROM sys.dm_xe_sessions AS s 
INNER JOIN sys.dm_xe_session_targets AS t ON t.event_session_address = s.address
WHERE s.name = N'Parse XML' and t.target_name = 'ring_buffer';
select @target_data
GO


ALTER EVENT SESSION [Parse XML]
ON SERVER
STATE = STOP
GO


-- Read data from ring buffer again
DECLARE @target_data XML;
SELECT @target_data = CAST(target_data AS XML)
FROM sys.dm_xe_sessions AS s 
INNER JOIN sys.dm_xe_session_targets AS t ON t.event_session_address = s.address
WHERE s.name = N'Parse XML' and t.target_name = 'ring_buffer';
select @target_data
GO


DROP EVENT SESSION [Parse XML]
ON SERVER
GO


-- Function does not return anything - check file name
select cast(event_data as XML) as event_data
from sys.fn_xe_file_target_read_file('D:\SQLSat538\ParseXML.xel', null, null, null)
GO


-- Selecting data as XML
select cast(event_data as XML) as event_data
from sys.fn_xe_file_target_read_file('D:\SQLSat538\ParseXML*.xel', null, null, null)
GO


-- Using SELECT * to get all data is not possible
select *
from (select cast(event_data as XML) as event_data
from sys.fn_xe_file_target_read_file('D:\SQLSat538\ParseXML*.xel', null, null, null)) ed
cross apply ed.event_data.nodes('event') as q(n)
GO


-- You have to know element names and their data types
select
	n.value('(@name)[1]', 'varchar(50)') as event_name,
    n.value('(@package)[1]', 'varchar(50)') AS package_name,
    n.value('(@timestamp)[1]', 'datetime2') AS [utc_timestamp],
    n.value('(data[@name="duration"]/value)[1]', 'int') as duration,
    n.value('(data[@name="cpu_time"]/value)[1]', 'int') as cpu,
    n.value('(data[@name="physical_reads"]/value)[1]', 'int') as physical_reads,
    n.value('(data[@name="logical_reads"]/value)[1]', 'int') as logical_reads,
    n.value('(data[@name="writes"]/value)[1]', 'int') as writes,
    n.value('(data[@name="row_count"]/value)[1]', 'int') as row_count,
    n.value('(data[@name="last_row_count"]/value)[1]', 'int') as last_row_count,
    n.value('(data[@name="line_number"]/value)[1]', 'int') as line_number,
    n.value('(data[@name="offset"]/value)[1]', 'int') as offset,
    n.value('(data[@name="offset_end"]/value)[1]', 'int') as offset_end,
	n.value('(data[@name="statement"]/value)[1]', 'nvarchar(max)') as statement,
	n.value('(action[@name="database_name"]/value)[1]', 'nvarchar(128)') as database_name
from (select cast(event_data as XML) as event_data
from sys.fn_xe_file_target_read_file('D:\SQLSat538\ParseXML*.xel', null, null, null)) ed
cross apply ed.event_data.nodes('event') as q(n)
GO





