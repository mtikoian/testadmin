use [WideWorldImporters]

DROP PROCEDURE IF EXISTS [dbo].[SelectCustomerData]
GO

CREATE PROCEDURE [dbo].[SelectCustomerData]
	@CustomerID int
AS
BEGIN
	SET NOCOUNT ON;

	select InvoiceDate, Comments, DeliveryInstructions, InternalComments
	from Sales.Invoices
	where CustomerID = @CustomerID

	select OrderDate, ExpectedDeliveryDate, CustomerPurchaseOrderNumber, Comments, DeliveryInstructions, InternalComments
	from Sales.Orders
	where CustomerID = @CustomerID

	select TransactionOccurredWhen, Quantity
	from Warehouse.StockItemTransactions
	where CustomerID = @CustomerID
END
GO

DROP EVENT SESSION IF EXISTS [Track Causality]
ON SERVER
GO

IF EXISTS(SELECT * FROM sys.server_event_sessions WHERE name='Track Causality')  
	DROP EVENT session [Track Causality]
	ON SERVER 
GO  

-- select DB_ID()
CREATE EVENT SESSION [Track Causality]
ON SERVER 
ADD EVENT sqlserver.sp_statement_completed
(
    WHERE (sqlserver.database_id = 12 AND sqlserver.is_system = 0)
),
ADD EVENT sqlserver.sql_statement_completed
(
	WHERE (sqlserver.database_id = 12 AND sqlserver.is_system = 0)
)
ADD TARGET package0.event_file
(
	SET filename = 'D:\SQLSat538\Track Causality.xel',
		max_file_size = 5,
		max_rollover_files = 1
)
WITH (TRACK_CAUSALITY=ON)
GO


ALTER EVENT SESSION [Track Causality]
ON SERVER
STATE = START


-- Execute these few times

exec [dbo].[SelectCustomerData] 1060
GO

exec [dbo].[SelectCustomerData] 831
GO



ALTER EVENT SESSION [Track Causality]
ON SERVER
STATE = STOP



-- View event data - show attach_activity_id.guid and show attach_activity_id.seq in table. Group by attach_activity_id.guid to see related events


DROP EVENT SESSION [Track Causality]
ON SERVER
GO
