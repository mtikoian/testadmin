/**************************************************************************************************************************
https://msdn.microsoft.com/en-us/library/bb677278.aspx
A package is a container for SQL Server Extended Events objects.
package0 - Extended Events system objects. This is the default package.
sqlserver - SQL Server related objects.
sqlos - SQL Server Operating System (SQLOS) related objects.
**************************************************************************************************************************/

-- Get list of packages
select *
from sys.dm_xe_packages



/**************************************************************************************************************************
A package is a container for SQL Server Extended Events objects - https://msdn.microsoft.com/en-us/library/bb677278.aspx
Events are monitoring points of interest in the execution path of a program, such as SQL Server.
An event firing carries with it the fact that the point of interest was reached, and state information from the time the event was fired.
**************************************************************************************************************************/

-- Get list of events
select p.name, o.name, o.description
from sys.dm_xe_objects o
inner join sys.dm_xe_packages p on p.guid = o.package_guid
where o.object_type = 'event'
order by p.name, o.name


-- Compare with Trace - 180 rows in each SQL Server version since 2008
select e.trace_event_id, e.name, c.name as CategoryName
from sys.trace_events e
inner join sys.trace_categories c on c.category_id = e.category_id



-- Get list of actions - Actions are not related to events. You can add any action to any event, even from different packages.
select o.name, o.description, p.name
from sys.dm_xe_objects o
inner join sys.dm_xe_packages p on p.guid = o.package_guid
where o.object_type = 'action'




-- Get list of fields (optional filters for event)
-- https://msdn.microsoft.com/en-us/library/04521d7f-588c-4259-abc2-1a2857eb05ec#section_C_4_data_fields
-- * Modified to show the default payload and column type and data type

SELECT  -- C.4
        p.name         AS [Package],
        c.object_name  AS [Event],
        c.name         AS [Column-for-Predicate-Data],
        c.description  AS [Column-Description],
		case c.column_type
			when 'readonly' then 'Descriptor column'
			when 'data' then 'Default payload'
			when 'customizable' then 'Customizable column' -- These columns are collected similar to actions in the event session and have an added expense to the data collection. Because the cost to collect this data could affect performance, it is only collected when specified explicitly as a part of the event definition in the session.
			else 'Other - ' + c.column_type
		end as [Column-Type],
		c.type_name
    FROM
              sys.dm_xe_object_columns  AS c
        JOIN  sys.dm_xe_objects         AS o

            ON  o.name = c.object_name

        JOIN  sys.dm_xe_packages        AS p

            ON  p.guid = o.package_guid
    WHERE
        c.column_type in ('readonly', 'data', 'customizable')
        AND
        o.object_type = 'event'
        AND
        o.name        = 'sql_statement_completed'  -- Event name here
    ORDER BY
        [Package],
        [Event],
        [Column-for-Predicate-Data];


-- Get list of targets
select o.name, o.description, p.name
from sys.dm_xe_objects o
inner join sys.dm_xe_packages p on p.guid = o.package_guid
where o.object_type = 'target'



-- Get list of target parameters
-- https://msdn.microsoft.com/en-us/library/mt740143.aspx#section_C_6_parameters_targets
-- * Modified to show the default payload and column data type
SELECT  --C.6
        p.name        AS [Package],
        o.name        AS [Target],
        c.name        AS [Parameter],
        c.type_name   AS [Parameter-Type],

        CASE c.capabilities_desc
            WHEN 'mandatory' THEN 'YES_Mandatory'
            ELSE 'Not_mandatory'
        END  AS [IsMandatoryYN],

        c.description AS [Parameter-Description],
		c.type_name
    FROM
              sys.dm_xe_objects   AS o
        JOIN  sys.dm_xe_packages  AS p

            ON  o.package_guid = p.guid

        LEFT OUTER JOIN  sys.dm_xe_object_columns  AS c

            ON  o.name        = c.object_name
            AND c.column_type = 'customizable'  -- !
    WHERE
        o.object_type = 'target'
        AND
        o.name     = 'event_file'    -- Target name here
    ORDER BY
        [Package],
        [Target],
        [IsMandatoryYN]  DESC,
        [Parameter];