create event session [Trace Statements]
on server
add event sqlserver.sql_statement_completed (ACTION (sqlserver.sql_text))
add target package0.asynchronous_file_target (set filename = 'D:\SQLSat538\TraceStatements.xel', metadatafile = 'D:\SQLSat538\TraceStatements.xem')

alter event session [Trace Statements]
on server
state = start



alter event session [Trace Statements]
on server
state = stop


drop event session [Trace Statements]
on server