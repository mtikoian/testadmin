CREATE EVENT SESSION [Backup_Restore_XE_Demo] ON SERVER 
ADD EVENT sqlserver.backup_restore_progress_trace,
ADD EVENT sqlserver.database_recovery_progress_report,
ADD EVENT sqlserver.database_recovery_times,
ADD EVENT sqlserver.database_recovery_trace
ADD TARGET package0.ring_buffer(SET max_memory=(25600))
WITH (MAX_MEMORY=4096 KB,EVENT_RETENTION_MODE=ALLOW_SINGLE_EVENT_LOSS,MAX_DISPATCH_LATENCY=30 SECONDS,MAX_EVENT_SIZE=0 KB,MEMORY_PARTITION_MODE=NONE,TRACK_CAUSALITY=OFF,STARTUP_STATE=OFF)
GO

