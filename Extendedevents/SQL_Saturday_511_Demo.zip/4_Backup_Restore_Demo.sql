
EXEC xp_cmdshell 'del "C:\Program Files\Microsoft SQL Server\MSSQL13.MSSQLSERVER\MSSQL\Backup\adwfull_demo.bak"'
-- Take a backup
backup database adventureworksdw2014 to disk = 'adwfull_demo.bak' 
GO

USE [master]
GO
IF EXISTS (SELECT name from sys.databases WHERE name ='AdventureWorksDW2014_Demo')
	DROP DATABASE AdventureWorksDW2014_Demo
GO
RESTORE DATABASE [AdventureWorksDW2014_Demo] 
FROM  DISK = N'C:\Program Files\Microsoft SQL Server\MSSQL13.MSSQLSERVER\MSSQL\Backup\adwfull_demo.bak' 
WITH  FILE = 1,  
MOVE N'AdventureWorksDW2014_Data' TO N'C:\Program Files\Microsoft SQL Server\MSSQL13.MSSQLSERVER\MSSQL\DATA\AdventureWorksDW2014Demo_Data.mdf',  
MOVE N'AdventureWorksDW2014_Log' TO N'C:\Program Files\Microsoft SQL Server\MSSQL13.MSSQLSERVER\MSSQL\DATA\AdventureWorksDW2014Demo_Log.ldf',  NOUNLOAD,  STATS = 5
GO

ALTER DATABASE [AdventureWorksDW2014_Demo] SET OFFLINE
GO
ALTER DATABASE [AdventureWorksDW2014_Demo] SET ONLINE
GO


