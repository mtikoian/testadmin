-- Get information about the replica databases
select agr.replica_server_name,db_name(hadrdb.database_id) as databasename,
hadrdb.is_local,
hadrdb.synchronization_state_desc,
hadrdb.synchronization_health_desc,
hadrdb.suspend_reason_desc,agr.*
from sys.dm_hadr_database_replica_states hadrdb
inner join sys.availability_replicas agr
on hadrdb.replica_id = agr.replica_id


-- Perform a failover to bring the AG back to this replica instance
if ((select role_desc from sys.dm_hadr_availability_replica_states 
where replica_id = '406C9756-6309-438F-8E40-B1585EC6A2BE') = 'SECONDARY')
begin
	print 'Failing over replica'
	alter availability group SQLSatAG failover
end

-- Open XE live view
-- Initiate a failover 
-- Check state on the other server
select ag.replica_server_name, agr.role_desc
from sys.dm_hadr_availability_replica_states agr
inner join sys.availability_replicas ag
on agr.replica_id = ag.replica_id

-- Query to find out what the XEvents are showing
;WITH XEData 
AS
(
	SELECT CAST(xest.target_data as XML) xml_data
	FROM  sys.dm_xe_session_targets xest 
	INNER JOIN sys.dm_xe_sessions xes on xes.[address] = xest.event_session_address 
	WHERE xes.name = 'AG_XE_DEMO' 
	AND xest.target_name = 'ring_buffer'
)
SELECT 
dateadd(mi,datediff(mi,getutcdate(),getdate()),event_xml.value('(./@timestamp)', 'datetime')) as [Time],
event_xml.value('(./@timestamp)', 'datetime') as [UTCTime],
event_xml.value('(./data[@name="new_timeout"]/value)[1]', 'bigint') as [New_Timeout], 
event_xml.value('(./data[@name="state"]/text)[1]', 'varchar(255)') as [State],
event_xml.value('(./data[@name="id_or_name"]/value)[1]', 'varchar(255)') as [AG_Name],
event_xml.value('(./data[@name="error_code"]/value)[1]', 'varchar(255)') as [ErrorCode]
FROM XEData
CROSS APPLY xml_data.nodes('//event[@name="hadr_ag_lease_renewal"]') n (event_xml) 


;WITH XEData 
AS
(
	SELECT CAST(xest.target_data as XML) xml_data
	FROM  sys.dm_xe_session_targets xest 
	INNER JOIN sys.dm_xe_sessions xes on xes.[address] = xest.event_session_address 
	WHERE xes.name = 'AG_XE_DEMO' 
	AND xest.target_name = 'ring_buffer'
)
SELECT 
dateadd(mi,datediff(mi,getutcdate(),getdate()),event_xml.value('(./@timestamp)', 'datetime')) as [Time],
event_xml.value('(./@timestamp)', 'datetime') as [UTCTime],
event_xml.value('(./data[@name="new_timeout"]/value)[1]', 'bigint') as [New_Timeout], 
event_xml.value('(./data[@name="availability_group_name"]/value)[1]', 'varchar(255)') as [AGName],
event_xml.value('(./data[@name="current_time"]/value)[1]', 'bigint') as [Current_Time],
event_xml.value('(./data[@name="state"]/value)[1]', 'varchar(255)') as [State]
FROM XEData
CROSS APPLY xml_data.nodes('//event[@name="availability_group_lease_expired"]') n (event_xml) 

-- Demo 2 
-- Trace the record
use sqlsaturday511
go
-- Perform a failover to bring the AG back to this replica instance
if ((select role_desc from sys.dm_hadr_availability_replica_states where replica_id = '406C9756-6309-438F-8E40-B1585EC6A2BE') = 'SECONDARY')
begin
	print 'Failing over replica'
	alter availability group SQLSatAG failover
end
-- Insert rows
insert into tblDemo values (@@spid,getdate())

-- Find out the server and database name for the GUID
select replica_server_name from sys.availability_replicas 
where replica_id = '406C9756-6309-438F-8E40-B1585EC6A2BE'
select [database_name] from sys.availability_databases_cluster 
where group_database_id = 'D1F47681-E7F7-4075-8B0B-9530958E70E7'