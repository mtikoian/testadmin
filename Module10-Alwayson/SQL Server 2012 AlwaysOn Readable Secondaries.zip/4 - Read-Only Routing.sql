use master;

alter availability group [DemoAG]
	modify replica on N'AlwaysOn1'
		with (secondary_role (read_only_routing_url = N'tcp://AlwaysOn1.Demo.local:1433'));

alter availability group [DemoAG]
	modify replica on N'AlwaysOn2'
		with (secondary_role (read_only_routing_url = N'tcp://AlwaysOn2.Demo.local:1433'));

alter availability group [DemoAG]
	modify replica on N'AlwaysOn3'
		with (secondary_role (read_only_routing_url = N'tcp://AlwaysOn3.Demo.local:1433'));

alter availability group [DemoAG]
	modify replica on N'AlwaysOn1'
		with (primary_role (read_only_routing_list=('AlwaysOn2','AlwaysOn3')));

alter availability group [DemoAG]
	modify replica on N'AlwaysOn2'
		with (primary_role (read_only_routing_list=('AlwaysOn3','AlwaysOn1')));

alter availability group [DemoAG]
	modify replica on N'AlwaysOn3'
		with (primary_role (read_only_routing_list=('AlwaysOn1','AlwaysOn2')));