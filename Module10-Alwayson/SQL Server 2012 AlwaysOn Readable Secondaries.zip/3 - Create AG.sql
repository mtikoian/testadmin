--- YOU MUST EXECUTE THE FOLLOWING SCRIPT IN SQLCMD MODE.


-- Create HADR endpoint on all replicas
:Connect ALWAYSON1

USE [master];

GO

CREATE ENDPOINT [Hadr_endpoint] 
	AS TCP (LISTENER_PORT = 5022)
	FOR DATA_MIRRORING (ROLE = ALL, ENCRYPTION = REQUIRED ALGORITHM AES);

GO

IF (SELECT state FROM sys.endpoints WHERE name = N'Hadr_endpoint') <> 0
	BEGIN
		ALTER ENDPOINT [Hadr_endpoint] STATE = STARTED;
	END;


GO

use [master];

GO

GRANT CONNECT ON ENDPOINT::[Hadr_endpoint] TO [Demo\SQLService];

GO

:Connect ALWAYSON2

USE [master];

GO

CREATE ENDPOINT [Hadr_endpoint] 
	AS TCP (LISTENER_PORT = 5022)
	FOR DATA_MIRRORING (ROLE = ALL, ENCRYPTION = REQUIRED ALGORITHM AES);

GO

IF (SELECT state FROM sys.endpoints WHERE name = N'Hadr_endpoint') <> 0
	BEGIN
		ALTER ENDPOINT [Hadr_endpoint] STATE = STARTED;
	END;


GO

use [master];

GO

GRANT CONNECT ON ENDPOINT::[Hadr_endpoint] TO [Demo\SQLService];

GO

:Connect ALWAYSON3

USE [master];

GO

CREATE ENDPOINT [Hadr_endpoint] 
	AS TCP (LISTENER_PORT = 5022)
	FOR DATA_MIRRORING (ROLE = ALL, ENCRYPTION = REQUIRED ALGORITHM AES);

GO

IF (SELECT state FROM sys.endpoints WHERE name = N'Hadr_endpoint') <> 0
	BEGIN
		ALTER ENDPOINT [Hadr_endpoint] STATE = STARTED;
	END;


GO

use [master];

GO

GRANT CONNECT ON ENDPOINT::[Hadr_endpoint] TO [Demo\SQLService];

GO


-- Create an XEvents session on each replica to monitor the health of the Availability Group
:Connect ALWAYSON1

IF EXISTS(SELECT * FROM sys.server_event_sessions WHERE name='AlwaysOn_health')
	BEGIN
	  ALTER EVENT SESSION [AlwaysOn_health] ON SERVER WITH (STARTUP_STATE=ON);
	END;

IF NOT EXISTS(SELECT * FROM sys.dm_xe_sessions WHERE name='AlwaysOn_health')
	BEGIN
	  ALTER EVENT SESSION [AlwaysOn_health] ON SERVER STATE=START;
	END;

GO

:Connect ALWAYSON2

IF EXISTS(SELECT * FROM sys.server_event_sessions WHERE name='AlwaysOn_health')
	BEGIN
	  ALTER EVENT SESSION [AlwaysOn_health] ON SERVER WITH (STARTUP_STATE=ON);
	END;

IF NOT EXISTS(SELECT * FROM sys.dm_xe_sessions WHERE name='AlwaysOn_health')
	BEGIN
	  ALTER EVENT SESSION [AlwaysOn_health] ON SERVER STATE=START;
	END;

GO

:Connect ALWAYSON3

IF EXISTS(SELECT * FROM sys.server_event_sessions WHERE name='AlwaysOn_health')
	BEGIN
	  ALTER EVENT SESSION [AlwaysOn_health] ON SERVER WITH (STARTUP_STATE=ON);
	END;

IF NOT EXISTS(SELECT * FROM sys.dm_xe_sessions WHERE name='AlwaysOn_health')
	BEGIN
	  ALTER EVENT SESSION [AlwaysOn_health] ON SERVER STATE=START;
	END;

GO


-- Create the Availability Group
:Connect ALWAYSON1

USE [master];

GO

CREATE AVAILABILITY GROUP [DemoAG]
	WITH (AUTOMATED_BACKUP_PREFERENCE = SECONDARY)
	FOR DATABASE
		[AdventureWorks2012]
		, [AdventureWorksDW2012]
	REPLICA ON
		N'ALWAYSON1'
			WITH (
				ENDPOINT_URL = N'TCP://AlwaysOn1.Demo.Local:5022'
				, FAILOVER_MODE = AUTOMATIC
				, AVAILABILITY_MODE = SYNCHRONOUS_COMMIT
				, BACKUP_PRIORITY = 50
				, SECONDARY_ROLE (ALLOW_CONNECTIONS = ALL)
			)
		, N'ALWAYSON2'
			WITH (
				ENDPOINT_URL = N'TCP://AlwaysOn2.Demo.Local:5022'
				, FAILOVER_MODE = AUTOMATIC
				, AVAILABILITY_MODE = SYNCHRONOUS_COMMIT
				, BACKUP_PRIORITY = 50
				, SECONDARY_ROLE (ALLOW_CONNECTIONS = ALL)
			)
		, N'ALWAYSON3'
			WITH (
				ENDPOINT_URL = N'TCP://AlwaysOn3.Demo.Local:5022'
				, FAILOVER_MODE = MANUAL
				, AVAILABILITY_MODE = SYNCHRONOUS_COMMIT
				, BACKUP_PRIORITY = 50
				, SECONDARY_ROLE (ALLOW_CONNECTIONS = ALL)
			);
GO


-- Create the Availability Group Listener Name
:Connect ALWAYSON1

USE [master];

GO

ALTER AVAILABILITY GROUP [DemoAG]
	ADD LISTENER N'DemoAG' (
		WITH IP (
			(N'10.10.10.100'
			, N'255.255.255.0')
		)
		, PORT=1433
	);

GO


-- Join the replicas to the Availability Group
:Connect ALWAYSON2

ALTER AVAILABILITY GROUP [DemoAG] JOIN;

GO

:Connect ALWAYSON3

ALTER AVAILABILITY GROUP [DemoAG] JOIN;

GO


-- Backup AdventureWorks2012 on the primary replica and restore it on the secondary replicas
:Connect ALWAYSON1

BACKUP DATABASE [AdventureWorks2012] TO  DISK = N'\\AlwaysOnDC\AlwaysOn\AdventureWorks2012.bak' WITH  COPY_ONLY, FORMAT, INIT, SKIP, REWIND, NOUNLOAD, COMPRESSION,  STATS = 5;

GO

:Connect ALWAYSON2

RESTORE DATABASE [AdventureWorks2012] FROM  DISK = N'\\AlwaysOnDC\AlwaysOn\AdventureWorks2012.bak' WITH  NORECOVERY,  NOUNLOAD,  STATS = 5;

GO

:Connect ALWAYSON3

RESTORE DATABASE [AdventureWorks2012] FROM  DISK = N'\\AlwaysOnDC\AlwaysOn\AdventureWorks2012.bak' WITH  NORECOVERY,  NOUNLOAD,  STATS = 5;

GO


-- Backup the t-log of AdventureWorks2012 on the primary replica and restore it on the secondary replicas
:Connect ALWAYSON1

BACKUP LOG [AdventureWorks2012] TO  DISK = N'\\AlwaysOnDC\AlwaysOn\AdventureWorks2012_20120522181744.trn' WITH NOFORMAT, NOINIT, NOSKIP, REWIND, NOUNLOAD, COMPRESSION,  STATS = 5;

GO

:Connect ALWAYSON2

RESTORE LOG [AdventureWorks2012] FROM  DISK = N'\\AlwaysOnDC\AlwaysOn\AdventureWorks2012_20120522181744.trn' WITH  NORECOVERY,  NOUNLOAD,  STATS = 5;

GO

:Connect ALWAYSON3

RESTORE LOG [AdventureWorks2012] FROM  DISK = N'\\AlwaysOnDC\AlwaysOn\AdventureWorks2012_20120522181744.trn' WITH  NORECOVERY,  NOUNLOAD,  STATS = 5;

GO


-- Backup AdventureWorksDW2012 on the primary replica and restore it on the secondary replicas
:Connect ALWAYSON1

BACKUP DATABASE [AdventureWorksDW2012] TO  DISK = N'\\AlwaysOnDC\AlwaysOn\AdventureWorksDW2012.bak' WITH  COPY_ONLY, FORMAT, INIT, SKIP, REWIND, NOUNLOAD, COMPRESSION,  STATS = 5;

GO

:Connect ALWAYSON2

RESTORE DATABASE [AdventureWorksDW2012] FROM  DISK = N'\\AlwaysOnDC\AlwaysOn\AdventureWorksDW2012.bak' WITH  NORECOVERY,  NOUNLOAD,  STATS = 5;

GO

:Connect ALWAYSON3

RESTORE DATABASE [AdventureWorksDW2012] FROM  DISK = N'\\AlwaysOnDC\AlwaysOn\AdventureWorksDW2012.bak' WITH  NORECOVERY,  NOUNLOAD,  STATS = 5;

GO


-- Backup the t-log of AdventureWorksDW2012 on the primary replica and restore it on the secondary replicas
:Connect ALWAYSON1

BACKUP LOG [AdventureWorksDW2012] TO  DISK = N'\\AlwaysOnDC\AlwaysOn\AdventureWorksDW2012_20120522181744.trn' WITH NOFORMAT, NOINIT, NOSKIP, REWIND, NOUNLOAD, COMPRESSION,  STATS = 5;

GO

:Connect ALWAYSON2

RESTORE LOG [AdventureWorksDW2012] FROM  DISK = N'\\AlwaysOnDC\AlwaysOn\AdventureWorksDW2012_20120522181744.trn' WITH  NORECOVERY,  NOUNLOAD,  STATS = 5;

GO

:Connect ALWAYSON3

RESTORE LOG [AdventureWorksDW2012] FROM  DISK = N'\\AlwaysOnDC\AlwaysOn\AdventureWorksDW2012_20120522181744.trn' WITH  NORECOVERY,  NOUNLOAD,  STATS = 5;

GO


-- Join the database to the Availability Group on each of the replicas
:Connect ALWAYSON2

ALTER DATABASE [AdventureWorks2012] SET HADR AVAILABILITY GROUP = DemoAG;

GO

ALTER DATABASE [AdventureWorksDW2012] SET HADR AVAILABILITY GROUP = DemoAG;

GO

:Connect ALWAYSON3

ALTER DATABASE [AdventureWorks2012] SET HADR AVAILABILITY GROUP = DemoAG;

GO

ALTER DATABASE [AdventureWorksDW2012] SET HADR AVAILABILITY GROUP = DemoAG;

GO