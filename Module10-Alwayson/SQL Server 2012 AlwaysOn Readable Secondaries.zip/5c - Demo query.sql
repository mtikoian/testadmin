use AdventureWorks2012;

begin tran;

declare @ShipDateBefore datetime, @ShipDateAfter datetime;

select @ShipDateBefore = ShipDate
from Sales.SalesOrderHeader
where SalesOrderID = 43678;

update Sales.SalesOrderHeader
set ShipDate = getdate()
where SalesOrderID = 43678;

select @ShipDateAfter = ShipDate
from Sales.SalesOrderHeader
where SalesOrderID = 43678;

select @ShipDateBefore ShipDateBefore, @ShipDateAfter ShipDateAfter;

rollback tran;