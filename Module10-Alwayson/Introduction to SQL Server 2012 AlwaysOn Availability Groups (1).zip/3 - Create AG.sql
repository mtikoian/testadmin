--- YOU MUST EXECUTE THE FOLLOWING SCRIPT IN SQLCMD MODE.
:Connect ALWAYSON14REP1
USE [master]
GO

CREATE LOGIN [sqldiablo\sqlservice] FROM WINDOWS
GO

:Connect ALWAYSON14REP2
USE [master]
GO

CREATE LOGIN [sqldiablo\sqlservice] FROM WINDOWS
GO

:Connect ALWAYSON14REP3
USE [master]
GO

CREATE LOGIN [sqldiablo\sqlservice] FROM WINDOWS
GO

:Connect ALWAYSON14REP1
USE [master]
GO

CREATE ENDPOINT [Hadr_endpoint] 
	AS TCP (LISTENER_PORT = 5022)
	FOR DATA_MIRRORING (ROLE = ALL, ENCRYPTION = REQUIRED ALGORITHM AES)
GO

IF (SELECT state FROM sys.endpoints WHERE name = N'Hadr_endpoint') <> 0
	BEGIN
		ALTER ENDPOINT [Hadr_endpoint] STATE = STARTED
	END
GO

use [master]
GO

GRANT CONNECT ON ENDPOINT::[Hadr_endpoint] TO [sqldiablo\sqlservice]
GO

:Connect ALWAYSON14REP2
USE [master]
GO

CREATE ENDPOINT [Hadr_endpoint] 
	AS TCP (LISTENER_PORT = 5022)
	FOR DATA_MIRRORING (ROLE = ALL, ENCRYPTION = REQUIRED ALGORITHM AES)
GO

IF (SELECT state FROM sys.endpoints WHERE name = N'Hadr_endpoint') <> 0
	BEGIN
		ALTER ENDPOINT [Hadr_endpoint] STATE = STARTED
	END
GO

use [master]
GO

GRANT CONNECT ON ENDPOINT::[Hadr_endpoint] TO [sqldiablo\sqlservice]
GO

:Connect ALWAYSON14REP3
USE [master]
GO

CREATE ENDPOINT [Hadr_endpoint] 
	AS TCP (LISTENER_PORT = 5022)
	FOR DATA_MIRRORING (ROLE = ALL, ENCRYPTION = REQUIRED ALGORITHM AES)
GO

IF (SELECT state FROM sys.endpoints WHERE name = N'Hadr_endpoint') <> 0
	BEGIN
		ALTER ENDPOINT [Hadr_endpoint] STATE = STARTED
	END
GO

use [master]
GO

GRANT CONNECT ON ENDPOINT::[Hadr_endpoint] TO [sqldiablo\sqlservice]
GO

:Connect ALWAYSON14REP1
IF EXISTS(SELECT * FROM sys.server_event_sessions WHERE name='AlwaysOn_health')
	BEGIN
	  ALTER EVENT SESSION [AlwaysOn_health] ON SERVER WITH (STARTUP_STATE=ON);
	END

IF NOT EXISTS(SELECT * FROM sys.dm_xe_sessions WHERE name='AlwaysOn_health')
	BEGIN
	  ALTER EVENT SESSION [AlwaysOn_health] ON SERVER STATE=START;
	END
GO

:Connect ALWAYSON14REP2
IF EXISTS(SELECT * FROM sys.server_event_sessions WHERE name='AlwaysOn_health')
	BEGIN
	  ALTER EVENT SESSION [AlwaysOn_health] ON SERVER WITH (STARTUP_STATE=ON);
	END

IF NOT EXISTS(SELECT * FROM sys.dm_xe_sessions WHERE name='AlwaysOn_health')
	BEGIN
	  ALTER EVENT SESSION [AlwaysOn_health] ON SERVER STATE=START;
	END
GO

:Connect ALWAYSON14REP3
IF EXISTS(SELECT * FROM sys.server_event_sessions WHERE name='AlwaysOn_health')
	BEGIN
	  ALTER EVENT SESSION [AlwaysOn_health] ON SERVER WITH (STARTUP_STATE=ON);
	END

IF NOT EXISTS(SELECT * FROM sys.dm_xe_sessions WHERE name='AlwaysOn_health')
	BEGIN
	  ALTER EVENT SESSION [AlwaysOn_health] ON SERVER STATE=START;
	END
GO

:Connect ALWAYSON14REP1
USE [master]
GO

CREATE AVAILABILITY GROUP [DemoAG]
WITH (AUTOMATED_BACKUP_PREFERENCE = SECONDARY)
FOR DATABASE [AdventureWorks2012], [AdventureWorksDW2012]
REPLICA ON
	N'ALWAYSON14REP1' WITH (
		ENDPOINT_URL = N'TCP://AlwaysOn14Rep1.SQLDiablo.local:5022'
		, FAILOVER_MODE = AUTOMATIC
		, AVAILABILITY_MODE = SYNCHRONOUS_COMMIT
		, BACKUP_PRIORITY = 50
		, SECONDARY_ROLE(ALLOW_CONNECTIONS = ALL)
	)
	, N'ALWAYSON14REP2' WITH (
		ENDPOINT_URL = N'TCP://AlwaysOn14Rep2.SQLDiablo.local:5022'
		, FAILOVER_MODE = AUTOMATIC
		, AVAILABILITY_MODE = SYNCHRONOUS_COMMIT
		, BACKUP_PRIORITY = 50
		, SECONDARY_ROLE(ALLOW_CONNECTIONS = ALL)
	)
	, N'ALWAYSON14REP3' WITH (
		ENDPOINT_URL = N'TCP://AlwaysOn14Rep3.SQLDiablo.local:5022'
		, FAILOVER_MODE = MANUAL
		, AVAILABILITY_MODE = ASYNCHRONOUS_COMMIT
		, BACKUP_PRIORITY = 50
		, SECONDARY_ROLE(ALLOW_CONNECTIONS = ALL)
	);
GO

:Connect ALWAYSON14REP1
USE [master]
GO

ALTER AVAILABILITY GROUP [DemoAG]
	ADD LISTENER N'DemoAG' (
		WITH
			IP (
				(N'10.100.100.100', N'255.255.255.0')
				, (N'10.200.200.100', N'255.255.255.0')
			)
			, PORT=1433
	);
GO

:Connect ALWAYSON14REP2
ALTER AVAILABILITY GROUP [DemoAG] JOIN;
GO

:Connect ALWAYSON14REP3
ALTER AVAILABILITY GROUP [DemoAG] JOIN;
GO

:Connect ALWAYSON14REP1
BACKUP DATABASE [AdventureWorks2012] TO  DISK = N'\\ALWAYSON14DC\AlwaysOn\AdventureWorks2012.bak' WITH  COPY_ONLY, FORMAT, INIT, SKIP, REWIND, NOUNLOAD, COMPRESSION,  STATS = 5
GO

:Connect ALWAYSON14REP2
RESTORE DATABASE [AdventureWorks2012] FROM  DISK = N'\\ALWAYSON14DC\AlwaysOn\AdventureWorks2012.bak' WITH  NORECOVERY,  NOUNLOAD,  STATS = 5
GO

:Connect ALWAYSON14REP3
RESTORE DATABASE [AdventureWorks2012] FROM  DISK = N'\\ALWAYSON14DC\AlwaysOn\AdventureWorks2012.bak' WITH  NORECOVERY,  NOUNLOAD,  STATS = 5
GO

:Connect ALWAYSON14REP1
BACKUP LOG [AdventureWorks2012] TO  DISK = N'\\ALWAYSON14DC\AlwaysOn\AdventureWorks2012_20140323194840.trn' WITH NOFORMAT, NOINIT, NOSKIP, REWIND, NOUNLOAD, COMPRESSION,  STATS = 5
GO

:Connect ALWAYSON14REP2
RESTORE LOG [AdventureWorks2012] FROM  DISK = N'\\ALWAYSON14DC\AlwaysOn\AdventureWorks2012_20140323194840.trn' WITH  NORECOVERY,  NOUNLOAD,  STATS = 5
GO

:Connect ALWAYSON14REP2
-- Wait for the replica to start communicating
begin try
	declare @conn bit
	declare @count int
	declare @replica_id uniqueidentifier 
	declare @group_id uniqueidentifier
	set @conn = 0
	set @count = 30 -- wait for 5 minutes 

	if (serverproperty('IsHadrEnabled') = 1) and (isnull((select member_state from master.sys.dm_hadr_cluster_members where upper(member_name COLLATE Latin1_General_CI_AS) = upper(cast(serverproperty('ComputerNamePhysicalNetBIOS') as nvarchar(256)) COLLATE Latin1_General_CI_AS)), 0) <> 0) and (isnull((select state from master.sys.database_mirroring_endpoints), 1) = 0)
		begin
			select @group_id = ags.group_id from master.sys.availability_groups as ags where name = N'DemoAG'
			select @replica_id = replicas.replica_id from master.sys.availability_replicas as replicas where upper(replicas.replica_server_name COLLATE Latin1_General_CI_AS) = upper(@@SERVERNAME COLLATE Latin1_General_CI_AS) and group_id = @group_id
		
			while @conn <> 1 and @count > 0
			begin
				set @conn = isnull((select connected_state from master.sys.dm_hadr_availability_replica_states as states where states.replica_id = @replica_id), 1)
			
				if @conn = 1
					begin
						-- exit loop when the replica is connected, or if the query cannot find the replica status
						break
					end
			
				waitfor delay '00:00:10'
				set @count = @count - 1
			end
		end
end try
begin catch
	-- If the wait loop fails, do not stop execution of the alter database statement
end catch

ALTER DATABASE [AdventureWorks2012] SET HADR AVAILABILITY GROUP = [DemoAG];
GO

:Connect ALWAYSON14REP3
RESTORE LOG [AdventureWorks2012] FROM  DISK = N'\\ALWAYSON14DC\AlwaysOn\AdventureWorks2012_20140323194840.trn' WITH  NORECOVERY,  NOUNLOAD,  STATS = 5
GO

:Connect ALWAYSON14REP3
-- Wait for the replica to start communicating
begin try
	declare @conn bit
	declare @count int
	declare @replica_id uniqueidentifier 
	declare @group_id uniqueidentifier
	set @conn = 0
	set @count = 30 -- wait for 5 minutes 

	if (serverproperty('IsHadrEnabled') = 1) and (isnull((select member_state from master.sys.dm_hadr_cluster_members where upper(member_name COLLATE Latin1_General_CI_AS) = upper(cast(serverproperty('ComputerNamePhysicalNetBIOS') as nvarchar(256)) COLLATE Latin1_General_CI_AS)), 0) <> 0) and (isnull((select state from master.sys.database_mirroring_endpoints), 1) = 0)
		begin
			select @group_id = ags.group_id from master.sys.availability_groups as ags where name = N'DemoAG'
			select @replica_id = replicas.replica_id from master.sys.availability_replicas as replicas where upper(replicas.replica_server_name COLLATE Latin1_General_CI_AS) = upper(@@SERVERNAME COLLATE Latin1_General_CI_AS) and group_id = @group_id
			
			while @conn <> 1 and @count > 0
				begin
					set @conn = isnull((select connected_state from master.sys.dm_hadr_availability_replica_states as states where states.replica_id = @replica_id), 1)
					
					if @conn = 1
						begin
							-- exit loop when the replica is connected, or if the query cannot find the replica status
							break
						end

					waitfor delay '00:00:10'
					set @count = @count - 1
				end
		end
end try
begin catch
	-- If the wait loop fails, do not stop execution of the alter database statement
end catch

ALTER DATABASE [AdventureWorks2012] SET HADR AVAILABILITY GROUP = [DemoAG];
GO

:Connect ALWAYSON14REP1
BACKUP DATABASE [AdventureWorksDW2012] TO  DISK = N'\\ALWAYSON14DC\AlwaysOn\AdventureWorksDW2012.bak' WITH  COPY_ONLY, FORMAT, INIT, SKIP, REWIND, NOUNLOAD, COMPRESSION,  STATS = 5
GO

:Connect ALWAYSON14REP2
RESTORE DATABASE [AdventureWorksDW2012] FROM  DISK = N'\\ALWAYSON14DC\AlwaysOn\AdventureWorksDW2012.bak' WITH  NORECOVERY,  NOUNLOAD,  STATS = 5
GO

:Connect ALWAYSON14REP3
RESTORE DATABASE [AdventureWorksDW2012] FROM  DISK = N'\\ALWAYSON14DC\AlwaysOn\AdventureWorksDW2012.bak' WITH  NORECOVERY,  NOUNLOAD,  STATS = 5
GO

:Connect ALWAYSON14REP1
BACKUP LOG [AdventureWorksDW2012] TO  DISK = N'\\ALWAYSON14DC\AlwaysOn\AdventureWorksDW2012_20140323194841.trn' WITH NOFORMAT, NOINIT, NOSKIP, REWIND, NOUNLOAD, COMPRESSION,  STATS = 5
GO

:Connect ALWAYSON14REP2
RESTORE LOG [AdventureWorksDW2012] FROM  DISK = N'\\ALWAYSON14DC\AlwaysOn\AdventureWorksDW2012_20140323194841.trn' WITH  NORECOVERY,  NOUNLOAD,  STATS = 5
GO

:Connect ALWAYSON14REP2
-- Wait for the replica to start communicating
begin try
	declare @conn bit
	declare @count int
	declare @replica_id uniqueidentifier 
	declare @group_id uniqueidentifier
	set @conn = 0
	set @count = 30 -- wait for 5 minutes 

	if (serverproperty('IsHadrEnabled') = 1) and (isnull((select member_state from master.sys.dm_hadr_cluster_members where upper(member_name COLLATE Latin1_General_CI_AS) = upper(cast(serverproperty('ComputerNamePhysicalNetBIOS') as nvarchar(256)) COLLATE Latin1_General_CI_AS)), 0) <> 0) and (isnull((select state from master.sys.database_mirroring_endpoints), 1) = 0)
		begin
			select @group_id = ags.group_id from master.sys.availability_groups as ags where name = N'DemoAG'
			select @replica_id = replicas.replica_id from master.sys.availability_replicas as replicas where upper(replicas.replica_server_name COLLATE Latin1_General_CI_AS) = upper(@@SERVERNAME COLLATE Latin1_General_CI_AS) and group_id = @group_id
			
			while @conn <> 1 and @count > 0
				begin
					set @conn = isnull((select connected_state from master.sys.dm_hadr_availability_replica_states as states where states.replica_id = @replica_id), 1)
					
					if @conn = 1
						begin
							-- exit loop when the replica is connected, or if the query cannot find the replica status
							break
						end
					
					waitfor delay '00:00:10'
					set @count = @count - 1
				end
		end
end try
begin catch
	-- If the wait loop fails, do not stop execution of the alter database statement
end catch

ALTER DATABASE [AdventureWorksDW2012] SET HADR AVAILABILITY GROUP = [DemoAG];
GO

:Connect ALWAYSON14REP3
RESTORE LOG [AdventureWorksDW2012] FROM  DISK = N'\\ALWAYSON14DC\AlwaysOn\AdventureWorksDW2012_20140323194841.trn' WITH  NORECOVERY,  NOUNLOAD,  STATS = 5
GO

:Connect ALWAYSON14REP3
-- Wait for the replica to start communicating
begin try
	declare @conn bit
	declare @count int
	declare @replica_id uniqueidentifier 
	declare @group_id uniqueidentifier
	set @conn = 0
	set @count = 30 -- wait for 5 minutes 

	if (serverproperty('IsHadrEnabled') = 1) and (isnull((select member_state from master.sys.dm_hadr_cluster_members where upper(member_name COLLATE Latin1_General_CI_AS) = upper(cast(serverproperty('ComputerNamePhysicalNetBIOS') as nvarchar(256)) COLLATE Latin1_General_CI_AS)), 0) <> 0) and (isnull((select state from master.sys.database_mirroring_endpoints), 1) = 0)
		begin
			select @group_id = ags.group_id from master.sys.availability_groups as ags where name = N'DemoAG'
			select @replica_id = replicas.replica_id from master.sys.availability_replicas as replicas where upper(replicas.replica_server_name COLLATE Latin1_General_CI_AS) = upper(@@SERVERNAME COLLATE Latin1_General_CI_AS) and group_id = @group_id
			
			while @conn <> 1 and @count > 0
				begin
					set @conn = isnull((select connected_state from master.sys.dm_hadr_availability_replica_states as states where states.replica_id = @replica_id), 1)
					
					if @conn = 1
						begin
							-- exit loop when the replica is connected, or if the query cannot find the replica status
							break
						end
					
					waitfor delay '00:00:10'
					set @count = @count - 1
				end
		end
end try
begin catch
	-- If the wait loop fails, do not stop execution of the alter database statement
end catch

ALTER DATABASE [AdventureWorksDW2012] SET HADR AVAILABILITY GROUP = [DemoAG];
GO