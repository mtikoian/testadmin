use master;

alter availability group [DemoAG]
	modify replica on N'AlwaysOn14Rep1'
		with (secondary_role (read_only_routing_url = N'tcp://AlwaysOn14Rep1.SQLDiablo.local:1433'));

alter availability group [DemoAG]
	modify replica on N'AlwaysOn14Rep2'
		with (secondary_role (read_only_routing_url = N'tcp://AlwaysOn14Rep2.SQLDiablo.local:1433'));

alter availability group [DemoAG]
	modify replica on N'AlwaysOn14Rep3'
		with (secondary_role (read_only_routing_url = N'tcp://AlwaysOn14Rep3.SQLDiablo.local:1433'));

alter availability group [DemoAG]
	modify replica on N'AlwaysOn14Rep1'
		with (primary_role (read_only_routing_list=('AlwaysOn14Rep2','AlwaysOn14Rep3')));

alter availability group [DemoAG]
	modify replica on N'AlwaysOn14Rep2'
		with (primary_role (read_only_routing_list=('AlwaysOn14Rep1','AlwaysOn14Rep3')));

alter availability group [DemoAG]
	modify replica on N'AlwaysOn14Rep3'
		with (primary_role (read_only_routing_list=('AlwaysOn14Rep1','AlwaysOn14Rep2')));
go