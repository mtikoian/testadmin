USE [AdventureWorks2008R2]
GO

/*
	Run the following on Primary Replica
*/

/*
Step 1: 
This select does a clustered index scan. In fact in execution plan we gonna get a missing index warning/recommendation.
*/
SELECT p.FirstName, p.LastName
FROM Person.Person as p 
WHERE p.PersonType = N'EM'
GO

/*
Step 2: Create Missing Index
(Missing Index Details: The Query Processor estimates that implementing the following index could improve the query cost by 98.2554%.)
*/
CREATE NONCLUSTERED INDEX [IX_Person_PersonType]
ON [Person].[Person] ([PersonType])
INCLUDE ([FirstName],[LastName])
GO

/*
Step 3: Go to secondary replica and run query from step 1
*/

/*
Step 5: Drop the index...
*/
DROP INDEX [IX_Person_PersonType] ON [Person].[Person]
GO

/*
For REDO thread blocking: Add a new column to Person tablle
*/
ALTER TABLE [Person].[Person] ADD DemoColumn varchar(10) null;
GO

ALTER TABLE [Person].[Person] DROP COLUMN DemoColumn
GO