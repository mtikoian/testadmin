USE [AdventureWorks2008R2]
GO
-------------------------------------------------------------------------------------------
-- SETUP
-------------------------------------------------------------------------------------------
IF EXISTS (select 1 from INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'T1')
DROP TABLE dbo.T1
GO

create table T1 (c1 int, c2 int, c3 int)
go

-- insert into T1 1 row
insert into T1 values (-1, -1, -1)
-------------------------------------------------------------------------------------------
-- Example 1 Temp Statistics
-------------------------------------------------------------------------------------------
 -- query T1 and show that stats got created automatically on T1/c1
select * from T1 where c1 = 1

 -- check the stats on table T1
select * from sys.stats where OBJECT_ID = object_id('T1')

-- Go to secondary, run the same select and check the statistics for T1
-------------------------------------------------------------------------------------------
-- Example 2: Stale Statistics
-------------------------------------------------------------------------------------------
-- insert 10000 rows on the primary to make the statistics stale
set nocount on
go

declare @i int = 0

while (@i < 10000)
begin
    insert into t1 values (@i, @i + 1000, @i + 10000)
    set @i = @i + 1
end 

-- Now, go to the secondary

-- statistics details on primary
dbcc show_statistics('t1', '_WA_Sys_00000001_2B5F6B28')

-- query t1 and show that stats got created created automatically on t1/c1
select * from t1 where c1 > 1000
