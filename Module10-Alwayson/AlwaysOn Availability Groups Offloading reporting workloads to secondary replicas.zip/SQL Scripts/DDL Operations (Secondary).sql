USE [AdventureWorks2008R2]
GO

/*
	Run the following on Secondary Replica
*/

/*
Step 4: Run query and check execution plan
*/
SELECT p.FirstName, p.LastName
FROM Person.Person as p 
WHERE p.PersonType = N'EM'

/*
Step 5: Now run same query with open transaction, and then go back to primary and drop the index...
*/
BEGIN TRANSACTION

SELECT p.FirstName, p.LastName
FROM Person.Person as p 
WHERE p.PersonType = N'EM'
GO

/*
Step 6: run the query again with transaction still in effect...
*/
SELECT p.FirstName, p.LastName
FROM Person.Person as p 
WHERE p.PersonType = N'EM'
GO

/*
Step 7: what if we use read uncommited isolation level and put nolock hint?
*/
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
GO
BEGIN TRANSACTION

SELECT p.FirstName, p.LastName
FROM Person.Person as p (NOLOCK)
WHERE p.PersonType = N'EM'
GO

/*
Step 8: will I get an error this time?
*/
SELECT p.FirstName, p.LastName
FROM Person.Person as p (NOLOCK)
WHERE p.PersonType = N'EM'
GO