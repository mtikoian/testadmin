--> Define a readonly connection and check which instance you are connected to
sqlcmd -S AGSQL -E -d AdventureWorks2008R2 -K readonly