/*
Must Run this on Primary Replica
*/
USE [master]
GO

/*
1 Setup all nodes for the availability group to have Readable Secondary set to Yes 
*/

/*
2 Make sure that the Connections in Primary Role value is set to Allow all connections. 
If the secondary node(s) go offline and this value is set to allow read/write connections, 
then read-only connections will be denied.
*/
ALTER AVAILABILITY GROUP [AGROUP]
MODIFY REPLICA ON 
N'SQL01' WITH 
(PRIMARY_ROLE(ALLOW_CONNECTIONS = ALL))
GO
ALTER AVAILABILITY GROUP [AGROUP]
MODIFY REPLICA ON 
N'SQL02' WITH 
(PRIMARY_ROLE(ALLOW_CONNECTIONS = ALL))
GO

/*
3 Configure read-only routing URLs, for all replicas.
*/
ALTER AVAILABILITY GROUP [AGROUP]
MODIFY REPLICA ON
N'SQL01' With
(Secondary_Role(READ_ONLY_ROUTING_URL = N'tcp://SQL01.stdomain.local:1433'))
GO
ALTER AVAILABILITY GROUP [AGROUP]
MODIFY REPLICA ON
N'SQL02' With
(Secondary_Role(READ_ONLY_ROUTING_URL = N'tcp://SQL02.stdomain.local:1433'))
GO

/*
4 Configure read-only routing lists.
*/
-- Configure SQL01 to route to the SQL02 first, then SQL01 when SQL01 is the primary
-- Configure SQL02 to route to SQL01 first, then SQL02 when SQL02 is the primary.
ALTER AVAILABILITY GROUP [AGROUP]
MODIFY REPLICA ON
N'SQL01' With
(Primary_Role (READ_ONLY_ROUTING_LIST = (N'SQL02',N'SQL01')))
GO
ALTER AVAILABILITY GROUP [AGROUP]
MODIFY REPLICA ON
N'SQL02' With
(Primary_Role (READ_ONLY_ROUTING_LIST = (N'SQL01',N'SQL02')))
GO
