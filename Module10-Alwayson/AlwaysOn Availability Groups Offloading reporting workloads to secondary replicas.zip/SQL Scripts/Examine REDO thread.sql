-- Examine the redo queue size
select dhdrs.redo_queue_size
from master.sys.dm_hadr_database_replica_states dhdrs
join master.sys.databases d
on d.database_id = dhdrs.database_id
and d.name = 'AdventureWorks2008R2';
GO

-- Query the following DMV to see how far the REDO thread has fallen behind. 
select	d.name as database_name, synchronization_state_desc,
		recovery_lsn, -- For a secondary replica, if this value is less than the current hardened LSN (last_hardened_lsn), recovery_lsn is the value to which this secondary database would need to resynchronize
		truncation_lsn, last_hardened_lsn, last_received_lsn, 
		last_redone_lsn, last_redone_time
from sys.dm_hadr_database_replica_states as rs
inner join sys.databases as d
	on d.database_id = rs.database_id
where d.name = N'AdventureWorks2008R2'
GO
