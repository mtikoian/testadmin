USE MASTER
GO

SELECT ag.name as "Availability Group", ar.replica_server_name as "When Primary Replica Is",
        rl.routing_priority as "Routing Priority", ar2.replica_server_name as "RO Routed To", 
        ar.secondary_role_allow_connections_desc, ar2.read_only_routing_url
FROM sys.availability_read_only_routing_lists rl 
INNER JOIN sys.availability_replicas ar on rl.replica_id = ar.replica_id
INNER JOIN sys.availability_replicas ar2 on rl.read_only_replica_id = ar2.replica_id
INNER JOIN sys.availability_groups ag on ar.group_id = ag.group_id
ORDER BY ag.name, ar.replica_server_name, rl.routing_priority
GO
