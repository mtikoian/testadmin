USE [master]
GO
/*
Execute this on Primary Replica Instance
*/

/*
	Set Secondary to Accept ALL connections
*/
ALTER AVAILABILITY GROUP [AGROUP]
MODIFY REPLICA ON N'SQL02' WITH (SECONDARY_ROLE(ALLOW_CONNECTIONS = ALL))
GO


/*
	Set Secondary to Accept READ ONLY connections
*/
ALTER AVAILABILITY GROUP [AGROUP]
MODIFY REPLICA ON N'SQL02' WITH (SECONDARY_ROLE(ALLOW_CONNECTIONS = READ_ONLY))
GO
