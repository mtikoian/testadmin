USE [AdventureWorks2008R2]
GO

-------------------------------------------------------------------------------------------
-- Example 1 Temp Statistics
-------------------------------------------------------------------------------------------
--show the stats on the secondary
select * from sys.stats WHERE OBJECT_ID = OBJECT_ID('t1')

-- query on column C2 to show TEMPSTATS
select * from dbo.T1 where c2= -1

--show the stats on the secondary (check for stats on tempdb)
select * from sys.stats WHERE OBJECT_ID = OBJECT_ID('t1')

-------------------------------------------------------------------------------------------
-- Example 2: Stale Statistics
-------------------------------------------------------------------------------------------
-- Query on the secondary so that stats are updated with TEMPSTATS
select c2 from t1 where c1 = 100

--show again the stats on the secondary (check last updated date)
select STATS_DATE([object_id], stats_id) AS LastUpdated , *
from sys.stats WHERE OBJECT_ID = OBJECT_ID('t1')

 --Let us see the full details of this statistics
dbcc show_statistics('t1', '_WA_Sys_00000001_2B5F6B28')
