/*
Author: Ryan Adams
Website: http://www.ryanjadams.com
Twitter: @ryanjadams

This script must be executed in SQLCMD mode.  This script was designed to remove an AlwaysOn Availability Group
in a custom lab environment.  Use at your own risk and DO NOT run this in production.  Make sure you read and understand
it thoroughly.
*/

/* We connect to each replica and remove the logins associated with the SQL Server Services of the other replicas */
:Connect SERVER1

USE [master]
GO

DROP LOGIN [stars\svc-sql2]
GO

DROP LOGIN [stars\svc-sql3]
GO

DROP LOGIN [stars\svc-sql4]
GO

DROP LOGIN [stars\svc-sql5]
GO

:Connect server2

USE [master]
GO

DROP LOGIN [stars\svc-sql1]
GO

DROP LOGIN [stars\svc-sql3]
GO

DROP LOGIN [stars\svc-sql4]
GO

DROP LOGIN [stars\svc-sql5]
GO

:Connect server3

USE [master]
GO

DROP LOGIN [stars\svc-sql1]
GO

DROP LOGIN [stars\svc-sql2]
GO

DROP LOGIN [stars\svc-sql4]
GO

DROP LOGIN [stars\svc-sql5]
GO

:Connect server4

USE [master]
GO

DROP LOGIN [stars\svc-sql1]
GO

DROP LOGIN [stars\svc-sql2]
GO

DROP LOGIN [stars\svc-sql3]
GO

DROP LOGIN [stars\svc-sql5]
GO

:Connect server5

USE [master]
GO

DROP LOGIN [stars\svc-sql1]
GO

DROP LOGIN [stars\svc-sql2]
GO

DROP LOGIN [stars\svc-sql3]
GO

DROP LOGIN [stars\svc-sql4]
GO

/* Now we remove the endpoints from each replica */
:Connect SERVER1

USE [master]
GO

DROP ENDPOINT [AlwaysOn_EP] 
GO

:Connect server2

USE [master]
GO

DROP ENDPOINT [AlwaysOn_EP]
GO

:Connect server3

USE [master]
GO

DROP ENDPOINT [AlwaysOn_EP]
GO

:Connect server4

USE [master]
GO

DROP ENDPOINT [AlwaysOn_EP]
GO

:Connect server5

USE [master]
GO

DROP ENDPOINT [AlwaysOn_EP]
GO

/* We no longer need the extended events session so we stop it and make sure it won't restart */
:Connect SERVER1

IF EXISTS(SELECT * FROM sys.server_event_sessions WHERE name='AlwaysOn_health')
BEGIN
  ALTER EVENT SESSION [AlwaysOn_health] ON SERVER WITH (STARTUP_STATE=OFF);
END

IF EXISTS(SELECT * FROM sys.dm_xe_sessions WHERE name='AlwaysOn_health')
BEGIN
  ALTER EVENT SESSION [AlwaysOn_health] ON SERVER STATE=STOP;
END

GO

:Connect server2

IF EXISTS(SELECT * FROM sys.server_event_sessions WHERE name='AlwaysOn_health')
BEGIN
  ALTER EVENT SESSION [AlwaysOn_health] ON SERVER WITH (STARTUP_STATE=OFF);
END

IF EXISTS(SELECT * FROM sys.dm_xe_sessions WHERE name='AlwaysOn_health')
BEGIN
  ALTER EVENT SESSION [AlwaysOn_health] ON SERVER STATE=STOP;
END

GO

:Connect server3

IF EXISTS(SELECT * FROM sys.server_event_sessions WHERE name='AlwaysOn_health')
BEGIN
  ALTER EVENT SESSION [AlwaysOn_health] ON SERVER WITH (STARTUP_STATE=OFF);
END

IF EXISTS(SELECT * FROM sys.dm_xe_sessions WHERE name='AlwaysOn_health')
BEGIN
  ALTER EVENT SESSION [AlwaysOn_health] ON SERVER STATE=STOP;
END

GO

:Connect server4

IF EXISTS(SELECT * FROM sys.server_event_sessions WHERE name='AlwaysOn_health')
BEGIN
  ALTER EVENT SESSION [AlwaysOn_health] ON SERVER WITH (STARTUP_STATE=OFF);
END

IF EXISTS(SELECT * FROM sys.dm_xe_sessions WHERE name='AlwaysOn_health')
BEGIN
  ALTER EVENT SESSION [AlwaysOn_health] ON SERVER STATE=STOP;
END

GO

:Connect server5

IF EXISTS(SELECT * FROM sys.server_event_sessions WHERE name='AlwaysOn_health')
BEGIN
  ALTER EVENT SESSION [AlwaysOn_health] ON SERVER WITH (STARTUP_STATE=OFF);
END

IF EXISTS(SELECT * FROM sys.dm_xe_sessions WHERE name='AlwaysOn_health')
BEGIN
  ALTER EVENT SESSION [AlwaysOn_health] ON SERVER STATE=STOP;
END

GO

/* We remove our 3 DBs from the AG */
:Connect SERVER1

USE [master]
GO

ALTER AVAILABILITY GROUP [App1AG]
REMOVE DATABASE [App1AG_DB1];
GO

ALTER AVAILABILITY GROUP [App1AG]
REMOVE DATABASE [App1AG_DB2];
GO

ALTER AVAILABILITY GROUP [App1AG]
REMOVE DATABASE [App1AG_DB3];
GO

/* With the DBs removed we can now remove the AG */
DROP AVAILABILITY GROUP [App1AG]
GO

WAITFOR DELAY '00:00:30'

/* Now we can remove our 3 DBs from each SECONDARY replica.  We fully restore it, kick out any users, and drop it */
:Connect SERVER2

USE [master]
GO

RESTORE DATABASE App1AG_DB1
GO
RESTORE DATABASE App1AG_DB2
GO
RESTORE DATABASE App1AG_DB3
GO

ALTER DATABASE [App1AG_DB1] SET  SINGLE_USER WITH ROLLBACK IMMEDIATE;
GO
ALTER DATABASE [App1AG_DB2] SET  SINGLE_USER WITH ROLLBACK IMMEDIATE;
GO
ALTER DATABASE [App1AG_DB3] SET  SINGLE_USER WITH ROLLBACK IMMEDIATE;
GO

DROP DATABASE App1AG_DB1
GO
DROP DATABASE App1AG_DB2
GO
DROP DATABASE App1AG_DB3
GO

:Connect SERVER3

USE [master]
GO

RESTORE DATABASE App1AG_DB1
GO
RESTORE DATABASE App1AG_DB2
GO
RESTORE DATABASE App1AG_DB3
GO

ALTER DATABASE [App1AG_DB1] SET  SINGLE_USER WITH ROLLBACK IMMEDIATE;
GO
ALTER DATABASE [App1AG_DB2] SET  SINGLE_USER WITH ROLLBACK IMMEDIATE;
GO
ALTER DATABASE [App1AG_DB3] SET  SINGLE_USER WITH ROLLBACK IMMEDIATE;
GO

DROP DATABASE App1AG_DB1
GO
DROP DATABASE App1AG_DB2
GO
DROP DATABASE App1AG_DB3
GO

:Connect SERVER4

USE [master]
GO

RESTORE DATABASE App1AG_DB1
GO
RESTORE DATABASE App1AG_DB2
GO
RESTORE DATABASE App1AG_DB3
GO

ALTER DATABASE [App1AG_DB1] SET  SINGLE_USER WITH ROLLBACK IMMEDIATE;
GO
ALTER DATABASE [App1AG_DB2] SET  SINGLE_USER WITH ROLLBACK IMMEDIATE;
GO
ALTER DATABASE [App1AG_DB3] SET  SINGLE_USER WITH ROLLBACK IMMEDIATE;
GO

DROP DATABASE App1AG_DB1
GO
DROP DATABASE App1AG_DB2
GO
DROP DATABASE App1AG_DB3
GO

:Connect SERVER5

USE [master]
GO

RESTORE DATABASE App1AG_DB1
GO
RESTORE DATABASE App1AG_DB2
GO
RESTORE DATABASE App1AG_DB3
GO

ALTER DATABASE [App1AG_DB1] SET  SINGLE_USER WITH ROLLBACK IMMEDIATE;
GO
ALTER DATABASE [App1AG_DB2] SET  SINGLE_USER WITH ROLLBACK IMMEDIATE;
GO
ALTER DATABASE [App1AG_DB3] SET  SINGLE_USER WITH ROLLBACK IMMEDIATE;
GO

DROP DATABASE App1AG_DB1
GO
DROP DATABASE App1AG_DB2
GO
DROP DATABASE App1AG_DB3
GO

/* This is usually not necessary, but I have found some instances of the DB not going back into normal mode
on the primary after removing the AG. */
:Connect SERVER1

USE [master]
GO

IF (SELECT [state] FROM SYS.DATABASES WHERE name = 'App1AG_DB1') = 1
BEGIN
	RESTORE DATABASE App1AG_DB1
END

IF (SELECT [state] FROM SYS.DATABASES WHERE name = 'App1AG_DB2') = 1
BEGIN
	RESTORE DATABASE App1AG_DB2
END

IF (SELECT [state] FROM SYS.DATABASES WHERE name = 'App1AG_DB3') = 1
BEGIN
	RESTORE DATABASE App1AG_DB3
END