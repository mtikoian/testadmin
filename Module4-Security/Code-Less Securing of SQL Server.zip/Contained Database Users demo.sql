SELECT * FROM sys.configurations;
GO

EXEC sp_configure 'contained database authentication', 1;
GO

RECONFIGURE;
GO

USE [master]
GO
ALTER DATABASE [VendorDB] SET CONTAINMENT = PARTIAL WITH ROLLBACK IMMEDIATE;
GO

USE [VendorDB]
GO

EXEC sp_migrate_user_to_contained @username = N'sa',@rename = N'keep_name', @disablelogin = N'do_not_disable_login';
GO

SELECT * FROM sys.database_principals;
GO