/*

Event Notifications






Introduced in SQL Server 2005
A great alternative to DDL Triggers
Asynchronous! They don't run in the scope of a transaction that triggered them
No control over what data is captured
No GUI
Several moving parts



*/

-- what can we be notified on?
SELECT * FROM sys.event_notification_event_types


WITH DirectReports(name, parent_type, type, level, sort) AS 
(
    SELECT CONVERT(varchar(255),type_name), parent_type, type, 1, CONVERT(varchar(255),type_name)
    FROM sys.event_notification_event_types
    WHERE parent_type IS NULL
    UNION ALL
    SELECT  CONVERT(varchar(255), REPLICATE ('|      ' , level) + e.type_name),
        e.parent_type, e.type, level + 1,
    CONVERT (varchar(255), RTRIM(sort) + '|      ' + e.type_name)
    FROM sys.event_notification_event_types AS e
        INNER JOIN DirectReports AS d
        ON e.parent_type = d.type 
)
SELECT parent_type, type, name
FROM DirectReports
ORDER BY sort;


-- how do we use them?

-- first need to create a queue & service
USE [msdb];
GO


IF EXISTS (SELECT 1 FROM sys.services WHERE name = 'AlertService')
DROP SERVICE AlertService;

IF OBJECT_ID('AlertQueue') IS NOT NULL
	DROP QUEUE AlertQueue



-- create a service broker queue for the events
CREATE QUEUE AlertQueue;


-- create a service broker service to place events on the queue
CREATE SERVICE AlertService
ON QUEUE AlertQueue ([http://schemas.microsoft.com/SQL/Notifications/PostEventNotification]);


-- get service broker identifier for msdb database
--  (we will need this below)
SELECT service_broker_guid
FROM sys.databases
WHERE name = 'msdb';


-- create event notification
USE [DemoDB];
GO

CREATE EVENT NOTIFICATION CaptureDBEvents
ON DATABASE
WITH FAN_IN
FOR CREATE_INDEX
TO SERVICE 'AlertService','79892B59-26AB-4712-9A95-C1E0FCBE0DD3';
-- GUID will differ for every instance


-- create an index to trigger the event notification
IF EXISTS(SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID('dbo.Customers') 
	AND name = 'IX_CustomerCity')
	DROP INDEX IX_CustomerCity ON dbo.Customers;


CREATE INDEX IX_CustomerCity ON dbo.Customers (City);

-- see what was added to the queue
SELECT * FROM msdb.dbo.AlertQueue;

-- message_body has the payload - convert to XML
SELECT CONVERT(XML, message_body) AS MessageXML
FROM msdb.dbo.AlertQueue;



-- now it's on a queue - what to do with it?

-- create a stored procedure to pull from queue and do something
--  in this case, simulate sending an email
USE [msdb];
go

IF OBJECT_ID('dbo.ProcessNotifications') IS NOT NULL
	DROP PROCEDURE dbo.ProcessNotifications;
GO

CREATE PROCEDURE dbo.ProcessNotifications
WITH EXECUTE AS OWNER, ENCRYPTION 
-- ***if encrypting, make sure you save the source code somewhere!***
AS

SET NOCOUNT ON;
DECLARE @message_body XML;
DECLARE @email_message NVARCHAR(MAX);
DECLARE @email_subject NVARCHAR(MAX);
DECLARE @DBName NVARCHAR(128);
DECLARE @SchemaName NVARCHAR(128);
DECLARE @ObjectName NVARCHAR(128);

-- create table for storing email
-- for purposes of this demo only
IF(OBJECT_ID('dbo.DEMO_EmailTable') IS NULL)
CREATE TABLE dbo.DEMO_EmailTable (
	EmailSubject nvarchar(MAX),
	EmailMessage nvarchar(MAX)
);


WHILE (1=1) -- iterate through each row in the queue
BEGIN
	BEGIN TRAN;
	
	WAITFOR (
		RECEIVE TOP (1) @message_body = message_body
		FROM dbo.AlertQueue
	), TIMEOUT 1000 
	-- if nothing is found, quit
	IF (@@ROWCOUNT = 0)
	BEGIN
		ROLLBACK TRAN;
		BREAK;
	END
	
	-- pull object name values from message body
	-- these will be null if not found
	SELECT @DBName = @message_body.value('(/EVENT_INSTANCE/DatabaseName)[1]', 'varchar(128)');
	SELECT @SchemaName = @message_body.value('(/EVENT_INSTANCE/SchemaName)[1]', 'varchar(128)');
	SELECT @ObjectName = @message_body.value('(/EVENT_INSTANCE/ObjectName)[1]', 'varchar(128)');

	-- generate email message
	SELECT @email_message = 'Time: ' + @message_body.value('(/EVENT_INSTANCE/PostTime)[1]', 'varchar(128)') + CHAR(10) +
		'User: ' + @message_body.value('(/EVENT_INSTANCE/LoginName)[1]', 'varchar(128)') + CHAR(10) +
		'Object: ' + ISNULL(@DBName, '[SERVER LEVEL]') + '.' +
					 ISNULL(@SchemaName, '') + '.' +
					 ISNULL(@ObjectName, '[SERVER PERMISSION]') + CHAR(10) +
		'Statement: ' + @message_body.value('(/EVENT_INSTANCE/TSQLCommand/CommandText)[1]','nvarchar(max)');
		
	-- generate email subject
	SELECT @email_subject = @message_body.value('(/EVENT_INSTANCE/ServerName)[1]', 'varchar(128)') + '.' +
		ISNULL(@DBName, '') + ' - ' +
		@message_body.value('(/EVENT_INSTANCE/EventType)[1]', 'varchar(128)') + ' event';

	-- Normally you would send an email here, but email isn't configured in this environment
	/*
	EXEC msdb.dbo.sp_send_dbmail
		@profile_name = '<profile name>',
		@recipients = '<email addresses>',
		@subject = @email_subject,
		@body = @email_message;
	*/

	-- insert into our demo table instead
	INSERT INTO DEMO_EmailTable (EmailSubject, EmailMessage)
	VALUES (@email_subject, @email_message);


	COMMIT TRAN;
END -- while loop
GO


-- set this procedure to run on queue activation
-- (when a record is placed on the queue, it is called)
ALTER QUEUE [AlertQueue]
WITH STATUS=ON, 
ACTIVATION (
	STATUS=ON,
	PROCEDURE_NAME = [ProcessNotifications],
	MAX_QUEUE_READERS = 1,
	EXECUTE AS OWNER
);
GO


-- check the table
SELECT * FROM msdb.dbo.DEMO_EmailTable;


-- create a more general notification, like for all DB security events
USE [DemoDB]
GO

CREATE EVENT NOTIFICATION CaptureDBSecurityEvents
ON DATABASE
WITH FAN_IN
FOR DDL_DATABASE_SECURITY_EVENTS
TO SERVICE 'AlertService','79892B59-26AB-4712-9A95-C1E0FCBE0DD3';


-- create a role & alter some rights

CREATE ROLE TestRole AUTHORIZATION dbo;
EXEC sp_addrolemember 'db_owner','ReadOnlyDemoUser'
DENY REFERENCES ON dbo.Customers TO TestRole;

-- see what was captured & processed
SELECT * FROM msdb.dbo.DEMO_EmailTable;



-- limitations
-- not a good replacement for audit
-- AUDIT_SCHEMA_OBJECT_ACCESS_EVENT will pick up DML operations, but noisy
-- listens to all instances of an event - filter later






-- what about rollbacks?

BEGIN TRAN;

EXEC sp_droprolemember 'db_owner', 'ReadOnlyDemouser'

ROLLBACK

SELECT * FROM msdb.dbo.DEMO_EmailTable;




-- see all event notifications
SELECT * FROM sys.event_notifications


-- see all event notifications and what they listen for
SELECT
	en.name AS EventNotificationName,
	e.type_desc AS EventType,
	en.parent_class_desc AS ParentClass,
	en.service_name AS ServiceName,
	en.broker_instance AS BrokerInstance
FROM sys.event_notifications en
INNER JOIN sys.events e ON en.object_id = e.object_id
ORDER BY EventNotificationName, EventType;


-- works in any edition


-- clean up
DROP EVENT NOTIFICATION CaptureDBSecurityEvents ON DATABASE;
GO
DROP EVENT NOTIFICATION CaptureDBEvents ON DATABASE;
GO
