/*

Extended Events




Introduced in SQL Server 2008

can be more lightweight
better able to customize what is captured and filter it
SSMS 2012 has a GUI (for 2012 instances only)
Are used behind the scenes for SQL Audit

Packages
-Events
-Actions
-Predicates
-Targets



*/

-- Events that can be captured
SELECT p.name AS package_name,
       o.name AS event_name,
       o.description
FROM sys.dm_xe_packages AS p
JOIN sys.dm_xe_objects AS o 
     ON p.guid = o.package_guid
WHERE (p.capabilities IS NULL OR p.capabilities & 1 = 0)
  AND (o.capabilities IS NULL OR o.capabilities & 1 = 0)
  AND o.object_type = 'event'


  -- show creating session in GUI


-- create an XE session to capture login info
-- Also has some pretty easy-to-read syntax
CREATE EVENT SESSION [LoginActivity] ON SERVER 
ADD EVENT sqlserver.login(SET collect_database_name=(1)
    ACTION(sqlserver.client_app_name,sqlserver.client_hostname,sqlserver.session_id,sqlserver.username)) 
ADD TARGET package0.ring_buffer
WITH (MAX_MEMORY=4096 KB,EVENT_RETENTION_MODE=ALLOW_SINGLE_EVENT_LOSS,MAX_DISPATCH_LATENCY=5 SECONDS,
	MAX_EVENT_SIZE=0 KB,MEMORY_PARTITION_MODE=NONE,TRACK_CAUSALITY=OFF,STARTUP_STATE=OFF)
GO


-- view ring buffer results as a table
SELECT
	q.value('(@name)[1]','varchar(50)') AS EventName,
	DATEADD(hh, DATEDIFF(hh, GETUTCDATE(), CURRENT_TIMESTAMP), 
		q.value('(@timestamp)[1]', 'datetime2(3)')) AS EventTime,
	q.value('(action[@name="username"]/value)[1]', 'nvarchar(250)') AS Username,
	q.value('(action[@name="session_id"]/value)[1]', 'nvarchar(250)') AS SessionID,
	q.value('(action[@name="client_hostname"]/value)[1]', 'nvarchar(250)') AS ClientHostname,
	q.value('(action[@name="client_app_name"]/value)[1]', 'nvarchar(250)') AS ClientAppName
FROM (
	SELECT CONVERT(XML, target_data) AS target_data
	FROM sys.dm_xe_sessions s
	INNER JOIN sys.dm_xe_session_targets AS t ON t.event_session_address = s.address
	WHERE s.name = 'LoginActivity'
) AS xmldoc
CROSS APPLY target_data.nodes('RingBufferTarget/event') AS r(q)

ALTER EVENT SESSION [LoginActivity] ON SERVER STATE = start
GO


-- live data viewer









-- Can also log query activity
CREATE EVENT SESSION [QueryActivity] ON SERVER 
ADD EVENT sqlserver.module_start(SET collect_statement=(1)
    ACTION(sqlserver.client_app_name,sqlserver.database_name,sqlserver.session_id,sqlserver.sql_text,sqlserver.username,sqlserver.session_server_principal_name)
    WHERE [package0].[equal_boolean]([sqlserver].[is_system],(0))),
ADD EVENT sqlserver.rpc_starting(
    ACTION(sqlserver.client_app_name,sqlserver.database_name,sqlserver.session_id,sqlserver.sql_text,sqlserver.username,sqlserver.session_server_principal_name)
    WHERE [package0].[equal_boolean]([sqlserver].[is_system],(0))),
ADD EVENT sqlserver.sp_statement_starting(SET collect_object_name=(1)
    ACTION(sqlserver.client_app_name,sqlserver.database_name,sqlserver.session_id,sqlserver.sql_text,sqlserver.username,sqlserver.session_server_principal_name)
    WHERE [package0].[equal_boolean]([sqlserver].[is_system],(0))),
ADD EVENT sqlserver.sql_batch_starting(
    ACTION(sqlserver.client_app_name,sqlserver.database_name,sqlserver.session_id,sqlserver.sql_text,sqlserver.username,sqlserver.session_server_principal_name)
    WHERE [package0].[equal_boolean]([sqlserver].[is_system],(0))),
ADD EVENT sqlserver.sql_statement_starting(
    ACTION(sqlserver.client_app_name,sqlserver.database_name,sqlserver.session_id,sqlserver.sql_text,sqlserver.username,sqlserver.session_server_principal_name)
    WHERE [package0].[equal_boolean]([sqlserver].[is_system],(0))) 
ADD TARGET package0.event_file(SET filename=N'C:\Demos\QueryActivity.xel')
WITH (MAX_MEMORY=4096 KB,EVENT_RETENTION_MODE=ALLOW_SINGLE_EVENT_LOSS,MAX_DISPATCH_LATENCY=10 SECONDS,
	MAX_EVENT_SIZE=0 KB,MEMORY_PARTITION_MODE=NONE,TRACK_CAUSALITY=ON,STARTUP_STATE=ON)
GO

ALTER EVENT SESSION [QueryActivity] ON SERVER STATE = start
GO




-- view file results as a table
SELECT
    n.value('(@name)[1]', 'varchar(50)') AS event_name,
    DATEADD(hh, 
            DATEDIFF(hh, GETUTCDATE(), CURRENT_TIMESTAMP), 
            n.value('(@timestamp)[1]', 'datetime2(3)')) AS [timestamp],
	n.value('(data[@name="feature"]/value)[1]', 'varchar(max)') AS feature,
	n.value('(action[@name="client_app_name"]/value)[1]', 'varchar(max)') AS app,
	n.value('(action[@name="database_name"]/value)[1]', 'varchar(128)') AS dbid,
	n.value('(action[@name="username"]/value)[1]', 'varchar(max)') AS username,
	n.value('(action[@name="session_server_principal_name"]/value)[1]', 'varchar(max)') AS sessionserverprincipalname,
	n.value('(data[@name="statement"]/value)[1]', 'varchar(max)') AS stmt
FROM 
(SELECT
    CAST(event_data AS XML) AS event_data
 FROM sys.fn_xe_file_target_read_file('C:\Demos\QueryActivity*xel',NULL,NULL,NULL)
) as tab
CROSS APPLY event_data.nodes('event') as q(n)
ORDER BY [timestamp] DESC;




-- how about rollbacks?

-- delete a record and rollback
BEGIN TRAN;

DELETE FROM DemoDB.dbo.Customers WHERE id = 17;

ROLLBACK;






-- what about when an attempt fails?

-- impersonate another user
EXECUTE AS LOGIN = 'ReadOnlyDemoUser';

-- attempt to update a record (user does not  have permission)
UPDATE DemoDB.dbo.Customers SET FirstName = 'Clay' WHERE FirstName = 'Clayton'

REVERT; -- stop impersonating



SELECT TOP (20)
    n.value('(@name)[1]', 'varchar(50)') AS event_name,
    DATEADD(hh, 
            DATEDIFF(hh, GETUTCDATE(), CURRENT_TIMESTAMP), 
            n.value('(@timestamp)[1]', 'datetime2(3)')) AS [timestamp],
	n.value('(data[@name="feature"]/value)[1]', 'varchar(max)') AS feature,
	n.value('(action[@name="client_app_name"]/value)[1]', 'varchar(max)') AS app,
	n.value('(action[@name="database_name"]/value)[1]', 'varchar(128)') AS dbid,
	n.value('(action[@name="username"]/value)[1]', 'varchar(max)') AS username,
	n.value('(action[@name="session_server_principal_name"]/value)[1]', 'varchar(max)') AS sessionserverprincipalname,
	n.value('(data[@name="statement"]/value)[1]', 'varchar(max)') AS stmt
FROM 
(SELECT
    CAST(event_data AS XML) AS event_data
 FROM sys.fn_xe_file_target_read_file('C:\Demos\QueryActivity*xel',NULL,NULL,NULL)
) as tab
CROSS APPLY event_data.nodes('event') as q(n)
where n.value('(action[@name="client_app_name"]/value)[1]', 'varchar(max)') NOT LIKE '%intellisense%'
ORDER BY [timestamp] desc





-- what event sessions are there?
SELECT * FROM sys.server_event_sessions

-- sessions & events
SELECT s.name AS SessionName,
	se.name AS EventName,
	se.package AS PackageName,
	se.predicate
FROM sys.server_event_session_events se
INNER JOIN sys.server_event_sessions s ON s.event_session_id = se.event_session_id
