/*
Triggers













- The classic "when A happens then do B" of databases

- Found in every edition

- They execute in the same transaction as the operation that triggered them
--- Synchronous
--- Can roll back an operation

- 3 Flavors: DML and DDL (and login)

*/

-- DML Triggers (Insert, Update, Delete)


-- create a trigger that will automatically 
--  roll back deletes from a table
USE DemoDB;
GO

CREATE TRIGGER dbo.PreventDeletes
	ON dbo.Customers
	INSTEAD OF DELETE
AS
BEGIN
	RAISERROR ('Please don''t delete from this table!', 16, 1);
	ROLLBACK TRANSACTION;
END

-- check how many rows exist before (should be 9)
SELECT COUNT(*) FROM dbo.Customers WHERE ID < 10;

-- run delete
DELETE FROM dbo.Customers WHERE ID < 10;

-- check how many rows exist after (should be 9)
SELECT COUNT(*) FROM dbo.Customers WHERE ID < 10;

-- clean up
DROP TRIGGER dbo.PreventDeletes;




-- capture insert/update/delete operations via triggers
--  into another table vs. not capturing them

-- create tables
IF(OBJECT_ID('dbo.test_notrigger') IS NOT NULL)
	DROP TABLE dbo.test_notrigger;

CREATE TABLE dbo.test_notrigger (
	id INT PRIMARY KEY NOT NULL,
	val VARCHAR(50) NULL
);

IF(OBJECT_ID('dbo.test_trigger') IS NOT NULL)
	DROP TABLE dbo.test_trigger;

CREATE TABLE dbo.test_trigger (
	id INT PRIMARY KEY NOT NULL,
	val VARCHAR(50) NULL
);

IF(OBJECT_ID('dbo.test_trigger_results') IS NOT NULL)
	DROP TABLE dbo.test_trigger_results;

CREATE TABLE dbo.test_trigger_results (
	EventTime datetime2(0) NOT NULL,
	UserName NVARCHAR(128) NULL,
	RowID INT NOT NULL,
    Msg nvarchar(MAX) NOT NULL
);

-- create trigger to capture activity
IF(OBJECT_ID('dbo.trg') IS NOT NULL)
	DROP TRIGGER dbo.trg;
GO

CREATE TRIGGER dbo.trg ON dbo.test_trigger
AFTER INSERT,UPDATE,DELETE
as
begin
	DECLARE @InsertEvent BIT, @UpdateEvent BIT, @DeleteEvent BIT
	SELECT @InsertEvent = 0, @UpdateEvent = 0, @DeleteEvent = 0

	INSERT INTO dbo.test_trigger_results (EventTime, UserName, RowID, Msg)
	SELECT SYSDATETIME(), ORIGINAL_LOGIN(), #i.id, 'Updated'
	FROM INSERTED #i
	INNER JOIN DELETED #d ON #i.id = #d.id;

	INSERT INTO dbo.test_trigger_results (EventTime, UserName, RowID, Msg)
	SELECT SYSDATETIME(), ORIGINAL_LOGIN(), #i.id, 'Inserted'
	FROM INSERTED #i
	left JOIN DELETED #d ON #i.id = #d.id
	WHERE #d.id IS NULL;

	INSERT INTO dbo.test_trigger_results (EventTime, UserName, RowID, Msg)
	SELECT SYSDATETIME(), ORIGINAL_LOGIN(), #d.id, 'Deleted'
	FROM DELETED #d
	left JOIN INSERTED #i ON #i.id = #d.id
	WHERE #i.id IS NULL;
	

	-- could also do something like send an email here


END;


-- capture execution plan
-- insert values into both tables
INSERT INTO test_notrigger (id) VALUES (1),(2),(3),(4);

INSERT INTO test_trigger (id) VALUES (1),(2),(3),(4);


-- check captured results
SELECT * FROM dbo.test_trigger_results;

-- updates and deletes?
UPDATE dbo.test_trigger SET val='blah' WHERE id=3;
DELETE FROM dbo.test_trigger WHERE id=2;

-- check captured results
SELECT * FROM dbo.test_trigger_results;


-- we don't know what exactly was updated
-- what if primary key changes? or any other columns?
-- what if changes happen that DBAs don't know about?


-- handling rollbacks?

-- insert row into table and show trigger captured it
BEGIN TRAN;
INSERT INTO dbo.test_trigger (id) VALUES (7);
SELECT * FROM dbo.test_trigger_results;

-- roll it back
ROLLBACK;

-- check what was captured
SELECT * FROM dbo.test_trigger_results;



-- denials due to inappropriate permissions?

-- impersonate another user with read-only permissions
EXECUTE AS LOGIN = 'ReadOnlyDemoUser';

INSERT INTO dbo.test_trigger (id) VALUES (8);

REVERT; -- stop impersonating

-- check what was captured
SELECT * FROM dbo.test_trigger_results;





-- what if any other type of operation happens?


























-- DDL Triggers

-- introduced IN SQL Server 2005

-- types of DDL events that can be triggered on
SELECT * FROM sys.trigger_event_types


-- in hierarchical form
-- (from http://technet.microsoft.com/en-us/library/bb510452.aspx)
WITH DirectReports(name, parent_type, type, level, sort) AS 
(
    SELECT CONVERT(varchar(255),type_name), parent_type, type, 1, CONVERT(varchar(255),type_name)
    FROM sys.trigger_event_types 
    WHERE parent_type IS NULL
    UNION ALL
    SELECT  CONVERT(varchar(255), REPLICATE ('|      ' , level) + e.type_name),
        e.parent_type, e.type, level + 1,
    CONVERT (varchar(255), RTRIM(sort) + '|      ' + e.type_name)
    FROM sys.trigger_event_types AS e
        INNER JOIN DirectReports AS d
        ON e.parent_type = d.type 
)
SELECT parent_type, type, name
FROM DirectReports
ORDER BY sort;




-- EVENTDATA() function


-- create a DDL trigger and capture EVENTDATA() to a table
CREATE TABLE dbo.EventDataTest (
	EVENTDATA XML
)
GO

CREATE TRIGGER DDL_ED_Trg
ON DATABASE
FOR CREATE_TABLE
AS
INSERT INTO dbo.EventDataTest
SELECT EVENTDATA();


CREATE TABLE MyTestTable (
	id INT NOT NULL,
	NAME NVARCHAR(50) NOT NULL,
	AddDate DATETIME2(0) NOT NULL
);

-- see what was captured
SELECT * FROM dbo.EventDataTest;





-- can it handle impersonation?

-- impersonate another user
EXECUTE AS LOGIN = 'NonTrustedSysAdminUser';

CREATE TABLE MyTestTable2 (
	id INT NOT NULL,
	NAME NVARCHAR(50) NOT NULL,
	AddDate DATETIME2(0) NOT NULL
);

REVERT; -- stop impersonation

-- check what was captured
SELECT * FROM dbo.EventDataTest;





-- capture all database-level DDL
-- ***not a good idea!***

CREATE TABLE dbo.test_ddl_trigger_results (
	EventTime datetime2(0) NOT NULL,
	UserName NVARCHAR(128) NULL,
    Msg nvarchar(MAX) NOT NULL
);
GO

CREATE TRIGGER DDL_DB_Trg
ON DATABASE
FOR DDL_DATABASE_LEVEL_EVENTS
AS
INSERT INTO dbo.test_ddl_trigger_results (EventTime,UserName,Msg)
SELECT SYSDATETIME(), 
	ORIGINAL_LOGIN(), 
	EVENTDATA().value('(/EVENT_INSTANCE/TSQLCommand/CommandText)[1]','nvarchar(max)');
GO

CREATE TRIGGER DDL_Srv_Trg
ON ALL SERVER
FOR DDL_SERVER_LEVEL_EVENTS
AS
INSERT INTO dbo.test_ddl_trigger_results (EventTime,UserName,Msg)
SELECT SYSDATETIME(), ORIGINAL_LOGIN(), EVENTDATA().value('(/EVENT_INSTANCE/TSQLCommand/CommandText)[1]','nvarchar(max)');
GO


CREATE TABLE NewTable (
	a INT
);
    
SELECT * FROM dbo.test_ddl_trigger_results


-- clean up
DROP TRIGGER DDL_DB_Trg ON DATABASE;
DROP TRIGGER DDL_Srv_Trg ON ALL SERVER;





-- what about SELECT?
