-- demo environment setup

USE [msdb]
GO

IF(OBJECT_ID('dbo.DEMO_EmailTable') IS NOT NULL)
	DROP TABLE dbo.DeMO_EmailTable;
GO


USE [master]
GO


SET NOCOUNT ON;

-- drop server triggers
IF (SELECT 1 FROM sys.server_triggers WHERE name = 'DDL_Srv_Trg') IS NOT NULL
	DROP TRIGGER DDL_Srv_Trg ON ALL SERVER;

-- drop audits
IF (SELECT 1 FROM sys.server_audits WHERE name = 'DemoAudit') IS NOT NULL
BEGIN
	ALTER SERVER AUDIT [DemoAudit] WITH (STATE=OFF);
	DROP SERVER AUDIT [DemoAudit];
END




-- create db
IF DB_ID('DemoDB') IS NOT NULL
BEGIN
	ALTER DATABASE [DemoDB] SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
	DROP DATABASE [DemoDB];
END


CREATE DATABASE [DemoDB]
 CONTAINMENT = NONE
 ON  PRIMARY 
( NAME = N'DemoDB', FILENAME = N'C:\Demos\DemoDB.mdf' , SIZE = 10240KB , FILEGROWTH = 1024KB )
 LOG ON 
( NAME = N'DemoDB_log', FILENAME = N'C:\Demos\DemoDB.ldf' , SIZE = 3072KB , FILEGROWTH = 1MB)
GO
ALTER DATABASE [DemoDB] SET RECOVERY SIMPLE 
GO
USE [DemoDB]
GO
IF NOT EXISTS (SELECT name FROM sys.filegroups WHERE is_default=1 AND name = N'PRIMARY') ALTER DATABASE [DemoDB] MODIFY FILEGROUP [PRIMARY] DEFAULT
GO
ALTER AUTHORIZATION ON DATABASE::DemoDB TO sa;


-- create logins
USE [master]
GO

IF EXISTS (SELECT 1 FROM sys.server_principals WHERE name = 'ReadOnlyDemoUser' AND type = 's')
BEGIN
	DROP LOGIN ReadOnlyDemoUser;
END;
CREATE LOGIN [ReadOnlyDemoUser] WITH PASSWORD=N'ILike2Read!', DEFAULT_DATABASE=[master], CHECK_EXPIRATION=OFF, CHECK_POLICY=OFF


IF EXISTS (SELECT 1 FROM sys.server_principals WHERE name = 'NonTrustedSysadminUser' AND type = 's')
BEGIN
	DROP LOGIN NonTrustedSysadminUser;
END;
CREATE LOGIN [NonTrustedSysadminUser] WITH PASSWORD=N'Sn3akers*', DEFAULT_DATABASE=[master], CHECK_EXPIRATION=OFF, CHECK_POLICY=OFF
GO


-- create users
USE [DemoDB]
GO
CREATE USER [ReadOnlyDemoUser] FOR LOGIN [ReadOnlyDemoUser]
GO
ALTER ROLE [db_datareader] ADD MEMBER [ReadOnlyDemoUser]
GO
ALTER SERVER ROLE [sysadmin] ADD MEMBER [NonTrustedSysadminUser]
GO


-- create Customers table
USE DemoDB;
go

CREATE TABLE dbo.Customers (
	ID INT NOT NULL IDENTITY(1,1),
	LastName NVARCHAR(100) NOT NULL,
	FirstName NVARCHAR(50) NOT NULL,
	AddressLine1 NVARCHAR(100) NOT NULL,
	AddressLine2 NVARCHAR(100) NULL,
	City NVARCHAR(50) NOT NULL,
	StProvince NVARCHAR(50) NOT NULL,
	PostalCode NVARCHAR(15) NOT NULL,
	Country NVARCHAR(50) NOT NULL
);
GO


CREATE PROCEDURE dbo.LoadCustomers
AS
BEGIN
	SET NOCOUNT ON;
	
	-- insert 90 rows
	BEGIN TRANSACTION;

	TRUNCATE TABLE dbo.Customers;

	SET IDENTITY_INSERT [dbo].[Customers] ON
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (1, N'Oliver', N'Regina', N'36 W. Loudon Rd.', N'', N'St. Louis', N'Utah', N'86036', N'Tonga')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (2, N'Alexander', N'Roy', N'22 Gatesby Rd.', N'', N'Fort Worth', N'New Hampshire', N'98849', N'Cape Verde')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (3, N'Mueller', N'Dewayne', N'58 N. Bartram Rd.', N'', N'Denver', N'Wisconsin', N'18483', N'Guinea')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (4, N'Buckley', N'Beth', N'91 Kimbark Rd.', N'', N'Norfolk', N'Tennessee', N'07514', N'Estonia')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (5, N'Koch', N'Jolene', N'250 Kent Rd.', N'APT 74', N'Miami', N'Virginia', N'09047', N'Somalia')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (6, N'Gallagher', N'Nicolas', N'554 Des Plaines Ave.', N'', N'Columbus', N'South Dakota', N'21100', N'Malvinas')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (7, N'Mckinney', N'Tricia', N'50 Leesley Rd.', N'Suite 657', N'Jacksonville', N'New Jersey', N'15986', N'Liberia')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (8, N'Lucero', N'Hilary', N'48 Loudon Rd.', N'', N'Little Rock', N'Minnesota', N'05975', N'Kazakhstan')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (9, N'Henderson', N'Shane', N'864 Leesley Rd.', N'', N'Anaheim', N'Oklahoma', N'12879', N'Venezuela')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (10, N'Brennan', N'Linda', N'46 E. Repton Rd.Ridgewood Rd.', N'', N'Baltimore', N'Missouri', N'86163', N'Denmark')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (11, N'Perez', N'Marjorie', N'17 W. Pine Ave.', N'', N'Fremont', N'Oklahoma', N'04101', N'Congo')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (12, N'Harvey', N'Jenifer', N'21 Maplewood Rd.', N'', N'Virginia Beach', N'Delaware', N'20856', N'Philippines')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (13, N'Sutton', N'Olivia', N'803 Fairbank Rd.', N'41th Floor', N'Detroit', N'Pennsylvania', N'91041', N'Bulgaria')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (14, N'Shea', N'Damon', N'23 Berkeley Rd.', N'APT 23', N'Detroit', N'New Jersey', N'43313', N'Nepal')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (15, N'Preston', N'Alisa', N'76 Michaux Rd.', N'', N'Omaha', N'Georgia', N'85152', N'Micronesia')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (16, N'Rich', N'Elizabeth', N'601 Olmsted Rd.', N'', N'Jacksonville', N'Rhode Island', N'64228', N'Angola')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (17, N'Delgado', N'Felix', N'342 Northgate Rd.', N'', N'Bakersfield', N'Maryland', N'99414', N'Denmark')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (18, N'Dalton', N'Carmen', N'72 Berkeley Rd.', N'APT 91', N'San Antonio', N'Oklahoma', N'05507', N'Uzbekistan')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (19, N'Villanueva', N'Wendi', N'99 S. Bloomingbank Rd.', N'APT 6', N'Lincoln', N'Tennessee', N'53532', N'Timor-Leste')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (20, N'Merritt', N'Gerard', N'712 N. Barrypoint Rd.', N'', N'Nashville', N'New York', N'38161', N'Iran')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (21, N'Galloway', N'Sheryl', N'749 Burlington St.', N'', N'Omaha', N'New Mexico', N'67749', N'Tajikistan')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (22, N'Russell', N'Robbie', N'60 Riverside Rd.', N'APT 75', N'Dallas', N'Kentucky', N'57284', N'Slovenia')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (23, N'Holmes', N'Jody', N'28 Gage Rd.', N'', N'Yonkers', N'Alabama', N'42881', N'Guadeloupe')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (24, N'Daniel', N'Wendi', N'44 Des Plaines Ave.', N'', N'Jackson', N'Connecticut', N'98840', N'South Georgia')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (25, N'Donovan', N'Bradford', N'15 Forest Ave.', N'', N'Washington', N'Iowa', N'73218', N'Lebanon')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (26, N'Rice', N'Jamison', N'448 Lionel Rd.', N'', N'Stockton', N'Maryland', N'03785', N'North Korea')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (27, N'Mahoney', N'Scottie', N'71 Bloomingbank Rd.', N'32th Floor', N'Cleveland', N'California', N'75644', N'Slovenia')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (28, N'Nunez', N'Leonard', N'13 Olmsted Rd.', N'58th Floor', N'Jackson', N'Massachusetts', N'46948', N'New Caledonia')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (29, N'Acevedo', N'Darren', N'458 Harlem Ave.', N'Suite 16', N'Columbus', N'Hawaii', N'14637', N'Rwanda')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (30, N'Sanford', N'Devin', N'33 Maplewood Rd.', N'3rd Floor', N'San Jose', N'Virginia', N'71686', N'Macedonia')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (31, N'Collier', N'Rhonda', N'68 Herrick Rd.', N'', N'Houston', N'Massachusetts', N'94828', N'Burkina Faso')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (32, N'Mckee', N'Taryn', N'29 S. Delaplaine Rd.', N'Suite 452', N'Shreveport', N'Alaska', N'35710', N'Mauritania')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (33, N'Kemp', N'Annie', N'874 Barrypoint Rd.', N'', N'Kansas', N'Oklahoma', N'15379', N'Luxembourg')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (34, N'Thomas', N'Samantha', N'921 E. Southcote Rd.', N'', N'Baltimore', N'Connecticut', N'93420', N'Congo')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (35, N'Bright', N'Alvin', N'575 Northgate Rd.', N'', N'Oakland', N'Oregon', N'36641', N'Jamaica')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (36, N'Hurley', N'Donald', N'910 E. West Ave.', N'', N'Fort Wayne', N'Alaska', N'09904', N'Bermuda')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (37, N'Blanchard', N'Luke', N'131 Riverside Rd.', N'', N'Milwaukee', N'Alabama', N'12781', N'Niger')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (38, N'Peterson', N'Loren', N'471 Park Place', N'', N'Mobile', N'Mississippi', N'10402', N'South Korea')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (39, N'Cochran', N'Evan', N'84 Eastgrove Rd.', N'', N'Boston', N'Maine', N'09229', N'Philippines')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (40, N'Velasquez', N'Karla', N'24 Northgate Ct.', N'', N'Des Moines', N'Maine', N'16348', N'Libya')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (41, N'Schneider', N'Lynette', N'38 Eastgrove Rd.', N'', N'St. Louis', N'Colorado', N'49440', N'New Zealand')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (42, N'Bolton', N'Kathleen', N'386 Forbes Rd.', N'', N'San Jose', N'Maryland', N'70025', N'United Kingdom')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (43, N'Orozco', N'Kelly', N'339 Lionel Rd.', N'Suite 90', N'Fort Wayne', N'Nevada', N'60111', N'Panama')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (44, N'O''Connor', N'Kendra', N'565 Des Plaines Ave.', N'Appartment 2', N'Yonkers', N'West Virginia', N'93443', N'Colombia')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (45, N'Hubbard', N'Helen', N'367 Southcote Rd.', N'Appartment 126', N'Colorado', N'Arkansas', N'08059', N'Botswana')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (46, N'Tanner', N'Elena', N'855 York Rd.', N'6th Floor', N'Boston', N'Arkansas', N'67354', N'Sri Lanka')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (47, N'Eaton', N'Rochelle', N'32 Burling Rd.', N'Appartment 60', N'Houston', N'Maine', N'97933', N'Austria')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (48, N'French', N'Aaron', N'837 E. Loudon Rd.', N'', N'Mesa', N'Nevada', N'17355', N'Moldova')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (49, N'Jensen', N'Karen', N'154 Waubansee Rd.', N'APT 67', N'Las Vegas', N'Oregon', N'19535', N'Uganda')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (50, N'Fletcher', N'Jamie', N'909 Lionel Rd.', N'', N'Greensboro', N'Alabama', N'79523', N'Fiji')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (51, N'Montoya', N'Herman', N'38 Bloomingbank Rd.', N'', N'Arlington', N'Colorado', N'11015', N'Grenada')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (52, N'Rice', N'Erica', N'718 Gatesby Rd.', N'', N'Fremont', N'Michigan', N'31692', N'Gibraltar')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (53, N'Padilla', N'Courtney', N'65 Lionel Rd.', N'', N'Nashville', N'Wyoming', N'06013', N'Jamaica')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (54, N'Barry', N'Lakesha', N'62 Burling Rd.', N'', N'Buffalo', N'Oklahoma', N'75324', N'Bolivia')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (55, N'Stevenson', N'Abel', N'131 Downing Rd.', N'', N'Boston', N'Maryland', N'33187', N'Sierra Leone')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (56, N'Hicks', N'Kisha', N'642 N. Nuttall Rd.', N'', N'Denver', N'Nevada', N'76371', N'Belgium')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (57, N'Galloway', N'Courtney', N'75 Longcommon Rd.', N'', N'Honolulu', N'New Hampshire', N'19252', N'South Africa')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (58, N'Myers', N'Wanda', N'27 Nuttall Rd.', N'APT 596', N'Omaha', N'Tennessee', N'11713', N'Malawi')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (59, N'Gay', N'Gerard', N'21 Selborne Rd.', N'1st Floor', N'Tulsa', N'Nevada', N'45594', N'Senegal')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (60, N'Hogan', N'Justin', N'949 N. Bartram Rd.', N'Suite 5311', N'Aurora', N'Nebraska', N'88708', N'Cambodia')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (61, N'Harrell', N'Stephen', N'413 E. Northwood Rd.', N'', N'Anchorage', N'Oklahoma', N'74312', N'R�union')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (62, N'Phillips', N'Lewis', N'55 Forbes Rd.', N'', N'Atlanta', N'Georgia', N'03480', N'Sudan')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (63, N'Ellis', N'Marie', N'38 S. Evelyn Rd.', N'', N'Chicago', N'Illinois', N'32390', N'Paraguay')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (64, N'Silva', N'Ramon', N'801 Coonley Rd.', N'166th Floor', N'Omaha', N'South Dakota', N'31024', N'Jersey')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (65, N'Long', N'Alejandro', N'41 Kent Rd.', N'', N'Phoenix', N'California', N'97158', N'Barbados')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (66, N'Byrd', N'Sylvia', N'460 Arlington Rd.', N'Suite 5671', N'Seattle', N'North Dakota', N'40098', N'Namibia')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (67, N'Clayton', N'Leonard', N'641 Kent Rd.', N'Suite 55', N'Detroit', N'Minnesota', N'00911', N'Costa Rica')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (68, N'Chambers', N'Ricardo', N'52 S. Forest Ave.', N'', N'Little Rock', N'New Mexico', N'46515', N'United States')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (69, N'Kidd', N'Jimmie', N'58 W. Delaplaine Rd.', N'Suite 557', N'Jersey', N'Texas', N'49847', N'Costa Rica')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (70, N'Nixon', N'Candice', N'658 Bloomingbank Rd.', N'', N'Buffalo', N'Delaware', N'24011', N'Kyrgyzstan')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (71, N'Michael', N'Trisha', N'273 Des Plaines Ave.', N'', N'Fort Wayne', N'Rhode Island', N'34513', N'Guyana')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (72, N'Garza', N'Christy', N'19 Parkway Rd.', N'', N'Memphis', N'Virginia', N'34458', N'Hungary')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (73, N'Henderson', N'Shauna', N'328 E. Millbridge Rd.', N'', N'Dayton', N'Louisiana', N'31007', N'Ecuador')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (74, N'Weaver', N'Rebecca', N'65 Woodside Rd.', N'', N'Los Angeles', N'Mississippi', N'67290', N'Iceland')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (75, N'Juarez', N'Clarence', N'165 Parkview Rd.', N'Appartment 49', N'Garland', N'Nebraska', N'40246', N'Saint Lucia')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (76, N'Benitez', N'Brett', N'15 Burlington St.', N'', N'Virginia Beach', N'Idaho', N'79847', N'United Kingdom')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (77, N'Manning', N'Jonathan', N'52 Southcote Rd.', N'', N'San Antonio', N'Rhode Island', N'33248', N'Bhutan')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (78, N'Howe', N'Kristen', N'820 York Rd.', N'', N'Arlington', N'Arizona', N'79181', N'Chile')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (79, N'Joyce', N'Stephanie', N'35 Olmsted Rd.', N'', N'New Orleans', N'Arizona', N'51724', N'Paraguay')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (80, N'Stevens', N'Bart', N'59 Shenstone Rd.', N'', N'Arlington', N'Hawaii', N'24466', N'New Caledonia')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (81, N'Lindsey', N'Derrick', N'21 Parkway Rd.', N'', N'Anchorage', N'Alabama', N'88717', N'Mozambique')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (82, N'Cohen', N'Chadwick', N'298 E. Parkview Rd.', N'', N'Anchorage', N'Nevada', N'18446', N'Djibouti')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (83, N'Peterson', N'Tyrone', N'80 N. Fairbank Rd.', N'', N'Jacksonville', N'North Dakota', N'52902', N'Pitcairn')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (84, N'Hartman', N'Terry', N'27 Scottswood Rd.', N'APT 4', N'Philadelphia', N'Georgia', N'76868', N'Latvia')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (85, N'Klein', N'Rick', N'934 Selborne Rd.', N'1st Floor', N'Baltimore', N'South Dakota', N'65551', N'Congo')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (86, N'O''Connor', N'Max', N'40 Parkview Rd.', N'7th Floor', N'San Diego', N'Wisconsin', N'27796', N'Somalia')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (87, N'Griffith', N'Moses', N'231 Quincy St.', N'', N'Wichita', N'Arizona', N'46127', N'Brazil')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (88, N'Garcia', N'Bridget', N'667 W. Lionel Rd.', N'', N'Des Moines', N'Wyoming', N'11537', N'Iceland')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (89, N'Hensley', N'Yesenia', N'348 Groveland Rd.', N'', N'Glendale', N'Pennsylvania', N'41139', N'Hungary')
	INSERT INTO [dbo].[Customers] ([ID], [LastName], [FirstName], [AddressLine1], [AddressLine2], [City], [StProvince], [PostalCode], [Country]) VALUES (90, N'Fry', N'Travis', N'320 N. Parkway Rd.', N'3rd Floor', N'Indianapolis', N'Georgia', N'42014', N'Guadeloupe')
	SET IDENTITY_INSERT [dbo].[Customers] OFF
	COMMIT TRANSACTION
END

GO


EXEC dbo.LoadCustomers;
