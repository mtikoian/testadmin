USE master;
GO 

IF EXISTS(SELECT name FROM sys.databases WHERE name = 'TestSecurityDB')
  DROP DATABASE [TestSecurityDB];
GO 

IF EXISTS(SELECT name FROM sys.server_principals WHERE name = 'UserDefinedServerRole')
  DROP SERVER ROLE [UserDefinedServerRole];
GO 

IF EXISTS(SELECT name FROM sys.server_principals WHERE name='SecurityAdminLogin')
  DROP LOGIN [SecurityAdminLogin];
GO 

IF EXISTS(SELECT name FROM sys.server_principals WHERE name='MappedLogin')
  DROP LOGIN [MappedLogin];
GO 
