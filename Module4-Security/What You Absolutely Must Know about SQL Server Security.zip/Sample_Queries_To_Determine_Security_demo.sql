-- Member of sysadmin or securityadmin
EXEC sp_helpsrvrolemember 'sysadmin';
EXEC sp_helpsrvrolemember 'securityadmin';
GO 

-- User-defined server roles
SELECT [name] 
FROM sys.server_principals
WHERE type = 'R'
  AND principal_id > 10; -- End of built-in roles

-- Find who has CONTROL permissions
SELECT p.state_desc, p.permission_name, l.name 
FROM sys.server_permissions AS p
  JOIN sys.server_principals AS l
    ON p.grantee_principal_id = l.principal_id
WHERE p.type = 'CL';

-- Find who can connect to SQL Server
SELECT p.state_desc, p.permission_name, l.name 
FROM sys.server_permissions AS p
  JOIN sys.server_principals AS l
    ON p.grantee_principal_id = l.principal_id
WHERE p.type = 'COSQ';

-- Determine Database Owners (server level)
SELECT d.name AS 'Database_Name', l.name AS 'Owner_Name'
FROM sys.databases AS d
  LEFT JOIN sys.server_principals AS l
    ON d.owner_sid = l.sid;

-- Determine Database Owners (database level)
USE TestSecurityDB;
GO 

SELECT u.name AS 'Database_User', l.name AS 'Login'
FROM sys.database_principals AS u
  LEFT JOIN sys.server_principals AS l
    ON u.sid = l.sid
WHERE u.name = 'dbo';

-- Check members of the various database roles
EXEC sp_helprolemember 'db_owner';
EXEC sp_helprolemember 'db_ddladmin';
EXEC sp_helprolemember 'db_securityadmin';

-- Who can connect to the DB
SELECT p.state_desc, p.permission_name, u.name 
FROM sys.database_permissions AS p
  JOIN sys.database_principals AS u
    ON p.grantee_principal_id = u.principal_id
WHERE p.type = 'CO'
  AND p.class = 0;

-- Who has CONTROL permission
SELECT p.state_desc, p.permission_name, u.name 
FROM sys.database_permissions AS p
  JOIN sys.database_principals AS u
    ON p.grantee_principal_id = u.principal_id
WHERE p.type = 'CL'
  AND p.class = 0;

-- Check backup history but not completely accurate
USE msdb;
GO 

SELECT database_name, backup_start_date,
  CASE type
    WHEN 'D' THEN 'Full'
	WHEN 'I' THEN 'Differential'
	WHEN 'L' THEN 'Transaction Log'
	WHEN 'F' THEN 'Filegroup'
	ELSE 'Look up in BOL: ' + type END AS 'backup_type'
FROM dbo.backupset;

-- Check recovery model on the databases
SELECT name, recovery_model_desc 
FROM sys.databases;

-- Show there is encrypted data for this demo
USE TestSecurityDB;
GO 

SELECT PersonName, SSN FROM dbo.SampleData;
SELECT PersonName, 
  CONVERT(VARCHAR(20), DECRYPTBYKEYAUTOASYMKEY(ASYMKEY_ID('Asym_Key'), NULL, SSN))
FROM dbo.SampleData;

-- Detect Evidence of Encryption
SELECT name, algorithm_desc, create_date 
FROM sys.symmetric_keys;

SELECT name, algorithm_desc
FROM sys.asymmetric_keys;

SELECT name, subject, start_date, expiry_date
FROM sys.certificates;

-- Determine if Databases are using Transparent Data Encryption
SELECT name, is_encrypted 
FROM sys.databases;
