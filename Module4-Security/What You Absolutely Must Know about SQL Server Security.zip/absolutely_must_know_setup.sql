IF EXISTS(SELECT name FROM sys.sql_logins WHERE name = 'SecurityAdminLogin')
  DROP LOGIN [SecurityAdminLogin];

CREATE LOGIN [SecurityAdminLogin] WITH PASSWORD = 'AStr0ngPa$$w0rd!';
GO 

EXEC sp_addsrvrolemember @loginame = 'SecurityAdminLogin', @rolename = 'SecurityAdmin';
GO 

CREATE SERVER ROLE [UserDefinedServerRole];
GO 

GRANT CONTROL SERVER TO [UserDefinedServerRole];
GO 

IF EXISTS(SELECT name FROM sys.databases WHERE name = 'TestSecurityDB')
  DROP DATABASE [TestSecurityDB];
GO

CREATE DATABASE [TestSecurityDB];
GO 

ALTER AUTHORIZATION ON DATABASE::[TestSecurityDB] TO [sa];
GO 

CREATE LOGIN [MappedLogin] WITH PASSWORD = 'AStr0ngPa$$w0rd!';

USE [TestSecurityDB];
GO 

CREATE USER [MappedLogin] FROM LOGIN [MappedLogin];
GO 

CREATE USER [dbowner_level] WITHOUT LOGIN;
CREATE USER [ddladmin_level] WITHOUT LOGIN;
CREATE USER [dbsecurity_level] WITHOUT LOGIN;
GO 

EXEC sp_addrolemember @membername = 'dbowner_level', @rolename = 'db_owner';
EXEC sp_addrolemember @membername = 'ddladmin_level', @rolename = 'db_ddladmin';
EXEC sp_addrolemember @membername = 'dbsecurity_level', @rolename = 'db_securityadmin';
GO 

GRANT CONTROL ON DATABASE::[TestSecurityDB] TO [MappedLogin];
GO 

CREATE MASTER KEY ENCRYPTION BY PASSWORD = 'AStr0ngPa$$w0rd!';
GO 

CREATE ASYMMETRIC KEY [ASym_Key] 
WITH ALGORITHM = RSA_2048;
GO 

CREATE SYMMETRIC KEY [Sym_Key]
WITH ALGORITHM = AES_256 
ENCRYPTION BY ASYMMETRIC KEY [ASym_Key];
GO 

CREATE TABLE [dbo].[SampleData]
(PersonName VARCHAR(255),
 SSN VARBINARY(256));
GO 

OPEN SYMMETRIC KEY [Sym_Key]
DECRYPTION BY ASYMMETRIC KEY [ASym_Key];
GO 

INSERT INTO dbo.SampleData 
(PersonName, SSN)
VALUES
('John Doe', ENCRYPTBYKEY(KEY_GUID('Sym_Key'), '111-11-1111'));

INSERT INTO dbo.SampleData 
(PersonName, SSN)
VALUES
('Jane Doe', ENCRYPTBYKEY(KEY_GUID('Sym_Key'), '999-99-9999'));
GO 

BACKUP DATABASE [TestSecurityDB] TO DISK = N'C:\temp\TestSecurityDB.BAK';
GO 
