-- SQL Server Audit

-- what can be audited?
SELECT * FROM sys.dm_audit_actions



-- audits come in 3 parts
-- audit
-- database audit specification
-- server audit specification

-- creating audits in GUI






-- creating audits with T-SQL

USE Master
GO

CREATE SERVER AUDIT [DemoAudit]
TO FILE 
(	FILEPATH = N'C:\Demos'
	,MAXSIZE = 1 GB
	,MAX_ROLLOVER_FILES = 5
	,RESERVE_DISK_SPACE = OFF
)
WITH
(	QUEUE_DELAY = 1000
	,ON_FAILURE = CONTINUE
)
GO


-- create database audit specification
USE DemoDB
GO

CREATE DATABASE AUDIT SPECIFICATION [DemoDBAudit]
FOR SERVER AUDIT [DemoAudit]
ADD (SELECT ON DATABASE::[DemoDB] BY [public]),
ADD (DELETE ON DATABASE::[DemoDB] BY [public]),
ADD (INSERT ON DATABASE::[DemoDB] BY [public]),
ADD (UPDATE ON DATABASE::[DemoDB] BY [public]),
ADD (SCHEMA_OBJECT_CHANGE_GROUP),
ADD (DATABASE_PERMISSION_CHANGE_GROUP),
ADD (AUDIT_CHANGE_GROUP);


-- enable audit & audit specification
USE master
go

ALTER SERVER AUDIT [DemoAudit] WITH (STATE=ON);


USE DemoDB
go

ALTER DATABASE AUDIT SPECIFICATION DemoDBAudit WITH (STATE=ON);




-- run some queries
CREATE INDEX IX_LastName ON dbo.Customers (LastName);

GRANT SHOWPLAN TO ReadOnlyDemoUser;

EXEC dbo.LoadCustomers;




-- looking at results

SELECT * 
FROM sys.fn_get_audit_file('C:\Demos\DemoAudit*',NULL,NULL);


SELECT 
	DATEADD(hh, DATEDIFF(hh, GETUTCDATE(), CURRENT_TIMESTAMP), event_time) AS EventTime,
	action_id,
	succeeded,
	session_server_principal_name,
	target_server_principal_name,
	server_instance_name,
	database_name,
	schema_name,
	object_name,
	statement
FROM sys.fn_get_audit_file('C:\Demos\DemoAudit*',NULL,NULL);





-- filtering (SQL 2012)
/*
CREATE SERVER AUDIT [DemoAudit]
TO FILE 
(	FILEPATH = N'C:\Demos'
	,MAXSIZE = 0 GB
	,MAX_ROLLOVER_FILES = 2147483647
	,RESERVE_DISK_SPACE = OFF
)
WITH
(	QUEUE_DELAY = 1000
	,ON_FAILURE = CONTINUE
)
WHERE SERVER_PRINCIPAL_ID = 301
GO

*/







-- what if person's query fails due to lack of permissions?

-- impersonate another user
EXECUTE AS LOGIN = 'ReadOnlyDemoUser';
GO

-- perform a delete (they don't have rights to do this)
DELETE FROM dbo.Customers
WHERE ID = 11;

REVERT; -- stop impersonating

-- see what was captured
SELECT TOP (10)
	DATEADD(hh, DATEDIFF(hh, GETUTCDATE(), CURRENT_TIMESTAMP), event_time) AS EventTime,
	action_id,
	succeeded,
	session_server_principal_name,
	server_principal_name,
	target_server_principal_name,
	server_instance_name,
	database_name,
	schema_name,
	object_name,
	statement
FROM sys.fn_get_audit_file('C:\Demos\DemoAudit*',NULL,NULL)
ORDER BY event_time DESC;




-- rollbacks?

-- delete a row, but rollback before it commits
BEGIN TRAN;

DELETE FROM dbo.Customers
WHERE ID = 12;

ROLLBACK;


-- see what was captured
SELECT TOP (10)
	DATEADD(hh, DATEDIFF(hh, GETUTCDATE(), CURRENT_TIMESTAMP), event_time) AS EventTime,
	action_id,
	succeeded,
	session_server_principal_name,
	target_server_principal_name,
	server_instance_name,
	database_name,
	schema_name,
	object_name,
	statement
FROM sys.fn_get_audit_file('C:\Demos\DemoAudit*',NULL,NULL)
ORDER BY event_time DESC;


-- yep, rows are still there
SELECT * FROM dbo.Customers WHERE ID IN (11,12);


-- clean up
USE [DemoDB]
GO
ALTER DATABASE AUDIT SPECIFICATION [DemoDBAudit]
WITH (STATE = OFF)
GO
DROP DATABASE AUDIT SPECIFICATION [DemoDBAudit]
GO

USE [master]
GO
ALTER SERVER AUDIT [DemoAudit]
WITH (STATE = OFF)
GO
DROP SERVER AUDIT [DemoAudit]
GO
