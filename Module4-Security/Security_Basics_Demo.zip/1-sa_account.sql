-- security tips for 'sa' login




-- If you can, disable it!

ALTER LOGIN [sa] DISABLE;
GO



-- If you can't disable, create a different one!
-- change name of sa account to something different

ALTER LOGIN [sa] WITH NAME = original_sa;
GO


-- create a new sa account with fewer rights :)

CREATE LOGIN [sa] WITH PASSWORD=N'passw0rd', DEFAULT_DATABASE=[master], CHECK_EXPIRATION=OFF, CHECK_POLICY=OFF
GO


SELECT * FROM sys.server_principals
