USE [master]
GO
/*
USE [master]
GO
DROP LOGIN [denyuser] 
go
use securitydemo
go
DROP USER [denyuser]
drop view dbo.denyusertableview 
drop table dbo.denyusertable 
drop proc dbo.denyusertablesproc
drop proc dbo.denyusertablesproc_adhoc
*/
use master
go
CREATE LOGIN [denyuser] WITH PASSWORD=N'deny', DEFAULT_DATABASE=[master], CHECK_EXPIRATION=OFF, CHECK_POLICY=OFF
GO
GRANT CONNECT SQL TO [denyuser]
ALTER LOGIN [denyuser] ENABLE
GO
use securitydemo
go
CREATE USER [denyuser] FOR LOGIN [denyuser]
GO
create table dbo.denyusertable (
id int identity(1,1) not null primary key,
text1 varchar(100)
)
go
insert into denyusertable (text1) values ('test')
go 10
go

create view dbo.denyusertableview with schemabinding as
select selectview = text1 from dbo.denyusertable 
go


grant select on dbo.denyusertableview to [denyuser]
go

deny select on dbo.denyusertable to [denyuser]
go

create proc dbo.denyusertablesproc as
begin
select execsproc = text1 
from dbo.denyusertable 
end
GO

grant execute on dbo.denyusertablesproc to [denyuser]
GO

deny select to [denyuser] --on the entire database!
go

revoke select to [denyuser]
go


create proc dbo.denyusertablesproc_adhoc as
begin
declare @sql nvarchar(1000)
select @sql = 'select execsproc_adhoc = text1 from dbo.denyusertable'
exec sp_executesql @SQL
end
go
grant execute on dbo.denyusertablesproc_adhoc to [denyuser]
GO


