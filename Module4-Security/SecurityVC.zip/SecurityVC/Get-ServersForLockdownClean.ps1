## Get servers still needing new MSSQL security model ##
## Requires SQLPSX functions from http://sqlpsx.codeplex.com
## .\My Documents\Backup\Scripts\PowerShell\Get-ServersForLockdown.ps1

#[reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo") | out-null

import-module adolib
import-module SQLServer
import-module SQLParser
import-module Showmbrs
<#
import-module Agent
import-module Repl
import-module SSIS
import-module SQLMaint
import-module SQLProfiler
import-module PerfCounters
#>

$serverName = "SERVERNAME\InstanceName, Port"
$databaseName = "DatabaseInventory"

# here string contains SQL query
$qry = @"
SELECT  DISTINCT
        ISNULL(A.MACH_LPAR_NM, '') + CASE a.INST_NM
                                       WHEN 'DEFAULT' THEN ''
                                       ELSE '\'
                                     END + CASE a.INST_NM
                                             WHEN 'DEFAULT' THEN ''
                                             ELSE ISNULL(a.INST_NM, '')
                                           END + ','
        + ISNULL(CAST(A.PORT_NUM AS VARCHAR(6)),0) AS InstanceName
FROM    DatabaseInventory.dbo.v_all_metrics_inst a
        JOIN DatabaseInventory.dbo.T_DB_REL_ASSOC b ON a.mach_lpar_id = b.MACH_LPAR_ID
                                              AND a.inst_nm = b.INST_NM
WHERE   a.instobj_env_typ = 'PRD'
        AND a.dbms_cd = 'SQL'
        AND a.mach_lpar_nm NOT LIKE 'METINT%'
"@

$Servers = Get-SqlData $serverName $databaseName $qry

#$Servers = "SERVERNAME\InstanceName, Port"

$FilePath = "C:\Output"
#$OutFile = Join-Path -path $FilePath -childPath ("ServersNeedingLockdown_" + (get-date).toString('yyyyMMdd_hhmmtt') + ".csv")
$OutFile = Join-Path -path $FilePath -childPath ("ServersNeedingLockdown_" + (get-date).toString('yyyyMMdd_hhmmtt') + ".txt")


$databasename = "master"
$qry = @"
SELECT  @@SERVERNAME ServerName, COUNT(*) SysadminLogins
FROM    sys.server_principals SP1
        JOIN sys.server_role_members SRM ON SP1.principal_id = SRM.member_principal_id
        JOIN sys.server_principals SP2 ON SRM.role_principal_id = SP2.principal_id
WHERE SP2.name = 'sysadmin'
AND (SP1.name LIKE '%DBA%' AND SP1.name NOT LIKE '%BSG_GRP_MSSQL_DBATools'AND SP1.name <> 'DBAPRISE')
"@

# Get list of servers that haven't been locked down by new MSSQL Security Model.
@(foreach ($svr in $Servers)
{
	trap {"Oops! Query failed. $_"; continue } Get-SqlData $svr.InstanceName $databaseName $qry

})  | where { $_.SysadminLogins -NE 0} | Out-File $OutFile #| export-csv -noType $OutFile  #Out-File $OutFile
