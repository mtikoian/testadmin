-- Clean up Login Created to demonstrate CONTROL SERVER
DROP LOGIN JohnCena;

-- Clean up database used to demonstrate schema permissions
DROP DATABASE FortressSQLServer;
GO
