USE FortressSQLServer;
GO

CREATE USER [NoPermissions] WITHOUT LOGIN;
GO

-- This will fail. No permissions.
EXECUTE AS USER = 'NoPermissions';
GO 

SELECT * FROM [Accomodations].[Cabin];
GO

REVERT;
GO

EXECUTE AS USER = 'NoPermissions';
GO 

-- This will fail, too. Again, no permissions
DECLARE @Result INT;

EXECUTE @Result = [Business].[ScheduleReservation]
  @CabinID = 2,
  @StartDate = '2009-04-18',
  @EndDate = '2009-04-19';

SELECT @Result;
GO

REVERT;
GO

-- This will also fail. No permissions.
EXECUTE AS USER = 'JaneSmith';
GO 

SELECT * FROM [Accomodations].[CabinAvailability];
GO

REVERT;
GO

-- This will work! The user has EXECUTE rights on the Business schema.
EXECUTE AS USER = 'JaneSmith';
GO 

DECLARE @Result INT;

EXECUTE @Result = [Business].[ScheduleReservation]
  @CabinID = 2,
  @StartDate = '2009-04-18',
  @EndDate = '2009-04-19';

SELECT @Result;
GO

REVERT;
GO

SELECT CabinID, AvailabilityDate, AvailabilityFlag FROM [Accomodations].[CabinAvailability];
SELECT CabinID, StartDate, EndDate FROM [Business].[Reservation];

USE MASTER;
GO
