USE master;
GO

EXEC sp_helpsrvrolemember 'sysadmin';
GO

CREATE LOGIN [JohnCena] WITH PASSWORD = 'YouCantSeeMe!';
GO

GRANT CONTROL SERVER TO [JohnCena];
GO

EXEC sp_helpsrvrolemember 'sysadmin';
GO

SELECT 
  prin.name [Login], 
  perm.permission_name, 
  perm.state_desc 
FROM sys.server_permissions perm
  JOIN sys.server_principals prin
    ON perm.grantee_principal_id = prin.principal_id
ORDER BY [Login], permission_name
GO