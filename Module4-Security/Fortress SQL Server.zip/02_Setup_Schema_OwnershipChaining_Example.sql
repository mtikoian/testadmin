-- Create the database and a sample user to test with
CREATE DATABASE FortressSQLServer;
GO

USE FortressSQLServer;
GO

CREATE USER JaneSmith WITHOUT LOGIN;
GO

-- Build two different schema to show ownership chaining
CREATE SCHEMA Business AUTHORIZATION dbo;
GO
CREATE SCHEMA Accomodations AUTHORIZATION dbo;
GO

-- Create database roles to manage security
CREATE ROLE ReservationAgent;
GRANT EXECUTE ON SCHEMA::Business TO ReservationAgent;
EXEC sys.sp_addrolemember 'ReservationAgent', 'JaneSmith';
GO

-- Build objects for accomodations
CREATE TABLE [Accomodations].[Park]
(
	ParkID INT NOT NULL PRIMARY KEY CLUSTERED,
	ParkName VARCHAR(50) NOT NULL
);
GO

INSERT INTO [Accomodations].[Park] (ParkID, ParkName) VALUES (1, 'Barnwell State Park');
INSERT INTO [Accomodations].[Park] (ParkID, ParkName) VALUES (2, 'Edisto Beach State Park');
GO

SELECT ParkID, ParkName FROM [Accomodations].[Park];
GO

CREATE TABLE [Accomodations].[Cabin] 
(
	CabinID INT NOT NULL PRIMARY KEY CLUSTERED,
	ParkID INT NOT NULL,
	CabinNumber INT NOT NULL,
	CONSTRAINT FK_Cabin_Park FOREIGN KEY (ParkID) REFERENCES [Accomodations].[Park] (ParkID)
);
GO

INSERT INTO [Accomodations].[Cabin] (CabinID, ParkID, CabinNumber) VALUES (1, 1, 1);
INSERT INTO [Accomodations].[Cabin] (CabinID, ParkID, CabinNumber) VALUES (2, 1, 2);
INSERT INTO [Accomodations].[Cabin] (CabinID, ParkID, CabinNumber) VALUES (3, 2, 1);
INSERT INTO [Accomodations].[Cabin] (CabinID, ParkID, CabinNumber) VALUES (4, 2, 2);
GO

SELECT CabinID, ParkID, CabinNumber FROM [Accomodations].[Cabin];
GO

CREATE TABLE [Accomodations].[CabinAvailability]
(
	CabinID INT NOT NULL,
	AvailabilityDate SMALLDATETIME NOT NULL,
	AvailabilityFlag CHAR(1) NOT NULL DEFAULT 'Y',
	CONSTRAINT PK_CabinAvailability PRIMARY KEY CLUSTERED (AvailabilityDate, CabinID)
);
GO

INSERT INTO [Accomodations].[CabinAvailability] (CabinID, AvailabilityDate) VALUES (1, '2009-04-18');
INSERT INTO [Accomodations].[CabinAvailability] (CabinID, AvailabilityDate) VALUES (1, '2009-04-19');
INSERT INTO [Accomodations].[CabinAvailability] (CabinID, AvailabilityDate) VALUES (2, '2009-04-18');
INSERT INTO [Accomodations].[CabinAvailability] (CabinID, AvailabilityDate) VALUES (2, '2009-04-19');
INSERT INTO [Accomodations].[CabinAvailability] (CabinID, AvailabilityDate) VALUES (3, '2009-04-18');
INSERT INTO [Accomodations].[CabinAvailability] (CabinID, AvailabilityDate) VALUES (3, '2009-04-19');
INSERT INTO [Accomodations].[CabinAvailability] (CabinID, AvailabilityDate) VALUES (4, '2009-04-18');
INSERT INTO [Accomodations].[CabinAvailability] (CabinID, AvailabilityDate) VALUES (4, '2009-04-19');
GO

SELECT CabinID, AvailabilityDate, AvailabilityFlag FROM [Accomodations].[CabinAvailability];
GO


CREATE TABLE [Business].[Reservation]
(
	ReservationID INT NOT NULL IDENTITY(1,1) PRIMARY KEY,
	CabinID INT NOT NULL,
	StartDate SMALLDATETIME NOT NULL,
	EndDate SMALLDATETIME NOT NULL,
	CONSTRAINT FK_Reservation_Cabin FOREIGN KEY (CabinID) REFERENCES [Accomodations].[Cabin] (CabinID)
);
GO

CREATE PROC [Business].[ScheduleReservation]
  @CabinID INT,
  @StartDate SMALLDATETIME,
  @EndDate SMALLDATETIME
AS
	BEGIN
	  SET NOCOUNT ON;
	  
	  IF NOT EXISTS (SELECT AvailabilityFlag FROM [Accomodations].[CabinAvailability] WHERE AvailabilityFlag = 'N' AND CabinID = @CabinID AND AvailabilityDate BETWEEN @StartDate AND @EndDate)
		  BEGIN
			  BEGIN TRAN;
			  
			  INSERT INTO [Business].[Reservation] (CabinID, StartDate, EndDate) VALUES (@CabinID, @StartDate, @EndDate);
			  
			  UPDATE [Accomodations].[CabinAvailability] 
			  SET AvailabilityFlag = 'N'
			  WHERE AvailabilityDate BETWEEN @StartDate AND @EndDate
			  AND CabinID = @CabinID;
			  
			  COMMIT TRAN;
			  
			  RETURN(0);
		  END;
	  ELSE
	    RETURN(1);
	END;
GO

USE MASTER;
GO
