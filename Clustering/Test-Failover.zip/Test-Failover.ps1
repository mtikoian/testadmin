﻿$command = 'SELECT COUNT(*) As [Count] FROM dbo.TestTable';

$conn = New-Object System.Data.SqlClient.SqlConnection;

$connString = "Server = CSLAB-SQLVM01; Failover Partner = CSLAB-SQLVM03; Database = TestMirroring; Integrated Security = True;";

$conn.ConnectionString = $connString;
$conn.Open();
if ($conn.State -eq 1)
{
	$cmd = New-Object System.Data.SqlClient.SqlCommand $command, $conn;
	if ($cmd)
	{
		$data = New-Object System.Data.SqlClient.SqlDataAdapter;
		if ($data)
		{
			$ds = New-Object System.Data.DataSet;
			if ($ds)
			{
				$data.SelectCommand = $cmd;
				$data.Fill($ds) | Out-Null;
				foreach ($table in $ds.Tables)
				{
					$table.Rows[0].Count;
				}
				$ds.Dispose();
			}
			else
			{
				Write-Host "Failed creating the data set object!";
			}
			$data.Dispose();
		}
		else
		{
			Write-Host "Failed creating the data adapter object!";
		}
		$cmd.Dispose();
	}	
	else
	{
		Write-Host "Failed creating the command object!";
	}
	$conn.Close();
}
else
{
	Write-Host "Connection could not be opened!";
}
$conn.Dispose();

