USE ONETRAN
GO

SELECT * FROM ::fn_dblog(NULL, NULL)

USE master
GO

SELECT * FROM ::fn_dblog(NULL, NULL)

	SELECT 
	SPID,
	[Begin Time],
	[Current LSN],
	[Previous LSN],
	Operation,
	Context,
	[Log Reserve],
	AllocUnitName,
	[Page ID],
	[Number of Locks],
	[Lock Information]
	FROM ::fn_dblog(NULL, NULL)