/***************************************************************
  Name: D3_LogHogs.sql
  Project/Ticket#: Turbo-Charged Transaction Logs
  Date: March 2015
  Requester: SQL Saturday
  DBA: David M Maxwell
  Step: 3 of 6
  Server: (local)
  Instructions: Shows usage of DMF queries to determine what 
    sessions are using the most transaction log, and what
    queries they are running.
***************************************************************/

set nocount on;

use [master]; 
go

/* Drop test DB if it already exists. */
if exists (select name from sys.databases where name = 'TurboTLog')
begin 
    drop database TurboTLog;
end

/* Create our test database. */
create database TurboTLog on
    primary (name = 'TurboTLog_data', 
		   filename = 'C:\TurboTLogs\TurboTLog_data.mdf', 
		   size = 100MB, 
		   filegrowth = 10MB, 
		   maxsize = unlimited)
    log on  (name = 'TurboTLog_log', 
		   filename = 'C:\TurboTLogs\TurboTLog_log.ldf', 
		   size = 5MB, 
		   filegrowth = 5MB, 
		   maxsize = unlimited)
;

/* Set to full, and take the first backup and tlog 
   backup, to start the log chain. */
alter database TurboTLog
set recovery full;

backup database TurboTLog
to disk = 'C:\TurboTLogs\TurboTLog_Initial.bak'
with init, checksum, compression;

backup log TurboTLog
to disk = 'C:\TurboTLogs\TurboTLog_log.trn';

/* Create a table to throw some transactions at. */
use TurboTLog;

create table Movies (
    MovieID int identity(1,1) not null
	   primary key clustered,
    MovieName varchar(100) not null,
    Director varchar(100) not null, 
    Rating int null
);

/* Insert some test data... */
insert into Movies (MovieName, Director, Rating)
values ('The Good, The Bad and The Ugly','Sergio Leone',100),
	  ('Pitch Black','David Twohy',2),
	  ('The Muppet Movie','James Frawley',85),
	  ('Moulin Rouge','Baz Luhrmann',null)
;

/* Start a transaction and do some work, but don't 
    commit the transaction. */
begin transaction bond;

insert into Movies (MovieName, Director, Rating)
values ('Spectre','Sam Mendes',null);


/* Show how much space the transaction is taking up
   in the log */
SELECT  
    d.name AS [Database Name],   
    s.session_id AS [Session ID],         
    s.login_name AS [Login Name],
    dt.database_transaction_begin_time AS [Transaction Start],         
    dt.database_transaction_log_record_count AS [Transaction Records],         
    dt.database_transaction_log_bytes_used AS [Transaction Bytes]
FROM sys.dm_tran_database_transactions AS dt         
INNER JOIN sys.dm_tran_session_transactions AS st                
    ON dt.transaction_id = st.transaction_id         
INNER JOIN sys.databases AS d 
    ON dt.database_id = d.database_id 
inner join sys.dm_exec_sessions AS s
    on st.session_id = s.session_id
where dt.database_transaction_begin_time is not null;


/* Now commit the transaction and look at the log space */
commit transaction bond;

SELECT  
    d.name AS [Database Name],   
    s.session_id AS [Session ID],         
    s.login_name AS [Login Name],
    dt.database_transaction_begin_time AS [Transaction Start],         
    dt.database_transaction_log_record_count AS [Transaction Records],         
    dt.database_transaction_log_bytes_used AS [Transaction Bytes]
FROM sys.dm_tran_database_transactions AS dt         
INNER JOIN sys.dm_tran_session_transactions AS st                
    ON dt.transaction_id = st.transaction_id         
INNER JOIN sys.databases AS d 
    ON dt.database_id = d.database_id 
inner join sys.dm_exec_sessions AS s
    on st.session_id = s.session_id
where dt.database_transaction_begin_time is not null;



