/***************************************************************
  Name: D4_VLF_Fragmentation.sql
  Project/Ticket#: Turbo-Charged Transaction Logs
  Date: March 2015
  Requester: SQL Saturday
  DBA: David M Maxwell
  Step: 4 of 6
  Server: (local)
  Instructions: Shows before and after of a large transaction 
    log, where VLF count has been reduced, though the log is 
    the same size.
***************************************************************/

set nocount on;

use [master]; 
go

/* Drop test DB if it already exists. */
if exists (select name from sys.databases where name = 'TurboTLog')
begin 
    drop database TurboTLog;
end

/* Create our test database. */
create database TurboTLog on
    primary (name = 'TurboTLog_data', 
		   filename = 'C:\TurboTLogs\TurboTLog_data.mdf', 
		   size = 100MB, 
		   filegrowth = 10MB, 
		   maxsize = unlimited)
    log on  (name = 'TurboTLog_log', 
		   filename = 'C:\TurboTLogs\TurboTLog_log.ldf', 
		   size = 16MB, 
		   filegrowth = 16MB, 
		   maxsize = unlimited)
;

use TurboTLog;

dbcc loginfo();

/* Grow the log in small increments to create lots of little VLFs */

select getdate() as StartingTime;

declare 
    @sizeint int = 16, 
    @size nvarchar(6), 
    @cmd nvarchar(2048)

while @sizeint < 2048
begin 
    set @sizeint = @sizeint + 16;
    set @size = convert(nvarchar(4),@sizeint) + N'MB';
    set @cmd = N'
    alter database TurboTLog
    modify file (name = ''TurboTLog_log'', size = '+  @size + N');'
    exec sp_executesql @cmd 
end 

select getdate() as EndingTime;

/* Show number of VLFs with LOGINFO() */
use TurboTLog;

dbcc loginfo()

dbcc sqlperf(logspace);


/* Shrink the log down, and alter growth settings. */
dbcc shrinkfile(2,8);

dbcc loginfo();

/* Re-grow the log with a saner amount of VLFs. */
alter database TurboTLog
modify file (name = 'TurboTLog_log', size = 2048MB);

dbcc loginfo();
