/***************************************************************
  Name: D2_LOGINFO_VLFs.sql
  Project/Ticket#: Turbo-Charged Transaction Logs
  Date: March 2015
  Requester: SQL Saturday
  DBA: David M Maxwell
  Step: 2 of 6
  Server: (local)
  Instructions: Shows VLF information with LOGINFO() and how VLFs 
    are used through transactions with fn_dblog().
***************************************************************/

set nocount on;

use [master]; 
go

/* Drop test DB if it already exists. */
if exists (select name from sys.databases where name = 'TurboTLog')
begin 
    drop database TurboTLog;
end

/* Create our test database. */
create database TurboTLog on
    primary (name = 'TurboTLog_data', 
		   filename = 'C:\TurboTLogs\TurboTLog_data.mdf', 
		   size = 100MB, 
		   filegrowth = 10MB, 
		   maxsize = unlimited)
    log on  (name = 'TurboTLog_log', 
		   filename = 'C:\TurboTLogs\TurboTLog_log.ldf', 
		   size = 4MB,              /* Note the log size and growth rate */
		   filegrowth = 4MB, 
		   maxsize = unlimited)
;

/* Set to full, and take the first backup and tlog 
   backup, to start the log chain. */
alter database TurboTLog
set recovery full;

backup database TurboTLog
to disk = 'C:\TurboTLogs\TurboTLog_Initial.bak'
with init, checksum, compression;

backup log TurboTLog
to disk = 'C:\TurboTLogs\TurboTLog_log.trn';

/* Take a look at the VLFs currently in the log: */
use TurboTLog;

dbcc loginfo();

/* Create a table, and insert some data, to activate another VLF. */
create table VacationSpots (
    SpotID int identity(1,1) not null
	   primary key clustered,
    Country varchar(50) not null, 
    City varchar(100) not null,
    Rating tinyint null
    )
;

insert into VacationSpots (Country, City, Rating)
values ('United States','New York City',35), 
	  ('United States','Nashville',150),
	  ('United States','Kansas City',245),
	  ('Canada','Windsor',150),
	  ('Mexico','Cabo San Lucas',null)
;

dbcc loginfo();

/* Do a little more work, so that all VLFs are activated. */
create table TravelDiary (
    EntryID int identity(1,1) not null 
	   primary key clustered,
    SpotID int not null
	   foreign key references dbo.VacationSpots (SpotID),
    DiaryEntry nvarchar(3000) not null
    )
;

insert into TravelDiary (SpotID,DiaryEntry)
select top 1 SpotID, replicate('a',3000)
from VacationSpots 
where Rating is not null
order by newid();
go 400

dbcc loginfo();

/* In another window, add just one more, *wafer thin* transaction, 
   but keep it open. */

/* Now take a log backup and check to see which VLFs are active. */
backup log TurboTLog
to disk = 'C:\TurboTLogs\TurboTLog_log.trn';

dbcc loginfo();


/* If we do even more work, where will the log records be written? */
insert into TravelDiary (SpotID,DiaryEntry)
select top 1 SpotID, replicate('a',3000)
from VacationSpots 
where Rating is not null
order by newid();
go 300

dbcc loginfo();

/* Do a bit more work, and cause a log growth. */
insert into TravelDiary (SpotID,DiaryEntry)
select top 1 SpotID, replicate('a',3000)
from VacationSpots 
where Rating is not null
order by newid();
go 300

/* Show the VLFs created for a log growth. (Don't forget to check the Create LSN.) */
dbcc loginfo();

/* Show the transaction log records for a log growth. */
select 
    [Current LSN],
    [Operation],
    [Context], 
    [Page ID], 
    [Description], 
    [VLFs added]
from fn_dblog(null,null)
where [VLFs added] is not null

/* Now, in the other window, commit the transaction, 
   and take a log backup. */

backup log TurboTLog
to disk = 'C:\TurboTLogs\TurboTLog_log.trn';

/* How do our VLFs look now? */
dbcc loginfo();
