/***************************************************************
  Name: D5_StartupTimes.sql
  Project/Ticket#: Turbo-Charged Transaction Logs
  Date: March 2015
  Requester: SQL Saturday
  DBA: David M Maxwell
  Step: 5 of 6
  Server: (local)
  Instructions: Shows difference in startup times between two
    databases with similar log size, but one has heavy VLF 
    fragmentation.
***************************************************************/

set nocount on;

use [master]; 
go

/* Drop test DBs if it already exists. */
if exists (select name from sys.databases where name = 'TurboTLog')
begin 
    drop database TurboTLog;
end

if exists (select name from sys.databases where name = 'TurboTLog2')
begin 
    drop database TurboTLog2;
end

/* Create our first test database. */
create database TurboTLog on
    primary (name = 'TurboTLog_data', 
		   filename = 'C:\TurboTLogs\TurboTLog_data.mdf', 
		   size = 100MB, 
		   filegrowth = 10MB, 
		   maxsize = unlimited)
    log on  (name = 'TurboTLog_log', 
		   filename = 'C:\TurboTLogs\TurboTLog_log.ldf', 
		   size = 4MB, 
		   filegrowth = 4MB, 
		   maxsize = unlimited)
;

/* Grow the log to 2048MB - 4MB at a time. */
declare 
    @sizeint int = 4, 
    @size nvarchar(6), 
    @cmd nvarchar(2048)

while @sizeint < 2048
begin 
    set @sizeint = @sizeint + 4;
    set @size = convert(nvarchar(4),@sizeint) + N'MB';
    set @cmd = N'
    alter database TurboTLog
    modify file (name = ''TurboTLog_log'', size = '+  @size + N');'
    exec sp_executesql @cmd 
end 

alter database TurboTLog
set recovery full;

backup database TurboTLog
to disk = 'C:\TurboTLogs\TurboTLog_Initial.bak'
with init, checksum, compression;

backup log TurboTLog
to disk = 'C:\TurboTLogs\TurboTLog_log.trn';

/* Create our second test database, but with a 2048MB log to start. */
create database TurboTLog2 on
    primary (name = 'TurboTLog2_data', 
		   filename = 'C:\TurboTLogs\TurboTLog2_data.mdf', 
		   size = 100MB, 
		   filegrowth = 10MB, 
		   maxsize = unlimited)
    log on  (name = 'TurboTLog2_log', 
		   filename = 'C:\TurboTLogs\TurboTLog2_log.ldf', 
		   size = 2048MB, 
		   filegrowth = 16MB, 
		   maxsize = unlimited)
;

alter database TurboTLog2
set recovery full;

backup database TurboTLog2
to disk = 'C:\TurboTLogs\TurboTLog2_Initial.bak'
with init, checksum, compression;

backup log TurboTLog2
to disk = 'C:\TurboTLogs\TurboTLog2_log.trn';

/* Check the number of VLFs in the logs. */

use TurboTLog;
dbcc loginfo();

use TurboTLog2;
dbcc loginfo();


/* Take both databases offline and bring back online, 
   noticing difference in startup times, even with 
   no transactions to recover. */

use master; 

alter database TurboTLog set offline;
alter database TurboTLog2 set offline; 

declare @start datetime, @end datetime

select @start = getdate()
alter database TurboTLog set online;
select @end = getdate()
select 'TurboTLog' AS dbname,
	  @start AS StartedAt,
	  @end AS EndedAt,
	  cast(datediff(ms,@start,@end) as float) AS ElapsedMS;

select @start = getdate()
alter database TurboTLog2 set online;
select @end = getdate()
select 'TurboTLog2' AS dbname,
	  @start AS StartedAt,
	  @end AS EndedAt,
	  cast(datediff(ms,@start,@end) as float) AS ElapsedMS;

/* Clean up */
use [master];

drop database TurboTLog;
drop database TurboTLog2;
