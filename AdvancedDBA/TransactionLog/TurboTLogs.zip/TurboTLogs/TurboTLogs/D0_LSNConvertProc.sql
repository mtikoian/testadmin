USE [master];
GO

IF (SELECT OBJECT_ID('dbo.ConvertLSNHexToDec')) IS NULL
BEGIN 
    EXEC ('CREATE PROCEDURE dbo.ConvertLSNHexToDec
            AS
            PRINT ''STUB VERSION - Replace with actual procedure.'';
            ')
END
GO

ALTER PROCEDURE dbo.ConvertLSNHexToDec 
/*******************************************************************************
AUTHOR:
  David Maxwell
  
DATE: 
  April 2015

DESCRIPTION:
  Converts the LSN in fn_dblog() from a three part hex to three part decimal, 
  so you can pass it back to fn_dblog() as a parameter. (Because inconsistency.)

DEPENDENCIES: 
  none
  
TEST EXEC:

EXEC dbo.ConvertLSNHexToDec @lsn = N''
GO

TO DO LIST:
  1. Find a better way to do this other than this proc.
  2. Add an option to do this either in three part format or an integer string.

NOTES:  
  Please send any comments or suggestions to dmmaxwell@gmail.com.

CHANGE HISTORY:
Date - Author - Change
April 2015 - David Maxwell - initial version - pending feedback

*******************************************************************************/
    @lsn nvarchar(22) = NULL /* The LSN from fn_dblog that you want to convert */
AS

set nocount on;

declare @cmd nvarchar(2048), /* Dynamic SQL required for this, explained below */
	   @declsn nchar(22); /* The resulting, decimal-formatted LSN. */

/* In order to do this and keep everything in a three part format, I have to break
   up the LSN into its three component parts via string parsing. So this makes the 
   hux numbers turn into strings. You can't convert a string to an int. 
      
   So we create a dynamic SQL query and execute it, bypassing any conversions
   when we break this apart into strings. 
*/

select @cmd = '
select  
	  right(replicate(''0'',8) + cast(convert(int, 0x' + left(@lsn,8) + ') as nvarchar(8)),8) + N'':'' + 
       right(replicate(''0'',8) + cast(convert(int, 0x' + substring(@lsn,10,8) + ') as nvarchar(8)),8) + N'':'' + 
	  right(replicate(''0'',4) + cast(convert(int, 0x' + right(@lsn,4) + ') as nvarchar(4)),4)
';

print @cmd; /* This is just here for troubleshooting, if this fails. */

/* Execute the dynamic SQL, and output to the @declsn variable. */
exec sp_executesql @stmt = @cmd, @declsn = @declsn output;

/* Here's your LSN. */
return @declsn
go