/***************************************************************
  Name: D1_fn_dblog.sql
  Project/Ticket#: Turbo-Charged Transaction Logs
  Date: March 2015
  Requester: SQL Saturday
  DBA: David M Maxwell
  Step: 1 of 6
  Server: (local)
  Instructions: Demonstration of fn_dblog, showing how 
    transactions are logged.
***************************************************************/

set nocount on;

use [master]; 
go

/* Drop test DB if it already exists. */
if exists (select name from sys.databases where name = 'TurboTLog')
begin 
    drop database TurboTLog;
end

/* Create our test database. */
create database TurboTLog on
    primary (name = 'TurboTLog_data', 
		   filename = 'C:\TurboTLogs\TurboTLog_data.mdf', 
		   size = 100MB, 
		   filegrowth = 10MB, 
		   maxsize = unlimited)
    log on  (name = 'TurboTLog_log', 
		   filename = 'C:\TurboTLogs\TurboTLog_log.ldf', 
		   size = 5MB, 
		   filegrowth = 5MB, 
		   maxsize = unlimited)
;

/* Set to full, and take the first backup and tlog 
   backup, to start the log chain. */
alter database TurboTLog
set recovery full;

backup database TurboTLog
to disk = 'C:\TurboTLogs\TurboTLog_Initial.bak'
with init, checksum, compression;

backup log TurboTLog
to disk = 'C:\TurboTLogs\TurboTLog_log.trn';

/* Show the current contents of the transaction log. */
use TurboTLog;

select * 
from fn_dblog(null,null); /* start / end LSN - show everything for now */

/* Just a few of the *129* columns. */
select 
    [Current LSN], 
    [Operation], 
    [Context], 
    [Log Record Length], 
    [Page ID], 
    [Slot ID], 
    [Transaction SID],
    [Number of Locks],
    [Lock Information],	
    [Description]
from fn_dblog(null,null);

/* Pick a non-null SID to get the username for. */
select suser_sname(0x010500000000000515000000A23AFC5E2A8E6A6D9A7F6D59E9030000);

/* Make a note of the last LSN to convert it to decimal. */
EXEC master.dbo.ConvertLSNHexToDec @lsn = N'0000029d:00000098:0001';

/* Create an object to modify. */
create table Cookies (
    CookieID int IDENTITY(1,1) PRIMARY KEY NOT NULL,
    BrandName varchar(50) NOT NULL, 
    CookieName varchar(100) NOT NULL,
    Rating tinyint NULL
    )

/* Does the log show the creation? */
select 
    [Current LSN], 
    [Operation], 
    [Context], 
    [Log Record Length], 
    [AllocUnitName],
    [Page ID], 
    [Slot ID], 
    [Transaction Name],
    [Number of Locks],
    [Lock Information],	
    [Description]
from fn_dblog('00000669:00000152:0001',null)

/* Insert a few rows. */
INSERT INTO dbo.Cookies (BrandName, CookieName, Rating)
VALUES ('Nabisco','Oreos',4),
	  ('Nabisco','Chips Ahoy',5),
	  ('Keebler','Fudge Stripes',8),
	  ('Pepperidge Farm','Pirouette',25),
	  ('Nabisco','Nutter Butter',100)

/* Get starting LSN */
EXEC master.dbo.ConvertLSNHexToDec @lsn = N'000000a4:000000e0:0035';

/* What does the log show now? */
select 
    [Current LSN], 
    [Operation], 
    [Context], 
    [Log Record Length], 
    [AllocUnitName],
    [Page ID], 
    [Slot ID], 
    [Database Name],
    [Number of Locks],
    [Lock Information],	
    [Description],
    [RowLog Contents 0],
    [RowLog Contents 1],
    [RowLog Contents 2],
    [RowLog Contents 3],
    [RowLog Contents 4],
    [RowLog Contents 5]
from fn_dblog('00000164:00000224:0053',null)

backup log TurboTLog
to disk = 'C:\TurboTLogs\TurboTLog_log.trn';

/* Start a transaction, then roll back. Don't forget to get 
   the last LSN so we can view the appropriate results. */
EXEC master.dbo.ConvertLSNHexToDec @lsn = N'000000a4:00000100:0001';

begin transaction CookieRoll

update dbo.Cookies
set Rating = 75
where BrandName = 'Nabisco' 
  and CookieName = 'Nutter Butter'

rollback transaction

/* Look for the compensation record in the log. */
select 
    [Current LSN], 
    [Operation], 
    [Context], 
    [Log Record Length], 
    [Page ID], 
    [Slot ID], 
    [Checkpoint Begin],
    [Checkpoint End],
    [Transaction Name],
    [Description],
    [RowLog Contents 0],
    [RowLog Contents 1],
    [RowLog Contents 2],
    [RowLog Contents 3],
    [RowLog Contents 4],
    [RowLog Contents 5]
from fn_dblog('00000164:00000256:0001',null)