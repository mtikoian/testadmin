/***************************************************************
  Name: D6_PageSplits.sql
  Project/Ticket#: Turbo-Charged Transaction Logs
  Date: March 2015
  Requester: SQL Saturday
  DBA: David M Maxwell
  Step: 6 of 6
  Server: (local)
  Instructions: Shows page splits on the transaction log, and 
    how adjusting index fill factor can mitigate this.
***************************************************************/

set nocount on;

use [master]; 
go

/* Drop test DB if it already exists. */
if exists (select name from sys.databases where name = 'TurboTLog')
begin 
    drop database TurboTLog;
end

/* Create our test database. */
create database TurboTLog on
    primary (name = 'TurboTLog_data', 
		   filename = 'C:\TurboTLogs\TurboTLog_data.mdf', 
		   size = 100MB, 
		   filegrowth = 10MB, 
		   maxsize = unlimited)
    log on  (name = 'TurboTLog_log', 
		   filename = 'C:\TurboTLogs\TurboTLog_log.ldf', 
		   size = 5MB, 
		   filegrowth = 5MB, 
		   maxsize = unlimited)
;

alter database TurboTLog
set recovery full;

backup database TurboTLog
to disk = 'C:\TurboTLogs\TurboTLog_Initial.bak'
with init, checksum, compression;

backup log TurboTLog
to disk = 'C:\TurboTLogs\TurboTLog_log.trn';


/* Create a table we can fragment. */
use TurboTLog;

create table FragmentMe (
     EasyButton uniqueidentifier not null
	   constraint df_FragmentMe_EasyButton default newid(),
	SomeText varchar(256) not null
	   constraint df_FragmentMe_SomeText default replicate('a',256)
	)

/* Start populating the table */
insert into FragmentMe
default values;
go 4000

/* Create clustered index with 100% fill factor. */
create clustered index PK_FragmentMe_EasyButton 
on dbo.FragmentMe(EasyButton) with 
(fillfactor = 100);

/* Check fragmentation level */
select db_name(ips.database_id) as [Database Name],
       object_name(ips.[object_id]) as [Table Name],
	  ix.name as [Index Name],
	  ips.avg_fragmentation_in_percent AS [Percent Fragmentation], 
	  ips.avg_page_space_used_in_percent AS [Average Page Density]
from sys.dm_db_index_physical_stats(
    db_id('TurboTLog'), null, null, null, 'sampled'
    ) as ips
inner join sys.indexes as ix
    on ips.[object_id] = ix.[object_id]
   and ips.[index_id] = ix.[index_id]

/* Take a log backup to clear the log */
backup log TurboTLog
to disk = 'C:\TurboTLogs\TurboTLog_log.trn';

/* Now do lots of inserts with random IDs. */
insert into FragmentMe
default values;
go 1000

/* Check the page fragmentation and density. */
select db_name(ips.database_id) as [Database Name],
       object_name(ips.[object_id]) as [Table Name],
	  ix.name as [Index Name],
	  ips.avg_fragmentation_in_percent AS [Percent Fragmentation], 
	  ips.avg_page_space_used_in_percent AS [Average Page Density]
from sys.dm_db_index_physical_stats(
    db_id('TurboTLog'), null, null, null, 'sampled'
    ) as ips
inner join sys.indexes as ix
    on ips.[object_id] = ix.[object_id]
   and ips.[index_id] = ix.[index_id]

/* Now, check the log file - how many page split entries did we have? */
select count(*) 
from fn_dblog(null,null);

select count(*) 
from fn_dblog(null,null)
where [New Split Page] IS NOT NULL;

/* Clear the log - Remember to check the backup size. (578) */
backup log TurboTLog
to disk = 'C:\TurboTLogs\TurboTLog_log.trn';

/* Now start over, but with a different fill factor. */
truncate table FragmentMe

insert into FragmentMe
default values;
go 4000

alter index PK_FragmentMe_EasyButton
on dbo.FragmentMe
rebuild
with (fillfactor = 60)

/* Clear the log... */
backup log TurboTLog
to disk = 'C:\TurboTLogs\TurboTLog_log.trn';

/* Same insert pattern as before... */
insert into FragmentMe
default values;
go 1000

/* What's the fragmentation look like now?  */
select db_name(ips.database_id) as [Database Name],
       object_name(ips.[object_id]) as [Table Name],
	  ix.name as [Index Name],
	  ips.avg_fragmentation_in_percent AS [Percent Fragmentation], 
	  ips.avg_page_space_used_in_percent AS [Average Page Density]
from sys.dm_db_index_physical_stats(
    db_id('TurboTLog'), null, null, null, 'sampled'
    ) as ips
inner join sys.indexes as ix
    on ips.[object_id] = ix.[object_id]
   and ips.[index_id] = ix.[index_id]

/* And the log usage...? */
select count(*) 
from fn_dblog(null,null)

select count(*) 
from fn_dblog(null,null)
where [New Split Page] IS NOT NULL;

/* What about log backup size? */
backup log TurboTLog
to disk = 'C:\TurboTLogs\TurboTLog_log.trn';