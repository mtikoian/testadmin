/***************************************************************
  Name: D2_LOGINFO_VLFs_OpenTran.sql
  Project/Ticket#: Turbo-Charged Transaction Logs
  Date: March 2015
  Requester: SQL Saturday
  DBA: David M Maxwell
  Step: 2 of 6
  Server: (local)
  Instructions: Shows VLF information with LOGINFO() and how VLFs 
    are used through transactions with fn_dblog().
***************************************************************/

use TurboTLog;

/* Leave this transaction open for now... */

begin transaction OpenDoor

insert into dbo.TravelDiary (SpotID, DiaryEntry)
select SpotID, 'Great time with great friends. Would go again.'
from VacationSpots 
Where City = 'Kansas City';

/* Now commit, and see what happens to the log. */
commit transaction OpenDoor