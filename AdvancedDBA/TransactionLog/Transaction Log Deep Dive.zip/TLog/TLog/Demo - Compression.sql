
EXEC sp_configure 'backup compression default', '0' --DISABLE BACKUP COMPRESSION
GO
RECONFIGURE WITH OVERRIDE
GO

SET NOCOUNT ON
GO

CREATE DATABASE TestCompression
GO

USE TestCompression
GO

CREATE TABLE Test(Name CHAR(8000))
GO

DBCC LOGINFO
GO

BEGIN TRAN
GO

INSERT INTO Test VALUES('a')
GO 100

COMMIT TRAN
GO

DBCC LOGINFO
GO

SELECT Name, recovery_model_desc 
FROM sys.databases
WHERE name = 'TestCompression'
GO

--Database still in Pseudo-Simple Mode
CHECKPOINT
GO

DBCC LOGINFO
GO

--Run the backups in another window
BACKUP LOG TestCompression TO DISK = 'E:\Backups\SQLServer\Test_Log.BAK'
GO

BACKUP DATABASE TestCompression TO DISK = 'E:\Backups\SQLServer\Test_FULL.BAK'
GO

BACKUP LOG TestCompression TO DISK = 'E:\Backups\SQLServer\Test_Log.BAK'
GO


--Reset Environment for BLOCKSIZE Test
USE master
GO
DROP DATABASE TestCompression
GO

CREATE DATABASE TestCompression
GO

USE TestCompression
GO

CREATE TABLE Test(Name CHAR(8000))
GO

BEGIN TRAN
GO

INSERT INTO Test VALUES('a')
GO 100

COMMIT TRAN
GO

BACKUP DATABASE TestCompression TO DISK = 'E:\Backups\SQLServer\Test_BLOCKSIZE_FULL.BAK' WITH BLOCKSIZE = 65536
GO

BACKUP LOG TestCompression TO DISK = 'E:\Backups\SQLServer\Test_BLOCKSIZE_Log.BAK' WITH BLOCKSIZE = 65536
GO

--Enable backup Compression Setting
EXEC sp_configure 'backup compression default', '1'
GO
RECONFIGURE WITH OVERRIDE
GO

--Reset Environment for Compression Testing
USE master
GO
DROP DATABASE TestCompression
GO

CREATE DATABASE TestCompression
GO

USE TestCompression
GO

CREATE TABLE Test(Name CHAR(8000))
GO

BEGIN TRAN
GO

INSERT INTO Test VALUES('a')
GO 100

COMMIT TRAN
GO

--Run Backups with Compression
BACKUP DATABASE TestCompression TO DISK = 'E:\Backups\SQLServer\Test_Compression_FULL.BAK'
GO

BACKUP LOG TestCompression TO DISK = 'E:\Backups\SQLServer\Test_Compression_Log.BAK'
GO

BEGIN TRAN
GO

INSERT INTO Test VALUES('a')
GO 100

COMMIT TRAN
GO

BACKUP LOG TestCompression TO DISK = 'E:\Backups\SQLServer\Test_Compression_BLOCKSIZE_Log.BAK' WITH BLOCKSIZE = 65536
GO

--Cleanup after
USE master
GO
EXEC msdb.dbo.sp_delete_database_backuphistory @database_name = N'TestCompression'
GO
ALTER DATABASE [TestCompression] SET  SINGLE_USER WITH ROLLBACK IMMEDIATE
GO
DROP DATABASE TestCompression
GO

EXEC sp_configure 'backup compression default', '1' --REENABLE BACKUP COMPRESSION!?!
GO
RECONFIGURE WITH OVERRIDE
GO
