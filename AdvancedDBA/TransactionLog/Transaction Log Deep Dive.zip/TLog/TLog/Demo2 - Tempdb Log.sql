SET NOCOUNT ON
GO

USE tempdb
GO

DBCC LOGINFO
GO

WHILE 1<>2
BEGIN 

	SELECT * 
	INTO #Temp
	FROM sys.databases
	
	DROP TABLE #Temp
	
	WAITFOR DELAY '00:00:0.1'
END


DBCC LOGINFO
GO

DBCC SHRINKFILE (N'templog' , 1)
GO

--DROP TABLE #Temp

USE tempdb
GO
CHECKPOINT