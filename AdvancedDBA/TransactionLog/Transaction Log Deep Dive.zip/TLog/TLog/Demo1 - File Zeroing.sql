DBCC TRACEON(3004,3605,-1) --3004 IFI, 3605 output to error log
GO 

CREATE DATABASE TestFileZero 
GO 

EXEC sp_readerrorlog 
GO 

DROP DATABASE TestFileZero 
GO 

DBCC TRACEOFF(3004,3605,-1)
GO
