DBCC LOGINFO

DBCC SQLPERF(LOGSPACE)


SELECT * FROM sys.dm_os_wait_stats
WHERE wait_type LIKE '%log%'
ORDER BY wait_time_ms DESC

SELECT * FROM sys.dm_os_waiting_tasks --really don't want to see WRITELOG here!!
ORDER BY wait_duration_ms DESC