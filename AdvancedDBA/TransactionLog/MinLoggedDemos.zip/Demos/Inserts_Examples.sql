USE Demo_MLL ;
GO
SET NOCOUNT ON ;


IF OBJECT_ID('dbo.TestBI') IS NOT NULL
	DROP TABLE dbo.TestBI ;
GO
--  Creating a raw table to do the inserts on.
CREATE TABLE [TestBI] (
	[Sub_ID] [int] NOT NULL ,
	[LName] [varchar] (20) NULL ,
	[MDate] [datetime] NULL 
) ON [PRIMARY] ;
GO

TRUNCATE TABLE TestBI ;
GO
--  Make the Recovery Mode Full, clear out
--  any transactions and then show the usage.
  
ALTER DATABASE Demo_MLL SET RECOVERY FULL ;
GO
CHECKPOINT ;
GO
BACKUP DATABASE Demo_MLL TO DISK = 'NUL' WITH INIT ;
GO

BACKUP LOG Demo_MLL TO DISK = 'NUL' WITH INIT ;
GO

EXEC dbo.cp_list_sizes ;

EXEC dbo.cp_list_log_records 'dbo.TestBI' ;


DECLARE @x INT = 1 ;
WHILE @x <= 10000
BEGIN
    INSERT INTO [dbo].[TestBI] ([Sub_ID],[LName],[MDate]) VALUES (101318839,'dorey','2002-04-17 15:38:12') ;
    INSERT INTO [dbo].[TestBI] ([Sub_ID],[LName],[MDate]) VALUES (101318841,'Tallent','2002-07-03 02:16:51') ;
    INSERT INTO [dbo].[TestBI] ([Sub_ID],[LName],[MDate]) VALUES (101318845,'Miller','2002-04-17 15:38:12') ;
    INSERT INTO [dbo].[TestBI] ([Sub_ID],[LName],[MDate]) VALUES (101318848,'Taylor','2002-06-21 02:20:06') ;
    INSERT INTO [dbo].[TestBI] ([Sub_ID],[LName],[MDate]) VALUES (101318849,'lambert','2002-04-17 15:38:12') ;
    INSERT INTO [dbo].[TestBI] ([Sub_ID],[LName],[MDate]) VALUES (101318851,'peiyuan','2002-04-17 15:38:12') ;
    INSERT INTO [dbo].[TestBI] ([Sub_ID],[LName],[MDate]) VALUES (101318852,'Jacobsson','2002-04-17 15:38:12') ;
    INSERT INTO [dbo].[TestBI] ([Sub_ID],[LName],[MDate]) VALUES (101318854,'Pepper','2002-06-21 02:20:08') ;
    INSERT INTO [dbo].[TestBI] ([Sub_ID],[LName],[MDate]) VALUES (101318855,'Collins','2002-04-17 15:38:12') ;
    INSERT INTO [dbo].[TestBI] ([Sub_ID],[LName],[MDate]) VALUES (101318856,'perdomo','2002-04-17 15:38:12') ;

    SET @x = @x + 1 ;
END


EXEC dbo.cp_list_sizes ;

EXEC dbo.cp_list_log_records 'dbo.TestBI' ;

--  Look at the actual log records
SELECT [allocunitname], Operation, [Log Record Length], [Log Reserve],
 [Description], [Transaction ID], * 
    FROM fn_dblog(null, null) ;





-------------------------------------------------------


--  Insert 50K rows with FULL recovery model

TRUNCATE TABLE TestBI ;
GO
--  Make the Recovery Mode Full, clear out
--  any transactions and then show the usage.
  
ALTER DATABASE Demo_MLL SET RECOVERY FULL ;
GO
CHECKPOINT ;
GO
BACKUP DATABASE Demo_MLL TO DISK = 'NUL' WITH INIT ;
GO

BACKUP LOG Demo_MLL TO DISK = 'NUL' WITH INIT ;
GO

EXEC dbo.cp_list_sizes ;

EXEC dbo.cp_list_log_records 'dbo.TestBI' ;

--  Insert the 50K rows
EXEC dbo.insert_50K_rows --1

EXEC dbo.cp_list_sizes ;

EXEC dbo.cp_list_log_records 'dbo.TestBI' ;

--  Look at the actual log records
SELECT [allocunitname], Operation, [Log Record Length], [Log Reserve],
 [Description], [Transaction ID], * 
    FROM fn_dblog(null, null) ;




--  Now do the same thing but wrapped in a single transaction





-----------------------------------------------



--  Use Insert - Select with FULL recovery model

IF OBJECT_ID('dbo.TestSI') IS NOT NULL
	DROP TABLE dbo.TestSI ;
GO
--  Create a raw table to do the inserts on.
CREATE TABLE [TestSI] (
	[Sub_ID] [int] NOT NULL ,
	[LName] [varchar] (20) NULL ,
	[MDate] [datetime] NULL 
) ON [PRIMARY] ;
GO

ALTER DATABASE Demo_MLL SET RECOVERY FULL ;
GO

CHECKPOINT ;
GO
BACKUP DATABASE Demo_MLL TO DISK = 'NUL' WITH INIT ;
GO
BACKUP LOG Demo_MLL TO DISK = 'NUL' WITH INIT ;
GO

EXEC dbo.cp_list_sizes ;

EXEC dbo.cp_list_log_records 'dbo.TestSI' ;

INSERT INTO dbo.TestSI ([Sub_ID],[LName],[MDate])
	SELECT [Sub_ID],[LName],[MDate] FROM dbo.TestBI ;

EXEC dbo.cp_list_sizes ;

EXEC dbo.cp_list_log_records 'dbo.TestSI' ;



--  Look at the actual log records
SELECT [allocunitname], Operation, [Log Record Length], [Log Reserve],
 [Description], [Transaction ID], * 
    FROM fn_dblog(null, null) ;



-------------------------


--  Use Insert - Select with Bulk Logged recovery model 

TRUNCATE TABLE dbo.TestSI ;
GO


ALTER DATABASE Demo_MLL SET RECOVERY BULK_LOGGED ;
GO

CHECKPOINT ;
GO
BACKUP DATABASE Demo_MLL TO DISK = 'NUL' WITH INIT ;
GO
BACKUP LOG Demo_MLL TO DISK = 'NUL' WITH INIT ;
GO

EXEC dbo.cp_list_sizes ;

EXEC dbo.cp_list_log_records 'dbo.TestSI' ;

INSERT INTO dbo.TestSI ([Sub_ID],[LName],[MDate])
	SELECT [Sub_ID],[LName],[MDate] FROM dbo.TestBI ;

EXEC dbo.cp_list_sizes ;

EXEC dbo.cp_list_log_records 'dbo.TestSI' ;


--  Look at the actual log records
SELECT [allocunitname], Operation, [Log Record Length], [Log Reserve],
 [Description], [Transaction ID], * 
    FROM fn_dblog(null, null) ;



------------------------------------------



--  Use Insert - Select with Bulk Logged recovery model and TABLOCK

TRUNCATE TABLE dbo.TestSI ;
GO


ALTER DATABASE Demo_MLL SET RECOVERY BULK_LOGGED ;
GO

CHECKPOINT ;
GO
BACKUP DATABASE Demo_MLL TO DISK = 'NUL' WITH INIT ;
GO
BACKUP LOG Demo_MLL TO DISK = 'NUL' WITH INIT ;
GO

EXEC dbo.cp_list_sizes ;

EXEC dbo.cp_list_log_records 'dbo.TestsI' ;

INSERT INTO dbo.TestSI WITH (TABLOCK) ([Sub_ID],[LName],[MDate]) 
	SELECT [Sub_ID],[LName],[MDate] FROM dbo.TestBI ;

EXEC dbo.cp_list_sizes ;

EXEC dbo.cp_list_log_records 'dbo.TestsI' ;




--  Look at the actual log records
SELECT [allocunitname], Operation, [Log Record Length], [Log Reserve],
 [Description], [Transaction ID], * 
    FROM fn_dblog(null, null) ;




-----------------------


--  Use SELECT INTO with FULL recovery mode
DROP TABLE dbo.TestSI ;


ALTER DATABASE Demo_MLL SET RECOVERY FULL ;
GO

CHECKPOINT ;
GO
BACKUP DATABASE Demo_MLL TO DISK = 'NUL' WITH INIT ;
GO
BACKUP LOG Demo_MLL TO DISK = 'NUL' WITH INIT ;
GO

EXEC dbo.cp_list_sizes ;

EXEC dbo.cp_list_log_records 'dbo.TestsI' ;

SELECT * INTO dbo.TestSI 
    FROM dbo.TestBI ;

EXEC dbo.cp_list_sizes ;

EXEC dbo.cp_list_log_records 'dbo.TestsI' ;



--  Look at the actual log records
SELECT [allocunitname], Operation, [Log Record Length], [Log Reserve],
 [Description], [Transaction ID], * 
    FROM fn_dblog(null, null) ;



-----------------------------------------------------

--  Use SELECT INTO with Bulk_Logged
DROP TABLE dbo.TestSI ;


ALTER DATABASE Demo_MLL SET RECOVERY BULK_LOGGED ;
GO

CHECKPOINT ;
GO
BACKUP DATABASE Demo_MLL TO DISK = 'NUL' WITH INIT ;
GO
BACKUP LOG Demo_MLL TO DISK = 'NUL' WITH INIT ;
GO

EXEC dbo.cp_list_sizes ;

EXEC dbo.cp_list_log_records 'dbo.TestSI' ;

SELECT * INTO dbo.TestSI 
    FROM dbo.TestBI ;

EXEC dbo.cp_list_sizes ;

EXEC dbo.cp_list_log_records 'dbo.TestSI' ;



--  Look at the actual log records
SELECT [allocunitname], Operation, [Log Record Length], [Log Reserve],
 [Description], [Transaction ID], * 
    FROM fn_dblog(null, null) ;



-----------------------------------------




