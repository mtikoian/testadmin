USE [Demo_MLL] ;
GO
IF OBJECT_ID('dbo.cp_list_log_records','P') IS NOT NULL
    DROP PROCEDURE dbo.cp_list_log_records ;
GO
CREATE PROCEDURE dbo.cp_list_log_records
@Object_Name VARCHAR(40) 

AS

SET NOCOUNT ON ;

DECLARE @Recs BIGINT, @RecLength BIGINT, @Reserve BIGINT, @TotRecs BIGINT, @TotRecLength BIGINT, @TotReserve BIGINT ;

SELECT @Recs = COUNT(*)
    , @RecLength = SUM([Log Record Length])
    , @Reserve = SUM([Log Reserve])
FROM fn_dblog(null, null) 
    WHERE [allocunitname] = @Object_Name ;

SELECT @TotRecs = COUNT(*)
    , @TotRecLength = SUM([LOG RECORD LENGTH])
    , @TotReserve = SUM([Log Reserve])
FROM fn_dblog(null, null) ;


SELECT FORMAT(@Recs,'###,##0') AS [# Tran Recs]
    , FORMAT(@RecLength,'###,##0') AS [Tran Rec Length]
    , FORMAT((@RecLength / 1024),'###,##0') AS [Tran KBs]
    , FORMAT((@Reserve / 1024),'###,##0') AS [Reserve KBs]
    , '    ' AS [----]
    , FORMAT(@TotRecs,'###,##0') AS [# Total Recs]
    , FORMAT(@TotRecLength,'###,##0') AS [Total Rec Length]
    , FORMAT((@TotRecLength / 1024),'###,##0') AS [Total KBs] 
    , FORMAT((@TotReserve / 1024),'###,##0') AS [Tot Reserve KBs] ;


GO

--  SELECT * FROM fn_dblog(null, null) ;
--  sp_help 'sys.fn_dblog';
