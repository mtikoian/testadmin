USE Demo_MLL ;
GO

SELECT FORMAT(COUNT(*),'###,##0') AS [Totals]
    FROM Demo_MLL.dbo.[TestBI] ;


EXEC sp_spaceused

