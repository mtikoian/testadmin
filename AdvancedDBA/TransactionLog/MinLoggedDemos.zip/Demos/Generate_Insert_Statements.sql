USE [Demo_MLL]
GO

SELECT TOP 100000 
'INSERT INTO [dbo].[TestBI] ([Sub_ID],[LName],[MDate]) VALUES (' + CAST([Sub_ID] AS VARCHAR(12)) 
        + ',''' + [LName] + ''',''' + CONVERT(VARCHAR(20),([MDate]),120) + ''') ;'
FROM [dbo].[TestBI] ;

GO
