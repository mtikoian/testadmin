
USE Demo_MLL ;
GO

--  Clean up prior db objects
IF OBJECT_ID('dbo.TestBI') IS NOT NULL
	DROP TABLE dbo.TestBI ;
GO


IF OBJECT_ID('dbo.TestSI') IS NOT NULL
	DROP TABLE dbo.TestSI ;
GO

IF OBJECT_ID('dbo.t_source') IS NOT NULL
	DROP TABLE dbo.t_source ;
GO

IF OBJECT_ID('dbo.T_CI') IS NOT NULL
	DROP TABLE dbo.T_CI ;
GO
USE [Demo_MLL]
GO
DBCC SHRINKFILE (N'Demo_MLL_log' , 99)
GO
