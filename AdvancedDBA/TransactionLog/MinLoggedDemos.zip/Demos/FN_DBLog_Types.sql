https://www.blackhat.com/presentations/bh-usa-07/Fowler/Whitepaper/bh-usa-07-fowler-WP.pdf


    ABORT_XACT Indicates that a transaction was aborted and rolled back.

    BEGIN_CKPT A checkpoint has begun.

    BEGIN_XACT Indicates the start of a transaction.

    BUF_WRITE Writing to Buffer.

    COMMIT_XACT Indicates that a transaction has committed.

    CREATE_INDEX Creating an index.

    DELETE_ROWS Rows were deleted from a table.

    DELETE_SPLIT A page split has occurred. Rows have moved physically.

    DELTA_SYSIND  SYSINDEXES table has been modified.

    DROP_INDEX Dropping an index.

    END_CKPT Checkpoint has finished.

    EXPUNGE_ROWS row physically expunged from a page, now free for new rows.

    FILE_HDR_MODIF  SQL Server has grown a database file.

    FORGET_XACT Shows that a 2-phase commit transaction was rolled back.

    FORMAT_PAGE  Write a header of a newly allocated database page.

    INSERT_ROWS  Insert a row into a user or system table.

    MARK_DDL Data Definition Language change - table schema was modified.

    MARK_SAVEPOINT designate that an application has issued a 'SAVE TRANSACTION' command.

    MODIFY_COLUMNS  Designates that a row was modified as the result of an Update command.

    MODIFY_HEADER  A new data page created and has initialized the header of that page.

    MODIFY_ROW  Row modification as a result of an Update command.

    PREP_XACT Transaction is in a 2-phase commit protocol.

    SET_BITS Designates that the DBMS modified space allocation bits as the result of allocating a new extent.

    SET_FREE_SPACE  Designates that a previously allocated extent has been returned to the free pool.

    SET_MASK_BITS

    SORT_BEGIN A sort begins with index creation. - SORT_END end of the sorting while creating an index.

    SORT_EXTENT Sorting extents as part of building an index.

    UNDO_DELETE_SPLIT The page split process has been dumped.

    XACT_CKPT during the Checkpoint, open transactions were detected.