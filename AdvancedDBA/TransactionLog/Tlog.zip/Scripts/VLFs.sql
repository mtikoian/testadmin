USE [master]
GO
IF  EXISTS (SELECT name FROM sys.databases WHERE name = N'HighVLF')
DROP DATABASE [HighVLF]
GO
IF  EXISTS (SELECT name FROM sys.databases WHERE name = N'LowVLF')
DROP DATABASE [LowVLF]
GO

CREATE DATABASE [HighVLF] ON PRIMARY 
( NAME = N'HighVLF', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL10_50.SQLSERVER2008R2\MSSQL\DATA\HighVLF.mdf' , 
SIZE = 5120000KB , MAXSIZE = UNLIMITED, FILEGROWTH = 262144KB )
 LOG ON 
( NAME = N'HighVLF_log', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL10_50.SQLSERVER2008R2\MSSQL\DATA\HighVLF_log.ldf' , 
SIZE = 1024KB , MAXSIZE = 2192000KB , FILEGROWTH = 1024KB )
GO

CREATE DATABASE [LowVLF] ON PRIMARY 
( NAME = N'LowVLF', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL10_50.SQLSERVER2008R2\MSSQL\DATA\LowVLF.mdf' , 
SIZE = 5120000KB , MAXSIZE = UNLIMITED, FILEGROWTH = 262144KB )
 LOG ON 
( NAME = N'LowVLF_log', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL10_50.SQLSERVER2008R2\MSSQL\DATA\LowVLF_log.ldf' , 
SIZE = 1024KB , MAXSIZE = 2192000KB , FILEGROWTH = 1024000KB )
GO

--then pre-grow the databases
use [LowVLF]
go
dbcc loginfo

USE [master]
GO
ALTER DATABASE [LowVLF] MODIFY FILE ( NAME = N'LowVLF_log', SIZE = 1025MB )
GO
USE [master]
GO
ALTER DATABASE [LowVLF] MODIFY FILE ( NAME = N'LowVLF_log', SIZE = 2049MB )
GO

use [LowVLF]
go
dbcc loginfo

use [HighVLF]
go
dbcc loginfo

declare @count integer;
set @count=2;
while @count<2050
begin
USE [master]
ALTER DATABASE [HighVLF] MODIFY FILE ( NAME = N'HighVLF_log', SIZE =cast([@count] as varchar(10))+'MB');
set @count=@count+1
end

use [HighVLF]
go
dbcc loginfo