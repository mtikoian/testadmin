USE [master]
GO

IF  EXISTS (SELECT name FROM sys.databases WHERE name = N'SlowLogFile')
DROP DATABASE [SlowLogFile]
GO

CREATE DATABASE SlowLogFile on PRIMARY
(
Name='SlowLogFile_Date', Filename=N'D:\SlowLogFile.mdf')
LOG ON
(
Name='SlowLogFile_Log', Filename=N'D:\SlowLogFile_log.ldf', Size=5 MB, Filegrowth= 1 MB
);
GO

Alter database SlowLogFile set recovery simple
go

Use SlowLogFile
Go

Create Table BadKeyTable
(
c1 uniqueidentifier default newid () rowguidcol,
c2 datetime default getdate (),
c3 char(400) default 'a'
);
CREATE CLUSTERED INDEX BadKeyTable_CL ON BadKeyTable(c1);
CREATE NONCLUSTERED INDEX BadKeyTable_NCL ON BadKeyTable(c2);

--use ssd

USE [master]
GO

IF  EXISTS (SELECT name FROM sys.databases WHERE name = N'SlowLogFile')
DROP DATABASE [SlowLogFile]
GO

CREATE DATABASE SlowLogFile on PRIMARY
(
Name='SlowLogFile_Date', Filename=N'C:\SlowLogFile.mdf')
LOG ON
(
Name='SlowLogFile_Log', Filename=N'C:\SlowLogFile_log.ldf', Size=5 MB, Filegrowth= 1 MB
);
GO

Alter database SlowLogFile set recovery simple
go

Use SlowLogFile
Go

Create Table BadKeyTable
(
c1 uniqueidentifier default newid () rowguidcol,
c2 datetime default getdate (),
c3 char(400) default 'a'
);
CREATE CLUSTERED INDEX BadKeyTable_CL ON BadKeyTable(c1);
CREATE NONCLUSTERED INDEX BadKeyTable_NCL ON BadKeyTable(c2);

--clean


USE [master]
GO

IF  EXISTS (SELECT name FROM sys.databases WHERE name = N'SlowLogFile')
DROP DATABASE [SlowLogFile]
GO