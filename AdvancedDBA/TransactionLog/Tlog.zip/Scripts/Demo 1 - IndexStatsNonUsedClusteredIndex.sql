--drop it
Use master
GO
IF  EXISTS (SELECT name FROM sys.databases WHERE name = N'AdventureWorksDW2008R2')
DROP DATABASE [AdventureWorksDW2008R2]
GO

--take a clean distribution from D:\SQL Saturday and copy it to C:\Program Files\Microsoft SQL Server\MSSQL10_50.SQLSERVER2008R2\MSSQL\DATA
EXEC sp_configure 'show advanced options', 1
GO

RECONFIGURE
GO

EXEC sp_configure 'xp_cmdshell', 1
GO

RECONFIGURE
GO

EXEC xp_cmdshell 'copy "D:\SQL Saturday\TLog\AdventureWorksDW2008R2_Data.mdf" "C:\Program Files\Microsoft SQL Server\MSSQL13.MSSQLSERVER\MSSQL\DATA\AdventureWorksDW2008R2_Data.mdf" /Y';
GO
EXEC xp_cmdshell 'copy "D:\SQL Saturday\TLog\AdventureWorksDW2008R2_log.LDF" "C:\Program Files\Microsoft SQL Server\MSSQL13.MSSQLSERVER\MSSQL\DATA\AdventureWorksDW2008R2_Log.LDF" /Y';
GO

USE [master]
GO
CREATE DATABASE [AdventureWorksDW2008R2] ON 
( FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL13.MSSQLSERVER\MSSQL\DATA\AdventureWorksDW2008R2_Data.mdf' ),
( FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL13.MSSQLSERVER\MSSQL\DATA\AdventureWorksDW2008R2_Log.LDF' )
 FOR ATTACH
GO

--Deliberately turn off stats for AWDW database
USE [master] 
GO 
ALTER DATABASE [AdventureWorksDW2008R2] SET AUTO_CREATE_STATISTICS OFF WITH NO_WAIT 
GO 

--Include Actual Execution Plan ctrl+M
--Then run this query and take a look on Estimated and Actual number of rows
USE [AdventureWorksDW2008R2] 
GO 
SELECT RevisionNumber 
FROM dbo.FactInternetSales 
WHERE TaxAmt = 5.08 

--Create an index to improve the cardinality
CREATE INDEX IX_FactInternetSales_TaxAmt ON 
dbo.FactInternetSales (TaxAmt) 

--Then run the query again and take a look on Estimated and Actual number of rows
USE [AdventureWorksDW2008R2] 
GO 
SELECT RevisionNumber 
FROM dbo.FactInternetSales 
WHERE TaxAmt = 5.08 

--So now it is fine
--Was the index used then in this situation? I would say probably 
SELECT i.name,u.user_seeks, u.user_lookups, u.user_scans 
FROM sys.dm_db_index_usage_stats u 
INNER JOIN sys.indexes i ON 
     u.object_id = i.object_id AND 
     u.index_id = i.index_id 
WHERE u.object_id=object_id('dbo.FactInternetSales') AND 
     i.name = 'IX_FactInternetSales_TaxAmt'

--not working
DBCC SQLPERF ('sys.dm_db_index_usage_stats', clear)

--According to index_usage_stats, this index is not being utilized so I guess i is safe to drop it
USE [AdventureWorksDW2008R2] 
GO 
DROP INDEX [IX_FactInternetSales_TaxAmt] ON [dbo].[FactInternetSales] WITH ( ONLINE = OFF ) 
GO 

--Then run the query again and take a look on Estimated and Actual number of rows
SELECT RevisionNumber
FROM dbo.FactInternetSales 
WHERE TaxAmt = 5.08 

--Turn on auto-create stats
--Then run the query again and take a look on Estimated and Actual number of rows
USE [master] 
GO
ALTER DATABASE [AdventureWorksDW2008R2] SET AUTO_CREATE_STATISTICS ON WITH NO_WAIT 
GO 
USE [AdventureWorksDW2008R2] 
GO 
SELECT RevisionNumber 
FROM dbo.FactInternetSales 
WHERE TaxAmt = 5.08 

--Check if automatic stats was created
SELECT s.name, STATS_DATE(s.object_id, s.stats_id) auto_stats_date 
FROM sys.stats s 
INNER JOIN sys.stats_columns c ON 
     s.stats_id = c.stats_id AND 
     s.object_id = c.object_id 
WHERE s.object_id = object_id('dbo.FactInternetSales') AND 
     s.auto_created = 1 AND 
     c.column_id = 20 -- TaxAmt 


--drop it
Use master
GO
IF  EXISTS (SELECT name FROM sys.databases WHERE name = N'AdventureWorksDW2008R2')
DROP DATABASE [AdventureWorksDW2008R2]
GO

--disable cmdshell
EXEC sp_configure 'show advanced options', 1
GO

RECONFIGURE
GO

EXEC sp_configure 'xp_cmdshell', 0
GO

RECONFIGURE
GO




