 --drop it
 use master
 go
IF  EXISTS (SELECT name FROM sys.databases WHERE name = N'PageSplitTest')
DROP DATABASE [PageSplitTest]
GO

--create a test database to play with
CREATE DATABASE PageSplitTest;
 GO
 USE pagesplittest;
 GO 

CREATE TABLE BigRows (c1 INT, c2 CHAR (1000));
 CREATE CLUSTERED INDEX BigRows_CL ON BigRows (c1);
 GO 

INSERT INTO BigRows VALUES (1, 'a');
 INSERT INTO BigRows VALUES (2, 'a');
 INSERT INTO BigRows VALUES (3, 'a');
 INSERT INTO BigRows VALUES (4, 'a');
 INSERT INTO BigRows VALUES (6, 'a');
 INSERT INTO BigRows VALUES (7, 'a');
 GO 

 --in this case index data page has a space for one more row
 --let's add it and see how much log was used

 BEGIN TRAN
 INSERT INTO BigRows VALUES (8, 'a');
 GO 

SELECT [database_transaction_log_bytes_used] FROM sys.dm_tran_database_transactions
 WHERE [database_id] = DB_ID ('PageSplitTest');
 GO 

 --now we will cause a page split by committing the previous transaction and insert the missing c1=5
 COMMIT TRAN
 GO 

BEGIN TRAN
 INSERT INTO BigRows VALUES (5, 'a');
 GO 

SELECT [database_transaction_log_bytes_used] FROM sys.dm_tran_database_transactions
 WHERE [database_id] = DB_ID ('PageSplitTest');
 GO 

 --ratio is 5.5x

--just commit it
 COMMIT TRAN
 GO 

 --drop it
 use master
 go
IF  EXISTS (SELECT name FROM sys.databases WHERE name = N'PageSplitTest')
DROP DATABASE [PageSplitTest]
GO

--test with 100 bytes
--create a test database to play with
CREATE DATABASE PageSplitTest;
 GO
 USE pagesplittest;
 GO 

CREATE TABLE BigRows (c1 INT, c2 CHAR (100));
 CREATE CLUSTERED INDEX BigRows_CL ON BigRows (c1);
 GO 

--gap left for c1=30
INSERT INTO BigRows VALUES (1, 'a');
 INSERT INTO BigRows VALUES (2, 'a');
 INSERT INTO BigRows VALUES (3, 'a');
 INSERT INTO BigRows VALUES (4, 'a');
 INSERT INTO BigRows VALUES (6, 'a');
 INSERT INTO BigRows VALUES (7, 'a');
 INSERT INTO BigRows VALUES (8, 'a');
 INSERT INTO BigRows VALUES (9, 'a');
 INSERT INTO BigRows VALUES (10, 'a');
 INSERT INTO BigRows VALUES (11, 'a');
 INSERT INTO BigRows VALUES (12, 'a');
 INSERT INTO BigRows VALUES (13, 'a');
 INSERT INTO BigRows VALUES (14, 'a');
 INSERT INTO BigRows VALUES (15, 'a');
 INSERT INTO BigRows VALUES (16, 'a');
 INSERT INTO BigRows VALUES (17, 'a');
 INSERT INTO BigRows VALUES (18, 'a');
 INSERT INTO BigRows VALUES (19, 'a');
 INSERT INTO BigRows VALUES (20, 'a');
 INSERT INTO BigRows VALUES (21, 'a');
 INSERT INTO BigRows VALUES (22, 'a');
 INSERT INTO BigRows VALUES (23, 'a');
 INSERT INTO BigRows VALUES (24, 'a');
 INSERT INTO BigRows VALUES (25, 'a');
 INSERT INTO BigRows VALUES (26, 'a');
 INSERT INTO BigRows VALUES (27, 'a');
 INSERT INTO BigRows VALUES (28, 'a');
 INSERT INTO BigRows VALUES (29, 'a');
 INSERT INTO BigRows VALUES (31, 'a');
 INSERT INTO BigRows VALUES (32, 'a');
 INSERT INTO BigRows VALUES (33, 'a');
 INSERT INTO BigRows VALUES (34, 'a');
 INSERT INTO BigRows VALUES (35, 'a');
 INSERT INTO BigRows VALUES (36, 'a');
 INSERT INTO BigRows VALUES (37, 'a');
 INSERT INTO BigRows VALUES (38, 'a');
 INSERT INTO BigRows VALUES (39, 'a');
 INSERT INTO BigRows VALUES (40, 'a');
 INSERT INTO BigRows VALUES (41, 'a');
 INSERT INTO BigRows VALUES (41, 'a');
 INSERT INTO BigRows VALUES (42, 'a');
 INSERT INTO BigRows VALUES (43, 'a');
 INSERT INTO BigRows VALUES (44, 'a');
 INSERT INTO BigRows VALUES (45, 'a');
 INSERT INTO BigRows VALUES (46, 'a');
 INSERT INTO BigRows VALUES (47, 'a');
 INSERT INTO BigRows VALUES (48, 'a');
 INSERT INTO BigRows VALUES (49, 'a');
 INSERT INTO BigRows VALUES (50, 'a');
 INSERT INTO BigRows VALUES (51, 'a');
 INSERT INTO BigRows VALUES (52, 'a');
 INSERT INTO BigRows VALUES (53, 'a');
 INSERT INTO BigRows VALUES (54, 'a');
 INSERT INTO BigRows VALUES (55, 'a');
 INSERT INTO BigRows VALUES (56, 'a');
 INSERT INTO BigRows VALUES (57, 'a');
 INSERT INTO BigRows VALUES (58, 'a');
 INSERT INTO BigRows VALUES (59, 'a');
 INSERT INTO BigRows VALUES (60, 'a');
 INSERT INTO BigRows VALUES (61, 'a');
 INSERT INTO BigRows VALUES (62, 'a');
 INSERT INTO BigRows VALUES (63, 'a');
 INSERT INTO BigRows VALUES (64, 'a');
 INSERT INTO BigRows VALUES (65, 'a');
 INSERT INTO BigRows VALUES (66, 'a');
 INSERT INTO BigRows VALUES (67, 'a');
 INSERT INTO BigRows VALUES (68, 'a');
 INSERT INTO BigRows VALUES (69, 'a');
 INSERT INTO BigRows VALUES (70, 'a');
 INSERT INTO BigRows VALUES (71, 'a');
 GO 

 --insert 72
 BEGIN TRAN
 INSERT INTO BigRows VALUES (72, 'a');
 GO 

SELECT [database_transaction_log_bytes_used] FROM sys.dm_tran_database_transactions
 WHERE [database_id] = DB_ID ('PageSplitTest');
 GO 

  --now we will cause a page split by committing the previous transaction and insert the missing c1=30
 COMMIT TRAN
 GO 

BEGIN TRAN
 INSERT INTO BigRows VALUES (30, 'a');
 GO 

SELECT [database_transaction_log_bytes_used] FROM sys.dm_tran_database_transactions
 WHERE [database_id] = DB_ID ('PageSplitTest');
 GO 

 --Ratio is over 17x
 --as the data becomes smaller the ratio is even worse

 --just commit it
 COMMIT TRAN
 GO 

 --drop it
 use master
 go
IF  EXISTS (SELECT name FROM sys.databases WHERE name = N'PageSplitTest')
DROP DATABASE [PageSplitTest]
GO