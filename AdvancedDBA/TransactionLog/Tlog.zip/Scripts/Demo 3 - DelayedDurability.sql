--drop databases if exist
use master 
go
IF  EXISTS (SELECT name FROM sys.databases WHERE name = N'dd1')
DROP DATABASE [dd1]
GO
IF  EXISTS (SELECT name FROM sys.databases WHERE name = N'dd2')
DROP DATABASE [dd2]
GO

--create databases
CREATE DATABASE dd1 ON (name = 'dd1_data', filename = 'C:\SQLData\dd1.mdf', size = 1024MB)
LOG ON (name = 'dd1_log', filename = 'C:\SQLLog\dd1.ldf', size = 1024MB);
  ALTER DATABASE dd1 SET RECOVERY FULL;
  ALTER DATABASE dd1 SET DELAYED_DURABILITY = DISABLED;
  CREATE DATABASE dd2 ON (name = 'dd2_data', filename = 'C:\SQLData\dd2.mdf', size = 1024MB)
LOG ON (name = 'dd2_log', filename = 'C:\SQLLog\dd2.ldf', size = 1024MB);
  ALTER DATABASE dd2 SET RECOVERY FULL;
  ALTER DATABASE dd2 SET DELAYED_DURABILITY = FORCED;

  --check their property
  SELECT d.name, d.recovery_model_desc, d.delayed_durability_desc, 
  log_disk = CASE WHEN mf.physical_name LIKE N'C%' THEN 'SSD' else 'HDD' END
FROM sys.databases AS d
INNER JOIN sys.master_files AS mf
ON d.database_id = mf.database_id
WHERE d.name LIKE N'dd[1-2]'
--WHERE d.name LIKE N'dd[1-4]'
AND mf.[type] = 1; -- log

--generate the table
USE dd1;
GO
 
 IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TheTable]') AND type in (N'U'))
DROP TABLE [dbo].[TheTable]
GO
CREATE TABLE dbo.TheTable
(
  TheID INT IDENTITY(1,1) PRIMARY KEY,
  TheDate DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  RowGuid UNIQUEIDENTIFIER NOT NULL DEFAULT NEWID()
);

USE dd2;
GO
 
 IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TheTable]') AND type in (N'U'))
DROP TABLE [dbo].[TheTable]
GO
CREATE TABLE dbo.TheTable
(
  TheID INT IDENTITY(1,1) PRIMARY KEY,
  TheDate DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  RowGuid UNIQUEIDENTIFIER NOT NULL DEFAULT NEWID()
);


IF OBJECT_ID('tempdb..#Metrics') IS NOT NULL
    DROP TABLE #Metrics
GO

--this would allow to record start and finish time
SELECT test = 1, cycle = 1, start_time = GETDATE(), * 
INTO #Metrics 
FROM sys.dm_io_virtual_file_stats(DB_ID('dd1'), 2) WHERE 1 = 0;

--test with a lot of small transactions
--100 000 separate batches of single insert
--dd1 database
INSERT #Metrics SELECT 1, 1, GETDATE(), * 
  FROM sys.dm_io_virtual_file_stats(DB_ID('dd1'), 2);
GO
use dd1
go
INSERT dbo.TheTable DEFAULT VALUES;
GO 100000
INSERT #Metrics SELECT 1, 2, GETDATE(), * 
  FROM sys.dm_io_virtual_file_stats(DB_ID('dd1'), 2);

--dd2 database
  INSERT #Metrics SELECT 1, 1, GETDATE(), * 
  FROM sys.dm_io_virtual_file_stats(DB_ID('dd2'), 2);
GO
use dd2
go
INSERT dbo.TheTable DEFAULT VALUES;
GO 100000
INSERT #Metrics SELECT 1, 2, GETDATE(), * 
  FROM sys.dm_io_virtual_file_stats(DB_ID('dd2'), 2);


--after run them check the stats
SELECT 
  [database] = db_name(m1.database_id),
  num_writes = m2.num_of_writes - m1.num_of_writes, 
  write_bytes = m2.num_of_bytes_written - m1.num_of_bytes_written,
  bytes_per_write = (m2.num_of_bytes_written - m1.num_of_bytes_written)*1.0
  /(m2.num_of_writes - m1.num_of_writes),
  io_stall_ms = m2.io_stall_write_ms - m1.io_stall_write_ms,
  m1.start_time,
  end_time = m2.start_time,
  duration = DATEDIFF(SECOND, m1.start_time, m2.start_time)
FROM #Metrics AS m1
INNER JOIN #Metrics AS m2
ON m1.database_id = m2.database_id
WHERE m1.cycle = 1 AND m2.cycle = 2
AND m1.test = 1 AND m2.test = 1;

--clean
use master
go
IF  EXISTS (SELECT name FROM sys.databases WHERE name = N'dd1')
DROP DATABASE [dd1]
GO

IF  EXISTS (SELECT name FROM sys.databases WHERE name = N'dd2')
DROP DATABASE [dd2]
GO





--now with larger sets
--create databases
CREATE DATABASE dd1 ON (name = 'dd1_data', filename = 'C:\SQLData\dd1.mdf', size = 1024MB)
LOG ON (name = 'dd1_log', filename = 'C:\SQLLog\dd1.ldf', size = 1024MB);
  ALTER DATABASE dd1 SET RECOVERY FULL;
  ALTER DATABASE dd1 SET DELAYED_DURABILITY = DISABLED;
  CREATE DATABASE dd2 ON (name = 'dd2_data', filename = 'C:\SQLData\dd2.mdf', size = 1024MB)
LOG ON (name = 'dd2_log', filename = 'C:\SQLLog\dd2.ldf', size = 1024MB);
  ALTER DATABASE dd2 SET RECOVERY FULL;
  ALTER DATABASE dd2 SET DELAYED_DURABILITY = FORCED;

  --check their property
  SELECT d.name, d.recovery_model_desc, d.delayed_durability_desc, 
  log_disk = CASE WHEN mf.physical_name LIKE N'C%' THEN 'SSD' else 'HDD' END
FROM sys.databases AS d
INNER JOIN sys.master_files AS mf
ON d.database_id = mf.database_id
WHERE d.name LIKE N'dd[1-2]'
--WHERE d.name LIKE N'dd[1-4]'
AND mf.[type] = 1; -- log

--temp table creation for stats
IF OBJECT_ID('tempdb..#Metrics') IS NOT NULL
    DROP TABLE #Metrics
GO

--this would allow to record start and finish time
SELECT test = 1, cycle = 1, start_time = GETDATE(), * 
INTO #Metrics 
FROM sys.dm_io_virtual_file_stats(DB_ID('dd1'), 2) WHERE 1 = 0;

--fewer operations (5000) but affected larger amount of data
--dd1 database
use dd1
go
CREATE TABLE dbo.Rnd
(
  batch TINYINT,
  TheID INT
);
 
INSERT dbo.Rnd SELECT TOP (1000) 1, TheID FROM dbo.TheTable ORDER BY NEWID();
INSERT dbo.Rnd SELECT TOP (10)   2, TheID FROM dbo.TheTable ORDER BY NEWID();
INSERT dbo.Rnd SELECT TOP (300)  3, TheID FROM dbo.TheTable ORDER BY NEWID();
GO
 
INSERT #Metrics SELECT 1, 1, GETDATE(), * 
  FROM sys.dm_io_virtual_file_stats(DB_ID('dd1'), 2);
GO
UPDATE t SET TheDate = DATEADD(MINUTE, 1, TheDate)
  FROM dbo.TheTable AS t
  INNER JOIN dbo.Rnd AS r
  ON t.TheID = r.TheID
  WHERE r.batch = 1;
GO 5000
UPDATE t SET RowGuid = NEWID()
  FROM dbo.TheTable AS t
  INNER JOIN dbo.Rnd AS r
  ON t.TheID = r.TheID
  WHERE r.batch = 2;
GO 5000
DELETE dbo.TheTable WHERE TheID IN (SELECT TheID   FROM dbo.Rnd WHERE batch = 3);
DELETE dbo.TheTable WHERE TheID IN (SELECT TheID+1 FROM dbo.Rnd WHERE batch = 3);
DELETE dbo.TheTable WHERE TheID IN (SELECT TheID-1 FROM dbo.Rnd WHERE batch = 3);
GO
INSERT #Metrics SELECT 1, 2, GETDATE(), * 
  FROM sys.dm_io_virtual_file_stats(DB_ID('dd1'), 2);

--dd2 database
  use dd2
go
CREATE TABLE dbo.Rnd
(
  batch TINYINT,
  TheID INT
);
 
INSERT dbo.Rnd SELECT TOP (1000) 1, TheID FROM dbo.TheTable ORDER BY NEWID();
INSERT dbo.Rnd SELECT TOP (10)   2, TheID FROM dbo.TheTable ORDER BY NEWID();
INSERT dbo.Rnd SELECT TOP (300)  3, TheID FROM dbo.TheTable ORDER BY NEWID();
GO
 
INSERT #Metrics SELECT 1, 1, GETDATE(), * 
  FROM sys.dm_io_virtual_file_stats(DB_ID('dd2'), 2);
GO
UPDATE t SET TheDate = DATEADD(MINUTE, 1, TheDate)
  FROM dbo.TheTable AS t
  INNER JOIN dbo.Rnd AS r
  ON t.TheID = r.TheID
  WHERE r.batch = 1;
GO 5000
UPDATE t SET RowGuid = NEWID()
  FROM dbo.TheTable AS t
  INNER JOIN dbo.Rnd AS r
  ON t.TheID = r.TheID
  WHERE r.batch = 2;
GO 5000
DELETE dbo.TheTable WHERE TheID IN (SELECT TheID   FROM dbo.Rnd WHERE batch = 3);
DELETE dbo.TheTable WHERE TheID IN (SELECT TheID+1 FROM dbo.Rnd WHERE batch = 3);
DELETE dbo.TheTable WHERE TheID IN (SELECT TheID-1 FROM dbo.Rnd WHERE batch = 3);
GO
INSERT #Metrics SELECT 1, 2, GETDATE(), * 
  FROM sys.dm_io_virtual_file_stats(DB_ID('dd2'), 2);


--after run them check the stats
SELECT 
  [database] = db_name(m1.database_id),
  num_writes = m2.num_of_writes - m1.num_of_writes, 
  write_bytes = m2.num_of_bytes_written - m1.num_of_bytes_written,
  bytes_per_write = (m2.num_of_bytes_written - m1.num_of_bytes_written)*1.0
  /(m2.num_of_writes - m1.num_of_writes),
  io_stall_ms = m2.io_stall_write_ms - m1.io_stall_write_ms,
  m1.start_time,
  end_time = m2.start_time,
  duration = DATEDIFF(SECOND, m1.start_time, m2.start_time)
FROM #Metrics AS m1
INNER JOIN #Metrics AS m2
ON m1.database_id = m2.database_id
WHERE m1.cycle = 1 AND m2.cycle = 2
AND m1.test = 1 AND m2.test = 1;

--clean
use master
go
IF  EXISTS (SELECT name FROM sys.databases WHERE name = N'dd1')
DROP DATABASE [dd1]
GO

IF  EXISTS (SELECT name FROM sys.databases WHERE name = N'dd2')
DROP DATABASE [dd2]
GO
