--	**********    PREPARE    **********

USE master;
GO

-- drop database, if needed
IF DATABASEPROPERTYEX('test', 'Version') IS NOT NULL
BEGIN
	ALTER DATABASE [test]
	SET SINGLE_USER 
	WITH ROLLBACK IMMEDIATE;

	DROP DATABASE [test];
END
GO

-- create test database
CREATE DATABASE [test]
ON  PRIMARY 
(	NAME = N'test', 
	FILENAME = N'C:\Data\test.mdf', 
	SIZE = 5120KB, 
	FILEGROWTH = 1024KB 
)
LOG ON 
(	NAME = N'test_log', 
	FILENAME = N'C:\Data\test_log.ldf', 
	SIZE = 1024KB, 
	MAXSIZE = 2048KB, 
	FILEGROWTH = 256KB 
)
GO

-- full backup
BACKUP DATABASE [test]
TO DISK = N'C:\Backup\test.bak'
WITH INIT;
GO

--	**********    FILL WITH DATA    **********

USE [test];
GO

CREATE TABLE [dbo].[Messages](
	[MessageId] [int] IDENTITY(1,1) NOT NULL,
	[MessageText] [nchar](2000) NOT NULL,
	[Time] datetime DEFAULT GETDATE()
) ON [PRIMARY]
GO

-- insert some stuff
INSERT INTO Messages (MessageText)
VALUES (N'bla-bla-bla');
GO 100

-- look at VLF
DBCC LOGINFO('test');
GO

-- backup log
BACKUP LOG [test]
TO DISK = N'C:\Backup\test.trn'
WITH INIT;
GO

-- look at VLF
DBCC LOGINFO('test');
GO

-- add 50 records
INSERT INTO Messages (MessageText)
VALUES (N'bla-bla-bla');
GO 50

-- look at VLF
DBCC LOGINFO('test');
GO

-- **********    SHRINKING LOG FILE    **********

-- shrink log file to 1 MB
DBCC SHRINKFILE('test_log', 1);
GO

-- look at VLF
-- maybe even worse
DBCC LOGINFO('test');
GO

-- backup log
BACKUP LOG [test]
TO DISK = N'C:\Backup\test.trn'
WITH INIT;
GO

-- look at VLF
DBCC LOGINFO('test');
GO

-- shrink file 1 to 1 MB
DBCC SHRINKFILE('test_log', 1);
GO

-- look at VLF
DBCC LOGINFO('test');
GO

-- manually resize log to 8MB (+7MB)
ALTER DATABASE [test] 
MODIFY FILE 
(	NAME = N'test_log', 
	SIZE = 8192KB, 
	MAXSIZE = UNLIMITED, 
	FILEGROWTH = 8192KB 
)
GO

-- manually resize log to 16MB (+8MB)
ALTER DATABASE [test] 
MODIFY FILE 
(	NAME = N'test_log', 
	SIZE = 16384KB, 
	MAXSIZE = UNLIMITED, 
	FILEGROWTH = 8192KB 
)
GO

-- look at VLF
DBCC LOGINFO('test');
GO
