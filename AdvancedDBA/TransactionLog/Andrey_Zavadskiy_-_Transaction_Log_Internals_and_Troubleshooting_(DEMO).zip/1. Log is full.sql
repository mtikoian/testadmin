--	**********    PREPARE    **********

USE master;
GO

-- drop database, if needed
IF DATABASEPROPERTYEX('test', 'Version') IS NOT NULL
BEGIN
	ALTER DATABASE [test]
	SET SINGLE_USER 
	WITH ROLLBACK IMMEDIATE;

	DROP DATABASE [test];
END
GO

-- create test database
CREATE DATABASE [test]
ON  PRIMARY 
(	NAME = N'test', 
	FILENAME = N'C:\Data\test.mdf', 
	SIZE = 5120KB, 
	FILEGROWTH = 1024KB 
)
LOG ON 
(	NAME = N'test_log', 
	FILENAME = N'C:\Data\test_log.ldf', 
	SIZE = 1024KB, 
	MAXSIZE = 2048KB, 
	FILEGROWTH = 512KB 
)
GO

-- full backup
BACKUP DATABASE [test]
TO DISK = N'C:\Backup\test.bak'
WITH INIT;
GO

--	**********    ERROR 9002    **********

USE [test];
GO

CREATE TABLE [dbo].[Messages](
	[MessageId] [int] IDENTITY(1,1) NOT NULL,
	[MessageText] [nchar](2000) NOT NULL,
	[Time] datetime DEFAULT GETDATE()
) ON [PRIMARY]
GO

-- space before data inserts
DBCC SQLPERF(LOGSPACE);
GO

-- insert some stuff
INSERT INTO Messages (MessageText)
VALUES (N'bla-bla-bla');
GO 190

-- space after data inserts
DBCC SQLPERF(LOGSPACE);
GO

SELECT * 
FROM sys.dm_db_log_space_usage;
GO

-- insert some stuff
DECLARE @x INT = 191;
WHILE (@x < 205)
BEGIN
	PRINT @x;
	INSERT INTO Messages (MessageText)
	VALUES (
		CAST(@x AS nchar(2000))
	);
	SET @x += 1;
END
GO

-- space after log is full
DBCC SQLPERF(LOGSPACE);
GO

-- why?
SELECT name, log_reuse_wait_desc
FROM sys.databases;
GO

-- which transaction is the last?
SELECT TOP 5 * 
FROM Messages
ORDER BY MessageId DESC;
GO

--	**********    CORRECTING    **********

-- option 1: Backup log
BACKUP LOG [test]
TO DISK = N'C:\Backup\test.trn'
WITH INIT;
GO

-- space after log backup
DBCC SQLPERF(LOGSPACE);
GO

SELECT * 
FROM sys.dm_db_log_space_usage;
GO

-- option 2: expand log file
ALTER DATABASE [test] 
MODIFY FILE 
( 
	NAME = N'test_log', 
	MAXSIZE = 3072KB
)
GO

-- space after file expanding
DBCC SQLPERF(LOGSPACE);
GO

SELECT * 
FROM sys.dm_db_log_space_usage;

-- option 3: Add a second log file
ALTER DATABASE [test] 
ADD LOG FILE 
(	NAME = N'test_log2', 
	FILENAME = N'C:\Data\test_log2.ldf', 
	SIZE = 1024KB, 
	MAXSIZE = 2048KB, 
	FILEGROWTH = 512KB 
)
GO

-- space after second file was added
DBCC SQLPERF(LOGSPACE);
GO

SELECT * 
FROM sys.dm_db_log_space_usage;

-- look at VLFs
DBCC LOGINFO('test');

-- check the database is working
INSERT INTO Messages (MessageText)
VALUES (N'bla-bla-bla');
GO 50


-- **********    DELETING 2nd LOG FILE    **********

-- analyze VLFs
DBCC LOGINFO('test');

-- waiting for log roll-over
-- add some records
INSERT INTO Messages (MessageText)
VALUES (N'bla-bla-bla');
GO 100

-- look at VLF
DBCC LOGINFO('test');
GO

-- backup log
BACKUP LOG [test]
TO DISK = N'C:\Backup\test.trn'
WITH INIT;
GO

-- look at VLF
DBCC LOGINFO('test');
GO

-- repeat INSERT & BACKUP if needed

-- check physical file in C:\Data
-- open File Explorer

-- remove second log file
ALTER DATABASE [test] 
REMOVE FILE [test_log2];
GO

-- look at VLF
DBCC LOGINFO('test');
GO

-- check physical file in C:\Data
-- phantom record
SELECT * FROM sys.database_files;
