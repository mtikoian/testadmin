USE [test];
GO

-- neverendless update
WHILE (1 = 1)
BEGIN
	UPDATE dbo.StressTable
	SET [Guid] = NEWID();
END
GO
