-- **********    PROVISION DATABASE    **********

USE master;
GO

-- drop database, if needed
IF DATABASEPROPERTYEX('test', 'Version') IS NOT NULL
BEGIN
	ALTER DATABASE [test]
	SET SINGLE_USER 
	WITH ROLLBACK IMMEDIATE;

	DROP DATABASE [test];
END
GO

-- create test database
CREATE DATABASE [test]
ON  PRIMARY 
(	NAME = N'test', 
	FILENAME = N'C:\Data\test.mdf', 
	SIZE = 5120KB, 
	FILEGROWTH = 1024KB 
)
LOG ON 
(	NAME = N'test_log', 
	FILENAME = N'C:\Data\test_log.ldf', 
	SIZE = 1024KB, 
	MAXSIZE = 5120KB, 
	FILEGROWTH = 512KB 
)
GO

-- simple recovery model
ALTER DATABASE [test] SET RECOVERY SIMPLE;
GO
-- set full durable
ALTER DATABASE [test] SET DELAYED_DURABILITY = DISABLED;
GO

-- create table
USE [test]
GO

CREATE TABLE [dbo].[StressTable](
	[Guid] [uniqueidentifier] NOT NULL,
	[Text] [char](100) NOT NULL,
	CONSTRAINT [PK_StressTable] PRIMARY KEY CLUSTERED ([Guid])
);
GO

-- initial data
INSERT INTO [dbo].[StressTable] ([Guid], [Text])
VALUES (NEWID(), 'bla-bla-bla');
GO 5

-- add counters to Performance Monitor:
-- 1) Transactions/sec
-- 2) Log Flushes/sec
-- then run script 3b

-- set delayed durable
ALTER DATABASE [test] SET DELAYED_DURABILITY = FORCED;
GO
