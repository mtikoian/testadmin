USE Demo
go
create table TEST
(
idx int 
)

TRUNCATE TABLE TEST


SET XACT_ABORT OFF
GO
BEGIN TRAN
INSERT INTO test VALUES (100/2)
INSERT INTO test VALUES (100/0) -- Divided by zero error
INSERT INTO test VALUES (100/4)
COMMIT TRAN

SELECT @@TRANCOUNT
SELECT * FROM test


SET XACT_ABORT ON
go
BEGIN TRAN
INSERT INTO test VALUES (100/2)
INSERT INTO test VALUES (100/0) -- Divided by zero error
INSERT INTO test VALUES (100/4)
COMMIT TRAN

SELECT * FROM test
select @@TRANCOUNT


CHECKPOINT
SELECT * FROM sys.fn_dblog(null,null)