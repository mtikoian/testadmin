USE master
GO

DROP DATABASE LogDemo
GO 

-- Create db with no log autogrow
CREATE DATABASE [LogDemo] 
ON  PRIMARY 
(NAME = N'LogDemo', 
 FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL11.MSSQLSERVER\MSSQL\DATA\LogDemo.mdf' , 
 SIZE = 1GB , 
 FILEGROWTH = 2048MB 
)
LOG ON 
( NAME = N'LogDemo_log', 
  FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL11.MSSQLSERVER\MSSQL\DATA\LogDemo_log.ldf' , 
  SIZE = 1024KB , 
  FILEGROWTH = 0)
GO

USE LogDemo
GO

--FULL recovery model so checkpoint doesn't truncate
ALTER DATABASE LogDemo SET RECOVERY FULL WITH ROLLBACK IMMEDIATE;
GO

BACKUP DATABASE LogDemo TO DISK = 'C:\Temp\LogDemo.bak'
GO

--create table
CREATE TABLE bar (c1 INT IDENTITY, c2 NCHAR(4000) DEFAULT 'Demo')
GO

--what do the VLFs look like?
DBCC LOGINFO(LogDemo)
DBCC SQLPERF(LOGSPACE)
GO


-- Insert some rows 
INSERT INTO bar DEFAULT VALUES;
GO 10

select * from bar


--VLFs
DBCC LOGINFO(LogDemo)
DBCC SQLPERF(LOGSPACE)

-- uncommitted transaction
BEGIN TRAN
INSERT bar DEFAULT VALUES;
GO

-- What does the log look like?
DBCC LOGINFO;
DBCC SQLPERF(LOGSPACE)

GO

--fill the log
INSERT INTO bar DEFAULT VALUES;
GO 1000

--why is it full
SELECT name, log_reuse_wait_desc FROM sys.databases 
GO

--what do VLFs look like
DBCC LOGINFO(LogDemo)
DBCC SQLPERF(LOGSPACE)

--okay back it up
BACKUP LOG LogDemo TO DISK = 'C:\Temp\LogDemo.trn' WITH INIT

--now what
DBCC LOGINFO;
DBCC SQLPERF(LOGSPACE)

GO


rollback
