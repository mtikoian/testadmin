USE [master];
GO

IF db_id('LogDemo') is not null  
	DROP DATABASE LogDemo;
GO

-- Create a database without specifying log
CREATE DATABASE [LogDemo] 
ON  PRIMARY 
(NAME = N'LogDemo', 
 FILENAME = N'D:\LogDemo.mdf' , 
 SIZE = 256MB , 
 FILEGROWTH = 2048MB 
)
go

--how big is the log
select * from sys.master_files where database_id = db_id('LogDemo')

--vlf's
dbcc loginfo('LogDemo')
go

--drop db
drop database LogDemo
GO

-- create larger db specifying small log
CREATE DATABASE [LogDemo] 
ON  PRIMARY 
(NAME = N'LogDemo', 
 FILENAME = N'D:\LogDemo.mdf' , 
 SIZE = 15GB , 
 FILEGROWTH = 2048MB 
)
LOG ON 
( NAME = N'LogDemo_log', 
  FILENAME = N'D:\LogDemo_log.ldf' , 
  SIZE = 1024KB , 
  FILEGROWTH = 10%)
go

--drop again
drop database LogDemo
GO

-- create larger db with default 25% log size
CREATE DATABASE [LogDemo] 
ON  PRIMARY 
(NAME = N'LogDemo', 
 FILENAME = N'D:\LogDemo.mdf' , 
 SIZE = 15GB , 
 FILEGROWTH = 2048MB 
)
go

--what do the VLF's look like now
dbcc loginfo('LogDemo')


--space used
dbcc sqlperf(logspace)


--what about a really big log
drop database LogDemo
GO

CREATE DATABASE [LogDemo] 
ON  PRIMARY 
(NAME = N'LogDemo', 
 FILENAME = N'D:\LogDemo.mdf' , 
 SIZE = 1GB , 
 FILEGROWTH = 2048MB 
)
LOG ON 
( NAME = N'LogDemo_log', 
  FILENAME = N'D:\LogDemo_log.ldf' , 
  SIZE = 16GB , 
  FILEGROWTH = 10%)
go

DBCC LOGINFO('LogDemo')


--what about a 200GB log?  And so on.




