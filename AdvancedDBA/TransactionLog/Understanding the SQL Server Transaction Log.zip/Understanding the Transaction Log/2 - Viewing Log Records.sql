USE [master];
GO

-- get rid of extraneous log records
ALTER DATABASE LogDemo SET RECOVERY SIMPLE WITH ROLLBACK IMMEDIATE
ALTER DATABASE LogDemo SET AUTO_CREATE_STATISTICS OFF
GO

CHECKPOINT
GO


--create a table and insert 5 rows
use LogDemo
go

DROP TABLE foo
CREATE TABLE foo (c1 int, c2 int)

INSERT foo VALUES(1,2)
GO 5

SELECT * FROM foo


--view log records
SELECT * FROM fn_dblog (NULL, NULL);
GO

--update record
CHECKPOINT

UPDATE foo SET c1= 2 where c2 = 2

--view log records
SELECT * FROM fn_dblog (NULL, NULL);
GO

--delete
CHECKPOINT

DELETE foo

SELECT * FROM fn_dblog (NULL, NULL);
GO


