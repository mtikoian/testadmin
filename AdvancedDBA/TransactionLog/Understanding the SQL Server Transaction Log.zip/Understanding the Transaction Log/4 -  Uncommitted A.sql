USE LogDemo
GO

--make sure we're in full
ALTER DATABASE LogDemo SET RECOVERY FULL WITH ROLLBACK IMMEDIATE
GO

--where are we at
DBCC LOGINFO()
GO

--add 10 rows
INSERT bar DEFAULT VALUES
GO 10

DBCC LOGINFO()
GO

--add 10 more
INSERT bar DEFAULT VALUES
GO 10

DBCC LOGINFO()
GO

--add 10 more
INSERT bar DEFAULT VALUES
GO 10

DBCC LOGINFO()
GO

--go to 2nd connection


--backup log
BACKUP LOG LogDemo TO DISK = 'C:\Temp\LogDemo.trn' WITH INIT
GO

DBCC LOGINFO()

--insert 20 rows
INSERT bar DEFAULT VALUES
GO 20

DBCC LOGINFO()
GO

--insert 20 rows
INSERT bar DEFAULT VALUES
GO 20

DBCC LOGINFO()

--backup log
BACKUP LOG LogDemo TO DISK = 'C:\Temp\LogDemo.trn' WITH INIT
GO

DBCC LOGINFO()
GO

--go to 2nd connection and rollback

--backup log again
BACKUP LOG LogDemo TO DISK = 'C:\Temp\LogDemo.trn' WITH INIT
GO

DBCC LOGINFO()
GO







