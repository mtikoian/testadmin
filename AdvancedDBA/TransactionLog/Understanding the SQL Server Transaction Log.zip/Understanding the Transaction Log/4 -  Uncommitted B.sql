--explict tran
BEGIN TRAN

--add row
INSERT bar DEFAULT VALUES
GO

--go back to first connection

ROLLBACK

