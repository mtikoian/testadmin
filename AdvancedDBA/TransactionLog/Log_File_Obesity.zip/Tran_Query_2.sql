use Mr_T_log
begin tran OPEN_24_HOURS;
exec foo_insertdata 2000;

--rollback tran OPEN_24_HOURS;