USE [NorthwindDW]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ProcessPTSTABLE]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[ProcessPTSTABLE]
GO

CREATE PROCEDURE [dbo].[ProcessPTSTABLE]
	@messagebody XML
WITH EXECUTE AS 'NWSyncUser'
AS
  SET NOCOUNT ON
  BEGIN TRY
  
    -- Create a temporary table to hold the message results
    CREATE TABLE #PTSTABLE(
    	[Action] [nchar](1) NOT NULL,
    	[PTSKEY] [int] NOT NULL,
    	-- Remaining columns here
    );
    
    -- Use XQuery to shred the message and insert it into the temporary table
    INSERT INTO #PTSTABLE
    select  a.value(N'(./Action)[1]', N'nchar(1)') as [Action],
        a.value(N'(./PTSKEY)[1]', N'int') as [PTSKEY],
        -- Remaining columns here
    from @messagebody.nodes('/SBETL/row') as r(a);
    
    -- Insert or Update the rows based on the incoming changes

    DELETE cs
    FROM [dbo].[PTSTABLE] cs
    INNER JOIN #PTSTABLE t ON cs.[PTSKEY] = t.[PTSKEY]
    
    DELETE
    FROM #PTSTABLE
    WHERE [Action] = 'D'

    FROM #PTSTABLE

  END TRY

  BEGIN CATCH
    -- Insert any errors into the ErrorLog table for later review and correction
    INSERT INTO dbo.ErrorLog (ErrorTime, UserName, ErrorNumber, ErrorSeverity,
    	ErrorState, ErrorProcedure, ErrorLine, ErrorMessage, MessageBody)
    VALUES (getdate(), USER_NAME(), ERROR_NUMBER(), ERROR_SEVERITY(),
    	ERROR_STATE(), ERROR_PROCEDURE(), ERROR_LINE(), ERROR_MESSAGE(), @messagebody)
  
  END CATCH

  RETURN

GO
