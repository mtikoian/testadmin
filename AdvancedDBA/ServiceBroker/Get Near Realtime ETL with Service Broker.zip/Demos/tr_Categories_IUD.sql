USE [Northwind]
GO

IF OBJECT_ID ('dbo.tr_Categories_IUD','TR') IS NOT NULL
   DROP TRIGGER dbo.tr_Categories_IUD 
GO

CREATE TRIGGER dbo.tr_Categories_IUD
   ON  [dbo].[Categories]
   FOR INSERT, UPDATE, DELETE
AS 

  DECLARE @InitDlgHandle UNIQUEIDENTIFIER;
  DECLARE @ChangeMsg XML;
  DECLARE @ChangeCnt int;
  DECLARE @Action char(1);
  DECLARE @TableName varchar(100) = 'Categories';
  DECLARE @service_name nvarchar(512) = N'//NWSyncSite/NWSyncService';
	
  SELECT @InitDlgHandle=[ch]
  FROM [dbo].[BrokerConversation]
  WHERE [service_name] = @service_name;
  
  BEGIN TRY
    BEGIN
      
      -- If there are rows in both inserted and deleted, the change is an update
      SELECT @ChangeCnt = count(*)
        FROM [dbo].[Categories] t
        INNER JOIN deleted d on t.[CategoryID] = d.[CategoryID]
        INNER JOIN inserted i on t.[CategoryID] = i.[CategoryID];
      if (@ChangeCnt > 0)
        BEGIN;
        SET @Action = 'U';
        END;
      ELSE
        BEGIN
        -- Since rows aren't in both inserted and deleted, then the change is an insert or a delete
        -- If there are rows in deleted, the change is a delete, and we only need the primary key value
        select @ChangeCnt = count(*) from deleted
        if (@ChangeCnt > 0)
          BEGIN
          SET @Action = 'D';
          END;
        
        -- If there are rows in inserted, the change is an insert and we need all the column values
        select @ChangeCnt = count(*) from inserted
        if (@ChangeCnt > 0)
          BEGIN
          SET @Action = 'I';
          END;
      
        END;

      if (@Action = 'D')
        BEGIN;
        -- Build the XML message, flagging it as an update
        set @ChangeMsg = (
        SELECT @Action as [Action]
              ,@TableName as [TableName]
              ,t.[CategoryID]
              ,t.[CategoryName]
              ,t.[CategoryDescription]
          FROM [dbo].[Categories] t
          INNER JOIN deleted d on t.[CategoryID] = d.[CategoryID]
          FOR XML RAW, ELEMENTS, ROOT ('SBETL')
          );
        END;
      ELSE
        BEGIN;
        -- Build the XML message, flagging it as an update
        set @ChangeMsg = (
        SELECT @Action as [Action]
              ,@TableName as [TableName]
              ,t.[CategoryID]
              ,t.[CategoryName]
              ,t.[CategoryDescription]
          FROM [dbo].[Categories] t
          INNER JOIN inserted i on t.[CategoryID] = i.[CategoryID]
          FOR XML RAW, ELEMENTS, ROOT ('SBETL')
          );
        END;

    IF @ChangeMsg IS NOT NULL
      BEGIN
      BEGIN TRANSACTION;
      ;SEND ON CONVERSATION @InitDlgHandle
           MESSAGE TYPE [//NorthWindSync/SBETL]
           (@ChangeMsg);
      --END CONVERSATION @InitDlgHandle;
      COMMIT TRANSACTION;
      END
    END
  END TRY
  BEGIN CATCH
  	IF XACT_STATE() <> 0
  		BEGIN
		-- Rollback any pending transaction
		ROLLBACK TRANSACTION;
		END	
	
	-- Insert the error information into the ErrorLog Categories for later reference
  	INSERT INTO dbo.ErrorLog (ErrorTime, UserName, ErrorNumber, ErrorSeverity,
  		ErrorState, ErrorProcedure, ErrorLine, ErrorMessage)
  	VALUES (getdate(), USER_NAME(), ERROR_NUMBER(), ERROR_SEVERITY(),
  		ERROR_STATE(), ERROR_PROCEDURE(), ERROR_LINE(), ERROR_MESSAGE())
  
  END CATCH
  
GO

EXEC sp_settriggerorder @triggername=N'[dbo].[tr_Categories_IUD]', @order=N'Last', @stmttype=N'DELETE'
GO

EXEC sp_settriggerorder @triggername=N'[dbo].[tr_Categories_IUD]', @order=N'Last', @stmttype=N'INSERT'
GO

EXEC sp_settriggerorder @triggername=N'[dbo].[tr_Categories_IUD]', @order=N'Last', @stmttype=N'UPDATE'
GO


