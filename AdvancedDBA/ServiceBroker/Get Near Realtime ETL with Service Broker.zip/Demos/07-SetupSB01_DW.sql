USE NorthwindDW
GO

ALTER QUEUE DWSyncQueue
WITH ACTIVATION
(
	STATUS = ON,
	PROCEDURE_NAME = [dbo].[ProcessSyncMessages],
	MAX_QUEUE_READERS = 1,
	EXECUTE AS 'DWSyncUser'
)
GO
GRANT EXECUTE ON dbo.ProcessSyncMessages to DWSyncUser
GO
