USE [NorthwindDW]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ProcessCategories]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[ProcessCategories]
GO

CREATE PROCEDURE [dbo].[ProcessCategories]
	@messagebody XML
WITH EXECUTE AS 'NWSyncUser'
AS
  SET NOCOUNT ON
  BEGIN TRY
  
    -- Create a temporary table to hold the message results
    CREATE TABLE #Categories (
	[Action] nchar(1) NULL,
	[CategoryID]  Int NULL,
	[CategoryName]  NVarChar(15) NULL,
	[CategoryDescription]  NVarChar(250) NULL
	)
    
    -- Use XQuery to shred the message and insert it into the temporary table
    INSERT INTO #Categories
    SELECT
    	a.value(N'(./Action)[1]', N'nchar(1)') as [Action],
    	a.value(N'(./CategoryID)[1]', N'Int') as [CategoryID],
    	a.value(N'(./CategoryName)[1]', N'NVarChar(15)') as [CategoryName],
    	a.value(N'(./CategoryDescription)[1]', N'NVarChar(250)') as [CategoryDescription]
    	from @messagebody.nodes('/SBETL/row') as r(a);
    
    -- Delete the existing rows for the incoming changes, then insert the ones that aren't deletes

    DELETE cs
    FROM [Reference].[Categories] cs
    INNER JOIN #Categories t ON cs.[CategoryID] = t.[CategoryID]
    
    DELETE
    FROM #Categories
    WHERE [Action] = 'D'

    INSERT INTO [Reference].[Categories]
           ([CategoryID]
           ,[CategoryName]
           ,[CategoryDescription])
    SELECT [CategoryID]
      ,[CategoryName]
      ,[CategoryDescription]
    FROM #Categories

  END TRY

  BEGIN CATCH
    -- Insert any errors into the ErrorLog table for later review and correction
    INSERT INTO dbo.ErrorLog (ErrorTime, UserName, ErrorNumber, ErrorSeverity,
    	ErrorState, ErrorProcedure, ErrorLine, ErrorMessage, MessageBody)
    VALUES (getdate(), USER_NAME(), ERROR_NUMBER(), ERROR_SEVERITY(),
    	ERROR_STATE(), ERROR_PROCEDURE(), ERROR_LINE(), ERROR_MESSAGE(), @messagebody)
  
  END CATCH

  RETURN

GO
