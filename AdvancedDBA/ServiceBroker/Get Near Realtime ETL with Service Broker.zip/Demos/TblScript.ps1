$svr = New-Object Microsoft.SqlServer.Management.Smo.Server WS12SQL01
$db = $svr.Databases['Northwind']
foreach ($tbl in $db.Tables) {
    $tblnm = $tbl.Name
    $clst = @()
    foreach ($col in $tbl.Columns) {
        $cnm = $col.Name
        $cdn = $col.DataType.Name
        $cdt = $col.DataType.SqlDataType
        $cln = [string]$col.DataType.MaximumLength
        $cnp = [string]$col.DataType.NumericPrecision
        $cns = [string]$col.DataType.NumericScale
        if ($cln -eq -1) {
            $dtype = "$cdn(max)"
            }
        elseif (($cdt -like '*char*') -or ($cdt -like '*Char*') -or ($cdt -like '*binary*') -or ($cdt -like '*Binary*')) {
            $dtype = "$cdt($cln)"
            }
        elseif (($cdt -eq 'Numeric') -or ($cdt -eq 'Decimal')) {
            $dtype = "$cdt($cnp,$cns)"
            }
        else {
            $dtype = [string]$cdt
            }
        $mcol = New-Object System.Object
        $mcol | Add-Member -type NoteProperty -name Name -value $cnm
        $mcol | Add-Member -type NoteProperty -name DataType -value $dtype
        $clst += $mcol
        }
    $ddl = 'CREATE TABLE #' + $tblnm + ' ('
    Write-Output $ddl
    $ddl = "`t" + '[Action] nchar(1) NULL,'
    Write-Output $ddl
    $i = 0
    $ccnt = $clst.Count
    foreach ($cl in $clst) {
        $i++
        $cnm = $cl.Name
        $cdt = $cl.DataType
        $ddl = "`t[$cnm]  $cdt NULL"
        if ($i -lt $ccnt) {
            $ddl = $ddl + ','
            }
        Write-Output $ddl
        if ($i -eq $ccnt) {
            Write-Output "`t)"
            }
        }
    $ddl = 'INSERT INTO #' + $tblnm
    Write-Output $ddl
    Write-Output 'SELECT'
    $ddl = "`ta.value(N'(./Action)[1]', N'nchar(1)') as [Action],"
    Write-Output $ddl

    $i = 0
    $ccnt = $clst.Count
    foreach ($cl in $clst) {
        $i++
        $cnm = $cl.Name
        $cdt = $cl.DataType
        $ddl = [string]"`t" + 'a.value(N''(./' + $cnm + ')[1]'', N''' + $cdt + ''') as [' + $cnm + ']'
        if ($i -lt $ccnt) {
            $ddl = $ddl + ','
            }
        Write-Output $ddl
        if ($i -eq $ccnt) {
            $ddl = [string]"`t" + 'from @messagebody.nodes(''/SBETL/row'') as r(a);'
            Write-Output $ddl
            }
        }
    Write-Output ''

    $ddl = 'INSERT INTO ' + $tblnm + ' ('
    Write-Output $ddl
    $i = 0
    $ccnt = $clst.Count
    foreach ($cl in $clst) {
        $i++
        $cnm = $cl.Name
        $cdt = $cl.DataType
        $ddl = "`t[$cnm]"
        if ($i -lt $ccnt) {
            $ddl = $ddl + ','
            }
        Write-Output $ddl
        if ($i -eq $ccnt) {
            Write-Output "`t)"
            }
        }
    $ddl = 'SELECT '
    Write-Output $ddl
    $i = 0
    $ccnt = $clst.Count
    foreach ($cl in $clst) {
        $i++
        $cnm = $cl.Name
        $cdt = $cl.DataType
        $ddl = "`t[$cnm]"
        if ($i -lt $ccnt) {
            $ddl = $ddl + ','
            }
        Write-Output $ddl
        if ($i -eq $ccnt) {
            $ddl = 'FROM #' + $tblnm
            Write-Output $ddl
            }
        }
    Write-Output ''
    }
