USE NorthwindDW
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ProcessSyncData]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[ProcessSyncData]
GO

CREATE PROCEDURE [dbo].[ProcessSyncData]
AS
SET NOCOUNT ON
	DECLARE @id INT;
	DECLARE @ch UNIQUEIDENTIFIER
	DECLARE @messagetypename NVARCHAR(256)
	DECLARE	@messagebody XML
	DECLARE @responsemessage XML;
	DECLARE @returnrows INT;

	WHILE (1=1)
	BEGIN
		BEGIN TRY

			SELECT TOP 1 @id=id, @ch=ch, @messagetypename=messagetypename, @messagebody=messagebody
			FROM [dbo].[BrokerMessages]
			ORDER BY id;
			SELECT @returnrows = @@ROWCOUNT
			
			IF (@returnrows > 0)
			BEGIN
				
				-- First extract the name of the table from the top row of the message
				DECLARE @TableName varchar(100);
				DECLARE @ETLTable TABLE (TableName varchar(100));

				INSERT INTO @ETLTable (TableName)
				select TOP 1 a.value(N'(./TableName)[1]', N'varchar(100)') as TableName
				from @messagebody.nodes('/SBETL/row') as r(a);

				SELECT @TableName = TableName FROM @ETLTable;

				-- Now call the procedure corresponding to the table passed into the message
				IF (@TableName = 'Categories')
					BEGIN
					EXEC dbo.ProcessCategories @messagebody;
					END
				IF (@TableName = 'Customers')
					BEGIN
					EXEC dbo.ProcessCustomers @messagebody;
					END
				IF (@TableName = 'Employees')
					BEGIN
					EXEC dbo.ProcessEmployees @messagebody;
					END
				IF (@TableName = 'OrderDetails')
					BEGIN
					EXEC dbo.ProcessOrderDetails @messagebody;
					END
				IF (@TableName = 'Orders')
					BEGIN
					EXEC dbo.ProcessOrders @messagebody;
					END
				IF (@TableName = 'Products')
					BEGIN
					EXEC dbo.ProcessProducts @messagebody;
					END
				IF (@TableName = 'Shippers')
					BEGIN
					EXEC dbo.ProcessShippers @messagebody;
					END
				IF (@TableName = 'Suppliers')
					BEGIN
					EXEC dbo.ProcessSuppliers @messagebody;
					END

				-- Delete the message so it's only processed once
				DELETE FROM [dbo].[BrokerMessages]
				WHERE id = @id;
			END
			ELSE
			BEGIN
				-- If we're out of messages, wait a minute and then check again
				WAITFOR DELAY '00:01:00';
			END

		END TRY
		BEGIN CATCH
				
			INSERT INTO dbo.ErrorLog (ErrorTime, UserName, ErrorNumber, ErrorSeverity,
				ErrorState, ErrorProcedure, ErrorLine, ErrorMessage, MessageBody)
			VALUES (getdate(), USER_NAME(), ERROR_NUMBER(), ERROR_SEVERITY(),
				ERROR_STATE(), ERROR_PROCEDURE(), ERROR_LINE(), ERROR_MESSAGE(), @messagebody)

		END CATCH
	END
GO