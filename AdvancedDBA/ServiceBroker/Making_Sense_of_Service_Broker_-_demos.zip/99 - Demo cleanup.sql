:CONNECT ASUS\BLANTONS

USE msdb
GO
IF EXISTS (SELECT 1 FROM sys.routes WHERE name = 'JoeTaxpayerRoute')
	DROP ROUTE JoeTaxpayerRoute

USE master
GO
IF EXISTS (SELECT 1 FROM sys.server_principals WHERE name = 'ASUS\SQLSvcBookers')
	DROP LOGIN [ASUS\SQLSvcBookers]


IF EXISTS (SELECT * FROM sys.endpoints WHERE name = 'BlantonsEndpoint' and type_desc = 'SERVICE_BROKER')
	DROP ENDPOINT [BlantonsEndPoint]

-- drop the demo database
if exists (select * from sys.databases where name = 'SBDemoDB1')
BEGIN
	alter database [SBDemoDB1] set single_user with rollback immediate
	DROP DATABASE [SBDemoDB1] 
END

:CONNECT ASUS\BOOKERS

USE msdb
GO
IF EXISTS (SELECT 1 FROM sys.routes WHERE name = 'IRSRoute')
	DROP ROUTE IRSRoute

USE master
GO
IF EXISTS (SELECT 1 FROM sys.server_principals WHERE name = 'ASUS\SQLSvcBlantons')
	DROP LOGIN [ASUS\SQLSvcBlantons]


IF EXISTS (SELECT * FROM sys.endpoints WHERE name = 'BookersEndpoint' and type_desc = 'SERVICE_BROKER')
	DROP ENDPOINT [BookersEndPoint]

-- drop the demo database
if exists (select * from sys.databases where name = 'SBDemoDB2')
BEGIN
	alter database [SBDemoDB2] set single_user with rollback immediate
	DROP DATABASE [SBDemoDB2] 
END