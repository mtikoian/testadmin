
USE [SBDemoDB1]
GO

--view the target queue without removing any messages
SELECT * FROM IRSQueue
GO


DECLARE @RecvReqDlgHandle UNIQUEIDENTIFIER;
DECLARE @RecvReqMsg NVARCHAR(100);
DECLARE @RecvReqMsgName sysname;

BEGIN TRANSACTION;

	RECEIVE TOP(1)
		@RecvReqDlgHandle = conversation_handle,
		@RecvReqMsg = message_body,
		@RecvReqMsgName = message_type_name
	FROM IRSQueue

	SELECT @RecvReqMsg AS ReceivedRequestMsg;

	IF @RecvReqMsgName =
	   N'//SBDemo/Taxes/TaxFormMessage'
	BEGIN
		 DECLARE @ReplyMsg NVARCHAR(100);
		 SELECT @ReplyMsg =
		 N'<ReplyMsg>Here is your refund!</ReplyMsg>';
 
		 SEND ON CONVERSATION @RecvReqDlgHandle
			  MESSAGE TYPE 
			  [//SBDemo/Taxes/ReplyMessage]
			  (@ReplyMsg);

		 END CONVERSATION @RecvReqDlgHandle;
	END

	SELECT @ReplyMsg AS SentReplyMsg;

COMMIT TRANSACTION;
GO
