
USE [SBDemoDB1]
GO

DECLARE @InitDlgHandle UNIQUEIDENTIFIER;
DECLARE @TaxFormMessage NVARCHAR(100);

BEGIN TRANSACTION;

--open a dialog between the initiator service and target service
BEGIN DIALOG @InitDlgHandle
     FROM SERVICE
      [//SBDemo/Taxes/JoeTaxpayerService]
     TO SERVICE
      N'//SBDemo/Taxes/IRSService'
     ON CONTRACT
      [//SBDemo/Taxes/TaxContract]
     WITH
         ENCRYPTION = OFF;

--build the message
SELECT @TaxFormMessage =
       N'<RequestMsg>This is my 1040EZ Form.</RequestMsg>';

--send the message using the id of the conversation started above
--specify the Request message, which can only be sent by the conversation initiator
SEND ON CONVERSATION @InitDlgHandle
     MESSAGE TYPE 
     [//SBDemo/Taxes/TaxFormMessage]
     (@TaxFormMessage);

SELECT @TaxFormMessage AS SentRequestMsg;

COMMIT TRANSACTION;
GO