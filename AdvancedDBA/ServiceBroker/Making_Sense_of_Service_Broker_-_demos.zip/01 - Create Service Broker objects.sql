
USE [master]
GO

-- create the demo database
if exists (select * from sys.databases where name = 'SBDemoDB1')
BEGIN
	alter database [SBDemoDB1] set single_user with rollback immediate
	DROP DATABASE [SBDemoDB1] 
END
GO
CREATE DATABASE [SBDemoDB1]
GO

USE master;
GO
--enable service broker in our user database
ALTER DATABASE [SBDemoDB1] SET ENABLE_BROKER
GO
USE [SBDemoDB1]
GO

--create the message types
--use URI format in the message type name to ensure the name is unique across Service Broker instances
--in this case, we're telling SQL Server to validate that messages are well-formed XML, but not a specific schema
CREATE MESSAGE TYPE
       [//SBDemo/Taxes/TaxFormMessage]
       VALIDATION = WELL_FORMED_XML;
CREATE MESSAGE TYPE
       [//SBDemo/Taxes/ReplyMessage]
       VALIDATION = WELL_FORMED_XML;
GO

--create the contract
CREATE CONTRACT [//SBDemo/Taxes/TaxContract]
      ([//SBDemo/Taxes/TaxFormMessage] SENT BY INITIATOR,
       [//SBDemo/Taxes/ReplyMessage] SENT BY TARGET
      );
GO

--create the initiator queue and service
CREATE QUEUE JoeTaxpayerQueue;

CREATE SERVICE
       [//SBDemo/Taxes/JoeTaxpayerService]
       ON QUEUE JoeTaxpayerQueue
	   ([//SBDemo/Taxes/TaxContract]);
GO

--create the target queue and service
CREATE QUEUE IRSQueue;

CREATE SERVICE
       [//SBDemo/Taxes/IRSService]
       ON QUEUE IRSQueue
	   ([//SBDemo/Taxes/TaxContract]);
GO


