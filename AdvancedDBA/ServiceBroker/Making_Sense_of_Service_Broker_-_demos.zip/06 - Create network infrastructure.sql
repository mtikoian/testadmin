--because messages are traveling over the network, we need to create a TCP endpoint in each
--SQL Server instance to listen for Service Broker messages coming from remote servers
--here we create the endpoint for the target service

:CONNECT ASUS\BOOKERS
USE master;
GO
IF EXISTS (SELECT * FROM master.sys.endpoints
           WHERE name = N'BookersEndpoint')
     DROP ENDPOINT BookersEndpoint;
GO
CREATE ENDPOINT BookersEndpoint
STATE = STARTED
AS TCP ( LISTENER_PORT = 4022 )
FOR SERVICE_BROKER (AUTHENTICATION = WINDOWS );
GO

--now create an endpoint for the initiator service
:CONNECT ASUS\BLANTONS
USE master;
GO
IF EXISTS (SELECT * FROM master.sys.endpoints
           WHERE name = N'BlantonsEndpoint')
     DROP ENDPOINT BlantonsEndpoint;
GO
CREATE ENDPOINT BlantonsEndpoint
STATE = STARTED
AS TCP ( LISTENER_PORT = 4023 )
FOR SERVICE_BROKER (AUTHENTICATION = WINDOWS );
GO

--Now we need to create routes so SQL Server knows where to find the specified services
--First on the initiator, we create a route to the target service in the SBDemoDB1
--We also create a local route so that SQL Server knows where to direct replies
:CONNECT ASUS\BLANTONS
USE [SBDemoDB1]
CREATE ROUTE IRSRoute
WITH SERVICE_NAME =
       N'//SBDemo/Taxes/IRSService',
     ADDRESS = N'TCP://ASUS:4022'; --the Bookers endpoint
GO

USE msdb
CREATE ROUTE JoeTaxpayerRoute
WITH SERVICE_NAME =
       N'//SBDemo/Taxes/JoeTaxpayerService',
     ADDRESS = N'LOCAL'
GO

--Now do the same thing on the target server
:CONNECT ASUS\BOOKERS
USE [SBDemoDB2]
CREATE ROUTE JoeTaxpayerRoute
WITH SERVICE_NAME =
       N'//SBDemo/Taxes/JoeTaxpayerService',
     ADDRESS = N'TCP://ASUS:4023'; --the Blantons endpoint
GO

USE msdb
CREATE ROUTE IRSRoute
WITH SERVICE_NAME =
       N'//SBDemo/Taxes/IRSService',
     ADDRESS = N'LOCAL'
GO