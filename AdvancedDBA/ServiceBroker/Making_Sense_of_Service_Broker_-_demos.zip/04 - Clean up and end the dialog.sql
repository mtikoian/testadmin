USE SBDemoDB1
GO

--the reply message sent will be in the JoeTaxpayerQueue
--along with it, will be the EndDialog message, which will tell Service Broker to end the conversation
SELECT * FROM JoeTaxpayerQueue

DECLARE @RecvReplyMsg NVARCHAR(100);
DECLARE @RecvReplyDlgHandle UNIQUEIDENTIFIER;

BEGIN TRANSACTION;

RECEIVE TOP(1)
    @RecvReplyDlgHandle = conversation_handle,
    @RecvReplyMsg = message_body
FROM JoeTaxpayerQueue

END CONVERSATION @RecvReplyDlgHandle;

SELECT @RecvReplyMsg AS ReceivedReplyMsg;

COMMIT TRANSACTION;
GO