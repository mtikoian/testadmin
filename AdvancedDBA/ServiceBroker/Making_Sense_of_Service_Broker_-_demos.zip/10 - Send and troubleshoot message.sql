
USE [SBDemoDB1]
GO

DECLARE @InitDlgHandle UNIQUEIDENTIFIER;
DECLARE @RequestMsg NVARCHAR(100);

BEGIN TRANSACTION;

--open a dialog between the initiator service and target service
BEGIN DIALOG @InitDlgHandle
     FROM SERVICE
      [//SBDemo/Taxes/JoeTaxpayerService]
     TO SERVICE
      N'//SBDemo/Taxes/IRSService'
     ON CONTRACT
      [//SBDemo/Taxes/TaxContract]
     WITH
         ENCRYPTION = OFF;

--build the message
SELECT @RequestMsg =
       N'<RequestMsg>Can I file an extension?</RequestMsg>';

--send the message using the id of the conversation started above
--specify the Request message, which can only be sent by the conversation initiator
SEND ON CONVERSATION @InitDlgHandle
     MESSAGE TYPE 
     [//SBDemo/Taxes/TaxFormMessage]
     (@RequestMsg);

SELECT @RequestMsg AS SentRequestMsg;

COMMIT TRANSACTION;
GO

--Check if the message was received
:CONNECT ASUS\Bookers
USE [SBDemoDB2]
SELECT * FROM IRSQueue


--check the transmission_status column in sys.transmission_queue
select * from sys.transmission_queue
--there's a problem, but what is it?


--check the error log on the initiator and on the target instance
/*
From Bookers error log:
Message
Service Broker login attempt by user 'ASUS\SQLSvcBlantons.' failed with error: 'Connection handshake failed. The login 'ASUS\SQLSvcBlantons' does not have CONNECT permission on the endpoint. State 84.'.  [CLIENT: 2001:0:9d38:6abd:1457:6de:e7a2:421b]
*/

--We need to configure Transport Security.  Since we're in the same domain, we can use
--Windows authentication.  Create a login for the Blantons service account in the Bookers
--instance, and vice-versa.  Grant each login connect permission to the endpoint on that
--instance.  Finally, grant SEND on the local service to PUBLIC.  There are other ways 
--to configure transport security, but this is the easiest.

--create Bookers login on Blantons
:CONNECT ASUS\BLANTONS
USE master
GO
create login [ASUS\SQLSvcBookers] from WINDOWS;
GRANT CONNECT ON ENDPOINT::BlantonsEndpoint to [ASUS\SQLSvcBookers];
GO
USE [SBDemoDB1]
GO
GRANT SEND ON SERVICE::[//SBDemo/Taxes/JoeTaxpayerService] to PUBLIC

--create Blantons login on Bookers
:CONNECT ASUS\BOOKERS
USE master
GO
create login [ASUS\SQLSvcBlantons] from WINDOWS;
GRANT CONNECT ON ENDPOINT::BookersEndpoint to [ASUS\SQLSvcBlantons];
GO
USE [SBDemoDB2]
GO
GRANT SEND ON SERVICE::[//SBDemo/Taxes/IRSService] to PUBLIC

--check the transmission_status column in sys.transmission_queue
select * from sys.transmission_queue

--select cast(message_body as XML) from JoeTaxpayerQueue

--end conversation 'CD7D972A-3CBA-E511-BE83-0025D3AF5B03' 