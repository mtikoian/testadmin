RECEIVE CONVERT(NVARCHAR(max), message_body) AS message FROM StockReceiveQueue 
