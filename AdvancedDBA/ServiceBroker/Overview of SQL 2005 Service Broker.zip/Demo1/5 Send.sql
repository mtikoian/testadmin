DECLARE @StockDialog uniqueidentifier
DECLARE @Message nvarchar(128)
BEGIN DIALOG CONVERSATION @StockDialog
  FROM SERVICE StockSendService
  TO SERVICE 'StockReceiveService'
  ON CONTRACT StockContract
  WITH ENCRYPTION = OFF
SET @Message = N'Add 12 widgets to inventory';
SEND ON CONVERSATION @StockDialog 
  MESSAGE TYPE StockMessage (@Message)
SET @Message = N'Remove 4 springs from inventory';
SEND ON CONVERSATION @StockDialog 
  MESSAGE TYPE StockMessage (@Message)
SET @Message = N'Add 7 twonkies to inventory';
SEND ON CONVERSATION @StockDialog 
  MESSAGE TYPE StockMessage (@Message)
