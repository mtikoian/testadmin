USE master;
GO
ALTER DATABASE AdventureWorks
      SET ENABLE_BROKER;
GO
USE AdventureWorks;
GO