CREATE SERVICE StockSendService ON QUEUE StockSendQueue (StockContract)

CREATE SERVICE StockReceiveService ON QUEUE StockReceiveQueue (StockContract) 
