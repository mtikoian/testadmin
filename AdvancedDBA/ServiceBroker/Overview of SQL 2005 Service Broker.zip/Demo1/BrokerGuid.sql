SELECT service_broker_guid
FROM sys.databases
WHERE database_id = DB_ID() ;
