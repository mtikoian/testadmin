--------------------------------------------------------------------
-- Script for dialog pool sample.
--
-- This file is part of the Microsoft SQL Server Code Samples.
-- Copyright (C) Microsoft Corporation. All Rights reserved.
-- This source code is intended only as a supplement to Microsoft
-- Development Tools and/or on-line documentation. See these other
-- materials for detailed information regarding Microsoft code samples.
--
-- THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF
-- ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
-- THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
-- PARTICULAR PURPOSE.
--------------------------------------------------------------------

------------------------------------------------------------------------------
-- This sample shows how to create and use a shared pool of reuseable dialogs.
-- The purpose of reusing dialogs is to reduce the overhead of creating them.
-- The sample also shows how dialogs in the pool can be "recycled" by deleting
-- dialogs based on application criteria, such as number of messages sent.
------------------------------------------------------------------------------

--------------------------------------------------------------------------
-- Create demo database.
--------------------------------------------------------------------------

USE master;
GO

IF EXISTS (SELECT name FROM sys.databases WHERE name = 'SsbDemoDb')
      DROP DATABASE SsbDemoDb;

CREATE DATABASE SsbDemoDb;
GO

USE SsbDemoDb;
GO

-- Create master key
IF NOT EXISTS(SELECT name FROM sys.symmetric_keys WHERE name = '##MS_DatabaseMasterKey##')
      CREATE MASTER KEY ENCRYPTION BY PASSWORD='Password#123';
GO
