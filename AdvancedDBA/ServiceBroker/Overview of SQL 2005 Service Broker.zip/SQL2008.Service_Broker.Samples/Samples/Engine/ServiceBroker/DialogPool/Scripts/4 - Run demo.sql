--------------------------------------------------------------------
-- Script for dialog pool sample.
--
-- This file is part of the Microsoft SQL Server Code Samples.
-- Copyright (C) Microsoft Corporation. All Rights reserved.
-- This source code is intended only as a supplement to Microsoft
-- Development Tools and/or on-line documentation. See these other
-- materials for detailed information regarding Microsoft code samples.
--
-- THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF
-- ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
-- THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
-- PARTICULAR PURPOSE.
--------------------------------------------------------------------

------------------------------------------------------------------------------------
-- Run demo application.
------------------------------------------------------------------------------------

USE SsbDemoDb;
GO

--------------------------------------------------------------------------
-- Send messages from initiator to target.
-- Initiator uses dialogs from the dialog pool.
-- Initiator also retires dialogs based on application criteria,
-- which results in recycling dialogs in the pool.
--------------------------------------------------------------------------
exec usp_send 'SsbInitiatorService', 'SsbTargetService', 'SsbContract', 'SsbMsgType', '<xml>This is a well formed XML Message1.</xml>'
exec usp_send 'SsbInitiatorService', 'SsbTargetService', 'SsbContract', 'SsbMsgType', '<xml>This is a well formed XML Message2.</xml>'
exec usp_send 'SsbInitiatorService', 'SsbTargetService', 'SsbContract', 'SsbMsgType', '<xml>This is a well formed XML Message3.</xml>'
exec usp_send 'SsbInitiatorService', 'SsbTargetService', 'SsbContract', 'SsbMsgType', '<xml>This is a well formed XML Message4.</xml>'
exec usp_send 'SsbInitiatorService', 'SsbTargetService', 'SsbContract', 'SsbMsgType', '<xml>This is a well formed XML Message5.</xml>'
GO

-- Show the dialog pool
SELECT * FROM DialogPool;
GO

-- Show the dialogs used.
SELECT * FROM sys.conversation_endpoints;
GO

-- Check whether the TARGET side has processed the messages
SELECT * FROM MsgTable;
GO

TRUNCATE TABLE MsgTable;
GO

 

 
