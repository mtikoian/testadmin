--------------------------------------------------------------------
-- Script for dialog pool sample.
--
-- This file is part of the Microsoft SQL Server Code Samples.
-- Copyright (C) Microsoft Corporation. All Rights reserved.
-- This source code is intended only as a supplement to Microsoft
-- Development Tools and/or on-line documentation. See these other
-- materials for detailed information regarding Microsoft code samples.
--
-- THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF
-- ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
-- THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
-- PARTICULAR PURPOSE.
--------------------------------------------------------------------

--------------------------------------------------------------------------
-- Demo application setup.
--------------------------------------------------------------------------

USE SsbDemoDb;
GO

-- Create a table to hold the received messages.
IF EXISTS (SELECT name FROM sys.tables WHERE name = 'MsgTable')
      DROP TABLE MsgTable;
GO

CREATE TABLE MsgTable (message_type SYSNAME, message_body VARCHAR(4000));
GO

-- Activated store proc for the initiator to receive messages.
-- The low volume here permits receiving one message at a time.
CREATE PROCEDURE initiator_queue_activated_procedure
AS
BEGIN
     DECLARE @conversation_handle UNIQUEIDENTIFIER,
             @message_type_name SYSNAME,
             @message_body VARCHAR(MAX);

     -- Error variables.
     DECLARE @error_number INT;
     DECLARE @error_message VARCHAR(4000);
     DECLARE @error_severity INT;
     DECLARE @error_state INT;
     DECLARE @error_procedure SYSNAME;
     DECLARE @error_line INT;
     DECLARE @error_dialog VARCHAR(50);

     BEGIN TRY
     BEGIN TRANSACTION;

     -- Wait 5 seconds for a message.
     WAITFOR (
          RECEIVE TOP(1)
                  @conversation_handle = conversation_handle,
                  @message_type_name = message_type_name,
                  @message_body = message_body
          FROM initiator_queue), TIMEOUT 5000;

     IF @@ROWCOUNT = 1
     BEGIN
          IF @message_type_name = 'http://schemas.microsoft.com/SQL/ServiceBroker/EndDialog'
          BEGIN
               -- Target is ending dialog normally.
               END CONVERSATION @conversation_handle;
          END
          ELSE IF @message_type_name = 'http://schemas.microsoft.com/SQL/ServiceBroker/Error'
          BEGIN
               -- Raise the error.
               WITH XMLNAMESPACES ('http://schemas.microsoft.com/SQL/ServiceBroker/Error' AS ssb)
               SELECT
               @error_number = CAST(@message_body AS XML).value('(//ssb:Error/ssb:Code)[1]', 'INT'),
               @error_message = CAST(@message_body AS XML).value('(//ssb:Error/ssb:Description)[1]', 'VARCHAR(4000)');
               SET @error_dialog = CAST(@conversation_handle AS VARCHAR(50));
               RAISERROR('Error in dialog %s: %s (%i)', 16, 1, @error_dialog, @error_message, @error_number);

               -- End the conversation.
               END CONVERSATION @conversation_handle;
          END
     END
     COMMIT;
     END TRY
     BEGIN CATCH
           SET @error_number = ERROR_NUMBER();
           SET @error_message = ERROR_MESSAGE();
           SET @error_severity = ERROR_SEVERITY();
           SET @error_state = ERROR_STATE();
           SET @error_procedure = ERROR_PROCEDURE();
           SET @error_line = ERROR_LINE();
           SET @error_dialog = CAST(@conversation_handle AS VARCHAR(50));

           IF XACT_STATE() = -1
           BEGIN
                -- The transaction is doomed. Only rollback possible.
                ROLLBACK TRANSACTION;
                BEGIN TRANSACTION;

                -- Raise the error.
                RAISERROR('Error in dialog %s: %s (%i)', 16, 1, @error_dialog, @error_message, @error_number);
                COMMIT;
           END
           ELSE IF XACT_STATE() = 1
           BEGIN
                -- Raise the error and commit transaction.
                RAISERROR('Error in dialog %s: %s (%i)', 16, 1, @error_dialog, @error_message, @error_number);
                COMMIT;
           END
     END CATCH
END;
GO

-- Activated store proc for the target to receive messages.
CREATE PROCEDURE target_queue_activated_procedure
AS
BEGIN
    -- Variable table for received messages.
    DECLARE @receive_table TABLE(
            queuing_order BIGINT,
            conversation_handle UNIQUEIDENTIFIER,
            message_type_name SYSNAME,
            message_body VARCHAR(MAX));
    
    -- Cursor for received message table.
    DECLARE message_cursor CURSOR LOCAL FORWARD_ONLY READ_ONLY
            FOR SELECT
            conversation_handle,
            message_type_name,
            message_body
            FROM @receive_table ORDER BY queuing_order;

     DECLARE @conversation_handle UNIQUEIDENTIFIER;
     DECLARE @message_type SYSNAME;
     DECLARE @message_body VARCHAR(4000);

     -- Error variables.
     DECLARE @error_number INT;
     DECLARE @error_message VARCHAR(4000);
     DECLARE @error_severity INT;
     DECLARE @error_state INT;
     DECLARE @error_procedure SYSNAME;
     DECLARE @error_line INT;
     DECLARE @error_dialog VARCHAR(50);

     WHILE (1 = 1)
     BEGIN

         BEGIN TRY
         BEGIN TRANSACTION;
    
         -- Receive all available messages into the table.
         -- Wait 5 seconds for messages.
         WAITFOR (
    		RECEIVE
    		   [queuing_order],
    		   [conversation_handle],
    		   [message_type_name],
    		   CAST([message_body] AS VARCHAR(4000))
    		FROM [SsbTargetQueue]
    		INTO @receive_table
         ), TIMEOUT 5000;
    
         IF @@ROWCOUNT = 0
         BEGIN
              COMMIT TRANSACTION;
              BREAK;
         END
         ELSE
         BEGIN
              OPEN message_cursor;
              WHILE (1=1)
              BEGIN
                  FETCH NEXT FROM message_cursor
        	                INTO @conversation_handle,
        	                     @message_type,
        	                     @message_body;
        
                  IF (@@FETCH_STATUS != 0) BREAK;

                  IF @message_type = 'SsbMsgType'
                  BEGIN
                      -- process the msg. Here we will just insert it into a table
                      INSERT INTO MsgTable values(@message_type, @message_body);
                  END
                  ELSE IF @message_type = 'EndOfStream'
                  BEGIN
                      -- initiator is signaling end of message stream: end the dialog
                      END CONVERSATION @conversation_handle;
                  END
                  ELSE IF @message_type = 'http://schemas.microsoft.com/SQL/ServiceBroker/Error'
                  BEGIN
                       -- If the message_type indicates that the message is an error,
                       -- raise the error and end the conversation.
                       WITH XMLNAMESPACES ('http://schemas.microsoft.com/SQL/ServiceBroker/Error' AS ssb)
                       SELECT
                       @error_number = CAST(@message_body AS XML).value('(//ssb:Error/ssb:Code)[1]', 'INT'),
                       @error_message = CAST(@message_body AS XML).value('(//ssb:Error/ssb:Description)[1]', 'VARCHAR(4000)');
                       SET @error_dialog = CAST(@conversation_handle AS VARCHAR(50));
                       RAISERROR('Error in dialog %s: %s (%i)', 16, 1, @error_dialog, @error_message, @error_number);
  	               END CONVERSATION @conversation_handle;
                  END
              END
              CLOSE message_cursor;
              DELETE @receive_table;
         END
         COMMIT;
         END TRY
         BEGIN CATCH
               SET @error_number = ERROR_NUMBER();
               SET @error_message = ERROR_MESSAGE();
               SET @error_severity = ERROR_SEVERITY();
               SET @error_state = ERROR_STATE();
               SET @error_procedure = ERROR_PROCEDURE();
               SET @error_line = ERROR_LINE();
               SET @error_dialog = CAST(@conversation_handle AS VARCHAR(50));

               IF XACT_STATE() = -1
               BEGIN
                    -- The transaction is doomed. Only rollback possible.
                    -- This could disable the queue if done 5 times consecutively!
                    ROLLBACK TRANSACTION;
                    BEGIN TRANSACTION;

                    -- Raise the error.
                    RAISERROR('Error in dialog %s: %s (%i)', 16, 1, @error_dialog, @error_message, @error_number);
                    COMMIT;
               END
               ELSE IF XACT_STATE() = 1
               BEGIN
                    -- Raise error and commit transaction.
                    RAISERROR('Error in dialog %s: %s (%i)', 16, 1, @error_dialog, @error_message, @error_number);
                    COMMIT;
               END
         END CATCH
     END
END;
GO


-- Create Initiator and Target side SSB entities
CREATE MESSAGE TYPE SsbMsgType VALIDATION = WELL_FORMED_XML;
CREATE MESSAGE TYPE EndOfStream;

CREATE CONTRACT SsbContract
       (
        SsbMsgType SENT BY INITIATOR,
        EndOfStream SENT BY INITIATOR
       );

CREATE QUEUE SsbInitiatorQueue
      WITH ACTIVATION (
            STATUS = ON,
            MAX_QUEUE_READERS = 1,
            PROCEDURE_NAME = [initiator_queue_activated_procedure],
            EXECUTE AS OWNER);

CREATE QUEUE SsbTargetQueue
      WITH ACTIVATION (
            STATUS = ON,
            MAX_QUEUE_READERS = 1,
            PROCEDURE_NAME = [target_queue_activated_procedure],
            EXECUTE AS OWNER);

CREATE SERVICE SsbInitiatorService ON QUEUE SsbInitiatorQueue;
CREATE SERVICE SsbTargetService ON QUEUE SsbTargetQueue (SsbContract);
GO

-- SEND procedure. Uses a dialog from the dialog pool.
--
IF EXISTS (SELECT name FROM sys.procedures WHERE name = 'usp_send')
      DROP PROC usp_send;
GO

CREATE PROCEDURE [usp_send] (
      @fromService SYSNAME,
      @toService SYSNAME,
      @onContract SYSNAME,
      @messageType SYSNAME,
      @messageBody VARCHAR(MAX))
AS
BEGIN
      SET NOCOUNT ON;

      DECLARE @dialogHandle UNIQUEIDENTIFIER;
      DECLARE @sendCount BIGINT;
      DECLARE @counter INT;
      DECLARE @error INT;

      SELECT @counter = 1;
      BEGIN TRANSACTION;

      -- Will need a loop to retry in case the dialog is
      -- in a state that does not allow transmission
      --
      WHILE (1=1)
      BEGIN
            -- Claim a dialog from the dialog pool.
            -- A new one will be created if none are available.
            --
            EXEC usp_get_dialog @fromService, @toService, @onContract, @dialogHandle OUTPUT, @sendCount OUTPUT;

            -- Attempt to SEND on the dialog
            --
            IF (@messageBody IS NOT NULL)
            BEGIN
                  -- If the @messageBody is not null it must be sent explicitly
                  SEND ON CONVERSATION @dialogHandle MESSAGE TYPE @messageType (@messageBody);
            END
            ELSE
            BEGIN
                  -- Messages with no body must *not* specify the body,
                  -- cannot send a NULL value argument
                  SEND ON CONVERSATION @dialogHandle MESSAGE TYPE @messageType;
            END

            SELECT @error = @@ERROR;
            IF @error = 0
            BEGIN
                  -- Successful send, increment count and exit the loop
                  --
                  SET @sendCount = @sendCount + 1;
                  BREAK;
            END

            SELECT @counter = @counter+1;
            IF @counter > 10
            BEGIN
                  -- We failed 10 times in a  row, something must be broken
                  --
                  RAISERROR('Failed to SEND on a conversation for more than 10 times. Error %i.', 16, 1, @error) WITH LOG;
                  BREAK;
            END

            -- Delete the associated dialog from the table and try again
            --
            EXEC usp_delete_dialog @dialogHandle;
            SELECT @dialogHandle = NULL;
      END

      -- "Criterion" for dialog pool removal is send count > 1000.
      -- Modify to suit application.
      -- When deleting also inform the target to end the dialog.
      IF @sendCount > 1000
      BEGIN
         EXEC usp_delete_dialog @dialogHandle ;
         SEND ON CONVERSATION @dialogHandle MESSAGE TYPE [EndOfStream];
      END
      ELSE
      BEGIN
         -- Free the dialog.
         EXEC usp_free_dialog @dialogHandle, @sendCount;
      END

      COMMIT;
END;
GO
