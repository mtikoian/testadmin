--------------------------------------------------------------------
-- Script for dialog security sample.
--
-- This file is part of the Microsoft SQL Server Code Samples.
-- Copyright (C) Microsoft Corporation. All Rights reserved.
-- This source code is intended only as a supplement to Microsoft
-- Development Tools and/or on-line documentation. See these other
-- materials for detailed information regarding Microsoft code samples.
--
-- THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF
-- ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
-- THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
-- PARTICULAR PURPOSE.
--------------------------------------------------------------------

-- The initiator creates a database, queue, service, target route,
-- and certificate for the dialog to the target service.
-- Modify target_host and location of stored certificate in script
-- to suit configuration.

USE master;
GO

-- Create initiator database.
IF EXISTS (SELECT * FROM sys.databases WHERE name = 'initiator_database')
	DROP DATABASE initiator_database;
GO

CREATE DATABASE initiator_database;
GO

USE initiator_database;
GO

-- Create a message queue.
CREATE QUEUE initiator_queue;
GO

-- Create a service with a default contract.
CREATE SERVICE initiator_service ON QUEUE initiator_queue ([DEFAULT]);
GO

-- Create a route to the target service.
CREATE ROUTE target_route
	WITH SERVICE_NAME = 'target_service',
	ADDRESS = 'tcp://target_host:4022';
GO

-- Create a user who is authorized for the initiator service.
IF NOT EXISTS (SELECT * FROM sys.sysusers WHERE name = 'initiator_user')
	CREATE USER initiator_user WITHOUT LOGIN;
GO

ALTER AUTHORIZATION ON SERVICE::initiator_service TO initiator_user;
GO

-- A master key is required to use certificates. 
BEGIN TRANSACTION;
IF NOT EXISTS (SELECT * FROM sys.symmetric_keys WHERE name = '##MS_DatabaseMasterKey##')
	CREATE MASTER KEY ENCRYPTION BY PASSWORD='Password#123'
COMMIT;
GO

-- Create a certificate and associate it with the user.
IF EXISTS (SELECT * FROM sys.certificates WHERE name = 'initiator_dialog_cert')
	DROP CERTIFICATE initiator_dialog_cert;
GO

CREATE CERTIFICATE initiator_dialog_cert
	AUTHORIZATION initiator_user
	WITH SUBJECT = 'Dialog certificate for initiator';
GO

-- Backup to a file to allow the certificate to be given to the target.
BACKUP CERTIFICATE initiator_dialog_cert
	TO FILE = 'c:\initiator_dialog.cert';
GO

-- In msdb, create an incoming route to the initiator service.
USE msdb;
GO

CREATE ROUTE initiator_route
	WITH SERVICE_NAME = 'initiator_service',
	ADDRESS = 'local';
GO

USE initiator_database;
GO

