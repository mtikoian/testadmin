--------------------------------------------------------------------
-- Script for transport security sample.
--
-- This file is part of the Microsoft SQL Server Code Samples.
-- Copyright (C) Microsoft Corporation. All Rights reserved.
-- This source code is intended only as a supplement to Microsoft
-- Development Tools and/or on-line documentation. See these other
-- materials for detailed information regarding Microsoft code samples.
--
-- THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF
-- ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
-- THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
-- PARTICULAR PURPOSE.
--------------------------------------------------------------------

-- This script sets up a the initiator broker endpoint for transport 
-- certificate-based security.
-- Modify the location of the certificate in script to suit configuration.

USE master;
GO

-- A master key is required to use certificates.
BEGIN TRANSACTION;
IF NOT EXISTS (SELECT * FROM sys.symmetric_keys where name = '##MS_DatabaseMasterKey##')
	CREATE MASTER KEY ENCRYPTION BY PASSWORD='Password#123'
COMMIT;
GO

-- Create a certificate to authenticate the endpoint.
IF EXISTS (SELECT * FROM sys.certificates WHERE name = 'initiator_transport_cert')
	DROP CERTIFICATE initiator_transport_cert;
GO

CREATE CERTIFICATE initiator_transport_cert
	WITH SUBJECT = 'Service broker transport authentication for initiator';
GO

-- Backup to a file to allow the certificate to be given to the target.
BACKUP CERTIFICATE initiator_transport_cert
	TO FILE = 'c:\initiator_transport.cert';
GO

-- Create the broker endpoint using the certificate for authentication.
IF EXISTS (SELECT * FROM sys.endpoints WHERE name = 'service_broker_endpoint')
	DROP ENDPOINT service_broker_endpoint;
GO

CREATE ENDPOINT service_broker_endpoint
STATE = STARTED
AS TCP (LISTENER_PORT = 4022)
FOR SERVICE_BROKER (AUTHENTICATION = CERTIFICATE initiator_transport_cert);
GO



