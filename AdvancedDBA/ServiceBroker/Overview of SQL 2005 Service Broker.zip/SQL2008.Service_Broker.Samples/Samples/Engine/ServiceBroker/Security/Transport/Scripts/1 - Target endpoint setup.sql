--------------------------------------------------------------------
-- Script for transport security sample.
--
-- This file is part of the Microsoft SQL Server Code Samples.
-- Copyright (C) Microsoft Corporation. All Rights reserved.
-- This source code is intended only as a supplement to Microsoft
-- Development Tools and/or on-line documentation. See these other
-- materials for detailed information regarding Microsoft code samples.
--
-- THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF
-- ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
-- THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
-- PARTICULAR PURPOSE.
--------------------------------------------------------------------

-- This script sets up a the target broker endpoint for transport
-- certificate-based security.
-- Modify the location of the certificate in script to suit configuration.

USE master;
GO

-- A master key is required to use certificates.
BEGIN TRANSACTION;
IF NOT EXISTS (SELECT * FROM sys.symmetric_keys WHERE name = '##MS_DatabaseMasterKey##')
	CREATE MASTER KEY ENCRYPTION BY PASSWORD ='Password#123'
COMMIT;
GO

-- Create a certificate to authenticate the endpoint.
IF EXISTS (SELECT * FROM sys.certificates WHERE name = 'target_transport_cert')
	DROP CERTIFICATE target_transport_cert;
GO

CREATE CERTIFICATE target_transport_cert
	WITH SUBJECT = 'Service broker transport authentication for target';
GO

-- Backup to a file to allow the certificate to be given to the initiator.
BACKUP CERTIFICATE target_transport_cert
	TO FILE = 'c:\target_transport.cert';
GO

-- Create the broker endpoint using the certificate for authentication.
IF EXISTS (SELECT * FROM sys.endpoints WHERE name = 'service_broker_endpoint')
	DROP ENDPOINT service_broker_endpoint;
GO

CREATE ENDPOINT service_broker_endpoint
STATE = STARTED
AS TCP (LISTENER_PORT = 4022)
FOR SERVICE_BROKER (AUTHENTICATION = CERTIFICATE target_transport_cert);
GO

----------EXCHANGE CERTIFICATES BEFORE PROCEEDING---------------
-- The initiator and target certificates must be exchanged in order for them to
-- authenticate each other. In a production system, this "out of band" exchange
-- should be done with a high level of trust, since a certificate bearer will be 
-- able to begin dialogs and send messages to service broker services in the
-- authenticating server. However, assuming the sample is being used on a development
-- system, the exchange may be simple remote copies.




