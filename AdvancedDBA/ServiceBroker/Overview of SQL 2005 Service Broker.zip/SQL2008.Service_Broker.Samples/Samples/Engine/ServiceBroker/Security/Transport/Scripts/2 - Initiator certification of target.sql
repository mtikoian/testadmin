--------------------------------------------------------------------
-- Script for transport security sample.
--
-- This file is part of the Microsoft SQL Server Code Samples.
-- Copyright (C) Microsoft Corporation. All Rights reserved.
-- This source code is intended only as a supplement to Microsoft
-- Development Tools and/or on-line documentation. See these other
-- materials for detailed information regarding Microsoft code samples.
--
-- THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF
-- ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
-- THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
-- PARTICULAR PURPOSE.
--------------------------------------------------------------------

-- The initiator creates a target user certified by the target certificate
-- and grants it connection access to the service broker endpoint.
-- Modify the location of the certificate in script to suit configuration.

USE master;
GO

IF EXISTS (SELECT * FROM sys.syslogins WHERE name = 'target_user')
	DROP LOGIN target_user;
GO

CREATE LOGIN target_user WITH PASSWORD = 'Password#123';
GO

IF EXISTS (SELECT * FROM sys.sysusers WHERE name = 'target_user')
	DROP USER target_user;
GO

CREATE USER target_user;
GO

IF EXISTS (SELECT * FROM sys.certificates WHERE name = 'target_transport_cert')
	DROP CERTIFICATE target_transport_cert;
GO

CREATE CERTIFICATE target_transport_cert
	AUTHORIZATION target_user
	FROM FILE = 'c:\target_transport.cert';
GO

GRANT CONNECT ON ENDPOINT::service_broker_endpoint TO target_user;
GO