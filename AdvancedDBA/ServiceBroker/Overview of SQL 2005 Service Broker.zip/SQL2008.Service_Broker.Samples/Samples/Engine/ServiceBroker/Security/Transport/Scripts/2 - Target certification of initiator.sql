--------------------------------------------------------------------
-- Script for transport security sample.
--
-- This file is part of the Microsoft SQL Server Code Samples.
-- Copyright (C) Microsoft Corporation. All Rights reserved.
-- This source code is intended only as a supplement to Microsoft
-- Development Tools and/or on-line documentation. See these other
-- materials for detailed information regarding Microsoft code samples.
--
-- THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF
-- ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
-- THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
-- PARTICULAR PURPOSE.
--------------------------------------------------------------------

-- The target creates an initiator user certified by the initiator certificate
-- and grants it connection access to the service broker endpoint.
-- Modify the location of the certificate in script to suit configuration.

USE master;
GO

IF EXISTS (SELECT * FROM sys.syslogins WHERE name = 'initiator_user')
	DROP LOGIN initiator_user;
GO

CREATE LOGIN initiator_user WITH PASSWORD = 'Password#123';
GO

IF EXISTS (SELECT * FROM sys.sysusers WHERE name = 'initiator_user')
	DROP USER initiator_user;
GO

CREATE USER initiator_user;
GO

IF EXISTS (SELECT * FROM sys.certificates WHERE name = 'initiator_transport_cert')
	DROP CERTIFICATE initiator_transport_cert;
GO

CREATE CERTIFICATE initiator_transport_cert
	AUTHORIZATION initiator_user
	FROM FILE = 'c:\initiator_transport.cert';
GO

GRANT CONNECT ON ENDPOINT::service_broker_endpoint TO initiator_user;
GO
