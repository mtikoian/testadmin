--------------------------------------------------------------------
-- Script for dialog security sample.
--
-- This file is part of the Microsoft SQL Server Code Samples.
-- Copyright (C) Microsoft Corporation. All Rights reserved.
-- This source code is intended only as a supplement to Microsoft
-- Development Tools and/or on-line documentation. See these other
-- materials for detailed information regarding Microsoft code samples.
--
-- THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF
-- ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
-- THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
-- PARTICULAR PURPOSE.
--------------------------------------------------------------------

-- The initiator creates a target user certified by the target certificate,
-- binds it to the target service, and grants it send access to the initiator
-- service.
-- Modify location of stored certificate in script to suit configuration.

USE initiator_database;
GO

-- Create a user for the target.
IF NOT EXISTS (SELECT * FROM sys.sysusers WHERE name = 'target_user')
	CREATE USER target_user WITHOUT LOGIN;
GO

IF EXISTS (SELECT * FROM sys.certificates WHERE name = 'target_dialog_cert')
	DROP CERTIFICATE target_dialog_cert;
GO

-- Associate the target user with the target certificate.
CREATE CERTIFICATE target_dialog_cert
	AUTHORIZATION target_user
	FROM FILE = 'c:\target_dialog.cert';
GO

-- Bind the target service to the target user.
IF EXISTS (SELECT * FROM sys.remote_service_bindings WHERE name = 'remote_target_service_binding')
	DROP REMOTE SERVICE BINDING remote_target_service_binding;
GO

CREATE REMOTE SERVICE BINDING remote_target_service_binding
	TO SERVICE 'target_service'
	WITH USER = target_user;
GO

-- Allow the target to send to the initiator service.
GRANT SEND ON SERVICE::initiator_service TO target_user;
GO
