--------------------------------------------------------------------
-- Script for transport security sample.
--
-- This file is part of the Microsoft SQL Server Code Samples.
-- Copyright (C) Microsoft Corporation. All Rights reserved.
-- This source code is intended only as a supplement to Microsoft
-- Development Tools and/or on-line documentation. See these other
-- materials for detailed information regarding Microsoft code samples.
--
-- THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF
-- ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
-- THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
-- PARTICULAR PURPOSE.
--------------------------------------------------------------------

-- The initiator creates a dialog and sends a message to the target service.

USE initiator_database;
GO

-- Create a message.
DECLARE @message varchar(max);
SELECT @message = 'Hello from initiator';

-- Create a dialog to the target service.
-- Note: here the dialog does not encrypt; the endpoint does.
DECLARE @handle uniqueidentifier;
BEGIN DIALOG CONVERSATION @handle
      FROM SERVICE initiator_service
      TO SERVICE 'target_service'
      WITH ENCRYPTION = OFF;

-- Send the message.
SEND ON CONVERSATION @handle (@message);

PRINT 'Message sent to target_service on conversation:';
PRINT @handle;
GO




