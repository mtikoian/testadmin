--------------------------------------------------------------------
-- Script for dialog security sample.
--
-- This file is part of the Microsoft SQL Server Code Samples.
-- Copyright (C) Microsoft Corporation. All Rights reserved.
-- This source code is intended only as a supplement to Microsoft
-- Development Tools and/or on-line documentation. See these other
-- materials for detailed information regarding Microsoft code samples.
--
-- THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF
-- ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
-- THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
-- PARTICULAR PURPOSE.
--------------------------------------------------------------------

-- Set up an initiator service broker endpoint for dialog
-- certificate-based security.
-- Modify domain_name and target_host in script to suit configuration.

USE master;
GO

-- Create the broker endpoint using Windows authentication.
IF EXISTS (SELECT * FROM sys.endpoints WHERE name = 'service_broker_endpoint')
	DROP ENDPOINT service_broker_endpoint;
GO

CREATE ENDPOINT service_broker_endpoint
STATE = STARTED
AS TCP (LISTENER_PORT = 4022)
FOR SERVICE_BROKER (AUTHENTICATION = Windows);
GO

-- Create a login for the target machine (target_host) in the shared domain
-- (domain_name). This assumes the availability of Kerberos authentication.
-- Note: the '$' is significant.
CREATE LOGIN [domain_name\target_host$] FROM Windows;
GO

-- Grant the target connection access to the endpoint.
GRANT CONNECT ON ENDPOINT::service_broker_endpoint TO [domain_name\target_host$];
GO

