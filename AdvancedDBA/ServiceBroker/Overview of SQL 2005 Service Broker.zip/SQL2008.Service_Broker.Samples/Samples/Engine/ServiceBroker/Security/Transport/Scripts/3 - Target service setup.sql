--------------------------------------------------------------------
-- Script for transport security sample.
--
-- This file is part of the Microsoft SQL Server Code Samples.
-- Copyright (C) Microsoft Corporation. All Rights reserved.
-- This source code is intended only as a supplement to Microsoft
-- Development Tools and/or on-line documentation. See these other
-- materials for detailed information regarding Microsoft code samples.
--
-- THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF
-- ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
-- THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
-- PARTICULAR PURPOSE.
--------------------------------------------------------------------

-- The target creates a database, queue, service, and routes for the dialog
-- to the initiator service.
-- Modify the initiator_host name in script to suit configuration.

USE master;
GO

-- Create initiator database.
IF EXISTS (SELECT * FROM sys.databases WHERE name = 'target_database')
	DROP DATABASE target_database;
GO

CREATE DATABASE target_database;
GO

USE target_database;
GO

-- Create a message queue.
CREATE QUEUE target_queue;
GO

-- Create a service with a default contract.
CREATE SERVICE target_service ON QUEUE target_queue ([DEFAULT]);
GO

-- Any user can send on the service.
GRANT SEND ON SERVICE::target_service TO PUBLIC;
GO

-- Create a route to the initiator service.
CREATE ROUTE initiator_route
	WITH SERVICE_NAME = 'initiator_service',
	ADDRESS = 'tcp://initiator_host:4022';
GO

-- In msdb, create an incoming route to the target service.
USE msdb;
GO

CREATE ROUTE target_route
	WITH SERVICE_NAME = 'target_service',
	ADDRESS = 'local';
GO

USE target_database;
GO
