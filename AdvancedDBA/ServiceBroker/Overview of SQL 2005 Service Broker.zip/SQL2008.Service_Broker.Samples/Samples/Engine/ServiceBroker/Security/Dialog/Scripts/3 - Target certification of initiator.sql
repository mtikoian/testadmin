--------------------------------------------------------------------
-- Script for dialog security sample.
--
-- This file is part of the Microsoft SQL Server Code Samples.
-- Copyright (C) Microsoft Corporation. All Rights reserved.
-- This source code is intended only as a supplement to Microsoft
-- Development Tools and/or on-line documentation. See these other
-- materials for detailed information regarding Microsoft code samples.
--
-- THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF
-- ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
-- THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
-- PARTICULAR PURPOSE.
--------------------------------------------------------------------

-- The target creates an initiator user certified by the initiator certificate,
-- binds it to the initiator service, and grants it send access to the target
-- service.
-- Modify location of stored certificate in script to suit configuration.

USE target_database;
GO

-- Create a user for the initiator.
IF NOT EXISTS (SELECT * FROM sys.sysusers WHERE name = 'initiator_user')
	CREATE USER initiator_user WITHOUT LOGIN;
GO

-- Associate the initiator user with the initiator certificate.
IF EXISTS (SELECT * FROM sys.certificates WHERE name = 'initiator_dialog_cert')
	DROP CERTIFICATE initiator_dialog_cert;
GO

CREATE CERTIFICATE initiator_dialog_cert
	AUTHORIZATION initiator_user
	FROM FILE = 'c:\initiator_dialog.cert';
GO

-- Bind the initiator service to the initiator user.
IF EXISTS (SELECT * FROM sys.remote_service_bindings WHERE name = 'remote_initiator_service_binding')
	DROP REMOTE SERVICE BINDING remote_initiator_service_binding;
GO

CREATE REMOTE SERVICE BINDING remote_initiator_service_binding
	TO SERVICE 'initiator_service'
	WITH USER = initiator_user;
GO

-- Allow the initiator to send to the target service.
GRANT SEND ON SERVICE::target_service TO initiator_user;
GO
