--------------------------------------------------------------------
-- Script for transport security sample.
--
-- This file is part of the Microsoft SQL Server Code Samples.
-- Copyright (C) Microsoft Corporation. All Rights reserved.
-- This source code is intended only as a supplement to Microsoft
-- Development Tools and/or on-line documentation. See these other
-- materials for detailed information regarding Microsoft code samples.
--
-- THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF
-- ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
-- THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
-- PARTICULAR PURPOSE.
--------------------------------------------------------------------

-- The target waits for and receives a message from the initiator.

USE target_database;
GO

DECLARE @message_body varchar(max);

-- Wait for the message.
WAITFOR(
    RECEIVE TOP(1)
        @message_body=message_body
        FROM target_queue
);

PRINT 'Target received message: ' + @message_body;
GO


