--------------------------------------------------------------------
-- Summary: Cleanup script for Service Broker HelloWorld sample.
-- 
--------------------------------------------------------------------
-- This file is part of the Microsoft SQL Server Code Samples.
-- Copyright (C) Microsoft Corporation. All Rights reserved.
-- This source code is intended only as a supplement to Microsoft
-- Development Tools and/or on-line documentation. See these other
-- materials for detailed information regarding Microsoft code samples.
--
-- THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF
-- ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
-- THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
-- PARTICULAR PURPOSE.
--------------------------------------------------------------------
-- Drop InitiatorService if the service exists.

IF EXISTS (SELECT *
           FROM sys.services
           WHERE name = 'InitiatorService')
BEGIN
    DROP SERVICE InitiatorService ;
END ;
GO

-- Drop TargetService if the service exists.

IF EXISTS (SELECT *
           FROM sys.services
           WHERE name = 'TargetService')
BEGIN
    DROP SERVICE TargetService ;
END ;
GO

-- Because contracts depend on message types, the script
-- drops contracts before dropping message types.

-- Drop HelloWorldContract if the contract exists.

IF EXISTS (SELECT *
           FROM sys.service_contracts
           WHERE name = 'HelloWorldContract')
BEGIN
    DROP CONTRACT HelloWorldContract ;
END ;
GO

-- Drop HelloWorldMessage if the message type exists.

IF EXISTS (SELECT *
           FROM sys.service_message_types
           WHERE name = 'HelloWorldMessage')
BEGIN
    DROP MESSAGE TYPE HelloWorldMessage ;
END ;
GO


-- Drop InitiatorQueue if the queue exists.

IF OBJECT_ID('[dbo].[InitiatorQueue]') IS NOT NULL AND
   EXISTS(SELECT *
          FROM sys.objects
          WHERE object_id = OBJECT_ID('[dbo].[InitiatorQueue]')
            AND type = 'SQ')
BEGIN
    DROP QUEUE [dbo].[InitiatorQueue] ;
END ;
GO

-- Drop TargetQueue if the queue exists.

IF OBJECT_ID('[dbo].[TargetQueue]') IS NOT NULL AND
   EXISTS(SELECT *
          FROM sys.objects
          WHERE object_id = OBJECT_ID('[dbo].[TargetQueue]')
            AND type = 'SQ')
BEGIN
    DROP QUEUE [dbo].[TargetQueue] ;
END ;
GO
--------------------------------------------------------------------