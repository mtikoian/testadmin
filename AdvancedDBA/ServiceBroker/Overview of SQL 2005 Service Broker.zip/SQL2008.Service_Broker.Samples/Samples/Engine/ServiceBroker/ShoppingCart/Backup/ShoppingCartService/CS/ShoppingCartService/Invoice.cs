﻿//-----------------------------------------------------------------------
//  This file is part of the Microsoft Code Samples.
// 
//  Copyright (C) Microsoft Corporation.  All rights reserved.
// 
//This source code is intended only as a supplement to Microsoft
//Development Tools and/or on-line documentation.  See these other
//materials for detailed information regarding Microsoft code samples.
// 
//THIS CODE AND INFORMATION ARE PROVIDED AS IS WITHOUT WARRANTY OF ANY
//KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
//IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
//PARTICULAR PURPOSE.
//-----------------------------------------------------------------------

#region Using directives

using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Xml;

#endregion

namespace Microsoft.Samples.SqlServer
{
    public class Invoice
    {
        private int m_numberItems;
        public int NumberItems
        {
            get { return m_numberItems; }
        }

        private double m_totalAmount;
        public double TotalAmount
        {
            get { return m_totalAmount; }
        }

        private Dictionary<int, LineItem> m_shoppingCart;
        public Invoice(Dictionary<int, LineItem> shoppingCart)
        {
            m_shoppingCart = shoppingCart;
            foreach (int itemNumber in m_shoppingCart.Keys)
            {
                LineItem li = m_shoppingCart[itemNumber];
                m_numberItems += li.Quantity;
                m_totalAmount += li.Price;
            }
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1305:SpecifyIFormatProvider", MessageId = "System.Int32.ToString"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1305:SpecifyIFormatProvider", MessageId = "System.Double.ToString")]
        public Stream Serialize()
        {
            MemoryStream memstream = new MemoryStream();
            XmlWriter writer = new XmlTextWriter(memstream, Encoding.ASCII);
            writer.WriteStartElement("Invoice");
            foreach (int itemNumber in m_shoppingCart.Keys)
            {
                LineItem li = m_shoppingCart[itemNumber];
                writer.WriteStartElement("LineItem");
                writer.WriteStartElement("ItemNumber");
                writer.WriteString(li.ItemNumber.ToString());
                writer.WriteEndElement();
                writer.WriteStartElement("Name");
                writer.WriteString(li.Name);
                writer.WriteEndElement();
                writer.WriteStartElement("UnitPrice");
                writer.WriteString(li.UnitPrice.ToString());
                writer.WriteEndElement();
                writer.WriteStartElement("Quantity");
                writer.WriteString(li.Quantity.ToString());
                writer.WriteEndElement();
                writer.WriteStartElement("Price");
                writer.WriteString(li.Price.ToString());
                writer.WriteEndElement();
                writer.WriteEndElement();
            }
            writer.WriteStartElement("NumberItems");
            writer.WriteString(NumberItems.ToString());
            writer.WriteEndElement();
            writer.WriteStartElement("TotalAmount");
            writer.WriteString(TotalAmount.ToString());
            writer.WriteEndElement();
            writer.WriteEndElement();
            writer.Flush();
            memstream.Seek(0, SeekOrigin.Begin);
            return memstream;
        }
    }
}
