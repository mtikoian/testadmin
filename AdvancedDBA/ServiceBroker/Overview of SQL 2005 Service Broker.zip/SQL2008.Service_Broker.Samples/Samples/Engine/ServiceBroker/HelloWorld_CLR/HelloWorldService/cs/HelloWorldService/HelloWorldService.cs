﻿//-----------------------------------------------------------------------
//  This file is part of the Microsoft Code Samples.
// 
//  Copyright (C) Microsoft Corporation.  All rights reserved.
// 
//  This source code is intended only as a supplement to Microsoft
//  Development Tools and/or on-line documentation.  See these other
//  materials for detailed information regarding Microsoft code samples.
// 
//  THIS CODE AND INFORMATION ARE PROVIDED AS IS WITHOUT WARRANTY OF ANY
//  KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
//  IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
//  PARTICULAR PURPOSE.
//-----------------------------------------------------------------------

#region Using directives

using System;
using System.IO;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using Microsoft.Samples.SqlServer;
using System.Security;
using System.Collections.Generic;

#endregion

[assembly: AllowPartiallyTrustedCallers]
namespace Microsoft.Samples.SqlServer
{

public class HelloWorldService : Service
{
    public HelloWorldService(SqlConnection conn)
        :
        base("HelloWorldService", conn)
    {
        WaitforTimeout = TimeSpan.FromSeconds(1);
    }

    [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1062:ValidateArgumentsOfPublicMethods"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1822:MarkMembersAsStatic"), BrokerMethod("Greeting", "Request")]
    public void SayHello(
		Message msgReceived,
		SqlConnection connection,
		SqlTransaction transaction)
    {
        MemoryStream body = new MemoryStream(Encoding.ASCII.GetBytes("Hello World!"));
        Message msgSend = new Message("Response", body);
        Conversation conversation = msgReceived.Conversation;
        conversation.Send(msgSend, connection, transaction);
    }

    [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1062:ValidateArgumentsOfPublicMethods"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1822:MarkMembersAsStatic"), BrokerMethod(Message.EndDialogType)]
    public void EndConversation(
		Message msgReceived,
		SqlConnection connection,
		SqlTransaction transaction)
    {
        Conversation conversation = msgReceived.Conversation;
        conversation.End(connection, transaction);
    }

    [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1804:RemoveUnusedLocals", MessageId = "sqlex"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes")]
    public static void ServiceProc()
    {
        Service service = null;
        SqlConnection conn = null;

		try
		{
			// Get the SqlConnection from the in-proc managed provider
			conn = new SqlConnection("context connection=true");

			// Open the connection
			conn.Open();

			// Create an instance of HelloWorldService
			service = new HelloWorldService(conn);

			// Set FetchSize to 1 for one message at a time processing
			// i.e. use RECEIVE TOP(1)
			service.FetchSize = 1;

			// Use the default message loop for fetching messages
			service.Run(true, conn, null);
		}
		catch (ServiceException svcex)
		{
			Conversation conversation = svcex.CurrentConversation;
			if (conversation != null)
			{
				conversation.EndWithError(1, 
					"Ending dialog with error: " + svcex.InnerException.Message, 
					svcex.Connection, svcex.Transaction);
			}

			SqlTransaction transaction = svcex.Transaction;
			if (transaction != null)
			{
				transaction.Commit();
			}
		}
        catch (SqlException)
        {
        }
        finally
        {
            conn.Close();
        }
    }
}
}