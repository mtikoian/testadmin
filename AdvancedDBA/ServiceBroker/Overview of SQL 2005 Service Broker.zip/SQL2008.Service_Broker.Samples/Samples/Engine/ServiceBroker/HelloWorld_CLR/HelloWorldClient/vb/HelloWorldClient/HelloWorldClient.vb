 '-----------------------------------------------------------------------
'  This file is part of the Microsoft Code Samples.
' 
'  Copyright (C) Microsoft Corporation.  All rights reserved.
' 
'  This source code is intended only as a supplement to Microsoft
'  Development Tools and/or on-line documentation.  See these other
'  materials for detailed information regarding Microsoft code samples.
' 
'  THIS CODE AND INFORMATION ARE PROVIDED AS IS WITHOUT WARRANTY OF ANY
'  KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
'  IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
'  PARTICULAR PURPOSE.
'-----------------------------------------------------------------------
#Region "Using directives"

Imports System
Imports System.IO
Imports System.Text
Imports System.Data
Imports System.Data.SqlTypes
Imports System.Data.SqlClient
Imports Microsoft.Samples.SqlServer


'System.Data.SqlClient.SqlConnection
'System.Data.SqlServer.SqlConnection
#End Region


Class HelloWorldClient
    
    Shared Sub Main() 
        Dim conn As SqlConnection = Nothing
        Dim tran As SqlTransaction = Nothing
        Dim reader As TextReader = Nothing
        
        Try
            Console.WriteLine("Connecting to SQL Server instance")
            
            ' Create a connection
            conn = New SqlConnection("Initial Catalog=ssb_HelloWorld; Data Source=localhost;Integrated Security=SSPI;")
            ' Open the connection
            conn.Open()
            Console.WriteLine("Connected to SQL Server instance")
            
            ' Begin a transaction
            tran = conn.BeginTransaction()
            Console.WriteLine(vbLf + "Transaction 1 begun")
            
            ' Create a service object
            Dim client As New Service("HelloWorldClient", conn, tran)
            
            ' Set the FetchSize to 1 since we will receive one message at a time
            ' i.e. use RECEIVE TOP(1)
            client.FetchSize = 1
            
            ' Begin a dialog with the HelloWorld service
            Dim dialog As Conversation = client.BeginDialog("HelloWorldService", Nothing, "Greeting", TimeSpan.FromMinutes(1), False, conn, tran)
            Console.WriteLine("Dialog begun from service (HelloWorldClient) to service (HelloWorldService)")
            
            ' Create an empty request message
            Dim request As New Message("Request", Nothing)
            
            ' Send the message to the service
            dialog.Send(request, conn, tran)
            Console.WriteLine("Message sent of type '" + request.Type + "'")
            
            tran.Commit() ' Message isn't sent until transaction has been committed
            Console.WriteLine("Transaction 1 committed")
            
            ' Begin transaction
            tran = conn.BeginTransaction()
            Console.WriteLine(vbLf + "Transaction 2 begun")
            
            ' Waitfor messages on this conversation
            Console.WriteLine("Waiting for Response....")
            
            client.WaitforTimeout = TimeSpan.FromSeconds(5)
            If client.GetConversation(dialog, conn, tran) Is Nothing Then
                Console.WriteLine("No message received - Ending dialog with Error")
                dialog.EndWithError(1, "no response within 5 seconds.", conn, tran)
                tran.Commit()
                Console.WriteLine("Transaction 2 committed")
                conn.Close()
                Console.WriteLine(vbLf + "Connection closed - exiting")
                Return
            End If
            
            ' Fetch the message from the conversation
            Dim response As Message = dialog.Receive()
            
            ' Output the message to the Console
            'Console.WriteLine("Message received of type '" + response.Type + "'");
            If Not (response.Body Is Nothing) Then
                Console.Write("Message contains: ")
                reader = New StreamReader(response.Body)
                Console.WriteLine(reader.ReadToEnd())
            End If
            
            ' End the conversation
            dialog.End(conn, tran)
            Console.WriteLine("Ended Dialog")
            
            'tran.Commit();  // Remember to commit again
            Console.WriteLine("Transaction 2 committed")
            
            ' Close the database connection
            conn.Close()
            Console.WriteLine(vbLf + "Connection closed - exiting")
        Catch e As ServiceException
            Console.WriteLine("An exception occurred - {0}" + vbLf, e.ToString())
            If Not (tran Is Nothing) Then
                tran.Rollback()
                Console.WriteLine(vbLf + "Transaction rolled back")
            End If
            If Not (conn Is Nothing) Then
                conn.Close()
                Console.WriteLine(vbLf + "Connection closed - exiting")
            End If
        Finally
            If Not (reader Is Nothing) Then
                reader.Close()
            End If 
            Console.WriteLine()
            Console.WriteLine("Press Enter to Exit")
            Console.ReadLine()
        End Try
    
    End Sub 'Main
End Class 'HelloWorldClient