﻿//-----------------------------------------------------------------------
//  This file is part of the Microsoft Code Samples.
// 
//  Copyright (C) Microsoft Corporation.  All rights reserved.
// 
//  This source code is intended only as a supplement to Microsoft
//  Development Tools and/or on-line documentation.  See these other
//  materials for detailed information regarding Microsoft code samples.
// 
//  THIS CODE AND INFORMATION ARE PROVIDED AS IS WITHOUT WARRANTY OF ANY
//  KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
//  IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
//  PARTICULAR PURPOSE.
//-----------------------------------------------------------------------

#region Using directives

using System;
using System.IO;
using System.Text;
using System.Data;
using System.Data.SqlTypes;
using System.Data.SqlClient;
using Microsoft.Samples.SqlServer;

//System.Data.SqlClient.SqlConnection
//System.Data.SqlServer.SqlConnection

#endregion

namespace Microsoft.Samples.SqlServer
{
    class HelloWorldClient
    {
        static void Main()
        {
            SqlConnection conn = null;
            SqlTransaction tran = null;
            TextReader reader = null;

            try
            {
                Console.WriteLine("Connecting to SQL Server instance");

                // Create a connection
                conn = new SqlConnection(
                    "Initial Catalog=ssb_HelloWorld; Data Source=localhost;Integrated Security=SSPI;");
                // Open the connection
                conn.Open();
                Console.WriteLine("Connected to SQL Server instance");

                // Begin a transaction
                tran = conn.BeginTransaction();
                Console.WriteLine("\nTransaction 1 begun");

                // Create a service object
                Service client = new Service("HelloWorldClient", conn, tran);

                // Set the FetchSize to 1 since we will receive one message at a time
                // i.e. use RECEIVE TOP(1)
                client.FetchSize = 1;

                // Begin a dialog with the HelloWorld service
                Conversation dialog = client.BeginDialog(
                    "HelloWorldService",
					null,
 					"Greeting",
                    TimeSpan.FromMinutes(1),
                    false,
					conn,
					tran);
                Console.WriteLine("Dialog begun from service (HelloWorldClient) to service (HelloWorldService)");

                // Create an empty request message
                Message request = new Message("Request", null);

                // Send the message to the service
                dialog.Send(request, conn, tran);
                Console.WriteLine("Message sent of type '" + request.Type + "'");

                tran.Commit(); // Message isn't sent until transaction has been committed
                Console.WriteLine("Transaction 1 committed");

                // Begin transaction
				tran = conn.BeginTransaction();
				Console.WriteLine("\nTransaction 2 begun");

				// Waitfor messages on this conversation
				Console.WriteLine("Waiting for Response....");

				client.WaitforTimeout = TimeSpan.FromSeconds(5);
				if (client.GetConversation(dialog, conn, tran) == null)
				{
					Console.WriteLine("No message received - Ending dialog with Error");
					dialog.EndWithError(1, "no response within 5 seconds.", conn, tran);
					tran.Commit();
					Console.WriteLine("Transaction 2 committed");
					conn.Close();
					Console.WriteLine("\nConnection closed - exiting");
					return;
				}

				// Fetch the message from the conversation
				Message response = dialog.Receive();

				// Output the message to the Console
				//Console.WriteLine("Message received of type '" + response.Type + "'");
				if (response.Body != null)
				{
					Console.Write("Message contains: ");
					reader = new StreamReader(response.Body);
					Console.WriteLine(reader.ReadToEnd());
				}

				// End the conversation
				dialog.End(conn, tran);
				Console.WriteLine("Ended Dialog");

				//tran.Commit();  // Remember to commit again
				Console.WriteLine("Transaction 2 committed");

                // Close the database connection
                conn.Close();
                Console.WriteLine("\nConnection closed - exiting");
            }
            catch (ServiceException e)
            {
                Console.WriteLine("An exception occurred - {0}\n", e.ToString());
                if (tran != null)
                {
                    tran.Rollback();
                    Console.WriteLine("\nTransaction rolled back");
                }
                if (conn != null)
                {
                    conn.Close();
                    Console.WriteLine("\nConnection closed - exiting");
                }
            }
            finally
            {
                if (reader != null)
                    reader.Close();

                Console.WriteLine();
                Console.WriteLine("Press Enter to Exit");
                Console.ReadLine();
            }
        }
    }
}