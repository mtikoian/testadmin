'-----------------------------------------------------------------------
'  This file is part of the Microsoft Code Samples.
' 
'  Copyright (C) Microsoft Corporation.  All rights reserved.
' 
'  This source code is intended only as a supplement to Microsoft
'  Development Tools and/or on-line documentation.  See these other
'  materials for detailed information regarding Microsoft code samples.
' 
'  THIS CODE AND INFORMATION ARE PROVIDED AS IS WITHOUT WARRANTY OF ANY
'  KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
'  IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
'  PARTICULAR PURPOSE.
'-----------------------------------------------------------------------
#Region "Using directives"

Imports System
Imports System.IO
Imports System.Text
Imports System.Data
Imports System.Data.SqlClient
Imports System.Data.SqlTypes
Imports Microsoft.Samples.SqlServer
Imports System.Security
Imports System.Collections.Generic


#End Region

Public Class HelloWorldService
    Inherits Service
    
    Public Sub New(ByVal conn As SqlConnection) 
        MyBase.New("HelloWorldService", conn)
        WaitforTimeout = TimeSpan.FromSeconds(1)
    End Sub
    
    
    <System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1062:ValidateArgumentsOfPublicMethods")> <System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1822:MarkMembersAsStatic")> <BrokerMethod("Greeting", "Request")> _
    Public Sub SayHello(ByVal msgReceived As Message, ByVal connection As SqlConnection, ByVal transaction As SqlTransaction)
        Dim body As New MemoryStream(Encoding.ASCII.GetBytes("Hello World!"))
        Dim msgSend As New Message("Response", body)
        Dim conversation As Conversation = msgReceived.Conversation
        conversation.Send(msgSend, connection, transaction)
    End Sub
    
    
    <System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1062:ValidateArgumentsOfPublicMethods")> <System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1822:MarkMembersAsStatic")> <BrokerMethod(Message.EndDialogType)> _
    Public Sub EndConversation(ByVal msgReceived As Message, ByVal connection As SqlConnection, ByVal transaction As SqlTransaction)
        Dim conversation As Conversation = msgReceived.Conversation
        conversation.End(connection, transaction)
    End Sub
    
    
    <System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes")>  _
    Public Shared Sub ServiceProc() 
        Dim service As Service = Nothing
        Dim conn As SqlConnection = Nothing
        
        Try
            ' Get the SqlConnection from the in-proc managed provider
            conn = New SqlConnection("context connection=true")
            
            ' Open the connection
            conn.Open()
            
            ' Create an instance of HelloWorldService
            service = New HelloWorldService(conn)
            
            ' Set FetchSize to 1 for one message at a time processing
            ' i.e. use RECEIVE TOP(1)
            service.FetchSize = 1
            
            ' Use the default message loop for fetching messages
            service.Run(True, conn, Nothing)
        Catch svcex As ServiceException
            Dim conversation As Conversation = svcex.CurrentConversation
            If Not (conversation Is Nothing) Then
                conversation.EndWithError(1, "Ending dialog with error: " + svcex.InnerException.Message, svcex.Connection, svcex.Transaction)
            End If
            
            Dim transaction As SqlTransaction = svcex.Transaction
            If Not (transaction Is Nothing) Then
                transaction.Commit()
            End If
        Catch sqlex As SqlException
        Finally
            conn.Close()
        End Try
    
    End Sub
End Class
