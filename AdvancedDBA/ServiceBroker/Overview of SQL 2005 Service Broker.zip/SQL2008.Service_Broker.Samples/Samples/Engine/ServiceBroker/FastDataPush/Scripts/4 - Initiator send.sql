--------------------------------------------------------------------
-- Script for fast data push sample.
--
-- This file is part of the Microsoft SQL Server Code Samples.
-- Copyright (C) Microsoft Corporation. All Rights reserved.
-- This source code is intended only as a supplement to Microsoft
-- Development Tools and/or on-line documentation. See these other
-- materials for detailed information regarding Microsoft code samples.
--
-- THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF
-- ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
-- THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
-- PARTICULAR PURPOSE.
--------------------------------------------------------------------

---------------------------------------------------------------------
-- Initiator data push.
--
-- This script can also be run on multiple connections to achieve transactional
-- concurrency. Since each connection will send message_quantity messages
-- with number_initiator_transactions transactions and number_dialogs
-- dialogs, these parameter quantities should be divided by the number
-- of connections to get the same total quantities.
---------------------------------------------------------------------

USE data_push_database;
GO

-- Send the messages. Output sending time.
EXEC usp_data_push;
GO

---------------------------------------------------------------------
-- Wait for transmission queue to be empty, signifying the
-- reception and acknowledgement of all messages by the target.
-- Use this efficient checking method every 5 seconds.
---------------------------------------------------------------------
DECLARE @count BIGINT;
WHILE (1=1)
BEGIN
     SET @count =
         (SELECT p.rows
         FROM sys.objects AS o
         JOIN sys.partitions AS p ON p.object_id = o.object_id
         WHERE o.name = 'sysxmitqueue');
     IF (@count = 0) BREAK;
     WAITFOR DELAY '00:00:05:000';
END;
SELECT GETDATE() AS 'End transmission';
GO

-- View processing errors.
SELECT * FROM initiator_processing_errors;
GO

-- View unsent messages.
SELECT * FROM unsent_messages;
GO




