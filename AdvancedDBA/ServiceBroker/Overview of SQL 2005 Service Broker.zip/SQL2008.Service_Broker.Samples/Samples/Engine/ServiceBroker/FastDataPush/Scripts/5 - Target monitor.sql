--------------------------------------------------------------------
-- Script for fast data push sample.
--
-- This file is part of the Microsoft SQL Server Code Samples.
-- Copyright (C) Microsoft Corporation. All Rights reserved.
-- This source code is intended only as a supplement to Microsoft
-- Development Tools and/or on-line documentation. See these other
-- materials for detailed information regarding Microsoft code samples.
--
-- THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF
-- ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
-- THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
-- PARTICULAR PURPOSE.
--------------------------------------------------------------------

----------------------------------------------------
-- Monitor target.
--
-- A count of processed messages is kept in the
-- target_message_counter table.
-- The usp_get_queue_size procedure can also be used to
-- monitor the size of the target queue.
----------------------------------------------------

USE data_push_database;
GO

-- Wait for message_quantity messages to be processed.
DECLARE @message_quantity BIGINT;
SET @message_quantity = (SELECT message_quantity FROM data_push_parameters);
DECLARE @count BIGINT;
WHILE (1=1)
BEGIN
     SET @count = (SELECT TOP(1) counter FROM target_message_counter);
     IF (@count >= @message_quantity) BREAK;
     WAITFOR DELAY '00:00:05:000';
END;
SELECT GETDATE() AS 'Messages processed';
GO

-- View message processing errors.
SELECT * FROM target_processing_errors;
GO

-- Clear processed message counter for next run.
UPDATE target_message_counter SET counter = 0;
GO
