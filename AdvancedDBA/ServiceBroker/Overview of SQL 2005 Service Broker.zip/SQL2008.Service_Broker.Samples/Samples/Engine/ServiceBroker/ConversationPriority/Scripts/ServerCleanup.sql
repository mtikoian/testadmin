--------------------------------------------------------------------
-- Summary: Cleanup script for Server Service and database.
-- 
/*=====================================================================
  This file is part of a Microsoft SQL Server Shared Source Application.
  Copyright (C) Microsoft Corporation.  All rights reserved.
 
THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
PARTICULAR PURPOSE.
======================================================= */

use master ;
GO

SET NOCOUNT ON;
GO

IF EXISTS
  (SELECT * FROM sys.databases
   WHERE name = 'Ssb_Sample_Priority_Server')
BEGIN
  -- Drop the broker priorities.
  -- In this sample, this is not really necessary since the database will be dropped.
  USE Ssb_Sample_Priority_Server;
  IF EXISTS 
	(SELECT * FROM sys.conversation_priorities
	 WHERE name = 'Client2Priority')
	BEGIN
	  DROP BROKER PRIORITY Client2Priority
	END;
  IF EXISTS 
	(SELECT * FROM sys.conversation_priorities
	 WHERE name = 'Client1LowPriority')
	BEGIN
	  DROP BROKER PRIORITY Client1LowPriority
	END;
  IF EXISTS 
	(SELECT * FROM sys.conversation_priorities
	 WHERE name = 'Client1MediumPriority')
	BEGIN
	  DROP BROKER PRIORITY Client1MediumPriority
	END;
  USE Master;
  -- Drop the database.
  DROP DATABASE Ssb_Sample_Priority_Server;
END ;
GO 


--------------------------------------------------------------------