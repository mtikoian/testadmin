USE Northwind
GO

IF OBJECT_ID ('dbo.tr_Categories_IUD','TR') IS NOT NULL
   DROP TRIGGER dbo.tr_Categories_IUD 
GO

CREATE TRIGGER dbo.tr_Categories_IUD
   ON  [dbo].[Categories]
   FOR INSERT, UPDATE, DELETE
AS 

  DECLARE @InitDlgHandle UNIQUEIDENTIFIER;
  DECLARE @ChangeMsg XML;
  DECLARE @ChangeCnt int;
  DECLARE @Action char(1);
  DECLARE @TableName varchar(100) = 'dbo_Categories';
  DECLARE @service_name nvarchar(512) = N'//INST02Site/INST02Service';
	
  SELECT @InitDlgHandle=[ch]
  FROM [dbo].[BrokerConversation]
  WHERE [service_name] = @service_name;
  
  BEGIN TRY
    IF USER_NAME() <> 'INST02User'
    BEGIN

      -- If there are rows in both inserted and deleted, the change is an update
      SELECT @ChangeCnt = count(*)
        FROM [dbo].[Categories] t
        INNER JOIN deleted d on
            t.[CategoryID] = d.[CategoryID]
        INNER JOIN inserted i on
            t.[CategoryID] = i.[CategoryID]
      if (@ChangeCnt > 0)
        BEGIN;
        SET @Action = 'U';
        END;
      ELSE
        BEGIN
        -- Since rows aren't in both inserted and deleted, then the change is an insert or a delete
        -- If there are rows in deleted, the change is a delete, and we only need the primary key value
        select @ChangeCnt = count(*) from deleted
        if (@ChangeCnt > 0)
          BEGIN
          SET @Action = 'D';
          END;

        -- If there are rows in inserted, the change is an insert and we need all the column values
        select @ChangeCnt = count(*) from inserted
        if (@ChangeCnt > 0)
          BEGIN
          SET @Action = 'I';
          END;
        END;

      if (@Action = 'D')
        BEGIN;
        -- Build the XML message, flagging it as an update
        set @ChangeMsg = (
        SELECT @Action as [Action]
              ,@TableName as [TableName]
              ,t.[CategoryID]
              ,t.[CategoryName]
              ,t.[CategoryDescription]
          FROM [dbo].[Categories] t
          INNER JOIN deleted d on
            t.[CategoryID] = d.[CategoryID]
          FOR XML RAW, ELEMENTS, ROOT ('NorthWind')
          );
        END;
      ELSE
        BEGIN;
        -- Build the XML message, flagging it as an update
        set @ChangeMsg = (
        SELECT @Action as [Action]
              ,@TableName as [TableName]
              ,t.[CategoryID]
              ,t.[CategoryName]
              ,t.[CategoryDescription]
          FROM [dbo].[Categories] t
          INNER JOIN inserted i on
            t.[CategoryID] = i.[CategoryID]
          FOR XML RAW, ELEMENTS, ROOT ('NorthWind')
          );
        END;

    IF @ChangeMsg IS NOT NULL
      BEGIN
      BEGIN TRANSACTION;
      ;SEND ON CONVERSATION @InitDlgHandle
           MESSAGE TYPE [//NorthWindSync/SBETL]
           (@ChangeMsg);
      --END CONVERSATION @InitDlgHandle;
      COMMIT TRANSACTION;
      END
    END
  END TRY
  BEGIN CATCH
  	IF XACT_STATE() <> 0
  		BEGIN
		-- Rollback any pending transaction
		ROLLBACK TRANSACTION;
		END

	-- Insert the error information into the ErrorLog Categories for later reference
  	INSERT INTO dbo.ErrorLog (ErrorTime, UserName, ErrorNumber, ErrorSeverity,
  		ErrorState, ErrorProcedure, ErrorLine, ErrorMessage, MessageBody)
  	VALUES (getdate(), USER_NAME(), ERROR_NUMBER(), ERROR_SEVERITY(),
  		ERROR_STATE(), ERROR_PROCEDURE(), ERROR_LINE(), ERROR_MESSAGE(), @ChangeMsg)

  END CATCH

GO

EXEC sp_settriggerorder @triggername=N'[dbo].[tr_Categories_IUD]', @order=N'Last', @stmttype=N'DELETE'
GO
EXEC sp_settriggerorder @triggername=N'[dbo].[tr_Categories_IUD]', @order=N'Last', @stmttype=N'INSERT'
GO
EXEC sp_settriggerorder @triggername=N'[dbo].[tr_Categories_IUD]', @order=N'Last', @stmttype=N'UPDATE'
GO

IF OBJECT_ID ('dbo.tr_Customers_IUD','TR') IS NOT NULL
   DROP TRIGGER dbo.tr_Customers_IUD 
GO

CREATE TRIGGER dbo.tr_Customers_IUD
   ON  [dbo].[Customers]
   FOR INSERT, UPDATE, DELETE
AS 

  DECLARE @InitDlgHandle UNIQUEIDENTIFIER;
  DECLARE @ChangeMsg XML;
  DECLARE @ChangeCnt int;
  DECLARE @Action char(1);
  DECLARE @TableName varchar(100) = 'dbo_Customers';
  DECLARE @service_name nvarchar(512) = N'//INST02Site/INST02Service';
	
  SELECT @InitDlgHandle=[ch]
  FROM [dbo].[BrokerConversation]
  WHERE [service_name] = @service_name;
  
  BEGIN TRY
    IF USER_NAME() <> 'INST02User'
    BEGIN

      -- If there are rows in both inserted and deleted, the change is an update
      SELECT @ChangeCnt = count(*)
        FROM [dbo].[Customers] t
        INNER JOIN deleted d on
            t.[CustomerID] = d.[CustomerID]
        INNER JOIN inserted i on
            t.[CustomerID] = i.[CustomerID]
      if (@ChangeCnt > 0)
        BEGIN;
        SET @Action = 'U';
        END;
      ELSE
        BEGIN
        -- Since rows aren't in both inserted and deleted, then the change is an insert or a delete
        -- If there are rows in deleted, the change is a delete, and we only need the primary key value
        select @ChangeCnt = count(*) from deleted
        if (@ChangeCnt > 0)
          BEGIN
          SET @Action = 'D';
          END;

        -- If there are rows in inserted, the change is an insert and we need all the column values
        select @ChangeCnt = count(*) from inserted
        if (@ChangeCnt > 0)
          BEGIN
          SET @Action = 'I';
          END;
        END;

      if (@Action = 'D')
        BEGIN;
        -- Build the XML message, flagging it as an update
        set @ChangeMsg = (
        SELECT @Action as [Action]
              ,@TableName as [TableName]
              ,t.[CustomerID]
              ,t.[CompanyName]
              ,t.[ContactName]
              ,t.[ContactTitle]
              ,t.[Address]
              ,t.[City]
              ,t.[Region]
              ,t.[PostalCode]
              ,t.[Country]
              ,t.[Phone]
              ,t.[Fax]
          FROM [dbo].[Customers] t
          INNER JOIN deleted d on
            t.[CustomerID] = d.[CustomerID]
          FOR XML RAW, ELEMENTS, ROOT ('NorthWind')
          );
        END;
      ELSE
        BEGIN;
        -- Build the XML message, flagging it as an update
        set @ChangeMsg = (
        SELECT @Action as [Action]
              ,@TableName as [TableName]
              ,t.[CustomerID]
              ,t.[CompanyName]
              ,t.[ContactName]
              ,t.[ContactTitle]
              ,t.[Address]
              ,t.[City]
              ,t.[Region]
              ,t.[PostalCode]
              ,t.[Country]
              ,t.[Phone]
              ,t.[Fax]
          FROM [dbo].[Customers] t
          INNER JOIN inserted i on
            t.[CustomerID] = i.[CustomerID]
          FOR XML RAW, ELEMENTS, ROOT ('NorthWind')
          );
        END;

    IF @ChangeMsg IS NOT NULL
      BEGIN
      BEGIN TRANSACTION;
      ;SEND ON CONVERSATION @InitDlgHandle
           MESSAGE TYPE [//NorthWindSync/SBETL]
           (@ChangeMsg);
      --END CONVERSATION @InitDlgHandle;
      COMMIT TRANSACTION;
      END
    END
  END TRY
  BEGIN CATCH
  	IF XACT_STATE() <> 0
  		BEGIN
		-- Rollback any pending transaction
		ROLLBACK TRANSACTION;
		END

	-- Insert the error information into the ErrorLog Categories for later reference
  	INSERT INTO dbo.ErrorLog (ErrorTime, UserName, ErrorNumber, ErrorSeverity,
  		ErrorState, ErrorProcedure, ErrorLine, ErrorMessage, MessageBody)
  	VALUES (getdate(), USER_NAME(), ERROR_NUMBER(), ERROR_SEVERITY(),
  		ERROR_STATE(), ERROR_PROCEDURE(), ERROR_LINE(), ERROR_MESSAGE(), @ChangeMsg)

  END CATCH

GO

EXEC sp_settriggerorder @triggername=N'[dbo].[tr_Customers_IUD]', @order=N'Last', @stmttype=N'DELETE'
GO
EXEC sp_settriggerorder @triggername=N'[dbo].[tr_Customers_IUD]', @order=N'Last', @stmttype=N'INSERT'
GO
EXEC sp_settriggerorder @triggername=N'[dbo].[tr_Customers_IUD]', @order=N'Last', @stmttype=N'UPDATE'
GO

IF OBJECT_ID ('dbo.tr_Employees_IUD','TR') IS NOT NULL
   DROP TRIGGER dbo.tr_Employees_IUD 
GO

CREATE TRIGGER dbo.tr_Employees_IUD
   ON  [dbo].[Employees]
   FOR INSERT, UPDATE, DELETE
AS 

  DECLARE @InitDlgHandle UNIQUEIDENTIFIER;
  DECLARE @ChangeMsg XML;
  DECLARE @ChangeCnt int;
  DECLARE @Action char(1);
  DECLARE @TableName varchar(100) = 'dbo_Employees';
  DECLARE @service_name nvarchar(512) = N'//INST02Site/INST02Service';
	
  SELECT @InitDlgHandle=[ch]
  FROM [dbo].[BrokerConversation]
  WHERE [service_name] = @service_name;
  
  BEGIN TRY
    IF USER_NAME() <> 'INST02User'
    BEGIN

      -- If there are rows in both inserted and deleted, the change is an update
      SELECT @ChangeCnt = count(*)
        FROM [dbo].[Employees] t
        INNER JOIN deleted d on
            t.[EmployeeID] = d.[EmployeeID]
        INNER JOIN inserted i on
            t.[EmployeeID] = i.[EmployeeID]
      if (@ChangeCnt > 0)
        BEGIN;
        SET @Action = 'U';
        END;
      ELSE
        BEGIN
        -- Since rows aren't in both inserted and deleted, then the change is an insert or a delete
        -- If there are rows in deleted, the change is a delete, and we only need the primary key value
        select @ChangeCnt = count(*) from deleted
        if (@ChangeCnt > 0)
          BEGIN
          SET @Action = 'D';
          END;

        -- If there are rows in inserted, the change is an insert and we need all the column values
        select @ChangeCnt = count(*) from inserted
        if (@ChangeCnt > 0)
          BEGIN
          SET @Action = 'I';
          END;
        END;

      if (@Action = 'D')
        BEGIN;
        -- Build the XML message, flagging it as an update
        set @ChangeMsg = (
        SELECT @Action as [Action]
              ,@TableName as [TableName]
              ,t.[EmployeeID]
              ,t.[LastName]
              ,t.[FirstName]
              ,t.[Title]
              ,t.[TitleOfCourtesy]
              ,t.[BirthDate]
              ,t.[HireDate]
              ,t.[Address]
              ,t.[City]
              ,t.[Region]
              ,t.[PostalCode]
              ,t.[Country]
              ,t.[HomePhone]
              ,t.[Extension]
          FROM [dbo].[Employees] t
          INNER JOIN deleted d on
            t.[EmployeeID] = d.[EmployeeID]
          FOR XML RAW, ELEMENTS, ROOT ('NorthWind')
          );
        END;
      ELSE
        BEGIN;
        -- Build the XML message, flagging it as an update
        set @ChangeMsg = (
        SELECT @Action as [Action]
              ,@TableName as [TableName]
              ,t.[EmployeeID]
              ,t.[LastName]
              ,t.[FirstName]
              ,t.[Title]
              ,t.[TitleOfCourtesy]
              ,t.[BirthDate]
              ,t.[HireDate]
              ,t.[Address]
              ,t.[City]
              ,t.[Region]
              ,t.[PostalCode]
              ,t.[Country]
              ,t.[HomePhone]
              ,t.[Extension]
          FROM [dbo].[Employees] t
          INNER JOIN inserted i on
            t.[EmployeeID] = i.[EmployeeID]
          FOR XML RAW, ELEMENTS, ROOT ('NorthWind')
          );
        END;

    IF @ChangeMsg IS NOT NULL
      BEGIN
      BEGIN TRANSACTION;
      ;SEND ON CONVERSATION @InitDlgHandle
           MESSAGE TYPE [//NorthWindSync/SBETL]
           (@ChangeMsg);
      --END CONVERSATION @InitDlgHandle;
      COMMIT TRANSACTION;
      END
    END
  END TRY
  BEGIN CATCH
  	IF XACT_STATE() <> 0
  		BEGIN
		-- Rollback any pending transaction
		ROLLBACK TRANSACTION;
		END

	-- Insert the error information into the ErrorLog Categories for later reference
  	INSERT INTO dbo.ErrorLog (ErrorTime, UserName, ErrorNumber, ErrorSeverity,
  		ErrorState, ErrorProcedure, ErrorLine, ErrorMessage, MessageBody)
  	VALUES (getdate(), USER_NAME(), ERROR_NUMBER(), ERROR_SEVERITY(),
  		ERROR_STATE(), ERROR_PROCEDURE(), ERROR_LINE(), ERROR_MESSAGE(), @ChangeMsg)

  END CATCH

GO

EXEC sp_settriggerorder @triggername=N'[dbo].[tr_Employees_IUD]', @order=N'Last', @stmttype=N'DELETE'
GO
EXEC sp_settriggerorder @triggername=N'[dbo].[tr_Employees_IUD]', @order=N'Last', @stmttype=N'INSERT'
GO
EXEC sp_settriggerorder @triggername=N'[dbo].[tr_Employees_IUD]', @order=N'Last', @stmttype=N'UPDATE'
GO

IF OBJECT_ID ('dbo.tr_OrderDetails_IUD','TR') IS NOT NULL
   DROP TRIGGER dbo.tr_OrderDetails_IUD 
GO

CREATE TRIGGER dbo.tr_OrderDetails_IUD
   ON  [dbo].[OrderDetails]
   FOR INSERT, UPDATE, DELETE
AS 

  DECLARE @InitDlgHandle UNIQUEIDENTIFIER;
  DECLARE @ChangeMsg XML;
  DECLARE @ChangeCnt int;
  DECLARE @Action char(1);
  DECLARE @TableName varchar(100) = 'dbo_OrderDetails';
  DECLARE @service_name nvarchar(512) = N'//INST02Site/INST02Service';
	
  SELECT @InitDlgHandle=[ch]
  FROM [dbo].[BrokerConversation]
  WHERE [service_name] = @service_name;
  
  BEGIN TRY
    IF USER_NAME() <> 'INST02User'
    BEGIN

      -- If there are rows in both inserted and deleted, the change is an update
      SELECT @ChangeCnt = count(*)
        FROM [dbo].[OrderDetails] t
        INNER JOIN deleted d on
            t.[OrderDetailID] = d.[OrderDetailID]
        INNER JOIN inserted i on
            t.[OrderDetailID] = i.[OrderDetailID]
      if (@ChangeCnt > 0)
        BEGIN;
        SET @Action = 'U';
        END;
      ELSE
        BEGIN
        -- Since rows aren't in both inserted and deleted, then the change is an insert or a delete
        -- If there are rows in deleted, the change is a delete, and we only need the primary key value
        select @ChangeCnt = count(*) from deleted
        if (@ChangeCnt > 0)
          BEGIN
          SET @Action = 'D';
          END;

        -- If there are rows in inserted, the change is an insert and we need all the column values
        select @ChangeCnt = count(*) from inserted
        if (@ChangeCnt > 0)
          BEGIN
          SET @Action = 'I';
          END;
        END;

      if (@Action = 'D')
        BEGIN;
        -- Build the XML message, flagging it as an update
        set @ChangeMsg = (
        SELECT @Action as [Action]
              ,@TableName as [TableName]
              ,t.[OrderDetailID]
              ,t.[OrderID]
              ,t.[ProductID]
              ,t.[UnitPrice]
              ,t.[Quantity]
              ,t.[Discount]
          FROM [dbo].[OrderDetails] t
          INNER JOIN deleted d on
            t.[OrderDetailID] = d.[OrderDetailID]
          FOR XML RAW, ELEMENTS, ROOT ('NorthWind')
          );
        END;
      ELSE
        BEGIN;
        -- Build the XML message, flagging it as an update
        set @ChangeMsg = (
        SELECT @Action as [Action]
              ,@TableName as [TableName]
              ,t.[OrderDetailID]
              ,t.[OrderID]
              ,t.[ProductID]
              ,t.[UnitPrice]
              ,t.[Quantity]
              ,t.[Discount]
          FROM [dbo].[OrderDetails] t
          INNER JOIN inserted i on
            t.[OrderDetailID] = i.[OrderDetailID]
          FOR XML RAW, ELEMENTS, ROOT ('NorthWind')
          );
        END;

    IF @ChangeMsg IS NOT NULL
      BEGIN
      BEGIN TRANSACTION;
      ;SEND ON CONVERSATION @InitDlgHandle
           MESSAGE TYPE [//NorthWindSync/SBETL]
           (@ChangeMsg);
      --END CONVERSATION @InitDlgHandle;
      COMMIT TRANSACTION;
      END
    END
  END TRY
  BEGIN CATCH
  	IF XACT_STATE() <> 0
  		BEGIN
		-- Rollback any pending transaction
		ROLLBACK TRANSACTION;
		END

	-- Insert the error information into the ErrorLog Categories for later reference
  	INSERT INTO dbo.ErrorLog (ErrorTime, UserName, ErrorNumber, ErrorSeverity,
  		ErrorState, ErrorProcedure, ErrorLine, ErrorMessage, MessageBody)
  	VALUES (getdate(), USER_NAME(), ERROR_NUMBER(), ERROR_SEVERITY(),
  		ERROR_STATE(), ERROR_PROCEDURE(), ERROR_LINE(), ERROR_MESSAGE(), @ChangeMsg)

  END CATCH

GO

EXEC sp_settriggerorder @triggername=N'[dbo].[tr_OrderDetails_IUD]', @order=N'Last', @stmttype=N'DELETE'
GO
EXEC sp_settriggerorder @triggername=N'[dbo].[tr_OrderDetails_IUD]', @order=N'Last', @stmttype=N'INSERT'
GO
EXEC sp_settriggerorder @triggername=N'[dbo].[tr_OrderDetails_IUD]', @order=N'Last', @stmttype=N'UPDATE'
GO

IF OBJECT_ID ('dbo.tr_Orders_IUD','TR') IS NOT NULL
   DROP TRIGGER dbo.tr_Orders_IUD 
GO

CREATE TRIGGER dbo.tr_Orders_IUD
   ON  [dbo].[Orders]
   FOR INSERT, UPDATE, DELETE
AS 

  DECLARE @InitDlgHandle UNIQUEIDENTIFIER;
  DECLARE @ChangeMsg XML;
  DECLARE @ChangeCnt int;
  DECLARE @Action char(1);
  DECLARE @TableName varchar(100) = 'dbo_Orders';
  DECLARE @service_name nvarchar(512) = N'//INST02Site/INST02Service';
	
  SELECT @InitDlgHandle=[ch]
  FROM [dbo].[BrokerConversation]
  WHERE [service_name] = @service_name;
  
  BEGIN TRY
    IF USER_NAME() <> 'INST02User'
    BEGIN

      -- If there are rows in both inserted and deleted, the change is an update
      SELECT @ChangeCnt = count(*)
        FROM [dbo].[Orders] t
        INNER JOIN deleted d on
            t.[OrderID] = d.[OrderID]
        INNER JOIN inserted i on
            t.[OrderID] = i.[OrderID]
      if (@ChangeCnt > 0)
        BEGIN;
        SET @Action = 'U';
        END;
      ELSE
        BEGIN
        -- Since rows aren't in both inserted and deleted, then the change is an insert or a delete
        -- If there are rows in deleted, the change is a delete, and we only need the primary key value
        select @ChangeCnt = count(*) from deleted
        if (@ChangeCnt > 0)
          BEGIN
          SET @Action = 'D';
          END;

        -- If there are rows in inserted, the change is an insert and we need all the column values
        select @ChangeCnt = count(*) from inserted
        if (@ChangeCnt > 0)
          BEGIN
          SET @Action = 'I';
          END;
        END;

      if (@Action = 'D')
        BEGIN;
        -- Build the XML message, flagging it as an update
        set @ChangeMsg = (
        SELECT @Action as [Action]
              ,@TableName as [TableName]
              ,t.[OrderID]
              ,t.[CustomerID]
              ,t.[EmployeeID]
              ,t.[OrderDate]
              ,t.[RequiredDate]
              ,t.[ShippedDate]
              ,t.[ShipVia]
              ,t.[Freight]
              ,t.[ShipName]
              ,t.[ShipAddress]
              ,t.[ShipCity]
              ,t.[ShipRegion]
              ,t.[ShipPostalCode]
              ,t.[ShipCountry]
          FROM [dbo].[Orders] t
          INNER JOIN deleted d on
            t.[OrderID] = d.[OrderID]
          FOR XML RAW, ELEMENTS, ROOT ('NorthWind')
          );
        END;
      ELSE
        BEGIN;
        -- Build the XML message, flagging it as an update
        set @ChangeMsg = (
        SELECT @Action as [Action]
              ,@TableName as [TableName]
              ,t.[OrderID]
              ,t.[CustomerID]
              ,t.[EmployeeID]
              ,t.[OrderDate]
              ,t.[RequiredDate]
              ,t.[ShippedDate]
              ,t.[ShipVia]
              ,t.[Freight]
              ,t.[ShipName]
              ,t.[ShipAddress]
              ,t.[ShipCity]
              ,t.[ShipRegion]
              ,t.[ShipPostalCode]
              ,t.[ShipCountry]
          FROM [dbo].[Orders] t
          INNER JOIN inserted i on
            t.[OrderID] = i.[OrderID]
          FOR XML RAW, ELEMENTS, ROOT ('NorthWind')
          );
        END;

    IF @ChangeMsg IS NOT NULL
      BEGIN
      BEGIN TRANSACTION;
      ;SEND ON CONVERSATION @InitDlgHandle
           MESSAGE TYPE [//NorthWindSync/SBETL]
           (@ChangeMsg);
      --END CONVERSATION @InitDlgHandle;
      COMMIT TRANSACTION;
      END
    END
  END TRY
  BEGIN CATCH
  	IF XACT_STATE() <> 0
  		BEGIN
		-- Rollback any pending transaction
		ROLLBACK TRANSACTION;
		END

	-- Insert the error information into the ErrorLog Categories for later reference
  	INSERT INTO dbo.ErrorLog (ErrorTime, UserName, ErrorNumber, ErrorSeverity,
  		ErrorState, ErrorProcedure, ErrorLine, ErrorMessage, MessageBody)
  	VALUES (getdate(), USER_NAME(), ERROR_NUMBER(), ERROR_SEVERITY(),
  		ERROR_STATE(), ERROR_PROCEDURE(), ERROR_LINE(), ERROR_MESSAGE(), @ChangeMsg)

  END CATCH

GO

EXEC sp_settriggerorder @triggername=N'[dbo].[tr_Orders_IUD]', @order=N'Last', @stmttype=N'DELETE'
GO
EXEC sp_settriggerorder @triggername=N'[dbo].[tr_Orders_IUD]', @order=N'Last', @stmttype=N'INSERT'
GO
EXEC sp_settriggerorder @triggername=N'[dbo].[tr_Orders_IUD]', @order=N'Last', @stmttype=N'UPDATE'
GO

IF OBJECT_ID ('dbo.tr_Products_IUD','TR') IS NOT NULL
   DROP TRIGGER dbo.tr_Products_IUD 
GO

CREATE TRIGGER dbo.tr_Products_IUD
   ON  [dbo].[Products]
   FOR INSERT, UPDATE, DELETE
AS 

  DECLARE @InitDlgHandle UNIQUEIDENTIFIER;
  DECLARE @ChangeMsg XML;
  DECLARE @ChangeCnt int;
  DECLARE @Action char(1);
  DECLARE @TableName varchar(100) = 'dbo_Products';
  DECLARE @service_name nvarchar(512) = N'//INST02Site/INST02Service';
	
  SELECT @InitDlgHandle=[ch]
  FROM [dbo].[BrokerConversation]
  WHERE [service_name] = @service_name;
  
  BEGIN TRY
    IF USER_NAME() <> 'INST02User'
    BEGIN

      -- If there are rows in both inserted and deleted, the change is an update
      SELECT @ChangeCnt = count(*)
        FROM [dbo].[Products] t
        INNER JOIN deleted d on
            t.[ProductID] = d.[ProductID]
        INNER JOIN inserted i on
            t.[ProductID] = i.[ProductID]
      if (@ChangeCnt > 0)
        BEGIN;
        SET @Action = 'U';
        END;
      ELSE
        BEGIN
        -- Since rows aren't in both inserted and deleted, then the change is an insert or a delete
        -- If there are rows in deleted, the change is a delete, and we only need the primary key value
        select @ChangeCnt = count(*) from deleted
        if (@ChangeCnt > 0)
          BEGIN
          SET @Action = 'D';
          END;

        -- If there are rows in inserted, the change is an insert and we need all the column values
        select @ChangeCnt = count(*) from inserted
        if (@ChangeCnt > 0)
          BEGIN
          SET @Action = 'I';
          END;
        END;

      if (@Action = 'D')
        BEGIN;
        -- Build the XML message, flagging it as an update
        set @ChangeMsg = (
        SELECT @Action as [Action]
              ,@TableName as [TableName]
              ,t.[ProductID]
              ,t.[ProductName]
              ,t.[SupplierID]
              ,t.[CategoryID]
              ,t.[QuantityPerUnit]
              ,t.[UnitPrice]
              ,t.[UnitsInStock]
              ,t.[UnitsOnOrder]
              ,t.[ReorderLevel]
              ,t.[Discontinued]
          FROM [dbo].[Products] t
          INNER JOIN deleted d on
            t.[ProductID] = d.[ProductID]
          FOR XML RAW, ELEMENTS, ROOT ('NorthWind')
          );
        END;
      ELSE
        BEGIN;
        -- Build the XML message, flagging it as an update
        set @ChangeMsg = (
        SELECT @Action as [Action]
              ,@TableName as [TableName]
              ,t.[ProductID]
              ,t.[ProductName]
              ,t.[SupplierID]
              ,t.[CategoryID]
              ,t.[QuantityPerUnit]
              ,t.[UnitPrice]
              ,t.[UnitsInStock]
              ,t.[UnitsOnOrder]
              ,t.[ReorderLevel]
              ,t.[Discontinued]
          FROM [dbo].[Products] t
          INNER JOIN inserted i on
            t.[ProductID] = i.[ProductID]
          FOR XML RAW, ELEMENTS, ROOT ('NorthWind')
          );
        END;

    IF @ChangeMsg IS NOT NULL
      BEGIN
      BEGIN TRANSACTION;
      ;SEND ON CONVERSATION @InitDlgHandle
           MESSAGE TYPE [//NorthWindSync/SBETL]
           (@ChangeMsg);
      --END CONVERSATION @InitDlgHandle;
      COMMIT TRANSACTION;
      END
    END
  END TRY
  BEGIN CATCH
  	IF XACT_STATE() <> 0
  		BEGIN
		-- Rollback any pending transaction
		ROLLBACK TRANSACTION;
		END

	-- Insert the error information into the ErrorLog Categories for later reference
  	INSERT INTO dbo.ErrorLog (ErrorTime, UserName, ErrorNumber, ErrorSeverity,
  		ErrorState, ErrorProcedure, ErrorLine, ErrorMessage, MessageBody)
  	VALUES (getdate(), USER_NAME(), ERROR_NUMBER(), ERROR_SEVERITY(),
  		ERROR_STATE(), ERROR_PROCEDURE(), ERROR_LINE(), ERROR_MESSAGE(), @ChangeMsg)

  END CATCH

GO

EXEC sp_settriggerorder @triggername=N'[dbo].[tr_Products_IUD]', @order=N'Last', @stmttype=N'DELETE'
GO
EXEC sp_settriggerorder @triggername=N'[dbo].[tr_Products_IUD]', @order=N'Last', @stmttype=N'INSERT'
GO
EXEC sp_settriggerorder @triggername=N'[dbo].[tr_Products_IUD]', @order=N'Last', @stmttype=N'UPDATE'
GO

IF OBJECT_ID ('dbo.tr_Shippers_IUD','TR') IS NOT NULL
   DROP TRIGGER dbo.tr_Shippers_IUD 
GO

CREATE TRIGGER dbo.tr_Shippers_IUD
   ON  [dbo].[Shippers]
   FOR INSERT, UPDATE, DELETE
AS 

  DECLARE @InitDlgHandle UNIQUEIDENTIFIER;
  DECLARE @ChangeMsg XML;
  DECLARE @ChangeCnt int;
  DECLARE @Action char(1);
  DECLARE @TableName varchar(100) = 'dbo_Shippers';
  DECLARE @service_name nvarchar(512) = N'//INST02Site/INST02Service';
	
  SELECT @InitDlgHandle=[ch]
  FROM [dbo].[BrokerConversation]
  WHERE [service_name] = @service_name;
  
  BEGIN TRY
    IF USER_NAME() <> 'INST02User'
    BEGIN

      -- If there are rows in both inserted and deleted, the change is an update
      SELECT @ChangeCnt = count(*)
        FROM [dbo].[Shippers] t
        INNER JOIN deleted d on
            t.[ShipperID] = d.[ShipperID]
        INNER JOIN inserted i on
            t.[ShipperID] = i.[ShipperID]
      if (@ChangeCnt > 0)
        BEGIN;
        SET @Action = 'U';
        END;
      ELSE
        BEGIN
        -- Since rows aren't in both inserted and deleted, then the change is an insert or a delete
        -- If there are rows in deleted, the change is a delete, and we only need the primary key value
        select @ChangeCnt = count(*) from deleted
        if (@ChangeCnt > 0)
          BEGIN
          SET @Action = 'D';
          END;

        -- If there are rows in inserted, the change is an insert and we need all the column values
        select @ChangeCnt = count(*) from inserted
        if (@ChangeCnt > 0)
          BEGIN
          SET @Action = 'I';
          END;
        END;

      if (@Action = 'D')
        BEGIN;
        -- Build the XML message, flagging it as an update
        set @ChangeMsg = (
        SELECT @Action as [Action]
              ,@TableName as [TableName]
              ,t.[ShipperID]
              ,t.[CompanyName]
              ,t.[Phone]
          FROM [dbo].[Shippers] t
          INNER JOIN deleted d on
            t.[ShipperID] = d.[ShipperID]
          FOR XML RAW, ELEMENTS, ROOT ('NorthWind')
          );
        END;
      ELSE
        BEGIN;
        -- Build the XML message, flagging it as an update
        set @ChangeMsg = (
        SELECT @Action as [Action]
              ,@TableName as [TableName]
              ,t.[ShipperID]
              ,t.[CompanyName]
              ,t.[Phone]
          FROM [dbo].[Shippers] t
          INNER JOIN inserted i on
            t.[ShipperID] = i.[ShipperID]
          FOR XML RAW, ELEMENTS, ROOT ('NorthWind')
          );
        END;

    IF @ChangeMsg IS NOT NULL
      BEGIN
      BEGIN TRANSACTION;
      ;SEND ON CONVERSATION @InitDlgHandle
           MESSAGE TYPE [//NorthWindSync/SBETL]
           (@ChangeMsg);
      --END CONVERSATION @InitDlgHandle;
      COMMIT TRANSACTION;
      END
    END
  END TRY
  BEGIN CATCH
  	IF XACT_STATE() <> 0
  		BEGIN
		-- Rollback any pending transaction
		ROLLBACK TRANSACTION;
		END

	-- Insert the error information into the ErrorLog Categories for later reference
  	INSERT INTO dbo.ErrorLog (ErrorTime, UserName, ErrorNumber, ErrorSeverity,
  		ErrorState, ErrorProcedure, ErrorLine, ErrorMessage, MessageBody)
  	VALUES (getdate(), USER_NAME(), ERROR_NUMBER(), ERROR_SEVERITY(),
  		ERROR_STATE(), ERROR_PROCEDURE(), ERROR_LINE(), ERROR_MESSAGE(), @ChangeMsg)

  END CATCH

GO

EXEC sp_settriggerorder @triggername=N'[dbo].[tr_Shippers_IUD]', @order=N'Last', @stmttype=N'DELETE'
GO
EXEC sp_settriggerorder @triggername=N'[dbo].[tr_Shippers_IUD]', @order=N'Last', @stmttype=N'INSERT'
GO
EXEC sp_settriggerorder @triggername=N'[dbo].[tr_Shippers_IUD]', @order=N'Last', @stmttype=N'UPDATE'
GO

IF OBJECT_ID ('dbo.tr_Suppliers_IUD','TR') IS NOT NULL
   DROP TRIGGER dbo.tr_Suppliers_IUD 
GO

CREATE TRIGGER dbo.tr_Suppliers_IUD
   ON  [dbo].[Suppliers]
   FOR INSERT, UPDATE, DELETE
AS 

  DECLARE @InitDlgHandle UNIQUEIDENTIFIER;
  DECLARE @ChangeMsg XML;
  DECLARE @ChangeCnt int;
  DECLARE @Action char(1);
  DECLARE @TableName varchar(100) = 'dbo_Suppliers';
  DECLARE @service_name nvarchar(512) = N'//INST02Site/INST02Service';
	
  SELECT @InitDlgHandle=[ch]
  FROM [dbo].[BrokerConversation]
  WHERE [service_name] = @service_name;
  
  BEGIN TRY
    IF USER_NAME() <> 'INST02User'
    BEGIN

      -- If there are rows in both inserted and deleted, the change is an update
      SELECT @ChangeCnt = count(*)
        FROM [dbo].[Suppliers] t
        INNER JOIN deleted d on
            t.[SupplierID] = d.[SupplierID]
        INNER JOIN inserted i on
            t.[SupplierID] = i.[SupplierID]
      if (@ChangeCnt > 0)
        BEGIN;
        SET @Action = 'U';
        END;
      ELSE
        BEGIN
        -- Since rows aren't in both inserted and deleted, then the change is an insert or a delete
        -- If there are rows in deleted, the change is a delete, and we only need the primary key value
        select @ChangeCnt = count(*) from deleted
        if (@ChangeCnt > 0)
          BEGIN
          SET @Action = 'D';
          END;

        -- If there are rows in inserted, the change is an insert and we need all the column values
        select @ChangeCnt = count(*) from inserted
        if (@ChangeCnt > 0)
          BEGIN
          SET @Action = 'I';
          END;
        END;

      if (@Action = 'D')
        BEGIN;
        -- Build the XML message, flagging it as an update
        set @ChangeMsg = (
        SELECT @Action as [Action]
              ,@TableName as [TableName]
              ,t.[SupplierID]
              ,t.[SupplierCompanyName]
              ,t.[SupplierContactName]
              ,t.[SupplierContactTitle]
              ,t.[SupplierAddress]
              ,t.[SupplierCity]
              ,t.[SupplierRegion]
              ,t.[SupplierPostalCode]
              ,t.[SupplierCountry]
              ,t.[Phone]
              ,t.[Fax]
          FROM [dbo].[Suppliers] t
          INNER JOIN deleted d on
            t.[SupplierID] = d.[SupplierID]
          FOR XML RAW, ELEMENTS, ROOT ('NorthWind')
          );
        END;
      ELSE
        BEGIN;
        -- Build the XML message, flagging it as an update
        set @ChangeMsg = (
        SELECT @Action as [Action]
              ,@TableName as [TableName]
              ,t.[SupplierID]
              ,t.[SupplierCompanyName]
              ,t.[SupplierContactName]
              ,t.[SupplierContactTitle]
              ,t.[SupplierAddress]
              ,t.[SupplierCity]
              ,t.[SupplierRegion]
              ,t.[SupplierPostalCode]
              ,t.[SupplierCountry]
              ,t.[Phone]
              ,t.[Fax]
          FROM [dbo].[Suppliers] t
          INNER JOIN inserted i on
            t.[SupplierID] = i.[SupplierID]
          FOR XML RAW, ELEMENTS, ROOT ('NorthWind')
          );
        END;

    IF @ChangeMsg IS NOT NULL
      BEGIN
      BEGIN TRANSACTION;
      ;SEND ON CONVERSATION @InitDlgHandle
           MESSAGE TYPE [//NorthWindSync/SBETL]
           (@ChangeMsg);
      --END CONVERSATION @InitDlgHandle;
      COMMIT TRANSACTION;
      END
    END
  END TRY
  BEGIN CATCH
  	IF XACT_STATE() <> 0
  		BEGIN
		-- Rollback any pending transaction
		ROLLBACK TRANSACTION;
		END

	-- Insert the error information into the ErrorLog Categories for later reference
  	INSERT INTO dbo.ErrorLog (ErrorTime, UserName, ErrorNumber, ErrorSeverity,
  		ErrorState, ErrorProcedure, ErrorLine, ErrorMessage, MessageBody)
  	VALUES (getdate(), USER_NAME(), ERROR_NUMBER(), ERROR_SEVERITY(),
  		ERROR_STATE(), ERROR_PROCEDURE(), ERROR_LINE(), ERROR_MESSAGE(), @ChangeMsg)

  END CATCH

GO

EXEC sp_settriggerorder @triggername=N'[dbo].[tr_Suppliers_IUD]', @order=N'Last', @stmttype=N'DELETE'
GO
EXEC sp_settriggerorder @triggername=N'[dbo].[tr_Suppliers_IUD]', @order=N'Last', @stmttype=N'INSERT'
GO
EXEC sp_settriggerorder @triggername=N'[dbo].[tr_Suppliers_IUD]', @order=N'Last', @stmttype=N'UPDATE'
GO


