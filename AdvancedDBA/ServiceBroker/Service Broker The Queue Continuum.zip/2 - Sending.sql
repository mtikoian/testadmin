USE [SBDemo_SQLKaraoke];
GO

DECLARE @dialogHandle uniqueidentifier;

BEGIN DIALOG CONVERSATION @dialogHandle
	FROM SERVICE [//sqlkaraoke.local/song/singerService]
	TO SERVICE '//sqlkaraoke.local/song/djService'
	ON CONTRACT [//sqlkaraoke.local/song/songRequest];

SEND ON CONVERSATION @dialogHandle
	MESSAGE TYPE [//sqlkaraoke.local/song/request]
		('<request>This is a request</request>');
GO

-- Show what's in the queues
SELECT * FROM [songRequestQueue];
SELECT * FROM [djQueue];
SELECT * FROM sys.conversation_endpoints;
GO

SELECT CAST(message_body AS xml) FROM djQueue;
GO

-- Send a return message - Copy the conversation_handle here before proceeding
SEND ON CONVERSATION '1AA5C887-1CA3-E211-82F3-5CAC4CC27CD9'
	MESSAGE TYPE [//sqlkaraoke.local/song/selected]
		('<request>You''re up next!</request>');
GO

-- Show what's in the queues
SELECT *, CAST(message_body AS xml) FROM [songRequestQueue];
SELECT * FROM [djQueue];
SELECT * FROM sys.conversation_endpoints;
GO
