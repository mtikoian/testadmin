USE [master];
GO

IF EXISTS (SELECT 'x' FROM sys.databases WHERE [name] = 'SBDemo_SQLKaraoke')
	DROP DATABASE [SBDemo_SQLKaraoke];

CREATE DATABASE [SBDemo_SQLKaraoke];
GO

USE [SBDemo_SQLKaraoke];
GO

CREATE TABLE Song
	(Id int IDENTITY(1,1) NOT NULL PRIMARY KEY,
	 SongName nvarchar(100) NOT NULL,
	 Artist nvarchar(100) NULL);
CREATE INDEX IX_Song_SongName
	ON Song (SongName);
CREATE INDEX IX_Song_Artist
	ON Song (Artist);
GO

INSERT INTO dbo.Song (SongName, Artist)
	SELECT REPLACE(Song, '''''', '') AS Song, Artists
		FROM OPENROWSET(BULK 'Z:\Dropbox\Presentations\Service Broker\Entertainment_Weekly_s_Great_and_Grating_Karaoke_Songs.txt',
						FORMATFILE = 'Z:\Dropbox\Presentations\Service Broker\songFormat.xml',
						FIRSTROW = 2) AS importFile;
GO
