USE [SBDemo_SQLKaraoke];
GO

CREATE PROCEDURE requestSong (@singer varchar(100), @songId int) AS
BEGIN
	DECLARE @handle uniqueidentifier;
	DECLARE @message xml;
	DECLARE @title nvarchar(100);
	DECLARE @artist nvarchar(100);

	BEGIN DIALOG CONVERSATION @handle
		FROM SERVICE [//sqlkaraoke.local/song/singerService]
		TO SERVICE '//sqlkaraoke.local/song/djService'
		ON CONTRACT [//sqlkaraoke.local/song/songRequest];

	SELECT @title = SongName, @artist = Artist
		FROM dbo.Song
		WHERE Id = @songId;

	SET @message = '<request><song>' + @title + '</song><artist>' + @artist + '</artist><singer>' + @singer + '</singer></request>';

	SEND ON CONVERSATION @handle
		MESSAGE TYPE [//sqlkaraoke.local/song/request]
		(@message);
END;
GO

CREATE PROCEDURE djQueue_Activation AS
BEGIN
	DECLARE @handle uniqueidentifier;
	DECLARE @messageType nvarchar(256);
	DECLARE @message xml;

	BEGIN TRY
		BEGIN TRANSACTION

		WAITFOR (
			RECEIVE TOP (1)
					@handle = conversation_handle,
					@messageType = message_type_name,
					@message = CAST(message_body AS xml)
				FROM djQueue),
			TIMEOUT 5000;

		IF (@@ROWCOUNT > 0)
		BEGIN
			SAVE TRANSACTION messageReceived;
			      
			IF @messageType = '//sqlkaraoke.local/song/request'
			BEGIN
				PRINT 'Song request received';
				
				SEND ON CONVERSATION @handle
					MESSAGE TYPE [//sqlkaraoke.local/song/selected]
					('Your song request has been received. You''re up next!');

				END CONVERSATION @handle;
			END
		END
	END TRY
	BEGIN CATCH
		ROLLBACK TRANSACTION messageReceived;
		
		END CONVERSATION @handle
			WITH ERROR = 50000
				 DESCRIPTION = 'Something bad happened';
	END CATCH;

	COMMIT TRANSACTION;
END;
GO

EXECUTE dbo.requestSong 'Ed', 6;

SELECT *, CAST(message_body AS xml) FROM djQueue;
GO

EXECUTE dbo.djQueue_Activation;

SELECT * FROM djQueue;
SELECT * FROM songRequestQueue;
GO

ALTER QUEUE djQueue
	WITH ACTIVATION (STATUS = ON,
					 PROCEDURE_NAME = dbo.djQueue_Activation,
					 MAX_QUEUE_READERS = 1,
					 EXECUTE AS OWNER);
GO

EXECUTE dbo.requestSong 'Ed', 6;

SELECT *, CAST(message_body AS xml) FROM djQueue;
GO

SELECT *, CAST(message_body AS xml) FROM djQueue;
SELECT *, CAST(message_body AS xml) FROM songRequestQueue;
GO