USE [SBDemo_SQLKaraoke];
GO

DECLARE @handle uniqueidentifier;
DECLARE @messageType nvarchar(256);
DECLARE @message xml;

RECEIVE TOP (1)
		@handle = conversation_handle,
		@messageType = message_type_name,
		@message = CAST(message_body AS XML)
	FROM djQueue;

SELECT @handle, @messageType, @message;

SEND ON CONVERSATION @handle
	MESSAGE TYPE [//sqlkaraoke.local/song/selected]
		('<request>You''re up next!</request>');

END CONVERSATION @handle;
GO

SELECT *, CAST(message_body AS xml) FROM [songRequestQueue];
SELECT * FROM [djQueue];
SELECT * FROM sys.conversation_endpoints;
GO

DECLARE @handle uniqueidentifier;
DECLARE @messageType nvarchar(256);
DECLARE @message xml;

RECEIVE TOP (1)
		@handle = conversation_handle,
		@messageType = message_type_name,
		@message = CAST(message_body AS XML)
	FROM songRequestQueue;

SELECT @handle, @messageType, @message;
GO

SELECT *, CAST(message_body AS xml) FROM [songRequestQueue];
SELECT * FROM [djQueue];
SELECT * FROM sys.conversation_endpoints;
GO

DECLARE @handle uniqueidentifier;
DECLARE @messageType nvarchar(256);
DECLARE @message xml;

RECEIVE TOP (1)
		@handle = conversation_handle,
		@messageType = message_type_name,
		@message = CAST(message_body AS XML)
	FROM songRequestQueue;

SELECT @handle, @messageType, @message;

END CONVERSATION @handle;
GO

SELECT *, CAST(message_body AS xml) FROM [songRequestQueue];
SELECT * FROM [djQueue];
SELECT * FROM sys.conversation_endpoints;
GO
