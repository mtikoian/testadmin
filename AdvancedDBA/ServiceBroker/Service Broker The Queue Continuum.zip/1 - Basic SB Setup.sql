USE [SBDemo_SQLKaraoke];
GO

-- Database owner must be able to be validated if it is a domain user
EXECUTE sys.sp_changedbowner 'sa';
GO

-- Database must have a master key
CREATE MASTER KEY ENCRYPTION BY PASSWORD = 'sql-r0cks!';
GO

ALTER DATABASE [SBDemo_SQLKaraoke] SET ENABLE_BROKER;
GO

CREATE MESSAGE TYPE [//sqlkaraoke.local/song/request]
	VALIDATION = WELL_FORMED_XML;

CREATE MESSAGE TYPE [//sqlkaraoke.local/song/selected]
	VALIDATION = WELL_FORMED_XML;
GO

CREATE CONTRACT [//sqlkaraoke.local/song/songRequest]
	([//sqlkaraoke.local/song/request] SENT BY INITIATOR,
	 [//sqlkaraoke.local/song/selected] SENT BY TARGET);
GO

CREATE QUEUE [songRequestQueue]
	WITH STATUS = ON;

CREATE QUEUE [djQueue]
	WITH STATUS = ON;
GO

CREATE SERVICE [//sqlkaraoke.local/song/singerService]
	ON QUEUE [songRequestQueue]
		([//sqlkaraoke.local/song/songRequest]);

CREATE SERVICE [//sqlkaraoke.local/song/djService]
	ON QUEUE [djQueue]
		([//sqlkaraoke.local/song/songRequest]);
GO
