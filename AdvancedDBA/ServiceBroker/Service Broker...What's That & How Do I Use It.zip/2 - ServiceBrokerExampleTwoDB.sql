/*
Name: 2 - ServiceBrokerExampleTwoDB.sql
Desc: Example scripts for Service Broker communication
      between two databases
Author: Brian Davis (rbd.davis@gmail.com)
Comments: 
  Must have at least DB_DDLADMIN permissions on the database
  Any edition of SQL Server 2005 or SQL Server 2008
Revision History:
  12/8/2010: Original Creation

http://msdn.microsoft.com/en-us/library/bb839498.aspx

*/

/************************************************************
*************************************************************
PART I - Setup & Configuration
*************************************************************
************************************************************/
-- Create Databases
USE master;
GO
IF EXISTS (SELECT * FROM sys.databases
           WHERE name = N'TargetDB')
     DROP DATABASE TargetDB;
GO
CREATE DATABASE TargetDB;
GO
IF EXISTS (SELECT * FROM sys.databases
           WHERE name = N'InitiatorDB')
     DROP DATABASE InitiatorDB;
GO
CREATE DATABASE InitiatorDB;
GO
ALTER DATABASE InitiatorDB SET TRUSTWORTHY ON;
GO

-- Create the Target DB Objects
USE TargetDB;
GO
-- Message Types
CREATE MESSAGE TYPE [//BothDB/2DBSample/RequestMessage]
       VALIDATION = WELL_FORMED_XML;
CREATE MESSAGE TYPE [//BothDB/2DBSample/ReplyMessage]
       VALIDATION = WELL_FORMED_XML;
GO
-- Contracts
CREATE CONTRACT [//BothDB/2DBSample/SimpleContract]
      ([//BothDB/2DBSample/RequestMessage]
         SENT BY INITIATOR,
       [//BothDB/2DBSample/ReplyMessage]
         SENT BY TARGET
      );
GO
-- Queue & Service
CREATE QUEUE TargetQueue2DB;
CREATE SERVICE [//TgtDB/2DBSample/TargetService]
       ON QUEUE TargetQueue2DB
       ([//BothDB/2DBSample/SimpleContract]);
GO

-- Create the Initiator DB Ohjects
USE InitiatorDB;
GO
-- Message Types
CREATE MESSAGE TYPE [//BothDB/2DBSample/RequestMessage]
       VALIDATION = WELL_FORMED_XML;
CREATE MESSAGE TYPE [//BothDB/2DBSample/ReplyMessage]
       VALIDATION = WELL_FORMED_XML;
GO
-- Contracts
CREATE CONTRACT [//BothDB/2DBSample/SimpleContract]
      ([//BothDB/2DBSample/RequestMessage]
         SENT BY INITIATOR,
       [//BothDB/2DBSample/ReplyMessage]
         SENT BY TARGET
      );
GO
-- Queue & Service
CREATE QUEUE InitiatorQueue2DB;
CREATE SERVICE [//InitDB/2DBSample/InitiatorService]
       ON QUEUE InitiatorQueue2DB;
GO

/************************************************************
*************************************************************
PART II - The Conversation
*************************************************************
************************************************************/
-- Start a Conversation & Send a Message
USE InitiatorDB;
GO
DECLARE @InitDlgHandle UNIQUEIDENTIFIER;
DECLARE @RequestMsg NVARCHAR(100);

BEGIN TRANSACTION;
	BEGIN DIALOG @InitDlgHandle
		 FROM SERVICE [//InitDB/2DBSample/InitiatorService]
		 TO SERVICE N'//TgtDB/2DBSample/TargetService'
		 ON CONTRACT [//BothDB/2DBSample/SimpleContract]
		 WITH
			 ENCRYPTION = OFF;
	SELECT @RequestMsg =
	   N'<RequestMsg>Sign Me Up for Even MORE Emails!!!</RequestMsg>';
	SEND ON CONVERSATION @InitDlgHandle
		 MESSAGE TYPE [//BothDB/2DBSample/RequestMessage]
		  (@RequestMsg);
	SELECT @RequestMsg AS SentRequestMsg;
COMMIT TRANSACTION;
GO

--  Receive a Request & Send a Reply
USE TargetDB;
GO
DECLARE @RecvReqDlgHandle UNIQUEIDENTIFIER;
DECLARE @RecvReqMsg NVARCHAR(100);
DECLARE @RecvReqMsgName sysname;

BEGIN TRANSACTION;
	WAITFOR
	( RECEIVE TOP(1)
		@RecvReqDlgHandle = conversation_handle,
		@RecvReqMsg = message_body,
		@RecvReqMsgName = message_type_name
	  FROM TargetQueue2DB
	), TIMEOUT 1000;
	SELECT @RecvReqMsg AS ReceivedRequestMsg;
	IF @RecvReqMsgName =
	   N'//BothDB/2DBSample/RequestMessage'
	BEGIN
		 DECLARE @ReplyMsg NVARCHAR(100);
		 SELECT @ReplyMsg =
			N'<ReplyMsg>Signed Up for a TON of Emails (SUBID=839409).</ReplyMsg>';
	 
		 SEND ON CONVERSATION @RecvReqDlgHandle
			  MESSAGE TYPE
				[//BothDB/2DBSample/ReplyMessage] (@ReplyMsg);

		 END CONVERSATION @RecvReqDlgHandle;
	END
	SELECT @ReplyMsg AS SentReplyMsg;
COMMIT TRANSACTION;
GO

-- Receive the Reply & End the Conversation
USE InitiatorDB;
GO
DECLARE @RecvReplyMsg NVARCHAR(100);
DECLARE @RecvReplyDlgHandle UNIQUEIDENTIFIER;

BEGIN TRANSACTION;
	WAITFOR
	( RECEIVE TOP(1)
		@RecvReplyDlgHandle = conversation_handle,
		@RecvReplyMsg = message_body
	  FROM InitiatorQueue2DB
	), TIMEOUT 1000;
	END CONVERSATION @RecvReplyDlgHandle;
	-- Display recieved request.
	SELECT @RecvReplyMsg AS ReceivedReplyMsg;
COMMIT TRANSACTION;
GO

/************************************************************
*************************************************************
PART III - Cleanup
*************************************************************
************************************************************/
-- Drop the Databases
USE master;
GO
DROP DATABASE TargetDB;
DROP DATABASE InitiatorDB;
