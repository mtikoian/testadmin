/*
Name: ServiceBrokerExampleSingleDB.sql
Desc: Example scripts for Service Broker communication
      within a single database
Author: Brian Davis (rbd.davis@gmail.com)
Comments: 
  Must have at least DB_DDLADMIN permissions on the database
  Any edition of SQL Server 2005 or SQL Server 2008
Revision History:
  12/8/2010: Original Creation

http://msdn.microsoft.com/en-us/library/bb839495.aspx
*/

/************************************************************
*************************************************************
PART I - Setup & Configuration
*************************************************************
************************************************************/
-- Enable Service Broker on the AdventureWorks2008R2 Database
USE master;
GO
ALTER DATABASE AdventureWorksLT2008R2
      SET ENABLE_BROKER;
GO
USE AdventureWorksLT2008R2;
GO

-- Create Message Types
CREATE MESSAGE TYPE [//AWDB/1DBSample/RequestMessage]
       VALIDATION = WELL_FORMED_XML;
CREATE MESSAGE TYPE [//AWDB/1DBSample/ReplyMessage]
       VALIDATION = WELL_FORMED_XML;
GO

-- Create the Contract
CREATE CONTRACT [//AWDB/1DBSample/SampleContract]
      ([//AWDB/1DBSample/RequestMessage]
       SENT BY INITIATOR,
       [//AWDB/1DBSample/ReplyMessage]
       SENT BY TARGET
      );
GO

-- Create the Target Queue & Service
CREATE QUEUE TargetQueue1DB;
-- Create the Target Service
CREATE SERVICE
       [//AWDB/1DBSample/TargetService]  --Service Name
       ON QUEUE TargetQueue1DB            
       ([//AWDB/1DBSample/SampleContract]);  --Only conversations that use this contract can use the service as a target
GO

-- Create the Initiator Queue & Service
CREATE QUEUE InitiatorQueue1DB;
-- Create the Initiator Service
-- No Contract is specified so no other services can use this as a Target Service
CREATE SERVICE
       [//AWDB/1DBSample/InitiatorService]
       ON QUEUE InitiatorQueue1DB;
GO

/*
At this point AdventureWorks2008R2 is configured to support 
a conversation between the //AWDB/1DBSample/InitiatorService 
and the //AWDB/1DBSample/TargetService.
*/

/************************************************************
*************************************************************
PART II - The Conversation
*************************************************************
************************************************************/

-- Begin a Conversation and Send a Request Message
DECLARE @InitDlgHandle UNIQUEIDENTIFIER;
DECLARE @RequestMsg NVARCHAR(100);

BEGIN TRANSACTION;

BEGIN DIALOG @InitDlgHandle
     FROM SERVICE [//AWDB/1DBSample/InitiatorService]
     TO SERVICE N'//AWDB/1DBSample/TargetService'
     ON CONTRACT [//AWDB/1DBSample/SampleContract]
     WITH ENCRYPTION = OFF;

SELECT @RequestMsg = N'<RequestMsg>Sign Me Up for Emails!!.</RequestMsg>';

SEND ON CONVERSATION @InitDlgHandle
     MESSAGE TYPE [//AWDB/1DBSample/RequestMessage]
     (@RequestMsg);

SELECT @RequestMsg AS SentRequestMsg;

COMMIT TRANSACTION;
GO

-- Receive the Request and Send a Reply
DECLARE @RecvReqDlgHandle UNIQUEIDENTIFIER;
DECLARE @RecvReqMsg NVARCHAR(100);
DECLARE @RecvReqMsgName sysname;

BEGIN TRANSACTION;

WAITFOR
( RECEIVE TOP(1)
    @RecvReqDlgHandle = conversation_handle,
    @RecvReqMsg = message_body,
    @RecvReqMsgName = message_type_name
  FROM TargetQueue1DB
), TIMEOUT 1000;

SELECT @RecvReqMsg AS ReceivedRequestMsg;

IF @RecvReqMsgName = N'//AWDB/1DBSample/RequestMessage'
BEGIN
     DECLARE @ReplyMsg NVARCHAR(100);
     SELECT @ReplyMsg = N'<ReplyMsg>Signup Complete! (ID=30547).</ReplyMsg>';
 
     SEND ON CONVERSATION @RecvReqDlgHandle
          MESSAGE TYPE [//AWDB/1DBSample/ReplyMessage]
          (@ReplyMsg);

     END CONVERSATION @RecvReqDlgHandle;
END

SELECT @ReplyMsg AS SentReplyMsg;

COMMIT TRANSACTION;
GO

-- Receive the Reply and End the Conversation
DECLARE @RecvReplyMsg NVARCHAR(100);
DECLARE @RecvReplyDlgHandle UNIQUEIDENTIFIER;

BEGIN TRANSACTION;

WAITFOR
( RECEIVE TOP(1)
    @RecvReplyDlgHandle = conversation_handle,
    @RecvReplyMsg = message_body
  FROM InitiatorQueue1DB
), TIMEOUT 1000;

END CONVERSATION @RecvReplyDlgHandle;

SELECT @RecvReplyMsg AS ReceivedReplyMsg;

COMMIT TRANSACTION;
GO

/************************************************************
*************************************************************
PART III - Cleanup
*************************************************************
************************************************************/

-- Drop the Target Service and Queue
IF EXISTS (SELECT * FROM sys.services
           WHERE name = N'//AWDB/1DBSample/TargetService')
     DROP SERVICE [//AWDB/1DBSample/TargetService];

IF EXISTS (SELECT * FROM sys.service_queues
           WHERE name = N'TargetQueue1DB')
     DROP QUEUE TargetQueue1DB;

-- Drop the Intitator Queue and Service
IF EXISTS (SELECT * FROM sys.services
           WHERE name = N'//AWDB/1DBSample/InitiatorService')
     DROP SERVICE [//AWDB/1DBSample/InitiatorService];

IF EXISTS (SELECT * FROM sys.service_queues
           WHERE name = N'InitiatorQueue1DB')
     DROP QUEUE InitiatorQueue1DB;

-- Drop the Contracts
IF EXISTS (SELECT * FROM sys.service_contracts
           WHERE name = N'//AWDB/1DBSample/SampleContract')
     DROP CONTRACT [//AWDB/1DBSample/SampleContract];

-- Drop the Message Types
IF EXISTS (SELECT * FROM sys.service_message_types
           WHERE name = N'//AWDB/1DBSample/RequestMessage')
     DROP MESSAGE TYPE [//AWDB/1DBSample/RequestMessage];

IF EXISTS (SELECT * FROM sys.service_message_types
           WHERE name = N'//AWDB/1DBSample/ReplyMessage')
     DROP MESSAGE TYPE [//AWDB/1DBSample/ReplyMessage];
GO
