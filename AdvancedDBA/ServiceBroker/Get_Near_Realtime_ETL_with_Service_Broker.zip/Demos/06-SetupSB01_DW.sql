USE NorthwindDW
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[BrokerMessages]') AND type = N'U')
DROP TABLE [dbo].[BrokerMessages]
GO

CREATE TABLE  [dbo].[BrokerMessages] (
	id		INT IDENTITY(1,1) NOT NULL,
	ch		UNIQUEIDENTIFIER,
	messagetypename	NVARCHAR(256),
	messagebody	XML
	)
GO

CREATE TABLE [dbo].[BrokerConversation]
(
	[ch] [uniqueidentifier] NULL,
	[service_name] [nvarchar] (512) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
)
GO
CREATE TABLE [dbo].[ErrorLog](
	[ErrorLogID] [int] IDENTITY(1,1) NOT NULL,
	[ErrorTime] [datetime] NOT NULL,
	[UserName] [sysname] NOT NULL,
	[ErrorNumber] [int] NOT NULL,
	[ErrorSeverity] [int] NULL,
	[ErrorState] [int] NULL,
	[ErrorProcedure] [nvarchar](126) NULL,
	[ErrorLine] [int] NULL,
	[ErrorMessage] [nvarchar](4000) NOT NULL,
	[MessageBody] [xml] NULL,
 CONSTRAINT [PK_ErrorLog_ErrorLogID] PRIMARY KEY CLUSTERED 
(
	[ErrorLogID] ASC
)
) ON [PRIMARY]

GO
IF OBJECT_ID ('dbo.StartETLConversation','P') IS NOT NULL
   DROP PROCEDURE dbo.StartETLConversation
GO
CREATE PROC [dbo].[StartETLConversation]
AS
SET NOCOUNT ON;

    DECLARE @ch UNIQUEIDENTIFIER;
    DECLARE @service_name nvarchar(512) = N'//DWSyncSite/DWSyncService';
    
    SELECT @ch=[ch]
    FROM [dbo].[BrokerConversation]
    WHERE [service_name] = @service_name;
    
    IF @ch IS NOT NULL
        BEGIN
        DELETE FROM [dbo].[BrokerConversation]
        WHERE [service_name] = @service_name;
        
        END CONVERSATION @ch;
        END

    BEGIN DIALOG @ch
       FROM SERVICE [//DWSyncSite/DWSyncService]
       TO SERVICE N'//NWSyncSite/NWSyncService'
       ON CONTRACT [//NorthwindSync/SyncContract]
       WITH
           ENCRYPTION = ON;

    INSERT INTO [dbo].[BrokerConversation]
        (ch, service_name)
    VALUES (@ch, @service_name);

GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ProcessSyncMessages]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[ProcessSyncMessages]
GO

CREATE PROCEDURE [dbo].[ProcessSyncMessages]
AS
SET NOCOUNT ON
	DECLARE @ch UNIQUEIDENTIFIER
	DECLARE @messagetypename NVARCHAR(256)
	DECLARE	@messagebody XML
	DECLARE @responsemessage XML;

	WHILE (1=1)
	BEGIN
		BEGIN TRY
			BEGIN TRANSACTION

			WAITFOR (
				RECEIVE TOP(1)
					@ch = conversation_handle,
					@messagetypename = message_type_name,
					@messagebody = CAST(message_body AS XML)
				FROM DWSyncQueue
			), TIMEOUT 60000

			IF (@@ROWCOUNT = 0)
			BEGIN
				ROLLBACK TRANSACTION
				BREAK
			END
			
			INSERT INTO [dbo].[BrokerMessages] (ch, messagetypename, messagebody)
			VALUES (@ch, @messagetypename, @messagebody);

			-- End the conversation
			--END CONVERSATION @ch;

			COMMIT TRANSACTION
		END TRY
		BEGIN CATCH
				
			ROLLBACK TRANSACTION

			INSERT INTO dbo.ErrorLog (ErrorTime, UserName, ErrorNumber, ErrorSeverity,
				ErrorState, ErrorProcedure, ErrorLine, ErrorMessage, MessageBody)
			VALUES (getdate(), USER_NAME(), ERROR_NUMBER(), ERROR_SEVERITY(),
				ERROR_STATE(), ERROR_PROCEDURE(), ERROR_LINE(), ERROR_MESSAGE(), @messagebody)

			--END CONVERSATION @ch;
			
			INSERT INTO [dbo].[BrokerMessages] (ch, messagetypename, messagebody)
			VALUES (@ch, @messagetypename, @messagebody);

		END CATCH
	END
GO