USE [NorthwindDW]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ProcessProducts]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[ProcessProducts]
GO

CREATE PROCEDURE [dbo].[ProcessProducts]
	@messagebody XML
WITH EXECUTE AS 'NWSyncUser'
AS
  SET NOCOUNT ON
  BEGIN TRY
  
    -- Create a temporary table to hold the message results
    CREATE TABLE #Products (
	[Action] nchar(1) NULL,
	[ProductID]  Int NULL,
	[ProductName]  NVarChar(40) NULL,
	[SupplierID]  Int NULL,
	[CategoryID]  Int NULL,
	[QuantityPerUnit]  NVarChar(20) NULL,
	[UnitPrice]  Money NULL,
	[UnitsInStock]  SmallInt NULL,
	[UnitsOnOrder]  SmallInt NULL,
	[ReorderLevel]  SmallInt NULL,
	[Discontinued]  Bit NULL
	)
    
    -- Use XQuery to shred the message and insert it into the temporary table
    INSERT INTO #Products
    SELECT
	a.value(N'(./Action)[1]', N'nchar(1)') as [Action],
	a.value(N'(./ProductID)[1]', N'Int') as [ProductID],
	a.value(N'(./ProductName)[1]', N'NVarChar(40)') as [ProductName],
	a.value(N'(./SupplierID)[1]', N'Int') as [SupplierID],
	a.value(N'(./CategoryID)[1]', N'Int') as [CategoryID],
	a.value(N'(./QuantityPerUnit)[1]', N'NVarChar(20)') as [QuantityPerUnit],
	a.value(N'(./UnitPrice)[1]', N'Money') as [UnitPrice],
	a.value(N'(./UnitsInStock)[1]', N'SmallInt') as [UnitsInStock],
	a.value(N'(./UnitsOnOrder)[1]', N'SmallInt') as [UnitsOnOrder],
	a.value(N'(./ReorderLevel)[1]', N'SmallInt') as [ReorderLevel],
	a.value(N'(./Discontinued)[1]', N'Bit') as [Discontinued]
	from @messagebody.nodes('/SBETL/row') as r(a);
    
    -- Insert or Update the rows based on the incoming changes

    UPDATE s
      SET s.[ProductEndDate] = GETDATE()
    FROM [dbo].[dimProducts] s
    INNER JOIN #Products t ON s.[ProductID] = t.[ProductID]
      WHERE s.[ProductEndDate] IS NULL
    
    DELETE FROM #Products
      WHERE [Action] = 'D'
    
    INSERT INTO [dbo].[dimProducts]
           ([ProductID]
           ,[ProductName]
           ,[SupplierID]
           ,[SupplierCompanyName]
           ,[SupplierContactName]
           ,[SupplierContactTitle]
           ,[SupplierAddress]
           ,[SupplierCity]
           ,[SupplierRegion]
           ,[SupplierPostalCode]
           ,[SupplierCountry]
           ,[CategoryID]
           ,[CategoryName]
           ,[CategoryDescription]
           ,[QuantityPerUnit]
           ,[UnitPrice]
           ,[ProductStartDate]
           ,[ProductEndDate])
    SELECT t.[ProductID]
      ,t.[ProductName]
      ,t.[SupplierID]
      ,[SupplierCompanyName] = CASE WHEN s.[SupplierID] IS NULL THEN 'Unknown' ELSE s.[SupplierCompanyName] END
      ,[SupplierContactName] = CASE WHEN s.[SupplierID] IS NULL THEN 'Unknown' ELSE s.[SupplierContactName] END
      ,[SupplierContactTitle] = CASE WHEN s.[SupplierID] IS NULL THEN 'Unknown' ELSE s.[SupplierContactTitle] END
      ,[SupplierAddress] = CASE WHEN s.[SupplierID] IS NULL THEN 'Unknown' ELSE s.[SupplierAddress] END
      ,[SupplierCity] = CASE WHEN s.[SupplierID] IS NULL THEN 'Unknown' ELSE s.[SupplierCity] END
      ,[SupplierRegion] = CASE WHEN s.[SupplierID] IS NULL THEN 'Unknown' ELSE s.[SupplierRegion] END
      ,[SupplierPostalCode] = CASE WHEN s.[SupplierID] IS NULL THEN 'Unknown' ELSE s.[SupplierPostalCode] END
      ,[SupplierCountry] = CASE WHEN s.[SupplierID] IS NULL THEN 'Unknown' ELSE s.[SupplierCountry] END
      ,t.[CategoryID]
      ,[CategoryName] = CASE WHEN c.[CategoryID] IS NULL THEN 'Unknown' ELSE c.[CategoryName] END
      ,[CategoryDescription] = CASE WHEN c.[CategoryID] IS NULL THEN 'Unknown' ELSE c.[CategoryDescription] END
      ,t.[QuantityPerUnit]
      ,t.[UnitPrice]
      ,GETDATE() AS [ProductStartDate]
      ,NULL AS [ProductEndDate]
    FROM #Products t
    LEFT JOIN [Reference].[Categories] c ON t.[CategoryID] = c.[CategoryID]
    LEFT JOIN [Reference].[Suppliers] s ON t.[SupplierID] = s.[SupplierID]

  END TRY

  BEGIN CATCH
    -- Insert any errors into the ErrorLog table for later review and correction
    INSERT INTO dbo.ErrorLog (ErrorTime, UserName, ErrorNumber, ErrorSeverity,
    	ErrorState, ErrorProcedure, ErrorLine, ErrorMessage, MessageBody)
    VALUES (getdate(), USER_NAME(), ERROR_NUMBER(), ERROR_SEVERITY(),
    	ERROR_STATE(), ERROR_PROCEDURE(), ERROR_LINE(), ERROR_MESSAGE(), @messagebody)
  
  END CATCH

  RETURN

GO
