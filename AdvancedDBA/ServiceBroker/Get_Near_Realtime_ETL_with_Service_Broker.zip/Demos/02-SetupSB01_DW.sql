USE master
GO

SELECT d.is_master_key_encrypted_by_server
FROM sys.databases AS d
WHERE d.name = 'NorthwindDW';  --Returns 0 before implementing the database master key
GO

USE NorthwindDW
GO

CREATE MASTER KEY
       ENCRYPTION BY PASSWORD = N'XYJDn2SXHjceE5R98uu9Ts9G';
GO

CREATE USER DWSyncUser WITHOUT LOGIN;
GO

CREATE CERTIFICATE DWSyncCertificate
     AUTHORIZATION DWSyncUser
     WITH SUBJECT = N'DWSync Certificate',
          EXPIRY_DATE = N'12/31/2040';
GO

BACKUP CERTIFICATE DWSyncCertificate
  TO FILE = N'E:\Certs\DWSyncCertificate.cer';
GO

USE [master] 
ALTER DATABASE [NorthwindDW] SET NEW_BROKER
GO

USE NorthwindDW
GO

CREATE MESSAGE TYPE [//NorthWindSync/SBETL]
AUTHORIZATION dbo
VALIDATION = WELL_FORMED_XML
GO

CREATE CONTRACT [//NorthWindSync/SyncContract]
	AUTHORIZATION dbo (
	[//NorthWindSync/SBETL] SENT BY ANY
	)
GO

CREATE QUEUE DWSyncQueue
   WITH 
   STATUS = ON,
   RETENTION = OFF 
GO

CREATE SERVICE [//DWSyncSite/DWSyncService] 
AUTHORIZATION DWSyncUser 
ON QUEUE DWSyncQueue
([//NorthWindSync/SyncContract])
GO

USE [master];
GO

IF EXISTS 
(SELECT * 
	FROM sys.endpoints
	WHERE name = N'INST02Endpoint')
	
	DROP ENDPOINT INST02Endpoint;
GO

CREATE ENDPOINT INST02Endpoint
STATE = STARTED
AS TCP ( LISTENER_PORT = 4023 )
FOR SERVICE_BROKER (AUTHENTICATION = WINDOWS );
GO
GRANT CONNECT ON ENDPOINT::[INST02Endpoint] to [SQLTBWS\sqlexec]
GO


