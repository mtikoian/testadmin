USE AdventureWorks
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ProcessSyncData]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[ProcessSyncData]
GO

CREATE PROCEDURE [dbo].[ProcessSyncData]
AS
SET NOCOUNT ON
	DECLARE @broker_id INT;
	DECLARE @ch UNIQUEIDENTIFIER
	DECLARE @messagetypename NVARCHAR(256)
	DECLARE	@messagebody XML
	DECLARE @responsemessage XML;
	DECLARE @returnrows INT;

	WHILE (1=1)
	BEGIN
		BEGIN TRY

			SELECT TOP 1 @broker_id=broker_id, @ch=ch, @messagetypename=messagetypename, @messagebody=messagebody
			FROM [dbo].[BrokerMessages]
			ORDER BY broker_id;
			SELECT @returnrows = @@ROWCOUNT

			IF (@returnrows > 0)
			BEGIN

				IF (@messagetypename = '//PortalSync/Sync/HumanResourcesEmployee')
				BEGIN
					-- Process the message
					EXEC dbo.ProcessEmployee @messagebody
				END
				IF (@messagetypename = '//PortalSync/Sync/PersonContact')
				BEGIN
					-- Process the message
					EXEC dbo.ProcessContact @messagebody
				END
				IF (@messagetypename = '//PortalSync/Sync/PurchasingVendor')
				BEGIN
					-- Process the message
					EXEC dbo.ProcessVendor @messagebody
				END

				-- Delete the message so it's only processed once
				DELETE FROM [dbo].[BrokerMessages]
				WHERE broker_id = @broker_id;
			END
			ELSE
			BEGIN
				-- If we're out of messages, wait a minute and then check again
				WAITFOR DELAY '00:01:00';
			END

		END TRY
		BEGIN CATCH

			INSERT INTO dbo.ErrorLog (ErrorTime, UserName, ErrorNumber, ErrorSeverity,
				ErrorState, ErrorProcedure, ErrorLine, ErrorMessage)
			VALUES (getdate(), USER_NAME(), ERROR_NUMBER(), ERROR_SEVERITY(),
				ERROR_STATE(), ERROR_PROCEDURE(), ERROR_LINE(), ERROR_MESSAGE())

		END CATCH
	END

GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ProcessEmployee]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[ProcessEmployee]
GO

CREATE PROCEDURE [dbo].[ProcessEmployee]
	@messagebody XML
AS
  SET NOCOUNT ON
  BEGIN TRY
  
    -- Create a temporary table to hold the message results
    CREATE TABLE #Employee(
    	[Action] [nchar](1) NOT NULL,
	[EmployeeID] [int] NOT NULL,
	[NationalIDNumber] [nvarchar](15) NOT NULL,
	[ContactID] [int] NOT NULL,
	[LoginID] [nvarchar](256) NOT NULL,
	[ManagerID] [int] NULL,
	[Title] [nvarchar](50) NOT NULL,
	[BirthDate] [datetime] NOT NULL,
	[MaritalStatus] [nchar](1) NOT NULL,
	[Gender] [nchar](1) NOT NULL,
	[HireDate] [datetime] NOT NULL,
	[SalariedFlag] [dbo].[Flag] NOT NULL,
	[VacationHours] [smallint] NOT NULL,
	[SickLeaveHours] [smallint] NOT NULL,
	[CurrentFlag] [dbo].[Flag] NOT NULL
    );
    
    -- Use XQuery to shred the message and insert it into the temporary table
    INSERT INTO #Employee
    select  a.value(N'(./Action)[1]', N'nchar(1)') as [Action],
        a.value(N'(./EmployeeID)[1]', N'int') as [EmployeeID],
        a.value(N'(./NationalIDNumber)[1]', N'nvarchar(15)') as [NationalIDNumber],
        a.value(N'(./ContactID)[1]', N'int') as [ContactID],
        a.value(N'(./LoginID)[1]', N'nvarchar(256)') as [LoginID],
        a.value(N'(./ManagerID)[1]', N'int') as [ManagerID],
        a.value(N'(./Title)[1]', N'nvarchar(50)') as [Title],
        a.value(N'(./BirthDate)[1]', N'datetime') as [BirthDate],
        a.value(N'(./MaritalStatus)[1]', N'nchar(1)') as [MaritalStatus],
        a.value(N'(./Gender)[1]', N'nchar(1)') as [Gender],
        a.value(N'(./HireDate)[1]', N'datetime') as [HireDate],
        a.value(N'(./SalariedFlag)[1]', N'bit') as [SalariedFlag],
        a.value(N'(./VacationHours)[1]', N'smallint') as [VacationHours],
        a.value(N'(./SickLeaveHours)[1]', N'smallint') as [SickLeaveHours],
        a.value(N'(./CurrentFlag)[1]', N'bit') as [CurrentFlag]
    from @messagebody.nodes('/Employee/row') as r(a);

    -- Merge the updates into the Employee table
    MERGE [HumanResources].[Employee] e
    USING #Employee t
    ON e.EmployeeID = t.EmployeeID
    WHEN MATCHED AND (t.Action = 'D') THEN
      DELETE
    WHEN MATCHED THEN
    UPDATE
      SET [NationalIDNumber] = t.[NationalIDNumber]
	,[ContactID] = t.[ContactID]
	,[LoginID] = t.[LoginID]
	,[ManagerID] = t.[ManagerID]
	,[Title] = t.[Title]
	,[BirthDate] = t.[BirthDate]
	,[MaritalStatus] = t.[MaritalStatus]
	,[Gender] = t.[Gender]
	,[HireDate] = t.[HireDate]
	,[SalariedFlag] = t.[SalariedFlag]
	,[VacationHours] = t.[VacationHours]
	,[SickLeaveHours] = t.[SickLeaveHours]
	,[CurrentFlag] = t.[CurrentFlag]
    WHEN NOT MATCHED THEN
      INSERT ([EmployeeID]
	,[NationalIDNumber]
	,[ContactID]
	,[LoginID]
	,[ManagerID]
	,[Title]
	,[BirthDate]
	,[MaritalStatus]
	,[Gender]
	,[HireDate]
	,[SalariedFlag]
	,[VacationHours]
	,[SickLeaveHours]
	,[CurrentFlag])
      VALUES ([EmployeeID]
	,t.[NationalIDNumber]
	,t.[ContactID]
	,t.[LoginID]
	,t.[ManagerID]
	,t.[Title]
	,t.[BirthDate]
	,t.[MaritalStatus]
	,t.[Gender]
	,t.[HireDate]
	,t.[SalariedFlag]
	,t.[VacationHours]
	,t.[SickLeaveHours]
	,t.[CurrentFlag]);
    
  END TRY

  BEGIN CATCH
    -- Insert any errors into the ErrorLog table for later review and correction
    INSERT INTO dbo.ErrorLog (ErrorTime, UserName, ErrorNumber, ErrorSeverity,
    	ErrorState, ErrorProcedure, ErrorLine, ErrorMessage)
    VALUES (getdate(), USER_NAME(), ERROR_NUMBER(), ERROR_SEVERITY(),
    	ERROR_STATE(), ERROR_PROCEDURE(), ERROR_LINE(), ERROR_MESSAGE(), @messagebody)
  
  END CATCH

  RETURN

GO
