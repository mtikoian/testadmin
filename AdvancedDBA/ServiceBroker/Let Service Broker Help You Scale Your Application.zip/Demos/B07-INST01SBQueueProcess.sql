USE AdventureWorks
GO

ALTER QUEUE INST01Queue
WITH ACTIVATION
(
	STATUS = ON,
	PROCEDURE_NAME = [dbo].[ProcessSyncMessages],
	MAX_QUEUE_READERS = 1,
	EXECUTE AS 'INST01User'
)
GO
GRANT EXECUTE ON dbo.ProcessSyncMessages to INST01User
GO
