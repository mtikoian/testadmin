-- DO NOT FORGET TO QUERY - SQLCMD MODE!!!

!! md "E:\certs"

USE [MASTER] 
ALTER DATABASE [AdventureWorks] SET NEW_BROKER
GO

USE AdventureWorks
GO

CREATE MASTER KEY
       ENCRYPTION BY PASSWORD = N'D8CT93u8XAr4ctcBopX7V7dm';
GO

CREATE USER ETLUser WITHOUT LOGIN;
GO
CREATE CERTIFICATE ETLCert 
     AUTHORIZATION ETLUser
     WITH SUBJECT = 'ETL Certificate',
          EXPIRY_DATE = N'12/31/2012';

BACKUP CERTIFICATE ETLCert
  TO FILE = N'E:\Certs\ETLCert.cer';
GO

CREATE MESSAGE TYPE [//WhseETL/Customer] 
AUTHORIZATION dbo 
VALIDATION = WELL_FORMED_XML
GO

CREATE MESSAGE TYPE [//WhseETL/Product] 
AUTHORIZATION dbo 
VALIDATION = WELL_FORMED_XML
GO

CREATE MESSAGE TYPE [//WhseETL/SalesOrderHeader] 
AUTHORIZATION dbo 
VALIDATION = WELL_FORMED_XML
GO

CREATE MESSAGE TYPE [//WhseETL/SalesOrderDetail] 
AUTHORIZATION dbo 
VALIDATION = WELL_FORMED_XML
GO

CREATE CONTRACT [//WhseETL/ETLContract]
    AUTHORIZATION dbo 
    ( [//WhseETL/Customer] SENT BY ANY,
      [//WhseETL/Product] SENT BY ANY,
      [//WhseETL/SalesOrderHeader] SENT BY ANY,
      [//WhseETL/SalesOrderDetail] SENT BY ANY
    )
GO

CREATE QUEUE ETLQueue
   WITH 
   STATUS = ON,
   RETENTION = OFF 
GO

CREATE SERVICE [//WhseETL/ETLService] 
AUTHORIZATION ETLUser 
ON QUEUE ETLQueue
([//WhseETL/ETLContract])
GO

CREATE QUEUE ETLProcessQueue
   WITH 
   STATUS = ON,
   RETENTION = OFF 
GO

CREATE SERVICE [//WhseETL/ETLProcessSvc] 
AUTHORIZATION ETLUser 
ON QUEUE ETLProcessQueue
([//WhseETL/ETLContract])
GO


-- Send a message

  DECLARE @InitDlgHandle UNIQUEIDENTIFIER;
  DECLARE @ChangeMsg XML;
  DECLARE @ChangeCnt int;

      BEGIN DIALOG @InitDlgHandle
           FROM SERVICE [//WhseETL/ETLService]
           TO SERVICE N'//WhseETL/ETLProcessSvc'
           ON CONTRACT [//WhseETL/ETLContract]
           WITH
               ENCRYPTION = ON;

        set @ChangeMsg = (
        SELECT TOP 1 c.[AccountNumber]
          FROM [Sales].[Customer] c
          FOR XML RAW, ELEMENTS, ROOT ('Customer')
          );

      BEGIN TRANSACTION;
      SEND ON CONVERSATION @InitDlgHandle
           MESSAGE TYPE [//WhseETL/Customer]
           (@ChangeMsg);
      COMMIT TRANSACTION;
      END CONVERSATION @InitDlgHandle;

-- View the transmission queue
SELECT * FROM sys.transmission_queue
GO

-- View the created conversation endpoints
SELECT * FROM sys.conversation_endpoints
GO

-- See that it's there
  SELECT * from ETLProcessQueue
  
-- Now actually receive it
    DECLARE @ch UNIQUEIDENTIFIER
    DECLARE @messagetypename NVARCHAR(256),
        @service_name nvarchar(512),
        @service_contract_name NVARCHAR(256)
    DECLARE @messagebody XML

    WAITFOR (
        RECEIVE TOP(1)
            @ch = conversation_handle,
            @service_name = service_name,
            @service_contract_name = service_contract_name,
            @messagetypename = message_type_name,
            @messagebody = CAST(message_body AS XML)
        FROM ETLProcessQueue
    ), TIMEOUT 60000

    SELECT @messagebody

-- See that it's not there now
  SELECT * from ETLProcessQueue
  
