
USE AdventureWorks
GO

IF OBJECT_ID ('HumanResources.trIUDEmployee','TR') IS NOT NULL
   DROP TRIGGER HumanResources.trIUDEmployee 
GO

CREATE TRIGGER HumanResources.trIUDEmployee
   ON  [HumanResources].[Employee]
   FOR INSERT, UPDATE, DELETE
AS 

  DECLARE @InitDlgHandle UNIQUEIDENTIFIER;
  DECLARE @ChangeMsg XML;
  DECLARE @ChangeCnt int;
  
  BEGIN TRANSACTION;
  
  select @ChangeCnt = count(*)
    from [HumanResources].[Employee] e
    inner join deleted d on e.[EmployeeID] = d.[EmployeeID]
    INNER JOIN inserted i on e.[EmployeeID] = i.[EmployeeID];
  if (@ChangeCnt > 0)
    BEGIN
    set @ChangeMsg = (
    SELECT 'U' as [Action]
          ,e.[EmployeeID]
          ,e.[NationalIDNumber]
          ,e.[ContactID]
          ,e.[LoginID]
          ,e.[ManagerID]
          ,e.[Title]
          ,e.[BirthDate]
          ,e.[MaritalStatus]
          ,e.[Gender]
          ,e.[HireDate]
          ,e.[SalariedFlag]
          ,e.[VacationHours]
          ,e.[SickLeaveHours]
          ,e.[CurrentFlag]
      FROM [HumanResources].[Employee] e
      INNER JOIN inserted i on e.[EmployeeID] = i.[EmployeeID]
      FOR XML RAW, ELEMENTS, ROOT ('Employee')
      );
  
    END;
  ELSE
    BEGIN
    select @ChangeCnt = count(*) from deleted
    if (@ChangeCnt > 0)
      BEGIN
      set @ChangeMsg = (
      SELECT 'D' as [Action]
            ,d.[EmployeeID]
        FROM deleted d
        FOR XML RAW, ELEMENTS, ROOT ('Employee')
        );
    
      END;
    
    select @ChangeCnt = count(*) from inserted
    if (@ChangeCnt > 0)
      BEGIN
      set @ChangeMsg = (
        SELECT 'I' as [Action]
            ,e.[EmployeeID]
            ,e.[NationalIDNumber]
            ,e.[ContactID]
            ,e.[LoginID]
            ,e.[ManagerID]
            ,e.[Title]
            ,e.[BirthDate]
            ,e.[MaritalStatus]
            ,e.[Gender]
            ,e.[HireDate]
            ,e.[SalariedFlag]
            ,e.[VacationHours]
            ,e.[SickLeaveHours]
            ,e.[CurrentFlag]
        FROM [HumanResources].[Employee] e
        INNER JOIN inserted i on e.[EmployeeID] = i.[EmployeeID]
        FOR XML RAW, ELEMENTS, ROOT ('Employee')
        );
    
      END;
  
    END;

  BEGIN DIALOG @InitDlgHandle
       FROM SERVICE [//INST02Site/Sync/INST02Service]
       TO SERVICE N'//INST01Site/Sync/INST01Service'
       ON CONTRACT [//PortalSync/Sync/SyncContract]
       WITH
           ENCRYPTION = ON;

  SEND ON CONVERSATION @InitDlgHandle
       MESSAGE TYPE [//PortalSync/Sync/HumanResourcesEmployee]
       (@ChangeMsg);
  
  COMMIT TRANSACTION;
  
GO

IF OBJECT_ID ('Person.trIUDContact','TR') IS NOT NULL
   DROP TRIGGER Person.trIUDContact 
GO

CREATE TRIGGER Person.trIUDContact
   ON  Person.Contact
   FOR INSERT, UPDATE, DELETE
AS 

  DECLARE @InitDlgHandle UNIQUEIDENTIFIER;
  DECLARE @ChangeMsg XML;
  DECLARE @ChangeCnt int;
  
  BEGIN TRANSACTION;
  
  select @ChangeCnt = count(*)
    from [Person].[Contact] c
    inner join deleted d on c.[ContactID] = d.[ContactID]
    INNER JOIN inserted i on c.[ContactID] = i.[ContactID];
  if (@ChangeCnt > 0)
    BEGIN
    set @ChangeMsg = (
    SELECT 'U' as [Action]
          ,c.[ContactID]
          ,c.[NameStyle]
          ,c.[Title]
          ,c.[FirstName]
          ,c.[MiddleName]
          ,c.[LastName]
          ,c.[Suffix]
          ,c.[EmailAddress]
          ,c.[EmailPromotion]
          ,c.[Phone]
          ,c.[PasswordHash]
          ,c.[PasswordSalt]
      FROM [Person].[Contact] c
      INNER JOIN inserted i on c.[ContactID] = i.[ContactID]
      FOR XML RAW, ELEMENTS, ROOT ('Contact')
      );
  
    END;
  ELSE
    BEGIN
    select @ChangeCnt = count(*) from deleted
    if (@ChangeCnt > 0)
      BEGIN
      set @ChangeMsg = (
      SELECT 'D' as [Action]
            ,d.[ContactID]
        FROM deleted d
        FOR XML RAW, ELEMENTS, ROOT ('Contact')
        );
    
      END;
    
    select @ChangeCnt = count(*) from inserted
    if (@ChangeCnt > 0)
      BEGIN
      set @ChangeMsg = (
      SELECT 'I' as [Action]
            ,c.[ContactID]
            ,c.[NameStyle]
            ,c.[Title]
            ,c.[FirstName]
            ,c.[MiddleName]
            ,c.[LastName]
            ,c.[Suffix]
            ,c.[EmailAddress]
            ,c.[EmailPromotion]
            ,c.[Phone]
            ,c.[PasswordHash]
            ,c.[PasswordSalt]
        FROM [Person].[Contact] c
        INNER JOIN inserted i on c.[ContactID] = i.[ContactID]
        FOR XML RAW, ELEMENTS, ROOT ('Contact')
        );
    
      END;
  
    END;
  
  BEGIN DIALOG @InitDlgHandle
       FROM SERVICE [//INST02Site/Sync/INST02Service]
       TO SERVICE N'//INST01Site/Sync/INST01Service'
       ON CONTRACT [//PortalSync/Sync/SyncContract]
       WITH
           ENCRYPTION = ON;

  SEND ON CONVERSATION @InitDlgHandle
       MESSAGE TYPE [//PortalSync/Sync/PersonContact]
       (@ChangeMsg);

  COMMIT TRANSACTION;
  
GO

IF OBJECT_ID ('Purchasing.trIUDVendor','TR') IS NOT NULL
   DROP TRIGGER Purchasing.trIUDVendor
GO

CREATE TRIGGER Purchasing.trIUDVendor
   ON  [Purchasing].[Vendor]
   FOR INSERT, UPDATE, DELETE
AS 

  DECLARE @InitDlgHandle UNIQUEIDENTIFIER;
  DECLARE @ChangeMsg XML;
  DECLARE @ChangeCnt int;
  
  BEGIN TRANSACTION;
  
  select @ChangeCnt = count(*)
    from [Purchasing].[Vendor] v
    inner join deleted d on v.[VendorID] = d.[VendorID]
    INNER JOIN inserted i on v.[VendorID] = i.[VendorID];
  if (@ChangeCnt > 0)
    BEGIN
    set @ChangeMsg = (
    SELECT 'U' as [Action]
          ,v.[VendorID]
          ,v.[AccountNumber]
          ,v.[Name]
          ,v.[CreditRating]
          ,v.[PreferredVendorStatus]
          ,v.[ActiveFlag]
          ,v.[PurchasingWebServiceURL]
      FROM [Purchasing].[Vendor] v
      INNER JOIN inserted i on v.[VendorID] = i.[VendorID]
      FOR XML RAW, ELEMENTS, ROOT ('Vendor')
      );
  
    END;
  ELSE
    BEGIN
    select @ChangeCnt = count(*) from deleted
    if (@ChangeCnt > 0)
      BEGIN
      set @ChangeMsg = (
      SELECT 'D' as [Action]
            ,d.[VendorID]
        FROM deleted d
        FOR XML RAW, ELEMENTS, ROOT ('Vendor')
        );
    
      END;
    
    select @ChangeCnt = count(*) from inserted
    if (@ChangeCnt > 0)
      BEGIN
      set @ChangeMsg = (
        SELECT 'I' as [Action]
            ,v.[VendorID]
            ,v.[AccountNumber]
            ,v.[Name]
            ,v.[CreditRating]
            ,v.[PreferredVendorStatus]
            ,v.[ActiveFlag]
            ,v.[PurchasingWebServiceURL]
        FROM [Purchasing].[Vendor] v
        INNER JOIN inserted i on v.[VendorID] = i.[VendorID]
        FOR XML RAW, ELEMENTS, ROOT ('Vendor')
        );
    
      END;
  
    END;
  
  BEGIN DIALOG @InitDlgHandle
       FROM SERVICE [//INST02Site/Sync/INST02Service]
       TO SERVICE N'//INST01Site/Sync/INST01Service'
       ON CONTRACT [//PortalSync/Sync/SyncContract]
       WITH
           ENCRYPTION = ON;

  SEND ON CONVERSATION @InitDlgHandle
       MESSAGE TYPE [//PortalSync/Sync/PurchasingVendor]
       (@ChangeMsg);

  COMMIT TRANSACTION;
  
GO
