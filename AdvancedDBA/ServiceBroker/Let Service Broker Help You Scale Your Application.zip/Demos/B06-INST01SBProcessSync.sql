USE AdventureWorks
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[BrokerMessages]') AND type = N'U')
DROP TABLE [dbo].[BrokerMessages]
GO

CREATE TABLE  [dbo].[BrokerMessages] (
	id		INT IDENTITY(1,1) NOT NULL,
	ch		UNIQUEIDENTIFIER,
	messagetypename	NVARCHAR(256),
	messagebody	XML
	)
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ProcessSyncMessages]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[ProcessSyncMessages]
GO

CREATE PROCEDURE [dbo].[ProcessSyncMessages]
AS
SET NOCOUNT ON
	DECLARE @ch UNIQUEIDENTIFIER
	DECLARE @messagetypename NVARCHAR(256)
	DECLARE	@messagebody XML
	DECLARE @responsemessage XML;

	WHILE (1=1)
	BEGIN
		BEGIN TRY
			BEGIN TRANSACTION

			WAITFOR (
				RECEIVE TOP(1)
					@ch = conversation_handle,
					@messagetypename = message_type_name,
					@messagebody = CAST(message_body AS XML)
				FROM INST01Queue
			), TIMEOUT 60000

			IF (@@ROWCOUNT = 0)
			BEGIN
				ROLLBACK TRANSACTION
				BREAK
			END
			
			INSERT INTO [dbo].[BrokerMessages] (ch, messagetypename, messagebody)
			VALUES (@ch, @messagetypename, @messagebody);

			-- End the conversation
			END CONVERSATION @ch;

			COMMIT TRANSACTION
		END TRY
		BEGIN CATCH
				
			ROLLBACK TRANSACTION

			INSERT INTO dbo.ErrorLog (ErrorTime, UserName, ErrorNumber, ErrorSeverity,
				ErrorState, ErrorProcedure, ErrorLine, ErrorMessage)
			VALUES (getdate(), USER_NAME(), ERROR_NUMBER(), ERROR_SEVERITY(),
				ERROR_STATE(), ERROR_PROCEDURE(), ERROR_LINE(), ERROR_MESSAGE())

			END CONVERSATION @ch;
			
			INSERT INTO [dbo].[BrokerMessages] (ch, messagetypename, messagebody)
			VALUES (@ch, @messagetypename, @messagebody);

		END CATCH
	END
GO