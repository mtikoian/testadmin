-- DO NOT FORGET TO QUERY - SQLCMD MODE!!!

!! md "E:\certs"

USE AdventureWorks
GO

CREATE MASTER KEY
       ENCRYPTION BY PASSWORD = N'D8CT93u8XAr4ctcBopX7V7dm';
GO

CREATE USER INST01User WITHOUT LOGIN;
GO
CREATE CERTIFICATE INST01Certificate 
     AUTHORIZATION INST01User
     WITH SUBJECT = 'INST01 Certificate',
          EXPIRY_DATE = N'12/31/2012';

BACKUP CERTIFICATE INST01Certificate
  TO FILE = N'E:\Certs\INST01Certificate.cer';
GO

USE [MASTER] 
ALTER DATABASE [AdventureWorks] SET NEW_BROKER
GO

USE AdventureWorks
GO

CREATE MESSAGE TYPE [//PortalSync/Sync/HumanResourcesEmployee] 
AUTHORIZATION dbo 
VALIDATION = WELL_FORMED_XML
GO

CREATE MESSAGE TYPE [//PortalSync/Sync/PersonContact] 
AUTHORIZATION dbo 
VALIDATION = WELL_FORMED_XML
GO

CREATE MESSAGE TYPE [//PortalSync/Sync/PurchasingVendor] 
AUTHORIZATION dbo 
VALIDATION = WELL_FORMED_XML
GO

CREATE CONTRACT [//PortalSync/Sync/SyncContract]
	AUTHORIZATION dbo 
	( [//PortalSync/Sync/HumanResourcesEmployee] SENT BY ANY, 
	  [//PortalSync/Sync/PersonContact] SENT BY ANY,
      [//PortalSync/Sync/PurchasingVendor] SENT BY ANY )
GO

CREATE QUEUE INST01Queue
   WITH 
   STATUS = ON,
   RETENTION = OFF 
GO

CREATE SERVICE [//INST01Site/Sync/INST01Service] 
AUTHORIZATION INST01User 
ON QUEUE INST01Queue
([//PortalSync/Sync/SyncContract])
GO

USE [master];
GO

IF EXISTS 
(SELECT * 
	FROM master.sys.endpoints
    WHERE name = N'INST01Endpoint')
    
	DROP ENDPOINT INST01Endpoint;
GO

CREATE ENDPOINT INST01Endpoint
STATE = STARTED
AS TCP ( LISTENER_PORT = 4022 )
FOR SERVICE_BROKER (AUTHENTICATION = WINDOWS );
GO
GRANT CONNECT ON ENDPOINT::[INST01Endpoint] to [SQLTBWS\sqlexec]
GO
