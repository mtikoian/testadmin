/**********************************************************************
**  drop existing objects
**********************************************************************/
USE	PittsburghSteelers
GO

if	exists(select 1 from sys.services where name = 'sb_srvc_Steelers_Alpha')
	drop	service [sb_srvc_Steelers_Alpha]
go
if	exists(select 1 from sys.service_queues where name = 'sb_queue_Steelers_Alpha')
	drop	queue [dbo].[sb_queue_Steelers_Alpha]
go
if	exists( select 1 from sys.service_contracts where name = 'sb_contract_Steelers_Sync')
	drop	contract [sb_contract_Steelers_Sync]
go
if	exists(select 1 from sys.service_message_types where name = N'sb_MessageType_Steelers_Roster')
	drop	message type sb_MessageType_Steelers_Roster
go
/**********************************************************************
**  create  master key

DEMO PASSWORD ONLY!!!
MAKE YOURS A STRONG PASSWORD!!!

**********************************************************************/
CREATE	MASTER KEY ENCRYPTION BY PASSWORD = N'PittsburghSteelers';
GO
/**********************************************************************
**  create 01 user.  Login is not necessary
**********************************************************************/
CREATE	USER WR01_ALPHA_User WITHOUT LOGIN;
GO
/**********************************************************************
**  create and backup certificate
**********************************************************************/

CREATE	CERTIFICATE WR01_ALPHA_Certificate 
	AUTHORIZATION	WR01_ALPHA_User
	WITH SUBJECT	= 'WR01 Certificate'	,
	EXPIRY_DATE	= N'12/31/2099'		;
GO
BACKUP	CERTIFICATE WR01_ALPHA_Certificate
TO	FILE =
N'C:\Users\sqlwarewolf\Google Drive\Presentations\ServiceBroker\ServiceBrokerPittsburgh\WR01_ALPHA_Certificate.cer';
GO
/**********************************************************************
**  enable service broker
**********************************************************************/
USE	[MASTER] 
ALTER	DATABASE PittsburghSteelers SET NEW_BROKER

GO
/**********************************************************************
**  Create message type
**********************************************************************/
Use	PittsburghSteelers
go
CREATE		MESSAGE TYPE [sb_MessageType_Steelers_Roster] 
AUTHORIZATION	dbo 
VALIDATION	= WELL_FORMED_XML;
GO
/**********************************************************************
**  Create contract for messages
**********************************************************************/
CREATE	CONTRACT [sb_contract_Steelers_Sync]
	AUTHORIZATION dbo 
	(
	[sb_MessageType_Steelers_Roster]	SENT BY ANY
	)
GO

/**********************************************************************
**  Create queue and service
**********************************************************************/
CREATE	QUEUE sb_queue_Steelers_Alpha
WITH 
STATUS		= ON	,
RETENTION	= OFF 
GO

CREATE	SERVICE [sb_srvc_Steelers_Alpha] 
AUTHORIZATION WR01_ALPHA_User 
ON	QUEUE sb_queue_Steelers_Alpha
([sb_contract_Steelers_Sync])
GO

/**********************************************************************
**  Create endpoint
**********************************************************************/
USE	[master];
GO

IF	EXISTS (SELECT 1 FROM master.sys.endpoints WHERE name = N'WAREWOLF_ALPHA_Endpoint')
    
	DROP ENDPOINT WAREWOLF_ALPHA_Endpoint;
GO

CREATE	ENDPOINT WAREWOLF_ALPHA_Endpoint
STATE	= STARTED
AS	TCP ( LISTENER_PORT = 4022 )
FOR	SERVICE_BROKER (AUTHENTICATION = WINDOWS );
GO
GRANT	CONNECT ON ENDPOINT::[WAREWOLF_ALPHA_Endpoint]
to	[SQLWAREWOLF-LAP\sqlwarewolf] --SQL Server Service Account
GO
