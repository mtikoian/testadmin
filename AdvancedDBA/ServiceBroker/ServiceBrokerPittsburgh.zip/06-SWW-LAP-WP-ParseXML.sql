Use	PittsburghSteelers
go
/**********************************************************************
**  Create tables
**********************************************************************/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[BrokerMessages]') AND type = N'U')
DROP TABLE [dbo].[BrokerMessages]
GO

CREATE TABLE  [dbo].[BrokerMessages] (
	id		INT IDENTITY(1,1)	,
	ch		UNIQUEIDENTIFIER	,
	messagetypename	NVARCHAR(256)		,
	messagebody	XML
	)
GO


IF	NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ErrorLog]') AND type in (N'U'))
BEGIN
CREATE	TABLE [dbo].[ErrorLog]
	(
	[ErrorLogID] [int] IDENTITY(1,1),
	[ErrorTime] [datetime],
	[UserName] [sysname],
	[ErrorNumber] [int],
	[ErrorSeverity] [int],
	[ErrorState] [int],
	[ErrorProcedure] [nvarchar](126),
	[ErrorLine] [int],
	[ErrorMessage] [nvarchar](4000),
 CONSTRAINT [PK_ErrorLog_ErrorLogID] PRIMARY KEY CLUSTERED 
(
	[ErrorLogID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
go
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[DF_ErrorLog_ErrorTime]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[ErrorLog] ADD  CONSTRAINT [DF_ErrorLog_ErrorTime]  DEFAULT (getdate()) FOR [ErrorTime]
END

GO

GO
if	OBJECT_ID('Roster', 'U') is not null
	drop	table Roster
Go
create	table Roster
	(
	RosterID		int			not null	,
	PlayerNumber		smallint				,
	PlayerLN		varchar(64)				,
	PlayerFN		varchar(64)				,
	PlayerStatus		char(1)					,
	PlayerStartDate		datetime				,
	PlayerPosition		char(2)					,
	PlayerDepthPosition	tinyint
	)

go
alter	table Roster
add	constraint PK_Roster_RosterID  primary key clustered(RosterID)
go

/**********************************************************************
**  
**********************************************************************/
if	object_id('uspProcessBMRoster', 'P') is not null
	drop	procedure uspProcessBMRoster
go
create	procedure uspProcessBMRoster
	@messagetypename	nvarchar(256) = 'sb_MessageType_Steelers_Roster'
as
set	nocount on
/**********************************************************************
**  
**********************************************************************/
declare	@BMID		int	,
	@MessageBody	xml

create	table #tmp_Roster
	(
	Action			char(1)			,
	RosterID		int			,
	PlayerNumber		smallint		,
	PlayerLN		varchar(64)		,
	PlayerFN		varchar(64)		,
	PlayerStatus		char(1)			,
	PlayerStartDate		datetime		,
	PlayerPosition		char(2)			,
	PlayerDepthPosition	tinyint
	)
/**********************************************************************
**  
**********************************************************************/
BEGIN	TRANSACTION;
BEGIN	TRY;
while	exists(select 1 from BrokerMessages where messagetypename = @messagetypename)
	BEGIN
		select	top 1
			@BMID = id
		from	BrokerMessages
		where	messagetypename = @messagetypename
		order	by id;

		insert	into #tmp_Roster
			(
			Action			,
			RosterID		,
			PlayerNumber		,
			PlayerLN		,
			PlayerFN		,
			PlayerStatus		,
			PlayerPosition		,
			PlayerDepthPosition
			)
		select	[Action]		= BrokerMessages.Process.value('Action[1]', 'char(1)')			,
			RosterID		= BrokerMessages.Process.value('RosterID[1]', 'int')			,
			PlayerNumber		= BrokerMessages.Process.value('PlayerNumber[1]', 'smallint')		,
			PlayerLN		= BrokerMessages.Process.value('PlayerLN[1]', 'varchar(64)')		,
			PlayerFN		= BrokerMessages.Process.value('PlayerFN[1]', 'varchar(64)')		,
			PlayerStatus		= BrokerMessages.Process.value('PlayerStatus[1]', 'char(1)')		,
			PlayerPosition		= BrokerMessages.Process.value('PlayerPosition[1]', 'char(2)')		,
			PlayerDepthPosition	= BrokerMessages.Process.value('PlayerDepthPosition[1]', 'tinyint')
		FROM	[BrokerMessages] as Data
			CROSS APPLY [messagebody].nodes('/Roster/row')  AS BrokerMessages (Process)
		Where	data.id = @BMID;
		--------------------------------------------------------------------------------------------
		if	exists(select 1 from #tmp_Roster where Action = 'I')
			BEGIN
				insert	into Roster
					(
					RosterID		,
					PlayerNumber		,
					PlayerLN		,
					PlayerFN		,
					PlayerStatus		,
					PlayerPosition		,
					PlayerDepthPosition
					)
				select	RosterID		,
					PlayerNumber		,
					PlayerLN		,
					PlayerFN		,
					PlayerStatus		,
					PlayerPosition		,
					PlayerDepthPosition
				from	#tmp_Roster;
			END
		--------------------------------------------------------------------------------------------
		else	if exists(select 1 from #tmp_Roster where Action = 'U')
			BEGIN
				update	r
				set	r.RosterID		= t.RosterID		,
					r.PlayerNumber		= t.PlayerNumber	,
					r.PlayerLN		= t.PlayerLN		,
					r.PlayerFN		= t.PlayerFN		,
					r.PlayerStatus		= t.PlayerStatus	,
					r.PlayerPosition	= t.PlayerPosition	,
					r.PlayerDepthPosition	= t.PlayerDepthPosition
				from	#tmp_Roster t
					inner join Roster r on r.RosterID = t.RosterID;
			END
		--------------------------------------------------------------------------------------------
		else	if exists(select 1 from #tmp_Roster where Action = 'D')
			BEGIN
				delete	r
				from	#tmp_Roster t
					inner join Roster r on r.RosterID = t.RosterID;
			END
		--------------------------------------------------------------------------------------------
		delete	b
		from	BrokerMessages b
		where	b.id = @BMID;
	END;
END	TRY
BEGIN	CATCH;

	declare	@error			varchar(5000)	,
		@ERROR_NUMBER		varchar(10)	,
		@ERROR_SEVERITY		varchar(10)	,
		@ERROR_STATE		varchar(10)	,
		@ERROR_PROCEDURE	varchar(128)	,
		@ERROR_LINE		varchar(10)	,
		@ERROR_MESSAGE		varchar(4000)	;
	
	select	@ERROR_LINE		= ERROR_LINE()		,
		@ERROR_MESSAGE		= ERROR_MESSAGE()	,
		@ERROR_NUMBER		= ERROR_NUMBER()	,
		@ERROR_PROCEDURE	= ERROR_PROCEDURE()	,
		@ERROR_SEVERITY		= ERROR_SEVERITY()	,
		@ERROR_STATE		= ERROR_STATE()		;
		
	
	set	@error +=	'Error Number   : ' + isnull(@ERROR_NUMBER, '')		+ CHAR(13) + CHAR(10)
	set	@error +=	'Error Severity : ' + isnull(@ERROR_SEVERITY, '')	+ CHAR(13) + CHAR(10)
	set	@error +=	'Error State    : ' + isnull(@ERROR_STATE, '')		+ CHAR(13) + CHAR(10)
	set	@error +=	'Error Procedure: ' + isnull(@ERROR_PROCEDURE, '')	+ CHAR(13) + CHAR(10)
	set	@error +=	'Error Line     : ' + isnull(@ERROR_LINE, '')		+ CHAR(13) + CHAR(10)
	set	@error +=	'Error Message  : ' + isnull(@ERROR_MESSAGE, '')	+ CHAR(13) + CHAR(10)

	SELECT	@ERROR_NUMBER		AS ErrorNumber		,
		@ERROR_SEVERITY		AS ErrorSeverity	,
		@ERROR_STATE		AS ErrorState		,
		@ERROR_PROCEDURE	AS ErrorProcedure	,
		@ERROR_LINE		AS ErrorLine		,
		@ERROR_MESSAGE		AS ErrorMessage		;
		
	RAISERROR (@error,10,1); 

	RAISERROR (@error,16,1);

IF	@@TRANCOUNT > 0
        ROLLBACK TRANSACTION;
END	CATCH;

IF	@@TRANCOUNT > 0
    COMMIT TRANSACTION;