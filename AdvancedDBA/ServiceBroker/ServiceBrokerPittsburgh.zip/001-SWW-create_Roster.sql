USE [PittsburghSteelers]
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Roster]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[Roster](
	[RosterID] [int] NOT NULL,
	[PlayerNumber] [smallint] NULL,
	[PlayerLN] [varchar](64) NULL,
	[PlayerFN] [varchar](64) NULL,
	[PlayerStatus] [char](1) NULL,
	[PlayerStartDate] [datetime] NULL,
	[PlayerPosition] [char](2) NULL,
	[PlayerDepthPosition] [tinyint] NULL,
 CONSTRAINT [PK_Roster_RosterID] PRIMARY KEY CLUSTERED 
(
	[RosterID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO

SET ANSI_PADDING OFF
GO
INSERT [dbo].[Roster] ([RosterID], [PlayerNumber], [PlayerLN], [PlayerFN], [PlayerStatus], [PlayerStartDate], [PlayerPosition], [PlayerDepthPosition]) 
VALUES (1, 8, N'Roethlisberger', N'Ben', N'A', NULL, N'QB', 1)
GO
INSERT [dbo].[Roster] ([RosterID], [PlayerNumber], [PlayerLN], [PlayerFN], [PlayerStatus], [PlayerStartDate], [PlayerPosition], [PlayerDepthPosition]) 
VALUES (2, 46, N'Bell', N'Le''veon', N'A', NULL, N'RB', 1)
GO
INSERT [dbo].[Roster] ([RosterID], [PlayerNumber], [PlayerLN], [PlayerFN], [PlayerStatus], [PlayerStartDate], [PlayerPosition], [PlayerDepthPosition]) 
VALUES (3, 11, N'Brown', N'Antonio', N'A', NULL, N'WR', 1)
GO

