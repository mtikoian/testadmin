USE [PittsburghSteelers]
GO
select	*
from	roster
go


