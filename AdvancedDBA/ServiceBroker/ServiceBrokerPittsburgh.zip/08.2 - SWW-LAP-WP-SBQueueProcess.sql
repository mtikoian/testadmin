USE PittsburghSteelers
GO

ALTER QUEUE sb_queue_Steelers_Wolfpack
WITH ACTIVATION
(
	STATUS = ON,
	PROCEDURE_NAME = [dbo].[ProcessSyncMessages],
	MAX_QUEUE_READERS = 1,
	EXECUTE AS 'WR01_ALPHA_User'
)
GO
GRANT EXECUTE ON dbo.ProcessSyncMessages to WR01_ALPHA_User
GO
