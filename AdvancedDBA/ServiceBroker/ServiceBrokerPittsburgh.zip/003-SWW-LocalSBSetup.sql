
--set	ansi_warnings off
set	nocount on
go
/****************************************************************************************
** enable service broker
****************************************************************************************/
use	master
go
ALTER	DATABASE PittsburghSteelers SET DISABLE_BROKER;
GO
ALTER	DATABASE PittsburghSteelers SET ENABLE_BROKER;
GO

/****************************************************************************************
** Create the message types
****************************************************************************************/
USE	PittsburghSteelers
go
/****************************************************************************************
** check for/drop existing objects
****************************************************************************************/
if	exists(select 1 from sys.services where name = 'sb_srvc_Steelers_Plays_Result')
	drop	service [sb_srvc_Steelers_Plays_Result]
go
if	exists(select 1 from sys.services where name = 'sb_srvc_Steelers_Plays_Processing')
	drop	service [sb_srvc_Steelers_Plays_Processing]
go
if	exists(select 1 from sys.service_queues where name = 'sb_queue_Steelers_Plays_Result')
	drop	queue [sb_queue_Steelers_Plays_Result]
go
if	exists(select 1 from sys.service_queues where name = 'sb_queue_Steelers_Plays_Processing')
	drop	queue [sb_queue_Steelers_Plays_Processing]
go
if	exists( select 1 from sys.service_contracts where name = 'sb_contract_Steelers_Plays_Processing')
	drop	contract [sb_contract_Steelers_Plays_Processing] 
go
if	exists(select 1 from sys.service_message_types where name = N'sb_MessageType_Steelers_Plays_Processing')
	drop	message type [sb_MessageType_Steelers_Plays_Processing]
go
if	exists(select 1 from sys.service_message_types where name = N'sb_MessageType_Steelers_Plays_Result')
	drop	message type [sb_MessageType_Steelers_Plays_Result] 
GO

/****************************************************************************************
** Create the message type(s)
****************************************************************************************/
CREATE	MESSAGE TYPE [sb_MessageType_Steelers_Plays_Processing]	VALIDATION = WELL_FORMED_XML;
GO
CREATE	MESSAGE TYPE [sb_MessageType_Steelers_Plays_Result]	VALIDATION = WELL_FORMED_XML;

--NONE
  --------
--Specifies that no validation is performed. The message body can contain data, or it can be NULL.


--EMPTY
  --------
--Specifies that the message body must be NULL.


--WELL_FORMED_XML
  --------
--Specifies that the message body must contain well-formed XML.


--VALID_XML WITH SCHEMA COLLECTION schema_collection_name
  --------
--Specifies that the message body must contain XML that complies with a schema in the specified
--schema collection The schema_collection_name must be the name of an existing XML schema collection.

/****************************************************************************************
** Create the contract
****************************************************************************************/
GO
CREATE	CONTRACT [sb_contract_Steelers_Plays_Processing] 
	(
	[sb_MessageType_Steelers_Plays_Processing]	SENT BY ANY, 
	[sb_MessageType_Steelers_Plays_Result]	SENT BY ANY
	);

/****************************************************************************************
** Create the processing queue and service - specify the contract to allow sending to the service
****************************************************************************************/


GO
CREATE	QUEUE  [sb_queue_Steelers_Plays_Processing];
GO
CREATE	SERVICE [sb_srvc_Steelers_Plays_Processing] ON QUEUE [sb_queue_Steelers_Plays_Processing] ([sb_contract_Steelers_Plays_Processing]);

/****************************************************************************************
** Create the request queue and service
****************************************************************************************/ 


GO
CREATE	QUEUE [sb_queue_Steelers_Plays_Result];
GO
CREATE	SERVICE [sb_srvc_Steelers_Plays_Result] ON QUEUE [sb_queue_Steelers_Plays_Result] ([sb_contract_Steelers_Plays_Processing]);

GO
/****************************************************************************************
** Create the wrapper procedure for sending messages
****************************************************************************************/
if	object_id('SendBrokerMessage', 'P') is not null
	drop	procedure SendBrokerMessage
GO
CREATE	PROCEDURE dbo.SendBrokerMessage 
	@FromService SYSNAME,
	@ToService   SYSNAME,
	@Contract    SYSNAME,
	@MessageType SYSNAME,
	@MessageBody XML
AS
BEGIN
	---------------------------------------------------------------------
	SET	NOCOUNT ON;
 
	DECLARE	@conversation_handle UNIQUEIDENTIFIER;
	---------------------------------------------------------------------
	BEGIN	TRANSACTION;
	---------------------------------------------------------------------
	BEGIN	DIALOG CONVERSATION	@conversation_handle
		FROM	SERVICE		@FromService
		TO	SERVICE		@ToService
		ON	CONTRACT	@Contract
		WITH	ENCRYPTION	= OFF;
 
	SEND	ON CONVERSATION @conversation_handle
	MESSAGE	TYPE @MessageType(@MessageBody);
	---------------------------------------------------------------------
	COMMIT	TRANSACTION;
END
GO
/****************************************************************************************
** Add messages to queue.  View queue
****************************************************************************************/
declare	@playNumber	tinyint = 1	,
	@MessageBody	varchar(512)

while	@playNumber < 12
	BEGIN
		set	@MessageBody =
			N'<pr>
			<PlaysRequest><PlayNumber>'
			+ cast(@playNumber as varchar) +
			'</PlayNumber>
			<RQ>0</RQ>
			</PlaysRequest>
			</pr>'

		EXECUTE	dbo.SendBrokerMessage
			@FromService = N'sb_srvc_Steelers_Plays_Result'		,
			@ToService   = N'sb_srvc_Steelers_Plays_Processing'	,
			@Contract    = N'sb_contract_Steelers_Plays_Processing'	,
			@MessageType = N'sb_MessageType_Steelers_Plays_Processing'	,
			@MessageBody = @MessageBody				;

		set	@playNumber = @playNumber + 1
	END
GO

SELECT CAST(message_body AS XML) FROM [sb_queue_Steelers_Plays_Processing];
GO

/****************************************************************************************
** Create processing procedure for processing queue
****************************************************************************************/
if	object_id('PittsburghSteelers_PlaysProcessingQueueActivation', 'P') is not null
	drop	procedure PittsburghSteelers_PlaysProcessingQueueActivation
GO
CREATE	PROCEDURE dbo.PittsburghSteelers_PlaysProcessingQueueActivation
AS
BEGIN
	---------------------------------------------------------------------
	SET NOCOUNT ON;
	set ansi_warnings on;
	---------------------------------------------------------------------
	DECLARE	@conversation_handle	UNIQUEIDENTIFIER	,
		@message_body		XML			,
		@message_type_name	sysname			,
		@PlayNumber		INT			,
		@rowCount		int			,
		@PlayResult		varchar(512)		,
		@RequestQueue		bit = 1			,
		@reply_message_body	XML			;
	---------------------------------------------------------------------


	WHILE	(1=1)
		BEGIN
			BEGIN	TRANSACTION			;
 
			WAITFOR
				(
				RECEIVE TOP (1)
					@conversation_handle	= conversation_handle,
					@message_body		= CAST(message_body AS XML),
					@message_type_name	= message_type_name
				FROM	[sb_queue_Steelers_Plays_Processing]
				), TIMEOUT 5000			;

			set	@rowCount = @@ROWCOUNT


 
			IF	(@rowCount = 0)
				BEGIN
					
					rollback TRANSACTION	;
					BREAK			;
				END
 

			IF	@message_type_name = N'sb_MessageType_Steelers_Plays_Processing'
				BEGIN
					-- Handle complex long processing here
					-- For demonstration we'll pull the account number and send a reply back only

					set	@PlayNumber = @message_body.value('(pr/PlaysRequest/PlayNumber)[1]', 'INT');
					set	@RequestQueue = @message_body.value('(pr/PlaysRequest/RQ)[1]', 'BIT');




					select	@PlayResult	= PlayResult
					from	PlayScript
					where	PlayID		= @PlayNumber;

					while	charindex('<', @PlayResult) > 0
						BEGIN
							select	@PlayResult =
								replace	(
									@PlayResult,
									'<' + cast(r.RosterID as varchar) + '>',
									r.PlayerLN
									)
							From	roster r
							where	@PlayResult  like '%<' + cast(r.RosterID as varchar) + '>%';
						END
					
					if	@RequestQueue = 1
						BEGIN
							-- Build reply message and send back
							set	@reply_message_body =
								N'<play><playresult>'
								+ CAST(@PlayResult AS NVARCHAR(512))
								+ '</playresult></play>'	;
 
							SEND ON CONVERSATION @conversation_handle
							MESSAGE TYPE [sb_MessageType_Steelers_Plays_Result] (@reply_message_body);
						END
				END
 
			-- If end dialog message, end the dialog
			ELSE	IF @message_type_name = N'http://schemas.microsoft.com/SQL/ServiceBroker/EndDialog'
				BEGIN
					END	CONVERSATION @conversation_handle;
				END
 
			-- If error message, log and end conversation
			ELSE	IF @message_type_name = N'http://schemas.microsoft.com/SQL/ServiceBroker/Error'
				BEGIN
					-- Log the error code and perform any required handling here
					-- End the conversation for the error
					END CONVERSATION @conversation_handle;
				END
 
			COMMIT TRANSACTION;
		END
END
GO
/****************************************************************************************
** Create procedure for processing replies to the request queue
****************************************************************************************/
if	object_id('PittsburghSteelers_PlaysResultQueueActivation', 'P') is not null
	drop	procedure PittsburghSteelers_PlaysResultQueueActivation
GO
-- 
CREATE PROCEDURE dbo.PittsburghSteelers_PlaysResultQueueActivation
AS
BEGIN
	---------------------------------------------------------------------
	SET NOCOUNT ON;
	set	ansi_warnings on;
 
	DECLARE	@conversation_handle	UNIQUEIDENTIFIER	,
		@message_body		XML			,
		@message_type_name	sysname			,
		@PlayResult		varchar(512)		,
		@rowCount		int			;

	---------------------------------------------------------------------
 

	WHILE	(1=1)
		BEGIN
			BEGIN TRANSACTION;
 
			WAITFOR
				(
				RECEIVE TOP (1)
					@conversation_handle	= conversation_handle		,
					@message_body		= CAST(message_body AS XML)	,
					@message_type_name	= message_type_name
				FROM	[sb_queue_Steelers_Plays_Result]
				), TIMEOUT 5000;

			set	@rowCount = @@ROWCOUNT


 
			IF	(@rowCount = 0)
				BEGIN

					rollback TRANSACTION	;
					BREAK			;
				END
 
			IF	@message_type_name = N'sb_MessageType_Steelers_Plays_Result'
				BEGIN
					-- If necessary handle the reply message here
					set	@PlayResult = @message_body.value('(play/playresult)[1]', 'varchar(512)');


					select	@PlayResult;
					waitfor delay '00:00:03';
 
					-- Since this is all the work being done, end the conversation to send the EndDialog message
					END	CONVERSATION @conversation_handle;
				END
 
			-- If end dialog message, end the dialog
			ELSE	IF @message_type_name = N'http://schemas.microsoft.com/SQL/ServiceBroker/EndDialog'
				END CONVERSATION @conversation_handle;

 
			-- If error message, log and end conversation
			ELSE	IF @message_type_name = N'http://schemas.microsoft.com/SQL/ServiceBroker/Error'
				END	CONVERSATION @conversation_handle;
 
			COMMIT TRANSACTION;
		END
END
GO





exec	PittsburghSteelers_PlaysProcessingQueueActivation;
go
SELECT CAST(message_body AS XML) FROM [sb_queue_Steelers_Plays_Processing];
GO
SELECT CAST(message_body AS XML) FROM [sb_queue_Steelers_Plays_Result];
GO
/****************************************************************************************
** Alter the processing queue to specify internal activation
****************************************************************************************/
go
-- 
alter	QUEUE [sb_queue_Steelers_Plays_Processing]
	WITH	ACTIVATION
		( 
		STATUS			= ON							,
		PROCEDURE_NAME		= dbo.PittsburghSteelers_PlaysProcessingQueueActivation	,
		MAX_QUEUE_READERS	= 1							,
		EXECUTE AS self
		);
GO
/****************************************************************************************
** Alter the request queue to specify internal activation
****************************************************************************************/
--ALTER	QUEUE [sb_queue_Steelers_Plays_Result]
--	WITH	ACTIVATION
--		( 
--		STATUS			= ON				,
--		PROCEDURE_NAME		= dbo.PittsburghSteelers_PlaysResultQueueActivation	,
--		MAX_QUEUE_READERS	= 1				,
--		EXECUTE AS self
--		);
--GO


/****************************************************************************************
** Test automated activation
****************************************************************************************/
-- 
-- Send a request


go
 
declare	@playNumber	tinyint = 1	,
	@MessageBody	varchar(512);

while	@playNumber < 12
	BEGIN
		set	@MessageBody =
			N'<pr>
			<PlaysRequest><PlayNumber>'
			+ cast(@playNumber as varchar) +
			'</PlayNumber>
			<RQ>1</RQ>
			</PlaysRequest>
			</pr>'

		EXECUTE	dbo.SendBrokerMessage
			@FromService = N'sb_srvc_Steelers_Plays_Result'							,
			@ToService   = N'sb_srvc_Steelers_Plays_Processing'							,
			@Contract    = N'sb_contract_Steelers_Plays_Processing'								,
			@MessageType = N'sb_MessageType_Steelers_Plays_Processing'								,
			@MessageBody = @MessageBody	;

		set	@playNumber = @playNumber + 1;
	END
GO
-- Check for message on processing queue 
-- nothing is there because it was automatically processed
SELECT CAST(message_body AS XML) FROM [sb_queue_Steelers_Plays_Processing];
GO
 
-- Check for reply message on request queue 
-- This can be made to automatically process, but for this demo, 
-- we are processing manually to see the results
SELECT count(1) as Number_of_Play_Results FROM [sb_queue_Steelers_Plays_Result];
GO

exec	PittsburghSteelers_PlaysResultQueueActivation;
go

SELECT CAST(message_body AS XML) FROM [sb_queue_Steelers_Plays_Result];
GO