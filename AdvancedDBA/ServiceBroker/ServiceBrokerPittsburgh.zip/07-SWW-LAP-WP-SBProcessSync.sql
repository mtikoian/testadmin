USE PittsburghSteelers
GO

/**********************************************************************
**  Process procedures
**********************************************************************/

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ProcessSyncMessages]')
	AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[ProcessSyncMessages]
GO

CREATE PROCEDURE [dbo].[ProcessSyncMessages]
AS
SET NOCOUNT ON
	DECLARE @conversation_handle UNIQUEIDENTIFIER
	DECLARE @message_type_name NVARCHAR(256)
	DECLARE	@message_body XML
	DECLARE @responsemessage XML;

	WHILE (1=1)
	BEGIN
		BEGIN TRY
			BEGIN TRANSACTION

			WAITFOR
				(
				RECEIVE TOP (1)
					@conversation_handle	= conversation_handle,
					@message_body		= CAST(message_body AS XML),
					@message_type_name	= message_type_name
				FROM	[sb_queue_Steelers_Wolfpack]
				), TIMEOUT 5000	

			IF (@@ROWCOUNT = 0)
			BEGIN
				ROLLBACK TRANSACTION
				BREAK
			END
			
			INSERT INTO [dbo].[BrokerMessages] (ch, messagetypename, messagebody)
			VALUES (@conversation_handle, @message_type_name, @message_body);

			-- End the conversation
			END CONVERSATION @conversation_handle;


			exec	uspProcessBMRoster

			COMMIT TRANSACTION
		END TRY
		BEGIN CATCH
				
			ROLLBACK TRANSACTION

			INSERT INTO dbo.ErrorLog (ErrorTime, UserName, ErrorNumber, ErrorSeverity,
				ErrorState, ErrorProcedure, ErrorLine, ErrorMessage)
			VALUES (getdate(), USER_NAME(), ERROR_NUMBER(), ERROR_SEVERITY(),
				ERROR_STATE(), ERROR_PROCEDURE(), ERROR_LINE(), ERROR_MESSAGE())

			END CONVERSATION @conversation_handle;
			
			INSERT INTO [dbo].[BrokerMessages] (ch, messagetypename, messagebody)
			VALUES (@conversation_handle, @message_type_name, @message_body);

		END CATCH
	END
GO