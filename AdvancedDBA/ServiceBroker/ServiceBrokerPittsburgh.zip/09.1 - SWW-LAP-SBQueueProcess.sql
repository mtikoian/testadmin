USE PittsburghSteelers
GO

ALTER QUEUE sb_queue_Steelers_Alpha
WITH ACTIVATION
(
	STATUS = ON,
	PROCEDURE_NAME = [dbo].[PittsburghSteelers_sb_queue_Steelers_Alpha],
	MAX_QUEUE_READERS = 1,
	EXECUTE AS 'WR02_WOLFPACK_User'
)
GO
GRANT EXECUTE ON dbo.PittsburghSteelers_sb_queue_Steelers_Alpha to WR02_WOLFPACK_User
GO
