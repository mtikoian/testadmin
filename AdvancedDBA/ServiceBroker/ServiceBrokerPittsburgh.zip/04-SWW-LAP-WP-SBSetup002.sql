USE PittsburghSteelers
GO
/**********************************************************************
**  simulate user from WAREWOLF_WOLFPACK(Instance 2)
**********************************************************************/
create USER WR01_ALPHA_User WITHOUT LOGIN;
/**********************************************************************
**  restore certificate from WAREWOLF_WOLFPACK(Instance 2)
**********************************************************************/
CREATE CERTIFICATE WR01_ALPHA_Certificate
AUTHORIZATION WR01_ALPHA_User
FROM FILE =
N'C:\Users\sqlwarewolf\Google Drive\Presentations\ServiceBroker\ServiceBrokerPittsburgh\WR01_ALPHA_Certificate.cer';
GO

/**********************************************************************
**  create route to WAREWOLF_WOLFPACK(Instance 2)
**********************************************************************/
CREATE ROUTE sb_route_Steelers_Alpha 
AUTHORIZATION dbo 
WITH 
     SERVICE_NAME = N'sb_srvc_Steelers_Alpha',
     ADDRESS = N'TCP://localhost:4022'
GO
/**********************************************************************
**  create route to WAREWOLF_ALPHA(Instance 1)
**********************************************************************/
USE msdb;
GO
if	exists(select 1 from sys.routes where name = 'sb_route_Steelers_Wolfpack')
drop	route sb_route_Steelers_Wolfpack
go
CREATE ROUTE sb_route_Steelers_Wolfpack 
AUTHORIZATION dbo 
WITH 
     SERVICE_NAME = N'sb_srvc_Steelers_Wolfpack',
     ADDRESS = N'LOCAL'
GO
/**********************************************************************
**  create service binding to WAREWOLF_ALPHA(Instance 1)
**********************************************************************/
USE PittsburghSteelers
GO

CREATE REMOTE SERVICE BINDING [WR01_ALPHA_Binding] 
  AUTHORIZATION dbo 
  TO SERVICE N'sb_srvc_Steelers_Alpha'
  WITH USER = [WR01_ALPHA_User]
GO

GRANT SEND
      ON SERVICE::[sb_srvc_Steelers_Wolfpack]
      TO WR01_ALPHA_User;
GO
