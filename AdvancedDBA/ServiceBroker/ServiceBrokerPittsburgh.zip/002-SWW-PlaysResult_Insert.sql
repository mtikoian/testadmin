use	PittsburghSteelers
go
if	object_id('PlayScript', 'U') is not null
	drop	table PlayScript
go

create	table PlayScript
	(
	PlayID		int		,
	PlayDescription	varchar(512)	,
	PlayResult	varchar(512)
	)


insert	into PlayScript(PlayID, PlayDescription, PlayResult)
select	1, 'Bootleg', '1st and 10 at Steeler''s 20.  <1> fakes the handoff to <2> and throws to <3> for 6 yards'
union
select	2, 'Off tackle', '2nd and 4 at Steeler''s 26. <1> hands off to <2> who runs for 5 yards to the 31.  First Down'
union
select	3, 'Slant', '1st and 10 at Steeler''s 31. <1> throws to <3> on the slant route.  Broken up by the Bengals defense.'
union
select	4, 'Counter Left', '2nd and 10 at Steeler''s 31. <1> hands off to <2> on the counter.  <2> is stopped in the backfield '+char(13) + char(10) + 'for a 2 yard loss'
union
select	5, 'Flat Route', '3rd and 12 at the Steeler 29. <2> connects with <3> in the flat for 23 yards'
union
select	6, 'Screen', '1st and 10 at the Bengals 48.  <1> throws a screen to <2> who runs out of bounds after a gain of 3 yards'
union
select	7, 'Draw Play', '2nd and 7 at the Bengals 45. <1> hands off to <2> who breaks up the middle for 20 yards'
union
select	8, 'Play Action', '1st and 10 at the Bengals 25. <1> Fakes the handoff to <2>, Drops back, is sacked for a 7 yard loss'
union
select	9, 'Post Route', '2nd and 17 at the Bengals 32. <1> Drops back. Targets <3> at the 10 at the center of the field.  '+char(13) + char(10) + 'Broken up and nearly intercepted by the Bengals.'
union
select	10, 'Corner Route', '3rd and 17 at the Bengals 32.  <1> Drops back.  Surveys the field.  '+char(13) + char(10) + 'Finds <3> in the corner of the endzone for a Steeler TOUCHDOWN'
union
select	11, 'Final', 'Final Score.  34 - 17, Steelers.  #wedey'

