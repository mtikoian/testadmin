USE PittsburghSteelers
GO
/**********************************************************************
**  simulate user from WAREWOLF_WOLFPACK(Instance 2)
**********************************************************************/
CREATE USER WR02_WOLFPACK_User WITHOUT LOGIN;
/**********************************************************************
**  restore certificate from WAREWOLF_WOLFPACK(Instance 2)
**********************************************************************/
CREATE CERTIFICATE WR02Certificate
AUTHORIZATION WR02_WOLFPACK_User
FROM FILE =
N'C:\Users\sqlwarewolf\Google Drive\Presentations\ServiceBroker\ServiceBrokerPittsburgh\WR02_WOLFPACK_Certificate.cer';
GO

/**********************************************************************
**  create route to WAREWOLF_WOLFPACK(Instance 2)
**********************************************************************/
CREATE ROUTE sb_route_Steelers_Wolfpack 
AUTHORIZATION dbo 
WITH 
     SERVICE_NAME = N'sb_srvc_Steelers_Wolfpack',
     ADDRESS = N'TCP://localhost:4023'
GO
/**********************************************************************
**  create route to WAREWOLF_ALPHA(Instance 1)
**********************************************************************/
USE msdb;
GO

if	exists(select 1 from sys.routes where name = 'sb_route_Steelers_Alpha')
	drop	route sb_route_Steelers_Alpha
go
create ROUTE sb_route_Steelers_Alpha 
AUTHORIZATION dbo 
WITH 
     SERVICE_NAME = N'sb_srvc_Steelers_Alpha',
     ADDRESS = N'LOCAL'
GO
/**********************************************************************
**  create service binding to WAREWOLF_ALPHA(Instance 1)
**********************************************************************/
USE PittsburghSteelers
GO
CREATE REMOTE SERVICE BINDING [WR02_WOLFPACK_Binding] 
  AUTHORIZATION dbo 
  TO SERVICE N'sb_srvc_Steelers_Wolfpack'
  WITH USER = [WR02_WOLFPACK_User]
GO
GRANT SEND
ON SERVICE::[sb_srvc_Steelers_Alpha]
TO WR02_WOLFPACK_User;