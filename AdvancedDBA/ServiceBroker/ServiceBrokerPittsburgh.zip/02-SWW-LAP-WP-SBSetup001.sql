USE	PittsburghSteelers
GO

if	exists(select 1 from sys.services where name = 'sb_srvc_Steelers_Wolfpack')
	drop	service [sb_srvc_Steelers_Wolfpack]
go
if	exists(select 1 from sys.service_queues where name = 'sb_queue_Steelers_Wolfpack')
	drop	queue [dbo].[sb_queue_Steelers_Wolfpack]
go
if	exists( select 1 from sys.service_contracts where name = 'sb_contract_Steelers_Sync')
	drop	contract [sb_contract_Steelers_Sync]
go
if	exists(select 1 from sys.service_message_types where name = N'sb_MessageType_Steelers_Roster')
	drop	message type sb_MessageType_Steelers_Roster
go
/**********************************************************************
**  create  master key

DEMO PASSWORD ONLY!!!
MAKE YOURS A STRONG PASSWORD!!!

**********************************************************************/

CREATE	MASTER KEY ENCRYPTION BY PASSWORD = N'PittsburghSteelers';
GO
/**********************************************************************
**  create 01 user.  Login is not necessary
**********************************************************************/
CREATE	USER WR02_WOLFPACK_User WITHOUT LOGIN;
GO
/**********************************************************************
**  create and backup certificate
**********************************************************************/
CREATE	CERTIFICATE WR02_WOLFPACK_Certificate 
	AUTHORIZATION	WR02_WOLFPACK_User
	WITH SUBJECT	= 'WR02 Certificate'	,
	EXPIRY_DATE	= N'12/31/2099'		;

BACKUP	CERTIFICATE WR02_WOLFPACK_Certificate
TO	FILE =
N'C:\Users\sqlwarewolf\Google Drive\Presentations\ServiceBroker\ServiceBrokerPittsburgh\WR02_WOLFPACK_Certificate.cer';
GO
/**********************************************************************
**  enable service broker
**********************************************************************/
USE	[MASTER] 
ALTER	DATABASE PittsburghSteelers SET NEW_BROKER
GO
/**********************************************************************
**  Create message type
**********************************************************************/
USE	PittsburghSteelers
GO

CREATE	MESSAGE TYPE [sb_MessageType_Steelers_Roster] 
AUTHORIZATION dbo 
VALIDATION	= WELL_FORMED_XML
GO


/**********************************************************************
**  Create contract for messages
**********************************************************************/
CREATE	CONTRACT [sb_contract_Steelers_Sync]
	AUTHORIZATION dbo 
	(
	[sb_MessageType_Steelers_Roster]	SENT BY ANY
	)
GO
/**********************************************************************
**  Create queue and service
**********************************************************************/
CREATE	QUEUE sb_queue_Steelers_Wolfpack
WITH 
STATUS		= ON	,
RETENTION	= OFF 
GO

CREATE	SERVICE [sb_srvc_Steelers_Wolfpack] 
AUTHORIZATION WR02_WOLFPACK_User 
ON	QUEUE sb_queue_Steelers_Wolfpack
([sb_contract_Steelers_Sync])
GO

/**********************************************************************
**  Create endpoint
**********************************************************************/
USE	[master];
GO

IF	EXISTS (SELECT * FROM master.sys.endpoints WHERE name = N'WAREWOLF_WOLFPACK_Endpoint')
	DROP ENDPOINT WAREWOLF_WOLFPACK_Endpoint;
GO

CREATE	ENDPOINT WAREWOLF_WOLFPACK_Endpoint
STATE	= STARTED
AS	TCP ( LISTENER_PORT = 4023 )
FOR	SERVICE_BROKER (AUTHENTICATION = WINDOWS );
GO
GRANT	CONNECT ON ENDPOINT::WAREWOLF_WOLFPACK_Endpoint
to	[SQLWAREWOLF-LAP\sqlwarewolf] --SQL Server Service Account
GO
