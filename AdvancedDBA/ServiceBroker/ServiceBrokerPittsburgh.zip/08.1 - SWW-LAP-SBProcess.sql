USE	PittsburghSteelers
go
/****************************************************************************************
** Create procedure for processing replies to the request queue
****************************************************************************************/
if	object_id('PittsburghSteelers_sb_queue_Steelers_Alpha', 'P') is not null
	drop	procedure PittsburghSteelers_sb_queue_Steelers_Alpha
GO
-- 
CREATE PROCEDURE dbo.PittsburghSteelers_sb_queue_Steelers_Alpha
AS
BEGIN
	---------------------------------------------------------------------
	SET NOCOUNT ON;
	set	ansi_warnings on;
 
	DECLARE	@conversation_handle	UNIQUEIDENTIFIER	,
		@message_body		XML			,
		@message_type_name	sysname			,
		@PlayResult		varchar(512)		,
		@rowCount		int			;

	---------------------------------------------------------------------
 

	WHILE	(1=1)
		BEGIN
			BEGIN TRANSACTION;
 
			WAITFOR
				(
				RECEIVE TOP (1)
					@conversation_handle	= conversation_handle		,
					@message_body		= CAST(message_body AS XML)	,
					@message_type_name	= message_type_name
				FROM	[sb_queue_Steelers_Alpha]
				), TIMEOUT 5000;

			set	@rowCount = @@ROWCOUNT


 
			IF	(@rowCount = 0)
				BEGIN

					rollback TRANSACTION	;
					BREAK			;
				END
 
			IF	@message_type_name = N'sb_MessageType_Steelers_Roster'
				BEGIN
					-- If necessary handle the reply message here
					--set	@PlayResult = @message_body.value('(play/playresult)[1]', 'varchar(512)');


					--select	@PlayResult;
					--waitfor delay '00:00:03';
 
					-- Since this is all the work being done, end the conversation to send the EndDialog message
					END	CONVERSATION @conversation_handle;
				END
 
			-- If end dialog message, end the dialog
			ELSE	IF @message_type_name = N'http://schemas.microsoft.com/SQL/ServiceBroker/EndDialog'
				END CONVERSATION @conversation_handle;

 
			-- If error message, log and end conversation
			ELSE	IF @message_type_name = N'http://schemas.microsoft.com/SQL/ServiceBroker/Error'
				END	CONVERSATION @conversation_handle;
 
			COMMIT TRANSACTION;
		END
END
GO
