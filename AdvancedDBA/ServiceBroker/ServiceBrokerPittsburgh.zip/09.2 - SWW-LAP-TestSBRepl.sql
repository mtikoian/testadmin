use	PittsburghSteelers
go
delete	Roster

go
INSERT [dbo].[Roster] ([RosterID], [PlayerNumber], [PlayerLN], [PlayerFN], [PlayerStatus], [PlayerStartDate], [PlayerPosition], [PlayerDepthPosition]) 
VALUES (1, 8, N'Cousins', N'Kirk', N'A', NULL, N'QB', 1)
GO
INSERT [dbo].[Roster] ([RosterID], [PlayerNumber], [PlayerLN], [PlayerFN], [PlayerStatus], [PlayerStartDate], [PlayerPosition], [PlayerDepthPosition]) 
VALUES (2, 46, N'Morris', N'Alred', N'A', NULL, N'RB', 1)
GO
INSERT [dbo].[Roster] ([RosterID], [PlayerNumber], [PlayerLN], [PlayerFN], [PlayerStatus], [PlayerStartDate], [PlayerPosition], [PlayerDepthPosition]) 
VALUES (3, 11, N'Jackson', N'DeSean', N'A', NULL, N'WR', 1)
GO




 


 
  