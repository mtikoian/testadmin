USE	PittsburghSteelers
GO

/**********************************************************************
**  create triggers
**********************************************************************/
IF	OBJECT_ID ('tr_Roster_IUD','TR') IS not null
	DROP TRIGGER tr_Roster_IUD
GO

CREATE	TRIGGER tr_Roster_IUD
	ON  Roster
	FOR INSERT, UPDATE, DELETE
AS 
/**********************************************************************
**  Declare variables
**********************************************************************/
	DECLARE @InitDlgHandle	UNIQUEIDENTIFIER	,
		@ChangeMsg	XML			,
		@ChangeCnt	int			;
/**********************************************************************
**  
**********************************************************************/
	BEGIN TRANSACTION;
/**********************************************************************
**  updated records
**********************************************************************/ 
	select	@ChangeCnt = count(1)
	from	Roster r
		inner join deleted d on r.RosterID = d.RosterID
		INNER JOIN inserted i on r.RosterID = i.RosterID;
	if	(@ChangeCnt > 0)
		BEGIN
			set	@ChangeMsg = 
				(
				SELECT	'U' as [Action]		,
					r.RosterID		,
					r.PlayerNumber		,
					r.PlayerLN		,
					r.PlayerFN		,
					r.PlayerStatus		,
					r.PlayerStartDate	,
					r.PlayerPosition	,
					r.PlayerDepthPosition
				FROM	Roster r
					INNER JOIN inserted i on r.RosterID = i.RosterID
					inner join deleted d on r.RosterID = d.RosterID
				FOR XML RAW, ELEMENTS, ROOT ('Roster')
				);
		END;
/**********************************************************************
**  deleted records
**********************************************************************/ 
	ELSE
		BEGIN
			select	@ChangeCnt = count(1) from deleted;
			
			if	(@ChangeCnt > 0)
				BEGIN
					set	@ChangeMsg =
						(
						SELECT	'D' as [Action]	,
							d.RosterID
						FROM	deleted d
						FOR	XML RAW, ELEMENTS, ROOT ('Roster')
						);
				END;
    
			select	@ChangeCnt = count(1) from inserted
			
			if	(@ChangeCnt > 0)
				BEGIN
					set @ChangeMsg =
						(
						SELECT	'I' as [Action]		,
							r.RosterID		,
							r.PlayerNumber		,
							r.PlayerLN		,
							r.PlayerFN		,
							r.PlayerStatus		,
							r.PlayerStartDate	,
							r.PlayerPosition	,
							r.PlayerDepthPosition
						FROM	Roster r
							INNER JOIN inserted i on r.RosterID = i.RosterID
						FOR XML RAW, ELEMENTS, ROOT ('Roster')
						);
				END;
  
		END;
/**********************************************************************
**  send message
**********************************************************************/
	EXECUTE	dbo.SendBrokerMessage
		@FromService = N'sb_srvc_Steelers_Alpha'		,
		@ToService   = N'sb_srvc_Steelers_Wolfpack'	,
		@Contract    = N'sb_contract_Steelers_Sync'	,
		@MessageType = N'sb_MessageType_Steelers_Roster'	,
		@MessageBody = @ChangeMsg			;

/**********************************************************************
**  Commit transactions
**********************************************************************/
	COMMIT TRANSACTION;
  
GO
