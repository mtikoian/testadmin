use master;

/* NOTES:
	1) This script is provided as-is with no warranty or support and is intended for illustration purposes only. Use it at your own risk!
	2) This script uses Windows Authentication for encryption between servers
*/

-- Setup remote users on local servers (SB2)
use [AdventureWorks2012];
Go

open master key decryption by password = 'Passw0rd!';

create user SB1User without login;
exec sp_addrolemember @rolename = 'db_owner', @membername = SB1User;

create certificate SB1User_Cert
	authorization SB1User
	from file = '\\SBDC\Share\SB1User_cert.cer'
	with
		private key (file = '\\SBDC\Share\SB1User_Cert.pvk',
		decryption by password = 'Passw0rd!');

-- Grant send on the local service to the remote user
grant send on service::[//SB2/DemoService] to SB1User;