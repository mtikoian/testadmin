USE [master]
GO

create master key encryption by password = 'Passw0rd!';

create certificate SBEndpoint_Cert
	from file = '\\SBDC\Share\SBEndpoint_Cert.cer'
	with
		private key (file = '\\SBDC\Share\SBEndpoint_Cert.pvk',
		decryption by password = 'Passw0rd!');
Go

DROP ENDPOINT [SBEndpoint];
GO

CREATE ENDPOINT SBEndpoint
	authorization sa
	STATE = STARTED
	AS TCP (LISTENER_PORT = 4022)
	FOR SERVICE_BROKER (AUTHENTICATION = CERTIFICATE SBEndpoint_Cert);
Go