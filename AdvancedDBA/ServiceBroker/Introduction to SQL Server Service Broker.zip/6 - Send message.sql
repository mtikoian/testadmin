use AdventureWorks2012;

declare @message xml = (
	select *
	from sales.currency
	for xml path('row'), type, root('Currency')
);

declare @ConversationHandle uniqueidentifier;

begin dialog @ConversationHandle
	from service [//SB1/DemoService]
	to service N'//SB2/DemoService'
	on contract [DemoContract]
	with encryption = on;

send on conversation @ConversationHandle
	message type DemoMessageType
	(@Message);

end conversation @ConversationHandle;