USE [master]
GO

create master key encryption by password = 'Passw0rd!';

create certificate SBEndpoint_Cert
	with subject = 'Certificate for Service Broker Endpoint',
	expiry_date = '12/31/2099';

backup certificate SBEndpoint_Cert
	to file = '\\SBDC\Share\SBEndpoint_Cert.cer'
	with
		private key (file = '\\SBDC\Share\SBEndpoint_Cert.pvk',
		encryption by password = 'Passw0rd!');
Go

DROP ENDPOINT [SBEndpoint];
GO

CREATE ENDPOINT SBEndpoint
	authorization sa
	STATE = STARTED
	AS TCP (LISTENER_PORT = 4022)
	FOR SERVICE_BROKER (AUTHENTICATION = CERTIFICATE SBEndpoint_Cert);
Go