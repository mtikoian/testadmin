-- Make sure to switch to SQLCMD mode

-- Copy the AdventureWorks2012 mdf file into each SQL server's data directory
!!copy "\\vmware-host\Shared Folders\Demos\AdventureWorks2012_Data.mdf" "\\SB1\C$\Program Files\Microsoft SQL Server\MSSQL11.MSSQLSERVER\MSSQL\DATA"
!!copy "\\vmware-host\Shared Folders\Demos\AdventureWorks2012_Data.mdf" "\\SB2\C$\Program Files\Microsoft SQL Server\MSSQL11.MSSQLSERVER\MSSQL\DATA"

-- Attach the AdventureWorks2012 database on each server

:connect SB1

CREATE DATABASE [AdventureWorks2012]
	ON (FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL11.MSSQLSERVER\MSSQL\DATA\AdventureWorks2012_Data.mdf')
	FOR ATTACH;
GO

:connect SB2

CREATE DATABASE [AdventureWorks2012]
	ON (FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL11.MSSQLSERVER\MSSQL\DATA\AdventureWorks2012_Data.mdf')
	FOR ATTACH;
GO