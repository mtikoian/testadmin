use AdventureWorks2012;

declare @ConversationHandle uniqueidentifier, @service_name nvarchar(512), @service_contract_name nvarchar(256), @message_type_name nvarchar(256), @message_body XML

-- Receive the next message from the queue
waitfor (
	Receive Top (1)
		@ConversationHandle = conversation_handle,
		@service_name = service_name,
		@service_contract_name = service_contract_name,
		@message_type_name = message_type_name,
		@message_body = cast(message_body as XML)
	From DemoQueue
), timeout 1000;

-- Handle end conversation request from far service
if @ConversationHandle is not null
	begin
		if exists(select top 1 * from sys.conversation_endpoints where conversation_handle = @ConversationHandle and state_desc = 'DISCONNECTED_INBOUND' and @message_body is null)
			begin
				end conversation @ConversationHandle;
			end;
	end;

-- Do something with the message received
select @message_body message_body, @ConversationHandle ConversationHandle;