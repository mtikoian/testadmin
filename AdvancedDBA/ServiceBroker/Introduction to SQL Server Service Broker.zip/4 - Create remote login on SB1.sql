use master;

/* NOTES:
	1) This script is provided as-is with no warranty or support and is intended for illustration purposes only. Use it at your own risk!
	2) This script uses Windows Authentication for encryption between servers
*/

-- Setup remote users on local servers (SB1)
use [AdventureWorks2012];
Go

open master key decryption by password = 'Passw0rd!';

create user SB2User without login;
exec sp_addrolemember @rolename = 'db_owner', @membername = SB2User;

create certificate SB2User_Cert
	authorization SB2User
	from file = '\\SBDC\Share\SB2User_cert.cer'
	with
		private key (file = '\\SBDC\Share\SB2User_Cert.pvk',
		decryption by password = 'Passw0rd!');

-- Grant send on the local service to the remote user
grant send on service::[//SB1/DemoService] to SB2User;