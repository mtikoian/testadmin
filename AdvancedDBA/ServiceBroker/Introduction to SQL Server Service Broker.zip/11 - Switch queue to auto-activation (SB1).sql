use AdventureWorks2012;
go

create table BrokerMessages (Message XML, DateReceived DateTime);

go
create proc dbo.DemoQueue_Receive
as
begin
	declare @ConversationHandle uniqueidentifier, @service_name nvarchar(512), @service_contract_name nvarchar(256), @message_type_name nvarchar(256), @message_body XML

	-- Receive the next message from the queue
	waitfor (
		Receive Top (1)
			@ConversationHandle = conversation_handle,
			@service_name = service_name,
			@service_contract_name = service_contract_name,
			@message_type_name = message_type_name,
			@message_body = cast(message_body as XML)
		From DemoQueue
	), timeout 1000;

	-- Handle end conversation request from far service
	if @ConversationHandle is not null
		begin
			if exists(select top 1 * from sys.conversation_endpoints where conversation_handle = @ConversationHandle and state_desc = 'DISCONNECTED_INBOUND' and @message_body is null)
				begin
					end conversation @ConversationHandle;
				end;
			else
				begin
					-- Log that the message was received
					insert BrokerMessages (Message, DateReceived)
					values (@message_body, getdate());
				end;
		end;
end;
go

alter queue DemoQueue With
	Status = ON,
	Retention = OFF,
	Activation (
		PROCEDURE_NAME = dbo.DemoQueue_Receive,
		MAX_QUEUE_READERS = 1,
		Execute AS 'SB1User',
		Status = ON
	);