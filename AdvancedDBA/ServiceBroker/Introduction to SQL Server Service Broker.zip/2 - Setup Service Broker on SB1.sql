use master;

/* NOTES:
	1) This script is provided as-is with no warranty or support and is intended for illustration purposes only. Use it at your own risk!
	2) This script uses Windows Authentication for encryption between servers
*/

-- Setup SB1
-- Enable Service Broker
use master;
go
alter database [AdventureWorks2012] set new_broker;
Go

use [AdventureWorks2012];
Go

-- Create a database master key for encryption (you should also back this up)
create master key encryption by password = 'Passw0rd!';

-- Create local login & user (you only have to create the login if you want Service Broker to be able to interact with
-- other databases in the instance. Otherwise, just create a database user without login.
create login SB1User with password = 'Passw0rd!', SID = 0xdb715669c47b794fb67ba91f819f422a;

create user SB1User for login SB1User;
exec sp_addrolemember @rolename = 'db_owner', @membername = 'SB1User';

create certificate SB1User_Cert
	authorization SB1User
	with subject = 'Certificate for SQL user SB1User',
	expiry_date = '12/31/2099';

backup certificate SB1User_Cert
	to file = '\\SBDC\Share\SB1User_cert.cer'
	with
		private key (file = '\\SBDC\Share\SB1User_cert.pvk',
		encryption by password = 'Passw0rd!');

-- Create a message type and contract to define how Service Broker communicates
CREATE MESSAGE TYPE DemoMessageType
	Authorization dbo
	Validation = WELL_FORMED_XML;

CREATE CONTRACT DemoContract
	Authorization dbo
	(DemoMessageType SENT BY ANY);

-- Create a queue that inbound messages will be stored in until processed
CREATE QUEUE DemoQueue
	With
		Status = ON,
		Retention = OFF;

-- Create a service that Service Broker will use to send and receive messages
CREATE SERVICE [//SB1/DemoService]
		authorization [SB1User]
		ON QUEUE DemoQueue
		([DemoContract]);

-- Create a route to the remote server's services
CREATE ROUTE DemoService_Send
	AUTHORIZATION dbo
	WITH
		SERVICE_NAME=N'//SB2/DemoService',
		ADDRESS=N'TCP://SB2:4022';

-- Create a remote service binding to let Service Broker know what external service goes with the route we just created
create remote service binding [DemoService_Send]
		Authorization dbo
		To Service N'//SB2/DemoService'
		with user = [SB1User];

-- Create a route for incoming messages
Use msdb;

CREATE ROUTE DemoService_Receive
		AUTHORIZATION dbo
		WITH
			SERVICE_NAME=N'//SB1/DemoService',
			ADDRESS=N'LOCAL';

-- Create a TCP endpoint for Service Broker to receive messages on
Go
CREATE ENDPOINT SBEndpoint
	authorization sa
	STATE = STARTED
	AS TCP (LISTENER_PORT = 4022)
	FOR SERVICE_BROKER (AUTHENTICATION = WINDOWS);
Go

use master;
go
grant connect on endpoint::SBEndpoint to [SQLDiablo\SQLService];
Go