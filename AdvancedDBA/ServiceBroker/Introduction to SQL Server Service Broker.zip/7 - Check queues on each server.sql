use AdventureWorks2012;

-- Local queue status
select * from sys.service_queues sq left join sys.dm_broker_queue_monitors dbqm on dbqm.queue_id = sq.object_id where sq.name = 'DemoQueue';

-- Established conversations
select * from sys.conversation_endpoints;

-- Messages received and in the queue
select *, cast(message_body as xml) MessageBodyXml from DemoQueue with (nolock);

-- Messages sent and still in the transmission queue
select *, cast(message_body as xml) MessageBodyXml from sys.transmission_queue with (nolock);