USE AdventureWorks
GO

ALTER QUEUE ETLProcessQueue
	WITH ACTIVATION (DROP)
GO

-- create a queue to host the notification service
CREATE QUEUE ETLNotificationQueue
GO

-- create event notification service
CREATE SERVICE ETLNotificationService
      ON QUEUE ETLNotificationQueue
      (
            [http://schemas.microsoft.com/SQL/Notifications/PostEventNotification]
      )
GO

CREATE EVENT NOTIFICATION ETLEventNotification
ON QUEUE ETLProcessQueue
FOR QUEUE_ACTIVATION
TO SERVICE 'ETLNotificationService' , 'current database'
GO

USE [AdventureWorks]
GO

UPDATE [Person].[Contact]
   SET [NameStyle] = 1
 WHERE ContactID < 6
GO

