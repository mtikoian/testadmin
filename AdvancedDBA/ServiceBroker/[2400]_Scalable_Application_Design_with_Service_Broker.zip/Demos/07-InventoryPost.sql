USE AdventureWorks
GO

CREATE MESSAGE TYPE [//Inventory/CountRec] 
AUTHORIZATION dbo 
VALIDATION = WELL_FORMED_XML
GO

CREATE CONTRACT [//Inventory/CountContract]
    AUTHORIZATION dbo 
    ( [//Inventory/CountRec] SENT BY ANY
    )
GO

CREATE QUEUE InvQueue
   WITH 
   STATUS = ON,
   RETENTION = OFF 
GO

CREATE SERVICE [//Inventory/CountService] 
AUTHORIZATION ETLUser 
ON QUEUE InvQueue
([//Inventory/CountContract])
GO

CREATE QUEUE InvProcessQueue
   WITH 
   STATUS = ON,
   RETENTION = OFF 
GO

CREATE SERVICE [//Inventory/InvProcessSvc] 
AUTHORIZATION ETLUser 
ON QUEUE InvProcessQueue
([//Inventory/CountContract])
GO

IF OBJECT_ID ('dbo.StartInvConversation','P') IS NOT NULL
   DROP PROCEDURE dbo.StartInvConversation
GO
CREATE PROC [dbo].[StartInvConversation]
AS
SET NOCOUNT ON;

    DECLARE @ch UNIQUEIDENTIFIER;
    DECLARE @service_name nvarchar(512) = N'//Inventory/InvProcessSvc';
    
    SELECT @ch=[ch]
    FROM [dbo].[BrokerConversation]
    WHERE [service_name] = @service_name;
    
    IF @ch IS NOT NULL
        BEGIN
        DELETE FROM [dbo].[BrokerConversation]
        WHERE [service_name] = @service_name;
        
        END CONVERSATION @ch;
        END

    BEGIN DIALOG @ch
       FROM SERVICE [//Inventory/CountService]
       TO SERVICE N'//Inventory/InvProcessSvc'
       ON CONTRACT [//Inventory/CountContract]
       WITH
           ENCRYPTION = ON;

    INSERT INTO [dbo].[BrokerConversation]
        (ch, service_name)
    VALUES (@ch, @service_name);

GO

USE AdventureWorks
GO

CREATE TABLE dbo.InvCount(
	[ProductNumber] [varchar](25) NULL,
	[ProductCount] [int] NULL
	)
GO

CREATE PROCEDURE [dbo].[ProcessCount]
AS
SET NOCOUNT ON
	DECLARE @ch UNIQUEIDENTIFIER
	DECLARE @messagetypename NVARCHAR(256)
	DECLARE	@messagebody XML
	DECLARE @responsemessage XML;

	WHILE (1=1)
	BEGIN
		BEGIN TRY
			BEGIN TRANSACTION

			WAITFOR (
				RECEIVE TOP(1)
					@ch = conversation_handle,
					@messagetypename = message_type_name,
					@messagebody = CAST(message_body AS XML)
				FROM InvProcessQueue
			), TIMEOUT 5000

			IF (@@ROWCOUNT = 0)
			BEGIN
				ROLLBACK TRANSACTION
				BREAK
			END
			
			INSERT INTO dbo.InvCount ([ProductNumber],[ProductCount])
			SELECT
				a.value(N'(./ProductNumber/text())[1]', N'NVarChar(20)') as [ProductNumber],
				a.value(N'(./ProductCount/text())[1]', N'int') as [ProductCount]
			from @messagebody.nodes('/Inventory/row') as r(a)
			option (optimize for (@messagebody = NULL));
			
			-- End the conversation
			COMMIT TRANSACTION
		END TRY
		BEGIN CATCH
				
			ROLLBACK TRANSACTION

			INSERT INTO dbo.ErrorLog (ErrorTime, UserName, ErrorNumber, ErrorSeverity,
				ErrorState, ErrorProcedure, ErrorLine, ErrorMessage)
			VALUES (getdate(), USER_NAME(), ERROR_NUMBER(), ERROR_SEVERITY(),
				ERROR_STATE(), ERROR_PROCEDURE(), ERROR_LINE(), ERROR_MESSAGE())

		END CATCH
	END
GO

ALTER QUEUE InvProcessQueue
WITH ACTIVATION
(
	STATUS = ON,
	PROCEDURE_NAME = [dbo].[ProcessCount],
	MAX_QUEUE_READERS = 1,
	EXECUTE AS 'ETLUser'
)
GO
GRANT EXECUTE ON dbo.ProcessCount to ETLUser
GO
