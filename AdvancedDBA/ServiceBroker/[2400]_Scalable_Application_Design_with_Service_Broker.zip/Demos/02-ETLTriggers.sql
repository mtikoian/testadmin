USE AdventureWorks
GO

IF OBJECT_ID ('dbo.BrokerConversation','U') IS NOT NULL
   DROP TABLE dbo.BrokerConversation
GO
CREATE TABLE [dbo].[BrokerConversation]
(
[ch] [uniqueidentifier] NULL,
[service_name] [nvarchar] (512) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]
GO


IF OBJECT_ID ('dbo.StartETLConversation','P') IS NOT NULL
   DROP PROCEDURE dbo.StartETLConversation
GO
CREATE PROC [dbo].[StartETLConversation]
AS
SET NOCOUNT ON;

    DECLARE @ch UNIQUEIDENTIFIER;
    DECLARE @service_name nvarchar(512) = N'//WhseETL/ETLProcessSvc';
    
    SELECT @ch=[ch]
    FROM [dbo].[BrokerConversation]
    WHERE [service_name] = @service_name;
    
    IF @ch IS NOT NULL
        BEGIN
        DELETE FROM [dbo].[BrokerConversation]
        WHERE [service_name] = @service_name;
        
        END CONVERSATION @ch;
        END

    BEGIN DIALOG @ch
       FROM SERVICE [//WhseETL/ETLService]
       TO SERVICE N'//WhseETL/ETLProcessSvc'
       ON CONTRACT [//WhseETL/ETLContract]
       WITH
           ENCRYPTION = ON;

    INSERT INTO [dbo].[BrokerConversation]
        (ch, service_name)
    VALUES (@ch, @service_name);

GO


IF OBJECT_ID ('Sales.trETLCustomer','TR') IS NOT NULL
   DROP TRIGGER Sales.trETLCustomer
GO

CREATE TRIGGER Sales.trETLCustomer
   ON  [Sales].[Customer]
   FOR INSERT, UPDATE, DELETE
AS 

  DECLARE @InitDlgHandle UNIQUEIDENTIFIER;
  DECLARE @ChangeMsg XML;
  DECLARE @ChangeCnt int;
    DECLARE @service_name nvarchar(512) = N'//WhseETL/ETLProcessSvc';
    
    SELECT @InitDlgHandle=[ch]
    FROM [dbo].[BrokerConversation]
    WHERE [service_name] = @service_name;
  
  BEGIN TRY
      
      set @ChangeMsg = (
        SELECT c.[AccountNumber]
          FROM [Sales].[Customer] c
        INNER JOIN inserted i on c.[AccountNumber] = i.[AccountNumber]
        FOR XML RAW, ELEMENTS, ROOT ('Customer')
        );
      
      BEGIN TRANSACTION;

      SEND ON CONVERSATION @InitDlgHandle
           MESSAGE TYPE [//WhseETL/Customer]
           (@ChangeMsg);

      COMMIT TRANSACTION;

  END TRY
  BEGIN CATCH

    INSERT INTO dbo.ErrorLog (ErrorTime, UserName, ErrorNumber, ErrorSeverity,
        ErrorState, ErrorProcedure, ErrorLine, ErrorMessage)
    VALUES (getdate(), USER_NAME(), ERROR_NUMBER(), ERROR_SEVERITY(),
        ERROR_STATE(), ERROR_PROCEDURE(), ERROR_LINE(), ERROR_MESSAGE())
  
  END CATCH
  
GO


IF OBJECT_ID ('Production.trETLProduct','TR') IS NOT NULL
   DROP TRIGGER Production.trETLProduct
GO

CREATE TRIGGER Production.trETLProduct
   ON  [Production].[Product]
   FOR INSERT, UPDATE, DELETE
AS 

  DECLARE @InitDlgHandle UNIQUEIDENTIFIER;
  DECLARE @ChangeMsg XML;
  DECLARE @ChangeCnt int;
    DECLARE @service_name nvarchar(512) = N'//WhseETL/ETLProcessSvc';
    
    SELECT @InitDlgHandle=[ch]
    FROM [dbo].[BrokerConversation]
    WHERE [service_name] = @service_name;
  
  BEGIN TRY
      
      set @ChangeMsg = (
        SELECT c.[ProductNumber]
          FROM [Production].[Product] c
        INNER JOIN inserted i on c.[ProductNumber] = i.[ProductNumber]
        FOR XML RAW, ELEMENTS, ROOT ('Product')
        );
      
      BEGIN TRANSACTION;

      SEND ON CONVERSATION @InitDlgHandle
           MESSAGE TYPE [//WhseETL/Product]
           (@ChangeMsg);

      COMMIT TRANSACTION;

  END TRY
  BEGIN CATCH

    INSERT INTO dbo.ErrorLog (ErrorTime, UserName, ErrorNumber, ErrorSeverity,
        ErrorState, ErrorProcedure, ErrorLine, ErrorMessage)
    VALUES (getdate(), USER_NAME(), ERROR_NUMBER(), ERROR_SEVERITY(),
        ERROR_STATE(), ERROR_PROCEDURE(), ERROR_LINE(), ERROR_MESSAGE())
  
  END CATCH
  
GO

IF OBJECT_ID ('Person.trETLContact','TR') IS NOT NULL
   DROP TRIGGER Person.trETLContact
GO

CREATE TRIGGER Person.trETLContact
   ON  [Person].[Contact]
   FOR INSERT, UPDATE, DELETE
AS 

  DECLARE @InitDlgHandle UNIQUEIDENTIFIER;
  DECLARE @ChangeMsg XML;
  DECLARE @ChangeCnt int;
    DECLARE @service_name nvarchar(512) = N'//WhseETL/ETLProcessSvc';
    
    SELECT @InitDlgHandle=[ch]
    FROM [dbo].[BrokerConversation]
    WHERE [service_name] = @service_name;
  
  BEGIN TRY
      
      set @ChangeMsg = (
        SELECT SUBSTRING(c.[EmailAddress],1,(CHARINDEX('@',c.[EmailAddress],1) - 1)) AS UserID
	      ,c.[FirstName]
	      ,c.[LastName]
	      ,c.[EmailAddress]
	      ,c.[Phone]
	    FROM [Person].[Contact] c
        INNER JOIN inserted i on c.[ContactID] = i.[ContactID]
        FOR XML RAW, ELEMENTS, ROOT ('Contact')
        );
      
      BEGIN TRANSACTION;

      SEND ON CONVERSATION @InitDlgHandle
           MESSAGE TYPE [//WhseETL/Contact]
           (@ChangeMsg);

      COMMIT TRANSACTION;

  END TRY
  BEGIN CATCH

    INSERT INTO dbo.ErrorLog (ErrorTime, UserName, ErrorNumber, ErrorSeverity,
        ErrorState, ErrorProcedure, ErrorLine, ErrorMessage)
    VALUES (getdate(), USER_NAME(), ERROR_NUMBER(), ERROR_SEVERITY(),
        ERROR_STATE(), ERROR_PROCEDURE(), ERROR_LINE(), ERROR_MESSAGE())
  
  END CATCH
  
GO

