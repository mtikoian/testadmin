USE [AdventureWorks]
GO

UPDATE [Person].[Contact]
   SET [NameStyle] = 1
 WHERE ContactID < 6
GO


