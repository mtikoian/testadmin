USE Northwind
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ProcessCategories]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[ProcessCategories]
GO

CREATE PROCEDURE [dbo].[ProcessCategories]
	@messagebody XML
WITH EXECUTE AS 'INST01User'
AS
  SET NOCOUNT ON
  BEGIN TRY
  CREATE TABLE #dbo_Categories (
	[Action] nchar(1) NULL,
	[CategoryID]  Int NULL,
	[CategoryName]  NVarChar(15) NULL,
	[CategoryDescription]  NVarChar(250) NULL
	)
  INSERT INTO #dbo_Categories
  SELECT
	a.value(N'(./Action)[1]', N'nchar(1)') as [Action],
	a.value(N'(./CategoryID)[1]', N'Int') as [CategoryID],
	a.value(N'(./CategoryName)[1]', N'NVarChar(15)') as [CategoryName],
	a.value(N'(./CategoryDescription)[1]', N'NVarChar(250)') as [CategoryDescription]
	from @messagebody.nodes('/NorthWind/row') as r(a);

  -- Delete the existing rows for the incoming changes, then insert the ones that aren't deletes

  DELETE cs
  FROM [dbo].[Categories] cs
  INNER JOIN #dbo_Categories t ON
	cs.[CategoryID] = t.[CategoryID]

  DELETE
  FROM #dbo_Categories
  WHERE [Action] = 'D'

  SET IDENTITY_INSERT [dbo].[Categories] ON
  INSERT INTO [dbo].[Categories] (
	[CategoryID],
	[CategoryName],
	[CategoryDescription]
	)
  SELECT 
	[CategoryID],
	[CategoryName],
	[CategoryDescription]
  FROM #dbo_Categories
  SET IDENTITY_INSERT [dbo].[Categories] OFF

  END TRY

  BEGIN CATCH
    -- Insert any errors into the ErrorLog table for later review and correction
    INSERT INTO dbo.ErrorLog (ErrorTime, UserName, ErrorNumber, ErrorSeverity,
    	ErrorState, ErrorProcedure, ErrorLine, ErrorMessage, MessageBody)
    VALUES (getdate(), USER_NAME(), ERROR_NUMBER(), ERROR_SEVERITY(),
    	ERROR_STATE(), ERROR_PROCEDURE(), ERROR_LINE(), ERROR_MESSAGE(), @messagebody)
  
  END CATCH

  RETURN

GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ProcessCustomers]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[ProcessCustomers]
GO

CREATE PROCEDURE [dbo].[ProcessCustomers]
	@messagebody XML
WITH EXECUTE AS 'INST01User'
AS
  SET NOCOUNT ON
  BEGIN TRY
  CREATE TABLE #dbo_Customers (
	[Action] nchar(1) NULL,
	[CustomerID]  NChar(5) NULL,
	[CompanyName]  NVarChar(40) NULL,
	[ContactName]  NVarChar(30) NULL,
	[ContactTitle]  NVarChar(30) NULL,
	[Address]  NVarChar(60) NULL,
	[City]  NVarChar(15) NULL,
	[Region]  NVarChar(15) NULL,
	[PostalCode]  NVarChar(10) NULL,
	[Country]  NVarChar(15) NULL,
	[Phone]  NVarChar(24) NULL,
	[Fax]  NVarChar(24) NULL
	)
  INSERT INTO #dbo_Customers
  SELECT
	a.value(N'(./Action)[1]', N'nchar(1)') as [Action],
	a.value(N'(./CustomerID)[1]', N'NChar(5)') as [CustomerID],
	a.value(N'(./CompanyName)[1]', N'NVarChar(40)') as [CompanyName],
	a.value(N'(./ContactName)[1]', N'NVarChar(30)') as [ContactName],
	a.value(N'(./ContactTitle)[1]', N'NVarChar(30)') as [ContactTitle],
	a.value(N'(./Address)[1]', N'NVarChar(60)') as [Address],
	a.value(N'(./City)[1]', N'NVarChar(15)') as [City],
	a.value(N'(./Region)[1]', N'NVarChar(15)') as [Region],
	a.value(N'(./PostalCode)[1]', N'NVarChar(10)') as [PostalCode],
	a.value(N'(./Country)[1]', N'NVarChar(15)') as [Country],
	a.value(N'(./Phone)[1]', N'NVarChar(24)') as [Phone],
	a.value(N'(./Fax)[1]', N'NVarChar(24)') as [Fax]
	from @messagebody.nodes('/NorthWind/row') as r(a);

  -- Delete the existing rows for the incoming changes, then insert the ones that aren't deletes

  DELETE cs
  FROM [dbo].[Customers] cs
  INNER JOIN #dbo_Customers t ON
	cs.[CustomerID] = t.[CustomerID]

  DELETE
  FROM #dbo_Customers
  WHERE [Action] = 'D'

  INSERT INTO [dbo].[Customers] (
	[CustomerID],
	[CompanyName],
	[ContactName],
	[ContactTitle],
	[Address],
	[City],
	[Region],
	[PostalCode],
	[Country],
	[Phone],
	[Fax]
	)
  SELECT 
	[CustomerID],
	[CompanyName],
	[ContactName],
	[ContactTitle],
	[Address],
	[City],
	[Region],
	[PostalCode],
	[Country],
	[Phone],
	[Fax]
  FROM #dbo_Customers

  END TRY

  BEGIN CATCH
    -- Insert any errors into the ErrorLog table for later review and correction
    INSERT INTO dbo.ErrorLog (ErrorTime, UserName, ErrorNumber, ErrorSeverity,
    	ErrorState, ErrorProcedure, ErrorLine, ErrorMessage, MessageBody)
    VALUES (getdate(), USER_NAME(), ERROR_NUMBER(), ERROR_SEVERITY(),
    	ERROR_STATE(), ERROR_PROCEDURE(), ERROR_LINE(), ERROR_MESSAGE(), @messagebody)
  
  END CATCH

  RETURN

GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ProcessEmployees]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[ProcessEmployees]
GO

CREATE PROCEDURE [dbo].[ProcessEmployees]
	@messagebody XML
WITH EXECUTE AS 'INST01User'
AS
  SET NOCOUNT ON
  BEGIN TRY
  CREATE TABLE #dbo_Employees (
	[Action] nchar(1) NULL,
	[EmployeeID]  Int NULL,
	[LastName]  NVarChar(20) NULL,
	[FirstName]  NVarChar(10) NULL,
	[Title]  NVarChar(30) NULL,
	[TitleOfCourtesy]  NVarChar(25) NULL,
	[BirthDate]  DateTime NULL,
	[HireDate]  DateTime NULL,
	[Address]  NVarChar(60) NULL,
	[City]  NVarChar(15) NULL,
	[Region]  NVarChar(15) NULL,
	[PostalCode]  NVarChar(10) NULL,
	[Country]  NVarChar(15) NULL,
	[HomePhone]  NVarChar(24) NULL,
	[Extension]  NVarChar(4) NULL
	)
  INSERT INTO #dbo_Employees
  SELECT
	a.value(N'(./Action)[1]', N'nchar(1)') as [Action],
	a.value(N'(./EmployeeID)[1]', N'Int') as [EmployeeID],
	a.value(N'(./LastName)[1]', N'NVarChar(20)') as [LastName],
	a.value(N'(./FirstName)[1]', N'NVarChar(10)') as [FirstName],
	a.value(N'(./Title)[1]', N'NVarChar(30)') as [Title],
	a.value(N'(./TitleOfCourtesy)[1]', N'NVarChar(25)') as [TitleOfCourtesy],
	a.value(N'(./BirthDate)[1]', N'DateTime') as [BirthDate],
	a.value(N'(./HireDate)[1]', N'DateTime') as [HireDate],
	a.value(N'(./Address)[1]', N'NVarChar(60)') as [Address],
	a.value(N'(./City)[1]', N'NVarChar(15)') as [City],
	a.value(N'(./Region)[1]', N'NVarChar(15)') as [Region],
	a.value(N'(./PostalCode)[1]', N'NVarChar(10)') as [PostalCode],
	a.value(N'(./Country)[1]', N'NVarChar(15)') as [Country],
	a.value(N'(./HomePhone)[1]', N'NVarChar(24)') as [HomePhone],
	a.value(N'(./Extension)[1]', N'NVarChar(4)') as [Extension]
	from @messagebody.nodes('/NorthWind/row') as r(a);

  -- Delete the existing rows for the incoming changes, then insert the ones that aren't deletes

  DELETE cs
  FROM [dbo].[Employees] cs
  INNER JOIN #dbo_Employees t ON
	cs.[EmployeeID] = t.[EmployeeID]

  DELETE
  FROM #dbo_Employees
  WHERE [Action] = 'D'

  SET IDENTITY_INSERT [dbo].[Employees] ON
  INSERT INTO [dbo].[Employees] (
	[EmployeeID],
	[LastName],
	[FirstName],
	[Title],
	[TitleOfCourtesy],
	[BirthDate],
	[HireDate],
	[Address],
	[City],
	[Region],
	[PostalCode],
	[Country],
	[HomePhone],
	[Extension]
	)
  SELECT 
	[EmployeeID],
	[LastName],
	[FirstName],
	[Title],
	[TitleOfCourtesy],
	[BirthDate],
	[HireDate],
	[Address],
	[City],
	[Region],
	[PostalCode],
	[Country],
	[HomePhone],
	[Extension]
  FROM #dbo_Employees
  SET IDENTITY_INSERT [dbo].[Employees] OFF

  END TRY

  BEGIN CATCH
    -- Insert any errors into the ErrorLog table for later review and correction
    INSERT INTO dbo.ErrorLog (ErrorTime, UserName, ErrorNumber, ErrorSeverity,
    	ErrorState, ErrorProcedure, ErrorLine, ErrorMessage, MessageBody)
    VALUES (getdate(), USER_NAME(), ERROR_NUMBER(), ERROR_SEVERITY(),
    	ERROR_STATE(), ERROR_PROCEDURE(), ERROR_LINE(), ERROR_MESSAGE(), @messagebody)
  
  END CATCH

  RETURN

GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ProcessOrderDetails]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[ProcessOrderDetails]
GO

CREATE PROCEDURE [dbo].[ProcessOrderDetails]
	@messagebody XML
WITH EXECUTE AS 'INST01User'
AS
  SET NOCOUNT ON
  BEGIN TRY
  CREATE TABLE #dbo_OrderDetails (
	[Action] nchar(1) NULL,
	[OrderDetailID]  Int NULL,
	[OrderID]  Int NULL,
	[ProductID]  Int NULL,
	[UnitPrice]  Money NULL,
	[Quantity]  SmallInt NULL,
	[Discount]  Real NULL
	)
  INSERT INTO #dbo_OrderDetails
  SELECT
	a.value(N'(./Action)[1]', N'nchar(1)') as [Action],
	a.value(N'(./OrderDetailID)[1]', N'Int') as [OrderDetailID],
	a.value(N'(./OrderID)[1]', N'Int') as [OrderID],
	a.value(N'(./ProductID)[1]', N'Int') as [ProductID],
	a.value(N'(./UnitPrice)[1]', N'Money') as [UnitPrice],
	a.value(N'(./Quantity)[1]', N'SmallInt') as [Quantity],
	a.value(N'(./Discount)[1]', N'Real') as [Discount]
	from @messagebody.nodes('/NorthWind/row') as r(a);

  -- Delete the existing rows for the incoming changes, then insert the ones that aren't deletes

  DELETE cs
  FROM [dbo].[OrderDetails] cs
  INNER JOIN #dbo_OrderDetails t ON
	cs.[OrderDetailID] = t.[OrderDetailID]

  DELETE
  FROM #dbo_OrderDetails
  WHERE [Action] = 'D'

  SET IDENTITY_INSERT [dbo].[OrderDetails] ON
  INSERT INTO [dbo].[OrderDetails] (
	[OrderDetailID],
	[OrderID],
	[ProductID],
	[UnitPrice],
	[Quantity],
	[Discount]
	)
  SELECT 
	[OrderDetailID],
	[OrderID],
	[ProductID],
	[UnitPrice],
	[Quantity],
	[Discount]
  FROM #dbo_OrderDetails
  SET IDENTITY_INSERT [dbo].[OrderDetails] OFF

  END TRY

  BEGIN CATCH
    -- Insert any errors into the ErrorLog table for later review and correction
    INSERT INTO dbo.ErrorLog (ErrorTime, UserName, ErrorNumber, ErrorSeverity,
    	ErrorState, ErrorProcedure, ErrorLine, ErrorMessage, MessageBody)
    VALUES (getdate(), USER_NAME(), ERROR_NUMBER(), ERROR_SEVERITY(),
    	ERROR_STATE(), ERROR_PROCEDURE(), ERROR_LINE(), ERROR_MESSAGE(), @messagebody)
  
  END CATCH

  RETURN

GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ProcessOrders]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[ProcessOrders]
GO

CREATE PROCEDURE [dbo].[ProcessOrders]
	@messagebody XML
WITH EXECUTE AS 'INST01User'
AS
  SET NOCOUNT ON
  BEGIN TRY
  CREATE TABLE #dbo_Orders (
	[Action] nchar(1) NULL,
	[OrderID]  Int NULL,
	[CustomerID]  NChar(5) NULL,
	[EmployeeID]  Int NULL,
	[OrderDate]  DateTime NULL,
	[RequiredDate]  DateTime NULL,
	[ShippedDate]  DateTime NULL,
	[ShipVia]  Int NULL,
	[Freight]  Money NULL,
	[ShipName]  NVarChar(40) NULL,
	[ShipAddress]  NVarChar(60) NULL,
	[ShipCity]  NVarChar(15) NULL,
	[ShipRegion]  NVarChar(15) NULL,
	[ShipPostalCode]  NVarChar(10) NULL,
	[ShipCountry]  NVarChar(15) NULL
	)
  INSERT INTO #dbo_Orders
  SELECT
	a.value(N'(./Action)[1]', N'nchar(1)') as [Action],
	a.value(N'(./OrderID)[1]', N'Int') as [OrderID],
	a.value(N'(./CustomerID)[1]', N'NChar(5)') as [CustomerID],
	a.value(N'(./EmployeeID)[1]', N'Int') as [EmployeeID],
	a.value(N'(./OrderDate)[1]', N'DateTime') as [OrderDate],
	a.value(N'(./RequiredDate)[1]', N'DateTime') as [RequiredDate],
	a.value(N'(./ShippedDate)[1]', N'DateTime') as [ShippedDate],
	a.value(N'(./ShipVia)[1]', N'Int') as [ShipVia],
	a.value(N'(./Freight)[1]', N'Money') as [Freight],
	a.value(N'(./ShipName)[1]', N'NVarChar(40)') as [ShipName],
	a.value(N'(./ShipAddress)[1]', N'NVarChar(60)') as [ShipAddress],
	a.value(N'(./ShipCity)[1]', N'NVarChar(15)') as [ShipCity],
	a.value(N'(./ShipRegion)[1]', N'NVarChar(15)') as [ShipRegion],
	a.value(N'(./ShipPostalCode)[1]', N'NVarChar(10)') as [ShipPostalCode],
	a.value(N'(./ShipCountry)[1]', N'NVarChar(15)') as [ShipCountry]
	from @messagebody.nodes('/NorthWind/row') as r(a);

  -- Delete the existing rows for the incoming changes, then insert the ones that aren't deletes

  DELETE cs
  FROM [dbo].[Orders] cs
  INNER JOIN #dbo_Orders t ON
	cs.[OrderID] = t.[OrderID]

  DELETE
  FROM #dbo_Orders
  WHERE [Action] = 'D'

  SET IDENTITY_INSERT [dbo].[Orders] ON
  INSERT INTO [dbo].[Orders] (
	[OrderID],
	[CustomerID],
	[EmployeeID],
	[OrderDate],
	[RequiredDate],
	[ShippedDate],
	[ShipVia],
	[Freight],
	[ShipName],
	[ShipAddress],
	[ShipCity],
	[ShipRegion],
	[ShipPostalCode],
	[ShipCountry]
	)
  SELECT 
	[OrderID],
	[CustomerID],
	[EmployeeID],
	[OrderDate],
	[RequiredDate],
	[ShippedDate],
	[ShipVia],
	[Freight],
	[ShipName],
	[ShipAddress],
	[ShipCity],
	[ShipRegion],
	[ShipPostalCode],
	[ShipCountry]
  FROM #dbo_Orders
  SET IDENTITY_INSERT [dbo].[Orders] OFF

  END TRY

  BEGIN CATCH
    -- Insert any errors into the ErrorLog table for later review and correction
    INSERT INTO dbo.ErrorLog (ErrorTime, UserName, ErrorNumber, ErrorSeverity,
    	ErrorState, ErrorProcedure, ErrorLine, ErrorMessage, MessageBody)
    VALUES (getdate(), USER_NAME(), ERROR_NUMBER(), ERROR_SEVERITY(),
    	ERROR_STATE(), ERROR_PROCEDURE(), ERROR_LINE(), ERROR_MESSAGE(), @messagebody)
  
  END CATCH

  RETURN

GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ProcessProducts]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[ProcessProducts]
GO

CREATE PROCEDURE [dbo].[ProcessProducts]
	@messagebody XML
WITH EXECUTE AS 'INST01User'
AS
  SET NOCOUNT ON
  BEGIN TRY
  CREATE TABLE #dbo_Products (
	[Action] nchar(1) NULL,
	[ProductID]  Int NULL,
	[ProductName]  NVarChar(40) NULL,
	[SupplierID]  Int NULL,
	[CategoryID]  Int NULL,
	[QuantityPerUnit]  NVarChar(20) NULL,
	[UnitPrice]  Money NULL,
	[UnitsInStock]  SmallInt NULL,
	[UnitsOnOrder]  SmallInt NULL,
	[ReorderLevel]  SmallInt NULL,
	[Discontinued]  Bit NULL
	)
  INSERT INTO #dbo_Products
  SELECT
	a.value(N'(./Action)[1]', N'nchar(1)') as [Action],
	a.value(N'(./ProductID)[1]', N'Int') as [ProductID],
	a.value(N'(./ProductName)[1]', N'NVarChar(40)') as [ProductName],
	a.value(N'(./SupplierID)[1]', N'Int') as [SupplierID],
	a.value(N'(./CategoryID)[1]', N'Int') as [CategoryID],
	a.value(N'(./QuantityPerUnit)[1]', N'NVarChar(20)') as [QuantityPerUnit],
	a.value(N'(./UnitPrice)[1]', N'Money') as [UnitPrice],
	a.value(N'(./UnitsInStock)[1]', N'SmallInt') as [UnitsInStock],
	a.value(N'(./UnitsOnOrder)[1]', N'SmallInt') as [UnitsOnOrder],
	a.value(N'(./ReorderLevel)[1]', N'SmallInt') as [ReorderLevel],
	a.value(N'(./Discontinued)[1]', N'Bit') as [Discontinued]
	from @messagebody.nodes('/NorthWind/row') as r(a);

  -- Delete the existing rows for the incoming changes, then insert the ones that aren't deletes

  DELETE cs
  FROM [dbo].[Products] cs
  INNER JOIN #dbo_Products t ON
	cs.[ProductID] = t.[ProductID]

  DELETE
  FROM #dbo_Products
  WHERE [Action] = 'D'

  SET IDENTITY_INSERT [dbo].[Products] ON
  INSERT INTO [dbo].[Products] (
	[ProductID],
	[ProductName],
	[SupplierID],
	[CategoryID],
	[QuantityPerUnit],
	[UnitPrice],
	[UnitsInStock],
	[UnitsOnOrder],
	[ReorderLevel],
	[Discontinued]
	)
  SELECT 
	[ProductID],
	[ProductName],
	[SupplierID],
	[CategoryID],
	[QuantityPerUnit],
	[UnitPrice],
	[UnitsInStock],
	[UnitsOnOrder],
	[ReorderLevel],
	[Discontinued]
  FROM #dbo_Products
  SET IDENTITY_INSERT [dbo].[Products] OFF

  END TRY

  BEGIN CATCH
    -- Insert any errors into the ErrorLog table for later review and correction
    INSERT INTO dbo.ErrorLog (ErrorTime, UserName, ErrorNumber, ErrorSeverity,
    	ErrorState, ErrorProcedure, ErrorLine, ErrorMessage, MessageBody)
    VALUES (getdate(), USER_NAME(), ERROR_NUMBER(), ERROR_SEVERITY(),
    	ERROR_STATE(), ERROR_PROCEDURE(), ERROR_LINE(), ERROR_MESSAGE(), @messagebody)
  
  END CATCH

  RETURN

GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ProcessShippers]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[ProcessShippers]
GO

CREATE PROCEDURE [dbo].[ProcessShippers]
	@messagebody XML
WITH EXECUTE AS 'INST01User'
AS
  SET NOCOUNT ON
  BEGIN TRY
  CREATE TABLE #dbo_Shippers (
	[Action] nchar(1) NULL,
	[ShipperID]  Int NULL,
	[CompanyName]  NVarChar(40) NULL,
	[Phone]  NVarChar(24) NULL
	)
  INSERT INTO #dbo_Shippers
  SELECT
	a.value(N'(./Action)[1]', N'nchar(1)') as [Action],
	a.value(N'(./ShipperID)[1]', N'Int') as [ShipperID],
	a.value(N'(./CompanyName)[1]', N'NVarChar(40)') as [CompanyName],
	a.value(N'(./Phone)[1]', N'NVarChar(24)') as [Phone]
	from @messagebody.nodes('/NorthWind/row') as r(a);

  -- Delete the existing rows for the incoming changes, then insert the ones that aren't deletes

  DELETE cs
  FROM [dbo].[Shippers] cs
  INNER JOIN #dbo_Shippers t ON
	cs.[ShipperID] = t.[ShipperID]

  DELETE
  FROM #dbo_Shippers
  WHERE [Action] = 'D'

  SET IDENTITY_INSERT [dbo].[Shippers] ON
  INSERT INTO [dbo].[Shippers] (
	[ShipperID],
	[CompanyName],
	[Phone]
	)
  SELECT 
	[ShipperID],
	[CompanyName],
	[Phone]
  FROM #dbo_Shippers
  SET IDENTITY_INSERT [dbo].[Shippers] OFF

  END TRY

  BEGIN CATCH
    -- Insert any errors into the ErrorLog table for later review and correction
    INSERT INTO dbo.ErrorLog (ErrorTime, UserName, ErrorNumber, ErrorSeverity,
    	ErrorState, ErrorProcedure, ErrorLine, ErrorMessage, MessageBody)
    VALUES (getdate(), USER_NAME(), ERROR_NUMBER(), ERROR_SEVERITY(),
    	ERROR_STATE(), ERROR_PROCEDURE(), ERROR_LINE(), ERROR_MESSAGE(), @messagebody)
  
  END CATCH

  RETURN

GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ProcessSuppliers]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[ProcessSuppliers]
GO

CREATE PROCEDURE [dbo].[ProcessSuppliers]
	@messagebody XML
WITH EXECUTE AS 'INST01User'
AS
  SET NOCOUNT ON
  BEGIN TRY
  CREATE TABLE #dbo_Suppliers (
	[Action] nchar(1) NULL,
	[SupplierID]  Int NULL,
	[SupplierCompanyName]  NVarChar(40) NULL,
	[SupplierContactName]  NVarChar(30) NULL,
	[SupplierContactTitle]  NVarChar(30) NULL,
	[SupplierAddress]  NVarChar(60) NULL,
	[SupplierCity]  NVarChar(15) NULL,
	[SupplierRegion]  NVarChar(15) NULL,
	[SupplierPostalCode]  NVarChar(10) NULL,
	[SupplierCountry]  NVarChar(15) NULL,
	[Phone]  NVarChar(24) NULL,
	[Fax]  NVarChar(24) NULL
	)
  INSERT INTO #dbo_Suppliers
  SELECT
	a.value(N'(./Action)[1]', N'nchar(1)') as [Action],
	a.value(N'(./SupplierID)[1]', N'Int') as [SupplierID],
	a.value(N'(./SupplierCompanyName)[1]', N'NVarChar(40)') as [SupplierCompanyName],
	a.value(N'(./SupplierContactName)[1]', N'NVarChar(30)') as [SupplierContactName],
	a.value(N'(./SupplierContactTitle)[1]', N'NVarChar(30)') as [SupplierContactTitle],
	a.value(N'(./SupplierAddress)[1]', N'NVarChar(60)') as [SupplierAddress],
	a.value(N'(./SupplierCity)[1]', N'NVarChar(15)') as [SupplierCity],
	a.value(N'(./SupplierRegion)[1]', N'NVarChar(15)') as [SupplierRegion],
	a.value(N'(./SupplierPostalCode)[1]', N'NVarChar(10)') as [SupplierPostalCode],
	a.value(N'(./SupplierCountry)[1]', N'NVarChar(15)') as [SupplierCountry],
	a.value(N'(./Phone)[1]', N'NVarChar(24)') as [Phone],
	a.value(N'(./Fax)[1]', N'NVarChar(24)') as [Fax]
	from @messagebody.nodes('/NorthWind/row') as r(a);

  -- Delete the existing rows for the incoming changes, then insert the ones that aren't deletes

  DELETE cs
  FROM [dbo].[Suppliers] cs
  INNER JOIN #dbo_Suppliers t ON
	cs.[SupplierID] = t.[SupplierID]

  DELETE
  FROM #dbo_Suppliers
  WHERE [Action] = 'D'

  SET IDENTITY_INSERT [dbo].[Suppliers] ON
  INSERT INTO [dbo].[Suppliers] (
	[SupplierID],
	[SupplierCompanyName],
	[SupplierContactName],
	[SupplierContactTitle],
	[SupplierAddress],
	[SupplierCity],
	[SupplierRegion],
	[SupplierPostalCode],
	[SupplierCountry],
	[Phone],
	[Fax]
	)
  SELECT 
	[SupplierID],
	[SupplierCompanyName],
	[SupplierContactName],
	[SupplierContactTitle],
	[SupplierAddress],
	[SupplierCity],
	[SupplierRegion],
	[SupplierPostalCode],
	[SupplierCountry],
	[Phone],
	[Fax]
  FROM #dbo_Suppliers
  SET IDENTITY_INSERT [dbo].[Suppliers] OFF

  END TRY

  BEGIN CATCH
    -- Insert any errors into the ErrorLog table for later review and correction
    INSERT INTO dbo.ErrorLog (ErrorTime, UserName, ErrorNumber, ErrorSeverity,
    	ErrorState, ErrorProcedure, ErrorLine, ErrorMessage, MessageBody)
    VALUES (getdate(), USER_NAME(), ERROR_NUMBER(), ERROR_SEVERITY(),
    	ERROR_STATE(), ERROR_PROCEDURE(), ERROR_LINE(), ERROR_MESSAGE(), @messagebody)
  
  END CATCH

  RETURN

GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ProcessSyncData]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[ProcessSyncData]
GO

CREATE PROCEDURE [dbo].[ProcessSyncData]
AS
SET NOCOUNT ON
    DECLARE @id INT;
    DECLARE @ch UNIQUEIDENTIFIER
    DECLARE @messagetypename NVARCHAR(256)
    DECLARE @messagebody XML
    DECLARE @responsemessage XML;
    DECLARE @returnrows INT;

    WHILE (1=1)
    BEGIN
        BEGIN TRY

            SELECT TOP 1 @id=id, @ch=ch, @messagetypename=messagetypename, @messagebody=messagebody
            FROM [dbo].[BrokerMessages]
            ORDER BY id;
            SELECT @returnrows = @@ROWCOUNT

            IF (@returnrows > 0)
            BEGIN

                -- First extract the name of the table from the top row of the message
                DECLARE @TableName varchar(100);
                DECLARE @ETLTable TABLE (TableName varchar(100));

                INSERT INTO @ETLTable (TableName)
                select TOP 1 a.value(N'(./TableName)[1]', N'varchar(100)') as TableName
                from @messagebody.nodes('//row') as r(a);

                SELECT @TableName = TableName FROM @ETLTable;

                -- Now call the procedure corresponding to the table passed into the message
                IF (@TableName = 'dbo_Categories')
                    BEGIN
                    EXEC [dbo].[ProcessCategories] @messagebody;
                    END
                IF (@TableName = 'dbo_Customers')
                    BEGIN
                    EXEC [dbo].[ProcessCustomers] @messagebody;
                    END
                IF (@TableName = 'dbo_Employees')
                    BEGIN
                    EXEC [dbo].[ProcessEmployees] @messagebody;
                    END
                IF (@TableName = 'dbo_OrderDetails')
                    BEGIN
                    EXEC [dbo].[ProcessOrderDetails] @messagebody;
                    END
                IF (@TableName = 'dbo_Orders')
                    BEGIN
                    EXEC [dbo].[ProcessOrders] @messagebody;
                    END
                IF (@TableName = 'dbo_Products')
                    BEGIN
                    EXEC [dbo].[ProcessProducts] @messagebody;
                    END
                IF (@TableName = 'dbo_Shippers')
                    BEGIN
                    EXEC [dbo].[ProcessShippers] @messagebody;
                    END
                IF (@TableName = 'dbo_Suppliers')
                    BEGIN
                    EXEC [dbo].[ProcessSuppliers] @messagebody;
                    END
                -- Delete the message so it's only processed once
                DELETE FROM [dbo].[BrokerMessages]
                WHERE id = @id;
            END
            ELSE
            BEGIN
                -- If we're out of messages, wait a minute and then check again
                WAITFOR DELAY '00:01:00';
            END

        END TRY
        BEGIN CATCH

            INSERT INTO dbo.ErrorLog (ErrorTime, UserName, ErrorNumber, ErrorSeverity,
                ErrorState, ErrorProcedure, ErrorLine, ErrorMessage, MessageBody)
            VALUES (getdate(), USER_NAME(), ERROR_NUMBER(), ERROR_SEVERITY(),
                ERROR_STATE(), ERROR_PROCEDURE(), ERROR_LINE(), ERROR_MESSAGE(), @messagebody)

        END CATCH
    END
GO


