<#
.Synopsis
   Receives Service Broker Messages from the AdventureWorks ETLProcessQueue.
.DESCRIPTION
   This script will receive Service Broker Messages from the AdventureWorks ETLProcessQueue
   and send the received data into a holding table in the same database.
.EXAMPLE
   ./Receive-ETLProcessMessages.ps1
#>

# Test to see if the SQLPS module is loaded, and if not, load it
if (-not(Get-Module -name 'SQLPS')) {
  if (Get-Module -ListAvailable | Where-Object {$_.Name -eq 'SQLPS' }) {
    Push-Location # The SQLPS module load changes location to the Provider, so save the current location
	Import-Module -Name 'SQLPS' -DisableNameChecking
	Pop-Location # Now go back to the original location
    }
  }

try {
	# Connect to the specified instance
	$cn = new-object System.Data.SqlClient.SqlConnection("Data Source=SQLTBWS\INST01;Integrated Security=SSPI;Initial Catalog=AdventureWorks");

	# Create a SqlCommand object and set its properties
	$cmd = New-Object System.Data.SqlClient.SqlCommand
	$cmd.Connection = $cn
$q = @'
    WAITFOR (
        RECEIVE TOP(1)
            @ch = conversation_handle,
            @service_name = service_name,
            @service_contract_name = service_contract_name,
            @messagetypename = message_type_name,
            @messagebody = CAST(message_body AS XML)
        FROM ETLProcessQueue
    ), TIMEOUT 5000
'@
	$cmd.CommandText = $q
	
	# The Service Broker RECEIVE command takes these output parameters, so define them
	$ch = New-Object System.Data.SqlClient.SqlParameter("@ch",[System.Data.SQLDBType]::UniqueIdentifier);
	$ch.Direction = [System.Data.ParameterDirection]'Output';
	$cmd.Parameters.Add($ch) | Out-Null
	$mtn = New-Object System.Data.SqlClient.SqlParameter("@messagetypename",[System.Data.SQLDBType]::NVarChar, 256);
	$mtn.Direction = [System.Data.ParameterDirection]'Output';
	$cmd.Parameters.Add($mtn) | Out-Null
	$svn = New-Object System.Data.SqlClient.SqlParameter("@service_name",[System.Data.SQLDBType]::NVarChar, 512);
	$svn.Direction = [System.Data.ParameterDirection]'Output';
	$cmd.Parameters.Add($svn) | Out-Null
	$scn = New-Object System.Data.SqlClient.SqlParameter("@service_contract_name",[System.Data.SQLDBType]::NVarChar, 256);
	$scn.Direction = [System.Data.ParameterDirection]'Output';
	$cmd.Parameters.Add($scn) | Out-Null
	$msb = New-Object System.Data.SqlClient.SqlParameter("@messagebody",[System.Data.SQLDBType]::XML);
	$msb.Direction = [System.Data.ParameterDirection]'Output';
	$cmd.Parameters.Add($msb) | Out-Null

	# Open the connection, execute the command, save the @messagebody value and close the connection
	$cn.Open();
	$result = $cmd.ExecuteNonQuery();
	[XML] $msg = $msb.Value;
	$cn.Close();
	
	# While the @messagetypename parameter returns a value, process the message and then execute that command again
	do {
		foreach ($r in $msg.Product.row) {
			# For each row in the Product XML, get the ProductNumber and insert it into the table
			$rpn = $r.ProductNumber;
			$qi = "INSERT INTO dbo.ProductTick([ProductNumber]) VALUES ('$rpn');"
			$cmdi = New-Object System.Data.SqlClient.SqlCommand;
			$cmdi.Connection = $cn;
			$cmdi.CommandText = $qi;
			$cn.Open();
			$result = $cmdi.ExecuteNonQuery();
			$cn.Close();
			}
		
		$cn.Open();
		$result = $cmd.ExecuteNonQuery();
		[XML] $msg = $msb.Value;
		$cn.Close();

		} while ($mtn.Value -ne [System.DBNull]::Value)
	
	}
catch {
	   # Handle the error
	   $err = $_.Exception
	   write-output $err.Message
	   while( $err.InnerException ) {
	   	$err = $err.InnerException
	   	write-output $err.Message
	  	}
	}

