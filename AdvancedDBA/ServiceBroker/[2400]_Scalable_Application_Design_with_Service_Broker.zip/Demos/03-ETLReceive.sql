USE AdventureWorks
GO

-- Start the conversation
EXEC [dbo].[StartETLConversation]
GO

-- Update the Production.Product table
    UPDATE Production.Product
    SET ReorderPoint = 500
    WHERE ProductID < 5;
GO
    UPDATE Production.Product
    SET ReorderPoint = 500
    WHERE ProductID > 315
	AND ProductID < 320 ;
GO

-- Create a place for it
    CREATE TABLE #Product(
	[ProductNumber] [varchar](50) NULL,
	)

-- See that it's there
    SELECT * from ETLProcessQueue
  
-- Now actually receive it
    DECLARE @ch UNIQUEIDENTIFIER
    DECLARE @messagetypename NVARCHAR(256),
        @service_name nvarchar(512),
        @service_contract_name NVARCHAR(256)
    DECLARE @messagebody XML

    WAITFOR (
        RECEIVE TOP(1)
            @ch = conversation_handle,
            @service_name = service_name,
            @service_contract_name = service_contract_name,
            @messagetypename = message_type_name,
            @messagebody = CAST(message_body AS XML)
        FROM ETLProcessQueue
    ), TIMEOUT 60000

    SELECT @messagebody


-- Shred the XML and insert it into the table
    INSERT INTO #Product
    select  a.value(N'(./ProductNumber)[1]', N'varchar(50)') as [ProductNumber]
    from @messagebody.nodes('/Product/row') as r(a);

-- Let's see it's there
    SELECT * FROM #Product;