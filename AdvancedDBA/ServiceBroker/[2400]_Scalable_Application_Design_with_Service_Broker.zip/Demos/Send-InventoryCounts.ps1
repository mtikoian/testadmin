<#
.Synopsis
   Sends Service Broker Messages to the AdventureWorks InvProcessQueue.
.DESCRIPTION
   This script will receive Service Broker Messages from the AdventureWorks ETLProcessQueue
   and send the received data into a holding table in the same database.
.EXAMPLE
   ./Send-InventoryCounts.ps1
#>
param(
	[string] $ProdNo = $null,
	[int] $ProdCnt = $null
)

try {
	# Connect to the specified instance
	$cn = new-object System.Data.SqlClient.SqlConnection("Data Source=SQLTBWS\INST01;Integrated Security=SSPI;Initial Catalog=AdventureWorks");

$q = @"
    SELECT [ch]
    FROM [dbo].[BrokerConversation]
    WHERE [service_name] = '//Inventory/InvProcessSvc';
"@
	
	$ds = new-object "System.Data.DataSet" "dsConvHandle"
	$da = new-object "System.Data.SqlClient.SqlDataAdapter" ($q, $cn)
	$da.Fill($ds)
	$dtHandle = $ds.Tables[0]
	[guid]$ch = $dtHandle[0].ch

	$cmd = New-Object System.Data.SqlClient.SqlCommand
	$cmd.Connection = $cn
$q = @"
      BEGIN TRANSACTION;

      SEND ON CONVERSATION '$ch'
           MESSAGE TYPE [//Inventory/CountRec]
           ('<Inventory><row><ProductNumber>$ProdNo</ProductNumber><ProductCount>$ProdCnt</ProductCount></row></Inventory>');

      COMMIT TRANSACTION;
"@
	$cmd.CommandText = $q

	# Open the connection, execute the command, save the @messagebody value and close the connection
	$cn.Open();
	$result = $cmd.ExecuteNonQuery();
	$cn.Close();
	
	}
catch {
	   # Handle the error
	   $err = $_.Exception
	   write-output $err.Message
	   while( $err.InnerException ) {
	   	$err = $err.InnerException
	   	write-output $err.Message
	  	}
	}

