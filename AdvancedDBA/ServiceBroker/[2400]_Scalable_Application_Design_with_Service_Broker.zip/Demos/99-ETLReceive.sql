USE AdventureWorks
GO

IF OBJECT_ID ('dbo.ProcessETLMessages','P') IS NOT NULL
   DROP PROCEDURE dbo.ProcessETLMessages
GO
CREATE PROCEDURE [dbo].[ProcessETLMessages]
AS
SET NOCOUNT ON
	DECLARE @ch UNIQUEIDENTIFIER
	DECLARE @messagetypename NVARCHAR(256),
		@service_name nvarchar(512),
		@service_contract_name NVARCHAR(256)
	DECLARE	@messagebody XML
	DECLARE @responsemessage XML;

	WHILE (1=1)
	BEGIN
		BEGIN TRY
			BEGIN TRANSACTION

			WAITFOR (
				RECEIVE TOP(1)
					@ch = conversation_handle,
					@service_name = service_name,
					@service_contract_name = service_contract_name,
					@messagetypename = message_type_name,
					@messagebody = CAST(message_body AS XML)
				FROM ETLProcessQueue
			), TIMEOUT 60000

			IF (@@ROWCOUNT = 0)
			BEGIN
				ROLLBACK TRANSACTION
				BREAK
			END
			
			-- If we get an EndDialog message, the conversation on the other side was complete, so end the conversation here, too
			IF @messagetypename = 'http://schemas.microsoft.com/SQL/ServiceBroker/EndDialog'
			BEGIN
				-- End the conversation
				END CONVERSATION @ch;
			END
			ELSE

				IF (@messagetypename = '//WhseETL/Customer')
				BEGIN
					-- Process the message
					EXEC dbo.ProcessCustomer @messagebody
				END
				IF (@messagetypename = '//WhseETL/Product')
				BEGIN
					-- Process the message
					EXEC dbo.ProcessProduct @messagebody
				END
				IF (@messagetypename = '//WhseETL/SalesOrderHeader')
				BEGIN
					-- Process the message
					EXEC dbo.ProcessSalesOrderHeader @messagebody
				END
				IF (@messagetypename = '//WhseETL/SalesOrderDetail')
				BEGIN
					-- Process the message
					EXEC dbo.ProcessSalesOrderDetail @messagebody
				END
				IF @messagetypename = 'http://schemas.microsoft.com/SQL/ServiceBroker/Error'
				BEGIN
					-- Process the message
					INSERT INTO dbo.ErrorLog (ErrorTime, UserName, ErrorNumber, ErrorSeverity,
    					ErrorState, ErrorProcedure, ErrorLine, ErrorMessage)
					VALUES (getdate(), 'WombatUser', 65539, 25,
    					0, 'ProcessSyncData', 1, @messagetypename)
				END
			COMMIT TRANSACTION
		END TRY
		BEGIN CATCH
				
			ROLLBACK TRANSACTION

			INSERT INTO dbo.ErrorLog (ErrorTime, UserName, ErrorNumber, ErrorSeverity,
				ErrorState, ErrorProcedure, ErrorLine, ErrorMessage)
			VALUES (getdate(), USER_NAME(), ERROR_NUMBER(), ERROR_SEVERITY(),
				ERROR_STATE(), ERROR_PROCEDURE(), ERROR_LINE(), ERROR_MESSAGE())
			
		END CATCH
	END

GO
