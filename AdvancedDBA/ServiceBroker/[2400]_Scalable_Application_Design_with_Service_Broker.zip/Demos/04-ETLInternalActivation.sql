USE AdventureWorks
GO

CREATE TABLE dbo.ProductTick(
	[ProductNumber] [varchar](25) NULL
	)
GO

CREATE PROCEDURE [dbo].[ProcessProduct]
AS
SET NOCOUNT ON
	DECLARE @ch UNIQUEIDENTIFIER
	DECLARE @messagetypename NVARCHAR(256)
	DECLARE	@messagebody XML
	DECLARE @responsemessage XML;

	WHILE (1=1)
	BEGIN
		BEGIN TRY
			BEGIN TRANSACTION

			WAITFOR (
				RECEIVE TOP(1)
					@ch = conversation_handle,
					@messagetypename = message_type_name,
					@messagebody = CAST(message_body AS XML)
				FROM ETLProcessQueue
			), TIMEOUT 5000

			IF (@@ROWCOUNT = 0)
			BEGIN
				ROLLBACK TRANSACTION
				BREAK
			END
			
			INSERT INTO dbo.ProductTick ([ProductNumber])
			SELECT
				a.value(N'(./ProductNumber/text())[1]', N'NVarChar(20)') as [ProductNumber]
			from @messagebody.nodes('/Product/row') as r(a)
			option (optimize for (@messagebody = NULL));
			
			-- End the conversation
			COMMIT TRANSACTION
		END TRY
		BEGIN CATCH
				
			ROLLBACK TRANSACTION

			INSERT INTO dbo.ErrorLog (ErrorTime, UserName, ErrorNumber, ErrorSeverity,
				ErrorState, ErrorProcedure, ErrorLine, ErrorMessage)
			VALUES (getdate(), USER_NAME(), ERROR_NUMBER(), ERROR_SEVERITY(),
				ERROR_STATE(), ERROR_PROCEDURE(), ERROR_LINE(), ERROR_MESSAGE())

		END CATCH
	END
GO

ALTER QUEUE ETLProcessQueue
WITH ACTIVATION
(
	STATUS = ON,
	PROCEDURE_NAME = [dbo].[ProcessProduct],
	MAX_QUEUE_READERS = 1,
	EXECUTE AS 'ETLUser'
)
GO
GRANT EXECUTE ON dbo.ProcessProduct to ETLUser
GO
