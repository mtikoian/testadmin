--------------------------------------------
-- Copyright (c) Vortal, SA
-- Secret Information
--------------------------------------------

-- Selecting the database
use econstroi2

-- Set the trustworthy level to on to allow deployment of unsafe assemblies
ALTER DATABASE econstroi2 SET TRUSTWORTHY ON

-- Check if broker is enabled (row MUST show value 1)
SELECT name, is_broker_enabled 
FROM sys.databases 
WHERE name = 'econstroi2'

-- If is_broker_enable shows 0, then enable the SQL Service Broker 
--ALTER DATABASE econstroi2
--SET ENABLE_BROKER 

-- Enable the Common Language Runtime for the SQL database
sp_configure 'clr enabled', 1
go
reconfigure
go

-- Check if CLR is enabled for SQL Server 2005
-- go to 'Start > Programs > Microsoft SQL Server 2005 > Configuration Tools >
-- > SQL Server Surface Area Configuration'
-- Choose 'Surface Area Configuration for Features', then under 
-- 'Database Engine > CLR Integration', make sure the checkbox 'Enable CLR Integration' is ticked.

-- 2. Creating authorization for strong key 

-- Select the master database
USE master;

-- Create the asymmetric key for the strong key pair file (created step 0, if none was available)
CREATE MASTER KEY ENCRYPTION BY PASSWORD = 'Visionvia2008'

CREATE ASYMMETRIC KEY extKey FROM FILE = 'C:\sqlBroker\brokerExtKey.snk'
ENCRYPTION BY PASSWORD = 'Visionvia2008'

-- Create a login for that key
CREATE LOGIN extLogin FROM ASYMMETRIC KEY extKey;

-- Give that login permission to deploy the unsafe assemblies
GRANT UNSAFE ASSEMBLY TO extLogin;

-- Switch to the host database
USE econstroi2

-- Create a user in that database mapped to the login
CREATE USER extLogin FROM LOGIN extLogin

-- Give that user the right to catalog an assembly
GRANT CREATE ASSEMBLY TO extLogin


-- 3. Deploy the assemblies

IF NOT EXISTS (SELECT * FROM sys.assemblies WHERE name = 'System.Web')
CREATE ASSEMBLY [System.Web] 
	AUTHORIZATION extLogin
    FROM 'C:\Windows\Microsoft.NET\Framework\v2.0.50727\System.Web.dll'
	WITH PERMISSION_SET=UNSAFE;

IF NOT EXISTS (SELECT * FROM sys.assemblies WHERE name = 'SMDiagnostics')
CREATE ASSEMBLY [SMDiagnostics]
	AUTHORIZATION extLogin
	FROM 'C:\Windows\Microsoft.NET\Framework\v3.0\Windows Communication Foundation\SMDiagnostics.dll'
	WITH PERMISSION_SET=UNSAFE;

IF NOT EXISTS (SELECT * FROM sys.assemblies WHERE name = 'System.IdentityModel')
CREATE ASSEMBLY [System.IdentityModel] 
	AUTHORIZATION extLogin
	FROM 'C:\Program Files\Reference Assemblies\Microsoft\Framework\v3.0\System.IdentityModel.dll'
	WITH PERMISSION_SET=UNSAFE;

IF NOT EXISTS (SELECT * FROM sys.assemblies WHERE name = 'System.Messaging')
CREATE ASSEMBLY [System.Messaging] 
	AUTHORIZATION extLogin
	FROM 'C:\Windows\Microsoft.NET\Framework\v2.0.50727\System.Messaging.dll'
	WITH PERMISSION_SET=UNSAFE;

IF NOT EXISTS (SELECT * FROM sys.assemblies WHERE name = 'System.IdentityModel.Selectors')
CREATE ASSEMBLY [System.IdentityModel.Selectors] 
	AUTHORIZATION extLogin
	FROM 'C:\Program Files\Reference Assemblies\Microsoft\Framework\v3.0\System.IdentityModel.Selectors.dll'
	WITH PERMISSION_SET=UNSAFE;

IF NOT EXISTS (SELECT * FROM sys.assemblies WHERE name = 'System.ServiceModel')
CREATE ASSEMBLY [System.ServiceModel] 
	AUTHORIZATION extLogin
	FROM 'C:\WINDOWS\Microsoft.NET\Framework\v3.0\Windows Communication Foundation\System.ServiceModel.dll' 
	WITH PERMISSION_SET=UNSAFE;

IF NOT EXISTS (SELECT * FROM sys.assemblies WHERE name = 'Microsoft.Transactions.Bridge')
CREATE ASSEMBLY [Microsoft.Transactions.Bridge] 
	AUTHORIZATION extLogin
	FROM 'C:\Windows\Microsoft.NET\Framework\v3.0\Windows Communication Foundation\Microsoft.Transactions.Bridge.dll'
	WITH PERMISSION_SET=UNSAFE;




