USE econstroi2
GO

-- 3. Deploy the assemblies

IF NOT EXISTS (SELECT * FROM sys.assemblies WHERE name = 'System.Web')
CREATE ASSEMBLY [System.Web] 
	AUTHORIZATION extLogin
    FROM 'C:\Windows\Microsoft.NET\Framework\v2.0.50727\System.Web.dll'
	WITH PERMISSION_SET=UNSAFE;

IF NOT EXISTS (SELECT * FROM sys.assemblies WHERE name = 'SMDiagnostics')
CREATE ASSEMBLY [SMDiagnostics]
	AUTHORIZATION extLogin
	FROM 'C:\Windows\Microsoft.NET\Framework\v3.0\Windows Communication Foundation\SMDiagnostics.dll'
	WITH PERMISSION_SET=UNSAFE;

IF NOT EXISTS (SELECT * FROM sys.assemblies WHERE name = 'System.IdentityModel')
CREATE ASSEMBLY [System.IdentityModel] 
	AUTHORIZATION extLogin
	FROM 'C:\Program Files\Reference Assemblies\Microsoft\Framework\v3.0\System.IdentityModel.dll'
	WITH PERMISSION_SET=UNSAFE;

IF NOT EXISTS (SELECT * FROM sys.assemblies WHERE name = 'System.Messaging')
CREATE ASSEMBLY [System.Messaging] 
	AUTHORIZATION extLogin
	FROM 'C:\Windows\Microsoft.NET\Framework\v2.0.50727\System.Messaging.dll'
	WITH PERMISSION_SET=UNSAFE;

IF NOT EXISTS (SELECT * FROM sys.assemblies WHERE name = 'System.IdentityModel.Selectors')
CREATE ASSEMBLY [System.IdentityModel.Selectors] 
	AUTHORIZATION extLogin
	FROM 'C:\Program Files\Reference Assemblies\Microsoft\Framework\v3.0\System.IdentityModel.Selectors.dll'
	WITH PERMISSION_SET=UNSAFE;

IF NOT EXISTS (SELECT * FROM sys.assemblies WHERE name = 'System.ServiceModel')
CREATE ASSEMBLY [System.ServiceModel] 
	AUTHORIZATION extLogin
	FROM 'C:\WINDOWS\Microsoft.NET\Framework\v3.0\Windows Communication Foundation\System.ServiceModel.dll' 
	WITH PERMISSION_SET=UNSAFE;

IF NOT EXISTS (SELECT * FROM sys.assemblies WHERE name = 'Microsoft.Transactions.Bridge')
CREATE ASSEMBLY [Microsoft.Transactions.Bridge] 
	AUTHORIZATION extLogin
	FROM 'C:\Windows\Microsoft.NET\Framework\v3.0\Windows Communication Foundation\Microsoft.Transactions.Bridge.dll'
	WITH PERMISSION_SET=UNSAFE;
