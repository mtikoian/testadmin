USE [SourceDB];
GO


--RECEIVE THE REQUEST AND SEND A REPLY TO INITIATOR SERVER - STEP 2
DECLARE @RecvReqDlgHandle UNIQUEIDENTIFIER;
DECLARE @RecvReqMsg NVARCHAR(1000);
DECLARE @RecvReqMsgName sysname;

BEGIN TRANSACTION;

--RECEIVE MESSAGE FROM INITIATOR
WAITFOR
( RECEIVE TOP(1)
    @RecvReqDlgHandle = conversation_handle,
    @RecvReqMsg = message_body,
    @RecvReqMsgName = message_type_name
  FROM [dbo].[Queue\\SrcSrvName\SourceDbName\trgSrvName\TargetDbName]), TIMEOUT 1000;

SELECT @RecvReqMsg AS ReceivedRequestMsg;

--CONFIRM AND SEND A REPLY
IF @RecvReqMsgName = N'msg\\SrcSrvName\SourceDbName\trgSrvName\TargetDbName'
BEGIN
     END CONVERSATION @RecvReqDlgHandle; -- WITH CLEANUP;
END


COMMIT TRANSACTION;
GO

--SELECT * FROM sys.conversation_endpoints
--END CONVERSATION '<conversation_handle here>' WITH CLEANUP


----Any errors with sending message??
--SELECT * FROM Sys.transmission_queue