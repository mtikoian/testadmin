USE [SourceDB];
GO
--START A CONVERSATION AND SEND A MESSAGE TO TARGET SERVER - STEP 1
DECLARE @InitDlgHandle UNIQUEIDENTIFIER;
DECLARE @RequestMsg NVARCHAR(100);

BEGIN TRANSACTION;

BEGIN DIALOG @InitDlgHandle
     FROM SERVICE [SourceService\\SrcSrvName\SourceDbName\trgSrvName\TargetDbName]
     TO SERVICE N'TargetService\\SrcSrvName\SourceDbName\trgSrvName\TargetDbName'
     ON CONTRACT [con\\SrcSrvName\SourceDbName\trgSrvName\TargetDbName]
     WITH ENCRYPTION = ON;

SELECT @RequestMsg = N'SRCtoTRG Message for Target service.';

SEND ON CONVERSATION @InitDlgHandle
     MESSAGE TYPE [msg\\SrcSrvName\SourceDbName\trgSrvName\TargetDbName]
     (@RequestMsg);



SELECT @RequestMsg AS SentRequestMsg;

COMMIT TRANSACTION;
GO



--SELECT * FROM sys.conversation_endpoints
--END CONVERSATION '<conversation_handle here>' WITH CLEANUP


----Any errors with sending message??
--SELECT * FROM Sys.transmission_queue
