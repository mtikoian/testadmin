
----------------------------CREATE MASTER CERTS----------------------------
--Configure the transport security.
USE [master]
go

--Create a master key in the master database.
--DROP MASTER KEY
CREATE MASTER KEY ENCRYPTION BY password = '!MasterKeyPassword!'
Go
--CERTS AND KEYS CAN BE DELETED FROM PHYSICAL DRIVE AFTER CREATED ON SQL DB (FOR BETTER SECURITY)

--Create a certificate for transport security.
--DROP CERTIFICATE ctfTargetMasterServer
CREATE CERTIFICATE ctfTargetMasterServer
FROM FILE = 'C:\CertStore\Master\Certificate_ctfTargetMasterServer.cer'
--PRIVATE KEY IS REQUIRED ON CREATION. CAN BE DROPPED FROM TARGETS PHYSICAL LOCATION FOR SECURITY PURPOSES
WITH PRIVATE KEY															
	(FILE='C:\CertStore\Master\Certificate_ctfTargetMasterServer.key',
	 DECRYPTION BY PASSWORD = '!PrivateMasterKeyPassword!') 
ACTIVE FOR BEGIN_DIALOG = ON
GO

--Create the login and the user to own a certificate.
--DROP LOGIN democert
CREATE LOGIN democert WITH PASSWORD = '!democertPassword!'
GO
--DROP USER democert
CREATE USER democert FOR LOGIN democert
GO

--DROP CERTIFICATE ctfSourceMasterServer
CREATE CERTIFICATE ctfSourceMasterServer
AUTHORIZATION democert
FROM FILE = 'C:\CertStore\Master\Certificate_ctfSourceMasterServer.cer'
ACTIVE FOR BEGIN_DIALOG = ON
GO

--Create a new endpoint for SQL Server Service Broker, 
	--set the AUTHENTICATION option to use the ctfTargetMasterServer certificate.

--DROP ENDPOINT BrokerEndpoint
CREATE ENDPOINT BrokerEndpoint
	STATE = STARTED
	AS TCP
	(
		LISTENER_PORT = 4022
	)
	FOR SERVICE_BROKER (AUTHENTICATION = CERTIFICATE ctfTargetMasterServer)
GO

--Grant the required permissions to the democert login.
GRANT CONNECT TO democert
GRANT CONNECT ON ENDPOINT::BrokerEndpoint to democert
GO
----------------------------END OF MASTER CERTS----------------------------

----------------------------CREATE DATABASE CERTS----------------------------
USE [master]
GO

CREATE DATABASE [TargetDB];


USE [TargetDB]
GO


--Drop and create a new master key in the master database.
--DROP MASTER KEY
CREATE MASTER KEY ENCRYPTION BY PASSWORD = '!DbKeyPassword!'

--CERTS AND KEYS CAN BE DELETED FROM PHYSICAL DRIVE AFTER CREATED ON SQL DB (FOR BETTER SECURITY)

--Create a certificate for the TargetDB database.
--DROP CERTIFICATE [ctgTarget_SrcSrvName-SourceDbName--trgSrvName-TargetDbName]
CREATE CERTIFICATE [ctgTarget_SrcSrvName-SourceDbName--trgSrvName-TargetDbName]
FROM FILE = 'C:\CertStore\SourceToTarget\ctgTarget_SrcSrvName-SourceDbName--trgSrvName-TargetDbNam.cer'
WITH PRIVATE KEY 
	( FILE = 'C:\CertStore\SourceToTarget\ctgTarget_SrcSrvName-SourceDbName--trgSrvName-TargetDbNam.key',
	  DECRYPTION BY PASSWORD = '!PrivateDBKeyPassword!')
ACTIVE FOR BEGIN_DIALOG = ON
GO


--Create a user for the democert login that owns a certificate.
--DROP USER democert
CREATE USER democert for LOGIN democert
GO

--DROP CERTIFICATE [Source_SrcSrvName-SourceDbName--trgSrvName-TargetDbName]
CREATE CERTIFICATE [Source_SrcSrvName-SourceDbName--trgSrvName-TargetDbName]
AUTHORIZATION democert
FROM FILE = 'C:\CertStore\SourceToTarget\_SrcSrvName-SourceDbName--trgSrvName-TargetDbName.cer'
ACTIVE FOR BEGIN_DIALOG = ON

----------------------------END OF DATABASE CERTS----------------------------

----------------------------CREATE SB OBJECTS--------------------------------
USE [TargetDB]
GO

select [name], is_broker_enabled, is_trustworthy_on from sys.databases WHERE [name] = 'TargetDB'
ALTER DATABASE [TargetDB] SET ENABLE_BROKER  --WITH ROLLBACK IMMEDIATE  --Kills any active process in the database.
ALTER DATABASE [TargetDB] SET TRUSTWORTHY ON --Not generally a good practice within database, make sure to follow safety guidlines when using this feature.


--Create a message type, a contract, a queue, and a service.
CREATE MESSAGE TYPE [msg\\SrcSrvName\SourceDbName\trgSrvName\TargetDbName] VALIDATION = NONE 

CREATE CONTRACT [con\\SrcSrvName\SourceDbName\trgSrvName\TargetDbName] ([msg\\SrcSrvName\SourceDbName\trgSrvName\TargetDbName] SENT BY ANY)

CREATE QUEUE [dbo].[Queue\\SrcSrvName\SourceDbName\trgSrvName\TargetDbName] 
--ALter QUEUE [dbo].[Queue\\SrcSrvName\SourceDbName\trgSrvName\TargetDbName]  WITH STATUS = ON , 
--	RETENTION = OFF , 
--	ACTIVATION (  STATUS = ON ,
--    PROCEDURE_NAME = [dbo].[usp_SB_GetSubjectInfoDataFromXML] , 
--    MAX_QUEUE_READERS = 10 , 
--    EXECUTE AS N'democert' )

CREATE SERVICE [TargetService\\SrcSrvName\SourceDbName\trgSrvName\TargetDbName] 
ON QUEUE [dbo].[Queue\\SrcSrvName\SourceDbName\trgSrvName\TargetDbName] ([con\\SrcSrvName\SourceDbName\trgSrvName\TargetDbName])
GO

--Grant the send permission to the user.
GRANT SEND ON SERVICE::[TargetService\\SrcSrvName\SourceDbName\trgSrvName\TargetDbName] TO democert
GO

--Create a remote service binding for the target service. THIS IS NOT REQUIRED FOR TARGET SERVER, IF NOT SENDING A REPLY BACK TO SOURCE.
CREATE REMOTE SERVICE BINDING [RSM\\SrcSrvName\SourceDbName\trgSrvName\TargetDbName]
   TO SERVICE 'SourceService\\SrcSrvName\SourceDbName\trgSrvName\TargetDbName'
   WITH  USER = democert,
   ANONYMOUS=Off  

--Create a route for the target service.
CREATE ROUTE [Route\\SrcSrvName\SourceDbName\trgSrvName\TargetDbName]
    WITH 
    SERVICE_NAME = 'SourceService\\SrcSrvName\SourceDbName\trgSrvName\TargetDbName',
    address = 'TCP://<Source Server IP Address Here>:4022';

----------------------------END OF SB OBJECTS--------------------------------


---- For droping the object in one shot--
--DROP ROUTE [Route\\SrcSrvName\SourceDbName\trgSrvName\TargetDbName]
--DROP REMOTE SERVICE BINDING [RSM\\SrcSrvName\SourceDbName\trgSrvName\TargetDbName]
--DROP SERVICE [TargetService\\SrcSrvName\SourceDbName\trgSrvName\TargetDbName]
--DROP CONTRACT [con\\SrcSrvName\SourceDbName\trgSrvName\TargetDbName]
--DROP QUEUE [Queue\\SrcSrvName\SourceDbName\trgSrvName\TargetDbName]
--DROP MESSAGE TYPE [msg\\SrcSrvName\SourceDbName\trgSrvName\TargetDbName]