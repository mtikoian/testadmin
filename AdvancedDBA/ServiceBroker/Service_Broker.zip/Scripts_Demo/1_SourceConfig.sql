----------------------------CREATE MASTER CERTS----------------------------
--Configure the transport security.
USE [master]
go

--Create a master key in the master database.
--DROP MASTER KEY;
CREATE MASTER KEY ENCRYPTION BY password = '!MasterKeyPassword!'
Go

--Create a certificate at the master level
--DROP CERTIFICATE ctfSourceMasterServer
CREATE CERTIFICATE ctfSourceMasterServer
     WITH SUBJECT = N'ctfSourceMasterServer',
     EXPIRY_DATE = N'12/31/2099'
     ACTIVE FOR BEGIN_DIALOG = ON;
BACKUP CERTIFICATE ctfSourceMasterServer
  TO FILE = 
N'C:\CertStore\Master\Certificate_ctfSourceMasterServer.cer';
GO


--Create the login and the user to own a certificate.
--DROP LOGIN democert
CREATE LOGIN democert WITH PASSWORD = '!democertPassword!'
GO
--DROP USER democert
CREATE USER democert FOR LOGIN democert
GO


--Create a certificate at the master level
--DROP CERTIFICATE ctfTargetMasterServer
CREATE CERTIFICATE ctfTargetMasterServer
     AUTHORIZATION democert
     WITH SUBJECT = N'ctfTargetMasterServer',
     EXPIRY_DATE = N'12/31/2099'
     ACTIVE FOR BEGIN_DIALOG = ON;
BACKUP CERTIFICATE ctfTargetMasterServer
  TO FILE = N'C:\CertStore\Master\Certificate_ctfTargetMasterServer.cer'
--PRIVATE KEY IS REQUIRED ON CREATION. CAN BE DROPPED FROM TARGETS PHYSICAL LOCATION FOR SECURITY PURPOSES
  WITH PRIVATE KEY
    ( FILE = N'C:\CertStore\Master\Certificate_ctfTargetMasterServer.key',
      ENCRYPTION BY PASSWORD = '!PrivateMasterKeyPassword!' )
GO


--Create a new endpoint for SQL Server Service Broker, 
	--set the authentication option to use the ctfSourceMasterServer certificate.

--DROP ENDPOINT BrokerEndpoint
CREATE ENDPOINT BrokerEndpoint
	STATE = STARTED
	AS TCP
	(
		LISTENER_PORT = 4022
	)
	FOR SERVICE_BROKER (AUTHENTICATION = CERTIFICATE ctfSourceMasterServer)
GO					  --AUTHENTICATION = WINDOWS)

--Grant the required permissions to the democert login.
GRANT CONNECT TO democert
GRANT CONNECT ON ENDPOINT::BrokerEndpoint to democert
GO

----------------------END OF MASTER CERTS----------------------------

---------------------CREATE DB CERTIFICATES-----------------
USE [master]
GO

CREATE DATABASE [SourceDB];


USE [SourceDB]
GO

--Drop and create a new master key in the master database.
--DROP MASTER KEY
CREATE MASTER KEY ENCRYPTION BY PASSWORD = '!DbKeyPassword!'

--Create a certificate for the SourceDB database.
--DROP CERTIFICATE [ctfSource_SrcSrvName-SourceDbName--trgSrvName-TargetDbName]
CREATE CERTIFICATE [ctfSource_SrcSrvName-SourceDbName--trgSrvName-TargetDbName]
     WITH SUBJECT = N'ctfSource_SrcSrvName-SourceDbName--trgSrvName-TargetDbName',
     EXPIRY_DATE = N'12/31/2099'
     ACTIVE FOR BEGIN_DIALOG = ON;
BACKUP CERTIFICATE [ctfSource_SrcSrvName-SourceDbName--trgSrvName-TargetDbName]
  TO FILE = 
N'C:\CertStore\SourceToTarget\ctfSource_SrcSrvName-SourceDbName--trgSrvName-TargetDbName.cer';
GO

--Create a user for the democert login that owns a certificate for the dialog security.
--DROP USER democert
CREATE USER democert for LOGIN democert
GO

--DROP CERTIFICATE [ctgTarget_SrcSrvName-SourceDbName--trgSrvName-TargetDbName]
CREATE CERTIFICATE [ctgTarget_SrcSrvName-SourceDbName--trgSrvName-TargetDbName]
     AUTHORIZATION democert
     WITH SUBJECT = N'ctgTarget_SrcSrvName-SourceDbName--trgSrvName-TargetDbName',
     EXPIRY_DATE = N'12/31/2099'
     ACTIVE FOR BEGIN_DIALOG = ON;
BACKUP CERTIFICATE [ctgTarget_SrcSrvName-SourceDbName--trgSrvName-TargetDbName]
  TO FILE = 
N'C:\CertStore\SourceToTarget\ctgTarget_SrcSrvName-SourceDbName--trgSrvName-TargetDbName.cer'
  WITH PRIVATE KEY
    ( FILE = N'C:\CertStore\SourceToTarget\ctgTarget_SrcSrvName-SourceDbName--trgSrvName-TargetDbName.key',
      ENCRYPTION BY PASSWORD = '!PrivateDBKeyPassword!' )
GO

----------------------------END OF DB CERTIFICATES----------------------------


----------------------------CREATE SB OBJECTS--------------------------------
USE [SourceDB]
GO

SELECT [name], is_broker_enabled, is_trustworthy_on from sys.databases WHERE [name] = 'SourceDB'
ALTER DATABASE [SourceDB] SET ENABLE_BROKER  --WITH ROLLBACK IMMEDIATE --Kills any active process in the database. 
ALTER DATABASE [SourceDB] SET TRUSTWORTHY ON --Not generally a good practice within database, make sure to follow safety guidlines when using this feature.


--Create a message type, a contract, a queue, and a service.
CREATE MESSAGE TYPE [msg\\SrcSrvName\SourceDbName\trgSrvName\TargetDbName] VALIDATION = NONE 
CREATE CONTRACT [con\\SrcSrvName\SourceDbName\trgSrvName\TargetDbName] ([msg\\SrcSrvName\SourceDbName\trgSrvName\TargetDbName] SENT BY ANY)
CREATE QUEUE [dbo].[Queue\\SrcSrvName\SourceDbName\trgSrvName\TargetDbName]

CREATE SERVICE [SourceService\\SrcSrvName\SourceDbName\trgSrvName\TargetDbName]
ON QUEUE [dbo].[Queue\\SrcSrvName\SourceDbName\trgSrvName\TargetDbName]([con\\SrcSrvName\SourceDbName\trgSrvName\TargetDbName])
GO

--Grant the send permission to the user.
GRANT SEND ON SERVICE::[SourceService\\SrcSrvName\SourceDbName\trgSrvName\TargetDbName] TO democert

--Create a remote service binding for the target service. 
CREATE REMOTE SERVICE BINDING [RSM\\SrcSrvName\SourceDbName\trgSrvName\TargetDbName]
   TO SERVICE 'TargetService\\SrcSrvName\SourceDbName\trgSrvName\TargetDbName'
   WITH  USER = democert,
   ANONYMOUS=OFF		

--Create a route for the target service.
CREATE ROUTE [Route\\SrcSrvName\SourceDbName\trgSrvName\TargetDbName]
    WITH 
    SERVICE_NAME = 'TargetService\\SrcSrvName\SourceDbName\trgSrvName\TargetDbName',
    ADDRESS = 'TCP://<Target Server IP Address Here>:4022';


----------------------------END OF SB OBJECTS--------------------------------


-- For droping the object in one shot--
--DROP ROUTE [Route\\SrcSrvName\SourceDbName\trgSrvName\TargetDbName]
--DROP REMOTE SERVICE BINDING [RSM\\SrcSrvName\SourceDbName\trgSrvName\TargetDbName]
--DROP SERVICE [SourceService\\SrcSrvName\SourceDbName\trgSrvName\TargetDbName]
--DROP CONTRACT [con\\SrcSrvName\SourceDbName\trgSrvName\TargetDbName]
--DROP QUEUE [Queue\\SrcSrvName\SourceDbName\trgSrvName\TargetDbName]
--DROP MESSAGE TYPE [msg\\SrcSrvName\SourceDbName\trgSrvName\TargetDbName]
