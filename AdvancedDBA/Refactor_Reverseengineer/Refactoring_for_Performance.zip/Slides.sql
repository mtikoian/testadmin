/***********************************
Refactoring for Performance

Dmitri V. Korotkevitch
MCITP(DBDev, DBA), MCPD

(B): http://aboutsqlserver.com
(E): dmitri@aboutsqlserver.com

Agenda:
1. 1001 ways to save the data
2. Can you catch me? (OUTPUT) 
3. The Good and the Ugly (Functions)
4. Job Security (CTE) 
************************************/