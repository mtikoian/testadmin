/**********************************************************************
SQL Saturday #62 (January 15th, 2010. Tampa, FL)

Dmitri Korotkevitch: "Refactoring for performance"

Multi-Statement vs. Inline table valued functions
**********************************************************************/


use SqlSat62
go


if exists(
	select * 
	from sys.objects 
	where object_id = OBJECT_ID(N'[dbo].[AvgItemCost]') and type in (N'FN')
)
	drop function [dbo].[AvgItemCost]
GO

create function dbo.AvgItemCost
(
	@OrderId int
)
returns money
as
begin
	declare
		@Result money
	
	select @Result = Sum(Quantity * UnitPrice) / Sum(Quantity)
	from dbo.OrderItems
	where OrderId = @OrderId

	return @Result
end
go

declare
	@DT datetime = getDate()

select Sum(dbo.AvgItemCost(OrderId))
from dbo.Orders 

select DATEDIFF(millisecond,@DT,getDate())
go



















































if exists(
	select * 
	from sys.objects 
	where object_id = OBJECT_ID(N'[dbo].[AvgItemCostInline]') and type in (N'IF')
)
	drop function [dbo].AvgItemCostInline
GO

create function dbo.AvgItemCostInline
(
	@OrderId int
)
returns table
as
return
(
	select Sum(Quantity * UnitPrice) / Sum(Quantity) as [AvgCost]
	from dbo.OrderItems
	where OrderId = @OrderId
)
go

declare
	@DT datetime = getDate()

select Sum(a.AvgCost)
from 
	dbo.Orders o cross apply
		dbo.AvgItemCostInline(o.OrderId) a

select DATEDIFF(millisecond,@DT,getDate())
go


























/* Enable Execution Plan */

select Sum(dbo.AvgItemCost(OrderId))
from dbo.Orders 

select Sum(a.AvgCost)
from 
	dbo.Orders o cross apply
		dbo.AvgItemCostInline(o.OrderId) a
go































/* Enable profiler: "SP: Starting" event. */