/**********************************************************************
SQL Saturday #62 (January 15th, 2010. Tampa, FL)

Dmitri Korotkevitch: "Refactoring for performance"

OUTPUT clause
**********************************************************************/


use SqlSat62
go

set nocount on
set xact_abort on
go

if exists
(
	select * 
	from 
		sys.tables t join sys.schemas s on
			t.schema_id = s.schema_id
	where 
		t.name = 'OrderItems' and s.name = 'dbo'
) 
	drop table dbo.OrderItems
go

if exists
(
	select * 
	from 
		sys.tables t join sys.schemas s on
			t.schema_id = s.schema_id
	where 
		t.name = 'Orders' and s.name = 'dbo'
) 
	drop table dbo.Orders
go

create table dbo.Orders
(
	OrderId int not null identity(1,1),
	OrderDate datetime not null,
	OrderNum varchar(32) not null,
	Amount money not null,
	OtherColumns char(100) not null
		constraint DEF_Orders_OtherColumns
		default 'This is placeholder',
	
	constraint PK_Orders
	primary key clustered(OrderId)
)
go

create table dbo.OrderItems
(
	OrderId int not null,
	OrderItemId int not null identity(1,1),
	Product varchar(32) not null, 
	Quantity smallint not null,
	UnitPrice money not null,
	OtherColumns char(100) not null
		constraint DEF_OrderItems_OtherColumns
		default 'This is placeholder',
	
	constraint PK_OrderItems
	primary key clustered(OrderId, OrderItemId),
	
	constraint FK_OrderItems_Orders
	foreign key(OrderId)
	references dbo.Orders(OrderId)
	on update cascade
	on delete cascade
)
go

create table #TmpOrders
(
	InternalId smallint not null primary key,
	OrderDate datetime not null,
	OrderNum varchar(32) not null,
	Amount money not null,
	OtherColumns char(100) not null
		default 'This is placeholder'
)
go

create table #TmpOrderItems
(
	InternalOrderId smallint not null,
	Product varchar(32) not null, 
	Quantity smallint not null,
	UnitPrice money not null,
	OtherColumns char(100) not null 
		default 'This is placeholder'
)
go

-- populate temporary tables
truncate table #TmpOrders
truncate table #TmpOrderItems
go

declare
	@TmpOrderId int
	,@I int

select @TmpOrderId = 1

begin tran
	while @TmpOrderId <= 10000 
	begin
		insert into #TmpOrders(InternalId, OrderDate, OrderNum, Amount)
		values(
			@TmpOrderId, 
			DATEADD(day,@TmpOrderId - 500,GetDate()), 
			'Order ' + CONVERT(varchar(5), @TmpOrderId),
			@TmpOrderId)
		
		select @I = 0
		
		while @I < 10
		begin
			insert into #TmpOrderItems(InternalOrderId, Product, Quantity, UnitPrice)
			values(
				@TmpOrderId, 
				'Product ' + CONVERT(varchar(2),@I),
				@I, 
				@I)
			select @I += 1
		end
		select @TmpOrderId += 1
	end
commit
go

select top 10 * from #TmpOrders
select top 30 * from #TmpOrderItems
go




-- classical approach with cursor
truncate table dbo.OrderItems
delete from dbo.Orders
go

declare
	@InternalId int
	,@OrderDate datetime
	,@OrderNum varchar(32)
	,@Amount money
	,@OtherColumns char(100)
	,@OrderId int
	,@DT datetime

select @DT = GETDATE()

declare 
	curWork cursor LOCAL FAST_FORWARD
	for
		select InternalId, OrderDate, OrderNum, Amount, OtherColumns 
		from #TmpOrders

open curWork
fetch next from curWork into @InternalId, @OrderDate, @OrderNum, @Amount, @OtherColumns 

begin tran
	while @@FETCH_STATUS = 0
	begin
		insert into dbo.Orders(OrderDate, OrderNum, Amount, OtherColumns)
		values(@OrderDate, @OrderNum, @Amount, @OtherColumns)
		
		select @OrderId = @@IDENTITY
		insert into dbo.OrderItems(OrderId, Product, Quantity, UnitPrice, OtherColumns)
			select @OrderId, Product, Quantity, UnitPrice, OtherColumns
			from #TmpOrderItems
			where InternalOrderId = @InternalId
			
		fetch next from curWork into @InternalId, @OrderDate, @OrderNum, @Amount, @OtherColumns 
	end
commit
close curWork
deallocate curWork

select DATEDIFF(millisecond,@DT,GetDate()) as [Exec Time]
go















































-- OUTPUT approach #1		
truncate table dbo.OrderItems
delete from dbo.Orders
go

declare
	@DT datetime

select @DT = GETDATE()

declare
	@Ids table (
		OrderId int not null,
		OrderNum varchar(32) not null
	)
	
begin tran
	insert into dbo.Orders(OrderDate, OrderNum, Amount, OtherColumns)
		output inserted.OrderId, inserted.OrderNum into @Ids(OrderId, OrderNum)
		select OrderDate, OrderNum, Amount, OtherColumns
		from #TmpOrders
		
	insert into dbo.OrderItems(OrderId, Product, Quantity, UnitPrice, OtherColumns)
		select i.OrderId, t.Product, t.Quantity, t.UnitPrice, t.OtherColumns
		from 
			@Ids i join #TmpOrders o on
				i.OrderNum = o.OrderNum 
			join #TmpOrderItems t on
				t.InternalOrderId  = o.InternalId
commit

select DATEDIFF(millisecond,@DT,GetDate()) as [Exec Time]
go
















































-- OUTPUT approach #2 (What if OrderNum is not unique)
truncate table dbo.OrderItems
delete from dbo.Orders
go

declare
	@DT datetime

select @DT = GETDATE()

declare
	@Ids table (OrderId int not null)
	
begin tran
	insert into dbo.Orders(OrderDate, OrderNum, Amount, OtherColumns)
		output inserted.OrderId into @Ids(OrderId)
		select OrderDate, OrderNum, Amount, OtherColumns
		from #TmpOrders
		order by InternalId
		
	;with CTE(OrderId, InternalOrderId)
	as
	(
		select 
			OrderId,
			ROW_NUMBER() over(order by OrderId)
		from @Ids
	)
	insert into dbo.OrderItems(OrderId, Product, Quantity, UnitPrice, OtherColumns)
		select CTE.OrderId, t.Product, t.Quantity, t.UnitPrice, t.OtherColumns
		from 
		-- Make sure Internal Ids start with 1
			#TmpOrderItems t join CTE on
				t.InternalOrderId  = CTE.InternalOrderId
commit

select DATEDIFF(millisecond,@DT,GetDate()) as [Exec Time]
go




/* Approach #2 is guaranteed to work on SQL 05 only - 
http://blogs.msdn.com/b/sqltips/archive/2005/07/20/441053.aspx

*/
















































-- Output Approach #3 (Merge - SQL 2008) 
truncate table dbo.OrderItems
delete from dbo.Orders
go

declare
	@DT datetime

select @DT = GETDATE()

declare
	@Ids table (
		OrderId int not null,
		InternalOrderId int not null
		)
	
begin tran
	insert into @Ids(OrderId, InternalOrderId)
		select M.OrderId, InternalOrderId
		from
			(
				merge into dbo.Orders as Target
				using #TmpOrders as Source
				on Target.OrderId is null -- never happens
				when not matched then
					insert(OrderDate, OrderNum, Amount, OtherColumns)
					values(Source.OrderDate, Source.OrderNum, Source.Amount, Source.OtherColumns)
				output
					inserted.OrderId, Source.InternalId
			) as M(OrderId, InternalOrderId)
		
	insert into dbo.OrderItems(OrderId, Product, Quantity, UnitPrice, OtherColumns)
		select i.OrderId, t.Product, t.Quantity, t.UnitPrice, t.OtherColumns
		from 
			#TmpOrderItems t join @Ids i on
				t.InternalOrderId  = i.InternalOrderId
commit

select DATEDIFF(millisecond,@DT,GetDate()) as [Exec Time]
go

