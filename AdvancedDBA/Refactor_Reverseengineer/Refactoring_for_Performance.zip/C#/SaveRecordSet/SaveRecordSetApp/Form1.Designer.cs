﻿namespace SaveRecordSetApp
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.tbPacketSize = new System.Windows.Forms.TextBox();
            this.btnSeparateInserts = new System.Windows.Forms.Button();
            this.btnTvp = new System.Windows.Forms.Button();
            this.btnElementCentric = new System.Windows.Forms.Button();
            this.btnAttributeCentric = new System.Windows.Forms.Button();
            this.btnOpenXml = new System.Windows.Forms.Button();
            this.btnAttributeCentricTempTable = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Packet Size:";
            // 
            // tbPacketSize
            // 
            this.tbPacketSize.Location = new System.Drawing.Point(86, 10);
            this.tbPacketSize.Name = "tbPacketSize";
            this.tbPacketSize.Size = new System.Drawing.Size(100, 20);
            this.tbPacketSize.TabIndex = 1;
            this.tbPacketSize.Text = "5000";
            // 
            // btnSeparateInserts
            // 
            this.btnSeparateInserts.Location = new System.Drawing.Point(16, 41);
            this.btnSeparateInserts.Name = "btnSeparateInserts";
            this.btnSeparateInserts.Size = new System.Drawing.Size(137, 23);
            this.btnSeparateInserts.TabIndex = 2;
            this.btnSeparateInserts.Text = "Separate inserts";
            this.btnSeparateInserts.UseVisualStyleBackColor = true;
            this.btnSeparateInserts.Click += new System.EventHandler(this.btnSeparateInserts_Click);
            // 
            // btnTvp
            // 
            this.btnTvp.Location = new System.Drawing.Point(16, 70);
            this.btnTvp.Name = "btnTvp";
            this.btnTvp.Size = new System.Drawing.Size(137, 23);
            this.btnTvp.TabIndex = 3;
            this.btnTvp.Text = "TVP";
            this.btnTvp.UseVisualStyleBackColor = true;
            this.btnTvp.Click += new System.EventHandler(this.btnTvp_Click);
            // 
            // btnElementCentric
            // 
            this.btnElementCentric.Location = new System.Drawing.Point(16, 99);
            this.btnElementCentric.Name = "btnElementCentric";
            this.btnElementCentric.Size = new System.Drawing.Size(137, 23);
            this.btnElementCentric.TabIndex = 4;
            this.btnElementCentric.Text = "Element-Centric XML";
            this.btnElementCentric.UseVisualStyleBackColor = true;
            this.btnElementCentric.Click += new System.EventHandler(this.btnElementCentric_Click);
            // 
            // btnAttributeCentric
            // 
            this.btnAttributeCentric.Location = new System.Drawing.Point(16, 128);
            this.btnAttributeCentric.Name = "btnAttributeCentric";
            this.btnAttributeCentric.Size = new System.Drawing.Size(137, 23);
            this.btnAttributeCentric.TabIndex = 5;
            this.btnAttributeCentric.Text = "Attribute-Centric XML";
            this.btnAttributeCentric.UseVisualStyleBackColor = true;
            this.btnAttributeCentric.Click += new System.EventHandler(this.btnAttributeCentric_Click);
            // 
            // btnOpenXml
            // 
            this.btnOpenXml.Location = new System.Drawing.Point(16, 158);
            this.btnOpenXml.Name = "btnOpenXml";
            this.btnOpenXml.Size = new System.Drawing.Size(137, 23);
            this.btnOpenXml.TabIndex = 6;
            this.btnOpenXml.Text = "Open XML";
            this.btnOpenXml.UseVisualStyleBackColor = true;
            this.btnOpenXml.Click += new System.EventHandler(this.btnOpenXml_Click);
            // 
            // btnAttributeCentricTempTable
            // 
            this.btnAttributeCentricTempTable.Location = new System.Drawing.Point(16, 187);
            this.btnAttributeCentricTempTable.Name = "btnAttributeCentricTempTable";
            this.btnAttributeCentricTempTable.Size = new System.Drawing.Size(218, 23);
            this.btnAttributeCentricTempTable.TabIndex = 7;
            this.btnAttributeCentricTempTable.Text = "Attribute-Centric XML with Temp Table";
            this.btnAttributeCentricTempTable.UseVisualStyleBackColor = true;
            this.btnAttributeCentricTempTable.Click += new System.EventHandler(this.btnAttributeCentric_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(304, 239);
            this.Controls.Add(this.btnAttributeCentricTempTable);
            this.Controls.Add(this.btnOpenXml);
            this.Controls.Add(this.btnAttributeCentric);
            this.Controls.Add(this.btnElementCentric);
            this.Controls.Add(this.btnTvp);
            this.Controls.Add(this.btnSeparateInserts);
            this.Controls.Add(this.tbPacketSize);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbPacketSize;
        private System.Windows.Forms.Button btnSeparateInserts;
        private System.Windows.Forms.Button btnTvp;
		private System.Windows.Forms.Button btnElementCentric;
		private System.Windows.Forms.Button btnAttributeCentric;
		private System.Windows.Forms.Button btnOpenXml;
        private System.Windows.Forms.Button btnAttributeCentricTempTable;
    }
}

