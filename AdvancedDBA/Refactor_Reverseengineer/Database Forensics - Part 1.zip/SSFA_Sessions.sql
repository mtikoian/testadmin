-- 
-- Source: SQL Server Forensic Analysis
-- Author: Kevvie Fowler
-- Script: SSFA_Sessions.sql - Gathers active SQL Server 2000, 2005 & 2008 sessions
-- 
--
-- Verify if server is running SQL Server 2000, if so gather data, otherwise jump to next version check
DECLARE @tstring varchar (300)
--IF CONVERT(char(20), SERVERPROPERTY('productversion')) LIKE '8.00%'
--BEGIN
----
---- Gather session data
--select spid, login_time, hostname, [program_name], loginame, nt_domain,  nt_username, [status], last_batch from master..sysprocesses
----
---- Log and exit script
--GOTO LOG_EXIT
--END
----
--ELSE
--
-- Verify if server is running SQL Server 2005 or 2008
IF ((CONVERT(char(20), SERVERPROPERTY('productversion')) LIKE '11.00%') OR (CONVERT(char(20), SERVERPROPERTY('productversion')) LIKE '10.50%'))
BEGIN
--
-- Gather session data
-- Check for RTM and SP1 versions of SQL Server which don't contain original_login_name, last_successful_logon, last_unsuccessful_logon and unsuccessful_logon fields within sys.dm_exec_sessions
IF (RTRIM(CONVERT(char(20), SERVERPROPERTY('ProductLevel'))) = 'RTM') OR (RTRIM(CONVERT(char(20), SERVERPROPERTY('ProductLevel'))) = 'SP1')
BEGIN
Select session_id, login_time, [host_name], [program_name], login_name, nt_domain,  nt_user_name, [status], last_request_start_time, last_request_end_time, row_count from sys.dm_exec_sessions
GOTO LOG_EXIT
END
SET @tstring = 'Select session_id, login_time, [host_name], [program_name], login_name, original_login_name, nt_domain,  nt_user_name, [status], last_request_start_time, last_request_end_time, row_count, last_successful_logon, last_unsuccessful_logon, unsuccessful_logons from sys.dm_exec_sessions'
EXEC (@tstring)
--
LOG_EXIT:
-- Log connection information
PRINT ''
PRINT ''
PRINT ''
PRINT '************************************************************************************************************************************'
PRINT 'User: ' + suser_sname() +' | Script: SSFA_Sessions.sql | SPID: ' + CAST(@@SPID AS VARCHAR(5)) + ' | Closed on ' + CAST(GETDATE() AS VARCHAR(30))
PRINT '************************************************************************************************************************************'
-- Exit script
RETURN
END
--

