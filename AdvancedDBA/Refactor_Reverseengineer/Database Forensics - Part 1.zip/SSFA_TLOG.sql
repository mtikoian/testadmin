-- 
-- Source: SQL Server Forensic Analysis
-- Author: Kevvie Fowler
-- Script: SSFA_Tlog.sql - Gathers the 1000 most recent SQL Server 2000, 2005 or 2008 transaction log entries per database
-- 
--
-- Verify if server is running SQL Server 2000, if so gather data, otherwise jump to next version check
DECLARE 	@dbname varchar(400)
--IF CONVERT(char(20), SERVERPROPERTY('productversion')) LIKE '8.00%'
--BEGIN
----
----
----
--DECLARE CUR_getdbusr CURSOR READ_ONLY FOR 
--select [name] from master..sysdatabases;
--OPEN CUR_getdbusr
----
--FETCH NEXT FROM CUR_getdbusr INTO @dbname
--WHILE @@FETCH_STATUS = 0
----
--BEGIN
----
---- Gather transaction log entries
--EXEC('USE ' + @dbname + ' select Top 1000 ' +  '''' + @dbname + '''' + ' as ''Database'', [Current LSN], [Object Name], Operation, [Transaction ID], [Page ID], [Slot ID], [Offset in Row], [Server UID], SPID, [Begin Time], [Transaction Name], [End Time] from ::fn_dblog(null, null) order by [Current LSN]')
----
--FETCH NEXT FROM CUR_getdbusr INTO @dbname
--END
--
--CLOSE CUR_getdbusr
--DEALLOCATE CUR_getdbusr
--
-- Log and exit script
--GOTO LOG_EXIT
--END
----
--ELSE
--
-- Verify if server is running SQL Server 2005 or 2008
--IF ((CONVERT(char(20), SERVERPROPERTY('productversion')) LIKE '11.00%') OR (CONVERT(char(20), SERVERPROPERTY('productversion')) LIKE '9.0%'))
--BEGIN
--
-- Gather Transaction Log entries
--
--
DECLARE CUR_getdbusr CURSOR READ_ONLY FOR 
select [name] from sys.sysdatabases where dbid <60;
OPEN CUR_getdbusr
--
FETCH NEXT FROM CUR_getdbusr INTO @dbname
WHILE @@FETCH_STATUS = 0
--
BEGIN
--
-- Gather transaction log entries
EXEC ('USE ' + @dbname + ' select Top 1000 ' + '''' + @dbname + '''' + ' as ''Database'', [Current LSN], Operation, [Transaction ID], [AllocUnitName], [Page ID], [Slot ID], [Offset in Row], [Server UID], SPID, [Begin Time], [Transaction Name], [Transaction SID], [End Time], [Description], [RowLog Contents 0], [RowLog Contents 1], [RowLog Contents 2], [RowLog Contents 3], [RowLog Contents 4] from ::fn_dblog(null, null) order by [Current LSN]')
FETCH NEXT FROM CUR_getdbusr INTO @dbname
END
--
CLOSE CUR_getdbusr
DEALLOCATE CUR_getdbusr
--
LOG_EXIT:
-- Log connection information
PRINT ''
PRINT ''
PRINT ''
PRINT '************************************************************************************************************************************'
PRINT 'User: ' + suser_sname() +' | Script: SSFA_Tlog.sql | SPID: ' + CAST(@@SPID AS VARCHAR(5)) + ' | Closed on ' + CAST(GETDATE() AS VARCHAR(30))
PRINT '************************************************************************************************************************************'
-- Exit script
RETURN
--END
--
