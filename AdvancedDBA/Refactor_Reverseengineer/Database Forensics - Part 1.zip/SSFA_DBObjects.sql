-- 
-- Source: SQL Server Forensic Analysis
-- Author: Kevvie Fowler
-- Script: SSFA_DbObjects.sql - Gathers SQL Server 2000, 2005 and 2008 database objects
-- 
--
-- Verify if server is running SQL Server 2000, if so gather data, otherwise jump to next version check
DECLARE 	@dbname varchar(100)
DECLARE 	@tstring varchar(4000)
DECLARE		@fpass bit

SET @tstring = ''
SET @FPASS = 0

--IF CONVERT(char(20), SERVERPROPERTY('productversion')) LIKE '8.00%'
--BEGIN
----
---- Gather objects
----
----
--DECLARE CUR_getdbobj CURSOR READ_ONLY FOR 
--select [name] from master..sysdatabases;
--OPEN CUR_getdbobj
----
--FETCH NEXT FROM CUR_getdbobj INTO @dbname
--WHILE @@FETCH_STATUS = 0
----
--BEGIN
--IF (@FPASS = 1) SET @tstring = @tstring + ' UNION ALL ' 
--SET @tstring = @tstring + ' select ' + '''' + @dbname + '''' + ' COLLATE Latin1_General_CI_AS as ''database'', [name] COLLATE Latin1_General_CI_AS, id, crdate, refdate, xtype COLLATE Latin1_General_CI_AS, '' '' as ''type_desc'',  1 as ''schema_id'',  '' '' as ''is_ms_shipped'' from ' + @dbname + '..sysobjects'
--SET @FPASS = 1
--FETCH NEXT FROM CUR_getdbobj INTO @dbname
--END
--set @tstring = @tstring + ' order by [database], [crdate] DESC, [name] COLLATE Latin1_General_CI_AS DESC'
--EXEC (@tstring)
----
--CLOSE CUR_getdbobj
--DEALLOCATE CUR_getdbobj
----
---- Log and exit script 
--GOTO LOG_EXIT
--END
----
--ELSE
--
-- Verify if server is running SQL Server 2005 or 2008
IF ((CONVERT(char(20), SERVERPROPERTY('productversion')) LIKE '11.00%') OR (CONVERT(char(20), SERVERPROPERTY('productversion')) LIKE '12.0%'))
BEGIN
--
-- Gather databases
--
--
DECLARE CUR_getdbobj CURSOR READ_ONLY FOR 
select [name] from sys.sysdatabases;
OPEN CUR_getdbobj
--
FETCH NEXT FROM CUR_getdbobj INTO @dbname
WHILE @@FETCH_STATUS = 0
--
-- Gather objects
BEGIN
IF (@FPASS = 1) SET @tstring = @tstring + ' UNION ALL ' 
SET @tstring = @tstring + ' SELECT ' + '''' + @dbname + '''' + ' as ''database'', [name] COLLATE Latin1_General_CI_AS, object_id, create_date, modify_date, type, type_desc, schema_id, is_ms_shipped from ' + @dbname + '.sys.objects'
SET @FPASS = 1
FETCH NEXT FROM CUR_getdbobj INTO @dbname
END
-- Gather Resource database information 
set @tstring = @tstring + ' UNION ALL SELECT ''MsSQLSystemResourcedb'' as ''database'', [name] COLLATE Latin1_General_CI_AS, object_id, create_date, modify_Date, type, type_desc, schema_id, is_ms_shipped from master.sys.system_objects '
-- Sort results
set @tstring = @tstring + ' order by [database], [create_date] DESC, [name] COLLATE Latin1_General_CI_AS DESC'
EXEC (@tstring)
CLOSE CUR_getdbobj
DEALLOCATE CUR_getdbobj
LOG_EXIT:
-- Log connection information
PRINT ''
PRINT ''
PRINT ''
PRINT '************************************************************************************************************************************'
PRINT 'User: ' + suser_sname() +' | Script: SSFA_DBObjects.sql | SPID: ' + CAST(@@SPID AS VARCHAR(5)) + ' | Closed on ' + CAST(GETDATE() AS VARCHAR(30))
PRINT '************************************************************************************************************************************'
-- Exit script 
RETURN
END
--
--select * from sys.system_objects where-- type='u'
-- is_ms_shipped=0

--select * from sys.sysobjects where type='u'