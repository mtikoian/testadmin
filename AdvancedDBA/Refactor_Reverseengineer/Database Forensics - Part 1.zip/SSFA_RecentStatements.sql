-- 
-- Source: SQL Server Forensic Analysis
-- Author: Kevvie Fowler
-- Script: SSFA_RecentStatements.sql - Gathers most recently executed SQL statement for each active SQL Server 2000, 2005 & 2008 connection 
-- 
--
DECLARE @lb varchar (50)
DECLARE @spid int
DECLARE @dbname varchar (115)
DECLARE @string NVARCHAR(4000)
DECLARE @execstr NVARCHAR(4000)
DECLARE @handle binary(20)
DECLARE @login nvarchar (100)
--
-- Verify if server is running SQL Server 2000, if so gather data, otherwise jump to next version check
IF CONVERT(char(20), SERVERPROPERTY('productversion')) LIKE '8.00%'
BEGIN
-- Gather MRE TSQL statement
DECLARE CUR_getspidsql CURSOR READ_ONLY FOR 
select spo.spid, sdb.[name], spo.last_batch, RTRIM(loginame) from master..sysprocesses spo, master..sysdatabases sdb where spo.dbid = sdb.dbid and spid > 50 ORDER BY SPID
OPEN CUR_getspidsql
--
FETCH NEXT FROM CUR_getspidsql INTO @spid, @dbname, @lb, @login
WHILE @@FETCH_STATUS = 0
--
BEGIN


SELECT @execstr = 'DBCC INPUTBUFFER(' + CAST(@spid AS VARCHAR) + ')' + 
ISNULL(@execstr + CHAR(13), '' + @String + '') + 'DBCC INPUTBUFFER(' + CAST(@spid AS VARCHAR) + ')'
SELECT 'Database: ' + @dbname + ' | ' + 'SPID: ' + CAST(@spid AS VARCHAR) + ' | ' + 'Login: ' + @login + ' | ' + 'Execution time: ' + @lb
DBCC INPUTBUFFER (@spid)
--
FETCH NEXT FROM CUR_getspidsql INTO @spid, @dbname, @lb, @login
END
--
CLOSE CUR_getspidsql
DEALLOCATE CUR_getspidsql
-- Log and exit script
GOTO LOG_EXIT
END
--

ELSE
--
-- Verify if server is running SQL Server 2005 or 2008
IF ((CONVERT(char(20), SERVERPROPERTY('productversion')) LIKE '12.0%') OR (CONVERT(char(20), SERVERPROPERTY('productversion')) LIKE '10.5%'))
BEGIN
--
-- Gather MRE TSQL statement
DECLARE CUR_getspidsql CURSOR READ_ONLY FOR 
select spo.sql_handle, spo.spid, sdb.[name] from sys.sysprocesses spo, sys.sysdatabases sdb where spo.dbid = sdb.dbid and spo.sql_handle <> 0x0000000000000000000000000000000000000000 ORDER BY SPID;
OPEN CUR_getspidsql
--
FETCH NEXT FROM CUR_getspidsql INTO @handle, @spid, @dbname
WHILE @@FETCH_STATUS = 0
--
BEGIN
SELECT @dbname as 'Database', @SPID as 'SPID', syp.loginame, [Text] as 'Statement Syntax', cmd as 'Active command',  Login_time, syp.Last_batch as 'Time_of_last_batch'  from ::fn_get_sql(@handle) fgs, sys.sysprocesses syp where syp.spid = @SPID and @dbname='eas'
FETCH NEXT FROM CUR_getspidsql INTO @handle, @spid, @dbname
END
--
CLOSE CUR_getspidsql
DEALLOCATE CUR_getspidsql
--
LOG_EXIT:
-- Log connection information
PRINT ''
PRINT ''
PRINT ''
PRINT '************************************************************************************************************************************'
PRINT 'User: ' + suser_sname() +' | Script: SSFA_RecentStatements.sql | SPID: ' + CAST(@@SPID AS VARCHAR(5)) + ' | Closed on ' + CAST(GETDATE() AS VARCHAR(30))
PRINT '************************************************************************************************************************************'
-- Exit script
RETURN
END
--
