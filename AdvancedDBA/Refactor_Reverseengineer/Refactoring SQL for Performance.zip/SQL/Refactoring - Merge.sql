-- Loans table
CREATE TABLE Loans (
 loan_nbr INT NOT NULL,
 customer_nbr INT NOT NULL,
 loan_date DATETIME NOT NULL,
 loan_amount DECIMAL(15, 2) NOT NULL,
 loan_type VARCHAR(10) NOT NULL,
 CONSTRAINT ck_loan_type
 CHECK (loan_type IN ('personal', 'business')),
 CONSTRAINT pk_loans
 PRIMARY KEY (loan_nbr));
 
INSERT INTO Loans 
(loan_nbr, customer_nbr, loan_date, loan_amount, loan_type)
VALUES(1, 1, '20080101', 1500.00, 'personal'); 
INSERT INTO Loans 
(loan_nbr, customer_nbr, loan_date, loan_amount, loan_type)
VALUES(2, 2, '20080215', 1000.00, 'personal');
INSERT INTO Loans 
(loan_nbr, customer_nbr, loan_date, loan_amount, loan_type)
VALUES(3, 1, '20080311', 5000.00, 'business');

SELECT loan_nbr, customer_nbr, loan_date, loan_amount, loan_type
FROM Loans;

/*

loan_nbr    customer_nbr loan_date               loan_amount    loan_type
----------- ------------ ----------------------- -------------- ----------
2           2            2008-02-15 00:00:00.000 1000.00        personal
3           1            2008-03-11 00:00:00.000 4500.00        business
4           3            2008-03-12 00:00:00.000 2000.00        personal

*/


-- Daily changes
CREATE TABLE DailyChangedLoans (
 loan_nbr INT NOT NULL,
 customer_nbr INT NOT NULL,
 loan_date DATETIME NOT NULL,
 loan_amount DECIMAL(15, 2) NOT NULL,
 loan_type VARCHAR(10) NOT NULL,
 CONSTRAINT ck_dailychangedloan_type
 CHECK (loan_type IN ('personal', 'business')),
 CONSTRAINT pk_dailychangedloans
 PRIMARY KEY (loan_nbr));
 
INSERT INTO DailyChangedLoans 
(loan_nbr, customer_nbr, loan_date, loan_amount, loan_type)
VALUES(2, 2, '20080215', 1000.00, 'personal');
INSERT INTO DailyChangedLoans 
(loan_nbr, customer_nbr, loan_date, loan_amount, loan_type)
VALUES(3, 1, '20080311', 4500.00, 'business');
INSERT INTO DailyChangedLoans 
(loan_nbr, customer_nbr, loan_date, loan_amount, loan_type)
VALUES(4, 3, '20080312', 2000.00, 'personal');

SELECT loan_nbr, customer_nbr, loan_date, loan_amount, loan_type
FROM DailyChangedLoans;

/*

loan_nbr    customer_nbr loan_date               loan_amount    loan_type
----------- ------------ ----------------------- -------------- ----------
2           2            2008-02-15 00:00:00.000 1000.00        personal
3           1            2008-03-11 00:00:00.000 4500.00        business
4           3            2008-03-12 00:00:00.000 2000.00        personal

*/

-- Loan #1 deleted
-- Loan #2 no changes
-- Loan #3 amount changed
-- Loan #4 new loan

/*

Expected results:

loan_nbr    customer_nbr loan_date   loan_amount   loan_type
----------- ------------ ----------- ------------- ----------
2           2            2008-02-15  1000.00       personal
3           1            2008-03-11  4500.00       business
4           3            2008-03-12  2000.00       personal

*/

GO

BEGIN TRANSACTION;

-- SQL Server 2000 solution to merge both tables
-- requires 3 queries

-- Update changed
UPDATE Loans
SET loan_amount = (SELECT D.loan_amount
                   FROM DailyChangedLoans AS D
                   WHERE D.loan_nbr = Loans.loan_nbr
                     AND D.loan_amount <> Loans.loan_amount)
WHERE EXISTS(SELECT *
             FROM DailyChangedLoans AS D
             WHERE D.loan_nbr = Loans.loan_nbr
               AND D.loan_amount <> Loans.loan_amount);

-- Insert new loans
INSERT INTO Loans
(loan_nbr, customer_nbr, loan_date, loan_amount, loan_type)
SELECT loan_nbr, 
       customer_nbr, 
       loan_date, 
       loan_amount, 
       loan_type
FROM DailyChangedLoans AS D
WHERE NOT EXISTS(SELECT *
                 FROM Loans AS L
                 WHERE D.loan_nbr = L.loan_nbr);
                 
-- Remove deleted
DELETE FROM Loans
WHERE NOT EXISTS(SELECT *
                 FROM DailyChangedLoans AS D
                 WHERE D.loan_nbr = Loans.loan_nbr);

SELECT loan_nbr, customer_nbr, loan_date, loan_amount, loan_type
FROM Loans;

ROLLBACK;
       
BEGIN TRANSACTION;

-- Using a single MERGE statement in SQL Server 2008
MERGE INTO Loans AS L
USING DailyChangedLoans AS D
   ON D.loan_nbr = L.loan_nbr
WHEN MATCHED
 AND L.loan_amount <> D.loan_amount
THEN UPDATE SET loan_amount = D.loan_amount
WHEN NOT MATCHED
THEN INSERT VALUES(D.loan_nbr, 
                   D.customer_nbr, 
                   D.loan_date, 
                   D.loan_amount, 
                   D.loan_type)
WHEN NOT MATCHED BY SOURCE
THEN DELETE;

SELECT loan_nbr, customer_nbr, loan_date, loan_amount, loan_type
FROM Loans;

ROLLBACK;
                             
GO

DROP TABLE Loans;
DROP TABLE DailyChangedLoans;
 