CREATE TABLE Loans (
 loan_nbr INT NOT NULL,
 customer_nbr INT NOT NULL,
 loan_date DATETIME NOT NULL,
 loan_amount DECIMAL(15, 2) NOT NULL,
 loan_type VARCHAR(10) NOT NULL,
 CONSTRAINT ck_loan_type
 CHECK (loan_type IN ('personal', 'business')),
 CONSTRAINT pk_loans
 PRIMARY KEY (loan_nbr));
 
INSERT INTO Loans 
(loan_nbr, customer_nbr, loan_date, loan_amount, loan_type)
VALUES(1, 1, '20080101', 1500.00, 'personal'); 
INSERT INTO Loans 
(loan_nbr, customer_nbr, loan_date, loan_amount, loan_type)
VALUES(2, 2, '20080102', 1000.00, 'personal');
INSERT INTO Loans 
(loan_nbr, customer_nbr, loan_date, loan_amount, loan_type)
VALUES(3, 1, '20080103', 5000.00, 'business');
INSERT INTO Loans
(loan_nbr, customer_nbr, loan_date, loan_amount, loan_type)
VALUES(4, 3, '20080112', 2000.00, 'personal');
INSERT INTO Loans 
(loan_nbr, customer_nbr, loan_date, loan_amount, loan_type)
VALUES(5, 4, '20080113', 1200.00, 'personal');
INSERT INTO Loans 
(loan_nbr, customer_nbr, loan_date, loan_amount, loan_type)
VALUES(6, 3, '20080129', 4000.00, 'business');
INSERT INTO Loans 
(loan_nbr, customer_nbr, loan_date, loan_amount, loan_type)
VALUES(7, 5, '20080130', 3500.00, 'business');
INSERT INTO Loans 
(loan_nbr, customer_nbr, loan_date, loan_amount, loan_type)
VALUES(8, 2, '20080131', 2000.00, 'personal');

SELECT loan_nbr, customer_nbr, loan_date, loan_amount, loan_type
FROM Loans;

/*

loan_nbr    customer_nbr loan_date               loan_amount   loan_type
----------- ------------ ----------------------- ------------- ----------
1           1            2008-01-01 00:00:00.000 1500.00       personal
2           2            2008-01-02 00:00:00.000 1000.00       personal
3           1            2008-01-03 00:00:00.000 5000.00       business
4           3            2008-01-12 00:00:00.000 2000.00       personal
5           4            2008-01-13 00:00:00.000 1200.00       personal
6           3            2008-01-29 00:00:00.000 4000.00       business
7           5            2008-01-30 00:00:00.000 3500.00       business
8           2            2008-01-31 00:00:00.000 2000.00       personal

*/

GO

/*

Expected results:

start_date  end_date
----------- -----------
2008-01-01  2008-01-03 
2008-01-12  2008-01-13 
2008-01-29  2008-01-31 

*/

-- Find ranges of consecutive dates when loans exist
-- SQL server 2000 solution
SELECT MIN(loan_date) AS start_date,
       MAX(loan_date) AS end_date
FROM (SELECT loan_date,
            (SELECT MIN(L2.loan_date) 
             FROM Loans AS L2
             WHERE L2.loan_date >= L1.loan_date
               AND NOT EXISTS
                  (SELECT *
                   FROM Loans AS L3
                   WHERE L3.loan_date = 
                         DATEADD(DAY, 1, L2.loan_date))) AS base
      FROM Loans AS L1) AS L
GROUP BY base;

-- Preparation for solution
SELECT loan_date,
       DATEDIFF(DAY, '19000101', loan_date) AS days_since_base_date,
       ROW_NUMBER() OVER(ORDER BY loan_date) AS rn
FROM Loans;

/*

Results from prep query:

loan_date   days_since_base_date rn
----------- -------------------- ---
2008-01-01  39446                1
2008-01-02  39447                2
2008-01-03  39448                3
2008-01-12  39457                4
2008-01-13  39458                5
2008-01-29  39474                6
2008-01-30  39475                7
2008-01-31  39476                8

*/
      
-- Solution with ROW_NUMBER      
SELECT MIN(loan_date) AS start_date,
       MAX(loan_date) AS end_date 
FROM (SELECT loan_date,
             DATEDIFF(DAY, '19000101', loan_date) -
             ROW_NUMBER() OVER(ORDER BY loan_date) AS base
      FROM Loans) AS L
GROUP BY base; 
      
GO

DROP TABLE Loans;