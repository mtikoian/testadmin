-- EAV table
CREATE TABLE EAV_Loans (
 loan_nbr INT NOT NULL,
 customer_nbr INT NOT NULL,
 code VARCHAR(30) NOT NULL,
 value VARCHAR(200),
 CONSTRAINT pk_eav_loans
 PRIMARY KEY (loan_nbr, customer_nbr, code));
 
INSERT INTO EAV_Loans 
(loan_nbr, customer_nbr, code, value)
VALUES(1, 1, 'date', '20080110'); 
INSERT INTO EAV_Loans 
(loan_nbr, customer_nbr, code, value)
VALUES(1, 1, 'amount', '1500.00');
INSERT INTO EAV_Loans 
(loan_nbr, customer_nbr, code, value)
VALUES(1, 1, 'type', 'personal');
INSERT INTO EAV_Loans 
(loan_nbr, customer_nbr, code, value)
VALUES(2, 2, 'date', '20080215'); 
INSERT INTO EAV_Loans 
(loan_nbr, customer_nbr, code, value)
VALUES(2, 2, 'amount', '3500.00');
INSERT INTO EAV_Loans 
(loan_nbr, customer_nbr, code, value)
VALUES(2, 2, 'type', 'personal');

SELECT loan_nbr, customer_nbr, code, value
FROM EAV_Loans;

/*

loan_nbr    customer_nbr code      value
----------- ------------ --------- ----------
1           1            amount    1500.00
1           1            date      20080110
1           1            type      personal
2           2            amount    3500.00
2           2            date      20080215
2           2            type      personal


*/

GO

-- Customers with personal loans over 1000.00 for the period
-- Jan 1, 2008 through Jan 31, 2008
SELECT A.loan_nbr, 
       A.customer_nbr,
       CAST(A.value AS DATETIME) AS loan_date,
       CAST(B.value AS DECIMAL(15, 2)) AS loan_amount
FROM EAV_Loans AS A
INNER JOIN EAV_Loans AS B
   ON A.loan_nbr = B.loan_nbr
  AND A.customer_nbr = B.customer_nbr
INNER JOIN EAV_Loans AS C
   ON A.loan_nbr = C.loan_nbr
  AND A.customer_nbr = C.customer_nbr
WHERE A.code = 'date'
  AND CAST(A.value AS DATETIME) >= '20080101'
  AND CAST(A.value AS DATETIME) <  '20080201'
  AND B.code = 'amount'
  AND CAST(B.value AS DECIMAL(15, 2)) > 1000.00
  AND C.code = 'type'
  AND C.value = 'personal';

-- Even using table expressions can result in conversion errors
SELECT A.loan_nbr, 
       A.customer_nbr,
       loan_date,
       loan_amount
FROM (SELECT loan_nbr, customer_nbr, 
             CAST(value AS DATETIME) AS loan_date
      FROM EAV_Loans
      WHERE code = 'date') AS A
INNER JOIN (SELECT loan_nbr, customer_nbr, 
                   CAST(value AS DECIMAL(15, 2)) AS loan_amount
            FROM EAV_Loans
            WHERE code = 'amount') AS B
   ON A.loan_nbr = B.loan_nbr
  AND A.customer_nbr = B.customer_nbr
INNER JOIN (SELECT loan_nbr, customer_nbr, 
                   value AS loan_type
            FROM EAV_Loans
            WHERE code = 'type') AS C
   ON A.loan_nbr = C.loan_nbr
  AND A.customer_nbr = C.customer_nbr
WHERE loan_date >= '20080101'
  AND loan_date <  '20080201'
  AND loan_amount > 1000.00
  AND loan_type = 'personal';

-- Using pivoting to query EAV table
-- Logically correct query to avoid conversion errors
-- because query engine is free to rearrange predicates 
-- and execute in any order it finds efficient
SELECT loan_nbr, 
       customer_nbr,
       loan_date,
       loan_amount
FROM (SELECT loan_nbr,
             customer_nbr,
             MAX(CASE WHEN code = 'date' THEN CAST(value AS DATETIME) END),
             MAX(CASE WHEN code = 'amount' THEN CAST(value AS DECIMAL(15, 2)) END),
             MAX(CASE WHEN code = 'type' THEN value END)
      FROM EAV_Loans
      GROUP BY loan_nbr, customer_nbr
      ) AS L(loan_nbr, customer_nbr, loan_date, loan_amount, loan_type)
WHERE loan_date >= '20080101'
  AND loan_date <  '20080201'
  AND loan_amount > 1000.00
  AND loan_type = 'personal';    

GO

-- Normalized table
CREATE TABLE Loans (
 loan_nbr INT NOT NULL,
 customer_nbr INT NOT NULL,
 loan_date DATETIME NOT NULL,
 loan_amount DECIMAL(15, 2) NOT NULL,
 loan_type VARCHAR(10) NOT NULL,
 CONSTRAINT ck_loan_type
 CHECK (loan_type IN ('personal', 'business')),
 CONSTRAINT pk_loans
 PRIMARY KEY (loan_nbr));

GO

-- Convert EAV table to normalized
INSERT INTO Loans 
(loan_nbr, customer_nbr, loan_date, loan_amount, loan_type)
SELECT loan_nbr,
       customer_nbr,
       MAX(CASE WHEN code = 'date' THEN CAST(value AS DATETIME) END),
       MAX(CASE WHEN code = 'amount' THEN CAST(value AS DECIMAL(15, 2)) END),
       MAX(CASE WHEN code = 'type' THEN value END)
FROM EAV_Loans
GROUP BY loan_nbr, customer_nbr;

SELECT loan_nbr, customer_nbr, loan_date, loan_amount, loan_type
FROM Loans;

-- Customers with personal loans over 1000.00 for the period
-- Jan 1, 2008 through Jan 31, 2008
SELECT loan_nbr, customer_nbr, loan_date, loan_amount
FROM Loans
WHERE loan_date >= '20080101'
  AND loan_date <  '20080201'
  AND loan_amount > 1000.00
  AND loan_type = 'personal';
  
GO

DROP TABLE EAV_Loans;

GO

-- Replacement view for legacy code
CREATE VIEW EAV_Loans
(loan_nbr, customer_nbr, code, value)
AS 
SELECT loan_nbr, customer_nbr, 
       CAST('date' AS VARCHAR(30)), 
       CONVERT(VARCHAR(200), loan_date, 112)
FROM Loans
UNION
SELECT loan_nbr, customer_nbr, 
       CAST('amount' AS VARCHAR(30)), 
       CAST(loan_amount AS VARCHAR(200))
FROM Loans
UNION
SELECT loan_nbr, customer_nbr, 
       CAST('type' AS VARCHAR(30)), 
       CAST(loan_type AS VARCHAR(200))
FROM Loans;

GO

SELECT loan_nbr, customer_nbr, code, value
FROM EAV_Loans;

GO

DROP VIEW EAV_Loans;

GO

DROP TABLE Loans;

