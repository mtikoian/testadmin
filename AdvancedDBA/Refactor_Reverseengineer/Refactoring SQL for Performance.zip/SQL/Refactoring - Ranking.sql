CREATE TABLE Loans (
 loan_nbr INT NOT NULL,
 customer_nbr INT NOT NULL,
 loan_date DATETIME NOT NULL,
 loan_amount DECIMAL(15, 2) NOT NULL,
 loan_type VARCHAR(10) NOT NULL,
 CONSTRAINT ck_loan_type
 CHECK (loan_type IN ('personal', 'business')),
 CONSTRAINT pk_loans
 PRIMARY KEY (loan_nbr));
 
INSERT INTO Loans 
(loan_nbr, customer_nbr, loan_date, loan_amount, loan_type)
VALUES(1, 1, '20080101', 1500.00, 'personal'); 
INSERT INTO Loans 
(loan_nbr, customer_nbr, loan_date, loan_amount, loan_type)
VALUES(2, 2, '20080215', 1000.00, 'personal');
INSERT INTO Loans 
(loan_nbr, customer_nbr, loan_date, loan_amount, loan_type)
VALUES(3, 1, '20080311', 5000.00, 'business');
INSERT INTO Loans 
(loan_nbr, customer_nbr, loan_date, loan_amount, loan_type)
VALUES(4, 3, '20080312', 2000.00, 'personal');
INSERT INTO Loans 
(loan_nbr, customer_nbr, loan_date, loan_amount, loan_type)
VALUES(5, 4, '20080325', 1200.00, 'personal');
INSERT INTO Loans 
(loan_nbr, customer_nbr, loan_date, loan_amount, loan_type)
VALUES(6, 3, '20080327', 4000.00, 'business');
INSERT INTO Loans 
(loan_nbr, customer_nbr, loan_date, loan_amount, loan_type)
VALUES(7, 5, '20080410', 3500.00, 'business');
INSERT INTO Loans 
(loan_nbr, customer_nbr, loan_date, loan_amount, loan_type)
VALUES(8, 2, '20080412', 2000.00, 'personal');

GO
/*

Expected result set:

loan_nbr    loan_date   loan_amount   loan_type  rk
----------- ----------- ------------- ---------- ----
3           2008-03-11  5000.00       business   1
6           2008-03-27  4000.00       business   2
7           2008-04-10  3500.00       business   3
4           2008-03-12  2000.00       personal   1
8           2008-04-12  2000.00       personal   2
1           2008-01-01  1500.00       personal   3
5           2008-03-25  1200.00       personal   4
2           2008-02-15  1000.00       personal   5

*/

-- Good index for ranking functions is 
-- on partitioning and order by columns
-- as well as covered columns
CREATE INDEX ix_Loans
ON Loans (loan_type, loan_amount DESC, loan_nbr, loan_date);

-- SQL Server 2000 ranking solution
-- Rank loans by amount based on loan type
-- Use loan number as tie breaker
SELECT loan_nbr, loan_date, loan_amount, loan_type, 
      (SELECT COUNT(*)
       FROM Loans AS L2
       WHERE L2.loan_type = L1.loan_type
         AND (L2.loan_amount > L1.loan_amount
          OR  L2.loan_amount = L1.loan_amount
         AND  L2.loan_nbr <= L1.loan_nbr)) AS rk
FROM Loans AS L1
ORDER BY loan_type, rk;

-- SQL Server 2005/2008 solution utilizing
-- analytical ranking functions
SELECT loan_nbr, loan_date, loan_amount, loan_type, 
       ROW_NUMBER() OVER(PARTITION BY loan_type
                         ORDER BY loan_amount DESC,
                                  loan_nbr) AS rk
FROM Loans AS L1
ORDER BY loan_type, rk;

GO

DROP TABLE Loans; 