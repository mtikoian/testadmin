-------------------	-------------------	-------------------	-------------------	
-------------------	-------------------	-------------------	-------------------	
-- Implicit Conversion Demo
-- Author: Mickey Stuewe
-------------------	-------------------	-------------------	-------------------	
-------------------	-------------------	-------------------	-------------------	

-------------------	-------------------	-------------------	-------------------	
--Example 1 -- not to different...except for CPU usage.
-------------------	-------------------	-------------------	-------------------	

USE DemoProgramming
go

SET STATISTICS IO ON
SET STATISTICS TIME ON;
go 
--1 million rows
SELECT TOP 10
    TestDataID
    ,SomeText
    ,SomeTextNumber
	,SomeDate
    ,SomeDateText
FROM
    testdata

SELECT TOP 10
    DateValue
   ,DateMonth
   ,DateYear
   ,DateDay
   ,DateQuarter
FROM
    dbo.DimDate
WHERE
	DateYear = 2005;

SELECT
	TestDataID
	,SomeText
	,SomeDate
	,SomeDateText
	,DateValue
	,DateYear
FROM
	dbo.TestData AS td
	JOIN dbo.dimdate AS dd ON td.SomeDate = dd.datevalue
WHERE
	dd.dateyear = 2005


SELECT
	TestDataID
	,SomeText
	,SomeDate
	,SomeDateText
	,DateValue
	,DateYear
FROM
	dbo.TestData AS td
	JOIN dbo.dimdate AS dd ON td.SomeDateText = dd.datevalue
WHERE
	dd.dateyear = 2005

-------------------	-------------------	-------------------	-------------------	
--Example 2 -- No data
-------------------	-------------------	-------------------	-------------------	

SELECT
	TestDataID
	,SomeDate
	,SomeDateText
	,DateValue
	,DateYear
FROM
	dbo.TestData AS td
	JOIN dbo.dimdate AS dd ON td.SomeDate = dd.datevalue
WHERE
	td.SomeDate BETWEEN '1/1/2005' AND '12/31/2005'


SELECT
	TestDataID
	,SomeDate
	,SomeDateText
	,DateValue
	,DateYear
FROM
	dbo.TestData AS td
	JOIN dbo.dimdate AS dd ON td.SomeDateText = dd.datevalue
WHERE
	td.SomeDateText BETWEEN '1/1/2005' AND '12/31/2005'


-------------------	-------------------	-------------------	-------------------	
--Example 3 -- Different data
-------------------	-------------------	-------------------	-------------------	

SELECT
	TestDataID
	,SomeText
	,SomeTextNumber
FROM
	dbo.TestData AS td
WHERE
	SomeText BETWEEN '0100' AND '2000'
--	AND testdataid =320

SELECT
	TestDataID
	,SomeText
	,SomeTextNumber
FROM
	dbo.TestData AS td
WHERE
	SomeTextNumber BETWEEN 0100 AND 2000
--	AND testdataid =320