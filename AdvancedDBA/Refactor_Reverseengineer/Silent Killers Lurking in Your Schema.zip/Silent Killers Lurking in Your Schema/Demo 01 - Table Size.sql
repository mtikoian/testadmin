------------------------------------------
------------------------------------------
/*				Clean UP!				*/
------------------------------------------
------------------------------------------

USE DataModel_Bad
go
DBCC DBREINDEX ('Client.Customer','')

USE DataModel_Good
go
DBCC DBREINDEX ('Client.Customer','')
ALTER TABLE [Client].[Customer] DROP CONSTRAINT [UX_Customer_AccountNumber]
GO
------------------------------------------
------------------------------------------
/*				Demo 1					*/
------------------------------------------
------------------------------------------

USE DataModel_Bad
GO
SELECT TOP 10 * FROM Client.customer
SELECT COUNT(*) Row_Count FROM Client.customer
GO

USE DataModel_Good
GO
SELECT TOP 10 * FROM Client.customer
SELECT COUNT(*) ROW_COUNT FROM Client.customer
GO

------------------------------------------
------------------------------------------
/*				Demo 2					*/
------------------------------------------
------------------------------------------

USE DataModel_Bad
GO
EXEC sp_spaceused N'Client.customer'
GO

USE DataModel_Good
GO
EXEC sp_spaceused N'Client.customer'
GO

------------------------------------------
------------------------------------------
/*				Demo 2					*/
------------------------------------------
-----------------------------------------

USE DataModel_Bad
GO
EXEC sp_spaceused N'Client.customer'
GO

USE DataModel_bad
GO
/* ***********************************************************************************
Purpose:    Lists all indexes for a table
Author:     mickey stuewe www.mickeystuewe.com
Date:       12/6/2013
************************************************************************************ */
SELECT
	i.name AS IndexName
	,i.type_desc
	,STUFF(Indexed.ColumnList, 1, 1, '') AS IndexColumnList
	,STUFF(Included.ColumnList, 1, 1, '') AS IncludeColumnList
	,i.filter_definition
	,i.fill_factor
FROM
	sys.indexes AS i
	OUTER APPLY
			(
				SELECT
					',' +  CASE 
							WHEN ic.is_descending_key = 1 THEN col.name + ' DESC'
							ELSE col.name  
							END 
				FROM
					sys.index_columns AS ic 
					INNER JOIN sys.columns col ON ic.object_id = col.object_id
													AND ic.column_id = col.column_id
				WHERE
					ic.index_id = i.index_id
					AND ic.object_id =  i.object_id
					AND ic.is_included_column = 0
				ORDER BY
					ic.index_column_id
				FOR XML	PATH('')
			) AS Indexed(ColumnList)
	OUTER APPLY
			(
				SELECT
					',' +  CASE 
							WHEN ic.is_descending_key = 1 THEN col.name + ' DESC'
							ELSE col.name  
							END 
				FROM
					sys.index_columns AS ic 
					INNER JOIN sys.columns col ON ic.object_id = col.object_id
													AND ic.column_id = col.column_id
				WHERE
					ic.index_id = i.index_id
					AND ic.object_id =  i.object_id
					AND ic.is_included_column = 1
				ORDER BY
					ic.index_column_id
				FOR XML	PATH('')
			) AS Included(ColumnList)
WHERE
	i.object_id =  OBJECT_ID(N'Client.Customer')
ORDER BY
	i.type_desc
	,Indexed.ColumnList
GO

USE DataModel_Good
GO
EXEC sp_spaceused N'Client.customer'
GO

--http://sqlserverzest.com/2013/06/28/sql-server-understanding-sp_spaceused-results-for-database-size-information/


USE DataModel_Good
GO
/* ***********************************************************************************
Purpose:    Lists all indexes for a table
Author:     mickey stuewe www.mickeystuewe.com
Date:       12/6/2013
************************************************************************************ */
SELECT
	i.name AS IndexName
	,i.type_desc
	,STUFF(Indexed.ColumnList, 1, 1, '') AS IndexColumnList
	,STUFF(Included.ColumnList, 1, 1, '') AS IncludeColumnList
	,i.filter_definition
	,i.fill_factor
FROM
	sys.indexes AS i
	OUTER APPLY
			(
				SELECT
					',' +  CASE 
							WHEN ic.is_descending_key = 1 THEN col.name + ' DESC'
							ELSE col.name  
							END 
				FROM
					sys.index_columns AS ic 
					INNER JOIN sys.columns col ON ic.object_id = col.object_id
													AND ic.column_id = col.column_id
				WHERE
					ic.index_id = i.index_id
					AND ic.object_id =  i.object_id
					AND ic.is_included_column = 0
				ORDER BY
					ic.index_column_id
				FOR XML	PATH('')
			) AS Indexed(ColumnList)
	OUTER APPLY
			(
				SELECT
					',' +  CASE 
							WHEN ic.is_descending_key = 1 THEN col.name + ' DESC'
							ELSE col.name  
							END 
				FROM
					sys.index_columns AS ic 
					INNER JOIN sys.columns col ON ic.object_id = col.object_id
													AND ic.column_id = col.column_id
				WHERE
					ic.index_id = i.index_id
					AND ic.object_id =  i.object_id
					AND ic.is_included_column = 1
				ORDER BY
					ic.index_column_id
				FOR XML	PATH('')
			) AS Included(ColumnList)
WHERE
	i.object_id =  OBJECT_ID(N'Client.Customer')
ORDER BY
	i.type_desc
	,Indexed.ColumnList
GO


------------------------------------------
------------------------------------------
/*				Demo 3					*/
------------------------------------------
-----------------------------------------

ALTER TABLE [Client].[Customer] ADD  CONSTRAINT [UX_Customer_AccountNumber] UNIQUE NONCLUSTERED 
(
	[AccountNumber] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 95)
GO