USE DataModel_Bad
GO

-- DROP TABLE Mystrings

CREATE TABLE MyStrings
	(
	 MystringsID int IDENTITY
	,CharString char(20)
	,VarcharString varchar(20)
	,NVarcharString nvarchar(20)
	)

GO

INSERT	INTO mystrings
		(CharString, Varcharstring, NvarcharString)
VALUES
		('Mickey', 'Mickey', 'Mickey')
	,	('Mickey     ', 'Mickey     ', 'Mickey     ')


SELECT
	*
FROM
	dbo.MyStrings AS ms

SELECT
	MystringsID
   ,CharString
   ,LEN(CharString) AS LenString
   ,DATALENGTH(CharString) AS DataLengthString
   ,VarcharString
   ,LEN(VarcharString) AS LenString
   ,DATALENGTH(VarcharString) AS DataLengthString
   ,NVarcharString
   ,LEN(NVarcharString) AS LenString
   ,DATALENGTH(NVarcharString) AS DataLengthString
FROM
	dbo.MyStrings AS ms

SELECT
	*
FROM
	dbo.MyStrings AS msChar
	JOIN dbo.MyStrings AS msVarchar ON mschar.MystringsID = msVarchar.MystringsID

SELECT
	*
FROM
	dbo.MyStrings AS msChar
	JOIN dbo.MyStrings AS msVarchar ON mschar.CharString = msVarchar.VarcharString
