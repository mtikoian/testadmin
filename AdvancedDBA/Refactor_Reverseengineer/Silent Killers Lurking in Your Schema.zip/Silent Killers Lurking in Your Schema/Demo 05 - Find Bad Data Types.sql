USE DemoProgramming;
GO

SELECT
    *
FROM
    INFORMATION_SCHEMA.COLUMNS AS c;

SELECT
    *
FROM
    INFORMATION_SCHEMA.COLUMNS AS c
WHERE
    c.DATA_TYPE = 'nvarchar'
    AND (
         c.CHARACTER_MAXIMUM_LENGTH = -1
         OR c.CHARACTER_MAXIMUM_LENGTH >= 100
        );
