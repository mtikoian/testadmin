USE DemoProgramming
GO
/* YO MICKEY! TURN ON EXECUTION PLAN*/


SET STATISTICS IO ON; 
SET STATISTICS TIME ON;

SELECT
    co.OrderStatus
   ,COUNT(OrderStatus)
FROM
    dbo.CustomerOrder AS co
GROUP BY
    OrderStatus;
GO
SELECT
    co.OrderStatus
   ,COUNT(OrderStatus)
FROM
    dbo.CustomerOrder2 AS co
GROUP BY
    OrderStatus;
GO


CREATE NONCLUSTERED INDEX IX_CustomerOrder_OrderStatus ON dbo.CustomerOrder(OrderStatus ASC)
GO
CREATE NONCLUSTERED INDEX IX_CustomerOrder2_OrderStatus ON dbo.CustomerOrder2 (OrderStatus ASC)
GO

SET STATISTICS IO OFF; 
SET STATISTICS TIME OFF;

/*

--Use Shift + Ctrl + M to set Template Parameters
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.CustomerOrder2') AND name = N'IX_CustomerOrder2_OrderStatus')
DROP INDEX IX_CustomerOrder2_OrderStatus ON dbo.CustomerOrder2 WITH ( ONLINE = OFF )
GO
--Use Shift + Ctrl + M to set Template Parameters
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.CustomerOrder') AND name = N'IX_CustomerOrder_OrderStatus')
DROP INDEX IX_CustomerOrder_OrderStatus ON dbo.CustomerOrder WITH ( ONLINE = OFF )
GO

*/