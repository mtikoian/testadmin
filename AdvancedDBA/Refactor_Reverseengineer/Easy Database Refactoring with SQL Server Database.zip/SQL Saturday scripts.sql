--SQL Saturday SSDT demo Scripts

--DimEmployee Index
CREATE INDEX [IX_DimEmployee_TwoColumn] ON [dbo].[DimEmployee] (FirstName,LastName)

--Adding columns
	[MiddleColumn]						   INT			  NULL,
	[LastColumn]						   INT			  NULL,

--Create table
CREATE TABLE [dbo].[TestTable]
(
	[Hello]		int NULL,
	[World]		int Null
)


USE SQL_Saturday

INSERT INTO [dbo].[TestTable] Values (1,1)

SELECT * FROM dbo.TestTable


--add database reference


UPDATE [dbo].[DimCustomer]
   SET [Title]		
      ,[FirstName]	
      ,[MiddleName]		
      ,[LastName]	
FROM [$(LinkedServer)].[$(AW_Source)].[SalesLT].[Customer] c
WHERE  DimCustomer.CustomerKey = c.CustomerID


--function tests
-- database unit test for dbo.udfTwoDigitZeroFill
DECLARE @RC AS CHAR (2), @number AS INT;

SELECT @RC = NULL,
       @number = 123;

SELECT @RC = [dbo].[udfTwoDigitZeroFill](@number);

SELECT @RC AS RC;


--demo of reference data

Create Proc [dbo].[Populate_SSISConfigurations]
AS
BEGIN
	Set nocount on;

CREATE TABLE #SSIS_Configurations(
	[ConfigurationFilter] [nvarchar](255) NOT NULL,
	[ConfiguredValue] [nvarchar](255) NULL,
	[PackagePath] [nvarchar](255) NOT NULL,
	[ConfiguredValueType] [nvarchar](20) NOT NULL
) ;

INSERT INTO #SSIS_Configurations (ConfigurationFilter, ConfiguredValue, PackagePath, ConfiguredValueType)
VALUES 
(N'Staging'
	 , N'' 
	 , N'\Package.Variables[Framework::ArchiveRoot].Properties[Value]' 
	 , N'String' )
, (N'Extract.SL'
	, N'\\localhost\ssis\Extract.SL.dtsx'
	, N'\Package.Connections[Extract.SL.dtsx].Properties[ConnectionString]'
	, N'String')
;


	Merge dbo.[SSIS Configurations] AS Target
	USING
		(
		SELECT 
			ConfigurationFilter
			, ConfiguredValue
			, PackagePath
			, ConfiguredValueType
		FROM #SSIS_Configurations
		)AS SOURCE
	ON
		(
			Target.ConfigurationFilter = Source.ConfigurationFilter
			AND Target.PackagePath = Source.PackagePath
		)
	WHEN Matched THEN
	UPDATE
		SET
			Target.ConfiguredValue = Source.ConfiguredValue
			, Target.ConfiguredValueType = Source.ConfiguredValueType

	WHEN NOT Matched
		THEN
		INSERT
			(
			ConfigurationFilter
			,ConfiguredValue
			,PackagePath
			,ConfiguredValueType
			)
		VALUES
			(
			Source.ConfigurationFilter
			,Source.ConfiguredValue
			,Source.PackagePath
			,Source.ConfiguredValueType
			)
	--WHEN NOT MATCHED BY SOURCE
	--	THEN DELETE;
END
GO
