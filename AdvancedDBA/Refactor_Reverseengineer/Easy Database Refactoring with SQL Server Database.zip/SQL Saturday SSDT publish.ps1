﻿

#Create Publish script
$SQLPackage = "${Env:PROGRAMFILES(X86)}\Microsoft SQL Server\110\DAC\bin\sqlpackage.exe"
$Source = "C:\Temp\SQL Saturday\SQL_Saturday\SQL_Saturday"
$OutputFile = "C:\Temp\SQLScript.sql"

& $SQLPackage /a:Script /OutputPath:$OutputFile /SourceFile:"$Source\bin\Debug\SQL_Saturday.dacpac" /Profile:"$Source\SQL_Saturday.publish.xml" /p:BlockOnPossibleDataLoss:False
& $OutputFil



#Create deploy report
$SQLPackage = "${Env:PROGRAMFILES(X86)}\Microsoft SQL Server\110\DAC\bin\sqlpackage.exe"
$Source = "C:\Temp\SQL Saturday\SQL_Saturday\SQL_Saturday"

& $SQLPackage /a:DeployReport /OutputPath:"c:\Temp\DeployReport.xml" /SourceFile:"$Source\bin\Debug\SQL_Saturday.dacpac" /Profile:"$Source\SQL_Saturday.publish.xml"
& "c:\Temp\DeployReport.xml"
