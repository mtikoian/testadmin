﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Text;
using Microsoft.Data.Tools.Schema.Sql.UnitTesting;
using Microsoft.Data.Tools.Schema.Sql.UnitTesting.Conditions;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace SQL_Saturday_Test
{
    [TestClass()]
    public class FunctionTests : SqlDatabaseTestClass
    {

        public FunctionTests()
        {
            InitializeComponent();
        }

        [TestInitialize()]
        public void TestInitialize()
        {
            base.InitializeTest();
        }
        [TestCleanup()]
        public void TestCleanup()
        {
            base.CleanupTest();
        }

        #region Designer support code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Microsoft.Data.Tools.Schema.Sql.UnitTesting.SqlDatabaseTestAction dbo_udfTwoDigitZeroFillTest_TestAction;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FunctionTests));
            Microsoft.Data.Tools.Schema.Sql.UnitTesting.Conditions.ScalarValueCondition scalarValueCondition1;
            Microsoft.Data.Tools.Schema.Sql.UnitTesting.SqlDatabaseTestAction dbo_udfTwoDigitZeroFillTest_MoreThanTwo_TestAction;
            Microsoft.Data.Tools.Schema.Sql.UnitTesting.Conditions.ScalarValueCondition scalarValueCondition2;
            Microsoft.Data.Tools.Schema.Sql.UnitTesting.SqlDatabaseTestAction dbo_idfTwoDigitZeroFillTest_MoreThanNine_TestAction;
            Microsoft.Data.Tools.Schema.Sql.UnitTesting.Conditions.ScalarValueCondition scalarValueCondition3;
            this.dbo_udfTwoDigitZeroFillTestData = new Microsoft.Data.Tools.Schema.Sql.UnitTesting.SqlDatabaseTestActions();
            this.dbo_udfTwoDigitZeroFillTest_MoreThanTwoData = new Microsoft.Data.Tools.Schema.Sql.UnitTesting.SqlDatabaseTestActions();
            this.dbo_idfTwoDigitZeroFillTest_MoreThanNineData = new Microsoft.Data.Tools.Schema.Sql.UnitTesting.SqlDatabaseTestActions();
            dbo_udfTwoDigitZeroFillTest_TestAction = new Microsoft.Data.Tools.Schema.Sql.UnitTesting.SqlDatabaseTestAction();
            scalarValueCondition1 = new Microsoft.Data.Tools.Schema.Sql.UnitTesting.Conditions.ScalarValueCondition();
            dbo_udfTwoDigitZeroFillTest_MoreThanTwo_TestAction = new Microsoft.Data.Tools.Schema.Sql.UnitTesting.SqlDatabaseTestAction();
            scalarValueCondition2 = new Microsoft.Data.Tools.Schema.Sql.UnitTesting.Conditions.ScalarValueCondition();
            dbo_idfTwoDigitZeroFillTest_MoreThanNine_TestAction = new Microsoft.Data.Tools.Schema.Sql.UnitTesting.SqlDatabaseTestAction();
            scalarValueCondition3 = new Microsoft.Data.Tools.Schema.Sql.UnitTesting.Conditions.ScalarValueCondition();
            // 
            // dbo_udfTwoDigitZeroFillTest_TestAction
            // 
            dbo_udfTwoDigitZeroFillTest_TestAction.Conditions.Add(scalarValueCondition1);
            resources.ApplyResources(dbo_udfTwoDigitZeroFillTest_TestAction, "dbo_udfTwoDigitZeroFillTest_TestAction");
            // 
            // dbo_udfTwoDigitZeroFillTestData
            // 
            this.dbo_udfTwoDigitZeroFillTestData.PosttestAction = null;
            this.dbo_udfTwoDigitZeroFillTestData.PretestAction = null;
            this.dbo_udfTwoDigitZeroFillTestData.TestAction = dbo_udfTwoDigitZeroFillTest_TestAction;
            // 
            // scalarValueCondition1
            // 
            scalarValueCondition1.ColumnNumber = 1;
            scalarValueCondition1.Enabled = true;
            scalarValueCondition1.ExpectedValue = "00";
            scalarValueCondition1.Name = "scalarValueCondition1";
            scalarValueCondition1.NullExpected = false;
            scalarValueCondition1.ResultSet = 1;
            scalarValueCondition1.RowNumber = 1;
            // 
            // dbo_udfTwoDigitZeroFillTest_MoreThanTwoData
            // 
            this.dbo_udfTwoDigitZeroFillTest_MoreThanTwoData.PosttestAction = null;
            this.dbo_udfTwoDigitZeroFillTest_MoreThanTwoData.PretestAction = null;
            this.dbo_udfTwoDigitZeroFillTest_MoreThanTwoData.TestAction = dbo_udfTwoDigitZeroFillTest_MoreThanTwo_TestAction;
            // 
            // dbo_udfTwoDigitZeroFillTest_MoreThanTwo_TestAction
            // 
            dbo_udfTwoDigitZeroFillTest_MoreThanTwo_TestAction.Conditions.Add(scalarValueCondition2);
            resources.ApplyResources(dbo_udfTwoDigitZeroFillTest_MoreThanTwo_TestAction, "dbo_udfTwoDigitZeroFillTest_MoreThanTwo_TestAction");
            // 
            // scalarValueCondition2
            // 
            scalarValueCondition2.ColumnNumber = 1;
            scalarValueCondition2.Enabled = true;
            scalarValueCondition2.ExpectedValue = "* ";
            scalarValueCondition2.Name = "scalarValueCondition2";
            scalarValueCondition2.NullExpected = false;
            scalarValueCondition2.ResultSet = 1;
            scalarValueCondition2.RowNumber = 1;
            // 
            // dbo_idfTwoDigitZeroFillTest_MoreThanNineData
            // 
            this.dbo_idfTwoDigitZeroFillTest_MoreThanNineData.PosttestAction = null;
            this.dbo_idfTwoDigitZeroFillTest_MoreThanNineData.PretestAction = null;
            this.dbo_idfTwoDigitZeroFillTest_MoreThanNineData.TestAction = dbo_idfTwoDigitZeroFillTest_MoreThanNine_TestAction;
            // 
            // dbo_idfTwoDigitZeroFillTest_MoreThanNine_TestAction
            // 
            dbo_idfTwoDigitZeroFillTest_MoreThanNine_TestAction.Conditions.Add(scalarValueCondition3);
            resources.ApplyResources(dbo_idfTwoDigitZeroFillTest_MoreThanNine_TestAction, "dbo_idfTwoDigitZeroFillTest_MoreThanNine_TestAction");
            // 
            // scalarValueCondition3
            // 
            scalarValueCondition3.ColumnNumber = 1;
            scalarValueCondition3.Enabled = true;
            scalarValueCondition3.ExpectedValue = "* ";
            scalarValueCondition3.Name = "scalarValueCondition3";
            scalarValueCondition3.NullExpected = false;
            scalarValueCondition3.ResultSet = 1;
            scalarValueCondition3.RowNumber = 1;
        }

        #endregion


        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class
        // [ClassInitialize()]
        // public static void MyClassInitialize(TestContext testContext) { }
        //
        // Use ClassCleanup to run code after all tests in a class have run
        // [ClassCleanup()]
        // public static void MyClassCleanup() { }
        //
        #endregion


        [TestMethod()]
        public void dbo_udfTwoDigitZeroFillTest()
        {
            SqlDatabaseTestActions testActions = this.dbo_udfTwoDigitZeroFillTestData;
            // Execute the pre-test script
            // 
            System.Diagnostics.Trace.WriteLineIf((testActions.PretestAction != null), "Executing pre-test script...");
            SqlExecutionResult[] pretestResults = TestService.Execute(this.PrivilegedContext, this.PrivilegedContext, testActions.PretestAction);
            // Execute the test script
            // 
            System.Diagnostics.Trace.WriteLineIf((testActions.TestAction != null), "Executing test script...");
            SqlExecutionResult[] testResults = TestService.Execute(this.ExecutionContext, this.PrivilegedContext, testActions.TestAction);
            // Execute the post-test script
            // 
            System.Diagnostics.Trace.WriteLineIf((testActions.PosttestAction != null), "Executing post-test script...");
            SqlExecutionResult[] posttestResults = TestService.Execute(this.PrivilegedContext, this.PrivilegedContext, testActions.PosttestAction);
        }
        [TestMethod()]
        public void dbo_udfTwoDigitZeroFillTest_MoreThanTwo()
        {
            SqlDatabaseTestActions testActions = this.dbo_udfTwoDigitZeroFillTest_MoreThanTwoData;
            // Execute the pre-test script
            // 
            System.Diagnostics.Trace.WriteLineIf((testActions.PretestAction != null), "Executing pre-test script...");
            SqlExecutionResult[] pretestResults = TestService.Execute(this.PrivilegedContext, this.PrivilegedContext, testActions.PretestAction);
            // Execute the test script
            // 
            System.Diagnostics.Trace.WriteLineIf((testActions.TestAction != null), "Executing test script...");
            SqlExecutionResult[] testResults = TestService.Execute(this.ExecutionContext, this.PrivilegedContext, testActions.TestAction);
            // Execute the post-test script
            // 
            System.Diagnostics.Trace.WriteLineIf((testActions.PosttestAction != null), "Executing post-test script...");
            SqlExecutionResult[] posttestResults = TestService.Execute(this.PrivilegedContext, this.PrivilegedContext, testActions.PosttestAction);
        }
        [TestMethod()]
        public void dbo_idfTwoDigitZeroFillTest_MoreThanNine()
        {
            SqlDatabaseTestActions testActions = this.dbo_idfTwoDigitZeroFillTest_MoreThanNineData;
            // Execute the pre-test script
            // 
            System.Diagnostics.Trace.WriteLineIf((testActions.PretestAction != null), "Executing pre-test script...");
            SqlExecutionResult[] pretestResults = TestService.Execute(this.PrivilegedContext, this.PrivilegedContext, testActions.PretestAction);
            // Execute the test script
            // 
            System.Diagnostics.Trace.WriteLineIf((testActions.TestAction != null), "Executing test script...");
            SqlExecutionResult[] testResults = TestService.Execute(this.ExecutionContext, this.PrivilegedContext, testActions.TestAction);
            // Execute the post-test script
            // 
            System.Diagnostics.Trace.WriteLineIf((testActions.PosttestAction != null), "Executing post-test script...");
            SqlExecutionResult[] posttestResults = TestService.Execute(this.PrivilegedContext, this.PrivilegedContext, testActions.PosttestAction);
        }


        private SqlDatabaseTestActions dbo_udfTwoDigitZeroFillTestData;
        private SqlDatabaseTestActions dbo_udfTwoDigitZeroFillTest_MoreThanTwoData;
        private SqlDatabaseTestActions dbo_idfTwoDigitZeroFillTest_MoreThanNineData;
    }
}
