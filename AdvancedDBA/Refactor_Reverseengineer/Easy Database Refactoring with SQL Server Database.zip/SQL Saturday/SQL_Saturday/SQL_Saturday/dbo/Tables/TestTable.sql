﻿CREATE TABLE [dbo].[TestTable]
(
	[Hello]		int NULL,
	[Worlds]		int Null, 
    [NotNullDate] DATE NOT NULL
)