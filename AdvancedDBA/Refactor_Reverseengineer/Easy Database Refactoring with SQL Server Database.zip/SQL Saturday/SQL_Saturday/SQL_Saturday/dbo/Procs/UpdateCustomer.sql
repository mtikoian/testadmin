﻿CREATE PROCEDURE [dbo].[UpdateCustomer]
	@param1 int = 0,
	@param2 int
AS


UPDATE [dbo].[DimCustomer]
   SET DimCustomer.[Title]			= c.[Title]		
      ,DimCustomer.[FirstName]		= c.[FirstName]	
      ,DimCustomer.[MiddleName]		= c.[MiddleName]	
      ,DimCustomer.[LastName]		= c.[LastName]	
FROM [$(LinkedServer)].[$(AW_Source)].[SalesLT].[Customer] c
WHERE  DimCustomer.CustomerKey = c.CustomerID

