﻿Create Proc [dbo].[Update_SSISConfigurations]
AS
BEGIN
	Set nocount on;

CREATE TABLE #SSIS_Configurations(
	[ConfigurationFilter] [nvarchar](255) NOT NULL,
	[ConfiguredValue] [nvarchar](255) NULL,
	[PackagePath] [nvarchar](255) NOT NULL,
	[ConfiguredValueType] [nvarchar](20) NOT NULL
) ;

INSERT INTO #SSIS_Configurations (ConfigurationFilter, ConfiguredValue, PackagePath, ConfiguredValueType)
VALUES 
(N'Staging'
	 , N'$(StagingServerName)' 
	 , N'\Package.Connections[Staging].Properties[ServerName]' 
	 , N'String' )
,(N'SSIS_Folder'
	,N'$(SSIS_Folder)'
	,N'\Package.Variables[User::SSIS_Folder].Properties[Value]'
	,N'String'
);


	Merge dbo.SSIS_Configurations AS Target
	USING
		(
		SELECT 
			ConfigurationFilter
			, ConfiguredValue
			, PackagePath
			, ConfiguredValueType
		FROM #SSIS_Configurations
		)AS SOURCE
	ON
		(
			Target.ConfigurationFilter = Source.ConfigurationFilter
			AND Target.PackagePath = Source.PackagePath
		)
	WHEN Matched THEN
	UPDATE
		SET
			Target.ConfiguredValue = Source.ConfiguredValue
			, Target.ConfiguredValueType = Source.ConfiguredValueType

	WHEN NOT Matched
		THEN
		INSERT
			(
			ConfigurationFilter
			,ConfiguredValue
			,PackagePath
			,ConfiguredValueType
			)
		VALUES
			(
			Source.ConfigurationFilter
			,Source.ConfiguredValue
			,Source.PackagePath
			,Source.ConfiguredValueType
			)
	WHEN NOT MATCHED BY SOURCE
		THEN DELETE;
END
GO
