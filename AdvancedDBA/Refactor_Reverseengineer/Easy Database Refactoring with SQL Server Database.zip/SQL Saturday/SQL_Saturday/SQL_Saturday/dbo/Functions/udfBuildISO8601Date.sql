﻿CREATE FUNCTION [dbo].[udfBuildISO8601Date] (@year int, @month int, @day int)
RETURNS datetime
AS 
BEGIN
RETURN cast(convert(varchar, @year) + '-' + [dbo].[udfTwoDigitZeroFill](@month) 
+ '-' + [dbo].[udfTwoDigitZeroFill](@day) + 'T00:00:00' 
as datetime);
END
