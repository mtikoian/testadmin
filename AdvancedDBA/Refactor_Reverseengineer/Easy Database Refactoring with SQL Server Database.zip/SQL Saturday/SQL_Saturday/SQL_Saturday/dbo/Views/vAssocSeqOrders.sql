﻿CREATE VIEW [dbo].[vAssocSeqOrders]
AS
SELECT DISTINCT
[OrderNumber]
,[CustomerKey]
,[Region]
,[IncomeGroup]
FROM
[dbo].[vDMPrep] 
WHERE
[FiscalYear] = '2008'
