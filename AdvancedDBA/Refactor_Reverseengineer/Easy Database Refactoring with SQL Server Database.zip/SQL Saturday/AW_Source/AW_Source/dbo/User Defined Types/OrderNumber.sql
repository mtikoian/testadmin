﻿CREATE TYPE [dbo].[OrderNumber]
    FROM NVARCHAR (25) NULL;

