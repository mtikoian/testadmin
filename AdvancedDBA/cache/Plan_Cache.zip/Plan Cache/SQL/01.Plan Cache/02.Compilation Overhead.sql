/****************************************************************************/
/*  Cautionary Tale of Recompilations, Excessive CPU Load and Plan Caching  */
/*																			*/
/*                         Dmitri V. Korotkevitch                           */
/*                        http://aboutsqlserver.com                         */
/*                          dk@aboutsqlserver.com                           */
/****************************************************************************/
/*					         Ad-Hoc script (Demo)							*/
/****************************************************************************/

set nocount on
go

use SQLServerInternals
go

declare
	@SQL nvarchar(4000)

while 1 = 1
begin
	select @SQL = 
N'select top 1 OrderId from dbo.Orders where CustomerId = ''' + 
	convert(varchar(64),NEWID()) + '''';

	exec(@SQL); 
end
go
