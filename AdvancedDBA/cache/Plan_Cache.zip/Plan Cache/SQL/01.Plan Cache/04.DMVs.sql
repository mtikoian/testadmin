/****************************************************************************/
/*  Cautionary Tale of Recompilations, Excessive CPU Load and Plan Caching  */
/*																			*/
/*                         Dmitri V. Korotkevitch                           */
/*                        http://aboutsqlserver.com                         */
/*                          dk@aboutsqlserver.com                           */
/****************************************************************************/
/*					                 DMVs									*/
/****************************************************************************/

set nocount on
go

select 
	top 100 
	p.usecounts, p.cacheobjtype, p.objtype, p.size_in_bytes,
	t.[text] 
from 
	sys.dm_exec_cached_plans p
		cross apply sys.dm_exec_sql_text(p.plan_handle) t
where 
	p.cacheobjtype like 'Compiled Plan%' 
order by
	--p.objtype desc
	p.usecounts desc
option (recompile)
go

-- Some stats
select top(10) 
	[type] as [Memory Clerk Type], 
    sum(pages_kb) as [Memory Kb] 
from sys.dm_os_memory_clerks with (nolock)
group by [type]  
order by sum(pages_kb) desc
option(recompile)
go

select top (150)
		[text] as [QueryText], cp.objtype, cp.size_in_bytes
from	sys.dm_exec_cached_plans as cp with (nolock)
		cross apply sys.dm_exec_sql_text(plan_handle)
where	cp.cacheobjtype = N'Compiled Plan'
		and cp.objtype in (N'Adhoc', N'Prepared')
		and cp.usecounts = 1
order by cp.size_in_bytes desc 
option	(recompile);
go

exec sys.sp_configure N'optimize for ad hoc workloads',0
go
reconfigure with override
go

dbcc freeproccache
go
