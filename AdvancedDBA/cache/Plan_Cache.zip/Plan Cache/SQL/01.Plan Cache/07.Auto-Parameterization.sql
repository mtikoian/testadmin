/****************************************************************************/
/*  Cautionary Tale of Recompilations, Excessive CPU Load and Plan Caching  */
/*                         Dmitri V. Korotkevitch                           */
/*                        http://aboutsqlserver.com                         */
/*                          dk@aboutsqlserver.com                           */
/****************************************************************************/
/*					         Auto-Parameterization                          */
/****************************************************************************/

set nocount on
go

use SQLServerInternals
go

alter database SQLServerInternals set parameterization simple;
go

dbcc freeproccache
go

select * 
from dbo.Orders
where OrderId = 1000;
go

select * 
from dbo.Orders
where StoreId = 2;
go

select * 
from dbo.Orders
where StoreId = 99;
go

select top 10 * 
from dbo.Orders
where StoreId = 2
order by Amount desc;
go

select 
	p.usecounts, p.cacheobjtype, p.objtype, p.size_in_bytes,
	t.[text] 
from 
	sys.dm_exec_cached_plans p
		cross apply sys.dm_exec_sql_text(p.plan_handle) t
where 
	p.cacheobjtype like 'Compiled Plan%' 
order by
	--p.objtype desc
	p.usecounts desc
option (recompile)
go

alter database SQLServerInternals set parameterization forced;
go
