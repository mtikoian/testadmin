/****************************************************************************/
/*  Cautionary Tale of Recompilations, Excessive CPU Load and Plan Caching  */
/*                         Dmitri V. Korotkevitch                           */
/*                        http://aboutsqlserver.com                         */
/*                          dk@aboutsqlserver.com                           */
/****************************************************************************/
/*		                         Take Aways                                 */
/****************************************************************************/


-- Always Enable "Optimize for Ad-Hoc workload" setting

-- Evaluate how (re)compilations affect you
--		SQL Compilations / Sec; SQL Recompilations / Sec
--		System profile (OLTP, DW)
--		Amount of Ad-Hoc activity

-- Parameterize queries as much as possible in OLTP systems

-- Avoid "universal search" pattern

-- Consider to enable FORCED PARAMETERIZATION if compilations become the issue
--		Be aware of consiquences (Parameter sniffing for Ad-hoc)
--		Consider to enable OPTIMIZE FOR UNKNOWN on db/server level (TF 4136 prior SS2016)
--		Plan guides may help with individual queries
