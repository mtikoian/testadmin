/****************************************************************************/
/*  Cautionary Tale of Recompilations, Excessive CPU Load and Plan Caching  */
/*																			*/
/*                         Dmitri V. Korotkevitch                           */
/*                        http://aboutsqlserver.com                         */
/*                          dk@aboutsqlserver.com                           */
/****************************************************************************/
/*					     Parameterized script (Demo)						*/
/****************************************************************************/

set nocount on
go

use SQLServerInternals
go

declare
	@SQL nvarchar(4000)
	,@UUID uniqueidentifier

while 1 = 1
begin
	select @SQL = 
N'select top 1 OrderId from dbo.Orders where CustomerId = @CustomerId';
	
	select @UUID = NEWID();
	exec sp_executesql @SQL, N'@CustomerId uniqueidentifier',@CustomerID = @UUID;
end
go
