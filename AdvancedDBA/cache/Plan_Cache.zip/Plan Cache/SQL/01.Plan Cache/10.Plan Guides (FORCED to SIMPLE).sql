/****************************************************************************/
/*  Cautionary Tale of Recompilations, Excessive CPU Load and Plan Caching  */
/*                         Dmitri V. Korotkevitch                           */
/*                        http://aboutsqlserver.com                         */
/*                          dk@aboutsqlserver.com                           */
/****************************************************************************/
/*		            Plan Guides (Force SIMPLE parameterization)             */
/****************************************************************************/

alter database SQLServerInternals set parameterization forced;
go

dbcc freeproccache
go

if object_id('tempdb..#tmpOrders') is not null
	drop table #tmpOrders;
go

select *
into #tmpOrders
from dbo.Orders
where 1 = 2;
go

select top 50
	substring(qt.text, (qs.statement_start_offset/2)+1,
		((
			case qs.statement_end_offset
				when -1 then datalength(qt.text)
				else qs.statement_end_offset
			end - qs.statement_start_offset)/2)+1) as SQL
	,qt.text as [Full SQL]
	,qp.query_plan as [Query Plan]
	,qs.execution_count as [Exec Cnt]
	,(qs.total_logical_reads + qs.total_logical_writes) / 
		qs.execution_count as [Avg IO]
	,qs.total_logical_reads as [Total Reads]
	,qs.last_logical_reads as [Last Reads]
	,qs.total_logical_writes as [Total Writes]
	,qs.last_logical_writes as [Last Writes]
	,qs.total_worker_time as [Total Worker Time]
	,qs.last_worker_time as [Last Worker Time]
	,qs.total_elapsed_time / 1000 as [Total Elapsed Time]
	,qs.last_elapsed_time / 1000 as [Last Elapsed Time]
	,qs.last_execution_time as [Last Exec Time]
	,qs.creation_time as [Cached Time]
	,qs.total_rows as [Total Rows] -- SQL Server 2008R2+
	,qs.last_rows as [Last Rows] -- SQL Server 2008R2+
	,qs.min_rows as [Min Rows] -- SQL Server 2008R2+
	,qs.max_rows as [Max Rows] -- SQL Server 2008R2+ 
from 
	sys.dm_exec_query_stats qs with (nolock)
		cross apply sys.dm_exec_sql_text(qs.sql_handle) qt
		cross apply sys.dm_exec_query_plan(qs.plan_handle) qp
order by
	[Avg IO] desc
option (recompile);

declare
	@stmt nvarchar(max) = N'select * into #tmpOrders from dbo . Orders where @0 = @1'
	,@params nvarchar(max) = N'@0 int,@1 int'
 	
-- Creating plan guide
exec sp_create_plan_guide
	@type = N'TEMPLATE'
	,@name = N'simple_parameterization_plan_guide'
	,@stmt = @stmt
	,@module_or_batch = null
	,@params = @params
	,@hints = N'OPTION (PARAMETERIZATION SIMPLE)';
go

exec sp_control_plan_guide @Operation = 'DROP', @Name = 'simple_parameterization_plan_guide'
go

