/****************************************************************************/
/*  Cautionary Tale of Recompilations, Excessive CPU Load and Plan Caching  */
/*                         Dmitri V. Korotkevitch                           */
/*                        http://aboutsqlserver.com                         */
/*                          dk@aboutsqlserver.com                           */
/****************************************************************************/
/*		            Plan Guides (Force FORCED parameterization)             */
/****************************************************************************/

set nocount on
go

use SQLServerInternals
go

alter database SQLServerInternals set parameterization simple;
go

declare
	@stmt nvarchar(max)
	,@params nvarchar(max) 
	,@query nvarchar(max) = 
N'select top 1 OrderId from dbo.Orders where CustomerId = ''B970D68B-F88E-438B-9B04-6EDE47CC1D9A'''
 
-- Getting template for the query. Forcing PARAMETERIZATION FORCED
exec sp_get_query_template
	@querytext = @query
	,@templatetext = @stmt output
	,@params = @params output;
	
-- Creating plan guide
exec sp_create_plan_guide
	@type = N'TEMPLATE'
	,@name = N'force_parameterization_plan_guide'
	,@stmt = @stmt
	,@module_or_batch = null
	,@params = @params
	,@hints = N'OPTION (PARAMETERIZATION FORCED)';
go

dbcc freeproccache
go

exec sp_control_plan_guide @Operation = 'DROP', @Name = 'force_parameterization_plan_guide'
go