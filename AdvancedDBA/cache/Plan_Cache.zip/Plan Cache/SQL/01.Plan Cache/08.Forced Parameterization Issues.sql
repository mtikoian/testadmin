/****************************************************************************/
/*  Cautionary Tale of Recompilations, Excessive CPU Load and Plan Caching  */
/*                         Dmitri V. Korotkevitch                           */
/*                        http://aboutsqlserver.com                         */
/*                          dk@aboutsqlserver.com                           */
/****************************************************************************/
/*		     	         Forced Parameterization Issues                     */
/****************************************************************************/

set nocount on
go

use SQLServerInternals
go

-- FORCED PARAMETERIZATION introduces "Parameter Sniffing" for all ad-hoc workload
-- Consider OPTIMIZE FOR UNKNOWN: 
--	SQL Server 2016: Database scoped configuration
--  SQL Server <2016: TF 4136 (Server-level - be careful)


-- Filtered indexes:
alter database SQLServerInternals set parameterization simple;
go

create index IDX_Orders_Fulfilled_Filtered
on dbo.Orders(OrderId)
include(Fulfilled)
where Fulfilled = 0;
go

select top 10 *  
from dbo.Orders
where Fulfilled = 0
order by OrderId
go

alter database SQLServerInternals set parameterization forced;
go

select top 10 *  
from dbo.Orders
where Fulfilled = 0
order by OrderId
go

create proc dbo.GetOrdersForFulfillment
as
	select top 10 *  
	from dbo.Orders
	where Fulfilled = 0
	order by OrderId
go

exec dbo.GetOrdersForFulfillment
go

-- Ad-hoc temp table creation (SELECT INTO)
alter database SQLServerInternals set parameterization simple;
go

select *
into #tmpOrders
from dbo.Orders
where 1 = 2;
go

alter database SQLServerInternals set parameterization forced;
go

-- Filter predicate may prevent some part of the 
select *
into #tmpOrders2
from dbo.Orders
where 1 = 2;
go

select *
into #tmpOrders3
from dbo.Orders
	cross apply 
	(
		select count(*) as Cnt from dbo.Orders
	) c
where 1 = 2;
go




select *
into #tmpOrders4
from dbo.Orders
where 1 = null;
go