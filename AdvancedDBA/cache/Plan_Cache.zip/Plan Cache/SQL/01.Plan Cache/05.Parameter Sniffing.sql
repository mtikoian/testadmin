/****************************************************************************/
/*  Cautionary Tale of Recompilations, Excessive CPU Load and Plan Caching  */
/*																			*/
/*                         Dmitri V. Korotkevitch                           */
/*                        http://aboutsqlserver.com                         */
/*                          dk@aboutsqlserver.com                           */
/****************************************************************************/
/*					         Parameter Sniffing								*/
/****************************************************************************/

set nocount on
go

use SQLServerInternals
go

if exists(select * from sys.procedures p join sys.schemas s on p.schema_id = s.schema_id where p.name = 'GetTotalPerStore' and s.name = 'dbo') drop proc dbo.GetTotalPerStore;
go

insert into dbo.Orders(OrderDate, OrderNum, CustomerId, Amount, StoreId, Fulfilled)
	select top 10 OrderDate, OrderNum, CustomerId, Amount, 99, 0
	from dbo.Orders
	order by OrderId;
go

alter index IDX_Orders_StoreID on dbo.Orders rebuild
go

dbcc show_statistics('dbo.Orders','IDX_Orders_StoreID');
go

create proc dbo.GetTotalPerStore(@StoreId int)
as
	select sum(Amount)
	from dbo.Orders
	where StoreId = @StoreId;
go

-- Enable "Display Actual Execution Plan"
set statistics io on

exec dbo.GetTotalPerStore @StoreId = 1;
exec dbo.GetTotalPerStore @StoreId = 99;

set statistics io off
go


dbcc freeproccache;
go

set statistics io on

exec dbo.GetTotalPerStore @StoreId = 99;
exec dbo.GetTotalPerStore @StoreId = 1;

set statistics io off
go





/* Fixing the issues */
alter proc dbo.GetTotalPerStore(@StoreId int)
as
	select sum(Amount)
	from dbo.Orders
	where StoreId = @StoreId
	option (recompile);
go


exec dbo.GetTotalPerStore @StoreId = 99;
exec dbo.GetTotalPerStore @StoreId = 1;
go



alter proc dbo.GetTotalPerStore(@StoreId int)
as
	select sum(Amount)
	from dbo.Orders
	where StoreId = @StoreId
	option (optimize for (@StoreId = 1));
go

exec dbo.GetTotalPerStore @StoreId = 99;
exec dbo.GetTotalPerStore @StoreId = 1;
go



update dbo.Orders set StoreId = -1 where StoreId = 1;
go

exec dbo.GetTotalPerStore @StoreId = 99;
exec dbo.GetTotalPerStore @StoreId = 2;
go


alter proc dbo.GetTotalPerStore(@StoreId int)
as
	select sum(Amount)
	from dbo.Orders
	where StoreId = @StoreId
	option (optimize for unknown); -- SS 2008+
go


exec dbo.GetTotalPerStore @StoreId = 99;
exec dbo.GetTotalPerStore @StoreId = 2;
go


alter proc dbo.GetTotalPerStore(@StoreId int)
as
	declare
		@tmpStoreId int = @StoreId

	select sum(Amount)
	from dbo.Orders
	where StoreId = @tmpStoreId
go


dbcc freeproccache;
go

exec dbo.GetTotalPerStore @StoreId = 99;
exec dbo.GetTotalPerStore @StoreId = 2;
go

