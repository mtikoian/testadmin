/****************************************************************************/
/*  Cautionary Tale of Recompilations, Excessive CPU Load and Plan Caching  */
/*																			*/
/*                         Dmitri V. Korotkevitch                           */
/*                        http://aboutsqlserver.com                         */
/*                          dk@aboutsqlserver.com                           */
/****************************************************************************/
/*					          Universal Search								*/
/****************************************************************************/

set nocount on
go

use SQLServerInternals
go

if exists(select * from sys.procedures p join sys.schemas s on p.schema_id = s.schema_id where p.name = 'SearchOrdersByCustomer' and s.name = 'dbo') drop proc dbo.SearchOrdersByCustomer;
if exists(select * from sys.procedures p join sys.schemas s on p.schema_id = s.schema_id where p.name = 'SearchOrdersByOrderNum' and s.name = 'dbo') drop proc dbo.SearchOrdersByOrderNum;
if exists(select * from sys.procedures p join sys.schemas s on p.schema_id = s.schema_id where p.name = 'SearchOrders' and s.name = 'dbo') drop proc dbo.SearchOrders;
go

create proc dbo.SearchOrdersByCustomer(@CustomerId uniqueidentifier)
as
	select OrderId, OrderDate, OrderNum, CustomerId, Amount, StoreId, FulFilled
	from dbo.Orders
	where CustomerId = @CustomerId;
go

create proc dbo.SearchOrdersByOrderNum(@OrderNum varchar(32))
as
	select OrderId, OrderDate, OrderNum, CustomerId, Amount, StoreId, FulFilled
	from dbo.Orders
	where OrderNum = @OrderNum;
go


-- Enable Actual Execution Plan
exec dbo.SearchOrdersByCustomer @CustomerId = 'B56462DC-4B04-47D7-BF06-3CA442831B65';
exec dbo.SearchOrdersByOrderNum @OrderNum = 'Order: 100';
go

create proc dbo.SearchOrders(@CustomerId uniqueidentifier, @OrderNum varchar(32))
as
	select OrderId, OrderDate, OrderNum, CustomerId, Amount, StoreId, FulFilled
	from dbo.Orders
	where 
		(@OrderNum is null or OrderNum = @OrderNum) and
		(@CustomerId is null or CustomerId = @CustomerId);
go

set statistics io on
exec dbo.SearchOrders @CustomerId = 'B56462DC-4B04-47D7-BF06-3CA442831B65', 
@OrderNum = 'Order: 100';
exec dbo.SearchOrders @CustomerId = 'B56462DC-4B04-47D7-BF06-3CA442831B65', 
@OrderNum = null;
exec dbo.SearchOrders @CustomerId = null, @OrderNum = 'Order: 100';
go


alter proc dbo.SearchOrders(@CustomerId uniqueidentifier, @OrderNum varchar(32))
as
	select OrderId, OrderDate, OrderNum, CustomerId, Amount, StoreId, FulFilled
	from dbo.Orders
	where 
		(@OrderNum is null or OrderNum = @OrderNum) and
		(@CustomerId is null or CustomerId = @CustomerId)
	option (recompile);
go

exec dbo.SearchOrders @CustomerId = 'B56462DC-4B04-47D7-BF06-3CA442831B65', @OrderNum = 'Order: 100';
exec dbo.SearchOrders @CustomerId = 'B56462DC-4B04-47D7-BF06-3CA442831B65', @OrderNum = null;
exec dbo.SearchOrders @CustomerId = null, @OrderNum = 'Order: 100';
go

alter proc dbo.SearchOrders(@CustomerId uniqueidentifier, @OrderNum varchar(32))
as
	declare
		@sql nvarchar(max) = 
N'select OrderId, OrderDate, OrderNum, CustomerId, Amount, StoreId, FulFilled
from dbo.Orders
where 
	1 = 1 '
	+ IIF(@OrderNum is null, '', ' and OrderNum = @OrderNum')
	+ IIF(@CustomerId is null, '', ' and CustomerId = @CustomerId');

	exec sp_executesql 
		@sql
		,N'@CustomerId uniqueidentifier, @OrderNum varchar(32)'
		,@CustomerId = @CustomerId, @OrderNum = @OrderNum;
go

exec dbo.SearchOrders @CustomerId = 'B56462DC-4B04-47D7-BF06-3CA442831B65', @OrderNum = 'Order: 100';
exec dbo.SearchOrders @CustomerId = 'B56462DC-4B04-47D7-BF06-3CA442831B65', @OrderNum = null;
exec dbo.SearchOrders @CustomerId = null, @OrderNum = 'Order: 100';
go
