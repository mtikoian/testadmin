USE [msdb]
GO

/****** Object:  Job [_Force Replication]    Script Date: 05/14/2013 13:07:35 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 05/14/2013 13:07:35 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'_Force Replication', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sa', 
		@notify_email_operator_name=N'DBAlerts', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [step]    Script Date: 05/14/2013 13:07:37 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'step', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec msdb.dbo.sp_start_job @job_name = ''COLLECTION-ILCentral-Distribution-REPORT''
--exec msdb.dbo.sp_start_job @job_name = ''COLLECTION-ILCentral-Distribution-VOO1COLLECTION\COLLECTION''
exec msdb.dbo.sp_start_job @job_name = ''COLLECTION-ILCentralData-Distribution-REPORT''
exec msdb.dbo.sp_start_job @job_name = ''COLLECTION-ILCentralDataEnt-Distribution-REPORT''
', 
		@database_name=N'msdb', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'schedule', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=8, 
		@freq_subday_interval=4, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20120425, 
		@active_end_date=99991231, 
		@active_start_time=60000, 
		@active_end_time=175959, 
		@schedule_uid=N'8dbe45ef-2cb6-4f09-91fc-ceddd302eb58'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [Agent history clean up: distribution]    Script Date: 05/14/2013 13:07:37 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [REPL-History Cleanup]    Script Date: 05/14/2013 13:07:38 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'REPL-History Cleanup' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'REPL-History Cleanup'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Agent history clean up: distribution', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'Removes replication agent history from the distribution database.', 
		@category_name=N'REPL-History Cleanup', 
		@owner_login_name=N'COLLECTION\Administrator', 
		@notify_email_operator_name=N'DBAlerts', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Run agent.]    Script Date: 05/14/2013 13:07:38 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Run agent.', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC dbo.sp_MShistory_cleanup @history_retention = 48', 
		@server=N'COLLECTION', 
		@database_name=N'distribution', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Replication agent schedule.', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=4, 
		@freq_subday_interval=10, 
		@freq_relative_interval=1, 
		@freq_recurrence_factor=0, 
		@active_start_date=20090827, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959, 
		@schedule_uid=N'2c4b2975-b839-4ae5-986b-440868c14b4b'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [COLLECTION-ILCentralData-Distribution-REPORT]    Script Date: 05/14/2013 13:07:38 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [REPL-Distribution]    Script Date: 05/14/2013 13:07:38 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'REPL-Distribution' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'REPL-Distribution'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'COLLECTION-ILCentralData-Distribution-REPORT', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'REPL-Distribution', 
		@owner_login_name=N'COLLECTION\Administrator', 
		@notify_email_operator_name=N'DBAlerts', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Distribution Agent startup message.]    Script Date: 05/14/2013 13:07:38 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Distribution Agent startup message.', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'sp_MSadd_distribution_history @perfmon_increment = 0, @agent_id = 5, @runstatus = 1,  
                    @comments = N''Starting agent.''', 
		@server=N'COLLECTION', 
		@database_name=N'distribution', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Run agent.]    Script Date: 05/14/2013 13:07:38 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Run agent.', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=10, 
		@retry_interval=1, 
		@os_run_priority=0, @subsystem=N'Distribution', 
		@command=N'-Subscriber [REPORT] -SubscriberDB [ILCentralData] -Publisher [COLLECTION] -Distributor [COLLECTION] -DistributorSecurityMode 1 -Publication [ILCentralData] -PublisherDB [ILCentralData]   ', 
		@server=N'COLLECTION', 
		@database_name=N'distribution', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Detect nonlogged agent shutdown.]    Script Date: 05/14/2013 13:07:38 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Detect nonlogged agent shutdown.', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=2, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'sp_MSdetect_nonlogged_shutdown @subsystem = ''Distribution'', @agent_id = 5', 
		@server=N'COLLECTION', 
		@database_name=N'distribution', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'All Day Long', 
		@enabled=0, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=4, 
		@freq_subday_interval=10, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20110519, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959, 
		@schedule_uid=N'1c7b3c17-917d-406c-ac61-e11fab247c0f'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Once during the day', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20121024, 
		@active_end_date=99991231, 
		@active_start_time=120000, 
		@active_end_time=235959, 
		@schedule_uid=N'cd3aadbd-f12d-494f-b4ff-c6101d0b587a'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Replication agent schedule.', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=4, 
		@freq_subday_interval=10, 
		@freq_relative_interval=1, 
		@freq_recurrence_factor=0, 
		@active_start_date=20100818, 
		@active_end_date=99991231, 
		@active_start_time=170200, 
		@active_end_time=30200, 
		@schedule_uid=N'11957196-856f-4a52-81ba-951af834e965'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [COLLECTION-ILCentralDataEnt-Distribution-REPORT]    Script Date: 05/14/2013 13:07:39 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [REPL-Distribution]    Script Date: 05/14/2013 13:07:39 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'REPL-Distribution' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'REPL-Distribution'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'COLLECTION-ILCentralDataEnt-Distribution-REPORT', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'REPL-Distribution', 
		@owner_login_name=N'COLLECTION\Administrator', 
		@notify_email_operator_name=N'DBAlerts', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Distribution Agent startup message.]    Script Date: 05/14/2013 13:07:39 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Distribution Agent startup message.', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'sp_MSadd_distribution_history @perfmon_increment = 0, @agent_id = 12, @runstatus = 1,  
                    @comments = N''Starting agent.''', 
		@server=N'COLLECTION', 
		@database_name=N'distribution', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Run agent.]    Script Date: 05/14/2013 13:07:39 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Run agent.', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=10, 
		@retry_interval=1, 
		@os_run_priority=0, @subsystem=N'Distribution', 
		@command=N'-Subscriber [REPORT] -SubscriberDB [ILCentralDataEnt] -Publisher [COLLECTION] -Distributor [COLLECTION] -DistributorSecurityMode 1 -Publication [ILCentralDataEnt] -PublisherDB [ILCentralDataEnt]   ', 
		@server=N'COLLECTION', 
		@database_name=N'distribution', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Detect nonlogged agent shutdown.]    Script Date: 05/14/2013 13:07:39 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Detect nonlogged agent shutdown.', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=2, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'sp_MSdetect_nonlogged_shutdown @subsystem = ''Distribution'', @agent_id = 12', 
		@server=N'COLLECTION', 
		@database_name=N'distribution', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'All Day Long', 
		@enabled=0, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=4, 
		@freq_subday_interval=10, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20110519, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959, 
		@schedule_uid=N'4e3d2ec0-ba42-4123-8080-5b27a90615ea'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Once during the day', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20121024, 
		@active_end_date=99991231, 
		@active_start_time=121000, 
		@active_end_time=235959, 
		@schedule_uid=N'c39933fd-9699-4fc8-a261-3d9b81ca7ef8'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Replication agent schedule.', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=4, 
		@freq_subday_interval=10, 
		@freq_relative_interval=1, 
		@freq_recurrence_factor=0, 
		@active_start_date=20110518, 
		@active_end_date=99991231, 
		@active_start_time=170000, 
		@active_end_time=35959, 
		@schedule_uid=N'cd589709-1c89-4078-9243-a01de26594b0'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [COLLECTION-ILCentralDataEnt-LogReader]    Script Date: 05/14/2013 13:07:39 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [REPL-LogReader]    Script Date: 05/14/2013 13:07:39 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'REPL-LogReader' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'REPL-LogReader'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'COLLECTION-ILCentralDataEnt-LogReader', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'REPL-LogReader', 
		@owner_login_name=N'COLLECTION\Administrator', 
		@notify_email_operator_name=N'DBAlerts', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Log Reader Agent startup message.]    Script Date: 05/14/2013 13:07:39 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Log Reader Agent startup message.', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'sp_MSadd_logreader_history @perfmon_increment = 0, @agent_id = 3, @runstatus = 1, 
                    @comments = N''Starting agent.''', 
		@server=N'COLLECTION', 
		@database_name=N'distribution', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Run agent.]    Script Date: 05/14/2013 13:07:39 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Run agent.', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=2147483647, 
		@retry_interval=1, 
		@os_run_priority=0, @subsystem=N'LogReader', 
		@command=N'-Publisher [COLLECTION] -PublisherDB [ILCentralDataEnt] -Distributor [COLLECTION] -DistributorSecurityMode 1  -Continuous', 
		@server=N'COLLECTION', 
		@database_name=N'distribution', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Detect nonlogged agent shutdown.]    Script Date: 05/14/2013 13:07:40 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Detect nonlogged agent shutdown.', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=2, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'sp_MSdetect_nonlogged_shutdown @subsystem = ''LogReader'', @agent_id = 3', 
		@server=N'COLLECTION', 
		@database_name=N'distribution', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Replication agent schedule.', 
		@enabled=1, 
		@freq_type=64, 
		@freq_interval=0, 
		@freq_subday_type=0, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20110516, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959, 
		@schedule_uid=N'5da156a7-9c87-4d19-9c7f-ebdae6efe6da'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [COLLECTION-ILCentralDataEnt-Snapshot]    Script Date: 05/14/2013 13:07:40 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [REPL-Snapshot]    Script Date: 05/14/2013 13:07:40 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'REPL-Snapshot' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'REPL-Snapshot'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'COLLECTION-ILCentralDataEnt-Snapshot', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'REPL-Snapshot', 
		@owner_login_name=N'COLLECTION\Administrator', 
		@notify_email_operator_name=N'DBAlerts', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Snapshot Agent startup message.]    Script Date: 05/14/2013 13:07:40 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Snapshot Agent startup message.', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'sp_MSadd_snapshot_history @perfmon_increment = 0,  @agent_id = 3, @runstatus = 1,  
                    @comments = N''Starting agent.''', 
		@server=N'COLLECTION', 
		@database_name=N'distribution', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Run agent.]    Script Date: 05/14/2013 13:07:40 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Run agent.', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=10, 
		@retry_interval=1, 
		@os_run_priority=0, @subsystem=N'Snapshot', 
		@command=N'-Publisher [COLLECTION] -PublisherDB [ILCentralDataEnt] -Distributor [COLLECTION] -Publication [ILCentralDataEnt] -DistributorSecurityMode 1 ', 
		@server=N'COLLECTION', 
		@database_name=N'distribution', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Detect nonlogged agent shutdown.]    Script Date: 05/14/2013 13:07:40 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Detect nonlogged agent shutdown.', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=2, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'sp_MSdetect_nonlogged_shutdown @subsystem = ''Snapshot'', @agent_id = 3', 
		@server=N'COLLECTION', 
		@database_name=N'distribution', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [COLLECTION-ILCentralData-LogReader]    Script Date: 05/14/2013 13:07:40 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [REPL-LogReader]    Script Date: 05/14/2013 13:07:40 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'REPL-LogReader' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'REPL-LogReader'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'COLLECTION-ILCentralData-LogReader', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'REPL-LogReader', 
		@owner_login_name=N'COLLECTION\Administrator', 
		@notify_email_operator_name=N'DBAlerts', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Log Reader Agent startup message.]    Script Date: 05/14/2013 13:07:40 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Log Reader Agent startup message.', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'sp_MSadd_logreader_history @perfmon_increment = 0, @agent_id = 1, @runstatus = 1, 
                    @comments = N''Starting agent.''', 
		@server=N'COLLECTION', 
		@database_name=N'distribution', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Run agent.]    Script Date: 05/14/2013 13:07:40 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Run agent.', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=2147483647, 
		@retry_interval=1, 
		@os_run_priority=0, @subsystem=N'LogReader', 
		@command=N'-Publisher [COLLECTION] -PublisherDB [ILCentralData] -Distributor [COLLECTION] -DistributorSecurityMode 1  -Continuous', 
		@server=N'COLLECTION', 
		@database_name=N'distribution', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Detect nonlogged agent shutdown.]    Script Date: 05/14/2013 13:07:40 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Detect nonlogged agent shutdown.', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=2, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'sp_MSdetect_nonlogged_shutdown @subsystem = ''LogReader'', @agent_id = 1', 
		@server=N'COLLECTION', 
		@database_name=N'distribution', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Replication agent schedule.', 
		@enabled=1, 
		@freq_type=64, 
		@freq_interval=0, 
		@freq_subday_type=0, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20090827, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959, 
		@schedule_uid=N'8f387307-c585-411d-8bce-bd9c3bf3f1bc'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [COLLECTION-ILCentralData-Snapshot]    Script Date: 05/14/2013 13:07:41 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [REPL-Snapshot]    Script Date: 05/14/2013 13:07:41 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'REPL-Snapshot' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'REPL-Snapshot'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'COLLECTION-ILCentralData-Snapshot', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'REPL-Snapshot', 
		@owner_login_name=N'COLLECTION\Administrator', 
		@notify_email_operator_name=N'DBAlerts', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Snapshot Agent startup message.]    Script Date: 05/14/2013 13:07:41 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Snapshot Agent startup message.', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'sp_MSadd_snapshot_history @perfmon_increment = 0,  @agent_id = 1, @runstatus = 1,  
                    @comments = N''Starting agent.''', 
		@server=N'COLLECTION', 
		@database_name=N'distribution', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Run agent.]    Script Date: 05/14/2013 13:07:41 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Run agent.', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=10, 
		@retry_interval=1, 
		@os_run_priority=0, @subsystem=N'Snapshot', 
		@command=N'-Publisher [COLLECTION] -PublisherDB [ILCentralData] -Distributor [COLLECTION] -Publication [ILCentralData] -DistributorSecurityMode 1 ', 
		@server=N'COLLECTION', 
		@database_name=N'distribution', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Detect nonlogged agent shutdown.]    Script Date: 05/14/2013 13:07:41 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Detect nonlogged agent shutdown.', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=2, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'sp_MSdetect_nonlogged_shutdown @subsystem = ''Snapshot'', @agent_id = 1', 
		@server=N'COLLECTION', 
		@database_name=N'distribution', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Replication agent schedule.', 
		@enabled=0, 
		@freq_type=1, 
		@freq_interval=0, 
		@freq_subday_type=0, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20090827, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959, 
		@schedule_uid=N'925a1ea6-c279-4319-a49a-8e4e1fc4fad7'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [COLLECTION-ILCentral-Distribution-REPORT]    Script Date: 05/14/2013 13:07:41 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [REPL-Distribution]    Script Date: 05/14/2013 13:07:41 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'REPL-Distribution' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'REPL-Distribution'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'COLLECTION-ILCentral-Distribution-REPORT', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'REPL-Distribution', 
		@owner_login_name=N'COLLECTION\Administrator', 
		@notify_email_operator_name=N'DBAlerts', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Distribution Agent startup message.]    Script Date: 05/14/2013 13:07:41 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Distribution Agent startup message.', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'sp_MSadd_distribution_history @perfmon_increment = 0, @agent_id = 6, @runstatus = 1,  
                    @comments = N''Starting agent.''', 
		@server=N'COLLECTION', 
		@database_name=N'distribution', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Run agent.]    Script Date: 05/14/2013 13:07:41 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Run agent.', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=10, 
		@retry_interval=1, 
		@os_run_priority=0, @subsystem=N'Distribution', 
		@command=N'-Subscriber [REPORT] -SubscriberDB [ILCentral] -Publisher [COLLECTION] -Distributor [COLLECTION] -DistributorSecurityMode 1 -Publication [ILCentral] -PublisherDB [ILCentral]   ', 
		@server=N'COLLECTION', 
		@database_name=N'distribution', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Detect nonlogged agent shutdown.]    Script Date: 05/14/2013 13:07:41 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Detect nonlogged agent shutdown.', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=2, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'sp_MSdetect_nonlogged_shutdown @subsystem = ''Distribution'', @agent_id = 6', 
		@server=N'COLLECTION', 
		@database_name=N'distribution', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'All Day Long', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=4, 
		@freq_subday_interval=10, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20110519, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959, 
		@schedule_uid=N'9baba295-b27e-4d33-83e3-c9b8303b4f16'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Replication agent schedule.', 
		@enabled=0, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=4, 
		@freq_subday_interval=10, 
		@freq_relative_interval=1, 
		@freq_recurrence_factor=0, 
		@active_start_date=20110429, 
		@active_end_date=99991231, 
		@active_start_time=180000, 
		@active_end_time=55959, 
		@schedule_uid=N'1a0b2d56-8786-4aa9-be5e-fd80b31d753c'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [COLLECTION-ILCentral-LogReader]    Script Date: 05/14/2013 13:07:41 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [REPL-LogReader]    Script Date: 05/14/2013 13:07:41 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'REPL-LogReader' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'REPL-LogReader'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'COLLECTION-ILCentral-LogReader', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'REPL-LogReader', 
		@owner_login_name=N'COLLECTION\Administrator', 
		@notify_email_operator_name=N'DBAlerts', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Log Reader Agent startup message.]    Script Date: 05/14/2013 13:07:42 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Log Reader Agent startup message.', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'sp_MSadd_logreader_history @perfmon_increment = 0, @agent_id = 2, @runstatus = 1, 
                    @comments = N''Starting agent.''', 
		@server=N'COLLECTION', 
		@database_name=N'distribution', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Run agent.]    Script Date: 05/14/2013 13:07:42 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Run agent.', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=2147483647, 
		@retry_interval=1, 
		@os_run_priority=0, @subsystem=N'LogReader', 
		@command=N'-Publisher [COLLECTION] -PublisherDB [ILCentral] -Distributor [COLLECTION] -DistributorSecurityMode 1  -Continuous', 
		@server=N'COLLECTION', 
		@database_name=N'distribution', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Detect nonlogged agent shutdown.]    Script Date: 05/14/2013 13:07:42 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Detect nonlogged agent shutdown.', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=2, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'sp_MSdetect_nonlogged_shutdown @subsystem = ''LogReader'', @agent_id = 2', 
		@server=N'COLLECTION', 
		@database_name=N'distribution', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Replication agent schedule.', 
		@enabled=1, 
		@freq_type=64, 
		@freq_interval=0, 
		@freq_subday_type=0, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20110429, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959, 
		@schedule_uid=N'd0df6f95-4cf6-48fb-af44-42a6f98c803e'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [COLLECTION-ILCentral-Snapshot]    Script Date: 05/14/2013 13:07:42 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [REPL-Snapshot]    Script Date: 05/14/2013 13:07:42 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'REPL-Snapshot' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'REPL-Snapshot'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'COLLECTION-ILCentral-Snapshot', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'REPL-Snapshot', 
		@owner_login_name=N'COLLECTION\Administrator', 
		@notify_email_operator_name=N'DBAlerts', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Snapshot Agent startup message.]    Script Date: 05/14/2013 13:07:42 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Snapshot Agent startup message.', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'sp_MSadd_snapshot_history @perfmon_increment = 0,  @agent_id = 2, @runstatus = 1,  
                    @comments = N''Starting agent.''', 
		@server=N'COLLECTION', 
		@database_name=N'distribution', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Run agent.]    Script Date: 05/14/2013 13:07:42 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Run agent.', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=10, 
		@retry_interval=1, 
		@os_run_priority=0, @subsystem=N'Snapshot', 
		@command=N'-Publisher [COLLECTION] -PublisherDB [ILCentral] -Distributor [COLLECTION] -Publication [ILCentral] -DistributorSecurityMode 1 ', 
		@server=N'COLLECTION', 
		@database_name=N'distribution', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Detect nonlogged agent shutdown.]    Script Date: 05/14/2013 13:07:42 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Detect nonlogged agent shutdown.', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=2, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'sp_MSdetect_nonlogged_shutdown @subsystem = ''Snapshot'', @agent_id = 2', 
		@server=N'COLLECTION', 
		@database_name=N'distribution', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Replication agent schedule.', 
		@enabled=0, 
		@freq_type=1, 
		@freq_interval=0, 
		@freq_subday_type=0, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20110429, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959, 
		@schedule_uid=N'66828b5e-7620-4c1f-8107-dc2f5c1444f5'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [Database Backup - Cleanup]    Script Date: 05/14/2013 13:07:42 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 05/14/2013 13:07:42 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Database Backup - Cleanup', 
		@enabled=1, 
		@notify_level_eventlog=2, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'sa', 
		@notify_email_operator_name=N'DBAlerts', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Cleanup Full Backup Files]    Script Date: 05/14/2013 13:07:43 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Cleanup Full Backup Files', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'

declare @dt datetime
select @dt=getdate()-1 --No days to delete
EXECUTE master.dbo.xp_delete_file 0,N''F:\MSSQL\Backup\'',N''bak'',@dt

', 
		@database_name=N'MASTER', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Cleanup TLog Backup Files]    Script Date: 05/14/2013 13:07:43 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Cleanup TLog Backup Files', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'

declare @dt datetime
select @dt=getdate()-2 --No days to delete
EXECUTE master.dbo.xp_delete_file 0,N''F:\MSSQL\Backup\TLOG\'',N''bak'',@dt

', 
		@database_name=N'MASTER', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Schedule', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20070927, 
		@active_end_date=99991231, 
		@active_start_time=40000, 
		@active_end_time=235959, 
		@schedule_uid=N'ef1c18a4-194f-4a36-85d9-a37f9edecf57'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [Database Backup Diff - ILCENTRALDATACUM]    Script Date: 05/14/2013 13:07:43 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 05/14/2013 13:07:43 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Database Backup Diff - ILCENTRALDATACUM', 
		@enabled=1, 
		@notify_level_eventlog=2, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'sa', 
		@notify_email_operator_name=N'DBAlerts', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Backup Step]    Script Date: 05/14/2013 13:07:43 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Backup Step', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
--Determine if we should backup today.  Full backups only occur every 3 days
if ( datePart( day, GETDATE()) % 3) <> 0
begin
    
  declare 
    @DatabaseName varchar(25),
    @Location varchar(255),
    @ErrorString varchar(255),
    @Date datetime,
    @String varchar(15),
    @execStr NVarChar(1024),
    @Result int

  set @DatabaseName = ''ILCENTRALDATACUM''
  set @Location = ''F:\MSSQL\Backup\''
  set @ErrorString = ''Backup for Database ('' + @DatabaseName + '') has failed''
  set @Date = GetDate()
  set @String = convert(varchar(4), datepart( year, @Date)) + RIGHT(''0'' + convert(varchar(2), datepart( month, @Date)), 2) + RIGHT(''0'' + convert(varchar(2), datepart( day, @Date)), 2) + ''_'' +  RIGHT(''0'' + convert(varchar(2), datepart( hour, @Date)), 2) + RIGHT(''0'' + convert(varchar(2), datepart( minute, @Date)), 2) + RIGHT(''0'' + convert(varchar(2), datepart( second, @Date)), 2)
  set @execStr = ''BACKUP DATABASE ['' + @DatabaseName + ''] TO  DISK = N'''''' + @Location + @DatabaseName + ''_DIFF_'' + @String + ''.bak'''' WITH DIFFERENTIAL, NOFORMAT, NOINIT, NAME = N'''''' + @DatabaseName + ''-Full Database Backup'''', SKIP, NOREWIND, NOUNLOAD, STATS = 10, DESCRIPTION = N'''''' + @DatabaseName + '' backup'''', MEDIANAME = N'''''' + @DatabaseName + '' backup'''', MEDIADESCRIPTION = N'''''' + @DatabaseName + '' backup''''''
  --select @execStr

  exec @Result = sp_executesql @execStr
  if @@Error <> 0 or @Result <> 0 
    RAISERROR (@ErrorString,16,1);

end

', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Run Backup', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20070927, 
		@active_end_date=99991231, 
		@active_start_time=51500, 
		@active_end_time=235959, 
		@schedule_uid=N'201cd924-e987-447c-aa82-8864a0908234'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [Database Backup Full - ASPNETDB]    Script Date: 05/14/2013 13:07:43 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 05/14/2013 13:07:43 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Database Backup Full - ASPNETDB', 
		@enabled=1, 
		@notify_level_eventlog=2, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'sa', 
		@notify_email_operator_name=N'DBAlerts', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Backup Step]    Script Date: 05/14/2013 13:07:43 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Backup Step', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
declare 
  @DatabaseName varchar(25),
  @Location varchar(255),
  @ErrorString varchar(255),
  @Date datetime,
  @String varchar(15),
  @execStr NVarChar(1024),
  @Result int

set @DatabaseName = ''ASPNETDB''
set @Location = ''F:\MSSQL\Backup\''
set @ErrorString = ''Backup for Database ('' + @DatabaseName + '') has failed''
set @Date = GetDate()
set @String = convert(varchar(4), datepart( year, @Date)) + RIGHT(''0'' + convert(varchar(2), datepart( month, @Date)), 2) + RIGHT(''0'' + convert(varchar(2), datepart( day, @Date)), 2) + ''_'' +  RIGHT(''0'' + convert(varchar(2), datepart( hour, @Date)), 2) + RIGHT(''0'' + convert(varchar(2), datepart( minute, @Date)), 2) + RIGHT(''0'' + convert(varchar(2), datepart( second, @Date)), 2)
set @execStr = ''BACKUP DATABASE ['' + @DatabaseName + ''] TO  DISK = N'''''' + @Location + @DatabaseName + ''_'' + @String + ''.bak'''' WITH NOFORMAT, NOINIT, NAME = N'''''' + @DatabaseName + ''-Database Backup Full'''', SKIP, NOREWIND, NOUNLOAD, STATS = 10, DESCRIPTION = N'''''' + @DatabaseName + '' backup'''', MEDIANAME = N'''''' + @DatabaseName + '' backup'''', MEDIADESCRIPTION = N'''''' + @DatabaseName + '' backup''''''
--select @execStr

exec @Result = sp_executesql @execStr
if @@Error <> 0 or @Result <> 0 
  RAISERROR (@ErrorString,16,1);
', 
		@database_name=N'MASTER', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Run Backup', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20070927, 
		@active_end_date=99991231, 
		@active_start_time=40200, 
		@active_end_time=235959, 
		@schedule_uid=N'6caba779-1ded-4209-8ade-9f461f569bdf'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [Database Backup Full - DISTRIBUTION]    Script Date: 05/14/2013 13:07:43 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 05/14/2013 13:07:44 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Database Backup Full - DISTRIBUTION', 
		@enabled=1, 
		@notify_level_eventlog=2, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'sa', 
		@notify_email_operator_name=N'DBAlerts', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Backup Step]    Script Date: 05/14/2013 13:07:44 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Backup Step', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
declare 
  @DatabaseName varchar(25),
  @Location varchar(255),
  @ErrorString varchar(255),
  @Date datetime,
  @String varchar(15),
  @execStr NVarChar(1024),
  @Result int

set @DatabaseName = ''DISTRIBUTION''
set @Location = ''F:\MSSQL\Backup\''
set @ErrorString = ''Backup for Database ('' + @DatabaseName + '') has failed''
set @Date = GetDate()
set @String = convert(varchar(4), datepart( year, @Date)) + RIGHT(''0'' + convert(varchar(2), datepart( month, @Date)), 2) + RIGHT(''0'' + convert(varchar(2), datepart( day, @Date)), 2) + ''_'' +  RIGHT(''0'' + convert(varchar(2), datepart( hour, @Date)), 2) + RIGHT(''0'' + convert(varchar(2), datepart( minute, @Date)), 2) + RIGHT(''0'' + convert(varchar(2), datepart( second, @Date)), 2)
set @execStr = ''BACKUP DATABASE ['' + @DatabaseName + ''] TO  DISK = N'''''' + @Location + @DatabaseName + ''_'' + @String + ''.bak'''' WITH NOFORMAT, NOINIT, NAME = N'''''' + @DatabaseName + ''-Database Backup Full'''', SKIP, NOREWIND, NOUNLOAD, STATS = 10, DESCRIPTION = N'''''' + @DatabaseName + '' backup'''', MEDIANAME = N'''''' + @DatabaseName + '' backup'''', MEDIADESCRIPTION = N'''''' + @DatabaseName + '' backup''''''
--select @execStr

exec @Result = sp_executesql @execStr
if @@Error <> 0 or @Result <> 0 
  RAISERROR (@ErrorString,16,1);
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Run Backup', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20070927, 
		@active_end_date=99991231, 
		@active_start_time=40245, 
		@active_end_time=235959, 
		@schedule_uid=N'4462bae8-0eae-4fb5-8a8a-52ff1b4b03e7'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [Database Backup Full - EDMODO]    Script Date: 05/14/2013 13:07:44 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 05/14/2013 13:07:44 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Database Backup Full - EDMODO', 
		@enabled=1, 
		@notify_level_eventlog=2, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'sa', 
		@notify_email_operator_name=N'DBAlerts', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Backup Step]    Script Date: 05/14/2013 13:07:44 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Backup Step', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
declare 
  @DatabaseName varchar(25),
  @Location varchar(255),
  @ErrorString varchar(255),
  @Date datetime,
  @String varchar(15),
  @execStr NVarChar(1024),
  @Result int

set @DatabaseName = ''EDMODO''
set @Location = ''F:\MSSQL\Backup\''
set @ErrorString = ''Backup for Database ('' + @DatabaseName + '') has failed''
set @Date = GetDate()
set @String = convert(varchar(4), datepart( year, @Date)) + RIGHT(''0'' + convert(varchar(2), datepart( month, @Date)), 2) + RIGHT(''0'' + convert(varchar(2), datepart( day, @Date)), 2) + ''_'' +  RIGHT(''0'' + convert(varchar(2), datepart( hour, @Date)), 2) + RIGHT(''0'' + convert(varchar(2), datepart( minute, @Date)), 2) + RIGHT(''0'' + convert(varchar(2), datepart( second, @Date)), 2)
set @execStr = ''BACKUP DATABASE ['' + @DatabaseName + ''] TO  DISK = N'''''' + @Location + @DatabaseName + ''_'' + @String + ''.bak'''' WITH NOFORMAT, NOINIT, NAME = N'''''' + @DatabaseName + ''-Database Backup Full'''', SKIP, NOREWIND, NOUNLOAD, STATS = 10, DESCRIPTION = N'''''' + @DatabaseName + '' backup'''', MEDIANAME = N'''''' + @DatabaseName + '' backup'''', MEDIADESCRIPTION = N'''''' + @DatabaseName + '' backup''''''
--select @execStr

exec @Result = sp_executesql @execStr
if @@Error <> 0 or @Result <> 0 
  RAISERROR (@ErrorString,16,1);
', 
		@database_name=N'MASTER', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Run Backup', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20070927, 
		@active_end_date=99991231, 
		@active_start_time=40115, 
		@active_end_time=235959, 
		@schedule_uid=N'37e7afd0-9259-45fe-ab4c-87562171c390'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [Database Backup Full - EDMODOBOX]    Script Date: 05/14/2013 13:07:44 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 05/14/2013 13:07:44 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Database Backup Full - EDMODOBOX', 
		@enabled=1, 
		@notify_level_eventlog=2, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'sa', 
		@notify_email_operator_name=N'DBAlerts', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Backup Step]    Script Date: 05/14/2013 13:07:44 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Backup Step', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
declare 
  @DatabaseName varchar(25),
  @Location varchar(255),
  @ErrorString varchar(255),
  @Date datetime,
  @String varchar(15),
  @execStr NVarChar(1024),
  @Result int

set @DatabaseName = ''EDMODOBOX''
set @Location = ''F:\MSSQL\Backup\''
set @ErrorString = ''Backup for Database ('' + @DatabaseName + '') has failed''
set @Date = GetDate()
set @String = convert(varchar(4), datepart( year, @Date)) + RIGHT(''0'' + convert(varchar(2), datepart( month, @Date)), 2) + RIGHT(''0'' + convert(varchar(2), datepart( day, @Date)), 2) + ''_'' +  RIGHT(''0'' + convert(varchar(2), datepart( hour, @Date)), 2) + RIGHT(''0'' + convert(varchar(2), datepart( minute, @Date)), 2) + RIGHT(''0'' + convert(varchar(2), datepart( second, @Date)), 2)
set @execStr = ''BACKUP DATABASE ['' + @DatabaseName + ''] TO  DISK = N'''''' + @Location + @DatabaseName + ''_'' + @String + ''.bak'''' WITH NOFORMAT, NOINIT, NAME = N'''''' + @DatabaseName + ''-Database Backup Full'''', SKIP, NOREWIND, NOUNLOAD, STATS = 10, DESCRIPTION = N'''''' + @DatabaseName + '' backup'''', MEDIANAME = N'''''' + @DatabaseName + '' backup'''', MEDIADESCRIPTION = N'''''' + @DatabaseName + '' backup''''''
--select @execStr

exec @Result = sp_executesql @execStr
if @@Error <> 0 or @Result <> 0 
  RAISERROR (@ErrorString,16,1);
', 
		@database_name=N'MASTER', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Run Backup', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20070927, 
		@active_end_date=99991231, 
		@active_start_time=40130, 
		@active_end_time=235959, 
		@schedule_uid=N'72948ebe-19ef-4c72-8af2-c0aaee3cf498'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [Database Backup Full - ILBlog]    Script Date: 05/14/2013 13:07:45 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 05/14/2013 13:07:45 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Database Backup Full - ILBlog', 
		@enabled=1, 
		@notify_level_eventlog=2, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'sa', 
		@notify_email_operator_name=N'DBAlerts', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Backup Step]    Script Date: 05/14/2013 13:07:45 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Backup Step', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
declare 
  @DatabaseName varchar(25),
  @Location varchar(255),
  @ErrorString varchar(255),
  @Date datetime,
  @String varchar(15),
  @execStr NVarChar(1024),
  @Result int

set @DatabaseName = ''ILBlog''
set @Location = ''F:\MSSQL\Backup\''
set @ErrorString = ''Backup for Database ('' + @DatabaseName + '') has failed''
set @Date = GetDate()
set @String = convert(varchar(4), datepart( year, @Date)) + RIGHT(''0'' + convert(varchar(2), datepart( month, @Date)), 2) + RIGHT(''0'' + convert(varchar(2), datepart( day, @Date)), 2) + ''_'' +  RIGHT(''0'' + convert(varchar(2), datepart( hour, @Date)), 2) + RIGHT(''0'' + convert(varchar(2), datepart( minute, @Date)), 2) + RIGHT(''0'' + convert(varchar(2), datepart( second, @Date)), 2)
set @execStr = ''BACKUP DATABASE ['' + @DatabaseName + ''] TO  DISK = N'''''' + @Location + @DatabaseName + ''_'' + @String + ''.bak'''' WITH NOFORMAT, NOINIT, NAME = N'''''' + @DatabaseName + ''-Database Backup Full'''', SKIP, NOREWIND, NOUNLOAD, STATS = 10, DESCRIPTION = N'''''' + @DatabaseName + '' backup'''', MEDIANAME = N'''''' + @DatabaseName + '' backup'''', MEDIADESCRIPTION = N'''''' + @DatabaseName + '' backup''''''
--select @execStr

exec @Result = sp_executesql @execStr
if @@Error <> 0 or @Result <> 0 
  RAISERROR (@ErrorString,16,1);
', 
		@database_name=N'MASTER', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Run Backup', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20070927, 
		@active_end_date=99991231, 
		@active_start_time=40200, 
		@active_end_time=235959, 
		@schedule_uid=N'6caba779-1ded-4209-8ade-9f461f569bdf'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [Database Backup Full - ILBlogLegacy]    Script Date: 05/14/2013 13:07:45 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 05/14/2013 13:07:45 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Database Backup Full - ILBlogLegacy', 
		@enabled=1, 
		@notify_level_eventlog=2, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'sa', 
		@notify_email_operator_name=N'DBAlerts', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Backup Step]    Script Date: 05/14/2013 13:07:45 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Backup Step', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
declare 
  @DatabaseName varchar(25),
  @Location varchar(255),
  @ErrorString varchar(255),
  @Date datetime,
  @String varchar(15),
  @execStr NVarChar(1024),
  @Result int

set @DatabaseName = ''ILBlogLegacy''
set @Location = ''F:\MSSQL\Backup\''
set @ErrorString = ''Backup for Database ('' + @DatabaseName + '') has failed''
set @Date = GetDate()
set @String = convert(varchar(4), datepart( year, @Date)) + RIGHT(''0'' + convert(varchar(2), datepart( month, @Date)), 2) + RIGHT(''0'' + convert(varchar(2), datepart( day, @Date)), 2) + ''_'' +  RIGHT(''0'' + convert(varchar(2), datepart( hour, @Date)), 2) + RIGHT(''0'' + convert(varchar(2), datepart( minute, @Date)), 2) + RIGHT(''0'' + convert(varchar(2), datepart( second, @Date)), 2)
set @execStr = ''BACKUP DATABASE ['' + @DatabaseName + ''] TO  DISK = N'''''' + @Location + @DatabaseName + ''_'' + @String + ''.bak'''' WITH NOFORMAT, NOINIT, NAME = N'''''' + @DatabaseName + ''-Database Backup Full'''', SKIP, NOREWIND, NOUNLOAD, STATS = 10, DESCRIPTION = N'''''' + @DatabaseName + '' backup'''', MEDIANAME = N'''''' + @DatabaseName + '' backup'''', MEDIADESCRIPTION = N'''''' + @DatabaseName + '' backup''''''
--select @execStr

exec @Result = sp_executesql @execStr
if @@Error <> 0 or @Result <> 0 
  RAISERROR (@ErrorString,16,1);
', 
		@database_name=N'MASTER', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Run Backup', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20070927, 
		@active_end_date=99991231, 
		@active_start_time=40200, 
		@active_end_time=235959, 
		@schedule_uid=N'6caba779-1ded-4209-8ade-9f461f569bdf'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [Database Backup Full - ILCENTRAL]    Script Date: 05/14/2013 13:07:45 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 05/14/2013 13:07:45 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Database Backup Full - ILCENTRAL', 
		@enabled=1, 
		@notify_level_eventlog=2, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'Backup', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'sa', 
		@notify_email_operator_name=N'DBAlerts', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Backup Step]    Script Date: 05/14/2013 13:07:46 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Backup Step', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
declare 
  @DatabaseName varchar(25),
  @Location varchar(255),
  @ErrorString varchar(255),
  @Date datetime,
  @String varchar(15),
  @execStr NVarChar(1024),
  @Result int

set @DatabaseName = ''ILCENTRAL''
set @Location = ''F:\MSSQL\Backup\''
set @ErrorString = ''Backup for Database ('' + @DatabaseName + '') has failed''
set @Date = GetDate()
set @String = convert(varchar(4), datepart( year, @Date)) + RIGHT(''0'' + convert(varchar(2), datepart( month, @Date)), 2) + RIGHT(''0'' + convert(varchar(2), datepart( day, @Date)), 2) + ''_'' +  RIGHT(''0'' + convert(varchar(2), datepart( hour, @Date)), 2) + RIGHT(''0'' + convert(varchar(2), datepart( minute, @Date)), 2) + RIGHT(''0'' + convert(varchar(2), datepart( second, @Date)), 2)
set @execStr = ''BACKUP DATABASE ['' + @DatabaseName + ''] TO  DISK = N'''''' + @Location + @DatabaseName + ''_'' + @String + ''.bak'''' WITH NOFORMAT, NOINIT, NAME = N'''''' + @DatabaseName + ''-Database Backup Full'''', SKIP, NOREWIND, NOUNLOAD, STATS = 10, DESCRIPTION = N'''''' + @DatabaseName + '' backup'''', MEDIANAME = N'''''' + @DatabaseName + '' backup'''', MEDIADESCRIPTION = N'''''' + @DatabaseName + '' backup''''''
--select @execStr

exec @Result = sp_executesql @execStr
if @@Error <> 0 or @Result <> 0 
  RAISERROR (@ErrorString,16,1);
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Run Backup', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20070927, 
		@active_end_date=99991231, 
		@active_start_time=41700, 
		@active_end_time=235959, 
		@schedule_uid=N'c096b858-27b1-411e-b37b-4a01245ef57b'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [Database Backup Full - ILCENTRALDATA]    Script Date: 05/14/2013 13:07:46 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 05/14/2013 13:07:46 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Database Backup Full - ILCENTRALDATA', 
		@enabled=1, 
		@notify_level_eventlog=2, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'sa', 
		@notify_email_operator_name=N'DBAlerts', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Backup Step]    Script Date: 05/14/2013 13:07:46 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Backup Step', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
declare 
  @DatabaseName varchar(25),
  @Location varchar(255),
  @ErrorString varchar(255),
  @Date datetime,
  @String varchar(15),
  @execStr NVarChar(1024),
  @Result int

set @DatabaseName = ''ILCENTRALDATA''
set @Location = ''F:\MSSQL\Backup\''
set @ErrorString = ''Backup for Database ('' + @DatabaseName + '') has failed''
set @Date = GetDate()
set @String = convert(varchar(4), datepart( year, @Date)) + RIGHT(''0'' + convert(varchar(2), datepart( month, @Date)), 2) + RIGHT(''0'' + convert(varchar(2), datepart( day, @Date)), 2) + ''_'' +  RIGHT(''0'' + convert(varchar(2), datepart( hour, @Date)), 2) + RIGHT(''0'' + convert(varchar(2), datepart( minute, @Date)), 2) + RIGHT(''0'' + convert(varchar(2), datepart( second, @Date)), 2)
set @execStr = ''BACKUP DATABASE ['' + @DatabaseName + ''] TO  DISK = N'''''' + @Location + @DatabaseName + ''_'' + @String + ''.bak'''' WITH NOFORMAT, NOINIT, NAME = N'''''' + @DatabaseName + ''-Database Backup Full'''', SKIP, NOREWIND, NOUNLOAD, STATS = 10, DESCRIPTION = N'''''' + @DatabaseName + '' backup'''', MEDIANAME = N'''''' + @DatabaseName + '' backup'''', MEDIADESCRIPTION = N'''''' + @DatabaseName + '' backup''''''
--select @execStr

exec @Result = sp_executesql @execStr
if @@Error <> 0 or @Result <> 0 
  RAISERROR (@ErrorString,16,1);
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Run Backup', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20070927, 
		@active_end_date=99991231, 
		@active_start_time=61900, 
		@active_end_time=235959, 
		@schedule_uid=N'db9756aa-43c6-49b3-b6f0-83ceeef67655'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [Database Backup Full - ILCENTRALDATAARCHIVE]    Script Date: 05/14/2013 13:07:46 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 05/14/2013 13:07:46 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Database Backup Full - ILCENTRALDATAARCHIVE', 
		@enabled=1, 
		@notify_level_eventlog=2, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'sa', 
		@notify_email_operator_name=N'DBAlerts', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Backup Step]    Script Date: 05/14/2013 13:07:46 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Backup Step', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
declare 
  @DatabaseName varchar(25),
  @Location varchar(255),
  @ErrorString varchar(255),
  @Date datetime,
  @String varchar(15),
  @execStr NVarChar(1024),
  @Result int

set @DatabaseName = ''ILCENTRALDATAARCHIVE''
set @Location = ''F:\MSSQL\Backup\''
set @ErrorString = ''Backup for Database ('' + @DatabaseName + '') has failed''
set @Date = GetDate()
set @String = convert(varchar(4), datepart( year, @Date)) + RIGHT(''0'' + convert(varchar(2), datepart( month, @Date)), 2) + RIGHT(''0'' + convert(varchar(2), datepart( day, @Date)), 2) + ''_'' +  RIGHT(''0'' + convert(varchar(2), datepart( hour, @Date)), 2) + RIGHT(''0'' + convert(varchar(2), datepart( minute, @Date)), 2) + RIGHT(''0'' + convert(varchar(2), datepart( second, @Date)), 2)
set @execStr = ''BACKUP DATABASE ['' + @DatabaseName + ''] TO  DISK = N'''''' + @Location + @DatabaseName + ''_'' + @String + ''.bak'''' WITH NOFORMAT, NOINIT, NAME = N'''''' + @DatabaseName + ''-Database Backup Full'''', SKIP, NOREWIND, NOUNLOAD, STATS = 10, DESCRIPTION = N'''''' + @DatabaseName + '' backup'''', MEDIANAME = N'''''' + @DatabaseName + '' backup'''', MEDIADESCRIPTION = N'''''' + @DatabaseName + '' backup''''''
--select @execStr

exec @Result = sp_executesql @execStr
if @@Error <> 0 or @Result <> 0 
  RAISERROR (@ErrorString,16,1);
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Run Backup', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20070927, 
		@active_end_date=99991231, 
		@active_start_time=72900, 
		@active_end_time=235959, 
		@schedule_uid=N'369e7064-ec62-4959-86e0-a957df1753a6'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [Database Backup Full - ILCENTRALDATACUM]    Script Date: 05/14/2013 13:07:46 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 05/14/2013 13:07:46 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Database Backup Full - ILCENTRALDATACUM', 
		@enabled=1, 
		@notify_level_eventlog=2, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'sa', 
		@notify_email_operator_name=N'DBAlerts', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Backup Step]    Script Date: 05/14/2013 13:07:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Backup Step', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
--Determine if we should backup today.  Full backups only occur every 3 days
if ( datePart( day, GETDATE()) % 3) = 0
begin
    
  declare 
    @DatabaseName varchar(25),
    @Location varchar(255),
    @ErrorString varchar(255),
    @Date datetime,
    @String varchar(15),
    @execStr NVarChar(1024),
    @Result int

  set @DatabaseName = ''ILCENTRALDATACUM''
  set @Location = ''F:\MSSQL\Backup\''
  set @ErrorString = ''Backup for Database ('' + @DatabaseName + '') has failed''
  set @Date = GetDate()
  set @String = convert(varchar(4), datepart( year, @Date)) + RIGHT(''0'' + convert(varchar(2), datepart( month, @Date)), 2) + RIGHT(''0'' + convert(varchar(2), datepart( day, @Date)), 2) + ''_'' +  RIGHT(''0'' + convert(varchar(2), datepart( hour, @Date)), 2) + RIGHT(''0'' + convert(varchar(2), datepart( minute, @Date)), 2) + RIGHT(''0'' + convert(varchar(2), datepart( second, @Date)), 2)
  set @execStr = ''BACKUP DATABASE ['' + @DatabaseName + ''] TO  DISK = N'''''' + @Location + @DatabaseName + ''_'' + @String + ''.bak'''' WITH NOFORMAT, NOINIT, NAME = N'''''' + @DatabaseName + ''-Database Backup Full'''', SKIP, NOREWIND, NOUNLOAD, STATS = 10, DESCRIPTION = N'''''' + @DatabaseName + '' backup'''', MEDIANAME = N'''''' + @DatabaseName + '' backup'''', MEDIADESCRIPTION = N'''''' + @DatabaseName + '' backup''''''
  --select @execStr

  exec @Result = sp_executesql @execStr
  if @@Error <> 0 or @Result <> 0 
    RAISERROR (@ErrorString,16,1);

end

', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Run Backup', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20070927, 
		@active_end_date=99991231, 
		@active_start_time=62900, 
		@active_end_time=235959, 
		@schedule_uid=N'bbc6c7b1-a1d7-45cf-903f-ce3fc37de2c1'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [Database Backup Full - ILCENTRALDATACUM - simple]    Script Date: 05/14/2013 13:07:47 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 05/14/2013 13:07:47 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Database Backup Full - ILCENTRALDATACUM - simple', 
		@enabled=0, 
		@notify_level_eventlog=2, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'sa', 
		@notify_email_operator_name=N'DBAlerts', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Backup Step]    Script Date: 05/14/2013 13:07:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Backup Step', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'

  declare 
    @DatabaseName varchar(25),
    @Location varchar(255),
    @ErrorString varchar(255),
    @Date datetime,
    @String varchar(15),
    @execStr NVarChar(1024),
    @Result int

  set @DatabaseName = ''ILCENTRALDATACUM''
  set @Location = ''F:\MSSQL\Backup\''
  set @ErrorString = ''Backup for Database ('' + @DatabaseName + '') has failed''
  set @Date = GetDate()
  set @String = convert(varchar(4), datepart( year, @Date)) + RIGHT(''0'' + convert(varchar(2), datepart( month, @Date)), 2) + RIGHT(''0'' + convert(varchar(2), datepart( day, @Date)), 2) + ''_'' +  RIGHT(''0'' + convert(varchar(2), datepart( hour, @Date)), 2) + RIGHT(''0'' + convert(varchar(2), datepart( minute, @Date)), 2) + RIGHT(''0'' + convert(varchar(2), datepart( second, @Date)), 2)
  set @execStr = ''BACKUP DATABASE ['' + @DatabaseName + ''] TO  DISK = N'''''' + @Location + @DatabaseName + ''_'' + @String + ''.bak'''' WITH NOFORMAT, NOINIT, NAME = N'''''' + @DatabaseName + ''-Database Backup Full'''', SKIP, NOREWIND, NOUNLOAD, STATS = 10, DESCRIPTION = N'''''' + @DatabaseName + '' backup'''', MEDIANAME = N'''''' + @DatabaseName + '' backup'''', MEDIADESCRIPTION = N'''''' + @DatabaseName + '' backup''''''
  --select @execStr

  exec @Result = sp_executesql @execStr
  if @@Error <> 0 or @Result <> 0 
    RAISERROR (@ErrorString,16,1);

', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [Database Backup Full - ILCENTRALDATAENT]    Script Date: 05/14/2013 13:07:47 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 05/14/2013 13:07:47 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Database Backup Full - ILCENTRALDATAENT', 
		@enabled=1, 
		@notify_level_eventlog=2, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'sa', 
		@notify_email_operator_name=N'DBAlerts', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Backup Step]    Script Date: 05/14/2013 13:07:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Backup Step', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
declare 
  @DatabaseName varchar(25),
  @Location varchar(255),
  @ErrorString varchar(255),
  @Date datetime,
  @String varchar(15),
  @execStr NVarChar(1024),
  @Result int

set @DatabaseName = ''ILCENTRALDATAENT''
set @Location = ''F:\MSSQL\Backup\''
set @ErrorString = ''Backup for Database ('' + @DatabaseName + '') has failed''
set @Date = GetDate()
set @String = convert(varchar(4), datepart( year, @Date)) + RIGHT(''0'' + convert(varchar(2), datepart( month, @Date)), 2) + RIGHT(''0'' + convert(varchar(2), datepart( day, @Date)), 2) + ''_'' +  RIGHT(''0'' + convert(varchar(2), datepart( hour, @Date)), 2) + RIGHT(''0'' + convert(varchar(2), datepart( minute, @Date)), 2) + RIGHT(''0'' + convert(varchar(2), datepart( second, @Date)), 2)
set @execStr = ''BACKUP DATABASE ['' + @DatabaseName + ''] TO  DISK = N'''''' + @Location + @DatabaseName + ''_'' + @String + ''.bak'''' WITH NOFORMAT, NOINIT, NAME = N'''''' + @DatabaseName + ''-Database Backup Full'''', SKIP, NOREWIND, NOUNLOAD, STATS = 10, DESCRIPTION = N'''''' + @DatabaseName + '' backup'''', MEDIANAME = N'''''' + @DatabaseName + '' backup'''', MEDIADESCRIPTION = N'''''' + @DatabaseName + '' backup''''''
--select @execStr

exec @Result = sp_executesql @execStr
if @@Error <> 0 or @Result <> 0 
  RAISERROR (@ErrorString,16,1);
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Run Backup', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20070927, 
		@active_end_date=99991231, 
		@active_start_time=61900, 
		@active_end_time=235959, 
		@schedule_uid=N'db9756aa-43c6-49b3-b6f0-83ceeef67655'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [Database Backup Full - ILCONSUMER]    Script Date: 05/14/2013 13:07:47 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 05/14/2013 13:07:47 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Database Backup Full - ILCONSUMER', 
		@enabled=1, 
		@notify_level_eventlog=2, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'sa', 
		@notify_email_operator_name=N'DBAlerts', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Backup Step]    Script Date: 05/14/2013 13:07:48 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Backup Step', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
declare 
  @DatabaseName varchar(25),
  @Location varchar(255),
  @ErrorString varchar(255),
  @Date datetime,
  @String varchar(15),
  @execStr NVarChar(1024),
  @Result int

set @DatabaseName = ''ILCONSUMER''
set @Location = ''F:\MSSQL\Backup\''
set @ErrorString = ''Backup for Database ('' + @DatabaseName + '') has failed''
set @Date = GetDate()
set @String = convert(varchar(4), datepart( year, @Date)) + RIGHT(''0'' + convert(varchar(2), datepart( month, @Date)), 2) + RIGHT(''0'' + convert(varchar(2), datepart( day, @Date)), 2) + ''_'' +  RIGHT(''0'' + convert(varchar(2), datepart( hour, @Date)), 2) + RIGHT(''0'' + convert(varchar(2), datepart( minute, @Date)), 2) + RIGHT(''0'' + convert(varchar(2), datepart( second, @Date)), 2)
set @execStr = ''BACKUP DATABASE ['' + @DatabaseName + ''] TO  DISK = N'''''' + @Location + @DatabaseName + ''_'' + @String + ''.bak'''' WITH NOFORMAT, NOINIT, NAME = N'''''' + @DatabaseName + ''-Database Backup Full'''', SKIP, NOREWIND, NOUNLOAD, STATS = 10, DESCRIPTION = N'''''' + @DatabaseName + '' backup'''', MEDIANAME = N'''''' + @DatabaseName + '' backup'''', MEDIADESCRIPTION = N'''''' + @DatabaseName + '' backup''''''
--select @execStr

exec @Result = sp_executesql @execStr
if @@Error <> 0 or @Result <> 0 
  RAISERROR (@ErrorString,16,1);
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Run Backup', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20070927, 
		@active_end_date=99991231, 
		@active_start_time=41300, 
		@active_end_time=235959, 
		@schedule_uid=N'e525eb56-8b44-4fe1-aaf4-3a1d4d113fe8'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [Database Backup Full - ILDAM]    Script Date: 05/14/2013 13:07:48 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 05/14/2013 13:07:48 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Database Backup Full - ILDAM', 
		@enabled=1, 
		@notify_level_eventlog=2, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'sa', 
		@notify_email_operator_name=N'DBAlerts', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Backup Step]    Script Date: 05/14/2013 13:07:48 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Backup Step', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
declare 
  @DatabaseName varchar(25),
  @Location varchar(255),
  @ErrorString varchar(255),
  @Date datetime,
  @String varchar(15),
  @execStr NVarChar(1024),
  @Result int

set @DatabaseName = ''ILDAM''
set @Location = ''F:\MSSQL\Backup\''
set @ErrorString = ''Backup for Database ('' + @DatabaseName + '') has failed''
set @Date = GetDate()
set @String = convert(varchar(4), datepart( year, @Date)) + RIGHT(''0'' + convert(varchar(2), datepart( month, @Date)), 2) + RIGHT(''0'' + convert(varchar(2), datepart( day, @Date)), 2) + ''_'' +  RIGHT(''0'' + convert(varchar(2), datepart( hour, @Date)), 2) + RIGHT(''0'' + convert(varchar(2), datepart( minute, @Date)), 2) + RIGHT(''0'' + convert(varchar(2), datepart( second, @Date)), 2)
set @execStr = ''BACKUP DATABASE ['' + @DatabaseName + ''] TO  DISK = N'''''' + @Location + @DatabaseName + ''_'' + @String + ''.bak'''' WITH NOFORMAT, NOINIT, NAME = N'''''' + @DatabaseName + ''-Database Backup Full'''', SKIP, NOREWIND, NOUNLOAD, STATS = 10, DESCRIPTION = N'''''' + @DatabaseName + '' backup'''', MEDIANAME = N'''''' + @DatabaseName + '' backup'''', MEDIADESCRIPTION = N'''''' + @DatabaseName + '' backup''''''
--select @execStr

exec @Result = sp_executesql @execStr
if @@Error <> 0 or @Result <> 0 
  RAISERROR (@ErrorString,16,1);
', 
		@database_name=N'MASTER', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Run Backup', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20070927, 
		@active_end_date=99991231, 
		@active_start_time=40215, 
		@active_end_time=235959, 
		@schedule_uid=N'65504247-0397-421f-b311-f590e496472b'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [Database Backup Full - ILLOGS]    Script Date: 05/14/2013 13:07:48 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 05/14/2013 13:07:48 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Database Backup Full - ILLOGS', 
		@enabled=1, 
		@notify_level_eventlog=2, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'sa', 
		@notify_email_operator_name=N'DBAlerts', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Backup Step]    Script Date: 05/14/2013 13:07:48 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Backup Step', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
declare 
  @DatabaseName varchar(25),
  @Location varchar(255),
  @ErrorString varchar(255),
  @Date datetime,
  @String varchar(15),
  @execStr NVarChar(1024),
  @Result int

set @DatabaseName = ''ILLOGS''
set @Location = ''F:\MSSQL\Backup\''
set @ErrorString = ''Backup for Database ('' + @DatabaseName + '') has failed''
set @Date = GetDate()
set @String = convert(varchar(4), datepart( year, @Date)) + RIGHT(''0'' + convert(varchar(2), datepart( month, @Date)), 2) + RIGHT(''0'' + convert(varchar(2), datepart( day, @Date)), 2) + ''_'' +  RIGHT(''0'' + convert(varchar(2), datepart( hour, @Date)), 2) + RIGHT(''0'' + convert(varchar(2), datepart( minute, @Date)), 2) + RIGHT(''0'' + convert(varchar(2), datepart( second, @Date)), 2)
set @execStr = ''BACKUP DATABASE ['' + @DatabaseName + ''] TO  DISK = N'''''' + @Location + @DatabaseName + ''_'' + @String + ''.bak'''' WITH NOFORMAT, NOINIT, NAME = N'''''' + @DatabaseName + ''-Database Backup Full'''', SKIP, NOREWIND, NOUNLOAD, STATS = 10, DESCRIPTION = N'''''' + @DatabaseName + '' backup'''', MEDIANAME = N'''''' + @DatabaseName + '' backup'''', MEDIADESCRIPTION = N'''''' + @DatabaseName + '' backup''''''
--select @execStr

exec @Result = sp_executesql @execStr
if @@Error <> 0 or @Result <> 0 
  RAISERROR (@ErrorString,16,1);
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Run Backup', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20070927, 
		@active_end_date=99991231, 
		@active_start_time=41500, 
		@active_end_time=235959, 
		@schedule_uid=N'78077892-c2b8-4784-a8e1-bfd348a468e2'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [Database Backup Full - ILStoreFront]    Script Date: 05/14/2013 13:07:48 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 05/14/2013 13:07:49 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Database Backup Full - ILStoreFront', 
		@enabled=1, 
		@notify_level_eventlog=2, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'sa', 
		@notify_email_operator_name=N'DBAlerts', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Backup Step]    Script Date: 05/14/2013 13:07:49 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Backup Step', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
declare 
  @DatabaseName varchar(25),
  @Location varchar(255),
  @ErrorString varchar(255),
  @Date datetime,
  @String varchar(15),
  @execStr NVarChar(1024),
  @Result int

set @DatabaseName = ''ILStoreFront''
set @Location = ''F:\MSSQL\Backup\''
set @ErrorString = ''Backup for Database ('' + @DatabaseName + '') has failed''
set @Date = GetDate()
set @String = convert(varchar(4), datepart( year, @Date)) + RIGHT(''0'' + convert(varchar(2), datepart( month, @Date)), 2) + RIGHT(''0'' + convert(varchar(2), datepart( day, @Date)), 2) + ''_'' +  RIGHT(''0'' + convert(varchar(2), datepart( hour, @Date)), 2) + RIGHT(''0'' + convert(varchar(2), datepart( minute, @Date)), 2) + RIGHT(''0'' + convert(varchar(2), datepart( second, @Date)), 2)
set @execStr = ''BACKUP DATABASE ['' + @DatabaseName + ''] TO  DISK = N'''''' + @Location + @DatabaseName + ''_'' + @String + ''.bak'''' WITH NOFORMAT, NOINIT, NAME = N'''''' + @DatabaseName + ''-Database Backup Full'''', SKIP, NOREWIND, NOUNLOAD, STATS = 10, DESCRIPTION = N'''''' + @DatabaseName + '' backup'''', MEDIANAME = N'''''' + @DatabaseName + '' backup'''', MEDIADESCRIPTION = N'''''' + @DatabaseName + '' backup''''''
--select @execStr

exec @Result = sp_executesql @execStr
if @@Error <> 0 or @Result <> 0 
  RAISERROR (@ErrorString,16,1);
', 
		@database_name=N'MASTER', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Run Backup', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20070927, 
		@active_end_date=99991231, 
		@active_start_time=40230, 
		@active_end_time=235959, 
		@schedule_uid=N'04185f95-eff7-4c41-ab3d-e49396d7d15b'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [Database Backup Full - ILWeb]    Script Date: 05/14/2013 13:07:49 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 05/14/2013 13:07:49 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Database Backup Full - ILWeb', 
		@enabled=1, 
		@notify_level_eventlog=2, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'sa', 
		@notify_email_operator_name=N'DBAlerts', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Backup Step]    Script Date: 05/14/2013 13:07:49 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Backup Step', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
declare 
  @DatabaseName varchar(25),
  @Location varchar(255),
  @ErrorString varchar(255),
  @Date datetime,
  @String varchar(15),
  @execStr NVarChar(1024),
  @Result int

set @DatabaseName = ''ILWeb''
set @Location = ''F:\MSSQL\Backup\''
set @ErrorString = ''Backup for Database ('' + @DatabaseName + '') has failed''
set @Date = GetDate()
set @String = convert(varchar(4), datepart( year, @Date)) + RIGHT(''0'' + convert(varchar(2), datepart( month, @Date)), 2) + RIGHT(''0'' + convert(varchar(2), datepart( day, @Date)), 2) + ''_'' +  RIGHT(''0'' + convert(varchar(2), datepart( hour, @Date)), 2) + RIGHT(''0'' + convert(varchar(2), datepart( minute, @Date)), 2) + RIGHT(''0'' + convert(varchar(2), datepart( second, @Date)), 2)
set @execStr = ''BACKUP DATABASE ['' + @DatabaseName + ''] TO  DISK = N'''''' + @Location + @DatabaseName + ''_'' + @String + ''.bak'''' WITH NOFORMAT, NOINIT, NAME = N'''''' + @DatabaseName + ''-Database Backup Full'''', SKIP, NOREWIND, NOUNLOAD, STATS = 10, DESCRIPTION = N'''''' + @DatabaseName + '' backup'''', MEDIANAME = N'''''' + @DatabaseName + '' backup'''', MEDIADESCRIPTION = N'''''' + @DatabaseName + '' backup''''''
--select @execStr

exec @Result = sp_executesql @execStr
if @@Error <> 0 or @Result <> 0 
  RAISERROR (@ErrorString,16,1);
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Run Backup', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20070927, 
		@active_end_date=99991231, 
		@active_start_time=41400, 
		@active_end_time=235959, 
		@schedule_uid=N'7b6af57e-683c-42e9-aee2-84eb66e12bc8'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [Database Backup Full - IMAGINE]    Script Date: 05/14/2013 13:07:49 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 05/14/2013 13:07:49 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Database Backup Full - IMAGINE', 
		@enabled=1, 
		@notify_level_eventlog=2, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'sa', 
		@notify_email_operator_name=N'DBAlerts', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Backup Step]    Script Date: 05/14/2013 13:07:49 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Backup Step', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
declare 
  @DatabaseName varchar(25),
  @Location varchar(255),
  @ErrorString varchar(255),
  @Date datetime,
  @String varchar(15),
  @execStr NVarChar(1024),
  @Result int

set @DatabaseName = ''IMAGINE''
set @Location = ''F:\MSSQL\Backup\''
set @ErrorString = ''Backup for Database ('' + @DatabaseName + '') has failed''
set @Date = GetDate()
set @String = convert(varchar(4), datepart( year, @Date)) + RIGHT(''0'' + convert(varchar(2), datepart( month, @Date)), 2) + RIGHT(''0'' + convert(varchar(2), datepart( day, @Date)), 2) + ''_'' +  RIGHT(''0'' + convert(varchar(2), datepart( hour, @Date)), 2) + RIGHT(''0'' + convert(varchar(2), datepart( minute, @Date)), 2) + RIGHT(''0'' + convert(varchar(2), datepart( second, @Date)), 2)
set @execStr = ''BACKUP DATABASE ['' + @DatabaseName + ''] TO  DISK = N'''''' + @Location + @DatabaseName + ''_'' + @String + ''.bak'''' WITH NOFORMAT, NOINIT, NAME = N'''''' + @DatabaseName + ''-Database Backup Full'''', SKIP, NOREWIND, NOUNLOAD, STATS = 10, DESCRIPTION = N'''''' + @DatabaseName + '' backup'''', MEDIANAME = N'''''' + @DatabaseName + '' backup'''', MEDIADESCRIPTION = N'''''' + @DatabaseName + '' backup''''''
--select @execStr

exec @Result = sp_executesql @execStr
if @@Error <> 0 or @Result <> 0 
  RAISERROR (@ErrorString,16,1);
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Run Backup', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20070927, 
		@active_end_date=99991231, 
		@active_start_time=41415, 
		@active_end_time=235959, 
		@schedule_uid=N'324fd431-c826-4abb-8eb8-5cc248e12354'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [Database Backup Full - IMAGINE_2008_8]    Script Date: 05/14/2013 13:07:49 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 05/14/2013 13:07:49 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Database Backup Full - IMAGINE_2008_8', 
		@enabled=1, 
		@notify_level_eventlog=2, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'sa', 
		@notify_email_operator_name=N'DBAlerts', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Backup Step]    Script Date: 05/14/2013 13:07:50 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Backup Step', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
declare 
  @DatabaseName varchar(25),
  @Location varchar(255),
  @ErrorString varchar(255),
  @Date datetime,
  @String varchar(15),
  @execStr NVarChar(1024),
  @Result int

set @DatabaseName = ''IMAGINE_2008_8''
set @Location = ''F:\MSSQL\Backup\''
set @ErrorString = ''Backup for Database ('' + @DatabaseName + '') has failed''
set @Date = GetDate()
set @String = convert(varchar(4), datepart( year, @Date)) + RIGHT(''0'' + convert(varchar(2), datepart( month, @Date)), 2) + RIGHT(''0'' + convert(varchar(2), datepart( day, @Date)), 2) + ''_'' +  RIGHT(''0'' + convert(varchar(2), datepart( hour, @Date)), 2) + RIGHT(''0'' + convert(varchar(2), datepart( minute, @Date)), 2) + RIGHT(''0'' + convert(varchar(2), datepart( second, @Date)), 2)
set @execStr = ''BACKUP DATABASE ['' + @DatabaseName + ''] TO  DISK = N'''''' + @Location + @DatabaseName + ''_'' + @String + ''.bak'''' WITH NOFORMAT, NOINIT, NAME = N'''''' + @DatabaseName + ''-Database Backup Full'''', SKIP, NOREWIND, NOUNLOAD, STATS = 10, DESCRIPTION = N'''''' + @DatabaseName + '' backup'''', MEDIANAME = N'''''' + @DatabaseName + '' backup'''', MEDIADESCRIPTION = N'''''' + @DatabaseName + '' backup''''''
--select @execStr

exec @Result = sp_executesql @execStr
if @@Error <> 0 or @Result <> 0 
  RAISERROR (@ErrorString,16,1);
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Run Backup', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20070927, 
		@active_end_date=99991231, 
		@active_start_time=41430, 
		@active_end_time=235959, 
		@schedule_uid=N'39f518ad-1280-4023-a6ce-bdc791a15f54'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [Database Backup Full - MASTER]    Script Date: 05/14/2013 13:07:50 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 05/14/2013 13:07:50 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Database Backup Full - MASTER', 
		@enabled=1, 
		@notify_level_eventlog=2, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'sa', 
		@notify_email_operator_name=N'DBAlerts', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Backup Step]    Script Date: 05/14/2013 13:07:50 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Backup Step', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
declare 
  @DatabaseName varchar(25),
  @Location varchar(255),
  @ErrorString varchar(255),
  @Date datetime,
  @String varchar(15),
  @execStr NVarChar(1024),
  @Result int

set @DatabaseName = ''MASTER''
set @Location = ''F:\MSSQL\Backup\''
set @ErrorString = ''Backup for Database ('' + @DatabaseName + '') has failed''
set @Date = GetDate()
set @String = convert(varchar(4), datepart( year, @Date)) + RIGHT(''0'' + convert(varchar(2), datepart( month, @Date)), 2) + RIGHT(''0'' + convert(varchar(2), datepart( day, @Date)), 2) + ''_'' +  RIGHT(''0'' + convert(varchar(2), datepart( hour, @Date)), 2) + RIGHT(''0'' + convert(varchar(2), datepart( minute, @Date)), 2) + RIGHT(''0'' + convert(varchar(2), datepart( second, @Date)), 2)
set @execStr = ''BACKUP DATABASE ['' + @DatabaseName + ''] TO  DISK = N'''''' + @Location + @DatabaseName + ''_'' + @String + ''.bak'''' WITH NOFORMAT, NOINIT, NAME = N'''''' + @DatabaseName + ''-Database Backup Full'''', SKIP, NOREWIND, NOUNLOAD, STATS = 10, DESCRIPTION = N'''''' + @DatabaseName + '' backup'''', MEDIANAME = N'''''' + @DatabaseName + '' backup'''', MEDIADESCRIPTION = N'''''' + @DatabaseName + '' backup''''''
--select @execStr

exec @Result = sp_executesql @execStr
if @@Error <> 0 or @Result <> 0 
  RAISERROR (@ErrorString,16,1);
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Run Backup', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20070927, 
		@active_end_date=99991231, 
		@active_start_time=40015, 
		@active_end_time=235959, 
		@schedule_uid=N'860bc936-b539-4139-84ec-4813d8dc3f13'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [Database Backup Full - MobileServices]    Script Date: 05/14/2013 13:07:50 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 05/14/2013 13:07:50 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Database Backup Full - MobileServices', 
		@enabled=1, 
		@notify_level_eventlog=2, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'sa', 
		@notify_email_operator_name=N'DBAlerts', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Backup Step]    Script Date: 05/14/2013 13:07:50 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Backup Step', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
declare 
  @DatabaseName varchar(25),
  @Location varchar(255),
  @ErrorString varchar(255),
  @Date datetime,
  @String varchar(15),
  @execStr NVarChar(1024),
  @Result int

set @DatabaseName = ''MobileServices''
set @Location = ''F:\MSSQL\Backup\''
set @ErrorString = ''Backup for Database ('' + @DatabaseName + '') has failed''
set @Date = GetDate()
set @String = convert(varchar(4), datepart( year, @Date)) + RIGHT(''0'' + convert(varchar(2), datepart( month, @Date)), 2) + RIGHT(''0'' + convert(varchar(2), datepart( day, @Date)), 2) + ''_'' +  RIGHT(''0'' + convert(varchar(2), datepart( hour, @Date)), 2) + RIGHT(''0'' + convert(varchar(2), datepart( minute, @Date)), 2) + RIGHT(''0'' + convert(varchar(2), datepart( second, @Date)), 2)
set @execStr = ''BACKUP DATABASE ['' + @DatabaseName + ''] TO  DISK = N'''''' + @Location + @DatabaseName + ''_'' + @String + ''.bak'''' WITH NOFORMAT, NOINIT, NAME = N'''''' + @DatabaseName + ''-Database Backup Full'''', SKIP, NOREWIND, NOUNLOAD, STATS = 10, DESCRIPTION = N'''''' + @DatabaseName + '' backup'''', MEDIANAME = N'''''' + @DatabaseName + '' backup'''', MEDIADESCRIPTION = N'''''' + @DatabaseName + '' backup''''''
--select @execStr

exec @Result = sp_executesql @execStr
if @@Error <> 0 or @Result <> 0 
  RAISERROR (@ErrorString,16,1);
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Run Backup', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20070927, 
		@active_end_date=99991231, 
		@active_start_time=41330, 
		@active_end_time=235959, 
		@schedule_uid=N'064bcda6-a607-4331-9500-648dd6d3ae4d'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [Database Backup Full - MODEL]    Script Date: 05/14/2013 13:07:50 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 05/14/2013 13:07:51 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Database Backup Full - MODEL', 
		@enabled=1, 
		@notify_level_eventlog=2, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'sa', 
		@notify_email_operator_name=N'DBAlerts', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Backup Step]    Script Date: 05/14/2013 13:07:51 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Backup Step', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
declare 
  @DatabaseName varchar(25),
  @Location varchar(255),
  @ErrorString varchar(255),
  @Date datetime,
  @String varchar(15),
  @execStr NVarChar(1024),
  @Result int

set @DatabaseName = ''MODEL''
set @Location = ''F:\MSSQL\Backup\''
set @ErrorString = ''Backup for Database ('' + @DatabaseName + '') has failed''
set @Date = GetDate()
set @String = convert(varchar(4), datepart( year, @Date)) + RIGHT(''0'' + convert(varchar(2), datepart( month, @Date)), 2) + RIGHT(''0'' + convert(varchar(2), datepart( day, @Date)), 2) + ''_'' +  RIGHT(''0'' + convert(varchar(2), datepart( hour, @Date)), 2) + RIGHT(''0'' + convert(varchar(2), datepart( minute, @Date)), 2) + RIGHT(''0'' + convert(varchar(2), datepart( second, @Date)), 2)
set @execStr = ''BACKUP DATABASE ['' + @DatabaseName + ''] TO  DISK = N'''''' + @Location + @DatabaseName + ''_'' + @String + ''.bak'''' WITH NOFORMAT, NOINIT, NAME = N'''''' + @DatabaseName + ''-Database Backup Full'''', SKIP, NOREWIND, NOUNLOAD, STATS = 10, DESCRIPTION = N'''''' + @DatabaseName + '' backup'''', MEDIANAME = N'''''' + @DatabaseName + '' backup'''', MEDIADESCRIPTION = N'''''' + @DatabaseName + '' backup''''''
--select @execStr

exec @Result = sp_executesql @execStr
if @@Error <> 0 or @Result <> 0 
  RAISERROR (@ErrorString,16,1);
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Run Backup', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20070927, 
		@active_end_date=99991231, 
		@active_start_time=40030, 
		@active_end_time=235959, 
		@schedule_uid=N'7998a56c-fe7f-4194-ae56-8ba278d91755'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [Database Backup Full - MSDB]    Script Date: 05/14/2013 13:07:51 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 05/14/2013 13:07:51 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Database Backup Full - MSDB', 
		@enabled=1, 
		@notify_level_eventlog=2, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'sa', 
		@notify_email_operator_name=N'DBAlerts', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Backup Step]    Script Date: 05/14/2013 13:07:51 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Backup Step', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
declare 
  @DatabaseName varchar(25),
  @Location varchar(255),
  @ErrorString varchar(255),
  @Date datetime,
  @String varchar(15),
  @execStr NVarChar(1024),
  @Result int

set @DatabaseName = ''MSDB''
set @Location = ''F:\MSSQL\Backup\''
set @ErrorString = ''Backup for Database ('' + @DatabaseName + '') has failed''
set @Date = GetDate()
set @String = convert(varchar(4), datepart( year, @Date)) + RIGHT(''0'' + convert(varchar(2), datepart( month, @Date)), 2) + RIGHT(''0'' + convert(varchar(2), datepart( day, @Date)), 2) + ''_'' +  RIGHT(''0'' + convert(varchar(2), datepart( hour, @Date)), 2) + RIGHT(''0'' + convert(varchar(2), datepart( minute, @Date)), 2) + RIGHT(''0'' + convert(varchar(2), datepart( second, @Date)), 2)
set @execStr = ''BACKUP DATABASE ['' + @DatabaseName + ''] TO  DISK = N'''''' + @Location + @DatabaseName + ''_'' + @String + ''.bak'''' WITH NOFORMAT, NOINIT, NAME = N'''''' + @DatabaseName + ''-Database Backup Full'''', SKIP, NOREWIND, NOUNLOAD, STATS = 10, DESCRIPTION = N'''''' + @DatabaseName + '' backup'''', MEDIANAME = N'''''' + @DatabaseName + '' backup'''', MEDIADESCRIPTION = N'''''' + @DatabaseName + '' backup''''''
--select @execStr

exec @Result = sp_executesql @execStr
if @@Error <> 0 or @Result <> 0 
  RAISERROR (@ErrorString,16,1);
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Run Backup', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20070927, 
		@active_end_date=99991231, 
		@active_start_time=40045, 
		@active_end_time=235959, 
		@schedule_uid=N'94ad852c-97bf-4f6b-90dc-0f2d42898ce7'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [Database Backup Full - Reports]    Script Date: 05/14/2013 13:07:51 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 05/14/2013 13:07:51 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Database Backup Full - Reports', 
		@enabled=1, 
		@notify_level_eventlog=2, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'sa', 
		@notify_email_operator_name=N'DBAlerts', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Backup Step]    Script Date: 05/14/2013 13:07:51 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Backup Step', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
declare 
  @DatabaseName varchar(25),
  @Location varchar(255),
  @ErrorString varchar(255),
  @Date datetime,
  @String varchar(15),
  @execStr NVarChar(1024),
  @Result int

set @DatabaseName = ''Reports''
set @Location = ''F:\MSSQL\Backup\''
set @ErrorString = ''Backup for Database ('' + @DatabaseName + '') has failed''
set @Date = GetDate()
set @String = convert(varchar(4), datepart( year, @Date)) + RIGHT(''0'' + convert(varchar(2), datepart( month, @Date)), 2) + RIGHT(''0'' + convert(varchar(2), datepart( day, @Date)), 2) + ''_'' +  RIGHT(''0'' + convert(varchar(2), datepart( hour, @Date)), 2) + RIGHT(''0'' + convert(varchar(2), datepart( minute, @Date)), 2) + RIGHT(''0'' + convert(varchar(2), datepart( second, @Date)), 2)
set @execStr = ''BACKUP DATABASE ['' + @DatabaseName + ''] TO  DISK = N'''''' + @Location + @DatabaseName + ''_'' + @String + ''.bak'''' WITH NOFORMAT, NOINIT, NAME = N'''''' + @DatabaseName + ''-Database Backup Full'''', SKIP, NOREWIND, NOUNLOAD, STATS = 10, DESCRIPTION = N'''''' + @DatabaseName + '' backup'''', MEDIANAME = N'''''' + @DatabaseName + '' backup'''', MEDIADESCRIPTION = N'''''' + @DatabaseName + '' backup''''''
--select @execStr

exec @Result = sp_executesql @execStr
if @@Error <> 0 or @Result <> 0 
  RAISERROR (@ErrorString,16,1);
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Run Backup', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20070927, 
		@active_end_date=99991231, 
		@active_start_time=41400, 
		@active_end_time=235959, 
		@schedule_uid=N'7b6af57e-683c-42e9-aee2-84eb66e12bc8'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [Database Backup Full - RESEARCH]    Script Date: 05/14/2013 13:07:51 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 05/14/2013 13:07:52 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Database Backup Full - RESEARCH', 
		@enabled=1, 
		@notify_level_eventlog=2, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'sa', 
		@notify_email_operator_name=N'DBAlerts', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Backup Step]    Script Date: 05/14/2013 13:07:52 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Backup Step', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
declare 
  @DatabaseName varchar(25),
  @Location varchar(255),
  @ErrorString varchar(255),
  @Date datetime,
  @String varchar(15),
  @execStr NVarChar(1024),
  @Result int

set @DatabaseName = ''RESEARCH''
set @Location = ''F:\MSSQL\Backup\''
set @ErrorString = ''Backup for Database ('' + @DatabaseName + '') has failed''
set @Date = GetDate()
set @String = convert(varchar(4), datepart( year, @Date)) + RIGHT(''0'' + convert(varchar(2), datepart( month, @Date)), 2) + RIGHT(''0'' + convert(varchar(2), datepart( day, @Date)), 2) + ''_'' +  RIGHT(''0'' + convert(varchar(2), datepart( hour, @Date)), 2) + RIGHT(''0'' + convert(varchar(2), datepart( minute, @Date)), 2) + RIGHT(''0'' + convert(varchar(2), datepart( second, @Date)), 2)
set @execStr = ''BACKUP DATABASE ['' + @DatabaseName + ''] TO  DISK = N'''''' + @Location + @DatabaseName + ''_'' + @String + ''.bak'''' WITH NOFORMAT, NOINIT, NAME = N'''''' + @DatabaseName + ''-Database Backup Full'''', SKIP, NOREWIND, NOUNLOAD, STATS = 10, DESCRIPTION = N'''''' + @DatabaseName + '' backup'''', MEDIANAME = N'''''' + @DatabaseName + '' backup'''', MEDIADESCRIPTION = N'''''' + @DatabaseName + '' backup''''''
--select @execStr

exec @Result = sp_executesql @execStr
if @@Error <> 0 or @Result <> 0 
  RAISERROR (@ErrorString,16,1);
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Run Backup', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20070927, 
		@active_end_date=99991231, 
		@active_start_time=41400, 
		@active_end_time=235959, 
		@schedule_uid=N'7b6af57e-683c-42e9-aee2-84eb66e12bc8'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [Database Backup TLog - All]    Script Date: 05/14/2013 13:07:52 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 05/14/2013 13:07:52 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Database Backup TLog - All', 
		@enabled=1, 
		@notify_level_eventlog=2, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'This job will backup the Transaction Log of any and all databases that are not in Simple mode.  It will deposit these in the \MSSQL\Backup\TLog.', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'sa', 
		@notify_email_operator_name=N'DBAlerts', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Backup Step]    Script Date: 05/14/2013 13:07:52 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Backup Step', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'

declare 
  @Location varchar(255),
  @ErrorString varchar(255),
  @Date datetime,
  @String varchar(15),
  @execStr NVarChar(1024),
  @Result int

set @Location = ''F:\MSSQL\Backup\TLog\''
set @Date = GetDate()
set @String = convert(varchar(4), datepart( year, @Date)) + RIGHT(''0'' + convert(varchar(2), datepart( month, @Date)), 2) + RIGHT(''0'' + convert(varchar(2), datepart( day, @Date)), 2) + ''_'' +  RIGHT(''0'' + convert(varchar(2), datepart( hour, @Date)), 2) + RIGHT(''0'' + convert(varchar(2), datepart( minute, @Date)), 2) + RIGHT(''0'' + convert(varchar(2), datepart( second, @Date)), 2)


declare BackupCursor insensitive cursor
  for
    select NAME 
      FROM sys.sysdatabases
      WHERE name NOT IN (''Master'')

if @@Error <> 0 goto ErrorLabel
--try

  declare
    @DatabaseName sysname,
    @Recovery sql_variant

  open BackupCursor
  if @@Error <> 0 goto ErrorBackupCursor
  while 0 = 0
  begin
    fetch next from BackupCursor into
      @DatabaseName

    if @@Error <> 0 goto ErrorBackupCursor
    if (@@Fetch_Status = 0)
    begin

--      PRINT @DatabaseName
      SET @Recovery = DATABASEPROPERTYEX (@DatabaseName, ''RECOVERY'') 
      
      IF @Recovery <> ''Simple''
      begin

        set @ErrorString = ''TLog Backup for Database ('' + @DatabaseName + '') has failed''

        set @execStr = ''BACKUP LOG  ['' + @DatabaseName + ''] TO  DISK = N'''''' + @Location + @DatabaseName + ''_'' + @String + ''tlog.bak''''''
--        select @execStr

        exec @Result = sp_executesql @execStr
        if @@Error <> 0 or @Result <> 0 
        BEGIN
          RAISERROR (@ErrorString,16,1);

          goto ErrorBackupCursor
        end
      end
    end
    else
      break
  end
  goto SuccessBackupCursor

--except
  ErrorBackupCursor:
  deallocate BackupCursor
  goto ErrorLabel

--finally
  SuccessBackupCursor:
  deallocate BackupCursor
--end

ErrorLabel:

', 
		@database_name=N'MASTER', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Run Backup', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=8, 
		@freq_subday_interval=4, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20070927, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959, 
		@schedule_uid=N'a16f6876-843c-4bbf-87cc-34d5d3029b74'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [Distribution clean up: distribution]    Script Date: 05/14/2013 13:07:52 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [REPL-Distribution Cleanup]    Script Date: 05/14/2013 13:07:52 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'REPL-Distribution Cleanup' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'REPL-Distribution Cleanup'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Distribution clean up: distribution', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'Removes replicated transactions from the distribution database.', 
		@category_name=N'REPL-Distribution Cleanup', 
		@owner_login_name=N'COLLECTION\Administrator', 
		@notify_email_operator_name=N'DBAlerts', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Run agent.]    Script Date: 05/14/2013 13:07:52 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Run agent.', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC dbo.sp_MSdistribution_cleanup @min_distretention = 0, @max_distretention = 72', 
		@server=N'COLLECTION', 
		@database_name=N'distribution', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Replication agent schedule.', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=4, 
		@freq_subday_interval=10, 
		@freq_relative_interval=1, 
		@freq_recurrence_factor=0, 
		@active_start_date=20090827, 
		@active_end_date=99991231, 
		@active_start_time=50500, 
		@active_end_time=165959, 
		@schedule_uid=N'de4f9429-0cb8-4371-9006-0dde320e69d1'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [Expired subscription clean up]    Script Date: 05/14/2013 13:07:53 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [REPL-Subscription Cleanup]    Script Date: 05/14/2013 13:07:53 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'REPL-Subscription Cleanup' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'REPL-Subscription Cleanup'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Expired subscription clean up', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'Detects and removes expired subscriptions from published databases.', 
		@category_name=N'REPL-Subscription Cleanup', 
		@owner_login_name=N'COLLECTION\Administrator', 
		@notify_email_operator_name=N'DBAlerts', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Run agent.]    Script Date: 05/14/2013 13:07:53 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Run agent.', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC sys.sp_expired_subscription_cleanup', 
		@server=N'COLLECTION', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Replication agent schedule.', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=1, 
		@freq_relative_interval=1, 
		@freq_recurrence_factor=0, 
		@active_start_date=20090827, 
		@active_end_date=99991231, 
		@active_start_time=10000, 
		@active_end_time=235959, 
		@schedule_uid=N'ae4599f1-b810-4323-ac02-cd11f0eba197'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [insert data into ILCentralFullRequest]    Script Date: 05/14/2013 13:07:53 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 05/14/2013 13:07:53 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'insert data into ILCentralFullRequest', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [insert data]    Script Date: 05/14/2013 13:07:53 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'insert data', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'insert into ILCentralFullRequest ( SchoolID, TimeRequested) values ( ''04B3C8A6-5566-4A96-A3F1-3F9739D8AEA8'', ''11/01/2012 22:00:00'')
insert into ILCentralFullRequest ( SchoolID, TimeRequested) values ( ''4BB3AAEA-1D5F-40EF-9BDD-945889BB5123'', ''11/01/2012 22:20:00'')
insert into ILCentralFullRequest ( SchoolID, TimeRequested) values ( ''70D766FA-AE54-40EF-B811-0526A0910DAD'', ''11/01/2012 22:40:00'')
insert into ILCentralFullRequest ( SchoolID, TimeRequested) values ( ''417CA415-2A15-45BD-BFAB-068DE7C3A596'', ''11/01/2012 23:00:00'')
insert into ILCentralFullRequest ( SchoolID, TimeRequested) values ( ''9A41E307-AA31-401E-B321-1CF69B822476'', ''11/01/2012 23:20:00'')
insert into ILCentralFullRequest ( SchoolID, TimeRequested) values ( ''21250634-CA82-40FF-B42B-A4A3F5940C04'', ''11/01/2012 23:40:00'')
insert into ILCentralFullRequest ( SchoolID, TimeRequested) values ( ''996EA45C-8135-4564-8907-3952E963245D'', ''11/02/2012 00:00:00'')
insert into ILCentralFullRequest ( SchoolID, TimeRequested) values ( ''770AEFE6-1978-4D74-9D3D-E4722E65C959'', ''11/02/2012 00:20:00'')
insert into ILCentralFullRequest ( SchoolID, TimeRequested) values ( ''6289861B-DCF7-4687-8B80-6A0E7B08F6CB'', ''11/02/2012 00:40:00'')
insert into ILCentralFullRequest ( SchoolID, TimeRequested) values ( ''BAA3245F-F837-401A-91DD-A93501806319'', ''11/02/2012 01:00:00'')
insert into ILCentralFullRequest ( SchoolID, TimeRequested) values ( ''C0B4BEB8-EE85-4D27-9B9D-3A3E27039341'', ''11/02/2012 01:20:00'')
insert into ILCentralFullRequest ( SchoolID, TimeRequested) values ( ''0FAD0184-2594-47B7-95C4-A9D644772EA7'', ''11/02/2012 01:40:00'')
insert into ILCentralFullRequest ( SchoolID, TimeRequested) values ( ''24926C8D-034D-41D4-ACA8-89871A665BC8'', ''11/02/2012 02:00:00'')
insert into ILCentralFullRequest ( SchoolID, TimeRequested) values ( ''A38B31ED-C9E8-4E3D-BF34-6ABEDCB30F2F'', ''11/02/2012 02:20:00'')
insert into ILCentralFullRequest ( SchoolID, TimeRequested) values ( ''6CCED0E6-39C0-4C2C-A453-05707AE5C85C'', ''11/02/2012 02:40:00'')
insert into ILCentralFullRequest ( SchoolID, TimeRequested) values ( ''2F0D52D4-3483-47C3-9E9A-C1716F7EC477'', ''11/02/2012 03:00:00'')
insert into ILCentralFullRequest ( SchoolID, TimeRequested) values ( ''53A5C9F4-2E67-48B4-A042-FA66333ECA4B'', ''11/02/2012 03:20:00'')

insert into ILCentralFullRequest ( SchoolID, TimeRequested) values ( ''7B72F871-A372-4496-B8D0-E205950975C3'', ''11/02/2012 22:00:00'')
insert into ILCentralFullRequest ( SchoolID, TimeRequested) values ( ''89EE8F28-91A6-43FA-8489-F8BE0F44D0DF'', ''11/02/2012 22:20:00'')
insert into ILCentralFullRequest ( SchoolID, TimeRequested) values ( ''A203ECC7-5AE3-448D-B746-E18F5A3A3771'', ''11/02/2012 22:40:00'')
insert into ILCentralFullRequest ( SchoolID, TimeRequested) values ( ''816D476D-E6D3-4BF7-9C82-6FEBFB012D70'', ''11/02/2012 23:00:00'')
insert into ILCentralFullRequest ( SchoolID, TimeRequested) values ( ''B075A4B9-6B1A-445D-93B0-811B67B97F62'', ''11/02/2012 23:20:00'')
insert into ILCentralFullRequest ( SchoolID, TimeRequested) values ( ''25CE7A3D-F58A-426A-8397-416DE424F66B'', ''11/02/2012 23:40:00'')
insert into ILCentralFullRequest ( SchoolID, TimeRequested) values ( ''0332ECCF-D702-4626-ACCB-0F42EFB8AB73'', ''11/03/2012 00:00:00'')
insert into ILCentralFullRequest ( SchoolID, TimeRequested) values ( ''052EC14F-CA3D-48A9-B414-CE30DBC393A6'', ''11/03/2012 00:20:00'')
insert into ILCentralFullRequest ( SchoolID, TimeRequested) values ( ''744E901E-B6B0-412E-A7A7-1806D247A996'', ''11/03/2012 00:40:00'')
insert into ILCentralFullRequest ( SchoolID, TimeRequested) values ( ''18D26C86-4C04-4A64-8275-C2647793E456'', ''11/03/2012 01:00:00'')
insert into ILCentralFullRequest ( SchoolID, TimeRequested) values ( ''530D0620-E082-4BDA-BEE9-72ECF20DC41B'', ''11/03/2012 01:20:00'')
insert into ILCentralFullRequest ( SchoolID, TimeRequested) values ( ''4E32CF4E-53E1-4F7B-8B4A-A911D3D37D67'', ''11/03/2012 01:40:00'')
insert into ILCentralFullRequest ( SchoolID, TimeRequested) values ( ''83C08A6E-8BD0-4210-9593-E3F1D120380B'', ''11/03/2012 02:00:00'')
insert into ILCentralFullRequest ( SchoolID, TimeRequested) values ( ''7C750B6F-D47F-48EA-B671-9B1EF429AAA2'', ''11/03/2012 02:20:00'')
insert into ILCentralFullRequest ( SchoolID, TimeRequested) values ( ''182B9E36-FB0B-4351-8FC0-DEF158D97606'', ''11/03/2012 02:40:00'')
insert into ILCentralFullRequest ( SchoolID, TimeRequested) values ( ''2D99BD5A-1662-4774-9700-AE61E2A915BA'', ''11/03/2012 03:00:00'')
insert into ILCentralFullRequest ( SchoolID, TimeRequested) values ( ''E13C588D-F011-4525-A8A9-C5B08E1F2BE8'', ''11/03/2012 03:20:00'')
insert into ILCentralFullRequest ( SchoolID, TimeRequested) values ( ''D808E4FA-4EEB-4A06-B6E2-48396C7323EF'', ''11/03/2012 03:40:00'')
', 
		@database_name=N'ILCentralData', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'schedule', 
		@enabled=0, 
		@freq_type=1, 
		@freq_interval=0, 
		@freq_subday_type=0, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20121101, 
		@active_end_date=99991231, 
		@active_start_time=190000, 
		@active_end_time=235959, 
		@schedule_uid=N'2abbfc5d-907d-4e8f-9621-8e1dcbe2171d'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [KicksOffReplication]    Script Date: 05/14/2013 13:07:53 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 05/14/2013 13:07:53 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'KicksOffReplication', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=3, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'tjay', 
		@notify_email_operator_name=N'DBInfo', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [step]    Script Date: 05/14/2013 13:07:54 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'step', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
exec msdb.dbo.sp_start_job @job_name = ''COLLECTION-ILCentral-Distribution-REPORT''
exec msdb.dbo.sp_start_job @job_name = ''COLLECTION-ILCentralData-Distribution-REPORT''
exec msdb.dbo.sp_start_job @job_name = ''COLLECTION-ILCentralDataEnt-Distribution-REPORT''', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [Maintenance - DBCC CheckDB]    Script Date: 05/14/2013 13:07:54 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 05/14/2013 13:07:54 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Maintenance - DBCC CheckDB', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'run DBCC CheckDB, output to a file, review file results
just perform this task periodically, and review results as best practice', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'sa', 
		@notify_email_operator_name=N'DBAlerts', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Run DBCC CheckDB]    Script Date: 05/14/2013 13:07:54 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Run DBCC CheckDB', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec master.dbo.spDBCCCheckDB', 
		@database_name=N'master', 
		@output_file_name=N'F:\Files\DBCC_Results.txt', 
		@flags=2
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Mid week execution Schedule', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=8, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20120213, 
		@active_end_date=99991231, 
		@active_start_time=140000, 
		@active_end_time=235959, 
		@schedule_uid=N'a2fe5068-2340-4cc0-8934-db7c3d3ca013'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Schedule', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20110112, 
		@active_end_date=99991231, 
		@active_start_time=140000, 
		@active_end_time=235959, 
		@schedule_uid=N'c9252370-5656-4921-bc35-678d57c09189'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [Maintenance - Defragmentation - ILCentral]    Script Date: 05/14/2013 13:07:54 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 05/14/2013 13:07:54 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Maintenance - Defragmentation - ILCentral', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'Check specific tables for fragmentation. Process those dbs that need Defragmentation', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'sa', 
		@notify_email_operator_name=N'DBAlerts', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Execute sp_IndexDefrag on ILCentral [ActivationCode]]]    Script Date: 05/14/2013 13:07:54 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Execute sp_IndexDefrag on ILCentral [ActivationCode]', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
EXEC master.dbo.sp_IndexDefrag 
    @DatabaseList = ''ILCentral'',
    @TableName = ''ActivationCode'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
', 
		@database_name=N'ILCentral', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Execute sp_IndexDefrag on ILCentral [ActivationCodeTransaction]]]    Script Date: 05/14/2013 13:07:54 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Execute sp_IndexDefrag on ILCentral [ActivationCodeTransaction]', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
EXEC master.dbo.sp_IndexDefrag 
    @DatabaseList = ''ILCentral'',
    @TableName = ''ActivationCodeTransaction'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
', 
		@database_name=N'ILCentral', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Execute sp_IndexDefrag on ILCentral [aspnet_Membership]]]    Script Date: 05/14/2013 13:07:54 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Execute sp_IndexDefrag on ILCentral [aspnet_Membership]', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
EXEC master.dbo.sp_IndexDefrag 
    @DatabaseList = ''ILCentral'',
    @TableName = ''aspnet_Membership'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
', 
		@database_name=N'ILCentral', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Execute sp_IndexDefrag on ILCentral [District]]]    Script Date: 05/14/2013 13:07:54 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Execute sp_IndexDefrag on ILCentral [District]', 
		@step_id=4, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
EXEC master.dbo.sp_IndexDefrag 
    @DatabaseList = ''ILCentral'',
    @TableName = ''District'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
', 
		@database_name=N'ILCentral', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Execute sp_IndexDefrag on ILCentral [ExpressInstallation]]]    Script Date: 05/14/2013 13:07:54 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Execute sp_IndexDefrag on ILCentral [ExpressInstallation]', 
		@step_id=5, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
EXEC master.dbo.sp_IndexDefrag 
    @DatabaseList = ''ILCentral'',
    @TableName = ''ExpressInstallation'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
', 
		@database_name=N'ILCentral', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Execute sp_IndexDefrag on ILCentral [HardwareIDs]]]    Script Date: 05/14/2013 13:07:54 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Execute sp_IndexDefrag on ILCentral [HardwareIDs]', 
		@step_id=6, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
EXEC master.dbo.sp_IndexDefrag 
    @DatabaseList = ''ILCentral'',
    @TableName = ''HardwareIDs'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
', 
		@database_name=N'ILCentral', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Execute sp_IndexDefrag on ILCentral [Installation]]]    Script Date: 05/14/2013 13:07:55 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Execute sp_IndexDefrag on ILCentral [Installation]', 
		@step_id=7, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
EXEC master.dbo.sp_IndexDefrag 
    @DatabaseList = ''ILCentral'',
    @TableName = ''Installation'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
', 
		@database_name=N'ILCentral', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Execute sp_IndexDefrag on ILCentral [RegistrationStatus]]]    Script Date: 05/14/2013 13:07:55 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Execute sp_IndexDefrag on ILCentral [RegistrationStatus]', 
		@step_id=8, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
EXEC master.dbo.sp_IndexDefrag 
    @DatabaseList = ''ILCentral'',
    @TableName = ''RegistrationStatus'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
', 
		@database_name=N'ILCentral', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Execute sp_IndexDefrag on ILCentral [aspnet_Profile]]]    Script Date: 05/14/2013 13:07:55 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Execute sp_IndexDefrag on ILCentral [aspnet_Profile]', 
		@step_id=9, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
EXEC master.dbo.sp_IndexDefrag 
    @DatabaseList = ''ILCentral'',
    @TableName = ''aspnet_Profile'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
', 
		@database_name=N'ILCentral', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Execute sp_IndexDefrag on ILCentral [ProductUpdate]]]    Script Date: 05/14/2013 13:07:55 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Execute sp_IndexDefrag on ILCentral [ProductUpdate]', 
		@step_id=10, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
EXEC master.dbo.sp_IndexDefrag 
    @DatabaseList = ''ILCentral'',
    @TableName = ''ProductUpdate'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
', 
		@database_name=N'ILCentral', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Execute sp_IndexDefrag on ILCentral [InstallationHistory]]]    Script Date: 05/14/2013 13:07:55 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Execute sp_IndexDefrag on ILCentral [InstallationHistory]', 
		@step_id=11, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
EXEC master.dbo.sp_IndexDefrag 
    @DatabaseList = ''ILCentral'',
    @TableName = ''InstallationHistory'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
', 
		@database_name=N'ILCentral', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Execute sp_IndexDefrag on ILCentral [Group]]]    Script Date: 05/14/2013 13:07:55 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Execute sp_IndexDefrag on ILCentral [Group]', 
		@step_id=12, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
EXEC master.dbo.sp_IndexDefrag 
    @DatabaseList = ''ILCentral'',
    @TableName = ''Group'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
', 
		@database_name=N'ILCentral', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'schedule', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20110610, 
		@active_end_date=99991231, 
		@active_start_time=180000, 
		@active_end_time=235959, 
		@schedule_uid=N'91f40a28-3541-4db4-ac9d-5c3841753e35'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [Maintenance - Defragmentation - ILCentralData]    Script Date: 05/14/2013 13:07:55 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 05/14/2013 13:07:55 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Maintenance - Defragmentation - ILCentralData', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'Check specific tables for fragmentation. Process those dbs that need Defragmentation', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'sa', 
		@notify_email_operator_name=N'DBAlerts', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Execute sp_IndexDefrag on ILCentralData [AdaptiveTestInstance]]]    Script Date: 05/14/2013 13:07:55 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Execute sp_IndexDefrag on ILCentralData [AdaptiveTestInstance]', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
EXEC master.dbo.sp_IndexDefrag 
    @DatabaseList = ''ILCentralData'',
    @TableName = ''AdaptiveTestInstance'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
', 
		@database_name=N'ILCentralData', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Execute sp_IndexDefrag on ILCentralData [AdaptiveTestStrandInstance]]]    Script Date: 05/14/2013 13:07:55 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Execute sp_IndexDefrag on ILCentralData [AdaptiveTestStrandInstance]', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
EXEC master.dbo.sp_IndexDefrag 
    @DatabaseList = ''ILCentralData'',
    @TableName = ''AdaptiveTestStrandInstance'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
', 
		@database_name=N'ILCentralData', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Execute sp_IndexDefrag on ILCentralData [Classroom]]]    Script Date: 05/14/2013 13:07:55 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Execute sp_IndexDefrag on ILCentralData [Classroom]', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
EXEC master.dbo.sp_IndexDefrag 
    @DatabaseList = ''ILCentralData'',
    @TableName = ''Classroom'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
', 
		@database_name=N'ILCentralData', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Execute sp_IndexDefrag on ILCentralData [ClassroomUser]]]    Script Date: 05/14/2013 13:07:55 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Execute sp_IndexDefrag on ILCentralData [ClassroomUser]', 
		@step_id=4, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
EXEC master.dbo.sp_IndexDefrag 
    @DatabaseList = ''ILCentralData'',
    @TableName = ''ClassroomUser'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
', 
		@database_name=N'ILCentralData', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Execute sp_IndexDefrag on ILCentralData [CSVVersion]]]    Script Date: 05/14/2013 13:07:56 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Execute sp_IndexDefrag on ILCentralData [CSVVersion]', 
		@step_id=5, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
EXEC master.dbo.sp_IndexDefrag 
    @DatabaseList = ''ILCentralData'',
    @TableName = ''CSVVersion'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
', 
		@database_name=N'ILCentralData', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Execute sp_IndexDefrag on ILCentralData [DBVersion]]]    Script Date: 05/14/2013 13:07:56 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Execute sp_IndexDefrag on ILCentralData [DBVersion]', 
		@step_id=6, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
EXEC master.dbo.sp_IndexDefrag 
    @DatabaseList = ''ILCentralData'',
    @TableName = ''DBVersion'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
', 
		@database_name=N'ILCentralData', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Execute sp_IndexDefrag on ILCentralData [Group]]]    Script Date: 05/14/2013 13:07:56 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Execute sp_IndexDefrag on ILCentralData [Group]', 
		@step_id=7, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
EXEC master.dbo.sp_IndexDefrag 
    @DatabaseList = ''ILCentralData'',
    @TableName = ''Group'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
', 
		@database_name=N'ILCentralData', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Execute sp_IndexDefrag on ILCentralData [ILCentralDataDump]]]    Script Date: 05/14/2013 13:07:56 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Execute sp_IndexDefrag on ILCentralData [ILCentralDataDump]', 
		@step_id=8, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
EXEC master.dbo.sp_IndexDefrag 
    @DatabaseList = ''ILCentralData'',
    @TableName = ''ILCentralDataDump'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
', 
		@database_name=N'ILCentralData', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Execute sp_IndexDefrag on ILCentralData [ILCentralFullRequest]]]    Script Date: 05/14/2013 13:07:56 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Execute sp_IndexDefrag on ILCentralData [ILCentralFullRequest]', 
		@step_id=9, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
EXEC master.dbo.sp_IndexDefrag 
    @DatabaseList = ''ILCentralData'',
    @TableName = ''ILCentralFullRequest'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
', 
		@database_name=N'ILCentralData', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Execute sp_IndexDefrag on ILCentralData [School]]]    Script Date: 05/14/2013 13:07:56 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Execute sp_IndexDefrag on ILCentralData [School]', 
		@step_id=10, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
EXEC master.dbo.sp_IndexDefrag 
    @DatabaseList = ''ILCentralData'',
    @TableName = ''School'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
', 
		@database_name=N'ILCentralData', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Execute sp_IndexDefrag on ILCentralData [Station]]]    Script Date: 05/14/2013 13:07:56 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Execute sp_IndexDefrag on ILCentralData [Station]', 
		@step_id=11, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
EXEC master.dbo.sp_IndexDefrag 
    @DatabaseList = ''ILCentralData'',
    @TableName = ''Station'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
', 
		@database_name=N'ILCentralData', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Execute sp_IndexDefrag on ILCentralData [StrandBookmark]]]    Script Date: 05/14/2013 13:07:56 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Execute sp_IndexDefrag on ILCentralData [StrandBookmark]', 
		@step_id=12, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
EXEC master.dbo.sp_IndexDefrag 
    @DatabaseList = ''ILCentralData'',
    @TableName = ''StrandBookmark'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
', 
		@database_name=N'ILCentralData', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Execute sp_IndexDefrag on ILCentralData [StrandProgress]]]    Script Date: 05/14/2013 13:07:56 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Execute sp_IndexDefrag on ILCentralData [StrandProgress]', 
		@step_id=13, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
EXEC master.dbo.sp_IndexDefrag 
    @DatabaseList = ''ILCentralData'',
    @TableName = ''StrandProgress'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
', 
		@database_name=N'ILCentralData', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Execute sp_IndexDefrag on ILCentralData [Student]]]    Script Date: 05/14/2013 13:07:56 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Execute sp_IndexDefrag on ILCentralData [Student]', 
		@step_id=14, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
EXEC master.dbo.sp_IndexDefrag 
    @DatabaseList = ''ILCentralData'',
    @TableName = ''Student'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
', 
		@database_name=N'ILCentralData', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Execute sp_IndexDefrag on ILCentralData [StudentClassroomSettings]]]    Script Date: 05/14/2013 13:07:56 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Execute sp_IndexDefrag on ILCentralData [StudentClassroomSettings]', 
		@step_id=15, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
EXEC master.dbo.sp_IndexDefrag 
    @DatabaseList = ''ILCentralData'',
    @TableName = ''StudentClassroomSettings'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
', 
		@database_name=N'ILCentralData', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Execute sp_IndexDefrag on ILCentralData [StudentGroupProductSettings]]]    Script Date: 05/14/2013 13:07:56 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Execute sp_IndexDefrag on ILCentralData [StudentGroupProductSettings]', 
		@step_id=16, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
EXEC master.dbo.sp_IndexDefrag 
    @DatabaseList = ''ILCentralData'',
    @TableName = ''StudentGroupProductSettings'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
', 
		@database_name=N'ILCentralData', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Execute sp_IndexDefrag on ILCentralData [StudentStudents_GroupGroups]]]    Script Date: 05/14/2013 13:07:56 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Execute sp_IndexDefrag on ILCentralData [StudentStudents_GroupGroups]', 
		@step_id=17, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
EXEC master.dbo.sp_IndexDefrag 
    @DatabaseList = ''ILCentralData'',
    @TableName = ''StudentStudents_GroupGroups'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
', 
		@database_name=N'ILCentralData', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Execute sp_IndexDefrag on ILCentralData [User]]]    Script Date: 05/14/2013 13:07:56 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Execute sp_IndexDefrag on ILCentralData [User]', 
		@step_id=18, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
EXEC master.dbo.sp_IndexDefrag 
    @DatabaseList = ''ILCentralData'',
    @TableName = ''User'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
', 
		@database_name=N'ILCentralData', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Execute sp_IndexDefrag on ILCentralData [UserProductSettings]]]    Script Date: 05/14/2013 13:07:56 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Execute sp_IndexDefrag on ILCentralData [UserProductSettings]', 
		@step_id=19, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
EXEC master.dbo.sp_IndexDefrag 
    @DatabaseList = ''ILCentralData'',
    @TableName = ''UserProductSettings'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
', 
		@database_name=N'ILCentralData', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Execute sp_IndexDefrag on ILCentralData [ActivitySavedData]]]    Script Date: 05/14/2013 13:07:56 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Execute sp_IndexDefrag on ILCentralData [ActivitySavedData]', 
		@step_id=20, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
EXEC master.dbo.sp_IndexDefrag 
    @DatabaseList = ''ILCentralData'',
    @TableName = ''ActivitySavedData'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
', 
		@database_name=N'ILCentralData', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Execute sp_IndexDefrag on ILCentralData [SessionHistory]]]    Script Date: 05/14/2013 13:07:56 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Execute sp_IndexDefrag on ILCentralData [SessionHistory]', 
		@step_id=21, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
EXEC master.dbo.sp_IndexDefrag 
    @DatabaseList = ''ILCentralData'',
    @TableName = ''SessionHistory'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
', 
		@database_name=N'ILCentralData', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Execute sp_IndexDefrag on ILCentralData [AudioRecording]]]    Script Date: 05/14/2013 13:07:56 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Execute sp_IndexDefrag on ILCentralData [AudioRecording]', 
		@step_id=22, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
EXEC master.dbo.sp_IndexDefrag 
    @DatabaseList = ''ILCentralData'',
    @TableName = ''AudioRecording'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
', 
		@database_name=N'ILCentralData', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Execute sp_IndexDefrag on ILCentralData [AdaptiveTestQuestionInstance]]]    Script Date: 05/14/2013 13:07:56 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Execute sp_IndexDefrag on ILCentralData [AdaptiveTestQuestionInstance]', 
		@step_id=23, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
EXEC master.dbo.sp_IndexDefrag 
    @DatabaseList = ''ILCentralData'',
    @TableName = ''AdaptiveTestQuestionInstance'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
', 
		@database_name=N'ILCentralData', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Execute sp_IndexDefrag on ILCentralData [StudentLessonStateHistory]]]    Script Date: 05/14/2013 13:07:56 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Execute sp_IndexDefrag on ILCentralData [StudentLessonStateHistory]', 
		@step_id=24, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
EXEC master.dbo.sp_IndexDefrag 
    @DatabaseList = ''ILCentralData'',
    @TableName = ''StudentLessonStateHistory'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
', 
		@database_name=N'ILCentralData', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Execute sp_IndexDefrag on ILCentralData [StudentLessonState]]]    Script Date: 05/14/2013 13:07:56 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Execute sp_IndexDefrag on ILCentralData [StudentLessonState]', 
		@step_id=25, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
EXEC master.dbo.sp_IndexDefrag 
    @DatabaseList = ''ILCentralData'',
    @TableName = ''StudentLessonState'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
', 
		@database_name=N'ILCentralData', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Execute sp_IndexDefrag on ILCentralData [Score]]]    Script Date: 05/14/2013 13:07:56 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Execute sp_IndexDefrag on ILCentralData [Score]', 
		@step_id=26, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
EXEC master.dbo.sp_IndexDefrag 
    @DatabaseList = ''ILCentralData'',
    @TableName = ''Score'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
', 
		@database_name=N'ILCentralData', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'schedule', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=53, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20110610, 
		@active_end_date=99991231, 
		@active_start_time=181500, 
		@active_end_time=235959, 
		@schedule_uid=N'da9f4aa5-ff43-4b4a-aea8-7a9cba2bf821'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [Maintenance - Defragmentation - ILCentralData - Large Indexes]    Script Date: 05/14/2013 13:07:56 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 05/14/2013 13:07:56 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Maintenance - Defragmentation - ILCentralData - Large Indexes', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'Check specific tables for fragmentation. Process those dbs that need Defragmentation', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'sa', 
		@notify_email_operator_name=N'DBAlerts', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Execute sp_IndexDefrag on ILCentralData [ActivitySavedData]]]    Script Date: 05/14/2013 13:07:56 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Execute sp_IndexDefrag on ILCentralData [ActivitySavedData]', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
EXEC master.dbo.sp_IndexDefrag 
    @DatabaseList = ''ILCentralData'',
    @TableName = ''ActivitySavedData'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
', 
		@database_name=N'ILCentralData', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Execute sp_IndexDefrag on ILCentralData [SessionHistory]]]    Script Date: 05/14/2013 13:07:56 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Execute sp_IndexDefrag on ILCentralData [SessionHistory]', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
EXEC master.dbo.sp_IndexDefrag 
    @DatabaseList = ''ILCentralData'',
    @TableName = ''SessionHistory'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
', 
		@database_name=N'ILCentralData', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Execute sp_IndexDefrag on ILCentralData [AudioRecording]]]    Script Date: 05/14/2013 13:07:57 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Execute sp_IndexDefrag on ILCentralData [AudioRecording]', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
EXEC master.dbo.sp_IndexDefrag 
    @DatabaseList = ''ILCentralData'',
    @TableName = ''AudioRecording'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
', 
		@database_name=N'ILCentralData', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Execute sp_IndexDefrag on ILCentralData [AdaptiveTestQuestionInstance]]]    Script Date: 05/14/2013 13:07:57 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Execute sp_IndexDefrag on ILCentralData [AdaptiveTestQuestionInstance]', 
		@step_id=4, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
EXEC master.dbo.sp_IndexDefrag 
    @DatabaseList = ''ILCentralData'',
    @TableName = ''AdaptiveTestQuestionInstance'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
', 
		@database_name=N'ILCentralData', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Execute sp_IndexDefrag on ILCentralData [StudentLessonStateHistory]]]    Script Date: 05/14/2013 13:07:57 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Execute sp_IndexDefrag on ILCentralData [StudentLessonStateHistory]', 
		@step_id=5, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
EXEC master.dbo.sp_IndexDefrag 
    @DatabaseList = ''ILCentralData'',
    @TableName = ''StudentLessonStateHistory'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
', 
		@database_name=N'ILCentralData', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Execute sp_IndexDefrag on ILCentralData [StudentLessonState]]]    Script Date: 05/14/2013 13:07:57 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Execute sp_IndexDefrag on ILCentralData [StudentLessonState]', 
		@step_id=6, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
EXEC master.dbo.sp_IndexDefrag 
    @DatabaseList = ''ILCentralData'',
    @TableName = ''StudentLessonState'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
', 
		@database_name=N'ILCentralData', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Execute sp_IndexDefrag on ILCentralData [Score]]]    Script Date: 05/14/2013 13:07:57 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Execute sp_IndexDefrag on ILCentralData [Score]', 
		@step_id=7, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
EXEC master.dbo.sp_IndexDefrag 
    @DatabaseList = ''ILCentralData'',
    @TableName = ''Score'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
', 
		@database_name=N'ILCentralData', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'schedule', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20110610, 
		@active_end_date=99991231, 
		@active_start_time=73000, 
		@active_end_time=235959, 
		@schedule_uid=N'36c10fa8-a29d-49f0-b66b-946120f5daad'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [Maintenance - Defragmentation - ILCentralDataEnt]    Script Date: 05/14/2013 13:07:57 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 05/14/2013 13:07:57 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Maintenance - Defragmentation - ILCentralDataEnt', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'Check specific tables for fragmentation. Process those dbs that need Defragmentation', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'sa', 
		@notify_email_operator_name=N'DBAlerts', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Execute sp_IndexDefrag on ILCentralDataEnt [ActivitySavedData]]]    Script Date: 05/14/2013 13:07:57 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Execute sp_IndexDefrag on ILCentralDataEnt [ActivitySavedData]', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
EXEC master.dbo.sp_IndexDefrag 
    @DatabaseList = ''ILCentralDataEnt'',
    @TableName = ''ActivitySavedData'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
', 
		@database_name=N'ILCentralDataEnt', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Execute sp_IndexDefrag on ILCentralDataEnt [AdaptiveTestInstance]]]    Script Date: 05/14/2013 13:07:57 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Execute sp_IndexDefrag on ILCentralDataEnt [AdaptiveTestInstance]', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
EXEC master.dbo.sp_IndexDefrag 
    @DatabaseList = ''ILCentralDataEnt'',
    @TableName = ''AdaptiveTestInstance'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
', 
		@database_name=N'ILCentralDataEnt', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Execute sp_IndexDefrag on ILCentralDataEnt [AdaptiveTestStrandInstance]]]    Script Date: 05/14/2013 13:07:57 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Execute sp_IndexDefrag on ILCentralDataEnt [AdaptiveTestStrandInstance]', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
EXEC master.dbo.sp_IndexDefrag 
    @DatabaseList = ''ILCentralDataEnt'',
    @TableName = ''AdaptiveTestStrandInstance'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
', 
		@database_name=N'ILCentralDataEnt', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Execute sp_IndexDefrag on ILCentralDataEnt [CacheVersion]]]    Script Date: 05/14/2013 13:07:57 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Execute sp_IndexDefrag on ILCentralDataEnt [CacheVersion]', 
		@step_id=4, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
EXEC master.dbo.sp_IndexDefrag 
    @DatabaseList = ''ILCentralDataEnt'',
    @TableName = ''CacheVersion'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
', 
		@database_name=N'ILCentralDataEnt', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Execute sp_IndexDefrag on ILCentralDataEnt [ComputerInfo]]]    Script Date: 05/14/2013 13:07:57 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Execute sp_IndexDefrag on ILCentralDataEnt [ComputerInfo]', 
		@step_id=5, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
EXEC master.dbo.sp_IndexDefrag 
    @DatabaseList = ''ILCentralDataEnt'',
    @TableName = ''ComputerInfo'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
', 
		@database_name=N'ILCentralDataEnt', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Execute sp_IndexDefrag on ILCentralDataEnt [DBInfo]]]    Script Date: 05/14/2013 13:07:57 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Execute sp_IndexDefrag on ILCentralDataEnt [DBInfo]', 
		@step_id=6, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
EXEC master.dbo.sp_IndexDefrag 
    @DatabaseList = ''ILCentralDataEnt'',
    @TableName = ''DBInfo'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
', 
		@database_name=N'ILCentralDataEnt', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Execute sp_IndexDefrag on ILCentralDataEnt [Group]]]    Script Date: 05/14/2013 13:07:57 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Execute sp_IndexDefrag on ILCentralDataEnt [Group]', 
		@step_id=7, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
EXEC master.dbo.sp_IndexDefrag 
    @DatabaseList = ''ILCentralDataEnt'',
    @TableName = ''Group'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
', 
		@database_name=N'ILCentralDataEnt', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Execute sp_IndexDefrag on ILCentralDataEnt [Institution]]]    Script Date: 05/14/2013 13:07:57 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Execute sp_IndexDefrag on ILCentralDataEnt [Institution]', 
		@step_id=8, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
EXEC master.dbo.sp_IndexDefrag 
    @DatabaseList = ''ILCentralDataEnt'',
    @TableName = ''Institution'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
', 
		@database_name=N'ILCentralDataEnt', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Execute sp_IndexDefrag on ILCentralDataEnt [SessionHistory]]]    Script Date: 05/14/2013 13:07:57 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Execute sp_IndexDefrag on ILCentralDataEnt [SessionHistory]', 
		@step_id=9, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
EXEC master.dbo.sp_IndexDefrag 
    @DatabaseList = ''ILCentralDataEnt'',
    @TableName = ''SessionHistory'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
', 
		@database_name=N'ILCentralDataEnt', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Execute sp_IndexDefrag on ILCentralDataEnt [StrandProgress]]]    Script Date: 05/14/2013 13:07:57 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Execute sp_IndexDefrag on ILCentralDataEnt [StrandProgress]', 
		@step_id=10, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
EXEC master.dbo.sp_IndexDefrag 
    @DatabaseList = ''ILCentralDataEnt'',
    @TableName = ''StrandProgress'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
', 
		@database_name=N'ILCentralDataEnt', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Execute sp_IndexDefrag on ILCentralDataEnt [Student]]]    Script Date: 05/14/2013 13:07:57 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Execute sp_IndexDefrag on ILCentralDataEnt [Student]', 
		@step_id=11, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
EXEC master.dbo.sp_IndexDefrag 
    @DatabaseList = ''ILCentralDataEnt'',
    @TableName = ''Student'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
', 
		@database_name=N'ILCentralDataEnt', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Execute sp_IndexDefrag on ILCentralDataEnt [StudentGroup]]]    Script Date: 05/14/2013 13:07:57 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Execute sp_IndexDefrag on ILCentralDataEnt [StudentGroup]', 
		@step_id=12, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
EXEC master.dbo.sp_IndexDefrag 
    @DatabaseList = ''ILCentralDataEnt'',
    @TableName = ''StudentGroup'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
', 
		@database_name=N'ILCentralDataEnt', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Execute sp_IndexDefrag on ILCentralDataEnt [SyncHistory]]]    Script Date: 05/14/2013 13:07:57 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Execute sp_IndexDefrag on ILCentralDataEnt [SyncHistory]', 
		@step_id=13, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
EXEC master.dbo.sp_IndexDefrag 
    @DatabaseList = ''ILCentralDataEnt'',
    @TableName = ''SyncHistory'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
', 
		@database_name=N'ILCentralDataEnt', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Execute sp_IndexDefrag on ILCentralDataEnt [UnassignedStudent]]]    Script Date: 05/14/2013 13:07:57 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Execute sp_IndexDefrag on ILCentralDataEnt [UnassignedStudent]', 
		@step_id=14, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
EXEC master.dbo.sp_IndexDefrag 
    @DatabaseList = ''ILCentralDataEnt'',
    @TableName = ''UnassignedStudent'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
', 
		@database_name=N'ILCentralDataEnt', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Execute sp_IndexDefrag on ILCentralDataEnt [User]]]    Script Date: 05/14/2013 13:07:57 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Execute sp_IndexDefrag on ILCentralDataEnt [User]', 
		@step_id=15, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
EXEC master.dbo.sp_IndexDefrag 
    @DatabaseList = ''ILCentralDataEnt'',
    @TableName = ''User'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
', 
		@database_name=N'ILCentralDataEnt', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Execute sp_IndexDefrag on ILCentralDataEnt [Photo]]]    Script Date: 05/14/2013 13:07:58 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Execute sp_IndexDefrag on ILCentralDataEnt [Photo]', 
		@step_id=16, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
EXEC master.dbo.sp_IndexDefrag 
    @DatabaseList = ''ILCentralDataEnt'',
    @TableName = ''Photo'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
', 
		@database_name=N'ILCentralDataEnt', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Execute sp_IndexDefrag on ILCentralDataEnt [AudioRecording]]]    Script Date: 05/14/2013 13:07:58 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Execute sp_IndexDefrag on ILCentralDataEnt [AudioRecording]', 
		@step_id=17, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
EXEC master.dbo.sp_IndexDefrag 
    @DatabaseList = ''ILCentralDataEnt'',
    @TableName = ''AudioRecording'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
', 
		@database_name=N'ILCentralDataEnt', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Execute sp_IndexDefrag on ILCentralDataEnt [ActivityCounted]]]    Script Date: 05/14/2013 13:07:58 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Execute sp_IndexDefrag on ILCentralDataEnt [ActivityCounted]', 
		@step_id=18, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
EXEC master.dbo.sp_IndexDefrag 
    @DatabaseList = ''ILCentralDataEnt'',
    @TableName = ''ActivityCounted'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
', 
		@database_name=N'ILCentralDataEnt', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Execute sp_IndexDefrag on ILCentralDataEnt [AdaptiveTestQuestionInstance]]]    Script Date: 05/14/2013 13:07:58 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Execute sp_IndexDefrag on ILCentralDataEnt [AdaptiveTestQuestionInstance]', 
		@step_id=19, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
EXEC master.dbo.sp_IndexDefrag 
    @DatabaseList = ''ILCentralDataEnt'',
    @TableName = ''AdaptiveTestQuestionInstance'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
', 
		@database_name=N'ILCentralDataEnt', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Execute sp_IndexDefrag on ILCentralDataEnt [StudentLessonStateHistory]]]    Script Date: 05/14/2013 13:07:58 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Execute sp_IndexDefrag on ILCentralDataEnt [StudentLessonStateHistory]', 
		@step_id=20, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
EXEC master.dbo.sp_IndexDefrag 
    @DatabaseList = ''ILCentralDataEnt'',
    @TableName = ''StudentLessonStateHistory'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
', 
		@database_name=N'ILCentralDataEnt', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Execute sp_IndexDefrag on ILCentralDataEnt [Score]]]    Script Date: 05/14/2013 13:07:58 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Execute sp_IndexDefrag on ILCentralDataEnt [Score]', 
		@step_id=21, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
EXEC master.dbo.sp_IndexDefrag 
    @DatabaseList = ''ILCentralDataEnt'',
    @TableName = ''Score'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
', 
		@database_name=N'ILCentralDataEnt', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Execute sp_IndexDefrag on ILCentralDataEnt [StudentLessonState]]]    Script Date: 05/14/2013 13:07:58 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Execute sp_IndexDefrag on ILCentralDataEnt [StudentLessonState]', 
		@step_id=22, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
EXEC master.dbo.sp_IndexDefrag 
    @DatabaseList = ''ILCentralDataEnt'',
    @TableName = ''StudentLessonState'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
', 
		@database_name=N'ILCentralDataEnt', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'schedule', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=53, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20110610, 
		@active_end_date=99991231, 
		@active_start_time=183000, 
		@active_end_time=235959, 
		@schedule_uid=N'dc67254b-2ebd-4dc9-8f9e-e207d18c126c'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [Maintenance - Defragmentation - ILCentralDataEnt - Large Indexes]    Script Date: 05/14/2013 13:07:58 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 05/14/2013 13:07:58 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Maintenance - Defragmentation - ILCentralDataEnt - Large Indexes', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'Check specific tables for fragmentation. Process those dbs that need Defragmentation', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'sa', 
		@notify_email_operator_name=N'DBAlerts', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Execute sp_IndexDefrag on ILCentralDataEnt [Photo]]]    Script Date: 05/14/2013 13:07:58 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Execute sp_IndexDefrag on ILCentralDataEnt [Photo]', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
EXEC master.dbo.sp_IndexDefrag 
    @DatabaseList = ''ILCentralDataEnt'',
    @TableName = ''Photo'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
', 
		@database_name=N'ILCentralDataEnt', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Execute sp_IndexDefrag on ILCentralDataEnt [AudioRecording]]]    Script Date: 05/14/2013 13:07:58 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Execute sp_IndexDefrag on ILCentralDataEnt [AudioRecording]', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
EXEC master.dbo.sp_IndexDefrag 
    @DatabaseList = ''ILCentralDataEnt'',
    @TableName = ''AudioRecording'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
', 
		@database_name=N'ILCentralDataEnt', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Execute sp_IndexDefrag on ILCentralDataEnt [ActivityCounted]]]    Script Date: 05/14/2013 13:07:58 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Execute sp_IndexDefrag on ILCentralDataEnt [ActivityCounted]', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
EXEC master.dbo.sp_IndexDefrag 
    @DatabaseList = ''ILCentralDataEnt'',
    @TableName = ''ActivityCounted'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
', 
		@database_name=N'ILCentralDataEnt', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Execute sp_IndexDefrag on ILCentralDataEnt [AdaptiveTestQuestionInstance]]]    Script Date: 05/14/2013 13:07:58 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Execute sp_IndexDefrag on ILCentralDataEnt [AdaptiveTestQuestionInstance]', 
		@step_id=4, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
EXEC master.dbo.sp_IndexDefrag 
    @DatabaseList = ''ILCentralDataEnt'',
    @TableName = ''AdaptiveTestQuestionInstance'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
', 
		@database_name=N'ILCentralDataEnt', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Execute sp_IndexDefrag on ILCentralDataEnt [StudentLessonStateHistory]]]    Script Date: 05/14/2013 13:07:58 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Execute sp_IndexDefrag on ILCentralDataEnt [StudentLessonStateHistory]', 
		@step_id=5, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
EXEC master.dbo.sp_IndexDefrag 
    @DatabaseList = ''ILCentralDataEnt'',
    @TableName = ''StudentLessonStateHistory'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
', 
		@database_name=N'ILCentralDataEnt', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Execute sp_IndexDefrag on ILCentralDataEnt [Score]]]    Script Date: 05/14/2013 13:07:58 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Execute sp_IndexDefrag on ILCentralDataEnt [Score]', 
		@step_id=6, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
EXEC master.dbo.sp_IndexDefrag 
    @DatabaseList = ''ILCentralDataEnt'',
    @TableName = ''Score'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
', 
		@database_name=N'ILCentralDataEnt', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Execute sp_IndexDefrag on ILCentralDataEnt [StudentLessonState]]]    Script Date: 05/14/2013 13:07:58 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Execute sp_IndexDefrag on ILCentralDataEnt [StudentLessonState]', 
		@step_id=7, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
EXEC master.dbo.sp_IndexDefrag 
    @DatabaseList = ''ILCentralDataEnt'',
    @TableName = ''StudentLessonState'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
', 
		@database_name=N'ILCentralDataEnt', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'schedule', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20110610, 
		@active_end_date=99991231, 
		@active_start_time=71000, 
		@active_end_time=235959, 
		@schedule_uid=N'e1b5424b-62c8-4bbc-8223-3d86df19b528'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [Maintenance - Defragmentation - ILCentralDataEnt - MSSync Indexes]    Script Date: 05/14/2013 13:07:58 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 05/14/2013 13:07:58 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Maintenance - Defragmentation - ILCentralDataEnt - MSSync Indexes', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'Check specific tables for fragmentation. Process those dbs that need Defragmentation', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'sa', 
		@notify_email_operator_name=N'DBAlerts', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Execute sp_IndexDefrag on ILCentralDataEnt [AdaptiveTestInstance]]]    Script Date: 05/14/2013 13:07:59 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Execute sp_IndexDefrag on ILCentralDataEnt [AdaptiveTestInstance]', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'

EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v116_ActivityCounted_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v116_ActivitySavedData_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v116_AdaptiveTestInstance_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v116_AdaptiveTestQuestionInstance_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v116_AdaptiveTestStrandInstance_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v116_AudioRecording_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v116_CacheVersion_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v116_ComputerInfo_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v116_DBInfo_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v116_Group_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v116_Institution_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v116_Photo_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v116_schema_info'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v116_scope_config'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v116_scope_info'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v116_scope_parameters'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v116_scope_templates'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v116_Score_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v116_SessionHistory_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v116_StrandProgress_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v116_Student_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v116_StudentGroup_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v116_StudentLessonState_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v116_StudentLessonStateHistory_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v116_SyncHistory_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v116_UnassignedStudent_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v116_User_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v117_ActivityCounted_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v117_ActivitySavedData_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v117_AdaptiveTestInstance_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v117_AdaptiveTestQuestionInstance_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v117_AdaptiveTestStrandInstance_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v117_AudioRecording_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v117_CacheVersion_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v117_ComputerInfo_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v117_DBInfo_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v117_Group_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v117_Institution_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v117_Photo_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v117_schema_info'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v117_scope_config'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v117_scope_info'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v117_scope_parameters'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v117_scope_templates'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v117_Score_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v117_SessionHistory_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v117_StrandProgress_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v117_Student_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v117_StudentGroup_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v117_StudentLessonState_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v117_StudentLessonStateHistory_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v117_SyncHistory_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v117_UnassignedStudent_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v117_User_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v124_ActivityCounted_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v124_ActivitySavedData_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v124_AdaptiveTestInstance_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v124_AdaptiveTestQuestionInstance_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v124_AdaptiveTestStrandInstance_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v124_AudioRecording_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v124_CacheVersion_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v124_ComputerInfo_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v124_DBInfo_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v124_Group_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v124_Institution_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v124_InstitutionMediaServer_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v124_QuestionResponse_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v124_schema_info'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v124_scope_config'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v124_scope_info'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v124_scope_parameters'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v124_scope_templates'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v124_Score_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v124_SessionHistory_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v124_StrandProgress_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v124_Student_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v124_StudentGroup_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v124_StudentLessonState_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v124_StudentLessonStateHistory_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v124_SyncHistory_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v124_UnassignedStudent_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v124_User_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v124f1_schema_info'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v124f1_scope_config'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v124f1_scope_info'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v124f1_scope_parameters'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v124f1_scope_templates'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v125_ActivityCounted_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v125_ActivitySavedData_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v125_AdaptiveTestInstance_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v125_AdaptiveTestQuestionInstance_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v125_AdaptiveTestStrandInstance_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v125_AudioRecording_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v125_CacheVersion_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v125_ComputerInfo_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v125_DBInfo_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v125_Group_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v125_Institution_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v125_InstitutionMediaServer_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v125_QuestionResponse_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v125_schema_info'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v125_scope_config'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v125_scope_info'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v125_scope_parameters'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v125_scope_templates'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v125_Score_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v125_SessionHistory_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v125_StrandProgress_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v125_Student_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v125_StudentGroup_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v125_StudentLessonState_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v125_StudentLessonStateHistory_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v125_SyncHistory_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v125_UnassignedStudent_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v125_User_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v125f1_ActivityCounted_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v125f1_ActivitySavedData_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v125f1_AdaptiveTestInstance_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v125f1_AdaptiveTestQuestionInstance_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v125f1_AdaptiveTestStrandInstance_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v125f1_AudioRecording_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v125f1_CacheVersion_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v125f1_ComputerInfo_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v125f1_DBInfo_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v125f1_Group_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v125f1_Institution_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v125f1_InstitutionMediaServer_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v125f1_QuestionResponse_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v125f1_schema_info'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v125f1_scope_config'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v125f1_scope_info'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v125f1_scope_parameters'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v125f1_scope_templates'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v125f1_Score_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v125f1_SessionHistory_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v125f1_StrandProgress_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v125f1_Student_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v125f1_StudentGroup_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v125f1_StudentLessonState_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v125f1_StudentLessonStateHistory_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v125f1_SyncHistory_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v125f1_UnassignedStudent_tracking'', @PerformDefragmentation = 1
EXEC master.dbo.sp_IndexDefrag @DatabaseList = ''ILCentralDataEnt'', @TableName = ''Sync.v125f1_User_tracking'', @PerformDefragmentation = 1

', 
		@database_name=N'ILCentralDataEnt', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'schedule', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=53, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20110610, 
		@active_end_date=99991231, 
		@active_start_time=184500, 
		@active_end_time=235959, 
		@schedule_uid=N'3a5c199b-59bd-472c-96cc-ba24a573a583'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [Maintenance - Defragmentation - Other]    Script Date: 05/14/2013 13:07:59 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 05/14/2013 13:07:59 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Maintenance - Defragmentation - Other', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'Check specific tables for fragmentation. Process those dbs that need Defragmentation', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'sa', 
		@notify_email_operator_name=N'DBAlerts', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Execute sp_IndexDefrag on Other]    Script Date: 05/14/2013 13:07:59 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Execute sp_IndexDefrag on Other', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
--EXEC master.dbo.sp_IndexDefrag 
--    @DatabaseList = ''msdb,aspnetdb,Edmodo,EdmodoBox,ILBlog,ILBlogLegacy,ILConsumer,ILDAM,ILLogs,ILStoreFront,ILWeb,Imagine,Imagine_2008_8,MobileServices,Reports,Research'',
--    --@ScanMode = ''DETAILED'',
--    @PerformDefragmentation = 1


if ( select is_read_only from sys.databases where name = ''msdb'') = 0
  exec master.dbo.sp_IndexDefrag
    @DatabaseList = ''msdb'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
go

if ( select is_read_only from sys.databases where name = ''aspnetdb'') = 0
  exec master.dbo.sp_IndexDefrag
    @DatabaseList = ''aspnetdb'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
go

if ( select is_read_only from sys.databases where name = ''Edmodo'') = 0
  exec master.dbo.sp_IndexDefrag
    @DatabaseList = ''Edmodo'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
go

if ( select is_read_only from sys.databases where name = ''EdmodoBox'') = 0
  exec master.dbo.sp_IndexDefrag
    @DatabaseList = ''EdmodoBox'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
go

if ( select is_read_only from sys.databases where name = ''ILBlog'') = 0
  exec master.dbo.sp_IndexDefrag
    @DatabaseList = ''ILBlog'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
go

if ( select is_read_only from sys.databases where name = ''ILBlogLegacy'') = 0
  exec master.dbo.sp_IndexDefrag
    @DatabaseList = ''ILBlogLegacy'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
go

if ( select is_read_only from sys.databases where name = ''ILConsumer'') = 0
  exec master.dbo.sp_IndexDefrag
    @DatabaseList = ''ILConsumer'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
go

if ( select is_read_only from sys.databases where name = ''ILDAM'') = 0
  exec master.dbo.sp_IndexDefrag
    @DatabaseList = ''ILDAM'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
go

if ( select is_read_only from sys.databases where name = ''ILLogs'') = 0
  exec master.dbo.sp_IndexDefrag
    @DatabaseList = ''ILLogs'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
go

if ( select is_read_only from sys.databases where name = ''ILStoreFront'') = 0
  exec master.dbo.sp_IndexDefrag
    @DatabaseList = ''ILStoreFront'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
go

if ( select is_read_only from sys.databases where name = ''ILWeb'') = 0
  exec master.dbo.sp_IndexDefrag
    @DatabaseList = ''ILWeb'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
go

if ( select is_read_only from sys.databases where name = ''Imagine'') = 0
  exec master.dbo.sp_IndexDefrag
    @DatabaseList = ''Imagine'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
go

if ( select is_read_only from sys.databases where name = ''Imagine_2008_8'') = 0
  exec master.dbo.sp_IndexDefrag
    @DatabaseList = ''Imagine_2008_8'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
go

if ( select is_read_only from sys.databases where name = ''MobileServices'') = 0
  exec master.dbo.sp_IndexDefrag
    @DatabaseList = ''MobileServices'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
go

if ( select is_read_only from sys.databases where name = ''Reports'') = 0
  exec master.dbo.sp_IndexDefrag
    @DatabaseList = ''Reports'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
go

if ( select is_read_only from sys.databases where name = ''Research'') = 0
  exec master.dbo.sp_IndexDefrag
    @DatabaseList = ''Research'',
    --@ScanMode = ''DETAILED'',
    @PerformDefragmentation = 1
go

', 
		@database_name=N'msdb', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'schedule', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=53, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20110610, 
		@active_end_date=99991231, 
		@active_start_time=70000, 
		@active_end_time=235959, 
		@schedule_uid=N'ca9b02d0-3430-4b79-8b2e-d61f632c214b'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [Maintenance - Statistics]    Script Date: 05/14/2013 13:07:59 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 05/14/2013 13:08:00 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Maintenance - Statistics', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'Perform an update of Statistics on

  ILBlog  
  ILBlogLegacy  
  ILCentral  
  ILCentralData  
  ILCentralDataCum  
  ILCentralDataEnt  
  ILConsumer  
  ILLogs  
  ILStoreFront  
  ILWeb  
  Reports  
  Research  
  
', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'sa', 
		@notify_email_operator_name=N'DBAlerts', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [update ILCentral]    Script Date: 05/14/2013 13:08:00 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'update ILCentral', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'IF ( SELECT is_read_only FROM sys.databases WHERE name = ''ILCentral'') = 0
  EXEC ilcentral.dbo.sp_updatestats', 
		@database_name=N'ILCentral', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [update ILCentralData]    Script Date: 05/14/2013 13:08:00 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'update ILCentralData', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'IF ( SELECT is_read_only FROM sys.databases WHERE name = ''ILCentralData'') = 0
  EXEC ilcentraldata.dbo.sp_updatestats', 
		@database_name=N'ILCentralData', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [update ILCentralDataEnt]    Script Date: 05/14/2013 13:08:00 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'update ILCentralDataEnt', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'IF ( SELECT is_read_only FROM sys.databases WHERE name = ''ILCentralDataEnt'') = 0
  EXEC ilcentraldataent.dbo.sp_updatestats', 
		@database_name=N'ILCentralDataEnt', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [update ILBlog]    Script Date: 05/14/2013 13:08:00 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'update ILBlog', 
		@step_id=4, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'IF ( SELECT is_read_only FROM sys.databases WHERE name = ''ILBlog'') = 0
  EXEC ILBlog.dbo.sp_updatestats', 
		@database_name=N'ILBlog', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [update ILBlogLegacy]    Script Date: 05/14/2013 13:08:00 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'update ILBlogLegacy', 
		@step_id=5, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'IF ( SELECT is_read_only FROM sys.databases WHERE name = ''ILBlogLegacy'') = 0
  EXEC ILBlogLegacy.dbo.sp_updatestats', 
		@database_name=N'ILBlogLegacy', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [update ILCentralDataCum]    Script Date: 05/14/2013 13:08:00 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'update ILCentralDataCum', 
		@step_id=6, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'IF ( SELECT is_read_only FROM sys.databases WHERE name = ''ILCentralDataCum'') = 0
  EXEC ILCentralDataCum.dbo.sp_updatestats', 
		@database_name=N'ILCentralDataCum', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [update ILConsumer]    Script Date: 05/14/2013 13:08:00 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'update ILConsumer', 
		@step_id=7, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'IF ( SELECT is_read_only FROM sys.databases WHERE name = ''ILConsumer'') = 0
  EXEC ILConsumer.dbo.sp_updatestats', 
		@database_name=N'ILConsumer', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [update ILLogs]    Script Date: 05/14/2013 13:08:00 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'update ILLogs', 
		@step_id=8, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'IF ( SELECT is_read_only FROM sys.databases WHERE name = ''ILLogs'') = 0
  EXEC ILLogs.dbo.sp_updatestats', 
		@database_name=N'ILLogs', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [update ILStoreFront]    Script Date: 05/14/2013 13:08:00 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'update ILStoreFront', 
		@step_id=9, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'IF ( SELECT is_read_only FROM sys.databases WHERE name = ''ILStoreFront'') = 0
  EXEC ILStoreFront.dbo.sp_updatestats', 
		@database_name=N'ILStoreFront', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [update ILWeb]    Script Date: 05/14/2013 13:08:00 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'update ILWeb', 
		@step_id=10, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'IF ( SELECT is_read_only FROM sys.databases WHERE name = ''ILWeb'') = 0
  EXEC ILWeb.dbo.sp_updatestats', 
		@database_name=N'ILWeb', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [update Reports]    Script Date: 05/14/2013 13:08:00 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'update Reports', 
		@step_id=11, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'IF ( SELECT is_read_only FROM sys.databases WHERE name = ''Reports'') = 0
  EXEC Reports.dbo.sp_updatestats', 
		@database_name=N'Reports', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [update Research]    Script Date: 05/14/2013 13:08:00 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'update Research', 
		@step_id=12, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'IF ( SELECT is_read_only FROM sys.databases WHERE name = ''Research'') = 0
  EXEC Research.dbo.sp_updatestats', 
		@database_name=N'Research', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'schedule', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20120601, 
		@active_end_date=99991231, 
		@active_start_time=60000, 
		@active_end_time=235959, 
		@schedule_uid=N'0cf2588e-57ee-40b2-9dfe-8e333773d846'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [Offline Cumulative Maintenance.Subplan_1]    Script Date: 05/14/2013 13:08:00 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 05/14/2013 13:08:00 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Offline Cumulative Maintenance.Subplan_1', 
		@enabled=0, 
		@notify_level_eventlog=2, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'COLLECTION\Administrator', 
		@notify_email_operator_name=N'DBAlerts', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Subplan_1]    Script Date: 05/14/2013 13:08:00 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Subplan_1', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'SSIS', 
		@command=N'/Server "$(ESCAPE_NONE(SRVR))" /SQL "Maintenance Plans\Offline Cumulative Maintenance" /set "\Package\Subplan_1.Disable;false"', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [Reinitialize subscriptions having data validation failures]    Script Date: 05/14/2013 13:08:01 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [REPL-Alert Response]    Script Date: 05/14/2013 13:08:01 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'REPL-Alert Response' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'REPL-Alert Response'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Reinitialize subscriptions having data validation failures', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'Reinitializes all subscriptions that have data validation failures.', 
		@category_name=N'REPL-Alert Response', 
		@owner_login_name=N'COLLECTION\Administrator', 
		@notify_email_operator_name=N'DBAlerts', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Run agent.]    Script Date: 05/14/2013 13:08:01 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Run agent.', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec sys.sp_MSreinit_failed_subscriptions @failure_level = 1', 
		@server=N'COLLECTION', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [Replication agents checkup]    Script Date: 05/14/2013 13:08:01 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [REPL-Checkup]    Script Date: 05/14/2013 13:08:01 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'REPL-Checkup' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'REPL-Checkup'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Replication agents checkup', 
		@enabled=1, 
		@notify_level_eventlog=2, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'Detects replication agents that are not logging history actively.', 
		@category_name=N'REPL-Checkup', 
		@owner_login_name=N'COLLECTION\Administrator', 
		@notify_email_operator_name=N'DBAlerts', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Run agent.]    Script Date: 05/14/2013 13:08:01 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Run agent.', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'sys.sp_replication_agent_checkup @heartbeat_interval = 10', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Replication agent schedule.', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=4, 
		@freq_subday_interval=10, 
		@freq_relative_interval=1, 
		@freq_recurrence_factor=0, 
		@active_start_date=20090827, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959, 
		@schedule_uid=N'1cae09c5-45e3-4252-9d8a-126a29e746c5'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [Replication monitoring refresher for distribution.]    Script Date: 05/14/2013 13:08:01 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [REPL-Alert Response]    Script Date: 05/14/2013 13:08:01 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'REPL-Alert Response' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'REPL-Alert Response'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Replication monitoring refresher for distribution.', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'Replication monitoring refresher for distribution.', 
		@category_name=N'REPL-Alert Response', 
		@owner_login_name=N'COLLECTION\Administrator', 
		@notify_email_operator_name=N'DBAlerts', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Run agent.]    Script Date: 05/14/2013 13:08:02 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Run agent.', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=2147483647, 
		@retry_interval=1, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec dbo.sp_replmonitorrefreshjob  ', 
		@server=N'COLLECTION', 
		@database_name=N'distribution', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Replication agent schedule.', 
		@enabled=1, 
		@freq_type=64, 
		@freq_interval=0, 
		@freq_subday_type=0, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20090827, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959, 
		@schedule_uid=N'8ab9451c-e852-4232-b737-92277259b866'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [Restore ILCentral]    Script Date: 05/14/2013 13:08:02 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 05/14/2013 13:08:02 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Restore ILCentral', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'COLLECTION\Administrator', 
		@notify_email_operator_name=N'DBAlerts', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Set single-user mode (kill connectoins in 10 seconds)]    Script Date: 05/14/2013 13:08:02 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Set single-user mode (kill connectoins in 10 seconds)', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'ALTER DATABASE ILCentral
SET SINGLE_USER
WITH ROLLBACK AFTER 10 SECONDS', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Restore Command]    Script Date: 05/14/2013 13:08:02 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Restore Command', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=3, 
		@retry_interval=5, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'DECLARE @cmd NVARCHAR(255)
DECLARE @latestBackup NVARCHAR(255)
DECLARE @fileList TABLE (backupFile NVARCHAR(255))
DECLARE @backupPath NVARCHAR(255)

--SET @cmd = ''dir /on /b \\Mirkwood\CentralServBackup\ILCentral*.bak''
SET @cmd = ''dir /o-d /b \\Mirkwood\CentralServBackup\ILCentral*.bak''
SET @backupPath = ''\\Mirkwood\CentralServBackup\''

INSERT INTO @fileList
EXEC master.sys.xp_cmdshell @cmd

--SELECT @latestBackup = @backupPath + MAX(backupFile)
SELECT top 1 @latestBackup = @backupPath + backupFile
FROM @fileList

RESTORE DATABASE ILCentral
FROM DISK = @latestBackup
WITH MOVE ''ILCentral'' to ''E:\Program Files\Microsoft SQL Server\MSSQL10.MSSQLSERVER\MSSQL\DATA\ILCentral.mdf'',
MOVE ''ILCentral_Log'' to ''D:\Program Files\Microsoft SQL Server\MSSQL10.MSSQLSERVER\MSSQL\Data\ILCentral_Log.ldf'',
REPLACE



', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Connect ASPNET user]    Script Date: 05/14/2013 13:08:02 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Connect ASPNET user', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'alter user [WTFS397\ASPNET] 
with login = [IMAGINELEARNING\ASPNET]', 
		@database_name=N'ILCentral', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Add Bret user object]    Script Date: 05/14/2013 13:08:02 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Add Bret user object', 
		@step_id=4, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'USE [ILCentral]
GO

/****** Object:  User [IMAGINELEARNING\bret.elzinga]    Script Date: 10/13/2009 10:20:18 ******/
GO

CREATE USER [IMAGINELEARNING\bret.elzinga] FOR LOGIN [IMAGINELEARNING\bret.elzinga] WITH DEFAULT_SCHEMA=[dbo]
GO


sp_addrolemember ''db_datareader'', ''IMAGINELEARNING\bret.elzinga''

/****** Object:  User [IMAGINELEARNING\jim.woolf]    Script Date: 10/13/2009 10:20:18 ******/
GO

CREATE USER [IMAGINELEARNING\jim.woolf] FOR LOGIN [IMAGINELEARNING\jim.woolf] WITH DEFAULT_SCHEMA=[dbo]
GO


sp_addrolemember ''db_datareader'', ''IMAGINELEARNING\jim.woolf''
', 
		@database_name=N'ILCentralData', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Set multi-user mode (success)]    Script Date: 05/14/2013 13:08:02 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Set multi-user mode (success)', 
		@step_id=5, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'ALTER DATABASE ILCentral
SET MULTI_USER', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [set AUTO_CLOSE to False]    Script Date: 05/14/2013 13:08:02 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'set AUTO_CLOSE to False', 
		@step_id=6, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'USE [master]
GO
ALTER DATABASE [ILCentral] SET AUTO_CLOSE OFF WITH NO_WAIT
GO
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Daily @ 5:30 am', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20080314, 
		@active_end_date=99991231, 
		@active_start_time=53000, 
		@active_end_time=235959, 
		@schedule_uid=N'46c61f21-cf2b-47b1-8f87-76ad194615f0'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [syspolicy_purge_history]    Script Date: 05/14/2013 13:08:02 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 05/14/2013 13:08:02 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'syspolicy_purge_history', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sa', 
		@notify_email_operator_name=N'DBAlerts', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Verify that automation is enabled.]    Script Date: 05/14/2013 13:08:02 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Verify that automation is enabled.', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=1, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'IF (msdb.dbo.fn_syspolicy_is_automation_enabled() != 1)
        BEGIN
            RAISERROR(34022, 16, 1)
        END', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Purge history.]    Script Date: 05/14/2013 13:08:02 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Purge history.', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC msdb.dbo.sp_syspolicy_purge_history', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Erase Phantom System Health Records.]    Script Date: 05/14/2013 13:08:02 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Erase Phantom System Health Records.', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'PowerShell', 
		@command=N'(Get-Item SQLSERVER:\SQLPolicy\COLLECTION\DEFAULT).EraseSystemHealthPhantomRecords()', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'syspolicy_purge_history_schedule', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20080101, 
		@active_end_date=99991231, 
		@active_start_time=20000, 
		@active_end_time=235959, 
		@schedule_uid=N'534dca98-8365-43d1-b541-cf42885363e5'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [Update Licenses Used]    Script Date: 05/14/2013 13:08:03 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 05/14/2013 13:08:03 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Update Licenses Used', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sa', 
		@notify_email_operator_name=N'DBAlerts', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [step]    Script Date: 05/14/2013 13:08:03 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'step', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec [UpdateLicensesUsed]', 
		@database_name=N'ILCentralDataEnt', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'schedule', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20110727, 
		@active_end_date=99991231, 
		@active_start_time=60000, 
		@active_end_time=235959, 
		@schedule_uid=N'f7d0850c-f9bd-44eb-aada-2c95e249c600'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [Weekly Tuning.Subplan_1]    Script Date: 05/14/2013 13:08:03 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 05/14/2013 13:08:03 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Weekly Tuning.Subplan_1', 
		@enabled=0, 
		@notify_level_eventlog=2, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'COLLECTION\Administrator', 
		@notify_email_operator_name=N'DBAlerts', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Subplan_1]    Script Date: 05/14/2013 13:08:03 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Subplan_1', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'SSIS', 
		@command=N'/Server "$(ESCAPE_NONE(SRVR))" /SQL "Maintenance Plans\Weekly Tuning" /set "\Package\Subplan_1.Disable;false"', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Weekly Tuning.Subplan_1', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20090827, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959, 
		@schedule_uid=N'b34c7791-4b8a-4192-bb62-4e2744058eb1'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

