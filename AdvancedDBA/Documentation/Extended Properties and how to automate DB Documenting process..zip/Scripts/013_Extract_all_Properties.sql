use EP_TestDB;
GO
;WITH o AS (
  -- Extract Columns
  SELECT 1 as Class, o.object_id as major_id, o.name as Major_Name, 
    CASE o.type WHEN 'U' THEN 'TABLE' WHEN 'TF' THEN 'FUNCTION' ELSE 'VIEW' END as Major_Object, 
    c.Column_Id as Minor_Id, c.name as Minor_Name, 'COLUMN' as Minor_Object,
    o.schema_Id
  FROM sys.objects as o INNER JOIN sys.columns as c 
  ON o.object_id = c.object_id WHERE o.type in ('U','V','TF')
  UNION
  -- Extract Tables & Views & Functions, & Procedures
  SELECT 1 as Class, o.object_id as major_id, o.name as Major_Name, 
    CASE o.type WHEN 'U' THEN 'TABLE' WHEN 'V' THEN 'VIEW' WHEN 'P' THEN 'PROCEDURE' ELSE 'FUNCTION' END as Major_Object, 
    0, '', '', o.schema_Id
  FROM sys.objects as o WHERE o.type in ('U','V', 'FN','TF','P')
  UNION
  -- Extract Constraints & Triggers
  SELECT 1 as Class, o.object_id as major_id, po.name as Major_Name, 
    CASE po.type WHEN 'U' THEN 'TABLE' WHEN 'V' THEN 'VIEW' ELSE po.Type_Desc END as Major_Object, 
    0, o.name as Minor_Name, CASE o.type WHEN 'TR' THEN 'TRIGGER' ELSE 'CONSTRAINT' END  as Minor_Object, 
    po.schema_Id
  FROM sys.objects as o 
  INNER JOIN sys.objects as po ON o.Parent_object_id = po.object_id
  WHERE o.type in ('PK','C','D','F','TR') and  po.type in ('U','V')
  UNION
  -- Extract Functions' & Procedures' parameters
  SELECT 2 as Class, o.object_id as major_id, o.name as Major_Name, 
    CASE o.type WHEN 'P' THEN 'PROCEDURE' ELSE 'FUNCTION' END as Major_Object, p.Parameter_Id as Minor_Id, 
    CASE p.name WHEN '' THEN 'N/A' ELSE p.name End as Minor_Name, 'PARAMETER' as Minor_Object, o.schema_Id
  FROM sys.objects as o INNER JOIN sys.parameters as p on o.object_id = p.object_id 
  WHERE o.type in ('FN','P','TF')
  UNION
  -- Extract Indexes
  SELECT 7 as Class, i.object_id as major_id, o.name as Major_Name, 
    CASE o.type WHEN 'U' THEN 'TABLE' ELSE o.Type_Desc END as Major_Object, 
    i.index_id as Minor_Id, i.name as Minor_Name, 'INDEX' as Minor_Object, o.schema_Id
  FROM sys.INDEXES as i 
  INNER JOIN sys.objects as o ON i.object_id = o.object_id
  UNION
  -- Extract xml_schemas
  SELECT 10 as Class, s.xml_collection_id as major_id, s.name as Major_Name, 'XML SCHEMA COLLECTION' as Major_Object, 0 as Minor_Id, '', '', s.schema_Id
  FROM sys.xml_schema_collections s
  UNION
  -- Extract Synonyms
  SELECT 1 as Class, s.object_id as major_id, s.name as Major_Name, 'SYNONYM' as Major_Object, 0 as Minor_Id, '', '', s.schema_Id
  FROM sys.synonyms s 
  UNION
  -- Extract User Defined Types
  SELECT 6 as Class, t.user_type_id as major_id, t.name as Major_Name, 'TYPE' as Major_Object, 0 as Minor_Id, '', '', t.schema_Id
  FROM sys.types as t WHERE system_type_id != user_type_id
)
SELECT s.name as SchemaName, o.Major_Object, o.Major_Name, o.Minor_Object, o.Minor_Name, ep.name, ep.Value
FROM sys.extended_properties as ep
INNER JOIN o ON o.major_id = ep.major_id and ep.Minor_Id = o.Minor_Id and ep.Class = o.Class
INNER JOIN sys.schemas as s ON s.schema_Id = o.schema_Id
WHERE ep.Class in (1,2,6,7,10)
ORDER BY o.Major_Object, o.Major_Name, ep.minor_id;

