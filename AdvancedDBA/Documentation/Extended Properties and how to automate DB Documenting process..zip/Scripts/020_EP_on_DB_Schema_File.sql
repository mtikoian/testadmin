/*
SQL Saturday 

March , 2014

Extended Properties and how to automate DB Documenting process. 

Slava Murygin

Assign Extended Properties to Database, Schema, User and Files
*/


-------------- Assign Extended Properties to Database
USE EP_TestDB
GO
EXEC sys.sp_addextendedproperty @name=N'Database description', @value=N'This is test Extended property for EP_TestDB DB' 
GO
EXEC sys.sp_addextendedproperty @name=N'Additional Database description', @value=N'Demonstrate ability of having multiple Extended Properties for one Object' 
GO
----------------------------------------------------------------------------------------------------------------------------------

-------------- Assign Extended Properties to Schemas
USE EP_TestDB
GO
EXECUTE sys.sp_addextendedproperty @level0type = N'SCHEMA', @level0name = 'EP_Test_Schema',
  @name = N'Schema Description', @value = N'Test schema in EP_TestDB DB.';
GO
EXECUTE sys.sp_addextendedproperty @level0type = N'SCHEMA', @level0name = 'dbo',
  @name = N'Schema Description', @value = N'Default schema in EP_TestDB DB.';
GO
----------------------------------------------------------------------------------------------------------------------------------

-------------- Assign Extended Properties to a User
USE EP_TestDB
GO
EXECUTE sys.sp_addextendedproperty @level0type = N'USER', @level0name = 'TestUser',
  @name = N'User Description', @value = N'Test Description for user in EP_TestDB DB.';
GO
----------------------------------------------------------------------------------------------------------------------------------

-------------- Assign Extended Properties to a FILEGROUP
USE EP_TestDB
GO
EXECUTE sys.sp_addextendedproperty @level0type = N'FILEGROUP', @level0name = 'PRIMARY',
  @name = N'Filegroup Description', @value = N'Primary Filegroup in EP_TestDB DB.';
GO
----------------------------------------------------------------------------------------------------------------------------------

-------------- Assign Extended Properties to a Database File
USE EP_TestDB
GO
EXECUTE sys.sp_addextendedproperty @level0type = N'FILEGROUP', @level0name = 'PRIMARY',
  @level1type = N'Logical File Name', @level1name = 'EP_TestDB',
  @name = N'Data File Description', @value = N'Data file of EP_TestDB DB.';
GO
-- There is not possible to assign Extended Properties to a Log File


----------------------------------------------------------------------------------------------------------------------------------

-------------- Show properties
SELECT ep.class_desc, COALESCE(s.Name, fg.name, df.name, '') as ObjectName, ep.name as Property_Name, ep.value as Property_Value, ep.* 
FROM sys.extended_properties as ep
LEFT JOIN sys.schemas as s ON s.schema_id = ep.major_id and ep.class_desc = 'SCHEMA'
LEFT JOIN sys.filegroups as fg ON fg.data_space_id = ep.major_id and ep.class_desc = 'DATASPACE'
LEFT JOIN sys.database_files as df ON df.file_id = ep.major_id and ep.class_desc = 'DATABASE_FILE'
WHERE ep.Class in (0,3,4,20,22) and ep.name != 'MS_Description';
GO
