/*
SQL Saturday #294 Philadelphia, PA

June 7, 2014

Best SQL Server Programming practices

Slava Murygin

Stored Procedure Template

Usage:
1. Save as new file
2. Rename Current DB (If it's not current)
3. Rename Current DB Schema (If it's not current)
4. Rename Procedure
5. Delete unnecesary manipulations
6. Add necesary checks.
7. Add SP logic. 
8. Document SP. 
9. Run the script.

*/
USE SomeDatabase
GO
IF EXISTS (SELECT TOP 1 1 FROM sys.procedures p WHERE object_id = OBJECT_ID('[SomeSchema].[usp_SomeProcedure]'))
DROP PROCEDURE [SomeSchema].[usp_SomeProcedure]
GO
CREATE PROCEDURE [SomeSchema].[usp_SomeProcedure]
/***********************************************************************************************************************
#Description - record in following tables:

#Checkups

#Logic

#Example of Usage:
EXEC [SomeSchema].[usp_SomeProcedure] '123456', 'MuryginS', '<XML/>'

***********************************************************************************************************************
Person           Date       Action Description
---------------- ---------- ------ ----------------------------------------------------------------
Slava Murygin    2013-12-07 Init   Creation
***********************************************************************************************************************/
@User Varchar(50), -- User, under who runs a request
@TaxId Char(9) ,
@Login Varchar(50),
@XML XML,
@Debug tinyint=0
WITH EXECUTE AS OWNER
AS
SET NOCOUNT ON

DECLARE @SP_Name varchar(128) = OBJECT_SCHEMA_NAME(@@PROCID) + '.' + OBJECT_NAME(@@PROCID)

IF SomeSchema.ufn_User_Access(@User, @SP_Name ) != 0
BEGIN 
	RAISERROR ('User has no rights to run this procedure', 16, 1);
	RETURN 0;
END

INSERT INTO SomeSchema.tbl_Activity_Audit(UserLogin, Activity, Parameters)
VALUES (@User, @SP_Name, '<Param  Login="' + Common.ufn_Replace_for_XML(@Login) + '">' + @XML + '</Param>')

OPEN SYMMETRIC KEY EncryptionCommonKey DECRYPTION BY CERTIFICATE EncryptionCommonCertificate

DECLARE @ETaxId varbinary(255) = ENCRYPTBYKEY(KEY_GUID('EncryptionCommonKey'),@TaxId)
DECLARE @EHash TINYINT = CAST(@ETaxId as TINYINT)

CLOSE SYMMETRIC KEY EncryptionCommonKey

-- Start of Checkups --------------------------------------------------------------------------------------------

-- Check if "Sequence" does not have duplicates
IF EXISTS (SELECT TOP 1 1 FROM @ComponentMethods GROUP BY Sequence HAVING COUNT(*) > 1)
BEGIN
	RAISERROR ('Provided Sequence numbers have duplicates.', 16, 1);
	RETURN 1;
END;

-- End of Checkups ----------------------------------------------------------------------------------------------

BEGIN TRANSACTION 
BEGIN TRY
  -- Main Logic
  IF @Debug != 0
  BEGIN
	  PRINT CAST(@Debug as varchar)
  END
END TRY

BEGIN CATCH
	EXECUTE SomeSchema.usp_GetErrorInfo @SP_Name, '';
	IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;

	SET @SP_Name = 'Error raised in ' + @SP_Name
	RAISERROR (@SP_Name, 16, 1);
	RETURN 1;
END CATCH;
COMMIT TRANSACTION

RETURN 0;
GO


EXEC sys.sp_addextendedproperty 
	@name=N'MS_Description', @value=N'Procedure description.' ,
	@level0type=N'SCHEMA',@level0name=N'SomeSchema', 
	@level1type=N'PROCEDURE',@level1name=N'usp_SomeProcedure'
GO

EXEC sys.sp_addextendedproperty 
	@name=N'MS_Description', @value=N'User id of a user who started SP.' , 
	@level0type=N'SCHEMA',@level0name=N'SomeSchema', 
	@level1type=N'PROCEDURE',@level1name=N'usp_SomeProcedure', 
	@level2type=N'PARAMETER',@level2name=N'@User'
GO

EXEC sys.sp_addextendedproperty 
	@name=N'MS_Description', @value=N'Tax ID or SSN.' , 
	@level0type=N'SCHEMA',@level0name=N'SomeSchema', 
	@level1type=N'PROCEDURE',@level1name=N'usp_SomeProcedure', 
	@level2type=N'PARAMETER',@level2name=N'@TaxId'
GO

EXEC sys.sp_addextendedproperty 
	@name=N'MS_Description', @value=N'@Login name of a user who started SP.' , 
	@level0type=N'SCHEMA',@level0name=N'SomeSchema', 
	@level1type=N'PROCEDURE',@level1name=N'usp_SomeProcedure', 
	@level2type=N'PARAMETER',@level2name=N'@Login'
GO

EXEC sys.sp_addextendedproperty 
	@name=N'MS_Description', @value=N'XML formatted list of parameters.' , 
	@level0type=N'SCHEMA',@level0name=N'SomeSchema', 
	@level1type=N'PROCEDURE',@level1name=N'usp_SomeProcedure', 
	@level2type=N'PARAMETER',@level2name=N'@XML'
GO

EXEC sys.sp_addextendedproperty 
	@name=N'MS_Description', @value=N'Debugging indicator.' , 
	@level0type=N'SCHEMA',@level0name=N'SomeSchema', 
	@level1type=N'PROCEDURE',@level1name=N'usp_SomeProcedure', 
	@level2type=N'PARAMETER',@level2name=N'@Debug'
GO
