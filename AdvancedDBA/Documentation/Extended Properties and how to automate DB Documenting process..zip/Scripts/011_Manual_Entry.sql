/*
DATABASE:
[EP_TestDB]
Test:
That is a test database to demonstrate EP

[Person].[Address]
Description
That table contains only personal addresses

[City]
Description
City where person live
*/