USE EP_TestDB;
GO
/* Add property to a Database */
EXEC sp_addextendedproperty 
	@name=N'Test Database Extended Property', 
	@value=N'This is the Test Database Extended Property';
GO
/*Add EP to Procedure's parameter */
EXEC sys.sp_addextendedproperty 
	@name=N'Testing Description', @value=N'ID of a starting product. Property is used for testing purposes only.' , 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'PROCEDURE',@level1name=N'uspGetBillOfMaterials', 
	@level2type=N'PARAMETER',@level2name=N'@StartProductID';
GO
/*Add EP to Table's Constraint*/
EXEC sys.sp_addextendedproperty 
	@name=N'Testing Description', @value=N'Test Property for Address Modified Dt.' , 
	@level0type=N'SCHEMA', @level0name=N'Person', 
	@level1type=N'TABLE',@level1name=N'Address', 
	@level2type=N'CONSTRAINT',@level2name=N'DF_Address_ModifiedDate';
GO
/*--------------------------------------------------------------------------------------------------------*/
/* Update extended property for a Database */
EXEC sp_updateextendedproperty 
	@name=N'Test Database Extended Property', 
	@value=N'This is UPDATED the Test Database Extended Property';
GO
/*--------------------------------------------------------------------------------------------------------*/
/* Drop extended property for a Database */
EXEC sp_dropextendedproperty @name=N'Test Database Extended Property';
GO
/*--------------------------------------------------------------------------------------------------------*/
/* Look for extended properties for the Database*/
SELECT * FROM sys.fn_listextendedproperty(default, default, default, default, default, default, default);
GO
/* Look for extended properties */
SELECT * FROM sys.fn_listextendedproperty (NULL, 'schema', 'Person', 'table', 'Address', 'CONSTRAINT', default);
GO
SELECT * FROM sys.fn_listextendedproperty (
	'Testing Description', 
	'schema', 'Person', 
	'table', 'Address', 
	'CONSTRAINT', 'DF_Address_ModifiedDate');
GO
/* Look for extended properties */
SELECT * FROM sys.fn_listextendedproperty (NULL, 'schema', 'dbo', 'PROCEDURE', 'uspGetBillOfMaterials', 'PARAMETER', default);
GO
/*--------------------------------------------------------------------------------------------------------*/
SELECT * FROM sys.extended_properties;
GO
SELECT ep.class_desc, o.name as "Object_Name", o.type_desc, ep.name, ep.value
FROM sys.extended_properties as ep
INNER JOIN sys.objects as o ON o.object_id = ep.major_id;
GO
SELECT o.name as "Object_Name", o.type_desc, c.name as Column_Name, ep.name, ep.value
FROM sys.extended_properties as ep
INNER JOIN sys.objects as o ON o.object_id = ep.major_id
INNER JOIN sys.columns as c ON o.object_id = c.object_id and ep.minor_id = c.column_id
WHERE o.type in ('V','U');
GO
SELECT o.name as "Object_Name", o.type_desc, p.name as Parameter_Name, ep.name, ep.value
FROM sys.extended_properties as ep
INNER JOIN sys.objects as o ON o.object_id = ep.major_id
INNER JOIN sys.parameters as p ON o.object_id = p.object_id and ep.minor_id = p.parameter_id
WHERE o.type in ('P','FN');
GO

/*   END */