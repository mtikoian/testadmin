Use AdventureWorksDW2014;

-- Run a query
Select FinanceKey, Amount, Date
From dbo.FactFinance
Where FinanceKey > 3;

-- Create an index on FinanceKey
Create Index ix_FactFinance_FinanceKey On dbo.FactFinance(FinanceKey);

-- Re-run query
Select FinanceKey, Amount, Date
From dbo.FactFinance
Where FinanceKey > 3;

-- Let's try forcing a recompile
Exec sp_recompile N'dbo.FactFinance';

-- Re-run query
Select FinanceKey, Amount, Date
From dbo.FactFinance
Where FinanceKey > 3;

-- Re-run query
Select FinanceKey, Amount, Date
From dbo.FactFinance
Where FinanceKey <= 3;

-- Compare first query with each plan
-- Compare both query plans and IO
Set Statistics IO On;
-- Table scan
Select FinanceKey, Amount, Date
From dbo.FactFinance with(index(0))
Where FinanceKey > 3;

Set Statistics IO Off;

Set Statistics IO On;
-- Index seek plus RID lookups
Select FinanceKey, Amount, Date
From dbo.FactFinance with(index=ix_FactFinance_FinanceKey)
Where FinanceKey > 3;

Set Statistics IO Off;

-- Compare second query with each plan
-- Compare both query plans and IO
Set Statistics IO On;
-- Table scan
Select FinanceKey, Amount, Date
From dbo.FactFinance with(index(0))
Where FinanceKey <= 3;

Set Statistics IO Off;

Set Statistics IO On;
-- Index seek plus RID lookups
Select FinanceKey, Amount, Date
From dbo.FactFinance with(index=ix_FactFinance_FinanceKey)
Where FinanceKey <= 3;

Set Statistics IO Off;

-- Create covering index
Create Index ix_FactFinance_FinanceKey_Incs On dbo.FactFinance(FinanceKey)
	Include (Amount, Date);

-- Let's see the difference in all 3 plans
Set Statistics IO On;
-- Table scan
Select FinanceKey, Amount, Date
From dbo.FactFinance with(index(0))
Where FinanceKey > 3;

Set Statistics IO Off;

Set Statistics IO On;
-- Index seek plus RID lookups
Select FinanceKey, Amount, Date
From dbo.FactFinance with(index=ix_FactFinance_FinanceKey)
Where FinanceKey > 3;

Set Statistics IO Off;

Set Statistics IO On;
-- Covering index
Select FinanceKey, Amount, Date
From dbo.FactFinance
Where FinanceKey > 3;

Set Statistics IO Off;


-- Clean up
-- Drop Index
Drop Index ix_FactFinance_FinanceKey On dbo.FactFinance;
Drop Index ix_FactFinance_FinanceKey_Incs On dbo.FactFinance