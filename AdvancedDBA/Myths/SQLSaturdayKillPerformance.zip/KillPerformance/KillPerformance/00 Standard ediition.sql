USE SQLServiceSommarkollo2013;
GO
SET NOCOUNT ON;
GO

IF NOT EXISTS (SELECT * FROM sys.[schemas] AS s WHERE name = 'DEMO')
	EXEC sp_executeSQL 'CREATE SCHEMA DEMO';	
GO

IF NOT EXISTS(SELECT * FROM Sys.[sequences] AS s WHERE s.[name] = 'IDGenerator')
	CREATE SEQUENCE DEMO.IDGenerator AS INT START WITH 1 INCREMENT BY 1 NO MAXVALUE CYCLE;
GO

IF EXISTS(SELECT * FROM [INFORMATION_SCHEMA].Tables t WHERE t.[TABLE_SCHEMA]='DEMO' AND [t].[TABLE_NAME]='UDTTest')
	DROP TABLE [DEMO].UDTTest;

CREATE TABLE DEMO.UDTTest
(
    [ID] int NOT NULL DEFAULT NEXT VALUE FOR DEMO.IDGenerator,
    [NAME] CHAR(1000) NOT NULL,
	 IntString INT NULL,
	 DateString Date NULL
);

SET STATISTICS TIME on
----------------------------------------------------------------------------------------------------------------
-- Add some data
----------------------------------------------------------------------------------------------------------------
INSERT INTO DEMO.UDTTest ([NAME], IntString, DateString)
SELECT TOP 100000 c.name, x.n, CONVERT(VARCHAR(10),DATEADD(d,x.n,'1900-01-01'),121) FROM sys.[columns] AS c 
CROSS APPLY (SELECT ROW_NUMBER() OVER(ORDER BY GETDATE()) FROM sys.columns) AS x(n);
GO


CREATE NONCLUSTERED INDEX [IX_UDTTest]
ON [DEMO].[UDTTest] ([IntString])
WITH (FILLFACTOR=100, SORT_IN_TEMPDB=ON)

SET STATISTICS TIME	OFF
IF EXISTS(SELECT * FROM [INFORMATION_SCHEMA].Tables t WHERE t.[TABLE_SCHEMA]='DEMO' AND [t].[TABLE_NAME]='UDTTest')
	DROP TABLE [DEMO].UDTTest;

CREATE TABLE DEMO.UDTTest
(
    [ID] int NOT NULL DEFAULT NEXT VALUE FOR DEMO.IDGenerator,
    [NAME] CHAR(1000) NOT NULL,
	 IntString INT NULL,
	 DateString Date NULL
) WITH (DATA_COMPRESSION=PAGE)

----------------------------------------------------------------------------------------------------------------
-- Add some data
----------------------------------------------------------------------------------------------------------------
SET STATISTICS TIME ON
INSERT INTO DEMO.UDTTest ([NAME], IntString, DateString)
SELECT TOP 100000 c.name, x.n, CONVERT(VARCHAR(10),DATEADD(d,x.n,'1900-01-01'),121) FROM sys.[columns] AS c 
CROSS APPLY (SELECT ROW_NUMBER() OVER(ORDER BY GETDATE()) FROM sys.columns) AS x(n);
GO

CREATE NONCLUSTERED INDEX [IX_UDTTest]
ON [DEMO].[UDTTest] ([IntString])
WITH (FILLFACTOR=100, SORT_IN_TEMPDB=ON, DATA_COMPRESSION=page)
SET STATISTICS TIME OFF	