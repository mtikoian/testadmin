USE [SQLServiceSommarkollo2013]
IF EXISTS (SELECT * FROM [INFORMATION_SCHEMA].[TABLES] AS [t] WHERE [t].[TABLE_NAME]='Table1' AND [t].[TABLE_SCHEMA]='dbo')
	DROP	 TABLE dbo.Table1; 

CREATE TABLE dbo.table1 ( 
col1 INT IDENTITY(1,1) NOT NULL, 
col2 DATE NOT NULL 
);
GO

IF EXISTS (SELECT * FROM [INFORMATION_SCHEMA].[TABLES] AS [t] WHERE [t].[TABLE_NAME]='Table2' AND [t].[TABLE_SCHEMA]='dbo')
	DROP	 TABLE dbo.Table2; 

CREATE TABLE dbo.table2 ( 
col1 INT IDENTITY(100000,1) NOT NULL, 
col2 DATE NOT NULL ) ;
GO

SELECT  
	T1.COL2 ,
    col1 = ( 
			SELECT    t2.[col1]
			FROM      [table2] AS t2
			WHERE     t2.[col2] = t1.[col2]
			)  --The inner query that is correlated with the outer query 
FROM [table1] AS T1



;WITH cteNums AS
( 
	-- I use this common table expression to create a list of numbers from 1 to 1 000 000 
	SELECT top 1000000 ROW_NUMBER() OVER(ORDER BY o1.object_ID) AS n 
	FROM master.sys.columns o1 
	CROSS JOIN master.sys.columns o2 
	CROSS JOIN master.sys.columns o3 
) 
INSERT INTO table1 (col2) --insert into table1 
OUTPUT INSERTED.col2 INTO table2 (col2) --use the output clause to insert into table2 
SELECT DATEADD(d,n,GETDATE()) -- create dates from the list of numbers 
FROM cteNums;

--Now I have two tables with 1 000 000 records in each, they contain the same set of data and it's time to compare a correlate subquery with a simple join.
SET STATISTICS IO ON; 
SET STATISTICS TIME ON; 
DBCC DROPCLEANBUFFERS; 

--first use a correlated subquery to populate a temp table to avoid the data transfer to the client 
SELECT
	T1.COL2 ,
	(
		SELECT
			t2.[col1]
		FROM
			[table2] AS t2
		WHERE
			t2.[col2] = t1.[col2]
	) AS col1
INTO
	#TABLE3
FROM
	[table1] AS T1 
DBCC DROPCLEANBUFFERS; 

--second use a simple join to populate a temp table to avoid the data transfer to the client 
SELECT
	T1.COL2 ,
	T3.col1
INTO
	#TABLE4
FROM
	[table1] AS T1
INNER JOIN (
				SELECT
					t2.[col1] ,
					T2.COL2
				FROM
					[table2] AS t2
			) AS t3
	ON T3.[col2] = t1.[col2] 
SET STATISTICS TIME OFF; 
SET STATISTICS IO OFF; 
DROP TABLE [#table3]
DROP TABLE [#table4]
