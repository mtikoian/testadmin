USE SQLServiceSommarkollo2013;
GO
SET NOCOUNT ON;
GO

IF NOT EXISTS (SELECT * FROM sys.[schemas] AS s WHERE name = 'DEMO')
	EXEC sp_executeSQL 'CREATE SCHEMA DEMO';	
GO

IF NOT EXISTS(SELECT * FROM Sys.[sequences] AS s WHERE s.[name] = 'IDGenerator')
	CREATE SEQUENCE DEMO.IDGenerator AS INT START WITH 1 INCREMENT BY 1 NO MAXVALUE CYCLE;
GO

IF EXISTS(SELECT * FROM [INFORMATION_SCHEMA].Tables t WHERE t.[TABLE_SCHEMA]='DEMO' AND [t].[TABLE_NAME]='DataTypeTest')
	DROP TABLE [DEMO].DataTypeTest;

CREATE TABLE DEMO.DataTypeTest
(
    [ID] int NOT NULL DEFAULT NEXT VALUE FOR DEMO.IDGenerator,
    [NAME] CHAR(1000) NOT NULL,
	 IntString VARCHAR(10) NULL,
	 DateString VARCHAR(10) NULL
);

----------------------------------------------------------------------------------------------------------------
-- Add some data
----------------------------------------------------------------------------------------------------------------
INSERT INTO DEMO.DataTypeTest ([NAME], IntString, DateString)
SELECT TOP 8000 c.name, x.n, CONVERT(VARCHAR(10),DATEADD(d,x.n,'1900-01-01'),121) FROM sys.[columns] AS c 
CROSS APPLY (SELECT ROW_NUMBER() OVER(ORDER BY GETDATE()) FROM sys.columns) AS x(n)



CREATE INDEX ix_DataTypeTest ON [DEMO].[DataTypeTest] ([IntString]) INCLUDE([NAME], DateString) WITH(FILLFACTOR=100, SORT_IN_TEMPDB=ON)
GO

----------------------------------------------------------------------------------------------------------------
-- Get all records sorted by IntString
----------------------------------------------------------------------------------------------------------------
SELECT dt.*									FROM DEMO.DataTypeTest dt									ORDER BY IntString					-- wrong sort order, table scan, sort
SELECT dt.[NAME], dt.[DateString]	FROM DEMO.DataTypeTest dt									ORDER BY IntString					-- wrong sort order, index scan,  no sort
SELECT dt.[NAME], dt.[DateString]	FROM DEMO.DataTypeTest dt									ORDER BY CONVERT(INT,IntString)	-- index scan, sort
SELECT dt.[NAME], dt.[DateString]	FROM DEMO.DataTypeTest dt WHERE [IntString]>100		ORDER BY CONVERT(INT,IntString)	-- index scan, sort, implicit convert
SELECT dt.[NAME], dt.[DateString]	FROM DEMO.DataTypeTest dt WHERE [IntString]>'100'	ORDER BY CONVERT(INT,IntString)	-- index seek, sort


----------------------------------------------------------------------------------------------------------------
-- Drop the index
-- Change the IntString to INT
-- Add the index
----------------------------------------------------------------------------------------------------------------
DROP INDEX [DEMO].[DataTypeTest].[ix_DataTypeTest];	

ALTER TABLE [DEMO].[DataTypeTest] ALTER COLUMN [IntString] INT;

CREATE INDEX ix_DataTypeTest ON [DEMO].[DataTypeTest] ([IntString]) INCLUDE([NAME], DateString) WITH(FILLFACTOR=100, SORT_IN_TEMPDB=ON)
GO
DBCC  FREEPROCCACHE
----------------------------------------------------------------------------------------------------------------
-- Get all records sorted by IntString
----------------------------------------------------------------------------------------------------------------
SELECT dt.*									FROM DEMO.DataTypeTest dt									ORDER BY IntString		-- table scan, sort
SELECT dt.[NAME], dt.[DateString]	FROM DEMO.DataTypeTest dt									ORDER BY IntString		-- index scan, no sort
SELECT dt.[NAME], dt.[DateString]	FROM DEMO.DataTypeTest dt WHERE [IntString]>100		ORDER BY IntString		-- index seek, no sort
SELECT dt.[NAME], dt.[DateString]	FROM DEMO.DataTypeTest dt WHERE [IntString]>'100'	ORDER BY IntString		-- index seek, no sort, implicit convert (p� r�tt st�lle)


----------------------------------------------------------------------------------------------------------------
-- Get records by date
----------------------------------------------------------------------------------------------------------------
DECLARE @myDate1 DATE='1900-01-27';
SELECT * FROM [DEMO].[DataTypeTest] AS dtt WHERE [dtt].[DateString] = @myDate1;

----------------------------------------------------------------------------------------------------------------
-- Change one date to an incorrect date
----------------------------------------------------------------------------------------------------------------
UPDATE TOP (1) [DEMO].[DataTypeTest] 
SET [DateString] ='190-001-27' 
FROM [DEMO].[DataTypeTest] AS dtt;

----------------------------------------------------------------------------------------------------------------
-- Try to gate records by date
----------------------------------------------------------------------------------------------------------------
DECLARE @myDate2 DATE='1900-01-27';
SELECT * FROM [DEMO].[DataTypeTest] AS dtt WHERE [dtt].[DateString] = @myDate2;
DECLARE @myDate3 DATE='1900-01-27';
SELECT * FROM [DEMO].[DataTypeTest] AS dtt WHERE TRY_CONVERT(date,[dtt].[DateString]) = @myDate3 OR TRY_CONVERT(date,[dtt].[DateString]) IS NULL;