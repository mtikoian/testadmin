USE SQLServiceSommarkollo2013;
GO
SET NOCOUNT ON;
GO

IF NOT EXISTS (SELECT * FROM sys.[schemas] AS s WHERE name = 'DEMO')
	EXEC sp_executeSQL 'CREATE SCHEMA DEMO';	
GO

IF NOT EXISTS(SELECT * FROM Sys.[sequences] AS s WHERE s.[name] = 'IDGenerator')
	CREATE SEQUENCE DEMO.IDGenerator AS INT START WITH 1 INCREMENT BY 1 NO MAXVALUE CYCLE;
GO

IF EXISTS(SELECT * FROM [INFORMATION_SCHEMA].Tables t WHERE t.[TABLE_SCHEMA]='DEMO' AND [t].[TABLE_NAME]='UDTTest')
	DROP TABLE [DEMO].UDTTest;

CREATE TABLE DEMO.UDTTest
(
    [ID] int NOT NULL DEFAULT NEXT VALUE FOR DEMO.IDGenerator,
    [NAME] CHAR(1000) NOT NULL,
	 IntString INT NULL,
	 DateString Date NULL
);

----------------------------------------------------------------------------------------------------------------
-- Add some data
----------------------------------------------------------------------------------------------------------------
INSERT INTO DEMO.UDTTest ([NAME], IntString, DateString)
SELECT TOP 100000 c.name, x.n, CONVERT(VARCHAR(10),DATEADD(d,x.n,'1900-01-01'),121) FROM sys.[columns] AS c 
CROSS APPLY (SELECT ROW_NUMBER() OVER(ORDER BY GETDATE()) FROM sys.columns) AS x(n);
GO

CREATE NONCLUSTERED INDEX [IX_UDTTest]
ON [DEMO].[UDTTest] ([IntString])
WITH (FILLFACTOR=100, SORT_IN_TEMPDB=ON)


IF EXISTS(SELECT * FROM [INFORMATION_SCHEMA].Routines r WHERE r.[ROUTINE_SCHEMA]='DEMO' AND [r].[ROUTINE_NAME]='fnInlineUdtTest')
	DROP FUNCTION [DEMO].[fnInlineUdtTest];
GO
CREATE FUNCTION DEMO.fnInlineUdtTest()
RETURNS TABLE
AS
RETURN 
	SELECT TOP 100000 ROW_NUMBER() OVER(ORDER BY GETDATE()) AS n
	FROM sys.[columns] AS c 
	CROSS APPLY (
						SELECT 1 
						FROM sys.columns) AS x(n);
GO


IF EXISTS(SELECT * FROM [INFORMATION_SCHEMA].Routines r WHERE r.[ROUTINE_SCHEMA]='DEMO' AND [r].[ROUTINE_NAME]='fnNonInlineUdtTest')
	DROP FUNCTION [DEMO].[fnNonInlineUdtTest];
GO


CREATE FUNCTION DEMO.fnNonInlineUdtTest()
RETURNS @returntable TABLE 
(
	[n] int
)
AS
BEGIN
 
	INSERT @returntable
   SELECT TOP 100000 ROW_NUMBER() OVER(ORDER BY GETDATE()) n
	FROM sys.[columns] AS c 
	CROSS APPLY (
						SELECT 1 
						FROM sys.columns) AS x(n);
	RETURN;
END
GO


SET STATISTICS IO ON;
SET STATISTICS TIME ON; 
SELECT * FROM DEMO.fnInlineUdtTest()
SELECT * FROM DEMO.fnNonInlineUdtTest()

SET STATISTICS TIME ON;
DBCC DROPCLEANBUFFERS WITH	NO_INFOMSGS;

SELECT * FROM [DEMO].[UDTTest] AS ut
INNER JOIN [DEMO].[fnInlineUdtTest]() AS fniut ON [ut].[IntString] = [fniut].[n];

DBCC DROPCLEANBUFFERS WITH	NO_INFOMSGS;
SELECT * FROM [DEMO].[UDTTest] AS ut
INNER JOIN [DEMO].fnNonInlineUdtTest() AS fniut ON [ut].[IntString] = [fniut].[n];

DBCC DROPCLEANBUFFERS WITH	NO_INFOMSGS;