USE [AdventureWorks2014]
GO

INSERT INTO Production.Product (Name, ProductNumber, MakeFlag, FinishedGoodsFlag, SafetyStockLevel, ReorderPoint, StandardCost, ListPrice, DaysToManufacture, SellStartDate, rowguid, ModifiedDate)
SELECT TOP 1 'SQL service', 'SS', MakeFlag, FinishedGoodsFlag, SafetyStockLevel, ReorderPoint, StandardCost, ListPrice, DaysToManufacture, SellStartDate, NewID(), ModifiedDate FROM Production.Product

SELECT Scope_identity()


BEGIN TRAN
	SET STATISTICS IO ON;
	SET STATISTICS TIME ON;
	DELETE FROM Production.Product WHERE Product.ProductID=1003
	SET STATISTICS TIME OFF;
	SET STATISTICS IO OFF;
ROLLBACK TRAN


EXEC sys.sp_dropextendedproperty @name=N'MS_Description' , @level0type=N'SCHEMA',@level0name=N'Sales', @level1type=N'TABLE',@level1name=N'SpecialOfferProduct', @level2type=N'INDEX',@level2name=N'IX_SpecialOfferProduct_ProductID'

GO

/****** Object:  Index [IX_SpecialOfferProduct_ProductID]    Script Date: 2015-08-30 20:03:11 ******/
DROP INDEX [IX_SpecialOfferProduct_ProductID] ON [Sales].[SpecialOfferProduct]
GO


BEGIN TRAN
	SET STATISTICS IO ON;
	SET STATISTICS TIME ON;
	DELETE FROM Production.Product WHERE Product.ProductID=1003
	SET STATISTICS TIME OFF;
	SET STATISTICS IO OFF;
ROLLBACK TRAN



/****** Object:  Index [IX_SpecialOfferProduct_ProductID]    Script Date: 2015-08-30 20:03:11 ******/
CREATE NONCLUSTERED INDEX [IX_SpecialOfferProduct_ProductID] ON [Sales].[SpecialOfferProduct]
(
	[ProductID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Nonclustered index.' , @level0type=N'SCHEMA',@level0name=N'Sales', @level1type=N'TABLE',@level1name=N'SpecialOfferProduct', @level2type=N'INDEX',@level2name=N'IX_SpecialOfferProduct_ProductID'
GO


