USE [AdventureWorks2008R2];
GO

SET STATISTICS IO ON;

SELECT
soh.[SalesOrderID],
[sod].[SalesOrderID],
[sod].[SalesOrderDetailID],
[sod].[CarrierTrackingNumber],
[sod].[OrderQty],
[sod].[ProductID],
[sod].[SpecialOfferID]
FROM [Sales].[SalesOrderHeader] AS soh
INNER JOIN [Sales].[SalesOrderDetail] AS sod
ON [soh].[SalesOrderID]=[sod].[SalesOrderID]
WHERE soh.OrderDate='2008-07-31'

DECLARE @orderDate DATE='2008-07-31'

SELECT
soh.[SalesOrderID],
[sod].[SalesOrderID],
[sod].[SalesOrderDetailID],
[sod].[CarrierTrackingNumber],
[sod].[OrderQty],
[sod].[ProductID],
[sod].[SpecialOfferID]
FROM [Sales].[SalesOrderHeader] AS soh
INNER JOIN [Sales].[SalesOrderDetail] AS sod
ON [soh].[SalesOrderID]=[sod].[SalesOrderID]
WHERE soh.[OrderDate]=@orderDate

SET STATISTICS IO OFF;
