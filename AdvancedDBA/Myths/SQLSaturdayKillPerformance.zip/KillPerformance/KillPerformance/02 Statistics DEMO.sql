SELECT @@VERSION
--- Has to be run on SQL2012 or SQL2008R2
USE SQLServiceSommarkollo2013;
GO
SET NOCOUNT ON;
GO

----------------------------------------------------------------------------------------------------------------
-- Disable some traceflags
----------------------------------------------------------------------------------------------------------------
DBCC TRACEOFF(2371, 2389, 2390, -1);
GO
--DBCC TRACEON(2312);
--GO
IF NOT EXISTS (SELECT * FROM sys.[schemas] AS s WHERE name = 'DEMO')
	EXEC sp_executeSQL 'CREATE SCHEMA DEMO';	
GO

IF NOT EXISTS(SELECT * FROM Sys.[sequences] AS s WHERE s.[name] = 'IDGenerator')
	CREATE SEQUENCE DEMO.IDGenerator AS INT START WITH 1 INCREMENT BY 1 NO MAXVALUE CYCLE;
GO

IF EXISTS(SELECT * FROM [INFORMATION_SCHEMA].Tables t WHERE t.[TABLE_SCHEMA]='DEMO' AND [t].[TABLE_NAME]='StatsTest')
	DROP TABLE [DEMO].StatsTest;

CREATE TABLE DEMO.StatsTest
(
    [ID] int NOT NULL DEFAULT NEXT VALUE FOR DEMO.IDGenerator,
    [NAME] CHAR(1000) NOT NULL,
	 IntString INT NULL,
	 DateString Date NULL
);

----------------------------------------------------------------------------------------------------------------
-- Add some data
----------------------------------------------------------------------------------------------------------------
INSERT INTO DEMO.StatsTest ([NAME], IntString, DateString)
SELECT TOP 100000 c.name, x.n, CONVERT(VARCHAR(10),DATEADD(d,x.n,'1900-01-01'),121) FROM sys.[columns] AS c 
CROSS APPLY (SELECT ROW_NUMBER() OVER(ORDER BY GETDATE()) FROM sys.columns) AS x(n);

CREATE CLUSTERED		INDEX ix_StatsTest_ID	ON [DEMO].[StatsTest] ([ID])				WITH(FILLFACTOR=100, SORT_IN_TEMPDB=ON);	-- do not use fill factor 100 in production
CREATE NONCLUSTERED	INDEX ix_StatsTest		ON [DEMO].[StatsTest] ([IntString])		WITH(FILLFACTOR=100, SORT_IN_TEMPDB=ON);			-- do not use fill factor 100 in production
GO

--DBCC TRACEON(2389, 2390, -1);
--GO
DBCC FREEPROCCACHE;
SELECT * FROM Demo.StatsTest WHERE IntString > 700;

----------------------------------------------------------------------------------------------------------------
-- Add some more records, but not more than 20%
----------------------------------------------------------------------------------------------------------------
;WITH cte ([name], n)
AS
(
	SELECT TOP 19000 c.name, ROW_NUMBER() OVER(ORDER BY GETDATE()) FROM sys.[columns] AS c 
	CROSS APPLY sys.columns
)
INSERT INTO DEMO.StatsTest ([NAME], IntString, DateString)
SELECT c.name, c.n, CONVERT(VARCHAR(10),DATEADD(d,c.n,'1900-01-01'),121) FROM cte c;

SET STATISTICS IO ON;
SET STATISTICS TIME ON;

DBCC TRACEOFF(2371,2389, 2390, -1);
GO
DBCC FREEPROCCACHE

SELECT * FROM Demo.StatsTest WHERE IntString > 700;


----------------------------------------------------------------------------------------------------------------
-- enable traceflags for incrementing indexes
----------------------------------------------------------------------------------------------------------------
DBCC TRACEON(2389, 2390, -1);
GO
DBCC TRACEOFF(2312,-1)
DBCC FREEPROCCACHE
DBCC DROPCLEANBUFFERS

SELECT * FROM Demo.StatsTest WHERE IntString > 700 --OPTION(QUERYTRACEON 2389,QUERYTRACEON 2390);

SET STATISTICS TIME OFF;
SET STATISTICS IO OFF;

----------------------------------------------------------------------------------------------------------------
-- update the stats
----------------------------------------------------------------------------------------------------------------
UPDATE STATISTICS [DEMO].[StatsTest];

----------------------------------------------------------------------------------------------------------------
-- try again and take a look at the execution plan
-- and the IO stats
----------------------------------------------------------------------------------------------------------------
DBCC FREEPROCCACHE;

SET STATISTICS IO ON;
SET STATISTICS TIME ON;

SELECT * FROM Demo.StatsTest WHERE IntString > 700;

SET STATISTICS TIME OFF;
SET STATISTICS IO OFF;
