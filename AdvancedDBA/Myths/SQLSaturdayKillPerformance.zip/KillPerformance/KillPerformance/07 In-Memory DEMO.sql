USE InMemDemo
GO

/*
-- create database with a memory-optimized filegroup and a container.
ALTER DATABASE InMemDemo ADD FILEGROUP imoltp_mod CONTAINS MEMORY_OPTIMIZED_DATA 
ALTER DATABASE InMemDemo ADD FILE (name='imoltp_mod1', filename='c:\data\imoltp_mod1') TO FILEGROUP imoltp_mod 
ALTER DATABASE InMemDemo SET MEMORY_OPTIMIZED_ELEVATE_TO_SNAPSHOT=ON
GO
*/
/****** Object:  Table [Sales].[ShoppingCartItem]    Script Date: 2014-05-14 09:13:46 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF EXISTS(SELECT * FROM INFORMATION_SCHEMA.TABLES t WHERE t.TABLE_SCHEMA = 'dbo' AND t.TABLE_NAME='ShoppingCartItemOLTP')
	DROP TABLE [ShoppingCartItemOLTP];
IF EXISTS(SELECT * FROM INFORMATION_SCHEMA.TABLES t WHERE t.TABLE_SCHEMA = 'dbo' AND t.TABLE_NAME='ShoppingCartItem')
	DROP TABLE [ShoppingCartItem];

--------------------------------------------------------------------------------------------
-- disk based table
--------------------------------------------------------------------------------------------
CREATE TABLE dbo.[ShoppingCartItem](
	[ShoppingCartItemID] [int] IDENTITY(1,1) NOT NULL PRIMARY KEY CLUSTERED,
	[ShoppingCartID] [nvarchar](50) NOT NULL,
	[Quantity] [int] NOT NULL,
	[ProductID] [int] NOT NULL
	--adding some nonclustered indexes
	INDEX IX_ShoppingCartID_ProductID NONCLUSTERED ([ShoppingCartID] ASC, [ProductID] ASC) WITH (DATA_COMPRESSION=PAGE) ON [PRIMARY], 
	INDEX IX_ProductID NONCLUSTERED ([ProductID] ASC) WITH (DATA_COMPRESSION=PAGE) ON [PRIMARY] 
) ON [PRIMARY]
GO



--------------------------------------------------------------------------------------------
-- In-Memory based table
--------------------------------------------------------------------------------------------
CREATE TABLE dbo.[ShoppingCartItemOLTP](
	[ShoppingCartItemID] [int] IDENTITY(1,1) NOT NULL PRIMARY KEY NONCLUSTERED HASH WITH(BUCKET_COUNT=1000),
	[ShoppingCartID] [nvarchar](50) COLLATE Latin1_General_100_BIN2 NOT NULL INDEX ixShoppingCart NONCLUSTERED HASH WITH(BUCKET_COUNT=1000),
	[Quantity] [int] NOT NULL,
	[ProductID] [int] NOT NULL,
	--adding some nonclustered indexes
	INDEX IX_ShoppingCartID_ProductID NONCLUSTERED ([ShoppingCartID] ASC, [ProductID] ASC), 
	INDEX IX_ProductID NONCLUSTERED ([ProductID] ASC) 
) WITH (MEMORY_OPTIMIZED=ON) 
GO

SET NOCOUNT ON;
GO

--EXEC msdb.dbo.sp_start_job N'OLTP Demo Workload';

----------------------------------------------
-- create proc for disk based table
----------------------------------------------
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.ROUTINES r WHERE r.ROUTINE_NAME ='spAddToCart' AND r.ROUTINE_SCHEMA = 'dbo')
	DROP PROC dbo.spAddToCart;
GO
CREATE PROCEDURE dbo.spAddToCart @max int
AS
DECLARE @a INT = 0;
DECLARE @startTime DATETIME2 = SYSDATETIME();

WHILE @a < @max
BEGIN
	SET @a +=1;
	INSERT INTO dbo.ShoppingCartItem ([ShoppingCartID], [ProductID], [Quantity]) VALUES(@a,1,0) 
END
SELECT DATEDIFF(mcs,@startTime, SYSDATETIME());
GO


----------------------------------------------
-- create proc for disk based table
----------------------------------------------
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.ROUTINES r WHERE r.ROUTINE_NAME ='spAddToCartOLTP' AND r.ROUTINE_SCHEMA = 'dbo')
	DROP PROC dbo.spAddToCartOLTP;
GO

CREATE PROCEDURE dbo.spAddToCartOLTP @max INT
AS 
BEGIN 
	DECLARE @a INT = 0;
	DECLARE @startTime DATETIME2 = SYSDATETIME();

	WHILE @a < @max
	BEGIN
		SET @a +=1;
		INSERT INTO dbo.ShoppingCartItemOLTP ([ShoppingCartID], [ProductID], [Quantity]) VALUES(@a,1,0) 
	END
	SELECT DATEDIFF(mcs,@startTime, SYSDATETIME());
END
GO

--------------------------------------------------------
-- execute the procedures
--------------------------------------------------------
EXEC dbo.spAddToCart 1000;
EXEC dbo.spAddToCartOLTP 1000;

/*
SELECT * FROM dbo.[ShoppingCartItemSmallOLTP] WHERE [ShoppingCartID]=100;
SELECT * FROM dbo.[ShoppingCartItemSmallOLTP] WHERE [ShoppingCartID]=100 AND ProductID =1;
SELECT * FROM dbo.[ShoppingCartItemSmallOLTP] WHERE ProductID =1;
*/

--------------------------------------------------------
-- remove the records
--------------------------------------------------------
DELETE FROM [ShoppingCartItemOLTP]
DELETE FROM [ShoppingCartItem]

----------------------------------------------
-- create proc for disk based table
----------------------------------------------
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.ROUTINES r WHERE r.ROUTINE_NAME ='spAddToCart' AND r.ROUTINE_SCHEMA = 'dbo')
	DROP PROC dbo.spAddToCart;
GO
CREATE PROCEDURE dbo.spAddToCart @max int
AS
DECLARE @a INT = 0;
DECLARE @startTime DATETIME2 = SYSDATETIME();

WHILE @a < @max
BEGIN
	SET @a +=1;
	INSERT INTO dbo.ShoppingCartItem ([ShoppingCartID], [ProductID], [Quantity]) VALUES(@a,1,0) 
END
SELECT DATEDIFF(mcs,@startTime, SYSDATETIME());
GO

----------------------------------------------
-- create native proc for disk based table
----------------------------------------------
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.ROUTINES r WHERE r.ROUTINE_NAME ='spAddToCartOLTP' AND r.ROUTINE_SCHEMA = 'dbo')
	DROP PROC dbo.spAddToCartOLTP;
GO
CREATE PROCEDURE dbo.spAddToCartOLTP @max INT
WITH NATIVE_COMPILATION, SCHEMABINDING, EXECUTE AS OWNER 
AS 
BEGIN ATOMIC 
WITH (TRANSACTION ISOLATION LEVEL = SNAPSHOT, LANGUAGE = N'us_english', DELAYED_DURABILITY=ON)
DECLARE @a INT = 0;
DECLARE @startTime DATETIME2 = SYSDATETIME();

WHILE @a < @max
BEGIN
	SET @a +=1;
	INSERT INTO dbo.ShoppingCartItemOLTP ([ShoppingCartID], [ProductID], [Quantity]) VALUES(@a,1,0) 
END
SELECT DATEDIFF(mcs,@startTime, SYSDATETIME());
END
GO

-- take a look at the dll in C:\SQL\2012\Data\MSSQL12.SQL2014\MSSQL\DATA\xtp\13

--- execute the procedures with native compiled
EXEC dbo.spAddToCart 1000;
EXEC dbo.spAddToCartOLTP 10000;
GO

EXEC msdb.dbo.sp_stop_job N'OLTP Demo Workload';

DELETE FROM [ShoppingCartItemOLTP]
DELETE FROM [ShoppingCartItem]

DROP PROC dbo.spAddToCartOLTP;
DROP PROC dbo.spAddToCart;

DROP TABLE [ShoppingCartItemOLTP];
DROP TABLE [ShoppingCartItem];


