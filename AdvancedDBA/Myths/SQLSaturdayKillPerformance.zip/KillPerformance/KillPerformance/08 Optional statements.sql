
----------------------------------------------------------------------------------
-- Running total
----------------------------------------------------------------------------------
SET STATISTICS IO ON;
SET STATISTICS TIME ON;
SELECT 
	[frsl].[ResellerKey], 
	OrderDateKey, 
	Total= SUM([frsl].[SalesAmount]) OVER(PARTITION BY [frsl].[ResellerKey] ORDER BY [frsl].[OrderDateKey]) 
INTO #t2 FROM dbo.[FactResellerSalesLarge] AS [frsl]

SELECT 
	[frsl].[ResellerKey], 
	OrderDateKey, 
	Total=SUM([frsl].[SalesAmount]) OVER(PARTITION BY [frsl].[ResellerKey] ORDER BY [frsl].[OrderDateKey] ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) 
INTO #t1 FROM dbo.[FactResellerSalesLarge] AS [frsl]

SET STATISTICS IO OFF;
SET STATISTICS TIME OFF;

DROP TABLE [#t1]
DROP TABLE [#t2]