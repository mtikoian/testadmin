USE [AdventureWorksDW2008R2]
GO

DECLARE @t1 TABLE (ID INT)

INSERT INTO @T1 (id)
SELECT TOP 1000 DateKey FROM DBO.[DimDate] 


CREATE TABLE #T1 (id INT)

INSERT INTO #T1 (id)
SELECT TOP 1000 DateKey FROM DBO.[DimDate] 

SET STATISTICS TIME ON
SET STATISTICS IO ON 
DBCC FREEPROCCACHE

-- If you look at the executionplan, it looks like the table variable is faster, but take a look at estimated no of rows vs actual
-- If you look at the statistics io and time, you'll see that the temptable is faster
-- It all has to do with the statitics
SELECT * FROM DBO.[FactResellerSales] frsl WHERE [frsl].[DueDateKey] IN ( SELECT ID FROM @t1)
DBCC FREEPROCCACHE
SELECT * FROM DBO.[FactResellerSales] frsl WHERE [frsl].[DueDateKey] IN ( SELECT ID FROM #t1)

DBCC FREEPROCCACHE
-- If you look at the executionplan, it looks like the table variable is faster, but take a look at estimated no of rows vs actual
-- If you look at the statistics io and time, you'll see that the temptable is faster
-- It all has to do with the statitics
SELECT * FROM DBO.[FactResellerSales] frsl INNER JOIN @t1 ON [frsl].[OrderDateKey] = [@t1].[ID]
DBCC FREEPROCCACHE
SELECT * FROM DBO.[FactResellerSales] frsl INNER JOIN #t1 ON [frsl].[OrderDateKey] = [#t1].[ID]


SET STATISTICS TIME OFF;
SET STATISTICS IO OFF;

DROP TABLE #T1