SELECT * FROM [AdventureWorksDW2008R2].dbo.[FactResellerSalesLarge] AS [frsl]

