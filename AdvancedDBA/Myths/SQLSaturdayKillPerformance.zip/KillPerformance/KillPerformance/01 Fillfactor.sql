USE SQLServiceSommarkollo2013;
GO
SET NOCOUNT ON;
GO

IF NOT EXISTS (SELECT * FROM sys.[schemas] AS s WHERE name = 'DEMO')
	EXEC sp_executeSQL N'CREATE SCHEMA DEMO';	
GO

IF NOT EXISTS(SELECT * FROM Sys.[sequences] AS s WHERE s.[name] = 'IDGenerator')
	CREATE SEQUENCE DEMO.IDGenerator AS INT START WITH 1 INCREMENT BY 1 NO MAXVALUE CYCLE;
GO

IF EXISTS(SELECT * FROM [INFORMATION_SCHEMA].Tables t WHERE t.[TABLE_SCHEMA]='DEMO' AND [t].[TABLE_NAME]='FillFactorTest')
	DROP TABLE [DEMO].[FillFactorTest];

CREATE TABLE DEMO.FillFactorTest
(
    [ID] int NOT NULL DEFAULT NEXT VALUE FOR DEMO.IDGenerator,
    [NAME] CHAR(1000) NOT NULL
);

----------------------------------------------------------------------------------------------------------------
-- Add some data
----------------------------------------------------------------------------------------------------------------
INSERT INTO DEMO.FillFactorTest ([NAME])
SELECT TOP 8000 c.name FROM sys.[columns] AS c 
CROSS APPLY sys.columns AS c2

----------------------------------------------------------------------------------------------------------------
-- Add a clustered index with fillfactor 100
----------------------------------------------------------------------------------------------------------------
CREATE CLUSTERED INDEX ix_FillFactorTest_ID ON DEMO.FillFactorTest 
(ID) WITH (SORT_IN_TEMPDB=ON,FILLFACTOR = 100, PAD_INDEX=ON, ONLINE=ON) ON [Primary]
GO

CHECKPOINT;
DBCC DROPCLEANBUFFERS WITH NO_INFOMSGS;;

SET STATISTICS IO ON; 
SET STATISTICS TIME ON;

----------------------------------------------------------------------------------------------------------------
-- Get all records from index with 100% Fillfactor
----------------------------------------------------------------------------------------------------------------
SELECT * FROM DEMO.FillFactorTest;

SET STATISTICS TIME OFF; 
SET STATISTICS IO OFF;
GO
----------------------------------------------------------------------------------------------------------------
-- Lets try with a lower fill factor --
----------------------------------------------------------------------------------------------------------------
CREATE CLUSTERED INDEX ix_FillFactorTest_ID ON DEMO.FillFactorTest 
(ID) WITH (SORT_IN_TEMPDB=ON, DROP_EXISTING=ON, FILLFACTOR = 50, PAD_INDEX=ON, ONLINE=ON) ON [Primary]
GO

----------------------------------------------------------------------------------------------------------------
-- Make sure we have clean buffers, do not try this i production
----------------------------------------------------------------------------------------------------------------
CHECKPOINT;
DBCC DROPCLEANBUFFERS WITH NO_INFOMSGS;;

SET STATISTICS IO ON;
SET STATISTICS TIME ON;

----------------------------------------------------------------------------------------------------------------
-- Get all records from index with 50% Fillfactor, pages half full
----------------------------------------------------------------------------------------------------------------
SELECT * FROM DEMO.FillFactorTest;

SET STATISTICS TIME OFF;
SET STATISTICS IO OFF;
GO
----------------------------------------------------------------------------------------------------------------
-- Take a look at the result
-- Almost twice as many pages AND twice the time spent
-- Conclusion? Always use 100% Fillfactor?
----------------------------------------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------------------
-- NO!!!!!
-- Let's try another scenario
----------------------------------------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------------------
-- Lets go back to 100% fill factor --
----------------------------------------------------------------------------------------------------------------
CREATE CLUSTERED INDEX ix_FillFactorTest_ID ON DEMO.FillFactorTest 
(ID) WITH (SORT_IN_TEMPDB=ON, DROP_EXISTING=ON, FILLFACTOR = 100, PAD_INDEX=ON, ONLINE=ON) ON [Primary]
GO

----------------------------------------------------------------------------------------------------------------
-- Update the table
----------------------------------------------------------------------------------------------------------------
RAISERROR('',10,1);
RAISERROR('---------------------------------------',10,1);
RAISERROR('Update the table with fill factor 100%%',10,1);
RAISERROR('---------------------------------------',10,1);
GO

SET STATISTICS TIME ON;

UPDATE [DEMO].[FillFactorTest]
SET ID *= 2;

SET STATISTICS TIME OFF;

----------------------------------------------------------------------------------------------------------------
-- Make sure we have clean buffers, do not try this i production
----------------------------------------------------------------------------------------------------------------
CHECKPOINT;
DBCC DROPCLEANBUFFERS WITH NO_INFOMSGS;;

SET STATISTICS IO ON;
SET STATISTICS TIME ON;

----------------------------------------------------------------------------------------------------------------
-- Get all records from index with 100% Fillfactor
----------------------------------------------------------------------------------------------------------------
SELECT * FROM DEMO.FillFactorTest;

SET STATISTICS TIME OFF;
SET STATISTICS IO OFF;
GO
 
SELECT * FROM sys.[dm_db_index_physical_stats](DB_ID('SQLServiceSommarkollo2013'),OBJECT_ID('DEMO.FillFactorTest'),NULL,0,'DETAILED') AS ddips

----------------------------------------------------------------------------------------------------------------
-- Lets go back to 50% fill factor --
----------------------------------------------------------------------------------------------------------------
CREATE CLUSTERED INDEX ix_FillFactorTest_ID ON DEMO.FillFactorTest 
(ID) WITH (SORT_IN_TEMPDB=ON, DROP_EXISTING=ON, FILLFACTOR = 50, PAD_INDEX=ON, ONLINE=ON) ON [Primary]
GO

----------------------------------------------------------------------------------------------------------------
-- Update the table
----------------------------------------------------------------------------------------------------------------
RAISERROR('',10,1);
RAISERROR('---------------------------------------',10,1);
RAISERROR('Update the table with fill factor 50%%',10,1) WITH NOWAIT;
RAISERROR('---------------------------------------',10,1);
GO


SET STATISTICS TIME ON;

UPDATE [DEMO].[FillFactorTest]
SET ID *= 2;

SET STATISTICS TIME OFF;
GO
----------------------------------------------------------------------------------------------------------------
-- Make sure we have clean buffers, do not try this i production
----------------------------------------------------------------------------------------------------------------
CHECKPOINT;
DBCC DROPCLEANBUFFERS WITH NO_INFOMSGS;

SET STATISTICS IO ON;
SET STATISTICS TIME ON;
GO
----------------------------------------------------------------------------------------------------------------
-- Get all records from index with 50% Fillfactor
----------------------------------------------------------------------------------------------------------------
SELECT * FROM DEMO.FillFactorTest;

SET STATISTICS TIME OFF;
SET STATISTICS IO OFF;
GO

----------------------------------------------------------------------------------------------------------------
-- Conclusion?
-- As you could see, when data is changed (added/updated) you get a lot more pages, why?
----------------------------------------------------------------------------------------------------------------

SELECT * FROM sys.[dm_db_index_physical_stats](DB_ID('SQLServiceSommarkollo2013'),OBJECT_ID('DEMO.FillFactorTest'),NULL,0,'DETAILED') AS ddips