-- Create a test database with 3 filegroups
USE MASTER
GO
IF DATABASEPROPERTYEX ('DemoFilegroups1', 'Version') > 0
	DROP DATABASE DemoFilegroups1;
GO
IF DATABASEPROPERTYEX ('DemoFilegroups2', 'Version') > 0
	DROP DATABASE DemoFilegroups2;
GO

CREATE DATABASE DemoFilegroups1
ON (NAME = DemoFilegroups_Data,
    FILENAME = N'C:\SQLData\DemoFilegroups1_Data.mdf')
LOG ON (NAME = DemoFilegroups_Log,
    FILENAME = N'C:\SQLData\DemoFilegroups1_log.ldf');
GO

ALTER DATABASE DemoFilegroups1
	ADD FILEGROUP DFG_Filegroup1;
GO
ALTER DATABASE DemoFilegroups1
	ADD FILEGROUP DFG_Filegroup2;
GO

ALTER DATABASE DemoFilegroups1
ADD FILE
	(NAME = DFG_TestFile1,
	FILENAME = N'C:\SQLData\DFG1_TestFile1.ndf')
TO FILEGROUP DFG_Filegroup1;
GO
ALTER DATABASE DemoFilegroups1
ADD FILE
	(NAME = DFG_TestFile2,
	FILENAME = N'C:\SQLData\DFG1_TestFile2.ndf')
TO FILEGROUP DFG_Filegroup2;
GO

-- Create another database with 3 filegroups
CREATE DATABASE DemoFilegroups2
ON (NAME = DemoFilegroups_Data,
    FILENAME = N'C:\SQLData\DemoFilegroups2_Data.mdf')
LOG ON (NAME = DemoFilegroups_Log,
    FILENAME = N'C:\SQLData\DemoFilegroups2_log.ldf');
GO

ALTER DATABASE DemoFilegroups2
	ADD FILEGROUP DFG_Filegroup1;
GO
ALTER DATABASE DemoFilegroups2
	ADD FILEGROUP DFG_Filegroup2;
GO

ALTER DATABASE DemoFilegroups2
ADD FILE
	(NAME = DFG_TestFile1,
	FILENAME = N'C:\SQLData\DFG2_TestFile1.ndf')
TO FILEGROUP DFG_Filegroup1;
GO
ALTER DATABASE DemoFilegroups2
ADD FILE
	(NAME = DFG_TestFile2,
	FILENAME = N'C:\SQLData\DFG2_TestFile2.ndf')
TO FILEGROUP DFG_Filegroup2;
GO

-- Check filegroup properties
SELECT
	f.name as [filename],
	fg.name as [fgname]
FROM
	DemoFilegroups1.sys.database_files as f inner join DemoFilegroups1.sys.filegroups 
	as fg on f.data_space_id=fg.data_space_id
GO

SELECT
	f.name as [filename],
	fg.name as [fgname]
FROM
	DemoFilegroups2.sys.database_files as f inner join DemoFilegroups2.sys.filegroups 
	as fg on f.data_space_id=fg.data_space_id
GO

-- Take full database backups
BACKUP DATABASE DemoFilegroups1
TO DISK = N'C:\SQLData\Filegroups1.bak'
WITH INIT;
GO

BACKUP DATABASE DemoFilegroups2
TO DISK = N'C:\SQLData\Filegroups2.bak'
WITH INIT;
GO

-- Now drop both databases
DROP DATABASE DemoFilegroups1;
DROP DATABASE DemoFilegroups2;
GO

-- Partial restore of DemoFilegroups1
RESTORE DATABASE DemoFilegroups1
    FILEGROUP = 'PRIMARY'
FROM DISK = N'C:\SQLData\Filegroups1.bak'
WITH PARTIAL, STATS;
GO

-- Check filegroup status
SELECT
	[name],
	[state_desc]
FROM
	DemoFilegroups1.sys.database_files;
GO

-- Restore another filegroup
RESTORE DATABASE DemoFilegroups1
    FILEGROUP = 'DFG_Filegroup1'
FROM DISK = N'C:\SQLData\Filegroups1.bak'
WITH STATS;
GO

-- Check filegroup status
SELECT
	[name],
	[state_desc]
FROM
	DemoFilegroups1.sys.database_files;
GO

-- Now try one from another database
RESTORE DATABASE DemoFilegroups1
    FILEGROUP = 'DFG_Filegroup2'
FROM DISK = N'C:\SQLData\Filegroups2.bak'
WITH STATS;
GO

-- Now try one from another database
RESTORE DATABASE DemoFilegroups1
    FILEGROUP = 'DFG_Filegroup2'
FROM DISK = N'C:\SQLData\Filegroups1.bak'
WITH STATS;
GO

-- Check filegroup status
SELECT
	[name],
	[state_desc]
FROM
	DemoFilegroups1.sys.database_files;
GO

-- Cleanup 
DROP DATABASE DemoFilegroups1;
GO