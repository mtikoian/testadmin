-- Create a test database to play with
USE master;
GO
IF DATABASEPROPERTYEX ('LogBackupChain', 'Version') > 0
	DROP DATABASE LogBackupChain;
GO
CREATE DATABASE LogBackupChain;
GO
USE LogBackupChain;
GO

-- Create a table and insert 8MB
CREATE TABLE BigTable (
	c1 INT IDENTITY,
	c2 CHAR (8000) DEFAULT 'a');
GO

-- Put the database into the FULL recovery.
ALTER DATABASE LogBackupChain SET RECOVERY FULL;
GO

-- Initial backup
BACKUP DATABASE LogBackupChain TO
	DISK = 'C:\SQLData\LogBackupChain.bak'
	WITH INIT, STATS;
GO

SET NOCOUNT ON;
GO

INSERT INTO BigTable DEFAULT VALUES;
GO 100

-- Log backup
BACKUP LOG LogBackupChain TO
	DISK = 'C:\SQLData\LogBackupChain_Log1.bak'
	WITH INIT, STATS;
GO

-- Now switch to SIMPLE, do some stuff, and switch back
ALTER DATABASE LogBackupChain SET RECOVERY SIMPLE;
GO

INSERT INTO BigTable DEFAULT VALUES;
GO 100

CHECKPOINT;
GO

ALTER DATABASE LogBackupChain SET RECOVERY FULL;
GO

-- Now try a log backup
BACKUP LOG LogBackupChain TO
	DISK = 'C:\SQLData\LogBackupChain_Log2.bak'
	WITH INIT, STATS;
GO

-- Look at recovery status
SELECT * FROM sys.database_recovery_status
WHERE [database_id] = DB_ID ('LogBackupChain');
GO

-- Restart log backup chain
BACKUP DATABASE LogBackupChain TO
	DISK = 'C:\SQLData\LogBackupChain_Diff.bak'
	WITH DIFFERENTIAL, INIT, STATS;
GO

-- Look at recovery status
SELECT * FROM sys.database_recovery_status
WHERE [database_id] = DB_ID ('LogBackupChain');
GO

-- Now try the log backup again
BACKUP LOG LogBackupChain TO
	DISK = 'C:\SQLData\LogBackupChain_Log2.bak'
	WITH INIT, STATS;
GO

-- Part 2: "Large" database
USE master;
GO
IF DATABASEPROPERTYEX ('LogBackupChain', 'Version') > 0
	DROP DATABASE LogBackupChain;
GO
CREATE DATABASE LogBackupChain
 ON  PRIMARY 
( NAME = N'LogBackupChain', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL13.MSSQLSERVER\MSSQL\DATA\LogBackupChain.mdf' , SIZE = 8192KB , FILEGROWTH = 65536KB ), 
 FILEGROUP [Data] 
( NAME = N'LogBackupChain2', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL13.MSSQLSERVER\MSSQL\DATA\LogBackupChain2.ndf' , SIZE = 8192KB , FILEGROWTH = 65536KB ),
( NAME = N'LogBackupChain3', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL13.MSSQLSERVER\MSSQL\DATA\LogBackupChain3.ndf' , SIZE = 8192KB , FILEGROWTH = 65536KB )
 LOG ON 
( NAME = N'LogBackupChain_log', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL13.MSSQLSERVER\MSSQL\DATA\LogBackupChain_log.ldf' , SIZE = 8192KB , FILEGROWTH = 65536KB )
GO
USE LogBackupChain;
GO

-- Create a table and insert 8MB
CREATE TABLE BigTable (
	c1 INT IDENTITY,
	c2 CHAR (8000) DEFAULT 'a');
GO

-- Put the database into the FULL recovery.
ALTER DATABASE LogBackupChain SET RECOVERY FULL;
GO

-- Initial backup
BACKUP DATABASE LogBackupChain TO
	DISK = 'C:\SQLData\LogBackupChain.bak'
	WITH INIT, STATS;
GO

SET NOCOUNT ON;
GO

INSERT INTO BigTable DEFAULT VALUES;
GO 100

-- Log backup
BACKUP LOG LogBackupChain TO
	DISK = 'C:\SQLData\LogBackupChain_Log1.bak'
	WITH INIT, STATS;
GO

-- Now switch to SIMPLE, do some stuff, and switch back
ALTER DATABASE LogBackupChain SET RECOVERY SIMPLE;
GO

INSERT INTO BigTable DEFAULT VALUES;
GO 100

CHECKPOINT;
GO

ALTER DATABASE LogBackupChain SET RECOVERY FULL;
GO

-- Now try a log backup
BACKUP LOG LogBackupChain TO
	DISK = 'C:\SQLData\LogBackupChain_Log2.bak'
	WITH INIT, STATS;
GO

-- Look at recovery status
SELECT * FROM sys.database_recovery_status
WHERE [database_id] = DB_ID ('LogBackupChain');
GO

-- Restart log backup chain
BACKUP DATABASE LogBackupChain FILE = N'LogBackupChain' TO 
DISK = N'C:\SQLData\LogBackupChain_Diff.bak' 
WITH DIFFERENTIAL, INIT, STATS;
GO

-- Look at recovery status
SELECT * FROM sys.database_recovery_status
WHERE [database_id] = DB_ID ('LogBackupChain');
GO

-- Now try the log backup again
BACKUP LOG LogBackupChain TO
	DISK = 'C:\SQLData\LogBackupChain_Log2.bak'
	WITH INIT, STATS;
GO

-- Cleanup
USE master;
GO
IF DATABASEPROPERTYEX ('LogBackupChain', 'Version') > 0
	DROP DATABASE LogBackupChain;
GO