-- Create test database to play with
USE master;
GO
IF DATABASEPROPERTYEX ('NestedTransactions', 'Version') > 0
	DROP DATABASE NestedTransactions;
GO
CREATE DATABASE NestedTransactions;
GO
USE NestedTransactions;
GO
CREATE TABLE Test (
	c1 INT,
	c2 VARCHAR (4000));
GO

-- Outer transaction
BEGIN TRAN
INSERT INTO test VALUES (1, REPLICATE ('Susy', 1000));
INSERT INTO test VALUES (2, REPLICATE ('John', 1000));
GO

SELECT @@TRANCOUNT;
GO

-- Check log usage

-- Start nested transaction
BEGIN TRAN
INSERT INTO test VALUES (3, REPLICATE ('Dave', 1000));
INSERT INTO test VALUES (4, REPLICATE ('Bret', 1000));
GO

SELECT @@TRANCOUNT;
GO

-- Check log usage

-- Commit inner transaction
COMMIT TRAN;
GO

SELECT @@TRANCOUNT;
GO

-- Check log usage and observe if there is any change

-- Commit the outer transaction
COMMIT TRAN;
GO

SELECT @@TRANCOUNT;
GO

-- Check log usage


-- Part 2: Rollback inner transaction
USE master;
GO
IF DATABASEPROPERTYEX ('NestedTransactions', 'Version') > 0
	DROP DATABASE NestedTransactions;
GO
CREATE DATABASE NestedTransactions;
GO
USE NestedTransactions;
GO
CREATE TABLE Test (
	c1 INT,
	c2 VARCHAR (4000));
GO
-- Outer transaction
BEGIN TRAN
INSERT INTO test VALUES (1, REPLICATE ('Susy', 1000));
INSERT INTO test VALUES (2, REPLICATE ('John', 1000));
GO

--Inner transaction
BEGIN TRAN
INSERT INTO test VALUES (3, REPLICATE ('Dave', 1000));
INSERT INTO test VALUES (4, REPLICATE ('Bret', 1000));
GO

--Check the data
SELECT * FROM test

ROLLBACK;

--Check the data again
SELECT * FROM test













-- Part 3: Rollback inner transaction using save point

USE master;
GO
IF DATABASEPROPERTYEX ('NestedTransactions', 'Version') > 0
	DROP DATABASE NestedTransactions;
GO
CREATE DATABASE NestedTransactions;
GO
USE NestedTransactions;
GO
CREATE TABLE Test (
	c1 INT,
	c2 VARCHAR (4000));
GO
-- Outer transaction
BEGIN TRAN
INSERT INTO test VALUES (1, REPLICATE ('Susy', 1000));
INSERT INTO test VALUES (2, REPLICATE ('John', 1000));
GO

-- Check the data
SELECT * FROM test

-- Inner transaction
SAVE TRAN InnerTrn
INSERT INTO test VALUES (3, REPLICATE ('Dave', 1000));
INSERT INTO test VALUES (4, REPLICATE ('Bret', 1000));
GO

-- Check the trancount
SELECT @@TRANCOUNT

-- Check the data
SELECT * FROM test

ROLLBACK TRAN InnerTrn;

-- Check the data
SELECT * FROM test

-- Commit
COMMIT TRAN;

-- Cleanup

USE master;
GO
IF DATABASEPROPERTYEX ('NestedTransactions', 'Version') > 0
	DROP DATABASE NestedTransactions;
GO