-- Overwrite the SalesDB database
USE master
GO
RESTORE DATABASE SalesDB
	FROM DISK = N'C:\SQL Trainer\SalesDBOriginal.bak'
	WITH MOVE N'SalesDBData' TO N'C:\SQLData\SalesDBData.mdf',
	MOVE N'SalesDBLog' TO N'C:\SQLLog\SalesDBLog.ldf',
	REPLACE, STATS = 10;
GO

-- Drop everything from the buffer pool
DBCC DROPCLEANBUFFERS;
GO

-- Create the snapshot
CREATE DATABASE SalesDB_Snapshot
ON (NAME = N'SalesDBData',
	FILENAME = N'C:\SQLData\SalesDBData.mdfss')
AS SNAPSHOT OF SalesDB;
GO

-- Show size on disk of snapshot
SELECT
	vfs.[file_id] AS [File ID],
	mf.[name] AS [Filename],
	vfs.[size_on_disk_bytes] / 1024 AS [Sparse File PHYSICAL Size (KB)]
FROM
	sys.dm_io_virtual_file_stats (NULL, NULL) AS vfs
JOIN
	sys.master_files AS mf
ON
	vfs.[file_id] = mf.[file_id]
WHERE
	mf.[database_id] = vfs.[database_id]
	AND mf.[database_id] = DB_ID ('SalesDB_Snapshot');
GO

-- See the size of the source database 
declare @temp table 
(database_name varchar(100),file_type varchar(5),all_space decimal(12,2),space_used decimal(12,2),space_free decimal(12,2),physical_path varchar(256))
insert into @temp
exec sp_MSforeachdb '
use [?] select DB_NAME() AS DatabaseName,type_desc,CONVERT(decimal(12,2),ROUND(size/128.000,2)),ROUND(fileproperty(name,''SpaceUsed'')/128.000,2),CONVERT(decimal(12,2),ROUND((size-fileproperty(name,''SpaceUsed''))/128.000,2)),physical_name from sys.database_files' 
select database_name,file_type,SUM(all_space) as total_space_mb,SUM(space_used) as space_used_mb,SUM(space_free) as space_free_mb from @temp
where database_name='SalesDB' and file_type='ROWS'
group by database_name,file_type


-- Now let's look at size in memory
SELECT *,
	[DirtyPageCount] * 8 / 1024 AS [DirtyPageMB],
	[CleanPageCount] * 8 / 1024 AS [CleanPageMB]
FROM
	(SELECT 
		(CASE WHEN ([database_id] = 32767)
			THEN 'Resource Database'
			ELSE DB_NAME ([database_id]) END) AS [DatabaseName], 
		SUM (CASE WHEN ([is_modified] = 1)
			THEN 1 ELSE 0 END) AS [DirtyPageCount], 
		SUM (CASE WHEN ([is_modified] = 1)
			THEN 0 ELSE 1 END) AS [CleanPageCount]
	FROM sys.dm_os_buffer_descriptors
	GROUP BY [database_id]) AS buffers
	WHERE [DatabaseName] like 'SalesDB%'
ORDER BY [DatabaseName]
GO 

-- Now some queries
SELECT
	COUNT (*)
FROM
	SalesDB.dbo.Sales;
GO

SELECT
	COUNT (*)
FROM
	SalesDB_Snapshot.dbo.Sales;
GO

-- And check size again
SELECT *,
	[DirtyPageCount] * 8 / 1024 AS [DirtyPageMB],
	[CleanPageCount] * 8 / 1024 AS [CleanPageMB]
FROM
	(SELECT 
		(CASE WHEN ([database_id] = 32767)
			THEN 'Resource Database'
			ELSE DB_NAME ([database_id]) END) AS [DatabaseName], 
		SUM (CASE WHEN ([is_modified] = 1)
			THEN 1 ELSE 0 END) AS [DirtyPageCount], 
		SUM (CASE WHEN ([is_modified] = 1)
			THEN 0 ELSE 1 END) AS [CleanPageCount]
	FROM sys.dm_os_buffer_descriptors
	GROUP BY [database_id]) AS buffers
	WHERE [DatabaseName] like 'SalesDB%'
ORDER BY [DatabaseName]
GO 

-- They are using the same amount of memory although nothing has been changed in the source database

-- Part 2: Compare the pages
USE SalesDB;
GO
DBCC IND (SalesDB, Sales, -1);
GO

-- Pick a random page

DBCC TRACEON (3604);
DBCC PAGE (SalesDB, 1, xx, 3);
GO

-- In other window (for easy comparison)
DBCC TRACEON (3604);
DBCC PAGE (SalesDB_Snapshot, 1, xx, 3);
GO










-- Look at the BUF addresses, PAGE addresses and the data

-- Cleanup
USE master
GO
IF DATABASEPROPERTYEX ('SalesDB_Snapshot', 'Version') > 0
	DROP DATABASE SalesDB_Snapshot;
GO
IF DATABASEPROPERTYEX ('SalesDB', 'Version') > 0
	DROP DATABASE SalesDB;
GO