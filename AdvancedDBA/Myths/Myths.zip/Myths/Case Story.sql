-- Run this agains SQL 2008 R2
SELECT @@VERSION

USE AdventureWorks2008R2;  
GO  
SELECT TOP 10 ProductNumber, Name, "Price Range" =   
      CASE   
         WHEN ListPrice = 0 THEN 'Not for resale'  
         WHEN ListPrice = 0 THEN '0$'  
         WHEN ListPrice > 0 THEN 'expensive'
         ELSE 'Over $1000'  
      END  
FROM Production.Product  
WHERE ListPrice=0
ORDER BY ProductNumber ;  
GO

-- Now this one

DECLARE @i INT = 1;
SELECT CASE WHEN @i = 1 THEN 1 ELSE MIN(1/0) END;


-- Check the connect item
-- Check if it has been fixed in 2016

-- Use SQL 2016
SELECT @@VERSION

USE AdventureWorks2014;  
GO  
SELECT TOP 10 ProductNumber, Name, "Price Range" =   
      CASE   
         WHEN ListPrice = 0 THEN 'Not for resale'  
         WHEN ListPrice = 0 THEN '0$'  
         WHEN ListPrice > 0 THEN 'expensive'
         ELSE 'Over $1000'  
      END  
FROM Production.Product  
WHERE ListPrice=0
ORDER BY ProductNumber ;  
GO

DECLARE @i INT = 1;
SELECT CASE WHEN @i = 1 THEN 1 ELSE MIN(1/0) END;