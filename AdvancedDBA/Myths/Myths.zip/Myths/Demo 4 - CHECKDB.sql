/*
Download the SalesDB database zip file, unzip it and restore it.
Get it from:
https://s3.amazonaws.com/pluralsight-mediasource/sqlskills/SalesDBOriginal.zip
*/

USE master;
GO
-- Make sure we have the SalesDB database
RESTORE DATABASE SalesDB
	FROM DISK = N'C:\SQL Trainer\SalesDBOriginal.bak'
	WITH MOVE N'SalesDBData' TO N'C:\SQLData\SalesDBData.mdf',
	MOVE N'SalesDBLog' TO N'C:\SQLLog\SalesDBLog.ldf',
	REPLACE, STATS = 10;
GO

-- Create a new transaction

-- Flush out the error log
EXEC sp_cycle_errorlog;
GO

-- Run DBCC CHECKDB
DBCC CHECKDB ('SalesDB') WITH NO_INFOMSGS;
GO

-- Examine the error log
EXEC xp_readerrorlog;
GO

-- Finish the transaction script

-- Part 2: Last known good DBCC
CREATE TABLE #temp (
������ Id INT IDENTITY(1,1), 
�������ParentObject VARCHAR(255),
������ [Object] VARCHAR(255),
������ Field VARCHAR(255),
������ [Value] VARCHAR(255)
)
INSERT INTO #temp
EXECUTE SP_MSFOREACHDB'DBCC DBINFO ( ''?'') WITH TABLERESULTS';
;WITH CHECKDB1 AS
(
��� SELECT [Value],ROW_NUMBER() OVER (ORDER BY ID) AS rn1 FROM #temp WHERE Field IN ('dbi_dbname'))
��� ,CHECKDB2 AS ( SELECT [Value], ROW_NUMBER() OVER (ORDER BY ID) AS rn2 FROM #temp WHERE Field IN ('dbi_dbccLastKnownGood')
)����� 
SELECT CHECKDB1.Value AS DatabaseName
������� , CHECKDB2.Value AS LastKnownGoodDBCCCHECKDB
FROM CHECKDB1 JOIN CHECKDB2
ON rn1 =rn2
WHERE CHECKDB1.Value='SalesDB'
DROP TABLE #temp

-- wait 1 min and restart SQL

-- check the error log

-- check the last known good checkdb again
CREATE TABLE #temp (
������ Id INT IDENTITY(1,1), 
�������ParentObject VARCHAR(255),
������ [Object] VARCHAR(255),
������ Field VARCHAR(255),
������ [Value] VARCHAR(255)
)
INSERT INTO #temp
EXECUTE SP_MSFOREACHDB'DBCC DBINFO ( ''?'') WITH TABLERESULTS';
;WITH CHECKDB1 AS
(
��� SELECT [Value],ROW_NUMBER() OVER (ORDER BY ID) AS rn1 FROM #temp WHERE Field IN ('dbi_dbname'))
��� ,CHECKDB2 AS ( SELECT [Value], ROW_NUMBER() OVER (ORDER BY ID) AS rn2 FROM #temp WHERE Field IN ('dbi_dbccLastKnownGood')
)����� 
SELECT CHECKDB1.Value AS DatabaseName
������� , CHECKDB2.Value AS LastKnownGoodDBCCCHECKDB
FROM CHECKDB1 JOIN CHECKDB2
ON rn1 =rn2
WHERE CHECKDB1.Value='SalesDB'
DROP TABLE #temp