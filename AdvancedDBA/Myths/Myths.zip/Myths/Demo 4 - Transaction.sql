-- Create a transaction
BEGIN TRANSACTION;
GO

UPDATE SalesDB.dbo.Sales
SET Quantity = 1
WHERE SalesID < 1000;
GO

-- Execute to here

-- Check that the transaction is still open
SELECT @@TRANCOUNT;

-- Roll it back
ROLLBACK TRANSACTION;
GO