use stackexchange;
go

select sum(reputation) as totalreputation
from dbo.users u
where u.lastaccessdate > cast(dateadd(m,datediff(m,0,getdate()),0) as date)

