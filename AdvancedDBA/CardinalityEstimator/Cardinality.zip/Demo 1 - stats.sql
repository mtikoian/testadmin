USE AdventureWorks2012;
GO

/* CTRL-M is quick key for actual execution plans */

-- drop statistics sales.salesorderdetail._WA_Sys_00000007_44CA3770

DBCC show_statistics ('Sales.SalesOrderDetail',UnitPrice)
GO

-- Note No stats - column not referenced before now.
-- Query table with where on unitprice
SELECT SalesOrderID ,
       SalesOrderDetailID ,
       CarrierTrackingNumber ,
       OrderQty ,
       ProductID ,
       SpecialOfferID ,
       UnitPrice ,
       UnitPriceDiscount ,
       LineTotal ,
       rowguid ,
       ModifiedDate FROM sales.SalesOrderDetail
WHERE unitprice > 1000
GO


-- then Redo check and see stats created automatically
-- View header, density and histogram
DBCC show_statistics ('Sales.SalesOrderDetail',UnitPrice)
GO

/* let's look at another table with easier to interpret numbers */
DBCC SHOW_STATISTICS('Sales.SalesOrderDetail', IX_SalesOrderDetail_ProductID);
-- Review the section for range 826 - 832
GO

/* look a little deeper at the specified sample */
SELECT 
	productID, 
	Count(*) as Total
FROM Sales.SalesOrderDetail
WHERE ProductID BETWEEN 827 and 831
GROUP BY ProductID;
GO



/* Let's look at hte histogram and how selectivity is estimated */

SELECT * FROM Sales.SalesOrderDetail
WHERE ProductID = 831;
GO
 /* Look at the arrow to the final select in the execution plan - not it is a precise value, of the rows in the histogram */

/* Try it now with a different value that was in the range if the step instead */
SELECT * FROM Sales.SalesOrderDetail
WHERE ProductID = 828;
GO
