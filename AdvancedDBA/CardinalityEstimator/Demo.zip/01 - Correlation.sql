
/*
	Put database to 120 compatibility level.
*/
use master

alter database AdventureWorks2012
	set compatibility_level = 120;
go

USE [AdventureWorks2012];
go

if exists (select * from sys.stats as t where t.name = 'S_PersonAddress_StateProvinceID')
	drop statistics Person.Address.S_PersonAddress_StateProvinceID;
go

if exists (select * from sys.indexes as i where i.name = 'IX_PersonAddress_StateProvinceID')
	drop index IX_PersonAddress_StateProvinceID on Person.Address;
go


-- CE 70
SELECT	[AddressID],
	[AddressLine1],
	[AddressLine2]
FROM Person.[Address]
WHERE [StateProvinceID] = 9 AND
      [City] = N'Burbank' AND
      [PostalCode] = N'91502'
OPTION (QUERYTRACEON 9481); -- CardinalityEstimationModelVersion 70
go


-- CE 120
SELECT	[AddressID],
	[AddressLine1],
	[AddressLine2]
FROM Person.[Address]
WHERE [StateProvinceID] = 9 AND
      [City] = N'Burbank' AND
      [PostalCode] = N'91502'
go

create statistics S_PersonAddress_StateProvinceID on Person.Address (PostalCode, City, StateProvinceID);
go

-- CE 70
SELECT	[AddressID],
	[AddressLine1],
	[AddressLine2]
FROM Person.[Address]
WHERE [StateProvinceID] = 9 AND
      [City] = N'Burbank' AND
      [PostalCode] = N'91502'
OPTION (QUERYTRACEON 9481); -- CardinalityEstimationModelVersion 70
GO


-- CE 120
SELECT	[AddressID],
	[AddressLine1],
	[AddressLine2]
FROM Person.[Address]
WHERE [StateProvinceID] = 9 AND
      [City] = N'Burbank' AND
      [PostalCode] = N'91502'
go

if exists (select * from sys.stats as t where t.name = 'S_PersonAddress_StateProvinceID')
	drop statistics Person.Address.S_PersonAddress_StateProvinceID;
go

create nonclustered index IX_PersonAddress_StateProvinceID on Person.Address (PostalCode, City, StateProvinceID);
go

-- CE 70
SELECT	[AddressID],
	[AddressLine1],
	[AddressLine2]
FROM Person.[Address]
WHERE [StateProvinceID] = 9 AND
      [City] = N'Burbank' AND
      [PostalCode] = N'91502'
OPTION (QUERYTRACEON 9481); -- CardinalityEstimationModelVersion 70
GO


-- CE 120
SELECT	[AddressID],
	[AddressLine1],
	[AddressLine2]
FROM Person.[Address]
WHERE [StateProvinceID] = 9 AND
      [City] = N'Burbank' AND
      [PostalCode] = N'91502'
go