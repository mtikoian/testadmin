use [AdventureWorksDW2012];
go

/*
	CE 70
*/
select
		f.ProductKey
		, d.DayNumberOfYear
from	dbo.FactInternetSales as f
		inner join dbo.DimDate as d on f.OrderDateKey = d.DateKey
where	f.SalesTerritoryKey = 8
group by
		f.ProductKey
		, d.DayNumberOfYear;

/*
	CE 120
*/
select
		f.ProductKey
		, d.DayNumberOfYear
from	dbo.FactInternetSales as f
		inner join dbo.DimDate as d on f.OrderDateKey = d.DateKey
where	f.SalesTerritoryKey = 8
group by
		f.ProductKey
		, d.DayNumberOfYear
option ( QUERYTRACEON 2312 );

/*
	CE 70 - many to many
*/
SELECT [f].[ProductKey], [d].[DayNumberOfYear]
FROM    dbo.[FactInternetSales] AS [f]
INNER JOIN dbo.[DimDate] AS [d] 
	ON [f].[OrderDateKey] = [d].[DateKey]
INNER JOIN dbo.[FactProductInventory] AS fi
       ON  [fi].[DateKey] = [d].[DateKey]
WHERE [f].[SalesTerritoryKey] = 8
GROUP BY [f].[ProductKey], [d].[DayNumberOfYear];


/*
	CE120 - many to many
*/
SELECT [f].[ProductKey], [d].[DayNumberOfYear]
FROM    dbo.[FactInternetSales] AS [f]
INNER JOIN dbo.[DimDate] AS [d] 
	ON [f].[OrderDateKey] = [d].[DateKey]
INNER JOIN dbo.[FactProductInventory] AS fi
       ON  [fi].[DateKey] = [d].[DateKey]
WHERE [f].[SalesTerritoryKey] = 8
GROUP BY [f].[ProductKey], [d].[DayNumberOfYear]
option ( QUERYTRACEON 2312 );
