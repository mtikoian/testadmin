-----------------------------------------------------------------
-- Course: Cardinality Estimator 2016
-- Setup: Demo Database Setup for AdventureWorks2012 Sample Database
-----------------------------------------------------------------
 
-- Restore as follows:
USE [master];
GO

IF DATABASEPROPERTYEX (N'AdventureWorksDW2012', N'Version') > 0
BEGIN
	ALTER DATABASE AdventureWorksDW2012 
		SET SINGLE_USER
		WITH ROLLBACK IMMEDIATE;
	DROP DATABASE AdventureWorksDW2012;
END;
GO

RESTORE DATABASE AdventureWorksDW2012
FROM DISK = N'D:\Backup\AdventureWorksDW2012.bak'
WITH
    MOVE N'AdventureWorksDW2012_Data'
		TO N'C:\Program Files\Microsoft SQL Server\MSSQL14.SQL2017\MSSQL\DATA\AdventureWorksDW2012_Data.mdf',
	MOVE N'AdventureWorksDW2012_Log' 
		TO N'C:\Program Files\Microsoft SQL Server\MSSQL14.SQL2017\MSSQL\DATA\AdventureWorksDW2012_log.ldf';
GO

----------------------------------
-- DATABASE: Required Configuration
----------------------------------

ALTER DATABASE AdventureWorksDW2012
	SET PARAMETERIZATION SIMPLE;
GO

USE AdventureWorksDW2012;
GO