
USE [AdventureWorks2012];
GO

/*
	Create auto statistic on OrderDate.
*/
SELECT [SalesOrderID], [OrderDate] 
FROM Sales.[SalesOrderHeader]
WHERE [OrderDate] = '2005-07-01 00:00:00.000';

SELECT  [s].[object_id],
        [s].[name],
        [s].[auto_created]
FROM    sys.[stats] AS s
INNER JOIN sys.[stats_columns] AS [sc]
        ON [s].[stats_id] = [sc].[stats_id] AND
           [s].[object_id] = [sc].[object_id]
WHERE   [s].[object_id] = OBJECT_ID('Sales.SalesOrderHeader') AND
	    COL_NAME([s].[object_id], [sc].[column_id]) = 'OrderDate';

DBCC SHOW_STATISTICS('Sales.SalesOrderHeader', _WA_Sys_00000003_4B7734FF);

INSERT  INTO Sales.[SalesOrderHeader] ( [RevisionNumber], [OrderDate],
                                          [DueDate], [ShipDate], [Status],
                                          [OnlineOrderFlag],
                                          [PurchaseOrderNumber],
                                          [AccountNumber], [CustomerID],
                                          [SalesPersonID], [TerritoryID],
                                          [BillToAddressID], [ShipToAddressID],
                                          [ShipMethodID], [CreditCardID],
                                          [CreditCardApprovalCode],
                                          [CurrencyRateID], [SubTotal],
                                          [TaxAmt], [Freight], [Comment] )
VALUES  ( 3, '2014-02-02 00:00:00.000', '5/1/2014', '4/1/2014', 5, 0, 'SO43659', 'PO522145787',29825, 279, 5, 985, 985, 5, 21, 'Vi84182', NULL, 250.00,
25.00, 10.00, '' );
GO 50 -- INSERT 50 rows, representing very recent data, with a current OrderDate value

-- CE 70
SELECT [SalesOrderID], [OrderDate] 
FROM Sales.[SalesOrderHeader]
WHERE [OrderDate] = '2014-02-02 00:00:00.000'
OPTION (QUERYTRACEON 9481);  -- CardinalityEstimationModelVersion 70

-- CE 120
SELECT [SalesOrderID], [OrderDate] 
FROM Sales.[SalesOrderHeader]
WHERE [OrderDate] = '2014-02-02 00:00:00.000'
