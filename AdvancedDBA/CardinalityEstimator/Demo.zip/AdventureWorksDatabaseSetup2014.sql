-----------------------------------------------------------------
-- Course: Cardinality Estimator 2016
-- Setup: Demo Database Setup for AdventureWorks2012 Sample Database
-----------------------------------------------------------------
 
-- Restore as follows:
USE [master];
GO

IF DATABASEPROPERTYEX (N'AdventureWorks2012', N'Version') > 0
BEGIN
	ALTER DATABASE AdventureWorks2012 
		SET SINGLE_USER
		WITH ROLLBACK IMMEDIATE;
	DROP DATABASE AdventureWorks2012;
END;
GO

RESTORE DATABASE AdventureWorks2012
FROM DISK = N'D:\Backup\AdventureWorks2012.bak'
WITH
    MOVE N'AdventureWorks2012_Data'
		TO N'C:\Program Files\Microsoft SQL Server\MSSQL14.SQL2017\MSSQL\DATA\AdventureWorks2012_Data.mdf',
	MOVE N'AdventureWorks2012_Log' 
		TO N'C:\Program Files\Microsoft SQL Server\MSSQL14.SQL2017\MSSQL\DATA\AdventureWorks2012_log.ldf';
GO

----------------------------------
-- DATABASE: Required Configuration
----------------------------------

ALTER DATABASE AdventureWorks2012
	SET PARAMETERIZATION SIMPLE;
GO

USE AdventureWorks2012;
GO