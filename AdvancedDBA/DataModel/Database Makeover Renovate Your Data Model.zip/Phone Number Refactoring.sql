SELECT * 
INTO dbo.CustomerBackup
FROM dbo.Customer

--CREATE TABLES
--DROP TABLE dbo.PhoneType
--GO 

CREATE TABLE dbo.PhoneType
	(
	PhoneTypeKey int IDENTITY(1,1) NOT NULL, 
	PhoneTypeName varchar(20) NOT NULL, 
		CONSTRAINT PK_PhoneType PRIMARY KEY (PhoneTypeKey)
	); 
GO

--DROP TABLE dbo.CustomerPhone
--GO

CREATE TABLE dbo.CustomerPhone
	(
	CustomerPhoneKey int IDENTITY(1,1) NOT NULL, 
	CustomerKey int NOT NULL, 
	PhoneTypeKey int NOT NULL, 
	PhoneNumber varchar(20) NOT NULL, 
	PhoneExtension varchar(10) NULL, 
	ActiveFlag bit NOT NULL, 
		CONSTRAINT PK_CustomerPhoneKey PRIMARY KEY (CustomerPhoneKey)
	); 
GO

--CREATE CONSTRAINTS
ALTER TABLE dbo.CustomerPhone
	ADD CONSTRAINT FK_CustomerPhone_CustomerKey
		FOREIGN KEY(CustomerKey) REFERENCES dbo.Customer(CustomerKey); 
GO

ALTER TABLE dbo.CustomerPhone
	ADD CONSTRAINT FK_CustomerPhone_PhoneTypeKey 
		FOREIGN KEY (PhoneTypeKey) REFERENCES dbo.PhoneType(PhoneTypeKey); 
GO

ALTER TABLE dbo.CustomerPhone
	ADD CONSTRAINT DF_CustomerPhone_ActiveFlag
		DEFAULT(0) FOR ActiveFlag; 
GO

--POPULATE LOOKUP TABLE 
INSERT INTO dbo.PhoneType(PhoneTypeName)
VALUES
	('Home'), 
	('Work'), 
	('Cell'), 
	('Skype'); 

SELECT * FROM dbo.PhoneType

--MIGRATE PHONE NUMBERS
--Home Phone
INSERT INTO dbo.CustomerPhone(CustomerKey, PhoneTypeKey, PhoneNumber, ActiveFlag, PhoneExtension)
SELECT CustomerKey, (SELECT PhoneTypeKey FROM dbo.PhoneType WHERE PhoneTypeName = 'Home') as PhoneTypeKey, 
	HomePhone, 1 as ActiveFlag, 
	CASE WHEN HomePhone like '%x%' THEN SUBSTRING(HomePhone, CHARINDEX('x', HomePhone, 1)+1, 5) ELSE NULL END as PhoneExtension
FROM dbo.Customer 
WHERE HomePhone IS NOT NULL; 

--Work Phone
INSERT INTO dbo.CustomerPhone(CustomerKey, PhoneTypeKey, PhoneNumber, ActiveFlag, PhoneExtension)
SELECT CustomerKey, (SELECT PhoneTypeKey FROM dbo.PhoneType WHERE PhoneTypeName = 'Work') as PhoneTypeKey, 
	LEFT(WorkPhone, 12) as WorkPhone, 1 as ActiveFlag, 
	CASE WHEN WorkPhone like '%x%' THEN SUBSTRING(WorkPhone, CHARINDEX('x', WorkPhone, 1)+1, 5) ELSE NULL END as PhoneExtension
FROM dbo.Customer 
WHERE WorkPhone IS NOT NULL; 

--Cell Phone
INSERT INTO dbo.CustomerPhone(CustomerKey, PhoneTypeKey, PhoneNumber, ActiveFlag, PhoneExtension)
SELECT CustomerKey, (SELECT PhoneTypeKey FROM dbo.PhoneType WHERE PhoneTypeName = 'Cell') as PhoneTypeKey, 
	CellPhone, 1 as ActiveFlag, 
	CASE WHEN CellPhone like '%x%' THEN SUBSTRING(CellPhone, CHARINDEX('x', CellPhone, 1)+1, 5) ELSE NULL END as PhoneExtension
FROM dbo.Customer 
WHERE CellPhone IS NOT NULL; 

SELECT * 
FROM dbo.CustomerPhone
ORDER BY CustomerKey DESC
GO

--CREATE VIEW 
CREATE VIEW dbo.vwCustomer 
AS
SELECT c.CustomerKey, c.FirstName, c.MiddleName, c.LastName, c.CustomerStatus, c.StreetAddress1, c.StreetAddress2, c.City, c.State, 
	c.ZipCode, CASE WHEN hp.PhoneExtension IS NULL THEN hp.PhoneNumber ELSE hp.PhoneNumber+' x'+hp.PhoneExtension END as HomePhone, 
	CASE WHEN cp.PhoneExtension IS NULL THEN cp.PhoneNumber ELSE cp.PhoneNumber+' x'+cp.PhoneExtension END as CellPhone, 
	CASE WHEN wp.PhoneExtension IS NULL THEN wp.PhoneNumber ELSE wp.PhoneNumber+' x'+wp.PhoneExtension END as WorkPhone, 
	c.EmailAddress, c.StartDate, c.CustomerNumber, c.FirstOrderDate, c.MostRecentOrderDate
FROM dbo.Customer	c
	LEFT JOIN dbo.CustomerPhone hp
		ON c.CustomerKey = hp.CustomerKey
			AND hp.PhoneTypeKey = (SELECT PhoneTypeKey FROM dbo.PhoneType WHERE PhoneTypeName = 'Home')
	LEFT JOIN dbo.CustomerPhone cp
		ON c.CustomerKey = cp.CustomerKey
			AND cp.PhoneTypeKey = (SELECT PhoneTypeKey FROM dbo.PhoneType WHERE PhoneTypeName = 'Cell')
	LEFT JOIN dbo.CustomerPhone wp
		ON c.CustomerKey = wp.CustomerKey
			AND wp.PhoneTypeKey = (SELECT PhoneTypeKey FROM dbo.PhoneType WHERE PhoneTypeName = 'Work')


SELECT * 
FROM dbo.vwCustomer

--Verify View
SELECT c.CustomerKey, c.HomePhone, v.HomePhone, c.CellPhone, v.CellPhone, c.WorkPhone, v.WorkPhone
FROM dbo.Customer c
	JOIN dbo.vwCustomer v
		ON c.CustomerKey = v.CustomerKey
WHERE c.HomePhone <> v.HomePhone
	OR c.CellPhone <> v.CellPhone
	OR c.WorkPhone <> v.WorkPhone

--DROP COLUMNS
ALTER TABLE dbo.Customer
	DROP COLUMN HomePhone

ALTER TABLE dbo.Customer
	DROP COLUMN CellPhone

ALTER TABLE dbo.Customer
	DROP COLUMN WorkPhone
