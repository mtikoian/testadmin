--Data Types
SELECT LastName, State, ZipCode, StartDate
FROM dbo.Customer

SELECT LastName, State, 
 CASE LEN(ZipCode) WHEN 4 THEN '0'+cast(ZipCode as varchar(5))
  ELSE ZipCode
 END as ZipCode, 
 CAST(StartDate as date) as StartDate
FROM dbo.Customer

--Different Answers
SELECT DISTINCT c.FirstName, c.LastName, co.CustomerFirstName, co.CustomerLastName
FROM dbo.Customer c
	JOIN dbo.CustomerOrder co
		ON c.CustomerKey = co.CustomerKey
WHERE c.LastName in ('Stanton IV', 'Monroe', 'Elmer', 'Grayson', 'Paterson')

--Atomic Attributes
SELECT CustomerNumber, CASE WHEN (substring(CustomerNumber, 1,1) = 'P') THEN 'Premium' ELSE 'Standard' END as CustomerType, 
 RIGHT(CustomerNumber, 6) as CustomerIdentifier
FROM dbo.Customer

--Lookup Tables
SELECT State, CustomerStatus
FROM dbo.Customer
ORDER BY State

--Calculated Data
SELECT c.CustomerKey as [Key], cast(FirstOrderDate as date) as FirstOrder, cast(MostRecentOrderDate as date) as MostRecentOrder, OrderDate
FROM dbo.Customer c
	JOIN dbo.CustomerOrder co
		ON c.CustomerKey = co.CustomerKey
WHERE c.CustomerKey in (1,5, 9)
ORDER BY c.CustomerKey, OrderDate

--Orphaned Row
SELECT c.CustomerKey, co.CustomerKey, co.CustomerLastname as LastName, co.OrderNumber
FROM dbo.CustomerOrder co
	LEFT JOIN dbo.Customer c
		ON co.CustomerKey = c.CustomerKey
WHERE co.CustomerLastName = 'Monroe'