DELETE CUSTOMER

--Populate Customer
INSERT INTO dbo.Customer(FirstName, MiddleName, LastName, CustomerStatus, StreetAddress1, StreetAddress2, 
City, State, ZipCode, HomePhone, CellPhone, WorkPhone, EmailAddress, StartDate, CustomerNumber, FirstOrderDate, MostRecentOrderDate)
VALUES
	('Richard', NULL, 'Bassett', 'Active', '1 Delaware Way', NULL, 'Dover', 'DE', 19901, '302-643-2341', '302-342-8812', NULL, 'RichardBasset@Dover.com', 
	 '2009-12-03', '004AX1', '2009-12-03', '2011-05-16'), 
	('Pierce', NULL, 'Butler', 'Active', '67 Palmetto Street', 'Suite 100', 'Charlestown', 'SC', 29401, '843-991-8133', NULL, NULL, 'PierceButler@Palmetto.net', 
	 '2008-09-30', 'P0088B2', '2008-09-30', '2010-10-21'), 
	('Charles', NULL, 'Carroll', 'Active', '8871 Terrapin Road', NULL, 'Annapolis', 'MD', 21401, NULL, '410-881-8767', NULL, 'ccarroll@crabcakes.com', 
	 '2009-04-01', '00567C', '2009-04-01', '2011-07-06'), 
	('Tristram', NULL, 'Dalton', 'Inactive', '992 Fenway Drive', 'Apt 413', 'Boston', 'MA', 02101, NULL, '617-321-8825', NULL, 'TristramD@BoSox.com', 
	 '2008-05-15', '00431X', '2008-05-15', '2011-08-31'), 
	('Oliver', NULL, 'Ellsworth', 'A', '901 Hartford Street', NULL, 'New Haven', 'CT', 06501, NULL, '203-882-8771', NULL, 'OliverEllsworth@JointCapitals.com', 
	 '2007-04-28', '00886T', '2007-04-28', '2007-04-28'), 
	('Jonathan', NULL, 'Elmer', 'Active', '1340 Burlington Way', 'Bldg 10', 'Perth Amboy', 'NJ', 08861, '732-442-0921', NULL, NULL, 'Jonathan.Elmer@Turnpike.net', 
	 '2011-05-14', 'P003219', '2011-05-14', '2011-09-16'), 
	('William', NULL, 'Few', 'Active', '9 Peachtree Street', NULL, 'Augusta', 'GA', 30901, '706-755-3421', '706-123-2342', NULL, 'WilliamFew@Braves.net', 
	 '2008-07-14', '00982B', '2008-07-14', '2011-01-18'), 
	('William', NULL, 'Grayson', 'Inactive', '7 Williamsburg Court', 'Suite 120', 'Richmond', 'VA', 23173, NULL, '804-431-8772', '804-339-8832', 'BillGrayson@uva.edu', 
	 '2010-03-15', '00984G', '2010-03-15', '2011-02-21'), 
	('James', NULL, 'Gunn', 'I', '8821 Masters Lane', NULL, 'Augusta', 'GA', 30901, NULL, NULL, '706-234-8811', 'Gunn.James@chattahoochee.com', 
	 '2007-10-11', 'P00439X', '2007-10-11', '2011-07-10'), 
	('John', NULL, 'Henry', 'Active', 'One Maryland Court', NULL, 'Annapolis', 'MD', 21401, NULL, NULL, NULL, 'JohnHenry@crabcakes.com', 
	 '2011-08-01', '00866B', '2011-08-01', '2011-08-01'), 
	('Ralph', NULL, 'Izard', 'Active', '8972 Crepe Myrtle Street', 'Apt. B', 'Charleston', 'SC', 29401, NULL, '843-324-9823', NULL, 'IzardRalph@Palmetto.net', 
	 '2009-12-08', 'P01887B', '2009-12-08', '2011-09-14'), 
	('William', 'Samuel', 'Johnson', 'Active', '341 Fort Amsterdam Road', NULL, 'New Haven', 'CT', 06501, NULL, NULL, '203-522-1343 x7', 'WSJohnson@JointCapitals.com', 
	 '2009-02-23', '00422C', '2009-02-23', '2011-04-17'), 
	('John', NULL, 'Langdon', 'Inactive', '990 Concord Drive', 'Suite 5552', 'Exeter', 'NH', 03833, NULL, '603-313-9876', NULL, 'John.Langdon@LiveFreeOrDie.com', 
	 '2010-06-03', '00976C', '2010-06-03', '2011-08-15'), 
	('Richard', 'Henry', 'Lee', 'A', '7 Jamestown Ct', NULL, 'Richmond', 'VA', 23173, '804-931-9881', NULL, NULL, 'RichardHenryLee@Commonwealth.net', 
	 '2007-12-04', 'P00976A', '2007-12-04', '2011-03-28'), 
	('William', NULL, 'Maclay', 'Active', '67 Harrisburg Lane', 'Building 12', 'Philadelphia', 'PA', 19019, '215-910-2342', '215-642-8814', '215-902-9914 x6', 'WmMaclay@LibertyBell.com', 
	 '2011-05-01', '00982X', '2011-05-01', '2011-09-09'), 
	('Robert', NULL, 'Morris', 'Inactive', '9341 Lancaster St.', 'Apartment 813', 'Philadelphia', 'PA', 19019, NULL, '215-452-2382', NULL, 'RobertMorris@LibertyBell.com', 
	 '2009-07-09', '00245C', '2009-07-09', '2007-07-09'), 
	('William', NULL, 'Paterson', 'Active', '2534 New Haven Court', NULL, 'Perth Amboy', 'NJ', 08861, NULL, NULL, NULL, NULL, 
	 '2010-08-12', '00236X', '2010-08-12', '2010-09-01'), 
	('George', NULL, 'Read', 'Inactive', '1532 Blue Hen Walk', NULL, 'Dover', 'Del', 19901, NULL, '302-012-2532', '302-821-4225', 'GeorgeRead@HorseshoeCrab.net', 
	 '2011-06-12', '00363C', '2011-06-12', '2011-07-29'), 
	('Philip', NULL, 'Schuyler', 'Active', '34525 Madison Avenue', NULL, 'New York', 'NY', 10001, '212-225-2542', NULL, NULL, 'Schuyler.Philip@Albany.net', 
	 '2008-02-11', '00225X', '2008-02-11', '2010-08-23'), 
	('Caleb', NULL, 'Strong', 'Inactive', '8321 Plimouth Road', NULL, 'Boston', 'Mass', 02101, NULL, NULL, NULL, 'Caleb.Strong@BoSox.com', 
	 '2009-07-28', '00423X', '2009-07-28', '2011-01-30'), 
	('Paine', NULL, 'Wingate', 'Active', '1122C Portsmouth Way', NULL, 'Exeter', 'NH', 03833, '603-215-2321', NULL, NULL, NULL, 
	 '2010-04-30', '00234B', '2010-04-30', '2011-01-25'), 
	('Rufus', NULL, 'King', 'Active', '252 Fifth Avenue', NULL, 'New York', 'NY', 10001, NULL, '212-241-5324', NULL, 'RKing@Albany.net', 
	 '2011-02-19', '00341C', '2011-02-19', '2011-09-12'), 
	('Benjamin', NULL, 'Hawkins', 'Active', '3542 Raleigh Road', NULL, 'Fayetteville', 'NC', 28301, '910-431-5213', NULL, NULL, 'BenHawkins@NewBern.com', 
	 '2010-04-23', '00467B', '2010-04-23', '2011-02-28'), 
	('Samuel', NULL, 'Johnston', 'Active', '432 Outer Banks Court', 'Suite C', 'Fayetteville', 'NC', 28301, NULL, NULL, NULL, 'SamuelJohnston@NewBern.com', 
	 '2011-03-30', '00886X', '2011-03-30', '2011-03-30'), 
	('John', NULL, 'Walker', 'Inactive', '9826 Roanoke Blvd', NULL, 'Richmond', 'VA', 23173, NULL, '804-342-2522', NULL, 'JohnWalker@Commonwealth.net', 
	 '2010-06-09', '00812B', '2010-06-09', '2011-02-19'), 
	('Theodore', NULL, 'Foster', 'Active', '6326 Newport Rd', 'Suite 13C', 'Providence', 'RI', 02906, '401-311-5322', '401-532-5691', NULL, 'TheoFoster@SouthKingstown.net', 
	 '2008-08-12', 'P00742A', '2008-08-12', '2011-04-21'), 
	('Joseph', NULL, 'Stanton IV', 'Active', '98 Bristol Court', NULL, 'Providence', 'RI', 02906, NULL, NULL, '401-242-0882 x9', 'JStanton@SouthKingstown.net', 
	 '2011-01-30', '00726C', '2011-01-30', '2011-01-30'), 
	('James', NULL, 'Monroe', 'Active', '521 Monticello Drive', NULL, 'Richmond', 'VA', 23173, NULL, NULL, NULL, 'JamesMonroe@Commonwealth.net', 
	 '2010-05-25', '00626X', '2010-05-25', '2010-09-30'), 
	('Philemon', NULL, 'Dickinson', 'Inactive', '3621 Trenton Street', NULL, 'Perth Amboy', 'NJ', 08861, '732-453-7014', '732-256-2411', NULL, 'Philemon@Turnpike.net', 
	 '2009-04-12', '00670C', '2009-04-12', '2011-03-31'); 

SELECT * 
FROM dbo.Customer

--First Order
INSERT INTO dbo.CustomerOrder(CustomerKey, OrderDate, OrderNumber, CustomerFirstName, CustomerLastName, ShipToName, ShippingAddress1, ShippingAddress2, 
 ShippingCity, ShippingState, ShippingZip, BillToName, BillToAddress1, BillToAddress2, BillToCity, BillToState, BillToZip)
SELECT CustomerKey, FirstOrderDate, cast(RAND(CustomerKey)*ZipCode as int) as OrderNumber, FirstName, LastName, FirstName +' '+LastName, 
	StreetAddress1, StreetAddress2, City, State, ZipCode, FirstName +' '+LastName, StreetAddress1, StreetAddress2, City, State, ZipCode
FROM dbo.Customer

--Last Order
INSERT INTO dbo.CustomerOrder(CustomerKey, OrderDate, OrderNumber, CustomerFirstName, CustomerLastName, ShipToName, ShippingAddress1, ShippingAddress2, 
 ShippingCity, ShippingState, ShippingZip, BillToName, BillToAddress1, BillToAddress2, BillToCity, BillToState, BillToZip)
SELECT CustomerKey, MostRecentOrderDate, cast(RAND(CustomerKey)*ZipCode*2 as int) as OrderNumber, FirstName, LastName, FirstName +' '+LastName, 
	StreetAddress1, StreetAddress2, City, State, ZipCode, FirstName +' '+LastName, StreetAddress1, StreetAddress2, City, State, ZipCode
FROM dbo.Customer
WHERE FirstOrderDate <> MostRecentOrderDate

--Intermediate Order
INSERT INTO dbo.CustomerOrder(CustomerKey, OrderDate, OrderNumber, CustomerFirstName, CustomerLastName, ShipToName, ShippingAddress1, ShippingAddress2, 
 ShippingCity, ShippingState, ShippingZip, BillToName, BillToAddress1, BillToAddress2, BillToCity, BillToState, BillToZip)
SELECT CustomerKey, DATEADD(mm, -4, MostRecentOrderDate), cast(RAND(CustomerKey)*ZipCode*3 as int) as OrderNumber, FirstName, LastName, FirstName +' '+LastName, 
	StreetAddress1, StreetAddress2, City, State, ZipCode, FirstName +' '+LastName, StreetAddress1, StreetAddress2, City, State, ZipCode
FROM dbo.Customer
WHERE FirstOrderDate <> MostRecentOrderDate

UPDATE dbo.CustomerOrder
SET BillToZip = '0'+BillToZip 
WHERE len(billtozip) = 4

UPDATE dbo.CustomerOrder
SET ShippingZip = '0'+ShippingZip 
WHERE len(ShippingZip) = 4

UPDATE dbo.CustomerOrder
SET ShippingState = 'MA'
WHERE ShippingState = 'Mass'

UPDATE dbo.CustomerOrder
SET BillToState = 'MA'
WHERE BillToState = 'Mass'

SELECT  *
FROM dbo.CustomerOrder

UPDATE CustomerOrder
SET CustomerFirstName = 'John'
WHERE CustomerKey = 351

UPDATE CustomerOrder
SET CustomerFirstName = 'Bill'
WHERE CustomerKey = 353

UPDATE CustomerOrder
SET CustomerLastName = 'Peterson'
WHERE CustomerKey = 362

UPDATE CustomerOrder 
SET CustomerLastName = 'Stanton' 
WHERE CustomerKey = 372

SELECT * 
FROM dbo.CustomerOrder
WHERE CustomerKey in (351, 353, 362, 372, 373)

--Order Detail
--First Item
INSERT INTO dbo.OrderDetail(CustomerKey, OrderNumber, ItemNumber, Quantity)
SELECT c.CustomerKey, co.OrderNumber, 
 substring(substring(co.BillToZip, 2,2)+Substring(cast(c.CustomerKey as varchar(20)), 2,1)+cast(co.OrderID*2 as varchar(20)), 1, 3) as ItemNumber, 
 CASE cast(substring(co.BillToZip, 2,1) as int) WHEN 0 THEN 1 ELSE cast(substring(co.BillToZip, 2,1) as int) END as Quantity
FROM dbo.Customer c
	JOIN dbo.CustomerOrder co
		On c.CustomerKey = co.CustomerKey


UPDATE dbo.OrderDetail
SET UnitPrice = cast(SQRT(Quantity)*1.3 as numeric(5,2))

SET IDENTITY_INSERT dbo.OrderDetail ON

INSERT INTO dbo.OrderDetail(OrderDetailID, CustomerKey, OrderNumber, ItemNumber, Quantity)
SELECT 4, CustomerKey, OrderNumber, ItemNumber, Quantity
FROM dbo.OrderDetail 
WHERE OrderDetailID = 2

UPDATE OrderDetail 
SET UnitPrice = 2.45 
WHERE UnitPrice IS NULL

SELECT * 
FROM dbo.OrderDetail
ORDER BY OrderDetailID

--Orphan a row
SELECT * 
FROM dbo.Customer

DELETE dbo.Customer
WHERE LastName = 'Monroe'
 