IF OBJECT_ID('dbo.Customer') IS NOT NULL
BEGIN
	DROP TABLE dbo.Customer
END

CREATE TABLE dbo.Customer
	(
	CustomerKey int IDENTITY(1,1) NOT NULL, 
	FirstName varchar(50) NULL, 
	MiddleName varchar(50) NULL, 
	LastName varchar(50) NULL, 
	CustomerStatus varchar(10), 
	StreetAddress1 varchar(100), 
	StreetAddress2 varchar(100), 
	City varchar(100), 
	State varchar(20), 
	ZipCode int, 
	HomePhone varchar(15), 
	CellPhone varchar(15), 
	WorkPhone varchar(15), 
	EmailAddress varchar(100), 
	StartDate varchar(20), 
	CustomerNumber varchar(25), 
	FirstOrderDate datetime, 
	MostRecentOrderDate datetime, 
CONSTRAINT PK_Customer_CustomerKey
               PRIMARY KEY CLUSTERED (CustomerKey)
	)

IF OBJECT_ID('dbo.CustomerOrder') IS NOT NULL
BEGIN
	DROP TABLE dbo.CustomerOrder
END

CREATE TABLE dbo.CustomerOrder
	(
	OrderID int IDENTITY(1,1) NOT NULL, 
	CustomerKey int NOT NULL, 
	OrderDate date, 
	OrderNumber varchar(50) NOT NULL, 
	CustomerFirstName varchar(50), 
	CustomerLastName varchar(50), 
	ShipToName varchar(200), 
	ShippingAddress1 varchar(100), 
	ShippingAddress2 varchar(100), 
	ShippingCity varchar(100), 
	ShippingState varchar(20), 
	ShippingZip varchar(20), 
	BillToName varchar(200), 
	BillToAddress1 varchar(100), 
	BillToAddress2 varchar(100), 
	BillToCity varchar(100), 
	BillToState varchar(20), 
	BillToZip varchar(20), 
	OrderTotal numeric(11,2), 
CONSTRAINT PK_CustomerOrder_OrderID PRIMARY KEY CLUSTERED (OrderID)
	)

IF OBJECT_ID('dbo.OrderDetail') IS NOT NULL
BEGIN
	DROP TABLE dbo.OrderDetail
END

CREATE TABLE dbo.OrderDetail
	(
	OrderDetailID int IDENTITY(1,1) NOT NULL, 
	CustomerKey int NOT NULL, 
	OrderNumber varchar(50), 
	ItemNumber varchar(20), 
	Quantity smallint, 
	UnitPrice numeric(9,2)
	)

