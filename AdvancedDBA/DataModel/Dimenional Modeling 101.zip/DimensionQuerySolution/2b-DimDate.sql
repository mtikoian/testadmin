/****** Script for SelectTopNRows command from SSMS  ******/
SELECT TOP 1000 [DateKey]      ,[FullDateAlternateKey]      ,[DayNumberOfWeek]      ,[DayNameOfWeek]
      ,[DayNumberOfMonth]      ,[DayNumberOfYear]      ,[WeekNumberOfYear]      ,[MonthName]
      ,[MonthNumberOfYear]      ,[CalendarQuarter]      ,[CalendarYear]      ,[CalendarSemester]
      , 'FY ' + CAST([FiscalYear] AS CHAR(4)) + ' Qtr ' + CAST( [FiscalQuarter] AS char(1) ) AS FullFiscalQuarter
      ,[FiscalQuarter]      ,[FiscalYear]      ,[FiscalSemester]
  FROM [AdvWorkEDW].[dbo].[DimDate]