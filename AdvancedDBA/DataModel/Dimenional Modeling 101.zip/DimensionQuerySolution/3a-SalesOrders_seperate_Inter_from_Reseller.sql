use [AdventureWorks2008R2]
go

/****** Script for SelectTopNRows command from SSMS  ******/
SELECT TOP 100 soh.[SalesOrderID],soh.[RevisionNumber]      ,soh.[OrderDate] -- ,soh.[DueDate],soh.[ShipDate]      
    , soh.[SubTotal],soh.[TaxAmt],soh.[Freight]      ,soh.[TotalDue]
    , CASE soh.OnlineOrderFlag WHEN 1 THEN 'Internet' ELSE 'Reseller' END AS SalesType
    , DATEPART(Year, SOH.OrderDate) AS SalesYear
    , sod.SalesOrderDetailID, sod.ProductID, sod.LineTotal, sod.OrderQty, sod.UnitPrice, sod.UnitPriceDiscount
    , so.Description, so.Category, so.DiscountPct
    , p.ProductNumber, p.ListPrice, p.Name
  FROM [Sales].[SalesOrderHeader] soh
    INNER JOIN sales.SalesOrderDetail sod         ON sod.SalesOrderID = soh.SalesOrderID
      INNER JOIN Sales.SpecialOfferProduct sop    ON sop.SpecialOfferID = sod.SpecialOfferID AND sop.ProductID = sod.ProductID
        INNER JOIN Production.Product p           ON p.ProductID = sop.ProductID
        INNER JOIN Sales.SpecialOffer so          ON so.SpecialOfferID = sop.SpecialOfferID
  WHERE SalesOrderNumber IN ('SO45798', 'SO48053', 'SO51180', 'SO51181')

SELECT TOP 100 soh.[SalesOrderID],soh.[RevisionNumber]      ,soh.[OrderDate] -- ,soh.[DueDate],soh.[ShipDate]      
    , soh.[SubTotal],soh.[TaxAmt],soh.[Freight]      ,soh.[TotalDue]
    , CASE soh.OnlineOrderFlag WHEN 1 THEN 'Internet' ELSE 'Reseller' END AS SalesType
    , DATEPART(Year, SOH.OrderDate) AS SalesYear
    , sod.SalesOrderDetailID, sod.ProductID, sod.LineTotal, sod.OrderQty, sod.UnitPrice, sod.UnitPriceDiscount
    , so.Description, so.Category, so.DiscountPct
    , p.ProductNumber, p.ListPrice, p.Name
  FROM [Sales].[SalesOrderHeader] soh
    INNER JOIN sales.SalesOrderDetail sod         ON sod.SalesOrderID = soh.SalesOrderID
      INNER JOIN Sales.SpecialOfferProduct sop    ON sop.SpecialOfferID = sod.SpecialOfferID AND sop.ProductID = sod.ProductID
        INNER JOIN Production.Product p           ON p.ProductID = sop.ProductID
        INNER JOIN Sales.SpecialOffer so          ON so.SpecialOfferID = sop.SpecialOfferID
  WHERE so.SpecialOfferID = 16
  
      
