USE AdvWorkEDW
GO

SELECT DateKey, FullDateAlternateKey, [MonthName], CalendarQuarter, CalendarYear
  FROM dbo.DimDate
  WHERE CalendarYear = 2007