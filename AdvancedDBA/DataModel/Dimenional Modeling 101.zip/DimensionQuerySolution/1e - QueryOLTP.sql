USE AdventureWorks2008R2
GO
-- Add Category, get rid of Product name

DECLARE @ReportYear int = 2007

-- demonstrate having to add Employee and person
SELECT PER.FirstName + ' ' + PER.LastName AS Employee
    , P.Name AS Product
    , DATEPART(Year, SOH.OrderDate)  
    , SUM(DET.LineTotal) AS Sales
  FROM Sales.SalesOrderHeader SOH 
    INNER JOIN Sales.SalesOrderDetail DET 
        ON SOH.SalesOrderID = DET.SalesOrderID
      -- Product join
      INNER JOIN Production.Product P 
        ON DET.ProductID = P.ProductID 
      -- Employee join
      INNER JOIN [Sales].[SalesPerson] SP 
        ON SP.[BusinessEntityID] = SOH.[SalesPersonID]
        -- Person join
        INNER JOIN [Person].[Person] PER 
          ON PER.[BusinessEntityID] = SP.[BusinessEntityID]
   INNER JOIN Production.ProductSubcategory PS ON P.ProductSubcategoryID = PS.ProductSubcategoryID 
   INNER JOIN Production.ProductCategory PC ON PS.ProductCategoryID = PC.ProductCategoryID
  WHERE DATEPART(Year, SOH.OrderDate) = @ReportYear
  GROUP BY p.Name, DATEPART(Year, SOH.OrderDate), PER.FirstName + ' ' + PER.LastName 
    , ps.Name    , pc.Name

/*

    , ps.Name AS Subcategory
    , pc.Name AS Category


   INNER JOIN Production.ProductSubcategory PS ON P.ProductSubcategoryID = PS.ProductSubcategoryID 
   INNER JOIN Production.ProductCategory PC ON PS.ProductCategoryID = PC.ProductCategoryID
*/
