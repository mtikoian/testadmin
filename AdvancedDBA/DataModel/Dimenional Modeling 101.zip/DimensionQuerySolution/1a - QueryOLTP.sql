USE AdventureWorks2008R2
GO
-- Get Total Sales for 2007
DECLARE @ReportYear int = 2007

SELECT SalesOrderID, SubTotal, TotalDue
  FROM Sales.SalesOrderHeader SOH 
  WHERE DATEPART(Year, SOH.OrderDate) = @ReportYear
    -- WHERE SOH.OrderDate BETWEEN '01/01/2007' AND '12/31/2007'
  

