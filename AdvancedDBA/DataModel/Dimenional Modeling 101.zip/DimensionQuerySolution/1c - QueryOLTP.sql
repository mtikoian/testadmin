USE AdventureWorks2008R2
GO
-- Get Total Sales for 2007
  -- By Product and Year
  
DECLARE @ReportYear int = 2007

-- Add By Product
SELECT P.Name AS Product, SUM(DET.LineTotal) AS Sales
  FROM Sales.SalesOrderHeader SOH 
    INNER JOIN Sales.SalesOrderDetail DET 
        ON SOH.SalesOrderID = DET.SalesOrderID
      INNER JOIN Production.Product P 
        ON DET.ProductID = P.ProductID 
  WHERE DATEPART(Year, SOH.OrderDate) = @ReportYear
  GROUP BY p.Name

/*
-- Add By Year DATEPART(Year, SOH.OrderDate)
SELECT DATEPART(Year, SOH.OrderDate), P.Name AS Product, SUM(DET.LineTotal) AS Sales
  FROM Sales.SalesOrderHeader SOH 
    INNER JOIN Sales.SalesOrderDetail DET 
        ON SOH.SalesOrderID = DET.SalesOrderID
      INNER JOIN Production.Product P 
        ON DET.ProductID = P.ProductID 
  --WHERE DATEPART(Year, SOH.OrderDate) = @ReportYear
  GROUP BY DATEPART(Year, SOH.OrderDate), p.Name
*/