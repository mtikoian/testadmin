USE AdventureWorks2008R2
GO
-- Get Total Sales for 2007
DECLARE @ReportYear int = 2007

SELECT SalesOrderID, SubTotal, TotalDue
  FROM Sales.SalesOrderHeader SOH 
  WHERE DATEPART(Year, SOH.OrderDate) = @ReportYear
  

SELECT SUM(DET.LineTotal) AS Sales
  FROM Sales.SalesOrderHeader SOH 
    INNER JOIN Sales.SalesOrderDetail DET ON SOH.SalesOrderID = DET.SalesOrderID
  WHERE DATEPART(Year, SOH.OrderDate) = @ReportYear

-- Add By Product
SELECT P.Name AS Product, SUM(DET.LineTotal) AS Sales
  FROM Sales.SalesOrderHeader SOH 
    INNER JOIN Sales.SalesOrderDetail DET 
        ON SOH.SalesOrderID = DET.SalesOrderID
      INNER JOIN Production.Product P 
        ON DET.ProductID = P.ProductID 
  WHERE DATEPART(Year, SOH.OrderDate) = @ReportYear
  GROUP BY p.Name

-- Add By Product
SELECT DATEPART(Year, SOH.OrderDate), P.Name AS Product, SUM(DET.LineTotal) AS Sales
  FROM Sales.SalesOrderHeader SOH 
    INNER JOIN Sales.SalesOrderDetail DET 
        ON SOH.SalesOrderID = DET.SalesOrderID
      INNER JOIN Production.Product P 
        ON DET.ProductID = P.ProductID 
  WHERE DATEPART(Year, SOH.OrderDate) = @ReportYear
  GROUP BY DATEPART(Year, SOH.OrderDate), P.Name


/*
DECLARE @ReportMonth int = 11, @EmployeeID int ;

SELECT PER.FirstName + ' ' + PER.LastName AS Employee,
   PS.Name AS Subcategory, SUM(DET.LineTotal) AS Sales, 
   SOH.SalesOrderID,  SOH.SalesOrderNumber, 
   P.Name AS Product, 
   SUM(DET.OrderQty) AS OrderQty, DET.UnitPrice, 
   PC.Name AS Category
FROM Sales.SalesOrderHeader SOH 
   INNER JOIN [Sales].[SalesPerson] SP ON SP.[BusinessEntityID] = SOH.[SalesPersonID]
   INNER JOIN Sales.SalesOrderDetail DET ON SOH.SalesOrderID = DET.SalesOrderID
   INNER JOIN [HumanResources].[Employee] E ON SOH.[SalesPersonID] = E.[BusinessEntityID] 
   INNER JOIN [Person].[Person] PER ON PER.[BusinessEntityID] = SP.[BusinessEntityID]
   INNER JOIN Production.Product P ON DET.ProductID = P.ProductID 
   INNER JOIN Production.ProductSubcategory PS ON P.ProductSubcategoryID = PS.ProductSubcategoryID 
   INNER JOIN Production.ProductCategory PC ON PS.ProductCategoryID = PC.ProductCategoryID
WHERE (DATEPART(Year, SOH.OrderDate) = @ReportYear) AND 
   (DATEPART(Month, SOH.OrderDate) = @ReportMonth) 
    --AND     (SOH.SalesPersonID = @EmployeeID)
GROUP BY PER.FirstName + ' ' + PER.LastName, 
   DATEPART(Month, SOH.OrderDate), SOH.SalesOrderID, SOH.SalesOrderNumber, 
   P.Name, PS.Name, DET.UnitPrice, PC.Name
   
   
*/