use AdventureWorks2008R2
go

-- Query for Internet Sales Fact

SELECT DET.ProductID, p.ProductNumber
      , CAST( CONVERT( varchar(8), SOH.OrderDate, 112) AS int) AS OrderDate
      , CAST( CONVERT( varchar(8), SOH.DueDate, 112) AS int) AS DueDate
      , CAST( CONVERT( varchar(8), SOH.ShipDate, 112) AS int) AS ShipDate
      , CAST( c.[AccountNumber] AS nvarchar(15) ) AS CustomerAccountNumber, DET.SpecialOfferID
      , IsNull( SOH.CurrencyRateID, 100) AS CurrencyRateID, SOH.SalesPersonID
      , SOH.SalesOrderNumber, st.TerritoryID
      , CAST( ROW_NUMBER() OVER(PARTITION BY SOH.SalesOrderNumber ORDER BY SOH.SalesOrderNumber) AS tinyint) AS SalesOrderDetailID
      , SOH.RevisionNumber, IsNull( IsNull( DET.OrderQty, 0 ), 0 ) AS OrderQty , DET.UnitPrice, (IsNull( DET.OrderQty, 0 ) * DET.UnitPrice) AS ExtendedPrice
      , DET.UnitPriceDiscount AS DiscountPct, ( DET.UnitPriceDiscount * (IsNull( DET.OrderQty, 0 ) * p.StandardCost) ) AS DiscountAmt
      , p.StandardCost, (IsNull( DET.OrderQty, 0 ) * p.StandardCost) AS TotalProductCost
      , DET.LineTotal AS SalesAmount, SOH.TaxAmt, SOH.Freight
      , SOH.PurchaseOrderNumber, DET.CarrierTrackingNumber
      , CASE SOH.OnlineOrderFlag WHEN 1 THEN 'Internet' ELSE 'Reseller' END AS OrderType
      , SOH.SubTotal, SOH.TotalDue
  FROM Sales.SalesOrderHeader SOH 
    INNER JOIN Sales.SalesOrderDetail DET 
        ON SOH.SalesOrderID = DET.SalesOrderID
      -- Product join
      INNER JOIN Production.Product P 
        ON DET.ProductID = P.ProductID 
    -- Customer join
	  INNER JOIN Sales.Customer c
		ON c.CustomerID = soh.CustomerID
    -- Sales Territory join
    INNER JOIN [Sales].SalesTerritory st 
      ON st.TerritoryID = SOH.[TerritoryID]
  WHERE soh.OnlineOrderFlag = 1

/*
SELECT DET.ProductID, p.ProductNumber, SOH.OnlineOrderFlag
      , CAST( CONVERT( varchar(8), SOH.OrderDate, 112) AS int) AS OrderDate
      , CAST( CONVERT( varchar(8), SOH.DueDate, 112) AS int) AS DueDate
      , CAST( CONVERT( varchar(8), SOH.ShipDate, 112) AS int) AS ShipDate
      , SOH.CustomerID, c.AccountNumber
      , DET.SpecialOfferID
      , SOH.CurrencyRateID, SOH.SalesPersonID
      , soh.TerritoryID, st.CountryRegionCode
      , SOH.SalesOrderNumber, DET.SalesOrderDetailID
      , SOH.RevisionNumber, IsNull( DET.OrderQty, 0 ), DET.UnitPrice, (IsNull( DET.OrderQty, 0 ) * DET.UnitPrice) AS ExtendedPrice
      , DET.UnitPriceDiscount AS DiscountPct, ( DET.UnitPriceDiscount * (IsNull( DET.OrderQty, 0 ) * p.StandardCost) ) AS DiscountAmt
      , p.StandardCost, (IsNull( DET.OrderQty, 0 ) * p.StandardCost) AS TotalProductCost
      , DET.LineTotal AS SalesAmount, SOH.TaxAmt, SOH.Freight
      , SOH.PurchaseOrderNumber, DET.CarrierTrackingNumber
      , CASE SOH.OnlineOrderFlag WHEN 1 THEN 'Internet' ELSE 'Reseller' END AS OrderType
      , SOH.SubTotal, SOH.TotalDue
  FROM Sales.SalesOrderHeader SOH 
    INNER JOIN Sales.SalesOrderDetail DET 
        ON SOH.SalesOrderID = DET.SalesOrderID
      -- Product join
      INNER JOIN Production.Product P 
        ON DET.ProductID = P.ProductID 
    -- Customer join
	  INNER JOIN Sales.Customer c
		ON c.CustomerID = soh.CustomerID
    -- Sales Territory join
    INNER JOIN [Sales].SalesTerritory st 
      ON st.TerritoryID = SOH.[TerritoryID]
  WHERE soh.OnlineOrderFlag = 1
    


SELECT DET.ProductID, p.ProductNumber, SOH.OnlineOrderFlag
      , CAST( CONVERT( varchar(8), SOH.OrderDate, 112) AS int) AS OrderDate
      , CAST( CONVERT( varchar(8), SOH.DueDate, 112) AS int) AS DueDate
      , CAST( CONVERT( varchar(8), SOH.ShipDate, 112) AS int) AS ShipDate
      , SOH.CustomerID, DET.SpecialOfferID
      , SOH.CurrencyRateID, SOH.SalesPersonID, sp.TerritoryID
      , SOH.SalesOrderNumber, DET.SalesOrderDetailID
      , SOH.RevisionNumber, IsNull( DET.OrderQty, 0 ), DET.UnitPrice, (IsNull( DET.OrderQty, 0 ) * DET.UnitPrice) AS ExtendedPrice
      , DET.UnitPriceDiscount AS DiscountPct, ( DET.UnitPriceDiscount * (IsNull( DET.OrderQty, 0 ) * p.StandardCost) ) AS DiscountAmt
      , p.StandardCost, (IsNull( DET.OrderQty, 0 ) * p.StandardCost) AS TotalProductCost
      , DET.LineTotal AS SalesAmount, SOH.TaxAmt, SOH.Freight
      , SOH.PurchaseOrderNumber, DET.CarrierTrackingNumber
      , CASE SOH.OnlineOrderFlag WHEN 1 THEN 'Internet' ELSE 'Reseller' END AS OrderType
      , SOH.SubTotal, SOH.TotalDue
  FROM Sales.SalesOrderHeader SOH 
    INNER JOIN Sales.SalesOrderDetail DET 
        ON SOH.SalesOrderID = DET.SalesOrderID
      -- Product join
      INNER JOIN Production.Product P 
        ON DET.ProductID = P.ProductID 
    -- Employee join
    INNER JOIN [Sales].[SalesPerson] SP 
      ON SP.[BusinessEntityID] = SOH.[SalesPersonID]
        -- Person join
        INNER JOIN [Person].[Person] PER 
          ON PER.[BusinessEntityID] = SP.[BusinessEntityID]
         -- Sales Territory
        LEFT JOIN Sales.SalesTerritory st ON st.TerritoryID = sp.TerritoryID
    -- Special Offer
    LEFT JOIN Sales.SpecialOfferProduct sop ON sop.SpecialOfferID = DET.SpecialOfferID AND sop.ProductID = DET.ProductID
      INNER JOIN Sales.SpecialOffer so ON so.SpecialOfferID = sop.SpecialOfferID   
  WHERE soh.OnlineOrderFlag = 1
*/
   --WHERE soh.SalesOrderNumber = 'SO43659'
    