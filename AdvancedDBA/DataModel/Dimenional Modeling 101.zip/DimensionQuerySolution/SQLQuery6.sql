-- Query for Internet Sales Fact

SELECT DET.ProductID, SOH.OrderDate, SOH.DueDate, SOH.ShipDate, SOH.CustomerID, 
      PER.FirstName + ' ' + PER.LastName AS Employee
    , P.Name AS Product
    , SOH.OrderDate
    , DET.LineTotal
  FROM Sales.SalesOrderHeader SOH 
    INNER JOIN Sales.SalesOrderDetail DET 
        ON SOH.SalesOrderID = DET.SalesOrderID
      -- Product join
      INNER JOIN Production.Product P 
        ON DET.ProductID = P.ProductID 
    -- Employee join
    INNER JOIN [Sales].[SalesPerson] SP 
      ON SP.[BusinessEntityID] = SOH.[SalesPersonID]
        -- Person join
        INNER JOIN [Person].[Person] PER 
          ON PER.[BusinessEntityID] = SP.[BusinessEntityID]
    LEFT JOIN Sales.SpecialOfferProduct sop ON sop.SpecialOfferID = DET.SpecialOfferID AND sop.ProductID = DET.ProductID
      INNER JOIN Sales.SpecialOffer so ON so.SpecialOfferID = sop.SpecialOfferID   

/*

    , ps.Name AS Subcategory
    , pc.Name AS Category


   INNER JOIN Production.ProductSubcategory PS ON P.ProductSubcategoryID = PS.ProductSubcategoryID 
   INNER JOIN Production.ProductCategory PC ON PS.ProductCategoryID = PC.ProductCategoryID
*/
