USE AdventureWorks2008R2
GO
-- Get Total Sales for 2007
  -- By Product By Salesperson

DECLARE @ReportYear int = 2007

-- demonstrate having to add Employee and person
SELECT P.Name AS Product, DATEPART(Year, SOH.OrderDate),  
    -- PER.FirstName + ' ' + PER.LastName AS Employee,
    SUM(DET.LineTotal) AS Sales
  FROM Sales.SalesOrderHeader SOH 
    INNER JOIN Sales.SalesOrderDetail DET 
        ON SOH.SalesOrderID = DET.SalesOrderID
      -- Product join
      INNER JOIN Production.Product P 
        ON DET.ProductID = P.ProductID 
      -- Employee join
      INNER JOIN [Sales].[SalesPerson] SP 
        ON SP.[BusinessEntityID] = SOH.[SalesPersonID]
  WHERE DATEPART(Year, SOH.OrderDate) = @ReportYear
  GROUP BY p.Name, DATEPART(Year, SOH.OrderDate)
  --, PER.FirstName + ' ' + PER.LastName 

/*


SELECT *
  FROM [Sales].[SalesPerson]

        -- Person join
        INNER JOIN [Person].[Person] PER 
          ON PER.[BusinessEntityID] = SP.[BusinessEntityID]

*/