USE AdventureWorks2008R2
GO
-- Add Category, get rid of Product name

-- demonstrate having to add Employee and person
SELECT Employee, Category, Subcategory, product, IsNull( [2006], 0) AS Year2006, IsNull( [2007], 0) AS Year2007, IsNull( [2008], 0) AS Year2008
  FROM ( 
          SELECT PER.FirstName + ' ' + PER.LastName AS Employee, P.Name AS Product, DATEPART(Year, SOH.OrderDate) AS SalesYear
              , ps.Name AS Subcategory, pc.Name AS Category, SUM(DET.LineTotal) AS Sales
            FROM Sales.SalesOrderHeader SOH 
              INNER JOIN Sales.SalesOrderDetail DET ON SOH.SalesOrderID = DET.SalesOrderID
                INNER JOIN Production.Product P ON DET.ProductID = P.ProductID 
                  INNER JOIN Production.ProductSubcategory PS ON P.ProductSubcategoryID = PS.ProductSubcategoryID 
                  INNER JOIN Production.ProductCategory PC ON PS.ProductCategoryID = PC.ProductCategoryID
                INNER JOIN [Sales].[SalesPerson] SP ON SP.[BusinessEntityID] = SOH.[SalesPersonID]
                  INNER JOIN [Person].[Person] PER ON PER.[BusinessEntityID] = SP.[BusinessEntityID]
            GROUP BY p.Name, DATEPART(Year, SOH.OrderDate), PER.FirstName + ' ' + PER.LastName, ps.Name, pc.Name
        ) AS SalesCrossTab
     PIVOT ( SUM(Sales) FOR SalesYear IN ([2006], [2007], [2008] ) ) AS pvtSales
   ORDER BY Employee
/*

    , ps.Name AS Subcategory, pc.Name AS Category


   INNER JOIN Production.ProductSubcategory PS ON P.ProductSubcategoryID = PS.ProductSubcategoryID 
   INNER JOIN Production.ProductCategory PC ON PS.ProductCategoryID = PC.ProductCategoryID
*/
