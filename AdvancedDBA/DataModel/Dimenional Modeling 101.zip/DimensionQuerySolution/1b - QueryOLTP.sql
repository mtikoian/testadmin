USE AdventureWorks2008R2
GO
-- Get Total Sales for 2007
DECLARE @ReportYear int = 2007

SELECT '2007' AS SalesFor, SUM(DET.LineTotal) AS Sales
  FROM Sales.SalesOrderHeader SOH 
    INNER JOIN Sales.SalesOrderDetail DET ON SOH.SalesOrderID = DET.SalesOrderID
  WHERE DATEPART(Year, SOH.OrderDate) = @ReportYear

-- Show Group By for all years
/*
SELECT DATEPART(Year, SOH.OrderDate), SUM(DET.LineTotal) AS Sales
  FROM Sales.SalesOrderHeader SOH 
    INNER JOIN Sales.SalesOrderDetail DET ON SOH.SalesOrderID = DET.SalesOrderID
  GROUP BY DATEPART(Year, SOH.OrderDate)

*/