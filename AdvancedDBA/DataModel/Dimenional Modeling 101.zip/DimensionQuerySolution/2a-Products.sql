-- Production Dimension

use [AdventureWorks2008R2]
go

/****** Script for SelectTopNRows command from SSMS  ******/
SELECT [ProductNumber]
      , [SizeUnitMeasureCode], ums.Name AS SizeUOMDesc
      , [WeightUnitMeasureCode], umw.Name as WeightUOMDesc
      , p.[Name] as ProductName
      , [StandardCost], [FinishedGoodsFlag]
      ,[Color],[SafetyStockLevel], [ReorderPoint]
      ,[ListPrice], [Size], '' AS SizeRange
      ,[Weight], [DaysToManufacture], [ProductLine], 0 AS DealerPrice
      , [Class], [Style], '' AS ModelName, Null AS LargePhoto, '' AS EnglishDescription
      ,[ProductSubcategoryID]
  FROM [Production].[Product] p
    LEFT JOIN [Production].UnitMeasure ums ON ums.UnitMeasureCode = p.SizeUnitMeasureCode
    LEFT JOIN [Production].UnitMeasure umw ON umw.UnitMeasureCode = p.WeightUnitMeasureCode
    
SELECT [ProductNumber]
      , [SizeUnitMeasureCode], ums.Name AS SizeUOMDesc
      , [WeightUnitMeasureCode], umw.Name as WeightUOMDesc
      , p.[Name] as ProductName
      , IsNull([StandardCost],0) AS StandardCost, [FinishedGoodsFlag]
      ,IsNull([Color], 'NA') AS Color, [SafetyStockLevel], [ReorderPoint]
      ,IsNull([ListPrice], 0) AS ListPrice,  IsNull([Size], 'NA') AS Size, '' AS SizeRange
      ,[Weight], [DaysToManufacture], [ProductLine], 0 AS DealerPrice
      , [Class], [Style], '' AS ModelName, Null AS LargePhoto, '' AS EnglishDescription
      ,IsNull([ProductSubcategoryID], 38) AS ProductSubcategoryID
  FROM [Production].[Product] p
    LEFT JOIN [Production].UnitMeasure ums ON ums.UnitMeasureCode = p.SizeUnitMeasureCode
    LEFT JOIN [Production].UnitMeasure umw ON umw.UnitMeasureCode = p.WeightUnitMeasureCode    
