use AdventureWorks2008R2
go

-- Query for Reseller Sales Fact

SELECT DET.ProductID, p.ProductNumber, SOH.OnlineOrderFlag
      , CAST( CONVERT( varchar(8), SOH.OrderDate, 112) AS int) AS OrderDate
      , CAST( CONVERT( varchar(8), SOH.DueDate, 112) AS int) AS DueDate
      , CAST( CONVERT( varchar(8), SOH.ShipDate, 112) AS int) AS ShipDate
      , SOH.CustomerID, DET.SpecialOfferID
      , SOH.CurrencyRateID, SOH.SalesPersonID, sp.TerritoryID
      , SOH.SalesOrderNumber, DET.SalesOrderDetailID
      , SOH.RevisionNumber, DET.OrderQty, DET.UnitPrice, (DET.OrderQty * DET.UnitPrice) AS ExtendedPrice
      , DET.UnitPriceDiscount AS DiscountPct, ( DET.UnitPriceDiscount * (DET.OrderQty * p.StandardCost) ) AS DiscountAmt
      , p.StandardCost, (DET.OrderQty * p.StandardCost) AS TotalProductCost
      , DET.LineTotal AS SalesAmount, SOH.TaxAmt, SOH.Freight
      , SOH.PurchaseOrderNumber, DET.CarrierTrackingNumber
      , CASE SOH.OnlineOrderFlag WHEN 1 THEN 'Internet' ELSE 'Reseller' END AS OrderType
      , SOH.SubTotal, SOH.TotalDue
  FROM Sales.SalesOrderHeader SOH 
    INNER JOIN Sales.SalesOrderDetail DET 
        ON SOH.SalesOrderID = DET.SalesOrderID
      -- Product join
      INNER JOIN Production.Product P 
        ON DET.ProductID = P.ProductID 
    -- Employee join
    INNER JOIN [Sales].[SalesPerson] SP 
      ON SP.[BusinessEntityID] = SOH.[SalesPersonID]
        -- Person join
        INNER JOIN [Person].[Person] PER 
          ON PER.[BusinessEntityID] = SP.[BusinessEntityID]
         -- Sales Territory
        LEFT JOIN Sales.SalesTerritory st ON st.TerritoryID = sp.TerritoryID
    -- Special Offer
    LEFT JOIN Sales.SpecialOfferProduct sop ON sop.SpecialOfferID = DET.SpecialOfferID AND sop.ProductID = DET.ProductID
      INNER JOIN Sales.SpecialOffer so ON so.SpecialOfferID = sop.SpecialOfferID   
  WHERE soh.OnlineOrderFlag = 0

   --WHERE soh.SalesOrderNumber = 'SO43659'
    