/* ======================================================================= */
/*                  Test database backups with passwords                   */
/* ======================================================================= */


/* Back up the database using a password */
BACKUP DATABASE EncryptionTestDB TO DISK='C:\SQLBackups\EncryptionDB_backup_testpassword.bak'
WITH PASSWORD = 'ILikeDonuts'


/* Now edit the .bak file in notepad and look for any unencrypted and encrypted data that is known, like Steve or Jeff.  
   Then search for one of the SSN's that we used, like 444.  */


/* Now delete the database */


/* Now attempt to restore the database without using the password (receives error message)*/
RESTORE DATABASE EncryptionTestDB FROM DISK='C:\SQLBackups\EncryptionDB_backup_testpassword.bak'


/* Now restore the database using the correct password */
RESTORE DATABASE EncryptionTestDB FROM DISK='C:\SQLBackups\EncryptionDB_backup_testpassword.bak' WITH PASSWORD = 'ILikeDonuts'