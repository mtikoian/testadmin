/* ====================================================================================== */
/*             Create Roles and Set Permissions To Test Ownership Chaining                */
/*             and ability of normal user to see data and execute SPROCs                  */


USE EncryptionTestDB
GO

/* ====================================================================================== */


CREATE ROLE EncryptionTestDBUser

GRANT EXECUTE ON dbo.xp_usp_Read_Applicant_Rec TO EncryptionTestDBUser
GRANT EXECUTE ON dbo.xp_usp_Read_Applicant_Rec_With_Spec_SSN TO EncryptionTestDBUser
GRANT EXECUTE ON dbo.xp_usp_Read_All_Applicant_Rec TO EncryptionTestDBUser
GRANT EXECUTE ON dbo.xp_usp_Create_Applicant_Rec TO EncryptionTestDBUser
GRANT EXECUTE ON dbo.xp_usp_Update_Applicant_Rec TO EncryptionTestDBUser


--for reference, but role should not have SELECT capabilities on the data for security reasons (restrict the columns they can see)
--GRANT SELECT ON Applicant TO EncryptionTestDBUser





--allow the role to use the symmetric key in the sprocs
GRANT REFERENCES ON SYMMETRIC KEY::SymmKey1 TO EncryptionTestDBUser;
GO

/*
possible permissions for Symmetric Key:
=======================================
ALTER
CONTROL
REFERENCES
TAKE OWNERSHIP
VIEW DEFINITION
*/




/* ========================================================================================================================= */
--set up the main login
USE MASTER
GO


CREATE LOGIN DBUser
	WITH PASSWORD = 'doorjam', DEFAULT_DATABASE=[EncryptionTestDB], DEFAULT_LANGUAGE=[us_english], CHECK_EXPIRATION=OFF, CHECK_POLICY=OFF
GO


-- set up the user in the database
USE EncryptionTestDB
GO

CREATE USER DBUser FOR LOGIN DBUser
	WITH DEFAULT_SCHEMA = dbo
GO


-- add the user to the role
EXEC sys.sp_addrolemember 'EncryptionTestDBUser','DBUser'
GO

/* Now log in to Management Studio as this user (using SQL Authentication and typing the username
and password).  Then, run the EncryptionTestDB_5_Data_Insert_And_Testing.sql file,
one section at a time and see how security is implemented.         */