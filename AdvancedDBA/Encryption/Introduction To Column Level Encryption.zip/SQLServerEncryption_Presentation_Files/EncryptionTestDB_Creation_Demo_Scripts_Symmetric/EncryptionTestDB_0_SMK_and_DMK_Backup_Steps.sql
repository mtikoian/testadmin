/* ==============================================================================================*/
/*                           Service Master Key                                                   */
/*  Each instance has one Service Master Key.                                                     */
/* ==============================================================================================*/




/* ============================================================================================== */
/* ONCE OVERALL - back up the service master key using an encryption password
Only needs to be done once overall, period.  Backup file should be saved to CD and 
kept offsite in safe place (safe deposit box, etc.).  Don't forget to safeguard the password
that was used to encrypt it.  You'll need it to restore the backup.  Only keep in the 
same place as the backup if really safe (like safe deposit box). With both, can decrypt the
database columns.  */



BACKUP SERVICE MASTER KEY TO FILE='c:\ServiceMasterKeyBackup_YYYYMMDDHHMM.bak'
ENCRYPTION BY PASSWORD='SQLServerIsReallyCoolServiceMasterBackup334$'
GO


-- To restore that key, use the following:
/*
RESTORE SERVICE MASTER KEY FROM FILE=�c:\ServiceMasterKeyBackup_YYYYMMDDHHMM.bak�
DECRYPTION BY PASSWORD=�SQLServerIsReallyCoolServiceMasterBackup334$�
*/




/* ============================================================================================== */


/* This service master key can be regenerated, to produce a different service master key, 
by issuing the following (note that this replaces the current one, great care should 
be taken to back up the existing one in case it is needed if anyone has encrypted 
anything using it) */

/*
ALTER SERVICE MASTER KEY REGENERATE
*/

/* ==============================================================================================*/
/*                            Database Master Key                                                */
/*  Each database can have only one Service Master Key.  It has to be manually created.          */
/* ==============================================================================================*/

/*  Create the database master key using the server's service master key.
    This becomes part of the database, and is included in any database backups.
    Is encrypted with the Service Master Key and saved in the Master database, and is 
    encrypted with the passphrase and saved in the database.  (this behavior can be changed)
    Database Master Key can only be created once per database.  Be sure to keep the database master key
    password in a safe place in case it has to be recreated.   */

/*  This database master key is created once per database            */
--note:  Not needed for Symmetric Key creation the way we are going to do it
USE <dbname>
GO

CREATE MASTER KEY
ENCRYPTION BY PASSWORD='$iUksH8&!eDvBuLLQ24$&8*tYPkMnbV2$1SaFbGkEr'

