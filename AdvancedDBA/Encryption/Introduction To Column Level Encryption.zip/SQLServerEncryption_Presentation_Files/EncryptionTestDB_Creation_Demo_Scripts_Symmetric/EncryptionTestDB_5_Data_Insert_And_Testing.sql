USE EncryptionTestDB
GO


-- notice:   Return Status value of 1 means OK

-- Run each section, one section at a time

/* ===================================================================================================================================== */

-- Create record for Jeff H Smith
DECLARE @st   int
DECLARE @rn   int
DECLARE @em varchar(200)
EXEC xp_usp_Create_Applicant_Rec  'Jeff','H','Smith','123-45-6789',@spstat=@st OUTPUT,@errmsg=@em OUTPUT,@recn=@rn OUTPUT
SELECT 'xp_usp_Create_Applicant_Rec' as SPROC, @st as Status, @em as ErrorMessage, @rn as RecNum

/* ===================================================================================================================================== */

-- Create record for Steve J Brown
DECLARE @st   int
DECLARE @rn   int
DECLARE @em varchar(200)
EXEC xp_usp_Create_Applicant_Rec  'Steve','J','Brown','444-55-6666',@spstat=@st OUTPUT,@errmsg=@em OUTPUT,@recn=@rn OUTPUT
SELECT 'xp_usp_Create_Applicant_Rec' as SPROC, @st as Status, @em as ErrorMessage, @rn as RecNum

/* ===================================================================================================================================== */

-- Create record for Christopher C Edmunds
DECLARE @st   int
DECLARE @rn   int
DECLARE @em varchar(200)
EXEC xp_usp_Create_Applicant_Rec  'Christopher','C','Edmunds','555-66-7890',@spstat=@st OUTPUT,@errmsg=@em OUTPUT,@recn=@rn OUTPUT
SELECT 'xp_usp_Create_Applicant_Rec' as SPROC, @st as Status, @em as ErrorMessage, @rn as RecNum

/* ===================================================================================================================================== */

-- read all Applicant table records, showing the encrypted value in the AppSSN column
SELECT * FROM Applicant

/* ===================================================================================================================================== */

-- read  all Applicant table records, with value decoded
DECLARE @st   int
DECLARE @rn   int
DECLARE @em varchar(200)
EXEC xp_usp_Read_All_Applicant_Rec  @spstat=@st OUTPUT,@errmsg=@em OUTPUT,@recn=@rn OUTPUT
SELECT 'xp_usp_Read_All_Applicant_Rec' as SPROC, @st as Status, @em as ErrorMessage, @rn as RecNum

/* ===================================================================================================================================== */

-- read the record where AppID = 1 (the input parameter value)  with value decoded
DECLARE @st   int
DECLARE @rn   int
DECLARE @em varchar(200)
EXEC xp_usp_Read_Applicant_Rec  1,@spstat=@st OUTPUT,@errmsg=@em OUTPUT,@recn=@rn OUTPUT
SELECT 'xp_usp_Read_Applicant_Rec' as SPROC, @st as Status, @em as ErrorMessage,@rn as RecNum
/* ===================================================================================================================================== */

-- read the record where SSN = 555-66-7890 (the input parameter value)  with value decoded
DECLARE @st   int
DECLARE @rn   int
DECLARE @em varchar(200)
EXEC xp_usp_Read_Applicant_Rec_With_Spec_SSN  '555-66-7890',@spstat=@st OUTPUT,@errmsg=@em OUTPUT,@recn=@rn OUTPUT
SELECT 'xp_usp_Read_Applicant_Rec_With_Spec_SSN' as SPROC, @st as Status, @em as ErrorMessage,@rn as RecNum

/* ================================================================================================= */
--For SQL Server 2008 and up....

--Attempt to drop the Symmetric Key SymmKey1 (assuming the ddl trigger was created from previous script #3)
DROP SYMMETRIC KEY SymmKey1

--See the error message in the AppErrorLog table
SELECT * FROM AppErrorLog

--Now go back and run SPROC xp_usp_Read_All_Applicant_Rec to make sure the symmetric key is still there.
