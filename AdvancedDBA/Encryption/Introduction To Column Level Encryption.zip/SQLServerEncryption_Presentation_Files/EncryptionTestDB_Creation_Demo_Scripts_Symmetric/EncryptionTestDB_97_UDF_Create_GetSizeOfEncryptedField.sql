/*  This user defined function (udf) can be used to calculate the expected output length for encrypted data (using EncryptByKey) based on the key, plaintext length and if a hashed data/column is being used (optional parameter). 
    If you are using the results of the formula/udf to calculate the size of the column for a table, 
    I strongly suggest adding 1 or 2 blocks (i.e. 16 bytes) to the expected size to account for possible future changes to algorithms of choice or the stored format.
*
*     (c) 2005 Microsoft Corporation. All rights reserved. 
*
*************************************************************************/

-- @KeyName		:= name of the symmetric key.
-- @PTLen		:= length in bytes of the plain text
-- @UsesHash	:= if the optional MAC option of EncryptByKey is being using this value must be 1, 0 otherwise
--   returns the expected length in bytes of the ciphertext returned by EncryptByKey using @KeyName symnmetric key
-- and a plaintext of @PTLen bytes in length, either using the optional @MAC parameter or not.

/*    NOTE:   This UDF is from the white paper "Protect Sensitive Data Using Encryption in SQL Server 2005", by Don Kiely, 
			a SQL Server Technical Article from Microsoft, published Dec. 2006            */


--SELECT dbo.CalculateCipherLen('SymmKey1',11,1) as EncryptionLength



USE EncryptionTestDB
GO


CREATE FUNCTION dbo.CalculateCipherLen( @KeyName sysname, @PTLen int, @UsesHash	int = 0 )
RETURNS int
as
BEGIN
	declare @KeyType	nvarchar(2)
	declare @RetVal		int
	declare @BLOCK		int
	declare @IS_BLOCK	int
	declare @HASHLEN	int
	
	-- Hash length that
	SET @HASHLEN	= 20
	SET @RetVal	= NULL
	
	-- Look for the symmetric key in the catalog 
	SELECT @KeyType	= key_algorithm FROM sys.symmetric_keys WHERE name = @KeyName
	
	-- If parameters are valid
	if( @KeyType is not null AND @PTLen > 0)
	BEGIN
		-- If hash is being used. NOTE: as we use this value to calculate the length, we only use 0 or 1
		if( @UsesHash <> 0 )
			SET @UsesHash = 1
	
		-- 64 bit block ciphers
		if( @KeyType = N'R2' OR @KeyType = N'D' OR @KeyType = N'D3' OR @KeyType = N'DX' )
		BEGIN
			SET @BLOCK = 8
			SET @IS_BLOCK = 1
		END
		-- 128 bit block ciphers
		else if( @KeyType = N'A1' OR @KeyType = N'A2' OR @KeyType = N'A3' )
		BEGIN
			SET @BLOCK = 16
			SET @IS_BLOCK = 1
		END
		-- Stream ciphers, today only RC4 is supported as a stream cipher
		else
		BEGIN
			SET @IS_BLOCK = 0
		END
	
		-- Calclulate the expected length. Notice that the formula is different for block ciphres & stream ciphers
		if( @IS_BLOCK = 1 )
		BEGIN
			SET @RetVal = ( FLOOR( (8 + @PTLen + (@UsesHash * @HASHLEN) )/@BLOCK)+1 ) * @BLOCK + 16 + @BLOCK + 4
		END
		else
		BEGIN
			SET @RetVal = @PTLen + (@UsesHash * @HASHLEN) + 36 + 4
		END
	
	END

	return @RetVal
END
go
