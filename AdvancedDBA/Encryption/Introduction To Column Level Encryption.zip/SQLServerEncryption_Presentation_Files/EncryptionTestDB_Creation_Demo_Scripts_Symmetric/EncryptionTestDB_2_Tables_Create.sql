/* EncryptionTestDB database table creation script
--------------------------------------------------------------------------- 	
	Create EncryptionTestDB tables.



---------------------------------------------------------------------------*/
/* ========================================================================================== */
USE EncryptionTestDB
GO

/* ========================================================================================== */
/*                            =                                     =                         */
/*                            =                                     =                         */
/*                            =             Main Tables             =                         */
/*                            =                                     =                         */
/*                            =                                     =                         */
/* ========================================================================================== */

/* ======================================================================================== */
CREATE TABLE dbo.Applicant
(	AppID 			int IDENTITY NOT NULL
		CONSTRAINT PK_Applicant_On_AppID PRIMARY KEY CLUSTERED,
	AppFName		varchar(35)	NOT NULL,
	AppMName		varchar(35)	NULL,
	AppLName		varchar(35)	NOT NULL,
	AppSSN			varbinary(200)	NULL,
	LCHost			varchar(50)	NOT NULL	DEFAULT HOST_NAME(),
	LCUser			varchar(50)	NOT NULL	DEFAULT USER,
	LCDate			datetime	NOT NULL	DEFAULT GETDATE()
)
ON EncryptionTestDB_data
GO




/* ======================================================================================== */
CREATE TABLE dbo.AppErrorLog
(	EID 		int IDENTITY 	NOT NULL
		CONSTRAINT PK_AppErrorLog_On_EID PRIMARY KEY CLUSTERED,
	EDate		datetime	NOT NULL,
	EUser		varchar(50)	NULL,
	EMessage	varchar(1000)	NULL,
	ESource	        varchar(150)	NOT NULL,
	ENo		int		NOT NULL	DEFAULT 0,
	ESeverity	int		NOT NULL	DEFAULT 0,
	ELineNo   	int		NOT NULL	DEFAULT 0,
	EHost        	varchar(50)	NULL
)
ON EncryptionTestDB_data
GO