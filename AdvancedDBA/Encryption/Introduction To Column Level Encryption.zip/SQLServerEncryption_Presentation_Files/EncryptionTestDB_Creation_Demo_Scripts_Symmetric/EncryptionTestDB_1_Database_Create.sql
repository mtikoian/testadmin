/* Listing 1: Code to Create EncryptionTestDB Database
--------------------------------------------------------------------------- 	
	Create EncryptionTestDB.
---------------------------------------------------------------------------
   filegroup PRIMARY - for MSSQL system files
   filegroup EncryptionTestDB_data - for heap and clustered user tables
---------------------------------------------------------------------------
	This is the code to create the EncryptionTestDB database.
---------------------------------------------------------------------------*/
Use Master

CREATE DATABASE EncryptionTestDB
ON PRIMARY
 ( NAME = EncryptionTestDB_sys,
	FILENAME = 'C:\SQLData\EncryptionTestDB_sys.mdf',
	SIZE = 5 MB, MAXSIZE = UNLIMITED, FILEGROWTH = 1 MB ),
FILEGROUP EncryptionTestDB_data
 ( NAME = EncryptionTestDB_data,
	FILENAME = 'C:\SQLData\EncryptionTestDB_data1.ndf',
	SIZE = 10 MB, MAXSIZE = UNLIMITED, FILEGROWTH = 2 MB )
LOG ON
 ( NAME = EncryptionTestDB_log,
	FILENAME = 'C:\SQLData\EncryptionTestDB_log.ldf',
         SIZE = 3 MB, MAXSIZE = UNLIMITED, FILEGROWTH = 2 MB ) 
GO




EXEC dbo.sp_dbcmptlevel @dbname=N'EncryptionTestDB', @new_cmptlevel=90
GO
IF (1 = FULLTEXTSERVICEPROPERTY('IsFullTextInstalled'))
begin
EXEC [EncryptionTestDB].[dbo].[sp_fulltext_database] @action = 'enable'
end


GO

ALTER DATABASE [EncryptionTestDB] SET ANSI_NULL_DEFAULT OFF 
GO
ALTER DATABASE [EncryptionTestDB] SET ANSI_NULLS OFF 
GO
ALTER DATABASE [EncryptionTestDB] SET ANSI_PADDING OFF 
GO
ALTER DATABASE [EncryptionTestDB] SET ANSI_WARNINGS OFF 
GO
ALTER DATABASE [EncryptionTestDB] SET ARITHABORT OFF 
GO
ALTER DATABASE [EncryptionTestDB] SET AUTO_CLOSE OFF 
GO
ALTER DATABASE [EncryptionTestDB] SET AUTO_CREATE_STATISTICS ON 
GO
ALTER DATABASE [EncryptionTestDB] SET AUTO_SHRINK OFF 
GO
ALTER DATABASE [EncryptionTestDB] SET AUTO_UPDATE_STATISTICS ON 
GO
ALTER DATABASE [EncryptionTestDB] SET CURSOR_CLOSE_ON_COMMIT OFF 
GO
ALTER DATABASE [EncryptionTestDB] SET CURSOR_DEFAULT  GLOBAL 
GO
ALTER DATABASE [EncryptionTestDB] SET CONCAT_NULL_YIELDS_NULL OFF 
GO
ALTER DATABASE [EncryptionTestDB] SET NUMERIC_ROUNDABORT OFF 
GO
ALTER DATABASE [EncryptionTestDB] SET QUOTED_IDENTIFIER OFF 
GO
ALTER DATABASE [EncryptionTestDB] SET RECURSIVE_TRIGGERS OFF 
GO
ALTER DATABASE [EncryptionTestDB] SET  ENABLE_BROKER 
GO
ALTER DATABASE [EncryptionTestDB] SET AUTO_UPDATE_STATISTICS_ASYNC OFF 
GO
ALTER DATABASE [EncryptionTestDB] SET DATE_CORRELATION_OPTIMIZATION OFF 
GO
ALTER DATABASE [EncryptionTestDB] SET TRUSTWORTHY OFF 
GO
ALTER DATABASE [EncryptionTestDB] SET ALLOW_SNAPSHOT_ISOLATION OFF 
GO
ALTER DATABASE [EncryptionTestDB] SET PARAMETERIZATION SIMPLE 
GO
ALTER DATABASE [EncryptionTestDB] SET  READ_WRITE 
GO
ALTER DATABASE [EncryptionTestDB] SET  MULTI_USER 
GO
ALTER DATABASE [EncryptionTestDB] SET PAGE_VERIFY CHECKSUM  
GO
ALTER DATABASE [EncryptionTestDB] SET DB_CHAINING OFF 
GO



/*   Can set to either FULL, BULK_LOGGED, or SIMPLE  */

Alter Database EncryptionTestDB SET RECOVERY SIMPLE
GO





/*  Alter the database by setting the EncryptionTestDB_data filegroup as the DEFAULT */
USE EncryptionTestDB
GO
ALTER DATABASE EncryptionTestDB
MODIFY FILEGROUP EncryptionTestDB_data DEFAULT
GO









