/* ====================================================================================================== */
/*                   Create Database Master Key and any needed Symmetric or Assymetric keys               */
/* ====================================================================================================== */

USE EncryptionTestDB
GO





/*  Create a symmetric key.  Note: This symmetric key is NOT based on the Database Master Key.
    Created once in database per key (each key is given a unique name).  */

--This symmetric key is recreatable
CREATE SYMMETRIC KEY SymmKey1 
WITH ALGORITHM=AES_256,
	IDENTITY_VALUE = N'tU8$180$kMnH5T7#eJLknKW7qA',
	KEY_SOURCE = N'C3&fHw#erTfv7*&4k@DNmWdXpL8#4$'
ENCRYPTION BY PASSWORD='39eiIke$uY2$1!hBc5RfPm&%rFc3@L'
GO

  
/* Multiple symmetric (or assymetric, for that matter) keys can be generated per database.
   Just be sure and keep the passwords in a safe place so they can be retrieved if needed.  They
   would be needed to create any new SPROCs, or modify existing ones, since the SPROCS are encrypted
   and cannot be scripted out. */


/* Example of non-recreatable Symmetric Key:    */
/*
CREATE SYMMETRIC KEY SymmKey1 WITH ALGORITHM=AES_256
ENCRYPTION BY PASSWORD='39eiIke$uY2$1!hBc5RfPm&%rFc3@L'
GO
*/
/* The reason this particular type is non-recreatable:
   Symmetric keys such as this use a GUID each time it is created.  Therefore, if the symmetric 
   key is dropped, it cannot be recreated, since the key is created with a brand new GUID each
   time.  Therefore, another key cannot be created with the exact same values, unless
   IDENTITY_VALUE and KEY_SOURCE statements are used with appropriate values, as in the example
   of a recreatable Symmetric Key above.  */

/* ======================================================================================================================================== */
/* For SQL Server 2008 databases (and up), a DDL trigger can be created to prevent the accidental
   deletion of the Symmetric Key. */
   
    
--  NOTE: Trigger only works on SQL SERVER 2008 databases (and up)
--  Now create the DDL Trigger that keeps anyone from accidentally deleting the symmetric key

/*  To check compatibility level
DECLARE @dbname varchar(100)
DECLARE @compatlvl int
SET @dbname = 'EncryptionTestDB'
SELECT @compatlvl = compatibility_level FROM sys.databases WHERE name = @dbname

PRINT @compatlvl

80 = SQL 2000
90 = SQL 2005
100= SQL 2008
*/
/*
CREATE TRIGGER ddl_tgr_EncryptionTestDB_prevent_Symmetric_Key_Drop		--note, not a schema owned object
ON DATABASE
AFTER DROP_SYMMETRIC_KEY
AS
BEGIN
	SET NOCOUNT ON		-- to avoid the rowcount messages
	SET ROWCOUNT 0		-- in case the cilent has modified the rowcount


	BEGIN TRY
	
		--Note: do not put the name of the trigger in the error message for security reasons
		
		RAISERROR ('Trigger exists to prevent the dropping of the Symmetric Keys.  Trigger must be disabled before making any trigger modifications.',16,1)


	END TRY
	--error handling
	BEGIN CATCH
		-- rollback the transaction.  We do not want the key dropped
		IF @@trancount >0
			ROLLBACK TRANSACTION
	

		DECLARE	@ErrorNo	int,
			@Severity	int,
			@State		int,
			@LineNo		int,
			@Message	varchar(1000)
		SELECT	@ErrorNo = ERROR_NUMBER(),
			@Severity = ERROR_SEVERITY(),
			@State = ERROR_STATE(),
			@LineNo = ERROR_LINE(),
			@Message = ERROR_MESSAGE()



		--insert into error log if needed
		INSERT INTO AppErrorLog
		VALUES (GETDATE(), USER, @Message, 'ddl_tgr_EncryptionTestDB_prevent_Symmetric_Key_Drop', @ErrorNo, @Severity, @LineNo, HOST_NAME())



		DECLARE @ERROR_MESSAGE varchar(8000)
		SET @ERROR_MESSAGE=@Message
		RAISERROR (@ERROR_MESSAGE,16,1)
	END CATCH
END

*/

/*   To see the trigger information in the database, use the following:  */
--  SELECT * FROM sys.triggers
--  SELECT * FROM sys.trigger_events
