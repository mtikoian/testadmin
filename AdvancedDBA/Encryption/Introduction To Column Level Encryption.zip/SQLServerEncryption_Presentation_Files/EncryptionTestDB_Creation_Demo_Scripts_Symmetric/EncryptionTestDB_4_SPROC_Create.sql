USE EncryptionTestDB
GO

CREATE PROCEDURE dbo.xp_usp_Read_Applicant_Rec_With_Spec_SSN
@ssn		varchar(2000),
@spstat		int	OUTPUT,
@errmsg		varchar(200)	OUTPUT,
@recn		int	OUTPUT
WITH ENCRYPTION
AS
DECLARE @numrecs int
DECLARE @stmta nvarchar(4000)

SET NOCOUNT ON

SET @spstat = 1           -- go ahead and set to ok
SET @errmsg = ''          -- go ahead and set to ok
SET @recn = 0             -- go ahead and set to ok

BEGIN TRY

SET @stmta = N'OPEN SYMMETRIC KEY SymmKey1 DECRYPTION BY PASSWORD=''39eiIke$uY2$1!hBc5RfPm&%rFc3@L'''
EXEC sp_executesql @stmta


	SELECT AppID,AppFName,AppMName,AppLName,LTRIM(RTRIM(CONVERT(varchar(2000),DecryptByKey(AppSSN)))) AS AppSSN,LCHost,LCUser,LCDate
	FROM Applicant
	WHERE LTRIM(RTRIM(CONVERT(varchar(2000),DecryptByKey(AppSSN)))) = @ssn

	SET @numrecs = @@rowcount
	SET @recn = @numrecs

	if @numrecs=0
		BEGIN
			SET @spstat = -1
			SET @errmsg = 'No record selected'
			SET @recn = 0
		END

CLOSE SYMMETRIC KEY SymmKey1
--close all symmetric keys

	RETURN @spstat
END TRY
BEGIN CATCH
	DECLARE	@ErrorNo	int,
		@Severity	int,
		@State		int,
		@LineNo		int,
		@Message	varchar(1000)
	SELECT	@ErrorNo = ERROR_NUMBER(),
		@Severity = ERROR_SEVERITY(),
		@State = ERROR_STATE(),
		@LineNo = ERROR_LINE(),
		@Message = ERROR_MESSAGE()

	SET @errmsg = CONVERT(varchar(200), @Message)
	SET @spstat = 0

	INSERT INTO AppErrorLog
	VALUES (GETDATE(), USER, @Message, 'xp_usp_Read_Applicant_Rec_With_Spec_SSN', @ErrorNo, @Severity, @LineNo, HOST_NAME())
END CATCH
GO


CREATE PROCEDURE dbo.xp_usp_Read_Applicant_Rec
@appid		int,
@spstat		int	OUTPUT,
@errmsg		varchar(200)	OUTPUT,
@recn		int	OUTPUT
WITH ENCRYPTION
AS
DECLARE @numrecs int
DECLARE @stmta nvarchar(4000)

SET NOCOUNT ON

SET @spstat = 1           -- go ahead and set to ok
SET @errmsg = ''          -- go ahead and set to ok
SET @recn = 0             -- go ahead and set to ok

BEGIN TRY

SET @stmta = N'OPEN SYMMETRIC KEY SymmKey1 DECRYPTION BY PASSWORD=''39eiIke$uY2$1!hBc5RfPm&%rFc3@L'''
EXEC sp_executesql @stmta


	SELECT AppID,AppFName,AppMName,AppLName,LTRIM(RTRIM(CONVERT(varchar(2000),DecryptByKey(AppSSN)))) AS AppSSN,LCHost,LCUser,LCDate
	FROM Applicant
	WHERE AppID=@appid

	SET @numrecs = @@rowcount
	SET @recn = @numrecs

	if @numrecs=0
		BEGIN
			SET @spstat = -1
			SET @errmsg = 'No record selected'
			SET @recn = 0
		END

CLOSE SYMMETRIC KEY SymmKey1
--close all symmetric keys

	RETURN @spstat
END TRY
BEGIN CATCH
	DECLARE	@ErrorNo	int,
		@Severity	int,
		@State		int,
		@LineNo		int,
		@Message	varchar(1000)
	SELECT	@ErrorNo = ERROR_NUMBER(),
		@Severity = ERROR_SEVERITY(),
		@State = ERROR_STATE(),
		@LineNo = ERROR_LINE(),
		@Message = ERROR_MESSAGE()

	SET @errmsg = CONVERT(varchar(200), @Message)
	SET @spstat = 0

	INSERT INTO AppErrorLog
	VALUES (GETDATE(), USER, @Message, 'xp_usp_Read_Applicant_Rec', @ErrorNo, @Severity, @LineNo, HOST_NAME())
END CATCH
GO


CREATE PROCEDURE dbo.xp_usp_Read_All_Applicant_Rec
@spstat		int	OUTPUT,
@errmsg		varchar(200)	OUTPUT,
@recn		int	OUTPUT
WITH ENCRYPTION
AS
DECLARE @numrecs int
DECLARE @stmta nvarchar(4000)

SET NOCOUNT ON

SET @spstat = 1           -- go ahead and set to ok
SET @errmsg = ''          -- go ahead and set to ok
SET @recn = 0             -- go ahead and set to ok

BEGIN TRY

SET @stmta = N'OPEN SYMMETRIC KEY SymmKey1 DECRYPTION BY PASSWORD=''39eiIke$uY2$1!hBc5RfPm&%rFc3@L'''
EXEC sp_executesql @stmta


	SELECT AppID,AppFName,AppMName,AppLName,LTRIM(RTRIM(CONVERT(varchar(2000),DecryptByKey(AppSSN)))) AS AppSSN,LCHost,LCUser,LCDate
	FROM Applicant
	ORDER BY AppID


	SET @numrecs = @@rowcount
	SET @recn = @numrecs

	if @numrecs=0
		BEGIN
			SET @spstat = -1
			SET @errmsg = 'No record selected'
			SET @recn = 0
		END

CLOSE SYMMETRIC KEY SymmKey1
--close all symmetric keys

	RETURN @spstat
END TRY
BEGIN CATCH
	DECLARE	@ErrorNo	int,
		@Severity	int,
		@State		int,
		@LineNo		int,
		@Message	varchar(1000)
	SELECT	@ErrorNo = ERROR_NUMBER(),
		@Severity = ERROR_SEVERITY(),
		@State = ERROR_STATE(),
		@LineNo = ERROR_LINE(),
		@Message = ERROR_MESSAGE()

	SET @errmsg = CONVERT(varchar(200), @Message)
	SET @spstat = 0

	INSERT INTO AppErrorLog
	VALUES (GETDATE(), USER, @Message, 'xp_usp_Read_All_Applicant_Rec', @ErrorNo, @Severity, @LineNo, HOST_NAME())
END CATCH
GO

CREATE PROCEDURE dbo.xp_usp_Create_Applicant_Rec
@appfname		varchar(35),
@appmname		varchar(35),
@applname		varchar(35),
@appssn		varchar(2000),
@spstat		int	OUTPUT,
@errmsg		varchar(200)	OUTPUT,
@recn		int	OUTPUT
WITH ENCRYPTION
AS
DECLARE @numrecs int
DECLARE @stmta nvarchar(4000)


SET NOCOUNT ON

SET @spstat = 1           -- go ahead and set to ok
SET @errmsg = ''          -- go ahead and set to ok
SET @recn = 0             -- go ahead and set to ok

BEGIN TRY

	BEGIN TRANSACTION

	SET @stmta = N'OPEN SYMMETRIC KEY SymmKey1 DECRYPTION BY PASSWORD=''39eiIke$uY2$1!hBc5RfPm&%rFc3@L'''
	EXEC sp_executesql @stmta


	INSERT INTO Applicant (AppFName,AppMName,AppLName,AppSSN)
	VALUES (@appfname,@appmname,@applname,EncryptByKey(Key_GUID('SymmKey1'), @appssn))

	SET @recn = @@identity
	SET @numrecs = @@rowcount

	if @numrecs=0
		BEGIN
			SET @spstat = -1
			SET @errmsg = 'No record added'
			SET @recn = 0
		END


	CLOSE SYMMETRIC KEY SymmKey1
	--close all symmetric keys

	COMMIT TRANSACTION


	RETURN @spstat
END TRY
BEGIN CATCH
	DECLARE	@ErrorNo	int,
		@Severity	int,
		@State		int,
		@LineNo		int,
		@Message	varchar(1000)
	SELECT	@ErrorNo = ERROR_NUMBER(),
		@Severity = ERROR_SEVERITY(),
		@State = ERROR_STATE(),
		@LineNo = ERROR_LINE(),
		@Message = ERROR_MESSAGE()

	ROLLBACK TRAN
	
	close all symmetric keys

	SET @errmsg = CONVERT(varchar(200), @Message)
	SET @spstat = 0

	INSERT INTO AppErrorLog
	VALUES (GETDATE(), USER, @Message, 'xp_usp_Create_Applicant_Rec', @ErrorNo, @Severity, @LineNo, HOST_NAME())
END CATCH
GO


CREATE PROCEDURE dbo.xp_usp_Update_Applicant_Rec
@appid		int,
@appfname		varchar(35),
@appmname		varchar(35),
@applname		varchar(35),
@appssn		varchar(2000),
@spstat		int	OUTPUT,
@errmsg		varchar(200)	OUTPUT,
@recn		int	OUTPUT
WITH ENCRYPTION
AS
DECLARE @numrecs int
DECLARE @stmta nvarchar(4000)


SET NOCOUNT ON

SET @spstat = 1           -- go ahead and set to ok
SET @errmsg = ''          -- go ahead and set to ok
SET @recn = 0             -- go ahead and set to ok

BEGIN TRY

	BEGIN TRANSACTION

	SET @stmta = N'OPEN SYMMETRIC KEY SymmKey1 DECRYPTION BY PASSWORD=''39eiIke$uY2$1!hBc5RfPm&%rFc3@L'''
	EXEC sp_executesql @stmta



	UPDATE Applicant SET 
	AppFName=@appfname
	,AppMName=@appmname
	,AppLName=@applname
	,AppSSN=EncryptByKey(Key_GUID('SymmKey1'), @appssn)
	WHERE AppID = @appid

	SET @numrecs = @@rowcount
	SET @recn = @numrecs

	if @numrecs=0
		BEGIN
			SET @spstat = -1
			SET @errmsg = 'No record changed'
		END


	CLOSE SYMMETRIC KEY SymmKey1
	--close all symmetric keys
	

	COMMIT TRANSACTION

	RETURN @spstat
END TRY
BEGIN CATCH
	DECLARE	@ErrorNo	int,
		@Severity	int,
		@State		int,
		@LineNo		int,
		@Message	varchar(1000)
	SELECT	@ErrorNo = ERROR_NUMBER(),
		@Severity = ERROR_SEVERITY(),
		@State = ERROR_STATE(),
		@LineNo = ERROR_LINE(),
		@Message = ERROR_MESSAGE()

	ROLLBACK TRAN

	close all symmetric keys

	SET @errmsg = CONVERT(varchar(200), @Message)
	SET @spstat = 0

	INSERT INTO AppErrorLog
	VALUES (GETDATE(), USER, @Message, 'xp_usp_Update_Applicant_Rec', @ErrorNo, @Severity, @LineNo, HOST_NAME())
END CATCH
GO


/*   ==============================================================================================================  */


