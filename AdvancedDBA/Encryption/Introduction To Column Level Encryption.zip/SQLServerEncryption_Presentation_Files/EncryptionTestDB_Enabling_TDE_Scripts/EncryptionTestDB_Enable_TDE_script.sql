/* ========================================================================================================================= */
/* =                                                                                                                       = */
/* =                                                         Enable TDE                                                    = */
/* =                                                                                                                       = */
/* ========================================================================================================================= */



/* STEP 1:   Create DMK in the Master Database    */
USE master;
GO

CREATE MASTER KEY
ENCRYPTION BY PASSWORD = N'&tG2wEd4$QxC34#';
GO



/* ==================================================================================== */

/*  STEP 2:   Create a Server Certificate       */
USE master;
GO

CREATE CERTIFICATE Test_Certificate_TDE
WITH SUBJECT = N'Encryption Server Certificate for TDE';
GO



/* ==================================================================================== */
/*  STEP 2a:   Back up the Server Certificate    */
USE master;
GO

BACKUP CERTIFICATE Test_Certificate_TDE
TO FILE = N'C:\TDE_Server_Certificate.cer'
WITH PRIVATE KEY
(
	FILE = N'C:\TDE_Server_Certificate.pvk',
	ENCRYPTION BY PASSWORD = N'5Ty3$qSz8&h!KnM'
);
GO



/* ==================================================================================== */
/*  STEP 3:  Create a Database Encryption Key    */
USE EncryptionTestDB;
GO

CREATE DATABASE ENCRYPTION KEY
WITH ALGORITHM = AES_256
ENCRYPTION BY SERVER CERTIFICATE Test_Certificate_TDE;
GO



/* ==================================================================================== */
/*  STEP 4:   Turn on TDE                        */
USE EncryptionTestDB;
GO

ALTER DATABASE EncryptionTestDB
SET ENCRYPTION ON;
GO

