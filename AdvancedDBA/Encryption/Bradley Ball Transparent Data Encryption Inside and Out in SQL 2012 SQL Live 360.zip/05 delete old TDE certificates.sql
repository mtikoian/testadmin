/*============================================================
--@SQLBalls: SQLBalls@gmail.com
--Transparent Data Encryption - The Lightning Round
--

This Sample Code is provided for the purpose of illustration only and is not intended
to be used in a production environment.  THIS SAMPLE CODE AND ANY RELATED INFORMATION
ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, 
INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS
FOR A PARTICULAR PURPOSE.
==============================================================*/
/*
Enable the ability to set advance settings and xp_cmdshell
*/
exec sp_configure 'show advanced options', 1
go
reconfigure
go

exec sp_configure 'xp_cmdshell', 1

go
reconfigure
go

/*
Declare variable's to use in the code and set their values
*/
declare @myTable as table (
					[myID] [int] IDENTITY(1,1) NOT NULL,
					FileInfo varchar(max))
					
declare @myTable2 as table (
					[myID] [int] IDENTITY(1,1) NOT NULL,
					FileNames varchar(max))
declare @myTable3 as table (
					[myID] [int] IDENTITY(1,1) NOT NULL,
					FileNames varchar(max),
					FileCreationDate datetime)
declare @myTable4 as table (
					[myID] [int] IDENTITY(1,1) NOT NULL,
					FileNames varchar(max),
					FileCreationDate datetime)
					
declare @filecount int
declare @i int
declare @filepath varchar(100)
declare @sqlcmd varchar(max)
declare @sqlcmd2 varchar(max)
declare @sqlcmd3 varchar(max)
declare @filename1 varchar(100)

set @filepath = '"C:\Program Files\Microsoft SQL Server\MSSQL11.BRADSQL2012\MSSQL\Backup\"'
set @sqlcmd= 'master..xp_cmdshell ' + ''''+ 'dir ' + @filepath + ''''
set @sqlcmd2= 'master..xp_cmdshell ' + ''''+ 'dir ' + @filepath + ' /b' + ''''		
set @i = 1


/*
insert the contents of the direcotry path into our table
variables.  @myTable will hold the file names, @myTable2
will hold all of the file names and the size and date of
creation
*/
insert  @myTable exec(@sqlcmd)
insert  @myTable2 exec(@sqlcmd2)

/*
delete all info that is null only certificates should
be in this folder so we are not filtering criteria
*/
delete from
@myTable2 
where FileNames not like 'master%'and FileNames not like 'DatabaseCertificate%' or  FileNames is null
/*
Insert into @myTable3 the FileName and Date info from
the file directory, convert the char date text into a
real datetime field
*/
insert into @myTable3 
select 
mt2.filenames,
(
	convert(datetime,left((select mt1.fileinfo from @myTable mt1 where mt1.FileInfo like ('%' + mt2.FileNames + '%')), 20))
) as FileCreationDate
from @myTable2 mt2

/*
Reinsert all data into @myTable4 so the myID column 
will incriment at the same rate as the counter we will
use to delete these files from the directory
*/
insert into @myTable4 
select FileNames, FileCreationDate  
from @myTable3
order by FileCreationDate 
/*
Set the @filecount variable that we will use 
for our loop.  I set it to get a list of files
older than 4 days.  If you want to alter the time
frame here is where you would do that
*/
--set @filecount = (select COUNT (*) from @myTable3 where FileCreationDate < DATEADD(dd, -4,getdate()))

set @filecount = (select COUNT (*) from @myTable3 where FileCreationDate < getdate())


/*
Begin loop, @i should match @myTable4.myID, so that way
we can select a filename from @myTable4 to delete from
the file structure.
*/
while @i <= @filecount 
	Begin
		set @filename1 = (select filenames from @myTable4 where myID= @i)
		set @sqlCmd3 = 'master..xp_cmdshell' + ''''+ 'del /Q ' + @filepath + @filename1 + ''''

		print @filename1
		print @sqlcmd3
		exec(@sqlCmd3)


		set @filename1=''
		set @sqlcmd3=''
		set @i = @i + 1

	end

/*
Re-Configure the server not to display advanced options
Re-Configure the server not to allow xp_cmdshell commands
to be run
*/
exec sp_configure 'show advanced options', 1
go
reconfigure
go

exec sp_configure 'xp_cmdshell', 0

go
reconfigure
go
exec sp_configure 'show advanced options', 0
go
reconfigure