/*
Create Master Key
and Certificate
*/
USE master
GO
Create Master Key Encryption By Password='MasterKeyPass1'
GO
Create Certificate DatabaseCertificate With Subject='Dont Put Anything Importiant in the subject'
GO

/*
Create a Database Encryption Key
on Our Corrupt Database

set encryption to on
*/
use CorruptAdventure
go
create database encryption key
with algorithm = aes_256
encryption by server certificate DatabaseCertificate
go
ALTER DATABASE CorruptAdventure
SET ENCRYPTION ON
go
/*
validate our status
*/
SELECT 
    CASE e.encryption_state 
                WHEN 0 THEN 'No database encryption key present, no encryption' 
                WHEN 1 THEN 'Unencrypted' 
                WHEN 2 THEN 'Encryption in progress' 
                WHEN 3 THEN 'Encrypted' 
                WHEN 4 THEN 'Key change in progress' 
                WHEN 5 THEN 'Decryption in progress' 
    END AS encryption_state_desc,
      e.percent_complete,
    DB_NAME(e.database_id) AS DatabaseName,
		c.name as CertificateName,
            e.encryption_state 
    FROM sys.dm_database_encryption_keys AS e 
    LEFT JOIN master.sys.certificates AS c 
    ON e.encryptor_thumbprint = c.thumbprint 

/*
It just stalled out
Why would this happen?

A page checksum occurs on all pages
whent the TDE scan
*/
select * from msdb.dbo.suspect_pages
/*
database id 21
let's find our database
*/
select
	name
from
	sys.databases
where
	database_id=9
/*
A quick look at DBCC Page
will help us find what kind 
of Corruption we are dealing 
with
*/
DBCC TRACEON(3604)
GO
DBCC PAGE('CorruptAdventure', 1, 3874, 3)
GO
/*
Now we've got our object and
Index ID let's find out the index
that is corrupted
*/
select
	o.name as TableName
	,i.name as IndexName
	,i.type_desc
from
	sys.indexes i
	left join sys.objects o
	on i.object_id=o.object_id
where
	o.object_id=325576198
	and i.index_id=5

DBCC TRACEON(5004)
GO
DBCC TRACEOFF(5004)
GO