/*
Jasper Smith SQL Server MVP blog New in SQL 2008 : Transparent Data Encryption Part I & II http://sqlblogcasts.com/blogs/sqldbatips/archive/2008/06/24/new-in-sql-2008-transparent-data-encryption-overview.aspx

*/

SELECT 
    CASE e.encryption_state 
                WHEN 0 THEN 'No database encryption key present, no encryption' 
                WHEN 1 THEN 'Unencrypted' 
                WHEN 2 THEN 'Encryption in progress' 
                WHEN 3 THEN 'Encrypted' 
                WHEN 4 THEN 'Key change in progress' 
                WHEN 5 THEN 'Decryption in progress' 
    END AS encryption_state_desc,
      e.percent_complete,
    DB_NAME(e.database_id) AS DatabaseName,
		c.name as CertificateName,
            e.encryption_state 
    FROM sys.dm_database_encryption_keys AS e 
    LEFT JOIN master.sys.certificates AS c 
    ON e.encryptor_thumbprint = c.thumbprint 
    