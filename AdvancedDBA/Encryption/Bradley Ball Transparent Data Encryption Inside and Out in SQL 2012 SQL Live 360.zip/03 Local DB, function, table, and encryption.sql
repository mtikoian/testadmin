/*============================================================
--@SQLBalls: SQLBalls@gmail.com
--http://www.SQLBalls.com
--Transparent Data Encryption - Inside and Out
--

This Sample Code is provided for the purpose of illustration only and is not intended
to be used in a production environment.  THIS SAMPLE CODE AND ANY RELATED INFORMATION
ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, 
INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS
FOR A PARTICULAR PURPOSE.
==============================================================*/
USE [master]
GO
/*
Create the Master Key for the SQL Server
*/

CREATE MASTER KEY ENCRYPTION BY PASSWORD='MasterKeyPass1'
GO
/*
Create the Certificate that will be used
for database level encryption
*/
CREATE CERTIFICATE DatabaseCertificate WITH SUBJECT='Dont Put Sensetive Stuff Here!'
GO
/*
Create the Database
*/
if exists(select name from sys.databases where name='TDEDB')
Begin
	drop database TDEDB
end
CREATE DATABASE [TDEDB] 
go


USE TDEDB
GO
/*
Create Table
*/
IF EXISTS(SELECT * FROM SYS.TABLES WHERE NAME='tdeKeys')
BEGIN
	DROP TABLE dbo.tdeKeys
END
CREATE TABLE [dbo].[tdeKeys](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[nameText] [varchar](100) NOT NULL,
	[pwText] [varchar](100) NOT NULL,
) ON [PRIMARY]
GO
/*
Create Database Encryption Key
*/
CREATE DATABASE ENCRYPTION KEY
WITH ALGORITHM = AES_256
ENCRYPTION BY SERVER CERTIFICATE DatabaseCertificate
go
/*
Turn Encryption On
*/
ALTER DATABASE TDEDB
SET ENCRYPTION ON
GO
/*
Insert values into table
*/
INSERT INTO tdeKeys(nameText, pwText)
VALUES('master','MasterKeyPass1')
GO
/*
Insert Values into table
*/
INSERT INTO tdeKeys(nameText, pwText)
VALUES('bradprivkey','PrivateKeyPass1')

go
/*
Create User Function to retrieve password
*/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ufn_TDEDBGetpwd]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[ufn_TDEDBGetpwd]
go

CREATE FUNCTION ufn_TDEDBGetpwd(@keyNameText VARCHAR(50))
RETURNS VARCHAR(100)
AS
BEGIN
	DECLARE @returnPassword VARCHAR(100)
	
		SELECT @returnPassword =pwText FROM tdeKeys
		WHERE @keyNameText =nameText
		
		IF (@returnPassword is null)
			SET @returnPassword=''
		RETURN @returnPassword
END
