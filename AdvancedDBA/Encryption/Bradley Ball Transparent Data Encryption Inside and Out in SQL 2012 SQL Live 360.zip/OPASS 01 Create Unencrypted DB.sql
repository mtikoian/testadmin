/*============================================================
--@SQLBalls: SQLBalls@gmail.com
--BBall@Pragmaticworks.com
--HTTP://www.SQLBalls.com
--Transparent Data Encryption - The Lightning Round
--

This Sample Code is provided for the purpose of illustration only and is not intended
to be used in a production environment.  THIS SAMPLE CODE AND ANY RELATED INFORMATION
ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, 
INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS
FOR A PARTICULAR PURPOSE.
==============================================================*/
/*
Create TDE Database for demo
*/

USE master
GO

if exists(select * from sys.databases where name=N'TDE')
BEGIN
	DROP DATABASE TDE
END
CREATE DATABASE TDE
GO

USE TDE
GO

/*
Create Table for filler data
*/
IF EXISTS(SELECT NAME FROM SYS.TABLES WHERE NAME='tdeData')
BEGIN
	DROP TABLE	dbo.tdeData
END
CREATE TABLE [dbo].[tdeData](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[nameText] [varchar](100) default 'fakeSSN',
	[ssnText] [varchar](100) default '111-11-1111',
	[fillerText] [char](7600) default 'a'
) 
go
/*
Create filler data for TDE demo
*/
DECLARE @i int
SET @i = 0
 
BEGIN TRAN
	 
	WHILE (@i < 15000)
		BEGIN
			insert into tdeData default values
			set @i = @i +1
		END
COMMIT TRAN

use master 
go
BACKUP DATABASE [TDE] TO  DISK = N'C:\Program Files\Microsoft SQL Server\MSSQL11.BRADSQL2012\MSSQL\Backup\tde_unencrypted.bak' WITH NOFORMAT, NOINIT,  NAME = N'TDE-Full Database Backup', SKIP, NOREWIND, NOUNLOAD,  STATS = 10
GO

/*
--Don't Forget

DROP CERTIFICATE DatabaseCertificate
DROP MASTER KEY 

Create the Master Key for the SQL
 Server
*/
USE master
GO
Create Master Key Encryption By Password='MasterKeyPass1'
GO

/*
Create the Certificate that will be used
for database level encryption
*/
Create Certificate DatabaseCertificate With Subject='Dont Put Anything Importiant in the subject'
GO
/*
Create Database Encryption Key
*/
use TDE
go
create database encryption key
with algorithm = aes_256
encryption by server certificate DatabaseCertificate
go
/*
Turn Encryption On
*/
Alter Database tde
Set Encryption on
go
waitfor delay '00:00:10'
go
use master
go
BACKUP DATABASE [TDE] TO  DISK = N'C:\Program Files\Microsoft SQL Server\MSSQL11.BRADSQL2012\MSSQL\Backup\tde_encrypted.bak' WITH NOFORMAT, NOINIT,  NAME = N'TDE-Full Database Backup', SKIP, NOREWIND, NOUNLOAD,  STATS = 10
GO
/*
Print out the backup command
Using Dynamic Script
*/

USE MASTER 
go

declare @filepath varchar(max);
declare @filename1 varchar(100);
declare @filename2 varchar(100);
declare @sqlcmd varchar(max);
declare @password varchar(100);
declare @datestring varchar(50);

set @datestring = left(CONVERT(VARCHAR(20), convert(datetime,GETDATE()),112) + REPLACE(CONVERT(VARCHAR(20), GETDATE(),108),':',''),8)
set @filepath='C:\Program Files\Microsoft SQL Server\MSSQL11.BRADSQL2012\MSSQL\Backup\'
set @filename1 = 'DatabaseCertificate'+ @datestring +'.cer'
set @filename2 ='bradprivkey'+ @datestring +'.key'
set @password='PrivateKeyPass1'
set @sqlcmd = 'BACKUP CERTIFICATE DatabaseCertificate TO FILE =' + ''''+ @filepath + @filename1 + '''' + 'WITH PRIVATE KEY ( FILE =' + '''' + @filepath + @filename2 + '''' + ', ENCRYPTION BY PASSWORD =' + '''' + @password +'''' + ')'

print (@sqlcmd)

BACKUP CERTIFICATE DatabaseCertificate TO FILE ='C:\Program Files\Microsoft SQL Server\MSSQL11.BRADSQL2012\MSSQL\Backup\DatabaseCertificate20120328.cer'WITH PRIVATE KEY ( FILE ='C:\Program Files\Microsoft SQL Server\MSSQL11.BRADSQL2012\MSSQL\Backup\bradprivkey20120328.key', ENCRYPTION BY PASSWORD ='PrivateKeyPass1')


Use master
go
--=======================================
--Drop the Database Certificate
--=======================================
DROP CERTIFICATE DatabaseCertificate
go
sp_detach_db tde
go

/*
attempt to Re Attach our database

Attempt to restore our encrypted backup

sp_attach_db is depriceated in SQL 2008
so we use create db for attach
*/
USE [master]
GO

CREATE DATABASE [TDE] ON 
( FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL11.BRADSQL2012\MSSQL\DATA\TDE.mdf' ),
( FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL11.BRADSQL2012\MSSQL\DATA\TDE_log.ldf' )
 FOR ATTACH
GO

/*
Insert Certificate Path from our backup output
*/

USE master
go
Create Certificate DatabaseCertificate 
From File= 'C:\Program Files\Microsoft SQL Server\MSSQL11.BRADSQL2012\MSSQL\Backup\DatabaseCertificate20120510.cer'
With Private Key (file='C:\Program Files\Microsoft SQL Server\MSSQL11.BRADSQL2012\MSSQL\Backup\bradprivkey20120510.key', decryption by password = 'PrivateKeyPass1')


/*
Drop the Database Certificate
*/
USE master
GO
DROP CERTIFICATE DatabaseCertificate

/*
Restart SQL Server
*/

/*
Unencrypting
*/
USE TDE
GO
Alter Database tde
Set Encryption off
GO

DROP DATABASE ENCRYPTION KEY
GO