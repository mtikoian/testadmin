/*============================================================
--@SQLBalls: SQLBalls@gmail.com
--Transparent Data Encryption - The Lightning Round
--

This Sample Code is provided for the purpose of illustration only and is not intended
to be used in a production environment.  THIS SAMPLE CODE AND ANY RELATED INFORMATION
ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, 
INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS
FOR A PARTICULAR PURPOSE.
==============================================================*/
/*
	First we will backup
	the Master Key for our
	SQL Server
*/
use master;
go

/*
Declare  our variables
*/
DECLARE @filepath VARCHAR(max);
DECLARE @filename1 VARCHAR(100);
DECLARE @sqlcmd VARCHAR(max);
DECLARE @password VARCHAR(100);
DECLARE @datestring VARCHAR(50);

/*
Set our variables
@datestring will be a datetime stamp to make our certificate name specific by day
@filepath is the directory location you want your key to be stored
@filename1 is what we are calling our master key backup
@password calls the TDE function to get our master key password
@sqlcmd creates our dynamic sql that will be executed
*/
SET @datestring = left(CONVERT(VARCHAR(20),convert(DATETIME,GETDATE()),112) + REPLACE(CONVERT(VARCHAR(20), GETDATE(),108),':',''),8)
SET @filepath ='C:\Program Files\Microsoft SQL Server\MSSQL11.BRADSQL2012\MSSQL\Backup\'
SET @filename1='masterkey' + @datestring 
SET @password= TDEDB.dbo.ufn_TDEDBGetpwd('master')
SET @sqlcmd ='backup Master Key to File=' +''''+ @filepath + @filename1 +''''+ ' encryption by password ='+ ''''+@password +''''
EXEC (@sqlcmd)
GO
/*
Now we backup our certificate
we will wrap this in a private key
and back that up as well

We start by declaring our Variables
*/

DECLARE @filepath VARCHAR(max);
DECLARE @filename1 VARCHAR(100);
DECLARE @filename2 VARCHAR(100);
DECLARE @sqlcmd VARCHAR(max);
DECLARE @password VARCHAR(100);
DECLARE @datestring VARCHAR(50);

/*
Set our variables
@datestring will be a datetime stamp to make our certificate name specific by day
@filepath is the directory location you want your cert & key to be stored
@filename1 is what we are calling our Certificate backup
@filename2 is what we are calling our Private Key backup
@password calls the TDE function to get our master key password
@sqlcmd creates our dynamic sql that will be executed
*/
set @datestring = left(CONVERT(VARCHAR(20), convert(DATETIME,GETDATE()),112) + REPLACE(CONVERT(VARCHAR(20), GETDATE(),108),':',''),8)
SET @filepath='C:\Program Files\Microsoft SQL Server\MSSQL11.BRADSQL2012\MSSQL\Backup\'
SET @filename1 = 'DatabaseCertificate'+ @datestring +'.cer'
SET @filename2 ='DatabaseCertificatePrivateKey'+ @datestring +'.key'
SET @password=TDEDB.dbo.ufn_TDEDBGetpwd('bradprivkey')
SET @sqlcmd = 'BACKUP CERTIFICATE DatabaseCertificate TO FILE =' + ''''+ @filepath + @filename1 + '''' + 'WITH PRIVATE KEY ( FILE =' + '''' + @filepath + @filename2 + '''' + ', ENCRYPTION BY PASSWORD =' + '''' + @password +'''' + ')'

EXEC (@sqlcmd)
GO