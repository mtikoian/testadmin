USE [master]
RESTORE DATABASE [CorruptAdventure] FROM  DISK = N'C:\Users\bball\Documents\Presentations\SQL Live 360\Transparent Data Encryption Inside and Out\CoruptAdventure_Corupted.bak' WITH  FILE = 1,  MOVE N'AdventureWorksDW2008R2_Data' TO N'C:\Program Files\Microsoft SQL Server\MSSQL11.BRADSQL2012\MSSQL\DATA\CorruptAdventure.bak',  MOVE N'AdventureWorksDW2008R2_Log' TO N'C:\Program Files\Microsoft SQL Server\MSSQL11.BRADSQL2012\MSSQL\DATA\CorruptAdventure_log.ldf',  NOUNLOAD,  REPLACE,  STATS = 5

GO


