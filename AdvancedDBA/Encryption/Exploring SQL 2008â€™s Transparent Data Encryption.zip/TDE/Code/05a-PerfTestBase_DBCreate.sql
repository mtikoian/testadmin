SET NOCOUNT ON
USE master
GO

IF EXISTS (SELECT * FROM sys.databases WHERE [name] = 'PerfTestBase')
    DROP DATABASE PerfTestBase
GO

PRINT 'CREATE DATABASE PerfTestBase'
GO
CREATE DATABASE PerfTestBase ON (
	NAME        = N'PerfTestBase_Primary',
	FILENAME    = N'C:\PerfTestBase_Primary.MDF',
	SIZE        = 4,
	FILEGROWTH  = 10%
)
LOG ON (
	NAME = N'PerfTestBase_Log',
	FILENAME    = N'C:\PerfTestBase_Log.LDF',
	SIZE        = 2,
	FILEGROWTH  = 10%
)
GO

USE PerfTestBase
GO

EXEC sp_changedbowner 'sa'
GO

PRINT 'Set database options'
GO
ALTER DATABASE PerfTestBase SET ANSI_NULLS              ON
ALTER DATABASE PerfTestBase SET ANSI_PADDING            ON
ALTER DATABASE PerfTestBase SET ANSI_WARNINGS           ON
ALTER DATABASE PerfTestBase SET ARITHABORT              ON
ALTER DATABASE PerfTestBase SET CONCAT_NULL_YIELDS_NULL ON
ALTER DATABASE PerfTestBase SET NUMERIC_ROUNDABORT      OFF
ALTER DATABASE PerfTestBase SET QUOTED_IDENTIFIER       ON
GO

--PRINT 'SET RECOVERY Simple'
--ALTER DATABASE PerfTestBase SET RECOVERY Simple
--GO

CREATE SCHEMA Perf
GO

PRINT '<< DONE >>'
GO
