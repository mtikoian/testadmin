SET NOCOUNT ON
--USE PerfTestBase
--USE PerfTestTde
GO

IF EXISTS (SELECT * FROM sys.tables WHERE [name] = 'Purchase')
    DROP TABLE Perf.Purchase
GO
IF EXISTS (SELECT * FROM sys.tables WHERE [name] = 'Vendor')
    DROP TABLE Perf.Vendor
GO
IF EXISTS (SELECT * FROM sys.tables WHERE [name] = 'Card')
    DROP TABLE Perf.[Card]
GO

-- ==============================================================
PRINT N'Create table Card'
GO
CREATE TABLE Perf.[Card] (
    CardID          int         NOT NULL        IDENTITY,
    CardNumber      bigint      NOT NULL,
    SecurityCode    smallint    NOT NULL,
    SecureString    char(36)    NOT NULL,

    CONSTRAINT PK_Card PRIMARY KEY CLUSTERED (CardID)
)
GO

CREATE UNIQUE NONCLUSTERED INDEX UIX_Card_CardNumber_SecurityCode ON Perf.[Card] (
    CardNumber,
    SecurityCode
)
GO

CREATE NONCLUSTERED INDEX IX_Card_SecurityCode_CardNumber ON Perf.[Card] (
    SecurityCode,
    CardNumber
)
GO

CREATE NONCLUSTERED INDEX IX_Card_SecureString ON Perf.[Card] (
    SecureString
)
GO

-- ==============================================================
PRINT N'Create table Vendor'
GO
CREATE TABLE Perf.Vendor (
    VendorID        int         NOT NULL        IDENTITY,
    BusinessName    varchar(40) NOT NULL,
    Address1        varchar(40) NOT NULL,
    Address2        varchar(40) NULL,
    City            varchar(40) NOT NULL,
    [State]         char(2)     NOT NULL,
    ZipCode         varchar(10) NOT NULL,

    CONSTRAINT PK_Vendor PRIMARY KEY CLUSTERED (VendorID)
)
GO

CREATE NONCLUSTERED INDEX IX_Vendor_BusinessName ON Perf.Vendor (
    BusinessName
)
GO

-- ==============================================================
PRINT N'Create table Purchase'
GO
CREATE TABLE Perf.Purchase (
    PurchaseID      int         NOT NULL        IDENTITY,
    CardID          int         NOT NULL,
    VendorID        int         NOT NULL,
    Amount          money       NOT NULL,

    CONSTRAINT PK_Purchase PRIMARY KEY CLUSTERED (PurchaseID),
    CONSTRAINT FK_Purchase_Card FOREIGN KEY (CardID) REFERENCES Perf.Card (CardID),
    CONSTRAINT FK_Purchase_Vendor FOREIGN KEY (VendorID) REFERENCES Perf.Vendor (VendorID)
)
GO

CREATE NONCLUSTERED INDEX IX_Purchase_CardID ON Perf.Purchase (
    CardID
)
GO

CREATE NONCLUSTERED INDEX IX_Purchase_VendorID ON Perf .Purchase (
    VendorID
)
GO

PRINT '<< DONE >>'
GO
