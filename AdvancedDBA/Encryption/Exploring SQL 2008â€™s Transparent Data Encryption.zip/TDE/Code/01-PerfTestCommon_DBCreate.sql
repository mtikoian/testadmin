SET NOCOUNT ON
USE master
GO

-- This database is used to store settings and results
IF EXISTS (SELECT * FROM sys.databases WHERE [name] = 'PerfTestCommon')
    DROP DATABASE PerfTestCommon
GO

PRINT 'CREATE DATABASE PerfTestCommon'
GO
CREATE DATABASE PerfTestCommon ON (
	NAME        = N'PerfTestCommon_Primary',
	FILENAME    = N'C:\PerfTestCommon_Primary.MDF',
	SIZE        = 4,
	FILEGROWTH  = 10%
)
LOG ON (
	NAME = N'PerfTestCommon_Log',
	FILENAME    = N'C:\PerfTestCommon_Log.LDF',
	SIZE        = 2,
	FILEGROWTH  = 10%
)
GO

USE PerfTestCommon
GO

EXEC sp_changedbowner 'sa'
GO

PRINT 'Set database options'
GO
ALTER DATABASE PerfTestCommon SET ANSI_NULLS              ON
ALTER DATABASE PerfTestCommon SET ANSI_PADDING            ON
ALTER DATABASE PerfTestCommon SET ANSI_WARNINGS           ON
ALTER DATABASE PerfTestCommon SET ARITHABORT              ON
ALTER DATABASE PerfTestCommon SET CONCAT_NULL_YIELDS_NULL ON
ALTER DATABASE PerfTestCommon SET NUMERIC_ROUNDABORT      OFF
ALTER DATABASE PerfTestCommon SET QUOTED_IDENTIFIER       ON
GO

CREATE SCHEMA Perf
GO

PRINT '<< DONE >>'
GO
