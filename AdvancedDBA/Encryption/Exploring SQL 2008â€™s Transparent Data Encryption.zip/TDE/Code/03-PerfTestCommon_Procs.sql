SET NOCOUNT ON
USE PerfTestCommon
GO

-- =============================================================
PRINT '__BuildMessage'
-- =============================================================
GO
IF EXISTS (SELECT * FROM sys.procedures WHERE [name] = '__BuildMessage')
    DROP PROCEDURE Perf.__BuildMessage
GO
CREATE PROCEDURE Perf.__BuildMessage (
    @Msg     nvarchar(255)        OUTPUT,
    @Name1   nvarchar(64) = NULL,
    @Value1  nvarchar(64) = NULL,
    @Name2   nvarchar(64) = NULL,
    @Value2  nvarchar(64) = NULL,
    @Name3   nvarchar(64) = NULL,
    @Value3  nvarchar(64) = NULL,
    @Name4   nvarchar(64) = NULL,
    @Value4  nvarchar(64) = NULL,
    @Name5   nvarchar(64) = NULL,
    @Value5  nvarchar(64) = NULL,
    @Name6   nvarchar(64) = NULL,
    @Value6  nvarchar(64) = NULL,
    @Name7   nvarchar(64) = NULL,
    @Value7  nvarchar(64) = NULL,
    @Name8   nvarchar(64) = NULL,
    @Value8  nvarchar(64) = NULL,
    @Name9   nvarchar(64) = NULL,
    @Value9  nvarchar(64) = NULL,
    @Name10  nvarchar(64) = NULL,
    @Value10 nvarchar(64) = NULL,
    @Name11  nvarchar(64) = NULL,
    @Value11 nvarchar(64) = NULL,
    @Name12  nvarchar(64) = NULL,
    @Value12 nvarchar(64) = NULL,
    @Name13  nvarchar(64) = NULL,
    @Value13 nvarchar(64) = NULL,
    @Name14  nvarchar(64) = NULL,
    @Value14 nvarchar(64) = NULL,
    @Name15  nvarchar(64) = NULL,
    @Value15 nvarchar(64) = NULL,
    @Name16  nvarchar(64) = NULL,
    @Value16 nvarchar(64) = NULL,
    @Name17  nvarchar(64) = NULL,
    @Value17 nvarchar(64) = NULL,
    @Name18  nvarchar(64) = NULL,
    @Value18 nvarchar(64) = NULL,
    @Name19  nvarchar(64) = NULL,
    @Value19 nvarchar(64) = NULL,
    @Name20  nvarchar(64) = NULL,
    @Value20 nvarchar(64) = NULL
) AS
BEGIN
    SET NOCOUNT ON

    -- Name/Value 1
    IF @Name1 IS NULL BEGIN
        RETURN(0)
    END
    -- This line begins the string
    SELECT @Msg = N'(' + @Name1 + N': ' + ISNULL(@Value1, N'NULL') + N')'

    -- Name/Value 2
    IF @Name2 IS NULL BEGIN
        RETURN(0)
    END
    SELECT @Msg = @Msg + N' (' + @Name2 + N': ' + ISNULL(@Value2, N'NULL') + N')'

    -- Name/Value 3
    IF @Name3 IS NULL BEGIN
        RETURN(0)
    END
    SELECT @Msg = @Msg + N' (' + @Name3 + N': ' + ISNULL(@Value3, N'NULL') + N')'

    -- Name/Value 4
    IF @Name4 IS NULL BEGIN
        RETURN(0)
    END
    SELECT @Msg = @Msg + N' (' + @Name4 + N': ' + ISNULL(@Value4, N'NULL') + N')'

    -- Name/Value 5
    IF @Name5 IS NULL BEGIN
        RETURN(0)
    END
    SELECT @Msg = @Msg + N' (' + @Name5 + N': ' + ISNULL(@Value5, N'NULL') + N')'

    -- Name/Value 6
    IF @Name6 IS NULL BEGIN
        RETURN(0)
    END
    SELECT @Msg = @Msg + N' (' + @Name6 + N': ' + ISNULL(@Value6, N'NULL') + N')'

    -- Name/Value 7
    IF @Name7 IS NULL BEGIN
        RETURN(0)
    END
    SELECT @Msg = @Msg + N' (' + @Name7 + N': ' + ISNULL(@Value7, N'NULL') + N')'

    -- Name/Value 8
    IF @Name8 IS NULL BEGIN
        RETURN(0)
    END
    SELECT @Msg = @Msg + N' (' + @Name8 + N': ' + ISNULL(@Value8, N'NULL') + N')'

    -- Name/Value 9
    IF @Name9 IS NULL BEGIN
        RETURN(0)
    END
    SELECT @Msg = @Msg + N' (' + @Name9 + N': ' + ISNULL(@Value9, N'NULL') + N')'

    -- Name/Value 10
    IF @Name10 IS NULL BEGIN
        RETURN(0)
    END
    SELECT @Msg = @Msg + N' (' + @Name10 + N': ' + ISNULL(@Value10, N'NULL') + N')'

    -- Name/Value 11
    IF @Name11 IS NULL BEGIN
        RETURN(0)
    END
    SELECT @Msg = @Msg + N' (' + @Name11 + N': ' + ISNULL(@Value11, N'NULL') + N')'

    -- Name/Value 12
    IF @Name12 IS NULL BEGIN
        RETURN(0)
    END
    SELECT @Msg = @Msg + N' (' + @Name12 + N': ' + ISNULL(@Value12, N'NULL') + N')'

    -- Name/Value 13
    IF @Name13 IS NULL BEGIN
        RETURN(0)
    END
    SELECT @Msg = @Msg + N' (' + @Name13 + N': ' + ISNULL(@Value13, N'NULL') + N')'

    -- Name/Value 14
    IF @Name14 IS NULL BEGIN
        RETURN(0)
    END
    SELECT @Msg = @Msg + N' (' + @Name14 + N': ' + ISNULL(@Value14, N'NULL') + N')'

    -- Name/Value 15
    IF @Name15 IS NULL BEGIN
        RETURN(0)
    END
    SELECT @Msg = @Msg + N' (' + @Name15 + N': ' + ISNULL(@Value15, N'NULL') + N')'

    -- Name/Value 16
    IF @Name16 IS NULL BEGIN
        RETURN(0)
    END
    SELECT @Msg = @Msg + N' (' + @Name16 + N': ' + ISNULL(@Value16, N'NULL') + N')'

    -- Name/Value 17
    IF @Name17 IS NULL BEGIN
        RETURN(0)
    END
    SELECT @Msg = @Msg + N' (' + @Name17 + N': ' + ISNULL(@Value17, N'NULL') + N')'

    -- Name/Value 18
    IF @Name18 IS NULL BEGIN
        RETURN(0)
    END
    SELECT @Msg = @Msg + N' (' + @Name18 + N': ' + ISNULL(@Value18, N'NULL') + N')'

    -- Name/Value 19
    IF @Name19 IS NULL BEGIN
        RETURN(0)
    END
    SELECT @Msg = @Msg + N' (' + @Name19 + N': ' + ISNULL(@Value19, N'NULL') + N')'

    -- Name/Value 20
    IF @Name20 IS NULL BEGIN
        RETURN(0)
    END
    SELECT @Msg = @Msg + N' (' + @Name20 + N': ' + ISNULL(@Value20, N'NULL') + N')'

    RETURN(0)
END
GO

-- =============================================================
PRINT 'SettingRead'
-- =============================================================
GO
IF EXISTS (SELECT * FROM sys.procedures WHERE [name] = 'SettingRead')
    DROP PROCEDURE Perf.SettingRead
GO
CREATE PROCEDURE Perf.SettingRead (
    @Run            bit         OUTPUT,
    @LoopMax        int         OUTPUT,
    @delayEveryN    int         OUTPUT,
    @delayString    char(8)     OUTPUT,
    @MaxVendorCt    int         OUTPUT,
    @MaxCardCt      int         OUTPUT,
    @MaxPurchCt     int         OUTPUT,
    @LoopsRead      tinyint     OUTPUT,
    @LoopsUpdate    tinyint     OUTPUT,
    @LoopsInsert    tinyint     OUTPUT
) AS
-- Read Setting
BEGIN
    SELECT
        @Run            = Run,
        @LoopMax        = LoopMax,
        @DelayEveryN    = DelayEveryN,
        @DelayString    = DelayString,
        @MaxVendorCt    = MaxVendorCt,
        @MaxCardCt      = MaxCardCt,
        @MaxPurchCt     = MaxPurchCt,
        @LoopsRead      = LoopsRead,
        @LoopsUpdate    = LoopsUpdate,
        @LoopsInsert    = LoopsInsert
    FROM Perf.TestSetting
    WHERE EntryID = 1

    RETURN(0)
END
GO

-- =============================================================
PRINT 'SettingUpsert'
-- =============================================================
GO
IF EXISTS (SELECT * FROM sys.procedures WHERE [name] = 'SettingUpsert')
    DROP PROCEDURE Perf.SettingUpsert
GO
CREATE PROCEDURE Perf.SettingUpsert (
    @Run            bit,
    @LoopMax        int     = NULL,
    @DelayEveryN    int     = NULL,
    @DelayString    char(8) = NULL,
    @MaxVendorCt    int     = NULL,
    @MaxCardCt      int     = NULL,
    @MaxPurchCt     int     = NULL,
    @LoopsRead      tinyint = NULL,
    @LoopsUpdate    tinyint = NULL,
    @LoopsInsert    tinyint = NULL
)AS
-- Update Setting. If a row does not exist, create one with the new values.
BEGIN
    DECLARE @error    int
    DECLARE @rowcount int

    IF EXISTS (
        SELECT 1
        FROM Perf.TestSetting
    ) BEGIN
        UPDATE Perf.TestSetting
        SET
            Run                = @Run,
            LoopMax         = @LoopMax,
            DelayEveryN     = @DelayEveryN,
            DelayString     = @DelayString,
            MaxVendorCt     = @MaxVendorCt,
            MaxCardCt       = @MaxCardCt,
            MaxPurchCt      = @MaxPurchCt,
            LoopsRead       = @LoopsRead,
            LoopsUpdate     = @LoopsUpdate,
            LoopsInsert     = @LoopsInsert
    END
    ELSE BEGIN
        INSERT INTO Perf.TestSetting (
            Run,
            LoopMax,
            DelayEveryN,
            DelayString,
            MaxVendorCt,
            MaxCardCt,
            MaxPurchCt,
            LoopsRead,
            LoopsUpdate,
            LoopsInsert
        )
        VALUES (
            @Run,
            @LoopMax,
            @DelayEveryN,
            @DelayString,
            @MaxVendorCt,
            @MaxCardCt,
            @MaxPurchCt,
            @LoopsRead,
            @LoopsUpdate,
            @LoopsInsert
        )
    END

    SELECT
        @error    = @@error,
        @rowcount = @@rowcount

    IF @error <> 0 OR @rowcount <> 1 BEGIN
        DECLARE @msg      nvarchar(255)
        DECLARE @spName   nvarchar(50)

        SELECT @spName = Object_Name(@@ProcID)
        EXEC __BuildMessage @msg OUTPUT,
            N'Run', @Run,
            N'LoopMax', @LoopMax,
            N'MaxVendorCt', @MaxVendorCt,
            N'MaxCardCt', @MaxCardCt,
            N'MaxPurchCt', @MaxPurchCt

        RAISERROR('SP %s failed with error %d, rowcount %d. %s', 10, 1, @spName, @error, @rowcount, @msg) WITH SETERROR
        RETURN(-1)
    END

    RETURN(0)
END
GO

-- =============================================================
PRINT 'TestResultCreate'
-- =============================================================
GO
IF EXISTS (SELECT * FROM sys.procedures WHERE [name] = 'TestResultCreate')
    DROP PROCEDURE Perf.TestResultCreate
GO
CREATE PROCEDURE Perf.TestResultCreate (
    @DatabaseName   sysname,
    @LoopMax        int,
    @DelayEveryN    int,
    @DelayString    char(8),
    @MaxVendorCt    int,
    @MaxCardCt      int,
    @MaxPurchCt     int,
    @LoopsRead      tinyint,
    @LoopsUpdate    tinyint,
    @LoopsInsert    tinyint,
    @ElapsedTimeMs  int,
    @RunCompleted   datetime
)AS
-- Record the results of a test
BEGIN
    DECLARE @error    int
    DECLARE @rowcount int

    INSERT INTO Perf.TestResult (
        DatabaseName,
        LoopMax,
        DelayEveryN,
        DelayString,
        MaxVendorCt,
        MaxCardCt,
        MaxPurchCt,
        LoopsRead,
        LoopsUpdate,
        LoopsInsert,
        ElapsedTimeMs,
        RunCompleted
    )
    VALUES (
        @DatabaseName,
        @LoopMax,
        @DelayEveryN,
        @DelayString,
        @MaxVendorCt,
        @MaxCardCt,
        @MaxPurchCt,
        @LoopsRead,
        @LoopsUpdate,
        @LoopsInsert,
        @ElapsedTimeMs,
        @RunCompleted
    )

    SELECT
        @error    = @@error,
        @rowcount = @@rowcount

    IF @error <> 0 OR @rowcount <> 1 BEGIN
        DECLARE @msg      nvarchar(255)
        DECLARE @spName   nvarchar(50)

        SELECT @spName = Object_Name(@@ProcID)
        EXEC __BuildMessage @msg OUTPUT,
            N'DatabaseName', @DatabaseName,
            N'LoopMax', @LoopMax,
            N'MaxVendorCt', @MaxVendorCt,
            N'MaxCardCt', @MaxCardCt,
            N'MaxPurchCt', @MaxPurchCt,
            N'ElapsedTimeMs', @ElapsedTimeMs

        RAISERROR('SP %s failed with error %d, rowcount %d. %s', 10, 1, @spName, @error, @rowcount, @msg) WITH SETERROR
        RETURN(-1)
    END

    RETURN(0)
END
GO

PRINT '<< DONE >>'
GO
