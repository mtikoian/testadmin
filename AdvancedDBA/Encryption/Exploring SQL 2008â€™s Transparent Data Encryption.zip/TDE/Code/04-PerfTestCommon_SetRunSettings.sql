SET NOCOUNT ON
USE PerfTestCommon
GO

DECLARE @run            bit
DECLARE @loopMax        int
DECLARE @delayEveryN    int
DECLARE @delayString    char(8)
DECLARE @maxVendorCt    int
DECLARE @maxCardCt      int
DECLARE @maxPurchCt     int
DECLARE @loopsRead      tinyint
DECLARE @loopsUpdate    tinyint
DECLARE @loopsInsert    tinyint

SET @loopMax        = 1000
SET @MaxVendorCt    = @loopMax / 10
SET @MaxCardCt      = @loopMax / 10
SET @MaxPurchCt     = @loopMax / 10
SET @delayEveryN    = 100
SET @delayString    = '00:00:00'
-- Of every 10 loops, x are reads, y are updates, and z are inserts
SET @loopsRead      = 10
SET @loopsUpdate    = 0
SET @loopsInsert    = 0

IF (@loopsRead + @loopsUpdate + @loopsInsert) <> 10 BEGIN
    RAISERROR('Error: Set the values for @loopsRead, @loopsUpdate, and @loopsInsert so they add up to 10.', 16, 1)
    RETURN
END

EXEC PerfTestCommon.Perf.SettingUpsert
    @Run            = 1,
    @LoopMax        = @loopMax,
    @DelayEveryN    = @delayEveryN,
    @DelayString    = @delayString,
    @MaxVendorCt    = @MaxVendorCt,
    @MaxCardCt      = @MaxCardCt,
    @MaxPurchCt     = @MaxPurchCt,
    @loopsRead      = @LoopsRead,
    @loopsUpdate    = @LoopsUpdate,
    @loopsInsert    = @LoopsInsert

EXEC PerfTestCommon.Perf.SettingRead
    @Run            = @run          OUTPUT,
    @LoopMax        = @loopMax      OUTPUT,
    @DelayEveryN    = @delayEveryN  OUTPUT,
    @DelayString    = @delayString  OUTPUT,
    @MaxVendorCt    = @maxVendorCt  OUTPUT,
    @MaxCardCt      = @maxCardCt    OUTPUT,
    @MaxPurchCt     = @maxPurchCt   OUTPUT,
    @LoopsRead      = @loopsRead    OUTPUT,
    @LoopsUpdate    = @loopsUpdate  OUTPUT,
    @LoopsInsert    = @loopsInsert  OUTPUT

SELECT
    @run            AS '@run',
    @loopMax        AS '@loopMax',
    @DelayEveryN    AS '@delayEveryN',
    @DelayString    AS '@delayString',
    @maxVendorCt    AS '@maxVendorCt',
    @maxCardCt      AS '@maxCardCt',
    @maxPurchCt     AS '@maxPurchCt',
    @loopsRead      AS '@loopsRead',
    @loopsUpdate    AS '@loopsUpdate',
    @loopsInsert    AS '@loopsInsert'
GO

/*
SELECT * FROM Perf.TestResults
SELECT
    AVG(ElapsedTimeMs)  AS AvgElapsedTimeMs,
    COUNT(*)            AS RecordCt
FROM Perf.TestResults

-- To stop run:
EXEC PerfTestCommon.Perf.SettingUpsert
    @Run    = 0
*/
