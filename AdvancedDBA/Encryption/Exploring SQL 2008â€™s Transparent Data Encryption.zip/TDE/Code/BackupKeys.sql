SET NOCOUNT ON
USE master
GO

-- These will fail if the named files already exist
BACKUP SERVICE MASTER KEY
TO FILE = N'C:\ServiceMaster_20090602.key'
ENCRYPTION BY PASSWORD = N'r-SwEbrE?eP9&f9y'
GO
BACKUP MASTER KEY
TO FILE = N'C:\EncryptionDB_20090602.key'
ENCRYPTION BY PASSWORD = N'na#Aw6EdUSuwe-Ra'
GO

PRINT '<< DONE >>'
GO
