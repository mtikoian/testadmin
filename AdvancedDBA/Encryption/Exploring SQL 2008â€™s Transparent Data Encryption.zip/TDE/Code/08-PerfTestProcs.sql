SET NOCOUNT ON
--USE PerfTestBase
--USE PerfTestTde
GO

-- =============================================================
PRINT '__BuildMessage'
-- =============================================================
GO
IF EXISTS (SELECT * FROM sys.procedures WHERE [name] = '__BuildMessage')
    DROP PROCEDURE Perf.__BuildMessage
GO
CREATE PROCEDURE Perf.__BuildMessage (
    @Msg     nvarchar(255)        OUTPUT,
    @Name1   nvarchar(64) = NULL,
    @Value1  nvarchar(64) = NULL,
    @Name2   nvarchar(64) = NULL,
    @Value2  nvarchar(64) = NULL,
    @Name3   nvarchar(64) = NULL,
    @Value3  nvarchar(64) = NULL,
    @Name4   nvarchar(64) = NULL,
    @Value4  nvarchar(64) = NULL,
    @Name5   nvarchar(64) = NULL,
    @Value5  nvarchar(64) = NULL,
    @Name6   nvarchar(64) = NULL,
    @Value6  nvarchar(64) = NULL,
    @Name7   nvarchar(64) = NULL,
    @Value7  nvarchar(64) = NULL,
    @Name8   nvarchar(64) = NULL,
    @Value8  nvarchar(64) = NULL,
    @Name9   nvarchar(64) = NULL,
    @Value9  nvarchar(64) = NULL,
    @Name10  nvarchar(64) = NULL,
    @Value10 nvarchar(64) = NULL,
    @Name11  nvarchar(64) = NULL,
    @Value11 nvarchar(64) = NULL,
    @Name12  nvarchar(64) = NULL,
    @Value12 nvarchar(64) = NULL,
    @Name13  nvarchar(64) = NULL,
    @Value13 nvarchar(64) = NULL,
    @Name14  nvarchar(64) = NULL,
    @Value14 nvarchar(64) = NULL,
    @Name15  nvarchar(64) = NULL,
    @Value15 nvarchar(64) = NULL,
    @Name16  nvarchar(64) = NULL,
    @Value16 nvarchar(64) = NULL,
    @Name17  nvarchar(64) = NULL,
    @Value17 nvarchar(64) = NULL,
    @Name18  nvarchar(64) = NULL,
    @Value18 nvarchar(64) = NULL,
    @Name19  nvarchar(64) = NULL,
    @Value19 nvarchar(64) = NULL,
    @Name20  nvarchar(64) = NULL,
    @Value20 nvarchar(64) = NULL
) AS
BEGIN
    SET NOCOUNT ON

    -- Name/Value 1
    IF @Name1 IS NULL BEGIN
        RETURN(0)
    END
    -- This line begins the string
    SELECT @Msg = N'(' + @Name1 + N': ' + ISNULL(@Value1, N'NULL') + N')'

    -- Name/Value 2
    IF @Name2 IS NULL BEGIN
        RETURN(0)
    END
    SELECT @Msg = @Msg + N' (' + @Name2 + N': ' + ISNULL(@Value2, N'NULL') + N')'

    -- Name/Value 3
    IF @Name3 IS NULL BEGIN
        RETURN(0)
    END
    SELECT @Msg = @Msg + N' (' + @Name3 + N': ' + ISNULL(@Value3, N'NULL') + N')'

    -- Name/Value 4
    IF @Name4 IS NULL BEGIN
        RETURN(0)
    END
    SELECT @Msg = @Msg + N' (' + @Name4 + N': ' + ISNULL(@Value4, N'NULL') + N')'

    -- Name/Value 5
    IF @Name5 IS NULL BEGIN
        RETURN(0)
    END
    SELECT @Msg = @Msg + N' (' + @Name5 + N': ' + ISNULL(@Value5, N'NULL') + N')'

    -- Name/Value 6
    IF @Name6 IS NULL BEGIN
        RETURN(0)
    END
    SELECT @Msg = @Msg + N' (' + @Name6 + N': ' + ISNULL(@Value6, N'NULL') + N')'

    -- Name/Value 7
    IF @Name7 IS NULL BEGIN
        RETURN(0)
    END
    SELECT @Msg = @Msg + N' (' + @Name7 + N': ' + ISNULL(@Value7, N'NULL') + N')'

    -- Name/Value 8
    IF @Name8 IS NULL BEGIN
        RETURN(0)
    END
    SELECT @Msg = @Msg + N' (' + @Name8 + N': ' + ISNULL(@Value8, N'NULL') + N')'

    -- Name/Value 9
    IF @Name9 IS NULL BEGIN
        RETURN(0)
    END
    SELECT @Msg = @Msg + N' (' + @Name9 + N': ' + ISNULL(@Value9, N'NULL') + N')'

    -- Name/Value 10
    IF @Name10 IS NULL BEGIN
        RETURN(0)
    END
    SELECT @Msg = @Msg + N' (' + @Name10 + N': ' + ISNULL(@Value10, N'NULL') + N')'

    -- Name/Value 11
    IF @Name11 IS NULL BEGIN
        RETURN(0)
    END
    SELECT @Msg = @Msg + N' (' + @Name11 + N': ' + ISNULL(@Value11, N'NULL') + N')'

    -- Name/Value 12
    IF @Name12 IS NULL BEGIN
        RETURN(0)
    END
    SELECT @Msg = @Msg + N' (' + @Name12 + N': ' + ISNULL(@Value12, N'NULL') + N')'

    -- Name/Value 13
    IF @Name13 IS NULL BEGIN
        RETURN(0)
    END
    SELECT @Msg = @Msg + N' (' + @Name13 + N': ' + ISNULL(@Value13, N'NULL') + N')'

    -- Name/Value 14
    IF @Name14 IS NULL BEGIN
        RETURN(0)
    END
    SELECT @Msg = @Msg + N' (' + @Name14 + N': ' + ISNULL(@Value14, N'NULL') + N')'

    -- Name/Value 15
    IF @Name15 IS NULL BEGIN
        RETURN(0)
    END
    SELECT @Msg = @Msg + N' (' + @Name15 + N': ' + ISNULL(@Value15, N'NULL') + N')'

    -- Name/Value 16
    IF @Name16 IS NULL BEGIN
        RETURN(0)
    END
    SELECT @Msg = @Msg + N' (' + @Name16 + N': ' + ISNULL(@Value16, N'NULL') + N')'

    -- Name/Value 17
    IF @Name17 IS NULL BEGIN
        RETURN(0)
    END
    SELECT @Msg = @Msg + N' (' + @Name17 + N': ' + ISNULL(@Value17, N'NULL') + N')'

    -- Name/Value 18
    IF @Name18 IS NULL BEGIN
        RETURN(0)
    END
    SELECT @Msg = @Msg + N' (' + @Name18 + N': ' + ISNULL(@Value18, N'NULL') + N')'

    -- Name/Value 19
    IF @Name19 IS NULL BEGIN
        RETURN(0)
    END
    SELECT @Msg = @Msg + N' (' + @Name19 + N': ' + ISNULL(@Value19, N'NULL') + N')'

    -- Name/Value 20
    IF @Name20 IS NULL BEGIN
        RETURN(0)
    END
    SELECT @Msg = @Msg + N' (' + @Name20 + N': ' + ISNULL(@Value20, N'NULL') + N')'

    RETURN(0)
END
GO

-- =============================================================
PRINT 'VendorCreate'
-- =============================================================
GO
IF EXISTS (SELECT * FROM sys.procedures WHERE [name] = 'VendorCreate')
    DROP PROCEDURE Perf.VendorCreate
GO
CREATE PROCEDURE Perf.VendorCreate (
    @VendorID       int             OUTPUT,
    @BusinessName   varchar(40),
    @Address1       varchar(40),
    @Address2       varchar(40),
    @City           varchar(40),
    @State          char(2),
    @ZipCode        varchar(10)
) AS
-- Create a new Vendor record
BEGIN
    SET NOCOUNT ON

    DECLARE @error      int

    INSERT INTO Perf.Vendor (
        --VendorID,
        BusinessName,
        Address1,
        Address2,
        City,
        [State],
        ZipCode
    )
    VALUES (
        @BusinessName,
        @Address1,
        @Address2,
        @City,
        @State,
        @ZipCode
    )

    -- Error check
    SELECT
        @error    = @@error,
        @VendorID = SCOPE_IDENTITY()

    RETURN(@error)
END
GO

-- =============================================================
PRINT 'VendorUpdate'
-- =============================================================
GO
IF EXISTS (SELECT * FROM sys.procedures WHERE [name] = 'VendorUpdate')
    DROP PROCEDURE Perf.VendorUpdate
GO
CREATE PROCEDURE Perf.VendorUpdate (
    @VendorID       int,
    @BusinessName   varchar(40),
    @Address1       varchar(40),
    @Address2       varchar(40),
    @City           varchar(40),
    @State          char(2),
    @ZipCode        varchar(10)
) AS
-- Update a Vendor record
BEGIN
    SET NOCOUNT ON

    UPDATE Perf.Vendor
    SET
        BusinessName    = @BusinessName,
        Address1        = @Address1,
        Address2        = @Address2,
        City            = @City,
        [State]         = @State,
        ZipCode         = @ZipCode
    WHERE VendorID = @VendorID

    -- Error check
    SELECT @VendorID = SCOPE_IDENTITY()

    RETURN(0)
END
GO

-- =============================================================
PRINT 'VendorRead'
-- =============================================================
GO
IF EXISTS (SELECT * FROM sys.procedures WHERE [name] = 'VendorRead')
    DROP PROCEDURE Perf.VendorRead
GO
CREATE PROCEDURE Perf.VendorRead (
    @VendorID       int
) AS
-- Read a Vendor record
-- Read to local variables to avoid returning results
BEGIN
    SET NOCOUNT ON

    DECLARE
        @BusinessName   varchar(40),
        @Address1       varchar(40),
        @Address2       varchar(40),
        @City           varchar(40),
        @State          char(2),
        @ZipCode        varchar(10)

    SELECT
        @businessName    = BusinessName,
        @address1        = Address1,
        @address2        = Address2,
        @city            = City,
        @state           = [State],
        @zipCode         = ZipCode
    FROM Perf.Vendor
    WHERE VendorID = @VendorID

    -- Error check
    IF @businessName IS NULL BEGIN
        RETURN(-1)
    END

    RETURN(0)
END
GO

-- =============================================================
PRINT 'CardCreate'
-- =============================================================
GO
IF EXISTS (SELECT * FROM sys.procedures WHERE [name] = 'CardCreate')
    DROP PROCEDURE Perf.CardCreate
GO
CREATE PROCEDURE Perf.CardCreate (
    @CardID         int             OUTPUT,
    @CardNumber     bigint,
    @SecurityCode   smallint,
    @SecureString   char(36)
) AS
BEGIN
    SET NOCOUNT ON

    DECLARE @error      int

    INSERT INTO Perf.[Card] (
        --CardID,
        CardNumber,
        SecurityCode,
        SecureString
    )
    VALUES (
        @CardNumber,
        @SecurityCode,
        @SecureString
    )

    -- Error check
    SELECT
        @error  = @@error,
        @CardID = SCOPE_IDENTITY()

    RETURN(@error)
END
GO

-- =============================================================
PRINT 'CardRead'
-- =============================================================
GO
IF EXISTS (SELECT * FROM sys.procedures WHERE [name] = 'CardRead')
    DROP PROCEDURE Perf.CardRead
GO
CREATE PROCEDURE Perf.CardRead (
    @CardID         int
) AS
BEGIN
    SET NOCOUNT ON

    DECLARE
        @cardNumber     bigint,
        @securityCode   smallint,
        @secureString   char(36)

    SELECT
        @cardNumber     = CardNumber,
        @securityCode   = SecurityCode,
        @secureString   = SecureString
    FROM Perf.[Card]
    WHERE CardID = @CardID

    -- Error check
    IF @cardNumber IS NULL BEGIN
        RETURN(-1)
    END

    RETURN(0)
END
GO

-- =============================================================
PRINT 'PurchaseCreate'
-- =============================================================
GO
IF EXISTS (SELECT * FROM sys.procedures WHERE [name] = 'PurchaseCreate')
    DROP PROCEDURE Perf.PurchaseCreate
GO
CREATE PROCEDURE Perf.PurchaseCreate (
    @PurchaseID int            OUTPUT,
    @CardID     int,
    @VendorID   int,
    @Amount     money
) AS
-- Create a new Purchase record
BEGIN
    SET NOCOUNT ON

    DECLARE @error      int

    INSERT INTO Perf.Purchase (
        -- PurchaseID
        CardID,
        VendorID,
        Amount
    )
    VALUES (
        @CardID,
        @VendorID,
        @Amount
    )

    -- Error check
    SELECT
        @error      = @@error,
        @PurchaseID = SCOPE_IDENTITY()

    RETURN(@error)
END
GO

PRINT '<< DONE >>'
GO
