SET NOCOUNT ON
USE master
GO

IF EXISTS (SELECT * FROM sys.databases WHERE [name] = 'PerfTestTde')
    DROP DATABASE PerfTestTde
GO

PRINT 'CREATE DATABASE PerfTestTde'
GO
CREATE DATABASE PerfTestTde ON (
	NAME        = N'PerfTestTde_Primary',
	FILENAME    = N'C:\PerfTestTde_Primary.MDF',
	SIZE        = 4,
	FILEGROWTH  = 10%
)
LOG ON (
	NAME = N'PerfTestTde_Log',
	FILENAME    = N'C:\PerfTestTde_Log.LDF',
	SIZE        = 2,
	FILEGROWTH  = 10%
)
GO

USE PerfTestTde
GO

EXEC sp_changedbowner 'sa'
GO

PRINT 'Set database options'
GO
ALTER DATABASE PerfTestTde SET ANSI_NULLS              ON
ALTER DATABASE PerfTestTde SET ANSI_PADDING            ON
ALTER DATABASE PerfTestTde SET ANSI_WARNINGS           ON
ALTER DATABASE PerfTestTde SET ARITHABORT              ON
ALTER DATABASE PerfTestTde SET CONCAT_NULL_YIELDS_NULL ON
ALTER DATABASE PerfTestTde SET NUMERIC_ROUNDABORT      OFF
ALTER DATABASE PerfTestTde SET QUOTED_IDENTIFIER       ON
GO

--PRINT 'SET RECOVERY Simple'
--ALTER DATABASE PerfTestTde SET RECOVERY Simple
--GO

CREATE SCHEMA Perf
GO

PRINT '<< DONE >>'
GO
