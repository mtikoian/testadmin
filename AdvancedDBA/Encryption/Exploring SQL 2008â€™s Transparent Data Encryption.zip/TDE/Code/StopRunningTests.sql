SET NOCOUNT ON
--USE PerfTestBasic
--USE PerfTestTde
--USE master
GO

DECLARE @run            bit
DECLARE @runCt          int
DECLARE @maxInsertCt    int

EXEC PerfTestCommon.Perf.SettingUpsert
	@Run    = 0

PRINT ''
PRINT 'Stopped run'
GO
