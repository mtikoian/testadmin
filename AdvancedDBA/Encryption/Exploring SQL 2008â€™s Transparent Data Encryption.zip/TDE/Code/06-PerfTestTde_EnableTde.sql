SET NOCOUNT ON
USE master
GO

-- Create the "master" database master key
IF NOT EXISTS (
    SELECT *
    FROM sys.symmetric_keys
    WHERE name = '##MS_DatabaseMasterKey##'
) BEGIN
    PRINT 'Create master key'
    CREATE MASTER KEY
    ENCRYPTION BY PASSWORD = N'thuyuy73r_!r-kuwru4huy&Yar=-athE'
END
GO

-- Create the certificate
IF NOT EXISTS (
    SELECT *
    FROM sys.certificates
    WHERE name = N'TestServerCert1'
) BEGIN
    PRINT 'Create certificate'
    CREATE CERTIFICATE TestServerCert1
    WITH SUBJECT = N'TestServerCert1'
END
GO

USE PerfTestTde
GO

-- Create the encryption key
IF EXISTS (
    SELECT *
    FROM master.sys.certificates
    WHERE name = N'TestServerCert1'
)
  AND NOT EXISTS (
    SELECT k.*, d.name
    FROM sys.dm_database_encryption_keys    AS k
    JOIN sys.databases                      AS d ON k.database_id = d.database_id
    WHERE d.name = DB_NAME()
  ) BEGIN
    PRINT 'Create Database Encryption Key'
    CREATE DATABASE ENCRYPTION KEY
    WITH ALGORITHM = AES_256
    ENCRYPTION BY SERVER CERTIFICATE TestServerCert1
END
GO

-- Enable TDE
IF EXISTS (
    SELECT *
    FROM sys.databases
    WHERE name = 'PerfTestTde'
      AND is_encrypted = 0
) BEGIN
    PRINT 'Enable TDE on PerfTestTde'
    ALTER DATABASE PerfTestTde
    SET ENCRYPTION ON
END
GO

PRINT '<< DONE >>'
GO
