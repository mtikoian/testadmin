SET NOCOUNT ON
GO

DBCC FREEPROCCACHE    WITH NO_INFOMSGS
GO
DBCC DROPCLEANBUFFERS WITH NO_INFOMSGS
GO

---- Only when running this script by itself
--DELETE FROM Perf.Purchase
--DBCC CHECKIDENT ("Perf.Purchase", RESEED, 0) WITH NO_INFOMSGS
--DELETE FROM Perf.[Card]
--DBCC CHECKIDENT ("Perf.[Card]",   RESEED, 0) WITH NO_INFOMSGS
--DELETE FROM Perf.Vendor
--DBCC CHECKIDENT ("Perf.Vendor",   RESEED, 0) WITH NO_INFOMSGS
--GO

DECLARE @now            time(7)
DECLARE @beginLastLoop  time(7)
DECLARE @elapsedTimeMs  int
DECLARE @done           bit
DECLARE @thisDB			sysname
DECLARE @vendorID       int
DECLARE @cardID         int
DECLARE @purchaseID     int
DECLARE @rtn            int
DECLARE @loopCt         int
DECLARE @loopMs         int
DECLARE @delayEveryN    int
DECLARE @delayString    char(8)
DECLARE @maxVendorCt    int
DECLARE @maxCardCt      int
DECLARE @maxPurchCt     int
DECLARE @run            bit
DECLARE @loopMax        int
DECLARE @loopsRead      tinyint
DECLARE @loopsUpdate    tinyint
DECLARE @loopsInsert    tinyint

DECLARE @rowCtVendor    int
DECLARE @rowCtCard      int
DECLARE @rowCtPurchase  int

DECLARE @str0           nvarchar(36)
DECLARE @str1           nvarchar(255)
DECLARE @str2           nvarchar(255)
DECLARE @str3           nvarchar(255)
DECLARE @debug          tinyint
DECLARE @beginTime      time(7)
DECLARE @readToUpdate   int
DECLARE @secureString   varchar(36)
DECLARE @cardNumber     bigint
DECLARE @securityCode   smallint
DECLARE @amount         money
DECLARE @businessName   varchar(40)

SELECT
    @debug          = 1,        -- 0: None, 1: Summary, 2: Detail, 3: Full
    @done           = 0,
    @rowCtVendor    = NULL,
    @rowCtCard      = NULL,
    @rowCtPurchase  = NULL,
    @loopMax        = NULL,
    @beginTime      = SYSDATETIME(),
    @beginLastLoop  = @beginTime

-- Delay each script on start-up
WAITFOR DELAY '00:00:05'

EXEC PerfTestCommon.Perf.SettingRead
    @Run            = @run          OUTPUT,
    @LoopMax        = @loopMax      OUTPUT,
    @DelayEveryN    = @delayEveryN  OUTPUT,
    @DelayString    = @delayString  OUTPUT,
    @MaxVendorCt    = @maxVendorCt  OUTPUT,
    @MaxCardCt      = @maxCardCt    OUTPUT,
    @MaxPurchCt     = @maxPurchCt   OUTPUT,
    @LoopsRead      = @loopsRead    OUTPUT,
    @LoopsUpdate    = @loopsUpdate  OUTPUT,
    @LoopsInsert    = @loopsInsert  OUTPUT

PRINT 'Initial Settings'
SELECT
    @run            AS '@run',
    @loopMax        AS '@loopMax',
    @DelayEveryN    AS '@delayEveryN',
    @DelayString    AS '@delayString',
    @maxVendorCt    AS '@maxVendorCt',
    @maxCardCt      AS '@maxCardCt',
    @maxPurchCt     AS '@maxPurchCt',
    @loopsRead      AS '@loopsRead',
    @loopsUpdate    AS '@loopsUpdate',
    @loopsInsert    AS '@loopsInsert'

SET @loopCt = 0
WHILE @done = 0 BEGIN
    SET @loopCt = @loopCt + 1

    IF @debug > 2 BEGIN
        RAISERROR('LoopCt: %d', 10, 1, @loopCt) WITH NOWAIT
    END

    SET @run        = NULL
    SET @loopMax    = NULL

    EXEC PerfTestCommon.Perf.SettingRead
        @Run            = @run          OUTPUT,
        @LoopMax        = @loopMax      OUTPUT,
        @DelayEveryN    = @delayEveryN  OUTPUT,
        @DelayString    = @delayString  OUTPUT,
        @MaxVendorCt    = @maxVendorCt  OUTPUT,
        @MaxCardCt      = @maxCardCt    OUTPUT,
        @MaxPurchCt     = @maxPurchCt   OUTPUT,
        @LoopsRead      = @loopsRead    OUTPUT,
        @LoopsUpdate    = @loopsUpdate  OUTPUT,
        @LoopsInsert    = @loopsInsert  OUTPUT

    IF @run = 0 BEGIN
        PRINT 'Test Stopped. @run is 0.'
        SET @done = 1
    END
    ELSE IF @run = 0 OR (@loopMax IS NOT NULL AND @loopCt >= @loopMax) BEGIN
        PRINT 'Test Stopped. @loopMax (' + CONVERT(varchar(11), @loopMax) + ') reached.'
        SET @done = 1
    END
    ELSE BEGIN
        --RAISERROR('DelayEveryN: %d. Delay: %s. LoopCt: %d', 10, 1, @delayEveryN, @delayString, @loopCt) WITH NOWAIT

        IF @DelayEveryN IS NOT NULL AND @loopCt % @DelayEveryN = 0 BEGIN
            SET @delayString    = ISNULL(@delayString, '00:00:01')
            SET @now            = SYSDATETIME()
            --SELECT @beginLastLoop AS '@beginLastLoop', @now AS '@now'
            SET @loopMs         = DATEDIFF(ms, @beginLastLoop, @now)
            --SELECT @loopMs AS '@loopMs', @loopCt AS '@loopCt', @DelayEveryN AS '@DelayEveryN', @beginLastLoop AS '@beginLastLoop', SYSDATETIME() AS 'CurrentTime'
            RAISERROR('Before WAITFOR. Delay: %s. LoopCt: %d. LoopMs: %d', 10, 1, @delayString, @loopCt, @loopMs) WITH NOWAIT
            SET @beginLastLoop  = @now
            WAITFOR DELAY @delayString
        END

        -- ============================================
        -- Vendor
        -- ============================================
        IF @loopCt <= @maxVendorCt BEGIN
            IF @debug > 1 BEGIN
                PRINT '[DEBUG] Call VendorCreate'
            END

            SET @rtn = NULL
            EXEC @rtn = Perf.VendorCreate
                @VendorID       = @vendorID         OUTPUT,
                @BusinessName   = 'WebMD Health',
                @Address1       = '2701 NW Vaughn Street',
                @Address2       = 'Suite 700',
                @City           = 'Portland',
                @State          = 'OR',
                @ZipCode        = '97210'

            IF @rtn <> 0 BEGIN
                PRINT 'Failed test'
            END

            IF @loopCt = @maxVendorCt BEGIN
                PRINT 'Done writing Vendor'
            END
        END
        ELSE BEGIN
            IF @rowCtVendor IS NULL BEGIN
                -- This will only happen once
                SELECT @rowCtVendor = COUNT(*) FROM Perf.Vendor (NOLOCK)
                PRINT 'Row Count - Vendor: ' + CONVERT(varchar(11), @rowCtVendor)
            END

            -- If all (initial) inserts are done, pick a random Vendor record
            SELECT @vendorID = CONVERT(bigint, ((RAND() * @rowCtVendor) + 1))

            IF @debug > 2 BEGIN
                PRINT '[DEBUG] Random VendorID: ' + CONVERT(varchar(11), @vendorID)
            END
        END

        -- ============================================
        -- Card
        -- ============================================
        IF @loopCt <= @maxCardCt BEGIN
            IF @debug > 1 BEGIN
                PRINT '[DEBUG] Call CardCreate'
            END

            SET @rtn = NULL
            SET @cardNumber     = RAND() * 10000000000000000 + 1
            SET @securityCode   = RAND() * 1000 + 1
            SET @SecureString   = CONVERT(char(36), NEWID())
            IF @debug > 2 BEGIN
                PRINT '[DEBUG] @cardNumber: ' + CONVERT(varchar(20), @cardNumber) + '. @securityCode: ' + CONVERT(varchar(5), @securityCode)
            END
            EXEC @rtn = Perf.CardCreate
                @CardID         = @cardID             OUTPUT,
                @CardNumber     = @cardNumber,
                @SecurityCode   = @securityCode,
                @SecureString   = @secureString

            IF @rtn <> 0 BEGIN
                PRINT 'Failed test'
            END

            IF @loopCt = @maxCardCt BEGIN
                PRINT 'Done writing Card'
            END
        END
        ELSE BEGIN
            IF @rowCtCard IS NULL BEGIN
                -- This will only happen once
                SELECT @rowCtCard = COUNT(*) FROM Perf.[Card] (NOLOCK)
                PRINT 'Row Count - Card: ' + CONVERT(varchar(11), @rowCtCard)
            END

            -- If all (initial) inserts are done, pick a random Card record
            SELECT @cardID = CONVERT(bigint, ((RAND() * @rowCtCard) + 1))

            IF @debug > 2 BEGIN
                PRINT '[DEBUG] Random CardID: ' + CONVERT(varchar(11), @cardID)
            END
        END

        -- ============================================
        -- Purchase
        -- ============================================
        IF @loopCt <= @maxPurchCt BEGIN
            IF @debug > 1 BEGIN
                PRINT '[DEBUG] Call PurchaseCreate'
            END

            SET @rtn = NULL
            SET @amount = RAND() * 1000 + 1
            --IF @debug > 2 BEGIN
            --    PRINT '[DEBUG] @amount: ' + CONVERT(varchar(20), @amount)
            --END
            EXEC @rtn = Perf.PurchaseCreate
                @PurchaseID = @purchaseID             OUTPUT,
                @CardID     = @cardID,
                @VendorID   = @vendorID,
                @Amount     = @amount

            IF @rtn <> 0 BEGIN
                PRINT 'Failed test'
				SELECT
					@purchaseID AS '@purchaseID',
					@cardID     AS '@cardID',
					@vendorID   AS '@vendorID',
					@amount     AS '@amount'
            END

            IF @loopCt = @maxPurchCt BEGIN
                PRINT 'Done writing Purchase'
            END
        END
        ELSE BEGIN
            IF @rowCtPurchase IS NULL BEGIN
                -- This will only happen once
                SELECT @rowCtPurchase = COUNT(*) FROM Perf.[Purchase] (NOLOCK)
                PRINT 'Row Count - Purchase: ' + CONVERT(varchar(11), @rowCtPurchase)
            END

            -- If all (initial) inserts are done, pick a random Purchase record
            SELECT @purchaseID = CONVERT(bigint, ((RAND() * @rowCtPurchase) + 1))

            IF @debug > 2 BEGIN
                PRINT '[DEBUG] Random PurchaseID: ' + CONVERT(varchar(11), @purchaseID)
            END
        END

        -- ============================================
        -- Read, Update, or Insert
        -- ============================================
        -- Of every 10 loops, x are reads, y are updates, and z are inserts
        -- This code is a bit complex, but it gives us the right results.
        IF (@loopCt - 1) % 10 >= (@loopsRead + @loopsUpdate) BEGIN
            -- ===== Insert Purchase =====
            SET @rtn = NULL
            SET @amount = RAND() * 1000 + 1
            --IF @debug > 2 BEGIN
            --    PRINT '[DEBUG] @amount: ' + CONVERT(varchar(20), @amount)
            --END
            EXEC @rtn = Perf.PurchaseCreate
                @PurchaseID = @purchaseID             OUTPUT,
                @CardID     = @cardID,
                @VendorID   = @vendorID,
                @Amount     = @amount

            IF @rtn <> 0 BEGIN
                PRINT 'Failed test'
            END
        END
        ELSE IF (@loopCt - 1) % 10 >= (@loopsRead) BEGIN
            -- ===== Update Vendor =====
            SET @rtn            = NULL
            SET @businessName   = NEWID()
            EXEC @rtn = Perf.VendorUpdate
                @VendorID       = @vendorID,
                @BusinessName   = @businessName,
                @Address1       = '2701 NW Vaughn Street',
                @Address2       = 'Suite 700',
                @City           = 'Portland',
                @State          = 'OR',
                @ZipCode        = '97210'

            IF @rtn <> 0 BEGIN
                PRINT 'Failed test'
            END

            IF @debug > 1 BEGIN
                PRINT '[DEBUG] Call VendorUpdate. VendorID: ' + CONVERT(varchar(11), @vendorID)
            END
        END
        ELSE BEGIN
            -- ===== Read Card =====
            IF @debug > 1 BEGIN
                PRINT '[DEBUG] Call CardRead with CardID ' + CONVERT(varchar(11), @cardID)
            END

            SET @rtn = NULL
            EXEC @rtn = Perf.CardRead
                @CardID = @cardID

            IF @rtn <> 0 BEGIN
                PRINT 'Failed test'
            END
        END
    END
END


SELECT
	@thisDB			= DB_NAME(),
    @now            = CONVERT(time(7), SYSDATETIME()),
    @elapsedTimeMs  = DATEDIFF(ms, @beginTime, @now)

-- Record the elapsed time for each run
EXEC @rtn = PerfTestCommon.Perf.TestResultCreate
	@DatabaseName	= @thisDB,
    @LoopMax        = @loopMax,
    @DelayEveryN    = @delayEveryN,
    @DelayString    = @delayString,
    @MaxVendorCt    = @maxVendorCt,
    @MaxCardCt      = @maxCardCt,
    @MaxPurchCt     = @maxPurchCt,
    @LoopsRead      = @loopsRead,
    @LoopsUpdate    = @loopsUpdate,
    @LoopsInsert    = @loopsInsert,
    @ElapsedTimeMs  = @elapsedTimeMs,
    @RunCompleted   = @now

IF @rtn <> 0 BEGIN
    PRINT 'Failed test'
END

SELECT @elapsedTimeMs AS ElapsedTimeMs

PRINT '<< DONE >>'
GO
