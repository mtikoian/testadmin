SET NOCOUNT ON
USE PerfTestCommon
GO

-- ==============================================================
PRINT 'TestSetting'
GO
CREATE TABLE Perf.TestSetting (
    EntryID             int         NOT NULL    IDENTITY,
    Run                 bit         NOT NULL,           -- Set to 0 to stop a running test
    -- These columns below are nullable so that
    --  a test can be stopped simply by updating
    --  Run to 0.
    LoopMax             int         NULL,               -- Do the test loop n times, then quit (if NULL, loop without bound)
    DelayEveryN         int         NULL,               -- Every N loops, delay DelayString
    DelayString         char(8)     NULL,               -- The delay time (format is 'HH:MM:SS')
    MaxVendorCt         int         NULL,               -- Insert n Vendor   records, then stop inserting
    MaxCardCt           int         NULL,               -- Insert n Card     records, then stop inserting
    MaxPurchCt          int         NULL,               -- Insert n Purchase records, then stop inserting
    -- Of every 10 loops, x are reads, y are updates, and z are inserts
    LoopsRead           tinyint     NULL,
    LoopsUpdate         tinyint     NULL,
    LoopsInsert         tinyint     NULL
)
GO

-- ==============================================================
PRINT 'TestResult'
GO
CREATE TABLE Perf.TestResult (
    DatabaseName        sysname     NOT NULL,
    LoopMax             int         NOT NULL,           -- Do the test loop n times, then quit (if NULL, loop without bound)
    DelayEveryN         int         NOT NULL,           -- Every N loops, delay DelayString
    DelayString         char(8)     NOT NULL,           -- The delay time (format is 'HH:MM:SS')
    MaxVendorCt         int         NOT NULL,           -- Insert n Vendor   records, then stop inserting
    MaxCardCt           int         NOT NULL,           -- Insert n Card     records, then stop inserting
    MaxPurchCt          int         NOT NULL,           -- Insert n Purchase records, then stop inserting
    -- Of every 10 loops, x are reads, y are updates, and z are inserts
    LoopsRead           tinyint     NOT NULL,
    LoopsUpdate         tinyint     NOT NULL,
    LoopsInsert         tinyint     NOT NULL,
    ElapsedTimeMs       int         NOT NULL,
    RunCompleted        datetime    NOT NULL
)
GO

PRINT '<< DONE >>'
GO
