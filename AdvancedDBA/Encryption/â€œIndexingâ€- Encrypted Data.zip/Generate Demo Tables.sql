/* Create a table to hold plaintext custid and fake ssn*/
CREATE TABLE testcust (custid INT identity (1,1) PRIMARY KEY, SSN CHAR(9))
go

/* Populate the table with 1 million customers - takes about minutes to populate dependent on machine of course*/
INSERT testcust (ssn)
 SELECT right('000000000' + cast(abs(checksum(newid()))%1000000000 as varchar(9)), 9)
go 1000000

/* Check for dups */
select ssn from testcust group by ssn having count(*) > 1

/* Loop until values are unique */
IF exists (SELECT 1 from testcust group by ssn having count(*) > 1)
    UPDATE testcust
     set ssn = right('000000000' + cast(abs(checksum(newid()))%1000000000 as varchar(9)), 9)
     where ssn in (select ssn from testcust group by ssn having count(*) > 1)

/* Verifyt here are no dups */
select ssn from testcust group by ssn having count(*) > 1