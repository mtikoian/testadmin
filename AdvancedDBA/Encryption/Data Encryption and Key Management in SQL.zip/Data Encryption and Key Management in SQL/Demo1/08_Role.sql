USE AdventureWorks2008


/****** Object:  DatabaseRole [db_cansee]    Script Date: 04/10/2010 00:58:19 ******/
CREATE ROLE [db_cansee] AUTHORIZATION [dbo]
GO

GRANT VIEW DEFINITION ON CERTIFICATE :: PasswordFieldCertificate TO [db_cansee]
GRANT CONTROL ON CERTIFICATE :: PasswordFieldCertificate TO [db_cansee]

GRANT VIEW DEFINITION ON SYMMETRIC KEY :: PasswordFieldSymmetricKey TO [db_cansee]
GRANT CONTROL ON SYMMETRIC KEY :: PasswordFieldSymmetricKey TO [db_cansee]