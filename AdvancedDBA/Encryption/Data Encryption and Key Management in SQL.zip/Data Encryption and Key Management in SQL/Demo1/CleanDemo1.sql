Use AdventureWorks2008

ALTER TABLE [AdventureWorks2008].[Person].[EmailAddress]
 Drop COLUMN EncryptedEmailAddress; 

DROP SYMMETRIC KEY PasswordFieldSymmetricKey

Drop CERTIFICATE PasswordFieldCertificate

DROP MASTER KEY

