EXECUTE AS LOGIN = 'cant_read';

Use AdventureWorks2008

/*************** DECRYPT *********************************/
OPEN SYMMETRIC KEY PasswordFieldSymmetricKey
DECRYPTION BY CERTIFICATE PasswordFieldCertificate;

SELECT TOP 10
EmailAddress, 
CONVERT(nvarchar, DecryptByKey(EncryptedEmailAddress)) AS 'Decrypted Email Address',
EncryptedEmailAddress
FROM [AdventureWorks2008].[Person].[EmailAddress];
GO
CLOSE ALL SYMMETRIC KEYS;
REVERT;
