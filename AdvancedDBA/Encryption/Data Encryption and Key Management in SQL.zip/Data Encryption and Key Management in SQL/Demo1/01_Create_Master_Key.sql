USE master

SELECT * FROM sys.symmetric_keys

Use AdventureWorks2008

/*************** CREATE MASTER KEY *********************************/
IF NOT EXISTS (
SELECT * FROM sys.symmetric_keys WHERE name = N'##MS_DatabaseMasterKey##'
)
CREATE MASTER KEY ENCRYPTION BY PASSWORD = '$EncryptionPassword12'
GO

SELECT * FROM sys.symmetric_keys