USE mssqltips_tde;

SELECT [BusinessEntityID]
      ,[EmailAddressID]
      ,[EmailAddress]
      ,[rowguid]
      ,[ModifiedDate]
  --    ,[EncryptedEmailAddress]
  INTO [mssqltips_tde].dbo.[EmailAddress]
  FROM [AdventureWorks2008].[Person].[EmailAddress]
GO

Select * from [mssqltips_tde].dbo.[EmailAddress]


