USE master
Drop database mssqltips_tde
Drop CERTIFICATE TDECert 
Drop Master Key