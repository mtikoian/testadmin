CREATE DATABASE EncryptionDemo;
GO 

USE EncryptionDemo;
GO 

-- Create a schema for our security objects
CREATE SCHEMA AppSecurity;
GO 

-- Create a table to hold user credentials
CREATE TABLE AppSecurity.UserCredentials (
  UserID int IDENTITY(1,1) NOT NULL,
  UserName varchar(20) NOT NULL,
  UserPassword varbinary(256) NOT NULL,
  CONSTRAINT PK_AppSecurity_UserCredentials PRIMARY KEY CLUSTERED (UserID)
);
GO 

-- Create a stored procedure to demonstrate HASHBYTES
CREATE PROCEDURE AppSecurity.CreateUser
  @UserName varchar(20),
  @UnencryptedPassword varchar(128)
AS
BEGIN
  IF NOT EXISTS (SELECT UserID FROM AppSecurity.UserCredentials WHERE UserName = @UserName)
    BEGIN
      INSERT INTO AppSecurity.UserCredentials (Username, UserPassword) VALUES (@UserName, HASHBYTES('SHA1', @UnencryptedPassword));
      RETURN 0;
    END;
  ELSE
    RETURN 1;
END;
GO 

-- Insert a User
DECLARE @Result TINYINT;
EXEC @Result = AppSecurity.CreateUser 'Brian', 'IluvEncryption!';
PRINT @Result;
GO 

SELECT * FROM AppSecurity.UserCredentials;
GO 

-- Create a stored procedure to compare HASHBYTE results
CREATE PROCEDURE AppSecurity.UserLogon
  @UserName VARCHAR(20),
  @UnencryptedPassword VARCHAR(128)
AS
BEGIN
  IF EXISTS (SELECT UserID FROM AppSecurity.UserCredentials 
             WHERE UserName = @UserName 
			   AND UserPassword = HASHBYTES('SHA1', @UnencryptedPassword))
    RETURN 0;
  ELSE
    RETURN 1;
END;
GO 

-- Test UserLogon Stored Procedure with Different Passwords
DECLARE @Result TINYINT;
EXEC @Result = AppSecurity.UserLogon 'Brian', 'NotTheRightPassword!';
PRINT @Result;
GO

DECLARE @Result TINYINT;
EXEC @Result = AppSecurity.UserLogon 'Brian', 'AnotherFailedAttempt';
PRINT @Result;
GO

DECLARE @Result TINYINT;
EXEC @Result = AppSecurity.UserLogon 'Brian', 'IluvEncryption!';
PRINT @Result;
GO
