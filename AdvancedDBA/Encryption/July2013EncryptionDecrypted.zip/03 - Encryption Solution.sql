USE EncryptionDemo;
GO

-- Encryption example: Database Master Key Creation
-- Choosing Option 1, where DBAs can see the data
CREATE MASTER KEY ENCRYPTION BY PASSWORD = '@EncryptionDemo@'
GO

-- Encryption example: Create Keys
CREATE ASYMMETRIC KEY AsymExample
WITH ALGORITHM = RSA_1024
GO

CREATE SYMMETRIC KEY SymExample
WITH ALGORITHM = AES_256
ENCRYPTION BY ASYMMETRIC KEY AsymExample
GO

-- Encryption example: Table for Data
CREATE TABLE dbo.EncryptionExample (EncryptedCol varbinary(128));
GO

SELECT * FROM dbo.EncryptionExample;

-- Open Keys, Store Encrypted Data
OPEN SYMMETRIC KEY SymExample 
DECRYPTION BY ASYMMETRIC KEY AsymExample;

INSERT INTO dbo.EncryptionExample
(EncryptedCol) VALUES 
(EncryptByKey(Key_GUID('SymExample'), 'Columbia'));

INSERT INTO dbo.EncryptionExample
(EncryptedCol) VALUES 
(EncryptByKey(Key_GUID('SymExample'), 'Charleston'));

INSERT INTO dbo.EncryptionExample
(EncryptedCol) VALUES 
(EncryptByKey(Key_GUID('SymExample'), 'Greenville'));
GO 

-- View Data while key is open
SELECT CONVERT(varchar, DecryptByKey(EncryptedCol))
FROM dbo.EncryptionExample;
GO 

-- View Data while key is closed
CLOSE SYMMETRIC KEY SymExample;
GO

SELECT * FROM dbo.EncryptionExample;
GO

SELECT CONVERT(varchar, DecryptByKey(EncryptedCol))
FROM dbo.EncryptionExample;
GO

-- Automate the open and the viewing
SELECT CONVERT(varchar, DecryptByKeyAutoAsymKey
 (ASymKey_ID('AsymExample'), NULL, EncryptedCol))
FROM dbo.EncryptionExample;
GO
