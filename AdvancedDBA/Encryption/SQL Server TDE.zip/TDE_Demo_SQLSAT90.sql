
SELECT @@SERVERNAME, @@VERSION

/* 
	Create database for use in the Demo.
*/
CREATE DATABASE [TESTTDE] ON  PRIMARY 
( 
	NAME = N'TESTTDE', 
	FILENAME = N'E:\sqldata\INSTANCE1\TESTTDE.mdf' , 
	SIZE = 10240KB , 
	FILEGROWTH = 10240KB 
)
 LOG ON 
( 
	NAME = N'TESTTDE_log', 
	FILENAME = N'E:\sqldata\INSTANCE1\TESTTDE_log.ldf' , 
	SIZE = 10240KB , 
	FILEGROWTH = 10240KB 
)
GO

USE TESTTDE
GO

CREATE TABLE dbo.TestTable (
	Field1 int,
	Field2 varchar(25),
	Field3 decimal(18,2)
)
GO
INSERT INTO dbo.TestTable 
VALUES (1, '1 Value', 18.2),
(2, '2 Value', 19.2),
(3, '3 Value', 20.2),
(4, '4 Value', 21.2)
GO

SELECT *
FROM dbo.TestTable
GO

/*
	Let's backup the database and view it in an editor
*/
/*
	This is the backup of the unencrypted database and uncompressed 
*/
BACKUP DATABASE TESTTDE 
	TO DISK='E:\SQLBACKUP\INSTANCE1\TESTTDE_unenc.bak' 
	WITH INIT
GO

/*
	This is the backup of the unencrypted database and compressed 
*/
BACKUP DATABASE TESTTDE 
	TO DISK='E:\SQLBACKUP\INSTANCE1\TESTTDE_unenc_compressed.bak' 
	WITH INIT, COMPRESSION
GO

/*
	This is the backup of the unencrypted database and uncompressed 
*/
BACKUP DATABASE AdventureWorks 
	TO DISK='E:\SQLBACKUP\INSTANCE1\AdventureWorks_unenc.bak' 
	WITH INIT
GO

/*
	This is the backup of the unencrypted database and compressed 
*/
BACKUP DATABASE AdventureWorks
	TO DISK='E:\SQLBACKUP\INSTANCE1\AdventureWorks_unenc_compressed.bak' 
	WITH INIT, COMPRESSION
GO

/*
	Let's create the DB MASTER key for use in TDE
*/
select *
from sys.symmetric_keys

USE master;
GO
CREATE MASTER KEY 
ENCRYPTION BY PASSWORD = 'INSTANCE1_Use1Strong2Password3Here!';
go

/* 
	Now see if it is there...
	Look for ##MS_DatabaseMasterKey##
*/
SELECT *
FROM sys.symmetric_keys

/*
	Now let's create a Certificate that will be used
	in the Encryption hierarchy.
	When not using the ENCRYPTION BY PASSWORD clause
	the certificate Private key is encrypted by the 
	DATABASE MASTER KEY or up the chain to the Master
	DATABASE MASTER KEY.
	By default the certificate is created by SQL Server 
	with the key length of 1024.
	The database master key has to be able to be opened.
*/

CREATE CERTIFICATE MyServerCert 
WITH SUBJECT = 'My DEK Certificate'
go

/*
	You get warned if you do not backup the Certificate

BACKUP CERTIFICATE MyServerCert
TO FILE='E:\SQLBACKUP\INSTANCE1\MyserverCert.cer'
WITH PRIVATE KEY (FILE='E:\SQLBACKUP\INSTANCE1\MyServerCert.pvk',
	ENCRYPTION BY PASSWORD='My1Secure2Password!')	

*/

/*
	Check to see that it exists.
*/
select *
from sys.certificates

/*
	You must be in the database that you are creating
	the Key for.  Then Create the Key for Encryption
	You can choose the following Encryption algorithms.
		AES_128, AES_192, AES_256, TRIPLE_DES_3KEY
*/
USE TESTTDE
GO

CREATE DATABASE ENCRYPTION KEY
WITH ALGORITHM = AES_128
ENCRYPTION BY SERVER CERTIFICATE MyServerCert
GO
select *
from sys.databases
select *
from sys.symmetric_keys
select *
from sys.dm_database_encryption_keys


USE AdventureWorks
GO

CREATE DATABASE ENCRYPTION KEY
WITH ALGORITHM = AES_128
ENCRYPTION BY SERVER CERTIFICATE MyServerCert
GO

/*
	You get warned if you do not backup the Certificate
*/
USE master
GO

BACKUP CERTIFICATE MyServerCert
TO FILE='E:\SQLBACKUP\INSTANCE1\MyserverCert.cer'
WITH PRIVATE KEY (FILE='E:\SQLBACKUP\INSTANCE1\MyServerCert.pvk',
	ENCRYPTION BY PASSWORD='My1Secure2Password!')	
GO

/* 
	Let's look at the certificates now.
*/
select 
	name,
	pvt_key_encryption_type_desc,
	[subject],
	pvt_key_last_backup_date
from sys.certificates

/*
	Now Set the Encryption Mode on
*/
ALTER DATABASE TESTTDE
SET ENCRYPTION ON
GO

ALTER DATABASE AdventureWorks
SET ENCRYPTION ON
GO

select *
from sys.databases

USE master; 

GO
/* 
	Checking the status of all databases
	Notice that there are 2 databases that are encrypted
	after setting encryption on.  TempDB and the database
	itself.
*/
SELECT 
    db.name,
    db.is_encrypted,
    dm.encryption_state,
    dm.percent_complete,
    dm.key_algorithm,
    dm.key_length
FROM 
    sys.databases db
    LEFT OUTER JOIN sys.dm_database_encryption_keys dm
        ON db.database_id = dm.database_id;

/*
	Interesting to note:
	sys.database has a CREATE_DATE column that is according
	to your local time zone (of the server).
	sys.dm_database_encryption_keys has a column CREATE_DATE
	that is GMT instead of Local.
*/
SELECT 
	db.name, 
	db.create_date
FROM sys.databases db
GO

SELECT 
	db.name,
	db.create_date as db_created,
	dm.create_date as enc_created
FROM
	sys.databases db
	LEFT OUTER JOIN sys.dm_database_encryption_keys dm
		ON db.database_id = dm.database_id
GO


USE master; 
GO

BACKUP DATABASE TESTTDE 
	TO DISK='E:\SQLBACKUP\INSTANCE1\TESTTDE_enc.bak' 
	WITH INIT
GO
BACKUP DATABASE TESTTDE 
	TO DISK='E:\SQLBACKUP\INSTANCE1\TESTTDE_enc_compressed.bak' 
	WITH INIT, COMPRESSION
GO

BACKUP DATABASE AdventureWorks
	TO DISK='E:\SQLBACKUP\INSTANCE1\AdventureWorks_enc.bak' 
	WITH INIT
GO

BACKUP DATABASE AdventureWorks
	TO DISK='E:\SQLBACKUP\INSTANCE1\AdventureWorks_enc_compressed.bak' 
	WITH INIT, COMPRESSION
GO

/*
** Switch to INSTANCE2
*/
select @@VERSION

/*
** Why do you get an error on this statement?
** You have not brought the Encryption Hierarchy back in sync.
*/
RESTORE FILELISTONLY FROM DISK='C:\SQLBACKUP\TESTTDE_enc.bak'
GO

USE master;
GO
CREATE MASTER KEY 
ENCRYPTION BY PASSWORD = 'INSTANCE2_Use1Strong2Password3Here!';
GO
CREATE CERTIFICATE MyServerCert
    FROM FILE = 'C:\SQLBACKUP\MyServerCert.cer' 
    WITH PRIVATE KEY (FILE = 'C:\SQLBACKUP\MyServerCert.pvk', 
    DECRYPTION BY PASSWORD = 'My1Secure2Password!');
GO

select *
from sys.certificates

GO
/*
No need to create the Database Encryption Key as it is in 
the database already, but needed the Certificate to 
allow unencryption
*/

RESTORE FILELISTONLY FROM DISK='C:\SQLBACKUP\TESTTDE_enc.bak'
GO

RESTORE DATABASE TESTTDE 
FROM DISK='C:\SQLBACKUP\TESTTDE_enc.bak'
WITH MOVE 'TESTTDE' TO 'C:\sqldata\TESTTDE.mdf',
	MOVE 'TESTTDE_Log' TO 'C:\sqldata\TESTTDE_log.ldf'
GO

USE TESTTDE
GO
SELECT *
FROM dbo.TestTable
GO

use master
drop master key

/*
	Just one little warning...
	Protect your certificates
*/
USE master
GO
DROP CERTIFICATE MyServerCert
GO
/*
	We can still see the data in the database
*/

USE TESTTDE
GO
SELECT *
FROM dbo.TestTable
GO
