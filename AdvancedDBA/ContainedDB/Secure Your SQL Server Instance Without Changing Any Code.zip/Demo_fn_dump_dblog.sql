USE master;
GO

IF EXISTS (SELECT 1
		    FROM sys.databases
		    WHERE name = N'Demo_fn_dump_dblog')
	DROP DATABASE Demo_fn_dump_dblog;
GO

CREATE DATABASE Demo_fn_dump_dblog ON 
	PRIMARY ( NAME = N'Demo_fn_dump_dblog', 
			  FILENAME = N'C:\LocalDatabases\Demo_fn_dump_dblog.mdf' , 
			  SIZE = 4096KB , 
			  FILEGROWTH = 1024KB )
    LOG ON ( NAME = N'Demo_fn_dump_dblog_log', 
			 FILENAME = N'C:\LocalDatabases\Demo_fn_dump_dblog_log.ldf' , 
			 SIZE = 1024KB , 
			 FILEGROWTH = 256KB);
GO

ALTER DATABASE Demo_fn_dump_dblog
 SET RECOVERY FULL;
GO

BACKUP DATABASE Demo_fn_dump_dblog
 TO DISK = 'Demo_fn_dump_dblog_FULL.BAK'
 WITH INIT,
	  COMPRESSION,
	  STATS = 10,
	  CHECKSUM;
GO

USE Demo_fn_dump_dblog;
GO

CREATE TABLE dbo.TestTable (id INT IDENTITY(1,1) ,
						    filler CHAR(2000) DEFAULT(REPLICATE('DATA', 500)));
GO

INSERT INTO dbo.TestTable
 DEFAULT VALUES; 
GO 2

SELECT * FROM dbo.TestTable;
GO

DELETE 
 FROM dbo.TestTable
 WHERE id = 2;
GO

BACKUP LOG [Demo_fn_dump_dblog]
 TO DISK = 'Demo_fn_dump_dblog_LOG.TRN'
 WITH INIT,
      COMPRESSION,
	  STATS = 10,
	  CHECKSUM;
GO

-- Best function invocation ever in SQL Server ahead!

SELECT [RowLog Contents 0]
FROM fn_dump_dblog
(NULL, NULL, NULL, 1,
'Demo_fn_dump_dblog_LOG.TRN',
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
WHERE OPERATION = 'LOP_DELETE_ROWS'

-- Homework: write T-SQL to convert [RowLog Contents 0] to its actual data type
-- For beginning of transactions, use LOP_BEGIN_XACT

-- Clean up

USE master;
GO

ALTER DATABASE Demo_fn_dump_dblog SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
GO

DROP DATABASE Demo_fn_dump_dblog;
