USE [InjectionSandbox];
GO

/***************************************
* 
* Solutions for preventing SQL injection
*
***************************************/

/***************************************
* 
* 0. Don't write dynamic queries
*
***************************************/

DROP PROCEDURE IF EXISTS dbo.usp_GetFullNameSafe;
GO

CREATE PROCEDURE dbo.usp_GetFullNameSafe
	@ParmUserName varchar(100)
AS
BEGIN
	-- Our original query didn't need to be dynamic...so write it as 
	-- plain old parameterized SQL
	SELECT FullName FROM dbo.Users WHERE UserName =  @ParmUserName
END
GO

-- Our 'safe' parameter works as expected
EXEC dbo.usp_GetFullNameSafe 'TFly37' 

-- Our injected query fails to return any sensitive records
EXEC dbo.usp_GetFullNameSafe 'TFly37'' or 1=1 --'





/***************************************
* 
* 1. Damage Control - Limit execute access
*
***************************************/

-- Even if a query is exploitable, limit what a malicious user can do. 
-- Set up permissions to only allow select on our single table of interest.
-- This should be done for every dynamic SQL query where injection is a concern.

DROP USER IF EXISTS LimitedUser;
GO

CREATE USER LimitedUser
WITHOUT LOGIN;
GO

-- Only allow our LimitedUser access to the Users table
GRANT SELECT ON Users TO LimitedUser;
GO
 
DROP PROCEDURE IF EXISTS dbo.usp_GetFullNameExecuteAs;
GO

CREATE PROCEDURE dbo.usp_GetFullNameExecuteAs
	@ParmUserName varchar(100)
WITH EXECUTE AS 'LimitedUser' -- Execute our stored procedure as our LimitedUser
AS
BEGIN
	DECLARE @FullQuery varchar(1000)

	SET @FullQuery = '	SELECT FullName 
						FROM dbo.Users 
						WHERE UserName = ''' + @ParmUserName + '''' --injectable SQL

	EXEC(@FullQuery);
END
GO
-- Our 'safe' parameter works as expected
EXEC dbo.usp_GetFullNameExecuteAs 'TFly37'

-- Our injected WOULD work - except we only allow our "LimitedUser" access to dbo.Users
EXEC dbo.usp_GetFullNameExecuteAs 'TFly37'' UNION SELECT (SELECT * FROM sys.objects FOR XML PATH) --' 

-- However injection against the dbo.Users table will still work:
EXEC dbo.usp_GetFullNameExecuteAs 'TFly37'' OR 1=1 --'






/***************************************
* 
* 2. Use sp_executesql
*
***************************************/
-- sp_executesql allows you to name parameters in your dynamic SQL string
-- and then pass parameters into them during execution
DROP PROCEDURE IF EXISTS dbo.usp_GetFullNameSafeSpExecuteSQL;
GO

CREATE PROCEDURE dbo.usp_GetFullNameSafeSpExecuteSQL
	@ParmUserName varchar(100)
AS
BEGIN
	DECLARE @FullQuery nvarchar(1000)
	SET @FullQuery = N'SELECT FullName FROM dbo.Users WHERE UserName = @UserName'

	DECLARE @ParmDefinition nvarchar(100) = N'@UserName varchar(100)';
	EXEC sp_executesql @FullQuery, @ParmDefinition,  
						@UserName = @ParmUserName;  
END
GO

-- Our 'safe' parameter works as expected
EXEC dbo.usp_GetFullNameSafe 'TFly37' 

-- Our injected query fails to return any sensitive records
EXEC dbo.usp_GetFullNameSafe 'TFly37'' or 1=1 --'


-- What if we want to parameterize something other than a predicate? Like our table name?
DROP PROCEDURE IF EXISTS dbo.usp_GetFullNameFromTable;
GO

CREATE PROCEDURE dbo.usp_GetFullNameFromTable
	@ParmTableName varchar(100),
	@ParmUserName varchar(100)
AS
BEGIN
	DECLARE @FullQuery nvarchar(1000)
	SET @FullQuery = N'SELECT FullName FROM dbo.@TableName WHERE UserName = @UserName'

	DECLARE @ParmDefinition nvarchar(100) = N'@TableName varchar(100), @UserName varchar(100)';  
  
	EXEC sp_executesql @FullQuery, @ParmDefinition,  
						@UserName = @ParmUserName,
						@TableName = @ParmTableName;  

END
GO

-- This doesn't work!
EXEC dbo.usp_GetFullNameFromTable @ParmTableName = 'Users', @ParmUserName = 'TFly37' 


/***************************************
* 
* 3. Sanitize - QUOTENAME()
*
***************************************/

-- So what do we do?  Escape any dangerous characters with QUOTENAME(): 
-- https://technet.microsoft.com/en-us/library/ms176114(v=sql.110).aspx
-- QUOTENAME() only works if your parameter values are < 128 characters.
-- If longer than 128 characters, you will have to write a UDF to process your 
-- parameter in chunks: http://www.sommarskog.se/dynamic_sql.html#quotestring

SELECT QUOTENAME('te''st')
SELECT QUOTENAME('te''st','''')

DROP PROCEDURE IF EXISTS dbo.usp_GetFullNameFromTableSanitized;
GO

CREATE PROCEDURE dbo.usp_GetFullNameFromTableSanitized
	@ParmTableName varchar(100),
	@ParmUserName varchar(100)
AS
BEGIN
	DECLARE @FullQuery nvarchar(1000)
	SET @FullQuery = N'SELECT FullName FROM dbo.' + QUOTENAME(@ParmTableName) 
	+ ' WHERE UserName = @UserName'

	DECLARE @ParmDefinition nvarchar(100) = N'@UserName varchar(100)';  
  
	EXEC sp_executesql @FullQuery, @ParmDefinition,  
						@UserName = @ParmUserName

END
GO
-- Our 'safe' parameter works as expected
EXEC dbo.usp_GetFullNameFromTableSanitized 
	@ParmTableName = 'Users', 
	@ParmUserName = 'TFly37' 

-- Our injected query fails to return any sensitive records	
EXEC dbo.usp_GetFullNameFromTableSanitized 
	@ParmTableName = 'Users; SELECT * FROM dbo.Users; --', 
	@ParmUserName = 'TFly37'
	


/***************************************
* 
* 4. Sanitize - REPLACE()
*
***************************************/
-- DISCLAIMER: This solution is not foolproof 
DROP PROCEDURE IF EXISTS dbo.usp_GetFullNameFromTableReplace;
GO

CREATE PROCEDURE dbo.usp_GetFullNameFromTableReplace
	@ParmTableName varchar(100),
	@ParmUserName varchar(100)
AS
BEGIN
	-- Escape single quotes
	SET @ParmTableName = REPLACE(@ParmTableName, '''','''''')
	SET @ParmUserName = REPLACE(@ParmUserName, '''','''''')

	DECLARE @FullQuery nvarchar(1000)
	SET @FullQuery = N'SELECT FullName FROM dbo.' + @ParmTableName
	+ ' WHERE UserName = ''' + @ParmUserName + ''''

  
	EXEC(@FullQuery)

END
GO

-- Our 'safe' parameter works as expected
EXEC dbo.usp_GetFullNameFromTableReplace 
	@ParmTableName = 'Users', 
	@ParmUserName = 'TFly37' 

-- Our injected query fails to return on parameters that are surrounded by single quotes (ParmUserName) 	
EXEC dbo.usp_GetFullNameFromTableReplace 
	@ParmTableName = 'Users', 
	@ParmUserName = 'TFly37'' or 1=1 --'

-- However it doesn't help us on parameters that don't have single quotes around them (ParmTableName)
EXEC dbo.usp_GetFullNameFromTableReplace 
	@ParmTableName = 'Users; SELECT * FROM dbo.Users; --', 
	@ParmUserName = 'TFly37'

-- The point here is that using REPLACE() can be used...but it is hard.
-- We can build more complicated logic (checking for other input characters that might indicated injection,
-- like semicolons), however that can be comprised too (see 03-Homoglpyh attacks.sql)
	


/***************************************
* 
* 5. Limit inputs, check inputs
*
***************************************/

-- Another solution that isn't foolproof, but helps.
-- Among other reasons, this is why good coding standards matter

DROP PROCEDURE IF EXISTS dbo.usp_GetFullNameLongInput;
GO

CREATE PROCEDURE dbo.usp_GetFullNameLongInput
	@ParmUserName varchar(100)
AS
BEGIN
	DECLARE @FullQuery varchar(1000)

	SET @FullQuery = '	SELECT FullName 
						FROM dbo.Users 
						WHERE UserName = ''' + @ParmUserName + ''''

	EXEC(@FullQuery);
END
GO

DROP PROCEDURE IF EXISTS dbo.usp_GetFullNameShortInput;
GO

CREATE PROCEDURE dbo.usp_GetFullNameShortInput
	@ParmUserName varchar(6) -- If we know usernames will never be more than length 6, let's specify that
AS
BEGIN

	-- Assume our input should only ever allow letters and numbers
	IF @ParmUserName LIKE '%[^0-9a-z]%'
	BEGIN
		RETURN;
	END

	DECLARE @FullQuery varchar(1000)

	SET @FullQuery = '	SELECT FullName 
						FROM dbo.Users 
						WHERE UserName = ''' + @ParmUserName + ''''

	EXEC(@FullQuery);
END
GO

-- Our lazily typed input is injectable
EXEC dbo.usp_GetFullNameLongInput 'TFly37'' OR 1=1 --'

-- Our properly typed input is also injectable, but specifying the correct max data length 
-- truncates input text and prevents SQL injection in some instances.
EXEC dbo.usp_GetFullNameShortInput 'TFly37'' OR 1=1 --'

-- Alpha numeric values are allowed
EXEC dbo.usp_GetFullNameShortInput 'T37'

-- Non-alpha numerics are rejected
EXEC dbo.usp_GetFullNameShortInput 'T37;'
