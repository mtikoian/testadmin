--TODO
-- Upload presentation to bertwagner.com

-- Build and use our database for testing
DROP DATABASE IF EXISTS [InjectionSandbox];
GO
CREATE DATABASE [InjectionSandbox];
GO
USE [InjectionSandbox];
GO

DROP TABLE IF EXISTS dbo.Users
CREATE TABLE dbo.Users
(
	Id INT IDENTITY(1,1),
	FullName varchar(100),
	UserName varchar(40),
	HashedPassword char(66),
	JoinDate datetime2
)


INSERT INTO dbo.Users (FullName,UserName,HashedPassword,JoinDate)
SELECT 'Toucan Sam','TFly37', HASHBYTES('SHA2_256','asdf' + '2014-02-11'),'2014-02-11'
UNION ALL 
SELECT 'Crackle','StockingCap123', HASHBYTES('SHA2_256','asdf' + '2016-09-09'),'2016-09-09'
UNION ALL 
SELECT 'Tony','OrangeNBlack11', HASHBYTES('SHA2_256','asdf' + '2015-01-30'),'2015-01-30'
UNION ALL 
SELECT 'Smacks Frog','RibbetRibbet', HASHBYTES('SHA2_256','asdf' + '2017-08-09'),'2017-08-09'
UNION ALL 
SELECT 'Count Chocula','OneAhHaHa', HASHBYTES('SHA2_256','asdf' + '2016-11-24'),'2016-11-24'

SELECT * FROM dbo.Users