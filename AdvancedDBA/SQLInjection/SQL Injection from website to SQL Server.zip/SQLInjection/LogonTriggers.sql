USE AdventureWorks
GO

-- DROP TABLE AdventureWorks.dbo.InvalidKeyWords
CREATE TABLE AdventureWorks.dbo.InvalidKeyWords(Keyword NVARCHAR(100) PRIMARY KEY)
GO
INSERT INTO AdventureWorks.dbo.InvalidKeyWords
SELECT 'DROP' UNION ALL
SELECT 'ALTER' UNION ALL
SELECT 'SYS.' UNION ALL
SELECT 'WAITFOR' UNION ALL
SELECT 'DELAY'

-- DROP TABLE AdventureWorks.dbo.CaughtSQLInjectionAttempts
CREATE TABLE AdventureWorks.dbo.CaughtSQLInjectionAttempts
(
	ID INT IDENTITY(1,1) PRIMARY KEY,
	CreatedON datetime default getutcdate(),
	SPID INT,
	DBID INT,
    SqlText NVARCHAR(MAX)
)

/*
-- run this in another windows
SELECT  *
FROM    AdventureWorks.dbo.CaughtSQLInjectionAttempts

SELECT  *
FROM    AdventureWorks.dbo.InvalidKeyWords

DELETE	AdventureWorks.dbo.InvalidKeyWords
WHERE	Keyword = 'SYS.'
*/

/*
-- run this in a disconneced window
waitfor delay '00:00:03'

SELECT  *
FROM    master..spt_values
*/
GO


USE master
-- DROP TRIGGER dbTrigForLogon ON ALL SERVER
GO
CREATE TRIGGER dbTrigForLogon 
	ON ALL SERVER
	WITH EXECUTE AS 'sa'
	FOR LOGON 
AS
DECLARE @rowCnt INT;
declare @CaughtSQLInjectionAttempts table
(
	SPID INT,
	DBID INT,
    SqlText NVARCHAR(MAX)
)
INSERT INTO @CaughtSQLInjectionAttempts(SPID, DBID, SqlText)
SELECT  R.session_id, R.database_id, T.text
FROM    sys.dm_exec_requests R
		CROSS APPLY sys.dm_exec_sql_text(R.sql_handle) T
WHERE	session_id = @@SPID
		AND EXISTS (SELECT * FROM AdventureWorks.dbo.InvalidKeyWords WHERE T.text LIKE '%' + Keyword + '%' COLLATE Latin1_General_CI_AI);

SELECT @rowCnt = @@ROWCOUNT
IF @rowCnt > 0 
BEGIN
	PRINT 'SQL Injection detected!' 
	ROLLBACK TRANSACTION

	PRINT 'LOGGING START' 
	INSERT INTO AdventureWorks.dbo.CaughtSQLInjectionAttempts(SPID, DBID, SqlText)
	SELECT  SPID, DBID, SqlText
	FROM	@CaughtSQLInjectionAttempts
	PRINT 'LOGGING END'
END
GO

