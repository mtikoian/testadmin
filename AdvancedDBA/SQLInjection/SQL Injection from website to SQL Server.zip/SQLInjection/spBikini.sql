USE TheAwesome
GO
/*
Create a single master access stored procedure
*/
CREATE PROCEDURE spBikini
(
    @select NVARCHAR(500) = '' ,
    @tableName NVARCHAR(500) = '' ,
    @where NVARCHAR(500) = '1=1' ,
    @orderBy NVARCHAR(500) = '1'
)
AS
EXEC('SELECT ' + @select +
     ' FROM ' + @tableName +
     ' WHERE ' + @where +
     ' ORDER BY ' + @orderBy)
GO

/*
Valid use as anticipated by a novice developer
*/
EXEC spBikini @select = '*', 
              @tableName = 'Users', 
              @where = 'UserName = ''Mladen'' AND UserPassword = ''MyHardPwd''', 
              @orderBy = 'UserID'
/*
Malicious use SQL injection
The SQL injection principles are the same as
with SQL string concatenation I described earlier,
so I won't repeat them again here.
*/
EXEC spBikini @select = '* FROM INFORMATION_SCHEMA.TABLES FOR XML RAW --',
			  @tableName = '--Users',
              @where = '--UserName = ''Mladen'' AND UserPassword = ''MyHardPwd''',
              @orderBy = '--UserID'

