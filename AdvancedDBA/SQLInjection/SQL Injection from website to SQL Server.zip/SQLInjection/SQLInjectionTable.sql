USE TheAwesome
GO
DROP TABLE Users
GO
CREATE TABLE Users
(
    UserId INT IDENTITY(1, 1) PRIMARY KEY,
    UserName VARCHAR(50),
    UserPassword NVARCHAR(10),
	UserDescription NVARCHAR(400)
)

/* Insert 2 users */
INSERT INTO Users(UserName, UserPassword, UserDescription)
SELECT 'Mladen', 'MyHardPwd', 'Yours truly' UNION ALL
SELECT 'ChuckNorris', 'strongPwd', 'Cobra bit him once and then died in excruciating pain 5 days later'


