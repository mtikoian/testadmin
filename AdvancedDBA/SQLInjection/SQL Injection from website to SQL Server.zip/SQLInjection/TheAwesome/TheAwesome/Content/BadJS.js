﻿alert("OMG, WE ARE HACKED!!! Watch the awesome redirect to Online Casino!");
window.location = "http://www.andrewkardon.com/wp-content/uploads/2012/10/ngbbs4b16701676fe6.jpg"
//window.location = "http://www.google.com";
//window.location = "file://d:/SkyDrive/Presentations/PASS2012/SadCat.jpg";