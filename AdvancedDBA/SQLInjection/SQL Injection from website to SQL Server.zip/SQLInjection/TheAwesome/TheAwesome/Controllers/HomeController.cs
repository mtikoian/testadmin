﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TheAwesome.Models;

namespace TheAwesome.Controllers
{
    [HandleError]
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            ViewData["Message"] = "";
            return View();
        }

        public ActionResult Awesomize(string sqlText)
        {
            string msg = "";
            sqlText = sqlText.Trim();
            if (!string.IsNullOrEmpty(sqlText))
            {
                TheAwesomeModel model = new TheAwesomeModel();
                msg = "User <br/>" + sqlText + "<br />";
                var userExists = model.DoesUserExist(sqlText);
                if (userExists)
                    msg += " is AWESOME!";
                else
                    msg += " is NOT awesome.";
            }
            ViewData["Message"] = msg;
            return View("Index");
        }

        public ActionResult ShowUser()
        {
            ViewData["UserDescription"] = "";
            ViewData["UserName"] = "";

            return View("User");
        }

        [ValidateAntiForgeryToken]
        public ActionResult UserDetails()
        {
            ViewData["UserDescription"] = "";
            ViewData["UserName"] = "";

            string userName = Request.Form["UserName"];
            if (userName != null)
            {
                TheAwesomeModel model = new TheAwesomeModel();
                string userDescription = model.GetUserDescription(userName);
                ViewData["UserDescription"] = userDescription;
                ViewData["UserName"] = userName;
            }
            return View("User");
        }

        /*
        CSRF ATTACK:
        User must be somehow conviced to go to this malicious page.
        Because it correctly posts to our server it uses users cookies for our site. 
        And with that it uses user's security context
         * * 
        <body onload="document.getElementById('form1').submit()">
            <form id="form1" action="http://TheAwesome.com/Home/ShowUser" method="post">
                <input name="UserName" value="MaliciousUserName" />
            </form>
        </body>
        */
    }
}
