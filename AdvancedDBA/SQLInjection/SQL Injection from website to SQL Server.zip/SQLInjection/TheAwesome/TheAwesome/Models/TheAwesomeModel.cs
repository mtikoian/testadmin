﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;

namespace TheAwesome.Models
{
    public class TheAwesomeModel
    {
        string _connString = @"Server=Zen\SQL2012;Database=TheAwesome;Trusted_Connection=True;";

        public bool DoesUserExist(string username)
        {
            using (SqlConnection conn = new SqlConnection(_connString))
            {
                /* 
                This is the SQL string you usually see with 
                novice developers. It returns a row if a 
                user exists and no rows if it doesn't
                */
                string sql = "SELECT UserId, UserName, UserDescription FROM Users WHERE UserName = '" + username + "'";
                SqlCommand cmd = conn.CreateCommand();
                cmd.CommandText = sql;
                cmd.CommandType = CommandType.Text;
                cmd.Connection.Open();
                /*
                If a user doesn't exist the cmd.ExecuteScalar() 
                returns null; this is just to simplify the 
                example; you can use other Execute methods too
                */
                string userExists = (cmd.ExecuteScalar() ?? "0").ToString();
                return userExists != "0";
            }
        }

        public bool DoesUserExistSafe(string username, string password)
        {
            using (SqlConnection conn = new SqlConnection(_connString))
            {
                //This is the version of the SQL string that should be safe from SQL injection        
                string sql = "SELECT UserId, UserName, UserDescription FROM Users WHERE UserName = @username AND UserPassword = @password";
                SqlCommand cmd = conn.CreateCommand();
                cmd.CommandText = sql;
                cmd.CommandType = CommandType.Text;

                // adding 2 SQL Parameters solves the SQL injection issue completely
                SqlParameter usernameParameter = new SqlParameter();
                usernameParameter.ParameterName = "@username";
                usernameParameter.DbType = DbType.String;
                usernameParameter.Value = username;
                cmd.Parameters.Add(usernameParameter);

                SqlParameter passwordParameter = new SqlParameter();
                passwordParameter.ParameterName = "@password";
                passwordParameter.DbType = DbType.String;
                passwordParameter.Value = password;
                cmd.Parameters.Add(passwordParameter);

                cmd.Connection.Open();
                /*
                If a user doesn't exist the cmd.ExecuteScalar() 
                returns null; this is just to simplify the 
                example; you can use other Execute methods too
                */
                string userExists = (cmd.ExecuteScalar() ?? "0").ToString();
                return userExists == "1";
            }
        }

        public string GetUserDescription(string userName)
        {
            using (SqlConnection conn = new SqlConnection(_connString))
            {
                string sql = "SELECT UserDescription FROM Users WHERE UserName = @username";
                SqlCommand cmd = conn.CreateCommand();
                cmd.CommandText = sql;
                cmd.CommandType = CommandType.Text;
                cmd.Connection.Open();
                SqlParameter usernameParameter = new SqlParameter();
                usernameParameter.ParameterName = "@username";
                usernameParameter.DbType = DbType.String;
                usernameParameter.Value = userName;
                cmd.Parameters.Add(usernameParameter);

                string userPassword = (cmd.ExecuteScalar() ?? "N/A").ToString();
                return userPassword;
            }
        }
    }
}