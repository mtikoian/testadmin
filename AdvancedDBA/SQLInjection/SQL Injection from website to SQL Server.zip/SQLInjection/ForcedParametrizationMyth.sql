-- SET PARAMETRIZATION to FORCED in Database Options
use AdventureWorks
GO
dbcc freeproccache
GO

declare @sql varchar(max),
		@param varchar(max)
--SET @param = '676'

SET @param = '0; SELECT * FROM sys.tables WHERE name = ''SalesPerson''  ; --'

SET @sql = 'SELECT  *
			FROM    Sales.SalesOrderHeader SOH
					join Sales.SalesOrderDetail SOD on SOH.SalesOrderID = SOD.SalesOrderID
			WHERE	SOH.CustomerID = ' + @param + ' and SOH.SalesOrderID = 43659'
--select @sql 
exec(@sql)

GO

-- objtype is prepared for forced parametrization
SELECT  CP.objtype, ST.text
FROM    sys.dm_exec_cached_plans CP		
		cross apply sys.dm_exec_sql_text(CP.plan_handle) ST
WHERE	dbid = db_id()

