CREATE TABLE [dbo].[Orders](
	[OrderId] [smallint] IDENTITY(1,1) NOT NULL,
	[UserId] [smallint] NOT NULL,
	[Amount] [varchar](50) NOT NULL,
	[CreditCard] [varchar](50) NOT NULL,
 CONSTRAINT [PK_Orders] PRIMARY KEY CLUSTERED ([OrderId])
)
GO

INSERT Orders(UserId,Amount,CreditCard)
SELECT 	3,	'0.01',	'123456'
UNION
SELECT 	2,	'0.01',	'222111'
UNION
SELECT 	1,	'0.01',	'12345678'

GO

CREATE TABLE [dbo].[Users](
	[UserId] [smallint] IDENTITY(1,1) NOT NULL,
	[UserName] [varchar](50) NOT NULL,
	[Password] [varchar](50) NOT NULL,
 CONSTRAINT [PK_Users] PRIMARY KEY CLUSTERED ([UserId] ASC)
)
GO
select * from users
INSERT Users (UserName, Password)
SELECT 'Rob',	'password'
UNION
SELECT 'test',	'test'
UNION
SELECT 'admin',	'admin'