use AdventureWorks
go

create table CreditCardInfo (userid int, cardnumber varchar(30))
insert CreditCardInfo values (1, '1234123412341234')

select *
from CreditCardInfo

