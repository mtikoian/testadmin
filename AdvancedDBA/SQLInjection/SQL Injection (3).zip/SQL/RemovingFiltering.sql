--changing filtering characteristics
USE Northwind
GO
SET NOCOUNT ON
GO

DECLARE @LastName nvarchar(20),
        @sql varchar(100)

--"good" application user
SET @LastName = 'Fuller' --sent in from text box in application

SET @sql = 'SELECT * FROM dbo.Employees WHERE LastName = ''' + @LastName + ''';'

PRINT @sql
PRINT ''

EXEC (@sql)


--"sneaky" application user

DECLARE @LastName nvarchar(20),
        @sql varchar(100)

SET @LastName = ''' or ''1''=''1' --sent in from text box in application

SET @sql = 'SELECT * FROM dbo.Employees WHERE LastName = ''' + @LastName + ''';'

PRINT @sql
PRINT ''

EXEC (@sql)
