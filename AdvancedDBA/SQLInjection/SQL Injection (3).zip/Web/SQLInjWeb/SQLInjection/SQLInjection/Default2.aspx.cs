using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace SQLInjection
{
	public partial class Default2 : System.Web.UI.Page
	{
		protected void Page_Load(object sender, EventArgs e)
		{

		}
		protected void cmdSearch_Click(object sender, EventArgs e)
		{
			SearchProducts();
		}

		private void SearchProducts()
		{
			//ProductResults.DataSource = BADGetProducts();
			//ProductResults.DataSource = GoodWithCheckGetProducts();
			ProductResults.DataSource = GoodWithParameterGetProducts();
			ProductResults.DataBind();
		}

		#region BAD
		private DataView BADGetProducts()
		{
			string connStr = "Server=INDICIUMLAPTOP4;Database=AdventureWorks;User ID=SQLInjection;pwd=sqlinjection";

			// dynamic query susceptible to SQL injection attacks
			// examples:
			// 1). explore
			//     step 1: ZZZ' UNION SELECT name, CAST(id AS VARCHAR(10)), '' FROM sysobjects WHERE xtype ='U' --
			//     step 2: ZZZ' UNION SELECT COLUMN_NAME, DATA_TYPE, TABLE_SCHEMA FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'Address' --
			//     step 3: ZZZ' UNION SELECT TOP 100 AddressLine1, City, PostalCode FROM Person.Address --
            // 2). Just see all rows
            //     ' or '1'='1'--%'
            // 3). Find column/table information from errors
            //     ' or email='1'--%'
            //     &&&' or 1 = convert(int,(select top 1 name from sysobjects where id=(select top 1 id from (select TOP 1 id from sysobjects where xtype='U' order by id) sq order by id DESC))) --%'
			// 4). destroy
			//     ZZZ'; DROP TABLE CreditCardInfo --
            // 5). other: INSERT/UPDATE, XP_CMDSHELL, SHUTDOWN (SA access to your database from webserver, anyone??), etc

			string cmdStr = @"SELECT Name, ProductNumber, Color
                              FROM Production.Product 
                              WHERE Name LIKE N'%" + SearchText.Text + "%'";

			using (SqlConnection conn = new SqlConnection(connStr))
			using (SqlDataAdapter sda = new SqlDataAdapter(cmdStr, conn))
			{
				DataTable dtProducts = new DataTable();

				sda.Fill(dtProducts);

				return dtProducts.DefaultView;
			}

		}
		#endregion

		#region GOOD WITH CHECK BLACK LIST
		public static string[] blackList = {"--",";--",";","/*","*/","@@","@",
                                           "char","nchar","varchar","nvarchar",
                                           "alter","begin","cast","create","cursor",
                                           "declare","delete","drop","end","exec","execute",
                                           "fetch","insert","kill","open",
                                           "select", "sys","sysobjects","syscolumns",
                                           "table","update"};

		private bool CheckInput(string SearchText)
		{
			for (int i = 0; i < blackList.Length; i++)
			{
				if ((SearchText.IndexOf(blackList[i], StringComparison.OrdinalIgnoreCase) >= 0))
				{
					HttpContext.Current.Response.Redirect("~/Error.aspx");
					return false;
				}
			}
			return true;
		}

		private DataView GoodWithCheckGetProducts()
		{
			string connStr = "Server=INDICIUMLAPTOP4;Database=AdventureWorks;User ID=SQLInjection;pwd=sqlinjection";

			// dynamic query susceptible to SQL injection attacks
			// examples:
			// 1). explore
			//     step 1: ZZZ' UNION SELECT name, CAST(id AS VARCHAR(10)), '' FROM sysobjects WHERE xtype ='U' --
			//     step 2: ZZZ' UNION SELECT COLUMN_NAME, DATA_TYPE, TABLE_SCHEMA FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'Address' --
			//     step 3: ZZZ' UNION SELECT AddressLine1, City, PostalCode FROM Person.Address --
			// 2). destroy
			//     ZZZ'; DROP TABLE CreditCardInfo --

			string cmdStr = @"SELECT Name, ProductNumber, Color
                              FROM Production.Product 
                              WHERE Name LIKE N'%" + SearchText.Text + "%'";

			if (CheckInput(SearchText.Text))
			{
				using (SqlConnection conn = new SqlConnection(connStr))
				using (SqlDataAdapter sda = new SqlDataAdapter(cmdStr, conn))
				{
					DataTable dtProducts = new DataTable();

					sda.Fill(dtProducts);

					return dtProducts.DefaultView;
				}
			}
			else
			{
				DataTable dtProducts = new DataTable();
				return dtProducts.DefaultView;
			}

		}

		#endregion

		#region GOOD WITH PARAMETER
		private DataView GoodWithParameterGetProducts()
		{
			string connStr = "Server=INDICIUMLAPTOP4;Database=AdventureWorks;User ID=SQLInjection;pwd=sqlinjection";

			// dynamic query susceptible to SQL injection attacks
			// examples:
			// 1). explore
			//     step 1: ZZZ' UNION SELECT name, CAST(id AS VARCHAR(10)), '' FROM sysobjects WHERE xtype ='U' --
			//     step 2: ZZZ' UNION SELECT COLUMN_NAME, DATA_TYPE, TABLE_SCHEMA FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'Address' --
			//     step 3: ZZZ' UNION SELECT AddressLine1, City, PostalCode FROM Person.Address --
			// 2). destroy
			//     ZZZ'; DROP TABLE CreditCardInfo --

			string cmdStr = @"SELECT Name, ProductNumber, Color
                              FROM Production.Product 
                              WHERE Name LIKE N'%' + @SearchText + '%'";

			using (SqlConnection conn = new SqlConnection(connStr))
			using (SqlDataAdapter sda = new SqlDataAdapter(cmdStr, conn))
			{
				DataTable dtProducts = new DataTable();

				SqlParameter parm = sda.SelectCommand.Parameters.Add("@SearchText",
                    //ALWAYS make sure this is EXACTLY the correct datatype and size!! Potentially HUGE performance/concurrency issues!!
                    //DECLARE @prod varchar(20) = 'Ball%';SELECT Name, ProductNumber, Color FROM Production.Product WHERE Name LIKE @prod --OPTION (RECOMPILE)
                                    SqlDbType.NVarChar, 50);  
				parm.Value = SearchText.Text;

				sda.Fill(dtProducts);

				return dtProducts.DefaultView;
			}

		}
		#endregion
	}
}

