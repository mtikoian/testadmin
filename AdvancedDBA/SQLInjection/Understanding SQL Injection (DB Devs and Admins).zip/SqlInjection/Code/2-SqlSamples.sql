--
SET NOCOUNT ON
USE InjectionDB
GO

DECLARE @sql1       nvarchar(1000)
DECLARE @sql2       nvarchar(1000)
DECLARE @loginName  nvarchar(100)
DECLARE @password   nvarchar(100)

SET @loginName  = N'meg'
SET @password   = N'3re#ehebResw'
--SET @loginName  = N''
--SET @password   = N''' OR 1 = 1--'

SET @sql1 = N'SELECT * FROM dbo.Users WHERE LoginName = '''
    + @loginName
    + N''' AND [Password] = '''
    + @password
    + ''''

SET @sql2 = N'SELECT * FROM dbo.Users WHERE LoginName = @loginName AND [Password] = @password'

PRINT @sql1
PRINT @sql2
PRINT '=================='

-- Unsafe call to EXEC
EXEC (@sql1)

-- Unsafe call to sp_executesql
EXEC sp_executesql @sql1

-- Safe call to sp_executesql
EXEC sp_executesql
    @stmt      = @sql2,
    @params    = N'@loginName nvarchar(100), @password nvarchar(100)',
    @loginName = @loginName,
    @password  = @password
