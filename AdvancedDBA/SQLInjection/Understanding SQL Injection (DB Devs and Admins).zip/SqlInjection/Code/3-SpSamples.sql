--
SET NOCOUNT ON
USE InjectionDB
GO

-- ===================================
-- Insecure SP
-- ===================================
IF EXISTS (SELECT * FROM sys.procedures WHERE [name] = 'UserReadByLoginAndPassword_Insecure')
    DROP PROCEDURE dbo.UserReadByLoginAndPassword_Insecure
GO
CREATE PROCEDURE dbo.UserReadByLoginAndPassword_Insecure (
    @LoginName      varchar(100),
    @Password       varchar(100)
) AS
BEGIN
    SET NOCOUNT ON

    DECLARE @sql    nvarchar(1000)

    SET @sql = N'SELECT * FROM dbo.Users WHERE LoginName = '''
        + @loginName
        + N''' AND [Password] = '''
        + @password
        + ''''

    EXEC sp_executesql @sql

    RETURN(0)
END
GO

-- ===================================
-- Secure SP1
-- ===================================
IF EXISTS (SELECT * FROM sys.procedures WHERE [name] = 'UserReadByLoginAndPassword_Secure')
    DROP PROCEDURE dbo.UserReadByLoginAndPassword_Secure
GO
CREATE PROCEDURE dbo.UserReadByLoginAndPassword_Secure (
    @LoginName      varchar(100),
    @Password       varchar(100)
) AS
BEGIN
    SET NOCOUNT ON

    SELECT *
    FROM dbo.Users
    WHERE LoginName   = @LoginName
       AND [Password] = @Password

    RETURN(0)
END
GO

-- ===================================
-- Secure SP (dynamic SQL)
-- ===================================
IF EXISTS (SELECT * FROM sys.procedures WHERE [name] = 'UserReadByLoginAndPassword_Secure_Dynamic')
    DROP PROCEDURE dbo.UserReadByLoginAndPassword_Secure_Dynamic
GO
CREATE PROCEDURE dbo.UserReadByLoginAndPassword_Secure_Dynamic (
    @LoginName      varchar(100),
    @Password       varchar(100)
) AS
BEGIN
    SET NOCOUNT ON

    DECLARE @sql       nvarchar(1000)

    SET @sql = N'SELECT * FROM dbo.Users WHERE LoginName = @loginName AND [Password] = @password'

    EXEC sp_executesql
        @stmt      = @sql,
        @params    = N'@loginName nvarchar(100), @password nvarchar(100)',
        @loginName = @LoginName,
        @password  = @Password

    RETURN(0)
END
GO

-- ===================================
-- Black-list
-- ===================================
IF EXISTS (SELECT * FROM sys.procedures WHERE [name] = 'UserReadByLoginAndPassword_BlackList')
    DROP PROCEDURE dbo.UserReadByLoginAndPassword_BlackList
GO
CREATE PROCEDURE dbo.UserReadByLoginAndPassword_BlackList (
    @LoginName      varchar(100),
    @Password       varchar(100)
) AS
BEGIN
    SET NOCOUNT ON

    IF CHARINDEX('--', @LoginName) <> 0 OR CHARINDEX('--', @Password) <> 0 BEGIN
        RAISERROR('Warning: Possible SQL Injection code in user input.', 10, 1)
        RETURN(-1)
    END

    SELECT *
    FROM dbo.Users
    WHERE LoginName   = @LoginName
       AND [Password] = @Password

    RETURN(0)
END
GO

-- ===================================
DECLARE @sql1       nvarchar(1000)
DECLARE @sql2       nvarchar(1000)
DECLARE @loginName  nvarchar(20)
DECLARE @password   nvarchar(40)

SET @loginName  = N'meg'
SET @password   = N'3re#ehebResw'
--SET @loginName  = N''
--SET @password   = N''' OR 1 = 1--'

PRINT '    ==>> UserReadByLoginAndPassword_Insecure'
EXEC dbo.UserReadByLoginAndPassword_Insecure
    @LoginName = @loginName,
    @Password  = @password

PRINT '    ==>> UserReadByLoginAndPassword_Secure'
EXEC dbo.UserReadByLoginAndPassword_Secure
    @LoginName = @loginName,
    @Password  = @password

PRINT '    ==>> UserReadByLoginAndPassword_Secure_Dynamic'
EXEC dbo.UserReadByLoginAndPassword_Secure_Dynamic
    @LoginName = @loginName,
    @Password  = @password

PRINT '    ==>> UserReadByLoginAndPassword_BlackList'
EXEC dbo.UserReadByLoginAndPassword_BlackList
    @LoginName = @loginName,
    @Password  = @password
