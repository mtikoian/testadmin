SET NOCOUNT ON
USE InjectionDB
GO

DELETE FROM dbo.Users; DELETE FROM dbo.Orders; DBCC CHECKIDENT('Users', RESEED, 0);

-- Populate Users
INSERT INTO dbo.Users (LoginName, UserName, [Password]) VALUES ('christine',   'Christine Daa�',      'Qutu2ubAPrA-')
INSERT INTO dbo.Users (LoginName, UserName, [Password]) VALUES ('carlotta',    'Carlotta Giudicelli', 'Pra6@QU4efra')
INSERT INTO dbo.Users (LoginName, UserName, [Password]) VALUES ('ubaldo',      'Ubaldo Piangi',       '?ru_eH9mupru')
INSERT INTO dbo.Users (LoginName, UserName, [Password]) VALUES ('meg',         'Meg Giry',            '3re#ehebResw')
INSERT INTO dbo.Users (LoginName, UserName, [Password]) VALUES ('joseph',      'Joseph Buquet',       'j+5rUdrUxuWr')

-- Populate Orders
DECLARE @ct         int
DECLARE @max        int
DECLARE @userID     int
DECLARE @userName   varchar(60)
DECLARE @amount     money
DECLARE @cc         char(16)

SET @ct = 0
SELECT @max = COUNT(*) FROM dbo.Users

WHILE @ct < @max BEGIN
    SET @ct = @ct + 1
    SELECT
        @userID   = UserID,
        @userName = UserName,
        @amount   = CONVERT(money, ROUND((RAND() * 100), 2)),
        @cc       = CONVERT(varchar(16), CONVERT(bigint, ROUND((RAND() * 10000000000000000), 0)))
    FROM dbo.Users
    WHERE UserID = @ct

    INSERT INTO dbo.Orders (UserID, Amount, CreditCard, NameOnCard) VALUES (@userID, @amount *  1, @cc, @userName)
    --INSERT INTO dbo.Orders (UserID, Amount, CreditCard, NameOnCard) VALUES (@userID, @amount * 10, @cc, @userName)
END

SELECT * FROM dbo.Users ORDER BY UserID
SELECT * FROM dbo.Orders ORDER BY OrderID
GO
