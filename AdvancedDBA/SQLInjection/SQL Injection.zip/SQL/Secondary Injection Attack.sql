select cast('select * from sysobjects' as varbinary(256))
0x73656C656374202A2066726F6D207379736F626A65637473

declare @var varchar(1000)
set @var = cast(0x73656C656374202A2066726F6D207379736F626A65637473 as varchar(100))
print @var

exec (@var)



