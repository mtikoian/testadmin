USE AdventureWorks
GO

IF OBJECT_ID('ProductSearch', N'P') IS NOT NULL
   DROP PROCEDURE ProductSearch;

GO

-- BAD
CREATE PROCEDURE ProductSearch
 @SearchText NVARCHAR(200)
AS
 EXEC('SELECT Name, ProductNumber, Color FROM Production.Product WHERE Name LIKE N''%' +
       @SearchText + '''%''');

GO

DECLARE @SearchText NVARCHAR(200);

SET @SearchText = N'ZZZ'' UNION SELECT name, CAST(id AS VARCHAR(10)), '''' FROM sysobjects WHERE xtype =''U'' --';
EXEC ProductSearch @SearchText;

GO


-- GOOD WITH CHECK
IF OBJECT_ID('GoodWithCheckProductSearch', N'P') IS NOT NULL
   DROP PROCEDURE GoodWithCheckProductSearch;

GO

CREATE PROCEDURE GoodWithCheckProductSearch
 @SearchText NVARCHAR(200)
AS

 IF  UPPER(@SearchText) LIKE UPPER(N'%0x%')
  OR UPPER(@SearchText) LIKE UPPER(N'%;%')
  OR UPPER(@SearchText) LIKE UPPER(N'%''%')
  OR UPPER(@SearchText) LIKE UPPER(N'%--%')
  OR UPPER(@SearchText) LIKE UPPER(N'%/*%*/%')
  OR UPPER(@SearchText) LIKE UPPER(N'%EXEC %')
  OR UPPER(@SearchText) LIKE UPPER(N'%xp[_]%')
  OR UPPER(@SearchText) LIKE UPPER(N'%sp[_]%')
  OR UPPER(@SearchText) LIKE UPPER(N'%SELECT %')
  OR UPPER(@SearchText) LIKE UPPER(N'%INSERT %')
  OR UPPER(@SearchText) LIKE UPPER(N'%UPDATE %')
  OR UPPER(@SearchText) LIKE UPPER(N'%DELETE %')
  OR UPPER(@SearchText) LIKE UPPER(N'%TRUNCATE %')
  OR UPPER(@SearchText) LIKE UPPER(N'%CREATE %')
  OR UPPER(@SearchText) LIKE UPPER(N'%ALTER %')
  OR UPPER(@SearchText) LIKE UPPER(N'%DROP %')
  -- add other possible strings used in SQL Injection here
BEGIN
  RAISERROR('Possible SQL Injection attempt.', 16, 1);
  RETURN;
END

 EXEC('SELECT Name, ProductNumber, Color FROM Production.Product WHERE Name LIKE N''%' + @SearchText + '%''');

GO

DECLARE @SearchText NVARCHAR(200);

--SET @SearchText = 'Ball'
SET @SearchText = 'ZZZ'' UNION SELECT name, CAST(id AS VARCHAR(10)), '''' FROM sysobjects WHERE xtype =''U'' --';
EXEC GoodWithCheckProductSearch @SearchText;

GO


-- GOOD WITH PARAMETER
IF OBJECT_ID('GoodWithParameterProductSearch', N'P') IS NOT NULL
   DROP PROCEDURE GoodWithParameterProductSearch;

GO

CREATE PROCEDURE GoodWithParameterProductSearch
 @SearchText NVARCHAR(200)
AS

 DECLARE @sql NVARCHAR(200);

 SET @sql = N'SELECT Name, ProductNumber, Color FROM Production.Product WHERE Name LIKE N''%' +
             '@SearchText%''';

 DECLARE @params NVARCHAR(50);

 SET @params = N'@SearchText NVARCHAR(200)';

 EXEC sp_executesql @sql, @params, @SearchText = @SearchText;

GO

DECLARE @SearchText VARCHAR(200);

SET @SearchText = N'ZZZ'' UNION SELECT name, CAST(id AS VARCHAR(10)), '''' FROM sysobjects WHERE xtype =''U'' --';
EXEC GoodWithParameterProductSearch @SearchText;

-- GOOD WITHOUT DYNAMIC SQL
IF OBJECT_ID('GoodWithoutDSQLProductSearch', N'P') IS NOT NULL
   DROP PROCEDURE GoodWithoutDSQLProductSearch;

GO

CREATE PROCEDURE GoodWithoutDSQLProductSearch
 @SearchText NVARCHAR(200)
AS
 SELECT Name, ProductNumber, Color
 FROM Production.Product
 WHERE Name LIKE N'%' + @SearchText + '%'; --Performance Issue!!

GO

DECLARE @SearchText NVARCHAR(200);

SET @SearchText = N'ZZZ'' UNION SELECT name, CAST(id AS VARCHAR(10)), '''' FROM sysobjects WHERE xtype =''U'' --';
EXEC GoodWithoutDSQLProductSearch @SearchText;