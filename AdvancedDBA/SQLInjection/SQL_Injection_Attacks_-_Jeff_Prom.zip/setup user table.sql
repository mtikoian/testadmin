use AdventureWorksDemo
GO
-- recreate the user table
CREATE TABLE [dbo].[DimUser](
	[UserKey] [int] IDENTITY(1,1) NOT NULL,
	[UserName] [varchar](100) NULL,
	[FirstName] [varchar](50) NULL,
	[LastName] [varchar](50) NULL,
	[SSN] [varchar](50) NULL,
	[Password] [varchar](50) NULL,
	[CreditCardNum] [varchar](50) NULL,
	[CreditCardType] [varchar](50) NULL,
	[EmailAddr] [varchar](50) NULL,
	[UserType] [varchar](50) NULL,
 CONSTRAINT [PK_DimUser] PRIMARY KEY CLUSTERED 
(
	[UserKey] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

INSERT INTO [dbo].[DimUser]
           ([UserName]
           ,[FirstName]
           ,[LastName]
           ,[SSN]
           ,[Password]
           ,[CreditCardNum]
           ,[CreditCardType]
           ,[EmailAddr]
		   ,[UserType])
VALUES
           ('Jeremiah42'
		   ,'Jeremiah'
		   ,'Jacks'
		   ,'253-95-2291'
		   ,'password42'
		   ,'1028391050382567'
		   ,'Discover'
		   ,'jeremiah42@gmail.com'
		   ,'User'),

           ('KevinM'
		   ,'Kevin'
		   ,'Mitnick'
		   ,'301-57-8921'
		   ,'password21'
		   ,'94838274001283492'
		   ,'Visa'
		   ,'kevinm@gmail.com'
		   ,'User');
