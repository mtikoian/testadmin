-----------------------------------------------------------------------------------
-- == CHECK FOR ATTACKS == 
-----------------------------------------------------------------------------------

-- check running queries and see if anything looks suspicious
sp_who2
-- dbcc inputbuffer(55)
-- kill 53


-- check for queries running. sort by cpu time
SELECT session_id, db_name(database_id) as db_name, user_name(user_id) as user_name, start_time, command, status, cpu_time, total_elapsed_time, reads, writes, text as query
FROM sys.dm_exec_requests a
OUTER APPLY sys.dm_exec_sql_text(a.sql_handle) b
WHERE session_id > 50 -- filter out background tasks
and session_id <> @@spid -- filter out this query session
order by cpu_time desc


-- check for signatures on recently completed queries
SELECT TOP 50 * 
FROM (SELECT ProcName = COALESCE(OBJECT_NAME(s2.objectid),'Ad-Hoc')
	,execution_count
	,total_elapsed_time
--	,s2.objectid
	,sql_statement = (SELECT TOP 1 SUBSTRING(s2.TEXT,statement_start_offset / 2+1 ,( (CASE WHEN statement_end_offset = -1 THEN (LEN(CONVERT(NVARCHAR(MAX),s2.TEXT)) * 2) ELSE statement_end_offset END)- statement_start_offset) / 2+1))
	,last_execution_time
	FROM sys.dm_exec_query_stats AS s1
	CROSS APPLY sys.dm_exec_sql_text(sql_handle) AS s2 
) as x
where sql_statement like '%1=1%'
--ORDER BY last_execution_time DESC
ORDER BY execution_count DESC

