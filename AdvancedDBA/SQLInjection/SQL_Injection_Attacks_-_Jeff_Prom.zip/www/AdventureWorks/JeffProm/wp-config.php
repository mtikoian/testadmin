<?php
/**
 * The base configurations of the WordPress.
 *
 * This file has the following configurations: MySQL settings, Table Prefix,
 * Secret Keys, WordPress Language, and ABSPATH. You can find more information
 * by visiting {@link http://codex.wordpress.org/Editing_wp-config.php Editing
 * wp-config.php} Codex page. You can get the MySQL settings from your web host.
 *
 * This file is used by the wp-config.php creation script during the
 * installation. You don't have to use the web site, you can just copy this file
 * to "wp-config.php" and fill in the values.
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'WordPress');

/** MySQL database username */
define('DB_USER', 'WordPressAdmin');

/** MySQL database password */
define('DB_PASSWORD', 'Summer2014!');

/** MySQL hostname */
define('DB_HOST', '.\sql2012');

/** Database Type. Defaults to mysql */
define('DB_TYPE', 'sqlsrv');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '*l>9/.kN0z5]#io =%X!g:G}d5O;m`>-4<KUJ(/u/UY}A|BD$db|^#3cVGa@TG!`');
define('SECURE_AUTH_KEY',  ']H/cHKL(JtEOh(M|6+p0o1DT=4rL9}Ul.||}=CI+Y/fr[2$vB4 =^o-|~blb8<&o');
define('LOGGED_IN_KEY',    '#E%,aAZ07uh9-U6XQ-}=`0XH,bnjl*B$+r>e{y{y}C_)*}~B6f+D<{Eke,01KfEm');
define('NONCE_KEY',        '}X]G7[A^x#0c0{UZHkhg>H!<*J7Q6(wS|Y)-nV2>#uKM9(H`%y<*(0J%L=>Z9nif');
define('AUTH_SALT',        'k Fd`cVO^ss?6gFa74$=~N_YiZ_?JHK.$x>k[NlahinD6hRyxk?ADp}r~^QR`T`j');
define('SECURE_AUTH_SALT', '5u!?0/`~vQXE/;vl#X-^ p6sOZ2jZk@-a{ut[TwcK(NNST@Zn@4f8NM`FNAmkOwc');
define('LOGGED_IN_SALT',   'SYQ,k6/6NL}eUDy(%[7>`E0i4|A3N@{!!u[m=#_O.2CN`!f><tr*Z@aQi/>0ULFy');
define('NONCE_SALT',       'r.}yO7DsB:0?lGAyhq+-Y4Y7)bS%y$wZfU03x[$i1*98.cu5**u#do6cYLf-DB8(');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each a unique
 * prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';


/** Query Logging Settings */
define('SAVEQUERIES', FALSE);
define('QUERY_LOG', 'C:\www\AdventureWorks\JeffProm/wp-content\queries.log');

/**
 * WordPress Localized Language, defaults to English.
 *
 * Change this to localize WordPress. A corresponding MO file for the chosen
 * language must be installed to wp-content/languages. For example, install
 * de_DE.mo to wp-content/languages and set WPLANG to 'de_DE' to enable German
 * language support.
 */
define('WPLANG', '');

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
