<?PHP
session_start();
require('../functions.php');
ini_set ('display_errors', $DebugMode);
include('../includes/styles.css');
require_once('../Connections/dbconnection.php');
header_start();

// Get varbinary value of a known 'unknown' image.
$tsql_NoImage = "SELECT LargePhoto FROM DimProduct WHERE ProductKey=1";
$stmt_NoImage = sqlsrv_query($conn, $tsql_NoImage);
$row_NoImage = sqlsrv_fetch_array($stmt_NoImage, SQLSRV_FETCH_ASSOC);

body();
echo "<div align='center'>";

menu_bar();
MainFrame_Top();
small_space();

//echo "<img src='/images/icons/application_view_list.png'> <font class='darkblue-15px'><b>Product List</b></font>";
//small_space();


if (isset($_GET['ID']) && (isset($_GET['Action']) == 'Delete') && isset($_SESSION['UserName'])){ // They want to delete a product

    $tsql_ProductName = sprintf("SELECT EnglishProductName FROM DimProduct WHERE ProductKey=%s", $_GET['ID']);
    $stmt_ProductName = sqlsrv_query($conn, $tsql_ProductName);
    $row_ProductName = sqlsrv_fetch_array($stmt_ProductName, SQLSRV_FETCH_ASSOC);
    if ($DebugMode==1){
        echo $tsql_ProductName;
    }
    
    $tsql_DeleteProduct = sprintf("DELETE FROM DimProduct WHERE ProductKey=%s", $_GET['ID']);
	$stmt_DeleteProduct = sqlsrv_query($conn, $tsql_DeleteProduct);
    if ($DebugMode==1){
        small_space();
		echo $tsql_DeleteProduct;
        small_space();
    }
        
    printf("<img src='../images/icons/tick.png' border='0'> <font class='darkgreen-13px'>Product '%s' Has Been Deleted</font><br>", $row_ProductName['EnglishProductName']);
	small_space();     
}


echo "<table border='1' bordercolor='#999999' cellspacing='0' cellpadding='2'>";
  echo "<tr bgcolor='#CCCCCC'>";
      echo "<td width='100'><font class='black-13px'><b>Code</b></font></td>";
      echo "<td width='225'><font class='black-13px'><b>Name</b></font></td>";
      echo "<td width='75'><font class='black-13px'><b>Color</b></font></td>";
      echo "<td width='75'><font class='black-13px'><b>List Price</b></font></td>";
      echo "<td width='200'><font class='black-13px'><b>Model Name</b></font></td>";
      echo "<td><font class='black-13px'><b>Finished?</b></font></td>";
      echo "<td><font class='black-13px'><b>Has Photo?</b></font></td>";
  echo "</tr>";

// test injection attacks
// http://localhost/htm/product-list.php?StatusFilter=' or 1=0 union select x=null,x=null,x=name,x=null,x=null,x=null,x=null,x=null,x=null,x=null from sys.databases --
if ($_GET['StatusFilter']){
	// UNSAFE
	$tsql_ProductList = sprintf("SELECT ProductKey, ProductAlternateKey, EnglishProductName, Color, ListPrice, DealerPrice, ModelName, LargePhoto, EnglishDescription, FinishedGoodsFlag
	FROM DimProduct WHERE status='%s' ORDER BY ProductAlternateKey", $_GET['StatusFilter']);
	$stmt_ProductList = sqlsrv_query($conn, $tsql_ProductList, array(), array("Scrollable" => SQLSRV_CURSOR_KEYSET)); 
	$row_ProductListCount = sqlsrv_num_rows($stmt_ProductList);
	

	// SAFE
	/*
	$tsql_ProductList = "SELECT ProductKey, ProductAlternateKey, EnglishProductName, Color, ListPrice, DealerPrice, ModelName, LargePhoto, EnglishDescription, FinishedGoodsFlag
	FROM DimProduct WHERE status=? ORDER BY ProductAlternateKey";
	$params_ProductList = array($_GET['StatusFilter']);
	$stmt_ProductList = sqlsrv_query($conn, $tsql_ProductList, $params_ProductList, array("Scrollable" => SQLSRV_CURSOR_KEYSET)); 
	$row_ProductListCount = sqlsrv_num_rows($stmt_ProductList);
	*/
} else {
	$tsql_ProductList = "SELECT ProductKey, ProductAlternateKey, EnglishProductName, Color
	, ListPrice, DealerPrice, ModelName, LargePhoto, EnglishDescription, FinishedGoodsFlag
	FROM DimProduct WHERE status='Current' ORDER BY ProductAlternateKey";
	// run the query and add an array so we can get a count later	
	$stmt_ProductList = sqlsrv_query($conn, $tsql_ProductList, array(), array("Scrollable" => SQLSRV_CURSOR_KEYSET)); 
	$row_ProductListCount = sqlsrv_num_rows($stmt_ProductList);
}

if ($DebugMode==1){
    echo $tsql_ProductList."<br><br>";
}

$rowColor=1; // <-- this line essentially 'declares' the variable and will get rid of the error
while($row_ProductList = sqlsrv_fetch_array($stmt_ProductList, SQLSRV_FETCH_ASSOC))
  {
    if($rowColor % 2){ 
	    echo "<tr bgcolor='#EEEEEE'>\n";
	}else{
	    echo "<tr bgcolor='#FFFFFF'>\n";
	}    
    
	    printf("<td><a href='product-details.php?ID=%s'><font class='darkblue-12px'>%s</font></a></td>\n", $row_ProductList['ProductKey'], $row_ProductList['ProductAlternateKey']);
	    printf("<td><font class='black-12px'>%s</font></td>\n", $row_ProductList['EnglishProductName']);
	    printf("<td><font class='black-12px'>%s</font></td>\n", $row_ProductList['Color']);
	    printf("<td><font class='black-12px'>%s</font></td>\n", ($row_ProductList['ListPrice'] ? '$'.number_format($row_ProductList['ListPrice'], 2) : '&nbsp;'));
	    printf("<td><font class='black-12px'>%s</font></td>\n", ($row_ProductList['ModelName'] ? $row_ProductList['ModelName'] : '&nbsp;'));
	    printf("<td><font class='black-12px'><div align='center'>%s</center></font></td>\n", ($row_ProductList['FinishedGoodsFlag'] == 1 ? "<img src='../images/icons/tick.png' title='Yes'>" : "<img src='../images/icons/cross.png' title='No'>"));
	    printf("<td><font class='black-12px'><div align='center'>%s</center></font></td>\n", ($row_ProductList['LargePhoto'] <> $row_NoImage['LargePhoto'] && $row_ProductList['LargePhoto'] ? "<img src='../images/icons/tick.png' title='Yes'>" : "<img src='../images/icons/cross.png' title='No'>"));
    echo "</tr>\n";
    $rowColor++;
  }
echo "</table>";  
small_space();


printf ("<font class='darkgrey-13px'>%s Products Found</font>", number_format($row_ProductListCount, 0));
small_space();

if (isset($_SESSION['UserName'])){
	echo "<img src='/images/icons/cog_add.png'> <a href='product-add.php'><font class='darkblue-13px'>Add New Product</font></a>";
	small_space();
}

MainFrame_Bottom();
footer();

echo "</div>";
 
echo "</body>";
echo "</html>";
?>