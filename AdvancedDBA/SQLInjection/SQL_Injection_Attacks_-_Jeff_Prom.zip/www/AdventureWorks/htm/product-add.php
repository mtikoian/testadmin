<?PHP
session_start();
require('../functions.php');
ini_set ('display_errors', $DebugMode);
include('../includes/styles.css');
require_once('../Connections/dbconnection.php');
header_start();

body();
echo "<div align='center'>";



menu_bar();
MainFrame_Top();
small_space();

echo "<img src='/images/icons/cog_add.png'> <font class='darkblue-15px'><b>Add A New Product</b></font>";
small_space();



if (isset($_POST['Submit'])){

    // check required fields
    if ($_POST['EnglishProductName']){ // looks good. proceed

        // They are updating data. Write it to the db.
        if ($_POST['Submit']){
            $tsql_InsertProduct = sprintf("INSERT INTO DimProduct 
                (ProductAlternateKey
                , EnglishProductName
                , Color
                , ListPrice
                , ModelName
                , FinishedGoodsFlag 
        
                , WeightUnitMeasureCode
                , SizeUnitMeasureCode
                , StandardCost
                , SafetyStockLevel
                , ReorderPoint
                , Size
                
                , SizeRange
                , Weight
                , DaysToManufacture
                , ProductLine
                , DealerPrice
                , Class
                , Style
                
                , StartDate
                , Status)
                
                VALUES
                (%s, '%s', '%s', %s, %s, %s
                
                , %s, %s, %s, %s, %s, %s
                
                , %s, %s, %s, %s, %s, %s, %s
                
                , getdate(), 'Current')"
                
                , ($_POST['ProductAlternateKey'] ? "'".$_POST['ProductAlternateKey']."'" : 'NULL')
                , $_POST['EnglishProductName']
                , $_POST['Color']
                , ($_POST['ListPrice'] ? $_POST['ListPrice'] : 'NULL')
                , ($_POST['ModelName'] ? "'".$_POST['ModelName']."'" : 'NULL')
		        , ($_POST['FinishedGoodsFlag'] == 'on' ? '1' : '0')
                 
                , ($_POST['WeightUnitMeasureCode'] ? "'".$_POST['WeightUnitMeasureCode']."'" : 'NULL')
                , ($_POST['SizeUnitMeasureCode'] ? "'".$_POST['SizeUnitMeasureCode']."'" : 'NULL')
                , ($_POST['StandardCost'] ? $_POST['StandardCost'] : 'NULL')
                , ($_POST['SafetyStockLevel'] ? $_POST['SafetyStockLevel'] : 'NULL')
                , ($_POST['ReorderPoint'] ? $_POST['ReorderPoint'] : 'NULL')
                , ($_POST['Size'] ? "'".$_POST['Size']."'" : 'NULL')
                
                , ($_POST['SizeRange'] ? "'".$_POST['SizeRange']."'" : 'NULL')
                , ($_POST['Weight'] ? $_POST['Weight'] : 'NULL')
                , $_POST['DaysToManufacture']
                , ($_POST['ProductLine'] ? "'".$_POST['ProductLine']."'" : 'NULL')
                , ($_POST['DealerPrice'] ? $_POST['DealerPrice'] : 'NULL')
                , ($_POST['Class'] ? "'".$_POST['Class']."'" : 'NULL')
                , ($_POST['Style'] ? "'".$_POST['Style']."'" : 'NULL'));
	        $stmt_InsertProduct = sqlsrv_query($conn, $tsql_InsertProduct);
                if ($DebugMode==1){
                    small_space();
		            echo $tsql_InsertProduct;
                    small_space();
                }            
        }

	    printf("<img src='../images/icons/tick.png' border='0'> <font class='darkgreen-13px'>Product '%s' Added</font><br>", $_POST['EnglishProductName']);
	    small_space();
        
        
    } else { // required field missing
    
        echo "<img src='../images/icons/cross.png' border='0'> <font class='darkred-13px'>Please Enter a Product Name</font><br>";
	    small_space();
    
    }

}


if ($_SESSION['UserName']){ // user is logged in. let them add info

    // Show a form to insert info.
    echo "<form method='post' name='insert-product' style='margin-bottom:5;margin-top:5;'>";
    echo "<table border='1' bordercolor='#999999' bgcolor='#EEEEEE' cellspacing='0' cellpadding='2' width='475'>";
        echo "<tr><td><font class='black-13px'><b>Code:</b></font></td><td><input name='ProductAlternateKey' type='text' size='40'></td></tr>";
        echo "<tr><td><font class='black-13px'><b>Name:</b></font></td><td><input name='EnglishProductName' type='text' size='40'> *</td></tr>";

        echo "<tr><td><font class='black-13px'><b>Color:</b></font></td>";
        echo "<td>";
            echo "<SELECT id='Color' NAME='Color'>";
            $tsql_ColorList = "SELECT distinct Color FROM DimProduct ORDER BY Color";
            $stmt_ColorList = sqlsrv_query($conn, $tsql_ColorList);
            while($row_ColorList = sqlsrv_fetch_array($stmt_ColorList, SQLSRV_FETCH_ASSOC))
            {
	            printf("<Option value='%s'>%s</option>", $row_ColorList['Color'], $row_ColorList['Color']);
            }
            echo "</SELECT>";
        echo "</td></tr>";
    
        echo "<tr><td><font class='black-13px'><b>List Price:</b></font></td><td><input name='ListPrice' type='text' size='15'></td></tr>";
        echo "<tr><td><font class='black-13px'><b>Model Name:</b></font></td><td><input name='ModelName' type='text' size='40'></td></tr>";
	    echo "<tr>";
	        echo "<td><font class='black-13px'><b>Finished Goods:</b></font></td>";
		    echo "<td><INPUT TYPE=CHECKBOX NAME='FinishedGoodsFlag'></td>";
        echo "</tr>";  

        echo "<tr><td><font class='black-13px'><b>Weight Unit Measure Code:</b></font></td><td><input name='WeightUnitMeasureCode' type='text' size='15'></td></tr>";
        echo "<tr><td><font class='black-13px'><b>Size Unit Measure Code</b></font></td><td><input name='SizeUnitMeasureCode' type='text' size='15'></td></tr>";
        echo "<tr><td><font class='black-13px'><b>Standard Cost:</b></font></td><td><input name='StandardCost' type='text' size='15'></td></tr>";
        echo "<tr><td><font class='black-13px'><b>Safety Stock Level:</b></font></td><td><input name='SafetyStockLevel' type='text' size='15'></td></tr>";
        echo "<tr><td><font class='black-13px'><b>Reorder Point:</b></font></td><td><input name='ReorderPoint' type='text' size='15'></td></tr>";
        echo "<tr><td><font class='black-13px'><b>Size:</b></font></td><td><input name='Size' type='text' size='15'></td></tr>";

        echo "<tr><td><font class='black-13px'><b>Size Range:</b></font></td>";
        echo "<td>";
            echo "<SELECT id='SizeRange' NAME='SizeRange'>";
            $tsql_SizeRangeList = "SELECT distinct SizeRange FROM DimProduct ORDER BY SizeRange";
            $stmt_SizeRangeList = sqlsrv_query($conn, $tsql_SizeRangeList);
            while($row_SizeRangeList = sqlsrv_fetch_array($stmt_SizeRangeList, SQLSRV_FETCH_ASSOC))
            {
	            printf("<Option value='%s'>%s</option>", $row_SizeRangeList['SizeRange'], $row_SizeRangeList['SizeRange']);
            }
            echo "</SELECT>";
        echo "</td></tr>";
    
        echo "<tr><td><font class='black-13px'><b>Weight:</b></font></td><td><input name='Weight' type='text' size='15'></td></tr>";

        echo "<tr><td><font class='black-13px'><b>Days To Manufacture:</b></font></td>";
        echo "<td>";
            echo "<SELECT id='DaysToManufacture' NAME='DaysToManufacture'>";
            $DaysToManufactureCounter=0;
            $Max_DaysToManufactureCounter=20;
	        while ($DaysToManufactureCounter <= $Max_DaysToManufactureCounter){
		        printf("<Option value='%s'>%s</option>", $DaysToManufactureCounter, $DaysToManufactureCounter);
		        $DaysToManufactureCounter++;
	        }       
            echo "</SELECT>";
        echo "</td></tr>";
        
        echo "<tr><td><font class='black-13px'><b>Product Line:</b></font></td><td><input name='ProductLine' type='text' size='15'></td></tr>";
        echo "<tr><td><font class='black-13px'><b>Dealer Price:</b></font></td><td><input name='DealerPrice' type='text' size='15'></td></tr>";
        echo "<tr><td><font class='black-13px'><b>Class:</b></font></td><td><input name='Class' type='text' size='15'></td></tr>";
        echo "<tr><td><font class='black-13px'><b>Style:</b></font></td><td><input name='Style' type='text' size='15'></td></tr>";    
    
    echo "</table>";

    small_space();
    echo "<input type='submit' name='Submit' value='Submit'>";
    echo "</form>";
   
    small_space();
    echo "<font class='darkgrey-12px'>* Required Field</font>";
    
} else { // user is not logged in. 

	echo "<img src='../images/icons/stop.png' border='0'> <font class='black-13px'>You need to be logged in to add a new product.</font><br>";
	small_space();


} // check if user is logged in or not

small_space();

MainFrame_Bottom();
footer();

echo "</div>";
 
echo "</body>";
echo "</html>";
?>