<?PHP
session_start();
require('../functions.php');
ini_set ('display_errors', $DebugMode);
include('../includes/styles.css');
require_once('../Connections/dbconnection.php');
header_start();

// Set ProductKey value
$ProductKey = (isset($_POST['ID']) ? $_POST['ID'] : $_GET['ID']);

body();
echo "<div align='center'>";


// They are updating data. Write it to the db.
if (isset($_POST['Submit'])){
    $tsql_UpdateProduct = sprintf("UPDATE DimProduct SET EnglishProductName='%s'
        , Color='%s'
        , ListPrice=%s
        , ModelName=%s
        , FinishedGoodsFlag=%s 
        
        , WeightUnitMeasureCode=%s
        , SizeUnitMeasureCode=%s
        , StandardCost=%s
        , SafetyStockLevel=%s
        , ReorderPoint=%s
        , Size=%s
        , SizeRange=%s
        , Weight=%s
        , DaysToManufacture=%s
        , ProductLine=%s
        , DealerPrice=%s
        , Class=%s
        , Style=%s        
    
        WHERE ProductKey=%s"
        , $_POST['EnglishProductName']
        , $_POST['Color']
        , ($_POST['ListPrice'] ? $_POST['ListPrice'] : 'NULL')
        , ($_POST['ModelName'] ? "'".$_POST['ModelName']."'" : 'NULL')
		, ($_POST['FinishedGoodsFlag'] == 'on' ? '1' : '0')
                 
        , ($_POST['WeightUnitMeasureCode'] ? "'".$_POST['WeightUnitMeasureCode']."'" : 'NULL')
        , ($_POST['SizeUnitMeasureCode'] ? "'".$_POST['SizeUnitMeasureCode']."'" : 'NULL')
        , ($_POST['StandardCost'] ? $_POST['StandardCost'] : 'NULL')
        , ($_POST['SafetyStockLevel'] ? $_POST['SafetyStockLevel'] : 'NULL')
        , ($_POST['ReorderPoint'] ? $_POST['ReorderPoint'] : 'NULL')
        , ($_POST['Size'] ? "'".$_POST['Size']."'" : 'NULL')
        , ($_POST['SizeRange'] ? "'".$_POST['SizeRange']."'" : 'NULL')
        , ($_POST['Weight'] ? $_POST['Weight'] : 'NULL')
        , ($_POST['DaysToManufacture'] ? $_POST['DaysToManufacture'] : 'NULL')
        , ($_POST['ProductLine'] ? "'".$_POST['ProductLine']."'" : 'NULL')
        , ($_POST['DealerPrice'] ? $_POST['DealerPrice'] : 'NULL')
        , ($_POST['Class'] ? "'".$_POST['Class']."'" : 'NULL')
        , ($_POST['Style'] ? "'".$_POST['Style']."'" : 'NULL')
        
	, $_GET['ID']);
	$stmt_UpdateProduct = sqlsrv_query($conn, $tsql_UpdateProduct);
        if ($DebugMode==1){
            small_space();
		    echo $tsql_UpdateProduct;
            small_space();
        }            
}

/*
// check if the product exists
$tsql_CheckProduct = sprintf("select count(*) as RecordCount from DimProduct WHERE ProductKey=%s", $ProductKey);
$stmt_CheckProduct = sqlsrv_query($conn, $tsql_CheckProduct);
$row_CheckProduct = sqlsrv_fetch_array($stmt_CheckProduct, SQLSRV_FETCH_ASSOC);
if ($row_CheckProduct['RecordCount'] == 0){
	exit;
}
*/



// == UNSAFE METHOD ==
// Get data values from the db.
$tsql_ProductList = sprintf("SELECT ProductAlternateKey
	,EnglishProductName
	,Color
	,ListPrice
	,ModelName
	,FinishedGoodsFlag
	,WeightUnitMeasureCode
	,SizeUnitMeasureCode
	,StandardCost
	,SafetyStockLevel
	,ReorderPoint
	,Size
	,SizeRange
	,Weight
	,DaysToManufacture
	,ProductLine
	,DealerPrice
	,Class
	,Style 
	,LargePhoto FROM DimProduct WHERE ProductKey=%s", $ProductKey);
$stmt_ProductList = sqlsrv_query($conn, $tsql_ProductList);
$row_ProductList = sqlsrv_fetch_array($stmt_ProductList, SQLSRV_FETCH_ASSOC);


/*
// == SAFE METHOD ==
$tsql_ProductList = "SELECT ProductAlternateKey
	,EnglishProductName
	,Color
	,ListPrice
	,ModelName
	,FinishedGoodsFlag
	,WeightUnitMeasureCode
	,SizeUnitMeasureCode
	,StandardCost
	,SafetyStockLevel
	,ReorderPoint
	,Size
	,SizeRange
	,Weight
	,DaysToManufacture
	,ProductLine
	,DealerPrice
	,Class
	,Style 
	,LargePhoto FROM DimProduct WHERE ProductKey=?";
$params_ProductList = array($ProductKey);
$stmt_ProductList = sqlsrv_query($conn, $tsql_ProductList, $params_ProductList);
$row_ProductList = sqlsrv_fetch_array($stmt_ProductList, SQLSRV_FETCH_ASSOC);
*/



if ($DebugMode==1){
    small_space();
    echo $tsql_ProductList;
    small_space();
}

menu_bar();
MainFrame_Top();
small_space();

echo "<img src='/images/icons/cog.png'> <font class='darkblue-15px'><b>Product Details</b></font>";
small_space();

printf("<font class='black-16px'><b>%s</b></font>", $row_ProductList['EnglishProductName']);
small_space();

if ($row_ProductList['LargePhoto']){
    // Show photos that are in the database.
    $mime = "image/jpeg";
    $b64Src = "data:".$mime.";base64," . base64_encode($row_ProductList['LargePhoto']);
    printf("<img src='%s' border='1' style='border-color:#CCCCCC'>\n", $b64Src);
    small_space();
}

if (isset($_POST['Submit'])){
	echo "<img src='../images/icons/tick.png' border='0'> <font class='darkgreen-13px'>Product Updated</font><br>";
	small_space();

}


if (isset($_SESSION['UserName'])){ // user is logged in. let them update info
	
    // Show a form to update info.
    echo "<form method='post' name='update-product' style='margin-bottom:5;margin-top:5;'>";
    echo "<table border='1' bordercolor='#999999' bgcolor='#EEEEEE' cellspacing='0' cellpadding='2' width='475'>\n";
        printf("<tr><td><font class='black-13px'><b>Code:</b></font></td><td><font class='black-13px'>%s</font></td></tr>\n", $row_ProductList['ProductAlternateKey']);
        printf("<tr><td><font class='black-13px'><b>Name:</b></font></td><td><input name='EnglishProductName' type='text' size='40' value='%s'></td></tr>\n", $row_ProductList['EnglishProductName']);

        echo "<tr><td><font class='black-13px'><b>Color:</b></font></td>";
        echo "<td>";
            echo "<SELECT id='Color' NAME='Color'>";
            $tsql_ColorList = "SELECT distinct Color FROM DimProduct ORDER BY Color";
            $stmt_ColorList = sqlsrv_query($conn, $tsql_ColorList);
            while($row_ColorList = sqlsrv_fetch_array($stmt_ColorList, SQLSRV_FETCH_ASSOC))
            {
	            printf("<Option value='%s' %s>%s</option>", $row_ColorList['Color'], ($row_ProductList['Color'] == $row_ColorList['Color'] ? 'selected' : ''), $row_ColorList['Color']);
            }
            echo "</SELECT>";
        echo "</td></tr>\n";
    
        printf("<tr><td><font class='black-13px'><b>List Price:</b></font></td><td><input name='ListPrice' type='text' size='15' value='%s'></td></tr>\n", $row_ProductList['ListPrice']);
        printf("<tr><td><font class='black-13px'><b>Model Name:</b></font></td><td><input name='ModelName' type='text' size='40' value='%s'></td></tr>\n", $row_ProductList['ModelName']);
	    echo "<tr>";
	        echo "<td><font class='black-13px'><b>Finished Goods:</b></font></td>";
		    printf("<td><INPUT TYPE=CHECKBOX NAME='FinishedGoodsFlag' %s></td>", ($row_ProductList['FinishedGoodsFlag'] == 1 ? 'checked' : ''));
        echo "</tr>";  

        printf("<tr><td><font class='black-13px'><b>Weight Unit Measure Code:</b></font></td><td><input name='WeightUnitMeasureCode' type='text' size='15' value='%s'></td></tr>\n", $row_ProductList['WeightUnitMeasureCode']);
        printf("<tr><td><font class='black-13px'><b>Size Unit Measure Code</b></font></td><td><input name='SizeUnitMeasureCode' type='text' size='15' value='%s'></td></tr>\n", $row_ProductList['SizeUnitMeasureCode']);
        printf("<tr><td><font class='black-13px'><b>Standard Cost:</b></font></td><td><input name='StandardCost' type='text' size='15' value='%s'></td></tr>\n", $row_ProductList['StandardCost']);
        printf("<tr><td><font class='black-13px'><b>Safety Stock Level:</b></font></td><td><input name='SafetyStockLevel' type='text' size='15' value='%s'></td></tr>\n", $row_ProductList['SafetyStockLevel']);
        printf("<tr><td><font class='black-13px'><b>Reorder Point:</b></font></td><td><input name='ReorderPoint' type='text' size='15' value='%s'></td></tr>\n", $row_ProductList['ReorderPoint']);
        printf("<tr><td><font class='black-13px'><b>Size:</b></font></td><td><input name='Size' type='text' size='15' value='%s'></td></tr>\n", $row_ProductList['Size']);

        echo "<tr><td><font class='black-13px'><b>Size Range:</b></font></td>";
        echo "<td>";
            echo "<SELECT id='SizeRange' NAME='SizeRange'>";
            $tsql_SizeRangeList = "SELECT distinct SizeRange FROM DimProduct ORDER BY SizeRange";
            $stmt_SizeRangeList = sqlsrv_query($conn, $tsql_SizeRangeList);
            while($row_SizeRangeList = sqlsrv_fetch_array($stmt_SizeRangeList, SQLSRV_FETCH_ASSOC))
            {
	            printf("<Option value='%s' %s>%s</option>", $row_SizeRangeList['SizeRange'], ($row_SizeRangeList['SizeRange'] == $row_ProductList['SizeRange'] ? 'selected' : ''), $row_SizeRangeList['SizeRange']);
            }
            echo "</SELECT>";
        echo "</td></tr>\n";
    
        printf("<tr><td><font class='black-13px'><b>Weight:</b></font></td><td><input name='Weight' type='text' size='15' value='%s'></td></tr>", $row_ProductList['Weight']);

        echo "<tr><td><font class='black-13px'><b>Days To Manufacture:</b></font></td>";
        echo "<td>";
            echo "<SELECT id='DaysToManufacture' NAME='DaysToManufacture'>";
            $DaysToManufactureCounter=0;
            $Max_DaysToManufactureCounter=20;
	        while ($DaysToManufactureCounter <= $Max_DaysToManufactureCounter){
		        printf("<Option value='%s' %s>%s</option>", $DaysToManufactureCounter, ($DaysToManufactureCounter == $row_ProductList['DaysToManufacture'] ? 'selected' : ''), $DaysToManufactureCounter);
		        $DaysToManufactureCounter++;
	        }       
            echo "</SELECT>";
        echo "</td></tr>";
        
        printf("<tr><td><font class='black-13px'><b>Product Line:</b></font></td><td><input name='ProductLine' type='text' size='15' value='%s'></td></tr>\n", $row_ProductList['ProductLine']);
    
        printf("<tr><td><font class='black-13px'><b>Dealer Price:</b></font></td><td><input name='DealerPrice' type='text' size='15' value='%s'></td></tr>\n", $row_ProductList['DealerPrice']);
        printf("<tr><td><font class='black-13px'><b>Class:</b></font></td><td><input name='Class' type='text' size='15' value='%s'></td></tr>\n", $row_ProductList['Class']);
        printf("<tr><td><font class='black-13px'><b>Style:</b></font></td><td><input name='Style' type='text' size='15' value='%s'></td></tr>\n", $row_ProductList['Style']);    
    
    echo "</table>";

    printf("<input type='hidden' name='ID' value='%s'>", $_GET['ID']);
    small_space();
    echo "<input type='submit' name='Submit' value='Submit'>";
    echo "</form>";
    
    small_space();
    printf("<img src='/images/icons/cog_delete.png'> <a href='product-list.php?ID=%s&Action=Delete'><font class='darkblue-13px'>Delete This Product</font></a>", $_GET['ID']);
    small_space();
    
    
} else { // user is not logged in. show info but don't let them edit

    // Show info.
    echo "<table border='1' bordercolor='#999999' bgcolor='#EEEEEE' cellspacing='0' cellpadding='2' width='475'>\n";
        printf("<tr><td><font class='black-13px'><b>Code:</b></font></td><td><font class='black-13px'>%s</font></td></tr>\n", $row_ProductList['ProductAlternateKey']);
        printf("<tr><td><font class='black-13px'><b>Name:</b></font></td><td><font class='black-13px'>%s</font></td></tr>\n", $row_ProductList['EnglishProductName']);
        printf("<tr><td><font class='black-13px'><b>Color:</b></font></td><td><font class='black-13px'>%s</font></td></tr>\n", $row_ProductList['Color']);
        printf("<tr><td><font class='black-13px'><b>List Price:</b></font></td><td><font class='black-13px'>%s</font></td></tr>\n", $row_ProductList['ListPrice']);
        printf("<tr><td><font class='black-13px'><b>Model Name:</b></font></td><td><font class='black-13px'>%s</font></td></tr>\n", $row_ProductList['ModelName']);
	    echo "<tr><td><font class='black-13px'><b>Finished Goods:</b></font></td>";
		    printf("<td><font class='black-13px'>%s</font></td>", ($row_ProductList['FinishedGoodsFlag'] == 1 ? 'Yes' : 'No'));
        echo "</tr>\n";  
        printf("<tr><td><font class='black-13px'><b>Weight Unit Measure Code:</b></font></td><td><font class='black-13px'>%s</font></td></tr>\n", $row_ProductList['WeightUnitMeasureCode']);
        printf("<tr><td><font class='black-13px'><b>Size Unit Measure Code</b></font></td><td><font class='black-13px'>%s</font></td></tr>\n", $row_ProductList['SizeUnitMeasureCode']);
        printf("<tr><td><font class='black-13px'><b>Standard Cost:</b></font></td><td><font class='black-13px'>%s</font></td></tr>\n", $row_ProductList['StandardCost']);
        printf("<tr><td><font class='black-13px'><b>Safety Stock Level:</b></font></td><td><font class='black-13px'>%s</font></td></tr>\n", $row_ProductList['SafetyStockLevel']);
        printf("<tr><td><font class='black-13px'><b>Reorder Point:</b></font></td><td><font class='black-13px'>%s</font></td></tr>\n", $row_ProductList['ReorderPoint']);
        printf("<tr><td><font class='black-13px'><b>Size:</b></font></td><td><font class='black-13px'>%s</font></td></tr>\n", $row_ProductList['Size']);
        printf("<tr><td><font class='black-13px'><b>Size Range:</b></font></td><td><font class='black-13px'>%s</font></td></tr>\n", $row_ProductList['SizeRange']);  
        printf("<tr><td><font class='black-13px'><b>Weight:</b></font></td><td><font class='black-13px'>%s</font></td></tr>\n", $row_ProductList['Weight']);
        printf("<tr><td><font class='black-13px'><b>Days To Manufacture:</b></font></td><td><font class='black-13px'>%s</font></td></tr>\n", $row_ProductList['DaysToManufacture']);
        printf("<tr><td><font class='black-13px'><b>Product Line:</b></font></td><td><font class='black-13px'>%s</font></td></tr>\n", $row_ProductList['ProductLine']);
        printf("<tr><td><font class='black-13px'><b>Dealer Price:</b></font></td><td><font class='black-13px'>%s</font></td></tr>\n", $row_ProductList['DealerPrice']);
        printf("<tr><td><font class='black-13px'><b>Class:</b></font></td><td><font class='black-13px'>%s</font></td></tr>\n", $row_ProductList['Class']);
        printf("<tr><td><font class='black-13px'><b>Style:</b></font></td><td><font class='black-13px'>%s</font></td></tr>\n", $row_ProductList['Style']);
    echo "</table>\n";

} // check if user is logged in or not

small_space();

MainFrame_Bottom();
footer();

echo "</div>";
 
echo "</body>";
echo "</html>";
?>