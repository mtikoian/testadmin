<?PHP
// --------------------------------------------------------------------------------------------------
// === AdventureWorks Online ===
//
// Created by Jeff Prom on 8/29/2013
// http://jeffprom.com
//
// This demo site uses PHP, IIS, and SQL Server with the AdventureWorksDW database. 
// It was created to show how PHP can use SQL Server to create database driven websites.
// --------------------------------------------------------------------------------------------------

session_start();
require('functions.php');
ini_set ('display_errors', $DebugMode);
include('includes/styles.css');
require_once('Connections/dbconnection.php');
header_start();

body2();

echo "<div align='center'>";

show_logo();
echo "<br>";

small_space();
small_space();
small_space();

echo "<a href='htm/product-list.php'><img src='images/product-list-icon.png' border='0'></a>";
small_space();
small_space();

// Logout. Unregister session variables
if (isset($_POST['Logout'])){
	unset($_SESSION['UserID']);
	unset($_SESSION['UserName']);
}


if ($DebugMode == 1){
    echo "<img src='/images/icons/error.png'> Debug Mode = On";
    small_space();
    echo "SessionID = ".session_id();
    small_space();
	if(isset($_SESSION['UserID'])){
		echo "UserID (Session) = ".$_SESSION['UserID'];
		echo "<br>";
	}
	if(isset($_SESSION['UserName'])){
		echo "UserName (Session) = ".$_SESSION['UserName'];
		small_space();
	}
	
	if (isset($_POST['Login'])){
		echo "Username (Post) = ".$_POST['username'];
        small_space();
		echo "Password (Post) = ".$_POST['password'];
        small_space();
	}
}


// Begin ------------------- Login / Logout ------------------------

$tsql_GetUser = sprintf("SELECT * from DimUser where UserName='%s'", $_GET['username']);
$stmt_GetUser = sqlsrv_query($conn, $tsql_GetDate);
$row_GetDate = sqlsrv_fetch_array($stmt_GetDate, SQLSRV_FETCH_ASSOC);

echo $tsql_GetUser;
/*
// Hard coded values for demo purposes. Change this to pull values from your user/pwd table.
$username = 'demo';
$userid = 1;
$password = 'password';
$ErrorCount = 0; // use this to track and show error messages

// Login. Register session variables
if (isset($_POST['Login'])){
    if ($_POST['username'] == $username && $_POST['password'] == $password){ // check if the submitted username and pwd match a known value.
        $_SESSION['UserID'] = $userid;
        $_SESSION['UserName'] = $username;
    } else { // didn't match. show an error message
        $ErrorCount = 1;
    }
}
*/

// get the current server date
$tsql_GetDate = "SELECT getdate() as ServerDate";
$stmt_GetDate = sqlsrv_query($conn, $tsql_GetDate);
$row_GetDate = sqlsrv_fetch_array($stmt_GetDate, SQLSRV_FETCH_ASSOC);

echo "<table border='1' bordercolor='#999999' cellspacing='0' cellpadding='2' width='300'>";
  echo "<tr bgcolor='#CCCCCC'>";
  echo "<td>";

  if ($ErrorCount > 0){ // there was an error. show a message.
        small_space();
        echo "<div align='center'><img src='/images/icons/cross.png'> <font class='red-13px'>Incorrect Username or Password.<br>Please try again.</font></div>";    
        small_space();  
  }
  
if (isset($_SESSION['UserName'])){ // user is logged in
    printf("<div align='center'><img src='/images/icons/lock_open.png'> <font class='darkblue-13px'><b>You are logged in as '%s'</b></font></div>", $_SESSION['UserName']);

	// provide form to log out 
	small_space();
	echo "<form method='POST' style='margin-bottom:5;margin-top:5;'>";
	echo "<div align='center'><input type='submit' name='Logout' value='Logout'></div>";
	echo "</form>";
} else { // show login form
    echo "<div align='center'><img src='/images/icons/lock.png'> <font class='darkblue-13px'><b>You are not logged in.</b></font></div>";
	small_space();
	echo "<form method='POST' style='margin-bottom:5;margin-top:5;'>";
	      echo "<table width='300' border='0' cellspacing='0' cellpadding='2'>";
	        echo "<tr>";
				echo "<td><div align='right'><font class='black-14px'>Username: </font></div></td>";
				echo "<td><div align='center'><input name='username' type='text' size='30'></div></td>";
			echo "</tr>";
			echo "<tr>";
				echo "<td><div align='right'><font class='black-14px'>Password: </font></div></td>";
				echo "<td><div align='center'><input name='password' type='password' size='30'></div></td>";
			echo "</tr>";
			echo "<tr>";
				echo "<td colspan='2'><div align='center'><input type='submit' name='Login' value='Login'></div></td>";
			echo "</tr>";
	      echo "</table>";	
	echo "</form>";
}

printf("<div align='center'><font class='black-13px'>Server Date: %s</font></div>", date_format($row_GetDate['ServerDate'], 'm/d/Y g:i:s A'));

echo "</td>";
echo "</tr>";
echo "</table>";  
// End ------------------- Login / Logout ------------------------

footer();

echo "</div>";  
echo "</body>";
echo "</html>";
?>

