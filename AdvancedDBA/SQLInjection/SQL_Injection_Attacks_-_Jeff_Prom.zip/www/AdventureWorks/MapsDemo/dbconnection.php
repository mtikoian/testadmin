<?PHP
/*Connect to the local server using Windows Authentication and specify
the AdventureWorks database as the database in use. To connect using
SQL Server Authentication, set values for the "UID" and "PWD"
 attributes in the $connectionInfo parameter. For example:
$connectionInfo = array("UID" => $uid, "PWD" => $pwd)); */

// sql server php driver
// http://www.microsoft.com/download/en/details.aspx?displaylang=en&id=20098

//$serverName = "(local)";
$serverName = "reports.silverbaymgmt.com";
//$serverName = "(local)\MSSQLSERVER";

$uid = "jprom";
$pwd = "!j70-p04*";
$connectionInfo = array( "Database"=>"DataMart", "UID" => $uid, "PWD" => $pwd);
$conn = sqlsrv_connect( $serverName, $connectionInfo);

// ------------------------------------------------------------
// Use this section to test if the connection is working.
// ------------------------------------------------------------
if ($DebugMode == 1){
    if( $conn )
    {
         echo "Connection established.\n";
    }
    else
    {
         echo "Connection could not be established.\n";
         die( print_r( sqlsrv_errors(), true));
    }
}
?>