<?PHP
ini_set ('display_errors', '1');
session_start();
require('../functions.php');
//include('../includes/styles.css');
require_once('dbconnection.php');

?>

<!DOCTYPE html>
<html>
  <head>
    <title>Silver Bay</title>
    <meta name="viewport" content="initial-scale=1.0, user-scalable=no">
    <meta charset="utf-8">
    <style>
      html, body, #map-canvas {
        height: 100%;
        margin: 0px;
        padding: 0px
      }
    </style>
    <script src="https://maps.googleapis.com/maps/api/js?v=3.exp&sensor=false"></script>
    <script>
var map;
function initialize() {
  var mapOptions = {
    
	 <?PHP
	 // -- Location Check ---------------------------------------------------------------------------------------------------------------------
	 if (isset($_GET['loc'])=='PHX') {
	    echo "zoom: 8,";
	    echo "center: new google.maps.LatLng(33.436530, -112.007269)";
	 } elseif (isset($_GET['loc'])=='ATL'){
	    echo "zoom: 8,";
	    echo "center: new google.maps.LatLng(33.748994, -84.387983)";
	 } else {
	    echo "zoom: 4,";
	    echo "center: new google.maps.LatLng(36.909644, -99.598577)";
	 } // end location check
	 ?>      
    
  };
  var map = new google.maps.Map(document.getElementById("map-canvas"), mapOptions);
 
 <?PHP
 // -- PHOENIX ---------------------------------------------------------------------------------------------------------------------
 if (isset($_GET['loc'])=='PHX') { 
 ?>  
	  var Coords_8342 = new google.maps.LatLng(33.489711,-112.335316);	
	  var String_8342 = '<div id="content">'+
	      '<h2 id="firstHeading" class="firstHeading">12814 W Clarendon Ave<br>Avondale, AZ 85392</h2>'+
	      '<div id="bodyContent">'+
	      '<p><b>Property Identifier: 8342</b><br>' +
	      'Year Built: 2001<br>'+
	      'Purchase Price: $155,080<br>'+
	      'Square Feet: 2,012<br>'+
	      'Stabilized: Yes<br>'+
	      'Rented: Yes<br>'+
	      '<img src="8342.jpg"><br>'+
	      '<a href="details.php">View Details >></a></p>'
	      '</div>'+
	      '</div>';
	  var InfoWindow_8342 = new google.maps.InfoWindow({ content: String_8342 });   
	  var Marker_8342 = new google.maps.Marker({
	      position: Coords_8342,
	      map: map,
	      title: '12814 W Clarendon Ave, Avondale, AZ 85392'
	  });
	  google.maps.event.addListener(Marker_8342, 'click', function() { InfoWindow_8342.open(map, Marker_8342); }); 
	
	  
	  var Coords_8344 = new google.maps.LatLng(33.429633,-112.202672);	
	  var String_8344 = '<div id="content">'+
	      '<h2 id="firstHeading" class="firstHeading">6616 W Gross Ave<br>Phoenix, AZ 85043</h2>'+
	      '<div id="bodyContent">'+
	      '<p><b>Property Identifier: 8344</b><br>' +
	      'Year Built: 2004<br>'+
	      'Purchase Price: $111,408<br>'+
	      'Square Feet: 2,049<br>'+
	      'Stabilized: Yes<br>'+
	      'Rented: Yes<br>'+
	      '<img src="8344.jpg"><br>'+
	      '<a href="details.php">View Details >></a></p>'
	      '</div>'+
	      '</div>';
	  var InfoWindow_8344 = new google.maps.InfoWindow({ content: String_8344 });   
	  var Marker_8344 = new google.maps.Marker({
	      position: Coords_8344,
	      map: map,
	      title: '6616 W Gross Ave, Phoenix, AZ 85043'
	  });
	  google.maps.event.addListener(Marker_8344, 'click', function() { InfoWindow_8344.open(map, Marker_8344); });   
	  
	  
	  var Coords_8345 = new google.maps.LatLng(33.7574,-112.335158);	
	  var String_8345 = '<div id="content">'+
	      '<h2 id="firstHeading" class="firstHeading">12738 W Desert Mirage Dr.<br>Peoria, AZ 85383</h2>'+
	      '<div id="bodyContent">'+
	      '<p><b>Property Identifier: 8344</b><br>' +
	      'Year Built: 2004<br>'+
	      'Purchase Price: $166,555<br>'+
	      'Square Feet: 1,814<br>'+
	      'Stabilized: Yes<br>'+
	      'Rented: No<br>'+
	      '<img src="8345.jpg"><br>'+
	      '<a href="details.php">View Details >></a></p>'
	      '</div>'+
	      '</div>';
	  var InfoWindow_8345 = new google.maps.InfoWindow({ content: String_8345 });   
	  var Marker_8345 = new google.maps.Marker({
	      position: Coords_8345,
	      map: map,
	      title: '12738 W Desert Mirage Dr., Peoria, AZ 85383'
	  });
	  google.maps.event.addListener(Marker_8345, 'click', function() { InfoWindow_8345.open(map, Marker_8345); });    
  <?PHP
 } // end PHX section ----------------------------------------------------------------------------------------------------------------
 ?>
  
  
 <?PHP
 // -- ATLANTA -----------------------------------------------------------------------------------------------------------------------
 if (isset($_GET['loc'])=='ATL') { 
 ?> 
	  var Coords_ATL322P = new google.maps.LatLng(33.900216, -84.619305);	
	  var String_ATL322P = '<div id="content">'+
	      '<h2 id="firstHeading" class="firstHeading">2211 Caneridge Court<br> Marietta, GA 30064</h2>'+
	      '<div id="bodyContent">'+
	      '<p><b>Property Identifier: ATL322P</b><br>' +
	      'Year Built: 1999<br>'+
	      'Purchase Price: $133,304<br>'+
	      'Square Feet: 2,556<br>'+
	      'Stabilized: Yes<br>'+
	      'Rented: Yes<br>'+
	      '<img src="ATL322P.jpg"><br>'+
	      '<a href="details.php">View Details >></a></p>'
	      '</div>'+
	      '</div>';
	  var InfoWindow_ATL322P = new google.maps.InfoWindow({ content: String_ATL322P });   
	  var Marker_ATL322P = new google.maps.Marker({
	      position: Coords_ATL322P,
	      map: map,
	      title: '2211 Caneridge Court, Marietta, GA 30064'
	  });
	  google.maps.event.addListener(Marker_ATL322P, 'click', function() { InfoWindow_ATL322P.open(map, Marker_ATL322P); });
	  
	  var Coords_ATL323P = new google.maps.LatLng(34.071336, -84.599991);	
	  var String_ATL323P = '<div id="content">'+
	      '<h2 id="firstHeading" class="firstHeading">4959 Niagara Dr<br>Acworth, GA 30102</h2>'+
	      '<div id="bodyContent">'+
	      '<p><b>Property Identifier: ATL323P</b><br>' +
	      'Year Built: 1999<br>'+
	      'Purchase Price: $150,688<br>'+
	      'Square Feet: 2,282<br>'+
	      'Stabilized: Yes<br>'+
	      'Rented: No<br>'+
	      '<img src="ATL322P.jpg"><br>'+
	      '<a href="details.php">View Details >></a></p>'
	      '</div>'+
	      '</div>';
	  var InfoWindow_ATL323P = new google.maps.InfoWindow({ content: String_ATL323P });   
	  var Marker_ATL323P = new google.maps.Marker({
	      position: Coords_ATL323P,
	      map: map,
	      title: '4959 Niagara Dr, Acworth, GA 30102'
	  });
	  google.maps.event.addListener(Marker_ATL323P, 'click', function() { InfoWindow_ATL323P.open(map, Marker_ATL323P); });  
	  
	  var Coords_ATL299P = new google.maps.LatLng(33.815630, -84.714533);	
	  var String_ATL299P = '<div id="content">'+
	      '<h2 id="firstHeading" class="firstHeading">5325 Rolling Meadow Dr<br>Powder Springs, GA 30127</h2>'+
	      '<div id="bodyContent">'+
	      '<p><b>Property Identifier: ATL299P</b><br>' +
	      'Year Built: 2003<br>'+
	      'Purchase Price: $114,772<br>'+
	      'Square Feet: 2,835<br>'+
	      'Stabilized: Yes<br>'+
	      'Rented: Yes<br>'+
	      '<img src="ATL299P.jpg"><br>'+
	      '<a href="details.php">View Details >></a></p>'
	      '</div>'+
	      '</div>';
	  var InfoWindow_ATL299P = new google.maps.InfoWindow({ content: String_ATL299P });   
	  var Marker_ATL299P = new google.maps.Marker({
	      position: Coords_ATL299P,
	      map: map,
	      title: '5325 Rolling Meadow Dr, Powder Springs, GA 30127'
	  });
	  google.maps.event.addListener(Marker_ATL299P, 'click', function() { InfoWindow_ATL299P.open(map, Marker_ATL299P); });  
	  
  <?PHP
 } // end ATL section ----------------------------------------------------------------------------------------------------------------
 ?>
 
 
<?PHP
 // -- DEFAULT -----------------------------------------------------------------------------------------------------------------------
 if (isset($_GET['loc'])!='ATL') { 
?>
	  var Coords_ATL299P = new google.maps.LatLng(33.815630, -84.714533);	
	  var String_ATL299P = '<div id="content">'+
	      '<h2 id="firstHeading" class="firstHeading">5325 Rolling Meadow Dr<br>Powder Springs, GA 30127</h2>'+
	      '<div id="bodyContent">'+
	      '<p><b>Property Identifier: ATL299P</b><br>' +
	      'Year Built: 2003<br>'+
	      'Purchase Price: $114,772<br>'+
	      'Square Feet: 2,835<br>'+
	      'Stabilized: Yes<br>'+
	      'Rented: Yes<br>'+
	      '<img src="ATL299P.jpg"><br>'+
	      '<a href="details.php">View Details >></a></p>'
	      '</div>'+
	      '</div>';
	  var InfoWindow_ATL299P = new google.maps.InfoWindow({ content: String_ATL299P });   
	  var Marker_ATL299P = new google.maps.Marker({
	      position: Coords_ATL299P,
	      map: map,
	      title: '5325 Rolling Meadow Dr, Powder Springs, GA 30127'
	  });
	  google.maps.event.addListener(Marker_ATL299P, 'click', function() { InfoWindow_ATL299P.open(map, Marker_ATL299P); });   	 
<?PHP 	 
 	 
 } // end DEFAULT section ----------------------------------------------------------------------------------------------------------------
 	 
 ?> 
 
 
  
 }
  
  
}
google.maps.event.addDomListener(window, 'load', initialize);

    </script>
  </head>
  <body>
  	<img src='SilverBay.png' border='0'> 
  	Select a Market: <a href='index4.php?loc=PHX'>Phoenix</a> - <a href='index4.php?loc=TUC'>Tucson</a> - <a href='index4.php?loc=ATL'>Atlanta</a> - <a href='index4.php?loc=SFL'>Southeast Florida</a> - <a href='index4.php?loc=LAS'>Las Vegas</a>
    <div id="map-canvas"></div>
  </body>
</html>


