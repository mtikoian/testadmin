<?PHP
ini_set ('display_errors', '1');
session_start();
require('../functions.php');
include('../includes/styles.css');
require_once('dbconnection.php');

/*
Challenges:
images

- check box options -
weather
MTM
stabilized
leased
has pool
duplex
rehab complete

*/
?>

<!DOCTYPE html>
<html>
  <head>
    <title>Silver Bay</title>
    <meta name="viewport" content="initial-scale=1.0, user-scalable=no">
    <meta charset="utf-8">
    <style>
      html, body, #map-canvas {
        height: 100%;
        margin: 0px;
        padding: 0px
      }
    </style>
    <script src="https://maps.googleapis.com/maps/api/js?v=3.exp&sensor=false"></script>
    <script>
var map;
function initialize() {
  var mapOptions = {
	 <?PHP
	 // -- Location Check ---------------------------------------------------------------------------------------------------------------------
	 // 1 = Far Away
	 // 10 = Close Up
	 if ($_GET['loc']=='ATL'){
	    echo "zoom: 8,";
	    echo "center: new google.maps.LatLng(33.748994, -84.387983)"; // Atlanta
	 } elseif ($_GET['loc']=='CHA') {
	    echo "zoom: 10,";
	    echo "center: new google.maps.LatLng(35.227086, -80.843127)"; // Charlotte
	 } elseif ($_GET['loc']=='COH'){
	    echo "zoom: 10,";
	    echo "center: new google.maps.LatLng(39.938894, -83.079086)"; // Columbus
	 } elseif ($_GET['loc']=='DAL') {
	    echo "zoom: 9,";
	    echo "center: new google.maps.LatLng(32.780138, -96.80045)"; // Dallas
	 } elseif ($_GET['loc']=='HOU') {
	    echo "zoom: 10,";
	    echo "center: new google.maps.LatLng(29.760191, -95.369394)"; // Houston
	 } elseif ($_GET['loc']=='JAX') {
	    echo "zoom: 10,";
	    echo "center: new google.maps.LatLng(30.208879, -81.640193)"; // Jacksonville
	 } elseif ($_GET['loc']=='LAS') {
	    echo "zoom: 11,";
	    echo "center: new google.maps.LatLng(36.134554, -115.169523)"; // Las Vegas
	 } elseif ($_GET['loc']=='NCA') {
	    echo "zoom: 9,";
	    echo "center: new google.maps.LatLng(37.941365, -122.068250)"; // Northern CA
	 } elseif ($_GET['loc']=='FLO') {
	    echo "zoom: 9,";
	    echo "center: new google.maps.LatLng(28.538336, -81.379236)"; // Orlando
	 } elseif ($_GET['loc']=='PHX') {
	    echo "zoom: 9,";
	    echo "center: new google.maps.LatLng(33.436530, -112.007269)"; // Phoenix
	 } elseif ($_GET['loc']=='SFL') {
	    echo "zoom: 8,";
	    echo "center: new google.maps.LatLng(25.788969, -80.226438)"; // Southeast Florida
	 } elseif ($_GET['loc']=='SCA') { 
	    echo "zoom: 9,";
	    echo "center: new google.maps.LatLng(33.978692, -117.322511)"; // Southern CA
	 } elseif ($_GET['loc']=='FLT') { 
	    echo "zoom: 9,";
	    echo "center: new google.maps.LatLng(27.697836, -82.478009)"; // Tampa
	 } elseif ($_GET['loc']=='TUC') { 
	    echo "zoom: 10,";
	    echo "center: new google.maps.LatLng(32.199788, -110.938230)"; // Tucson
	 } else {
	    echo "zoom: 4,";
	    echo "center: new google.maps.LatLng(36.909644, -99.598577)"; // All/None
	 } // end location check
	 ?> 
  };
  var map = new google.maps.Map(document.getElementById("map-canvas"), mapOptions);
  

 <?PHP
 // -- begin market section --------------------------------------------------------------------------------------------------------------
 if ($_GET['loc'] <> 'None') {

 	 if ($_GET['loc'] == 'All'){
		$tsql_PropertyList = "select pdf.PropertyIdentifier
			,m.MarketName
			,m.MarketCode
			,HasPool = case when pdf.HasPool=1 then 'Yes' else 'No' end
			,pdf.LotSize
			,IsDuplex = case when pdf.IsDuplex=1 then 'Yes' else 'No' end
			,pdf.LatitudeDecimal
			,pdf.LongitudeDecimal
			,Stabilized = case when pdf.Stabilized_Operations=1 then 'Yes' else 'No' end
			from rpt.PropertyDrawFact as pdf
			inner join (select * from rpt.PropertyFact where PeriodID=16) as pf
				on pf.PropertyIdentifier=pdf.PropertyIdentifier
			inner join (select * from rpt.MarketDim) as m
				on m.MarketID=pf.MarketID
			where 
			pdf.LatitudeDecimal is not null and pdf.LongitudeDecimal is not null";
 	 } else {
		$tsql_PropertyList = sprintf("select pdf.PropertyIdentifier
			,m.MarketName
			,m.MarketCode
			,HasPool = case when pdf.HasPool=1 then 'Yes' else 'No' end
			,pdf.LotSize
			,IsDuplex = case when pdf.IsDuplex=1 then 'Yes' else 'No' end
			,pdf.LatitudeDecimal
			,pdf.LongitudeDecimal
			,Stabilized = case when pdf.Stabilized_Operations=1 then 'Yes' else 'No' end
			from rpt.PropertyDrawFact as pdf
			inner join (select * from rpt.PropertyFact where PeriodID=16) as pf
				on pf.PropertyIdentifier=pdf.PropertyIdentifier
			inner join (select * from rpt.MarketDim) as m
				on m.MarketID=pf.MarketID
			where 
			pdf.LatitudeDecimal is not null and pdf.LongitudeDecimal is not null
			and m.MarketCode='%s'", $_GET['loc']);
 	 }
	$stmt_PropertyList = sqlsrv_query($conn, $tsql_PropertyList);
	while($row_PropertyList = sqlsrv_fetch_array($stmt_PropertyList, SQLSRV_FETCH_ASSOC))
	{
		//printf("ID: %s, Lat: %f Lon: %f", $row_PropertyList['PropertyIdentifier'], $row_PropertyList['LatitudeDecimal'], $row_PropertyList['LongitudeDecimal']);
		printf("var Coords_%s = new google.maps.LatLng(%f,%f);"
			, str_replace('-', '', $row_PropertyList['PropertyIdentifier'])
			, $row_PropertyList['LatitudeDecimal'], $row_PropertyList['LongitudeDecimal']);
		// https://developers.google.com/maps/documentation/streetview/index
		// heading indicates the compass heading of the camera. Accepted values are from 0 to 360 (both values indicating North, with 90 indicating East, and 180 South). If no heading is specified, a value will be calculated that directs the camera towards the specified location, from the point at which the closest photograph was taken.
		// fov (default is 90) determines the horizontal field of view of the image. The field of view is expressed in degrees, with a maximum allowed value of 120. When dealing with a fixed-size viewport, as with a Street View image of a set size, field of view in essence represents zoom, with smaller numbers indicating a higher level of zoom.
		// pitch (default is 0) specifies the up or down angle of the camera relative to the Street View vehicle. This is often, but not always, flat horizontal. Positive values angle the camera up (with 90 degrees indicating straight up); negative values angle the camera down (with -90 indicating straight down).
		printf("var String_%s = '<font class=\"darkblue-14px\"><b>%s</b></font><br><img src=\"http://maps.googleapis.com/maps/api/streetview?size=200x200&location=%f,%f&heading=235&sensor=false\">';"
			, str_replace('-', '', $row_PropertyList['PropertyIdentifier'])
			, $row_PropertyList['PropertyIdentifier']
			, $row_PropertyList['LatitudeDecimal'], $row_PropertyList['LongitudeDecimal']);
		//<img src="http://maps.googleapis.com/maps/api/streetview?size=200x200&location=40.720032,-73.988354&heading=235&sensor=false">
		//printf("var String_%s = '<font class=\"darkblue-14px\"><b>%s</b></font><br>--------------<img src='http://maps.googleapis.com/maps/api/staticmap?center=%f,%f&zoom=11&size=200x200&sensor=false'>';"
		//	, str_replace('-', '', $row_PropertyList['PropertyIdentifier'])
		//	, $row_PropertyList['PropertyIdentifier']
		//	, $row_PropertyList['LatitudeDecimal'], $row_PropertyList['LongitudeDecimal']);
		printf("var InfoWindow_%s = new google.maps.InfoWindow({ content: String_%s });"
			, str_replace('-', '', $row_PropertyList['PropertyIdentifier'])
			, str_replace('-', '', $row_PropertyList['PropertyIdentifier']));   
		printf("var Marker_%s = new google.maps.Marker({", str_replace('-', '', $row_PropertyList['PropertyIdentifier']));
		printf("  position: Coords_%s,", str_replace('-', '', $row_PropertyList['PropertyIdentifier']));
		echo   "  map: map,";
		printf("title: '%s'", $row_PropertyList['PropertyIdentifier']);
	  	echo   "});";
	  	printf("google.maps.event.addListener(Marker_%s, 'click', function() { InfoWindow_%s.open(map, Marker_%s); });"
	  		, str_replace('-', '', $row_PropertyList['PropertyIdentifier'])
	  		, str_replace('-', '', $row_PropertyList['PropertyIdentifier'])
	  		, str_replace('-', '', $row_PropertyList['PropertyIdentifier']));
	}
 } // end market section ----------------------------------------------------------------------------------------------------------------
 
 /*
 -- sample
 	  var Coords_ATL322P = new google.maps.LatLng(33.900216, -84.619305);	
	  var String_ATL322P = '<font class="darkblue-14px"><b>2211 Caneridge Court<br> Marietta, GA 30064</b></font><br>'+
	      '<font class="black-11px"><b>Property Identifier: ATL322P</b></font><br><br>' +
	      '<font class="black-11px">Year Built: 1999</font><br>'+
	      '<font class="black-11px">Purchase Price: $133,304</font><br>'+
	      '<font class="black-11px">Square Feet: 2,556</font><br>'+
	      '<font class="black-11px">Stabilized: Yes</font><br>'+
	      '<font class="black-11px">Rented: Yes</font><br><br>'+
	      '<img src="ATL322P.jpg"><br><br>'+
	      '<a href="details.php"><font class="darkblue-11px">View Details >></font></a>';
	  var InfoWindow_ATL322P = new google.maps.InfoWindow({ content: String_ATL322P });   
	  var Marker_ATL322P = new google.maps.Marker({
	      position: Coords_ATL322P,
	      map: map,
	      title: '2211 Caneridge Court, Marietta, GA 30064'
	  });
	  google.maps.event.addListener(Marker_ATL322P, 'click', function() { InfoWindow_ATL322P.open(map, Marker_ATL322P); });
 */
 
echo "}";
echo "google.maps.event.addDomListener(window, 'load', initialize);";

echo "</script>";
echo "</head>";
echo "<body>";
echo "&nbsp;<a href='index.php?loc=None'><img src='SilverBay.png' border='0'></a>"; 
echo "&nbsp;&nbsp;<font class='black-14px'><b>Select a Market:</b></font> ";

// All
$tsql_AllCount = "SELECT count(*) as RecordCount
  FROM rpt.PropertyMarketPeriod
  where PeriodID=16";
$stmt_AllCount = sqlsrv_query($conn, $tsql_AllCount);
while($row_AllCount = sqlsrv_fetch_array($stmt_AllCount, SQLSRV_FETCH_ASSOC))
printf("<a href='index.php?loc=All'><font class='darkblue-12px'>All</font></a> <font class='darkgrey-11px'>(%s)&nbsp;&nbsp;-</font>", number_format($row_AllCount['RecordCount'],0));

// Market List
$tsql_Market = "SELECT p.MarketName, m.MarketCode
  ,count(*) as RecordCount
  FROM rpt.PropertyMarketPeriod as p
  inner join rpt.MarketDim as m on m.MarketName=p.MarketName
  where p.PeriodID=16
  group by p.MarketName, m.MarketCode
  order by p.MarketName";
$stmt_Market = sqlsrv_query($conn, $tsql_Market);
while($row_Market = sqlsrv_fetch_array($stmt_Market, SQLSRV_FETCH_ASSOC))
{
	if ($row_Market['MarketCode'] == 'JAX'){
		echo "<br>";
	}
	if ($row_Market['MarketCode'] == 'HOU' or $row_Market['MarketCode'] == 'TUC'){
		printf("&nbsp;<a href='index.php?loc=%s'><font class='darkblue-12px'>%s</font></a> <font class='darkgrey-11px'>(%s)</font>", $row_Market['MarketCode'], $row_Market['MarketName'], number_format($row_Market['RecordCount'], 0));
	} else {
		printf("&nbsp;<a href='index.php?loc=%s'><font class='darkblue-12px'>%s</font></a> <font class='darkgrey-11px'>(%s)&nbsp;&nbsp;-</font>", $row_Market['MarketCode'], $row_Market['MarketName'], number_format($row_Market['RecordCount'], 0));
	}
}


	//testing
	/*
	echo "<br>";
	$tsql_PropertyList = sprintf("select pdf.PropertyIdentifier
		,m.MarketName
		,m.MarketCode
		,HasPool = case when pdf.HasPool=1 then 'Yes' else 'No' end
		,pdf.LotSize
		,IsDuplex = case when pdf.IsDuplex=1 then 'Yes' else 'No' end
		,pdf.LatitudeDecimal
		,pdf.LongitudeDecimal
		,Stabilized = case when pdf.Stabilized_Operations=1 then 'Yes' else 'No' end
		from rpt.PropertyDrawFact as pdf
		inner join (select * from rpt.PropertyFact where PeriodID=16) as pf
			on pf.PropertyIdentifier=pdf.PropertyIdentifier
		inner join (select * from rpt.MarketDim) as m
			on m.MarketID=pf.MarketID
		where 
		pdf.LatitudeDecimal is not null and pdf.LongitudeDecimal is not null
		and m.MarketCode='%s'
		and pdf.PropertyIdentifier='FLO123-2T'", $_GET['loc']);
	$stmt_PropertyList = sqlsrv_query($conn, $tsql_PropertyList);
	while($row_PropertyList = sqlsrv_fetch_array($stmt_PropertyList, SQLSRV_FETCH_ASSOC))
	{
		
		printf("ID: %s, Lat: %f Lon: %f<br>", str_replace('-', '', $row_PropertyList['PropertyIdentifier']), $row_PropertyList['LatitudeDecimal'], $row_PropertyList['LongitudeDecimal']);
	}
	*/

    echo "<div id='map-canvas'></div>";
  echo "</body>";
echo "</html>";
?> 	
  	

