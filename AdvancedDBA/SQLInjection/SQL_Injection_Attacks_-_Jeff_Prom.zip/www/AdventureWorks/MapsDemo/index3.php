<?PHP
ini_set ('display_errors', '1');
session_start();
require('../functions.php');
//include('../includes/styles.css');
require_once('dbconnection.php');

?>

<!DOCTYPE html>
<html>
  <head>
    <title>Silver Bay</title>
    <meta name="viewport" content="initial-scale=1.0, user-scalable=no">
    <meta charset="utf-8">
    <style>
      html, body, #map-canvas {
        height: 100%;
        margin: 0px;
        padding: 0px
      }
    </style>
    <script src="https://maps.googleapis.com/maps/api/js?v=3.exp&sensor=false"></script>
    <script>
var map;
function initialize() {
  var mapOptions = {
    zoom: 8,
    center: new google.maps.LatLng(34.236388, -111.811825)
  };
  var map = new google.maps.Map(document.getElementById("map-canvas"), mapOptions);
  
  
  var Coords_8342 = new google.maps.LatLng(33.489711,-112.335316);	
  var String_8342 = '<div id="content">'+
      '<h2 id="firstHeading" class="firstHeading">12814 W Clarendon Ave<br>Avondale, AZ 85392</h2>'+
      '<div id="bodyContent">'+
      '<p><b>Property Identifier: 8342</b><br>' +
      'Year Built: 2001<br>'+
      'Purchase Price: $155,080<br>'+
      'Square Feet: 2,012<br>'+
      'Stabilized: Yes<br>'+
      'Rented: Yes<br>'+
      '<img src="8342.jpg"><br>'+
      '<a href="details.php">View Details >></a></p>'
      '</div>'+
      '</div>';
  var InfoWindow_8342 = new google.maps.InfoWindow({ content: String_8342 });   
  var Marker_8342 = new google.maps.Marker({
      position: Coords_8342,
      map: map,
      title: '12814 W Clarendon Ave, Avondale, AZ 85392'
  });
  google.maps.event.addListener(Marker_8342, 'click', function() { InfoWindow_8342.open(map, Marker_8342); }); 

  
  var Coords_8344 = new google.maps.LatLng(33.429633,-112.202672);	
  var String_8344 = '<div id="content">'+
      '<h2 id="firstHeading" class="firstHeading">6616 W Gross Ave<br>Phoenix, AZ 85043</h2>'+
      '<div id="bodyContent">'+
      '<p><b>Property Identifier: 8344</b><br>' +
      'Year Built: 2004<br>'+
      'Purchase Price: $111,408<br>'+
      'Square Feet: 2,049<br>'+
      'Stabilized: Yes<br>'+
      'Rented: Yes<br>'+
      '<img src="8344.jpg"><br>'+
      '<a href="details.php">View Details >></a></p>'
      '</div>'+
      '</div>';
  var InfoWindow_8344 = new google.maps.InfoWindow({ content: String_8344 });   
  var Marker_8344 = new google.maps.Marker({
      position: Coords_8344,
      map: map,
      title: '6616 W Gross Ave, Phoenix, AZ 85043'
  });
  google.maps.event.addListener(Marker_8344, 'click', function() { InfoWindow_8344.open(map, Marker_8344); });   
  
  
  var Coords_8345 = new google.maps.LatLng(33.7574,-112.335158);	
  var String_8345 = '<div id="content">'+
      '<h2 id="firstHeading" class="firstHeading">12738 W Desert Mirage Dr.<br>Peoria, AZ 85383</h2>'+
      '<div id="bodyContent">'+
      '<p><b>Property Identifier: 8344</b><br>' +
      'Year Built: 2004<br>'+
      'Purchase Price: $166,555<br>'+
      'Square Feet: 1,814<br>'+
      'Stabilized: Yes<br>'+
      'Rented: No<br>'+
      '<img src="8345.jpg"><br>'+
      '<a href="details.php">View Details >></a></p>'
      '</div>'+
      '</div>';
  var InfoWindow_8345 = new google.maps.InfoWindow({ content: String_8345 });   
  var Marker_8345 = new google.maps.Marker({
      position: Coords_8345,
      map: map,
      title: '12738 W Desert Mirage Dr., Peoria, AZ 85383'
  });
  google.maps.event.addListener(Marker_8345, 'click', function() { InfoWindow_8345.open(map, Marker_8345); });    
  
  
}
google.maps.event.addDomListener(window, 'load', initialize);

    </script>
  </head>
  <body>
    <div id="map-canvas"></div>
  </body>
</html>


