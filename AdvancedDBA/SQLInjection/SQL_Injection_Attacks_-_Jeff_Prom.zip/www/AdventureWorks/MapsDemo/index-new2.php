<?PHP
ini_set ('display_errors', '1');
session_start();
require('../functions.php');
include('../includes/styles.css');
require_once('dbconnection.php');

/*
Challenges:
images

- check box options -
weather
MTM
stabilized
leased
has pool
duplex
rehab complete

*/
?>

<!DOCTYPE html>
<html>
  <head>
    <title>Silver Bay</title>
    <meta name="viewport" content="initial-scale=1.0, user-scalable=no">
    <meta charset="utf-8">
    <style>
      html, body, #map-canvas {
        height: 100%;
        margin: 0px;
        padding: 0px
      }
    </style>
    <script src="https://maps.googleapis.com/maps/api/js?v=3.exp&sensor=false"></script>
    <script>
var map;
function initialize() {
  var mapOptions = {
	 <?PHP
	 // -- Location Check ---------------------------------------------------------------------------------------------------------------------
	 if ($_GET['loc']=='ATL'){ // Atlanta
	    echo "zoom: 9,";
	    echo "center: new google.maps.LatLng(33.748994, -84.387983)";
	 } elseif ($_GET['loc']=='CHA') { // Charlotte
	    echo "zoom: 9,";
	    echo "center: new google.maps.LatLng(35.227086, -80.843127)";
	 } elseif ($_GET['loc']=='COL'){ // Columbus
	    echo "zoom: 9,";
	    echo "center: new google.maps.LatLng(39.938894, -83.079086)";
	 } elseif ($_GET['loc']=='DAL') { // Dallas
	    echo "zoom: 9,";
	    echo "center: new google.maps.LatLng(32.780138, -96.80045)";
	 } elseif ($_GET['loc']=='HOU') { // Houston
	    echo "zoom: 9,";
	    echo "center: new google.maps.LatLng(29.760191, -95.369394)";
	 } elseif ($_GET['loc']=='JAX') { // Jacksonville
	    echo "zoom: 9,";
	    echo "center: new google.maps.LatLng(30.332183, -81.65565)";
	 } elseif ($_GET['loc']=='LAS') { // Las Vegas
	    echo "zoom: 9,";
	    echo "center: new google.maps.LatLng(36.255122, -115.238347)";
	 } elseif ($_GET['loc']=='NCA') { // Northern CA
	    echo "zoom: 9,";
	    echo "center: new google.maps.LatLng(37.774930, -122.419416)";
	 } elseif ($_GET['loc']=='FLO') { // Orlando
	    echo "zoom: 9,";
	    echo "center: new google.maps.LatLng(28.538336, -81.379236)";
	 } elseif ($_GET['loc']=='PHX') { // Phoenix
	    echo "zoom: 9,";
	    echo "center: new google.maps.LatLng(33.436530, -112.007269)";
	 } elseif ($_GET['loc']=='SFL') { // Southeast Florida
	    echo "zoom: 9,";
	    echo "center: new google.maps.LatLng(25.788969, -80.226438)";
	 } elseif ($_GET['loc']=='SCA') { // Southern CA
	    echo "zoom: 9,";
	    echo "center: new google.maps.LatLng(32.715327, -117.157255)";
	 } elseif ($_GET['loc']=='FLT') { // Tampa
	    echo "zoom: 9,";
	    echo "center: new google.maps.LatLng(82.450575, -82.457177)";
	 } elseif ($_GET['loc']=='TUC') { // Tucson
	    echo "zoom: 9,";
	    echo "center: new google.maps.LatLng(32.221741, -110.926477)";
	 } else {
	    echo "zoom: 4,";
	    echo "center: new google.maps.LatLng(36.909644, -99.598577)";
	 } // end location check
	 ?> 
  };
  var map = new google.maps.Map(document.getElementById("map-canvas"), mapOptions);
  

 <?PHP
 // -- begin market section --------------------------------------------------------------------------------------------------------------
 if ($_GET['loc'] <> 'ALL') {

	$tsql_PropertyList = sprintf("select pdf.PropertyIdentifier
		,m.MarketName
		,m.MarketCode
		,HasPool = case when pdf.HasPool=1 then 'Yes' else 'No' end
		,pdf.LotSize
		,IsDuplex = case when pdf.IsDuplex=1 then 'Yes' else 'No' end
		,pdf.LatitudeDecimal
		,pdf.LongitudeDecimal
		,Stabilized = case when pdf.Stabilized_Operations=1 then 'Yes' else 'No' end
		from rpt.PropertyDrawFact as pdf
		inner join (select * from rpt.PropertyFact where PeriodID=16) as pf
			on pf.PropertyIdentifier=pdf.PropertyIdentifier
		inner join (select * from rpt.MarketDim) as m
			on m.MarketID=pf.MarketID
		where 
		pdf.LatitudeDecimal is not null and pdf.LongitudeDecimal is not null
		and m.MarketCode='%s'", $_GET['loc']);
	$stmt_PropertyList = sqlsrv_query($conn, $tsql_PropertyList);
	while($row_PropertyList = sqlsrv_fetch_array($stmt_PropertyList, SQLSRV_FETCH_ASSOC))
	{
		printf("var Coords_%s = new google.maps.LatLng(%f,%f);", $row_PropertyList['PropertyIdentifier']
			, $row_PropertyList['LatitudeDecimal'], $row_PropertyList['LongitudeDecimal']);
		printf("var String_%s = '<font class=\"darkblue-14px\"><b>%s</b></font>';", $row_PropertyList['PropertyIdentifier']
			, $row_PropertyList['PropertyIdentifier']);
		printf("var InfoWindow_%s = new google.maps.InfoWindow({ content: String_%s });", $row_PropertyList['PropertyIdentifier']
			, $row_PropertyList['PropertyIdentifier']);   
		printf("var Marker_%s = new google.maps.Marker({", $row_PropertyList['PropertyIdentifier']);
		printf("  position: Coords_%s,", $row_PropertyList['PropertyIdentifier']);
		echo   "  map: map,";
		printf("title: '%s'", $row_PropertyList['PropertyIdentifier']);
	  	echo   "});";
	  	printf("google.maps.event.addListener(Marker_%s, 'click', function() { InfoWindow_%s.open(map, Marker_%s); });"
	  		, $row_PropertyList['PropertyIdentifier'], $row_PropertyList['PropertyIdentifier'], $row_PropertyList['PropertyIdentifier']); 
	}
	
 	 
 } // end market section ----------------------------------------------------------------------------------------------------------------
 
 /*
 -- sample
 	  var Coords_ATL322P = new google.maps.LatLng(33.900216, -84.619305);	
	  var String_ATL322P = '<font class="darkblue-14px"><b>2211 Caneridge Court<br> Marietta, GA 30064</b></font><br>'+
	      '<font class="black-11px"><b>Property Identifier: ATL322P</b></font><br><br>' +
	      '<font class="black-11px">Year Built: 1999</font><br>'+
	      '<font class="black-11px">Purchase Price: $133,304</font><br>'+
	      '<font class="black-11px">Square Feet: 2,556</font><br>'+
	      '<font class="black-11px">Stabilized: Yes</font><br>'+
	      '<font class="black-11px">Rented: Yes</font><br><br>'+
	      '<img src="ATL322P.jpg"><br><br>'+
	      '<a href="details.php"><font class="darkblue-11px">View Details >></font></a>';
	  var InfoWindow_ATL322P = new google.maps.InfoWindow({ content: String_ATL322P });   
	  var Marker_ATL322P = new google.maps.Marker({
	      position: Coords_ATL322P,
	      map: map,
	      title: '2211 Caneridge Court, Marietta, GA 30064'
	  });
	  google.maps.event.addListener(Marker_ATL322P, 'click', function() { InfoWindow_ATL322P.open(map, Marker_ATL322P); });
 */
 
 ?>

  
}
google.maps.event.addDomListener(window, 'load', initialize);

<?PHP

echo "</script>";
echo "</head>";
echo "<body>";
echo "&nbsp;<a href='index.php?loc=ALL'><img src='SilverBay.png' border='0'></a>"; 
echo "&nbsp;&nbsp;<font class='black-14px'><b>Select a Market:</b></font> "; 

$tsql_Market = "SELECT p.[MarketName], m.MarketCode
  ,count(*) as RecordCount
  FROM [DataMart].[rpt].[PropertyMarketPeriod] as p
  inner join rpt.MarketDim as m on m.MarketName=p.MarketName
  where p.PeriodID=16
  group by p.MarketName, m.MarketCode
  order by p.MarketName";
$stmt_Market = sqlsrv_query($conn, $tsql_Market);
while($row_Market = sqlsrv_fetch_array($stmt_Market, SQLSRV_FETCH_ASSOC))
{
	if ($row_Market['MarketCode'] == 'JAX'){
		echo "<br>";
	}
	if ($row_Market['MarketCode'] == 'HOU' or $row_Market['MarketCode'] == 'TUC'){
		printf("<a href='index.php?loc=%s'><font class='darkblue-12px'>%s</font></a> <font class='darkgrey-11px'>(%s)</font>", $row_Market['MarketCode'], $row_Market['MarketName'], number_format($row_Market['RecordCount'], 0));
	} else {
		printf("&nbsp;<a href='index.php?loc=%s'><font class='darkblue-12px'>%s</font></a> <font class='darkgrey-11px'>(%s) - </font>", $row_Market['MarketCode'], $row_Market['MarketName'], number_format($row_Market['RecordCount'], 0));
	}
} 	
?> 	
  	
    <div id="map-canvas"></div>
  </body>
</html>

