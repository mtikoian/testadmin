<?PHP
ini_set ('display_errors', '1');
session_start();
require('../functions.php');
//include('../includes/styles.css');
require_once('dbconnection.php');

// maps v3 link
// https://developers.google.com/maps/articles/v2tov3?utm_source=welovemapsdevelopers&utm_campaign=v2_deprecation_announcement_oct13

// v3 auth key: AIzaSyD1iuooDwTOpurkrVELqDHDMW81SKZ14NY

// map quota report
// https://code.google.com/apis/console/?noredirect&pli=1#project:485940583919:stats:maps_backend

// api's
// https://code.google.com/apis/console/?noredirect&pli=1#project:485940583919:services


?>

<!DOCTYPE html>
<html>
  <head>
    <title>Simple Map</title>
    <meta name="viewport" content="initial-scale=1.0, user-scalable=no">
    <meta charset="utf-8">
    <style>
      html, body, #map-canvas {
        height: 100%;
        margin: 0px;
        padding: 0px
      }
    </style>
    <script src="https://maps.googleapis.com/maps/api/js?v=3.exp&sensor=false"></script>
    <script>
var map;
function initialize() {
  var mapOptions = {
    zoom: 8,
    center: new google.maps.LatLng(34.236388, -111.811825)
  };
  map = new google.maps.Map(document.getElementById('map-canvas'), mapOptions);
  var showCSR = new google.maps.KmlLayer({ url: 'http://www.campsitereports.com/maps/US/US-AZ-SP.xml', map: map });
  
}

google.maps.event.addDomListener(window, 'load', initialize);

    </script>
  </head>
  <body>
    <div id="map-canvas"></div>
  </body>
</html>


