<?PHP
ini_set ('display_errors', '0');
session_start();
require('../functions.php');
include('../includes/styles.css');
require_once('dbconnection.php');

/*
Challenges:
converting addresses to lat/lng
images

Check Box Options:
MTM
Rented
Stabilized
Weather (on/off)



*/
?>

<!DOCTYPE html>
<html>
  <head>
    <title>Silver Bay</title>
    <meta name="viewport" content="initial-scale=1.0, user-scalable=no">
    <meta charset="utf-8">
    <style>
      html, body, #map-canvas {
        height: 100%;
        margin: 0px;
        padding: 0px
      }
    </style>
    <script src="https://maps.googleapis.com/maps/api/js?v=3.exp&sensor=false&libraries=weather"></script>
    <script>
var map;
function initialize() {
  var mapOptions = {
	 <?PHP
	 // -- Location Check ---------------------------------------------------------------------------------------------------------------------
	 if ($_GET['loc']=='PHX') {
	    echo "zoom: 9,";
	    echo "center: new google.maps.LatLng(33.436530, -112.007269)";
	 } elseif ($_GET['loc']=='ATL'){
	    echo "zoom: 9,";
	    echo "center: new google.maps.LatLng(33.748994, -84.387983)";
	 } else {
	    echo "zoom: 4,";
	    echo "center: new google.maps.LatLng(36.909644, -99.598577)";
	 } // end location check
	 ?> 
  };
  var map = new google.maps.Map(document.getElementById("map-canvas"), mapOptions);
	  
  var weatherLayer = new google.maps.weather.WeatherLayer({
    temperatureUnits: google.maps.weather.TemperatureUnit.FAHRENHEIT
  });
  weatherLayer.setMap(map);

  var cloudLayer = new google.maps.weather.CloudLayer();
  cloudLayer.setMap(map);
	  
 <?PHP
 // -- PHOENIX ---------------------------------------------------------------------------------------------------------------------
 if ($_GET['loc']=='PHX') { 
 ?>  
	  var Coords_8342 = new google.maps.LatLng(33.489711,-112.335316);	
	  var String_8342 = '<font class="darkblue-14px"><b>12814 W Clarendon Ave<br>Avondale, AZ 85392</b></font><br>'+
	      '<font class="black-11px"><b>Property Identifier: 8342</b></font><br><br>' +
	      '<font class="black-11px">Year Built: 2001</font><br>'+
	      '<font class="black-11px">Purchase Price: $155,080</font><br>'+
	      '<font class="black-11px">Square Feet: 2,012</font><br>'+
	      '<font class="black-11px">Stabilized: Yes</font><br>'+
	      '<font class="black-11px">Rented: Yes</font><br><br>'+
	      '<img src="8342.jpg"><br><br>'+
	      '<a href="details.php"><font class="darkblue-11px">View Details >></font></a>';
	  var InfoWindow_8342 = new google.maps.InfoWindow({ content: String_8342 });   
	  var Marker_8342 = new google.maps.Marker({
	      position: Coords_8342,
	      map: map,
	      title: '12814 W Clarendon Ave, Avondale, AZ 85392'
	  });
	  google.maps.event.addListener(Marker_8342, 'click', function() { InfoWindow_8342.open(map, Marker_8342); }); 
	
	  
	  var Coords_8344 = new google.maps.LatLng(33.429633,-112.202672);	
	  var String_8344 = '<font class="darkblue-14px"><b>6616 W Gross Ave<br>Phoenix, AZ 85043</b></font><br>'+
	      '<font class="black-11px"><b>Property Identifier: 8344</b></font><br><br>' +
	      '<font class="black-11px">Year Built: 2004</font><br>'+
	      '<font class="black-11px">Purchase Price: $111,408</font><br>'+
	      '<font class="black-11px">Square Feet: 2,049</font><br>'+
	      '<font class="black-11px">Stabilized: Yes</font><br>'+
	      '<font class="black-11px">Rented: Yes</font><br><br>'+
	      '<img src="8344.jpg"><br><br>'+
	      '<a href="details.php"><font class="darkblue-11px">View Details >></font></a>';
	  var InfoWindow_8344 = new google.maps.InfoWindow({ content: String_8344 });   
	  var Marker_8344 = new google.maps.Marker({
	      position: Coords_8344,
	      map: map,
	      title: '6616 W Gross Ave, Phoenix, AZ 85043'
	  });
	  google.maps.event.addListener(Marker_8344, 'click', function() { InfoWindow_8344.open(map, Marker_8344); });   
	  
	  
	  var Coords_8345 = new google.maps.LatLng(33.7574,-112.335158);	
	  var String_8345 = '<font class="darkblue-14px"><b>12738 W Desert Mirage Dr.<br>Peoria, AZ 85383</b></font><br>'+
	      '<font class="black-11px"><b>Property Identifier: 8344</b></font><br><br>' +
	      '<font class="black-11px">Year Built: 2004</font><br>'+
	      '<font class="black-11px">Purchase Price: $166,555</font><br>'+
	      '<font class="black-11px">Square Feet: 1,814</font><br>'+
	      '<font class="black-11px">Stabilized: Yes</font><br>'+
	      '<font class="black-11px">Rented: No</font><br><br>'+
	      '<img src="8345.jpg"><br><br>'+
	      '<a href="details.php"><font class="darkblue-11px">View Details >></font></a>';
	  var InfoWindow_8345 = new google.maps.InfoWindow({ content: String_8345 });   
	  var Marker_8345 = new google.maps.Marker({
	      position: Coords_8345,
	      map: map,
	      title: '12738 W Desert Mirage Dr., Peoria, AZ 85383'
	  });
	  google.maps.event.addListener(Marker_8345, 'click', function() { InfoWindow_8345.open(map, Marker_8345); });    
  <?PHP
 } // end PHX section ----------------------------------------------------------------------------------------------------------------
 ?>
 
 
 <?PHP
 // -- ATLANTA -----------------------------------------------------------------------------------------------------------------------
 //if (isset($_GET['loc'])=='ATL') { 
 if ($_GET['loc']=='ATL') { 
 ?> 
	  var Coords_ATL322P = new google.maps.LatLng(33.900216, -84.619305);	
	  var String_ATL322P = '<font class="darkblue-14px"><b>2211 Caneridge Court<br> Marietta, GA 30064</b></font><br>'+
	      '<font class="black-11px"><b>Property Identifier: ATL322P</b></font><br><br>' +
	      '<font class="black-11px">Year Built: 1999</font><br>'+
	      '<font class="black-11px">Purchase Price: $133,304</font><br>'+
	      '<font class="black-11px">Square Feet: 2,556</font><br>'+
	      '<font class="black-11px">Stabilized: Yes</font><br>'+
	      '<font class="black-11px">Rented: Yes</font><br><br>'+
	      '<img src="ATL322P.jpg"><br><br>'+
	      '<a href="details.php"><font class="darkblue-11px">View Details >></font></a>';
	  var InfoWindow_ATL322P = new google.maps.InfoWindow({ content: String_ATL322P });   
	  var Marker_ATL322P = new google.maps.Marker({
	      position: Coords_ATL322P,
	      map: map,
	      title: '2211 Caneridge Court, Marietta, GA 30064'
	  });
	  google.maps.event.addListener(Marker_ATL322P, 'click', function() { InfoWindow_ATL322P.open(map, Marker_ATL322P); });
	  
	  var Coords_ATL323P = new google.maps.LatLng(34.071336, -84.599991);	
	  var String_ATL323P = '<font class="darkblue-14px"><b>4959 Niagara Dr<br>Acworth, GA 30102</b></font><br>'+
	      '<font class="black-11px"><b>Property Identifier: ATL323P</b></font><br><br>' +
	      '<font class="black-11px">Year Built: 1999</font><br>'+
	      '<font class="black-11px">Purchase Price: $150,688</font><br>'+
	      '<font class="black-11px">Square Feet: 2,282</font><br>'+
	      '<font class="black-11px">Stabilized: Yes</font><br>'+
	      '<font class="black-11px">Rented: No</font><br><br>'+
	      '<img src="ATL323P.jpg"><br><br>'+
	      '<a href="details.php"><font class="darkblue-11px">View Details >></font></a>';
	  var InfoWindow_ATL323P = new google.maps.InfoWindow({ content: String_ATL323P });   
	  var Marker_ATL323P = new google.maps.Marker({
	      position: Coords_ATL323P,
	      map: map,
	      title: '4959 Niagara Dr, Acworth, GA 30102'
	  });
	  google.maps.event.addListener(Marker_ATL323P, 'click', function() { InfoWindow_ATL323P.open(map, Marker_ATL323P); });  
	  
	  var Coords_ATL299P = new google.maps.LatLng(33.815630, -84.714533);	
	  var String_ATL299P = ''+
	      '<font class="darkblue-14px"><b>5325 Rolling Meadow Dr<br>Powder Springs, GA 30127</b></font><br>'+
	      '<font class="black-11px"><b>Property Identifier: ATL299P</b></font><br><br>' +
	      '<font class="black-11px">Year Built: 2003</font><br>'+
	      '<font class="black-11px">Purchase Price: $114,772</font><br>'+
	      '<font class="black-11px">Square Feet: 2,835</font><br>'+
	      '<font class="black-11px">Stabilized: Yes</font><br>'+
	      '<font class="black-11px">Rented: Yes</font><br><br>'+
	      '<img src="ATL299P.jpg"><br><br>'+
	      '<a href="details.php"><font class="darkblue-11px">View Details >></font></a>';
	  var InfoWindow_ATL299P = new google.maps.InfoWindow({ content: String_ATL299P });   
	  var Marker_ATL299P = new google.maps.Marker({
	      position: Coords_ATL299P,
	      map: map,
	      title: '5325 Rolling Meadow Dr, Powder Springs, GA 30127'
	  });
	  google.maps.event.addListener(Marker_ATL299P, 'click', function() { InfoWindow_ATL299P.open(map, Marker_ATL299P); });  
	  
  <?PHP
 } // end ATL section ----------------------------------------------------------------------------------------------------------------
 
 ?>
  
}
google.maps.event.addDomListener(window, 'load', initialize);

<?PHP

echo "</script>";
echo "</head>";
echo "<body>";
echo "&nbsp;<a href='index.php?loc=ALL'><img src='SilverBay.png' border='0'></a>"; 
echo "&nbsp;&nbsp;<font class='black-14px'><b>Select a Market:</b></font> "; 

$tsql_Market = "SELECT p.[MarketName], m.MarketCode
  ,count(*) as RecordCount
  FROM [DataMart].[rpt].[PropertyMarketPeriod] as p
  inner join rpt.MarketDim as m on m.MarketName=p.MarketName
  where p.PeriodID=16
  group by p.MarketName, m.MarketCode
  order by p.MarketName";
$stmt_Market = sqlsrv_query($conn, $tsql_Market);
while($row_Market = sqlsrv_fetch_array($stmt_Market, SQLSRV_FETCH_ASSOC))
{
	if ($row_Market['MarketCode'] == 'JAX'){
		echo "<br>";
	}
	if ($row_Market['MarketCode'] == 'HOU' or $row_Market['MarketCode'] == 'TUC'){
		printf("<a href='index.php?loc=%s'><font class='darkblue-12px'>%s</font></a> <font class='darkgrey-11px'>(%s)</font>", $row_Market['MarketCode'], $row_Market['MarketName'], number_format($row_Market['RecordCount'], 0));
	} else {
		printf("&nbsp;<a href='index.php?loc=%s'><font class='darkblue-12px'>%s</font></a> <font class='darkgrey-11px'>(%s) - </font>", $row_Market['MarketCode'], $row_Market['MarketName'], number_format($row_Market['RecordCount'], 0));
	}
} 	
?> 	
  	
    <div id="map-canvas"></div>
  </body>
</html>

