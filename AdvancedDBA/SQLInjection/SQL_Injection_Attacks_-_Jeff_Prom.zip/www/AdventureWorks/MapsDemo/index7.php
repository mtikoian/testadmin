<?PHP
ini_set ('display_errors', '1');
session_start();
require('../functions.php');
include('../includes/styles.css');
require_once('dbconnection.php');

?>

<!DOCTYPE html>
<html>
  <head>
    <title>Silver Bay</title>
    <meta name="viewport" content="initial-scale=1.0, user-scalable=no">
    <meta charset="utf-8">
    <style>
      html, body, #map-canvas {
        height: 100%;
        margin: 0px;
        padding: 0px
      }
    </style>
    <script src="https://maps.googleapis.com/maps/api/js?v=3.exp&sensor=false"></script>
    <script>
var map;
function initialize() {
  var mapOptions = {
    zoom: 8,
    center: new google.maps.LatLng(33.436530, -112.007269)
  };
  var map = new google.maps.Map(document.getElementById("map-canvas"), mapOptions);
  
  
  var Coords_8342 = new google.maps.LatLng(33.489711,-112.335316);	
  var String_8342 = '<font class="black-13px">12814 W Clarendon Ave<br>Avondale, AZ 85392</font>';
  var InfoWindow_8342 = new google.maps.InfoWindow({ content: String_8342 });   
  var Marker_8342 = new google.maps.Marker({
      position: Coords_8342,
      map: map,
      title: '12814 W Clarendon Ave, Avondale, AZ 85392'
  });
  google.maps.event.addListener(Marker_8342, 'click', function() { InfoWindow_8342.open(map, Marker_8342); }); 

  
  
}
google.maps.event.addDomListener(window, 'load', initialize);

    </script>
  </head>
  <body>
    <div id="map-canvas"></div>
  </body>
</html>


