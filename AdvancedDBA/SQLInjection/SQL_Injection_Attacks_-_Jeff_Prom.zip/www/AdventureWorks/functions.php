<?PHP
// ----------------------------------------------------------------------------------
// ---------------     AdventureWorks Online FUNCTIONS      -------------------------
// ----------------------------------------------------------------------------------

$DebugMode=1;

// Header Start
function header_start()
{
	echo "<html>";
	echo "<head>";
	echo "<title>AdventureWorks Online!</title>";
	echo "<meta http-equiv='Content-Type' content='text/html; charset=iso-8859-1'>";
	echo "</head>";
}

// ----------------------------------------------------------------------------------
function MainFrame_Top()
{
	echo "<table border='0' cellspacing='0' cellpadding='0' width='900' bgcolor='#f9f9f9'>\n";
		echo "<tr>";
			echo "<td><img src='/images/frame-white3/up-left.gif' width='15' height='15' border='0'></td>";
			echo "<td background='/images/frame-white3/up.gif' width='100%' height='15' border='0'></td>";
			echo "<td><img src='/images/frame-white3/up-right.gif' width='15' height='15' border='0'></td>";
		echo "</tr>\n";
		echo "<tr>";
			echo "<td background='/images/frame-white3/left.gif' width='15'>&nbsp;</td>";
			echo "<td align='center'>";
}

// --------------------------------------------------------------------------------------------------------------------------------
function MainFrame_Bottom()
{
			echo "</td>";
			echo "<td background='/images/frame-white3/right.gif' width='15'>&nbsp;</td>";
		echo "</tr>\n";
		echo "<tr>";
			echo "<td><img src='/images/frame-white3/down-left.gif' width='15' height='15' border='0'></td>";
			echo "<td background='/images/frame-white3/down.gif' width='15' height='15' border='0'></td>";
			echo "<td><img src='/images/frame-white3/down-right.gif' width='15' height='15' border='0'></td>";
		echo "</tr>\n";
		echo "</td>";
		echo "</tr>\n";
	echo "</table>\n";
}

// --------------------------------------------------------------------------------------------------------------------------------
function body() { echo "<body style='margin: 2; padding: 0;' bgcolor='#97b7cf'>"; } // blue
function body2() { echo "<body style='margin: 2; padding: 0;' bgcolor='#97b7cf' background='/images/Downhill-Mountain-Biking-75.jpg'>"; } // blue

// --------------------------------------------------------------------------------------------------------------------------------
function show_logo()
{
	echo "<a href='/index.php'><img src='/images/adventure-works-title.png' border='0'></a>";
}

// --------------------------------------------------------------------------------------------------------------------------------
function small_space()
{
	echo "<table border='0'><tr><td height='5'></td></tr></table>";
}

// --------------------------------------------------------------------------------------------------------------------------------
function footer()
{
	small_space();
	echo "<font class='white-11px'>Copyright &copy; 2013 AdventureWorks Online All rights reserved</font>\n";
	small_space();
}

// --------------------------------------------------------------------------------------------------------------------------------
function menu_bar()
{
	echo "<table border='0' cellspacing='0' cellpadding='0' width='900'>\n";
		echo "<tr valign='bottom'>";
			echo "<td width='575'><a href='/index.php'><img src='/images/adventure-works-title2.png' border='0'></a></td>";
			echo "<td width='125'><div align='left'><img src='/images/icons/application_view_list.png'> <a href='/htm/product-list.php?StatusFilter=Current'><font class='darkblue-13px'>Product List</font></a>";
			echo "</div></td>";
			echo "<td width='200'><div align='left'>";
					if (isset($_SESSION['UserName'])) { // user is logged in
						printf("<img src='/images/icons/lock.png'> <font class='black-13px'><b>You are logged in as '%s'</b></font>", $_SESSION['UserName']);
					} else { // not logged in
						echo "<img src='/images/icons/lock_open.png'> <font class='black-13px'><b>You are not logged in.</b></font>";					
					}
			echo "</div></td>";
		echo "</tr>\n";
	echo "</table>\n";
}

// --------------------------------------------------------------------------------------------------------------------------------

?>
