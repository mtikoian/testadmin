/*
Run an adhoc PBM scan on a server or group of servers,
then save the results as an XML file.
*/
drop table #NodesExample
create table #NodesExample (XMLDocument xml)

INSERT #NodesExample
SELECT * FROM OPENROWSET (BULK 'C:\Temp\output.xml', SINGLE_CLOB) AS xmlData

--SELECT * FROM #NodesExample


-- Use XMLNAMESPACES in order to reference the elements by name
;WITH XMLNAMESPACES ('http://schemas.microsoft.com/sqlserver/DMF/2007/08' AS DMF)
,cte as
(-- Load inital data into a cte. This will break up the document into 1 row for each policy evaluated.
SELECT 
Expr.query('.') as BufferData
FROM #NodesExample
CROSS APPLY XMLDocument.nodes('declare default element namespace "http://schemas.microsoft.com/sqlserver/DMF/2007/08";//bufferData') AS Res(Expr)
)
-- Pull the values for each row.
select
--* -- Select * at this point if you want to see the raw XML data for each row.
BufferData.value('declare default element namespace "http://schemas.microsoft.com/sqlserver/DMF/2007/08";(//DMF:ConnectionEvaluationHistory/DMF:ServerInstance)[1]','varchar(255)') as InstanceName
,BufferData.value('declare default element namespace "http://schemas.microsoft.com/sqlserver/DMF/2007/08";(//DMF:EvaluationHistory/DMF:PolicyName)[1]','varchar(200)') as PolicyName
,(	CASE WHEN UPPER(BufferData.value('(//DMF:EvaluationDetail/DMF:Result)[1]', 'nvarchar(150)')) = 'FALSE' AND BufferData.value('(//DMF:EvaluationDetail/DMF:Exception)[1]', 'nvarchar(max)') = ''
		THEN 'FAIL' 
	WHEN UPPER(BufferData.value('(//DMF:EvaluationDetail/DMF:Result)[1]', 'nvarchar(150)')) = 'FALSE' AND BufferData.value('(//DMF:EvaluationDetail/DMF:Exception)[1]', 'nvarchar(max)') <> ''
		THEN 'ERROR'
	ELSE 'PASS' 
	END
) AS PolicyResult
,BufferData.value('declare default element namespace "http://schemas.microsoft.com/sqlserver/DMF/2007/08";(//DMF:EvaluationDetail/DMF:Exception)[1]','varchar(150)') as Exception
,BufferData.query('declare default element namespace "http://schemas.microsoft.com/sqlserver/DMF/2007/08";//DMF:EvaluationHistory') as EvaluationHistory
,BufferData.query('declare default element namespace "http://schemas.microsoft.com/sqlserver/DMF/2007/08";//DMF:ConnectionEvaluationHistory') as ConnectionEvaluationHistory
,BufferData.query('declare default element namespace "http://schemas.microsoft.com/sqlserver/DMF/2007/08";//DMF:EvaluationDetail') as EvaluationDetail
from cte
