#poleval.ps1
#This script evaluates the dev db option policy.
#
# Change log:
# October 30, 2010: Allen White
#   Initial Version

# Get the SQL Server instance name from the command line
param(
  [string]$inst=$null
  )

# Load SMO assembly, and if we're running SQL 2008 DLLs load the SMOExtended and SQLWMIManagement libraries
$v = [System.Reflection.Assembly]::LoadWithPartialName( 'Microsoft.SqlServer.SMO')
if ((($v.FullName.Split(','))[1].Split('='))[1].Split('.')[0] -ne '9') {
  [System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.SMOExtended') | out-null
  [System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.SQLWMIManagement') | out-null
  }

# Handle any errors that occur
Trap {
  # Handle the error
  $err = $_.Exception
  write-host $err.Message
  while( $err.InnerException ) {
  	$err = $err.InnerException
  	write-output $err.Message
  	};
  # End the script.
  break
  }

$s = new-object ('Microsoft.SqlServer.Management.Smo.Server') $inst

$bkup = $s.Settings.BackupDirectory

# Create the evaluation results directory if it doesn't exist
if (!(Test-Path -path "$bkup\EvalResults\"))
	{
	New-Item "$bkup\EvalResults\" -type directory | out-null
	}

$dt = get-date -format yyyyMMddHHmmss
$evalfile = "$bkup\EvalResults\DevDBEval$dt.xml"

# Get the instance name to determine if it's a default instance
$srv = $inst.Split("\")
if ($srv.Count -eq 1) {
	$polinst = $inst + '\DEFAULT'
	}
	else {
	$polinst = $inst
	}

Set-Location "SQLServer:\SQLPolicy\$polinst\Policies"
Get-Item 'CheckDevelopmentDBOptions' | Invoke-PolicyEvaluation -TargetServerName $inst -OutputXML > $evalfile
