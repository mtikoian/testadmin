#develdbpolicy.ps1
# Create Development Database Policy
#
# Change log:
# October 30, 2010: Allen White
#   Initial Version

# Get the SQL Server instance name from the command line
param(
  [string]$inst=$null
  )

# Load SMO assembly, and if we're running SQL 2008 DLLs load the SMOExtended and SQLWMIManagement libraries
$v = [System.Reflection.Assembly]::LoadWithPartialName( 'Microsoft.SqlServer.SMO')
if ((($v.FullName.Split(','))[1].Split('='))[1].Split('.')[0] -ne '9') {
  [System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.SMOExtended') | out-null
  [System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.SQLWMIManagement') | out-null
  }
[System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.Dmf') | out-null
[System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SQLServer.Management.Sdk.Sfc') | out-null

# Handle any errors that occur
Trap {
  # Handle the error
  $err = $_.Exception
  write-output $err.Message
  while( $err.InnerException ) {
  	$err = $err.InnerException
  	write-output $err.Message
  	};
  # End the script.
  break
  }

# Set Object Names as variables
$polnm = 'CheckDevelopmentDBOptions'
$osetnm = 'DevelopmentDBObjectSet'
$optcondnm = 'DevelopmentDatabase'
$filternm = 'UserDatabase'

# Connect to the specified instance
$conn = New-Object Microsoft.SQlServer.Management.Sdk.Sfc.SqlStoreConnection("server=$inst;Trusted_Connection=true");

# Connect to the policy store
$pstore = New-Object Microsoft.SqlServer.Management.DMF.PolicyStore($conn);

# Create the condition
$cond=New-Object Microsoft.SqlServer.Management.Dmf.Condition ($pstore, $optcondnm) 
$oper=New-Object Microsoft.SqlServer.Management.Dmf.ExpressionNodeOperator ("AND", "@AutoClose = False()", "@AutoShrink = False()")
$cond.ExpressionNode=$oper

$val = "@RecoveryModel = Enum('Microsoft.SqlServer.Management.Smo.RecoveryModel','Simple')"
$oper = New-Object ('Microsoft.SqlServer.Management.Dmf.ExpressionNodeOperator') ("AND", $cond.ExpressionNode, $val)
$cond.ExpressionNode=$oper

$val = "@CompatibilityLevel = Enum('Microsoft.SqlServer.Management.Smo.CompatibilityLevel','Version100')"
$oper = New-Object ('Microsoft.SqlServer.Management.Dmf.ExpressionNodeOperator') ("AND", $cond.ExpressionNode, $val)
$cond.ExpressionNode=$oper
$cond.Facet='IDatabaseOptions'
$cond.Create() | Out-Null

# Create the UserDatabase condition to filter the target set
$dbcond=New-Object Microsoft.SqlServer.Management.Dmf.Condition ($pstore, $filternm) 
$val = '@IsSystemObject = False()'
$dbcond.ExpressionNode=$val
$dbcond.Facet='Database'
$dbcond.Create() | Out-Null

# Create the object set to include every user database.
$oset=New-Object Microsoft.SqlServer.Management.Dmf.ObjectSet($pstore, $osetnm)
$oset.Facet='IDatabaseOptions'
$tset=$oset.TargetSets["Server/Database"]
$tset.SetLevelCondition($tset.GetLevel("Server/Database"),$filternm) | Out-Null
$oset.Create() | Out-Null

# Create the policy
$pol=New-Object ('Microsoft.SqlServer.Management.Dmf.Policy') ($pstore, $polnm)
$pol.Condition=$optcondnm
$pol.ObjectSet=$osetnm
$pol.AutomatedPolicyEvaluationMode="None"
$pol.Create() | Out-Null
