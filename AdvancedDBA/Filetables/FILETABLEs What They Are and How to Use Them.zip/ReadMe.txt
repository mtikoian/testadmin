-------------------------------------------------------------------------------------------------------------
Microsoft SQL Server 2012
FILETABLEs: What They Are and How to Use Them
-------------------------------------------------------------------------------------------------------------
(c) Matija Lah, SQL Server MVP
SolidQ (http://www.solidq.com/)
-------------------------------------------------------------------------------------------------------------
Demonstration materials are published as part of the MVP Award Blog post, entitled "SQL Server 2012: 
Migrating BLOBs to FILETABLEs", available at:
http://blogs.msdn.com/b/mvpawardprogram/archive/2012/07/23/sql-server-2012-migrating-blobs-to-filetables.aspx
-------------------------------------------------------------------------------------------------------------
