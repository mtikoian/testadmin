You may have to modify the following items in the scripts and code:

- Connection strings. Mine assume that you have a default local SQL Server 2012 instance.
- Data file locations. Mine assume that your SQL Server files are stored in C:\SQLData\Data. Alternatively, you can create that folder and ensure that your SQL Server identity has full control NFTS permissions over that folder.
- Database names. Mine assume that the demo will end with 4 different databases, Demo_FileTable01 through Demo_FileTable04. However, you could put everything in a single 

PREREQUISITES

- SQL Server 2012. Everything should work on the Express edition.
	- Full-Text Indexing and Semantic Search installed.
- Visual Studio 2010 Service Pack 1.

CONTENTS

- Visual Studio 2010 SP 1 solution containing the PhotoWatermark project. Sample project showing how transactional access to FileTable data is possible.
- SQL Server 2012 SSDT solution containing 4 script files. In the demo, script 01 is run first, however, you may want to run scripts 05 and 10 first to create the database and the FileTable.
	- Script 40 is for the semantic search demo. Setting up semantic search in SQL Server 2012 is documented here: http://svenaelterman.wordpress.com/2012/04/14/step-by-step-enabling-semantic-search-on-sql-server-2012/ 