USE Demo_FileTable01
GO

SELECT *
FROM Documents

SELECT path_locator, path_locator.ToString()
FROM Documents

SELECT Name, path_locator.ToString() 'HIERARCHYID'
	, path_locator.GetLevel() 'Level'
FROM Documents

SELECT Name, path_locator.GetLevel() 'Level'
	, file_stream.GetFileNamespacePath(1)
FROM Documents

-- This really is FILESTREAM
SELECT Name, file_stream.PathName()
FROM Documents
