USE Demo_FileTable
GO

CREATE TABLE Documents AS FILETABLE
GO

SELECT * from Documents
DROP TABLE Documents

CREATE TABLE Documents AS FILETABLE
	WITH (FILETABLE_DIRECTORY = 'My Documents')
GO