USE Demo_FileTable04
GO

SELECT SERVERPROPERTY('IsFullTextInstalled')
	GO

SELECT * FROM sys.fulltext_semantic_language_statistics_database
GO

SELECT * FROM sys.fulltext_semantic_languages
GO

/*

CREATE DATABASE _SemanticsDB
    ON ( FILENAME = 'C:\SQLData\Data\semanticsdb.mdf' )
    LOG ON ( FILENAME = 'C:\SQLData\Data\semanticsdb_log.ldf' )
    FOR ATTACH
GO

EXEC sp_fulltext_semantic_register_language_statistics_db @dbname = '_SemanticsDB'
GO

*/

/*
	IFILTER COMMANDS
*/
/*
EXEC sp_help_fulltext_system_components 'filter'

EXEC sp_fulltext_service @action='load_os_resources', @value=1;
EXEC sp_fulltext_service 'update_languages';
EXEC sp_fulltext_service 'restart_all_fdhosts'; 

*/

CREATE FULLTEXT CATALOG FT_Resumes AS DEFAULT
GO

CREATE FULLTEXT INDEX ON Resumes
(
	-- Use the file name column for search
	Name LANGUAGE 1033,
	-- Use the contents of the data file
	file_stream 
		-- IFilter is selected based on the file extension
		TYPE COLUMN file_type
		LANGUAGE 1033
		-- This enables statistical semantic search on this column
		Statistical_Semantics 
)
-- FileTable's primary key is suitable for FT
KEY INDEX PK__Resumes__5A5B77D54C319479
GO

SELECT * FROM sys.fulltext_indexes
GO

/*
	Semantic Search Queries
*/

-- Find documents that contain the key phrase Microsoft
SELECT Documents.name, A.FirstName, A.LastName
	, Keyphrases.score
FROM Resumes AS Documents
	LEFT JOIN Applicants A ON A.ResumeId = Documents.stream_id
    INNER JOIN SEMANTICKEYPHRASETABLE		-- This is a TVF
    (
		Resumes,
		file_stream
    ) AS Keyphrases
	ON Documents.path_locator = Keyphrases.document_key
WHERE Keyphrases.keyphrase = 'troy'
ORDER BY Keyphrases.Score DESC;
GO

-- So, what key words are in the resumes?
SELECT KeyPhraseTable.keyphrase, KeyPhraseTable.score
FROM SEMANTICKEYPHRASETABLE
    (
	    Resumes,	-- the table name containing the document
		file_stream	-- the column name of the document
    ) AS KeyPhraseTable
ORDER BY KeyPhraseTable.score DESC

/*
	TEST FULL-TEXT INDEX
*/
SELECT *
FROM Resumes
WHERE FREETEXT(file_stream, 'Microsoft')

/*
	RESET
*/
/*
DROP FULLTEXT INDEX ON Resumes

DROP FULLTEXT CATALOG FT_Resumes
*/