﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

// Imports related to SqlFileStream
using System.Data.SqlClient;
using System.Data.SqlTypes;

namespace PhotoWatermark
{
	public partial class frmMain : Form
	{
		#region Plumbing code

		ImageList il = new ImageList();

		public frmMain()
		{
			InitializeComponent();

			using (SqlConnection conn = new SqlConnection("Data Source=(local);Initial Catalog=Demo_FileTable03;Integrated Security=sspi;"))
			using (SqlCommand cmd = new SqlCommand("TRUNCATE TABLE Pictures",conn))
			{
				conn.Open();
				cmd.ExecuteNonQuery();				
			}

			ImageListView.MultiSelect = true;
			ImageListView.LargeImageList = il;

			il.ImageSize = new System.Drawing.Size(100, 100);

			ShowPictureFolderContents(@"C:\Users\saelterman\Pictures");

		}

		private void ShowPictureFolderContents(string p)
		{
			string[] AllowedExtensions = new string[] { ".gif", ".png", ".bmp", ".jpg" };
			int index = 0;

			foreach (FileInfo item in new DirectoryInfo(p).EnumerateFiles())
			{
				if (AllowedExtensions.Contains(item.Extension))
				{
					il.Images.Add(Image.FromFile(item.FullName));

					ListViewItem i = new ListViewItem(item.Name);
					i.ImageIndex = index;
					i.Name = item.Name;
					i.Tag = item.FullName;

					ImageListView.Items.Add(i);

					index++;
				}
			}
		}

		public Stream AddWatermark(string filename, string watermarkText)
		{
			MemoryStream ms = new MemoryStream();
			Image bitmap = Bitmap.FromFile(filename);
			Font font = new Font("Calibri", 20, FontStyle.Bold, GraphicsUnit.Pixel);
			Color color = Color.FromArgb(25, 255, 255, 255); // Adds a black watermark with a low alpha value (almost transparent)
			Point atPoint = new Point(50, 50); // The pixel point to draw the watermark at (this example puts it at 100, 100 (x, y))
			SolidBrush brush = new SolidBrush(color);

			Graphics graphics = null;

			graphics = Graphics.FromImage(bitmap);

			graphics.DrawString(watermarkText, font, brush, atPoint);
			graphics.Dispose();

			// This routine does not maintain the original image format
			bitmap.Save(ms, System.Drawing.Imaging.ImageFormat.Jpeg);
			ms.Position = 0;

			return ms;
		}
#endregion

		private void WatermarkButton_Click(object sender, EventArgs e)
		{
			if (ImageListView.SelectedItems.Count == 0) return;

			using (SqlConnection conn = new SqlConnection("Data Source=(local);Initial Catalog=Demo_FileTable03;Integrated Security=sspi;"))
			using (SqlCommand cmd = new SqlCommand("SELECT file_stream.PathName(), GET_FILESTREAM_TRANSACTION_CONTEXT() FROM Pictures WHERE name = @name", conn))
			using (SqlCommand CreateRowCmd = new SqlCommand("INSERT INTO Pictures (name, file_stream) VALUES (@name, 0x);", conn))
			{
				conn.Open();

				using (SqlTransaction tran = conn.BeginTransaction())
				{
					CreateRowCmd.Transaction = tran;
					cmd.Transaction = tran;

					foreach (ListViewItem i in ImageListView.SelectedItems)
					{
						SqlParameter NameParam = new SqlParameter("name", i.Name);

						// Create a new row in the FileTable
						CreateRowCmd.Parameters.Add(NameParam);
						CreateRowCmd.ExecuteNonQuery();

						CreateRowCmd.Parameters.Clear();

						// Retrieve the information necessary to access the filestream file
						// for the row that was just inserted
						cmd.Parameters.Clear();
						cmd.Parameters.Add(NameParam);

						byte[] TranContext = null;
						string Path = null;

						using (SqlDataReader dr = cmd.ExecuteReader(CommandBehavior.SingleResult))
						{
							if (dr.Read())
							{
								Path = dr.GetString(0);
								TranContext = (byte[])dr.GetValue(1);
							}
						}

						if (Path != null)
							using (SqlFileStream sfs = new SqlFileStream(Path, TranContext, FileAccess.Write))
							{
								AddWatermark(i.Tag.ToString(), WatermarkTextBox.Text).CopyTo(sfs);
							}
						else
						{
							tran.Rollback();
							MessageBox.Show(this, "INSERT for " + i.Name + " failed.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
							return;
						}
					}

					tran.Commit();
				}
			}
		}
	}
}
