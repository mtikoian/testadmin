﻿namespace PhotoWatermark
{
	partial class frmMain
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.WatermarkLabel = new System.Windows.Forms.Label();
			this.WatermarkTextBox = new System.Windows.Forms.TextBox();
			this.ImageListView = new System.Windows.Forms.ListView();
			this.WatermarkButton = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// WatermarkLabel
			// 
			this.WatermarkLabel.AutoSize = true;
			this.WatermarkLabel.Location = new System.Drawing.Point(12, 9);
			this.WatermarkLabel.Name = "WatermarkLabel";
			this.WatermarkLabel.Size = new System.Drawing.Size(102, 13);
			this.WatermarkLabel.TabIndex = 0;
			this.WatermarkLabel.Text = "Watermark to apply:";
			// 
			// WatermarkTextBox
			// 
			this.WatermarkTextBox.Location = new System.Drawing.Point(120, 6);
			this.WatermarkTextBox.Name = "WatermarkTextBox";
			this.WatermarkTextBox.Size = new System.Drawing.Size(206, 20);
			this.WatermarkTextBox.TabIndex = 1;
			this.WatermarkTextBox.Text = "SQL Saturday 111";
			// 
			// ImageListView
			// 
			this.ImageListView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.ImageListView.Location = new System.Drawing.Point(15, 45);
			this.ImageListView.Name = "ImageListView";
			this.ImageListView.Size = new System.Drawing.Size(580, 302);
			this.ImageListView.TabIndex = 2;
			this.ImageListView.UseCompatibleStateImageBehavior = false;
			// 
			// WatermarkButton
			// 
			this.WatermarkButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.WatermarkButton.Location = new System.Drawing.Point(519, 353);
			this.WatermarkButton.Name = "WatermarkButton";
			this.WatermarkButton.Size = new System.Drawing.Size(75, 23);
			this.WatermarkButton.TabIndex = 3;
			this.WatermarkButton.Text = "Watermark";
			this.WatermarkButton.UseVisualStyleBackColor = true;
			this.WatermarkButton.Click += new System.EventHandler(this.WatermarkButton_Click);
			// 
			// frmMain
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(607, 388);
			this.Controls.Add(this.WatermarkButton);
			this.Controls.Add(this.ImageListView);
			this.Controls.Add(this.WatermarkTextBox);
			this.Controls.Add(this.WatermarkLabel);
			this.Name = "frmMain";
			this.Text = "Photo Watermark";
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Label WatermarkLabel;
		private System.Windows.Forms.TextBox WatermarkTextBox;
		private System.Windows.Forms.ListView ImageListView;
		private System.Windows.Forms.Button WatermarkButton;
	}
}

