/*
This script is the first of 4 scripts used to set up event notifications for deadlocks.
The event notification system will send an email - See script 3.
So please make sure database mail is correctly set up before setting up event notifications for deadlocks.
*/

USE [master];
GO
/*
Set service broker on in the database.
*/

IF EXISTS (SELECT 1 FROM sys.databases WHERE [name] = 'DBA_ADMIN' AND is_broker_enabled = 0)
	BEGIN
		PRINT 'About to enable service broker in database [DBA_ADMIN]';
		ALTER DATABASE [DBA_ADMIN] SET ENABLE_BROKER
	END
ELSE
	BEGIN
		PRINT 'Service broker is enabled in database [DBA_ADMIN]';
	END
GO
/*
Switch to DBA_ADMIN database
*/
USE [DBA_ADMIN];
GO

/*
Create the service broker queue if it does not already exsist.
*/
IF NOT EXISTS (SELECT * FROM [sys].[service_queues] [sq] WHERE [sq].[name] = 'CreateDatabaseQueue')
	BEGIN	
		PRINT 'QUEUE [CreateDatabaseQueue] does not exist in database [' + db_name() + '] on Server [' + @@SERVERNAME + '] - about to create it';
		CREATE QUEUE [CreateDatabaseQueue];
		PRINT 'QUEUE [CreateDatabaseQueue] now created in database [' + db_name() + '] on Server [' + @@SERVERNAME + ']';

	END
ELSE
	BEGIN
		PRINT 'QUEUE [CreateDatabaseQueue] already exists in database [' + db_name() + '] on Server [' + @@SERVERNAME + '] - and will not be created';
	END;
GO
/*
Create the service 'DeadlockNotificationService' on the previously created queue 'DeadlockNotificationQueue'
*/
IF NOT EXISTS (SELECT * FROM [DBA_ADMIN].[sys].[services] [S] WHERE [S].[name] = 'CreateDatabaseService')
	BEGIN
		PRINT 'SERVICE [CreateDatabaseService] does not exist in database [' + db_name() + '] - about to create this';
		CREATE SERVICE CreateDatabaseService
			ON QUEUE CreateDatabaseQueue
			([http://schemas.microsoft.com/SQL/Notifications/PostEventNotification]);
	END
ELSE
	BEGIN
		PRINT 'SERVICE [CreateDatabaseService] already exists in database [' + db_name() + ']'
	END;
GO
/*
CREATE A ROUTE ON THAT SERVICE.
*/
IF NOT EXISTS (SELECT * FROM [sys].[routes] [R] WHERE [R].[name] = 'CreateDatabaseNotificationRoute')
	BEGIN
		PRINT 'ROUTE [CreateDatabaseNotificationRoute] does not exists in database [' + db_name() + '] on server [' + @@SERVERNAME + '] - about to create this.';
		CREATE ROUTE CreateDatabaseNotificationRoute
			WITH SERVICE_NAME = 'CreateDatabaseService',
			ADDRESS = 'LOCAL' ;
	END
ELSE
	BEGIN
		PRINT 'ROUTE [CreateDatabaseNotificationRoute] already exists in database [' + db_name() + '] on server [' + @@SERVERNAME + ']';
	END;
GO
/*
Create the notification if it does not already exist.
*/
IF NOT EXISTS (SELECT * FROM [sys].[server_event_notifications] [sen] WHERE [sen].[name] = 'CreateDatabaseNotification')
	BEGIN
		PRINT 'Server event notification [CreateDatabaseNotification] does not exists on server [' + @@SERVERNAME + '] and will be created';
		--DROP EVENT NOTIFICATION CreateDatabaseNotification ON SERVER;
		CREATE EVENT NOTIFICATION CreateDatabaseNotification
			ON SERVER
			WITH FAN_IN
			FOR CREATE_DATABASE , DROP_DATABASE /*This is the event we are interested in*/
			TO SERVICE 'CreateDatabaseService','current database';
	END
ELSE
	BEGIN
		PRINT 'Server event notification [CreateDatabaseNotification] already exists on server [' + @@SERVERNAME + ']';
	END;
GO



