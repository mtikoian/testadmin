USE [DBA_ADMIN];
GO

SELECT * FROM [dbo].[DatabaseObjectReports] ORDER BY create_date DESC;
/*
DELETE FROM [dbo].[DatabaseObjectReports]
INSERT INTO [dbo].[DatabaseObjectReports] ([event_data]) VALUES ('<CreateDB>Testdb</CreateDB>');

SELECT COUNT(*) FROM [dbo].[DatabaseObjectReports];
*/

SELECT [dbs].[is_trustworthy_on] , [dbs].[name] FROM [sys].[databases] [dbs] --WHERE [dbs].[name] IN ('msdb')