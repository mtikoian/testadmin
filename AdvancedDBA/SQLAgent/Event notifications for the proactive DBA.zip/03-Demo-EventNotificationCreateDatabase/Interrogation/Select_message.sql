/*
Shred the XML that is returned by the CREATE_DATABASE / DROP_DATABASE events of event notifications.
Do this for the CREATE_DATABASE event - ORDER BY create_date
*/
USE [DBA_Admin];
GO
DECLARE @event_data XML;
DECLARE @EventType NVARCHAR(128);
DECLARE @PostTime NVARCHAR(128);
DECLARE @SPID NVARCHAR(128);
DECLARE @ServerName NVARCHAR(128);
DECLARE @LoginName NVARCHAR(128);
DECLARE @DatabaseName NVARCHAR(128);
DECLARE @CommandText NVARCHAR(128);

SELECT	
	@event_data = event_data,
	@EventType = Event_Instance.value('EventType[1]' ,'NVARCHAR(128)'),
	@PostTime = Event_Instance.value('PostTime[1]' ,'NVARCHAR(128)'),
	@SPID = Event_Instance.value('SPID[1]' ,'NVARCHAR(128)'),
	@ServerName = Event_Instance.value('ServerName[1]' ,'NVARCHAR(128)'),
	@LoginName = Event_Instance.value('LoginName[1]' ,'NVARCHAR(128)'),
	@DatabaseName = Event_Instance.value('DatabaseName[1]' ,'NVARCHAR(128)'),
	@CommandText = T_SQL.value('CommandText[1]' ,'NVARCHAR(128)')
FROM 
	[dbo].[DatabaseObjectReports] [DOR]
OUTER APPLY 
	event_data.nodes('/EVENT_INSTANCE') a(Event_Instance)
OUTER APPLY 
	event_data.nodes('/EVENT_INSTANCE/TSQLCommand') b(T_SQL)
ORDER BY
	[DOR].[create_date] DESC;

PRINT 'Event is [' + @EventType + ']';
PRINT 'TSQL Command is ' + @CommandText;
PRINT 'SQL SERVER Instance is [' + @ServerName +']';
PRINT 'Login Name is [' + @LoginName +']';
PRINT 'SPID - [' + @SPID +']';
PRINT 'Create Time - [' + @PostTime +']';

