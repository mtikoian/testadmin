/*
Shred the XML that is returned by the CREATE_DATABASE / DROP_DATABASE events of event notifications.
Do this for the CREATE_DATABASE event - ORDER BY create_date
*/
USE [DBA_Admin];
GO
SELECT	
	event_data,
	Event_Instance.value('EventType[1]' ,'NVARCHAR(128)') as [EventType],
	Event_Instance.value('PostTime[1]' ,'NVARCHAR(128)') as [PostTime],
	Event_Instance.value('SPID[1]' ,'NVARCHAR(128)') as [SPID],
	Event_Instance.value('ServerName[1]' ,'NVARCHAR(128)') as [ServerName],
	Event_Instance.value('LoginName[1]' ,'NVARCHAR(128)') as [LoginName],
	Event_Instance.value('DatabaseName[1]' ,'NVARCHAR(128)') as [DatabaseName],
	T_SQL.value('CommandText[1]' ,'NVARCHAR(128)') as [CommandText],
	create_date [event date]

FROM 
	[dbo].[DatabaseObjectReports] [DOR]
OUTER APPLY 
	event_data.nodes('/EVENT_INSTANCE') a(Event_Instance)
OUTER APPLY 
	event_data.nodes('/EVENT_INSTANCE/TSQLCommand') b(T_SQL)
WHERE
	Event_Instance.value('EventType[1]' ,'NVARCHAR(128)') = 'CREATE_DATABASE'
ORDER BY
	[DOR].[create_date] DESC;

