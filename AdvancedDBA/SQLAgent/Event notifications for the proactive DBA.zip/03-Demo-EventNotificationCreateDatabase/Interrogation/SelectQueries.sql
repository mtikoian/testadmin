USE [tempdb];
GO  
ALTER DATABASE [tester] SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
DROP DATABASE [tester];
CREATE DATABASE [tester];
GO
USE [DBA_Admin];
GO
--SELECT * FROM [dbo].[CreateDatabaseQueue];
SELECT * FROM [dbo].[DatabaseObjectReports] [DOR] ORDER BY [DOR].[create_date] DESC;
GO








