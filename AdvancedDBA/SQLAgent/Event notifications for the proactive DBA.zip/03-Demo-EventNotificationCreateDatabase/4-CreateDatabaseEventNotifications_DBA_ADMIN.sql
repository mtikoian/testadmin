USE [DBA_ADMIN];
GO
ALTER QUEUE CreateDatabaseQueue
WITH
ACTIVATION
(
	STATUS=ON,
	PROCEDURE_NAME = [ProcessCreateDatabaseReports],
	MAX_QUEUE_READERS = 1,
	EXECUTE AS OWNER
);
GO
/*
GO
ALTER QUEUE CreateDatabaseQueue
WITH
ACTIVATION
(
	STATUS=ON
);
GO

ALTER QUEUE CreateDatabaseQueue
WITH
ACTIVATION
(
	STATUS=OFF,
	PROCEDURE_NAME = [ProcessCreateDatabaseReports],
	MAX_QUEUE_READERS = 1,
	EXECUTE AS OWNER
);
GO

ALTER QUEUE [DeadlockNotificationQueue] WITH STATUS = ON;
*/