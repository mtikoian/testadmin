USE [DBA_ADMIN];
GO
/*
DROP TABLE [dbo].[DatabaseObjectReports];
*/
IF NOT EXISTS ( SELECT *
				FROM sys.tables
					WHERE OBJECT_ID = OBJECT_ID('dbo.DatabaseObjectReports') )
	BEGIN
		PRINT 'Table [dbo].[DatabaseObjectReports] about to be created in database [' + DB_NAME() + '] on server [' + @@SERVERNAME + ']';
		CREATE TABLE [dbo].[DatabaseObjectReports]
		(
			 DatabaseObjectReports_id INT IDENTITY(1,1)
			,event_data XML
			,create_date DATETIME CONSTRAINT DF_DatabaseObjectReports_CreateDate DEFAULT (GETDATE())
			,created_by NVARCHAR(255) CONSTRAINT DF_DatabaseObjectReports_CreatedBy DEFAULT (SUSER_SNAME())
			,notes NVARCHAR(MAX) NOT NULL CONSTRAINT DF_DatabaseObjectReports_notes DEFAULT ('Default text')
			,CONSTRAINT PK_DatabaseObjectReports PRIMARY KEY CLUSTERED (DatabaseObjectReports_id)
		);
		PRINT 'Table [dbo].[DatabaseObjectReports] has been created in database [' + DB_NAME() + '] on server [' + @@SERVERNAME + ']';
	END
ELSE
	BEGIN
		PRINT 'Table [dbo].[DatabaseObjectReports] already exists in database [' + DB_NAME() + '] on server [' + @@SERVERNAME + ']';
	END
GO
