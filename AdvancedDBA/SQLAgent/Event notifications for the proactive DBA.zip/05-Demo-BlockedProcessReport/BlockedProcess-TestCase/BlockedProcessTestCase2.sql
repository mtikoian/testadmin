/*
Run this file in a seperate window after running BlockedProcessTestCase1.sql
BlockedProcessTestCase1.sql create an exclusive table lock on the entire table, inside a transaction, 
and so this statement will be blocked indefinitly.
*/
USE [tempdb];
GO
	UPDATE dbo.table1 WITH (TABLOCK) SET col1 = 1; -- now attempt to insert update this table from a new query window
GO


