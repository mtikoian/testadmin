/*
Run this file to create a table level lock
*/
USE [tempdb];
GO
BEGIN TRAN --Start inside a transaction so the table level lock is held.
	INSERT dbo.table1 ( col1 )VALUES  ( 1 );
	UPDATE dbo.table1 WITH (TABLOCK) SET col1 = 1 -- now attempt to insert update this table from a new query window
--ROLLBACK


