/*
Create test table for the blocked process report test case.
These tables will be used to create a block.
*/
USE [tempdb];
GO
IF NOT EXISTS(SELECT 1 FROM [sys].[tables] [T] WHERE [T].[name] = 'table1')
	BEGIN
		PRINT 'Creating table [table1] in database [' + db_name() + '] on server [' + @@SERVERNAME + ']';
		CREATE TABLE table1 (col1 INT NOT NULL);
	END
ELSE
	BEGIN
		PRINT 'Table [table1] exists in database [' + db_name() + '] on server [' + @@SERVERNAME + ']';
	END
IF NOT EXISTS(SELECT 1 FROM [sys].[tables] [T] WHERE [T].[name] = 'table2')
	BEGIN
		PRINT 'Creating table [table2] in database [' + db_name() + '] on server [' + @@SERVERNAME + ']';
		CREATE TABLE table2 (col2 INT NOT NULL);
	END
ELSE
	BEGIN
		PRINT 'Table [table2] exists in database [' + db_name() + '] on server [' + @@SERVERNAME + ']';
	END
GO