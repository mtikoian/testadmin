/*
This script will delete the tables that are used for a test case for the blocked process report.
*/
USE [tempdb];
GO
IF EXISTS(SELECT 1 FROM [sys].[tables] [T] WHERE [T].[name] = 'table1')
	BEGIN
		PRINT 'Dropping table [table1] in database [' + db_name() + '] on server [' + @@SERVERNAME + ']';
		DROP TABLE table1;
	END
ELSE
	BEGIN
		PRINT 'Table [table1] does not exists in database [' + db_name() + '] on server [' + @@SERVERNAME + ']';
	END;
IF EXISTS(SELECT 1 FROM [sys].[tables] [T] WHERE [T].[name] = 'table2')
	BEGIN
		PRINT 'Dropping table [table2] in database [' + db_name() + '] on server [' + @@SERVERNAME + ']';
		DROP TABLE table2;
	END
ELSE
	BEGIN
		PRINT 'Table [table2] does not exists in database [' + db_name() + '] on server [' + @@SERVERNAME + ']';
	END;
GO