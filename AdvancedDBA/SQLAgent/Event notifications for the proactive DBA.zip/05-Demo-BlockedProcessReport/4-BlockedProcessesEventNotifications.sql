USE [DBA_ADMIN];
GO
SELECT [sq].[activation_procedure] , [sq].[is_activation_enabled] FROM [sys].[service_queues] [sq] WHERE [sq].[name] = 'BlockedProcessReportQueue'
GO
ALTER QUEUE BlockedProcessReportQueue
WITH
ACTIVATION
(
	STATUS=ON,
	PROCEDURE_NAME = [dbo].[ProcessBlockProcessReports],
	MAX_QUEUE_READERS = 1,
	EXECUTE AS OWNER
);
GO
SELECT [sq].[activation_procedure] , [sq].[is_activation_enabled] FROM [sys].[service_queues] [sq] WHERE [sq].[name] = 'BlockedProcessReportQueue'
GO