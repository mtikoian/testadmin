/*
This script will remove all service broker components connected to the blocked process report.
These are
Service
Queue
Route
Server Event Notification.

The ENABLE_BROKER setting in the DBA_ADMIN database will be left set to on.
Please switch this off manually if needed but be aware that switching this off
will affect any other service broker compoents using that database.
*/
USE [DBA_ADMIN];
GO


/*
Create the service 'BlockedProcessReportService' on the previously created queue 'DeadlockNotificationQueue'
*/
IF NOT EXISTS (SELECT * FROM [DBA_ADMIN].[sys].[services] [S] WHERE [S].[name] = 'BlockedProcessReportService')
	BEGIN
		PRINT 'SERVICE [BlockedProcessReportService] does not exist in database [' + db_name() + '] on Server [' + @@SERVERNAME + '] - and therefore can not be dropped';
	END
ELSE
	BEGIN
		PRINT 'SERVICE [BlockedProcessReportService] exists in database [' + db_name() + '] on server [' + @@SERVERNAME + '] and will be dropped.';
		DROP SERVICE BlockedProcessReportService
	END;
GO
/*
Remove the service broker queue if it exists.
*/
IF NOT EXISTS (SELECT * FROM [sys].[service_queues] [sq] WHERE [sq].[name] = 'BlockedProcessReportQueue')
	BEGIN	
		PRINT 'QUEUE [BlockedProcessReportQueue] does not exist in database [' + db_name() + '] on Server [' + @@SERVERNAME + '] - and therefore can not be removed';
	END
ELSE
	BEGIN
		PRINT 'QUEUE [BlockedProcessReportQueue] exists in database [' + db_name() + '] on Server [' + @@SERVERNAME + '] - and will be removed';
		DROP QUEUE [BlockedProcessReportQueue];
		PRINT 'QUEUE [BlockedProcessReportQueue] has now been dropped';
	END;
GO
/*
DROP THE ROUTE 'BlockedProcessReportRoute'.
*/
IF NOT EXISTS (SELECT * FROM [sys].[routes] [R] WHERE [R].[name] = 'BlockedProcessReportRoute')
	BEGIN
		PRINT 'ROUTE [BlockedProcessReportRoute] does not exists in database [' + db_name() + '] on server [' + @@SERVERNAME + '] - and therefore can not be dropped.';
	END
ELSE
	BEGIN
		PRINT 'ROUTE [BlockedProcessReportRoute] exists in database [' + db_name() + '] on server [' + @@SERVERNAME + '] and is about to be dropped';
		DROP ROUTE BlockedProcessReportRoute;
		PRINT 'ROUTE [BlockedProcessReportRoute] has now been dropped';
	END;
GO
/*
Create the notification if it does not already exist.
*/
IF NOT EXISTS (SELECT * FROM [sys].[server_event_notifications] [sen] WHERE [sen].[name] = 'BlockedProcessReport')
	BEGIN
		PRINT 'Server event notification [BlockedProcessReport] does not exists on server [' + @@SERVERNAME + '] and therefore can not be dropped';
	END
ELSE
	BEGIN
		PRINT 'Server event notification [BlockedProcessReport] exists on server [' + @@SERVERNAME + '] and will be dropped';
		DROP EVENT NOTIFICATION BlockedProcessReport ON SERVER;
		PRINT 'Server event notification [BlockedProcessReport] has been dropped';
	END;
GO


USE [tempdb];
GO
IF EXISTS (SELECT 1 FROM [sys].[databases] [dbs] WHERE [dbs].[name] = 'DBA_ADMIN' AND is_broker_enabled = 0)
	BEGIN
		PRINT 'Service broker is not enabled in database [DBA_ADMIN] ON SERVER [' + @@SERVERNAME + ']';
	END
ELSE
	BEGIN
		PRINT 'Service broker is enabled in database [DBA_ADMIN] ON SERVER [' + @@SERVERNAME + ']';
	END
GO
USE [DBA_ADMIN];
GO


