
USE [DBA_ADMIN_TST]
GO
select * from [dbo].[BlockedProcessReports]

