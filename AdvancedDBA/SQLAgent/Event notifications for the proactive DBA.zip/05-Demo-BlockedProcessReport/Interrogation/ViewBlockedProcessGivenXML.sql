/*

*/
USE [DBA_ADMIN];
GO
DECLARE @xml xml;
SELECT TOP 1 @xml = [bpr].[blocked_process_report] 
FROM [dbo].[BlockedProcessReports] [bpr];


WITH CTE AS (
   SELECT sqlhandle = convert(varbinary(64), T.c.value('@sqlhandle', 'varchar(128)'), 1),
          stmtstart = T.c.value('@stmtstart', 'int'),
          stmtend   = T.c.value('@stmtend', 'int')
   FROM   @xml.nodes('/blocked-process-report/blocked-process/process/executionStack/frame') AS T(c)
 )
 SELECT substring([est].[text], (([CTE].[stmtstart] / 2) + 1), 
                 CASE WHEN CTE.stmtend IS NOT NULL
                       THEN (CTE.stmtend - CTE.stmtstart) / 2
                       ELSE len(text)
                  END)
 FROM CTE
 CROSS APPLY 
	sys.dm_exec_sql_text(CTE.sqlhandle) AS est
