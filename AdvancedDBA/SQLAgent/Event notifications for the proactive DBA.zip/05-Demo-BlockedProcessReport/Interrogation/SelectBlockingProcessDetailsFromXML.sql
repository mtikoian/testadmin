/*
Get the details from the "blocking-process" element of the blocked process report that
is stored dbo].[BlockedProcessReports] table
This query uses the plan cache so the query plan must still be in the plan text.
*/
USE [DBA_ADMIN];
GO
IF OBJECT_ID('tempdb..#temp') IS NOT NULL
BEGIN
	DROP TABLE #temp;
END

SELECT	
	[BPR].[blocked_process_id] [ID],
	--[BPR].[server_name],
	--[BPR].[create_date],
	[BPR].[database_name],
	--e.value('@monitorLoop' ,'int') as [monitorLoop],
	convert(varbinary(64), x.value('@sqlhandle', 'varchar(128)'), 1) AS [sqlhandle],
	--g.value('@waittime', 'int') [WaitTime],
		
	--CAST(x.value('@sqlhandle', 'varchar(128)') AS VARBINARY) AS [sqlhandle],
	stmtstart = x.value('@stmtstart', 'int'),
	stmtend   = x.value('@stmtend', 'int')
INTO
	#temp
FROM 
	[dbo].[BlockedProcessReports] [BPR]
OUTER APPLY 
	blocked_process_report.nodes('/blocked-process-report/blocked-process/process/executionStack/frame') a(x)
WHERE
	[BPR].[blocked_process_id] = 1;

SELECT * FROM [dbo].[BlockedProcessReports] [BPR]

/*
Now query the temp table.
*/
SELECT
	*,
	--OBJECT_NAME([EST].[objectid]),
	substring([EST].[text], ([BlockedProcess].stmtstart / 2) + 1, 
            CASE WHEN [BlockedProcess].stmtend IS NOT NULL
                THEN ([BlockedProcess].stmtend - [BlockedProcess].stmtstart) / 2
                ELSE len(text)
            END) [Statement],
	est.text [FullStatementBatch] 
FROM 
	[#temp] [BlockedProcess]
CROSS APPLY		
	[sys].[dm_exec_sql_text]([BlockedProcess].[sqlhandle]) AS [EST]
CROSS APPLY 
	[BlockedProcess].nodes('//frame') x (frame)
INNER JOIN sys.dm_exec_query_stats qs
		ON qs.[sql_handle] = frame.value('xs:hexBinary(substring((@sqlhandle)[1],3))', 'varbinary(max)');
SELECT * FROM dbo.BlockedProcessReports
SELECT 
	frame.value('xs:hexBinary(substring((@sqlhandle)[1],3))', 'varbinary(max)')
FROM 
	dbo.BlockedProcessReports
CROSS APPLY 
	blocked_process_report.nodes('//frame[1]') x (frame)
INNER JOIN sys.dm_exec_query_stats qs
		ON qs.[sql_handle] = frame.value('xs:hexBinary(substring((@sqlhandle)[1],3))', 'varbinary(max)');
