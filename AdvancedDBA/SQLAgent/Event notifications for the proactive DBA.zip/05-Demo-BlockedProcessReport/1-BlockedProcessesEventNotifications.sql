USE [tempdb];
GO
IF EXISTS (SELECT 1 FROM sys.databases WHERE [name] = 'DBA_ADMIN' AND is_broker_enabled = 0)
	BEGIN
		PRINT 'About to enable service broker in database [DBA_ADMIN]';
		ALTER DATABASE [DBA_ADMIN] SET ENABLE_BROKER
	END
ELSE
	BEGIN
		PRINT 'Service broker is already enabled in database [DBA_ADMIN] - no changes required to this setting.';
	END
GO
USE [DBA_ADMIN];
GO

/*
Create the service broker queue if it does not already exsist.
*/
IF NOT EXISTS (SELECT * FROM [sys].[service_queues] [sq] WHERE [sq].[name] = 'BlockedProcessReportQueue')
	BEGIN	
		PRINT 'QUEUE [BlockedProcessReportQueue] does not exist in database [' + db_name() + '] on Server [' + @@SERVERNAME + '] - about to create it';
		CREATE QUEUE BlockedProcessReportQueue;
		PRINT 'QUEUE [BlockedProcessReportQueue] now created in database [' + db_name() + '] on Server [' + @@SERVERNAME + ']';
	END
ELSE
	BEGIN
		PRINT 'QUEUE [BlockedProcessReportQueue] already exists in database [' + db_name() + '] on Server [' + @@SERVERNAME + '] - and will not be created';
	END;
GO
/*
Create the service 'BlockedProcessReportService' on the previously created queue 'DeadlockNotificationQueue'
*/
IF NOT EXISTS (SELECT * FROM [DBA_ADMIN].[sys].[services] [S] WHERE [S].[name] = 'BlockedProcessReportService')
	BEGIN
		PRINT 'SERVICE [BlockedProcessReportService] does not exist in database [' + db_name() + '] on instance [' + @@SERVERNAME + '] - about to create this';
		CREATE SERVICE BlockedProcessReportService
			ON QUEUE BlockedProcessReportQueue
				([http://schemas.microsoft.com/SQL/Notifications/PostEventNotification]);
		PRINT 'SERVICE [BlockedProcessReportService] now created in database [' + db_name() + '] on instance [' + @@SERVERNAME + ']';
	END
ELSE
	BEGIN
		PRINT 'SERVICE [BlockedProcessReportService] already exists in database [' + db_name() + '] - and will not be created';
	END;
GO
/*
CREATE A ROUTE ON THAT SERVICE.
*/
IF NOT EXISTS (SELECT * FROM [sys].[routes] [R] WHERE [R].[name] = 'BlockedProcessReportRoute')
	BEGIN
		PRINT 'ROUTE [BlockedProcessReportRoute] does not exists in database [' + db_name() + '] on instance [' + @@SERVERNAME + '] - about to create this.';
		CREATE ROUTE BlockedProcessReportRoute
			WITH SERVICE_NAME = 'BlockedProcessReportService',
			ADDRESS = 'LOCAL' ;
		PRINT 'ROUTE [BlockedProcessReportRoute] now created in database [' + db_name() + '] on instance [' + @@SERVERNAME + ']';
	END
ELSE
	BEGIN
		PRINT 'ROUTE [BlockedProcessReportRoute] already exists in database [' + db_name() + '] on server [' + @@SERVERNAME + '] - and will not be created';
	END;
GO
/*
Create the notification if it does not already exist.
*/
IF NOT EXISTS (SELECT * FROM [sys].[server_event_notifications] [sen] WHERE [sen].[name] = 'BlockedProcessReport')
	BEGIN
		PRINT 'Server event notification [BlockedProcessReport] does not exists on server [' + @@SERVERNAME + ']';
		CREATE EVENT NOTIFICATION BlockedProcessReport
			ON SERVER
			WITH FAN_IN
			FOR BLOCKED_PROCESS_REPORT
			TO SERVICE 'BlockedProcessReportService','current database';
		PRINT 'Server event notification [BlockedProcessReport] now created on instance [' + @@SERVERNAME + ']';
	END
ELSE
	BEGIN
		PRINT 'Server event notification [BlockedProcessReport] already exists on server [' + @@SERVERNAME + '] - and will not be created';
	END;
GO



