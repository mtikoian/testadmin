USE [DBA_ADMIN];
GO

/*
--Only use this if you wish to drop the table [dbo].[BlockedProcessReports]
IF OBJECT_ID('[dbo].[BlockedProcessReports]') IS NOT NULL
BEGIN
	PRINT 'About to drop table [dbo].[BlockedProcessReports] on database [' + db_name() + '] on server [' + @@SERVERNAME + ']'; 
	DROP TABLE [dbo].[BlockedProcessReports];
	PRINT 'Table [dbo].[BlockedProcessReports] dropped on database [' + db_name() + '] on server [' + @@SERVERNAME + ']';  
END;
GO
*/

IF OBJECT_ID('[dbo].[BlockedProcessReports]') IS NULL
	BEGIN
		PRINT 'Table [dbo].[BlockedProcessReports] does not exists and will be created';
		CREATE TABLE [dbo].[BlockedProcessReports]
		(
			 blocked_process_id int IDENTITY(1,1) NOT NULL
			,database_name sysname
			,blocked_process_report xml
			,server_name  NVARCHAR(255) CONSTRAINT [DF_BlockedProcessReports_server_name] DEFAULT @@SERVERNAME
			,create_date datetime CONSTRAINT [DF_BlockedProcessReports_create_date] DEFAULT GETDATE()
			,created_by NVARCHAR(255) CONSTRAINT [DF_BlockedProcessReports_CreateBy] DEFAULT SUSER_SNAME()
			CONSTRAINT PK_BlockedProcessReports PRIMARY KEY CLUSTERED (blocked_process_id ASC)
		);
	END
ELSE
	BEGIN
		PRINT 'Table [dbo].[BlockedProcessReports] already exists';
	END
GO