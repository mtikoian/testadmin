/*
This script will set the blocked process report interval in [sys].[configurations]
*/
USE [tempdb];
GO
EXEC sp_configure 'show advanced options',1 ;
GO
RECONFIGURE;
GO
EXEC sp_configure 'blocked process threshold',2 ;
GO
RECONFIGURE;
GO
EXEC sp_configure 'show advanced options',0 ;
GO
RECONFIGURE;
GO