/*
This will remove the deadlock notifications that 
*/

USE [master];
GO
/*
Set service broker off in the database.
Make sure nothing else is using it - else it will not work.
Blocked process report uses this.
*/
IF EXISTS (SELECT [dbs].[is_broker_enabled] FROM sys.databases [dbs] WHERE [name] = 'DBA_ADMIN' AND is_broker_enabled = 1)
	BEGIN
		PRINT 'About to disable service broker in database [DBA_ADMIN] on server [' + @@SERVERNAME + ']  - check nothing else needs this';	
		ALTER DATABASE [DBA_ADMIN] SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
		ALTER DATABASE [DBA_ADMIN] SET DISABLE_BROKER
		ALTER DATABASE [DBA_ADMIN] SET MULTI_USER;
		PRINT 'Service broker in database [DBA_ADMIN] on server [' + @@SERVERNAME + '] is now disabled - check nothing else needs this';
	END
ELSE
	BEGIN
		PRINT 'Service broker is not enabled in database [DBA_ADMIN] on server [' + @@SERVERNAME + ']';
	END
GO
/*
Switch to DBA_ADMIN database
*/
USE [DBA_ADMIN];
GO
/*
Drop the service 'DeadlockNotificationService' - database scoped
*/
IF EXISTS (SELECT * FROM [DBA_ADMIN].[sys].[services] [S] WHERE [S].[name] = 'DeadlockNotificationService')
	BEGIN
		PRINT 'DROPPING SERVICE [DeadlockNotificationService] in database [' + db_name() + '] on server [' + @@SERVERNAME + ']';
		DROP SERVICE DeadlockNotificationService
	END
ELSE
	BEGIN
		PRINT 'SERVICE [DeadlockNotificationService] does not exist in database [' + db_name() + '] on server [' + @@SERVERNAME + ']';
	END;
GO
/*
remove the service broker queue if exsist - database scoped
*/
IF EXISTS (SELECT * FROM [sys].[service_queues] [sq] WHERE [sq].[name] = 'DeadlockNotificationQueue')
	BEGIN	
		PRINT 'QUEUE [DeadlockNotificationQueue] exists in database [' + db_name() + '] on Server [' + @@SERVERNAME + '] - and will be dropped';
		DROP QUEUE [DeadlockNotificationQueue];
	END
ELSE
	BEGIN
		PRINT 'QUEUE [DeadlockNotificationQueue] does not exists in database [' + db_name() + '] on Server [' + @@SERVERNAME + ']';
	END;
GO

/*
DROP ROUTE ON THAT SERVICE - database scoped
*/
IF EXISTS (SELECT * FROM [sys].[routes] [R] WHERE [R].[name] = 'DeadlockNotificationRoute')
	BEGIN
		PRINT 'ROUTE [DeadlockNotificationRoute] exists in database [' + db_name() + '] on server [' + @@SERVERNAME + '] - and is being dropped';
		DROP ROUTE DeadlockNotificationRoute;
	END
ELSE
	BEGIN
		PRINT 'ROUTE [DeadlockNotificationRoute] does not exists in database [' + db_name() + '] on server [' + @@SERVERNAME + ']';
	END;
GO
/*
drop the notification if it does not already exist - database scoped
*/
IF EXISTS (SELECT * FROM [sys].[server_event_notifications] [sen] WHERE [sen].[name] = 'DeadlockNotification')
	BEGIN
		PRINT 'Server event notification [DeadlockNotification] exists on server [' + @@SERVERNAME + '] and will be dropped';
		DROP EVENT NOTIFICATION DeadlockNotification
			ON SERVER
	END
ELSE
	BEGIN
		PRINT 'Server event notification [DeadlockNotification] does not exists on server [' + @@SERVERNAME + ']';
	END;
GO



