USE [DBA_ADMIN];
GO
ALTER QUEUE DeadlockNotificationQueue
WITH
ACTIVATION
(
	STATUS=ON,
	PROCEDURE_NAME = [ProcessDeadlocksReports],
	MAX_QUEUE_READERS = 1,
	EXECUTE AS OWNER
);
GO
/*
GO
ALTER QUEUE DeadlockNotificationQueue
WITH
ACTIVATION
(
	STATUS=ON
);
GO

ALTER QUEUE [DeadlockNotificationQueue] WITH STATUS = ON;
*/