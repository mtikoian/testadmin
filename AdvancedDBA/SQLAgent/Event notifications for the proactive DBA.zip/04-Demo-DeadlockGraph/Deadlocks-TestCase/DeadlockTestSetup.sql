/*
This script will create tables in the DBA_ADMIN database that are to be used 
for testing the deadlock Event Notification.
After completion please remove these tables.
*/
USE [DBA_ADMIN];
GO


IF OBJECT_ID('dbo.table1') IS NOT NULL
	BEGIN
		PRINT 'Dropping table dbo.table1 in database [' + db_name() + '] on server [' + @@SERVERNAME + ']';
		DROP TABLE [dbo].[table1];
	END
GO
PRINT 'Creating table table1';
CREATE TABLE [dbo].[table1] (col1 INT NOT NULL)
GO

IF OBJECT_ID('dbo.table2') IS NOT NULL
	BEGIN
		PRINT 'Dropping table dbo.table2 in database [' + db_name() + '] on server [' + @@SERVERNAME + ']';
		DROP TABLE [dbo].[table2];
	END
GO
PRINT 'Creating table table2';
CREATE TABLE table2 (col2 INT NOT NULL)
GO