USE [DBA_ADMIN];
GO

BEGIN TRAN
INSERT dbo.table1 ( col1 )
VALUES  ( 1 )

SELECT * FROM dbo.table2

--ROLLBACK
