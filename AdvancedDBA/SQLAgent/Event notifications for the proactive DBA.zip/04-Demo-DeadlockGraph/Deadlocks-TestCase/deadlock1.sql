USE [DBA_ADMIN];
GO

BEGIN TRAN BlockingTransaction1
	INSERT dbo.table2 ( col2 ) VALUES  ( 1 )

SELECT * FROM dbo.table1

--ROLLBACK
