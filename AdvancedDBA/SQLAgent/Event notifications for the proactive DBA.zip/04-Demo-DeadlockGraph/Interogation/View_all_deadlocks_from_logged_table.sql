USE [DBA_ADMIN];
GO
SELECT * FROM [dbo].[DeadlocksReports];
GO
SELECT * FROM [dbo].[DeadlocksPlans];
GO