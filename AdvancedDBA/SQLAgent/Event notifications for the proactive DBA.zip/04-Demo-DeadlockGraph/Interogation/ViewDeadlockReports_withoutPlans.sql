
USE [DBA_ADMIN];
GO
--ALL deadlock reports with no plans attached
SELECT * FROM [dbo].[DeadlocksReports] [dr]
	WHERE [dr].[deadlock_id] NOT IN (SELECT deadlock_id FROM [dbo].[DeadlocksPlans])
ORDER BY create_date DESC;
GO

