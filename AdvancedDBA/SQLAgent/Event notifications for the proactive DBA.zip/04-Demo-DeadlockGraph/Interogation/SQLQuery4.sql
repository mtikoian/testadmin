USE [DBA_ADMIN];
GO

DELETE FROM [dbo].[DeadlocksPlans];
DELETE FROM [dbo].[DeadlocksReports];

SELECT * FROM [dbo].[DeadlocksReports];
SELECT * FROM [dbo].[DeadlocksPlans];

