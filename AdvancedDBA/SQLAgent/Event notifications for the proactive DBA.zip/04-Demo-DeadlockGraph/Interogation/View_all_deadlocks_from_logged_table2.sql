USE [DBA_ADMIN];
GO
SELECT * FROM [dbo].[DeadlocksReports] ORDER by create_date DESC;
GO
SELECT * FROM [dbo].[DeadlocksPlans]
GO
/*
DELETE [dbo].[DeadlocksReports]
DBCC CHECKIDENT(DeadlocksReports , RESEED);
TRUNCATE TABLE [dbo].[DeadlocksPlans]
*/
--SELECT * FROM [sys].[databases];