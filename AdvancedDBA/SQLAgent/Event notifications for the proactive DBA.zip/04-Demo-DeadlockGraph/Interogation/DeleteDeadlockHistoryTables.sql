/*
Delete all data from the deadlock history tables.
*/
USE [DBA_ADMIN];
GO
DELETE [dbo].[DeadlocksPlans];
DELETE [dbo].[DeadlocksReports];
GO

