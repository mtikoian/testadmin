
DROP TABLE [dbo].[handles];
CREATE TABLE [dbo].[handles]
(
	 [deadlock_id] INT
	,[plan_handle] VARBINARY(64)
	,[sql_handle] VARBINARY(64)
);

INSERT INTO [dbo].[handles]
(
		[deadlock_id]
	,[plan_handle]
	,[sql_handle]
)
SELECT 
	d.deadlock_id
	,qs.plan_handle
	,qs.sql_handle
	,frame.value('xs:hexBinary(substring((@sqlhandle)[1],3))', 'varbinary(max)')
FROM 
	[dbo].[DeadlocksReports] d
CROSS APPLY 
	deadlock_graph.nodes('//frame') x (frame)
INNER JOIN 
	[sys].[dm_exec_query_stats] [qs]
ON 
	[qs].[sql_handle] = frame.value('xs:hexBinary(substring((@sqlhandle)[1],3))', 'varbinary(max)');

SELECT * FROM [dbo].[handles]

