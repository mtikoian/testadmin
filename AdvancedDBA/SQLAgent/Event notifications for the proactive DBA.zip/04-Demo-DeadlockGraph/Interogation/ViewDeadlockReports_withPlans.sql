USE [DBA_ADMIN];
GO
--ALL deadlock reports with plans attached
SELECT * FROM [dbo].[DeadlocksReports] [dr]
	WHERE [dr].[deadlock_id] IN (SELECT deadlock_id FROM [dbo].[DeadlocksPlans])
ORDER BY create_date DESC;
GO
