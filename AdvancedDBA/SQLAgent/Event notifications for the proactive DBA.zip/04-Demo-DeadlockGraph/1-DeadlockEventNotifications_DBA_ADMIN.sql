/*
This script is the first of 4 scripts used to set up event notifications for deadlocks.
The event notification system will send an email - See script 3.
So please make sure database mail is correctly set up before setting up event notifications for deadlocks.
CREATE DATABASE [DBA_ADMIN];
GO
*/

USE [master];
GO
/*
Set service broker on in the database.
*/
IF EXISTS (SELECT 1 FROM sys.databases WHERE [name] = 'DBA_ADMIN' AND is_broker_enabled = 0)
	BEGIN
		PRINT 'About to enable service broker in database [DBA_ADMIN]';
		ALTER DATABASE [DBA_ADMIN] SET ENABLE_BROKER
	END
ELSE
	BEGIN
		PRINT 'Service broker is enabled in database [DBA_ADMIN]';
	END
GO
/*
Switch to DBA_ADMIN database
*/
USE [DBA_ADMIN];
GO
/*
Create the service broker queue if it does not already exsist.
*/
IF NOT EXISTS (SELECT * FROM [sys].[service_queues] [sq] WHERE [sq].[name] = 'DeadlockNotificationQueue')
	BEGIN	
		PRINT 'QUEUE [DeadlockNotificationQueue] does not exist in database [' + db_name() + '] on Server [' + @@SERVERNAME + '] - about to create it';
		CREATE QUEUE [DeadlockNotificationQueue];
	END
ELSE
	BEGIN
		PRINT 'QUEUE [DeadlockNotificationQueue] already exists in database [' + db_name() + '] on Server [' + @@SERVERNAME + '] - and will not be created';
	END;
GO
/*
Create the service 'DeadlockNotificationService' on the previously created queue 'DeadlockNotificationQueue'
*/
IF NOT EXISTS (SELECT * FROM [DBA_ADMIN].[sys].[services] [S] WHERE [S].[name] = 'DeadlockNotificationService')
	BEGIN
		PRINT 'SERVICE [DeadlockNotificationService] does not exist in database [' + db_name() + '] - about to create this';
		CREATE SERVICE DeadlockNotificationService
			ON QUEUE DeadlockNotificationQueue
			([http://schemas.microsoft.com/SQL/Notifications/PostEventNotification]);
	END
ELSE
	BEGIN
		PRINT 'SERVICE [DeadlockNotificationService] already exists in database [' + db_name() + ']'
	END;
GO
/*
CREATE A ROUTE ON THAT SERVICE.
*/
IF NOT EXISTS (SELECT * FROM [sys].[routes] [R] WHERE [R].[name] = 'DeadlockNotificationRoute')
	BEGIN
		PRINT 'ROUTE [DeadlockNotificationRoute] does not exists in database [' + db_name() + '] on server [' + @@SERVERNAME + '] - about to create this.';
		CREATE ROUTE DeadlockNotificationRoute
			WITH SERVICE_NAME = 'DeadlockNotificationService',
			ADDRESS = 'LOCAL' ;
	END
ELSE
	BEGIN
		PRINT 'ROUTE [DeadlockNotificationRoute] already exists in database [' + db_name() + '] on server [' + @@SERVERNAME + ']';
	END;
GO
/*
Create the notification if it does not already exist.
*/
IF NOT EXISTS (SELECT * FROM [sys].[server_event_notifications] [sen] WHERE [sen].[name] = 'DeadlockNotification')
	BEGIN
		PRINT 'Server event notification [DeadlockNotification] does not exists on server [' + @@SERVERNAME + '] and will be created';
		CREATE EVENT NOTIFICATION DeadlockNotification
			ON SERVER
			WITH FAN_IN
			FOR DEADLOCK_GRAPH /*This is the event we are interested in*/
			TO SERVICE 'DeadlockNotificationService','current database';
	END
ELSE
	BEGIN
		PRINT 'Server event notification [DeadlockNotification] already exists on server [' + @@SERVERNAME + ']';
	END;
GO



