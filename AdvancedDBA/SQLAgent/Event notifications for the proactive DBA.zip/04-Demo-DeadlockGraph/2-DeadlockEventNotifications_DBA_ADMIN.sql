USE [DBA_ADMIN];
GO

/*
DROP TABLE [dbo].[DeadlocksPlans];
DROP TABLE [dbo].[DeadlocksReports];
*/

IF NOT EXISTS ( SELECT *
				FROM sys.tables
					WHERE OBJECT_ID = OBJECT_ID('dbo.DeadlocksReports') )
	BEGIN
		PRINT 'Creating "dbo.DeadlocksReports"';
		CREATE TABLE dbo.DeadlocksReports
		(
			 deadlock_id INT IDENTITY(1,1)
			,originalXML XML
			,deadlock_graph XML
			,create_date DATETIME CONSTRAINT [DF_MonitorDeadlocksReports_CreateDate] DEFAULT GETDATE()
			,created_by NVARCHAR(255) CONSTRAINT [DF_MonitorDeadlocksReports_CreateBy] DEFAULT SUSER_SNAME()
			,CONSTRAINT DF_MonitorDeadlocksReports PRIMARY KEY CLUSTERED (deadlock_id)
		);
		/*
		ALTER TABLE dbo.DeadlocksReports
			ADD CONSTRAINT DF_MonitorDeadlocksReports_CreateBy DEFAULT SUSER_SNAME() FOR created_by;
		ALTER TABLE dbo.DeadlocksReports
			ADD CONSTRAINT DF_MonitorDeadlocksReports_CreateDate DEFAULT GETDATE() FOR create_date; 
		*/
	END
ELSE
	BEGIN
		PRINT 'Table "dbo.DeadlocksReports" already exists';
	END
GO
IF NOT EXISTS ( SELECT *
					FROM sys.tables
						WHERE OBJECT_ID = OBJECT_ID('dbo.DeadlocksPlans') )
	BEGIN
		PRINT 'Creating "dbo.DeadlocksPlans"';
		CREATE TABLE [dbo].[DeadlocksPlans]
		(
			 deadlock_plan_id INT IDENTITY(1,1)
			,deadlock_id INT
			,sql_handle VARBINARY(64)
			,plan_handle VARBINARY(64)
			,query_plan XML
			,create_date DATETIME CONSTRAINT [DF_DeadlocksPlans_CreateDate] DEFAULT GETDATE()
			,created_by NVARCHAR(255) CONSTRAINT [DF_DeadlocksPlans_CreateBy] DEFAULT SUSER_SNAME()
			,CONSTRAINT PK_DeadlocksPlans PRIMARY KEY NONCLUSTERED (deadlock_plan_id)
		);
		CREATE CLUSTERED INDEX [CIX_DeadlocksPlans] ON dbo.[DeadlocksPlans] (deadlock_id, deadlock_plan_id);
		ALTER TABLE dbo.[DeadlocksPlans] WITH CHECK
		ADD CONSTRAINT [FK_DeadlocksPlans_DeadlocksReports] FOREIGN KEY(deadlock_id)
		REFERENCES dbo.[DeadlocksReports] (deadlock_id) ;
	END
ELSE
	BEGIN
		PRINT 'Table "dbo.DeadlocksPlans" already exists';
	END
GO
GO