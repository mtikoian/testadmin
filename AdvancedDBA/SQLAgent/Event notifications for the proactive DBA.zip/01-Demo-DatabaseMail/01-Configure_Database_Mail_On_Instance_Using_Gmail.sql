/*
Author :- Martin Catherall
Purpose :- To configure database mail on a particular instance of sql server 2005 / 2008
/****IMPORTANT - PLEASE READ***********/
Notes : - This script will delete all mail accounts and profiles on the server.
          A new account will be created and the current server name will be included in the account / profile name.
		  The script will send a test email.
		  Please change the variable "@test_email_address" appropriatly.
*/
use master
go
EXEC sp_configure 'show advanced options',1;
go
reconfigure with override;
go
EXEC sp_configure 'Database Mail XPs',1;
go
reconfigure;
go
--EXEC sp_configure 'SQL Mail XPs',0;
go
reconfigure;
go
EXEC sp_configure 'show advanced options',0;
go
reconfigure with override;
go
SET NOCOUNT ON
/*Delete any existing databases mail accounts / profiles in the database*/
USE [msdb];
GO
delete dbo.sysmail_principalprofile
delete dbo.sysmail_account
delete dbo.sysmail_profile
delete dbo.sysmail_profileaccount
delete dbo.sysmail_server
GO
USE [master];
GO
/*DECLARE VARIABLES*/
DECLARE @test_email_address varchar(128) -- MAKE SURE THAT THIS IS CORRECT ***Address test email will go to**
DECLARE @account_name sysname
DECLARE	@account_description nvarchar(256)
DECLARE	@email_address nvarchar(128)
DECLARE	@display_name nvarchar(128)
DECLARE @replyto_address nvarchar(128)
DECLARE @mailserver_name sysname
DECLARE @mailserver_port int
DECLARE @account_id int
DECLARE @profile_name sysname
DECLARE @profile_description nvarchar(256)
DECLARE @profile_id int
/*SET VARIABLES*/
SET @test_email_address = 'SQLSaturday296Notifications@gmail.com'
SET @account_name = 'DBA mail account on [' + @@servername + ']';
SET	@account_description = 'Mail account for Database Mail on [' + @@servername + ']';
SET	@email_address = 'SQLSaturday296Notifications@gmail.com'
SET	@display_name = 'DBA account for [' + @@servername + ']';
SET @replyto_address = 'SQLSaturday296Notifications@gmail.com'
SET @mailserver_name = 'smtp.gmail.com'
SET @mailserver_port = 587
SET @profile_name = 'Mail profile for [' + @@servername + ']';
SET @profile_description = 'Profile used for database mail on ' + @@servername
PRINT '@profile_name is [' + @profile_name + ']';

EXECUTE msdb.dbo.sysmail_add_account_sp
    @account_name = @account_name,
    @description = @account_description,
    @email_address = @email_address,
    @display_name = @display_name,
	@replyto_address = @replyto_address,
    @mailserver_name = @mailserver_name,
	@port = @mailserver_port,
	@username = 'SQLSaturday296Notifications@gmail.com',
	@password = '!ChristchurchSQL!',
	@enable_ssl = 1,
	@account_id = @account_id OUTPUT

EXECUTE msdb.dbo.sysmail_add_profile_sp
       @profile_name = @profile_name,
       @description = @profile_description,
	   @profile_id = @profile_id OUTPUT

EXECUTE msdb.dbo.sysmail_add_profileaccount_sp
    @profile_name = @profile_name,
    @account_name = @account_name,
    @sequence_number = 1

Print '/*SCRIPT TO DELETE DATABASE MAIL ACCOUNT AND PROFILE*/'
Print '--Account id is ' + cast(@account_id as varchar)
Print '--To remove run the following'
Print 'EXECUTE msdb.dbo.sysmail_delete_account_sp @account_id=' + cast(@account_id as varchar)
Print '--Profile id is ' + cast(@profile_id as varchar)
Print '--To remove run the following'
Print 'EXECUTE msdb.dbo.sysmail_delete_profile_sp @profile_id=' + cast(@profile_id as varchar)
PRINT '/*****END SCRIPT TO DELETE DATABASE MAIL ACCOUNT AND PROFILE*****/'

EXECUTE msdb.dbo.sysmail_add_principalprofile_sp
    @profile_name = @profile_name,
    @principal_name = 'public',
    @is_default = 1 ;


declare @bodyMessage varchar(100)
set @bodyMessage = 'Server :'+@@servername+ ' Test Email'
EXEC msdb.dbo.sp_send_dbmail	
	@profile_name = @profile_name,
	@recipients=@test_email_address,
    @subject = 'Configured mail via gmail',
    @body = @bodyMessage,
    @body_format = 'HTML';
GO
--SELECT * FROM msdb.dbo.sysmail_event_log
SET NOCOUNT OFF;
GO



