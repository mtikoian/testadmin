USE [master]
GO
/*
Check if the server trigger exists and create an empty stub if it does not.
This means that the trigger then only ever needs to be altered.
We only need to keep one script that both creates and alters te trigger.
*/
IF NOT EXISTS (SELECT * FROM [sys].[server_triggers] [st] WHERE [st].[name] = 'create_drop_database_server_trigger')
	BEGIN
		PRINT 'Server Trigger "create_drop_database_server_trigger" does not exist on [' + @@SERVERNAME + '] and will be created';
		EXECUTE ('CREATE TRIGGER create_drop_database_server_trigger 
						ON ALL SERVER FOR
							CREATE_DATABASE , DROP_DATABASE 
						AS
						BEGIN
							SELECT @@SERVERNAME;
						END;')
	END
ELSE
	BEGIN
		PRINT 'Server Trigger "create_drop_database_server_trigger" already exist on [' + @@SERVERNAME + '] and will be created';
	END
GO
/*
At this point the server trigger already exists so it only has to be altered.
*/
ALTER TRIGGER [create_drop_database_server_trigger]
ON ALL SERVER --WITH EXECUTE AS 'SA'
FOR CREATE_DATABASE , DROP_DATABASE
AS
BEGIN
	DECLARE @EVENTDATA XML = EVENTDATA(); /*Populate a varaible so we can use in email*/
	/*Just convert the event data to text so we can send it in an email*/
	DECLARE @EVENTDATATEXT NVARCHAR(MAX) = CAST (@EVENTDATA AS NVARCHAR(MAX));
	DECLARE @EmailSubject NVARCHAR(100) = 'Database event on SQL INSTANCE [' + @@SERVERNAME + '] - From server trigger';
	/*Insert into table*/
	INSERT INTO [DBA_ADMIN].[dbo].[DatabaseObjectReports] (event_data) VALUES(@EVENTDATA);
	/*Send email notifying event has taken place.
	Some hard coded stuff here - in reality we'd be a bit more dynamic that this
	*/
	EXEC msdb.dbo.sp_send_dbmail 
		@profile_name = 'Mail profile for [LAPSTER]',
		@recipients='SQLSaturday296Notifications@gmail.com',/*Change this*/
		@subject = @EmailSubject,
		@body = @EVENTDATATEXT,
		@body_format = 'TEXT' ;
		--@body_format = 'HTML' ; /*Not so great to send xml in a HTML based email.*/
END;
GO
/*
Ensure that the server trigger is enabled.
ENABLE TRIGGER [create_drop_database_server_trigger] ON ALL SERVER
GO
*/

/*
View output
*/

SELECT * FROM [sys].[server_triggers] [st] WHERE [st].[name] = 'create_drop_database_server_trigger';
GO