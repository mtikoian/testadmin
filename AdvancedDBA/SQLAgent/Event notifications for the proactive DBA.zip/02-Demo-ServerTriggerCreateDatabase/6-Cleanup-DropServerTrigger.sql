USE [master]
GO
/*
Check if the server trigger exists and create an empty stub if it does not.
This means that the trigger then only ever needs to be altered.
We only need to keep one script that both creates and alters te trigger.
*/
IF NOT EXISTS (SELECT * FROM [sys].[server_triggers] [st] WHERE [st].[name] = 'create_drop_database_server_trigger')
	BEGIN
		PRINT 'SERVER TRIGER "create_drop_database_server_trigger" does not exist on instance [' + @@SERVERNAME + ']';
	END
ELSE
	BEGIN
		PRINT 'Server Trigger "create_drop_database_server_trigger" exist on [' + @@SERVERNAME + '] and will be dropped';
		DROP TRIGGER create_drop_database_server_trigger ON ALL SERVER;
		PRINT 'Server Trigger "create_drop_database_server_trigger" has been dropped on server [' + @@SERVERNAME + ']';
	END
GO