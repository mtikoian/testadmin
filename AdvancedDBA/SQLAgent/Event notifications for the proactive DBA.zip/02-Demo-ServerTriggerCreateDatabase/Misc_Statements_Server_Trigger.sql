USE [DBA_ADMIN];
GO


DELETE [dbo].[DatabaseObjectReports];

SELECT * FROM [dbo].[DatabaseObjectReports] [DOR] order by create_date desc
GO

/*
INSERT INTO [DBA_ADMIN_SQLSAT296MELBOURNE].[dbo].[DatabaseObjectReports] (event_data) VALUES('<Test></Test>');
GO
*/
	