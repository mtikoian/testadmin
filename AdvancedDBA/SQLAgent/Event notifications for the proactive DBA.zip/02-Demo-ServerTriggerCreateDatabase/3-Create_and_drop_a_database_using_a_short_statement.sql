/*
Create a new database - dropping the original one if it already exists.
*/
USE [tempdb];
GO
/*
Drop the database first if it exists.
*/
IF EXISTS (SELECT * FROM [sys].[databases] [dbs] WHERE [dbs].[name] = 'SQLSAT_Test')
BEGIN
	PRINT 'Database SQLSAT_Test already exists - about to drop it';
	ALTER DATABASE [SQLSAT_Test] SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
	DROP DATABASE [SQLSAT_Test];
	PRINT 'Database SQLSAT_Test dropped successfully';
END;
GO
/*
Now we'll just use a simple statement to create the database again.
*/
CREATE DATABASE [SQLSAT_Test];
GO

