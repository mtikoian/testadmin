USE [tempdb];
GO
IF EXISTS (SELECT * FROM [sys].[databases] [dbs] WHERE [dbs].[name] = 'SQLSAT_Test')
BEGIN
	PRINT 'Database SQLSAT_Test already exists - about to drop it';
	ALTER DATABASE [SQLSAT_Test] SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
	DROP DATABASE [SQLSAT_Test];
	PRINT 'Database SQLSAT_Test dropped successfully';
END;
GO
CREATE DATABASE SQLSAT_Test
ON
PRIMARY
(
	NAME = 'SQLSAT_Test_Primary',
	FILENAME = 'C:\SQLSaturday296Melboune\Databases\Data\SQLSAT_Test_Primary.mdf',
	SIZE = 10 MB,
	MAXSIZE = UNLIMITED,
	FILEGROWTH = 10 MB
),
FILEGROUP SQLSAT_Test_FG1
(
	NAME = 'MartinTest_File1',
	FILENAME = 'C:\SQLSaturday296Melboune\Databases\Data\SQLSAT_Test_File1.ldf',
	SIZE = 10 MB,
	MAXSIZE = UNLIMITED,
	FILEGROWTH = 10 MB
)
LOG ON
(
	NAME = 'SQLSAT_Test_Log',
	FILENAME = 'C:\SQLSaturday296Melboune\Databases\Log.ldf',
	SIZE = 1 MB,
	MAXSIZE = UNLIMITED,
	FILEGROWTH = 1 MB
);
GO


--SELECT * FROM [DBA_ADMIN_SQLSAT296MELBOURNE].[dbo].[DatabaseObjectReports] ORDER BY create_date DESC;

--DELETE FROM [DBA_ADMIN_SQLSAT296MELBOURNE].[dbo].[DatabaseObjectReports];