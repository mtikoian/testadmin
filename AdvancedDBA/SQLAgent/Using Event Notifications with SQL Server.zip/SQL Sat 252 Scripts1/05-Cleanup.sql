--CLEANUP

USE [_dba]
GO

DROP PROCEDURE dbo.usp_get_deadlock_graph
GO

DROP PROCEDURE dbo.usp_get_error_info
GO

DROP TABLE dbo.deadlock_log
GO

DROP TABLE dbo.error_info
GO


DROP EVENT NOTIFICATION myEN ON SERVER
GO

DROP ROUTE myRoute
GO

DROP SERVICE myService
GO

DROP QUEUE myQueue
GO

EXEC sp_configure 'show advanced options', 1
GO
RECONFIGURE
GO

EXEC sp_configure 'xp_cmdshell', 1
GO
RECONFIGURE
GO

EXEC master..xp_cmdshell 'del D:\MSSQL\Data\*.cer'
GO

EXEC sp_configure 'xp_cmdshell', 1
GO
RECONFIGURE
GO

EXEC sp_configure 'show advanced options', 0
GO
RECONFIGURE
GO


USE msdb
GO

DROP USER sendDBMailUser
GO

DROP CERTIFICATE sendDBMailCertificate
GO

USE master
GO

DROP DATABASE [_dba]
GO

