USE tempdb
GO

CREATE TABLE table2 (col2 INT NOT NULL)
GO


BEGIN TRAN
INSERT dbo.table2 ( col2 )
VALUES  ( 1 )

SELECT * FROM dbo.table1

ROLLBACK
