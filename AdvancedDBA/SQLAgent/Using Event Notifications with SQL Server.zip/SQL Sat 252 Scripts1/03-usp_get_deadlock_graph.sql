--	CREATE A STORED PROCEDURE TO PROCESS THE EVENTS

--prerequisite items first
USE _dba
GO

IF OBJECT_ID('dbo.deadlock_log') IS NOT NULL 
    BEGIN 
        DROP TABLE dbo.deadlock_log
    END;
GO

CREATE TABLE dbo.deadlock_log
    ( id INT IDENTITY(1,1) CONSTRAINT pk_deadlock_log PRIMARY KEY CLUSTERED ,
      post_time DATETIME NOT NULL ,
      deadlock_graph XML NOT NULL
    );
GO





IF OBJECT_ID('dbo.error_info') IS NOT NULL 
    BEGIN 
        DROP TABLE dbo.error_info
    END
GO

CREATE TABLE dbo.error_info
    (
     [event_time] DATETIME NULL
    , [error_number] INT NULL
    , [error_severity] INT NULL
    , [error_state] INT NULL
    , [error_procedure] NVARCHAR(200) NULL
    , [error_line] INT NULL
    , [error_message] NVARCHAR(4000) NULL
    )
GO

CREATE CLUSTERED INDEX ix_error_info ON dbo.error_info (event_time)
GO






IF OBJECT_ID('dbo.usp_get_error_info', 'P') IS NOT NULL 
    DROP PROCEDURE dbo.usp_get_error_info ;
GO

CREATE PROCEDURE dbo.usp_get_error_info WITH ENCRYPTION
AS 
    IF ERROR_NUMBER() IS NULL 
        RETURN ;

    INSERT  dbo.error_info
            (
              event_time,
              [error_number],
              [error_severity],
              [error_state],
              [error_procedure],
              [error_line],
              [error_message]
            )
            SELECT  GETDATE(),
                    ERROR_NUMBER() AS ErrorNumber,
                    ERROR_SEVERITY() AS ErrorSeverity,
                    ERROR_STATE() AS ErrorState,
                    ERROR_PROCEDURE() AS ErrorProcedure,
                    ERROR_LINE() AS ErrorLine,
                    ERROR_MESSAGE() AS ErrorMessage ;
GO





USE [_dba] ;
GO

IF OBJECT_ID('dbo.usp_get_deadlock_graph', 'P') IS NOT NULL 
    BEGIN
        DROP PROCEDURE dbo.usp_get_deadlock_graph
    END ;
GO

CREATE PROCEDURE dbo.usp_get_deadlock_graph
WITH EXECUTE AS OWNER
AS

    DECLARE @conversation_handle UNIQUEIDENTIFIER
      , @message_body XML
      , @message_type_name NVARCHAR(128)
      , @deadlock_graph XML
      , @post_time DATETIME
      , @deadlock_id INT
    BEGIN TRY
        BEGIN TRANSACTION
        WAITFOR ( RECEIVE TOP ( 1 ) @conversation_handle = conversation_handle
		, @message_body = CAST(message_body AS XML)
		, @message_type_name = message_type_name FROM dbo.myQueue )

        IF ( @message_type_name = 'http://schemas.microsoft.com/SQL/Notifications/EventNotification'
             AND @message_body.exist('(/EVENT_INSTANCE/TextData/deadlock-list)') = 1
           ) 
            BEGIN
                SELECT  @deadlock_graph = @message_body.query('(/EVENT_INSTANCE/TextData/deadlock-list)')
                      , @post_time = @message_body.value('(/EVENT_INSTANCE/PostTime)[1]', 'datetime') ;

                INSERT  dbo.deadlock_log
                        (
                          post_time
                        , deadlock_graph
                        )
                VALUES  (
                          @post_time
                        , @deadlock_graph
                        ) ;

                SELECT  @deadlock_id = SCOPE_IDENTITY() ;
		
                BEGIN TRY
                    DECLARE @subject NVARCHAR(255) = 'A deadlock occurred on ' + @@SERVERNAME
                      , @msgbody NVARCHAR(MAX) = 'A deadlock occurred at '
                        + CONVERT(VARCHAR(50), @post_time, 120)
                        + '. See attached xdl-file for deadlock graph and query _dba.dbo.deadlock_log for the xml of the deadlock'
                      , @myquery NVARCHAR(MAX) = 'SET NOCOUNT ON; SELECT deadlock_graph FROM _dba.dbo.deadlock_log WITH (NOLOCK) WHERE id = ' + CAST(@deadlock_id AS VARCHAR(10))
                      , @attachment_filename NVARCHAR(255) = @@SERVERNAME + '_' + CAST(@deadlock_id AS VARCHAR(10)) + '.xdl' ;
                      
                    EXEC msdb.dbo.sp_send_dbmail @profile_name = 'Gmail'
                        , @recipients = 'brent.mccracken@gmail.com'
                        , @subject = @subject
                        , @body = @msgbody
                        , @query = @myquery
                        , @attach_query_result_as_file = 1
                        , @query_attachment_filename = @attachment_filename
                        , @query_result_header = 0
                        , @query_result_width = 32767
                        , @query_no_truncate = 1 ;
                END TRY
                BEGIN CATCH
                    EXEC dbo.usp_get_error_info
                END CATCH
            END
        ELSE -- Not an event notification with deadlock-list
            END CONVERSATION @conversation_handle
        COMMIT TRAN
    END TRY
    BEGIN CATCH
        ROLLBACK TRAN
    END CATCH ;
GO



--	EXECUTE STORED PROCEDURE
EXEC dbo.usp_get_deadlock_graph


--	CHECK THE QUEUE
SELECT * FROM myQueue



SELECT * FROM _dba.dbo.deadlock_log

SELECT * FROM dbo.error_info


















--	fix up the script to allow to sendmail




--	automate the collection of events



USE [_dba];
GO

ALTER QUEUE dbo.myQueue
WITH
STATUS = ON,
ACTIVATION (
	PROCEDURE_NAME = dbo.usp_get_deadlock_graph,
	STATUS = ON,
	MAX_QUEUE_READERS = 1,
	EXECUTE AS OWNER ) ;
GO


SELECT * FROM myQueue


SELECT * FROM msdb.sys.transmission_queue


SELECT * FROM dbo.deadlock_log
SELECT * FROM dbo.error_info
