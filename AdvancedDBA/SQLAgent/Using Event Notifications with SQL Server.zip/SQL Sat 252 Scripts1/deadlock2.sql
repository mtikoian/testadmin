USE tempdb
GO

CREATE TABLE table1 (col1 INT NOT NULL)
GO


BEGIN TRAN
INSERT dbo.table1 ( col1 )
VALUES  ( 1 )

SELECT * FROM dbo.table2

ROLLBACK
