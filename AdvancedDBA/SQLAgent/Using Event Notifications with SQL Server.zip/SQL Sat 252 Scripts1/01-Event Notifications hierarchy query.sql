--this recursive CTE is taken from SQL2012 Books Online

WITH    DirectReports ( name, parent_type, type, level, sort )
          AS ( SELECT   CONVERT(VARCHAR(255), type_name) ,
                        parent_type ,
                        type ,
                        1 ,
                        CONVERT(VARCHAR(255), type_name)
               FROM     sys.trigger_event_types
               WHERE    parent_type IS NULL
               UNION ALL
               SELECT   CONVERT(VARCHAR(255), REPLICATE('|   ', level) + e.type_name) ,
                        e.parent_type ,
                        e.type ,
                        level + 1 ,
                        CONVERT (VARCHAR(255), RTRIM(sort) + '|   ' + e.type_name)
               FROM     sys.trigger_event_types AS e
                        INNER JOIN DirectReports AS d ON e.parent_type = d.type
             )
    SELECT  parent_type ,
            type ,
            name
    FROM    DirectReports
    ORDER BY sort;