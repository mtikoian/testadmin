USE master
GO

IF DB_ID('_dba') IS NOT NULL
BEGIN
	ALTER DATABASE [_dba] SET SINGLE_USER WITH ROLLBACK IMMEDIATE
	DROP DATABASE [_dba]	
END

GO

CREATE DATABASE _dba ON PRIMARY (
NAME = dba_sys, FILENAME = 'd:\mssql\data\dba_sys.mdf', SIZE = 100, MAXSIZE = UNLIMITED, FILEGROWTH = 100),
    FILEGROUP DATA DEFAULT (
NAME = dba_data, FILENAME = 'd:\mssql\data\dba_data.ndf', SIZE = 1000, MAXSIZE = UNLIMITED, FILEGROWTH = 1000)
    LOG ON (
NAME = dba_log, FILENAME = 'e:\mssql\data\dba_log.ldf', SIZE = 200, MAXSIZE = UNLIMITED, FILEGROWTH = 200)
GO

ALTER AUTHORIZATION ON DATABASE::_dba TO sa
GO

ALTER DATABASE _dba SET RECOVERY SIMPLE
GO

SELECT name, service_broker_guid FROM master.sys.databases WHERE name = '_dba'

ALTER DATABASE _dba SET ENABLE_BROKER
GO












USE _dba
GO

--	CREATE A QUEUE
CREATE QUEUE dbo.myQueue
--	SELECT * FROM sys.service_queues











--	CREATE A SERVICE ON THE QUEUE THAT REFERENCES THE EVENT NOTIFICATIONS CONTRACT.
CREATE SERVICE myService AUTHORIZATION dbo 
	ON QUEUE myQueue ([http://schemas.microsoft.com/SQL/Notifications/PostEventNotification])
--	SELECT * FROM sys.services










--	CREATE A ROUTE FOR THE SERVICE
CREATE ROUTE myRoute AUTHORIZATION dbo 
	WITH SERVICE_NAME = 'myService',
	ADDRESS = 'LOCAL'
--	SELECT * FROM sys.routes









--	CREATE EVENT NOTIFICATION FOR LOGIN EVENTS
CREATE EVENT NOTIFICATION myEN
	ON SERVER -- ON DATABASE
	WITH FAN_IN
	FOR DEADLOCK_GRAPH
	TO SERVICE 'myService', 'FAE29FEA-F109-4880-8226-2214D0432B7F'--get broker id from sys.databases
--	SELECT * FROM sys.server_event_notifications
--	SELECT name, service_broker_guid FROM master.sys.databases WHERE name = '_dba'









--	CREATE AN EVENT TO FIRE THE NOTIFICATION


--	SEE THE EVENT ON THE QUEUE
SELECT * FROM myQueue




--	READ THE DEADLOCK PROPERLY
SELECT CAST(message_body AS xml) FROM myQueue
SELECT CAST(message_body AS NVARCHAR(MAX)) FROM myQueue




--	PROCESS THE EVENT OFF THE QUEUE
 RECEIVE TOP ( 1 ) CAST(message_body AS xml)
        FROM _dba.dbo.myQueue




--	CHANGE THE STATE OF THE QUEUE TO SHOW WHERE THE MESSAGE IS
ALTER QUEUE myQueue WITH STATUS = OFF



--	CREATE AN EVENT TO FIRE THE NOTIFICATION




--	CHECK THE QUEUE AGAIN
SELECT * FROM myQueue


--	LOOK AT WAITING EVENTS
SELECT * FROM msdb.sys.transmission_queue




--	TURN THE QUEUE BACK ON AND SEE THE MESSAGES FLOW AGAIN
ALTER QUEUE myQueue WITH STATUS = ON




--	SEE THE EVENT ON THE QUEUE
SELECT * FROM myQueue



--	PROCESS THE EVENTS OFF THE QUEUE
 RECEIVE TOP ( 1 ) CAST(message_body AS xml)
        FROM _dba.dbo.myQueue


--	CREATE A STORED PROCEDURE TO PROCESS THE EVENTS

