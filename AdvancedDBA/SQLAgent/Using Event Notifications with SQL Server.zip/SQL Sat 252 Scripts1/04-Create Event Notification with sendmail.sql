USE _dba ;
GO

CREATE CERTIFICATE sendDBMailCertificate ENCRYPTION BY PASSWORD = 'Pa$$w0rd1' WITH SUBJECT = 'Certificate for signing usp_get_deadlock_graph to call sp_send_dbmail' ;
GO



ADD SIGNATURE TO OBJECT::usp_get_deadlock_graph BY CERTIFICATE sendDBMailCertificate WITH PASSWORD = 'Pa$$w0rd1';
GO


BACKUP CERTIFICATE sendDBMailCertificate TO FILE = 'D:\mssql\data\sendDBMailCertificate.cer' ;
GO


USE [msdb]
GO


CREATE CERTIFICATE sendDBMailCertificate FROM FILE = 'D:\mssql\data\sendDBMailCertificate.cer';
GO


CREATE USER sendDBMailUser FROM CERTIFICATE sendDBMailCertificate


GRANT AUTHENTICATE TO sendDBMailUser


EXEC msdb.dbo.sp_addrolemember @rolename = 'DatabaseMailUserRole', @membername = 'sendDBMailUser';


