USE master
GO
IF ( SELECT DB_ID('EventLogging')) IS NOT NULL 
    BEGIN
        DROP DATABASE EventLogging
    END
GO

CREATE DATABASE EventLogging ON PRIMARY 
(NAME = EventLogging_sys, FILENAME = 'D:\MSSQL\DATA\EventLogging_sys.MDF', SIZE = 100, MAXSIZE = UNLIMITED, FILEGROWTH = 100),
FILEGROUP DATA DEFAULT
(NAME = EventLogging_data, FILENAME = 'D:\MSSQL\DATA\EventLogging_data.NDF', SIZE = 5000, MAXSIZE = UNLIMITED, FILEGROWTH = 1000)
LOG ON 
(NAME = EventLogging_log, FILENAME = 'E:\MSSQL\DATA\EventLogging_log.LDF', SIZE = 1000, MAXSIZE = UNLIMITED, FILEGROWTH = 1000)
GO

ALTER DATABASE EventLogging SET ENABLE_BROKER;
GO
ALTER DATABASE EventLogging SET RECOVERY SIMPLE
GO
ALTER AUTHORIZATION ON DATABASE::EventLogging TO sa
GO



USE MASTER
GO

-- SELECT * FROM sys.symmetric_keys
CREATE MASTER KEY ENCRYPTION BY PASSWORD = 'Pa$$w0rd1'
-- DROP MASTER KEY
GO

-- SELECT * FROM sys.certificates
CREATE CERTIFICATE EventNotificationCert WITH SUBJECT = 'Service Broker certificate for Transport Security', EXPIRY_DATE = '20201231'
-- DROP CERTIFICATE EventNotificationCert
GO


IF NOT EXISTS ( SELECT  *
                FROM    sys.server_principals
                WHERE   name = 'endpoint_owner' ) --create login for ownership of endpoint so it is not a person's login
    BEGIN
        CREATE LOGIN endpoint_owner WITH PASSWORD = 'Pa$$w0rd1' --same password for all endpoints
    END
-- DROP LOGIN endpoint_owner
GO

IF NOT EXISTS ( SELECT  *
                FROM    sys.endpoints
                WHERE   NAME = 'SB_Endpoint' ) 
    BEGIN
        CREATE ENDPOINT SB_Endpoint AUTHORIZATION endpoint_owner STATE = STARTED AS TCP ( LISTENER_PORT = 4022 ) FOR SERVICE_BROKER ( AUTHENTICATION = CERTIFICATE EventNotificationCert, ENCRYPTION = SUPPORTED)--DISABLED)
    END
-- DROP ENDPOINT SB_Endpoint
GO


GRANT CONNECT ON ENDPOINT::SB_Endpoint TO PUBLIC
--REVOKE CONNECT ON ENDPOINT::SB_Endpoint FROM PUBLIC
GO

USE EventLogging
GO

--  Create a service broker queue to hold the events
IF NOT EXISTS ( SELECT  *
                FROM    sys.service_queues
                WHERE   name = 'TargetServerLevelEventNotificationQueue' ) 
    BEGIN
        CREATE QUEUE dbo.TargetServerLevelEventNotificationQueue ON [DEFAULT]
    END
-- DROP QUEUE dbo.TargetServerLevelEventNotificationQueue
GO


--  Create a service broker service to receive the events
IF NOT EXISTS ( SELECT  *
                FROM    sys.services
                WHERE   name = 'TargetServerLevelEventNotificationService' ) 
    BEGIN
        CREATE SERVICE TargetServerLevelEventNotificationService AUTHORIZATION dbo
        ON QUEUE dbo.TargetServerLevelEventNotificationQueue ([http://schemas.microsoft.com/SQL/Notifications/PostEventNotification])
    END
-- DROP SERVICE [TargetServerLevelEventNotificationService]
GO

GRANT SEND ON SERVICE::TargetServerLevelEventNotificationService TO PUBLIC
GO


select service_broker_guid from sys.databases where database_id = db_id('EventLogging')
select service_broker_guid from sys.databases where database_id = db_id('msdb')

 
-- Create this in the Target DB, not MSDB.
-- Get MSDB service_broker_guid from initiator
-- one route required for each instance
USE EventLogging
GO
IF NOT EXISTS ( SELECT  *
                FROM    sys.routes
                WHERE   name = 'SQLSAT1_ReturnRoute' ) 
    BEGIN
        CREATE ROUTE SQLSAT1_ReturnRoute WITH
        SERVICE_NAME = 'http://schemas.microsoft.com/SQL/Notifications/EventNotificationService', 
        BROKER_INSTANCE = 'F4C0E214-7F04-43E5-93AE-680575F593D8', --needs msdb guid at source
        ADDRESS = 'TCP://SQLSAT1:4022' --this will be the netbios name of your server
    END
-- DROP ROUTE SQLSAT1_ReturnRoute
GO



SELECT service_broker_guid FROM sys.databases WHERE database_id = DB_ID('EventLogging') --49D97E15-6F44-4256-8294-8F29074346DB
GO


SELECT * FROM TargetServerLevelEventNotificationQueue
SELECT * FROM sys.transmission_queue
SELECT * FROM msdb.sys.transmission_queue

SELECT * FROM sys.routes
SELECT * FROM msdb.sys.routes

SELECT * FROM sys.conversation_groups
SELECT * FROM sys.conversation_endpoints

SELECT * FROM msdb.sys.conversation_groups
SELECT * FROM msdb.sys.conversation_endpoints

receive top (1) cast(message_body as xml) from TargetServerLevelEventNotificationQueue


/***********************************************************************************/
--						DATABASE OBJECT CREATION
/***********************************************************************************/

USE EventLogging
GO

IF TYPE_ID('SSWNAMETYPE') IS NULL
    BEGIN
        CREATE TYPE SSWNAMETYPE FROM VARCHAR(128) NOT NULL
    END
-- DROP TYPE SSWNAMETYPE  
GO


IF TYPE_ID('PATHTYPE') IS NULL 
    BEGIN
        CREATE TYPE PATHTYPE FROM VARCHAR(257) NOT NULL
    END
-- DROP TYPE PATHTYPE
GO


IF OBJECT_ID('ServerLevelEvents') IS NULL 
    BEGIN
        CREATE TABLE dbo.ServerLevelEvents
            (
              ID INT IDENTITY(1,1) NOT NULL
            , EventType SSWNAMETYPE
            , PostTime DATETIME NOT NULL
            , SPID INT NOT NULL
            , ServerName PATHTYPE
            , LoginName PATHTYPE
            , ObjectName SSWNAMETYPE
            , ObjectType SSWNAMETYPE
            , DefaultLanguage SSWNAMETYPE
            , DefaultDatabase SSWNAMETYPE
            , LoginType SSWNAMETYPE
            , SID VARBINARY(85) NOT NULL
            , SetOptions VARCHAR(200) NOT NULL
            , CommandText VARCHAR(4000) NULL
            )
    END
-- DROP TABLE dbo.ServerLevelEvents
GO
CREATE CLUSTERED INDEX ix_ServerLevelEvents ON dbo.ServerLevelEvents (ID) ON DATA
GO


IF OBJECT_ID('LoggedEventsXML') IS NULL 
    BEGIN
        CREATE TABLE dbo.LoggedEventsXML
            (
              ID INT IDENTITY(1,1) NOT NULL
            , EventType SSWNAMETYPE
            , PostTime DATETIME NOT NULL
            , [EventData] XML NOT NULL
            )
    END
-- DROP TABLE dbo.LoggedEventsXML  
GO
CREATE CLUSTERED INDEX ix_LoggedEventsXML ON dbo.LoggedEventsXML (ID) ON DATA
GO

-- stored procedure to process messages
CREATE PROCEDURE dbo.LogEvents
AS 
    SET NOCOUNT ON ;

    DECLARE @message_body XML
      , @message_type_name NVARCHAR(256)
      , @dialog UNIQUEIDENTIFIER ;

--  This procedure continues to process messages in the queue until the
--  queue is empty.

    WHILE ( 1 = 1 ) 
        BEGIN
            BEGIN TRANSACTION ;

    -- Receive the next available message

            WAITFOR (
        RECEIVE TOP(1) -- just handle one message at a time
            @message_type_name = message_type_name,  --the type of message received
            @message_body = message_body,      -- the message contents
            @dialog = conversation_handle    -- the identifier of the dialog this message was received on
            FROM TargetServerLevelEventNotificationQueue
    ), TIMEOUT 2000 ; -- if the queue is empty for two seconds, give up and go away

   -- If RECEIVE did not return a message, roll back the transaction
   -- and break out of the while loop, exiting the procedure.

            IF ( @@ROWCOUNT = 0 ) 
                BEGIN
                    ROLLBACK TRANSACTION ;
                    BREAK ;
                END ;

   -- Check to see if the message is an end dialog message.

            IF ( @message_type_name = 'http://schemas.microsoft.com/SQL/ServiceBroker/EndDialog' ) 
                BEGIN
                    PRINT 'End Dialog received for dialog # ' + CAST(@dialog AS NVARCHAR(40)) ;
                    END CONVERSATION @dialog ;
                END ;
            ELSE 
                BEGIN
    -- Extract the event information using XQuery.
                    INSERT  INTO [dbo].[ServerLevelEvents]
                            ( EventType
                            , PostTime
                            , SPID
                            , ServerName
                            , LoginName
                            , ObjectName
                            , ObjectType
                            , DefaultLanguage
                            , DefaultDatabase
                            , LoginType
                            , SID
                            , SetOptions
                            , CommandText
                            )
                    VALUES  ( CAST(@message_body.query('/EVENT_INSTANCE/EventType/text()') AS VARCHAR(128))
                            , CAST(CAST(@message_body.query('/EVENT_INSTANCE/PostTime/text()') AS VARCHAR(50)) AS DATETIME)
                            , CAST(CAST(@message_body.query('/EVENT_INSTANCE/SPID/text()') AS VARCHAR(20)) AS INT)
                            , CAST(@message_body.query('/EVENT_INSTANCE/ServerName/text()') AS VARCHAR(257))
                            , CAST(@message_body.query('/EVENT_INSTANCE/LoginName/text()') AS VARCHAR(257))
                            , CAST(@message_body.query('/EVENT_INSTANCE/ObjectName/text()') AS VARCHAR(128))
                            , CAST(@message_body.query('/EVENT_INSTANCE/ObjectType/text()') AS VARCHAR(128))
                            , CAST(@message_body.query('/EVENT_INSTANCE/DefaultLanguage/text()') AS VARCHAR(128))
                            , CAST(@message_body.query('/EVENT_INSTANCE/DefaultDatabase/text()') AS VARCHAR(128))
                            , CAST(@message_body.query('/EVENT_INSTANCE/LoginType/text()') AS VARCHAR(128))
                            , CAST(@message_body.query('/EVENT_INSTANCE/SID/text()') AS VARBINARY(85))
                            , CAST(@message_body.query('/EVENT_INSTANCE/TSQLCommand/SetOptions/text()') AS VARCHAR(200))
                            --, CAST(@message_body.query('/EVENT_INSTANCE/TSQLCommand/CommandText/text()') AS VARCHAR(4000))
                            , REPLACE(CAST(@message_body.query('/EVENT_INSTANCE/TSQLCommand/CommandText/text()') AS VARCHAR(max)), '&#x0D', '')
                            ) ;

    -- Insert the message body as XML into the loggedEventsXML table
                    INSERT  INTO [dbo].[LoggedEventsXML]
                            ( EventType
                            , PostTime
                            , [EventData]
                            )
                    VALUES  ( CAST(@message_body.query('/EVENT_INSTANCE/EventType/text()') AS VARCHAR(256))
                            , CAST(CAST(@message_body.query('/EVENT_INSTANCE/PostTime/text()') AS VARCHAR(50)) AS DATETIME)
                            , @message_body
                            ) ;
                END ;
            COMMIT TRANSACTION ;
        END ;
GO








/***********************************************************************************/
--						         TESTING
/***********************************************************************************/
SELECT * FROM dbo.LoggedEventsXML
SELECT * FROM dbo.ServerLevelEvents

TRUNCATE TABLE dbo.LoggedEventsXML
TRUNCATE TABLE dbo.ServerLevelEvents




--	CHECK THE QUEUE
select CAST(message_body AS XML) FROM TargetServerLevelEventNotificationQueue

--	RUN STORED PROCEDURE MANUALLY
EXEC dbo.LogEvents

--	RECEIVE THE MESSAGE MANUALLY
RECEIVE TOP (1) CAST(message_body AS XML) FROM TargetServerLevelEventNotificationQueue



--	SETUP AUTO-ACTIVATION
ALTER QUEUE TargetServerLevelEventNotificationQueue WITH 
STATUS = ON
, ACTIVATION
( 
PROCEDURE_NAME = dbo.LogEvents
, MAX_QUEUE_READERS = 1 --set to zero to disable activation also, limit number of connections, increment based on number of initiating event Notification servers
, EXECUTE AS OWNER
, STATUS = off --need this status set for activation
)
--ALTER QUEUE TargetEventNotificationQueue WITH ACTIVATION (DROP)
GO
