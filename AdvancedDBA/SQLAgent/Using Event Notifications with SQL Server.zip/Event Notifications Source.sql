USE master
GO


-- SELECT * FROM sys.symmetric_keys
CREATE MASTER KEY ENCRYPTION BY PASSWORD = 'Pa$$w0rd1'
-- DROP MASTER KEY
GO


-- SELECT * FROM sys.certificates
CREATE CERTIFICATE EventNotificationCert WITH SUBJECT = 'Service Broker certificate for Transport Security', START_DATE = '20111212' , EXPIRY_DATE = '20201231'
-- DROP CERTIFICATE EventNotificationCert
GO

IF NOT EXISTS ( SELECT  *
                FROM    sys.server_principals
                WHERE   name = 'endpoint_owner' ) --create login for ownership of endpoint so it is not a person's login
    BEGIN
        CREATE LOGIN endpoint_owner WITH PASSWORD = 'Pa$$w0rd1' --same password for all endpoints
    END
-- DROP LOGIN endpoint_owner
GO


IF NOT EXISTS ( SELECT  *
                FROM    sys.endpoints
                WHERE   NAME = 'SB_Endpoint' ) 
    BEGIN
        CREATE ENDPOINT SB_Endpoint AUTHORIZATION endpoint_owner STATE = STARTED AS TCP ( LISTENER_PORT = 4022 ) FOR SERVICE_BROKER ( AUTHENTICATION = CERTIFICATE EventNotificationCert, ENCRYPTION = SUPPORTED )

    END ;
-- DROP ENDPOINT SB_Endpoint
GO

GRANT CONNECT ON ENDPOINT::SB_Endpoint TO PUBLIC
--REVOKE CONNECT ON ENDPOINT::SB_Endpoint FROM PUBLIC


select service_broker_guid from sys.databases where database_id = db_id('msdb')


USE msdb
GO


--	Create a service broker route for the service
--	leave the autocreated route in place so as not to disturb DBMail
IF NOT EXISTS ( SELECT  *
                FROM    sys.routes
                WHERE   name = 'EventNotificationServerLevelEventRoute' ) 
    BEGIN
        CREATE ROUTE EventNotificationServerLevelEventRoute-- AUTHORIZATION dbo
        WITH SERVICE_NAME = 'TargetServerLevelEventNotificationService',
        BROKER_INSTANCE = '49D97E15-6F44-4256-8294-8F29074346DB', --guid of EventLogging database
        ADDRESS = 'TCP://SQLSAT2:4022' --your servername
    END
-- DROP ROUTE EventNotificationServerLevelEventRoute
GO


USE _dba
GO

EXECUTE AS LOGIN = 'aeronet\svc_SQL_Audit';
GO
-- Create the event notification
IF NOT EXISTS ( SELECT  *
                FROM    sys.server_event_notifications
                WHERE   name = 'ServerLevelNotifications' ) 
    BEGIN
        CREATE EVENT NOTIFICATION ServerLevelNotifications
        ON SERVER
        WITH FAN_IN
        FOR DDL_SERVER_LEVEL_EVENTS 
        TO SERVICE 'TargetServerLevelEventNotificationService', '49D97E15-6F44-4256-8294-8F29074346DB' ; --<<use guid from EventLogging database
    END
-- DROP EVENT NOTIFICATION ServerLevelNotifications ON SERVER
GO

REVERT
GO


--	CREATE LOGIN brent with password = 'pa$$w0rd1'

--	DROP LOGIN brent



SELECT * FROM sys.transmission_queue
SELECT * FROM msdb.sys.transmission_queue

