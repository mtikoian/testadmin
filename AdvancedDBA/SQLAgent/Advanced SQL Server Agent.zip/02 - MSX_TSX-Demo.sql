--===========================================================================--
--== SQL Saturday - Advanced SQL Agent - DEMO 2 - MSX/TSX                  ==--
--===========================================================================--
--#############################################################################
--== 01. Check for incomplete downloads
--#############################################################################
	--== Run on MSX
	-- Show download list
	SELECT  source_server,
			operation_code,
			object_id AS job_id,
			target_server,
			date_posted,
			error_message,
			date_downloaded
	FROM	msdb.dbo.sysdownloadlist
	ORDER BY
			date_posted DESC;

	-- Show pending downloads
	SELECT  source_server,
			operation_code,
			object_id AS job_id,
			target_server,
			date_posted,
			error_message,
			date_downloaded
	FROM	msdb.dbo.sysdownloadlist
	WHERE	date_downloaded IS NULL
	ORDER BY
			date_posted DESC;

	--== Make a job change, run above query again ^^

--#############################################################################
--###### 02. Resync a target
--#############################################################################
	--== Run on the MSX instance to resync for the given target (TSX1 in this case)
	EXEC msdb.dbo.sp_resync_targetserver 'MARKWE6540\TSX1'

	--== If that doesn't work ( which it may not ) you can defect and enlist THIS IS THE NUCLEAR OPTION
	
	-- RUN THIS ON THE TSX IN QUESTION
	-- Defect
	EXEC msdb.dbo.sp_msx_defect
	
	-- Enlist
	EXEC msdb.dbo.sp_msx_enlist @msx_server_name = 'localhost\MSX'

	--== Check local jobs out ( OH NOES! )

	-- SWITCH TO MSX AND RUN
	--== Add target back to ALL multiserver jobs
	--== THIS MAY NOT BE HOW YOU WANT TO DO IT
	DECLARE @job_id uniqueidentifier

	DECLARE Jobs CURSOR
	FOR
			SELECT  DISTINCT job_id
			FROM    msdb.dbo.sysjobservers
			WHERE   server_id <> 0;

	OPEN Jobs

	FETCH NEXT FROM Jobs INTO
		@job_id

	WHILE @@FETCH_STATUS = 0
	BEGIN
		EXEC msdb.dbo.sp_add_jobserver @job_id = @job_id, @server_name = N'MARKWE6540\TSX1'

		FETCH NEXT FROM Jobs INTO
			@job_id
	END

	--== Check for the incomplete downloads now
    -- Show pending downloads
	SELECT  source_server,
			operation_code,
			object_id AS job_id,
			target_server,
			date_posted,
			error_message,
			date_downloaded
	FROM	msdb.dbo.sysdownloadlist
	WHERE	date_downloaded IS NULL
	ORDER BY
			date_posted DESC;

	--== ALL SET! ==--

--########################################
-- How do we use this????
--########################################
--== Job that checks for older blocked instructions and resyncs the target
--== Alerts if that doesn't fix it.

--#############################################################################
-- 03. How to get around category limitations
--#############################################################################
--== 01. Just add stuff to the description and check it in your monitoring system
	
	--== Example: {CAT:Maint}{TEAM:DBA}{SEV:1} This job does some maintenance.
