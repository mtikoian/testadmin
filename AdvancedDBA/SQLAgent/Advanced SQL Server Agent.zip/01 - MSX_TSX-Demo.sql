--===========================================================================--
--== SQL Saturday - Advanced SQL Agent - DEMO 1 - MSX/TSX                  ==--
--===========================================================================--
--#############################################################################
--== 01. Look at how jobs are represented
--#############################################################################
    --== SSMS - SQL Server Agent > Jobs: Two folders
    --== Explore each instance to show the jobs exist on all

	--== Query and show the target and origination servers
	--== on both the MSX and any TSX instance.
	--== Run from MSX
	SELECT	job_id,
			originating_server_id,
			name,
			enabled,
			description,
			start_step_id,
			category_id
	FROM	msdb.dbo.sysjobs
	WHERE	name = 'Test - 0'
			OR name = 'syspolicy_purge_history'

	SELECT	*
	FROM	msdb.dbo.sysoriginatingservers;

	SELECT	server_id,
			server_name,
			location,
			last_poll_date,
			local_time_at_last_poll,
			poll_interval
	FROM	msdb.dbo.systargetservers;
	--== Run the same from any TSX ^

	--== Jobs will share ids across all instances:
	--== Run multi-query across all TSX instances
	SELECT	job_id,
			name
	FROM	msdb.dbo.sysjobs
	WHERE	name = 'Test - 0';

	--== Schedules have the same UID, but not the same ID
	SELECT	schedule_id,
			schedule_uid,
			name
	FROM	msdb.dbo.sysschedules;

--#############################################################################
--== 02. Check for list of target servers and history of instruction downloads
--#############################################################################
	--== On MSX Agent > Multi-Server Administration > Manage target Server

	--== Run from MSX
	SELECT	*
	FROM	msdb.dbo.sysdownloadlist;

--#############################################################################
--== 03. Run jobs across all instances.
--#############################################################################
	--== SSMS - Just right click

	--== Start jobs. 3 TSX instances, 3 instructions posted.
	--== Show the local time as well as the posted instructions
	--== Run from MSX
	-- Start Jobs
	EXEC msdb.dbo.sp_start_job @job_name = 'Test - 0';
	
	-- Show Date
	SELECT GETDATE()
	
	-- Show download list
	SELECT TOP 1 WITH TIES
			source_server,
			operation_code,
			object_id AS job_id,
			target_server,
			date_posted,
			date_downloaded
	FROM	msdb.dbo.sysdownloadlist
	ORDER BY
			date_posted DESC;

--== 04. Delete some jobs and observe in SSMS
	EXEC msdb.dbo.sp_delete_job @job_name = 'Test - 1';

--== 05. Show job  history
	--== SSMS - Shows limited data, just last execution, no step detail

	--== Query job history in both locations (Run from MSX)
	-- Local Job History
	SELECT	sj.name,
			sjh.job_id,
			sjh.step_id,
			sjh.step_name
	FROM	msdb.dbo.sysjobhistory AS sjh
			INNER JOIN msdb.dbo.sysjobs AS sj
				ON sjh.job_id = sj.job_id;

	-- TSX history (in sysjobservers OF COURSE ?!?!?)
	SELECT	sj.name,
			sjh.*
	FROM	msdb.dbo.sysjobservers AS sjh
			INNER JOIN msdb.dbo.sysjobs AS sj
				ON sjh.job_id = sj.job_id;