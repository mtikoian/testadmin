1. SqlSaturday29-SQL2k8r2.bak

The database backup file. The database was backed up from a SQL Server 2008 R2 November 2009 CTP instance, but is compatible with SQL Server 2008.

The SQL Server 2008 instance this database backup is restored to must have FILESTREAM support enabled.

2. OriginalSource.zip

Visual Studio 2010 source code (before and after demo script files). Created and compiled with VS 2010 Ultimate RC.

The source code should work without modification on VS 2008 SP 1.

Demo 5 (SQL Server Reporting Services) is a Visual Studio 2008 solution. Business Intelligence Development Studio (BIDS) project types are not available for VS 2010.

3. PDF files

PDF files from PowerPoint presentations (1 per session) and demo scripts (1 for both sessions combined).