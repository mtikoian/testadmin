/* Programming with FileStream Object */
/* Sam Nasr, MCAD, MCT, MCTS          */
/* sam@nasr.info                      */

EXEC sp_configure filestream_access_level, 2
RECONFIGURE
Go


IF EXISTS (SELECT * FROM sys.databases WHERE name = 'PhotoDB')
  DROP DATABASE PhotoDB
  /* ToDo: manually delete folder C:\data and supporting file groups */
GO

CREATE DATABASE PhotoDB ON PRIMARY
  (NAME = PhotoDB_data, FILENAME = 'C:\data\PhotoDb.mdf'),       /* "C:\data" must exist */
    
FILEGROUP PhotoDBFS CONTAINS FILESTREAM    /* New clause */
  (NAME = PhotoDB_FS, FILENAME = 'C:\data\Photos')               /* ToDo: "Photos" folder will be created */
    
LOG ON 
  (NAME = 'PhotoDB_log', FILENAME = 'C:\data\PhotoDB_log.ldf');  /* "C:\data" must exist */
  
GO


use photodb
go


IF EXISTS (SELECT * FROM sys.tables WHERE name = 'Photos')
 drop table Photos
Go

create table Photos
(
  /* RowId uniqueidentifier ROWGUIDCOL not null unique default newsequentialid(), */
  rowid uniqueidentifier rowguidcol not null primary key default(NEWID()), 
  name nvarchar(256) not null, 
  photo varbinary(max) filestream /* default(0x) */
)
Go

/***********/
/* Demo #1 */
/***********/
insert into Photos(name, photo)
values('Text entry', CAST('Modified via T-SQL' as varbinary(max)))

select *, CAST(photo as varchar) as PicText
from Photos

select * from Photos


/***********/
/* Demo #2 */
/***********/
delete from Photos

/* ToDo: Insert records via .Net application */

select * from Photos

select photo.PathName() as Internal_UNC_Path 
from photos

select photo.PathName(), GET_FILESTREAM_TRANSACTION_CONTEXT() from photos 