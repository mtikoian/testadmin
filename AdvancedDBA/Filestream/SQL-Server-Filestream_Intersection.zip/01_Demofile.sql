/* Demo 1 */
/* Show the SQL Server Setup */

/* Show the share that is configured NET SHARE */

/* Show the configuration of the server level configuration */
select *
from sys.configurations
where name = 'filestream access level';

/* Verify the Configuration */
SELECT
      SERVERPROPERTY ('FilestreamShareName') ShareName
     ,SERVERPROPERTY ('FilestreamConfiguredLevel') ConfiguredLevel
     ,SERVERPROPERTY ('FilestreamEffectiveLevel') EffectiveLevel
	 ;
GO
USE master
GO
/* Use sp_configure to check */
/* This will get the setting, show advanced options not required */
EXEC sp_configure 'filestream access level'
GO
/* To use this to set it, you will use 0, 1, 2 */
EXEC sp_configure 'filestream access level', 2
GO
RECONFIGURE
GO
use master;
go
/* Create the database */
CREATE DATABASE [MyProductionDB] ON  PRIMARY
(     
	NAME = N'MyProductionDB_data',     
	FILENAME = N'C:\SQLDATA\MyProductionDB.mdf'
)
LOG ON
(     
	NAME = N'MyProductionDB_log',     
	FILENAME = N'C:\SQLDATA\MyProductionDB_log.ldf'
)
GO

ALTER DATABASE [MyProductionDB]
     ADD FILEGROUP FilestreamGroup1
     CONTAINS FILESTREAM
GO

ALTER DATABASE [MyProductionDB]
 ADD FILE
 (
    NAME = Photos,
    FILENAME = 'C:\SQLDATA\Files'
 )
 TO FILEGROUP FilestreamGroup1
GO
use MyProductionDB
GO
CREATE TABLE dbo.[PhotosWithFilestream] (
     [PhotoID] [int] IDENTITY(1,1) NOT NULL PRIMARY KEY,
     [PhotoFile] varbinary(max) FILESTREAM NULL,
     [PhotoGuid] UNIQUEIDENTIFIER NOT NULL ROWGUIDCOL
                       UNIQUE DEFAULT NEWSEQUENTIALID()
)
FILESTREAM_ON FilestreamGroup1
GO

select *
from dbo.PhotosWithFilestream

truncate table dbo.PhotosWithFilestream

DECLARE @ID UNIQUEIDENTIFIER
SET @ID = NEWID()
INSERT INTO dbo.PhotosWithFilestream(PhotoGuid, PhotoFile)
VALUES (@ID, CAST('Photo Placeholder' AS VARBINARY(MAX)))

SELECT PhotoFile.PathName() as [PhotoFile.PathName()]
FROM dbo.PhotosWithFilestream
WHERE PhotoGuid = 'E66B1731-B670-44EC-9D00-68AA0B60FBC6'

\\BENXPS\MSSQLSERVER\v02-A60EC2F8-2B24-11DF-9CC3-AF2E56D89593\MyProductionDB\dbo\PhotosWithFilestream\PhotoFile\E66B1731-B670-44EC-9D00-68AA0B60FBC6\VolumeHint-HarddiskVolume2

BEGIN TRAN;
SELECT 
PhotoFile.PathName() as PathName,  
GET_FILESTREAM_TRANSACTION_CONTEXT() as Context 
FROM dbo.PhotosWithFileStream 
WHERE PhotoID = 2

commit
