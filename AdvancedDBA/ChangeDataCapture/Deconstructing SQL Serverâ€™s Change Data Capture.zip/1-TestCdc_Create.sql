-- Reference 1: systranschemas; http://msdn.microsoft.com/en-us/library/ms186987.aspx
-- Reference 2: Index maintenance and Change Data Capture (CDC); http://averagedba.blogspot.com/2012/01/index-maintenance-and-change-data.html
SET NOCOUNT ON;
USE master;
GO
CREATE DATABASE TestCdc;
GO
USE TestCdc;
GO

-- ============================================================
-- Create a table to track objects
CREATE TABLE dbo.ObjectList (
    ObjectID        int         NOT NULL,
    SchemaName      sysname     NULL,
    ObjectName      sysname     NOT NULL,
    ObjectType      char(2)     NOT NULL,
    RoundNumber     tinyint     NOT NULL,
	CONSTRAINT PK_ObjectList PRIMARY KEY CLUSTERED (ObjectID)
);
GO

-- ============================================================
-- Round 1 - Initial database creation
INSERT INTO dbo.ObjectList (
    ObjectID,
    SchemaName,
    ObjectName,
    ObjectType,
    RoundNumber
)
SELECT
    o.[object_id],
    s.name,			-- SchemaName
    o.name,			-- ObjectName
    o.[type],
    1
FROM sys.all_objects		AS o
LEFT OUTER JOIN sys.schemas	AS s ON o.[schema_id] = s.[schema_id];

	-- AF = Aggregate function (CLR)
	-- C  = CHECK constraint
	-- D  = DEFAULT (constraint or stand-alone)
	-- F  = FOREIGN KEY constraint
	-- FN = SQL scalar function
	-- FS = Assembly (CLR) scalar-function
	-- FT = Assembly (CLR) table-valued function
	-- IF = SQL inline table-valued function
	-- IT = Internal table
	-- P  = SQL Stored Procedure
	-- PC = Assembly (CLR) stored-procedure
	-- PG = Plan guide
	-- PK = PRIMARY KEY constraint
	-- R  = Rule (old-style, stand-alone)
	-- RF = Replication-filter-procedure
	-- S  = System base table
	-- SN = Synonym
	-- SQ = Service queue
	-- TA = Assembly (CLR) DML trigger
	-- TF = SQL table-valued-function
	-- TR = SQL DML trigger
	-- TT = Table type
	-- U  = Table (user-defined)
	-- UQ = UNIQUE constraint
	-- V  = View
	-- X  = Extended stored procedure

-- Object count
SELECT COUNT(*) AS ObjectCt
FROM dbo.ObjectList;

-- Object count by schema
SELECT
	SchemaName,
	COUNT(*)	AS Ct
FROM dbo.ObjectList
GROUP BY SchemaName
ORDER BY COUNT(*) DESC;

-- What is in dbo?
-- Our user table/PK and three service queues
SELECT * FROM dbo.ObjectList WHERE SchemaName = 'dbo' ORDER BY ObjectID;

-- Object count by type
SELECT
	ObjectType,
	COUNT(*)	AS Ct
FROM dbo.ObjectList
GROUP BY ObjectType
ORDER BY COUNT(*) DESC;

-- List jobs
SELECT
    name			AS JobName,
    [description]
FROM msdb.dbo.sysjobs;
-- "The job syspolicy_purge_history prunes the data older than the the days defined in HistoryRetentionInDays property of Policy Management."
-- Source: http://sqlserverpedia.com/blog/sql-server-bloggers/syspolicy_purge_history-what-is-it/

-- List database roles (not fixed, not public)
SELECT
    name        AS RoleName,
    type_desc
FROM sys.database_principals
WHERE [type] = 'R'
  AND is_fixed_role = 0
  AND name <> N'public'
ORDER BY create_date DESC;
GO

-- ============================================================
-- Turn on Change Data Capture at database level
EXEC sys.sp_cdc_enable_db;
GO

-- ============================================================
-- Round 2 - After turning on CDC
-- Record new objects
INSERT INTO dbo.ObjectList (
    ObjectID,
    SchemaName,
    ObjectName,
    ObjectType,
    RoundNumber
)
SELECT
    o.[object_id],
    s.name,
    o.name,
    o.[type],
    2
FROM sys.all_objects		AS o
LEFT OUTER JOIN sys.schemas	AS s ON o.[schema_id] = s.[schema_id]
WHERE o.[object_id] NOT IN (
    SELECT ObjectID
    FROM dbo.ObjectList
    WHERE RoundNumber = 1
  );

-- New object count
SELECT COUNT(*) AS ObjectCt
FROM dbo.ObjectList
WHERE RoundNumber = 2;

-- Object count by schema
SELECT
	SchemaName,
	COUNT(*)	AS Ct
FROM dbo.ObjectList
WHERE RoundNumber = 2
GROUP BY SchemaName
ORDER BY COUNT(*) DESC;

-- What is in dbo?
SELECT *
FROM dbo.ObjectList
WHERE RoundNumber = 2
  AND SchemaName = 'dbo'
ORDER BY ObjectID;
-- From Reference 1:
-- "The systranschemas table is used to track schema changes in articles published in transactional and snapshot publications.
-- This table is stored in both publication and subscription databases."

-- Added "..." functions
SELECT SchemaName, QUOTENAME(ObjectName) AS ObjectName, ObjectType
FROM dbo.ObjectList
WHERE RoundNumber = 2
  AND ObjectName LIKE '%...%'
ORDER BY ObjectID;

-- What is in schema_id 0?
SELECT *
FROM dbo.ObjectList
WHERE RoundNumber = 2
  AND SchemaName IS NULL
ORDER BY ObjectID;
-- From Reference 2:
-- "CDC enabled tables are covered by a database-level DDL trigger (tr_MScdc_ddl_event)
-- which auto-rollbacks any ALTER_TABLE, DROP_TABLE, ALTER_INDEX or DROP_INDEX commands."

-- Round 2 object count by schema and type
SELECT
	SchemaName,
	ObjectType,
	COUNT(*)	AS Ct
FROM dbo.ObjectList
WHERE RoundNumber = 2
GROUP BY
	SchemaName,
	ObjectType
ORDER BY
	SchemaName,
	COUNT(*)	DESC,
	ObjectType;

---- List jobs
--SELECT
--    name AS JobName,
--    [description]
--FROM msdb.dbo.sysjobs
--WHERE name <> 'syspolicy_purge_history'
--ORDER BY date_created DESC;

---- List database roles (not fixed, not public)
--SELECT
--    name        AS RoleName,
--    type_desc
--FROM sys.database_principals
--WHERE [type] = 'R'
--  AND is_fixed_role = 0
--  AND name <> N'public'
--ORDER BY create_date DESC
GO

-- ============================================================
-- Create a new schema
CREATE SCHEMA MySchema
GO

-- ============================================================
-- Create a new user table
CREATE TABLE MySchema.Person (
    PersonID    int             IDENTITY,
    FirstName   varchar(32)     NOT NULL,
    LastName    varchar(32)     NOT NULL,
    UpdateCt    int             NOT NULL,
	CONSTRAINT PK_Person PRIMARY KEY CLUSTERED (PersonID)
);
GO
ALTER TABLE MySchema.Person
ADD CONSTRAINT DF_Person_UpdateCt
DEFAULT 0 FOR UpdateCt;
GO

-- Any new objects?
SELECT
    [object_id],
    name,
    [type]
FROM sys.all_objects
WHERE [object_id] NOT IN (
    SELECT ObjectID
    FROM dbo.ObjectList
    WHERE RoundNumber IN (1, 2)
  )
GO

-- ============================================================
-- Turn on Change Data Capture at table level
EXEC sys.sp_cdc_enable_table
    @source_schema          = N'MySchema',
    @source_name            = N'Person',
    @role_name              = N'ChangeDataAccessRole',
    --@role_name              = N'MySchema',
    @supports_net_changes   = 1
GO

-- If @supports_net_changes = 0, adds      fn_cdc_get_all_changes_MySchema_Person.
-- If @supports_net_changes = 1, also adds fn_cdc_get_net_changes_MySchema_Person.

-- ============================================================
-- Round 3 - After creating table Person and setting CDC on
INSERT INTO dbo.ObjectList (
    ObjectID,
    SchemaName,
    ObjectName,
    ObjectType,
    RoundNumber
)
SELECT
    o.[object_id],
    s.name,
    o.name,
    o.[type],
    3
FROM sys.all_objects		AS o
LEFT OUTER JOIN sys.schemas	AS s ON o.[schema_id] = s.[schema_id]
WHERE o.[object_id] NOT IN (
    SELECT ObjectID
    FROM dbo.ObjectList
    WHERE RoundNumber IN (1, 2)
  );

-- New object count
SELECT COUNT(*) AS ObjectCt
FROM dbo.ObjectList
WHERE RoundNumber = 3;

-- Object count by schema
SELECT
	SchemaName,
	COUNT(*)	AS Ct
FROM dbo.ObjectList
WHERE RoundNumber = 3
GROUP BY SchemaName
ORDER BY COUNT(*) DESC;

-- What is new?
SELECT
	SchemaName,
	ObjectName,
	ObjectType
FROM dbo.ObjectList
WHERE RoundNumber = 3
ORDER BY
	SchemaName,
	ObjectName;

-- List jobs
SELECT
    name AS JobName,
    [description]
FROM msdb.dbo.sysjobs
WHERE name <> 'syspolicy_purge_history'
ORDER BY date_created DESC;

-- List database roles (not fixed, not public)
SELECT
    name        AS RoleName,
    type_desc
FROM sys.database_principals
WHERE [type] = 'R'
  AND is_fixed_role = 0
  AND name <> N'public'
ORDER BY create_date DESC
