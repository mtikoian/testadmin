USE TestCdc;
GO

--TRUNCATE TABLE MySchema.Person
-- Cannot truncate table 'MySchema.Person' because it is published for replication or enabled for Change Data Capture.

--DELETE FROM MySchema.Person;
--GO
--WAITFOR DELAY '00:00:05';
--GO
--DELETE FROM cdc.MySchema_Person_CT;
--GO

SELECT * FROM MySchema.Person;
SELECT * FROM cdc.MySchema_Person_CT ORDER BY [__$start_lsn] DESC, PersonID DESC, UpdateCt DESC;

-- INSERT first record
INSERT INTO MySchema.Person (FirstName, LastName) VALUES ('Doug', 'Michael');
SELECT * FROM cdc.MySchema_Person_CT ORDER BY [__$start_lsn] DESC, PersonID DESC, UpdateCt DESC;
WAITFOR DELAY '00:00:05';
SELECT * FROM cdc.MySchema_Person_CT ORDER BY [__$start_lsn] DESC, PersonID DESC, UpdateCt DESC;

-- An UPDATE is recorded
UPDATE MySchema.Person SET UpdateCt += 1;
WAITFOR DELAY '00:00:05';
SELECT * FROM cdc.MySchema_Person_CT ORDER BY [__$start_lsn] DESC, PersonID DESC, UpdateCt DESC;

-- A non-UPDATE is not recorded
SELECT * FROM MySchema.Person;

UPDATE MySchema.Person SET UpdateCt = 1;
WAITFOR DELAY '00:00:05';
SELECT * FROM cdc.MySchema_Person_CT ORDER BY [__$start_lsn] DESC, PersonID DESC, UpdateCt DESC;

-- INSERT more records
INSERT INTO MySchema.Person (
    FirstName,
    LastName
)
VALUES
    ('Shane',   'Stefanson'),
    ('Brian',   'McCullough'),
    ('Sopheap', 'Suy'),
    ('Rob',     'Garrison');
WAITFOR DELAY '00:00:05';
SELECT * FROM cdc.MySchema_Person_CT ORDER BY [__$start_lsn] DESC, PersonID DESC, UpdateCt DESC;

DELETE FROM MySchema.Person WHERE LastName = 'Garrison';
SELECT * FROM MySchema.Person;
WAITFOR DELAY '00:00:05';
SELECT * FROM cdc.MySchema_Person_CT ORDER BY [__$start_lsn] DESC, PersonID DESC, UpdateCt DESC;

DECLARE @i int = 0;
WHILE @i < 4
BEGIN
    SET @i += 1;
    UPDATE MySchema.Person SET UpdateCt += 1;
END
WAITFOR DELAY '00:00:05';
SELECT * FROM cdc.MySchema_Person_CT ORDER BY [__$start_lsn] DESC, PersonID DESC, UpdateCt DESC;

-- System Function
-- Reference: http://msdn.microsoft.com/en-us/library/bb510627.aspx
-- "When the 'all' row filter option is specified, each change has exactly one row to identify the change.
-- When the 'all update old' option is specified, update operations are represented as two rows:
-- one containing the values of the captured columns before the update and another containing
-- the values of the captured columns after the update."
DECLARE @from_lsn           binary(10);
DECLARE @to_lsn             binary(10);
DECLARE @row_filter_option  nvarchar(30);

SET @from_lsn   = sys.fn_cdc_get_min_lsn('MySchema_Person');
SET @to_lsn     = sys.fn_cdc_get_max_lsn();

SET @row_filter_option  = N'all update old';
SELECT *
FROM TestCdc.cdc.fn_cdc_get_all_changes_MySchema_Person (
    @from_lsn,
    @to_lsn,
    @row_filter_option
);

SET @row_filter_option  = N'all';
SELECT *
FROM TestCdc.cdc.fn_cdc_get_all_changes_MySchema_Person (
    @from_lsn,
    @to_lsn,
    @row_filter_option
);
GO

-- If the specified LSN range does not fall within the
-- change tracking timeline for the capture instance,
-- the function returns error 208 ("An insufficient
-- number of arguments were supplied for the procedure
-- or function cdc.fn_cdc_get_all_changes.").
