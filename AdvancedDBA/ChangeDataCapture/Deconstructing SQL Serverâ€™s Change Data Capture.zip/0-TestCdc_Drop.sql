USE master;
GO

-- Drop database
IF EXISTS (SELECT * FROM sys.databases WHERE name = 'TestCdc') ALTER DATABASE TestCdc SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
IF EXISTS (SELECT * FROM sys.databases WHERE name = 'TestCdc') DROP DATABASE  TestCdc;
GO

-- Drop jobs
DECLARE @jobName    sysname;

SET @jobName = N'cdc.TestCdc_capture';

IF EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = @jobName)
BEGIN
    PRINT 'Drop job ' + @jobName;
    EXEC msdb.dbo.sp_delete_job
        @job_name               = @jobName,
        @delete_unused_schedule = 1;
END
ELSE BEGIN
    PRINT 'Job ' + @jobName + ' does not exist';
END

SET @jobName = N'cdc.TestCdc_cleanup';

IF EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = @jobName)
BEGIN
    PRINT 'Drop job ' + @jobName;
    EXEC msdb.dbo.sp_delete_job
        @job_name               = @jobName,
        @delete_unused_schedule = 1;
END
ELSE BEGIN
    PRINT 'Job ' + @jobName + ' does not exist';
END
GO
