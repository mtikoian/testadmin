use scratch
go
Drop Table mySales
go
Create Table mySales
(
SaleId integer primary key,
SaleAmount decimal(10,2) not null,
SaleDate   datetime not null
)
go
delete from mySales

insert into mysales
select top(100000)
       row_number() over (order by (select null)) as Rown,
	   abs(cast(checksum(newid()) as integer))%1000,
	   dateadd(dd,abs(cast(checksum(newid()) as integer))%1000,'20100101')
from sys.columns a
cross apply sys.columns b
cross apply sys.columns c
go

drop index mysales.DateSold
go
create index DateSold on mySales(SaleDate,SaleAmount)
go



select * from mySales
order by SaleId
go




/* Seek on index */
/* Is this good or bad ?!?! */
/* Found a small amount of rows, index seek = good , right */
Select SaleID,
	   SaleDate
  from mySales
  where SaleDate > '20100201'
    and SaleAmount =998
option(recompile)

go
/* Disable the push-predicate*/
Select SaleID,
	   SaleDate
  from mySales
  where SaleDate > '20100201'
    and SaleAmount =998
option(querytraceon 9130,recompile)
go

/* Both have read the data */

set statistics io on
go
Select SaleID,
	   SaleDate
  from mySales
  where SaleDate > '20100201'
    and SaleAmount =998
option(recompile)

go
Select SaleID,
	   SaleDate
  from mySales
  where SaleDate > '20100201'
    and SaleAmount =998
option(querytraceon 9130,recompile)
go


/* Count of rows scanned */
select count(*) 
  from mySales
  where SaleDate > '20100201'
option(recompile)


go

/* Proper fix */

create index SaleAmount on mySales(SaleAmount,SaleDate)
go
set statistics io on
go
Select SaleID,
	   SaleDate
  from mySales
  where SaleDate > '20100201'
    and SaleAmount =998
option(recompile)

go
Select SaleID,
	   SaleDate
  from mySales
  where SaleDate > '20100201'
    and SaleAmount =998
option(querytraceon 9130,recompile)
go
