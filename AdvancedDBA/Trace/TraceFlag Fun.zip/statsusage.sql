use AdventureWorks2012	
go
drop index person.address.idxRhodes
go
select top(10) city from person.Address where city='Rhodes'
go
dbcc traceon(3604)
dbcc traceon(9292)
dbcc traceoff(9204)
go
select count(*) 
  from person.Address 
 where city='Rhodes'
option(recompile)

go
select count( * ) 
  from person.Address 
 where addressline1 like '%Avenue%'
option(recompile)
go

dbcc traceon(9204)
go
select count(*) 
  from person.Address 
 where city='Rhodes'
option(recompile)

go
select count( * ) 
  from person.Address 
 where addressline1 like '%Avenue%'
option(recompile)


go

create index idxRhodes on person.Address(City) where City='Rhodes';

go

select count(*) 
  from person.Address 
 where city='Rhodes'
option(recompile)
go
select count(*) 
  from person.Address 
 where city='London'
option(recompile)
go

create index idxState79 on person.Address(StateProvinceId) where StateProvinceId=79;
go
select count(*) 
  from person.Address 
 where city='Rhodes'
  and StateProvinceID =79
option(recompile)
go



/* Display Optimizer internals in plans */
/* Have to use dbcc,  does not operate with querytraceon */
dbcc traceon(8666)
go
SELECT TOP 1000 [BusinessEntityID]
      ,[Name]
      ,[AddressType]
      ,[AddressLine1]
      ,[AddressLine2]
      ,[City]
      ,[StateProvinceName]
      ,[PostalCode]
      ,[CountryRegionName]
  FROM [AdventureWorks2012].[Sales].[vStoreWithAddresses]


go
/* Cached Plans */
select * from sys.dm_exec_cached_plans
cross apply sys.dm_exec_query_plan(plan_handle)

go
/* Something 'interesting' */
select * from sys.dm_exec_cached_plans
cross apply sys.dm_exec_query_plan(plan_handle)
where cast(query_plan as varchar(max)) like '%FieldValue="mssqlsystemresourc%'
and objtype='Prepared'
