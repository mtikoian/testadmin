dbcc traceoff(2389)
dbcc traceoff(2390)
dbcc traceoff(2388)
go

use scratch

go
if(object_id('dbo.AscKey') is not null) 
   drop table AscKey
go

create table AscKey
(
SaleID integer primary key,
SaleDateTime datetime not null
)
go
Create index idxSaleDate on AscKey(SaleDateTime);
go
/* Populate 100,000 rows of sales one per minute backwards in time */
declare @Today datetime;
select @Today = cast(getdate() as date);

with cteCount
as
(
   Select top(100000) ROW_NUMBER() over ( order by (select null)) as rowN
    from  sys.columns a 
	cross join sys.columns b
	cross join sys.columns c
)
insert into asckey(SaleID,SaleDateTime)
Select 100000-(RowN -1),
       dateadd(mi,0-rowN,@Today)
 from  cteCount;
go

select * from AscKey
go

if (object_id('dbo.CountSales') is not null) begin 

	drop procedure CountSales
end

go

       
create procedure CountSales @SaleDate Date
as
Declare @Tommorrow date
Select @Tommorrow = dateadd(dd,1,@SaleDate)
Select count(*) 
  from dbo.AscKey
 where SaleDateTime >= @SaleDate and SaleDateTime<@Tommorrow
option(recompile)
go

/* Count Yesterdays Sales , Stats are built here and we get an accurate Plan */
Declare @RepDate date=getdate()-1
exec CountSales @SaleDate = @RepDate
go

/* Populate in 360 of todays sales*/

declare @Today datetime;
select @Today = cast(getdate() as date);

with cteCount
as
(
   Select top(360) ROW_NUMBER() over ( order by (select null) ) as rowN
    from  sys.columns a 
	cross join sys.columns b
	cross join sys.columns c
)
insert into asckey(SaleID,SaleDateTime)
Select 100000+RowN,
       dateadd(mi,rowN,@Today)
 from  cteCount;
go

/* Estimated Number of rows = 1 */
Declare @RepDate date=getdate()
exec CountSales @SaleDate = @RepDate


go
dbcc show_statistics("dbo.ascKey",idxSaleDate) with histogram
go
/* Turn on Ascending stats flags */
dbcc traceon(2389)
dbcc traceon(2390)
go
/* Estimated Number of rows = ~360 */
Declare @RepDate date=getdate()
exec CountSales @SaleDate = @RepDate
go


--  2389 Poll the table for max value if 'ascending' branding
--  2390 Override branding in TF 2389

/* Turn off branding override */
dbcc traceoff(2390)
go
Declare @RepDate date=getdate()
exec CountSales @SaleDate = @RepDate
go

/* Turn on Stats info flag */
dbcc traceon(2388)
go
dbcc show_statistics("dbo.ascKey",idxSaleDate)
go

/* Insert a single row, update stats and show stats header */
declare @MaxSaleID integer
Declare @MaxSaleDate   datetime

Select @MaxSaleID = max(SaleID),
       @MaxSaleDate = max(SaleDateTime)
  from AscKey

declare @Today datetime;
select @Today = cast(getdate() as date);

insert into AscKey(SaleID,SaleDateTime)
Select @MaxSaleID+1,DATEADD(mi,1,@MaxSaleDate)
go
update statistics AscKey with fullscan
go
dbcc show_statistics("dbo.ascKey",idxSaleDate) with stat_header
go

/*  Until branding shows ascending */




dbcc traceoff(2388)
dbcc show_statistics("dbo.ascKey",idxSaleDate) with histogram
go
/* Populate 'tommorrows' sales */
declare @MaxSaleID integer
declare @Today datetime;

Select @MaxSaleID = max(SaleID)
  from AscKey

select @Today = cast(getdate() as date);
select @Today = DATEADD(dd,1,@today);

with cteCount
as
(
   Select top(360) ROW_NUMBER() over ( order by (select null) ) as rowN
    from  sys.columns a 
	cross join sys.columns b
	cross join sys.columns c
)
insert into asckey(SaleID,SaleDateTime)
Select @MaxSaleID+RowN,
       dateadd(mi,rowN,@Today)
 from  cteCount;
go

dbcc show_statistics("dbo.ascKey",idxSaleDate) with histogram
go

/* Now estimates at 90 for tommorrow */
Declare @RepDate date=getdate()
set @RepDate=DATEADD(dd,1,@repdate)
exec CountSales @SaleDate = @RepDate
go
/* Estimates at ~633 rows  */

Declare @RepDate date=getdate()
exec CountSales @SaleDate = @RepDate
go

