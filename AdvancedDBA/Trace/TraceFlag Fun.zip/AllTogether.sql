dbcc traceon(3604)
go
use AdventureWorks2012
go
/* Exploring the memo */
go
drop table #c1
go
drop table #c2
go


create table #c1
(
customerid integer
)
go
create table #c2
(
customerid integer
)
go
/* Simple A join B  */
/* 8608 - Initial Memo */
select * 
  from #c1 join #c2
  on #c1.customerid = #c2.customerid
option(querytraceon 8608,recompile)
go

/* 8608 - Initial Memo - Anti Semi Join */
select * 
  from #c1 
  where not exists 
   (Select 1 from #c2
     where #c1.customerid = #c2.customerid)
option(querytraceon 8608,recompile)

/* 8615 - Output Memo */
select * 
  from #c1 join #c2
  on #c1.customerid = #c2.customerid
option(querytraceon 8608, querytraceon 8615,recompile)
go

/* Bit more complex, lots of unused Groups */
select Customer.CustomerId
from sales.Customer 
join sales.SalesOrderHeader
on Customer.CustomerID = SalesOrderHeader.CustomerID
option(querytraceon 8608, querytraceon 8615,recompile)
go
/* Add in total due */
select Customer.CustomerId,TotalDue
from sales.Customer 
join sales.SalesOrderHeader
on Customer.CustomerID = SalesOrderHeader.CustomerID
option(querytraceon 8608, querytraceon 8615,recompile)

go
-- N-Ary Join 
-- Gets split in the phys join
select Customer.CustomerId
from sales.Customer 
join sales.SalesOrderHeader
on Customer.CustomerID = SalesOrderHeader.CustomerID
join sales.PersonCreditCard 
on PersonCreditCard.BusinessEntityID = SalesOrderHeader.CustomerID
option(querytraceon 8608, querytraceon 8615,recompile)
go


/* More Complicated ..... */
select Customer.CustomerId,count(*)
from sales.Customer 
join sales.SalesOrderHeader
on Customer.CustomerID = SalesOrderHeader.CustomerID
group by customer.customerid
option(querytraceon 8608, querytraceon 8615,recompile)
go

/* Or More 4-Table Join - Group 18 */
/* Going through multiple stages + Parralel considerations ( 2 Initial and Final Memos) */
SELECT EnglishMonthName,TotalChildren,DimProduct.Size,sum(UnitPrice)
  FROM [AdventureWorksDW2012].[dbo].[FactInternetSales]
  join [AdventureWorksDW2012].[dbo].[DimDate] on
     [FactInternetSales].OrderDateKey = DimDate.DateKey 
  join [AdventureWorksDW2012].[dbo].[DimCustomer] on
     [FactInternetSales].CustomerKey = DimCustomer.CustomerKey
  join [AdventureWorksDW2012].[dbo].[DimProduct] on
     [FactInternetSales].ProductKey = DimProduct.ProductKey
where TotalChildren >3
group by TotalChildren,EnglishMonthName,DimProduct.Size
option(querytraceon 8608, querytraceon 8615,recompile)
go

/* Putting it all together */
select * 
  from #c1 join #c2
  on #c1.customerid = #c2.customerid
option(querytraceon 8608,   -- Initial Memo
       querytraceon 8615,   -- Final Memo
	   querytraceon 8605, -- Converted tree,
	   querytraceon 8606, -- Input, simplified, join-collapsed and normalized trees
	   querytraceon 8607, -- Output tree,
	   querytraceon 8612, -- Add Costings and Cardinality to output tree
	   --querytraceon 7352, -- Final Query tree
	   recompile)
go

select * 
  from #c1 inner hash join #c2
  on #c1.customerid = #c2.customerid
option(querytraceon 8608,  -- Initial Memo
       querytraceon 8615,  -- Final Memo
	 --  querytraceon 8619, -- Apply rules, Also notice labels in the memo
	  -- querytraceon 8620, -- Add Memo args to 8619
	 --  querytraceon 8621, -- Rule with resulting tree
	 --  querytraceon 8609, -- Tasks Counts
	 --  querytraceon 2373, -- Memory Used Before and After Rules applied
	   	   recompile)

/* Simplification being applied */
SELECT th.ProductID--,p.ProductID
FROM Production.Product AS p
JOIN Production.TransactionHistory AS th ON
    th.ProductID = p.ProductID
option(querytraceon 8606,querytraceon 8619)
go

/* Starts with an inital GBAgg in the memo, but ends with initial Merge */
select Customer.CustomerId,count(*)
from sales.Customer join sales.SalesOrderHeader
on Customer.CustomerID = SalesOrderHeader.CustomerID
group by customer.customerid
option(querytraceon 8608, querytraceon 8615,recompile)



go

/* This is done with GbAggBeforeJoin */
/* Group-By-Aggregation-Before-Join */
/* It may be cheaper to aggregate then join, rather than join then aggregate */
/* Lets see the rule being applied */
select Customer.CustomerId,count(*)
from sales.Customer join sales.SalesOrderHeader
on Customer.CustomerID = SalesOrderHeader.CustomerID
group by customer.customerid
option(querytraceon 8608, querytraceon 8615,querytraceon 8619,recompile)


go
/* DMV */
select * from sys.dm_exec_query_transformation_stats
go

/* Turning off rules */
dbcc traceon(3604)
go

DBCC SHOWONRULES
go

DBCC SHOWOFFRULES
go
dbcc ruleoff('GbAggBeforeJoin')
go
/* Rule off */
select Customer.CustomerId,count(*)
from sales.Customer join sales.SalesOrderHeader
on Customer.CustomerID = SalesOrderHeader.CustomerID
group by customer.customerid
option(recompile)
go

dbcc ruleon('GbAggBeforeJoin')

go




-- More Complicated Rules

SELECT EnglishMonthName,TotalChildren,DimProduct.Size,sum(UnitPrice)
  FROM [AdventureWorksDW2012].[dbo].[FactInternetSales]
  join [AdventureWorksDW2012].[dbo].[DimDate] on
     [FactInternetSales].OrderDateKey = DimDate.DateKey 
  join [AdventureWorksDW2012].[dbo].[DimCustomer] on
     [FactInternetSales].CustomerKey = DimCustomer.CustomerKey
  join [AdventureWorksDW2012].[dbo].[DimProduct] on
     [FactInternetSales].ProductKey = DimProduct.ProductKey
where TotalChildren >3
 --and DimDate.EnglishMonthName = 'May'
 --and DimProduct.Size = '28'
group by TotalChildren,EnglishMonthName,DimProduct.Size
option(querytraceon 8619, recompile)
go

--  Even More
--  But with timing so we can see the phases
SELECT EnglishMonthName,TotalChildren,DimProduct.Size,DimCurrency.CurrencyName,sum(UnitPrice)
  FROM [AdventureWorksDW2012].[dbo].[FactInternetSales]
  join [AdventureWorksDW2012].[dbo].[DimDate] on
     [FactInternetSales].OrderDateKey = DimDate.DateKey 
  join [AdventureWorksDW2012].[dbo].[DimCustomer] on
     [FactInternetSales].CustomerKey = DimCustomer.CustomerKey
  join [AdventureWorksDW2012].[dbo].[DimProduct] on
     [FactInternetSales].ProductKey = DimProduct.ProductKey
  join [AdventureWorksDW2012].[dbo].DimCurrency on
      FactInternetSales.CurrencyKey = DimCurrency.CurrencyKey
where TotalChildren >3
 --and DimDate.EnglishMonthName = 'May'
 --and DimProduct.Size = '28'
group by TotalChildren,EnglishMonthName,DimProduct.Size,DimCurrency.CurrencyName
option(recompile,querytraceon 8675,querytraceon 8619)
go

/* Unique hash optimization used*/
dbcc traceon(3604)
go
dbcc traceon(7357) 
go

select * 
FROM  [Person].[BusinessEntityAddress] bea 
    INNER JOIN [Person].[Address] a 
    ON a.[AddressID] = bea.[AddressID]
option(recompile)

go
dbcc traceon (3604)
dbcc traceon (7357)

select distinct SalesOrderDetail.UnitPrice
from sales.SalesOrderDetail
option(recompile)
go

SELECT TOP 1000 [BusinessEntityID]
      ,[Name]
      ,[AddressType]
      ,[AddressLine1]
      ,[AddressLine2]
      ,[City]
      ,[StateProvinceName]
      ,[PostalCode]
      ,[CountryRegionName]
  FROM [AdventureWorks2012].[Sales].[vStoreWithAddresses]
option(Recompile)

go

dbcc traceoff(7357) 

go
