select * from sys.dm_exec_query_optimizer_info
go
dbcc traceon(3604)
go

dbcc freeproccache
go
use AdventureWorks2012
go
/* Simple Trivial Plan */
go
SELECT * FROM Sales.SalesOrderHeader WHERE SalesOrderID = 43665
go
/* 8675 - Show QO timings */
SELECT * FROM Sales.SalesOrderHeader where SalesOrderID = 43665
OPTION( querytraceon 8675)

go
/* Show using TRACEON */
DBCC traceon(8675)
go
SELECT * FROM Sales.SalesOrderHeader where SalesOrderID = 43665
go
/* No timings ??? It found the cached plan */
go

dbcc freeproccache
go
SELECT * FROM Sales.SalesOrderHeader where SalesOrderID = 43665
go
/* Use recompile so no caching */
SELECT * FROM Sales.SalesOrderHeader where SalesOrderID = 43665
option(querytraceon 8675,recompile)
go

/* Enter search (0) - Transaction Processing */
SELECT * 
  FROM Sales.SalesOrderHeader SOH
  JOIN Sales.SalesOrderDetail SOD
    on SOH.SalesOrderID = SOD.SalesOrderID
  JOIN Person.Person on Person.BusinessEntityID = SOH.SalesPersonID
 WHERE SOH.SalesOrderID = 43665
option(querytraceon 8675,recompile)
go
/* Enter search (1)  */
/* Does not meet the requirements for search(0) */
SELECT * 
  FROM Sales.SalesOrderHeader SOH
  JOIN Sales.SalesOrderDetail SOD
    on SOH.SalesOrderID = SOD.SalesOrderID
  --JOIN Person.Person on Person.BusinessEntityID = SOH.SalesPersonID
 WHERE SOH.SalesOrderID = 43665
option(querytraceon 8675,recompile)
go



/* Optimizer Timeout in search 0 */
SELECT TOP 1000 [BusinessEntityID]
      ,[Name]
      ,[AddressType]
      ,[AddressLine1]
      ,[AddressLine2]
      ,[City]
      ,[StateProvinceName]
      ,[PostalCode]
      ,[CountryRegionName]
  FROM [AdventureWorks2012].[Sales].[vStoreWithAddresses]
option(querytraceon 8675,recompile)
go

/* Lower Cost of parralelism to 0 - 8649 */
SELECT TOP 1000 [BusinessEntityID]
      ,[Name]
      ,[AddressType]
      ,[AddressLine1]
      ,[AddressLine2]
      ,[City]
      ,[StateProvinceName]
      ,[PostalCode]
      ,[CountryRegionName]
  FROM [AdventureWorks2012].[Sales].[vStoreWithAddresses]
option(querytraceon 8675,querytraceon 8649,recompile)
go

/* Remove the timeout - 8780 */
SELECT TOP 1000 [BusinessEntityID]
      ,[Name]
      ,[AddressType]
      ,[AddressLine1]
      ,[AddressLine2]
      ,[City]
      ,[StateProvinceName]
      ,[PostalCode]
      ,[CountryRegionName]
  FROM [AdventureWorks2012].[Sales].[vStoreWithAddresses]
option(querytraceon 8675,querytraceon 8780,recompile)
go

/* Combine !! */

SELECT TOP 1000 [BusinessEntityID]
      ,[Name]
      ,[AddressType]
      ,[AddressLine1]
      ,[AddressLine2]
      ,[City]
      ,[StateProvinceName]
      ,[PostalCode]
      ,[CountryRegionName]
  FROM [AdventureWorks2012].[Sales].[vStoreWithAddresses]
option(querytraceon 8675,querytraceon 8780,querytraceon 8649,recompile)
go


/* Does removing the timeout get a "better" plan ? */
DBCC traceoff(8675)
dbcc traceoff(8780)
go

dbcc freeproccache
go

declare @SalesPersonID integer
declare @FullName nvarchar(255)
declare @JobTitle nvarchar(30)
declare @SalesTerritory nvarchar(30)
declare @Sales2002 money
declare @Sales2003 money
declare @Sales2004 money
select  @SalesPersonID = SalesPersonID,
        @FullName = FullName,
        @JobTitle = JobTitle,
        @SalesTerritory = SalesTerritory,
        @Sales2002 = [2002],
        @Sales2003 = [2003],
        @Sales2004 = [2004]
   From Sales.vSalesPersonSalesByFiscalYears
  where SalesTerritory ='Canada'
  go 5

dbcc freeproccache
go
dbcc traceon (8780)
go


declare @SalesPersonID integer
declare @FullName nvarchar(255)
declare @JobTitle nvarchar(30)
declare @SalesTerritory nvarchar(30)
declare @Sales2002 money
declare @Sales2003 money
declare @Sales2004 money
select  @SalesPersonID = SalesPersonID,
        @FullName = FullName,
        @JobTitle = JobTitle,
        @SalesTerritory = SalesTerritory,
        @Sales2002 = [2002],
        @Sales2003 = [2003],
        @Sales2004 = [2004]
   From Sales.vSalesPersonSalesByFiscalYears
  where SalesTerritory ='Canada'
  go 5

dbcc traceoff (8780)

/* Skip Search (1) - 8677 */

SELECT * 
  FROM Sales.SalesOrderHeader SOH
  JOIN Sales.SalesOrderDetail SOD
    on SOH.SalesOrderID = SOD.SalesOrderID
  --JOIN Person.Person on Person.BusinessEntityID = SOH.SalesPersonID
 WHERE SOH.SalesOrderID = 43665
option(querytraceon 8675,querytraceon 8677,recompile)
go


/* Larger Query, Naturally creates a parralel plan*/
/* Two search 1 phases*/
SELECT EnglishMonthName,TotalChildren,DimProduct.Size,DimCurrency.CurrencyName,sum(UnitPrice)
  FROM [AdventureWorksDW2012].[dbo].[FactInternetSales]
  join [AdventureWorksDW2012].[dbo].[DimDate] on
     [FactInternetSales].OrderDateKey = DimDate.DateKey 
  join [AdventureWorksDW2012].[dbo].[DimCustomer] on
     [FactInternetSales].CustomerKey = DimCustomer.CustomerKey
  join [AdventureWorksDW2012].[dbo].[DimProduct] on
     [FactInternetSales].ProductKey = DimProduct.ProductKey
  join [AdventureWorksDW2012].[dbo].DimCurrency on
      FactInternetSales.CurrencyKey = DimCurrency.CurrencyKey
where TotalChildren >3
group by TotalChildren,EnglishMonthName,DimProduct.Size,DimCurrency.CurrencyName
option(recompile,querytraceon 8675)