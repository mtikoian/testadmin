SET STATISTICS IO OFF

EXEC dbo.TempTableBlaster
GO 200
