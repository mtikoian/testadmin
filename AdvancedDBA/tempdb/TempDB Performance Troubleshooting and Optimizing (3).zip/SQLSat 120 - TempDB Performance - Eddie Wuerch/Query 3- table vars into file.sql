DECLARE @ThisShouldBeFun table(FunStuff varchar(1000) NOT NULL)

INSERT @ThisShouldBeFun(FunStuff)
SELECT 'Welcome to SQL Saturday #87!' 
  FROM sys.all_objects a, sys.all_objects b

SELECT count(*) FROM @ThisShouldBeFun

WAITFOR DELAY '01:00:00'
GO

