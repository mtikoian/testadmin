use AdventureWorks2014
select top(1000) * into #temp from dbo.bigProduct

go

insert into #temp 
	select top(1000) * from dbo.bigProduct
waitfor delay '00:00:01'

go 1000

drop table #temp