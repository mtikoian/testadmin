SET ANSI_NULLS, QUOTED_IDENTIFIER ON;
GO
USE WaitDemo;
GO

ALTER PROC dbo.TempAllocationBlaster
AS
SET NOCOUNT ON;
DECLARE @cmd nvarchar(256);

CREATE TABLE #SysObjs(
object_id   int      NOT NULL PRIMARY KEY,
schema_id   int      NOT NULL,
name        char(5000)  NOT NULL,
create_date datetime NOT NULL,
type_desc   varchar(128) NOT NULL
);

CREATE TABLE #SysObjs2(
object_id   int      NOT NULL PRIMARY KEY,
schema_id   int      NOT NULL,
name        char(5000) NOT NULL,
create_date datetime NOT NULL,
type_desc   varchar(128) NOT NULL
);

CREATE TABLE #SysObjs3(
object_id   int      NOT NULL PRIMARY KEY,
schema_id   int      NOT NULL,
name        char(5000)  NOT NULL,
create_date datetime NOT NULL,
type_desc   varchar(128) NOT NULL
);

INSERT #SysObjs(object_id, schema_id, name, create_date, type_desc)
SELECT object_id, schema_id, name, create_date, type_desc
  FROM sys.objects;

INSERT #SysObjs2(object_id, schema_id, name, create_date, type_desc)
SELECT top 10 object_id, schema_id, name, create_date, type_desc
  FROM sys.objects;

INSERT #SysObjs3(object_id, schema_id, name, create_date, type_desc)
SELECT top 100 object_id, schema_id, name, create_date, type_desc
  FROM sys.objects;


RETURN;
GO