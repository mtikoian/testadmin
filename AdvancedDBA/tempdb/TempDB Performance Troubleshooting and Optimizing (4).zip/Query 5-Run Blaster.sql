SET STATISTICS IO OFF
GO
USE WaitDemo
GO

EXEC dbo.TempAllocationBlaster
GO 200

EXEC dbo.TempTableBlaster
GO 200
