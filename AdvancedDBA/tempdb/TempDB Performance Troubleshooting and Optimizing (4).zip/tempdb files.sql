use tempdb;
GO
-- view files and sizes in TempDB
SELECT f.file_id, fg.name, f.name, f.physical_name, f.type_desc, f.data_space_id, f.size/128 AS Size , 
       (f.size/128 - CONVERT(int, FILEPROPERTY(f.name, 'SpaceUsed'))/128) AS MBFree, 
       CONVERT(int, FILEPROPERTY(f.name, 'SpaceUsed'))/128  AS Used
  FROM sys.database_files f LEFT JOIN sys.filegroups fg ON f.data_space_id = fg.data_space_id
 ORDER BY f.data_space_id, f.FILE_ID

CHECKPOINT

ALTER DATABASE tempdb
  ADD FILE (NAME=tempdev2, SIZE = 128MB, FILENAME = 'C:\mssql\DefaultInstance\MSSQL10_50.MSSQLSERVER\MSSQL\DATA\tempdb2.ndf', FILEGROWTH = 128MB)
GO

ALTER DATABASE tempdb
  ADD FILE (NAME=tempdev3, SIZE = 128MB, FILENAME = 'C:\mssql\DefaultInstance\MSSQL10_50.MSSQLSERVER\MSSQL\DATA\tempdb3.ndf', FILEGROWTH = 128MB)
GO

ALTER DATABASE tempdb
  ADD FILE (NAME=tempdev4, SIZE = 128MB, FILENAME = 'C:\mssql\DefaultInstance\MSSQL10_50.MSSQLSERVER\MSSQL\DATA\tempdb4.ndf', FILEGROWTH = 128MB)
GO

ALTER DATABASE tempdb
  ADD FILE (NAME=tempdev5, SIZE = 128MB, FILENAME = 'C:\mssql\DefaultInstance\MSSQL10_50.MSSQLSERVER\MSSQL\DATA\tempdb5.ndf', FILEGROWTH = 128MB)
GO

ALTER DATABASE tempdb
  ADD FILE (NAME=tempdev6, SIZE = 128MB, FILENAME = 'C:\mssql\DefaultInstance\MSSQL10_50.MSSQLSERVER\MSSQL\DATA\tempdb6.ndf', FILEGROWTH = 128MB)
GO

ALTER DATABASE tempdb
  ADD FILE (NAME=tempdev7, SIZE = 128MB, FILENAME = 'C:\mssql\DefaultInstance\MSSQL10_50.MSSQLSERVER\MSSQL\DATA\tempdb7.ndf', FILEGROWTH = 128MB)
GO


-- Cleanup: drop all files, except the primary data files and the log file from TempDB
DECLARE @CurFileID tinyint = 3, @MaxFileID tinyint = (SELECT max(file_id) FROM sys.database_files), @sql nvarchar(256);
WHILE @CurFileID <= @MaxFileID
  BEGIN
    IF EXISTS(SELECT * FROM sys.database_files WHERE file_id = @CurFileID)
      BEGIN
        SELECT @sql = N'
            USE tempdb;
            DBCC SHRINKFILE(' + convert(nchar(1), @CurFileID) + N', EMPTYFILE);
            ALTER DATABASE tempdb REMOVE FILE ' + name + N';'
         FROM sys.database_files 
        WHERE file_id = @CurFileID;

        EXEC sp_executesql @sql;
      END
    SELECT @CurFileID += 1;
  END
GO
