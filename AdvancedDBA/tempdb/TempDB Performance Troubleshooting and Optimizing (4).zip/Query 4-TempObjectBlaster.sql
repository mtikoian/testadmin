SET ANSI_NULLS, QUOTED_IDENTIFIER ON;
GO
USE WaitDemo;
GO

ALTER PROC dbo.TempTableBlaster
AS
SET NOCOUNT ON;

CREATE TABLE #SysObjs(
object_id   int      NOT NULL PRIMARY KEY,
schema_id   int      NOT NULL,
name        sysname  NOT NULL,
create_date datetime NOT NULL,
type_desc   varchar(128) NOT NULL
);

CREATE TABLE #SysObjs2(
object_id   int      NOT NULL PRIMARY KEY,
schema_id   int      NOT NULL,
name        sysname  NOT NULL,
create_date datetime NOT NULL,
type_desc   varchar(128) NOT NULL
);

CREATE TABLE #SysObjs3(
object_id   int      NOT NULL PRIMARY KEY,
schema_id   int      NOT NULL,
name        sysname  NOT NULL,
create_date datetime NOT NULL,
type_desc   varchar(128) NOT NULL
);

CREATE NONCLUSTERED INDEX ix1 ON #SysObjs(name);
CREATE NONCLUSTERED INDEX ix1 ON #SysObjs2(name);
CREATE NONCLUSTERED INDEX ix1 ON #SysObjs3(name);

--INSERT #SysObjs(object_id, schema_id, name, create_date, type_desc)
--SELECT object_id, schema_id, name, create_date, type_desc
--  FROM sys.objects;

--INSERT #SysObjs2(object_id, schema_id, name, create_date, type_desc)
--SELECT top 10 object_id, schema_id, name, create_date, type_desc
--  FROM sys.objects;

--INSERT #SysObjs3(object_id, schema_id, name, create_date, type_desc)
--SELECT top 100 object_id, schema_id, name, create_date, type_desc
--  FROM sys.objects;


RETURN;
GO