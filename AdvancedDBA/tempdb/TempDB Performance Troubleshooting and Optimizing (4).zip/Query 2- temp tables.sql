USE tempdb
GO

SELECT COUNT(*) FROM sys.tables

CREATE TABLE #SQLSat(id int not null)

SELECT COUNT(*) FROM sys.tables
GO

DROP TABLE #SQLSat
GO




CHECKPOINT
GO

CREATE TABLE #SQLSat(id int not null)

SELECT * FROM fn_dblog(null, null)
GO
DROP TABLE #SQLSat
GO

