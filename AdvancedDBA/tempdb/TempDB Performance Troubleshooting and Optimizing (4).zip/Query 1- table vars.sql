-- Are @table variable stored in tempdb?
USE tempdb
GO

SELECT COUNT(*) FROM sys.tables
GO
SELECT COUNT(*) FROM sys.tables

DECLARE @SQLSat table(id int not null)

SELECT COUNT(*) FROM sys.tables
GO


-- more proof and info: the transaction log
CHECKPOINT
GO

DECLARE @SQLSat table(id int not null)

SELECT * FROM fn_dblog(null, null)
GO


