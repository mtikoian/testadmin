  SELECT
 CONVERT(decimal(4, 1), percent_complete) AS [%],
         estimated_completion_time/100/60 AS MinLeft,
         DB_NAME(st.dbid) AS [Database], convert(varchar(24), r.start_time, 20) AS StartTime, r.session_id, 
         r.wait_type, wait_resource, --count(*) as TheCount
         r.wait_time, r.reads, r.writes, r.logical_reads, r.cpu_time, convert(decimal(9,1), (r.granted_query_memory / 128.0)) AS MBytesRAM,
         ss.host_name, ss.login_name, ss.program_name,
         CASE ss.transaction_isolation_level
           WHEN 1 THEN 'NoLock' WHEN 2 THEN 'ReadCom' WHEN 3 THEN 'ReadRpt!' WHEN 4 THEN 'Srlize!' WHEN 5 THEN 'SnapShot' ELSE '???'
         END AS LckLvl,
         IsNull(OBJECT_NAME(st.objectid, st.dbid), 'Ad hoc') AS ObjectName,
        CASE WHEN r.statement_start_offset > DATALENGTH(st.text) THEN st.text
        ELSE SUBSTRING(st.text, (r.statement_start_offset/2)+1, 
          ((CASE r.statement_end_offset
            WHEN -1 THEN DATALENGTH(st.text)
            ELSE r.statement_end_offset
            END - r.statement_start_offset)/2) + 1) 
         END AS CurrentStatement 
    FROM sys.dm_exec_connections c  INNER JOIN
         sys.dm_exec_sessions    ss ON c.session_id = ss.session_id INNER JOIN
         sys.dm_exec_requests    r  ON ss.session_id = r.session_id CROSS APPLY
         sys.dm_exec_sql_text(r.sql_handle) st
   WHERE r.session_id > 45 --and wait_time > 0
   ORDER BY r.start_time --wait_time DESC
