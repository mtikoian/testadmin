create database tests;
go

use tests;
go

--setup test objects
/****** Object:  Table [dbo].[test]    Script Date: 6/3/2014 11:03:37 AM ******/
DROP TABLE [dbo].[test]
GO

/****** Object:  Table [dbo].[test]    Script Date: 6/3/2014 11:03:37 AM ******/
CREATE TABLE [dbo].[test](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[data] [nvarchar](max) NULL
	)

GO

/* Create some test data. Very simple, designed to give us a table with ~500 MB in it. */
set nocount on
go

insert tests.dbo.test ([data])
	select REPLICATE(CONVERT(nvarchar(max), 'A'), 2500000)
	union
	select REPLICATE(CONVERT(nvarchar(max), 'B'), 2500000)
	union
	select REPLICATE(CONVERT(nvarchar(max), 'C'), 2500000)
	union
	select REPLICATE(CONVERT(nvarchar(max), 'D'), 2500000)
GO 25

-- Use dm_db_partition_stats check table size
SELECT SUM(stat.used_page_count) * 8 / 1024 MBs
FROM sys.dm_db_partition_stats stat
WHERE stat.[object_id] = object_id('dbo.test')



/* START DEMOS */

/* 
	dm_db_task_space_usage returns page allocation and deallocation activity by task for a database.
	For these demos, we can use it to demonstrate when this SPID is causing pages to be allocated for objects in tempdb.
	We use the intrinsic @@SPID value and the database_id of 2, which is the database_id for tempdb.
*/

--Table variables
SELECT user_objects_alloc_page_count [Before] 
FROM sys.dm_db_task_space_usage 
WHERE session_id = @@SPID and database_id = 2

DECLARE @tmp TABLE(id int)
	INSERT INTO @tmp(id)
	SELECT TOP 5000 x.object_id
	FROM sys.all_objects x
	CROSS JOIN sys.all_objects y

SELECT user_objects_alloc_page_count [During] 
FROM sys.dm_db_task_space_usage 
WHERE session_id = @@SPID and database_id = 2

SELECT TOP 5000 x.object_id
INTO #tmp
FROM sys.all_objects x
CROSS JOIN sys.all_objects y

SELECT user_objects_alloc_page_count [After] 
FROM sys.dm_db_task_space_usage 
WHERE session_id = @@SPID and database_id = 2

drop table #tmp

GO
-- End table Variables

--Sorts
SET NOCOUNT ON
USE tempdb
GO

SELECT internal_objects_alloc_page_count * 8 / 1024 [Before MBs] 
FROM sys.dm_db_task_space_usage 
WHERE session_id = @@SPID and database_id = 2

select top 1000 * 
from (SELECT TOP 5000 * FROM sys.all_columns) col cross join (SELECT TOP 1000 * FROM sys.all_objects) obj 
order by newid()

SELECT internal_objects_alloc_page_count * 8 / 1024 [After MBs] 
FROM sys.dm_db_task_space_usage 
WHERE session_id = @@SPID and database_id = 2

GO
-- End Sorts

--Cursor
SET NOCOUNT ON
USE tempdb
GO

SELECT internal_objects_alloc_page_count * 8 / 1024 [Before MBs] 
FROM sys.dm_db_task_space_usage 
WHERE session_id = @@SPID and database_id = 2

DECLARE c CURSOR STATIC FOR SELECT [data] FROM tests.dbo.test
OPEN c

SELECT internal_objects_alloc_page_count * 8 / 1024 [After MBs] 
FROM sys.dm_db_task_space_usage 
WHERE session_id = @@SPID and database_id = 2

CLOSE c
DEALLOCATE c

SELECT internal_objects_dealloc_page_count * 8 / 1024 [Deallocate MBs] 
FROM sys.dm_db_task_space_usage 
WHERE session_id = @@SPID and database_id = 2
GO
--End Cursor

-- Trigger
use tests
go
create trigger tUpdateTest on dbo.test for update as

	declare @var nvarchar(max)

	declare @pages int

	SELECT @pages = internal_objects_alloc_page_count * 8 / 1024
	FROM sys.dm_db_task_space_usage 
	WHERE session_id = @@SPID and database_id = 2

	print '[During MBs] ' + cast(@pages as varchar)

	select @var = deleted.[data] from deleted
go

SELECT internal_objects_alloc_page_count * 8 / 1024 [Before MBs] 
FROM sys.dm_db_task_space_usage 
WHERE session_id = @@SPID and database_id = 2

update tests.dbo.test set [data] = [data] + 'x'
-- End Trigger


--LOB Variable
USE tests
GO

DECLARE @bigVar nvarchar(max) = '';

WHILE(LEN(@bigVar) < 1000000)
BEGIN
	SELECT @bigVar = @bigVar + REPLICATE(CONVERT(nvarchar(max), 'x'), 100000);

	SELECT LEN(@bigVar) [Variable Length], internal_objects_alloc_page_count * 8 / 1024 [TempDB MBs] 
	FROM sys.dm_db_task_space_usage 
	WHERE session_id = @@SPID and database_id = 2
END
-- End LOB Variable


--temp table caching
USE tests;
GO

--proc creates a temp table, populates it and drops it
--drop procedure cachingdemo;
create proc cachingdemo as
begin
	create table #tmp (id int not null, data nvarchar(128));
	insert into 
		#tmp (id, data) 
	values
		(1,'Jason'),
		(2,'Angie'),
		(3,'Niko'),
		(4,'Jesse'),
		(5,'Caitlin'),
		(6,'Savannah');

	create unique clustered index ixtmp on #tmp(id); 

	drop table #tmp;
end
GO

--call proc in a loop, while watching temp table creation rate counter
exec cachingdemo;
go 100

--make temp table cacheable
alter proc cachingdemo as
begin
	create table #tmp (id int not null primary key, data nvarchar(128));
	insert into 
		#tmp (id, data) 
	values
		(1,'Jason'),
		(2,'Angie'),
		(3,'Niko'),
		(4,'Jesse'),
		(5,'Caitlin'),
		(6,'Savannah');

	drop table #tmp;
end
GO

--run test again
exec cachingdemo;
go 100

-- End temp table caching