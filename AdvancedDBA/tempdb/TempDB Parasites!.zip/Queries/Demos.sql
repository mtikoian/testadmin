use tests;
go

--setup test objects
/****** Object:  Table [dbo].[test]    Script Date: 6/3/2014 11:03:37 AM ******/
DROP TABLE [dbo].[test]
GO

/****** Object:  Table [dbo].[test]    Script Date: 6/3/2014 11:03:37 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[test](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[data] [nvarchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

/* Create some test data. Very simle, designed to give us a table with ~500 MB in it. */
insert tests.dbo.test ([data])
	select REPLICATE(CONVERT(nvarchar(max), 'A'), 2500000)
	union
	select REPLICATE(CONVERT(nvarchar(max), 'B'), 2500000)
	union
	select REPLICATE(CONVERT(nvarchar(max), 'C'), 2500000)
	union
	select REPLICATE(CONVERT(nvarchar(max), 'D'), 2500000)
go 25

-- Use dm_db_partition_stats check table size
SELECT SUM(stat.used_page_count) * 8 / 1024 MBs
FROM sys.dm_db_partition_stats stat
WHERE stat.[object_id] = object_id('dbo.test')



/* START DEMOS */

/* 
	dm_db_task_space_usage returns page allocation and deallocation activity by task for a database.
	For these demos, we can use it to demonstrate when this SPID is causing pages to be allocated for user objects in tempdb.
	We use the intrinsic @@SPID value and the database_id of 2, which is the database_id for tempdb.
*/

--Table variables
SELECT user_objects_alloc_page_count [Before] 
FROM sys.dm_db_task_space_usage 
WHERE session_id = @@SPID and database_id = 2

DECLARE @tmp TABLE(id int)
	INSERT INTO @tmp(id)
	SELECT TOP 5000 x.object_id
	FROM sys.all_objects x
	CROSS JOIN sys.all_objects y

SELECT user_objects_alloc_page_count [Before] 
FROM sys.dm_db_task_space_usage 
WHERE session_id = @@SPID and database_id = 2

	SELECT TOP 5000 x.object_id
	INTO #tmp
	FROM sys.all_objects x
	CROSS JOIN sys.all_objects y

	drop table #tmp

SELECT user_objects_alloc_page_count [After] 
FROM sys.dm_db_task_space_usage 
WHERE session_id = @@SPID and database_id = 2

GO
-- End table Variables



--Cursor
SET NOCOUNT ON
USE tempdb

GO

SELECT internal_objects_alloc_page_count * 8 / 1024 [Before MBs] 
FROM sys.dm_db_task_space_usage 
WHERE session_id = @@SPID and database_id = 2

DECLARE c CURSOR STATIC FOR SELECT [data] FROM tests.dbo.test
OPEN c

SELECT internal_objects_alloc_page_count * 8 / 1024 [After MBs] 
FROM sys.dm_db_task_space_usage 
WHERE session_id = @@SPID and database_id = 2

CLOSE c
DEALLOCATE c

SELECT internal_objects_dealloc_page_count * 8 / 1024 [Deallocate MBs] 
FROM sys.dm_db_task_space_usage 
WHERE session_id = @@SPID and database_id = 2

GO
--End Cursor



--Sorts
SET NOCOUNT ON
USE tempdb
GO

SELECT internal_objects_alloc_page_count * 8 / 1024 [Before MBs] 
FROM sys.dm_db_task_space_usage 
WHERE session_id = @@SPID and database_id = 2

select top 5000 * 
from (SELECT TOP 5000 * FROM sys.all_columns) col cross join (SELECT TOP 5000 * FROM sys.all_objects) obj 
order by newid()

SELECT internal_objects_alloc_page_count * 8 / 1024 [After MBs] 
FROM sys.dm_db_task_space_usage 
WHERE session_id = @@SPID and database_id = 2

GO
-- End Sorts


-- Trigger
use tests
go
create trigger tUpdateTest on dbo.test for update as

	declare @var nvarchar(max)

	declare @pages int

	SELECT @pages = internal_objects_alloc_page_count * 8 / 1024
	FROM sys.dm_db_task_space_usage 
	WHERE session_id = @@SPID and database_id = 2

	print '[During MBs] ' + cast(@pages as varchar)

	select @var = deleted.[data] from deleted

go

SELECT internal_objects_alloc_page_count * 8 / 1024 [Before MBs] 
FROM sys.dm_db_task_space_usage 
WHERE session_id = @@SPID and database_id = 2

update tests.dbo.test set [data] = [data] + 'x'

-- Use dm_tran_top_version_generators to show that my test table is a top generator of version data
SELECT QUOTENAME(OBJECT_SCHEMA_NAME(p.object_id)) + '.' + QUOTENAME(OBJECT_NAME(p.object_id)), vs.aggregated_record_length_in_bytes
FROM sys.dm_tran_top_version_generators AS vs
INNER JOIN sys.partitions AS p ON vs.rowset_id = p.hobt_id
WHERE vs.database_id = DB_ID()
AND p.index_id IN (0,1);
-- End Trigger


--LOB Variable
USE tests
GO

DECLARE @bigVar nvarchar(max) = '';

WHILE(LEN(@bigVar) < 1000000)
BEGIN
	SELECT @bigVar = @bigVar + REPLICATE(CONVERT(nvarchar(max), 'x'), 100000);

	SELECT LEN(@bigVar) [Variable Length], internal_objects_alloc_page_count * 8 / 1024 [TempDB MBs] 
	FROM sys.dm_db_task_space_usage 
	WHERE session_id = @@SPID and database_id = 2
END
-- End LOB Variable