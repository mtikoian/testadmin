DECLARE @t TABLE (i int, c char(100))

DBCC TRACEON(1200,-1,3604)

INSERT INTO @t (i, c)

VALUES (1, REPLICATE('A',100)), (2, REPLICATE('A',100))

DBCC TRACEOFF(1200,-1,3604)

GO

--Paul R
DECLARE @t TABLE (i int, c char(100)) 
INSERT INTO @t (i, c)

VALUES (1, REPLICATE('A',100))

SELECT i
FROM @T 
OPTION (RECOMPILE, QUERYTRACEON 3604, QUERYTRACEON 8607) --Trace flag 8607 shows the optimization output tree