DBCC TRACEOFF (1117, 1118)
GO
USE UG_Demo
GO

IF OBJECT_ID('CreateTmpTable') IS NOT NULL
DROP PROC CreateTmpTable
GO

CREATE PROC CreateTmpTable 
AS
BEGIN
SET NOCOUNT ON

CREATE TABLE #TBL (Id int Identity PRIMARY KEY,
C char(10) default 'abcdefg',
D datetime2 default sysdatetime())
DECLARE @i int =0
WHILE @i < 10
BEGIN
INSERT #TBL default values
SET @i +=1
END

END
GO

IF OBJECT_ID('RUN100CreateTmpTable') IS NOT NULL
DROP PROC RUN100CreateTmpTable
GO

CREATE PROC RUN100CreateTmpTable 
AS
BEGIN
SET NOCOUNT ON

DECLARE @i int =0
WHILE @i < 100
BEGIN
EXEC CreateTmpTable
SET @i +=1
END
END
GO

EXEC RUN100CreateTmpTable

-- Clears the wait statistics
DBCC SQLPERF ('sys.dm_os_wait_stats', CLEAR)
GO

--USE SQL Query Stress (A.M)
--EXEC CreateTmpTable

-- check num of proccess 
EXEC SP_WHO2

---check waites

SELECT * FROM sys.dm_exec_requests WHERE session_id > 50
SELECT session_id, wait_type, wait_duration_ms, resource_description 
FROM   sys.dm_os_waiting_tasks
WHERE wait_type LIKE '%LAT%'
SELECT session_id, wait_type, wait_duration_ms, resource_description 
FROM   sys.dm_os_waiting_tasks
WHERE  resource_description like '2:%'


DBCC traceon (3604)
GO
--examine the details of the page
DBCC PAGE (2,1, 120, -1)
GO

DBCC TRACEOFF (3604)
GO
