--Win 1
---
CREATE TABLE #table (i INT)
GO
SELECT name FROM  tempdb.sys.tables

CREATE TABLE #table2 (i INT)

SELECT name FROM  tempdb.sys.tables

INSERT #table
        ( i )
VALUES  ( 0 )
GO 3

CREATE TABLE ##table ( i INT)

INSERT ##table
        ( i )
VALUES  ( 1 )
GO 3
---
