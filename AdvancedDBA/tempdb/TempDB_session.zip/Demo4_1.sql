
USE SalesDB;
GO

-- Large query spill to tempdb
--
SELECT S.*, P.* from Sales S
JOIN Products P ON P.ProductID = S.ProductID
ORDER BY P.Name;
GO

-- Go troubleshoot...
