USE tempdb
go
if OBJECT_ID('tempdb..#DontbProc') is not null DROP PROC #DontbProc
GO

CREATE Proc #DontbProc 
AS
SELECT t.object_id,
       t.name,
       p.rows,
       a.type_desc,
       a.total_pages,
       a.used_pages,
       a.data_pages,
       p.data_compression_desc
FROM   tempdb.sys.partitions AS p
       INNER JOIN tempdb.sys.system_internals_allocation_units AS a
         ON p.hobt_id = a.container_id
       INNER JOIN tempdb.sys.tables AS t
         ON t.object_id = p.object_id
       INNER JOIN tempdb.sys.columns AS c
         ON c.object_id = p.object_id
WHERE  c.name = 'DubiOrNot2b'
GO

DECLARE  @DontbTBL TABLE (
 DubiOrNot2b int identity primary key
,D char(100) DEFAULT REPLICATE('D',100)
,U char(100) DEFAULT REPLICATE('U',100)
,B char(100) DEFAULT REPLICATE('B',100)
,I char(100) DEFAULT REPLICATE('i',100)
,DubiImage varchar(MAX) DEFAULT REPLICATE(cast('?' as varchar(1)),10000)
,FFU varchar(8000) DEFAULT REPLICATE('FFU',1000)
)

insert @DontbTBL Default values
insert @DontbTBL Default values
insert @DontbTBL Default values
insert @DontbTBL Default values
insert @DontbTBL Default values
insert @DontbTBL Default values
insert @DontbTBL Default values
insert @DontbTBL Default values
insert @DontbTBL Default values
insert @DontbTBL Default values
insert @DontbTBL Default values
insert @DontbTBL Default values


select * from @DontbTBL

exec #DontbProc
