---Win 3
INSERT ##table VALUES(2)
GO
CREATE PROC p_temp (@i int=9)
AS 
BEGIN
INSERT ##table VALUES(@i)
END 
GO
EXEC dbo.p_temp  @i = 3




