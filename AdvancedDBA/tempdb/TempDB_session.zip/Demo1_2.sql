--Win 2


BEGIN TRAN
INSERT ##table
        ( i )
VALUES  ( 5 )
GO 


-----
/*
INSERT ##table
        ( i )
VALUES  ( 6 )
GO 

SELECT * FROM ##table
*/


COMMIT
---
