--TraceFlag 1117


USE master
GO
IF db_id('TF1117')>0
	Drop Database TF1117
GO
Create Database TF1117
ON  Primary
( NAME = N'TF1117', Filename = N'D:\SQL2K12\Dados\1117.mdf'
, SIZE = 3072KB , MAXSIZE = UNLIMITED, FILEGROWTH = 1024KB ), 
( NAME = N'TF1117_1', Filename = N'D:\SQL2K12\Dados\1117_1.ndf'
, SIZE = 1024KB , MAXSIZE = UNLIMITED, FILEGROWTH = 1024KB ), 
( NAME = N'TF1117_2', Filename = N'D:\SQL2K12\Dados\1117_2.ndf'
, SIZE = 1024KB , MAXSIZE = UNLIMITED, FILEGROWTH = 1024KB ), 
( NAME = N'TF1117_3', Filename = N'D:\SQL2K12\Dados\1117_3.ndf'
, SIZE = 1024KB , MAXSIZE = UNLIMITED, FILEGROWTH = 1024KB )
LOG ON
( NAME = N'TF1117_log', FILENAME = N'D:\SQL2K12\Log\1117_log.ldf'
, SIZE = 1024KB , MAXSIZE = 2048GB , FILEGROWTH = 10%)
GO
Use TF1117
Go
--Tamanho inicial
Select name, (size*8)/1024 'Size in MB' From TF1117.sys.database_files 
--Criando e populando a tabela 
GO
Create Table t1 (name Char(8000))
GO
Insert t1 Values ('TraceFlag1117')
GO 500
--Ap�s a execu��o
Select name, (size*8)/1024 'Size in MB' From TF1117.sys.database_files 
GO


/*
Ativando TraceFlag 1117

Dbcc Traceon(1117,-1)
Dbcc TraceOff(1117,-1)
*/


Use tempdb

Go

If Object_id('##teste','U')>0
	Drop Table ##teste

Go
Create table ##teste
(c1 char(8000))

Go
Insert into ##teste
values('B')



Select * from sys.tables
order by create_date desc

/*
	Ativando TraceFlag 3604 Retornar output

	Dbcc Traceon (3604,-1)
*/


Dbcc Extentinfo(2,357576312,-1)


/*
	Habilitando TraceFlag 1118 
	
	Dbcc Traceon(1118,-1)	
	Dbcc Traceoff(1118,-1)
*/



Insert into ##teste
values('B')


Dbcc Extentinfo(2,357576312,-1)

















/*Cache para tabelas temporar�rias em Procedures*/




use TempdbTest
go
 
set nocount on
go
 
 
-- Cria��o da Procedure
if object_id('test_temptable_caching') IS NOT NULL
     drop procedure test_temptable_caching;
go
create procedure test_temptable_caching
as
 
create table #t1 (c1 int, c2 int, c3 char(5000))
--create index foo on #t1(c1);
declare @i int
select @i = 0
while (@i < 10)
begin
     insert into #t1 values (@i, @i + 1000, 'hello')
     select @i = @i+1
end
Create nonclustered index IDX_teste on #t1(c1)
print 'Procedure Executada !!'
go
 
--Agora, se eu executar este procedimento armazenado em um loop, 
--o #table s� � criado na primeira execu��o. Voc� pode usar o seguinte script para saber quantas vezes o #table foi criado.

 
declare @QtdeTablesAntesDoTeste Int;

select @QtdeTablesAntesDoTeste=cntr_value
from sys.dm_os_performance_counters
where counter_name = 'Temp Tables Creation Rate';
 
 
declare @i int
select @i = 0
while (@i < 10)
begin
     exec  test_temptable_caching
     select @i = @i+1
end
 
Declare @table_counter_after_test Int;


select @table_counter_after_test=cntr_value
from sys.dm_os_performance_counters
where counter_name = 'Temp Tables Creation Rate';
 
print 'Qtde de tables tempor�rias criadas durante o teste: ' +
     convert( varchar(100), @table_counter_after_test-@QtdeTablesAntesDoTeste);




/*Somente em dois casos os objetos tempor�rios n�o s�o armazenados em cache 
 
 * Nomear constraints. 
 * DDL que afetam diretamente a tabela tempor�ria - Creade Index ou Create Statistics por exemplo.
 * Tabela criada em escopo diferente. (Ex: Criado por uma trigger.)
 * Quando a tabela tempor�ria for criado por SQL Din�mico, Ex: sp_executeSQL 'Create table #temp (c1 int)'
 * Recompile na procedure.

*/



--Trace Flag 1118--







