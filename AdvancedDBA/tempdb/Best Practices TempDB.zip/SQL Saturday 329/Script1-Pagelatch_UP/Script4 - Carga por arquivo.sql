
--Teste carga por arquivo.

--Drop table SampleTable

		
		USE testeTempdb;
		GO

		If Object_id('SampleTable','U')>0
			Drop Table SampleTable

		Create TAble SampleTable (
			c1 char(8000));
		GO

		Insert Into SampleTable Default Values;
		GO 10





--Adicionando outro Arquivo

/*

ALTER DATABASE tempdb
ADD FILE 
(
    NAME = Tempdb2,
    FILENAME = 'D:\SQL2K12\Tempdb\tempdb2.ndf',
    SIZE = 40MB,
    MAXSIZE = 100MB,
    FILEGROWTH = 10%
);

ALTER DATABASE tempdb
ADD FILE 
(
    NAME = Tempdb3,
    FILENAME = 'D:\SQL2K12\Tempdb\tempdb3.ndf',
    SIZE = 40MB,
    MAXSIZE = 100MB,
    FILEGROWTH = 10%
);


ALTER DATABASE tempdb
ADD FILE 
(
    NAME = Tempdb4,
    FILENAME = 'D:\SQL2K12\Tempdb\tempdb4.ndf',
    SIZE = 40MB,
    MAXSIZE = 100MB,
    FILEGROWTH = 10%
);


ALTER DATABASE tempdb
ADD FILE 
(
    NAME = Tempdb5,
    FILENAME = 'D:\SQL2K12\Tempdb\tempdb5.ndf',
    SIZE = 40MB,
    MAXSIZE = 100MB,
    FILEGROWTH = 10%
);


ALTER DATABASE tempdb
ADD FILE 
(
    NAME = Tempdb6,
    FILENAME = 'D:\SQL2K12\Tempdb\tempdb6.ndf',
    SIZE = 40MB,
    MAXSIZE = 100MB,
    FILEGROWTH = 10%
);

ALTER DATABASE tempdb
ADD FILE 
(
    NAME = Tempdb7,
    FILENAME = 'D:\SQL2K12\Tempdb\tempdb7.ndf',
    SIZE = 40MB,
    MAXSIZE = 100MB,
    FILEGROWTH = 10%
);

ALTER DATABASE tempdb
ADD FILE 
(
    NAME = Tempdb8,
    FILENAME = 'D:\SQL2K12\Tempdb\tempdb8.ndf',
    SIZE = 40MB,
    MAXSIZE = 100MB,
    FILEGROWTH = 10%
);

ALTER DATABASE tempdb
ADD FILE 
(
    NAME = Tempdb9,
    FILENAME = 'D:\SQL2K12\Tempdb\tempdb9.ndf',
    SIZE = 40MB,
    MAXSIZE = 100MB,
    FILEGROWTH = 10%
);

ALTER DATABASE tempdb
ADD FILE 
(
    NAME = Tempdb10,
    FILENAME = 'D:\SQL2K12\Tempdb\tempdb10.ndf',
    SIZE = 40MB,
    MAXSIZE = 100MB,
    FILEGROWTH = 10%
);

ALTER DATABASE tempdb
ADD FILE 
(
    NAME = Tempdb11,
    FILENAME = 'D:\SQL2K12\Tempdb\tempdb11.ndf',
    SIZE = 40MB,
    MAXSIZE = 100MB,
    FILEGROWTH = 10%
);

ALTER DATABASE tempdb
ADD FILE 
(
    NAME = Tempdb12,
    FILENAME = 'D:\SQL2K12\Tempdb\tempdb12.ndf',
    SIZE = 40MB,
    MAXSIZE = 100MB,
    FILEGROWTH = 10%
);


*/
GO

--Removendo Arquivos
/*
	Use Tempdb

	Dbcc Shrinkfile('Tempdb2',Emptyfile)
	
	Alter Database Tempdb
	Remove file Tempdb2 

	Dbcc Shrinkfile('Tempdb3',Emptyfile)
	
	Alter Database Tempdb
	Remove file Tempdb3 

	Dbcc Shrinkfile('Tempdb4',Emptyfile)
	
	Alter Database Tempdb
	Remove file Tempdb4 

	Dbcc Shrinkfile('Tempdb5',Emptyfile)
	
	Alter Database Tempdb
	Remove file Tempdb5 

	Dbcc Shrinkfile('Tempdb6',Emptyfile)
	
	Alter Database Tempdb
	Remove file Tempdb6

	Dbcc Shrinkfile('Tempdb7',Emptyfile)
	
	Alter Database Tempdb
	Remove file Tempdb7 

	Dbcc Shrinkfile('Tempdb8',Emptyfile)
	
	Alter Database Tempdb
	Remove file Tempdb8 

	Dbcc Shrinkfile('Tempdb9',Emptyfile)
	
	Alter Database Tempdb
	Remove file Tempdb9 

	Dbcc Shrinkfile('Tempdb10',Emptyfile)
	
	Alter Database Tempdb
	Remove file Tempdb10 

	Dbcc Shrinkfile('Tempdb11',Emptyfile)
	
	Alter Database Tempdb
	Remove file Tempdb11 


	Dbcc Shrinkfile('Tempdb12',Emptyfile)
	
	Alter Database Tempdb
	Remove file Tempdb12



*/

--Select * from sys.master_files
--sp_helpdb tempdb

/*
	Use Tempdb
	Alter Database Tempdb
	Modify file(name=tempdev,size=40MB)
*/



