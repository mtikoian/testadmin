
/*
USE master;
GO
DROP DATABASE testeTempdb;
GO

*/

If db_id('SampleTable')>0
	Drop database SampleTable

go

--CREATE DATABASE testeTempdb;
--GO


USE testeTempdb;
GO

If Object_id('SampleTable','U')>0
	Drop Table SampleTable

CREATE TABLE SampleTable (
	c1 INT IDENTITY);
GO

INSERT INTO SampleTable DEFAULT VALUES;
GO 10






--Drop table SampleTable

--Adicionando outro Arquivo

/*

ALTER DATABASE tempdb
ADD FILE 
(
    NAME = Tempdb2,
    FILENAME = 'D:\SQL2K12\Tempdb\tempdb2.ndf',
    SIZE = 40MB,
    MAXSIZE = 100MB,
    FILEGROWTH = 10%
);

ALTER DATABASE tempdb
ADD FILE 
(
    NAME = Tempdb3,
    FILENAME = 'D:\SQL2K12\Tempdb\tempdb3.ndf',
    SIZE = 40MB,
    MAXSIZE = 100MB,
    FILEGROWTH = 10%
);


ALTER DATABASE tempdb
ADD FILE 
(
    NAME = Tempdb4,
    FILENAME = 'D:\SQL2K12\Tempdb\tempdb4.ndf',
    SIZE = 40MB,
    MAXSIZE = 100MB,
    FILEGROWTH = 10%
);


ALTER DATABASE tempdb
ADD FILE 
(
    NAME = Tempdb5,
    FILENAME = 'D:\SQL2K12\Tempdb\tempdb5.ndf',
    SIZE = 40MB,
    MAXSIZE = 100MB,
    FILEGROWTH = 10%
);


*/
GO

--Removendo Arquivos
/*
	Use Tempdb

	Dbcc Shrinkfile('Tempdb2',Emptyfile)
	
	Alter Database Tempdb
	Remove file Tempdb2 

	Dbcc Shrinkfile('Tempdb3',Emptyfile)
	
	Alter Database Tempdb
	Remove file Tempdb3 

	Dbcc Shrinkfile('Tempdb4',Emptyfile)
	
	Alter Database Tempdb
	Remove file Tempdb4 

	Dbcc Shrinkfile('Tempdb5',Emptyfile)
	
	Alter Database Tempdb
	Remove file Tempdb5 


*/

--Select * from sys.master_files
--sp_helpdb tempdb

/*
	Use Tempdb
	Alter Database Tempdb
	Modify file(name=tempdev,size=40MB)
*/



