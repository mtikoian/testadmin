--Simula��o Clientes

USE TesteTempdb;
GO

SET NOCOUNT ON;
GO

DECLARE @TableName  VARCHAR (128);
DECLARE @ExecString VARCHAR (8000);
DECLARE @a INT;

SELECT @TableName = '##Temp' + CAST (@@SPID AS VARCHAR);

WHILE (1=1)
BEGIN
	-- Calculate doc name length
	SELECT @ExecString = 'SELECT * INTO ' +
		@TableName +
		' FROM TesteTempdb..SampleTable';
		
	--SELECT @ExecString;
	EXEC (@ExecString);

	SELECT @ExecString = 'DROP TABLE ' +
		@TableName;
	
	EXEC (@ExecString);
	
	SELECT @a=COUNT (*) FROM TesteTempdb..SampleTable;
END;
GO