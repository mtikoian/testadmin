--Criando Extent Events para monitoramento.

If Exists(Select * From sys.server_event_sessions Where name = 'TempdbMonitorContencao')
    DROP EVENT SESSION TempdbMonitorContencao ON SERVER;
GO


---Criando o evento e definindo um predicado
Create Event Session TempdbMonitorContencao 
On Server 
Add Event sqlserver.latch_suspend_end --> Objeto do evento
(Where ( database_id=2 AND duration >0 AND (mode=2 OR mode=3) 
AND 
           (page_id < 4 OR -- Paginas bitmap de aloca��o inicial
            package0.divides_by_uint64(page_id, 8088) OR --p�ginas PFS
            package0.divides_by_uint64(page_id, 511232) OR  --p�ginas GAM
            page_id=511233 OR  --2� p�ginas SGAM 4GB-8GB
            page_id=1022465 OR --3� p�ginas SGAM 8GB-12GB
            page_id=1533697 OR --4� p�ginas SGAM 12GB-16GB
            page_id=2044929 OR --5� p�ginas SGAM 16GB-20GB
            page_id=2556161 OR --6� p�ginas SGAM page 20GB-24GB
            page_id=3067393 OR --7� p�ginas SGAM page 24GB-28GB
            page_id=3578625) --8� p�ginas SGAM 28GB-32GB
           )
       )

--Capturando eventos 

--Alvos de Sess�es - Para grava��o dos eventos em disco. Opera��o ass�ncrona.
Add Target package0.Histogram( 
Set filtering_event_name = N'sqlserver.latch_suspend_end' , 
       source = N'page_id' , 
       source_type = 0 ), --1 = Evento e 0 = A��o

Add Target package0.event_file ( 
Set filename = 'C:\SQL2K12\Backup\TempdbMonitorContencao.xel' , 
    max_file_size = 50 , 
    max_rollover_files = 10 , 
    increment = 10 )

--Definindo op��o de sess�o --Podemos definir sem esse par�metro, por�m, 
--precisarismos nos atentar sempre que o servi�o do SQL for iniciado
--WITH (STARTUP_STATE=ON);


/*No BOL existe refer�ncia para cada par�metro desejado*/









---Iniciando
ALTER EVENT SESSION TempdbMonitorContencao
ON SERVER
STATE=Start;



--Select * from sys.server_event_sessions


--Monitorando p�ginas com maior Wait_count
SELECT 
   n.value('(value)[1]', 'bigint') AS page_id,
   n.value('(@count)[1]', 'bigint') AS wait_count
FROM
(  SELECT CAST(target_data AS XML) target_data
   FROM sys.dm_xe_sessions AS s 
   INNER JOIN sys.dm_xe_session_targets AS t
       ON s.address = t.event_session_address
   WHERE s.name = N'TempdbMonitorContencao'
   AND t.target_name = N'histogram' ) AS tab
CROSS APPLY target_data.nodes('HistogramTarget/Slot') AS q(n);



---Monitorando com descri��es de p�ginas
SELECT 
n.value('(value)[1]', 'bigint') AS page_id,
CASE 
WHEN n.value('(value)[1]', 'bigint') = 1 THEN 'PFS'
WHEN n.value('(value)[1]', 'bigint') % 8088 = 0 THEN 'PFS'
WHEN n.value('(value)[1]', 'bigint') = 2 THEN 'GAM'
WHEN n.value('(value)[1]', 'bigint') % 511232 = 0 THEN 'GAM'
WHEN n.value('(value)[1]', 'bigint') = 3 THEN 'SGAM'
WHEN n.value('(value)[1]', 'bigint') % 511232 + 1 = 0 THEN 'SGAM'
ELSE 'Desconhecido'
END AS PageType,
n.value('(@count)[1]', 'bigint') AS wait_count
FROM
( SELECT CAST(target_data AS XML) target_data
FROM sys.dm_xe_sessions AS s 
INNER JOIN sys.dm_xe_session_targets AS t
ON s.address = t.event_session_address
WHERE s.name = N'TempdbMonitorContencao'
AND t.target_name = N'histogram' ) AS tab
CROSS APPLY target_data.nodes('HistogramTarget/Slot') AS q(n); 




--SELECT 
--    SUM(n.value('(data[@name="duration"]/value)[1]', 'int')) AS duration
--FROM 
--(SELECT
--    CAST(event_data AS XML) AS event_data
--FROM sys.fn_xe_file_target_read_file('C:\SQL2K12\Backup\TempdbMonitorContencao*xel',
--       'See its not used', -- No metadata file required in 2012
--       NULL,
--       NULL)
--) AS tab
--CROSS APPLY event_data.nodes('event') AS q(n)






Select map_key, map_value
From sys.dm_xe_map_values
Where name = N'latch_mode'
And map_value IN (N'UP', N'SH',N'EX');
   



   --
SELECT S.*, P.* from Sales S
JOIN Products P ON P.ProductID = S.ProductID
ORDER BY P.Name;
GO
