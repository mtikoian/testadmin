

---Monitorando Spills Tempdb
SELECT 
	GETDATE () AS [Date],
	tsu.session_id AS [SessionID],
	tsu.exec_context_id AS [ExecContextID],
	(tsu.user_objects_alloc_page_count - tsu.user_objects_dealloc_page_count) AS [UserPages],
	ROUND (CONVERT (FLOAT, (tsu.user_objects_alloc_page_count - tsu.user_objects_dealloc_page_count) * 8) / 1024.0, 2) AS [UserMB],
	(tsu.internal_objects_alloc_page_count - tsu.internal_objects_dealloc_page_count) AS [InternalPages],
	ROUND (CONVERT (FLOAT, (tsu.internal_objects_alloc_page_count - tsu.internal_objects_dealloc_page_count) * 8) / 1024.0, 2) AS [InternalMB],
	er.plan_handle AS [Plan],
	est.text AS [Text]
FROM
	sys.dm_db_task_space_usage tsu
	JOIN sys.dm_exec_requests er
		ON er.session_id = tsu.session_id
	CROSS APPLY sys.dm_exec_sql_text (er.sql_handle) est
/*
WHERE
	-- Look for anything using 128MB or more
	((user_objects_alloc_page_count - user_objects_dealloc_page_count) +
		(internal_objects_alloc_page_count - internal_objects_dealloc_page_count)) >= 16384 --threshold a definir
*/
ORDER BY
	((user_objects_alloc_page_count - user_objects_dealloc_page_count) +
		(internal_objects_alloc_page_count - internal_objects_dealloc_page_count)) DESC;










		
-- Verificar plano problem�tico !
--
Select * From sys.dm_exec_query_plan
(0x06000C0087167F2300FB4DE60200000001000000000000000000000000000000000000000000000000000000);
GO






-- Go troubleshoot...

Select * from sys.dm_db_task_space_usage 


--Limpando o Log
Checkpoint



Select 
     [Current LSN], 
     Operation, 
     Context, 
     [Transaction ID], 
     [Log Record Fixed Length], 
     [Description] 
From fn_dblog (null, null); 
GO


