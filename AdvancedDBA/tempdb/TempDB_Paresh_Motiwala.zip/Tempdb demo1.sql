dbcc checkalloc
--The check statement was aborted. DBCC CHECKALLOC cannot be run on TEMPDB.


DBCC CHECKCATALOG
--The check statement was aborted. DBCC CHECKCATALOG cannot be run on TEMPDB.

Alter database tempdb
set offline
--Option 'OFFLINE' cannot be set in database 'tempdb'.


ALTER DATABASE TempDb SET  READ_ONLY WITH NO_WAIT
--Option 'READ_ONLY' cannot be set in database 'tempdb'.


ALTER DATABASE [tempdb] ADD FILEGROUP [secondary]
--User-defined filegroups are not allowed on "tempdb".	ALTER DATABASE statement not allowed within multi-statement transaction.

BACKUP DATABASE Tempdb TO  DISK = N'C:\Program Files\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\Backup\Tempdb.bak' WITH NOFORMAT, NOINIT,  NAME = N'AdventureWorksDW2014-Full Database Backup', SKIP, NOREWIND, NOUNLOAD,  STATS = 10
--Backup and restore operations are not allowed on database tempdb.


ALTER DATABASE Tempdb COLLATE SQL_Latin1_General_CP1_CS_AS
--Cannot alter the database 'Tempdb' because it is a system database.

USE [tempdb]
GO
DROP USER [guest]
GO
--Cannot disable access to the guest user in master or tempdb.

/*Script to Check TempDB Speed  
From Brent Ozar
This query hits the dynamic management function (DMF) sys.dm_io_virtual_file_stats 
for all of the TempDB data files and lists out how fast they�re responding to write (and read) requests:
*/
SELECT files.physical_name, files.name, 
  stats.num_of_writes, (1.0 * stats.io_stall_write_ms / stats.num_of_writes) AS avg_write_stall_ms,
  stats.num_of_reads, (1.0 * stats.io_stall_read_ms / stats.num_of_reads) AS avg_read_stall_ms
FROM sys.dm_io_virtual_file_stats(2, NULL) as stats
INNER JOIN master.sys.master_files AS files 
  ON stats.database_id = files.database_id
  AND stats.file_id = files.file_id
WHERE files.type_desc = 'ROWS'

---http://www.sqlservercentral.com/scripts/tempdb/72007/

;WITH task_space_usage AS (
    -- SUM alloc/delloc pages
    SELECT session_id,
           request_id,
           SUM(internal_objects_alloc_page_count) AS alloc_pages,
           SUM(internal_objects_dealloc_page_count) AS dealloc_pages
    FROM sys.dm_db_task_space_usage WITH (NOLOCK)
    WHERE session_id <> @@SPID
    GROUP BY session_id, request_id
)
SELECT TSU.session_id,
       TSU.alloc_pages * 1.0 / 128 AS [internal object MB space],
       TSU.dealloc_pages * 1.0 / 128 AS [internal object dealloc MB space],
       EST.text,
       -- Extract statement from sql text
       ISNULL(
           NULLIF(
               SUBSTRING(
                   EST.text, 
                   ERQ.statement_start_offset / 2, 
                   CASE WHEN ERQ.statement_end_offset < ERQ.statement_start_offset THEN 0 ELSE( ERQ.statement_end_offset - ERQ.statement_start_offset ) / 2 END
               ), ''
           ), EST.text
       ) AS [statement text],
       EQP.query_plan
FROM task_space_usage AS TSU
INNER JOIN sys.dm_exec_requests ERQ WITH (NOLOCK)
    ON  TSU.session_id = ERQ.session_id
    AND TSU.request_id = ERQ.request_id
OUTER APPLY sys.dm_exec_sql_text(ERQ.sql_handle) AS EST
OUTER APPLY sys.dm_exec_query_plan(ERQ.plan_handle) AS EQP
WHERE EST.text IS NOT NULL OR EQP.query_plan IS NOT NULL
ORDER BY 3 DESC, 5 DESC

----Marco Kleinert --Great query to find the contention for page allocation in tempdb!

Select session_id,
wait_type,
wait_duration_ms,
blocking_session_id,
resource_Description,
Descr.*
From sys.dm_os_waiting_tasks as waits inner join sys.dm_os_buffer_Descriptors as Descr
on LEFT(waits.resource_description, Charindex(':', waits.resource_description,0)-1) = Descr.database_id
and SUBSTRING(waits.resource_description, Charindex(':', waits.resource_description)+1,Charindex(':', waits.resource_description,Charindex(':', resource_description)+1)- (Charindex(':', resource_description)+1)) = Descr.[file_id]
and Right(waits.resource_description, Len(waits.resource_description) - Charindex(':', waits.resource_description, 3)) = Descr.[page_id]
Where wait_type Like 'PAGE%LATCH_%'

----What happened to my temp tables?
Begin transaction
select *
into #product3 from [Production].[Product]

select * from tempdb.sys.tables where name like'#product3%'
	  drop table #product3___________________________________________________________________________________________________________000000000005
--Commit transaction
--go 10000
--drop table #product3___________________________________________________________________________________________________________000000000004

select * from tempdb.dbo.sysobjects where name like '#prod%'






---The following procedure shows a total of nine cache objects created using CREATE TABLE #xyz syntax, table variables, and SELECT�INTO:

CREATE PROCEDURE dbo.Demo
AS
BEGIN
    CREATE TABLE #T1 (dummy int NULL);
    CREATE TABLE #T2 (dummy int NULL);
    CREATE TABLE #T3 (dummy int NULL);
 
    DECLARE @T1 AS TABLE (dummy int NULL);
    DECLARE @T2 AS TABLE (dummy int NULL);
    DECLARE @T3 AS TABLE (dummy int NULL);
    
    SELECT * INTO #T4 FROM #T1;
    SELECT * INTO #T5 FROM @T2;
    SELECT * INTO #T6 FROM #T3;
 
    WAITFOR DELAY '00:00:01'
END;
GO
DBCC FREEPROCCACHE;
EXECUTE dbo.Demo;
GO
SELECT
    t.* 
FROM tempdb.sys.tables AS t 
WHERE
t.name LIKE N'#[0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f]';

drop procedure dbo.demo

----Trace flag 1118 : the is_mixed_page_allocation_on value is 0 only for Tempdb. Indicating that tf 118 is enabled.
select Name, Is_mixed_page_allocation_on from sys.databases where Database_id in (1,2,3,4)


----Trace flag 1117 : the is_autogrow_all_files value is 1 for only tempdb. This indicates that it is the only system database that supports Autogrow_All_Files ON option.
select DB_ID as databaseName, is autogrow_all_files from sys.filegroups

