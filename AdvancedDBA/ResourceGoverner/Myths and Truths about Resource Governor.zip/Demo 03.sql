USE master
GO

-- Clean all RG previous configurations with the same name pools, 
-- workloads, functions and table.
IF  EXISTS ( SELECT name FROM sys.resource_governor_workload_groups WHERE name = N'wrkgroupDBA')
	DROP WORKLOAD GROUP [wrkgroupDBA];
GO
IF  EXISTS ( SELECT name FROM sys.resource_governor_resource_pools WHERE name = N'poolDBA')
	DROP RESOURCE POOL [poolDBA];
GO
ALTER RESOURCE GOVERNOR WITH (CLASSIFIER_FUNCTION = NULL);
GO
ALTER RESOURCE GOVERNOR RECONFIGURE;
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[rgclassifierDBA]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
	DROP FUNCTION [dbo].[rgclassifierDBA];
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[RG_DBAJobs]') AND type in (N'U'))
	DROP TABLE [dbo].[RG_DBAJobs];
GO


-- Alter Default Resource Pool to establish the CPU MIN & MAX.
-- This configuration will guaranttee 50% CPU resources to default group
-- and will be sharing the other 50% when needed.
ALTER RESOURCE POOL [default] 
WITH
(
	MAX_CPU_PERCENT = 100,
	MIN_CPU_PERCENT = 50 
)
GO
-- Create Resource Pool to limit CPU resources for DBA Jobs.
CREATE RESOURCE POOL poolDBA
WITH
(
	MAX_CPU_PERCENT = 90,
	MIN_CPU_PERCENT = 50
)
GO

-- Create Workload Group to hold connections from DBA Jobs executions and assign resource pool.
CREATE WORKLOAD GROUP wrkgroupDBA
USING poolDBA
GO

-- Create DBA Job's collection.
CREATE TABLE dbo.RG_DBAJobs
(
	job_id 	UNIQUEIDENTIFIER,
	name 		SYSNAME,
	match_string NVARCHAR(256) PRIMARY KEY
);
GO
INSERT dbo.RG_DBAJobs
(
	job_id, name, match_string
)
SELECT
	job_id, name, N'%SQLAgent - TSQL JobStep (Job ' 
	+ CONVERT(VARCHAR(36), CONVERT(BINARY(16), job_id), 1) + '%'
FROM msdb.dbo.sysjobs
WHERE name like 'DBA%';
GO

-- Create Classification UDF to determine when a DBA Job will run.
CREATE FUNCTION rgclassifierDBA() 
RETURNS SYSNAME
WITH SCHEMABINDING
AS
BEGIN
	DECLARE 
		@app NVARCHAR(256) = APP_NAME(),
		@grp_name SYSNAME = N'default';
	
	IF @app LIKE N'%TSQL JobStep%'
	BEGIN
		IF EXISTS 
		(
			SELECT 1
				FROM dbo.RG_DBAJobs
				WHERE @app LIKE match_string
		)
		BEGIN
			SET @grp_name = N'wrkgroupDBA';
		END
	END
	RETURN (@grp_name);
END
GO

-- Register classifier function with Resource Governor
ALTER RESOURCE GOVERNOR WITH (CLASSIFIER_FUNCTION = dbo.rgclassifierDBA);

-- Finally apply changes.
ALTER RESOURCE GOVERNOR RECONFIGURE;

/**
IMPORTANT: Restart SQL Agent in order to recycle all SQL Agent connections 
and they can be correctly mapped to the DBA workload pool
**/


/*******************************************************/
/***Reviewing configurations and debuging connections***/
/*******************************************************/
USE master
GO
SELECT * FROM sys.resource_governor_resource_pools
SELECT * FROM sys.resource_governor_workload_groups
GO

--- Get the classifier function Id and state (enabled).
SELECT * FROM sys.resource_governor_configuration
GO

--- Get the classifer function name and the name of the schema
--- that it is bound to.
SELECT 
      object_schema_name(classifier_function_id) AS [schema_name],
      object_name(classifier_function_id) AS [function_name]
FROM sys.dm_resource_governor_configuration

--Obtain the current runtime data for the resource pools and workload 
--groups by using the following query.
SELECT * FROM sys.dm_resource_governor_resource_pools
SELECT * FROM sys.dm_resource_governor_workload_groups
GO

--Find out what sessions are in each group by using the following query.
SELECT s.group_id
		,CAST(g.name as nvarchar(100))
		,s.session_id, s.login_time
		,CAST(s.host_name as nvarchar(100))
		,CAST(s.program_name AS nvarchar(100))
  FROM sys.dm_exec_sessions s
INNER JOIN sys.dm_resource_governor_workload_groups g
          ON g.group_id = s.group_id
ORDER BY g.name
GO

--Find out which requests are in each group by using the following query.
SELECT r.group_id
		,g.name group_name
		,r.status
		,r.session_id
		,r.request_id
		,r.start_time
		,r.command
		,r.sql_handle
		,t.text 
 FROM sys.dm_exec_requests r
INNER JOIN sys.dm_resource_governor_workload_groups g
            ON g.group_id = r.group_id
CROSS APPLY sys.dm_exec_sql_text(r.sql_handle) AS t
ORDER BY g.name
GO

/***
If you want to monitor how each group is consuming CPU resources
on the fly, open Perfmon and review the following counters:

\SQL Server:Resource Pool Stats(default)\CPU usage %
\SQL Server:Resource Pool Stats(poolDBA)\CPU usage %
\SQL Server:Resource Pool Stats(default)\CPU usage target %
\SQL Server:Resource Pool Stats(poolDBA)\CPU usage target %

Note: You can query these values as well from sys.dm_os_performance_counters
***/