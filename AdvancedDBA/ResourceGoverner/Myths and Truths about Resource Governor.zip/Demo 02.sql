/******* Changing RG parameters on the fly *******/ 

-- 1. Open 2 new sessions and run a Query to stress CPU.
--    One session needs to be opened with Login "A" and the other one with "B".

-- 2. Open Perfmon and review the following counters:
-- \SQL Server:Resource Pool Stats(PoolA)\CPU usage %
-- \SQL Server:Resource Pool Stats(PoolB)\CPU usage %

-- 3. Set MIN_CPU_PERCENT on PoolA
ALTER RESOURCE POOL PoolA
WITH (MIN_CPU_PERCENT = 70)
GO
ALTER RESOURCE GOVERNOR RECONFIGURE
GO

-- 4. Check Perfmon again and notice the % on all threads and discuss why they are taking only 50% of total CPU time.

-- 6. Affinitize CPU to pools (***New feature on SQL 2012***). Distribute Pools across cores.

ALTER RESOURCE POOL PoolA
WITH (AFFINITY SCHEDULER = (0))
GO
ALTER RESOURCE POOL PoolB
WITH (AFFINITY SCHEDULER = (1))
GO
ALTER RESOURCE GOVERNOR RECONFIGURE
GO

--7. 
--   a) Notice how both sessions are using 50% (50 + 50 = 100)
--   a) Notice how both sessions are using 100% CPU, even with the MIN_CPU_PERCENT = 70

-- 8. Revert CPU affinitize
ALTER RESOURCE POOL PoolA
WITH (AFFINITY SCHEDULER = (0))
GO
ALTER RESOURCE POOL PoolB
WITH (AFFINITY SCHEDULER = (0))
GO
ALTER RESOURCE GOVERNOR RECONFIGURE
GO

--9. Disconnect Session A, notice how Session B will take all CPU % again.

--10. Set a hard cap to CPU on Session B.
ALTER RESOURCE POOL PoolB
WITH (CAP_CPU_PERCENT=30)
ALTER RESOURCE GOVERNOR RECONFIGURE
GO

--11. Look back at Perfmon and check how Sessions B was affectted. 
--    A hard cap was set up, no matter what sessions are running, session b will not raise 30%.

--12. Clean

ALTER RESOURCE POOL PoolB
WITH (CAP_CPU_PERCENT=100)
ALTER RESOURCE POOL PoolA
WITH (MIN_CPU_PERCENT = 0)
GO
ALTER RESOURCE GOVERNOR RECONFIGURE
GO