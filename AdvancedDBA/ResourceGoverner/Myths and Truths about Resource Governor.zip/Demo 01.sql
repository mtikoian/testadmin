USE master
GO

-- Clean all previous RG configurations and logins.
IF  EXISTS (SELECT name FROM sys.resource_governor_workload_groups WHERE name = N'wrkgroupA')
	DROP WORKLOAD GROUP [wrkgroupA];
GO
IF  EXISTS ( SELECT name FROM sys.resource_governor_resource_pools WHERE name = N'poolA')
	DROP RESOURCE POOL [poolA];
GO
IF  EXISTS (SELECT name FROM sys.resource_governor_workload_groups WHERE name = N'wrkgroupB')
	DROP WORKLOAD GROUP [wrkgroupB];
GO
IF  EXISTS ( SELECT name FROM sys.resource_governor_resource_pools WHERE name = N'poolB')
	DROP RESOURCE POOL [poolB];
GO
ALTER RESOURCE GOVERNOR WITH (CLASSIFIER_FUNCTION = NULL);
GO
ALTER RESOURCE GOVERNOR RECONFIGURE;
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[udf_LoginClassifier]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
	DROP FUNCTION [dbo].[udf_LoginClassifier];
GO

IF  EXISTS (SELECT * FROM sys.database_principals WHERE name = 'A')
	DROP USER [A];
IF  EXISTS (SELECT * FROM sys.database_principals WHERE name = 'B')
	DROP USER [B];
IF  EXISTS (SELECT * FROM sys.server_principals WHERE name = 'A')
	DROP LOGIN [A];
IF  EXISTS (SELECT * FROM sys.server_principals WHERE name = 'B')
	DROP LOGIN [B];


/**************************BEGIN*****************************/

-- PART 1: Create Logins
CREATE LOGIN A WITH PASSWORD = 'SQLSATURDAY', CHECK_POLICY = OFF
GO
CREATE LOGIN B WITH PASSWORD = 'SQLSATURDAY', CHECK_POLICY = OFF
GO
CREATE USER A FOR LOGIN A
GO
CREATE USER B FOR LOGIN B
GO

--PART 2: Setup RG

-- Create Resource Pool for Login A.
CREATE RESOURCE POOL poolA
GO
-- Create Workload Group for PoolA.
CREATE WORKLOAD GROUP wrkgroupA
USING poolA
GO

-- Create Resource Pool for Login B.
CREATE RESOURCE POOL poolB
GO
-- Create Workload Group for PoolB.
CREATE WORKLOAD GROUP wrkgroupB
USING poolB
GO

-- Create Classification UDF to map logins.
CREATE FUNCTION udf_LoginClassifier() 
RETURNS SYSNAME
WITH SCHEMABINDING
AS
BEGIN
	DECLARE 
		@WorkGroupName VARCHAR(10) = 'Default',
		@LoginName SYSNAME = SUSER_NAME();
	IF @LoginName = 'A'
		SET @WorkGroupName = 'wrkgroupA';
	IF @LoginName = 'B'
		SET @WorkGroupName = 'wrkgroupB';
	RETURN (@WorkGroupName);
END
GO

-- Register classifier function with Resource Governor
ALTER RESOURCE GOVERNOR WITH (CLASSIFIER_FUNCTION = dbo.udf_LoginClassifier);

-- Finally apply changes.
ALTER RESOURCE GOVERNOR RECONFIGURE;

-- Part 3: Connect with SQL Login A & B and test.

/**************************END*****************************/

/***Reviewing configurations and debuging connections***/
USE master
GO
SELECT * FROM sys.resource_governor_resource_pools
SELECT * FROM sys.resource_governor_workload_groups
GO

--- Get the classifier function Id and state (enabled).
SELECT * FROM sys.resource_governor_configuration
GO

--- Get the classifer function name and the name of the schema
--- that it is bound to.
SELECT 
      object_schema_name(classifier_function_id) AS [schema_name],
      object_name(classifier_function_id) AS [function_name]
FROM sys.dm_resource_governor_configuration

--Find out what sessions are in each group by using the following query.
SELECT s.group_id
		,CAST(g.name as nvarchar(100)) group_name
		,s.login_name
		,s.session_id, s.login_time
		,CAST(s.host_name as nvarchar(100))
		,CAST(s.program_name AS nvarchar(100))
FROM sys.dm_exec_sessions s
INNER JOIN sys.dm_resource_governor_workload_groups g
          ON g.group_id = s.group_id
ORDER BY g.name
GO

--Find out which requests are in each group by using the following query.
SELECT r.group_id
		,g.name group_name
		,r.status
		,r.session_id
		,r.request_id
		,r.start_time
		,r.command
		,r.sql_handle
		,t.text 
FROM sys.dm_exec_requests r
INNER JOIN sys.dm_resource_governor_workload_groups g
            ON g.group_id = r.group_id
CROSS APPLY sys.dm_exec_sql_text(r.sql_handle) AS t
ORDER BY g.name
GO