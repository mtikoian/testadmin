-- first enable advanced options in sp_configure
sp_configure 'show advanced', 1
GO
 
RECONFIGURE
GO
 
-- use only 1 CPU on demo machine
sp_configure 'affinity mask', 1
GO
 
RECONFIGURE
GO

-------------------------------------------------------------------
-- Step 1 - Enable Dedicated Admin  Connection
-------------------------------------------------------------------
USE master
GO
/* 0 = Allow Local Connection, 1 = Allow Remote Connections*/ 
sp_configure 'remote admin connections', 1 
GO
RECONFIGURE
GO



-------------------------------------------------------------------
-- Step 2 -- RG Meta Data info
-------------------------------------------------------------------
USE master
GO

-- metadata information
SELECT * FROM sys.resource_governor_workload_groups
SELECT * FROM sys.resource_governor_resource_pools
SELECT * FROM sys.resource_governor_configuration

-- in-memory information
SELECT * FROM sys.dm_resource_governor_workload_groups
SELECT * FROM sys.dm_resource_governor_resource_pools
SELECT * FROM sys.dm_resource_governor_configuration
SELECT * FROM sys.dm_resource_governor_resource_pool_affinity --2012
SELECT * FROM sys.dm_resource_governor_resource_pool_volumes -- 2014

-------------------------------------------------------------------
-- Step 3 -- Check Server Connection Information
-------------------------------------------------------------------
USE MonitorConnections
GO
EXEC dbo.getconnectioninfo
GO

-------------------------------------------------------------------
-- Step 4 -- Create Users
-------------------------------------------------------------------
USE Master
GO
CREATE LOGIN BackupUser WITH PASSWORD = 'BackupUserPwd', CHECK_POLICY = OFF
GO
CREATE LOGIN AdhocUser WITH PASSWORD = 'AdhocUserPwd', CHECK_POLICY = OFF
GO
CREATE LOGIN OltpUser WITH PASSWORD = 'OltpUserPwd', CHECK_POLICY = OFF
GO

ALTER SERVER ROLE sysadmin ADD MEMBER BackupUser
GO
ALTER SERVER ROLE sysadmin ADD MEMBER AdhocUser
GO
ALTER SERVER ROLE sysadmin ADD MEMBER OltpUser
GO

-------------------------------------------------------------------
-- Step 5 -- Create Resource Pools
-------------------------------------------------------------------
USE [master]
GO

-- Backup Pool
CREATE RESOURCE POOL Backup_Adhoc_Pool
GO
-- Adhoc Queries
CREATE RESOURCE POOL OLTP_Pool
GO

-- metadata information
SELECT * FROM sys.resource_governor_resource_pools
SELECT * FROM sys.resource_governor_configuration
-- in-memory information
SELECT * FROM sys.dm_resource_governor_resource_pools
SELECT * FROM sys.dm_resource_governor_configuration

-- make the changes effective
ALTER RESOURCE GOVERNOR RECONFIGURE
GO

-- metadata information
SELECT * FROM sys.resource_governor_resource_pools
SELECT * FROM sys.resource_governor_configuration
-- in-memory information
SELECT * FROM sys.dm_resource_governor_resource_pools
SELECT * FROM sys.dm_resource_governor_configuration
-------------------------------------------------------------------
-- Step 6 -- Create Workload Groups
-------------------------------------------------------------------
USE [master]
GO

-- Backup Group
CREATE WORKLOAD GROUP Backup_Group
USING Backup_Adhoc_Pool
GO
-- Adhoc Group
CREATE WORKLOAD GROUP Adhoc_Group
USING Backup_Adhoc_Pool
GO
-- Oltp Group
CREATE WORKLOAD GROUP Oltp_Group
USING OLTP_Pool
GO

-- metadata information
SELECT * FROM sys.resource_governor_workload_groups
SELECT * FROM sys.resource_governor_configuration

-- in-memory information
SELECT * FROM sys.dm_resource_governor_workload_groups
SELECT * FROM sys.dm_resource_governor_configuration

-- make the changes effective
ALTER RESOURCE GOVERNOR RECONFIGURE
GO

-- metadata information
SELECT * FROM sys.resource_governor_workload_groups
SELECT * FROM sys.resource_governor_configuration

-- in-memory information
SELECT * FROM sys.dm_resource_governor_workload_groups
SELECT * FROM sys.dm_resource_governor_configuration

-------------------------------------------------------------------
-- Step 7 -- Create Classifier Function Simple
-------------------------------------------------------------------
USE [master]
GO

-- now create the classifier function
IF OBJECT_ID('DBO.CLASSIFIER_SIMPLE','FN') IS NOT NULL
       DROP FUNCTION DBO.CLASSIFIER_SIMPLE
GO
 
-- note that this is just a regular function
CREATE FUNCTION CLASSIFIER_SIMPLE ()
RETURNS SYSNAME WITH SCHEMABINDING
BEGIN
	DECLARE @groupname SYSNAME
	
		IF (SUSER_SNAME() = 'OltpUser') 
			SET @groupname = 'Oltp_Group'
		ELSE		
		IF (SUSER_SNAME() = 'BackupUser') 
			SET @groupname = 'Backup_Group'
		ELSE
		IF APP_NAME() LIKE 'SQLCMD%'
			SET @groupname = 'Adhoc_Group'
		ELSE  
			SET @groupname = 'default';

       RETURN @groupname;
END
GO

-- Create a mirror Function to test the logic
CREATE FUNCTION CLASSIFIER_SIMPLE_Mirror 
(
	@suser_sname VARCHAR(256),
	@app_name VARCHAR(256)
)
RETURNS SYSNAME WITH SCHEMABINDING
BEGIN
	DECLARE @groupname SYSNAME
	
		IF (@suser_sname = 'OltpUser')  
			SET @groupname = 'Oltp_Group'
		ELSE		
		IF (@suser_sname = 'BackupUser') 
			SET @groupname = 'Backup_Group'
		ELSE
		IF @app_name LIKE 'SQLCMD%'
			SET @groupname = 'Adhoc_Group'
		ELSE  
			SET @groupname = 'default';

       RETURN @groupname;
END
GO

-- Test Mirror function
select dbo.CLASSIFIER_SIMPLE_Mirror('OltpUser','SQLCMD')
select dbo.CLASSIFIER_SIMPLE_Mirror('BackupUser','Test')
select dbo.CLASSIFIER_SIMPLE_Mirror('MBP-WIN8\Martin','SQLCMD')
select dbo.CLASSIFIER_SIMPLE_Mirror('MBP-WIN8\Martin','Test')




-- Assign the function to the Resource Governor and reconfigure
ALTER RESOURCE GOVERNOR
WITH (CLASSIFIER_FUNCTION = dbo.CLASSIFIER_SIMPLE)
GO

-- metadata information
SELECT * FROM sys.resource_governor_configuration
-- in-memory information
SELECT * FROM sys.dm_resource_governor_configuration
GO

ALTER RESOURCE GOVERNOR RECONFIGURE
GO

-- metadata information
SELECT * FROM sys.resource_governor_configuration
-- in-memory information
SELECT * FROM sys.dm_resource_governor_configuration
GO

-------------------------------------------------------------------
-- Step 8 -- Test CPU Utilisation with NO Limits
-------------------------------------------------------------------
-- first enable advanced options in sp_configure
sp_configure 'show advanced', 1
GO
 
RECONFIGURE
GO
 
-- use only 1 CPU on demo machine
sp_configure 'affinity mask', 1
GO
 
RECONFIGURE
GO

-------------------------------------------------------------------
-- Step 9 -- Run CPU Test
-------------------------------------------------------------------
-- Minimize SSMS
-- Run Perfmon X 2 RHS of Screen
-- Properties: Duration=300 | Horizontal Grid Scale =50
-- SQLServer: Resource Pool Stats
-- SQLServer: WorkLoad Group Stats
--Counter : CPU Usage %
-- Run "C:\Users\Martin\Dropbox\Work\SQLSaturday Presentation\Who is in Control\CPU_Test.cmd"

-------------------------------------------------------------------
-- Step 10 -- Alter Resouce Pools
-------------------------------------------------------------------
ALTER RESOURCE POOL Backup_Adhoc_Pool
WITH
(MAX_CPU_PERCENT = 50)
GO

ALTER RESOURCE GOVERNOR RECONFIGURE
GO

-------------------------------------------------------------------
-- Step 11 -- Alter Workload Groups
-------------------------------------------------------------------
USE [master]
GO

-- Backup Group
ALTER WORKLOAD GROUP Backup_Group
WITH
(
IMPORTANCE = MEDIUM
)
GO
-- Adhoc Group
ALTER WORKLOAD GROUP Adhoc_Group
WITH
(
IMPORTANCE = LOW
)
GO

-- make the changes effective
ALTER RESOURCE GOVERNOR RECONFIGURE
GO

-------------------------------------------------------------------
-- Step 12 -- Setup for  IO Tests
-------------------------------------------------------------------
USE MonitorConnections
GO
IF OBJECT_ID ('MonitorConnections..IOTest') is not null
   DROP TABLE IOTest
GO
CREATE TABLE IOTest(ID INT IDENTITY 
                    CONSTRAINT [PK_IOTest_ID] PRIMARY KEY CLUSTERED (ID ASC)
                  , Number INT
                  , ABCString CHAR(60)); 
GO

SET NOCOUNT ON;
INSERT INTO IOTest (Number, ABCString)
       SELECT TOP (50000) ROW_NUMBER() OVER(ORDER BY c1.OBJECT_ID), REPLICATE('ABC',20)
       FROM sys.columns AS c1 CROSS JOIN sys.columns AS c2
GO 300

-------------------------------------------------------------------
-- Step 13 -- Run IO Tests With No Limits
-------------------------------------------------------------------
-- Unpin Object Explorer & shrink SSMS to RHS
-- Run Perfmon
-- Properties: Duration=300 | Horizontal Grid Scale =100
-- SQLServer: Resource Pool Stats
-- Instance: Backup_Adhoc_Pool
-- Counters: Disk Read Bytes/sec
--         : Disk Read IO/Sec
--         : Disk Read IO Throttled/sec

CHECKPOINT
DBCC DROPCLEANBUFFERS


USE MonitorConnections
GO
IF OBJECT_ID ('tempdb..#IOTest') is not null
   DROP TABLE #IOTest;
GO
SELECT * INTO #IOTest FROM IOTest;
GO

-------------------------------------------------------------------
-- Step 14 -- Alter Resource Pools
-------------------------------------------------------------------
USE [master]
GO

-- Alter Backup_Adhoc_Pool
ALTER RESOURCE POOL Backup_Adhoc_Pool
WITH
(
MAX_IOPS_PER_VOLUME = 25
)
GO

ALTER RESOURCE POOL Oltp_Pool
WITH
(
MAX_IOPS_PER_VOLUME = 75
)
GO
-- metadata information
SELECT * FROM sys.resource_governor_resource_pools
-- in-memory information
SELECT * FROM sys.dm_resource_governor_resource_pools

-- make the changes effective
ALTER RESOURCE GOVERNOR RECONFIGURE
GO

-- metadata information
SELECT * FROM sys.resource_governor_resource_pools
-- in-memory information
SELECT * FROM sys.dm_resource_governor_resource_pools


-------------------------------------------------------------------
-- Step 15 -- Run IO Tests With Limits
-------------------------------------------------------------------
-- Run Perfmon
-- Properties: Duration=300 | Horizontal Grid Scale =100
-- SQLServer: Resource Pool Stats
-- Instance: Backup_Adhoc_Pool
-- Counters: Disk Read Bytes/sec
--         : Disk Read IO/Sec
--         : Disk Read IO Throttled/sec

-- NB Change Connection to Login with trusted
CHECKPOINT
DBCC DROPCLEANBUFFERS

-- NB - Change Connection to Login with BackupUser - pwd = BackupUserPwd
USE MonitorConnections
GO
IF OBJECT_ID ('tempdb..#IOTest') is not null
   DROP TABLE #IOTest;
GO
SELECT * INTO #IOTest FROM IOTest;
GO

-- Run Perfmon
-- Properties: Duration=300 | Horizontal Grid Scale =100
-- SQLServer: Resource Pool Stats
-- Instance: Oltp_Pool
-- Counters: Disk Read Bytes/sec
--         : Disk Read IO/Sec
--         : Disk Read IO Throttled/sec

-- NB Change Connection to Login with trusted
CHECKPOINT
DBCC DROPCLEANBUFFERS

-- NB - Change Connection to Login with OltpUser - pwd = OltpUserPwd
USE MonitorConnections
GO
IF OBJECT_ID ('tempdb..#IOTest') is not null
   DROP TABLE #IOTest;
GO
SELECT * INTO #IOTest FROM IOTest;
GO

-- NB Change Connection to Login with trusted
