USE master
GO

-- Create Database to store Connection Information
CREATE DATABASE MonitorConnections
 ON  PRIMARY 
( NAME = N'MonitorConnections', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL11.MSSQLSERVER\MSSQL\DATA\MonitorConnections.mdf' , SIZE = 5120KB , MAXSIZE = UNLIMITED, FILEGROWTH = 1024KB )
 LOG ON 
( NAME = N'MonitorConnections_log', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL11.MSSQLSERVER\MSSQL\DATA\MonitorConnections_log.ldf' , SIZE = 2048KB , MAXSIZE = 2048GB , FILEGROWTH = 10%)
GO

USE MonitorConnections
GO
--Create Table to store Connection INformation
CREATE TABLE dbo.MonitorConnections(
	hostname		NVARCHAR(128),
	[program_name]	NVARCHAR(128),
	nt_domain		NVARCHAR(128),
	nt_username		NVARCHAR(128),
	loginame		NVARCHAR(128)
) ON [PRIMARY]
GO

--Create Proc to save unique Connection Information
CREATE PROCEDURE dbo.SaveConnectionInfo 
AS
BEGIN
	SET NOCOUNT ON;

	;WITH SavedConnections(connection) AS
	(
	SELECT 
		ISNULL(hostname,'')+ISNULL(program_name,'')+ISNULL(nt_domain,'')+ISNULL(nt_username,'')+ISNULL(loginame,'') 
	FROM 
		MonitorConnections WITH (NOLOCK)
	) 
	INSERT 
		INTO MonitorConnections
	SELECT DISTINCT 
		host_name,
		program_name,
		nt_domain,
		nt_user_name,
		login_name
	FROM 
		sys.dm_exec_sessions es LEFT JOIN 
		SavedConnections     sc ON ISNULL(es.host_name,'')+ISNULL(es.program_name,'')+ISNULL(es.nt_domain,'')+ISNULL(es.nt_user_name,'')+ISNULL(es.login_name,'') = sc.connection
WHERE 
	connection IS NULL

END

--Create Proc to retrieve unique Connection Information
CREATE PROCEDURE dbo.GetConnectionInfo 
AS
BEGIN
	SET NOCOUNT ON;

	SELECT 
		hostname,
		program_name,
		nt_domain,
		nt_username,
		loginame 
	FROM 
		MonitorConnections
	ORDER BY
		hostname,
		program_name,
		nt_domain,
		nt_username,
		loginame 	 
END
GO

--Schedule Job to capture Connection Information
USE [msdb]
GO
DECLARE @jobId BINARY(16)
EXEC  msdb.dbo.sp_add_job @job_name=N'MonitorConnections', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=2, 
		@notify_level_page=2, 
		@delete_level=0, 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
select @jobId
GO
EXEC msdb.dbo.sp_add_jobserver @job_name=N'MonitorConnections', @server_name = N'MBP-WIN8'
GO
USE [msdb]
GO
EXEC msdb.dbo.sp_add_jobstep @job_name=N'MonitorConnections', @step_name=N'MonitorConnections', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_fail_action=2, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC dbo.SaveConnectionInfo', 
		@database_name=N'MonitorConnections', 
		@flags=0
GO
USE [msdb]
GO
EXEC msdb.dbo.sp_update_job @job_name=N'MonitorConnections', 
		@enabled=1, 
		@start_step_id=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=2, 
		@notify_level_page=2, 
		@delete_level=0, 
		@description=N'', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sa', 
		@notify_email_operator_name=N'', 
		@notify_netsend_operator_name=N'', 
		@notify_page_operator_name=N''
GO
USE [msdb]
GO
DECLARE @schedule_id int
EXEC msdb.dbo.sp_add_jobschedule @job_name=N'MonitorConnections', @name=N'EveryFiveMinutes', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=4, 
		@freq_subday_interval=5, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20140816, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959, @schedule_id = @schedule_id OUTPUT
select @schedule_id
GO
