select max(t1.OrderQty) - AVG(t2.OrderQty) + sum(t3.SubTotal) 
from sales.SalesOrderDetail t1
cross join sales.SalesOrderDetail t2
cross join sales.SalesOrderHeader t3


USE [master]
GO

CREATE RESOURCE POOL OPSPool WITH
	   (min_cpu_percent=0, 
		max_cpu_percent=30,
		 
		min_memory_percent=0, 
		max_memory_percent=20,
		cap_cpu_percent=20)

GO

CREATE RESOURCE POOL ANAPool WITH
	   (min_cpu_percent=0, 
		max_cpu_percent=20,
		 
		min_memory_percent=0, 
		max_memory_percent=30)
GO



CREATE WORKLOAD GROUP OPSGroup
WITH (
	--IMPORTANCE = <IMPORTANCE, const, MEDIUM>
	--, REQUEST_MAX_MEMORY_GRANT_PERCENT = <REQUEST_MAX_MEMORY_GRANT_PERCENT, int, 25>
	--, REQUEST_MEMORY_GRANT_TIMEOUT_SEC = <REQUEST_MEMORY_GRANT_TIMEOUT_SEC, int, 0>
	--, REQUEST_MAX_CPU_TIME_SEC = <REQUEST_MAX_CPU_TIME_SEC, int, 0>,
	 MAX_DOP = 1
	--, GROUP_MAX_REQUESTS = <GROUP_MAX_REQUESTS, int, 0>
)
USING OPSPool
GO

CREATE WORKLOAD GROUP ANAGroup
WITH (
	 MAX_DOP = 2
)
USING OPSPool
GO


CREATE FUNCTION Classify() 
RETURNS sysname 
WITH SCHEMABINDING
AS
BEGIN
     -- Define the return sysname variable for the function
     DECLARE @grp_name AS sysname;
     SET @grp_name = 'default';

     -- Specify the T-SQL statements for mapping session information
     -- with Workload Groups defined for the Resource Governor.
     IF (IS_MEMBER ('ReportingTeam') = 1)
          SET @grp_name = 'ANAGroup';
	 else if (IS_MEMBER ('OpsTeam') = 1)
		  SET @grp_name = 'OPSGroup';
	 else
		  SET @grp_name = NULL;

     RETURN @grp_name;
END
GO

ALTER RESOURCE GOVERNOR 
WITH ( 
	CLASSIFIER_FUNCTION = dbo.Classify
)
GO

ALTER RESOURCE GOVERNOR RECONFIGURE
GO

---------------------------------------------------------------------
--catalog views
--first column is the classifier function id.
--second column shows wether resource governor is enabled
select * from sys.resource_governor_configuration



