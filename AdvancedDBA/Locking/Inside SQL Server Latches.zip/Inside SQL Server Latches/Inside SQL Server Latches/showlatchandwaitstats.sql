select * from sys.dm_os_latch_stats
go
select * from sys.dm_os_wait_stats
order by wait_type
go