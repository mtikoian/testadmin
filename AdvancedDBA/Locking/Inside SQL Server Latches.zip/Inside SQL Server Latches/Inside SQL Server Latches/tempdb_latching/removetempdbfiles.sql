alter database tempdb remove file tempdev2
go
alter database tempdb remove file tempdev3
go
alter database tempdb remove file tempdev4
go
alter database tempdb remove file tempdev5
go
alter database tempdb remove file tempdev6
go
shutdown
go