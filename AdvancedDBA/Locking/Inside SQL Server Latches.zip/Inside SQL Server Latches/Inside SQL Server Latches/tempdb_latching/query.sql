select * from troyt
go