select * from sys.dm_db_index_operational_stats(null, null, null, null)
go