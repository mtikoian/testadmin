-- Dump out the PFS page for master
--
dbcc traceon(3604)
go
dbcc page(1,1,1,3)
go
-- bstat shows BUF_HASHED and BUF_ONLRU bits
--
-- Create a table in master
go
use master
go
drop table mytab
go
create table mytab (col1 int)
go
--
-- Dump out the PFS page for master again
-- bstat changes. What is the extra bit set?
-- it is BUF_DIRTY. Why for just creating a table?
dbcc traceon(3604)
go
dbcc page(1,1,1,3)
go
-- Checkpoint master
--
checkpoint
-- Does the bstat change?
--
dbcc traceon(3604)
go
dbcc page(1,1,1,3)
go
