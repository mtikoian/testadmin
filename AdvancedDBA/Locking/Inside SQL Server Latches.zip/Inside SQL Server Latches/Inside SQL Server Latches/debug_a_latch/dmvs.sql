-- Let's clear the stats first
--
dbcc sqlperf('sys.dm_os_wait_stats', clear)
go
dbcc sqlperf('sys.dm_os_latch_stats', clear)
go
select ot.task_address, er.session_id, er.command, er.wait_type, 
er.wait_resource, er.wait_time, 
er.blocking_session_id
from sys.dm_exec_requests er
join sys.dm_exec_sessions es
on es.session_id = er.session_id
and es.is_user_process = 1
join sys.dm_os_tasks ot
on es.session_id = ot.session_id
go
-- resource_address for a latch is the Latch class
--
select et.session_id, et.exec_context_id, et.wait_duration_ms, 
et.wait_type, et.resource_address, et.blocking_task_address,
et.blocking_session_id, et.blocking_exec_context_id,
et.resource_description
from sys.dm_os_waiting_tasks et
join sys.dm_exec_sessions es
on et.session_id = es.session_id
and es.is_user_process = 1
go
-- Show the stats
-- First wait_stats
select * from sys.dm_os_wait_stats
where wait_type like '%LATCH%'
go
select * from sys.dm_os_latch_stats
where waiting_requests_count > 0
order by waiting_requests_count desc
go
select * from sys.dm_os_latch_stats
go