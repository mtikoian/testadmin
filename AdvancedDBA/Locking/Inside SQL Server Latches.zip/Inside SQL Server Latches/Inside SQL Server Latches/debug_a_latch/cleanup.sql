dbcc traceoff(1806,-1)
go