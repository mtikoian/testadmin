SELECT CONVERT (XML, event_data) AS data FROM sys.fn_xe_file_target_read_file
('C:\temp\xe_trace_latch*.xel', 'C:\temp\xe_trace_latch*.xem', null, null)
go