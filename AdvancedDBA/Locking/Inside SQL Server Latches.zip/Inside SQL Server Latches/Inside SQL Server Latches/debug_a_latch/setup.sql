USE [master]
GO
DROP DATABASE [whatayearforthetexasrangers]
GO
USE [master]
GO
CREATE DATABASE [whatayearforthetexasrangers] ON  PRIMARY 
( NAME = N'whatayearforthetexasrangers', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL10_50.MSSQLSERVER\MSSQL\DATA\whatayearforthetexasrangers.mdf' , SIZE = 3MB , MAXSIZE = UNLIMITED, FILEGROWTH = 2048Mb)
 LOG ON 
( NAME = N'whatayearforthetexasrangers_log', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL10_50.MSSQLSERVER\MSSQL\DATA\whatayearforthetexasrangers_log.LDF' , SIZE = 500MB , MAXSIZE = 2048GB , FILEGROWTH = 10%)
GO
use whatayearforthetexasrangers
go
drop table firstworldseries
go
create table firstworldseries (col1 int identity, col2 char(7000) not null)
go
