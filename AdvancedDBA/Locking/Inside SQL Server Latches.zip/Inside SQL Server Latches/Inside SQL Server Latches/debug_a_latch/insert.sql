use whatayearforthetexasrangers
go
insert into firstworldseries (col2) values ('But...the Giants were better')
go
