use master
go
drop event session trace_latch on server
go
create event session trace_latch on server
add event sqlserver.latch_suspend_end
(
action (sqlserver.session_id, sqlserver.sql_text, sqlserver.client_app_name, sqlserver.database_id)
)
ADD TARGET package0.asynchronous_file_target
   (SET FILENAME = N'C:\temp\xe_trace_latch.xel', METADATAFILE = N'C:\temp\xe_trace_latch.xem')
WITH (max_dispatch_latency = 1 seconds);
go
alter event session trace_latch on server state = start
go
