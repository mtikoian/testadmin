use dontaskmeaboutthecowboys
go
insert into butwehostthesuperbowl (col2) values ('At least we get a first round draft pick')
go
