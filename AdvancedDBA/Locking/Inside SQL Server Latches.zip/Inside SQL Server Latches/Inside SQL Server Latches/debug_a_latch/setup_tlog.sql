USE [master]
GO
DROP DATABASE [dontaskmeaboutthecowboys]
GO
USE [master]
GO
CREATE DATABASE [dontaskmeaboutthecowboys] ON  PRIMARY 
( NAME = N'dontaskmeaboutthecowboys', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL10.SQL2008\MSSQL\DATA\dontaskmeaboutthecowboys.mdf' , SIZE = 500MB , MAXSIZE = UNLIMITED, FILEGROWTH = 10%)
 LOG ON 
( NAME = N'dontaskmeaboutthecowboys_log', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL10.SQL2008\MSSQL\DATA\dontaskmeaboutthecowboys_log.LDF' , SIZE = 2MB , MAXSIZE = UNLIMITED , FILEGROWTH = 2048Mb)
GO
use dontaskmeaboutthecowboys
go
drop table butwehostthesuperbowl
go
create table butwehostthesuperbowl (col1 int identity, col2 char(7000) not null)
go
