﻿MICROSOFT ENTERPRISE LIBRARY
TRANSIENT FAULT HANDLING APPLICATION BLOCK ("TOPAZ")
6.0.1304.1

Summary: The Transient Fault Handling Application Block makes your on-premises or cloud application more resilient to transient failures by providing intelligent retry logic mechanisms.

The most up-to-date version of the release notes and known issues is available online:
http://aka.ms/el6release


Microsoft patterns & practices
http://microsoft.com/practices
