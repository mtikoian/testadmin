USE
	VeryLargeTableDemo;
GO


SET NOCOUNT ON;
GO


-- Insert one row at a time consecutively
-- Open Performance Monitor and look at the SQL Statistics:Batch Requests/sec counter (~3,000)
-- Query sys.dm_os_wait_stas for the "WRITELOG" wait type (almost 100% of the time)

BEGIN TRANSACTION
	InsertPageView;

INSERT INTO
	Web.PageViews
(
	URL ,
	ReferenceCode ,
	SessionId ,
	DateAndTime
)
SELECT
	URL				= N'www.' + REPLICATE (N'x' , ABS (CHECKSUM (NEWID ())) % 90) + N'.com' ,
	ReferenceCode	= ABS (CHECKSUM (NEWID ())) % 1000000 + 1 ,
	SessionId		= ABS (CHECKSUM (NEWID ())) % 1000000 + 1 ,
	DateAndTime		= SYSDATETIME ();

COMMIT TRANSACTION
	InsertPageView;
GO 1000000


ROLLBACK TRANSACTION;
GO


-- Allow delayed durability at the database level

ALTER DATABASE
	VeryLargeTableDemo
SET
	DELAYED_DURABILITY = ALLOWED;
GO


-- Insert one row at a time consecutively, but this time each transaction uses delayed durability
-- Open Performance Monitor and look at the SQL Statistics:Batch Requests/sec counter (~5,000)
-- Query sys.dm_os_wait_stas for the "WRITELOG" wait type (almost completely gone)

BEGIN TRANSACTION
	InsertPageView;

INSERT INTO
	Web.PageViews
(
	URL ,
	ReferenceCode ,
	SessionId ,
	DateAndTime
)
SELECT
	URL				= N'www.' + REPLICATE (N'x' , ABS (CHECKSUM (NEWID ())) % 90) + N'.com' ,
	ReferenceCode	= ABS (CHECKSUM (NEWID ())) % 1000000 + 1 ,
	SessionId		= ABS (CHECKSUM (NEWID ())) % 1000000 + 1 ,
	DateAndTime		= SYSDATETIME ();

COMMIT TRANSACTION
	InsertPageView
WITH
	(DELAYED_DURABILITY = ON);
GO 1000000


ROLLBACK TRANSACTION;
GO


-- Now, insert 1,000 rows at a time, and check the improvement
-- between full durability and delayed durability

BEGIN TRANSACTION
	InsertPageView;

INSERT INTO
	Web.PageViews
(
	URL ,
	ReferenceCode ,
	SessionId ,
	DateAndTime
)
SELECT TOP (1000)
	URL				= N'www.' + REPLICATE (N'x' , ABS (CHECKSUM (NEWID ())) % 90) + N'.com' ,
	ReferenceCode	= ABS (CHECKSUM (NEWID ())) % 1000000 + 1 ,
	SessionId		= ABS (CHECKSUM (NEWID ())) % 1000000 + 1 ,
	DateAndTime		= SYSDATETIME ()
FROM
	sys.all_objects;

COMMIT TRANSACTION
	InsertPageView
WITH
	(DELAYED_DURABILITY = OFF);
GO 1000000


ROLLBACK TRANSACTION;
GO


BEGIN TRANSACTION
	InsertPageView;

INSERT INTO
	Web.PageViews
(
	URL ,
	ReferenceCode ,
	SessionId ,
	DateAndTime
)
SELECT TOP (1000)
	URL				= N'www.' + REPLICATE (N'x' , ABS (CHECKSUM (NEWID ())) % 90) + N'.com' ,
	ReferenceCode	= ABS (CHECKSUM (NEWID ())) % 1000000 + 1 ,
	SessionId		= ABS (CHECKSUM (NEWID ())) % 1000000 + 1 ,
	DateAndTime		= SYSDATETIME ()
FROM
	sys.all_objects;

COMMIT TRANSACTION
	InsertPageView
WITH
	(DELAYED_DURABILITY = ON);
GO 1000000


ROLLBACK TRANSACTION;
GO


-- In order to demonstrate the behavior of delayed durability vs. full durability,
-- open Performance Monitor and look at the Databases:Log Flushes/sec counter.
-- We insert one row at a time again.
-- Now compare the results between fully durable transactions and transactions that use delayed durability...

BEGIN TRANSACTION
	InsertPageView;

INSERT INTO
	Web.PageViews
(
	URL ,
	ReferenceCode ,
	SessionId ,
	DateAndTime
)
SELECT
	URL				= N'www.' + REPLICATE (N'x' , ABS (CHECKSUM (NEWID ())) % 90) + N'.com' ,
	ReferenceCode	= ABS (CHECKSUM (NEWID ())) % 1000000 + 1 ,
	SessionId		= ABS (CHECKSUM (NEWID ())) % 1000000 + 1 ,
	DateAndTime		= SYSDATETIME ();

COMMIT TRANSACTION
	InsertPageView
WITH
	(DELAYED_DURABILITY = OFF);
GO 1000000


ROLLBACK TRANSACTION;
GO


BEGIN TRANSACTION
	InsertPageView;

INSERT INTO
	Web.PageViews
(
	URL ,
	ReferenceCode ,
	SessionId ,
	DateAndTime
)
SELECT
	URL				= N'www.' + REPLICATE (N'x' , ABS (CHECKSUM (NEWID ())) % 90) + N'.com' ,
	ReferenceCode	= ABS (CHECKSUM (NEWID ())) % 1000000 + 1 ,
	SessionId		= ABS (CHECKSUM (NEWID ())) % 1000000 + 1 ,
	DateAndTime		= SYSDATETIME ();

COMMIT TRANSACTION
	InsertPageView
WITH
	(DELAYED_DURABILITY = ON);
GO 1000000


ROLLBACK TRANSACTION;
GO
