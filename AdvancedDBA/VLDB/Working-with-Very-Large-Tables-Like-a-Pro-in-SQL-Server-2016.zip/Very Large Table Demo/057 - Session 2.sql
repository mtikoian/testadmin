USE
	VeryLargeTableDemo;
GO


-- Session 2: Begin an explicit transaction

BEGIN TRANSACTION
	InsertRow;
GO


-- Session 2: Insert a new row into "Web.PageViews", but don't commit in order to preserve the locks

INSERT INTO
	Web.PageViews
(
	URL ,
	ReferenceCode ,
	SessionId ,
	DateAndTime
)
SELECT
	URL				= N'www.' + REPLICATE (N'x' , ABS (CHECKSUM (NEWID ())) % 90) + N'.com' ,
	ReferenceCode	= ABS (CHECKSUM (NEWID ())) % 100000 + 1 ,
	SessionId		= ABS (CHECKSUM (NEWID ())) % 100000 + 1 ,
	DateAndTime		= SYSDATETIME ();
GO


-- Session 2: Commit the transaction and release the locks

COMMIT TRANSACTION
	InsertRow;
GO
