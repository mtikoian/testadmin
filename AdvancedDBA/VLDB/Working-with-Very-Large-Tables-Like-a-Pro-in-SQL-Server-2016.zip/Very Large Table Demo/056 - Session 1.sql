USE
	VeryLargeTableDemo;
GO


-- Session 1: Query the "Web.PageViews" table

SELECT
	PageViewId		= PageViews.Id ,
	SessionId		= PageViews.SessionId ,
	DateAndTime		= PageViews.DateAndTime ,
	ReferenceCode	= ReferenceCodes.ReferenceCode ,
	CustomerId		= ReferenceCodes.CustomerId ,
	ExpirationDate	= ReferenceCodes.ExpirationDate
FROM
	Web.PageViews AS PageViews
INNER JOIN
	Web.ReferenceCodes AS ReferenceCodes
ON
	PageViews.ReferenceCode = ReferenceCodes.ReferenceCode
WHERE
	PageViews.DateAndTime >= DATEADD (WEEK , -1 , SYSDATETIME ())
ORDER BY
	PageViews.DateAndTime ASC;
GO


-- Session 1: Begin an explicit transaction

BEGIN TRANSACTION
	InsertRow;
GO


-- Session 1: Insert a new row into "Web.PageViews", but don't commit in order to preserve the locks

INSERT INTO
	Web.PageViews
(
	URL ,
	ReferenceCode ,
	SessionId ,
	DateAndTime
)
SELECT
	URL				= N'www.' + REPLICATE (N'x' , ABS (CHECKSUM (NEWID ())) % 90) + N'.com' ,
	ReferenceCode	= ABS (CHECKSUM (NEWID ())) % 1000000 + 1 ,
	SessionId		= ABS (CHECKSUM (NEWID ())) % 1000000 + 1 ,
	DateAndTime		= SYSDATETIME ();
GO


-- Session 1: Commit the transaction and release the locks

COMMIT TRANSACTION
	InsertRow;
GO
