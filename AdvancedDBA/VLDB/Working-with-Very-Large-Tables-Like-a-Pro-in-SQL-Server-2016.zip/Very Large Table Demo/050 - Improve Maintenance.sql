USE
	VeryLargeTableDemo;
GO


-- Index Rebuild:
-- This is how we used to rebuild indexes before index operations could be online and even before we could rebuild single partitions
-- This operation blocks the whole table for the duration of the rebuild operation

ALTER INDEX
	pk_PageViews_c_DateAndTime#Id
ON
	Web.PageViews
REBUILD
	PARTITION = ALL
WITH
	(ONLINE = OFF);
GO


-- Index Rebuild:
-- Since SQL Server 2008, we can rebuild the index online
-- This operation only takes a shared lock at the beginning of the operation and a short Sch-M lock at the end

ALTER INDEX
	pk_PageViews_c_DateAndTime#Id
ON
	Web.PageViews
REBUILD
	PARTITION = ALL
WITH
	(ONLINE = ON);
GO


-- Index Rebuild:
-- Of course, we can also rebuild a specific partition. Before SQL Server 2014 this could only be an offline operation.
-- This operation blocks the whole table for the duration of the rebuild operation, just like rebuilding the whole table,
-- but the operation is much faster, because we only rebuild a specific partition.

ALTER INDEX
	pk_PageViews_c_DateAndTime#Id
ON
	Web.PageViews
REBUILD
	PARTITION = 178
WITH
	(ONLINE = OFF);
GO


-- Index Rebuild:
-- Since SQL Server 2014 we can rebuild a specific partition online
-- Just like an online index rebuild on all partitions, this operation only takes a shared lock at the beginning of the operation
-- and a short Sch-M lock at the end, and just like an index rebuild on a single partition, it's faster than rebuilding the whole table

ALTER INDEX
	pk_PageViews_c_DateAndTime#Id
ON
	Web.PageViews
REBUILD
	PARTITION = 178
WITH
	(ONLINE = ON);
GO


-- An online index rebuild operation can now also wait at low prioirty for a specified number of minutes,
-- and then take one of three optional actions:


-- Index Rebuild:
-- 1. Continue to wait with a normal priority

ALTER INDEX
	pk_PageViews_c_DateAndTime#Id
ON
	Web.PageViews
REBUILD
	PARTITION = 178
WITH
	(ONLINE = ON (WAIT_AT_LOW_PRIORITY (MAX_DURATION = 1 MINUTES , ABORT_AFTER_WAIT = NONE)));
GO


-- Index Rebuild:
-- 2. abort the operation

ALTER INDEX
	pk_PageViews_c_DateAndTime#Id
ON
	Web.PageViews
REBUILD
	PARTITION = 178
WITH
	(ONLINE = ON (WAIT_AT_LOW_PRIORITY (MAX_DURATION = 1 MINUTES , ABORT_AFTER_WAIT = SELF)));
GO


-- Index Rebuild:
-- 3. Kill all the blockers and start the operation

ALTER INDEX
	pk_PageViews_c_DateAndTime#Id
ON
	Web.PageViews
REBUILD
	PARTITION = 178
WITH
	(ONLINE = ON (WAIT_AT_LOW_PRIORITY (MAX_DURATION = 1 MINUTES , ABORT_AFTER_WAIT = BLOCKERS)));
GO
