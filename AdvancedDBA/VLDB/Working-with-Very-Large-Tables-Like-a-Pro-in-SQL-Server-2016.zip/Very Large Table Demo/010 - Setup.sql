-- Create the "C:\VeryLargeTableDemo" folder to hold the database files

USE
	master;
GO


EXECUTE sys.sp_configure
	@configname		= 'show advanced options' ,
	@configvalue	= 1;
GO


RECONFIGURE;
GO


EXECUTE sys.sp_configure
	@configname		= 'xp_cmdshell' ,
	@configvalue	= 1;
GO


RECONFIGURE;
GO


EXECUTE sys.xp_cmdshell
	N'md C:\VeryLargeTableDemo' ,
	no_output;
GO


EXECUTE sys.sp_configure
	@configname		= 'xp_cmdshell' ,
	@configvalue	= 0;
GO


RECONFIGURE;
GO


EXECUTE sys.sp_configure
	@configname		= 'show advanced options' ,
	@configvalue	= 0;
GO


RECONFIGURE;
GO


-- Create the "VeryLargeTableDemo" database

IF
	DB_ID (N'VeryLargeTableDemo') IS NOT NULL
BEGIN

	ALTER DATABASE
		VeryLargeTableDemo
	SET
		SINGLE_USER
	WITH
		ROLLBACK IMMEDIATE;

	DROP DATABASE
		VeryLargeTableDemo;

END;
GO


CREATE DATABASE
	VeryLargeTableDemo
ON PRIMARY
(
	NAME		= N'VeryLargeTableDemo_Data' ,
	FILENAME	= N'C:\VeryLargeTableDemo\VeryLargeTableDemo_Data.mdf' ,
	SIZE		= 2GB ,
	FILEGROWTH	= 10%
)
LOG ON
(
	NAME		= N'VeryLargeTableDemo_Log' ,
	FILENAME	= N'C:\VeryLargeTableDemo\VeryLargeTableDemo_Log.ldf' ,
	SIZE		= 1GB ,
	FILEGROWTH	= 10%
);
GO


-- We don't need the full recovery model for the sake of this demo

ALTER DATABASE
	VeryLargeTableDemo
SET RECOVERY
	SIMPLE;
GO


-- We will start with compatibility level 110 (SQL Server 2012) in order to demonstrate the behavior of the cardinality estimator
-- prior to SQL Server 2014. We will change this later during the demo.

ALTER DATABASE
	VeryLargeTableDemo
SET
	COMPATIBILITY_LEVEL = 110;
GO


-- Create and populate the "Web.ReferenceCodes" table

USE
	VeryLargeTableDemo;
GO


CREATE SCHEMA
	Web;
GO


CREATE TABLE
	Web.ReferenceCodes
(
	ReferenceCode	BIGINT	NOT NULL ,
	CustomerId		BIGINT	NOT NULL ,
	CampaignId		BIGINT	NULL ,
	CreationDate	DATE	NOT NULL ,
	ExpirationDate	DATE	NULL ,

	CONSTRAINT
		pk_ReferenceCodes_c_ReferenceCode
	PRIMARY KEY CLUSTERED
		(ReferenceCode ASC)
);
GO


INSERT INTO
	Web.ReferenceCodes WITH (TABLOCK)
(
	ReferenceCode ,
	CustomerId ,
	CampaignId ,
	CreationDate ,
	ExpirationDate
)
SELECT TOP (1000000)
	ReferenceCode	= ROW_NUMBER () OVER (ORDER BY (SELECT NULL) ASC) ,
	CustomerId		= ABS (CHECKSUM (NEWID ())) % 100000 + 1 ,
	CampaignId		=
		CASE
			WHEN ABS (CHECKSUM (NEWID ())) % 10 <= 1
				THEN NULL
			ELSE
				ABS (CHECKSUM (NEWID ())) % 10000 + 1
		END ,
	CreationDate	= DATEADD (DAY , - (ABS (CHECKSUM (NEWID ())) % (365 * 2)) , SYSDATETIME ()) ,
	ExpirationDate	=
		CASE
			WHEN ABS (CHECKSUM (NEWID ())) % 10 = 0
				THEN NULL
			ELSE
				DATEADD (DAY , ABS (CHECKSUM (NEWID ())) % 365 , SYSDATETIME ())
		END
FROM
	sys.all_objects AS T1
CROSS JOIN
	sys.columns AS T2;
GO


-- Create the "Web.PageViews" table including a dedicated sequence object

CREATE SEQUENCE
	Web.PageViewIDs
AS
	BIGINT
START WITH
	1
INCREMENT BY
	1
MINVALUE
	1
NO MAXVALUE
CACHE
	10000;
GO


CREATE TABLE
	Web.PageViews
(
	Id				BIGINT			NOT NULL ,
	URL				NVARCHAR(100)	NOT NULL ,
	ReferenceCode	BIGINT			NULL ,
	SessionId		BIGINT			NOT NULL ,
	DateAndTime		DATETIME2(7)	NOT NULL ,

	CONSTRAINT
		pk_PageViews_c_Id
	PRIMARY KEY CLUSTERED
		(
			Id ASC
		) ,

	CONSTRAINT
		fk_PageViews_ReferenceCode_ReferenceCodes
	FOREIGN KEY
		(ReferenceCode)
	REFERENCES
		Web.ReferenceCodes (ReferenceCode)
)
ON
	[PRIMARY];
GO


ALTER TABLE
	Web.PageViews
ADD CONSTRAINT
	df_PageViews_Id
DEFAULT
	NEXT VALUE FOR Web.PageViewIDs
FOR
	Id;
GO


-- Create and populate the "Web.RandomDateTimeValues" table as a preparation for loading the "Web.PageViews" table

CREATE TABLE
	Web.RandomDateTimeValues
(
	RandomDateTime DATETIME2(7) NOT NULL
);
GO


INSERT INTO
	Web.RandomDateTimeValues
(
	RandomDateTime
)
SELECT TOP (5000000)
	RandomDateTime = DATEADD (MILLISECOND , ABS (CHECKSUM (NEWID ())) % (24 * 60 * 60 * 1000) , DATEADD (DAY , - (ABS (CHECKSUM (NEWID ())) % (6 * 30)) , CAST (CAST (SYSDATETIME () AS DATE) AS DATETIME2(7))))
FROM
	sys.all_objects AS T1
CROSS JOIN
	sys.all_objects AS T2;
GO


DELETE FROM
	Web.RandomDateTimeValues
WHERE
	RandomDateTime > SYSDATETIME ();
GO


-- Populate the "Web.PageViews" table with data up until last week

INSERT INTO
	Web.PageViews WITH (TABLOCK)
(
	URL ,
	ReferenceCode ,
	SessionId ,
	DateAndTime
)
SELECT
	URL				= N'www.' + REPLICATE (N'x' , ABS (CHECKSUM (NEWID ())) % 90) + N'.com' ,
	ReferenceCode	= ABS (CHECKSUM (NEWID ())) % 1000000 + 1 ,
	SessionId		= ABS (CHECKSUM (NEWID ())) % 1000000 + 1 ,
	DateAndTime		= RandomDateTime
FROM
	Web.RandomDateTimeValues
WHERE
	RandomDateTime < DATEADD (WEEK , -1 , SYSDATETIME ())
ORDER BY
	RandomDateTime ASC;
GO


-- Update statistics on the "Web.PageViews" table with a full scan

UPDATE STATISTICS
	Web.PageViews
WITH
	FULLSCAN;
GO


-- Insert data for the last week into the "Web.PageViews" table
-- This will not trigger the automatic statistics update, so according to statistics there are still no rows in the last week

INSERT INTO
	Web.PageViews WITH (TABLOCK)
(
	URL ,
	ReferenceCode ,
	SessionId ,
	DateAndTime
)
SELECT
	URL				= N'www.' + REPLICATE (N'x' , ABS (CHECKSUM (NEWID ())) % 90) + N'.com' ,
	ReferenceCode	= ABS (CHECKSUM (NEWID ())) % 1000000 + 1 ,
	SessionId		= ABS (CHECKSUM (NEWID ())) % 1000000 + 1 ,
	DateAndTime		= RandomDateTime
FROM
	Web.RandomDateTimeValues
WHERE
	RandomDateTime >= DATEADD (WEEK , -1 , SYSDATETIME ())
ORDER BY
	RandomDateTime ASC;
GO
