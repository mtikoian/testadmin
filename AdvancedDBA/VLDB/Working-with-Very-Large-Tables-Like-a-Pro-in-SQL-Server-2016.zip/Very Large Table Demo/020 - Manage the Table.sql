USE
	VeryLargeTableDemo;
GO


-- This query displays information about the partitions in the "Web.PageViews" table
-- Since the table is currently not partitioned, it contains a single partition

SELECT
	PartitionId				= Partitions.partition_id ,
	PartitionNumber			= Partitions.partition_number ,
	NumberOfRows			= Partitions.rows
FROM
	sys.partitions AS Partitions
WHERE
	Partitions.object_id = OBJECT_ID (N'Web.PageViews')
AND
	Partitions.index_id = 1
ORDER BY
	PartitionNumber ASC;
GO


-- Create a partition function and a partition scheme with 182 daily partitions
-- (last 180 days + 1 empty partition for pre-history + 1 empty partition for the next day)

DECLARE
	@DatesTable TABLE
(
	DateValue DATETIME2(7) NOT NULL
);

INSERT INTO
	@DatesTable
(
	DateValue
)
SELECT TOP (181)
	DateValue = CAST (DATEADD (DAY , 2 - (ROW_NUMBER () OVER (ORDER BY (SELECT NULL))) , SYSDATETIME ()) AS DATETIME2(7))
FROM
	sys.all_columns;

DECLARE 
	@Statement AS NVARCHAR(MAX) =
		N'
			CREATE PARTITION FUNCTION
				pf_EveryDay (DATETIME2(7))
			AS RANGE
				RIGHT
			FOR VALUES
				(
					';

SELECT
	@Statement += N'''' + CONVERT (NCHAR(8) , DateValue , 112) + N''' ,
					'
FROM
	@DatesTable
ORDER BY
	DateValue ASC;

SET
	@Statement = LEFT (@Statement , LEN (@Statement) - 9) + N'
				);
		';

EXECUTE sys.sp_executesql
	@statement = @Statement;
GO


CREATE PARTITION SCHEME
	ps_EveryDay
AS
	PARTITION pf_EveryDay
ALL TO
	([PRIMARY]);
GO


-- Convert the "Web.PageViews" table to a partitioned table

ALTER TABLE
	Web.PageViews
DROP CONSTRAINT
	pk_PageViews_c_Id;
GO


ALTER TABLE
	Web.PageViews
ADD CONSTRAINT
	pk_PageViews_c_DateAndTime#Id
PRIMARY KEY CLUSTERED
	(
		DateAndTime	ASC ,
		Id			ASC
	)
ON
	ps_EveryDay (DateAndTime);
GO


-- This query displays information about the partitions in the "Web.PageViews" table

SELECT
	PartitionId				= Partitions.partition_id ,
	PartitionNumber			= Partitions.partition_number ,
	NumberOfRows			= Partitions.rows ,
	PartitionMinValue		= PartitionRangeValues.value ,
	IsBoundaryValueOnRight	= PartitionFunctions.boundary_value_on_right ,
	DestinationFilegroup	= Filegroups.name
FROM
	sys.partitions AS Partitions
INNER JOIN
	sys.indexes AS Indexes
ON
	Partitions.object_id = Indexes.object_id
AND
	Partitions.index_id = Indexes.index_id
LEFT OUTER JOIN
	sys.partition_range_values AS PartitionRangeValues
ON
	Partitions.partition_number = PartitionRangeValues.boundary_id + 1
LEFT OUTER JOIN
	sys.partition_functions AS PartitionFunctions
ON
	PartitionRangeValues.function_id = PartitionFunctions.function_id
INNER JOIN
	sys.destination_data_spaces AS DestinationDataSpaces
ON
	Partitions.partition_number = DestinationDataSpaces.destination_id
INNER JOIN
	sys.partition_schemes AS PartitionSchemes
ON
	DestinationDataSpaces.partition_scheme_id = PartitionSchemes.data_space_id
INNER JOIN
	sys.filegroups AS Filegroups
ON
	DestinationDataSpaces.data_space_id = Filegroups.data_space_id
WHERE
	Partitions.object_id = OBJECT_ID (N'Web.PageViews')
AND
	(PartitionFunctions.name = N'pf_EveryDay' OR PartitionFunctions.function_id IS NULL)
AND
	PartitionSchemes.name = N'ps_EveryDay'
AND
	Indexes.index_id = 1
ORDER BY
	PartitionNumber ASC;
GO


-- Create another table with an identical schema to "Web.PageViews", which will be used to switch
-- partitions out and then truncate them

CREATE TABLE
	Web.PageViews_ToDelete
(
	Id				BIGINT			NOT NULL ,
	URL				NVARCHAR(100)	NOT NULL ,
	ReferenceCode	BIGINT			NULL ,
	SessionId		BIGINT			NOT NULL ,
	DateAndTime		DATETIME2(7)	NOT NULL ,

CONSTRAINT
	pk_PageViewsToDelete_c_DateAndTime#Id
PRIMARY KEY CLUSTERED
	(
		DateAndTime	ASC ,
		Id			ASC
	)
)
ON
	[PRIMARY];
GO


-- Split the partition function and add a new partition for the next day

DECLARE
	@CurrentLastBoundary	AS DATETIME2(7) ,
	@NextBoundary			AS DATETIME2(7);

SELECT
	@CurrentLastBoundary = MAX (CAST (PartitionRangeValues.[value] AS DATETIME2(7)))
FROM
	sys.partition_range_values AS PartitionRangeValues
INNER JOIN
	sys.partition_functions AS PartitionFunctions
ON
	PartitionRangeValues.function_id = PartitionFunctions.function_id
WHERE
	PartitionFunctions.name = N'pf_EveryDay';

--SELECT
--	CurrentLastBoundary = @CurrentLastBoundary;

SET @NextBoundary = DATEADD (DAY , 1 , @CurrentLastBoundary);

ALTER PARTITION SCHEME
	ps_EveryDay
NEXT USED
	[PRIMARY];

ALTER PARTITION FUNCTION
	pf_EveryDay ()
SPLIT RANGE
	(@NextBoundary);
GO


-- This query displays information about the partitions in the "Web.PageViews" table

SELECT
	PartitionId				= Partitions.partition_id ,
	PartitionNumber			= Partitions.partition_number ,
	NumberOfRows			= Partitions.rows ,
	PartitionMinValue		= PartitionRangeValues.value ,
	IsBoundaryValueOnRight	= PartitionFunctions.boundary_value_on_right ,
	DestinationFilegroup	= Filegroups.name
FROM
	sys.partitions AS Partitions
INNER JOIN
	sys.indexes AS Indexes
ON
	Partitions.object_id = Indexes.object_id
AND
	Partitions.index_id = Indexes.index_id
LEFT OUTER JOIN
	sys.partition_range_values AS PartitionRangeValues
ON
	Partitions.partition_number = PartitionRangeValues.boundary_id + 1
LEFT OUTER JOIN
	sys.partition_functions AS PartitionFunctions
ON
	PartitionRangeValues.function_id = PartitionFunctions.function_id
INNER JOIN
	sys.destination_data_spaces AS DestinationDataSpaces
ON
	Partitions.partition_number = DestinationDataSpaces.destination_id
INNER JOIN
	sys.partition_schemes AS PartitionSchemes
ON
	DestinationDataSpaces.partition_scheme_id = PartitionSchemes.data_space_id
INNER JOIN
	sys.filegroups AS Filegroups
ON
	DestinationDataSpaces.data_space_id = Filegroups.data_space_id
WHERE
	Partitions.object_id = OBJECT_ID (N'Web.PageViews')
AND
	(PartitionFunctions.name = N'pf_EveryDay' OR PartitionFunctions.function_id IS NULL)
AND
	PartitionSchemes.name = N'ps_EveryDay'
AND
	Indexes.index_id = 1
ORDER BY
	PartitionNumber ASC;
GO


-- Switch the second partition (the first is empty) to the staging table, and then truncate it

ALTER TABLE
	Web.PageViews
SWITCH PARTITION
	2
TO
	Web.PageViews_ToDelete;
GO


TRUNCATE TABLE
	Web.PageViews_ToDelete;
GO


-- This query displays information about the partitions in the "Web.PageViews" table

SELECT
	PartitionId				= Partitions.partition_id ,
	PartitionNumber			= Partitions.partition_number ,
	NumberOfRows			= Partitions.rows ,
	PartitionMinValue		= PartitionRangeValues.value ,
	IsBoundaryValueOnRight	= PartitionFunctions.boundary_value_on_right ,
	DestinationFilegroup	= Filegroups.name
FROM
	sys.partitions AS Partitions
INNER JOIN
	sys.indexes AS Indexes
ON
	Partitions.object_id = Indexes.object_id
AND
	Partitions.index_id = Indexes.index_id
LEFT OUTER JOIN
	sys.partition_range_values AS PartitionRangeValues
ON
	Partitions.partition_number = PartitionRangeValues.boundary_id + 1
LEFT OUTER JOIN
	sys.partition_functions AS PartitionFunctions
ON
	PartitionRangeValues.function_id = PartitionFunctions.function_id
INNER JOIN
	sys.destination_data_spaces AS DestinationDataSpaces
ON
	Partitions.partition_number = DestinationDataSpaces.destination_id
INNER JOIN
	sys.partition_schemes AS PartitionSchemes
ON
	DestinationDataSpaces.partition_scheme_id = PartitionSchemes.data_space_id
INNER JOIN
	sys.filegroups AS Filegroups
ON
	DestinationDataSpaces.data_space_id = Filegroups.data_space_id
WHERE
	Partitions.object_id = OBJECT_ID (N'Web.PageViews')
AND
	(PartitionFunctions.name = N'pf_EveryDay' OR PartitionFunctions.function_id IS NULL)
AND
	PartitionSchemes.name = N'ps_EveryDay'
AND
	Indexes.index_id = 1
ORDER BY
	PartitionNumber ASC;
GO


-- Merge the first two partitions (which are now both empty)

DECLARE
	@CurrentFirstBoundary AS DATETIME2(7);

SELECT
	@CurrentFirstBoundary = MIN (CAST (PartitionRangeValues.[value] AS DATETIME2(7)))
FROM
	sys.partition_range_values AS PartitionRangeValues
INNER JOIN
	sys.partition_functions AS PartitionFunctions
ON
	PartitionRangeValues.function_id = PartitionFunctions.function_id
WHERE
	PartitionFunctions.name = N'pf_EveryDay';

ALTER PARTITION FUNCTION
	pf_EveryDay ()
MERGE RANGE
	(@CurrentFirstBoundary);
GO


-- This query displays information about the partitions in the "Web.PageViews" table

SELECT
	PartitionId				= Partitions.partition_id ,
	PartitionNumber			= Partitions.partition_number ,
	NumberOfRows			= Partitions.rows ,
	PartitionMinValue		= PartitionRangeValues.value ,
	IsBoundaryValueOnRight	= PartitionFunctions.boundary_value_on_right ,
	DestinationFilegroup	= Filegroups.name
FROM
	sys.partitions AS Partitions
INNER JOIN
	sys.indexes AS Indexes
ON
	Partitions.object_id = Indexes.object_id
AND
	Partitions.index_id = Indexes.index_id
LEFT OUTER JOIN
	sys.partition_range_values AS PartitionRangeValues
ON
	Partitions.partition_number = PartitionRangeValues.boundary_id + 1
LEFT OUTER JOIN
	sys.partition_functions AS PartitionFunctions
ON
	PartitionRangeValues.function_id = PartitionFunctions.function_id
INNER JOIN
	sys.destination_data_spaces AS DestinationDataSpaces
ON
	Partitions.partition_number = DestinationDataSpaces.destination_id
INNER JOIN
	sys.partition_schemes AS PartitionSchemes
ON
	DestinationDataSpaces.partition_scheme_id = PartitionSchemes.data_space_id
INNER JOIN
	sys.filegroups AS Filegroups
ON
	DestinationDataSpaces.data_space_id = Filegroups.data_space_id
WHERE
	Partitions.object_id = OBJECT_ID (N'Web.PageViews')
AND
	(PartitionFunctions.name = N'pf_EveryDay' OR PartitionFunctions.function_id IS NULL)
AND
	PartitionSchemes.name = N'ps_EveryDay'
AND
	Indexes.index_id = 1
ORDER BY
	PartitionNumber ASC;
GO


-- In SQL Server 2016 we can directly truncate a single partition

TRUNCATE TABLE
	Web.PageViews
WITH
	(PARTITIONS (2));
GO


-- This query displays information about the partitions in the "Web.PageViews" table

SELECT
	PartitionId				= Partitions.partition_id ,
	PartitionNumber			= Partitions.partition_number ,
	NumberOfRows			= Partitions.rows ,
	PartitionMinValue		= PartitionRangeValues.value ,
	IsBoundaryValueOnRight	= PartitionFunctions.boundary_value_on_right ,
	DestinationFilegroup	= Filegroups.name
FROM
	sys.partitions AS Partitions
INNER JOIN
	sys.indexes AS Indexes
ON
	Partitions.object_id = Indexes.object_id
AND
	Partitions.index_id = Indexes.index_id
LEFT OUTER JOIN
	sys.partition_range_values AS PartitionRangeValues
ON
	Partitions.partition_number = PartitionRangeValues.boundary_id + 1
LEFT OUTER JOIN
	sys.partition_functions AS PartitionFunctions
ON
	PartitionRangeValues.function_id = PartitionFunctions.function_id
INNER JOIN
	sys.destination_data_spaces AS DestinationDataSpaces
ON
	Partitions.partition_number = DestinationDataSpaces.destination_id
INNER JOIN
	sys.partition_schemes AS PartitionSchemes
ON
	DestinationDataSpaces.partition_scheme_id = PartitionSchemes.data_space_id
INNER JOIN
	sys.filegroups AS Filegroups
ON
	DestinationDataSpaces.data_space_id = Filegroups.data_space_id
WHERE
	Partitions.object_id = OBJECT_ID (N'Web.PageViews')
AND
	(PartitionFunctions.name = N'pf_EveryDay' OR PartitionFunctions.function_id IS NULL)
AND
	PartitionSchemes.name = N'ps_EveryDay'
AND
	Indexes.index_id = 1
ORDER BY
	PartitionNumber ASC;
GO


-- Merge the first two partitions (which are now both empty)

DECLARE
	@CurrentFirstBoundary AS DATETIME2(7);

SELECT
	@CurrentFirstBoundary = MIN (CAST (PartitionRangeValues.[value] AS DATETIME2(7)))
FROM
	sys.partition_range_values AS PartitionRangeValues
INNER JOIN
	sys.partition_functions AS PartitionFunctions
ON
	PartitionRangeValues.function_id = PartitionFunctions.function_id
WHERE
	PartitionFunctions.name = N'pf_EveryDay';

ALTER PARTITION FUNCTION
	pf_EveryDay ()
MERGE RANGE
	(@CurrentFirstBoundary);
GO


-- This query displays information about the partitions in the "Web.PageViews" table

SELECT
	PartitionId				= Partitions.partition_id ,
	PartitionNumber			= Partitions.partition_number ,
	NumberOfRows			= Partitions.rows ,
	PartitionMinValue		= PartitionRangeValues.value ,
	IsBoundaryValueOnRight	= PartitionFunctions.boundary_value_on_right ,
	DestinationFilegroup	= Filegroups.name
FROM
	sys.partitions AS Partitions
INNER JOIN
	sys.indexes AS Indexes
ON
	Partitions.object_id = Indexes.object_id
AND
	Partitions.index_id = Indexes.index_id
LEFT OUTER JOIN
	sys.partition_range_values AS PartitionRangeValues
ON
	Partitions.partition_number = PartitionRangeValues.boundary_id + 1
LEFT OUTER JOIN
	sys.partition_functions AS PartitionFunctions
ON
	PartitionRangeValues.function_id = PartitionFunctions.function_id
INNER JOIN
	sys.destination_data_spaces AS DestinationDataSpaces
ON
	Partitions.partition_number = DestinationDataSpaces.destination_id
INNER JOIN
	sys.partition_schemes AS PartitionSchemes
ON
	DestinationDataSpaces.partition_scheme_id = PartitionSchemes.data_space_id
INNER JOIN
	sys.filegroups AS Filegroups
ON
	DestinationDataSpaces.data_space_id = Filegroups.data_space_id
WHERE
	Partitions.object_id = OBJECT_ID (N'Web.PageViews')
AND
	(PartitionFunctions.name = N'pf_EveryDay' OR PartitionFunctions.function_id IS NULL)
AND
	PartitionSchemes.name = N'ps_EveryDay'
AND
	Indexes.index_id = 1
ORDER BY
	PartitionNumber ASC;
GO
