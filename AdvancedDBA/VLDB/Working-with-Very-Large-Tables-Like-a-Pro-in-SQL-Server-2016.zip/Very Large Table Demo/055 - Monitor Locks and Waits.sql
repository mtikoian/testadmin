USE
	VeryLargeTableDemo;
GO


-- Find the session ID of "Index Rebuild" and show its locks

DECLARE
	@SessionId AS SMALLINT;

SELECT
	@SessionId = Requests.session_id
FROM
	sys.dm_exec_Requests AS Requests
CROSS APPLY
	sys.dm_exec_sql_text (Requests.sql_handle) AS RequestTexts
WHERE
	RequestTexts.text LIKE N'%Index Rebuild%'
AND
	Requests.session_id != @@SPID;

SELECT
	*
FROM
	sys.dm_tran_locks
WHERE
	request_session_id = @SessionId;
GO


-- Find the session ID of "Session 1" and show its locks

DECLARE
	@SessionId AS SMALLINT;

SELECT
	@SessionId = Connections.session_id
FROM
	sys.dm_exec_connections AS Connections
CROSS APPLY
	sys.dm_exec_sql_text (Connections.most_recent_sql_handle) AS ConnectionTexts
WHERE
	ConnectionTexts.text LIKE N'%Session 1%'
AND
	Connections.session_id != @@SPID;

SELECT
	*
FROM
	sys.dm_tran_locks
WHERE
	request_session_id = @SessionId;
GO


-- Find the session ID of "Session 2" and show its locks

DECLARE
	@SessionId AS SMALLINT;

SELECT
	@SessionId = Connections.session_id
FROM
	sys.dm_exec_connections AS Connections
CROSS APPLY
	sys.dm_exec_sql_text (Connections.most_recent_sql_handle) AS ConnectionTexts
WHERE
	ConnectionTexts.text LIKE N'%Session 2%'
AND
	Connections.session_id != @@SPID;

SELECT
	*
FROM
	sys.dm_tran_locks
WHERE
	request_session_id = @SessionId;
GO


-- Find all the 3 session IDs and show their respective waiting tasks

DECLARE
	@IndexRebuildSessionId	AS SMALLINT ,
	@Session1Id				AS SMALLINT ,
	@Session2Id				AS SMALLINT;

SELECT
	@IndexRebuildSessionId = Requests.session_id
FROM
	sys.dm_exec_Requests AS Requests
CROSS APPLY
	sys.dm_exec_sql_text (Requests.sql_handle) AS RequestTexts
WHERE
	RequestTexts.text LIKE N'%Index Rebuild%'
AND
	Requests.session_id != @@SPID;

SELECT
	@Session1Id = Connections.session_id
FROM
	sys.dm_exec_connections AS Connections
CROSS APPLY
	sys.dm_exec_sql_text (Connections.most_recent_sql_handle) AS ConnectionTexts
WHERE
	ConnectionTexts.text LIKE N'%Session 1%'
AND
	Connections.session_id != @@SPID;

SELECT
	@Session2Id = Connections.session_id
FROM
	sys.dm_exec_connections AS Connections
CROSS APPLY
	sys.dm_exec_sql_text (Connections.most_recent_sql_handle) AS ConnectionTexts
WHERE
	ConnectionTexts.text LIKE N'%Session 2%'
AND
	Connections.session_id != @@SPID;

SELECT
	*
FROM
	sys.dm_os_waiting_tasks
WHERE
	session_id IN (@IndexRebuildSessionId , @Session1Id , @Session2Id);
GO
