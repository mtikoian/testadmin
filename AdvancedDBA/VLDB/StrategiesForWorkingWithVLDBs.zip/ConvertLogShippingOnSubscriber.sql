-- Run on server taking over as replication subscriber
-- Restore log backup to keep in sync
Use master;

Restore Log TwoTBDatabase
	From Disk = 'c:\bak\SQL1\TwoTBDatabase.trn'
	With NoRecovery;



-- Restore log backup to keep in sync
Use master;

Restore Log TwoTBDatabase
	From Disk = 'c:\bak\SQL2\TwoTBDatabase.trn'
	With Recovery; -- Note using RECOVERY option

-- Now create the subscription on the publisher
-- Create the subscription on the subscriber