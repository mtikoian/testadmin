-- Run on Publisher
USE TwoTBDatabase;

EXEC sp_addsubscription
	@publication = N'TwoTBDatabase_pub', 
	@subscriber = N'rodav1\SQL2', 
	@destination_db = N'TwoTBDatabase', 
	@subscription_type = N'Pull',
	@sync_type = N'initialize with backup',
	@backupdevicetype = N'Disk',
	-- Change this parameter to point to the backup file
	@backupdevicename = N'c:\bak\SQL2\TwoTBDatabase.trn',
	@article = N'all', 
	@update_mode = N'read only', 
	@subscriber_type = 0;
