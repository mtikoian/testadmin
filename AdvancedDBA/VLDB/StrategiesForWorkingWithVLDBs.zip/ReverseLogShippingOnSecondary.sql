-- Run on server taking over as log shipping primary
-- Restore log backup to recover the new primary
Use master;

Restore Log TwoTBDatabase
	From Disk = 'c:\bak\SQL1\TwoTBDatabase.trn'
	With Recovery; -- Note using RECOVERY


-- Configure the replication publication and enable initialize from backup
-- Create new log backup for restarting log shipping and creating replication subscriber.
Use master;

Backup Log TwoTBDatabase
	To Disk = 'c:\bak\SQL2\TwoTBDatabase.trn';
