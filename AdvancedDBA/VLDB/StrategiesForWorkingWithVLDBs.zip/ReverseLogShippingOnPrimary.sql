-- Run on original log shipping primary
-- Create log backup for reversing log shipping
Use master;

Backup Log TwoTBDatabase
	To Disk = 'c:\bak\SQL1\TwoTBDatabase.trn'
	With NoRecovery;



-- Restore log backup to complete log shipping reversal
Use master;

Restore Log TwoTBDatabase
	From Disk = 'c:\bak\SQL2\TwoTBDatabase.trn'
	With NoRecovery;
