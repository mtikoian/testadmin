select o.name as TableName,c.name as FKColumn from sys.sysreferences r
	Inner join sys.syscolumns c
		on r.fkeyid = c.id
		and r.fkey1 = c.colid
	Inner Join sys.sysobjects o
		on c.id = o.id
	--Left Outer Join sys.sysindexes i
	--	on c.colid = i.id
	Left Outer Join sys.sysindexkeys k
		on c.id = k.id
		And c.colid = k.colid
	Where k.id is null
	/* alternative to the is null in where clause
	convert(varchar(11),c.id) + ',' + convert(varchar(11),c.colid) 
			not in (select convert(varchar(11),id) + ',' + convert(varchar(11),colid) from sys.sysindexkeys)
	*/
	Order by o.name
	
		
select c.id from sys.syscolumns c
	where convert(varchar(11),c.id) + ',' + convert(varchar(11),c.colid) 
			not in (select convert(varchar(11),id) + ',' + convert(varchar(11),colid) from sys.sysindexkeys)
			
		select * from sys.syscolumns
		select * from sys.sysindexes where name = 'ix_contact'
		select * from sys.sysindexkeys
		