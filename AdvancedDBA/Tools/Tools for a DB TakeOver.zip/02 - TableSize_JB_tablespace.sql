/* Part I */
--Drop Table #indstats
If exists (select * from tempdb.sys.objects where name like '%#indstats%')
Begin
	Drop table tempdb.dbo.#indstats
End

Begin
CREATE TABLE #indstats (
         IndStatsID Int PRIMARY KEY CLUSTERED
        ,database_id BIGINT
        ,index_id BIGINT
        ,IndexSizeMB DECIMAL(16,1)
        ,OBJECT_ID	BIGINT
);
End


INSERT INTO #indstats (IndStatsID,database_id,index_id,OBJECT_ID,IndexSizeMB)
        SELECT Row_Number() over (order by Object_id) as IndStatsID
				,database_id,index_id,OBJECT_ID
				,CONVERT(DECIMAL(19,2),(SUM(ps.page_count))) * 8 /1024 AS IndexSizeMB
			FROM sys.dm_db_index_physical_stats(DB_ID(),null,NULL,NULL,'DETAILED') ps
			GROUP BY database_id,OBJECT_ID,index_id;

/* Part II */
declare @dbsize decimal(19,2)


set nocount on

/*
**  Summary data.
*/
begin
	select @dbsize = sum(convert(decimal(19,2),case when type = 0 then size else 0 end)) * 8/1024
		from sys.database_files

end

/* Part III */
Begin
	With RegData as (
		SELECT a.container_id,p.OBJECT_ID,p.index_id,us.database_id
			,FileGroupName = FILEGROUP_NAME(a.data_space_id)
			,TableName = OBJECT_NAME(p.OBJECT_ID)
			,NumRows = p.rows
			,UsedPages = IsNull(a.used_pages,0)
			,TotalPages = IsNull(a.total_pages,0)
			,DataSizeMB = Convert(decimal(19,2),IsNull(a.used_pages,0)) * 8/1024
			,IndexSizeMB = case when ps.index_id < 2 then 0 else ps.IndexSizeMB end
			,UserRequests = IsNull(us.user_seeks,0) + IsNull(us.user_scans,0) + IsNull(us.user_lookups,0)
			,UserUpdates = IsNull(us.user_updates,0)
			,LastUpdate = IsNull(us.last_user_update,null)
			,RatioRequestsToUpdates = CAST(IsNull(us.user_seeks,0) 
					+ IsNull(us.user_scans,0) + IsNull(us.user_lookups,0) AS REAL)
				/ CAST(CASE us.user_updates WHEN 0 THEN 1 ELSE us.user_updates END AS REAL)
		FROM sys.allocation_units a
			Inner Join sys.partitions p
				On p.hobt_id = a.container_id
				And a.type = 1
			Left Outer Join sys.dm_db_index_usage_stats us
				ON us.OBJECT_ID = p.OBJECT_ID
				And us.index_id = p.index_id
				And us.database_id = DB_ID()
			Left Outer Join #indstats ps
				ON p.index_id = ps.index_id
				And ps.database_id = DB_ID()
				And p.OBJECT_ID = ps.OBJECT_ID
		--WHERE OBJECTPROPERTY(p.OBJECT_ID,'IsMSShipped') = 0
	)
	, LOBData as (
		SELECT a.container_id,p.OBJECT_ID,p.index_id,us.database_id
			,FileGroupName = FILEGROUP_NAME(a.data_space_id)
			,TableName = OBJECT_NAME(p.OBJECT_ID)
			,NumRows = p.rows
			,UsedPages = IsNull(a.used_pages,0)
			,TotalPages = IsNull(a.total_pages,0)
			,DataSizeMB = Convert(decimal(19,2),IsNull(a.used_pages,0)) * 8/1024
			,IndexSizeMB = case when ps.index_id < 2 then 0 else ps.IndexSizeMB end
			,UserRequests = IsNull(us.user_seeks,0) + IsNull(us.user_scans,0) + IsNull(us.user_lookups,0)
			,UserUpdates = IsNull(us.user_updates,0)
			,LastUpdate = IsNull(us.last_user_update,null)
			,RatioRequestsToUpdates = CAST(IsNull(us.user_seeks,0) 
					+ IsNull(us.user_scans,0) + IsNull(us.user_lookups,0) AS REAL)
				/ CAST(CASE us.user_updates WHEN 0 THEN 1 ELSE us.user_updates END AS REAL)
		FROM sys.allocation_units a
			Inner Join sys.partitions p
				ON p.partition_id = a.container_id
				And a.type = 2
			Left Outer Join sys.dm_db_index_usage_stats us
				ON us.OBJECT_ID = p.OBJECT_ID
				And us.index_id = p.index_id
				And us.database_id = DB_ID()
			Left Outer Join #indstats ps
				ON p.index_id = ps.index_id
				And ps.database_id = DB_ID()
				And p.OBJECT_ID = ps.OBJECT_ID
		--WHERE OBJECTPROPERTY(p.OBJECT_ID,'IsMSShipped') = 0
	)
	, OverFlowData as (
		SELECT a.container_id,p.OBJECT_ID,p.index_id,us.database_id
			,FileGroupName = FILEGROUP_NAME(a.data_space_id)
			,TableName = OBJECT_NAME(p.OBJECT_ID)
			,NumRows = p.rows
			,UsedPages = IsNull(a.used_pages,0)
			,TotalPages = IsNull(a.total_pages,0)
			,DataSizeMB = Convert(decimal(19,2),IsNull(a.used_pages,0)) * 8/1024
			,IndexSizeMB = case when ps.index_id < 2 then 0 else ps.IndexSizeMB end
			,UserRequests = IsNull(us.user_seeks,0) + IsNull(us.user_scans,0) + IsNull(us.user_lookups,0)
			,UserUpdates = IsNull(us.user_updates,0)
			,LastUpdate = IsNull(us.last_user_update,null)
			,RatioRequestsToUpdates = CAST(IsNull(us.user_seeks,0) 
					+ IsNull(us.user_scans,0) + IsNull(us.user_lookups,0) AS REAL)
				/ CAST(CASE us.user_updates WHEN 0 THEN 1 ELSE us.user_updates END AS REAL)
		FROM sys.allocation_units a
			Inner Join sys.partitions p
				On p.hobt_id = a.container_id
				And a.type = 3
			Left Outer Join sys.dm_db_index_usage_stats us
				ON us.OBJECT_ID = p.OBJECT_ID
				And us.index_id = p.index_id
				And us.database_id = DB_ID()
			Left Outer Join #indstats ps
				ON p.index_id = ps.index_id
				And ps.database_id = DB_ID()
				And p.OBJECT_ID = ps.OBJECT_ID
		--WHERE OBJECTPROPERTY(p.OBJECT_ID,'IsMSShipped') = 0
	), IndexSum as (
		Select a.object_id
		,AllDataSizeMB = sum(case when a.index_id in (0,1) 
							Then IsNull(a.DataSizeMB,0) +  IsNull(p2.DataSizeMB,0) +  IsNull(p3.DataSizeMB,0)
							Else IsNull(p2.DataSizeMB,0) + IsNull(p3.DataSizeMB,0)
							End)
		From RegData a
			Left Outer Join LOBData p2
				ON p2.container_id = a.container_id
			Left Outer Join OverFlowData p3
				ON p3.container_id = a.container_id
		Group By a.object_id
	), SummaryInfo as (
		SELECT 
			TableName = Max(a.TableName)
			,InRowDataSizeMB = sum(IsNull(a.DataSizeMB,0))
			,LOBDataSizeMB = sum(IsNull(p2.DataSizeMB,0))
			,OFlowDataSizeMB = sum(IsNull(p3.DataSizeMB,0))
			,NumRows = Max(Coalesce(a.NumRows,p2.NumRows,p3.NumRows,0))
			,AllUsedPages = sum(IsNull(a.UsedPages,0) + IsNull(p2.UsedPages,0) + IsNull(p3.UsedPages,0))
			,AllPages = sum(IsNull(a.TotalPages,0) + IsNull(p2.TotalPages,0) + IsNull(p3.TotalPages,0))
			,FreeDataSpace = convert(decimal(19,2),
				sum(IsNull(a.TotalPages,0) + IsNull(p2.TotalPages,0) + IsNull(p3.TotalPages,0)) 
				- sum(IsNull(a.UsedPages,0) + IsNull(p2.UsedPages,0) + IsNull(p3.UsedPages,0)))* 8 / 1024
			,AllDataSizeMB = Max(ids.AllDataSizeMB)
			,IndexSizeMB = Sum(IsNull(a.IndexSizeMB,0)) 
				+ sum(IsNull(p2.IndexSizeMB,0)) + sum(IsNull(p3.IndexSizeMB,0))
			,UserRequests = Avg(IsNull(a.UserRequests,0) 
				+ IsNull(p2.UserRequests,0) + IsNull(p3.UserRequests,0))
			,UserUpdates = Avg(IsNull(a.UserUpdates,0) + IsNull(p2.UserUpdates,0) + IsNull(p3.UserUpdates,0))
			,LastUpdate = Max(Coalesce(a.LastUpdate,p2.LastUpdate,p3.LastUpdate,null))
			,DatabaseSize = @dbsize
		FROM RegData a
			Left Outer Join LOBData p2
				ON p2.container_id = a.container_id
			Left Outer Join OverFlowData p3
				ON p3.container_id = a.container_id
			Left Outer Join sys.indexes i
				ON i.OBJECT_ID = a.OBJECT_ID
				And i.index_id = a.index_id
			Left Outer Join IndexSum ids
				On i.object_id = ids.object_id
		--WHERE filegroup_name(a.data_space_id) = 'Primary'
		Group by a.object_id
	)
	Select TableName,NumRows,InRowDataSizeMB,LOBDataSizeMB,OFlowDataSizeMB
			,AllUsedPages,AllPages
			,FreeDataSpace,AllDataSizeMB,IndexSizeMB
			,TableSizeMB = AllDataSizeMB + IndexSizeMB + FreeDataSpace
			,UserRequests,UserUpdates,LastUpdate
			,PercentofDB = ((IndexSizeMB + AllDataSizeMB) / DatabaseSize) * 100
			,DatabaseSize
		From SummaryInfo
		Order By PercentofDB desc
End