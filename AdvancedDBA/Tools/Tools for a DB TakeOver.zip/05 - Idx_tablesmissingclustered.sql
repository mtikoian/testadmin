With MissingClustered as 
(
Select o.object_id,o.name as TableName,isnull(i.index_id,0) as IndexID
	From sys.objects o
		Left Outer Join sys.indexes i
			On o.object_id = i.object_id
			And I.index_id = 1
	Where i.index_id is null
		And o.type = 'U'
)
--Retrieve the rowcount for the table that is missing a clustered index
Select TableName,IndexID,SUM(p.rows) as TableRowCount
	From MissingClustered M
		Inner Join sys.indexes i
			On m.object_id = i.object_id
			And m.IndexID = i.index_id
		Inner Join sys.partitions P 
			ON P.object_id = i.object_id 
			And P.index_id = I.index_id
			And I.index_id < 2
	Group By TableName,IndexID
	Order by TableName


/*
--select * from sys.indexes

--sql2k
SELECT Rows, object_Name(id) as TableName FROM sysindexes WHERE indid < 2 and OBJECTPROPERTY(id, 'IsUserTable') = 1
--sql2k5
SELECT OBJECT_NAME(p.object_id) AS [Name], SUM(p.rows) as TableRowCount FROM sys.indexes I
INNER JOIN sys.partitions P ON P.object_id = I.object_id AND P.index_id = I.index_id
WHERE I.index_id < 2
Group By OBJECT_NAME(p.object_id)


*/
