--find column name of clustered index
--all clustered indexes
Select o.name As TableName,i.index_id
	,COL_NAME(ic.OBJECT_ID,ic.column_id) As ColumnName,t.name As DataType
From sys.objects o
	Inner Join sys.indexes i
		On o.object_id = i.object_id
		And I.index_id = 1
	Inner Join sys.index_columns AS ic
		On i.OBJECT_ID = ic.OBJECT_ID
		And i.index_id = ic.index_id
		--And i.is_primary_key = 1
	Inner Join sys.columns sc
		On sc.column_id = ic.column_id
		And ic.object_id = sc.object_id
	Inner Join sys.types t
		On sc.user_type_id = t.user_type_id
Where o.is_ms_shipped = 0
Order by o.name

--pks with clustered
Select o.name As TableName,i.index_id
	,COL_NAME(ic.OBJECT_ID,ic.column_id) As ColumnName,t.name As DataType
From sys.objects o
	Inner Join sys.indexes i
		On o.object_id = i.object_id
		And I.index_id = 1
	Inner Join sys.index_columns AS ic
		On i.OBJECT_ID = ic.OBJECT_ID
		And i.index_id = ic.index_id
		And i.is_primary_key = 1
	Inner Join sys.columns sc
		On sc.column_id = ic.column_id
		And ic.object_id = sc.object_id
	Inner Join sys.types t
		On sc.user_type_id = t.user_type_id
Where o.is_ms_shipped = 0
Order by o.name

--only Non PK
Select o.name As TableName,i.index_id
	,COL_NAME(ic.OBJECT_ID,ic.column_id) As ColumnName,t.name As DataType
From sys.objects o
	Inner Join sys.indexes i
		On o.object_id = i.object_id
		And I.index_id = 1
	Inner Join sys.index_columns AS ic
		On i.OBJECT_ID = ic.OBJECT_ID
		And i.index_id = ic.index_id
		And i.is_primary_key <> 1
	Inner Join sys.columns sc
		On sc.column_id = ic.column_id
		And ic.object_id = sc.object_id
	Inner Join sys.types t
		On sc.user_type_id = t.user_type_id
Where o.is_ms_shipped = 0
Order by o.name

--Primary key Query
SELECT OBJECT_NAME(ic.OBJECT_ID) AS TableName,i.name AS ConstraintName,COL_NAME(ic.OBJECT_ID,ic.column_id) AS ColumnName
	,t.name as DataType
	FROM sys.indexes AS i
	INNER JOIN sys.index_columns AS ic
		ON i.OBJECT_ID = ic.OBJECT_ID
		AND i.index_id = ic.index_id
		And i.is_primary_key = 1
	Inner Join sys.columns sc
		On sc.column_id = ic.column_id
		And ic.object_id = sc.object_id
	Inner Join sys.types t
		On sc.user_type_id = t.user_type_id
	Order by OBJECT_NAME(ic.OBJECT_ID)

SELECT name as TableName, ObjectProperty(object_id, 'TableHasPrimaryKey') AS HasPrimaryKey
FROM sys.tables