DECLARE	@StartParentTable	Varchar(256)

SELECT @StartParentTable = 'loanprogramvariation'

;With FkCascade (ParentTable,ParentColumn, ChildTable,ChildColumn, FKLevel, SortCol) as (
	Select OBJECT_NAME(sfk.referenced_object_id) as ParentTable
	,sc2.name as ParentColumn
	,OBJECT_NAME(sfk.Parent_object_id) as ChildTable
	,sc.name as ChildColumn
	,0 as FKLevel,cast(row_number() over(order by sfk.referenced_object_id) as varbinary(50))
	From sys.foreign_key_columns sfkc
		Inner Join sys.foreign_keys sfk
			On sfkc.constraint_object_id = sfk.object_id
		Inner Join sys.columns sc
			On sfkc.parent_object_id = sc.object_id
			And sfkc.parent_column_id = sc.column_id
		Inner join sys.columns sc2
			On sfkc.referenced_object_id = sc2.object_id
			And sfkc.referenced_column_id = sc2.column_id
		Where OBJECT_NAME(sfk.referenced_object_id) = @StartParentTable
	Union All
	Select OBJECT_NAME(sfk.referenced_object_id) as ParentTable
	,sc2.name as ParentColumn
	,OBJECT_NAME(sfk.Parent_object_id) as ChildTable
	,sc.name as ChildColumn
	,FKLevel + 1,cast(SortCol + cast(row_number() over(order by sfk.referenced_object_id) as varbinary(3)) as varbinary(50))
		From FkCascade F
		Inner Join sys.foreign_keys sfk
			On f.ChildTable = OBJECT_NAME(sfk.referenced_object_id)
		Inner Join sys.foreign_key_columns sfkc
			On sfkc.constraint_object_id = sfk.object_id
		Inner Join sys.columns sc
			On sfkc.parent_object_id = sc.object_id
			And sfkc.parent_column_id = sc.column_id
		Inner join sys.columns sc2
			On sfkc.referenced_object_id = sc2.object_id
			And sfkc.referenced_column_id = sc2.column_id
), WalkBackUp (ParentTable,ParentColumn, ChildTable,ChildColumn, FKLevel, SortCol) as (
	Select distinct OBJECT_NAME(sfk.referenced_object_id) as ParentTable
	,sc2.name as ParentColumn
	,OBJECT_NAME(sfk.Parent_object_id) as ChildTable
	,sc.name as ChildColumn
	,-1 as FKLevel,cast(SortCol + cast(row_number() over(order by sfk.referenced_object_id) as varbinary(3)) as varbinary(50))
		From FkCascade F
			Inner Join sys.foreign_keys sfk
				On f.ChildTable = OBJECT_NAME(sfk.parent_object_id)
				And F.ParentTable <> OBJECT_NAME(sfk.referenced_object_id)
			Inner Join sys.foreign_key_columns sfkc
				On sfkc.constraint_object_id = sfk.object_id
			Inner Join sys.columns sc
				On sfkc.parent_object_id = sc.object_id
				And sfkc.parent_column_id = sc.column_id
			Inner join sys.columns sc2
				On sfkc.referenced_object_id = sc2.object_id
				And sfkc.referenced_column_id = sc2.column_id
	Union All
	Select OBJECT_NAME(sfk.referenced_object_id) as ParentTable
	,sc2.name as ParentColumn
	,OBJECT_NAME(sfk.Parent_object_id) as ChildTable
	,sc.name as ChildColumn
	,f.FKLevel -1,cast(SortCol + cast(row_number() over(order by sfk.referenced_object_id) as varbinary(3)) as varbinary(50))
		From WalkBackup F
			Inner Join sys.foreign_keys sfk
				On f.parentTable = OBJECT_NAME(sfk.parent_object_id)
			Inner Join sys.foreign_key_columns sfkc
				On sfkc.constraint_object_id = sfk.object_id
			Inner Join sys.columns sc
				On sfkc.parent_object_id = sc.object_id
				And sfkc.parent_column_id = sc.column_id
			Inner join sys.columns sc2
				On sfkc.referenced_object_id = sc2.object_id
				And sfkc.referenced_column_id = sc2.column_id
		Where f.parentTable not in (select ParentTable from FKCascade)
)

Select ParentTable,ParentColumn, ChildTable,ChildColumn, FKLevel, SortCol
From FKCascade
Union All
Select ParentTable,ParentColumn, ChildTable,ChildColumn, FKLevel, SortCol
From WalkBackUp
	Order By SortCol asc
	option (maxrecursion 500)