/*similar to sp_spaceused */


declare @dbsize decimal(19,2)
		,@logsize decimal(19,2)


set nocount on

/*
**  Summary data.
*/
begin
	select @dbsize = sum(convert(decimal(19,2),case when type = 0 then size else 0 end)) * 8/1024
		, @logsize = sum(convert(decimal(19,2),case when type = 1 then size else 0 end)) * 8/1024
		from sys.database_files

end
/*
**  We want all objects.
*/
Begin
	With FirstPass as (
		SELECT OBJECT_ID,
			ReservedPage = convert(decimal(19,2),SUM(reserved_page_count)) * 8/1024,
			UsedPage = convert(decimal(19,2),SUM(used_page_count)) *8/1024,
			PageCnt = SUM(
			convert(decimal(19,2),CASE
				WHEN (index_id < 2) 
					THEN (used_page_count)
				ELSE lob_used_page_count + row_overflow_used_page_count
				END
			)) * 8/1024,
			RowCnt = SUM(
			CASE
				WHEN (index_id < 2) 
					THEN row_count
				ELSE 0
			END
			)
		FROM sys.dm_db_partition_stats 
		--Where OBJECTPROPERTY(OBJECT_ID,'IsMSShipped') = 0
		Group By OBJECT_ID
	)
	,InternalTables as (
		Select ps.OBJECT_ID,
			ReservedPage = convert(decimal(19,2),SUM(reserved_page_count)) * 8/1024,
			UsedPage = convert(decimal(19,2),SUM(used_page_count)) *8/1024
		From sys.dm_db_partition_stats  ps
			Inner Join sys.internal_tables it
				On it.OBJECT_ID = ps.OBJECT_ID
				And it.internal_type IN (202,204,211,212,213,214,215,216)
		Where it.parent_id = ps.OBJECT_ID
			--And OBJECTPROPERTY(ps.OBJECT_ID,'IsMSShipped') = 0
		Group By ps.OBJECT_ID
	)
	,Summary as (
		SELECT 
			ObjName = OBJECT_NAME (f.OBJECT_ID),
			NumRows = MAX(f.rowcnt),
			ReservedPageMB = SUM(IsNull(f.reservedpage,0) + IsNull(i.ReservedPage,0)),
			DataSizeMB = Sum(f.PageCnt),
			IndexSizeMB = Sum(CASE WHEN (f.UsedPage + IsNull(i.UsedPage,0)) > f.PageCnt 
							THEN ((f.UsedPage + IsNull(i.UsedPage,0)) - f.PageCnt) ELSE 0 END) ,-- Equivalent of max_record_size from sys.dm_db_index_physical_stats
			UnusedSpace = Sum(CASE WHEN (f.ReservedPage + IsNull(i.ReservedPage,0)) > (f.UsedPage + IsNull(i.UsedPage,0)) 
				THEN ((f.ReservedPage + IsNull(i.ReservedPage,0)) - (f.UsedPage + IsNull(i.UsedPage,0))) ELSE 0 END),
			DBSizeMB = @Dbsize,
			LogSizeMB = @logsize
		From FirstPass F
			Left Outer Join InternalTables i
			On i.OBJECT_ID = f.OBJECT_ID
		Group By f.OBJECT_ID
	)
	Select ObjName,NumRows, ReservedPageMB, DataSizeMB, IndexSizeMB, UnusedSpace, DBSizeMB, LogSizeMB,
			PercentofDB = ((IndexSizeMb + DataSizeMB) / @DBsize) * 100

	From Summary
	Order By PercentofDB desc
End