/*
	REMEMEBER TO SET SQLCMD MODE
*/

/****** 
	Create a Policy manually on the Database Maintenance
	facet, for the Condition 
	"LastBackupDate >= dateadd(�day�, -1, getdate())"
******/

:CONNECT SQLMDW
USE MDW

-- Create the custom_mdw_overview_reports table. This is used by the 
-- MdwOverviewCustom.rdl report. The table lists all available top-level 
-- custom reports and all of the SQL instances that have data in the MDW 
-- db to support that report.  It also maps each of these reports 
-- to a collection set so that the report can display the last upload time 
-- for the data that drives a report. 
IF OBJECT_ID ('dbo.custom_mdw_overview_reports') IS NULL
BEGIN
    RAISERROR ('Creating table dbo.custom_mdw_overview_reports...',0, 1) 
	WITH NOWAIT;

    CREATE TABLE dbo.custom_mdw_overview_reports (
        top_level_report_file_name          NVARCHAR(400) NOT NULL, 
        top_level_report_display_name       NVARCHAR(1024) NOT NULL, 
        collection_set_uid                  UNIQUEIDENTIFIER NOT NULL, 
        max_expected_upload_delay_minutes   INT
    );
    
    GRANT SELECT ON dbo.custom_mdw_overview_reports TO mdw_reader; 
    GRANT INSERT ON dbo.custom_mdw_overview_reports TO mdw_admin; 
    GRANT UPDATE ON dbo.custom_mdw_overview_reports TO mdw_admin; 
    GRANT DELETE ON dbo.custom_mdw_overview_reports TO mdw_admin; 
    GRANT SELECT ON dbo.custom_mdw_overview_reports TO mdw_admin; 
    
    ALTER TABLE dbo.custom_mdw_overview_reports 
		ADD CONSTRAINT pk_custom_mdw_overview_reports 
		PRIMARY KEY CLUSTERED (top_level_report_file_name)
			WITH (IGNORE_DUP_KEY=ON)
END;

-- Add the reports we want to be able to launch from here
RAISERROR ('Registering the Server Activity top-level custom report...',0, 1) 
			WITH NOWAIT;

DELETE FROM dbo.custom_mdw_overview_reports 
	WHERE top_level_report_display_name = 'Server Activity';
INSERT INTO dbo.custom_mdw_overview_reports 
	(
		top_level_report_file_name, 
		top_level_report_display_name, 
		collection_set_uid, 
		max_expected_upload_delay_minutes
	)
VALUES 
	(
		'0E456729-BC31-47D5-9118-E7B9D2C9B25D', -- just an ID
		'Server Activity', 
		'49268954-4FD4-4EB6-AA04-CD59D9BB5714', -- dbo.syscollector_collection_sets
		120
	); 

