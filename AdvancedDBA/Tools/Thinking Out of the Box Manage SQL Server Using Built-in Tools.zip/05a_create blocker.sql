/*
	REMEMEBER TO SET SQLCMD MODE
*/

:CONNECT SQL2012

/****** Script to lock the table  ******/
USE AdventureWorks2012

BEGIN TRAN
UPDATE HumanResources.Employee 
SET VacationHours += 75

/****** Clean up transaction  ******/
--ROLLBACK TRAN
