/*
	REMEMEBER TO SET SQLCMD MODE
*/

--On the MDW Instance:
:CONNECT SQLMDW

-- Create the login matching the proxy account so all collectors can 
-- connect the same way.
USE [master]
GO
CREATE LOGIN [LAB\DC_Proxy] FROM WINDOWS ;
GO

-- Allow access to the MDW database and 
USE [MDW]
GO
CREATE USER [DC_Proxy] FOR LOGIN [LAB\DC_Proxy] WITH DEFAULT_SCHEMA = [snapshots];
GO
-- The roles below are added when we run the wizard:
--ALTER ROLE [mdw_writer] ADD MEMBER [DC_Proxy]
--GO
--ALTER ROLE [mdw_reader] ADD MEMBER [DC_Proxy]
--GO

-- On the collector instance
:CONNECT SQL2012

-- Create the login and proxy for data collections
USE [master]
GO
CREATE CREDENTIAL [DC_Proxy] WITH IDENTITY=N'LAB\DC_Proxy', SECRET=N'm1Lng8v13' ;
GO
CREATE LOGIN [LAB\DC_Proxy] FROM WINDOWS ;
GO

-- Give the login permission to access Data Collector objects
-- We'll come back later and configure the collectors to use the proxy
USE [msdb]
GO
CREATE USER [LAB\DC_Proxy] FOR LOGIN [LAB\DC_Proxy] WITH DEFAULT_SCHEMA = dbo ;
GO
ALTER ROLE [dc_proxy] ADD MEMBER [LAB\DC_Proxy] ;
GO

USE [msdb]
GO
-- Create the proxy
EXEC dbo.sp_add_proxy @proxy_name=N'DC_Proxy', @credential=N'DC_Proxy'
	, @enabled=1, @description=N'Proxy for the Data Collector' ;
GO

-- Give the msdb role access to the proxy
EXEC dbo.sp_grant_login_to_proxy @proxy_name=N'DC_Proxy', @msdb_role=N'dc_proxy' ;
GO

-- Add to �Operating System (CmdExec)�
EXEC dbo.grant_proxy_to_subsystem @proxy_name=N'DC_Proxy', @subsystem_id = 3 ;
GO
