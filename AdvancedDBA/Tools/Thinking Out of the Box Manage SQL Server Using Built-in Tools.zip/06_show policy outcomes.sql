/*
	REMEMEBER TO SET SQLCMD MODE
*/

:CONNECT SQL2012
USE msdb

/****** Script for show Policy events from system tables  ******/
SELECT p.name
     , phd.execution_date
	 , ph.result
  FROM [dbo].[syspolicy_policy_execution_history] ph
  JOIN [dbo].[syspolicy_policies] p ON ph.policy_id = p.policy_id
  JOIN [dbo].[syspolicy_policy_categories] pc ON p.policy_category_id = pc.policy_category_id
  JOIN [dbo].[syspolicy_policy_execution_history_details] phd ON ph.history_id = phd.history_id
WHERE pc.name = N'Data Collection' 
      --AND p.is_enabled = 1
	  AND ph.result = 0

/****** Script for show Policy events from logs  ******/
DECLARE @log1 TABLE 
(
	LogDate DATETIME NOT NULL, 
	ProcessInfo NVARCHAR(32) NOT NULL, 
	Text NVARCHAR(MAX)
)
DECLARE @log2 TABLE 
(
	LogDate DATETIME NOT NULL, 
	ProcessInfo NVARCHAR(32) NOT NULL, 
	Text NVARCHAR(MAX)
)
INSERT @log1 
	EXEC sys.sp_readerrorlog -1, 1, '3405'
INSERT @log2 
	EXEC sys.sp_readerrorlog 

SELECT  [@log1].LogDate, 
	[@log1].ProcessInfo, 
	[@log1].Text + N' : ' + [@log2].Text AS [Text]
FROM @log1 JOIN @log2 
	ON [@log2].LogDate = [@log1].LogDate 
	AND [@log2].ProcessInfo = [@log1].ProcessInfo 
	AND [@log2].Text != [@log1].Text
GO


