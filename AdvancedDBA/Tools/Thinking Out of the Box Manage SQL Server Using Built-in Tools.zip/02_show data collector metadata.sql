/*
	REMEMEBER TO SET SQLCMD MODE
*/

:CONNECT SQL2012
USE [msdb]

/****** Script for Data Collector Configuration Information  ******/
SELECT [parameter_name]
      ,[parameter_value]
  FROM [dbo].[syscollector_config_store]

/****** Script for Data Collector Collection Sets  ******/
SELECT [collection_set_id]
      ,[collection_set_uid]
      ,[schedule_uid]
      ,[name]
      ,[is_running]
      ,[is_system]
      ,[collection_job_id]
      ,[upload_job_id]
      ,[collection_mode]
      ,[description]
      ,[days_until_expiration]
  FROM [dbo].[syscollector_collection_sets] ;

/****** Script for Data Collector Collection Items  ******/
SELECT [collection_set_id]
      ,[collection_item_id]
      ,[collector_type_uid]
      ,[name]
      ,[frequency]
      ,[parameters]
  FROM [dbo].[syscollector_collection_items]

/****** Script for Data Collector Collector Types   ******/
SELECT [collector_type_uid]
      ,[name]
      ,[parameter_schema]
      ,[parameter_formatter]
      ,[collection_package_name]
      ,[collection_package_path]
      ,[upload_package_name]
      ,[upload_package_path]
      ,[is_system]
  FROM [dbo].[syscollector_collector_types]

/****** Script for Data Collector SSIS Packages   ******/
SELECT [name]
      ,[description]
	  ,[createdate]
	  ,[ownersid]
FROM [dbo].[sysssispackages]
WHERE [description] = N'System Data Collector Package' ;

/****** Show the cache folder in operation   ******/
--
-- Open folder on SQL2012 : C:\DCCache
--

/****** Script for Data Collector Sources on the MDW   ******/
:CONNECT SQLMDW
USE MDW

SELECT src.source_id
      ,ISNULL(cs.name, 'Custom')
	  ,src.instance_name
	  ,src.days_until_expiration
	  ,src.operator 
FROM core.source_info_internal src
     LEFT JOIN [msdb].[dbo].[syscollector_collection_sets] cs ON src.collection_set_uid = cs.collection_set_uid

/****** Script for Data Collector Snapshots that have been Uploaded to THIS MDW  ******/
SELECT source_id
      ,snapshot_id
	  ,snapshot_time_id
	  ,snapshot_time
	  ,valid_through
FROM core.snapshots

/****** Script for example collections uploaded  ******/
SELECT snapshot_id
      ,dbsize
	  ,logsize
	  ,ftsize
	  ,reservedpages
	  ,usedpages
	  ,pages
	  ,database_name
	  ,collection_time
FROM snapshots.disk_usage

SELECT TOP (200) snapshot_id
      ,performance_counter_id
	  ,performance_object_name
	  ,performance_counter_name
	  ,performance_instance_name
	  ,[path]
FROM snapshots.performance_counters


