/*
	REMEMEBER TO SET SQLCMD MODE
*/

/****** 
	Create a Policy manually on the Database Maintenance
	facet, for the Condition 
	"LastBackupDate >= dateadd(�day�, -1, getdate())"

	Evaluate and show failures
******/

/****** 
	Create another Policy on the Server Performance facet, for the
	Condition "BlockedProcessThreshold  = 5"

	Evaluate and show failures
******/

/****** 
	To check the Policy does work as expected we then need to 
	backup a database and recheck
******/

:CONNECT SQL2012
USE master

BACKUP DATABASE [Training] TO
DISK='C:\Program Files\Microsoft SQL Server\MSSQL11.MSSQLSERVER\MSSQL\Backup\training.bak' ;

/****** 
	Evaluate the Policy again and see that Training is now compliant
******/

/****** 
	To check the Blocked Threshold works, we need to configure 
	the Blocked Process Threshold value
******/
:CONNECT SQL2012
USE master

-- It is an Advanced Option
EXEC sp_configure 'show advanced options',1
reconfigure

-- Show the current value
EXEC sp_configure 'blocked process threshold (s)'

-- Set it to 5 seconds
EXEC sp_configure 'blocked process threshold (s)', 5

-- Check the new value
EXEC sp_configure 'blocked process threshold (s)'

-- Switch Advanced Settings off again
EXEC sp_configure 'show advanced options',0
reconfigure
GO

/****** 
	Evaluate the Policy again and see that is is now compliant
******/
