/*
http://msdn.microsoft.com/en-us/library/ms174396(v=SQL.90).aspx

EXEC master..sp_enumerrorlogs
EXEC master.dbo.sp_readerrorlog 0,1,'version'
EXEC master.dbo.xp_readerrorlog 0,1,'version'
SELECT SERVERPROPERTY('ProductVersion')
SELECT SERVERPROPERTY('ProcessID')
select serverproperty('MachineName')
*/

/*
--Examine error log for a particular instance
IF(
select Left(cast(SERVERPROPERTY('ProductVersion') as varchar(20)), charindex('.', cast(SERVERPROPERTY('ProductVersion') as varchar(20)), 0) -1)
) ='8'
	Begin 
	EXEC master.dbo.sp_readerrorlog 0,1,'copyright'
	END
ELSE
	BEGIN
	EXEC master.dbo.xp_readerrorlog 0,1,'copyright'
	END
*/

EXEC master.dbo.xp_readerrorlog 0,1,'starting'
 
