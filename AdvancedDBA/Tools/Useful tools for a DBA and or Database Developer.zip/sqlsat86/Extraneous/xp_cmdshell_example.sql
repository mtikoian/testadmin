sp_configure 'show advanced options',1
go
reconfigure with override
go
sp_configure 'xp_cmdshell',1
go
reconfigure with override
go


--xp_cmdshell 'SYSTEMINFO |find "cpu:"'
xp_cmdshell 'SYSTEMINFO'


sp_configure 'xp_cmdshell',0
go
reconfigure with override
go
sp_configure 'show advanced options',0
go
reconfigure with override
go
