/*
create blocking statement
*/
use AdventureWorks_sqlsat86

begin tran
update Person.Address
set PostalCode=98011
where AddressID=1
--commit tran

