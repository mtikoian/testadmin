set statistics io on

select a.AddressID, a.AddressLine1, a.AddressLine2, a.City ,a.StateProvinceID, a.PostalCode, a.rowguid, a.ModifiedDate
from Person.Address a
inner join Person.address b on a.AddressID=b.AddressID
where a.AddressID > 5000 and a.AddressID < 15000
go 100

