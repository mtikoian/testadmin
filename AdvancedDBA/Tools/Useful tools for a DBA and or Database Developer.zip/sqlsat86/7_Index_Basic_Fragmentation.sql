/*
http://msdn.microsoft.com/en-us/library/ms188917.aspx
*/
SELECT OBJECT_NAME(a.object_id) AS table_name,b.name AS index_name,index_type_desc AS index_type, 
avg_fragmentation_in_percent AS fragmentation
FROM   sys.dm_db_index_physical_stats (  db_id('AdventureWorks'), OBJECT_ID('person.Address'), NULL, NULL, 'DETAILED')a
INNER JOIN sys.indexes b   ON a.object_id = b.object_id AND a.index_id = b.index_id






