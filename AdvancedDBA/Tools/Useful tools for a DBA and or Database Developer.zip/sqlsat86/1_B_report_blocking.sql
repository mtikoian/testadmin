/*
show how this this compares to blocking report
*/
select blocking_session_id,* from sys.dm_exec_requests
where blocking_session_id > 0
