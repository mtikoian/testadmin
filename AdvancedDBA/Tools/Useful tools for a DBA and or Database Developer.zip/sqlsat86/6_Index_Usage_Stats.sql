/*
http://msdn.microsoft.com/en-us/library/ms188755.aspx
*/
SELECT
db_name(database_id) AS DBName,
database_id,
OBJECT_NAME(OBJECT_ID) AS TableName,
index_id,
(SELECT NAME FROM sys.indexes si WHERE si.object_id=ius.OBJECT_ID AND si.index_id=ius.index_id) AS IndexName,
user_seeks ,
user_scans ,
user_lookups ,
user_updates ,
last_user_seek ,
last_user_scan ,
last_user_lookup ,
last_user_update
--system_seeks ,
--system_scans ,
--system_lookups ,
--system_updates ,
--last_system_seek ,
--last_system_scan ,
--last_system_lookup ,
--last_system_update
FROM sys.dm_db_index_usage_stats ius
WHERE database_id > 4 AND object_id > 100 and db_name(database_id)=db_name()
ORDER BY ius.object_id,ius.index_id





