set transaction isolation level serializable

select * from Person.Address

update Person.Address
set PostalCode=98011
go 100

set transaction isolation level serializable

update Person.Address
set PostalCode=98011

select * from Person.Address
