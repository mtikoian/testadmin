/*
create blocked event
*/
use AdventureWorks_sqlsat86
go

select AddressID, AddressLine1, AddressLine2, City, StateProvinceID, PostalCode, rowguid, ModifiedDate
from Person.Address

