--dbcc freeproccache

select DB_NAME(dbid),objtype,plan_handle,text,refcounts,usecounts from sys.dm_exec_cached_plans cp
cross apply 
sys.dm_exec_sql_text(cp.plan_handle) st
where text like '%sp_ssrs_address%' and dbid in (8,17)

select * from sys.dm_exec_query_plan(0x0500080059ED607FB8A0B811000000000000000000000000)
select * from sys.dm_exec_query_plan(0x0500110095555D02B8202510000000000000000000000000)