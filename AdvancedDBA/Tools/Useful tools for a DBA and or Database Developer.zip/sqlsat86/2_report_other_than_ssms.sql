/*
Provides object type and description
*/
SELECT type,type_desc from sys.all_objects
GROUP BY type,type_desc

/*
Pull information about tables within your database
*/
SELECT name, create_date, modify_date,object_id, principal_id, schema_id, parent_object_id, type, type_desc,  is_ms_shipped, is_published, is_schema_published 
FROM sys.all_objects
WHERE type='U' AND object_id > 0 and create_date >='11/05/2011 00:00:00'


/*
Pull information about procedures within your database
*/
SELECT name, create_date, modify_date,object_id, principal_id, schema_id, parent_object_id, type, type_desc,  is_ms_shipped, is_published, is_schema_published 
FROM sys.all_objects
WHERE type='P' AND object_id > 0

/*
Pull information about your indexes
*/
SELECT OBJECT_NAME(object_id) AS TableName,type_desc,index_id FROM sys.indexes
WHERE object_id > 100

