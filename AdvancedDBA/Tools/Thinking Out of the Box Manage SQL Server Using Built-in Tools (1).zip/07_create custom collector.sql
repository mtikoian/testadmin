/*
	REMEMEBER TO SET SQLCMD MODE
*/

:CONNECT SQL2012
USE msdb;

-- Make sure that the Proxy has permission to create the 
-- new data collector packages
ALTER ROLE [dc_admin] ADD MEMBER [LAB\DC_Proxy]


-- Create a table on the collection instance to track which log
-- entries have been sent to the MDW
BEGIN TRY
	DROP TABLE dbo.MDW_Tracking_Dates ;
END TRY
BEGIN CATCH
END CATCH

CREATE TABLE dbo.MDW_Tracking_Dates
(
	CollectionSetName nvarchar(128) NOT NULL,
	LastCollectionTime datetime2(7) NOT NULL
)

-- Seed the table with the default date value for the collection
INSERT dbo.MDW_Tracking_Dates
(
	CollectionSetName,
	LastCollectionTime
)
VALUES (N'Policy Management', '2012-01-01') ;

-- Check the entries
SELECT *
FROM dbo.MDW_Tracking_Dates ;





-- Create a stored procedure to extract the log data and store
-- the updated extract date
CREATE PROCEDURE dbo.Policy_Data_Collection
AS
SET NOCOUNT ON;

DECLARE @LastExecution datetime2(7);
DECLARE @TempStorage TABLE
(
	ExecutionTime datetime2(7) DEFAULT GETDATE(),
	[name] nvarchar(128),
	[execution_date] datetime,
	[result] int
)

SELECT @LastExecution = ISNULL(LastCollectionTime, '2012-01-01' )
FROM [msdb].[dbo].[MDW_Tracking_Dates]
WHERE CollectionSetName = N'Policy Management' ;

-- Now get the data into a temp table so we can also
-- return the extraction date and time
INSERT @TempStorage 
	(
		[name],
		[execution_date],
		[result]
	)
SELECT p.name
     , phd.execution_date
	 , ph.result
  FROM [msdb].[dbo].[syspolicy_policy_execution_history] ph
  JOIN [msdb].[dbo].[syspolicy_policies] p ON ph.policy_id = p.policy_id
  JOIN [msdb].[dbo].[syspolicy_policy_categories] pc ON p.policy_category_id = pc.policy_category_id
  JOIN [msdb].[dbo].[syspolicy_policy_execution_history_details] phd ON ph.history_id = phd.history_id
WHERE pc.name = N'Data Collection' 
      AND ph.result = 0
	  AND phd.execution_date > @LastExecution ;

IF @@ROWCOUNT > 0
BEGIN
	BEGIN TRY
		BEGIN TRAN
			SELECT @LastExecution = MAX(ExecutionTime)
			FROM @TempStorage ;

			UPDATE [msdb].[dbo].[MDW_Tracking_Dates]
			SET LastCollectionTime = @LastExecution
			WHERE CollectionSetName = N'Policy Management' ;
	END TRY
	BEGIN CATCH
		DECLARE @ErrorMessage NVARCHAR(4000);
		DECLARE @ErrorSeverity INT;
		DECLARE @ErrorState INT;
  
		SELECT  @ErrorMessage = ERROR_MESSAGE(),
				@ErrorSeverity = ERROR_SEVERITY(),
				@ErrorState = ERROR_STATE();
  
		RAISERROR (@ErrorMessage, -- Message text.
                   @ErrorSeverity, -- Severity.
                   @ErrorState -- State.
                  )
  		ROLLBACK TRAN 
	END CATCH

	COMMIT TRAN
END

SELECT [name],
	   [execution_date],
	   [result]
FROM @TempStorage 
GO

-- Make sure that the proxy can execute the procedure
GRANT EXECUTE ON dbo.Policy_Data_Collection TO [dc_proxy]


-- Create the Collection Set

DECLARE @collection_set_id int;
DECLARE @collection_set_uid uniqueidentifier

EXEC dbo.sp_syscollector_create_collection_set
    @name = N'Policy Management',
    @collection_mode = 1,		-- Non-cached mode. We want to collect & load together
    @description = N'Gathers details of Policy Failures',
    @logging_level=2,			-- Level of detail. 2 is full: debug
    @days_until_expiration = 14,
	@proxy_name = N'DC_Proxy',	-- Still running as Proxy
    @schedule_name=N'CollectorSchedule_Every_6h',
    @collection_set_id = @collection_set_id OUTPUT,
    @collection_set_uid = @collection_set_uid OUTPUT;
SELECT @collection_set_id,@collection_set_uid;

DECLARE @collector_type_uid uniqueidentifier;
SELECT @collector_type_uid = collector_type_uid 
FROM syscollector_collector_types 
WHERE name = N'Generic T-SQL Query Collector Type';

-- Call the stored procedure
-- note the DB restriction - we only need to run this
-- once in MSDB
DECLARE @collection_item_id int;
EXEC sp_syscollector_create_collection_item
@name= N'Policies',
@parameters=N'
<ns:TSQLQueryCollector xmlns:ns="DataCollectorType">
<Query>
  <Value>EXEC [msdb].[dbo].Policy_Data_Collection</Value>
  <OutputTable>policy_failures</OutputTable>
</Query>
<Databases>
  <Database>msdb</Database>
</Databases>
 </ns:TSQLQueryCollector>',
    @collection_item_id = @collection_item_id OUTPUT,
    @collection_set_id = @collection_set_id,
    @collector_type_uid = @collector_type_uid;
SELECT @collection_item_id;
   

-- We can now drop the Proxy out of the roles
ALTER ROLE [dc_admin] DROP MEMBER [LAB\DC_Proxy]
ALTER ROLE [dc_operator] DROP MEMBER [LAB\DC_Proxy]
