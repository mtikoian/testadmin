/*
	REMEMEBER TO SET SQLCMD MODE
*/

:CONNECT SQL2012

/****** Script to trigger blocking  ******/
USE AdventureWorks2012

SELECT *
FROM HumanResources.Employee
WHERE VacationHours > 100



