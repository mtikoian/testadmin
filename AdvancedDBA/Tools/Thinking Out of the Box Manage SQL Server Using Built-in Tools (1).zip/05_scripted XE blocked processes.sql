/*
	REMEMEBER TO SET SQLCMD MODE
*/

:CONNECT SQL2012
USE msdb

/****** Script for create a Blocked Process Event Session  ******/
CREATE EVENT SESSION [Blocked Process] ON SERVER 
ADD EVENT sqlserver.blocked_process_report
(
    ACTION( package0.collect_system_time,
			sqlserver.server_instance_name,
			sqlserver.session_id,
			sqlserver.request_id
		  )
) 
ADD TARGET package0.event_file
(
	SET filename=N'C:\Program Files\Microsoft SQL Server\MSSQL11.MSSQLSERVER\MSSQL\Log\Blocked_Process.xel'
)
WITH (STARTUP_STATE=OFF)


ALTER EVENT SESSION [Blocked Process] ON SERVER
STATE = START
GO
