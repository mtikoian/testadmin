-----------------------------------------------------------------------------
-- Author       : Craig Purnell  
-- Presentation : Integrating SQL Server with Active Directory
--              : Demo Code for SQL Saturday #75
-----------------------------------------------------------------------------
USE [Interfaces]
GO
--create the AD schema
CREATE SCHEMA [AD] AUTHORIZATION [dbo]
GO
--ADUsers table 
--this is the base schema that you see in ADUC
CREATE TABLE [AD].[ADUsers](
	[cn] varchar(max) NULL,
	[givenName] varchar(max) NULL,
	[initials] varchar(50) NULL,
	[sn] varchar(max) NULL,
	[displayname] varchar(max) NULL,
	--[description] varchar(max) NULL, --problem w/ driver
	[physicaldeliveryofficename] varchar(max) NULL,
	[telephonenumber] varchar(max) NULL,
	[othertelephone] varchar(max) NULL, --multivalued
	[mail] varchar(max) NULL,
	[wwwhomepage] varchar(max) NULL,
	[url] varchar(max) NULL, --multivalued
	[streetaddress] varchar(max) NULL,
	--[postofficebox] varchar(max) NULL, throwing an error 
	[l] varchar(max) NULL, 
	[st] varchar(max) NULL,
	[postalcode] varchar(max) NULL,
	[countrycode] varchar(max) NULL,
	[userprincipalName] varchar(max) NULL, 
	[samAccountname] varchar(max) NULL,
	[useraccountcontrol] varchar(10) nULL,
	[logonhours] varbinary NULL,
	[userworkstations] varchar(max) NULL, --multivalued
	[pwdlastset] varchar(max),
	--[useraccountcontrol] bit
	--[useraccountcontrol] bit
	--[useraccountcontrol] bit
	[accountexpires] varchar(max) NULL,
	[profilepath] varchar(max) NULL,
	[scriptpath] varchar(max) NULL,
	[homedirectory1] varchar(max) NULL,
	[homedrive] varchar(max) NULL,
	[homedirectory2] varchar(max) NULL,
	[homephone] varchar(max) NULL,
	--[otherhomephone] varchar(max) NULL, --multivalued
	[pager] varchar(max) NULL,
	[otherpager] varchar(max) NULL, --multivalued
	[mobile] varchar(max) NULL,
	--[othermobile] varchar(max) NULL, --multivalued
	[facsimileTelephoneNumber] varchar(max) NULL,
	[otherfacsimileTelephoneNumber] varchar(max) NULL, -- multivalued
	[IPPhone] varchar(max) NULL,
	[otherIPPhone] varchar(max) NULL, --multivalued
	[info] varchar(max),
	[Title] varchar(max) NULL,
	[Department] varchar(max) NULL,
	[company] varchar(max) NULL,
	[manager] varchar(max) NULL,
	[Disabled] [bit] NULL
) ON [PRIMARY]
GO
-------------------------------------------------------------
-- Create the Linked Server to AD
-------------------------------------------------------------
EXEC master.dbo.sp_addlinkedserver @server = N'ADSI'
, @srvproduct=N'Active Directory Services 2.5'
, @provider=N'ADsDSOObject'
, @datasrc=N'adsdatasource'

----------------------------------------------------------
-- master view into the AD
----------------------------------------------------------
CREATE view [AD].[vw_adsi] as
--note that we are filtering disabled accounts at the LDAP level - not at the SQL level
SELECT cn,givenname,initials,sn,displayname,physicaldeliveryofficename,telephonenumber,othertelephone,mail,wwwhomepage, url
,streetaddress,l,st,postalcode,co
,userprincipalname,samaccountname,useraccountcontrol, logonhours, userworkstations, pwdlastset, accountexpires
,profilepath, scriptpath, homedirectory, homedrive
,homephone, pager, otherpager, mobile, othermobile, facsimiletelephonenumber, otherfacsimiletelephonenumber
,ipphone, otherIpphone, info,title, department, company, manager  
,CAST(2 & CAST(userAccountControl AS int) AS bit) AS [Disabled]
FROM
OPENQUERY(adsi, '<LDAP://dc=fabrikam,dc=com>;(&(objectCategory=Person)(objectClass=user)(!userAccountControl:1.2.840.113556.1.4.803:=2));
cn,givenname,initials,sn,displayname,physicaldeliveryofficename,telephonenumber,othertelephone,mail,wwwhomepage, url
,streetaddress,l,st,postalcode,co
,userprincipalname,samaccountname,useraccountcontrol, logonhours, userworkstations, pwdlastset, accountexpires
,profilepath, scriptpath, homedirectory, homedrive
,homephone, pager, otherpager, mobile, othermobile, facsimiletelephonenumber, otherfacsimiletelephonenumber
,ipphone, otherIpphone, info
,title, department, company, manager;subtree')





