USE [INTERFACES];
GO
-----------------------------------------------------------------------------
-- Author       : Craig Purnell  
-- Presentation : Integrating SQL Server with Active Directory
--              : Demo Code for SQL Saturday #75
-----------------------------------------------------------------------------
-- Example usage of newADuser
-- creating users in AD from inside SQL Server
------------------------------------------------------------------------------
DECLARE @samaccountname varchar(100) = 'asmith';
DECLARE @firstname varchar(100) = 'Agent';
DECLARE @lastname varchar(100) = 'Smith';
DECLARE @emailaddress varchar(100) = 'asmith@fabrikam.com';
DECLARE @password varchar(100) = 'p@ssw0rd';
DECLARE @domain varchar(100) = 'Fabrikam';
DECLARE @path varchar(100) = 'ou=Executive, dc=Fabrikam, dc=com';

EXEC [dbo].[newADUser] @samaccountname, @firstname, @lastname, @emailaddress, @password, @domain, @path;
------------------------------------------------------------------------------
-- Example usage of newADGroup
-- Creating a group in AD from inside of SQL Server
------------------------------------------------------------------------------
DECLARE @name varchar(100) = 'CrossBorder';
DECLARE @desc varchar(100) = 'Created 6/06/11 by CP DO NOT DELETE'
DECLARE @domain varchar(100) = 'Fabrikam';
DECLARE @path varchar(100) = 'ou=Executive, dc=Fabrikam, dc=com';

EXEC [dbo].[newADGroup] @name, @desc, @domain, @path;

------------------------------------------------------------------------------
-- Example groups that a user is a member of 
------------------------------------------------------------------------------
DECLARE @samaccountname varchar(100) = 'sculp';
DECLARE @domain varchar(100) = 'Fabrikam';
DECLARE @path varchar(100) = 'ou=Executive, dc=Fabrikam, dc=com';
EXEC [dbo].[enumGroupsForaUser] @samaccountname, @domain, @path;

--------------------------------------------------------------------------------
-- Enumerate users in a group
--------------------------------------------------------------------------------
DECLARE @groupname varchar(100) = 'PASS';
DECLARE @recursive bit = 1;
DECLARE @domain varchar(100) = 'Fabrikam';
DECLARE @path varchar(100) = 'ou=Executive, dc=Fabrikam, dc=com';
EXEC [dbo].[enumUsersInaGroup] @groupname, @recursive, @domain, @path;
-------------------------------------------------------------------------------
-- Get rootDSE
-------------------------------------------------------------------------------
SELECT [INTERFACES].[dbo].[getrootDSE] ()

