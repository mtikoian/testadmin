-----------------------------------------------------------------------------
-- Author       : Craig Purnell  
-- Presentation : Integrating SQL Server with Active Directory
--              : Demo Code for SQL Saturday #75
----------------------------------------------
-- Select from the view
----------------------------------------------
SELECT * FROM [AD].[vw_adsi];
GO
----------------------------------------------
-- use Openquery - really the same thing
-- note that we are not filtering on disabled accounts
----------------------------------------------
SELECT * 
FROM
OPENQUERY(adsi, '<LDAP://dc=fabrikam,dc=com>;(&(objectCategory=Person)(objectClass=user)(!userAccountControl:1.2.840.113556.1.4.803:=2));
cn,givenname,initials,sn,displayname,physicaldeliveryofficename,telephonenumber,othertelephone,mail,wwwhomepage, url
,streetaddress,l,st,postalcode,co
,userprincipalname,samaccountname,useraccountcontrol, logonhours, userworkstations, pwdlastset, accountexpires
,profilepath, scriptpath, homedirectory, homedrive
,homephone, pager, otherpager, mobile, othermobile, facsimiletelephonenumber, otherfacsimiletelephonenumber
,ipphone, otherIpphone, info
,title, department, company, manager
 ;subtree')
----------------------------------------------------------------
-- OPENROWSET: note that page size has NO effect here
----------------------------------------------------------------
SELECT * FROM OPENROWSET
( 'AdsDsoObject' , 'User ID=bogus;Password=bogus;ADSI Flag=0x11;Page Size=10000', 
'SELECT givenName,sn, samaccountname FROM ''LDAP://DC=fabrikam,DC=com''')
