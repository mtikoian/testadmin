-----------------------------------------------------------------------------
-- Author       : Craig Purnell  
-- Presentation : Integrating SQL Server with Active Directory
--              : Demo Code for SQL Saturday #75
-----------------------------------------------------------------------------
-- clean up script
DROP DATABASE INTERFACES;
GO
sp_dropserver 'ADSI'
GO
USE [msdb]
GO
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'ADSI Refresh from AD')
EXEC msdb.dbo.sp_delete_job @job_name=N'ADSI Refresh from AD', @delete_unused_schedule=1
GO


--create the interfaces databases
CREATE DATABASE [INTERFACES] ON  PRIMARY 
( NAME = N'INTERFACES', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL10_50.MSSQLSERVER\MSSQL\DATA\INTERFACES.mdf' , SIZE = 51200KB , FILEGROWTH = 1024KB )
 LOG ON 
( NAME = N'INTERFACES_log', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL10_50.MSSQLSERVER\MSSQL\DATA\INTERFACES_log.ldf' , SIZE = 20480KB , FILEGROWTH = 10%)
GO
---------------------------------------------------
--recreate the assemblies 
---------------------------------------------------
ALTER DATABASE [Interfaces] SET TRUSTWORTHY ON 
GO
USE [INTERFACES]
GO 
CREATE ASSEMBLY [System.DirectoryServices] FROM 
'C:\Windows\Microsoft.NET\Framework\v2.0.50727\System.DirectoryServices.dll' 
WITH PERMISSION_SET = UNSAFE 
GO
CREATE ASSEMBLY [System.DirectoryServices.Protocols] FROM 
'C:\Windows\Microsoft.NET\Framework\v2.0.50727\System.DirectoryServices.Protocols.dll' 
WITH PERMISSION_SET = UNSAFE 
GO
CREATE ASSEMBLY [System.DirectoryServices.AccountManagement] FROM 
'C:\Program Files\Reference Assemblies\Microsoft\Framework\v3.5\System.DirectoryServices.AccountManagement.dll' 
WITH PERMISSION_SET = UNSAFE 
GO