﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using Microsoft.SqlServer.Server;
using System.DirectoryServices;

public partial class UserDefinedFunctions
{
    [Microsoft.SqlServer.Server.SqlFunction]
    public static SqlString getrootDSE()
    {
        // Craig Purnell - SQL Satuday #75 Integrating Active Directory with SQL Server
        //!!!! WARNING: THIS CODE IS PROOF OF CONCEPT ONLY !!!!
        //!!!! DO NOT RUN THIS IN PRODUCTION !!!!!
        String defaultNamingContext;
        DirectoryEntry rootDSE = new DirectoryEntry("LDAP://rootDSE");
        defaultNamingContext = rootDSE.Properties["defaultNamingContext"].Value.ToString();
        return new SqlString(defaultNamingContext);
    }
};

