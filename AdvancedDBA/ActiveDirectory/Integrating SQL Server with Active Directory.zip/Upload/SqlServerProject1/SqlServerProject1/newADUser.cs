﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using Microsoft.SqlServer.Server;
using System.DirectoryServices;
using System.DirectoryServices.AccountManagement;
using System.DirectoryServices.Protocols;

public partial class StoredProcedures
{
    [Microsoft.SqlServer.Server.SqlProcedure]
    public static void newADUser(string samaccountname, string firstname, string lastname, string emailaddress, string password, string domain, string path)
    {
        // Craig Purnell - SQL Satuday #75 Integrating Active Directory with SQL Server
        //!!!! WARNING: THIS CODE IS PROOF OF CONCEPT ONLY !!!!
        //!!!! DO NOT RUN THIS IN PRODUCTION !!!!!
        String adContainer = path; //your LDAP path to the OU where new users go
        String adDomain = domain; 
        PrincipalContext adPrincipalContext = new PrincipalContext(ContextType.Domain, adDomain, adContainer);
        if (adPrincipalContext != null) //comm channel to a DC
        {
                UserPrincipal user = new UserPrincipal(adPrincipalContext, samaccountname, password, true);
                user.GivenName = firstname;
                user.Surname = lastname;
                user.EmailAddress = emailaddress;
                user.ExpirePasswordNow();
                user.Save();
  
        }
    }
};
