﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using Microsoft.SqlServer.Server;
using System.DirectoryServices;
using System.DirectoryServices.AccountManagement;
using System.DirectoryServices.Protocols;

public partial class StoredProcedures
{
    [Microsoft.SqlServer.Server.SqlProcedure]
    public static void newADGroup(String name, String desc, String domain, String path)
    {
        // Craig Purnell - SQL Satuday #75 Integrating Active Directory with SQL Server
        //!!!! WARNING: THIS CODE IS PROOF OF CONCEPT ONLY !!!!
        //!!!! DO NOT RUN THIS IN PRODUCTION !!!!!
        String adContainer = path; //your LDAP path to the OU where new groups go
        String adDomain = domain;
        PrincipalContext adPrincipalContext = new PrincipalContext(ContextType.Domain, adDomain, adContainer);
        GroupPrincipal group = new GroupPrincipal(adPrincipalContext, name);
        group.DisplayName = name;
        group.Description = desc;
        group.Save();
    }
};
