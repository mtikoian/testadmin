﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using Microsoft.SqlServer.Server;
using System.DirectoryServices;
using System.DirectoryServices.AccountManagement;


public partial class StoredProcedures
{
    [Microsoft.SqlServer.Server.SqlProcedure]
    public static void enumUsersInaGroup(String groupname, bool recursive, String domain, String path)
    {
        // Craig Purnell - SQL Satuday #75 Integrating Active Directory with SQL Server
        //!!!! WARNING: THIS CODE IS PROOF OF CONCEPT ONLY !!!!
        //!!!! DO NOT RUN THIS IN PRODUCTION !!!!!
        String adContainer = path;
        String adDomain = domain;
        PrincipalContext adPrincipalContext = new PrincipalContext(ContextType.Domain, adDomain, adContainer);
        GroupPrincipal gp = GroupPrincipal.FindByIdentity(adPrincipalContext, IdentityType.Name, groupname);
        //recursive in this context means search nested groups and return their contents
        PrincipalSearchResult<Principal> results = gp.GetMembers(recursive);

        SqlMetaData columns = new SqlMetaData("Users", SqlDbType.NVarChar, 4000);
        SqlDataRecord record = new SqlDataRecord(new SqlMetaData[] { columns });

        SqlContext.Pipe.SendResultsStart(record); //headers

        foreach (Principal result in results)
        {
            record.SetString(0, result.Name);
            SqlContext.Pipe.SendResultsRow(record); //return row back to client
        }
        SqlContext.Pipe.SendResultsEnd();
        gp.Dispose();
    }
};
