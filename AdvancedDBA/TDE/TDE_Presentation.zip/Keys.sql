CREATE MASTER KEY ENCRYPTION BY PASSWORD='Instance1_StrongPassword111'
GO
CREATE CERTIFICATE MyEncryptionCert
with subject='dbaduck.com', expiry_date = '20160131'

GO
CREATE SYMMETRIC KEY SymKey1 AUTHORIZATION dbo
WITH ALGORITHM = AES_256 ENCRYPTION BY CERTIFICATE MyEncryptionCert

open symmetric key SymKey1
decryption by certificate MyEncryptionCert

select EncryptByKey(Key_GUID('SymKey1'), '411111111111111', 1, HASHBYTES('SHA1', N'3333333'))
select EncryptByKey(Key_GUID('SymKey1'), '555555555555555', 1, HASHBYTES('SHA1', N'4444444'))
select EncryptByKey(Key_GUID('SymKey1'), '411111111111111')
select EncryptByKey(Key_GUID('SymKey1'), '555555555555555')

select CONVERT(varchar(50), DECRYPTBYKEY(/* Put Key Here */))

CREATE ASYMMETRIC KEY ASymKey1 
WITH ALGORITHM = RSA_1024 

select *
from sys.asymmetric_keys

drop asymmetric key Asymkey1
drop symmetric key SymKey1
drop certificate MyEncryptionCert
drop master key
