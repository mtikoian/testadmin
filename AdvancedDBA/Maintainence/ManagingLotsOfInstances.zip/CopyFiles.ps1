﻿#------------------------------------------------------------------------------
# Script: CopyFiles
# Author: M.Wilkinson
# Date: 2016.03.14 14:40
# Parameters:
#
# Purpose:
# This is a generic script to copy files to a specified list of instances
#
#------------------------------------------------------------------------------

# Command line parameters
param(
    [string]$source,
    [string]$servers,
    [string]$filePath,
    [string]$destPath,
    [string]$postCopy,
    [string]$preCopy,
    [int]$ParallelJobs = 20
)

if( ([System.Diagnostics.Process]::GetCurrentProcess()).ProcessName -eq 'powershell_ise')
{
    throw "This script must be run via a PowerShell console, not via ISE."
}


Import-Module DBOps -Force

Write-Host "Getting instances..."
Try{
    If ( Test-Path $servers ) {
        $instances = Get-CmsHosts -instanceList $servers
    } Else {
        $instances = Get-CmsHosts -searchPattern $servers
    }
} Catch {
    Write-Host "Error getting instances: $($_.Exception.Message)" -ForegroundColor White -BackgroundColor Red
}

# Get a list of our files
if(Test-Path $filePath -PathType Container) {
    $type = 'p'
} elseif (Test-Path $filePath -PathType Leaf) {
    $type = 'f'
} else {
    Write-Host "Invalid Path - $filePath" -ForegroundColor White -BackgroundColor Red
    break
}

Write-Host "Source Type: $($type)"
Write-Host "     Source: $($filePath)"
Write-Host "Files will be deployed to the following hosts:"
Foreach ($instance IN $instances){
    Write-Host "   - $instance"
}
Write-Host "The following post-copy command(s) will be executed:"
Write-Host $postCopy
pause
# Now we loop through our instances and deploy the files
$TotalProgress = $instances.Count
$PerCycle = 100 / $TotalProgress
$Progress = 0

foreach ($instance IN $instances){
    Write-Progress -Activity 'Copying Files...' -Status "$([int]$Progress)% Complete" -PercentComplete $Progress    
    $scriptBlock_Copy = {
        param(
            $files,
            $instance,
            $filePath,
            $destPath,
            $postCopy,
            $preCopy,
            $type
        )

        $destination = '\\' + $instance + '\' + $destPath

        $scriptBlock_PreInstall = [Scriptblock]::Create($preCopy)

        if ( $preCopy ) {
            try {
                If ( Test-Connection -Count 1 -ComputerName $instance - ) {
                    Invoke-Command -ComputerName $instance -ScriptBlock $scriptBlock_PreInstall -ErrorAction Stop
                    Write-Host "Pre copy complete: $instance." -ForegroundColor Green -BackgroundColor Black
                } else {
                    throw "Cannot connect to remote instance."
                }
            } catch {
                Write-Host "Failed to run pre copy: $instance - $($_.Exception.Message)" -ForegroundColor White -BackgroundColor Red
                continue
            }
        
            if (!(Test-Path Microsoft.PowerShell.Core\FileSystem::$destination)) {
                Try {
                    New-Item -Path Microsoft.PowerShell.Core\FileSystem::$destination -Type Directory | Out-Null
                } Catch {
                    Write-Host "Failed to create path $instance - $($_.Exception.Message)" -ForegroundColor White -BackgroundColor Red
                    continue
                }
	        }
        }

 	    try {
            Copy-Item "$($filePath)" Microsoft.PowerShell.Core\FileSystem::$destination -Recurse -Force
            Write-Host "All files deployed to $instance." -ForegroundColor Green -BackgroundColor Black
        } Catch {
                Write-Host "Failed to copy file(s) to $($instance): $($_.Exception.Message)" -ForegroundColor White -BackgroundColor Red
                continue
        }

        if( $postCopy ) {
            $scriptBlock_PostInstall = [Scriptblock]::Create($postCopy)

            try {
                If ( Test-Connection -Count 1 -ComputerName $instance ) {
                    Invoke-Command -ComputerName $instance -ScriptBlock $scriptBlock_PostInstall -ErrorAction Stop
                    Write-Host "Post copy complete: $instance." -ForegroundColor Green -BackgroundColor Black
                } else {
                    throw "Cannot connect to remote instance: $instance"
                }
            } catch {
                Write-Host "Failed to run post copy $instance - $($_.Exception.Message)" -ForegroundColor White -BackgroundColor Red
                continue
            }  
        }      
    }

    Wait-Jobs -max_jobs $ParallelJobs
    
    Write-Host "Starting copy for instance: $($instance)..."
    Start-Job -ScriptBlock $scriptBlock_Copy -ArgumentList $files,$instance,$filePath,$destPath,$postCopy,$preCopy,$type | Out-Null
    $Progress = $Progress + $PerCycle
                
    # Recive the status of all current jobs
    Get-Job | Receive-Job
    # Clear out any completed jobs
    Get-Job | Where-Object { $_.State -eq "Completed" } | Remove-Job
}

While ( (Get-Job).Count -ne 0 ) {
    sleep 1
    Get-Job | Receive-Job
    Get-Job | Where-Object { $_.State -eq "Completed" } | Remove-Job
}