﻿<#
.SYNOPSIS
  Script to upgrade/patch SQL Server instances

.DESCRIPTION
  This script is designed to take care of everything you need to patch
  or upgrade an instance including:
   - Checking for pending reboots and rebooting the instance
   - Pre and Post install checks

.PARAMETER InstancePattern
  This is the pattern used to query CMS for target instances. You can use standard TSQL 'LIKE'
  syntax here.
  Example: '[D,I,Q]2-' would target all instances in D2, Q2, and I2

.PARAMETER InstanceList
  This is the path to a file that contains a list of instances. Each instance should be on it's
  own line, and must be in FQDN form.

.PARAMETER CurrentVersion
  The version of SQL Server that should be targetted for upgrade/install.
  Example: 13.0.1601.5 (SQL Server 2016 RTM)

.PARAMETER TargetVersion
  The version of SQL Server that should be reported after the upgrade/install.
  Example: 13.0.2149.0 (SQL Server 2016 RTM CU1)

.PARAMETER UpgradeCommand
  The full path and parameters for the command to execute the upgrade/install
  Example: c:\temp\Unpacked\setup.exe /q /ACTION=Upgrade /INSTANCENAME=MSSQLSERVER /IACCEPTSQLSERVERLICENSETERMS /PID=TBR8B-BXC4Y-298NV-PYTBY-G3BCP /UpdateEnabled=False
  Example: c:\temp\SQLServer2016-KB3164674-x64.exe /quiet /ACTION=Patch /INSTANCENAME=MSSQLSERVER /IACCEPTSQLSERVERLICENSETERMS

.PARAMETER CommandRootPath
  This parameter just contains the path where the executable lives. This parameter is used solely as a means
  of making sure the path exists without having to parse the upgrade command parameter

.PARAMETER CmsHost
  The CMS host to get target instances from.
  Default: cms.doamin.com

.PARAMETER PreCheckOnly
  Flag to tell the installer to only run prechecks, which include a reboot

.PARAMETER InstallOnly
  Flag to tell the installer to only skip prechecks and start the install/upgrade

.PARAMETER PrintOnly
  Flag to tell the installer to simply report what it would have done. This will generate
  the standard logging directories and files.
  Default: $true

  To disable this option, you must run this script with: -PrintOnly:$false

.EXAMPLE
  # Patch all servers from one CU1 to another
 .\SQLUpdater.ps1 -InstanceList 'c:\temp\servers.txt' -CurrentVersion '13.0.4435.0' -TargetVersion '13.0.4446.0' -CommandRootPath 'c:\temp\' -PrintOnly:$False -UpgradeCommand 'c:\temp\SQLServer2016-KB4024305-x64.exe /quiet /ACTION=Patch /INSTANCENAME=MSSQLSERVER /IACCEPTSQLSERVERLICENSETERMS'

 .EXAMPLE
  # Upgrade servers to from 2016 to 2017 
  .\SQLUpdater.ps1 -InstanceList 'c:\temp\servers2.txt' -CurrentVersion '13.0.4435.0' -TargetVersion '14.0.1000.169' -CommandRootPath 'c:\temp\RTM\' -PrintOnly: $False -UpgradeCommand 'c:\temp\RTM\setup.exe /quiet /UpdateEnabled=False /ACTION=Upgrade /INSTANCENAME=MSSQLSERVER /IACCEPTSQLSERVERLICENSETERMS /SkipRules=Cluster_IsWMIServiceOperational /PID="<yourlicensekey>"'

.NOTES
  Version:        1.0
  Author:         Mark Wilkinson @m82labs
  Creation Date:  2016.07.22
  Purpose/Change: Initial script development

  Date: 2016.11.08
  Change: Added method to have pre-deploy scripts that generate post-deploy scripts.
#>
param(
    [Parameter(
        Mandatory=$false,
        HelpMessage='Pattern to use when querying CMS for instances to target for the install.'
    )]
    [string]$InstancePattern,
    [Parameter(
        Mandatory=$false,
        HelpMessage='List to use as instance list.'
    )]
    [string]$InstanceList,
    [Parameter(
        Mandatory=$true,
        HelpMessage='SQL Server version you are installing, eg 13.0.1601.5'
    )]
    [string]$TargetVersion,
    [Parameter(
        Mandatory=$true,
        HelpMessage='Full upgrade command. This will be passed to a remote command shell (cmd.exe) so it must match what you would type there, including the full path.'    
    )]
    [string]$UpgradeCommand,
    [Parameter(
        Mandatory=$true,
        HelpMessage='The root path of the command above. It is needed in both places to validate that the path actually exists before running the command.'
    )]
    [string]$CommandRootPath,
    [Parameter(
        Mandatory=$false,
        HelpMessage='CMS host to query for our target instances.'
    )]
    [string]$CmsHost = 'RDU-YODADB-01.auctionrover.com',
    [Parameter(
        Mandatory=$false,
        HelpMessage='Does pre-checks Only'
    )]
    [switch]$PreCheckOnly = $false,
    [Parameter(
        Mandatory=$false,
        HelpMessage='Skips pre-checks'
    )]
    [switch]$InstallOnly = $false,
    [Parameter(
        Mandatory=$false,
        HelpMessage='Prints what WOULD occur but does no work.'
    )]
    [switch]$PrintOnly = $true,
    [Parameter(
        Mandatory=$false,
        HelpMessage='The version that should be on the targetted instances. This is used to filter the list of targets.'
    )]
    [string]$CurrentVersion
)

## Clean up jobs
# This scripts uses jobs heavily. If we clean up the jobs here, we
# can avoid confusion if stale jobs are hanging out.
Get-Job | Receive-Job | Out-Null
Get-Job | Remove-Job

## Declare some variables
# This is a list of the sections we want to print from the summary
$sections = @('Detailed results:','Overall summary:')
$working_directory = "c:\temp\SQL_Upgrade\v$($TargetVersion)"
$scripts_directory = Join-Path -Path $working_directory -ChildPath 'scripts'
$max_deploy = 20

# Create the scripts directory in our working directory
New-Item -Path $scripts_directory -Type Directory -Force | Out-Null

If ( $PrintOnly ) {
    Write-Host @'
    YOU ARE CURRENTLY RUNNING IN 'PRINTONLY' MODE. NO UPGRADES WILL ACTUALLY BE DONE.

    If this is not intended, rerun the script and pass in the '-PrintOnly:$false' argument:
    .\SQLUpdater -PrintOnly:$false
'@ -ForegroundColor Red -BackgroundColor Black
}

Write-Host @"

    BEFORE CONTINUING:
    - This script assumes all install files are already located on the instance being upgraded

    IN CASE OF ERROR:
    - Per instance sub-directories containing recovery files are being stored in: $($working_directory)  
    - In here you will find scripts to re-attach databases, and restore databases, as well as the  
        Summary.txt file generated by the upgrade/install process  

"@ -BackgroundColor Black -ForegroundColor Yellow

########################################################################

# Get our list of instances
If ( -not $InstancePattern -and -not $InstanceList -and -not $CurrentVersion ) {
    Write-Host "No instance pattern, list, or version filter specified. Defaulting to ALL instances." -ForegroundColor Yellow -BackgroundColor Black
    Write-Host 'To filter the target instances, specify one of the following parameters: $InstancePattern, $InstanceList, $CurrentVersion' -ForegroundColor Yellow -BackgroundColor Black
    Pause
}

Write-Host "Getting the list of target instances..." -NoNewline
Try {
    If ( $InstancePattern ) {
        $Instances = Get-CmsHosts -searchPattern $InstancePattern -cmsHost $CmsHost -version $CurrentVersion
    } Else {
        $Instances = Get-CmsHosts -cmsHost $CmsHost -version $CurrentVersion -instanceList $InstanceList
    }
    Write-Host "done." -ForegroundColor Green -BackgroundColor Black
} Catch {
    Write-Host "`nUnable to get target instances"
    Write-Host $_.Exception.Message -ForegroundColor White -BackgroundColor Red
    Exit(1)
}

Write-Host "Deploying to the following $($instances.Count) instance(s): "
ForEach ( $instance IN $instances ) {
    Write-host "`t- $instance"
}
Pause
Clear-Variable instance

If ( -not $InstallOnly ) {
    Write-Host "Entering pre-install check loop..."
    ForEach ( $instance IN $Instances ) {
        If ( (Invoke-Sqlcmd -Query "SELECT SERVERPROPERTY('productversion') AS v" -ServerInstance $instance).v -eq $TargetVersion) {
            Write-Host "$($instance): Already at target version! Skipping!" -BackgroundColor Green -ForegroundColor Black
            $Instances = $Instances | Where-Object { $_ -notmatch $instance }
            Continue
        }

        Wait-Jobs -max_jobs $max_deploy

        Start-Job -ScriptBlock {
            param( 
                [string]$instance,
                [string]$working_directory,
                [string]$scripts_directory,
                [string]$TargetVersion,
                [bool]$PrintOnly
            )

            $short_instance = $instance.Split('.')[0]
            Write-Host "$($short_instance): Getting instance start time..." -NoNewline
            Try {
                $instance_start = (Invoke-Sqlcmd -ServerInstance $instance -Query 'SELECT sqlserver_start_time AS start_time FROM sys.dm_os_sys_info;').start_time
                Write-Host $($instance_start) -ForegroundColor Green -BackgroundColor Black
            } Catch {
                Write-Host "`nCannot get start time."
                Write-Host $_.Exception.Message
                Exit(1)
            }

            $instance_working_directory = Join-Path -Path $working_directory -ChildPath $short_instance
            # Creating a local working directory
            Write-Host "Creating local working directory for this instance: $($instance_working_directory)..."
            if (!(Test-Path $instance_working_directory)) {
                Try {
                    New-Item -Path $instance_working_directory -Type Directory -Force | Out-Null
                    Write-Host "done" -ForegroundColor Green -BackgroundColor Black
                } Catch {
                    Write-Host "$($short_instance): Failed to create path - $($_.Exception.Message)" -ForegroundColor White -BackgroundColor Red
                    Exit(1)
                }
            }
            "[$(Get-Date -Format "yyyy-MM-dd HH:mm:ss")] $($short_instance): ================= Starting Upgrade/Install =================" | Out-File -FilePath "$(Join-Path -Path $instance_working_directory -ChildPath 'SQLUpdater_Log.txt')" -Append
    
            If ( -not $PrintOnly ) {
                Write-Host "$($short_instance): Rebooting host..." -ForegroundColor Red -BackgroundColor Black -NoNewline
                "[$(Get-Date -Format "yyyy-MM-dd HH:mm:ss")] $($short_instance): Rebooting host..." | Out-File -FilePath "$(Join-Path -Path $instance_working_directory -ChildPath 'SQLUpdater_Log.txt')" -Append
                Restart-Computer -ComputerName $instance -Force
                Sleep(5)
                $connect = 0
                While ( $connect -eq 0 ) {
                    Try {
                        If ( $instance_start -lt (Invoke-Sqlcmd -ServerInstance $instance -Query 'SELECT sqlserver_start_time AS start_time FROM sys.dm_os_sys_info;' -ErrorAction SilentlyContinue).start_time ) {
                            $connect = 1
                        }
                    } Catch {
                        $connect = 0
                    }
                }
                Write-Host "Reboot Complete" -ForegroundColor Green -BackgroundColor Black
            } Else {
                Write-Host "$($short_instance): Reboot would occur here."
            }

            # Generate Re-attach and Restore scripts just in case
            Write-Host "$($short_instance): Running pre-deploy scripts..."
            "[$(Get-Date -Format "yyyy-MM-dd HH:mm:ss")] $($short_instance): Running pre-deploy scripts..." | Out-File -FilePath "$(Join-Path -Path $instance_working_directory -ChildPath 'SQLUpdater_Log.txt')" -Append
            ForEach ( $script in $(Get-ChildItem -Path $scripts_directory -Filter "Pre*" | Sort-Object @{Expression={$_.Name.Replace("PrePost","Pre")}}) ) {
                If ( $script.Name -match '^.*.sql$' ) {
                    If ( -not $PrintOnly ) {
                        (Invoke-Sqlcmd -ServerInstance $instance -Database 'master' -InputFile $script.FullName -MaxCharLength 999999 -QueryTimeout 900).Column1 | Out-File -FilePath "$(Join-Path -Path $instance_working_directory -ChildPath $script.Name)"
                    } Else {
                        Write-Host "Execute $($script.Name)"
                    }
                } Elseif ( $script.Name -match '^.*.ps1$' ) {
                    If ( -not $PrintOnly ) {
                        Try {
                            Invoke-Command -ComputerName $instance -FilePath $script.FullName 
                        } Catch {
                            Write-Host "Failed to execute $($script.Name): "
                            Write-Host $_.Exception.Message -BackgroundColor Red
                        }
                    } Else {
                        Write-Host "Execute $($script.Name)"
                    }
                }
            }
            Write-Host "$($short_instance): Pre install checks complete." -ForegroundColor Black -BackgroundColor Green
            "[$(Get-Date -Format "yyyy-MM-dd HH:mm:ss")] $($short_instance): Pre install checks complete." | Out-File -FilePath "$(Join-Path -Path $instance_working_directory -ChildPath 'SQLUpdater_Log.txt')" -Append
        } -ArgumentList $instance, $working_directory, $scripts_directory, $TargetVersion, $PrintOnly | Out-Null
        Wait-Jobs -max_jobs $max_deploy -message "Waiting for some jobs to finish..."
    }
}

Wait-Jobs -max_jobs 1 -message "Waiting for all jobs to finish..."

Write-Host "`n"
Write-Host "Pre-install checks complete."

If ( -not $Instances ) {
    Write-Host "DONE: All instances currently at the target version." -BackgroundColor Green -ForegroundColor Black
    Exit
}

Write-Host "!!! PRESSING ENTER WILL BEGIN THE UPGRADE/INSTALL PROCESS !!!" -BackgroundColor Red -ForegroundColor White
Pause

If ( -not $PreCheckOnly ) {
    ForEach ( $instance IN $instances ) {
        $short_instance = $instance.Split('.')[0]
        $instance_working_directory = Join-Path -Path $working_directory -ChildPath $short_instance

        Write-Host "Creating local working directory for this instance: $($instance_working_directory)..."
        if (!(Test-Path $instance_working_directory)) {
            Try {
                New-Item -Path $instance_working_directory -Type Directory -Force | Out-Null
                Write-Host "done" -ForegroundColor Green -BackgroundColor Black
            } Catch {
                Write-Host "$($short_instance): Failed to create path - $($_.Exception.Message)" -ForegroundColor White -BackgroundColor Red
                Exit(1)
            }
        }

        If ( $InstallOnly ) {
            "[$(Get-Date -Format "yyyy-MM-dd HH:mm:ss")] $($short_instance): ================= Starting Upgrade/Install =================" | Out-File -FilePath "$(Join-Path -Path $instance_working_directory -ChildPath 'SQLUpdater_Log.txt')" -Append
        }
        If ( (Invoke-Sqlcmd -Query "SELECT SERVERPROPERTY('productversion') AS v" -ServerInstance $instance).v -eq $TargetVersion) {
            Continue
        } else {
            Write-Host "$($short_instance): Starting..."
            $s = New-PSSession -ComputerName $instance
        
            Write-Host "Starting Upgrade for $($short_instance)"
            "[$(Get-Date -Format "yyyy-MM-dd HH:mm:ss")] $($short_instance): Starting Upgrade" | Out-File -FilePath "$(Join-Path -Path $instance_working_directory -ChildPath 'SQLUpdater_Log.txt')" -Append

            <#
                This command will fire off the upgrade in a job and report back if it fails.
                If it fails, or needs a reboot to continue, you will get more verbose output.
                Otherwise, it will simply tell you the upgrade is successful.
            #>
            If ( -not $PrintOnly ) {
                Wait-Jobs -max_jobs $max_deploy
                
                Invoke-Command -Session $s -ScriptBlock {
                    param( $instance,$short_instance,$TargetVersion,$UpgradeCommand,$CommandRootPath )
                
                    If ( ! (Test-Path -Path "$($CommandRootPath)") ) {
                        Write-Host "Install/Upgrade root path not found: $($CommandRootPath). Skipping this instance." -BackgroundColor Red -ForegroundColor White
                        Exit(1)
                    }

                    Invoke-Command -ScriptBlock { & cmd.exe /c $UpgradeCommand }
                    If ( (Invoke-Sqlcmd -Query "SELECT SERVERPROPERTY('productversion') AS v" -ServerInstance $instance).v -eq $TargetVersion) {
                        Write-Host "$($short_instance.ToUpper()): UGRADE SUCCESSFUL!" -BackgroundColor Green -ForegroundColor Black
                    } else {
                        Write-Host "$($short_instance.ToUpper()): UPGRADE DID NOT COMPLETE" -BackgroundColor Magenta
                        # Set the summary file path
                        $InstallSummary = "C:\Program Files\Microsoft SQL Server\$($TargetVersion.Split('.')[0])0\Setup Bootstrap\Log\Summary.txt"
                        $SummaryData = Get-Content -Path $InstallSummary
                        $FinalResult = ($SummaryData | Where-Object { $_ -match 'Final result:' })

                        If ( $FinalResult -match 'Reboot' ) {
                            Write-Host " - REBOOT MAY BE REQUIRED - `n - CHECK LOGS ON THE INSTANCE: $($InstallSummary) -" -BackgroundColor Yellow -ForegroundColor Black
                        } ElseIf ( $FinalResult -match 'Failed:' ) {
                            Write-Host " - FAILED -" -BackgroundColor Red
                        }
                        $WriteLines = $false
                        ForEach ( $line in $SummaryData ) {
                            If ( $line -match 'Exit message:' ) {
                                Write-Host $line
                            }

                            If ( $Sections | Where-Object { $line -match $_ } ) {
                                $WriteLines = $true
                                Write-Host $line
                            } elseif ( $line -notmatch '^\W.*' -and $line -notmatch '^$' -and $WriteLines ) {
                                $WriteLines = $false
                            } elseif ( $line -match '^\W.*' -and $WriteLines ) {
                                Write-Host $line
                            }
                        }
                    }
                } -ArgumentList $instance,$short_instance,$TargetVersion,$UpgradeCommand,$CommandRootPath -AsJob | Out-Null
            } Else {
                Write-Host "A job would be fired off here. For debug purposes we will fire off an 'ipconfig'"
                Invoke-Command -Session $s -ScriptBlock {
                    & cmd.exe /c ipconfig
                } -AsJob | Out-Null
            }
        }
    }

    While ( Get-Job -HasMoreData $true ) {
        Write-Spinner
        # Set up the array to hold the job results
        $JobResult = New-Object -TypeName System.Collections.ArrayList
        $JobResult = (Get-Job -State Completed -HasMoreData $true | Receive-Job)
        If ( -not $JobResult ) {
            continue
        }

        # Attempt to grab the install summary
        ForEach ( $i in $JobResult.GetEnumerator()) {
            $instance_working_directory = Join-Path -Path $working_directory -ChildPath $i.PSComputerName.Split('.')[0]
            "[$(Get-Date -Format "yyyy-MM-dd HH:mm:ss")] $($i.PSComputerName.Split('.')[0]): $($i)" | Out-File -FilePath "$(Join-Path -Path $instance_working_directory -ChildPath 'SQLUpdater_Log.txt')" -Append
        }

        ForEach ( $i in $($JobResult.GetEnumerator() | Select-Object PSComputerName -Unique).PSComputerName) {
            $short_instance = $i.Split('.')[0]
            $instance_working_directory = Join-Path -Path $working_directory -ChildPath $short_instance
            $destination = Join-Path -Path $instance_working_directory -ChildPath "\Summary_$(Get-Date -Format "yyyyMMdd_hhmmss").txt"
            If ( Test-Path -Path "\\$($i)\c$\Program Files\Microsoft SQL Server\$($TargetVersion.Split('.')[0])0\Setup Bootstrap\Log\Summary.txt" ) {
                Copy-Item -Path "\\$($i)\c$\Program Files\Microsoft SQL Server\$($TargetVersion.Split('.')[0])0\Setup Bootstrap\Log\Summary.txt" -Destination $destination
            }

            If ( (Invoke-Sqlcmd -Query "SELECT SERVERPROPERTY('productversion') AS v" -ServerInstance $i).v -eq $TargetVersion) {
                Write-Host "Install successful, running post-install scripts..."
                "[$(Get-Date -Format "yyyy-MM-dd HH:mm:ss")] $($short_instance): Starting post-install..." | Out-File -FilePath "$(Join-Path -Path $instance_working_directory -ChildPath 'SQLUpdater_Log.txt')" -Append
                ForEach ( $script in $(Get-ChildItem -Path $instance_working_directory -Filter "PrePost*") ) {
                    If ( $script.Name -match '^.*.sql$' ) {
                        If ( -not $PrintOnly ) {
                            (Invoke-Sqlcmd -ServerInstance $instance -Database 'master' -InputFile $script.FullName -MaxCharLength 999999 -QueryTimeout 900).Column1 | Out-File -FilePath "$(Join-Path -Path $instance_working_directory -ChildPath "PostExec$($script.Name)")"
                        } Else {
                            Write-Host "Execute $($script.Name)"
                        }
                    } Elseif ( $script.Name -match '^.*.ps1$' ) {
                        If ( -not $PrintOnly ) {
                            Try {
                                Invoke-Command -ComputerName $instance -FilePath $script.FullName 
                            } Catch {
                                Write-Host "Failed to execute $($script.Name): "
                                Write-Host $_.Exception.Message -BackgroundColor Red
                            }
                        } Else {
                            Write-Host "Execute $($script.Name)"
                        }
                    }
                }
                
                ForEach ( $script in $(Get-ChildItem -Path $scripts_directory -Filter "Post-*") ) {
                    "[$(Get-Date -Format "yyyy-MM-dd HH:mm:ss")] $($short_instance): Running - $($script.Name)" | Out-File -FilePath "$(Join-Path -Path $instance_working_directory -ChildPath 'SQLUpdater_Log.txt')" -Append
                    If ( $script.Name -match '^.*.sql$' ) {
                        If ( -not $PrintOnly ) {
                            $result = Invoke-Sqlcmd -ServerInstance $i -Database 'master' -InputFile $script.FullName
                        } Else {
                            Write-Host "Execute $($script.Name)"
                        }
                    } Elseif ( $script.Name -match '^.*.ps1$' ) {
                        If ( -not $PrintOnly ) {
                            Try {
                                Invoke-Command -ComputerName $i -FilePath $script.FullName 
                            } Catch {
                                Write-Host "Failed to execute $($script.Name): "
                                Write-Host $_.Exception.Message -BackgroundColor Red
                            }
                        } Else {
                            Write-Host "Execute $($script.Name)"
                        }
                    }
                }

                If ( (Get-Content $destination | Where-Object { $_ -match 'Passed but reboot required, see logs for details' }) -and -not $PrintOnly ) {
                    Write-Host "$($short_instance) needs to be rebooted to complete the install. Rebooting now."
                    Restart-Computer -ComputerName $i -Force
                }
            } Else {
                "[$(Get-Date -Format "yyyy-MM-dd HH:mm:ss")] $($short_instance): Skipping post-install scripts" | Out-File -FilePath "$(Join-Path -Path $instance_working_directory -ChildPath 'SQLUpdater_Log.txt')" -Append
            }
            "[$(Get-Date -Format "yyyy-MM-dd HH:mm:ss")] $($short_instance): ================= Upgrade/Install Complete =================" | Out-File -FilePath "$(Join-Path -Path $instance_working_directory -ChildPath 'SQLUpdater_Log.txt')" -Append
        }
        Get-Job -HasMoreData $false | Remove-Job
        Start-Sleep(0.75)
    }
}