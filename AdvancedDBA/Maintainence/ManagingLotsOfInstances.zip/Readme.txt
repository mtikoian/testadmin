If there is anything I missed feel free to email, or something you
wished I covered that I didn't. I know I covered a lot of material fast
so don't hestiate to ask questions.  tracy@tracyboggiano.com