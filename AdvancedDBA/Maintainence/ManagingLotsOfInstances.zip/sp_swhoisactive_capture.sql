EXEC dbo.sp_WhoIsActive @get_plans = 1, @get_full_inner_text = 1, @format_output = 0, @get_task_info = 2, 
	@destination_table = 'dbo.WhoIsActiveOutput';
