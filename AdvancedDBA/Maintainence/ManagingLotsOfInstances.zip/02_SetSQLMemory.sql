DECLARE @TotalServerMemoryGB INT
DECLARE @NewMemoryValueGB NVARCHAR(10)
DECLARE @TempMemory INT
DECLARE @SQLCmd NVARCHAR(1000)
DECLARE @NewServerMemoryMB INT
DECLARE @debug BIT

SET @debug = 0

SELECT @TotalServerMemoryGB = ROUND(((total_physical_memory_kb/1024))/1024,0) --have to do the +1 to avoid things like 31.99GB
FROM [master].[sys].[dm_os_sys_memory]


SET @NewServerMemoryMB = (@TotalserverMemoryGB * 1024)  - IIF((@TotalServerMemoryGB>32),(@TotalServerMemoryGB *1024 * .1),4096)

--catch all for negative numbers
IF(@NewServerMemoryMB <= 1024)
BEGIN
    SET @NewServerMemoryMB = 2048
END

SET @SQLCmd = N'EXEC sp_configure ''show advanced option'', ''1''; RECONFIGURE;'

IF(@debug = 1)
BEGIN
    SELECT @SQLCmd
END
ELSE
BEGIN
    EXEC sp_executesql @SQLCmd
END

SET @SQLCmd = N'EXEC sys.sp_configure N''max server memory (MB)'', N''' + CONVERT(NVARCHAR(20),@NewServerMemoryMB) + ''' RECONFIGURE'

IF(@debug = 1)
BEGIN
    SELECT @SQLCmd
END
ELSE
BEGIN
    EXEC sp_executesql @SQLCmd
END