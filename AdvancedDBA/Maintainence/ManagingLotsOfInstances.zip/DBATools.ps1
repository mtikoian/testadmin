﻿#Set-DbaMaxMemory -SqlServer . -whatif
#Test-DbaMaxMemory -SqlServer .
#Set-SqlTempDbConfiguration -SqlInstance . -DataFileCount 2 -DataFileSizeMB 2048 -LogFileSizeMB 5120 -DisableGrowth -WhatIf
#Set-DbaPowerPlan -ComputerName . -whatif
#Get-Help Get-SqlRegisteredServerName -Detailed
#Sync-SqlLoginPermissions -Source ag1 -Destination ag2
Invoke-DbaWhoisActive -SqlInstance ag1,ag2 | Out-GridView