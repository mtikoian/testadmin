EXEC dbo.sp_Blitz
@OutputDatabaseName = 'dba_local',
@OutputSchemaName = 'dbo',
@OutputTableName = 'BlitzResults'