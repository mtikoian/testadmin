-- Database Level Configuration
USE [master]
GO
ALTER DATABASE msdb SET AUTO_UPDATE_STATISTICS_ASYNC ON WITH NO_WAIT
GO
ALTER DATABASE model SET AUTO_UPDATE_STATISTICS_ASYNC ON WITH NO_WAIT
GO
ALTER DATABASE model SET AUTO_CREATE_STATISTICS ON (INCREMENTAL=ON)
GO
ALTER DATABASE model SET READ_COMMITTED_SNAPSHOT ON
GO

-- Server Level Configurations
EXEC sp_configure 'show advanced options', 1;
RECONFIGURE;
GO

-- Ad Hoc Distributed Queries 1
EXEC sp_configure 'Ad Hoc Distributed Queries', 1;
RECONFIGURE;
GO

-- xp_cmdshell 1
EXEC sp_configure 'xp_cmdshell', 1;
GO

-- CLR ENABLED
EXEC sp_configure 'clr enabled' , '1';
RECONFIGURE;
GO

--Remote Query Timeout 1200
EXEC sys.sp_configure N'remote query timeout (s)', N'1200'
GO
RECONFIGURE  -- is this needed
GO

--Backup Compression Default 1
EXEC sp_configure 'backup compression default', 1;
RECONFIGURE;
GO

-- Remote Admin Connections 1
sp_configure 'remote admin connections', 1;
GO
RECONFIGURE;
GO

-- Scan for Startup Procs 1
EXEC sp_configure 'scan for startup procs', 1;
GO
RECONFIGURE
GO

-- OLE Automation 
sp_configure 'Ole Automation Procedures', 1;
GO
RECONFIGURE;
GO

-- Remote Login Timeout 20
EXEC sp_configure 'remote login timeout', 20 ;
GO
RECONFIGURE ;
GO

-- CTfP 50
EXEC sp_configure 'cost threshold for parallelism', 100;
GO
RECONFIGURE
GO

-- Backup Checksum Default 1
EXEC sys.sp_configure N'backup checksum default', 1
GO

--Optimize for Ad Hoc Distributed Workload
EXEC sys.sp_configure N'optimize for ad hoc workloads', N'1'
RECONFIGURE 
GO

EXEC sys.sp_configure N'cross db ownership chaining', N'1'
GO
RECONFIGURE
GO

EXEC sys.sp_configure 'Agent XPs', 1;  
GO
RECONFIGURE
GO

-- Enable sa Login
ALTER LOGIN [sa] ENABLE 
GO