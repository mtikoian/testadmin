.\CopyFiles.ps1 -servers 'D1-PLDB-' -filePath '\\server\SQL2017\Win8.1AndW2K12R2-KB3191564-x64.msu' -destPath 'c$\temp' -ParallelJobs 20 

#Install Windows Management Framework 5.1

$servers= Get-CmsHosts -SearchPattern 'AG'
$hotfix = 'c:\temp\Win8.1AndW2K12R2-KB3191564-x64.msu'
$user = 'domain\tracy.boggiano'
$pass = 'password'
$psexec = 'c:\pstools\PsExec.exe'
foreach ($server in $servers)
{
    & $psexec /accepteula \\$server -u $user -p $pass -d wusa /install $hotfix /quiet /forcerestart
}

Get-CmsHosts -InstanceList 'AG' | % { New-PSSession -ComputerName $_ | out-null}
$sessions = Get-PSSession
$scriptblock = {
Install-Module -Name sqlserver -Force -Scope CurrentUser -Confirm
}
Invoke-Command -Session $($sessions | ? { $_.State -eq 'Opened' }) -ScriptBlock $scriptblock
$sessions | Remove-PSSession

.\SQLUpdater.ps1 -InstancePattern 'AG' -CurrentVersion '13.0.4422.0'  -TargetVersion '14.0.500.272' 
    -CommandRootPath 'c:\temp\CTP20\' -Project '201704-SQLUpgrades' -PrintOnly:$False 
    -UpgradeCommand 'c:\temp\CTP20\setup.exe /quiet /UpdateEnabled=False /ACTION=Upgrade 
    /INSTANCENAME=MSSQLSERVER /IACCEPTSQLSERVERLICENSETERMS /PID="licensekey"'
