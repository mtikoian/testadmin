-- This script runs through all user databases
-- and turns on query store with sane defaults

USE master
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
DECLARE @SQL VARCHAR(MAX) = '';

SELECT @SQL += REPLACE(
    '
    ALTER DATABASE {{DBName}} SET QUERY_STORE = ON;
    ALTER DATABASE {{DBName}} SET QUERY_STORE
    (
        OPERATION_MODE = READ_WRITE,
        CLEANUP_POLICY = (STALE_QUERY_THRESHOLD_DAYS = 90),
        DATA_FLUSH_INTERVAL_SECONDS = 3600,
        INTERVAL_LENGTH_MINUTES = 15,
        MAX_STORAGE_SIZE_MB = 2048,
        QUERY_CAPTURE_MODE = AUTO,
        SIZE_BASED_CLEANUP_MODE = AUTO,
        MAX_PLANS_PER_QUERY = 100
    );
    '
    , '{{DBName}}', name)
FROM DBA.DBMaint.vAccessibleChangeableDBs
WHERE
database_id > 2;

EXEC(@SQL);
