*****************************************************************************

DBA Repository Update Instructions.

_____________________________________________________________________
DISCLAIMER: If you have this solution already deployed, I highly recommend
taking a backup of the DBA_Rep database and deploying this update in a
test environment.
_____________________________________________________________________

*  If this is your first installation of theDBA Repository
download the code from Feb 2008 (InstantDoc 97840)
and follow the installation instructions in the Code_Install_Instructions.txt
file.
	* You will also need to populate the ServerList_SSIS table. That process
	Is also described in InstantDoc 95385.

* If you have already downloaded and have been running the solution from 
February 2008, execute the script contained in this download called
DBA_Repository_Update_2010.sql against your DBA_Rep database.

* Open the updated Populate_DBA_Rep.dtsx package in Business Intelligence
Development Studio (BIDS) and make sure that all validation is successful.
Execute and validate that the package is working as you intend.
Once you are comfortable with the processing, deploy to production.


Enjoy!
Rodney Landrum, SQL MVP



