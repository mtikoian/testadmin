Declare @BackupPath varchar(512) = Null					--Stores the Base Path for the All Backups Files
Declare @AlternateBackupPath varchar(512) = NULL		--Stores an Alternate Base Path for the ALL Backups Files
Declare @Str nvarchar(1000)								--Stores the command to execute

--Set up the two distinct backup paths
Set @BackupPath = 'X:\SQLDatabases\Hydra\'
Set @AlternateBackupPath = 'C:\SQLBackups\BSC_Hydra_Admin\'


Begin Try
	--Purposely Bad Backup Path
	Set @Str = 'BACKUP DATABASE [BSC_Hydra_Admin] 
		TO DISK = N' + Char(39) + @BackupPath + 'BSC_Hydra_Admin_Backup.bak' + Char(39) + ' 
		WITH NOFORMAT, NOINIT,  SKIP, NOREWIND, NOUNLOAD,  STATS = 10'
	
	--Execute Backup Statement
	Exec sp_executesql @str
End Try

Begin Catch
	Print 'Primary Backup Path ' + @BackupPath + ' Failed!
	
	
	'

	--Purposely Good (Alternate) Backup Path
	Set @Str = 'BACKUP DATABASE [BSC_Hydra_Admin] 
		TO DISK = N' + Char(39) + @AlternateBackupPath + 'BSC_Hydra_Admin_Backup.bak' + Char(39) + ' 
		WITH NOFORMAT, NOINIT,  SKIP, NOREWIND, NOUNLOAD,  STATS = 10'
	
	--Execute Backup Statement
	Exec sp_executesql @str

	Print 'Backup Completed!!!!!'
End Catch

