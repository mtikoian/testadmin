/*-------------------------------------------------

	Alter Filtering Infrastructure

--------------------------------------------------*/
USE [msdb]
GO

/****** Object:  Operator [BSC Email]    Script Date: 8/8/2014 11:13:38 PM ******/
EXEC msdb.dbo.sp_add_operator @name=N'Email', 
		@enabled=1, 
		@weekday_pager_start_time=90000, 
		@weekday_pager_end_time=180000, 
		@saturday_pager_start_time=90000, 
		@saturday_pager_end_time=180000, 
		@sunday_pager_start_time=90000, 
		@sunday_pager_end_time=180000, 
		@pager_days=0, 
		@email_address=N'warren.sifre@broadstrokeconsulting.com', 
		@category_name=N'[Uncategorized]'
GO

EXEC msdb.dbo.sp_set_sqlagent_properties @alert_replace_runtime_tokens=1
GO

Use SQLSat_IndyDBA
Go

CREATE TABLE  [dbo].[ALRT_Filters](
	AF_ID int identity(1,1),
	AF_Error int Not Null,
	AF_Severity int Not Null,
	AF_MSG_Contains varchar(4000) Null,
	AF_Enabled bit default 1,
	AF_DateCreated datetime default getdate(),
	AF_CreatedBy varchar(256) not null,
	AF_Description varchar(4000) not null,
	AF_ExpirationDate datetime Default '12/31/2029'
) ON [Primary]


--Adds filter to eliminate 3 emails being sent for every one Instance Configuration Change.
INSERT  [dbo].[ALRT_Filters]  (AF_Error, AF_Severity, AF_MSG_Contains, AF_Enabled, AF_DateCreated, AF_CreatedBy, AF_Description)
	SELECT 15457, 10, '@message like ''%show advanced options%''', 1, '02-04-2013', 'BSC', 'This will elminate the Show Advance Options notifications'

--Adds filter to eliminate emails being sent for for specific failed user login.
INSERT  [dbo].[ALRT_Filters]  (AF_Error, AF_Severity, AF_MSG_Contains, AF_Enabled, AF_DateCreated, AF_CreatedBy, AF_Description)
	SELECT 18456, 14, '@message like ''%LoginID%'' and @message like ''%IPAddress%''', 0, '02-25-2013', 'BSC', 'This is a sample for how to create a filter to ignore certain Login and IP address source combinations'

--Adds filter to eliminate emails being sent when xp_cmdshell is enabled for Performance Monitor Check restart process.
INSERT  [dbo].[ALRT_Filters]  (AF_Error, AF_Severity, AF_MSG_Contains, AF_Enabled, AF_DateCreated, AF_CreatedBy, AF_Description)
	SELECT 15457, 10, '@message like ''%xp_cmdshell%''', 1, '11-16-2013', 'BSC', 'This is used by Performance Monitor Check process to enable the Collector Set when disabled.'


USE [msdb]
GO

/****** Object:  Job [BSC_Capture Alerts]    Script Date: 8/8/2014 11:11:56 PM ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Monitoring]    Script Date: 8/8/2014 11:11:56 PM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Monitoring' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Monitoring'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Capture Alerts', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'Captures all Alerts triggered on the server to allow for alert notification filtering.', 
		@category_name=N'Database Monitoring', 
		@owner_login_name=N'sa', 
		@notify_email_operator_name=N'Email', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Capture Alert]    Script Date: 8/8/2014 11:11:56 PM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Capture Alert', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'Exec [SQLSat_IndyDBA].[dbo].[Alertlog] ''$(ESCAPE_SQUOTE(A-DBN))'', ''$(ESCAPE_SQUOTE(A-SVR))'', ''$(ESCAPE_SQUOTE(STRTDT))'', ''$(ESCAPE_SQUOTE(STRTTM))'', ''$(ESCAPE_SQUOTE(A-SEV))'', ''$(ESCAPE_SQUOTE(A-ERR))'', ''$(ESCAPE_SQUOTE(A-MSG))''', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

