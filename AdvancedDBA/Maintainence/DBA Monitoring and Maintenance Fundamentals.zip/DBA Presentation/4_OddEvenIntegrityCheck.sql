Select name, database_id, state from Sys.databases;



		-- SET NOCOUNT ON added to prevent extra result sets from
		-- interfering with SELECT statements.
		SET NOCOUNT ON;

		Declare @DBName nvarchar(300)
		Declare @Str nvarchar(300)

		--Create Temp Table for result storage
		Create Table [dbo].[_DBCCResults]
			([Error] integer
			,[Level] integer
			,[State] integer
			,[MessageText] varchar(1000)
			,[RepairLevel] varchar(1000)
			,[Status] integer
			,[DBID] integer
			,[DBFragID] integer
			,[ObjectID] integer
			,[IndexID] integer
			,[PartitionID] BigInt
			,[AllocUnitID] BigInt
			,[RidDbID] integer
			,[RidPruID] integer
			,[File] integer
			,[Page] integer
			,[Slot] integer
			,[RefDbId] integer
			,[RefPruID] integer
			,[RefFile] integer
			,[RefPage] integer
			,[RefSlot] integer
			,[Allocation] BigInt)

		--If week days are any of these then do even numbered Database ID.
		if (Datepart(Weekday, GetDate()) IN (2,4,6))
			Begin
				Declare DB_Cursor Cursor for
				Select name from sys.databases where name <> 'TempDB' and [state] = 0 and (DB_ID(name) % 2) = 0

				Open DB_Cursor

				Fetch Next from DB_Cursor into @DBName

				While @@FETCH_STATUS = 0
					Begin

						Set @Str = 'DBCC CheckDB(' + CHAR(39) + @DBName + CHAR(39) + ') with TableResults'

						Print @Str

						--Start execution of integrity check
						Insert Into [dbo].[_DBCCResults]
						Exec (@str)
						
						Fetch Next from DB_Cursor into @DBname
					End
			
				Close DB_Cursor
				Deallocate DB_Cursor
			End
		Else
			Begin
				Declare DB_Cursor Cursor for
				Select name from sys.databases where name <> 'TempDB' and [state] = 0 and (DB_ID(name) % 2) <> 0

				Open DB_Cursor

				Fetch Next from DB_Cursor into @DBName

				While @@FETCH_STATUS = 0
					Begin

						Set @Str = 'DBCC CheckDB(' + CHAR(39) + @DBName + CHAR(39) + ') with TableResults'

						Print @Str
								
						Insert Into [dbo].[_DBCCResults]
						Exec (@str)

						Fetch Next from DB_Cursor into @DBname
					End
			
				Close DB_Cursor
				Deallocate DB_Cursor
			End

Select * from [dbo].[_DBCCResults]

Drop Table [dbo].[_DBCCResults]