Use SQLSat_IndyDBA
Go

--Change the threshold to something less than one.
Update LRJ_Profile
Set RuntimeThreshold = 0
Where JobID = (Select job_id from msdb.dbo.sysjobs where name = 'LRJ_Test')


	DECLARE @is_sysadmin int
	DECLARE @job_owner sysname
	DECLARE @runningjobid nvarchar(100)
	DECLARE @isRunning int
	DECLARE @runtime int
	DECLARE @jobName nvarchar(200)
	DECLARE @msg nvarchar(max)
	DECLARE @sub nvarchar(100)
	DECLARE @threshold int
	DECLARE @ImportanceID int

	--Query running jobs and insert results into temp table	
	CREATE TABLE #tmprunningjobs (
	job_id                UNIQUEIDENTIFIER NOT NULL,
	last_run_date         INT              NOT NULL,
	last_run_time         INT              NOT NULL,
	next_run_date         INT              NOT NULL,
	next_run_time         INT              NOT NULL,
	next_run_schedule_id  INT              NOT NULL,
	requested_to_run      INT              NOT NULL,
	request_source        INT              NOT NULL,
	request_source_id     sysname          COLLATE database_default NULL,
	running               INT              NOT NULL,
	current_step          INT              NOT NULL,
	current_retry_attempt INT              NOT NULL,
	job_state             INT              NOT NULL)

	SELECT @is_sysadmin = isnull(is_srvrolemember(N'sysadmin'), 0)
	SELECT @job_owner = suser_sname()

	insert into #tmprunningjobs
	Exec master.dbo.xp_sqlagent_enum_jobs @is_sysadmin, @job_owner, @job_id = null

	--DECLARE a cursor to iterate through the currently running jobs
	DECLARE runningjobs_cursor cursor for
	SELECT job_id from #tmprunningjobs

	open runningjobs_cursor

	fetch next from runningjobs_cursor into @runningjobid

	while @@FETCH_STATUS = 0
		begin
			SELECT @isRunning = running from #tmprunningjobs where job_id = @runningjobid
		
			SELECT @threshold = RuntimeThreshold, @ImportanceID = ImportanceID from [dbo].[LRJ_Profile] where JobID = @runningjobid

			SELECT @runtime = 
				datediff(mi, 
				(SELECT top 1 start_execution_date from msdb.dbo.sysjobactivity where job_id = @runningjobid Order by Session_ID DESC), 
				getdate())
			
			--Check if the job is running, exceeded threshold and alerting enabled, send an email
			if @isRunning = 1 and @runtime > @threshold	and (SELECT isenabled from [dbo].[LRJ_Profile] where JobID = @runningjobid) = 1
				BEGIN
					SELECT @jobName = name FROM [msdb].[dbo].[sysjobs] where job_id = @runningjobid

					Print 'Job is running long - ' + @JobName				
				END
      		
			fetch next from runningjobs_cursor into @runningjobid
		end


	--Close cursor, drop tables
	close runningjobs_cursor
	deallocate runningjobs_cursor

	drop table #tmprunningjobs


