Select 
	name, 
	database_id, 
	state,
	(SELECT Sum( (size*8)/1024)
		FROM sys.master_files
		WHERE DB_NAME(database_id) = DB.name) as Size
from Sys.databases DB;


Declare @SizePivot int = 10


		-- SET NOCOUNT ON added to prevent extra result sets from
		-- interfering with SELECT statements.
		SET NOCOUNT ON;

		Declare @DBName nvarchar(300)
		Declare @Str nvarchar(300)
		Declare @DBSize int

		--Set @RunType = 2
		
		--Create Temp Table for result storage
		Create Table [dbo].[_DBCCResults]
			([Error] integer
			,[Level] integer
			,[State] integer
			,[MessageText] varchar(1000)
			,[RepairLevel] varchar(1000)
			,[Status] integer
			,[DBID] integer
			,[DBFragID] integer
			,[ObjectID] integer
			,[IndexID] integer
			,[PartitionID] BigInt
			,[AllocUnitID] BigInt
			,[RidDbID] integer
			,[RidPruID] integer
			,[File] integer
			,[Page] integer
			,[Slot] integer
			,[RefDbId] integer
			,[RefPruID] integer
			,[RefFile] integer
			,[RefPage] integer
			,[RefSlot] integer
			,[Allocation] BigInt)

		--Run all DBs each day
			Declare DB_Cursor Cursor for
			Select name from sys.databases 
			where name <> 'TempDB' and [state] = 0

			Open DB_Cursor

			Fetch Next from DB_Cursor into @DBName

			While @@FETCH_STATUS = 0
				Begin
					--Delete From [dbo].[_DBCCResults]

					if @SizePivot = 0 
						Begin
							Set @Str = 'DBCC CheckDB(' + CHAR(39) + @DBName + CHAR(39) + ') with TableResults'
						End
					Else
						Begin
							SELECT @DBSize = Sum( (size*8)/1024)
								FROM sys.master_files
								WHERE DB_NAME(database_id) = @DBname

							if @DBSize > @SizePivot
								Begin
									Set @Str = 'DBCC CheckDB(' + CHAR(39) + @DBName + CHAR(39) + ') with Physical_Only, TableResults'
								End
							Else
								Begin
									Set @Str = 'DBCC CheckDB(' + CHAR(39) + @DBName + CHAR(39) + ') with TableResults'
								End
						End

					Print @Str
				
					Insert Into [dbo].[_DBCCResults]
					Exec (@str)
						
					Fetch Next from DB_Cursor into @DBname
				End
			
			Close DB_Cursor
			Deallocate DB_Cursor

Select * from [dbo].[_DBCCResults]

Drop Table [dbo].[_DBCCResults]



