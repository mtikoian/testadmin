Declare @RetryCount int = 2								--Stores the Retry count
Declare @intCurrentRetry int = 0

RunMeAgain:

Begin Try
	--Purposely Bad Backup Path
	BACKUP DATABASE [BSC_Hydra_Admin] 
		TO DISK = N'X:\SQLDatabases\Hydra\BSC_Hydra_Admin_Backup.bak' 
		WITH NOFORMAT, NOINIT,  NAME = N'BSC_Hydra_Admin-Full Database Backup', SKIP, NOREWIND, NOUNLOAD,  STATS = 10
End Try

Begin Catch
	If @intCurrentRetry < @RetryCount
		Begin
			--Increment the Current Retry count by one
			Set @intCurrentRetry += 1

			Print 'I failed ' + Cast(@intCurrentRetry as char(1)) + ' time.'

			--Allow time for connectivity problem to potentially subside
			Waitfor Delay '00:00:05'

			--Goto the point above the Begin Try and run the backup again
			Goto RunMeAgain
		End
	Else
		Begin
			Print 'I finally failed'
		End

End Catch
