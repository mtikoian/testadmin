/*____________________________________

NOTE: To test out code, must create a new database 
	or restore an existing data to break the LSN chain.


______________________________________*/
If Not Exists(Select Name from sys.databases where name = 'TestMe')
	Begin
		Create Database TestMe
	end

Go


Declare @BackupType smallint = Null		--Determine whether it be a 1 - Full Backup, 2 - Transaction Log Backup, 3 - Differential
Declare @DBName varchar(100) = 'TestMe'
Declare @BackupFullPath varchar(512) = 'C:\SQLBackups\BSC_Hydra_Admin\'
Declare @Str nvarchar(max)

--Backup Type value of 2 equals T-Logs
Set @BackupType = 2

--Get list of DBNames and Dates to determine whether certain backup types can be performed on specific database 
SELECT   bs.database_name,
		MAX(bs.backup_finish_date) AS BackupDate
	INTO #BackupState
	FROM     msdb..backupset bs
	WHERE    bs.TYPE = 'D' and last_lsn is not null
		AND database_name = @DBName
	GROUP BY bs.database_name

--If @BackupType = 2, then a TRANSACTION LOG backup will be performed
if @BackupType = 2
	Begin
			--Derive the T-SQL statement to be executed to perform the backup
			If Not Exists(Select 'X' from #BackupState where database_name = @DBName) 
						OR (Select top 1 restore_date From msdb..restorehistory Where destination_database_name = @DBName Order by restore_date Desc) >=
							(Select BackupDate from #BackupState where database_name = @DBName)
				Begin

					Set @str = 'BACKUP DATABASE [' + @DBName + '] TO  DISK = ' + Char(39) + @BackupFullPath + @DBName + '.bak' + Char(39) + 
							' WITH NOFORMAT, NOINIT,  NAME = ' + Char(39) + @DBName + '-Full Backup' + Char(39) + 
							', SKIP, NOREWIND, NOUNLOAD,  STATS = 10'
				End
			Else
				Begin
					--Derive the T-SQL statement to be executed to perform the backup
					Set @str = 'BACKUP LOG [' + @DBName + '] TO  DISK = ' + Char(39) + @BackupFullPath + @DBName + '.bak' + Char(39) + 
						' WITH NOFORMAT, NOINIT,  NAME = ' + Char(39) + @DBName + '-Transaction Log  Backup' + Char(39) + 
						', SKIP, NOREWIND, NOUNLOAD,  STATS = 10'
				END

			Print @str

			Begin Try
				--Execute the T-SQL Statement Derived.
				Exec sp_executesql @str

			End Try

			--Enters this piece of code when failure in the backup execution.
			Begin Catch
				Print 'Backup Failed for some dumb reason.  I must be a very bad developer.  Shame on me!!!!'
			End Catch

		End

Drop Table #BackupState

