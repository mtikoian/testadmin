--Adds filter to eliminate emails being sent for for specific failed user login.
INSERT  [SQLSat_IndyDBA].[dbo].[ALRT_Filters]  (AF_Error, AF_Severity, AF_MSG_Contains, AF_Enabled, AF_DateCreated, AF_CreatedBy, AF_Description)
	SELECT 18456, 14, '@message like ''%TestLogin%''', 1, '02-25-2013', 'BSC', 'This is a sample for how to create a filter to ignore certain Login and IP address source combinations'

