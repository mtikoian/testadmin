USE [msdb]
GO

/****** Object:  Job [LRJ_Test]    Script Date: 8/8/2014 12:05:29 PM ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 8/8/2014 12:05:29 PM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'LRJ_Test', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Run Statement]    Script Date: 8/8/2014 12:05:30 PM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Run Statement', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'Select * from sys.databases
		
		--Waitfor Delay ''00:05:00''', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

Exec dbo.sp_start_job N'LRJ_Test' ;

WaitFor Delay '00:00:03'

Use SQLSat_IndyDBA
Go

/*-------------------------------

	Run Job Check to capture the fact job just executed

--------------------------------*/

	DECLARE @jobid nvarchar(100)
	DECLARE @AvgRuntime int
	DECLARE @threshold int

	DECLARE @importanceID nvarchar(100)
	DECLARE @isEnabled bit
	DECLARE @LastUpdate datetime
	DECLARE @UpdatedBy nvarchar(200)

	DECLARE @AvgRunTime_Insert int
	DECLARE @RuntimeThreshold_Insert int
	DECLARE @LastUpdated_Insert datetime

--Determine if Profile Table exists.  If not, then create it.
If Not Exists(Select name from sys.objects where type_desc = 'User_Table' and name = 'LRJ_Profile')
	Begin
		CREATE TABLE [dbo].[LRJ_Profile](
			[ID] [int] IDENTITY(1,1) NOT NULL,
			[JobID] [nvarchar](100) NULL,
			[ImportanceID] [int] NULL,
			[isEnabled] [bit] NULL,
			[AvgRuntime] [int] NULL,
			[RuntimeThreshold] [int] NULL,
			[LastUpdated] [datetime] NULL,
			[UpdatedBy] [nvarchar](200) NULL
		) ON [PRIMARY]
	End


	--Create temp tables
	CREATE TABLE #tmpjobid
	(
		job_id nvarchar(100)
	)
	CREATE TABLE #tmpjobtime
	(
		job_id nvarchar(100),
		jobruntime int,
		jobruntimemin int
	)


	--SELECT each distinct job id and insert the results into the tmpjobid table
	insert into #tmpjobid
	SELECT distinct job_id
	FROM [msdb].[dbo].[sysjobhistory]

	--DECLARE curosr to iterate through job ids
	DECLARE jobid_cursor cursor for
	SELECT job_id from #tmpjobid

	open jobid_cursor

	fetch next from jobid_cursor into @jobid

	--Look to see if new jobs exist that have not been added
	--Find the runtimes of jobs and calulate the average of each, insert the results into second temp table
	while @@FETCH_STATUS = 0
		begin		
			--insert into #tmpjobtime
			SELECT 
			@AvgRuntime = (case(avg([run_duration])) / 60
				when 0 then 1
				else ((avg([run_duration]) / 60) + 0)
				end )
			FROM [msdb].[dbo].[sysjobhistory]
			WHERE job_id = @jobid
		
		    IF @AvgRuntime < 0
                 BEGIN
              
                    select top 10  run_duration
					into #tmptime
                    from [msdb].[dbo].[sysjobhistory]
                    where job_id = @jobid
                    and run_duration >= 0
                    Order by [run_duration] Desc

					SELECT 
						@AvgRuntime = (case(avg([run_duration])) / 60
							when 0 then 1
							else ((avg([run_duration]) / 60) + 0)
							end )
						FROM #tmptime

					Drop Table #tmptime


				END

			-- Determine what the threshold should be for the job based on the average runtime
			IF @AvgRuntime <= 4
				Begin 
					set @threshold = @AvgRuntime * 8
				End
			Else IF @AvgRuntime >= 5 and @AvgRuntime < 10
				Begin
					Set @threshold = @AvgRuntime * 5
				End
			Else IF @AvgRuntime >= 10 AND @AvgRuntime <= 20
				Begin
					Set @threshold = @AvgRuntime * 3
				End
			Else
				Begin
					Set @threshold = @AvgRuntime * 1.5
				End
		
			--Add the job to the Attribute table if it does not exist
			--Importance Level 2 will only send email, no text messages.
			set @importanceID = 2
			set @isEnabled = 1
			set @LastUpdate = GETDATE()
			set @UpdatedBy = (select SYSTEM_USER)
		
			if not exists (SELECT * from [dbo].[LRJ_Profile] where JobID = @jobid)
				Begin	
					insert into [dbo].[LRJ_Profile]
						(JobID, ImportanceID, isEnabled, AvgRuntime, RuntimeThreshold, LastUpdated, UpdatedBy)
					SELECT @jobid, @importanceID, @isEnabled, @AvgRuntime, @threshold, @LastUpdate, @UpdatedBy
				
				End
			ELSE
				BEGIN
				
					UPDATE [dbo].[LRJ_Profile]
					SET RuntimeThreshold = @threshold, LastUpdated = @LastUpdate, AvgRunTime = @AvgRunTime
					WHERE JobID = @jobid
				END 
			
		
			fetch next from jobid_cursor into @jobid		
		end

	--Close the cursor
	close jobid_cursor
	deallocate jobid_cursor

	--drop tables
	drop table #tmpjobtime
	drop table #tmpjobid

Select SJ.name, LP.* from LRJ_Profile LP
INNER Join msdb.dbo.sysjobs SJ on LP.JobID = SJ.job_id

