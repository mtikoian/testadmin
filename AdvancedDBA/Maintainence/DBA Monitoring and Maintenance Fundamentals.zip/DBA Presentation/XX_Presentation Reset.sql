USE [msdb]
GO

/****** Object:  Job [Capture Alerts]    Script Date: 8/8/2014 11:29:00 PM ******/
EXEC msdb.dbo.sp_delete_job @job_name=N'Capture Alerts', @delete_unused_schedule=1
GO


USE [msdb]
GO

/****** Object:  Job [LRJ_Test]    Script Date: 8/8/2014 11:29:23 PM ******/
EXEC msdb.dbo.sp_delete_job @job_name=N'LRJ_Test', @delete_unused_schedule=1
GO


USE [msdb]
GO

/****** Object:  Operator [Email]    Script Date: 8/8/2014 11:29:54 PM ******/
EXEC msdb.dbo.sp_delete_operator @name=N'Email'
GO

Drop Database SQLSat_IndyDBA;
Go

Drop Database TestMe;
Go

EXEC [BSC_Hydra_Admin].[dbo].[BSC_HistoryClean]
Go