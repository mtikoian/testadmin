Create Database SQLSat_IndyDBA;
Go

Use SQLSat_IndyDBA
Go

--Change the Database Context to the one named [SQLSat_IndyDBA]

	--DECLARE variables
	DECLARE @jobid nvarchar(100)
	DECLARE @AvgRuntime int
	DECLARE @threshold int

	DECLARE @importanceID nvarchar(100)
	DECLARE @isEnabled bit
	DECLARE @LastUpdate datetime
	DECLARE @UpdatedBy nvarchar(200)

	DECLARE @AvgRunTime_Insert int
	DECLARE @RuntimeThreshold_Insert int
	DECLARE @LastUpdated_Insert datetime

--Determine if Profile Table exists.  If not, then create it.
If Not Exists(Select name from sys.objects where type_desc = 'User_Table' and name = 'LRJ_Profile')
	Begin
		CREATE TABLE [dbo].[LRJ_Profile](
			[ID] [int] IDENTITY(1,1) NOT NULL,
			[JobID] [nvarchar](100) NULL,
			[ImportanceID] [int] NULL,
			[isEnabled] [bit] NULL,
			[AvgRuntime] [int] NULL,
			[RuntimeThreshold] [int] NULL,
			[LastUpdated] [datetime] NULL,
			[UpdatedBy] [nvarchar](200) NULL
		) ON [PRIMARY]
	End


	--Create temp tables
	CREATE TABLE #tmpjobid
	(
		job_id nvarchar(100)
	)
	CREATE TABLE #tmpjobtime
	(
		job_id nvarchar(100),
		jobruntime int,
		jobruntimemin int
	)


	--SELECT each distinct job id and insert the results into the tmpjobid table
	insert into #tmpjobid
	SELECT distinct job_id
	FROM [msdb].[dbo].[sysjobhistory]

	--DECLARE curosr to iterate through job ids
	DECLARE jobid_cursor cursor for
	SELECT job_id from #tmpjobid

	open jobid_cursor

	fetch next from jobid_cursor into @jobid

	--Look to see if new jobs exist that have not been added
	--Find the runtimes of jobs and calulate the average of each, insert the results into second temp table
	while @@FETCH_STATUS = 0
		begin		
			--insert into #tmpjobtime
			SELECT 
			@AvgRuntime = (case(avg([run_duration])) / 60
				when 0 then 1
				else ((avg([run_duration]) / 60) + 0)
				end )
			FROM [msdb].[dbo].[sysjobhistory]
			WHERE job_id = @jobid
		
		    IF @AvgRuntime < 0
                 BEGIN
              
                    select top 10  run_duration
					into #tmptime
                    from [msdb].[dbo].[sysjobhistory]
                    where job_id = @jobid
                    and run_duration >= 0
                    Order by [run_duration] Desc

					SELECT 
						@AvgRuntime = (case(avg([run_duration])) / 60
							when 0 then 1
							else ((avg([run_duration]) / 60) + 0)
							end )
						FROM #tmptime

					Drop Table #tmptime


				END

			-- Determine what the threshold should be for the job based on the average runtime
			IF @AvgRuntime <= 4
				Begin 
					set @threshold = @AvgRuntime * 8
				End
			Else IF @AvgRuntime >= 5 and @AvgRuntime < 10
				Begin
					Set @threshold = @AvgRuntime * 5
				End
			Else IF @AvgRuntime >= 10 AND @AvgRuntime <= 20
				Begin
					Set @threshold = @AvgRuntime * 3
				End
			Else
				Begin
					Set @threshold = @AvgRuntime * 1.5
				End
		
			--Add the job to the Attribute table if it does not exist
			--Importance Level 2 will only send email, no text messages.
			set @importanceID = 2
			set @isEnabled = 1
			set @LastUpdate = GETDATE()
			set @UpdatedBy = (select SYSTEM_USER)
		
			if not exists (SELECT * from [dbo].[LRJ_Profile] where JobID = @jobid)
				Begin	
					insert into [dbo].[LRJ_Profile]
						(JobID, ImportanceID, isEnabled, AvgRuntime, RuntimeThreshold, LastUpdated, UpdatedBy)
					SELECT @jobid, @importanceID, @isEnabled, @AvgRuntime, @threshold, @LastUpdate, @UpdatedBy
				
				End
			ELSE
				BEGIN
				
					UPDATE [dbo].[LRJ_Profile]
					SET RuntimeThreshold = @threshold, LastUpdated = @LastUpdate, AvgRunTime = @AvgRunTime
					WHERE JobID = @jobid
				END 
			
		
			fetch next from jobid_cursor into @jobid		
		end

	--Close the cursor
	close jobid_cursor
	deallocate jobid_cursor

	--drop tables
	drop table #tmpjobtime
	drop table #tmpjobid

Select SJ.name, LP.* from LRJ_Profile LP
INNER Join msdb.dbo.sysjobs SJ on LP.JobID = SJ.job_id


