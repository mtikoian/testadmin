--use 2008 R2
--Prep Script must have been run already
--integrity checks

DBCC CHECKDB ('AdventureWorks2008R2')
GO
--2 mins & 22 seconds

--checkdb with no_infomsgs
DBCC CHECKDB ('AdventureWorks2008R2') with no_infomsgs
GO
--2 mins & 19 seconds

DBCC CHECKDB ('AdventureWorks2008R2') with physical_only
GO
-- 1 min and 55 seconds

--enable some trace flags
--2549 - treating each file as residing on unique disk
--2562 - treats CHECKDB process as a single batch at the cost of higher tempdb utilization
--part of SQL 2012 code so you will benefit from it without the TF
--2568 - correct poor performance of DATA_PURITY in SQL Server 2005 x64
--2528 - turn off parallelism for CHECKDB
DBCC TRACESTATUS
GO
DBCC TRACEON (2549, 2562, -1)
GO
DBCC CHECKDB ('AdventureWorks2008R2') with physical_only
GO
DBCC TRACEOFF (2549, 2562, -1)
GO
--1 min & 43 seconds