--use SQL Server 2014
use [IndexDemo]
go

--x lock
BEGIN TRANSACTION
UPDATE [dbo].[OnlineRebuild]
SET vcFName = 'Name1'
WHERE iID = 1

Select @@SPID '@@SPID'
--rollback
--