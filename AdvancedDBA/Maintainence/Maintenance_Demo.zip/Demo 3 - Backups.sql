--use 2008 R2
--Prep Script must have been run already for Demo 2
--check for enabled flags
DBCC TRACESTATUS
GO

--enable some useful trace flags
--3226 � no backup/restore info in the errorlog
--3001 � no backup history saved in msdb
--3605 - directs the output of other trace flags to the errorlog
--3004 - writes in the log zeroing information
--3213 - writes in the log parameter details
DBCC TRACEON(3605,3004,3213,-1)
GO
DBCC TRACESTATUS
GO

--start a default backup
BACKUP DATABASE [AdventureWorks2008R2] TO DISK=N'D:\AdventureWorks2008R2_Original.bak'
WITH STATS=10
--3 mins & 46 seconds
--check backup size ~ 8.23 GB


--try to split it into files on the same device
BACKUP DATABASE [AdventureWorks2008R2] TO 
DISK=N'D:\AdventureWorks2008R2_Stream1.bak',
DISK=N'D:\AdventureWorks2008R2_Stream2.bak'
WITH STATS=10
--4 mins & 47 seconds
--check backup size ~ 2 files * 4.11 GB each

--try to split it into two different devices
BACKUP DATABASE [AdventureWorks2008R2] TO 
DISK=N'C:\AdventureWorks2008R2_Stream1.bak',
DISK=N'D:\AdventureWorks2008R2_Stream3.bak'
WITH STATS=10
--2 mins & 43 seconds
--check backup size ~ 2 files * 4.11 GB each

--backup with compression
BACKUP DATABASE [AdventureWorks2008R2] TO DISK=N'D:\AdventureWorks2008R2_Compressed.bak'
WITH STATS=10, COMPRESSION
--2 min & 31 seconds
--check backup size ~ 3.12 GB

--parameter tweaking
BACKUP DATABASE [AdventureWorks2008R2] TO 
DISK=N'D:\AdventureWorks2008R2_Compressed_Parameters.bak'
WITH STATS=10, COMPRESSION,
BUFFERCOUNT=100,
MAXTRANSFERSIZE=4194304,
BLOCKSIZE=65536
--2 mins & 09 seconds
--check backup size ~ 3.12 GB

--check for compressed tables
USE [AdventureWorks2008R2]
GO
SELECT st.name, ix.name , st.object_id, sp.partition_id, sp.partition_number, sp.data_compression,sp.data_compression_desc
FROM sys.partitions SP 
INNER JOIN sys.tables ST ON st.object_id = sp.object_id 
LEFT OUTER JOIN sys.indexes IX ON sp.object_id = ix.object_id and sp.index_id = ix.index_id
WHERE sp.data_compression <> 0
order by st.name, sp.index_id

--compress some of the largest tables
USE [AdventureWorks2008R2]
GO

ALTER INDEX [PK_SalesOrderHeaderEnlarged_SalesOrderID] ON 
[Sales].[SalesOrderHeaderEnlarged]
REBUILD WITH (ONLINE=OFF, DATA_COMPRESSION=PAGE)

ALTER INDEX [PK_SalesOrderHeaderEnlarged1_SalesOrderID] ON 
[Sales].[SalesOrderHeaderEnlarged1]
REBUILD WITH (ONLINE=OFF, DATA_COMPRESSION=PAGE)
--1 min & 06 seconds

--ALTER INDEX [PK_SalesOrderHeaderEnlarged2_SalesOrderID] ON 
--[Sales].[SalesOrderHeaderEnlarged2]
--REBUILD WITH (ONLINE=OFF, DATA_COMPRESSION=PAGE)

--check for compressed tables
USE [AdventureWorks2008R2]
GO
SELECT st.name, ix.name , st.object_id, sp.partition_id, sp.partition_number, sp.data_compression,sp.data_compression_desc
FROM sys.partitions SP 
INNER JOIN sys.tables ST ON st.object_id = sp.object_id 
LEFT OUTER JOIN sys.indexes IX ON sp.object_id = ix.object_id and sp.index_id = ix.index_id
WHERE sp.data_compression <> 0
order by st.name, sp.index_id

--backup with backup compression and data compression
BACKUP DATABASE [AdventureWorks2008R2] TO DISK=N'D:\AdventureWorks2008R2_Compressed_Data_Compressed.bak'
WITH STATS=10, COMPRESSION
--2 mins & 18 seconds
--check backup size ~ 2.99 GB

--parameter tweaking plus backup and data compression
BACKUP DATABASE [AdventureWorks2008R2] TO 
DISK=N'D:\AdventureWorks2008R2_Compressed_Data_Compressed_Parameters.bak'
WITH STATS=10, COMPRESSION,
BUFFERCOUNT=100,
MAXTRANSFERSIZE=4194304,
BLOCKSIZE=65536
--1 min & 56 seconds
--check backup size ~ 2.99 GB

--turn off the flags
DBCC TRACEOFF(3605,3004,3213,-1)
GO
DBCC TRACESTATUS
GO