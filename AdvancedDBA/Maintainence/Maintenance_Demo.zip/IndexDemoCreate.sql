CREATE DATABASE IndexDemo 
go 

-- Create Table in Database 
USE IndexDemo
go 
CREATE TABLE OnlineRebuild 
  ( 
     iID     INT, 
     vcFName VARCHAR(100), 
     vcLName VARCHAR(100), 
     CONSTRAINT PK_OnlineRebuild PRIMARY KEY (iID) 
  ) 

go 

-- Populate Table
SET nocount ON 
go 
DECLARE @iLoop INT 
SET @iLoop = 1 
WHILE @iLoop <= 100000 
  BEGIN 
      INSERT INTO OnlineRebuild 
      VALUES      (@iLoop, 
                   'FName' + CONVERT(VARCHAR(10), @iLoop), 
                   'LName' + CONVERT(VARCHAR(10), @iLoop) ) 
      SET @iLoop = @iLoop + 1 
  END 
go 
SET nocount OFF 
go   