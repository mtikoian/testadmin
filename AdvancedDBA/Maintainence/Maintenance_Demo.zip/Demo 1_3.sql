select session_id, blocking_session_id, wait_resource, wait_time, wait_type
from sys.dm_exec_requests where session_id = 57

SELECT request_session_id
    ,request_mode
    ,request_type
    ,request_status
    ,resource_type
FROM sys.dm_tran_locks
WHERE request_session_id = 57