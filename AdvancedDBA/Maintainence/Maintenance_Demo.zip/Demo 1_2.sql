Select @@SPID 'SPID'
go

use [IndexDemo]
go

ALTER INDEX PK_OnlineRebuild ON [dbo].[OnlineRebuild]
REBUILD WITH (ONLINE = ON)

--ALTER INDEX PK_OnlineRebuild ON [dbo].[OnlineRebuild]
--REBUILD WITH 
--( 
--ONLINE = ON ( WAIT_AT_LOW_PRIORITY ( MAX_DURATION = 1 MINUTES, ABORT_AFTER_WAIT = NONE ) )
--)

--ALTER INDEX PK_OnlineRebuild ON [dbo].[OnlineRebuild]
--REBUILD WITH 
--( 
--ONLINE = ON ( WAIT_AT_LOW_PRIORITY ( MAX_DURATION = 1 MINUTES, ABORT_AFTER_WAIT = SELF ) )
--)

ALTER INDEX PK_OnlineRebuild ON [dbo].[OnlineRebuild]
REBUILD WITH 
( 
ONLINE = ON ( WAIT_AT_LOW_PRIORITY ( MAX_DURATION = 1 MINUTES, ABORT_AFTER_WAIT = BLOCKERS ) )
)