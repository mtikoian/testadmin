sp_configure 'max degree of parallelism', 8
RECONFIGURE


DBCC DROPCLEANBUFFERS

USE master;
GO

EXECUTE [dbo].[DatabaseIntegrityCheck] @Databases = 'USER_DATABASES', @LogToTable = 'N'