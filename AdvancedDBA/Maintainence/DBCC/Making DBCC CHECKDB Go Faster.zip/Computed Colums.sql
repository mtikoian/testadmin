USE master;
GO

IF EXISTS (SELECT 1
		    FROM sys.databases
		    WHERE name = N'ComputedColumns')
	DROP DATABASE ComputedColumns;


CREATE DATABASE ComputedColumns;
GO

ALTER DATABASE ComputedColumns SET RECOVERY SIMPLE WITH ROLLBACK IMMEDIATE;
GO

USE ComputedColumns;
GO

CREATE TABLE TestTable (id INT PRIMARY KEY IDENTITY(1,1),
						computedCol AS (id % 2))
GO

INSERT INTO dbo.TestTable DEFAULT VALUES;
GO 5000000 -- Took 24 minutes and 13 secs to complete on BRISKET!

--DROP TABLE dbo.TestTable

SELECT COUNT(*) FROM dbo.TestTable

DBCC FREEPROCCACHE
DBCC DROPCLEANBUFFERS

USE master;
GO

DBCC CHECKDB('ComputedColumns') WITH TABLOCK, NO_INFOMSGS, ALL_ERRORMSGS
GO

CREATE NONCLUSTERED INDEX Humongously_Evil_Little_Index ON dbo.TestTable(computedCol);
GO

DROP INDEX Humongously_Evil_Little_Index ON dbo.TestTable;
GO