/*******************************************************************************
Filename: 8_DBCC_FindData.sql
Author: (C) 04/30/2012, Erin Stellato
Summary: This script was used in support of a session given by Erin Stellato
Feedback: mailto:erin@erinstellato.com

This script and information herein are provided "as is" without warranty
of any kind, either expressed or implied.

*******************************************************************************/

-- corrupt page
DBCC TRACEON (3604);
GO
DBCC PAGE('AdventureWorksCorrupt2', 1, 747, 2);

-- parent page
DBCC TRACEON (3604);
GO
DBCC PAGE('AdventureWorksCorrupt2', 1, 744, 3);

-- previous page
DBCC TRACEON (3604);
GO
DBCC PAGE('AdventureWorksCorrupt2', 1, 746, 3);
-- last EmployeeID = ???

-- next page
DBCC TRACEON (3604);
GO
DBCC PAGE('AdventureWorksCorrupt2', 1, 748, 3);
-- first EmployeeID = ???
