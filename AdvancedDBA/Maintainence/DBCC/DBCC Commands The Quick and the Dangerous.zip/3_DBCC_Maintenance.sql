/*******************************************************************************
Filename: 3_DBCC_Maintenance.sql
Author: (C) 05/08/2012, Erin Stellato
Summary: This script was used in support of a session given by Erin Stellato
Feedback: mailto:erin@erinstellato.com

This script and information herein are provided "as is" without warranty
of any kind, either expressed or implied.

*******************************************************************************/

USE AdventureWorksDBCC;
GO


/*
	DROPCLEANBUFFERS
*/
-- **Enable Execution Plan
SET STATISTICS IO ON;

SELECT SalesOrderID, LineTotal, UnitPriceDiscount
FROM Sales.SalesOrderDetail
WHERE LineTotal > 10000
/*

*/

sp_helpindex "Sales.SalesOrderDetail"


CREATE NONCLUSTERED INDEX IX_SalesOrderDetail_LineTotal 
	ON Sales.SalesOrderDetail (LineTotal)


DBCC DROPCLEANBUFFERS;


SELECT SalesOrderID, LineTotal, UnitPriceDiscount
FROM Sales.SalesOrderDetail
WHERE LineTotal > 10000;
/*

*/

CREATE NONCLUSTERED INDEX IX_SalesOrderDetail_LineTotal_UnitPriceDiscount
	ON Sales.SalesOrderDetail (LineTotal, UnitPriceDiscount)

DBCC DROPCLEANBUFFERS;

SELECT SalesOrderID, LineTotal, UnitPriceDiscount
FROM Sales.SalesOrderDetail
WHERE LineTotal > 10000;
/*

*/

DROP INDEX Sales.SalesOrderDetail.IX_SalesOrderDetail_LineTotal
DROP INDEX Sales.SalesOrderDetail.IX_SalesOrderDetail_LineTotal_UnitPriceDiscount






/*
	FREEPROCCACHE
*/

USE AdventureWorksDBCC;
GO

IF OBJECT_ID ( 'HumanResources.uspGetManagerEmps', 'P' ) IS NOT NULL 
    DROP PROCEDURE HumanResources.uspGetManagerEmps;
GO
CREATE PROCEDURE HumanResources.uspGetManagerEmps
	@ManagerID INT
AS	
	SET NOCOUNT ON;
	SELECT ManagerID, Title AS "Employee Title"
	FROM HumanResources.Employee
	WHERE ManagerID = @ManagerID
	ORDER BY Title
	
GO


SET STATISTICS IO ON

EXECUTE HumanResources.uspGetManagerEmps @ManagerID = 71;

EXECUTE HumanResources.uspGetManagerEmps @ManagerID = 21;


/*
	get the plan for the query
*/
SELECT p.usecounts, s.text, qp.query_plan, p.plan_handle
FROM sys.dm_exec_cached_plans p
CROSS APPLY sys.dm_exec_query_plan (p.plan_handle) qp
CROSS APPLY sys.dm_exec_sql_text(p.plan_handle) s
WHERE s.text LIKE '%HumanResources.Employee%';


SELECT COUNT(*) FROM HumanResources.Employee WHERE ManagerID = 71
SELECT COUNT(*) FROM HumanResources.Employee WHERE ManagerID = 21

 
/*
	clear the entire plan cache :(
*/
DBCC FREEPROCCACHE



EXECUTE HumanResources.uspGetManagerEmps @ManagerID = 71;

EXECUTE HumanResources.uspGetManagerEmps @ManagerID = 21;


/*
	get the plan for the query
*/
SELECT p.usecounts, s.text, qp.query_plan, p.plan_handle
FROM sys.dm_exec_cached_plans p
CROSS APPLY sys.dm_exec_query_plan (p.plan_handle) qp
CROSS APPLY sys.dm_exec_sql_text(p.plan_handle) s
WHERE s.text LIKE '%HumanResources.Employee%';
 

/*
	clear the ONE plan from cache :)
*/
DBCC FREEPROCCACHE (<crazylongvarbinaryinhereplease>)




/*
	FLUSHPROCINDB
*/

DBCC FLUSHPROCINDB(<db_id>)




