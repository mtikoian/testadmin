/*******************************************************************************
Filename: 7_DBCC_CHECKDB.sql
Author: (C) 05/08/2012, Erin Stellato
Summary: This script was used in support of a session given by Erin Stellato
Feedback: mailto:erin@erinstellato.com

This script and information herein are provided "as is" without warranty
of any kind, either expressed or implied.

ELS Demo prep: 
	set to READ UNCOMMITTED in Tools | Options

*******************************************************************************/

USE AdventureWorksDBCC;
GO

/*
	CHECKDB
*/


DBCC CHECKDB 
[
    [ ( database_name | database_id | 0
        [ , NOINDEX 
        | , { REPAIR_ALLOW_DATA_LOSS | REPAIR_FAST | REPAIR_REBUILD } ]
    ) ]
    [ WITH 
        {
            [ ALL_ERRORMSGS ]
            [ , EXTENDED_LOGICAL_CHECKS ] 
            [ , NO_INFOMSGS ]
            [ , TABLOCK ]
            [ , ESTIMATEONLY ]
            [ , { PHYSICAL_ONLY | DATA_PURITY } ]
        }
    ]
]


/*
	Corruption 1
*/

USE AdventureWorksCorrupt1;
GO


SELECT EmployeeID, LoginID
FROM AdventureWorksDBCC.HumanResources.Employee 
WHERE LoginID LIKE 'adventure-works\kevin%'


SELECT EmployeeID, LoginID
FROM AdventureWorksCorrupt1.HumanResources.Employee 
WHERE LoginID LIKE 'adventure-works\kevin%'


/*
	this will not solve your problem
*/
SELECT EmployeeID, LoginID
FROM AdventureWorksCorrupt1.HumanResources.Employee WITH (NOLOCK)
WHERE LoginID LIKE 'adventure-works\kevin%'

/*
	do not take the database offline!  
	do not detach the database!
*/

USE AdventureWorksCorrupt1;
GO
DBCC CHECKTABLE ('HumanResources.Employee') WITH ALL_ERRORMSGS, NO_INFOMSGS;

DBCC CHECKALLOC ('AdventureWorksCorrupt1') WITH ALL_ERRORMSGS, NO_INFOMSGS;

DBCC CHECKCATALOG ('AdventureWorksCorrupt1');


DBCC CHECKDB ('AdventureWorksCorrupt1') WITH ESTIMATEONLY;

DBCC CHECKDB ('AdventureWorksCorrupt1') WITH ALL_ERRORMSGS, NO_INFOMSGS;



/*
	rebuilding index will not work
*/
ALTER INDEX AK_Employee_LoginID ON HumanResources.Employee REBUILD

sp_helpindex "HumanResources.Employee"

/*
	Option 1: Drop and then recreate index
*/
DROP INDEX  HumanResources.Employee.AK_Employee_LoginID

CREATE UNIQUE NONCLUSTERED INDEX AK_Employee_LoginID ON HumanResources.Employee (LoginID)

/*
	Option 2: Disable, then rebuild
	If constraints exist, do this within a transaction
*/

BEGIN TRANSACTION;

	ALTER INDEX AK_Employee_LoginID ON HumanResources.Employee DISABLE;

	ALTER INDEX AK_Employee_LoginID ON HumanResources.Employee REBUILD;

COMMIT;


/*
	Corruption 2
*/
USE AdventureWorksCorrupt2;
GO


SELECT EmployeeID, LoginID
FROM AdventureWorksCorrupt2.HumanResources.Employee 
WHERE LoginID LIKE 'adventure-works\david%'

SELECT EmployeeID, LoginID, ManagerID 
FROM AdventureWorksCorrupt2.HumanResources.Employee 
WHERE LoginID LIKE 'adventure-works\david%'


/*
	again, this will not solve your problem
*/
SELECT EmployeeID, LoginID, ManagerID 
FROM AdventureWorksCorrupt2.HumanResources.Employee WITH (NOLOCK)
WHERE LoginID LIKE 'adventure-works\david%'

/*
	do not take the database offline!  
	do not detach the database!
*/

USE AdventureWorksCorrupt2;
GO
DBCC CHECKTABLE ('HumanResources.Employee') WITH ALL_ERRORMSGS, NO_INFOMSGS;

DBCC CHECKALLOC ('AdventureWorksCorrupt2') WITH ALL_ERRORMSGS, NO_INFOMSGS;

DBCC CHECKCATALOG ('AdventureWorksCorrupt2');

DBCC CHECKDB ('AdventureWorksCorrupt2') WITH ALL_ERRORMSGS, NO_INFOMSGS;

--**switch to 8_DBCC_CHECKDB to find missing data




/*
	Corruption 3
*/
USE AdventureWorksCorrupt3;
GO


SELECT EmployeeID, LoginID
FROM AdventureWorksCorrupt3.HumanResources.Employee 
WHERE LoginID LIKE 'adventure-works\kevin%'

SELECT EmployeeID, LoginID, ManagerID 
FROM AdventureWorksCorrupt3.HumanResources.Employee 
WHERE LoginID LIKE 'adventure-works\david%'

SELECT * 
FROM AdventureWorksCorrupt3.HumanResources.Employee 


DBCC CHECKTABLE ('HumanResources.Employee') WITH ALL_ERRORMSGS, NO_INFOMSGS;

DBCC CHECKALLOC ('AdventureWorksCorrupt3') WITH ALL_ERRORMSGS, NO_INFOMSGS;

DBCC CHECKCATALOG ('AdventureWorksCorrupt3');

DBCC CHECKDB ('AdventureWorksCorrupt3') WITH ALL_ERRORMSGS, NO_INFOMSGS;




/*
	CHECKCATALOG
*/
DBCC CHECKCATALOG 
[ 
    ( 
    database_name | database_id | 0
    )
]
    [ WITH NO_INFOMSGS ] 
        

/*
	CHECKALLOC
*/
DBCC CHECKALLOC 
[
    ( database_name | database_id | 0 
      [ , NOINDEX 
      | , { REPAIR_ALLOW_DATA_LOSS | REPAIR_FAST | REPAIR_REBUILD } ]
    )
    [ WITH 
        { 
          [ ALL_ERRORMSGS ]
          [ , NO_INFOMSGS ] 
          [ , TABLOCK ] 
          [ , ESTIMATEONLY ] 
        }
    ]
]


/*
	CHECKFILEGROUP
*/
DBCC CHECKFILEGROUP 
[
    [ ( { filegroup_name | filegroup_id | 0 } 
        [ , NOINDEX ] 
  ) ]
    [ WITH 
        { 
            [ ALL_ERRORMSGS | NO_INFOMSGS ] 
            [ , TABLOCK ] 
            [ , ESTIMATEONLY ]
            [ , PHYSICAL_ONLY ]  
        } 
    ]
]
  


/*
	CHECKTABLE
*/
DBCC CHECKTABLE 
(
    table_name | view_name
    [ , { NOINDEX | index_id }
     |, { REPAIR_ALLOW_DATA_LOSS | REPAIR_FAST | REPAIR_REBUILD } 
    ] 
)
    [ WITH 
        { ALL_ERRORMSGS ]
          [ , EXTENDED_LOGICAL_CHECKS ] 
          [ , NO_INFOMSGS ]
          [ , TABLOCK ] 
          [ , ESTIMATEONLY ] 
          [ , { PHYSICAL_ONLY | DATA_PURITY } ] 
        }
    ]
      










