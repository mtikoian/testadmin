/*******************************************************************************
Filename: 1_DBCC_Basics.sql
Author: (C) 05/08/2012, Erin Stellato
Summary: This script was used in support of a session given by Erin Stellato
Feedback: mailto:erin@erinstellato.com

This script and information herein are provided "as is" without warranty
of any kind, either expressed or implied.

*******************************************************************************/

USE AdventureWorksDBCC;
GO


/*
	DBCC HELP example
*/

DBCC HELP(CHECKDB);
GO

/*
	List all* DBCC commands 
*/
DBCC HELP ('?');
GO



/*
	Could previously be used to show undocumented comments, but no longer available
*/
DBCC TRACEON(2520); 
GO
DBCC HELP ('?');
GO

DBCC TRACEON(2520); 
GO
DBCC HELP ('EXTENTINFO');
GO

DBCC EXTENTINFO



/*
	should list all trace flags enabled globally
*/ 
DBCC TRACESTATUS(-1); 
GO 

/*
	should list all trace flags enabled for this connection
*/
DBCC TRACESTATUS(); 
GO 



/*
	backup transaction log
*/
DECLARE @CurrentDT DATETIME2 = GETDATE();
DECLARE @SQLString VARCHAR(4000)
SET @SQLString = 'BACKUP LOG [AdventureWorksDBCC] TO  DISK = N''C:\Databases\Backups\AW_DBCC_' 
SET @SQLString = @SQLString + CONVERT(VARCHAR(30),@CurrentDT, 112) + REPLACE(REPLACE(CONVERT(VARCHAR(30),@CurrentDT, 114),':',''),'.','')
SET @SQLString = @SQLString + '.trn'' WITH NOFORMAT, NOINIT,  NAME = N''AdventureWorksDBCC-TLog'', SKIP, NOREWIND, NOUNLOAD,  STATS = 10'
EXEC (@SQLString)


/*
	Supress entries to the SQL Server error log for every 
	successful backup operation (locally)
*/
DBCC TRACEON(3226);
GO


/*
	verify trace flag is enabled
*/
DBCC TRACESTATUS(3226); 
GO 

DBCC TRACESTATUS(-1); 
GO 


/*
	turn off 3226 locally
*/
DBCC TRACEOFF(3226);
GO

DBCC TRACESTATUS(-1); 
GO 



/*
	Disables parallel checking of objects by DBCC CHECKDB, DBCC CHECKFILEGROUP, and DBCC CHECKTABLE globally
*/
DBCC TRACEON(2528, -1);
GO

/*
	Turns off TF 2528 globally
*/
DBCC TRACEOFF(2528, -1);
GO