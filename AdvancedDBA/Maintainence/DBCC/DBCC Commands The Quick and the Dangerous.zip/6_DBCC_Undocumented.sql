/*******************************************************************************
Filename: 6_DBCC_Undocumented.sql
Author: (C) 05/08/2012, Erin Stellato
Summary: This script was used in support of a session given by Erin Stellato
Feedback: mailto:erin@erinstellato.com

This script and information herein are provided "as is" without warranty
of any kind, either expressed or implied.

*******************************************************************************/

USE AdventureWorksDBCC;
GO

/*	
	IND
*/
SELECT TOP 2 * FROM HumanResources.Employee;
GO

sp_helpindex "HumanResources.Employee";
GO

SELECT *
FROM sys.indexes 
WHERE object_id = OBJECT_ID(N'AdventureWorksDBCC.HumanResources.Employee');
GO


DBCC IND ('AdventureWorksDBCC', 'HumanResources.Employee', 2)


/*
	In SQL 2012, utilize sys.dm_db_database_page_allocations
	to get this same information (and more)
*/



/*	
	PAGE
*/
DBCC PAGE ( {'dbname' | dbid}, filenum, pagenum [, printopt={0|1|2|3} ])


DBCC TRACEON (3604);
GO
DBCC PAGE('AdventureWorksDBCC', 1, 1581, 3);


-- clustered index
DBCC IND ('AdventureWorksDBCC', 'HumanResources.Employee', 1);


DBCC TRACEON (3604);
GO
DBCC PAGE('AdventureWorksDBCC', 1, 747, 3);


/*	
	DBINFO
*/
DBCC TRACEON (3604);
GO
DBCC DBINFO ('AdventureWorksDBCC');
GO


/*	
	LOGINFO
*/

DBCC LOGINFO ('AdventureWorksDBCC')

