/*******************************************************************************
Filename: 5_DBCC_Validation.sql
Author: (C) 05/08/2012, Erin Stellato
Summary: This script was used in support of a session given by Erin Stellato
Feedback: mailto:erin@erinstellato.com

This script and information herein are provided "as is" without warranty
of any kind, either expressed or implied.

*******************************************************************************/


USE AdventureWorksDBCC;
GO
    

/*
	create a table
*/
CREATE TABLE MovieInfoHistory (
	ID INT IDENTITY(1,1) PRIMARY KEY, 
	MovieName VARCHAR(800), 
	ReleaseDate SMALLDATETIME,
	Rating VARCHAR(5)
	);


/*
	add some data
*/
INSERT INTO dbo.MovieInfoHistory ( 
	MovieName, ReleaseDate, Rating
	)
VALUES
	('Caddyshack', '1980-07-25', 'R'),
	('Bill & Ted''s Excellent Adventure', '1989-02-17 00:00:00', 'PG'),
	('Apollo 13', '1995-05-30 00:00:00', 'PG'),
	('The Hunt for Red October', '1990-03-02 00:00:00', 'PG'),
	('A Few Good Men', '1994-12-11 00:00:00', 'R'),
	('Memento', '2000-10-11', 'R'),
	('Apollo 13', '1995-06-30 00:00:00', 'PG'),
	('The Truman Show', '1998-06-05 00:00:00', 'PG-13'),
	('All The President''s Men', '1976-04-09 00:00:00', 'R'),
	('The Right Stuff', '1983-10-21 00:00:00', 'PG-13');


/*
	try to add a constraint
*/
ALTER TABLE dbo.MovieInfoHistory 
ADD CONSTRAINT CheckReleaseDate CHECK (ReleaseDate < '2000-01-01 00:00:00');

/*
	try again to add a constraint
*/
ALTER TABLE dbo.MovieInfoHistory WITH NOCHECK 
ADD CONSTRAINT CheckReleaseDate CHECK (ReleaseDate < '2000-01-01 00:00:00');


/*
	add more data
*/
INSERT INTO dbo.MovieInfoHistory ( 
	MovieName, ReleaseDate, Rating
	)
VALUES
	('The Natural', '1984-05-11 00:00:00', 'PG'),
	('The Hangover', '2009-06-05 00:00:00', 'R'),
	('IronMan', '2008-05-02 00:00:00', 'PG-13'),
	('The Incredibles', '2004-11-05 00:00:00', 'PG');

/*
	check constraints
*/
DBCC CHECKCONSTRAINTS(CheckReleaseDate);


/*
	find the bad data
*/
SELECT * FROM dbo.MovieInfoHistory WHERE ...


/*
	clean up
*/
DROP TABLE dbo.MovieInfoHistory;


/*
	check all constraints
*/
DBCC CHECKCONSTRAINTS WITH ALL_CONSTRAINTS;
GO





/*
	CHECKIDENT
*/
DBCC CHECKIDENT 
 ( 
    table_name
        [, { NORESEED | { RESEED [, new_reseed_value ] } } ]
)
[ WITH NO_INFOMSGS ]


CREATE TABLE dbo.identtest (id INT IDENTITY (1,1), info VARCHAR(20));

SET NOCOUNT ON;

INSERT INTO dbo.identtest (info)
VALUES ('test data');
GO 1000


/*
	reseed the identity
*/
DBCC CHECKIDENT ("dbo.identtest", RESEED, 10);


/*
	do not fix identity if it is wrong
*/
DBCC CHECKIDENT ("dbo.identtest", NORESEED)


/*
	fix the identity if it is wrong
*/
DBCC CHECKIDENT ("dbo.identtest")


DROP TABLE dbo.identtest


SELECT 
	schema_name(st.schema_id) + '.' + st.name AS 'Table', 
	sc.name AS 'Column',
	CASE sc.system_type_id
		WHEN 127 THEN 'bigINT'
		WHEN 56 THEN 'INT'
		WHEN 52 THEN 'smallINT'
		WHEN 48 THEN 'tinyINT'
	END AS 'DataType',
	ident_current(schema_name(st.schema_id) + '.' + st.name) AS 'Current Identity Value',
	CASE sc.system_type_id
		WHEN 127 THEN (ident_current(schema_name(st.schema_id) + '.' + st.name) * 100.) / 9223372036854775807
		WHEN 56 THEN (ident_current(schema_name(st.schema_id) + '.' + st.name) * 100.) / 2147483647
		WHEN 52 THEN (ident_current(schema_name(st.schema_id) + '.' + st.name) * 100.) / 32767
		WHEN 48 THEN (ident_current(schema_name(st.schema_id) + '.' + st.name) * 100.) / 255
	END AS 'Percentage Used' 
FROM sys.columns sc 
JOIN sys.tables st ON st.object_id = sc.object_id
WHERE sc.is_identity = 1
ORDER BY st.name

