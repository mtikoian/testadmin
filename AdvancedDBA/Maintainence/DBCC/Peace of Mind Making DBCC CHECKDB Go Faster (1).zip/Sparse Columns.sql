USE master;
GO

IF EXISTS (SELECT 1
		    FROM sys.databases
		    WHERE name = N'SparseColumns')
	DROP DATABASE SparseColumns;


CREATE DATABASE SparseColumns;
GO

ALTER DATABASE SparseColumns SET RECOVERY SIMPLE WITH ROLLBACK IMMEDIATE;
GO

USE SparseColumns;
GO

CREATE TABLE TestTable (sparseCol NVARCHAR(10) SPARSE)
GO

INSERT INTO dbo.TestTable DEFAULT VALUES;
GO 5000000

--DROP TABLE dbo.TestTable

SELECT COUNT(*) FROM dbo.TestTable
WHERE sparseCol IS NOT NULL

DBCC FREEPROCCACHE
DBCC DROPCLEANBUFFERS

USE master;
GO

DBCC CHECKDB('SparseColumns') WITH TABLOCK, NO_INFOMSGS, ALL_ERRORMSGS
GO

CREATE INDEX Not_So_Evil_Little_Index ON dbo.TestTable(sparseCol);
GO

DROP INDEX Not_So_Evil_Little_Index ON dbo.TestTable;
GO

CREATE INDEX Tremendously_Evil_Little_Index ON dbo.TestTable(sparseCol)
WHERE sparseCol IS NOT NULL;
GO

DROP INDEX Not_So_Evil_Little_Index ON dbo.TestTable;
GO

DROP INDEX Tremendously_Evil_Little_Index ON dbo.TestTable;
GO