---------------------------------------------------------------------
-- Optimizing Temporal Queries
-- Overlapping Intervals
-- Itzik Ben-Gan, Dejan Sarka, Davide Mauri, SolidQ, 2013
---------------------------------------------------------------------

/*---------------------------------------------------------------------
Additional information

Relational Interval Tree model by Hans-Peter, Kriegel Marco, P�tke Thomas Seidl
See academic paper: Managing Intervals Efficiently in Object-Relational Databases 
                    (http://www.dbs.ifi.lmu.de/Publikationen/Papers/VLDB2000.pdf)
Further optimizations (static RI-tree) by Laurent Martin - see articles:
 A Static Relational Interval Tree 
 (http://www.solidq.com/sqj/Pages/2011-September-Issue/A-Static-Relational-Interval-Tree.aspx)
 Advanced interval queries with the Static Relational Interval Tree 
 (http://www.solidq.com/sqj/Pages/Relational/Advanced-interval-queries-with-the-Static-Relational-Interval-Tree.aspx)

Inside Microsoft� SQL Server� 2008: T-SQL Programming book
 by Itzik Ben-Gan, Dejan Sarka, Roger Wolter, Greg Low, Ed Katibah, and Isaac Kunen, Microsoft Press, 2009, 
 especially Dejan Sarka chapter 12, Temporal Support in the Relational Model. 
 (http://www.amazon.com/gp/product/0735626022/ref=s9_simh_gw_p14_d0_i1?pf_rd_m=ATVPDKIKX0DER&pf_rd_s=center-2&pf_rd_r=1AEWTQ7GTY1XS1R68R2M&pf_rd_t=101&pf_rd_p=1389517282&pf_rd_i=507846)
 You can find all of the theory explained in this chapter, and the definition of the IntervalCID data type 
 and PACK and UNPACK operators. The Date's proposed sixth normal form is discussed there as well. 

Interval Queries in SQL Server SQL Server magazine article by Itzik Ben-Gan,
 where he develops the Relational Interval Tree model solution in T-SQL. 
 (http://sqlmag.com/t-sql/sql-server-interval-queries)

Four blog posts by Dejan Sarka that describe the four additional solutions for optimized interval queries: 
 Interval Queries in SQL Server Part 1 
 (http://blogs.solidq.com/dsarka/Post.aspx?ID=149&title=Interval+Queries+in+SQL+Server+Part+1)
 Interval Queries in SQL Server Part 2 
 (http://blogs.solidq.com/dsarka/Post.aspx?ID=150&title=Interval+Queries+in+SQL+Server+Part+2)
 Interval Queries in SQL Server Part 3 
 (http://blogs.solidq.com/dsarka/Post.aspx?ID=151&title=Interval+Queries+in+SQL+Server+Part+3)
 Interval Queries in SQL Server Part 4 
 (http://blogs.solidq.com/dsarka/Post.aspx?ID=152&title=Interval+Queries+in+SQL+Server+Part+4)

Connect feature proposal by Itzik Ben-Gan, suggesting intervals and interval indexes integration in SQL Server.
 In the Workarounds section, Dejan Sarka also added the links to these additional solutions. 
 (https://connect.microsoft.com/SQLServer/feedback/details/780746)
---------------------------------------------------------------------*/

---------------------------------------------------------------------
-- DB, Helper Function, Staging Data
---------------------------------------------------------------------

-- Code creating sample database, helper function and staging data

-- create sample database IntervalsDB
SET NOCOUNT ON;
USE master;
IF DB_ID('IntervalsDB') IS NOT NULL DROP DATABASE IntervalsDB;
CREATE DATABASE IntervalsDB;
GO
ALTER DATABASE IntervalsDB SET RECOVERY SIMPLE WITH NO_WAIT;
GO

USE IntervalsDB;
GO

-- create helper function dbo.GetNums
-- purpose: table function returning sequence of integers between inputs @low and @high
CREATE FUNCTION dbo.GetNums(@low AS BIGINT, @high AS BIGINT) RETURNS TABLE
AS
RETURN
  WITH
    L0   AS (SELECT c FROM (SELECT 1 UNION ALL SELECT 1) AS D(c)),
    L1   AS (SELECT 1 AS c FROM L0 AS A CROSS JOIN L0 AS B),
    L2   AS (SELECT 1 AS c FROM L1 AS A CROSS JOIN L1 AS B),
    L3   AS (SELECT 1 AS c FROM L2 AS A CROSS JOIN L2 AS B),
    L4   AS (SELECT 1 AS c FROM L3 AS A CROSS JOIN L3 AS B),
    L5   AS (SELECT 1 AS c FROM L4 AS A CROSS JOIN L4 AS B),
    Nums AS (SELECT ROW_NUMBER() OVER(ORDER BY (SELECT NULL)) AS rownum
            FROM L5)
  SELECT TOP(@high - @low + 1) @low + rownum - 1 AS n
  FROM Nums
  ORDER BY rownum;
GO

-- Create staging table dbo.Stage with 10,000,000 intervals
CREATE TABLE dbo.Stage
(
  id    INT NOT NULL,
  lower INT NOT NULL,
  upper INT NOT NULL,
  CONSTRAINT PK_Stage PRIMARY KEY(id),
  CONSTRAINT CHK_Stage_upper_gteq_lower CHECK(upper >= lower)
);
GO

DECLARE
  @numintervals AS INT = 10000000,
  @minlower     AS INT = 1,
  @maxupper     AS INT = 10000000,
  @maxdiff      AS INT = 20;

WITH C AS
(
  SELECT
    n AS id,
    @minlower + (ABS(CHECKSUM(NEWID())) % (@maxupper - @minlower - @maxdiff + 1)) AS lower,
    ABS(CHECKSUM(NEWID())) % (@maxdiff + 1) AS diff
  FROM dbo.GetNums(1, @numintervals) AS Nums
)
INSERT INTO dbo.Stage WITH(TABLOCK) (id, lower, upper)
  SELECT id, lower, lower + diff AS upper
  FROM C;

SELECT TOP 1000 *
FROM dbo.Stage;
SELECT COUNT(*)
FROM dbo.Stage;
GO

---------------------------------------------------------------------
-- Traditional Interval Representation
---------------------------------------------------------------------

-- Create and populate Intervals table
-- 73 seconds
CREATE TABLE dbo.Intervals
(
  id    INT NOT NULL,
  lower INT NOT NULL,
  upper INT NOT NULL,
  CONSTRAINT CHK_Intervals_upper_gteq_lower CHECK(upper >= lower)
);

INSERT INTO dbo.Intervals WITH(TABLOCK) (id, lower, upper)
  SELECT id, lower, upper
  FROM dbo.Stage;

ALTER TABLE dbo.Intervals ADD CONSTRAINT PK_Intervals PRIMARY KEY(id);

CREATE INDEX idx_lower ON dbo.Intervals(lower) INCLUDE(upper);
CREATE INDEX idx_upper ON dbo.Intervals(upper) INCLUDE(lower);
GO
-- 73 seconds up to here

SELECT TOP 1000 *
FROM dbo.Intervals;
SELECT COUNT(*), MIN(lower), MAX(upper)
FROM dbo.Intervals;
SELECT MAX(upper-lower)  -- 20 = max length
FROM dbo.Intervals;
GO

-- query
SET STATISTICS IO ON;
SET STATISTICS TIME ON;
GO

-- middle of data
-- logical reads: 11254, CPU time: 764 ms
DECLARE @l AS INT = 5000000, @u AS INT = 5000020;

SELECT id
FROM dbo.Intervals
WHERE lower <= @u AND upper >= @l
OPTION (RECOMPILE); -- used to allow variable sniffing and prevent plan reuse
GO
-- logical reads: 11254, CPU time: 764 ms

-- beginning of data
-- logical reads: 3, CPU time: 0 ms
DECLARE @l AS INT = 80, @u AS INT = 100;

SELECT id
FROM dbo.Intervals
WHERE lower <= @u AND upper >= @l
OPTION (RECOMPILE);
GO

-- end of data
-- logical reads: 3, CPU time: 0 ms
DECLARE @l AS INT = 10000000 - 100, @u AS INT = 10000000 - 80;

SELECT id
FROM dbo.Intervals
WHERE lower <= @u AND upper >= @l
OPTION (RECOMPILE);
GO

SET STATISTICS IO OFF;
SET STATISTICS TIME OFF;
GO

---------------------------------------------------------------------
-- Relational Interval Tree ([RI], [SRI1], [SRI2])
---------------------------------------------------------------------

-- Definition of forkNode function
CREATE FUNCTION dbo.forkNode(@lower AS INT, @upper AS INT) RETURNS INT
  WITH SCHEMABINDING
AS
BEGIN
  DECLARE @node AS INT = 1073741824; -- @node = 2^(h-1), h = height of tree, #values: 2^h - 1
  DECLARE @step AS INT = @node / 2;

  WHILE @step >= 1
  BEGIN
    IF @upper < @node
      SET @node -= @step;
    ELSE IF @lower > @node
      SET @node += @step;
    ELSE
      BREAK;
    SET @step /= 2;
  END;
  RETURN @node;
END;
GO

SELECT dbo.forkNode(110, 130);
GO

-- Create and populate IntervalsRIT table
-- 83 seconds
CREATE TABLE dbo.IntervalsRIT
(
  id    INT NOT NULL,
  node  AS upper - upper % POWER(2, FLOOR(LOG((lower - 1) ^ upper, 2))) PERSISTED NOT NULL,
  lower INT NOT NULL,
  upper INT NOT NULL,
  CONSTRAINT CHK_IntervalsRIT_upper_gteq_lower CHECK(upper >= lower)
);

INSERT INTO dbo.IntervalsRIT WITH(TABLOCK) (id, lower, upper)
  SELECT id, lower, upper
  FROM dbo.Stage;

ALTER TABLE dbo.IntervalsRIT ADD CONSTRAINT PK_IntervalsRIT PRIMARY KEY(id);
CREATE INDEX idx_lower ON dbo.IntervalsRIT(node, lower);
CREATE INDEX idx_upper ON dbo.IntervalsRIT(node, upper);
GO
-- 83 seconds up to here

SELECT TOP 1000 *
FROM dbo.IntervalsRIT
ORDER BY node;
SELECT COUNT(*)
FROM dbo.IntervalsRIT;
GO

-- Definitions of leftNodes and rightNodes functions

-- leftNodes function
CREATE FUNCTION dbo.leftNodes(@lower AS INT, @upper AS INT)
  RETURNS @T TABLE
  (
    node INT NOT NULL PRIMARY KEY
  )
AS
BEGIN
  DECLARE @node AS INT = 1073741824;
  DECLARE @step AS INT = @node / 2;

  -- descend from root node to lower
  WHILE @step >= 1
  BEGIN
    -- right node
    IF @lower < @node
      SET @node -= @step;
    -- left node
    ELSE IF @lower > @node
    BEGIN
      INSERT INTO @T(node) VALUES(@node);
      SET @node += @step;
    END
    -- lower
    ELSE
      BREAK;
    SET @step /= 2;
  END;

  RETURN;
END;
GO

-- rightNodes function
CREATE FUNCTION dbo.rightNodes(@lower AS INT, @upper AS INT)
  RETURNS @T TABLE
  (
    node INT NOT NULL PRIMARY KEY
  )
AS
BEGIN
  DECLARE @node AS INT = 1073741824;
  DECLARE @step AS INT = @node / 2;

  -- descend from root node to upper
  WHILE @step >= 1
  BEGIN
    -- left node
    IF @upper > @node
      SET @node += @step
    -- right node
    ELSE IF @upper < @node
    BEGIN
      INSERT INTO @T(node) VALUES(@node);
      SET @node -= @step
    END
    -- upper
    ELSE
      BREAK;
    SET @step /= 2;
  END;

  RETURN;
END;
GO

-- Test
DECLARE @l AS INT = 1000000, @u AS INT = 6000100;
--SELECT * FROM dbo.leftNodes(@l, @u);
SELECT * FROM dbo.rightNodes(@l, @u);
SELECT I.id, I.lower, I.upper, I.node
FROM dbo.IntervalsRIT AS I
  JOIN dbo.rightNodes(@l, @u) AS L
    ON I.node = L.node
    AND I.upper >= @l;
GO


-- Intersection query
SET STATISTICS IO ON;
SET STATISTICS TIME ON;
GO

-- logical reads: 81 (IntervalsRIT) + 2 (@T - leftNodes) + 2 (@T - rightNodes), CPU time: 16 ms
DECLARE @l AS INT = 5000000, @u AS INT = 5000020;

SELECT I.id
FROM dbo.IntervalsRIT AS I
  JOIN dbo.leftNodes(@l, @u) AS L
    ON I.node = L.node
    AND I.upper >= @l

UNION ALL

SELECT I.id
FROM dbo.IntervalsRIT AS I
  JOIN dbo.rightNodes(@l, @u) AS R
    ON I.node = R.node
    AND I.lower <= @u

UNION ALL

SELECT id
FROM dbo.IntervalsRIT
WHERE node BETWEEN @l AND @u

OPTION (RECOMPILE);
GO

SET STATISTICS IO OFF;
SET STATISTICS TIME OFF;
GO

---------------------------------------------------------------------
-- Traditional Interval Presentation with Length
---------------------------------------------------------------------

-- Create and populate IntervalsL table
-- 73 seconds
CREATE TABLE dbo.IntervalsL
(
  id    INT NOT NULL,
  lower INT NOT NULL,
  upper INT NOT NULL,
  ilen  AS upper - lower PERSISTED,
  CONSTRAINT CHK_IntervalsL_upper_gteq_lower CHECK(upper >= lower)
);

INSERT INTO dbo.IntervalsL WITH(TABLOCK) (id, lower, upper)
  SELECT id, lower, upper
  FROM dbo.Stage;

ALTER TABLE dbo.IntervalsL ADD CONSTRAINT PK_IntervalsL PRIMARY KEY(id);

CREATE INDEX idx_lowerL ON dbo.IntervalsL(lower) INCLUDE(upper);
CREATE INDEX idx_upperL ON dbo.IntervalsL(upper) INCLUDE(lower);
CREATE INDEX ids_ilenL ON dbo.IntervalsL(ilen);
GO
-- 73 seconds up to here

SELECT TOP 1000 *
FROM dbo.IntervalsL;
SELECT COUNT(*), MIN(lower), MAX(upper)
FROM dbo.Intervals;
SELECT MAX(ilen)  -- 20 = max length
FROM dbo.IntervalsL;
GO

-- query
SET STATISTICS IO ON;
SET STATISTICS TIME ON;
GO

-- middle of data
-- logical reads: 6 (3 + 3 to calculate the max length), CPU time: 0 ms
DECLARE @l AS INT = 5000000, @u AS INT = 5000020;

DECLARE @max AS INT;
SET @max = 
 (SELECT MAX(ilen) AS maxlen FROM
  (SELECT MAX(ilen) AS ilen FROM dbo.IntervalsL
   UNION
   SELECT @u - @l) AS m1
 );

SELECT id
FROM dbo.Intervals
WHERE lower <= @u AND lower >= @l - @max
  AND upper >= @l AND upper <= @u + @max
OPTION (RECOMPILE);
GO
-- logical reads: 6 (3 + 3 to calculate the max length), CPU time: 0 ms

-- Check with longer maximal interval
DECLARE @l AS INT = 5000000, @u AS INT = 5000020;

DECLARE @max AS INT = 100000;

SELECT id
FROM dbo.Intervals
WHERE lower <= @u AND lower >= @l - @max
  AND upper >= @l AND upper <= @u + @max
OPTION (RECOMPILE);
GO
-- logical reads: 228, CPU time: 0 ms

-- beginning of data
-- logical reads: 6, CPU time: 0 ms
DECLARE @l AS INT = 80, @u AS INT = 100;

DECLARE @max AS INT;
SET @max = 
 (SELECT MAX(ilen) AS maxlen FROM
  (SELECT MAX(ilen) AS ilen FROM dbo.IntervalsL
   UNION
   SELECT @u - @l) AS m1
 );

SELECT id
FROM dbo.Intervals
WHERE lower <= @u AND lower >= @l - @max
  AND upper >= @l AND upper <= @u + @max
OPTION (RECOMPILE);
GO


-- end of data
-- logical reads: 6, CPU time: 0 ms
DECLARE @l AS INT = 10000000 - 100, @u AS INT = 10000000 - 80;

DECLARE @max AS INT;
SET @max = 
 (SELECT MAX(ilen) AS maxlen FROM
  (SELECT MAX(ilen) AS ilen FROM dbo.IntervalsL
   UNION
   SELECT @u - @l) AS m1
 );

SELECT id
FROM dbo.Intervals
WHERE lower <= @u AND lower >= @l - @max
  AND upper >= @l AND upper <= @u + @max
OPTION (RECOMPILE);
GO

SET STATISTICS IO OFF;
SET STATISTICS TIME OFF;
GO

---------------------------------------------------------------------
-- Intervals Geometry Data Type Presentation
---------------------------------------------------------------------

SET NOCOUNT ON;
GO

CREATE TABLE dbo.IntervalsSP
(
	id INT NOT NULL,
	segment geometry NOT NULL
);

-- SLOW! (20+ min!)
INSERT INTO dbo.IntervalsSP WITH(TABLOCK) (id, segment)
  SELECT 
	id,
	segment = 
		CASE WHEN lower != upper then
			geometry::STGeomFromText('LINESTRING
			 (' + CAST(lower AS VARCHAR(50)) + ' 0, ' + 
			      CAST(upper AS VARCHAR(50)) + ' 0)', 0) 
		ELSE 
			geometry::STGeomFromText('POINT
			 (' + CAST(lower AS VARCHAR(50)) + ' 0)', 0)
		END
  FROM dbo.Stage;
GO

-- ~ 1 min
ALTER TABLE dbo.IntervalsSP ADD CONSTRAINT PK_IntervalsSP PRIMARY KEY(id);
GO

-- ~ 3 min
CREATE SPATIAL INDEX ixs_1
 ON dbo.IntervalsSP (segment) 
 USING GEOMETRY_AUTO_GRID
 WITH (BOUNDING_BOX = (0, 0, 10000000,1));
GO

-- query
SET STATISTICS IO ON
SET STATISTICS TIME ON
GO

-- middle of data
SELECT id 
FROM dbo.IntervalsSP 
WHERE segment.STIntersects
 (geometry::STGeomFromText('LINESTRING (5000000 0, 5000020 0)', 0)) = 1
ORDER BY id;
-- logical reads: 396 (284 table + 112 index), CPU time: 16 ms

-- beginning of data
SELECT id 
FROM dbo.IntervalsSP 
WHERE segment.STIntersects
 (geometry::STGeomFromText('LINESTRING (80 0, 100 0)', 0)) = 1
ORDER BY id;
-- logical reads: 267 (211 table + 56 index), CPU time: 16 ms


-- end of data
SELECT id 
FROM dbo.IntervalsSP 
WHERE segment.STIntersects
(geometry::STGeomFromText('LINESTRING (9999900 0, 9999920 0)', 0)) = 1
ORDER BY id;
-- logical reads: 208 (152 table + 56 index), CPU time: 16 ms
GO

SET STATISTICS IO OFF
SET STATISTICS TIME OFF
GO

---------------------------------------------------------------------
-- Intervals Unpacked Form
---------------------------------------------------------------------

-- Create and populate Intervals table

-- Numbers table
-- Auxiliary table of numbers
-- Need a table, not a function
-- Must use JOIN and not APPLY for an indexed view
SET NOCOUNT ON;

IF OBJECT_ID('dbo.Nums', 'U') IS NOT NULL DROP TABLE dbo.Nums;
CREATE TABLE dbo.Nums
 (n INT NOT NULL PRIMARY KEY);
GO

DECLARE @max AS INT, @rc AS INT, @d AS DATE;
SET @max = 10000000;
SET @rc = 1;

INSERT INTO dbo.Nums VALUES(1);
WHILE @rc * 2 <= @max
BEGIN
  INSERT INTO dbo.Nums 
  SELECT n + @rc FROM dbo.Nums;
  SET @rc = @rc * 2;
END

INSERT INTO dbo.Nums
  SELECT n + @rc
  FROM dbo.Nums 
  WHERE n + @rc <= @max;
GO

-- Check data
SELECT * FROM dbo.Nums
GO

-- Create and populate IntervalsU table
CREATE TABLE dbo.IntervalsU
(
  id    INT NOT NULL,
  lower INT NOT NULL,
  upper INT NOT NULL,
  CONSTRAINT CHK_IntervalsU_upper_gteq_lower CHECK(upper >= lower)
);
GO

ALTER TABLE dbo.IntervalsU ADD CONSTRAINT PK_IntervalsU PRIMARY KEY(id);
GO

-- Create view Intervals_Unpacked
IF OBJECT_ID('dbo.Intervals_Unpacked', 'V') IS NOT NULL
   DROP VIEW dbo.Intervals_Unpacked;
GO
CREATE VIEW dbo.Intervals_Unpacked
WITH SCHEMABINDING
AS
SELECT i.id, n.n
FROM dbo.IntervalsU AS i
 INNER JOIN dbo.Nums AS n
  ON n.n BETWEEN i.lower AND i.upper;
GO
-- Index the view
CREATE UNIQUE CLUSTERED INDEX PK_Intervals_Unpacked
 ON dbo.Intervals_Unpacked(n, id);
GO

-- Insert the data
-- SLOW! (17+ min!)
INSERT INTO dbo.IntervalsU WITH(TABLOCK) (id, lower, upper)
  SELECT id, lower, upper
  FROM dbo.Stage;
GO

SELECT TOP 1000 *
FROM dbo.Intervals_Unpacked;
SELECT COUNT(*)
FROM dbo.Intervals_Unpacked;
-- 109982796 rows
GO

-- query
SET STATISTICS IO ON;
SET STATISTICS TIME ON;
GO

-- middle of data
DECLARE @l AS INT = 5000000, @u AS INT = 5000020;
DECLARE @t AS TABLE(id INT);
INSERT INTO @t(id)
SELECT id
FROM dbo.Intervals_Unpacked
WHERE n BETWEEN @l AND @u;
SELECT DISTINCT id
FROM @t;
-- logical reads: 6 (5 + 1 from the table variable), CPU time: 0 ms
GO

-- Checking also beginning of data
-- logical reads: 7, CPU time: 0 ms
DECLARE @l AS INT = 80, @u AS INT = 100;
DECLARE @t AS TABLE(id INT);
INSERT INTO @t(id)
SELECT id
FROM dbo.Intervals_Unpacked
WHERE n BETWEEN @l AND @u;
SELECT DISTINCT id
FROM @t
GO

-- end of data
-- logical reads: 6, CPU time: 0 ms
DECLARE @l AS INT = 10000000 - 100, @u AS INT = 10000000 - 80;
DECLARE @t AS TABLE(id INT);
INSERT INTO @t(id)
SELECT id
FROM dbo.Intervals_Unpacked
WHERE n BETWEEN @l AND @u;
SELECT DISTINCT id
FROM @t
GO   

SET STATISTICS IO OFF;
SET STATISTICS TIME OFF;
GO

-- Table with intervals unpacked
-- Listing 2: Create and populate Intervals_Unpacked_Table table
-- With row compression
CREATE TABLE dbo.Intervals_Unpacked_Table
(
  id    INT NOT NULL,
  n     INT NOT NULL
)
WITH (DATA_COMPRESSION = ROW);
GO

ALTER TABLE dbo.Intervals_Unpacked_Table
 ADD CONSTRAINT PK_Intervals_Unpacked_Table PRIMARY KEY(n, id);
GO

-- 4 min with row compression
INSERT INTO dbo.Intervals_Unpacked_Table WITH(TABLOCK) (id, n)
SELECT id, n
FROM dbo.Intervals
 CROSS APPLY dbo.GetNums(lower, upper);
GO

-- Check the space used 
EXEC sys.sp_spaceused N'dbo.Intervals', TRUE;
EXEC sys.sp_spaceused N'dbo.Intervals_Unpacked', TRUE;
EXEC sys.sp_spaceused N'dbo.Intervals_Unpacked_Table', TRUE;
GO
-- Original table reserverd:				 566424 KB
-- Indexed view reserved:					1857808 KB
-- Table with row compressions reserved:	1234000 KB

-- Use page compression
-- 2 min
ALTER TABLE dbo.Intervals_Unpacked_Table 
 REBUILD WITH (DATA_COMPRESSION = PAGE);
GO

-- Check the space used 
EXEC sys.sp_spaceused N'dbo.Intervals_Unpacked_Table', TRUE;
GO
-- Table with page compressions reserved:	1229136 KB

-- query
SET STATISTICS IO ON;
SET STATISTICS TIME ON;
GO

-- middle of data
DECLARE @l AS INT = 5000000, @u AS INT = 5000020;
SELECT DISTINCT id
FROM dbo.Intervals_Unpacked_Table
WHERE n BETWEEN @l AND @u;
GO
-- logical reads: 7, CPU time: 0 ms

-- Checking also beginning of data
-- logical reads: 6, CPU time: 0 ms
DECLARE @l AS INT = 80, @u AS INT = 100;
SELECT DISTINCT id
FROM dbo.Intervals_Unpacked_Table
WHERE n BETWEEN @l AND @u;
GO

-- end of data
-- logical reads: 6, CPU time: 0 ms
DECLARE @l AS INT = 10000000 - 100, @u AS INT = 10000000 - 80;
SELECT DISTINCT id
FROM dbo.Intervals_Unpacked_Table
WHERE n BETWEEN @l AND @u;
GO   

SET STATISTICS IO OFF;
SET STATISTICS TIME OFF;
GO


---------------------------------------------------------------------
-- IntervalCID Representation
---------------------------------------------------------------------

-- IntervalCID C# code
/*
using System;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using Microsoft.SqlServer.Server;
using System.Text.RegularExpressions;
using System.Globalization;

[Serializable]
[Microsoft.SqlServer.Server.SqlUserDefinedType(
    Format.Native,
    IsByteOrdered = true,
    ValidationMethodName = "ValidateIntervalCID")]
public struct IntervalCID : INullable
{
    //Regular expression used to parse values of the form (intBegin,intEnd)
    private static readonly Regex _parser
        = new Regex
		  (@"\A\(\s*(?<intBegin>\-?\d+?)\s*:\s*(?<intEnd>\-?\d+?)\s*\)\Z",
           RegexOptions.Compiled | RegexOptions.ExplicitCapture);

    // Begin, end of interval
    private Int32 _begin;
    private Int32 _end;

    // Internal member to show whether the value is null
    private bool _isnull;

    // Null value returned equal for all instances
    private const string NULL = "<<null interval>>";
    private static readonly IntervalCID NULL_INSTANCE
       = new IntervalCID(true);

    // Constructor for a known value
    public IntervalCID(Int32 begin, Int32 end)
    {
        this._begin = begin;
        this._end = end;
        this._isnull = false;
    }

    // Constructor for an unknown value
    private IntervalCID(bool isnull)
    {
        this._isnull = isnull;
        this._begin = this._end = 0;
    }

    // Default string representation
    public override string ToString()
    {
        return this._isnull ? NULL : ("("
            + this._begin.ToString(CultureInfo.InvariantCulture) + ":"
            + this._end.ToString(CultureInfo.InvariantCulture)
            + ")");
    }

    // Null handling
    public bool IsNull
    {
        get
        {
            return this._isnull;
        }
    }

    public static IntervalCID Null
    {
        get
        {
            return NULL_INSTANCE;
        }
    }

    // Parsing input using regular expression
    public static IntervalCID Parse(SqlString sqlString)
    {
        string value = sqlString.ToString();

        if (sqlString.IsNull || value == NULL)
            return new IntervalCID(true);

        // Check whether the input value matches the regex pattern
        Match m = _parser.Match(value);

        // If the input�s format is incorrect, throw an exception
        if (!m.Success)
            throw new ArgumentException(
                "Invalid format for complex number. "
                + "Format is (intBegin:intEnd).");

        // If everything is OK, parse the value; 
        // we will get two Int32 type values
        IntervalCID it = new IntervalCID(Int32.Parse(m.Groups[1].Value,
            CultureInfo.InvariantCulture), Int32.Parse(m.Groups[2].Value,
            CultureInfo.InvariantCulture));
        if (!it.ValidateIntervalCID())
            throw new ArgumentException("Invalid begin and end values.");

        return it;
    }

    // Begin and end separately
    public Int32 BeginInt
    {
        [SqlMethod(IsDeterministic = true, IsPrecise = true)]
        get
        {
            return this._begin;
        }
        set
        {
            Int32 temp = _begin;
            _begin = value;
            if (!ValidateIntervalCID())
            {
                _begin = temp;
                throw new ArgumentException("Invalid begin value.");
            }

        }
    }

    public Int32 EndInt
    {
        [SqlMethod(IsDeterministic = true, IsPrecise = true)]
        get
        {
            return this._end;
        }
        set
        {
            Int32 temp = _end;
            _end = value;
            if (!ValidateIntervalCID())
            {
                _end = temp;
                throw new ArgumentException("Invalid end value.");
            }

        }
    }

    // Validation method
    private bool ValidateIntervalCID()
    {
        if (_end >= _begin)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    // Allen's operators

    public bool Equals(IntervalCID target)
    {
        return ((this._begin == target._begin) &
		 (this._end == target._end));
    }

    public bool Before(IntervalCID target)
    {
        return (this._end < target._begin);
    }

    public bool After(IntervalCID target)
    {
        return (this._begin > target._end);
    }

    public bool Includes(IntervalCID target)
    {
        return ((this._begin <= target._begin) &
		 (this._end >= target._end));
    }

    public bool ProperlyIncludes(IntervalCID target)
    {
        return ((this._begin < target._begin) &
		 (this._end > target._end));
    }

    public bool Meets(IntervalCID target)
    {
        return ((this._end + 1 == target._begin) |
		 (this._begin == target._end + 1));
    }

    public bool Overlaps(IntervalCID target)
    {
        return ((this._begin <= target._end) &
		 (target._begin <= this._end));
    }

    public bool Merges(IntervalCID target)
    {
        return (this.Meets(target) |
		 this.Overlaps(target));
    }

    public bool Begins(IntervalCID target)
    {
        return ((this._begin == target._begin) &
		 (this._end <= target._end));
    }

    public bool Ends(IntervalCID target)
    {
        return ((this._begin >= target._begin) &
		 (this._end == target._end));
    }

    public IntervalCID Union(IntervalCID target)
    {
        if (this.Merges(target))
            return new IntervalCID(
			 System.Math.Min(this.BeginInt, target.BeginInt),
             System.Math.Max(this.EndInt, target.EndInt));
        else
            return new IntervalCID(true);
    }

    public IntervalCID Intersect(IntervalCID target)
    {
        if (this.Merges(target))
            return new IntervalCID(
			 System.Math.Max(this.BeginInt, target.BeginInt),
             System.Math.Min(this.EndInt, target.EndInt));
        else
            return new IntervalCID(true);
    }

    public IntervalCID Minus(IntervalCID target)
    {
        if (this.Merges(target) &
		 (this.BeginInt < target.BeginInt) & 
		 (this.EndInt <= target.EndInt))
            return new IntervalCID(
			 this.BeginInt, 
			 System.Math.Min(target.BeginInt - 1, this.EndInt));
        else
            if (this.Merges(target) &
			 (this.BeginInt >= target.BeginInt) & 
			 (this.EndInt > target.EndInt))
                return new IntervalCID(
				 System.Math.Max(target.EndInt + 1, this.BeginInt), 
				 this.EndInt);
            else
                return new IntervalCID(true);
    }
}
*/

-- Enable CLR
USE master; 
EXEC sp_configure 'clr enabled', 1; 
RECONFIGURE; 
GO 
USE IntervalsDB;
GO

-- Deploy assembly
-- Replace the path with your path to the .dll file
CREATE ASSEMBLY IntervalCID
FROM 'C:\Temp\IntervalCID.dll' 
WITH PERMISSION_SET = SAFE;
GO
-- Type
CREATE TYPE dbo.IntervalCID 
EXTERNAL NAME IntervalCID.IntervalCID;
GO

-- Listing x: Create and populate IntervalsCID table
CREATE TABLE dbo.IntervalsCID
(
  id     INT NOT NULL,
  during IntervalCID NOT NULL
);

INSERT INTO dbo.IntervalsCID WITH(TABLOCK) (id, during)
  SELECT id, N'(' + CAST(lower AS NVARCHAR(10)) +':' +
   CAST(upper AS NVARCHAR(10)) + ')'
  FROM dbo.Stage;

ALTER TABLE dbo.IntervalsCID ADD CONSTRAINT
 PK_IntervalsCID PRIMARY KEY(id);

CREATE INDEX idx_IntervalCID ON dbo.IntervalsCID(during);
GO
-- 80 seconds up to here
-- Slightly slower insert - please note that the insert code is not optimized for IntervalCID
-- Anyway, not important

SELECT TOP 1000 *, during.ToString()
FROM dbo.IntervalsCID
ORDER BY during DESC;
SELECT COUNT(*), MIN(during.BeginInt), MAX(during.EndInt)
FROM dbo.IntervalsCID;
GO

-- query
SET STATISTICS IO ON;
SET STATISTICS TIME ON;
GO

-- middle of data - naive solution
DECLARE @l AS INT = 5000000, @u AS INT = 5000020;
DECLARE @i AS IntervalCID;
-- An interval to filter exactly the intervals needed,
-- the ones that really overlap with the given one
SET @i = N'(' + CAST(@l AS NVARCHAR(10)) +':'
 + CAST(@u AS NVARCHAR(10)) + ')';

SELECT id
FROM dbo.IntervalsCID AS I
WHERE @i.Overlaps(I.during) = 1
OPTION (RECOMPILE);   
GO
-- logical reads: 23722, CPU time: 16973 ms

-- middle of data - optimized solution
DECLARE @l AS INT = 5000000, @u AS INT = 5000020;
DECLARE @max AS INT = 20;   -- max length in the data is 20
DECLARE @b AS IntervalCID, @e AS IntervalCID, @i AS IntervalCID;
-- An interval whose sort value is low enough to filter out
-- the intervals before the given one
SET @b = N'(' + CAST((@l - 1 - @max) AS NVARCHAR(10)) + ':'
 + CAST((@l-1) AS NVARCHAR(10)) + ')';
-- An interval whose sort value is high enough to filter out
-- the intervals after the given one
SET @e = N'(' + CAST((@u+1) AS NVARCHAR(10)) + ':'
 + CAST((@u +1) AS NVARCHAR(10)) + ')';
-- An interval to filter exactly the intervals needed,
-- the ones that really overlap with the given one
SET @i = N'(' + CAST(@l AS NVARCHAR(10)) +':'
 + CAST(@u AS NVARCHAR(10)) + ')';

SELECT id
FROM dbo.IntervalsCID AS I
WHERE during < @e AND during > @b
  AND @i.Overlaps(I.during) = 1
OPTION (RECOMPILE);   
GO
-- logical reads: 4, CPU time: 0 ms

-- Checking also beginning of data
-- logical reads: 3, CPU time: 0 ms
DECLARE @l AS INT = 80, @u AS INT = 100;
DECLARE @max AS INT = 20;   -- max length in the data is 20
DECLARE @b AS IntervalCID, @e AS IntervalCID, @i AS IntervalCID;
-- An interval whose sort value is low enough to filter out the intervals before the given one
SET @b = N'(' + CAST((@l - 1 - @max) AS NVARCHAR(8)) +':' + CAST((@l-1) AS NVARCHAR(8)) + ')';
-- An interval whose sort value is high enough to filter out the intervals after the given one
SET @e = N'(' + CAST((@u+1) AS NVARCHAR(8)) +':' + CAST((@u +1) AS NVARCHAR(8)) + ')';
-- An interval to filter excatly the intervals needed, the ones that really ovelap with the given one
SET @i = N'(' + CAST(@l AS NVARCHAR(8)) +':' + CAST(@u AS NVARCHAR(8)) + ')';

SELECT id--, during, during.ToString(), @b, @b.ToString(), @e, @e.ToString()
FROM dbo.IntervalsCID AS I
WHERE during < @e AND during > @b
  AND @i.Overlaps(I.during) = 1
OPTION (RECOMPILE);
GO

-- end of data
-- logical reads: 3, CPU time: 0 ms
DECLARE @l AS INT = 10000000 - 100, @u AS INT = 10000000 - 80;
DECLARE @max AS INT = 20;   -- max length in the data is 20
DECLARE @b AS IntervalCID, @e AS IntervalCID, @i AS IntervalCID;
-- An interval whose sort value is low enough to filter out the intervals before the given one
SET @b = N'(' + CAST((@l - 1 - @max) AS NVARCHAR(8)) +':' + CAST((@l-1) AS NVARCHAR(8)) + ')';
-- An interval whose sort value is high enough to filter out the intervals after the given one
SET @e = N'(' + CAST((@u+1) AS NVARCHAR(8)) +':' + CAST((@u +1) AS NVARCHAR(8)) + ')';
-- An interval to filter excatly the intervals needed, the ones that really ovelap with the given one
SET @i = N'(' + CAST(@l AS NVARCHAR(8)) +':' + CAST(@u AS NVARCHAR(8)) + ')';

SELECT id
FROM dbo.IntervalsCID AS I
WHERE during < @e AND during > @b
  AND @i.Overlaps(I.during) = 1
OPTION (RECOMPILE);
GO

-- Note: all of these queries filter efficiently the right side
-- and less efficiently the left side if the maximum length of the intervals is substantially larger.
-- For example, test with @max = 10000000 - the query that queries the end of the data scans the complete table.
-- This is because there is only one index on the type as a whole in order left, right.
-- Also, the calculation of the maximum interval length value is simplified down to using a constant.
-- To catch up with the T-SQL solution, the BeginInd and EndInt properties should be persisted and indexed
-- and then used like the lower and upper columns in the T-SQL solution.

SET STATISTICS IO OFF;
SET STATISTICS TIME OFF;
GO

-- Listing x: Create and populate IntervalsCID table with additional persisted calculated columns
DROP TABLE dbo.IntervalsCID;
GO

CREATE TABLE dbo.IntervalsCID
(
  id     INT NOT NULL,
  during IntervalCID NOT NULL,
  lower AS during.BeginInt PERSISTED,
  upper AS during.EndInt PERSISTED,
  ilen  AS during.EndInt - during.BeginInt PERSISTED,
  node  AS during.EndInt - during.EndInt %
   POWER(2, FLOOR(LOG((during.BeginInt - 1) ^ during.EndInt, 2))) 
   PERSISTED
);

INSERT INTO dbo.IntervalsCID WITH(TABLOCK) (id, during)
  SELECT id, N'(' + CAST(lower AS NVARCHAR(10)) +':' +
   CAST(upper AS NVARCHAR(10)) + ')'
  FROM dbo.Stage;

ALTER TABLE dbo.IntervalsCID ADD CONSTRAINT
 PK_IntervalsCID PRIMARY KEY(id);

CREATE INDEX idx_IntervalCID ON dbo.IntervalsCID(during);
-- Create any other indexes you need
GO
-- 100+ seconds up to here

SELECT TOP 1000 *, during.ToString()
FROM dbo.IntervalsCID
ORDER BY during DESC;
SELECT COUNT(*), MIN(during.BeginInt), MAX(during.EndInt)
FROM dbo.IntervalsCID;
GO

---------------------------------------------------------------------
-- Interval XML Representation
---------------------------------------------------------------------

SELECT TOP 1000 id, lower, upper,
 CAST(N'<intervalXML lower="' + CAST(lower AS NVARCHAR(10)) +
      N'" upper="' + CAST(upper AS NVARCHAR(10)) + N'" />' AS XML)
FROM dbo.Stage;

-- Create and populate IntervalsXML table
-- SLOW! 18 min
CREATE TABLE dbo.IntervalsXML
(
  id          INT NOT NULL,
  IntervalXML XML NOT NULL
);

ALTER TABLE dbo.IntervalsXML ADD CONSTRAINT PK_IntervalsXML PRIMARY KEY(id);
CREATE PRIMARY XML INDEX PXML_IntervalsXML
 ON dbo.IntervalsXML (IntervalXML);
CREATE XML INDEX IXML_IntervalsXML_Property 
 ON dbo.IntervalsXML (IntervalXML)
 USING XML INDEX PXML_IntervalsXML FOR PROPERTY;

INSERT INTO dbo.IntervalsXML WITH(TABLOCK) (id, IntervalXML)
	SELECT id,
	 CAST(N'<intervalXML lower="' + CAST(lower AS NVARCHAR(10)) +
		  N'" upper="' + CAST(upper AS NVARCHAR(10)) + N'" />' AS XML)
	FROM dbo.Stage;
GO
-- SLOW! 18 min

SELECT TOP 1000 *
FROM dbo.IntervalsXML;
SELECT COUNT(*), MIN(lower), MAX(upper)
FROM dbo.Intervals;
SELECT MAX(upper-lower)  -- 20 = max length
FROM dbo.Intervals;
GO

-- Check the space used 
EXEC sys.sp_spaceused N'dbo.Intervals', TRUE;
-- reserved, data, index:   566,424 KB;   207,816 KB;   357,600 KB
EXEC sys.sp_spaceused N'dbo.IntervalsXML', TRUE;
-- reserved, data, index: 4,670,192 KB; 1,212,120 KB; 3,456,984 KB
GO

-- query
SET STATISTICS IO ON;
SET STATISTICS TIME ON;
GO

-- middle of data
-- !!! INCREDIBLY INEFFICIENT !!!
DECLARE @l AS INT = 5000000, @u AS INT = 5000020;

SELECT id 
FROM dbo.IntervalsXML
WHERE IntervalXML.value('(/intervalXML/@lower)[1]', 'INT') <= @u
  AND IntervalXML.value('(/intervalXML/@upper)[1]', 'INT') >= @l;
GO
-- logical reads: 77,916,198, CPU time: 527,968 ms

-- Different predicate (by Matija Lah)
DECLARE @l AS INT = 5000000, @u AS INT = 5000020;

SELECT id 
FROM dbo.IntervalsXML
WHERE IntervalXML.exist('/intervalXML[@lower <= sql:variable("@u")
                         and @upper >= sql:variable("@l")]') = 1;
GO
-- logical reads: 706,223, CPU time: 101,517 ms

-- Trying with a selective XML index (by Matija Lah)
-- Drop regular XML indexes
DROP INDEX IXML_IntervalsXML_Property 
 ON dbo.IntervalsXML;
DROP INDEX PXML_IntervalsXML
 ON dbo.IntervalsXML;
GO
-- Enabling selective XML indexes
EXEC sys.sp_db_selective_xml_index
  @dbname = 'IntervalsDB'
  ,@selective_xml_index = 'on'
GO
-- Creating the selective XML indexes
CREATE SELECTIVE XML INDEX SXX_IntervalsXML
ON dbo.IntervalsXML
(
IntervalXML
)
for (
  interval = '/intervalXML' as xquery 'node()',
  interval_lower = '/intervalXML/@lower' as xquery 'xs:double' singleton,
  interval_upper = '/intervalXML/@upper' as xquery 'xs:double' singleton
);
GO
-- 4:13
CREATE XML INDEX FXX_IntervalsXML_interval_lower
 ON dbo.IntervalsXML
  (
  IntervalXML
  )
 USING XML INDEX SXX_IntervalsXML
 FOR (
  interval_lower
  );
GO
-- 0:13
CREATE XML INDEX FXX_IntervalsXML_interval_upper
 ON dbo.IntervalsXML
  (
  IntervalXML
  )
 USING XML INDEX SXX_IntervalsXML
 FOR (
  interval_upper
  );
GO
-- 5 min

-- middle of data
DECLARE @l AS INT = 5000000, @u AS INT = 5000020;

SELECT id 
FROM dbo.IntervalsXML
WHERE IntervalXML.exist('/intervalXML[@lower <= sql:variable("@u")
                         and @upper >= sql:variable("@l")]') = 1;
GO
-- logical reads: 85,079, CPU time: 26,624 ms

SET STATISTICS IO OFF;
SET STATISTICS TIME OFF;
GO

