﻿param
(
  $ServerName,
  $DatabaseName
)
$exitCode = 0;

try
{
  . $PSScriptRoot\Process-AvailabilityGroupFailoverTasks.ps1
  . $PSScriptRoot\Move-AvailabilityGroup.ps1

  Process-AvailabilityGroupFailoverTasks -DatabaseName $DatabaseName -ServerName $ServerName;
}
catch
{
  Write-Error $_.Exception.Message;
  $exitCode = 256;
}

exit $exitCode;

