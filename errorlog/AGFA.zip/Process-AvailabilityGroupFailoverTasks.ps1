﻿<#
.SYNOPSIS
   This function retrieves failover tasks from the database and processes them.
.DESCRIPTION
   As part of the AlwaysOn Availability Group Failover Automation framework, this 
   function retrieves any unprocessed tasks from the specified database and then processes them.
.PARAMETER ServerName
   The name of the database server where the tasks table resides.
.PARAMETER DatabaseName
   The name of the database where the tasks table resides.
.NOTES
   This code is copyright 2015 Joshua Feierman (josh@sqljosh.com). 
  
   To sign up for updates, please visit this page: http://bit.ly/sqljosh.
  
  License:
  The availability group failover automation framework is free to download and use for personal, educational, and internal
  purposes, provided this license and all original attributions are included.
  Redistribution or sale in whole or in part is prohibited without the author's 
  express written consent.

  By installing or using this framework you agree to accept any and all risk associated with its use. The author is not liable
  for any damages or other consequences of using this framework. Please always test in a non-production system.
#>
function Process-AvailabilityGroupFailoverTasks
{
  [cmdletbinding()]
  param
  (
    [parameter(mandatory=$true)]
    $ServerName,
    [parameter(mandatory=$true)]
    $DatabaseName,
    [parameter(mandatory=$false)]
    [System.Management.Automation.PSCredential]$Credential
    
  )
  
  Set-StrictMode -Version 2.0;
  
  [System.Data.SqlClient.SqlConnection]$sqlConn = $null;
  [System.Data.SqlClient.SqlCommand]$sqlCmd = $null;
  [System.Data.SqlClient.SqlDataReader]$sqlReader = $null;
  [string]$sqlGetUnprocessedTasks = @"
  SELECT t.AvailabilityGroupFailoverTaskID,
         t.AvailabilityGroupName,
         t.PrimaryServerName
    FROM dbo.AvailabilityGroupFailoverTask t
   WHERE GETUTCDATE() BETWEEN t.FailoverWindowStartTime AND t.FailoverWindowEndTime
         AND t.ProcessedFl = 0;
"@;
  [string]$sqlUpdateTask = @"
  UPDATE dbo.AvailabilityGroupFailoverTask
  SET
      dbo.AvailabilityGroupFailoverTask.StatusText = @StatusText,
      dbo.AvailabilityGroupFailoverTask.ProcessedFl = @ProcessedFl
  WHERE
      dbo.AvailabilityGroupFailoverTask.AvailabilityGroupFailoverTaskID = @AvailabilityGroupFailoverTaskID;
"@;
  $tasksToProcess = @();
  $returnCode = 0;
  $Identity = $null;
  $Context = $null;
  $allResults = @();

  try
  {
    
    #Begin section for impersonation if a Credential is specified
    #Based on scripts by Joel Bennett, at http://poshcode.org/1867
    if ($Credential -ne $null)
    {
      # Import a type for the advapi functions
      $Impersonator = Add-Type -Namespace DISS -Name Impersonator -MemberDefinition @"
         // http://msdn.microsoft.com/en-us/library/aa378184.aspx
         [DllImport("advapi32.dll", SetLastError = true)]
         public static extern bool LogonUser(string lpszUsername, string lpszDomain, string lpszPassword, int dwLogonType, int dwLogonProvider, ref IntPtr phToken);

         // http://msdn.microsoft.com/en-us/library/aa379317.aspx
         [DllImport("advapi32.dll", SetLastError=true)]
         public static extern bool RevertToSelf();
"@ -passthru
      
      [IntPtr]$UserToken = [Security.Principal.WindowsIdentity]::GetCurrent().Token;
      
      if(!$Impersonator::LogonUser( 
            $Credential.GetNetworkCredential().UserName, 
            $Credential.GetNetworkCredential().Domain, 
            $Credential.GetNetworkCredential().Password, 9, 0, [ref]$userToken)
      ) {
         throw (new-object System.ComponentModel.Win32Exception( [System.Runtime.InteropServices.Marshal]::GetLastWin32Error() ) )
      }
      $Identity = New-Object Security.Principal.WindowsIdentity $userToken;
      $Context = $Identity.Impersonate();
    }
  
    $sqlConn = New-Object System.Data.SqlClient.SqlConnection;
    $sqlConn.ConnectionString = "Server=$ServerName;Database=$DatabaseName;Trusted_Connection=true";
    $sqlConn.Open();
    $sqlCmd = $sqlConn.CreateCommand();
    
    # Retrieve the tasks to process
    $sqlCmd.CommandText = $sqlGetUnprocessedTasks;
    $sqlReader = $sqlCmd.ExecuteReader();
    
    while ($sqlReader.Read())
    {
      $task = New-Object PSObject -Property @{
        AvailabilityGroupFailoverTaskID = $sqlReader["AvailabilityGroupFailoverTaskID"]
        AvailabilityGroupName = $sqlReader["AvailabilityGroupName"]
        PrimaryServerName = $sqlReader["PrimaryServerName"]
      };
      $tasksToProcess += $task;
    }
    $sqlReader.Close();
    
    # Prepare to process the availability group tasks
    $sqlCmd.CommandText = $sqlUpdateTask;
    $sqlCmd.Parameters.Add("@AvailabilityGroupFailoverTaskID",[System.Data.SqlDbType]::Int) | Out-Null;
    $sqlCmd.Parameters.Add("@StatusText",[System.Data.SqlDbType]::VarChar,2000) | Out-Null;
    $sqlCmd.Parameters.Add("@ProcessedFl",[System.Data.SqlDbType]::Bit) | Out-Null;
    
    # Process the tasks in a loop
    foreach ($task in $tasksToProcess)
    {
      $sqlCmd.Parameters["@AvailabilityGroupFailoverTaskID"].Value = $task.AvailabilityGroupFailoverTaskID;
      $sqlCmd.Parameters["@ProcessedFl"].Value = 1;
      try
      {
        $results = Move-AvailabilityGroup -NewPrimaryServerName $task.PrimaryServerName -AvailabiltyGroup $task.AvailabilityGroupName;
        $allResults += $results;
        if ($results.ExitCode -ne 0)
        {
          throw new-object System.Exception $results.StatusText;
        }
        $sqlCmd.Parameters["@StatusText"].Value = $results.StatusText;
      }
      catch
      {
        $sqlCmd.Parameters["@StatusText"].Value = $_.Exception.Message;
        $returnCode = 1;
      }
      finally
      {
        $sqlCmd.ExecuteNonQuery() | Out-Null;
      }
    }
    
    if ($returnCode -ne 0)
    {
      throw "Errors were encountered during exection. See the AvailabilityGroupFailoverTask table for details.";
    }
    
  }
  catch
  {
    Throw $_.Exception.Message;
  }
  finally
  {
    if (-not ($sqlCmd -eq $null))
    {
        $sqlCmd.Dispose();
    }
    if (-not ($sqlConn -eq $null))
    {
        $sqlConn.Dispose();
    }
    if ($Context -is [System.Security.Principal.WindowsImpersonationContext])
    {
      $Context.Undo();
      $Context.Dispose();
    }
    Write-Output $allResults;
  }
}