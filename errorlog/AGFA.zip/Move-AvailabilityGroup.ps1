﻿<#
.SYNOPSIS
   This function fails over AlwaysOn availability groups to the specified new primary server.
.DESCRIPTION
   As part of the AlwaysOn Availability Group Failover Automation framework, this 
   function attempts to fail over the specified availability group to the specified 
   server. If the group is in asynchronous mode, it will switch it to synchronous mode
   and then back to asynchronous.
.PARAMETER NewPrimaryServerName
   The name of the database server that the availability group should be failed over to.
.PARAMETER AvailabilityGroup
   The name of the availability group to fail over.
.NOTES
   This code is copyright 2015 Joshua Feierman. (josh@sqljosh.com)

   To sign up for updates, please visit this page: http://bit.ly/sqljosh.
  
  License:
  The availability group failover automation framework is free to download and use for personal, educational, and internal
  purposes, provided this license and all original attributions are included.
  Redistribution or sale in whole or in part is prohibited without the author's 
  express written consent.

  By installing or using this framework you agree to accept any and all risk associated with its use. The author is not liable
  for any damages or other consequences of using this framework. Please always test in a non-production system.
#>
function Move-AvailabilityGroup
{
[cmdletbinding()]
param
(
    [parameter(mandatory=$true)]
    [string]$NewPrimaryServerName,
    [parameter(mandatory=$true,ValueFromPipeline=$true)]
    [object]$AvailabiltyGroup
)
begin
{
    $exitCode = 0;
    $exitStatus = "";
    $isAsynchronous = $false;
    $primaryIsAsynchronous = $false;
    $currentPrimaryServerName = "";
    $isSuccessful = $true;
    $synchWaitTime = 30;
    $synchWaitedTime = 0;


    try
    {
        [System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SQLServer.SMO') | Out-Null;
        Write-Verbose "Connecting to server $NewPrimaryServerName.";
        $smoServer = New-Object Microsoft.SqlServer.Management.Smo.Server $NewPrimaryServerName;
    }
    catch
    {
        Write-Warning "Error occurred: $_";
        exit 1;
    }
}
process
{
    try
    {
        # Check if the specified server is a secondary for the given availability group.
        Write-Verbose "Checking if target server is a secondary for the specified availability group."
        if ($smoServer.AvailabilityGroups.Contains($AvailabiltyGroup) -eq $false)
        {
            throw "Availability group $AvailabiltyGroup is not available on server $NewPrimaryServerName.";
        }

        $smoAG = $smoServer.AvailabilityGroups[$AvailabiltyGroup];
        
        # If the AG is already using the specified server as a primary, then we don't need to do anything.
        if ($smoAG.PrimaryReplicaServerName -eq $smoServer.DomainInstanceName)
        {
          $exitStatus = "The specified server ($NewPrimaryServerName) is already the primary.";
        }
        else
        {
          
          $currentPrimaryServerName = $smoAG.PrimaryReplicaServerName;
          
          # Check if the AG is asynchronous
          $smoReplica = $smoAG.AvailabilityReplicas[$smoServer.DomainInstanceName];
          Write-Verbose "Checking if replica is in synchronous commit mode."
          if ($smoReplica.AvailabilityMode -ne [Microsoft.SqlServer.Management.Smo.AvailabilityReplicaAvailabilityMode]::SynchronousCommit)
          {
              $isAsynchronous = $true;
              Write-Verbose "Replica is not in synchronous mode, attempting to switch.";
              # Get the primary server
              $smoPrimaryServer = New-Object Microsoft.SqlServer.Management.Smo.Server $currentPrimaryServerName;

              # Alter the AG to be synchronous
              $smoPrimaryServer.AvailabilityGroups[$AvailabiltyGroup].AvailabilityReplicas[$smoServer.DomainInstanceName].AvailabilityMode = [Microsoft.SqlServer.Management.Smo.AvailabilityReplicaAvailabilityMode]::SynchronousCommit;
              if ($smoPrimaryServer.AvailabilityGroups[$AvailabiltyGroup].AvailabilityReplicas[$smoAG.PrimaryReplicaServerName].AvailabilityMode -eq [Microsoft.SqlServer.Management.Smo.AvailabilityReplicaAvailabilityMode]::AsynchronousCommit)
              {
                $smoPrimaryServer.AvailabilityGroups[$AvailabiltyGroup].AvailabilityReplicas[$currentPrimaryServerName].AvailabilityMode = [Microsoft.SqlServer.Management.Smo.AvailabilityReplicaAvailabilityMode]::SynchronousCommit;
                $smoPrimaryServer.AvailabilityGroups[$AvailabiltyGroup].AvailabilityReplicas[$currentPrimaryServerName].Alter();
                $primaryIsAsynchronous = $true;
              }
              $smoPrimaryServer.AvailabilityGroups[$AvailabiltyGroup].AvailabilityReplicas[$smoServer.DomainInstanceName].Alter();
          }
          
          # Check if the group is healthy
          Write-Verbose "Checking if replica is synchronized."
          $smoReplica = $smoAG.AvailabilityReplicas[$smoServer.DomainInstanceName];
          $smoReplica.Refresh();
          while ($smoReplica.RollupSynchronizationState -ne [Microsoft.SqlServer.Management.Smo.AvailabilityReplicaRollupSynchronizationState]::Synchronized)
          {
              if ($synchWaitedTime -le $synchWaitTime)
              {
                Write-Verbose "Waiting for AG to synchronize. Total time waited: $synchWaitedTime seconds.";
                Start-Sleep -Seconds 1
                $smoReplica.Refresh();
                $synchWaitedTime += 1;
              }
              else
              {
                throw "Availability group $AvailabiltyGroup is not synchronized on replica $($smoServer.DomainInstanceName). Aborting.";
              }
          }

          # Failover the group
          $smoAG.Failover();
          
          $exitStatus = "Group failed over successfully at $([DateTime]::Now.ToString()).";
        }
    }
    catch
    {
        $exitStatus = "Could not failover availability group $AvailabiltyGroup to server $NewPrimaryServerName. Error is: $_";
        Write-Warning $exitStatus;
        $exitCode = 1;
    }
    finally
    {
      # If the group was asynchronous, we need to set it back
      try
      {
        if ($isAsynchronous)
        {
          # If the failover was successful, we need to update the AG on the new primary. We want the original Primary (now 
          # secondary) to be set as async.
          if ($exitCode -eq 0)
          {
            $smoAG.AvailabilityReplicas[$currentPrimaryServerName].AvailabilityMode = [Microsoft.SqlServer.Management.Smo.AvailabilityReplicaAvailabilityMode]::AsynchronousCommit;
            $smoAG.AvailabilityReplicas[$currentPrimaryServerName].Alter();
#            if ($primaryIsAsynchronous)
#            {
#              $smoAG.AvailabilityReplicas[$smoAG.PrimaryReplicaServerName].AvailabilityMode = [Microsoft.SqlServer.Management.Smo.AvailabilityReplicaAvailabilityMode]::AsynchronousCommit;
#              $smoAG.AvailabilityReplicas[$smoAG.PrimaryReplicaServerName].ALter();
#            }
          }
          # Otherwise we need to do it on the original primary
          else
          {
            $smoPrimaryServer.AvailabilityGroups[$AvailabiltyGroup].AvailabilityReplicas[$smoServer.DomainInstanceName].AvailabilityMode = [Microsoft.SqlServer.Management.Smo.AvailabilityReplicaAvailabilityMode]::AsynchronousCommit;
            $smoPrimaryServer.AvailabilityGroups[$AvailabiltyGroup].AvailabilityReplicas[$smoServer.DomainInstanceName].Alter();
#            if ($primaryIsAsynchronous)
#            {
#              $smoPrimaryServer.AvailabilityGroups[$AvailabiltyGroup].AvailabilityReplicas[$smoAG.PrimaryReplicaServerName].AvailabilityMode = [Microsoft.SqlServer.Management.Smo.AvailabilityReplicaAvailabilityMode]::AsynchronousCommit;
#              $smoPrimaryServer.AvailabilityGroups[$AvailabiltyGroup].AvailabilityReplicas[$smoAG.PrimaryReplicaServerName].ALter();
#            }
          }
          $exitStatus += " Availability replica was set back to asynchronous mode.";
        }
      }
      catch
      {
        $exitStatus += "`nError occurred attempting to set AG back to asynchronous mode: $($_.Exception.Message).";
        $exitCode = 1;
      }
      $output = New-Object psobject -Property @{
        AvailabilityGroupName = $AvailabiltyGroup
        OriginalPrimaryName = $currentPrimaryServerName
        NewPrimaryServerName = $NewPrimaryServerName
        ExitCode = $exitCode
        StatusText = $exitStatus
      };
      Write-Output $output;
    }
}
}