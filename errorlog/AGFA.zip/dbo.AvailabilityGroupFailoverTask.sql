IF OBJECT_ID('dbo.AvailabilityGroupFailoverTask') IS NOT NULL
  DROP TABLE dbo.AvailabilityGroupFailoverTask;
CREATE TABLE [dbo].[AvailabilityGroupFailoverTask](
    [AvailabilityGroupFailoverTaskID] int IDENTITY,
	[AvailabilityGroupName] [sysname] NOT NULL,
	[PrimaryServerName] [sysname] NOT NULL,
	[FailoverWindowStartTime] [datetime] NOT NULL,
	[FailoverWindowEndTime] [datetime] NOT NULL,
	[StatusText] [nvarchar](max) NULL,
    ProcessedFl bit NOT NULL DEFAULT 0,
    CONSTRAINT PKAvailabilityGroupFailoverTask PRIMARY KEY NONCLUSTERED (AvailabilityGroupFailoverTaskID)
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY];

IF NOT EXISTS (
  SELECT 1 
    FROM sys.indexes i 
   WHERE i.name = 'CI_AvailabilityGroupFailoverTask' 
         AND i.object_id = OBJECT_ID('dbo.AvailabilityGroupFailoverTask')
)
  CREATE INDEX CI_AvailabilityGroupFailoverTask ON dbo.AvailabilityGroupFailoverTask
  (
    ProcessedFl,
    FailoverWindowStartTime
  );

IF NOT EXISTS (SELECT 1 FROM sys.database_principals dp WHERE dp.name = 'prole_FailoverTaskProcessor')
  CREATE ROLE prole_FailoverTaskProcessor;

GRANT SELECT,UPDATE ON dbo.AvailabilityGroupFailoverTask TO prole_FailoverTaskProcessor;