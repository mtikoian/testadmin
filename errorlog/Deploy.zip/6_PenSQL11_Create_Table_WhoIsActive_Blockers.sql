USE DBAdmin;
go


SET ANSI_NULLS ON;
GO

SET QUOTED_IDENTIFIER ON;
GO

SET ANSI_PADDING ON;
GO


/*
 File Name				: Create_Table_WhoIsActive_Blockers.sql
 Description   			: This tables stored blocking session information
 Created By    			: VBANDI
 Created Date  			: 03/10/2015
 Modification History	:
 ------------------------------------------------------------------------------
 Date		Modified By 		Description
*/
PRINT ''
PRINT '----------------------------------------'
PRINT 'TABLE script for WhoIsActive_Blockers'
PRINT '----------------------------------------'

BEGIN TRY

	IF NOT EXISTS 
		(
			SELECT 1 
			FROM   information_schema.Tables 
			WHERE  Table_schema = 'dbo' 
				   AND Table_name = 'WhoIsActive_Blockers'  
		)
		BEGIN
		 		CREATE TABLE dbo.WhoIsActive_Blockers(
					[dd hh:mm:ss.mss] [varchar](8000) NULL,
					[session_id] [smallint] NOT NULL,
					[sql_text] [xml] NULL,
					[login_name] [nvarchar](128) NOT NULL,
					[wait_info] [nvarchar](4000) NULL,
					[CPU] [varchar](30) NULL,
					[tempdb_allocations] [varchar](30) NULL,
					[tempdb_current] [varchar](30) NULL,
					[blocking_session_id] [smallint] NULL,
					[blocked_session_count] [varchar](30) NULL,
					[reads] [varchar](30) NULL,
					[writes] [varchar](30) NULL,
					[physical_reads] [varchar](30) NULL,
					[query_plan] [xml] NULL,
					[used_memory] [varchar](30) NULL,
					[status] [varchar](30) NOT NULL,
					[open_tran_count] [varchar](30) NULL,
					[percent_complete] [varchar](30) NULL,
					[host_name] [nvarchar](128) NULL,
					[database_name] [nvarchar](128) NULL,
					[program_name] [nvarchar](128) NULL,
					[start_time] [datetime] NOT NULL,
					[login_time] [datetime] NULL,
					[request_id] [int] NULL,
					[collection_time] [datetime] NOT NULL
				) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY];

				print 'Table WhoIsActive_Blockers Created';
		END;
		ELSE
		BEGIN
				print 'Table WhoIsActive_Blockers already exists';
		END;
END TRY
BEGIN CATCH
  DECLARE @error_Message VARCHAR(2100); 
        DECLARE @error_Severity INT; 
        DECLARE @error_State INT; 
	
        SET @error_Message = Error_Message() 
        SET @error_Severity = Error_Severity() 
        SET @error_State = Error_State()         

        RAISERROR (@error_Message,@error_Severity,@error_State); 
END CATCH;
PRINT '';
PRINT 'End of TABLE script for WhoIsActive_Blockers';
PRINT '----------------------------------------';



