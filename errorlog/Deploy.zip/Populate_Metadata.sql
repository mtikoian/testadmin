USE DBAdmin;
GO
DECLARE @ErrorMessage NVARCHAR(4000)            ; SET @ErrorMessage = '';
DECLARE @ErrorSeverity INTEGER                  ; SET @ErrorSeverity = 0;
DECLARE @ErrorState INTEGER                     ; SET @ErrorState = 0;


	BEGIN TRY
		INSERT INTO [dbo].[EmailRecepientsList]
           ([Recepients]
           )
		 VALUES
           ('IT_Infra@pentegra.com')
	END TRY
    BEGIN CATCH
       
        SELECT @ErrorMessage = ERROR_MESSAGE(),
               @ErrorSeverity = ERROR_SEVERITY(),
               @ErrorState = ERROR_STATE();

        RAISERROR (@ErrorMessage, -- Message text.
                   @ErrorSeverity, -- Severity.
                   @ErrorState -- State.
                   );
    END CATCH ;


