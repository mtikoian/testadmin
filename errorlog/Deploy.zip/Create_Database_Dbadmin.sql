use master;
go

if exists (select 1 from sys.databases where name = 'DBAdmin') 
begin 
PRINT 'Database DBAdmin already exists skipping database creation'
end
else
BEGIN
create database DBAdmin;
PRINT '<<< Created Database DBAdmin >>>'
END;
go