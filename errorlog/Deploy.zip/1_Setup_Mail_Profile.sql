/* 2005,2008,2008R2,2012 */


 
/*****************************************************************************************************
 * Script Information
 *----------------------------------------------------------------------------------------------------
 *		Author: VBANDI
 *		  Date: 3/09/2015
 * Description: Sets up the standard DBA mail profile.
 *	   History:
 *****************************************************************************************************/
-- Setup  DB Mail profile --
BEGIN TRY

    EXEC sp_configure 'Show Advanced Options',1;
    RECONFIGURE WITH OVERRIDE;
    EXEC sp_configure 'Database Mail XPs', 1;
    RECONFIGURE WITH OVERRIDE;
    
    DECLARE @profile_name sysname,
        @account_name sysname,
        @SMTP_servername sysname,
        @email_address NVARCHAR(128),
	    @display_name NVARCHAR(128);

    -- Profile name. Replace with the name for your profile
    SET @profile_name = 'DBA_Mail_Profile';

    -- Account information. Replace with the information for your account.

    SET @account_name = 'DBA_Mail_Profile';
    SET @SMTP_servername = 'mail2hub';
    SET @email_address = 'SQL-Alerts@pentegra.com';
    SET @display_name = 'DBA Alerts';

	IF EXISTS (SELECT 1 FROM msdb.dbo.sysmail_profile WHERE name = @account_name )
	begin
	EXEC msdb.dbo.sysmail_delete_profile_sp @profile_name= @profile_name, @force_delete=True
	end;

	IF EXISTS (SELECT 1 FROM msdb.dbo.sysmail_account WHERE name = @account_name )
	begin
	EXEC msdb.dbo.sysmail_delete_account_sp @account_name= @account_name;
	end;

    -- Verify the specified account and profile do not already exist.
    IF EXISTS (SELECT 1 FROM msdb.dbo.sysmail_profile WHERE name = @profile_name)
    BEGIN
      RAISERROR('The specified Database Mail profile (DBA_Mail_Profile) already exists.', 16, 1);
    END;

    IF EXISTS (SELECT * FROM msdb.dbo.sysmail_account WHERE name = @account_name )
    BEGIN
     RAISERROR('The specified Database Mail account (DBA_Mail_Profile) already exists.', 16, 1) ;
    END;

    -- Start a transaction before adding the account and the profile
    BEGIN TRANSACTION ;

    DECLARE @rv INT;

    -- Add the account
    EXECUTE @rv=msdb.dbo.sysmail_add_account_sp
        @account_name = @account_name,
        @email_address = @email_address,
        @display_name = @display_name,
        @mailserver_name = @SMTP_servername;

    IF @rv<>0
    BEGIN
        RAISERROR('Failed to create the specified Database Mail account (DBA_Account).', 16, 1) ;
    END

    -- Add the profile
    EXECUTE @rv=msdb.dbo.sysmail_add_profile_sp
        @profile_name = @profile_name ;

    IF @rv<>0
    BEGIN
        RAISERROR('Failed to create the specified Database Mail profile (DBA_Profile).', 16, 1);
    END;

    -- Associate the account with the profile.
    EXECUTE @rv=msdb.dbo.sysmail_add_profileaccount_sp
        @profile_name = @profile_name,
        @account_name = @account_name,
        @sequence_number = 1 ;

    IF @rv<>0
    BEGIN
        RAISERROR('Failed to associate the speficied profile with the specified account (DBA_Account).', 16, 1) ;
    END;

    COMMIT TRANSACTION;
    
END TRY
BEGIN CATCH

    RAISERROR('Error occurred setting up database mail options.',16,1)
    
    DECLARE @errno INT,
                @errmsg VARCHAR(100),
                @errsev INT,
                @errstate INT ;

    SELECT   @errno = ERROR_NUMBER(),
             @errmsg = ERROR_MESSAGE(),
             @errsev = ERROR_SEVERITY(),
             @errstate = ERROR_STATE() ;
             
    RAISERROR(@errmsg,@errsev,@errstate);

END CATCH
