USE DBAdmin;
GO

SET ANSI_NULLS ON;
GO

SET QUOTED_IDENTIFIER ON;
GO

SET ANSI_PADDING OFF;
GO
/*
 File Name				: Create_Table_EmailRecepientsList.sql
 Description   			: This tables stored EmailRecepientsList information
 Created By    			: VBANDI
 Created Date  			: 03/19/2015
 Modification History	:
 ------------------------------------------------------------------------------
 Date		Modified By 		Description
*/
PRINT '';
PRINT '----------------------------------------';
PRINT 'TABLE script for EmailRecepientsList';
PRINT '----------------------------------------';

BEGIN TRY

	IF  EXISTS 
		(
			SELECT 1 
			FROM   information_schema.Tables 
			WHERE  Table_schema = 'dbo' 
				   AND Table_name = 'EmailRecepientsList'  
		)
		BEGIN
			DROP Table dbo.EmailRecepientsList;
			PRINT 'Table dbo.EmailRecepientsList has been dropped.';
		END;
CREATE TABLE dbo.EmailRecepientsList(
	Recepients			varchar(512) NOT NULL,
	Copy_Recepients		varchar(512) NULL,
 CONSTRAINT PK_EmailRecepientsList PRIMARY KEY CLUSTERED 
(
	Recepients ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

-- Validate if the table has been created.
	IF  EXISTS 
		(
			SELECT 1 
			FROM   information_schema.Tables 
			WHERE  Table_schema = 'dbo' 
				   AND Table_name = 'EmailRecepientsList'  
		)
		BEGIN
			PRINT 'Table dbo.EmailRecepientsList has been created.';
		END;
	ELSE
		BEGIN
			PRINT 'Failed to create Table dbo.EmailRecepientsList!!!!!!!';
		END;

END TRY
BEGIN CATCH
  DECLARE @error_Message VARCHAR(2100); 
        DECLARE @error_Severity INT; 
        DECLARE @error_State INT; 
	
        SET @error_Message = Error_Message(); 
        SET @error_Severity = Error_Severity();
        SET @error_State = Error_State();         

        RAISERROR (@error_Message,@error_Severity,@error_State); 
END CATCH;
PRINT '';
PRINT 'End of TABLE script for EmailRecepientsList';
PRINT '----------------------------------------';
SET ANSI_PADDING OFF
GO


