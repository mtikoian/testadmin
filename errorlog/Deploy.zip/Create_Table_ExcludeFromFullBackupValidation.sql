USE DBAdmin;
GO

SET ANSI_NULLS ON;
GO

SET QUOTED_IDENTIFIER ON;
GO

SET ANSI_PADDING OFF;
GO
/*
 File Name				: Create_Table_ExcludeFromFullBackupValidation.sql
 Description   			: This tables stored ExcludeFromFullBackupValidation information
 Created By    			: VBANDI
 Created Date  			: 03/19/2015
 Modification History	:
 ------------------------------------------------------------------------------
 Date		Modified By 		Description
*/
PRINT '';
PRINT '----------------------------------------';
PRINT 'TABLE script for ExcludeFromFullBackupValidation';
PRINT '----------------------------------------';

BEGIN TRY

	IF  EXISTS 
		(
			SELECT 1 
			FROM   information_schema.Tables 
			WHERE  Table_schema = 'dbo' 
				   AND Table_name = 'ExcludeFromFullBackupValidation'  
		)
		BEGIN
			DROP Table dbo.ExcludeFromFullBackupValidation;
			PRINT 'Table dbo.ExcludeFromFullBackupValidation has been dropped.';
		END;

CREATE TABLE dbo.ExcludeFromFullBackupValidation
(
	Database_Nm			varchar(50) NOT NULL, --Database Name that need to excluded from Tlog check
	Last_Update_Dt		datetime	NOT NULL, --Last update date
	Last_Update_User_Id varchar(50) NOT NULL, --Last update user id
 CONSTRAINT PK_CI_ExcludeFromFullBackupValidation PRIMARY KEY CLUSTERED 
(
	Database_Nm ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY];

PRINT 'Adding constraints';
ALTER TABLE dbo.ExcludeFromFullBackupValidation ADD  DEFAULT (getdate()) FOR Last_Update_Dt;


ALTER TABLE dbo.ExcludeFromFullBackupValidation ADD  DEFAULT (user_name()) FOR Last_Update_User_Id;

-- Validate if the table has been created.
	IF  EXISTS 
		(
			SELECT 1 
			FROM   information_schema.Tables 
			WHERE  Table_schema = 'dbo' 
				   AND Table_name = 'ExcludeFromFullBackupValidation'  
		)
		BEGIN
			PRINT 'Table dbo.ExcludeFromFullBackupValidation has been created.';
		END;
	ELSE
		BEGIN
			PRINT 'Failed to create Table dbo.ExcludeFromFullBackupValidation!!!!!!!';
		END;

END TRY
BEGIN CATCH
  DECLARE @error_Message VARCHAR(2100); 
        DECLARE @error_Severity INT; 
        DECLARE @error_State INT; 
	
        SET @error_Message = Error_Message(); 
        SET @error_Severity = Error_Severity();
        SET @error_State = Error_State();         

        RAISERROR (@error_Message,@error_Severity,@error_State); 
END CATCH;
PRINT '';
PRINT 'End of TABLE script for ExcludeFromFullBackupValidation';
PRINT '----------------------------------------';

SET ANSI_PADDING OFF;
GO