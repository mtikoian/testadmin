USE [msdb]
GO
IF EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'DBAdmin_CheckFailedJobs')
begin
EXEC msdb.dbo.sp_delete_job @job_name= N'DBAdmin_CheckFailedJobs', @delete_unused_schedule=1
end;
/****** Object:  Job [DBAdmin_CheckFailedJobs]    Script Date: 3/18/2015 2:23:45 PM ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [DBA]    Script Date: 3/18/2015 2:23:45 PM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'DBA' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'DBA'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'DBAdmin_CheckFailedJobs', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'This job will call p_admin_CheckFailedJobs procedure to track and 
generate alerts for the failed jobs on the server', 
		@category_name=N'DBA', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [CheckFailedJobs from past 24 hours]    Script Date: 3/18/2015 2:23:45 PM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'CheckFailedJobs from past 24 hours', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC dbo.p_admin_CheckFailedJobs
  @TBL_STYLE = ''style="font:12pt" class="altlistborder" cellpadding="2" cellspacing="1" table border="1" p style="color:black"''
  ,@HDR_STYLE = ''table style="background-color:BurlyWood"''
  ,@FINALBODY = ''<h3>List of Failed Job(s)</h3>''
  ,@MAILPROFILE = ''DBA_Mail_Profile''
  ,@EMAIL_RECEPIENTS = ''''
  ,@COPY_RECEPIENTS = ''''
  ,@EMAIL_SUBJECT = ''SQL Job(s) Failure Alert on ''
  ,@MESSAGEDESC1 = ''Following list of job(s) have failed on ''
  ,@MESSAGEDESC2 = ''server in last 24 hours.Please check why the job(s) failed.'' 
  ,@JOBHISTORY = 24 --Specify the Job history here', 
		@database_name=N'DBAdmin', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Daily every 8 hours', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=8, 
		@freq_subday_interval=8, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20150316, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959
		--@schedule_uid=N'47cbe79b-a92f-457f-861a-271d6a60d002'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO


