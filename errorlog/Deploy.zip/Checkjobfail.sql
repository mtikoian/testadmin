USE msdb

SET QUOTED_IDENTIFIER OFF
GO

SET ANSI_NULLS ON
GO

IF EXISTS (
		SELECT 1
		FROM sysobjects
		WHERE NAME = 'checkForJobFail'
		)
	DROP TRIGGER dbo.[checkForJobFail]
GO

CREATE TRIGGER dbo.[checkForJobFail] ON [dbo].[sysjobhistory]
FOR INSERT
AS
DECLARE @msg VARCHAR(2048)
	,@maillist VARCHAR(256)
	,@mailfrom VARCHAR(256)
	,@jobName SYSNAME
	,@subject VARCHAR(256)
	,@failStepID INT

IF (
		SELECT step_id
		FROM inserted
		) <> 0
	RETURN
ELSE
BEGIN
	SELECT @jobName = NAME
	FROM inserted i
	INNER JOIN sysjobs j ON i.job_id = j.job_id

	IF (
			SELECT run_status
			FROM inserted
			) = 0 --the job failed
	BEGIN
		SELECT @msg = message
		FROM inserted
	END
	ELSE IF (
			EXISTS (
				SELECT h.instance_id
				FROM inserted i
				INNER JOIN sysjobhistory h ON i.job_id = h.job_id
				WHERE i.run_date <= h.run_date
					AND i.run_time <= h.run_time
					AND h.run_status = 0
					AND h.step_id > 0
				)
			) --any step in the job failed
	BEGIN
		SELECT @failStepID = min(h.instance_id)
		FROM inserted i
		INNER JOIN sysjobhistory h ON i.job_id = h.job_id
		WHERE i.run_date <= h.run_date
			AND i.run_time <= h.run_time
			AND h.run_status = 0
			AND h.step_id > 0

		SELECT @msg = 'Step ' + cast(h.step_id AS VARCHAR(3)) + ' failed 
		' + h.message
		FROM inserted i
		INNER JOIN sysjobhistory h ON i.job_id = h.job_id
		WHERE h.instance_id = @failStepID
	END
	ELSE
		RETURN -- the job didn't fail and no steps failed

	DECLARE @rc INT
	DECLARE @EMAIL_RECEPIENTS NVARCHAR(1000);

	SET @EMAIL_RECEPIENTS = '';

	SELECT @EMAIL_RECEPIENTS = @EMAIL_RECEPIENTS + Recepients + ';'
	FROM dbadmin.dbo.EmailRecepientsList;

	SET @EMAIL_RECEPIENTS = LEFT(@EMAIL_RECEPIENTS, LEN(@EMAIL_RECEPIENTS) - 1);

	set @EMAIL_RECEPIENTS = 'ITOperations@pentegra.com';

	SELECT @subject = 'Job ''' + @jobName + ''' failed on ' + @@servername

	--Send out email (SQL 2005 or newer)
	EXEC @rc = msdb.dbo.sp_send_dbmail @profile_name = 'DBA_Mail_Profile'
		,@recipients = @EMAIL_RECEPIENTS
		,@Subject = @subject
		,@Body = @msg
END
GO

SET QUOTED_IDENTIFIER OFF
GO

SET ANSI_NULLS ON
GO



