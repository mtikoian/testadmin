SET NOCOUNT ON;
DECLARE @loginame VARCHAR(100);
SET @loginame = N'PENTEGRA\pentdb4'
DECLARE @ScriptList TABLE (  Script VARCHAR(MAX))
INSERT INTO @ScriptList
SELECT
            'ALTER AUTHORIZATION ON DATABASE::' + d.name + ' to '''+ @loginame+''';'
FROM sys.databases  d
WHERE
        SUSER_SNAME(owner_sid) <> SUSER_SNAME(0x01);
 
--Once you've saved your rollback script.  Save your roll-forward script
SELECT * FROM @scriptlist ;
