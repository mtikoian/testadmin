USE DBAdmin;
GO

SET QUOTED_IDENTIFIER ON;
GO

SET ANSI_NULLS ON;
GO

IF EXISTS (
		SELECT 1
		FROM sysobjects
		WHERE NAME = 'p_admin_DatabaseMaintenance_Wrapper'
		)
BEGIN
	DROP PROCEDURE dbo.p_admin_DatabaseMaintenance_Wrapper;

	PRINT 'Stored procedure p_admin_DatabaseMaintenance_Wrapper dropped';
END;
ELSE
BEGIN
	PRINT 'Creating Procedure p_admin_DatabaseMaintenance_Wrapper';
END;
GO



CREATE PROCEDURE dbo.p_admin_DatabaseMaintenance_Wrapper
@pi_Databases nvarchar(max),
@pi_opts int = 0,
@pi_LockTimeout int = NULL,
@pi_LogToTable nvarchar(max) = 'N',
@pi_Execute nvarchar(max) = 'Y',

/* Index procedure input parameters */
@pi_FragmentationLow nvarchar(max) = NULL,
@pi_FragmentationMedium nvarchar(max) = 'INDEX_REORGANIZE,INDEX_REBUILD_ONLINE,INDEX_REBUILD_OFFLINE',
@pi_FragmentationHigh nvarchar(max) = 'INDEX_REBUILD_ONLINE,INDEX_REBUILD_OFFLINE',
@pi_FragmentationLevel1 int = 5,
@pi_FragmentationLevel2 int = 30,
@pi_PageCountLevel int = 1000,
@pi_SortInTempdb nvarchar(max) = 'N',
@pi_MaxDOP int = NULL,
@pi_FillFactor int = NULL,
@pi_PadIndex nvarchar(max) = NULL,
@pi_LOBCompaction nvarchar(max) = 'Y',
@pi_UpdateStatistics nvarchar(max) = NULL,
@pi_OnlyModifiedStatistics nvarchar(max) = 'N',
@pi_StatisticsSample int = NULL,
@pi_StatisticsResample nvarchar(max) = 'N',
@pi_PartitionLevel nvarchar(max) = 'Y',
@pi_MSShippedObjects nvarchar(max) = 'N',
@pi_Indexes nvarchar(max) = NULL,
@pi_TimeLimit int = NULL,
@pi_Delay int = NULL,
@pi_WaitAtLowPriorityMaxDuration int = NULL,
@pi_WaitAtLowPriorityAbortAfterWait nvarchar(max) = NULL,


/* Databse Integrity Check */
@pi_CheckCommands nvarchar(max) = 'CHECKDB',
@pi_PhysicalOnly nvarchar(max) = 'N',
@pi_NoIndex nvarchar(max) = 'N',
@pi_ExtendedLogicalChecks nvarchar(max) = 'N',
@pi_TabLock nvarchar(max) = 'N',
@pi_FileGroups nvarchar(max) = NULL,
@pi_Objects nvarchar(max) = NULL,
@pi_OverrideDBCCPreference nvarchar(max) = 'N',


/* Database Backup input parameters */
@pi_Directory nvarchar(max) = NULL,
@pi_BackupType nvarchar(max),
@pi_Verify nvarchar(max) = 'N',
@pi_CleanupTime int = NULL,
@pi_Compress nvarchar(max) = NULL,
@pi_CopyOnly nvarchar(max) = 'N',
@pi_ChangeBackupType nvarchar(max) = 'N',
@pi_BackupSoftware nvarchar(max) = NULL,
@pi_CheckSum nvarchar(max) = 'N',
@pi_BlockSize int = NULL,
@pi_BufferCount int = NULL,
@pi_MaxTransferSize int = NULL,
@pi_NumberOfFiles int = NULL,
@pi_CompressionLevel int = NULL,
@pi_Description nvarchar(max) = NULL,
@pi_Threads int = NULL,
@pi_Throttle int = NULL,
@pi_Encrypt nvarchar(max) = 'N',
@pi_EncryptionAlgorithm nvarchar(max) = NULL,
@pi_ServerCertificate nvarchar(max) = NULL,
@pi_ServerAsymmetricKey nvarchar(max) = NULL,
@pi_EncryptionKey nvarchar(max) = NULL,
@pi_ReadWriteFileGroups nvarchar(max) = 'N',
@pi_OverrideBackupPreference nvarchar(max) = 'N',






@pi_PrimaryRecipient VARCHAR(255) = ' ',
@pi_SecondaryRecipient VARCHAR(255) = ' ',
@pi_OnCallRecipient VARCHAR(255) = ' '
AS
   /*===================================================================================================================================================
   Name : p_admDatabaseMaintenance_Wrapper
   Author : VBANDI 03/06/2015 
   Description : Wrapper for calling the Index Optimze script

	    This procedure calls the IndexOptimze script written by Ola Hallengren
		This procedure calls the DatabaseIntegrityCheck script written by Ola Hallengren
		This procedure calls the DatabaseBackup script written by Ola Hallengren
        Source: http://ola.hallengren.com
  

    
===================================================================================================================================================
Parameters :
Name                                | I/O | Description

@pi_Databases   INPUT Database list to backup. To exclude any database prefix the database name with a hyphen (-)
                      Examples: 1. SYSTEM_DATABASES
                                2. USER_DATABASES
                                3. ALL_DATABASES
                                4. Database1
                                5. Database1, Database2
                                6. %Database%
                                7. %Database%, -Database1
                                8. option 1..3, -Database1   

@pi_opts              Options that drive execution for the proc. NOTE: Inputs are based off of (bitmask) operations.
                            2 bit - if set, Index Maintenance is performed
                            4 bit - if set, Database Consistency Checks are performed
							8 bit - if set, Database Backups are performed

							IF @pi_opts & 2 = 2 then run index maintenance
							IF @pi_opts & 4 = 4 then run database integrity checks
							IF @pi_opts & 8 = 8 then run database backups

							IF @pi_opts & 10 = 10 then only run index maintenance and database backups
							IF @pi_opts & 12 = 12 then only run database integrity checks and database backups
							IF @pi_opts & 14 = 14 then run all maintenance steps

@pi_LockTimeout	int				|	Set the time, in seconds, that a command waits for a lock to be released. By default, the time is not limited
@pi_LogToTable	nvarchar(max)	|	Log commands to the table dbo.CommandLog.
										Y = Log commands to the table. 
										N = Do not log commands to the table. This is the default. 

@pi_Execute		nvarchar(max)	|	Execute commands. By default, the commands are executed normally. If this parameter is set to N, then the commands are printed only.
										Y = Execute commands. This is the default. 
										N = Only print commands. 

***** parameters below control index maintenance execution *****
@pi_FragmentationLow					nvarchar(max)	|	Specify index maintenance operations to be performed on a low-fragmented index.
															Examples:	INDEX_REBUILD_ONLINE = Rebuild index online. 
																		INDEX_REBUILD_OFFLINE = Rebuild index offline. 
																		INDEX_REORGANIZE = Reorganize index. 
																		INDEX_REBUILD_ONLINE,INDEX_REBUILD_OFFLINE = Rebuild index online. Rebuild index offline if online rebuilding is not supported on an index. 
																		INDEX_REBUILD_ONLINE,INDEX_REORGANIZE = Rebuild index online. Reorganize index if online rebuilding is not supported on an index. 
																		INDEX_REORGANIZE,INDEX_REBUILD_ONLINE,INDEX_REBUILD_OFFLINE = Reorganize index. Rebuild index online if reorganizing is not supported on an index. Rebuild index offline if reorganizing and online rebuilding are not supported on an index. 
																		NULL = Do not perform index maintenance. This is the default for a low-fragmented index. 

															An online index rebuild or an index reorganization is not always possible. Because of this, you can specify multiple index-maintenance operations 
															for each fragmentation group. These operations are prioritized from left to right: If the first operation is supported for the index, 
															then that operation is used; if the first operation is not supported, then the second operation is used (if supported), and so on. 
															If none of the specified operations are supported for an index, then that index is not maintained.

@pi_FragmentationMedium					nvarchar(max)	|	Specify index maintenance operations to be performed on a medium-fragmented index.
															Examples:	INDEX_REBUILD_ONLINE = Rebuild index online. 
																		INDEX_REBUILD_OFFLINE = Rebuild index offline. 
																		INDEX_REORGANIZE = Reorganize index. 
																		INDEX_REBUILD_ONLINE,INDEX_REBUILD_OFFLINE = Rebuild index online. Rebuild index offline if online rebuilding is not supported on an index. 
																		INDEX_REBUILD_ONLINE,INDEX_REORGANIZE = Rebuild index online. Reorganize index if online rebuilding is not supported on an index. 
																		INDEX_REORGANIZE,INDEX_REBUILD_ONLINE,INDEX_REBUILD_OFFLINE = Reorganize index. Rebuild index online if reorganizing is not supported on an index. Rebuild index offline if reorganizing and online rebuilding are not supported on an index. This is the default for a medium-fragmented index. 
																		NULL = Do not perform index maintenance. 

															An online index rebuild or an index reorganization is not always possible. Because of this, you can specify multiple index-maintenance operations 
															for each fragmentation group. These operations are prioritized from left to right: If the first operation is supported for the index, 
															then that operation is used; if the first operation is not supported, then the second operation is used (if supported), and so on. 
															If none of the specified operations are supported for an index, then that index is not maintained.

@pi_FragmentationHigh					nvarchar(max)	|	Specify index maintenance operations to be performed on a high-fragmented index.
															Examples:	INDEX_REBUILD_ONLINE = Rebuild index online. 
																		INDEX_REBUILD_OFFLINE = Rebuild index offline. 
																		INDEX_REORGANIZE = Reorganize index. 
																		INDEX_REBUILD_ONLINE,INDEX_REBUILD_OFFLINE = Rebuild index online. Rebuild index offline if online rebuilding is not supported on an index.
																		                                             This is the default for a high-fragmented index. 
																		INDEX_REBUILD_ONLINE,INDEX_REORGANIZE = Rebuild index online. Reorganize index if online rebuilding is not supported on an index. 
																		INDEX_REORGANIZE,INDEX_REBUILD_ONLINE,INDEX_REBUILD_OFFLINE = Reorganize index. Rebuild index online if reorganizing is not supported on an index. Rebuild index offline if reorganizing and online rebuilding are not supported on an index.  
																		NULL = Do not perform index maintenance.
																		
															An online index rebuild or an index reorganization is not always possible. Because of this, you can specify multiple index-maintenance operations for each fragmentation group. 
															These operations are prioritized from left to right: If the first operation is supported for the index, then that operation is used; if the first operation is not supported, 
															then the second operation is used (if supported), and so on. If none of the specified operations are supported for an index, then that index is not maintained. 

@pi_FragmentationLevel1					int				|	Set the lower limit, as a percentage, for medium fragmentation. The default is 5 percent. This is based on Microsoft�s recommendation in Books Online.
																IndexOptimize checks avg_fragmentation_in_percent in sys.dm_db_index_physical_stats to determine the fragmentation.

@pi_FragmentationLevel2					int				|	Set the lower limit, as a percentage, for high fragmentation. The default is 30 percent. This is based on Microsoft�s recommendation in Books Online.
																IndexOptimize checks avg_fragmentation_in_percent in sys.dm_db_index_physical_stats to determine the fragmentation.


@pi_PageCountLevel						int				|	Set a size, in pages; indexes with fewer pages are skipped for index maintenance. The default is 1000 pages. This is based on Microsoft�s recommendation in this white paper.
																IndexOptimize checks page_count in sys.dm_db_index_physical_stats to determine the size of the index.

@pi_SortInTempdb						nvarchar(max)	|	Use tempdb for sort operations when rebuilding indexes.
																Y = Use tempdb for sort operations when rebuilding indexes. 
																N = Do not use tempdb for sort operations when rebuilding indexes. This is the default. 

@pi_MaxDOP								int				|	Specify the number of CPUs to use when rebuilding indexes. If this number is not specified, the global maximum degree of parallelism is used.
																The MaxDOP option in IndexOptimize uses the MAXDOP option in the SQL Server ALTER INDEX command.

@pi_FillFactor							int				|	Indicate, as a percentage, how full the pages should be made when rebuilding indexes. If a percentage is not specified, the fill factor in sys.indexes is used.
																The FillFactor option in IndexOptimize uses the FILLFACTOR option in the SQL Server ALTER INDEX command.

@pi_PadIndex							nvarchar(max)	|	Apply the percentage of free space that the fill factor specifies to the intermediate-level pages of the index.
																Y = Apply the percentage of free space that the fill factor specifies to the intermediate-level pages of the index. 
																N = The intermediate-level pages of the index are filled to near capacity. This is the default. 
															The PadIndex option in IndexOptimize uses the PADINDEX option in the SQL Server ALTER INDEX command.
@pi_LOBCompaction						nvarchar(max)	|	Compact pages that contain large object (LOB) columns, when reorganizing indexes.
																Y = Compact pages that contain LOB columns, when reorganizing indexes. This is the default. 
																N = Do not compact pages that contain LOB columns, when reorganizing indexes. 
															The LOBCompaction option in IndexOptimize uses the LOB_COMPACTION option in the SQL Server ALTER INDEX command.

@pi_UpdateStatistics					nvarchar(max)	|	Update statistics.
															Examples:	ALL Update index and column statistics. 
																		INDEX = Update index statistics. 
																		COLUMNS = Update column statistics. 
																		NULL = Do not perform statistics maintenance. This is the default.		
															IndexOptimize uses the SQL Server UPDATE STATISTICS command to update statistics.
	
@pi_OnlyModifiedStatistics				nvarchar(max)	|	Update statistics only if any rows have been modified since the most recent statistics update.
																Y = Update statistics only if any rows have been modified since the most recent statistics update. 
																N = Update statistics regardless of whether any rows have been modified. 
															IndexOptimize checks modification_counter in sys.dm_db_stats_properties, in SQL Server 2008 R2 starting with Service Pack 2 and in SQL Server 2012 starting with Service Pack 1, 
															  to determine whether any rows have been modified since the most recent statistics update. In earlier versions it checks rowmodctr in sys.sysindexes.

@pi_StatisticsSample					int				|	Indicate, as a percentage, how much of a table is gathered when updating statistics. A value of 100 is equivalent to a full scan. If no value is specified, then SQL Server automatically computes the required sample.
																The StatisticsSample option in IndexOptimize uses the SAMPLE and FULLSCAN options in the SQL Server UPDATE STATISTICS command.

@pi_StatisticsResample					nvarchar(max)	|	Update statistics with the most recent sample.
																Y = Update statistics with the most recent sample. 
																N = Let SQL Server automatically compute the required sample. This is the default. 
															The StatisticsResample option in IndexOptimize uses the RESAMPLE option in the SQL Server UPDATE STATISTICS command.
															You cannot combine the options StatisticsSample and StatisticsResample.

@pi_PartitionLevel						nvarchar(max)	|	Maintain partitioned indexes on the partition level. If this parameter is set to Y, the fragmentation level and page count is checked for each partition. The appropriate index maintenance (reorganize or rebuild) is then performed for each partition.
																Y = Maintain partitioned indexes on the partition level. This is the default. 
																N = Maintain partitioned indexes on the index level. 

@pi_MSShippedObjects					nvarchar(max)	|	Maintain indexes and statistics on objects that are created by internal SQL Server components.
																Y = Maintain indexes and statistics on objects that are created by internal SQL Server components. 
																N = Do not maintain indexes and statistics on objects that are created by internal SQL Server components. This is the default. 

@pi_Indexes								nvarchar(max)	|	Select indexes. If this parameter is not specified, all indexes are selected. The ALL_INDEXES keyword is supported. The hyphen character (-) is used to exclude indexes, and the percent character (%) is used for wildcard selection. All these operations can be combined by using the comma (,).
															Examples:	ALL_INDEXES = All indexes 
																		Db1.Schema1.Tbl1.Idx1 = The index Idx1 on the object Schema1.Tbl1 in the database Db1 
																		Db1.Schema1.Tbl1.Idx1, Db2.Schema2.Tbl2.Idx2 = The index Idx1 on the object Schema1.Tbl1 in the database Db1 and the index Idx2 on the object Schema2.Tbl2 in the database Db2 
																		Db1.Schema1.Tbl1 = All indexes on the object Schema1.Tbl1 in the database Db1 
																		Db1.Schema1.Tbl1, Db2.Schema2.Tbl2 = All indexes on the object Schema1.Tbl1 in the database Db1 and all indexes on the object Schema2.Tbl2 in the database Db2 
																		Db1.Schema1.% = All indexes in the schema Schema1 in the database Db1 
																		%.Schema1.% = All indexes in the schema Schema1 in all databases 
																		ALL_INDEXES, -Db1.Schema1.Tbl1.Idx1 = All indexes except the index Idx1 on the object Schema1.Tbl1 in the database Db1 
																		ALL_INDEXES, -Db1.Schema1.Tbl1 = All indexes except indexes on the object Schema1.Tbl1 in the database Db1 

@pi_TimeLimit							int				|	Set the time, in seconds, after which no commands are executed. By default, the time is not limited.
@pi_Delay								int				|	Set the delay, in seconds, between index commands. By default, there is no delay
@pi_WaitAtLowPriorityMaxDuration		int				|	The time, in minutes that an online index rebuild operation will wait for low priority locks.
																The WaitAtLowPriorityMaxDuration option in IndexOptimize uses the WAIT_AT_LOW_PRIORITY and MAX_DURATION options in the SQL Server ALTER INDEX command.
@pi_WaitAtLowPriorityAbortAfterWait		nvarchar(max)	|	The action that will be performed after an online index rebuild operation has been waiting for low priority locks.
															Examples:	NONE = Continue waiting for locks with normal priority. 
																		SELF = Abort the online index rebuild operation. 
																		BLOCKERS = Kill user transactions that block the online index rebuild operation. 
															The WaitAtLowPriorityAbortAfterWait option in IndexOptimize uses the WAIT_AT_LOW_PRIORITY and ABORT_AFTER_WAIT options in the SQL Server ALTER INDEX command.


***** parameters below control database integrity check execution *****
@pi_CheckCommands			nvarchar(max)	| Specify the integrity check commands to be performed.
												Examples:	CHECKDB = Check the database. This is the default. 
															CHECKFILEGROUP = Check the filegroups. 
															CHECKTABLE = Check the tables and the indexed views. 
															CHECKALLOC = Check the disk space allocation structures. 
															CHECKCATALOG = Check the catalog consistency. 
															CHECKALLOC,CHECKCATALOG = Check the disk space allocation structures and the catalog consistency. 
															CHECKFILEGROUP,CHECKCATALOG = Check the filegroups and the catalog consistency. 
															CHECKALLOC,CHECKTABLE,CHECKCATALOG = Check the disk space allocation structures, the tables and the indexed views, and the catalog consistency. 
@pi_PhysicalOnly			nvarchar(max)	| Limit the checks to the physical structures of the database.
												Y = Limit the checks to the physical structures of the database. 
												N = Do not limit the checks to the physical structures of the database. This is the default. 
@pi_NoIndex					nvarchar(max)	| Do not check nonclustered indexes.
												Y = Do not check nonclustered indexes. 
												N = Check nonclustered indexes. This is the default. 

@pi_ExtendedLogicalChecks	nvarchar(max)	| Perform extended logical checks.
												Y = Perform extended logical checks. 
												N = Do not perform extended logical checks. This is the default. 
@pi_TabLock					nvarchar(max)	| Use locks instead of an internal database snapshot.
												Y = Use locks to perform the consistency checks. 
												N = Use an internal database snapshot to perform the consistency checks. This is the default. 
@pi_FileGroups				nvarchar(max)	| Select filegroups. The ALL_FILEGROUPS keyword is supported. The hyphen character (-) is used to exclude filegroups, and the percent character (%) is used for wildcard selection. All these operations can be combined by using the comma (,).
												This option can be used only if CHECKFILEGROUPS is specified in the CheckCommands option
												Examples:	ALL_FILEGROUPS = All filegroups 
															Db1.FileGroup1 = The filegroup FileGroup1 in the database Db1 
															Db1.FileGroup1, Db2.FileGroup2 = The filegroup FileGroup1 in the database Db1 and the filegroup FileGroup2 in the database Db2 
															ALL_FILEGROUPS, -Db1.FileGroup1 = All filegroups except the filegroup FileGroup1 in the database Db1 
															Db1.%FileGroup% = All filegroups in the database Db1 that have �FileGroup� in the name 
@pi_Objects					nvarchar(max)	| Select objects. The ALL_OBJECTS keyword is supported. The hyphen character (-) is used to exclude objects, and the percent character (%) is used for wildcard selection. All these operations can be combined by using the comma (,).
												This option can be used only if CHECKTABLE is specified in the CheckCommands option.
												Examples:	ALL_OBJECTS = All objects 
															Db1.Schema1.Tbl1 = The object Schema1.Tbl1 in the database Db1 
															Db1.Schema1.Object1, Db2.Schema2.Object2 = The object Schema1.Tbl1 in the database Db1 and the object Schema2.Tbl2 in the database Db2 
															ALL_OBJECTS, -Db1.Schema1.Object1 All = objects except the object Schema1.Object1 in the database Db1 
															Db1.Schema1.% = All objects in the schema Schema1 in the database Db1 


***** parameters below control database backup execution *****
@pi_Directory			nvarchar(max)	| INPUT Location where the backups are to be placed. If NULL passed then will assume the server configuration. NULL (default)
@pi_BackupType			nvarchar(max)	| INPUT Type of backup; full, differential or transaction log backup.
										Examples: 1. FULL
												  2. DIFF
												  3. LOG
@pi_Verify				nvarchar(max)	| INPUT The Verify option in DatabaseBackup uses the SQL Server RESTORE VERIFYONLY command. (Y=Yes | N=No)
@pi_CleanupTime			int				| Specify the time, in hours, after which the backup files are deleted. If no time is specified, then no backup files are deleted.
@pi_Compress			nvarchar(max)	| Compress the backup. If no value is specified, then the backup compression default in sys.configurations is used.
											Examples:	NULL =	Use the backup compression default in sys.configurations. This is the default. 
														Y =		Compress the backup. 
														N =		Do not compress the backup. 
@pi_CopyOnly			nvarchar(max)	| Perform a copy-only backup.
											Y =	Perform a copy-only backup. 
											N =	Perform a normal backup. This is the default. 

@pi_ChangeBackupType	nvarchar(max)	| Change the backup type if a differential or transaction-log backup cannot be performed.
											Y =	Change the backup type if a backup cannot be performed. 
											N =	Skip the backup if a backup cannot be performed. This is the default. 
@pi_BackupSoftware		nvarchar(max)	| Specify third-party backup software; otherwise, SQL Server native backup is performed.
											NULL		=	SQL Server native backup (the default) 
											LITESPEED	=	LiteSpeed for SQL Server 
											SQLBACKUP	=	Red Gate SQL Backup 
											SQLSAFE		=	Idera SQL safe backup 

@pi_CheckSum			nvarchar(max)	|	Enable backup checksums.
											Y =	Enable backup checksums. 
											N =	Do not enable backup checksums. This is the default. 

@pi_BlockSize			int				| Specify the physical blocksize in bytes.
@pi_BufferCount			int				| Specify the number of I/O buffers to be used for the backup operation.
@pi_MaxTransferSize		int				| Specify the largest unit of transfer, in bytes, to be used between SQL Server and the backup media
@pi_NumberOfFiles		int				| Specify the number of backup files. The default is the number of backup directories and the maximum is 64 files.
@pi_CompressionLevel	int				| Set the LiteSpeed for SQL Server, Red Gate SQL Backup, or Idera SQL safe backup compression level.
											In LiteSpeed for SQL Server, the compression levels 0 to 8 are supported. In Red Gate SQL Backup, levels 0 to 4 are supported, and in Idera SQL safe backup, levels 1 to 4 are supported
@pi_Description			nvarchar(max)	| Enter a description for the backup.
@pi_Threads				int				| Specify the LiteSpeed for SQL Server, Red Gate SQL Backup, or Idera SQL safe backup number of threads. The maximum number of threads is 32.
@pi_Throttle			int				| Specify the LiteSpeed for SQL Server maximum CPU usage, as a percentage.
@pi_Encrypt				nvarchar(max)	| Encrypt the backup.
											Y =	Encrypt the backup. 
											N =	Do not encrypt the backup. This is the default. 
@pi_EncryptionAlgorithm	nvarchar(max)	| Specify the type of encryption.
											NULL			=	No encryption (the default) 
											RC2_40			=	RC2 40-bit encryption (LiteSpeed for SQL Server) 
											RC2_56			=	RC2 56-bit encryption (LiteSpeed for SQL Server) 
											RC2_112			=	RC2 112-bit encryption (LiteSpeed for SQL Server) 
											RC2_128			=	RC2 128-bit encryption (LiteSpeed for SQL Server) 
											TRIPLE_DES_3KEY	=	Triple DES encryption (SQL Server 2014 or LiteSpeed for SQL Server) 
											RC4_128			=	RC4 128-bit encryption (LiteSpeed for SQL Server) 
											AES_128			=	AES 128-bit encryption (SQL Server 2014, LiteSpeed for SQL Server, Red Gate SQL Backup, or Idera SQL safe backup) 
											AES_192			=	AES 192-bit encryption (SQL Server 2014 or LiteSpeed for SQL Server) 
											AES_256			=	AES 256-bit encryption (SQL Server 2014, LiteSpeed for SQL Server, Red Gate SQL Backup, or Idera SQL safe backup)
@pi_ServerCertificate	nvarchar(max)	| Server certificate that is used to encrypt the backup
											The ServerCertificate option in DatabaseBackup uses the ENCRYPTION and SERVER CERTIFICATE options in the SQL Server BACKUP command
@pi_ServerAsymmetricKey	nvarchar(max)	| Asymmetric key that is used to encrypt the backup.
											The ServerAsymmetricKey option in DatabaseBackup uses the ENCRYPTION and SERVER ASYMMETRIC KEY options in the SQL Server BACKUP command.
@pi_EncryptionKey		nvarchar(max)	| Key that is used to encrypt the backup. This is used with LiteSpeed for SQL Server, Red Gate SQL Backup, and Idera SQL safe backup. 
@pi_ReadWriteFileGroups	nvarchar(max)	| Perform a backup of the primary filegroup and any read/write filegroups.
											Y =	Perform a backup of the primary filegroup and any read/write filegroups. 
											N =	Perform a normal backup. This is the default. 

@pi_OverrideBackupPreference	nvarchar(max)	| Override the backup preference for availability groups. This option only applies to copy-only full backups and regular transaction log backups.
													Y =	Override the backup preference for availability groups. 
													N =	Do not override the backup preference for availability groups. This is the default. 

@pi_LogToTable			nvarchar(max)			| Log commands to the table dbo.CommandLog.
													Y =	Log commands to the table. 
													N =	Do not log commands to the table. This is the default. 

@pi_Execute				nvarchar(max)	| Execute commands. By default, the commands are executed normally. If this parameter is set to N, then the commands are printed only.


***** parameters below control email notifcation *****
@pi_PrimaryRecipient  INPUT Email address of the primary recipient.  (DEFAULT)
@pi_SecondaryRecipientINPUT Email address of the secondary recipient. 
@pi_OnCallRecipient   INPUT Email address to send email

------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
   Error Reason codes:  
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
   Return Value: 0
   Success : 0
   Failure : will be sent via email to DBA Team

   Revisions :
   --------------------------------------------------------------------------------
   Ini    | Date          | Description
   --------------------------------------------------------------------------------
                           
   ===================================================================================================================================================*/

-- Stops the message that shows the count of the number of rows affected by a
-- Transact-SQL statement or stored procedure from being returned as part of the result set
SET NOCOUNT ON;
DECLARE @EMAIL_RECEPIENTS VARCHAR(2000);

SET @EMAIL_RECEPIENTS = '';

SELECT @EMAIL_RECEPIENTS =  @EMAIL_RECEPIENTS + Recepients + ';' FROM dbo.EmailRecepientsList;

SET @EMAIL_RECEPIENTS  = LEFT (@EMAIL_RECEPIENTS,LEN(@EMAIL_RECEPIENTS)-1); 
SET @pi_PrimaryRecipient = @EMAIL_RECEPIENTS; 
DECLARE @cMAXXFERSIZE         bigint           ; SET @cMAXXFERSIZE = 65536;
DECLARE @TlogIsRunning        bit              ; SET @TlogIsRunning = 0;

DECLARE @ValidateCommand      nvarchar(255)     ; SET @ValidateCommand  = '';
DECLARE @DefaultDirectory     nvarchar(4000)    ; SET @DefaultDirectory = N'';  
DECLARE @CurrentDirectory     nvarchar(max)     ; SET @CurrentDirectory = NULL;
DECLARE @CurrentFilePath      nvarchar(max)     ; SET @CurrentFilePath = NULL;
DECLARE @ReturnCode integer                     ; SET @ReturnCode = 0;
DECLARE @DBCCInnerCallStackError integer		; SET @DBCCInnerCallStackError = 0;
DECLARE @IndexOptimzeInnerCallStackError integer; SET @IndexOptimzeInnerCallStackError = 0;
DECLARE @DatabaseBkupInnerCallStackError integer; SET @DatabaseBkupInnerCallStackError = 0;
DECLARE @OuterCallStackError integer            ; SET @OuterCallStackError = 0;
DECLARE @DatabaseFirstLogBkupError integer      ; SET @DatabaseFirstLogBkupError = 0;
DECLARE @DatabaseSecondLogBkupError integer     ; SET @DatabaseSecondLogBkupError = 0;
DECLARE @IndexMaintError integer                ; SET @IndexMaintError = 0;
DECLARE @DBCCError integer						; SET @DBCCError = 0;
DECLARE @DatabaseBkupError integer              ; SET @DatabaseBkupError = 0;
DECLARE @Log_Detail_ID integer                  ; SET @Log_Detail_ID = NULL;
DECLARE @Log_Detail_Text varchar(256)           ; SET @Log_Detail_Text = NULL;
DECLARE @Log_Diagnostic_Tx varchar(256)         ; SET @Log_Diagnostic_Tx = NULL;
DECLARE @Status nvarchar(128)                   ;
DECLARE @UserAccess nvarchar(128)               ;
DECLARE @IsInStandByFlag char(1)                ;
DECLARE @Updateability nvarchar(128)            ;

DECLARE @ErrorMessage         nvarchar(max)    ; SET @ErrorMessage = N'';
DECLARE @ErrorSeverity        integer          ; SET @ErrorSeverity = 0;
DECLARE @ErrorState           integer          ; SET @ErrorState = 0;
DECLARE @Error_Number         integer          ; SET @Error_Number = 0;
DECLARE @Error_Line           integer          ; SET @Error_Line = 0;
                               
DECLARE @CurrentAvailabilityGroup nvarchar(max);
DECLARE @CurrentAvailabilityGroupRole nvarchar(max);
DECLARE @CurrentAvailabilityGroupBackupPreference nvarchar(max);
DECLARE @CurrentIsPreferredBackupReplica bit;
DECLARE @CurrentIsFailoverReady bit;
DECLARE @Cluster nvarchar(max);


DECLARE @CurrentDBID integer                   ;
DECLARE @CurrentDatabase nvarchar(max)         ;

DECLARE @LogErrorMessage varchar(MAX)          ; SET @LogErrorMessage = '';

DECLARE @AlertMessage varchar(2000)            ; SET @AlertMessage = 'WARNING: Database maintenance did not complete successfully. Review the dbo.LOG_DETAIL table.';
DECLARE @MailSubject varchar(128)              ; SET @MailSubject = @@SERVERNAME + ': Database Maintenance Failure'
DECLARE @DBCCMessage varchar(2000)			   ; SET @DBCCMessage = 'URGENT: Database Integrity is at risk for database: ';

-- Log Level (LL) Error
DECLARE @LL_Error smallint                     ; SET @LL_Error = 1;
-- Log Level (LL) Warning
DECLARE @LL_Warning smallint                   ; SET @LL_Warning = 2;
-- Log Level (LL) Info
DECLARE @LL_Info smallint                      ; SET @LL_Info = 3;
-- Log Level (LL) Debug
DECLARE @LL_Debug smallint                     ; SET @LL_Debug = 4;
-- Log_Detail.Log_Detail_ID
DECLARE @po_Log_Detail_ID integer              ;
--Error reason code
DECLARE @po_Error_Reason_Cd integer            ;
                     
-- table variable to store list of databases
DECLARE @tmpDatabases TABLE ([ID] int IDENTITY PRIMARY KEY,
                             [DatabaseName] nvarchar(max),
                             [Completed] bit);


DECLARE @DirectoryInfo TABLE ([FileExists] bit,
                              [FileIsADirectory] bit,
                              [ParentDirectoryExists] bit);
                                                                
-- table variable to hold the LOG_DETAIL_ID out of the LOG_DETAIL table
DECLARE @LogTabeID TABLE (LOG_DETAIL_ID integer);

-- Table variable to hold error codes that will allow for retry of a failed maintenance
DECLARE @ErrorCodes TABLE (ErrorCode integer);

DECLARE @VersionMajor int;
DECLARE @VersionMinor int;
DECLARE @Edition int;

-- Capture SQL Server version and edition
;With CTE_SQLEditions([Major],[Minor],[Edition])
AS
(
select CAST(parsename(convert(varchar,serverproperty ('productversion')),4) As integer) As Major,
       CAST(parsename(convert(varchar,serverproperty ('productversion')),3) As integer) As Minor,
       CAST(serverproperty ('EngineEdition') As integer) As Edition
)
    
Select @VersionMajor = [Major]
     , @VersionMinor = [Minor]
	 , @Edition = [Edition]
FROM CTE_SQLEditions; 

IF @VersionMajor >= 11
BEGIN
    SELECT @Cluster = cluster_name
    FROM sys.dm_hadr_cluster;
END; 

                          
BEGIN TRY
	/******************************
	  Check input parameters
	*******************************/ 
    IF NOT LEN(@pi_databases) > 0
    BEGIN
        RAISERROR(80003,16,1,@pi_databases) WITH NOWAIT;
    END;
    
	IF @pi_FragmentationLevel1 <= 0 OR @pi_FragmentationLevel1 >= 100 OR @pi_FragmentationLevel1 >= @pi_FragmentationLevel2 OR @pi_FragmentationLevel1 IS NULL
	BEGIN
		SET @ErrorMessage = 'The value for the parameter @pi_FragmentationLevel1 is not supported.' + CHAR(13) + CHAR(10) + ' ';
		RAISERROR(@ErrorMessage,16,1) WITH NOWAIT;
	END;

	IF @pi_FragmentationLevel2 <= 0 OR @pi_FragmentationLevel2 >= 100 OR @pi_FragmentationLevel2 <= @pi_FragmentationLevel1 OR @pi_FragmentationLevel2 IS NULL
	BEGIN
		SET @ErrorMessage = 'The value for the parameter @pi_FragmentationLevel2 is not supported.' + CHAR(13) + CHAR(10) + ' ';
		RAISERROR(@ErrorMessage,16,1) WITH NOWAIT;
	END;

	IF @pi_PageCountLevel < 0 OR @pi_PageCountLevel IS NULL
	BEGIN
		SET @ErrorMessage = 'The value for the parameter @pi_PageCountLevel is not supported.' + CHAR(13) + CHAR(10) + ' ';
		RAISERROR(@ErrorMessage,16,1) WITH NOWAIT;
	END;

	IF @pi_SortInTempdb NOT IN('Y','N') OR @pi_SortInTempdb IS NULL
	BEGIN
	    SET @ErrorMessage = 'The value for the parameter @pi_SortInTempdb is not supported.' + CHAR(13) + CHAR(10) + ' ';
	    RAISERROR(@ErrorMessage,16,1) WITH NOWAIT;
	END;

	IF @pi_MaxDOP < 0 OR @pi_MaxDOP > 64 OR @pi_MaxDOP > (SELECT cpu_count FROM sys.dm_os_sys_info) OR (@pi_MaxDOP > 1 AND SERVERPROPERTY('EngineEdition') <> 3)
	BEGIN
	    SET @ErrorMessage = 'The value for the parameter @pi_MaxDOP is not supported.' + CHAR(13) + CHAR(10) + ' ';
	    RAISERROR(@ErrorMessage,16,1) WITH NOWAIT;
	END;

	IF @pi_FillFactor <= 0 OR @pi_FillFactor > 100
	BEGIN
	    SET @ErrorMessage = 'The value for the parameter @pi_FillFactor is not supported.' + CHAR(13) + CHAR(10) + ' ';
	    RAISERROR(@ErrorMessage,16,1) WITH NOWAIT;
	END;

	IF @pi_PadIndex NOT IN('Y','N')
	BEGIN
	    SET @ErrorMessage = 'The value for the parameter @pi_PadIndex is not supported.' + CHAR(13) + CHAR(10) + ' ';
	    RAISERROR(@ErrorMessage,16,1) WITH NOWAIT;
	END;

	IF @pi_LOBCompaction NOT IN('Y','N') OR @pi_LOBCompaction IS NULL
	BEGIN
	    SET @ErrorMessage = 'The value for the parameter @pi_LOBCompaction is not supported.' + CHAR(13) + CHAR(10) + ' ';
	    RAISERROR(@ErrorMessage,16,1) WITH NOWAIT;
	END;

	IF @pi_UpdateStatistics NOT IN('ALL','COLUMNS','INDEX')
	BEGIN
	    SET @ErrorMessage = 'The value for the parameter @pi_UpdateStatistics is not supported.' + CHAR(13) + CHAR(10) + ' ';
	    RAISERROR(@ErrorMessage,16,1) WITH NOWAIT;
	END;

	IF @pi_OnlyModifiedStatistics NOT IN('Y','N') OR @pi_OnlyModifiedStatistics IS NULL
	BEGIN
	    SET @ErrorMessage = 'The value for the parameter @pi_OnlyModifiedStatistics is not supported.' + CHAR(13) + CHAR(10) + ' ';
	    RAISERROR(@ErrorMessage,16,1) WITH NOWAIT;
	END

	IF @pi_StatisticsSample <= 0 OR @pi_StatisticsSample  > 100
	BEGIN
	    SET @ErrorMessage = 'The value for the parameter @pi_StatisticsSample is not supported.' + CHAR(13) + CHAR(10) + ' ';
	    RAISERROR(@ErrorMessage,16,1) WITH NOWAIT;
	END;

	IF @pi_StatisticsResample NOT IN('Y','N') OR @pi_StatisticsResample IS NULL OR (@pi_StatisticsResample = 'Y' AND @pi_StatisticsSample IS NOT NULL)
	BEGIN
	    SET @ErrorMessage = 'The value for the parameter @StatisticsResample is not supported.' + CHAR(13) + CHAR(10) + ' ';
	    RAISERROR(@ErrorMessage,16,1) WITH NOWAIT;
	END

	IF @pi_PartitionLevel NOT IN('Y','N') OR @pi_PartitionLevel IS NULL OR (@pi_PartitionLevel = 'Y' AND SERVERPROPERTY('EngineEdition') <> 3)
	BEGIN
	    SET @ErrorMessage = 'The value for the parameter @pi_PartitionLevel is not supported.' + CHAR(13) + CHAR(10) + ' ';
	    RAISERROR(@ErrorMessage,16,1) WITH NOWAIT;
	END;

	IF @pi_MSShippedObjects NOT IN('Y','N') OR @pi_MSShippedObjects IS NULL
	BEGIN
	    SET @ErrorMessage = 'The value for the parameter @pi_MSShippedObjects is not supported.' + CHAR(13) + CHAR(10) + ' ';
	    RAISERROR(@ErrorMessage,16,1) WITH NOWAIT;
	END;

	IF @pi_TimeLimit < 0
	BEGIN
	    SET @ErrorMessage = 'The value for the parameter @pi_TimeLimit is not supported.' + CHAR(13) + CHAR(10) + ' ';
	    RAISERROR(@ErrorMessage,16,1) WITH NOWAIT;
	END;

	IF @pi_Delay < 0
	BEGIN
	    SET @ErrorMessage = 'The value for the parameter @pi_Delay is not supported.' + CHAR(13) + CHAR(10) + ' ';
	    RAISERROR(@ErrorMessage,16,1) WITH NOWAIT;
	END;

	IF @pi_LockTimeout < 0
	BEGIN
	    SET @ErrorMessage = 'The value for the parameter @pi_LockTimeout is not supported.' + CHAR(13) + CHAR(10) + ' ';
	    RAISERROR(@ErrorMessage,16,1) WITH NOWAIT;
	END;

	IF @pi_LogToTable NOT IN('Y','N') OR @pi_LogToTable IS NULL
	BEGIN
	    SET @ErrorMessage = 'The value for the parameter @pi_LogToTable is not supported.' + CHAR(13) + CHAR(10) + ' ';
	    RAISERROR(@ErrorMessage,16,1) WITH NOWAIT;
	END;

	IF @pi_Execute NOT IN('Y','N') OR @pi_Execute IS NULL
	BEGIN
	    SET @ErrorMessage = 'The value for the parameter @pi_Execute is not supported.' + CHAR(13) + CHAR(10) + ' ';
	    RAISERROR(@ErrorMessage,16,1) WITH NOWAIT;
	END;


 -- /******************************************************************************************************* 
 --    check @pi_backuptype is valid
 -- ********************************************************************************************************/   
 -- IF UPPER(@pi_backuptype) NOT IN ('FULL','DIFF')
	--BEGIN                   				
 --     RAISERROR(80009,16,1,@pi_backuptype) WITH NOWAIT;		
	--END

 -- /*******************************************************************************************************
 --   Build databases list
 --   report on any databases not valid on the server
 -- ********************************************************************************************************/       
  INSERT INTO @tmpDatabases (DatabaseName, Completed)
  SELECT DatabaseName AS DatabaseName,
         0 AS Completed
    FROM dbo.f_admGetDatabaseList (@pi_databases)
   ORDER BY DatabaseName ASC; 
    
  IF @@ERROR <> 0 OR (@@ROWCOUNT = 0 AND @pi_databases <> 'USER_DATABASES')
  BEGIN
      RAISERROR(80022,16,1) WITH NOWAIT;
  END;    


  /******************************************************************************************************* 
   Get default backup directory.                                                              
  ********************************************************************************************************/  
  --IF @pi_Directory IS NULL
  --BEGIN TRY
  --    EXECUTE [master].dbo.xp_instance_regread N'HKEY_LOCAL_MACHINE', N'SOFTWARE\Microsoft\MSSQLServer\MSSQLServer', N'BackupDirectory', @DefaultDirectory OUTPUT;
  --    SET @pi_Directory = @DefaultDirectory;
  --END TRY
  --BEGIN CATCH
  --    RAISERROR(80016,16,1,@pi_Directory) WITH NOWAIT;
  --END CATCH;
  
  --/******************************************************************************************************* 
  --     check @pi_backupfldr
  --********************************************************************************************************/
  --IF NOT (@pi_Directory LIKE '_:' OR @pi_Directory LIKE '_:\%' OR @pi_Directory LIKE '\\%\%') 
  --    OR CHARINDEX(CHAR(32),@pi_Directory)>0
  --BEGIN
  --    RAISERROR(80001,16,1,@pi_Directory) WITH NOWAIT;
  --END;
   
  --SET @ValidateCommand = 'EXECUTE master..xp_fileexist N''' + REPLACE(@pi_Directory,'''','''''') + ''''
   
  --INSERT INTO @DirectoryInfo (FileExists, FileIsADirectory, ParentDirectoryExists)
  --EXECUTE(@ValidateCommand);

  --IF NOT EXISTS (SELECT * FROM @DirectoryInfo WHERE FileExists = 0 AND FileIsADirectory = 1 AND ParentDirectoryExists = 1)
  --BEGIN
  --    RAISERROR(80000,16,1,@pi_Directory) WITH NOWAIT;
  --END;
   
  --/******************************************************************************************************* 
  --  Validate that the value for MaxTransferSize is a mulitple of 65536
  --  any fall between 64K and 4MB
  --********************************************************************************************************/
  --IF @pi_MaxTransferSize IS NOT NULL AND @pi_MaxTransferSize NOT BETWEEN 65536 AND 4194304
  --BEGIN
  --    RAISERROR(80025, 16,1,@pi_MaxTransferSize);
  --END
  --ELSE IF @pi_MaxTransferSize IS NOT NULL AND @pi_MaxTransferSize BETWEEN 65536 AND 4194304
  --BEGIN
  --    IF (@cMAXXFERSIZE % @pi_MaxTransferSize) <> @cMAXXFERSIZE
  --    BEGIN
  --        RAISERROR(80026, 16,1, @pi_MaxTransferSize) WITH NOWAIT;
  --    END;
  --END;
  
  --/******************************************************************************************************* 
  -- Validate that the value for Buffer Count is between an acceptable range
  --********************************************************************************************************/    
  --IF @pi_BufferCount IS NOT NULL AND @pi_BufferCount NOT BETWEEN 1 AND 60
  --BEGIN
  --    RAISERROR(80028, 16,1,@pi_BufferCount);
  --END;

  
	/******************************************************************************************************* 
     Validate that the value for TABLOCK is between an acceptable range
  ********************************************************************************************************/    
  --IF @pi_TabLock IS NOT NULL AND @pi_TabLock NOT IN ('Y', 'N')
  --BEGIN
  --    RAISERROR(80029, 16,1,@pi_TabLock);
  --END;
    
 
  --/******************************************************************************************************* 
  --    If Compression set, verify compression is supported
  --********************************************************************************************************/
  --IF @pi_Compress NOT IN ('Y','N')
  --BEGIN
  --    SET @ErrorMessage = 'The value for parameter @pi_Compress is not supported.' + CHAR(13) + CHAR(10);
  
    
	 -- Select @ErrorMessage = @ErrorMessage +
		--							   CASE 
		--							   WHEN @pi_Compress = 'Y' AND @VersionMajor = 9  -- SQL 2005
		--								 THEN 'Backup compression is only supported in SQL Server 2008 or newwer.' + CHAR(13) + CHAR(10)
		--							   WHEN @pi_Compress = 'Y' AND @VersionMajor = 10 And @VersionMinor = 0 AND @Edition <> 3 -- SQL 2008 R1
		--								 THEN 'Backup compression is only supported in SQL Server 2008 Enterprise edtion.' + CHAR(13) + CHAR(10)
		--							   WHEN @pi_Compress = 'Y' AND @VersionMajor = 12 And @VersionMinor = 0 AND @Edition <> 3 -- SQL 2014
		--								 THEN 'Backup compression is only supported in SQL Server 2014 Enterprise edtion.' + CHAR(13) + CHAR(10)
		--							   END;
  --    RAISERROR(@ErrorMessage, 16, 1) WITH NOWAIT;

  --END;
     
  --/******************************************************************************************************* 
  --    If Purge Backup time is not set
  --********************************************************************************************************/    
  --IF @pi_CleanupTime IS NOT NULL AND @pi_CleanupTime < 0
  --BEGIN
  --    RAISERROR(80027,16,1,@pi_Directory) WITH NOWAIT;
  --END;
  

    
    /***********************************************************************************************************************
      Main Processing
    ***********************************************************************************************************************/

    WHILE EXISTS (SELECT * FROM @tmpDatabases WHERE Completed = 0)
    BEGIN--begin while loop
        SELECT TOP 1 @CurrentDBID = [ID],
                     @CurrentDatabase = [DatabaseName]
          FROM @tmpDatabases
         WHERE Completed = 0
         ORDER BY [DatabaseName] DESC;

        /*****************************************************************************
		 If SQL Server version >= 2012 and instance is hosted on a WSFC configuration
		   For each database capture the
		     availability group name
			 current availability group role (primary or secondary)
			 current availability group backup preference 
		 
		 this data will be used to test where to execute database integrity checks.
		   (NOTE:  the standard is to run database integrity checks on the
		           secondary replica unless the secondary replica is down the run
				    on the primary replica
		*****************************************************************************/
		--IF @VersionMajor >= 11 AND @Cluster IS NOT NULL
		--BEGIN
		--	SELECT @CurrentAvailabilityGroup = availability_groups.name,
		--		   @CurrentAvailabilityGroupRole = dm_hadr_availability_replica_states.role_desc,
		--		   @CurrentAvailabilityGroupBackupPreference = UPPER(availability_groups.automated_backup_preference_desc)
		--	FROM sys.databases databases
		--	INNER JOIN sys.availability_databases_cluster availability_databases_cluster ON databases.group_database_id = availability_databases_cluster.group_database_id
		--	INNER JOIN sys.availability_groups availability_groups ON availability_databases_cluster.group_id = availability_groups.group_id
		--	INNER JOIN sys.dm_hadr_availability_replica_states dm_hadr_availability_replica_states ON availability_groups.group_id = dm_hadr_availability_replica_states.group_id AND databases.replica_id = dm_hadr_availability_replica_states.replica_id
		--	WHERE databases.name = @CurrentDatabase

		--	 SELECT @CurrentIsFailoverReady = is_failover_ready
		--	   FROM sys.dm_hadr_database_replica_cluster_states drcs inner join sys.availability_replicas ar on drcs.replica_id = ar.replica_id
		--	  WHERE database_name = @CurrentDatabase 
		--		AND replica_server_name <> @@servername;

		--	IF @CurrentAvailabilityGroup IS NOT NULL
		--	BEGIN
		--		SELECT @CurrentIsPreferredBackupReplica = sys.fn_hadr_backup_is_preferred_replica(@CurrentDatabase);
		--	END;
		--END;

            
        IF DATABASEPROPERTYEX(@CurrentDatabase,'Status') = 'ONLINE'
           AND NOT (DATABASEPROPERTYEX(@CurrentDatabase,'UserAccess') = 'SINGLE_USER')
        BEGIN--begin processing database
		
		    IF @pi_opts & 2 = 2 
			  --  AND DATABASEPROPERTYEX(@CurrentDatabase,'IsInStandBy') = 0
              --  AND DATABASEPROPERTYEX(@CurrentDatabase,'Updateability') = 'READ_WRITE'
		   BEGIN --begin index optimize step
		    BEGIN TRY --begin TRY index optimize step

  --              SET @ReturnCode = 0;
		            --Need to create a transaction log backup first
					--EXECUTE @ReturnCode = dbo.DatabaseBackup
					--		 @Databases 				=	@CurrentDatabase
					--		,@Directory					=	@pi_Directory 
					--		,@BackupType				=	N'LOG'
					--		,@Verify					=	@pi_Verify 
					--		,@CleanupTime				=	@pi_CleanupTime 
					--		,@Compress					=	@pi_Compress 
					--		,@CopyOnly					=	N'N' 
					--		,@ChangeBackupType			=	@pi_ChangeBackupType 
					--		,@BackupSoftware			=	@pi_BackupSoftware 
					--		,@CheckSum 					=	@pi_CheckSum 
					--		,@BlockSize 				=	@pi_BlockSize 
					--		,@BufferCount 				=	@pi_BufferCount 
					--		,@MaxTransferSize 			=	@pi_MaxTransferSize 
					--		,@NumberOfFiles 			=	@pi_NumberOfFiles 
					--		,@CompressionLevel 			=	@pi_CompressionLevel 
					--		,@Description 				=	N'Transaction Log backup before Index Maintenance' 
					--		,@Threads					=	@pi_Threads 
					--		,@Throttle 					=	@pi_Throttle 
					--		,@Encrypt 					=	@pi_Encrypt 
					--		,@EncryptionAlgorithm 		=	@pi_EncryptionAlgorithm 
					--		,@ServerCertificate 		=	@pi_ServerCertificate 
					--		,@ServerAsymmetricKey 		=	@pi_ServerAsymmetricKey 
					--		,@EncryptionKey 			=	@pi_EncryptionKey 
					--		,@ReadWriteFileGroups 		=	@pi_ReadWriteFileGroups 
					--		,@OverrideBackupPreference	=	@pi_OverrideBackupPreference
					--		,@LogToTable 				=	@pi_LogToTable
					--		,@Execute					=	@pi_Execute;


            
                -- if procedure p_admDatabaseBackup return a non-zero condition code                                              
                --IF @ReturnCode <> 0 
                --BEGIN --begin first backup log error handler                   
                --    SET @DatabaseFirstLogBkupError = 1;
                    
                --    SET @Log_Diagnostic_Tx = 'Failed running first backup log for database ( ' + @CurrentDatabase + ' ).'
                                  
                --    SET @Log_Detail_Text = 'Backups were processing for Database ( ' + @CurrentDatabase + ' ).'
                
                --    -- Log error to the Log_Detail table
                --    Exec dbo.LogEntry 
                --        @LL_Error, -- Log_Level_ID
                --        NULL, -- Organization_ID
                --        NULL, -- UserID
                --        'p_admDatabaseMaintenance_Wrapper', -- Procedure_Name
                --        @Log_Detail_Text,  -- Log_Detail_Text
                --        0, -- Log_Diagnostic_Num
                --        @Log_Diagnostic_Tx, -- Log_Diagnostic_Tx
                --        'First Log Bkup Error', -- Log_Reference_Tag
                --        @po_Log_Detail_ID = @po_Log_Detail_ID out, -- Log_Detail_ID
                --        @po_Error_Reason_Cd = @po_Error_Reason_Cd out; -- Error_Reason_Cd
                --    Set @ReturnCode = @po_Log_Detail_ID;
                
                --    -- capture and store the LOG_Detail_ID values. These will be used to inform the DBA which records to search on.
                --    INSERT INTO @LogTabeID (LOG_DETAIL_ID)
                --    SELECT @po_Log_Detail_ID;
                    
                --END; --end first backup log error handler		    
                 

                SET @ReturnCode = 0;
                --Perform index maintenance

		            EXECUTE @ReturnCode = dbo.IndexOptimize
											 @Databases							=	@CurrentDatabase
											,@FragmentationLow					=	@pi_FragmentationLow
											,@FragmentationMedium				=	@pi_FragmentationMedium
											,@FragmentationHigh					=	@pi_FragmentationHigh
											,@FragmentationLevel1				=	@pi_FragmentationLevel1
											,@FragmentationLevel2				=	@pi_FragmentationLevel2
											,@PageCountLevel					=	@pi_PageCountLevel
											,@SortInTempdb						=	@pi_SortInTempdb
											,@MaxDOP							=	@pi_MaxDOP
											,@FillFactor						=	@pi_FillFactor
											,@PadIndex							=	@pi_PadIndex
											,@LOBCompaction						=	@pi_LOBCompaction
											,@UpdateStatistics					=	@pi_UpdateStatistics
											,@OnlyModifiedStatistics			=	@pi_OnlyModifiedStatistics
											,@StatisticsSample					=	@pi_StatisticsSample
											,@StatisticsResample				=	@pi_StatisticsResample
											,@PartitionLevel					=	@pi_PartitionLevel
											,@MSShippedObjects					=	@pi_MSShippedObjects
											,@Indexes							=	@pi_Indexes
											,@TimeLimit							=	@pi_TimeLimit
											,@Delay								=	@pi_Delay
											,@WaitAtLowPriorityMaxDuration		=	@pi_WaitAtLowPriorityMaxDuration
											,@WaitAtLowPriorityAbortAfterWait	=	@pi_WaitAtLowPriorityAbortAfterWait
											,@LockTimeout						=	@pi_LockTimeout
											,@LogToTable						=	@pi_LogToTable
											,@Execute							=	@pi_Execute;  
            
                -- if procedure IndexOptimize return a non-zero condition code                                              
                IF @ReturnCode <> 0 
                BEGIN --Begin Index Optimize error handler
                    SET @IndexMaintError = 1;
                    
                    SET @Log_Diagnostic_Tx = 'Failed running IndexOptimize for database ( ' + @CurrentDatabase + ' ).'
                                  
                    SET @Log_Detail_Text = 'Index Maintenance was processing for Database ( ' + @CurrentDatabase + ' ). Check the commandlog table for further details.'
                
                    -- Log error to the Log_Detail table
                    Exec dbo.LogEntry 
                        @LL_Error, -- Log_Level_ID
                        NULL, -- Organization_ID
                        NULL, -- UserID
                        'p_admDatabaseMaintenance_Wrapper', -- Procedure_Name
                        @Log_Detail_Text,  -- Log_Detail_Text
                        0, -- Log_Diagnostic_Num
                        @Log_Diagnostic_Tx, -- Log_Diagnostic_Tx
                        'INNER Call Stack CATCH', -- Log_Reference_Tag
                        @po_Log_Detail_ID = @po_Log_Detail_ID out, -- Log_Detail_ID
                        @po_Error_Reason_Cd = @po_Error_Reason_Cd out; -- Error_Reason_Cd
                    Set @ReturnCode = @po_Log_Detail_ID;
                
                    -- capture and store the LOG_Detail_ID values. These will be used to inform the DBA which records to search on.
                    INSERT INTO @LogTabeID (LOG_DETAIL_ID)
                    SELECT @po_Log_Detail_ID;
                END; --End Index Optimize error handler    
       
            END TRY --end TRY index optimize step
            BEGIN CATCH --begin index optimze catch block
		      SET @IndexOptimzeInnerCallStackError = 1;
                 
                SET @Log_Detail_Text = 'Index Maintenance was processing for Database ( ' + @CurrentDatabase + ' ).'

				SELECT @Error_Number = ERROR_NUMBER(),
                       @ErrorMessage = ERROR_MESSAGE(),
                       @ErrorSeverity = ERROR_SEVERITY(),
                       @ErrorState = ERROR_STATE(),
                       @Error_Line = ERROR_LINE();
			    
                SET @Log_Detail_Text = @Log_Detail_Text + space(5) + @ErrorMessage;

                -- Log error to the Log_Detail table
                Exec dbo.LogEntry 
                    @LL_Error, -- Log_Level_ID
                    NULL, -- Organization_ID
                    NULL, -- UserID
                    'p_admDatabaseMaintenance_Wrapper', -- Procedure_Name
                    'IndexOptimze Call failure catch block',  -- Log_Detail_Text
                    0, -- Log_Diagnostic_Num
                    @Log_Detail_Text,                         -- Log_Diagnostic_Tx
                    'INNER Call Stack CATCH', -- Log_Reference_Tag
                    @po_Log_Detail_ID = @po_Log_Detail_ID out, -- Log_Detail_ID
                    @po_Error_Reason_Cd = @po_Error_Reason_Cd out; -- Error_Reason_Cd
                    Set @ReturnCode = @po_Log_Detail_ID;
                
                -- capture and store the LOG_Detail_ID values. These will be used to inform the DBA which records to search on.
                INSERT INTO @LogTabeID (LOG_DETAIL_ID)
                SELECT @po_Log_Detail_ID;
                 
		    END CATCH --end index optimze catch block
	        END--End index optimize step
            ELSE
            BEGIN--Begin database not available for index maintenance
      		    SET @Log_Detail_Text = 'Database ( ' + @CurrentDatabase + ' ) not available for INDEX maintenance.'
		    
		        SET @Status = CAST(DATABASEPROPERTYEX(@CurrentDatabase,'Status') AS NVARCHAR);
                SET @UserAccess = CAST(DATABASEPROPERTYEX(@CurrentDatabase,'UserAccess') AS NVARCHAR);
                SET @IsInStandByFlag = CASE DATABASEPROPERTYEX(@CurrentDatabase,'IsInStandBy') WHEN 1 THEN 'Y' ELSE 'N' END;
                SET @Updateability = CAST(DATABASEPROPERTYEX(@CurrentDatabase,'Updateability') AS NVARCHAR);
		    
		        SET @Log_Diagnostic_Tx = 'Database Properties: Status = ' + @Status + ' | UserAccess = ' + @UserAccess
		                           + ' | IsInStandBy = ' + @IsInStandByFlag + ' | UpdateAbility = ' + @Updateability;
		    
		        -- Log error to the Log_Detail table
                Exec dbo.LogEntry 
                    @LL_Info, -- Log_Level_ID
                    NULL, -- Organization_ID
                    NULL, -- UserID
                    'p_admDatabaseMaintenance_Wrapper', -- Procedure_Name
                    @Log_Detail_Text,  -- Log_Detail_Text
                    0, -- Log_Diagnostic_Num
                    @Log_Diagnostic_Tx,    -- Log_Diagnostic_Tx
                    'Test Database Online', -- Log_Reference_Tag
                    @po_Log_Detail_ID = @po_Log_Detail_ID out, -- Log_Detail_ID
                    @po_Error_Reason_Cd = @po_Error_Reason_Cd out; -- Error_Reason_Cd
                 Set @ReturnCode = @po_Log_Detail_ID;
                
            END;--End Database not available for index maintenance

			IF @pi_opts & 8 = 8
			BEGIN TRY --begin database backup step
						
				IF  @pi_opts & 4 = 4 
				--AND @pi_backuptype IN ('FULL','DIFF')
				AND (NOT (@CurrentAvailabilityGroup IS NOT NULL AND (@CurrentAvailabilityGroupRole = 'PRIMARY' OR @CurrentAvailabilityGroupRole IS NULL))
                AND  NOT (@CurrentAvailabilityGroup IS NOT NULL AND (@CurrentIsPreferredBackupReplica <> 1 OR @CurrentIsPreferredBackupReplica IS NULL))
                      OR (@CurrentAvailabilityGroup IS NOT NULL AND @CurrentIsFailoverReady <> 1))
                      OR 'Y' = UPPER(@pi_OverrideDBCCPreference)
	            BEGIN --begin dbcc integrity check step
			        SET @ReturnCode = 0;
				
					EXECUTE @ReturnCode = dbo.DatabaseIntegrityCheck
									 @Databases				=	@CurrentDatabase
									,@CheckCommands			=	@pi_CheckCommands
									,@PhysicalOnly			=	@pi_PhysicalOnly
									,@NoIndex				=	@pi_NoIndex
									,@ExtendedLogicalChecks	=	@pi_ExtendedLogicalChecks
									,@TabLock				=	@pi_TabLock
									,@FileGroups			=	@pi_FileGroups
									,@Objects				=	@pi_Objects
									,@LockTimeout			=	@pi_LockTimeout
									,@LogToTable			=	@pi_LogToTable
									,@Execute				=	@pi_Execute;

					IF (@ReturnCode <> 0)
					BEGIN
                        --begin log dbcc error
						SET @DBCCError = 1;

					    SET @Log_Detail_Text = 'Database Integrity Checks were processing for Database ( ' + @CurrentDatabase + ' ). Check CommandLog table and Agent Job log''s';
                        
                        -- Log error to the Log_Detail table
                        Exec dbo.LogEntry 
                            @LL_Error, -- Log_Level_ID
                            NULL, -- Organization_ID
                            NULL, -- UserID
                            'p_admDatabaseMaintenance_Wrapper', -- Procedure_Name
                            'DBCC Call failure catch block',  -- Log_Detail_Text
                            0, -- Log_Diagnostic_Num
                            @Log_Detail_Text,                         -- Log_Diagnostic_Tx
                            'INNER Call Stack CATCH', -- Log_Reference_Tag
                            @po_Log_Detail_ID = @po_Log_Detail_ID out, -- Log_Detail_ID
                            @po_Error_Reason_Cd = @po_Error_Reason_Cd out; -- Error_Reason_Cd
                            Set @ReturnCode = @po_Log_Detail_ID;
                           
                        -- capture and store the LOG_Detail_ID values. These will be used to inform the DBA which records to search on.
                        INSERT INTO @LogTabeID (LOG_DETAIL_ID)
                        SELECT @po_Log_Detail_ID;

                         RAISERROR(80015,16,1,@CurrentDatabase) WITH NOWAIT;
                    END;

			    END --end dbcc integrity check
				ELSE
                BEGIN--Begin database integrity check not available
                        --update the record for current database as completed.
		    
		                 SET @Log_Detail_Text = 'Database ( ' + @CurrentDatabase + ' ) not available for integrity checks.';
		    
		                 SET @Log_Diagnostic_Tx = 'Database AG Properties: Current Availability Group = ' + CAST(@CurrentAvailabilityGroup AS NVARCHAR) 
				                                + ' | Current Is Preferred Backup Replica = ' + CAST(@CurrentIsPreferredBackupReplica AS NVARCHAR)
		                                        + ' | Current Availability Group Role = ' + CAST(@CurrentAvailabilityGroupRole AS NVARCHAR)  
									            + ' | Current Is Failover Ready = ' + CAST(@CurrentIsFailoverReady AS NVARCHAR) ;
		    
		                 -- Log error to the Log_Detail table
						Exec dbo.LogEntry 
							@LL_Info, -- Log_Level_ID
							NULL, -- Organization_ID
							NULL, -- UserID
					 		'p_admDatabaseMaintenance_Wrapper', -- Procedure_Name
							@Log_Detail_Text,  -- Log_Detail_Text
							0, -- Log_Diagnostic_Num
							@Log_Diagnostic_Tx,    -- Log_Diagnostic_Tx
							'Test Database Integrity Check', -- Log_Reference_Tag
							@po_Log_Detail_ID = @po_Log_Detail_ID out, -- Log_Detail_ID
							@po_Error_Reason_Cd = @po_Error_Reason_Cd out; -- Error_Reason_Cd
							Set @ReturnCode = @po_Log_Detail_ID;
                
                END;--End database integrity check not available

	 
                    SET @ReturnCode = 0;
                    --perform database backup
						--EXECUTE @ReturnCode = dbo.DatabaseBackup
						--	 @Databases 				=	@CurrentDatabase
						--	,@Directory					=	@pi_Directory 
						--	,@BackupType				=	@pi_backuptype
						--	,@Verify					=	@pi_Verify 
						--	,@CleanupTime				=	@pi_CleanupTime 
						--	,@Compress					=	@pi_Compress 
						--	,@CopyOnly					=	@pi_CopyOnly
						--	,@ChangeBackupType			=	@pi_ChangeBackupType 
						--	,@BackupSoftware			=	@pi_BackupSoftware 
						--	,@CheckSum 					=	@pi_CheckSum 
						--	,@BlockSize 				=	@pi_BlockSize 
						--	,@BufferCount 				=	@pi_BufferCount 
						--	,@MaxTransferSize 			=	@pi_MaxTransferSize 
						--	,@NumberOfFiles 			=	@pi_NumberOfFiles 
						--	,@CompressionLevel 			=	@pi_CompressionLevel 
						--	,@Description 				=	@pi_Description 
						--	,@Threads					=	@pi_Threads 
						--	,@Throttle 					=	@pi_Throttle 
						--	,@Encrypt 					=	@pi_Encrypt 
						--	,@EncryptionAlgorithm 		=	@pi_EncryptionAlgorithm 
						--	,@ServerCertificate 		=	@pi_ServerCertificate 
						--	,@ServerAsymmetricKey 		=	@pi_ServerAsymmetricKey 
						--	,@EncryptionKey 			=	@pi_EncryptionKey 
						--	,@ReadWriteFileGroups 		=	@pi_ReadWriteFileGroups 
						--	,@OverrideBackupPreference	=	@pi_OverrideBackupPreference
						--	,@LogToTable 				=	@pi_LogToTable
						--	,@Execute					=	@pi_Execute;
                        
                    -- if procedure DatabaseBackup return a non-zero condition code                                              
                    IF @ReturnCode <> 0 
                    BEGIN --Begin Database Backup Error Handler              
                        SET @DatabaseBkupError = 1;
                        
                        SET @Log_Diagnostic_Tx = 'Failed running ' + @pi_backuptype + ' backup for database ( ' + @CurrentDatabase + ' ).'
                                  
                        SET @Log_Detail_Text = 'Backups were processing for Database ( ' + @CurrentDatabase + ' ). Check CommandLog table and Agent Job log''s'
                           
                        -- Log error to the Log_Detail table
                        Exec dbo.LogEntry 
                            @LL_Error, -- Log_Level_ID
                            NULL, -- Organization_ID
                            NULL, -- UserID
                            'DatabaseMaintenance_Wrapper', -- Procedure_Name
                            @Log_Detail_Text,  -- Log_Detail_Text
                            0, -- Log_Diagnostic_Num
                            @Log_Diagnostic_Tx, -- Log_Diagnostic_Tx
                            'INNER Call Stack CATCH', -- Log_Reference_Tag
                            @po_Log_Detail_ID = @po_Log_Detail_ID out, -- Log_Detail_ID
                            @po_Error_Reason_Cd = @po_Error_Reason_Cd out; -- Error_Reason_Cd
                        Set @ReturnCode = @po_Log_Detail_ID;
                        
                        -- capture and store the LOG_Detail_ID values. These will be used to inform the DBA which records to search on.
                        INSERT INTO @LogTabeID (LOG_DETAIL_ID)
                        SELECT @po_Log_Detail_ID;
                    END;--End Database Backup Error Handler      
                    
                    --Transaction Log backups are running for a the current processing database wait and then move on.
                    WHILE 1=1
                    BEGIN
                        IF EXISTS (SELECT 1 
                                     FROM sys.dm_exec_requests r 
                                    WHERE (r.command LIKE '%BACKUP DATABASE%' OR r.command LIKE '%DBCC%' OR r.command LIKE '%RESTORE%')
                                      AND r.session_id > 49
                                      AND UPPER(db_name(r.database_id)) = UPPER(@CurrentDatabase))
                        BEGIN
                            SET @TlogIsRunning = 1;
                            CONTINUE;
                        END
                        ELSE
                           BREAK;
                    END;
		            
                    SET @ReturnCode = 0;
                    IF @TlogIsRunning = 0 --ONLY if TLOG has not executed after maintenance
                        --Need to create a new transaction log dump after the successful database backup
		      --          EXECUTE @ReturnCode = dbo.DatabaseBackup
								-- @Databases 				=	@CurrentDatabase
								--,@Directory					=	@pi_Directory 
								--,@BackupType				=	N'LOG'
								--,@Verify					=	@pi_Verify 
								--,@CleanupTime				=	@pi_CleanupTime 
								--,@Compress					=	@pi_Compress 
								--,@CopyOnly					=	N'N' 
								--,@ChangeBackupType			=	@pi_ChangeBackupType 
								--,@BackupSoftware			=	@pi_BackupSoftware 
								--,@CheckSum 					=	@pi_CheckSum 
								--,@BlockSize 				=	@pi_BlockSize 
								--,@BufferCount 				=	@pi_BufferCount 
								--,@MaxTransferSize 			=	@pi_MaxTransferSize 
								--,@NumberOfFiles 			=	@pi_NumberOfFiles 
								--,@CompressionLevel 			=	@pi_CompressionLevel 
								--,@Description 				=	N'Transaction Log backup after Maintenance' 
								--,@Threads					=	@pi_Threads 
								--,@Throttle 					=	@pi_Throttle 
								--,@Encrypt 					=	@pi_Encrypt 
								--,@EncryptionAlgorithm 		=	@pi_EncryptionAlgorithm 
								--,@ServerCertificate 		=	@pi_ServerCertificate 
								--,@ServerAsymmetricKey 		=	@pi_ServerAsymmetricKey 
								--,@EncryptionKey 			=	@pi_EncryptionKey 
								--,@ReadWriteFileGroups 		=	@pi_ReadWriteFileGroups 
								--,@OverrideBackupPreference	=	@pi_OverrideBackupPreference
								--,@LogToTable 				=	@pi_LogToTable
								--,@Execute					=	@pi_Execute;
                    
                    -- if procedure p_admDatabaseBackup return a non-zero condition code                                              
                    IF @ReturnCode <> 0 
                    BEGIN --begin error handler for second backup log
                        SET @DatabaseSecondLogBkupError = 1;
                        
                        SET @Log_Diagnostic_Tx = 'Failed running secondary backup log for database ( ' + @CurrentDatabase + ' ).'
                                  
                        SET @Log_Detail_Text = 'Backups were processing for Database ( ' + @CurrentDatabase + ' ).'
                        
                        -- Log error to the Log_Detail table
                        Exec dbo.LogEntry 
                            @LL_Error, -- Log_Level_ID
                            NULL, -- Organization_ID
                            NULL, -- UserID
                            'p_admDatabaseMaintenance_Wrapper', -- Procedure_Name
                            @Log_Detail_Text,  -- Log_Detail_Text
                            0, -- Log_Diagnostic_Num
                            @Log_Diagnostic_Tx, -- Log_Diagnostic_Tx
                            'INNER Call Stack CATCH', -- Log_Reference_Tag
                            @po_Log_Detail_ID = @po_Log_Detail_ID out, -- Log_Detail_ID
                            @po_Error_Reason_Cd = @po_Error_Reason_Cd out; -- Error_Reason_Cd
                        Set @ReturnCode = @po_Log_Detail_ID;
                       
                        -- capture and store the LOG_Detail_ID values. These will be used to inform the DBA which records to search on.
                        INSERT INTO @LogTabeID (LOG_DETAIL_ID)
                        SELECT @po_Log_Detail_ID;
                        
                    END;--End error handler for second backup log
                END TRY--End database backup step
		        BEGIN CATCH--begin database backup catch
		            SET @DatabaseBkupInnerCallStackError = 1;
                
                    SET @Log_Detail_Text = 'Backups were processing for Database ( ' + @CurrentDatabase + ' ). Check CommandLog table and Agent Job log'

					SELECT @Error_Number = ERROR_NUMBER(),
                           @ErrorMessage = ERROR_MESSAGE(),
                           @ErrorSeverity = ERROR_SEVERITY(),
                           @ErrorState = ERROR_STATE(),
                           @Error_Line = ERROR_LINE();
                
				    
					SET @Log_Detail_Text = @Log_Detail_Text + @ErrorMessage;

                    -- Log error to the Log_Detail table
                    Exec dbo.LogEntry 
                        @LL_Error, -- Log_Level_ID
                        NULL, -- Organization_ID
                        NULL, -- UserID
                        'p_admDatabaseMaintenance_Wrapper', -- Procedure_Name
                        'Database Backup Call failure catch block',  -- Log_Detail_Text
                        0, -- Log_Diagnostic_Num
                        @Log_Detail_Text,                         -- Log_Diagnostic_Tx
                        'INNER Call Stack CATCH', -- Log_Reference_Tag
                        @po_Log_Detail_ID = @po_Log_Detail_ID out, -- Log_Detail_ID
                        @po_Error_Reason_Cd = @po_Error_Reason_Cd out; -- Error_Reason_Cd
                        Set @ReturnCode = @po_Log_Detail_ID;
                     
                    -- capture and store the LOG_Detail_ID values. These will be used to inform the DBA which records to search on.
                    INSERT INTO @LogTabeID (LOG_DETAIL_ID)
                     SELECT @po_Log_Detail_ID;

					/*******************************************************************************************************
					 Serious error condition occured which requires the production DBA to be paged.
					********************************************************************************************************/
					IF (@Error_Number = 80015)
					BEGIN
						SET @MailSubject = @@SERVERNAME + ': Database Integrity Check Alert. (' + @CurrentDatabase + ')';
						SET @DBCCMessage = @DBCCMessage + '(' + @CurrentDatabase + ')' + char(13) + char(10) + ' **** Operations phone the DBA ONCALL! ****';
						EXEC msdb.dbo.sp_send_dbmail 
									  @profile_name = ' Mail Profile',
									  @recipients = @pi_OnCallRecipient,
									  @copy_recipients = @pi_SecondaryRecipient,
									  @Subject = @MailSubject,
									  @Body = @DBCCMessage;
					END;
               		  
					END CATCH;--end database backup catch
                                                           
		        --Update the database to reflect processing completed
            UPDATE @tmpDatabases
            SET Completed = 1
            WHERE Completed = 0
            AND ID = @CurrentDBID;
                
        END--End processing database
        ELSE
        BEGIN--Begin database not available
            --update the record for current database as completed.
            UPDATE @tmpDatabases
               SET Completed = 1
            WHERE Completed = 0
              AND ID = @CurrentDBID;        
		    
		        SET @Log_Detail_Text = 'Database ( ' + @CurrentDatabase + ' ) not available for maintenance.'
		    
		        SET @Status = CAST(DATABASEPROPERTYEX(@CurrentDatabase,'Status') AS NVARCHAR);
                SET @UserAccess = CAST(DATABASEPROPERTYEX(@CurrentDatabase,'UserAccess') AS NVARCHAR);
                SET @IsInStandByFlag = CASE DATABASEPROPERTYEX(@CurrentDatabase,'IsInStandBy') WHEN 1 THEN 'Y' ELSE 'N' END;
                SET @Updateability = CAST(DATABASEPROPERTYEX(@CurrentDatabase,'Updateability') AS NVARCHAR);
		    
		        SET @Log_Diagnostic_Tx = 'Database Properties: Status = ' + @Status + ' | UserAccess = ' + @UserAccess
		                           + ' | IsInStandBy = ' + @IsInStandByFlag + ' | UpdateAbility = ' + @Updateability;
		    
		        -- Log error to the Log_Detail table
            Exec dbo.LogEntry 
                @LL_Info, -- Log_Level_ID
                NULL, -- Organization_ID
                NULL, -- UserID
                'p_admDatabaseMaintenance_Wrapper', -- Procedure_Name
                @Log_Detail_Text,  -- Log_Detail_Text
                0, -- Log_Diagnostic_Num
                @Log_Diagnostic_Tx,    -- Log_Diagnostic_Tx
                'Test Database Online', -- Log_Reference_Tag
                @po_Log_Detail_ID = @po_Log_Detail_ID out, -- Log_Detail_ID
                @po_Error_Reason_Cd = @po_Error_Reason_Cd out; -- Error_Reason_Cd
                Set @ReturnCode = @po_Log_Detail_ID;
                
        END;--End Database not available
                
        --Clear variables
        SET @CurrentDBID = NULL;
        SET @CurrentDatabase = NULL;
	    SET @Log_Detail_Text = NULL;
        SET @Log_Diagnostic_Tx = NULL;
        SET @ReturnCode = 0;
        SET @TlogIsRunning = 0; 
		SET @CurrentAvailabilityGroup = NULL;
        SET @CurrentAvailabilityGroupRole = NULL;
        SET @CurrentAvailabilityGroupBackupPreference = NULL;
        SET @CurrentIsPreferredBackupReplica = NULL;
    END; --End While Loop


END TRY
BEGIN CATCH
    SET @OuterCallStackError = 1;
               
    -- Roll back any active or uncommittable transactions before
    -- inserting information in the ErrorLog.
    -- XACT_STATE = 0 means there is no transaction and a commit or rollback operation would generate an error.
    -- XACT_STATE = -1 The transaction is in an uncommittable state
    IF XACT_STATE () <> 0
        BEGIN
            ROLLBACK TRANSACTION;
        END;

    -- Log error to the Log_Detail table
    Exec dbo.LogEntry 
        @LL_Error, -- Log_Level_ID
        NULL, -- Organization_ID
        NULL, -- UserID
        'p_admDatabaseMaintenance_Wrapper', -- Procedure_Name
        'Procedure failure catch block',  -- Log_Detail_Text
        0, -- Log_Diagnostic_Num
        NULL,                            -- Log_Diagnostic_Tx
        'CATCH', -- Log_Reference_Tag
        @po_Log_Detail_ID = @po_Log_Detail_ID out, -- Log_Detail_ID
        @po_Error_Reason_Cd = @po_Error_Reason_Cd out; -- Error_Reason_Cd
        Set @Log_Detail_ID = @po_Log_Detail_ID;


END CATCH;  

-- check if there are any errors to report 
IF (@IndexOptimzeInnerCallStackError <> 0 
    or @DatabaseBkupInnerCallStackError <> 0 
    or @OuterCallStackError <> 0
    or @DatabaseFirstLogBkupError <> 0
    or @DatabaseSecondLogBkupError <> 0
    or @IndexMaintError <> 0
    or @DatabaseBkupError <> 0)
BEGIN
    IF @OuterCallStackError <> 0
    BEGIN
        SET @AlertMessage = @AlertMessage + CHAR(13) + CHAR(10)
                          + 'Execute -> SELECT * FROM dbo.LOG_DETAIL WHERE Log_Detail_ID = ' + CAST(@Log_Detail_ID as varchar);
    END
    ELSE IF (@IndexOptimzeInnerCallStackError <> 0 
            or @DatabaseBkupInnerCallStackError <> 0
            or @DatabaseFirstLogBkupError <> 0
            or @DatabaseSecondLogBkupError <> 0
            or @IndexMaintError <> 0
            or @DatabaseBkupError <> 0 )           
    BEGIN
        DECLARE @MinLogID integer;
        DECLARE @MaxLogID integer;
        
        SELECT @MinLogID = min(LOG_DETAIL_ID),
               @MaxLogID = max(LOG_DETAIL_ID)
          FROM @LogTabeID;
        
        SET @AlertMessage = @AlertMessage + CHAR(13) + CHAR(10)
                          + 'Execute -> SELECT * FROM dbo.LOG_DETAIL WHERE Log_Detail_ID BETWEEN ' + CAST(@MinLogID as varchar) + ' AND ' + CAST(@MaxLogID as varchar);
    END;
    
    EXEC msdb.dbo.sp_send_dbmail 
              @profile_name = 'DBA_MAIL_PROFILE',
              @recipients = @pi_PrimaryRecipient,
              @Subject = @MailSubject,
              @Body = @AlertMessage
END;


GO


