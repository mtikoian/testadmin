/* 2005,2008,2008R2,2012 */

/*****************************************************************************************************
 * Script Information
 *----------------------------------------------------------------------------------------------------
 *		Author: VBANDI
 *		  Date: 3/14/2015
 * Description: Sets up the standard DBA alerts and operators for notification.
 *	   History:
 *****************************************************************************************************/
-- Setup DBA operator and alerts --
BEGIN TRY

	EXEC sp_configure 'Show Advanced Options',1;
	RECONFIGURE WITH OVERRIDE;
	
	EXEC sp_configure 'Agent XPs', 1;
	RECONFIGURE WITH OVERRIDE;    

    IF EXISTS (SELECT 1 FROM msdb.dbo.sysoperators WHERE name = 'DBA')
			EXEC msdb.dbo.sp_delete_operator @name = 'DBA';
			
    IF NOT EXISTS (SELECT 1 FROM MSDB.DBO.SYSOPERATORS WHERE NAME = 'DBA')
        EXEC msdb.dbo.sp_add_operator @name=N'DBA', --Operator Name
		        @enabled=1, 
		        @weekday_pager_start_time=90000, 
		        @weekday_pager_end_time=180000, 
		        @saturday_pager_start_time=90000, 
		        @saturday_pager_end_time=180000, 
		        @sunday_pager_start_time=90000, 
		        @sunday_pager_end_time=180000, 
		        @pager_days=0, 
		        @email_address=N'it_infra@pentegra.com', 
		        @category_name=N'[Uncategorized]';

	--SQL_SEV_17 # This severity indicates that an operation making SQL Server out of resources or exceeding defined limit. 
	--			That may be disk space or lock limit	    
    IF EXISTS (SELECT 1 FROM msdb.dbo.sysalerts WHERE name = 'SQL_SEV_17')
			EXEC msdb.dbo.sp_delete_alert @name ='SQL_SEV_17';
			
    EXEC msdb.dbo.sp_add_alert @name=N'SQL_SEV_17', 
		    @message_id=0, 
		    @severity=17, 
		    @enabled=1, 
		    @delay_between_responses=60, 
		    @include_event_description_in=1, 
		    @job_id=N'00000000-0000-0000-0000-000000000000'
	
    EXEC msdb.dbo.sp_add_notification @alert_name=N'SQL_SEV_17', @operator_name=N'DBA', @notification_method = 1

    IF EXISTS (SELECT 1 FROM msdb.dbo.sysalerts WHERE name = 'SQL_SEV_18')
			EXEC msdb.dbo.sp_delete_alert @name ='SQL_SEV_18';
	--SQL_SEV_18 # This error represents nonfatal internal software error.	
    EXEC msdb.dbo.sp_add_alert @name=N'SQL_SEV_18', 
		    @message_id=0, 
		    @severity=18, 
		    @enabled=1, 
		    @delay_between_responses=60, 
		    @include_event_description_in=1, 
		    @job_id=N'00000000-0000-0000-0000-000000000000'

    EXEC msdb.dbo.sp_add_notification @alert_name=N'SQL_SEV_18', @operator_name=N'DBA', @notification_method = 1

    --SQL_SEV_19 # This error represents some non-configurable internal 
	--			limit has been exceeded and the current batch process is terminated. 
    IF EXISTS (SELECT 1 FROM msdb.dbo.sysalerts WHERE name = 'SQL_SEV_19')
			EXEC msdb.dbo.sp_delete_alert @name ='SQL_SEV_19';
		
    EXEC msdb.dbo.sp_add_alert @name=N'SQL_SEV_19', 
		    @message_id=0, 
		    @severity=19, 
		    @enabled=1, 
		    @delay_between_responses=60, 
		    @include_event_description_in=1, 
		    @job_id=N'00000000-0000-0000-0000-000000000000'

    EXEC msdb.dbo.sp_add_notification @alert_name=N'SQL_SEV_19', @operator_name=N'DBA', @notification_method = 1

	--SQL_SEV_20 # This severity indicates current statement has encountered a problem and because of 
	--			this severity level client connection with SQL Server will be disconnected.
		IF EXISTS (SELECT 1 FROM msdb.dbo.sysalerts WHERE name = 'SQL_SEV_20')
			EXEC msdb.dbo.sp_delete_alert @name ='SQL_SEV_20';
		
    EXEC msdb.dbo.sp_add_alert @name=N'SQL_SEV_20', 
		    @message_id=0, 
		    @severity=20, 
		    @enabled=1, 
		    @delay_between_responses=60, 
		    @include_event_description_in=1, 
		    @job_id=N'00000000-0000-0000-0000-000000000000'

    EXEC msdb.dbo.sp_add_notification @alert_name=N'SQL_SEV_20', @operator_name=N'DBA', @notification_method = 1

		IF EXISTS (SELECT 1 FROM msdb.dbo.sysalerts WHERE name = 'SQL_SEV_21')
			EXEC msdb.dbo.sp_delete_alert @name ='SQL_SEV_21';

	EXEC msdb.dbo.sp_add_alert @name=N'SQL_SEV_21',
			@message_id=0,
			@severity=21,
			@enabled=1,
			@delay_between_responses=60,
			@include_event_description_in=1,
			@job_id=N'00000000-0000-0000-0000-000000000000';


	EXEC msdb.dbo.sp_add_notification @alert_name=N'SQL_SEV_21', @operator_name=N'DBA', @notification_method = 1;

		IF EXISTS (SELECT 1 FROM msdb.dbo.sysalerts WHERE name = 'SQL_SEV_22')
			EXEC msdb.dbo.sp_delete_alert @name ='SQL_SEV_22';

	EXEC msdb.dbo.sp_add_alert @name=N'SQL_SEV_22',
			@message_id=0,
			@severity=22,
			@enabled=1,
			@delay_between_responses=60,
			@include_event_description_in=1,
			@job_id=N'00000000-0000-0000-0000-000000000000';

	EXEC msdb.dbo.sp_add_notification @alert_name=N'SQL_SEV_22', @operator_name=N'DBA', @notification_method = 1;

	IF EXISTS (SELECT 1 FROM msdb.dbo.sysalerts WHERE name = 'SQL_SEV_23')
			EXEC msdb.dbo.sp_delete_alert @name ='SQL_SEV_23';

			EXEC msdb.dbo.sp_add_alert @name=N'SQL_SEV_23',
			@message_id=0,
			@severity=23,
			@enabled=1,
			@delay_between_responses=60,
			@include_event_description_in=1,
			@job_id=N'00000000-0000-0000-0000-000000000000';
 
	EXEC msdb.dbo.sp_add_notification @alert_name=N'SQL_SEV_23', @operator_name=N'DBA', @notification_method = 1;

		IF EXISTS (SELECT 1 FROM msdb.dbo.sysalerts WHERE name = 'SQL_SEV_24')
			EXEC msdb.dbo.sp_delete_alert @name ='SQL_SEV_24';

	EXEC msdb.dbo.sp_add_alert @name=N'SQL_SEV_24',
			@message_id=0,
			@severity=24,
			@enabled=1,
			@delay_between_responses=60,
			@include_event_description_in=1,
			@job_id=N'00000000-0000-0000-0000-000000000000';
 
	EXEC msdb.dbo.sp_add_notification @alert_name=N'SQL_SEV_24', @operator_name=N'DBA', @notification_method = 1;

		IF EXISTS (SELECT 1 FROM msdb.dbo.sysalerts WHERE name = 'SQL_SEV_25')
			EXEC msdb.dbo.sp_delete_alert @name ='SQL_SEV_25';
	EXEC msdb.dbo.sp_add_alert @name=N'SQL_SEV_25',
			@message_id=0,
			@severity=25,
			@enabled=1,
			@delay_between_responses=60,
			@include_event_description_in=1,
			@job_id=N'00000000-0000-0000-0000-000000000000';
 
	EXEC msdb.dbo.sp_add_notification @alert_name=N'SQL_SEV_25', @operator_name=N'DBA', @notification_method = 1;

		IF EXISTS (SELECT 1 FROM msdb.dbo.sysalerts WHERE name = 'Error Number 823')
			EXEC msdb.dbo.sp_delete_alert @name ='Error Number 823';
	EXEC msdb.dbo.sp_add_alert @name=N'Error Number 823',
			@message_id=823,
			@severity=0,
			@enabled=1,
			@delay_between_responses=60,
			@include_event_description_in=1,
			@job_id=N'00000000-0000-0000-0000-000000000000'
	
	EXEC msdb.dbo.sp_add_notification @alert_name=N'Error Number 823', @operator_name=N'DBA', @notification_method = 1;

		IF EXISTS (SELECT 1 FROM msdb.dbo.sysalerts WHERE name = 'Error Number 824')
			EXEC msdb.dbo.sp_delete_alert @name ='Error Number 824';
	
	EXEC msdb.dbo.sp_add_alert @name=N'Error Number 824',
			@message_id=824,
			@severity=0,
			@enabled=1,
			@delay_between_responses=60,
			@include_event_description_in=1,
			@job_id=N'00000000-0000-0000-0000-000000000000'
	
	EXEC msdb.dbo.sp_add_notification @alert_name=N'Error Number 824', @operator_name=N'DBA', @notification_method = 1;
 
 		IF EXISTS (SELECT 1 FROM msdb.dbo.sysalerts WHERE name = 'Error Number 825')
			EXEC msdb.dbo.sp_delete_alert @name ='Error Number 825';

	EXEC msdb.dbo.sp_add_alert @name=N'Error Number 825',
			@message_id=825,
			@severity=0,
			@enabled=1,
			@delay_between_responses=60,
			@include_event_description_in=1,
			@job_id=N'00000000-0000-0000-0000-000000000000'
	 
	EXEC msdb.dbo.sp_add_notification @alert_name=N'Error Number 825', @operator_name=N'DBA', @notification_method = 1;
    
    --SQL_Login_Failed # Login	Failures
		IF EXISTS (SELECT 1 FROM msdb.dbo.sysalerts WHERE name = 'SQL_Login_Failed')
			EXEC msdb.dbo.sp_delete_alert @name = 'SQL_Login_Failed';
			
		EXEC msdb.dbo.sp_add_alert @name=N'SQL_Login_Failed', 
				@message_id=18456, 
				@severity=0, 
				@enabled=1, 
				@delay_between_responses=60, 
				@include_event_description_in=1, 
				@category_name=N'[Uncategorized]', 
				@job_id=N'00000000-0000-0000-0000-000000000000'
				
		EXEC msdb.dbo.sp_add_notification @alert_name = N'SQL_Login_Failed', @operator_name = N'DBA', @notification_method = 1;



		--HA errors
		/* *************************************************************** */ 
		--EXEC msdb.dbo.sp_add_alert @name=N'HA Error - 35273',
		--  @message_id=35273, 
		--  @severity=0, 
		--  @enabled=1, 
		--  @delay_between_responses=0, 
		--  @include_event_description_in=1, 
		--  @job_id=N'00000000-0000-0000-0000-000000000000'
		--  GO
		--  EXEC msdb.dbo.sp_add_notification @alert_name=N'HA Error - 35273', 
		--	@operator_name=N'DBA', @notification_method = 1
		--  GO 
		--/* *************************************************************** */ 
		--EXEC msdb.dbo.sp_add_alert @name=N'HA Error - 35274',
		--  @message_id=35274, 
		--  @severity=0, 
		--  @enabled=1, 
		--  @delay_between_responses=0, 
		--  @include_event_description_in=1, 
		--  @job_id=N'00000000-0000-0000-0000-000000000000'
		--  GO
		--  EXEC msdb.dbo.sp_add_notification @alert_name=N'HA Error - 35274', 
		--	@operator_name=N'DBA', @notification_method = 1
		--  GO 
		--/* *************************************************************** */ 
		--EXEC msdb.dbo.sp_add_alert @name=N'HA Error - 35275',
		--  @message_id=35275, 
		--  @severity=0, 
		--  @enabled=1, 
		--  @delay_between_responses=0, 
		--  @include_event_description_in=1, 
		--  @job_id=N'00000000-0000-0000-0000-000000000000'
		--  GO
		--  EXEC msdb.dbo.sp_add_notification @alert_name=N'HA Error - 35275', 
		--	@operator_name=N'DBA', @notification_method = 1
		--  GO 
		--/* *************************************************************** */ 
		--EXEC msdb.dbo.sp_add_alert @name=N'HA Error - 35254',
		--  @message_id=35254, 
		--  @severity=0, 
		--  @enabled=1, 
		--  @delay_between_responses=0, 
		--  @include_event_description_in=1, 
		--  @job_id=N'00000000-0000-0000-0000-000000000000'
		--  GO
		--  EXEC msdb.dbo.sp_add_notification @alert_name=N'HA Error - 35254', 
		--	@operator_name=N'DBA', @notification_method = 1
		--  GO 
		--/* *************************************************************** */ 
		--EXEC msdb.dbo.sp_add_alert @name=N'HA Error - 35279',
		--  @message_id=35279, 
		--  @severity=0, 
		--  @enabled=1, 
		--  @delay_between_responses=0, 
		--  @include_event_description_in=1, 
		--  @job_id=N'00000000-0000-0000-0000-000000000000'
		--  GO
		--  EXEC msdb.dbo.sp_add_notification @alert_name=N'HA Error - 35279', 
		--	@operator_name=N'DBA', @notification_method = 1
		--  GO 
		--/* *************************************************************** */ 
		--EXEC msdb.dbo.sp_add_alert @name=N'HA Error - 35262',
		--  @message_id=35262, 
		--  @severity=0, 
		--  @enabled=1, 
		--  @delay_between_responses=0, 
		--  @include_event_description_in=1, 
		--  @job_id=N'00000000-0000-0000-0000-000000000000'
		--  GO
		--  EXEC msdb.dbo.sp_add_notification @alert_name=N'HA Error - 35262', 
		--	@operator_name=N'DBA', @notification_method = 1
		--  GO 
		--/* *************************************************************** */ 
		--EXEC msdb.dbo.sp_add_alert @name=N'HA Error - 35276',
		--  @message_id=35276, 
		--  @severity=0, 
		--  @enabled=1, 
		--  @delay_between_responses=0, 
		--  @include_event_description_in=1, 
		--  @job_id=N'00000000-0000-0000-0000-000000000000'
		--  GO
		--  EXEC msdb.dbo.sp_add_notification @alert_name=N'HA Error - 35276', 
		--	@operator_name=N'DBA', @notification_method = 1
		--  GO 
		/* *************************************************************** */ 


		EXEC msdb.dbo.sysmail_delete_principalprofile_sp @principal_name=N'guest', @profile_name=N'DBA_Mail_Profile'
EXEC msdb.dbo.sysmail_add_principalprofile_sp @principal_name=N'guest', @profile_name=N'DBA_Mail_Profile', @is_default=1

END TRY
BEGIN CATCH

    RAISERROR('Error occurred setting up operators and alerts.',16,1)
    
    DECLARE @errno INT,
                @errmsg VARCHAR(100),
                @errsev INT,
                @errstate INT ;

    SELECT   @errno = ERROR_NUMBER(),
             @errmsg = ERROR_MESSAGE(),
             @errsev = ERROR_SEVERITY(),
             @errstate = ERROR_STATE() ;
             
    RAISERROR(@errmsg,@errsev,@errstate);

END CATCH

--USE [msdb]
--EXEC msdb.dbo.sp_set_sqlagent_properties @email_save_in_sent_folder=0;
--EXEC master.dbo.xp_instance_regwrite N'HKEY_LOCAL_MACHINE', N'SOFTWARE\Microsoft\MSSQLServer\SQLServerAgent', N'UseDatabaseMail', N'REG_DWORD', 1;
--EXEC master.dbo.xp_instance_regwrite N'HKEY_LOCAL_MACHINE', N'SOFTWARE\Microsoft\MSSQLServer\SQLServerAgent', N'DatabaseMailProfile', N'REG_SZ', N'DBA_Profile';