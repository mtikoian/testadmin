USE msdb;
GO

DECLARE @JobName VARCHAR(4000);

SET @JobName = 'DBAdmin_Weekend_Maintenance_UserDatabases'

IF EXISTS (
		SELECT 1
		FROM msdb.dbo.sysjobs
		WHERE NAME = @JobName
		)
BEGIN
	EXEC sp_delete_job @job_name = @JobName;

	PRINT 'Deleted job ' + @JobName
END
ELSE
BEGIN
	PRINT 'Creating job ' + @JobName;
END
GO

BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'DBA' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'DBA'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'DBAdmin_Weekend_Maintenance_UserDatabases', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'Performs the following steps daily at 21:00 hours; update statistics, index maintenance, integrity checks', 
		@category_name=N'DBA', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [User Databases Weekend Maintenance]    Script Date: 3/27/2015 12:14:13 PM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'User Databases Weekend Maintenance', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec DBAdmin.dbo.p_admin_DatabaseMaintenance_Wrapper
@pi_Databases = ''User_DATABASES'',
@pi_opts = 14,
@pi_LockTimeout = NULL,
@pi_LogToTable = ''Y'',
@pi_Execute = ''Y'',

/* Index procedure input parameters */
@pi_FragmentationLow = NULL,
@pi_FragmentationMedium = ''INDEX_REORGANIZE,INDEX_REBUILD_ONLINE,INDEX_REBUILD_OFFLINE'',
@pi_FragmentationHigh = ''INDEX_REBUILD_ONLINE,INDEX_REBUILD_OFFLINE'',
@pi_FragmentationLevel1 = 1,
@pi_FragmentationLevel2 = 2,
@pi_PageCountLevel = 20,
@pi_SortInTempdb = ''N'',
@pi_MaxDOP = 1,
@pi_FillFactor = NULL,
@pi_PadIndex = NULL,
@pi_LOBCompaction = ''Y'',
@pi_UpdateStatistics = ''all'',
@pi_OnlyModifiedStatistics = ''Y'',
@pi_StatisticsSample = NULL,
@pi_StatisticsResample = ''N'',
@pi_PartitionLevel = ''n'',
@pi_MSShippedObjects = ''N'',
@pi_Indexes = NULL,
@pi_TimeLimit = NULL,
@pi_Delay = NULL,
@pi_WaitAtLowPriorityMaxDuration = NULL,
@pi_WaitAtLowPriorityAbortAfterWait = NULL,


/* Databse Integrity Check */
@pi_CheckCommands = ''CHECKDB'',
@pi_PhysicalOnly = ''N'',
@pi_NoIndex = ''Y'',
@pi_ExtendedLogicalChecks = ''N'',
@pi_TabLock = ''N'',
@pi_FileGroups = NULL,
@pi_Objects = NULL,


/* Database Backup input parameters */
@pi_Directory = '''',
@pi_BackupType = ''FULL'',
@pi_Verify = ''Y'',
@pi_CleanupTime = 24,
@pi_Compress = ''Y'',
@pi_CopyOnly = ''Y'',
@pi_ChangeBackupType = ''N'',
@pi_BackupSoftware = NULL,
@pi_CheckSum = ''Y'',
@pi_BlockSize = NULL,
@pi_BufferCount = NULL,
@pi_MaxTransferSize = NULL,
@pi_NumberOfFiles = 8,
@pi_CompressionLevel = NULL,
@pi_Description = NULL,
@pi_Threads = NULL,
@pi_Throttle = NULL,
@pi_Encrypt = ''N'',
@pi_EncryptionAlgorithm = NULL,
@pi_ServerCertificate = NULL,
@pi_ServerAsymmetricKey = NULL,
@pi_EncryptionKey  = NULL,
@pi_ReadWriteFileGroups = ''N'',
@pi_OverrideBackupPreference  = ''N'',

@pi_PrimaryRecipient = ''it_infra@pentegra.com'',
@pi_SecondaryRecipient  = ''it_infra@pentegra.com'',
@pi_OnCallRecipient  = ''it_infra@pentegra.com''', 
		@database_name=N'DBAdmin', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Weekly', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=64, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20150320, 
		@active_end_date=99991231, 
		@active_start_time=210000, 
		@active_end_time=235959
		--@schedule_uid=N'23340540-9c2b-464e-bd72-bf4e3870fa89'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO


