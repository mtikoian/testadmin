CREATE PROC dbo.BCPOUT AS
declare @header varchar(max),
        @details varchar(max),
        @CRLF char(2),
        @RowTerminator char(1)

set @CRLF = char(13) + char(10)
set @RowTerminator = '|'

-- generate a comma-separated list of the column names of the table        
set @header = stuff((
select ',' + name 
  from sys.columns
 where object_id = object_id('v_Type')  -- enter your table or view name here
 order by column_id
 FOR XML PATH('')
 ),1,1,'')
 
-- create a comma-delimited list of the columns in each row. 
-- NOTE: this is limited to 2GB
-- NOTE: you will need to specify each column in the select list as ',' + whatever conversion is necessary to make it a character
-- NOTE: the last column needs a "row terminator" added to it... in my case, I used "|", but you can use whatever you desire.
set @details = stuff((
select ',' + convert(varchar(10), ID) +
       ',' + ltrim(rtrim(ID_Value)) + @RowTerminator
  from dbo.v_Type
 FOR XML PATH('')
),1,1,'')  -- removes the first comma in the output

-- replace the "row terminators" (and comma for the first column of the next row) between rows with CRLF
-- replace the final "row terminator" with an empty string
set @details = replace(replace(@details, @RowTerminator + ',', @CRLF), @RowTerminator, '')

-- final result
select @header UNION ALL select @details


--bcp "execute "YourDatabaseName".dbo.BCPOut" queryout "Your OutputFile" -c -T -S"Your Server"