/*******************
drop table #MyFiles
drop table #MyDir
*******************/
--===== Assign a path for the files to be found
DECLARE @Path VARCHAR(1000)
    SET @Path = 'd:\' --Must be UNC if outside of server
--===== Table to hold all the directory info from xp_DirTree.
     -- Will have both file names and directory names.
 CREATE TABLE #MyDir
        (
        FileNum  INT IDENTITY (1,1) PRIMARY KEY CLUSTERED,
        LongName VARCHAR(1000),
        Depth    INT,
        IsFile   INT
        )
--===== Table to hold just file names and a number for
     -- loops without cursors
 CREATE TABLE #MyFiles
        (
        FileNum  INT IDENTITY (1,1),
        LongName VARCHAR(1000)
        )
--===== Store all the directory info for path just one level deep
     -- Syntax note: Master.dbo.xp_DirTree path,level,markfiles
     -- "level" should probably always be "1". "0" means "all levels".
     -- "markfiles" will produce extra column "file" if is not null or "0".
     -- Could stop demo here but we'll go on to make life easier...
 INSERT INTO #MyDir
        (LongName,Depth,IsFile)
   EXEC Master.dbo.xp_DirTree @Path,1,1
--===== Move just the file info to a separate table for ease of processing.
 INSERT INTO #MyFiles 
        (LongName)
 SELECT LongName
   FROM #MyDir
  WHERE IsFile = 1 --Can add other criteria to filter by extension, etc.
  ORDER BY LongName
--===== For demo purposes, display the file names
 SELECT * FROM #MyFiles