 CREATE FUNCTION dbo.AA99AA99
/*******************************************************************************
 Pupose:
 Give an integer value from 0 to 3,317,759,999 for a total of 3,317,760,000
 different values (about a billion more than the positive range of an INT),
 convert the integer to the AA99AA99 format where "A" is a letter of the 
 English Alphabet not including "I" or "O" and "9" is a digit from 0 to 9 in
 the decimal numbering system.

 Usage:
--===== Basic Syntax
 SELECT dbo.AA99AA99('1235')
;

 Revision History
 Rev 00 - 22 Apr 2015 - Jeff Moden
        - Initial creation and unit test.
        - Ref: http://www.sqlservercentral.com/Forums/Topic1678735-391-3.aspx

*******************************************************************************/
--===== Declare the I/O for this function
        (@N BIGINT)
RETURNS CHAR(8) WITH SCHEMABINDING AS
  BEGIN
 RETURN 
(
 SELECT Seq_AA99AA99 = 
        SUBSTRING(Str2,(@N/138240000)%LEN(Str2)+1,1) --LeftMost
      + SUBSTRING(Str2,(@N/5760000)%LEN(Str2)+1,1)
      + SUBSTRING(Str1,(@N/576000)%LEN(Str1)+1,1)
      + SUBSTRING(Str1,(@N/57600)%LEN(Str1)+1,1)
      + SUBSTRING(Str2,(@N/2400)%LEN(Str2)+1,1)
      + SUBSTRING(Str2,(@N/100)%LEN(Str2)+1,1)
      + SUBSTRING(Str1,(@N/10)%LEN(Str1)+1,1)
      + SUBSTRING(Str1,(@N/1)%LEN(Str1)+1,1) --RightMost
   FROM (SELECT '0123456789','ABCDEFGHJKLMNPQRSTUVWXYZ')d(Str1,Str2)
);
    END
;
