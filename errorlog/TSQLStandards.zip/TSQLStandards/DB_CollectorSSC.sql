
/****** Object:  Table [dbo].[servers]    Script Date: 07/02/2009 10:42:03 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[servers](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[name] [varchar](50) NULL,
	[WindowsVersion] [varchar](255) NULL,
	[ProductVersion] [varchar](50) NULL,
	[Edition] [varchar](100) NULL,
	[ProductLevel] [varchar](5) NULL,
	[Collation] [varchar](100) NULL,
	[IsIntegratedSecurityOnly] [bit] NULL,
	[LastUpdated] [datetime] NULL,
 CONSTRAINT [PK__servers__014935CB] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[servers] ADD  CONSTRAINT [df_servers_date]  DEFAULT (getdate()) FOR [LastUpdated]
GO



/****** Object:  Table [dbo].[databases]    Script Date: 07/02/2009 10:42:21 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[databases](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[serverid] [int] NOT NULL,
	[databaseid] [int] NOT NULL,
	[name] [varchar](255) NOT NULL,
	[compatibility] [int] NOT NULL,
	[size] [int] NULL,
	[collation] [varchar](255) NULL,
	[user_access] [varchar](255) NULL,
	[recovery_model] [varchar](255) NULL,
	[read_only] [bit] NULL,
	[LastUpdated] [datetime] NULL,
 CONSTRAINT [PK_databases] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[databases]  WITH CHECK ADD  CONSTRAINT [FK__databases__serve__0425A276] FOREIGN KEY([serverid])
REFERENCES [dbo].[servers] ([id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO

ALTER TABLE [dbo].[databases] CHECK CONSTRAINT [FK__databases__serve__0425A276]
GO

ALTER TABLE [dbo].[databases] ADD  CONSTRAINT [df_databases_date]  DEFAULT (getdate()) FOR [LastUpdated]
GO



/****** Object:  Table [dbo].[logins]    Script Date: 07/02/2009 10:42:42 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[logins](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[serverid] [int] NOT NULL,
	[name] [varchar](255) NOT NULL,
	[type] [varchar](5) NULL,
	[type_desc] [varchar](255) NULL,
	[sysadmin] [varchar](255) NOT NULL,
	[setupadmin] [varchar](255) NOT NULL,
	[securityadmin] [varchar](255) NOT NULL,
	[serveradmin] [varchar](255) NOT NULL,
	[processadmin] [varchar](255) NOT NULL,
	[diskadmin] [varchar](255) NOT NULL,
	[bulkadmin] [varchar](255) NOT NULL,
	[dbcreator] [varchar](255) NOT NULL,
	[LastUpdated] [datetime] NOT NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO



/****** Object:  Table [dbo].[Role_Membership]    Script Date: 07/02/2009 10:42:57 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[Role_Membership](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[serverid] [int] NOT NULL,
	[databaseid] [int] NOT NULL,
	[role] [varchar](255) NOT NULL,
	[user] [varchar](255) NOT NULL,
	[login] [varchar](255) NULL,
	[is_disabled] [bit] NULL,
	[LastUpdated] [datetime] NULL,
 CONSTRAINT [PK_Role_Membership] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[Role_Membership] ADD  CONSTRAINT [df_Role_Membership_date]  DEFAULT (getdate()) FOR [LastUpdated]
GO


/****** Object:  Table [dbo].[object_permissions]    Script Date: 07/02/2009 10:43:09 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[object_permissions](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[serverid] [int] NULL,
	[databaseid] [int] NULL,
	[class_desc] [varchar](255) NULL,
	[permission_name] [varchar](255) NULL,
	[state_desc] [varchar](255) NULL,
	[ObjectName] [varchar](255) NULL,
	[GranteeName] [varchar](255) NULL,
	[GrantorName] [varchar](255) NULL,
	[LastUpdated] [datetime] NULL,
 CONSTRAINT [PK_object_permissions] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[object_permissions] ADD  CONSTRAINT [df_object_permissions_date]  DEFAULT (getdate()) FOR [LastUpdated]
GO


/****** Object:  Table [dbo].[agentjobs]    Script Date: 07/02/2009 10:43:46 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[agentjobs](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[serverid] [int] NOT NULL,
	[name] [varchar](255) NOT NULL,
	[enabled] [bit] NOT NULL,
	[schedule] [varchar](50) NULL,
	[frequency] [varchar](100) NULL,
	[start_at] [char](8) NULL,
	[end_at] [char](8) NULL,
	[LastUpdated] [datetime] NOT NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO



-- load server info
set NOCOUNT on 

declare @servername varchar(255)
declare @serverid varchar(10)
declare @sql nvarchar(4000)

DECLARE _serverinfo CURSOR 
FOR    SELECT id,name FROM servers 
-- Open the cursor.
OPEN _serverinfo 
-- Loop through the partitions.
WHILE (1=1) 
BEGIN    
		FETCH NEXT FROM _serverinfo         
		INTO @serverid, @servername  

		IF @@FETCH_STATUS < 0 
		BREAK 



			set @sql =' 
			update servers 
			set WindowsVersion = cast((select * from OPENQUERY(['+@servername+'],''select case when substring(@@VERSION,patINDEX(''''%Windows%'''',@@VERSION),200) like ''''%5.1%'''' then replace(substring(@@VERSION,patINDEX(''''%Windows%'''',@@VERSION),200),''''NT 5.1'''',''''XP'''')
when substring(@@VERSION,patINDEX(''''%Windows%'''',@@VERSION),200) like ''''%5.0%'''' then replace(substring(@@VERSION,patINDEX(''''%Windows%'''',@@VERSION),200),''''NT 5.0'''',''''Server 2000'''')
when substring(@@VERSION,patINDEX(''''%Windows%'''',@@VERSION),200) like ''''%5.2%'''' then replace(substring(@@VERSION,patINDEX(''''%Windows%'''',@@VERSION),200),''''NT 5.2'''',''''Server 2003'''')
else  substring(@@VERSION,patINDEX(''''%Windows%'''',@@VERSION),200) End as win''))as varchar(255)),
			Productversion = cast((select * from OPENQUERY(['+@servername+'],''select serverproperty(''''ProductVersion'''')'')) as varchar(50)),
			Edition = cast((select * from OPENQUERY(['+@servername+'],''select serverproperty(''''Edition'''')'')) as varchar(100)),
			ProductLevel = cast((select * from OPENQUERY(['+@servername+'],''select serverproperty(''''ProductLevel'''')'')) as varchar(5)),
			Collation = cast((select * from OPENQUERY(['+@servername+'],''select serverproperty(''''Collation'''')'')) as varchar(100)),
			IsIntegratedSecurityOnly = cast((select * from OPENQUERY(['+@servername+'],''select serverproperty(''''IsIntegratedSecurityOnly'''')'')) as bit),
			LastUpdated = getdate()
			where id = '''+@serverid+'''
			'
			--print @sql
			exec sp_executesql @sql

END

CLOSE _serverinfo
DEALLOCATE _serverinfo 
GO

--load login info
set NOCOUNT on 

declare @servername varchar(255)
declare @serverid varchar(10)
declare @productversion varchar(255)
declare @sql nvarchar(4000)

DECLARE _logininfo CURSOR 
FOR    SELECT id,name,ProductVersion FROM servers 
-- Open the cursor.
OPEN _logininfo 
-- Loop through the partitions.
WHILE (1=1) 
BEGIN    
		FETCH NEXT FROM _logininfo         
		INTO @serverid, @servername, @productversion  

		IF @@FETCH_STATUS < 0 
		BREAK 


		IF substring(@productversion,1,charindex('.',@productversion)-1) = 8
			BEGIN
				set @sql =' 
				insert into logins(serverid,[name],sysadmin,setupadmin,securityadmin,serveradmin,processadmin,diskadmin,bulkadmin,dbcreator,lastupdated)
				select '+@serverid+',[name],sysadmin,setupadmin,securityadmin,serveradmin,processadmin,diskadmin,bulkadmin,dbcreator,getdate() from OPENQUERY(['+@servername+'],''select 
				name,
				IS_SRVROLEMEMBER(''''sysadmin'''',name)sysadmin,
				IS_SRVROLEMEMBER(''''setupadmin'''',name)setupadmin,
				IS_SRVROLEMEMBER(''''securityadmin'''',name)securityadmin,
				IS_SRVROLEMEMBER(''''serveradmin'''',name)serveradmin,
				IS_SRVROLEMEMBER(''''processadmin'''',name)processadmin,
				IS_SRVROLEMEMBER(''''diskadmin'''',name)diskadmin,
				IS_SRVROLEMEMBER(''''bulkadmin'''',name)bulkadmin,
				IS_SRVROLEMEMBER(''''dbcreator'''',name)dbcreator  from syslogins'')
				'
				--print @sql
				exec sp_executesql @sql
			END
		ELSE
			BEGIN

				set @sql =' 
				insert into logins(serverid,[name],[type],type_desc,sysadmin,setupadmin,securityadmin,serveradmin,processadmin,diskadmin,bulkadmin,dbcreator,lastupdated)
				select '+@serverid+',[name],[type],type_desc,sysadmin,setupadmin,securityadmin,serveradmin,processadmin,diskadmin,bulkadmin,dbcreator,getdate() from OPENQUERY(['+@servername+'],''select 
				name,
				type,
				type_desc,
				IS_SRVROLEMEMBER(''''sysadmin'''',name)sysadmin,
				IS_SRVROLEMEMBER(''''setupadmin'''',name)setupadmin,
				IS_SRVROLEMEMBER(''''securityadmin'''',name)securityadmin,
				IS_SRVROLEMEMBER(''''serveradmin'''',name)serveradmin,
				IS_SRVROLEMEMBER(''''processadmin'''',name)processadmin,
				IS_SRVROLEMEMBER(''''diskadmin'''',name)diskadmin,
				IS_SRVROLEMEMBER(''''bulkadmin'''',name)bulkadmin,
				IS_SRVROLEMEMBER(''''dbcreator'''',name)dbcreator  from sys.server_principals
				where type in (''''U'''',''''S'''',''''G'''')'')
				'
				--print @sql
				exec sp_executesql @sql
			END
END

CLOSE _logininfo
DEALLOCATE _logininfo 
GO

-- load agentjob info
set NOCOUNT on 

declare @servername varchar(255)
declare @serverid varchar(10)
declare @productversion varchar(255)
declare @sql nvarchar(4000)

DECLARE _agentinfo CURSOR 
FOR    SELECT id,name,productversion FROM servers 
-- Open the cursor.
OPEN _agentinfo 
-- Loop through the partitions.
WHILE (1=1) 
BEGIN    
		FETCH NEXT FROM _agentinfo         
		INTO @serverid, @servername,@productversion   

		IF @@FETCH_STATUS < 0 
		BREAK 
		
			
		IF substring(@productversion,1,charindex('.',@productversion)-1) = 8
			BEGIN
			
			set @sql = '
			insert into agentjobs(serverid,name,[enabled],schedule,frequency,start_at,end_at,LastUpdated)
			select '+@serverid+',a.name, a.enabled,   case b.freq_type  -- Daily, weekly, Monthly
			when 1    then ''Once''
					when 4    then ''Daily''
					when 8    then ''Wk '' -- For weekly, add in the days of the week
					+    case      freq_interval & 2 when 2 then ''M'' else '''' end  -- Monday
					+    case      freq_interval & 4 when 4 then ''Tu'' else '''' end -- Tuesday
					+    case      freq_interval & 8 when 8 then ''W'' else '''' end  -- etc
					+    case      freq_interval & 16 when 16 then ''Th'' else '''' end
					+    case      freq_interval & 32 when 32 then ''F'' else '''' end
					+    case      freq_interval & 64 when 64 then ''Sa'' else '''' end
					+    case      freq_interval & 1 when 1 then ''Su'' else '''' end
					when 16   then ''Mthly on day '' + convert(varchar(2), freq_interval) -- Monthly on a particular day
					when 32   then ''Mthly ''  -- The most complicated one, "every third Friday of the month" for example
					+ case b.freq_relative_interval 
						when 1 then ''Every First ''
						when 2 then ''Every Second ''
						when 4 then ''Every Third ''
						when 8 then ''Every Fourth ''
						when 16 then ''Every Last ''
					end
					+ case b.freq_interval	
						when 1 then ''Sunday'' 
						when 2 then ''Monday''
						when 3 then ''Tuesday'' 
						when 4 then ''Wednesday'' 
						when 5 then ''Thursday'' 
						when 6 then ''Friday'' 
						when 7 then ''Saturday'' 
						when 8 then ''Day'' 
						when 9 then ''Week day''
						when 10 then ''Weekend day''
					end	
				when 64   then ''Startup''	-- When SQL Server starts
				when 128 then ''Idle''		-- Whenever SQL Server gets bored
				else ''Err''			-- This should never happen
				end as schedule,
				case b.freq_subday_type		-- FOr when a job funs every few seconds, minutes or hours
					when 1    then ''Runs once at:''
					when 2    then ''every '' + convert(varchar(3), freq_subday_interval) + '' seconds''
					when 4    then ''every '' + convert(varchar(3), freq_subday_interval) + '' minutes''
					when 8    then ''every '' + convert(varchar(3), freq_subday_interval) + '' hours''
				end as frequency
				,    	substring (right (stuff ('' '', 1, 1, ''000000'') + convert(varchar(6),b.active_start_time), 6), 1, 2)
				+    '':''
				+ substring (
				right (stuff ('' '', 1, 1, ''000000'') + convert(varchar(6), b.active_start_time), 6) ,3 ,2)
				+    '':''
				+ substring (
				right (stuff ('' '', 1, 1, ''000000'') + convert(varchar(6),b.active_start_time), 6) ,5 ,2) as start_at

			,case	b.freq_subday_type
				when 1  then NULL  -- Ignore the end time if not a recurring job
				else	substring (right (stuff ('' '', 1, 1, ''000000'') + convert(varchar(6), b.active_end_time), 6), 1, 2)
				+    '':''
				+ substring (
				right (stuff ('' '', 1, 1, ''000000'') + convert(varchar(6), b.active_end_time), 6) ,3 ,2)
				+    '':''
				+ substring (
				right (stuff ('' '', 1, 1, ''000000'') + convert(varchar(6), b.active_end_time), 6) ,5 ,2) end as end_at,
				getdate()
			 from ['+@servername+'].msdb.dbo.sysjobs a
			inner join ['+@servername+'].msdb.dbo.sysjobschedules b
			on a.job_id = b.job_id
			--inner join msdb.dbo.sysschedules c
			--on b.schedule_id = c.schedule_id
			order	by a.name, start_at
			'
			--print @sql
			exec sp_executesql @sql
			END
		ELSE
			BEGIN
			
				set @sql = '
				insert into agentjobs(serverid,name,[enabled],schedule,frequency,start_at,end_at,LastUpdated)
				select '+@serverid+',a.name, a.enabled,   case c.freq_type  -- Daily, weekly, Monthly
						when 1    then ''Once''
						when 4    then ''Daily''
						when 8    then ''Wk '' -- For weekly, add in the days of the week
						+    case      freq_interval & 2 when 2 then ''M'' else '''' end  -- Monday
						+    case      freq_interval & 4 when 4 then ''Tu'' else '''' end -- Tuesday
						+    case      freq_interval & 8 when 8 then ''W'' else '''' end  -- etc
						+    case      freq_interval & 16 when 16 then ''Th'' else '''' end
						+    case      freq_interval & 32 when 32 then ''F'' else '''' end
						+    case      freq_interval & 64 when 64 then ''Sa'' else '''' end
						+    case      freq_interval & 1 when 1 then ''Su'' else '''' end
						when 16   then ''Mthly on day '' + convert(varchar(2), freq_interval) -- Monthly on a particular day
						when 32   then ''Mthly ''  -- The most complicated one, "every third Friday of the month" for example
						+ case c.freq_relative_interval 
							when 1 then ''Every First ''
							when 2 then ''Every Second ''
							when 4 then ''Every Third ''
							when 8 then ''Every Fourth ''
							when 16 then ''Every Last ''
						end
						+ case c.freq_interval	
							when 1 then ''Sunday'' 
							when 2 then ''Monday''
							when 3 then ''Tuesday'' 
							when 4 then ''Wednesday'' 
							when 5 then ''Thursday'' 
							when 6 then ''Friday'' 
							when 7 then ''Saturday'' 
							when 8 then ''Day'' 
							when 9 then ''Week day''
							when 10 then ''Weekend day''
						end	
					when 64   then ''Startup''	-- When SQL Server starts
					when 128 then ''Idle''		-- Whenever SQL Server gets bored
					else ''Err''			-- This should never happen
					end as schedule,
					case c.freq_subday_type		-- FOr when a job funs every few seconds, minutes or hours
						when 1    then ''Runs once at:''
						when 2    then ''every '' + convert(varchar(3), freq_subday_interval) + '' seconds''
						when 4    then ''every '' + convert(varchar(3), freq_subday_interval) + '' minutes''
						when 8    then ''every '' + convert(varchar(3), freq_subday_interval) + '' hours''
					end as frequency
					,    	substring (right (stuff ('' '', 1, 1, ''000000'') + convert(varchar(6),c.active_start_time), 6), 1, 2)
					+    '':''
					+ substring (
					right (stuff ('' '', 1, 1, ''000000'') + convert(varchar(6), c.active_start_time), 6) ,3 ,2)
					+    '':''
					+ substring (
					right (stuff ('' '', 1, 1, ''000000'') + convert(varchar(6),c.active_start_time), 6) ,5 ,2) as start_at

				,case	c.freq_subday_type
					when 1  then NULL  -- Ignore the end time if not a recurring job
					else	substring (right (stuff ('' '', 1, 1, ''000000'') + convert(varchar(6), c.active_end_time), 6), 1, 2)
					+    '':''
					+ substring (
					right (stuff ('' '', 1, 1, ''000000'') + convert(varchar(6), c.active_end_time), 6) ,3 ,2)
					+    '':''
					+ substring (
					right (stuff ('' '', 1, 1, ''000000'') + convert(varchar(6), c.active_end_time), 6) ,5 ,2) end as end_at,
					getdate()
				 from ['+@servername+'].msdb.dbo.sysjobs a
				inner join ['+@servername+'].msdb.dbo.sysjobschedules b
				on a.job_id = b.job_id
				inner join ['+@servername+'].msdb.dbo.sysschedules c
				on b.schedule_id = c.schedule_id
				order	by a.name, start_at
				'
				--print @sql
				EXEC sp_executesql @sql
			END

END

CLOSE _agentinfo 
DEALLOCATE _agentinfo 
GO


--load databases table

declare @serverid varchar(10)
declare @servername varchar(255)
declare	@servercollation varchar(255)
declare @productversion varchar(255)
declare @sql nvarchar(4000)

DECLARE _databaseinfo CURSOR 
FOR    SELECT id,name,ProductVersion,collation FROM servers 
-- Open the cursor.
OPEN _databaseinfo  
-- Loop through the partitions.
WHILE (1=1) 
BEGIN    
		FETCH NEXT FROM _databaseinfo          
		INTO @serverid, @servername,@productversion, @servercollation 

		IF @@FETCH_STATUS < 0 
		BREAK 


		IF substring(@productversion,1,charindex('.',@productversion)-1) = 8
			BEGIN

		set @sql = 'declare @PageSize varchar(10)
select @PageSize=v.low/1024.0
from ['+@servername+'].master.dbo.spt_values v
where v.number=1 and v.type=''E''

select '+@serverid+' as serverid,dbid,name as databasename,cmptlevel, convert(float,null) as Size, case 
				when CAST(status & 0x800 AS bit) = 1 then ''Restricted User''
				WHEN CAST(status & 0x1000 AS bit) = 1 THEN ''Single User''
				else ''Multi User'' end as user_access,
								 CAST(status & 0x400 AS bit) as read_only,
								 getdate()as lastupdated
into #tem
From ['+@servername+'].master.dbo.sysdatabases where dbid <> 2

declare @SQL varchar (8000)
set @SQL=''''

while exists (select * from #tem where size is null)
begin
select @SQL=''update #tem set size=(select round(sum(size)*''+@PageSize+''/1024,0) From ['+@servername+'].''+quotename(databasename)+''.dbo.sysfiles) where databasename=''''''+databasename+''''''''
from #tem
where size is null
exec (@SQL)
end

insert into security.dbo.databases (serverid,databaseid,name,compatibility,size,User_access, read_only,LastUpdated)
select * from #tem order by DatabaseName
drop table #tem

		'
		--print @sql
		EXEC sp_executesql @sql
			END
		ELSE
			BEGIN
				set @sql = '
				declare @PageSize varchar(10)
select @PageSize=v.low/1024.0
from ['+@servername+'].master.dbo.spt_values v
where v.number=1 and v.type=''E''

select '+@serverid+' as serverid,database_id,name as databasename,compatibility_level,convert(float,null) as Size,collation_name, USER_access_desc,recovery_model_desc,is_read_only ,getdate()as lastupdated
into #tem
From ['+@servername+'].master.sys.databases where database_id <> 2

declare @SQL varchar (8000)
set @SQL=''''

while exists (select * from #tem where size is null)
begin
select @SQL=''update #tem set size=(select round(sum(size)*''+@PageSize+''/1024,0) From ['+@servername+'].''+quotename(databasename)+''.dbo.sysfiles) where databasename=''''''+databasename+''''''''
from #tem
where size is null
exec (@SQL)
end

insert into security.dbo.databases (serverid,databaseid,name,compatibility,size,collation,User_access,recovery_model, read_only,LastUpdated)
select * from #tem order by DatabaseName
drop table #tem

				'
				
				--print @sql
				EXEC sp_executesql @sql
				END
END

CLOSE _databaseinfo  
DEALLOCATE _databaseinfo  
GO

-- load role_membership table

declare @databasename varchar(255)
declare @servername varchar(255)
declare @serverid varchar(10)
declare @compatibility varchar(10)
declare @dbid varchar(10)
declare @sql nvarchar(4000)


DECLARE _roleinfo CURSOR 
FOR    SELECT serverid,databaseid, compatibility FROM databases where lastupdated > getdate()-1--where serverid <> 26
-- Open the cursor.
OPEN _roleinfo 
-- Loop through the partitions.
WHILE (1=1) 
BEGIN    
		FETCH NEXT FROM _roleinfo        
		INTO @serverid, @dbid, @compatibility  

		IF @@FETCH_STATUS < 0 
		BREAK 

		select @databasename = [name] from databases where serverid = @serverid and databaseid = @dbid
		select @servername = [name] from servers where id = @serverid


		IF @compatibility = '80'
			BEGIN 
				--set @databasename = 'Budget'
				--set @servername = 'ARIEL'

				--select @serverid = id from servers where [name] = @servername
				--select @dbid = databaseid from databases where [name] = @databasename and serverid = @serverid


				set @sql = 
				/*
				'insert into role_membership(serverid,databaseid,[role],[user]) select distinct '''+@serverid+''' as serverid,'''+@dbid+''' as databaseid,c.name as Role_Name, b.name as [User_name] from ['+@servername+'].'+@databasename+'.sys.database_role_members a
				inner join ['+@servername+'].'+@databasename+'.sys.database_principals b on b.principal_id = a.member_principal_id
				inner join ['+@servername+'].'+@databasename+'.sys.database_principals c on c.principal_id = a.role_principal_id
				and b.type <> ''R'''
				*/
				'insert into role_membership(serverid,databaseid,[role],[user],[login]) select '''+@serverid+''' as serverid,'''+@dbid+''' as databaseid,a.name as rolename,c.name as username, d.name as login from ['+@servername+'].['+@databasename+'].dbo.sysusers a
				inner join ['+@servername+'].['+@databasename+'].dbo.sysmembers b
				on a.uid = b.groupuid
				inner join ['+@servername+'].['+@databasename+'].dbo.sysusers c
				on b.memberuid = c.uid
				inner join ['+@servername+'].master.dbo.syslogins d
				on c.sid = d.sid'

				--select @sql

				exec sp_executesql @sql

			END 

		ELSE
			BEGIN
								set @sql = 
				/*
				'insert into role_membership(serverid,databaseid,[role],[user]) select distinct '''+@serverid+''' as serverid,'''+@dbid+''' as databaseid,c.name as Role_Name, b.name as [User_name] from ['+@servername+'].'+@databasename+'.sys.database_role_members a
				inner join ['+@servername+'].'+@databasename+'.sys.database_principals b on b.principal_id = a.member_principal_id
				inner join ['+@servername+'].'+@databasename+'.sys.database_principals c on c.principal_id = a.role_principal_id
				and b.type <> ''R'''
				*/
				'insert into role_membership(serverid,databaseid,[role],[user],[login],is_disabled) select '''+@serverid+''' as serverid,'''+@dbid+''' as databaseid,a.name as rolename,c.name as username, d.name as login, e.is_disabled as is_disabled  from ['+@servername+'].['+@databasename+'].dbo.sysusers a
				inner join ['+@servername+'].['+@databasename+'].dbo.sysmembers b
				on a.uid = b.groupuid
				inner join ['+@servername+'].['+@databasename+'].dbo.sysusers c
				on b.memberuid = c.uid
				inner join ['+@servername+'].master.dbo.syslogins d
				on c.sid = d.sid
				inner join ['+@servername+'].master.sys.server_principals e
				on d.sid = e.sid '

				--select @sql

				exec sp_executesql @sql


			END

END

CLOSE _roleinfo
DEALLOCATE _roleinfo 
GO

--load object_permission table

declare @databasename varchar(255)
declare @servername varchar(255)
declare @serverid varchar(10)
declare @dbid varchar(10)
declare @sql nvarchar(4000)


DECLARE _perminfo CURSOR 
FOR    SELECT serverid,databaseid FROM databases where lastupdated > getdate()-1
-- Open the cursor.
OPEN _perminfo  
-- Loop through the partitions.
WHILE (1=1) 
BEGIN    
		FETCH NEXT FROM _perminfo        
		INTO @serverid, @dbid  

		IF @@FETCH_STATUS < 0 
		BREAK 

		select @databasename = [name] from databases where serverid = @serverid and databaseid = @dbid
		select @servername = [name] from servers where id = @serverid

 
SET @sql = '
insert into object_permissions(serverid,databaseid,class_desc,permission_name,state_desc,ObjectName,GranteeName,GrantorName)
select  '''+@serverid+''' as serverid,'''+@dbid+''' as databaseid,
CASE a.xtype 
		WHEN ''C'' THEN ''CHECK_CONSTRAINT''
		WHEN ''D'' THEN ''DEFAULT_CONSTRAINT''
		WHEN ''F'' THEN ''FOREIGN_KEY_CONSTRAINT''
		WHEN ''L'' THEN ''LOG''
		WHEN ''FN'' THEN ''SQL_SCALAR_FUNCTION''
		WHEN ''P'' THEN ''SQL_STORED_PROCEDURE''
		WHEN ''PK'' THEN ''PRIMARY_KEY_CONSTRAINT''
		WHEN ''RF'' THEN ''REPLICATION_FILTER_PROCEDURE''
		WHEN ''S'' THEN ''SYSTEM_TABLE''
		WHEN ''TR'' THEN ''SQL_TRIGGER''
		WHEN ''U'' THEN ''USER_TABLE''
		WHEN ''UQ'' THEN ''UNIQUE_CONSTRAINT''
		WHEN ''V'' THEN ''VIEW''
		WHEN ''X'' THEN ''EXTENDED_STORED_PROCEDURE''
		WHEN ''FS'' THEN ''CLR_SCALAR_FUNCTION''
		ELSE ''***UNDEFINED***''
END as type_desc,
CASE c.action 
		WHEN 26 THEN ''REFERENCES''
		WHEN 193 THEN ''SELECT''
		WHEN 195 THEN ''INSERT''
		WHEN 196 THEN ''DELETE''
		WHEN 197 THEN ''UPDATE''
		WHEN 198 THEN ''CREATE TABLE''
		WHEN 203 THEN ''CREATE DATABASE''
		WHEN 207 THEN ''CREATE VIEW''
		WHEN 222 THEN ''CREATE PROCEDURE''
		WHEN 224 THEN ''EXECUTE''
		WHEN 228 THEN ''BACKUP DATABASE''
		WHEN 233 THEN ''CREATE DEFAULT''
		WHEN 235 THEN ''BACKUP LOG''
		ELSE ''CREATE RULE'' 
END as permission_name,
CASE c.protecttype
	WHEN 205 THEN ''GRANT''
	ELSE ''DENY''
END as state_desc,
a.name as ObjectName,b.name as GranteeName, user_name(c.grantor) as GrantorName
FROM ['+@servername+'].['+@databasename+'].dbo.sysobjects a 
INNER JOIN ['+@servername+'].['+@databasename+'].dbo.sysprotects c
	ON a.id = c.id
INNER JOIN ['+@servername+'].['+@databasename+'].dbo.sysusers b
	ON c.uid = b.uid
'


/*
SELECT      ob.type_desc, dp.permission_name, dp.state_desc,ObjectName = OBJECT_NAME(major_id), GranteeName = grantee.name, GrantorName = grantor.name
FROM ['+@servername+'].['+@databasename+'].sys.database_permissions dp
JOIN ['+@servername+'].['+@databasename+'].sys.database_principals grantee 
on dp.grantee_principal_id = grantee.principal_id
JOIN ['+@servername+'].['+@databasename+'].sys.database_principals grantor 
on dp.grantor_principal_id = grantor.principal_id
JOIN ['+@servername+'].['+@databasename+'].sys.objects ob
on dp.major_id = ob.object_id
*/

EXEC sp_executesql @sql
END

CLOSE _perminfo 
DEALLOCATE _perminfo 
GO
