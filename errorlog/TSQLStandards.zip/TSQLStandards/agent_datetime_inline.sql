
CREATE FUNCTION dbo.agent_datetime_inline
(
@Date integer, 
@Time integer
)
RETURNS TABLE WITH SCHEMABINDING
AS RETURN 
SELECT
CONVERT(datetime,
CONVERT(nvarchar(4), @Date/ 10000) + N'-' + 
CONVERT(nvarchar(2),(@Date % 10000)/100) + N'-' +
CONVERT(nvarchar(2), @Date % 100) + N' ' + 
CONVERT(nvarchar(2), @Time / 10000) + N':' + 
CONVERT(nvarchar(2),(@Time % 10000)/100) + N':' + 
CONVERT(nvarchar(2), @Time % 100),
120) AS date_time

GO
