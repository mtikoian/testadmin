/****************************************************************************************
' Name		: 06_Encryption.sql
' Author	: Shalini Sharma
' Description	: This script for:
'                 1.) Update the RTODR Connection string in ODR_ODT_CONNECTION_INFORMATION
					  table and insert as encrypted data.
' Parameters	:
' Name				 [I/O]	Description
'---------------------------------------------------------------------------------------
'---------------------------------------------------------------------------------------
' Return Value	:        
' Success:                      [ O ]
' Failure                       [ O ]  
' Revisions:
' --------------------------------------------------------------------------------------
' Ini |	Date	   |	Description
' --------------------------------------------------------------------------------------
******************************************************************************************/
--Use <database_name, sysname, EnterpriseConfigDB>


USE [$(EntDBDatabaseName)]
GO

DECLARE @ApplicationName	varchar(30)
DECLARE @BankID				varchar(4)
DECLARE @ConnectionString	varchar(250)

SET @ApplicationName	= N'$(ApplicationName)'
SET @BankID				= N'$(MasterID)'
SET @ConnectionString   = N'$(ConnectionString)'

BEGIN TRY

	BEGIN TRANSACTION

	/*************** ENCRYPT SENSITIVE DATA *********************************/
	OPEN SYMMETRIC KEY ConnectionStringSymmetricKey
	DECRYPTION BY CERTIFICATE ConnectionStringCertificate

	UPDATE [ACS_ENT_SCHEMA].[ODR_ODT_CONNECTION_INFORMATION] 
	--'Data Source=<DBSERVER,,DBSERVER>;Initial Catalog=<RTODR_DB,,RTODR_DB>;Integrated Security=SSPI'
	SET Connection_String = EncryptByKey(Key_GUID('ConnectionStringSymmetricKey'), @ConnectionString)
	WHERE Bank_Id = @BankID
	AND Application_Nm = @ApplicationName
	CLOSE SYMMETRIC KEY ConnectionStringSymmetricKey;
END TRY

BEGIN CATCH
	PRINT 'error occured while connection string update'
	PRINT Error_message()
	PRINT Error_line()
	ROLLBACK TRAN
END CATCH

If @@Trancount >0
COMMIT TRAN


