/****************************************************************************************
' Name		: 07_Users_EnterpriseConfigDB.sql
' Author	: Shalini Sharma
' Description	: This procedure will:
'                 1.) Create the Login ID and User For EnterpriseConfigDB
'                 2.) Create the APPLICATIONUSER database role with in the
'                     appropriate database(EnterpriseConfigDB)
'				  3.) Create schema for EnterpriseConfigDB
'				  4.) Assign the user to urole
'				  5.) Making the prole as owner of the schema
' Parameters	:
' Name				 [I/O]	Description
'---------------------------------------------------------------------------------------
'---------------------------------------------------------------------------------------
' Return Value	:        
' Success:                      [ O ]
' Failure                       [ O ]  
' Revisions:
' --------------------------------------------------------------------------------------
' Ini |	Date	   |	Description
' --------------------------------------------------------------------------------------
******************************************************************************************/
--USE <database_name, sysname, EnterpriseConfigDB>

USE [$(EntDBDatabaseName)]
GO

DECLARE @DOMAINLOGINID		nvarchar(200)
DECLARE @ACSENTSQLUSER		nvarchar(200)
DECLARE @ENDataBaseUrole	nvarchar(50)
DECLARE @ENDataBaseProle	nvarchar(50)
DECLARE @sqlcmd				nvarchar(4000)
DECLARE @rowcount			int

SET @DOMAINLOGINID		= N'$(AppPoolLoginID)'
SET @ACSENTSQLUSER		= N'$(EntSQLUser)'
SET @ENDataBaseUrole	= N'$(EntDBurole)'
SET @ENDataBaseProle	= N'$(EntDBprole)'
SET @sqlcmd				= ''

BEGIN TRY
	BEGIN TRANSACTION
	SET ANSI_NULLS ON
	SET QUOTED_IDENTIFIER ON	
	IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = @DOMAINLOGINID)
		BEGIN	
			SET @sqlcmd = N'CREATE LOGIN [' + @DOMAINLOGINID+ '] FROM WINDOWS' 			
			EXECUTE sp_executesql @sqlcmd
			PRINT 'LOGIN ' + @DOMAINLOGINID + ' has been successfully created.' 
		END
		
		-- Create SQL User for the Citrix User in ACS Database 
		SET @sqlcmd =N'SELECT 1 as count into #temp FROM sys.database_principals WHERE name =''' +  @ACSENTSQLUSER + ''''			
		EXECUTE sp_executesql @sqlcmd
		set @rowcount = @@ROWCOUNT			
		IF  @rowcount > 0 
		BEGIN	
			SET @sqlcmd =N'DROP USER [' + @ACSENTSQLUSER + ']'
			EXECUTE sp_executesql @sqlcmd	
			PRINT 'USER ' + @ACSENTSQLUSER + ' was exist and deleted succesfully.' 
		END
		
		SET @sqlcmd =N'SELECT 1 as count into #temp FROM sys.database_principals WHERE name =''' +  @ACSENTSQLUSER + ''''
		EXECUTE sp_executesql @sqlcmd
		set @rowcount = @@ROWCOUNT			
		IF  @rowcount = 0
		BEGIN
			SET @sqlcmd = N'CREATE USER [' + @ACSENTSQLUSER + '] FOR LOGIN [' + @DOMAINLOGINID + ']'			
			EXECUTE sp_executesql @sqlcmd	
			PRINT 'USER ' + @ACSENTSQLUSER + ' @ Database has been successfully created.' 
		END

	
END TRY
BEGIN CATCH
	Print 'Error Occured'
	Print Error_message()
	Print Error_line()
	Rollback tran
END CATCH
If @@Trancount >0
COMMIT TRAN

-- adding member in role
	SET @sqlcmd =N'EXEC sp_addrolemember @rolename=' + @ENDataBaseUrole + ', @membername=[' + @ACSENTSQLUSER + ']'
	EXECUTE sp_executesql @sqlcmd
	
	SET @sqlcmd =N'EXEC sp_addrolemember @rolename=' + @ENDataBaseProle + ', @membername=' + @ENDataBaseUrole + ''
	EXECUTE sp_executesql @sqlcmd

	--Grant the control for symmetricKey for user
	SET @sqlcmd =N'GRANT CONTROL ON CERTIFICATE::ConnectionStringCertificate TO [' + @ACSENTSQLUSER + ']'
	EXECUTE sp_executesql @sqlcmd
	
	SET @sqlcmd =N'GRANT VIEW DEFINITION ON SYMMETRIC KEY::ConnectionStringSymmetricKey TO [' + @ACSENTSQLUSER + ']'
	EXECUTE sp_executesql @sqlcmd