/****************************************************************************************
' Name		: 03_CreateKeys.sql
' Author	: Shalini Sharma
' Description	: This script will be for Enterprise DB to create:
'                 1.) MASTER KEY
'                 2.) CERTIFICATE
'                 3.) SYMMETRIC KEY
'
'Parameters      : Passed through the Batch file that installs this script. 
'-------------------------------------------------------------------------------
'$(EntDBDatabaseName)			- Name of the ECR Database
' Revisions:
' --------------------------------------------------------------------------------------
' Ini |	Date	   |	Description
' --------------------------------------------------------------------------------------
******************************************************************************************/
--USE <database_name, sysname,EnterpriseConfigDB>
USE [$(EntDBDatabaseName)]
GO

BEGIN TRY

	BEGIN TRANSACTION

	/*************** CREATE MASTER KEY *********************************/
	Print 'Check MASTER KEY if it exists '
	IF NOT EXISTS (SELECT * FROM sys.symmetric_keys WHERE name = N'##MS_DatabaseMasterKey##')
		BEGIN		
			CREATE MASTER KEY ENCRYPTION BY PASSWORD = 'ConnectionStringEncryptionPassword@123'
			Print '<<< MASTER KEY ##MS_DatabaseMasterKey## Created >>>'
		END
	ELSE
		BEGIN
			Print '<<< MASTER KEY ##MS_DatabaseMasterKey## already exists.>>>'
		END
	

	/*************** CREATE CERTIFICATE *********************************/
	Print 'Check Certificates if it exists'
	IF NOT EXISTS (SELECT * FROM sys.certificates WHERE name = N'ConnectionStringCertificate')
		BEGIN
			CREATE CERTIFICATE ConnectionStringCertificate WITH SUBJECT = 'Connection_String',				
			EXPIRY_DATE = '12/31/2020';
			Print '<<< Certificates ConnectionStringCertificate Created >>>'
		END
	ELSE
		BEGIN
			Print '<<< Certificates ConnectionStringCertificate already exists.>>>'
		END
	
	/*************** CREATE SYMMETRIC KEY *********************************/
	Print 'CREATE SYMMETRIC KEY'
	IF NOT EXISTS (SELECT * FROM sys.symmetric_keys WHERE name = N'ConnectionStringSymmetricKey')
		BEGIN
			CREATE SYMMETRIC KEY ConnectionStringSymmetricKey
			WITH ALGORITHM = AES_256
			ENCRYPTION BY CERTIFICATE ConnectionStringCertificate;
			Print '<<< SYMMETRIC KEY ConnectionStringSymmetricKey Created >>>'		
		END
	ELSE	
		BEGIN
			Print '<<< SYMMETRIC KEY ConnectionStringSymmetricKey already exists.>>>'
		END

	
END TRY

BEGIN CATCH
	PRINT 'Error has occured while creating the certificate or certificate key'
	PRINT Error_message()
	PRINT Error_line()
	ROLLBACK TRAN
END CATCH

If @@Trancount >0
COMMIT TRAN