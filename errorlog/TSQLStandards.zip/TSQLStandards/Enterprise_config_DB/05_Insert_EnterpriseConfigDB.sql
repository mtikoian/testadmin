/*********************************************************************************/
/****************************************************************************************
' Name		: 05_Insert_EnterpriseConfigDB.sql
' Author	: Shalini Sharma
' Description	: This Insert Statement to Insert ODT ODR Connection Info Data in
		  ODR_ODT_CONNECTION_INFORMATION.
' Parameters	:
' Name				 [I/O]	Description
'---------------------------------------------------------------------------------------
'---------------------------------------------------------------------------------------
' Return Value	:        
' Success:                      [ O ]
' Failure                       [ O ]  
' Revisions:
' --------------------------------------------------------------------------------------
' Ini |	Date	   |	Description
' --------------------------------------------------------------------------------------
******************************************************************************************/
USE [$(EntDBDatabaseName)]
GO

DECLARE @ApplicationName	varchar(30)
DECLARE @BankID				varchar(4)  
DECLARE @BankName			varchar(38)  
DECLARE @HostAddress		varchar(50)  
DECLARE @ListenerPort		int
DECLARE @ServerID			varchar(50)  
DECLARE @NetworkID			varchar(50)  

SET @ApplicationName	= N'$(ApplicationName)'
SET @BankID				= N'$(MasterID)'
SET @BankName			= N'$(ODTOrganizationName)'
SET @HostAddress		= N'$(HostAddress)'
SET @ListenerPort		= N'$(ListenerPort)'
SET @ServerID			= N'$(ServerID)'
SET @NetworkID			= N'$(NetworkID)'



BEGIN TRY
	
	BEGIN TRANSACTION
	if not exists(select 1 from ACS_ENT_SCHEMA.ODR_ODT_CONNECTION_INFORMATION WHERE Bank_Id = @BankID	AND Application_Nm = @ApplicationName)		
	BEGIN	
		INSERT INTO [ACS_ENT_SCHEMA].[ODR_ODT_CONNECTION_INFORMATION]
			(
				Application_Nm,
				Bank_Id,
				Organization_Name,
				HostAddress,
				ListenerPort,
				Server_Id,
				Network_Id) 
			VALUES 
			(
				@ApplicationName,
				@BankID,
				@BankName,
				@HostAddress,
				@ListenerPort,
				@ServerID,
				@NetworkID
			)
	END	
	ELSE
	BEGIN
		update [ACS_ENT_SCHEMA].[ODR_ODT_CONNECTION_INFORMATION]
		set		Organization_Name =	@BankName,
				HostAddress = @HostAddress,
				ListenerPort = @ListenerPort,
				Server_Id = @ServerID,
				Network_Id= @NetworkID
		Where Application_Nm = @ApplicationName and Bank_Id = @BankID
		
	END
END TRY
BEGIN CATCH
	PRINT 'error occured while inserting the records'
	PRINT Error_message()
	PRINT Error_line()
	ROLLBACK TRAN
END CATCH

If @@Trancount >0
COMMIT TRAN