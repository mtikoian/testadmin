/****************************************************************************************
' Name		: 01_CreateEnterpriseConfigDB.sql
' Author	: Shalini Sharma
' Description	: This procedure will:
'                 1.) Create the EnterpriseConfigDB Database One Time
'                 2.) Sets appropriate database options
'
'Parameters      : Passed through the Batch file that installs this script. 
'-------------------------------------------------------------------------------
'$(EDBDatabaseName)			- Name of the ECR Database
'$(EDBDataFilePath)			- Location where .mdf file will be stored
'$(EDBLogFilePath)			- Location where .ldf file will be stored
'---------------------------------------------------------------------------------------
'
' Revisions:
' --------------------------------------------------------------------------------------
' Ini		|	Date	   |	Description
' --------------------------------------------------------------------------------------
'Sarawat	| 3/19/2013			File updated for recovery model issue 
******************************************************************************************/
USE [MASTER]

GO

DECLARE @EDBDatabaseName		nvarchar(50)
DECLARE @EDBDataFolder			nvarchar(2000)  
DECLARE @EDBLogFolder			nvarchar(2000)  
DECLARE @EDBDataFileName		nvarchar(250)  
DECLARE @EDBLogFileName			nvarchar(250)  
DECLARE @ACSDataFileInitialSize	nvarchar(30)
DECLARE @ACSDataFileGrowthSize	nvarchar(30)
DECLARE @ACSLogFileInitialSize	nvarchar(30)
DECLARE @ACSLogFileGrowthSize	nvarchar(30)
DECLARE @sqlcmd					nvarchar(4000)

SET @sqlcmd				= ''
SET @EDBDatabaseName	= N'$(EntDBDatabaseName)'
SET @EDBDataFolder		= N'$(EDBDataFolderPath)'
SET @EDBLogFolder		= N'$(EDBLogFolderPath)'
SET @EDBDataFileName = @EDBDatabaseName + '_Data'
SET @EDBLogFileName = @EDBDatabaseName + '_Log'
SET @ACSDataFileInitialSize		= N'$(EDBDataFileInitialSize)'
SET @ACSDataFileGrowthSize		= N'$(EDBDataFileGrowthSize)'
SET @ACSLogFileInitialSize		= N'$(EDBLogFileInitialSize)'
SET @ACSLogFileGrowthSize		= N'$(EDBLogFileGrowthSize)'

SET NOCOUNT ON

BEGIN TRY

	IF not EXISTS (SELECT name FROM master.dbo.sysdatabases WHERE name = @EDBDatabaseName)
	BEGIN
		SET @sqlcmd = N'CREATE DATABASE [' + @EDBDatabaseName  + ']' 
			+ ' ON (NAME = ''' + @EDBDataFileName + ''' ,' 
			+ ' FILENAME = ''' + @EDBDataFolder + '\' + @EDBDataFileName + '.mdf''' + ','
			+ ' SIZE = ' + @ACSDataFileInitialSize + ','
			+ ' FILEGROWTH = ' + @ACSDataFileGrowthSize + ') '
			+ '	LOG ON (NAME = ''' + @EDBLogFileName + ''',' 
			+ ' FILENAME = ''' + @EDBLogFolder + '\' + @EDBLogFileName + '.ldf''' + ','
			+ ' SIZE = ' + @ACSLogFileInitialSize + ', '
			+ ' FILEGROWTH = '+ @ACSLogFileGrowthSize +')'			
			+ ' COLLATE SQL_Latin1_General_CP1_CI_AS'
	

		EXECUTE sp_executesql @sqlcmd
	
			
		exec sp_dboption @EDBDatabaseName, N'autoclose', N'false'
		

		exec sp_dboption @EDBDatabaseName, N'bulkcopy', N'false'
		

		exec sp_dboption @EDBDatabaseName, N'trunc. log', N'false'
		

		exec sp_dboption @EDBDatabaseName, N'torn page detection', N'true'
		

		exec sp_dboption @EDBDatabaseName, N'read only', N'false'
		

		exec sp_dboption @EDBDatabaseName, N'dbo use', N'false'
		

		exec sp_dboption @EDBDatabaseName, N'single', N'false'
		

		exec sp_dboption @EDBDatabaseName, N'autoshrink', N'false'
		

		exec sp_dboption @EDBDatabaseName, N'ANSI null default', N'false'
		

		exec sp_dboption @EDBDatabaseName, N'recursive triggers', N'false'
		

		exec sp_dboption @EDBDatabaseName, N'ANSI nulls', N'false'
		

		exec sp_dboption @EDBDatabaseName, N'concat null yields null', N'false'
		

		exec sp_dboption @EDBDatabaseName, N'cursor close on commit', N'false'
		

		exec sp_dboption @EDBDatabaseName, N'default to local cursor', N'false'
		

		exec sp_dboption @EDBDatabaseName, N'quoted identifier', N'false'
		

		exec sp_dboption @EDBDatabaseName, N'ANSI warnings', N'false'
		

		exec sp_dboption @EDBDatabaseName, N'auto create statistics', N'true'
		

		exec sp_dboption @EDBDatabaseName, N'auto update statistics', N'true'
		

		if( ( (@@microsoftversion / power(2, 24) = 8) and (@@microsoftversion & 0xffff >= 724) ) or ( (@@microsoftversion / power(2, 24) = 7) and (@@microsoftversion & 0xffff >= 1082) ) )
			exec sp_dboption @EDBDatabaseName, N'db chaining', N'false'
	
	End
	IF EXISTS (SELECT name FROM master.dbo.sysdatabases WHERE name = @EDBDatabaseName)
	BEGIN
		PRINT 'Database ' + @EDBDatabaseName + ' has been successfully created.' 
	END
END TRY

BEGIN CATCH
	PRINT 'error occured while creating the database'
	PRINT Error_message()
	PRINT Error_line()
	RAISERROR ('',16,255)
	RETURN;
END CATCH
