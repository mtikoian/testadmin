/****************************************************************************************
' Name		: 04_EnterpriseConfigDB.sql
' Author	: Shalini Sharma
' Description	: One time script for:
'                 1.) Create Table
						ODR_ODT_CONNECTION_INFORMATION
' Parameters	:
' Name				 [I/O]	Description
'---------------------------------------------------------------------------------------
'---------------------------------------------------------------------------------------
' Return Value	:        
' Success:                      [ O ]
' Failure                       [ O ]  
' Revisions:
' --------------------------------------------------------------------------------------
' Ini |	Date	   |	Description
' --------------------------------------------------------------------------------------
******************************************************************************************/
--Use <database_name, sysname, EnterpriseConfigDB>
USE [$(EntDBDatabaseName)]
GO

DECLARE @ENDataBaseUrole	nvarchar(50)
DECLARE @ENDataBaseProle	nvarchar(50)
DECLARE @SQLCmd 		nvarchar(200)
SET @ENDataBaseUrole	= N'$(EntDBurole)'
SET @ENDataBaseProle	= N'$(EntDBprole)'


BEGIN TRY

	BEGIN TRANSACTION
	SET QUOTED_IDENTIFIER OFF 

	SET ANSI_NULLS ON 

	-- Create prole
	IF NOT EXISTS (SELECT * FROM sys.database_principals WHERE name = @ENDataBaseProle AND type = 'R')	
	BEGIN
		SET @SQLCmd = 'CREATE ROLE ' + @ENDataBaseProle
		EXECUTE dbo.sp_executesql @SQLCmd
	END

	-- Create urole
	IF NOT EXISTS (SELECT * FROM sys.database_principals WHERE name = @ENDataBaseUrole AND type = 'R')
	BEGIN
		SET @SQLCmd = 'CREATE ROLE ' + @ENDataBaseUrole
		EXECUTE dbo.sp_executesql @SQLCmd
	END
	
	
	IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = 'ACS_ENT_SCHEMA')
	BEGIN
		SET @SQLCmd = 'CREATE SCHEMA ACS_ENT_SCHEMA AUTHORIZATION ' +  @ENDataBaseProle
		EXEC dbo.sp_executesql @SQLCmd
	END

	--Adding New Tables for the Access Service 



	IF NOT EXISTS (select 1 from sys.sysobjects where id = object_id(N'[ACS_ENT_SCHEMA].[ODR_ODT_CONNECTION_INFORMATION]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
	BEGIN
		CREATE TABLE [ACS_ENT_SCHEMA].[ODR_ODT_CONNECTION_INFORMATION](
			[Application_Nm] [varchar](30) NOT NULL,
			[Bank_Id] [varchar](4) NOT NULL,
			[Organization_Name] [varchar](38) NOT NULL,
			[HostAddress] [varchar](50) NOT NULL,
			[ListenerPort] [int] NOT NULL,
			[Server_Id] [varchar](50) NOT NULL,
			[Network_Id] [varchar](50) NOT NULL,
			[Connection_String] [varbinary](256) NULL,
		) ON [PRIMARY]


		/* Add the primary key constraint to the table */
		ALTER TABLE [ACS_ENT_SCHEMA].[ODR_ODT_CONNECTION_INFORMATION] 
		ADD CONSTRAINT [PK_ODR_ODT_CONNECTION_INFORMATION] PRIMARY KEY CLUSTERED 
		(
				[Application_Nm] ASC,
				[Bank_Id] ASC
		) ON [PRIMARY]
	END
	IF OBJECT_ID('[ACS_ENT_SCHEMA].[ODR_ODT_CONNECTION_INFORMATION]') IS NOT NULL
		PRINT 'CREATED TABLE [ACS_ENT_SCHEMA].[ODR_ODT_CONNECTION_INFORMATION]'
	ELSE
		PRINT 'FAILED CREATING TABLE [ACS_ENT_SCHEMA].[ODR_ODT_CONNECTION_INFORMATION]'
END TRY

BEGIN CATCH
	PRINT 'Error occured while creating the table'
	PRINT Error_message()
	PRINT Error_line()
	ROLLBACK TRAN
END CATCH

If @@Trancount >0
COMMIT TRAN