/****************************************************************************************
' Name            : 02_Delete_EnterpriseConfigDB.sql
' Author          : Shashank Mittal
' Description     : Delete the Connection string of a bank in ODR_ODT_CONNECTION_INFORMATION table.
' Parameters      :

' Name                        [I/O]      Description
'---------------------------------------------------------------------------------------
'---------------------------------------------------------------------------------------
' Return Value    :        
' Success:                      [ O ]
' Failure                       [ O ]  
' Revisions:
' --------------------------------------------------------------------------------------
' Ini |     Date     |  Description
' --------------------------------------------------------------------------------------
******************************************************************************************/
USE [$(EntDBDatabaseName)]
GO

DECLARE @ApplicationName	varchar(30)
DECLARE @BankID				varchar(4)  

SET @ApplicationName	= N'$(ApplicationName)'
SET @BankID				= N'$(MasterID)'

BEGIN TRY
      BEGIN TRANSACTION
		   DELETE FROM [ACS_ENT_SCHEMA].[ODR_ODT_CONNECTION_INFORMATION] 
		   Where Bank_Id = @BankID	AND Application_Nm = @ApplicationName
			PRINT 'Connection information for the client has been deleted.'
END TRY

BEGIN CATCH
      PRINT 'error occured while connection string update'
      PRINT Error_message()
      PRINT Error_line()
      ROLLBACK TRAN
END CATCH

If @@Trancount >0
COMMIT TRAN