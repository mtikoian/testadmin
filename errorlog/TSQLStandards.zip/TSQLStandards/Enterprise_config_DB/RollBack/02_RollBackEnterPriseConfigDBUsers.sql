/****************************************************************************************
' Name            : Enterprise DB_RollBack User.sql
' Author			: Rahul Sharma
' Parameters      :
' Name            [I/O]      Description
'---------------------------------------------------------------------------------------
'---------------------------------------------------------------------------------------
' Return Value    :        
' Success:                      [ O ]
' Failure                       [ O ]  
' Revisions:
' --------------------------------------------------------------------------------------
' Ini |     Date     |  Description
' --------------------------------------------------------------------------------------
******************************************************************************************/
--Use <database_name, sysname, EnterpriseConfigDB>
USE [$(EntDBDatabaseName)]
GO

DECLARE @DOMAINLOGINID		nvarchar(200)
DECLARE @ACSENTSQLUSER		nvarchar(200)
DECLARE @ENDataBaseUrole	nvarchar(50)
DECLARE @ENDataBaseProle	nvarchar(50)
DECLARE @sqlcmd				nvarchar(4000)
DECLARE @rowcount			int

SET @DOMAINLOGINID		= N'$(DOMAINLOGINIDFORSQL)'
SET @ACSENTSQLUSER		= N'$(EntSQLUser)'
SET @ENDataBaseUrole	= N'$(EntDB-urole)'
SET @ENDataBaseProle	= N'$(EntDB-prole)'
SET @sqlcmd				= ''

BEGIN TRY
	BEGIN TRANSACTION
	SET ANSI_NULLS ON
	SET QUOTED_IDENTIFIER ON
		-- Create SQL User for the Citrix User in ACS Database 
		SET @sqlcmd =N'SELECT 1 as count into #temp FROM sys.database_principals WHERE name =''' +  @ACSENTSQLUSER + ''''			
		EXECUTE sp_executesql @sqlcmd
		set @rowcount = @@ROWCOUNT			
		IF  @rowcount > 0 
		BEGIN	
			SET @sqlcmd =N'DROP USER [' + @ACSENTSQLUSER + ']'
			EXECUTE sp_executesql @sqlcmd	
			PRINT 'USER ' + @ACSENTSQLUSER + ' deleted succesfully.' 
		END
		ELSE
			PRINT 'USER ' + @ACSENTSQLUSER + ' does not exist.' 
	
		IF EXISTS (SELECT * FROM sys.server_principals WHERE name = @DOMAINLOGINID)
			BEGIN	
				SET @sqlcmd = N'DROP LOGIN [' + @DOMAINLOGINID + ']'		
				EXECUTE sp_executesql @sqlcmd
				PRINT 'LOGIN ' + @DOMAINLOGINID + ' has been successfully deleted.' 
			END
		ELSE
			PRINT 'LOGIN ' + @DOMAINLOGINID + ' Does not exists.' 
END TRY
BEGIN CATCH
	  Print 'Error Occured'
	  Print Error_message()
	  Print Error_line()
	  Rollback tran
END CATCH
	If @@Trancount >0
	COMMIT TRAN 	
