/**********************************************************************************************************************
 Purpose:
 Create a Calendar Table based on the first Monday of each year. Note that this is NOT an ISO based Calendar Table
 where the first week of the year is the week that contains the first Thursday of the year.

 Note also that this table does NOT account for holidays or week days, either, because I don't know what holidays
 the customer observes. 

 Revision History:
 Rev 00 - 16 Feb 2014 - Jeff Moden - Initial release.
**********************************************************************************************************************/
WITH
cteGenDates AS
( --=== Create a list of calendar dates from 1900-01-01 through 2099-12-31.
 SELECT TOP (DATEDIFF(dd,'1900','2100'))
        CalendarDate = ISNULL(DATEADD(dd,ROW_NUMBER()OVER(ORDER BY (SELECT NULL))-1,'1900'),0)
   FROM      master.sys.all_columns ac1
  CROSS JOIN master.sys.all_columns ac2
),
cteFiscal1 AS
( --=== Calculate the fiscal year and the week number of the fiscal year.
 SELECT  CalendarDate
        ,FiscalYear     = DATEPART(yy,DATEADD(dd,DATEDIFF(dd,'1753',CalendarDate)/7*7,'1753'))
        ,FiscalYearWeek = (DATEPART(dy,DATEADD(dd,DATEDIFF(dd,'1753',CalendarDate)/7*7,'1753'))+6)/7
   FROM cteGenDates
),
cteFiscal2 AS
( --=== Calculate the first Monday of the year as the start of the fiscal year.
 SELECT *
        ,FiscalYearStartDate = DATEADD(dd,DATEDIFF(dd,'1753',DATEADD(mm,DATEDIFF(mm,'1753',CAST(FiscalYear AS VARCHAR(10))),'1753')+6)/7*7,'17530101')
   FROM cteFiscal1
),
cteFiscal3 AS
( --=== Calculate the start date of each fiscal week 
 SELECT *
        ,FiscalWeekStartDate = DATEADD(dd,(FiscalYearWeek-1)*7,FiscalYearStartDate)
   FROM cteFiscal2
),
cteFiscal4 AS
( --=== Calculate the start date of each fiscal month
 SELECT *
        ,FiscalMonthStartDate = DATEADD(dd,DATEDIFF(dd,'1753',DATEADD(mm,DATEDIFF(mm,'1753',FiscalWeekStartDate),'1753')+6)/7*7,'1753')
   FROM cteFiscal3
) --=== Calculate some other useful columns and create a table from it all (JBM20140216)
 SELECT  CalendarDate
        ,NextDate        = CalendarDate+1
        ,DOW3            = LEFT(DATENAME(dw,CalendarDate),3)
        ,FiscalYearStartDate
        ,FiscalYear
        ,FiscalYearWeek
        ,FiscalMonthStartDate
        ,FiscalMonth     = DATEPART(mm,FiscalWeekStartDate)
        ,FiscalMonthWeek = DATEDIFF(dd,FiscalMonthStartDate,FiscalWeekStartDate)/7+1
        ,FiscalWeekStartDate
   INTO dbo.FiscalCalendar
   FROM cteFiscal4
;
--===== Add the expected PK
  ALTER TABLE dbo.FiscalCalendar
    ADD CONSTRAINT PK_FiscalCalendar 
        PRIMARY KEY CLUSTERED (CalendarDate)
        WITH FILLFACTOR = 100
;
--===== Display the contents of the new table
 SELECT * FROM dbo.FiscalCalendar ORDER BY CalendarDate
;
