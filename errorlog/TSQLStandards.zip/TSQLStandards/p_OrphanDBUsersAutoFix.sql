CREATE PROCEDURE [dbo].[p_OrphanDBUsersAutoFix] (@mode VARCHAR(10))
AS
BEGIN
SET NOCOUNT ON
DECLARE @tsql VARCHAR(400)
DECLARE @username SYSNAME
DECLARE c_orphanedusers CURSOR
FOR  SELECT a.NAME AS OrphUsr
FROM sys.database_principals a
LEFT OUTER JOIN sys.server_principals b
ON a.sid = b.sid
WHERE (b.sid IS NULL)  	AND (a.principal_id > 4) AND (a.type_desc = 'SQL_USER')
 
OPEN c_orphanedusers
FETCH c_orphanedusers
INTO @username
WHILE @@FETCH_STATUS = 0
BEGIN
SET @tsql = 'ALTER USER ' + @username + ' WITH LOGIN = ' + @username;
IF UPPER(@mode) = 'EXECUTE'
EXEC (@tsql)
ELSE
IF UPPER(@mode) = 'REPORT'
PRINT (@username)
 
FETCH c_orphanedusers  	INTO @username
END
CLOSE c_orphanedusers
DEALLOCATE c_orphanedusers
IF (
SELECT count(a.NAME) AS OrphUsr
FROM sys.database_principals a
LEFT OUTER JOIN sys.server_principals b
ON a.sid = b.sid
WHERE (b.sid IS NULL)
AND (a.principal_id > 4)
AND (a.type_desc = 'SQL_USER')
) = 0
PRINT 'No Orphaned SQL Users.'
SET NOCOUNT OFF
END
GO