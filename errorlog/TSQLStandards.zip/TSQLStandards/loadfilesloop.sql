
--=====================================================================================================================
--      PRESETS
--=====================================================================================================================
--===== Drop all temp tables up front to make reruns in SSMS easier.
     -- This section may be commented out if the code is converted to a stored procedure.
     -- Keep in mind that all DDL should be done at the beginning to help avoid recompiles.
     IF OBJECT_ID('tempdb..#FileName')      IS NOT NULL DROP TABLE #tmp;
     IF OBJECT_ID('tempdb..#ImportStaging') IS NOT NULL DROP TABLE #TempTable;
--===== For the same reasons as dropping temp tables up front, create them up front, as well.
     -- Also, name your tables in a meaningful manner to make the code easier to understand.
 CREATE TABLE #FileName 
        (
         RowNum       INT IDENTITY(1,1) PRIMARY KEY CLUSTERED --added and the PK is important for performance.
        ,jsonFileName VARCHAR(500)
        )
; 
 CREATE TABLE #ImportStaging
        (
         SKu                VARCHAR(250) --Again, NVARCHAR is probably overkill.
        ,[Product Status]   VARCHAR(250) --I'd also avoid spaces in my column names so no need for brackets.
        ,Title              VARCHAR(250)
        ,[TI Category]      VARCHAR(250)
        ,[TI Class]         VARCHAR(250)
        ,[TI Sub Class]     VARCHAR(250)
        ,[TI Price]         INT
     )
;
--===== Local variables
DECLARE  @Command       VARCHAR(1000) = 'dir "' + @filedirectory + '" /B' --changed, location of switches was bad
        ,@Counter       INT = 1       --Added
        ,@FileDirectory VARCHAR(100)  = 'E:\Temp\Filename\' --Probably no need for NVARCHAR
        ,@FileName      VARCHAR(1000) --Again, probably no need vor NVARCHAR
        ,@SQL           VARCHAR(4000)
;
--===== Load the full filenames to be imported.
     -- The RowNum column is auto incrementing from 1.
 INSERT INTO #tmp
        (jsonFileName) --added
   EXEC xp_cmdshell @command
;
--=====================================================================================================================
--      LOAD THE FILES
--=====================================================================================================================
--===== Get the first file name.
 SELECT @FileName   = jsonFileName
   FROM #FileName
  WHERE RowNum      = @Counter --1 at this point
;
--===== Loop through the file names and load each file
  WHILE @FileName > '' -- Not NULL or Blank
  BEGIN
        --===== Tokenized dynamic SQL is a whole lot easier to read/troubleshoot.
         SELECT @SQL = REPLACE(REPLACE('
   BULK INSERT #ImportStaging
   FROM <<FilePath>>
   WITH (
         FIELDTERMINATOR = "|"
        ,ROWTERMINATOR   = "\n"
        )
;'          -- Other end of the REPLACEs  
                ,'"'                ,'''') 
                ,'<<FilePath>>',QUOTENAME(@FileDirectory + @FileName,'''')) --Careful! QUOTENAME is only good for 258 characters max.
        ;                                                                   --It also helps with SQL Injection attempts.
        --===== Execute the dynamic SQL to load the file into the staging table.
             -- No need for sp_ExecuteSQL here so no need for NVARCHAR all over the place.
           EXEC (@SQL)
        ;
        --===== And now for the part you forgot. "BUMP" the counter to get to the next file name
         SELECT @Counter += 1
        ;
        --===== Get the next file name to work on.  If it's NULL or blank, the loop will quit.
         SELECT @FileName   = jsonFileName
           FROM #FileName
          WHERE RowNum      = @Counter
        ; 
    END
;