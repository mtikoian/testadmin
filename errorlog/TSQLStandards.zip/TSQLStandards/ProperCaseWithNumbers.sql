--CREATE FUNCTION [dbo].[ProperCaseWithNumbers]
--(
--	@StrIn VARCHAR(255)
--)
--RETURNS TABLE WITH SCHEMABINDING
--AS
--RETURN

--SELECT STUFF((
--			SELECT CASE
--					WHEN split.Item LIKE '%[0-9]%'
--						THEN ' ' + split.Item
--					ELSE ' ' + Upper(LEFT(split.Item, 1)) + Lower(Substring(split.Item, 2, 255))
--					END AS word
--			FROM dbo.Delimitedsplit8k(@StrIn, ' ') split
--			FOR XML PATH('')
--				,TYPE
--			).value('.', 'varchar(255)'), 1, 1, '') AS ProperCased



--GO

CREATE FUNCTION [dbo].[ProperCaseWithNumbers]
(
	@StrIn VARCHAR(255)
)
RETURNS TABLE WITH SCHEMABINDING
AS
RETURN

SELECT STUFF(
----Start of first parameter
			(SELECT CASE
					WHEN split.Item LIKE '%[0-9]%'
						THEN ' ' + split.Item
					ELSE ' ' + Upper(LEFT(split.Item, 1)) + Lower(Substring(split.Item, 2, 255))
					END AS word
			FROM dbo.Delimitedsplit8k(@StrIn, ' ') split
			FOR XML PATH('')
				,TYPE
			).value('.', 'varchar(255)') ----End of first parameter. List generated as: ',item1,item2,item3,...,itemN'
, 1 ----Position (first character)
, 1 ----Number of characters to be replaced (one, the first comma)
, '' ----Replacement string (empty)
) AS ProperCased