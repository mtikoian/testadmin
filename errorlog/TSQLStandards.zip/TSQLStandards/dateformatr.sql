--===== Define the date range.
DECLARE  @StartDate DATETIME    = '2000' --Inclusive
        ,@LimitDate DATETIME    = '2017' --Exclusive
        ,@Rows      INT         = 1000000
;
DECLARE  @Days      INT         = DATEDIFF(dd,@StartDate,@LimitDate)
;
--===== Create the test table
     IF OBJECT_ID('tempdb..#TestTable','U') IS NOT NULL
   DROP TABLE #TestTable
;
--===== Populate the table with
 SELECT TOP 1000000
        SomeDate = RAND(CHECKSUM(NEWID()))*@Days+@StartDate
   INTO #TestTable
   FROM      sys.all_columns ac1
  CROSS JOIN sys.all_columns ac2
;
GO
--===== Test the format method with a shunt variable to take the display time out of the picture.
  PRINT '========== FORMAT Method =======================================================';
GO
DECLARE @BitBucket CHAR(19);
    SET STATISTICS TIME ON;
 SELECT @BitBucket = FORMAT(SomeDate, 'MM-dd-yyyy hh:mm tt')
  FROM #TestTable; 
   SET STATISTICS TIME OFF;
GO 3
--===== Test the convert method with a shunt variable to take the display time out of the picture.
  PRINT '========== CONVERT Method =======================================================';
GO
DECLARE @BitBucket CHAR(19);
    SET STATISTICS TIME ON;
 SELECT @BitBucket = CONVERT(CHAR(11),SomeDate,110)+STUFF(RIGHT(CONVERT(CHAR(19),SomeDate,100),7),6,0,' ')
   FROM #TestTable;
   SET STATISTICS TIME OFF;
GO 