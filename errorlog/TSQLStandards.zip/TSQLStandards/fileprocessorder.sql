DROP TABLE #Control
GO
--===== Simulate a process that captures all of the
     -- file names in a table with an extra column
     -- for processing order.
 SELECT  d.PricesFileName
        ,ProcessOrder = CAST(0 AS INT)
   INTO #Control
   FROM
(
 SELECT 'PRICES_AM_20160622.TXT' UNION ALL
 SELECT 'PRICES_AM_20160623.TXT' UNION ALL
 SELECT 'PRICES_AP_20160622.TXT' UNION ALL
 SELECT 'PRICES_AP_20160623.TXT' UNION ALL
 SELECT 'PRICES_EU_20160622.TXT' UNION ALL
 SELECT 'PRICES_EU_20160623.TXT'
) d (PricesFileName)
;
--===== Parse the file names to establish the process order and update the control table
     -- with the correct order. 
WITH cteCreateProcessOrder AS
(
 SELECT  ProcessOrder
        ,RN = ROW_NUMBER() OVER (ORDER BY SUBSTRING(PricesFileName,11,8)
                                        ,CASE 
                                            WHEN SUBSTRING(PricesFileName,8,2) = 'AP' THEN 1
                                            WHEN SUBSTRING(PricesFileName,8,2) = 'EU' THEN 2
                                            WHEN SUBSTRING(PricesFileName,8,2) = 'AM' THEN 3
                                         ELSE 'UNKNOWN TYPE OF FILE DETECTED'
                                         END)
   FROM #Control
)
 UPDATE cteCreateProcessOrder
    SET ProcessOrder = RN
;
--==== Let's see what we have in the #Control table.
 SELECT * FROM #Control ORDER BY ProcessOrder
;