DECLARE @thing NVARCHAR(max)
	,@table SYSNAME = 'company' --update table name

SELECT TOP 1 @thing = 'SELECT ''' + @table + ''' as TableName, ' + STUFF((
			SELECT ', MAX(LEN(' + COLUMN_NAME + ')) as ' + COLUMN_NAME
			FROM information_schema.columns
			WHERE table_name = '' + @table + ''
				AND data_type <> 'ntext'
			FOR XML path('')
			), 1, 1, '') + ' FROM [' + @table + ']'
FROM information_schema.columns
WHERE table_name = '' + @table + ''
	AND data_type <> 'ntext'

EXEC sp_executesql @thing

SELECT @thing
