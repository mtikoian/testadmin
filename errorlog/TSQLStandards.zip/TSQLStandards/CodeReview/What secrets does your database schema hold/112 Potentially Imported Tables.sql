/*

	Author: Andre' DuBois 
	E: MtnDBA@gmail.com  
	T: @MtnDBA
	B: MtnDBA.wordpress.com

	Presented: SQL Saturday #191 Kansas City
	September 14, 2013

	Purpose: Check for any tables that may use imported data; they use poor default data types and sizes
	This is for a single database; select the database to browse

	Please run in non-production environment until you know what this scipt does. 
	It could affect performance or other nasty things;
			
*/

-- Imported tables are named ending with a $ as default
SELECT * 
FROM INFORMATION_SCHEMA.TABLES t
WHERE t.TABLE_NAME like '%$';