--http://msdn.microsoft.com/en-us/library/ms189822.aspx
/*-------------------------Drop temp tables-------------------------------------------*/
IF OBJECT_ID('tempdb..#Temp') IS NOT NULL
	DROP TABLE #Temp;

/*-------------------------Drop temp tables-------------------------------------------*/
IF OBJECT_ID('tempdb..#Temp1') IS NOT NULL
	DROP TABLE #Temp1;


;WITH Allkeywords (SourceName,KeyWord)
AS
(
SELECT 'SQL Keyword','ADD' UNION ALL
SELECT 'SQL Keyword','EXISTS' UNION ALL
SELECT 'SQL Keyword','PRECISION' UNION ALL
SELECT 'SQL Keyword','ALL' UNION ALL
SELECT 'SQL Keyword','EXIT' UNION ALL
SELECT 'SQL Keyword','PRIMARY' UNION ALL
SELECT 'SQL Keyword','ALTER' UNION ALL
SELECT 'SQL Keyword','EXTERNAL' UNION ALL
SELECT 'SQL Keyword','PRINT' UNION ALL
SELECT 'SQL Keyword','AND' UNION ALL
SELECT 'SQL Keyword','FETCH' UNION ALL
SELECT 'SQL Keyword','PROC' UNION ALL
SELECT 'SQL Keyword','ANY' UNION ALL
SELECT 'SQL Keyword','FILE' UNION ALL
SELECT 'SQL Keyword','PROCEDURE' UNION ALL
SELECT 'SQL Keyword','AS' UNION ALL
SELECT 'SQL Keyword','FILLFACTOR' UNION ALL
SELECT 'SQL Keyword','PUBLIC' UNION ALL
SELECT 'SQL Keyword','ASC' UNION ALL
SELECT 'SQL Keyword','FOR' UNION ALL
SELECT 'SQL Keyword','RAISERROR' UNION ALL
SELECT 'SQL Keyword','AUTHORIZATION' UNION ALL
SELECT 'SQL Keyword','FOREIGN' UNION ALL
SELECT 'SQL Keyword','READ' UNION ALL
SELECT 'SQL Keyword','BACKUP' UNION ALL
SELECT 'SQL Keyword','FREETEXT' UNION ALL
SELECT 'SQL Keyword','READTEXT' UNION ALL
SELECT 'SQL Keyword','BEGIN' UNION ALL
SELECT 'SQL Keyword','FREETEXTTABLE' UNION ALL
SELECT 'SQL Keyword','RECONFIGURE' UNION ALL
SELECT 'SQL Keyword','BETWEEN' UNION ALL
SELECT 'SQL Keyword','FROM' UNION ALL
SELECT 'SQL Keyword','REFERENCES' UNION ALL
SELECT 'SQL Keyword','BREAK' UNION ALL
SELECT 'SQL Keyword','FULL' UNION ALL
SELECT 'SQL Keyword','REPLICATION' UNION ALL
SELECT 'SQL Keyword','BROWSE' UNION ALL
SELECT 'SQL Keyword','FUNCTION' UNION ALL
SELECT 'SQL Keyword','RESTORE' UNION ALL
SELECT 'SQL Keyword','BULK' UNION ALL
SELECT 'SQL Keyword','GOTO' UNION ALL
SELECT 'SQL Keyword','RESTRICT' UNION ALL
SELECT 'SQL Keyword','BY' UNION ALL
SELECT 'SQL Keyword','GRANT' UNION ALL
SELECT 'SQL Keyword','RETURN' UNION ALL
SELECT 'SQL Keyword','CASCADE' UNION ALL
SELECT 'SQL Keyword','GROUP' UNION ALL
SELECT 'SQL Keyword','REVERT' UNION ALL
SELECT 'SQL Keyword','CASE' UNION ALL
SELECT 'SQL Keyword','HAVING' UNION ALL
SELECT 'SQL Keyword','REVOKE' UNION ALL
SELECT 'SQL Keyword','CHECK' UNION ALL
SELECT 'SQL Keyword','HOLDLOCK' UNION ALL
SELECT 'SQL Keyword','RIGHT' UNION ALL
SELECT 'SQL Keyword','CHECKPOINT' UNION ALL
SELECT 'SQL Keyword','IDENTITY' UNION ALL
SELECT 'SQL Keyword','ROLLBACK' UNION ALL
SELECT 'SQL Keyword','CLOSE' UNION ALL
SELECT 'SQL Keyword','IDENTITY_INSERT' UNION ALL
SELECT 'SQL Keyword','ROWCOUNT' UNION ALL
SELECT 'SQL Keyword','CLUSTERED' UNION ALL
SELECT 'SQL Keyword','IDENTITYCOL' UNION ALL
SELECT 'SQL Keyword','ROWGUIDCOL' UNION ALL
SELECT 'SQL Keyword','COALESCE' UNION ALL
SELECT 'SQL Keyword','IF' UNION ALL
SELECT 'SQL Keyword','RULE' UNION ALL
SELECT 'SQL Keyword','COLLATE' UNION ALL
SELECT 'SQL Keyword','IN' UNION ALL
SELECT 'SQL Keyword','SAVE' UNION ALL
SELECT 'SQL Keyword','COLUMN' UNION ALL
SELECT 'SQL Keyword','INDEX' UNION ALL
SELECT 'SQL Keyword','SCHEMA' UNION ALL
SELECT 'SQL Keyword','COMMIT' UNION ALL
SELECT 'SQL Keyword','INNER' UNION ALL
SELECT 'SQL Keyword','SECURITYAUDIT' UNION ALL
SELECT 'SQL Keyword','COMPUTE' UNION ALL
SELECT 'SQL Keyword','INSERT' UNION ALL
SELECT 'SQL Keyword','SELECT' UNION ALL
SELECT 'SQL Keyword','CONSTRAINT' UNION ALL
SELECT 'SQL Keyword','INTERSECT' UNION ALL
SELECT 'SQL Keyword','SESSION_USER' UNION ALL
SELECT 'SQL Keyword','CONTAINS' UNION ALL
SELECT 'SQL Keyword','INTO' UNION ALL
SELECT 'SQL Keyword','SET' UNION ALL
SELECT 'SQL Keyword','CONTAINSTABLE' UNION ALL
SELECT 'SQL Keyword','IS' UNION ALL
SELECT 'SQL Keyword','SETUSER' UNION ALL
SELECT 'SQL Keyword','CONTINUE' UNION ALL
SELECT 'SQL Keyword','JOIN' UNION ALL
SELECT 'SQL Keyword','SHUTDOWN' UNION ALL
SELECT 'SQL Keyword','CONVERT' UNION ALL
SELECT 'SQL Keyword','KEY' UNION ALL
SELECT 'SQL Keyword','SOME' UNION ALL
SELECT 'SQL Keyword','CREATE' UNION ALL
SELECT 'SQL Keyword','KILL' UNION ALL
SELECT 'SQL Keyword','STATISTICS' UNION ALL
SELECT 'SQL Keyword','CROSS' UNION ALL
SELECT 'SQL Keyword','LEFT' UNION ALL
SELECT 'SQL Keyword','SYSTEM_USER' UNION ALL
SELECT 'SQL Keyword','CURRENT' UNION ALL
SELECT 'SQL Keyword','LIKE' UNION ALL
SELECT 'SQL Keyword','TABLE' UNION ALL
SELECT 'SQL Keyword','CURRENT_DATE' UNION ALL
SELECT 'SQL Keyword','LINENO' UNION ALL
SELECT 'SQL Keyword','TABLESAMPLE' UNION ALL
SELECT 'SQL Keyword','CURRENT_TIME' UNION ALL
SELECT 'SQL Keyword','LOAD' UNION ALL
SELECT 'SQL Keyword','TEXTSIZE' UNION ALL
SELECT 'SQL Keyword','CURRENT_TIMESTAMP' UNION ALL
SELECT 'SQL Keyword','MERGE' UNION ALL
SELECT 'SQL Keyword','THEN' UNION ALL
SELECT 'SQL Keyword','CURRENT_USER' UNION ALL
SELECT 'SQL Keyword','NATIONAL' UNION ALL
SELECT 'SQL Keyword','TO' UNION ALL
SELECT 'SQL Keyword','CURSOR' UNION ALL
SELECT 'SQL Keyword','NOCHECK' UNION ALL
SELECT 'SQL Keyword','TOP' UNION ALL
SELECT 'SQL Keyword','DATABASE' UNION ALL
SELECT 'SQL Keyword','NONCLUSTERED' UNION ALL
SELECT 'SQL Keyword','TRAN' UNION ALL
SELECT 'SQL Keyword','DBCC' UNION ALL
SELECT 'SQL Keyword','NOT' UNION ALL
SELECT 'SQL Keyword','TRANSACTION' UNION ALL
SELECT 'SQL Keyword','DEALLOCATE' UNION ALL
SELECT 'SQL Keyword','NULL' UNION ALL
SELECT 'SQL Keyword','TRIGGER' UNION ALL
SELECT 'SQL Keyword','DECLARE' UNION ALL
SELECT 'SQL Keyword','NULLIF' UNION ALL
SELECT 'SQL Keyword','TRUNCATE' UNION ALL
SELECT 'SQL Keyword','DEFAULT' UNION ALL
SELECT 'SQL Keyword','OF' UNION ALL
SELECT 'SQL Keyword','TSEQUAL' UNION ALL
SELECT 'SQL Keyword','DELETE' UNION ALL
SELECT 'SQL Keyword','OFF' UNION ALL
SELECT 'SQL Keyword','UNION' UNION ALL
SELECT 'SQL Keyword','DENY' UNION ALL
SELECT 'SQL Keyword','OFFSETS' UNION ALL
SELECT 'SQL Keyword','UNIQUE' UNION ALL
SELECT 'SQL Keyword','DESC' UNION ALL
SELECT 'SQL Keyword','ON' UNION ALL
SELECT 'SQL Keyword','UNPIVOT' UNION ALL
SELECT 'SQL Keyword','DISK' UNION ALL
SELECT 'SQL Keyword','OPEN' UNION ALL
SELECT 'SQL Keyword','UPDATE' UNION ALL
SELECT 'SQL Keyword','DISTINCT' UNION ALL
SELECT 'SQL Keyword','OPENDATASOURCE' UNION ALL
SELECT 'SQL Keyword','UPDATETEXT' UNION ALL
SELECT 'SQL Keyword','DISTRIBUTED' UNION ALL
SELECT 'SQL Keyword','OPENQUERY' UNION ALL
SELECT 'SQL Keyword','USE' UNION ALL
SELECT 'SQL Keyword','DOUBLE' UNION ALL
SELECT 'SQL Keyword','OPENROWSET' UNION ALL
SELECT 'SQL Keyword','USER' UNION ALL
SELECT 'SQL Keyword','DROP' UNION ALL
SELECT 'SQL Keyword','OPENXML' UNION ALL
SELECT 'SQL Keyword','VALUES' UNION ALL
SELECT 'SQL Keyword','DUMP' UNION ALL
SELECT 'SQL Keyword','OPTION' UNION ALL
SELECT 'SQL Keyword','VARYING' UNION ALL
SELECT 'SQL Keyword','ELSE' UNION ALL
SELECT 'SQL Keyword','OR' UNION ALL
SELECT 'SQL Keyword','VIEW' UNION ALL
SELECT 'SQL Keyword','END' UNION ALL
SELECT 'SQL Keyword','ORDER' UNION ALL
SELECT 'SQL Keyword','WAITFOR' UNION ALL
SELECT 'SQL Keyword','ERRLVL' UNION ALL
SELECT 'SQL Keyword','OUTER' UNION ALL
SELECT 'SQL Keyword','WHEN' UNION ALL
SELECT 'SQL Keyword','ESCAPE' UNION ALL
SELECT 'SQL Keyword','OVER' UNION ALL
SELECT 'SQL Keyword','WHERE' UNION ALL
SELECT 'SQL Keyword','EXCEPT' UNION ALL
SELECT 'SQL Keyword','PERCENT' UNION ALL
SELECT 'SQL Keyword','WHILE' UNION ALL
SELECT 'SQL Keyword','EXEC' UNION ALL
SELECT 'SQL Keyword','PIVOT' UNION ALL
SELECT 'SQL Keyword','WITH' UNION ALL
SELECT 'SQL Keyword','EXECUTE' UNION ALL
SELECT 'SQL Keyword','PLAN' UNION ALL
SELECT 'SQL Keyword','WRITETEXT' UNION ALL
SELECT 'ODBC Keyword','ABSOLUTE' UNION ALL
SELECT 'ODBC Keyword','EXEC' UNION ALL
SELECT 'ODBC Keyword','OVERLAPS' UNION ALL
SELECT 'ODBC Keyword','ACTION' UNION ALL
SELECT 'ODBC Keyword','EXECUTE' UNION ALL
SELECT 'ODBC Keyword','PAD' UNION ALL
SELECT 'ODBC Keyword','ADA' UNION ALL
SELECT 'ODBC Keyword','EXISTS' UNION ALL
SELECT 'ODBC Keyword','PARTIAL' UNION ALL
SELECT 'ODBC Keyword','ADD' UNION ALL
SELECT 'ODBC Keyword','EXTERNAL' UNION ALL
SELECT 'ODBC Keyword','PASCAL' UNION ALL
SELECT 'ODBC Keyword','ALL' UNION ALL
SELECT 'ODBC Keyword','EXTRACT' UNION ALL
SELECT 'ODBC Keyword','POSITION' UNION ALL
SELECT 'ODBC Keyword','ALLOCATE' UNION ALL
SELECT 'ODBC Keyword','FALSE' UNION ALL
SELECT 'ODBC Keyword','PRECISION' UNION ALL
SELECT 'ODBC Keyword','ALTER' UNION ALL
SELECT 'ODBC Keyword','FETCH' UNION ALL
SELECT 'ODBC Keyword','PREPARE' UNION ALL
SELECT 'ODBC Keyword','AND' UNION ALL
SELECT 'ODBC Keyword','FIRST' UNION ALL
SELECT 'ODBC Keyword','PRESERVE' UNION ALL
SELECT 'ODBC Keyword','ANY' UNION ALL
SELECT 'ODBC Keyword','FLOAT' UNION ALL
SELECT 'ODBC Keyword','PRIMARY' UNION ALL
SELECT 'ODBC Keyword','ARE' UNION ALL
SELECT 'ODBC Keyword','FOR' UNION ALL
SELECT 'ODBC Keyword','PRIOR' UNION ALL
SELECT 'ODBC Keyword','AS' UNION ALL
SELECT 'ODBC Keyword','FOREIGN' UNION ALL
SELECT 'ODBC Keyword','PRIVILEGES' UNION ALL
SELECT 'ODBC Keyword','ASC' UNION ALL
SELECT 'ODBC Keyword','FORTRAN' UNION ALL
SELECT 'ODBC Keyword','PROCEDURE' UNION ALL
SELECT 'ODBC Keyword','ASSERTION' UNION ALL
SELECT 'ODBC Keyword','FOUND' UNION ALL
SELECT 'ODBC Keyword','PUBLIC' UNION ALL
SELECT 'ODBC Keyword','AT' UNION ALL
SELECT 'ODBC Keyword','FROM' UNION ALL
SELECT 'ODBC Keyword','READ' UNION ALL
SELECT 'ODBC Keyword','AUTHORIZATION' UNION ALL
SELECT 'ODBC Keyword','FULL' UNION ALL
SELECT 'ODBC Keyword','REAL' UNION ALL
SELECT 'ODBC Keyword','AVG' UNION ALL
SELECT 'ODBC Keyword','GET' UNION ALL
SELECT 'ODBC Keyword','REFERENCES' UNION ALL
SELECT 'ODBC Keyword','BEGIN' UNION ALL
SELECT 'ODBC Keyword','GLOBAL' UNION ALL
SELECT 'ODBC Keyword','RELATIVE' UNION ALL
SELECT 'ODBC Keyword','BETWEEN' UNION ALL
SELECT 'ODBC Keyword','GO' UNION ALL
SELECT 'ODBC Keyword','RESTRICT' UNION ALL
SELECT 'ODBC Keyword','BIT' UNION ALL
SELECT 'ODBC Keyword','GOTO' UNION ALL
SELECT 'ODBC Keyword','REVOKE' UNION ALL
SELECT 'ODBC Keyword','BIT_LENGTH' UNION ALL
SELECT 'ODBC Keyword','GRANT' UNION ALL
SELECT 'ODBC Keyword','RIGHT' UNION ALL
SELECT 'ODBC Keyword','BOTH' UNION ALL
SELECT 'ODBC Keyword','GROUP' UNION ALL
SELECT 'ODBC Keyword','ROLLBACK' UNION ALL
SELECT 'ODBC Keyword','BY' UNION ALL
SELECT 'ODBC Keyword','HAVING' UNION ALL
SELECT 'ODBC Keyword','ROWS' UNION ALL
SELECT 'ODBC Keyword','CASCADE' UNION ALL
SELECT 'ODBC Keyword','HOUR' UNION ALL
SELECT 'ODBC Keyword','SCHEMA' UNION ALL
SELECT 'ODBC Keyword','CASCADED' UNION ALL
SELECT 'ODBC Keyword','IDENTITY' UNION ALL
SELECT 'ODBC Keyword','SCROLL' UNION ALL
SELECT 'ODBC Keyword','CASE' UNION ALL
SELECT 'ODBC Keyword','IMMEDIATE' UNION ALL
SELECT 'ODBC Keyword','SECOND' UNION ALL
SELECT 'ODBC Keyword','CAST' UNION ALL
SELECT 'ODBC Keyword','IN' UNION ALL
SELECT 'ODBC Keyword','SECTION' UNION ALL
SELECT 'ODBC Keyword','CATALOG' UNION ALL
SELECT 'ODBC Keyword','INCLUDE' UNION ALL
SELECT 'ODBC Keyword','SELECT' UNION ALL
SELECT 'ODBC Keyword','CHAR' UNION ALL
SELECT 'ODBC Keyword','INDEX' UNION ALL
SELECT 'ODBC Keyword','SESSION' UNION ALL
SELECT 'ODBC Keyword','CHAR_LENGTH' UNION ALL
SELECT 'ODBC Keyword','INDICATOR' UNION ALL
SELECT 'ODBC Keyword','SESSION_USER' UNION ALL
SELECT 'ODBC Keyword','CHARACTER' UNION ALL
SELECT 'ODBC Keyword','INITIALLY' UNION ALL
SELECT 'ODBC Keyword','SET' UNION ALL
SELECT 'ODBC Keyword','CHARACTER_LENGTH' UNION ALL
SELECT 'ODBC Keyword','INNER' UNION ALL
SELECT 'ODBC Keyword','SIZE' UNION ALL
SELECT 'ODBC Keyword','CHECK' UNION ALL
SELECT 'ODBC Keyword','INPUT' UNION ALL
SELECT 'ODBC Keyword','SMALLINT' UNION ALL
SELECT 'ODBC Keyword','CLOSE' UNION ALL
SELECT 'ODBC Keyword','INSENSITIVE' UNION ALL
SELECT 'ODBC Keyword','SOME' UNION ALL
SELECT 'ODBC Keyword','COALESCE' UNION ALL
SELECT 'ODBC Keyword','INSERT' UNION ALL
SELECT 'ODBC Keyword','SPACE' UNION ALL
SELECT 'ODBC Keyword','COLLATE' UNION ALL
SELECT 'ODBC Keyword','INT' UNION ALL
SELECT 'ODBC Keyword','SQL' UNION ALL
SELECT 'ODBC Keyword','COLLATION' UNION ALL
SELECT 'ODBC Keyword','INTEGER' UNION ALL
SELECT 'ODBC Keyword','SQLCA' UNION ALL
SELECT 'ODBC Keyword','COLUMN' UNION ALL
SELECT 'ODBC Keyword','INTERSECT' UNION ALL
SELECT 'ODBC Keyword','SQLCODE' UNION ALL
SELECT 'ODBC Keyword','COMMIT' UNION ALL
SELECT 'ODBC Keyword','INTERVAL' UNION ALL
SELECT 'ODBC Keyword','SQLERROR' UNION ALL
SELECT 'ODBC Keyword','CONNECT' UNION ALL
SELECT 'ODBC Keyword','INTO' UNION ALL
SELECT 'ODBC Keyword','SQLSTATE' UNION ALL
SELECT 'ODBC Keyword','CONNECTION' UNION ALL
SELECT 'ODBC Keyword','IS' UNION ALL
SELECT 'ODBC Keyword','SQLWARNING' UNION ALL
SELECT 'ODBC Keyword','CONSTRAINT' UNION ALL
SELECT 'ODBC Keyword','ISOLATION' UNION ALL
SELECT 'ODBC Keyword','SUBSTRING' UNION ALL
SELECT 'ODBC Keyword','CONSTRAINTS' UNION ALL
SELECT 'ODBC Keyword','JOIN' UNION ALL
SELECT 'ODBC Keyword','SUM' UNION ALL
SELECT 'ODBC Keyword','CONTINUE' UNION ALL
SELECT 'ODBC Keyword','KEY' UNION ALL
SELECT 'ODBC Keyword','SYSTEM_USER' UNION ALL
SELECT 'ODBC Keyword','CONVERT' UNION ALL
SELECT 'ODBC Keyword','LANGUAGE' UNION ALL
SELECT 'ODBC Keyword','TABLE' UNION ALL
SELECT 'ODBC Keyword','CORRESPONDING' UNION ALL
SELECT 'ODBC Keyword','LAST' UNION ALL
SELECT 'ODBC Keyword','TEMPORARY' UNION ALL
SELECT 'ODBC Keyword','COUNT' UNION ALL
SELECT 'ODBC Keyword','LEADING' UNION ALL
SELECT 'ODBC Keyword','THEN' UNION ALL
SELECT 'ODBC Keyword','CREATE' UNION ALL
SELECT 'ODBC Keyword','LEFT' UNION ALL
SELECT 'ODBC Keyword','TIME' UNION ALL
SELECT 'ODBC Keyword','CROSS' UNION ALL
SELECT 'ODBC Keyword','LEVEL' UNION ALL
SELECT 'ODBC Keyword','TIMESTAMP' UNION ALL
SELECT 'ODBC Keyword','CURRENT' UNION ALL
SELECT 'ODBC Keyword','LIKE' UNION ALL
SELECT 'ODBC Keyword','TIMEZONE_HOUR' UNION ALL
SELECT 'ODBC Keyword','CURRENT_DATE' UNION ALL
SELECT 'ODBC Keyword','LOCAL' UNION ALL
SELECT 'ODBC Keyword','TIMEZONE_MINUTE' UNION ALL
SELECT 'ODBC Keyword','CURRENT_TIME' UNION ALL
SELECT 'ODBC Keyword','LOWER' UNION ALL
SELECT 'ODBC Keyword','TO' UNION ALL
SELECT 'ODBC Keyword','CURRENT_TIMESTAMP' UNION ALL
SELECT 'ODBC Keyword','MATCH' UNION ALL
SELECT 'ODBC Keyword','TRAILING' UNION ALL
SELECT 'ODBC Keyword','CURRENT_USER' UNION ALL
SELECT 'ODBC Keyword','MAX' UNION ALL
SELECT 'ODBC Keyword','TRANSACTION' UNION ALL
SELECT 'ODBC Keyword','CURSOR' UNION ALL
SELECT 'ODBC Keyword','MIN' UNION ALL
SELECT 'ODBC Keyword','TRANSLATE' UNION ALL
SELECT 'ODBC Keyword','DATE' UNION ALL
SELECT 'ODBC Keyword','MINUTE' UNION ALL
SELECT 'ODBC Keyword','TRANSLATION' UNION ALL
SELECT 'ODBC Keyword','DAY' UNION ALL
SELECT 'ODBC Keyword','MODULE' UNION ALL
SELECT 'ODBC Keyword','TRIM' UNION ALL
SELECT 'ODBC Keyword','DEALLOCATE' UNION ALL
SELECT 'ODBC Keyword','MONTH' UNION ALL
SELECT 'ODBC Keyword','TRUE' UNION ALL
SELECT 'ODBC Keyword','DEC' UNION ALL
SELECT 'ODBC Keyword','NAMES' UNION ALL
SELECT 'ODBC Keyword','UNION' UNION ALL
SELECT 'ODBC Keyword','DECIMAL' UNION ALL
SELECT 'ODBC Keyword','NATIONAL' UNION ALL
SELECT 'ODBC Keyword','UNIQUE' UNION ALL
SELECT 'ODBC Keyword','DECLARE' UNION ALL
SELECT 'ODBC Keyword','NATURAL' UNION ALL
SELECT 'ODBC Keyword','UNKNOWN' UNION ALL
SELECT 'ODBC Keyword','DEFAULT' UNION ALL
SELECT 'ODBC Keyword','NCHAR' UNION ALL
SELECT 'ODBC Keyword','UPDATE' UNION ALL
SELECT 'ODBC Keyword','DEFERRABLE' UNION ALL
SELECT 'ODBC Keyword','NEXT' UNION ALL
SELECT 'ODBC Keyword','UPPER' UNION ALL
SELECT 'ODBC Keyword','DEFERRED' UNION ALL
SELECT 'ODBC Keyword','NO' UNION ALL
SELECT 'ODBC Keyword','USAGE' UNION ALL
SELECT 'ODBC Keyword','DELETE' UNION ALL
SELECT 'ODBC Keyword','NONE' UNION ALL
SELECT 'ODBC Keyword','USER' UNION ALL
SELECT 'ODBC Keyword','DESC' UNION ALL
SELECT 'ODBC Keyword','NOT' UNION ALL
SELECT 'ODBC Keyword','USING' UNION ALL
SELECT 'ODBC Keyword','DESCRIBE' UNION ALL
SELECT 'ODBC Keyword','NULL' UNION ALL
SELECT 'ODBC Keyword','VALUE' UNION ALL
SELECT 'ODBC Keyword','DESCRIPTOR' UNION ALL
SELECT 'ODBC Keyword','NULLIF' UNION ALL
SELECT 'ODBC Keyword','VALUES' UNION ALL
SELECT 'ODBC Keyword','DIAGNOSTICS' UNION ALL
SELECT 'ODBC Keyword','NUMERIC' UNION ALL
SELECT 'ODBC Keyword','VARCHAR' UNION ALL
SELECT 'ODBC Keyword','DISCONNECT' UNION ALL
SELECT 'ODBC Keyword','OCTET_LENGTH' UNION ALL
SELECT 'ODBC Keyword','VARYING' UNION ALL
SELECT 'ODBC Keyword','DISTINCT' UNION ALL
SELECT 'ODBC Keyword','OF' UNION ALL
SELECT 'ODBC Keyword','VIEW' UNION ALL
SELECT 'ODBC Keyword','DOMAIN' UNION ALL
SELECT 'ODBC Keyword','ON' UNION ALL
SELECT 'ODBC Keyword','WHEN' UNION ALL
SELECT 'ODBC Keyword','DOUBLE' UNION ALL
SELECT 'ODBC Keyword','ONLY' UNION ALL
SELECT 'ODBC Keyword','WHENEVER' UNION ALL
SELECT 'ODBC Keyword','DROP' UNION ALL
SELECT 'ODBC Keyword','OPEN' UNION ALL
SELECT 'ODBC Keyword','WHERE' UNION ALL
SELECT 'ODBC Keyword','ELSE' UNION ALL
SELECT 'ODBC Keyword','OPTION' UNION ALL
SELECT 'ODBC Keyword','WITH' UNION ALL
SELECT 'ODBC Keyword','END' UNION ALL
SELECT 'ODBC Keyword','OR' UNION ALL
SELECT 'ODBC Keyword','WORK' UNION ALL
SELECT 'ODBC Keyword','END-EXEC' UNION ALL
SELECT 'ODBC Keyword','ORDER' UNION ALL
SELECT 'ODBC Keyword','WRITE' UNION ALL
SELECT 'ODBC Keyword','ESCAPE' UNION ALL
SELECT 'ODBC Keyword','OUTER' UNION ALL
SELECT 'ODBC Keyword','YEAR' UNION ALL
SELECT 'ODBC Keyword','EXCEPT' UNION ALL
SELECT 'ODBC Keyword','OUTPUT' UNION ALL
SELECT 'ODBC Keyword','ZONE' UNION ALL
SELECT 'ODBC Keyword','EXCEPTION' UNION ALL
SELECT 'Future Keyword','ABSOLUTE' UNION ALL
SELECT 'Future Keyword','HOST' UNION ALL
SELECT 'Future Keyword','RELATIVE' UNION ALL
SELECT 'Future Keyword','ACTION' UNION ALL
SELECT 'Future Keyword','HOUR' UNION ALL
SELECT 'Future Keyword','RELEASE' UNION ALL
SELECT 'Future Keyword','ADMIN' UNION ALL
SELECT 'Future Keyword','IGNORE' UNION ALL
SELECT 'Future Keyword','RESULT' UNION ALL
SELECT 'Future Keyword','AFTER' UNION ALL
SELECT 'Future Keyword','IMMEDIATE' UNION ALL
SELECT 'Future Keyword','RETURNS' UNION ALL
SELECT 'Future Keyword','AGGREGATE' UNION ALL
SELECT 'Future Keyword','INDICATOR' UNION ALL
SELECT 'Future Keyword','ROLE' UNION ALL
SELECT 'Future Keyword','ALIAS' UNION ALL
SELECT 'Future Keyword','INITIALIZE' UNION ALL
SELECT 'Future Keyword','ROLLUP' UNION ALL
SELECT 'Future Keyword','ALLOCATE' UNION ALL
SELECT 'Future Keyword','INITIALLY' UNION ALL
SELECT 'Future Keyword','ROUTINE' UNION ALL
SELECT 'Future Keyword','ARE' UNION ALL
SELECT 'Future Keyword','INOUT' UNION ALL
SELECT 'Future Keyword','ROW' UNION ALL
SELECT 'Future Keyword','ARRAY' UNION ALL
SELECT 'Future Keyword','INPUT' UNION ALL
SELECT 'Future Keyword','ROWS' UNION ALL
SELECT 'Future Keyword','ASENSITIVE' UNION ALL
SELECT 'Future Keyword','INT' UNION ALL
SELECT 'Future Keyword','SAVEPOINT' UNION ALL
SELECT 'Future Keyword','ASSERTION' UNION ALL
SELECT 'Future Keyword','INTEGER' UNION ALL
SELECT 'Future Keyword','SCROLL' UNION ALL
SELECT 'Future Keyword','ASYMMETRIC' UNION ALL
SELECT 'Future Keyword','INTERSECTION' UNION ALL
SELECT 'Future Keyword','SCOPE' UNION ALL
SELECT 'Future Keyword','AT' UNION ALL
SELECT 'Future Keyword','INTERVAL' UNION ALL
SELECT 'Future Keyword','SEARCH' UNION ALL
SELECT 'Future Keyword','ATOMIC' UNION ALL
SELECT 'Future Keyword','ISOLATION' UNION ALL
SELECT 'Future Keyword','SECOND' UNION ALL
SELECT 'Future Keyword','BEFORE' UNION ALL
SELECT 'Future Keyword','ITERATE' UNION ALL
SELECT 'Future Keyword','SECTION' UNION ALL
SELECT 'Future Keyword','BINARY' UNION ALL
SELECT 'Future Keyword','LANGUAGE' UNION ALL
SELECT 'Future Keyword','SENSITIVE' UNION ALL
SELECT 'Future Keyword','BIT' UNION ALL
SELECT 'Future Keyword','LARGE' UNION ALL
SELECT 'Future Keyword','SEQUENCE' UNION ALL
SELECT 'Future Keyword','BLOB' UNION ALL
SELECT 'Future Keyword','LAST' UNION ALL
SELECT 'Future Keyword','SESSION' UNION ALL
SELECT 'Future Keyword','BOOLEAN' UNION ALL
SELECT 'Future Keyword','LATERAL' UNION ALL
SELECT 'Future Keyword','SETS' UNION ALL
SELECT 'Future Keyword','BOTH' UNION ALL
SELECT 'Future Keyword','LEADING' UNION ALL
SELECT 'Future Keyword','SIMILAR' UNION ALL
SELECT 'Future Keyword','BREADTH' UNION ALL
SELECT 'Future Keyword','LESS' UNION ALL
SELECT 'Future Keyword','SIZE' UNION ALL
SELECT 'Future Keyword','CALL' UNION ALL
SELECT 'Future Keyword','LEVEL' UNION ALL
SELECT 'Future Keyword','SMALLINT' UNION ALL
SELECT 'Future Keyword','CALLED' UNION ALL
SELECT 'Future Keyword','LIKE_REGEX' UNION ALL
SELECT 'Future Keyword','SPACE' UNION ALL
SELECT 'Future Keyword','CARDINALITY' UNION ALL
SELECT 'Future Keyword','LIMIT' UNION ALL
SELECT 'Future Keyword','SPECIFIC' UNION ALL
SELECT 'Future Keyword','CASCADED' UNION ALL
SELECT 'Future Keyword','LN' UNION ALL
SELECT 'Future Keyword','SPECIFICTYPE' UNION ALL
SELECT 'Future Keyword','CAST' UNION ALL
SELECT 'Future Keyword','LOCAL' UNION ALL
SELECT 'Future Keyword','SQL' UNION ALL
SELECT 'Future Keyword','CATALOG' UNION ALL
SELECT 'Future Keyword','LOCALTIME' UNION ALL
SELECT 'Future Keyword','SQLEXCEPTION' UNION ALL
SELECT 'Future Keyword','CHAR' UNION ALL
SELECT 'Future Keyword','LOCALTIMESTAMP' UNION ALL
SELECT 'Future Keyword','SQLSTATE' UNION ALL
SELECT 'Future Keyword','CHARACTER' UNION ALL
SELECT 'Future Keyword','LOCATOR' UNION ALL
SELECT 'Future Keyword','SQLWARNING' UNION ALL
SELECT 'Future Keyword','CLASS' UNION ALL
SELECT 'Future Keyword','MAP' UNION ALL
SELECT 'Future Keyword','START' UNION ALL
SELECT 'Future Keyword','CLOB' UNION ALL
SELECT 'Future Keyword','MATCH' UNION ALL
SELECT 'Future Keyword','STATE' UNION ALL
SELECT 'Future Keyword','COLLATION' UNION ALL
SELECT 'Future Keyword','MEMBER' UNION ALL
SELECT 'Future Keyword','STATEMENT' UNION ALL
SELECT 'Future Keyword','COLLECT' UNION ALL
SELECT 'Future Keyword','METHOD' UNION ALL
SELECT 'Future Keyword','STATIC' UNION ALL
SELECT 'Future Keyword','COMPLETION' UNION ALL
SELECT 'Future Keyword','MINUTE' UNION ALL
SELECT 'Future Keyword','STDDEV_POP' UNION ALL
SELECT 'Future Keyword','CONDITION' UNION ALL
SELECT 'Future Keyword','MOD' UNION ALL
SELECT 'Future Keyword','STDDEV_SAMP' UNION ALL
SELECT 'Future Keyword','CONNECT' UNION ALL
SELECT 'Future Keyword','MODIFIES' UNION ALL
SELECT 'Future Keyword','STRUCTURE' UNION ALL
SELECT 'Future Keyword','CONNECTION' UNION ALL
SELECT 'Future Keyword','MODIFY' UNION ALL
SELECT 'Future Keyword','SUBMULTISET' UNION ALL
SELECT 'Future Keyword','CONSTRAINTS' UNION ALL
SELECT 'Future Keyword','MODULE' UNION ALL
SELECT 'Future Keyword','SUBSTRING_REGEX' UNION ALL
SELECT 'Future Keyword','CONSTRUCTOR' UNION ALL
SELECT 'Future Keyword','MONTH' UNION ALL
SELECT 'Future Keyword','SYMMETRIC' UNION ALL
SELECT 'Future Keyword','CORR' UNION ALL
SELECT 'Future Keyword','MULTISET' UNION ALL
SELECT 'Future Keyword','SYSTEM' UNION ALL
SELECT 'Future Keyword','CORRESPONDING' UNION ALL
SELECT 'Future Keyword','NAMES' UNION ALL
SELECT 'Future Keyword','TEMPORARY' UNION ALL
SELECT 'Future Keyword','COVAR_POP' UNION ALL
SELECT 'Future Keyword','NATURAL' UNION ALL
SELECT 'Future Keyword','TERMINATE' UNION ALL
SELECT 'Future Keyword','COVAR_SAMP' UNION ALL
SELECT 'Future Keyword','NCHAR' UNION ALL
SELECT 'Future Keyword','THAN' UNION ALL
SELECT 'Future Keyword','CUBE' UNION ALL
SELECT 'Future Keyword','NCLOB' UNION ALL
SELECT 'Future Keyword','TIME' UNION ALL
SELECT 'Future Keyword','CUME_DIST' UNION ALL
SELECT 'Future Keyword','NEW' UNION ALL
SELECT 'Future Keyword','TIMESTAMP' UNION ALL
SELECT 'Future Keyword','CURRENT_CATALOG' UNION ALL
SELECT 'Future Keyword','NEXT' UNION ALL
SELECT 'Future Keyword','TIMEZONE_HOUR' UNION ALL
SELECT 'Future Keyword','CURRENT_DEFAULT_TRANSFORM_GROUP' UNION ALL
SELECT 'Future Keyword','NO' UNION ALL
SELECT 'Future Keyword','TIMEZONE_MINUTE' UNION ALL
SELECT 'Future Keyword','CURRENT_PATH' UNION ALL
SELECT 'Future Keyword','NONE' UNION ALL
SELECT 'Future Keyword','TRAILING' UNION ALL
SELECT 'Future Keyword','CURRENT_ROLE' UNION ALL
SELECT 'Future Keyword','NORMALIZE' UNION ALL
SELECT 'Future Keyword','TRANSLATE_REGEX' UNION ALL
SELECT 'Future Keyword','CURRENT_SCHEMA' UNION ALL
SELECT 'Future Keyword','NUMERIC' UNION ALL
SELECT 'Future Keyword','TRANSLATION' UNION ALL
SELECT 'Future Keyword','CURRENT_TRANSFORM_GROUP_FOR_TYPE' UNION ALL
SELECT 'Future Keyword','OBJECT' UNION ALL
SELECT 'Future Keyword','TREAT' UNION ALL
SELECT 'Future Keyword','CYCLE' UNION ALL
SELECT 'Future Keyword','OCCURRENCES_REGEX' UNION ALL
SELECT 'Future Keyword','TRUE' UNION ALL
SELECT 'Future Keyword','DATA' UNION ALL
SELECT 'Future Keyword','OLD' UNION ALL
SELECT 'Future Keyword','UESCAPE' UNION ALL
SELECT 'Future Keyword','DATE' UNION ALL
SELECT 'Future Keyword','ONLY' UNION ALL
SELECT 'Future Keyword','UNDER' UNION ALL
SELECT 'Future Keyword','DAY' UNION ALL
SELECT 'Future Keyword','OPERATION' UNION ALL
SELECT 'Future Keyword','UNKNOWN' UNION ALL
SELECT 'Future Keyword','DEC' UNION ALL
SELECT 'Future Keyword','ORDINALITY' UNION ALL
SELECT 'Future Keyword','UNNEST' UNION ALL
SELECT 'Future Keyword','DECIMAL' UNION ALL
SELECT 'Future Keyword','OUT' UNION ALL
SELECT 'Future Keyword','USAGE' UNION ALL
SELECT 'Future Keyword','DEFERRABLE' UNION ALL
SELECT 'Future Keyword','OVERLAY' UNION ALL
SELECT 'Future Keyword','USING' UNION ALL
SELECT 'Future Keyword','DEFERRED' UNION ALL
SELECT 'Future Keyword','OUTPUT' UNION ALL
SELECT 'Future Keyword','VALUE' UNION ALL
SELECT 'Future Keyword','DEPTH' UNION ALL
SELECT 'Future Keyword','PAD' UNION ALL
SELECT 'Future Keyword','VAR_POP' UNION ALL
SELECT 'Future Keyword','DEREF' UNION ALL
SELECT 'Future Keyword','PARAMETER' UNION ALL
SELECT 'Future Keyword','VAR_SAMP' UNION ALL
SELECT 'Future Keyword','DESCRIBE' UNION ALL
SELECT 'Future Keyword','PARAMETERS' UNION ALL
SELECT 'Future Keyword','VARCHAR' UNION ALL
SELECT 'Future Keyword','DESCRIPTOR' UNION ALL
SELECT 'Future Keyword','PARTIAL' UNION ALL
SELECT 'Future Keyword','VARIABLE' UNION ALL
SELECT 'Future Keyword','DESTROY' UNION ALL
SELECT 'Future Keyword','PARTITION' UNION ALL
SELECT 'Future Keyword','WHENEVER' UNION ALL
SELECT 'Future Keyword','DESTRUCTOR' UNION ALL
SELECT 'Future Keyword','PATH' UNION ALL
SELECT 'Future Keyword','WIDTH_BUCKET' UNION ALL
SELECT 'Future Keyword','DETERMINISTIC' UNION ALL
SELECT 'Future Keyword','POSTFIX' UNION ALL
SELECT 'Future Keyword','WITHOUT' UNION ALL
SELECT 'Future Keyword','DICTIONARY' UNION ALL
SELECT 'Future Keyword','PREFIX' UNION ALL
SELECT 'Future Keyword','WINDOW' UNION ALL
SELECT 'Future Keyword','DIAGNOSTICS' UNION ALL
SELECT 'Future Keyword','PREORDER' UNION ALL
SELECT 'Future Keyword','WITHIN' UNION ALL
SELECT 'Future Keyword','DISCONNECT' UNION ALL
SELECT 'Future Keyword','PREPARE' UNION ALL
SELECT 'Future Keyword','WORK' UNION ALL
SELECT 'Future Keyword','DOMAIN' UNION ALL
SELECT 'Future Keyword','PERCENT_RANK' UNION ALL
SELECT 'Future Keyword','WRITE' UNION ALL
SELECT 'Future Keyword','DYNAMIC' UNION ALL
SELECT 'Future Keyword','PERCENTILE_CONT' UNION ALL
SELECT 'Future Keyword','XMLAGG' UNION ALL
SELECT 'Future Keyword','EACH' UNION ALL
SELECT 'Future Keyword','PERCENTILE_DISC' UNION ALL
SELECT 'Future Keyword','XMLATTRIBUTES' UNION ALL
SELECT 'Future Keyword','ELEMENT' UNION ALL
SELECT 'Future Keyword','POSITION_REGEX' UNION ALL
SELECT 'Future Keyword','XMLBINARY' UNION ALL
SELECT 'Future Keyword','END-EXEC' UNION ALL
SELECT 'Future Keyword','PRESERVE' UNION ALL
SELECT 'Future Keyword','XMLCAST' UNION ALL
SELECT 'Future Keyword','EQUALS' UNION ALL
SELECT 'Future Keyword','PRIOR' UNION ALL
SELECT 'Future Keyword','XMLCOMMENT' UNION ALL
SELECT 'Future Keyword','EVERY' UNION ALL
SELECT 'Future Keyword','PRIVILEGES' UNION ALL
SELECT 'Future Keyword','XMLCONCAT' UNION ALL
SELECT 'Future Keyword','EXCEPTION' UNION ALL
SELECT 'Future Keyword','RANGE' UNION ALL
SELECT 'Future Keyword','XMLDOCUMENT' UNION ALL
SELECT 'Future Keyword','FALSE' UNION ALL
SELECT 'Future Keyword','READS' UNION ALL
SELECT 'Future Keyword','XMLELEMENT' UNION ALL
SELECT 'Future Keyword','FILTER' UNION ALL
SELECT 'Future Keyword','REAL' UNION ALL
SELECT 'Future Keyword','XMLEXISTS' UNION ALL
SELECT 'Future Keyword','FIRST' UNION ALL
SELECT 'Future Keyword','RECURSIVE' UNION ALL
SELECT 'Future Keyword','XMLFOREST' UNION ALL
SELECT 'Future Keyword','FLOAT' UNION ALL
SELECT 'Future Keyword','REF' UNION ALL
SELECT 'Future Keyword','XMLITERATE' UNION ALL
SELECT 'Future Keyword','FOUND' UNION ALL
SELECT 'Future Keyword','REFERENCING' UNION ALL
SELECT 'Future Keyword','XMLNAMESPACES' UNION ALL
SELECT 'Future Keyword','FREE' UNION ALL
SELECT 'Future Keyword','REGR_AVGX' UNION ALL
SELECT 'Future Keyword','XMLPARSE' UNION ALL
SELECT 'Future Keyword','FULLTEXTTABLE' UNION ALL
SELECT 'Future Keyword','REGR_AVGY' UNION ALL
SELECT 'Future Keyword','XMLPI' UNION ALL
SELECT 'Future Keyword','FUSION' UNION ALL
SELECT 'Future Keyword','REGR_COUNT' UNION ALL
SELECT 'Future Keyword','XMLQUERY' UNION ALL
SELECT 'Future Keyword','GENERAL' UNION ALL
SELECT 'Future Keyword','REGR_INTERCEPT' UNION ALL
SELECT 'Future Keyword','XMLSERIALIZE' UNION ALL
SELECT 'Future Keyword','GET' UNION ALL
SELECT 'Future Keyword','REGR_R2' UNION ALL
SELECT 'Future Keyword','XMLTABLE' UNION ALL
SELECT 'Future Keyword','GLOBAL' UNION ALL
SELECT 'Future Keyword','REGR_SLOPE' UNION ALL
SELECT 'Future Keyword','XMLTEXT' UNION ALL
SELECT 'Future Keyword','GO' UNION ALL
SELECT 'Future Keyword','REGR_SXX' UNION ALL
SELECT 'Future Keyword','XMLVALIDATE' UNION ALL
SELECT 'Future Keyword','GROUPING' UNION ALL
SELECT 'Future Keyword','REGR_SXY' UNION ALL
SELECT 'Future Keyword','YEAR' UNION ALL
SELECT 'Future Keyword','HOLD' UNION ALL
SELECT 'Future Keyword','REGR_SYY' UNION ALL
SELECT 'Future Keyword','ZONE'
)
Select * into #temp  from Allkeywords



SELECT  column_name, table_name into #temp1
FROM    ( SELECT    REPLACE(LOWER(objects.type_desc), '_', ' ') AS table_type, schemas.name AS schema_name, objects.name AS table_name, 
                    columns.name AS column_name, CASE WHEN columns.is_identity = 1 THEN 'IDENTITY NOT NULL' 
                                                      WHEN columns.is_nullable = 1 THEN 'NULL' 
                                                      ELSE 'NOT NULL' 
                                                 END AS nullability, 
                   --types that have a ascii character or binary length 
                    CASE WHEN columns.is_computed = 1 THEN 'Computed' 
                         WHEN types.name IN ( 'varchar', 'char', 'varbinary' ) THEN types.name + CASE WHEN columns.max_length = -1 THEN '(max)' 
                                                                                                      ELSE '(' + CAST(columns.max_length AS VARCHAR(4)) + ')' 
                                                                                                 END 
                 
                         --types that have an unicode character type that requires length to be halved 
                         WHEN types.name IN ( 'nvarchar', 'nchar' ) THEN types.name + CASE WHEN columns.max_length = -1 THEN '(max)' 
                                                                                           ELSE '(' + CAST(columns.max_length / 2 AS VARCHAR(4)) + ')' 
                                                                                      END

                          --types with a datetime precision 
                         WHEN types.name IN ( 'time', 'datetime2', 'datetimeoffset' ) THEN types.name + '(' + CAST(columns.scale AS VARCHAR(4)) + ')'

                         --types with a precision/scale 
                         WHEN types.name IN ( 'numeric', 'decimal' ) 
                         THEN types.name + '(' + CAST(columns.precision AS VARCHAR(4)) + ',' + CAST(columns.scale AS VARCHAR(4)) + ')'

                        --timestamp should be reported as rowversion 
                         WHEN types.name = 'timestamp' THEN 'rowversion' 
                         --and the rest. Note, float is declared with a bit length, but is 
                         --represented as either float or real in types  
                         ELSE types.name 
                    END AS declared_datatype,

                   --types that have a ascii character or binary length 
                    CASE WHEN baseType.name IN ( 'varchar', 'char', 'varbinary' ) THEN baseType.name + CASE WHEN columns.max_length = -1 THEN '(max)' 
                                                   ELSE '(' + CAST(columns.max_length AS VARCHAR(4)) + ')' 
                                              END 
                
                         --types that have an unicode character type that requires length to be halved 
                         WHEN baseType.name IN ( 'nvarchar', 'nchar' ) THEN baseType.name + CASE WHEN columns.max_length = -1 THEN '(max)' 
                                                                                                 ELSE '(' + CAST(columns.max_length / 2 AS VARCHAR(4)) + ')' 
                                                                                            END

                         --types with a datetime precision 
                         WHEN baseType.name IN ( 'time', 'datetime2', 'datetimeoffset' ) THEN baseType.name + '(' + CAST(columns.scale AS VARCHAR(4)) + ')'

                         --types with a precision/scale 
                         WHEN baseType.name IN ( 'numeric', 'decimal' ) 
                         THEN baseType.name + '(' + CAST(columns.precision AS VARCHAR(4)) + ',' + CAST(columns.scale AS VARCHAR(4)) + ')'

                         --timestamp should be reported as rowversion 
                         WHEN baseType.name = 'timestamp' THEN 'rowversion' 
                         --and the rest. Note, float is declared with a bit length, but is 
                         --represented as either float or real in types 
                         ELSE baseType.name 
                    END AS base_datatype, CASE WHEN EXISTS ( SELECT * 
                                                             FROM   sys.key_constraints 
                                                                    JOIN sys.indexes 
                                                                        ON key_constraints.parent_object_id = indexes.object_id 
                                                                           AND key_constraints.unique_index_id = indexes.index_id 
                                                                    JOIN sys.index_columns 
                                                                        ON index_columns.object_id = indexes.object_id 
                                                                           AND index_columns.index_id = indexes.index_id 
                                                             WHERE  key_constraints.type = 'PK' 
                                                                    AND columns.column_id = index_columns.column_id 
                                                                    AND columns.OBJECT_ID = index_columns.OBJECT_ID ) THEN 1 
                                               ELSE 0 
                                          END AS primary_key_column, columns.column_id, default_constraints.definition AS default_value, 
                    check_constraints.definition AS column_check_constraint, 
                    CASE WHEN EXISTS ( SELECT   * 
                                       FROM     sys.check_constraints AS cc 
                                       WHERE    cc.parent_object_id = columns.OBJECT_ID 
                                                AND cc.definition LIKE '%~[' + columns.name + '~]%' ESCAPE '~' 
                                                AND cc.parent_column_id = 0 ) THEN 1 
                         ELSE 0 
                    END AS table_check_constraint_reference 
          FROM      sys.columns 
                    JOIN sys.types 
                        ON columns.user_type_id = types.user_type_id 
                    JOIN sys.types AS baseType 
                        ON columns.system_type_id = baseType.system_type_id 
                           AND baseType.user_type_id = baseType.system_type_id 
                    JOIN sys.objects 
                            JOIN sys.schemas 
                                   ON schemas.schema_id = objects.schema_id 
                        ON objects.object_id = columns.OBJECT_ID 
                    LEFT OUTER JOIN sys.default_constraints 
                        ON default_constraints.parent_object_id = columns.object_id 
                              AND default_constraints.parent_column_id = columns.column_id 
                    LEFT OUTER JOIN sys.check_constraints 
                        ON check_constraints.parent_object_id = columns.object_id 
                             AND check_constraints.parent_column_id = columns.column_id ) AS rows 
WHERE   table_type = 'user table' 
              AND schema_name LIKE '%' 
              AND table_name LIKE '%' 
              AND column_name LIKE '%' 
              AND nullability LIKE '%' 
              AND base_datatype LIKE '%' 
              AND declared_datatype LIKE '%' 
ORDER BY table_type, schema_name, table_name, column_id  


select * from #temp t 
join (select column_name from #temp1
union select table_name from #temp1 )tbl 
on tbl.column_name = t.KeyWord

