/*
	Some examples of inconsistency that can't be coded

	it appears these are named opposite (i.e. either something is delivered by MS or user defined
	consistency should use the same "view"

	You don't need to run this, only note the field names appear opposing

*/

SELECT t.is_user_defined as 'sys.types.is_user_defined'
FROM sys.types t

SELECT o.is_ms_shipped as 'sys.objects.is_ms_shipped'
FROM sys.objects o