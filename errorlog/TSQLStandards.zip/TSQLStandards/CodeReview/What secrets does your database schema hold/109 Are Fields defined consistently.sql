/*

	Author: Andre' DuBois 
	E: MtnDBA@gmail.com  
	T: @MtnDBA
	B: MtnDBA.wordpress.com

	Presented: SQL Saturday #191 Kansas City
	September 14, 2013

	Purpose: Are fields defined Consistently?
	This is for a single database; select the database to browse

	Note: If there is no data returned, then there is no data in the requested field!
	Note: Or it is spelled wrong

	Examples: use msdb database

	Please run in non-production environment until you know what this scipt does. 
	It could affect performance or other nasty things;
			
*/

WITH X_CTE (CTEdatabase, CTEschema, CTEtable, CTEname, CTEtype, CTElow, CTEhigh, CTEcount) 
AS
(
	SELECT table_catalog 	AS [Catalog] 
		, TABLE_SCHEMA 	AS [Schema] 
		, TABLE_NAME 	AS [Table] 
		, COLUMN_NAME 	AS [Column]  
		, DATA_TYPE + '('+ CAST(CHARACTER_MAXIMUM_LENGTH AS nvarchar(40)) + ')' 	AS [MyFormat]
		, MIN(CHARACTER_MAXIMUM_LENGTH) OVER(PARTITION by COLUMN_NAME) 			AS [Shortest]
		, MAX(CHARACTER_MAXIMUM_LENGTH) OVER(PARTITION by COLUMN_NAME) 			AS [Longest]
		, COUNT(CHARACTER_MAXIMUM_LENGTH) OVER(PARTITION by COLUMN_NAME) 		AS [Column Name Count]
	FROM INFORMATION_SCHEMA.COLUMNS
	WHERE CHARACTER_MAXIMUM_LENGTH IS NOT NULL
)
SELECT CTEdatabase 	as [Database]
	, CTEschema 	as [Schema]
	, CTEtable 	as [Table]
	, CTEname 	as [Field Name]
	, CTEtype 	as [Data Type/Size]
	, CTElow 	as [Low Value]
	, CTEhigh 	as [High Value]
	, CTEcount 	as [Count]
FROM X_CTE
WHERE CTElow <> CTEhigh
ORDER BY CTEname;
