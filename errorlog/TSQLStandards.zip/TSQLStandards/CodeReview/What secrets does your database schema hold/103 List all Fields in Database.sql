/*

	Author: Andre' DuBois 
	E: MtnDBA@gmail.com  
	T: @MtnDBA
	B: MtnDBA.wordpress.com

	Presented: SQL Saturday #191 Kansas City
	September 14, 2013

	Purpose: Show all Tables & fields in one list
	This is for a single database; select the database to browse

	Note: uncomment line below for wildcard search

	Please run in non-production environment until you know what this scipt does. 
	It could affect performance or other nasty things;
	
*/


SELECT c.TABLE_CATALOG
	, c.TABLE_SCHEMA
	, c.TABLE_NAME
	, c.COLUMN_NAME
	, c.DATA_TYPE
FROM INFORMATION_SCHEMA.COLUMNS AS c
-- Un-Comment out next line and change search string to find all fields that match wildcard name
-- WHERE c.COLUMN_NAME like '%zip%'
ORDER BY c.TABLE_SCHEMA, c.TABLE_NAME, c.COLUMN_NAME
