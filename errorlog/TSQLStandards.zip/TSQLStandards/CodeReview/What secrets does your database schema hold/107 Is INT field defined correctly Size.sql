/*

	Author: Andre' DuBois 
	E: MtnDBA@gmail.com  
	T: @MtnDBA
	B: MtnDBA.wordpress.com

	Presented: SQL Saturday #191 Kansas City
	September 14, 2013

	Purpose: Is Int defined correctly?

	Note: For now hardcoding identifiers in :(
	Note: If there is no data returned, then there is no data in the requested field!
	Note: Or it is spelled wrong
	Note: This script uses the TSQL2012 database found at http://tsql.solidq.com/books/tsqlfund2012/ (download T-SQL script Click on Source Code)

	Values for data types
	tinyint		= 0 to 255
	smallint	= -32768 to 32767
	int		= -2,147,483,648 to 2,147,483,647
	bigint		= -9,223,372,036,854,775,808 to 9,223,372,036,854,775,807

	TSQL2012
	Stats.Scores.score		tinyint
	Sales.OrderDetails.qty	smallint
	dbo.Nums.n				int

	Please run in non-production environment until you know what this scipt does. 
	It could affect performance or other nasty things;
	

*/

USE TSQL2012;
GO

-- For Demo Show all rows
-- select * from stats.scores;

-- This is to find fields for testing
-- SELECT *
-- FROM INFORMATION_SCHEMA.COLUMNS c
-- WHERE c.data_type IN ('tinyint','smallint','int','bigint');

IF OBJECT_ID('tempdb..#HowBigIsYourInt') IS NOT NULL
	DROP TABLE #HowBigIsYourInt;

CREATE TABLE #HowBigIsYourInt
(
	xColumn		varchar(80),	-- Column Name
	xNumRows	int,			-- Num Rows in Table
	xMinValue	int,			-- Min Stored Value
	xMaxValue	int,			-- Max Stored Value
	xDataType	varchar(25),	-- Data Type
	xDataMax	bigint,			-- Data Type Max Value
	xDiff		bigint			-- Diff between Max Stored Value and Data Type Max
);

-- Stats.Scores.score = tinyint
INSERT INTO #HowBigIsYourInt
SELECT 'Stats.Scores.score'
	, COUNT(*)
	, MIN(s.score)
	, MAX(s.score)
	, c.DATA_TYPE
	, CASE
			WHEN (c.DATA_TYPE = 'TinyInt')	then 255						
			WHEN (c.Data_type = 'SmallInt')	then 32767					
			WHEN (c.DATA_TYPE = 'int')	then 2147483647			
			WHEN (c.DATA_TYPE = 'bigint')	then 9223372036854775807 
	  END
	, CASE
			WHEN (c.DATA_TYPE = 'TinyInt')	then (255			- MAX(s.score))						
			WHEN (c.Data_type = 'SmallInt')	then (32767			- MAX(s.score))					
			WHEN (c.DATA_TYPE = 'int')	then (2147483647		- MAX(s.score))				
			WHEN (c.DATA_TYPE = 'bigint')	then (9223372036854775807	- MAX(s.score))	
	  END
FROM Stats.Scores s
JOIN INFORMATION_SCHEMA.COLUMNS c
	ON c.TABLE_CATALOG = 'TSQL2012'
	AND	c.TABLE_SCHEMA = 'Stats'
	AND c.TABLE_NAME = 'Scores'
	AND c.COLUMN_NAME = 'score'
	GROUP BY c.DATA_TYPE;

-- Sales.OrderDetails.qty smallint
INSERT INTO #HowBigIsYourInt
SELECT 'Sales.OrderDetails.qty'
	, COUNT(*)
	, MIN(od.qty)
	, MAX(od.qty)
	, c.DATA_TYPE
	, CASE
			WHEN (c.DATA_TYPE = 'TinyInt')	then 255						
			WHEN (c.Data_type = 'SmallInt')	then 32767					
			WHEN (c.DATA_TYPE = 'int')		then 2147483647			
			WHEN (c.DATA_TYPE = 'bigint')	then 9223372036854775807 
	  END
	, CASE
			WHEN (c.DATA_TYPE = 'TinyInt')	then (255					- MAX(od.qty))						
			WHEN (c.Data_type = 'SmallInt')	then (32767					- MAX(od.qty))					
			WHEN (c.DATA_TYPE = 'int')		then (2147483647			- MAX(od.qty))				
			WHEN (c.DATA_TYPE = 'bigint')	then (9223372036854775807	- MAX(od.qty))	
	  END
FROM Sales.OrderDetails od
JOIN INFORMATION_SCHEMA.COLUMNS c
	ON c.TABLE_CATALOG = 'TSQL2012'
	AND	c.TABLE_SCHEMA = 'Sales'
	AND c.TABLE_NAME = 'OrderDetails'
	AND c.COLUMN_NAME = 'qty'
	GROUP BY c.DATA_TYPE;

-- 	dbo.Nums.n				int
INSERT INTO #HowBigIsYourInt
SELECT 'dbo.Nums.n'
	, COUNT(*)
	, MIN(n)
	, MAX(n)
	, c.DATA_TYPE
	, CASE
			WHEN (c.DATA_TYPE = 'TinyInt')	then 255						
			WHEN (c.Data_type = 'SmallInt')	then 32767					
			WHEN (c.DATA_TYPE = 'int')		then 2147483647			
			WHEN (c.DATA_TYPE = 'bigint')	then 9223372036854775807 
	  END
	, CASE
			WHEN (c.DATA_TYPE = 'TinyInt')	then (255					- MAX(n))						
			WHEN (c.Data_type = 'SmallInt')	then (32767					- MAX(n))					
			WHEN (c.DATA_TYPE = 'int')		then (2147483647			- MAX(n))				
			WHEN (c.DATA_TYPE = 'bigint')	then (9223372036854775807	- MAX(n))	
	  END
FROM dbo.Nums
JOIN INFORMATION_SCHEMA.COLUMNS c
	ON c.TABLE_CATALOG = 'TSQL2012'
	AND	c.TABLE_SCHEMA = 'dbo'
	AND c.TABLE_NAME = 'Nums'
	AND c.COLUMN_NAME = 'n'
	GROUP BY c.DATA_TYPE;

SELECT xColumn  as 'Column Name'
	, xNumRows  as '# Rows in Table'
	, xMinValue as 'Min Stored Value'
	, xMaxValue as 'Max Stored Value'
	, xDataType as 'Data Type'
	, xDataMax  as 'Max Value for Data Type'
	, xDiff     as 'Diff To Max'
FROM #HowBigIsYourInt;

-- select * from information_schema.columns where column_name = 'n';

DROP TABLE #HowBigIsYourInt;
