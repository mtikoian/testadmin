/*

	Author: Andre' DuBois 
	E: MtnDBA@gmail.com  
	T: @MtnDBA
	B: MtnDBA.wordpress.com

	Presented: SQL Saturday #191 Kansas City
	September 14, 2013

	Purpose: Check for spaces in Table_Name or Column_Name
	This is for a single database; select the database to browse

	Note: No data returned means no name (identifier) with a space 

	Please run in non-production environment until you know what this scipt does. 
	It could affect performance or other nasty things;
	
*/


-- Space in Table Name?
SELECT t.TABLE_CATALOG
	, t.TABLE_SCHEMA
	, t.TABLE_NAME 
FROM INFORMATION_SCHEMA.Tables AS t
WHERE t.TABLE_NAME LIKE '% %';

-- Space in Column Name? 
SELECT c.TABLE_CATALOG, c.TABLE_SCHEMA, c.TABLE_NAME, c.COLUMN_NAME, 'Space in Column Name'  
FROM INFORMATION_SCHEMA.COLUMNS AS c
WHERE c.COLUMN_NAME LIKE '% %';