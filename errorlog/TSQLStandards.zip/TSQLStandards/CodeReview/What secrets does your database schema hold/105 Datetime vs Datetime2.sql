/*

	Author: Andre' DuBois 
	E: MtnDBA@gmail.com  
	T: @MtnDBA
	B: MtnDBA.wordpress.com

	Presented: SQL Saturday #191 Kansas City
	September 14, 2013

	Purpose: Display count of date, time, datetime and datetime2 in a database
	This is for a single database; select the database to browse

	Please run in non-production environment until you know what this scipt does. 
	It could affect performance or other nasty things;

*/

-- What date data types does my database have?
SELECT DISTINCT c.data_type as 'Data Type'
	, COUNT(c.data_type) as 'Count'
	, TABLE_CATALOG as 'Database'
FROM INFORMATION_SCHEMA.COLUMNS AS c
WHERE c.data_type IN ('datetime','datetime2', 'date', 'time')
GROUP BY c.data_type, c.TABLE_CATALOG
ORDER BY COUNT(c.data_type) DESC;