/*

	Author: Andre' DuBois 
	E: MtnDBA@gmail.com  
	T: @MtnDBA
	B: MtnDBA.wordpress.com

	Presented: SQL Saturday #191 Kansas City
	September 14, 2013

	Purpose: Any deprecated data types still in use?
	This is for a single database; select the database to browse

	Please run in non-production environment until you know what this scipt does. 
	It could affect performance or other nasty things;
				
*/

select c.COLUMN_NAME
	, c.DATA_TYPE
	, c.ORDINAL_POSITION
	, c.COLUMN_DEFAULT
	, c.IS_NULLABLE
	, c.CHARACTER_MAXIMUM_LENGTH
	, c.NUMERIC_PRECISION
	, c.NUMERIC_PRECISION_RADIX
	, c.NUMERIC_SCALE
	, c.DATETIME_PRECISION
	, c.CHARACTER_SET_NAME 
from INFORMATION_SCHEMA.COLUMNS AS c
WHERE c.DATA_TYPE IN ('text', 'ntext', 'image', 'timestamp') 
ORDER BY c.DATA_TYPE, c.COLUMN_NAME;

GO
