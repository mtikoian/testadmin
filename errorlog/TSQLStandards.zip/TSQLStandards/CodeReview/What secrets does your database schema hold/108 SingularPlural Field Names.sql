/*

	Author: Andre' DuBois 
	E: MtnDBA@gmail.com  
	T: @MtnDBA
	B: MtnDBA.wordpress.com

	Presented: SQL Saturday #191 Kansas City
	September 14, 2013

	Purpose: Find identifiers with both singular and plural names
	This is for a single database; select the database to browse

	Examples:
	AdventureWorks2012 Comment[s]
	ReportServer       Parameter[s]

	Please run in non-production environment until you know what this scipt does. 
	It could affect performance or other nasty things;
		
*/

-- Find any variables that have singlular and plural names
SELECT c1.TABLE_CATALOG	AS 'Database'
	, c1.TABLE_SCHEMA	AS 'Schema 1'
	, c1.TABLE_NAME		AS 'Table 1'
	, c1.COLUMN_NAME	AS 'Column 1'
	, c2.TABLE_SCHEMA	AS 'Schema 2'
	, c2.TABLE_NAME		AS 'Table 2'
	, c2.COLUMN_NAME	AS 'Column 2'
FROM INFORMATION_SCHEMA.COLUMNS AS c1
JOIN INFORMATION_SCHEMA.COLUMNS AS c2
ON c2.TABLE_CATALOG = c1.TABLE_CATALOG
WHERE c1.COLUMN_NAME LIKE '%s'
AND   c2.COLUMN_NAME = SUBSTRING(c1.COLUMN_NAME, 1, LEN(c1.COLUMN_NAME) - 1);

