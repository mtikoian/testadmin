/*

	Author: Andre' DuBois 
	E: MtnDBA@gmail.com  
	T: @MtnDBA
	B: MtnDBA.wordpress.com

	Presented: SQL Saturday #191 Kansas City
	September 14, 2013

	Purpose: Are we using any data types that don't produce best result
	This is for a single database; select the database to browse

	Here we reveal any data types that are 
		* Approximate (float/real) Use only if the precision provided by decimal is insufficiewnt 
		* Money (money/smallmoney) be aware: decimal would be more accurate

	Please run in non-production environment until you know what this scipt does. 
	It could affect performance or other nasty things;
			
*/

SELECT  c.COLUMN_NAME
	, c.DATA_TYPE
	, c.ORDINAL_POSITION
	, c.COLUMN_DEFAULT
	, c.IS_NULLABLE
	, c.CHARACTER_MAXIMUM_LENGTH
	, c.NUMERIC_PRECISION
	, c.NUMERIC_PRECISION_RADIX
	, c.NUMERIC_SCALE
	, c.DATETIME_PRECISION
	, c.CHARACTER_SET_NAME 
FROM   INFORMATION_SCHEMA.COLUMNS c
WHERE c.DATA_TYPE IN ('float','real','money','smallmoney')
ORDER BY c.DATA_TYPE, c.COLUMN_NAME;

GO
