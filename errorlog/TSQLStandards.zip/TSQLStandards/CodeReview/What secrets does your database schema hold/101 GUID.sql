/*

	Author: Andre' DuBois 
	E: MtnDBA@gmail.com  
	T: @MtnDBA
	B: MtnDBA.wordpress.com

	Presented: SQL Saturday #191 Kansas City
	September 14, 2013

	Purpose: Find GUIDs in a database
	This is for a single database; select the database to browse

	Please run in non-production environment until you know what this scipt does. 
	It could affect performance or other nasty things;

	Note: You can find fields of any data type by changing uniqueidentifier to the data type of your choice.

*/
 
SELECT c.TABLE_CATALOG		as 'Database'
	, c.TABLE_SCHEMA	as 'Schema'
	, c.TABLE_NAME		as 'Table'
	, c.COLUMN_NAME		as 'Column'
	, c.DATA_TYPE		as 'Data Type'
	, c.COLUMN_DEFAULT	as 'Default'
	, c.ORDINAL_POSITION	as 'Position'
FROM INFORMATION_SCHEMA.COLUMNS as c
WHERE c.DATA_TYPE = 'uniqueidentifier' -- to find other data types, change the data type here
ORDER BY c.TABLE_SCHEMA, c.TABLE_NAME, c.COLUMN_NAME;