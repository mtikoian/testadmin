/*

	Author: Andre' DuBois 
	E: MtnDBA@gmail.com  
	T: @MtnDBA
	B: MtnDBA.wordpress.com

	Presented: SQL Saturday #191 Kansas City
	September 14, 2013

	Purpose: Is CHAR Field sized correctly correctly
	This is for a single database; select the database to browse

	Note: To run script as written, you must have the Adventure works database
	Note: If you look at a different field, you must unfortunately change the hardcoded values in this script

	Please run in non-production environment until you know what this scipt does. 
	It could affect performance or other nasty things;
	
*/

-- change to database you want to check (must change field name )
USE adventureworks2012;
GO

-- uncomment the next 2 lines to show the actual data we are working with 
-- SELECT name
-- from humanresources.department

SELECT 'HumanResources.Department.Name' as 'Column'
	, COUNT(*) as 'Number of Rows in Table' 
	, MIN(LEN(d.Name)) as 'Shortest Stored Value'
	, MAX(LEN(d.Name)) as 'Longest Stored Value'  
	, c.CHARACTER_MAXIMUM_LENGTH as 'Max Length Allowed'
	, (c.CHARACTER_MAXIMUM_LENGTH - MAX(LEN(d.Name))) as 'Diff to Max'
FROM HumanResources.Department d
LEFT JOIN INFORMATION_SCHEMA.COLUMNS c
	ON c.TABLE_CATALOG = 'AdventureWorks2012'	-- Database Name
	AND c.TABLE_SCHEMA = 'HumanResources'		-- Schema
	AND c.TABLE_NAME   = 'Department'		-- Table
	AND c.COLUMN_NAME  = 'Name'			-- Column
	GROUP BY c.CHARACTER_MAXIMUM_LENGTH;




