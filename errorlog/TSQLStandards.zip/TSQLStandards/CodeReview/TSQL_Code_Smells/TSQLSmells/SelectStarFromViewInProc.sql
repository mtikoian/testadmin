CREATE PROCEDURE dbo.SelectStarFromViewInProc
AS
SELECT * FROM dbo.SelectStarInAViewTest
go