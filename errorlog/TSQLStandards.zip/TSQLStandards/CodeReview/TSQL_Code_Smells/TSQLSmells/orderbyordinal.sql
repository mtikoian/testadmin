
SELECT *
 FROM sys.objects ORDER BY 1,2,3
