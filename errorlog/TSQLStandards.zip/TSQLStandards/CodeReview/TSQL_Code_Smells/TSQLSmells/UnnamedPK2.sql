Create table myTest22
(
	ID2 integer,
	constraint x unique (ID2,ID1)
	
    
)
go
Create table #myTest
(
	ID2 integer,
	unique (ID2,ID1)
    
)
go
Create table #myTest22
(
	ID2 integer,
	constraint x unique (ID2,ID1)
	
    
)
go
Create table myTest
(
	ID2 integer,
	unique (ID2,ID1)
    
)