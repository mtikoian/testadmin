/*ver2*/
CREATE PROCEDURE dbo.TestSelectStarBeginEndBlock
as
begin
	SELECT * FROM sys.objects
end