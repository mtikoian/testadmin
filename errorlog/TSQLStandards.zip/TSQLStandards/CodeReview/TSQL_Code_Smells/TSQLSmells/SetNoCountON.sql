Create Procedure dbo.TestSetNoCount 
as
SET NOCOUNT ON