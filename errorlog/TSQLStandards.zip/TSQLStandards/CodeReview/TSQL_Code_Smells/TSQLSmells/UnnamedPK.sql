/*
Create table #myTest
(
    ID integer PRIMARY KEY
)

Create table #myTest21
(
    ID integer constraint PKName1 PRIMARY KEY,
    [Status]                BIT              CONSTRAINT [Named] DEFAULT ((0)) NOT NULL,
    [DateEntered]           DATETIME         DEFAULT (getdate()) NOT NULL,
	[NonGPRefund]             BIT            CONSTRAINT [DF_PaymentLedger_NonGPRefund] DEFAULT (0) NOT NULL

)

Create table #myTest22
(
    ID integer constraint PKName1 PRIMARY KEY,
    ID2 integer REFERENCES SalesPerson(SalesPersonID)
	

)


Create table #myTest22
(
    ID integer check (ID>0)
    
)
*/


Create table #myTest22
(
    ID1 integer check (ID1>0),
	ID2 integer,
	unique (ID2,ID1)
	
    
)
go
