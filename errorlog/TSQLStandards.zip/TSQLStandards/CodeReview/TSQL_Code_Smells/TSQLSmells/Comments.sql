-- Single Line Comment

SELECT 1

-- Second Line Comment