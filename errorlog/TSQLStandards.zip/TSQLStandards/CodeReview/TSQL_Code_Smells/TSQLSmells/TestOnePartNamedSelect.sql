
CREATE PROCEDURE dbo.TestOnePartNamedSelect
AS
	SELECT NAME FROM MyTable
