Create Table TestTable
(
ID integer
)