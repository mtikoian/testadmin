Create PRocedure dbo.SelectAs
as
Declare @X table
(
   Id integer
)

Select * from @x

