/*
This script will BCP out the tables that are stored in tbBcp_Tables

EXEC dbo.prc_BcpOut


IF OBJECT_ID('tbTman_Load_Log') IS NOT NULL
DROP TABLE    tbTman_Load_Log
GO
CREATE TABLE  tbTman_Load_Log 
	(
	 TableName      VARCHAR(100)
	,Rows           BIGINT
	,Records_Live   BIGINT
	,MaxID_MIS      BIGINT
	,MaxID_Live     BIGINT
	,Starttime		DATETIME
	,EndTime        DATETIME
	,Timetaken      VARCHAR(10)
	,RunDate        VARCHAR(10) DEFAULT REPLACE(CONVERT(VARCHAR(10),GETDATE(),120),'-','')
	)
IF OBJECT_ID('tbBcp_Tables') IS NOT NULL
DROP TABLE    tbBcp_Tables
GO
CREATE TABLE  tbBcp_Tables
	 (
	 Tablename varchar (200) NOT NULL 
	 ) 

INSERT tbBcp_Tables(Tablename) VALUES('ABMC'				)
INSERT tbBcp_Tables(Tablename) VALUES('DEBTCOUNSELLORS'		)
INSERT tbBcp_Tables(Tablename) VALUES('DEBTCOUNSELLING'		)
INSERT tbBcp_Tables(Tablename) VALUES('REPUDIATIONCODES'	)
INSERT tbBcp_Tables(Tablename) VALUES('ABCONTACT'			)
INSERT tbBcp_Tables(Tablename) VALUES('TEMPLATES'			)
INSERT tbBcp_Tables(Tablename) VALUES('ROUTES'				)
INSERT tbBcp_Tables(Tablename) VALUES('WORKLISTS'			)
INSERT tbBcp_Tables(Tablename) VALUES('USERS'				)
INSERT tbBcp_Tables(Tablename) VALUES('SHERIFF'				)
INSERT tbBcp_Tables(Tablename) VALUES('SEGMENTS'			)
INSERT tbBcp_Tables(Tablename) VALUES('ACTIVITIES'			)
INSERT tbBcp_Tables(Tablename) VALUES('THIRDPARTIES'		)
INSERT tbBcp_Tables(Tablename) VALUES('CREDITCARD'			)
INSERT tbBcp_Tables(Tablename) VALUES('PAYPOINTDETAILS'		)
INSERT tbBcp_Tables(Tablename) VALUES('PAYPOINT'			)
INSERT tbBcp_Tables(Tablename) VALUES('DIRECTLEGAL'			)
INSERT tbBcp_Tables(Tablename) VALUES('SMSREPLIES'			)
INSERT tbBcp_Tables(Tablename) VALUES('TMP_ACCOUNTACTIVITIES')
INSERT tbBcp_Tables(Tablename) VALUES('PRE_LEGAL'			)
INSERT tbBcp_Tables(Tablename) VALUES('ADMINORDER'			)
INSERT tbBcp_Tables(Tablename) VALUES('SMS'					)	
INSERT tbBcp_Tables(Tablename) VALUES('REASONCODEDATE'		)
INSERT tbBcp_Tables(Tablename) VALUES('INSURANCE'			)
INSERT tbBcp_Tables(Tablename) VALUES('THIRDPARTY'			)
INSERT tbBcp_Tables(Tablename) VALUES('BINARYRECENCY'		)
INSERT tbBcp_Tables(Tablename) VALUES('CUSTOMERDETAILS'		)
INSERT tbBcp_Tables(Tablename) VALUES('bankdetails'			)
INSERT tbBcp_Tables(Tablename) VALUES('ACCOUNTCLASSIFICATIONS')
INSERT tbBcp_Tables(Tablename) VALUES('ACCOUNTDETAILS'		)
INSERT tbBcp_Tables(Tablename) VALUES('ACCOUNTS'			)
INSERT tbBcp_Tables(Tablename) VALUES('USERPERFORMANCE'		)
INSERT tbBcp_Tables(Tablename) VALUES('INTERFACELOGBACKUP'	)
INSERT tbBcp_Tables(Tablename) VALUES('ACCOUNTACTIVITIES'	)
INSERT tbBcp_Tables(Tablename) VALUES('ACCOUNTCLASSIFICATIONRESULTS')
INSERT tbBcp_Tables(Tablename) VALUES('ACCOUNTDOCUMENTRESULTS')
INSERT tbBcp_Tables(Tablename) VALUES('ACCOUNTSEGMENTATIONRESULTS'	)
INSERT tbBcp_Tables(Tablename) VALUES('ACCOUNTTRANSACTIONSPLITS'	)
INSERT tbBcp_Tables(Tablename) VALUES('ACCOUNTUPDATES'		)
INSERT tbBcp_Tables(Tablename) VALUES('ACCOUNTVALUES'		)
INSERT tbBcp_Tables(Tablename) VALUES('EXTRACTSEQUENCENUMBERS')
INSERT tbBcp_Tables(Tablename) VALUES('CALL'				)
**/

IF OBJECT_ID('prc_BcpOut') IS NOT NULL
DROP PROC     prc_BcpOut
GO
CREATE PROCEDURE dbo.prc_BcpOut 
AS
SET NOCOUNT ON

SET QUOTED_IDENTIFIER OFF

DECLARE  @tblvar_tablename TABLE (srno INT identity , tablename VARCHAR(200))

DECLARE  @Totcnt		INT
		,@Cnt			INT
		,@Sqry			NVARCHAR(4000)
		,@tblname		VARCHAR(200)
		,@FileName		VARCHAR(50)
		,@Rows			INT
		,@Starttime		DATETIME
		,@Endtime		DATETIME

		,@Records_Live	INT
		,@MaxID_Mis     BIGINT
		,@MaxID_Live    BIGINT
		,@Currtable     VARCHAR(200) 
       

	INSERT INTO  @tblvar_tablename
	SELECT * FROM dbo.tbBcp_Tables 
    --WHERE tablename LIKE '%SMS%'

	SELECT @Totcnt     = COUNT(*) FROM @tblvar_tablename
    SET    @Cnt        = 0
	SELECT @Starttime  = GETDATE()

WHILE ( @Cnt < @Totcnt )
BEGIN
	SET @Cnt = @Cnt + 1
	
	SELECT @tblname = LTRIM(RTRIM(ISNULL(Tablename,''))), 
           @Sqry    = 'bcp "SELECT * FROM PhaseII..'+LTRIM(RTRIM(ISNULL(Tablename,'')))+'" queryout  "'
	FROM   @tblvar_tablename WHERE Srno = @Cnt


SET        @tblname = '\\MIS1\Tmandaily$\INFILES\' + @tblname+'.txt'
SELECT     @Sqry    = @Sqry + @tblname + ' "  -T -c -o -B10000 \\MIS1\Tmandaily$\INFILES\output.txt '

EXEC   master..xp_cmdshell @Sqry

SELECT @tblname = LTRIM(RTRIM(ISNULL(Tablename,'')))
SELECT @Endtime = GETDATE()

SELECT @Rows    =  COUNT(*) FROM @tblname

INSERT PhaseII..tbTman_Load_Log
		(
		 TableName
		,Rows
		,Records_Live
		,MaxID_MIS
		,MaxID_Live
		,Starttime
		,EndTime
		,TimeTaken
		,Rundate
		) 
SELECT 
		 @tblname
		,@Rows
		,0
		,0
		,0
        ,@Starttime
        ,@Endtime
		,@Starttime,@EndTime,CONVERT(VARCHAR, DATEADD(ss, DATEDIFF(ss, @Starttime, @Endtime), 0), 108)
        ,REPLACE(CONVERT(VARCHAR(10),GETDATE(),120),'-','')
END


