select 
	SUBSTRING(st.text, (er.statement_start_offset/2)+1, 
        ((CASE er.statement_end_offset
          WHEN -1 THEN DATALENGTH(st.text)
         ELSE er.statement_end_offset
         END - er.statement_start_offset)/2) + 1) AS statement_text
from sys.dm_exec_requests er cross apply sys.dm_exec_sql_text(er.sql_handle) st
where er.session_id = 54