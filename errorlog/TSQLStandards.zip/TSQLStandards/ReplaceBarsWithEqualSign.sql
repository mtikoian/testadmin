IF OBJECT_ID('dbo.ReplaceBarsWithEqualSign') IS NOT NULL DROP FUNCTION dbo.ReplaceBarsWithEqualSign
GO
CREATE FUNCTION dbo.ReplaceBarsWithEqualSign(
    @String varchar(8000)
)
RETURNS TABLE WITH SCHEMABINDING
AS
RETURN
SELECT  REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(@String COLLATE LATIN1_GENERAL_BIN,
      '|||||||||||||||||||||||||||||||||','|'),
      '|||||||||||||||||','|'),
      '|||||||||','|'),
      '|||||','|'),
      '|||','|'),
      '||','|'),
      '||','|'), '|', '=') AS CleanString

GO

SELECT  [a].[ORIGINAL_VALUE],
        [a].[EXPECTED_VALUE],
        r.CleanString
FROM    ( VALUES
        ( 'ServerCentral|||||forum|||||||||||||||is||||||the||best', 'ServerCentral=forum=is=the=best'),
        ( 'so||||||be|||||on||||||||||||||||||||||||||||||||||||||||||||it', 'so=be=on=it')) a (ORIGINAL_VALUE, EXPECTED_VALUE)
CROSS APPLY dbo.ReplaceBarsWithEqualSign(ORIGINAL_VALUE) r; 