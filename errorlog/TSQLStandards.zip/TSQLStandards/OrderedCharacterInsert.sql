 CREATE FUNCTION dbo.OrderedCharacterInsert
/**********************************************************************************************************************
 Purpose:
 This function accepts an existing order string and inserts a charcter in the proper order. 
 Note... spaces are not allowed in either string.

 Example and usage:
 SELECT dbo.OrderedCharacterInsert('1348','0') UNION ALL --Returns 01348
 SELECT dbo.OrderedCharacterInsert('1348','1') UNION ALL --Returns 1348 because the "1" already existed
 SELECT dbo.OrderedCharacterInsert('1348','7') UNION ALL --Returns 13478
 SELECT dbo.OrderedCharacterInsert('1348','9')           --Returns 13489

 Revision History:
 Rev 00 - 09 Jan 2009 - Jeff Moden - Initial creation and test
                        Written for: http://www.sqlservercentral.com/Forums/Topic633926-338-1.aspx?
**********************************************************************************************************************/
        (
        @ExistingString VARCHAR(256),
        @CharToInsert   CHAR(1)
        )
RETURNS VARCHAR(256)
     AS
  BEGIN
 RETURN (
         SELECT CASE -- If character isn't already present, then insert it
                   WHEN CHARINDEX(@CharToInsert,posit.ExistingString) = 0
                   THEN LTRIM(RTRIM(STUFF(posit.ExistingString,posit.InsertHere,0,@CharToInsert)))
                   ELSE @ExistingString
                END
           FROM (--==== Determines character to insert at and modified string to insert on.
                     -- The TOP 1 short circuits the "pseudo cursor" created by the
                     -- Tally table for extra speed.  The -t.N does it all backwards so
                     -- we don't have to ORDER BY DESC... again, for extra speed.
                 SELECT TOP 1 (LenExistingString -t.N +1) AS InsertHere,ExistingString
                   FROM dbo.Tally t,
                        (--==== Adds spaces to string to insert on and gets its new length.
                             -- Works like a CTE so we don't have to add the spaces elsewhere in code.
                         SELECT ' '+@ExistingString+' ' AS ExistingString,
                                LEN(@ExistingString)+2  AS LenExistingString
                        ) es
                  WHERE t.N <= LenExistingString
                    AND SUBSTRING(es.ExistingString,(LenExistingString -t.N),1) < @CharToInsert
                  ORDER BY t.N --Not actually used by execution plan, but makes nay sayers breath easier.
                               --And, yes, it still works in 2k5 ;-)
                ) posit
        ) --End of return
    END
    
    go
    
 --   DECLARE @SomeExistingString VARCHAR(100),
 --       @SomeStringToInsert VARCHAR(100)
 --SELECT @SomeExistingString = '1348',
 --       @SomeStringToInsert = '7'

 --SELECT STUFF(@SomeExistingString,4,0,@SomeStringToInsert)