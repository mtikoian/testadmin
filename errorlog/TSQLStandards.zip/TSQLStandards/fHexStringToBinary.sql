CREATE FUNCTION dbo.fHexStringToBinary
/****************************************************************************************
 Purpose:
 This function will take a string of characters that look like Hexadecimal or Varbinary
 (has the "0x" as a prefix) and convert it to an actual Varbinary value.  If the input
 consist of 8 bytes (2 hex characters each), the result will be suitable for comparison
 with TimeStamps.

 Notes: 
 1. Automatically removes all dashes and space including leading or trailing spaces.
 2. Returns NULL if odd number of characters is present.
 3. Returns NULL if input string contains other non-hex characters other than those 
    found in Note 1.
 4. Returns NULL if the stripped input string contains more than 32 hex characters

 Performance:
 Approximately 12k rows per second in lots of 12k rows on Pentium 4 1.8Ghz w/IDE
 Drives 2GB-RAM

 Dependencies:
 1. A "Tally" table must be present in the same database as this function.  The Tally
    table is used to replace a WHILE loop.
--===== Put the original hex string where we can get at it
DECLARE @D2 VARCHAR(100)
    SET @D2 = '0130323530333739343234310000ceae01420a5ab642b71562000000'

--===== Now, pick a couple of pieces of "8" apart and convert to whole numbers
 SELECT CAST(dbo.fHexStringToBinary(SUBSTRING(@D2,29,8)) AS BIGINT) AS F2
 SELECT CAST(dbo.fHexStringToBinary(SUBSTRING(@D2,37,8)) AS BIGINT) AS G2
 Written by Jeff Moden, 03 Jul 2006 
****************************************************************************************/
--=======================================================================================
--      Declare the I/O parameters
--=======================================================================================
    	(
		@pHexStr as VARCHAR(50)
		) 
RETURNS VARBINARY(16)
     AS 
  BEGIN

--=======================================================================================
--      Function body
--=======================================================================================

--===== Remove any dashes/spaces and the '0x' prefix if present 
    SET @pHexStr = UPPER(
                     REPLACE(
                       REPLACE(
                         REPLACE(
                           @pHexStr
                         ,'-','')
                       ,' ','')
                     ,'0x','')
                   )

--===== Declare local variables.
DECLARE @BinResult   VARBINARY(8) --Final result
DECLARE @CharCount   INT          --Number of characters left in @pHexStr

    SET @CharCount = LEN(@pHexStr)

--===== If any non-hex characters present or uneven number
     -- of characters or too big, early exit with NULL return
     IF @pHexStr     LIKE '%[^0-9A-F]%'
     OR @CharCount%2 > 0
     OR @CharCount   > 32
        RETURN NULL

--===== 
 SELECT @BinResult = ISNULL(@BinResult,0x) 
                   + CAST(
                          (CHARINDEX(SUBSTRING(@pHexStr,(N),1),'123456789ABCDEF'))*16
                          +
                          (CHARINDEX(SUBSTRING(@pHexStr,(N)+1,1),'123456789ABCDEF'))
                     AS BINARY(1))
   FROM dbo.Tally WITH (NOLOCK)
  WHERE N <= @CharCount
    AND N%2=1
  ORDER BY N ASC 

--=======================================================================================
--      Function end
--=======================================================================================
 RETURN @BinResult
    END 