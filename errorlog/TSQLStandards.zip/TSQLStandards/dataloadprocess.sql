--exec [dbo].[sp_Daily_Uploads] 'TEST1'

ALTER Procedure [dbo].[sp_Daily_Uploads] (@Server varchar(100))
AS
BEGIN

--============================================================================================================
-- Update CALL Static Table:
Declare Daily_Uploads_Static_CALL CURSOR 
FOR

SELECT 
	  Table_Name
FROM 
		Conman.INFORMATION_SCHEMA.TABLES a (NOLOCK)
Inner Join	
		MIIS.dbo.Table_Schema b
ON	a.TABLE_NAME = b.TableName
Where TABLE_NAME In(Select TABLE_NAME From Conman_Offline.INFORMATION_SCHEMA.TABLES (NOLOCK) )
AND	b.Type <> 'ID'
AND A.TABLE_NAME = 'CALL'

Declare 
	  @table_Static_CALL Varchar(255)
	, @SQL_Static_CALL Varchar(3000)

OPEN Daily_Uploads_Static_CALL

FETCH NEXT FROM Daily_Uploads_Static_CALL INTO @table_Static_CALL

WHILE (@@FETCH_STATUS <> -1) -- For as Long as The Cursor is Open Loop

BEGIN 
	
		Set @SQL_Static_CALL =
		'
		-- Carry Out the Static Table Restore
						
				Declare @Start Datetime, @End Datetime
				Set @Start = GetDate()


				Print ''Carry Out Static Table Restore On:		'' + ' + '''' + @table_Static_CALL + '''' + '

				Drop Table Conman.dbo.' + @table_Static_CALL + '

				Select * 
				Into Conman.dbo.' + @table_Static_CALL + '
				From ' + @Server + '.Conman.dbo.' + @table_Static_CALL + ' ' + '
				
				Set @End = GetDate()

				Insert Into MIIS.dbo.Nightly_Upload_Log
				([Date], UpdateDescription, TableName, Records_MIIS, Records_Live, StartTime, EndTime)
				
				Select 
				  Convert(Varchar(25), GetDate(), 112)
				, ''Static Table Restore''
				, ' + '''' + @table_Static_CALL + '''' + '
				, (Select Count(*) From Conman.dbo.' + @table_Static_CALL + '  )
				, (Select Count(*) From ' + @Server + '.Conman.dbo.' + @table_Static_CALL + ')
				, StartTime = @Start
				, EndTime = @End
				
				Print ''Start Time:		'' + Convert(varchar(25),@Start) + ' + '''		End Time: '' + Convert(varchar(25),@End)' + '

'

			execute  (@SQL_Static_CALL)

FETCH NEXT FROM Daily_Uploads_Static_CALL INTO @table_Static_CALL

END

CLOSE Daily_Uploads_Static_CALL
DEALLOCATE Daily_Uploads_Static_CALL




--============================================================================================================
-- Update All ID'd Tables:
Declare Daily_Uploads_ID CURSOR 
FOR

SELECT 
	  Table_Name, IDColumn = Case When IDColumn is null Then 'NoIDColumn' Else IDColumn END
FROM 
		Conman.INFORMATION_SCHEMA.TABLES a (NOLOCK)
Inner Join	
		MIIS.dbo.Table_Schema b
ON	a.TABLE_NAME = b.TableName
Where TABLE_NAME In(Select TABLE_NAME From Conman_Offline.INFORMATION_SCHEMA.TABLES (NOLOCK) )
AND	b.Type = 'ID'
AND b.IDColumn Like '%ID%'
AND A.TABLE_NAME NOT IN
(SELECT TABLE_NAME_NOT_TO_COPY FROM Conman.DBO.TABLES_NOT_TO_COPY (NOLOCK))
/*AND A.TABLE_NAME NOT IN (SELECT TABLENAME FROM MIIS.DBO.NIGHTLY_UPLOAD_LOG (NOLOCK) WHERE DATE = '20071005')*/
ORDER BY A.TABLE_NAME DESC

Declare 
	  @table_ID Varchar(255)
	, @IDColumn varchar(50)
	, @SQL_ID Varchar(3000)

OPEN Daily_Uploads_ID

FETCH NEXT FROM Daily_Uploads_ID INTO @table_ID, @IDColumn

WHILE (@@FETCH_STATUS <> -1) -- For as Long as The Cursor is Open Loop

BEGIN 


		Set @SQL_ID =
		'

				exec sp_MSforeachtable  ' + '''ALTER TABLE Conman.dbo.' + @table_ID + ' NOCHECK CONSTRAINT ALL''
				exec sp_MSforeachtable  ' + ''' ALTER TABLE Conman.dbo.' + @table_ID + ' DISABLE TRIGGER ALL ''

		-- Carry Out The ID Table Update
					
				Print ''Carry Out the ID Table Update On:		'' + ' + '''' + @table_ID + '''' + ' + ' +''' With ID: '''+ '+' + '''' + @IDColumn + '''' + '

				Declare @Start_ID Datetime, @End_ID Datetime
				Set @Start_ID = GetDate()

				Declare @MinID numeric, @MaxID numeric, @MaxID_live numeric 
				Set @MinID = (Select Max(' + @IDColumn + ') From Conman.dbo.' + @table_ID + ' ) + 1
				Set @MaxID_Live = (Select Max(' + @IDColumn + ') From ' + @Server + '.Conman.dbo.' + @table_ID + ')

				While @MinID < @MaxID_Live
				Begin

					Set @MaxID = @MinID + 80000

					Insert into Conman.dbo.' + @table_ID + '
					Select * From ' + @Server + '.Conman.dbo.' + @table_ID + '  
					Where ' + @IDColumn + ' between @MinID and @MaxID
					
					Set @MinID = @MaxID + 1

					WaitFor Delay ''00:00:01''

					IF @MinID >= @MaxID_live
						Break
					Else
						Continue

				End

				Set @End_ID = GetDate()

				Insert Into MIIS.dbo.Nightly_Upload_Log
				([Date], UpdateDescription, TableName, MaxID_MIIS, MaxID_Live, StartTime, EndTime)
				
				Select 
				  Convert(Varchar(25), GetDate(), 112)
				, ''ID Table Upload''
				, ' + '''' + @table_ID + '''' + '
				, (Select Convert(varchar(255),Max(' + @IDColumn + ')) From Conman.dbo.' + @table_ID + '  )
				, (Select Convert(varchar(255),Max(' + @IDColumn + ')) From ' + @Server + '.Conman.dbo.' + @table_ID + ')
				, StartTime = @Start_ID
				, EndTime = @End_ID


exec sp_MSforeachtable ' + '''ALTER TABLE Conman.dbo.' + @table_ID + ' CHECK CONSTRAINT ALL ''
exec sp_MSforeachtable '+ '''ALTER TABLE Conman.dbo.' + @table_ID + ' ENABLE TRIGGER ALL''

'


print @table_ID + 'Table completed'
			execute  (@SQL_ID)

FETCH NEXT FROM Daily_Uploads_ID INTO @table_ID, @IDColumn

END

CLOSE Daily_Uploads_ID
DEALLOCATE Daily_Uploads_ID
--============================================================================================================

--============================================================================================================
-- Update All Date ID'd Tables:
Declare Daily_Uploads_IDDate CURSOR 
FOR

SELECT 
	  Table_Name, IDColumn = Case When IDColumn is null Then 'NoIDColumn' Else IDColumn END
FROM 
		Conman.INFORMATION_SCHEMA.TABLES a (NOLOCK)
Inner Join	
		MIIS.dbo.Table_Schema b
ON	a.TABLE_NAME = b.TableName
Where TABLE_NAME In(Select TABLE_NAME From Conman_Offline.INFORMATION_SCHEMA.TABLES (NOLOCK) )
AND	b.Type = 'ID'
AND b.IDColumn Like '%Date%'
AND A.TABLE_NAME NOT IN
(SELECT TABLE_NAME_NOT_TO_COPY FROM Conman.DBO.TABLES_NOT_TO_COPY (NOLOCK))
/*AND A.TABLE_NAME NOT IN (SELECT TABLENAME FROM MIIS.DBO.NIGHTLY_UPLOAD_LOG (NOLOCK) WHERE DATE = '20071005')*/

Declare 
	  @table_IDD Varchar(255)
	, @IDColumn_D varchar(50)
	, @SQL_IDD Varchar(3000)

OPEN Daily_Uploads_IDDate

FETCH NEXT FROM Daily_Uploads_IDDate INTO @table_IDD, @IDColumn_D

WHILE (@@FETCH_STATUS <> -1) -- For as Long as The Cursor is Open Loop

BEGIN 
	
		Set @SQL_IDD =
		'
		-- Carry Out The ID Table Update
					
				Print ''Carry Out the ID Table Update On:		'' + ' + '''' + @table_IDD + '''' + ' + ' +''' With ID: '''+ '+' + '''' + @IDColumn_D + '''' + '

				Declare @Start_IDD Datetime, @End_IDD Datetime
				Set @Start_IDD = GetDate()

				Declare @MaxIDD datetime
				Set @MaxIDD = (Select Max([' + @IDColumn_D + ']) From Conman.dbo.' + @table_IDD + '  )
				
				Insert into Conman.dbo.' + @table_IDD + '
				Select * From ' + @Server + '.Conman.dbo.' + @table_IDD + '  Where [' + @IDColumn_D + '] > @MaxIDD

				Set @End_IDD = GetDate()

				Insert Into MIIS.dbo.Nightly_Upload_Log
				([Date], UpdateDescription, TableName, MaxID_MIIS, MaxID_Live, StartTime, EndTime)

				Select 
				  Convert(Varchar(25), GetDate(), 112)
				, ''ID Table Upload''
				, ' + '''' + @table_IDD + '''' + '
				, (Select Convert(varchar(255),Max(' + @IDColumn_D + ')) From Conman.dbo.' + @table_IDD + '  )
				, (Select Convert(varchar(255),Max(' + @IDColumn_D + ')) From ' + @Server + '.Conman.dbo.' + @table_IDD + ' )
				, StartTime = @Start_IDD
				, EndTime = @End_IDD

'

			execute  (@SQL_IDD)

FETCH NEXT FROM Daily_Uploads_IDDate INTO @table_IDD, @IDColumn_D

END

CLOSE Daily_Uploads_IDDate
DEALLOCATE Daily_Uploads_IDDate
--============================================================================================================


--============================================================================================================
-- Update All Static Tables:
Declare Daily_Uploads_Static CURSOR 
FOR

SELECT 
	  Table_Name
FROM 
		Conman.INFORMATION_SCHEMA.TABLES a (NOLOCK)
Inner Join	
		MIIS.dbo.Table_Schema b
ON	a.TABLE_NAME = b.TableName
Where TABLE_NAME In(Select TABLE_NAME From Conman_Offline.INFORMATION_SCHEMA.TABLES (NOLOCK) )
AND	b.Type <> 'ID'
AND A.TABLE_NAME NOT IN
(SELECT TABLE_NAME_NOT_TO_COPY FROM Conman.DBO.TABLES_NOT_TO_COPY (NOLOCK))
/*AND A.TABLE_NAME NOT IN (SELECT TABLENAME FROM MIIS.DBO.NIGHTLY_UPLOAD_LOG (NOLOCK) WHERE DATE = '20071005')*/
Order by b.NrOfAccounts Desc


Declare 
	  @table_Static Varchar(255)
	, @SQL_Static Varchar(3000)

OPEN Daily_Uploads_Static

FETCH NEXT FROM Daily_Uploads_Static INTO @table_Static

WHILE (@@FETCH_STATUS <> -1) -- For as Long as The Cursor is Open Loop

BEGIN 
	
		Set @SQL_Static =
		'
		-- Carry Out the Static Table Restore
						
				Declare @Start Datetime, @End Datetime
				Set @Start = GetDate()


				Print ''Carry Out Static Table Restore On:		'' + ' + '''' + @table_Static + '''' + '

				Drop Table Conman.dbo.' + @table_Static + '

				Select * 
				Into Conman.dbo.' + @table_Static + '
				From ' + @Server + '.Conman.dbo.' + @table_Static + ' ' + '
				
				Set @End = GetDate()

				Insert Into MIIS.dbo.Nightly_Upload_Log
				([Date], UpdateDescription, TableName, Records_MIIS, Records_Live, StartTime, EndTime)
				
				Select 
				  Convert(Varchar(25), GetDate(), 112)
				, ''Static Table Restore''
				, ' + '''' + @table_Static + '''' + '
				, (Select Count(*) From Conman.dbo.' + @table_Static + '  )
				, (Select Count(*) From ' + @Server + '.Conman.dbo.' + @table_Static + ')
				, StartTime = @Start
				, EndTime = @End
				
				Print ''Start Time:		'' + Convert(varchar(25),@Start) + ' + '''		End Time: '' + Convert(varchar(25),@End)' + '

'

			execute  (@SQL_Static)

FETCH NEXT FROM Daily_Uploads_Static INTO @table_Static

END

CLOSE Daily_Uploads_Static
DEALLOCATE Daily_Uploads_Static
--============================================================================================================

--============================================================================================================
-- Check for uploads that have already run for the current day (During the Week):	Step Added: 2006/10/27
--------------------------------------------------------------------------------------------------------------
IF DateName(dw, GetDate()) NOT IN('Saturday','Sunday') 
	AND EXISTS(Select Date From Log_Summary (NOLOCK) Where Date = Convert(varchar(8), GetDate(), 112))
	BEGIN
		Delete From dbo.Log_Summary
		Where Date = Convert(varchar(8), GetDate(), 112)
	END

IF (Select Max(Date) From MIIS.dbo.Log_Summary (NOLOCK) ) = Convert(varchar(8), GetDate(), 112)
	Begin 
		INSERT INTO MIIS.dbo.Log_Summary
		(Date, [Day], Records	, Starttime, EndTime, Processing_Sec, Processing_M, Tables_OOS)
		SELECT
			  Date					= Convert(varchar(8),GETDATE() + 1, 112)
			, [Day]					= DateName(dw, GetDate() + 1)
			, Records				= COUNT(*)
			, Starttime				= Min(Starttime)
			, EndTime				= Max(EndTime)
			, Processing_Sec	= DateDiff(ss, Min(starttime), Max(Endtime))
			, Processing_M		= DateDiff(n, Min(starttime), Max(Endtime))
			, Tables_OOS			=	Sum(Case WHEN Records_MIIS <> Records_Live OR MaxID_MIIS <> MaxID_Live Then 1 Else 0 End)
		From MIIS.dbo.Nightly_Upload_Log (NOLOCK)
		Where Date = Convert(varchar(8), GetDate(), 112)
		Group by Date
		Order by Date
	END 
Else
	Begin 
		INSERT INTO MIIS.dbo.Log_Summary
		(Date, [Day], Records	, Starttime, EndTime, Processing_Sec, Processing_M, Tables_OOS)
		SELECT
			  Date					= Convert(varchar(8),GETDATE(), 112)
			, [Day]					= DateName(dw, GetDate())
			, Records				= COUNT(*)
			, Starttime				= Min(Starttime)
			, EndTime				= Max(EndTime)
			, Processing_Sec	= DateDiff(ss, Min(starttime), Max(Endtime))
			, Processing_M		= DateDiff(n, Min(starttime), Max(Endtime))
			, Tables_OOS			=	Sum(Case WHEN Records_MIIS <> Records_Live OR MaxID_MIIS <> MaxID_Live Then 1 Else 0 End)
		From MIIS.dbo.Nightly_Upload_Log (NOLOCK)
		Where Date = Convert(varchar(8), GetDate(), 112)
		Group by Date
		Order by Date
	END 
--============================================================================================================


END
