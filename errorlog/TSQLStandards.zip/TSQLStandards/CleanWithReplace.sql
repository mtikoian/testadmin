CREATE FUNCTION dbo.CleanWithReplace
        (@SomeText VARCHAR(100))
RETURNS VARCHAR(100)
     AS
  BEGIN
        DECLARE @Characters TABLE(SomeChar CHAR(1) NOT NULL)
         INSERT  @Characters( SomeChar )
         SELECT  'A' UNION ALL
         SELECT  'E' UNION ALL
         SELECT  '-'

         SELECT @SomeText = REPLACE( @SomeText, SomeChar, '' )
           FROM @Characters

 RETURN @SomeText
    END;
GO
