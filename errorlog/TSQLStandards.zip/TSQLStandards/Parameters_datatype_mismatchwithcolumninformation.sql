;WITH userObject AS  
( SELECT 
  Name AS DataName,--the actual name of the parameter or column ('@' removed)
  --and the qualified object name of the routine
  OBJECT_SCHEMA_NAME(ObjectID) + '.' + OBJECT_NAME(ObjectID) AS ObjectName,
  --now the harder bit: the definition of the datatype.
  TypeName + ' ' 
    + CASE 
    --we may have to put in the length. e.g. CHAR (10)  
         WHEN TypeName IN ('char', 'varchar', 'nchar', 'nvarchar')
             THEN '(' 
              + CASE WHEN MaxLength = -1 THEN 'MAX'
                ELSE CONVERT(VARCHAR(4),
                    CASE WHEN TypeName IN ('nchar', 'nvarchar')
                      THEN MaxLength / 2 ELSE MaxLength
                    END)
                END + ')'
         WHEN TypeName IN ('decimal', 'numeric')--a BCD number!
             THEN '(' + CONVERT(VARCHAR(4), Precision) 
                  + ',' + CONVERT(VARCHAR(4), Scale) + ')'
         ELSE ''
      END  --we've done with putting in the length
      + CASE WHEN XML_collection_ID <> 0 --tush tush. XML
         THEN --deal with object schema names
             '(' + CASE WHEN is_XML_Document = 1
                    THEN 'DOCUMENT '
                    ELSE 'CONTENT '
                   END 
             + COALESCE(
               (SELECT TOP 1 QUOTENAME(ss.name) + '.' + QUOTENAME(sc.Name)
                FROM sys.xml_schema_collections sc
                INNER JOIN Sys.Schemas ss ON sc.schema_ID = ss.schema_ID
                WHERE sc.xml_collection_ID = XML_collection_ID),'NULL') + ')'
          ELSE ''
         END 
       AS [DataType],
       DataObjectType
  FROM 
  (Select t.name AS TypeName, REPLACE(c.name,'@','') AS Name,
          c.max_length AS MaxLength, c.precision AS [Precision], 
          c.scale AS [Scale], c.[Object_id] AS ObjectID, XML_collection_ID,
          is_XML_Document,'P' AS DataobjectType
  FROM sys.parameters c
  INNER JOIN sys.types t ON c.user_Type_ID = t.user_Type_ID
  AND parameter_id>0
  UNION all
  Select t.name AS TypeName, c.name AS Name, c.max_length AS MaxLength,
          c.precision AS [Precision], c.scale AS [Scale],
          c.[Object_id] AS ObjectID, XML_collection_ID,is_XML_Document,
          'C' AS DataobjectType
          
  FROM sys.columns c
  INNER JOIN sys.types t ON c.user_Type_ID = t.user_Type_ID 
  WHERE OBJECT_SCHEMA_NAME(c.object_ID) <> 'sys'
  )f)
SELECT CONVERT(CHAR(80),objectName+'.'
   + CASE WHEN DataobjectType ='P' THEN '@' ELSE '' END + DataName),DataType 
FROM UserObject
WHERE DataName IN 
  (SELECT DataName FROM UserObject
   GROUP BY DataName 
   HAVING MIN(Datatype)<>MAX(DataType))
ORDER BY DataName    