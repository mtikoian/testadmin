 CREATE FUNCTION dbo.RemoveGuidsAndDashes
        (@SomeString VARCHAR(MAX))
RETURNS VARCHAR(MAX) WITH SCHEMABINDING
     AS
  BEGIN
--===== Declare some obviously named variables
DECLARE @Pattern   VARCHAR(MAX),
        @NextPosit INT
;
--===== Create the GUID pattern, get rid of dashes surrounded by spaces,
     -- and find the position of the first GUID if it exists.
 SELECT @Pattern    = '%[0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f]-[0-9a-f][0-9a-f][0-9a-f][0-9a-f]-[0-9a-f][0-9a-f][0-9a-f][0-9a-f]-[0-9a-f][0-9a-f][0-9a-f][0-9a-f]-[0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f]%',
        @SomeString = REPLACE(@SomeString,' - ',''),
        @NextPosit  = PATINDEX(@Pattern,@SomeString)

--===== If the SELECT above found a GUID, STUFF each one out of existance.
     -- This will be skipped if no GUID was found.
  WHILE @NextPosit > 0
 SELECT @SomeString = STUFF(@SomeString,@NextPosit,36,''),
        @NextPosit  = PATINDEX(@Pattern,@SomeString)
;
 RETURN @SomeString
;
    END
;
