@ECHO OFF
CLS

rem Navigate to the folder
C:
CD C:\FileLocation\
MD C:\FileLocation\Output

rem Declare and set the dest file name
rem NOTE: No whitespace between variable name and value !!!!
SET dst=Output\Files.sql

rem Note the single ">" to create a new file
rem A double ">>" will append to an existing file
@ECHO. > %dst%

rem Loop through a csv list of files (in the current folder)
FOR %%f IN (*.sql) DO (

rem I like to put 2 blank lines followed by a header and separator before the contents of each file.
@ECHO. >> %dst%
@ECHO. >> %dst%
@ECHO -- Contents of file: %%f >> %dst%
@ECHO --======================================================================= >> %dst%

rem Pipe the contents of the current file into the destination file
TYPE %%f >> %dst%
)