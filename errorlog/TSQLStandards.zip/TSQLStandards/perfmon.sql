
--CREATE SCHEMA Tools AUTHORIZATION dbo
--GO
IF (OBJECT_ID('Tools.PerfMon') IS NULL)
   CREATE TABLE Tools.PerfMon
   (
      Id INT IDENTITY(1,1) NOT NULL,
      Description VARCHAR(100) NULL,
      CreationDate DATETIME NULL,
      ElapsedTime INT NULL,
      CpuTime INT NULL,
      PhysicalReads INT NULL,
      PhysicalWrites INT NULL,
      LogicalReads INT NULL,
      Sorting VARCHAR(100) NULL,
      IsInit bit NULL,
      SPID smallint NULL,
      
      CONSTRAINT PK_Tools_PerfMon 
         PRIMARY KEY CLUSTERED 
         (Id ASC)
   )
GO
/**********************************************************************************
Summary
=======
Procedure to write an initial entry into table Tools.PerfMon

Parameters
==========

   none

Remarks
=======
This module just writes an initial entry into performance counting table. After
the test statement you have to call Tools.usp_PerfMon_Write.

Version
=======
V01.00.00.00 (2009-03-10)
   Initial version
V01.00.01.00 (2009-04-15)
   Added SPID for multi threading tests
**********************************************************************************/
ALTER PROCEDURE Tools.usp_PerfMon_Init
AS
SET NOCOUNT ON

   INSERT INTO PerfMon (
            CreationDate, 
            ElapsedTime, 
            CpuTime, 
            PhysicalReads, 
            PhysicalWrites, 
            LogicalReads, 
            IsInit, 
            SPID
            )
      SELECT 
            GETDATE(), 
            r.total_elapsed_time, 
            r.cpu_time, 
            r.reads, 
            r.writes, 
            r.logical_reads, 
            1, 
            @@SPID
         FROM sys.dm_exec_requests r --sys.dm_exec_sessions r
         WHERE 
            r.session_id = @@SPID
GO
/**********************************************************************************
Summary
=======
Procedure to write a performance entry into table Tools.PerfMon

Parameters
==========

   @Description
         A description for the performance counting entry

   @Sorting
         Any optional information which can be used to sort results


Remarks
=======
To get real performance information the Tools.PerfMon needs a previous entry which
was written before the statement which has to be tested. This is usually done by
another procedure Tools.usp_PerfMon_Init

Version
=======
V01.00.00.00 (2009-03-10)
   Initial version
V01.00.01.00 (2009-04-15)
   Added SPID for multi threading tests
**********************************************************************************/
ALTER PROCEDURE Tools.usp_PerfMon_Write
   @Description   VARCHAR(100),
   @Sorting       VARCHAR(100)    = NULL
AS
SET NOCOUNT ON

   INSERT INTO PerfMon (
            Description, 
            CreationDate, 
            ElapsedTime, 
            CpuTime, 
            PhysicalReads, 
            PhysicalWrites, 
            LogicalReads, 
            Sorting, 
            IsInit, 
            SPID
            )
      SELECT 
            @Description, 
            GETDATE(), 
            r.total_elapsed_time, 
            r.cpu_time, 
            r.reads, 
            r.writes, 
            r.logical_reads, 
            ISNULL(@Sorting, 0), 
            0, 
            @@SPID
         FROM sys.dm_exec_requests r -- sys.dm_exec_sessions r
         WHERE 
            r.session_id = @@SPID
GO
/**********************************************************************************
Summary
=======
Procedure test the performance monitoring procedures Tools.usp_PerfMon_Init and
Tools.usp_PerfMon_Write.

Parameters
==========

   none

Remarks
=======
This procedure is a test gadget.

Version
=======
V01.00.01.00 (2009-04-15)
   Added SPID for multi threading tests
**********************************************************************************/
ALTER PROCEDURE Tools.usp_PerfMon_Test
AS

DECLARE @i INT
DECLARE @v VARCHAR(MAAX)
DECLARE @n NVARCHAR(MAX)

---===============================================
-- Initialize the test
DELETE FROM Tools.PerfMon

---===============================================
-- Test without sorting
EXECUTE Tools.usp_PerfMon_Init

SELECT @i = COUNT(*) FROM sys.all_columns

EXECUTE Tools.usp_PerfMon_Write 'Count of sys.all_columns'

---===============================================
-- Test with sorting
EXECUTE Tools.usp_PerfMon_Init

SELECT @v = ''
SELECT @v =  @v + name FROM MASTER.sys.all_objects
EXECUTE Tools.usp_PerfMon_Write 'VARCHAR', 'master.sys.all_objects'

SELECT @n = ''
SELECT @n = @n + name FROM MASTER.sys.all_objects
EXECUTE Tools.usp_PerfMon_Write 'NVARCHAR', 'master.sys.all_objects'

SELECT @v = ''
SELECT @v = @v + name FROM MASTER.sys.all_columns
EXECUTE Tools.usp_PerfMon_Write 'VARCHAR', 'master.sys.all_columns'

SELECT @n = ''
SELECT @n = @n + name FROM MASTER.sys.all_columns
EXECUTE Tools.usp_PerfMon_Write 'NVARCHAR', 'master.sys.all_columns'



---==========================================================
-- Results
SELECT 
      --SPID           = p1.SPID,
      Sorting        =  p1.Sorting, 
      Ranking        =  ROW_NUMBER() OVER (PARTITION BY p1.Sorting ORDER BY (DATEDIFF(MILLISECOND, p2.CreationDate, p1.CreationDate))),
      Module         =  p1.Description,
      Duration       =  RIGHT(
                           CONVERT(VARCHAR(30), 
                              DATEADD(
                                 MILLISECOND, 
                                 DATEDIFF(
                                    MILLISECOND, 
                                    p2.CreationDate, 
                                    p1.CreationDate
                                    ), 
                                 0),
                              126), 
                           12),
      CpuTime        = p1.CpuTime - p2.CpuTime,
      LogicalReads   = p1.LogicalReads - p2.LogicalReads,
      PhysicalReads  = p1.PhysicalReads - p2.PhysicalReads,
      PhysicalWrites = p1.PhysicalWrites - p2.PhysicalWrites
   FROM Tools.PerfMon p1
      CROSS APPLY (
         SELECT TOP(1)
               p3.*
            FROM Tools.PerfMon p3
            WHERE p3.Id < p1.Id AND p3.SPID = p1.SPID
            ORDER BY p3.Id DESC) p2
   WHERE p1.IsInit != 1
   ORDER BY 
      p1.Sorting, 
      Duration
GO


EXECUTE Tools.usp_PerfMon_Test