--Start of month last year
SELECT DATEADD(MONTH,DATEDIFF(MONTH,0,GETDATE()) - 12, 0), DATEADD(YEAR,-1,CAST(GETDATE() AS DATE))


--Next quarter start and end dates
SELECT DATEADD(QUARTER, DATEDIFF(QUARTER, 0, GETDATE()) +1, 0) AS QStart,
       DATEADD(DAY, -1, DATEADD(QUARTER, DATEDIFF(QUARTER, 0, GETDATE()) +2, 0)) AS QEnd;
       

--integer to date

DECLARE @DateAsInt INT = 20170625;

SELECT 
    DateAsDate = DATEFROMPARTS(SUBSTRING(dc.DateAsChar, 1, 4), SUBSTRING(dc.DateAsChar, 5, 2), SUBSTRING(dc.DateAsChar, 7, 2))
FROM
    ( VALUES (CAST(@DateAsInt AS CHAR(8))) ) dc (DateAsChar);

--float to date
SET NOCOUNT ON;

DECLARE @FDATE FLOAT  = CONVERT(FLOAT,GETDATE(),0);
DECLARE @TDATE DATE   = CONVERT(DATE,CONVERT(DATETIME,(FLOOR(@FDATE)),0),0);


SELECT @TDATE AS RESULT_DATE;


--last year
DECLARE @Year INT = 2017;
SELECT LastDayOfYear = DATEFROMPARTS(@Year, 12, 31);

--Uk format
DECLARE @StringDate CHAR(8) = '20170609';

SELECT 
    UK_Format = CONCAT(sv.DY, '/', sv.MO, '/', sv.YR)
FROM
    ( VALUES (
            SUBSTRING(@StringDate, 1, 4),
            SUBSTRING(@StringDate, 5, 2),
            SUBSTRING(@StringDate, 7, 2)
            ) ) sv (YR, MO, DY);

-- OR --

SELECT 
    UK_Format = CONCAT(SUBSTRING(@StringDate, 7, 2), '/', SUBSTRING(@StringDate, 5, 2), '/', SUBSTRING(@StringDate, 1, 4));

SELECT YEAR(GETDATE()) YEAR, 
   CAST(DATEADD(dd, -1, DATEADD(yy, DATEDIFF(yy, -1, GETDATE()), 0)) as date) LastDayofYear,
   CONVERT(date, DATENAME(YEAR,GETDATE())+'1231'),
   DATEADD(yyyy, DATEDIFF(yyyy, 0, GetDate())+1, -1)
   
   SELECT datepart(year, CAST(DATEADD(dd, -1, DATEADD(yy, DATEDIFF(yy, 0, GETDATE()), 0)) as date)) YEAR, CAST(DATEADD(dd, -1, DATEADD(yy, DATEDIFF(yy, 0, GETDATE()), 0)) as date) LastDayofYear

--Char to datetime
SELECT CONVERT(DATETIME,STUFF(STUFF(STUFF('20140626190825',9,0,' '),12,0,':'),15,0,':'),112) AS DTIME

--AM PM hours

SELECT start_time, end_time, DATEDIFF(MINUTE, start_time4, end_time4) AS minutes_diff
FROM (
  VALUES('11PM','7AM'),('2230','630AM'),('11PM','9'),('8','6')
) AS test_data(start_time, end_time)
CROSS APPLY (
  SELECT CASE WHEN start_time LIKE '%PM%' THEN 12 ELSE 0 END AS start_pm_flag,
    CASE WHEN end_time LIKE '%PM%' THEN 12 END AS end_pm_flag
) AS ca1
CROSS APPLY (
  SELECT CASE WHEN start_time LIKE '%[AP]M%' THEN STUFF(start_time, PATINDEX('%[AP]%', start_time), 2, '') 
      ELSE start_time END AS start_time2,
    CASE WHEN end_time LIKE '%[AP]M%' THEN STUFF(end_time, PATINDEX('%[AP]%', end_time), 2, '') 
     ELSE end_time END AS end_time2
) AS ca2
CROSS APPLY (
  SELECT RIGHT('000' + CASE WHEN start_time2 LIKE '%[^0-9]%' THEN '0'
    WHEN start_time2 < 24 THEN CAST(start_time2 + start_pm_flag AS varchar(2)) + '00' ELSE start_time2 END, 4)  AS start_time3,
    RIGHT('000' + CASE WHEN end_time2 LIKE '%[^0-9]%' THEN '0'
    WHEN end_time2 < 24 THEN end_time2 + '00' ELSE end_time2 END, 4) AS end_time3
) AS ca3
CROSS APPLY (
  SELECT CAST(STUFF(start_time3, 3, 0, ':') AS smalldatetime) AS start_time4,
    DATEADD(DAY, CASE WHEN start_time3 > end_time3 THEN 1 ELSE 0 END, CAST(STUFF(end_time3, 3, 0, ':') AS smalldatetime)) AS end_time4
) AS ca4


select  DateAdd(dd, -10, GetDate() )
--retrieve the date of the last Sunday of every month?

DECLARE @DateStart DATETIME,
        @DateEnd   DATETIME

 SELECT @DateStart = '20080131',
        @DateEnd   = '20101201'

 SELECT DATEADD(wk,DATEDIFF(wk,6,DATEADD(mm,DATEDIFF(mm,-1,DATEADD(mm,t.N-1,@DateStart)),-1)),6)
   FROM dbo.Tally t
  WHERE t.N <= DATEDIFF(mm,@DateStart,@DateEnd)+1


select convert(datetime, '1967-10-13T17:55:12', 126)
--This script finds the first of every month in the date range. Remove any columns from the outer SELECT that you don't need...


--=======================================================================================
--      Find first of every month between the start and end dates (inclusive)
--=======================================================================================
--===== Here are the two parameters you wanted
DECLARE @DateStart DATETIME
DECLARE @DateEnd   DATETIME
 SELECT @DateStart = '20070429',
        @DateEnd   = '20081201'

--===== Find the dates using a Tally table as a counter.
     -- The outer select formats it.  Once cached, it's incredibly fast.
;WITH
cteTally AS
(--==== Returns a value of 1 to the number of months in date range
 SELECT TOP (DATEDIFF(mm,
               DATEADD(mm,DATEDIFF(mm,0,@DateStart),0),  --First of start month
               DATEADD(mm,DATEDIFF(mm,0,@DateEnd)+1,0))) --First of month after end month
        N = ROW_NUMBER() OVER (ORDER BY t1.Object_ID)
   FROM Master.sys.All_Columns t1
  CROSS JOIN Master.sys.All_Columns t2
)
 SELECT N,
        DateStart = DATEADD(mm,DATEDIFF(mm,0,@DateStart)+t.N-1,0),
        NextStart = DATEADD(mm,DATEDIFF(mm,0,@DateStart)+t.N,0)
   FROM cteTally t
   
--This one finds all the dates of all months in the date range... again, remove any columns from the outer SELECT that you don't need.
--=======================================================================================
--      Find all dates for every month between the start and end dates (inclusive)
--=======================================================================================
--===== Here are the two parameters you wanted
DECLARE @DateStart DATETIME
DECLARE @DateEnd   DATETIME
 SELECT @DateStart = '20070429',
        @DateEnd   = '20081201'

--===== Find the dates using a Tally table as a counter.
     -- The outer select formats it.  Once cached, it's incredibly fast.
;WITH
cteTally AS
(--==== Returns a value of 1 to the number of days of all months in date range
 SELECT TOP (DATEDIFF(dd,
               DATEADD(mm,DATEDIFF(mm,0,@DateStart),0),  --First of start month
               DATEADD(mm,DATEDIFF(mm,0,@DateEnd)+1,0))) --First of month after end month
        N = ROW_NUMBER() OVER (ORDER BY t1.Object_ID)
   FROM Master.sys.All_Columns t1
  CROSS JOIN Master.sys.All_Columns t2
)
 SELECT N,
        DateStart = DATEADD(mm,DATEDIFF(mm,0,@DateStart),0)+t.N-1,
        NextStart = DATEADD(mm,DATEDIFF(mm,0,@DateStart),0)+t.N
   FROM cteTally t
   
--Last, but not least, this one just finds all dates in the date range without regard to whole months. Again, remove any columns in the outer SELECT that you don't need.
--=======================================================================================
--      Find all dates between the start and end dates (inclusive)
--=======================================================================================
--===== Here are the two parameters you wanted
DECLARE @DateStart DATETIME
DECLARE @DateEnd   DATETIME
 SELECT @DateStart = '20070429',
        @DateEnd   = '20081201'

--===== Find the dates using a Tally table as a counter.
     -- The outer select formats it.  Once cached, it's incredibly fast.
;WITH
cteTally AS
(--==== Returns a value of 1 to the number of days in date range
 SELECT TOP (DATEDIFF(dd,
               DATEADD(dd,DATEDIFF(dd,0,@DateStart),0),  --Whole day start of range
               DATEADD(dd,DATEDIFF(dd,0,@DateEnd)+1,0))) --Whole day end of range
        N = ROW_NUMBER() OVER (ORDER BY t1.Object_ID)
   FROM Master.sys.All_Columns t1
  CROSS JOIN Master.sys.All_Columns t2
)
 SELECT N,
        DateStart = DATEADD(dd,DATEDIFF(dd,0,@DateStart),0)+t.N-1,
        NextStart = DATEADD(dd,DATEDIFF(dd,0,@DateStart),0)+t.N
   FROM cteTally t
   
   
 --Day Range Caluculations
 
 DECLARE @StartDate DATETIME 
DECLARE @EndDate   DATETIME 
DECLARE @Days      INT
DECLARE @BinSize   INT
    SET @StartDate = '01/01/2006' 
    SET @EndDate   = '10/02/2007' 
    SET @Days      = DATEDIFF(dd, @StartDate, @EndDate) + 1
    SET @BinSize   = 90
 
  PRINT DATEDIFF(dd, @StartDate, @EndDate) + 1

--===== Returns what the original poster really wanted (0-90, 91-180, 181-270, etc)
 SELECT CASE WHEN fnt.N = 0 THEN 0 ELSE fnt.N + 1 END AS StartDay,
        CASE WHEN fnt.N + @BinSize < @Days THEN fnt.N + @BinSize ELSE @Days END AS EndDay
   FROM dbo.fnTally(0, @Days) fnt
  WHERE fnt.N % @BinSize = 0

--===== Return something a bit more conventional (0-89, 90-179, 180-269, etc)
 SELECT fnt.N AS StartDay, 
        fnt.N + @BinSize - 1 AS EndDay
   FROM dbo.fnTally(0, @Days) fnt
  WHERE fnt.N % @BinSize = 0

--===== Return something thats real easy for >= and < calcs and people are used to seeing
     -- (0-90, 90-180, 180-270, etc)
 SELECT fnt.N AS StartDay, 
        fnt.N + @BinSize AS EndDay
   FROM dbo.fnTally(0, @Days) fnt
  WHERE fnt.N % @BinSize = 0   
  
  
  
DECLARE @StartDate DATETIME 
DECLARE @EndDate   DATETIME 
DECLARE @Days      INT
DECLARE @BinSize   INT
    SET @StartDate = '01/01/2006' 
    SET @EndDate   = '10/02/2007' 
    SET @Days      = DATEDIFF(dd, @StartDate, @EndDate) + 1
    SET @BinSize   = 90
 
  PRINT DATEDIFF(dd, @StartDate, @EndDate) + 1

--===== Returns what the original poster really wanted (0-90, 91-180, 181-270, etc)
 SELECT CASE WHEN fnt.N = 0 THEN 0 ELSE fnt.N + 1 END AS StartDay,
        CASE WHEN fnt.N + @BinSize < @Days THEN fnt.N + @BinSize ELSE @Days END AS EndDay,
        DATEPART(qq,@StartDate+fnt.N) AS Qtr
   FROM dbo.fnTally(0, @Days) fnt
  WHERE fnt.N % @BinSize = 0
  

--Date difference

--===== Do this testing in a nice, safe place that everyone has
    USE tempdb
;
GO
--=======================================================================================
--      First things first.  We need to build a permanent Tally Table to replace some
--      WHILE loops and Recursive Counting CTE's to solve this problem.  DO NOTICE that
--      the Tally Table I'm using for this problem starts at zero.
--
--      Please see the following URL for why Recursive Counting CTE's should be avoided.
--      http://www.sqlservercentral.com/articles/T-SQL/74118/
--
--      Please see the following URL for how a Tally Table works to replace certain kinds
--      of loops (like the ones we'd normally need to solve this problem)
--      http://www.sqlservercentral.com/articles/T-SQL/62867/
--      Jeff Moden
--=======================================================================================
--===== Create and populate the Tally table on-the-fly.
     -- Good for more than 30 years of dates.
 SELECT TOP 11001
        IDENTITY(INT,0,1) AS N
   INTO dbo.Tally
   FROM Master.sys.ALL_Columns ac1
  CROSS JOIN Master.sys.ALL_Columns ac2
;
--===== Add a CLUSTERED Primary Key to maximize performance
  ALTER TABLE dbo.Tally
    ADD CONSTRAINT PK_Tally_N 
        PRIMARY KEY CLUSTERED (N) WITH FILLFACTOR = 100
;
--===== Allow the general public to use it
  GRANT SELECT ON dbo.Tally TO PUBLIC
;
GO
--=======================================================================================
--      Create the test data.
--      Nothing in this section is a part of the solution.
--      We're just creating test data here to demonstrate the solution with.
--=======================================================================================
--===== Change the date format to accomodate the OP's country of origin.
    SET DATEFORMAT 'DMY'
;
--===== Conditionally drop the test table to make reruns in SSMS easier
     IF OBJECT_ID('tempdb..#OneFactTable','U') IS NOT NULL
        DROP TABLE #OneFactTable
;
GO
--===== Create and populate the test table on-the-fly.
 SELECT ID = d.Col1,
        AdmissionKey = CAST(d.Col2 AS DATETIME),
        DischargeKey = CAST(d.Col3 AS DATETIME)
   INTO #OneFactTable
   FROM ( --=== Original data from the post (mdy date format)
         SELECT 1,'12/2/2011','12/3/2011' UNION ALL
         SELECT 2,'15/5/2010','5/6/2010'  UNION ALL
         SELECT 3,'29/12/2010','3/1/2011' UNION ALL --I added this to span a year.
         SELECT 4,'12/2/2008','12/3/2008' UNION ALL --This spans a Leap Year February
         SELECT 4,'29/12/2008','3/1/2009'           --and a year.
        ) d (Col1, Col2, Col3)
;
GO
--=======================================================================================
--      Now, we'll create a stored procedure that accepts an ID and creates the 
--      drill down structure.  I don't know how to use Analysis Services to use the
--      data, but all the data and some "control" columns are available.
--=======================================================================================
 CREATE PROCEDURE dbo.DrillDownByID
--===== Declare a parameter for the ID we want to drill down on
        @pIdToDrill INT
     AS

--===== Supress the auto-display of rowcounts to prevent false error returns to the app.
    SET NOCOUNT ON
;
--===== Create the result set for an external program to process as a Drill Down menu.
     -- It includes a drill-down level column and a display order column.
WITH
cteGenDates AS
( --=== Create all the dates between the AdmissionKey and the DischargeKey
     -- for the given ID using the "Tally Table".
 SELECT TheDate  = DATEADD(dd,t.N,oft.AdmissionKey)
   FROM #OneFactTable oft
  CROSS JOIN dbo.Tally t
  WHERE t.N <= DATEDIFF(dd, oft.AdmissionKey, oft.DischargeKey)
    AND oft.ID = @pIdToDrill
    AND oft.AdmissionKey <= oft.DischargeKey
),
cteSplitdates AS
( --=== Split the dates into (ugh!) indivdual columns so we can ROLLUP each column
 SELECT Year  = YEAR(TheDate),
        Month = MONTH(TheDate),
        Day   = DAY(TheDate)
  FROM cteGenDates
),
cteTotals AS
( --=== Do the totals with a ROLLUP (subtotal) on each column break
 SELECT Year,
        Month,
        Day,
        TheCount = COUNT(*)
   FROM cteSplitDates 
  GROUP BY Year, Month, Day WITH ROLLUP
)
--===== Format the final output.
 SELECT TheDate = ISNULL(
                        + RIGHT(Year,4)
                        + ISNULL('-' + LEFT(DATENAME(mm,DATEADD(mm,Month-1,0)),3),'')
                        + ISNULL('-' + RIGHT('0'+DATENAME(dd,DATEADD(dd,Day  -1,0)),2),'')
                  ,'Total'),
        TheCount,
        DrillDownLevel = ISNULL(SIGN(Year),0)
                       + ISNULL(SIGN(Month),0)
                       + ISNULL(SIGN(Day),0),
        DisplayOrder   = ROW_NUMBER() OVER (ORDER BY Year, Month, Day)
   FROM cteTotals
;
GO
--===== Then, we can use the stored procedure to return a drill-down structure to the app,
     -- whatever it is.
   EXEC dbo.DrillDownByID 4 -- This number is an "ID" from the table.
;  

--nth WeekDayName of a month

DECLARE @targetMonth datetime
DECLARE @nthDay int
DECLARE @weekDay int

SELECT @targetMonth = GETDATE() /* specify any date in the target month here */
SELECT @nthDay = 4 /* 1st, 2nd, 3rd, 4th or 5th weekday of month */
SELECT @weekDay = 5 /* 1=Mon, 2=Tue, 3=Wed, 4=Thu, 5=Fri, 6=Sat, 7=Sun */

DECLARE @firstOfMonth datetime
DECLARE @firstOfNextMonth datetime
DECLARE @deltaDays int
DECLARE @dt datetime

SELECT 
	@firstOfMonth = DATEADD(month, DATEDIFF(month, 0, @targetMonth), 0),
	@firstofNextMonth = DATEADD(month, 1, @firstOfMonth),
	@deltaDays = (@weekDay - 1) - (DATEDIFF(day, 0, @firstOfMonth) % 7),
	@dt = DATEADD(day, @deltaDays + 7 * (@nthDay - (CASE WHEN (@deltaDays >= 0) THEN 1 ELSE 0 END)), @firstOfMonth)

SELECT 
	@nthDay AS [N],
	DATENAME(weekday, @dt) AS [Weekday],
	CASE WHEN (@dt >= @firstOfMonth AND @dt < @firstOfNextMonth) THEN @dt ELSE NULL END AS [Date]



--datetime
--current date
SELECT DATEADD(s,0,DATEADD(mm, DATEDIFF(m,0,getdate())-1,0))
--curent year

SELECT DATEPART(YEAR,DATEADD(s,0,DATEADD(mm, DATEDIFF(m,0,getdate())-1,0)))
--current month
SELECT DATEPART(MONTH,DATEADD(s,0,DATEADD(mm, DATEDIFF(m,0,getdate())-1,0)))	
	
	
	--Get particular day between two dates
	
	DECLARE @StartDate DATE = '20140801', 
        @EndDate DATE = '20140831',
        @DayNo TINYINT = 0;

/* this is a virtual numbers/tally table that is used to get all the days 
between the days.  If you already have a calendar table or a table that has
the dates you are querying this isn't necessary */
WITH    E1(N)
          AS (
              SELECT
                1
              UNION ALL
              SELECT
                1
              UNION ALL
              SELECT
                1
              UNION ALL
              SELECT
                1
              UNION ALL
              SELECT
                1
              UNION ALL
              SELECT
                1
              UNION ALL
              SELECT
                1
              UNION ALL
              SELECT
                1
              UNION ALL
              SELECT
                1
              UNION ALL
              SELECT
                1
             ),                          -- 1*10^1 or 10 rows
        E2(N)
          AS (
              SELECT
                1
              FROM
                E1 a,
                E1 b
             ), -- 1*10^2 or 100 rows
        E4(N)
          AS (
              SELECT
                1
              FROM
                E2 a,
                E2 b
             ), -- 1*10^4 or 10,000 rows
        E8(N)
          AS (
              SELECT
                1
              FROM
                E4 a,
                E4 b
             ),  -- 1*10^8 or 100,000,000 rows
        nums
          AS (
              SELECT TOP (4000)
                ROW_NUMBER() OVER (ORDER BY (
                                             SELECT
                                                NULL
                                            )) - 1 AS N
              FROM
                E8
             ),
        Calendar
          AS (
              SELECT
                CONVERT(DATE, DATEADD(DAY, n, @StartDate)) AS theDate
              FROM
                nums
             ),
        WeekDays
          AS (
              SELECT
                *,
		DATEDIFF(dd,-1,theDate)%7 AS DayNo,
                DATENAME(WEEKDAY, theDate) AS DayName
              FROM
                Calendar
             )
    SELECT
        *
    FROM
        WeekDays
    WHERE
        WeekDays.theDate BETWEEN @StartDate
                         AND     @EndDate AND
        WeekDays.DayNo = @DayNo;



WITH Dates AS (
   SELECT 
   CAST(CAST(CAST(GETDATE() AS INT) - (DATENAME(DAYOFYEAR, GETDATE() - 1)) AS DATETIME) AS DATE) AS CalendarDate
   UNION ALL
   SELECT 
   DATEADD(DAY , 1, CalendarDate)
   FROM Dates
   WHERE CalendarDate <= DATEADD(YY, 1, GETDATE())
)
SELECT  
	CalendarDate,
	CalendarYear = YEAR(CalendarDate),
	CalendarQuarter = DATENAME(quarter, CalendarDate),
	CalendarMonth = MONTH(CalendarDate),
	CalendarWeek = DATEPART(wk, CalendarDate),
	CalendarDay = DAY(CalendarDate),
	CalendarMonthName = DATENAME(MONTH, CalendarDate),
	CalendarDayOfYear = DATENAME(dayofyear, CalendarDate),
	Weekday = DATENAME(weekday, CalendarDate),
	DayOfWeek = DATEPART(weekday, CalendarDate),
	IsLeapYear = ISDATE(CAST(YEAR(CalendarDate)AS CHAR(4)) + '-02-29')
FROM Dates
OPTION (MAXRECURSION 731) --365 + 366 (it is possible that a leap year sneaks in)


--split data of month into weeks

-- declaring variables to hold required date range, these can be made to be input 
-- parameters of stored procedure if you wish to create one
DECLARE @start_date DATETIME, @end_date DATETIME

-- table variable is for convenience of re-runnable example. #-temp table would 
-- offer better performance. And, at the end, why not create permanent calendar-week table
-- which you can index as required and use this table in many other queries  
DECLARE @Table table(StartDate datetime,Enddate datetime,WeekNo int)

-- let say that is 10 year range to populate
SET @start_date = '1 Jan 2011'
SET @end_date =   '31 Dec 2021'

-- populate our "calendar-week" table variable
INSERT @Table 
SELECT  MIN(dt)    -- start date of the week as minimum of the date range within the week  
          , MAX(dt)   -- end date of the week as maximum of the date range within the week  
          , w            -- week of the year
FROM
(
    SELECT  dt                                   -- date 
               ,year(dt)                  AS y   -- year of the date
               ,DATEPART(week,dt)  AS w   -- week of year 1 to 53 depending on SET DATEFIRST...
    FROM
    (
        SELECT @start_date + (ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) - 1) dt
        -- the above will increment @start_date by 1 as many times as many rows possibly to
        -- produce by the following: 
        FROM sys.columns s1 cross join sys.columns s2
        -- the above cross join creates a Cartesian product which results to 
        -- thousands of rows (count of records in sys.columns ^ 2)  
    ) q
    -- we limit number of rows to be in a requested date-range
    WHERE dt BETWEEN @start_date AND @end_date
) a
group by y, w -- we group result by year and week to get final ranges


--displaying results:
Select * from @Table order by startdate, weekno

--Every 3rd Friday of the Month

DECLARE @StartYear DATETIME,
        @EndYear   DATETIME
;
 SELECT @StartYear = '2000',
        @EndYear   = '2099'
;
WITH
cteBuildDates AS
( --=== This just builds a hundred years of test dates.  It is not a part of the solution
     -- unless the OP decides to use it to build a Calendar table for the problem.
 SELECT TOP (DATEDIFF(dd,@StartYear,DATEADD(yy,1,@EndYear)))
        CurrentDate = DATEADD(dd, ROW_NUMBER() OVER (ORDER BY (SELECT NULL))-1,@StartYear)
   FROM sys.All_Columns ac1
  CROSS JOIN sys.All_Columns ac2
) --=== Note that -2 is a Saturday.  The CASE statement solves the actual problem with no
     -- character based conversions, does not rely on @@DATEFIRST (dw parts of DATEPART),
     -- and requires no lookup table with additional logic to find the NEXT 3rd Friday.
     -- Hat's off to Chris for the hint about the "offset" for the first of the month.
 SELECT CurrentDate,
        DATENAME(dw,CurrentDate) AS Dow,
        CASE
            WHEN CurrentDate <= DATEADD(mm,DATEDIFF(mm,0,CurrentDate),0) --First of CurrentMonth
                              + (20-(DATEDIFF(dd,-2,DATEADD(mm,DATEDIFF(mm,0,CurrentDate),0))%7)) --Offset
            THEN DATEADD(mm,DATEDIFF(mm,0,CurrentDate),0) --First of Current Month
               + (20-(DATEDIFF(dd,-2,DATEADD(mm,DATEDIFF(mm,0,CurrentDate),0))%7)) --Offset
            ELSE DATEADD(mm,DATEDIFF(mm,0,CurrentDate)+1,0) --First of Next Month
               + (20-(DATEDIFF(dd,-2,DATEADD(mm,DATEDIFF(mm,0,CurrentDate)+1,0))%7)) --Offset
        END AS Next3rdFriday
   FROM cteBuildDates
;
-- week part

SELECT Item,
        EndOfWeekDate = d.EoW,
        Price = SUM(Price),
        Quantity = COUNT(*)
   FROM dbo.Orders
  CROSS APPLY (SELECT EoW = DATEADD(dd,DATEDIFF(dd,-7,DateOfPurchase)/7*7,-1)) d
  GROUP BY Item, d.EoW
--All Monday date of each month.

DECLARE @PassedInDate DATETIME;
 SELECT @PassedInDate = '15 OCT 2014'
;
 SELECT Wk# = ROW_NUMBER() OVER (ORDER BY wk.MondayDate), wk.MondayDate
   FROM (SELECT DATEADD(dd,DATEDIFF(dd,days.Offset,DATEADD(mm,DATEDIFF(mm,0,@PassedInDate),0))/7*7,0)
           FROM (VALUES (-6),(-13),(-20),(-27),(-34))days(Offset)
        )wk(MondayDate)
  WHERE DATEDIFF(mm,0,wk.MondayDate) = DATEDIFF(mm,0,@PassedInDate)
;


--method 2
DECLARE @PassedInDate DATETIME;
 SELECT @PassedInDate = '15 OCT 2014'
;
 SELECT
     wk.Wk#
    ,wk.MondayDate
   FROM (
   SELECT DATEADD(dd,DATEDIFF(dd,days.Offset,DATEADD(mm,DATEDIFF(mm,0,@PassedInDate),0))/7*7,0) 
          ,Wk#
           FROM (VALUES (-6,1),(-13,2),(-20,3),(-27,4),(-34,5))days(Offset,Wk#)
        )wk(MondayDate,Wk#)
  WHERE DATEDIFF(mm,0,wk.MondayDate) = DATEDIFF(mm,0,@PassedInDate)
;

-- integer to time
DECLARE @MaxRowDateTime DATETIME;
 SELECT @MaxRowDateTime = MAX(DATEADD(hh,starttime/100,DATEADD(mi,starttime%100,DATEDIFF(dd,0,row_date))))
   FROM avaya.dbo.hSplit
;
WITH
cteConvert AS
(
  SELECT StgDT = DATEADD(hh,starttime/100,DATEADD(mi,starttime%100,DATEDIFF(dd,0,row_date)))
    FROM stg.avaya_hSplit
)
 SELECT StgDT
        ,hsplitMaxrowdatetime = @MaxRowdateTime
   FROM cteConvert
  WHERE StgDT > @MaxRowdateTime
;

--Find last working day based on given start date and number of working days
--===== These would be the parameters of an ITVF
DECLARE  @pDate         DATETIME
        ,@pWorkingDays  INT
;
 SELECT  @pDate = '11/7/2015' --Your date from your code, assuming it's MM/DD/YYYY
        ,@pWorkingDays = 11
;
--===== Find the last working day according to @pworkingDays skipping weekends and holidays.
 SELECT DT = MAX(DT)
   FROM dbo.Calendar
  CROSS APPLY (SELECT WD#Next FROM dbo.Calendar WHERE DT = @pDate) ca (WDNext)
  WHERE WD#Next = ca.WDNext + @pWorkingDays - 1
;



SELECT SUBSTRING('200702071630+1100', 1, 8)


SELECT CONVERT(char(8), '200702071630+1100')

SELECT CONVERT(datetime, SUBSTRING('200702071630+1100', 1, 8))

SELECT CONVERT(datetime, CONVERT(char(8), '200702071630+1100'))

DECLARE @sdt varchar(30)
SELECT @sdt = '200702071630+1100'
--UTC
SELECT DATEADD(minute, 
	(CASE SUBSTRING(@sdt, 13, 1) WHEN '-' THEN 1 ELSE -1 END) 
		* (60 * CONVERT(int, SUBSTRING(@sdt, 14, 2)) + CONVERT(int, SUBSTRING(@sdt, 16, 2)))
	+ (60 * CONVERT(int, SUBSTRING(@sdt, 9, 2)) + CONVERT(int, SUBSTRING(@sdt, 11, 2))),
	CONVERT(datetime, SUBSTRING(@sdt, 1, 8)))
--ISO	
DECLARE @dt datetime
SELECT @dt = '2007-02-07 16:30:00'
SELECT CONVERT(char(8), @dt, 112)



 DECLARE @Date AS DateTime
SET @Date = GETDATE()

SELECT 
   DateAdd(day, DateDiff(day, 0, @Date), 0) AS DayStart, 
   DateAdd(second, -1, DateAdd(day, DateDiff(day, 0, @Date)+1, 0) ) AS DayEnd,
   DateAdd(week, DateDiff(week, 0, @Date), 0) AS WeekStart, 
   DateAdd(second, -1, DateAdd(week, DateDiff(week, 0, @Date)+1, 0) ) AS WeedEnd,
   DateAdd(month, DateDiff(month, 0, @Date), 0) AS MonthStart, 
   DateAdd(second, -1, DateAdd(month, DateDiff(month, 0, @Date)+1, 0) ) AS MonthEnd,
   DateAdd(year, DateDiff(year, 0, @Date), 0)  AS YearStart,
   DateAdd(second, -1, DateAdd(year, DateDiff(year, 0, @Date)+1, 0) ) AS YearEnd    


select
	a.CurrentDatetime,
	a.CurrentTimeOfDay,
	HourOfDay	=
	convert(numeric(18,4),round(datediff(ms,0,a.TimeOfDay)/3600000.000000,4)),
	MinuteOfDay	=
	convert(numeric(18,4),round(datediff(ms,0,a.TimeOfDay)/60000.000000,4)),
	SecondOfDay	=
	convert(numeric(18,4),round(datediff(ms,0,a.TimeOfDay)/1000.000000,4)),
	MillisecondOfDay	=
	datediff(ms,0,a.TimeOfDay)
from
	(
	select	CurrentDatetime		= getdate(),
		CurrentTimeOfDay	= convert(time(3),getdate()),
		TimeOfDay		= convert(datetime,convert(time,getdate()))
	) a
	
declare @UPH datetime = '2014-07-29 08:16:31.000'

select cast(DATEPART(hour, @UPH) as varchar(2)) + '.' + stuff(cast(DATEPART(minute, @UPH) / 60.0 as varchar(10)), 1, 2, '')  
  
DECLARE @UPH datetime = '2014-07-29 08:16:31.000';
 SELECT CAST(@UPH AS DECIMAL(17,12))%1*24;
  
   
-- Simple query for the Months of a year  
   declare @StartDate datetime
-- get the 12/1 date for the previous year
set @StartDate = DateAdd(month, -1, DateAdd(year, DATEDIFF(year, 0, GetDate()), 0))

-- See Jeff Moden's article 
-- The "Numbers" or "Tally" Table: What it is and how it replaces a loop.
-- at http://www.sqlservercentral.com/articles/T-SQL/62867/.
-- NOTE! A permanent tally table will always be MUCH faster 
-- than this inline one. See the above article to create your own!
;WITH 
Tens     (N) AS (SELECT 0 UNION ALL SELECT 0 UNION ALL SELECT 0 UNION ALL 
                 SELECT 0 UNION ALL SELECT 0 UNION ALL SELECT 0 UNION ALL 
                 SELECT 0 UNION ALL SELECT 0 UNION ALL SELECT 0 UNION ALL SELECT 0), 
Tally    (N) AS (SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 0)) FROM Tens t1 CROSS JOIN Tens t2)
SELECT MonthNbr = N,
       MonthName = DATENAME(month, DateAdd(month, N, @StartDate))
  FROM Tally 
 WHERE N between 1 and 12 
 ORDER BY N
 --Returning a date column to Bigint after an update
 
 SELECT DATEDIFF(dd,
            DATEADD(yy,0,CONVERT(DATETIME,'19700101') + 1276548319093/86400000),
            DATEADD(yy,1,CONVERT(DATETIME,'19700101') + 1276548319093/86400000)
        )
      * CONVERT(BIGINT,86400000) + 1276548319093
-- Convert time in milliseconds since 1970-01-01 to datetime
declare @MSTime bigint
set @MSTime = 1276548319095
select DT = dateadd(ms,@MSTime%86400000,
	convert(datetime2,convert(datetime,(@MSTime/86400000)+25567)))

-- Convert datetime to time in milliseconds since 1970-01-01
declare @datetime datetime2
set @datetime = '2010-06-14 20:45:19.095'
select @datetime
select	MSTime =
	(datediff(dd,25567,@DateTime)*00000086400000)+
	datediff(ms,dateadd(dd,datediff(dd,0,@DateTime),0),@DateTime)
	
	
	select DATEADD(DAY, DATEDIFF(DAY, 0, SomeDate), 0)
	
	
	DECLARE @dt DATETIME;
SET     @dt = '2010-07-19';

SELECT  DATEPART(WEEK, DAY(@dt));   -- 3
SELECT  DATEPART(WEEK, @dt);        -- 30


select dateadd(yy, datediff(yy, 0, GETDATE()), 0)     -- Beginning of this year
select dateadd(yy, datediff(yy, 0, GETDATE()) + 1, 0) -- Beginning of next year

select
	MonthDaySeven,
	FirstSun = dateadd(dd,(datediff(dd,-53684,a.MonthDaySeven)/7)*7,-53684),
	FirstMon = dateadd(dd,(datediff(dd,-53690,a.MonthDaySeven)/7)*7,-53690),
	FirstTue = dateadd(dd,(datediff(dd,-53689,a.MonthDaySeven)/7)*7,-53689),
	FirstWed = dateadd(dd,(datediff(dd,-53688,a.MonthDaySeven)/7)*7,-53688),
	FirstThu = dateadd(dd,(datediff(dd,-53687,a.MonthDaySeven)/7)*7,-53687),
	FirstFri = dateadd(dd,(datediff(dd,-53686,a.MonthDaySeven)/7)*7,-53686),
	FirstSat = dateadd(dd,(datediff(dd,-53685,a.MonthDaySeven)/7)*7,-53685)
from
	(select MonthDaySeven=dateadd(dd,6,dateadd(mm,datediff(mm,0,getdate()),0))) a

select
	MonthLastDay,
	LastSun = dateadd(dd,(datediff(dd,-53684,a.MonthLastDay)/7)*7,-53684),
	LastMon = dateadd(dd,(datediff(dd,-53690,a.MonthLastDay)/7)*7,-53690),
	LastTue = dateadd(dd,(datediff(dd,-53689,a.MonthLastDay)/7)*7,-53689),
	LastWed = dateadd(dd,(datediff(dd,-53688,a.MonthLastDay)/7)*7,-53688),
	LastThu = dateadd(dd,(datediff(dd,-53687,a.MonthLastDay)/7)*7,-53687),
	LastFri = dateadd(dd,(datediff(dd,-53686,a.MonthLastDay)/7)*7,-53686),
	LastSat = dateadd(dd,(datediff(dd,-53685,a.MonthLastDay)/7)*7,-53685)
from
	( select MonthLastDay = dateadd(mm,datediff(mm,-1,getdate()),-1) ) a
	
declare @ThisDate datetime;
set @ThisDate = getdate();
select dateadd(dd, datediff(dd, 0, @ThisDate), 0)     -- Beginning of this day
select dateadd(dd, datediff(dd, 0, @ThisDate) + 1, 0) -- Beginning of next day
select dateadd(dd, datediff(dd, 0, @ThisDate) - 1, 0) -- Beginning of previous day
select dateadd(wk, datediff(wk, 0, @ThisDate), 0)     -- Beginning of this week (Monday)
select dateadd(wk, datediff(wk, 0, @ThisDate) + 1, 0) -- Beginning of next week (Monday)
select dateadd(wk, datediff(wk, 0, @ThisDate) - 1, 0) -- Beginning of previous week (Monday)
select dateadd(mm, datediff(mm, 0, @ThisDate), 0)     -- Beginning of this month
select dateadd(mm, datediff(mm, 0, @ThisDate) + 1, 0) -- Beginning of next month
select dateadd(mm, datediff(mm, 0, @ThisDate) - 1, 0) -- Beginning of previous month
select dateadd(qq, datediff(qq, 0, @ThisDate), 0)     -- Beginning of this quarter (Calendar)
select dateadd(qq, datediff(qq, 0, @ThisDate) + 1, 0) -- Beginning of next quarter (Calendar)
select dateadd(qq, datediff(qq, 0, @ThisDate) - 1, 0) -- Beginning of previous quarter (Calendar)
select dateadd(yy, datediff(yy, 0, @ThisDate), 0)     -- Beginning of this year
select dateadd(yy, datediff(yy, 0, @ThisDate) + 1, 0) -- Beginning of next year
select dateadd(yy, datediff(yy, 0, @ThisDate) - 1, 0) -- Beginning of previous year

--get all dates between 2 dates 7 days apart

DECLARE @START_DATE DATE = CONVERT(DATE,'20100101',112);
DECLARE @END_DATE   DATE = CONVERT(DATE,'20100901',112);
DECLARE @INTERVAL   INT  = 14;

;WITH T(N) AS (SELECT N FROM (VALUES (0),(0),(0),(0),(0),(0),(0),(0),(0),(0)) AS X(N))
,  NUMS(N) AS (SELECT TOP((DATEDIFF(DAY,@START_DATE,@END_DATE) / @INTERVAL ) +1) ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) - 1 AS N
               FROM T T1,T T2,T T3,T T4)
SELECT
    NM.N
   ,DATEADD(DAY,(NM.N * @INTERVAL),@START_DATE) AS OUT_DATE
FROM NUMS   NM ;

declare @date date;
set @date = '2015-01-06';
select FORMAT(@date,'yyyy/M'); -- yields 2015/1
set @date = '2015-10-06';
select FORMAT(@date,'yyyy/M'); -- yields 2015/10

DECLARE @TDATE  DATE = '2016-01-15';
SELECT STUFF(CONVERT(nvarchar(6), @TDATE, 112),5,1 - MONTH(@TDATE) / 10,'/');
SELECT CONVERT(VARCHAR(4),YEAR(@TDATE),0) + CONVERT(VARCHAR(4),MONTH(@TDATE),0);
SET @TDATE = '2015-11-20';
SELECT STUFF(CONVERT(nvarchar(6), @TDATE, 112),5,1 - MONTH(@TDATE) / 10,'/');

SELECT CONVERT(VARCHAR(4),YEAR(@TDATE),0) + CHAR(47) + CONVERT(VARCHAR(4),MONTH(@TDATE),0);

DECLARE @Serial CHAR(12)
    SET @Serial = 'SER074400001'

SELECT DATEADD(wk,DATEDIFF(wk,0,DATEADD(yy,CAST(SUBSTRING(@Serial,4,2) AS INT),'2000'))+CAST(SUBSTRING(@Serial,6,2)AS INT),0)


SELECT CAST(DATEDIFF(dd,0,GETDATE()) AS DATETIME),
        DATEADD(dd,DATEDIFF(dd,0,GETDATE()),0)
        
        
        
--first Monday of the month 
SELECT DATEADD(day, DATEDIFF(day, '19000101', DATEADD(month, DATEDIFF(month, '19000101', GETDATE()), '19000101')-1) /7*7 + 7, '19000101');

--first Monday of the year 
SELECT DATEADD(day, DATEDIFF(day, '19000101', DATEADD(year, DATEDIFF(year, '19000101', GETDATE()), '19000101')-1) /7*7 + 7, '19000101');

--last Monday of the year 
SELECT DATEADD(day, DATEDIFF(day, '19000101',DATEADD(year, DATEDIFF(year, '18991231', GETDATE()), '18991231')) /7*7, '19000101');


DECLARE  @StartDate DATETIME
        ,@EndDate DATETIME
;
 SELECT  @StartDate = '31 Dec 2014 23:59:59.997'
        ,@EndDate = '01 Jan 2016 00:06:59.000'
;
--===== Subtraction method for display
 SELECT CONVERT(VARCHAR(10),DATEDIFF(hh,0,@EndDate-@StartDate))
      + RIGHT(CONVERT(CHAR(12),@EndDate-@StartDate,114),10)
;
--===== Subtraction method for decimal hours
 SELECT CONVERT(DECIMAL(11,1),(CONVERT(FLOAT,@EndDate-@StartDate)*24.0))
 
 DECLARE @SomeDateTime DATETIME;
SELECT @SomeDateTime = '1900-01-05 04:15:20';

 SELECT [HHHHH:MM:SS] = CONVERT(VARCHAR(10),DATEDIFF(hh,0,@SomeDateTime)) --Converts the hours
                      + RIGHT(CONVERT(CHAR(8),@SomeDateTime,108),6)       --Converts mins & secs
;
 SELECT  MonthStart     = DATEADD(mm,DATEDIFF(mm, 0,GETDATE())-t.N,0)
        ,NextMonthStart = DATEADD(mm,DATEDIFF(mm,-1,GETDATE())-t.N,0)
   FROM (VALUES(0),(1),(2))t(N)
;

DECLARE @StartDate DATETIME,
        @EndDate   DATETIME

 SELECT @StartDate = '01-12-2008',
        @EndDate   = DATEDIFF(dd,0,GETDATE())

;WITH 
L0   AS (SELECT 1 AS C UNION ALL SELECT 1),   --2 rows
L1   AS (SELECT 1 AS C FROM L0 AS A, L0 AS B),--4 rows
L2   AS (SELECT 1 AS C FROM L1 AS A, L1 AS B),--16 rows
L3   AS (SELECT 1 AS C FROM L2 AS A, L2 AS B),--256 rows
L4   AS (SELECT 1 AS C FROM L3 AS A, L3 AS B),--65536 rows
L5   AS (SELECT 1 AS C FROM L4 AS A, L4 AS B),--4294967296 rows
Nums AS (SELECT ROW_NUMBER() OVER (ORDER BY C) AS N FROM L5)
SELECT N-1+@StartDate FROM Nums WHERE N <= DATEDIFF(dd,@StartDate,@EndDate)+1 



DECLARE @pDateTime DATETIME; --This could be a parameter for a scalar or iTVF function.
 SELECT @pDateTime = '20120401';

WITH 
ctePrevMonthEnd AS
(SELECT PrevMonthEnd = DATEADD(dd,-1,DATEADD(mm,DATEDIFF(mm,0,@pDateTime),0)))
 SELECT DATEADD(dd,
                CASE DATEDIFF(dd,0,PrevMonthEnd)%7 
                WHEN 5 THEN 2
                WHEN 6 THEN 1
                ELSE 0
                END,
                PrevMonthEnd)
   FROM ctePrevMonthEnd
;


     IF OBJECT_ID('dbo.FirstWorkDayAfterPrevMonthCALC') IS NOT 
        NULL DROP FUNCTION dbo.FirstWorkDayAfterPrevMonthCALC;
     IF OBJECT_ID('dbo.FirstWorkDayAfterPrevMonthMIN') IS NOT 
        NULL DROP FUNCTION dbo.FirstWorkDayAfterPrevMonthMIN;
     IF OBJECT_ID('dbo.FirstWorkDayAfterPrevMonthTOP') IS NOT 
        NULL DROP FUNCTION dbo.FirstWorkDayAfterPrevMonthTOP;
     IF OBJECT_ID('dbo.FirstWorkDayAfterPrevMonthHYBRID') IS NOT 
        NULL DROP FUNCTION dbo.FirstWorkDayAfterPrevMonthHYBRID;
GO
--===== This function uses ONLY calculations.
     -- It does NOT refer to a calendar table.
     -- The problem with this function is that it is
     -- totally blind to holidays.
 CREATE FUNCTION dbo.FirstWorkDayAfterPrevMonthCALC
        (@pDateTime DATETIME)
RETURNS TABLE AS
 RETURN
WITH 
ctePrevMonthEnd AS
(SELECT PrevMonthEnd = DATEADD(dd,-1,DATEADD(mm,DATEDIFF(mm,0,@pDateTime),0)))
 SELECT FirstWorkDayAfterPrevMonth =
        DATEADD(dd,
                CASE DATEDIFF(dd,0,PrevMonthEnd)%7 
                WHEN 5 THEN 2
                WHEN 6 THEN 1
                ELSE 0
                END,
                PrevMonthEnd)
   FROM ctePrevMonthEnd
;
GO
--===== This function is similar to the one Graham made.
     -- The only functional modifications made were to make it 
     -- compatible with the Calendar Table created by
     -- the attached code.
 CREATE FUNCTION dbo.FirstWorkDayAfterPrevMonthMIN
        (@pDateTime DATETIME)
RETURNS TABLE AS
 RETURN
 SELECT FirstWorkDayAfterPrevMonth = MIN(DT)
   FROM  dbo.Calendar
  WHERE (IsWorkDay = 1)
    AND (DT >= (DATEADD(mm, DATEDIFF(mm, 0, @pDateTime), 0)) -1)  
  -- calendar date greater than or equal to last day of previous month
GO
--===== This function is nearly identical to Graham's code
     -- except it has been optimized by using TOP 
     -- instead of MIN which removes an aggregate from 
     -- the execution plan.
 CREATE FUNCTION dbo.FirstWorkDayAfterPrevMonthTOP
        (@pDateTime DATETIME)
RETURNS TABLE AS
 RETURN
 SELECT TOP 1 
        FirstWorkDayAfterPrevMonth = DT 
   FROM dbo.Calendar
  WHERE IsWorkDay = 1
    AND DT >= DATEADD(dd,-1,DATEADD(mm, DATEDIFF(mm, 0, @pDateTime), 0))
  ORDER BY DT  
  -- calendar date greater than or equal to last day of previous month
GO
--===== This function is a hybrid between the "calculation only"
     -- function and the lookup for a "MIN" first workday after
     -- the desired date except that it uses the lookup ONLY
     -- if the original date found was a non-workday.
     -- It also uses a special "WorkDayNum" column which is
     -- nothing more than a running count of workdays.
     -- Non-workdays will always have the same "WorkDayNum"
     -- as the last previous workday.  It makes for some 
     -- VERY fast lookups when workdays (business days) are
     -- part of the lookup.
 CREATE FUNCTION dbo.FirstWorkDayAfterPrevMonthHYBRID
        (@pDateTime DATETIME)
RETURNS TABLE AS
 RETURN
 SELECT FirstWorkDayAfterPrevMonth =
            CASE
            WHEN c1.IsWorkDay = 1
            THEN c1.DT
            ELSE (SELECT TOP 1 DT 
                    FROM dbo.Calendar c2 
                   WHERE c2.WorkDayNum = c1.WorkDayNum + 1 
                   ORDER BY c2.DT DESC)
            END
   FROM dbo.Calendar c1
  WHERE c1.DT = DATEADD(dd,-1,DATEADD(mm,DATEDIFF(mm,0,@pDateTime),0))
;
GO



DECLARE @DatePart VARCHAR(4), @DynamicSQL NVARCHAR(4000), @ReturnDate DATETIME
SET @DatePart = 'yyyy'
SET @DynamicSQL = 'SET @ReturnDate = DATEADD(' + @DatePart + ', 2, GETDATE())'
EXECUTE sp_executesql @DynamicSQL, N'@ReturnDate DATETIME OUTPUT', @ReturnDate OUTPUT
select @ReturnDate

--get minutes
declare @test datetime2 = '01/01/0001'
-- See Jeff Moden's article 
-- The "Numbers" or "Tally" Table: What it is and how it replaces a loop.
-- at http://www.sqlservercentral.com/articles/T-SQL/62867/.
-- NOTE! A permanent tally table will always be MUCH faster 
-- than this inline one. See the above article to create your own!
;WITH 
Tens     (N) AS (SELECT 0 UNION ALL SELECT 0 UNION ALL SELECT 0 UNION ALL 
                 SELECT 0 UNION ALL SELECT 0 UNION ALL SELECT 0 UNION ALL 
                 SELECT 0 UNION ALL SELECT 0 UNION ALL SELECT 0 UNION ALL SELECT 0), 
Thousands(N) AS (SELECT 1 FROM Tens t1 CROSS JOIN Tens t2 CROSS JOIN Tens t3), 
Millions (N) AS (SELECT 1 FROM Thousands t1 CROSS JOIN Thousands t2), 
Tally    (N) AS (SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 0)) FROM Millions),
Dates        AS (SELECT DateField = DATEADD(day, N-1, @test) FROM Tally WHERE N-1 = 1056915413/1440)
SELECT DATEADD(MINUTE, 1056915413 % 1440, DateField)
  FROM Dates
  
  
  ---
  create table #Table1 (ProjectID int, [Attribute Name] nvarchar(50), DateTimeValue datetime)
insert into #Table1
select 1,'Start Date','8/8/2008'
union all
select 1,'End Date','4/30/2011'
union all
select 2,'Start Date','10/1/2011'
union all
select 2,'End Date','9/30/2014';
  
  WITH
cteNormalizeData AS
(
 SELECT ProjectID,
        StartYear = MAX(CASE WHEN [Attribute Name] = 'Start Date' THEN DATEPART(yy,DateTimeValue) ELSE 0 END),
        EndYear   = MAX(CASE WHEN [Attribute Name] = 'End Date'   THEN DATEPART(yy,DateTimeValue) ELSE 0 END)
   FROM #Table1
  GROUP BY ProjectID
)
 SELECT ProjectID,
        FiscalYear = StartYear+t.N
   FROM dbo.Tally t,
        cteNormalizeData
  WHERE t.N >=0 AND t.N <= EndYear-StartYear
;


declare @IntDate bigint,
        @CharDate varchar(32);
set @IntDate = 20100224184500;--20100224184500 --> 02/24/2010 18:45:00.000

set @CharDate = CAST(@IntDate as varchar(32));
select @IntDate, @CharDate, cast(stuff(stuff(stuff(@CharDate,13,0,':'),11,0,':'),9,0,' ') as datetime);

DECLARE @weekday int
SELECT @weekday = 7  /* Monday = 1, Tuesday = 2, ..., Sunday = 7 */

SELECT DATEADD(day, (@weekday - DATEPART(dw, GETDATE()) - @@DATEFIRST + 15) % 7, GETDATE())

SELECT DATEADD(day, (@weekday - DATEDIFF(day, 0, GETDATE()) % 7 + 6) % 7, GETDATE())

SELECT DATEADD(day, DATEDIFF(day, (@weekday - 1), GETDATE() - 1) / 7 * 7 + 7, (@weekday - 1))

SELECT DATEADD(wk,DATEDIFF(wk,0,somedatetimevalue+7),0)-1

SELECT DATEADD(ss,1271782698,'19700101')

select  [Years ]        = datediff(year,0,ET-ST),
        [Months]        = datepart(month,ET-ST) -1,
        [Days]          = datepart(day,ET-ST) -1,
        [Hours]         = datepart(Hour,ET-ST),
        [Minutes]       = datepart(Minute,ET-ST),
        [Seconds]       = datepart(Second,ET-ST),
        [Milliseconds]  = datepart(millisecond,ET-ST)
from
        (
        select  -- Test Data
                ST = convert(datetime,'2009/04/23 12:00:00:000'),
                ET = convert(datetime,'2010/05/25 13:01:01:003')
        ) a
        
        
        
--===== Display the last 13 months as MonYYYY
 SELECT RIGHT(CONVERT(CHAR(11),DATEADD(mm,DATEDIFF(mm,0,GETDATE())-Number,0),106),8) AS MonYYYY
   FROM Master.dbo.spt_Values
  WHERE Number BETWEEN 1 AND 13
    AND TYPE = 'P'

--===== Display the last 13 months as week date ranges
 SELECT CONVERT(CHAR(6),Week,106)+'-'+CONVERT(CHAR(6),Week+6,106)
   FROM (
         SELECT DATEADD(wk,DATEDIFF(wk,0,DATEADD(mm,DATEDIFF(mm,0,GETDATE()),0))-Number,0) AS Week
           FROM Master.dbo.spt_Values
          WHERE Number BETWEEN 1 AND 66
            AND TYPE = 'P'
        )d
  WHERE Week >= DATEADD(mm,DATEDIFF(mm,0,GETDATE())-13,0)
  
  
  --calculate work days
  DECLARE @StartDate DATETIME,
        @EndDate   DATETIME

 SELECT @StartDate = '2010-04-19',
        @EndDate   = '2010-04-27'

SELECT
   (DATEDIFF(dd, @StartDate, @EndDate) - 1)
  -(DATEDIFF(wk, @StartDate, @EndDate) * 2)
  -(CASE WHEN DATENAME(dw, @StartDate) = 'Sunday' THEN 1 ELSE 0 END)
  -(CASE WHEN DATENAME(dw, @EndDate) = 'Saturday' THEN 1 ELSE 0 END)


DECLARE @StartDate DATETIME,
        @EndDate   DATETIME

 SELECT @StartDate = '2010-04-19',
        @EndDate   = '2010-04-27'

SELECT
   (DATEDIFF(dd, @StartDate, @EndDate) + 1)
  -(DATEDIFF(wk, @StartDate, @EndDate) * 2)
  -(CASE WHEN DATENAME(dw, @StartDate) = 'Sunday' THEN 1 ELSE 0 END)
  -(CASE WHEN DATENAME(dw, @EndDate) = 'Saturday' THEN 1 ELSE 0 END)


--No of days per month
SET DATEFORMAT DMY

DECLARE @StartDate   DATETIME,
        @EndDate     DATETIME
;
 SELECT @StartDate = '05/06/2011',
        @EndDate   = '31/08/2012'
;
WITH
cteMonthEnd AS
(
 SELECT t.N, 
        MonthEnd = DATEADD(mm,DATEDIFF(mm,0,@StartDate) + t.N, 0) - 1
   FROM dbo.Tally t
  WHERE t.N BETWEEN 1 AND DATEDIFF(mm,@StartDate,@EndDate) + 1
)
 SELECT MonthEnd,
        Days     = DATEPART(dd,MonthEnd) - CASE WHEN N > 1 THEN 0 ELSE DATEPART(dd,@StartDate) END
   FROM cteMonthEnd
;

--future dates 

DECLARE @dt DATETIME = '20131105'

SELECT 
    #months,
    future_date, 
    DATEADD(DAY, -DATEDIFF(DAY, curr_day_of_week, future_date) % 7, future_date) AS future_Tues_date
FROM (
    --check 3 different future dates: 6, 12 and 18 mths out
    SELECT 6 AS #months UNION ALL
    SELECT 12 AS #months UNION ALL
    SELECT 18 AS #months
) AS #months
CROSS APPLY (
    SELECT 
        DATEDIFF(DAY, 0, @dt) % 7 AS curr_day_of_week,
        DATEADD(DAY, 6, DATEADD(MONTH, #months, @dt)) AS future_date
) AS test_data


--Display all the Dates of a Week of the current date selected daysofaweek

DECLARE @SomeDate DATETIME;
 SELECT @SomeDate = '10 Sep 2014';

--===== This uses a "Goldilocks" (just the right size) Tally table to build
     -- a week's worth of dates for and date after 1899-12-31 except the last week
     -- of 9999 for almost all versions of SQL Server.
     -- This one returns dates for weeks that start on Sunday.
 SELECT DatesOfWeek = DATEADD(dd,DATEDIFF(dd,-1,@SomeDate)/7*7,-1) + t.N
   FROM (SELECT 0 UNION ALL SELECT 1 UNION ALL SELECT 2 UNION ALL 
         SELECT 3 UNION ALL SELECT 4 UNION ALL SELECT 5 UNION ALL SELECT 6)t(N)
;


-- yearweek

IF EXISTS (SELECT OBJECT_ID(N'dbo.yearweek'))
BEGIN
    DROP TABLE dbo.yearweek;
END

/*
   First suggestion, change the structure of the dbo.yearweek table, adding
   a clustered index, a computed column and finally an unique covering 
   index for the query.
*/
CREATE TABLE dbo.yearweek(
    yrwk    VARCHAR(6)  NOT NULL CONSTRAINT PK_DBO_YEARWEEK_YRWK PRIMARY KEY CLUSTERED
   ,yr      INT         NOT NULL
   ,wk      INT         NOT NULL
   ,rn      INT         NOT NULL
   ,weekx  AS (CONVERT( VARCHAR(9),((('W '+CONVERT([char](4),[yr]))+' ')
               +stuff('00',(3)-len(CONVERT([char](2),[wk]))
               ,len(CONVERT([char](2),[wk]))
               ,CONVERT([char](2),[wk]))),1)) PERSISTED
  
) ON [PRIMARY];
GO
/* Unique covering index  */
CREATE UNIQUE INDEX UNQIDX_DBO_YEARWEEK_WEEKX ON dbo.yearweek (weekx ASC)
INCLUDE (yr,wk,rn);
GO

/* Populate the table */
DECLARE @startyr as INT
DECLARE @no_yrs as INT

SET @startyr = 2010
SET @no_yrs = 20

;WITH T(N) AS (SELECT N FROM (VALUES (NULL),(NULL),(NULL),(NULL),(NULL),(NULL),(NULL),(NULL),(NULL),(NULL)) AS X(N))
,YEAR_NUMS(N) AS (SELECT TOP(@no_yrs) ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) -1  AS N FROM T T1,T T2, T T3 ,T T4, T T5, T T6, T T7)
,WEEK_NUMS(N) AS (SELECT TOP(52) ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) -1  AS N FROM T T1,T T2, T T3 ,T T4, T T5, T T6, T T7)

INSERT INTO dbo.yearweek (yrwk,yr,wk,rn)
SELECT 
	 CAST(a.yearno + b.dayno as VARCHAR(6)) AS yrwk
    ,CAST(a.yearno AS INT) AS yr
    ,CAST(b.dayno AS INT) AS wk
    ,CONVERT(INT,ROW_NUMBER() OVER (ORDER BY a.yearno, b.dayno),0) AS rn 
FROM 
	(SELECT CAST(@startyr + N AS VARCHAR) AS yearno FROM YEAR_NUMS)	AS a 
CROSS JOIN 
	(SELECT (CASE WHEN N < 10 THEN '0' + CAST(N AS VARCHAR) ELSE CAST(N AS VARCHAR) END ) AS dayno FROM WEEK_NUMS)	AS b


/* Check the content */

SELECT 
    *
FROM dbo.yearweek;


--calculate no of mondays for given dates
DECLARE @StartDate DATETIME
DECLARE @EndDate DATETIME
SET @StartDate = '02/01/2006'
SET @EndDate = '09/27/2006'

SELECT
DATEDIFF(wk,@StartDate,@EndDate)
-CASE WHEN DATENAME(dw,@EndDate)='Sunday' THEN 1 ELSE 0 END
+CASE WHEN DATENAME(dw,@StartDate)='Monday' THEN 1 ELSE 0 END

--DOB

select	a.DOB,
	b.CurrDate,
	BirthdayCurrentYear =
	dateadd(yy,datediff(yy,a.DOB,b.CurrDate),a.DOB),
	Age =
	datediff(yy,a.DOB,b.CurrDate) +
	-- Subtract 1 if current date before birthday in current year
	case when b.CurrDate < dateadd(yy,datediff(yy,a.DOB,b.CurrDate),a.DOB)
	then -1 else 0 end		
from
	( --Test Date of Birth
	select DOB = convert(date,'19600229')	union all
	select DOB = convert(date,'19521013')
	) a	join
	( -- Test Current Dates
	select CurrDate = convert(date,'20110227')	union all
	select CurrDate = convert(date,'20110228')	union all
	select CurrDate = convert(date,'20120228')	union all
	select CurrDate = convert(date,'20120229')	union all
	select CurrDate = convert(date,'20121012')	union all
	select CurrDate = convert(date,'20121013')
	) b	on month(a.DOB) = month(b.CurrDate)
order by
	a.DOB,
	b.CurrDate
	
	-- Monthend for a given range or month end for a given range
	
DECLARE	@dt1 DATETIME,
	@dt2 DATETIME

SELECT	@dt1 = '20080115',
	@dt2 = '20200308'

SELECT	DATEADD(MONTH, DATEDIFF(MONTH, '19000101', DATEADD(MONTH, Number, @dt1)), '19000131')
FROM	master..spt_values
WHERE	Type = 'P'
	AND Number <= DATEDIFF(MONTH, @dt1, @dt2)
	
	
	--hour date 
	
	select DATEADD(hh, DATEDIFF(hh,0,getdate()), 0) --2015-09-04 10:00:00.000
	
---	dates with a frequency 
	declare @StartDate date = '2015-01-01', @EndDate date = '2015-12-31';

WITH
	E1(N) AS (select 1 from (values (1),(1),(1),(1),(1),(1),(1),(1),(1),(1))dt(n)),
	E2(N) AS (SELECT 1 FROM E1 a, E1 b), --10E+2 or 100 rows
	E4(N) AS (SELECT 1 FROM E2 a, E2 b), --10E+4 or 10,000 rows max
	cteTally(N) AS 
	(
		SELECT  ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) FROM E4
	)

select DATEADD(DAY, N - 1, @StartDate)
from cteTally
where N <= DATEDIFF(DAY, @StartDate, @EndDate)
	AND (N - 1) % 7 = 0
	
	
	DECLARE @StartDate DATE 
DECLARE @EndDate DATE 
DECLARE @RotationDays INT

SET @StartDate = '01/01/2015'
SET @EndDate = '12/31/2015'
SET @RotationDays = 7

--===== Original method generates more than 2000 dates (and 33 reads) rather than just the 91 that are needed.
     -- Also has an extra ROW_NUMBER() calculation that's just not needed.
     -- In theory, could also run out of "rows" from sys.all_objects.
;WITH result AS
(
	SELECT DATEADD(DAY, (ROW_NUMBER() OVER (ORDER BY object_id) - 1) * @RotationDays, @StartDate) StartDate, 
	DATEADD(DAY, ((ROW_NUMBER() OVER (ORDER BY object_id) - 1) * @RotationDays) + @RotationDays - 1, @StartDate) EndDate
	FROM sys.all_objects
)
--INSERT INTO TABLE here, if you need to
SELECT StartDate, EndDate 
	FROM result
--LEFT OUTER JOIN table, if you need to join people here
WHERE EndDate <= @EndDate


--calculate years between dates
SELECT ABS(YEAR(DATEADD(dd,DATEDIFF(dd,@BirthDate,@ReferenceDate),0)-1)-1900)


-- add business days

DECLARE @SomeDate DATETIME,
        @BusinessDays INT
 SELECT @SomeDate = GETDATE(),
        @BusinessDays = 5

;WITH
cteAddBusinessDay AS
(
 SELECT t.N+@SomeDate AS SomeDate,
        ROW_NUMBER() OVER (ORDER BY t.N+@SomeDate) AS Businessday
   FROM dbo.Tally t
  WHERE t.N <= @BusinessDays + 7
    AND DATEDIFF(dd,0,t.N+@SomeDate)%7 NOT IN (5,6)
)
 SELECT SomeDate 
   FROM cteAddBusinessDay
  WHERE Businessday = @BusinessDays
  
 /*second friday*/
 -- Before
WITH	
cte1	AS (SELECT TOP 366 DATEADD(dd,(ROW_NUMBER() OVER (ORDER BY name) -1),CONVERT(DATE,CONVERT(CHAR(4),DATEPART(yyyy,GETDATE()))+'-01-01')) AS [Date] FROM sys.columns), 
cte2	AS (SELECT [Date],DATEPART(yy,[Date]) AS [Year],DATEPART(mm,[Date]) AS [Month],DATEPART(dw,[Date]) AS [DayOfWeek] FROM cte1),
cte3	AS (SELECT *,ROW_NUMBER() OVER (PARTITION BY [Year],[Month],[DayOfWeek] ORDER BY [Date]) AS [SequencedDayOfWeek] FROM cte2)		
SELECT * FROM cte3 
WHERE [DayOfWeek]=5 -- Friday
AND [SequencedDayOfWeek]=2 -- Second in the month
ORDER BY [Date];

-- After
WITH	
cte1	AS (SELECT TOP 366 DATEADD(dd,(ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) -1),CONVERT(DATE,CONVERT(CHAR(4),DATEPART(yyyy,GETDATE()))+'-01-01')) AS [Date] FROM sys.columns), 
cte2	AS (SELECT [Date],DATEPART(yy,[Date]) AS [Year],DATEPART(mm,[Date]) AS [Month],DATEPART(dw,[Date]) AS [DayOfWeek] FROM cte1),
cte3	AS (SELECT *,ROW_NUMBER() OVER (PARTITION BY [Year],[Month],[DayOfWeek] ORDER BY (SELECT NULL)) AS [SequencedDayOfWeek] FROM cte2)		
SELECT * FROM cte3 
WHERE [DayOfWeek]=5 -- Friday
AND [SequencedDayOfWeek]=2 -- Second in the month
ORDER BY [Date];


-- Before
WITH	
cte1	AS (SELECT TOP 366 DATEADD(dd,(ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) -1),CONVERT(DATE,CONVERT(CHAR(4),DATEPART(yyyy,GETDATE()))+'-01-01')) AS [Date] FROM sys.columns), 
cte2	AS (SELECT [Date],DATEPART(yy,[Date]) AS [Year],DATEPART(mm,[Date]) AS [Month],DATEPART(dw,[Date]) AS [DayOfWeek] FROM cte1),
cte3	AS (SELECT *,ROW_NUMBER() OVER (PARTITION BY [Year],[Month],[DayOfWeek] ORDER BY (SELECT NULL)) AS [SequencedDayOfWeek] FROM cte2)		
SELECT * FROM cte3 
WHERE [DayOfWeek]=5 -- Friday
AND [SequencedDayOfWeek]=2 -- Second in the month
ORDER BY [Date];

-- After
WITH	
cte1	AS (SELECT TOP 366 DATEADD(dd,(ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) -1),CONVERT(DATE,CONVERT(CHAR(4),DATEPART(yyyy,GETDATE()))+'-01-01')) AS [Date] FROM sys.columns), 
cte2	AS (SELECT [Date],DATEPART(yy,[Date]) AS [Year],DATEPART(mm,[Date]) AS [Month],DATEPART(dw,[Date]) AS [DayOfWeek] FROM cte1),
cte3	AS (SELECT *,ROW_NUMBER() OVER (PARTITION BY [Year],[Month],[DayOfWeek] ORDER BY (SELECT NULL)) AS [SequencedDayOfWeek] FROM cte2)		
SELECT * FROM cte3 
WHERE [DayOfWeek]=5 -- Friday
AND [SequencedDayOfWeek]=2 -- Second in the mo
ORDER BY [Year],[Month],[SequencedDayOfWeek];


--extract month and year(combined) from a date
SELECT RIGHT(CONVERT(CHAR(10),GETDATE(),103),7)


SET DATEFORMAT dmy

DECLARE @CurrentDate DATETIME
    SET @CurrentDate = '28-11-2007'

 SELECT DATEADD(mm,DATEDIFF(mm,0,@CurrentDate),0)     AS FirstDayOfMonth,
        DATEADD(mm,DATEDIFF(mm,0,@CurrentDate)+1,0)-1 AS LastDayOfMonth,
        DATEADD(mm,DATEDIFF(mm,0,@CurrentDate)+1,0)   AS FirstDayOfNextMonth
-- ISO Week or ISOWeek
DECLARE @Year    CHAR(4) 
DECLARE @NextYear CHAR(4)
DECLARE @ISOWeek VARCHAR(2)

    SET @Year    = '2001'
    SET @ISOWeek = '53'
    SET @NextYear = @Year+1
 
SELECT 
CASE
WHEN @ISOWeek > 0
 AND DATEADD(wk,DATEDIFF(wk,0,'01/04/'+@Year),0)+((@ISOWeek-1)*7) 
   < DATEADD(wk,DATEDIFF(wk,0,'01/04/'+@NextYear),0)
THEN DATEADD(wk,DATEDIFF(wk,0,'01/04/'+@Year),0)+((@ISOWeek-1)*7)
ELSE 0 
END AS StartDate,
       DATEADD(wk,DATEDIFF(wk,0,'01/04/'+@Year),0)+((@ISOWeek)*7)-1 AS EndDate
       
  --Calculating time between 2 dates minus time from week(s) end(s)     
       
       SELECT (DATEDIFF(dd,@StartDate,@EndDate)+1)
       -(DATEDIFF(wk,@StartDate,@EndDate)*2) 
       -(CASE WHEN DATENAME(dw,@StartDate) = 'Sunday' THEN 1 ELSE 0 END) 
       -(CASE WHEN DATENAME(dw,@EndDate) = 'Saturday' THEN 1 ELSE 0 END)
       
   --
       SET @Time = '1330'

 SELECT STUFF(@Time,3,0,':') + ':00'
 
 --Date range or daterange
 
 DECLARE @pStartDate DATETIME,
        @pEndDate   DATETIME
;
 SELECT @pStartDate = '2009-10-01',
        @pEndDate   = '2009-12-31'
;
WITH
      E1(N) AS (SELECT 1 UNION ALL SELECT 1 UNION ALL SELECT 1 UNION ALL
                SELECT 1 UNION ALL SELECT 1 UNION ALL SELECT 1 UNION ALL
                SELECT 1 UNION ALL SELECT 1 UNION ALL SELECT 1 UNION ALL
                SELECT 1),                 --10
      E2(N) AS (SELECT 1 FROM E1 a, E1 b), --100
      E4(N) AS (SELECT 1 FROM E2 a, E2 b), --10,000
      E8(N) AS (SELECT 1 FROM E4 a, E4 b), --100,000,000
cteTally(N) AS (SELECT ROW_NUMBER() OVER (ORDER BY N) FROM E8) --Add row numbers
 SELECT DATEADD(mm,DATEDIFF(mm,0,@pStartDate) + (t.N-1),0)    AS MonthStart,
        DATEADD(mm,DATEDIFF(mm,0,@pStartDate) + (t.N  ),0) -1 AS MonthEnd
   FROM cteTally t
  WHERE t.N BETWEEN 1 AND DATEDIFF(mm,@pStartDate,@pEndDate)+1
    
    
    DECLARE @pStartDate DATETIME,
        @pEndDate   DATETIME
 SELECT @pStartDate = '2009-10-01',
        @pEndDate   = '2009-12-31'

 SELECT DATEADD(mm,DATEDIFF(mm,0,@pStartDate) + (t.N-1),0) AS MonthStart,
        DATEADD(mm,DATEDIFF(mm,0,@pStartDate) + (t.N  ),0) AS NextMonthStart
   FROM dbo.Tally t
  WHERE t.N BETWEEN 1 AND DATEDIFF(mm,@pStartDate,@pEndDate)+1
	--format HH:MM:SS
	 SELECT CONVERT(VARCHAR(10),DATEDIFF(hh,0,DATEADD(ss,SecondsColumn,0)))
      + RIGHT(CONVERT(CHAR(8),DATEADD(ss,SecondsColumn,0),108),6)
      
      
--year dates

-- See how this starts off with a table and data in it?
-- If you had provided us the data in this format, 
-- it would have made things easier for all of the
-- volunteers on this site to help you out.
declare @temp table (MyDateField datetime);
insert into @temp 
select '20100101' UNION ALL
select '20150101';

declare @Min datetime, 
        @Max datetime,
        @Age int;
select @Min = MIN(MyDateField),
       @Max = MAX(MyDateField)
  from @temp;

select @Age = DATEDIFF(year, @Min, @Max);

-- See Jeff Modem's article The "Numbers" or "Tally" Table: What it is and how it replaces a loop.
-- at http://www.sqlservercentral.com/articles/T-SQL/62867/.
;WITH 
Tens (N)     AS (SELECT 0 UNION ALL SELECT 0 UNION ALL SELECT 0 UNION ALL SELECT 0 UNION ALL SELECT 0 UNION ALL
                 SELECT 0 UNION ALL SELECT 0 UNION ALL SELECT 0 UNION ALL SELECT 0 UNION ALL SELECT 0), 
Thousands(N) AS (SELECT 1 FROM Tens t1 CROSS JOIN Tens t2 CROSS JOIN Tens t3), 
Millions (N) AS (SELECT 1 FROM Thousands t1 CROSS JOIN Thousands t2), 
Tally (N)    AS (SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 0)) FROM Millions)
SELECT DateField = DATEADD(year, N, @Min)
  FROM Tally
 WHERE N <= @Age
UNION ALL
SELECT @Min 
order by DateField;

 Previous Week: DateDiff(wk,getdate(),datefield) = -1
  Current Week: DateDiff(wk,getdate(),datefield) =  0
     Next Week: DateDiff(wk,getdate(),datefield) =  1
 
Previous Month: DateDiff(mm,getdate(),datefield) = -1
 Current Month: DateDiff(mm,getdate(),datefield) =  0
    Next Month: DateDiff(mm,getdate(),datefield) =  1
  
  
Declare @subjectDate datetime;
Set @subjectDate = current_timestamp;

Select @subjectDate
       ,dateadd(month, datediff(month, 0, @subjectDate), 0) As FirstOfMonth
       ,dateadd(month, datediff(month, -1, @subjectDate), -1) As LastOfMonth
       ,dateadd(month, datediff(month, 0, @subjectDate) - 1, 0) As PreviousFirstOfMonth
       ,dateadd(month, datediff(month, -1, @subjectDate) - 1, -1) As PreviousLastOfMonth
       ,dateadd(month, datediff(month, 0, @subjectDate) - 1, 0) As PreviousFirstOfMonth
       ,dateadd(month, datediff(month, -1, @subjectDate) - 1, -1) As PreviousLastOfMonth
       ,dateadd(month, datediff(month, 0, @subjectDate) + 1, 0) As NextFirstOfMonth
       ,dateadd(month, datediff(month, -1, @subjectDate) + 1, -1) As NextLastOfMonth;
       
Set @subjectDate = '20080220';

Select @subjectDate
       ,dateadd(month, datediff(month, 0, @subjectDate), 0) As FirstOfMonth
       ,dateadd(month, datediff(month, -1, @subjectDate), -1) As LastOfMonth
       ,dateadd(month, datediff(month, 0, @subjectDate) - 1, 0) As PreviousFirstOfMonth
       ,dateadd(month, datediff(month, -1, @subjectDate) - 1, -1) As PreviousLastOfMonth
       ,dateadd(month, datediff(month, 0, @subjectDate) - 1, 0) As PreviousFirstOfMonth
       ,dateadd(month, datediff(month, -1, @subjectDate) - 1, -1) As PreviousLastOfMonth
       ,dateadd(month, datediff(month, 0, @subjectDate) + 1, 0) As NextFirstOfMonth
       ,dateadd(month, datediff(month, -1, @subjectDate) + 1, -1) As NextLastOfMonth;
       
 --total elasped time
 
 
 select
	TotalElapsedTime =
	dateadd(dd,sum(datediff(dd,0,a.ET)),
	dateadd(hh,sum(datepart(hh,a.ET)),
	dateadd(mi,sum(datepart(mi,a.ET)),
	dateadd(ss,sum(datepart(ss,a.ET)),
	dateadd(ms,sum(datepart(ms,a.ET)),0)))))
from
	( -- Test Data
	select ET = convert(datetime,'1900-01-01 07:49:03.000')	union all
	select ET = convert(datetime,'1900-01-01 02:28:06.000')	union all
	select ET = convert(datetime,'1900-01-01 03:09:01.003')	union all
	select ET = convert(datetime,'1900-01-01 06:19:02.040')	union all
	select ET = convert(datetime,'1900-01-07 06:19:02.000')
	) a
	
	
	select
	[Days]		= datediff(day,0,ET-ST),
	[Hours]		= datepart(Hour,ET-ST),
	[Minutes]	= datepart(Minute,ET-ST),
	[Seconds]	= datepart(Second,ET-ST),
	[Milliseconds]	= datepart(millisecond,ET-ST)
from
	(
	select	-- Test Data
		ST = convert(datetime,'2008/09/22 00:35:33.997'),
		ET = convert(datetime,'2009/10/22 01:05:45.443')
	) a


-- convert to int

select convert(int,getdate())
--40332 days since 01-01-1990, SQL's internal start date

select YEAR(getdate()) * 10000
 + MONTH(getdate()) * 100
 + DAY(getdate())
 --an integer "20100604"

      