CREATE FUNCTION dbo.removenonnumeric(@sText AS VARCHAR(8000))
RETURNS VARCHAR(8000)
     AS
  BEGIN
        DECLARE @Result AS VARCHAR(8000)
         SELECT @Result = ISNULL(@Result,'') + SUBSTRING(@sText, N, 1) 
           FROM dbo.TALLY 
          WHERE N <= LEN(@sText) 
            AND SUBSTRING(@sText, N, 1) LIKE '[0-9]'
 RETURN @Result
    END
GO