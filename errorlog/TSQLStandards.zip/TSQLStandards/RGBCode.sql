CREATE FUNCTION dbo.RGBCode
/**********************************************************************************************************************
 Purpose:
 Given an "RGB" value in the form of either "R,G,B" where each value is a decimal octet (0-255) or single 
 "DecimalColorValue" that represents the full color, convert the given value to an HTML Color Value in the form of
 "#rrggbb" where "rr", "gg", and "bb" are two character representations of hex bytes.

 Programmer's Notes:

 1. Note that this function uses functionality from the CONVERT function that is only available in SQL Server 2008
    and above.  It will NOT work in 2005 and below.

 2. If any individual parameter cannot be implicitly converted to an INT, the code will fail with the following
    error:
    Msg 245, Level 16, State 1, Line 1
    Conversion failed when converting the nvarchar value 'x38' to data type int.

 3. No error checking is done for negative numbers or octets being in the range of 0-255 and will return incorrect
    results if such problem parameters are passed in.

 4. If more than 3 delimited values are provided as the input, only 3 of the values will be used from right to
    left as "R,G,B".

 Usage Examples:

--===== Simple Single Value Syntax using "R,G,B" values (Strawberry Color #BE2625, in this case)
 SELECT RGBCode FROM dbo.RGBCode('190,38,37')
;
--===== This will return the same value as if '190,38,37' were used. See Note 4 in the "Programmer's Notes" above.
 SELECT RGBCode FROM dbo.RGBCode('100,190,38,37')
;
--===== Simple Single Value Syntax using a "DecimalColorValue" value (Strawberry Color #BE2625, in this case).
     -- Note that the code does a byte reversal to support when the decimal values come from a GUI where the LSB is
        furthest to the right and the MSB is furthest to the left at the machine language level.
 SELECT RGBCode FROM dbo.RGBCode(2434750)
;
--===== Multi-row Syntax using "R,G,B" values.
 SELECT ca.RGBCode 
   FROM dbo.SomeTable st
  CROSS APPLY dbo.RGBCode(st.RGBColumn) ca
;
--===== Multi-row Syntax using a "DecimalColorValue" value.
     -- Note that the code does a byte reversal to support when the decimal values come from a GUI where the LSB 
        and MSB are reversed compared to SQL Server returns at the machine language level.
 SELECT ca.RGBCode 
   FROM dbo.SomeTable st
  CROSS APPLY dbo.RGBCode(st.DecimalColorValue) ca
;

 Revision History:
 Rev 00 - 14 Mar 2015 - Jeff Moden 
        - Initial creation and partial unit testing.
        - Reference: http://www.sqlservercentral.com/Forums/Topic1668566-391-1.aspx (Original requirement)
        - Reference: http://www.december.com/html/spec/colorcodes.html (HTML Color Codes)
**********************************************************************************************************************/
--===== Define the I/O for this function
        (@StringRGB VARCHAR(20))
RETURNS TABLE WITH SCHEMABINDING AS
 RETURN WITH
 cteReDelim  AS ( --=== Prepare for parsing with PARSENAME.
                 SELECT Newstring = REPLACE(@StringRGB,',','.')
                )
,cteRGBHex   AS ( --=== Parses the input string whether it is "R,G,B" or "DecimalValue"
                 SELECT RGB =   CONVERT
                                    ( --== Convert each part to a decimal value and add them up.
                                    BINARY(3)
                                    ,ISNULL(PARSENAME(NewString,1),0) --Only one filled if single decimal passed in.
                                    +ISNULL(PARSENAME(NewString,2),0)*256
                                    +ISNULL(PARSENAME(NewString,3),0)*65536
                                    )
                   FROM cteReDelim
                )
,cteReverse  AS ( --=== Reverses the bytes if a single decimal value was passed in.
                 SELECT RGB =   CASE
                                    WHEN @StringRGB LIKE '%,%' 
                                    THEN RGB 
                                    ELSE CONVERT(BINARY(3),REVERSE(RGB))
                                END
                   FROM cteRGBHex
                )
--===== Convert the resulting 0xHEX to a string and prefix with "#".
 SELECT RGBCode = '#' + CONVERT(CHAR(7),RGB,2) 
   FROM cteReverse
;
