--DROP TABLE dbo.JBMTest,dbo.MyInTable
--===== Do this test in a nice safe place that everyone has...
USE TempDB
GO

--===== Create and populate a 1,000,000 row test table.
-- Column "RowNum" has a range of 1 to 1,000,000 unique numbers
-- Column "SomeInt" has a range of 1 to 50,000 non-unique numbers
-- Column "SomeLetters2" has a range of "AA" to "ZZ" non-unique 2 character strings
-- Column "SomeMoney has a range of 0.0000 to 99.9999 non-unique numbers
-- Column "SomeDate" has a range of  >=01/01/2000 and <01/01/2010 non-unique date/times
-- Column "SomeCSV" contains 'Part01,Part02,Part03,Part04,Part05,Part06,Part07,Part08,Part09,Part10'
--        for all rows.
-- Column "SomeHex12" contains 12 random hex characters (ie, 0-9,A-F)
-- Jeff Moden
DECLARE @Characters VARCHAR(100)
	,@Length INT

SELECT @Characters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789~`!@#$%^&*()_-+=|\{}[]:;"<>.?/,'''
	,@Length = LEN(@Characters)

SELECT TOP 1000000 RowNum = IDENTITY(INT, 1, 1)
	,ProductName = CHAR(STR(RAND(CAST(NEWID() AS VARBINARY)) * 25 + 65)) + CHAR(STR(RAND(CAST(NEWID() AS VARBINARY)) * 25 + 65)) + ' Type Product Name'
	,Cost = CAST(RAND(CAST(NEWID() AS VARBINARY)) * 100 AS MONEY)
	 PreFragmentationPercent = ABS(CHECKSUM(NEWID()))%101,
        IndexActive             = ABS(CHECKSUM(NEWID()))%2
	,  RandomDate = DATEADD(second,ABS(CHECKSUM(NEWID()))%36000, DATEADD(day,ABS(CHECKSUM(NEWID()))%3653+36524,'2000-01-01 00:00:01'))
	,VendorID = CAST(RAND(CAST(NEWID() AS VARBINARY)) * 50000 + 1 AS INT)
	,SomeDate = CAST(RAND(CAST(NEWID() AS VARBINARY)) * 3653.0 + 36524.0 AS DATETIME)
	,Start_Dt    = CAST(RAND(CHECKSUM(NEWID()))*3653.0+36524.0 AS DATETIME)
    ,End_Dt      = CAST(RAND(CHECKSUM(NEWID()))*3653.0+36524.0 AS DATETIME)
	,RandomSSN =RIGHT('000000000' + CAST(ABS(CHECKSUM(NEWID())) % 1000000000 AS VARCHAR(9)), 9)  
	,SomeMixedString = REPLICATE(CAST(NEWID() AS VARCHAR(50)), 1)
	,SomeInt = ABS(CHECKSUM(NEWID())) % 50000 + 1
	,SomeLetters2 = CHAR(ABS(CHECKSUM(NEWID())) % 26 + 65) + CHAR(ABS(CHECKSUM(NEWID())) % 26 + 65)
	,SomeCSV = CAST('Part01,Part02,Part03,Part04,Part05,Part06,Part07,Part08,Part09,Part10' AS VARCHAR(80))
	,SomeMoney = CAST(ABS(CHECKSUM(NEWID())) % 10000 / 100.0 AS MONEY)
	,SomeDate = CAST(RAND(CHECKSUM(NEWID())) * 3653.0 + 36524.0 AS DATETIME)
	,SomeString = CAST('‘Special Digital Data Service Obligation’' AS VARCHAR(80))
	,DATE = CAST(RAND(CHECKSUM(NEWID())) * 3653.0 + 36524.0 AS DATETIME)
	,SalesPerson = CAST(RIGHT(NEWID(), 2) + 'SalesPersonName' AS VARCHAR(100))
	,STATE = CHAR(ABS(CHECKSUM(NEWID())) % 25 + 65) + CHAR(ABS(CHECKSUM(NEWID())) % 2 + 65)
	--,Cost = CAST(ABS(CHECKSUM(NEWID())) % 10000 / 100.0 AS FLOAT)
	,LEFT(CAST(NEWID() AS VARCHAR(128)), 2) AS twoDigit
	,LEFT(CAST(NEWID() AS VARCHAR(128)), 3) AS threeDigit
	,LEFT(CAST(NEWID() AS VARCHAR(128)), 4) AS fourDigit
	,LEFT(CAST(NEWID() AS VARCHAR(128)), 5) AS fiveDigit
	,LEFT(CAST(NEWID() AS VARCHAR(128)), 6) AS sixDigit
	,SomeDigits   = CAST(ABS(CHECKSUM(NEWID()))%50000+1 AS VARCHAR(10))
	,(1 + ABS(CHECKSUM(NEWID())) % 10) AS tenPower
	,(10 + ABS(CHECKSUM(NEWID())) % 90) AS hundredPower
	,(100 + ABS(CHECKSUM(NEWID())) % 900) AS thousandPower
	,SomeHex12 = RIGHT(NEWID(), 12)
	,Password = SUBSTRING(@Characters, ABS(CHECKSUM(NEWID())) % @Length + 1, 1) + SUBSTRING(@Characters, ABS(CHECKSUM(NEWID())) % @Length + 1, 1) + SUBSTRING(@Characters, ABS(CHECKSUM(NEWID())) % @Length + 1, 1) + SUBSTRING(@Characters, ABS(CHECKSUM(NEWID())) % @Length + 1, 1) + SUBSTRING(@Characters, ABS(CHECKSUM(NEWID())) % @Length + 1, 1) + SUBSTRING(@Characters, ABS(CHECKSUM(NEWID())) % @Length + 1, 1) + SUBSTRING(@Characters, ABS(CHECKSUM(NEWID())) % @Length + 1, 1) + SUBSTRING(@Characters, ABS(CHECKSUM(NEWID())) % @Length + 1, 1) + SUBSTRING(@Characters, ABS(CHECKSUM(NEWID())) % @Length + 1, 1) + SUBSTRING(@Characters, ABS(CHECKSUM(NEWID())) % @Length + 1, 1)
	,ID = ABS(CHECKSUM(NEWID())) % 50000 + 1 -- Column "ID" has a range of 1 to 50,000 non-unique numbers
	,NAME = CHAR(ABS(CHECKSUM(NEWID())) % 26 + 65) + CHAR(ABS(CHECKSUM(NEWID())) % 26 + 65) -- Column "Name" has a range of "AA" to "ZZ" non-unique 2 character stringsontains 12 random hex characters (ie, 0-9,A-F)
	,DateCol = DATEADD(mm, (
			ROW_NUMBER() OVER (
				ORDER BY (
						SELECT NULL
						)
				) - 1
			), '1900')
	,Weights = RAND(CHECKSUM(NEWID())) * 10
	,SomeID = ABS(CHECKSUM(NEWID())) % 2500 + 1 --<<<LOOK! CHANGE THIS NUMBER TO 1/400th THE ROW COUNT
	,SomeCode = CHAR(ABS(CHECKSUM(NEWID())) % 26 + 65) + CHAR(ABS(CHECKSUM(NEWID())) % 26 + 65)
	,DocNo = ABS(CHECKSUM(NEWID())) % 200000 + 1
	,Line = CHAR(ABS(CHECKSUM(NEWID())) % 26 + 64)
	,LStatus = CHAR(ABS(CHECKSUM(NEWID())) % 26 + 64) + CHAR(ABS(CHECKSUM(NEWID())) % 26 + 64)
	--,SomeDate     = CAST(RAND(CHECKSUM(NEWID()))*3653.0+36524.0 AS DATETIME)
	,MyID = IDENTITY(BIGINT, 82011000000001, 1) -- Column "MyID" has a range of 1 to 1,000,000 unique numbers starting at 82011000000001
	,CAST('File ' + CAST(ROW_NUMBER() OVER (
				ORDER BY (
						SELECT NULL
						)
				) AS VARCHAR(100)) AS VARCHAR(100)) AS FileName
	,CAST(ABS(CHECKSUM(NEWID())) % (2000000 - 200000 + 1) + 200000 AS BIGINT) AS Bytes
	,CAST(0 AS BIGINT) AS RunningTotal
	,CAST(0 AS INT) AS Group100Meg
	,AccountNumber = CASE 
		WHEN (N % 1000) = 0
			THEN 1000
		ELSE N % 1000
		END
	,Value = CHAR(CONVERT(INT, RAND(CHECKSUM(NEWID())) * 10) + 64) + CHAR(CONVERT(INT, RAND(CHECKSUM(NEWID())) * 10) + 64) + CHAR(CONVERT(INT, RAND(CHECKSUM(NEWID())) * 10) + 64)
INTO dbo.JBMTest
FROM Master.dbo.SysColumns t1
CROSS JOIN Master.dbo.SysColumns t2

--===== A table is not properly formed unless a Primary Key has been assigned
ALTER TABLE dbo.JBMTest ADD PRIMARY KEY CLUSTERED (RowNum)

--===== Create a table with some "WHERE IN" values
SELECT TOP 1000 IDENTITY(INT, 1, 1) AS RowNum
	,ABS(CHECKSUM(NEWID())) % 50000 + 1 AS SomeInt
INTO dbo.MyInTable
FROM Master.dbo.SysColumns t1

--===== A table is not properly formed unless a Primary Key has been assigned
ALTER TABLE dbo.MyInTable ADD PRIMARY KEY CLUSTERED (RowNum)

--===== Add an index to it
CREATE INDEX IX_MyInTable_SomeInt ON dbo.MyInTable (SomeInt)



/*
--===== Conditionally drop the permanent random code and winner tables
     -- Uncomment if you want to test for reruns
     IF OBJECT_ID('dbo.jbmRandomCode','U') IS NOT NULL
        DROP TABLE dbo.jbmRandomCode
;
     IF OBJECT_ID('dbo.jbmWinnerCode','U') IS NOT NULL
        DROP TABLE dbo.jbmWinnerCode
;
--===== Generate 1.6 Million random codes where no two adjacent characters
     -- are alike.  We also remove all vowels to keep from accidently 
     -- spelling swear words and we remove things that could be mistaken
     -- for each other such as:
     -- Capital "O" and "0" (zero)
     -- Lower Case "L" and "1" (one)
     -- Lower Case "o" removed just to avoid all confusion
     -- Jeff Moden
WITH 
cteBytes AS
( --=== Generate 2.2 Million random 8 byte numbers.
     -- We need this many so that when we remove numbers that
     -- have identical adjacent characters and any dupes, 
     -- we still have enough to gen 1.6 Million random codes.
     -- This is done at the byte level because NEWID is expensive to run.
     -- If we ran 8 individual NEWID()'s for each code, this code would
     -- take a lot longer.
 SELECT TOP 2200000 CAST(NEWID() AS BINARY(8)) AS Bytes
   FROM Master.sys.All_Columns ac1
  CROSS JOIN Master.sys.All_Columns ac2  
)
,
cteCharacters AS
( --=== This is just the list of characters that we have to chose from.
     -- Vowels and certain other characters have been removed to avoid confusion.
     -- Note that both strings must be absolutely identical here.
 SELECT LEN('BCDFGHJKLMNPQRSTVWXYZbcdfghjkmnpqrstvwxyz23456789') AS CharLen,
            'BCDFGHJKLMNPQRSTVWXYZbcdfghjkmnpqrstvwxyz23456789'  AS Characters
)
,
cteChars AS
( --=== This takes each byte from the random 8 byte binary number and converts each into
     -- a human readable character by using the random byte to select from the allowed
     -- character list.  Note that "modulo" (%) plays an important role here.
 SELECT SUBSTRING(c.Characters,CAST(SUBSTRING(b.Bytes,1,1) AS INT)%c.CharLen+1,1) AS Char1,
        SUBSTRING(c.Characters,CAST(SUBSTRING(b.Bytes,2,1) AS INT)%c.CharLen+1,1) AS Char2,
        SUBSTRING(c.Characters,CAST(SUBSTRING(b.Bytes,3,1) AS INT)%c.CharLen+1,1) AS Char3,
        SUBSTRING(c.Characters,CAST(SUBSTRING(b.Bytes,4,1) AS INT)%c.CharLen+1,1) AS Char4,
        SUBSTRING(c.Characters,CAST(SUBSTRING(b.Bytes,5,1) AS INT)%c.CharLen+1,1) AS Char5,
        SUBSTRING(c.Characters,CAST(SUBSTRING(b.Bytes,6,1) AS INT)%c.CharLen+1,1) AS Char6,
        SUBSTRING(c.Characters,CAST(SUBSTRING(b.Bytes,7,1) AS INT)%c.CharLen+1,1) AS Char7,
        SUBSTRING(c.Characters,CAST(SUBSTRING(b.Bytes,8,1) AS INT)%c.CharLen+1,1) AS Char8
   FROM cteBytes b
  CROSS JOIN cteCharacters c
)
,
cteRandomCode AS
( --=== Now we take all the individual letters and slam them together to make a random code.
     -- In the process, we make sure that no two adjacent characters are alike.
 SELECT Char1+Char2+Char3+Char4+Char5+Char6+Char7+Char8 AS RandomCode
   FROM cteChars
  WHERE Char1<>Char2 AND Char2<>Char3 AND Char3<>Char4 AND Char4<>Char5 AND Char5<> Char6 AND Char6<>Char7 AND Char7<>Char8
)
,
cteNumberDupes AS
( --=== We need to remove dupes and this numbers one or more occurances of the same code
     -- with an incrementing number to count occurances of that same code.
 SELECT ROW_NUMBER() OVER (PARTITION BY RandomCode ORDER BY RandomCode) AS Occurance,
        RandomCode
   FROM cteRandomCode
) --=== This selects the top 1.6 million first occurances of all the codes we haven't
     -- rejected so far.  Since we only select the first occurance of any given code,
     -- this effectively removes dupes and does so much faster than using DISTINCT.
     -- The final result is stored in a new table called dbo.jbmRandomCode.
 SELECT TOP 1600000
        IDENTITY(INT,1,1) AS RowNum, 
        RandomCode COLLATE Latin1_General_BIN AS RandomCode --For case sensitivity
   INTO dbo.jbmRandomCode
   FROM cteNumberDupes
  WHERE Occurance = 1
;

select  * from jbmRandomCode


*/
--Random 64 Characters alphanumeric String


SELECT REPLACE(CONVERT(CHAR(36),NEWID())+CONVERT(CHAR(36),NEWID()),'-','')