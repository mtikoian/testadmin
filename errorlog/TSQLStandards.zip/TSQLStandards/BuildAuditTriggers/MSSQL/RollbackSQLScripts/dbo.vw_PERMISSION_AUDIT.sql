

    /***
================================================================================
Name        : dbo.vw_PERMISSION_AUDIT.sql
Author      : N/A
Description : This is a script to drop the auto-generated view from the
              BuildAuditTrigger framework.

Revision: $Rev: $
URL: $URL: $
Last Checked in: $Author: $
===============================================================================

Revisions    :
--------------------------------------------------------------------------------
Ini|   Date   | Description
--------------------------------------------------------------------------------

================================================================================
***/

IF EXISTS
   (SELECT 1 FROM INFORMATION_SCHEMA.VIEWS
    WHERE table_schema = N'dbo' and table_name = N'vw_PERMISSION_AUDIT')
   BEGIN
      DROP VIEW dbo.vw_PERMISSION_AUDIT;
      PRINT 'VIEW dbo.vw_PERMISSION_AUDIT has been dropped.';
   END;
GO

