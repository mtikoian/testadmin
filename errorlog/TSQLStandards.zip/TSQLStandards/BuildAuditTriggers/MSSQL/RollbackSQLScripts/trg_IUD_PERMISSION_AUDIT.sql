

    /***
================================================================================
Name        : trg_IUD_PERMISSION_AUDIT
Author      : N/A
Description : This is an auto-generated script to drop a trigger from the
              BuildAuditTrigger framework.

Revision: $Rev: $
URL: $URL: $
Last Checked in: $Author: $
===============================================================================

Revisions    :
--------------------------------------------------------------------------------
Ini|   Date   | Description
--------------------------------------------------------------------------------

================================================================================
***/

IF OBJECT_ID('dbo.trg_IUD_PERMISSION_AUDIT') IS NOT NULL
   DROP TRIGGER dbo.trg_IUD_PERMISSION_AUDIT;
GO

