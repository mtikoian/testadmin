
IF EXISTS
   (SELECT 1 FROM INFORMATION_SCHEMA.VIEWS
    WHERE table_schema = N'dbo' and table_name = N'vw_PERMISSION_AUDIT')
   BEGIN
      DROP VIEW dbo.vw_PERMISSION_AUDIT;
      PRINT 'VIEW dbo.vw_PERMISSION_AUDIT has been dropped.';
   END;
GO

/***
================================================================================
Name        : dbo.vw_PERMISSION_AUDIT.sql
Author      : N/A
Description : This is an auto-generated view from the BuildAuditTrigger framework.

Revision: $Rev: $
URL: $URL: $
Last Checked in: $Author: $
===============================================================================

Revisions    :
--------------------------------------------------------------------------------
Ini|   Date   | Description
--------------------------------------------------------------------------------

================================================================================
***/

CREATE VIEW dbo.vw_PERMISSION_AUDIT AS
SELECT TAB.AUDIT_TYPE,
       TAB.AUDIT_TIMESTAMP,
       TAB.TABLE_NAME,
       TAB.PRIMARY_KEY_VALUE,
       TAB.USER_ID,
       MAX(TAB.OLD_USER_CLS_ID) AS OLD_USER_CLS_ID,
       MAX(TAB.NEW_USER_CLS_ID) AS NEW_USER_CLS_ID,
       MAX(TAB.OLD_ACCT_ID) AS OLD_ACCT_ID,
       MAX(TAB.NEW_ACCT_ID) AS NEW_ACCT_ID,
       MAX(TAB.OLD_BK_ID) AS OLD_BK_ID,
       MAX(TAB.NEW_BK_ID) AS NEW_BK_ID,
       MAX(TAB.OLD_ORG_ID) AS OLD_ORG_ID,
       MAX(TAB.NEW_ORG_ID) AS NEW_ORG_ID,
       MAX(TAB.OLD_LST_CHG_TMS) AS OLD_LST_CHG_TMS,
       MAX(TAB.NEW_LST_CHG_TMS) AS NEW_LST_CHG_TMS,
       MAX(TAB.OLD_LST_CHG_USR_ID) AS OLD_LST_CHG_USR_ID,
       MAX(TAB.NEW_LST_CHG_USR_ID) AS NEW_LST_CHG_USR_ID,
       MAX(TAB.OLD_Create_user_id) AS OLD_Create_user_id,
       MAX(TAB.NEW_Create_user_id) AS NEW_Create_user_id
       FROM (SELECT AT.AUDIT_TYPE,
                    AT.AUDIT_TIMESTAMP,
                    AT.TABLE_NAME,
                    AT.PRIMARY_KEY_VALUE,
                    AT.USER_ID,
                    CASE AT.COLUMN_NAME
                       WHEN 'USER_CLS_ID' THEN AT.OLD_VALUE
                    END AS OLD_USER_CLS_ID,
                    CASE AT.COLUMN_NAME
                       WHEN 'USER_CLS_ID' THEN AT.NEW_VALUE
                    END AS NEW_USER_CLS_ID,
                    CASE AT.COLUMN_NAME
                       WHEN 'ACCT_ID' THEN AT.OLD_VALUE
                    END AS OLD_ACCT_ID,
                    CASE AT.COLUMN_NAME
                       WHEN 'ACCT_ID' THEN AT.NEW_VALUE
                    END AS NEW_ACCT_ID,
                    CASE AT.COLUMN_NAME
                       WHEN 'BK_ID' THEN AT.OLD_VALUE
                    END AS OLD_BK_ID,
                    CASE AT.COLUMN_NAME
                       WHEN 'BK_ID' THEN AT.NEW_VALUE
                    END AS NEW_BK_ID,
                    CASE AT.COLUMN_NAME
                       WHEN 'ORG_ID' THEN AT.OLD_VALUE
                    END AS OLD_ORG_ID,
                    CASE AT.COLUMN_NAME
                       WHEN 'ORG_ID' THEN AT.NEW_VALUE
                    END AS NEW_ORG_ID,
                    CASE AT.COLUMN_NAME
                       WHEN 'LST_CHG_TMS' THEN AT.OLD_VALUE
                    END AS OLD_LST_CHG_TMS,
                    CASE AT.COLUMN_NAME
                       WHEN 'LST_CHG_TMS' THEN AT.NEW_VALUE
                    END AS NEW_LST_CHG_TMS,
                    CASE AT.COLUMN_NAME
                       WHEN 'LST_CHG_USR_ID' THEN AT.OLD_VALUE
                    END AS OLD_LST_CHG_USR_ID,
                    CASE AT.COLUMN_NAME
                       WHEN 'LST_CHG_USR_ID' THEN AT.NEW_VALUE
                    END AS NEW_LST_CHG_USR_ID,
                    CASE AT.COLUMN_NAME
                       WHEN 'Create_user_id' THEN AT.OLD_VALUE
                    END AS OLD_Create_user_id,
                    CASE AT.COLUMN_NAME
                       WHEN 'Create_user_id' THEN AT.NEW_VALUE
                    END AS NEW_Create_user_id
             FROM dbo.AUDIT_TRAIL AT
             WHERE AT.TABLE_NAME = 'PERMISSION') TAB
       GROUP BY TAB.AUDIT_TYPE,
                TAB.AUDIT_TIMESTAMP,
                TAB.TABLE_NAME,
                TAB.PRIMARY_KEY_VALUE,
                TAB.USER_ID;
GO

