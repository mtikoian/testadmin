

IF OBJECT_ID('dbo.trg_IUD_PERMISSION_AUDIT') IS NOT NULL
   DROP TRIGGER dbo.trg_IUD_PERMISSION_AUDIT;
GO

    /***
================================================================================
Name        : trg_IUD_PERMISSION_AUDIT
Author      : N/A
Description : This is an auto-generated trigger from the BuildAuditTrigger framework.

Revision: $Rev: $
URL: $URL: $
Last Checked in: $Author: $
===============================================================================

Revisions    :
--------------------------------------------------------------------------------
Ini|   Date   | Description
--------------------------------------------------------------------------------

================================================================================
***/

CREATE TRIGGER dbo.trg_IUD_PERMISSION_AUDIT
ON dbo.PERMISSION
AFTER INSERT, UPDATE, DELETE
AS
BEGIN

-- Trigger generated Wed Dec 10 17:15:24 2014 by BuildAuditTriggersW process

   -- Local declarations
   DECLARE @l_TableName   VARCHAR(32);
   DECLARE @l_AuditType   VARCHAR(10);
   DECLARE @l_Tag         VARCHAR(20);
   DECLARE @l_Datetime    DATETIME;

   DECLARE @USER_CLS_ID char(8);
   DECLARE @ACCT_ID char(12);
   DECLARE @BK_ID char(4);
   DECLARE @ORG_ID char(4);

   -- The table name for the audit will always be the same for this table
   Set @l_TableName = 'PERMISSION';

   -- Get the structure version tag from the db_control table so we know
   -- under what structure version the audit took place
   Select @l_Tag = Structure_Version_Tag From dbo.DB_CONTROL;

   -- Get the current date and time to use on each audit trail row
   Set @l_Datetime = getdate();

   IF (SELECT Count(1) FROM inserted) > 0
   BEGIN
      IF (SELECT Count(1) FROM deleted) > 0
      BEGIN
         -- Update action
         -- Audit type and user id
         Set @l_AuditType = 'UPDATE';

         -- If the column has been changed, audit it
         INSERT INTO dbo.Audit_Trail (Structure_Version_Tag, Table_Name, Column_Name, Audit_Type, [User_ID], Audit_Timestamp, Old_Value, New_Value, Primary_Key_Value, Sequence_Num)
         SELECT @l_Tag,
                @l_TableName,
                'USER_CLS_ID',
                @l_AuditType,
                i.LST_CHG_USR_ID,
                @l_Datetime,
                d.USER_CLS_ID,
                i.USER_CLS_ID,
                'USER_CLS_ID:'+ISNULL(CAST(i.USER_CLS_ID as varchar(30)),CAST(d.USER_CLS_ID as varchar(30)))+'|'+'ACCT_ID:'+ISNULL(CAST(i.ACCT_ID as varchar(30)),CAST(d.ACCT_ID as varchar(30)))+'|'+'BK_ID:'+ISNULL(CAST(i.BK_ID as varchar(30)),CAST(d.BK_ID as varchar(30)))+'|'+'ORG_ID:'+ISNULL(CAST(i.ORG_ID as varchar(30)),CAST(d.ORG_ID as varchar(30))),
                row_number() over (order by i.USER_CLS_ID,i.ACCT_ID,i.BK_ID,i.ORG_ID)
         FROM INSERTED i FULL OUTER JOIN DELETED d ON d.USER_CLS_ID = i.USER_CLS_ID and d.ACCT_ID = i.ACCT_ID and d.BK_ID = i.BK_ID and d.ORG_ID = i.ORG_ID
         Where CASE
                  WHEN i.USER_CLS_ID <> d.USER_CLS_ID THEN 1
                  ELSE 0
               END = 1;

         INSERT INTO dbo.Audit_Trail (Structure_Version_Tag, Table_Name, Column_Name, Audit_Type, [User_ID], Audit_Timestamp, Old_Value, New_Value, Primary_Key_Value, Sequence_Num)
         SELECT @l_Tag,
                @l_TableName,
                'ACCT_ID',
                @l_AuditType,
                i.LST_CHG_USR_ID,
                @l_Datetime,
                d.ACCT_ID,
                i.ACCT_ID,
                'USER_CLS_ID:'+ISNULL(CAST(i.USER_CLS_ID as varchar(30)),CAST(d.USER_CLS_ID as varchar(30)))+'|'+'ACCT_ID:'+ISNULL(CAST(i.ACCT_ID as varchar(30)),CAST(d.ACCT_ID as varchar(30)))+'|'+'BK_ID:'+ISNULL(CAST(i.BK_ID as varchar(30)),CAST(d.BK_ID as varchar(30)))+'|'+'ORG_ID:'+ISNULL(CAST(i.ORG_ID as varchar(30)),CAST(d.ORG_ID as varchar(30))),
                row_number() over (order by i.USER_CLS_ID,i.ACCT_ID,i.BK_ID,i.ORG_ID)
         FROM INSERTED i FULL OUTER JOIN DELETED d ON d.USER_CLS_ID = i.USER_CLS_ID and d.ACCT_ID = i.ACCT_ID and d.BK_ID = i.BK_ID and d.ORG_ID = i.ORG_ID
         Where CASE
                  WHEN i.ACCT_ID <> d.ACCT_ID THEN 1
                  ELSE 0
               END = 1;

         INSERT INTO dbo.Audit_Trail (Structure_Version_Tag, Table_Name, Column_Name, Audit_Type, [User_ID], Audit_Timestamp, Old_Value, New_Value, Primary_Key_Value, Sequence_Num)
         SELECT @l_Tag,
                @l_TableName,
                'BK_ID',
                @l_AuditType,
                i.LST_CHG_USR_ID,
                @l_Datetime,
                d.BK_ID,
                i.BK_ID,
                'USER_CLS_ID:'+ISNULL(CAST(i.USER_CLS_ID as varchar(30)),CAST(d.USER_CLS_ID as varchar(30)))+'|'+'ACCT_ID:'+ISNULL(CAST(i.ACCT_ID as varchar(30)),CAST(d.ACCT_ID as varchar(30)))+'|'+'BK_ID:'+ISNULL(CAST(i.BK_ID as varchar(30)),CAST(d.BK_ID as varchar(30)))+'|'+'ORG_ID:'+ISNULL(CAST(i.ORG_ID as varchar(30)),CAST(d.ORG_ID as varchar(30))),
                row_number() over (order by i.USER_CLS_ID,i.ACCT_ID,i.BK_ID,i.ORG_ID)
         FROM INSERTED i FULL OUTER JOIN DELETED d ON d.USER_CLS_ID = i.USER_CLS_ID and d.ACCT_ID = i.ACCT_ID and d.BK_ID = i.BK_ID and d.ORG_ID = i.ORG_ID
         Where CASE
                  WHEN i.BK_ID <> d.BK_ID THEN 1
                  ELSE 0
               END = 1;

         INSERT INTO dbo.Audit_Trail (Structure_Version_Tag, Table_Name, Column_Name, Audit_Type, [User_ID], Audit_Timestamp, Old_Value, New_Value, Primary_Key_Value, Sequence_Num)
         SELECT @l_Tag,
                @l_TableName,
                'ORG_ID',
                @l_AuditType,
                i.LST_CHG_USR_ID,
                @l_Datetime,
                d.ORG_ID,
                i.ORG_ID,
                'USER_CLS_ID:'+ISNULL(CAST(i.USER_CLS_ID as varchar(30)),CAST(d.USER_CLS_ID as varchar(30)))+'|'+'ACCT_ID:'+ISNULL(CAST(i.ACCT_ID as varchar(30)),CAST(d.ACCT_ID as varchar(30)))+'|'+'BK_ID:'+ISNULL(CAST(i.BK_ID as varchar(30)),CAST(d.BK_ID as varchar(30)))+'|'+'ORG_ID:'+ISNULL(CAST(i.ORG_ID as varchar(30)),CAST(d.ORG_ID as varchar(30))),
                row_number() over (order by i.USER_CLS_ID,i.ACCT_ID,i.BK_ID,i.ORG_ID)
         FROM INSERTED i FULL OUTER JOIN DELETED d ON d.USER_CLS_ID = i.USER_CLS_ID and d.ACCT_ID = i.ACCT_ID and d.BK_ID = i.BK_ID and d.ORG_ID = i.ORG_ID
         Where CASE
                  WHEN i.ORG_ID <> d.ORG_ID THEN 1
                  ELSE 0
               END = 1;

         INSERT INTO dbo.Audit_Trail (Structure_Version_Tag, Table_Name, Column_Name, Audit_Type, [User_ID], Audit_Timestamp, Old_Value, New_Value, Primary_Key_Value, Sequence_Num)
         SELECT @l_Tag,
                @l_TableName,
                'LST_CHG_TMS',
                @l_AuditType,
                i.LST_CHG_USR_ID,
                @l_Datetime,
                d.LST_CHG_TMS,
                i.LST_CHG_TMS,
                'USER_CLS_ID:'+ISNULL(CAST(i.USER_CLS_ID as varchar(30)),CAST(d.USER_CLS_ID as varchar(30)))+'|'+'ACCT_ID:'+ISNULL(CAST(i.ACCT_ID as varchar(30)),CAST(d.ACCT_ID as varchar(30)))+'|'+'BK_ID:'+ISNULL(CAST(i.BK_ID as varchar(30)),CAST(d.BK_ID as varchar(30)))+'|'+'ORG_ID:'+ISNULL(CAST(i.ORG_ID as varchar(30)),CAST(d.ORG_ID as varchar(30))),
                row_number() over (order by i.USER_CLS_ID,i.ACCT_ID,i.BK_ID,i.ORG_ID)
         FROM INSERTED i FULL OUTER JOIN DELETED d ON d.USER_CLS_ID = i.USER_CLS_ID and d.ACCT_ID = i.ACCT_ID and d.BK_ID = i.BK_ID and d.ORG_ID = i.ORG_ID
         Where CASE
                  WHEN i.LST_CHG_TMS <> d.LST_CHG_TMS THEN 1
                  WHEN i.LST_CHG_TMS IS NULL AND d.LST_CHG_TMS IS NOT NULL THEN 1
                  WHEN i.LST_CHG_TMS IS NOT NULL AND d.LST_CHG_TMS IS NULL THEN 1
                  ELSE 0
               END = 1;

         INSERT INTO dbo.Audit_Trail (Structure_Version_Tag, Table_Name, Column_Name, Audit_Type, [User_ID], Audit_Timestamp, Old_Value, New_Value, Primary_Key_Value, Sequence_Num)
         SELECT @l_Tag,
                @l_TableName,
                'LST_CHG_USR_ID',
                @l_AuditType,
                i.LST_CHG_USR_ID,
                @l_Datetime,
                d.LST_CHG_USR_ID,
                i.LST_CHG_USR_ID,
                'USER_CLS_ID:'+ISNULL(CAST(i.USER_CLS_ID as varchar(30)),CAST(d.USER_CLS_ID as varchar(30)))+'|'+'ACCT_ID:'+ISNULL(CAST(i.ACCT_ID as varchar(30)),CAST(d.ACCT_ID as varchar(30)))+'|'+'BK_ID:'+ISNULL(CAST(i.BK_ID as varchar(30)),CAST(d.BK_ID as varchar(30)))+'|'+'ORG_ID:'+ISNULL(CAST(i.ORG_ID as varchar(30)),CAST(d.ORG_ID as varchar(30))),
                row_number() over (order by i.USER_CLS_ID,i.ACCT_ID,i.BK_ID,i.ORG_ID)
         FROM INSERTED i FULL OUTER JOIN DELETED d ON d.USER_CLS_ID = i.USER_CLS_ID and d.ACCT_ID = i.ACCT_ID and d.BK_ID = i.BK_ID and d.ORG_ID = i.ORG_ID
         Where CASE
                  WHEN i.LST_CHG_USR_ID <> d.LST_CHG_USR_ID THEN 1
                  WHEN i.LST_CHG_USR_ID IS NULL AND d.LST_CHG_USR_ID IS NOT NULL THEN 1
                  WHEN i.LST_CHG_USR_ID IS NOT NULL AND d.LST_CHG_USR_ID IS NULL THEN 1
                  ELSE 0
               END = 1;

         INSERT INTO dbo.Audit_Trail (Structure_Version_Tag, Table_Name, Column_Name, Audit_Type, [User_ID], Audit_Timestamp, Old_Value, New_Value, Primary_Key_Value, Sequence_Num)
         SELECT @l_Tag,
                @l_TableName,
                'Create_user_id',
                @l_AuditType,
                i.LST_CHG_USR_ID,
                @l_Datetime,
                d.Create_user_id,
                i.Create_user_id,
                'USER_CLS_ID:'+ISNULL(CAST(i.USER_CLS_ID as varchar(30)),CAST(d.USER_CLS_ID as varchar(30)))+'|'+'ACCT_ID:'+ISNULL(CAST(i.ACCT_ID as varchar(30)),CAST(d.ACCT_ID as varchar(30)))+'|'+'BK_ID:'+ISNULL(CAST(i.BK_ID as varchar(30)),CAST(d.BK_ID as varchar(30)))+'|'+'ORG_ID:'+ISNULL(CAST(i.ORG_ID as varchar(30)),CAST(d.ORG_ID as varchar(30))),
                row_number() over (order by i.USER_CLS_ID,i.ACCT_ID,i.BK_ID,i.ORG_ID)
         FROM INSERTED i FULL OUTER JOIN DELETED d ON d.USER_CLS_ID = i.USER_CLS_ID and d.ACCT_ID = i.ACCT_ID and d.BK_ID = i.BK_ID and d.ORG_ID = i.ORG_ID
         Where CASE
                  WHEN i.Create_user_id <> d.Create_user_id THEN 1
                  WHEN i.Create_user_id IS NULL AND d.Create_user_id IS NOT NULL THEN 1
                  WHEN i.Create_user_id IS NOT NULL AND d.Create_user_id IS NULL THEN 1
                  ELSE 0
               END = 1;

      END;
      ELSE
      BEGIN
         -- Insert action
         -- Audit Type
         Set @l_AuditType = 'INSERT';

         -- If the column has been changed, audit it
         Insert Into dbo.Audit_Trail(Structure_Version_Tag,Table_Name,Column_Name,Audit_Type,[User_ID],Audit_Timestamp,Old_Value,New_Value,Primary_Key_Value,Sequence_Num)
         SELECT @l_Tag,
                @l_TableName,
                'USER_CLS_ID',
                @l_AuditType,
                i.Create_user_id,
                @l_Datetime,
                NULL,
                i.USER_CLS_ID,
                'USER_CLS_ID:'+cast(i.USER_CLS_ID as varchar(30))+'|'+'ACCT_ID:'+cast(i.ACCT_ID as varchar(30))+'|'+'BK_ID:'+cast(i.BK_ID as varchar(30))+'|'+'ORG_ID:'+cast(i.ORG_ID as varchar(30)),
                row_number() over (order by i.USER_CLS_ID,i.ACCT_ID,i.BK_ID,i.ORG_ID)
         FROM inserted i;

         Insert Into dbo.Audit_Trail(Structure_Version_Tag,Table_Name,Column_Name,Audit_Type,[User_ID],Audit_Timestamp,Old_Value,New_Value,Primary_Key_Value,Sequence_Num)
         SELECT @l_Tag,
                @l_TableName,
                'ACCT_ID',
                @l_AuditType,
                i.Create_user_id,
                @l_Datetime,
                NULL,
                i.ACCT_ID,
                'USER_CLS_ID:'+cast(i.USER_CLS_ID as varchar(30))+'|'+'ACCT_ID:'+cast(i.ACCT_ID as varchar(30))+'|'+'BK_ID:'+cast(i.BK_ID as varchar(30))+'|'+'ORG_ID:'+cast(i.ORG_ID as varchar(30)),
                row_number() over (order by i.USER_CLS_ID,i.ACCT_ID,i.BK_ID,i.ORG_ID)
         FROM inserted i;

         Insert Into dbo.Audit_Trail(Structure_Version_Tag,Table_Name,Column_Name,Audit_Type,[User_ID],Audit_Timestamp,Old_Value,New_Value,Primary_Key_Value,Sequence_Num)
         SELECT @l_Tag,
                @l_TableName,
                'BK_ID',
                @l_AuditType,
                i.Create_user_id,
                @l_Datetime,
                NULL,
                i.BK_ID,
                'USER_CLS_ID:'+cast(i.USER_CLS_ID as varchar(30))+'|'+'ACCT_ID:'+cast(i.ACCT_ID as varchar(30))+'|'+'BK_ID:'+cast(i.BK_ID as varchar(30))+'|'+'ORG_ID:'+cast(i.ORG_ID as varchar(30)),
                row_number() over (order by i.USER_CLS_ID,i.ACCT_ID,i.BK_ID,i.ORG_ID)
         FROM inserted i;

         Insert Into dbo.Audit_Trail(Structure_Version_Tag,Table_Name,Column_Name,Audit_Type,[User_ID],Audit_Timestamp,Old_Value,New_Value,Primary_Key_Value,Sequence_Num)
         SELECT @l_Tag,
                @l_TableName,
                'ORG_ID',
                @l_AuditType,
                i.Create_user_id,
                @l_Datetime,
                NULL,
                i.ORG_ID,
                'USER_CLS_ID:'+cast(i.USER_CLS_ID as varchar(30))+'|'+'ACCT_ID:'+cast(i.ACCT_ID as varchar(30))+'|'+'BK_ID:'+cast(i.BK_ID as varchar(30))+'|'+'ORG_ID:'+cast(i.ORG_ID as varchar(30)),
                row_number() over (order by i.USER_CLS_ID,i.ACCT_ID,i.BK_ID,i.ORG_ID)
         FROM inserted i;

         Insert Into dbo.Audit_Trail(Structure_Version_Tag,Table_Name,Column_Name,Audit_Type,[User_ID],Audit_Timestamp,Old_Value,New_Value,Primary_Key_Value,Sequence_Num)
         SELECT @l_Tag,
                @l_TableName,
                'LST_CHG_TMS',
                @l_AuditType,
                i.Create_user_id,
                @l_Datetime,
                NULL,
                i.LST_CHG_TMS,
                'USER_CLS_ID:'+cast(i.USER_CLS_ID as varchar(30))+'|'+'ACCT_ID:'+cast(i.ACCT_ID as varchar(30))+'|'+'BK_ID:'+cast(i.BK_ID as varchar(30))+'|'+'ORG_ID:'+cast(i.ORG_ID as varchar(30)),
                row_number() over (order by i.USER_CLS_ID,i.ACCT_ID,i.BK_ID,i.ORG_ID)
         FROM inserted i;

         Insert Into dbo.Audit_Trail(Structure_Version_Tag,Table_Name,Column_Name,Audit_Type,[User_ID],Audit_Timestamp,Old_Value,New_Value,Primary_Key_Value,Sequence_Num)
         SELECT @l_Tag,
                @l_TableName,
                'LST_CHG_USR_ID',
                @l_AuditType,
                i.Create_user_id,
                @l_Datetime,
                NULL,
                i.LST_CHG_USR_ID,
                'USER_CLS_ID:'+cast(i.USER_CLS_ID as varchar(30))+'|'+'ACCT_ID:'+cast(i.ACCT_ID as varchar(30))+'|'+'BK_ID:'+cast(i.BK_ID as varchar(30))+'|'+'ORG_ID:'+cast(i.ORG_ID as varchar(30)),
                row_number() over (order by i.USER_CLS_ID,i.ACCT_ID,i.BK_ID,i.ORG_ID)
         FROM inserted i;

         Insert Into dbo.Audit_Trail(Structure_Version_Tag,Table_Name,Column_Name,Audit_Type,[User_ID],Audit_Timestamp,Old_Value,New_Value,Primary_Key_Value,Sequence_Num)
         SELECT @l_Tag,
                @l_TableName,
                'Create_user_id',
                @l_AuditType,
                i.Create_user_id,
                @l_Datetime,
                NULL,
                i.Create_user_id,
                'USER_CLS_ID:'+cast(i.USER_CLS_ID as varchar(30))+'|'+'ACCT_ID:'+cast(i.ACCT_ID as varchar(30))+'|'+'BK_ID:'+cast(i.BK_ID as varchar(30))+'|'+'ORG_ID:'+cast(i.ORG_ID as varchar(30)),
                row_number() over (order by i.USER_CLS_ID,i.ACCT_ID,i.BK_ID,i.ORG_ID)
         FROM inserted i;

      END;
   END;
   ELSE
   BEGIN
      -- Delete action
      Set @l_AuditType = 'DELETE';

      -- If the column has been changed, audit it
       Insert Into dbo.Audit_Trail(Structure_Version_Tag,Table_Name,Column_Name,Audit_Type,[User_ID],Audit_Timestamp,Old_Value,New_Value,Primary_Key_Value,Sequence_Num)
       SELECT @l_Tag,
              @l_TableName,
              'USER_CLS_ID',
              @l_AuditType,
              d.Create_user_id,
              @l_Datetime,
              d.USER_CLS_ID,
              NULL,
              'USER_CLS_ID:'+cast(d.USER_CLS_ID as varchar(30))+'|'+'ACCT_ID:'+cast(d.ACCT_ID as varchar(30))+'|'+'BK_ID:'+cast(d.BK_ID as varchar(30))+'|'+'ORG_ID:'+cast(d.ORG_ID as varchar(30)),
              row_number() over (order by d.USER_CLS_ID,d.ACCT_ID,d.BK_ID,d.ORG_ID)
       FROM deleted d;

       Insert Into dbo.Audit_Trail(Structure_Version_Tag,Table_Name,Column_Name,Audit_Type,[User_ID],Audit_Timestamp,Old_Value,New_Value,Primary_Key_Value,Sequence_Num)
       SELECT @l_Tag,
              @l_TableName,
              'ACCT_ID',
              @l_AuditType,
              d.Create_user_id,
              @l_Datetime,
              d.ACCT_ID,
              NULL,
              'USER_CLS_ID:'+cast(d.USER_CLS_ID as varchar(30))+'|'+'ACCT_ID:'+cast(d.ACCT_ID as varchar(30))+'|'+'BK_ID:'+cast(d.BK_ID as varchar(30))+'|'+'ORG_ID:'+cast(d.ORG_ID as varchar(30)),
              row_number() over (order by d.USER_CLS_ID,d.ACCT_ID,d.BK_ID,d.ORG_ID)
       FROM deleted d;

       Insert Into dbo.Audit_Trail(Structure_Version_Tag,Table_Name,Column_Name,Audit_Type,[User_ID],Audit_Timestamp,Old_Value,New_Value,Primary_Key_Value,Sequence_Num)
       SELECT @l_Tag,
              @l_TableName,
              'BK_ID',
              @l_AuditType,
              d.Create_user_id,
              @l_Datetime,
              d.BK_ID,
              NULL,
              'USER_CLS_ID:'+cast(d.USER_CLS_ID as varchar(30))+'|'+'ACCT_ID:'+cast(d.ACCT_ID as varchar(30))+'|'+'BK_ID:'+cast(d.BK_ID as varchar(30))+'|'+'ORG_ID:'+cast(d.ORG_ID as varchar(30)),
              row_number() over (order by d.USER_CLS_ID,d.ACCT_ID,d.BK_ID,d.ORG_ID)
       FROM deleted d;

       Insert Into dbo.Audit_Trail(Structure_Version_Tag,Table_Name,Column_Name,Audit_Type,[User_ID],Audit_Timestamp,Old_Value,New_Value,Primary_Key_Value,Sequence_Num)
       SELECT @l_Tag,
              @l_TableName,
              'ORG_ID',
              @l_AuditType,
              d.Create_user_id,
              @l_Datetime,
              d.ORG_ID,
              NULL,
              'USER_CLS_ID:'+cast(d.USER_CLS_ID as varchar(30))+'|'+'ACCT_ID:'+cast(d.ACCT_ID as varchar(30))+'|'+'BK_ID:'+cast(d.BK_ID as varchar(30))+'|'+'ORG_ID:'+cast(d.ORG_ID as varchar(30)),
              row_number() over (order by d.USER_CLS_ID,d.ACCT_ID,d.BK_ID,d.ORG_ID)
       FROM deleted d;

       Insert Into dbo.Audit_Trail(Structure_Version_Tag,Table_Name,Column_Name,Audit_Type,[User_ID],Audit_Timestamp,Old_Value,New_Value,Primary_Key_Value,Sequence_Num)
       SELECT @l_Tag,
              @l_TableName,
              'LST_CHG_TMS',
              @l_AuditType,
              d.Create_user_id,
              @l_Datetime,
              d.LST_CHG_TMS,
              NULL,
              'USER_CLS_ID:'+cast(d.USER_CLS_ID as varchar(30))+'|'+'ACCT_ID:'+cast(d.ACCT_ID as varchar(30))+'|'+'BK_ID:'+cast(d.BK_ID as varchar(30))+'|'+'ORG_ID:'+cast(d.ORG_ID as varchar(30)),
              row_number() over (order by d.USER_CLS_ID,d.ACCT_ID,d.BK_ID,d.ORG_ID)
       FROM deleted d;

       Insert Into dbo.Audit_Trail(Structure_Version_Tag,Table_Name,Column_Name,Audit_Type,[User_ID],Audit_Timestamp,Old_Value,New_Value,Primary_Key_Value,Sequence_Num)
       SELECT @l_Tag,
              @l_TableName,
              'LST_CHG_USR_ID',
              @l_AuditType,
              d.Create_user_id,
              @l_Datetime,
              d.LST_CHG_USR_ID,
              NULL,
              'USER_CLS_ID:'+cast(d.USER_CLS_ID as varchar(30))+'|'+'ACCT_ID:'+cast(d.ACCT_ID as varchar(30))+'|'+'BK_ID:'+cast(d.BK_ID as varchar(30))+'|'+'ORG_ID:'+cast(d.ORG_ID as varchar(30)),
              row_number() over (order by d.USER_CLS_ID,d.ACCT_ID,d.BK_ID,d.ORG_ID)
       FROM deleted d;

       Insert Into dbo.Audit_Trail(Structure_Version_Tag,Table_Name,Column_Name,Audit_Type,[User_ID],Audit_Timestamp,Old_Value,New_Value,Primary_Key_Value,Sequence_Num)
       SELECT @l_Tag,
              @l_TableName,
              'Create_user_id',
              @l_AuditType,
              d.Create_user_id,
              @l_Datetime,
              d.Create_user_id,
              NULL,
              'USER_CLS_ID:'+cast(d.USER_CLS_ID as varchar(30))+'|'+'ACCT_ID:'+cast(d.ACCT_ID as varchar(30))+'|'+'BK_ID:'+cast(d.BK_ID as varchar(30))+'|'+'ORG_ID:'+cast(d.ORG_ID as varchar(30)),
              row_number() over (order by d.USER_CLS_ID,d.ACCT_ID,d.BK_ID,d.ORG_ID)
       FROM deleted d;

   END;

END;
GO

