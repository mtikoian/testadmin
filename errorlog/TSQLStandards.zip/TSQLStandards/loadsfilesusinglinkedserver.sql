--Required settings for the provider to work correctly as a linked server
EXEC master.dbo.sp_MSset_oledb_prop N'Microsoft.ACE.OLEDB.12.0', N'AllowInProcess', 1 
GO 
EXEC master.dbo.sp_MSset_oledb_prop N'Microsoft.ACE.OLEDB.12.0', N'DynamicParameters', 1 
GO
--#################################################################################################
--Linked server Syntax for Folder Full Of Text Files
--#################################################################################################

--add a folder as a linked server to access all .txt and .csv files in the folder
DECLARE @server     sysname,
        @srvproduct nvarchar(256),
        @provider   nvarchar(256),
        @datasrc    nvarchar(100),
        @location   nvarchar(100),
        @provstr    nvarchar(100),
        @catalog    sysname,
        @sql        varchar(1000)
SET @server = N'TxtSvr'
SET @srvproduct = N'OLE DB Provider for ACE'
SET @provider = N'Microsoft.ACE.OLEDB.12.0'
SET @datasrc = N'C:\Data\'
SET @provstr ='Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Data\;Extended Properties="text;HDR=YES;FMT=Delimited" '
set @provstr  = 'Text'

EXEC  sp_addlinkedserver  @server,@srvproduct,@provider,@datasrc,@provstr,@provstr
GO
--===== Set up login mappings.
EXEC dbo.sp_AddLinkedSrvLogin TxtSvr, FALSE, NULL, Admin, NULL
GO
--===== List the tables in the linked server which is really a list of 
     -- file names in the directory.  Note that the "#" sign in the
     -- Table_Name is where the period in the filename actually goes.
   EXEC dbo.sp_Tables_Ex TxtSvr
GO
--===== Query one of the files by using a four-part name. 
SELECT * 
   FROM TxtSvr...[LegalName_NickName_List#txt]

--===== Drop the text server
   EXEC dbo.sp_DropServer 'TxtSvr', 'DropLogins'
GO