CREATE TABLE #example(myid INT IDENTITY(1,1),
myCalculatedPK AS 'martmp_' + RIGHT('00000000' + CONVERT(VARCHAR,myid),8) persisted PRIMARY KEY,
myotherstuff VARCHAR(30) )

INSERT INTO #EXAMPLE(MYOTHERSTUFF)
SELECT 'APPLES' UNION
SELECT 'BANANAS' UNION
SELECT 'GRAPES'

SELECT * FROM #example

DROP TABLE #example


results:
myid	myCalculatedPK	myotherstuff
1	martmp_00000001	APPLES
2	martmp_00000002	BANANAS
3	martmp_00000003	GRAPES