CREATE FUNCTION dbo.DELIMITED_CSV_SPLIT
(
/*********************************************************************
    Using Jeff Moden's DelimitedSplit8K as a base with the addition
    of a Text Qualifier parameter, @pTxtQualifier CHAR(1) = '"'
 *********************************************************************/
     @pString        VARCHAR(8000) 
    ,@pDelimiter     CHAR(1)       
    ,@pTxtQualifier  CHAR(1)       
) 
RETURNS TABLE WITH SCHEMABINDING AS
 RETURN
/*********************************************************************
    cteTally, inline Tally table returning a number sequence equivalent 
    to the length of the input string. 
 *********************************************************************/
WITH E1(N) AS 
(
  SELECT 1 UNION ALL SELECT 1 UNION ALL SELECT 1 UNION ALL 
  SELECT 1 UNION ALL SELECT 1 UNION ALL SELECT 1 UNION ALL 
  SELECT 1 UNION ALL SELECT 1 UNION ALL SELECT 1 UNION ALL SELECT 1
),                          
E2(N) AS (SELECT 1 FROM E1 a, E1 b), 
E4(N) AS (SELECT 1 FROM E2 a, E2 b), 
cteTally(N) AS 
(
  SELECT 
  ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) 
  FROM E4
  ORDER BY 1 OFFSET 0 ROWS 
  FETCH FIRST CAST(LEN(@pString) AS BIGINT) ROWS ONLY
)
/********************************************************************
   Retrieve the position (N) and the character code (chrCode) 
   for all delimiters (@pDelimiter) and text qualifiers 
   (@pTxtQualifier)
********************************************************************/
,ctePrimer(N,chrCode) AS 
(
  SELECT 
     t.N 
    ,UNICODE(SUBSTRING(@pString,t.N,1))  AS chrCode
  FROM cteTally t 
  WHERE SUBSTRING(@pString,t.N,1) COLLATE Latin1_General_BIN 
                 = @pDelimiter    COLLATE Latin1_General_BIN
  OR    SUBSTRING(@pString,t.N,1) COLLATE Latin1_General_BIN 
                 = @pTxtQualifier COLLATE Latin1_General_BIN
)
/********************************************************************
   The cteStart encloses the string in virtual delimiters using 
   Union All at the beginning and the end. The main body sets the 
   IsDelim and IsTxQf flags. 
********************************************************************/
,cteStart(N,IsDelim,IsTQA) AS 
(
  SELECT 
     0                   AS N
    ,1                   AS IsDelim
    ,0                   AS IsTxQf
UNION ALL 
  SELECT 
     t.N 
    ,(1 - SIGN(ABS(t.chrCode - UNICODE(@pDelimiter))))    AS IsDelim
    ,(1 - SIGN(ABS(t.chrCode - UNICODE(@pTxtQualifier)))) AS IsTxQf
  FROM ctePrimer t 
UNION ALL
  SELECT                  
     LEN(@pString) + 1   AS N
    ,1                   AS IsDelim
    ,0                   AS IsTxQf
)
/********************************************************************
   cteWorkSet:
   Position (N), Delimiter flag (IsDelim), Text Qualifier flag
   (IsTQA) and the running total of the number of appearances of 
   Text Qualifiers. The delimiters which are inside Text Qualifiers
   are cancelled out by multiplying the IsDelim flag with the result
   of ( 1 + the running total of IsTQA ) mod 2.
********************************************************************/
,cteWorkSet(N,IsDelim,IsTQA) AS 
(
  SELECT
      cST.N
     ,cST.IsDelim * ((1+ SUM(cST.IsTQA)  OVER 
      (PARTITION BY (SELECT NULL) ORDER BY cST.N 
      ROWS UNBOUNDED PRECEDING)) % 2)                   AS IsDelim
     ,((SUM(cST.IsTQA)  OVER (PARTITION BY (SELECT NULL) 
      ORDER BY cST.N ROWS UNBOUNDED PRECEDING)) % 2)    AS IsTQA
  FROM cteStart  cST
),
/********************************************************************
   cteWSTQ:
   Using LEAD and LAG to retrieve the offsets for the Text Qualifiers
   and filtering the results by IsDelim = 1 or IsTQA = 1. The set now
   holds all the information needed for correctly splitting the text.
********************************************************************/
cteWSTQ(P_START,IsDelim,NEXT_IsTQA,LAG_IsTQA) AS
(
  SELECT 
    cWS.N                                      AS P_START
    ,cWS.IsDelim                               AS IsDelim
    ,LEAD(cWS.IsTQA,1,0) OVER (ORDER BY cWS.N) AS NEXT_IsTQA
    ,LAG(cWS.IsTQA,1,0) OVER (ORDER BY cWS.N)  AS LAG_IsTQA
  FROM  cteWorkSet    cWS 
  WHERE cWS.IsDelim = 1
  OR    cWS.IsTQA   = 1
)
/********************************************************************
   cteWSLEN:
   Calculate the start and the length of each field
********************************************************************/
,cteWSLEN(P_START,P_LEN) AS
(
  SELECT 
     (X.P_START + X.NEXT_IsTQA + SIGN(X.P_START))       AS P_START
    ,(LEAD(X.P_START,1,0) OVER (ORDER BY X.P_START) - 
	 ((X.P_START + X.NEXT_IsTQA)  + SIGN(X.P_START) + 
	 LEAD(X.LAG_IsTQA,1,0) OVER (ORDER BY X.P_START)))  AS P_LEN
  FROM cteWSTQ X WHERE X.IsDelim = 1
)
/********************************************************************
   Splitting the string using the output of the cteWSLEN, filtering
   it by the length being non-negative value. The NULLIF returns NULL
   if the field is empty.
********************************************************************/

SELECT
   ROW_NUMBER() OVER (ORDER BY (SELECT NULL))           AS ItemNumber
  ,NULLIF(REPLACE(SUBSTRING(@pString,cWL.P_START,cWL.P_LEN),@pTxtQualifier+@pTxtQualifier,@pTxtQualifier),'') AS Item
FROM cteWSLEN    cWL
WHERE cWL.P_LEN > -1

GO
