Imports System.Data.SqlClient 
Imports System.Data.SqlTypes 
Imports Microsoft.SqlServer.Server 
Imports System.IO 

Namespace Enterprise.SqlServer.Server 
    Public Partial Class GetFileDetails 
        <Microsoft.SqlServer.Server.SqlProcedure()> _ 
        Public Shared Sub csp_getfiledetails(ByVal filePath As String) 
            Try 
                Dim fileProperties As New FileInfo(filePath) 
                
                Dim colAlternateName As New SqlMetaData("Alternate Name", SqlDbType.NVarChar, 4000) 
                Dim colSize As New SqlMetaData("Size", SqlDbType.BigInt) 
                Dim colCreationDate As New SqlMetaData("Creation Date", SqlDbType.NChar, 8) 
                Dim colCreationTime As New SqlMetaData("Creation Time", SqlDbType.NChar, 6) 
                Dim colLastWrittenDate As New SqlMetaData("Last Written Date", SqlDbType.NChar, 8) 
                Dim colLastWrittenTime As New SqlMetaData("Last Written Time", SqlDbType.NChar, 6) 
                Dim colLastAccessedDate As New SqlMetaData("Last Accessed Date", SqlDbType.NChar, 8) 
                Dim colLastAccessedTime As New SqlMetaData("Last Accessed Time", SqlDbType.NChar, 6) 
                Dim colAttributes As New SqlMetaData("Attributes", SqlDbType.Int) 
                
                Dim record As New SqlDataRecord(New SqlMetaData() {colAlternateName, colSize, colCreationDate, colCreationTime, colLastWrittenDate, colLastWrittenTime, _ 
                colLastAccessedDate, colLastAccessedTime, colAttributes}) 
                
                record.SetInt64(1, fileProperties.Length) 
                record.SetString(2, fileProperties.CreationTime.ToString("yyyyMMdd")) 
                record.SetString(3, fileProperties.CreationTime.ToString("HHmmss")) 
                record.SetString(4, fileProperties.LastWriteTime.ToString("yyyyMMdd")) 
                record.SetString(5, fileProperties.LastWriteTime.ToString("HHmmss")) 
                record.SetString(6, fileProperties.LastAccessTime.ToString("yyyyMMdd")) 
                record.SetString(7, fileProperties.LastAccessTime.ToString("HHmmss")) 
                
                Dim splitter As Char() = {","c} 
                Dim attributes As String() = fileProperties.Attributes.ToString().Split(splitter) 
                Dim attributesInt__1 As Integer = 0 
                
                For Each attributesString As String In attributes 
                    Dim fileAttributes As FileAttributes = DirectCast([Enum].Parse(GetType(FileAttributes), attributesString), FileAttributes) 
                    attributesint += CInt(fileAttributes) 
                Next 
                
                record.SetInt32(8, attributesInt__1) 
                
                record.SetInt32(8, CInt(fileProperties.Attributes)) 
                
                SqlContext.Pipe.Send(record) 
            Catch myexception As Exception 
                Throw (myexception) 
            End Try 
        End Sub 
    End Class 
End Namespace 