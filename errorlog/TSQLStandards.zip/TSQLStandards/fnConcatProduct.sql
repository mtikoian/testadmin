CREATE FUNCTION dbo.fnConcatProduct
        (@BuyerName VARCHAR(50),@BuyerAddress VARCHAR(50))
RETURNS VARCHAR(8000)
     AS 
  BEGIN
        --===== Declare local variables
        DECLARE @Return VARCHAR(8000)

        --===== Find and concatenate all the products for this buyer
         SELECT @Return = ISNULL(@Return+',','')
                        + CAST(ProductNumber AS VARCHAR(10))+','
                        + ProductDescription
           FROM yourview
          WHERE BuyerName    = @BuyerName
            AND BuyerAddress = @BuyerAddress
          ORDER BY ProductNumber 
        
         RETURN @Return
    END