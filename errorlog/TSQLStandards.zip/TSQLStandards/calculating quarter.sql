DECLARE @StartFY DATETIME,
        @EndFY DATETIME
;
 SELECT @StartFY = '2012',
        @EndFY   = '2013'
;
 SELECT QtrStartDate     = DATEADD(qq,t.N+1,@StartFY),
	NextQtrStartDate = DATEADD(qq,t.N+2,@StartFY),
	Qtr = t.N%4+1
   FROM dbo.Tally t
  WHERE t.N BETWEEN 0 AND (DATEDIFF(yy,@StartFY,@EndFY)+1)*4-1
  ORDER BY t.N
;
