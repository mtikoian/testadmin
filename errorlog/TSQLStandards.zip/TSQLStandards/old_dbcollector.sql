--create script om nagios tabel en user aan te maken 
--create admin user - admin password
--create database nagios

GO
/****** Object:  Database [nagios] **/
CREATE DATABASE [nagios];

CREATE LOGIN [admin] WITH PASSWORD=N'admin', DEFAULT_DATABASE=[master];
EXEC sys.sp_addsrvrolemember @loginame = N'admin', @rolename = N'sysadmin'
--aanmaken nagios user
CREATE LOGIN [nagios] WITH PASSWORD=N'nagios', DEFAULT_DATABASE=[nagios] ;
GRANT select, EXECute on nagios to nagios;
GO
begin transaction;
--create --objects nagios
--+usermappings + ....
IF NOT EXISTS (SELECT * FROM sys.database_principals WHERE name = N'admin')
CREATE USER [admin] FOR LOGIN [admin] WITH DEFAULT_SCHEMA=[dbo]
IF NOT EXISTS (SELECT * FROM sys.database_principals WHERE name = N'nagios')
CREATE USER [nagios] FOR LOGIN [nagios] WITH DEFAULT_SCHEMA=[dbo]

IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = N'nagios')
EXEC sys.sp_executesql N'CREATE SCHEMA [nagios] AUTHORIZATION [admin]'

commit

Use [nagios];
go
-----------------------------------------------------------------
---Begin transaction - aanmaken nagios tabel.--------
------------------------------------------------------------------
 begin transaction;
GO
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[nagios].[check_limits]') AND type in (N'U'))
BEGIN
CREATE TABLE [nagios].[check_limits](
	[max_wrong_logins] [int] NOT NULL DEFAULT ((5)),
	[max_days_between_backups] [int] NOT NULL DEFAULT ((1)),
	[min_uptime_minutes] [int] NOT NULL DEFAULT ((10)),
	[max_connections] [int] NOT NULL CONSTRAINT [DF_check_limits_max_connections]  DEFAULT ((15)),
	[max_days_between_backups_limit2] [int] NOT NULL CONSTRAINT [DF_check_limits_max_days_between_backup_limit2]  DEFAULT ((5))
) ON [PRIMARY]
END
commit;
GO
-----------------------------------
----aanmaken functies ------
-----------------------------------
begin transaction;
use [nagios];
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[nagios].[fix]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE function [nagios].[fix](@num float, @digits int) returns float as
begin
    declare @res float
    select @res = case when @num = 0 then 0 else round(@num,@digits-1-floor(log10(abs(@num)))) end
    return (@res)
end
' 
END
commit;
go
-----------------------------------------------------
----aanmaken van de stored procedures.---
-----------------------------------------------------
Begin transaction;
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[nagios].[SHOW_NONCRITICAL_FAILED_JOBS]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Steve Vos
-- Create date: 16 mei 2008
-- Description:	Dit script toont alle NIET critical failed jobs (die niet zijn opgenomen in tabel critical_jobs) 
-- Als parameter wordt het aantal dagen gegeven waarover gekeken moet worden. 
-- Dit script dient als debug script voor de helpdesk !
-- =============================================
CREATE PROCEDURE [nagios].[SHOW_NONCRITICAL_FAILED_JOBS] @dagen int
AS
BEGIN
	select  qry1.job_id,qry1.message,qry1.run_date,qry1.run_time, qry2.name, qry2.description,
case qry1.run_status WHEN 1 THEN 
		''Succeeded''
	else 
		case qry1.run_status WHEN 2 THEN 
		''Retry'' 
		else
		  case qry1.run_status WHEN 3 then
		  ''Canceled''
		  else
			case qry1.run_status WHEN 4 then
			''In progress''
			else
			 case qry1.run_status WHEN 0 then
			 ''Failed''
			 end
			end
		  end
		end
	end
	as ''Job Outcome''
	from
	msdb..sysjobhistory 	qry1 join	msdb..sysjobs		qry2
	on qry1.job_id = qry2.job_id
	where qry1.run_status != 1
	and	qry1.step_id != 0
	and	run_date >=  CONVERT(char(8), (select dateadd (day,(-1*@dagen), getdate())),112)
	AND (qry1.job_id not in (select job_id from nagios.nagios.critical_jobs))
	order by qry1.run_date DESC
END
' 
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[nagios].[SHOW_CRITICAL_FAILED_JOBS]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Steve Vos
-- Create date: 16 mei 2008
-- Description:	Dit script toont alle critical jobs (die zijn opgenomen in tabel critical_jobs) 
-- Als parameter wordt het aantal dagen gegeven waarover gekeken moet worden. 
-- Dit script dient als debug script voor de helpdesk !
-- =============================================
CREATE PROCEDURE [nagios].[SHOW_CRITICAL_FAILED_JOBS] @dagen int
AS
BEGIN
	select  qry1.job_id,qry1.message,qry1.run_date,qry1.run_time, qry2.name, qry2.description,
case qry1.run_status WHEN 1 THEN 
		''Succeeded''
	else 
		case qry1.run_status WHEN 2 THEN 
		''Retry'' 
		else
		  case qry1.run_status WHEN 3 then
		  ''Canceled''
		  else
			case qry1.run_status WHEN 4 then
			''In progress''
			else
			 case qry1.run_status WHEN 0 then
			 ''Failed''
			 end
			end
		  end
		end
	end
	as ''Job Outcome''
	from
	msdb..sysjobhistory 	qry1 join	msdb..sysjobs		qry2
	on qry1.job_id = qry2.job_id
	where qry1.run_status != 1
	and	qry1.step_id != 0
	and	run_date >=  CONVERT(char(8), (select dateadd (day,(-1*@dagen), getdate())),112)
	AND (qry1.job_id in (select job_id from nagios.nagios.critical_jobs))
	order by qry1.run_date DESC
END
' 
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[nagios].[NAGIOSINPUT]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [nagios].[NAGIOSINPUT] @nagioserrnumb int,@nagiosoutput varchar(8000)  
AS
	 --print convert(char(255),@nagiosoutput)+''''
     --print ''errnumber::''+convert(char(1),@nagioserrnumb)+''''
	print convert(char(1),@nagioserrnumb)
	print convert(char(8000),@nagiosoutput)
     


' 
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[nagios].[CHECK_DATABASE_EXISTS]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'
-- =============================================
-- Author:		Steve Vos
-- Create date: 21/04/2008
-- Description: Procedure die controleert of de databank bestaat, gebruik deze stred om op te roepen in andere streds
-- =============================================
CREATE PROCEDURE [nagios].[CHECK_DATABASE_EXISTS] @dbname varchar(255)
AS
  if EXISTS(select * FROM master..sysdatabases where [name] like @dbname)
   begin
      	   RETURN 1  
  end
  else
	   RETURN 0


' 
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[nagios].[critical_jobs]') AND type in (N'U'))
BEGIN
CREATE TABLE [nagios].[critical_jobs](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[job_id] [varchar](50) NOT NULL,
	[last_failed] [datetime] NOT NULL CONSTRAINT [DF_critical_jobs_last_failed]  DEFAULT ('01/01/1900 00:00:00')
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[nagios].[show_login_errors]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'
-- =============================================
-- Author:		Steve Vos
-- Create date: 19 mei 2008
-- Description:	Script dat het aantal failed login controleert de afgelopen x dagen (0 = vandaag)
-- =============================================
CREATE PROCEDURE [nagios].[show_login_errors]
	
AS
BEGIN
	create table #errors (logDate datetime,processInfo varchar(255),Expl text)
	insert #errors exec xp_readerrorlog
	select LogDate as "Date", Expl as "Message" from #errors WHERE Expl like ''%login failed%'' and logDate > CONVERT(char(8), (select dateadd (day,(-1*1), getdate())),112)

	drop table #errors
END


' 
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[nagios].[CHECK_DATA_SIZE]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Steve Vos
-- Create date: 06/05/2008
-- Description:	Dit script controleert de groote van de datafiles van een bepaalde databank, als deze > 50 % && < 80% --> WARNING 
-- > 80% --> CRITICAL
-- =============================================
CREATE PROCEDURE [nagios].[CHECK_DATA_SIZE] @dbname varchar(255)
AS
BEGIN
    declare @ber float
	declare @dbexists int	
	declare @used float	
	declare @max_size float
	declare @db_id int
	declare @output varchar(255)

   exec @dbexists =  nagios.CHECK_DATABASE_EXISTS @dbname 
   if (@dbexists=1)
	   BEGIN
		
		 select @db_id = (select database_id from sys.databases where name = @dbname)
		 select @used = (select sum(size) from sys.master_files where database_id=@db_id AND (physical_name like ''%.mdf'' OR physical_name like ''%.ndf''))
		 select @max_size = (select min(max_size) from sys.master_files where database_id=@db_id AND (physical_name like ''%.mdf'' or physical_name like ''%.ndf''))
			
		
     		SET @used = (@used*8)/1024  -- Het getal dat we uitkomen is uitgedrukt in 8KB pages om dit om te zetten naar MB eerst *8 dan /1024
			
			if(@max_size<0)  -- Als de max size == -1 dan betekent dit unlimited ....
            begin
				set @output = ''UNLIMITED DATA FILE SIZE ; PLEASE CHECK FREE DISK SPACE !|Size = '' + convert(char(6),@used)+ '' MB''
				exec nagios.NAGIOSINPUT 1,@output
			end
			else
			begin				
				select @max_size = (select sum(max_size) from sys.master_files where database_id=@db_id AND ( physical_name like ''%.mdf'' or physical_name like ''%.ndf''))
				SET @max_size = (CAST(@max_size AS FLOAT)*8)/1024  -- Het getal dat we uitkomen is uitgedrukt in 8KB pages om dit om te zetten naar MB eerst *8 dan /1024
								
				set @ber = (CAST(@used AS FLOAT)/CAST(@max_size AS FLOAT))*100
			
				if((@ber > 70) AND (@ber < 90))
				begin
					set @output = ''Usage exceeds 50%!\nSize = '' + convert(char(6),nagios.fix(@used,2)) + ''MB|Used= '' + convert(char(6),nagios.nagios.fix(@used,2))+ '' MB''
					exec nagios.NAGIOSINPUT 1,@output
				end
				else
				begin
					if(@ber > 90)
					begin
					   set @output = ''Usage exceeds 80%!\nSpace used = '' + convert(char(5),nagios.fix(@used,2)) + '' MB|Used = '' + convert(char(6),nagios.nagios.fix(@used,2)) + '' MB''
					   exec nagios.NAGIOSINPUT 2,@output
					end
					else
					begin						
						set @output = ''OK\nSpace used = ''+ convert(char(6),nagios.fix(@used,2))+'' MB|Used = '' + convert(char(6),nagios.fix(@used,2)) + '' MB''
						
						exec nagios.NAGIOSINPUT 0,@output
					end
				end
			end
		   
	END
   ELSE
	   BEGIN
			 exec nagios.NAGIOSINPUT 1,''DATABASE DOES NOT EXIST !''
	   END
END






' 
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[nagios].[CHECK_FAILED_LOGINS]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'
CREATE PROCEDURE [nagios].[CHECK_FAILED_LOGINS]
AS
declare @errors int
declare @limit int
declare @output varchar(255)
declare @auditlevel varchar(20)

--Controleren of het audit level wel goed staat ---
CREATE TABLE nagios.#xp_loginconfig
(
[Name] varchar(50) PRIMARY KEY,
config_value varchar(100) NULL
)
INSERT INTO nagios.#xp_loginconfig --temp tabel vullen met output van xp_loginconfig
EXEC master..xp_loginconfig ''audit level''

SELECT @auditlevel=(select config_value FROM  nagios.#xp_loginconfig WHERE Name=''audit level'')

if((@auditlevel=''all'')OR(@auditlevel=''failure''))
begin
		select @limit =(select max_wrong_logins from nagios.nagios.check_limits)

		create table #errors (logDate datetime,processInfo varchar(255),Expl text)
		insert #errors exec xp_readerrorlog
		select @errors=(select count(*) from #errors where Expl like ''login failed%'' and ((logdate > getdate()-1) and (logdate <= getdate())))

		drop table #errors

		--print ''aantal foutieve logons --> ''+convert(char(2),@errors)

		SET @output =''There are ''+convert(char(3),@errors)+'' login errors\n Please run exec show_login_errors  to see which logons are failed''

		if @errors > @limit
		   begin
			   
			   exec nagios.NAGIOSINPUT 1, @output
		   end
		else
			begin
				exec nagios.NAGIOSINPUT 0, @output
			end

end
else
begin
	set @output = ''Audit level correctly set! \n Please set to ALL or FAILURE to use this plugin !\n Currently: ''+@auditlevel
	exec nagios.nagiosinput 1,@output
end

' 
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[nagios].[CHECK_NONCRITICAL_FAILED_JOBS]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Steve Vos
-- Create date: 17/04/2008
-- Description:	Controleert het aantal failed jobs de afgelopen 24 uur, die niet critical zijn (die dus niet in de tabel critical_jobs staan !
-- =============================================
CREATE PROCEDURE [nagios].[CHECK_NONCRITICAL_FAILED_JOBS]
AS
SET NOCOUNT ON


declare @failed_jobs int
declare @output varchar(255)




select @failed_jobs = (select 	count(*) from
	msdb..sysjobhistory 	qry1 join	msdb..sysjobs		qry2
	on qry1.job_id = qry2.job_id
	where qry1.run_status != 1
	and	qry1.step_id != 0
	and	run_date >=  CONVERT(char(8), (select dateadd (day,(-1*1), getdate())),112)
	and qry1.job_id not in (select job_id from nagios.nagios.critical_jobs))

	if(@failed_jobs!=0)
	begin
	  set @output=''There are ''+convert(char(3),@failed_jobs)+'' non critical failed jobs the last 24 hours\n Please run the stored procedure show_noncritical_failed_jobs to see which jobs are failed!''
      exec nagios.NAGIOSINPUT 1,@output
    end
    else
    begin
		set @output=''OK, there are no non critical failed jobs the last 24 hours''
		exec nagios.NAGIOSINPUT 0,@output
    end
		
		


 



' 
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[nagios].[CHECK_CRITICAL_FAILED_JOBS]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Steve Vos
-- Create date: 16 mei 2008
-- Description:	stored procedure die controleert of er jobs die critical zijn en failed zijn, deze critical jobs zijn gedefinieerd in de tabel critical_jobs
-- =============================================
CREATE PROCEDURE [nagios].[CHECK_CRITICAL_FAILED_JOBS] AS
BEGIN
	
	declare @job_id varchar(255)
	declare @instance_id int
	declare @last_failed datetime
	declare @temp datetime
	declare @output varchar(255)
	declare @jobdesc varchar(255)
	declare @failedjobs int
	
	declare	MyC cursor for (select msdb.job_id,msdb.instance_id
				from msdb..sysjobhistory msdb
				WHERE (msdb.job_id in (select job_id FROM nagios.nagios.critical_jobs) and msdb.run_status!=1 and msdb.step_id!=0))
	Set @output = ''There are failed jobs !\n''	
	set @failedjobs = 0
					
	open MyC
	fetch next from MyC into @job_id,@instance_id
	while @@fetch_status >= 0
	begin
		
		set @temp = (select convert(datetime, run_date + '' '' +   --De datum en tijd van de tabel die opgeslagen zit in een INT
		substring(run_time, 2, 2) + '':'' +					     -- omzetten naar een datetime variabele
		substring(run_time, 4, 2) + '':'' +
		substring(run_time, 6, 2))
		from (select run_date = ltrim(str(run_date)),
		run_time = ltrim(str(1000000 + run_time))
		from msdb..sysjobhistory where instance_id=@instance_id) AS s)
		
		select @last_failed = (select last_failed FROM nagios.nagios.critical_jobs WHERE job_id=@job_id) -- in de tabel critical_jobs kijken wanneer deze job het laatst faalde, als dit hetzelfde is als vorige keer => geen probleem
	
		if(@temp > @last_failed)  --> Als de tijd wanneer dit gefaald is groter is dan in de tabel actie ondernemen
		begin
			set @failedjobs = @failedjobs+1 -- Teller verhogen
			select @jobdesc= (select name from msdb..sysjobs where job_id=@job_id)
			set @output = @output +''- ''+ convert(varchar,@jobdesc) +'' Failed  at ''+convert(varchar,@temp)+''\n''  -- Er zijn failed jobs
			UPDATE critical_jobs SET last_failed = @temp WHERE job_id = @job_id -- De last_failed tijd updaten bij de tabel critical jobs
			
		end
		
		fetch next from MyC into @job_id,@instance_id
	end
	close MyC
	deallocate MyC	
	if(@failedjobs=0)
	begin
		exec nagios.nagios.nagiosinput 0,''There are no new critical failed jobs since the last check time''  --Er zijn geen failed jobs
	end
	else
	begin
		exec nagios.nagios.nagiosinput 2,@output
	end
END



' 
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[nagios].[CHECK_LAST_BACKUP]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'
CREATE PROCEDURE [nagios].[CHECK_LAST_BACKUP] @dbname varchar(255)
AS
  declare @lastbackup varchar(10)
  declare @limit int
  declare @limit2 int
  declare @aantalbackups int
  declare @test int
  declare @output varchar(255)

  exec @test =  nagios.CHECK_DATABASE_EXISTS @dbname 
  if(@test = 0)
  begin
           exec nagios.NAGIOSINPUT 1,''Database does not exists!''       
  end
  else
  begin

	  select @limit = (select max_days_between_backups FROM nagios.nagios.check_limits)
	  select @limit2 = (select max_days_between_backups_limit2 FROM nagios.nagios.check_limits)
	  select @aantalbackups = (select count(*) from msdb.dbo.backupset WHERE database_name=@dbname)

	  if(@aantalbackups=0)		
	  begin
		set @output='' The database has never been backuped.''
		 exec nagios.NAGIOSINPUT 2, @output
	  end
	  else
	  begin
		  select @lastbackup = (select abs(datediff(day,getDate(),max(A.backup_finish_date)))	FROM msdb.dbo.backupset A JOIN master.dbo.sysdatabases B ON A.database_name=B.name
			WHERE A.database_name like @dbname GROUP BY A.database_name)

		set @output=''Last Backup ''+ convert(varchar(255),@dbname)+'', ''+convert(varchar(20),@lastbackup)+'' days ago.''

		if((@lastbackup >= @limit)AND(@lastbackup < @limit2) )
		BEGIN
			exec nagios.NAGIOSINPUT 1, @output
		END
		else
		BEGIN
		   if(@lastbackup >= @limit2)
		   begin
				exec nagios.NAGIOSINPUT 2,@output
		   end
		   else
		   begin
				 exec nagios.NAGIOSINPUT 0,@output
		   end
		  
		END
	end
end


' 
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[nagios].[CHECK_DATABASE_STATUS]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'

-- =============================================
-- Author:		Steve Vos
-- Create date: 07/05/2008
-- Description:	Dit script controleert de status van de verschillende databases (offline mode - recovering mode - not recovered mode - dbo use only mode - single user mode - emergency mode )
-- =============================================
CREATE PROCEDURE [nagios].[CHECK_DATABASE_STATUS] 
AS
BEGIN
	create table #temp (dbname varchar(255),messagenr int) --temp table maken 
	insert #temp select name,status from master..sysdatabases     --temp table vullen met de status van elke tabel

	declare lus cursor for select * from #temp
	declare @dbname varchar(255), @messagenr int
	declare @output varchar(8000)
	declare @temp varchar(1000)
	declare @aantal int
	
		open lus
		fetch next from lus into @dbname,@messagenr		
	    
		set @output =''The following databases are not in ONLINE modus: \n''
		set @aantal = 0
		while @@fetch_status >= 0
		  begin
				set @temp = ''''
				set @temp = @temp + ''\nDATABASE ''+@dbname +'' STATUS:\n''
				if(@messagenr & 512 <> 0) BEGIN SET @temp = @temp + ''offline mode - '' SET @aantal = @aantal +1 END 
				if(@messagenr & 128 <> 0) BEGIN SET @temp = @temp + ''recovering mode - '' SET @aantal = @aantal +1 END
				if(@messagenr & 256 <> 0) BEGIN SET @temp = @temp + ''not recovered - '' SET @aantal = @aantal +1 END
				if(@messagenr & 2048 <> 0) BEGIN SET @temp = @temp + ''DBO use only mode - '' SET @aantal = @aantal +1 END
				if(@messagenr & 4096 <> 0) BEGIN SET @temp = @temp + ''Single user mode - '' SET @aantal = @aantal +1 END
				if(@messagenr & 32768 <> 0) BEGIN SET @temp = @temp + ''emergency mode - '' SET @aantal = @aantal +1 END			
				
				if(@temp <> ''\nDATABASE ''+@dbname +'' STATUS:\n'')
				begin
					set @output = @output + @temp
					set @output = @output + ''\n-----------------------------------------------\n''
				end
			fetch next from lus into @dbname,@messagenr
		  end
		  if @aantal = 0
		  begin
				exec nagios.NAGIOSINPUT 0, ''All databases are in production !''
		  end
		  else
		  begin
			    exec nagios.NAGIOSINPUT 1, @output
		  end
		 
	--select * from #temp			
	drop table #temp --temp table droppen
END

' 
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[nagios].[CHECK_WEAK_PASSWORDS]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'
-- =============================================
-- Author:		Herman Maes
-- Aangepast door: Steve Vos
-- Aanpgepast op:  07/05/2008
-- Description:	Script dat controleert of er weak passwords (psw = null, psw = username, psw = onechar, psw = reverse (username)
-- =============================================
CREATE PROCEDURE [nagios].[CHECK_WEAK_PASSWORDS] 
AS
BEGIN
	
	create table #name (
			[name]		sysname not null,
			[weak]		bit null,
			[null]		bit null,
			[same]		bit null,
			[reverse]	bit null,
			[onechar]	bit null )
	insert into #name ([name],[weak],[null],[same],[reverse],[onechar] )
	select	[name],0,0,0,0,0 from master.dbo.syslogins where isntname = 0  --isntname = 0 --> enkel de logins selecteren die sqlserver2005 logins zijn

	update n                                         -- Alle accounts de als psw NULL Hebben aanduiden
	set [weak] = 1,[null] = 1
	from	#name n, master.dbo.syslogins sl
	where	n.[name] = sl.[name] and sl.[password] is null

	update	n                                         -- Alle accounts waar username = password selecteren
	set	[weak] = 1,[same] = 1
	from	#name n,master.dbo.syslogins sl
	where	n.[name] = sl.[name] and pwdcompare(sl.[name], sl.[password]) = 1

	update	n										-- Alle accounts waar het paswoord = omgekeerde username
	set	[weak] = 1,[reverse] = 1
	from	#name n,master.dbo.syslogins sl
	where	n.[name] = sl.[name] and pwdcompare(reverse(sl.[name]), sl.[password]) = 1

	declare	@char int, @name sysname				-- Alle accounts waar het password maar 1 char is 
	select	@char = 0
	declare	MyC cursor for select [name] from #name order by [name]
	open MyC
	fetch next from MyC into @name
	while @@fetch_status >= 0
		begin
		while (@char < 256)
			begin
			if ( select pwdcompare(char(@char), [password]) from master.dbo.syslogins where name = @name )=1
				begin
				update	#name
				set	[weak] = 1,[onechar] = 1
				where	[name] = @name
				end
			select	@char = @char + 1
			end
		select @char = 0
		fetch next from MyC into @name
		end
	close MyC
	deallocate MyC
--Aanpassingen doorgevoerd door Steve Vos--
--Eerst controleren hoeveel weak passwords er zijn (mbhv count)--
declare @aantal int

select @aantal=(select count(*) from #name where weak = 1)
if(@aantal = 0)
begin
	
	exec nagios.NAGIOSINPUT 0,''No weak passwords found !''
end
else
begin
		
		--Met een cursor over de tabel #name lopen--
		declare @output varchar(8000)   --Deze var bevat alle output
		declare lus cursor for select * from #name where weak = 1 -- alleen waar weak = 1 !
		declare @naam sysname, @same bit,@weak bit, @null bit, @reverse bit,@onechar bit
		set @output = ''Weak passwords found ! \n''
		open lus
		fetch next from lus into @naam,@weak,@null,@same,@reverse,@onechar
		while @@fetch_status >= 0
		  begin
			
			set @output = @output+@naam+'' >> \n''
			
			if(@same=1) begin set @output = @output+''Password is the same as the username\n'' end
			if(@null=1) begin set @output = @output+''Password is null\n'' end
			if(@reverse=1)begin set @output = @output + ''Password is reverse of the name\n'' end
			if(@onechar=1) begin set @output = @output +''Password is 1 character long\n'' end
			set @output = @output +''\n''
			
			fetch next from lus into @naam,@weak,@null,@same,@reverse,@onechar
		  end
		close lus
		deallocate lus	
		declare @out varchar(8000)
		set @output = @output + ''|Number of weak passwords : ''+convert(char(2),@aantal)
	
		exec nagios.NAGIOSINPUT 1,@output
end
	

	--select * from #name
	drop table #name
END

' 
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[nagios].[CHECK_USER]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'create PROCEDURE [nagios].[CHECK_USER]
AS
exec nagios.NAGIOSINPUT 0,''Login procedure passed !''' 
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[nagios].[CHECK_UPTIME]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'


-- =============================================
-- Author:		Steve Vos
-- Create date: 17/04/2008
-- Description:	Controleert de uptime van de sqlserver 
-- =============================================
CREATE PROCEDURE [nagios].[CHECK_UPTIME]
AS
  declare @uptime int
  declare @limit int
  declare @output varchar(255)

  select @limit = (select min_uptime_minutes from check_limits)
  select @uptime = (Select abs(datediff(mi,getDate(),login_time)) as uptime from master..sysprocesses
  where spid = 1)

  
  if(@uptime < @limit)
  begin
		set @output = ''Server has just been restarted. (UPTIME = '' + convert(char(2),@uptime) +'' minutes.\nThe limit is: ''+convert(char(2),@limit) + '' minutes.''
        exec nagios.NAGIOSINPUT 2,@output
  end
  else
  begin
	set @output = ''OK! (UPTIME = '' + convert(char(4),@uptime) + '' min.)''
    --set @output =''OK!''
	exec nagios.NAGIOSINPUT 0,@output
  end
' 
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[nagios].[CHECK_LOG_SIZE]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'
-- =============================================
-- Author:		Steve Vos
-- Create date: 18 april 2008
-- Description:	Controleren van de groote van de logfiles
-- =============================================
CREATE PROCEDURE [nagios].[CHECK_LOG_SIZE] @dbname varchar(255)
AS
BEGIN
	
	declare @dbexists int
    declare @space_used float
	declare @space_used_mb decimal(3,2)
	declare @log_size float
	declare @berekening float
	declare @output varchar(255)

    exec @dbexists =  nagios.CHECK_DATABASE_EXISTS @dbname 
   if (@dbexists=1)
   begin   

		select @space_used =(select cntr_value from master.dbo.sysperfinfo where object_name = ''SQLServer:Databases'' and counter_name like ''%Log File(s) Us%'' and instance_name = @dbname)
		select @log_size =(select cntr_value from master.dbo.sysperfinfo where object_name = ''SQLServer:Databases'' and counter_name like ''%Log File(s) Si%'' and instance_name = @dbname)
      
 set @berekening = (@space_used/@log_size)*100
--berekenen logspace in mb.
set @space_used_mb=(@space_used/1024)
-- print ''USAGE: ''+convert(char(4),@berekening)+'' %''
--print ''-->''+convert(char(4),@berekening)
 if((@berekening > 90) AND (@berekening <=95))
 begin
		  set @output = ''Usage exceeds 90%!\nSize = '' + convert(char(6),@space_used_mb) + ''MB|Size = '' +convert(char(6),@space_used_mb)+ '' MB''
          exec nagios.NAGIOSINPUT 1,@output
       end
	else
	begin
		if(@berekening >=100)
		begin
				set @output = ''Usage exceeds 100%!\nSize = '' + convert(char(6),@space_used_mb) + ''MB|Size = '' +convert(char(6),@space_used_mb)  + '' MB''
				exec nagios.NAGIOSINPUT 2,@output
		 end
		 else
		 begin
				set @output =''Usage OK \nSize = '' + convert(char(6),@space_used_mb) + ''MB|Size = '' +convert(char(6),@space_used_mb)+ '' MB''
				exec nagios.NAGIOSINPUT 0,@output
		  end
		end
   end
   else
   begin
          exec nagios.NAGIOSINPUT 1,''DATABASE DOES NOT EXIST !''
   end

END


' 
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[nagios].[CHECK_DATABASE_STATUS2]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'

-- =============================================
-- Author:		Steve Vos
-- Create date: 07/05/2008
-- Description:	Dit script controleert de status van de verschillende databases (offline mode - recovering mode - not recovered mode - dbo use only mode - single user mode - emergency mode )
-- =============================================
CREATE PROCEDURE [nagios].[CHECK_DATABASE_STATUS2] @name varchar(255)
AS
BEGIN
	create table #temp (dbname varchar(255),messagenr int) --temp table maken 
	insert #temp select name,status from master..sysdatabases where [name] like @name    --temp table vullen met de status van elke tabel

	declare lus cursor for select * from #temp
	declare @dbname varchar(255), @messagenr int
	declare @output varchar(8000)
	declare @temp varchar(1000)
	declare @aantal int
	
		open lus
		fetch next from lus into @dbname,@messagenr		
	    
		set @output =''The following databases are not in ONLINE modus: \n''
		set @aantal = 0
		while @@fetch_status >= 0
		  begin
				set @temp = ''''
				set @temp = @temp + ''\nDATABASE ''+@dbname +'' STATUS:\n''
				if(@messagenr & 512 <> 0) BEGIN SET @temp = @temp + ''offline mode - '' SET @aantal = @aantal +1 END 
				if(@messagenr & 128 <> 0) BEGIN SET @temp = @temp + ''recovering mode - '' SET @aantal = @aantal +1 END
				if(@messagenr & 256 <> 0) BEGIN SET @temp = @temp + ''not recovered - '' SET @aantal = @aantal +1 END
				if(@messagenr & 2048 <> 0) BEGIN SET @temp = @temp + ''DBO use only mode - '' SET @aantal = @aantal +1 END
				if(@messagenr & 4096 <> 0) BEGIN SET @temp = @temp + ''Single user mode - '' SET @aantal = @aantal +1 END
				if(@messagenr & 32768 <> 0) BEGIN SET @temp = @temp + ''emergency mode - '' SET @aantal = @aantal +1 END			
				
				if(@temp <> ''\nDATABASE ''+@dbname +'' STATUS:\n'')
				begin
					set @output = @output + @temp
					set @output = @output + ''\n-----------------------------------------------\n''
				end
			fetch next from lus into @dbname,@messagenr
		  end
		  if @aantal = 0
		  begin
				set @output = ''Database '' + convert(char(10),@dbname) + '' is online''
				exec nagios.NAGIOSINPUT 0, @output
		  end
		  else
		  begin
			    exec nagios.NAGIOSINPUT 1, @output
		  end
		 
	--select * from #temp			
	drop table #temp --temp table droppen
END



' 
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[nagios].[CHECK_CONNECTIONS]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'
-- =============================================
-- Author:		Steve Vos
-- Create date: 18/04/2008
-- Description:	controleert het aantal openstaande verbindingen naar de SQL Server 
-- Het max aantal connections kan ingesteld worden in de tabel check_limits, een aantal connecties zijn normaal
-- de sqlserveragent is vernatwoordelijk voor al 2 connecties wanneer deze draait. andere services van sqlserver 
-- kunnen er ook nog openhouden.
-- =============================================
CREATE PROCEDURE [nagios].[CHECK_CONNECTIONS] 
AS
BEGIN
	declare @limit int
	declare @connections int
	declare @output varchar(255)
	declare @obj varchar(255)
	
	


	select @limit=(select max_connections from check_limits)
    select @connections=(SELECT cntr_value FROM master..sysperfinfo as p WHERE
    p.object_name like ''%General Statistics%'' And p.counter_name = ''User Connections'')

    set @output = convert(char(3),@connections)+'' connections \nThe limit is ''+convert(char(7),@limit)+'' connections|Connections = '' + convert(char(3),@connections)

    if (@connections >= (@limit*0.5) and (@connections <= (@limit*0.8)))
    begin
       exec nagios.NAGIOSINPUT 1,@output
    end
	else
    begin
		if (@connections > (@limit*0.8))
		begin
			exec nagios.NAGIOSINPUT 2,@output
		end
		else
		begin
			exec nagios.NAGIOSINPUT 0, @output
		end
	end

    
END


' 
END
commit;
go

------------------------------------------------------
---------Toekennen van de juiste rechten--------------
------------------------------------------------------
--rechten geven aan nagios aan db nagios
use [nagios]
GO

GRANT select on [nagios].[check_limits] TO [nagios]
GRANT select on [nagios].[critical_jobs] TO [nagios]
GRANT select, insert on [nagios].[perfcounters] TO [nagios]

grant execute on [nagios].[check_connections] to [nagios]
grant execute on [nagios].[check_critical_failed_jobs] to [nagios]
grant execute on [nagios].[check_data_size] to [nagios]
grant execute on [nagios].[check_database_exists] to [nagios]
grant execute on [nagios].[check_database_status] to [nagios]
grant execute on [nagios].[check_failed_logins] to [nagios]
grant execute on [nagios].[check_last_backup] to [nagios]
grant execute on [nagios].[check_log_size] to [nagios]
grant execute on [nagios].[check_noncritical_failed_jobs] to [nagios]
grant execute on [nagios].[check_performance] to [nagios]

grant execute on [nagios].[check_uptime] to [nagios]
grant execute on [nagios].[check_user] to [nagios]
grant execute on [nagios].[check_weak_passwords] to [nagios]
grant execute on [nagios].[nagiosinput] to [nagios]
grant execute on [nagios].[show_critical_failed_jobs] to [nagios]
grant execute on [nagios].[show_login_errors] to [nagios]
grant execute on [nagios].[show_noncritical_failed_jobs] to [nagios]


-----rechten op db msdb
USE [msdb]
GO
---CREATE USER [nagios] FOR LOGIN [nagios] WITH DEFAULT_SCHEMA=[dbo]
exec sp_adduser 'admin','admin'
---CREATE USER [admin] FOR LOGIN [admin] WITH DEFAULT_SCHEMA=[dbo]
exec sp_adduser 'nagios','nagios'
go

--EXEC sp_addrolemember N'db_datareader', N'nagios'


----add nagios to master database
USE [master]
go
--CREATE USER [nagios] FOR LOGIN [nagios] WITH DEFAULT_SCHEMA=[dbo]
--CREATE USER [admin] FOR LOGIN [admin] WITH DEFAULT_SCHEMA=[dbo]
exec sp_adduser 'admin','admin'
exec sp_adduser 'nagios','nagios'


--zorgen dat nagios aan de tabel master..sysperfinfo kan
USE [master]
grant execute on [dbo].[xp_readerrorlog] to nagios
grant execute on [dbo].[xp_loginconfig] to nagios
GO
--ALTER LOGIN [nagios] WITH DEFAULT_DATABASE=[nagios], DEFAULT_LANGUAGE=[us_english], CHECK_EXPIRATION=OFF, CHECK_POLICY=OFF, NO CREDENTIAL
GO
use [master]
GO
--ng nt in orde
--GRANT VIEW SERVER STATE TO [nagios]
GO