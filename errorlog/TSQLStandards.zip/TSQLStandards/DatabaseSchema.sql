DECLARE @SQL VARCHAR(MAX)
; 
 SELECT @SQL  = ISNULL(@SQL + ' UNION ALL','') 
              + REPLACE(REPLACE(REPLACE('
 SELECT  DBName         = "[<<DBName>>]"
        ,DBID           = <<DBID>>
        ,SchemaName     = QUOTENAME(s.name COLLATE database_default)
        ,SchemaID       = s.schema_id
        ,SchemaOwnerName= p.name COLLATE database_default
        ,SchemaOwnerID  = s.principal_id
   FROM [<<DBName>>].sys.schemas s
   JOIN [<<DBName>>].sys.database_principals p
     ON s.principal_id = p.principal_id'
                ,'"','''')  --The other end of the REPLACEs starts here
                ,'<<DBName>>',db.name)
                ,'<<DBID>>',CONVERT(VARCHAR(10),database_id))
   FROM sys.databases db
  WHERE db.name NOT IN ('ReportServer','ReportServerTempDB')
    AND db.database_id > 4
    AND HAS_DBACCESS(name) = 1
;
 SELECT @SQL = '    USE master;'+@SQL;
;
  PRINT @SQL --Will be truncated at 8K or less
;
   EXEC (@SQL)
;