IF object_id('tempdb..#x') IS NOT NULL
	DROP TABLE #x;

CREATE TABLE #x
(
	[db]				varchar(100),
	[FileType]			varchar(30),
	[Physical_location]	varchar(200),
	[Size(mb)]			int,
	[MaxSize(mb)]		bigint,
	growth				int,
	is_percent_growth	bit
);

EXEC sp_msforeachdb '
USE [?];
INSERT INTO #x
	SELECT	DB_NAME() [db],
			type_desc [FileType],
			physical_name [Physical_location],
			size [Size(mb)],
			max_size [MaxSize(mb)],
			growth,
			is_percent_growth
	FROM sys.database_files
'	

SELECT	[db], 
		CASE (FileType)
			WHEN 'ROWS' THEN 'Data file'
			WHEN 'LOG' THEN 'Log File'
			ELSE FileType
		END [FileType],
		[Physical_location],
		([Size(mb)] * 8)/1024 [size(mb)],
		([MaxSize(mb)] * 8)/1024 [MaxSize(mb)],
		CASE
			WHEN is_percent_growth = 0
				THEN CAST(growth * 8/1024 AS varchar(10)) + 'MB'
			ELSE
				CAST(growth as varchar(10)) + '%'
		END AS [File Growth]
FROM #x
ORDER BY [db], [FileType]