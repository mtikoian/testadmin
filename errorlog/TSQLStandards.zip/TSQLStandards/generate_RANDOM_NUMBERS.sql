CREATE PROCEDURE dbo.RANDOM_NUMBERS(@HOW_MANY AS BIGINT, @MINIMUM_DIGITS AS tinyint, @ADDITIONAL_DIGITS AS tinyint)
AS
BEGIN
-- ***************************************************************************************************************** --
-- *  AUTHOR: Steve Munson                                                                                         * --
-- * CREATED: 08/06/2009 @ 09:00 AM                                                                                * --
-- *                                                                                                               * --
-- * This stored procedure uses NEWID() as a means to generate random numbers of at least @MINIMUM_DIGITS digits,  * --
-- * with up to @ADDITIONAL_DIGITS more digits, and return @HOW_MANY of them.   Initial idea for this method stems * --
-- * from code posted by Jeff Moden on SQL Server Central.  Thanks, Jeff!                                          * --
-- ***************************************************************************************************************** --
IF @HOW_MANY < 1 OR @MINIMUM_DIGITS < 1 OR @ADDITIONAL_DIGITS < 0 OR (@MINIMUM_DIGITS + @ADDITIONAL_DIGITS) > 18
	BEGIN
	DECLARE @ERROR_MSG AS nvarchar(200)
	SET @ERROR_MSG = 'Incorrect parameter specified.  You must specify a positive integer for all parameters except' +
		CHAR(13) + CHAR(10) + '@ADDITIONAL_DIGITS, which must be either 0 or a positive integer.  18 digits maximum.'
	RAISERROR (@ERROR_MSG,4,1)
	END
 ELSE
	BEGIN
	SELECT TOP (@HOW_MANY)
		CAST(RIGHT(CAST(CAST(NEWID() AS VARBINARY) AS BIGINT),
			ABS(CHECKSUM(NEWID()))%(@ADDITIONAL_DIGITS + 1)+@MINIMUM_DIGITS) AS bigint) AS RANDOM_NUMBER
	FROM master.sys.all_columns ac1
		CROSS JOIN master.sys.all_columns ac2
	END
END
GO