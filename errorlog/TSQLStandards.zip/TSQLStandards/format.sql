--works in 2012 above
if object_id('tempdb.dbo.#myphoneno') is not null drop table #myphoneno
create table #myphoneno (phone_id int, phone varchar(20))

Insert into #myphoneno values (01, '(866) 987-3847' ) --- Rule 1,3,4
Insert into #myphoneno values (02, '1-800-222-SAVE(7283)') --- Rule 2,4
Insert into #myphoneno values (03, '(800) 111-4015') --Rule 3,4
Insert into #myphoneno values (04, '18002288775') ---Rule 5
Insert into #myphoneno values (05, '(800) 2223415')--- Rule 1,3,4,5
Insert into #myphoneno values (06, '(800) 2-MOHAN')--- Rule 1,,3,4
Insert into #myphoneno values (07, '1-800-228-4995') ---Rule 4
Insert into #myphoneno values (08, '877-233-0112')---- Rule 1,4
Insert into #myphoneno values (09, '800 228 3315')--- 1,3,4
Insert into #myphoneno values (10, '18002284225')---Rule 5
Insert into #myphoneno values (11, '800/219-1140') --- Rule 1,4
Insert into #myphoneno values (12, '1 (855) ECO-8107') -- Rule 3,4
Insert into #myphoneno values (13, '(888) BOM4BQC')-- Rule1,3,4
Insert into #myphoneno values (14, '877-421K-MOX')-- Rule 1,4

Insert into #myphoneno values (15,'800-222-SAVE(7283)') --- Dup, just adding to test the "1 in front" situation

;WITH 
prep AS
(	SELECT *, px = patindex('%[a-z][a-z][a-z][a-z]([0-9][0-9][0-9][0-9])%',phone)
	FROM #myphoneno
),
transform1 AS
(	SELECT phone, newnum = newstring
	FROM prep
	CROSS APPLY PatReplace8K(phone, '[^0-9]','') xx
	WHERE 0 <> px
	UNION ALL
	SELECT phone, xx9.newstring
	FROM prep
	CROSS APPLY dbo.PatReplace8K(phone, '[a-cA-C]','2') xx1
	CROSS APPLY dbo.PatReplace8K(xx1.newstring, '[d-fD-F]','3') xx2
	CROSS APPLY dbo.PatReplace8K(xx2.newstring, '[g-iG-I]','4') xx3
	CROSS APPLY dbo.PatReplace8K(xx3.newstring, '[j-lJ-L]','5') xx4
	CROSS APPLY dbo.PatReplace8K(xx4.newstring, '[m-oM-O]','6') xx5
	CROSS APPLY dbo.PatReplace8K(xx5.newstring, '[p-sP-S]','7') xx6
	CROSS APPLY dbo.PatReplace8K(xx6.newstring, '[t-vT-V]','8') xx7
	CROSS APPLY dbo.PatReplace8K(xx7.newstring, '[w-zW-Z]','9') xx8
	CROSS APPLY dbo.PatReplace8K(xx8.newstring, '[^0-9]','') xx9
	WHERE 0 = px
),
transform2 AS
(	SELECT old = phone, newnum = IIF(substring(newnum,1,1)=1, newnum, concat(1,newnum)) 
	FROM transform1
)
SELECT old, newnum = IIF(len(newnum)<>11,'BAD!',stuff(stuff(stuff(newnum, 2,0,'.'),6,0,'.'),10,0,'.'))
FROM transform2;

--solution 2


SELECT mp.phone AS phone_original--, mpe.phone AS phone_expected
, phone_edited5
FROM #myphoneno mp
--left outer join #myphonenoExpected mpe on
--    mpe.phone_id = mp.phone_id
CROSS APPLY (
    SELECT LEFT(CASE WHEN SUBSTRING(phone_edited4,10, 1) LIKE '[.A-Z]' THEN phone_edited4 ELSE STUFF(phone_edited4,10, 0, '.') END, 14)
        AS phone_edited5
    FROM (
        SELECT CASE WHEN SUBSTRING(phone_edited3, 6, 1) LIKE '[.A-Z]' THEN phone_edited3 ELSE STUFF(phone_edited3, 6, 0, '.') END 
            AS phone_edited4
        FROM (
            SELECT CASE WHEN SUBSTRING(phone_edited2, 2, 1) LIKE '[.A-Z]' THEN phone_edited2 ELSE STUFF(phone_edited2, 2, 0, '.') END 
                AS phone_edited3
            FROM (
                SELECT CASE WHEN LEFT(phone_edited1, 1) = '1' THEN '' ELSE '1' END + phone_edited1 
                    AS phone_edited2
                FROM (
                    SELECT REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(mp.phone, 
                        SPACE(1), ''), '(', '.'), ')', '.'), '-', '.'), '/', '.') AS phone_edited1
                ) AS derived1
            ) AS derived2
        ) AS derived3
    ) AS derived4
) AS assign_alias_names
