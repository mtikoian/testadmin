--===== These could be parameters in a stored procedure
DECLARE @Directory  VARCHAR(256)
DECLARE @FileName   VARCHAR(256)
DECLARE @Header   VARCHAR(8000)
DECLARE @Query    VARCHAR(8000)

--===== These hold the necessary DOS commands for BCP and COPY
DECLARE @HeaderDosCmd VARCHAR(8000)
DECLARE @QueryDosCmd  VARCHAR(8000)
DECLARE @FilesDosCmd  VARCHAR(8000)

SET NOCOUNT ON

 SELECT @Directory  = 'C:\Temp\',
    @FileName   = 'Test'
        + CONVERT(VARCHAR(30),GETDATE(),112)
        + LEFT(REPLACE(CONVERT(VARCHAR(30),GETDATE(),108),':',''),4),
    @Header   = 'SELECT ''AddressID'',''AddressLine1'',''AddressLine2'',''City'',''StateProvinceID'',''PostalCode''',
    @Query    = 'SELECT AddressID,AddressLine1,AddressLine2,City,StateProvinceID,PostalCode FROM AdventureWorks.Person.Address',
    @HeaderDosCmd = 'BCP "'+@Header+'" QUERYOUT "'+@Directory+@FileName+'.hdr" -S"'+@@SERVERNAME+'" -c -t"" -T', 
    @QueryDosCmd  = 'BCP "'+@Query +'" QUERYOUT "'+@Directory+@FileName+'.txt" -S"'+@@SERVERNAME+'" -c -t"" -T',
    @FilesDosCmd  = 'COPY "'+@Directory+@FileName+'.hdr"+"'+@Directory+@FileName+'.txt" "'+@Directory+@FileName+'.csv"'

--===== Just shows what the commands end up looking like
  PRINT @HeaderDosCmd
  PRINT @QueryDosCmd
  PRINT @FilesDosCmd

--===== Do the work of exporting and combining files.
   -- I intentionally did not include a delete on the hdr and txt file.
   -- I didn't want to make anyone nervous ;-)
 EXEC Master.dbo.xp_CmdShell @HeaderDosCmd
 EXEC Master.dbo.xp_CmdShell @QueryDosCmd
 EXEC Master.dbo.xp_CmdShell @FilesDosCmd