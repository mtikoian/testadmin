---------------------------------------------------------------------------
-- Project: AGA DB CLEAR Tables data
-- @owner vkotian
--Created: 11/10/2011
--
-- Description:
--
--    This script will truncate the data from all the AGA tables 
--    Parent script:AGA_DB_CLEAR_TABLES_DATA.cmd
-- NOTE:
--	In case if you want to roll back the data, run bcp_in_aga_tables_data.cmd
--  modified:3/28/2012 @vkotian
--  added transaction support for delete  
--
-- ---------------------------------------------------------------------------
--truncate script
/** Usage:sqlcmd  -S<Server name> -i <dbcleanup-AGA.sql> -v DBNAME="AGA_DEV_D0931_435" SCHEMA_NAME="aga"  */

USE [$(DBNAME)]
GO

SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
GO
declare @ErrMsg                 varchar(1000) ;
declare @ErrNum                 int;
declare @CrLf                   char(2);
set nocount on;
    
    set @ErrMsg = '';
    set @ErrNum = 0;
    set @CrLf   = char(13) + char(10);
    
    print '***** Project: AGA DB CLEAR Tables data *****';
    print 'SQL Start Time: ' +  + convert(varchar(30), getdate(), 121);   
    print '';
begin try
	begin transaction;
	print 'Transaction is started';
    print ''
	--drop FKs
	--aga.group_detail FKs
	IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[$(SCHEMA_NAME)].[FK_Group_Detail_ref_Account_Group]') AND parent_object_id = OBJECT_ID(N'[$(SCHEMA_NAME)].[Group_Detail]'))
	ALTER TABLE [$(SCHEMA_NAME)].[Group_Detail] DROP CONSTRAINT [FK_Group_Detail_ref_Account_Group]
	
	IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[$(SCHEMA_NAME)].[FK_Group_Detail_ref_Account_Group_2]') AND parent_object_id = OBJECT_ID(N'[$(SCHEMA_NAME)].[Group_Detail]'))
	ALTER TABLE [$(SCHEMA_NAME)].[Group_Detail] DROP CONSTRAINT [FK_Group_Detail_ref_Account_Group_2]
	
	
	--aga.group_recipient FKs
	IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[$(SCHEMA_NAME)].[FK_Group_Recipient_ref_Account_Group]') AND parent_object_id = OBJECT_ID(N'[$(SCHEMA_NAME)].[Group_Recipient]'))
	ALTER TABLE [$(SCHEMA_NAME)].[Group_Recipient] DROP CONSTRAINT [FK_Group_Recipient_ref_Account_Group]


	
    
	
		--delete aga.account_group. This is the table that needs FK drops.
		delete from [$(SCHEMA_NAME)].ACCOUNT_GROUP
		print cast(@@rowcount as varchar(10)) + ' rows whacked from aga.Account_Group';
		--delete other tables too
		delete from [$(SCHEMA_NAME)].GROUP_DETAIL
		print cast(@@rowcount as varchar(10)) + ' rows whacked from aga.Group_Detail';
		delete from [$(SCHEMA_NAME)].ACCOUNT_RECIPIENT
		print cast(@@rowcount as varchar(10)) + ' rows whacked from aga.Account_Recipient';
		delete from [$(SCHEMA_NAME)].Group_Recipient
		print cast(@@rowcount as varchar(10)) + ' rows whacked from aga.Group_Recipient'
		delete from [$(SCHEMA_NAME)].Perfsta_State
		print cast(@@rowcount as varchar(10)) + ' rows whacked from aga.PerfSta_State';
		delete from [$(SCHEMA_NAME)].Audit_Trail
		print cast(@@rowcount as varchar(10)) + ' rows whacked from aga.Audit_Trail';
		--following tables should not be deleted
		--table [$(SCHEMA_NAME)].DB_Control_History
		--table [$(SCHEMA_NAME)].DB_Control
		--table [$(SCHEMA_NAME)].Table_Reference
		--table [$(SCHEMA_NAME)].GROUP_TYPE
	
	--recreate FKs
	--aga.group_detail FKs
	ALTER TABLE [$(SCHEMA_NAME)].[Group_Detail]  WITH CHECK ADD  CONSTRAINT [FK_Group_Detail_ref_Account_Group] FOREIGN KEY([Account_Group_Num])
	REFERENCES [$(SCHEMA_NAME)].[Account_Group] ([Account_Group_Num])
	
	
	ALTER TABLE [$(SCHEMA_NAME)].[Group_Detail] CHECK CONSTRAINT [FK_Group_Detail_ref_Account_Group]
	
	
	ALTER TABLE [$(SCHEMA_NAME)].[Group_Detail]  WITH CHECK ADD  CONSTRAINT [FK_Group_Detail_ref_Account_Group_2] FOREIGN KEY([Included_Account_Group_Num])
	REFERENCES [$(SCHEMA_NAME)].[Account_Group] ([Account_Group_Num])
	
	
	ALTER TABLE [$(SCHEMA_NAME)].[Group_Detail] CHECK CONSTRAINT [FK_Group_Detail_ref_Account_Group_2]
	
	--aga.group_recipient FKs
	ALTER TABLE [$(SCHEMA_NAME)].[Group_Recipient]  WITH CHECK ADD  CONSTRAINT [FK_Group_Recipient_ref_Account_Group] FOREIGN KEY([Account_Group_Num])
	REFERENCES [$(SCHEMA_NAME)].[Account_Group] ([Account_Group_Num])
	
	
	ALTER TABLE [$(SCHEMA_NAME)].[Group_Recipient] CHECK CONSTRAINT [FK_Group_Recipient_ref_Account_Group]
	
	commit transaction;
    print '';
    print 'Transaction is committed'    ;
    
    print '';

end try
begin catch
    if @@trancount > 0 begin
        rollback transaction;
        print 'Transaction is rolled back';
    end
        
    
	select  @ErrMsg =   'An error has occurred' + @CrLf +
                        'Error Number is      : ' + cast(error_number() + @ErrNum as varchar(10)) + @CrLf +
		                'Error Message is     : ' + case when @ErrMsg <> '' then @ErrMsg else error_message() end + @CrLf +
		                'Error Line Number is : ' + cast(error_line() as varchar(10)) + @CrLf + 
		                'Error State is       : ' + cast(error_state() as varchar(10)) + @CrLf + 
		                'Error Severity is    : ' + cast(error_severity() as varchar(10));
                        
    select @ErrMsg;
end catch			
GO