To bcp  all tables from the Arden database and import them to the same database on another server follow these steps



1:  Execute p_dbabcpout proc  	- exports all user tables to a predefined location as it_arden_tablename.dat 
2:  Zip up the .dat files
3:  encrypt and send them to Arden 

Duration:  10-15 minutes  

At arden
This can be scheduled in sql agent

4:  Unzip them 
5: drop constraints 		-drop_arden_constraints.sql
6: truncate tables  		- truncate_arden_tables.sql
7: execute p_dbabcpin proc  	- imports all it_arden_tablename.dat bcp file to the same tables
8: reapply constraints 		- add_arden_constraints.sql

Duration:  15-20 minutes  

