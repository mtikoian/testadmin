           DELETE/TRUNCATE Script for AGA Table  cleanup 
           ======================================                
  Run 'AGA_DB_CLEAR_TABLES_DATA.cmd' to clear data from AGA tables.                                
  If you want to roll back the data, run 'bcp_in_aga_tables_data.cmd'.
  
  @Author: vkotian    Script Date: 11 11 2011 9:51:00        
 	Notes:
 	1. Before running the scripts, make sure you set the enviroment variables in the following script:
	 	AGA_DB_CLEAR_TABLES_CONFIG.cmd    
	 	Following are the steps for updating variables in the above script
	 	1.Open the AGA_DB_CLEAR_TABLES_CONFIG.cmd file in Notepad and edit the SET statements as follows:  
	 		a) set DB_NAME=<name of the database used>
	 		b) set SCHEMA_NAME=<name of the schema>
	 		c) set SERVER_NAME=<name of the database server>
 		
 	2. Log files are available as 'aga_db_clear_tables_data.log' and 'aga_db_rollback_tables_data.log'
 		based on the commands run.     
 		
 	3. As soon as you run the script for the first time, copy *.dat files from the run location to the safe location.
 	4. Whenever you want to restore the data, bring back the *.dat files from the safe location to the run location. And run the 'bcp_in_aga_tables_data.cmd'.                                                          
	5. The checked in script will use 'delete' commands to delete each row. This is slow in performance, since all the triggers and logs will activate for each row.
		 If data is huge, you can use 'truncate' script by updating the 'AGA_DB_CLEAR_TABLES_DATA.cmd'. Information is provided in the file for doing this.
  6. The script will delete data from the following AGA tables:
    1.	ACCOUNT_GROUP
		2.	GROUP_DETAIL
		3.	ACCOUNT_RECIPIENT		
		4.	AUDIT_TRAIL
		5.	GROUP_RECIPIENT
		6.	PERFSTA_STATE
	7. Data from the following AGA tables are not deleted because some of them have AGA seed data for the AGA UI.
		1. 	DB_CONTROL
		2.	DB_CONTROL_HISTORY
		3.	GROUP_TYPE
		4.	TABLE_REFERENCE