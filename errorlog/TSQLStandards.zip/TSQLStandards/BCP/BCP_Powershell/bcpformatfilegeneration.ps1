function Create-SqlFormatFile {
    param (
        [Parameter(Mandatory = $true)]
        $SourceFilename,
        $Delimiter = ","
    )

    $headerList = New-Object System.Collections.ArrayList
foreach ($base in ((Get-Content $SourceFilename | Select -First 1) -split $Delimiter)) {
        $field = $base
        $number = 0
        while ($headerList -contains $field) {
            $field = $base + ($number++)
        }
 
        [void] $headerList.Add($field)
    }
	$format = New-Object System.Text.StringBuilder
    [void] $format.AppendLine(@"
<?xml version="1.0"?>
<BCPFORMAT xmlns="http://schemas.microsoft.com/sqlserver/2004/bulkload/format" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
<RECORD>
"@)
 $headerList | %{
        [void] $format.AppendLine(@" 
  <FIELD ID="$_" xsi:type="CharTerm" TERMINATOR="$(if ($_ -eq $headerList[-1]) { "\r\n" } else { $Delimiter })" />
"@)
    }
	[void] $format.AppendLine(@"
</RECORD>
<ROW>
"@)

    $headerList | %{
        [void] $format.AppendLine(@"
  <COLUMN SOURCE="$_" NAME="$_" xsi:type="SQLNVARCHAR" NULLABLE="YES" />
"@)
    }
	
	 [void] $format.AppendLine(@"
</ROW>
</BCPFORMAT>
"@)

    Set-Content -Path "$($SourceFilename).fmt" -Value 
$format.ToString()
}
Create-SqlFormatFile 