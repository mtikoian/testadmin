--===== Disable all triggers on user tables in database
DECLARE @SQL VARCHAR(MAX)
 SELECT @SQL =''
 SELECT @SQL = @SQL + 
             + 'DISABLE TRIGGER ALL ON ' + Table_Schema + '.' +Table_Name +';'
   FROM Information_Schema.Tables
  WHERE Table_Type = 'BASE TABLE'
   EXEC (@SQL)

--===== Enable all triggers on user tables in database
DECLARE @SQL VARCHAR(MAX)
 SELECT @SQL =''
 SELECT @SQL = @SQL + 
             + 'ENABLE TRIGGER ALL ON ' + Table_Schema + '.' +Table_Name +';'
   FROM Information_Schema.Tables
  WHERE Table_Type = 'BASE TABLE'
   EXEC (@SQL) 