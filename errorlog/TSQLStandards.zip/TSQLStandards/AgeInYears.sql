CREATE FUNCTION dbo.AgeInYears
        (
        @DOB DATETIME, --Date of birth or date of manufacture
        @Now DATETIME  --Usually, GETDATE() or CURRENT_TIMESTAMP but
                       --can be any date source like a column.
        )
RETURNS TABLE WITH SCHEMABINDING AS
RETURN
SELECT AgeInYears = 
            CASE
            WHEN a.[Now] < a.[DOB]
            THEN null
             --If birthday hasn't happended yet this year, subtract 1.
            WHEN DATEADD(yy, DATEDIFF(yy, a.[DOB], a.[Now]), a.[DOB]) > a.[Now]
            THEN DATEDIFF(yy, a.[DOB], a.[Now]) - 1
            ELSE DATEDIFF(yy, a.[DOB], a.[Now])
            END
FROM
	(SELECT	[DOB] = dateadd(dd,datediff(dd,0,@DOB),0),
		[Now] = dateadd(dd,datediff(dd,0,@Now),0)) a
;
GO