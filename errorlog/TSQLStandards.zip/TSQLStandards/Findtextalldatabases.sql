
declare @search_string varchar(100) = 'mytext'
declare @sql nvarchar(max) = '' --need to set this to an empty string for the next statement to work correctly

select @sql = @sql + 'select DISTINCT ''' + db.name + ''' as DatabaseName, s.name AS Schema_Name, o.name AS Object_Name, o.type_desc 
FROM ' + db.name + '.sys.sql_modules m 
INNER JOIN ' + db.name + '.sys.objects o ON m.object_id = o.object_id 
INNER JOIN ' + db.name + '.sys.schemas s ON o.schema_id = s.schema_id 
WHERE m.definition Like ''%' + @search_string + '%'' UNION ALL 
'
from sys.databases db
where db.database_id > 4 --eliminates master, tempdb, model, msdb

select @sql = STUFF(@sql, len(@sql) - 11, 11, '')

select @sql
--exec sp_executesql @sql --once you are comfortable with the dynamic sql you can uncomment this line

