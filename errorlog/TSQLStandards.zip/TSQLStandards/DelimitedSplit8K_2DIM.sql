
CREATE FUNCTION [dbo].[DelimitedSplit8K_2DIM]
    (
     @pString VARCHAR(8000)
    ,@pDelimiter1 CHAR(1)
    ,@pDelimiter2 CHAR(1) = NULL
    )
RETURNS TABLE WITH SCHEMABINDING AS
RETURN
WITH E1(N) AS (
                 SELECT 1 UNION ALL SELECT 1 UNION ALL SELECT 1 UNION ALL 
                 SELECT 1 UNION ALL SELECT 1 UNION ALL SELECT 1 UNION ALL 
                 SELECT 1 UNION ALL SELECT 1 UNION ALL SELECT 1 UNION ALL SELECT 1
                ),                          --10E+1 or 10 rows
       E2(N) AS (SELECT 1 FROM E1 a, E1 b), --10E+2 or 100 rows
       E4(N) AS (SELECT 1 FROM E2 a, E2 b), --10E+4 or 10,000 rows max
 cteTally(N) AS (
                 SELECT 0 UNION ALL
                 SELECT TOP (DATALENGTH(ISNULL(@pString,1))) ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) FROM E4
                ),
cteStart(N1) AS (
                 SELECT t.N+1
                 FROM cteTally t
                 WHERE (SUBSTRING(@pString,t.N,1) = @pDelimiter1 OR t.N = 0) 
                )
SELECT
    ItemNumber
   ,Item1
   ,Item2 = REPLACE(Item2,Item1+@pDelimiter2,'')
FROM
    (
    SELECT 
        ItemNumber = ROW_NUMBER() OVER(ORDER BY s.N1)
       ,Item1 = SUBSTRING(@pString,s.N1,ISNULL(NULLIF(CHARINDEX(@pDelimiter2,@pString,s.N1),0)-s.N1,8000))
       ,Item2 = SUBSTRING(@pString,s.N1,ISNULL(NULLIF(CHARINDEX(@pDelimiter1,@pString,s.N1),0)-s.N1,8000))
    FROM cteStart s
    ) i1
    
 
/*
Example usage:

DECLARE @str VARCHAR(8000) 
SET @str = '123,456|789,000'

SELECT * FROM [dbo].[DelimitedSplit8K_2DIM](@str,'|',',')

DECLARE @str VARCHAR(8000) 
SET @str = '0WQDNw|aXxbzu,durPP|7yaFpK,UMERA5|FLN2G,HUdZv|QUQy5,3MbdqS|JWUgPp,F23jqp|kWbSBn,nSWunU|uh1zR,pqBJ4U|eNnZzE,jbu7R|cwd4E,1hNMC|Ru7ar'

SELECT * FROM [dbo].[DelimitedSplit8K_2DIM](@str,',','|')

*/ 