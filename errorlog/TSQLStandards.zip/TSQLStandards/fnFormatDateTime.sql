

CREATE  FUNCTION dbo.fnFormatDateTime
/*************************************************************************************************
 Purpose:  This function reformats a DateSerial based on the content of a format string.
    Date:  03/10/2004 (Full rewrite of all code collections and snippets)
  Author:  Jeffrey B. Moden
--------------------------------------------------------------------------------------------------
Description:
Two categories of functions exist: Elapsed time and DateTime formatting.  The Elapsed time format
functions will not allow DateTime formatting to occur and should probably be used individually.
See the comments in each section to determine what format strings are available and what their 
expected output should be.  Characters not part of predefined formats are faithfully replicated
in the output.
--------------------------------------------------------------------------------------------------
   Usage: dbo.fnFormatDateTime(dateserial or elapsed time in fractional days,'formatstring')
--------------------------------------------------------------------------------------------------
Examples: 
 
The following example returns an elapsed time or "duration" formatted in decimal minutes.
SELECT dbo.fnFormatDateTime(@EndDateTime-@StartDateTime,'NNN.N')
 
The following example returns an elapsed time or "duration" formatted for telephone billing and
has been rounded up to the nearest 6 seconds (6 second incremental billing).
SELECT dbo.fnFormatDateTime(@CallEndDateTime-@CallStartDateTime,'6SECINC')
 
The following example returns an elapsed time or "duration" formatted for telephone billing and
has been rounded up to the nearest minute (whole minute billing).
SELECT dbo.fnFormatDateTime(@CallEndDateTime-@CallStartDateTime,'RNN')
 
The following examples return custom dates and times as indicated in the format string.
 
SELECT dbo.fnFormatDateTime(GETDATE(),'DAY, MONTH ?D YYYY')
...returns (for example) Wednesday, March 10 2004
 
SELECT dbo.fnFormatDateTime(GETDATE(),'?YJJJ JULIAN')
...returns (for example) 4070 JULIAN
 
SELECT dbo.fnFormatDateTime(GETDATE(),'THE CURRENT DATE & TIME IS: MM/DD/YY HH:NN:SS.TTT PM')
...returns (for example) THE CURRENT DATE & TIME IS: 03/04/04 11:22:01.153 AM
 
SELECT dbo.fnFormatDateTime(GETDATE(),'THE CURRENT TIME IS: 24HNN hours military time, HH:NN PM civilian time')
...returns (for example) THE CURRENT TIME IS: 2326 hours military time, 11:26 PM civilian time
--------------------------------------------------------------------------------------------------
Revisions:
Rev 0 - 03/10/2004 - JBM - Convert old collection of stored procedures and code snippets to a
                           single function which combines all of the individual formatting 
                           techinques developed over the years, into a single ultra-flexible
                           Date and Time formatting function.
Rev 1 - 04/10/2005 - JBM - Ticket QA 13950 - The 'DDY' format-key for Julian days interferes with
                           the ability to correctly produce the standard 'mmddyy' and 'mmddyyyy' 
                           formats. Searched system tables for usage of the 'DDY' format and none
                           currently exists so repairs will not break any other code.  Changed the
                           'DDY' format key to 'JJJ' and the '?DY' format key to '?JJ'.
Rev 2 - 04/12/2005 - JBM - Ticket QA 13950 - Changed the order of precedence for a "?" funtions so
                           that they could be used with their counterparts without spaces and
                           still work correctly.
*************************************************************************************************/
       (
        @DateSerial  DATETIME,    --Holds the time duration or date/time input
        @FMTString   VARCHAR(250) --Holds the format type indicator
       )
RETURNS VARCHAR(250)              --Defines the datatype of the output (return)
AS
 

BEGIN
--===== Presets ==================================================================================
DECLARE @fmtCASE INT              --Used to determine "Elapsed Time" cases in format
    SET @fmtCASE = 
         CHARINDEX('HHH.H'  ,@FMTString)
        +CHARINDEX('HHH'    ,@FMTString)
        +CHARINDEX('NNN.N'  ,@FMTString)
        +CHARINDEX('NNN'    ,@FMTString)
        +CHARINDEX('RNN'    ,@FMTString)
        +CHARINDEX('6SECINC',@FMTString)
        +CHARINDEX('SECDUR' ,@FMTString)
--      If any of the above formats exist in the format string, 
--      then @fmtCASE will be greater than 0 and only 
--      elapsed time calculations will be replaced on the format line.
  IF    @fmtCASE > 0
  BEGIN
--===== Elapsed time calculations =================================================================
--      These calculations will override all non-elapsed time formats.  The format characters for
--      non-elapsed time formats will show in the result rather than being converted
    SET @FMTString =
        REPLACE(
        REPLACE(
        REPLACE(
        REPLACE(
        REPLACE(
        REPLACE(
        REPLACE(
        @FMTString
--===== Each conversion is this sub-section must have a REPLACE( associated with it
--      and must follow the format of ,'formatchars',conversionformula)
--      Be careful when adding new functionality so as not to destroy the order
--      sensitivity or the ability to have non-format plain-text characters in
--      the format string.
     -- Rounded decimal hours 
      ,'HHH.H'  ,CONVERT(VARCHAR(28),                      --Convert numbers to text
                 CONVERT(DECIMAL(28,1),                    --Does the formatting
                (CONVERT(FLOAT,@DateSerial)*24.0))))       --Calcs decimal minutes
     -- Unrounded whole hours
      ,'HHH'    ,CONVERT(VARCHAR(8),DateDIFF(HH,0,@DateSerial)))
     -- Rounded decimal minutes
      ,'NNN.N'  ,CONVERT(VARCHAR(28),                      --Convert numbers to text
                 CONVERT(DECIMAL(28,1),                    --Does the formatting
                (CONVERT(FLOAT,@DateSerial)*24.0*60.0))))  --Calcs decimal minutes
     -- Unrounded whole minutes
      ,'NNN'    ,CONVERT(VARCHAR(8),DateDIFF(MI,0,@DateSerial)))
     -- Whole minutes rounded UP
      ,'RNN'    ,CONVERT(VARCHAR(28),                      --Convert numbers to text
                 CONVERT(DECIMAL(28,0),                    --Does the formatting
                (CONVERT(FLOAT,@DateSerial)*24.0*60.0)     --Calcs decimal minutes
                +.49999)))                                 --Rounds up to nearest minute
     -- Decimal minutes rounded up to 6 second increments
      ,'6SECINC',CONVERT(VARCHAR(28),                      --Convert numbers to text
                 CONVERT(DECIMAL(28,1),                    --Does the formatting
                (CONVERT(FLOAT,@DateSerial)*24.0*60.0)     --Calcs decimal minutes
                +.049999)))                                --Rounds up to nearest tenth
     -- Unrounded whole seconds
      ,'SECDUR' ,CONVERT(VARCHAR(28),                      --Convert numbers to text
                 ROUND(DateDIFF(SS,0,@DateSerial),0)))     --Returns duration as seconds
  END
  ELSE
--===== Date and Time formatting functions ========================================================
--      These "non-elapsed time" functions replace the formatting characters indicated in quotes 
--      with the appropriate character values except when any of the "Elapsed Time" formatting
--      functions are present in the formatting string.
  BEGIN
    SET @FMTString = 
        REPLACE(
        REPLACE(
        REPLACE(
        REPLACE(
        REPLACE(
        REPLACE(
        REPLACE(
        REPLACE(
        REPLACE(
        REPLACE(
        REPLACE(
        REPLACE(
        REPLACE(
        REPLACE(
        REPLACE(
        REPLACE(
        REPLACE(
        REPLACE(
        REPLACE(
        REPLACE(
        REPLACE(
        REPLACE(
        REPLACE(
        @FMTString
--===== Each conversion is this sub-section must have a REPLACE( associated with it
--      and must follow the format of ,'formatchars',conversionformula)
--      Be careful when adding new functionality so as not to destroy the order
--      sensitivity or the ability to have non-format plain-text characters in
--      the format string.
     -- Long (full) month name
      ,'MONTH' ,DATENAME(MM,@DateSerial))
     -- 1 or 2 digit month number without zero fill
      ,'?M'    ,DATEPART(MM,@DateSerial))
     -- 3 character abbreviated month name
      ,'MMM'   ,LEFT(DATENAME(MM,@DateSerial),3))
     -- 2 digit month number with 0 fill for months <10
      ,'MM'    ,RIGHT('00'+CONVERT(VARCHAR(2),DATEPART(MM,@DateSerial)),2))
     -- 1, 2, or 3 digit day of year (Julian) without zero fill
      ,'?JJ'   ,DATENAME(DY,@DateSerial))
     -- 3 digit day of year (Julian) with zero fill
      ,'JJJ'   ,RIGHT('000'+DATENAME(DY,@DateSerial),3))
     -- Long (full) day name
      ,'DAY'   ,DATENAME(DW,@DateSerial))
     -- 1 or 2 digit day of month number without zero fill
      ,'?D'    ,DATEPART(DD,@DateSerial))
     -- 3 character abbreviated day name
      ,'DDD'   ,LEFT(DATENAME(DW,@DateSerial),3))
     -- 2 digit day of month number with 0 fill for days <10
      ,'DD'    ,RIGHT('00'+CONVERT(VARCHAR(2),DATEPART(DD,@DateSerial)),2))
     -- 1 digit year number for Julian type dates
      ,'?Y'    ,RIGHT(DATENAME(YY,@DateSerial),1))
     -- 4 digit year number
      ,'YYYY'  ,DATENAME(YY,@DateSerial))
     -- 2 digit year number with 0 fill for years <10
      ,'YY'    ,RIGHT(DATENAME(YY,@DateSerial),2))
     -- 2 digit 0 filled hours for 24 hour clock
      ,'24H'   ,RIGHT('00'+DATENAME(HH,@DateSerial),2))
     -- 1 or 2 digit hours for 12 hour clock without 0 fill
      ,'?H'    ,CASE 
                  WHEN DATENAME(HH,@DateSerial)>12 
                  THEN DATENAME(HH,@DateSerial-.5)
                  ELSE DATENAME(HH,@DateSerial)
                END)
     -- 2 digit 0 filled hours for 12 hour clock
      ,'HH'    ,CASE 
                  WHEN DATENAME(HH,@DateSerial)>12 
                  THEN RIGHT('00'+DATENAME(HH,@DateSerial-.5),2)
                  ELSE RIGHT('00'+DATENAME(HH,@DateSerial),2)
                END)
     -- 2 digit 0 filled minutes
      ,'NN'    ,RIGHT('00'+DATENAME(MI,@DateSerial),2))
     -- 2 digit 0 filled seconds 
      ,'SS'    ,RIGHT('00'+DATENAME(SS,@DateSerial),2))
     -- 2 digit 0 filled milli-seconds
      ,'TTT'   ,RIGHT('000'+DATENAME(MS,@DateSerial),3))
     -- AM or PM indicator based on time of day
      ,'PM'    ,RIGHT(CONVERT(CHAR(19),@DateSerial,100),2))
     -- 1 or 2 digit week of year
      ,'?W'    ,DATENAME(WW,@DateSerial))
     -- 2 digit 0 filled week of year
      ,'WW'    ,RIGHT('00'+DATENAME(WW,@DateSerial),2))
     -- 1 digit quarter of year
      ,'?Q'    ,DATENAME(QQ,@DateSerial))
  END
--===== Return the reformatted format string and exit =============================================
 RETURN @FMTString --Return the answer as output of function
END


