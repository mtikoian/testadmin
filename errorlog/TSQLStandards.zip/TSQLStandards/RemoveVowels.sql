create function dbo.RemoveVowels(
    @pString varchar(max)
)
returns table
as
return (select replace(replace(replace(replace(replace(replace(@pString,'Y',''),'U',''),'O',''),'I',''),'E',''),'A','') NoVowels);
go
