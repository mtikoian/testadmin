DROP TABLE #TempLog

--===== Simulate loading the log file into a table
 CREATE TABLE #TempLog
        (
         LogEntry VARCHAR(8000)
        )
;
 INSERT INTO #TempLog
        (LogEntry)
 SELECT '2/16/2012 12:27:32 AM -- Found file 1776ELIG_20120215.txt for Processing -- Group 1776' UNION ALL
 SELECT '2/16/2012 12:27:32 AM -- File Copied -- Group 1776' UNION ALL
 SELECT '2/16/2012 12:27:38 AM -- 27376 Records IN: 0 A, 0 E, 0 N, 0 F -- Group 1776' UNION ALL
 SELECT '2/16/2012 12:37:42 AM -- 0 Errors found in Eligiblity Load -- Group 1776' UNION ALL

 SELECT '2/16/2012 01:27:32 AM -- Found file 99DODAH_20120215.txt for Processing -- Group 99' UNION ALL
 SELECT '2/16/2012 01:27:32 AM -- File Copied -- Group 99' UNION ALL
 SELECT '2/16/2012 01:27:38 AM -- 12 Records IN: 0 A, 0 E, 0 N, 0 F -- Group 99' UNION ALL
 SELECT '2/16/2012 01:37:42 AM -- 2 Errors found in Eligiblity Load -- Group 99' UNION ALL

 SELECT '2/17/2012 12:28:30 AM -- Found file 1776ELIG_20120216.txt for Processing -- Group 1776' UNION ALL
 SELECT '2/17/2012 12:28:30 AM -- File Copied -- Group 1776' UNION ALL
 SELECT '2/17/2012 12:28:30 AM -- 27384 Records IN: 0 A, 0 E, 0 N, 0 F -- Group 1776' UNION ALL
 SELECT '2/17/2012 12:38:40 AM -- 1 Errors found in Eligiblity Load -- Group 1776' UNION ALL

 SELECT '2/17/2012 01:27:32 AM -- Found file 99DODAH_20120216.txt for Processing -- Group 99' UNION ALL
 SELECT '2/17/2012 01:27:32 AM -- File Copied -- Group 99' UNION ALL
 SELECT '2/17/2012 01:27:38 AM -- 12 Records IN: 0 A, 0 E, 0 N, 0 F -- Group 99' UNION ALL
 SELECT '2/17/2012 01:37:42 AM -- 0 Errors found in Eligiblity Load -- Group 99'
;
--===== Solve the problem for multiple days and groups
WITH
cteFindAndParse AS
(
 SELECT [DateTime]    = SUBSTRING(LogEntry,1,21),
        [FileName]    = CASE
                        WHEN SUBSTRING(LogEntry,26,10) = 'Found file'
                        THEN SUBSTRING(LogEntry,37,CHARINDEX(' for',LogEntry)-37)
                        END,
        [GroupNumber] = SUBSTRING(LogEntry,CHARINDEX('-- Group',LogEntry,37)+9,8000),
        [Errors]      = CASE
                        WHEN SUBSTRING(LogEntry,26,10) <> 'Found file'
                        THEN SUBSTRING(LogEntry,CHARINDEX('--',LogEntry)+3,8000)
                        END
   FROM #TempLog
  WHERE SUBSTRING(LogEntry,26,10) = 'Found file'
     OR LogEntry LIKE '%Errors found%'
)
 SELECT [DateTime]    = MIN([DateTime]),
        [FileName]    = MAX([FileName]),
        [GroupNumber],
        [Errors]      = MAX(SUBSTRING([Errors],1,CHARINDEX(' Errors',[Errors])-1))
   FROM cteFindAndParse
  GROUP BY DATEDIFF(dd,0,[DateTime]),[GroupNumber]
  ORDER BY [DateTime],[GroupNumber]
;