--===== Build a long string
DECLARE @InputValue AS VARCHAR(8000)=REPLICATE('          ttttest           daaaaaaaaaaataaaaaaa Abbott',400)
;
--========= Dedupe the letters
       WITH
      E1(N) AS (SELECT 1 FROM (VALUES (1),(1),(1),(1),(1),(1),(1),(1),(1),(1))e0(N))
  ,Tally(N) AS (SELECT TOP (DATALENGTH(@InputValue)) 
                       ROW_NUMBER() OVER (ORDER BY (SELECT a.N)) 
                  FROM E1 a, E1 b, E1 c, E1 d)
SELECT Word = ((SELECT SUBSTRING(@InputValue,t.N,1)
                  FROM Tally t
                 WHERE SUBSTRING(@InputValue,t.N  ,1) COLLATE LATIN1_General_BIN 
                    <> SUBSTRING(@InputValue,t.N+1,1) COLLATE LATIN1_General_BIN
                 ORDER BY t.N
                   FOR XML PATH(''),TYPE).value('.','VARCHAR(8000)'))
;
GO


declare @InputValue as varchar(50)='ttttest',
        @Word varchar(50);

with e1(n) as (select 1 from (values (1),(1),(1),(1),(1),(1),(1),(1),(1),(1))dt(n)),
     eTally(n) as (select row_number() over (order by (select null)) from e1 a cross join e1 b), -- don't need more than a 100 (actually 50)
     pivotletters as (
     select
        n,
        ascii(substring(@InputValue,n,1)) LetterValue,
        substring(@InputValue,n,1) letters,
        rn = n - row_number() over (partition by substring(@InputValue,n,1) order by n)
     from eTally where n <= len(@InputValue)
     )
select @Word = stuff((  select -- min(n), letters  from pivotletters group by letters, rn order by min(n)
                            '' + letters
                        from
                            pivotletters
                        group by
                            letters, rn
                        order by
                            min(n)
                        for xml path(''),TYPE).value('.','varchar(50)'),1,0,'');

select @InputValue, @Word;




DECLARE @INPUT_STR  VARCHAR(500)    =   'WWWWWWHY          DDDDDDDDDDDOOOOOOOOO YYYYYYYYOOOOOOOOOOOOOOOOOUUUUUUUUUU WWWWWWWWWWANNNNNNNNNNNNNTTTTTTT TOOOOOOOOO DOOOOOOOO TTTTTTTTHIIIIIIIIIIISSSSSSS??????????';

;WITH T(N) AS (SELECT N FROM (VALUES (NULL),(NULL),(NULL),(NULL),(NULL),(NULL),(NULL),(NULL),(NULL),(NULL)) AS X(N))
,  NUMS(N) AS (SELECT TOP(LEN(@INPUT_STR)) ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS N FROM T T1,T T2,T T3)
,CHAR_LIST AS
(
    SELECT
        NM.N
       ,SUBSTRING(@INPUT_STR,NM.N,1)    AS TCHAR
    FROM NUMS   NM
)
,COMPARE_CHARS AS
(
    SELECT
        CL.TCHAR
       ,LAG(CL.TCHAR,1,CHAR(0)) OVER 
            (
                ORDER BY CL.N
            ) AS PREV_CHAR
    FROM    CHAR_LIST   CL
)
SELECT
    (SELECT 
        CC.TCHAR
    FROM  COMPARE_CHARS  CC
    WHERE CC.TCHAR <> CC.PREV_CHAR
    FOR XML PATH(''), TYPE).value('.[1]','VARCHAR(500)') AS OUT_STR
;