USE MASTER
GO

DECLARE @CompatLevel TINYINT;
DECLARE @ErrorMessage NVARCHAR(4000)    ; SET @ErrorMessage = '';
DECLARE @ErrorSeverity INTEGER          ; SET @ErrorSeverity = 0;
DECLARE @ErrorState INTEGER             ; SET @ErrorState = 0;
DECLARE @INFORMATION nvarchar(4000)     ; SET @INFORMATION = '';
DECLARE @DATABASENAME NVARCHAR(2000);


DECLARE GET_DATABASES CURSOR
READ_ONLY
FOR SELECT NAME
FROM SYS.DATABASES
WHERE state_desc = 'Online'
 
        
OPEN GET_DATABASES
FETCH NEXT FROM GET_DATABASES INTO @DATABASENAME
WHILE (@@fetch_status = 0)
BEGIN --begin while loop
  
   BEGIN TRY
       -- Set to SINGLE USER MODE
       --EXEC ('ALTER DATABASE '+ '[' + @DATABASENAME + ']' +' SET SINGLE_USER WITH ROLLBACK IMMEDIATE;');
       
       EXEC ('DBCC UPDATEUSAGE '+'('+ @DATABASENAME + ')');
	   SET @INFORMATION = '<<<<< DBCC updateusage on Database [ ' + @DATABASENAME + ' ]  >>>>>';
	    PRINT @INFORMATION;
       
            EXEC ('DBCC checkdb '+'( '+ @DATABASENAME + ' )' + 'WITH NO_INFOMSGS, ALL_ERRORMSGS ');       
       
   		--report change to user       
   	    SET @INFORMATION = '<<<<< DBCC completed on Database [ ' + @DATABASENAME + ' ]  >>>>>';
	    PRINT @INFORMATION;
	    
	    FETCH NEXT FROM GET_DATABASES INTO @DATABASENAME;
   END TRY
   BEGIN CATCH
   	   SELECT @ErrorMessage =  'Failed for database ' + @DATABASENAME + SPACE(2) + CAST(ERROR_NUMBER() AS NVARCHAR) + SPACE(2) +  ERROR_MESSAGE(),
	          @ErrorSeverity = ERROR_SEVERITY(),
		      @ErrorState = ERROR_STATE();
	    
			RAISERROR (@ErrorMessage, -- Message text.
					   @ErrorSeverity, -- Severity.
					   @ErrorState -- State.
					   );
					   
       FETCH NEXT FROM GET_DATABASES INTO @DATABASENAME;
   END CATCH;
      
   --
END --end while loop

CLOSE GET_DATABASES;
DEALLOCATE GET_DATABASES;

go
