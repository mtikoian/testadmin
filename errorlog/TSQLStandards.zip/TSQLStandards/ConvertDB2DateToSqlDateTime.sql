CREATE FUNCTION dbo.ConvertDB2DateToSqlDateTime
        (
        @CscDate CHAR(7)
        )
RETURNS TABLE WITH SCHEMABINDING AS
 RETURN (
         SELECT SqlDateTime = 
                    CAST(
                        STUFF(
                            @CscDate,
                            1,
                            1,
                            CASE LEFT(@CscDate,1) 
                                WHEN '0' THEN '19' 
                                WHEN '1' THEN '20' 
                                ELSE 'BadYear'
                            END
                        ) 
                    AS DATETIME)
        )
;

--===== Create and populate a test table with multiple Csc Dates.
     -- This isn't a part of the solution.  We're just building test data here.
WITH 
cteIsoDates AS
( --=== Build "ISO" dates from '1900-01-01' up to and not including '2100-01-01'
 SELECT TOP 1000
        IsoDate = CONVERT(CHAR(8),DATEADD(dd,ABS(CHECKSUM(NEWID()))%DATEDIFF(dd,'1900','2100'),'1900'),112)
   FROM sys.all_columns ac1
  CROSS JOIN sys.all_columns ac2
) --=== Put both dates in the new table formed on-the-fly (IsoDate included just for grins)
 SELECT IsoDate,
        CscDate = STUFF(IsoDate,1,2,CASE LEFT(IsoDate,2) WHEN '19' THEN '0' ELSE '1' END)
   INTO #MyHead
   FROM cteIsoDates
;

--===== Solve the problem with the iTVF we built earlier
 SELECT mh.IsoDate,
        mh.CscDate,
        cd.SqlDateTime
   FROM #MyHead mh
  CROSS APPLY dbo.ConvertDB2DateToSqlDateTime(CscDate) cd
;

 SELECT IsoDate,
        CscDate,
        SqlDateTime = CAST(STUFF(CscDate,1,1,CASE LEFT(CscDate,1) WHEN '0' THEN '19' WHEN '1' THEN '20' ELSE 'BadYear' END) AS DATETIME)
   FROM #MyHead
;
