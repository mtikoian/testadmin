--=========================================================================
-- start by making a fresh copy of Jeff's Calendar table.
--=========================================================================
IF OBJECT_ID('CodeTest.dbo.Calendar_Copy', 'U') IS NULL 
BEGIN    -- DROP TABLE dbo.Calendar_Copy;
    SELECT 
        cj.DT, cj.DTNext, cj.DTInt, cj.DTSerial, cj.YY, cj.MM, cj.DD, cj.DW, 
        cj.DWOccurance, cj.IsWorkDay, cj.IsHoliday, 
        WorkDayNumber = CAST(NULL AS INT),    --<<== this method relys on NULLs as opposed to 0's.
        cj.HolidayName
        INTO CodeTest.dbo.Calendar_Copy
    FROM
        dbo.Calendar_JM cj;

    -- With the exception of NULL's inplave of zeros,
    -- bring it to a state just prior to the "Observed" code.
    UPDATE cc SET  
        cc.IsWorkDay = 1,
        cc.IsHoliday = 0,
        cc.HolidayName = REPLACE(cc.HolidayName, ' (Observed)', '')
    FROM
        dbo.Calendar_Copy cc
    WHERE 
        cc.HolidayName LIKE '% (Observed)';        

    ALTER TABLE dbo.Calendar_Copy
        ADD CONSTRAINT PK_Calendar_Copy PRIMARY KEY CLUSTERED (DT) WITH FILLFACTOR = 100;
END;


--=========================================================================
-- use the LAG & LEAD windowing functions to update the "Observed" values 
-- in a single refference to the base table. Using a covering index key 
-- prevents a sort operation in the execution plan.
--=========================================================================
WITH
    cte_Observed AS (
        SELECT 
            cc.DW,
            cc.IsHoliday, 
            cc.IsWorkDay,
            cc.HolidayName,
            oIsHoliday = CASE                    -- this is where I was getting beat up by the DATEFIRST = 1  ... I was using 2 & 6 origionally.
                            WHEN cc.DW = 1 AND LAG(cc.IsHoliday, 1, cc.IsHoliday) OVER (ORDER BY cc.DT) = 1 THEN 1
                            WHEN cc.DW = 5 AND LEAD(cc.IsHoliday, 1, cc.IsHoliday) OVER (ORDER BY cc.DT) = 1 THEN 1
                            ELSE cc.IsHoliday
                        END,
            oIsWorkDay = CASE 
                            WHEN cc.DW = 1 AND LAG(cc.IsHoliday, 1, cc.IsHoliday) OVER (ORDER BY cc.DT) = 1 THEN 0
                            WHEN cc.DW = 5 AND LEAD(cc.IsHoliday, 1, cc.IsHoliday) OVER (ORDER BY cc.DT) = 1 THEN 0
                            ELSE cc.IsWorkDay
                        END,
            oHolidayName = CASE 
                            WHEN cc.DW = 1 THEN ISNULL(NULLIF(LAG(cc.HolidayName, 1, cc.HolidayName) OVER (ORDER BY cc.DT), '') + ' (Observed)', cc.HolidayName)
                            WHEN cc.DW = 5 THEN ISNULL(NULLIF(LEAD(cc.HolidayName, 1, cc.HolidayName) OVER (ORDER BY cc.DT), '') + ' (Observed)', cc.HolidayName)
                            ELSE cc.HolidayName
                        END 
        FROM
            dbo.Calendar_Copy cc
        )
UPDATE o SET 
    o.IsHoliday = o.oIsHoliday,
    o.IsWorkDay = o.oIsWorkDay,
    o.HolidayName = o.oHolidayName
FROM
    cte_Observed o
WHERE 
    o.oIsHoliday = 1
    AND o.DW IN (1, 5);


--=========================================================================
-- start by filling the WorkDayNumber w/ ROW_NUMBER() where IsWorkDay = 1
-- and leaving non-workdays NULL. 
--=========================================================================
WITH 
    cte_WorkDayNumberFill AS (
        SELECT 
            cc.WorkDayNumber,
            RN = ROW_NUMBER() OVER (ORDER BY cc.DT)
        FROM
            dbo.Calendar_Copy cc
        WHERE 
            cc.IsWorkDay = 1
        )
UPDATE wf SET  
    wf.WorkDayNumber = wf.RN
FROM
    cte_WorkDayNumberFill wf;

--=========================================================================
-- Smear the over the NULL values using MAX() in a window frame.
--=========================================================================
WITH 
    cte_WorkDayNumberSmear AS (
        SELECT
            cc.WorkDayNumber,
            wdns = MAX(cc.WorkDayNumber) OVER (ORDER BY cc.DT ROWS UNBOUNDED PRECEDING)
        FROM
            dbo.Calendar_Copy cc
        )
UPDATE ws SET  
    ws.WorkDayNumber = ISNULL(ws.wdns, 0)
FROM
    cte_WorkDayNumberSmear ws
WHERE 
    ws.WorkDayNumber IS NULL;

--=========================================================================
-- The net result...
--=========================================================================
SELECT 
    cc.DT, cc.DTNext, cc.DTInt, cc.DTSerial, cc.YY, cc.MM, cc.DD, cc.DW, 
    cc.DWOccurance, cc.IsWorkDay, cc.IsHoliday, cc.WorkDayNumber, cc.HolidayName
FROM
    dbo.Calendar_Copy cc;