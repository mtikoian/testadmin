create function dbo.getFY(@date datetime, @FYstartmonth tinyint, @FYstartday tinyint)
returns smallint
as
begin
return year(dateadd(day,1-@FYstartday,dateadd(month,1-@FYstartmonth,@date)))
end
go
declare @D table(d datetime)
declare @FYstartmonth int, @FYstartday int, @i int
select @i = 1
while @i < 366
begin
insert @D select @i + 38715
select @i = @i + 1
end
select d, dbo.getFY(d,4,1) fy from @D
go
drop function dbo.getFY
