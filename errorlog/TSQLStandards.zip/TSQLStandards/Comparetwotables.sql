--composite primary key

DECLARE @SQL nvarchar(max)
SELECT @SQL = N'SELECT H.id' + CHAR(10)
  + STUFF(( SELECT CHAR(10) + CHAR(9) + ',ISNULL( NULLIF( H.' + QUOTENAME(COLUMN_NAME) + ', H2.'  + QUOTENAME(COLUMN_NAME) + '), '''') AS '+ QUOTENAME(COLUMN_NAME) + 
        + ',ISNULL( NULLIF( H2.' + QUOTENAME(COLUMN_NAME) + ', H.'  + QUOTENAME(COLUMN_NAME) + '), '''')'
    FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_NAME = 'company'
    AND ORDINAL_POSITION > 1
    FOR XML PATH(''), TYPE).value('./text()[1]', 'varchar(max)'), 1, 1, '')
  + N'FROM company H JOIN company2 H2 ON h.hvaccompanyid= h2.hvaccompanyid and h.brandfamilyid = h2.brandfamilyid' + CHAR(10)
  + STUFF(( SELECT 'OR H.' + QUOTENAME(COLUMN_NAME) + '<> H2.'  + QUOTENAME(COLUMN_NAME) + CHAR(10)
    FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_NAME = 'company2'
    AND ORDINAL_POSITION > 1
    FOR XML PATH(''), TYPE).value('./text()[1]', 'varchar(max)'), 1, 2, N'WHERE ')
--PRINT @SQL
EXEC( @SQL);


-- primary key

DECLARE @SQL nvarchar(max)
SELECT @SQL = N'SELECT H.id' + CHAR(10)
  + STUFF(( SELECT CHAR(10) + CHAR(9) + ',ISNULL( NULLIF( H.' + QUOTENAME(COLUMN_NAME) + ', H2.'  + QUOTENAME(COLUMN_NAME) + '), '''') AS '+ QUOTENAME(COLUMN_NAME) + 
        + ',ISNULL( NULLIF( H2.' + QUOTENAME(COLUMN_NAME) + ', H.'  + QUOTENAME(COLUMN_NAME) + '), '''')'
    FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_NAME = 'company'
    AND ORDINAL_POSITION > 1
    FOR XML PATH(''), TYPE).value('./text()[1]', 'varchar(max)'), 1, 1, '')
  + N'FROM company H JOIN company2 H2 ON h.id= h2.id ' + CHAR(10)
  + STUFF(( SELECT 'OR H.' + QUOTENAME(COLUMN_NAME) + '<> H2.'  + QUOTENAME(COLUMN_NAME) + CHAR(10)
    FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_NAME = 'company2'
    AND ORDINAL_POSITION > 1
    FOR XML PATH(''), TYPE).value('./text()[1]', 'varchar(max)'), 1, 2, N'WHERE ')
--PRINT @SQL
EXEC( @SQL);