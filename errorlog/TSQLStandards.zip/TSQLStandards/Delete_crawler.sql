--===== Example "Delete Crawler" written by Jeff Moden
--===== Define the cutoff date with a time of "midnight" or, if you will,
     -- define the cutoff date with no time so we only delete whole days.
DECLARE @CutoffDate DATETIME
 SELECT @CutoffDate = DATEADD(dd,DATEDIFF(dd,0,GETDATE()),-94)

--===== Limit all further queries, including deletes, to 25,000 rows
     -- (about 1 second worth of deletes, like I said before)
    SET ROWCOUNT 25000

--===== See if any rows qualify for deletion.  If even just one exists,
     -- then there's work to do and @@ROWCOUNT will be > 0.
     -- DO NOT PUT ANY CODE BETWEEN THIS SELECT AND THE WHILE LOOP OR
     -- YOU'LL MESS UP THE ROWCOUNT FOR THE WHILE LOOP
 SELECT TOP 1 1 FROM dbo.JBMTestDetail WHERE Time_Stamp < @CutoffDate

--===== If the rowcount from the above is greater than 0,
     -- then delete 25,000 rows at a time until there's nothing
     -- left to delete
  WHILE @@ROWCOUNT > 0
  BEGIN 
        --===== Just a "marker" to separate the loop in the output
          PRINT REPLICATE('=',78) 

        --===== This delay gives other processes breathing room 
        WAITFOR DELAY '00:00:10' 

        --===== Do the delete. Will be limited by the SET ROWCOUNT above.
             -- DO NOT PUT ANY CODE BETWEEN THIS DELETE AND THE "END" OR 
             -- YOU'LL MESS UP THE ROWCOUNT FOR THE WHILE LOOP.
         DELETE dbo.JBMTestDetail WITH (TABLOCKX)
          WHERE Time_Stamp < @CutoffDate
    END

--===== Restore the ability to process more than 25,000 rows
    SET ROWCOUNT 0