 CREATE FUNCTION dbo.GetNextMondays 
        (@SomeDT DATETIME)
RETURNS TABLE WITH SCHEMABINDING AS
 RETURN 
   WITH cteMondays AS
(
 SELECT  ThisMonthMonday = DATEADD(dd,DATEDIFF(dd,'1753',DATEADD(mm,DATEDIFF(mm,'1753',@SomeDT)  ,'1753')+6)/7*7,'1753')
        ,NextMonthMonday = DATEADD(dd,DATEDIFF(dd,'1753',DATEADD(mm,DATEDIFF(mm,'1753',@SomeDT)+1,'1753')+6)/7*7,'1753')
)
 SELECT  DayDate          = @SomeDT
        ,DayNumber        = (DATEDIFF(dd,'1753',@SomeDT))%7+1
        ,NameOfDay        = DATENAME(dw,@SomeDT)
        ,NextWeekMonday   = DATEADD(dd,DATEDIFF(dd,'1753',@SomeDT)/7*7+7,'1753')
        ,NextMonthMonday  = CASE
                            WHEN @SomeDT >= ThisMonthMonday
                            THEN NextMonthMonday
                            ELSE ThisMonthMonday
                            END
   FROM cteMondays
;