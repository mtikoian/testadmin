--Replace the first charatcer in a String
CREATE TABLE #Test (Dsc VARCHAR(50));

INSERT #Test
(
  Dsc
)
VALUES
('0lzdhksd')
,('abc');

SELECT *
FROM #Test t;

UPDATE #Test
SET  Dsc = STUFF(Dsc, 1, 1, '27')
WHERE  Dsc LIKE '0%';

SELECT *
FROM #Test t;












--======================================
-- Create and populate a test table.
-- THIS IS NOT PART OF THE SOLUTION!!!
--======================================
--===== Create the test table
DECLARE @Demo TABLE
        (
        Month INT, 
        Count INT
        )

--===== Populate the test table with
     -- sample data from the post.
 INSERT INTO @Demo
        (Month,Count)
 SELECT 1,10 UNION ALL
 SELECT 2,20 UNION ALL
 SELECT 5,50 UNION ALL
 SELECT 8,90 UNION ALL
 SELECT 11,100 UNION ALL
 SELECT 12,1000

--======================================
-- HERE'S THE SOLUTION!
--======================================
 SELECT t.N,ISNULL(d.Count,0) AS Count
   FROM dbo.Tally t
   LEFT OUTER JOIN @Demo d
     ON t.N = d.Month
  WHERE t.N BETWEEN 1 AND 12
  
  
  
 DECLARE @text VARCHAR(100) = 'abc_def_cet_qwe '
DECLARE @start_index INT
DECLARE @end_index INT

SELECT @start_index = CHARINDEX('_', @text, 1)

SELECT @end_index = CHARINDEX('_', @text, CHARINDEX('_', @text, 1) + 1)

SELECT SUBSTRING(@text, @start_index + 1, @end_index - @start_index - 1) 

Select SubString(@string, (CHARINDEX('_', @string, 0) + 1), 
		(CharIndex('_', RIGHT(@string, (LEN(@string) - (CharIndex('_', @string, 0)))), 0) - 1)) As NewString

--test data		
		
		
/**********************************************************************************************************************
 Purpose:
 Create a voluminous test table with various types of highly randomized data.

 --Jeff Moden 
**********************************************************************************************************************/
--===== Conditionally drop the test table to make reruns easier
     IF OBJECT_ID('dbo.JBMTest','U') IS NOT NULL
        DROP TABLE dbo.JBMTest
;
--===== Create and populate a 1,000,000 row test table.
     -- "SomeID" has a range of 1 to 1,000,000 unique numbers
     -- "SomeInt" has a range of 1 to 50,000 non-unique numbers
     -- "SomeLetters2" has a range of "AA" to "ZZ" non-unique 2 character strings
     -- "SomeMoney has a range of 0.00 to 100.00 non-unique numbers
     -- "SomeDateTime" has a range of  >=01/01/2000 and <01/01/2020 non-unique date/times
     -- "SomeDate" has a range of  >=01/01/2000 and <01/01/2020 non-unique "whole dates"
     -- "SomeName" contains random characters at random lengths from 2 to 20 characters
 SELECT TOP 1000000
        SomeID       = IDENTITY(INT,1,1),
        SomeInt      = ABS(CHECKSUM(NEWID())) % 50000 + 1,
        SomeLetters2 = CHAR(ABS(CHECKSUM(NEWID())) % (ASCII('Z')-ASCII('A')+1) +ASCII('A'))
                     + CHAR(ABS(CHECKSUM(NEWID())) % (ASCII('Z')-ASCII('A')+1) +ASCII('A')),
        SomeMoney    = CAST(RAND(CHECKSUM(NEWID())) * 100 AS DECIMAL(9,2)), --Note rounding
        SomeDateTime = RAND(CHECKSUM(NEWID())) * DATEDIFF(dd,'2000','2020') + CAST('2000' AS DATETIME),
        SomeDate     = ABS (CHECKSUM(NEWID())) % DATEDIFF(dd,'2000','2020') + CAST('2000' AS DATETIME),
        SomeName     = RIGHT(NEWID(),ABS(CHECKSUM(NEWID())) % 19 + 2)
   INTO dbo.JBMTest
   FROM sys.all_columns ac1
  CROSS JOIN sys.all_columns ac2
; 
  ALTER TABLE dbo.JBMTest
    ADD CONSTRAINT PK_JBMTest PRIMARY KEY CLUSTERED (SomeID) WITH FILLFACTOR = 90		
    
    
 ---crosstab example 
 
 
 CREATE TABLE #test (LOB varchar(10), 
                    attribute varchar(10), 
                    value varchar(10)
                   );

INSERT INTO #test VALUES 
('MNS','XLO','MS'),
('MNS','XLO','ML'),
('MNS','BPL','MSUP%'),
('MNS','BPL','MSEL%');

--What's the desired result for the above?

TRUNCATE TABLE #test;

INSERT INTO #test VALUES 
('MNS','XLO','MS'),
('MNS','XLO','ML'),
('MNS','XLO','MR'),
('MNS','BPL','MSUP%'),
('MNS','BPL','MSEL%');
 ;WITH ExtraGroup AS (
	SELECT LOB, Attribute, Value, grp = ROW_NUMBER() OVER (PARTITION BY LOB, Attribute ORDER BY Value)
	FROM #test 
),
CrossTab AS (
	SELECT 
		LOB, 
		[XLO] = MAX(CASE WHEN Attribute = 'XLO' THEN Value ELSE '' END),
		[BPL] = MAX(CASE WHEN Attribute = 'BPL' THEN Value ELSE NULL END),
		[CAR] = MAX(CASE WHEN Attribute = 'CAR' THEN Value ELSE '' END),
		[RA] = MAX(CASE WHEN Attribute = 'RA' THEN Value ELSE '' END),
		[ARA] = MAX(CASE WHEN Attribute = 'ARA' THEN Value ELSE NULL END),
		[PT] = MAX(CASE WHEN Attribute = 'PT' THEN Value ELSE '' END),
		[COCM] = MAX(CASE WHEN Attribute = 'COCM' THEN Value ELSE '' END),
		[CBRAM] = MAX(CASE WHEN Attribute = 'CBRAM' THEN Value ELSE '' END),
		[EFI] = MAX(CASE WHEN Attribute = 'EFI' THEN Value ELSE '' END),
		[DP] = MAX(CASE WHEN Attribute = 'DP' THEN Value ELSE '' END),
		[CVG] = MAX(CASE WHEN Attribute = 'CVG' THEN Value ELSE NULL END),
		[OP] = MAX(CASE WHEN Attribute = 'OP' THEN Value ELSE '' END),
		[HX] = MAX(CASE WHEN Attribute = 'HX' THEN Value ELSE '' END),
		[MHPD] = MAX(CASE WHEN Attribute = 'MHPD' THEN Value ELSE NULL END),
		[SECTION] = MAX(CASE WHEN Attribute = 'SECTION' THEN Value ELSE NULL END),
		[COBA] = MAX(CASE WHEN Attribute = 'COBA' THEN Value ELSE NULL END),
		[HMS] = MAX(CASE WHEN Attribute = 'HMS' THEN Value ELSE NULL END),
		[BDM] = MAX(CASE WHEN Attribute = 'BDM' THEN Value ELSE NULL END),
		[MMM] = MAX(CASE WHEN Attribute = 'MMM' THEN Value ELSE NULL END),
		[ANM] = MAX(CASE WHEN Attribute = 'ANM' THEN Value ELSE NULL END),
		[CSM] = MAX(CASE WHEN Attribute = 'CSM' THEN Value ELSE NULL END),
		[ES] = MAX(CASE WHEN Attribute = 'ES' THEN Value ELSE NULL END),
		[WP] = MAX(CASE WHEN Attribute = 'WP' THEN Value ELSE NULL END)
	FROM ExtraGroup 
	GROUP BY LOB,grp
)
SELECT DISTINCT * -- there are dupes
FROM CrossTab
ORDER BY LOB
--Splitting a string into fields
;WITH SampleData AS (
SELECT MyString = 'Scrap : Part Assembly : Surface Defects : Scratch' UNION ALL
SELECT 'Scrap : Part Assembly : Components : Wrong Components' UNION ALL
SELECT 'Scrap : Part Assembly : Other : Change Over' UNION ALL
SELECT 'Repair : Punching : Surface Damages : Crack')

SELECT 
	MyString, 
	Element1 = PARSENAME(REPLACE(MyString,' : ','.'),4), 
	Element2 = PARSENAME(REPLACE(MyString,' : ','.'),3), 
	Element3 = PARSENAME(REPLACE(MyString,' : ','.'),2), 
	Element4 = PARSENAME(REPLACE(MyString,' : ','.'),1) 
FROM SampleData

-- split string to muliple columns 
;with cteData(string) as (
  select '172.26.248.8,Fe80::7033:acba:a4bd:f874' union all
  select '172.26.248.154,Fe90::7033:acba:a4bd:f874'
)
select d.string,
    MAX(case when s.ItemNumber = 1 then s.Item end) ip_address,
    MAX(case when s.ItemNumber = 2 then s.Item end) mac_address
  from cteData d
    cross apply f_DelimitedSplit8K(d.string, ',') s
  group by d.string;
  
  --cross tab
  ;WITH SAMPLE_DATA (ColumnA,ColumnB) AS
(
    SELECT 1 AS  ColumnA,88 AS ColumnB UNION ALL
     SELECT 2, 99 UNION ALL
     SELECT 3, 112
)

SELECT
    MAX(CASE WHEN SD.ColumnA = 1 THEN ColumnB END) AS C1
   ,MAX(CASE WHEN SD.ColumnA = 2 THEN ColumnB END) AS C2
   ,MAX(CASE WHEN SD.ColumnA = 3 THEN ColumnB END) AS C3
FROM SAMPLE_DATA SD;

--extract values from a column which has multiple delimiters?
--http://www.sqlservercentral.com/Forums/Topic1630371-1292-1.aspx


--pivot
DECLARE @Tab TABLE
(
  Item        VARCHAR(15),
  DateCreated DATETIME
)

INSERT INTO @Tab ( Item , DateCreated )
          SELECT 'item1',GETDATE()
UNION ALL SELECT 'item1',DATEADD( DD,1, GETDATE())
UNION ALL SELECT 'item1',DATEADD( DD,5, GETDATE())
UNION ALL SELECT 'item1',DATEADD( DD,4, GETDATE())
UNION ALL SELECT 'item1',DATEADD( DD,7, GETDATE())
UNION ALL SELECT 'item1',DATEADD( DD,3, GETDATE())
UNION ALL SELECT 'item1',DATEADD( DD,2, GETDATE())
UNION ALL SELECT 'item2',DATEADD( DD,6, GETDATE())
UNION ALL SELECT 'item2',DATEADD( DD,1, GETDATE())
UNION ALL SELECT 'item2',DATEADD( DD,2, GETDATE())
UNION ALL SELECT 'item3',GETDATE()

 
; WITH CTE0 AS
(
   SELECT   RN = ROW_NUMBER() OVER (PARTITION BY Item ORDER BY DateCreated )
          , Item
          , DateCreated
   FROM @Tab
) -- select * from CTE0
SELECT 
      Item ,
      [1] AS Date1 ,
      [2] AS Date2 ,
      [3] AS Date3 ,
      [4] AS Date4 ,
      [5] AS Date5 
FROM
   ( 
	  SELECT RN,Item, DateCreated FROM CTE0 WHERE RN <= 5 
   )   PIVOT_TABLE
PIVOT 
  (
    MAX(DateCreated) FOR RN IN ( [1] ,[2], [3] , [4] , [5] )
  )  PIVOT_HANDLE
  
  --unpivot
  
  --===== This just creates a test table and isn't part of the solution.
     -- Most folks want to see the data you post in this form because
     -- they like to test their solutions before posting them. See the
     -- first link in my signature below for an easy way to do this.
     -- It'll also help get your question answered much quicker.
     IF OBJECT_ID('TempDB..#TestTable','U') IS NOT NULL
        DROP TABLE #TestTable;

 CREATE TABLE #TestTable 
        (
        channel     VARCHAR(3),
        line_of_bus VARCHAR(2),
        prod_nm     VARCHAR(20)
        );

 INSERT INTO #TestTable
        (channel,line_of_bus,prod_nm)
 SELECT 'all', 'C1', 'last year p&c' UNION ALL
 SELECT 'all', 'D1', 'busi module'   UNION ALL
 SELECT 'all', 'd1', 'bus term'      UNION ALL
 SELECT 'IA' , 'c1', 'exp cum total' UNION ALL
 SELECT 'IA' , 'c1', 'exp cum total' UNION ALL
 SELECT 'IA' , 'c1', 'exp cum total' UNION ALL
 SELECT 'IA' , 'D1', 'busi module';
GO

--===== This is the solution I'd use in 2k5.
     -- This works but won't allow the use of a table alias on "Channel".
     -- It's also the fastest method that you can use in SQL Server 2005.
WITH
cteFixDataType AS
(
 SELECT ROW_NUMBER() OVER (ORDER BY Channel,line_of_bus,prod_nm) AS RowNum,
        Channel,
        CAST(line_of_bus AS VARCHAR(20)) AS line_of_bus,
        prod_nm
   FROM #TestTable
)
 SELECT Channel, --can't use fdt table alias on this or BOOM!
        up.ColumnValue AS line_of_bus
   FROM cteFixDataType fdt
UNPIVOT (ColumnValue FOR ColName IN (fdt.line_of_bus, fdt.prod_nm)) AS up;


---split strings with multiple 
declare @test varchar(50);
set @test = 'AA : 11, AB : 12, AC : 13';

SELECT ds1.ItemNumber,
       Property = MAX(CASE WHEN ds2.ItemNumber % 2 = 1 THEN ds2.Item ELSE NULL END),
       Value    = MAX(CASE WHEN ds2.ItemNumber % 2 = 0 THEN ds2.Item ELSE NULL END)
  FROM dbo.f_DelimitedSplit8K(@test, ',') ds1
       CROSS APPLY dbo.f_DelimitedSplit8K(ltrim(rtrim(ds1.Item)), ':') ds2
 GROUP BY ds1.ItemNumber
 ORDER BY ds1.ItemNumber;
 
 -- DROP TABLE #FileName
--===== Create a test table with some normal and "odd" file/path names.
 SELECT FileName = 'C:/Location/Folder/Subfolder/filename20130101.xxx'
   INTO #FileName  UNION ALL
 SELECT FileName = 'C:/Location/Folder/Subfolder/filename20130102' UNION ALL
 SELECT FileName = 'filename20130103' UNION ALL
 SELECT FileName = 'filename20130104.xxx' UNION ALL
 SELECT FileName = '20130105.xxx' UNION ALL
 SELECT FileName = '20130106' UNION ALL
 SELECT FileName = '20130107def' UNION ALL
 SELECT FileName = 'abc20130108def' UNION ALL
 SELECT FileName = 'abc20130109def.xxx' UNION ALL
 SELECT FileName = '123abc20130110def.xxx' UNION ALL
 SELECT FileName = 'abcdef.xxx' --will not show up because has no numbers
;
--===== Get just the last set of numbers.
 SELECT fn.FileName, DateOnly = LEFT(FromTheNumbers,ISNULL(NULLIF(PATINDEX('%[0-9][^0-9]%',FromTheNumbers),0),8000))
   FROM #FileName fn
  CROSS APPLY (SELECT RIGHT(FileName,ISNULL(NULLIF(PATINDEX('%[0-9][^0-9]%',REVERSE(FileName)),0),8000))) ca (FromTheNumbers)
  WHERE fn.FileName LIKE '%[0-9]%'
;

--bcp  export
declare @exists int
exec sys.xp_fileexist '\\dt-sc2\shares\Data.txt', @exists OUTPUT
if @exists = 1 
begin
   SET @Cmd = 'DEL \\dt-sc2\shares\Data.txt'
    EXEC Master.dbo.xp_CmdShell @Cmd
end


--cross tab 
CREATE TABLE #Temp (xType varchar(5), Name1 VARCHAR(15), Qty INT)
GO
Insert #Temp
Select 'Dev','Test',12 union all
Select 'Prod','Test',15 union all
Select 'Dev','Test12',6 union all
Select 'Prod','Test12',8 union all
Select 'Dev','Test34',77 union all
Select 'Prod','Test34',98 union all
Select 'Dev','Test56',57 union all
Select 'Prod','Test56',57 
GO
;
WITH 
ctePreAgg AS
(
 SELECT Name1,
        SUM(CASE WHEN xType = 'Dev'  THEN Qty ELSE 0 END) AS Dev,
        SUM(CASE WHEN xType = 'Prod' THEN Qty ELSE 0 END) AS Prod
   FROM #Temp
  GROUP BY Name1
)
 SELECT Name1, Dev, Prod, Dev-Prod AS Diff
   FROM ctePreAgg
 
 
 --replace space  
   declare @Original varchar(100) = 'Alternative Apparel     The Stevie Wrap in    Antique White,Tops  (L/S)  for Women'

select replace(replace(replace(@Original, '(', ' '), ')', ' '), '/', ' '), 
REPLACE(
            REPLACE(
                REPLACE(
                    LTRIM(RTRIM(replace(replace(replace(@Original, '(', ' '), ')', ' '), '/', ' ')))
                ,'  ',' '+CHAR(7))  --Changes 2 spaces to the OX model
            ,CHAR(7)+' ','')        --Changes the XO model to nothing
        ,CHAR(7),'') AS CleanString --Changes the remaining X's to nothing
        
        
        --string pattern
        IF OBJECT_ID('TEMPDB..#STRING_PARENS') IS NOT NULL
DROP TABLE #STRING_PARENS
CREATE TABLE #STRING_PARENS
(
   STRING VARCHAR(64)
)

INSERT INTO #STRING_PARENS (STRING)
SELECT 'SAVE ENVIRONMENT (AND) SAVE WORLD'
UNION ALL
SELECT '(WE) HAVE TO SAVE OUR PLANET'
UNION ALL
SELECT 'SAVE TIGERS OF INDIA (WE LOVE THEM,DONT WE?)'
UNION ALL
SELECT 'LETS NOT FIGHT FOR PEACE , LETS BE AT PEACE ('
UNION ALL
SELECT ') WAR IS NOT ANSWER '
UNION ALL
SELECT 'LOVE ALL HATE NONE'


SELECT 
       -- THE BELOW WILL PULL OFF THE DATA TO THE LEFT OF THE '('
       LEFT(STRING ,(CHARINDEX('(',STRING)-1))
       -- THE BELOW WILL PULL OFF THE DATA BETWEEN '(' AND ')'
     + SUBSTRING(STRING,(CHARINDEX('(',STRING) + 1 ) ,(CHARINDEX(')',STRING) - CHARINDEX('(',STRING) - 1 ))      
       -- THE BELOW WILL PULL OFF THE DATA TO THE RIGHT OF THE ')'
     + RIGHT(STRING ,(DATALENGTH(STRING) - CHARINDEX(')',STRING)))
     -- ALIAS THIS WITH A NICE NAME 
     AS PARENS_STRIPED_STRING
FROM #STRING_PARENS
WHERE 
    --MAKE SURE SOME JUNK ROWS ARE TAKEN INTO ACCOUNT
    CHARINDEX('(',STRING )> 0 
   AND 
    CHARINDEX(')',STRING) > CHARINDEX('(',STRING)

UNION ALL

-- NOW, LETS PUT TOGETHER THE JUNK AS WELL, SHALL WE??
SELECT STRING AS PARENS_STRIPED_STRING 
  FROM #STRING_PARENS
WHERE 
    CHARINDEX('(',STRING ) = 0 
   OR 
    CHARINDEX(')',STRING) < CHARINDEX('(',STRING)
   OR
    CHARINDEX(')',STRING ) = 0 


IF OBJECT_ID('TEMPDB..#STRING_PARENS') IS NOT NULL
DROP TABLE #STRING_PARENS

--Quaterly dates
declare @StartDate datetime
set @StartDate = DateAdd(month, -1, DateAdd(year, DATEDIFF(year, 0, GetDate()), 0))

-- See Jeff Moden's article 
-- The "Numbers" or "Tally" Table: What it is and how it replaces a loop.
-- at http://www.sqlservercentral.com/articles/T-SQL/62867/.
-- NOTE! A permanent tally table will always be MUCH faster 
-- than this inline one. See the above article to create your own!
;WITH 
Tens     (N) AS (SELECT 0 UNION ALL SELECT 0 UNION ALL SELECT 0 UNION ALL 
                 SELECT 0 UNION ALL SELECT 0 UNION ALL SELECT 0 UNION ALL 
                 SELECT 0 UNION ALL SELECT 0 UNION ALL SELECT 0 UNION ALL SELECT 0), 
Tally    (N) AS (SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 0)) FROM Tens t1 CROSS JOIN Tens t2),
Dates        AS (SELECT MyDate = DateAdd(month, N, @StartDate) FROM Tally ),
Quarters     AS (SELECT MyDate, MyYear = YEAR(MyDate), Qtr = DatePart(quarter, MyDate)
                   FROM Dates)
SELECT MyYear, Qtr,
       QtrStartDate = MIN(MyDate),
       QtrEndDate = MAX(DateAdd(ms, -3, DateAdd(month, 1, MyDate)))
  FROM Quarters       
 GROUP BY MyYear, Qtr
 ORDER BY MyYear, Qtr
 
 
 
--crosstab

with SampleData as (
select
    UserID,
    WhatTechnology
from (
values (1,'home,car'),
       (2,'home,car,dj'),
       (3,''),
       (4,'navigation')
)dt(UserID,WhatTechnology))
select
    sd.UserID,
    max(case ds.Item when 'home' then 'Y' else 'N' end) as home,
    max(case ds.Item when 'car' then 'Y' else 'N' end) as car,
    max(case ds.Item when 'dj' then 'Y' else 'N' end) as dj,
    max(case ds.Item when 'navigation' then 'Y' else 'N' end) as navigation
from
    SampleData sd
    cross apply dbo.DelimitedSplit8k(sd.WhatTechnology,',') ds
group by
    sd.UserID;
    
    
    --Reset identity column 
If @skipident = 'NO'
If exists(
SELECT * FROM information_schema.columns 
WHERE COLUMNPROPERTY(OBJECT_ID( 
QUOTENAME(table_schema)+'.'+QUOTENAME(@tableName)), 
column_name,'IsIdentity')=1
) 
begin
set @identInitValue=1
set @identInitValue=IDENT_SEED(@tableOwner + '.' + @tableName)
DBCC CHECKIDENT (@tableName, RESEED, @identInitValue)
end

checkpoint
End

--SQL to split a non delimited string into delimited string
declare @string VARCHAR(100)
SET @string = '12345'

;WITH
TENS      (N) AS (SELECT 0 UNION ALL SELECT 0 UNION ALL SELECT 0 UNION ALL 
                  SELECT 0 UNION ALL SELECT 0 UNION ALL SELECT 0 UNION ALL 
                  SELECT 0 UNION ALL SELECT 0 UNION ALL SELECT 0 UNION ALL SELECT 0),
THOUSANDS (N) AS (SELECT 1 FROM TENS t1 CROSS JOIN TENS t2 CROSS JOIN TENS t3),
TALLY     (N) AS (SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 0)) FROM THOUSANDS)

select STUFF( 
(SELECT ','+SUBSTRING(@string,N,1) 
FROM TALLY T_Outer
WHERE N <= LEN(@string)
FOR XML PATH('') ),1 ,1 ,'') Concat_Values


--inclause alternative
USE Northwind

DECLARE @IdList VARCHAR(8000)
    SET @IdList = '1,25,33,64,77'
 SELECT *
   FROM Products p,
        (--==== Derived table "s" returns split values
         SELECT Val = SUBSTRING(','+@IdList+',', t.N+1, CHARINDEX(',', ','+@IdList+',', t.N+1)-t.N-1)
           FROM dbo.Tally t
          WHERE SUBSTRING(','+@IdList+',', t.N, 1) = ',' 
            AND t.N < LEN(','+@IdList+',')) s
  WHERE p.ProductID = s.Val
  
 --calculating quarter
 DECLARE @StartFY DATETIME,
        @EndFY DATETIME
;
 SELECT @StartFY = '2012',
        @EndFY   = '2013'
;
 SELECT QtrStartDate     = DATEADD(qq,t.N+1,@StartFY),
	NextQtrStartDate = DATEADD(qq,t.N+2,@StartFY),
	Qtr = t.N%4+1
   FROM dbo.Tally t
  WHERE t.N BETWEEN 0 AND (DATEDIFF(yy,@StartFY,@EndFY)+1)*4-1
  ORDER BY t.N
;


--Count the number of spaces in a field
DECLARE @S VARCHAR(30)
SET @S='99202 10060 99000 A6402'

SELECT LEN(@S)-LEN(REPLACE(@S,' ','')) AS NumberOfSpaces


--date

DECLARE @TheDate DATETIME
SET @TheDate = '1994-08-01 00:13:00.000'

select dateadd(dd, datediff(dd,0, @TheDate),0)

--bcp out

DECLARE
@FLAGS varchar(50) = ' -c -t, -T -S ' + @@servername,  --replace -t, with -t\0 if csv not wanted
@MYPATH nvarchar(500) = 'C:\Users\Public\Documents\', --NB: use a folder sqlserveragent can access
@HEADERFILE nvarchar(255) = 'MyHeaderFile.txt',
@BODYFILE nvarchar(255) = 'MyBodyFile.txt',
@MERGEDFILE varchar(255) = 'MyMergedFile.txt', --can also be .csv for spreadsheet retrieval by users
@SQL varchar(4000),
@CMD varchar(8000)

--output header file
SET @SQL = 'SELECT ''col1'',''col2'',''col3''' 
SET @CMD = 'bcp "' + @SQL + '" queryout ' + @MYPATH + @HEADERFILE + @FLAGS  
EXEC master..xp_cmdshell @CMD  --,no_output --un-comment when done debugging 

--output body file
SET @SQL = 'SELECT ''red'',''black'',''blue'' UNION SELECT ''soap'',''lard'',''honey'''
SET @CMD = 'bcp "' + @SQL + '" queryout ' + @MYPATH + @BODYFILE + @FLAGS  
EXEC master..xp_cmdshell @CMD,no_output 

--merge files 
SET @CMD = 'copy /b ' + @MYPATH + @HEADERFILE + '+' + @MYPATH + @BODYFILE + ' ' + @MYPATH + @MERGEDFILE 
EXEC master..xp_cmdshell @CMD,no_output 

--Find Number Falls Between two dates
Declare @FrDate datetime,@ToDate datetime
Set @FrDate ='2010-09-28 17:38:58.577' 
Set @ToDate ='2011-02-01 17:38:58.577';

-- See Jeff Moden's article 
-- The "Numbers" or "Tally" Table: What it is and how it replaces a loop.
-- at http://www.sqlservercentral.com/articles/T-SQL/62867/.
-- NOTE! A permanent tally table will always be MUCH faster 
-- than this inline one. See the above article to create your own!
;WITH 
Tens     (N) AS (SELECT 0 UNION ALL SELECT 0 UNION ALL SELECT 0 UNION ALL 
                 SELECT 0 UNION ALL SELECT 0 UNION ALL SELECT 0 UNION ALL 
                 SELECT 0 UNION ALL SELECT 0 UNION ALL SELECT 0 UNION ALL SELECT 0), 
Thousands(N) AS (SELECT 1 FROM Tens t1 CROSS JOIN Tens t2 CROSS JOIN Tens t3), 
Millions (N) AS (SELECT 1 FROM Thousands t1 CROSS JOIN Thousands t2), 
Tally    (N) AS (SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 0)) FROM Millions)
SELECT DISTINCT MONTH(DateAdd(month, N-1, @FrDate))--, DATEADD(month, N-1, @FrDate)
  FROM Tally
 WHERE N <= DATEDIFF(month, @FrDate, @ToDate)+1;
 
 
 
--Number of days between two dates, grouped by month 
 
 DECLARE @StartDate datetime,
        @EndDate   datetime,
        @days      int;
SET @StartDate = '20110129';
SET @EndDate   = '20110505';

-- get the number of days difference between the first of the month
-- of the starting and ending dates.
SET @days =  DATEDIFF(day, DateAdd(month, DateDiff(month, 0, @StartDate), 0),
                           DateAdd(month, DateDiff(month, 0, @EndDate), 0));

-- See Jeff Moden's article 
-- The "Numbers" or "Tally" Table: What it is and how it replaces a loop.
-- at http://www.sqlservercentral.com/articles/T-SQL/62867/.
-- NOTE! A permanent tally table will always be MUCH faster 
-- than this inline one. See the above article to create your own!
;WITH 
Tens     (N) AS (SELECT 0 UNION ALL SELECT 0 UNION ALL SELECT 0 UNION ALL 
                 SELECT 0 UNION ALL SELECT 0 UNION ALL SELECT 0 UNION ALL 
                 SELECT 0 UNION ALL SELECT 0 UNION ALL SELECT 0 UNION ALL SELECT 0), 
Thousands(N) AS (SELECT 1 FROM Tens t1 CROSS JOIN Tens t2 CROSS JOIN Tens t3), 
Millions (N) AS (SELECT 1 FROM Thousands t1 CROSS JOIN Thousands t2), 
Tally    (N) AS (SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 0)) FROM Millions),
CTE (StartDate, EndDate) AS
(
-- get the starting date and the end of the starting month
SELECT @StartDate, DateAdd(day, -1, DATEADD(month, 1 + DateDiff(month, 0, @StartDate), 0)) UNION ALL
-- get the start of the ending month and the ending date
SELECT DATEADD(month, DateDiff(month, 0, @EndDate), 0), @EndDate UNION ALL
-- get the start and end of all months between
SELECT DATEADD(month, DateDiff(month, 0, @StartDate) + N, 0),
       DATEADD(day, -1, DATEADD(month, 1+DateDiff(month, 0, @StartDate) + N, 0))
  FROM Tally
 WHERE N < DATEDIFF(MONTH, @StartDate, @EndDate)
)
-- if @days > 0, then specified dates cross at least one 
-- month boundary, so get everything from the CTE
SELECT [Year] = YEAR(StartDate), 
       [Month] = MONTH(StartDate), 
       [Days] = DATEDIFF(day, StartDate, EndDate)+1
  FROM CTE
 WHERE @days > 0
UNION ALL
-- if @days = 0, then specified dates are in the same month
-- so get just this information.
SELECT YEAR(@StartDate),
       MONTH(@StartDate),
       DATEDIFF(day, @StartDate, @EndDate)+1
 WHERE @days = 0         
 ORDER BY [Year], [Month];
 
 --week day 
 
 WITH 
E1 AS (SELECT n = 1 FROM (VALUES (1),(1),(1),(1),(1),(1),(1),(1),(1),(1)) t(n)),	--10
E2 AS (SELECT n = 1 FROM E1 a CROSS JOIN E1 b),	--100
iTally AS (SELECT n = row_number() over (order by (select null)) FROM E2 a CROSS JOIN E2 b),
cal_table AS
(	SELECT	
		dtval = dateadd(D,n,cast('1/1/1990' AS date)), 
		wkdaynbr = datepart(weekday,dateadd(D,n,cast('1/1/1990' AS date))),
		wkdaytext = datename(weekday,dateadd(D,n,cast('1/1/1990' AS date)))
	FROM iTally
)
SELECT * 
FROM cal_table
--WHERE wkdaynbr = 3;

DECLARE @INPUT VARCHAR(50) = 'Documentation.Account';

SELECT
    @INPUT                                                   AS INPUT_STRING
   ,SUBSTRING(@INPUT,CHARINDEX(CHAR(46),@INPUT,1) + 1,50)  AS SUBSTRING_STRING
   ,STUFF(@INPUT,1,CHARINDEX(CHAR(46),@INPUT,1),'')          AS STUFF_STRING
   ,RIGHT(@INPUT,CHARINDEX(CHAR(46),REVERSE(@INPUT)) - 1)    AS RIGHT_STRING
;

DECLARE @ThisYear  INT,
        @ThisMonth INT;
 SELECT @ThisYear  = 2012, --Leap Year!
        @ThisMonth = 2;

 SELECT BOM = DATEADD(mm, @ThisYear*12-22801+@ThisMonth, 0),
        EOM = DATEADD(mm, @ThisYear*12-22800+@ThisMonth,-1)
        
        
 DECLARE @ThisYear  INT,
        @ThisMonth INT;
 SELECT @ThisYear  = 2013,
        @ThisMonth = 2;

 SELECT BOM = DATEADD(mm, @ThisYear*12-22800+@ThisMonth-1, 0),
        EOM = DATEADD(mm, @ThisYear*12-22800+@ThisMonth  ,-1)
        
select	dateadd(month, (@YearParam - 1900)*12 + @MonthParam- 1, 0)   AS BOM
select	dateadd(month, (@YearParam - 1900)*12 + @MonthParam, -1)    AS EOM

-- last day of month
DECLARE @Year DATETIME;
  SELECT @Year = '2011';

WITH
cteDate AS
(
 SELECT EOM = DATEADD(mm,number,@Year)-1
   FROM master.dbo.spt_values v
  WHERE Type = 'P' 
    AND Number BETWEEN 1 AND 12
)
 SELECT DATENAME(mm,EOM)+'-'+DATENAME(yy,EOM)+' :- '
      + DATENAME(dd,EOM)+'-'+DATENAME(mm,EOM)+'-'+DATENAME(yy,EOM)
      + ' '+DATENAME(dw,EOM)
   FROM cteDate
;
--convert varchar to datetime

WITH
cteTestData(D) AS
( --=== This is test data and is not a part of the solution
 SELECT '20111' UNION ALL
 SELECT '20112' UNION ALL
 SELECT '20113' UNION ALL
 SELECT '20114' UNION ALL
 SELECT '20115' UNION ALL
 SELECT '20116' UNION ALL
 SELECT '20117' UNION ALL
 SELECT '20118' UNION ALL
 SELECT '20119' UNION ALL
 SELECT '201110' UNION ALL
 SELECT '201111' UNION ALL
 SELECT '201112' UNION ALL
 SELECT '20121'
)
 SELECT OriginalData = D
,       Converted    = CONVERT(CHAR(10),DATEADD(mm,SUBSTRING(D,5,2)-1,SUBSTRING(D,1,4)),101)
   FROM cteTestData
;

--datediff
--===== Create a million row test table of start and end dates
     -- where the end date is always later than the start date.
     -- In this case, there could be a full century of time between the dates.
     IF OBJECT_ID('tempdb..#JBMTest','U') IS NOT NULL DROP TABLE #JBMTest;

   WITH cteRandomStartDT AS
(
 SELECT TOP 1000000
        StartDT = RAND(CHECKSUM(NEWID())) * DATEDIFF(dd,'2000','2020') + CAST('2000' AS DATETIME)
   FROM sys.all_columns ac1
  CROSS JOIN sys.all_columns ac2
)
 SELECT StartDT
        ,EndDT = RAND(CHECKSUM(NEWID())) * DATEDIFF(dd,'2000','2100') + StartDT
   INTO #JBMTest
   FROM cteRandomStartDT
;
--===== Calculate the Delta-T for each start/end date pair in the table.
     -- I'm dumping the output to a variable to take display times out of the picture.
     -- The formula calculates the total difference in time, converts that to HH:MI:SS:mmm format,
     -- and then stuffs the first 2 characters out and replaces them with difference in time 
     -- measured in whole hours.
DECLARE @BitBucket VARCHAR(20);
    SET STATISTICS TIME ON;
 SELECT @BitBucket = STUFF(CONVERT(VARCHAR(20),EndDT-StartDT,114),1,2,DATEDIFF(hh,0,EndDT-StartDT))
   FROM #JBMTest;
    SET STATISTICS TIME OFF;
GO
--===== Just to show that it really does work...
 SELECT *
        ,DeltaT = STUFF(CONVERT(VARCHAR(20),EndDT-StartDT,114),1,2,DATEDIFF(hh,0,EndDT-StartDT))
   FROM #JBMTest
  ORDER BY EndDT-StartDT
;


/**********************************************************************************************************************
 Purpose:
 Create a voluminous test table with various types of highly randomized data.

 --Jeff Moden 
**********************************************************************************************************************/
--===== Conditionally drop the test table to make reruns easier
     IF OBJECT_ID('dbo.JBMTest','U') IS NOT NULL
        DROP TABLE dbo.JBMTest
;
--===== Create and populate a 1,000,000 row test table.
     -- "SomeID" has a range of 1 to 1,000,000 unique numbers
     -- "SomeInt" has a range of 1 to 50,000 non-unique numbers
     -- "SomeLetters2" has a range of "AA" to "ZZ" non-unique 2 character strings
     -- "SomeMoney has a range of 0.00 to 100.00 non-unique numbers
     -- "SomeDateTime" has a range of  >=01/01/2000 and <01/01/2020 non-unique date/times
     -- "SomeDate" has a range of  >=01/01/2000 and <01/01/2020 non-unique "whole dates"
     -- "SomeName" contains random characters at random lengths from 2 to 20 characters
 SELECT TOP 1000000
        SomeID       = IDENTITY(INT,1,1),
        SomeInt      = ABS(CHECKSUM(NEWID())) % 50000 + 1,
        SomeLetters2 = CHAR(ABS(CHECKSUM(NEWID())) % (ASCII('Z')-ASCII('A')+1) +ASCII('A'))
                     + CHAR(ABS(CHECKSUM(NEWID())) % (ASCII('Z')-ASCII('A')+1) +ASCII('A')),
        SomeMoney    = CAST(RAND(CHECKSUM(NEWID())) * 100 AS DECIMAL(9,2)), --Note rounding
        SomeDateTime = RAND(CHECKSUM(NEWID())) * DATEDIFF(dd,'2000','2020') + CAST('2000' AS DATETIME),
        SomeDate     = ABS (CHECKSUM(NEWID())) % DATEDIFF(dd,'2000','2020') + CAST('2000' AS DATETIME),
        SomeName     = RIGHT(NEWID(),ABS(CHECKSUM(NEWID())) % 19 + 2)
   INTO dbo.JBMTest
   FROM sys.all_columns ac1
  CROSS JOIN sys.all_columns ac2
; 


SELECT UPPER( REPLACE( CONVERT(char(11), GETDATE(), 106), ' ', '-'))

--===== Return all characters that ISNUMERIC thinks is numeric
     -- (uses values 0-255 from the undocumented spt_Values table
     -- instead of a loop from 0-255)
 SELECT [Ascii Code] = STR(Number),
        [Ascii Character] = CHAR(Number),
        [ISNUMERIC Returns] = ISNUMERIC(CHAR(Number))
   FROM Master.dbo.spt_Values
  WHERE Name IS NULL
    AND ISNUMERIC(CHAR(Number)) = 1
    
    
    
    declare @Date datetime = '2011-10-07 13:18:48.720'

select LEFT(CAST(@Date as varchar(20)), 3) + '-' + CAST(YEAR(@Date) as CHAR(4))

--Get Last Name, First name and Middle Name from Full Name

CREATE TABLE #names (full_name varchar(254))
INSERT INTO #names VALUES ('Simpson, Homer J')
INSERT INTO #names VALUES ('Simpson, Bartholomew JoJo')
INSERT INTO #names VALUES ('Simpson,Maggie')
INSERT INTO #names VALUES ('Bouvier Simpson, Margorie "Marge"')
INSERT INTO #names VALUES ('Simpson, Lisa M.')
INSERT INTO #names VALUES ('Burns,Charles Montgomery "Monty"')
INSERT INTO #names VALUES ('Smithers, Waylon Jr.')

;
WITH 
cteStart AS
(
 SELECT SUBSTRING(full_name,1,CHARINDEX(',',full_name)-1) AS LastName,
        LTRIM(SUBSTRING(full_name,CHARINDEX(',',full_name)+1,254)) AS FirstNameStart
   FROM #Names
)
,
cteMiddle AS
(
 SELECT LastName,
        SUBSTRING(FirstNameStart,1,ISNULL(NULLIF(CHARINDEX(' ',FirstNameStart),0),254)) AS FirstName,
        REPLACE(LTRIM(SUBSTRING(FirstNameStart,NULLIF(CHARINDEX(' ',FirstNameStart),0),254)),'.','') AS MiStart
 FROM cteStart
)
 SELECT LastName,
        FirstName,
        CASE WHEN LEN(MiStart) = 1 THEN MiStart ELSE NULL END AS MI
   FROM cteMiddle
   
   
   --data rollup
   
   --=======================================================================================
--      Build the test data.  Nothing in this section is a part of the solution to the
--      problem.  We're just building test data here.
--=======================================================================================
--===== Conditionally drop the test table to make reruns in SSMS easier.
     IF OBJECT_ID('TempDB..#TestTable','U') IS NOT NULL DROP TABLE #TestTable;
GO
--===== Create and populate the test table on-the-fly with data from the original post.
 SELECT Yr, Month, Member, Code, [Desc]
   INTO #TestTable
   FROM (
         SELECT '2011','01','A','HCC1','ABC' UNION ALL
         SELECT '2011','01','A','HCC2','DEF' UNION ALL
         SELECT '2011','01','A','HCC3','GHI' UNION ALL
         SELECT '2011','02','A','HCC4','XYZ' UNION ALL
         SELECT '2011','02','A','HCC2','DEF' UNION ALL
         SELECT '2011','02','A','HCC3','GHI'
        ) d (Yr, Month, Member, Code, [Desc])
;
--=======================================================================================
--      Solve the problem using a Triangular Join and XML Concatenation methods.
--      Performance will be absolutely terrible because of the Triangular Join
--      if the number of rows get very large but I can't think of another way
--      to do it without a Triangular Join tonight. Wink
--      The separation of Yr and Month in the original table also makes it impossible to 
--      make a SARGable query.
--=======================================================================================
WITH
cteTriangularJoinCount AS
(
 SELECT Yr, Month, Member, Code, [Desc],
        [Count] = (SELECT COUNT(DISTINCT [Desc]) FROM #TestTable t2 WHERE t2.Yr+t2.Month <= t1.Yr+t1.Month)
   FROM #TestTable t1
)
 SELECT Yr, Month, Member, 
        [Desc] = STUFF((
                     SELECT DISTINCT ','+tjc2.[Desc]
                       FROM cteTriangularJoinCount tjc2
                      WHERE tjc2.Yr <= tjc1.Yr
                        AND tjc2.Month <= tjc1.Month
                        AND tjc2.Member = tjc1.Member
                      ORDER BY ','+tjc2.[Desc]
                        FOR XML PATH('')
                ),1,1,''),
        [Count]
   FROM cteTriangularJoinCount tjc1
  GROUP BY Yr, Month, Member, [Count]
;

--convert a varchar(4000) to a int
SELECT @tStr AS ORIGINAL, N, SUBSTRING(@tStr,N,LEN(@tStr)-N+1) AS SUBSTR,
       CAST(SUBSTRING(@tStr, N+1, CHARINDEX(',', @tStr, N+1)-N-1) AS INT) AS Number
FROM @TALLY
WHERE N < LEN(@tStr) AND
        SUBSTRING(@tStr,N,1) = ','
        
-- find nth occurance        
        
DECLARE @cSearchExpression nvarchar(4000), @cExpressionSearched  nvarchar(4000), @nOccurrence INT
SET @cSearchExpression = 'f'
SET @cExpressionSearched = 'aaaddddfffggghhhhjjjj'
SET @nOccurrence = 2 
            
SELECT CHARINDEX(@cSearchExpression, @cExpressionSearched, n.number) AS StartPos
FROM dbo.Numbers n 
WHERE n.number <= LEN(@cExpressionSearched)	
GROUP BY CHARINDEX(@cSearchExpression, @cExpressionSearched, n.number)
HAVING CHARINDEX(@cSearchExpression, @cExpressionSearched, n.number) > 0
ORDER BY 1        


--Convert Start and End Dates to Time records
--===== Set the correct date format
    SET DATEFORMAT DMY

--===== Build the test table and populate it with data.
     -- Note that this is NOT part of the solution
DECLARE @YourTable TABLE (StartDate DATETIME, EndDate DATETIME, Duration INT, Hours INT)
 INSERT INTO @YourTable
        (StartDate, EndDate, Duration, Hours)
 SELECT '01/04/2008', '04/04/2008', 4, 28 UNION ALL --Your orginal example
 SELECT '01/05/2008', '04/06/2008', 35, 320         --A large example just to show crossing month boundaries

--===== Spawn the necessary number of sequential dates and calculate
     -- the number of hours for each day evenly distributed
 SELECT DATEADD(dd,t.N,y.StartDate-1) AS Date,
        CAST((y.Hours+0.0)/y.Duration AS DECIMAL(9,2)) AS Hours
   FROM @YourTable y
  CROSS JOIN dbo.Tally t
  WHERE t.N <= y.Duration
  ORDER BY y.StartDate
  
  --parase emails
  
  declare @names nvarchar(max)
SET @names = N'O''Brien, Bob <bobrien@somedomain.com>;Doe, Jane <jdoe@somedomain.com> ; Van der Merwe, Koos <bla@bla>'

select 
	ltrim(rtrim(s3.first)) FirstName
	,ltrim(rtrim(s3.last)) LastName
	,ltrim(rtrim(s2.email)) Email
from dbo.f_DelimitedSplit8K(@names, N';') s1  -- convert to rows (By Jeff Moden)
cross apply (select charindex(N'<', s1.Item ) ) Idxs(n) -- locate email phrase
cross apply (select substring( s1.Item, 1, Idxs.n - 1 ) as names, substring(s1.item, idxs.n+1, len(s1.item) - idxs.n - 1 ) email) s2 -- get names, email
cross apply (select charIndex(N',', s2.names ) ) Idxc(n) -- locate name splitter
cross apply (select substring( s2.names, 1, idxc.n -1 ) last, substring( s2.names, idxc.n + 1 , len(s2.names) - idxc.n ) first) s3 -- get first, last


--Parse string to find letter
declare @MyString varchar(max) = '----aaa375475960dkgjfkfkgjfkvkl!!!!!-------DAfkwwrrr333qqqaaaadfk55500---!'

select len(@MyString) - len(replace(@MyString, 'a', ''))
select len(@MyString) - len(replace(@MyString collate SQL_Latin1_General_Cp1_CS_AS, 'a' collate SQL_Latin1_General_Cp1_CS_AS, ''))
select len(@MyString) - len(replace(@MyString collate SQL_Latin1_General_Cp1_CS_AS, 'A' collate SQL_Latin1_General_Cp1_CS_AS, ''))

--bcp

declare @cmd varchar(1000)
set @cmd = 
'bcp AdventureWorks.dbo.mytest in "C:\test.csv" -t "," -r  -c -q -S MYSERVER -T'
exec xp_cmdshell @cmd


--email

DECLARE @string VARCHAR(MAX) 
SET @string = '...the email ids abs@yahoo.co.uk and also cds@gmail.com are my mails ids...'

DECLARE @sub VARCHAR(MAX)
SELECT @sub = LEFT(@string,CHARINDEX(' ',@string,CHARINDEX('@',@string,1))-1)
SELECT RIGHT(@sub,LEN(@sub)-CHARINDEX(' ',REVERSE(@sub))-1)

--Convert alphanumeric to BigInt

--===== Create and populate a test table with the data given in the post.
     -- This is NOT a part of the solution
 CREATE TABLE #YourTable
        (
        SomeString VARCHAR(20)
        )
 INSERT INTO #YourTable
 SELECT '1230-544' UNION ALL
 SELECT '15C5487'  UNION ALL
 SELECT '132DE78'

--===== This solves the problem.
;WITH
cteSplit AS
(--==== This not only splits out the individual characters, it only splits 
     -- out the digits from 0 to 9
 SELECT SomeString,
        ROW_NUMBER() OVER (ORDER BY yt.SomeString) AS CharacterNumber,
        SUBSTRING(yt.SomeString,t.N,1) AS Character
   FROM #YourTable yt
  CROSS JOIN dbo.Tally t
  WHERE t.N <= LEN(yt.SomeString)
    AND SUBSTRING(yt.SomeString,t.N,1) LIKE '[0-9]'
)--==== This put's it all back together using a very high speed XML method
 SELECT t1.SomeString, 
        CAST((SELECT '' + t2.Character 
                FROM cteSplit t2 
               WHERE t1.SomeString = t2.SomeString 
               ORDER BY t2.CharacterNumber 
                 FOR XML PATH(''))
         AS BIGINT) AS NumbersOnly
   FROM cteSplit t1
  GROUP BY t1.SomeString

--COLUMNA Modifier RESULT

--COLUMNA Modifier RESULT
--1234.5678 10000 12345678
--1.8 10 18
--0.6750 10000 6750

--===== Create a test table from the original posting.
     -- This is NOT a part of the solution
DECLARE @t TABLE (ColumnA DECIMAL(9,4))
 INSERT INTO @t (ColumnA)
 SELECT 1234.5678 UNION ALL
 SELECT 1.8       UNION ALL
 SELECT 0.6750

--===== Show what's in the test table.
     -- Again, this is NOT a part of the solution.
 SELECT * FROM @t

--===== Now, solve the problem easily by using CTE's to peel one potato at a time...
;WITH 
cteTrim
AS      ( --=== Determine how many significant digits to right of decimal point
         SELECT ColumnA,
                Trimmed = RTRIM(REPLACE(CAST(ColumnA AS VARCHAR(10)),'0',' '))
           FROM @t)
,
cteModifier
AS      ( --=== From the above, determine what the modifier is
         SELECT ColumnA,
                Modifier = POWER(10,LEN(Trimmed)-CHARINDEX('.',Trimmed))
           FROM cteTrim)
--===== From that, determine the final output
 SELECT ColumnA,
        Modifier,
        Result = CAST(ColumnA*Modifier AS BIGINT)
   FROM cteModifier;


--Biweekly dates

;WITH
cteTally AS
(
 SELECT ROW_NUMBER() OVER (ORDER BY ID)-1 AS N
   FROM Master.sys.SysColumns
)
 SELECT DATEADD(dd,(t.n)*14,'20090102') AS BiFriday
   FROM cteTally t
  WHERE t.n < (DATEDIFF(dd,'20090102','20100101')+1)/14

--
SELECT DATEADD(dd,(t.n-1)*14,'20090102') AS BiFriday
   FROM dbo.Tally t
  WHERE t.n <= (DATEDIFF(dd,'20090102','20100101')+1)/14 

  --remove leading zeros
  DECLARE @Sku NVARCHAR(500)
SET @Sku = '000000000000000000000000000000000000000000000000000000012335670000'
  
SELECT @Sku AS Original,
SUBSTRING(@Sku,PATINDEX('%[^0]%',@Sku),DATALENGTH(@Sku)) AS NoLeadingZeros


--bulkinsert
   BULK INSERT dbo.DeviceStaging
   FROM 'C:\Temp\device1_2016-08-03_15-24-58.txt' 
   WITH ( 
         BATCHSIZE          = 2000000000 
        ,CODEPAGE           = 'RAW'
        ,DATAFILETYPE       = 'CHAR'
        ,FIELDTERMINATOR    = ','
        ,ROWTERMINATOR      = ''
        ,FIRSTROW           = 7
        ,TABLOCK
        )
--email validation


DECLARE @EmailAddress VARCHAR(512);
 SELECT @EmailAddress = 'Some.One@Company.com';

 SELECT CASE
   WHEN @EmailAddress NOT LIKE '%[^-a-zA-Z0-9__.@]' ESCAPE '_' COLLATE Latin1_General_BIN
    AND @EmailAddress LIKE '%[a-zA-Z0-9]@[a-zA-Z0-9]%.[a-zA-Z0-9][a-zA-Z0-9]%' COLLATE Latin1_General_BIN
   THEN 'Good'
   ELSE 'Bad'
    END

--
--Help with finding multiple Character Occurence in String
CREATE TABLE #Names ( id int, FIRSTNAME VARCHAR (20), LASTNAME VARCHAR (20))

INSERT INTO #Names VALUES 
 (1,'Thomas', 'Hohner')
,(2,'Mike', 'SSmith')
,(3,'TtTony', 'Hawk')
,(4,'Jeff',  'Smith')
,(5,'ZZSara', 'Jones')
,(6,'Luke', 'HendersonZZ')
,(7,'Lily', 'PPadZZZ');

WITH  E(n) AS(SELECT 0 UNION ALL SELECT 0 UNION ALL SELECT 0 UNION ALL 
              SELECT 0 UNION ALL SELECT 0 UNION ALL SELECT 0)
,E36(n) AS (SELECT E.n FROM E, E x)
,Letters AS(
    SELECT TOP 26 CHAR(ROW_NUMBER() OVER(ORDER BY (SELECT NULL)) + 64) letter
    FROM sys.all_columns
)
SELECT DISTINCT n.* 
FROM #Names n
JOIN Letters l ON n.FIRSTNAME LIKE '%' + letter + letter+ '%'
               OR n.LASTNAME LIKE '%' + letter + letter+ '%'
ORDER BY id;

WITH E(n) AS(SELECT 0 UNION ALL SELECT 0 UNION ALL SELECT 0 UNION ALL 
             SELECT 0 UNION ALL SELECT 0)
,E25(n) AS (SELECT E.n FROM E, E x)
,cteTally AS(
    SELECT TOP 20 ROW_NUMBER() OVER(ORDER BY (SELECT NULL)) n
    FROM E25
)
SELECT DISTINCT n.*
FROM #Names n
CROSS
JOIN cteTally t 
WHERE (LEN( n.FIRSTNAME) >= t.n AND SUBSTRING(n.FIRSTNAME, n, 1) = SUBSTRING(n.FIRSTNAME, n + 1, 1))
OR (LEN( n.LASTNAME) >= t.n AND SUBSTRING(n.LASTNAME, n, 1) = SUBSTRING(n.LASTNAME, n + 1, 1))
ORDER BY n.id

DROP TABLE #Names


--get filename from string

--===== Conditionally drop the test table to make reruns in SSMS easier.
     IF OBJECT_ID('tempdb..#Docs','U') IS NOT NULL DROP TABLE #Docs;

--===== Create the test table
 CREATE TABLE #Docs ([Document_and_path] VARCHAR(200));

--===== Add the given test data to the test table
 INSERT INTO #Docs 
        ([Document_and_path])
 SELECT 'F:\Offerter\2005\Posten\NYTT RAMAVTAL 2005-04-20\ramavtal utbildning personlig effektivitet Astrakan.doc' UNION ALL 
 SELECT 'F:\Offerter\Gammalt\2003 Frakt tillkommer\Tagna\Offert D-data_A4702_PJK.doc'
;

--===== Split the path name from the file name and display both.
 SELECT FilePath = SUBSTRING(Document_and_path, 1, d.FirstLength),
        FileName = SUBSTRING(Document_and_path, d.FirstLength + 2, 8000) --See the second trick here?
   FROM #Docs
  CROSS APPLY (SELECT DATALENGTH([Document_and_path])-CHARINDEX('\',REVERSE([Document_and_path]))) d (FirstLength)
;

--Return string between 2 characters from the end of the string

SELECT LEFT( NewString, CHARINDEX(' ', NewString)), PARSENAME(REPLACE(ref, ' ', '.'), 2) 'TEST'
--Start of sample data
FROM (VALUES
            ('INV CRT IR00000005 2'),
            ('INV CRT IS15000467 1'),
            ('INV CSH 144934 1'    ),
            ('INV CSH 144934 1'    ),
            ('INV CSH 144934 1'    ),
            ('INV CSH IS15000134 1'),
            ('INV CSH IS15000135 1'))x(ref)
--End of sample data
CROSS APPLY (SELECT STUFF( ref, 1, CHARINDEX(' ', ref, CHARINDEX(' ', ref)+1),''))y(NewString)

--
/*******************************************************************
 Demonstration of how to conditionally format a column to a format
 of $nnn,nnn,nnn.nn if the value is numeric only (decimal point
 allowed) and returns the original value if not 100% numeric.  Most
 of the code here is just a setup for the demo.  The meat of the 
 demo is in the CASE statement.
--Jeff Moden
*******************************************************************/
--===== If experimental table exists, drop it
     IF OBJECT_ID('TempDB..#yourtable') IS NOT NULL
        DROP TABLE #yourtable

--===== Create the experimental table
 CREATE TABLE #yourtable 
        (ID INT IDENTITY(1,1), 
         YourField VARCHAR(20))

--===== Populate the experimental table with values
 INSERT INTO #yourtable (YourField)
 SELECT 'A123.45' UNION ALL
 SELECT '123A.45' UNION ALL
 SELECT '123.A45' UNION ALL
 SELECT '123.45A' UNION ALL
 SELECT '123.45' UNION ALL
 SELECT '0000123.45' UNION ALL
 SELECT '123.450000' UNION ALL
 SELECT '12345'

--===== If value of the field has numbers only, 
     -- then append '$' sign in front of it and '.00' at the end.
 SELECT YourField AS OrigVal,
        CASE
            WHEN YourField NOT LIKE '%[^0-9,.]%'
            THEN '$'+CONVERT(VARCHAR(24),CONVERT(MONEY,YourField),1)
            ELSE YourField
        END AS DispVal
   FROM #yourtable

DROP table #Fruits
create table #Fruits (FruitGroup CHAR(1), FruitName varchar(20), iLike BIT)
INSERT INTO #Fruits (FruitGroup, FruitName, iLike)
SELECT 'B', 'Strawberry', 1 UNION ALL
SELECT 'B', 'Raspberry', 1 UNION ALL
SELECT 'B', 'Blackberry', 1 UNION ALL
SELECT 'B', 'Blueberry', 0 UNION ALL
SELECT 'A', 'CoxApple', 1 UNION ALL
SELECT 'A', 'CrabApple', 0 UNION ALL
SELECT 'A', 'BramleyApple', 0 

SELECT FruitGroup,
	SUM([Rows]) AS FruitsInGroup,
	SUM(CASE iLike WHEN 1 THEN [Rows] ELSE 0 END) AS FruitsILike
FROM (
	SELECT FruitGroup, iLike, COUNT(*) AS [Rows]
	FROM #Fruits
	GROUP BY FruitGroup, iLike
) d
GROUP BY FruitGroup

  select RowID = ROW_NUMBER() OVER (ORDER BY (SELECT 0))
--concurrent users 

  -- See how you start off by actually creating a table
-- and then inserting the data into it? Doing this really 
-- makes things a lot easier for all the people you want to 
-- help you. So, HELP US HELP YOU by doing this for us! See
-- http://www.sqlservercentral.com/articles/Best+Practices/61537/
-- for more details on how to do all of this.
declare @test table (ID int, [Action] varchar(6), [Time] datetime, UserName varchar(6))
INSERT INTO @test
SELECT 1, 'Login', '2010-05-01 13:00:00', 'abc123' UNION ALL
SELECT 2, 'Logout', '2010-05-01 14:00:00', 'abc123' UNION ALL
SELECT 3, 'Login', '2010-05-01 13:30:00', 'def234' UNION ALL
SELECT 4, 'Logout', '2010-05-01 14:10:00', 'def234' UNION ALL
SELECT 5, 'Login', '2010-05-02 13:00:00', 'xxxxxx' UNION ALL
SELECT 6, 'Login', '2010-05-03 13:10:00', 'xxxzzz'


-- whew!!! now that the test data has been made, 
-- let's see how to do what you're asking for!
DECLARE @Date DATE
-- set to the first day of the month
SET @Date = '20100501'

SELECT [Date] =  DateAdd(day, 0, DateDiff(day, 0, [Time])),
       MaxUsers = SUM(CASE WHEN [Action] = 'Login' THEN 1 
                            WHEN [Action] = 'Logout' THEN -1 
                            ELSE 0 END)
  FROM @test
 WHERE [Time] >= @Date
   AND [Time] < DateAdd(month,1,@Date)
 GROUP BY DateAdd(day, 0, DateDiff(day, 0, [Time]))
 ORDER BY [Date]


 --Converting nvarchar value to int

 WITH Codes(code) AS
(
	SELECT *
	FROM( VALUES('X200'), ('516'), ('XD1'), ('YTG'), ('24ZY'), ('40Y'), ('01DX')) Codes(code)
)

select * from Codes c
cross apply dbo.GetNumbersOnly(c.code) n


--concatenate

DECLARE @TblA TABLE (
	Col1 INT
	, Col2 INT
);

DECLARE @TblB TABLE (
	Col1 INT
	, Col2 INT
);

DECLARE @TblC TABLE (
	Col1 INT
	, Col2 INT
);

INSERT INTO @TblA (Col1, Col2) VALUES (1, 1),(2, 2);
INSERT INTO @TblC (Col1, Col2) VALUES (100, 1),(200, 2),(300, 3);
INSERT INTO @TblB (Col1, Col2) VALUES (1, 1),(2, 1),(2, 2),(2, 3);

Select A.Col2
	, STUFF((
		SELECT	',' + CONVERT(VARCHAR,c.Col1)
		FROM	@TblB B
				Inner join @TblC C on c.Col2 = b.Col2
		WHERE	 B.Col1 = a.Col2
		FOR XML PATH(''),TYPE).value('.','VARCHAR(MAX)'),1,1,'')
From @TblA A

--comma seperated list

WITH CTE AS
(
SELECT DISTINCT 
       AccountNumber
  FROM #TestData
)
SELECT AccountNumber,
       CommaList = STUFF((
                   SELECT ',' + Value
                     FROM #TestData
                    WHERE AccountNumber = CTE.AccountNumber
                    ORDER BY Value
                      FOR XML PATH(''), 
                              TYPE).value('.','varchar(max)'),1,1,'')
  FROM CTE
 ORDER BY AccountNumber;
-- 
 DECLARE @DupeChar CHAR(1)
SET     @DupeChar ='#' 
;With MySampleData
AS 
(
SELECT '####A##B#####C#####' As TheString UNION ALL
SELECT '####A##B#######C###' As TheString UNION ALL
SELECT '###########################################################A##B#####C###' As TheString UNION ALL
SELECT '######A##B#######C#####' As TheString  UNION ALL
SELECT '##This######has#multiple###unknown#################spaces#in########it.###' UNION ALL
SELECT 'So#####################does######################this!' UNION ALL
SELECT 'As################################does########################this' UNION ALL
SELECT 'This,#that,#and#the#other##thing.' UNION ALL
SELECT 'This#needs#no#repair.'
)
--===== Reduce each group of multiple spaces to a single space
     -- for a whole table without functions, loops, or other
     -- forms of slow RBAR.  In the following example, CHAR(7)
     -- is the "unlikely" character that "X" was used for in 
     -- the explanation.
 SELECT REPLACE(
            REPLACE(
                REPLACE(
                    LTRIM(RTRIM(TheString))
                ,@DupeChar + @DupeChar,@DupeChar + '~')  --Changes 2 spaces to the OX model
            ,'~' + @DupeChar,'')        --Changes the XO model to nothing
        ,'~','') AS CleanString --Changes the remaining X's to nothing
   FROM MySampleData
  WHERE CHARINDEX(@DupeChar + @DupeChar,TheString) > 0
  
  -- regedit reg edit regex edit
  
  
USE master;
CREATE USER TestingXPRead WITHOUT LOGIN;
grant execute on object::sys.xp_instance_regread to TestingXPRead;
EXECUTE AS USER='TestingXPRead';
SELECT USER_NAME();

declare @DefaultBackupDirectory nvarchar(512);
exec master.dbo.xp_instance_regread N'HKEY_LOCAL_MACHINE', N'Software\Microsoft\MSSQLServer\MSSQLServer',N'BackupDirectory', @DefaultBackupDirectory OUTPUT;

SELECT ISNULL(@DefaultBackupDirectory,'');
--change back into myself

REVERT;
DROP USER TestingXPRead;

--bcp
DECLARE @LastName nvarchar(100) = 'Tamburello',
    @FirstName nvarchar(100) = 'Roberto'

DECLARE @Command nvarchar(4000)

SET @Command = 'bcp "EXEC TEST.dbo.spTryOut @LastName='
            + QUOTENAME(@LastName,'''')
            + ', @FirstName='
            + QUOTENAME(@FirstName,'''')
            + '" queryout "D:\SQLServerResults\'
            + @LastName + @FirstName + REPLACE( CONVERT(varchar(19), GETDATE(), 120), ':', '')
            + '.csv" '
            + '-c '
            + '-CRAW '
            + '-S YourServer\AndInstance '
            + '-T '
            + '-t,'

EXEC xp_cmdshell @Command;

--paging or pagination
--===== Declare the local variables
DECLARE @PageSize INT --How many rows to appear per page
DECLARE @PageNum  INT --What page number to appear
DECLARE @Skip     INT --Working variable for where to start for page
DECLARE @SQL      VARCHAR(8000) --Holds dynamic SQL
 
--===== Set the local variables for pagesize and page
     -- PageSize and PageNum would be parameters in a stored proc
    SET @PageSize = 100
    SET @PageNum  = 4000
    SET @Skip    = @PageSize*@PageNum
 
 SELECT t.*
   FROM dbo.Test t,
        (
         SELECT TOP (@PageSize) * 
           FROM dbo.Test WITH (NOLOCK)
          WHERE RowNum NOT IN (SELECT TOP (@Skip) RowNum 
                                 FROM dbo.Test
                                ORDER BY RowNum)
          ORDER BY CustID
        ) d
  WHERE t.RowNum = d.RowNum
  
  
  
set statistics time on
--===== Declare the local variables
DECLARE @PageSize INT --How many rows to appear per page
DECLARE @PageNum  INT --What page number to appear
DECLARE @Skip     INT --Working variable for where to start for page
DECLARE @SQL      VARCHAR(8000)
 
--===== Set the local variables for pagesize and page
     -- PageSize and PageNum would be parameters in a stored proc
    SET @PageSize = 100
    SET @PageNum  = 9000
    SET @Skip    = @PageSize*@PageNum

--SELECT t.RowNum
--   FROM dbo.Test t,
--        (
--         SELECT TOP (@PageSize) RowNum 
--           FROM dbo.Test WITH (NOLOCK)
--          WHERE RowNum NOT IN (SELECT TOP (@Skip) RowNum 
--                                 FROM dbo.Test
--                                ORDER BY RowNum)
--          ORDER BY RowNum
--         ) d
--  WHERE t.RowNum = d.RowNum

SET @SQL = ' 
 SELECT t.RowNum
   FROM dbo.Test t,
        (
         SELECT TOP '+STR(@PageSize)+' RowNum 
           FROM dbo.Test WITH (NOLOCK)
          WHERE RowNum NOT IN (SELECT TOP '+STR(@Skip)+' RowNum 
                                 FROM dbo.Test
                                ORDER BY RowNum)
          ORDER BY RowNum
         ) d
  WHERE t.RowNum = d.RowNum'
EXEC (@SQL)
set statistics time off

--ip address or ipaddress

SELECT PARSENAME(d.IpAddr,4) As ColA,
        PARSENAME(d.IpAddr,3) As ColB,
        PARSENAME(d.IpAddr,2) As ColC,
        PARSENAME(d.IpAddr,1) As ColD
   FROM
        (SELECT '208.77.188.166' AS IpAddr UNION ALL
        SELECT '208.77.188.001' UNION ALL
        SELECT '208.77.188.1')d
        
        
 --Fraction
 
 
DECLARE @number AS NUMERIC(4,2) = 2.5;
SELECT @number;

IF (ROUND(@number,0) = @number)
	PRINT 'whole number';
ELSE
	PRINT 'has fractional component';
	
DECLARE @number AS NUMERIC(4,2) ; SELECT @number = 2.99;
print @number;

IF (ROUND(@number,0) = @number)
	PRINT 'whole number';
ELSE
	PRINT 'has fractional component';

IF @number%1 = 0
	PRINT 'whole number';
ELSE
	PRINT 'has fractional component';

IF CAST(@Number AS INT) = @Number
	PRINT 'whole number';
ELSE
	PRINT 'has fractional component';

IF (ROUND(@number,0,1) = @number)
	PRINT 'whole number';
ELSE
	PRINT 'has fractional component';

IF @number LIKE '%.%[1-9]%'
	PRINT 'has fractional component';
ELSE
	PRINT 'whole number';

 
 
 
 IF (FLOOR(@number) = @number)
	PRINT 'whole number';
ELSE
	PRINT 'has fractional component';
IF (CEILING(@number) = @number)
	PRINT 'whole number';
ELSE
	PRINT 'has fractional component';       
	
--Count Decimal Places	
	DECLARE @TestNum DECIMAL(38,15)
    SET @TestNum = 99.123456789012345
 SELECT 10-PATINDEX('%[^0]%',REVERSE(RIGHT(CAST(@TestNum as varchar),9))+'1')

--However... you gave me one heck of an idea... the following takes a bit more time (1,000,000 records in about 12 seconds)...

DECLARE @TestNum DECIMAL(38,15)
    SET @TestNum = 90 --99.123456780000000 --0.123456780000000 --99.1 --90

SELECT CHARINDEX('.',REVERSE(@TestNum))
      -PATINDEX('%[^0]%',REVERSE(@TestNum))
      
--currency format

--===== Create a data sample... this is not a part of the solution
DECLARE @SomeFormattedColumn VARCHAR(20)
    SET @SomeFormattedColumn = '$4,816,220.65'

--===== Solve the problem
 SELECT LEFT(@SomeFormattedColumn, 
             LEN(@SomeFormattedColumn)
           - ISNULL(LEN(@SomeFormattedColumn)
                  - NULLIF(CHARINDEX('.',@SomeFormattedColumn),0)+1
             ,0)
            )
            
 --Format phone numbers
 
 --===== Create and populate a test table.  This is NOT part of the solution
DECLARE @PhoneNumbers TABLE (Original VARCHAR(30))
 INSERT INTO @PhoneNumbers (Original)
 SELECT '+44 (0) 1908 123 456' UNION ALL
 SELECT '+44 (0) 121 430 4992' 

 SELECT Original,
        REPLACE(STUFF(PartialFormat,CHARINDEX(' ',PartialFormat),0,')'),'(',' (') AS Reformatted
   FROM (--==== Partially reformat the phone number by replacing the (0) and surrounding spaces
             -- with just a left parentheses...
         SELECT Original, REPLACE(Original, ' (0) ','(') AS PartialFormat FROM @PhoneNumbers
        ) d           
        
--Convert number to certain value or character


DECLARE @tbl_value TABLE (Code INT NOT NULL,Name VARCHAR(10) NOT NULL);
INSERT INTO @tbl_value(Code,Name)
VALUES (1,'A')
  ,(2,'B')
  ,(3,'C')
  ,(4,'D')
  ,(0,'X')
;
DECLARE @USER_VAL INT = 33410;

;WITH SINGLE_DIGITS(POS,DX) AS
(
  SELECT 1, @USER_VAL      % 10  UNION ALL
  SELECT 2, @USER_VAL / 10   % 10  UNION ALL
  SELECT 3, @USER_VAL / 100  % 10  UNION ALL
  SELECT 4, @USER_VAL / 1000 % 10  UNION ALL
  SELECT 5, @USER_VAL / 10000  % 10  UNION ALL
  SELECT 6, @USER_VAL / 100000 % 10  
)
SELECT
(
  SELECT
   '' + TV.Name
  FROM    @tbl_value    TV
  INNER JOIN  SINGLE_DIGITS   SD
  ON    SD.DX     = TV.Code
  WHERE   SD.POS <= (CEILING(LOG10(@USER_VAL + 0.0)))
  ORDER BY  SD.POS DESC
  FOR XML PATH(''),TYPE
).value('(./text())[1]','VARCHAR(10)') AS NAME_STR;



SELECT REPLACE(CONVERT(CHAR(36),NEWID())+CONVERT(CHAR(36),NEWID()),'-','')

--Random 64 Characters alphanumeric String
DECLARE @BINID VARBINARY(16) = NEWID();
;WITH BINARY_STUFF(DHASH,BINDATA,BINID)
AS
(
  SELECT CONVERT(CHAR(64),HASHBYTES('SHA2_512',CONVERT(VARCHAR(36),@BINID,0)),2),CONVERT(VARCHAR(36),@BINID,0),@BINID UNION ALL
  SELECT CONVERT(CHAR(64),HASHBYTES('SHA2_512',CONVERT(VARCHAR(36),@BINID,1)),2),CONVERT(VARCHAR(36),@BINID,1),@BINID UNION ALL
  SELECT CONVERT(CHAR(64),HASHBYTES('SHA2_512',CONVERT(VARCHAR(36),@BINID,2)),2),CONVERT(VARCHAR(36),@BINID,2),@BINID 
)
SELECT
  BS.DHASH
 ,BS.BINDATA
 ,BS.BINID
FROM  BINARY_STUFF  BS;