CREATE FUNCTION [dbo].[fx_FolderExists] (
	@Folder nvarchar(500),
	@Action tinyint
)
RETURNS int AS
/*
	----------------------------------------------------------------------------------------------------------------
	Purpose: Checks to see if a directory exists in any location
	Department	: DBA
	----------------------------------------------------------------------------------------------------------------
	NOTES: 1. Returns 0 if the folder being checked does NOT exist
		2. @Action = 0, Do nothing just test if folder exists, if @Action = 1, create the folder
		* OLE AUTOMATION MUST BE ENABLED ON THE DATABASE SERVER FOR THIS TO WORK * 
	----------------------------------------------------------------------------------------------------------------
	Created On	:	6/04/2014
	Create By	:	MyDoggieJessie
	----------------------------------------------------------------------------------------------------------------
	Modified On	:	
	Modified By	:	
	Changes	:	
		1.	
	----------------------------------------------------------------------------------------------------------------
	SELECT dbo.fx_FolderExists('\\NetworkPath\Folder', 1)
*/
BEGIN

/* ############## START MAIN PROCEDURE HERE ############## */
DECLARE @Exists int, @ObjFile int, @ObjFileSystem INT, @Idx tinyint
DECLARE @Folders TABLE (idx INT IDENTITY(1,1) , FLevel varchar(100))

EXEC dbo.sp_OACreate 'Scripting.FileSystemObject', @ObjFileSystem OUT
EXEC dbo.sp_OAMethod @ObjFileSystem, 'FolderExists', @Exists OUT, @Folder

IF @Action = 1
BEGIN
	IF @Exists = 0
	BEGIN
	INSERT INTO @Folders 
	SELECT Item FROM YourDB.dbo.fx_DelimitedSplit8K(@Folder, '\')
	WHERE Item <> ''

		SET @Idx = (SELECT TOP 1 idx FROM @Folders)
		SET @Folder = '\\'
		WHILE (@idx <= (SELECT MAX(idx) FROM @Folders))
		BEGIN
			SELECT @Folder = @Folder + (SELECT FLevel FROM @Folders WHERE idx = @Idx) + '\' 
				EXEC dbo.sp_OAMethod @ObjFileSystem, 'CreateFolder', @Folder OUT, @Folder
			SET @Idx = @idx + 1

			IF @@ERROR = 0 AND @Exists <> 0
				BEGIN	
					SET @Exists = 1
				END
			ELSE	
				BEGIN	
					SET @Exists = -1
				END
		END

	END
END 

EXEC dbo.sp_OADestroy @ObjFileSystem

RETURN ISNULL(@Exists, -1)

END

/* ########################################## END MAIN PROCEDURE HERE ########################################### */



