

create function dbo.Get_HarvestYear(@InputDate datetime)
returns table with schemabinding return
select year(dateadd(month, -6, @InputDate)) HarvestYear
go


SELECT
    isnull(HarvestYear,0) HarvestYear
FROM
    [tblFuelFlow]
    outer apply (select HarvestYear from dbo.Get_HarvestYear([ArrivalDateTime]);
