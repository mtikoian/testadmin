 CREATE FUNCTION CreateABACheckDigit
--===== Created by Jeff Moden
        (@RoutingNumber CHAR(8))
RETURNS INT
     AS
  BEGIN
 RETURN (SELECT NULLIF(10-( SUBSTRING(@RoutingNumber,1,1)*3
                          + SUBSTRING(@RoutingNumber,2,1)*7
                          + SUBSTRING(@RoutingNumber,3,1)*1
                          + SUBSTRING(@RoutingNumber,4,1)*3
                          + SUBSTRING(@RoutingNumber,5,1)*7
                          + SUBSTRING(@RoutingNumber,6,1)*1
                          + SUBSTRING(@RoutingNumber,7,1)*3
                          + SUBSTRING(@RoutingNumber,8,1)*7)%10
                      ,10))
    END