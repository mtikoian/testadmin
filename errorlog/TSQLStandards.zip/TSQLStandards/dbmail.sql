/**********************************************************************************************************************
 Create the test tables.  THIS SECTION IS NOT A PART OF THE SOLUTION!!! It just creates some test data.
**********************************************************************************************************************/
--===== Conditionally drop the test tables to make reruns easier
     IF OBJECT_ID('TempDB..#Staff') IS NOT NULL DROP TABLE #Staff;
     IF OBJECT_ID('TempDB..#Protocol') IS NOT NULL DROP TABLE #Protocol;

--===== Create the test tables
 CREATE TABLE #Staff
        (
        StaffID     int         IDENTITY(1,1) NOT NULL PRIMARY KEY CLUSTERED,
        FirstName   varchar(15) NOT NULL,
        LastName    varchar(20) NOT NULL,
        Department  varchar(50) NULL,
        Role        varchar(20) NULL,
        EMail       varchar(50) NULL,
        )
;
 CREATE TABLE #Protocol
        (
        ProtocolNo              varchar(30)     NOT NULL PRIMARY KEY CLUSTERED,
        PrincipalInvestigatorID int             NULL,
        StudyManagerID          int             NULL,
        OpenToEnrollDate        datetime        NULL,
        CloseToEnrollDate       datetime        NULL,
        EnrollmentGoal          int             NULL,
        IsOpen                  bit             NULL DEFAULT ((0)),
        NotifyOfOpenDate        smalldatetime   NULL,
        )
;
--===== Populate the test tables with data
 INSERT INTO #Staff
        (FirstName,LastName,Department,Role,EMail)
 SELECT 'Donald','Duck','Toons','Study Manager','dduck@toons.com' UNION ALL
 SELECT 'Mickey','Mouse','Toons','Study Manager','mmouse@toons.com'
;
 INSERT INTO #Protocol
        (ProtocolNo, StudyManagerID,OpenToEnrollDate, CloseToEnrollDate, EnrollmentGoal, IsOpen)
 SELECT 'BRE150', 1, '2010-08-26 22:01:56.857', NULL, 250,1 UNION ALL
 SELECT 'LUN120', 1, '2010-08-26 22:01:56.857', NULL, 50,1 UNION ALL
 SELECT 'LUN189', 2, '2010-08-26 22:01:56.857', NULL, 50,1 UNION ALL
 SELECT 'LUN90', 2, '2010-08-26 22:01:56.857', NULL, 20,1
;
GO
 CREATE PROCEDURE dbo.SendProtocol
/**********************************************************************************************************************
 Purpose:
 Send an email for all open Protocols for a given Study Manager ID. 
 (This IS a part of the solution)
**********************************************************************************************************************/
--===== Declare I/O Parameters
        @pStudyManagerID INT
     AS
--===== Environmental Presets
    SET NOCOUNT ON; 

--===== Declare local variables
DECLARE @Body       NVARCHAR(MAX),
        @Email      NVARCHAR(50),
        @FirstName  NVARCHAR(15)
;
--===== Get the email address and name for the given study manager id
 SELECT @FirstName = FirstName, 
        @EMail     = Email
   FROM #Staff 
  WHERE StaffID = @pStudyManagerID 
 ;      
--===== Create the body of the message including a nicely formatted table of the protocols
 SELECT @Body = 
------- Create the table and the table header. (Easily readable HTML)
'
<html>
<body>


Dear ' + @FirstName + ',


The following table contains a list of your open Protocols.
<table border="1" cellspacing="0" style="text-align:center">
        <caption>Protocols</caption>
        <tr style="background-color:AliceBlue"><th>Protocol No</th><th>Open to Enrollment Date</th><th>Enrollment Goal</th></tr>
'
------- Create the rest of the table.  Filled in from data in the table.
      + SPACE(8) 
      + REPLACE( --This just indents each row to make rows in the HTML apparent and easy to read
            CAST((SELECT td = ProtocolNo, N'', --<td></td> = "data" element in a row
                         td = CONVERT(NCHAR(11), OpenToEnrollDate, 106), N'',
                         td = CAST(EnrollmentGoal AS NVARCHAR(10)), N''
                    FROM #Protocol
                   WHERE IsOpen = 1
                     AND StudyManagerID = @pStudyManagerID
                     FOR XML PATH('tr'),TYPE --<tr></tr> = row encapsulation (The XML does a bunch of concatenation)
            )AS NVARCHAR(MAX))
        ,'</tr>','</tr>'+CHAR(10)+SPACE(8))
------- Finalize the HTML 
+ '
</table>
</body>
</html>'
;
--===== All set.  Send the email.
   EXEC msdb.dbo.sp_send_dbmail 
            @profile_name = 'Notifier_Profile',
            @recipients   = @EMail,
            @subject      = 'Your open Protocols',
            @body         = @Body
;
GO
 CREATE PROCEDURE dbo.SendAllProtocols
/**********************************************************************************************************************
 Purpose:
 Send an email for all open Protocols for each Study Manager ID that has open Protocols. 
 (This IS a part of the solution)
**********************************************************************************************************************/
--===== Declare I/O Parameters
     -- No parameters required for this proc
     AS
--===== Environmental Presets
    SET NOCOUNT ON; 

--===== Declare local variables
DECLARE @SendAll VARCHAR(MAX);

WITH cteStaffProtocol AS
( --=== This creates a list of all Staff IDs with at least 1 open protocol
 SELECT DISTINCT s.StaffID
   FROM #Staff s
  INNER JOIN #Protocol p
     ON s.StaffID = p.StudyManagerID
    AND p.IsOpen  = 1
) --=== This creates a list of commands to send protocol emails from the list of Staff IDs
 SELECT @SendAll = (SELECT 'EXEC dbo.SendProtocol ' + CAST(StaffID AS VARCHAR(10)) + CHAR(10)
                      FROM cteStaffProtocol sp
                       FOR XML PATH('')
                    )
;
--===== This executes ALL those commands to send ALL the emails 
   EXEC (@SendAll);
GO

--===== We're ready to rock... this will send ALL the emails... 
   EXEC dbo.SendAllProtocols

--===== ... or, you can send just one staff member his/her Protocol list
   EXEC dbo.SendProtocol 2