IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[coInsCarriers]') AND type in (N'U'))
  DROP TABLE [dbo].[coInsCarriers]
GO
CREATE TABLE [dbo].[coInsCarriers](
 [CarrierID] [int] IDENTITY(1,1) NOT NULL,
 [CarrierCode] [nvarchar](5) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
 [CarrierName] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
 -- Other non essential columns omitted
 CONSTRAINT [PK_coCarriers] PRIMARY KEY CLUSTERED 
(
 [CarrierID] ASC
)WITH (IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

SET IDENTITY_INSERT [dbo].[coInsCarriers] ON

INSERT INTO coInsCarriers (CarrierID, CarrierCode, CarrierName) VALUES (4, 'MCRTX', 'MEDICARE TX/')
INSERT INTO coInsCarriers (CarrierID, CarrierCode, CarrierName) VALUES (19, 'BTX',   'BCBS OF MICHIGAN')
INSERT INTO coInsCarriers (CarrierID, CarrierCode, CarrierName) VALUES (31, 'MCRTX', 'MEDICARE PART B')
INSERT INTO coInsCarriers (CarrierID, CarrierCode, CarrierName) VALUES (37, 'Group', 'PRO NET INSURANCE COMPANY')
INSERT INTO coInsCarriers (CarrierID, CarrierCode, CarrierName) VALUES (43, 'MD2',   'DEPT OF COMMUNITY HEALTH')
INSERT INTO coInsCarriers (CarrierID, CarrierCode, CarrierName) VALUES (48, 'Group', 'USAA LIFE INSURANCE')
INSERT INTO coInsCarriers (CarrierID, CarrierCode, CarrierName) VALUES (49, 'Group', 'NATIONAL STATES INS')
INSERT INTO coInsCarriers (CarrierID, CarrierCode, CarrierName) VALUES (57, 'Group', 'AETNA/')
INSERT INTO coInsCarriers (CarrierID, CarrierCode, CarrierName) VALUES (58, 'Group', 'TRICARE/TRICARE FOR LIFE')
INSERT INTO coInsCarriers (CarrierID, CarrierCode, CarrierName) VALUES (59, 'Group', 'TRICARE/TRICARE PRIME')
INSERT INTO coInsCarriers (CarrierID, CarrierCode, CarrierName) VALUES (61, 'Group', 'FIRSTCARE/')
INSERT INTO coInsCarriers (CarrierID, CarrierCode, CarrierName) VALUES (65, 'Group', 'CONSTITUTION LIFE INSURANCE/')
INSERT INTO coInsCarriers (CarrierID, CarrierCode, CarrierName) VALUES (72, 'Group', 'AARP/')
INSERT INTO coInsCarriers (CarrierID, CarrierCode, CarrierName) VALUES (94, 'Group', 'AETNA/AETNA')
INSERT INTO coInsCarriers (CarrierID, CarrierCode, CarrierName) VALUES (101, 'Group', 'STATE MUTUAL/STATE MUTUAL')
INSERT INTO coInsCarriers (CarrierID, CarrierCode, CarrierName) VALUES (160, 'MCRTX', 'MEDICARE TX/')
INSERT INTO coInsCarriers (CarrierID, CarrierCode, CarrierName) VALUES (197, 'Group', 'GPA/HEALTHSMART')
INSERT INTO coInsCarriers (CarrierID, CarrierCode, CarrierName) VALUES (198, 'Group', 'STERLING OPTION I/')
INSERT INTO coInsCarriers (CarrierID, CarrierCode, CarrierName) VALUES (211, 'Group', 'UNITED HEALTHCARE/')
INSERT INTO coInsCarriers (CarrierID, CarrierCode, CarrierName) VALUES (235, 'Group', 'NEW ERA LIFE INSURANCE COMPANY/')
INSERT INTO coInsCarriers (CarrierID, CarrierCode, CarrierName) VALUES (280, 'Group', 'WAUSAU BENEFITS/')
INSERT INTO coInsCarriers (CarrierID, CarrierCode, CarrierName) VALUES (311, 'CHAMP', 'HUMANA MILITARY HEALTH SERVICES/')
INSERT INTO coInsCarriers (CarrierID, CarrierCode, CarrierName) VALUES (325, 'Group', 'AETNA LIFE AND CASUALTY/')
INSERT INTO coInsCarriers (CarrierID, CarrierCode, CarrierName) VALUES (364, 'Group', 'PATIENT ACCESS NETWORK FOUNDATION/')
INSERT INTO coInsCarriers (CarrierID, CarrierCode, CarrierName) VALUES (386, 'Group', 'STATE FARM INSURANCE COMPANY/GREELEY SOUTH OPERATI')
INSERT INTO coInsCarriers (CarrierID, CarrierCode, CarrierName) VALUES (394, 'Group', 'PROVIDENT AMERICAN LIFE & HEALTH/')
INSERT INTO coInsCarriers (CarrierID, CarrierCode, CarrierName) VALUES (405, 'Group', 'EASTLAND COUNTY INDIGENT HEALTH CARE/')
GO                         
SET IDENTITY_INSERT [dbo].[coInsCarriers] OFF


IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ptContacts]') AND type in (N'U'))
  DROP TABLE [dbo].[ptContacts]
GO
CREATE TABLE [dbo].[ptContacts](
    [ContactID] [int] IDENTITY(1,1) NOT NULL,
    [MRN] [varchar](25) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
    [ContactName] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
    [FName] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
    [MI] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
    [LName] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
    [Address1] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
    [Address2] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
    [City] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
    [State] [nvarchar](2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
    [Zip] [nvarchar](15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
    [HomePhone] [nvarchar](25) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
    [WorkPhone] [nvarchar](25) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
    -- Other non essential columns omitted
 CONSTRAINT [PK_ptContacts] PRIMARY KEY CLUSTERED 
(
  [ContactID] ASC
)WITH (IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
SET IDENTITY_INSERT [dbo].[ptContacts] ON
GO
INSERT INTO ptContacts ([ContactID], [MRN],[ContactName], [FName], [MI], [LName], [Address1], [Address2], [City], [State], [Zip], [HomePhone], [WorkPhone])
     VALUES (29966, '10046', 'ContactName1', 'FName1', 'G', 'LName1', 'Address1', 'Address21', 'City1', 'TX', 'Zip1', 'HomePhone1', 'WorkPhone1')
INSERT INTO ptContacts ([ContactID], [MRN],[ContactName], [FName], [MI], [LName], [Address1], [Address2], [City], [State], [Zip], [HomePhone], [WorkPhone])
     VALUES (30021, '10121', 'ContactName2', 'Fname2', 'L', 'LName2', 'Address2', 'Address22', 'City2', 'TX', 'Zip2', 'HomePhone2', 'WorkPhone2')
INSERT INTO ptContacts ([ContactID], [MRN],[ContactName], [FName], [MI], [LName], [Address1], [Address2], [City], [State], [Zip], [HomePhone], [WorkPhone])
     VALUES (30295, '10554', 'ContactName3', 'FName3', 'G', 'LName3', 'Address3', 'Address23', 'City3', 'TX', 'Zip3', 'HomePhone3', 'WorkPhone3')
INSERT INTO ptContacts ([ContactID], [MRN],[ContactName], [FName], [MI], [LName], [Address1], [Address2], [City], [State], [Zip], [HomePhone], [WorkPhone])
     VALUES (30590, '1112', 'ContactName4', 'FName4', '', 'LName4', 'Address4', 'Address24', 'City4', 'TX', 'Zip4', 'HomePhone4', 'WorkPhone4')
INSERT INTO ptContacts ([ContactID], [MRN],[ContactName], [FName], [MI], [LName], [Address1], [Address2], [City], [State], [Zip], [HomePhone], [WorkPhone])
     VALUES (30968, '1195', 'ContactName5', 'FName5', 'L', 'LName5', 'Address5', 'Address25', 'City5', 'TX', 'Zip5', 'HomePhone5', 'WorkPhone5')
INSERT INTO ptContacts ([ContactID], [MRN],[ContactName], [FName], [MI], [LName], [Address1], [Address2], [City], [State], [Zip], [HomePhone], [WorkPhone])
     VALUES (31461, '12987', 'ContactName6', 'FName6', 'S', 'LName6', 'Address6', 'Address26', 'City6', 'TX', 'Zip6', 'HomePhone6', 'WorkPhone6')
INSERT INTO ptContacts ([ContactID], [MRN],[ContactName], [FName], [MI], [LName], [Address1], [Address2], [City], [State], [Zip], [HomePhone], [WorkPhone])
     VALUES (31697, '13473', 'ContactName7', 'FName7', 'L', 'LName7', 'Address7', 'Address27', 'City7', 'TX', 'Zip7', 'HomePhone7', 'WorkPhone7')
INSERT INTO ptContacts ([ContactID], [MRN],[ContactName], [FName], [MI], [LName], [Address1], [Address2], [City], [State], [Zip], [HomePhone], [WorkPhone])
     VALUES (32043, '14204', 'ContactName8', 'FName8', 'S', 'LName8', 'Address8', 'Address28', 'City8', 'TX', 'Zip8', 'HomePhone8', 'WorkPhone8')
INSERT INTO ptContacts ([ContactID], [MRN],[ContactName], [FName], [MI], [LName], [Address1], [Address2], [City], [State], [Zip], [HomePhone], [WorkPhone])
     VALUES (32251, '1461', 'ContactName9', 'FName9', 'A', 'LName9', 'Address9', 'Address29', 'City9', 'TX', 'Zip9', 'HomePhone9', 'WorkPhone9')
INSERT INTO ptContacts ([ContactID], [MRN],[ContactName], [FName], [MI], [LName], [Address1], [Address2], [City], [State], [Zip], [HomePhone], [WorkPhone])
     VALUES (32410, '14942', 'ContactName10', 'FName10', 'L', 'LName10', 'Address10', 'Address30', 'City10', 'TX', 'Zip10', 'HomePhone10', 'WorkPhone10')
INSERT INTO ptContacts ([ContactID], [MRN],[ContactName], [FName], [MI], [LName], [Address1], [Address2], [City], [State], [Zip], [HomePhone], [WorkPhone])
     VALUES (32611, '15332', 'ContactName11', 'FName11', 'G', 'LName11', 'Address11', 'Address31', 'City11', 'TX', 'Zip11', 'HomePhone11', 'WorkPhone11')
INSERT INTO ptContacts ([ContactID], [MRN],[ContactName], [FName], [MI], [LName], [Address1], [Address2], [City], [State], [Zip], [HomePhone], [WorkPhone])
     VALUES (32635, '15385', 'ContactName12', 'FName12', 'L', 'LName12', 'Address12', 'Address32', 'City12', 'TX', 'Zip12', 'HomePhone12', 'WorkPhone12')
INSERT INTO ptContacts ([ContactID], [MRN],[ContactName], [FName], [MI], [LName], [Address1], [Address2], [City], [State], [Zip], [HomePhone], [WorkPhone])
     VALUES (32682, '15475', 'ContactName13', 'FName13', 'L', 'LName13', 'Address13', 'Address33', 'City13', 'TX', 'Zip13', 'HomePhone13', 'WorkPhone13')
INSERT INTO ptContacts ([ContactID], [MRN],[ContactName], [FName], [MI], [LName], [Address1], [Address2], [City], [State], [Zip], [HomePhone], [WorkPhone])
     VALUES (33061, '16193', 'ContactName14', 'FName14', 'L', 'LName14', 'Address14', 'Address34', 'City14', 'TX', 'Zip14', 'HomePhone14', 'WorkPhone14')
INSERT INTO ptContacts ([ContactID], [MRN],[ContactName], [FName], [MI], [LName], [Address1], [Address2], [City], [State], [Zip], [HomePhone], [WorkPhone])
     VALUES (33389, '168', 'ContactName15', 'FName15', 'B', 'LName15', 'Address15', 'Address35', 'City15', 'TX', 'Zip15', 'HomePhone15', 'WorkPhone15')
INSERT INTO ptContacts ([ContactID], [MRN],[ContactName], [FName], [MI], [LName], [Address1], [Address2], [City], [State], [Zip], [HomePhone], [WorkPhone])
     VALUES (33549, '1821', 'ContactName16', 'FName16', 'L', 'LName16', 'Address16', 'Address36', 'City16', 'TX', 'Zip16', 'HomePhone16', 'WorkPhone16')
INSERT INTO ptContacts ([ContactID], [MRN],[ContactName], [FName], [MI], [LName], [Address1], [Address2], [City], [State], [Zip], [HomePhone], [WorkPhone])
     VALUES (33704, '1960', 'ContactName17', 'FName17', 'G', 'LName17', 'Address17', 'Address37', 'City17', 'TX', 'Zip17', 'HomePhone17', 'WorkPhone17')
INSERT INTO ptContacts ([ContactID], [MRN],[ContactName], [FName], [MI], [LName], [Address1], [Address2], [City], [State], [Zip], [HomePhone], [WorkPhone])
     VALUES (34265, '2466', 'ContactName18', 'FName18', 'J', 'LName18', 'Address18', 'Address38', 'City18', 'TX', 'Zip18', 'HomePhone18', 'WorkPhone18')
INSERT INTO ptContacts ([ContactID], [MRN],[ContactName], [FName], [MI], [LName], [Address1], [Address2], [City], [State], [Zip], [HomePhone], [WorkPhone])
     VALUES (34468, '265', 'ContactName19', 'FName19', 'H', 'LName19', 'Address19', 'Address39', 'City19', 'TX', 'Zip19', 'HomePhone19', 'WorkPhone19')
INSERT INTO ptContacts ([ContactID], [MRN],[ContactName], [FName], [MI], [LName], [Address1], [Address2], [City], [State], [Zip], [HomePhone], [WorkPhone])
     VALUES (35211, '3319', 'ContactName20', 'FName20', 'N', 'LName20', 'Address20', 'Address40', 'City20', 'TX', 'Zip20', 'HomePhone20', 'WorkPhone20')
INSERT INTO ptContacts ([ContactID], [MRN],[ContactName], [FName], [MI], [LName], [Address1], [Address2], [City], [State], [Zip], [HomePhone], [WorkPhone])
     VALUES (35715, '3775', 'ContactName21', 'FName21', 'M', 'LName21', 'Address21', 'Address41', 'City21', 'TX', 'Zip21', 'HomePhone21', 'WorkPhone21')
INSERT INTO ptContacts ([ContactID], [MRN],[ContactName], [FName], [MI], [LName], [Address1], [Address2], [City], [State], [Zip], [HomePhone], [WorkPhone])
     VALUES (35814, '3864', 'ContactName22', 'FName22', 'K', 'LName22', 'Address22', 'Address42', 'City22', 'TX', 'Zip22', 'HomePhone22', 'WorkPhone22')
INSERT INTO ptContacts ([ContactID], [MRN],[ContactName], [FName], [MI], [LName], [Address1], [Address2], [City], [State], [Zip], [HomePhone], [WorkPhone])
     VALUES (36951, '51', 'ContactName23', 'FName23', 'M', 'LName23', 'Address23', 'Address43', 'City23', 'TX', 'Zip23', 'HomePhone23', 'WorkPhone23')
INSERT INTO ptContacts ([ContactID], [MRN],[ContactName], [FName], [MI], [LName], [Address1], [Address2], [City], [State], [Zip], [HomePhone], [WorkPhone])
     VALUES (37684, '6429', 'ContactName24', 'FName24', 'L', 'LName24', 'Address24', 'Address44', 'City24', 'TX', 'Zip24', 'HomePhone24', 'WorkPhone24')
INSERT INTO ptContacts ([ContactID], [MRN],[ContactName], [FName], [MI], [LName], [Address1], [Address2], [City], [State], [Zip], [HomePhone], [WorkPhone])
     VALUES (37752, '6556', 'ContactName25', 'FName25', 'L', 'LName25', 'Address25', 'Address45', 'City25', 'TX', 'Zip25', 'HomePhone25', 'WorkPhone25')
INSERT INTO ptContacts ([ContactID], [MRN],[ContactName], [FName], [MI], [LName], [Address1], [Address2], [City], [State], [Zip], [HomePhone], [WorkPhone])
     VALUES (37758, '6567', 'ContactName26', 'FName26', 'D', 'LName26', 'Address26', 'Address46', 'City26', 'TX', 'Zip26', 'HomePhone26', 'WorkPhone26')
INSERT INTO ptContacts ([ContactID], [MRN],[ContactName], [FName], [MI], [LName], [Address1], [Address2], [City], [State], [Zip], [HomePhone], [WorkPhone])
     VALUES (38593, '797', 'ContactName27', 'FName27', '', 'LName27', 'Address27', 'Address47', 'City27', 'TX', 'Zip27', 'HomePhone27', 'WorkPhone27')
INSERT INTO ptContacts ([ContactID], [MRN],[ContactName], [FName], [MI], [LName], [Address1], [Address2], [City], [State], [Zip], [HomePhone], [WorkPhone])
     VALUES (39131, '8810', 'ContactName28', 'FName28', 'B', 'LName28', 'Address28', 'Address48', 'City28', 'TX', 'Zip28', 'HomePhone28', 'WorkPhone28')
GO
SET IDENTITY_INSERT [dbo].[ptContacts] OFF
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ptDemographics]') AND type in (N'U'))
  DROP TABLE [dbo].[ptDemographics]
GO
CREATE TABLE [dbo].[ptDemographics](
        [MRN] [varchar](25) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
        [FName] [nvarchar](35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ptDemographics_FName]  DEFAULT (''),
        [MI] [nvarchar](25) COLLATE SQL_Latin1_General_CP1_CI_AS NULL CONSTRAINT [DF_ptDemographics_MI]  DEFAULT (''),
        [LName] [nvarchar](35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ptDemographics_LName]  DEFAULT (''),
        [Surname] [nvarchar](25) COLLATE SQL_Latin1_General_CP1_CI_AS NULL CONSTRAINT [DF_ptDemographics_Surname]  DEFAULT (''),
        [Address1] [char](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
        [Address2] [char](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
        [City] [char](25) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
        [State] [char](2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
        [Zip] [char](10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
        [HomePhone] [nvarchar](25) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
        [WorkPhone] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
        [DateOfBirth] [datetime] NULL,
        [SocialSecurityNum] [nvarchar](15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL CONSTRAINT [DF_ptDemographics_SocialSecurityNum]  DEFAULT (''),
        [Gender] [nvarchar](6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
        [Physician] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
        -- Other non essential columns omitted
 CONSTRAINT [PK_ptDemographics] PRIMARY KEY CLUSTERED 
(
        [MRN] ASC
)WITH (IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
   
INSERT INTO ptDemographics ([MRN], [FName], [MI], [LName], [Surname], [Address1], [Address2], [City], [State]
                                             , [Zip], [HomePhone], [WorkPhone], [DateOfBirth], [SocialSecurityNum], [Gender], [Physician])
     VALUES ('10046', 'FName1', 'G', 'LName1', '', 'Address1', '', 'City1', 'TX', 'Zip1', 'HomePhone1', 'WorkPhone1', '1937-02-18 00:00:00.000', 'SSN1', 'M', 'Doctor')
INSERT INTO ptDemographics ([MRN], [FName], [MI], [LName], [Surname], [Address1], [Address2], [City], [State]
                                             , [Zip], [HomePhone], [WorkPhone], [DateOfBirth], [SocialSecurityNum], [Gender], [Physician])
     VALUES ('10121', 'FName2', 'L', 'LName2', '', 'Address2', '', 'City2', 'TX', 'Zip2', 'HomePhone2', 'WorkPhone2', '1951-06-28 00:00:00.000', 'SSN2', 'F', 'Doctor2')
INSERT INTO ptDemographics ([MRN], [FName], [MI], [LName], [Surname], [Address1], [Address2], [City], [State]
                                             , [Zip], [HomePhone], [WorkPhone], [DateOfBirth], [SocialSecurityNum], [Gender], [Physician])
     VALUES ('10554', 'FName3', 'G', 'LName3', '', 'Address3', '', 'City3', 'TX', 'Zip3', 'HomePhone3', 'WorkPhone3', '1934-09-12 00:00:00.000', 'SSN3', 'F', 'Doctor3')
INSERT INTO ptDemographics ([MRN], [FName], [MI], [LName], [Surname], [Address1], [Address2], [City], [State]
                                             , [Zip], [HomePhone], [WorkPhone], [DateOfBirth], [SocialSecurityNum], [Gender], [Physician])
     VALUES ('1112', 'FName4', '', 'LName4', '', 'Address4', '', 'City4', 'TX', 'Zip4', 'HomePhone4', 'WorkPhone4', '1947-10-22 00:00:00.000', 'SSN4', 'F', 'Doctor')
INSERT INTO ptDemographics ([MRN], [FName], [MI], [LName], [Surname], [Address1], [Address2], [City], [State]
                                             , [Zip], [HomePhone], [WorkPhone], [DateOfBirth], [SocialSecurityNum], [Gender], [Physician])
     VALUES ('1195', 'FName5', 'L', 'LName5', '', 'Address5', '', 'City5', 'TX', 'Zip5', 'HomePhone5', 'WorkPhone5', '1939-01-01 00:00:00.000', 'SSN5', 'M', 'Doctor')
INSERT INTO ptDemographics ([MRN], [FName], [MI], [LName], [Surname], [Address1], [Address2], [City], [State]
                                             , [Zip], [HomePhone], [WorkPhone], [DateOfBirth], [SocialSecurityNum], [Gender], [Physician])
     VALUES ('12987', 'FName6', 'S', 'LName6', '', 'Address6', '', 'City6', 'TX', 'Zip6', 'HomePhone6', 'WorkPhone6', '1946-08-18 00:00:00.000', 'SSN6', 'F', 'Doctor3')
INSERT INTO ptDemographics ([MRN], [FName], [MI], [LName], [Surname], [Address1], [Address2], [City], [State]
                                             , [Zip], [HomePhone], [WorkPhone], [DateOfBirth], [SocialSecurityNum], [Gender], [Physician])
     VALUES ('13473', 'FName7', 'L', 'LName7', '', 'Address7', '', 'City7', 'TX', 'Zip7', 'HomePhone7', 'WorkPhone7', '1962-06-14 00:00:00.000', 'SSN7', 'F', 'Doctor3')
INSERT INTO ptDemographics ([MRN], [FName], [MI], [LName], [Surname], [Address1], [Address2], [City], [State]
                                             , [Zip], [HomePhone], [WorkPhone], [DateOfBirth], [SocialSecurityNum], [Gender], [Physician])
     VALUES ('14204', 'FName8', 'S', 'LName8', '', 'Address8', '', 'City8', 'TX', 'Zip8', 'HomePhone8', 'WorkPhone8', '1948-07-01 00:00:00.000', 'SSN8', 'F', 'Doctor')
INSERT INTO ptDemographics ([MRN], [FName], [MI], [LName], [Surname], [Address1], [Address2], [City], [State]
                                             , [Zip], [HomePhone], [WorkPhone], [DateOfBirth], [SocialSecurityNum], [Gender], [Physician])
     VALUES ('1461', 'FName9', 'A', 'LName9', '', 'Address9', '', 'City9', 'TX', 'Zip9', 'HomePhone9', 'WorkPhone9', '1936-02-12 00:00:00.000', 'SSN9', 'F', 'Doctor')
INSERT INTO ptDemographics ([MRN], [FName], [MI], [LName], [Surname], [Address1], [Address2], [City], [State]
                                             , [Zip], [HomePhone], [WorkPhone], [DateOfBirth], [SocialSecurityNum], [Gender], [Physician])
     VALUES ('14942', 'FName10', 'L', 'LName10', '', 'Address10', '', 'City10', 'TX', 'Zip10', 'HomePhone10', 'WorkPhone10', '1935-11-02 00:00:00.000', 'SSN10', 'M', 'Doctor')
INSERT INTO ptDemographics ([MRN], [FName], [MI], [LName], [Surname], [Address1], [Address2], [City], [State]
                                             , [Zip], [HomePhone], [WorkPhone], [DateOfBirth], [SocialSecurityNum], [Gender], [Physician])
     VALUES ('15332', 'FName11', 'G', 'LName11', '', 'Address11', '', 'City11', 'TX', 'Zip11', 'HomePhone11', 'WorkPhone11', '1920-08-26 00:00:00.000', 'SSN11', 'F', 'Doctor4')
INSERT INTO ptDemographics ([MRN], [FName], [MI], [LName], [Surname], [Address1], [Address2], [City], [State]
                                             , [Zip], [HomePhone], [WorkPhone], [DateOfBirth], [SocialSecurityNum], [Gender], [Physician])
     VALUES ('15385', 'FName12', 'L', 'LName12', '', 'Address12', '', 'City12', 'TX', 'Zip12', 'HomePhone12', 'WorkPhone12', '1937-11-28 00:00:00.000', 'SSN12', 'M', 'Doctor')
INSERT INTO ptDemographics ([MRN], [FName], [MI], [LName], [Surname], [Address1], [Address2], [City], [State]
                                             , [Zip], [HomePhone], [WorkPhone], [DateOfBirth], [SocialSecurityNum], [Gender], [Physician])
     VALUES ('15475', 'FName13', 'L', 'LName13', '', 'Address13', '', 'City13', 'TX', 'Zip13', 'HomePhone13', 'WorkPhone13', '1960-08-05 00:00:00.000', 'SSN13', 'M', 'Doctor')
INSERT INTO ptDemographics ([MRN], [FName], [MI], [LName], [Surname], [Address1], [Address2], [City], [State]
                                             , [Zip], [HomePhone], [WorkPhone], [DateOfBirth], [SocialSecurityNum], [Gender], [Physician])
     VALUES ('16193', 'FName14', 'L', 'LName14', '', 'Address14', '', 'City14', 'TX', 'Zip14', 'HomePhone14', 'WorkPhone14', '1923-07-31 00:00:00.000', 'SSN14', 'F', 'Doctor')
INSERT INTO ptDemographics ([MRN], [FName], [MI], [LName], [Surname], [Address1], [Address2], [City], [State]
                                             , [Zip], [HomePhone], [WorkPhone], [DateOfBirth], [SocialSecurityNum], [Gender], [Physician])
     VALUES ('168', 'FName15', 'B', 'LName15', '', 'Address15', '', 'City15', 'TX', 'Zip15', 'HomePhone15', 'WorkPhone15', '1930-01-05 00:00:00.000', 'SSN15', 'F', 'Doctor')
INSERT INTO ptDemographics ([MRN], [FName], [MI], [LName], [Surname], [Address1], [Address2], [City], [State]
                                             , [Zip], [HomePhone], [WorkPhone], [DateOfBirth], [SocialSecurityNum], [Gender], [Physician])
     VALUES ('1821', 'FName16', 'L', 'LName16', '', 'Address16', '', 'City16', 'TX', 'Zip16', 'HomePhone16', 'WorkPhone16', '1926-07-04 00:00:00.000', 'SSN16', 'F', 'Doctor')
INSERT INTO ptDemographics ([MRN], [FName], [MI], [LName], [Surname], [Address1], [Address2], [City], [State]
                                             , [Zip], [HomePhone], [WorkPhone], [DateOfBirth], [SocialSecurityNum], [Gender], [Physician])
     VALUES ('1960', 'FName17', 'G', 'LName17', '', 'Address17', '', 'City17', 'TX', 'Zip17', 'HomePhone17', 'WorkPhone17', '1966-04-19 00:00:00.000', 'SSN17', 'F', 'Doctor')
INSERT INTO ptDemographics ([MRN], [FName], [MI], [LName], [Surname], [Address1], [Address2], [City], [State]
                                             , [Zip], [HomePhone], [WorkPhone], [DateOfBirth], [SocialSecurityNum], [Gender], [Physician])
     VALUES ('2466', 'FName18', 'J', 'LName18', '', 'Address18', '', 'City18', 'TX', 'Zip18', 'HomePhone18', 'WorkPhone18', '1944-03-22 00:00:00.000', 'SSN18', 'F', 'Doctor')
INSERT INTO ptDemographics ([MRN], [FName], [MI], [LName], [Surname], [Address1], [Address2], [City], [State]
                                             , [Zip], [HomePhone], [WorkPhone], [DateOfBirth], [SocialSecurityNum], [Gender], [Physician])
     VALUES ('265', 'FName19', 'H', 'LName19', '', 'Address19', '', 'City19', 'TX', 'Zip19', 'HomePhone19', 'WorkPhone19', '1932-05-27 00:00:00.000', 'SSN19', 'M', 'Doctor')
INSERT INTO ptDemographics ([MRN], [FName], [MI], [LName], [Surname], [Address1], [Address2], [City], [State]
                                             , [Zip], [HomePhone], [WorkPhone], [DateOfBirth], [SocialSecurityNum], [Gender], [Physician])
     VALUES ('3319', 'FName20', 'N', 'LName20', '', 'Address20', '', 'City20', 'TX', 'Zip20', 'HomePhone20', 'WorkPhone20', '1935-07-21 00:00:00.000', 'SSN20', 'M', 'Doctor2')
INSERT INTO ptDemographics ([MRN], [FName], [MI], [LName], [Surname], [Address1], [Address2], [City], [State]
                                             , [Zip], [HomePhone], [WorkPhone], [DateOfBirth], [SocialSecurityNum], [Gender], [Physician])
     VALUES ('3775', 'FName21', 'M', 'LName21', '', 'Address21', '', 'City21', 'TX', 'Zip21', 'HomePhone21', 'WorkPhone21', '1958-01-29 00:00:00.000', 'SSN21', 'F', 'Doctor')
INSERT INTO ptDemographics ([MRN], [FName], [MI], [LName], [Surname], [Address1], [Address2], [City], [State]
                                             , [Zip], [HomePhone], [WorkPhone], [DateOfBirth], [SocialSecurityNum], [Gender], [Physician])
     VALUES ('3864', 'FName22', 'K', 'LName22', '', 'Address22', '', 'City22', 'TX', 'Zip22', 'HomePhone22', 'WorkPhone22', '1957-01-19 00:00:00.000', 'SSN22', 'F', 'Doctor2')
INSERT INTO ptDemographics ([MRN], [FName], [MI], [LName], [Surname], [Address1], [Address2], [City], [State]
                                             , [Zip], [HomePhone], [WorkPhone], [DateOfBirth], [SocialSecurityNum], [Gender], [Physician])
     VALUES ('51', 'FName23', 'M', 'LName23', '', 'Address23', '', 'City23', 'TX', 'Zip23', 'HomePhone23', 'WorkPhone23', '1942-10-05 00:00:00.000', 'SSN23', 'F', 'Doctor')
INSERT INTO ptDemographics ([MRN], [FName], [MI], [LName], [Surname], [Address1], [Address2], [City], [State]
                                             , [Zip], [HomePhone], [WorkPhone], [DateOfBirth], [SocialSecurityNum], [Gender], [Physician])
     VALUES ('6429', 'FName24', 'L', 'LName24', '', 'Address24', '', 'City24', 'TX', 'Zip24', 'HomePhone24', 'WorkPhone24', '1941-08-08 00:00:00.000', 'SSN24', 'M', 'Doctor')
INSERT INTO ptDemographics ([MRN], [FName], [MI], [LName], [Surname], [Address1], [Address2], [City], [State]
                                             , [Zip], [HomePhone], [WorkPhone], [DateOfBirth], [SocialSecurityNum], [Gender], [Physician])
     VALUES ('6556', 'FName25', 'L', 'LName25', '', 'Address25', '', 'City25', 'TX', 'Zip25', 'HomePhone25', 'WorkPhone25', '1950-04-24 00:00:00.000', 'SSN25', 'F', 'Doctor')
INSERT INTO ptDemographics ([MRN], [FName], [MI], [LName], [Surname], [Address1], [Address2], [City], [State]
                                             , [Zip], [HomePhone], [WorkPhone], [DateOfBirth], [SocialSecurityNum], [Gender], [Physician])
     VALUES ('6567', 'FName26', 'D', 'LName26', '', 'Address26', '', 'City26', 'TX', 'Zip26', 'HomePhone26', 'WorkPhone26', '1963-03-06 00:00:00.000', 'SSN26', 'F', 'Doctor2')
INSERT INTO ptDemographics ([MRN], [FName], [MI], [LName], [Surname], [Address1], [Address2], [City], [State]
                                             , [Zip], [HomePhone], [WorkPhone], [DateOfBirth], [SocialSecurityNum], [Gender], [Physician])
     VALUES ('797', 'FName27', '', 'LName27', '', 'Address27', '', 'City27', 'TX', 'Zip27', 'HomePhone27', 'WorkPhone27', '1928-08-01 00:00:00.000', 'SSN27', 'F', 'Doctor')
INSERT INTO ptDemographics ([MRN], [FName], [MI], [LName], [Surname], [Address1], [Address2], [City], [State]
                                             , [Zip], [HomePhone], [WorkPhone], [DateOfBirth], [SocialSecurityNum], [Gender], [Physician])
     VALUES ('8810', 'FName28', 'B', 'LName28', '', 'Address28', '', 'City', 'TX', 'Zip28', 'HomePhone28', 'WorkPhone28', '1935-06-25 00:00:00.000', 'SSN28', 'F', 'Doctor')
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ptInsurancePlans]') AND type in (N'U'))
  DROP TABLE [dbo].[ptInsurancePlans]
GO
CREATE TABLE [dbo].[ptInsurancePlans](
        [InsurancePlanID] [int] IDENTITY(1,1) NOT NULL,
        [MRN] [varchar](25) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
        [InsuranceLevel] [int] NULL,
        [Sequence] [int] NULL,
        [CarrierID] [int] NULL,
        [GroupID] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
        [GroupName] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
        [PolicyID] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
        [SubscriberContactID] [int] NULL,
        [EffectiveDtTm] [datetime] NULL,
        [ExpirationDtTm] [datetime] NULL,
        [Copay] [decimal](18, 2) NULL,
        [CoIns] [decimal](18, 2) NULL,
        [SubscriberID] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
        -- Other non essential columns omitted
 CONSTRAINT [PK_ptInsurancePlans] PRIMARY KEY CLUSTERED 
(
        [InsurancePlanID] ASC
)WITH (IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
SET IDENTITY_INSERT [dbo].[ptInsurancePlans] ON
GO

INSERT INTO ptInsurancePlans ([InsurancePlanID], [MRN], [InsuranceLevel], [Sequence], [CarrierID], [GroupID], [GroupName], [PolicyID]
                            , [SubscriberContactID], [EffectiveDtTm], [ExpirationDtTm], [Copay], [CoIns], [SubscriberID])
     VALUES (5476, '3319',  1, 1, 4, NULL, NULL, 'PolicyID1',  35211, '6/1/2004', '12/31/2005', 0, NULL, NULL)
INSERT INTO ptInsurancePlans ([InsurancePlanID], [MRN], [InsuranceLevel], [Sequence], [CarrierID], [GroupID], [GroupName], [PolicyID]
                            , [SubscriberContactID], [EffectiveDtTm], [ExpirationDtTm], [Copay], [CoIns], [SubscriberID])
     VALUES (9205, '3319',  1, 1, 4, NULL, NULL, 'PolicyID2',  35211, '1/1/2006', '12/31/9998', 0, NULL, NULL)
INSERT INTO ptInsurancePlans ([InsurancePlanID], [MRN], [InsuranceLevel], [Sequence], [CarrierID], [GroupID], [GroupName], [PolicyID]
                            , [SubscriberContactID], [EffectiveDtTm], [ExpirationDtTm], [Copay], [CoIns], [SubscriberID])
     VALUES (9759, '6567',  1, 1, 4, NULL, NULL, 'PolicyID3',  37758, '2/1/2006', '12/31/9998', 0, NULL, NULL)
INSERT INTO ptInsurancePlans ([InsurancePlanID], [MRN], [InsuranceLevel], [Sequence], [CarrierID], [GroupID], [GroupName], [PolicyID]
                            , [SubscriberContactID], [EffectiveDtTm], [ExpirationDtTm], [Copay], [CoIns], [SubscriberID])
     VALUES (10247, '10554', 1, 1, 4, NULL, NULL, 'PolicyID4',  30295, '6/1/2001', '12/31/9998', 0, 80, NULL)
INSERT INTO ptInsurancePlans ([InsurancePlanID], [MRN], [InsuranceLevel], [Sequence], [CarrierID], [GroupID], [GroupName], [PolicyID]
                            , [SubscriberContactID], [EffectiveDtTm], [ExpirationDtTm], [Copay], [CoIns], [SubscriberID])
     VALUES (13541, '51',    1, 1, 4, NULL, NULL, 'PolicyID5',  36951, '10/1/2007', '12/31/9998', 0, 20, NULL)
INSERT INTO ptInsurancePlans ([InsurancePlanID], [MRN], [InsuranceLevel], [Sequence], [CarrierID], [GroupID], [GroupName], [PolicyID]
                            , [SubscriberContactID], [EffectiveDtTm], [ExpirationDtTm], [Copay], [CoIns], [SubscriberID])
     VALUES (13870, '14942', 1, 1, 4, NULL, NULL, 'PolicyID6',  32410, '12/1/1995', '12/31/9998', 0, 80, NULL)
INSERT INTO ptInsurancePlans ([InsurancePlanID], [MRN], [InsuranceLevel], [Sequence], [CarrierID], [GroupID], [GroupName], [PolicyID]
                            , [SubscriberContactID], [EffectiveDtTm], [ExpirationDtTm], [Copay], [CoIns], [SubscriberID])
     VALUES (14314, '15385', 1, 1, 4, NULL, NULL, 'PolicyID7',  32635, '11/1/2002', '12/31/9998', 0, 80, NULL)
INSERT INTO ptInsurancePlans ([InsurancePlanID], [MRN], [InsuranceLevel], [Sequence], [CarrierID], [GroupID], [GroupName], [PolicyID]
                            , [SubscriberContactID], [EffectiveDtTm], [ExpirationDtTm], [Copay], [CoIns], [SubscriberID])
     VALUES (14406, '15332', 1, 1, 4, NULL, NULL, 'PolicyID8',  32611, '8/1/1985', '12/31/9998', 0, 80, NULL)
INSERT INTO ptInsurancePlans ([InsurancePlanID], [MRN], [InsuranceLevel], [Sequence], [CarrierID], [GroupID], [GroupName], [PolicyID]
                            , [SubscriberContactID], [EffectiveDtTm], [ExpirationDtTm], [Copay], [CoIns], [SubscriberID])
     VALUES (14538, '10046', 1, 1, 4, NULL, NULL, 'PolicyID9',  29966, '1/1/2008', '12/31/9998', 0, 80, NULL)
INSERT INTO ptInsurancePlans ([InsurancePlanID], [MRN], [InsuranceLevel], [Sequence], [CarrierID], [GroupID], [GroupName], [PolicyID]
                            , [SubscriberContactID], [EffectiveDtTm], [ExpirationDtTm], [Copay], [CoIns], [SubscriberID])
     VALUES (15132, '16193', 1, 1, 4, NULL, NULL, 'PolicyID10', 33061, '7/1/1988', '12/31/9998', 0, 80, NULL)
INSERT INTO ptInsurancePlans ([InsurancePlanID], [MRN], [InsuranceLevel], [Sequence], [CarrierID], [GroupID], [GroupName], [PolicyID]
                            , [SubscriberContactID], [EffectiveDtTm], [ExpirationDtTm], [Copay], [CoIns], [SubscriberID])
     VALUES (935, '1195',  1, 1, 19, 'GroupID11', NULL, 'PolicyID11', 30968, '11/20/2002', '8/1/2003', 0, NULL, NULL)
INSERT INTO ptInsurancePlans ([InsurancePlanID], [MRN], [InsuranceLevel], [Sequence], [CarrierID], [GroupID], [GroupName], [PolicyID]
                            , [SubscriberContactID], [EffectiveDtTm], [ExpirationDtTm], [Copay], [CoIns], [SubscriberID])
     VALUES (1116, '1461',  2, 2, 19, 'GroupID12', NULL, 'PolicyID12', 32251, '10/21/1984', '12/31/9998', 0, 20, NULL)
INSERT INTO ptInsurancePlans ([InsurancePlanID], [MRN], [InsuranceLevel], [Sequence], [CarrierID], [GroupID], [GroupName], [PolicyID]
                            , [SubscriberContactID], [EffectiveDtTm], [ExpirationDtTm], [Copay], [CoIns], [SubscriberID])
     VALUES (1834, '2466',  1, 1, 19, 'GroupID13', NULL, 'PolicyID13', 34265, '1/1/2004', '12/31/9998', 20, NULL, NULL)
INSERT INTO ptInsurancePlans ([InsurancePlanID], [MRN], [InsuranceLevel], [Sequence], [CarrierID], [GroupID], [GroupName], [PolicyID]
                            , [SubscriberContactID], [EffectiveDtTm], [ExpirationDtTm], [Copay], [CoIns], [SubscriberID])
     VALUES (2460, '3319',  2, 2, 19, 'GroupID14', NULL, 'PolicyID14', 35211, '5/1/2003', '5/31/2004', 0, NULL, NULL)
INSERT INTO ptInsurancePlans ([InsurancePlanID], [MRN], [InsuranceLevel], [Sequence], [CarrierID], [GroupID], [GroupName], [PolicyID]
                            , [SubscriberContactID], [EffectiveDtTm], [ExpirationDtTm], [Copay], [CoIns], [SubscriberID])
     VALUES (2867, '1960',  1, 1, 19, 'GroupID15', NULL, 'PolicyID15', 33704, '9/1/2002', '12/31/9998', 35, 80, NULL)
INSERT INTO ptInsurancePlans ([InsurancePlanID], [MRN], [InsuranceLevel], [Sequence], [CarrierID], [GroupID], [GroupName], [PolicyID]
                            , [SubscriberContactID], [EffectiveDtTm], [ExpirationDtTm], [Copay], [CoIns], [SubscriberID])
     VALUES (2887, '1195',  1, 1, 19, 'GroupID16', NULL, 'PolicyID16', 30968, '5/2/2003', '12/31/9998', 30, NULL, NULL)
INSERT INTO ptInsurancePlans ([InsurancePlanID], [MRN], [InsuranceLevel], [Sequence], [CarrierID], [GroupID], [GroupName], [PolicyID]
                            , [SubscriberContactID], [EffectiveDtTm], [ExpirationDtTm], [Copay], [CoIns], [SubscriberID])
     VALUES (3069, '3775',  1, 1, 19, 'GroupID17', NULL, 'PolicyID17', 35715, '10/1/2003', '3/31/2008', 35, NULL, NULL)
INSERT INTO ptInsurancePlans ([InsurancePlanID], [MRN], [InsuranceLevel], [Sequence], [CarrierID], [GroupID], [GroupName], [PolicyID]
                            , [SubscriberContactID], [EffectiveDtTm], [ExpirationDtTm], [Copay], [CoIns], [SubscriberID])
     VALUES (4745, '1195',  1, 1, 19, 'GroupID18', NULL, 'PolicyID18', 30968, '1/1/2004', '12/31/9998', 0, NULL, NULL)
INSERT INTO ptInsurancePlans ([InsurancePlanID], [MRN], [InsuranceLevel], [Sequence], [CarrierID], [GroupID], [GroupName], [PolicyID]
                            , [SubscriberContactID], [EffectiveDtTm], [ExpirationDtTm], [Copay], [CoIns], [SubscriberID])
     VALUES (5247, '1112',  1, 1, 19, 'GroupID19', NULL, 'PolicyID19', 30590, '3/18/1994', '12/31/9998', 15, 90, NULL)
INSERT INTO ptInsurancePlans ([InsurancePlanID], [MRN], [InsuranceLevel], [Sequence], [CarrierID], [GroupID], [GroupName], [PolicyID]
                            , [SubscriberContactID], [EffectiveDtTm], [ExpirationDtTm], [Copay], [CoIns], [SubscriberID])
     VALUES (9711, '10046', 2, 2, 19, 'GroupID20', NULL, 'PolicyID20', 29966, '1/1/2006', '12/31/2007', 0, 80, NULL)
INSERT INTO ptInsurancePlans ([InsurancePlanID], [MRN], [InsuranceLevel], [Sequence], [CarrierID], [GroupID], [GroupName], [PolicyID]
                            , [SubscriberContactID], [EffectiveDtTm], [ExpirationDtTm], [Copay], [CoIns], [SubscriberID])
     VALUES (14315, '15385', 2, 2, 19, 'GroupID21', NULL, 'PolicyID21', 32635, '12/1/2002', '12/31/9998', 0, 20, NULL)
INSERT INTO ptInsurancePlans ([InsurancePlanID], [MRN], [InsuranceLevel], [Sequence], [CarrierID], [GroupID], [GroupName], [PolicyID]
                            , [SubscriberContactID], [EffectiveDtTm], [ExpirationDtTm], [Copay], [CoIns], [SubscriberID])
     VALUES (14407, '15332', 2, 2, 19, NULL, NULL, 'PolicyID22', 32611, '1/15/1993', '12/31/9998', 0, 20, NULL)
INSERT INTO ptInsurancePlans ([InsurancePlanID], [MRN], [InsuranceLevel], [Sequence], [CarrierID], [GroupID], [GroupName], [PolicyID]
                            , [SubscriberContactID], [EffectiveDtTm], [ExpirationDtTm], [Copay], [CoIns], [SubscriberID])
     VALUES (118, '168',   1, 1, 31, NULL, NULL, 'PolicyID23', 33389, '11/20/2003', '12/31/9998', 0, NULL, NULL)
INSERT INTO ptInsurancePlans ([InsurancePlanID], [MRN], [InsuranceLevel], [Sequence], [CarrierID], [GroupID], [GroupName], [PolicyID]
                            , [SubscriberContactID], [EffectiveDtTm], [ExpirationDtTm], [Copay], [CoIns], [SubscriberID])
     VALUES (190, '265',   1, 1, 31, NULL, NULL, 'PolicyID24', 34468, '5/1/1997', '12/31/9998', 0, NULL, NULL)
INSERT INTO ptInsurancePlans ([InsurancePlanID], [MRN], [InsuranceLevel], [Sequence], [CarrierID], [GroupID], [GroupName], [PolicyID]
                            , [SubscriberContactID], [EffectiveDtTm], [ExpirationDtTm], [Copay], [CoIns], [SubscriberID])
     VALUES (623, '797',   1, 1, 31, NULL, NULL, 'PolicyID25', 38593, '11/20/2003', '12/31/9998', 0, NULL, NULL)
INSERT INTO ptInsurancePlans ([InsurancePlanID], [MRN], [InsuranceLevel], [Sequence], [CarrierID], [GroupID], [GroupName], [PolicyID]
                            , [SubscriberContactID], [EffectiveDtTm], [ExpirationDtTm], [Copay], [CoIns], [SubscriberID])
     VALUES (1117, '1461',  1, 1, 31, NULL, NULL, 'PolicyID26', 32251, '2/1/2001', '12/31/9998', 0, 80, NULL)
INSERT INTO ptInsurancePlans ([InsurancePlanID], [MRN], [InsuranceLevel], [Sequence], [CarrierID], [GroupID], [GroupName], [PolicyID]
                            , [SubscriberContactID], [EffectiveDtTm], [ExpirationDtTm], [Copay], [CoIns], [SubscriberID])
     VALUES (1386, '1821',  1, 1, 31, NULL, NULL, 'PolicyID27', 33549, '7/1/1991', '6/30/2006', 0, NULL, NULL)
INSERT INTO ptInsurancePlans ([InsurancePlanID], [MRN], [InsuranceLevel], [Sequence], [CarrierID], [GroupID], [GroupName], [PolicyID]
                            , [SubscriberContactID], [EffectiveDtTm], [ExpirationDtTm], [Copay], [CoIns], [SubscriberID])
     VALUES (2459, '3319',  1, 1, 31, NULL, NULL, 'PolicyID28', 35211, '5/1/2003', '5/31/2004', 0, NULL, NULL)
INSERT INTO ptInsurancePlans ([InsurancePlanID], [MRN], [InsuranceLevel], [Sequence], [CarrierID], [GroupID], [GroupName], [PolicyID]
                            , [SubscriberContactID], [EffectiveDtTm], [ExpirationDtTm], [Copay], [CoIns], [SubscriberID])
     VALUES (4678, '1195',  2, 2, 31, NULL, NULL, 'PolicyID29', 30968, '6/1/2004', '12/31/9998', 0, NULL, NULL)
INSERT INTO ptInsurancePlans ([InsurancePlanID], [MRN], [InsuranceLevel], [Sequence], [CarrierID], [GroupID], [GroupName], [PolicyID]
                            , [SubscriberContactID], [EffectiveDtTm], [ExpirationDtTm], [Copay], [CoIns], [SubscriberID])
     VALUES (5204, '797',   1, 1, 31, NULL, NULL, 'PolicyID30', 38593, '11/20/2003', '12/31/9998', 0, NULL, NULL)
INSERT INTO ptInsurancePlans ([InsurancePlanID], [MRN], [InsuranceLevel], [Sequence], [CarrierID], [GroupID], [GroupName], [PolicyID]
                            , [SubscriberContactID], [EffectiveDtTm], [ExpirationDtTm], [Copay], [CoIns], [SubscriberID])
     VALUES (8458, '8810',  1, 1, 31, NULL, NULL, 'PolicyID31', 39131, '6/1/2000', '12/31/9998', 0, NULL, NULL)
INSERT INTO ptInsurancePlans ([InsurancePlanID], [MRN], [InsuranceLevel], [Sequence], [CarrierID], [GroupID], [GroupName], [PolicyID]
                            , [SubscriberContactID], [EffectiveDtTm], [ExpirationDtTm], [Copay], [CoIns], [SubscriberID])
     VALUES (937, '1195',  2, 2, 37, NULL, NULL, 'PolicyID32', 30968, '11/20/2002', '8/1/2003', 0, NULL, NULL)
INSERT INTO ptInsurancePlans ([InsurancePlanID], [MRN], [InsuranceLevel], [Sequence], [CarrierID], [GroupID], [GroupName], [PolicyID]
                            , [SubscriberContactID], [EffectiveDtTm], [ExpirationDtTm], [Copay], [CoIns], [SubscriberID])
     VALUES (3251, '3864',  1, 1, 43, NULL, NULL, 'PolicyID33', 35814, '11/1/2003', '12/1/2004', 0, NULL, NULL)
INSERT INTO ptInsurancePlans ([InsurancePlanID], [MRN], [InsuranceLevel], [Sequence], [CarrierID], [GroupID], [GroupName], [PolicyID]
                            , [SubscriberContactID], [EffectiveDtTm], [ExpirationDtTm], [Copay], [CoIns], [SubscriberID])
     VALUES (14873, '15475', 1, 1, 43, NULL, NULL, 'PolicyID34', 32682, '4/1/2008', '12/31/9998', 0, NULL, NULL)
INSERT INTO ptInsurancePlans ([InsurancePlanID], [MRN], [InsuranceLevel], [Sequence], [CarrierID], [GroupID], [GroupName], [PolicyID]
                            , [SubscriberContactID], [EffectiveDtTm], [ExpirationDtTm], [Copay], [CoIns], [SubscriberID])
     VALUES (119, '168',   2, 2, 48, NULL, NULL, 'PolicyID35', 33389, '11/20/2003', '12/31/9998', 0, NULL, NULL)
INSERT INTO ptInsurancePlans ([InsurancePlanID], [MRN], [InsuranceLevel], [Sequence], [CarrierID], [GroupID], [GroupName], [PolicyID]
                            , [SubscriberContactID], [EffectiveDtTm], [ExpirationDtTm], [Copay], [CoIns], [SubscriberID])
     VALUES (4568, '51',    2, 2, 49, NULL, NULL, 'PolicyID36', 36951, '6/1/2004', '10/31/2004', 0, NULL, NULL)
INSERT INTO ptInsurancePlans ([InsurancePlanID], [MRN], [InsuranceLevel], [Sequence], [CarrierID], [GroupID], [GroupName], [PolicyID]
                            , [SubscriberContactID], [EffectiveDtTm], [ExpirationDtTm], [Copay], [CoIns], [SubscriberID])
     VALUES (5683, '51',    2, 2, 49, NULL, NULL, 'PolicyID37', 36951, '11/1/2004', '9/30/2007', 0, NULL, NULL)
INSERT INTO ptInsurancePlans ([InsurancePlanID], [MRN], [InsuranceLevel], [Sequence], [CarrierID], [GroupID], [GroupName], [PolicyID]
                            , [SubscriberContactID], [EffectiveDtTm], [ExpirationDtTm], [Copay], [CoIns], [SubscriberID])
     VALUES (3570, '265',   2, 2, 57, 'GroupID38', NULL, 'PolicyID38', 34468, '5/1/1997', '12/31/9998', 0, NULL, NULL)
INSERT INTO ptInsurancePlans ([InsurancePlanID], [MRN], [InsuranceLevel], [Sequence], [CarrierID], [GroupID], [GroupName], [PolicyID]
                            , [SubscriberContactID], [EffectiveDtTm], [ExpirationDtTm], [Copay], [CoIns], [SubscriberID])
     VALUES (6205, '6429',  1, 1, 57, 'GroupID39', NULL, 'PolicyID39', 37684, '9/1/2004', '7/31/2006', 25, NULL, NULL)
INSERT INTO ptInsurancePlans ([InsurancePlanID], [MRN], [InsuranceLevel], [Sequence], [CarrierID], [GroupID], [GroupName], [PolicyID]
                            , [SubscriberContactID], [EffectiveDtTm], [ExpirationDtTm], [Copay], [CoIns], [SubscriberID])
     VALUES (10722, '6429',  2, 2, 57, 'GroupID40', NULL, 'PolicyID40', 37684, '8/1/2006', '12/31/9998', 0, NULL, NULL)
INSERT INTO ptInsurancePlans ([InsurancePlanID], [MRN], [InsuranceLevel], [Sequence], [CarrierID], [GroupID], [GroupName], [PolicyID]
                            , [SubscriberContactID], [EffectiveDtTm], [ExpirationDtTm], [Copay], [CoIns], [SubscriberID])
     VALUES (4567, '51',    1, 1, 58, NULL, NULL, 'PolicyID41', 36951, '6/1/2004', '10/31/2004', 0, NULL, NULL)
INSERT INTO ptInsurancePlans ([InsurancePlanID], [MRN], [InsuranceLevel], [Sequence], [CarrierID], [GroupID], [GroupName], [PolicyID]
                            , [SubscriberContactID], [EffectiveDtTm], [ExpirationDtTm], [Copay], [CoIns], [SubscriberID])
     VALUES (13542, '51',    2, 2, 59, NULL, NULL, 'PolicyID42', 36951, '10/1/2007', '12/31/9998', 0, NULL, NULL)
INSERT INTO ptInsurancePlans ([InsurancePlanID], [MRN], [InsuranceLevel], [Sequence], [CarrierID], [GroupID], [GroupName], [PolicyID]
                            , [SubscriberContactID], [EffectiveDtTm], [ExpirationDtTm], [Copay], [CoIns], [SubscriberID])
     VALUES (6415, '6556',  1, 1, 61, NULL, NULL, 'PolicyID43', 37752, '9/1/2004', '12/31/9998', 40, NULL, NULL)
INSERT INTO ptInsurancePlans ([InsurancePlanID], [MRN], [InsuranceLevel], [Sequence], [CarrierID], [GroupID], [GroupName], [PolicyID]
                            , [SubscriberContactID], [EffectiveDtTm], [ExpirationDtTm], [Copay], [CoIns], [SubscriberID])
     VALUES (12212, '12987', 1, 1, 61, 'GroupID44', NULL, 'PolicyID44', 31461, '9/1/2003', '12/31/9998', '40', '100', NULL)
INSERT INTO ptInsurancePlans ([InsurancePlanID], [MRN], [InsuranceLevel], [Sequence], [CarrierID], [GroupID], [GroupName], [PolicyID]
                            , [SubscriberContactID], [EffectiveDtTm], [ExpirationDtTm], [Copay], [CoIns], [SubscriberID])
     VALUES (8459, '8810',  2, 2, 65, NULL, NULL, 'PolicyID45', 39131, '6/1/2000', '12/31/9998', 0, NULL, NULL)
INSERT INTO ptInsurancePlans ([InsurancePlanID], [MRN], [InsuranceLevel], [Sequence], [CarrierID], [GroupID], [GroupName], [PolicyID]
                            , [SubscriberContactID], [EffectiveDtTm], [ExpirationDtTm], [Copay], [CoIns], [SubscriberID])
     VALUES (5205, '797',   2, 2, 72, NULL, NULL, 'PolicyID46', 38593, '6/1/2004', '12/31/9998', 0, NULL, NULL)
INSERT INTO ptInsurancePlans ([InsurancePlanID], [MRN], [InsuranceLevel], [Sequence], [CarrierID], [GroupID], [GroupName], [PolicyID]
                            , [SubscriberContactID], [EffectiveDtTm], [ExpirationDtTm], [Copay], [CoIns], [SubscriberID])
     VALUES (9206, '3319',  2, 2, 72, 'GroupID47', NULL, 'PolicyID47', 35211, '1/1/2006', '12/31/9998', 0, NULL, NULL)
INSERT INTO ptInsurancePlans ([InsurancePlanID], [MRN], [InsuranceLevel], [Sequence], [CarrierID], [GroupID], [GroupName], [PolicyID]
                            , [SubscriberContactID], [EffectiveDtTm], [ExpirationDtTm], [Copay], [CoIns], [SubscriberID])
     VALUES (10248, '10554', 2, 2, 94, 'GroupID48', NULL, 'PolicyID48', 30295, '6/1/2001', '12/31/9998', 0, 80, NULL)
INSERT INTO ptInsurancePlans ([InsurancePlanID], [MRN], [InsuranceLevel], [Sequence], [CarrierID], [GroupID], [GroupName], [PolicyID]
                            , [SubscriberContactID], [EffectiveDtTm], [ExpirationDtTm], [Copay], [CoIns], [SubscriberID])
     VALUES (4122, '797',   2, 2, 101, 'GroupID49', NULL, 'PolicyID49', 38593, '9/1/2000', '5/30/2004', 0, NULL, NULL)
INSERT INTO ptInsurancePlans ([InsurancePlanID], [MRN], [InsuranceLevel], [Sequence], [CarrierID], [GroupID], [GroupName], [PolicyID]
                            , [SubscriberContactID], [EffectiveDtTm], [ExpirationDtTm], [Copay], [CoIns], [SubscriberID])
     VALUES (9038, '3864',  1, 1, 160, NULL, NULL, 'PolicyID50', 35814, '2/1/2006', '12/31/9998', 0, NULL, NULL)
INSERT INTO ptInsurancePlans ([InsurancePlanID], [MRN], [InsuranceLevel], [Sequence], [CarrierID], [GroupID], [GroupName], [PolicyID]
                            , [SubscriberContactID], [EffectiveDtTm], [ExpirationDtTm], [Copay], [CoIns], [SubscriberID])
     VALUES (9710, '10046', 1, 1, 160, NULL, NULL, 'PolicyID51', 29966, '1/1/2006', '12/31/2007', 0, NULL, NULL)
INSERT INTO ptInsurancePlans ([InsurancePlanID], [MRN], [InsuranceLevel], [Sequence], [CarrierID], [GroupID], [GroupName], [PolicyID]
                            , [SubscriberContactID], [EffectiveDtTm], [ExpirationDtTm], [Copay], [CoIns], [SubscriberID])
     VALUES (10595, '1821',  1, 1, 160, NULL, NULL, 'PolicyID52', 33549, '7/1/2006', '12/31/9998', 0, NULL, NULL)
INSERT INTO ptInsurancePlans ([InsurancePlanID], [MRN], [InsuranceLevel], [Sequence], [CarrierID], [GroupID], [GroupName], [PolicyID]
                            , [SubscriberContactID], [EffectiveDtTm], [ExpirationDtTm], [Copay], [CoIns], [SubscriberID])
     VALUES (10721, '6429',  1, 1, 160, NULL, NULL, 'PolicyID53', 37684, '8/1/2006', '12/31/9998', 0, NULL, NULL)
INSERT INTO ptInsurancePlans ([InsurancePlanID], [MRN], [InsuranceLevel], [Sequence], [CarrierID], [GroupID], [GroupName], [PolicyID]
                            , [SubscriberContactID], [EffectiveDtTm], [ExpirationDtTm], [Copay], [CoIns], [SubscriberID])
     VALUES (13292, '14204', 1, 1, 197, 'GroupID54', NULL, 'PolicyID54', 32043, '7/1/2006', '12/31/9998', 20, 80, NULL)
INSERT INTO ptInsurancePlans ([InsurancePlanID], [MRN], [InsuranceLevel], [Sequence], [CarrierID], [GroupID], [GroupName], [PolicyID]
                            , [SubscriberContactID], [EffectiveDtTm], [ExpirationDtTm], [Copay], [CoIns], [SubscriberID])
     VALUES (6378, '6567',  1, 1, 198, 'GroupID55', NULL, 'PolicyID55', 37758, '1/1/2003', '2/27/2006', '35', NULL, NULL)
INSERT INTO ptInsurancePlans ([InsurancePlanID], [MRN], [InsuranceLevel], [Sequence], [CarrierID], [GroupID], [GroupName], [PolicyID]
                            , [SubscriberContactID], [EffectiveDtTm], [ExpirationDtTm], [Copay], [CoIns], [SubscriberID])
     VALUES (9848, '10121', 1, 1, 211, 'GroupID56', NULL, 'PolicyID56', 30021, '6/13/2006', '12/31/9998', 25, NULL, NULL)
INSERT INTO ptInsurancePlans ([InsurancePlanID], [MRN], [InsuranceLevel], [Sequence], [CarrierID], [GroupID], [GroupName], [PolicyID]
                            , [SubscriberContactID], [EffectiveDtTm], [ExpirationDtTm], [Copay], [CoIns], [SubscriberID])
     VALUES (11745, '10121', 1, 1, 211, 'GroupID57', NULL, 'PolicyID57', 30021, '1/1/2007', '12/31/9998', 30, 20, NULL)
INSERT INTO ptInsurancePlans ([InsurancePlanID], [MRN], [InsuranceLevel], [Sequence], [CarrierID], [GroupID], [GroupName], [PolicyID]
                            , [SubscriberContactID], [EffectiveDtTm], [ExpirationDtTm], [Copay], [CoIns], [SubscriberID])
     VALUES (13871, '14942', 2, 2, 211, 'GroupID58', NULL, 'PolicyID58', 32410, '4/1/2006', '12/31/9998', 0, 80, NULL)
INSERT INTO ptInsurancePlans ([InsurancePlanID], [MRN], [InsuranceLevel], [Sequence], [CarrierID], [GroupID], [GroupName], [PolicyID]
                            , [SubscriberContactID], [EffectiveDtTm], [ExpirationDtTm], [Copay], [CoIns], [SubscriberID])
     VALUES (1387, '1821',  2, 2, 235, 'GroupID59', NULL, 'PolicyID59', 33549, '9/1/1997', '6/30/2006', 0, NULL, NULL)
INSERT INTO ptInsurancePlans ([InsurancePlanID], [MRN], [InsuranceLevel], [Sequence], [CarrierID], [GroupID], [GroupName], [PolicyID]
                            , [SubscriberContactID], [EffectiveDtTm], [ExpirationDtTm], [Copay], [CoIns], [SubscriberID])
     VALUES (5477, '3319',  2, 2, 280, 'GroupID60', NULL, 'PolicyID60', 35211, '6/1/2004', '12/31/2005', 0, NULL, NULL)
INSERT INTO ptInsurancePlans ([InsurancePlanID], [MRN], [InsuranceLevel], [Sequence], [CarrierID], [GroupID], [GroupName], [PolicyID]
                            , [SubscriberContactID], [EffectiveDtTm], [ExpirationDtTm], [Copay], [CoIns], [SubscriberID])
     VALUES (5682, '51',    1, 1, 311, NULL, NULL, 'PolicyID61',        36951, '11/1/2004', '9/30/2007', 0, NULL, NULL)
INSERT INTO ptInsurancePlans ([InsurancePlanID], [MRN], [InsuranceLevel], [Sequence], [CarrierID], [GroupID], [GroupName], [PolicyID]
                            , [SubscriberContactID], [EffectiveDtTm], [ExpirationDtTm], [Copay], [CoIns], [SubscriberID])
     VALUES (12681, '13473', 1, 1, 311, NULL, NULL, 'PolicyID62',        31697, '11/1/2004', '12/31/9998', 0, 80, NULL)
INSERT INTO ptInsurancePlans ([InsurancePlanID], [MRN], [InsuranceLevel], [Sequence], [CarrierID], [GroupID], [GroupName], [PolicyID]
                            , [SubscriberContactID], [EffectiveDtTm], [ExpirationDtTm], [Copay], [CoIns], [SubscriberID])
     VALUES (14539, '10046', 2, 2, 325, 'GroupID63', NULL, 'PolicyID63', 29966, '1/1/2008', '12/31/9998', 0, 20, NULL)
INSERT INTO ptInsurancePlans ([InsurancePlanID], [MRN], [InsuranceLevel], [Sequence], [CarrierID], [GroupID], [GroupName], [PolicyID]
                            , [SubscriberContactID], [EffectiveDtTm], [ExpirationDtTm], [Copay], [CoIns], [SubscriberID])
     VALUES (9760, '6567',   2, 2, 364, NULL, NULL, 'PolicyID64', 37758, '2/28/2006', '12/31/9998', 0, NULL, NULL)
INSERT INTO ptInsurancePlans ([InsurancePlanID], [MRN], [InsuranceLevel], [Sequence], [CarrierID], [GroupID], [GroupName], [PolicyID]
                            , [SubscriberContactID], [EffectiveDtTm], [ExpirationDtTm], [Copay], [CoIns], [SubscriberID])
     VALUES (15133, '16193', 2, 2, 386, 'GroupID65', NULL, 'PolicyID65', 33061, '8/1/1992', '12/31/9998', 0, 20, NULL)
INSERT INTO ptInsurancePlans ([InsurancePlanID], [MRN], [InsuranceLevel], [Sequence], [CarrierID], [GroupID], [GroupName], [PolicyID]
                            , [SubscriberContactID], [EffectiveDtTm], [ExpirationDtTm], [Copay], [CoIns], [SubscriberID])
     VALUES (10596, '1821',  2, 2, 394, 'GroupID66', NULL, 'PolicyID66', 33549, '7/1/2006', '12/31/9998', 0, NULL, NULL)
INSERT INTO ptInsurancePlans ([InsurancePlanID], [MRN], [InsuranceLevel], [Sequence], [CarrierID], [GroupID], [GroupName], [PolicyID]
                            , [SubscriberContactID], [EffectiveDtTm], [ExpirationDtTm], [Copay], [CoIns], [SubscriberID])
     VALUES (14470, '15475', 1, 1, 405, 'GroupID67', NULL, 'PolicyID67', 32682, '12/1/2007', '3/31/2008', 0, NULL, NULL)
GO
SET IDENTITY_INSERT [dbo].[ptInsurancePlans] OFF
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ptSchedule]') AND type in (N'U'))
  DROP TABLE [dbo].[ptSchedule]
GO
CREATE TABLE [dbo].[ptSchedule](
        [ScheduleId] [int] IDENTITY(1,1) NOT NULL,
        [MRN] [varchar](25) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
        [ApptTypeID] [int] NULL,
        [ResourceId] [int] NULL,
        [StartDtTm] [datetime] NULL,
        [EndDtTm] [datetime] NULL,
        [Description] [nvarchar](1000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
        [Notes] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
        [Status] [int] NULL,
        [CheckedInDtTm] [datetime] NULL,
        [CheckedOutDtTm] [datetime] NULL,
        [EncounterID] [int] NULL,
        -- Other non essential columns omitted
 CONSTRAINT [PK_ptSchedule] PRIMARY KEY CLUSTERED 
(
        [ScheduleId] ASC
)WITH (IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
SET IDENTITY_INSERT [dbo].[ptSchedule] ON
GO

INSERT INTO ptSchedule ([ScheduleId], [MRN], [ApptTypeID], [ResourceId], [StartDtTm], [EndDtTm]
                      , [Description], [Notes], [Status], [CheckedInDtTm], [CheckedOutDtTm]
                      , [EncounterID])
     VALUES (13071, '51',   2,  21, '9/15/2008', '9/15/2008', 'OV-CXR-LAB results -CHEMO- 6 MONTH- 4314', 'PATIENT 1', 1, '9/15/2008', '9/15/2008', NULL)
INSERT INTO ptSchedule ([ScheduleId], [MRN], [ApptTypeID], [ResourceId], [StartDtTm], [EndDtTm]
                      , [Description], [Notes], [Status], [CheckedInDtTm], [CheckedOutDtTm]
                      , [EncounterID])
     VALUES (106790,'51',   2,  7, '9/15/2008', '9/15/2008', 'ESTABLISHED PATIENT', 'PATIENT 1', 1, '9/15/2008', '9/15/2008', NULL)
INSERT INTO ptSchedule ([ScheduleId], [MRN], [ApptTypeID], [ResourceId], [StartDtTm], [EndDtTm]
                      , [Description], [Notes], [Status], [CheckedInDtTm], [CheckedOutDtTm]
                      , [EncounterID])
     VALUES (8675,  '168',  2,  21, '9/15/2008', '9/15/2008', 'OV-CXR / LAB RSLTS / 1 YEAR / 4314 (SAW LANA LAST)', 'PATIENT 2', 1, '9/15/2008', '9/15/2008', NULL)
INSERT INTO ptSchedule ([ScheduleId], [MRN], [ApptTypeID], [ResourceId], [StartDtTm], [EndDtTm]
                      , [Description], [Notes], [Status], [CheckedInDtTm], [CheckedOutDtTm]
                      , [EncounterID])
     VALUES (65189, '168',  2,  7, '9/15/2008', '9/15/2008', 'ESTABLISHED PATIENT', 'PATIENT 2', 1, '9/15/2008', '9/15/2008', NULL)
INSERT INTO ptSchedule ([ScheduleId], [MRN], [ApptTypeID], [ResourceId], [StartDtTm], [EndDtTm]
                      , [Description], [Notes], [Status], [CheckedInDtTm], [CheckedOutDtTm]
                      , [EncounterID])
     VALUES (73981, '265',  2,  7, '9/15/2008', '9/15/2008', 'ESTABLISHED PATIENT', 'PATIENT 3', 1, '9/15/2008', '9/15/2008', NULL)
INSERT INTO ptSchedule ([ScheduleId], [MRN], [ApptTypeID], [ResourceId], [StartDtTm], [EndDtTm]
                      , [Description], [Notes], [Status], [CheckedInDtTm], [CheckedOutDtTm]
                      , [EncounterID])
     VALUES (141692,'797',  14, 9, '9/15/2008', '9/15/2008', 'SHORT APPT.', 'PATIENT 4', 1, '9/15/2008', '9/15/2008', NULL)
INSERT INTO ptSchedule ([ScheduleId], [MRN], [ApptTypeID], [ResourceId], [StartDtTm], [EndDtTm]
                      , [Description], [Notes], [Status], [CheckedInDtTm], [CheckedOutDtTm]
                      , [EncounterID])
     VALUES (38956, '1112', 14, 9, '9/15/2008', '9/15/2008', 'SHORT APPT.', 'PATIENT 5', 1, '9/15/2008', '9/15/2008', NULL)
INSERT INTO ptSchedule ([ScheduleId], [MRN], [ApptTypeID], [ResourceId], [StartDtTm], [EndDtTm]
                      , [Description], [Notes], [Status], [CheckedInDtTm], [CheckedOutDtTm]
                      , [EncounterID])
     VALUES (43074, '1195', 14, 9, '9/15/2008', '9/15/2008', 'SHORT APPT.', 'PATIENT 6', 1, '9/15/2008', '9/15/2008', NULL)
INSERT INTO ptSchedule ([ScheduleId], [MRN], [ApptTypeID], [ResourceId], [StartDtTm], [EndDtTm]
                      , [Description], [Notes], [Status], [CheckedInDtTm], [CheckedOutDtTm]
                      , [EncounterID])
     VALUES (57671, '1461', 14, 9, '9/15/2008', '9/15/2008', 'SHORT APPT.', 'PATIENT 7', 1, '9/15/2008', '9/15/2008', NULL)
INSERT INTO ptSchedule ([ScheduleId], [MRN], [ApptTypeID], [ResourceId], [StartDtTm], [EndDtTm]
                      , [Description], [Notes], [Status], [CheckedInDtTm], [CheckedOutDtTm]
                      , [EncounterID])
     VALUES (8791,  '1821', 2,  9, '9/15/2008', '9/15/2008', 'OV-LAB-CXR / Cancer Antigen 27-29, CBC w/ Differential, CEA, Comprehensive Metabolic Panel, LDH, Uri', 'PATIENT 8', 1, '9/15/2008', '9/15/2008', NULL)
INSERT INTO ptSchedule ([ScheduleId], [MRN], [ApptTypeID], [ResourceId], [StartDtTm], [EndDtTm]
                      , [Description], [Notes], [Status], [CheckedInDtTm], [CheckedOutDtTm]
                      , [EncounterID])
     VALUES (8792,  '1821', 2,  21, '9/15/2008', '9/15/2008', 'OV-LAB-CXR / Cancer Antigen 27-29, CBC w/ Differential, CEA, Comprehensive Metabolic Panel, LDH, Uri', 'PATIENT 8', 1, '9/15/2008', '9/15/2008', NULL)
INSERT INTO ptSchedule ([ScheduleId], [MRN], [ApptTypeID], [ResourceId], [StartDtTm], [EndDtTm]
                      , [Description], [Notes], [Status], [CheckedInDtTm], [CheckedOutDtTm]
                      , [EncounterID])
     VALUES (65126, '1821', 2,  10, '9/15/2008', '9/15/2008', 'ESTABLISHED PATIENT', 'PATIENT 8', 1, '9/15/2008', '9/15/2008', NULL)
INSERT INTO ptSchedule ([ScheduleId], [MRN], [ApptTypeID], [ResourceId], [StartDtTm], [EndDtTm]
                      , [Description], [Notes], [Status], [CheckedInDtTm], [CheckedOutDtTm]
                      , [EncounterID])
     VALUES (8982,  '1960', 2,  9, '9/15/2008', '9/15/2008', 'OV-LAB / Cancer Antigen 27-29, CBC w/ Differential, CEA, Comprehensive Metabolic Panel, LDH, Uric Ac', 'PATIENT 9', 1, '9/15/2008', '9/15/2008', NULL)
INSERT INTO ptSchedule ([ScheduleId], [MRN], [ApptTypeID], [ResourceId], [StartDtTm], [EndDtTm]
                      , [Description], [Notes], [Status], [CheckedInDtTm], [CheckedOutDtTm]
                      , [EncounterID])
     VALUES (67025, '1960', 2,  7, '9/15/2008', '9/15/2008', 'ESTABLISHED PATIENT', 'PATIENT 9', 1, '9/15/2008', '9/15/2008', NULL)
INSERT INTO ptSchedule ([ScheduleId], [MRN], [ApptTypeID], [ResourceId], [StartDtTm], [EndDtTm]
                      , [Description], [Notes], [Status], [CheckedInDtTm], [CheckedOutDtTm]
                      , [EncounterID])
     VALUES (71917, '2466', 14, 9, '9/15/2008', '9/15/2008', 'SHORT APPT.', 'PATIENT 10', 1, '9/15/2008', '9/15/2008', NULL)
INSERT INTO ptSchedule ([ScheduleId], [MRN], [ApptTypeID], [ResourceId], [StartDtTm], [EndDtTm]
                      , [Description], [Notes], [Status], [CheckedInDtTm], [CheckedOutDtTm]
                      , [EncounterID])
     VALUES (10462, '3319', 2,  9, '9/15/2008', '9/15/2008', 'OV-LAB / CBC w/ Differential, Comprehensive Metabolic Panel, ESR (Sedimentation Rate), LDH, Uric Aci', 'PATIENT 11', 1, '9/15/2008', '9/15/2008', NULL)
INSERT INTO ptSchedule ([ScheduleId], [MRN], [ApptTypeID], [ResourceId], [StartDtTm], [EndDtTm]
                      , [Description], [Notes], [Status], [CheckedInDtTm], [CheckedOutDtTm]
                      , [EncounterID])
     VALUES (82886, '3319', 2,  10, '9/15/2008', '9/15/2008', 'ESTABLISHED PATIENT', 'PATIENT 11', 1, '9/15/2008', '9/15/2008', NULL)
INSERT INTO ptSchedule ([ScheduleId], [MRN], [ApptTypeID], [ResourceId], [StartDtTm], [EndDtTm]
                      , [Description], [Notes], [Status], [CheckedInDtTm], [CheckedOutDtTm]
                      , [EncounterID])
     VALUES (11595, '3775', 2,  21, '9/15/2008', '9/15/2008', 'OV-WELL WOMAN CHECK-CXR / LAB RSLTS / 1 YEAR / 9472', 'PATIENT 12', 1, '9/15/2008', '9/15/2008', NULL)
INSERT INTO ptSchedule ([ScheduleId], [MRN], [ApptTypeID], [ResourceId], [StartDtTm], [EndDtTm]
                      , [Description], [Notes], [Status], [CheckedInDtTm], [CheckedOutDtTm]
                      , [EncounterID])
     VALUES (93194, '3775', 2,  10, '9/15/2008', '9/15/2008', 'ESTABLISHED PATIENT', 'PATIENT 12', 1, '9/15/2008', '9/15/2008', NULL)
INSERT INTO ptSchedule ([ScheduleId], [MRN], [ApptTypeID], [ResourceId], [StartDtTm], [EndDtTm]
                      , [Description], [Notes], [Status], [CheckedInDtTm], [CheckedOutDtTm]
                      , [EncounterID])
     VALUES (11677, '3864', 2,  9, '9/15/2008', '9/15/2008', 'OV-LAB / CBC w/ Differential, Comprehensive Metabolic Panel, LDH, Uric Acid / 6 MONTHS / 9472', 'PATIENT 13', 1, '9/15/2008', '9/15/2008', NULL)
INSERT INTO ptSchedule ([ScheduleId], [MRN], [ApptTypeID], [ResourceId], [StartDtTm], [EndDtTm]
                      , [Description], [Notes], [Status], [CheckedInDtTm], [CheckedOutDtTm]
                      , [EncounterID])
     VALUES (93809, '3864', 2,  10, '9/15/2008', '9/15/2008', 'ESTABLISHED PATIENT', 'PATIENT 13', 1, '9/15/2008', '9/15/2008', NULL)
INSERT INTO ptSchedule ([ScheduleId], [MRN], [ApptTypeID], [ResourceId], [StartDtTm], [EndDtTm]
                      , [Description], [Notes], [Status], [CheckedInDtTm], [CheckedOutDtTm]
                      , [EncounterID])
     VALUES (121522,'6429', 2,  7, '9/15/2008', '9/15/2008', 'ESTABLISHED PATIENT', 'PATIENT 14', 1, '9/15/2008', '9/15/2008', NULL)
INSERT INTO ptSchedule ([ScheduleId], [MRN], [ApptTypeID], [ResourceId], [StartDtTm], [EndDtTm]
                      , [Description], [Notes], [Status], [CheckedInDtTm], [CheckedOutDtTm]
                      , [EncounterID])
     VALUES (123074,'6556', 14, 9, '9/15/2008', '9/15/2008', 'SHORT APPT.', 'PATIENT 15', 1, '9/15/2008', '9/15/2008', NULL)
INSERT INTO ptSchedule ([ScheduleId], [MRN], [ApptTypeID], [ResourceId], [StartDtTm], [EndDtTm]
                      , [Description], [Notes], [Status], [CheckedInDtTm], [CheckedOutDtTm]
                      , [EncounterID])
     VALUES (14651, '6567', 2,  9, '9/15/2008', '9/15/2008', 'OV-LAB / Cancer Antigen 27-29, CBC w/ Differential, CEA, Comprehensive Metabolic Panel, LDH, Uric Ac', 'PATIENT 16', 1, '9/15/2008', '9/15/2008', NULL)
INSERT INTO ptSchedule ([ScheduleId], [MRN], [ApptTypeID], [ResourceId], [StartDtTm], [EndDtTm]
                      , [Description], [Notes], [Status], [CheckedInDtTm], [CheckedOutDtTm]
                      , [EncounterID])
     VALUES (122320,'6567', 2,  7, '9/15/2008', '9/15/2008', 'ESTABLISHED PATIENT', 'PATIENT 16', 1, '9/15/2008', '9/15/2008', NULL)
INSERT INTO ptSchedule ([ScheduleId], [MRN], [ApptTypeID], [ResourceId], [StartDtTm], [EndDtTm]
                      , [Description], [Notes], [Status], [CheckedInDtTm], [CheckedOutDtTm]
                      , [EncounterID])
     VALUES (150468,'8810', 14, 9, '9/15/2008', '9/15/2008', 'SHORT APPT.', 'PATIENT 17', 1, '9/15/2008', '9/15/2008', NULL)
INSERT INTO ptSchedule ([ScheduleId], [MRN], [ApptTypeID], [ResourceId], [StartDtTm], [EndDtTm]
                      , [Description], [Notes], [Status], [CheckedInDtTm], [CheckedOutDtTm]
                      , [EncounterID])
     VALUES (31256, '10046', 2, 7, '9/15/2008', '9/15/2008', 'ESTABLISHED PATIENT', 'PATIENT 18', 1, '9/15/2008', '9/15/2008', NULL)
INSERT INTO ptSchedule ([ScheduleId], [MRN], [ApptTypeID], [ResourceId], [StartDtTm], [EndDtTm]
                      , [Description], [Notes], [Status], [CheckedInDtTm], [CheckedOutDtTm]
                      , [EncounterID])
     VALUES (30807, '10121', 2, 7, '9/15/2008', '9/15/2008', 'ESTABLISHED PATIENT', 'PATIENT 19', 1, '9/15/2008', '9/15/2008', NULL)
INSERT INTO ptSchedule ([ScheduleId], [MRN], [ApptTypeID], [ResourceId], [StartDtTm], [EndDtTm]
                      , [Description], [Notes], [Status], [CheckedInDtTm], [CheckedOutDtTm]
                      , [EncounterID])
     VALUES (34935, '10554', 2, 19, '9/15/2008', '9/15/2008', 'ESTABLISHED PATIENT', 'PATIENT 20', 1, '9/15/2008', '9/15/2008', NULL)
INSERT INTO ptSchedule ([ScheduleId], [MRN], [ApptTypeID], [ResourceId], [StartDtTm], [EndDtTm]
                      , [Description], [Notes], [Status], [CheckedInDtTm], [CheckedOutDtTm]
                      , [EncounterID])
     VALUES (49600, '12987', 2, 19, '9/15/2008', '9/15/2008', 'ESTABLISHED PATIENT', 'PATIENT 21', 1, '9/15/2008', '9/15/2008', NULL)
INSERT INTO ptSchedule ([ScheduleId], [MRN], [ApptTypeID], [ResourceId], [StartDtTm], [EndDtTm]
                      , [Description], [Notes], [Status], [CheckedInDtTm], [CheckedOutDtTm]
                      , [EncounterID])
     VALUES (51822, '13473', 2, 19, '9/15/2008', '9/15/2008', 'ESTABLISHED PATIENT', 'PATIENT 22', 1, '9/15/2008', '9/15/2008', NULL)
INSERT INTO ptSchedule ([ScheduleId], [MRN], [ApptTypeID], [ResourceId], [StartDtTm], [EndDtTm]
                      , [Description], [Notes], [Status], [CheckedInDtTm], [CheckedOutDtTm]
                      , [EncounterID])
     VALUES (54641, '14204', 2, 10, '9/15/2008', '9/15/2008', 'ESTABLISHED PATIENT', 'PATIENT 23', 1, '9/15/2008', '9/15/2008', NULL)
INSERT INTO ptSchedule ([ScheduleId], [MRN], [ApptTypeID], [ResourceId], [StartDtTm], [EndDtTm]
                      , [Description], [Notes], [Status], [CheckedInDtTm], [CheckedOutDtTm]
                      , [EncounterID])
     VALUES (58760, '14942', 14, 9, '9/15/2008', '9/15/2008', 'SHORT APPT.', 'PATIENT 24', 1, '9/15/2008', '9/15/2008', NULL)
INSERT INTO ptSchedule ([ScheduleId], [MRN], [ApptTypeID], [ResourceId], [StartDtTm], [EndDtTm]
                      , [Description], [Notes], [Status], [CheckedInDtTm], [CheckedOutDtTm]
                      , [EncounterID])
     VALUES (25009, '14942', 5, 8, '9/15/2008', '9/15/2008', 'LAB-INJ / CBC w/ Differential / 4314', 'PATIENT 24', 1, '9/15/2008', '9/15/2008', NULL)
INSERT INTO ptSchedule ([ScheduleId], [MRN], [ApptTypeID], [ResourceId], [StartDtTm], [EndDtTm]
                      , [Description], [Notes], [Status], [CheckedInDtTm], [CheckedOutDtTm]
                      , [EncounterID])
     VALUES (60391, '15332', 2, 7, '9/15/2008', '9/15/2008', 'ESTABLISHED PATIENT', 'PATIENT 25', 1, '9/15/2008', '9/15/2008', NULL)
INSERT INTO ptSchedule ([ScheduleId], [MRN], [ApptTypeID], [ResourceId], [StartDtTm], [EndDtTm]
                      , [Description], [Notes], [Status], [CheckedInDtTm], [CheckedOutDtTm]
                      , [EncounterID])
     VALUES (8187,  '15385', 2, 21, '9/15/2008', '9/15/2008', 'OV-CXR / LAB RSLTS / 3 MONTHS / 4314', 'PATIENT 26', 1, '9/15/2008', '9/15/2008', NULL)
INSERT INTO ptSchedule ([ScheduleId], [MRN], [ApptTypeID], [ResourceId], [StartDtTm], [EndDtTm]
                      , [Description], [Notes], [Status], [CheckedInDtTm], [CheckedOutDtTm]
                      , [EncounterID])
     VALUES (60990, '15385', 2, 7, '9/15/2008', '9/15/2008', 'ESTABLISHED PATIENT', 'PATIENT 26', 1, '9/15/2008', '9/15/2008', NULL)
INSERT INTO ptSchedule ([ScheduleId], [MRN], [ApptTypeID], [ResourceId], [StartDtTm], [EndDtTm]
                      , [Description], [Notes], [Status], [CheckedInDtTm], [CheckedOutDtTm]
                      , [EncounterID])
     VALUES (8301,  '15475', 2, 9, '9/15/2008', '9/15/2008', 'OV-LAB / CBC w/ Differential, Comprehensive Metabolic Panel, Ferritin, LDH, Reticulocyte Count, Uric', 'PATIENT 27', 1, '9/15/2008', '9/15/2008', NULL)
INSERT INTO ptSchedule ([ScheduleId], [MRN], [ApptTypeID], [ResourceId], [StartDtTm], [EndDtTm]
                      , [Description], [Notes], [Status], [CheckedInDtTm], [CheckedOutDtTm]
                      , [EncounterID])
     VALUES (61350, '15475', 2, 7, '9/15/2008', '9/15/2008', 'ESTABLISHED PATIENT', 'PATIENT 27', 1, '9/15/2008', '9/15/2008', NULL)
INSERT INTO ptSchedule ([ScheduleId], [MRN], [ApptTypeID], [ResourceId], [StartDtTm], [EndDtTm]
                      , [Description], [Notes], [Status], [CheckedInDtTm], [CheckedOutDtTm]
                      , [EncounterID])
     VALUES (8686,  '16193', 2, 9, '9/15/2008', '9/15/2008', 'OV-LAB / Cancer Antigen 27-29, CBC w/ Differential, CEA, Comprehensive Metabolic Panel, LDH, Uric Ac', 'PATIENT 28', 1, '9/15/2008', '9/15/2008', NULL)
INSERT INTO ptSchedule ([ScheduleId], [MRN], [ApptTypeID], [ResourceId], [StartDtTm], [EndDtTm]
                      , [Description], [Notes], [Status], [CheckedInDtTm], [CheckedOutDtTm]
                      , [EncounterID])
     VALUES (64489, '16193', 2, 7, '9/15/2008', '9/15/2008', 'ESTABLISHED PATIENT', 'PATIENT 28', 1, '9/15/2008', '9/15/2008', NULL)
GO
SET IDENTITY_INSERT [dbo].[ptSchedule] OFF
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ptEncounter]') AND type in (N'U'))
  DROP TABLE [dbo].[ptEncounter]
GO
CREATE TABLE [dbo].[ptEncounter](
        [EncounterID] [int] IDENTITY(1,1) NOT NULL,
        [BillNumber] [int] NOT NULL,
        [ClaimNumber] [nvarchar](20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
        [MRN] [varchar](25) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
        [DateOfService] [datetime] NULL,
 CONSTRAINT [PK_ptEncounter] PRIMARY KEY CLUSTERED 
(
        [EncounterID] ASC
)WITH (IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]

SET IDENTITY_INSERT [dbo].[ptEncounter] ON
GO

INSERT INTO ptEncounter ([EncounterID], [BillNumber], [ClaimNumber], [MRN], [DateOfService])
     VALUES (145116, 146202, 146202, 10046, '9/15/2008')
INSERT INTO ptEncounter ([EncounterID], [BillNumber], [ClaimNumber], [MRN], [DateOfService])
     VALUES (145098, 146184, 146184, 10121, '9/15/2008')
INSERT INTO ptEncounter ([EncounterID], [BillNumber], [ClaimNumber], [MRN], [DateOfService])
     VALUES (145142, 146231, 146231, 1112, '9/15/2008')
INSERT INTO ptEncounter ([EncounterID], [BillNumber], [ClaimNumber], [MRN], [DateOfService])
     VALUES (145103, 146189, 146189, 12987, '9/15/2008')
INSERT INTO ptEncounter ([EncounterID], [BillNumber], [ClaimNumber], [MRN], [DateOfService])
     VALUES (145072, 146158, 146158, 14204, '9/15/2008')
INSERT INTO ptEncounter ([EncounterID], [BillNumber], [ClaimNumber], [MRN], [DateOfService])
     VALUES (145091, 146177, 146177, 1461, '9/15/2008')
INSERT INTO ptEncounter ([EncounterID], [BillNumber], [ClaimNumber], [MRN], [DateOfService])
     VALUES (145090, 146176, 146176, 15332, '9/15/2008')
INSERT INTO ptEncounter ([EncounterID], [BillNumber], [ClaimNumber], [MRN], [DateOfService])
     VALUES (145106, 146192, 146192, 15385, '9/15/2008')
INSERT INTO ptEncounter ([EncounterID], [BillNumber], [ClaimNumber], [MRN], [DateOfService])
     VALUES (145083, 146169, 146169, 15475, '9/15/2008')
INSERT INTO ptEncounter ([EncounterID], [BillNumber], [ClaimNumber], [MRN], [DateOfService])
     VALUES (145124, 146210, 146210, 16193, '9/15/2008')
INSERT INTO ptEncounter ([EncounterID], [BillNumber], [ClaimNumber], [MRN], [DateOfService])
     VALUES (145110, 146196, 146196, 168, '9/15/2008')
INSERT INTO ptEncounter ([EncounterID], [BillNumber], [ClaimNumber], [MRN], [DateOfService])
     VALUES (145122, 146208, 146208, 1821, '9/15/2008')
INSERT INTO ptEncounter ([EncounterID], [BillNumber], [ClaimNumber], [MRN], [DateOfService])
     VALUES (145130, 146218, 146218, 1960, '9/15/2008')
INSERT INTO ptEncounter ([EncounterID], [BillNumber], [ClaimNumber], [MRN], [DateOfService])
     VALUES (145089, 146175, 146175, 265, '9/15/2008')
INSERT INTO ptEncounter ([EncounterID], [BillNumber], [ClaimNumber], [MRN], [DateOfService])
     VALUES (145114, 146200, 146200, 51, '9/15/2008')
INSERT INTO ptEncounter ([EncounterID], [BillNumber], [ClaimNumber], [MRN], [DateOfService])
     VALUES (145084, 146170, 146170, 6429, '9/15/2008')
INSERT INTO ptEncounter ([EncounterID], [BillNumber], [ClaimNumber], [MRN], [DateOfService])
     VALUES (145073, 146159, 146159, 797, '9/15/2008')
GO
SET IDENTITY_INSERT [dbo].[ptEncounter] OFF
GO

-- ============================================================================
-- Functions to get PrimaryInsuranceCarrierID and SecondaryInsuranceCarrierID
-- ============================================================================
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetPrimaryInsuranceCarrierID]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
  DROP FUNCTION [dbo].[GetPrimaryInsuranceCarrierID]
GO
CREATE FUNCTION [dbo].[GetPrimaryInsuranceCarrierID](@MRN as varchar(25), @CheckDate as datetime)
RETURNS int
AS
BEGIN
  RETURN (SELECT Top 1 CarrierID
  FROM ptInsurancePlans 
  WHERE MRN = @MRN
  AND InsuranceLevel = 1 
  AND Sequence = 1
  AND EffectIveDtTm <= @CheckDate 
  AND ExpirationDtTm >= @CheckDate)
END
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetSecondaryInsuranceCarrierID]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
  DROP FUNCTION [dbo].[GetSecondaryInsuranceCarrierID]
GO
CREATE FUNCTION [dbo].[GetSecondaryInsuranceCarrierID](@MRN as varchar(25), @CheckDate as datetime)
RETURNS int
AS
BEGIN
  DECLARE @Carrier Int
  SET @Carrier = (SELECT TOP 1 CarrierID
  FROM ptInsurancePlans 
  WHERE MRN = @MRN
  AND InsuranceLevel = 2 
  AND Sequence = 2
  AND EffectiveDtTm <= @CheckDate 
  AND ExpirationDtTm >= @CheckDate)
RETURN @Carrier
END
GO

-- ============================================================================
-- Function to get the Patient's Age by passed MRN
-- ============================================================================
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[rr_GetAge_byMRN]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
  DROP FUNCTION [dbo].[rr_GetAge_byMRN]
GO
CREATE FUNCTION [dbo].[rr_GetAge_byMRN] (@MRN varchar(25)), @Today Datetime) RETURNS int
AS
BEGIN
  DECLARE @Age As int
  DECLARE @DOB as datetime
  SELECT @DOB = DateofBirth FROM ptDemographics WHERE MRN=@MRN
  SET @Age = 0
  IF @DOB IS NOT NULL
  BEGIN
    SET @Age = Year(@Today) - Year(@DOB)
    IF Month(@Today) < Month(@DOB)
      SET @Age = @Age -1
    IF Month(@Today) = Month(@DOB) AND Day(@Today) < Day(@DOB)
      SET @Age = @Age - 1
  END
  RETURN @AGE
END
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[rr_Collect_EncounterReport]') AND type in (N'P', N'PC'))
  DROP PROCEDURE [dbo].[rr_Collect_EncounterReport]
GO
-- ============================================================================
-- Author: By someone else, thats for sure!!!
-- Create Date: Not sure when, either!
-- Description:  Retrieves Encounter Reports
-- ============================================================================
CREATE PROCEDURE [dbo].[rr_Collect_EncounterReport]
 @StartDtTm as datetime
AS
BEGIN
  SELECT Distinct 
         ptSchedule.MRN, ptSchedule.StartDtTm, ptSchedule.Description, d.LName + ', ' + d.FName AS PatientName,  
         dbo.rr_GetAge_byMRN(d.MRN, GETDATE()) AS Age, d.DateOfBirth, d.Gender, d.Physician,  
         ptContacts.LName + ', ' + ptContacts.FName AS GuarantorName, ptContacts.Address1 AS GuarantorAddress, ptContacts.City AS GuarantorCity,  
         ptContacts.State AS GuarantorState, ptContacts.Zip AS GuarantorZip, coInsCarriers.CarrierCode AS PrimaryIns,  
         coInsCarriers.CarrierName AS PrimaryInsPlanName, ptInsurancePlans.SubscriberID AS PrimaryInsSubscriberID,  
         ptInsurancePlans.Copay AS PrimaryInsCopay, coInsCarriers_1.CarrierCode AS SecondaryIns, coInsCarriers_1.CarrierName AS SecondaryInsPlanName,  
         ptInsurancePlans_1.SubscriberID AS SecondaryInsSubscriberID, ptInsurancePlans_1.Copay AS SecondaryInsCopay  
         FROM ptSchedule INNER JOIN ptDemographics AS d ON ptSchedule.MRN = d.MRN LEFT OUTER JOIN coInsCarriers RIGHT OUTER JOIN  
         (SELECT * FROM ptInsurancePlans WHERE InsuranceLevel = 1 AND Sequence = 1) as ptInsurancePlans ON coInsCarriers.CarrierID = ptInsurancePlans.CarrierID LEFT OUTER JOIN  
         ptContacts ON ptInsurancePlans.SubscriberContactID = ptContacts.ContactID ON d.MRN = ptContacts.MRN LEFT OUTER JOIN  
         coInsCarriers AS coInsCarriers_1 RIGHT OUTER JOIN  
         (SELECT * FROM ptInsurancePlans WHERE InsuranceLevel = 2 AND Sequence = 2) AS ptInsurancePlans_1 ON coInsCarriers_1.CarrierID = ptInsurancePlans_1.CarrierID LEFT OUTER JOIN  
         ptContacts AS ptContacts_1 ON ptInsurancePlans_1.SubscriberContactID = ptContacts_1.ContactID ON  
         d.MRN = ptInsurancePlans_1.MRN WHERE (CONVERT(VARCHAR, ptSchedule.StartDtTm,101) = @StartDtTm)
END
GO
-- ============================================================================
-- rr_Collect_EncounterReport2
-- Procedure to collect Encounter records for Encounter Report
-- ============================================================================
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[rr_Collect_EncounterReport2]') AND type in (N'P', N'PC'))
  DROP PROCEDURE [dbo].[rr_Collect_EncounterReport2]
GO

-- ============================================================================
--Code to run the SP: 
-- ============================================================================
exec rr_Collect_EncounterReport '09/15/2008'


IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[rr_Collect_EncounterReport2]') AND type in (N'P', N'PC'))
EXEC sp_executesql N'-- ============================================================================
-- Author: David Schulz
-- Create Date: 07/11/2008 1:22:34 PM
-- Description:  Retrives Encounter Reports
-- ============================================================================
-- Modified: Eddie Shipman 10/24/2008
-- Added Encounter BillNumber to the result set.
-- ============================================================================

CREATE PROCEDURE [dbo].[rr_Collect_EncounterReport2]
 @StartDtTm as datetime
AS
BEGIN
  WITH MyContacts (LName, FName, Address1, City, State, Zip, MRN, ContactID) 
  AS (SELECT TOP 1 c.LName, c.FName, c.Address1, c.City, c.State, c.Zip, c.MRN, c.ContactID
      FROM ptContacts c
      INNER JOIN ptInsurancePlans ip
      ON c.MRN = ip.SubscriberContactID
      WHERE ip.MRN = c.MRN
      AND   ip.CarrierID = (SELECT dbo.GetPrimaryInsuranceCarrierID(c.MRN, @StartDtTm)))
      
  SELECT DISTINCT 
         ptSchedule.MRN, 
         ptSchedule.StartDtTm, 
         ptSchedule.Description, 
         d.LName + '', '' + d.FName AS PatientName,  
         dbo.rr_GetAge_byMRN(d.MRN, GETDATE()) AS Age, 
         d.DateOfBirth, 
         d.Gender, 
         d.Physician,  
         ptContacts.LName + '', '' + ptContacts.FName AS GuarantorName, 
         ptContacts.Address1 AS GuarantorAddress, 
         ptContacts.City AS GuarantorCity,  
         ptContacts.State AS GuarantorState, 
         ptContacts.Zip AS GuarantorZip, 
         (SELECT CarrierCode FROM coInsCarriers WHERE CarrierID = dbo.GetPrimaryInsuranceCarrierID(ptSchedule.MRN, @StartDtTm)) AS PrimaryIns,  
         (SELECT CarrierName FROM coInsCarriers WHERE CarrierID = dbo.GetPrimaryInsuranceCarrierID(ptSchedule.MRN, @StartDtTm)) AS PrimaryInsPlanName, 
         (SELECT SubscriberID FROM ptInsurancePlans WHERE MRN = ptSchedule.MRN AND CarrierID = dbo.GetPrimaryInsuranceCarrierID(ptSchedule.MRN, @StartDtTm)) AS PrimaryInsSubscriberID,  
         (SELECT CoPay FROM ptInsurancePlans WHERE MRN = ptSchedule.MRN AND CarrierID = dbo.GetPrimaryInsuranceCarrierID(ptSchedule.MRN, @StartDtTm)) AS PrimaryInsCopay, 
         (SELECT CarrierCode FROM coInsCarriers WHERE CarrierID = dbo.GetSecondaryInsuranceCarrierID(ptSchedule.MRN, @StartDtTm)) AS SecondaryIns,
         (SELECT CarrierName FROM coInsCarriers WHERE CarrierID = dbo.GetSecondaryInsuranceCarrierID(ptSchedule.MRN, @StartDtTm)) AS SecondaryInsPlanName,  
         (SELECT SubscriberID FROM ptInsurancePlans WHERE MRN = ptSchedule.MRN AND CarrierID = dbo.GetSecondaryInsuranceCarrierID(ptSchedule.MRN, @StartDtTm)) AS SecondaryInsSubscriberID,
         (SELECT CoPay FROM ptInsurancePlans WHERE MRN = ptSchedule.MRN AND CarrierID = dbo.GetSecondaryInsuranceCarrierID(ptSchedule.MRN, @StartDtTm)) AS SecondaryInsCopay,
         ptEncounter.BillNumber
  FROM ptSchedule 
  INNER JOIN ptDemographics AS d 
    ON d.MRN = ptSchedule.MRN
  INNER JOIN ptEncounter 
    ON ptEncounter.MRN = ptSchedule.MRN 
  LEFT OUTER JOIN MyContacts ptContacts
    ON ptContacts.MRN = d.MRN
  WHERE (CONVERT(VARCHAR, ptSchedule.StartDtTm,101) = @StartDtTm) 
  AND   CONVERT(varchar,ptEncounter.DateofService, 10) = CONVERT(varchar,ptSchedule.StartDtTm, 10)
END'
GO

-- ============================================================================
--Code to run the SP: 
-- ============================================================================
exec rr_Collect_EncounterReport2 '09/15/2008'