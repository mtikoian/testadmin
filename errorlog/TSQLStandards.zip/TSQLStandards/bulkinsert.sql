--===== Conditionally drop temp tables to make reruns in SSMS easier
     IF OBJECT_ID('TempDB..#RawData'  ,'U') IS NOT NULL DROP TABLE #RawData;
     IF OBJECT_ID('TempDB..#SplitData','U') IS NOT NULL DROP TABLE #SplitData;

--===== Explicitly create the raw data table for the BULK INSERT
 CREATE TABLE #RawData
        (
         RowNum INT IDENTITY(1,1) PRIMARY KEY CLUSTERED,
         Data   VARCHAR(8000)
        )
;
--===== Do the import into just the data column as controlled by the format file.
   BULK INSERT #RawData
   FROM 'C:\Temp\SomeFile.txt' 
   WITH (
        BATCHSIZE       = 100000,
        CODEPAGE        = 'RAW',
        DATAFILETYPE    = 'char',
        FORMATFILE      = 'D:\Util\Generic09_PipeCrLf.txt',
        TABLOCK 
        )
;
--===== Split the data and load it into a working table
 SELECT rd.RowNum, split.ItemNumber, split.Item
   INTO #SplitData
   FROM #RawData rd
  CROSS APPLY dbo.DelimitedSplit8K(Data,'|') split
;
--===== Get the desired common data from the header and remember it
DECLARE @ExtractDate  DATETIME,
        @SourceSystem VARCHAR(128)
;
 SELECT @ExtractDate  = MAX(CASE WHEN ItemNumber = 2 THEN Item ELSE '1900' END),
        @SourceSystem = MAX(CASE WHEN ItemNumber = 3 THEN Item ELSE ''     END)
   FROM #SplitData
  WHERE RowNum = 1
;
--===== Recombine the "ragged" data using a traditional high speed cross tab.
 SELECT CostCentreID            = MAX(CASE WHEN ItemNumber = 2 THEN Item ELSE 0  END),
        CostCentreName          = MAX(CASE WHEN ItemNumber = 3 THEN Item ELSE '' END),
        CostCentreDescription   = MAX(CASE WHEN ItemNumber = 4 THEN Item ELSE '' END),
        SourceSystem            = @SourceSystem,
        ExtractDate             = @ExtractDate
   FROM #SplitData
  WHERE RowNum > 2
  GROUP BY RowNum
 HAVING MAX(CASE WHEN ItemNumber = 1 THEN Item ELSE '' END) = 'D'
;



--9.0
--2
--1 SQLCHAR 0 0    ""      0 RowNum ""
--2 SQLCHAR 0 8001 "|\r\n" 2 Data   SQL_Latin1_General_CP1_CI_AS
----------------------------------------------------------------
--This is a BCP format file that allows a text file to be
--handled as if it were a single column and allows input to a
--table with the following structure because the RowNum column
--is skipped because of the "0" column number in the format
--above.

--There are 3 characters (|CrLf) at the end of each line.

--The 8001 will cause an input to a VARCHAR(8000) to fail if the
--line is actually too long.

-- CREATE TABLE #RawData
--        (
--         RowNum INT IDENTITY(1,1),
--         Data   VARCHAR(8000)
--        )
--;
--Jeff Moden


DECLARE @SQL nvarchar(max);
DECLARE @FromDate DATETIME;
DECLARE @ToDate DATETIME;
DECLARE @PathFileName varchar(2000)

SET @FromDate = CAST('20080101' AS DATETIME);
SET @ToDate = GETDATE();
SET @PathFileName = 'D:\SalesHis\SALES.'+CONVERT(CHAR(8),@FromDate,112)+'%''.txt'

IF @ToDate > @FromDate
BEGIN
                SELECT @SQL = 'BULK INSERT [SalesHis].[DBO].[Sales] FROM '+@PathFileName+'
                WITH (FIELDTERMINATOR = '''', ROWTERMINATOR = ''' + nchar(10) + ''')';
                EXEC (@SQL);
                SET @FromDate = DATEADD(dd,1,@FromDate)
END