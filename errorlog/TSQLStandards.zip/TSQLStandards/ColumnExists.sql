CREATE PROCEDURE dbo.ColumnExists (
	@DBName NVARCHAR(256)
	,@SchemaName NVARCHAR(256)
	,@TableName NVARCHAR(256)
	,@ColumnName NVARCHAR(256)
	)
AS
DECLARE @SQLCmd NVARCHAR(MAX)
	,@ExecSQLCmd NVARCHAR(MAX)
	,@SQLParm NVARCHAR(MAX)
	,@Result VARCHAR(30);

SET @SQLParm = N'@inTableName nvarchar(256), @inSchemaName nvarchar(256), @inColumnName nvarchar(256), @outResult varchar(30) output';
SET @SQLCmd = N'
SELECT @outResult = ''Valid Object''
FROM
 [@DBName@].[dbo].[sysobjects] AS [so]
 INNER JOIN [@DBName@].[dbo].[syscolumns] AS sc
  ON [sc].[id] = [so].[id]
WHERE
 [so].[name] = @inTableName
 AND [sc].[name] = @inColumnName
 AND [so].[uid] = SCHEMA_ID(@inSchemaName)
 AND [so].[xtype] = ''U'';
';
SET @ExecSQLCmd = REPLACE(@SQLCmd, '@DBName@', @DBName);

EXEC sp_executesql @ExecSQLCmd
	,@SQLParm
	,@inTableName = @TableName
	,@inSchemaName = @SchemaName
	,@inColumnName = @ColumnName
	,@outResult = @Result OUTPUT;

SELECT ISNULL(@Result, 'Invalid Object');
GO

EXEC [dbo].[ColumnExists] @DBName = N'black'
	,@SchemaName = N'dbo'
	,@TableName = N'company'
	,@ColumnName = N'columnname';

EXEC [dbo].[ColumnExists] @DBName = N'DBAUtilities'
	,@SchemaName = N'dbo'
	,@TableName = N'ColumnStandards'
	,@ColumnName = N'schemaname';
GO


