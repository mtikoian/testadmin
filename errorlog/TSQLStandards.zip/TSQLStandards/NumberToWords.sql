ALTER FUNCTION dbo.NumberToWords(@TheNumber DECIMAL (15,2), @CurrencyName VARCHAR(20), @JoinWord VARCHAR(20), @CentsName VARCHAR(20))
RETURNS VARCHAR(200)
-- USAGE: SELECT dbo.ToWords(1.01, 'dollar(s)', 'and', 'cent(s)') 
-- MAX. VALUE: 999999999999.99 (twelve nines before the decimal point)
BEGIN

DECLARE @numberstr CHAR (15), @NewString VARCHAR(200)
SET @numberstr = STR(@TheNumber, 15, 2)
SET @NewString = ''

DECLARE @tblNum TABLE(Num BIGint, MaxNum BIGint, NumStr VARCHAR(20))
INSERT INTO @tblNum
SELECT 1, 1, 'one' UNION       SELECT 2, 2, 'two' UNION
SELECT 3, 3, 'three' UNION     SELECT 4, 4, 'four' UNION
SELECT 5, 5, 'five' UNION      SELECT 6, 6, 'six' UNION
SELECT 7, 7, 'seven' UNION     SELECT 8, 8, 'eight' UNION
SELECT 9, 9, 'nine' UNION      SELECT 10, 10, 'ten' UNION
SELECT 11, 11, 'eleven' UNION      SELECT 12, 12, 'twelve' UNION
SELECT 13, 13, 'thirteen' UNION        SELECT 14, 14, 'fourteen' UNION
SELECT 15, 15, 'fifteen' UNION     SELECT 16, 16, 'sixteen' UNION
SELECT 17, 17, 'seventeen' UNION   SELECT 18, 18, 'eighteen' UNION
SELECT 19, 19, 'nineteen' UNION        SELECT 20, 29, 'twenty' UNION 
SELECT 30, 39, 'thirty' UNION      SELECT 40, 49, 'forty' UNION 
SELECT 50, 59, 'fifty' UNION       SELECT 60, 69, 'sixty' UNION 
SELECT 70, 79, 'seventy' UNION     SELECT 80, 89, 'eighty' UNION 
SELECT 90, 99, 'ninety' UNION      SELECT 100, 999, 'hundred' UNION
SELECT 1000, 999999, 'thousand' UNION  SELECT 1000000, 999999999, 'million' UNION
SELECT 1000000000, 999999999999, 'billion' 

SELECT @NewString = @NewString
   + CASE WHEN h.NumStr IS NULL THEN '' ELSE h.NumStr + ' ' + c.NumStr + ' ' END
   + CASE WHEN number < 15 AND h.NumStr IS NOT NULL AND (t.NumStr IS NOT NULL OR u.NumStr IS NOT NULL) THEN @JoinWord + ' ' ELSE '' END
   + CASE WHEN number < 15 AND t.NumStr IS NOT NULL THEN t.NumStr + ' ' ELSE '' END
   + CASE WHEN number < 15 AND u.NumStr IS NOT NULL THEN u.NumStr + ' ' ELSE '' END
   + CASE WHEN number = 12 THEN @CurrencyName + ' ' ELSE '' END
   + CASE WHEN number = 15 AND (t.NumStr IS NOT NULL OR u.NumStr IS NOT NULL) THEN @JoinWord + ' ' ELSE '' END
   + CASE WHEN number = 15 AND t.NumStr IS NOT NULL THEN t.NumStr + ' ' ELSE '' END
   + CASE WHEN number = 15 AND u.NumStr IS NOT NULL THEN u.NumStr + ' ' ELSE '' END
   + CASE WHEN number = 15 AND (t.NumStr IS NOT NULL OR u.NumStr IS NOT NULL) THEN @CentsName + ' ' ELSE '' END
   + CASE WHEN k.NumStr IS NULL THEN '' ELSE k.NumStr + ', ' END

FROM (SELECT 3 AS number UNION ALL SELECT 6 UNION ALL SELECT 9 UNION ALL SELECT 12 UNION ALL SELECT 15) n
LEFT JOIN @tblNum h ON number < 15 AND SUBSTRING(@numberstr, number-2, 1) BETWEEN h.Num AND h.MaxNum 
LEFT JOIN @tblNum t ON SUBSTRING(@numberstr, number-1, 2) BETWEEN t.Num AND t.MaxNum AND t.Num > 9   
LEFT JOIN @tblNum u ON SUBSTRING(@numberstr, number, 1) BETWEEN u.Num AND u.MaxNum AND NOT SUBSTRING(@numberstr, number-1, 2) BETWEEN 10 AND 19
LEFT JOIN @tblNum c ON number < 15 AND c.Num = 100 
LEFT JOIN @tblNum k ON number < 12 AND k.Num = POWER(10, 12-number) AND k.Num < @TheNumber

RETURN @NewString

END

GO

SELECT dbo.ToWords(number, 'dollar(s)', 'and', 'cent(s)') 
FROM Numbers 
WHERE number < 30000 
-- about a minute

SELECT dbo.ToWords(999999999999.99, 'dollar(s)', 'and', 'cent(s)')
-- nine hundred and ninety nine billion, nine hundred and ninety nine million, 
-- nine hundred and ninety nine thousand, nine hundred and ninety nine dollar(s) and ninety nine cent(s) 

SELECT dbo.ToWords(999999999999.99, 'pounds', 'and', 'pence')
-- nine hundred and ninety nine billion, nine hundred and ninety nine million, 
-- nine hundred and ninety nine thousand, nine hundred and ninety nine pounds and ninety nine pence 

