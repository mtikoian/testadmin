CREATE PROCEDURE [dbo].[get_crossdatabase_dependencies]
AS
SET NOCOUNT ON;

DECLARE @database_id INT
	,@database_name SYSNAME
	,@sql NVARCHAR(MAX)
	,@sqlparm NVARCHAR(MAX) = N'@db_id INT';

CREATE TABLE [#dependencies] (
	[referencing_database] NVARCHAR(256)
	,[referencing_schema] NVARCHAR(256)
	,[referencing_object_name] NVARCHAR(256)
	,[referenced_server] NVARCHAR(256)
	,[referenced_database] NVARCHAR(256)
	,[referenced_schema] NVARCHAR(256)
	,[referenced_object_name] NVARCHAR(256)
	);

DECLARE DBNames CURSOR LOCAL FORWARD_ONLY STATIC READ_ONLY
FOR
SELECT [name]
	,[database_id]
FROM [sys].[databases]
WHERE [state] <> 6 /* ignore offline DBs */
	AND [database_id] > 4;/* ignore system DBs */

OPEN [DBNames];

FETCH NEXT
FROM [DBNames]
INTO @database_name
	,@database_id;

WHILE @@FETCH_STATUS = 0
BEGIN
	SET @sql = N'INSERT INTO #dependencies select 
 DB_NAME(@db_id), 
 OBJECT_SCHEMA_NAME(referencing_id,@db_id), 
 OBJECT_NAME(referencing_id,@db_id), 
 referenced_server_name,
 ISNULL(referenced_database_name, db_name(@db_id)),
 referenced_schema_name,
 referenced_entity_name
FROM ' + QUOTENAME(@database_name) + '.sys.sql_expression_dependencies';

	EXEC [sys].[sp_executesql] @sql
		,@sqlparm
		,@db_id = @database_id;

	FETCH NEXT
	FROM [DBNames]
	INTO @database_name
		,@database_id;
END;

CLOSE [DBNames];

DEALLOCATE [DBNames];

SET NOCOUNT OFF;

SELECT *
FROM [#dependencies];
GO

-- End batch creating stored procedure
