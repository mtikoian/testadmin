SELECT *, dr = CASE WHEN Failure = 1 THEN DENSE_RANK() OVER(PARTITION BY IncidentID, Grp ORDER BY File_Date) ELSE 0 END
FROM (
SELECT *, Grp = rn1-rn2
FROM (
SELECT *, 
rn1 = ROW_NUMBER() OVER(PARTITION BY IncidentID, ScheduleTime ORDER BY File_Date ),
rn2 = ROW_NUMBER() OVER(PARTITION BY IncidentID, ScheduleTime, Failure ORDER BY File_Date) 
FROM #test t
CROSS APPLY (SELECT Failure = CASE WHEN ExecutedTime > '00:00:00.0000000' THEN 0 ELSE 1 END) x
) d1
) d2
ORDER BY File_Date, ScheduleTime

--https://www.sqlservercentral.com/Forums/1876350/Help-On-Calculating-Aging?PageIndex=3#bm1876835