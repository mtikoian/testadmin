CREATE FUNCTION dbo.fnLeaveOnly 
/***********************************************************************************
 Purpose: 
 This function accepts a string, the "LIKE" pattern that all characters must match 
 to be "kept", and a value to return if a NULL is the result of the function.

 -- Jeff Moden
***********************************************************************************/
--===== Define the I/O Parameters
        (
        @String      VARCHAR(8000), --String to be cleaned
        @CharPattern VARCHAR(100),  --Pattern a character must meet to keep
        @NullValue   VARCHAR(100)   --Return this if a NULL is the result
        )
RETURNS VARCHAR(8000)               --The "cleaned" string
     AS
  BEGIN
        --===== Declare the return variable
        DECLARE @Return VARCHAR(8000)

        --===== Clean the string leaving only what's in the character pattern
         SELECT @Return = ISNULL(@Return,'')+SUBSTRING(@String,N,1)
           FROM dbo.Tally
          WHERE N <= LEN(@String)
            AND SUBSTRING(@String,N,1) LIKE @CharPattern

--===== Return the "Cleaned" string substituting the null value if result is null
 RETURN ISNULL(@Return,@NullValue)
    END

	go


	--===== Create and populate the Tally table on the fly
 SELECT TOP 11000 --equates to more than 30 years of dates
        IDENTITY(INT,1,1) AS N
   INTO dbo.Tally
   FROM Master.dbo.SysColumns sc1,
        Master.dbo.SysColumns sc2

--===== Add a Primary Key to maximize performance
  ALTER TABLE dbo.Tally
    ADD CONSTRAINT PK_Tally_N 
        PRIMARY KEY CLUSTERED (N) WITH FILLFACTOR = 100

--===== Allow the general public to use it
  GRANT SELECT ON dbo.Tally TO PUBLIC

	DECLARE @yourtable TABLE (StarRating VARCHAR(100))
 INSERT INTO @yourtable (StarRating)
 SELECT '0'      UNION ALL
 SELECT '1'      UNION ALL
 SELECT '1.5'    UNION ALL
 SELECT 'NA'     UNION ALL
 SELECT '2'      UNION ALL
 SELECT '2 STAR' UNION ALL
 SELECT ' '      UNION ALL
 SELECT '3.00'   UNION ALL
 SELECT '4-STAR' UNION ALL
 SELECT '4'      UNION ALL
 SELECT NULL     UNION ALL
 SELECT '~`!@#$%^&*()-_=+\|[{]};:''", /?a1_b2C3$'

 SELECT StarRating AS Original,
        dbo.fnLeaveOnly(StarRating,'[0-9.]',0)
   FROM @yourtable

Result:
(12 row(s) affected)

Original                                  Cleaned    
----------------------------------------- ---------- 
0                                         0         
1                                         1         
1.5                                       1.5       
NA                                        0         
2                                         2         
2 STAR                                    2         
                                          0         
3.00                                      3.00      
4-STAR                                    4         
4                                         4         
NULL                                      0         
~`!@#$%^&*()-_=+\|[{]};:'", /?a1_b2C3$  .123      

(12 row(s) affected)