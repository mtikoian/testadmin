IF OBJECT_ID('tempdb..#Emp', 'U') IS NOT NULL 
DROP TABLE #Emp;
CREATE TABLE #Emp (
    empno INT 
    );
INSERT #Emp (empno) VALUES (1), (2);

IF OBJECT_ID('tempdb..#TestData', 'U') IS NOT NULL 
DROP TABLE #TestData;

CREATE TABLE #TestData (
    empno INT,
    jobid INT,
    vesselno INT,
    portid INT
    );
INSERT    #TestData (empno,jobid,vesselno,portid) VALUES
    (1,121,1455,1231),
    (1,122,1486,1322),
    (1,123,1496,1456),
    (2,232,1586,1462),
    (2,233,1596,1556);

select * from #TestData;

with Emps as (
select distinct
  empno
from
  #TestData
)
select
  e.empno
  , ca1.jobid
  , ca2.vesselno
  , ca3.portid
from
  Emps e
  cross apply (select STUFF((select ',' + cast(td.jobid as varchar(10)) from #TestData td where td.empno = e.empno for xml path(''),TYPE).value('.','varchar(max)'),1,1,'')) ca1(jobid)
  cross apply (select STUFF((select ',' + cast(td.vesselno as varchar(10)) from #TestData td where td.empno = e.empno for xml path(''),TYPE).value('.','varchar(max)'),1,1,'')) ca2(vesselno)
  cross apply (select STUFF((select ',' + cast(td.portid as varchar(10)) from #TestData td where td.empno = e.empno for xml path(''),TYPE).value('.','varchar(max)'),1,1,'')) ca3(portid);