DROP FUNCTION dbo.JBMStripHTML
GO

CREATE FUNCTION dbo.JBMStripHTML
        (@HTMLText VARCHAR(MAX))

--		DECLARE @MyHtml VARCHAR(8000)
--    SET @MyHtml = '
--<HTML><Body>

--<b><font face="Courier New" size="3">DOSAGE:</font> Adults--1 to 2

--teaspoonfuls. Children six to twelve--1/2 to 1 teaspoonful.

--Children two to six years--1/2 teaspoonful. These doses may be

--repeated in four hours if necessary but not more than four times in

--twenty-four hours.</b> WARNING: Persons with a high fever or

--persistent cough should not use this preparation unless directed by

--a physician. Do not exceed recommended dosage.<br />

--</Body></HTML>
--'

-- SELECT TOP 1000 @MyHtml AS MyHtml
--   INTO #MyHead
--   FROM dbo.Tally

RETURNS VARCHAR(MAX)
     AS
  BEGIN
--===== Replace all HTML tags with nothing 
  WHILE CHARINDEX('<',@HTMLText) > 0
 SELECT @HTMLText = STUFF(@HTMLText, 
                           CHARINDEX('<',@HTMLText), 
                           CHARINDEX('>',@HTMLText)-CHARINDEX('<',@HTMLText)+1, 
                           '')

--===== Replace all EntityCodes with space
  WHILE CHARINDEX('&',@HTMLText) > 0
 SELECT @HTMLText = STUFF(@HTMLText, 
                           CHARINDEX('&',@HTMLText), 
                           CHARINDEX(';',@HTMLText)-CHARINDEX('&',@HTMLText)+1, 
                           '')

--===== Replace all special characters (except dashes and spaces) and digits with a space 
 SELECT @HTMLText = STUFF(@HTMLText,t.N,1,' ')
   FROM dbo.Tally t
  WHERE t.N <= LEN(@HTMLText)
    AND SUBSTRING(@HTMLText,t.N,1) LIKE '%[^- A-Z]%'

--===== Replace single letter words with a space 
  WHILE PATINDEX('% _ %',@HTMLText) > 0 
 SELECT @HTMLText = STUFF(@HTMLText,PATINDEX('% _ %',@HTMLText),3,' ')

--===== Replace multiple spaces with a single space 
  WHILE CHARINDEX('  ',@HTMLText) > 0 
 SELECT @HTMLText = REPLACE(@HTMLText,'  ',' ')

--===== Drop any leading or trailing spaces 
 RETURN LTRIM(RTRIM(@HTMLText))
    END
GO
