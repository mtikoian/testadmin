if object_id('tempdb..#users', 'U') is not null

BEGIN
      DROP TABLE #users

END
CREATE TABLE #users (

   dbname varchar(128),

    dbusername varchar(128),

    create_date datetime, --user or group

   modifydate datetime,

    owningid int, --admin, user, or null. 

    );

insert into #users

exec sp_MSforeachdb @command1 = 

'use [?];select      DB_NAME()
         , dp.name
         , dp.create_date
         , dp.modify_date
         , dp.owning_principal_id
from sys.database_principals dp 
left outer join sys.server_principals sp
on dp.sid = sp.sid
where sp.name is null and 
dp.type <> ''R'' and dp.principal_id > 4'
select * from #users