
CREATE FUNCTION [dbo].[fnParseStringToSet]
(
    @str VARCHAR(8000), 
    @sep CHAR(1)
)
--WARNING!!! DO NOT USE MAX DATA-TYPES HERE!  IT KILLS PERFORMANCE!
RETURNS TABLE 
AS
/*******************************************************************************\
Function    : fnParseStringToSet

Purpose        : parses a string by a separator and returns a two columns set with
                each element and its position; uses the fnTally for parsing
              
Parameters    : @str - the string to parse
              @sep - the separator character

Invoke        :
    
        select * from [dbo].[fnParseStringToSet]('ab cd ef cd ef cd ef cd ef cd ef cd ef cd ef cd ef cd ef cd ef',' ')

        select tsk.ElemId, tsk.Elem as QATaskId,tme.Elem as EndTime from 
            [dbo].[fnParseStringToSet]('10,20,30,40,50',',') tsk
            left join [dbo].[fnParseStringToSet]('17:10,17:11,17:12',',') tme
                on tme.ElemId=tsk.ElemId

Author        : AdrianBT - 2013-03-18        
\*******************************************************************************/
RETURN
    with cteStart(N1) AS 
    (--returns N+1 (starting position of each "element" just once for each delimiter)
        SELECT 0 UNION ALL
        SELECT t.N+1 FROM [dbo].[fnTally]() t WHERE SUBSTRING(@str,t.N,1) = @sep and t.N<=len(@str)
    ),
    cteLen(N1,L1) AS
    (--returns start and length (for use in substring)
         SELECT s.N1,
                ISNULL(NULLIF(CHARINDEX(@sep,@str,s.N1),0)-s.N1,8000)
         FROM cteStart s
    )
    --so the actual split. The ISNULL/NULLIF combo handles the length for the final element when no delimiter is found.
    SELECT 
        ROW_NUMBER() OVER(ORDER BY l.N1)    as ElemID,
        SUBSTRING(@str, l.N1, l.L1)            as Elem
    FROM 
        cteLen l
    ;

go