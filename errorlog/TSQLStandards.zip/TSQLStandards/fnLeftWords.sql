
 CREATE FUNCTION dbo.fnLeftWords 
/******************************************************************************
 This function accepts a string of characters and returns the left "x" number
 of words using the provided delimiter.  Using "0" for the desired number of
 words returns the full string.
******************************************************************************/
        (
         @String VARCHAR(8000), --The string to return the left "x" words from
         @DesiredWords INT,     --The number of words to return from @String
         @Delimiter VARCHAR(1)  --The single character that separates words
        )
RETURNS VARCHAR(8000) 
     AS
  BEGIN
        --===== Declare local variables
        DECLARE @Work VARCHAR(8000), --Holds modified input string
                @Posit INT,          --Position of a delimiter in the string
                @Count INT           --Number of delimiters that have occurred
            SET @Count = 0           --No delimiters have occurred, yet

        --===== Convert the input with something not likely to be a delimiter.
             -- and we're going to count delimiters to find words.
            SET @Work = REPLACE(@String,@Delimiter,CHAR(1))+CHAR(1)
            
        --===== Using the Tally table to replace a loop, find the position 
             -- of the delimiter after the desired word
         SELECT @Count = @Count+1,
                @Posit = CASE 
                             WHEN @Count = @DesiredWords
                             THEN N
                             ELSE @Posit
                         END
           FROM dbo.Tally
          WHERE SUBSTRING(@Work,N,1) = CHAR(1)
            AND N < LEN(@Work)

        --===== Return all but the last delimiter after the number of desired words
         RETURN (SELECT SUBSTRING(@String,1,ISNULL(@Posit-1,8000)))
    END
GO

...and use it...

SET NOCOUNT ON
SELECT dbo.fnLeftWords(NULL,10,' ')
SELECT dbo.fnLeftWords('',10,' ')
SELECT dbo.fnLeftWords('one',10,' ')
SELECT dbo.fnLeftWords('one two',10,' ')
SELECT dbo.fnLeftWords('one two three',10,' ')
SELECT dbo.fnLeftWords('one two three four',10,' ')
SELECT dbo.fnLeftWords('one two three four five',10,' ')
SELECT dbo.fnLeftWords('one two three four five six',10,' ')
SELECT dbo.fnLeftWords('one two three four five six seven',10,' ')
SELECT dbo.fnLeftWords('one two three four five six seven eight',10,' ')
SELECT dbo.fnLeftWords('one two three four five six seven eight nine',10,' ')
SELECT dbo.fnLeftWords('one two three four five six seven eight nine ten',10,' ')
SELECT dbo.fnLeftWords('one two three four five six seven eight nine ten eleven',10,' ')
SELECT dbo.fnLeftWords('one two three four five six seven eight nine ten eleven twelve',10,' ')

...or...

 SELECT dbo.fnLeftWords(acolumn,#ofwords,somedelimiter)
   FROM yourtable