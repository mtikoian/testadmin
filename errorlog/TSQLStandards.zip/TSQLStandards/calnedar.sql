--===== Create a small example Calendar table
     -- Do notice the primary key constraint
 CREATE TABLE #Calendar 
        (
        DATE DATETIME,
        IsWeekday INT,
        IsWorkday INT,
        WorkDayCount INT,
        CONSTRAINT PK_Calendar_Date 
                   PRIMARY KEY CLUSTERED (Date) 
                   WITH FILLFACTOR = 100
        )

--===== Populate it with a small sample of data (all of Feb 2007)
 INSERT INTO #Calendar (DATE,IsWeekday,IsWorkday)
 SELECT '2007-02-01 00:00:00',1,1 UNION ALL
 SELECT '2007-02-02 00:00:00',1,1 UNION ALL
 SELECT '2007-02-03 00:00:00',0,0 UNION ALL
 SELECT '2007-02-04 00:00:00',0,0 UNION ALL
 SELECT '2007-02-05 00:00:00',1,1 UNION ALL
 SELECT '2007-02-06 00:00:00',1,1 UNION ALL
 SELECT '2007-02-07 00:00:00',1,1 UNION ALL
 SELECT '2007-02-08 00:00:00',1,1 UNION ALL
 SELECT '2007-02-09 00:00:00',1,1 UNION ALL
 SELECT '2007-02-10 00:00:00',0,0 UNION ALL
 SELECT '2007-02-11 00:00:00',0,0 UNION ALL
 SELECT '2007-02-12 00:00:00',1,1 UNION ALL
 SELECT '2007-02-13 00:00:00',1,1 UNION ALL
 SELECT '2007-02-14 00:00:00',1,1 UNION ALL
 SELECT '2007-02-15 00:00:00',1,1 UNION ALL
 SELECT '2007-02-16 00:00:00',1,1 UNION ALL
 SELECT '2007-02-17 00:00:00',0,0 UNION ALL
 SELECT '2007-02-18 00:00:00',0,0 UNION ALL
 SELECT '2007-02-19 00:00:00',1,1 UNION ALL 
 SELECT '2007-02-20 00:00:00',1,1 UNION ALL
 SELECT '2007-02-21 00:00:00',1,1 UNION ALL
 SELECT '2007-02-22 00:00:00',1,1 UNION ALL
 SELECT '2007-02-23 00:00:00',1,1 UNION ALL
 SELECT '2007-02-24 00:00:00',0,0 UNION ALL
 SELECT '2007-02-25 00:00:00',0,0 UNION ALL
 SELECT '2007-02-26 00:00:00',1,1 UNION ALL
 SELECT '2007-02-27 00:00:00',1,1 UNION ALL
 SELECT '2007-02-28 00:00:00',1,1
 
 
 --===== Now, populate the WorkDayCount column with a running count
     -- using a little SQL Server prestidigitation Wink
     -- Do notice the WITH (INDEX()) notation... it's important
DECLARE @CurrentCount INT
    SET @CurrentCount = 0

  UPDATE #Calendar
     SET @CurrentCount = WorkDayCount = CASE 
                                            WHEN IsWorkDay = 1 
                                            THEN @CurrentCount + 1 
                                            ELSE @CurrentCount 
                                        END
    FROM #Calendar WITH (INDEX(PK_Calendar_Date))

--===== Just verify what we have in the calendar table
 SELECT * FROM #Calendar

--From then on, the kinds of calculations you're asking for become very simple and very fast... recommend you create a function for it but here's an almost hard-coded example to solve the two problems you posted... and more...

--===== Setup a couple of variables to simulate what could be done in a function...
DECLARE @GivenDate    DATETIME
DECLARE @NumberOfDays INT

    SET @GivenDate = '20070221'

--===== Solve the first problem: Find business day 5 days BEFORE given date
    SET @NumberOfDays = -5

 SELECT DATE 
   FROM #Calendar
  WHERE WorkDayCount = (SELECT WorkdayCount FROM #Calendar WHERE Date=@GivenDate)+@NumberOfDays
    AND IsWorkDay = 1

--===== Solve the second problem: Find business day 4 days AFTER given date 
     -- (Notice that the SELECT is exactly the same so we could turn this into a function)
    SET @NumberOfDays = 4

 SELECT DATE 
   FROM #Calendar
  WHERE WorkDayCount = (SELECT WorkdayCount FROM #Calendar WHERE Date=@GivenDate)+@NumberOfDays
    AND IsWorkDay = 1

--===== Solve an additional problem: Find the next business day after given date
     -- (Notice that the SELECT is exactly the same so we could turn this into a function)
    SET @GivenDate = '20070217' --A SATURDAY
    SET @NumberOfDays = 1

 SELECT DATE 
   FROM #Calendar
  WHERE WorkDayCount = (SELECT WorkdayCount FROM #Calendar WHERE Date=@GivenDate)+@NumberOfDays
    AND IsWorkDay = 1

--===== Solve an additional problem: Find the next business day after given date
     -- (Notice that the SELECT is exactly the same so we could turn this into a function)
    SET @GivenDate = '20070216' --A FRIDAY
    SET @NumberOfDays = 1

 SELECT DATE 
   FROM #Calendar
  WHERE WorkDayCount = (SELECT WorkdayCount FROM #Calendar WHERE Date=@GivenDate)+@NumberOfDays
    AND IsWorkDay = 1

