
CREATE FUNCTION [dbo].[fnTally]()
RETURNS TABLE --WITH SCHEMABINDING 
AS
/*******************************************************************************\
Function    : fnTally

Purpose        : returns a set with numbers from 1 to 10,000 
              to be used in parsing and sequential data generation whithout loop
              
Parameters    : no parameters

Invoke        :
    
        select * from [dbo].[fnTally]()
        select N from [dbo].[fnTally]()
        select substring('abcdef',N,1) as chr from [dbo].[fnTally]() where N<len('abcdef') -- parsing a string
        select dateadd(dd, N, '2007-01-01') as dte from [dbo].[fnTally]() --gets dates for about 30 years

Author        : AdrianBT - 2013-03-18        
\*******************************************************************************/
RETURN
    WITH 
    E1(N) AS 
    ( --10E+1 or 10 rows
         SELECT 1 UNION ALL SELECT 1 UNION ALL SELECT 1 UNION ALL
         SELECT 1 UNION ALL SELECT 1 UNION ALL SELECT 1 UNION ALL
         SELECT 1 UNION ALL SELECT 1 UNION ALL SELECT 1 UNION ALL SELECT 1
    ),         
 E2(N) AS 
 ( --10E+2 or 100 rows    
        SELECT 1 FROM E1 a, E1 b
    ),
 E4(N) AS 
 ( --10E+4 or 10,000 rows max
        SELECT 1 FROM E2 a, E2 b
    )
             SELECT ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) as N FROM E4
    ;
GO
