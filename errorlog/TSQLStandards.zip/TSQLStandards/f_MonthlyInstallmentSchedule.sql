drop function dbo.MonthlyInstallmentSchedule
go
 CREATE FUNCTION dbo.MonthlyInstallmentSchedule
/**********************************************************************************************************************
 Purpose:
 Given a start date and the number of monthly installments to make where the start date is the date of the first
 monthly installment, return a list of monthly installment dates and the installment number up to 10,000 installments.

 If the start date is the end of the month, then all dates returned will be the end of the month. (Rev 01)

 Programmer Notes:
 1. Suitable for use with SQL Server 2005 and up.
 2. @pInstallments must be >= 0 or a TOP error will occur.
 3. Times will be stripped from the @pStartDate.
 4. Works with SET DATEFORMAT but is totally optional.
 5. This is a high-performance iTVF and won't bog a system down like a scalar or mTVF funtion will.

 Usage Example:
--===== Basic syntax
 SELECT  InstallmentNumber
        ,InstallmentDate
   FROM dbo.MonthlyInstallmentSchedule(@pStartDate,@pInstallments)
;
--===== Working example (with dmy format)
    SET DATEFORMAT dmy --Not required if dmy is the default
;
 SELECT  InstallmentNumber
        ,InstallmentDate
   FROM dbo.MonthlyInstallmentSchedule('31-01-2016',5)
;
--===== Working example (with mdy format)
    SET DATEFORMAT mdy --Not required if mdy is the default
;
 SELECT  InstallmentNumber
        ,InstallmentDate
   FROM dbo.MonthlyInstallmentSchedule('02-29-2016',5)
;
-----------------------------------------------------------------------------------------------------------------------
 Revision History:
 Rev 00 - 20 Jun 2014 - Jeff Moden - Initial creation and unit test.
 Rev 01 - 20 Jun 2014 - Jeff Moden - Add end-of-month sensitivity.
**********************************************************************************************************************/
--===== Declare the I/O for the function
        (
         @pStartDate    DATETIME
        ,@pInstallments INT
        )
RETURNS TABLE WITH SCHEMABINDING AS
 RETURN WITH
 WholeDate AS (SELECT  StartDate = DATEADD(dd,DATEDIFF(dd,'1753',@pStartDate),'1753')) --Convert to whole date
,DateInfo  AS (SELECT  StartDate
                      ,IsMonthEnd = CASE --(Rev 01)
                                    WHEN DATEADD(dd,1,StartDate)=DATEADD(mm,DATEDIFF(mm,'1753',StartDate)+1,'1753')
                                    THEN 1
                                    ELSE 0
                                    END
                 FROM  WholeDate)
,E1(N)     AS (SELECT 1 UNION ALL SELECT 1 UNION ALL SELECT 1 UNION ALL SELECT 1 UNION ALL SELECT 1 UNION ALL
               SELECT 1 UNION ALL SELECT 1 UNION ALL SELECT 1 UNION ALL SELECT 1 UNION ALL SELECT 1) --10 rows
,E4(N)     AS (SELECT 1 FROM E1 a, E1 b, E1 c, E1 d) --10 thousand rows
,Tally(N)  AS (SELECT TOP(@pInstallments) N = ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) FROM E4) --Create number sequence
               SELECT  InstallmentNumber = t.N
                      ,InstallmentDate   = 
                       CASE --If start date is end of month, always use end of month else use exact or closest date. (Rev 01)
                         WHEN IsMonthEnd = 1
                         THEN DATEADD(dd,-1,DATEADD(mm,DATEDIFF(mm,'1753',d.StartDate)+t.N,'1753'))
                         ELSE DATEADD(mm,t.N-1,d.StartDate)
                       END
                 FROM DateInfo  d
                CROSS JOIN Tally t
;
GO
