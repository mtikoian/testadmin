/*
   **********************************************************************************
   LAB/Demo:   Table Partitioning - "sliding window"/archiving
   This script demonstrates the workings of "sliding window" using Table Partitioning
   feature of SQL Server 2005 Enterprise Edition with SP1/SP2.  Future releases may
   alter the functionality and potentially change the behavior that is demonstrated
   in this script.

   SCRIPT SUMMARY
   The following scenario is presented:

   Test database is created to reside on 5 filegroups:

      PRIMARY  - test_data_main - contains system objects
      FGroup1  - test_data1 - filegroup will share Production and Staging objects
      FGroup2  - test_data2 - filegroup dedicated to Staging environment
      FGroup3  - test_data3 - filegroup will share Staging and Archive objects
      FGroup4  - test_data4 - filegroup dedicated to Archive environment

   Partition functions will be created to serve the following environments:

      Pf1(datetime) - Production
      Pf2(datetime) - Staging
      Pf3(datetime) - Archive

   Original split (01/01/1900) is for demonstration purposes only, and should not
   be used in the actual production environment.

   Partition schemes will be created using above functions, with the following
   definitions:

      Ps1 (based on Pf1 function) - FGroup1, FGroup2
      Ps2 (based on Pf2 function) - FGroup1, FGroup3
      Ps3 (based on Pf3 function) - FGroup4, FGroup3

   The following objects will be created:

      Production table - Production.Orders
      Staging table    - Staging.Orders
      Archiving table  - Archive.Orders

   There will be 3 cycles of 14 statement blocks executed sequentially, to demonstrate
   the "sliding window" effect:

      - Production
         1. Merge previous boundary
         2. Mark FGroup2 as NEXT USED
         3. Create new split to place the data to be switched out on the 1st partition - Pf1()
      - Staging
         4. Merge previous boundary
         5. Mark FGroup3 as NEXT USED
         6. Create new split to match Production partition function configuration - Pf2()
      - Production
         7. Switch data from FGroup1 of Production to FGroup1 of Staging
      - Staging
         8. Merge previous boundary
         9. Mark FGroup3 as NEXT USED
        10. Create new split based on the lowest value of partition key that was
            switched in step 7 - Pf2()
      - Archive
        11. Merge revious boundary
        12. Mark FGroup3 as NEXT USED
        13. Create new split to match the boundary point of Pf2()
      - Staging
        14. Switch data from FGroup3 of Staging to FGroup3 of Archive

   The steps above will be repeated 2 more times to facilitate the demonstration
   of "sliding window" effect.  All the steps mentioned above are identical with the
   exception of steps that reference boundary points.  The difference lies in values
   for MERGE and SPLIT operations for partition functions.

   SCRIPT REQUIREMENTS
   AdventureWorks sample database must be present and accessible with
   Sales.SalesOrderDetail table in an unaltered state.  The script will create TEST
   database in C:\TEMP sub-directory.  The account used to connect to the instance
   must have DROP and CREATE DATABASE permissions on the instance, and SELECT
   permission on Sales.SaleOderDetail table in AdventureWorks database.
   ***********************************************************************************
*/
use master;
if db_id('test') is not null begin
   exec ('use test')
   exec ('alter database test set single_user with rollback immediate')
   drop database test
end
go

-- Create new database (test) comprised of 5 filegroups:
--   PRIMARY filegroup will hold system objects
--   FGroup1 and FGroup2 will hold Production.Orders table
--   FGroup1 and FGroup3 will hold Staging.Orders table, and
--   FGroup4 and FGroup3 will hold Archive.Orders table.
create database test
   on primary
     (name        = test_data_main
     ,filename    = 'c:\temp\test_data_main.mdf'
     ,size        = 5MB
     ,filegrowth  = 0),
   filegroup FGroup1
     (name        = test_data1
     ,filename    = 'c:\temp\test_data1.ndf'
     ,size        = 50MB
     ,filegrowth  = 0),
   filegroup FGroup2
     (name        = test_data2
     ,filename    = 'c:\temp\test_data2.ndf'
     ,size        = 50MB
     ,filegrowth  = 0),
   filegroup FGroup3
     (name        = test_data3
     ,filename    = 'c:\temp\test_data3.ndf'
     ,size        = 50MB
     ,filegrowth  = 0),
   filegroup FGroup4
     (name        = test_data4
     ,filename    = 'c:\temp\test_data4.ndf'
     ,size        = 50MB
     ,filegrowth  = 0)
   log on
     (name        = test_log
     ,filename    = 'c:\temp\test_log.ldf'
     ,size        = 200MB
     ,filegrowth  = 0)
go

-- View the database file and filegroup configuration
use test
go
select
   [File Group Name]          = case f.groupid when 0 then 'TRANSACTION LOG' else fg.name end
  ,[Default File Group]       = case fg.is_default when 1 then 'Yes' else 'No' end
  ,[READ_ONLY]                = case fg.is_read_only when 1 then 'Yes' else 'No' end
  ,[Logical File Name]        = f.name
  ,[Physical File Name]       = f.filename
  ,[Allocated File Size (MB)] = f.size * 8.00 / 1024
   from sys.sysfiles f
   left outer join sys.filegroups fg
      on f.groupid = fg.data_space_id
   order by case f.groupid when 0 then 9999 else f.groupid end, f.fileid
go

-- Create a view that will help us view what partitions exist and how they are configured
create view dbo.vw_partitions as
   select top(100) percent
      dds.partition_scheme_id
     ,partition_sequence_number     = dds.destination_id
     ,partition_name                = ps.name
     ,file_group_id                 = dds.data_space_id
     ,file_group_name               = fg.name
     ,function_name                 = pf.name
     ,left_right                    = case pf.boundary_value_on_right when 1 then 'RIGHT' else 'LEFT' end
     ,pf.fanout
     ,prv.boundary_id
     ,boundary_value                = prv.value 
      from sys.destination_data_spaces dds
      inner join sys.filegroups fg
         on dds.data_space_id       = fg.data_space_id
      inner join sys.partition_schemes ps
         on dds.partition_scheme_id = ps.data_space_id
      inner join sys.partition_functions pf
         on ps.function_id          = pf.function_id
      left outer join sys.partition_range_values prv
         on pf.function_id          = prv.function_id
        and dds.destination_id      = prv.boundary_id
      order by 1, 2
go

-- Create partition function for Production.Orders
create partition function Pf1 (datetime)
   as range right for values (
      '19000101'
   )
go
-- Create partition function for Staging.Orders
create partition function Pf2 (datetime)
   as range right for values (
      '19000101'
   )
go
-- Create partition function for Archive.Orders
create partition function Pf3 (datetime)
   as range right for values (
      '19000101'
   )
go

-- Create partition scheme for Production.Orders
create partition scheme Ps1 as partition Pf1
   to (
      FGroup1
     ,FGroup2
   )
go
-- Create partition scheme for Staging.Orders
create partition scheme Ps2 as partition Pf2
   to (
      FGroup1
     ,FGroup3
   )
go
-- Create partition scheme for Archive.Orders
create partition scheme Ps3 as partition Pf3
   to (
      FGroup4
     ,FGroup3
   )
go

-- Create Production schema
create schema Production
go
-- Create Production.Orders table
create table Production.Orders(
	OrderID                 int               not null
  ,OrderDetailID           int               not null
  ,CarrierTrackingNumber   nvarchar(25)          null
  ,OrderQty                smallint          not null
  ,ProductID               int               not null
  ,SpecialOfferID          int               not null
  ,UnitPrice               money             not null
  ,UnitPriceDiscount       money             not null
  ,LineTotal               money             not null
  ,rowguid_id              uniqueidentifier  not null
  ,OrderDate               datetime          not null
) on Ps1(OrderDate)
go
-- Populate the table with data from AdentureWorks database
insert Production.Orders select * from AdventureWorks.Sales.SalesOrderDetail
go

-- Create Staging schema
create schema Staging
go
-- Create Staging.Orders table
create table Staging.Orders(
	OrderID                 int               not null
  ,OrderDetailID           int               not null
  ,CarrierTrackingNumber   nvarchar(25)          null
  ,OrderQty                smallint          not null
  ,ProductID               int               not null
  ,SpecialOfferID          int               not null
  ,UnitPrice               money             not null
  ,UnitPriceDiscount       money             not null
  ,LineTotal               money             not null
  ,rowguid_id              uniqueidentifier  not null
  ,OrderDate               datetime          not null
) on Ps2(OrderDate)
go
-- Create Archive schema
create schema Archive
go
-- Create Archive.Orders table
create table Archive.Orders(
	OrderID                 int               not null
  ,OrderDetailID           int               not null
  ,CarrierTrackingNumber   nvarchar(25)          null
  ,OrderQty                smallint          not null
  ,ProductID               int               not null
  ,SpecialOfferID          int               not null
  ,UnitPrice               money             not null
  ,UnitPriceDiscount       money             not null
  ,LineTotal               money             not null
  ,rowguid_id              uniqueidentifier  not null
  ,OrderDate               datetime          not null
) on Ps3(OrderDate)
go

-- View partition definitions and data distribution.
-- Notice that with the default boundary (01/01/1900) defined on Pf1,
-- all 121,317 rows reside in the second partition.
select * from dbo.vw_partitions
select [Partition #] = $partition.Pf1(OrderDate), 
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Production.Orders group by $partition.Pf1(OrderDate)
select [Partition #] = $partition.Pf2(OrderDate),
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Staging.Orders group by $partition.Pf2(OrderDate)
select [Partition #] = $partition.Pf3(OrderDate),
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Archive.Orders group by $partition.Pf3(OrderDate)

-- ********* BEGINNING of ITERATION OF SWITCHING DATA FROM PS1 to PS3 *********
-- 1. Merge the default range.  Notice that now all the data resides in the 1st partition,
-- and FGroup2 is no longer associated with Production.Orders table
alter partition function Pf1() merge range ('19000101')
select * from dbo.vw_partitions
select [Partition #] = $partition.Pf1(OrderDate), 
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Production.Orders group by $partition.Pf1(OrderDate)
select [Partition #] = $partition.Pf2(OrderDate),
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Staging.Orders group by $partition.Pf2(OrderDate)
select [Partition #] = $partition.Pf3(OrderDate),
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Archive.Orders group by $partition.Pf3(OrderDate)
go

-- Now re-introduce FGroup2 into the storage structure for Production.Orders
-- by marking it as NEXT USED for partition scheme Ps1, and by establishing a new boundary
-- 2. Mark FGroup2 as NEXT USED
alter partition scheme Ps1 next used FGroup2
-- 3. Create new split to place the data to be switched out on the 1st partition
alter partition function Pf1() split range ('20020101')
select * from dbo.vw_partitions
select [Partition #] = $partition.Pf1(OrderDate), 
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Production.Orders group by $partition.Pf1(OrderDate)
select [Partition #] = $partition.Pf2(OrderDate),
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Staging.Orders group by $partition.Pf2(OrderDate)
select [Partition #] = $partition.Pf3(OrderDate),
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Archive.Orders group by $partition.Pf3(OrderDate)
go

-- PARTITION SCHEME 2
-- Remove the previous boundary by issueing MERGE, and establish a new SPLIT
-- after marking FGroup3 as NEXT USED
-- 4. Merge previous boundary
alter partition function Pf2() merge range ('19000101')
-- 5. Mark FGroup3 as NEXT USED
alter partition scheme Ps2 next used FGroup3
-- 6. Create new split to match Production partition function configuration
alter partition function Pf2() split range ('20020101')
select * from dbo.vw_partitions
select [Partition #] = $partition.Pf1(OrderDate), 
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Production.Orders group by $partition.Pf1(OrderDate)
select [Partition #] = $partition.Pf2(OrderDate),
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Staging.Orders group by $partition.Pf2(OrderDate)
select [Partition #] = $partition.Pf3(OrderDate),
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Archive.Orders group by $partition.Pf3(OrderDate)
go

-- Switch the data from Production.Orders partition 1 (FGroup1) to Staging.Orders (FGroup1)
-- 7. Switch data from FGroup1 of Production to FGroup1 of Staging
alter table Production.Orders switch partition 1 to Staging.Orders partition 1
select * from dbo.vw_partitions
select [Partition #] = $partition.Pf1(OrderDate), 
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Production.Orders group by $partition.Pf1(OrderDate)
select [Partition #] = $partition.Pf2(OrderDate),
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Staging.Orders group by $partition.Pf2(OrderDate)
select [Partition #] = $partition.Pf3(OrderDate),
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Archive.Orders group by $partition.Pf3(OrderDate)
go

-- 8. Merge previous boundary
alter partition function Pf2() merge range ('20020101')
select * from dbo.vw_partitions
select [Partition #] = $partition.Pf1(OrderDate), 
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Production.Orders group by $partition.Pf1(OrderDate)
select [Partition #] = $partition.Pf2(OrderDate),
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Staging.Orders group by $partition.Pf2(OrderDate)
select [Partition #] = $partition.Pf3(OrderDate),
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Archive.Orders group by $partition.Pf3(OrderDate)
go

-- Relocate the data in Staging.Orders from the first to the second partition
-- by splitting on the lowest possible value,
-- while marking FGroup3 as the next used filegroup
-- 9. Mark FGroup3 as NEXT USED
alter partition scheme Ps2 next used FGroup3
--10. Create new split based on the lowest value of partition key that was
--    switched in step 7
alter partition function Pf2() split range ('20010101')
select * from dbo.vw_partitions
select [Partition #] = $partition.Pf1(OrderDate), 
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Production.Orders group by $partition.Pf1(OrderDate)
select [Partition #] = $partition.Pf2(OrderDate),
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Staging.Orders group by $partition.Pf2(OrderDate)
select [Partition #] = $partition.Pf3(OrderDate),
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Archive.Orders group by $partition.Pf3(OrderDate)
go

-- PARTITION SCHEME 3
--11. Merge revious boundary
alter partition function Pf3() merge range ('19000101')
select * from dbo.vw_partitions
select [Partition #] = $partition.Pf1(OrderDate), 
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Production.Orders group by $partition.Pf1(OrderDate)
select [Partition #] = $partition.Pf2(OrderDate),
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Staging.Orders group by $partition.Pf2(OrderDate)
select [Partition #] = $partition.Pf3(OrderDate),
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Archive.Orders group by $partition.Pf3(OrderDate)
go

-- Here we match partition function constraints between 2nd and 3rd partition functions
--12. Mark FGroup3 as NEXT USED
alter partition scheme Ps3 next used FGroup3
--13. Create new split to match the boundary point of Pf3()
alter partition function Pf3() split range ('20010101')
select * from dbo.vw_partitions
select [Partition #] = $partition.Pf1(OrderDate), 
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Production.Orders group by $partition.Pf1(OrderDate)
select [Partition #] = $partition.Pf2(OrderDate),
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Staging.Orders group by $partition.Pf2(OrderDate)
select [Partition #] = $partition.Pf3(OrderDate),
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Archive.Orders group by $partition.Pf3(OrderDate)
go

-- Switch the data from staging table to archiving table
--14. Switch data from FGroup3 of Staging to FGroup3 of Archive
alter table Staging.Orders switch partition 2 to Archive.Orders partition 2
select * from dbo.vw_partitions
select [Partition #] = $partition.Pf1(OrderDate), 
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Production.Orders group by $partition.Pf1(OrderDate)
select [Partition #] = $partition.Pf2(OrderDate),
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Staging.Orders group by $partition.Pf2(OrderDate)
select [Partition #] = $partition.Pf3(OrderDate),
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Archive.Orders group by $partition.Pf3(OrderDate)
go
-- ********* END OF FIRST ITERATION OF SWITCHING DATA FROM PS1 to PS3 *********

-- Eliminate the partition by merging on the previous boundary
alter partition function Pf1() merge range ('20020101')
select * from dbo.vw_partitions
select [Partition #] = $partition.Pf1(OrderDate), 
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Production.Orders group by $partition.Pf1(OrderDate)
select [Partition #] = $partition.Pf2(OrderDate),
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Staging.Orders group by $partition.Pf2(OrderDate)
select [Partition #] = $partition.Pf3(OrderDate),
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Archive.Orders group by $partition.Pf3(OrderDate)
go

-- Establish a new boundary and mark FGroup2 as the next used filegroup
alter partition scheme Ps1 next used FGroup2
alter partition function Pf1() split range ('20030101')
select * from dbo.vw_partitions
select [Partition #] = $partition.Pf1(OrderDate), 
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Production.Orders group by $partition.Pf1(OrderDate)
select [Partition #] = $partition.Pf2(OrderDate),
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Staging.Orders group by $partition.Pf2(OrderDate)
select [Partition #] = $partition.Pf3(OrderDate),
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Archive.Orders group by $partition.Pf3(OrderDate)
go

-- Prepare the staging table by establishing the same partition boundary as in Pf1()
alter partition function Pf2() merge range ('20010101')
alter partition scheme Ps2 next used FGroup3
alter partition function Pf2() split range ('20030101')
select * from dbo.vw_partitions
select [Partition #] = $partition.Pf1(OrderDate), 
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Production.Orders group by $partition.Pf1(OrderDate)
select [Partition #] = $partition.Pf2(OrderDate),
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Staging.Orders group by $partition.Pf2(OrderDate)
select [Partition #] = $partition.Pf3(OrderDate),
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Archive.Orders group by $partition.Pf3(OrderDate)
go

-- Switch the data from Production to staging table
alter table Production.Orders switch partition 1 to Staging.Orders partition 1
select * from dbo.vw_partitions
select [Partition #] = $partition.Pf1(OrderDate), 
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Production.Orders group by $partition.Pf1(OrderDate)
select [Partition #] = $partition.Pf2(OrderDate),
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Staging.Orders group by $partition.Pf2(OrderDate)
select [Partition #] = $partition.Pf3(OrderDate),
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Archive.Orders group by $partition.Pf3(OrderDate)
go

-- Relocate the data in staging table from the first to the second partition
-- by merging on 20020101 boundary point, and then splitting on the lowest possible value,
-- while marking FGroup3 as the next used filegroup
alter partition function Pf2() merge range ('20030101')
alter partition scheme Ps2 next used FGroup3
alter partition function Pf2() split range ('20020101')
select * from dbo.vw_partitions
select [Partition #] = $partition.Pf1(OrderDate), 
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Production.Orders group by $partition.Pf1(OrderDate)
select [Partition #] = $partition.Pf2(OrderDate),
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Staging.Orders group by $partition.Pf2(OrderDate)
select [Partition #] = $partition.Pf3(OrderDate),
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Archive.Orders group by $partition.Pf3(OrderDate)
go

-- Here we match partition function constraints between 2nd and 3rd partition functions
alter partition function Pf3() merge range ('20010101')
alter partition scheme Ps3 next used FGroup3
alter partition function Pf3() split range ('20020101')
select * from dbo.vw_partitions
select [Partition #] = $partition.Pf1(OrderDate), 
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Production.Orders group by $partition.Pf1(OrderDate)
select [Partition #] = $partition.Pf2(OrderDate),
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Staging.Orders group by $partition.Pf2(OrderDate)
select [Partition #] = $partition.Pf3(OrderDate),
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Archive.Orders group by $partition.Pf3(OrderDate)
go

-- Switch the data from staging to archiving table
alter table Staging.Orders switch partition 2 to Archive.Orders partition 2
select * from dbo.vw_partitions
select [Partition #] = $partition.Pf1(OrderDate), 
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Production.Orders group by $partition.Pf1(OrderDate)
select [Partition #] = $partition.Pf2(OrderDate),
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Staging.Orders group by $partition.Pf2(OrderDate)
select [Partition #] = $partition.Pf3(OrderDate),
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Archive.Orders group by $partition.Pf3(OrderDate)
go
-- *********************** 2 - END OF SECOND ITERATION OF SWITCHING DATA FROM PS1 to PS3 *************************

alter partition function Pf1() merge range ('20030101')
select * from dbo.vw_partitions
select [Partition #] = $partition.Pf1(OrderDate), 
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Production.Orders group by $partition.Pf1(OrderDate)
select [Partition #] = $partition.Pf2(OrderDate),
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Staging.Orders group by $partition.Pf2(OrderDate)
select [Partition #] = $partition.Pf3(OrderDate),
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Archive.Orders group by $partition.Pf3(OrderDate)
go

alter partition scheme Ps1 next used FGroup2
alter partition function Pf1() split range ('20040101')
select * from dbo.vw_partitions
select [Partition #] = $partition.Pf1(OrderDate), 
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Production.Orders group by $partition.Pf1(OrderDate)
select [Partition #] = $partition.Pf2(OrderDate),
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Staging.Orders group by $partition.Pf2(OrderDate)
select [Partition #] = $partition.Pf3(OrderDate),
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Archive.Orders group by $partition.Pf3(OrderDate)
go

alter partition function Pf2() merge range ('20020101')
alter partition scheme Ps2 next used FGroup3
alter partition function Pf2() split range ('20040101')
select * from dbo.vw_partitions
select [Partition #] = $partition.Pf1(OrderDate), 
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Production.Orders group by $partition.Pf1(OrderDate)
select [Partition #] = $partition.Pf2(OrderDate),
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Staging.Orders group by $partition.Pf2(OrderDate)
select [Partition #] = $partition.Pf3(OrderDate),
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Archive.Orders group by $partition.Pf3(OrderDate)
go

alter table Production.Orders switch partition 1 to Staging.Orders partition 1
select * from dbo.vw_partitions
select [Partition #] = $partition.Pf1(OrderDate), 
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Production.Orders group by $partition.Pf1(OrderDate)
select [Partition #] = $partition.Pf2(OrderDate),
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Staging.Orders group by $partition.Pf2(OrderDate)
select [Partition #] = $partition.Pf3(OrderDate),
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Archive.Orders group by $partition.Pf3(OrderDate)
go

-- Relocate the data in Staging.Orders from the first to the second partition
-- by merging on 20020101 boundary point, and then splitting on the lowest possible value,
-- while marking FGroup3 as the next used filegroup
alter partition function Pf2() merge range ('20040101')
alter partition scheme Ps2 next used FGroup3
alter partition function Pf2() split range ('20030101')
select * from dbo.vw_partitions
select [Partition #] = $partition.Pf1(OrderDate), 
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Production.Orders group by $partition.Pf1(OrderDate)
select [Partition #] = $partition.Pf2(OrderDate),
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Staging.Orders group by $partition.Pf2(OrderDate)
select [Partition #] = $partition.Pf3(OrderDate),
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Archive.Orders group by $partition.Pf3(OrderDate)
go

-- Here we match partition function constraints between 2nd and 3rd partition functions
alter partition function Pf3() merge range ('20020101')
alter partition scheme Ps3 next used FGroup3
alter partition function Pf3() split range ('20030101')
select * from dbo.vw_partitions
select [Partition #] = $partition.Pf1(OrderDate), 
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Production.Orders group by $partition.Pf1(OrderDate)
select [Partition #] = $partition.Pf2(OrderDate),
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Staging.Orders group by $partition.Pf2(OrderDate)
select [Partition #] = $partition.Pf3(OrderDate),
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Archive.Orders group by $partition.Pf3(OrderDate)
go

alter table Staging.Orders switch partition 2 to Archive.Orders partition 2
select * from dbo.vw_partitions
select [Partition #] = $partition.Pf1(OrderDate), 
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Production.Orders group by $partition.Pf1(OrderDate)
select [Partition #] = $partition.Pf2(OrderDate),
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Staging.Orders group by $partition.Pf2(OrderDate)
select [Partition #] = $partition.Pf3(OrderDate),
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Archive.Orders group by $partition.Pf3(OrderDate)
-- *********************** 3 - END OF THIRD ITERATION OF SWITCHING DATA FROM PS1 to PS3 *************************

-- At this point we assume that TEST database has been created with 6 filegroups and PRIMARY.
use test
go
-- Let's create a view that will help us see what filegroups are used
-- for what partitions.
create view dbo.vw_partitions as
   select top(100) percent
      dds.partition_scheme_id
     ,partition_sequence_number     = dds.destination_id
     ,partition_name                = ps.name
     ,file_group_id                 = dds.data_space_id
     ,file_group_name               = fg.name
     ,function_name                 = pf.name
     ,left_right                    = case pf.boundary_value_on_right when 1 then 'RIGHT' else 'LEFT' end
     ,pf.fanout
     ,prv.boundary_id
     ,boundary_value                = prv.value 
      from sys.destination_data_spaces dds
      inner join sys.filegroups fg
         on dds.data_space_id       = fg.data_space_id
      inner join sys.partition_schemes ps
         on dds.partition_scheme_id = ps.data_space_id
      inner join sys.partition_functions pf
         on ps.function_id          = pf.function_id
      left outer join sys.partition_range_values prv
         on pf.function_id          = prv.function_id
        and dds.destination_id      = prv.boundary_id
      order by 1, 2
go
-- Create partition function Pf() that is used as a foundation
-- for our partitioning scenario.
create partition function Pf(datetime) as range right for values (
   '20020201'
  ,'20020301'
  ,'20020401'
  ,'20020501'
  ,'20020601')
go
-- Create partition scheme based on Pf() partition function.
create partition scheme Ps as partition Pf to (
   FGroup1
  ,FGroup2
  ,FGroup3
  ,FGroup4
  ,FGroup5
  ,FGroup6)
go

-- Create Production schema
create schema Production
go
-- Create Production.Orders table
create table Production.Orders(
	OrderID                 int               not null
  ,OrderDetailID           int               not null
  ,CarrierTrackingNumber   nvarchar(25)          null
  ,OrderQty                smallint          not null
  ,ProductID               int               not null
  ,SpecialOfferID          int               not null
  ,UnitPrice               money             not null
  ,UnitPriceDiscount       money             not null
  ,LineTotal               money             not null
  ,rowguid_id              uniqueidentifier  not null
  ,OrderDate               datetime          not null
) on Ps(OrderDate)
go
-- Populate the table with data from AdentureWorks database
-- up to June 30th 2002.
insert Production.Orders select * from AdventureWorks.Sales.SalesOrderDetail
   where modifiedDate between '19000101' and '20020630'
go

-- See how data is distributed
select * from dbo.vw_partitions
select [Partition #] = $partition.Pf(OrderDate), 
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Production.Orders group by $partition.Pf(OrderDate)
   order by $partition.Pf(OrderDate)
select partition_number, rows from sys.partitions
   where object_id = object_id('Production.Orders')
go

-- Merge the first boundary.  By doing so we "drop" FGroup2
-- from the storage definition of Production.Orders
alter partition function Pf() merge range ('20020201')

-- Here we "drop" FGroup3 from the storage definition of Production.Orders
-- so that we can move its data to FGroup2, thus - sliding the window.
alter partition function Pf() merge range ('20020301')
-- See how data is distributed
select * from dbo.vw_partitions
select [Partition #] = $partition.Pf(OrderDate), 
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Production.Orders group by $partition.Pf(OrderDate)
   order by $partition.Pf(OrderDate)
select partition_number, rows from sys.partitions
   where object_id = object_id('Production.Orders')
go
-- As you see from above output, FGroup2 and FGroup3 are no longer part
-- of the storage definition of Production.Orders.  Now we need to
-- re-include FGroup2 into the table definition by marking it as NEXT USED.
alter partition scheme Ps next used FGroup2
-- Now we establish a new boundary, and since FGroup2 was marked as NEXT USED,
-- the data greater or equal to 03/01/2002 will go into FGroup2
alter partition function Pf() split range ('20020301')
-- See how data is distributed
select * from dbo.vw_partitions
select [Partition #] = $partition.Pf(OrderDate), 
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Production.Orders group by $partition.Pf(OrderDate)
   order by $partition.Pf(OrderDate)
select partition_number, rows from sys.partitions
   where object_id = object_id('Production.Orders')
go

-- Here we eliminate the next boundary and remove FGroup4 from table definition.
alter partition function Pf() merge range('20020401')
-- Now we mark FGroup3 as NEXT USED
alter partition scheme Ps next used FGroup3
-- We re-establish the same boundary, but instead of data going back to FGroup4,
-- it now goes to FGroup3 because we marked it as NEXT USED
alter partition function Pf() split range ('20020401')
-- See how data is distributed
select * from dbo.vw_partitions
select [Partition #] = $partition.Pf(OrderDate), 
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Production.Orders group by $partition.Pf(OrderDate)
   order by $partition.Pf(OrderDate)
select partition_number, rows from sys.partitions
   where object_id = object_id('Production.Orders')
go

alter partition function Pf() merge range('20020501')
alter partition scheme Ps next used FGroup4
alter partition function Pf() split range ('20020501')
alter partition function Pf() merge range('20020601')
alter partition scheme Ps next used FGroup5
alter partition function Pf() split range('20020601')
alter partition scheme Ps next used FGroup6
alter partition function Pf() split range ('20020701')
-- See how data is distributed
select * from dbo.vw_partitions
select [Partition #] = $partition.Pf(OrderDate), 
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Production.Orders group by $partition.Pf(OrderDate)
   order by $partition.Pf(OrderDate)
select partition_number, rows from sys.partitions
   where object_id = object_id('Production.Orders')
   order by partition_number
go
-- Let's insert the next month from AdventureWorks
declare @OrderDate1 datetime, @OrderDate2 datetime
select @OrderDate1 = dateadd(day, 1, max(OrderDate)) from Production.Orders
set @OrderDate2 = dateadd(day, -1, dateadd(month, 1, @OrderDate1))
insert Production.Orders select * from AdventureWorks.Sales.SalesOrderDetail
   where ModifiedDate between @OrderDate1 and @OrderDate2
go
--------------------------------------------------------------------------------------------------

alter partition function Pf() merge range ('20020301')

alter partition function Pf() merge range ('20020401')
alter partition scheme Ps next used FGroup2
alter partition function Pf() split range ('20020401')

alter partition function Pf() merge range ('20020501')
alter partition scheme Ps next used FGroup3
alter partition function Pf() split range ('20020501')

alter partition function Pf() merge range ('20020601')
alter partition scheme Ps next used FGroup4
alter partition function Pf() split range ('20020601')

alter partition function Pf() merge range ('20020701')
alter partition scheme Ps next used FGroup5
alter partition function Pf() split range ('20020701')

alter partition scheme Ps next used FGroup6
alter partition function Pf() split range ('20020801')
go
select * from dbo.vw_partitions
select [Partition #] = $partition.Pf(OrderDate), 
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Production.Orders group by $partition.Pf(OrderDate)
   order by $partition.Pf(OrderDate)
select partition_number, rows from sys.partitions
   where object_id = object_id('Production.Orders')
   order by partition_number
go
-- Let's insert the next month from AdventureWorks
declare @OrderDate1 datetime, @OrderDate2 datetime
select @OrderDate1 = dateadd(day, 1, max(OrderDate)) from Production.Orders
set @OrderDate2 = dateadd(day, -1, dateadd(month, 1, @OrderDate1))
insert Production.Orders select * from AdventureWorks.Sales.SalesOrderDetail
   where ModifiedDate between @OrderDate1 and @OrderDate2
go
--------------------------------------------------------------------------------------------------

alter partition function Pf() merge range ('20020401')

alter partition function Pf() merge range ('20020501')
alter partition scheme Ps next used FGroup2
alter partition function Pf() split range ('20020501')

alter partition function Pf() merge range ('20020601')
alter partition scheme Ps next used FGroup3
alter partition function Pf() split range ('20020601')

alter partition function Pf() merge range ('20020701')
alter partition scheme Ps next used FGroup4
alter partition function Pf() split range ('20020701')

alter partition function Pf() merge range ('20020801')
alter partition scheme Ps next used FGroup5
alter partition function Pf() split range ('20020801')

alter partition scheme Ps next used FGroup6
alter partition function Pf() split range ('20020901')
go
select * from dbo.vw_partitions
select [Partition #] = $partition.Pf(OrderDate), 
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Production.Orders group by $partition.Pf(OrderDate)
   order by $partition.Pf(OrderDate)
select partition_number, rows from sys.partitions
   where object_id = object_id('Production.Orders')
   order by partition_number
go
-- Let's insert the next month from AdventureWorks
declare @OrderDate1 datetime, @OrderDate2 datetime
select @OrderDate1 = dateadd(day, 1, max(OrderDate)) from Production.Orders
set @OrderDate2 = dateadd(day, -1, dateadd(month, 1, @OrderDate1))
insert Production.Orders select * from AdventureWorks.Sales.SalesOrderDetail
   where ModifiedDate between @OrderDate1 and @OrderDate2
go
--------------------------------------------------------------------------------------------------

alter partition function Pf() merge range ('20020501')

alter partition function Pf() merge range ('20020601')
alter partition scheme Ps next used FGroup2
alter partition function Pf() split range ('20020601')

alter partition function Pf() merge range ('20020701')
alter partition scheme Ps next used FGroup3
alter partition function Pf() split range ('20020701')

alter partition function Pf() merge range ('20020801')
alter partition scheme Ps next used FGroup4
alter partition function Pf() split range ('20020801')

alter partition function Pf() merge range ('20020901')
alter partition scheme Ps next used FGroup5
alter partition function Pf() split range ('20020901')

alter partition scheme Ps next used FGroup6
alter partition function Pf() split range ('20021001')
go
select * from dbo.vw_partitions
select [Partition #] = $partition.Pf(OrderDate), 
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Production.Orders group by $partition.Pf(OrderDate)
   order by $partition.Pf(OrderDate)
select partition_number, rows from sys.partitions
   where object_id = object_id('Production.Orders')
   order by partition_number
go
-- Let's insert the next month from AdventureWorks
declare @OrderDate1 datetime, @OrderDate2 datetime
select @OrderDate1 = dateadd(day, 1, max(OrderDate)) from Production.Orders
set @OrderDate2 = dateadd(day, -1, dateadd(month, 1, @OrderDate1))
insert Production.Orders select * from AdventureWorks.Sales.SalesOrderDetail
   where ModifiedDate between @OrderDate1 and @OrderDate2
go
--------------------------------------------------------------------------------------------------

alter partition function Pf() merge range ('20020601')

alter partition function Pf() merge range ('20020701')
alter partition scheme Ps next used FGroup2
alter partition function Pf() split range ('20020701')

alter partition function Pf() merge range ('20020801')
alter partition scheme Ps next used FGroup3
alter partition function Pf() split range ('20020801')

alter partition function Pf() merge range ('20020901')
alter partition scheme Ps next used FGroup4
alter partition function Pf() split range ('20020901')

alter partition function Pf() merge range ('20021001')
alter partition scheme Ps next used FGroup5
alter partition function Pf() split range ('20021001')

alter partition scheme Ps next used FGroup6
alter partition function Pf() split range ('20021101')
go
select * from dbo.vw_partitions
select [Partition #] = $partition.Pf(OrderDate), 
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Production.Orders group by $partition.Pf(OrderDate)
   order by $partition.Pf(OrderDate)
select partition_number, rows from sys.partitions
   where object_id = object_id('Production.Orders')
   order by partition_number
go
-- Let's insert the next month from AdventureWorks
declare @OrderDate1 datetime, @OrderDate2 datetime
select @OrderDate1 = dateadd(day, 1, max(OrderDate)) from Production.Orders
set @OrderDate2 = dateadd(day, -1, dateadd(month, 1, @OrderDate1))
insert Production.Orders select * from AdventureWorks.Sales.SalesOrderDetail
   where ModifiedDate between @OrderDate1 and @OrderDate2
go
--------------------------------------------------------------------------------------------------

alter partition function Pf() merge range ('20020701')

alter partition function Pf() merge range ('20020801')
alter partition scheme Ps next used FGroup2
alter partition function Pf() split range ('20020801')

alter partition function Pf() merge range ('20020901')
alter partition scheme Ps next used FGroup3
alter partition function Pf() split range ('20020901')

alter partition function Pf() merge range ('20021001')
alter partition scheme Ps next used FGroup4
alter partition function Pf() split range ('20021001')

alter partition function Pf() merge range ('20021101')
alter partition scheme Ps next used FGroup5
alter partition function Pf() split range ('20021101')

alter partition scheme Ps next used FGroup6
alter partition function Pf() split range ('20021201')
go
select * from dbo.vw_partitions
select [Partition #] = $partition.Pf(OrderDate), 
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Production.Orders group by $partition.Pf(OrderDate)
   order by $partition.Pf(OrderDate)
select partition_number, rows from sys.partitions
   where object_id = object_id('Production.Orders')
   order by partition_number
go
-- Let's insert the next month from AdventureWorks
declare @OrderDate1 datetime, @OrderDate2 datetime
select @OrderDate1 = dateadd(day, 1, max(OrderDate)) from Production.Orders
set @OrderDate2 = dateadd(day, -1, dateadd(month, 1, @OrderDate1))
insert Production.Orders select * from AdventureWorks.Sales.SalesOrderDetail
   where ModifiedDate between @OrderDate1 and @OrderDate2
go
--------------------------------------------------------------------------------------------------

alter partition function Pf() merge range ('20020801')

alter partition function Pf() merge range ('20020901')
alter partition scheme Ps next used FGroup2
alter partition function Pf() split range ('20020901')

alter partition function Pf() merge range ('20021001')
alter partition scheme Ps next used FGroup3
alter partition function Pf() split range ('20021001')

alter partition function Pf() merge range ('20021101')
alter partition scheme Ps next used FGroup4
alter partition function Pf() split range ('20021101')

alter partition function Pf() merge range ('20021201')
alter partition scheme Ps next used FGroup5
alter partition function Pf() split range ('20021201')

alter partition scheme Ps next used FGroup6
alter partition function Pf() split range ('20030101')
go
select * from dbo.vw_partitions
select [Partition #] = $partition.Pf(OrderDate), 
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Production.Orders group by $partition.Pf(OrderDate)
   order by $partition.Pf(OrderDate)
select partition_number, rows from sys.partitions
   where object_id = object_id('Production.Orders')
   order by partition_number
go
-- Let's insert the next month from AdventureWorks
declare @OrderDate1 datetime, @OrderDate2 datetime
select @OrderDate1 = dateadd(day, 1, max(OrderDate)) from Production.Orders
set @OrderDate2 = dateadd(day, -1, dateadd(month, 1, @OrderDate1))
insert Production.Orders select * from AdventureWorks.Sales.SalesOrderDetail
   where ModifiedDate between @OrderDate1 and @OrderDate2
go
--------------------------------------------------------------------------------------------------

alter partition function Pf() merge range ('20020901')

alter partition function Pf() merge range ('20021001')
alter partition scheme Ps next used FGroup2
alter partition function Pf() split range ('20021001')

alter partition function Pf() merge range ('20021101')
alter partition scheme Ps next used FGroup3
alter partition function Pf() split range ('20021101')

alter partition function Pf() merge range ('20021201')
alter partition scheme Ps next used FGroup4
alter partition function Pf() split range ('20021201')

alter partition function Pf() merge range ('20030101')
alter partition scheme Ps next used FGroup5
alter partition function Pf() split range ('20030101')

alter partition scheme Ps next used FGroup6
alter partition function Pf() split range ('20030201')
go
select * from dbo.vw_partitions
select [Partition #] = $partition.Pf(OrderDate), 
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Production.Orders group by $partition.Pf(OrderDate)
   order by $partition.Pf(OrderDate)
select partition_number, rows from sys.partitions
   where object_id = object_id('Production.Orders')
   order by partition_number
go
-- Let's insert the next month from AdventureWorks
declare @OrderDate1 datetime, @OrderDate2 datetime
select @OrderDate1 = dateadd(day, 1, max(OrderDate)) from Production.Orders
set @OrderDate2 = dateadd(day, -1, dateadd(month, 1, @OrderDate1))
insert Production.Orders select * from AdventureWorks.Sales.SalesOrderDetail
   where ModifiedDate between @OrderDate1 and @OrderDate2
go
--------------------------------------------------------------------------------------------------


alter partition function Pf() merge range ('20021001')

alter partition function Pf() merge range ('20021101')
alter partition scheme Ps next used FGroup2
alter partition function Pf() split range ('20021101')

alter partition function Pf() merge range ('20021201')
alter partition scheme Ps next used FGroup3
alter partition function Pf() split range ('20021201')

alter partition function Pf() merge range ('20030101')
alter partition scheme Ps next used FGroup4
alter partition function Pf() split range ('20030101')

alter partition function Pf() merge range ('20030201')
alter partition scheme Ps next used FGroup5
alter partition function Pf() split range ('20030201')

alter partition scheme Ps next used FGroup6
alter partition function Pf() split range ('20030301')
go
select * from dbo.vw_partitions
select [Partition #] = $partition.Pf(OrderDate), 
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Production.Orders group by $partition.Pf(OrderDate)
   order by $partition.Pf(OrderDate)
select partition_number, rows from sys.partitions
   where object_id = object_id('Production.Orders')
   order by partition_number
go
-- Let's insert the next month from AdventureWorks
declare @OrderDate1 datetime, @OrderDate2 datetime
select @OrderDate1 = dateadd(day, 1, max(OrderDate)) from Production.Orders
set @OrderDate2 = dateadd(day, -1, dateadd(month, 1, @OrderDate1))
insert Production.Orders select * from AdventureWorks.Sales.SalesOrderDetail
   where ModifiedDate between @OrderDate1 and @OrderDate2
go
--------------------------------------------------------------------------------------------------

alter partition function Pf() merge range ('20021101')

alter partition function Pf() merge range ('20021201')
alter partition scheme Ps next used FGroup2
alter partition function Pf() split range ('20021201')

alter partition function Pf() merge range ('20030101')
alter partition scheme Ps next used FGroup3
alter partition function Pf() split range ('20030101')

alter partition function Pf() merge range ('20030201')
alter partition scheme Ps next used FGroup4
alter partition function Pf() split range ('20030201')

alter partition function Pf() merge range ('20030301')
alter partition scheme Ps next used FGroup5
alter partition function Pf() split range ('20030301')

alter partition scheme Ps next used FGroup6
alter partition function Pf() split range ('20030401')
go
select * from dbo.vw_partitions
select [Partition #] = $partition.Pf(OrderDate), 
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Production.Orders group by $partition.Pf(OrderDate)
   order by $partition.Pf(OrderDate)
select partition_number, rows from sys.partitions
   where object_id = object_id('Production.Orders')
   order by partition_number
go
-- Let's insert the next month from AdventureWorks
declare @OrderDate1 datetime, @OrderDate2 datetime
select @OrderDate1 = dateadd(day, 1, max(OrderDate)) from Production.Orders
set @OrderDate2 = dateadd(day, -1, dateadd(month, 1, @OrderDate1))
insert Production.Orders select * from AdventureWorks.Sales.SalesOrderDetail
   where ModifiedDate between @OrderDate1 and @OrderDate2
go
--------------------------------------------------------------------------------------------------

alter partition function Pf() merge range ('20021201')

alter partition function Pf() merge range ('20030101')
alter partition scheme Ps next used FGroup2
alter partition function Pf() split range ('20030101')

alter partition function Pf() merge range ('20030201')
alter partition scheme Ps next used FGroup3
alter partition function Pf() split range ('20030201')

alter partition function Pf() merge range ('20030301')
alter partition scheme Ps next used FGroup4
alter partition function Pf() split range ('20030301')

alter partition function Pf() merge range ('20030401')
alter partition scheme Ps next used FGroup5
alter partition function Pf() split range ('20030401')

alter partition scheme Ps next used FGroup6
alter partition function Pf() split range ('20030501')
go
select * from dbo.vw_partitions
select [Partition #] = $partition.Pf(OrderDate), 
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Production.Orders group by $partition.Pf(OrderDate)
   order by $partition.Pf(OrderDate)
select partition_number, rows from sys.partitions
   where object_id = object_id('Production.Orders')
   order by partition_number
go
-- Let's insert the next month from AdventureWorks
declare @OrderDate1 datetime, @OrderDate2 datetime
select @OrderDate1 = dateadd(day, 1, max(OrderDate)) from Production.Orders
set @OrderDate2 = dateadd(day, -1, dateadd(month, 1, @OrderDate1))
insert Production.Orders select * from AdventureWorks.Sales.SalesOrderDetail
   where ModifiedDate between @OrderDate1 and @OrderDate2
go
--------------------------------------------------------------------------------------------------

alter partition function Pf() merge range ('20030101')

raiserror ('Move from FGroup1 to FGroup2', 0, 1)
alter partition function Pf() merge range ('20030201')
alter partition scheme Ps next used FGroup2
alter partition function Pf() split range ('20030201')

raiserror ('Move from FGroup2 to FGroup3', 0, 1)
alter partition function Pf() merge range ('20030301')
alter partition scheme Ps next used FGroup3
alter partition function Pf() split range ('20030301')

raiserror ('Move from FGroup3 to FGroup4', 0, 1)
alter partition function Pf() merge range ('20030401')
alter partition scheme Ps next used FGroup4
alter partition function Pf() split range ('20030401')

raiserror ('Move from FGroup4 to FGroup5', 0, 1)
alter partition function Pf() merge range ('20030501')
alter partition scheme Ps next used FGroup5
alter partition function Pf() split range ('20030501')

raiserror ('Move from FGroup5 to FGroup6', 0, 1)
alter partition scheme Ps next used FGroup6
alter partition function Pf() split range ('20030601')
go
select * from dbo.vw_partitions
select [Partition #] = $partition.Pf(OrderDate), 
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Production.Orders group by $partition.Pf(OrderDate)
   order by $partition.Pf(OrderDate)
select partition_number, rows from sys.partitions
   where object_id = object_id('Production.Orders')
   order by partition_number
go
-- Let's insert the next month from AdventureWorks
declare @OrderDate1 datetime, @OrderDate2 datetime
select @OrderDate1 = dateadd(day, 1, max(OrderDate)) from Production.Orders
set @OrderDate2 = dateadd(day, -1, dateadd(month, 1, @OrderDate1))
insert Production.Orders select * from AdventureWorks.Sales.SalesOrderDetail
   where ModifiedDate between @OrderDate1 and @OrderDate2
go
--------------------------------------------------------------------------------------------------
set statistics io on
go
alter partition function Pf() merge range ('20030201')

raiserror ('Move from FGroup1 to FGroup2', 0, 1)
alter partition function Pf() merge range ('20030301')
alter partition scheme Ps next used FGroup2
alter partition function Pf() split range ('20030301')

raiserror ('Move from FGroup2 to FGroup3', 0, 1)
alter partition function Pf() merge range ('20030401')
alter partition scheme Ps next used FGroup3
alter partition function Pf() split range ('20030401')

raiserror ('Move from FGroup3 to FGroup4', 0, 1)
alter partition function Pf() merge range ('20030501')
alter partition scheme Ps next used FGroup4
alter partition function Pf() split range ('20030501')

raiserror ('Move from FGroup4 to FGroup5', 0, 1)
alter partition function Pf() merge range ('20030601')
alter partition scheme Ps next used FGroup5
alter partition function Pf() split range ('20030601')

raiserror ('Move from FGroup5 to FGroup6', 0, 1)
alter partition scheme Ps next used FGroup6
alter partition function Pf() split range ('20030701')
go
set statistics io off
go
select * from dbo.vw_partitions
select [Partition #] = $partition.Pf(OrderDate), 
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Production.Orders group by $partition.Pf(OrderDate)
   order by $partition.Pf(OrderDate)
select partition_number, rows from sys.partitions
   where object_id = object_id('Production.Orders')
   order by partition_number
go
-- Let's insert the next month from AdventureWorks
declare @OrderDate1 datetime, @OrderDate2 datetime
select @OrderDate1 = dateadd(day, 1, max(OrderDate)) from Production.Orders
set @OrderDate2 = dateadd(day, -1, dateadd(month, 1, @OrderDate1))
insert Production.Orders select * from AdventureWorks.Sales.SalesOrderDetail
   where ModifiedDate between @OrderDate1 and @OrderDate2
go
--------------------------------------------------------------------------------------------------
set statistics io on
go
alter partition function Pf() merge range ('20030301')

raiserror ('Move from FGroup1 to FGroup2', 0, 1)
alter partition function Pf() merge range ('20030401')
alter partition scheme Ps next used FGroup2
alter partition function Pf() split range ('20030401')

raiserror ('Move from FGroup2 to FGroup3', 0, 1)
alter partition function Pf() merge range ('20030501')
alter partition scheme Ps next used FGroup3
alter partition function Pf() split range ('20030501')

raiserror ('Move from FGroup3 to FGroup4', 0, 1)
alter partition function Pf() merge range ('20030601')
alter partition scheme Ps next used FGroup4
alter partition function Pf() split range ('20030601')

raiserror ('Move from FGroup4 to FGroup5', 0, 1)
alter partition function Pf() merge range ('20030701')
alter partition scheme Ps next used FGroup5
alter partition function Pf() split range ('20030701')

raiserror ('Move from FGroup5 to FGroup6', 0, 1)
alter partition scheme Ps next used FGroup6
alter partition function Pf() split range ('20030801')
go
set statistics io off
go
select * from dbo.vw_partitions
select [Partition #] = $partition.Pf(OrderDate), 
   [Lowest Value] = min(OrderDate), [Highest Value] = max(OrderDate), [# of Records] = count(*)
   from Production.Orders group by $partition.Pf(OrderDate)
   order by $partition.Pf(OrderDate)
select partition_number, rows from sys.partitions
   where object_id = object_id('Production.Orders')
   order by partition_number
go
-- Let's insert the next month from AdventureWorks
declare @OrderDate1 datetime, @OrderDate2 datetime
select @OrderDate1 = dateadd(day, 1, max(OrderDate)) from Production.Orders
set @OrderDate2 = dateadd(day, -1, dateadd(month, 1, @OrderDate1))
insert Production.Orders select * from AdventureWorks.Sales.SalesOrderDetail
   where ModifiedDate between @OrderDate1 and @OrderDate2
go
--------------------------------------------------------------------------------------------------