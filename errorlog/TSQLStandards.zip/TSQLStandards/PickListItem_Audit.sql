CREATE TRIGGER PickListItem_Audit ON dbo.tblPickListItem
    FOR INSERT, UPDATE, DELETE 
     AS
--===== Presets
    Set Nocount On -- Prevents unexpected feedback to GUI's and increases speed a bit

--===== Declare local variables
Declare @TableName Varchar(50)
    Set @TableName = 'tblPickListItem'
Declare @KeyField Varchar(50)

Declare @Act Char(6)
Declare @Del Int
Declare @Ins Int
--Declare @HeaderID Int
Declare @ColumnsUpdated Varbinary(32) --1 byte for every 8 columns... 32 = 256 columns
Declare @Batch Binary(16)
    SET @Batch = NEWID()

Declare @RecordID Int
Declare @Counter Int
Declare @ColCount Int
Declare @RowNum Int
Declare @ColNum Int
Declare @ColName Varchar(50)
Declare @SQLString nVarchar(4000)
Declare @ParmDefinition nVarchar(4000)

--===== Create a table to hold the names of the columns affected by the query
 Create Table #ColNames
        (
        RowNum Int Primary Key Clustered,
        ColNum Int,
        ColName SysName --SysName is really NVarChar(128)
        )

--===== Determine what type of query fired the trigger and populate 
     -- temp tables for Inserted and Deleted records at the same time
 Select * Into #TempDeleted From Deleted
    Set @Del = Sign(@@Rowcount)

 Select * Into #TempInserted From Inserted
    Set @Ins = Sign(@@Rowcount)

 Select @Act = Case
                 When @Ins = 1 And @Del = 0 Then 'Insert'
                 When @Ins = 0 And @Del = 1 Then 'Delete'
                 Else 'Update'
               End

--===== Create the correct headers for all records at the same time
     -- and identify which columns to audit based on query type.
     -- Note that any given record will only be Inserted, Updated, or
     -- Deleted once per query, no matter what, so each RecordID in
     -- the trigger tables will be unique no matter what.  This totally
     -- eliminates the need for a cursor or a loop here... the Batch
     -- column is the key that will allow us to match the header and
     -- detail records.
     If @Act = 'Delete'
  Begin 
            --- Setup to handle up to 256 columns (one "FF" for every 8 columns)
            Set @ColumnsUpdated = 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

         Insert into AuditHeader
                (
                ChangeType,
                TableName,
                RecordID,
                Batch
                )
         Select  
                ChangeType = @ACT,
                TableName  = @TableName,
                RecordID   = intID,
                Batch      = @Batch
           From Deleted
    End
   Else --===== @Act is 'Update' or 'Insert'
  Begin 
            Set @ColumnsUpdated = Columns_Updated()

         Insert into AuditHeader
                (
                ChangeType,
                TableName,
                RecordID,
                Batch
                )
         Select  
                ChangeType = @ACT,
                TableName  = @TableName,
                RecordID   = intID,
                Batch      = @Batch
           From Inserted
    End

--===== At this point, we know enough to populate the col names table
     -- and capture the number of columns that were affected by the query
 Insert Into #ColNames 
        (RowNum,ColNum,ColName)
 Select RowNum, ColNum, ColName 
   From dbo.udf_auditColumnsUpdated(@TableName, @ColumnsUpdated)

    Set @ColCount = @@RowCount

--===== No matter what type of query fired the trigger, we're ready to rock
     -- for updating the Audit detail.  Because the dynamic SQL is so long,
     -- we still need to loop through for each column updated to make sure
     -- we don't run out of @SQLString variable space.  This should be a bit
     -- faster than a cursor.

    Set @Counter = 1 --Assuming that SOMETHING fired the trigger at this point
    Set @ParmDefinition = N'@Batch VarBinary(16)'

  While @Counter <= @ColCount
  Begin
         SELECT @SQLString = 
N'Insert into AuditDetail (AuditHeaderID, FieldChanged, OldValue, NewValue) 
Select h.AuditHeaderID,
       FieldChanged = ' + cn.ColName + ',
       OldValue = Left(Cast(d.'+ cn.ColName + ' as VarChar(8000)),4000),
       NewValue = Left(Cast(i.'+ cn.ColName + ' as VarChar(8000)),4000),
  From AuditHeader h
  Left Outer Join #TempDeleted  d On h.RecordID=d.intID
  Left Outer Join #TempInserted i On h.RecordID=i.intID
 Where h.Batch = @Batch'
           From #ColNames cn
          Where cn.RowNum = @Counter

        Execute sp_ExecuteSQL @SQLString, @ParmDefinition, @Batch = @Batch

    Set @Counter = @Counter + 1
    End

--===== Do a little housekeeping in case the same session fires the same trigger
   DROP TABLE #TempDeleted, #TempInserted, #ColNames