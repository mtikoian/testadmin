CREATE PROCEDURE p_FKRelationshipsFor 
@objectName SYSNAME=NULL
/*summary:   >

This procedure gives SQL Scripts to show sample (20 row)
results of the joins that can be made from
relationships defined in  all the foreign key constraints
associated with the table specified (all if no parameter give)

/* we would, of course, enshrine this in a procedure or function. Here is an example procedure that produces the SQL to then look at a sample of the result that would be created. Try it and see. It is quite handy.*/  
Author: Phil Factor
Revision: 
       � 1.1 added select statement to the ON clause
       � date: 20 sept 2010
Revision
       � 1.1 added facility to list everything
       � date: 21 sept 2010 
example:
     � code: p_FKRelationshipsFor 'HumanResources.Employee'
example:
     � code: p_FKRelationshipsFor 'Sales.SpecialOfferProduct'
example:
     � code: p_FKRelationshipsFor 'Production.ProductInventory'
example:
     � p_FKRelationshipsFor �do them all
Returns:   >
single column Varchar(MAX) result called 'Script'.

**/
AS
IF @objectName IS NOT NULL
  IF OBJECT_ID(@objectName) IS NULL 
    BEGIN
    RAISERROR(
      'Hmm. Couldn''t find ''%s''. Have you qualified it with the Schema name?',
      16,1,@ObjectName)
    RETURN 1
    END  

SELECT 'SELECT TOP 20 *
FROM '  
+ Object_Schema_name(fk.referenced_object_id) 
+ '.' +OBJECT_NAME(fk.referenced_object_id)
+ '
  INNER JOIN '
+ Object_Schema_name(fk.parent_object_id) 
+ '.' +OBJECT_NAME(fk.parent_object_id)+'
    ON '+
SUBSTRING(
     (SELECT ' AND ' + Object_Schema_name(fk.Parent_object_ID)
           + '.' + OBJECT_NAME(fk.Parent_object_ID) + '.' + cr.name + ' = ' 
           + OBJECT_NAME(fkc.referenced_object_id) + '.' + c.NAME
      FROM    sys.foreign_Key_columns fkc
              INNER JOIN sys.columns c 
                  ON fkc.referenced_column_id = c.column_id 
                     AND fkc.referenced_object_id = c.OBJECT_ID
              INNER JOIN sys.columns cr 
                  ON fkc.parent_column_id = cr.column_id 
                     AND fkc.parent_object_id = cr.OBJECT_ID
      WHERE   fkc.constraint_object_id = fk.OBJECT_ID
      FOR XML PATH('')
     ), 5, 2000) + CHAR(13)+CHAR(10)+'  � ' + fk.name AS script
FROM sys.foreign_keys fk
WHERE fk.referenced_object_ID
     = COALESCE(OBJECT_ID(@objectName),fk.referenced_object_ID)
  OR fk.parent_object_id
     = COALESCE(OBJECT_ID(@objectName),fk.parent_object_ID) 
GO

