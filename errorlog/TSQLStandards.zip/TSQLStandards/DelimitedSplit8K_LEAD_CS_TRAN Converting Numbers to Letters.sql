CREATE FUNCTION dbo.DelimitedSplit8K_LEAD_CS_TRAN (
--===== Define I/O parameters
    @pString VARCHAR(8000),
    @pDelimiter1 CHAR(1) = ',',
    @pDelimiter2 CHAR(1) = ';'
)
RETURNS TABLE WITH SCHEMABINDING AS
RETURN
--===== "Inline" CTE Driven "Tally Table� produces values from 0 up to 10,000...
   -- enough to cover VARCHAR(8000)
WITH ALPHA AS (
    -- Create the value list in table form to translate directly in the function
    SELECT KEY_VALUE, THE_CHAR
    FROM (
        VALUES    ('1', 'A'),
                ('2', 'B'),
                ('3', 'C'),
                ('4', 'D'),
                ('5', 'E'),
                ('6', 'F'),
                ('7', 'G'),
                ('8', 'H'),
                ('9', 'I'),
                ('10', 'J'),
                ('11', 'K'),
                ('12', 'L'),
                ('13', 'M'),
                ('14', 'N'),
                ('15', 'O'),
                ('16', 'P'),
                ('17', 'Q'),
                ('18', 'R'),
                ('19', 'S'),
                ('20', 'T'),
                ('21', 'U'),
                ('22', 'V'),
                ('23', 'W'),
                ('24', 'X'),
                ('25', 'Y'),
                ('26', 'Z')
        ) AS X (KEY_VALUE, THE_CHAR)
),
    E1(N) AS (

        SELECT 1 UNION ALL SELECT 1 UNION ALL SELECT 1 UNION ALL
        SELECT 1 UNION ALL SELECT 1 UNION ALL SELECT 1 UNION ALL
        SELECT 1 UNION ALL SELECT 1 UNION ALL SELECT 1 UNION ALL SELECT 1
),                        --10E+1 or 10 rows
    E2(N) AS (

        SELECT 1
        FROM E1 a, E1 b
),                        --10E+2 or 100 rows
    E4(N) AS (

        SELECT 1
        FROM E2 a, E2 b
),                        --10E+4 or 10,000 rows max
    cteTally AS (
        --==== This provides the "zero base" and limits the number of rows right up front
        -- for both a performance gain and prevention of accidental "overruns"
        SELECT 0 AS N
        UNION ALL
        SELECT TOP (DATALENGTH(ISNULL(@pString,1))) ROW_NUMBER() OVER (ORDER BY (SELECT NULL))
        FROM E4
),
    cteStart AS (
        --==== This returns N+1 (starting position of each "element" just once for each delimiter)
        SELECT t.N+1 AS N1, D.Delimiter
        FROM cteTally t
            LEFT OUTER JOIN (SELECT @pDelimiter1 AS Delimiter UNION ALL SELECT @pDelimiter2) AS D
                ON SUBSTRING(@pString,t.N,1) = D.Delimiter
        WHERE D.Delimiter IS NOT NULL
            OR t.N = 0
),
    THE_SPLIT AS (
        --===== Do the actual split. The ISNULL/NULLIF combo handles the length for the final element when no delimiter is found.
        SELECT ItemNumber = ROW_NUMBER() OVER(ORDER BY s.N1),
            Item = SUBSTRING(@pString,s.N1,ISNULL(NULLIF((LEAD(s.N1,1,1) OVER (ORDER BY s.N1) - 1),0)-s.N1,8000)),
            s.Delimiter
        FROM cteStart s
)
SELECT S.ItemNumber, A.THE_CHAR, S.Delimiter, S.Item
FROM THE_SPLIT AS S
    LEFT OUTER JOIN ALPHA AS A
        ON S.Item = A.KEY_VALUE;

GO


--testing


DECLARE @Keys TABLE
(
  ID INT IDENTITY(1,1)
  ,[Keys] VARCHAR(50)
)

INSERT INTO @Keys([Keys])
SELECT '5;7,3'
UNION ALL SELECT '15'
UNION ALL SELECT '7;8'
UNION ALL SELECT '4;6'
UNION ALL SELECT '4;7'
UNION ALL SELECT '1;2;3'
UNION ALL SELECT '2,3,4'
UNION ALL SELECT '2;4'
UNION ALL SELECT '2;3'
UNION ALL SELECT '3;2'
UNION ALL SELECT '26'
UNION ALL SELECT '2'
UNION ALL SELECT '6';

WITH ALL_DATA AS (

    SELECT K.ID, K.Keys, S.Item, S.ItemNumber, S.Delimiter, S.THE_CHAR
    FROM @Keys AS K
        CROSS APPLY dbo.DelimitedSplit8K_LEAD_CS_TRAN (K.Keys, ',', ';') AS S
)
SELECT D.ID, D.Keys,
    (
    SELECT AD.THE_CHAR + LEAD(Delimiter, 1, '') OVER(PARTITION BY AD.ID ORDER BY AD.ItemNumber)
    FROM ALL_DATA AS AD
    WHERE AD.ID = D.ID
    FOR XML PATH('')
    ) AS KeyString
FROM ALL_DATA AS D
GROUP BY D.ID, D.Keys
ORDER BY D.ID;