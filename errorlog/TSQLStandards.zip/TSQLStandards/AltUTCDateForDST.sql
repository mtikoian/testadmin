 CREATE FUNCTION dbo.AltUTCDateForDST
        (@UTCDateTime DATETIME)
RETURNS DATETIME
     AS
  BEGIN
        DECLARE @DstStartYr DATETIME
        DECLARE @DstEndYr   DATETIME
            SET @DstStartYr = '04/01/'+STR(YEAR(@SomeUTCDateTime),4)
            SET @DstEndYr   = '11/01/'+STR(YEAR(@SomeUTCDateTime),4) --Trust me on the 11/01 thing
        
         SELECT @UTCDateTime = DATEADD(hh,1,@SomeUTCDateTime)
          WHERE @UTCDateTime 
                BETWEEN (15-@@DATEFIRST-DATEPART(dw,@DstStartYr))%7 + @DstStartYr+'02:00'
                    AND (15-@@DATEFIRST-DATEPART(dw,@DstEndYr  ))%7 + @DstEndYr  +'02:00'-7
 RETURN @UTCDateTime
    END



--	create function dbo.UTCtoLOCALtime
--       (
--              @UTCDateTime DATETIME
--       ) RETURNS DATETIME
--AS
--       BEGIN
--              DECLARE @DstStartYr DATETIME
--              DECLARE @DstEndYr DATETIME
--              DECLARE @Offset INT
--              DECLARE @DST BIT
--              DECLARE @TimeStart DATETIME
--              DECLARE @TimeEnd DATETIME
--              -- Retrieve location timezone configuration parameters from database
-- table tblRefTimeZone (two columns)
--              --            DST (bit) = does location observe Daylight Saving Time
--              --            Offset (int) = time offset from UTC to location time zone
--              SELECT TOP 1 @DST = DST, @Offset = Offset FROM tblRefTimeZone
--              -- If the location does not observe Daylight Saving Time, 
--then adjust for time zone only
--              IF ((@DST = 0) or (@DST is null))
--                     RETURN DATEADD(hh,@Offset,@UTCDateTime)
 
--              -- Set UTC start & end times so that they equates to the start of Daylight 
--Saving Time in the respective time zone
--              SET @TimeStart = CAST('02:00:00' as datetime)
--              SET @TimeStart = DATEADD(hh,abs(@Offset),@TimeStart)
--              SET @TimeEnd = CAST('01:59:59' as datetime)
--              SET @TimeEnd = DATEADD(hh,abs(@Offset),@TimeEnd)
             
--              -- Determine DST Start and End Date
--              IF year(@UTCDateTime) < 2007
--              -- Prior to 2007, DST starts on first Sunday in April and ends on last sunday in October
--              BEGIN
--                     SET @DstStartYr = '04/01/'+ STR (YEAR(@UTCDateTime),4)
--                     SET    @DstEndYr = '11/01/'+ STR (YEAR(@UTCDateTime),4)
--                     SELECT @UTCDateTime = DATEADD(hh,1,@UTCDateTime) WHERE @UTCDateTime
--Between (15 - @@DATEFIRST - DATEPART(dw,@DstStartYr)) % 7 + @DstStartYr + @TimeStart And
--                                  (15 - @@DATEFIRST - DATEPART(dw,@DstEndYr)) % 7 + @DstEndYr + @TimeEnd - 7
--              END
--              ELSE
--              -- Starting in 2007, DST starts on second Sunday in March and ends on first sunday in November
--              BEGIN
--                     SET @DstStartYr = '03/01/'+ STR (YEAR(@UTCDateTime),4)
--                     SET    @DstEndYr = '11/01/'+ STR (YEAR(@UTCDateTime),4)
--                     SELECT @UTCDateTime = DATEADD(hh,1,@UTCDateTime) WHERE @UTCDateTime
--                                  Between (15 - @@DATEFIRST - DATEPART(dw,@DstStartYr)) % 7 + @DstStartYr + @TimeStart + 7  And
--                                  (15 - @@DATEFIRST - DATEPART(dw,@DstEndYr)) % 7 + @DstEndYr + @TimeEnd
--              END
--              -- Adjust time for the location timezone and return value
--              RETURN DATEADD(hh,@Offset,@UTCDateTime)
--       END
 