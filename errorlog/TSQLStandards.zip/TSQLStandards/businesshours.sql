--===== Declare some obviously named variables
DECLARE @StartDateTime  DATETIME,
        @EndDateTime    DATETIME,
        @WorkTimeStart1 DATETIME,
        @WorkTimeEnd1   DATETIME,
        @WorkTimeStart2 DATETIME,
        @WorkTimeEnd2   DATETIME,
        @BinSize        INT,
        @Saturday       INT, --Datepart(dw) for Saturday regardless of DATEFIRST
        @Sunday         INT  --Datepart(dw) for Sunday regardless of DATEFIRST
;
--===== Preset the variables
 SELECT @StartDateTime  = '2007-11-16 15:30', --Likely parameter in function
        @EndDateTime    = '2007-11-20 14:00', --Could be parameter in function
        @WorkTimeStart1 = '07:30',            --Could be parameter in function
        @WorkTimeEnd1   = '11:30',            --Could be parameter in function
        @WorkTimeStart2 = '12:00',            --Could be parameter in function
        @WorkTimeEnd2   = '16:00',            --Could be parameter in function
        @BinSize        = 15,                 --Minutes, Could be parameter in function
        @Saturday       = DATEPART(dw,5),     --First Saturday of 1900
        @Sunday         = DATEPART(dw,6)      --First Sunday of 1900
;
--===== Using the start and end time, calculate the number of business hours
     -- between those two date/times.
WITH 
cteTimeSlots AS
(--==== Produces a list of datetime slots in @BinSize minute intervals
 SELECT DATEADD(mi,(t.n-1)*@BinSize,@StartDateTime) AS TimeSlot
   FROM dbo.Tally t
  WHERE t.N <= DATEDIFF(mi,@StartDateTime,@EndDateTime)/@BinSize
)
,
cteDates AS
(--==== Separates the Time as a separate column and removes weekends
 SELECT ts.TimeSlot,
        Date = DATEADD(dd,DATEDIFF(dd,0,ts.TimeSlot),0),
        Time = ts.TimeSlot - DATEADD(dd,DATEDIFF(dd,0,ts.TimeSlot),0)
   FROM cteTimeSlots ts
  WHERE DATEPART(dw,ts.TimeSlot) NOT IN (@Saturday,@Sunday)
)
--===== Counts time slots within the workday and converts to
     -- decimal hours.  To exclude dates from a Holiday table,
     -- uncomment the last line and modify as necessary.
 SELECT COUNT(*)*@BinSize/60.0
   FROM cteDates d
  WHERE (
        (d.Time >= @WorkTimeStart1 AND d.Time < @WorkTimeEnd1)
        OR
        (d.Time >= @WorkTimeStart2 AND d.Time < @WorkTimeEnd2)
        )
--    AND NOT EXISTS (SELECT 1 FROM dbo.Holiday h WHERE d.Date = h.Date)