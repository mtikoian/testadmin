IF OBJECT_ID(N'dbo.ITVF_IP_NUMERICAL') IS NOT NULL DROP FUNCTION dbo.ITVF_IP_NUMERICAL;

EXEC (N'CREATE FUNCTION dbo.ITVF_IP_NUMERICAL
(
    @IPADDR VARCHAR(15) 
)
RETURNS TABLE
RETURN
/*
    ITVF_IP_NUMERICAL
    Converting an character representation of an IP address into
    an integer and masking A,B,C classes

    2015-04-26 Eirikur Eiriksson
*/
WITH IP_ADDRESS_DELIM AS
(
    SELECT
        CHARINDEX(CHAR(46),@IPADDR,1)                                                                  AS POS_01
       ,CHARINDEX(CHAR(46),@IPADDR,CHARINDEX(CHAR(46),@IPADDR,1) + 1)                                  AS POS_02
       ,CHARINDEX(CHAR(46),@IPADDR,CHARINDEX(CHAR(46),@IPADDR,CHARINDEX(CHAR(46),@IPADDR,1) + 1) + 1)  AS POS_03
       ,LEN(@IPADDR)                                                                                   AS POS_04
)
,NUMERICAL_IP AS
(
    SELECT
        CONVERT(INT,
          CONVERT(BINARY(1),CONVERT(TINYINT,SUBSTRING(@IPADDR,IAD.POS_03 + 1,(IAD.POS_04 -IAD.POS_03)   ),0),1)
        + CONVERT(BINARY(1),CONVERT(TINYINT,SUBSTRING(@IPADDR,IAD.POS_02 + 1,(IAD.POS_03 -IAD.POS_02) -1),0),1)
        + CONVERT(BINARY(1),CONVERT(TINYINT,SUBSTRING(@IPADDR,IAD.POS_01 + 1,(IAD.POS_02 -IAD.POS_01) -1),0),1)
        + CONVERT(BINARY(1),CONVERT(TINYINT,SUBSTRING(@IPADDR,1,IAD.POS_01 -1)                           ,0),1)
        ) AS IP_INT
    FROM    IP_ADDRESS_DELIM    IAD
)
SELECT
    NI.IP_INT & 0xFF        AS IP_AX
   ,NI.IP_INT & 0xFFFF      AS IP_BX
   ,NI.IP_INT & 0xFFFFFF    AS IP_CX
   ,NI.IP_INT               AS IP_DX
FROM NUMERICAL_IP   NI;
');

DECLARE @IP_LIST TABLE (IP_ID INT IDENTITY(1,1) NOT NULL,IPADDR VARCHAR(15) NOT NULL);
INSERT INTO @IP_LIST(IPADDR)
VALUES
 ('192.168.25.2')
,('192.168.25.22')
,('192.168.25.222')
,('192.168.25.2')
,('192.168.26.2')
,('192.168.27.2')
,('192.168.25.2')
,('192.169.25.2')
,('192.167.25.2')
,('192.168.25.2')
,('193.168.25.2')
,('194.168.25.2')
;

SELECT
    IL.IP_ID
   ,IL.IPADDR
   ,X.IP_AX
   ,X.IP_BX
   ,X.IP_CX
   ,X.IP_DX
FROM @IP_LIST   IL
CROSS APPLY dbo.ITVF_IP_NUMERICAL(IL.IPADDR) AS X;
