CREATE PROCEDURE dbo.EmployeesHoursWorked
/********************************************************************************************************************** 
 Purpose:
 Given any, all, or no parameters, return a report of hours worked by EmployeeID.
 Usage Examples:
--===== Full Syntax 
   EXEC dbo.EmployeesHoursWorked @Week, @HubCode, @MinHoursWorked
;
--===== No parameters. Same as 'All' for @week and @HubCode, 0 for @MinHoursWorked
   EXEC dbo.EmployeesHoursWorked
;
--===== Specified Week and HubCode. 
   EXEC dbo.EmployeesHoursWorked '17-2006','BLND'
;
--===== Specified HubCode only for all weeks
   EXEC dbo.EmployeesHoursWorked @HubCode = 'BLND'
;

 Revision History
 Rev 00 - 26 Feb 2017 - Jeff Moden
        - Initial creation and unit test.
**********************************************************************************************************************/
         @Week              VARCHAR(7)  = NULL --'ALL' or wk-yyyy or w-yyyy. 
        ,@HubCode           CHAR(4)     = NULL --'ALL' or some valid HubCode. Changed to same datatype as in table.
        ,@MinHoursWorked    NUMERIC(6,2)= NULL --Changed to same datatype as in table
     AS
--===== Default the variables to wide-open if they're NULL
 SELECT  @Week              = ISNULL(@Week,'All')
        ,@HubCode           = ISNULL(@HubCode,'All')
        ,@MinHoursWorked    = ISNULL(@MinHoursWorked,0)
;
--===== Define variables the dynamic SQL and two conditional pieces of the dynamic SQL.
DECLARE  @SQL       NVARCHAR(4000)
        ,@WeekJoin  NVARCHAR(4000)
        ,@WHERE     NVARCHAR(4000)
;
--===== Based on the content of the parameters, figure out what the dynamic pieces should be.
     -- Note that there is no contatenation of strings from the outside world so this is completely safe from SQL Injection.
     -- http://sqlinthewild.co.za/index.php/2009/03/19/catch-all-queries/
 SELECT @WeekJoin = CASE 
                    WHEN @Week = N'ALL' 
                    THEN N'' 
                    ELSE N'   JOIN dbo.WeekBoundaryDates(@Week) wkbd ON t.WorkDate >= wkbd.WeekStartDate and t.WorkDate < wkbd.CutoffDate'
                    END
        ,@WHERE   = CASE 
                    WHEN @HubCode = N'All'
                    THEN N''
                    ELSE N'  WHERE h.HubCode = @HubCode'
                    END
        ,@SQL = REPLACE(REPLACE(REPLACE('
 SELECT  e.EmployeeNumber
        ,e.FirstName
        ,e.LastName
        ,h.HubCode
        ,[Week] = RIGHT(100+DATENAME(wk,t.WorkDate),2)+"-"+DATENAME(yy,t.WorkDate)
        ,HoursWorked = SUM(t.HoursWorked)
   FROM dbo.TimeEntry   t
   JOIN dbo.Assignment  a   ON t.AssignmentID   = a.AssignmentID
   JOIN dbo.Employee    e   ON a.EmployeeNumber = e.EmployeeNumber
   JOIN dbo.Hub         h   ON a.HubCode        = h.HubCode
<<@WeekJoin>>
<<@WHERE>>
  GROUP BY   e.EmployeeNumber
            ,e.FirstName
            ,e.LastName
            ,h.HubCode
            ,RIGHT(100+DATENAME(wk,t.WorkDate),2)+"-"+DATENAME(yy,t.WorkDate)
 HAVING SUM(HoursWorked) >= @MinHoursWorked
  ORDER BY e.EmployeeNumber;'
                ,'"'            ,'''') --The next 3 lines are the other end of the REPLACEs
                ,'<<@WeekJoin>>',@WeekJoin)
                ,'<<@WHERE>>'   ,@WHERE)
;
--===== We're ready to rock. Let's see the dynamic SQL and then execute it.
  PRINT @SQL;
   EXEC sp_executesql 
             @SQL
            ,N'@Week VARCHAR(7), @HubCode CHAR(4), @MinHoursWorked NUMERIC(6,2)' --Variables in dynamic SQL
            ,@Week,@HubCode,@MinHoursWorked --One for one values for variables in dynamic SQL
;
GO