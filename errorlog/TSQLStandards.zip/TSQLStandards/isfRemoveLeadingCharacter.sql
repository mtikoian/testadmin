
--===== This is like the RemoveLeftCharPatIndex funtion except it's an "Inline Scalar Function".
 CREATE FUNCTION dbo.isfRemoveLeadingCharacter
        (
        @SomeString VARCHAR(8000),
        @RemoveChar CHAR(1)
        )
RETURNS TABLE WITH SCHEMABINDING AS
 RETURN SELECT CleanString = SUBSTRING(@SomeString,PATINDEX('%[^'+@RemoveChar+']%',@SomeString),8000)
;
GO
--=======================================================================================
--      Conditionally drop and rebuild the test data.
--=======================================================================================
--===== Conditionally drop the test table to make reruns in SSMS easier.
     IF OBJECT_ID('tempdb..#TestTable') IS NOT NULL
        DROP TABLE #TestTable
;
--===== Create and populate the test with 1,000,000 rows of test data
 SELECT TOP 1000000
        SomeString = REPLICATE('0',ABS(CHECKSUM(NEWID()))%5) -- 0 to 4 leading zeros
      + 'temp'+RIGHT('0000000'+CAST(ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS VARCHAR(10)),7)
   INTO #TestTable
   FROM sys.all_columns ac1
  CROSS JOIN sys.all_columns ac2
;
--=======================================================================================
--      Run the tests using a duration timer because SET STATISTICS TIME ON induces
--      large delay times because of the RBAR nature of Scalar UDFs.
--=======================================================================================
--===== Declare some obviously named variables. 
DECLARE @BitBucket  VARCHAR(8000),
        @StartTime  DATETIME,
        @DurationMS INT
;
--===== Run the tests on each function
        RAISERROR('=======================================',0,1) WITH NOWAIT;
        RAISERROR('============ Running Tests ============',0,1) WITH NOWAIT;
        RAISERROR('=======================================',0,1) WITH NOWAIT;
     -- Note that @BitBucket allows us to take display and disk time out of the equation.
-----------------------------------------------------------------------------------------
 SELECT @StartTime = GETDATE();
        RAISERROR('============ PatIndex Version',0,1) WITH NOWAIT;
 SELECT @BitBucket = dbo.RemoveLeftCharPatIndex(SomeString, '0')
   FROM #TestTable;
 SELECT @DurationMS = DATEDIFF(ms,@StartTime,GETDATE())
        RAISERROR('Duration ms: %u',0,1,@DurationMS) WITH NOWAIT;
-----------------------------------------------------------------------------------------
 SELECT @StartTime = GETDATE();
        RAISERROR('============ TrimReplace Version',0,1) WITH NOWAIT;
 SELECT @BitBucket = dbo.RemoveLeftCharTrimReplace(SomeString, '0')
   FROM #TestTable;
 SELECT @DurationMS = DATEDIFF(ms,@StartTime,GETDATE())
        RAISERROR('Duration ms: %u',0,1,@DurationMS) WITH NOWAIT;
-----------------------------------------------------------------------------------------
 SELECT @StartTime = GETDATE();
        RAISERROR('============ isf Substring/PatIndex',0,1) WITH NOWAIT;
 SELECT @BitBucket = ca.CleanString
   FROM #TestTable tt
  CROSS APPLY dbo.isfRemoveLeadingCharacter(tt.SomeString,'0') ca;
 SELECT @DurationMS = DATEDIFF(ms,@StartTime,GETDATE())
        RAISERROR('Duration ms: %u',0,1,@DurationMS) WITH NOWAIT;
-----------------------------------------------------------------------------------------
        RAISERROR('======================================',0,1) WITH NOWAIT;
        RAISERROR('============ RUN COMPLETE ============',0,1) WITH NOWAIT;
        RAISERROR('======================================',0,1) WITH NOWAIT;
