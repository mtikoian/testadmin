USE [Test]
GO
/****** Object:  Table [dbo].[NYSEHolidays]    Script Date: 12/10/2008 17:48:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[NYSEHolidays]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[NYSEHolidays](
	[Holiday] [smalldatetime] NOT NULL
) ON [PRIMARY]
END
GO

/****** Object:  Index [IX_NYSE]    Script Date: 12/10/2008 17:48:26 ******/
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[NYSEHolidays]') AND name = N'IX_NYSE')
CREATE UNIQUE NONCLUSTERED INDEX [IX_NYSE] ON [dbo].[NYSEHolidays] 
(
	[Holiday] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO
IF NOT EXISTS (SELECT * FROM ::fn_listextendedproperty(N'MS_Description' , N'SCHEMA',N'dbo', N'TABLE',N'NYSEHolidays', N'COLUMN',N'Holiday'))
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Includes all NYSE holidays' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'NYSEHolidays', @level2type=N'COLUMN',@level2name=N'Holiday'
GO
/****** Object:  UserDefinedFunction [dbo].[fn_PriorDay]    Script Date: 12/10/2008 17:48:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[fn_PriorDay]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[fn_PriorDay](@date SMALLDATETIME)
RETURNS SMALLDATETIME
AS
BEGIN  
DECLARE
@AdjStart DATETIME, 
@IntDays INT

SET @AdjStart=CONVERT(DATETIME, FLOOR(CONVERT(FLOAT, @date)))

-- Calculates 
SET @IntDays=1

SET @IntDays=@IntDays+
        (CASE WHEN DATEPART(dw, @AdjStart-@IntDays)%6=1 THEN 1 ELSE 0 END)

   WHILE EXISTS (SELECT holiday FROM NYSEholidays WHERE holiday = (@adjStart-@IntDays))
      BEGIN
         SET @IntDays = @IntDays + 1 
      END
      
  RETURN DATEADD(hh, 16, DATEADD(dd, -@IntDays, @AdjStart))
END 

' 
END