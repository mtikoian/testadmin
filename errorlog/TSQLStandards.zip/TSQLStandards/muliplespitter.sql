--=================================================================================================
--      Test table setup.  This is NOT a part of the solution.
--=================================================================================================
--===== Conditionally drop the test table to make reruns easier
     IF OBJECT_ID('TempDB..#YourTable','U') IS NOT NULL 
        DROP TABLE #YourTable
;
GO
--===== Create the test table
 CREATE TABLE #YourTable
        (
        Date NCHAR(10)            NOT NULL,
        Time NCHAR(8)             NOT NULL,
        CsuriQuery NVARCHAR(2000) NOT NULL
        )
;
--===== Populate the test table with test data
 INSERT INTO #YourTable
        (Date, Time, CsuriQuery)
 SELECT '2010-04-08','00:00:02','Cmd=Ping&User=User1_ID&DeviceId=PALM24854ace5ac4e080c918b7213ce4&DeviceType=Palm&Log=V121_LdapC1_LdapL0_RpcC29_RpcL36_Hb1740_Rto1_S1_' UNION ALL
 SELECT '2010-04-08','00:00:03','User=User2_ID&DeviceId=Appl84930CUZ3NP&DeviceType=iPhone&Cmd=Ping&Log=V121_Sst20_LdapC0_LdapL0_RpcC57_RpcL63_Hb975_Rto1_Erq1_Pk4026417530_S1_' UNION ALL
 SELECT '2010-04-08','00:00:04','NewParameter=Whatever&User=User2_ID&DeviceId=Appl84930CUZ3NP&DeviceType=iPhone&Cmd=Ping&Log=V121_Sst20_LdapC0_LdapL0_RpcC57_RpcL63_Hb975_Rto1_Erq1_Pk4026417530_S1_'
;
--=================================================================================================
--      Split the parameter names and values into an "NVP" (Name/Value Pair) table.
--      Yes... it's denormalized but it will "auto-magically" capture new/additional parameters
--      without any changes to the code as it does for line "3" in the test data above.
--=================================================================================================
--===== Finish the split at the "=" sign to put the ParameterName and PrameterValue in separate
     -- columns.
 SELECT yt1.Date,
        yt1.Time,
        SUBSTRING(ca.Item, 1, CHARINDEX(N'=',ca.Item)-1)    AS ParameterName,
        SUBSTRING(ca.Item, CHARINDEX(N'=',ca.Item)+1, 4000) AS ParameterValue
   FROM #YourTable yt1
  CROSS APPLY
        (--==== This does the main split returning parameter names and values separated by "="
         SELECT yt2.Item
           FROM dbo.f_DelimitedSplit8K(yt1.CsuriQuery, N'&') yt2
        ) ca
  ORDER BY yt1.Date, yt1.Time, ParameterName
  
  
  --=================================================================================================
--      Test table setup.  This is NOT a part of the solution. (Same as previous example)
--=================================================================================================
--===== Conditionally drop the test table to make reruns easier
     IF OBJECT_ID('TempDB..#YourTable','U') IS NOT NULL 
        DROP TABLE #YourTable
;
GO
--===== Create the test table
 CREATE TABLE #YourTable
        (
        Date NCHAR(10)            NOT NULL,
        Time NCHAR(8)             NOT NULL,
        CsuriQuery NVARCHAR(2000) NOT NULL
        )
;
--===== Populate the test table with test data
 INSERT INTO #YourTable
        (Date, Time, CsuriQuery)
 SELECT '2010-04-08','00:00:02','Cmd=Ping&User=User1_ID&DeviceId=PALM24854ace5ac4e080c918b7213ce4&DeviceType=Palm&Log=V121_LdapC1_LdapL0_RpcC29_RpcL36_Hb1740_Rto1_S1_' UNION ALL
 SELECT '2010-04-08','00:00:03','User=User2_ID&DeviceId=Appl84930CUZ3NP&DeviceType=iPhone&Cmd=Ping&Log=V121_Sst20_LdapC0_LdapL0_RpcC57_RpcL63_Hb975_Rto1_Erq1_Pk4026417530_S1_' UNION ALL
 SELECT '2010-04-08','00:00:04','NewParameter=Whatever&User=User2_ID&DeviceId=Appl84930CUZ3NP&DeviceType=iPhone&Cmd=Ping&Log=V121_Sst20_LdapC0_LdapL0_RpcC57_RpcL63_Hb975_Rto1_Erq1_Pk4026417530_S1_'
;
--=================================================================================================
--      Split the parameter names and values into an "NVP" (Name/Value Pair) table.
--      Yes... it's denormalized but it will "auto-magically" capture new/additional parameters
--      without any changes to the code as it does for line "3" in the test data above.
--      Changed the SELECT to a CTE so we can use it to drive the Cross-Tab.
--=================================================================================================
WITH
cteSplit AS
( --=== Finish the split at the "=" sign to put the ParameterName and PrameterValue in separate
     -- columns.
 SELECT yt1.Date,
        yt1.Time,
        SUBSTRING(ca.Item, 1, CHARINDEX(N'=',ca.Item)-1)    AS ParameterName,
        SUBSTRING(ca.Item, CHARINDEX(N'=',ca.Item)+1, 4000) AS ParameterValue
   FROM #YourTable yt1
  CROSS APPLY
        (--==== This does the main split returning parameter names and values separated by "="
         SELECT yt2.Item
           FROM dbo.DelimitedSplit8K(yt1.CsuriQuery, N'&') yt2
        ) ca
)
 SELECT Date,
        Time,
        MAX(CASE WHEN ParameterName = 'Cmd'          THEN ParameterValue END) AS Cmd,
        MAX(CASE WHEN ParameterName = 'DeviceId'     THEN ParameterValue END) AS DeviceId,
        MAX(CASE WHEN ParameterName = 'DeviceType'   THEN ParameterValue END) AS DeviceType,
        MAX(CASE WHEN ParameterName = 'Log'          THEN ParameterValue END) AS [Log],
        MAX(CASE WHEN ParameterName = 'User'         THEN ParameterValue END) AS [User],
        MAX(CASE WHEN ParameterName = 'NewParameter' THEN ParameterValue END) AS NewParameter
   FROM cteSplit
  GROUP BY Date, Time
  ORDER BY Date, Time


 SELECT @StartDate = CAST('2007' AS DATETIME),
        @EndDate = DATEADD(yy,1,CAST('2007' AS DATETIME))

 SELECT yada-yada
   FROM sometable
  WHERE somedatecolumn >= @StartDate
    AND someDateColumn <  @EndDate
    
    

IF OBJECT_ID('dbo.fn_split') IS NOT NULL
DROP FUNCTION dbo.fn_split;
GO
CREATE FUNCTION dbo.fn_split(@arr AS NVARCHAR(MAX), @sep AS NCHAR(1))
RETURNS TABLE
AS
RETURN
WITH 
   L0 AS (SELECT 1 AS C UNION ALL SELECT 1)       --2 rows
  ,L1 AS (SELECT 1 AS C FROM L0 AS A, L0 AS B)    --4 rows (2x2)
  ,L2 AS (SELECT 1 AS C FROM L1 AS A, L1 AS B)    --16 rows (4x4)
  ,L3 AS (SELECT 1 AS C FROM L2 AS A, L2 AS B)    --256 rows (16x16)
  ,L4 AS (SELECT 1 AS C FROM L3 AS A, L3 AS B)    --65536 rows (256x256)
  ,L5 AS (SELECT 1 AS C FROM L4 AS A, L4 AS B)    --4,294,967,296 rows (65536x65536)
  ,Numbers AS (SELECT row_number() OVER (ORDER BY (SELECT 0)) AS N FROM L5)  
SELECT
(n - 1) - LEN(REPLACE(LEFT(@arr, n-1), @sep, N'')) + 1 AS pos,
LTRIM(SUBSTRING(@arr, n, CHARINDEX(@sep, @arr + @sep, n) - n)) AS element
FROM Numbers
WHERE n <= LEN(@arr) + 1
AND SUBSTRING(@sep + @arr, n, 1) = @sep
AND Numbers.n <= 1000 -- make sure to change to an appropriate value
GO

DECLARE @var VARCHAR(MAX)
SET @var ='1,a,b,20080101|2,c,d,20080102|3,e,f,20080102'

SELECT 
	PARSENAME(REPLACE(element,',','.'),4) AS Col1,
	PARSENAME(REPLACE(element,',','.'),3) AS Col2,
	PARSENAME(REPLACE(element,',','.'),2) AS Col3,
	PARSENAME(REPLACE(element,',','.'),1) AS Col4
FROM dbo.fn_split(@var,'|')



IF NOT OBJECT_ID('tempdb.dbo.#Hold', 'U') IS NULL DROP TABLE #Hold
CREATE TABLE #Hold (BulkColumn VARCHAR(MAX))
GO

DECLARE @a VARCHAR(MAX) = '1,a,b,20080101|2,c,d,20080102|3,e,f,20080102|4,g,h,20080101|5,i,j,20080102|6,k,l,20080102|7,m,n,20080101|8,o,p,20080102|9,q,r,20080102|10,s,t,20080101|11,u,v,20080102|12,w,x,20080102'
INSERT #Hold SELECT @a
GO 100

SELECT a1, a2, a3, a4 FROM #Hold
CROSS APPLY
(
  SELECT 
    LEFT(SplitColumn, CHARINDEX(',', SplitColumn) - 1),
    SUBSTRING(SplitColumn, CHARINDEX(',', SplitColumn) + 1, CHARINDEX(',', SplitColumn, CHARINDEX(',', SplitColumn) + 1) - CHARINDEX(',', SplitColumn) - 1),
    REVERSE(SUBSTRING(REVERSE(SplitColumn), CHARINDEX(',', REVERSE(SplitColumn)) + 1, CHARINDEX(',', REVERSE(SplitColumn), CHARINDEX(',', REVERSE(SplitColumn)) + 1) - CHARINDEX(',', REVERSE(SplitColumn)) - 1)),
    REVERSE(LEFT(REVERSE(SplitColumn), CHARINDEX(',', REVERSE(SplitColumn)) - 1))
  FROM ( 
         SELECT SUBSTRING(BulkColumn + '|', N, CHARINDEX('|', BulkColumn + '|', N) - N)
         FROM master.dbo.tally 
         WHERE N < LEN(BulkColumn) + 2 AND SUBSTRING('|' + BulkColumn + '|', N, 1) = '|'
       ) AS X (SplitColumn)
) AS Y (a1, a2, a3, a4)



--Create temp holding of the first split by ;
select * into #temp1 from dbo.delimitedsplit8k ('Param1=3;param2=4;param4=testval;param6=11',';')
--Create temp holiding of the second split by =
select t1.ItemNumber as t1ItemNumber, t1.item as t1item, spl.ItemNumber, spl.item into #temp2 from #temp1 t1 cross apply dbo.delimitedsplit8k (t1.item,'=') spl

--Dynamic Pivot
DECLARE @columns NVARCHAR(MAX), @sql NVARCHAR(MAX);
SET @columns = N'';
SELECT @columns += N', p.' + QUOTENAME(item)
  FROM (SELECT item FROM #temp2 WHERE itemnumber = 1) AS x; --Second Split Output, value 1 for everything before the =
SET @sql = N'
SELECT ' + STUFF(@columns, 1, 2, '') + '
FROM
(
select
t1.item,
t2.item as itemvalue
from
(select	item, t1itemnumber from #temp2 where itemnumber = 1) as t1
join
(select item, t1itemnumber from #temp2 where itemnumber = 2) as t2
on t1.t1itemnumber = t2.t1itemnumber
) AS j
PIVOT
(
  MAX(itemvalue) FOR item IN ('
  + STUFF(REPLACE(@columns, ', p.[', ',['), 1, 1, '')
  + ')
) AS p;';
PRINT @sql;
EXEC sp_executesql @sql;
drop table #temp1, #temp2;




DECLARE @StartTime DATETIME 
DECLARE @Item VARCHAR(20) = ''

SET @StartTime = GETDATE()
SELECT @Item = @Item + ','+d2.Item 
FROM dbo.DelimitedSplit8K_LEAD ('Param1=3;param2=4;param4=testval;param6=11',';') d1
CROSS APPLY dbo.DelimitedSplit8K_LEAD (d1.Item, '=') d2
WHERE d2.ItemNumber = 2
ORDER BY d1.ItemNumber
SELECT DATEDIFF(MILLISECOND, @StartTime, GETDATE())

SELECT STUFF(@Item,1,1,'')

SET @StartTime = GETDATE()
SELECT 
	REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(
	'Param1=3;param2=4;param4=testval;param6=11',
	'Param',''),'1=',''),'2=',''),'3=',''),'4=',''),'5=',''),'6=',''),'7=',''),'8=',''),'9=',''),'10=',''),';',',')
SELECT DATEDIFF(MILLISECOND, @StartTime, GETDATE())



DECLARE @p                      VARCHAR(MAX);
declare @TargetTable table (
    URL varchar(128),
    Title varchar(128),
    Display varchar(128)
);

SET @p = 'url1|title1|display1,url2|title2|display2,url3|title3|display3,';

set nocount on;

with FirstParse as (
select
    ItemNumber,
    Item
from
    dbo.f_DelimitedSplit8K(@p,',')
), SecondParse as (
select
    fp.ItemNumber fpItemID,
    sp.ItemNumber spItemID,
    sp.Item
from
    FirstParse fp
    cross apply dbo.f_DelimitedSplit8K(fp.Item,'|') sp
), ParsedData as (
select
    max(case spItemID when 1 then Item else '' end) as URL,
    max(case spItemID when 2 then Item else '' end) as Title,
    max(case spItemID when 3 then Item else '' end) as Display
from
    SecondParse
group by
    fpItemID
)
insert into @TargetTable(URL,Title,Display)
select
    URL,
    Title,
    Display
from
    ParsedData
;

select * from @TargetTable;

set nocount off;

create table W
(
ID int,
acc_no varchar(5),
val varchar(255)
)

insert into W 
select 100,'a1','D,20987987.5%,,A account is being linked to B account'
union all
select 100,'a2','D,20987987.5%,,A account is being linked to B account'
union all
select 100,'b1','R,2.5%,,A account is being linked to B account'
union all
select 100,'b2','R,2.5%,,A account is being linked to B account'
union all
select 100,'b3','R,25%,,A account is being linked to B account'
union all
select 100,'c1','X,25%,,A account is being linked to B account'
union all
select 100,'c2','X,25%,,A account is being linked to B account'

drop table #t

SELECT IDENTITY(int,0,1) idn, --LOOK
       0 AS RN,  
       ID,
       acc_no,  
       val       = SUBSTRING(val, t.N, CHARINDEX(',', val+ ',', t.N) - t.N)  
INTO #t        
FROM W cross join dbo.Tally  t  
WHERE t.N <= DATALENGTH(val)+1  
    AND SUBSTRING(',' + val, t.N, 1) = ',' 
ORDER BY ID,acc_no, N 

SELECT * FROM #T
-- Better trick will turn all sequential numbers to 0,1,2,3         
UPDATE #t SET RN =  idn % 4 --LOOK
--final qry 
select  ID ,acc_no
       ,max(case when rn = 0 then val else null end) as colA  
       ,max(case when rn = 1 then val else null end) as colB  
       ,max(case when rn = 2 then val else null end) as colC  
       ,max(case when rn = 3 then val else null end) as colD  
from #t  
group by ID,acc_no 
order by ID,acc_no

-- remove non-numeric and put data back
declare @test table (RowID INT IDENTITY, Col1 varchar(50))
insert into @test
SELECT '**44-14**' UNION ALL
SELECT '**44-87**' UNION ALL
SELECT '**4284**' UNION ALL
SELECT ',**59-70**�' UNION ALL
SELECT '**442-05** ' UNION ALL
SELECT '**53-55**' UNION ALL
SELECT '**267-59**''' UNION ALL
SELECT '**48-73**' UNION ALL
SELECT '**344-97**''' UNION ALL
SELECT '�**4503**' UNION ALL
SELECT '**222-98** ''' UNION ALL
SELECT ''', **56-34**��,' UNION ALL
SELECT '**144-94**' UNION ALL
SELECT '**55-51**' UNION ALL
SELECT ',**52-53**' UNION ALL
SELECT '**97-40**' UNION ALL
SELECT '**75-55**' UNION ALL
SELECT 'k*44-03**' UNION ALL
SELECT '**55-95**' UNION ALL
SELECT '**64-04**' 

-- See Jeff Moden's article The "Numbers" or "Tally" Table: What it is and how it replaces a loop.
-- at http://www.sqlservercentral.com/articles/T-SQL/62867/.
;WITH 
Tally    (N) AS (SELECT TOP 100 ROW_NUMBER() OVER (ORDER BY (SELECT 0)) FROM master.sys.columns sc1),
CTE AS (
-- get the values that are numbers, or match other desired characters.
-- this breaks each character down into a separate row
SELECT t.RowID, 
       t.Col1,
       Tally.N, 
       Value = SUBSTRING(Col1,Tally.N,1)
  FROM @test t
       CROSS JOIN Tally 
 WHERE Tally.N <= LEN(t.Col1)
   AND (ASCII(SUBSTRING(t.Col1,Tally.N,1)) between 48 and 57
        OR SUBSTRING(t.Col1,Tally.N,1) IN ('.','-'))
)
-- put everything left back together
SELECT DISTINCT 
       RowID, 
       Original_value = Col1,
       Value = REPLACE((SELECT ',' + Value FROM CTE WHERE RowID = c.RowID ORDER BY N FOR XML PATH('')),',','')
  FROM CTE c
 ORDER BY RowID
 
 
 WITH Names (Name) AS (
    SELECT 'MOUSE, MICKEY X' UNION ALL SELECT 'MOUSE, MICKEY')
SELECT STUFF((
    SELECT ' ' + Item
    FROM dbo.PatternSplitCM(Name, '[A-Z]')
    WHERE [Matched]=1 AND ItemNumber IN (1,3)
    ORDER BY ItemNumber DESC
    FOR XML PATH('')), 1, 1, '')
FROM Names

declare @Name varchar(50) = 'MOUSE, MICKEY X'

SELECT Item as FirstName, Left(@Name, CHARINDEX(',', @Name) - 1) as LastName
from dbo.DelimitedSplit8K(LTRIM(RIGHT(@Name, CHARINDEX(',', REVERSE(@Name)) - 1 )), ' ')
where ItemNumber = 1
--
declare @parameter varchar (200)
set  @parameter ='1_2_3|4_5'

SELECT ss=isnull(MAX(CASE c.itemnumber WHEN 1 THEN c.item END), 0)
    ,col=isnull(MAX(CASE c.itemnumber WHEN 2 THEN c.item END), 0)
    ,col1=isnull(MAX(CASE c.itemnumber WHEN 3 THEN c.item END), 0)
FROM (SELECT @parameter) a(parameter)
CROSS APPLY dbo.DelimitedSplit8k(parameter, '|') b
CROSS APPLY dbo.DelimitedSplit8k(item, '_') c
GROUP BY b.ItemNumber
--
DECLARE @str VARCHAR(1000) = 'AAAAAA,BBBBBBBB,CCCCCCCCCC'

--Return as three separate values (you can set three separate variables here)
SELECT   PARSENAME(S,3) Val1
        ,PARSENAME(S,2) Val2
        ,PARSENAME(S,1) Val3
FROM (SELECT REPLACE(@str,',','.')) S(S)

--Return as table (you can join to it, just wrap it inn CLR or use it as subquery))
SELECT      PARSENAME(S,I)  Val
FROM (SELECT REPLACE(@str,',','.')) S(S)
CROSS JOIN (VALUES (1),(2),(3)) I(I)
ORDER BY I DESC