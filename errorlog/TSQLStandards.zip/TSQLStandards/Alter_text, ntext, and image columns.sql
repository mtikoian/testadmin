/* TABLES */
/* text -> varchar(max) */
SELECT  'ALTER TABLE ' + OBJECT_NAME(o.object_id) + ' ALTER COLUMN ' + c.name
        + ' VARCHAR(MAX) ' + CASE WHEN c.is_nullable = 0 THEN 'NOT NULL'
                                  ELSE 'NULL'
                             END
FROM    sys.objects o
        INNER JOIN sys.columns c ON o.object_id = c.object_id
        INNER JOIN sys.types t ON c.system_type_id = t.system_type_id
WHERE   o.type = 'U' AND t.name = 'text'
ORDER BY OBJECT_NAME(o.object_id)

/* ntext -> nvarchar(max) */
SELECT  'ALTER TABLE ' + OBJECT_NAME(o.object_id) + ' ALTER COLUMN ' + c.name
        + ' NVARCHAR(MAX) ' + CASE WHEN c.is_nullable = 0 THEN 'NOT NULL'
                                  ELSE 'NULL'
                             END
FROM    sys.objects o
        INNER JOIN sys.columns c ON o.object_id = c.object_id
        INNER JOIN sys.types t ON c.system_type_id = t.system_type_id
WHERE   o.type = 'U' AND t.name = 'ntext'
ORDER BY OBJECT_NAME(o.object_id)

/* image -> varbinary(max) */
SELECT  'ALTER TABLE ' + OBJECT_NAME(o.object_id) + ' ALTER COLUMN ' + c.name
        + ' VARBINARY(MAX) ' + CASE WHEN c.is_nullable = 0 THEN 'NOT NULL'
                                  ELSE 'NULL'
                             END
FROM    sys.objects o
        INNER JOIN sys.columns c ON o.object_id = c.object_id
        INNER JOIN sys.types t ON c.system_type_id = t.system_type_id
WHERE   o.type = 'U' AND t.name = 'image'
ORDER BY OBJECT_NAME(o.object_id)