CREATE FUNCTION fnDeleteNumbers (@String VARCHAR(8000))
RETURNS VARCHAR(8000)
     AS
  BEGIN
        DECLARE @Return VARCHAR(8000)
            SET @Return = ''
        
         SELECT @Return = @Return+SUBSTRING(@String,N,1)
           FROM dbo.Tally WITH (NOLOCK)
          WHERE N <= LEN(@String)
            AND SUBSTRING(@String,N,1) LIKE '%[^0-9]%' 

 RETURN @Return
END

--SELECT @T = dbo.fnDeleteNumbers(GID)
--   FROM TblTest WHERE CAST(GID AS VARCHAR(100)) BETWEEN 'A' AND 'D'