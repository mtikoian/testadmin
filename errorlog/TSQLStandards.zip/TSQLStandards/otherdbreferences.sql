SELECT p.name,
       sed.referenced_database_name,
       sed.referenced_schema_name,
       sed.referenced_entity_name
FROM   sys.procedures p
       INNER JOIN 
       sys.sql_expression_dependencies sed ON p.object_id = sed.referencing_id
WHERE  sed.referenced_database_name IS NOT NULL
;
