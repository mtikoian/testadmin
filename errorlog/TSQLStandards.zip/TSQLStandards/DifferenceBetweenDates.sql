CREATE FUNCTION dbo.DifferenceBetweenDates
/**********************************************************************************************************************
 Purpose:
 Given two dates/times in the correct left to right order, return a formatted period represented by the two dates in 
 the form of #d hh:mi:ss (or -#d hh:mi:ss) to a max of 18 characters where "#" will be some value from -2958463 thru 
 2958463, which is only 1 day short of a day-span of 10,000 years. 
-----------------------------------------------------------------------------------------------------------------------
 Usage Examples:
--===== Basic Syntax for Single Period
 SELECT Span FROM dbo.DifferenceBetweenDates(@StartDT,@EndDT)
;
--===== Basic Syntax for Multiple Rows from a Table.
 SELECT  ca.Span
        ,st.SomeColumns
   FROM dbo.SomeTable st
  CROSS APPLY dbo.DifferenceBetweenDates(st.StartDT,st.EndDT) ca
;
-----------------------------------------------------------------------------------------------------------------------
 Developer notes:
 1. This is a high performance iTVF (inline Table Valued Function), which executes about 7 times faster than the 
    equivalent Scalar function.  Please see the following URL for more information on this subject.
    http://www.sqlservercentral.com/articles/T-SQL/91724/
 2. Note that the maximum span that can be returned by this function is 1 second less than 10,000 years of days 
    or 2958463d 23:59:59 (when @StartDate <= @EndDate) or -2958463d 23:59:59 (when @StartDate > @EndDate).

 3. RETURN type is VARCHAR(18)

 4. This function works in all versions of SQL Server from 2000 to current.
-----------------------------------------------------------------------------------------------------------------------
 Revision History:
 Rev 00 - 22 Dec 2017 - Jeff Moden
        - Inital creation and unit test.
        - Ref: https://www.sqlservercentral.com/Forums/FindPost1913258.aspx
**********************************************************************************************************************/
--===== Define the I/O for this function
        (
         @StartDT DATETIME
        ,@EndDT   DATETIME
        )
RETURNS TABLE WITH SCHEMABINDING AS
 RETURN
--===== Calculate format, and return the period as a "single cell" table depending on the direction of the inputs.
 SELECT Span =  CASE 
                WHEN @StartDT <= @EndDT
                THEN CONVERT(VARCHAR(8), DATEDIFF(dd,0,@EndDT-@StartDT)) +'d ' + CONVERT(CHAR(8),@EndDT-@StartDT,108)
                ELSE CONVERT(VARCHAR(8),-DATEDIFF(dd,0,@StartDT-@EndDT)) +'d ' + CONVERT(CHAR(8),@StartDT-@EndDT,108)
                END
;
GO