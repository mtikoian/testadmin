USE [master]

/****** Object:  Database [Games]    Script Date: 06/14/2010 09:53:28 ******/
IF NOT EXISTS (SELECT name FROM sys.databases WHERE name = N'Games')
BEGIN
CREATE DATABASE [Games] ON  PRIMARY 
( NAME = N'Games', FILENAME = N'c:\Program Files\Microsoft SQL Server\MSSQL.1\MSSQL\DATA\Games.mdf' , SIZE = 3072KB , MAXSIZE = UNLIMITED, FILEGROWTH = 1024KB )
 LOG ON 
( NAME = N'Games_log', FILENAME = N'c:\Program Files\Microsoft SQL Server\MSSQL.1\MSSQL\DATA\Games_log.ldf' , SIZE = 1024KB , MAXSIZE = 2048GB , FILEGROWTH = 10%)
END

EXEC dbo.sp_dbcmptlevel @dbname=N'Games', @new_cmptlevel=90

IF (1 = FULLTEXTSERVICEPROPERTY('IsFullTextInstalled'))
begin
EXEC [Games].[dbo].[sp_fulltext_database] @action = 'enable'
end

ALTER DATABASE [Games] SET ANSI_NULL_DEFAULT OFF

ALTER DATABASE [Games] SET ANSI_NULLS OFF

ALTER DATABASE [Games] SET ANSI_PADDING OFF

ALTER DATABASE [Games] SET ANSI_WARNINGS OFF

ALTER DATABASE [Games] SET ARITHABORT OFF

ALTER DATABASE [Games] SET AUTO_CLOSE OFF

ALTER DATABASE [Games] SET AUTO_CREATE_STATISTICS ON

ALTER DATABASE [Games] SET AUTO_SHRINK OFF

ALTER DATABASE [Games] SET AUTO_UPDATE_STATISTICS ON

ALTER DATABASE [Games] SET CURSOR_CLOSE_ON_COMMIT OFF

ALTER DATABASE [Games] SET CURSOR_DEFAULT  GLOBAL

ALTER DATABASE [Games] SET CONCAT_NULL_YIELDS_NULL OFF

ALTER DATABASE [Games] SET NUMERIC_ROUNDABORT OFF

ALTER DATABASE [Games] SET QUOTED_IDENTIFIER OFF

ALTER DATABASE [Games] SET RECURSIVE_TRIGGERS OFF

ALTER DATABASE [Games] SET  DISABLE_BROKER

ALTER DATABASE [Games] SET AUTO_UPDATE_STATISTICS_ASYNC OFF

ALTER DATABASE [Games] SET DATE_CORRELATION_OPTIMIZATION OFF

ALTER DATABASE [Games] SET TRUSTWORTHY OFF

ALTER DATABASE [Games] SET ALLOW_SNAPSHOT_ISOLATION OFF

ALTER DATABASE [Games] SET PARAMETERIZATION SIMPLE

ALTER DATABASE [Games] SET  READ_WRITE

ALTER DATABASE [Games] SET RECOVERY SIMPLE

ALTER DATABASE [Games] SET  MULTI_USER

ALTER DATABASE [Games] SET PAGE_VERIFY CHECKSUM

ALTER DATABASE [Games] SET DB_CHAINING OFF

USE [Games]

/****** Object:  User [NITESH-PC\NITESH]    Script Date: 06/14/2010 09:53:28 ******/
IF NOT EXISTS (SELECT * FROM sys.database_principals WHERE name = N'NITESH-PC\NITESH')
CREATE USER [NITESH-PC\NITESH] FOR LOGIN [NITESH-PC\NITESH] WITH DEFAULT_SCHEMA=[dbo]

/****** Object:  Table [dbo].[Accounts]    Script Date: 06/14/2010 09:53:28 ******/
SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Accounts]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[Accounts](
	[AccountID] [bigint] IDENTITY(1,1) NOT NULL,
	[AccountType] [bigint] NULL,
	[PeopleID] [bigint] NULL,
 CONSTRAINT [PK_Accounts] PRIMARY KEY CLUSTERED 
(
	[AccountID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END

/****** Object:  Table [dbo].[AccountsType]    Script Date: 06/14/2010 09:53:28 ******/
SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

SET ANSI_PADDING ON

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[AccountsType]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[AccountsType](
	[AccountTypeID] [bigint] IDENTITY(1,1) NOT NULL,
	[Catery] [varchar](150) NULL,
 CONSTRAINT [PK_AccountsType] PRIMARY KEY CLUSTERED 
(
	[AccountTypeID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END

SET ANSI_PADDING OFF

/****** Object:  Table [dbo].[TransactionType]    Script Date: 06/14/2010 09:53:28 ******/
SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

SET ANSI_PADDING ON

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TransactionType]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[TransactionType](
	[TransactionTypeID] [bigint] IDENTITY(1,1) NOT NULL,
	[Description] [varchar](50) NULL,
	[Action] [varchar](2) NULL,
	[TranType] [int] NULL,
	[CanShow] [bit] NULL CONSTRAINT [DF_TransactionType_CanShow]  DEFAULT ((1)),
 CONSTRAINT [PK_TransactionType] PRIMARY KEY CLUSTERED 
(
	[TransactionTypeID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END

SET ANSI_PADDING OFF

/****** Object:  Table [dbo].[GameSheet]    Script Date: 06/14/2010 09:53:28 ******/
SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GameSheet]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[GameSheet](
	[GameSheetID] [bigint] IDENTITY(1,1) NOT NULL,
	[SheetDate] [datetime] NULL,
	[ClassID] [bigint] NULL,
	[GameYear] [int] NULL,
	[WeekNo] [int] NULL,
	[Complete] [bit] NULL CONSTRAINT [DF_GameSheet_Complete]  DEFAULT ((0)),
 CONSTRAINT [PK_GameSheet] PRIMARY KEY CLUSTERED 
(
	[GameSheetID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END

/****** Object:  Table [dbo].[GamesheetTX]    Script Date: 06/14/2010 09:53:28 ******/
SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GamesheetTX]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[GamesheetTX](
	[ID] [bigint] IDENTITY(1,1) NOT NULL,
	[GameSheetID] [bigint] NULL,
	[PeopleID] [bigint] NULL,
	[JobID] [bigint] NULL,
	[Day1] [bit] NULL,
	[Day2] [bit] NULL,
	[Day3] [bit] NULL,
	[Day4] [bit] NULL,
	[Day5] [bit] NULL,
	[Total] [decimal](18, 0) NULL,
	[Active] [bit] NULL CONSTRAINT [DF_GamesheetTX_Active]  DEFAULT ((1)),
 CONSTRAINT [PK_GamesheetTX] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END

/****** Object:  Table [dbo].[Users]    Script Date: 06/14/2010 09:53:28 ******/
SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

SET ANSI_PADDING ON

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Users]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[Users](
	[UserID] [bigint] IDENTITY(1,1) NOT NULL,
	[UserName] [varchar](150) NULL,
	[Password] [varchar](50) NULL,
	[Active] [bit] NULL,
	[UserLevel] [int] NULL,
 CONSTRAINT [PK_Users] PRIMARY KEY CLUSTERED 
(
	[UserID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END

SET ANSI_PADDING OFF

/****** Object:  UserDefinedFunction [dbo].[Balancer]    Script Date: 06/14/2010 09:53:29 ******/
SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Balancer]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE FUNCTION [dbo].[Balancer] 
(	
	@Name VARCHAR(100), 
	@Date DATETIME,
	@PeopleId int
)
RETURNS TABLE 
AS
RETURN 
(
	SELECT V.PEOPLEID, max(datepart(ww, transactiondate)) as Date, 
	@NAME Name, SUM(V.TRANSACTIONAMT) AS BALANCE,
	case when @NAME = ''Opening Balance'' THEN 1 ELSE 3 end orderer
	from V_ACCOUNT_BALANCE V 
	WHERE V.TRANSACTIONDATE < @DATE and V.PEOPLEID = @PEOPLEID
	group by V.PEOPLEID

	union select @PeopleId, max(datepart(ww, @Date)) as Date, @NAME Name,
	0, case when @NAME = ''Opening Balance'' THEN 0 ELSE 4 end
)
' 
END

/****** Object:  Table [dbo].[settings]    Script Date: 06/14/2010 09:53:28 ******/
SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

SET ANSI_PADDING ON

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[settings]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[settings](
	[ID] [bigint] IDENTITY(1,1) NOT NULL,
	[Description] [varchar](150) NULL,
	[Value] [varchar](150) NULL,
 CONSTRAINT [PK_settings] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END

SET ANSI_PADDING OFF

/****** Object:  Table [dbo].[Grade]    Script Date: 06/14/2010 09:53:28 ******/
SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

SET ANSI_PADDING ON

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Grade]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[Grade](
	[GradeID] [bigint] IDENTITY(1,1) NOT NULL,
	[Description] [varchar](50) NULL,
	[Active] [bit] NULL CONSTRAINT [DF_Grade_Active]  DEFAULT ((1)),
 CONSTRAINT [PK_Grade] PRIMARY KEY CLUSTERED 
(
	[GradeID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END

SET ANSI_PADDING OFF

/****** Object:  Table [dbo].[Transactions]    Script Date: 06/14/2010 09:53:28 ******/
SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

SET ANSI_PADDING ON

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Transactions]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[Transactions](
	[TransactionID] [bigint] IDENTITY(1,1) NOT NULL,
	[AccountID] [bigint] NULL,
	[TransactionType] [int] NULL,
	[TransactionDate] [datetime] NULL,
	[TransactionAmt] [decimal](18, 0) NULL,
	[GamesheetID] [bigint] NULL,
	[CustomDescription] [varchar](150) NULL,
	[Active] [bit] NULL CONSTRAINT [DF_Transactions_Active]  DEFAULT ((1)),
	[ShowInReport] [bit] NULL CONSTRAINT [DF_Transactions_ShowInReport]  DEFAULT ((1)),
	[ChequeDescription] [varchar](200) NULL,
 CONSTRAINT [PK_Transactions] PRIMARY KEY CLUSTERED 
(
	[TransactionID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END

SET ANSI_PADDING OFF

/****** Object:  UserDefinedFunction [dbo].[CommaSeperator]    Script Date: 06/14/2010 09:53:29 ******/
SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CommaSeperator]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE FUNCTION [dbo].[CommaSeperator] 
(
	-- Add the parameters for the function here
	@Param_Ids varchar(500)
)
RETURNS @Id_Table TABLE(IDField int)
AS
BEGIN
	IF (LEN(@Param_Ids) <= 0)       
RETURN   
DECLARE @CommaPos smallint   
SET @CommaPos = CHARINDEX('','', RTRIM(LTRIM(@Param_Ids)))	     
IF @CommaPos = 0       
INSERT INTO @Id_Table               
VALUES(CONVERT(BIGINT ,RTRIM(LTRIM(@Param_Ids))))   
ELSE        
BEGIN           
WHILE LEN(@Param_Ids) > 1	   
BEGIN	     
SET @CommaPos = CHARINDEX('','', RTRIM(LTRIM(@Param_Ids)))             
INSERT INTO @Id_Table                       
VALUES(CONVERT(INT ,SUBSTRING(RTRIM(LTRIM(@Param_Ids)),1, @CommaPos - 1)))	     
SET @Param_Ids = SUBSTRING(RTRIM(LTRIM(@Param_Ids)), @CommaPos + 1 , LEN(RTRIM(LTRIM(@Param_Ids))))	     
SET @CommaPos = CHARINDEX('','', RTRIM(LTRIM(@Param_Ids)))	     
IF @CommaPos = 0	    
 BEGIN                 
INSERT INTO @Id_Table VALUES(CONVERT(INT ,RTRIM(LTRIM(@Param_Ids))))                 
BREAK	     
END	   
END       
END       
RETURN 
END
' 
END

/****** Object:  Table [dbo].[Jobs]    Script Date: 06/14/2010 09:53:28 ******/
SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

SET ANSI_PADDING ON

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Jobs]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[Jobs](
	[JobID] [bigint] IDENTITY(1,1) NOT NULL,
	[Description] [varchar](150) NULL,
	[Wage] [decimal](18, 0) NULL,
	[Active] [smallint] NULL,
	[sortorder] [int] NULL,
	[isDefault] [bit] NULL CONSTRAINT [DF_Jobs_isDefault]  DEFAULT ((0))
) ON [PRIMARY]
END

SET ANSI_PADDING OFF

/****** Object:  Table [dbo].[people]    Script Date: 06/14/2010 09:53:28 ******/
SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

SET ANSI_PADDING ON

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[people]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[people](
	[peopleID] [bigint] IDENTITY(1,1) NOT NULL,
	[Surname] [varchar](200) NULL,
	[Firstname] [varchar](200) NULL,
	[ClassID] [bigint] NULL,
 CONSTRAINT [PK_people] PRIMARY KEY CLUSTERED 
(
	[peopleID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END

SET ANSI_PADDING OFF

/****** Object:  Table [dbo].[Classes]    Script Date: 06/14/2010 09:53:28 ******/
SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

SET ANSI_PADDING ON

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Classes]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[Classes](
	[ClassID] [bigint] IDENTITY(1,1) NOT NULL,
	[Description] [varchar](50) NULL,
	[Active] [tinyint] NULL CONSTRAINT [DF_Classes_Active]  DEFAULT ((1)),
	[GradeID] [bigint] NULL,
 CONSTRAINT [PK_Classes] PRIMARY KEY CLUSTERED 
(
	[ClassID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END

SET ANSI_PADDING OFF

/****** Object:  StoredProcedure [dbo].[proc_ShowAllBalances]    Script Date: 06/14/2010 09:53:29 ******/
SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_ShowAllBalances]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[proc_ShowAllBalances]
	@accountId VARCHAR(MAX),
	@peopleId INT,  
	@startDate DateTime,
	@endDate DateTime

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

   SET DATEFORMAT YMD

	Declare @balanceAtStartDate Decimal, @runningBalance Decimal, @openingBalance Decimal, @closingBalance Decimal, @PeopleName VARCHAR(200), @Pid INT, @AccId INT
	Declare @runningTable AS TABLE (PeopleId INT, PupilName VARCHAR(200), AccountId INT, TransactionType int, TransactionDescription VARCHAR(500), TransactionDate DateTime, TransactionAmt Decimal, Debit Decimal, Credit Decimal, Balance Decimal)
	
	SELECT @Pid = p.peopleid, @PeopleName =  p.FirstName + '' '' + p.Surname 
	FROM people p
	INNER JOIN accounts a ON (a.peopleid = p.peopleid)


		SELECT @AccId= AccountID,@openingBalance = Convert(Decimal,SUM(
					 CASE   tt.action 
							WHEN ''cr'' THEN TransactionAmt
							WHEN ''dr'' THEN (TransactionAmt * -1)
							ELSE TransactionAmt
					 END) )
			from transactions 
			inner join transactiontype tt on (tt.transactiontypeid = transactiontype)
			WHERE (TransactionDate < @startDate) and (accountID IN (select * from dbo.CommaSeperator(@accountId))) 
			AND (Active=1) and (ShowInReport=1)
		GROUP BY accountid
		
		 --Now do the rest
   INSERT INTO @runningTable (PeopleId,PupilName, AccountId, [TransactionType], TransactionDescription,[TransactionDate],[TransactionAmt], Debit, Credit, [Balance]) VALUES (@Pid,@PeopleName,@AccId,0,''Opening Balance'', @startDate, NULL, NULL, NULL, isnull(@openingBalance,0))
   SELECT @runningBalance = @openingBalance

	  --Calculate the Running Balance

	Declare	@AccNo		INT
	Declare @TranType   INT
	Declare @PplID		INT
	Declare @Descr		varchar(150)
	Declare @strStatus	varchar(50)
	DECLARE @TranDate DATETIME
	Declare @TranAmt DECIMAL
	Declare @dr VARCHAR(MAX)
	Declare @cr VARCHAR(MAX)
	Declare @bal DECIMAL

	DECLARE TransactionCursor CURSOR FOR 
	SELECT AccountId, D0.TransactionType, tt.description, D0.TransactionDate,D0.TransactionAmt,
		cast(isnull(case when tt.action = ''dr'' then D0.transactionamt end,0.00) as varchar)
		[debit],
		cast(isnull(case when tt.action = ''cr'' then D0.transactionamt end, 0.00) as varchar)
		[credit],
		(SELECT Convert(Decimal,SUM(
					 CASE   tt.action 
							WHEN ''cr'' THEN D1.TransactionAmt
							WHEN ''dr'' THEN (D1.TransactionAmt * -1)
							ELSE D1.TransactionAmt
					 END) ) 
		FROM transactions D1 
		inner join transactiontype tt on (tt.transactiontypeid = D1.transactiontype)
		WHERE (D1.transactiondate <= D0.transactiondate) and (D1.Active=1) and (D1.ShowInReport=1)
		and D1.accountid IN(select * from dbo.CommaSeperator(@accountId))) AS bal 
		
		FROM transactions D0
		inner join transactiontype tt on (tt.transactiontypeid = D0.transactiontype)

		WHERE D0.TransactionDate BETWEEN @startDate AND @endDate and D0.accountid IN(select * from dbo.CommaSeperator(@accountId)) and D0.Active=1 and D0.ShowInReport=1
		order by D0.AccountId,D0.transactionDate

		
	OPEN TransactionCursor
	FETCH NEXT FROM TransactionCursor

	INTO @AccNo, @TranType, @Descr, @TranDate, @TranAmt, @dr, @cr, @bal
	
	WHILE @@FETCH_STATUS = 0
	BEGIN

			INSERT INTO @runningTable (PeopleId,AccountId,TransactionType,TransactionDescription,TransactionAmt,TransactionDate,debit,credit,Balance) 
			VALUES(@PplID,@AccNo,@TranType,@Descr,@TranAmt,@TranDate,@dr,@cr,@bal)
			

	FETCH NEXT FROM TransactionCursor
			INTO @AccNo, @TranType, @Descr, @TranDate, @TranAmt, @dr, @cr, @bal

		-- Status Updates
		
	END

	DEALLOCATE TransactionCursor

  
	 SELECT * FROM @runningTable
END
' 
END

/****** Object:  StoredProcedure [dbo].[P_OtherStatement]    Script Date: 06/14/2010 09:53:29 ******/
SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[P_OtherStatement]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[P_OtherStatement] 
	-- Add the parameters for the stored procedure here
	@PeopleId int,
	@StartDate datetime,
	@EndDate datetime
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;


DECLARE	@d1 datetime
DECLARE	@d2 datetime
SET @d1 = @StartDate
SET @d2 = @EndDate


select top 1 peopleid, date, name, '''' income, '''' expense, balance, orderer 
from balancer(''Opening Balance'', @d1, @PeopleId)

union select 
	p.peopleid, datepart(ww, transactiondate), tt.description ''TxType'', 
	cast(case when tt.action = ''dr'' then sum(t.transactionamt) end as varchar),
	cast(case when tt.action = ''cr'' then sum(t.transactionamt) end as varchar),
	case when tt.action = ''dr'' then sum(t.transactionamt) else -sum(t.transactionamt) end,
	2 orderer
from people p
	inner join accounts a on (a.peopleid = p.peopleid)
	left join transactions t on (t.accountid = a.accountid)
	inner join transactiontype tt on (tt.transactiontypeid = t.transactiontype)
where p.peopleid = @PeopleId and 
	transactiondate >= @d1 and transactiondate <= @d2
group by p.peopleid, datepart(ww, transactiondate), t.transactiontype, tt.description, tt.action

union select top 1 peopleid, date, name, '''' income, '''' expense, balance, orderer  
from balancer(''Closing Balance'', @d2, @PeopleId)

order by peopleid, date, orderer



END
' 
END

/****** Object:  View [dbo].[v_output_statement]    Script Date: 06/14/2010 09:53:28 ******/
SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[v_output_statement]'))
EXEC dbo.sp_executesql @statement = N'CREATE VIEW [dbo].[v_output_statement]
AS
SELECT     TOP (100) PERCENT p.peopleID, p.Surname, p.Firstname, t.TransactionID, t.AccountID, tt.Description, tt.Action, 
                      CAST(ISNULL(CASE WHEN tt.action = ''dr'' THEN t .transactionamt END, 0.00) AS varchar) AS debit, CAST(ISNULL(CASE WHEN tt.action = ''cr'' THEN t .transactionamt END,
                       0.00) AS varchar) AS credit, t.TransactionDate
FROM         dbo.people AS p INNER JOIN
                      dbo.Accounts AS a ON a.PeopleID = p.peopleID LEFT OUTER JOIN
                      dbo.Transactions AS t ON t.AccountID = a.AccountID INNER JOIN
                      dbo.TransactionType AS tt ON tt.TransactionTypeID = t.TransactionType
ORDER BY a.AccountID
'

IF NOT EXISTS (SELECT * FROM ::fn_listextendedproperty(N'MS_DiagramPane1' , N'SCHEMA',N'dbo', N'VIEW',N'v_output_statement', NULL,NULL))
EXEC sys.sp_addextendedproperty @name=N'MS_DiagramPane1', @value=N'[0E232FF0-B466-11cf-A24F-00AA00A3EFFF, 1.00]
Begin DesignProperties = 
   Begin PaneConfigurations = 
      Begin PaneConfiguration = 0
         NumPanes = 4
         Configuration = "(H (1[40] 4[20] 2[20] 3) )"
      End
      Begin PaneConfiguration = 1
         NumPanes = 3
         Configuration = "(H (1 [50] 4 [25] 3))"
      End
      Begin PaneConfiguration = 2
         NumPanes = 3
         Configuration = "(H (1 [50] 2 [25] 3))"
      End
      Begin PaneConfiguration = 3
         NumPanes = 3
         Configuration = "(H (4 [30] 2 [40] 3))"
      End
      Begin PaneConfiguration = 4
         NumPanes = 2
         Configuration = "(H (1 [56] 3))"
      End
      Begin PaneConfiguration = 5
         NumPanes = 2
         Configuration = "(H (2 [66] 3))"
      End
      Begin PaneConfiguration = 6
         NumPanes = 2
         Configuration = "(H (4 [50] 3))"
      End
      Begin PaneConfiguration = 7
         NumPanes = 1
         Configuration = "(V (3))"
      End
      Begin PaneConfiguration = 8
         NumPanes = 3
         Configuration = "(H (1[56] 4[18] 2) )"
      End
      Begin PaneConfiguration = 9
         NumPanes = 2
         Configuration = "(H (1 [75] 4))"
      End
      Begin PaneConfiguration = 10
         NumPanes = 2
         Configuration = "(H (1[66] 2) )"
      End
      Begin PaneConfiguration = 11
         NumPanes = 2
         Configuration = "(H (4 [60] 2))"
      End
      Begin PaneConfiguration = 12
         NumPanes = 1
         Configuration = "(H (1) )"
      End
      Begin PaneConfiguration = 13
         NumPanes = 1
         Configuration = "(V (4))"
      End
      Begin PaneConfiguration = 14
         NumPanes = 1
         Configuration = "(V (2))"
      End
      ActivePaneConfig = 0
   End
   Begin DiagramPane = 
      Begin Origin = 
         Top = 0
         Left = 0
      End
      Begin Tables = 
         Begin Table = "p"
            Begin Extent = 
               Top = 6
               Left = 38
               Bottom = 125
               Right = 198
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "a"
            Begin Extent = 
               Top = 6
               Left = 236
               Bottom = 110
               Right = 396
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "t"
            Begin Extent = 
               Top = 6
               Left = 434
               Bottom = 125
               Right = 612
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "tt"
            Begin Extent = 
               Top = 114
               Left = 236
               Bottom = 218
               Right = 416
            End
            DisplayFlags = 280
            TopColumn = 0
         End
      End
   End
   Begin SQLPane = 
   End
   Begin DataPane = 
      Begin ParameterDefaults = ""
      End
      Begin ColumnWidths = 9
         Width = 284
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
      End
   End
   Begin CriteriaPane = 
      Begin ColumnWidths = 11
         Column = 1440
         Alias = 900
         Table = 1170
         Output = 720
         Append = 1400
         NewValue = 1170
         SortType = 1350
         SortOrder = 1410
         GroupBy = 1350
         Filter = 1350
         Or = 1350
         Or = 1350
         Or = 1350
      End
   End
End
' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'VIEW',@level1name=N'v_output_statement'

IF NOT EXISTS (SELECT * FROM ::fn_listextendedproperty(N'MS_DiagramPaneCount' , N'SCHEMA',N'dbo', N'VIEW',N'v_output_statement', NULL,NULL))
EXEC sys.sp_addextendedproperty @name=N'MS_DiagramPaneCount', @value=1 , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'VIEW',@level1name=N'v_output_statement'

/****** Object:  StoredProcedure [dbo].[P_NewStatement]    Script Date: 06/14/2010 09:53:29 ******/
SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[P_NewStatement]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[P_NewStatement] 
	-- Add the parameters for the stored procedure here
	@PeopleId int,
	@StartDate datetime,
	@EndDate datetime
AS
BEGIN
	
	SET NOCOUNT ON;

SET DATEFORMAT YMD

SELECT p.peopleid,D0.transactionid, D0.transactiondate, 
D0.transactionamt,a.accountid,
cast(isnull(case when tt.action = ''dr'' then D0.transactionamt end,0.00) as varchar)
[debit],
cast(isnull(case when tt.action = ''cr'' then D0.transactionamt end, 0.00) as varchar)
[credit],
(SELECT SUM(D1.transactionamt) 
FROM v_account_balance D1 
WHERE D1.transactiondate <= D0.transactiondate
and d1.peopleid=@PeopleId) AS balance
FROM people p
inner join accounts a on (a.peopleid = p.peopleid)
inner join v_account_balance D0 on (D0.accountid=a.accountid)
inner join transactiontype tt on (tt.transactiontypeid = D0.transactiontype)

where d0.peopleid=@PeopleId
order by a.accountid,d0.transactiondate
END
' 
END

/****** Object:  View [dbo].[v_account_balance]    Script Date: 06/14/2010 09:53:28 ******/
SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[v_account_balance]'))
EXEC dbo.sp_executesql @statement = N'CREATE VIEW [dbo].[v_account_balance]
AS
SELECT     dbo.people.peopleID, dbo.Accounts.AccountID, dbo.Transactions.TransactionID, dbo.Transactions.TransactionType, dbo.Transactions.TransactionDate, 
                      - dbo.Transactions.TransactionAmt AS TransactionAmt, dbo.Transactions.GamesheetID
FROM         dbo.people INNER JOIN
                      dbo.Accounts ON dbo.people.peopleID = dbo.Accounts.PeopleID INNER JOIN
                      dbo.Transactions ON dbo.Accounts.AccountID = dbo.Transactions.AccountID INNER JOIN
                      dbo.TransactionType ON dbo.TransactionType.TransactionTypeID = dbo.Transactions.TransactionType
WHERE     (dbo.TransactionType.Action = ''dr'') AND (dbo.Transactions.Active = 1)
UNION
SELECT     people_1.peopleID, Accounts_1.AccountID, Transactions_1.TransactionID, Transactions_1.TransactionType, Transactions_1.TransactionDate, 
                      Transactions_1.TransactionAmt, Transactions_1.GamesheetID
FROM         dbo.people AS people_1 INNER JOIN
                      dbo.Accounts AS Accounts_1 ON people_1.peopleID = Accounts_1.PeopleID INNER JOIN
                      dbo.Transactions AS Transactions_1 ON Accounts_1.AccountID = Transactions_1.AccountID INNER JOIN
                      dbo.TransactionType AS TransactionType_1 ON TransactionType_1.TransactionTypeID = Transactions_1.TransactionType
WHERE     (TransactionType_1.Action = ''cr'') AND (Transactions_1.Active = 1)
'

IF NOT EXISTS (SELECT * FROM ::fn_listextendedproperty(N'MS_DiagramPane1' , N'SCHEMA',N'dbo', N'VIEW',N'v_account_balance', NULL,NULL))
EXEC sys.sp_addextendedproperty @name=N'MS_DiagramPane1', @value=N'[0E232FF0-B466-11cf-A24F-00AA00A3EFFF, 1.00]
Begin DesignProperties = 
   Begin PaneConfigurations = 
      Begin PaneConfiguration = 0
         NumPanes = 4
         Configuration = "(H (1[40] 4[20] 2[20] 3) )"
      End
      Begin PaneConfiguration = 1
         NumPanes = 3
         Configuration = "(H (1 [50] 4 [25] 3))"
      End
      Begin PaneConfiguration = 2
         NumPanes = 3
         Configuration = "(H (1 [50] 2 [25] 3))"
      End
      Begin PaneConfiguration = 3
         NumPanes = 3
         Configuration = "(H (4[30] 2[40] 3) )"
      End
      Begin PaneConfiguration = 4
         NumPanes = 2
         Configuration = "(H (1 [56] 3))"
      End
      Begin PaneConfiguration = 5
         NumPanes = 2
         Configuration = "(H (2 [66] 3))"
      End
      Begin PaneConfiguration = 6
         NumPanes = 2
         Configuration = "(H (4 [50] 3))"
      End
      Begin PaneConfiguration = 7
         NumPanes = 1
         Configuration = "(V (3))"
      End
      Begin PaneConfiguration = 8
         NumPanes = 3
         Configuration = "(H (1[56] 4[18] 2) )"
      End
      Begin PaneConfiguration = 9
         NumPanes = 2
         Configuration = "(H (1 [75] 4))"
      End
      Begin PaneConfiguration = 10
         NumPanes = 2
         Configuration = "(H (1[66] 2) )"
      End
      Begin PaneConfiguration = 11
         NumPanes = 2
         Configuration = "(H (4 [60] 2))"
      End
      Begin PaneConfiguration = 12
         NumPanes = 1
         Configuration = "(H (1) )"
      End
      Begin PaneConfiguration = 13
         NumPanes = 1
         Configuration = "(V (4))"
      End
      Begin PaneConfiguration = 14
         NumPanes = 1
         Configuration = "(V (2))"
      End
      ActivePaneConfig = 3
   End
   Begin DiagramPane = 
      PaneHidden = 
      Begin Origin = 
         Top = 0
         Left = 0
      End
      Begin Tables = 
      End
   End
   Begin SQLPane = 
   End
   Begin DataPane = 
      Begin ParameterDefaults = ""
      End
      Begin ColumnWidths = 9
         Width = 284
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
      End
   End
   Begin CriteriaPane = 
      Begin ColumnWidths = 5
         Column = 1440
         Alias = 900
         Table = 1170
         Output = 720
         Append = 1400
         NewValue = 1170
         SortType = 1350
         SortOrder = 1410
         GroupBy = 1350
         Filter = 1350
         Or = 1350
         Or = 1350
         Or = 1350
      End
   End
End
' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'VIEW',@level1name=N'v_account_balance'

IF NOT EXISTS (SELECT * FROM ::fn_listextendedproperty(N'MS_DiagramPaneCount' , N'SCHEMA',N'dbo', N'VIEW',N'v_account_balance', NULL,NULL))
EXEC sys.sp_addextendedproperty @name=N'MS_DiagramPaneCount', @value=1 , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'VIEW',@level1name=N'v_account_balance'

/****** Object:  StoredProcedure [dbo].[P_Statement]    Script Date: 06/14/2010 09:53:29 ******/
SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[P_Statement]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[P_Statement] 
	-- Add the parameters for the stored procedure here
	@PeopleId int,
	@StartDate datetime,
	@EndDate datetime
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	select p.peopleid,p.surname,p.firstname,t.transactionid,t.accountid,tt.description,
tt.action,
cast(isnull(case when tt.action = ''dr'' then t.transactionamt end,0.00) as varchar)
[debit],
cast(isnull(case when tt.action = ''cr'' then t.transactionamt end, 0.00) as varchar)
[credit],
t.transactiondate,
sum(isnull(case when tt.action = ''dr'' then t.transactionamt end,0.00))
-
sum(isnull(case when tt.action = ''cr'' then t.transactionamt end, 0.00))
[balance],
g.gamesheetid,g.weekno,g.gameyear,
OB.BALANCE AS ''OPENINGBALANCE'', CB.BALANCE AS ''CLOSINGBALANCE''
from people p
inner join accounts a on (a.peopleid = p.peopleid)
left join transactions t on (t.accountid = a.accountid)
inner join transactiontype tt on (tt.transactiontypeid = t.transactiontype)

left join gamesheet g on (g.gamesheetid = t.gamesheetid) and (g.classid = p.classid)

LEFT JOIN(SELECT V.PEOPLEID,V.ACCOUNTID,SUM(V.TRANSACTIONAMT) AS BALANCE
from V_ACCOUNT_BALANCE V 
WHERE V.TRANSACTIONDATE < @StartDate
group by V.PEOPLEID,V.ACCOUNTID) OB
on (OB.PEOPLEID = P.PEOPLEID)

LEFT JOIN(SELECT V.PEOPLEID,V.ACCOUNTID,SUM(V.TRANSACTIONAMT) AS BALANCE
from V_ACCOUNT_BALANCE V 
WHERE V.TRANSACTIONDATE < @EndDate
group by V.PEOPLEID,V.ACCOUNTID) CB
on (CB.PEOPLEID = P.PEOPLEID)

group by p.peopleid,p.surname,p.firstname,t.transactionid,t.accountid,tt.description,
tt.action,t.transactionamt,t.transactiondate,a.accountid,g.gamesheetid,g.weekno,g.gameyear,
OB.BALANCE,CB.BALANCE

order by a.accountid,g.weekno,t.transactiondate
END
' 
END

/****** Object:  View [dbo].[v_people_account_trans]    Script Date: 06/14/2010 09:53:28 ******/
SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[v_people_account_trans]'))
EXEC dbo.sp_executesql @statement = N'CREATE VIEW [dbo].[v_people_account_trans]
AS
SELECT     dbo.people.peopleID, dbo.Accounts.AccountID, dbo.Transactions.TransactionID, dbo.Transactions.TransactionType, dbo.Transactions.TransactionDate, 
                      dbo.Transactions.TransactionAmt, dbo.Transactions.GamesheetID
FROM         dbo.people INNER JOIN
                      dbo.Accounts ON dbo.people.peopleID = dbo.Accounts.PeopleID INNER JOIN
                      dbo.Transactions ON dbo.Accounts.AccountID = dbo.Transactions.AccountID
'

IF NOT EXISTS (SELECT * FROM ::fn_listextendedproperty(N'MS_DiagramPane1' , N'SCHEMA',N'dbo', N'VIEW',N'v_people_account_trans', NULL,NULL))
EXEC sys.sp_addextendedproperty @name=N'MS_DiagramPane1', @value=N'[0E232FF0-B466-11cf-A24F-00AA00A3EFFF, 1.00]
Begin DesignProperties = 
   Begin PaneConfigurations = 
      Begin PaneConfiguration = 0
         NumPanes = 4
         Configuration = "(H (1[40] 4[20] 2[20] 3) )"
      End
      Begin PaneConfiguration = 1
         NumPanes = 3
         Configuration = "(H (1 [50] 4 [25] 3))"
      End
      Begin PaneConfiguration = 2
         NumPanes = 3
         Configuration = "(H (1 [50] 2 [25] 3))"
      End
      Begin PaneConfiguration = 3
         NumPanes = 3
         Configuration = "(H (4 [30] 2 [40] 3))"
      End
      Begin PaneConfiguration = 4
         NumPanes = 2
         Configuration = "(H (1 [56] 3))"
      End
      Begin PaneConfiguration = 5
         NumPanes = 2
         Configuration = "(H (2 [66] 3))"
      End
      Begin PaneConfiguration = 6
         NumPanes = 2
         Configuration = "(H (4 [50] 3))"
      End
      Begin PaneConfiguration = 7
         NumPanes = 1
         Configuration = "(V (3))"
      End
      Begin PaneConfiguration = 8
         NumPanes = 3
         Configuration = "(H (1[56] 4[18] 2) )"
      End
      Begin PaneConfiguration = 9
         NumPanes = 2
         Configuration = "(H (1 [75] 4))"
      End
      Begin PaneConfiguration = 10
         NumPanes = 2
         Configuration = "(H (1[66] 2) )"
      End
      Begin PaneConfiguration = 11
         NumPanes = 2
         Configuration = "(H (4 [60] 2))"
      End
      Begin PaneConfiguration = 12
         NumPanes = 1
         Configuration = "(H (1) )"
      End
      Begin PaneConfiguration = 13
         NumPanes = 1
         Configuration = "(V (4))"
      End
      Begin PaneConfiguration = 14
         NumPanes = 1
         Configuration = "(V (2))"
      End
      ActivePaneConfig = 0
   End
   Begin DiagramPane = 
      Begin Origin = 
         Top = 0
         Left = 0
      End
      Begin Tables = 
         Begin Table = "people"
            Begin Extent = 
               Top = 6
               Left = 38
               Bottom = 125
               Right = 198
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "Accounts"
            Begin Extent = 
               Top = 6
               Left = 236
               Bottom = 110
               Right = 396
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "Transactions"
            Begin Extent = 
               Top = 6
               Left = 434
               Bottom = 125
               Right = 603
            End
            DisplayFlags = 280
            TopColumn = 2
         End
      End
   End
   Begin SQLPane = 
   End
   Begin DataPane = 
      Begin ParameterDefaults = ""
      End
      Begin ColumnWidths = 9
         Width = 284
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
      End
   End
   Begin CriteriaPane = 
      Begin ColumnWidths = 11
         Column = 1440
         Alias = 900
         Table = 1170
         Output = 720
         Append = 1400
         NewValue = 1170
         SortType = 1350
         SortOrder = 1410
         GroupBy = 1350
         Filter = 1350
         Or = 1350
         Or = 1350
         Or = 1350
      End
   End
End
' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'VIEW',@level1name=N'v_people_account_trans'

IF NOT EXISTS (SELECT * FROM ::fn_listextendedproperty(N'MS_DiagramPaneCount' , N'SCHEMA',N'dbo', N'VIEW',N'v_people_account_trans', NULL,NULL))
EXEC sys.sp_addextendedproperty @name=N'MS_DiagramPaneCount', @value=1 , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'VIEW',@level1name=N'v_people_account_trans'

/****** Object:  View [dbo].[v_new_gamesheet]    Script Date: 06/14/2010 09:53:28 ******/
SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[v_new_gamesheet]'))
EXEC dbo.sp_executesql @statement = N'CREATE VIEW [dbo].[v_new_gamesheet]
AS
SELECT     p.peopleID, p.Surname, p.Firstname, a.AccountID, p.ClassID, SUM(ISNULL(v1.TransactionAmt, 0)) AS Balance
FROM         dbo.people AS p LEFT OUTER JOIN
                      dbo.Accounts AS a ON a.PeopleID = p.peopleID LEFT OUTER JOIN
                      dbo.v_account_balance AS v1 ON v1.AccountID = a.AccountID AND v1.peopleID = p.peopleID
GROUP BY p.peopleID, p.Surname, p.Firstname, a.AccountID, p.ClassID
'

IF NOT EXISTS (SELECT * FROM ::fn_listextendedproperty(N'MS_DiagramPane1' , N'SCHEMA',N'dbo', N'VIEW',N'v_new_gamesheet', NULL,NULL))
EXEC sys.sp_addextendedproperty @name=N'MS_DiagramPane1', @value=N'[0E232FF0-B466-11cf-A24F-00AA00A3EFFF, 1.00]
Begin DesignProperties = 
   Begin PaneConfigurations = 
      Begin PaneConfiguration = 0
         NumPanes = 4
         Configuration = "(H (1[40] 4[20] 2[20] 3) )"
      End
      Begin PaneConfiguration = 1
         NumPanes = 3
         Configuration = "(H (1 [50] 4 [25] 3))"
      End
      Begin PaneConfiguration = 2
         NumPanes = 3
         Configuration = "(H (1 [50] 2 [25] 3))"
      End
      Begin PaneConfiguration = 3
         NumPanes = 3
         Configuration = "(H (4 [30] 2 [40] 3))"
      End
      Begin PaneConfiguration = 4
         NumPanes = 2
         Configuration = "(H (1 [56] 3))"
      End
      Begin PaneConfiguration = 5
         NumPanes = 2
         Configuration = "(H (2 [66] 3))"
      End
      Begin PaneConfiguration = 6
         NumPanes = 2
         Configuration = "(H (4 [50] 3))"
      End
      Begin PaneConfiguration = 7
         NumPanes = 1
         Configuration = "(V (3))"
      End
      Begin PaneConfiguration = 8
         NumPanes = 3
         Configuration = "(H (1[56] 4[18] 2) )"
      End
      Begin PaneConfiguration = 9
         NumPanes = 2
         Configuration = "(H (1 [75] 4))"
      End
      Begin PaneConfiguration = 10
         NumPanes = 2
         Configuration = "(H (1[66] 2) )"
      End
      Begin PaneConfiguration = 11
         NumPanes = 2
         Configuration = "(H (4 [60] 2))"
      End
      Begin PaneConfiguration = 12
         NumPanes = 1
         Configuration = "(H (1) )"
      End
      Begin PaneConfiguration = 13
         NumPanes = 1
         Configuration = "(V (4))"
      End
      Begin PaneConfiguration = 14
         NumPanes = 1
         Configuration = "(V (2))"
      End
      ActivePaneConfig = 0
   End
   Begin DiagramPane = 
      Begin Origin = 
         Top = 0
         Left = 0
      End
      Begin Tables = 
         Begin Table = "p"
            Begin Extent = 
               Top = 6
               Left = 38
               Bottom = 125
               Right = 214
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "a"
            Begin Extent = 
               Top = 6
               Left = 252
               Bottom = 110
               Right = 428
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "v1"
            Begin Extent = 
               Top = 6
               Left = 466
               Bottom = 125
               Right = 651
            End
            DisplayFlags = 280
            TopColumn = 0
         End
      End
   End
   Begin SQLPane = 
   End
   Begin DataPane = 
      Begin ParameterDefaults = ""
      End
      Begin ColumnWidths = 22
         Width = 284
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
      End
   End
   Begin CriteriaPane = 
      Begin ColumnWidths = 12
         Column = 1440
         Alias = 900
         Table = 1170
         Output = 720
         Append = 1400
         NewValue = 1170
         SortType = 1350
         SortOrder = 1410
         GroupBy = 1350
         Filter = 1350
         Or = 1350
         Or = 1350
         Or = ' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'VIEW',@level1name=N'v_new_gamesheet'

IF NOT EXISTS (SELECT * FROM ::fn_listextendedproperty(N'MS_DiagramPane2' , N'SCHEMA',N'dbo', N'VIEW',N'v_new_gamesheet', NULL,NULL))
EXEC sys.sp_addextendedproperty @name=N'MS_DiagramPane2', @value=N'1350
      End
   End
End
' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'VIEW',@level1name=N'v_new_gamesheet'

IF NOT EXISTS (SELECT * FROM ::fn_listextendedproperty(N'MS_DiagramPaneCount' , N'SCHEMA',N'dbo', N'VIEW',N'v_new_gamesheet', NULL,NULL))
EXEC sys.sp_addextendedproperty @name=N'MS_DiagramPaneCount', @value=2 , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'VIEW',@level1name=N'v_new_gamesheet'

/****** Object:  View [dbo].[v_gamesheet]    Script Date: 06/14/2010 09:53:28 ******/
SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[v_gamesheet]'))
EXEC dbo.sp_executesql @statement = N'CREATE VIEW [dbo].[v_gamesheet]
AS
SELECT     p.peopleID, p.Surname, p.Firstname, a.AccountID, j.JobID, j.Description, p.ClassID, g.GameSheetID, gt.Day1, gt.Day2, gt.Day3, gt.Day4, gt.Day5, g.WeekNo, 
                      g.GameYear
FROM         dbo.people AS p LEFT OUTER JOIN
                      dbo.Accounts AS a ON a.PeopleID = p.peopleID LEFT OUTER JOIN
                      dbo.GameSheet AS g ON g.ClassID = p.ClassID LEFT OUTER JOIN
                      dbo.GamesheetTX AS gt ON gt.GameSheetID = g.GameSheetID AND gt.PeopleID = p.peopleID LEFT OUTER JOIN
                      dbo.Jobs AS j ON j.JobID = gt.JobID AND j.Active = 1
'

IF NOT EXISTS (SELECT * FROM ::fn_listextendedproperty(N'MS_DiagramPane1' , N'SCHEMA',N'dbo', N'VIEW',N'v_gamesheet', NULL,NULL))
EXEC sys.sp_addextendedproperty @name=N'MS_DiagramPane1', @value=N'[0E232FF0-B466-11cf-A24F-00AA00A3EFFF, 1.00]
Begin DesignProperties = 
   Begin PaneConfigurations = 
      Begin PaneConfiguration = 0
         NumPanes = 4
         Configuration = "(H (1[40] 4[20] 2[20] 3) )"
      End
      Begin PaneConfiguration = 1
         NumPanes = 3
         Configuration = "(H (1 [50] 4 [25] 3))"
      End
      Begin PaneConfiguration = 2
         NumPanes = 3
         Configuration = "(H (1 [50] 2 [25] 3))"
      End
      Begin PaneConfiguration = 3
         NumPanes = 3
         Configuration = "(H (4 [30] 2 [40] 3))"
      End
      Begin PaneConfiguration = 4
         NumPanes = 2
         Configuration = "(H (1 [56] 3))"
      End
      Begin PaneConfiguration = 5
         NumPanes = 2
         Configuration = "(H (2 [66] 3))"
      End
      Begin PaneConfiguration = 6
         NumPanes = 2
         Configuration = "(H (4 [50] 3))"
      End
      Begin PaneConfiguration = 7
         NumPanes = 1
         Configuration = "(V (3))"
      End
      Begin PaneConfiguration = 8
         NumPanes = 3
         Configuration = "(H (1[56] 4[18] 2) )"
      End
      Begin PaneConfiguration = 9
         NumPanes = 2
         Configuration = "(H (1 [75] 4))"
      End
      Begin PaneConfiguration = 10
         NumPanes = 2
         Configuration = "(H (1[66] 2) )"
      End
      Begin PaneConfiguration = 11
         NumPanes = 2
         Configuration = "(H (4 [60] 2))"
      End
      Begin PaneConfiguration = 12
         NumPanes = 1
         Configuration = "(H (1) )"
      End
      Begin PaneConfiguration = 13
         NumPanes = 1
         Configuration = "(V (4))"
      End
      Begin PaneConfiguration = 14
         NumPanes = 1
         Configuration = "(V (2))"
      End
      ActivePaneConfig = 0
   End
   Begin DiagramPane = 
      Begin Origin = 
         Top = 0
         Left = 0
      End
      Begin Tables = 
         Begin Table = "p"
            Begin Extent = 
               Top = 6
               Left = 38
               Bottom = 125
               Right = 198
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "a"
            Begin Extent = 
               Top = 6
               Left = 236
               Bottom = 125
               Right = 396
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "g"
            Begin Extent = 
               Top = 6
               Left = 434
               Bottom = 125
               Right = 594
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "gt"
            Begin Extent = 
               Top = 126
               Left = 38
               Bottom = 245
               Right = 198
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "j"
            Begin Extent = 
               Top = 126
               Left = 236
               Bottom = 245
               Right = 396
            End
            DisplayFlags = 280
            TopColumn = 0
         End
      End
   End
   Begin SQLPane = 
   End
   Begin DataPane = 
      Begin ParameterDefaults = ""
      End
      Begin ColumnWidths = 15
         Width = 284
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
      End
   End
   ' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'VIEW',@level1name=N'v_gamesheet'

IF NOT EXISTS (SELECT * FROM ::fn_listextendedproperty(N'MS_DiagramPane2' , N'SCHEMA',N'dbo', N'VIEW',N'v_gamesheet', NULL,NULL))
EXEC sys.sp_addextendedproperty @name=N'MS_DiagramPane2', @value=N'Begin CriteriaPane = 
      Begin ColumnWidths = 11
         Column = 1440
         Alias = 900
         Table = 1170
         Output = 720
         Append = 1400
         NewValue = 1170
         SortType = 1350
         SortOrder = 1410
         GroupBy = 1350
         Filter = 1350
         Or = 1350
         Or = 1350
         Or = 1350
      End
   End
End
' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'VIEW',@level1name=N'v_gamesheet'

IF NOT EXISTS (SELECT * FROM ::fn_listextendedproperty(N'MS_DiagramPaneCount' , N'SCHEMA',N'dbo', N'VIEW',N'v_gamesheet', NULL,NULL))
EXEC sys.sp_addextendedproperty @name=N'MS_DiagramPaneCount', @value=2 , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'VIEW',@level1name=N'v_gamesheet'

/****** Object:  StoredProcedure [dbo].[proc_ShowBalance]    Script Date: 06/14/2010 09:53:29 ******/
SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_ShowBalance]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[proc_ShowBalance]
	-- Add the parameters for the stored procedure here
	@accountId Int,
	@peopleId INT,  
	@startDate DateTime,
	@endDate DateTime
AS
BEGIN

SET DATEFORMAT YMD

	Declare @balanceAtStartDate Decimal, @runningBalance Decimal, @openingBalance Decimal, @closingBalance Decimal, @PeopleName VARCHAR(200)
	Declare @runningTable AS TABLE (PeopleId INT, PupilName VARCHAR(200), AccountId INT, TransactionType int, TransactionDescription VARCHAR(500), TransactionDate DateTime, TransactionAmt Decimal, Debit Decimal, Credit Decimal, Balance Decimal)
	
	SELECT @PeopleName =  FirstName + '' '' + Surname COLLATE DATABASE_DEFAULT 
	FROM people WHERE peopleid = @peopleId

    --Get the opening Balance on the date you want to start at
	SELECT  @openingBalance = Convert(Decimal,SUM(
             CASE   tt.action 
                    WHEN ''cr'' THEN TransactionAmt
                    WHEN ''dr'' THEN (TransactionAmt * -1)
                    ELSE TransactionAmt
             END) )
	from transactions 
	inner join transactiontype tt on (tt.transactiontypeid = transactiontype)
	WHERE (TransactionDate < @startDate) and (accountid=@accountId)
	AND (Active=1) and (ShowInReport=1)

   --Now do the rest
   INSERT INTO @runningTable (PeopleId,PupilName, AccountId, [TransactionType], TransactionDescription,[TransactionDate],[TransactionAmt], Debit, Credit, [Balance]) VALUES (@peopleId,@PeopleName,@accountId,0,''Opening Balance'', @startDate, NULL, NULL, NULL, isnull(@openingBalance,0))
   SELECT @runningBalance = @openingBalance
   
		--insert all transactions
		INSERT INTO @runningTable (PeopleId,PupilName,AccountId,TransactionType,TransactionDescription,TransactionDate,TransactionAmt,Debit,Credit,Balance) 
			
		SELECT @peopleId,@PeopleName,@accountId, D0.TransactionType, tt.description + case when D0.ChequeDescription is null then '''' else CHAR(13) + CHAR(10) + ''<i>'' + D0.ChequeDescription + ''</i>'' end, D0.TransactionDate,D0.TransactionAmt,
		cast(isnull(case when tt.action = ''dr'' then D0.transactionamt end,0.00) as varchar)
		[debit],
		cast(isnull(case when tt.action = ''cr'' then D0.transactionamt end, 0.00) as varchar)
		[credit],
		(SELECT Convert(Decimal,SUM(
					 CASE   tt.action 
							WHEN ''cr'' THEN D1.TransactionAmt
							WHEN ''dr'' THEN (D1.TransactionAmt * -1)
							ELSE D1.TransactionAmt
					 END) ) 
		FROM transactions D1 
		inner join transactiontype tt on (tt.transactiontypeid = D1.transactiontype)
		WHERE (D1.transactiondate <= D0.transactiondate) and (D1.Active=1) and (D1.ShowInReport=1)
		and D1.accountid=@accountId) AS bal 
		
		FROM transactions D0
		inner join transactiontype tt on (tt.transactiontypeid = D0.transactiontype)

		WHERE D0.TransactionDate BETWEEN @startDate AND @endDate and D0.accountid=@accountId and D0.Active=1 and D0.ShowInReport=1
		order by D0.AccountId,D0.transactionDate


 --Get the closing Balance on the date you want to end at
	SELECT  @closingBalance = Convert(Decimal,SUM(
             CASE   tt.action 
                    WHEN ''cr'' THEN TransactionAmt
                    WHEN ''dr'' THEN (TransactionAmt * -1)
                    ELSE TransactionAmt
             END) )
	from transactions
	inner join transactiontype tt on (tt.transactiontypeid = transactiontype)
	WHERE (TransactionDate <= @endDate) and (accountid=@accountId) and (Active=1) 
	and (ShowInReport=1)

   --Now do the rest
   INSERT INTO @runningTable (PeopleId,PupilName,AccountId,[TransactionType],TransactionDescription,[TransactionDate],[TransactionAmt],debit,credit, [Balance]) VALUES (@peopleId,@PeopleName,@accountId,0,''Closing Balance'', @endDate, NULL, NULL, NULL, isnull(@closingBalance,0))

  --Calculate the Running Balance
  
  SELECT * FROM @runningTable

END
' 
END

/****** Object:  View [dbo].[v_people_accounts]    Script Date: 06/14/2010 09:53:29 ******/
SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON

IF NOT EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[v_people_accounts]'))
EXEC dbo.sp_executesql @statement = N'CREATE VIEW [dbo].[v_people_accounts]
AS
SELECT     p.peopleID, p.Surname, p.Firstname, a.AccountID, j.JobID, j.Description, p.ClassID, SUM(ISNULL(v1.TransactionAmt, 0)) AS Balance, g.GameSheetID, g.SheetDate, 
                      g.ClassID AS Expr1, g.GameYear, g.WeekNo, gt.ID AS gametxid, gt.GameSheetID AS Expr2, gt.PeopleID AS Expr3, gt.JobID AS Expr4, gt.Day1, gt.Day2, gt.Day3, 
                      gt.Day4, gt.Day5
FROM         dbo.people AS p LEFT OUTER JOIN
                      dbo.Accounts AS a ON a.PeopleID = p.peopleID LEFT OUTER JOIN
                      dbo.GameSheet AS g ON g.ClassID = p.ClassID LEFT OUTER JOIN
                      dbo.GamesheetTX AS gt ON gt.GameSheetID = g.GameSheetID AND gt.PeopleID = p.peopleID AND gt.Active = 1 LEFT OUTER JOIN
                      dbo.Jobs AS j ON j.JobID = gt.JobID AND j.Active = 1 LEFT OUTER JOIN
                      dbo.v_account_balance AS v1 ON v1.AccountID = a.AccountID AND v1.peopleID = p.peopleID
GROUP BY p.peopleID, p.Surname, p.Firstname, a.AccountID, j.JobID, j.Description, p.ClassID, g.GameSheetID, g.SheetDate, g.ClassID, g.GameYear, g.WeekNo, gt.ID, 
                      gt.GameSheetID, gt.PeopleID, gt.JobID, gt.Day1, gt.Day2, gt.Day3, gt.Day4, gt.Day5
'

IF NOT EXISTS (SELECT * FROM ::fn_listextendedproperty(N'MS_DiagramPane1' , N'SCHEMA',N'dbo', N'VIEW',N'v_people_accounts', NULL,NULL))
EXEC sys.sp_addextendedproperty @name=N'MS_DiagramPane1', @value=N'[0E232FF0-B466-11cf-A24F-00AA00A3EFFF, 1.00]
Begin DesignProperties = 
   Begin PaneConfigurations = 
      Begin PaneConfiguration = 0
         NumPanes = 4
         Configuration = "(H (1[35] 4[17] 2[30] 3) )"
      End
      Begin PaneConfiguration = 1
         NumPanes = 3
         Configuration = "(H (1 [50] 4 [25] 3))"
      End
      Begin PaneConfiguration = 2
         NumPanes = 3
         Configuration = "(H (1 [50] 2 [25] 3))"
      End
      Begin PaneConfiguration = 3
         NumPanes = 3
         Configuration = "(H (4[30] 2[28] 3) )"
      End
      Begin PaneConfiguration = 4
         NumPanes = 2
         Configuration = "(H (1 [56] 3))"
      End
      Begin PaneConfiguration = 5
         NumPanes = 2
         Configuration = "(H (2 [66] 3))"
      End
      Begin PaneConfiguration = 6
         NumPanes = 2
         Configuration = "(H (4 [50] 3))"
      End
      Begin PaneConfiguration = 7
         NumPanes = 1
         Configuration = "(V (3))"
      End
      Begin PaneConfiguration = 8
         NumPanes = 3
         Configuration = "(H (1[56] 4[18] 2) )"
      End
      Begin PaneConfiguration = 9
         NumPanes = 2
         Configuration = "(H (1 [75] 4))"
      End
      Begin PaneConfiguration = 10
         NumPanes = 2
         Configuration = "(H (1[66] 2) )"
      End
      Begin PaneConfiguration = 11
         NumPanes = 2
         Configuration = "(H (4 [60] 2))"
      End
      Begin PaneConfiguration = 12
         NumPanes = 1
         Configuration = "(H (1) )"
      End
      Begin PaneConfiguration = 13
         NumPanes = 1
         Configuration = "(V (4))"
      End
      Begin PaneConfiguration = 14
         NumPanes = 1
         Configuration = "(V (2))"
      End
      ActivePaneConfig = 3
   End
   Begin DiagramPane = 
      PaneHidden = 
      Begin Origin = 
         Top = -96
         Left = 0
      End
      Begin Tables = 
         Begin Table = "p"
            Begin Extent = 
               Top = 6
               Left = 38
               Bottom = 125
               Right = 198
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "a"
            Begin Extent = 
               Top = 6
               Left = 236
               Bottom = 110
               Right = 396
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "g"
            Begin Extent = 
               Top = 114
               Left = 236
               Bottom = 233
               Right = 412
            End
            DisplayFlags = 280
            TopColumn = 2
         End
         Begin Table = "gt"
            Begin Extent = 
               Top = 234
               Left = 236
               Bottom = 353
               Right = 412
            End
            DisplayFlags = 280
            TopColumn = 6
         End
         Begin Table = "j"
            Begin Extent = 
               Top = 126
               Left = 38
               Bottom = 245
               Right = 198
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "v1"
            Begin Extent = 
               Top = 102
               Left = 434
               Bottom = 221
               Right = 619
            End
            DisplayFlags = 280
            TopColumn = 0
         End
      End
   End
   Begin SQLPane = 
   End
   Begin DataPane = 
      Begin ParameterDefaults = ""
      End
      Begin ColumnWidths = 22
         Width = 284
         Width = 1500
         Width = 1500
         Width =' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'VIEW',@level1name=N'v_people_accounts'

IF NOT EXISTS (SELECT * FROM ::fn_listextendedproperty(N'MS_DiagramPane2' , N'SCHEMA',N'dbo', N'VIEW',N'v_people_accounts', NULL,NULL))
EXEC sys.sp_addextendedproperty @name=N'MS_DiagramPane2', @value=N' 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
      End
   End
   Begin CriteriaPane = 
      Begin ColumnWidths = 12
         Column = 1440
         Alias = 900
         Table = 1170
         Output = 720
         Append = 1400
         NewValue = 1170
         SortType = 1350
         SortOrder = 1410
         GroupBy = 1350
         Filter = 1350
         Or = 1350
         Or = 1350
         Or = 1350
      End
   End
End
' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'VIEW',@level1name=N'v_people_accounts'

IF NOT EXISTS (SELECT * FROM ::fn_listextendedproperty(N'MS_DiagramPaneCount' , N'SCHEMA',N'dbo', N'VIEW',N'v_people_accounts', NULL,NULL))
EXEC sys.sp_addextendedproperty @name=N'MS_DiagramPaneCount', @value=2 , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'VIEW',@level1name=N'v_people_accounts'

/****** Object:  ForeignKey [FK_Accounts_Accounts]    Script Date: 06/14/2010 09:53:28 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Accounts_Accounts]') AND parent_object_id = OBJECT_ID(N'[dbo].[Accounts]'))
ALTER TABLE [dbo].[Accounts]  WITH CHECK ADD  CONSTRAINT [FK_Accounts_Accounts] FOREIGN KEY([AccountID])
REFERENCES [dbo].[Accounts] ([AccountID])

ALTER TABLE [dbo].[Accounts] CHECK CONSTRAINT [FK_Accounts_Accounts]
