--===== Setup the environment
    SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
    SET NOCOUNT ON
    SET ANSI_WARNINGS OFF
--===== If the result table already exists, drop it
     IF OBJECT_ID('TempDB..#ColumnData') IS NOT NULL
        DROP TABLE #ColumnData
--===== Declare the local variables
DECLARE @Columns INT          --Total number of columns found
DECLARE @Counter INT          --General purpose loop counter
DECLARE @SQL     VARCHAR(600) --Contains the dynamic SQL for each column
--===== Populate the result table with the initial table/column info
 --SELECT --RowNum              = IDENTITY(INT,1,1),
 --       TableName           = OBJECT_NAME(sc.ID), 
 --       ColumnName          = sc.Name,
 --       DataType            = UPPER(TYPE_NAME(sc.XType)),
 --       DefinedLength       = sc.Length,
 --       MaxActualDataLength = CAST(NULL AS INT)
 ----  INTO #ColumnData
 --  FROM dbo.SysColumns sc
  
 -- WHERE OBJECTPROPERTY(sc.ID,'IsTable')     = 1
 --   AND OBJECTPROPERTY(sc.ID,'IsMSShipped') = 0
    
    
  SELECT RowNum              = IDENTITY(INT,1,1),
  isc.TABLE_NAME AS TableName
	,Column_Name ColumnName
	,data_type
	,character_maximum_length DefinedLength
	,ist.TABLE_SCHEMA as TableSchema
	, MaxActualDataLength = CAST(NULL AS INT)
	INTO #ColumnData
FROM Information_schema.columns isc
INNER JOIN information_schema.Tables ist ON ist.Table_Catalog = isc.Table_Catalog
	AND ist.Table_Schema = isc.Table_Schema
	AND ist.Table_Name = isc.Table_Name
	AND ist.Table_Type = 'Base Table'

--===== Remember how many columns there are
    SET @Columns = @@ROWCOUNT
--===== Add a primary key to the result table (just 'cuz)
  ALTER TABLE #ColumnData
    ADD PRIMARY KEY CLUSTERED (ROWNUM) WITH FILLFACTOR = 100
--===== Loop through the column data and find the actual max data length for each
    SET @Counter = 1
  WHILE @Counter <= @Columns
  BEGIN
         SELECT @SQL = 'UPDATE #ColumnData SET '
                     + 'MaxActualDataLength=(SELECT MAX(DATALENGTH(['+ColumnName+'])) FROM ['+TableSchema+'].['+TableName+'])' 
                     + 'WHERE RowNum='+CAST(@Counter AS VARCHAR(10))
           FROM #ColumnData
          WHERE RowNum = @Counter
--PRINT @SQL
           EXEC (@SQL)
            SET @Counter = @Counter+1
    END
--===== Display the columns not fully utilized in order of worst usage of the length
     -- Note that NULL columns contain no data at all.
     -- Note that this does NOT find columns that have been RPadded to max length (yet).
 SELECT *,DefinedLength-MaxActualDataLength AS MinUnused
   FROM #ColumnData 
  WHERE ISNULL(MaxActualDataLength,0)<DefinedLength
  ORDER BY CASE WHEN MaxActualDataLength IS NULL THEN 9999
                ELSE DefinedLength-MaxActualDataLength 
                END  DESC,TableName,ColumnName