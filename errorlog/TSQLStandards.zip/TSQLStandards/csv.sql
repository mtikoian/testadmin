DECLARE @Files TABLE (FileName varchar(100));
declare @SQL varchar(max),
        @FilePath varchar(100),
        @FileName varchar(100);
set @FilePath = 'C:\';
set @SQL = 'dir /b ' + @FilePath;
INSERT INTO @Files execute xp_cmdshell @SQL;

CREATE TABLE #temp (FileData varchar(max));
declare cursor cFiles FOR
select FileName from @Files;
open cFiles;
fetch next from cFiles into @FileName;
while @@fetch_status = 0 begin
  set @FileName = @FilePath + @FileName;
  set @SQL = 'BULK INSERT #temp FROM ''' + @FileName + '''';
  EXEC (@SQL);
  if charindex('filename1 match criteria', @FileName) > 0
    insert into <base table1> (column list)
    select substring(FileData, startpos, NumberOfChars) Field1,
           substring(FileData, startpos, NumberOfChars) Field2 -- repeat as necessary
      from #temp
  else if charindex('filename2 match criteria', @FileName) > 0
    insert into <base table2> (column list)
    select substring(FileData, startpos, NumberOfChars) Field1,
           substring(FileData, startpos, NumberOfChars) Field2 -- repeat as necessary
      from #temp
  else (repeat for all 50+ types of files

  fetch next from cFiles into @FileName
end
close cFiles
deallocate cFiles


/**********************************************************************************************************************
 Purpose:
 Script to read from a TSV (Tab Separated Values) table having an unknown number of columns of unknown data type.
 This demo is setup to read a given file called Artists_mini.txt located in C:\Temp.  I'm saving the "any file"
 version for an article Wink

 Author: Jeff Moden - 28 Aug 2008
**********************************************************************************************************************/
--===== Declare the local variables we'll need. Names are self-documenting
DECLARE @RootKey       SYSNAME,
        @Key           SYSNAME,
        @Value_Name    SYSNAME,
        @Type          SYSNAME,
        @PreviousValue SYSNAME,
        @NewValue      SYSNAME

--===== Preset the "constants".  These are self documenting as well
 SELECT @RootKey    = N'HKEY_LOCAL_MACHINE',
        @Key        = N'SOFTWARE\Microsoft\Jet\4.0\Engines\Text',
        @Value_Name = N'Format',
        @Type       = N'REG_SZ',
        @NewValue   = N'TabDelimited' --May be a character using N'Delimited(,)' where the comma is the character
                                      --Original setting is usually N'CSVDelimited' which handles quote text qualifiers too.

--===== Remember the previous value so we can set it back
   EXEC Master.dbo.xp_Instance_RegRead
        @RootKey    = @RootKey,
        @Key        = @Key,
        @Value_Name = @Value_Name,
        @Value      = @PreviousValue OUTPUT

--===== Show what the original delimeter setting was set to.
     -- This, of course, may be commented out
 SELECT 'Previous delimiter setting = ' + @PreviousValue  

--===== All set... define the new temporary delimiter
   EXEC Master.dbo.xp_Instance_RegWrite
        @RootKey    = @RootKey,
        @Key        = @Key,
        @Value_Name = @Value_Name,
        @Type       = @Type,
        @Value      = @NewValue

--===== Read the TAB delimited file without knowing any of the columns
     -- Notes: "Database =" identifies the directory the file is in
     --        The FROM clause identifies the file name
     
 SELECT * 
   FROM OPENROWSET('Microsoft.Jet.OLEDB.4.0', 
                   'Text;Database=C:\Temp;HDR=YES;FMT=Delimited', 
                   'SELECT * FROM Artists_mini.txt')

--===== Show the content of the table we just populated
 SELECT * FROM #MyHEad

--===== Restore the original delimiter setting
   EXEC Master.dbo.xp_Instance_RegWrite
        @RootKey    = @RootKey,
        @Key        = @Key,
        @Value_Name = @Value_Name,
        @Type       = @Type,
        @Value      = @PreviousValue

--===== Cleanup after the demo
   DROP TABLE #MyHead
