CREATE FUNCTION IsHighAscii(@OriginalText VARCHAR(max))
RETURNS int  
BEGIN 
  DECLARE @HighCharFound int
  SET @HighCharFound = 0
  ;WITH tally (N) as
    (SELECT TOP 1000000 row_number() OVER (ORDER BY sc1.id)
     FROM Master.dbo.SysColumns sc1
     CROSS JOIN Master.dbo.SysColumns sc2)
  
  SELECT @HighCharFound = @HighCharFound +  
    CASE 
      --ascii numbers are 48(for '0') thru 57 (for '9')
      WHEN ASCII(SUBSTRING(@OriginalText,Tally.N,1)) BETWEEN 1 AND  126  
      THEN 0
      WHEN ASCII(SUBSTRING(@OriginalText,Tally.N,1)) BETWEEN 127 AND  255  
      THEN 1
      ELSE 0 
    END
  FROM Tally           
  WHERE Tally.N <= LEN(@OriginalText)            
if @HighCharFound > 0
  SET @HighCharFound= 1
RETURN @HighCharFound
END
