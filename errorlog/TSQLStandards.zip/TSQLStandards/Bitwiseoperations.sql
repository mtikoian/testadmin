--===== Create the test data
     -- (NOT PART OF THE SOLUTION)
DECLARE @SomeTable TABLE
        (BitMask INT)
 INSERT INTO @SomeTable
        (BitMask)
 SELECT 1 UNION ALL
 SELECT 5 UNION ALL
 SELECT 7 UNION ALL
 SELECT 17 UNION ALL
 SELECT 19 UNION ALL
 SELECT 29

--===== OR it all together
SELECT SIGN(SUM((BitMask & 1)+0))
+ SIGN(SUM(((BitMask & 2)/2)+0))*2
+ SIGN(SUM(((BitMask & 4)/4)+0))*4
+ SIGN(SUM(((BitMask & 8)/8)+0))*8
+ SIGN(SUM(((BitMask & 16)/16)+0))*16
+ SIGN(SUM(((BitMask & 32)/32)+0))*32
+ SIGN(SUM(((BitMask & 64)/64)+0))*64
+ SIGN(SUM(((BitMask & 128)/128)+0))*128
+ SIGN(SUM(((BitMask & 256)/256)+0))*256
+ SIGN(SUM(((BitMask & 512)/512)+0))*512
+ SIGN(SUM(((BitMask & 1024)/1024)+0))*1024
	AS AggregateBitmask
 From @SomeTable