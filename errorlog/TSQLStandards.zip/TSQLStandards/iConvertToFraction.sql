CREATE FUNCTION dbo.iConvertToFraction(
  @Decimal decimal(18,8)
)
RETURNS TABLE WITH SCHEMABINDING
AS
RETURN
  SELECT CAST(FLOOR(@Decimal) AS varchar(20)) + fraction AS FractionNum
  FROM (VALUES(0 , '')    , (1 , ' 1/16') , (2 , ' 1/8'), (3 , ' 3/16'),
              (4 , ' 1/4'), (5 , ' 5/16') , (6 , ' 3/8'), (7 , ' 7/16'),
              (8 , ' 1/2'), (9 , ' 9/16') , (10, ' 5/8'), (11, ' 11/16'),
              (12, ' 3/4'), (13, ' 13/16'), (14, ' 7/8'), (15, ' 15/16'))x(n,fraction)
  WHERE ROUND((@Decimal- FLOOR(@Decimal))*16,0)/16 = n/16.
GO

SELECT *
FROM (VALUES(5),(2.5),(3.47),(1.75),(pi()))x(num)
CROSS APPLY dbo.iConvertToFraction( x.num) f