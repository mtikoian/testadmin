
--===== If the function that programmatically creates suitably variable CSV values already exists,
     -- drop it to make reruns in SSMS easier.
     IF OBJECT_ID('dbo.CreateCsv8K') IS NOT NULL
        DROP FUNCTION dbo.CreateCsv8K
;
--===== Create the function that programatically creates suitably variable CSV values.
GO
 CREATE FUNCTION dbo.CreateCsv8K
/**********************************************************************************************************************
 Purpose:
 Create a CSV table result with a programmable number of rows, elements per row, minimum # of characters per element,
 and maximum characters per element.  The element size is random in nature constrained by the min and max characters
 per element.

 Usage:
 SELECT * FROM dbo.CreateCsv8K(@pNumberOfRows, @pNumberOfElementsPerRow, @pMinElementwidth, @pMaxElementWidth)

 Dependencies:
 1. View: dbo.iFunction (Produces a NEWID() usable from within a UDF)

 Programmer's Notes:
 1. The randomness of the elements prevents the delimiters for showing up in the same position for each row so that
    SQL Server won't figure that out and cache the information making some splitting techniques seem faster than they
    really are.
 2. No validation or constraints have been place on the input parameters so use with caution.  This code can generate
    a lot of data in a couple of heart beats.

 Revision History:
 Rev 00 - 11 May 2007 - Jeff Moden - Initial creation - Only returned one row and wasn't programmable.
 Rev 01 - 26 Jul 2009 - Jeff Moden - Added programmable variables but would only go to 20 characters wide.
 Rev 02 - 06 Mar 2011 - Jeff Moden - Converted to iTVF, added minimum element width, and made it so elements can be
                                     virtually any size within 8k Bytes.
 Rev 03 - 14 Sep 2015 - Jeff Moden - Changed content of each element from a simple number to be much more complex
                                     and to include letters instead of just digits by using part of a NEWID().
**********************************************************************************************************************/
--===== Declare the I/0
        (
        @pNumberOfRows           INT,
        @pNumberOfElementsPerRow INT,
        @pMinElementwidth        INT,
        @pMaxElementWidth        INT
        )
RETURNS TABLE
     AS
 RETURN
--===== This creates and populates a test table on the fly containing a
     -- sequential column and a randomly generated CSV Parameter column.
 SELECT TOP (@pNumberOfRows) --Controls the number of rows in the test table
        ISNULL(ROW_NUMBER() OVER (ORDER BY(SELECT NULL)),0) AS RowNum,
        CSV =
        (--==== This creates each CSV
         SELECT CAST(
                    STUFF( --=== STUFF get's rid of the leading comma
                         ( --=== This builds CSV row with a leading comma
                          SELECT TOP (@pNumberOfElementsPerRow) --Controls the number of CSV elements in each row
                                 ','
                               + LEFT(--==== Builds random length variable within element width constraints
                                      LEFT(REPLICATE((SELECT RIGHT(MyNewID,10) FROM dbo.iFunction)
                                                    ,CEILING(@pMaxElementWidth/10.0))
                                          ,@pMaxElementWidth),
                                      ABS(CHECKSUM((SELECT MyNewID FROM dbo.iFunction)))
                                            % (@pMaxElementWidth - @pMinElementwidth + 1) + @pMinElementwidth
                                     )
                            FROM      sys.All_Columns ac3       --Classic cross join pseudo-cursor
                           CROSS JOIN sys.All_Columns ac4       --can produce row sets up 16 million.
                           WHERE ac3.Object_ID <> ac1.Object_ID --Without this line, all rows would be the same.
                             FOR XML PATH('')
                         )
                    ,1,1,'')
                AS VARCHAR(8000))
        )
   FROM      sys.All_Columns ac1 --Classic cross join pseudo-cursor
  CROSS JOIN sys.All_Columns ac2 --can produce row sets up 16 million rows
;
GO
--===========================================================================
--      Create the stored procedure to create and populate the "ProdTable"
--      table for the demo.
--      Usage: EXEC dbo.CreateProdTable
                  -- @pNumberOfRows           INT
                  --,@pNumberOfElementsPerRow INT
                  --,@pMinElementwidth        INT
                  --,@pMaxElementWidth        INT;
--===========================================================================
--===== If the procedure already exists, drop it to make reruns in SSMS easier.
     IF OBJECT_ID('dbo.CreateProdTable','P') IS NOT NULL
        DROP PROCEDURE dbo.CreateProdTable
;
GO
 CREATE PROCEDURE dbo.CreateProdTable
                   @pNumberOfRows           INT
                  ,@pNumberOfElementsPerRow INT
                  ,@pMinElementwidth        INT
                  ,@pMaxElementWidth        INT
     AS
--===== Create and populate the "ProdTable" table
     IF OBJECT_ID('dbo.ProdTable','U') IS NOT NULL
        DROP TABLE dbo.ProdTable;
--===== Create the table
 CREATE TABLE dbo.ProdTable
        (
         RowNum INT IDENTITY(1,1)
        ,String NVARCHAR(4000)
        )
;
/*
DECLARE @RowCounter INTEGER = 0;
WHILE @RowCounter < @pNumberOfRows
BEGIN
--*/
            --===== Populate the table
             INSERT dbo.ProdTable
                                    (String)
             SELECT CSV
               FROM dbo.CreateCsv8K
                                                (
                                                 --1
                                                 @pNumberOfRows
                                                ,@pNumberOfElementsPerRow
                                                ,@pMinElementwidth
                                                ,@pMaxElementWidth
                                                )
              WHERE RowNum > 0  --MUST be included to keep from creating "grooved" data.
OPTION (QUERYTRACEON 9481)
            ;
/*
            SET @RowCounter = @RowCounter + 1;
END;
--*/
GO
EXEC dbo.CreateProdTable 10000, 165, 1, 25;
GO
PRINT 'All Done'

select * from dbo.Prodtable;