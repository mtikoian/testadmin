CREATE FUNCTION dbo.RemoveSplitPattern
        (
        @pString    VARCHAR(8000),
        @pDelimiter VARCHAR(1),
        @pPattern   VARCHAR(8000)
        )
RETURNS TABLE
     AS
 RETURN
 SELECT LTRIM
        (
             ( --== Split the items out, reject any having the pattern, reassemble with spaces
             SELECT ' ' + SUBSTRING(@pString, t.N, CHARINDEX(@pDelimiter, @pString + @pDelimiter, t.N) - t.N)
               FROM dbo.Tally t
              WHERE N BETWEEN 1 AND LEN(@pString)
                AND SUBSTRING(@pDelimiter + @pString, t.N, 1) = @pDelimiter
                AND SUBSTRING(@pString, t.N, CHARINDEX(@pDelimiter, @pString + @pDelimiter, t.N) - t.N) NOT LIKE @pPattern 
              ORDER BY t.N
                FOR XML PATH('') 
             ) 
        ) AS ITEM