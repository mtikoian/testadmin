DECLARE @Year int = 2014;
	SET DATEFIRST 1;

	WITH Tally(n) AS(
		SELECT TOP 400 DATEADD( dd, ROW_NUMBER() OVER( ORDER BY (SELECT NULL)), (SELECT MAX(fecha) FROM DWESTRELLAS.dbo.dimDate WHERE WeekYear = @Year - 1))
		FROM sys.all_columns),
	cteDays AS(
		SELECT n AS cal_date,
			DATEADD( WEEK, DATEDIFF( WEEK, 0, n - 1), 0) AS Monday,
			DATEADD( DAY, 6, DATEADD( WEEK, DATEDIFF( WEEK, 0, n - 1), 0)) AS Sunday
		FROM Tally
	)
	SELECT CONVERT( char(8), cal_date, 112) idDate,
		CAST( cal_date AS smalldatetime) cal_date,
		YEAR( cal_date) cal_year,
		MONTH( cal_date) cal_month,
		DAY( cal_date) cal_day,
		DATEPART( DAYOFYEAR, cal_date) day_year,
		YEAR( Sunday) WeekYear,
		DATEPART( WEEK, Sunday) cal_Week,
		DATEPART( QUARTER, cal_date) cal_Quarter,
		UPPER(REPLACE( CONVERT( char(6), Monday, 113), ' ', '')) + '-' 
			+ UPPER(REPLACE( CONVERT( char(6), Sunday, 113), ' ', '')) week_desc,
		UPPER( CONVERT( char(6), Sunday, 113)) SundayDesc,
		DATEPART( WEEKDAY, cal_date) cal_weekday,
		UPPER( DATENAME( WEEKDAY, cal_date)) weekdayName,
		CAST( YEAR( Sunday) AS CHAR(4)) + RIGHT( '0' + CAST( DATEPART( WEEK, Sunday) AS varchar(2)), 2) idSemana,
		CASE WHEN DATEPART( DAY, Sunday) > 3 
			THEN UPPER( RIGHT( CONVERT( char(6), Sunday, 113), 3)) + '-' + RIGHT( YEAR(Sunday), 2) 
			ELSE UPPER( RIGHT( CONVERT( char(6), Monday, 113), 3)) + '-' + RIGHT( YEAR(Monday), 2) END
		 MonthDesc
	FROM cteDays
	WHERE YEAR( Sunday) = @Year




DECLARE @StartDate date= '2005-01-01',
	@EndDate date = '2016-01-01';

WITH tally(n) AS 
(
	SELECT TOP (DATEDIFF(dd,@startDate,@endDate)+1)
			ROW_NUMBER() OVER (ORDER BY (SELECT ($)))-1
	FROM sys.all_columns a CROSS JOIN sys.all_columns b
),
daterange(dt) AS
(
	SELECT DATEADD(DD,n,@StartDate)
	FROM tally
)
--INSERT dbo.DimDate
	SELECT	
		DateKey =		REPLACE(CONVERT(CHAR(10),dt),'-',''),
		FullDateAlternateKey =	dt,
		DateString =		CONVERT(varchar(10),dt,105),
		[DayOfWeek] =		DATEPART(weekday,dt),
		[DayOfWeekName] =	DATENAME(weekday,dt),
		[DayOfMonth] =		DATEPART(dd,dt),
		[DayOfYear] =		DATEPART(dy,dt),
		[WeekOfYear] =		DATEPART(wk,dt),
		[MonthName] =		DATENAME(mm,dt),
		[MonthOfYear] =		DATEPART(mm,dt),
		[CalendarQuarter] =	DATEPART(qq,dt),
		CalendarYear =		YEAR(dt),
		IsWeekend =				
			CASE 
				WHEN DATEPART(weekday,dt) IN(1,7) 
					THEN 1 ELSE 0 END,
		isLeapYear =
			CASE 
				WHEN ((Year(dt) % 4 = 0)
					   AND (Year(dt) % 100 <> 0 
					   OR Year(dt) % 400 = 0)) 
					THEN 1 ELSE 0 END
	FROM daterange;