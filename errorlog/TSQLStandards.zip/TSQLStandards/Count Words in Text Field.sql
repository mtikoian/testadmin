DROP TABLE #TempSplit


--===== Create a table to hold some test data.
     -- This isn't part of the solution.
 CREATE TABLE #TempSplit
        (
        SomeUniqueIdentifier INT IDENTITY(1,1),
        MyData               VARCHAR(200)
        )
;
--===== Populate the test table with some test data.
     -- This isn't part of the solution.
 INSERT INTO #TempSplit
        (MyData)
 SELECT 'My SQL skills are broken' UNION ALL
 SELECT 'SQL Server Central rocks' UNION ALL
 SELECT 'My dog at my computer' UNION ALL
 SELECT 'The dog programs average for a dog' UNION ALL
 SELECT 'sql lower case SQL upper CASE' UNION ALL
 SELECT '111 222 3333 111' 
;
--===== Demonstrate a simple "split" with the necessary
     -- columns to potentially do a proximity search as
     -- well as other things.
 SELECT source.SomeUniqueIdentifier,
        WordPosition = split.ItemNumber,
        Word         = split.Item
   INTO #SplitWord
   FROM #TempSplit source
  CROSS APPLY dbo.f_DelimitedSplit8K(MyData,' ') split
;
--===== Show the simple content of the table
 SELECT *
   FROM #SplitWord
  ORDER BY SomeUniqueIdentifier, WordPosition
;
--===== Show a simple count of the different words.
 SELECT Word, COUNT(*)
   FROM #SplitWord
  GROUP BY Word
;