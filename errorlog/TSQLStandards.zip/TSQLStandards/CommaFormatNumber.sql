CREATE FUNCTION dbo.CommaFormatNumber
/***************************************************************************************************
 Purpose:
 To convert any numeric value that can be converted to the MONEY data to a right aligned
 string formatted with commas and rounded or truncated to the desired number of decimal 
 places.

 Programmer notes:
 1. Notes on inputs
        @SomeNumber : Must be implicitly convertable to the MONEY datatype.
        @ColWidth   : Must be large enough to hold the final formatted data.
        @DecPlaces  : Must be from 0 to 4 decimal places.
        @Suffix     : Can be any varchar up to 25 characters.  May be NULL.
        @Truncate   : If NULL or 0, then rounds to # of desired decimal places.
                    : If < 0 or > 0, then truncates to the # of desired decimal places.
 2. If any errors occur, then will produce an error with the reason for the error rather
    than returning a string of astericks as many other programs do.

 SELECT pod.DueDate,
        Quantity  = CONVERT(CHAR( 8),ca1.FormattedNumber),
        UnitPrice = CONVERT(CHAR(10),ca2.FormattedNumber),
        LineTotal = CONVERT(CHAR(14),ca3.FormattedNumber)
   FROM AdventureWorks.Purchasing.PurchaseOrderDetail pod
  CROSS APPLY dbo.CommaFormatNumber(pod.OrderQty ,8,0,NULL,NULL)ca1
  CROSS APPLY dbo.CommaFormatNumber(pod.UnitPrice,10,4,'ea',0)ca2
  CROSS APPLY dbo.CommaFormatNumber(pod.OrderQty*UnitPrice,14,2,NULL,NULL)ca3    

 Usage:
--===== Basic Syntax
 SELECT FormattedNumber 
   FROM dbo.CommaFormatNumber(@SomeNumber,@ColWidth,@DecPlaces,@Suffix,@Truncate)
;
--===== Example of formatting multiple columns from a table
 SELECT pod.DueDate,
        Quantity = ca1.FormattedNumber,
        UnitPrice = ca2.FormattedNumber,
        LintTotal = ca3.FormattedNumber
   FROM AdventureWorks.Purchasing.PurchaseOrderDetail pod
  CROSS APPLY dbo.CommaFormatNumber(pod.OrderQty ,8,0,NULL,NULL)ca1
  CROSS APPLY dbo.CommaFormatNumber(pod.UnitPrice,10,4,'ea',0)ca2
  CROSS APPLY dbo.CommaFormatNumber(pod.OrderQty*UnitPrice,14,2,NULL,NULL)ca3
;
--===== Example of returning data to the TEXT screen (can use with SELECT/INTO). 
--      If returning the data to the screen in the text mode or using SELECT/INTO to build
--      the proper width columns, you'll have to add a bit of extra code to control
--      the actual column width like this...
 SELECT pod.DueDate,
        Quantity  = CONVERT(CHAR( 8),ca1.FormattedNumber),
        UnitPrice = CONVERT(CHAR(10),ca2.FormattedNumber),
        LineTotal = CONVERT(CHAR(14),ca3.FormattedNumber)
   FROM AdventureWorks.Purchasing.PurchaseOrderDetail pod
  CROSS APPLY dbo.CommaFormatNumber(pod.OrderQty ,8,0,NULL,NULL)ca1
  CROSS APPLY dbo.CommaFormatNumber(pod.UnitPrice,10,4,'ea',0)ca2
  CROSS APPLY dbo.CommaFormatNumber(pod.OrderQty*UnitPrice,14,2,NULL,NULL)ca3
;
 Revision History:
 Rev 00 - 17 Mar 2013 - Jeff Moden 
        - Initial creation to answer problem at the following URL.
          http://www.sqlservercentral.com/Forums/Topic1430680-1292-1.aspx#bm1431888
***************************************************************************************************/
--===== Declare the IO for this function
        (
        @SomeNumber MONEY,
        @ColWidth   TINYINT,
        @DecPlaces  TINYINT,
        @Suffix     VARCHAR(8000),
        @Truncate   TINYINT
        )
RETURNS TABLE WITH SCHEMABINDING AS
 RETURN
   WITH cteRoundedValue AS
        ( --=== Round or truncate the value to the desired number of decimal places.
         SELECT RoundedMoney = ROUND(@SomeNumber,@DecPlaces,@Truncate)
        ),
        ctePreFormattedStrings AS
        ( --==== Add the commas and split out the decimal data
          SELECT WithCommas = CONVERT(VARCHAR(25),RoundedMoney,1),
                 Decimals   = RIGHT(CONVERT(VARCHAR(25),RoundedMoney,2),5)
            FROM cteRoundedValue
        ),
        cteSimpleFormattedString AS
        ( --=== Split out the formatted integer and add the desired number of decimal places
         SELECT SimpleFormattedString = 
                    SUBSTRING(WithCommas,1,CHARINDEX('.',WithCommas)-1)
                  + CASE WHEN @DecPlaces > 0 THEN LEFT(Decimals,@DecPlaces+1) ELSE '' END
                  + ISNULL(' ' + @Suffix,'')
           FROM ctePreFormattedStrings
        ) --=== Return the right aligned string with error checking
 SELECT FormattedNumber = RIGHT(SPACE(@ColWidth) + SimpleFormattedString, @ColWidth)
   FROM cteSimpleFormattedString
  WHERE 1 = CASE
                WHEN @DecPlaces NOT BETWEEN 0 AND 4 
                THEN CONVERT(INT,'Number of decimal places must be between 0 and 4.')
                WHEN LEN(SimpleFormattedString) > @ColWidth
                THEN CONVERT(INT,QUOTENAME(SimpleFormattedString,'"') + ' is too big for column width.')
                ELSE 1
            END
;
GO