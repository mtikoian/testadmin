-- Drop stored procedure if it already exists
IF EXISTS (
SELECT 1
FROM INFORMATION_SCHEMA.ROUTINES
WHERE SPECIFIC_SCHEMA = N'dbo'
AND SPECIFIC_NAME = N'p_Scrub_columns_Data'
)
BEGIN
DROP PROCEDURE dbo.p_Scrub_columns_Data;

PRINT 'PROCEDURE dbo.p_Scrub_columns_Data has been dropped.';
END;
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER OFF
GO

CREATE PROCEDURE dbo.p_Scrub_columns_Data
 @param   VARCHAR(20) = NULL
WITH ENCRYPTION
--EXECUTE AS OWNER

AS
BEGIN /*----Procedure Begin*/
SET NOCOUNT ON
    print 'SQL Start Time: ' +  + convert(varchar(30), getdate(), 121);   
    print '';
/*-------------------------Drop temp tables-------------------------------------------*/
IF OBJECT_ID('tempdb..#tempmask') IS NOT NULL
DROP TABLE #tempmask

-- Local declarations
DECLARE @sqlcmd NVARCHAR(max);
DECLARE @ErrorMessage NVARCHAR(4000);
DECLARE @ErrorSeverity INTEGER;
DECLARE @ErrorState INTEGER;
DECLARE @rowcount INT;
DECLARE @txt VARCHAR(40);
DECLARE @INFORMATION NVARCHAR(4000);
DECLARE @max INT;
DECLARE @cnt INT;
DECLARE @lstr VARCHAR(200);
DECLARE @tablename VARCHAR(30);
DECLARE @columnname VARCHAR(50);
DECLARE @DB_admin TABLE (
DB_Nme VARCHAR(50)
,Schema_nme CHAR(50)
,tablename VARCHAR(100)
,columnname VARCHAR(100)
,Status_fl CHAR(1)
)

--temp table
CREATE TABLE #tempmask (
prefix NVARCHAR(1000)
,updatecolumns NVARCHAR(4000)
)

--Set variables
SET @ErrorMessage = '';
SET @ErrorSeverity = 0;
SET @ErrorState = 0;
SET @rowcount = 0;
SET @INFORMATION = '';

INSERT INTO @DB_admin (
DB_Nme
,Schema_nme
,tablename
,columnname
,Status_fl
) (
SELECT DB_Nme AS DB_Nme
,Schema_nme AS schema_nme
,Table_Nme AS tablename
,Column_Nme AS columnname
,Status_fl AS Status_fl FROM db_admin
)

--Delete columns with status 0
DELETE @DB_admin
WHERE Status_fl < 1

INSERT INTO #tempmask
SELECT 'update ' + rtrim(ltrim(db_nme)) + '.' + rtrim(ltrim(Schema_nme)) + '.' + '['+tablename +']'+ ' set ' AS Prefix
,STUFF((
SELECT columnname + ' = dbo.f_scrambledata(' + columnname + ')' + ', '
--' = replace(' + columnname + case when IsNumber = 1 then ', 1, 2)' else ', ''S'', ''t'')' end + ', ' 
FROM @DB_admin u2
WHERE u2.tablename = u1.tablename
AND u2.Schema_nme = u1.Schema_nme
FOR XML path('')
), 1, 0, '') AS UpdateColumns
FROM @DB_admin u1
GROUP BY tablename
,db_nme
,Schema_nme

-- select Prefix + left(UpdateColumns, LEN(UpdateColumns) - 1)
--from UpdateValues
--sp_executesql(@sqlcmd)
--SELECT *
--FROM #tempmask

--SELECT Prefix + left(UpdateColumns, LEN(UpdateColumns) - 1)
--FROM #tempmask
-- Cursor 
DECLARE GET_TABLES CURSOR READ_ONLY
FOR
SELECT Prefix + left(UpdateColumns, LEN(UpdateColumns) - 1)
FROM #tempmask

OPEN GET_TABLES

FETCH NEXT
FROM GET_TABLES
INTO @SQLCMD

WHILE (@@fetch_status = 0)
BEGIN --begin while loop
BEGIN TRY
EXEC (@SQLCMD)
SET @rowcount = @@rowcount
--SET @txt = left(@SQLCMD, 30)
--report which table is updated      
SET @INFORMATION = '<<<<< Table [ ' + @SQLCMD + ' ]' + ' Total records updated ' +CAST(@rowcount AS VARCHAR) + ' >>>>>';

PRINT @INFORMATION;
PRINT 'SQL END Time: ' +  + convert(varchar(30), getdate(), 121);   
PRINT '';

FETCH NEXT
FROM GET_TABLES
INTO @SQLCMD;
END TRY

BEGIN CATCH
SELECT @ErrorMessage = 'Failed to mask table ' + @SQLCMD + SPACE(2) + CAST(ERROR_NUMBER() AS NVARCHAR) + SPACE(2) + ERROR_MESSAGE()
,@ErrorSeverity = ERROR_SEVERITY()
,@ErrorState = ERROR_STATE();

RAISERROR (
@ErrorMessage
,-- Message text.
@ErrorSeverity
,-- Severity.
@ErrorState -- State.
);

FETCH NEXT
FROM GET_TABLES
INTO @SQLCMD;
END CATCH;
--
END --end while loop

CLOSE GET_TABLES;

DEALLOCATE GET_TABLES;

END