

IF EXISTS (
SELECT 1 
FROM   information_schema.Tables 
WHERE  Table_schema = 'dbo' 
  AND Table_name = 'DB_Admin'  
)
BEGIN
DROP TABLE dbo.DB_Admin
END

CREATE TABLE dbo.DB_Admin (
Admin_ID INT IDENTITY(1, 1) NOT NULL
,DB_Nme CHAR(50) NOT NULL
,Schema_Nme CHAR(5) NOT NULL
,Table_Nme VARCHAR(100) NOT NULL
,Column_Nme VARCHAR(100) NOT NULL
,Status_fl CHAR(1) NOT NULL
)
ALTER TABLE dbo.DB_Admin 
ADD CONSTRAINT PK_Admin_ID PRIMARY KEY NONCLUSTERED (Admin_ID),
CONSTRAINT UQ_Table_Nme_Column_nme UNIQUE CLUSTERED (
Table_Nme ASC
,Column_Nme ASC
) 

PRINT ''
PRINT '----------------------------------------'
PRINT 'TABLE DB_Admin created'
PRINT '----------------------------------------'


insert into db_admin
(DB_Nme ,Schema_Nme ,Table_Nme ,Column_Nme ,Status_fl)


 select 'Carrier_MyInfinity','dbo','Location','AddressStreet1' , '1'
union select 'Carrier_MyInfinity','dbo','Location','AddressCity'       , '1'
union select 'Carrier_MyInfinity','dbo','Location','AddressStreet2'	, '1'
union select 'Carrier_MyInfinity','dbo','Location','AddressPostalCode'	, '1'
union select 'Carrier_MyInfinity','dbo','User','LastName' 				, '1'
union select 'Carrier_MyInfinity','dbo','User','AddressStreet2'		, '1'
union select 'Carrier_MyInfinity','dbo','User','AddressPostalCode'		, '1'
union select 'Carrier_MyInfinity','dbo','User','PhoneNumber1SubAddress', '1'
union select 'Carrier_MyInfinity','dbo','User','PhoneNumber2' 			, '1'
union select 'Carrier_MyInfinity','dbo','User','PhoneNumber2Formatted'	, '1'
union select 'Carrier_MyInfinity','dbo','User','FirstName'				, '1'
union select 'Carrier_MyInfinity','dbo','User','AddressStreet1'		, '1'
union select 'Carrier_MyInfinity','dbo','User','AddressCity'			, '1'
union select 'Carrier_MyInfinity','dbo','User','PhoneNumber1'			, '1'
union select 'Carrier_MyInfinity','dbo','User','PhoneNumber1Formatted'	, '1'
union select 'Carrier_MyInfinity','dbo','User','PhoneNumber2SubAddress', '1'
go

if exists (
    select 1
    from information_schema.ROUTINES
    where SPECIFIC_SCHEMA = 'dbo'
      and ROUTINE_NAME = 'f_scrambledata'
      and ROUTINE_TYPE = 'Function'
        ) 
begin
    drop function dbo.f_scrambledata
end
go

CREATE FUNCTION dbo.f_scrambledata (@txt VARCHAR(MAX))
RETURNS VARCHAR(MAX)
WITH ENCRYPTION
AS
BEGIN
-- ===================================================================================================
-- ===================================================================================================
SELECT @txt = replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(@txt, 's', 't'), 'j', 'a'), 'i', 'b'), 'p', 'z'), 'y', 'q'), 'r', 'u'), 'w', 'd'), 'q', 'e'), 'f', 'l'), 'g', 'n'), 'k', 'h'), 'null', 'null'), 'com', 'com'), 'a', 'v'), 'b', 'i'), 'f', 'j'), 'd', 'u'), 'e', 's'), '1', '2'), '3', '7'), '6', '4'), '8', '0'), '5', '1'), '2', '0'), '7', '5'), '4', '1'), '8', '2'), '3', '6'), '8', '3'), '7', '9'), '0', '5'), '6', '1')

RETURN (@txt)
END
GO