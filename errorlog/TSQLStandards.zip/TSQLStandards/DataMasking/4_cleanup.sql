
IF EXISTS (
SELECT 1 
FROM   information_schema.Tables 
WHERE  Table_schema = 'dbo' 
  AND Table_name = 'DB_Admin'  
)
BEGIN
DROP TABLE dbo.DB_Admin
END
go
if exists (
    select 1
    from information_schema.ROUTINES
    where SPECIFIC_SCHEMA = 'dbo'
      and ROUTINE_NAME = 'f_scrambledata'
      and ROUTINE_TYPE = 'Function'
        ) 
begin
    drop function dbo.f_scrambledata
end
go

IF EXISTS (
SELECT 1
FROM INFORMATION_SCHEMA.ROUTINES
WHERE SPECIFIC_SCHEMA = N'dbo'
AND SPECIFIC_NAME = N'p_Scrub_columns_Data'
)
BEGIN
DROP PROCEDURE dbo.p_Scrub_columns_Data;

PRINT 'PROCEDURE dbo.p_Scrub_columns_Data has been dropped.';
END;
GO