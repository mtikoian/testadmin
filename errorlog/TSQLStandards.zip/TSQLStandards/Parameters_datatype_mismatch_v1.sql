;WITH userColumns AS  
( SELECT 
  c.NAME AS columnName,
  OBJECT_SCHEMA_NAME(c.object_ID) + '.' + OBJECT_NAME(c.object_ID) AS ObjectName,
  REPLACE(t.name + ' ' 
  + CASE WHEN is_computed = 1 THEN ' AS ' + --do DDL for a computed column
          (SELECT definition FROM sys.computed_columns cc
           WHERE cc.object_id = c.object_id AND cc.column_ID = c.column_ID) 
    --we may have to put in the length   
         WHEN t.Name IN ('char', 'varchar', 'nchar', 'nvarchar')
             THEN '(' 
              + CASE WHEN c.Max_Length = -1 THEN 'MAX'
                ELSE CONVERT(VARCHAR(4),
                    CASE WHEN t.Name IN ('nchar', 'nvarchar')
                      THEN c.Max_Length / 2 ELSE c.Max_Length
                    END)
                END + ')'
       WHEN t.name IN ('decimal', 'numeric')
       THEN '(' + CONVERT(VARCHAR(4), c.precision) + ',' + CONVERT(VARCHAR(4), c.Scale) + ')'
       ELSE ''
      END + CASE WHEN c.is_rowguidcol = 1
          THEN ' ROWGUIDCOL'
          ELSE ''
         END + CASE WHEN XML_collection_ID <> 0
            THEN --deal with object schema names
             '(' + CASE WHEN is_XML_Document = 1
                THEN 'DOCUMENT '
                ELSE 'CONTENT '
               END + COALESCE((SELECT
                QUOTENAME(ss.name) + '.' + QUOTENAME(sc.name)
                FROM
                sys.xml_schema_collections sc
                INNER JOIN Sys.Schemas ss ON sc.schema_ID = ss.schema_ID
                WHERE
                sc.xml_collection_ID = c.XML_collection_ID),
                'NULL') + ')'
            ELSE ''
           END + CASE WHEN is_identity = 1
             THEN CASE WHEN OBJECTPROPERTY(object_id,
                'IsUserTable') = 1 AND COLUMNPROPERTY(object_id,
                c.name,
                'IsIDNotForRepl') = 0 AND OBJECTPROPERTY(object_id,
                'IsMSShipped') = 0
                THEN ''
                ELSE ' NOT FOR REPLICATION '
               END
             ELSE ''
            END + CASE WHEN c.is_nullable = 0
               THEN ' NOT NULL'
               ELSE ' NULL'
              END + CASE
                WHEN c.default_object_id <> 0
                THEN ' DEFAULT ' + object_Definition(c.default_object_id)
                ELSE ''
               END + CASE
                WHEN c.collation_name IS NULL
                THEN ''
                WHEN c.collation_name <> (SELECT
                collation_name
                FROM
                sys.databases
                WHERE
                name = DB_NAME()) COLLATE Latin1_General_CI_AS
                THEN COALESCE(' COLLATE ' + c.collation_name,
                '')
                ELSE ''
                END,'  ',' ') AS [DataType]
FROM sys.columns c
  INNER JOIN sys.types t ON c.user_Type_ID = t.user_Type_ID
  WHERE OBJECT_SCHEMA_NAME(c.object_ID) <> 'sys'

)
SELECT CONVERT(CHAR(80),objectName+'.'+columnName),DataType FROM UserColumns
WHERE columnName IN 
(SELECT columnName FROM UserColumns 
 GROUP BY columnName 
 HAVING MIN(Datatype)<>MAX(DataType))
ORDER BY columnName 