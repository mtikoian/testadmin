--===== If the demonstration table exists, drop it
     IF OBJECT_ID('TempDB.dbo.#MyHead') IS NOT NULL
        DROP TABLE #MyHead
GO

--===== Create the demonstration table
 CREATE TABLE #MyHead
        (
        RowNum        INT, --<<This will be the column we update
        SomeValue     INT 
        )

--===== Populate the table with 1,000,000 rows worth of random numbers (SomeValue)
     -- to simulate some form of data
 INSERT INTO #MyHead (SomeValue)
 SELECT TOP 1000000
        RAND(CAST(NEWID() AS VARBINARY))*2147483647+1
   FROM Master.dbo.SysColumns sc1,
        Master.dbo.SysColumns sc2

--=========================================================================
--===== Ok, our demo table is setup and we're ready to test
--=========================================================================
--===== Declare a counter variable...
DECLARE @MyCounter INT
    SET @MyCounter = 0

--===== Do the update with sequential numbers...LOOK MA!!! NO LOOP!!
     -- On my desktop box, it only takes 6 seconds to complete.
 UPDATE #MyHead
    SET @MyCounter = RowNum = @MyCounter + 1

--===== Now, let's check the table...
 SELECT * FROM #MyHead ORDER BY RowNum