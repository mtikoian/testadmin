DROP TABLE #File
GO
--===== Create a holding table for the file names
 CREATE TABLE #File
        (
        FileName    SYSNAME,
        Depth       TINYINT,
        IsFile      TINYINT
        )
;
--===== Capture the names in the desired directory
     -- (Change "C:\Temp" to the directory of your choice)
 INSERT INTO #File
        (FileName, Depth, IsFile)
 EXEC xp_DirTree 'd:\Temp\',1,1
;
--===== Find the latest file using the "constant" characters
     -- in the file name and the ISO style date.
 SELECT TOP 1 
        FileName
   FROM #File
  WHERE IsFile = 1
    AND FileName LIKE 'MyDB__20[0-9][0-9][0-1][0-9][0-3][0-9]__[0-2][0-9][0-5][0-9].bak' ESCAPE '_'
  ORDER BY FileName DESC
;