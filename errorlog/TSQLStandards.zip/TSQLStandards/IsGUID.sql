CREATE FUNCTION dbo.IsGUID
/*******************************************************************************
 Purpose:
 If the given string parameter matches the format of GUID, return a 1.
 Otherwise, return a 0.

 Notes:
 1. This is what Microsoft refers to as an "Inline Scalar Function" and it's
    MUCH faster than a regular or classic Scalar Function.

 Example Batch Usage:
 SELECT st.SomeVarcharColumn,
        ig.IsGUID
   FROM dbo.SomeTable st
  CROSS APPLY dbo.IsGUID(st.SomeVarcharColume) ig

 Example Single Variable Usage:
 SELECT IsGUID
   FROM dbo.IsGUID(@SomeString)

 Revision History:
 Rev 00 - 2 Jul 2012 - Jeff Moden - Initial creation 
          Ref: http://www.sqlservercentral.com/Forums/Topic1323353-392-1.aspx
*******************************************************************************/
        (@pSomeString VARCHAR(100))
RETURNS TABLE WITH SCHEMABINDING AS
 RETURN
 SELECT IsGuid = CASE
                     WHEN @pSomeString LIKE '[0-9A-F][0-9A-F][0-9A-F][0-9A-F][0-9A-F][0-9A-F][0-9A-F][0-9A-F]-[0-9A-F][0-9A-F][0-9A-F][0-9A-F]-[0-9A-F][0-9A-F][0-9A-F][0-9A-F]-[0-9A-F][0-9A-F][0-9A-F][0-9A-F]-[0-9A-F][0-9A-F][0-9A-F][0-9A-F][0-9A-F][0-9A-F][0-9A-F][0-9A-F][0-9A-F][0-9A-F][0-9A-F][0-9A-F]'
                     THEN 1 
                     ELSE 0
                 END
;