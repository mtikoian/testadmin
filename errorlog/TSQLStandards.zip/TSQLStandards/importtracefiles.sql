if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ImportTraceData]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ImportTraceData]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO




----------------------------------------------------------------------------
-- Insert a single record into AccountsDetail_Dividends
----------------------------------------------------------------------------
CREATE PROC dbo.ImportTraceData
	
AS


DECLARE @sql varchar(1000)
DECLARE @SrcDir varchar(1000)
DECLARE @File  varchar(1000)
DECLARE @FullPath  varchar(1000)
DECLARE @LastAudit  datetime
DECLARE @Test varchar(1000)
DECLARE @out int
DECLARE @RowCount bigint
DECLARE @TraceID int

--Find the trace we are interested in: 

IF OBJECT_ID('tempdb..#TraceTemp') IS NOT NULL DROP TABLE #TraceTemp

CREATE TABLE #TraceTemp (TraceID int, Property int, Value sql_variant)

INSERT INTO #TraceTemp SELECT * FROM ::fn_trace_getinfo(0)

Select @TraceID = TraceID From #TraceTemp Where Value = 'C:\Test'

IF OBJECT_ID('tempdb..#TraceTemp') IS NOT NULL DROP TABLE #TraceTemp

--Stop it, then delete it:

IF @TraceID is not null
BEGIN
EXEC sp_trace_setstatus @traceid = @TraceID , @status = 0
EXEC sp_trace_setstatus @traceid = @TraceID , @status = 2
END

--Import data from the trace files:
IF OBJECT_ID('tempdb..#LogFileList') IS NOT NULL DROP TABLE #LogFileList
IF OBJECT_ID('tempdb..#DeleteFileList') IS NOT NULL DROP TABLE #DeleteFileList

create table #LogFileList (fname varchar(255))
create table #DeleteFileList (fname varchar(255),FileOrder as CASE WHEN len(fname) > 18 THEN cast(right(left(fname,(len(fname)-4)),len(fname)-18) as int)ELSE cast(0 as int) END)

set @SrcDir = 'C:\Test'
set @sql = 'dir "' + @SrcDir + '"*.trc /b'

insert #LogFileList exec master.dbo.xp_cmdshell @sql
insert #DeleteFileList(fname) exec master.dbo.xp_cmdshell @sql

delete #LogFileList where fname is null or fname = 'File Not Found'
delete #DeleteFileList where fname is null or fname = 'File Not Found'

SELECT @File = fname FROM #DeleteFileList Where FileOrder = (Select Min(FileOrder) From #DeleteFileList)

SET @FullPath =  @SrcDir + @File

SET @LastAudit = 0

IF OBJECT_ID('Audit_DB..Temp_TRC') IS NOT NULL  
	BEGIN
	Select @RowCount = Count(*) From Audit_DB..Temp_TRC	
		IF @RowCount > 0
		BEGIN
		Select @LastAudit = Max(StartTime) From Temp_TRC
		END
	END


If @File is not Null ---If there are trace files
	BEGIN
	IF OBJECT_ID('Audit_DB..Temp_TRC') IS NULL SELECT * INTO Audit_DB..Temp_TRC FROM :: fn_trace_gettable(@FullPath, default)
	ELSE INSERT INTO Audit_DB..Temp_TRC SELECT * FROM :: fn_trace_gettable(@FullPath , default) WHERE StartTime >= @LastAudit
	END
ELSE PRINT 'No Trace Files Present'

--Delete the trace files
	BEGIN
	DECLARE @dict TABLE (value VARCHAR(50), executed BIT default 0)
	DECLARE @currentvalue VARCHAR(50)
	INSERT INTO @dict SELECT fname, x = 0 from #LogFileList

	WHILE EXISTS(SELECT * FROM @dict WHERE executed = 0)
		BEGIN
		SELECT TOP 1 @currentvalue = value FROM @dict WHERE executed = 0    
		SET @sql = 'del '+ '"' + @SrcDir + @currentvalue + '"'
		EXEC @out = master.dbo.xp_cmdshell @sql 
		UPDATE d SET executed = 1 FROM @dict d WHERE value = @currentvalue
		END

	END

IF OBJECT_ID('tempdb..#LogFileList') IS NOT NULL DROP TABLE #LogFileList
IF OBJECT_ID('tempdb..#DeleteFileList') IS NOT NULL DROP TABLE #DeleteFileList


--Create new trace:

EXEC dbo.CreateDDLTrace


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO
