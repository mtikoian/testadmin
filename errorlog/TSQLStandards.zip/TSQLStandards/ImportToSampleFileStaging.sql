CREATE PROCEDURE dbo.ImportToSampleFileStaging
/**********************************************************************************************************************
 Purpose:
 Given a file path and a file name filter, import the found files into the dbo.SampleFileStagingLoader table.
 Of course, the files should be in the proper format to be imported into the table.
  EXEC dbo.ImportToSampleFileStaging 'C:\Temp\','Import[0-9]%.txt';
 Usage:
--===== Basic syntax
   EXEC dbo.ImportToSampleFileStaging @pImportFilePath, @pImportFileFilter
;
--===== Import all files from the C:\Temp\ direcctory that have a file name that starts with "IMPORT", followed by
     -- at least one numeric digit, that has a .TXT extension.
   EXEC dbo.ImportToSampleFileStaging 'C:\Temp\','Import[0-9]%.txt'
;
 Revision History:
 Rev 00 - 16 Jan 2015 - Jeff Moden
        - Initial creation for http://www.sqlservercentral.com/Forums/Topic1649977-364-1.aspx
**********************************************************************************************************************/
--===== Parameters for this stored proceddure
         @pImportFilePath   VARCHAR(500)
        ,@pImportFileFilter VARCHAR(100)
     AS
--=====================================================================================================================
--      Environment
--=====================================================================================================================
--===== Suppress the auto-display of rowcounts for appearance and performance. 
    SET NOCOUNT ON
;
--===== Delouse the input parameters for SQL and DOS Injection.
     -- Return no clues if present.
     IF @pImportFilePath   LIKE '%[^-a-zA-Z0-9:.\__]%'  ESCAPE '_'
     OR @pImportFileFilter LIKE '%[^-a-zA-Z0-9:.\__%[]]%' ESCAPE '_'
        RETURN
;
--=====================================================================================================================
--      Temp Tables
--=====================================================================================================================
--===== Create a table to store all the file names.
     IF OBJECT_ID('tempdb..#AllFiles','U') IS NOT NULL
        DROP TABLE #AllFiles
;
 CREATE TABLE #AllFiles
        (
         SubDirectory   VARCHAR(100)
        ,Depth          INT
        ,IsFile         BIT
        )
;
--===== Create a table to store the filtered file names to import.
     IF OBJECT_ID('tempdb..#ImportFileName','U') IS NOT NULL
        DROP TABLE #ImportFileName
;
 CREATE TABLE #ImportFileName
        (
         FileNumber     INT IDENTITY(1,1)
        ,ImportFileName VARCHAR(100)
        )
;
--=====================================================================================================================
--      Presets
--=====================================================================================================================
--===== Local variables
DECLARE  @Counter           INT
        ,@FileCount         INT
        ,@ImportFileName    VARCHAR(100)
        ,@SQL               VARCHAR(MAX)
;
--=====================================================================================================================
--      Get the names of the files to import
--=====================================================================================================================
--===== Get all the file names for the given source directory.
 INSERT INTO #AllFiles
        (SubDirectory,Depth,IsFile)
   EXEC xp_DirTree @pImportFilePath,1,1
;
--===== Get the filtered file names to import and remember how many there are.
 INSERT INTO #ImportFileName
        (ImportFileName)
 SELECT ImportFileName = SubDirectory
   FROM #AllFiles af
  WHERE SubDirectory LIKE @pImportFileFilter
    AND NOT EXISTS (SELECT * FROM dbo.SampleFileStaging WHERE [FileName] LIKE '%'+af.SubDirectory+'%')
  ORDER BY SubDirectory
;
 SELECT @FileCount = @@ROWCOUNT
;
--=====================================================================================================================
--      Import each file and the name of the file
--=====================================================================================================================
 SELECT @Counter = 1
;
  WHILE @Counter <= @FileCount
  BEGIN
         SELECT @ImportFileName = ImportFileName
           FROM #ImportFileName
          WHERE FileNumber = @Counter
        ;
         SELECT @SQL = REPLACE(REPLACE(REPLACE('
        --===== Replace the default constraint to pickup the file name
          ALTER TABLE SampleFileStaging 
           DROP CONSTRAINT DF_SampleFileStaging_FileName
        ;
          ALTER TABLE SampleFileStaging 
            ADD CONSTRAINT DF_SampleFileStaging_FileName DEFAULT "<<@pImportFilePath>><<@ImportFileName>>" FOR [FileName]
        ;
        --===== Import the data from the given file path and the found file name.
           BULK INSERT dbo.SampleFileStagingLoader
           FROM "<<@pImportFilePath>><<@ImportFileName>>"
           WITH (
                 CODEPAGE           = "RAW"
                ,FIRSTROW           = 2
                ,FIELDTERMINATOR    = ","
                ,ROWTERMINATOR      = ""
                ,TABLOCK
                )
        ;'
                ,'"'                  ,'''')
                ,'<<@pImportFilePath>>',@pImportFilePath)
                ,'<<@ImportFileName>>' ,@ImportFileName)
        ;
           EXEC (@SQL)
        ;
         SELECT @Counter = @Counter + 1
        ;
    END
;
GO