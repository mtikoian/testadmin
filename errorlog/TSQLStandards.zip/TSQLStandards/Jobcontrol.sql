--===== This is the "job control" table...
     -- It would only need to be created once and
     -- would be truncated between runs...
 CREATE TABLE dbo.JobControl
        (
        RowNum INT IDENTITY(1,1),
        StartDate DATETIME,
        EndDate   DATETIME,
        Entity    INT
        )

--===== Populate the job control with data.
     -- You could probably do this with another query
     -- or manually for small ad hoc runs.
 INSERT INTO dbo.JobControl
        (StartDate, EndDate, Entity)
 SELECT 'Jan 2009','Jun 2009',104 UNION ALL
 SELECT 'Jul 2008','Dec 2009',210

 --===== Now, build the necessary queries from the data in the table...
DECLARE @SQL VARCHAR(MAX)
 SELECT @SQL =  (SELECT CHAR(10) 
                      + 'EXEC uspMy_Stored_Proc @Start = ''' + CONVERT(CHAR(8),DATEADD(mm,t.N-1,jc.StartDate),112)
                      + ''', @End = ''' + CONVERT(CHAR(8),DATEADD(mm,t.N-1,jc.StartDate),112)
                      + ''', @Entity = ' + CAST(jc.Entity AS VARCHAR(10))
                   FROM dbo.JobControl jc
                  CROSS JOIN dbo.Tally t
                  WHERE t.N BETWEEN 1 AND DATEDIFF(mm,StartDate,EndDate)+1
                  ORDER BY jc.Entity, jc.StartDate
                    FOR XML PATH(''),TYPE).value('.','VARCHAR(MAX)')

--===== Print the command to see what it looks like.
     -- This can be commented out for production... or not.
  PRINT @SQL

--===== Uncomment this line for production.
--   EXEC (@SQL)