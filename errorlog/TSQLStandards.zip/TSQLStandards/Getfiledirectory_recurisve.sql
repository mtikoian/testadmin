--===== Drop temp tables if they exist to make reruns in SSMS easier.
     IF OBJECT_ID('tempdb..#MyDir','U') IS NOT NULL
        DROP TABLE #MyDir
;
--===== Create the temp table that not only collects the file info,
     -- but parses it, as well.
 CREATE TABLE #MyDir
        (
         CmdOutput VARCHAR(500)
        ,ModifiedOn AS CAST(SUBSTRING(CmdOutput,1,CHARINDEX('"',CmdOutput)-1) AS DATETIME)
        ,FullPath AS CAST(REPLACE(SUBSTRING(CmdOutput,CHARINDEX('"',CmdOutput)+1,8000),'"','') AS VARCHAR(500))
        )
;
--===== Get our files and dates for the given path (/P) and all sub-directories.
 INSERT INTO #MyDir
        (CmdOutput)
   EXEC xp_CmdShell 'FORFILES /P "C:\Temp" /S /C "CMD /C IF @IsDir==FALSE ECHO @FDate @FTime @Path"'
;
--===== Let's see what we have
 SELECT FullPath, ModifiedOn 
   FROM #MyDir
  WHERE CmdOutput > ''
;