
CREATE TABLE #ActivityLog (Radio_name VARCHAR(20),
             Date_time DATETIME,
             Activity VARCHAR(30));
GO

INSERT INTO #ActivityLog
VALUES ('BBC Radio 1', DATEADD(MINUTE, -4320, GETDATE()), 'Connect'),
       ('BBC Radio 1', DATEADD(MINUTE, -4290, GETDATE()), 'Disconnect'),
       ('BBC Radio 1', DATEADD(MINUTE, -4280, GETDATE()), 'Connect'),
       ('BBC Radio 1', DATEADD(MINUTE, -4200, GETDATE()), 'Disonnect'),
       ('BBC Radio 1', DATEADD(MINUTE, -4000, GETDATE()), 'Disconnect'), --Intentional Anomalous data
       ('BBC Radio 1', DATEADD(MINUTE, -3999, GETDATE()), 'Connect'),
       ('BBC Radio 1', DATEADD(MINUTE, -3500, GETDATE()), 'Disconnect'),
       ('BBC Radio 1', DATEADD(MINUTE, -2100, GETDATE()), 'Connect'),
       ('BBC Radio 1', DATEADD(MINUTE, -2059, GETDATE()), 'Connect'),  --More intentional Anomalous data
       ('BBC Radio 1', DATEADD(MINUTE, -1000, GETDATE()), 'Disconnect'),
       ('BBC Radio 1', DATEADD(MINUTE, -600, GETDATE()), 'Connect'),
       ('BBC Radio 1', DATEADD(MINUTE, -300, GETDATE()), 'Disconnect'),
       ('BBC Radio 1', DATEADD(MINUTE, 300, GETDATE()), 'Connect'),
       ('BBC Radio 1', DATEADD(MINUTE, 650, GETDATE()), 'Disconnect'),
       ('BBC Radio 1', DATEADD(MINUTE, 800, GETDATE()), 'Connect'),
       ('BBC Radio 1', DATEADD(MINUTE, 1200, GETDATE()), 'Disconnect');

SELECT *
FROM #ActivityLog;
GO

SELECT C.Radio_name,
       C.Date_time,
       CAST(C.Date_time AS date) AS DOA,
       C.Activity,
       DATEDIFF(Minute, D.Date_time, C.Date_time) AS Prior_Disconnect_Minutes
FROM #ActivityLog C
   OUTER APPLY (SELECT TOP 1 *
                FROM #ActivityLog ca
                WHERE ca.Activity = 'Disconnect'
                  AND ca.Date_time <= C.Date_time
                  AND ca.Radio_name = C.Radio_name
                ORDER BY ca.Date_time DESC) D
WHERE C.Activity = 'Connect'
  AND CAST(C.Date_time AS date) BETWEEN CAST(DATEADD(DAY, -1, GETDATE()) AS date) AND CAST(GETDATE() AS date);

DROP TABLE #ActivityLog;
GO