IF OBJECT_ID ('p_Obfuscate_string') IS NOT NULL
   DROP procedure p_Obfuscate_string
GO
 
CREATE procedure p_Obfuscate_string @sentence VARCHAR(MAX) OUTPUT
AS
BEGIN
DECLARE @start INT, @WordLength INT,@sent VARCHAR(100), @LenSentence INT,@index INT;
SELECT @LenSentence=len(@Sentence),@Start=100,@index =0;
/* we find each word of four or more letters in a WHILE loop, and having found the
start and end position in the string, we shuffle the characters using the NEWID()
trick. We insert them back into the string using STUFF.
Declare @sentence varchar(max);
SELECT @sentence=
'There was a young lady of Natchez
Whose garments were always in patchez.
When comment arose
On the state of her clothes,
She drawled, ''When Ah itchez, Ah scratchez''';
EXECUTE p_Obfuscate_string @sentence OUTPUT
SELECT @Sentence
SELECT @sentence= 'whatever I type seems to me made rather hard to read!'
EXECUTE p_Obfuscate_string @sentence OUTPUT
SELECT @Sentence
SELECT @sentence= 'This seems rather trivial: or should I be amused?'
EXECUTE p_Obfuscate_string @sentence OUTPUT
SELECT @Sentence



*/
WHILE (@start>0 AND @index+4<@lenSentence)
  BEGIN
    SELECT
      @start= patindex('%[^a-z][a-z][a-z][a-z][a-z]%',' '+right(@Sentence,@lenSentence-@index)),
      @WordLength=
          CASE WHEN @start=0 THEN 0
            ELSE patindex('%[a-z][^a-z]%',substring(right(@Sentence,@lenSentence-@index),@start,100))END,
      @WordLength=CASE WHEN @WordLength=0 THEN @LenSentence-@index-@start ELSE @WordLength END
       IF @start>0
         BEGIN      
              SELECT  @Sentence=stuff(@Sentence, @index+@start+1,@WordLength-2,
                (SELECT substring(substring(@sentence,@index+@start+1, @WordLength-2), n,1)
              FROM (SELECT TOP (@WordLength-2) row_number() OVER (ORDER BY (SELECT NULL))
                FROM(VALUES(0),(0),(0),(0),(0),(0),(0),(0),(0),(0)) a(n)        -- 10 rows
                CROSS JOIN (VALUES(0),(0),(0),(0),(0),(0),(0),(0),(0),(0)) b(n))x(n) -- 100 rows
                ORDER BY ABS(CHECKSUM(NewId()))
              FOR Xml PATH (''), TYPE).value('.', 'varchar(max)'))
      END
       SELECT @index=@index+@start+@WordLength
       END
end
go

 
