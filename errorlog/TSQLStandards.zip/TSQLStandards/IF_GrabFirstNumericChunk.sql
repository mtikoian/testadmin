
-- I'd use a function for this, to mask the complexityfrom your queries:

CREATE FUNCTION dbo.IF_GrabFirstNumericChunk

( @MyString VARCHAR(100) )

RETURNS TABLE AS RETURN


WITH N0 AS (SELECT n = 0 FROM

(VALUES (0),(0),(0),(0),(0),(0),(0),(0),(0),(0)) a (n),

(VALUES (0),(0),(0),(0),(0),(0),(0),(0),(0),(0)) b (n)),

_Tally AS (SELECT TOP(LEN(@MyString)) rn = ROW_NUMBER() OVER(ORDER BY (SELECT NULL)) FROM N0),

Grouper AS (

SELECT rn, grp = rn - ROW_NUMBER() OVER(ORDER BY (SELECT NULL))

FROM _Tally

WHERE SUBSTRING(@MyString,rn,1) IN ('0','1','2','3','4','5','6','7','8','9')),

Agg AS (

SELECT grp, [Start] = MIN(rn), [End] = MAX(rn)

FROM Grouper

GROUP BY grp)

SELECT TOP(1) FirstNumericChunk = SUBSTRING(@MyString,[Start], [End]-[Start]+1)

FROM Agg ORDER BY grp


GO


Create table #TEMP (ID Varchar(200))

Insert Into #TEMP Values ('ABC205916_DAN')

Insert Into #TEMP Values ('ABC243296')

Insert Into #TEMP Values ('ABC222249_DAN25')

Insert Into #TEMP Values ('IN217465_v99')

Insert Into #TEMP Values ('ABC#243296')



SELECT *

FROM #TEMP

CROSS APPLY dbo.IF_GrabFirstNumericChunk(ID)