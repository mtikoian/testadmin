
CREATE FUNCTION dbo.fn_extract_chars_in_range( 
	 @input varchar(8000) -- the string to be cleansed
	,@start char(1) -- the first valid character
	,@end char(1) -- the last valid character
	,@maxlength smallint=10 -- maximum length to be returned
	)
RETURNS TABLE
WITH SCHEMABINDING
AS
RETURN
	-- dynamic tally table
	WITH 
	 c10(c)  AS(SELECT '' FROM (VALUES(''),(''),(''),(''),(''),(''),(''),(''),(''),(''),(''),(''),(''),(''),(''),(''),(''),(''),(''),('')) as c20(c))
	,c100(c) AS(SELECT '' FROM c10 a,c10 b)
	,c10000(c) AS(SELECT '' FROM c100 a,c100 b)
	-- the final select numbers the rows. the TOP is important for speed.
	,Tally(N) AS(SELECT TOP(LEN(@input)) row_number() OVER(ORDER BY (SELECT NULL)) FROM c10000) 

	SELECT 
		CAST(
			(
				-- extract valid characters and concatenate them
				SELECT TOP(@maxlength) substring(@input,N,1)
				FROM  Tally
				WHERE substring(@input,N,1) BETWEEN @start AND @end
				FOR XML PATH('')
			) AS VARCHAR(8000)
		) AS result;