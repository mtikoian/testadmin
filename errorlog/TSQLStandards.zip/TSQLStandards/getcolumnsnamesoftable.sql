--===== Variable declarations
DECLARE  @pDBName       SYSNAME      --Could be a parameter for a stored proc
        ,@pTableName    SYSNAME      --Could be a parameter for a stored proc
        ,@ColumnNames   VARCHAR(MAX) --Could be an output parameter for a stored proc
        ,@SQL           NVARCHAR(MAX)
;
--===== Preset the variables for the database and table name
 SELECT  @pDBName    = 'put_database_name_here'
        ,@pTableName = 'put_table_name_here'
;
--===== Make sure the @pDBName (the only variable with concatenation properties in the dynamic SQL)
     -- is actually a database name rather than SQL injection.  The other two variables are fully
     -- parameterized and of the correct length to prevent injection by truncation. Note that if 
     -- the database name does not exist, we do nothing but return so as to give no hint to a 
     -- a possible attacker.  This makes the QuOTENAME thing I did further down total overkill
     -- but I left that there anyway.
     IF NOT EXISTS (SELECT * FROM sys.databases WHERE name = @pDBName) 
        RETURN
;
--===== Setup the variable contents including the "double-dynamic" SQL.
 SELECT @SQL        = REPLACE(REPLACE('
 SELECT @ColumnNames = COALESCE(@ColumnNames+",","")  + COLUMN_NAME
   FROM <<@pDBName>>.INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_NAME = @pTableName
 OPTION (MAXDOP 1);'
        ,'"'              ,'''')
        ,'<<@pDBName>>'   ,QUOTENAME(@pDBName)) --QUOTENAME() to help prevent SQL-INJECTION
;
--===== Get the column names from the desired database and table.
EXECUTE sp_executesql @SQL
                    , N'@pTableName SYSNAME, @ColumnNames VARCHAR(MAX) OUT'       --Parameter Definitions
                    , @pTableName = @pTableName, @ColumnNames = @ColumnNames OUT  --Value Assignment
;
--===== Here are the desired results
  PRINT @ColumnNames;

--===== Here's the SQL that was executed
  PRINT @SQL;


/* way 2



USE tempdb;
GO
/* Database name variable*/
DECLARE @DATABASE_NAME NVARCHAR(128) = N'msdb';

/* The query with the database name placeholder "{{@DATABASE_NAME}}"
   replaced by the value of the @DATABASE_NAME variable
*/
DECLARE @SQL_STR       NVARCHAR(MAX) = REPLACE(N'SELECT * FROM [{{@DATABASE_NAME}}].[dbo].[sysalerts]',N'{{@DATABASE_NAME}}',@DATABASE_NAME);

/* Table variable to catch the output of the sp_describe_first_result_set procedure 
*/
DECLARE @RES TABLE
(
     is_hidden	                    BIT      NULL
    ,column_ordinal	                INT      NULL
    ,name	                        SYSNAME  NULL
    ,is_nullable	                BIT      NULL
    ,system_type_id	                INT      NULL
    ,system_type_name	            SYSNAME  NULL
    ,max_length	                    INT      NULL
    ,precision	                    INT      NULL
    ,scale	                        INT      NULL
    ,collation_name	                SYSNAME  NULL
    ,user_type_id	                INT      NULL
    ,user_type_database	            SYSNAME  NULL
    ,user_type_schema	            SYSNAME  NULL
    ,user_type_name	                SYSNAME  NULL
    ,assembly_qualified_type_name	SYSNAME  NULL
    ,xml_collection_id	            INT      NULL
    ,xml_collection_database	    SYSNAME  NULL
    ,xml_collection_schema	        SYSNAME  NULL
    ,xml_collection_name	        SYSNAME  NULL
    ,is_xml_document	            BIT      NULL
    ,is_case_sensitive	            BIT      NULL
    ,is_fixed_length_clr_type	    BIT      NULL
    ,source_server	                SYSNAME  NULL
    ,source_database	            SYSNAME  NULL
    ,source_schema	                SYSNAME  NULL
    ,source_table	                SYSNAME  NULL
    ,source_column	                SYSNAME  NULL
    ,is_identity_column	            BIT      NULL
    ,is_part_of_unique_key	        BIT      NULL
    ,is_updateable	                BIT      NULL
    ,is_computed_column	            BIT      NULL
    ,is_sparse_column_set	        BIT      NULL
    ,ordinal_in_order_by_list	    BIT      NULL
    ,order_by_is_descending	        BIT      NULL
    ,order_by_list_length	        BIT      NULL
    ,tds_type_id	                INT      NULL
    ,tds_length	                    INT      NULL
    ,tds_collation_id	            INT      NULL
    ,tds_collation_sort_id          INT      NULL
)

INSERT INTO @RES
EXEC sp_describe_first_result_set @SQL_STR;

/* Full description of the result set */
SELECT * FROM @RES;
*/