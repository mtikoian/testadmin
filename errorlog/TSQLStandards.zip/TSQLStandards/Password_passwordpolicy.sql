CREATE TABLE dbo.password_policy
(
	min_pw_length			tinyint NOT NULL,
	ucase_chars_required	tinyint NOT NULL,
	lcase_chars_required	tinyint NOT NULL,
	numeric_chars_required	tinyint NOT NULL,
	special_chars_required	tinyint NOT NULL,
	special_chars			varchar(50)
)

GO

INSERT INTO dbo.password_policy
 VALUES (6, 1, 1, 0, 1, '0123456789~`!@#$%^&*()_-+=|\{}[]:;"<>.?/')

--===== Create and populate a 1,000,000 row password test table including all of the "legal" characters
     -- and two illegal characters (comma and single quote).
DECLARE @Characters VARCHAR(100),
        @Length     INT
 SELECT @Characters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789~`!@#$%^&*()_-+=|\{}[]:;"<>.?/,''',
        @Length     = LEN(@Characters)

 SELECT TOP 100000
        RowNum       = IDENTITY(INT,1,1),
        Password     = SUBSTRING(@Characters,ABS(CHECKSUM(NEWID()))%@Length+1,1)
                     + SUBSTRING(@Characters,ABS(CHECKSUM(NEWID()))%@Length+1,1)
                     + SUBSTRING(@Characters,ABS(CHECKSUM(NEWID()))%@Length+1,1)
                     + SUBSTRING(@Characters,ABS(CHECKSUM(NEWID()))%@Length+1,1)
                     + SUBSTRING(@Characters,ABS(CHECKSUM(NEWID()))%@Length+1,1)
                     + SUBSTRING(@Characters,ABS(CHECKSUM(NEWID()))%@Length+1,1)
                     + SUBSTRING(@Characters,ABS(CHECKSUM(NEWID()))%@Length+1,1)
                     + SUBSTRING(@Characters,ABS(CHECKSUM(NEWID()))%@Length+1,1)
                     + SUBSTRING(@Characters,ABS(CHECKSUM(NEWID()))%@Length+1,1)
                     + SUBSTRING(@Characters,ABS(CHECKSUM(NEWID()))%@Length+1,1)
   INTO #Password
   FROM Master.dbo.SysColumns t1
  CROSS JOIN Master.dbo.SysColumns t2 

--===== Start the CPU and duration timers
    SET STATISTICS TIME ON

--===== Supress the auto-display of rowcounts for appearance
    SET NOCOUNT ON

--===== Declare local variables that match the policy table
     -- and populate them from that table.
DECLARE @Min_Pw_Length          TINYINT,
        @UCase_Chars_Required   TINYINT,
        @LCase_Chars_Required   TINYINT,
        @Special_Chars_Required TINYINT,
        @Special_Chars          VARCHAR(50)

 SELECT @Min_Pw_Length          = Min_Pw_Length,
        @UCase_Chars_Required   = UCase_Chars_Required,
        @LCase_Chars_Required   = LCase_Chars_Required,
        @Special_Chars_Required = Special_Chars_Required,
        @Special_Chars          = Special_Chars
   FROM dbo.Password_Policy

--===== Create a report of passwords that do not meet the requirements of the Policy table and the reasons why.
 SELECT d.RowNum,
        d.Password,
        CASE WHEN d.Length       < @Min_Pw_Length           THEN @Min_Pw_Length - d.Length                ELSE 0 END AS CountShort,
        CASE WHEN d.CountUpper   < @UCase_Chars_Required    THEN @UCase_Chars_Required - d.CountUpper     ELSE 0 END AS CountMissingUpper,
        CASE WHEN d.CountLower   < @LCase_Chars_Required    THEN @LCase_Chars_Required - d.CountLower     ELSE 0 END AS CountMissingLower,
        CASE WHEN d.CountSpecial < @Special_Chars_Required  THEN @Special_Chars_Required - d.CountSpecial ELSE 0 END AS CountMissingSpecial,
        CASE WHEN d.CountUpper+d.CountLower+d.CountSpecial <> d.Length THEN d.Length - (d.CountUpper+d.CountLower+d.CountSpecial)  ELSE 0 END AS CountIllegal
--,Length,CountUpper,CountLower,CountSpecial,d.CountUpper+d.CountLower+d.CountSpecial --For troubleshooting
  FROM 
        (--==== Preaggregate the counts like before.  
             -- I used Brian's method to determine upper/lower case because the OP didn't like the COLLATE clause I used previously.
         SELECT jt.RowNum,
                jt.Password,
                SUM(CASE WHEN ASCII(SUBSTRING(jt.Password,t.N,1)) BETWEEN 65 AND  90 THEN 1 ELSE 0 END)   AS CountUpper,
                SUM(CASE WHEN ASCII(SUBSTRING(jt.Password,t.N,1)) BETWEEN 97 AND 122 THEN 1 ELSE 0 END)   AS CountLower,
                SUM(CASE WHEN @Special_Chars LIKE '%'+CHAR(3)+SUBSTRING(jt.Password,t.N,1)+'%' ESCAPE CHAR(3) THEN 1 ELSE 0 END) AS CountSpecial,
                LEN(Password) AS Length
           FROM dbo.Tally t
          CROSS JOIN dbo.#Password jt
          WHERE t.N <= LEN(jt.Password)+1 --(+1) takes care of blank passwords, faster than using OR LEN(jt.Password) = 0
          GROUP BY jt.RowNum, jt.Password)d  
  WHERE d.Length       < @Min_Pw_Length                      --PW not long enough
     OR d.CountUpper   < @UCase_Chars_Required               --Not enough uppercase characters
     OR d.CountLower   < @LCase_Chars_Required               --Not enough lowercase characters
     OR d.CountSpecial < @Special_Chars_Required             --Not enough special characters
     OR d.CountUpper+d.CountLower+d.CountSpecial <> d.Length --Illegal characters present

--===== Turn the timers off
    SET STATISTICS TIME OFF