

::Patching
$item = Invoke-Command -computername testbox -scriptblock {Get-ChildItem "C:\" | Where-Object {$_.Name -like "*sqlserver*" -and $_.Name -like "*kb*"}}
$name = $item.Name
$directory = $item.Directoryname
$servicePackExec= $directory + $name
"Starting Service Pack Installation..."
$patchCmd = "$servicePackExec /Action=Patch /IAcceptSQLServerLicenseTerms /AllInstances"
$script = [scriptblock]::Create($patchCmd)
Invoke-command -ComputerName testbox -ScriptBlock $script

::Active Directory
$Results = Get-ADUser -Filter * -ResultPageSize 100 | Get-ADObject -Properties * | select -property sAMAccountName,ou,
  GivenName,SurName,DisplayName,email,emailaddress,
  StreetAddress,City,State,PostalCode,
  HomePhone,MobilePhone,OfficePhone,Fax,
  Company,Organization,Department,Title,Description,Office,
  extensionAttribute1,extensionAttribute2,extensionAttribute3,extensionAttribute4,extensionAttribute5,
  @{Name='AccountExpires';Expression={[DATETIME]::fromFileTime($_.accountExpires)}},Enabled,PasswordLastSet,
  @{n="PasswordExpirationDate";e={$_.PasswordLastSet.AddDays($maxPasswordAge)}},PasswordNeverExpires,PasswordExpired,
  LastLogonDate,whenCreated

$Results | Out-GridView 

:: scripting the definitions for the databases 

#Create Database Scripts with all properties
function get-databasescripts {
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo") | Out-Null
#$srv = New-Object "Microsoft.SqlServer.Management.Smo.Server" $sqlserver
$srv.Databases | foreach {
          try{
          $_.Script() + "GO"
          }
          catch [Exception] {$_.Exception.ToString() }
          } | Out-File $($directoryname + $serverfilename + "_Databases.sql") -Append
        }

###################################################################################################
# Core Workspace
###################################################################################################
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo")

#$servers = get-content C:\Data\PowerShell\computers.txt
##$servers = get-content C:\Data\PowerShell\computers.txt  # from a file
#$servers = @("SQLAlpha","SQLBeta","SQLDelta","SQLOmega") # multiple for testing
$servers = @("SQLAlpha") # just one for testing

##$basedirectory = "C:\_TFS\CCPMain\Main\DatabaseSchemas"
$basedirectory = "C:\Data\DatabaseSchemas"
$directoryname = $basedirectory

#make sure our prime directory exists
if (!(Test-Path -path $directoryname)) {
New-Item $directoryname -type directory
}

foreach ($sqlserver in $servers){
  if ($sqlserver.Trim() -ne "") {
  if($sqlserver.IndexOf("\") -gt 0) {
    $directoryname = $basedirectory + "\" + $sqlserver.Replace("\","(") + ")\"
    $position =$sqlserver.IndexOf("\")
    $server = $sqlserver.SubString(0,$position)
    $serverfilename = $sqlserver.Replace("\","(") + ")"
  }
  else {
    $directoryname = $basedirectory + "\" + $sqlserver + "\"
    $server = $sqlserver
    $serverfilename = $server
  }

  if (!(Test-Path -path $directoryname)) {
    New-Item $directoryname -type directory
  }
  $database = ""
  write-verbose -Message "directory $directoryname" -verbose
  write-verbose -Message "scripting $server" -verbose

  getwmiinfo $server

  $srv = New-Object "Microsoft.SqlServer.Management.Smo.Server" $sqlserver
  if($svr.NetName -ne '') {
  
    $srv.SetDefaultInitFields($true)
   
    get-databasescripts
    #get-errorlogs
    #get-triggers
    #get-backupdevices
    #get-sqlagentscript
    #get-jobscripts
    #get-linkscripts
    #get-userlogins
    #get-operators
    #get-alerts
    #get-databaseobjectscripts
    #get-singlescriptdatabaseobjects
    #$Scripter=new-object ("Microsoft.SqlServer.Management.Smo.Scripter") ($server) 
    #$Scripter.Options.DriAll=$False 
    #$Scripter.Options.IncludeHeaders=$False 
    #$Scripter.Options.ToFileOnly=$True 
    #$Scripter.Options.WithDependencies=$False 
    #foreach $database in $Scripter.Databases
    #{
    ##create a directory for each database.
    #if (!(Test-Path -path $directoryname\$server\$database)) {
    #New-Item $directoryname\$server\$database -type directory
    #}

    #}
    } #-ne $null
  } #-ne ""

} #foreach

::Multithreading to upload .bak files in parallel to S3 storage using PowerShell
::https://powertoe.wordpress.com/2012/05/03/foreach-parallel/

$logPath="C:\S3_UploadLog\UploadFull_ScriptBlockMain.log";
if (!(Test-Path $logPath))
{ 
Write-Verbose "Creating $logPath." 
$NewLogFile = New-Item $logPath -Force -ItemType File 
} 
Write-Output "$(Get-Date -Format "yyyy-MM-dd HH:mm:ss") INFO: Script Started" | Out-File -FilePath $logPath -Append

$cmd = {
param($a, $b)
$logPath="C:\S3_UploadLog\UploadFull_ScriptBlockThread.log";
try{
if (!(Test-Path $logPath))
{ 
Write-Verbose "Creating $logPath." 
$NewLogFile = New-Item $logPath -Force -ItemType File 
} 

if (Test-Path "C:\Program Files (x86)")
{
Write-Output "$(Get-Date -Format "yyyy-MM-dd HH:mm:ss") INFO: scriptblock1 adding awssdk.core" | Out-File -FilePath $logPath -Append
Add-Type -Path "C:\Program Files (x86)\AWS SDK for .NET\bin\Net35\AWSSDK.Core.dll"
Write-Output "$(Get-Date -Format "yyyy-MM-dd HH:mm:ss") INFO: scriptblock1 successfully added awssdk.core" | Out-File -FilePath $logPath -Append
}
Write-Output "$(Get-Date -Format "yyyy-MM-dd HH:mm:ss") INFO: a $a " | Out-File -FilePath $logPath -Append
Write-Output "$(Get-Date -Format "yyyy-MM-dd HH:mm:ss") INFO: b $b " | Out-File -FilePath $logPath -Append
#start
$bucket = 'YourBucketname' 
$Key = 'KeyInfo'
$secret = 'SecretKey'
$region = 'us-east-1'
$localpath = 'E:\sourceFile\BKUP\'
foreach($LastBKUP in $b){ 
$LastBKUP = $localpath+$LastBKUP;
$filename = [System.IO.Path]::GetFileName($LastBKUP)
Write-Output "$(Get-Date -Format "yyyy-MM-dd HH:mm:ss") INFO: filename: $filename " | Out-File -FilePath $logPath -Append
Write-Output "$(Get-Date -Format "yyyy-MM-dd HH:mm:ss") INFO: backupfile: $LastBKUP " | Out-File -FilePath $logPath -Append
Write-S3Object -BucketName $Bucket -File $LastBKUP -Key /subfoldername/$filename -Region $region -AccessKey $Key -SecretKey $secret -ServerSideEncryption AES256
Write-Output "$(Get-Date -Format "yyyy-MM-dd HH:mm:ss") INFO: sucessfully copied file: $LastBKUP " | Out-File -FilePath $logPath -Append 
}
}catch
{
write-Output "Caught an exception: " | Out-File -FilePath $logPath -Append 
write-Output $_.Exception |format-list -force | Out-File -FilePath $logPath -Append 
$ErrorMessage = $_.Exception.Message

}
finally
{
Write-Output "$(Get-Date -Format "yyyy-MM-dd HH:mm:ss") INFO: Task Ended. **********" | Out-File -FilePath $logPath -Append 
}
}#end of cmd
$sourcepath = 'E:\sourceFile\BKUP\'
Write-Output "$(Get-Date -Format "yyyy-MM-dd HH:mm:ss") INFO: source path : $sourcepath " | Out-File -FilePath $logPath -Append 
$files = Get-ChildItem -Path $sourcepath #|Where{$_.LastWriteTime -gt (Get-Date).AddDays(-4)} 
$a=$files -split " "
Write-Output "$(Get-Date -Format "yyyy-MM-dd HH:mm:ss") INFO: a: $a " | Out-File -FilePath $logPath -Append
Write-Output $files.Length;
$b = $a[0..3]

Write-Output "$(Get-Date -Format "yyyy-MM-dd HH:mm:ss") INFO: b: $b " | Out-File -FilePath $logPath -Append
$c = $a[4..7]
Write-Output "$(Get-Date -Format "yyyy-MM-dd HH:mm:ss") INFO: c: $c " | Out-File -FilePath $logPath -Append
$d = $a[8..11]
$e = $a[12..13]
$j = 1;
try{
1..4 | ForEach-Object {
if($j -eq 1){
Start-Job -ScriptBlock $cmd -ArgumentList $_, $b
}
if($j -eq 2)
{ 
Start-Job -ScriptBlock $cmd -ArgumentList $_, $c
}
if($j -eq 3)
{
Start-Job -ScriptBlock $cmd -ArgumentList $_, $d
}
if($j -eq 4)
{ 
Start-Job -ScriptBlock $cmd -ArgumentList $_, $e
}
$j = $j+1;
}

}catch
{
write-Output "Caught an exception: " | Out-File -FilePath $logPath -Append 
write-Output $_.Exception |format-list -force | Out-File -FilePath $logPath -Append 
$ErrorMessage = $_.Exception.Message

}finally
{
Write-Output "$(Get-Date -Format "yyyy-MM-dd HH:mm:ss") INFO: Script Ended. **********" | Out-File -FilePath $logPath -Append 
}

