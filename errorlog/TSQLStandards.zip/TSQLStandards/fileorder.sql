--===== Create the receiver table
 CREATE TABLE #Order
        (
         ObjectName VARCHAR(500) NOT NULL --Will be a filename where IsFile = 1
        ,Depth      TINYINT      NOT NULL --Will always be "1" for the commmand below
        ,IsFile     TINYINT      NOT NULL --1 for files, 0 for directories
        ,FileOrder  INT          NULL     --Will indicate the sort order for processing files in name order
        )
;
--===== Get the directory and file names for the file path.
     -- Obviously, you need to change 'yourfilepath' to the correct file path.
 INSERT INTO #Order
        (ObjectName, Depth, IsFile)
   EXEC xp_dirtree 'C:\',1,1
;
--===== Add a sequence to the file rows for processing files in name order.
     -- If you don't actually need to do any processing, you don't actually need this step.
   WITH cteEnumerate AS
(
 SELECT ObjectName
        ,IsFile
        ,FileOrder
        ,RowNum = ROW_NUMBER() OVER (ORDER BY ObjectName)
   FROM #Order
  WHERE IsFile = 1
)
 UPDATE cteEnumerate
    SET FileOrder = RowNum
;
--===== Display just the files in filename order
 SELECT [FileName] = ObjectName
        ,FileOrder
   FROM #Order
  WHERE IsFile = 1
  ORDER BY [FileName]
;