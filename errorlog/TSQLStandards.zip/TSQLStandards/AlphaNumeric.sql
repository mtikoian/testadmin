CREATE FUNCTION dbo.AlphaNumeric
        (@String VARCHAR(MAX))
RETURNS VARCHAR(MAX) AS
  BEGIN
DECLARE @IncorrectCharLoc SMALLINT
 SELECT @IncorrectCharLoc = PATINDEX('%[^0-9A-Za-z]%', @String)
  WHILE @IncorrectCharLoc > 0
 SELECT @string = STUFF(@String, @IncorrectCharLoc, 1, ''),
        @IncorrectCharLoc = PATINDEX('%[^0-9A-Za-z]%', @String)
 RETURN @string
    END