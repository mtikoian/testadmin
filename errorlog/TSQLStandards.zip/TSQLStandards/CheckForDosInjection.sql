CREATE FUNCTION [dbo].[CheckForDosInjection]
/**********************************************************************************************************************
 Purpose:
 Checks a string for unauthorized characters which could be used for DOS injection.  Returns 'Clean' if no unauthorized
 characters exist and 'Dirty' if any unauthorized characters or the word "REM" followed by a space exists or a double
 colon exists (possible replacement for "REM").

 Usage:
 SELECT Status
   FROM dbo.CheckForDosInjection(@pString)
;

 Revision History:
 Rev 00 - 03 Jul 2013 - Jeff Moden - Initial Creation and Unit Test.
**********************************************************************************************************************/
--===== Declare the I/O for the function
        (
        @pString VARCHAR(8000)
        )
RETURNS TABLE AS
 RETURN
 SELECT Status =    CASE --When no unauthorized characters are present... (note the "double-negative" is essential)
                        WHEN @pString NOT LIKE '%[^a-zA-Z0-9:\*. __]"%' ESCAPE '_' 
                         AND CHARINDEX('REM ',@pString) = 0 
                         AND CHARINDEX('::',@pString) = 0
                        THEN 'CLEAN' 
                        ELSE 'DIRTY' --otherwise, 
                     END
;
 