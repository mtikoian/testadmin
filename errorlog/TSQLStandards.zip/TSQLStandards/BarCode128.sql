

CREATE FUNCTION dbo.BarCode128
/**********************************************************************************************************************
 Pupose:
 Given a string of legal "Type B" Barcode 128 characters, return the original string with StartCode, Checksum, and
 StopCode characters.

 Note that this will currently only handle "Type B" and no excursions to "Type A" or "Type C" are allowed. The 
 @pBarCodeStart is for future exapansion to handle such things.

 Usage:
 SELECT BarCode128
   FROM dbo.BarCode128('B','bananas') --�bananas�� expected
;

 References:
 http://en.wikipedia.org/wiki/Code_128
 http://courses.cs.washington.edu/courses/cse370/01au/minirproject/BarcodeBattlers/barcodes.html

 Revision History:
 Rev 00 - 05 Feb 2015 - Jeff Moden
        - Intial creation. Handles only legal "Type B" characters and no excursions to "Type A" or "Type C".
**********************************************************************************************************************/
        (
         @pBarCodeStart CHAR(1)
        ,@pString VARCHAR(8000)
        )
RETURNS TABLE AS --iSF or "Inline Scalar Function", in this case. 
 RETURN WITH
cteCheckSum AS
(
 SELECT CheckSumValue = (
                         ASCII(@pBarCodeStart)+38 --StartCode Value (38 is 103-65 and 65 is "A")
                        +SUM((ASCII(SUBSTRING(@pString,t.N,1))-32)*t.N)
                        )%103+32
   FROM dbo.fnTally(1,LEN(@pString)) t
)
 SELECT BarCode128 = 
          CHAR(ASCII(@pBarCodeStart)+143) --StartCode Character (143 is 200-65 and 65 is "A")
        + @pString                                                               --Original String
        + CHAR(CheckSumValue + CASE WHEN CheckSumValue < 127 THEN 0 ELSE 73 END) --CheckSum Character
        + CHAR(211)                                                              --StopCode Character
   FROM cteCheckSum
  WHERE @pBarCodeStart = 'B'
;

