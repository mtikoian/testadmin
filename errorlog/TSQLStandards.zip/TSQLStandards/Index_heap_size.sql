SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
GO

SELECT DB_NAME() AS DBName
	,s.NAME AS SchemaName
	,OBJECT_NAME(o.OBJECT_ID) AS TableName
	,ISNULL(i.NAME, 'HEAP') AS IndexName
	,i.index_id AS IndexID
	,CASE i.[type]
		WHEN 0
			THEN 'HEAP'
		WHEN 1
			THEN 'Clustered'
		WHEN 2
			THEN 'NonClustered'
		WHEN 3
			THEN 'XML'
		WHEN 4
			THEN 'Spatial'
		END AS IndexType
	,i.is_disabled AS IsDisabled
	,i.data_space_id
	,CASE 
		WHEN i.data_space_id > 65600
			THEN ps.NAME
		ELSE f.NAME
		END AS FG_or_PartitionName
	,p.partition_number AS PartitionNo
	,p.[rows] AS [RowCnt]
	--, p.data_compression_desc    AS CompressionType
	,au.type_desc AS AllocType
	,au.total_pages / 128 AS TotalMBs
	,au.used_pages / 128 AS UsedMBs
	,au.data_pages / 128 AS DataMBs
FROM sys.indexes i
LEFT OUTER JOIN sys.partition_schemes ps ON i.data_space_id = ps.data_space_id
LEFT OUTER JOIN sys.filegroups f ON i.data_space_id = f.data_space_id
INNER JOIN sys.objects o ON i.object_id = o.object_id
INNER JOIN sys.partitions p ON i.object_id = p.object_id
	AND i.index_id = p.index_id
INNER JOIN sys.schemas s ON o.schema_id = s.schema_id
INNER JOIN sys.allocation_units au ON CASE 
		WHEN au.[type] IN (
				1
				,3
				)
			THEN p.hobt_id
		WHEN au.[type] = 2
			THEN p.partition_id
		END = au.container_id
WHERE o.is_ms_shipped <> 1
ORDER BY au.total_pages DESC
OPTION (RECOMPILE);
