IF OBJECT_ID('KillProcess','P') IS NOT NULL
DROP PROCEDURE KillProcess
GO

/*******************************************************************************************************
**	Name:			KillProcess
**	Desc:			Kills a connection based on login, databasename, or both. Optionally sends email
**	Auth:			Adam Bean 
**  Parameters:		@LoginName = Login Name 
					@DBName = Database Name
					@SetSingleUser = Put database into single user mode
					@DropDB = Drop database 
					@SendEmail = Send an email with the results of what was killed
					@Recipients = Email recipients if @SendEmail is enabled
					@Debug = Shows but does not kill connections
**  Notes:			You can pass both a @LoginName and @DBName to kill connections from a login to a specified database
					No connections will be killed to system databases
					If you're sending email, make sure you have sqlmail setup or 2000 and databasemail for 2005
					Real and temp tables were used over temp table variables to support SQL2000
**  Execution:		EXEC killprocess @dbname='admin',@SetSingleUser=0,@sendemail=1,@Recipients='you@something.com', @debug=1
					EXEC killprocess @loginname='domain\user',@SetSingleUser=1,@sendemail=0,@Recipients='you@something.com', @debug=1
					EXEC killprocess @loginname='sqluser',@DropDB=1,@dbname='admin',@sendemail=1,@Recipients='you@something', @debug=1
**	Date:			02/14/2008
*******************************************************************************
**	Change History
*******************************************************************************
**	Date:		Author:		Description:
**	--------	--------	---------------------------------------
**	02.15.08	ASB			Fixed email debug, Added nolocks, Omitted system databases, 
							Added ability to drop database, Test for work to do,
							Verify database and login
********************************************************************************************************/

CREATE PROCEDURE [dbo].[KillProcess] 
(
	@LoginName			VARCHAR(128)	= NULL
	,@DBName			VARCHAR(128)	= NULL
	,@SetSingleUser		TINYINT			= 0
	,@DropDB			TINYINT			= 0
	,@SendEmail			TINYINT			= 0
	,@Recipients		VARCHAR(1024)	= NULL
	,@Debug				TINYINT			= 0
)

AS

DECLARE
	@Body				VARCHAR(4000)
	,@Subject			VARCHAR(256)
	,@ProductVersion	VARCHAR(16)
	,@SPID				INT
	,@SQLID				INT
	,@SQL				VARCHAR(128)
	,@Count				INT

SET NOCOUNT ON

IF @Debug = 1
	PRINT '/*** DEBUG ENABLED ****/'
ELSE
	SELECT 'Check messages for more details' AS 'More Info'

-- Verify work to do
IF @DBName IS NULL AND @LoginName IS NULL
BEGIN
	RAISERROR ('@DBName or @LoginName must be passed in.',16,1) WITH NOWAIT
	RETURN
END

-- Verify database
IF @DBName IS NOT NULL
BEGIN
	IF (SELECT COUNT(*) FROM master.dbo.sysdatabases WHERE NAME = @DBName) = 0
	BEGIN
		RAISERROR ('Database doesn''t exits.',16,1) WITH NOWAIT
		RETURN
	END
	ELSE IF (SELECT DATABASEPROPERTYEX(@DBName, 'Status')) <> 'ONLINE'
	BEGIN
		RAISERROR ('Database is not accessible.',16,1) WITH NOWAIT
		RETURN
	END
END

-- Verify login
IF @LoginName IS NOT NULL
BEGIN
	IF (SELECT COUNT(*) FROM master.dbo.syslogins WHERE name = @LoginName) = 0
	BEGIN
		RAISERROR ('Login doesn''t exits.',16,1) WITH NOWAIT
		RETURN
	END
END

-- Setup table to hold active connections
IF OBJECT_ID('KillProcesses','U') IS NOT NULL
DROP TABLE KillProcesses 

CREATE TABLE KillProcesses 
(
	[SPID]				[TINYINT],
	[DBName]			[VARCHAR](128),
	[Login]				[NVARCHAR](128),
	[HostName]			[NCHAR](128),
	[ProgramName]		[NCHAR](128),
	[Query]				[NVARCHAR](4000),
	[cmd]				[NCHAR](16),
	[Status]			[NCHAR](30),
	[LoginTime]			[DATETIME],
	[LastBatch]			[DATETIME] 
)

-- Build table based on type to kill
INSERT INTO KillProcesses
([spid], [DBName], [Login], [HostName], [ProgramName], [cmd], [Status], [LoginTime], [LastBatch])
SELECT 
      l.req_spid AS SPID
      ,DB_NAME(s.dbid) AS DBName
      ,SUSER_SNAME(s.sid) AS Login
      ,s.hostname
      ,s.program_name
      ,s.cmd
      ,s.status
      ,s.login_time
      ,s.last_batch
FROM 
      master.dbo.sysprocesses s WITH (NOLOCK)
LEFT OUTER JOIN master.dbo.syslockinfo l WITH (NOLOCK)
  	ON s.dbid = l.rsc_dbid
	AND l.req_spid = s.spid
WHERE l.req_spid <> @@SPID
AND ((
      -- DB was specified
      s.dbid = DB_ID(@DBName)
      AND @LoginName IS NULL
)
OR (
      -- LoginName was specified
      @DBName IS NULL
      AND SUSER_SNAME(s.sid) = @LoginName
)
OR (
      -- Both were specified
      s.dbid = DB_ID(@DBName)
      AND SUSER_SNAME(s.sid) = @LoginName
))
AND s.dbid > 4 -- Exclude system databases

-- Setup temp table to hold spid info
IF OBJECT_ID('tempdb.dbo.#QueryCmd','U') IS NOT NULL
DROP TABLE #QueryCmd

CREATE TABLE #QueryCmd
(
	SQLID				[INT] IDENTITY, 
	SPID				[INT], 
	EventType			[VARCHAR](100), 
	Parameters			[INT], 
	Command				[VARCHAR](4000)
)

-- Get DBCC INPUTBUFFER per spid
DECLARE spids CURSOR FOR
SELECT spid FROM KillProcesses

OPEN spids
FETCH NEXT FROM spids INTO @SPID
WHILE @@FETCH_STATUS = 0
BEGIN
	
	INSERT INTO #QueryCmd 
	(EventType, Parameters, Command)
	EXEC('DBCC INPUTBUFFER( ' + @SPID + ') WITH NO_INFOMSGS')

	SELECT @SQLID = MAX(SQLID) FROM #QueryCmd
	UPDATE #QueryCmd 
		SET spid = @SPID 
	WHERE SQLID = @SQLID 	

FETCH NEXT FROM spids INTO @SPID
END
CLOSE spids
DEALLOCATE spids

-- Update main table with new spid info
UPDATE a
	SET a.Query = q.command
FROM KillProcesses a
	JOIN #QueryCmd q
	ON a.spid = q.spid

-- Return results before kill
IF (SELECT COUNT(*) FROM KillProcesses) > 0
BEGIN
	SELECT * FROM KillProcesses
END
ELSE
BEGIN
	SELECT 'No active connections to kill' AS 'Connections'
	PRINT 'No active connections to kill'
END

-- Kill the connections 
IF (SELECT COUNT(*) FROM KillProcesses) > 0
BEGIN
	DECLARE killspids CURSOR FOR
	SELECT spid FROM KillProcesses

	OPEN killspids
	FETCH NEXT FROM killspids INTO @SPID
	WHILE @@FETCH_STATUS = 0
	BEGIN
		
		SET @SQL = 'KILL ' + CAST(@SPID AS VARCHAR(5)) + ''
		IF @Debug = 0
		BEGIN
			EXEC(@SQL)
			PRINT 'KILLED ' + CAST(@SPID AS VARCHAR(5)) + ''
		END	
		ELSE
		BEGIN	
			PRINT (@SQL)
		END

	FETCH NEXT FROM killspids INTO @SPID
	END
	CLOSE killspids
	DEALLOCATE killspids
END

-- Set database to single user 
IF @SetSingleUser = 1
BEGIN
SET @SQL = 'ALTER DATABASE ' + @DBName + ' SET SINGLE_USER WITH ROLLBACK IMMEDIATE'
	IF @Debug = 0
	BEGIN
		EXEC(@SQL)
		PRINT @DBName + ' has been put into single user mode'
		PRINT 'To put ' + @DBName + ' back into multi user mode, issue: ALTER DATABASE ' + @DBName + ' SET MULTI_USER WITH NO_WAIT'
	END
	ELSE
	BEGIN
		PRINT(@SQL)
	END
END

-- Drop database 
IF @DropDB = 1
BEGIN
SET @SQL = 'DROP DATABASE ' + @DBName + ''
	IF @Debug = 0
	BEGIN
		EXEC(@SQL)
		PRINT @DBName + ' has been dropped'
	END
	ELSE
	BEGIN
		PRINT(@SQL)
	END
END

-- Send email
IF @SendEmail = 1
BEGIN
	IF @Debug = 0
	BEGIN
		IF @Recipients IS NULL
		BEGIN
			RAISERROR ('@Recipients must be passed in.',16,1) WITH NOWAIT
			RETURN
		END
		ELSE
		BEGIN
			IF (SELECT COUNT(*) FROM KillProcesses) > 0 -- Only send email if connections were present
			BEGIN
				DECLARE @EmailBody TABLE 
				(
					ID		INT IDENTITY,
					html	VARCHAR(4000)
				)
				SET @Subject = 'Active connections terminated on ' + @@SERVERNAME + ''
				INSERT INTO @EmailBody
				SELECT * FROM 
					(
						SELECT '
							<HTML>
								<TABLE BORDER ="1">
								<TR>
									<TH>SPID</TH>
									<TH>Database</TH>
									<TH>Login</TH>
									<TH>HostName</TH>
									<TH>ProgramName</TH>
									<TH>Query</TH>
									<TH>Command</TH>
									<TH>Status</TH>
									<TH>LoginTime</TH>
									<TH>LastBatch</TH>
								</TR>' AS html
						UNION ALL
						SELECT '
								<TR>
									<TD>' + CAST([spid] AS VARCHAR(5)) + '</TD>
									<TD>' + [DBName] + '</TD>
									<TD>' + [Login] + '</TD>
									<TD>' + [HostName] + '</TD>
									<TD>' + [ProgramName] + '</TD>
									<TD>' + [Query] + '</TD>
									<TD>' + [cmd] + '</TD>
									<TD>' + [Status] + '</TD>
									<TD>' + CONVERT(VARCHAR(20), [LoginTime], 100)+ '</TD>
									<TD>' + CONVERT(VARCHAR(20), [LastBatch], 100) + '</TD>
								</TR>'
						FROM KillProcesses
						UNION ALL
						SELECT '
								</TABLE>
							</HTML>'
					)t
				SET @Count = 1
				SET @Body = ''
				WHILE @Count <= (SELECT COUNT(*) FROM @EmailBody)
				BEGIN
					SET @Body = @Body + (SELECT html FROM @EmailBody WHERE ID = @Count)
					SET @Count = @Count + 1
				END
				-- Get SQL Version
				SELECT @ProductVersion = CAST(SERVERPROPERTY('ProductVersion') AS VARCHAR(16))
					IF LEFT(@ProductVersion,1) = 8
						BEGIN
							EXEC master.dbo.xp_sendmail 
								@recipients		= @Recipients
								,@subject		= @Subject
								,@query			= 'SELECT * FROM KillProcesses'
						END
					ELSE
						BEGIN
							EXEC msdb.dbo.sp_send_dbmail 
								@recipients		= @Recipients
								,@subject		= @Subject
								,@body			= @Body
								,@body_format	= 'HTML'
				END
			END
		END
	END
	ELSE
	BEGIN
		PRINT 'Debug enabled, no email will be sent'
	END
END

-- Cleanup
IF OBJECT_ID('KillProcesses','U') IS NOT NULL
DROP TABLE KillProcesses 

SET NOCOUNT OFF