CREATE FUNCTION dbo.RemoveSpecialCharacters
/**********************************************************************************************************************
 Purpose:
 This Scalar function removes all special characters except spaces, returns blank results as NULL, and converts
 multiple adjacent spaces to single spaces.

 Usage:
 SELECT dbo.RemoveSpecialCharacters(@pSomeString);

 SELECT dbo.RemoveSpecialCharacters(SomeStringColumn)
   FROM dbo.SomeTable;

   SELECT dbo.RemoveSpecialCharacters('This string contains special chracters:/ Which * & we % need @ to #remove')
;

 Reference:
 George Mastros post
 http://stackoverflow.com/questions/1007697/how-to-strip-all-non-alphabetic-characters-from-string-in-sql-server/1008566

 Revision History:
 Rev 00 - 08 Jul 2012 - Jeff Moden
        - Redaction of code to meet the current requirements stated in the "Purpose" above.
**********************************************************************************************************************/
--===== Declare the I/O for this function
        (@pSomeString VARCHAR(8000))
RETURNS VARCHAR(8000) WITH SCHEMABINDING AS
  BEGIN
--===== Delete all special characters except spaces.
  WHILE PATINDEX('%[^a-zA-Z0-9 ]%',@pSomeString COLLATE Latin1_General_BIN) > 0
    SET @pSomeString = STUFF(@pSomeString,PATINDEX('%[^a-zA-Z0-9 ]%',@pSomeString COLLATE Latin1_General_BIN),1,'');
--===== Convert empty strings to NULL, replace multiple adjacent spaces with just one, and return the function value.
 RETURN REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(NULLIF(@pSomeString,''),'  ',' '),'  ',' '),'   ',' '),'     ',' '),'          ',' ');
    END
;
GO
