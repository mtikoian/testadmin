CREATE FUNCTION dbo.GetFirstBracketDecimal
        (@String VARCHAR(50))

		--===== Create and populate the Tally table on the fly
-- SELECT TOP 20000
--        IDENTITY(INT,1,1) AS N
--   INTO dbo.Tally
--   FROM Master.dbo.SysColumns sc1,
--        Master.dbo.SysColumns sc2

----===== Add a Primary Key to maximize performance
--  ALTER TABLE dbo.Tally
--    ADD CONSTRAINT PK_Tally_N 
--        PRIMARY KEY CLUSTERED (N) WITH FILLFACTOR = 100

----===== Allow the general public to use it
--  GRANT SELECT ON dbo.Tally TO PUBLIC


--		--===== Create a test table and populate it with data from the original post.
--     -- THIS IS NOT PART OF THE SOLUTION!
-- CREATE TABLE #yourtable (GroupDesc VARCHAR(50))
-- INSERT INTO  #yourtable (GroupDesc)
-- SELECT 'Goboland Steel Gobo' UNION ALL
-- SELECT 'Procolor (39.0)' UNION ALL
-- SELECT 'Rosco J1 (43.?)' UNION ALL
-- SELECT 'Doughty 2, 3 & 4 (70.1)' UNION ALL
-- SELECT 'Clay Paky Spares (no PDF)' UNION ALL
-- SELECT 'DBX (A11.0)' UNION ALL
-- SELECT 'Le Mark (Stocked) (no PDF)' UNION ALL
-- SELECT 'Le Mark (non stocked) (no PDF)'
--GO

RETURNS DECIMAL(9,2) --Uses 4 bytes less than (10,2)
     AS
  BEGIN
        --===== Declare local variables
        DECLARE @WorkString VARCHAR(50)

        --===== Concatenate only numeric characters found in the first set of parentheses
         SELECT @WorkString = COALESCE(@WorkString,'') + SUBSTRING(@String,t.N,1)
           FROM dbo.Tally t
          WHERE t.N BETWEEN CHARINDEX('(',@String) +1 
                        AND CHARINDEX(')',@String) -1 
            AND SUBSTRING(@String,t.N,1) LIKE '[0-9.]'

        --===== Return the found value converting things where nothing was found to 0.
         RETURN ISNULL(@WorkString,0)
    END
GO
--===== Test the function using the test data from the original post
 SELECT GroupDesc, dbo.GetFirstBracketDecimal(GroupDesc) AS FoundDecimalValue
   FROM #yourtable
GO