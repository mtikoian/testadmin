
CREATE FUNCTION dbo.RemoveDupes8K(@string varchar(8000), @preserved varchar(100))
/*******************************************************************************
Purpose:
  Given a string (@String) this function will remove all instances of 
  repeated characters. The @preserved parameter can be used to ignore
  (and preserve) duplicate characters if they match the pattern. 
  
  This function performs much better when using make_parallel().  

Usage Examples:
  DECLARE @string varchar(8000) = '!!!aa###bb!!!'; -- !a#b!

  -- Remove all duplicate characters
  SELECT * FROM dbo.RemoveDupes8k(@string,'');

  -- Remove all non-alpha duplicates 
  SELECT * FROM dbo.RemoveDupes8k(@string,'[A-Za-z]');

  -- Remove only alphabetical duplicates 
  SELECT * FROM dbo.RemoveDupes8k(@string,'[^A-Za-z]');

Revision History:
 Rev 00 - 06/21/2015 Initial Development - Alan Burstein
*******************************************************************************/
RETURNS TABLE WITH SCHEMABINDING AS RETURN
WITH 
E1(N) AS (SELECT 1 FROM (VALUES (1),(1),(1),(1),(1),(1),(1),(1),(1),(1)) T(C)), -- 10
E2(N) AS (SELECT 1 FROM E1 a, E1 b), -- 100
iTally(N) AS 
(
  SELECT TOP(DATALENGTH(@string)) ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) 
  FROM E2 a, E2 b  -- 10K
) 
SELECT NewString = 
(
  SELECT SUBSTRING(@string,N,1)+''
  FROM iTally
  WHERE SUBSTRING(@string,N,1) <> SUBSTRING(@string,N+1,1) 
  OR SUBSTRING(@string,N,1) LIKE @preserved
  FOR XML PATH(''), TYPE
).value('.[1]', 'varchar(8000)');
GO


--SELECT D.ItemNumber, D.Item
--FROM #Sample S
--CROSS APPLY dbo.PatReplace8K(Numbers,'[^0-9]',',') P -- Replace all non-numeric characters with a comma
--CROSS APPLY dbo.RemoveDupes8K(P.NewString,'[0-9]') R -- Remove all duplicate commas
--CROSS APPLY dbo.delimitedsplit8K(R.NewString,',')  D -- Now split the comma-delimited string
--WHERE D.item <> '' -- exclude records with a leading commma. 