/**********************************************************************************************************************
 Purpose:
 For the current database, find all tables having an IDENTITY column, compare the value of IDENT_CURRENT against the
 MAX value in the column, and report those tables and values that aren't an exact match.

 Revision History:
 Rev 00 - 17 Oct 2016 - Jeff Moden
          Initial creation and unit test.
          REF: http://www.sqlservercentral.com/Forums/Topic1826014-3411-1.aspx
 Rev 01 - 18 Oct 2016 - Jeff Moden
          Add QUOTENAME() to the REPLACEs to cover the eventuality of names with dashes, spaces, and other horrors. Wink
**********************************************************************************************************************/
--===== Declare the code accumulator variable
DECLARE @SQL VARCHAR(MAX)
;
--===== Find every IDENTITY column and build the dynamic SQL to list the
     -- IDENT_CURRENT value and the MAX value in the column.
     -- This uses a <<TOKEN>> replacement method instead of a bazillion quotes and plus signs.
 SELECT @SQL = ISNULL(@SQL + '  UNION ALL','') 
             + REPLACE(REPLACE(REPLACE(REPLACE('
 SELECT  QualifiedObjectName = "<<SchemaName>>.<<ObjectName>>"
        ,CurrentIdentityVal  = IDENT_CURRENT("<<SchemaName>>.<<ObjectName>>")
        ,CurrentMaxVal       = MAX(<<ColumnName>>) 
   FROM <<SchemaName>>.<<ObjectName>>
 HAVING IDENT_CURRENT("<<SchemaName>>.<<ObjectName>>") <> ISNULL(MAX(<<ColumnName>>),-2147483648)
'           -- These are the other end of the REPLACEs.
            ,'"','''')
            ,'<<SchemaName>>',QUOTENAME(OBJECT_SCHEMA_NAME(object_id))) --Rev 01
            ,'<<ObjectName>>',QUOTENAME(OBJECT_NAME(object_id)))        --Rev 01
            ,'<<ColumnName>>',QUOTENAME(name))                          --Rev 01
   FROM sys.columns
  WHERE is_identity = 1
    AND OBJECT_SCHEMA_NAME(object_id) <> 'sys'
    AND OBJECTPROPERTY(object_id,'IsTable') = 1
;
--===== Display ALL the code to be executed up to the length limit of the server XML max length.
     -- This returns a clickable XML "Cell" when in the GRID MODE for result sets in SSMS.
 SELECT SQLCode = (SELECT REPLACE(CAST('--' + CHAR(10) + @SQL + CHAR(10) AS VARCHAR(MAX)), CHAR(0),'') --CHAR(0) (Null) cannot be converted to XML.
                       AS [processing-instruction(SQLCode)] 
                      FOR XML PATH(''), TYPE)
;
--===== Uncomment this once you've determined that the dynamic SQL is actually safe to run.
   --EXEC (@SQL)
;
