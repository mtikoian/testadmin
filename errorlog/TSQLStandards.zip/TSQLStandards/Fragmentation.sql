IF OBJECT_ID('tempdb.dbo.#index_info') IS NOT NULL
    DROP TABLE #index_info;

SELECT TOP (0)
dbschemas.[name] AS schema_name,db_name() AS db_name,
dbtables.[name] AS table_name ,
dbindexes.[name] AS index_name ,
indexstats.avg_fragmentation_in_percent,
indexstats.page_count
INTO #index_info
FROM sys.dm_db_index_physical_stats (DB_ID(), NULL, NULL, NULL, NULL) AS indexstats
INNER JOIN sys.tables dbtables on dbtables.[object_id] = indexstats.[object_id]
INNER JOIN sys.schemas dbschemas on dbtables.[schema_id] = dbschemas.[schema_id]
INNER JOIN sys.indexes AS dbindexes ON dbindexes.[object_id] = indexstats.[object_id]
AND indexstats.index_id = dbindexes.index_id


EXEC sp_MSForeachdb
'
USE [?];
--PRINT ''?'';
INSERT INTO #index_info
SELECT dbschemas.[name],db_name(),
dbtables.[name] ,
dbindexes.[name] ,
indexstats.avg_fragmentation_in_percent,
indexstats.page_count
FROM sys.dm_db_index_physical_stats (DB_ID(), NULL, NULL, NULL, NULL) AS indexstats
INNER JOIN sys.tables dbtables on dbtables.[object_id] = indexstats.[object_id]
INNER JOIN sys.schemas dbschemas on dbtables.[schema_id] = dbschemas.[schema_id]
INNER JOIN sys.indexes AS dbindexes ON dbindexes.[object_id] = indexstats.[object_id]
AND indexstats.index_id = dbindexes.index_id
WHERE indexstats.database_id = DB_ID()
ORDER BY indexstats.avg_fragmentation_in_percent desc
'

SELECT * 
FROM #index_info
ORDER BY db_name, table_name, index_name
