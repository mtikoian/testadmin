
CREATE FUNCTION dbo.GetNumberofWeekDaysYearly
(@StartDate DATETIME, @EndDate DATETIME, @ClientDate DATETIME)
RETURNS SMALLINT
AS
BEGIN

--===== Declare some local variables to control bounds of dates
DECLARE @YearStart DATETIME,
@YearEnd DATETIME,
@DowClient INT

--===== Calculate the correct bounds of dates
SELECT @YearStart = DATEADD(yy,DATEDIFF(yy,0,@ClientDate),0),
@YearEnd = DATEADD(yy,DATEDIFF(yy,-1,@ClientDate),-1),
@StartDate = CASE 
WHEN @StartDate < @YearStart 
THEN @YearStart
ELSE @StartDate
END, 
@EndDate = CASE 
WHEN @EndDate > @YearEnd 
THEN @YearEnd
ELSE @EndDate
END,
@DowClient = DATEDIFF(dd,0,@ClientDate)%7

--===== Calculate and return the count for the bounds of dates
-- based on the day of the week for the Client Date
RETURN (SELECT COUNT(*)
--@StartDate+(t.N-1),DATENAME(dw,@StartDate+(t.N-1))
FROM dbo.Tally t
WHERE @StartDate+(t.N-1) BETWEEN @StartDate AND @EndDate
AND DATEDIFF(dd,0,@StartDate+(t.N-1))%7 = @DowClient)
END