SELECT 
    ISNULL(CAST(ASCII(SUBSTRING(data, 1, 1)) AS varchar(3)), '') +
    ISNULL(CAST(ASCII(SUBSTRING(data, 2, 1)) AS varchar(3)), '') +
    ISNULL(CAST(ASCII(SUBSTRING(data, 3, 1)) AS varchar(3)), '') +
    ISNULL(CAST(ASCII(SUBSTRING(data, 4, 1)) AS varchar(3)), '') +
    ISNULL(CAST(ASCII(SUBSTRING(data, 5, 1)) AS varchar(3)), '')
FROM (
    SELECT '02yC' AS data UNION ALL
    SELECT '12G8' UNION ALL
    SELECT '9Pp1' UNION ALL
    SELECT '7@uL' UNION ALL
    SELECT '' UNION ALL
    SELECT 'a' UNION ALL
    SELECT 'b2' UNION ALL
    SELECT 'c34' UNION ALL
    SELECT 'd456' UNION ALL
    SELECT 'e5678' UNION ALL
    SELECT 'f90123'
) AS test_data