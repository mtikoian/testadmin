-- Sample data, solution
DECLARE @samples TABLE (dob date);
INSERT @samples VALUES 
('20161102'),('20150326'),('20150717'),('20140818'),('20120712'),('20121201'),('20120522');

-- Solution
SELECT dob,
   Age    = YY + CASE WHEN MM < 6 THEN 0 ELSE 1 END,
   calculated_age = YY+' Years '+MM+' Months '+DD+' Days'
FROM @samples s
CROSS APPLY 
(
  SELECT CAST(YEAR(DATEDIFF(DD, s.dob, GETDATE())) - 1900 AS varchar(4)), --Years
   CAST(MONTH(DATEDIFF(DD, s.dob, GETDATE())) - 1 AS VARCHAR(2)), --Months
   CAST(DAY(DATEDIFF(DD, s.dob, GETDATE())) AS VARCHAR(2))    --Days
) Parts(YY,MM,DD);