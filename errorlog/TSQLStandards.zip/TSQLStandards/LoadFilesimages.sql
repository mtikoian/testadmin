CREATE PROCEDURE dbo.LoadFiles
/*****************************************************************************************
 Purpose:
 Given a valid file path that SQL Server can "see" and an extension (can be a wildcard),
 load all of the files as images.
------------------------------------------------------------------------------------------
 Programmer notes:
 1. If either parameter contains signs of DOS Injection, the proc will return with no 
    error or any indication of what might be wrong so as to not give an attacker any
    hints.
------------------------------------------------------------------------------------------
 Example Usage:
--===== Simple syntax
   EXEC dbo.LoadFiles @pFullPath, @pExtension 
;
--===== Example to load all JPG files from C:\Temp and all of its subdirectories.
   EXEC dbo.LoadFiles 'C:\Temp', 'jpg' 
;
------------------------------------------------------------------------------------------
 Revision History:
 Rev 00 - 08 Dec 2014 - Jeff Moden
                      - Initial creation and unit test
*****************************************************************************************/
--===== Declare the paramters for this proc
         @pFullPath     VARCHAR(2000)
        ,@pExtension    VARCHAR(500)
     AS
--========================================================================================
--      Presets
--========================================================================================
--===== Setup the environment
    SET NOCOUNT ON;

--===== Local Variables
DECLARE  @Cmd           VARCHAR(2000)
        ,@BulkCmd       VARCHAR(MAX)
;
--===== Create the temp table to hold all the full file path names
 CREATE TABLE #FileName
        (
         FileNameID     INT IDENTITY(1,1)
        ,FUllPathName   VARCHAR(2000)
        ,Folder         VARCHAR(128)
        ,SubFolder      VARCHAR(128)
        ,[FileName]     VARCHAR(128)
        )
;
--========================================================================================
--      Get the desired file names from the given directory on down
--========================================================================================
--===== Create the DOS command to get ALL of the files with the correct extensions
     -- in all directories from the given @pFullPath on down.
 SELECT @Cmd = REPLACE(REPLACE(
               'DIR "<<@pFullPath>>\*.<<@pExtension>>" /s /b'
               ,'<<@pFullPath>>',@pFullPath)
               ,'<<@pExtension>>',@pExtension)
;
--===== Delouse the command to help prevent DOS injection
     IF 'Dirty' = (SELECT Status FROM dbo.CheckForDosInjection(@Cmd))
        RETURN -- We're intentionally exiting early with no error to not give an attacker hints
;
--===== Get the full file path names
 INSERT INTO #FileName (FUllPathName)
   EXEC xp_CmdShell @Cmd
;
--===== Split out the "Folder", "SubFolder", and "FileName" parts and remember them
WITH 
cteSplit AS
( --=== This splits the full file path name into parts based on backslashes
     -- and numbers them in descending order.
 SELECT  FileNameID
        ,RowNum = ROW_NUMBER() OVER (PARTITION BY FileNameID ORDER BY ItemNumber DESC)
        ,Item
   FROM #FileName
  CROSS APPLY dbo.DelimitedSplit8K(FUllPathName,'\')
  WHERE FUllPathName > '' --NOT NULL AND NOT BLANK
)
,
ctePivot AS
( --=== This takes the last 3 parts of the full file path name and assigns
     -- them to the desired columns
 SELECT  FileNameID
        ,Folder     = MAX(CASE WHEN RowNum = 3 THEN cte.Item ELSE '' END)
        ,SubFolder  = MAX(CASE WHEN RowNum = 2 THEN cte.Item ELSE '' END)
        ,[FileName] = MAX(CASE WHEN RowNum = 1 THEN cte.Item ELSE '' END)
   FROM cteSplit  cte
  GROUP BY cte.FileNameID
) --=== Then, we update the file name table with that info.
 UPDATE tgt
    SET tgt.Folder      = pvt.Folder
        ,tgt.SubFolder  = pvt.SubFolder
        ,tgt.[FileName] = pvt.[FileName]
   FROM ctePivot pvt
   JOIN #FileName tgt
     ON tgt.FileNameID = pvt.FileNameID
;
--========================================================================================
--      Load all the files that we've gotten names for
--========================================================================================
--===== Create the BULK command
 SELECT @BulkCmd = ''
 SELECT @BulkCmd = @BulkCmd + REPLACE(REPLACE(REPLACE(REPLACE(REPLACE('
 INSERT INTO dbo.LoadedImage 
       (Folder, SubFolder, Name, Photo)
 SELECT <<Folder>>,<<SubFolder>>,<<Name>>,blob.BulkColumn
   FROM OPENROWSET(BULK "<<FUllPathName>>", SINGLE_BLOB) blob
;'
        ,'"'               ,'''')
        ,'<<FUllPathName>>',FUllPathName)
        ,'<<Folder>>',QUOTENAME(Folder,''''))
        ,'<<SubFolder>>',QUOTENAME(SubFolder,''''))
        ,'<<Name>>',QUOTENAME([FileName],''''))
   FROM #FileName
  WHERE FUllPathName IS NOT NULL
;
--===== Load all the files along with all the amplifying information
   EXEC (@BulkCmd)
;
GO
