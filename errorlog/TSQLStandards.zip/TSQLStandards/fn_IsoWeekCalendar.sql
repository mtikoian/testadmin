 CREATE FUNCTION dbo.IsoWeekCalendar
/**********************************************************************************************************************
 Purpose:
 Given a start and end date, create an on-the-fly ISO Week table for the years involved as identified by the start and
 end date.  Important: See "Developer Notes 1." below for limits on dates.

 Usage Examples:
--===== Basic syntax
 SELECT *
   FROM dbo.IsoWeekCalendar(@pStartDate,@pEndDate)
;
--===== Full DATETIME example
 SELECT *
   FROM dbo.IsoWeekCalendar('2015-04-05 15:35:27.123','2016-06-07 09:25:18.997')
;
--===== Whole year example (years must be in single quotes if a literal)
 SELECT *
   FROM dbo.IsoWeekCalendar('1753','9998') --Demonstration of the min and max limits of this function.
;

 Developer Notes:
 1. The low value for any date should have a year >= 1753 and the high value for any date should have a year <= 9998.
 2. Derived from an original concept created by "t-clausen.dk" at the following link:
    http://stackoverflow.com/questions/7330711/isoweek-in-sql-server-2005
 3. Functionality improved by Peter Larsson and Jeff Moden and explained in full by Jeff Moden at the following link:
    http://www.sqlservercentral.com/articles/T-SQL/97910/

 Dependencies:
 1. Requires SQL Server 2005 or better.
 2. Requires separate dbo.fnTally inline Table Valued Function to already exist and must be able to return a "0" 
    to start a sequence.

 Revision History:
 Rev 00 - 30 Oct 2016 - Jeff Moden
        - Initial creation and unit test to support the following forum post:
        - http://www.sqlservercentral.com/Forums/Topic1830292-3412-1.aspx 
**********************************************************************************************************************/
--===== Parameters for this function
        (
         @pStartDate    DATETIME 
        ,@pEndDate      DATETIME
        )
RETURNS TABLE WITH SCHEMABINDING AS
 RETURN WITH 
        cteStartEndDates AS
( --=== Find the Monday for the first year involved (might be in the previous year)
     -- and the first Monday after the last year involved (might be in the next year)
 SELECT  StartDate      = DATEADD(dd,DATEDIFF(dd,0,DATEADD(yy,DATEDIFF(yy, 0,@pStartDate),0))/7*7  ,0)
        ,EndDate        = DATEADD(dd,DATEDIFF(dd,0,DATEADD(yy,DATEDIFF(yy,-1,@pEndDate  ),0))/7*7+7,0)
)
,       cteAllDates AS
( --=== Build all the Monday/Thursday dates for the date range identified in the previous CTE.
     -- We need the Thursday date to calculate the ISO Year.
 SELECT  Monday         = DATEADD(dd,t.N*7  ,dt.StartDate)
        ,Thursday       = DATEADD(dd,t.N*7+3,dt.StartDate)
   FROM cteStartEndDates dt
  CROSS APPLY dbo.fnTally(0,DATEDIFF(dd,dt.StartDate,dt.EndDate)/7) t
) 
,       cteISOWeekCalendar AS
( --=== Create the ISO Week Calendar for the years involved by the input parameters and some spillover.
 SELECT  WeekStart      = ad.Monday
        ,NextWeekStart  = DATEADD(dd,7,ad.Monday)
        ,ISOWeek        = (DATEPART(dy,DATEADD(dd,DATEDIFF(dd,'17530101',ad.Monday)/7*7,'17530104'))+6)/7
        ,ISOYear        = DATEPART(yy,ad.Thursday)
   FROM cteAllDates ad
)
--===== Return the ISO Week Calendar for the years involved by the input parameters without spillover.
 SELECT wc.WeekStart, wc.NextWeekStart, wc.ISOYear, wc.ISOWeek
   FROM cteISOWeekCalendar wc
  WHERE wc.ISOYear BETWEEN DATEPART(yy,@pStartDate) AND DATEPART(yy,@pEndDate)
;

GO