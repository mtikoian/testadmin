--DROP VIEW dbo.PreviousQuarters
;
GO
 CREATE VIEW dbo.PreviousQuarters AS
/**************************************************************************************************
 Purpose:
    Aggregate the last 3 quarters and the current quarter through all of today and produce a
    "vertical" report.

    It has all sorts of different sub-totals, looks kind of pretty, is nasty fast, and you never
    have to change a date because it figures out the quartes auto-magically.

    You can also do neat things like selecting just detail rows or just subtotal rows, etc.

 Examples (not all inclusive and sorts not guaranteed without an ORDER BY):
--===== Produce the entire report
 SELECT * 
   FROM dbo.PreviousQuarters
  ORDER BY SortOrder
;
--===== Produce a report just for where SomeLetters 2 = 'JM' or 'QZ'
     -- and include a "Percent of Total" for each row where the "Total"
     -- is the total of SomeMoney between the two. Since subtotals are
     -- included in all that, we have to divide the total by 2.
     -- A "Percent of Grand Total" for all data in the quarters is included, as well.
 SELECT *
        ,PercentOfTotal      = SomeMoney/((SUM(SomeMoney) OVER ())/2) * 100 
        ,PercentofGrandTotal = SomeMoney*100.0/(SELECT SUM(SomeMoney) FROM dbo.PreviousQuarters)
   FROM dbo.PreviousQuarters 
  WHERE SomeLetters2 IN ('JM','QZ')
  ORDER BY SortOrder
;
--===== Produce a report just for quarter subtotals and the grand total
 SELECT * 
   FROM dbo.PreviousQuarters 
  WHERE RowDescription IN ('SubTotal Quarter','Grand Total')
  ORDER BY SortOrder
;
--===== Produce a report just for SomeLetters2 subtotals and the grand total
 SELECT * 
   FROM dbo.PreviousQuarters 
  WHERE RowDescription IN ('SubTotal SomeLetters2','Grand Total')
  ORDER BY SortOrder
;

 Revision History:
 Rev 00 - 04 Mar 2016 - Jeff Moden
        - Initial creation and unit test
        - Ref:  http://www.sqlservercentral.com/Forums/Topic1766578-3412-1.aspx#bm1766600
        -       https://technet.microsoft.com/en-us/library/bb522495(v=sql.105).aspx
        -       https://technet.microsoft.com/en-us/library/ms178544(v=sql.105).aspx
**************************************************************************************************/
   WITH cteQuarter AS
(
 SELECT  Qtr = DATENAME(yy,SomeDateTime)+' Q'+DATENAME(qq,SomeDateTime)
        ,SomeLetters2
        ,SomeMoney 
   FROM dbo.JBMTest
  WHERE SomeDateTime >= DATEADD(qq,DATEDIFF(qq,0,GETDATE())-3,0) --Start of 3 quarters ago
    AND SomeDateTime <  DATEADD(dd,DATEDIFF(dd,0,GETDATE())+1,0) --Through all of today
)
 SELECT  SortOrder =
            ROW_NUMBER() OVER (ORDER BY  GROUPING(SomeLetters2), SomeLetters2
                                        ,GROUPING(Qtr), Qtr)
        ,RowDescription  =  
            CASE
                WHEN GROUPING(SomeLetters2) = 0 AND GROUPING(Qtr) = 0 THEN 'Detail'
                WHEN GROUPING(SomeLetters2) = 0 AND GROUPING(Qtr) = 1 THEN 'SubTotal SomeLetters2'
                WHEN GROUPING(SomeLetters2) = 1 AND GROUPING(Qtr) = 0 THEN 'SubTotal Quarter'
                WHEN GROUPING(SomeLetters2) = 1 AND GROUPING(Qtr) = 1 THEN 'Grand Total'
                ELSE 'ERROR'
            END
        ,Qtr = 
            CASE
                WHEN GROUPING(SomeLetters2) = 0 AND GROUPING(Qtr) = 0 THEN Qtr
                WHEN GROUPING(SomeLetters2) = 0 AND GROUPING(Qtr) = 1 THEN ''
                WHEN GROUPING(SomeLetters2) = 1 AND GROUPING(Qtr) = 0 THEN Qtr
                WHEN GROUPING(SomeLetters2) = 1 AND GROUPING(Qtr) = 1 THEN ''
                ELSE 'ERROR'
            END
        ,SomeLetters2 = 
            CASE
                WHEN GROUPING(SomeLetters2) = 0 AND GROUPING(Qtr) = 0 THEN SomeLetters2
                WHEN GROUPING(SomeLetters2) = 0 AND GROUPING(Qtr) = 1 THEN SomeLetters2
                WHEN GROUPING(SomeLetters2) = 1 AND GROUPING(Qtr) = 0 THEN ''
                WHEN GROUPING(SomeLetters2) = 1 AND GROUPING(Qtr) = 1 THEN ''
                ELSE 'ERROR'
            END
        ,SomeMoney = SUM(SomeMoney)
   FROM cteQuarter
  GROUP BY SomeLetters2, Qtr WITH CUBE
;