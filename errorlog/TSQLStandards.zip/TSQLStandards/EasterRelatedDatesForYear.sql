 CREATE FUNCTION dbo.EasterRelatedDatesForYear
/**********************************************************************************************************************
 Purpose:
 Given a date, calculate when Easter Sunday will occur for the year of that date.  This function also calculates the 
 "main" Easter related dates.  It does not calculate "Lent", which has interpretations for when it ends depending on 
 the particular faith.
-----------------------------------------------------------------------------------------------------------------------
 Credits/References:
 This function is based on a 19 year cycle, which I first picked up on from Peter "PESO" Larsson at the following URL:
        http://weblogs.sqlteam.com/peterl/archive/2010/09/08/fast-easter-day-function.aspx
 A deeper explanation of where the 19 year cycle comes from is realized at the following URL (Dwain Camps).
        http://www.sqlservercentral.com/blogs/dwainsql/2015/03/31/an-easter-sql/

 For information about when Lent start and ends, depending on faith, the following GOOGLE search will help.
        https://www.google.com/?gws_rd=ssl#q=when+does+lent+end+catholic
-----------------------------------------------------------------------------------------------------------------------
 Programmers Notes:
 1. This is a high performance iSF (Inline Scalar Function) that actually returns a single row table of values instead
    of a single scalar value.  Please refer to the following article for why it's so fast.
        http://www.sqlservercentral.com/articles/T-SQL/91724/
-----------------------------------------------------------------------------------------------------------------------
 Usage Examples;
--===== Basic Syntax for single date row ==============================================================================
 SELECT *
   FROM dbo.EasterRelatedDatesForYear(@SomeDate)
;
--===== Basic Syntax for multiple dates from a table containing a column (for example) called "SomeDate" ==============
 SELECT  st.SomeDate
        ,ca.*
   FROM dbo.SomeTable st
  CROSS APPLY dbo.EasterRelatedDatesForYear(st.SomeDate) ca
;
--===== Generate all days for all years in a given date range (1900 thru 9999, in this case) ==========================
--===== Obviously named variables
     -- The ones starting with @p could be parameters in an iTVF (inline Table Valued Function)
DECLARE  @pStartYear DATETIME
        ,@pEndYear   DATETIME
        ,@Years      INT     
;
--===== Preset the parameter variables and calculate the number of years in the range even for just 1 day.
 SELECT  @pStartYear = '1900' --Implicity converts to 1900-01-01
        ,@pEndYear   = '9999' --Implicity converts to 9999-01-01
        ,@Years      = DATEDIFF(yy,@pStartYear,@pEndYear)+1
;
--===== Calculate the Easter related dates for all years in the range of dates.
   WITH 
 E1(N)    AS    (--==== Creates up to 10 rows
                 SELECT 1 UNION ALL SELECT 1 UNION ALL SELECT 1 UNION ALL
                 SELECT 1 UNION ALL SELECT 1 UNION ALL SELECT 1 UNION ALL
                 SELECT 1 UNION ALL SELECT 1 UNION ALL SELECT 1 UNION ALL SELECT 1
                ) -- 10 rows max
,Dates(DT) AS   (--==== Creates up to 10,000 rows and numbers them starting at 0.
                 SELECT TOP (@Years)
                     DT = DATEADD(yy,ROW_NUMBER() OVER (ORDER BY (SELECT NULL))-1,@pStartYear)
                   FROM E1 a, E1 b, E1 c, E1 d
                )
 SELECT easter.*
   FROM Dates d
  CROSS APPLY dbo.EasterRelatedDatesForYear(d.DT) easter
;
-----------------------------------------------------------------------------------------------------------------------
 Revision History:
 Rev 00 - 08 Apr 2017 - Jeff Moden
        - Summarize and convert original concept code contained in the references and further optimize as an iSF.
**********************************************************************************************************************/    
        (
         @SomeDate DATETIME --Can be any legal DATETIME value.  Only the year will be considered.
        )
RETURNS TABLE WITH SCHEMABINDING AS
 RETURN WITH cteEasterSunday AS
(--==== Quickly calculate Easter Day based on the established 19 year cycle using Integer Division/Remainers.
     -- Note that the /7*7 is a high speed method of calculating whole weeks based on days.
 SELECT EasterDate = DATEADD(DAY, DATEDIFF(DAY,0,CONVERT(DATETIME,DATENAME(yy,@SomeDate)+d.BaseDate,112))/7*7,6)
   FROM (--==== Determine which of the 19 years in the cycle the given date is and lookup the month and day of Easter.
         SELECT CASE DATEPART(yy,@SomeDate) % 19
                    WHEN  0 THEN '0415'
                    WHEN  1 THEN '0404'
                    WHEN  2 THEN '0324'
                    WHEN  3 THEN '0412'
                    WHEN  4 THEN '0401'
                    WHEN  5 THEN '0419'
                    WHEN  6 THEN '0409'
                    WHEN  7 THEN '0329'
                    WHEN  8 THEN '0417'
                    WHEN  9 THEN '0406'
                    WHEN 10 THEN '0326'
                    WHEN 11 THEN '0414'
                    WHEN 12 THEN '0403'
                    WHEN 13 THEN '0323'
                    WHEN 14 THEN '0411'
                    WHEN 15 THEN '0331'
                    WHEN 16 THEN '0418'
                    WHEN 17 THEN '0408'
                    WHEN 18 THEN '0328'
                    ELSE NULL --Should never happen but an ELSE for CASE is a good practice.
                END
          WHERE DATEPART(yy,@SomeDate) BETWEEN 1900 AND 9999 --Seems to be an arbitrary start but kept it as the original.
        ) d (BaseDate)
)
 SELECT --===== These days have a fixed offset from Easter Sunday.
         FatTuesday     = DATEADD(dd,-47,EasterDate)
        ,AshWednesday   = DATEADD(dd,-46,EasterDate)
        ,GoodFriday     = DATEADD(dd,-2 ,EasterDate) 
        ,EasterSunday   = EasterDate
   FROM cteEasterSunday
;
GO