CREATE  PROCEDURE p_WhereIsItUsed_2000 

/* This Procedure is used in development work. It is for

SQL Server 2000 only. It is all so much simpler in 2005.

It searches through the code in the database for whatever string

you care to specify and displays the name of each routine

that the string is in, and its context (up to 255 characters

around it) of EVERY occurence so you can see, for example, 

whereabouts an object is being called. It is not really the 

same as having the build script in the Query Analyser. This

procedure makes it a lot quicker to find a problem.



Obviously, the code can be hacked for a particular problem,

as you end up with a table of all the routines in the database

with the routine name and all the text.



*/

@SearchString VARCHAR(40),--the string you want to search for 

@BackSpan INT=21,--when you find a string, 

                       --how many characters back you show

@ForwardSpan INT= 40--when you find a string, 

                       --how many characters forward you show



--e.g:

-- p_WhereIsItUsed_2000  'raiserror'

-- p_WhereIsItUsed_2000  'textptr',100,100

-- p_WhereIsItUsed_2000  'blog[sg]',100,100 --find blogg or blogs

-- p_WhereIsItUsed_2000  'b_gg',100,100     --find begg, bigg, etc

AS

DECLARE @ii INT

DECLARE @iiMax INT

DECLARE @ColID INT

DECLARE @objectID INT

DECLARE @currentProcedure INT

DECLARE @pointerValue varbinary(16)

DECLARE @EndOfText INT

DECLARE @Chunk NVARCHAR(4000)

DECLARE @pos INT

DECLARE @size INT

DECLARE @WhereWeAre INT--index into string so far

DECLARE @context INT



IF @BackSpan + @ForwardSpan > 255


   BEGIN

   RAISERROR (' sorry but your context span is just too great',16,1)

   RETURN 1

   END

SET nocount ON

DECLARE @raw_text TABLE --create a table so we can iterate through it

                        --a row at a time in the correct order

       (

       ourID INT IDENTITY(1,1), --

       colid INT, [id] INT, 

       chunk NVARCHAR(4000)

       )

--now get all the code routines into the table

INSERT INTO @Raw_Text (colid, id, Chunk)

    SELECT colid, id, text

        FROM syscomments s 

       WHERE OBJECTPROPERTY(id, 'IsExecuted') = 1 

               --view, procedure, function, or trigger

               AND encrypted=0

        ORDER BY id, colid 



--now we create the table of all the routines with their

--text source in the correct order.

CREATE TABLE #routine 

       (

       ourID INT IDENTITY(1,1), 

       objectName VARCHAR(80), 

       Definition text

       )



-- start the loop, adding all the nvarchar(4000) chunks 

SELECT @ii=MIN(ourID), @iiMax=MAX(ourID)

       FROM @Raw_Text



WHILE @ii<=@iiMax 

   BEGIN 

   SELECT 

       @colid=colid, 

       @objectID=id, 

       @chunk=chunk 

   FROM @Raw_Text WHERE ourID=@ii--no sir. No cursors

   IF @Colid=1

       BEGIN

         INSERT INTO #Routine (Objectname, Definition) 

           SELECT OBJECT_NAME(@objectID), @chunk
     -- get the pointer for the current procedure name / colid 

           SELECT @currentProcedure=@@Identity 

           SELECT @pointerValue = TEXTPTR(Definition) 

               FROM #Routine 

               WHERE ourid=@currentProcedure

       END

   ELSE

       BEGIN

       -- find out where to append the #temp table's value 

         SELECT @EndOfText = DATALENGTH(Definition) 

            FROM #Routine

            WHERE ourid=@currentProcedure

        

       --Take a deep breath. We are dealing with text here

         UPDATETEXT #Routine.definition
                       @pointerValue @EndOfText 0 @chunk 

       END

       SELECT @ii=@ii+1

   END 


--select objectname,datalength(definition) from #routine



DECLARE @results TABLE (

       ourID INT IDENTITY(1,1), 

       ObjectName VARCHAR(40), 

       offset INT,

       context VARCHAR(255))



SELECT @ii=MIN(ourID), @iiMax=MAX(ourID) FROM #Routine



WHILE @ii<=@iiMax--avoid cursors. Do we look like amateurs?

       BEGIN --for each routine�



       SELECT  @pos=1,

               @size=DATALENGTH(definition),

               @WhereWeAre=1  

       FROM #Routine WHERE ourID=@ii





--find all occurences of the string in the current text


   WHILE @WhereWeAre<@size
      BEGIN

              

      SELECT @pos=PATINDEX('%'+@SearchString+'%',

                       SUBSTRING(definition,@whereWeAre,8000))
           FROM #Routine WHERE ourID=@ii

      IF @pos>0 

          BEGIN

           SELECT @context=CASE
              WHEN @whereWeAre+@pos-@backspan<=1
              THEN 1
              ELSE @whereWeAre+@pos-@backspan END

           INSERT INTO @results (ObjectName, offset, Context)

               SELECT ObjectName, @whereWeAre+@pos,

               SUBSTRING(definition,@context,@BackSpan+@ForwardSpan) 

               FROM #Routine 

               WHERE ourID=@ii

           SELECT @WhereWeAre=@WhereWeAre+@pos

         END

      ELSE SELECT @WhereWeAre=@WhereWeAre+6000

      END

      SELECT @ii=@ii+1

    END

SELECT ObjectName, offset, [context]='�'+context+'�'
 FROM @results
