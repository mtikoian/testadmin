create function dbo.itvf_BRound(
    @val decimal(38,20),
    @pos int
) returns table with schemabinding
as return(
with BaseComp1 as (
select
    cast(floor(abs(@val) * power(cast(10 as float), @pos)) as int) tmpval1,
    cast(round(@val, @pos, 1) as decimal(38,20)) tmpval2,
    cast(sign(@val) * (0.5 * power(cast(10 as float), (-1 * @pos))) as decimal(38,20)) tmpval3
),
BaseComp2 as (
select
    cast((@val - tmpval2) as decimal(38,20)) tmpval4
from
    BaseComp1)
select
    cast(round(@val, @pos, case
                                        when nullif(tmpval1, (tmpval1 / 2) * 2) is null
                                             and ((tmpval3 >= tmpval4 and sign(@val) = 1)
                                             or (tmpval4 >= tmpval3 and sign(@val) = -1))
                                            then 1
                                            else 0 end) as decimal(38,20)) val
from
    BaseComp1 cross join BaseComp2
);