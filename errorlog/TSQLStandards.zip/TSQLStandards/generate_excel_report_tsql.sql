-- Make a new file from the template
DECLARE @Today VARCHAR(10), 
	@OldFile VARCHAR(100), 
	@NewFile VARCHAR(100), 
	@CMD VARCHAR (1000), 
	@return_status int

SET @Today = REPLACE(CONVERT(VARCHAR(10), GETDATE(), 102), '.', '')
SET @OldFile   = '\\ixnuflawLRS1\D$\SLA Reporting\Templates\SLA_DashboardTemplate.xls'
SET @NewFile = '\\ixnuflawLRS1\D$\SLA Reporting\' + 'SLA_Dashboard' + @Today + '.xls'
SET @CMD = 'COPY "' + @OldFile + '" "' + @NewFile + '"' 

IF OBJECT_ID('tempdb..#Output') IS NOT NULL
	DROP TABLE #Output
CREATE TABLE #Output (CopyResult VARCHAR(500))

INSERT INTO #Output EXEC MASTER..XP_CMDSHELL @CMD
IF (SELECT COUNT(*) FROM #Output WHERE CopyResult = '        1 file(s) copied.') = 0
BEGIN
	RAISERROR ('Template file WAS NOT copied.',0,1) WITH NOWAIT
	RETURN 
END


CREATE PROCEDURE [dbo].[CreateExcelLinkedServer] 

@ServerName VARCHAR(30), 
@TabName VARCHAR(30),
@xlsFileName VARCHAR(100)

AS

DECLARE @Retval int, @MsgString VARCHAR(400)

SET NOCOUNT ON


-- If the link already exists, then drop it first...
IF OBJECT_ID('tempdb..#Worksheets') IS NOT NULL
	DROP TABLE #Worksheets1
CREATE TABLE #Worksheets1 (srvname varchar(20), providerstring VARCHAR(50))
INSERT INTO #Worksheets1
	EXEC('SELECT srvname, providerstring FROM master.dbo.sysservers WHERE srvname = ''' + @ServerName + ''' AND providerstring = ''Excel 8.0;''')

IF (SELECT COUNT(srvname) FROM #Worksheets1 WHERE srvname = @ServerName) > 0
	EXEC sp_dropserver @ServerName, 'droplogins'

DROP TABLE #Worksheets1


-- Attempt to create the link...
EXEC sp_addlinkedserver @ServerName, 
	@srvproduct = '', 
	@provider = 'Microsoft.Jet.OLEDB.4.0', 
	@datasrc = @xlsFileName, 
	@provstr = 'Excel 8.0;'  

EXEC sp_addlinkedsrvlogin @ServerName, 'false'


-- Validate the linked server by checking that the tab is available...
IF OBJECT_ID('tempdb..#Worksheets') IS NOT NULL
	DROP TABLE #Worksheets
CREATE TABLE #Worksheets (TABLE_CAT varchar(20), TABLE_SCHEM VARCHAR(20), TABLE_NAME VARCHAR(20), TABLE_TYPE VARCHAR(20), REMARKS VARCHAR(20))
INSERT INTO #Worksheets
	EXEC sp_tables_ex @ServerName

IF (SELECT COUNT(TABLE_NAME) FROM #Worksheets WHERE TABLE_NAME = @TabName) = 0
BEGIN
	SET @MsgString = 'Tab [' + @TabName + '] or Excel file [' + @xlsFileName + '] not found, linked server [' + @ServerName + '] not created.'
	SET @Retval = 1
END
ELSE
BEGIN
	SET @MsgString = 'Linked server [' + @ServerName + '] created, with tab [' + @TabName + '].'
	SET @Retval = 0
END

RAISERROR (@MsgString, 0, 1) WITH NOWAIT

RETURN @Retval
GO
---Here's an example of calling the sp:
EXECUTE @return_status = dbo.CreateExcelLinkedServer 'SLA_Dashboard', 'Results$', @NewFile


UPDATE [SLA_Dashboard]...[Results$] 
	SET D = @month6, E = @month5, F = @month4, G = @month3, H = @month2, I = @month1
	WHERE [A] = '2.7'