CREATE FUNCTION dbo.ConvertFractionToDecimal
/**********************************************************************************************************************
 Purpose:
 Converts a valid string representation of a positive or negative fraction to a DECIMAL(38,19) value.  Returns NULL if
 the string is not a valid representation of a positive or negative fraction.

 Notes:
 1. Leading/trailing spaces are allowed.
 2. Multiple embedded spaces are not allowed. Only one space is allowed

 Revision History:
 Rev 00 - 15 Dec 2008 - Initial creation and test
                  REF - http://www.sqlservercentral.com/Forums/Topic619023-149-1.aspx
**********************************************************************************************************************/
--===== Declare the IO parameters      
        (@Fraction VARCHAR(20))
RETURNS DECIMAL(38,19)
     AS
  BEGIN ---------------------------------------------------------------------------------------------------------------

--===== Declare the return variable
DECLARE @DecimalValue DECIMAL(38,19)

--===== The following "cascading CTE's" solve the problem
;WITH 
cteFindSign AS
(--==== Find the sign and strip it from the fraction removing any leading or trailing spaces
 SELECT CASE 
            WHEN LEFT(LTRIM(RTRIM(@Fraction)),1) = '-'
            THEN -1
            ELSE 1
        END AS MySign,
        CASE
            WHEN LEFT(@Fraction,1) IN ('+','-')
            THEN LTRIM(RTRIM(SUBSTRING(@Fraction,2,20)))
            ELSE LTRIM(RTRIM(@Fraction))
        END AS MixedFraction
)
,
cteAddParts AS
(--==== Add any missing parts to make a Mixed Fraction format (even for improper fractions)
 SELECT MySign,
        CASE 
            WHEN MixedFraction NOT LIKE '%[0-9]/[0-9]%' --Add zero value fraction if missing
            THEN MixedFraction + ' 0/1'
            WHEN MixedFraction NOT LIKE '%[0-9] [0-9]%' --Add zero value whole number if missing
            THEN '0 ' + MixedFraction
            ELSE MixedFraction
        END AS MixedFraction
   FROM cteFindSign
)
,
cteReadyForParse AS
(--==== Do some format checking and get the MixedFraction ready for "dot" parsing
 SELECT MySign,
        MixedFraction = REPLACE(REPLACE(MixedFraction,' ','.'),'/','.') 
   FROM cteAddParts
  WHERE MixedFraction NOT LIKE '%/%/%'
    AND MixedFraction NOT LIKE '% % %'
    AND MixedFraction NOT LIKE '%[^ 0-9/]%'
    AND MixedFraction NOT LIKE '%/0%'
    AND LEN(MixedFraction)-2 = LEN(REPLACE(REPLACE(MixedFraction,' ',''),'/',''))
)
--===== Do the parsing, the conversion, and add the SIGN back in to produce the correct decimal number
 SELECT @DecimalValue =
        (  
        PARSENAME(MixedFraction,3) 
        +(CAST(PARSENAME(MixedFraction,2) AS DECIMAL(38,19))/CAST(PARSENAME(MixedFraction,1) AS DECIMAL(38,19)))
        )
      * MySign
   FROM cteReadyForParse

--===== Produce the return and exit
 RETURN @DecimalValue
    END ---------------------------------------------------------------------------------------------------------------
GO