CREATE FUNCTION dbo.DigitsOnly
        (@SomeString VARCHAR(8000))
RETURNS BIGINT
     AS 
  BEGIN
        DECLARE @CleanString VARCHAR(8000)
            SET @CleanString = ''
         SELECT @CleanString = @CleanString + SUBSTRING(@SomeString,t.N,1)
           FROM dbo.Tally t
          WHERE t.N <= LEN(@SomeString)
            AND SUBSTRING(@SomeString,t.N,1) LIKE '[0-9]'
 RETURN CAST(@CleanString AS BIGINT)
    END