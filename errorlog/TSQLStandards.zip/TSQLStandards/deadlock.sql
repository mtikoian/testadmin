if OBJECT_ID('tempdb..#deadlock') IS NOT NULL DROP TABLE #deadlock
CREATE TABLE #deadlock (TextData varchar(max))
INSERT INTO #deadlock
select * from OpenRowset(BULK N'C:\\Desktop\Deadlock.txt', SINGLE_BLOB) x
--                                 ^ SET TO YOUR PATH HERE
;with CTE as
(
select -- get the raw trace data, add a rowid and convert deadlock graph to xml
    [RowID] = ROW_NUMBER() OVER (ORDER BY (SELECT 0)),  -- assign a row number to each deadlock
    [DeadlockGraph] = convert(xml, TextData), 
    * 
  from #deadlock
)
, CTE2 AS
(
select -- get information about the process
    [DeadlockID]       = CTE.RowID,
    [DeadlockGraph],
    [Procedure]       = Deadlock.Process.value('executionStack[1]/frame[1]/@procname[1]', 'varchar(200)'),
    [Victim]          = case when Deadlock.Process.value('@id', 'varchar(50)') = Deadlock.Process.value('/deadlock-list[1]/deadlock[1]/@victim', 'varchar(50)') then 1 else 0 end,
    [LockMode]        = Deadlock.Process.value('@lockMode', 'char(1)'),
    [Code]            = Deadlock.Process.value('executionStack[1]/frame[1]', 'varchar(1000)'),
    [ClientApp]       = Deadlock.Process.value('@clientapp', 'varchar(100)'),
    [HostName]        = Deadlock.Process.value('@hostname', 'varchar(20)'),
    [LoginName]       = Deadlock.Process.value('@loginname', 'varchar(20)'),
    [TransactionTime] = Deadlock.Process.value('@lasttranstarted', 'datetime'),
    [InputBuffer]     = Deadlock.Process.value('inputbuf[1]', 'varchar(1000)'),
    [ProcessID]       = Deadlock.Process.value('@id', 'varchar(50)'),
    [SPID]            = Deadlock.Process.value('@spid','int'),
    [SBID]            = Deadlock.Process.value('@sbid','int'),
    [ECID]            = Deadlock.Process.value('@ecid','int')
  from CTE
    CROSS APPLY CTE.[DeadlockGraph].nodes('/deadlock-list/deadlock/process-list/process') as Deadlock(Process)
)
, ObjectLock AS
(
select  -- get information about all locks
    [DeadlockID]  = CTE.RowID,
    [ObjectName] = ObjectLock.Process.value('../../@objectname', 'varchar(200)'),
    [ProcessID]  = ObjectLock.Process.value('@id', 'varchar(200)')
  from CTE
    CROSS APPLY CTE.[DeadlockGraph].nodes('/deadlock-list/deadlock/resource-list/*/owner-list/owner') as ObjectLock(Process)
)
, KeyLock AS
(
select  -- get information about key locks (includes indexes)
    [DeadlockID]  = CTE.RowID,
    [ObjectName] = KeyLock.Process.value('../../@objectname', 'varchar(200)') + '.' +
                   KeyLock.Process.value('../../@indexname', 'varchar(200)'),  -- get the index name also
    [ProcessID]  = KeyLock.Process.value('@id', 'varchar(200)')
  from CTE
    CROSS APPLY CTE.[DeadlockGraph].nodes('/deadlock-list/deadlock/resource-list/keylock/owner-list/owner') as KeyLock(Process)
)
select  -- now put this all together
    CTE2.[DeadlockID],
    CTE2.[SPID],
    CTE2.[SBID],
    CTE2.[ECID],
    --[DeadlockTime],
    [DeadlockGraph],
    CTE2.[ProcessID],
    [Victim],
    [LockedObject] = coalesce(KeyLock.ObjectName, ObjectLock.ObjectName),
    [Procedure],
    [LockMode],
    [Code],
    [ClientApp],
    [HostName],
    [LoginName],
    [TransactionTime],
    [InputBuffer]
  from  CTE2
    LEFT OUTER JOIN KeyLock ON KeyLock.ProcessID = CTE2.ProcessID and KeyLock.DeadlockID = CTE2.DeadlockID
    LEFT OUTER JOIN ObjectLock ON ObjectLock.ProcessID = CTE2.ProcessID and ObjectLock.DeadlockID = CTE2.DeadlockID
 ORDER BY CTE2.DeadlockID DESC
 
 
 
 