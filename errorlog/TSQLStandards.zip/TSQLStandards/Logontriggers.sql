CREATE TRIGGER connection_limit_trigger
ON ALL SERVER WITH EXECUTE AS 'sql_login'
FOR LOGON
AS
BEGIN
BEGIN TRY
IF ORIGINAL_LOGIN()= 'sql_login' AND host_name() in (select hostname from admindb..sqllogin_hostname_blacklist)
    ROLLBACK
END TRY
BEGIN CATCH
  PRINT Error_message() -- goes into the SQL error log so that you can see what is causing the rollback
  ROLLBACK TRANSACTION
END CATCH
END 