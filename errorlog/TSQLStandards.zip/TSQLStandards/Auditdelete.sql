--------------------------------------------------------------------------------------------------------------------------
CREATE TRIGGER dbo.TRG_AUDIT_DBO_TBL_TEST_AUDIT
ON dbo.TBL_TEST_AUDIT
/* Generic Audit Trigger
   To implement in different tables, change the identity column
   references marked in the code.

   If either of the two actions does not require auditing
   then remove it from here. 
*/
FOR 
   UPDATE, DELETE
AS
BEGIN
    WITH IDENTITY_VALUES(ID_VAL, ACTION_TYPE) AS
    (
        SELECT
            DLTBL.ID_VAL
           ,X.ACTION_TYPE
        FROM
			(
				SELECT 
					D.TEST_AUDIT_ID AS ID_VAL
				FROM	deleted	D
			) AS DLTBL
			CROSS APPLY
            (
				SELECT
					CASE WHEN EXISTS (SELECT * FROM inserted) THEN 3
					ELSE 2
				END AS ACTION_TYPE
			) X(ACTION_TYPE)                
    )
    INSERT INTO dbo.TBL_GENERIC_AUDIT (AUDIT_COL_IDENTITY,AUDIT_OBJECT,AUDIT_ACTION_TYPE,AUDIT_XML)
SELECT
     X.ID_VAL
    ,N'dbo.TBL_TEST_AUDIT' AS AUDIT_OBJECT
    ,X.ACTION_TYPE
    ,(
        SELECT
            X.ACTION_TYPE    AS '@Type'
          ,(
                SELECT
                    *
                FROM deleted C
                WHERE A.ID_VAL = C.TEST_AUDIT_ID
                FOR XML PATH('DELETED'), TYPE,ELEMENTS  XSINIL
           )
        FROM IDENTITY_VALUES A
        WHERE X.ID_VAL = A.ID_VAL
        FOR XML PATH('ACTION'),TYPE,ELEMENTS  XSINIL
        )
FROM IDENTITY_VALUES X;
END
-------------------------------------------------------------