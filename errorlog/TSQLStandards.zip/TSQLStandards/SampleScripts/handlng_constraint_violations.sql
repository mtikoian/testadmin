/********************************************************************************
 $Author:$
 $Rev:$

 Description: Illustrates how to dynamically handle constraint violations in DML code

 ********************************************************************************/

use tempdb
go

create table parent (colA char(1) primary key);
create table child (colA char(1) foreign key references parent(colA), colB char(1));
go

insert parent values ('A');
insert child values ('A','A');
insert child values ('A','B');
go


-- example of deleting parent rows
declare @error_number int;
declare @error_message nvarchar(2048);
declare @startpos int;
declare @endpos int;

begin try

  delete from parent where colA = 'A';

end try
begin catch

  set @error_number = error_number();
  set @error_message = error_message();
  if @error_number = 547 begin
    set @startpos = charindex('table "',@error_message) + 7;
    set @endpos = charindex('", column',@error_message);
    select 'Cannot delete row due to child rows existing in table ' + substring(@error_message,@startpos,@endpos-@startpos) + '.';
  end
  else begin
    set @error_message = error_message();
    raiserror(@error_message,16,1);
  end

end catch
go

-- example of inserting child rows
declare @error_number int;
declare @error_message nvarchar(2048);
declare @startpos int;
declare @endpos int;

begin try

  insert child values ('B','A');

end try
begin catch

  set @error_number = error_number();
  set @error_message = error_message();
  if @error_number = 547 begin
    set @startpos = charindex('table "',@error_message) + 7;
    set @endpos = charindex('", column',@error_message);
    select 'Cannot insert row due to parent row not existing in table ' + substring(@error_message,@startpos,@endpos-@startpos) + '.';
  end
  else begin
    set @error_message = error_message();
    raiserror(@error_message,16,1);
  end

end catch

drop table child;
drop table parent;