#Best Practices For Error Handling In T-SQL Code#

##Introduction##

This document describes some general best practices for handling errors in Transact SQL code. It also documents several known scenarios around how errors are handled and communicated between various levels of the database and application layers.

Error handling is a complex subject, and it is difficult to recommend a single approach that will work well in all cases. Therefore, rather than lay out a particular standard, this document simply explains the related behaviors and approaches that are possible, along with suggestions for some reference implementations.

**The single most important principle to follow when implementing an error handling strategy is consistency**. Document a strategy early on in the process, and use it across all code within your system. Maintaining a codebase with differing methods of handling and communicating errors is extremely expensive and prone to mistakes.

###A Note About Scripts Within This Document###
This document contains links to several scripts for the purposes of illustrating behavior. These were tested on SQL Server 2012 but should work on other versions. To execute them you must have, at a minimum, a database with db_owner rights. It is recommended they be used in a clean sandbox environment so that there is no possibility of affecting existing code. Under no circumstances should they be run in a non-test system.

##Understanding How Errors Behave In Transact-SQL##
The behavior of errors within Transact-SQL code is complex and depends upon many factors. It is impossible to cover every possible scenario, but we attempt to document several common ones here for reference. When in doubt, experiment!

###Pre-SQL 2005 and Outside TRY/CATCH###
In SQL 2005, the concept of a TRY and CATCH blocks within T-SQL was introduced. Prior to this, the most common method of detecting and handling errors was through the global @@ERROR variable and utilizing the GOTO construct to invoke an error handler.

	SELECT ...
	  FROM ...
	 WHERE ...;
	
	SET @Err_Num = @@ERROR;
	IF @Err_Num <> 0 GOTO ErrHandler;

The checking of the @@ERROR variable was necessary after every statement that was executed. The reason is that without this check, code would continue executing even if an error occurred (with the exception of a Severity 17 or higher error, which halts the execution of the batch).

This behavior remains in versions of SQL Server 2005 and higher when code is executed outside of a TRY block. To illustrate this, use this code block. Note that we simulate an error occurring using the `RAISERROR` command.

	PRINT 'Before error...';
	RAISERROR('This is an error!',16,1);
	PRINT 'After the error...';

As you will see, both `PRINT` statements execute.

This method of handling errors, while still applicable, is not permitted in code running on SQL Server 2005 and higher. It is cumbersome and comes with certain caveats that make it quite easy to introduce the possibility that errors will not be caught. For example, the `@@ERROR` variable only returns the error number for the very last statement executed. Thus, if it is not immediately checked, this could lead to the code acting as if an error did not occur even when one does. For example...

	DECLARE @Err_Num INT;
	RAISERROR('I am an error!',16,1);
	
	PRINT 'I''m doing something else...';
	SET @Err_Num = @@ERROR;
	PRINT 'Error number is: ' + CAST(@Err_Num as varchar);

For these reasons, we require that TRY/CATCH style error handling be used in all code deployed in SQL Server versions 2005 and forward.

###Within a TRY/CATCH Block###

When an error occurs within the context of a TRY block, control of the execution is immediately transferred to the neighboring CATCH block. No further code in the TRY block is executed. To illustrate this, we use the following code.

	BEGIN TRY
		RAISERROR('An error!',16,1);
		PRINT 'I will never execute...';
	END TRY
	BEGIN CATCH
		PRINT 'I will execute...';
	END CATCH

In the case of nested calls (i.e. one stored procedure calling another), the behavior is similar, but can differ depending upon several variables.

If code in both stored procedures is executed in TRY blocks within their own boundaries, and an error occurs in the nested code, control will be transferred to the nested CATCH block.

	IF EXISTS (SELECT   1
	             FROM   INFORMATION_SCHEMA.ROUTINES
	            WHERE   ROUTINE_SCHEMA = 'dbo'
	                    AND ROUTINE_NAME = 'ChildProcedure')
	  DROP PROCEDURE dbo.ChildProcedure;
	GO
	CREATE PROCEDURE dbo.ChildProcedure
	AS
	BEGIN TRY
	  PRINT 'In the child...';
	  RAISERROR('An error!',16,1);
	  PRINT 'I will never execute...';
	END TRY
	BEGIN CATCH
	  PRINT 'Catch in child!';
	END CATCH
	PRINT 'After the Catch in child...';
	GO
	
	IF EXISTS (SELECT   1
	             FROM   INFORMATION_SCHEMA.ROUTINES
	            WHERE   ROUTINE_SCHEMA = 'dbo'
	                    AND ROUTINE_NAME = 'ParentProcedure')
	  DROP PROCEDURE dbo.ParentProcedure;
	GO
	CREATE PROCEDURE dbo.ParentProcedure
	AS
	BEGIN TRY
	  PRINT 'In the parent...';
	  EXEC dbo.ChildProcedure;
	  PRINT 'Still in the parent...';
	END TRY
	BEGIN CATCH
	  PRINT 'Catch in parent!';
	END CATCH
	GO

	EXEC dbo.ParentProcedure;
	
	DROP PROCEDURE dbo.ChildProcedure;
	DROP PROCEDURE dbo.ParentProcedure;

It is notable here that the parent procedure is not automatically notified of the error occurring. When writing code that is expected to be called in a nested fashion, you must designate an explicit notification protocol for communicating to the caller that an error has occurred. We examine several approaches of doing this in the next section.

It is also worth noting that code after the CATCH block also executes. Unless control is explicitly returned to the parent (via something like a `RETURN` statement), the child code continues to execute.

If code in a nested procedure is executed outside of (a nested) TRY block, and an error occurs, control is immediately transferred to the caller's CATCH block.

	IF EXISTS (SELECT   1
	             FROM   INFORMATION_SCHEMA.ROUTINES
	            WHERE   ROUTINE_SCHEMA = 'dbo'
	                    AND ROUTINE_NAME = 'ChildProcedure')
	  DROP PROCEDURE dbo.ChildProcedure;
	GO
	CREATE PROCEDURE dbo.ChildProcedure
	AS
	PRINT 'In the child...';
	RAISERROR('An error!',16,1);
	PRINT 'I will never execute...';
	GO
	
	IF EXISTS (SELECT   1
	             FROM   INFORMATION_SCHEMA.ROUTINES
	            WHERE   ROUTINE_SCHEMA = 'dbo'
	                    AND ROUTINE_NAME = 'ParentProcedure')
	  DROP PROCEDURE dbo.ParentProcedure;
	GO
	CREATE PROCEDURE dbo.ParentProcedure
	AS
	BEGIN TRY
	  PRINT 'In the parent...';
	  EXEC dbo.ChildProcedure;
	  PRINT 'I will never execute...';
	END TRY
	BEGIN CATCH
	  PRINT 'Catch in parent!';
	END CATCH

	PRINT 'After the catch in the parent...';
	GO
	
	EXEC dbo.ParentProcedure;
	
	DROP PROCEDURE dbo.ChildProcedure;
	DROP PROCEDURE dbo.ParentProcedure;

 

This concludes the section on understanding the behavior of errors within Transact-SQL code. As stated earlier, there are a large number of possible scenarios around the occurrence of an error, and it is not practical to document them all. Always verify behavior with mocked up code before proceeding if you are not absolutely certain of how it will behave.

##Communicating Errors in Transact-SQL##

When we speak of "communicating errors", we mean the act of notifying a caller of code (whether it be another piece of T-SQL code or an external application) that an error has occurred. As demonstrated earlier this is not an automatic result of an error occurring, and must be explicitly designed into the code.

###Use of RAISERROR###
One method of communicating to a caller that an error has occurred is the use of the RAISERROR statement within the nested CATCH block. This effectively 're-throws' the error up the call stack.

	IF EXISTS (SELECT   1
	             FROM   INFORMATION_SCHEMA.ROUTINES
	            WHERE   ROUTINE_SCHEMA = 'dbo'
	                    AND ROUTINE_NAME = 'ChildProcedure')
	  DROP PROCEDURE dbo.ChildProcedure;
	GO
	CREATE PROCEDURE dbo.ChildProcedure
	AS
	BEGIN TRY
	  PRINT 'In the child...';
	  RAISERROR('An error!',16,1);
	  PRINT 'I will never execute...';
	END TRY
	BEGIN CATCH
	  PRINT 'Catch in child!';
    
      DECLARE @Error_Message NVARCHAR(2048);
      SET @Error_Message = ERROR_MESSAGE();

      RAISERROR(@Error_Message,16,1);

      PRINT 'I will never execute!';
	END CATCH
	PRINT 'After the Catch in child...';
	GO
	
	IF EXISTS (SELECT   1
	             FROM   INFORMATION_SCHEMA.ROUTINES
	            WHERE   ROUTINE_SCHEMA = 'dbo'
	                    AND ROUTINE_NAME = 'ParentProcedure')
	  DROP PROCEDURE dbo.ParentProcedure;
	GO
	CREATE PROCEDURE dbo.ParentProcedure
	AS
	BEGIN TRY
	  PRINT 'In the parent...';
	  EXEC dbo.ChildProcedure;
	  PRINT 'Still in the parent...';
	END TRY
	BEGIN CATCH
	  PRINT 'Catch in parent!';
	END CATCH
	GO

	EXEC dbo.ParentProcedure;
	
	DROP PROCEDURE dbo.ChildProcedure;
	DROP PROCEDURE dbo.ParentProcedure;

While this seems simple, it has several disadvantages. First, it can be very difficult to determine at what level the error has occurred, depending upon the nest level of the code. Second, you must be very careful to include any nested error handling code **before** the `RAISERROR` statement. This is because raising an error in the nested CATCH block is handled the same as a nested error outside of a TRY block; that is, control is immediately transferred to the calling CATCH block (note how the `PRINT` statement after the `RAISERROR` in the child's CATCH block never runs).

It is important to note that this is not the case when the "caller" is an external application. In this case, any code in the stored procedure after the `RAISERROR` statement will execute. However, the calling application's CATCH block (assuming there is one) will be invoked. In this way, this method acts much like an error occurring within the application itself.

###Using Return Codes###
In Transact-SQL stored procedures, it is possible to return a numeric value to a caller using the `RETURN <a numeric literal or variable>` statement. This is a useful way to notify a caller that an error has occurred.

	IF EXISTS (SELECT   1
	             FROM   INFORMATION_SCHEMA.ROUTINES
	            WHERE   ROUTINE_SCHEMA = 'dbo'
	                    AND ROUTINE_NAME = 'ChildProcedure')
	  DROP PROCEDURE dbo.ChildProcedure;
	GO
	CREATE PROCEDURE dbo.ChildProcedure
	AS
    DECLARE @Return_Value INT;

    -- Initialize the return code to zero (meaning no error occurred)
    SET @Return_Value = 0;

	BEGIN TRY
	  PRINT 'In the child...';
	  RAISERROR('An error!',16,1);
	  PRINT 'I will never execute...';
	END TRY
	BEGIN CATCH
	  PRINT 'Catch in child!';
    
      DECLARE @Error_Message NVARCHAR(2048);
      SET @Error_Message = ERROR_MESSAGE();

      -- Set the return code to a non zero value, meaning an error has occurred
      SET @Return_Value = ERROR_NUMBER();

      -- Do something here to log the actual error message for later retrieval

	END CATCH
	PRINT 'After the Catch in child...';
	RETURN @Return_Value
	GO
	
	IF EXISTS (SELECT   1
	             FROM   INFORMATION_SCHEMA.ROUTINES
	            WHERE   ROUTINE_SCHEMA = 'dbo'
	                    AND ROUTINE_NAME = 'ParentProcedure')
	  DROP PROCEDURE dbo.ParentProcedure;
	GO
	CREATE PROCEDURE dbo.ParentProcedure
	AS
	DECLARE @Return_Value INT;

	BEGIN TRY
	  PRINT 'In the parent...';
	  EXEC @Return_Value = dbo.ChildProcedure;
      -- Check the value of the return code  
      IF @Return_Value <> 0
        RAISERROR('Error occurred in child.',16,1);
      PRINT 'This will not execute...';
	END TRY
	BEGIN CATCH
	  PRINT 'Catch in parent!';
	END CATCH
	GO

	EXEC dbo.ParentProcedure;
	
	DROP PROCEDURE dbo.ChildProcedure;
	DROP PROCEDURE dbo.ParentProcedure;

This allows the error to be handled and logged at the lowest level of execution, and eliminates hard to interpret nested error stacks. For this reason, this is the preferred method for communicating errors within T-SQL code.

We also recommend this approach for communicating errors to calling external applications. Both .NET and JAVA code are capable of checking return codes from executed stored procedures. For example, .NET code can access the return code of a stored procedure by declaring a `SQLParameter` object with the `Direction` property set to `ParameterDirection.ReturnValue`. For more information see [this MSDN page](http://msdn.microsoft.com/en-us/library/system.data.parameterdirection(v=vs.110).aspx). 

It is important to note that you must somehow persist relevant details of the error at the level where it originally occurred, such as the message text, the name of the procedure where it occurred, etc. While it is technically possible to pass this information up the call stack using something like output parameters, we feel it is best to log at the lowest level, then simply notify callers that an error occurred. It is acceptable to pass up an identifier that can be referenced to locate the details of the error, such as a unique identity value for a row in a log table. This is best done using output parameters. For an example of a robust and configurable framework for logging errors and other information during T-SQL execution,

##Conclusion##
There are few things more important in database code than how errors are handled and communicated. It is crucial that a robust and consistent strategy be implemented and enforced throughout an application's code. For this reason we encourage everyone to utilize the strategies noted in this document, and to experiment and learn on their own. We stand ready to assist anyone if questions arise.