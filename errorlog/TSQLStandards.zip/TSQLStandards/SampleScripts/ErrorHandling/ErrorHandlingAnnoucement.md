We would like to reiterate two current standards around mandatory error handling in SQL code.

**First, the use of error handling is mandatory in all SQL code.** This means that in SQL Server 2005 and higher, you must use TRY/CATCH style error handling. Older style error handling using the @@ERROR global variable is not permitted.

**Second, when calling stored procedures in nested fashion (i.e. calling one procedure from within another), you must check for a non-zero return code and invoke error handling if you find one.** Here is an example of how to properly do this.

    DECLARE @RC int;
    SET @RC = 0;

    EXEC @RC = dbo.ChildProc;

    IF @RC <> 0 BEGIN
        -- Invoke error handling here
    END

We require this as stored procedures have two main mechanisms for notifying callers of errors: 1) re-throwing the error up the call stack via something like `RAISERROR`, 2) returning a non zero return code. Calling the child procedure within a TRY block and checking the return code ensures that both these scenarios are covered. Of course, you should examine and understand the behavior of each stored procedure as they can vary significantly.

While there is no universal standard for how to implement error handling, we strongly recommend the following:

1. Always handle the error at the lowest level possible. That is, if an error occurs within one procedure, it should be handled within the same one. As you pass further up the call stack you quickly lose context, making it harder to handle the error in a specific manner.
2. Always persist the details of the error, such as the message and the context (i.e. who was running what and when was it running), within a table for later retrieval. An identity value that uniquely links to the row where the details are stored should be passed up the call stack via something like an output parameter. We have a [very robust and flexible logging framework for T-SQL](Logging) which was developed by the SME group and is freely available.
3. Make use of return codes to notify callers that an error has occurred, rather than re-raising (i.e. using `RAISERROR`) the error up the call stack. The latter method often results in a very cluttered error message and can have inadvertent consequences if handler code is not written in a very specific way.

Here is an example of a simple procedure which makes use of return codes as described above.

	IF EXISTS (SELECT   1
	             FROM   INFORMATION_SCHEMA.ROUTINES
	            WHERE   ROUTINE_SCHEMA = 'dbo'
	                    AND ROUTINE_NAME = 'ChildProcedure')
	  DROP PROCEDURE dbo.ChildProcedure;
	GO
	CREATE PROCEDURE dbo.ChildProcedure
    @Error_Log_Id INT OUTPUT
	AS
    DECLARE @Return_Value INT;

    -- Initialize the return code to zero (meaning no error occurred)
    SET @Return_Value = 0;

	BEGIN TRY
	  PRINT 'In the child...';
	  RAISERROR('An error!',16,1);
	END TRY
	BEGIN CATCH

    DECLARE @Error_Message NVARCHAR(2048);
    SET @Error_Message = ERROR_MESSAGE();

    -- Set the return code to a non zero value, meaning an error has occurred
    SET @Return_Value = ERROR_NUMBER();

    -- Log the error here and get the identity value for the log table
    EXEC dbo.LogError @Error_Log_Id OUTPUT;

	END CATCH
    RETURN @Return_Value
	GO

For a more comprehensive discussion of the behavior of errors in T-SQL, please see [insert link here to larger document].