/***
================================================================================
Name        : finding_missing_fk_values_with_metadata
Author      : Josh Feierman
Description : Illustrates how to programmatically locate and remediate missing foreign 
              key values by defining non-trusted keys and utilizing metadata to construct statements.

Revision: $Rev: 557 $
URL: $URL: 
Last Checked in: $Author: jfeierman $

Revisions    :
--------------------------------------------------------------------------------
Ini|   Date   | Description
--------------------------------------------------------------------------------

================================================================================
***/

use master;
if exists (select 1 from sys.databases where name = 'FK_With_Metadata') begin
  alter database FK_With_Metadata set single_user with rollback immediate;
  drop database FK_With_Metadata;
end

create database FK_With_Metadata;
go

use FK_With_Metadata;
go

create table parent 
(
  parent_id int primary key
);

with numbers as
(
  select  ROW_NUMBER( ) OVER( order by ac1.column_id ) as row_num
  from    sys.all_columns ac1 cross join sys.all_columns ac2
) 
insert into parent
(
  parent_id
)
values
(
  1
);

create table child 
(
  child_id int identity(1,1) primary key,
  parent_id int
);


insert into child
(
  parent_id
)
select 1
union
select 2;  

-- attempt to create a FK, we get an error
alter table child add constraint fk_child_parent foreign key (parent_id) references parent(parent_id);

-- do it again but with NOCHECK
alter table child with nocheck add constraint fk_child_parent foreign key (parent_id) references parent(parent_id);

-- try and check the constraint, this will fail
-- we would want to run this after the data is cleaned up
alter table child with check check constraint fk_child_parent;

-- example SQL to generate missing data
-- this assumes that all other columns are either optional or have defaults
with fk_cols as 
(
  select row_number() over(order by fkc.constraint_object_id) as row_num,
         pc.name as parent_name,
         cc.name as child_name,
         fkc.constraint_object_id
    from sys.foreign_key_columns fkc join sys.columns pc
           on fkc.parent_column_id = pc.column_id
              and fkc.parent_object_id = pc.object_id
         join sys.columns cc
           on fkc.parent_column_id = cc.column_id
              and fkc.parent_object_id = cc.object_id
)
select fk.name,
       po.name as parent_object_name,
       o.name as child_object_name,
       'insert into ' + po.name + char(10) +
       '(' + char(10) +
       (select case row_num when 1 then '' else ',' end + parent_name
                      from fk_cols
                     where constraint_object_id = fk.object_id
                    for xml path('')) + char(10) +
       ')' + char(10) +
       'select ' + (select case row_num when 1 then '' else ',' end + 'c.' + child_name
                      from fk_cols
                     where constraint_object_id = fk.object_id
                    for xml path('')) + char(10) +
       '  from ' + o.name + ' c left join ' + po.name + ' p ' + char(10) +
       '         on ' + (select case row_num when 1 then '' else ' and ' end + 'c.' + child_name + ' = p.' + parent_name + char(10)
                           from fk_cols
                          where constraint_object_id = fk.object_id
                         for xml path('')) +
       ' where p.' + (select child_name + ''
                        from fk_cols
                       where constraint_object_id = fk.object_id
                             and row_num = 1
                      for xml path('')) + ' is null' as sql_txt
  from sys.foreign_keys fk join sys.objects po
         on fk.referenced_object_id = po.object_id
       join sys.objects o
         on fk.parent_object_id = o.object_id;

-- example SQL to delete invalid child rows
with fk_cols as 
(
  select row_number() over(order by fkc.constraint_object_id) as row_num,
         pc.name as parent_name,
         cc.name as child_name,
         fkc.constraint_object_id
    from sys.foreign_key_columns fkc join sys.columns pc
           on fkc.parent_column_id = pc.column_id
              and fkc.parent_object_id = pc.object_id
         join sys.columns cc
           on fkc.parent_column_id = cc.column_id
              and fkc.parent_object_id = cc.object_id
)
select fk.name,
       po.name as parent_object_name,
       o.name as child_object_name,
       'delete c ' + char(10) +
       '  from ' + o.name + ' c left join ' + po.name + ' p ' + char(10) +
       '         on ' + (select case row_num when 1 then '' else ' and ' end + 'c.' + child_name + ' = p.' + parent_name + char(10)
                           from fk_cols
                          where constraint_object_id = fk.object_id
                         for xml path('')) +
       ' where p.' + (select child_name + ''
                        from fk_cols
                       where constraint_object_id = fk.object_id
                             and row_num = 1
                      for xml path('')) + ' is null' as sql_txt
  from sys.foreign_keys fk join sys.objects po
         on fk.referenced_object_id = po.object_id
       join sys.objects o
         on fk.parent_object_id = o.object_id;