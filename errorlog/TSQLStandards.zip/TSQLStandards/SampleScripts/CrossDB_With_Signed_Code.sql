/***
================================================================================
Name        : CrossDB_With_Signed_Code.sql
Author      : Josh Feierman
Description : 

Revision: $Rev: 393 $
URL: $URL: http://seisubvapp01/TSU_Utilities/SampleScripts/CrossDB_With_Signed_Code.sql $
Last Checked in: $Author: jfeierman $
===============================================================================
Scenario: We have a procedure that does some work in database B (we'll call it Procedure B). We would like to allow
 a user who only has access to database A the ability to execute Procedure B, via executing a procedure in database A 
 (we'll call it Procedure A).


================================================================================
***/

/****************************************
 Create test databases
 ****************************************/
use master;

if exists (select 1 from sys.databases where name = 'CertTestDB_A') begin
  alter database CertTestDB_A set single_user with rollback immediate;
  drop database CertTestDB_A;
end

create database CertTestDB_A;

if exists (select 1 from sys.databases where name = 'CertTestDB_B') begin
  alter database CertTestDB_B set single_user with rollback immediate;
  drop database CertTestDB_B;
end

create database CertTestDB_B;
go

/****************************************
 setup procedure in database B
 ****************************************/
use CertTestDB_B;
go

if exists (select 1 from INFORMATION_SCHEMA.TABLES where TABLE_NAME = 'cert_test')
  drop table dbo.cert_test;
create table dbo.cert_test
(
  val char(1)
);

if exists (select 1 from INFORMATION_SCHEMA.ROUTINES where ROUTINE_NAME = 'cert_test_proc') begin
  drop procedure dbo.cert_test_proc;
end
go

create procedure dbo.cert_test_proc
  @val char(1)
as
begin try
  select 'database b - proc b', * from sys.user_token;
  insert dbo.cert_test (val) values (@val);
end try
begin catch
  declare @err_message nvarchar(2048);
  set @err_message = error_message();

  raiserror('Database B: %s',16,1,@err_message);
end catch

go

/****************************************
 Setup procedure in database A
 ****************************************/

USE CertTestDB_A;

if exists (select 1 from INFORMATION_SCHEMA.ROUTINES where ROUTINE_NAME = 'cert_test_proc') begin
  drop procedure dbo.cert_test_proc;
end
go

create procedure dbo.cert_test_proc
as
begin try
  select 'database a - proc a',* from sys.user_token;
  select 'database b - proc a',* from CertTestDB_B.sys.user_token;
  exec CertTestDB_B.dbo.cert_test_proc @val = 'A';
end try
begin catch
  declare @err_message nvarchar(2048);
  set @err_message = error_message();

  raiserror('Database A: %s',16,1,@err_message);
end catch
go


/*****************************************
 Begin certificate setup
 *****************************************/

-- create database master key
if not exists (select 1 from sys.symmetric_keys where name = '##MS_DatabaseMasterKey##')
  create master key encryption by password = '1qaz@wsx';
  
-- create certificate encrypted by database master key
if exists (select 1 from sys.certificates where name = 'cert_test_deploy')
  drop certificate [cert_test_deploy];

create certificate [cert_test_deploy] with subject = 'Test certificate';

-- add signature to stored procedure
add signature to dbo.cert_test_proc by certificate [cert_test_deploy];
  
backup certificate [cert_test_deploy] to file = 'g:\sql\cert.cert'
  with private key
  (
    file='g:\sql\cert.pk',
    encryption by password='1qaz@wsx'
  );

use master;
-- create a login for use of testing the certificate permissions
-- this user will execute the procedure
create login [test_proc_exec] with password='1qaz@wsx';

use CertTestDB_B;

if not exists (select 1 from sys.symmetric_keys where name = '##MS_DatabaseMasterKey##')
  create master key encryption by password = '1qaz@wsx';

create certificate [cert_test_deploy] from file = 'g:\sql\cert.cert'
  with private key
  (
    file = 'g:\sql\cert.pk',
    decryption by password = '1qaz@wsx'
  );

-- counter sign the procedure in database 'B'
-- this is required if you are executing another module (i.e. calling another procedure)
add counter signature to dbo.cert_test_proc by certificate cert_test_deploy;

create user cert_test_deploy_proxy from certificate cert_test_deploy;

-- give the certificate user access to the procedure
grant execute on dbo.cert_test_proc to cert_test_deploy_proxy;


use CertTestDB_A;

if not exists (select 1 from sys.database_principals where name = 'test_proc_exec')
  create user test_proc_exec for login [test_proc_exec];

grant execute on dbo.cert_test_proc to test_proc_exec;
    
execute as login='test_proc_exec';
exec dbo.cert_test_proc;
revert;

-- Cleanup
revert;
use master;
if exists(select 1 from sys.server_principals where name = 'test_proc_exec')
  drop login test_proc_exec;
if exists (select 1 from sys.databases where name = 'CertTestDB_A') begin
  alter database CertTestDB_A set single_user with rollback immediate;
  drop database CertTestDB_A;
end
if exists (select 1 from sys.databases where name = 'CertTestDB_B') begin
  alter database CertTestDB_B set single_user with rollback immediate;
  drop database CertTestDB_B;
end

declare @fileexist table (file_exists bit,file_is_directory bit,parent_directory_exists bit);
declare @current_time datetime; set @current_time = current_timestamp;
insert @fileexist
exec master..xp_fileexist 'g:\sql\cert.cert';
if exists(select 1 from @fileexist where file_exists = 1)
  exec master..xp_cmdshell 'del g:\sql\cert.cert';
delete from @fileexist;
insert @fileexist
exec master..xp_fileexist 'g:\sql\cert.pk';
if exists(select 1 from @fileexist where file_exists = 1)
  exec master..xp_cmdshell 'del g:\sql\cert.pk';

