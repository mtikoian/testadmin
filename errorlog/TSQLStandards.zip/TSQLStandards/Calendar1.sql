--===== Do this in a nice, safe place that everyone has 
     -- because we're going to donditionally drop everything
     -- before we make it and most of it ISN'T temporary stuff.
    USE tempdb
;
GO
--===== Conditionally drop the Calendar table to make reruns in SSMS easier.
     IF OBJECT_ID('dbo.Calendar') IS NOT 
        NULL DROP TABLE dbo.Calendar;
;
go
WITH
cteGenDates AS
(
--===== Calculates all dates from 2000-01-01 up to and not including 2100-01-01
 SELECT TOP (DATEDIFF(dd,'2000','2100'))
        DT = DATEADD(dd,ROW_NUMBER() OVER (ORDER BY (SELECT NULL))-1,'2000')
   FROM      sys.all_columns ac1
  CROSS JOIN sys.all_columns ac2
),
cteGenDateParts AS
(
--===== Calculates the rest of the basic columns that we can calculate so far
     -- as well as passing the calculated date along.
 SELECT DT,
        YY  = DATEPART(yy,DT),
        MM  = DATEPART(mm,DT),
        DD  = DATEPART(dd,DT),
        DW  = DATEDIFF(dd,0,DT)%7+1
   FROM cteGenDates
),
cteGenDWMonth AS
(
--===== Calculates a special column that will make finding things like 
     -- the 3rd Wednesday of a month a whole lot easier as well as
     -- passing the other columns we've calculated along.
 SELECT DT, YY, MM, DD, DW,
        DWMonth = ROW_NUMBER() OVER (PARTITION BY YY,MM,DW ORDER BY DT)
   FROM cteGenDateParts
),
cteGenHolidays AS
(
--===== Calculate all holidays that don't depend on other dates.
     -- Some of the holidays are "fixed" dates like New Year's day.
     -- Others, like George Washington's Birthday and Thanksgiving occur
     -- on the Nth occurrence of a given weekday within a given month (DWMonth).
     -- Calculate the weekends, as well.
 SELECT DT, YY, MM, DD, DW, DWMonth,
        IsWeekEnd = CASE WHEN DW >= 6 THEN 1 ELSE 0 END, --"6" is Saturday, "7" is Sunday
        HolidayID =
            CASE 
            WHEN MM =  1 AND DD =  1                 THEN  1 --New Year's Day
            WHEN MM =  1 AND DW =  1 AND DWMonth = 3 THEN  2 --Martin Luther King, Jr. Birthday
            WHEN MM =  2 AND DW =  1 AND DWMonth = 2 THEN  3 --George Washington's Birthday
            WHEN MM =  5 AND DW =  1 AND DATEPART(mm,DATEADD(dd,7,DT)) = 6 THEN 4 --Memorial Day
            WHEN MM =  7 AND DD =  4                 THEN  5 --Independence Day
            WHEN MM =  9 AND DW =  1 AND DWMonth = 1 THEN  6 --Labor Day
            WHEN MM = 10 AND DW =  1 AND DWMonth = 2 THEN  7 --Columbus Day
            WHEN MM = 11 AND DD = 11                 THEN  8 --Veterans Day
            WHEN MM = 11 AND DW =  1 AND DWMonth = 4 THEN  9 --ThanksGivingDay
            WHEN MM = 12 AND DD = 25                 THEN 10 --Christmas Day
            WHEN DT = DATEADD(dd,DATEDIFF(dd,0,CAST(DATENAME(yy,DT)
                    + CASE YY % 19
                      WHEN  0 THEN '0415'
                      WHEN  1 THEN '0404'
                      WHEN  2 THEN '0324'
                      WHEN  3 THEN '0412'
                      WHEN  4 THEN '0401'
                      WHEN  5 THEN '0419'
                      WHEN  6 THEN '0409'
                      WHEN  7 THEN '0329'
                      WHEN  8 THEN '0417'
                      WHEN  9 THEN '0406'
                      WHEN 10 THEN '0326'
                      WHEN 11 THEN '0414'
                      WHEN 12 THEN '0403'
                      WHEN 13 THEN '0323'
                      WHEN 14 THEN '0411'
                      WHEN 15 THEN '0331'
                      WHEN 16 THEN '0418'
                      WHEN 17 THEN '0408'
                      WHEN 18 THEN '0328'
                      ELSE NULL
                      END
                   AS DATETIME))/7*7,6)
            THEN 11 --Easter Sunday
            ELSE 0
            END
   FROM cteGenDWMonth
),
cteGenFMHolidays AS
( --=== Calculate Monday/Friday holidays where the holiday fell on a weekend
 SELECT DT, YY, MM, DD, DW, DWMonth, IsWeekEnd,
        HolidayID = CASE
                    WHEN MM = 12 AND DD = 31 AND DW = 5 THEN 12 --Day before NewYears is Friday
                    WHEN MM =  1 AND DD =  2 AND DW = 1 THEN 12 --Day after NewYears is a Monday
                    WHEN MM =  7 AND DD =  3 AND DW = 5 THEN 13 --Day before Independence Day is Friday
                    WHEN MM =  7 AND DD =  5 AND DW = 1 THEN 13 --Day after Independence is a Monday
                    WHEN MM = 11 AND DD = 10 AND DW = 5 THEN 14 --Day before Veterans Day is a Friday
                    WHEN MM = 11 AND DD = 12 AND DW = 1 THEN 14 --Day after Veterans Day is a Monday 
                    WHEN MM = 12 AND DD = 24 AND DW = 5 THEN 15 --Day before Christmas is Friday
                    WHEN MM = 12 AND DD = 26 AND DW = 1 THEN 15 --Day after Christmas is a Monday
                    ELSE HolidayID
                    END
   FROM cteGenHolidays
)
--===== Make all of the columns NOT NULL and cast each of them
     -- to the smallest datatype possible without adding possible
     -- implicit conversions to the mix. 
     -- We also add in two columns that we're not yet ready to fill in.
 SELECT DT          = ISNULL(DT,0), --Already a DATETIME
        YY          = ISNULL(CAST(YY        AS SMALLINT),0),
        MM          = ISNULL(CAST(MM        AS TINYINT),0),
        DD          = ISNULL(CAST(DD        AS TINYINT),0),
        DW          = ISNULL(CAST(DW        AS TINYINT),0),
        DWMonth     = ISNULL(CAST(DWMonth   AS TINYINT),0),
        IsWeekEnd   = ISNULL(CAST(IsWeekEnd AS TINYINT),0),
        HolidayID   = ISNULL(CAST(HolidayID AS TINYINT),0),
        IsWorkDay   = ISNULL(CAST(0         AS TINYINT),0),
        WorkDayNum  = ISNULL(CAST(0         AS INT),0) --Just to be sure
   INTO dbo.Calendar
   FROM cteGenHolidays
;
--===== Update Good Friday and the Friday after Thanksgiving
 UPDATE tgt
    SET HolidayID = d.HolidayID
   FROM dbo.Calendar tgt
  INNER JOIN
        ( --=== Find dates and holiday IDs for Thanksgiving and Easter Sunday
             -- and translate them to dates for Day after Thanksgiving and Good Friday
         SELECT DT =        CASE
                            WHEN HolidayID =  9 THEN DATEADD(dd, 1,DT) --Day after Thanksgiving
                            WHEN HolidayID = 11 THEN DATEADD(dd,-2,DT) --Good Friday
                            END,
                HolidayID = CASE
                            WHEN HolidayID =  9 THEN 16 --Day after Thanksgiving
                            WHEN HolidayID = 11 THEN 17 --Good Friday
                            END
           FROM dbo.Calendar
          WHERE HolidayID IN (9,11) --Thanksgiving, Easter
        ) d
     ON tgt.DT = d.DT
;
--===== Update IsWorkday based on weekends and holidays
 UPDATE dbo.Calendar
    SET IsWorkday = CASE
                    WHEN IsWeekend = 0       --Isn't a weekend day
                     AND HolidayID IN (0,17) --Isn't a holiday or is Good Friday
                    THEN 1
                    ELSE 0
                    END
;
-------------------------------------------------------------
--===== Add the quintessential clustered index as a PK
  ALTER TABLE dbo.Calendar
    ADD CONSTRAINT PK_Calendar
        PRIMARY KEY CLUSTERED (DT ASC)
        WITH FILLFACTOR = 100
;
--===== Number the work days making the weekends and holidays 
     -- have the same workday as the last previous workday.
DECLARE @Counter    INT,
        @Anchor     DATETIME,
        @WorkDayNum INT
;
 SELECT @Counter = 1,
        @WorkDayNum = 0
;
WITH
cteQuirkyUpdate AS
(
 SELECT RowNum = ROW_NUMBER() OVER (ORDER BY DT),
        DT,
        WorkDayNum,
        IsWorkDay
   FROM dbo.Calendar tgt WITH (TABLOCKX)
)
 UPDATE tgt
    SET @WorkDayNum =   WorkDayNum 
                    =   CASE
                            WHEN RowNum = @Counter
                            THEN @WorkDayNum + IsWorkDay
                            ELSE 1/0 --Forces error if rows get out of sync
                        END,
        @Anchor     =   DT,
        @Counter    =   @Counter + 1
   FROM cteQuirkyUpdate tgt
 OPTION (MAXDOP 1)
;
GO
--===== Add another very important index for "workday" related searches.
 CREATE UNIQUE INDEX ix_Calendar_WorkDayNum
     ON dbo.Calendar (WorkDayNum ASC, DT DESC)
        WITH FILLFACTOR = 100
;
GO
 SELECT * FROM dbo.Calendar
;
