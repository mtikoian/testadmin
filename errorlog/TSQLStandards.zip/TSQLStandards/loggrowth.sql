WITH LogPath
AS (
	SELECT [path] = LEFT([path], LEN([path]) - (CHARINDEX('\', REVERSE([path])) - 1)) + N'log.trc'
	FROM [sys].[traces]
	WHERE [is_default] = 1
	)
SELECT [td].[DatabaseName]
	,[td].[Filename]
	,[Event] = [te].[name]
	,[Change_MB] = ([IntegerData] * 8) / 1024
	,[td].[StartTime]
	,[td].[EndTime]
	,[td].[LoginName]
	,[td].[HostName]
	,[td].[ApplicationName]
	,[td].[spid]
	,[td].[ClientProcessID]
	,[td].[IsSystem]
	,[td].[SqlHandle]
	,[td].[TextData]
FROM [sys].[fn_trace_gettable]((
			SELECT [path]
			FROM [LogPath]
			), DEFAULT) [td]
INNER JOIN [sys].[trace_events] [te] ON [td].[EventClass] = [te].[trace_event_id]
WHERE [td].[EventClass] = 93 --Log File autogrowth
ORDER BY [td].[StartTime];
