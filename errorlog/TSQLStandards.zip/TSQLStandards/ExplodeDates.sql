CREATE FUNCTION dbo.ExplodeDates
        (
         @pStartDate DATETIME
        ,@pEndDate   DATETIME
        )
RETURNS TABLE WITH SCHEMABINDING AS
 RETURN WITH
  E1(N) AS  (
            SELECT 1 UNION ALL SELECT 1 UNION ALL 
            SELECT 1 UNION ALL SELECT 1 UNION ALL 
            SELECT 1 UNION ALL SELECT 1 UNION ALL 
            SELECT 1 UNION ALL SELECT 1 UNION ALL 
            SELECT 1 UNION ALL SELECT 1
            )
, E7(N) AS  (SELECT 1 FROM E1 a, E1 b, E1 c, E1 d, E1 e, E1 f, E1 g)
 SELECT TheDate = @pStartDate UNION ALL --This eliminates the need for subtraction on the Row_Number
 SELECT TOP (DATEDIFF(dd,@pStartDate,@pEndDate)) --and addition here
        TheDate = DATEADD(dd,ROW_NUMBER() OVER (ORDER BY (SELECT NULL)),@pStartDate)
   FROM E7
;