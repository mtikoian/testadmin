
CREATE FUNCTION dbo.fProperCase (@MyString VARCHAR(8000))
/******************************************************************************
Purpose:
This function takes the input string, changes all characters to lower case,
and then changes the leading character of each word to uppercase.

SELECT dbo.fProperCase('this is a tESt of the emERGENcy, broadcast-system 4yoU.')
AS ProperCased

Dependencies:
The dbo.Tally table must exist prior to use of this function.

Revision History:
10/23/2005 - Jeff Moden - Initial creation and unit test
******************************************************************************/
RETURNS VARCHAR(8000)
AS
BEGIN
--===== First, set the whole string to lowercase so we know the condition
SET @MyString = LOWER(@MyString)

--===== Set the first character to uppercase, no matter what 
SET @MyString = STUFF(@MyString,1,1,UPPER(SUBSTRING(@MyString,1,1)))

--===== Set the first character following a "separator" to uppercase
SELECT @MyString = STUFF(@MyString,N+1,1,UPPER(SUBSTRING(@MyString,N+1,1)))
FROM dbo.Tally
WHERE N<LEN(@MyString)
AND SUBSTRING(@MyString,N,1) LIKE '[^A-Z]'

--===== Return the proper case value
RETURN @MySTRING
END
go

