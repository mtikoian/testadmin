CREATE FUNCTION dbo.Base21
--===== This function accepts an integer and returns mostly harmless
     -- "numbering" using letters with all vowels removed.
     -- Jeff Moden
        (@Integer INT)
RETURNS VARCHAR(8) AS
  BEGIN
DECLARE @Return VARCHAR(8)
;

WITH
cteAllowed AS
(
 SELECT 'BCDFGHJKLMNPQRSTVWXYZ' AS Letters
)
 SELECT @Return =
        SUBSTRING(Letters, @Integer/1801088541%21+1, 1) --21^7
      + SUBSTRING(Letters, @Integer/85766121%21+1, 1)   --21^6
      + SUBSTRING(Letters, @Integer/4084101%21+1, 1)    --21^5
      + SUBSTRING(Letters, @Integer/194481%21+1, 1)     --21^4
      + SUBSTRING(Letters, @Integer/9261%21+1, 1)       --21^3
      + SUBSTRING(Letters, @Integer/441%21+1, 1)        --21^2
      + SUBSTRING(Letters, @Integer/21%21+1, 1)         --21^1
      + SUBSTRING(Letters, @Integer%21+1, 1)            --21^0
   FROM cteAllowed
;
 RETURN @Return
    END
GO