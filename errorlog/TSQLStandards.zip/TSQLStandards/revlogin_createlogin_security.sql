SET CONCAT_NULL_YIELDS_NULL OFF

SELECT 'CREATE LOGIN [' + sp.NAME + '] ' + CASE 
		WHEN sp.type = 'S'
			THEN 'WITH PASSWORD = ' + sys.fn_varbintohexstr(sl.password_hash) + ' HASHED, SID = ' + sys.fn_varbintohexstr(sl.sid) + ', '
		WHEN sp.type IN (
				'G'
				,'U'
				)
			THEN ' FROM WINDOWS WITH'
		END + ' DEFAULT_DATABASE = ' + QUOTENAME(sp.default_database_name) + ', DEFAULT_LANGUAGE = ' + sp.default_language_name + CASE sp.type
		WHEN 'S'
			THEN ', CHECK_EXPIRATION = ' + CASE 
					WHEN sl.is_expiration_checked = 0
						THEN 'OFF'
					ELSE 'ON'
					END + ', CHECK_POLICY = ' + CASE 
					WHEN sl.is_policy_checked = 0
						THEN 'OFF'
					ELSE 'ON'
					END
		END + CASE sp.is_disabled
		WHEN 0
			THEN ''
		ELSE '; ALTER LOGIN [' + sp.NAME + '] DISABLE;'
		END
FROM master.sys.server_principals sp
LEFT OUTER JOIN sys.sql_logins sl ON sp.principal_id = sl.principal_id
WHERE sp.NAME NOT LIKE '##%'
	AND sp.NAME <> 'sa'
	AND sp.type <> 'R'
