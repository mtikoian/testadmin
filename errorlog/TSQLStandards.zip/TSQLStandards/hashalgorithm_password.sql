--SQL 2012 and above
DECLARE @pswd NVARCHAR(MAX) = 'APassword';
DECLARE @salt VARBINARY(4) 
set @salt =  CRYPT_GEN_RANDOM(4);
DECLARE @hash VARBINARY(MAX);
SET @hash = 0x0200 + @salt + HASHBYTES('SHA2_512', CAST(@pswd AS VARBINARY(MAX)) + @salt);
SELECT @hash AS HashValue, PWDCOMPARE(@pswd,@hash) AS IsPasswordHash;

--SQL 2005 ,2008 
DECLARE @pswd NVARCHAR(MAX); SET @pswd = 'APassword'; 
DECLARE @salt VARBINARY(4); SET @salt = CAST(NEWID() AS VARBINARY(4)); 
DECLARE @hash VARBINARY(MAX); 
SET @hash = 0x0100 + @salt 
           + HASHBYTES('SHA1', CAST(@pswd AS VARBINARY(MAX)) + @salt); 
SELECT @hash AS HashValue, PWDCOMPARE(@pswd,@hash) AS IsPasswordHash; 

--sql 2000

SET @hash = 0x0100 + @salt 
            HASHBYTES('SHA1', CAST(@pswd AS VARBINARY(MAX)) + @salt) 
            HASHBYTES('SHA1', CAST(UPPER(@pswd) AS VARBINARY(MAX)) + @salt); 