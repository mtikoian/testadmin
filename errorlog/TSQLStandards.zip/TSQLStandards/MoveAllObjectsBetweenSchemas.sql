CREATE PROCEDURE MoveAllObjectsBetweenSchemas(@SourceSchema  VARCHAR(128),
                @DestinationSchema VARCHAR(128),
                @CreateSchemaIfNotExists BIT = 0)
AS
  BEGIN
  DECLARE @err VARCHAR(2000);

  --#################################################################################################
  --Housekeeping and validation
  --#################################################################################################

  --source schema must exist, unless the override bit is sent
  --===================================================================================================
  IF NOT EXISTS(SELECT
        *
        FROM sys.schemas
        WHERE  NAME = @SourceSchema)
   AND @CreateSchemaIfNotExists = 0
    BEGIN
    SET @err = 'The Schema '
         + Quotename(ISNULL(@SourceSchema, 'NULL'))
         + ' Does not exist in sys.schemas in the '
         + Quotename(Db_name()) + ' database.';

    RAISERROR(@err,16,1)
    END

  --destination schema must exist
  --===================================================================================================
  IF NOT EXISTS(SELECT
        *
        FROM sys.schemas
        WHERE  NAME = @DestinationSchema)
    BEGIN
    SET @err = 'The Schema '
         + Quotename(ISNULL(@DestinationSchema, 'NULL'))
         + ' Does not exist in sys.schemas in the '
         + Quotename(Db_name()) + ' database.';

    RAISERROR(@err,16,1)
    END

  --destination schema must not contain any shared tables
  --===================================================================================================
  IF EXISTS (SELECT
       NAME
       FROM sys.tables
       WHERE  SCHEMA_NAME(schema_id) = @DestinationSchema
       INTERSECT
       SELECT
       NAME
       FROM sys.tables
       WHERE  SCHEMA_NAME(schema_id) = @SourceSchema)
    BEGIN
    SET @err = 'The Destination Schema '
         + Quotename(ISNULL(@DestinationSchema, 'NULL'))
         + ' shares at one or more tables with the same name as the '
         + Quotename(ISNULL(@DestinationSchema, 'NULL'))
         + ' Schema, and cannot continue until the Destination schema is cleared of identically named objects in the '
         + Quotename(Db_name()) + ' database.';

    RAISERROR(@err,16,1)
    END

  --you damn well must be sysadmin for this process
  --===================================================================================================
  IF NOT EXISTS(SELECT
        1
        WHERE  Is_srvrolemember('sysadmin') = 1)
    BEGIN
    SET @err = 'This Stored procedure is specifically restricted to sysadmin users only, regardless of execute permissions in the '
         + Quotename(Db_name()) + ' database';
    RAISERROR(@err,16,1)
    END
  --###############################################################################################
  --Optional Create Schema If Not Exists
  --###############################################################################################
  IF @CreateSchemaIfNotExists = 1
    BEGIN
    --DECLARE @DestinationSchema VARCHAR(128) = 'SandBox'
  --DECLARE @SourceSchema VARCHAR(128) = 'PreLoad'
  --Schema [SandBox]
  --Optional Block to create missing schemas
  IF NOT EXISTS(SELECT
        *
        FROM sys.schemas
        WHERE  NAME = @DestinationSchema)
    BEGIN
    DECLARE @cmd VARCHAR(500) = 'CREATE SCHEMA '
      + Quotename(@DestinationSchema) + ';'
    PRINT @cmd
    EXEC (@cmd)
    END;
    END --IF @CreateSchemaIfNotExists
  
  --###############################################################################################
  --core logic below: build the alter statements
  --###############################################################################################
  DECLARE @isql VARCHAR(8000)
  DECLARE c1 CURSOR LOCAL FORWARD_ONLY STATIC READ_ONLY FOR
    --###############################################################################################
    --cursor definition
    --###############################################################################################
    SELECT
    --example results 'ALTER SCHEMA [SandBox] TRANSFER [dbo].[Patient];'
    'ALTER SCHEMA '
    + Quotename(@DestinationSchema)
    + ' TRANSFER '
    + Quotename(OBJECT_SCHEMA_NAME(object_id))
    + '.' + Quotename(NAME) + ';'
    FROM sys.objects
    WHERE  OBJECT_SCHEMA_NAME(object_id) = @SourceSchema
    AND [objects].[type_desc] IN('VIEW',
             'SQL_STORED_PROCEDURE',
             'USER_TABLE',
             'SQL_INLINE_TABLE_VALUED_FUNCTION',
             'SQL_SCALAR_FUNCTION',
             'SQL_TABLE_VALUED_FUNCTION')
  --###############################################################################################
  OPEN c1
  FETCH next FROM c1 INTO @isql
  WHILE @@FETCH_STATUS <> -1
    BEGIN
    PRINT @isql
    EXEC(@isql)
    FETCH next FROM c1 INTO @isql
    END
  CLOSE c1
  DEALLOCATE c1
  END 


  GO