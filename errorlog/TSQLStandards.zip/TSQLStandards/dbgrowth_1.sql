USE master;
GO
SET NOCOUNT ON;

CREATE DATABASE [MALICIOUSNAME];
CREATE DATABASE [MALICIOUSNAME; DROP DATABASE XXX];

USE MALICIOUSNAME; DROP DATABASE XXX
INSERT INTO MONITORING_DB.dbo.TBL_TABLE_LOG
(
     [SERVER_NAME]
    ,[DB_NAME]
    ,[SCHEMA_NAME]
    ,[TABLE_NAME]
    ,[INDEX_NAME]
    ,[ROWS]
    ,[TOTAL_PAGES]
    ,[USED_PAGES]
    ,[DATA_PAGES]
    ,[TOTAL_MB]
    ,[USED_MB]
    ,[DATA_MB]
)
SELECT
   @@SERVERNAME                            AS [SERVER_NAME]
  ,DB_NAME(DB_ID())                        AS [DB_NAME]
  ,OBJECT_SCHEMA_NAME(SPART.object_id)     AS [SCHEMA_NAME]
  ,STAB.name                               AS [TABLE_NAME]
  ,SIDX.name                               AS [INDEX_NAME]
  ,SPART.rows                              AS [ROWS]
  ,SUM(SALU.total_pages  )                 AS [TOTAL_PAGES]
  ,SUM(SALU.used_pages   )                 AS [USED_PAGES]
  ,SUM(SALU.data_pages   )                 AS [DATA_PAGES]
  ,(8 * SUM(SALU.total_pages  )) / 1024.0  AS [TOTAL_MB]
  ,(8 * SUM(SALU.used_pages   )) / 1024.0  AS [USED_MB]
  ,(8 * SUM(SALU.data_pages   )) / 1024.0  AS [DATA_MB]
FROM        sys.tables                  STAB
INNER JOIN  sys.indexes                 SIDX
ON          STAB.object_id          =   SIDX.object_id
INNER JOIN  sys.partitions              SPART
ON          SIDX.object_id          =   SPART.object_id
AND         SIDX.index_id           =   SPART.index_id
INNER JOIN  sys.allocation_units        SALU
ON          SPART.partition_id      =   SALU.container_id
WHERE       SIDX.index_id           IN  (0,1)
AND         STAB.object_id          >   255
GROUP BY STAB.name
        ,SIDX.name
        ,SPART.object_id
        ,SPART.rows
;