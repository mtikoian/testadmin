--#################################################################################################
--developer utility function added by Lowell
--Purpose: Creates an Extended Event that captures all errors raised on the server,
-- that might be supressed by an application.
--#################################################################################################
IF NOT EXISTS(SELECT * FROM [sys].[server_event_sessions]  AS [dxs] WHERE [dxs].[name] = 'ApplicationErrors')
  BEGIN
    CREATE EVENT SESSION [ApplicationErrors] ON SERVER 
    ADD EVENT sqlserver.error_reported(
    ACTION(package0.event_sequence,
       package0.last_error,
       sqlserver.client_app_name,
       sqlserver.client_hostname,
       sqlserver.database_id,
       sqlserver.database_name,
       sqlserver.nt_username,
       sqlserver.plan_handle,
       sqlserver.query_hash,
       sqlserver.query_plan_hash,
       sqlserver.session_nt_username,
       sqlserver.sql_text,
       sqlserver.username)
      WHERE ([package0].[greater_than_equal_int64]([severity],(14)) 
      --AND [sqlserver].[not_equal_i_sql_unicode_string]([sqlserver].[client_hostname],N'SolarWinds')
        )
      ) 
    ADD TARGET package0.event_file(SET filename=N'ApplicationErrors.xel')
    WITH (MAX_MEMORY=1024 KB,EVENT_RETENTION_MODE=ALLOW_SINGLE_EVENT_LOSS,MAX_DISPATCH_LATENCY=30 SECONDS,MAX_EVENT_SIZE=0 KB,MEMORY_PARTITION_MODE=NONE,TRACK_CAUSALITY=OFF,STARTUP_STATE=OFF)

  END

--ALTER EVENT SESSION [ApplicationErrors] ON SERVER STATE = START
--ALTER EVENT SESSION [ApplicationErrors] ON SERVER STATE = STOP