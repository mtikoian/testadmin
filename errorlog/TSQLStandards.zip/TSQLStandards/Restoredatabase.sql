--#################################################################################################
-- Real World DBA Toolkit version 4.94 Lowell Izaguirre lowell@stormrage.com
--#################################################################################################USE [msdb];
USE [msdb];
GO

/****** Object:  Job [Database Maintenance: Restore Production SandBox To Dev]  Script Date: 2/17/2017 7:44:33 AM ******/
BEGIN TRANSACTION;
DECLARE @ReturnCode INT;
SELECT  @ReturnCode = 0;
/****** Object:  JobCategory [[Uncategorized (Local)]]  Script Date: 2/17/2017 7:44:33 AM ******/
IF NOT EXISTS ( SELECT  [syscategories].[name]
      FROM  [msdb].[dbo].[syscategories]
      WHERE [syscategories].[name] = N'[Uncategorized (Local)]'
        AND [syscategories].[category_class] = 1 )
  BEGIN
  EXEC @ReturnCode = [msdb].[dbo].[sp_add_category] @class = N'JOB', @type = N'LOCAL', @name = N'[Uncategorized (Local)]';
  IF ( @@ERROR <> 0
   OR @ReturnCode <> 0
   )
  GOTO QuitWithRollback;

  END;

DECLARE @jobId BINARY(16);
EXEC @ReturnCode = [msdb].[dbo].[sp_add_job] @job_name = N'Database Maintenance: Restore Production SandBox To Dev', @enabled = 1, @notify_level_eventlog = 0,
  @notify_level_email = 2, @notify_level_netsend = 0, @notify_level_page = 0, @delete_level = 0, @description = N'No description available.',
  @category_name = N'[Uncategorized (Local)]', @owner_login_name = N'mydomain\lizaguirre', @notify_email_operator_name = N'DBA Team', @job_id = @jobId OUTPUT;
IF ( @@ERROR <> 0
   OR @ReturnCode <> 0
 )
  GOTO QuitWithRollback;
/****** Object:  Step [Backup OurServerSSEG.SandBox As SandBoxSnapshot.bak]  Script Date: 2/17/2017 7:44:35 AM ******/
EXEC @ReturnCode = [msdb].[dbo].[sp_add_jobstep] @job_id = @jobId, @step_name = N'Backup OurServerSSEG.SandBox As SandBoxSnapshot.bak', @step_id = 1,
  @cmdexec_success_code = 0, @on_success_action = 3, @on_success_step_id = 0, @on_fail_action = 2, @on_fail_step_id = 0, @retry_attempts = 0,
  @retry_interval = 0, @os_run_priority = 0, @subsystem = N'TSQL', @command = N'EXECUTE(''
BACKUP DATABASE [SandBox] 
TO  DISK = N''''E:\MSSQL\Backups\OurServerSSEG_SandBox_Snapshot.bak'''' 
WITH  COPY_ONLY, 
NOFORMAT, 
INIT,  
NAME = N''''SandBox-Full Database Backup'''', 
SKIP, 
NOREWIND, 
NOUNLOAD,  
STATS = 10'') AT OurServerSSEG
', @database_name = N'master', @flags = 0;
IF ( @@ERROR <> 0
   OR @ReturnCode <> 0
 )
  GOTO QuitWithRollback;
/****** Object:  Step [Copy SandBoxSnapshot.bak to local drive]  Script Date: 2/17/2017 7:44:36 AM ******/
EXEC @ReturnCode = [msdb].[dbo].[sp_add_jobstep] @job_id = @jobId, @step_name = N'Copy SandBoxSnapshot.bak to local drive', @step_id = 2, @cmdexec_success_code = 0,
  @on_success_action = 3, @on_success_step_id = 0, @on_fail_action = 2, @on_fail_step_id = 0, @retry_attempts = 0, @retry_interval = 0, @os_run_priority = 0,
  @subsystem = N'CmdExec', @command = N'ROBOCOPY "\\OurServerSSEG\E$\MSSQL\Backups" "\\OurServerDev\F$\Backup\SQL" "OurServerSSEG_SandBox_Snapshot.bak"
IF %ERRORLEVEL% LSS 8 EXIT /B 0
  EXIT /B 1', @flags = 0;
IF ( @@ERROR <> 0
   OR @ReturnCode <> 0
 )
  GOTO QuitWithRollback;
/****** Object:  Step [Resxtore SandBoxSnapshot On Dev]  Script Date: 2/17/2017 7:44:37 AM ******/
EXEC @ReturnCode = [msdb].[dbo].[sp_add_jobstep] @job_id = @jobId, @step_name = N'Resxtore SandBoxSnapshot On Dev', @step_id = 3, @cmdexec_success_code = 0,
  @on_success_action = 3, @on_success_step_id = 0, @on_fail_action = 2, @on_fail_step_id = 0, @retry_attempts = 0, @retry_interval = 0, @os_run_priority = 0,
  @subsystem = N'TSQL', @command = N'ALTER DATABASE [SandBox] SET OFFLINE WITH ROLLBACK IMMEDIATE
USE [master]
RESTORE DATABASE [SandBox] 
FROM  DISK = N''F:\Backup\SQL\OurServerSSEG_SandBox_Snapshot.bak'' 
WITH  FILE = 1,  
MOVE N''SandBox'' TO N''G:\Data\SandBox.mdf'', 
MOVE N''SandBoxReadOnly'' TO N''G:\Data\SandBoxReadOnly.ndf'',  
MOVE N''SandBox_log'' TO N''F:\Log\SQL\SandBox_log.ldf'',  
NOUNLOAD,  
REPLACE,  
STATS = 5;
--this specific database is typically kept in a READ_ONLY state. On Dev it must be READ_WRITE
ALTER DATABASE [SandBox] SET READ_WRITE', @database_name = N'master', @flags = 0;
IF ( @@ERROR <> 0
   OR @ReturnCode <> 0
 )
  GOTO QuitWithRollback;
/****** Object:  Step [Delete the huge backup off of OurServerSSEG]  Script Date: 2/17/2017 7:44:37 AM ******/
EXEC @ReturnCode = [msdb].[dbo].[sp_add_jobstep] @job_id = @jobId, @step_name = N'Delete the huge backup off of OurServerSSEG', @step_id = 4, @cmdexec_success_code = 0,
  @on_success_action = 3, @on_success_step_id = 0, @on_fail_action = 2, @on_fail_step_id = 0, @retry_attempts = 0, @retry_interval = 0, @os_run_priority = 0,
  @subsystem = N'CmdExec', @command = N'DEL \\OurServerSSEG\e$\MSSQL\Backups\OurServerSSEG_SandBox_Snapshot.bak', @flags = 0;
IF ( @@ERROR <> 0
   OR @ReturnCode <> 0
 )
  GOTO QuitWithRollback;
/****** Object:  Step [Delete the huge backup off of OurServerDev]  Script Date: 2/17/2017 7:44:37 AM ******/
EXEC @ReturnCode = [msdb].[dbo].[sp_add_jobstep] @job_id = @jobId, @step_name = N'Delete the huge backup off of OurServerDev', @step_id = 5, @cmdexec_success_code = 0,
  @on_success_action = 3, @on_success_step_id = 0, @on_fail_action = 2, @on_fail_step_id = 0, @retry_attempts = 0, @retry_interval = 0, @os_run_priority = 0,
  @subsystem = N'CmdExec', @command = N'DEL \\OurServerDev\F$\Backup\SQL\OurServerSSEG_SandBox_Snapshot.bak', @flags = 0;
IF ( @@ERROR <> 0
   OR @ReturnCode <> 0
 )
  GOTO QuitWithRollback;
/****** Object:  Step [Notify BI Team that the database was refreshed]  Script Date: 2/17/2017 7:44:37 AM ******/
EXEC @ReturnCode = [msdb].[dbo].[sp_add_jobstep] @job_id = @jobId, @step_name = N'Notify BI Team that the database was refreshed', @step_id = 6,
  @cmdexec_success_code = 0, @on_success_action = 1, @on_success_step_id = 0, @on_fail_action = 2, @on_fail_step_id = 0, @retry_attempts = 0,
  @retry_interval = 0, @os_run_priority = 0, @subsystem = N'TSQL', @command = N'EXEC msdb.dbo.sp_send_dbmail
@profile_name = ''SQLAdmin'',
@recipients = ''lizaguirre@somedomain.org;'',
@subject = ''OurServerDev SandBox Database Restored From Production'',
@body = ''{from Lowell}<br /> The database SandBox from production has been backed up and restored from Production with todays most current data.'' ,
@body_format = ''HTML''
', @database_name = N'master', @flags = 0;
IF ( @@ERROR <> 0
   OR @ReturnCode <> 0
 )
  GOTO QuitWithRollback;
EXEC @ReturnCode = [msdb].[dbo].[sp_update_job] @job_id = @jobId, @start_step_id = 1;
IF ( @@ERROR <> 0
   OR @ReturnCode <> 0
 )
  GOTO QuitWithRollback;
EXEC @ReturnCode = [msdb].[dbo].[sp_add_jobserver] @job_id = @jobId, @server_name = N'(local)';
IF ( @@ERROR <> 0
   OR @ReturnCode <> 0
 )
  GOTO QuitWithRollback;
COMMIT TRANSACTION;
GOTO EndSave;
QuitWithRollback:
IF ( @@TRANCOUNT > 0 )
  ROLLBACK TRANSACTION;
EndSave:

GO