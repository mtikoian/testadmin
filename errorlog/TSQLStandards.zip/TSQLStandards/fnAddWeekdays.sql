 CREATE FUNCTION dbo.fnAddWeekdays (@Start DATETIME, @Days INT)
RETURNS DATETIME
     AS
  BEGIN
DECLARE @End DATETIME
 SELECT @End = @Start + @Days/5*7 + @Days%5 
             + CASE 
                   WHEN (@@DATEFIRST + (DATEPART(dw, @Start) - 2)) % 7 + 1 + @Days%5 > 5 
                   THEN 8 - ((@@DATEFIRST + (DATEPART(dw, @Start) - 2)) % 7 + 1 + @Days%5)
                   ELSE 0 
               END
 RETURN @End
    END