
--===== If DATETIME were stored as a FLOAT, it would be able to withstand
     -- a conversion to FLOAT and back to a DATETIME with no change.
     -- This demonstrates that's not the case and that even a 38 place
     -- DECIMAL conversion will not suffice.
DECLARE @DateTime DATETIME;
 SELECT @DateTime = '00:00:11';
 SELECT  [DATETIME]         = @DateTime
        ,[FLOAT AND BACK]   = CAST(CAST(@DateTime AS FLOAT) AS DATETIME)
        ,[DECIMAL AND BACK] = CAST(CAST(@DateTime AS DECIMAL(38,38)) AS DATETIME)
;


--===== A little deeper proof.  You could verify the values stored by saving them in a table and 
     -- then using DBCC PAGE to confirm the values below are true (taking "little endian into consideration").
DECLARE @DateTime DATETIME;
 SELECT @DateTime = '1900-01-11 12:00:00'
;
 SELECT  [BINARY]      = CAST(@DateTime AS BINARY(8)) --This is what 10 and a half days after 1900-01-01 looks like
        ,[FLOAT]       = CAST(@DateTime AS FLOAT)     --Converted to float to prove it's 10 and a half days                
        ,[10.5 as BIN] = CAST(10.5      AS BINARY(8)) --Converted to 10.5 to BINARY(8) and it's totally different.
;

CREATE TABLE #BigNums (TestNum DECIMAL(38,15))

INSERT INTO #BigNums
SELECT 1.* CHECKSUM(NEWID()) / POWER(10, ABS(CHECKSUM(NEWID())) % 10)
FROM (
    SELECT TOP 1000000 1
    FROM sys.all_columns a, sys.all_columns b
    )Tally(n)

PRINT 'Dwain Redux'
SET STATISTICS TIME ON
 SELECT  CASE 
        WHEN FLOOR(TestNum) = TestNum THEN 0
        ELSE LEN(CAST(REVERSE(TestNum - CAST(FLOOR(TestNum) AS DECIMAL)) AS DECIMAL)) END
FROM #BigNums


--===== For Digits
 SELECT  LeftPortion  = CONVERT(VARCHAR(10),CONVERT(INT,TestNum))
        ,RightPortion = STUFF(ABS(TestNum % 1),1,2,'')
   FROM #BigNums
;


--===== For Digits
 SELECT  IntegerPortion = CONVERT(INT,TestNum)
        ,DecimalPortion = ABS(TestNum % 1)
   FROM #BigNums
;