--@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
--IF table data_info exists in your current database sysobjects
--the script will drop the table then create it again (to avoid data redundancy)
--otherwise it will create the table data_info
IF EXISTS(SELECT name FROM sysobjects WHERE name='data_info')
DROP TABLE data_info

create table data_info 
   (
   fileid int,
   filegroup int, 
   totalextents real, 
   usedextents real,
   Name varchar(1024),
   filename varchar(1024),
   Data_Date datetime
   )
ALTER TABLE data_info  ADD 
	CONSTRAINT [DF_Data_info_Data_Date] DEFAULT (getdate()) FOR [Data_Date]

--@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@




--@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

--IF table data_log exists in your current database sysobjects
--the script will drop the table then create it again (to avoid data redundancy)
--otherwise it will create the table data_log 
IF EXISTS(SELECT name FROM sysobjects WHERE name='data_log')
DROP TABLE data_log
CREATE TABLE data_log
(
DBName varchar(32),
LogSize decimal(6,2),
LogSpaceUsed decimal(6,2),
Status int,
Dates Datetime
)

--Alter table to get the data and time of the executed process
--Every time the stored procedure is being used
ALTER TABLE data_log  ADD 
	CONSTRAINT [DF_Data_log_Dates] DEFAULT (getdate()) FOR [Dates]

--@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

--@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@--
--Script Made by Lester A. Policarpio
--July 20, 2007
--Any questions or clarifications feel free to email me at:
--lpolicarpio2005@yahoo.com
--@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@--

CREATE VIEW view_data AS
SELECT Name AS 'DB Name',(totalextents*64)/1024 AS'DB Size',(usedextents*64)/1024 AS 'DB Used',
((totalextents*64)/1024)-((usedextents*64)/1024) AS 'DB Space',
(logsize) AS 'LOG Size',((logsize*logspaceused)/100.0) AS 'LOG Used',
(logsize)-((logsize*logspaceused)/100.0)AS 'LOG Space',Dates AS 'DATE'
FROM data_info,data_log WHERE name = DBName  AND name !='model' AND name !='DBA' AND name !='master'
AND name !='msdb' AND name !='Northwind'AND name !='pubs'AND name !='tempdb' AND Data_Date >= DATEADD(day, DATEDIFF(day, 0, GETDATE()), 0) AND 
Data_Date < DATEADD(day, DATEDIFF(day, 0, GETDATE()),1) AND Dates >= DATEADD(day, DATEDIFF(day, 0, GETDATE()), 0) AND 
Dates < DATEADD(day, DATEDIFF(day, 0, GETDATE()),1)

