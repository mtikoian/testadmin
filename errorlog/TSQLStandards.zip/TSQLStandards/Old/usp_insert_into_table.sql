/***************************************************************
Script Made by Lester A. Policarpio
Any Questions or clarifications feel free to email me at
lpolicarpio2005@yahoo.com
Modified at 10/02/2007 9:00 AM
NOTE: THis is a stored procedure, you have to supply it with a table name
to have the schema of the table.
example: usp_insert_into_table <table_name>
       : usp_insert_into_table 'northwind'
that will give you INSERT INTO Northwind (blah blah blah)

*/

CREATE PROC usp_insert_into_table (@table varchar(128))
AS

DECLARE @transfer varchar(1024)
if exists (select name from sysobjects where name = 'scheme')
DROP TABLE scheme
if exists (select name from sysobjects where name = 'helpindex')
DROP TABLE helpindex

CREATE TABLE scheme 
(
col_names varchar(128),
col_id int,
col_typename varchar(100),
col_len int,
col_prec int,
col_scale nvarchar(128),
col_basetypename varchar(100),
col_defname varchar(100),
col_rulname varchar(100),
col_null int,
col_identitty int,
col_flags int,
col_see nvarchar(128),
col_increment nvarchar(128),
col_dridefname varchar(100),
text1 varchar(100),
col_iscomputed int,
text2 varchar(100),
col_notforepl int,
col_fulltext varchar(128),
col_ansipad int,
col_downer varchar(128),
col_dname varchar(128),
col_rowner varchar(128),
col_rname varchar(128),
collation varchar(128),
coltype varchar(128),
num int,
num2 int
)
CREATE TABLE helpindex
(
indexname varchar(128),
descript varchar(1024),
dbname varchar(128)
)
set @transfer = 'sp_mshelpcolumns '+''''+@table+''''
INSERT INTO scheme EXEC (@transfer)
DECLARE @a varchar(128)
DECLARE @b varchar(5000)
DECLARE @d varchar(128)
DECLARE @c varchar(1280)
DECLARE @e varchar(128)
DECLARE @f varchar(128)
DECLARE @select varchar(128)
DECLARE @copy varchar(1024)
DECLARE @dride varchar(128)
DECLARE @text1 varchar(128)
DECLARE @indexname varchar(128)
DECLARE @descript varchar(1024)
DECLARE @dbname varchar(1024)
DECLARE @help varchar(1024)
SET @help = 'sp_helpindex '+''''+@table+''''
INSERT INTO helpindex EXEC (@help) 
DELETE FROM helpindex WHERE indexname NOT LIKE '%PK_%'
if exists (select descript from helpindex where descript like '%nonclustered%')
UPDATE helpindex set descript = 'NONCLUSTERED'
else
UPDATE helpindex set descript = 'CLUSTERED'
set @b = 'INSERT INTO '+@table+'('
DECLARE a CURSOR FOR
select col_names,col_typename,col_len,col_prec,col_scale,col_dridefname,text1 from scheme
OPEN a
FETCH NEXT FROM a INTO @a,@c,@d,@e,@f,@dride,@text1
WHILE (@@FETCH_STATUS = 0)
BEGIN

--@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
if (@c = 'varchar') OR (@c = 'nvarchar') OR (@c = 'char')
BEGIN
	
	set @b = @b+@a+' '+@c+'('+@d+'),'
	
END
--@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	
--@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
if (@c = 'decimal') OR (@c = 'numeric')
BEGIN
	
	set @b = @b+@a+' '+@c+' '+'('+@e+','+@f+'),'
	
END
--@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

--@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
if (@c NOT IN  ('varchar','nvarchar','decimal','char'))
BEGIN
	
	set @b = @b+@a+' '+@c+','
	
END
--@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
FETCH NEXT FROM a INTO @a,@c,@d,@e,@f,@dride,@text1
END 
CLOSE a
DEALLOCATE a
if (select count(*) from helpindex) = 0
set @b = @b+')'


print @b


DROP TABLE scheme
DROP TABLE helpindex