CREATE PROCEDURE usp_data_info AS
--@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@--
--Script Made by Lester A. Policarpio
--July 19, 2007
--Any questions or clarifications feel free to email me at:
--lpolicarpio2005@yahoo.com
--@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@--

--Declare the variables
DECLARE @Database NVARCHAR(128)
DECLARE @data nvarchar(128)
DECLARE @counter nvarchar(128)
DECLARE @counter2 nvarchar(1028)
DECLARE @Datalog nvarchar(1024)

-- Declare CURSOR named DatabaseName to hold values of "SELECT name FROM master..sysdatabases "
DECLARE DatabaseName CURSOR FOR

-- Get all the names of the Databases in master..sysdatabases
SELECT name FROM master..sysdatabases 
  
-- Open the created cursor so we can use it to get the Database Names
OPEN DatabaseName

--  Create a loop for getting all the database names
FETCH NEXT FROM DatabaseName INTO @Database

	
	WHILE (@@FETCH_STATUS = 0)
		
		-- loop process starts from the 1st database name in master..sysdatabases
		BEGIN

			--The @data variable holds the value of (use [databasename] dbcc showfilestats)
			SELECT @data = 'use '+ @Database + ' dbcc showfilestats'

			-- Insert the executed value of @data to the table data_info
			INSERT INTO data_info(fileid,filegroup,totalextents,usedextents,Name,FIleName)  EXECUTE(@data)

			--Set @counter variable to hold the value of the select statament
			SET @counter = '('+'select name from '+ @Database +'..sysfiles where fileid = 1'+')'

			--SET @counter2 variable to hold the value of the UPDATE statement WHERE the name
			--is equal to the value stored in the variable @counter 
			SET @counter2 = 'UPDATE data_info SET name = '+''''+ @Database+''''+ ' WHERE name = '+  @counter
				
			--Execute the variable @counter2
			EXECUTE (@counter2)

			

	-- Proceed to the next database name in master..sysdatabases
	FETCH NEXT FROM DatabaseName INTO @Database

		--You have just reached the last database name in master..sysdatabases
		END 
		
--Close the Cursor DatabaseName
CLOSE DatabaseName

--Deallocate the Cursor DatabaseName
DEALLOCATE DatabaseName


-------GETTING THE LOG SIZE
DECLARE @logs varchar(1024)

SET @logs = 'DBCC SQLPERF(LOGSPACE)'
INSERT INTO data_log(dbname,LogSize,LogSpaceUsed,Status) EXEC(@logs)
GO