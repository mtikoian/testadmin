 CREATE VIEW dbo.vUnconstrainedRandomInt WITH SCHEMABINDING AS
/***************************************************************************************************
 Returns an unconstrained random integer suitable for use virtually anywhere including in a function
***************************************************************************************************/
 SELECT UnconstrainedRandomInt = ABS(CHECKSUM(NEWID()));
GO
 CREATE FUNCTION dbo.tvfRandomNumberList
/***************************************************************************************************
 Function returns a list of randomly generated numbers with a UniqueKey.
 @pMinValue = the mimiumn value of the random numbers generated.
 @pMaxValue = the maximum value of the random numbers generated.
 @pSize     = the number of random numbers to be returned.

 This code is a direct replacement for the CLR function which may be found at the following URL.
 http://www.sqlwithcindy.com/2013/04/elegant-random-number-list-in-sql-server.html
***************************************************************************************************/
--===== Declare the I/O for this function
        (
        @pMinValue  INT
,       @pMaxValue  INT
,       @pSize INT
        )
RETURNS TABLE WITH SCHEMABINDING AS
--===== Create and return the random number list
 RETURN WITH
  E1(N) AS (
            SELECT 1 UNION ALL SELECT 1 UNION ALL
            SELECT 1 UNION ALL SELECT 1 UNION ALL
            SELECT 1 UNION ALL SELECT 1 UNION ALL
            SELECT 1 UNION ALL SELECT 1 UNION ALL
            SELECT 1 UNION ALL SELECT 1     --10E1 or up to 10 rows
           )
, E3(N) AS (SELECT 1 FROM E1 a, E1 b, E1 c) --10E3 or up to 1,000 rows
, E9(N) AS (SELECT 1 FROM E3 a, E3 b, E3 c) --10E9 or up to 1,000,000,000 rows
            SELECT TOP (@pSize)
                   UniqueKey    = ROW_NUMBER() OVER (ORDER BY (SELECT NULL))
                 , RandomNumber = ri.UnconstrainedRandomInt %(@pMaxValue-@pMinValue+1) +@pMinValue
              FROM E9, dbo.vUnconstrainedRandomInt ri
;