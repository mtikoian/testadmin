--http://www.sqlservercentral.com/articles/comma+separated+list/71700/

WITH CTE AS
(
SELECT DISTINCT 
       AccountNumber
  FROM #TestData
)
SELECT AccountNumber,
       CommaList = STUFF((
                   SELECT ',' + Value
                     FROM #TestData
                    WHERE AccountNumber = CTE.AccountNumber
                    ORDER BY Value
                      FOR XML PATH(''), 
                              TYPE).value('.','varchar(max)'),1,1,'')
  FROM CTE
 ORDER BY AccountNumber;