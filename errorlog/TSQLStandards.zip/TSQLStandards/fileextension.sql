
SELECT 
    breach_content,
    RIGHT(breach_content, CASE WHEN SUBSTRING(breach_content, LEN(breach_content) - 3, 1) = '.' THEN 3 ELSE 4 END) AS extension
FROM (
    SELECT 'e:\deploy\applications\intel management engine interface and serial over lan driver (sol) driver 7.1.2.1041v2\me_sw\mewmiprov\me\cim_schema\system\cim_computersystemdma.mof' AS breach_content UNION ALL
    SELECT 'c:\$recycle.bin\s-1-5-21-3125639655-2069970247-2443061104-29869\$iqzvjd6.jpg' UNION ALL
    SELECT 'c:\users\asdf\music\the cranberrieso need to argue\02 i can''t be with you.mp3' UNION ALL
    SELECT 'e:\oracle\epm\docs\epm~1.111\wa_user\about_navigating_data_objects.html' UNION ALL
    SELECT 'Marijuana; Suicide; ***; butt; don�t say anything; drug; kick; knife; knives; marijuana; murder; naked; opiate; party;'  UNION ALL     
    SELECT 'prick; scam; sex; smoke; smoke a joint; smoking; sneak; speculation; stabbed; stoned; suck; tripping' UNION ALL
    SELECT '01 Jan. 1963; 01 SEP 1947; 01/01/1964; 01/01/58; 01/01/64; 01/01/65; 01/01/67; 01/01/68; 01/01/69; 01/01/71; 01/01/72; 01/01/73; 01/01/75; 01/01/78; 01/01/80; 01/01/82; 01/01/85; 01/02/62; 01/02/64; 01/02/66; 01/03/61; 01/03/64; 01/03/65; 01/04/66; 01/05/50; 01/05/72; 01/06/72; 01/06/76; 01/06/80; 01/07/71; 01/08/70; 01/09/79; 01/10/61; 01/10/76; 01/11/75; 01/12/73; 01/25/32; 02/01/72; 02/02/33; 02/02/63; 02/03/65; 02/03/84; 02/04/66; 02/05/69; 02/05/70;'
) AS test_data
WHERE breach_content LIKE '%[a-z]:%\%.%' AND 
    '.' IN (SUBSTRING(breach_content, LEN(breach_content) - 3, 1), SUBSTRING(breach_content, LEN(breach_content) - 4, 1))
