CREATE FUNCTION dbo.GetEasterDate
	/**********************************************************************************************************************
 Purpose:
 Given a 4 digit year, returns the date for Easter Sunday of that year.
 Acknowledgement:
This code was written by Peter Larsson. All I did was formalize the code a bit. Please visit Peter's blog about 
this code at the following URL:
http://weblogs.sqlteam.com/peterl/archive/2010/09/08/fast-easter-day-function.aspx
Peter's blog has a wealth of other very helpful tips in it. You might want to linger there a bit.
Usage:
--===== Single value usage
SELECT @EasterDate = EasterDate FROM dbo.GetEasterDate(@Year); --Year is a 4 digit integer data-type
--===== Select multi-value usage
SELECT t.ColList, ed.EasterDate
FROM dbo.SomeTable t
CROSS APPLY dbo.GetEasterDate(IntegerYear)
;
Programmer's Notes:
1. The basis for this function is simple. The occurance of Easter Sunday is cyclic and based on the relatively sure
orbit of the Moon. This cycle repeats itself every 19 years and, with the aid of a bit of hardcoding, makes this
function very simple and very fast.
2. Please refer to the following article for why this function was converted to an iSF in Rev 02.
http://www.sqlservercentral.com/articles/T-SQL/91724/
Revision History:
Rev 00 - 08 Sep 2010 - Peter Larsson - Initial development and test.
Rev 01 - 02 Nov 2010 - Jeff Moden - Formalize the code
Rev 02 - 11 Jun 2013 - Jeff Moden - Convert the code to a high performance iSF.
**********************************************************************************************************************/
	--===== Declare the I/O for this function
	(@Year SMALLINT)
RETURNS TABLE
	WITH SCHEMABINDING
AS
RETURN

SELECT EasterDate = DATEADD(DAY, DATEDIFF(DAY, 0, CONVERT(DATETIME, CAST(@Year AS CHAR(4)) + BaseDate, 112)) / 7 * 7, 6)
FROM (
	SELECT CASE @Year % 19
			WHEN 0
				THEN '0415'
			WHEN 1
				THEN '0404'
			WHEN 2
				THEN '0324'
			WHEN 3
				THEN '0412'
			WHEN 4
				THEN '0401'
			WHEN 5
				THEN '0419'
			WHEN 6
				THEN '0409'
			WHEN 7
				THEN '0329'
			WHEN 8
				THEN '0417'
			WHEN 9
				THEN '0406'
			WHEN 10
				THEN '0326'
			WHEN 11
				THEN '0414'
			WHEN 12
				THEN '0403'
			WHEN 13
				THEN '0323'
			WHEN 14
				THEN '0411'
			WHEN 15
				THEN '0331'
			WHEN 16
				THEN '0418'
			WHEN 17
				THEN '0408'
			WHEN 18
				THEN '0328'
			ELSE NULL --Should NEVER happen
			END
	WHERE @Year BETWEEN 1900
			AND 9999
	) d(BaseDate);
