create function GetNumbersOnly(@pString varchar(8000))
returns table as return
	WITH
		E1(N) AS (select 1 from (values (1),(1),(1),(1),(1),(1),(1),(1),(1),(1))dt(n)),
		E2(N) AS (SELECT 1 FROM E1 a, E1 b), --10E+2 or 100 rows
		E4(N) AS (SELECT 1 FROM E2 a, E2 b), --10E+4 or 10,000 rows max
		cteTally(N) AS (SELECT  ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) FROM E4)
	, ValueList as 
	(
		SELECT N, SUBSTRING(@pString, N, 1) as NewVal
		FROM cteTally
		WHERE N <= LEN(@pString)
			AND SUBSTRING(@pString, N, 1) LIKE ('[0-9]')  
	)
	
	SELECT top 1 NewVal = replace(STUFF((
                   SELECT '+' + NewVal
                     FROM ValueList
                      FOR XML PATH(''), TYPE).value('.','varchar(max)'),1,1,''), '+', '')
	FROM ValueList