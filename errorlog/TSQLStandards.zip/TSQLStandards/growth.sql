/*
ServerName DBName Total Disk Space LastInserted Rank1 
ServerA DbA 12671 11/21/2016 40 
ServerA DbA 14784 3/12/2017 1 
ServerB DbB 366 11/21/2016 24 
ServerB DbB 466 3/12/2017 1 
ServerC DbC 142 11/21/2016 14 
ServerC DbC 432 3/12/2017 1 
*/
declare @TestTable table (
  ServerName sysname,
  DBName sysname,
  TotalDiskSpace int, -- may want BIGINT
  LastInserted date,
  Rank1 int
);
insert into @TestTable
values
  ('ServerA','DbA',12671,'2016/11/21',40)
  ,('ServerA','DbA',14784,'2017/03/12',1)
  ,('ServerB','DbB',366,'2016/11/21',24)
  ,('ServerB','DbB',466,'2017/03/12',1)
  ,('ServerC','DbC',142,'2016/11/21',14)
  ,('ServerC','DbC',432,'2017/03/12',1);

select * from @TestTable;

/*
Assumptions, so I don't make an ass of myself
1) There will only be two entries for any given
   ServerName DBName pair. This allows for more
   than one database on a server.
2) The Rank1 column is actually unneeded as it
   does not appear in the expected results.
3) As this posted in a SQL2008 forum, you running
   SQL Server 2008 or 2008 R2.
4) All code is provided as is with no warranty
   implied or expressed and with no promise that
   it will work in your environment without any
   modification that must be done by you.
*/

with BaseData as (
select
  rn = row_number() over (partition by tt.ServerName, tt.DBName order by tt.LastInserted)
  , tt.ServerName
  , tt.DBName
  , tt.TotalDiskSpace
  , tt.LastInserted
from
  @TestTable tt
), PivotData as (
select
  bd.ServerName
  , bd.DBName
  , max(case rn when 1 then bd.LastInserted end) OldDt
  , max(case rn when 2 then bd.LastInserted end) NewDt
  , max(case rn when 1 then bd.TotalDiskSpace end) InitialSize
  , max(case rn when 2 then bd.TotalDiskSpace end) FinalSize
from
  BaseData bd
group by
  bd.ServerName
  , bd.DBName
)
select
  pd.ServerName
  , pd.DBName
  , pd.OldDt
  , pd.NewDt
  , pd.InitialSize
  , pd.FinalSize
  , SpaceGrowth = pd.FinalSize - pd.InitialSize
from
  PivotData pd
order by
  pd.ServerName
  , pd.DBName

