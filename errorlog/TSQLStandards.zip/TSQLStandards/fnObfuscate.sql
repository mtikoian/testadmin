IF EXISTS (SELECT * FROM sysobjects WHERE name = 'tblDigram' AND xtype = 'U')
	DROP TABLE tblDigram
GO

-- Table of the 100 most common English language Digrams
CREATE TABLE tblDigram(
	digramID INT IDENTITY (1, 1),
	digram CHAR(2)
	)

INSERT INTO tblDigram (digram) SELECT 'TH'; INSERT INTO tblDigram (digram) SELECT 'CO'
INSERT INTO tblDigram (digram) SELECT 'DI'; INSERT INTO tblDigram (digram) SELECT 'US'
INSERT INTO tblDigram (digram) SELECT 'EI'; INSERT INTO tblDigram (digram) SELECT 'IN'
INSERT INTO tblDigram (digram) SELECT 'DE'; INSERT INTO tblDigram (digram) SELECT 'SI'
INSERT INTO tblDigram (digram) SELECT 'MO'; INSERT INTO tblDigram (digram) SELECT 'AD'
INSERT INTO tblDigram (digram) SELECT 'ER'; INSERT INTO tblDigram (digram) SELECT 'RA'
INSERT INTO tblDigram (digram) SELECT 'CA'; INSERT INTO tblDigram (digram) SELECT 'OM'
INSERT INTO tblDigram (digram) SELECT 'SS'; INSERT INTO tblDigram (digram) SELECT 'RE'
INSERT INTO tblDigram (digram) SELECT 'RO'; INSERT INTO tblDigram (digram) SELECT 'UN'
INSERT INTO tblDigram (digram) SELECT 'AI'; INSERT INTO tblDigram (digram) SELECT 'IL'
INSERT INTO tblDigram (digram) SELECT 'AN'; INSERT INTO tblDigram (digram) SELECT 'LI'
INSERT INTO tblDigram (digram) SELECT 'UT'; INSERT INTO tblDigram (digram) SELECT 'PR'
INSERT INTO tblDigram (digram) SELECT 'OS'; INSERT INTO tblDigram (digram) SELECT 'HE'
INSERT INTO tblDigram (digram) SELECT 'RI'; INSERT INTO tblDigram (digram) SELECT 'NC'
INSERT INTO tblDigram (digram) SELECT 'WE'; INSERT INTO tblDigram (digram) SELECT 'UL'
INSERT INTO tblDigram (digram) SELECT 'AR'; INSERT INTO tblDigram (digram) SELECT 'IO'
INSERT INTO tblDigram (digram) SELECT 'WI'; INSERT INTO tblDigram (digram) SELECT 'AC'
INSERT INTO tblDigram (digram) SELECT 'EM'; INSERT INTO tblDigram (digram) SELECT 'EN'
INSERT INTO tblDigram (digram) SELECT 'LE'; INSERT INTO tblDigram (digram) SELECT 'HO'
INSERT INTO tblDigram (digram) SELECT 'EE'; INSERT INTO tblDigram (digram) SELECT 'NS'
INSERT INTO tblDigram (digram) SELECT 'TI'; INSERT INTO tblDigram (digram) SELECT 'ND'
INSERT INTO tblDigram (digram) SELECT 'TR'; INSERT INTO tblDigram (digram) SELECT 'ET'
INSERT INTO tblDigram (digram) SELECT 'OT'; INSERT INTO tblDigram (digram) SELECT 'TE'
INSERT INTO tblDigram (digram) SELECT 'MA'; INSERT INTO tblDigram (digram) SELECT 'BE'
INSERT INTO tblDigram (digram) SELECT 'SA'; INSERT INTO tblDigram (digram) SELECT 'GE'
INSERT INTO tblDigram (digram) SELECT 'AT'; INSERT INTO tblDigram (digram) SELECT 'SE'
INSERT INTO tblDigram (digram) SELECT 'CE'; INSERT INTO tblDigram (digram) SELECT 'NI'
INSERT INTO tblDigram (digram) SELECT 'IR'; INSERT INTO tblDigram (digram) SELECT 'ON'
INSERT INTO tblDigram (digram) SELECT 'AL'; INSERT INTO tblDigram (digram) SELECT 'WH'
INSERT INTO tblDigram (digram) SELECT 'RT'; INSERT INTO tblDigram (digram) SELECT 'AV'
INSERT INTO tblDigram (digram) SELECT 'HA'; INSERT INTO tblDigram (digram) SELECT 'IC'
INSERT INTO tblDigram (digram) SELECT 'LL'; INSERT INTO tblDigram (digram) SELECT 'NA'
INSERT INTO tblDigram (digram) SELECT 'CT'; INSERT INTO tblDigram (digram) SELECT 'OU'
INSERT INTO tblDigram (digram) SELECT 'FO'; INSERT INTO tblDigram (digram) SELECT 'FI'
INSERT INTO tblDigram (digram) SELECT 'OL'; INSERT INTO tblDigram (digram) SELECT 'TU'
INSERT INTO tblDigram (digram) SELECT 'IT'; INSERT INTO tblDigram (digram) SELECT 'IL'
INSERT INTO tblDigram (digram) SELECT 'NO'; INSERT INTO tblDigram (digram) SELECT 'EV'
INSERT INTO tblDigram (digram) SELECT 'DA'; INSERT INTO tblDigram (digram) SELECT 'ES'
INSERT INTO tblDigram (digram) SELECT 'NE'; INSERT INTO tblDigram (digram) SELECT 'TO'
INSERT INTO tblDigram (digram) SELECT 'IE'; INSERT INTO tblDigram (digram) SELECT 'AM'
INSERT INTO tblDigram (digram) SELECT 'ST'; INSERT INTO tblDigram (digram) SELECT 'LA'
INSERT INTO tblDigram (digram) SELECT 'PE'; INSERT INTO tblDigram (digram) SELECT 'MI'
INSERT INTO tblDigram (digram) SELECT 'CI'; INSERT INTO tblDigram (digram) SELECT 'OR'
INSERT INTO tblDigram (digram) SELECT 'TA'; INSERT INTO tblDigram (digram) SELECT 'AS'
INSERT INTO tblDigram (digram) SELECT 'NG'; INSERT INTO tblDigram (digram) SELECT 'SU'
INSERT INTO tblDigram (digram) SELECT 'NT'; INSERT INTO tblDigram (digram) SELECT 'EL'
INSERT INTO tblDigram (digram) SELECT 'WA'; INSERT INTO tblDigram (digram) SELECT 'PL'
INSERT INTO tblDigram (digram) SELECT 'BL'; INSERT INTO tblDigram (digram) SELECT 'HI'
INSERT INTO tblDigram (digram) SELECT 'ME'; INSERT INTO tblDigram (digram) SELECT 'UR'
INSERT INTO tblDigram (digram) SELECT 'IV'; INSERT INTO tblDigram (digram) SELECT 'OF'

IF EXISTS (SELECT * FROM sysobjects WHERE name = 'tblTrigram' AND xtype = 'U')
	DROP TABLE tblTrigram
GO

-- Table of the 98 most common English language Trigrams
CREATE TABLE tblTrigram(
	trigramID INT IDENTITY (1, 1),
	trigram CHAR(3)
	)

INSERT INTO tblTrigram (trigram) SELECT 'THE'; INSERT INTO tblTrigram (trigram) SELECT 'CON'
INSERT INTO tblTrigram (trigram) SELECT 'UND'; INSERT INTO tblTrigram (trigram) SELECT 'DIN'
INSERT INTO tblTrigram (trigram) SELECT 'SAN'; INSERT INTO tblTrigram (trigram) SELECT 'ING'
INSERT INTO tblTrigram (trigram) SELECT 'NCE'; INSERT INTO tblTrigram (trigram) SELECT 'INT'
INSERT INTO tblTrigram (trigram) SELECT 'STI'; INSERT INTO tblTrigram (trigram) SELECT 'STE'
INSERT INTO tblTrigram (trigram) SELECT 'AND'; INSERT INTO tblTrigram (trigram) SELECT 'ALL'
INSERT INTO tblTrigram (trigram) SELECT 'ANT'; INSERT INTO tblTrigram (trigram) SELECT 'NOT'
INSERT INTO tblTrigram (trigram) SELECT 'ANY'; INSERT INTO tblTrigram (trigram) SELECT 'ION'
INSERT INTO tblTrigram (trigram) SELECT 'EVE'; INSERT INTO tblTrigram (trigram) SELECT 'HOU'
INSERT INTO tblTrigram (trigram) SELECT 'ORT'; INSERT INTO tblTrigram (trigram) SELECT 'ART'
INSERT INTO tblTrigram (trigram) SELECT 'ENT'; INSERT INTO tblTrigram (trigram) SELECT 'ITH'
INSERT INTO tblTrigram (trigram) SELECT 'MEN'; INSERT INTO tblTrigram (trigram) SELECT 'THO'
INSERT INTO tblTrigram (trigram) SELECT 'NTE'; INSERT INTO tblTrigram (trigram) SELECT 'FOR'
INSERT INTO tblTrigram (trigram) SELECT 'TED'; INSERT INTO tblTrigram (trigram) SELECT 'WAS'
INSERT INTO tblTrigram (trigram) SELECT 'DAY'; INSERT INTO tblTrigram (trigram) SELECT 'RAT'
INSERT INTO tblTrigram (trigram) SELECT 'TIO'; INSERT INTO tblTrigram (trigram) SELECT 'AIN'
INSERT INTO tblTrigram (trigram) SELECT 'OUN'; INSERT INTO tblTrigram (trigram) SELECT 'ORE'
INSERT INTO tblTrigram (trigram) SELECT 'TUR'; INSERT INTO tblTrigram (trigram) SELECT 'ERE'
INSERT INTO tblTrigram (trigram) SELECT 'EST'; INSERT INTO tblTrigram (trigram) SELECT 'PRO'
INSERT INTO tblTrigram (trigram) SELECT 'BUT'; INSERT INTO tblTrigram (trigram) SELECT 'ICA'
INSERT INTO tblTrigram (trigram) SELECT 'HER'; INSERT INTO tblTrigram (trigram) SELECT 'MAN'
INSERT INTO tblTrigram (trigram) SELECT 'STA'; INSERT INTO tblTrigram (trigram) SELECT 'OUT'
INSERT INTO tblTrigram (trigram) SELECT 'ICH'; INSERT INTO tblTrigram (trigram) SELECT 'ATE'
INSERT INTO tblTrigram (trigram) SELECT 'RED'; INSERT INTO tblTrigram (trigram) SELECT 'INE'
INSERT INTO tblTrigram (trigram) SELECT 'URE'; INSERT INTO tblTrigram (trigram) SELECT 'NDE'
INSERT INTO tblTrigram (trigram) SELECT 'VER'; INSERT INTO tblTrigram (trigram) SELECT 'THI'
INSERT INTO tblTrigram (trigram) SELECT 'WHI'; INSERT INTO tblTrigram (trigram) SELECT 'STR'
INSERT INTO tblTrigram (trigram) SELECT 'PRE'; INSERT INTO tblTrigram (trigram) SELECT 'TER'
INSERT INTO tblTrigram (trigram) SELECT 'IVE'; INSERT INTO tblTrigram (trigram) SELECT 'OVE'
INSERT INTO tblTrigram (trigram) SELECT 'TIC'; INSERT INTO tblTrigram (trigram) SELECT 'ENC'
INSERT INTO tblTrigram (trigram) SELECT 'THA'; INSERT INTO tblTrigram (trigram) SELECT 'REA'
INSERT INTO tblTrigram (trigram) SELECT 'TIN'; INSERT INTO tblTrigram (trigram) SELECT 'AME'
INSERT INTO tblTrigram (trigram) SELECT 'HAS'; INSERT INTO tblTrigram (trigram) SELECT 'ATI'
INSERT INTO tblTrigram (trigram) SELECT 'WIT'; INSERT INTO tblTrigram (trigram) SELECT 'AST'
INSERT INTO tblTrigram (trigram) SELECT 'COM'; INSERT INTO tblTrigram (trigram) SELECT 'WHE'
INSERT INTO tblTrigram (trigram) SELECT 'HAT'; INSERT INTO tblTrigram (trigram) SELECT 'ONS'
INSERT INTO tblTrigram (trigram) SELECT 'DER'; INSERT INTO tblTrigram (trigram) SELECT 'OUR'
INSERT INTO tblTrigram (trigram) SELECT 'WIL'; INSERT INTO tblTrigram (trigram) SELECT 'ERS'
INSERT INTO tblTrigram (trigram) SELECT 'ESS'; INSERT INTO tblTrigram (trigram) SELECT 'OUS'
INSERT INTO tblTrigram (trigram) SELECT 'WER'; INSERT INTO tblTrigram (trigram) SELECT 'ERA'
INSERT INTO tblTrigram (trigram) SELECT 'HIS'; INSERT INTO tblTrigram (trigram) SELECT 'AVE'
INSERT INTO tblTrigram (trigram) SELECT 'ROM'; INSERT INTO tblTrigram (trigram) SELECT 'OME'
INSERT INTO tblTrigram (trigram) SELECT 'LIN'; INSERT INTO tblTrigram (trigram) SELECT 'RES'
INSERT INTO tblTrigram (trigram) SELECT 'PER'; INSERT INTO tblTrigram (trigram) SELECT 'VEN'
INSERT INTO tblTrigram (trigram) SELECT 'EEN'; INSERT INTO tblTrigram (trigram) SELECT 'TRA'
INSERT INTO tblTrigram (trigram) SELECT 'ILL'; INSERT INTO tblTrigram (trigram) SELECT 'ECT'
INSERT INTO tblTrigram (trigram) SELECT 'ARD'; INSERT INTO tblTrigram (trigram) SELECT 'LAR'
INSERT INTO tblTrigram (trigram) SELECT 'ARE'; INSERT INTO tblTrigram (trigram) SELECT 'ONE'
INSERT INTO tblTrigram (trigram) SELECT 'EAR'; INSERT INTO tblTrigram (trigram) SELECT 'LES'

IF EXISTS (SELECT * FROM sysobjects WHERE name = 'fnObfuscate' AND xtype IN ('FN', 'IF', 'TF'))
	DROP FUNCTION fnObfuscate
GO

CREATE FUNCTION fnObfuscate(
	@inputWord VARCHAR(128)
)
RETURNS VARCHAR(128)
AS
BEGIN

	DECLARE @charIndex SMALLINT
	DECLARE @trigramID SMALLINT, @digramID SMALLINT, @letterID SMALLINT
	DECLARE @outputWord VARCHAR(128)

	SET @charIndex = 1
	SET @outputWord = ''
	-- Trigram Replace
	WHILE @charIndex <= LEN (@inputWord)
	BEGIN
		SELECT @trigramID = ISNULL(trigramID, 0) FROM tblTrigram WHERE trigram = SUBSTRING(@inputWord, @charIndex, 3)
		IF @trigramID != 0
		BEGIN
			IF @trigramID = 98 SET @trigramID = 1 ELSE SET @trigramID = @trigramID + 1

			SELECT @outputWord = @outputWord + trigram FROM tblTrigram WHERE trigramID = @trigramID

			-- Remove Trigram From input word
			SELECT @inputWord = REPLACE(@inputWord, SUBSTRING(@inputWord, @charIndex, 3), '???')
			-- Skip Rest of Trigram
			SELECT @charIndex = @charIndex + 2 


		END
		ELSE
			SET @outputWord = @outputWord + '?' -- PlaceHolder

		SET @trigramID = 0
		SET @charIndex = @charIndex + 1
	END
	
	SET @charIndex = 1

	-- Digram Replace
	WHILE @charIndex <= LEN (@inputWord)
	BEGIN
		SELECT @digramID = ISNULL(digramID, 0) FROM tblDigram WHERE digram = SUBSTRING(@inputWord, @charIndex, 2)
		IF @digramID != 0
		BEGIN
			IF @digramID = 100 SET @digramID = 1 ELSE SET @digramID = @digramID + 1

			SELECT @outputWord = STUFF(@outputWord, @charIndex, 2, digram) FROM tblDigram WHERE digramID = @digramID
			-- Remove digram From input word
			SELECT @inputWord = REPLACE(@inputWord, SUBSTRING(@inputWord, @charIndex, 2), '??')
			-- Skip Rest of Digram
			SELECT @charIndex = @charIndex + 1
		END

		SET @digramID = 0
		SET @charIndex = @charIndex + 1
	END

	SET @charIndex = 1


	-- Letter Replace
	WHILE @charIndex <= LEN (@inputWord)
	BEGIN
		IF SUBSTRING(@inputWord, @charIndex, 1) != '?' AND SUBSTRING(@inputWord, @charIndex, 1) != ' '
			SELECT @outputWord = CASE 
					WHEN ASCII(SUBSTRING(@inputWord, @charIndex, 1)) + 1 <90 
						THEN STUFF(@outputWord, @charIndex, 1, CHAR(ASCII(SUBSTRING(@inputWord, @charIndex, 1)) + 1))
						ELSE STUFF(@outputWord, @charIndex, 1, 'A') END

		SET @charIndex = @charIndex + 1
	END

	-- Replace spaces back in to word/phrase
	SET @outputWord = REPLACE(@outputWord, '?', ' ')

	RETURN @outputWord

END
GO

SELECT dbo.fnObfuscate('William Mitchell')