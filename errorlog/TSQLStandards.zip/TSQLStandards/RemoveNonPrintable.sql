--===== Build a function using "Stuff"
 CREATE FUNCTION dbo.RemoveNonPrintable
     -- Modified by Jeff Moden
        (@String VARCHAR(8000))
RETURNS VARCHAR(8000) AS
  BEGIN
DECLARE @IncorrectCharLoc SMALLINT,
        @Pattern          CHAR(7)

 SELECT @Pattern = '%[-AE]%',
        @IncorrectCharLoc = PATINDEX(@Pattern, @String)

  WHILE @IncorrectCharLoc > 0
 SELECT @string = STUFF(@String, @IncorrectCharLoc, 1, ''),
        @IncorrectCharLoc = PATINDEX(@Pattern, @String)
 RETURN @string
    END
GO