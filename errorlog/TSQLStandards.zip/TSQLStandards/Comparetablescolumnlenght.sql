SELECT * into [name] ,
[column_id],
[system_type_id] ,
[user_type_id]  ,
[max_length] ,
[precision]   ,
[scale]  FROM sys.columns WHERE name =staging_tbl
EXCEPT
SELECT * into [name] ,
[column_id],
[system_type_id] ,
[user_type_id]  ,
[max_length] ,
[precision]   ,
[scale]  FROM <LinkedServer>.<db1>.sys.columns WHERE name ='table'