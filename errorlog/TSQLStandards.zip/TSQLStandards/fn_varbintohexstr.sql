CREATE FUNCTION dbo.fn_varbintohexstr 
/*****************************************************************************************
 Purpose:
 Replacement for undocumented Master.sys.fn_varbintohexstr function.

 Can probably be created as "sys.fn_varbintohexstr" instead of "dbo.fn_varbintohexstr"
 to create a direct replacement that requires no changes to code.  Just need to grant
 privs to the public to use it.

 Revision History:
 Rev 00 - 03 Mar 2010 - Initial creation and test
*****************************************************************************************/
        (@pbinin VARBINARY(MAX))
RETURNS TABLE AS
RETURN ( --======= Nested CTE provides base numbers from 1 to 10E16.
         WITH E1(N) AS (SELECT 1 UNION ALL SELECT 1 UNION ALL
                        SELECT 1 UNION ALL SELECT 1 UNION ALL 
                        SELECT 1 UNION ALL SELECT 1 UNION ALL 
                        SELECT 1 UNION ALL SELECT 1 UNION ALL
                        SELECT 1 UNION ALL SELECT 1),--10
              E2(N) AS (SELECT 1 FROM E1 a, E1 b),   --100
              E4(N) AS (SELECT 1 FROM E2 a, E2 b),   --10,000
              E8(N) AS (SELECT 1 FROM E4 a, E4 b),   --100,000,000
             E16(N) AS (SELECT 1 FROM E8 a, E8 b),   --10,000,000,000,000,000
        cteTally(N) AS (SELECT ROW_NUMBER() OVER (ORDER BY N) FROM E16)
         SELECT '0x'
              + ( --=== Converts at the character level and concatenates result
                 SELECT SUBSTRING('0123456789abcdef',SUBSTRING(@pbinin, t.N,1)/16+1,1)
                      + SUBSTRING('0123456789abcdef',SUBSTRING(@pbinin, t.N,1)%16+1,1)
                   FROM cteTally t
                  WHERE t.N <= LEN(@pbinin)
                  FOR XML PATH('')
                ) AS HexString
        )
;
