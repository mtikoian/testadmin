/* 20111009 is a Sunday */
SET LANGUAGE us_english ;

SELECT
	@@LANGUAGE AS language_setting,
    DATEPART(weekday, '20111009') AS weekday_number,
    DATENAME(weekday, '20111009') AS weekday_name;

DECLARE @StartDate DATE
DECLARE @DaysOut TINYINT
DECLARE @DesiredDayOfWeek TINYINT
SET @StartDate = '20111009'
 --The starting date
SET @DaysOut = 4
 --Number of days to count out (the Desired day is AFTER this count)
SET @DesiredDayOfWeek = 6
 --The desired day of week

SELECT
    DATEADD(d,
            (@DaysOut + (7 - (7 + DATEPART(weekday,
                                           DATEADD(d, @DaysOut, @StartDate)) -
                              @DesiredDayOfWeek)) % 7), @StartDate)

Go 
SET LANGUAGE italian

SELECT
    @@LANGUAGE AS language_setting,
    DATEPART(weekday, '20111009') AS weekday_number,
    DATENAME(weekday, '20111009') AS weekday_name;

DECLARE @StartDate DATE
DECLARE @DaysOut TINYINT
DECLARE @DesiredDayOfWeek TINYINT
SET @StartDate = '20111009'
 --The starting date
SET @DaysOut = 4
 --Number of days to count out (the Desired day is AFTER this count)
SET @DesiredDayOfWeek = 6
 --The desired day of week

SELECT
    DATEADD(d,
            (@DaysOut + (7 - (7 + DATEPART(weekday,
                                           DATEADD(d, @DaysOut, @StartDate)) -
                              @DesiredDayOfWeek)) % 7), @StartDate)



--

DECLARE @StartDate date
DECLARE @DaysOut tinyint
DECLARE @DesiredDayOfWeek tinyint
DECLARE @TargetDate date
DECLARE @MaxDays int

SET @StartDate = '20111013' --The starting date
SET @DaysOut = 1 --Number of days to count out (the Desired day is AFTER this count)
SET @DesiredDayOfWeek = 6 --The desired day of week
SET @TargetDate = dateadd(dd,@DaysOut,@StartDate)
SET @MaxDays = @DaysOut + @DesiredDayOfWeek + 1 --Tally Table row count limiter

;WITH
  L0   AS(SELECT 1 AS c UNION ALL SELECT 1),
  L1   AS(SELECT 1 AS c FROM L0 AS A CROSS JOIN L0 AS B),
  L2   AS(SELECT 1 AS c FROM L1 AS A CROSS JOIN L1 AS B),
  L3   AS(SELECT 1 AS c FROM L2 AS A CROSS JOIN L2 AS B),
  L4   AS(SELECT 1 AS c FROM L3 AS A CROSS JOIN L3 AS B),
  L5   AS(SELECT 1 AS c FROM L4 AS A CROSS JOIN L4 AS B),
  Nums AS(SELECT ROW_NUMBER() OVER(ORDER BY (SELECT NULL)) AS N FROM L5) 
SELECT TOP(1) @TargetDate = dateadd(dd,Tally_Table.N,@TargetDate)
FROM (SELECT TOP(@MaxDays) N FROM Nums ORDER BY N) AS Tally_Table
WHERE datepart(dw,dateadd(dd,Tally_Table.N,@TargetDate)) = @DesiredDayOfWeek

SELECT @TargetDate