--===== Conditionally drop temp tables to make reruns easier
     IF OBJECT_ID('TempDB..#FileList','U') IS NOT NULL
        DROP TABLE #FileList

--===== Create the working temp table with a couple of calculated columns to isolate the extention
     -- and just the file name.
 CREATE TABLE #FileList
        (
        FullFileName SYSNAME,
        Level TINYINT,
        IsFile TINYINT,
        FileName AS SUBSTRING(FullFileName,1,LEN(FullFileName)-CHARINDEX('.',REVERSE(FullFileName))),
        Extension AS RIGHT(FullFileName,CHARINDEX('.',REVERSE(FullFileName)))
        )

--===== Populate the table with file names from the given directory or UNC
     -- (YES, you CAN convert this section to dynamic SQL if you need to)
 INSERT INTO #FileList
        (FullFileName, Level, IsFile)
   EXEC xp_DirTree 'C:\Temp',1,1  --<<<<Change to the desired directory here

--===== Ok... let see what that has in it.  Not part of the problem but thought you should see it.
SELECT * FROM #FileList

--===== And finally, list all filenames that have a .txt extension but DON'T have a .PDF extension
 SELECT FileName FROM #FileList WHERE Extension = '.txt' AND IsFile = 1
 EXCEPT 
 SELECT FileName FROM #FileList WHERE Extension = '.pdf' AND IsFile = 1