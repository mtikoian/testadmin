--https://www.sqlservercentral.com/Forums/488867/Index-Implementation-Question?PageIndex=2
SET STATISTICS IO ON
GO
SET STATISTICS TIME ON
GO

CREATE TABLE TestingIndexOrder (
 ID INT IDENTITY,
 DayOfWeek smallint,
 CustomerKey int
)
GO

insert INTO TestingIndexOrder (DayOfWeek, CustomerKey)
SELECT DATEPART(dw,DATEADD(dd,number, '1900/01/01')), FLOOR(RAND(number*5452)*1000)
FROM (
SELECT TOP 4000000 v1.number, v1.number + v2.number AS Num 
 FROM master..spt_values v1, master..spt_values v2 WHERE v1.name is NULL AND v2.name IS null
UNION ALL
SELECT TOP 4000000 v1.number, v1.number + v2.number AS Num 
 FROM master..spt_values v1, master..spt_values v2 WHERE v1.name is NULL AND v2.name IS null 
UNION ALL
SELECT TOP 2000000 v1.number, v1.number + v2.number AS Num  
 FROM master..spt_values v1, master..spt_values v2 WHERE v1.name is NULL AND v2.name IS null ) x

GO

CREATE INDEX idx_test1 ON TestingIndexOrder (DayOfWeek, CustomerKey)
GO

SELECT DayOfWeek, CustomerKey FROM TestingIndexOrder WHERE  DayOfWeek =3 AND CustomerKey = 504
/*
(4096 row(s) affected)
Table 'TestingIndexOrder'. Scan count 1, logical reads 14, physical reads 0, read-ahead reads 0

SQL Server Execution Times:
   CPU time = 0 ms,  elapsed time = 121 ms.
*/

DROP INDEX idx_test1 ON TestingIndexOrder
CREATE INDEX idx_test2 ON TestingIndexOrder (CustomerKey, DayOfWeek)
GO

SELECT DayOfWeek, CustomerKey FROM TestingIndexOrder WHERE  DayOfWeek =3 AND CustomerKey = 504
/*
(4096 row(s) affected)
Table 'TestingIndexOrder'. Scan count 1, logical reads 14, physical reads 0, read-ahead reads 0

SQL Server Execution Times:
   CPU time = 0 ms,  elapsed time = 123 ms.
*/

DROP TABLE TestingIndexOrder