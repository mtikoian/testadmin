CREATE FUNCTION dbo.IsAllDigits 
/********************************************************************
 Purpose:
 This function will return a 1 if the string parameter contains only 
 numeric digits and will return a 0 in all other cases.

 --Jeff Moden
********************************************************************/
--===== Declare the I/O parameters
        (@MyString VARCHAR(8000))
RETURNS INT
     AS
  BEGIN
         RETURN (SELECT CASE 
                          WHEN @MyString NOT LIKE '%[^0-9]%'
                          THEN 1
                          ELSE 0
                        END)
    END