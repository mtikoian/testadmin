 CREATE FUNCTION dbo.GetDOWCount
        (
        @StartDate DATETIME,
        @EndDate DATETIME,
        @DOW INT -- 1,2,3,4,5,6, or 7 and is DateFirst sensitive
        )
RETURNS INT
     AS
  BEGIN
 RETURN (SELECT COUNT(*)
           FROM dbo.Tally t
          WHERE t.N <= DATEDIFF(dd,@StartDate,@EndDate)+1
            AND DATEPART(dw,t.N+@StartDate-1) = @Dow)
    END