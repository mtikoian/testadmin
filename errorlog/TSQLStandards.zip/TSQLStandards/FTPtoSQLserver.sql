declare @strPath varchar(2000);
declare @strDataFile varchar(2000);
declare @strCmd varchar(2000);
declare @scriptName varchar(100);

SET @strCmd = 'if exist ' + @strPath + '\script.ftp del ' + @strPath + '\script.ftp';
EXECUTE master..xp_cmdshell @strCmd;


 SET @strPath = 'E:\Download';
  SET @strDataFile = 'ImportData.txt';

  SET @strCmd = 'echo ftp_user_name>' + @strPath + '\script.ftp&' +
                'echo ftp_password>>' + @strPath + '\script.ftp&' +
                'echo bin>>' + @strPath + '\script.ftp & ' +
                'echo prompt n>>' + @strPath + '\script.ftp & ' +
                'echo lcd ' + @strPath + '>>' + @strPath + '\script.ftp & ' +
                'echo cd /Inbox >>' + @strPath + '\script.ftp & ' +
                'echo get ' + @strDataFile + '>> ' + @strPath + '\script.ftp & ' +
                'echo quit>>' + @strPath + '\script.ftp'
  EXECUTE master..xp_cmdshell @strCmd;

  --shell out to the ftp script we just created
  SET @strCmd = 'ftp.exe -v -s:' + @strPath + '\' + 'script.ftp some_ftp_server.com';
  EXECUTE master..xp_cmdshell @strCmd;