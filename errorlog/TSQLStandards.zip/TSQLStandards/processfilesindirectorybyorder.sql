CREATE TABLE #Files
        (
        RowNum INT IDENTITY(1,1),
        FileObject VARCHAR(500),
        Depth SMALLINT,
        IsFile BIT
        )
;
 INSERT INTO #Files
        (FileObject,Depth,IsFile)
   EXEC xp_DirTree 'C:\Temp',1,1
;
WITH
cteEnumerateExt AS
(
 SELECT FileObject,
        SortOrder = DENSE_RANK() OVER (ORDER BY SUBSTRING(FileObject,CHARINDEX('.',FileObject)+1,500) DESC)
   FROM #Files
  WHERE ISDATE(SUBSTRING(FileObject,CHARINDEX('.',FileObject)+1,500)) = 1
    AND IsFile = 1
)
 SELECT FileObject
   FROM cteEnumerateExt
  WHERE SortOrder = 1
;