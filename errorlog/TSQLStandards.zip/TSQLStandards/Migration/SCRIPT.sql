USE master;
GO
SET NOCOUNT ON
IF OBJECT_ID( 'tempdb.dbo.#tmp' ) IS NOT NULL DROP TABLE #tmp;
 
DECLARE
@SQLcmd VARCHAR(MAX)
,@DatabaseName VARCHAR(255)
,@PrevDatabaseName VARCHAR(255);
 
SET @SQLcmd = '';
SET @DatabaseName = ';';
SET @PrevDatabaseName = '';
 
CREATE TABLE #tmp (
DatabaseName SYSNAME NULL
,FileId INT NULL
,FileName VARCHAR(2000) NULL
,SQLcmd VARCHAR(MAX) NULL
);
 
INSERT  INTO #tmp
SELECT DISTINCT
DB_NAME(dbid) AS DatabaseName
,FileId
,FileName
,CONVERT(VARCHAR(MAX), '') AS SQLcmd
FROM master.dbo.sysaltfiles
WHERE dbid IN (
SELECT dbid FROM master.dbo.sysaltfiles )
 
--SUBSTRING(FileName, 1, 1) IN ( 'G', 'F' ) )  -- Put the appropriate drives here
--AND DATABASEPROPERTYEX(DB_NAME(dbid), 'Status') = 'ONLINE'
AND DB_NAME(dbid) NOT IN ( 'master', 'model', 'msdb', 'tempdb', 'ditribution' )
ORDER BY DatabaseName, FileId, FileName;
 
UPDATE #tmp SET
@SQLcmd = SQLcmd = CASE WHEN DatabaseName <> @PrevDatabaseName
THEN CONVERT(VARCHAR(200), 'exec sp_attach_db @DBName = N''' + DatabaseName + '''')
ELSE @SQLcmd
END + ',@FileName' + CONVERT(VARCHAR(10), FileId) + '=N''' + FileName + ''''
,@PrevDatabaseName = CASE WHEN DatabaseName <> @PrevDatabaseName THEN DatabaseName
ELSE @PrevDatabaseName
END
,@DatabaseName = DatabaseName
FROM #tmp;
 
SELECT
'USE master;' + CHAR(13) + CHAR(10) + 'GO'
SELECT
SQLcmd
FROM
( SELECT DatabaseName, MAX(SQLcmd) AS SQLcmd
FROM #tmp
GROUP BY DatabaseName
) AS SQLcmd;
 
--DROP TABLE #tmp
GO