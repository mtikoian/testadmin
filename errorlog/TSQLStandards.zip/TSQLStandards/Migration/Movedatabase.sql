-- Define the drives you wish to move the data files to. Do not put '\' on the end.
DECLARE	 @systemDBData		VARCHAR(100) = 'G:\MSSQL\SYSTEM_DATA'
	,@systemDBLog		VARCHAR(100) = 'F:\MSSQL\SYSTEM_LOG'
	,@tempDBData		VARCHAR(100) = 'E:\MSSQL\TEMPDB_DATA'
	,@tempDBLog		VARCHAR(100) = 'E:\MSSQL\TEMPDB_LOG' 
	,@userDBData		VARCHAR(100) = 'G:\MSSQL\USER_DATA'
	,@userDBLog		VARCHAR(100) = 'F:\MSSQL\USER_LOG'
	
	DECLARE	 @fromDrive		TABLE(Drive CHAR(1))
--Insert the Drive(s) You want to check for database files
INSERT INTO @fromDrive (Drive) VALUES ('C'),('D'),('E'),('F'),('G'),('I'),('M')

IF OBJECT_ID( 'dbo.MOVE_Servername_Log' ) IS NOT NULL DROP TABLE dbo.MOVE_Servername_Log
SELECT
masterFiles.database_id,
masterFiles.FILE_ID,
db.name AS DatabaseName,
masterFiles.name AS FileName,
RIGHT(masterFiles.physical_name,CHARINDEX('\',REVERSE(masterFiles.physical_name))-1) AS PhysFileName,
masterFiles.physical_name AS OriginalLocation,
LEFT(masterFiles.physical_name,LEN(masterFiles.physical_name) - CHARINDEX('\',REVERSE(masterFiles.physical_name))) AS OriginalDir,
CASE
WHEN masterFiles.type_desc = 'ROWS' AND db.name IN('master', 'model', 'msdb', 'distribution')
THEN @systemDBData + '\' +
RIGHT(masterFiles.physical_name,CHARINDEX('\',REVERSE(masterFiles.physical_name))-1)
WHEN masterFiles.type_desc = 'LOG' AND db.name IN('master', 'model', 'msdb', 'distribution')
THEN @systemDBLog + '\' +
RIGHT(masterFiles.physical_name,CHARINDEX('\',REVERSE(masterFiles.physical_name))-1)
WHEN masterFiles.type_desc = 'ROWS' AND db.name = 'tempdb'
THEN @tempDBData + '\' +
RIGHT(masterFiles.physical_name,CHARINDEX('\',REVERSE(masterFiles.physical_name))-1)
WHEN masterFiles.type_desc = 'LOG' AND db.name = 'tempdb'
THEN @tempDBLog + '\' +
RIGHT(masterFiles.physical_name,CHARINDEX('\',REVERSE(masterFiles.physical_name))-1)
WHEN masterFiles.type_desc = 'ROWS'
THEN @userDBData + '\' +
RIGHT(masterFiles.physical_name,CHARINDEX('\',REVERSE(masterFiles.physical_name))-1)
ELSE @userDBLog  + '\' +
RIGHT(masterFiles.physical_name,CHARINDEX('\',REVERSE(masterFiles.physical_name))-1)
END AS NewLocation,
CASE
WHEN masterFiles.type_desc = 'ROWS' AND db.name IN('master', 'model', 'msdb', 'distribution')
THEN @systemDBData
WHEN masterFiles.type_desc = 'LOG' AND db.name IN('master', 'model', 'msdb', 'distribution')
THEN @systemDBLog
WHEN masterFiles.type_desc = 'ROWS' AND db.name = 'tempdb' THEN @tempDBData
WHEN masterFiles.type_desc = 'LOG' AND db.name = 'tempdb' THEN @tempDBLog
WHEN masterFiles.type_desc = 'ROWS' THEN @userDBData
ELSE @userDBLog
END AS NewLocationDir,
masterFiles.type_desc AS FileType,
masterFiles.size * 8 / 1024 AS Size_MB,
fdrv.Drive AS FromDrive,
' ' AS ToDrive,
CASE
WHEN DATABASEPROPERTY(db.name,'isReadOnly') = 1 THEN 'isReadOnly'
WHEN DATABASEPROPERTY(db.name,'isOffline') = 1 THEN 'isOffline'
WHEN DATABASEPROPERTY(db.name,'isSuspect') = 1 THEN 'isSuspect'
WHEN DATABASEPROPERTY(db.name,'isInRecovery') = 1 THEN 'isInRecovery'
WHEN DATABASEPROPERTY(db.name,'isInLoad') = 1 THEN 'isInLoad'
WHEN DATABASEPROPERTY(db.name,'isNotRecovered') = 1 THEN 'isNotRecovered'
ELSE 'isAvailable'
END AS DatabaseAvailable
INTO dbo.MOVE_Servername_Log
FROM sys.master_files masterFiles
JOIN sys.sysdatabases db ON masterFiles.database_id = db.dbid
JOIN @fromDrive fdrv ON LEFT(masterFiles.physical_name, 1) = fdrv.Drive
ORDER BY masterFiles.name
UPDATE dbo.MOVE_Servername_Log SET ToDrive = LEFT(NewLocation,1)
IF OBJECT_ID( 'dbo.MOVE_Servername_Log' ) IS NOT NULL DROP TABLE dbo.MOVE_Servername_Log
SELECT
    masterFiles.database_id,
    masterFiles.file_id, 
    db.name AS DatabaseName,
    masterFiles.name AS FileName, 
    RIGHT(masterFiles.physical_name,CHARINDEX('\',REVERSE(masterFiles.physical_name))-1) AS PhysFileName,
    masterFiles.physical_name AS OriginalLocation,
    LEFT(masterFiles.physical_name,LEN(masterFiles.physical_name) -
        CHARINDEX('\',REVERSE(masterFiles.physical_name))) AS OriginalDir,
    CASE 
        WHEN masterFiles.type_desc = 'ROWS' AND db.name IN ('master', 'model', 'msdb', 'distribution')
            THEN @systemDBData + '\' + 
            RIGHT(masterFiles.physical_name,CHARINDEX('\',REVERSE(masterFiles.physical_name))-1)
        WHEN masterFiles.type_desc = 'LOG' AND db.name IN ('master', 'model', 'msdb', 'distribution')
            THEN @systemDBLog + '\' + 
             RIGHT(masterFiles.physical_name,CHARINDEX('\',REVERSE(masterFiles.physical_name))-1)
        WHEN masterFiles.type_desc = 'ROWS' AND db.name = 'tempdb'
            THEN @tempDBData + '\' + 
            RIGHT(masterFiles.physical_name,CHARINDEX('\',REVERSE(masterFiles.physical_name))-1)
        WHEN masterFiles.type_desc = 'LOG' AND db.name = 'tempdb'
            THEN @tempDBLog + '\' + 
            RIGHT(masterFiles.physical_name,CHARINDEX('\',REVERSE(masterFiles.physical_name))-1)
        WHEN masterFiles.type_desc = 'ROWS'
            THEN @userDBData + '\' + 
            RIGHT(masterFiles.physical_name,CHARINDEX('\',REVERSE(masterFiles.physical_name))-1) 
        ELSE @userDBLog  + '\' + 
            RIGHT(masterFiles.physical_name,CHARINDEX('\',REVERSE(masterFiles.physical_name))-1) 
    END AS NewLocation,
    CASE 
        WHEN masterFiles.type_desc = 'ROWS' AND db.name IN ('master', 'model', 'msdb', 'distribution') 
            THEN @systemDBData
        WHEN masterFiles.type_desc = 'LOG' AND db.name IN ('master', 'model', 'msdb', 'distribution')
            THEN @systemDBLog
        WHEN masterFiles.type_desc = 'ROWS' AND db.name = 'tempdb' THEN @tempDBData
        WHEN masterFiles.type_desc = 'LOG' AND db.name = 'tempdb' THEN @tempDBLog
        WHEN masterFiles.type_desc = 'ROWS' THEN @userDBData
        ELSE @userDBLog
    END AS NewLocationDir,
    masterFiles.type_desc AS FileType, 
    masterFiles.size * 8 / 1024 AS Size_MB,
    fdrv.Drive AS FromDrive, 
   ' ' AS ToDrive,
    CASE
        WHEN DATABASEPROPERTY(db.name,'isReadOnly') = 1 THEN 'isReadOnly'
        WHEN DATABASEPROPERTY(db.name,'isOffline') = 1 THEN 'isOffline'
        WHEN DATABASEPROPERTY(db.name,'isSuspect') = 1 THEN 'isSuspect'
        WHEN DATABASEPROPERTY(db.name,'isInRecovery') = 1 THEN 'isInRecovery'
        WHEN DATABASEPROPERTY(db.name,'isInLoad') = 1 THEN 'isInLoad'
        WHEN DATABASEPROPERTY(db.name,'isNotRecovered') = 1 THEN 'isNotRecovered'
        ELSE 'isAvailable'
    END AS DatabaseAvailable
INTO dbo.MOVE_Servername_Log
FROM sys.master_files masterFiles
JOIN sys.sysdatabases db ON masterFiles.database_id = db.dbid
JOIN @fromDrive fdrv ON LEFT(masterFiles.physical_name, 1) = fdrv.Drive
ORDER BY masterFiles.name
UPDATE dbo.MOVE_Servername_Log SET ToDrive = LEFT(NewLocation,1)


-- Get disk space totals ----------------------------------------------------------
SELECT ToDrive, CASE FileType WHEN 'ROWS' THEN 'DATA' ELSE FileType END AS FileType, SUM(size_MB) AS MBPerDrive
    FROM dbo.MOVE_Servername_Log
    WHERE FromDrive != ToDrive
    GROUP BY ToDrive, FileType
UNION
SELECT ToDrive, 'All' AS FileType, SUM(size_MB) AS MBPerDrive
    FROM dbo.MOVE_Servername_Log
    WHERE FromDrive != ToDrive
    GROUP BY ToDrive
UNION
SELECT '---- Total' AS ToDrive, 'All' AS FileType, SUM(size_MB) AS MBPerDrive
    FROM dbo.MOVE_Servername_Log
    WHERE FromDrive != ToDrive
ORDER BY ToDrive DESC,FileType DESC


-- Get disk space totals ----------------------------------------------------------
SELECT ToDrive, CASE FileType WHEN 'ROWS' THEN 'DATA' ELSE FileType END AS FileType, SUM(size_MB) AS MBPerDrive
    FROM dbo.MOVE_Servername_Log
    WHERE FromDrive != ToDrive
    GROUP BY ToDrive, FileType
UNION
SELECT ToDrive, 'All' AS FileType, SUM(size_MB) AS MBPerDrive
    FROM dbo.MOVE_Servername_Log
    WHERE FromDrive != ToDrive
    GROUP BY ToDrive
UNION
SELECT '---- Total' AS ToDrive, 'All' AS FileType, SUM(size_MB) AS MBPerDrive
    FROM dbo.MOVE_Servername_Log
    WHERE FromDrive != ToDrive
ORDER BY ToDrive DESC,FileType DESC


-- Define the location and name of the robocopy log
DECLARE	 @robocopyLog		VARCHAR(100) = 'G:\MSSQL\robocopy.log'

-- Build System DB move script ------------------------------------------------------------------------
INSERT INTO ##Script(Sort,Script) VALUES (0,'--------- Begin System Database Move Script ---------------')
 
INSERT INTO ##Script(DatabaseName, Sort,Script)
    SELECT DISTINCT DatabaseName, 1,'    ALTER DATABASE ' +  QUOTENAME(DatabaseName) + ' MODIFY FILE (NAME = ' + FileName + ', FILENAME = ''' +  NewLocation + ''' )'
    FROM DBA.dbo.MOVE_Servername_Log
    WHERE OriginalLocation <> NewLocation
        AND DatabaseAvailable = 'isAvailable'
        AND database_id <= 4
 
INSERT INTO ##Script(Sort,Script) VALUES (2,'-----------------------------------------------------------')
INSERT INTO ##Script(Sort,Script) VALUES (3,'-- COPY Physical files. Run the following commands in a CMD window. Run as Administrator!')
INSERT INTO ##Script(Sort,Script) VALUES (4,'-----------------------------------------------------------')
INSERT INTO ##Script(DatabaseName, Sort, Script)
    SELECT DISTINCT DatabaseName, 5,'    robocopy "' 
        + OriginalDir + '" "' 
        + NewLocationDir + '" "' 
        + PhysFileName + '" /COPYALL /NJS /LOG+:"' 
        + @robocopyLog + '"'
    FROM DBA.dbo.MOVE_Servername_Log
    WHERE OriginalLocation <> NewLocation
        AND DatabaseAvailable = 'isAvailable'
        AND database_id <= 4
 
INSERT INTO ##Script(Sort,Script) VALUES (6,'------------------- End System Script ---------------------')
-- END Build User DB move script -----------------------------------------------------------------------
 
-- Build User DB move script ---------------------------------------------------------------------------
INSERT INTO ##Script(Sort,Script) VALUES (7,'------------ Begin User Database Move Script --------------')
 
INSERT INTO ##Script(DatabaseName, Sort,Script)
    SELECT DISTINCT DatabaseName, 8,'    ALTER DATABASE ' +  QUOTENAME(DatabaseName) + ' MODIFY FILE (NAME = [' + FileName + '], FILENAME = ''' +  NewLocation + ''' )'
    FROM DBA.dbo.MOVE_Servername_Log
    WHERE OriginalLocation <> NewLocation
        AND DatabaseAvailable = 'isAvailable'
        AND database_id > 4
 
INSERT INTO ##Script(DatabaseName, Sort,Script)
    SELECT DISTINCT DatabaseName, 8,'    ALTER DATABASE ' +  QUOTENAME(DatabaseName) + ' SET OFFLINE'
    FROM DBA.dbo.MOVE_Servername_Log
    WHERE OriginalLocation <> NewLocation
        AND DatabaseAvailable = 'isAvailable'
        AND database_id > 4
 
INSERT INTO ##Script(Sort,Script) VALUES (9,'-----------------------------------------------------------')
INSERT INTO ##Script(Sort,Script) VALUES (10,'-- COPY Physical files. Run the following commands in a CMD window. Run as Administrator!')
INSERT INTO ##Script(Sort,Script) VALUES (11,'----------------------------------------------------------')
INSERT INTO ##Script(DatabaseName, Sort, Script)
    SELECT DISTINCT DatabaseName, 12,'    robocopy "' 
        + OriginalDir + '" "' 
        + NewLocationDir + '" "' 
        + PhysFileName + '" /COPYALL /NJS /LOG+:"' 
        + @robocopyLog + '"'
    FROM DBA.dbo.MOVE_Servername_Log
    WHERE OriginalLocation <> NewLocation
        AND DatabaseAvailable = 'isAvailable'
        AND database_id > 4
 
INSERT INTO ##Script(Sort,Script) VALUES (13,'----------------------------------------------------------')
INSERT INTO ##Script(Sort,Script) VALUES (14,'-- Bring the databases back online.')
INSERT INTO ##Script(Sort,Script) VALUES (15,'----------------------------------------------------------')
INSERT INTO ##Script(DatabaseName, Sort, Script)
    SELECT DISTINCT DatabaseName, 16,'    ALTER DATABASE ' +  QUOTENAME(DatabaseName) + ' SET ONLINE'
    FROM DBA.dbo.MOVE_Servername_Log
    WHERE OriginalLocation <> NewLocation
        AND DatabaseAvailable = 'isAvailable'
        AND database_id > 4
 
INSERT INTO ##Script(Sort,Script) VALUES (17,'--------------------- End User Script --------------------')
-- END Build User DB move script -----------------------------------------------------------------------

SELECT Script
FROM ##Script
ORDER BY Sort, DatabaseName, Script