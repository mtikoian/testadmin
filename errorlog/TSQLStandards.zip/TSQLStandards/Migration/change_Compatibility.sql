SELECT
  d.name
,   tsql = CONCAT(
       'ALTER DATABASE ['
     , d.name
     , '] SET SINGLE_USER; ALTER DATABASE ['
     , d.name
     , '] SET Compatibility_level = 120; ALTER DATABASE ['
     , d.name
     , '] SET MULTI_USER;'
     )
FROM  sys.databases d
WHERE d.database_id > 4;


DECLARE 
    @DBName VARCHAR(100)
    ,@SQL nvarchar(200)

DECLARE CompatCursor CURSOR FOR

    SELECT NAME FROM master.dbo.sysdatabases
    WHERE NAME NOT IN('master', 'tempdb', 'model', 'msdb')

OPEN CompatCursor
    FETCH NEXT FROM CompatCursor INTO @DBName
  
WHILE @@FETCH_STATUS = 0
    BEGIN

        SET @SQL = 'ALTER DATABASE [' + @DBName + '] ' + 'SET SINGLE_USER WITH ROLLBACK IMMEDIATE'
            EXECUTE( @SQL )
        
        SET @SQL = 'ALTER DATABASE [' + @DBName + '] ' + 'SET Compatibility_level = 120'
            EXECUTE( @SQL )

        SET @SQL = 'ALTER DATABASE [' + @DBName + '] ' + 'SET MULTI_USER'
            EXECUTE( @SQL )

        FETCH NEXT FROM CompatCursor INTO @DBName

    END

CLOSE CompatCursor
DEALLOCATE CompatCursor