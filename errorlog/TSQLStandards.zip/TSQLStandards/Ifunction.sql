--=====================================================================================================================
--      Create the objects necessary to build the "ProdTable" table for the demo.
--=====================================================================================================================
--===== If the view that allows the use of NEWID() in a function already exists, drop it to make reruns in SSMS easier
     IF OBJECT_ID('dbo.iFunction') IS NOT NULL
        DROP VIEW dbo.iFunction
;
--===== Create the view that allows the use of NEWID() in a function.
GO
 CREATE VIEW dbo.iFunction AS
/**********************************************************************************************************************
 Purpose:
 This view is callable from UDF's which allows us to indirectly get a NEWID() within a function where we can't do such
 a thing directly in the function.  This view also solves the same problem for GETDATE().

 Usage:
 SELECT MyNewID FROM dbo.iFunction; --Returns a GUID
 SELECT MyDate  FROM dbo.iFunction; --Returns a Date

 Revision History:
 Rev 00 - 06 Jun 2004 - Jeff Moden - Initial creation
 Rev 01 - 06 Mar 2011 - Jeff Moden - Formalize code.  No logic changes.
**********************************************************************************************************************/
SELECT MyNewID = NEWID(),
       MyDate  = GETDATE();
GO