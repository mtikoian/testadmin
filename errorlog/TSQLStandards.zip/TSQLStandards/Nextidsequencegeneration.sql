
CREATE PROCEDURE [getSequence]
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @newVal int

	BEGIN TRY

		BEGIN TRAN

		UPDATE SequenceTable
		SET @newVal = Sequence = Sequence + 1

		COMMIT

	END TRY
	BEGIN CATCH

		DECLARE @ErrorMessage NVARCHAR(4000);
		DECLARE @ErrorSeverity INT;
		DECLARE @ErrorState INT;

		SELECT 
			@ErrorMessage = ERROR_MESSAGE(),
			@ErrorSeverity = ERROR_SEVERITY(),
			@ErrorState = ERROR_STATE();
			
		IF XACT_STATE = 1
			ROLLBACK

		RAISERROR (@ErrorMessage, @ErrorSeverity,@ErrorState);
		
	END CATCH


	SELECT @newVal AS NEWPROG
	RETURN @newVal
END