CREATE FUNCTION dbo.CreateDateTimeSpan
/**********************************************************************************************************************
 Purpose:
 Given any legal DATETIME and a standard 2 character DATEPART, return the begining and next date/time of that DATEPART.
 When the DATEPART is WK (week), a day offset to determine the starting day for the week will be applied. 

 Usage Examples:
 SELECT SpanType, StartDate, NextStartDate 
   FROM dbo.CreateDateTimeSpan(@pDateTime, @pDatePart, @pDOWStart);

 SELECT st.selectlist, timespan.SpanType, timespan.StartDate, timespan.NextStartDate 
   FROM dbo.sometable st
  CROSS APPLY dbo.CreateDateTimeSpan(st.somedatetimecolumn, @pDatePart, @pDOWStart) timespan;

--===== Find the bounds of the current week starting on Sunday
 SELECT @StartDate     = StartDate, 
        @NextStartDate = NextStartDate 
   FROM dbo.CreateDateTimeSpan(GETDATE(), 'wk', 7);

 Notes:
 1. The 3rd operand will only be used when @pDatePart = 'WK'and should be 1 for all other DATEPARTs.
 2. If an illegal date or datepart is given, the function will throw the following error.
    Msg 8115, Level 16, State 2, Line 7
    Arithmetic overflow error converting expression to data type datetime.
 3. Please see notes in code for legal DATEPARTs and values for @pDOWStart.
 4. This code does not rely on any DATEFIRST or language settings unless you're using the Hijri calendar.
    Since I've never used that calendar, I don't know how to code for it.

 Revision History:
 Rev 00 - 04 Apr 2012 - Jeff Moden - Initial creation
**********************************************************************************************************************/
--===== Declare the IO parameters
        (
        @pDateTime DATETIME,
        @pDatePart CHAR(2),  --ss=Second, mi=Minute, hh=Hour, dd=Day, wk=Week, mm=Month, qq=Quarter, yy=Year
        @pDOWStart INT       --1=Mon, 2=Tue, 3=Wed, 4=Thu, 5=Fri, 6=Sat, 7=Sun
        )
RETURNS TABLE WITH SCHEMABINDING AS
 RETURN  
   WITH cteOffset AS
        (--==== Calculate the reference date to use.
             -- For Week calculations, the @pDOWStart will offset the day.
             -- For time calculations, the current day will be used to prevent overflows.
             -- Won't affect other calculations until the last week of the year 9999.
         SELECT RefDate = 
                    CAST(
                        CASE
                            WHEN @pDatePart IN ('dd','wk','mm','qq','yy')
                            THEN -53690+((@pDOWStart-1)%7) -- 1753-01-01 = -53690, a Monday
                            WHEN @pDatePart IN ('hh','mi','ss')
                            THEN DATEADD(dd,DATEDIFF(dd,0,@pDateTime),0)
                        END
                    AS DATETIME)
        ) 
 SELECT SpanType  = @pDatePart,
        StartDate = 
            CASE @pDatePart
                WHEN 'ss' THEN DATEADD(ss,DATEDIFF(ss,RefDate,@pDateTime),RefDate)
                WHEN 'mi' THEN DATEADD(mi,DATEDIFF(mi,RefDate,@pDateTime),RefDate)
                WHEN 'hh' THEN DATEADD(hh,DATEDIFF(hh,RefDate,@pDateTime),RefDate)
                WHEN 'dd' THEN DATEADD(dd,DATEDIFF(dd,RefDate,@pDateTime),RefDate)
                WHEN 'wk' THEN DATEADD(dd,DATEDIFF(dd,RefDate,@pDateTime)/7*7,RefDate)
                WHEN 'mm' THEN DATEADD(mm,DATEDIFF(mm,RefDate,@pDateTime),RefDate)
                WHEN 'qq' THEN DATEADD(qq,DATEDIFF(qq,RefDate,@pDateTime),RefDate)
                WHEN 'yy' THEN DATEADD(yy,DATEDIFF(yy,RefDate,@pDateTime),RefDate)
                ELSE CAST(-99999 AS DATETIME) --Throw an error if the datepart is wrong
            END,
        NextStartDate = 
            CASE @pDatePart
                WHEN 'ss' THEN DATEADD(ss,DATEDIFF(ss,RefDate,@pDateTime)+1,RefDate)
                WHEN 'mi' THEN DATEADD(mi,DATEDIFF(mi,RefDate,@pDateTime)+1,RefDate)
                WHEN 'hh' THEN DATEADD(hh,DATEDIFF(hh,RefDate,@pDateTime)+1,RefDate)
                WHEN 'dd' THEN DATEADD(dd,DATEDIFF(dd,RefDate,@pDateTime)+1,RefDate)
                WHEN 'wk' THEN DATEADD(dd,DATEDIFF(dd,RefDate,@pDateTime)/7*7+7,RefDate)
                WHEN 'mm' THEN DATEADD(mm,DATEDIFF(mm,RefDate,@pDateTime)+1,RefDate)
                WHEN 'qq' THEN DATEADD(qq,DATEDIFF(qq,RefDate,@pDateTime)+1,RefDate)
                WHEN 'yy' THEN DATEADD(yy,DATEDIFF(yy,RefDate,@pDateTime)+1,RefDate)
            END
   FROM cteOffset
;
