ALTER FUNCTION HTMLEncode(@OriginalText VARCHAR(8000))
RETURNS VARCHAR(8000)  
BEGIN 
DECLARE @CleanedText VARCHAR(8000) 
SELECT @CleanedText = ISNULL(@CleanedText,'') +  
CASE WHEN ASCII(SUBSTRING(@OriginalText,Tally.N,1)) < 128  THEN SUBSTRING(@OriginalText,Tally.N,1)
     WHEN ASCII(SUBSTRING(@OriginalText,Tally.N,1)) >= 128 THEN '&#' + CONVERT(VARCHAR,ASCII(SUBSTRING(@OriginalText,Tally.N,1)) ) + ';'  END
      
FROM dbo.Tally           WHERE Tally.N <= LEN(@OriginalText)            
                
RETURN @CleanedText 
END
go
SELECT dbo.HTMLEncode('�')
SELECT dbo.HTMLEncode('happin�ss �s a warm blank�t')

SELECT dbo.HTMLEncode('‘Special Digital Data Service Obligation’')

