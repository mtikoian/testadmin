CREATE FUNCTION dbo.Mondays
/****************************************************************************************
 Purpose:
 Given a number of weeks and a date, return @pWeeks number of dates of Mondays starting 
 with the Monday of the week that @pSomeDate is a part of.  Previous weeks are indicated
 by the use of a negative number for @pWeeks and future weeks are indicated by use of a
 positive number.
 Usage Example:
--===== Return the PREVIOUS 15 weeks' of Mondays including this week.
 SELECT MondayDT
   FROM dbo.Mondays(-15,GETDATE())
;
--===== Return the FUTURE 15 weeks' of Mondays including this week.
 SELECT MondayDT
   FROM dbo.Mondays( 15,GETDATE())
;
--===== Return every Monday from the beginning of 1753 to the end of 9999.
 SELECT MondayDT
   FROM dbo.Mondays( 430308,'1753')
;
 Programmer's Notes:
 1. The function may be used as part of a CROSS or OUTER APPLY or as a joinable source.
 2. -53690 is the date serial number of the date '1753-01-01', which is the earliest date
    available to the DATETIME data type and is also a Monday.
 3. The /7*7 part of the formula is integer math to correctly calculate the number of 
    whole weeks that have passed from  '1753-01-01' up to @pSomeDate.

 Revision History:
 Rev 00 - 21 Jun 2017 - Jeff Moden
        - Initial creation and unit test.
****************************************************************************************/
        (@pWeeks INT, @pSomeDate DATETIME)
RETURNS TABLE AS
 RETURN WITH
  E1(N) AS (SELECT 1 FROM (VALUES (1),(1),(1),(1),(1),(1),(1),(1),(1),(1))E0(N))
 ,E6(N) AS (SELECT 1 FROM E1 a, E1 b, E1 c, E1 d, E1 e, E1 f) --Up to 1 million
 SELECT TOP (ABS(@pWeeks))
        MondayDT =  DATEADD( wk
                            ,SIGN(@pWeeks)*(ROW_NUMBER() OVER (ORDER BY N)-1)
                            ,DATEADD(dd,DATEDIFF(dd,-53690,@pSomeDate)/7*7,-53690)
                           )
   FROM E6
;
GO