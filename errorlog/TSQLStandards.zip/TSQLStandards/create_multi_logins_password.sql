DECLARE  @SQL    VARCHAR(MAX)
        ,@Logins SMALLINT = 1435
;
 SELECT TOP (@Logins)
        @SQL =  ISNULL(@SQL,'')
                    + REPLACE(REPLACE('
CREATE LOGIN TestUser<<Suffix>> WITH PASSWORD = "UserT3$t<<Suffix>>";'
                    ,'"','')
                    ,'<<Suffix>>',RIGHT(ROW_NUMBER() OVER (ORDER BY (SELECT NULL))+10000,4))
   FROM sys.all_columns
;
PRINT @SQL