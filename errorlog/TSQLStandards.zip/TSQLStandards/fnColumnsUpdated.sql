CREATE FUNCTION dbo.fnColumnsUpdated
        (@TableName SYSNAME, @BinaryColNums VARBINARY(128))
        RETURNS @TableInfo TABLE (RowNum SMALLINT IDENTITY(1,1) PRIMARY KEY CLUSTERED,ColNum SMALLINT NULL, ColName VARCHAR(128) NULL)
AS
  BEGIN --Begin the main body of the function

--===== Declare local variables
DECLARE @ByteCount TINYINT
    SET @ByteCount = LEN(@BinaryColNums)

--===== Populate the return table with column numbers and names for the desired 
--===== table according to the bit mask passed in through @BinaryColNums
 INSERT INTO @TableInfo (ColNum,ColName)
 SELECT c.ColNum, '['+COL_NAME(OBJECT_ID(@TableName), c.ColNum )+']' AS ColName
   FROM (--Derived table "c" finds column numbers and names for columns identified
         --in the @BinaryColNums variable usually provided by COLUMNS_UPDATED() in
         --an INSERT or UPDATE table.
         SELECT CASE ---- Determine which bit # is set and use a column number
                     WHEN BinaryVal & POWER(2,t2.n-1) = POWER(2,t2.n-1)
                     THEN ((ByteNum)*8)+t2.n  --This creates the bit# that is set
                     ELSE 0
                END AS ColNum
           FROM (--Derived table splits the bytes of the binary number from left to
                 --right as outlined in Books OnLine for use of COLUMNS_UPDATED().
                 SELECT n-1 AS ByteNum,
                        SUBSTRING(@BinaryColNums,N,1) AS BinaryVal
                   FROM dbo.TALLY t1 WITH (NOLOCK)
                  WHERE N<= @ByteCount
                ) b,
                dbo.Tally t2 WITH (NOLOCK)
          WHERE N<=8 --8 bits in each byte
            AND BinaryVal & POWER(2,t2.n-1) = POWER(2,t2.n-1) --Suppress "0" bits
        ) c

--===== If @BinaryColNums indicated more columns than there are, delete the ColNums from the table
 DELETE @TableInfo
  WHERE ColName IS NULL

--===== Return the table and exit
 RETURN
    END --End of Function
go
SELECT * FROM dbo.fnColumnsUpdated('company',0xffffffff)