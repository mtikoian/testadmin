 +-------------+           +--------------------+           +---------------+
  | Customer    |-||-,,     | CustomerCreditCard |           | CreditCard    |
  +-------------+    ||     +--------------------+           +---------------+
  | Customer_ID |    ||     | CreditCard_ID      |>-|-----||-| CreditCard_ID |
  |(Details)    |    |'---o<| Customer_ID        |           | (Details)     |
  +-------------+    |      | (Details)          |           +---------------+
                     |      +--------------------+           
                     |
                     |      +----------------+           +----------------+         +----------------+
                     |      | Order (Header) |           | Payment        |         | Payment_Type   |
                     |      +----------------+           +----------------+         +----------------+
                     |      | Order_ID       |-||-,,     |Payment_ID      |    ,-||-| PaymentType_ID |
                     '----o<| Customer_ID    |    ||     |Payment_Type_ID |>|--'    | (details)      |
                            | (Details)      |    |'---o<|Order_Id        |         +----------------+
                            +----------------+    |      |(details)       |-|--,    +---------------+
                                                  |      +----------------+    |    | CCD_Detail    |
                                                  |                            |    +---------------+
                                                  |      +----------------+    '--o-| Payment_ID    |
                                                  |      | OrderDetail    |         | CreditCard_ID |
                                                  |      +----------------+         | (details)     |
                                                   '--|-<| Order_ID       |         +---------------+
                                                         | OrderDetail_ID |
                                                         | (Details)      |
                                                         +----------------+