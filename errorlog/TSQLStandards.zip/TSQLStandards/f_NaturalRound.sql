GO
CREATE  FUNCTION dbo.NaturalRound
        (
        @Value DOUBLE PRECISION
        )
RETURNS TABLE
WITH    SCHEMABINDING 
AS      
RETURN
SELECT v.Value
  FROM       (SELECT CONVERT(NVARCHAR(39), CONVERT(DECIMAL(38,8), @Value))) c (Converted)
 CROSS APPLY (SELECT REVERSE(c.Converted)) r (Reversed)
 CROSS APPLY (SELECT SUBSTRING(c.Converted,1,LEN(c.Converted)-PATINDEX('%[^0]%',r.Reversed)+1)) s (Stripped)
 CROSS APPLY (SELECT ISNULL(STUFF(s.Stripped,PATINDEX('%.',s.Stripped),1,''), s.Stripped)) v (Value)
;
GO
---- Single Item test
--SELECT  nr.Value
--FROM    dbo.NaturalRound (1234.5678) nr
--GO
---- Test with table
--DECLARE @Data
--TABLE   (
--        VALUE   DOUBLE PRECISION NULL
--        );
        
--INSERT  @Data
--SELECT (1234500) UNION ALL
--SELECT (1234500.) UNION ALL
--SELECT (1234500.0) UNION ALL
--SELECT (1234500.9) UNION ALL
--SELECT (1234500.99) UNION ALL
--SELECT (1234500.999) UNION ALL
--SELECT (1234500.9999);
        
--SELECT  d.Value,
--        nr.Value
--FROM    @Data d
--CROSS
--APPLY   dbo.NaturalRound (d.Value) nr
--GO
--DROP FUNCTION dbo.NaturalRound;