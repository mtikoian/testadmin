
--===== Build a real set-based function to find the first letter of each word using an iTVF.
     IF OBJECT_ID('tempdb.dbo.Abbreviate') IS NOT NULL 
        DROP FUNCTION dbo.Abbreviate
;
GO
CREATE FUNCTION dbo.Abbreviate
--===== Define I/O parameters
        (@pString VARCHAR(8000))
RETURNS TABLE WITH SCHEMABINDING AS
 RETURN
--===== "Inline" CTE Driven "Tally Table" produces values from 0 up to 10,000...
     -- enough to cover VARCHAR(8000)
  WITH E1(N) AS (
                 SELECT 1 UNION ALL SELECT 1 UNION ALL SELECT 1 UNION ALL 
                 SELECT 1 UNION ALL SELECT 1 UNION ALL SELECT 1 UNION ALL 
                 SELECT 1 UNION ALL SELECT 1 UNION ALL SELECT 1 UNION ALL SELECT 1
                ),                          --10E+1 or 10 rows
       E2(N) AS (SELECT 1 FROM E1 a, E1 b), --10E+2 or 100 rows
       E4(N) AS (SELECT 1 FROM E2 a, E2 b), --10E+4 or 10,000 rows max
 cteTally(N) AS (--==== This provides the "base" CTE and limits the number of rows right up front
                     -- for both a performance gain and prevention of accidental "overruns"
                 SELECT TOP (ISNULL(DATALENGTH(@pString),0)) ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) FROM E4
                ),
cteStart(N1) AS (--==== This returns N+1 (starting position of each "element" just once for each delimiter)
                 SELECT 1 UNION ALL -- does away with 0 base CTE, and the OR condition in one go!
                 SELECT t.N+1 FROM cteTally t WHERE SUBSTRING(@pString,t.N,2) COLLATE Latin1_General_BIN LIKE ' [A-Z0-9]' COLLATE Latin1_General_BIN
                )
--===== Do the actual split of each character following a space and concatenate it.
 SELECT Abbreviation       = (SELECT SUBSTRING(@pString, s.N1,1) FROM cteStart s FOR XML PATH(''))
;
GO
--=====================================================================================================================
--      Now, test the real set based function the same way we tested Vedran's
--=====================================================================================================================
--===== Test the RBAR function ========================================================================================
     IF OBJECT_ID('tempdb..#Results','U') IS NOT NULL DROP TABLE #Results
;

  PRINT '--===== Test the real set-based function ========================================================================================'
;
DECLARE @StartTime DATETIME;
 SELECT @StartTime = GETDATE()
;
 SELECT String, abbv.Abbreviation
   INTO #Results
   FROM #Names n
  CROSS APPLY dbo.Abbreviate(n.String) abbv

;
  PRINT 'Total Duration in Seconds: ' + CAST(DATEDIFF(ss,@StartTime,GETDATE()) AS VARCHAR(10))
;
GO