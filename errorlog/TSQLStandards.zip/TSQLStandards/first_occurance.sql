IF 1 = 1 
BEGIN
  SET NOCOUNT ON;
  IF OBJECT_ID('tempdb..#ListOfStrings') IS NOT NULL DROP TABLE #ListOfStrings;

  SELECT TOP(100000)
  [RowID] = ROW_NUMBER() OVER(ORDER BY (SELECT NULL)),
  [name]  = CAST(NEWID() AS VARCHAR(36))
  INTO #ListOfStrings
  FROM SYS.COLUMNS a, SYS.COLUMNS b
END;


select * from #ListOfStrings
PRINT char(10)+'== Chris3 (serial)'+REPLICATE('========================================',2);
GO
DECLARE @st datetime = getdate(), @x char(1);
  WITH Tally -- Chris3
  AS (SELECT n = 0 FROM (VALUES (0),(0),(0),(0),(0),(0),(0),(0),(0),(0)) d (n))
  SELECT -- c.RowID,
  @x = SUBSTRING(c.name, x.n, 1)
  FROM #ListOfStrings c
  CROSS APPLY 
  (
  SELECT TOP(1) n
  FROM (
  SELECT TOP(LEN(c.name)) n = ROW_NUMBER() OVER (ORDER BY @@VERSION)
  FROM Tally a, Tally b, Tally c
  ) t
  WHERE CHARINDEX(SUBSTRING(c.name, t.n, 1), LEFT(c.name, n-1)) > 0
  ORDER BY n
  ) x
  OPTION (maxdop 1);
PRINT datediff(ms,@st,getdate());
GO 

PRINT char(10)+'== Alan (serial)'+REPLICATE('========================================',2);
GO
DECLARE @st datetime = getdate(), @x char(1);
  SELECT @x = XCHar
  FROM #ListOfStrings los
  CROSS APPLY
  (
 SELECT TOP (1) token --, position
  FROM dbo.ngrams8k(los.name,1)
  WHERE CHARINDEX(token,SUBSTRING(los.name,1,CHECKSUM(position-1))) > 0
  ORDER BY position
  ) ngEng(XCHar)
  OPTION (maxdop 1);
PRINT datediff(ms,@st,getdate());
GO 3

PRINT char(10)+'== Chris3 (parallel)'+REPLICATE('========================================',2);
GO
DECLARE @st datetime = getdate(), @x char(1);
  WITH Tally -- Chris3
  AS (SELECT n = 0 FROM (VALUES (0),(0),(0),(0),(0),(0),(0),(0),(0),(0)) d (n))
  SELECT -- c.RowID,
  @x = SUBSTRING(c.name, x.n, 1)
  FROM #ListOfStrings c
  CROSS APPLY 
  (
  SELECT TOP(1) n
  FROM (
  SELECT TOP(LEN(c.name)) n = ROW_NUMBER() OVER (ORDER BY @@VERSION)
  FROM Tally a, Tally b, Tally c
  ) t
  WHERE CHARINDEX(SUBSTRING(c.name, t.n, 1), LEFT(c.name, n-1)) > 0
  ORDER BY n
  ) x
  OPTION (querytraceon 8649);
PRINT datediff(ms,@st,getdate());
GO 3

PRINT char(10)+'== Alan (parallel)'+REPLICATE('========================================',2);
GO
DECLARE @st datetime = getdate(), @x char(1);
  SELECT @x = XCHar
  FROM #ListOfStrings los
  CROSS APPLY
  (
 SELECT TOP (1) token --, position
  FROM dbo.ngrams8k(los.name,1)
  WHERE CHARINDEX(token,SUBSTRING(los.name,1,CHECKSUM(position-1))) > 0
  ORDER BY position
  ) ngEng(XCHar)
  OPTION (querytraceon 8649);
PRINT datediff(ms,@st,getdate());
GO 