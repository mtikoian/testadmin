create FUNCTION dbo.DateDiffDHMS(@StartDate Datetime,
            @EndDate Datetime) RETURNS TABLE WITH SCHEMABINDING
AS

  RETURN (
  WITH cteParts AS (
  SELECT Days  =  DATEDIFF(second, @StartDate, @EndDate) / 86400,
     Hours = (DATEDIFF(second, @StartDate, @EndDate) / 3600) - (DATEDIFF(second, @StartDate, @EndDate) / 86400 * 24),
     Minutes = (DATEDIFF(second, @StartDate, @EndDate) / 60) - (DATEDIFF(second, @StartDate, @EndDate) / 3600 * 60),
     Seconds =  DATEDIFF(second, @StartDate, @EndDate) % 60
  )
  SELECT Days, Hours, Minutes, Seconds, 
    DHMS = CONVERT(Varchar(8), Days) + ':' + 
     RIGHT('00' + CONVERT(Varchar(2), Hours), 2) + ':' + 
     RIGHT('00' + CONVERT(Varchar(2), Minutes), 2) + ':' + 
     RIGHT('00' + CONVERT(Varchar(2), Seconds), 2)
  FROM cteParts
  );