--===== Conditionally drop any Temp Tables to make reruns in SSMS easier.
     IF OBJECT_ID('tempdb..#CmdResult','U') IS NOT NULL DROP TABLE #CmdResult;
     IF OBJECT_ID('tempdb..#Service'  ,'U') IS NOT NULL DROP TABLE #Service;

--===== Create the table that will hold the unparsed service lines.
 CREATE TABLE #CmdResult
        (
         RowNum    INT IDENTITY(1,1)
        ,CmdResult VARCHAR(8000)
        )
;
--===== Pull the service lines into the temp table so we can parse the rows.
     -- Note that the order of the columns in the WMIC command doesn't matter.
     -- The (missing) NODE column will always come first and the rest of the
     -- columns will be in alphabetical order. I listed them in order just to make
     -- the returned order obvious. CSV rows are returned thanks to /FORMAT:CSV.
 INSERT INTO #CmdResult
        (CmdResult)
   EXEC xp_CmdShell 'wmic service get Caption,Name,ServiceType,StartMode,State,Status /FORMAT:CSV'
;
--SELECT * FROM #CmdResult;
--===== Parse, pivot (using a fast CROSSTAB), and save the service data in a table that we can query later.
     -- Note that "NODE" is the name of the computer we just ran on.
 SELECT  RowNum      = ROW_NUMBER() OVER (ORDER BY cr.RowNum)
        ,Node        =         MAX(CASE WHEN split.ItemNumber = 1 THEN split.Item ELSE '' END)
        ,Caption     = REPLACE(MAX(CASE WHEN split.ItemNumber = 2 THEN split.Item ELSE '' END),'&','&')
        ,Name        = REPLACE(MAX(CASE WHEN split.ItemNumber = 3 THEN split.Item ELSE '' END),'&','&')
        ,ServiceType =         MAX(CASE WHEN split.ItemNumber = 4 THEN split.Item ELSE '' END)
        ,StartMode   =         MAX(CASE WHEN split.ItemNumber = 5 THEN split.Item ELSE '' END)
        ,State       =         MAX(CASE WHEN split.ItemNumber = 6 THEN split.Item ELSE '' END)
        ,Status      =         MAX(CASE WHEN split.ItemNumber = 7 THEN split.Item ELSE '' END)
   INTO #Service
   FROM #CmdResult cr
  CROSS APPLY dbo.f_DelimitedSplit8K(cr.CmdResult,',') split
  WHERE cr.RowNum    > 2  --First row is blank, second row is column headers
    AND cr.CmdResult > '' --Last row is NULL but this takes care of BLANKS and NULLs
  GROUP BY cr.RowNum      --And now you know why the IDENTITY column is important.
;
--===== Show what we've got
 SELECT *
   FROM #Service
  ORDER BY Name
;