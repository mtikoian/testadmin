CREATE FUNCTION dbo.FormatPhone
        (
        @String  VARCHAR(8000)
        )
RETURNS CHAR(14)
     AS
  BEGIN
        --===== Declare and preset local variables
        DECLARE @Len INT
         SELECT @Len = LEN(@String)+1
&#160;
        --===== Remove non-digit characters
         SELECT @String = STUFF(@String,@Len-t.N,1,'')
           FROM dbo.Tally t
          WHERE t.N < @Len
            AND SUBSTRING(@String,@Len-t.N,1) LIKE '[^0-9]'
&#160;
--===== Return the cleaned value and exit
 RETURN CASE 
            WHEN LEN(@String) = 10 
            THEN '('+STUFF(STUFF(@String,7,0,'-'),4,0,') ')
            ELSE 'Bad Entry'
        END
&#160;
    END