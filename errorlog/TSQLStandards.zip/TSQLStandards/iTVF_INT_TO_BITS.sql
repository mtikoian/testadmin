CREATE FUNCTION dbo.iTVF_INT_TO_BITS
(
    @INTVAL INT
)
RETURNS TABLE
AS
RETURN
(
    SELECT
        (1 - SIGN(ABS(1+SIGN(@INTVAL)))) * ABS(SIGN(@INTVAL))      AS BIT_01
       ,1 - SIGN(ABS((@INTVAL &   1073741824 ) -    1073741824 ))  AS BIT_02
       ,1 - SIGN(ABS((@INTVAL &    536870912 ) -     536870912 ))  AS BIT_03
       ,1 - SIGN(ABS((@INTVAL &    268435456 ) -     268435456 ))  AS BIT_04
       ,1 - SIGN(ABS((@INTVAL &    134217728 ) -     134217728 ))  AS BIT_05
       ,1 - SIGN(ABS((@INTVAL &     67108864 ) -      67108864 ))  AS BIT_06
       ,1 - SIGN(ABS((@INTVAL &     33554432 ) -      33554432 ))  AS BIT_07
       ,1 - SIGN(ABS((@INTVAL &     16777216 ) -      16777216 ))  AS BIT_08
       ,1 - SIGN(ABS((@INTVAL &      8388608 ) -       8388608 ))  AS BIT_09
       ,1 - SIGN(ABS((@INTVAL &      4194304 ) -       4194304 ))  AS BIT_10
       ,1 - SIGN(ABS((@INTVAL &      2097152 ) -       2097152 ))  AS BIT_11
       ,1 - SIGN(ABS((@INTVAL &      1048576 ) -       1048576 ))  AS BIT_12
       ,1 - SIGN(ABS((@INTVAL &       524288 ) -        524288 ))  AS BIT_13
       ,1 - SIGN(ABS((@INTVAL &       262144 ) -        262144 ))  AS BIT_14
       ,1 - SIGN(ABS((@INTVAL &       131072 ) -        131072 ))  AS BIT_15
       ,1 - SIGN(ABS((@INTVAL &        65536 ) -         65536 ))  AS BIT_16
       ,1 - SIGN(ABS((@INTVAL &        32768 ) -         32768 ))  AS BIT_17
       ,1 - SIGN(ABS((@INTVAL &        16384 ) -         16384 ))  AS BIT_18
       ,1 - SIGN(ABS((@INTVAL &         8192 ) -          8192 ))  AS BIT_19
       ,1 - SIGN(ABS((@INTVAL &         4096 ) -          4096 ))  AS BIT_20
       ,1 - SIGN(ABS((@INTVAL &         2048 ) -          2048 ))  AS BIT_21
       ,1 - SIGN(ABS((@INTVAL &         1024 ) -          1024 ))  AS BIT_22
       ,1 - SIGN(ABS((@INTVAL &          512 ) -           512 ))  AS BIT_23
       ,1 - SIGN(ABS((@INTVAL &          256 ) -           256 ))  AS BIT_24
       ,1 - SIGN(ABS((@INTVAL &          128 ) -           128 ))  AS BIT_25
       ,1 - SIGN(ABS((@INTVAL &           64 ) -            64 ))  AS BIT_26
       ,1 - SIGN(ABS((@INTVAL &           32 ) -            32 ))  AS BIT_27
       ,1 - SIGN(ABS((@INTVAL &           16 ) -            16 ))  AS BIT_28
       ,1 - SIGN(ABS((@INTVAL &            8 ) -             8 ))  AS BIT_29
       ,1 - SIGN(ABS((@INTVAL &            4 ) -             4 ))  AS BIT_30
       ,1 - SIGN(ABS((@INTVAL &            2 ) -             2 ))  AS BIT_31
       ,1 - SIGN(ABS((@INTVAL &            1 ) -             1 ))  AS BIT_32
)