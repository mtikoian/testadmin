CREATE FUNCTION dbo.FiscalDateInfo (@pSomeDT DATETIME)
/**********************************************************************************************************************
 Purpose:
 Given a Calendar Date, calculate various date parts for a Fiscal Year whose definition is that it starts on the first
 Monday of April and each month within the Fiscal Year starts on the first Monday of that month.  It also calculates
 "Start" and "Next" boundaries for each "part" including Fiscal Weeks and more.

 Usage:
--===== Simple "Singleton" Syntax
 SELECT  FiscalYear
        ,FiscalMonth
        ,WeekOfFiscalYear    
        ,WeekOfFiscalMonth
        ,CurrFiscalYearStart 
        ,NextFiscalYearStart 
        ,CurrFiscalMonthStart
        ,NextFiscalMonthStart
        ,CurrFiscalWeekStart 
        ,NextFiscalWeekStart
   FROM dbo.FiscalDateInfo(@SomeDT)
;
--===== Return the Fiscal Calendar Information for 100 Calendar Years from the year 2000 up to 2100.
     -- This method can be used to create a permanent Fiscal Calendar Table.
     -- If you don't have an fnTally function, I've attached it to this post.
 SELECT  CalendarDate = DATEADD(dd,t.N,'2000')
        ,f.*
   FROM dbo.fnTally(0,DATEDIFF(dd,'2000','2100')) t
  CROSS APPLY dbo.FiscalDateInfo(DATEADD(dd,t.N,'2000')) f
  ORDER BY t.N
;

 Programmer's Notes:
 1. If you make a Fiscal Calendar Table from this, I suggest using the "CalendarDate" column as the Clustered PK.
 2. Consider NOT making a table from this because it's 100% memory (no READs whatsoever) and it's nasty fast.
    The 100 year example (36,526 days) takes only 552ms to run and that includes piping the output to the screen.
 3. Because only date functions were used, Leap Years are handled auto-magically.
  
 Revision History:
 Rev 00 - 24 Dec 2014 - Jeff Moden - Intial creation andd Unit Test.
**********************************************************************************************************************/
RETURNS TABLE AS
 RETURN
WITH 
cteFirstOfCurrMonth AS 
( --=== Finds the first of the month for the given date
 SELECT FirstOfCurrMonth = DATEADD(mm,DATEDIFF(mm,0,@pSomeDT),0)
)
,
cteFirstOfOther AS
( --=== Finds first of previous and next months
 SELECT  FirstOfPrevMonth = DATEADD(mm,-1,FirstOfCurrMonth)
        ,FirstOfCurrMonth
        ,FirstOfNextMonth = DATEADD(mm, 1,FirstOfCurrMonth)
   FROM cteFirstOfCurrMonth
)
,
cteFiscalMonthStart AS 
( --=== Finds the first Monday of the months from above
 SELECT  PrevFiscalMonthStart = DATEADD(dd,DATEDIFF(dd,-6,FirstOfPrevMonth)/7*7,0)
        ,CurrFiscalMonthStart = DATEADD(dd,DATEDIFF(dd,-6,FirstOfCurrMonth)/7*7,0)
        ,NextFiscalMonthStart = DATEADD(dd,DATEDIFF(dd,-6,FirstOfNextMonth)/7*7,0)
   FROM cteFirstOfOther
)
,
cteOffSet AS
( --=== If the given date is less than the first Monday of the month, then offset everything by -1 month
     -- Can't just subtract a month here because months don't have an even number of weeks. We have to do the "Monday" thing.
 SELECT  CurrFiscalMonthStart = CASE WHEN @pSomeDT < CurrFiscalMonthStart THEN PrevFiscalMonthStart ELSE CurrFiscalMonthStart END
        ,NextFiscalMonthStart = CASE WHEN @pSomeDT < CurrFiscalMonthStart THEN CurrFiscalMonthStart ELSE NextFiscalMonthStart END
   FROM cteFiscalMonthStart
)
,
cteFiscalBasics AS
( --=== Calculate the fiscal week starts, Year, and Month
 SELECT  FiscalYear          = YEAR(CurrFiscalMonthStart) - CASE WHEN MONTH(CurrFiscalMonthStart) <= 3 THEN 1 ELSE 0 END --Previous year if Jan, Feb, or Mar
        ,FiscalMonth         = (MONTH(CurrFiscalMonthStart)+8)%12+1 --The +8 is the other 9 months-1 because of the 0-based modulus
        ,WeekOfFiscalMonth   = DATEDIFF(dd,CurrFiscalMonthStart,@pSomeDT)/7+1 --Number of weeks since the first of the fiscal month +1
        ,CurrFiscalMonthStart
        ,NextFiscalMonthStart
        ,CurrFiscalWeekStart = DATEADD(dd,DATEDIFF(dd, 0,@pSomeDT)/7*7,0) --Figures out the Monday equal to or prior to the date
        ,NextFiscalWeekStart = DATEADD(dd,DATEDIFF(dd,-7,@pSomeDT)/7*7,0) --Figures out the Monday equal to or prior to the date +1 week
   FROM cteOffset
)
,
cteFiscalYears AS
( --=== Calculate the start of the current and next fiscal years
 SELECT  FiscalYear
        ,FiscalMonth
        ,WeekOfFiscalMonth
        ,CurrFiscalYearStart = DATEADD(dd,DATEDIFF(dd,-6,DATEADD(mm,(FiscalYear-1900)*12+ 3,0))/7*7,0) --Adds the year to date "0" as months + 3 and finds the first Monday of the year
        ,NextFiscalYearStart = DATEADD(dd,DATEDIFF(dd,-6,DATEADD(mm,(FiscalYear-1900)*12+15,0))/7*7,0) --Same but adds an extra 12 months
        ,CurrFiscalMonthStart
        ,NextFiscalMonthStart
        ,CurrFiscalWeekStart 
        ,NextFiscalWeekStart
   FROM cteFiscalBasics
)
 --==== Last but not least, calculate the week of the fiscal year
 SELECT  FiscalYear
        ,FiscalMonth
        ,WeekOfFiscalYear     = DATEDIFF(dd,CurrFiscalYearStart,CurrFiscalWeekStart)/7+1
        ,WeekOfFiscalMonth
        ,CurrFiscalYearStart 
        ,NextFiscalYearStart 
        ,CurrFiscalMonthStart
        ,NextFiscalMonthStart
        ,CurrFiscalWeekStart 
        ,NextFiscalWeekStart
   FROM cteFiscalYears
;
