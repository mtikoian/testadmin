Create Procedure CLR_TighterSecurity @sQueryCommand nvarchar(4000),
                                     @sIncludeHeaders int,
                                     @sTitle nvarchar(4000),
                                     @sSummary nvarchar(4000),
                                     @sHTMLStyle int
AS
BEGIN
SET NOCOUNT ON
  DECLARE  @sFilePath nvarchar(4000), 
           @sFileName nvarchar(4000) 
           
   SET  @sFilePath = 'C:\Data\'
   SET @sFileName = REPLACE(SUSER_NAME(),'\','_') 
                    + '_' 
                    + CONVERT(VARCHAR,GETDATE(),112) 
                    + '-' 
                    + REPLACE(CONVERT(VARCHAR,GETDATE(),114),':','') 
                    + '.html'
  --Above returns a fileName like 'MyDomain_lizaguirre_20120504-170747007.html
  EXECUTE CLR_ExportQueryToHTML @QueryCommand   = @sQueryCommand,
                                @FilePath       = @sFilePath,
                                @FileName       = @sFileName,
                                @IncludeHeaders = @sIncludeHeaders,
                                @Title          = @sTitle,
                                @Summary        = @sSummary,
                                @HTMLStyle      = @sHTMLStyle
 END --PROC
