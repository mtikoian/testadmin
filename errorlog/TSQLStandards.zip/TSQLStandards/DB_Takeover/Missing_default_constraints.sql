SELECT 	 SchemaName = s.name
		,TableName = o.name
		,ColumnName = c.name
		,DefaultConstraint = dc.name
		,t.name as datatype
FROM	sys.objects o
		INNER JOIN sys.columns c
		ON	c.object_id = o.object_id
		INNER JOIN sys.schemas s
		ON 	s.schema_id = o.schema_id
		inner join sys.types t
		on t.system_type_id = c.system_type_id
		LEFT OUTER JOIN sys.default_constraints dc
		ON	dc.parent_object_id = o.object_id AND
			dc.parent_column_id = c.column_id
WHERE  --	c.name = 'EffectiveDate' AND
t.name = 'bit' and 
		o.type = 'U'  
	AND	dc.parent_object_id IS NULL
ORDER BY 1,2,3