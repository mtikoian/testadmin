USE tempdb
GO
/*********************************************************************************

  File:         spFixColumnCheckNaming - Test Cases.sql
  Author:       Michael S�ndergaard
  Date:         December 2009
  Build Date:   20 March 2011
  Homepage:     http://sql.soendergaard.info
  Version:      1.0.3
  Supported / 
  Tested on:    Microsoft SQL Server 2005 & 2008
  
  Description:  This file contains all the test cases used for developing the 
                stored procedure spFixColumnCheckNaming.
                
  Requirements: The stored procedure spFixColumnCheckNaming should be
                installed in the tempdb.
                
                All test cases will be created in tempdb. for ensuring better cleanup
                and avoiding permissions
                

  Usage:        See test cases

  -----------------------------------------------------------------------------------

  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF
  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
  TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
  PARTICULAR PURPOSE. YOU MAY USE AND MODIFY THIS CODE FREELY FOR
  YOUR OWN PURPOSE, IF YOU REMEMBER TO CREDIT MY WORK. HOWEVER YOU 
  MAY NOT REPUBLISH IT, AND CLAIM IT AS YOUR OWN WORK 


  -----------------------------------------------------------------------------------

  Revision History:

    Version 1.0.0 - December 6 , 2009 
      - Inital version 

    Version 1.0.1 - April 4, 2010 
      - Added test cases for column aliases
      - Added test cases for table aliases
      - Added test cases for schema aliases

    Version 1.0.2 - May 8, 2010 
      - Added test cases for MaxNameLenght
      - Added test cases for UniquifyNames

    Version 1.0.3 - June 22, 2010 
      - Added test cases for %ENABLED_STATE% place holder, 
        and @EnabledStates
      - Added test cases for %REPLICATION_STATE% place holder, 
        and @ReplicationStates
      - Added test cases for %TRUSTED_STATE% place holder, 
        and @TrustedStates
 
**********************************************************************************/
USE tempdb

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

SET NOCOUNT ON

-- #######################################################################################
-- ###### Verify all requirements for this test case script
-- #######################################################################################
IF OBJECT_ID('fnGetFilteredTables', 'TF') IS NULL
BEGIN
  RAISERROR('The user defined function fnGetFilteredTables is not installed in the tempdb', 16, 1)
  RETURN
END 

IF SCHEMA_ID('dbautils') IS NULL EXECUTE ('CREATE SCHEMA dbautils AUTHORIZATION dbo')

DECLARE @DBIsCaseSensitive BIT
SET @DBIsCaseSensitive = CASE WHEN 'a' = 'A' THEN CAST(0 AS BIT) ELSE 1 END

DELETE AliasRulesSynonym  

-- #######################################################################################
-- ###### Create the AliasRules for the test cases
-- #######################################################################################
INSERT INTO AliasRulesSynonym
(
  DatabaseName,
  SchemaName,
  TableName,
  ColumnName,
  AliasName
)
          SELECT DatabaseName = 'tempdb', SchemaName = 'ColumnAliasRenaming', TableName = 'Case01', ColumnName = 'ProductNo', AliasName = 'CAR1' 
UNION ALL SELECT DatabaseName = 'tempdb', SchemaName = 'ColumnAliasRenaming', TableName = 'Case02', ColumnName = 'ProductNo', AliasName = 'CAR2'
UNION ALL SELECT DatabaseName = 'tempdb', SchemaName = 'ColumnAliasRenaming', TableName = 'Case03', ColumnName = 'ProductNo', AliasName = 'CAR3' 
UNION ALL SELECT DatabaseName = '%', SchemaName = 'ColumnAliasRenaming', TableName = '%', ColumnName = 'ProductNo', AliasName = 'CAR' 

UNION ALL SELECT DatabaseName = 'tempdb', SchemaName = 'TableAliasRenaming', TableName = 'Case01', ColumnName = '', AliasName = 'TAR1' 
UNION ALL SELECT DatabaseName = 'tempdb', SchemaName = 'TableAliasRenaming', TableName = 'Case02', ColumnName = '', AliasName = 'TAR2'
UNION ALL SELECT DatabaseName = 'tempdb', SchemaName = 'TableAliasRenaming', TableName = 'Case03', ColumnName = '', AliasName = 'TAR3' 
UNION ALL SELECT DatabaseName = '%', SchemaName = '%', TableName = 'Case04', ColumnName = '', AliasName = 'TAR4' 

UNION ALL SELECT DatabaseName = 'msdb', SchemaName = 'SchemaAliasRenaming01', TableName = '', ColumnName = '', AliasName = 'SAR01' 
UNION ALL SELECT DatabaseName = 'tempdb', SchemaName = 'SchemaAliasRenaming02', TableName = '', ColumnName = '', AliasName = 'SAR02'
UNION ALL SELECT DatabaseName = '%', SchemaName = 'SchemaAliasRenaming03', TableName = '', ColumnName = '', AliasName = 'SAR03'

UNION ALL SELECT DatabaseName = 'msdb', SchemaName = 'AliasRenaming01', TableName = '', ColumnName = '', AliasName = 'AR01' 
UNION ALL SELECT DatabaseName = 'msdb', SchemaName = 'AliasRenaming01', TableName = 'Case01', ColumnName = '', AliasName = 'AR02' 
UNION ALL SELECT DatabaseName = 'msdb', SchemaName = 'AliasRenaming01', TableName = 'Case01', ColumnName = 'ProductNo', AliasName = 'AR03' 
UNION ALL SELECT DatabaseName = 'tempdb', SchemaName = 'AliasRenaming02', TableName = '', ColumnName = '', AliasName = 'AR04'
UNION ALL SELECT DatabaseName = 'tempdb', SchemaName = 'AliasRenaming02', TableName = 'Case01', ColumnName = '', AliasName = 'AR05'
UNION ALL SELECT DatabaseName = 'tempdb', SchemaName = 'AliasRenaming02', TableName = 'Case01', ColumnName = 'ProductNo', AliasName = 'AR06'
UNION ALL SELECT DatabaseName = 'tempdb', SchemaName = 'AliasRenaming02', TableName = 'Case02', ColumnName = '', AliasName = 'AR07'
UNION ALL SELECT DatabaseName = 'tempdb', SchemaName = 'AliasRenaming02', TableName = 'Case02', ColumnName = 'ProductNo', AliasName = 'AR08'
UNION ALL SELECT DatabaseName = '%', SchemaName = 'AliasRenaming03', TableName = '', ColumnName = '', AliasName = 'AR09'
UNION ALL SELECT DatabaseName = '%', SchemaName = 'AliasRenaming03', TableName = 'Case01', ColumnName = '', AliasName = 'AR10'
UNION ALL SELECT DatabaseName = '%', SchemaName = 'AliasRenaming03', TableName = 'Case01', ColumnName = 'ProductNo', AliasName = 'AR11'
UNION ALL SELECT DatabaseName = '%', SchemaName = 'AliasRenaming03', TableName = 'Case02', ColumnName = '', AliasName = 'AR12'
UNION ALL SELECT DatabaseName = '%', SchemaName = 'AliasRenaming03', TableName = 'Case02', ColumnName = 'ProductNo', AliasName = 'AR13'


-- #######################################################################################
-- ###### Create a table for all schemas in test data
-- #######################################################################################
IF (OBJECT_ID('#TestSchemas', 'U') IS NOT NULL) DROP TABLE #TestSchemas 
CREATE TABLE #TestSchemas  
(
  IndexNo INT IDENTITY,
  SchemaName sysname NOT NULL
)

-- #######################################################################################
-- ###### Create a table containing all test tables
-- #######################################################################################
IF (OBJECT_ID('#TestTables', 'U') IS NOT NULL) DROP TABLE #TestTables 
CREATE TABLE #TestTables  
(
  TestNo INT IDENTITY PRIMARY KEY NOT NULL,
  SchemaName sysname NOT NULL,
  TableName sysname NOT NULL,
  ColumnName sysname NOT NULL,
  CheckName sysname NOT NULL,
  IsEnabled BIT NOT NULL DEFAULT 1,
  IsForReplication BIT NOT NULL DEFAULT 1,
  IsTrusted BIT NOT NULL DEFAULT 1,
  ObjectName AS QUOTENAME(SchemaName) + '.' + QUOTENAME(TableName)  
)

-- #######################################################################################
-- ###### Insert all test cases into the test case table
-- #######################################################################################
INSERT #TestTables ( SchemaName, TableName, ColumnName, CheckName )
          SELECT SchemaName = 'FromSpecialChar', TableName = 'Case01', ColumnName = 'ProductNo', CheckName = 'CheckConstraint_'
UNION ALL SELECT SchemaName = 'FromSpecialChar', TableName = 'Case02', ColumnName = 'ProductNo', CheckName = ' CheckConstraint'
UNION ALL SELECT SchemaName = 'FromSpecialChar', TableName = 'Case03', ColumnName = 'ProductNo', CheckName = 'CheckConstraint '
UNION ALL SELECT SchemaName = 'FromSpecialChar', TableName = 'Case04', ColumnName = 'ProductNo', CheckName = 'CheckConstraint?'
UNION ALL SELECT SchemaName = 'FromSpecialChar', TableName = 'Case05', ColumnName = 'ProductNo', CheckName = 'CheckConstraint%'
UNION ALL SELECT SchemaName = 'FromSpecialChar', TableName = 'Case06', ColumnName = 'ProductNo', CheckName = 'CheckConstraint^'
UNION ALL SELECT SchemaName = 'FromSpecialChar', TableName = 'Case07', ColumnName = 'ProductNo', CheckName = 'CheckConstraint'''
UNION ALL SELECT SchemaName = 'FromSpecialChar', TableName = 'Case08', ColumnName = 'ProductNo', CheckName = 'CheckConstraint"'
UNION ALL SELECT SchemaName = 'FromSpecialChar', TableName = 'Case09', ColumnName = 'ProductNo', CheckName = 'CheckConstraint,'
UNION ALL SELECT SchemaName = 'FromSpecialChar', TableName = 'Case10', ColumnName = 'ProductNo', CheckName = 'CheckConstraint.'
UNION ALL SELECT SchemaName = 'FromSpecialChar', TableName = 'Case11', ColumnName = 'ProductNo', CheckName = 'CheckConstraint*'
UNION ALL SELECT SchemaName = 'FromSpecialChar', TableName = 'Case12', ColumnName = 'ProductNo', CheckName = 'CheckConstraint['
UNION ALL SELECT SchemaName = 'FromSpecialChar', TableName = 'Case13', ColumnName = 'ProductNo', CheckName = 'CheckConstraint]'
UNION ALL SELECT SchemaName = 'FromSpecialChar', TableName = 'Case14', ColumnName = 'ProductNo', CheckName = 'CheckConstraint-'
UNION ALL SELECT SchemaName = 'FromSpecialChar', TableName = 'Case15', ColumnName = 'ProductNo', CheckName = 'CheckConstraint+'
UNION ALL SELECT SchemaName = 'FromSpecialChar', TableName = 'Case16', ColumnName = 'ProductNo', CheckName = '"CheckConstraint"'
UNION ALL SELECT SchemaName = 'FromSpecialChar', TableName = 'Case17', ColumnName = 'ProductNo', CheckName = '[CheckConstraint]'
UNION ALL SELECT SchemaName = 'FromSpecialChar', TableName = 'Case18', ColumnName = 'ProductNo', CheckName = '''CheckConstraint'''
UNION ALL SELECT SchemaName = 'FromSpecialChar', TableName = 'Case19', ColumnName = 'ProductNo', CheckName = 'Check.Constraint'
UNION ALL SELECT SchemaName = 'FromSpecialChar', TableName = 'Case20', ColumnName = 'ProductNo', CheckName = 'Check Constraint'

UNION ALL SELECT SchemaName = 'ToSpecialChar', TableName = 'Case01', ColumnName = 'ProductNo_', CheckName = 'CheckConstraint_'
UNION ALL SELECT SchemaName = 'ToSpecialChar', TableName = 'Case02', ColumnName = ' ProductNo', CheckName = ' CheckConstraint'
UNION ALL SELECT SchemaName = 'ToSpecialChar', TableName = 'Case03', ColumnName = 'ProductNo ', CheckName = 'CheckConstraint '
UNION ALL SELECT SchemaName = 'ToSpecialChar', TableName = 'Case04', ColumnName = 'ProductNo?', CheckName = 'CheckConstraint?'
UNION ALL SELECT SchemaName = 'ToSpecialChar', TableName = 'Case05', ColumnName = 'ProductNo%', CheckName = 'CheckConstraint%'
UNION ALL SELECT SchemaName = 'ToSpecialChar', TableName = 'Case06', ColumnName = 'ProductNo^', CheckName = 'CheckConstraint^'
UNION ALL SELECT SchemaName = 'ToSpecialChar', TableName = 'Case07', ColumnName = 'ProductNo''', CheckName = 'CheckConstraint'''
UNION ALL SELECT SchemaName = 'ToSpecialChar', TableName = 'Case08', ColumnName = 'ProductNo"', CheckName = 'CheckConstraint"'
UNION ALL SELECT SchemaName = 'ToSpecialChar', TableName = 'Case09', ColumnName = 'ProductNo,', CheckName = 'CheckConstraint,'
UNION ALL SELECT SchemaName = 'ToSpecialChar', TableName = 'Case10', ColumnName = 'ProductNo.', CheckName = 'CheckConstraint.'
UNION ALL SELECT SchemaName = 'ToSpecialChar', TableName = 'Case11', ColumnName = 'ProductNo*', CheckName = 'CheckConstraint*'
UNION ALL SELECT SchemaName = 'ToSpecialChar', TableName = 'Case12', ColumnName = 'ProductNo[', CheckName = 'CheckConstraint['
UNION ALL SELECT SchemaName = 'ToSpecialChar', TableName = 'Case13', ColumnName = 'ProductNo]', CheckName = 'CheckConstraint]'
UNION ALL SELECT SchemaName = 'ToSpecialChar', TableName = 'Case14', ColumnName = 'ProductNo-', CheckName = 'CheckConstraint-'
UNION ALL SELECT SchemaName = 'ToSpecialChar', TableName = 'Case15', ColumnName = 'ProductNo+', CheckName = 'CheckConstraint+'
UNION ALL SELECT SchemaName = 'ToSpecialChar', TableName = 'Case16', ColumnName = '"ProductNo"', CheckName = '"CheckConstraint"'
UNION ALL SELECT SchemaName = 'ToSpecialChar', TableName = 'Case17', ColumnName = '[ProductNo]', CheckName = '[CheckConstraint]'
UNION ALL SELECT SchemaName = 'ToSpecialChar', TableName = 'Case18', ColumnName = '''ProductNo''', CheckName = '''CheckConstraint'''
UNION ALL SELECT SchemaName = 'ToSpecialChar', TableName = 'Case19', ColumnName = 'Product.Name', CheckName = 'Check.Constraint'
UNION ALL SELECT SchemaName = 'ToSpecialChar', TableName = 'Case20', ColumnName = 'Product Name', CheckName = 'Check Constraint'

UNION ALL SELECT SchemaName = 'FilteredRenaming', TableName = 'Case01', ColumnName = 'ProductNo', CheckName = 'CheckName01'
UNION ALL SELECT SchemaName = 'FilteredRenaming', TableName = 'Case02', ColumnName = 'ProductNo', CheckName = 'CheckName02'
UNION ALL SELECT SchemaName = 'FilteredRenaming', TableName = 'Case03', ColumnName = 'ProductNo', CheckName = 'CheckName03'
UNION ALL SELECT SchemaName = 'FilteredRenaming', TableName = 'Case04', ColumnName = 'ProductNo', CheckName = 'CheckName04'

UNION ALL SELECT SchemaName = 'CustomRenaming', TableName = 'Case01', ColumnName = 'ProductNo', CheckName = 'CheckName01'
UNION ALL SELECT SchemaName = 'CustomRenaming', TableName = 'Case02', ColumnName = 'ProductNo', CheckName = 'CheckName02'
UNION ALL SELECT SchemaName = 'CustomRenaming', TableName = 'Case03', ColumnName = 'ProductNo', CheckName = 'CheckName03'
UNION ALL SELECT SchemaName = 'CustomRenaming', TableName = 'Case04', ColumnName = 'ProductNo', CheckName = 'CheckName04'

UNION ALL SELECT SchemaName = 'MaxNameLength&Truncate', TableName = 'Case01', ColumnName = 'ProductNo', CheckName = 'CheckName01'
UNION ALL SELECT SchemaName = 'MaxNameLength&Skip', TableName = 'Case01', ColumnName = 'ProductNo', CheckName = 'CheckName01'
UNION ALL SELECT SchemaName = 'UniquifyCheckConstraints', TableName = 'Case01', ColumnName = 'ProductNo', CheckName = 'CheckName01'
UNION ALL SELECT SchemaName = 'UniquifyCheckConstraints', TableName = 'Case02', ColumnName = 'ProductNo', CheckName = 'CheckName02'
UNION ALL SELECT SchemaName = 'UniquifyCheckConstraints', TableName = 'Case03', ColumnName = 'ProductNo', CheckName = 'CheckName03'
UNION ALL SELECT SchemaName = 'UniquifyCheckConstraints', TableName = 'Case04', ColumnName = 'ProductNo', CheckName = 'CheckName04'

UNION ALL SELECT SchemaName = 'CasingRenaming', TableName = 'Case01', ColumnName = 'ProductNo', CheckName = 'CK_Case01_ProductNo'
UNION ALL SELECT SchemaName = 'CasingRenaming', TableName = 'Case02', ColumnName = 'ProductNo', CheckName = 'CK_Case02_ProductNo'

UNION ALL SELECT SchemaName = 'ColumnAliasRenaming', TableName = 'Case01', ColumnName = 'ProductNo', CheckName = 'CK_Case01_ProductNo'
UNION ALL SELECT SchemaName = 'ColumnAliasRenaming', TableName = 'Case02', ColumnName = 'ProductNo', CheckName = 'CK_Case02_ProductNo'
UNION ALL SELECT SchemaName = 'ColumnAliasRenaming', TableName = 'Case03', ColumnName = 'ProductNo', CheckName = 'CK_Case03_ProductNo'

UNION ALL SELECT SchemaName = 'TableAliasRenaming', TableName = 'Case01', ColumnName = 'ProductNo', CheckName = 'CK_Case01_ProductNo'
UNION ALL SELECT SchemaName = 'TableAliasRenaming', TableName = 'Case02', ColumnName = 'ProductNo', CheckName = 'CK_Case02_ProductNo'
UNION ALL SELECT SchemaName = 'TableAliasRenaming', TableName = 'Case03', ColumnName = 'ProductNo', CheckName = 'CK_Case03_ProductNo'
UNION ALL SELECT SchemaName = 'TableAliasRenaming', TableName = 'Case04', ColumnName = 'ProductNo', CheckName = 'CK_Case04_ProductNo'

UNION ALL SELECT SchemaName = 'SchemaAliasRenaming01', TableName = 'Case01', ColumnName = 'ProductNo', CheckName = 'CK_Case01_ProductNo'
UNION ALL SELECT SchemaName = 'SchemaAliasRenaming02', TableName = 'Case02', ColumnName = 'ProductNo', CheckName = 'CK_Case02_ProductNo'
UNION ALL SELECT SchemaName = 'SchemaAliasRenaming03', TableName = 'Case03', ColumnName = 'ProductNo', CheckName = 'CK_Case03_ProductNo'

UNION ALL SELECT SchemaName = 'AliasRenaming01', TableName = 'Case01', ColumnName = 'ProductNo', CheckName = 'CK_Case01_ProductNo'
UNION ALL SELECT SchemaName = 'AliasRenaming01', TableName = 'Case02', ColumnName = 'ProductNo', CheckName = 'CK_Case02_ProductNo'
UNION ALL SELECT SchemaName = 'AliasRenaming01', TableName = 'Case03', ColumnName = 'ProductNo', CheckName = 'CK_Case03_ProductNo'
UNION ALL SELECT SchemaName = 'AliasRenaming02', TableName = 'Case01', ColumnName = 'ProductNo', CheckName = 'CK_Case01_ProductNo'
UNION ALL SELECT SchemaName = 'AliasRenaming02', TableName = 'Case02', ColumnName = 'ProductNo', CheckName = 'CK_Case02_ProductNo'
UNION ALL SELECT SchemaName = 'AliasRenaming02', TableName = 'Case03', ColumnName = 'ProductNo', CheckName = 'CK_Case03_ProductNo'
UNION ALL SELECT SchemaName = 'AliasRenaming03', TableName = 'Case01', ColumnName = 'ProductNo', CheckName = 'CK_Case01_ProductNo'
UNION ALL SELECT SchemaName = 'AliasRenaming03', TableName = 'Case02', ColumnName = 'ProductNo', CheckName = 'CK_Case02_ProductNo'
UNION ALL SELECT SchemaName = 'AliasRenaming03', TableName = 'Case03', ColumnName = 'ProductNo', CheckName = 'CK_Case03_ProductNo'

INSERT #TestTables ( SchemaName, TableName, ColumnName, CheckName, IsEnabled )
          SELECT SchemaName = 'EnabledStateRenaming', TableName = 'Case01', ColumnName = 'ProductNo', CheckName = 'CK_Case01_ProductNo', IsEnabled = 1
UNION ALL SELECT SchemaName = 'EnabledStateRenaming', TableName = 'Case02', ColumnName = 'ProductNo', CheckName = 'CK_Case02_ProductNo', IsEnabled = 0

INSERT #TestTables ( SchemaName, TableName, ColumnName, CheckName, IsForReplication )
          SELECT SchemaName = 'ReplicationStateRenaming', TableName = 'Case01', ColumnName = 'ProductNo', CheckName = 'CK_Case01_ProductNo', IsForReplication = 1
UNION ALL SELECT SchemaName = 'ReplicationStateRenaming', TableName = 'Case02', ColumnName = 'ProductNo', CheckName = 'CK_Case02_ProductNo', IsForReplication = 0

INSERT #TestTables ( SchemaName, TableName, ColumnName, CheckName, IsTrusted)
          SELECT SchemaName = 'TrustedStateRenaming', TableName = 'Case01', ColumnName = 'ProductNo', CheckName = 'CK_Case01_ProductNo', IsTrusted = 1
UNION ALL SELECT SchemaName = 'TrustedStateRenaming', TableName = 'Case02', ColumnName = 'ProductNo', CheckName = 'CK_Case02_ProductNo', IsTrusted = 0


-- #######################################################################################
-- ###### Create a table with all schemas used by the test cases
-- #######################################################################################
INSERT INTO #TestSchemas (SchemaName)
SELECT DISTINCT SchemaName FROM #TestTables WHERE SchemaName != 'dbo'

-- #######################################################################################
-- ###### Create a table containing all test cases
-- #######################################################################################
IF (OBJECT_ID('tempdb..#TestCases', 'U') IS NOT NULL) DROP TABLE #TestCases 
CREATE TABLE #TestCases  
(
  TestNo INT IDENTITY PRIMARY KEY NOT NULL,
  TestDesc NVARCHAR(MAX) NOT NULL,
  FilterSchema NVARCHAR(MAX) NULL,
  FilterTable NVARCHAR(MAX) NULL,
  NamingConvention NVARCHAR(MAX) NULL,
  OversizedMode NCHAR(1) NULL,
  ForceCaseSensitivity BIT NULL,
  UseAliases CHAR(3) NULL,
  MaxNameLength TINYINT NULL,
  UniquifyNames BIT NULL,
  EnabledStates NVARCHAR(MAX),
  ReplicationStates NVARCHAR(MAX),
  TrustedStates NVARCHAR(MAX),
  Expected NVARCHAR(MAX) NOT NULL,
)

-- #######################################################################################
-- ###### Insert all test cases into the test case table
-- #######################################################################################

INSERT #TestCases( TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Check constraint renaming from a name with "_" in it', FilterSchema = 'FromSpecialChar', FilterTable = 'Case01', Expected = '[FromSpecialChar].[Case01].[ProductNo].[CK_Case01_ProductNo]'
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Check constraint renaming from a name with leading space', FilterSchema = 'FromSpecialChar', FilterTable = 'Case02', Expected = '[FromSpecialChar].[Case02].[ProductNo].[CK_Case02_ProductNo]'
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Check constraint renaming from a name with trailing space', FilterSchema = 'FromSpecialChar', FilterTable = 'Case03', Expected = '[FromSpecialChar].[Case03].[ProductNo].[CK_Case03_ProductNo]'
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Check constraint renaming from a name with "?" in it', FilterSchema = 'FromSpecialChar', FilterTable = 'Case04', Expected = '[FromSpecialChar].[Case04].[ProductNo].[CK_Case04_ProductNo]'
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Check constraint renaming from a name with "%" in it', FilterSchema = 'FromSpecialChar', FilterTable = 'Case05', Expected = '[FromSpecialChar].[Case05].[ProductNo].[CK_Case05_ProductNo]'
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Check constraint renaming from a name with "^" in it', FilterSchema = 'FromSpecialChar', FilterTable = 'Case06', Expected = '[FromSpecialChar].[Case06].[ProductNo].[CK_Case06_ProductNo]'
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Check constraint renaming from a name with "''" in it', FilterSchema = 'FromSpecialChar', FilterTable = 'Case07', Expected = '[FromSpecialChar].[Case07].[ProductNo].[CK_Case07_ProductNo]'
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Check constraint renaming from a name with """ in it', FilterSchema = 'FromSpecialChar', FilterTable = 'Case08', Expected = '[FromSpecialChar].[Case08].[ProductNo].[CK_Case08_ProductNo]'
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Check constraint renaming from a name with "," in it', FilterSchema = 'FromSpecialChar', FilterTable = 'Case09', Expected = '[FromSpecialChar].[Case09].[ProductNo].[CK_Case09_ProductNo]'
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Check constraint renaming from a name with "." in it', FilterSchema = 'FromSpecialChar', FilterTable = 'Case10', Expected = '[FromSpecialChar].[Case10].[ProductNo].[CK_Case10_ProductNo]'
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Check constraint renaming from a name with "*" in it', FilterSchema = 'FromSpecialChar', FilterTable = 'Case11', Expected = '[FromSpecialChar].[Case11].[ProductNo].[CK_Case11_ProductNo]'
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Check constraint renaming from a name with "[" in it', FilterSchema = 'FromSpecialChar', FilterTable = 'Case12', Expected = '[FromSpecialChar].[Case12].[ProductNo].[CK_Case12_ProductNo]'
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Check constraint renaming from a name with "]" in it', FilterSchema = 'FromSpecialChar', FilterTable = 'Case13', Expected = '[FromSpecialChar].[Case13].[ProductNo].[CK_Case13_ProductNo]'
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Check constraint renaming from a name with "-" in it', FilterSchema = 'FromSpecialChar', FilterTable = 'Case14', Expected = '[FromSpecialChar].[Case14].[ProductNo].[CK_Case14_ProductNo]'
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Check constraint renaming from a name with "+" in it', FilterSchema = 'FromSpecialChar', FilterTable = 'Case15', Expected = '[FromSpecialChar].[Case15].[ProductNo].[CK_Case15_ProductNo]'
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Check constraint renaming from a name surrouned with ""', FilterSchema = 'FromSpecialChar', FilterTable = 'Case16', Expected = '[FromSpecialChar].[Case16].[ProductNo].[CK_Case16_ProductNo]'
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Check constraint renaming from a name surrouned with []', FilterSchema = 'FromSpecialChar', FilterTable = 'Case17', Expected = '[FromSpecialChar].[Case17].[ProductNo].[CK_Case17_ProductNo]'
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Check constraint renaming from a name surrouned with ''''', FilterSchema = 'FromSpecialChar', FilterTable = 'Case18', Expected = '[FromSpecialChar].[Case18].[ProductNo].[CK_Case18_ProductNo]'
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Check constraint renaming from a name with "." in the middle', FilterSchema = 'FromSpecialChar', FilterTable = 'Case19', Expected = '[FromSpecialChar].[Case19].[ProductNo].[CK_Case19_ProductNo]'
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Check constraint renaming from a name with " " in the middle', FilterSchema = 'FromSpecialChar', FilterTable = 'Case20', Expected = '[FromSpecialChar].[Case20].[ProductNo].[CK_Case20_ProductNo]'

INSERT #TestCases( TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Check constraint renaming to a name with "_" in it', FilterSchema = 'ToSpecialChar', FilterTable = 'Case01', Expected = '[ToSpecialChar].[Case01].[ProductNo_].[CK_Case01_ProductNo_]'
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Check constraint renaming to a name with leading space', FilterSchema = 'ToSpecialChar', FilterTable = 'Case02', Expected = '[ToSpecialChar].[Case02].[ ProductNo].[CK_Case02_ ProductNo]'
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Check constraint renaming to a name with trailing space', FilterSchema = 'ToSpecialChar', FilterTable = 'Case03', Expected = '[ToSpecialChar].[Case03].[ProductNo ].[CK_Case03_ProductNo ]'
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Check constraint renaming to a name with "?" in it', FilterSchema = 'ToSpecialChar', FilterTable = 'Case04', Expected = '[ToSpecialChar].[Case04].[ProductNo?].[CK_Case04_ProductNo?]'
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Check constraint renaming to a name with "%" in it', FilterSchema = 'ToSpecialChar', FilterTable = 'Case05', Expected = '[ToSpecialChar].[Case05].[ProductNo%].[CK_Case05_ProductNo%]'
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Check constraint renaming to a name with "^" in it', FilterSchema = 'ToSpecialChar', FilterTable = 'Case06', Expected = '[ToSpecialChar].[Case06].[ProductNo^].[CK_Case06_ProductNo^]'
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Check constraint renaming to a name with "''" in it', FilterSchema = 'ToSpecialChar', FilterTable = 'Case07', Expected = '[ToSpecialChar].[Case07].[ProductNo''].[CK_Case07_ProductNo'']'
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Check constraint renaming to a name with """ in it', FilterSchema = 'ToSpecialChar', FilterTable = 'Case08', Expected = '[ToSpecialChar].[Case08].[ProductNo"].[CK_Case08_ProductNo"]'
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Check constraint renaming to a name with "," in it', FilterSchema = 'ToSpecialChar', FilterTable = 'Case09', Expected = '[ToSpecialChar].[Case09].[ProductNo,].[CK_Case09_ProductNo,]'
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Check constraint renaming to a name with "." in it', FilterSchema = 'ToSpecialChar', FilterTable = 'Case10', Expected = '[ToSpecialChar].[Case10].[ProductNo.].[CK_Case10_ProductNo.]'
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Check constraint renaming to a name with "*" in it', FilterSchema = 'ToSpecialChar', FilterTable = 'Case11', Expected = '[ToSpecialChar].[Case11].[ProductNo*].[CK_Case11_ProductNo*]'
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Check constraint renaming to a name with "[" in it', FilterSchema = 'ToSpecialChar', FilterTable = 'Case12', Expected = '[ToSpecialChar].[Case12].[ProductNo[].[CK_Case12_ProductNo[]'
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Check constraint renaming to a name with "]" in it', FilterSchema = 'ToSpecialChar', FilterTable = 'Case13', Expected = '[ToSpecialChar].[Case13].[ProductNo]]].[CK_Case13_ProductNo]]]'
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Check constraint renaming to a name with "-" in it', FilterSchema = 'ToSpecialChar', FilterTable = 'Case14', Expected = '[ToSpecialChar].[Case14].[ProductNo-].[CK_Case14_ProductNo-]'
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Check constraint renaming to a name with "+" in it', FilterSchema = 'ToSpecialChar', FilterTable = 'Case15', Expected = '[ToSpecialChar].[Case15].[ProductNo+].[CK_Case15_ProductNo+]'
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Check constraint renaming to a name surrouned with ""', FilterSchema = 'ToSpecialChar', FilterTable = 'Case16', Expected = '[ToSpecialChar].[Case16].["ProductNo"].[CK_Case16_"ProductNo"]'
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Check constraint renaming to a name surrouned with []', FilterSchema = 'ToSpecialChar', FilterTable = 'Case17', Expected = '[ToSpecialChar].[Case17].[[ProductNo]]].[CK_Case17_[ProductNo]]]'
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Check constraint renaming to a name surrouned with ''''', FilterSchema = 'ToSpecialChar', FilterTable = 'Case18', Expected = '[ToSpecialChar].[Case18].[''ProductNo''].[CK_Case18_''ProductNo'']'
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Check constraint renaming to a name with "." in the middle', FilterSchema = 'ToSpecialChar', FilterTable = 'Case19', Expected = '[ToSpecialChar].[Case19].[Product.Name].[CK_Case19_Product.Name]'
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Check constraint renaming to a name with " " in the middle', FilterSchema = 'ToSpecialChar', FilterTable = 'Case20', Expected = '[ToSpecialChar].[Case20].[Product Name].[CK_Case20_Product Name]'

INSERT #TestCases( TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Check constraint renaming - filtered ', FilterSchema = 'FilteredRenaming', FilterTable = '%', Expected = '[FilteredRenaming].[Case01].[ProductNo].[CK_Case01_ProductNo];[FilteredRenaming].[Case02].[ProductNo].[CK_Case02_ProductNo];[FilteredRenaming].[Case03].[ProductNo].[CK_Case03_ProductNo];[FilteredRenaming].[Case04].[ProductNo].[CK_Case04_ProductNo]'
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, NamingConvention, Expected) SELECT TestDesc = 'Check constraint renaming - custom naming convention', FilterSchema = 'CustomRenaming', FilterTable = '%', NamingConvention = 'CK_%SCHEMA_NAME%_%TABLE_NAME%_%COLUMN_NAME%', Expected = '[CustomRenaming].[Case01].[ProductNo].[CK_CustomRenaming_Case01_ProductNo];[CustomRenaming].[Case02].[ProductNo].[CK_CustomRenaming_Case02_ProductNo];[CustomRenaming].[Case03].[ProductNo].[CK_CustomRenaming_Case03_ProductNo];[CustomRenaming].[Case04].[ProductNo].[CK_CustomRenaming_Case04_ProductNo]'
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, OversizedMode, MaxNameLength, Expected) SELECT TestDesc = 'Check constraint renaming - oversized mode skip', FilterSchema = 'MaxNameLength&Skip', FilterTable = '%', OversizedMode = 'S', MaxNameLength = 10, Expected = '[MaxNameLength&Skip].[Case01].[ProductNo].[CheckName01]'
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, OversizedMode, MaxNameLength, Expected) SELECT TestDesc = 'Check constraint renaming - oversized mode truncate', FilterSchema = 'MaxNameLength&Truncate', FilterTable = '%', OversizedMode = 'T', MaxNameLength = 10, Expected = '[MaxNameLength&Truncate].[Case01].[ProductNo].[CK_Case01_]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, UniquifyNames, NamingConvention, Expected) SELECT TestDesc = 'Check constraint renaming with uniquifying constraint names', FilterSchema = 'UniquifyCheckConstraints', FilterTable = '%', UniquifyNames = 1, NamingConvention = 'CK_%COLUMN_NAME%', Expected = '[UniquifyCheckConstraints].[Case01].[ProductNo].[CK_ProductNo];[UniquifyCheckConstraints].[Case02].[ProductNo].[CK_ProductNo2];[UniquifyCheckConstraints].[Case03].[ProductNo].[CK_ProductNo3];[UniquifyCheckConstraints].[Case04].[ProductNo].[CK_ProductNo4]'
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, ForceCaseSensitivity, Expected) SELECT TestDesc = 'Check constraint renaming - case sensitivity differences', FilterSchema = 'CasingRenaming', FilterTable = 'Case01', ForceCaseSensitivity = 0, Expected = '[CasingRenaming].[Case01].[ProductNo].[CK_Case01_ProductNo]' WHERE @DBIsCaseSensitive = 0
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, ForceCaseSensitivity, Expected) SELECT TestDesc = 'Check constraint renaming - case sensitivity differences', FilterSchema = 'CasingRenaming', FilterTable = 'Case01', ForceCaseSensitivity = 0, Expected = '[CasingRenaming].[Case01].[ProductNo].[CK_Case01_ProductNo]'  WHERE @DBIsCaseSensitive = 1
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, ForceCaseSensitivity, Expected) SELECT TestDesc = 'Check constraint renaming - force case sensitivity differences', FilterSchema = 'CasingRenaming', FilterTable = 'Case02', ForceCaseSensitivity = 1, Expected = '[CasingRenaming].[Case02].[ProductNo].[CK_Case02_ProductNo]'

INSERT #TestCases (TestDesc, FilterSchema, FilterTable, UseAliases, Expected) SELECT TestDesc = 'Check constraint renaming with column aliasing', FilterSchema = 'ColumnAliasRenaming', FilterTable = 'Case01', UseAliases = 'C', Expected = '[ColumnAliasRenaming].[Case01].[ProductNo].[CK_Case01_CAR1]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, UseAliases, Expected) SELECT TestDesc = 'Check constraint renaming with column aliasing', FilterSchema = 'ColumnAliasRenaming', FilterTable = 'Case02', UseAliases = 'C', Expected = '[ColumnAliasRenaming].[Case02].[ProductNo].[CK_Case02_CAR2]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, UseAliases, Expected) SELECT TestDesc = 'Check constraint renaming with column aliasing', FilterSchema = 'ColumnAliasRenaming', FilterTable = 'Case03', UseAliases = 'C', Expected = '[ColumnAliasRenaming].[Case03].[ProductNo].[CK_Case03_CAR3]'

INSERT #TestCases (TestDesc, FilterSchema, FilterTable, UseAliases, Expected) SELECT TestDesc = 'Check constraint renaming with table aliasing', FilterSchema = 'TableAliasRenaming', FilterTable = 'Case01', UseAliases = 'T', Expected = '[TableAliasRenaming].[Case01].[ProductNo].[CK_TAR1_ProductNo]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, UseAliases, Expected) SELECT TestDesc = 'Check constraint renaming with table aliasing', FilterSchema = 'TableAliasRenaming', FilterTable = 'Case02', UseAliases = 'T', Expected = '[TableAliasRenaming].[Case02].[ProductNo].[CK_TAR2_ProductNo]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, UseAliases, Expected) SELECT TestDesc = 'Check constraint renaming with table aliasing', FilterSchema = 'TableAliasRenaming', FilterTable = 'Case03', UseAliases = 'T', Expected = '[TableAliasRenaming].[Case03].[ProductNo].[CK_TAR3_ProductNo]'
                                                                                                                                                                                                                                                                                            
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, UseAliases, NamingConvention, Expected) SELECT TestDesc = 'Check constraint renaming with schema aliasing', FilterSchema = 'SchemaAliasRenaming01', FilterTable = 'Case01', UseAliases = 'S', NamingConvention = 'CK_%SCHEMA_NAME%_%TABLE_NAME%_%COLUMN_NAME%', Expected = '[SchemaAliasRenaming01].[Case01].[ProductNo].[CK_SchemaAliasRenaming01_Case01_ProductNo]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, UseAliases, NamingConvention, Expected) SELECT TestDesc = 'Check constraint renaming with schema aliasing', FilterSchema = 'SchemaAliasRenaming02', FilterTable = 'Case02', UseAliases = 'S', NamingConvention = 'CK_%SCHEMA_NAME%_%TABLE_NAME%_%COLUMN_NAME%', Expected = '[SchemaAliasRenaming02].[Case02].[ProductNo].[CK_SAR02_Case02_ProductNo]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, UseAliases, NamingConvention, Expected) SELECT TestDesc = 'Check constraint renaming with schema aliasing', FilterSchema = 'SchemaAliasRenaming03', FilterTable = 'Case03', UseAliases = 'S', NamingConvention = 'CK_%SCHEMA_NAME%_%TABLE_NAME%_%COLUMN_NAME%', Expected = '[SchemaAliasRenaming03].[Case03].[ProductNo].[CK_SAR03_Case03_ProductNo]'

INSERT #TestCases (TestDesc, FilterSchema, FilterTable, UseAliases, NamingConvention, Expected) SELECT TestDesc = 'Check constraint renaming with aliasing, wrong database rules, no alias match', FilterSchema = 'AliasRenaming01', FilterTable = 'Case01', UseAliases = 'STC', NamingConvention = 'CK_%SCHEMA_NAME%_%TABLE_NAME%_%COLUMN_NAME%', Expected = '[AliasRenaming01].[Case01].[ProductNo].[CK_AliasRenaming01_Case01_ProductNo]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, UseAliases, NamingConvention, Expected) SELECT TestDesc = 'Check constraint renaming with aliasing, wrong database rules, no alias match', FilterSchema = 'AliasRenaming01', FilterTable = 'Case02', UseAliases = 'STC', NamingConvention = 'CK_%SCHEMA_NAME%_%TABLE_NAME%_%COLUMN_NAME%', Expected = '[AliasRenaming01].[Case02].[ProductNo].[CK_AliasRenaming01_Case02_ProductNo]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, UseAliases, NamingConvention, Expected) SELECT TestDesc = 'Check constraint renaming with aliasing, wrong database rules, no alias match', FilterSchema = 'AliasRenaming01', FilterTable = 'Case03', UseAliases = 'STC', NamingConvention = 'CK_%SCHEMA_NAME%_%TABLE_NAME%_%COLUMN_NAME%', Expected = '[AliasRenaming01].[Case03].[ProductNo].[CK_AliasRenaming01_Case03_ProductNo]'

INSERT #TestCases (TestDesc, FilterSchema, FilterTable, UseAliases, NamingConvention, Expected) SELECT TestDesc = 'Check constraint renaming with aliasing, specific database rules, match schema, table, column #1', FilterSchema = 'AliasRenaming02', FilterTable = 'Case01', UseAliases = 'STC', NamingConvention = 'CK_%SCHEMA_NAME%_%TABLE_NAME%_%COLUMN_NAME%', Expected = '[AliasRenaming02].[Case01].[ProductNo].[CK_AR04_AR05_AR06]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, UseAliases, NamingConvention, Expected) SELECT TestDesc = 'Check constraint renaming with aliasing, specific database rules, match schema, table, column #2', FilterSchema = 'AliasRenaming02', FilterTable = 'Case02', UseAliases = 'STC', NamingConvention = 'CK_%SCHEMA_NAME%_%TABLE_NAME%_%COLUMN_NAME%', Expected = '[AliasRenaming02].[Case02].[ProductNo].[CK_AR04_AR07_AR08]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, UseAliases, NamingConvention, Expected) SELECT TestDesc = 'Check constraint renaming with aliasing, specific database rules, match schema', FilterSchema = 'AliasRenaming02', FilterTable = 'Case03', UseAliases = 'STC', NamingConvention = 'CK_%SCHEMA_NAME%_%TABLE_NAME%_%COLUMN_NAME%', Expected = '[AliasRenaming02].[Case03].[ProductNo].[CK_AR04_Case03_ProductNo]'

INSERT #TestCases (TestDesc, FilterSchema, FilterTable, UseAliases, NamingConvention, Expected) SELECT TestDesc = 'Check constraint renaming with aliasing, generic database rules, match schema, table, column #1', FilterSchema = 'AliasRenaming03', FilterTable = 'Case01', UseAliases = 'STC', NamingConvention = 'CK_%SCHEMA_NAME%_%TABLE_NAME%_%COLUMN_NAME%', Expected = '[AliasRenaming03].[Case01].[ProductNo].[CK_AR09_AR10_AR11]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, UseAliases, NamingConvention, Expected) SELECT TestDesc = 'Check constraint renaming with aliasing, generic database rules, match schema, table, column #2', FilterSchema = 'AliasRenaming03', FilterTable = 'Case02', UseAliases = 'STC', NamingConvention = 'CK_%SCHEMA_NAME%_%TABLE_NAME%_%COLUMN_NAME%', Expected = '[AliasRenaming03].[Case02].[ProductNo].[CK_AR09_AR12_AR13]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, UseAliases, NamingConvention, Expected) SELECT TestDesc = 'Check constraint renaming with aliasing, generic database rules, match schema', FilterSchema = 'AliasRenaming03', FilterTable = 'Case03', UseAliases = 'STC', NamingConvention = 'CK_%SCHEMA_NAME%_%TABLE_NAME%_%COLUMN_NAME%', Expected = '[AliasRenaming03].[Case03].[ProductNo].[CK_AR09_Case03_ProductNo]'

INSERT #TestCases (TestDesc, FilterSchema, FilterTable, EnabledStates, NamingConvention, Expected) SELECT TestDesc = 'Check constraint renaming with enabled state placeholder. Enabled', FilterSchema = 'EnabledStateRenaming', FilterTable = 'Case01', EnabledStates = 'ENABLED_STATE_YES=_Enabled,ENABLED_STATE_NO=_Disabled', NamingConvention = 'CK_%SCHEMA_NAME%_%TABLE_NAME%_%COLUMN_NAME%%ENABLED_STATE%', Expected = '[EnabledStateRenaming].[Case01].[ProductNo].[CK_EnabledStateRenaming_Case01_ProductNo_Enabled]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, EnabledStates, NamingConvention, Expected) SELECT TestDesc = 'Check constraint renaming with enabled state placeholder. Disabled', FilterSchema = 'EnabledStateRenaming', FilterTable = 'Case02', EnabledStates = 'ENABLED_STATE_YES=_Enabled,ENABLED_STATE_NO=_Disabled', NamingConvention = 'CK_%SCHEMA_NAME%_%TABLE_NAME%_%COLUMN_NAME%%ENABLED_STATE%', Expected = '[EnabledStateRenaming].[Case02].[ProductNo].[CK_EnabledStateRenaming_Case02_ProductNo_Disabled]'

INSERT #TestCases (TestDesc, FilterSchema, FilterTable, ReplicationStates, NamingConvention, Expected) SELECT TestDesc = 'Check constraint renaming with replication state placeholder. For replication', FilterSchema = 'ReplicationStateRenaming', FilterTable = 'Case01', ReplicationStates = 'REPLICATION_STATE_YES=,REPLICATION_STATE_NO=_NotForRepl', NamingConvention = 'CK_%SCHEMA_NAME%_%TABLE_NAME%_%COLUMN_NAME%%REPLICATION_STATE%', Expected = '[ReplicationStateRenaming].[Case01].[ProductNo].[CK_ReplicationStateRenaming_Case01_ProductNo]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, ReplicationStates, NamingConvention, Expected) SELECT TestDesc = 'Check constraint renaming with replication state placeholder. Not for replication', FilterSchema = 'ReplicationStateRenaming', FilterTable = 'Case02', ReplicationStates = 'REPLICATION_STATE_YES=,REPLICATION_STATE_NO=_NotForRepl', NamingConvention = 'CK_%SCHEMA_NAME%_%TABLE_NAME%_%COLUMN_NAME%%REPLICATION_STATE%', Expected = '[ReplicationStateRenaming].[Case02].[ProductNo].[CK_ReplicationStateRenaming_Case02_ProductNo_NotForRepl]'

INSERT #TestCases (TestDesc, FilterSchema, FilterTable, TrustedStates, NamingConvention, Expected) SELECT TestDesc = 'Check constraint renaming with trusted state placeholder. Enabled', FilterSchema = 'TrustedStateRenaming', FilterTable = 'Case01', TrustedStates = 'TRUSTED_STATE_YES=_Trusted,TRUSTED_STATE_NO=_Untrusted', NamingConvention = 'CK_%SCHEMA_NAME%_%TABLE_NAME%_%COLUMN_NAME%%TRUSTED_STATE%', Expected = '[TrustedStateRenaming].[Case01].[ProductNo].[CK_TrustedStateRenaming_Case01_ProductNo_Trusted]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, TrustedStates, NamingConvention, Expected) SELECT TestDesc = 'Check constraint renaming with trusted state placeholder. Disabled', FilterSchema = 'TrustedStateRenaming', FilterTable = 'Case02', TrustedStates = 'TRUSTED_STATE_YES=_Trusted,TRUSTED_STATE_NO=_Untrusted', NamingConvention = 'CK_%SCHEMA_NAME%_%TABLE_NAME%_%COLUMN_NAME%%TRUSTED_STATE%', Expected = '[TrustedStateRenaming].[Case02].[ProductNo].[CK_TrustedStateRenaming_Case02_ProductNo_Untrusted]'

DECLARE @ExecuteCommand NVARCHAR(MAX)
DECLARE @ExecuteCommandTemplate NVARCHAR(MAX)
DECLARE @SchemaName sysname
DECLARE @TableName sysname
DECLARE @ColumnName sysname
DECLARE @ObjectName NVARCHAR(256)
DECLARE @CheckName sysname
DECLARE @SQLEnabled NVARCHAR(MAX)
DECLARE @SQLReplication NVARCHAR(MAX)
DECLARE @SQLTrusted NVARCHAR(MAX)
DECLARE @IsEnabled BIT
DECLARE @IsForReplication BIT
DECLARE @IsTrusted BIT
DECLARE @I INT 



-- #######################################################################################
-- ###### Execute the test schema initialization command
-- #######################################################################################
SET @I = 1
WHILE (1 = 1)
BEGIN
  SELECT @SchemaName = SchemaName FROM #TestSchemas WHERE IndexNo = @I
  IF @@ROWCOUNT = 0 BREAK

  RAISERROR ('TEST CASE INITIALIZATION #%0.2d. CREATING SCHEMA %s', 10, 1, @I, @SchemaName) WITH NOWAIT
  SET @ExecuteCommand = REPLACE('IF SCHEMA_ID(''%SCHEMANAME%'') IS NULL EXECUTE (''CREATE SCHEMA [%SCHEMANAME%] AUTHORIZATION dbo'')', '%SCHEMANAME%', @SchemaName)
  EXECUTE (@ExecuteCommand)

  SET @I = @I + 1
END
PRINT ''
PRINT ''

-- #######################################################################################
-- ###### Execute the test table initialization command
-- #######################################################################################
SET @ExecuteCommandTemplate = 
  N'
  IF (OBJECT_ID(''%ESCAPEDOBJECTNAME%'', ''U'') IS NOT NULL)
    DROP TABLE %OBJECTNAME%
  CREATE TABLE %OBJECTNAME% (%COLUMN_NAME% INT) 
  ALTER TABLE %OBJECTNAME% %TRUSTED_STATE% ADD CONSTRAINT %CHECK_NAME% CHECK %REPLICATION_STATE% (%COLUMN_NAME% >= 0 )
  ALTER TABLE %OBJECTNAME% %ENABLED_STATE% CONSTRAINT %CHECK_NAME%'  
SET @I = 1
WHILE (1 = 1)
BEGIN
  SELECT @ObjectName = ObjectName, @ColumnName = QUOTENAME(ColumnName), @CheckName = QUOTENAME(CheckName), @IsEnabled = IsEnabled, @IsForReplication = IsForReplication, @IsTrusted = IsTrusted FROM #TestTables WHERE TestNo = @I
  IF @@ROWCOUNT = 0 BREAK

  IF (@IsEnabled = 1) SET @SQLEnabled = 'CHECK' ELSE SET @SQLEnabled = 'NOCHECK' 
  IF (@IsTrusted = 1) SET @SQLTrusted= 'WITH CHECK' ELSE SET @SQLTrusted = 'WITH NOCHECK' 
  IF (@IsForReplication = 1) SET @SQLReplication = '' ELSE SET @SQLReplication = 'NOT FOR REPLICATION' 

  RAISERROR ('TEST CASE INITIALIZATION #%0.2d. CREATING TABLE %s', 10, 1, @I, @ObjectName) WITH NOWAIT
  SET @ExecuteCommand =  REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(@ExecuteCommandTemplate, '%OBJECTNAME%', @ObjectName ), '%ESCAPEDOBJECTNAME%', REPLACE(@ObjectName, '''', '''''')), '%CHECK_NAME%', @CheckName), '%COLUMN_NAME%', @ColumnName), '%ENABLED_STATE%', @SQLEnabled), '%TRUSTED_STATE%', @SQLTrusted), '%REPLICATION_STATE%', @SQLReplication)
  EXECUTE (@ExecuteCommand)
  
  SET @I = @I + 1
END
PRINT ''
PRINT ''

DECLARE @TestDesc NVARCHAR(MAX)
DECLARE @Expected NVARCHAR(MAX)
DECLARE @Actual NVARCHAR(MAX)
DECLARE @Message NVARCHAR(MAX)
DECLARE @Filter NVARCHAR(MAX)
DECLARE @FilterTable NVARCHAR(MAX)
DECLARE @FilterSchema NVARCHAR(MAX)
DECLARE @NamingConvention NVARCHAR(MAX)
DECLARE @EnabledStates NVARCHAR(MAX)
DECLARE @ReplicationStates NVARCHAR(MAX)
DECLARE @TrustedStates NVARCHAR(MAX)
DECLARE @OversizedMode NCHAR(1)
DECLARE @UseAliases CHAR(3)
DECLARE @ForceCaseSensitivity BIT
DECLARE @MaxNameLength TINYINT
DECLARE @UniquifyNames BIT
DECLARE @Statement NVARCHAR(MAX)

-- #######################################################################################
-- ###### Execute the Test runner command
-- #######################################################################################
SET @ExecuteCommand = N'
SET @Statement = ''EXECUTE spFixColumnCheckNaming @PerformUpdate = 2''
DECLARE @FilterExpression NVARCHAR(MAX) 
SET @FilterExpression = @FilterSchema + ''.'' + @FilterTable

IF (@FilterExpression IS NOT NULL) SET @Statement = @Statement + '', @FilterExpression = '''''' + REPLACE(@FilterExpression, '''''''', '''''''''''') + ''''''''    
IF (@NamingConvention IS NOT NULL) SET @Statement = @Statement + '', @NamingConvention = '''''' + REPLACE(@NamingConvention, '''''''', '''''''''''') + ''''''''  
IF (@OversizedMode IS NOT NULL) SET @Statement = @Statement + '', @OversizedMode = '''''' + @OversizedMode + ''''''''  
IF (@ForceCaseSensitivity IS NOT NULL) SET @Statement = @Statement + '', @ForceCaseSensitivity = '' + CAST(@ForceCaseSensitivity AS NCHAR(1))  
IF (@UseAliases IS NOT NULL) SET @Statement = @Statement + '', @UseAliases = '''''' +  @UseAliases + ''''''''  
IF (@MaxNameLength IS NOT NULL) SET @Statement = @Statement + '', @MaxNameLength = '' + CAST(@MaxNameLength AS NVARCHAR(3)) 
IF (@UniquifyNames IS NOT NULL) SET @Statement = @Statement + '', @UniquifyNames = '' + CAST(@UniquifyNames AS NCHAR(1))
IF (@EnabledStates IS NOT NULL) SET @Statement = @Statement + '', @EnabledStates = '''''' + @EnabledStates + ''''''''
IF (@ReplicationStates IS NOT NULL) SET @Statement = @Statement + '', @ReplicationStates = '''''' + @ReplicationStates + ''''''''
IF (@TrustedStates IS NOT NULL) SET @Statement = @Statement + '', @TrustedStates = '''''' + @TrustedStates + ''''''''

EXECUTE (@Statement)
SET @Actual = ''''

SELECT  @Actual = @Actual + X.FullName + '';''
FROM
  ( 
    SELECT
      RowNo = ROW_NUMBER() OVER(ORDER BY s.name, t.name, c.name, cc.name),
      FullName = QUOTENAME(s.name) + ''.'' + QUOTENAME(t.name) + ''.'' + QUOTENAME(c.name) + ''.'' + QUOTENAME(cc.name)
    FROM  
      sys.check_constraints cc 
        JOIN sys.columns c ON
          cc.parent_object_id = c.object_id AND
          cc.parent_column_id = c.column_id
        JOIN sys.tables t ON 
          t.object_id = c.object_id
        JOIN sys.schemas s ON 
          t.schema_id = s.schema_id
        JOIN fnGetFilteredTables(@FilterExpression) ft ON
          cc.parent_object_id = ft.ObjectId
  ) X
ORDER BY RowNo  
  
IF Len(@Actual) > 0 SET @Actual = LEFT(@Actual, LEN(@Actual) - 1);
'

SET @Message = '### %s ###\t\tTEST CASE #%0.2d. - %s\n\tSTATEMENT: %s\n\tEXPECTED RESULT: %s\n\tACTUAL RESULT:   %s\n'
SET @I = 1
WHILE (1 = 1)
BEGIN
  SELECT @TestDesc = TestDesc, @FilterSchema = FilterSchema, @FilterTable = FilterTable, @NamingConvention = NamingConvention,  @UseAliases = UseAliases, @ForceCaseSensitivity = ForceCaseSensitivity, @OversizedMode = OversizedMode, @MaxNameLength = MaxNameLength, @UniquifyNames = UniquifyNames, @EnabledStates = EnabledStates, @ReplicationStates = ReplicationStates, @TrustedStates = TrustedStates , @Expected = Expected FROM #TestCases WHERE TestNo = @I
  IF @@ROWCOUNT = 0 BREAK

  EXECUTE sp_executesql 
    @ExecuteCommand, 
    N'@FilterSchema NVARCHAR(MAX), @FilterTable NVARCHAR(MAX), @NamingConvention NVARCHAR(MAX), @UseAliases CHAR(3), @ForceCaseSensitivity BIT, @OversizedMode NCHAR(1), @MaxNameLength TINYINT, @UniquifyNames BIT, @EnabledStates NVARCHAR(MAX), @ReplicationStates NVARCHAR(MAX), @TrustedStates NVARCHAR(MAX), @Actual NVARCHAR(MAX) OUTPUT, @Statement NVARCHAR(MAX) OUTPUT',
    @FilterSchema, @FilterTable, @NamingConvention, @UseAliases, @ForceCaseSensitivity, @OversizedMode, @MaxNameLength, @UniquifyNames, @EnabledStates, @ReplicationStates, @TrustedStates, @Actual OUTPUT, @Statement OUTPUT

  SET @Message = REPLACE(REPLACE(@Message, '\n', CHAR(13)), '\t', CHAR(9)) 
  IF @Expected + '#'  COLLATE Latin1_General_BIN = @Actual + '#'  COLLATE Latin1_General_BIN-- Dirty hack, because comparing ' ' and '  ' is equal in sql server
    RAISERROR (@Message, 10, 1, 'SUCCESS!!!', @I, @TestDesc, @Statement, @Expected, @Actual) WITH NOWAIT
  ELSE                            
    RAISERROR (@Message, 16, 1, 'FAILURE!!!', @I, @TestDesc, @Statement, @Expected, @Actual) WITH NOWAIT

  SET @I = @I + 1
END
PRINT ''
PRINT ''

-- #######################################################################################
-- ###### Execute the test table cleanup command
-- #######################################################################################
SET @I = 1
WHILE (1 = 1)
BEGIN
  SELECT @ObjectName = ObjectName FROM #TestTables WHERE TestNo = @I
  IF @@ROWCOUNT = 0 BREAK

  RAISERROR ('TEST CASE CLEANUP #%0.2d. DROPPING TABLE %s', 10, 1, @I, @ObjectName) WITH NOWAIT
  SET @ExecuteCommand = REPLACE(REPLACE('IF OBJECT_ID(''%OBJECT_NAME%'', ''U'') IS NOT NULL DROP TABLE %OBJECTNAME%', '%OBJECTNAME%', @ObjectName), '%OBJECT_NAME%', REPLACE(@ObjectName, '''', ''''''))
  --PRINT @ExecuteCommand  
  EXECUTE (@ExecuteCommand)
  
  SET @I = @I + 1
END
PRINT ''
PRINT ''


-- #######################################################################################
-- ###### Execute the test schema cleanup command
-- #######################################################################################
SET @I = 1
WHILE (1 = 1)
BEGIN
  SELECT @SchemaName = SchemaName FROM #TestSchemas WHERE IndexNo = @I
  IF @@ROWCOUNT = 0 BREAK

  RAISERROR ('TEST CASE CLEANUP #%0.2d. DROPPING SCHEMA %s', 10, 1, @I, @SchemaName) WITH NOWAIT
  SET @ExecuteCommand = REPLACE('IF SCHEMA_ID(''%SCHEMANAME%'') IS NOT NULL DROP SCHEMA %SCHEMANAME%', '%SCHEMANAME%', QUOTENAME(@SchemaName))
  EXECUTE (@ExecuteCommand)
  
  SET @I = @I + 1
END
PRINT ''
PRINT ''


IF (OBJECT_ID('tempdb..#TestSchemas', 'U') IS NOT NULL) DROP TABLE #TestSchemas 
IF (OBJECT_ID('tempdb..#TestTables', 'U') IS NOT NULL) DROP TABLE #TestTables 
IF (OBJECT_ID('tempdb..#TestCases', 'U') IS NOT NULL) DROP TABLE #TestCases 

GO