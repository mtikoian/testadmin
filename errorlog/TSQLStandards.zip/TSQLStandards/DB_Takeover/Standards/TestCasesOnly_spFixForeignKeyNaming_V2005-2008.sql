USE tempdb
GO
/*********************************************************************************

  File:         spFixForeignKeyNaming - Test Cases.sql
  Author:       Michael S�ndergaard
  Date:         July 2010
  Build Date:   20 March 2011
  Homepage:     http://sql.soendergaard.info
  Version:      1.0.0
  Supported / 
  Tested on:    Microsoft SQL Server 2005 & 2008
  
  Description:  This file contains all the test cases used for developing the 
                stored procedure dbautils.spFixForeignKeyNaming.
                
  Requirements: The stored procedure dbautils.spFixForeignKeyNaming should be
                installed in the tempdb.
                
                All test cases will be created in tempdb. for ensuring better cleanup
                and avoiding permissions

  Usage:        See test cases

  -----------------------------------------------------------------------------------

  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF
  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
  TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
  PARTICULAR PURPOSE. YOU MAY USE AND MODIFY THIS CODE FREELY FOR
  YOUR OWN PURPOSE, IF YOU REMEMBER TO CREDIT MY WORK. HOWEVER YOU 
  MAY NOT REPUBLISH IT, AND CLAIM IT AS YOUR OWN WORK 


  -----------------------------------------------------------------------------------

  Revision History:

    Version 1.0.0 - July 10, 2010 
      - Inital version 
     
**********************************************************************************/


USE tempdb

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

SET NOCOUNT ON

DECLARE @ExecuteCommand NVARCHAR(MAX)
DECLARE @ExecuteCommandTemplate NVARCHAR(MAX)
DECLARE @ObjectName NVARCHAR(MAX)
DECLARE @SchemaName sysname
DECLARE @TableName sysname
DECLARE @ForeignKeyName sysname
DECLARE @I INT
DECLARE @TestDesc NVARCHAR(MAX)
DECLARE @Expected NVARCHAR(MAX)
DECLARE @Actual NVARCHAR(MAX)
DECLARE @Message NVARCHAR(MAX)
DECLARE @FilterSchema NVARCHAR(MAX)
DECLARE @FilterTable NVARCHAR(MAX)
DECLARE @NamingConvention NVARCHAR(MAX)
DECLARE @EnabledStates NVARCHAR(MAX)
DECLARE @ReplicationStates NVARCHAR(MAX)
DECLARE @TrustedStates NVARCHAR(MAX)
DECLARE @DeleteRefActions NVARCHAR(MAX)
DECLARE @UpdateRefActions NVARCHAR(MAX)
DECLARE @ColumnsSeparator NVARCHAR(50)
DECLARE @UseAliases CHAR(3)
DECLARE @ForceCaseSensitivity BIT
DECLARE @OversizedMode CHAR
DECLARE @MaxNameLength TINYINT
DECLARE @MaxParentColumns TINYINT
DECLARE @MaxReferencedColumns TINYINT
DECLARE @UniquifyNames BIT
DECLARE @Statement NVARCHAR(MAX)
DECLARE @DBIsCaseSensitive BIT
SET @DBIsCaseSensitive = CASE WHEN 'a' = 'A' THEN CAST(0 AS BIT) ELSE 1 END


-- #######################################################################################
-- ###### Verify all requirements for this test case script
-- #######################################################################################
IF OBJECT_ID('dbautils.fnGetFilteredTables', 'TF') IS NULL
BEGIN
  RAISERROR('The user defined function dbautils.fnGetFilteredTables is not installed in the tempdb', 16, 1)
  RETURN
END 

IF SCHEMA_ID('dbautils') IS NULL EXECUTE ('CREATE SCHEMA dbautils AUTHORIZATION dbo')

IF (OBJECT_ID('tempdb..#TestSchemas', 'U') IS NOT NULL) DROP TABLE #TestSchemas
IF (OBJECT_ID('tempdb..#TestTables', 'U') IS NOT NULL) DROP TABLE #TestTables  
IF (OBJECT_ID('tempdb..#TestTablesPreCleanup', 'U') IS NOT NULL) DROP TABLE #TestTablesPreCleanup  
IF (OBJECT_ID('tempdb..#TestTablesPostCleanup', 'U') IS NOT NULL) DROP TABLE #TestTablesPostCleanup  
IF (OBJECT_ID('tempdb..#TestCases', 'U') IS NOT NULL) DROP TABLE #TestCases


DELETE dbautils.AliasRulesSynonym
-- #######################################################################################
-- ###### Create the AliasRules for the test cases
-- #######################################################################################
INSERT INTO dbautils.AliasRulesSynonym
(
  DatabaseName,
  SchemaName,
  TableName,
  ColumnName,
  AliasName
)
          SELECT DatabaseName = 'tempdb', SchemaName = 'ColumnAliasRenaming', TableName = 'Case01', ColumnName = 'ColA', AliasName = 'CAR1' 
UNION ALL SELECT DatabaseName = 'tempdb', SchemaName = 'ColumnAliasRenaming', TableName = 'Case02', ColumnName = 'ColA', AliasName = 'CAR2'
UNION ALL SELECT DatabaseName = 'tempdb', SchemaName = 'ColumnAliasRenaming', TableName = 'Case03', ColumnName = 'ColA', AliasName = 'CAR3' 
UNION ALL SELECT DatabaseName = '%', SchemaName = 'ColumnAliasRenaming', TableName = '%', ColumnName = 'ColA', AliasName = 'CAR4' 

UNION ALL SELECT DatabaseName = 'tempdb', SchemaName = 'TableAliasRenaming', TableName = 'Case01', ColumnName = '', AliasName = 'TAR1' 
UNION ALL SELECT DatabaseName = 'tempdb', SchemaName = 'TableAliasRenaming', TableName = 'Case02', ColumnName = '', AliasName = 'TAR2'
UNION ALL SELECT DatabaseName = 'tempdb', SchemaName = 'TableAliasRenaming', TableName = 'Case03', ColumnName = '', AliasName = 'TAR3' 
UNION ALL SELECT DatabaseName = '%', SchemaName = '%', TableName = 'Case04', ColumnName = '', AliasName = 'TAR4' 

UNION ALL SELECT DatabaseName = 'msdb', SchemaName = 'SchemaAliasRenaming01', TableName = '', ColumnName = '', AliasName = 'SAR01' 
UNION ALL SELECT DatabaseName = 'tempdb', SchemaName = 'SchemaAliasRenaming02', TableName = '', ColumnName = '', AliasName = 'SAR02'
UNION ALL SELECT DatabaseName = '%', SchemaName = 'SchemaAliasRenaming03', TableName = '', ColumnName = '', AliasName = 'SAR03'

UNION ALL SELECT DatabaseName = 'msdb', SchemaName = 'AliasRenaming01', TableName = '', ColumnName = '', AliasName = 'AR01' 
UNION ALL SELECT DatabaseName = 'msdb', SchemaName = 'AliasRenaming01', TableName = 'Case01', ColumnName = '', AliasName = 'AR02' 
UNION ALL SELECT DatabaseName = 'msdb', SchemaName = 'AliasRenaming01', TableName = 'Case01', ColumnName = 'ColA', AliasName = 'AR03' 
UNION ALL SELECT DatabaseName = 'tempdb', SchemaName = 'AliasRenaming02', TableName = '', ColumnName = '', AliasName = 'AR04'
UNION ALL SELECT DatabaseName = 'tempdb', SchemaName = 'AliasRenaming02', TableName = 'Case01', ColumnName = '', AliasName = 'AR05'
UNION ALL SELECT DatabaseName = 'tempdb', SchemaName = 'AliasRenaming02', TableName = 'Case01', ColumnName = 'ColA', AliasName = 'AR06'
UNION ALL SELECT DatabaseName = 'tempdb', SchemaName = 'AliasRenaming02', TableName = 'Case02', ColumnName = '', AliasName = 'AR07'
UNION ALL SELECT DatabaseName = 'tempdb', SchemaName = 'AliasRenaming02', TableName = 'Case02', ColumnName = 'ColA', AliasName = 'AR08'
UNION ALL SELECT DatabaseName = '%', SchemaName = 'AliasRenaming03', TableName = '', ColumnName = '', AliasName = 'AR09'
UNION ALL SELECT DatabaseName = '%', SchemaName = 'AliasRenaming03', TableName = 'Case01', ColumnName = '', AliasName = 'AR10'
UNION ALL SELECT DatabaseName = '%', SchemaName = 'AliasRenaming03', TableName = 'Case01', ColumnName = 'ColA', AliasName = 'AR11'
UNION ALL SELECT DatabaseName = '%', SchemaName = 'AliasRenaming03', TableName = 'Case02', ColumnName = '', AliasName = 'AR12'
UNION ALL SELECT DatabaseName = '%', SchemaName = 'AliasRenaming03', TableName = 'Case02', ColumnName = 'ColA', AliasName = 'AR13'

-- #######################################################################################
-- ###### Create a table for all schemas in test data
-- #######################################################################################
IF (OBJECT_ID('tempdb..#TestSchemas', 'U') IS NOT NULL) DROP TABLE #TestSchemas 
CREATE TABLE #TestSchemas  
(
  No INT IDENTITY,
  SchemaName sysname NOT NULL
)

-- #######################################################################################
-- ###### Create a table containing all test tables
-- #######################################################################################
IF (OBJECT_ID('tempdb..#TestTables', 'U') IS NOT NULL) DROP TABLE #TestTables 
CREATE TABLE #TestTables  
(
  TestNo INT IDENTITY PRIMARY KEY NOT NULL,
  SchemaName sysname NOT NULL,
  TableName sysname NOT NULL,
  ForeignKeyName sysname NOT NULL,
  ObjectName AS QUOTENAME(SchemaName) + '.' + QUOTENAME(TableName)  
  
)


-- #######################################################################################
-- ###### Insert all test cases into the test case table
-- #######################################################################################
INSERT #TestTables
(
  SchemaName, 
  TableName,
  ForeignKeyName
)
          SELECT SchemaName = 'FromSpecialChar', TableName = 'Case01', ForeignKeyName = 'FK_Case01_'
UNION ALL SELECT SchemaName = 'FromSpecialChar', TableName = 'Case02', ForeignKeyName = ' FK_Case02'
UNION ALL SELECT SchemaName = 'FromSpecialChar', TableName = 'Case03', ForeignKeyName = 'FK_Case03 '
UNION ALL SELECT SchemaName = 'FromSpecialChar', TableName = 'Case04', ForeignKeyName = 'FK_Case04?'
UNION ALL SELECT SchemaName = 'FromSpecialChar', TableName = 'Case05', ForeignKeyName = 'FK_Case05%'
UNION ALL SELECT SchemaName = 'FromSpecialChar', TableName = 'Case06', ForeignKeyName = 'FK_Case06^'
UNION ALL SELECT SchemaName = 'FromSpecialChar', TableName = 'Case07', ForeignKeyName = 'FK_Case07'''
UNION ALL SELECT SchemaName = 'FromSpecialChar', TableName = 'Case08', ForeignKeyName = 'FK_Case08"'
UNION ALL SELECT SchemaName = 'FromSpecialChar', TableName = 'Case09', ForeignKeyName = 'FK_Case09,'
UNION ALL SELECT SchemaName = 'FromSpecialChar', TableName = 'Case10', ForeignKeyName = 'FK_Case10.'
UNION ALL SELECT SchemaName = 'FromSpecialChar', TableName = 'Case11', ForeignKeyName = 'FK_Case11*'
UNION ALL SELECT SchemaName = 'FromSpecialChar', TableName = 'Case12', ForeignKeyName = 'FK_Case12['
UNION ALL SELECT SchemaName = 'FromSpecialChar', TableName = 'Case13', ForeignKeyName = 'FK_Case13]'
UNION ALL SELECT SchemaName = 'FromSpecialChar', TableName = 'Case14', ForeignKeyName = 'FK_Case14-'
UNION ALL SELECT SchemaName = 'FromSpecialChar', TableName = 'Case15', ForeignKeyName = 'FK_Case15+'
UNION ALL SELECT SchemaName = 'FromSpecialChar', TableName = 'Case16', ForeignKeyName = '"FK_Case16"'
UNION ALL SELECT SchemaName = 'FromSpecialChar', TableName = 'Case17', ForeignKeyName = '[FK_Case17]'
UNION ALL SELECT SchemaName = 'FromSpecialChar', TableName = 'Case18', ForeignKeyName = '''FK_Case18'''
UNION ALL SELECT SchemaName = 'FromSpecialChar', TableName = 'Case19', ForeignKeyName = 'FK_Case.19'
UNION ALL SELECT SchemaName = 'FromSpecialChar', TableName = 'Case20', ForeignKeyName = 'FK_Case 20'

UNION ALL SELECT SchemaName = 'ToSpecialChar', TableName = 'Case01_', ForeignKeyName = 'FK_Case01'
UNION ALL SELECT SchemaName = 'ToSpecialChar', TableName = ' Case02', ForeignKeyName = 'FK_Case02'
UNION ALL SELECT SchemaName = 'ToSpecialChar', TableName = 'Case03 ', ForeignKeyName = 'FK_Case03'
UNION ALL SELECT SchemaName = 'ToSpecialChar', TableName = 'Case04?', ForeignKeyName = 'FK_Case04'
UNION ALL SELECT SchemaName = 'ToSpecialChar', TableName = 'Case05%', ForeignKeyName = 'FK_Case05'
UNION ALL SELECT SchemaName = 'ToSpecialChar', TableName = 'Case06^', ForeignKeyName = 'FK_Case06'
UNION ALL SELECT SchemaName = 'ToSpecialChar', TableName = 'Case07''', ForeignKeyName = 'FK_Case07'
UNION ALL SELECT SchemaName = 'ToSpecialChar', TableName = 'Case08"', ForeignKeyName = 'FK_Case08'
UNION ALL SELECT SchemaName = 'ToSpecialChar', TableName = 'Case09,', ForeignKeyName = 'FK_Case09'
UNION ALL SELECT SchemaName = 'ToSpecialChar', TableName = 'Case10.', ForeignKeyName = 'FK_Case10'
UNION ALL SELECT SchemaName = 'ToSpecialChar', TableName = 'Case11*', ForeignKeyName = 'FK_Case11'
UNION ALL SELECT SchemaName = 'ToSpecialChar', TableName = 'Case12[', ForeignKeyName = 'FK_Case12'
UNION ALL SELECT SchemaName = 'ToSpecialChar', TableName = 'Case13]', ForeignKeyName = 'FK_Case13'
UNION ALL SELECT SchemaName = 'ToSpecialChar', TableName = 'Case14-', ForeignKeyName = 'FK_Case14'
UNION ALL SELECT SchemaName = 'ToSpecialChar', TableName = 'Case15+', ForeignKeyName = 'FK_Case15'
UNION ALL SELECT SchemaName = 'ToSpecialChar', TableName = '"Case16"', ForeignKeyName = 'FK_Case16'
UNION ALL SELECT SchemaName = 'ToSpecialChar', TableName = '[Case17]', ForeignKeyName = 'FK_Case17'
UNION ALL SELECT SchemaName = 'ToSpecialChar', TableName = '''Case18''', ForeignKeyName = 'FK_Case18'
UNION ALL SELECT SchemaName = 'ToSpecialChar', TableName = 'Case.19', ForeignKeyName = 'FK_Case19'
UNION ALL SELECT SchemaName = 'ToSpecialChar', TableName = 'Case 20', ForeignKeyName = 'FK_Case20'

UNION ALL SELECT SchemaName = 'FilteredRenaming', TableName = 'Case01', ForeignKeyName = 'FK_Case01'
UNION ALL SELECT SchemaName = 'FilteredRenaming', TableName = 'Case02', ForeignKeyName = 'FK_Case02'
UNION ALL SELECT SchemaName = 'CustomWithSchema', TableName = 'Case01', ForeignKeyName = 'FK_Case01'
UNION ALL SELECT SchemaName = 'CustomWithSchema', TableName = 'Case02', ForeignKeyName = 'FK_Case02'
UNION ALL SELECT SchemaName = 'CustomWithParCols', TableName = 'Case01', ForeignKeyName = 'FK_Case01'
UNION ALL SELECT SchemaName = 'CustomWithParCols', TableName = 'Case02', ForeignKeyName = 'FK_Case02'
UNION ALL SELECT SchemaName = 'CustomWithRefCols', TableName = 'Case01', ForeignKeyName = 'FK_Case01'
UNION ALL SELECT SchemaName = 'CustomWithRefCols', TableName = 'Case02', ForeignKeyName = 'FK_Case02'
UNION ALL SELECT SchemaName = 'CustomWithColSep', TableName = 'Case01', ForeignKeyName = 'FK_Case01'
UNION ALL SELECT SchemaName = 'CustomWithColSep', TableName = 'Case02', ForeignKeyName = 'FK_Case02'
UNION ALL SELECT SchemaName = 'CustomWithEnabledState', TableName = 'Case01', ForeignKeyName = 'FK_Case01'
UNION ALL SELECT SchemaName = 'CustomWithEnabledState', TableName = 'Case02', ForeignKeyName = 'FK_Case02'
UNION ALL SELECT SchemaName = 'CustomWithEnabledState', TableName = 'Case03', ForeignKeyName = 'FK_Case03'
UNION ALL SELECT SchemaName = 'CustomWithEnabledState', TableName = 'Case04', ForeignKeyName = 'FK_Case04'

UNION ALL SELECT SchemaName = 'CustomWithReplicationState', TableName = 'Case01', ForeignKeyName = 'FK_Case01'
UNION ALL SELECT SchemaName = 'CustomWithReplicationState', TableName = 'Case02', ForeignKeyName = 'FK_Case02'
UNION ALL SELECT SchemaName = 'CustomWithReplicationState', TableName = 'Case03', ForeignKeyName = 'FK_Case03'
UNION ALL SELECT SchemaName = 'CustomWithReplicationState', TableName = 'Case04', ForeignKeyName = 'FK_Case04'

UNION ALL SELECT SchemaName = 'CustomWithTrustedState', TableName = 'Case01', ForeignKeyName = 'FK_Case01'
UNION ALL SELECT SchemaName = 'CustomWithTrustedState', TableName = 'Case02', ForeignKeyName = 'FK_Case02'
UNION ALL SELECT SchemaName = 'CustomWithTrustedState', TableName = 'Case03', ForeignKeyName = 'FK_Case03'
UNION ALL SELECT SchemaName = 'CustomWithTrustedState', TableName = 'Case04', ForeignKeyName = 'FK_Case04'

UNION ALL SELECT SchemaName = 'CustomWithDelRefActions', TableName = 'Case01', ForeignKeyName = 'FK_Case01'
UNION ALL SELECT SchemaName = 'CustomWithDelRefActions', TableName = 'Case02', ForeignKeyName = 'FK_Case02'
UNION ALL SELECT SchemaName = 'CustomWithDelRefActions', TableName = 'Case03', ForeignKeyName = 'FK_Case03'
UNION ALL SELECT SchemaName = 'CustomWithDelRefActions', TableName = 'Case04', ForeignKeyName = 'FK_Case04'

UNION ALL SELECT SchemaName = 'CustomWithUpdRefActions', TableName = 'Case01', ForeignKeyName = 'FK_Case01'
UNION ALL SELECT SchemaName = 'CustomWithUpdRefActions', TableName = 'Case02', ForeignKeyName = 'FK_Case02'
UNION ALL SELECT SchemaName = 'CustomWithUpdRefActions', TableName = 'Case03', ForeignKeyName = 'FK_Case03'
UNION ALL SELECT SchemaName = 'CustomWithUpdRefActions', TableName = 'Case04', ForeignKeyName = 'FK_Case04'

UNION ALL SELECT SchemaName = 'CasingRenaming', TableName = 'Case01', ForeignKeyName = 'CK_Case01_ProductNo'
UNION ALL SELECT SchemaName = 'CasingRenaming', TableName = 'Case02', ForeignKeyName = 'CK_Case02_ProductNo'
UNION ALL SELECT SchemaName = 'MaxNameLength&Truncate', TableName = 'Case01', ForeignKeyName = 'FK_Case01'
UNION ALL SELECT SchemaName = 'MaxNameLength&Skip', TableName = 'Case01', ForeignKeyName = 'FK_Case01'
UNION ALL SELECT SchemaName = 'MaxParentColumns', TableName = 'Case01', ForeignKeyName = 'FK_Case01'
UNION ALL SELECT SchemaName = 'MaxReferencedColumns', TableName = 'Case01', ForeignKeyName = 'FK_Case01'

UNION ALL SELECT SchemaName = 'UniquifyForeignKeys', TableName = 'Case01', ForeignKeyName = 'FK_Case01'

UNION ALL SELECT SchemaName = 'ColumnAliasRenaming', TableName = 'Case01', ForeignKeyName = 'FK_Case01'
UNION ALL SELECT SchemaName = 'ColumnAliasRenaming', TableName = 'Case02', ForeignKeyName = 'FK_Case02'
UNION ALL SELECT SchemaName = 'ColumnAliasRenaming', TableName = 'Case03', ForeignKeyName = 'FK_Case03'

UNION ALL SELECT SchemaName = 'TableAliasRenaming', TableName = 'Case01', ForeignKeyName = 'FK_Case01'
UNION ALL SELECT SchemaName = 'TableAliasRenaming', TableName = 'Case02', ForeignKeyName = 'FK_Case02'
UNION ALL SELECT SchemaName = 'TableAliasRenaming', TableName = 'Case03', ForeignKeyName = 'FK_Case03'
UNION ALL SELECT SchemaName = 'TableAliasRenaming', TableName = 'Case04', ForeignKeyName = 'FK_Case04'

UNION ALL SELECT SchemaName = 'SchemaAliasRenaming01', TableName = 'Case01', ForeignKeyName = 'FK_Case01'
UNION ALL SELECT SchemaName = 'SchemaAliasRenaming02', TableName = 'Case02', ForeignKeyName = 'FK_Case02'
UNION ALL SELECT SchemaName = 'SchemaAliasRenaming03', TableName = 'Case03', ForeignKeyName = 'FK_Case03'

UNION ALL SELECT SchemaName = 'AliasRenaming01', TableName = 'Case01', ForeignKeyName = 'FK_Case01'
UNION ALL SELECT SchemaName = 'AliasRenaming01', TableName = 'Case02', ForeignKeyName = 'FK_Case02'
UNION ALL SELECT SchemaName = 'AliasRenaming01', TableName = 'Case03', ForeignKeyName = 'FK_Case03'
UNION ALL SELECT SchemaName = 'AliasRenaming02', TableName = 'Case01', ForeignKeyName = 'FK_Case01'
UNION ALL SELECT SchemaName = 'AliasRenaming02', TableName = 'Case02', ForeignKeyName = 'FK_Case02'
UNION ALL SELECT SchemaName = 'AliasRenaming02', TableName = 'Case03', ForeignKeyName = 'FK_Case03'
UNION ALL SELECT SchemaName = 'AliasRenaming03', TableName = 'Case01', ForeignKeyName = 'FK_Case01'
UNION ALL SELECT SchemaName = 'AliasRenaming03', TableName = 'Case02', ForeignKeyName = 'FK_Case02'
UNION ALL SELECT SchemaName = 'AliasRenaming03', TableName = 'Case03', ForeignKeyName = 'FK_Case03'


-- #######################################################################################
-- ###### Create a table with all schemas used by the test cases
-- #######################################################################################
INSERT INTO #TestSchemas (SchemaName)
SELECT DISTINCT SchemaName FROM #TestTables WHERE SchemaName != 'dbo'

-- #######################################################################################
-- ###### Create a table containing all test cases
-- #######################################################################################
IF (OBJECT_ID('tempdb..#TestCases', 'U') IS NOT NULL) DROP TABLE #TestCases 
CREATE TABLE #TestCases  
(
  TestNo INT IDENTITY PRIMARY KEY NOT NULL,
  TestDesc NVARCHAR(MAX) NOT NULL,
  FilterSchema NVARCHAR(MAX) NULL,
  FilterTable NVARCHAR(MAX) NULL,
  NamingConvention NVARCHAR(MAX) NULL,
  EnabledStates NVARCHAR(MAX) NULL,
  ReplicationStates NVARCHAR(MAX) NULL,
  TrustedStates NVARCHAR(MAX) NULL,
  DeleteRefActions NVARCHAR(MAX) NULL,
  UpdateRefActions NVARCHAR(MAX) NULL,
  ColumnsSeparator NVARCHAR(50) NULL,
  OversizedMode NCHAR(1) NULL,
  MaxNameLength TINYINT NULL,
  MaxParentColumns TINYINT NULL,
  MaxReferencedColumns TINYINT NULL,
  ForceCaseSensitivity BIT NULL,
  UseAliases CHAR(3) NULL,  
  UniquifyNames BIT NULL,
  Expected NVARCHAR(MAX) NOT NULL,
)

-- #######################################################################################
-- ###### Insert all test cases into the test case table
-- #######################################################################################
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Foreign key renaming from a name with "_" in it', FilterSchema = 'FromSpecialChar', FilterTable = 'Case01', Expected = '[FK_Case01_Case01Cascade];[FK_Case01_Case01Cascade2];[FK_Case01_Case01Multi];[FK_Case01_Case01SetDefault];[FK_Case01_Case01SetDefault2];[FK_Case01_Case01SetNull];[FK_Case01_Case01SetNull2];[FK_Case01_Case01Single];[FK_Case01_Case01Single2];[FK_Case01_Case01Single3];[FK_Case01_Case01Single4];[FK_Case01_Case01Single5];[FK_Case01_Case01Single6]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Foreign key renaming from a name with leading space', FilterSchema = 'FromSpecialChar', FilterTable = 'Case02', Expected = '[FK_Case02_Case02Cascade];[FK_Case02_Case02Cascade2];[FK_Case02_Case02Multi];[FK_Case02_Case02SetDefault];[FK_Case02_Case02SetDefault2];[FK_Case02_Case02SetNull];[FK_Case02_Case02SetNull2];[FK_Case02_Case02Single];[FK_Case02_Case02Single2];[FK_Case02_Case02Single3];[FK_Case02_Case02Single4];[FK_Case02_Case02Single5];[FK_Case02_Case02Single6]'  
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Foreign key renaming from a name with trailing space', FilterSchema = 'FromSpecialChar', FilterTable = 'Case03', Expected = '[FK_Case03_Case03Cascade];[FK_Case03_Case03Cascade2];[FK_Case03_Case03Multi];[FK_Case03_Case03SetDefault];[FK_Case03_Case03SetDefault2];[FK_Case03_Case03SetNull];[FK_Case03_Case03SetNull2];[FK_Case03_Case03Single];[FK_Case03_Case03Single2];[FK_Case03_Case03Single3];[FK_Case03_Case03Single4];[FK_Case03_Case03Single5];[FK_Case03_Case03Single6]' 
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Foreign key renaming from a name with "?" in it', FilterSchema = 'FromSpecialChar', FilterTable = 'Case04', Expected = '[FK_Case04_Case04Cascade];[FK_Case04_Case04Cascade2];[FK_Case04_Case04Multi];[FK_Case04_Case04SetDefault];[FK_Case04_Case04SetDefault2];[FK_Case04_Case04SetNull];[FK_Case04_Case04SetNull2];[FK_Case04_Case04Single];[FK_Case04_Case04Single2];[FK_Case04_Case04Single3];[FK_Case04_Case04Single4];[FK_Case04_Case04Single5];[FK_Case04_Case04Single6]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Foreign key renaming from a name with "%" in it', FilterSchema = 'FromSpecialChar', FilterTable = 'Case05', Expected = '[FK_Case05_Case05Cascade];[FK_Case05_Case05Cascade2];[FK_Case05_Case05Multi];[FK_Case05_Case05SetDefault];[FK_Case05_Case05SetDefault2];[FK_Case05_Case05SetNull];[FK_Case05_Case05SetNull2];[FK_Case05_Case05Single];[FK_Case05_Case05Single2];[FK_Case05_Case05Single3];[FK_Case05_Case05Single4];[FK_Case05_Case05Single5];[FK_Case05_Case05Single6]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Foreign key renaming from a name with "^" in it', FilterSchema = 'FromSpecialChar', FilterTable = 'Case06', Expected = '[FK_Case06_Case06Cascade];[FK_Case06_Case06Cascade2];[FK_Case06_Case06Multi];[FK_Case06_Case06SetDefault];[FK_Case06_Case06SetDefault2];[FK_Case06_Case06SetNull];[FK_Case06_Case06SetNull2];[FK_Case06_Case06Single];[FK_Case06_Case06Single2];[FK_Case06_Case06Single3];[FK_Case06_Case06Single4];[FK_Case06_Case06Single5];[FK_Case06_Case06Single6]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Foreign key renaming from a name with "''" in it', FilterSchema = 'FromSpecialChar', FilterTable = 'Case07', Expected = '[FK_Case07_Case07Cascade];[FK_Case07_Case07Cascade2];[FK_Case07_Case07Multi];[FK_Case07_Case07SetDefault];[FK_Case07_Case07SetDefault2];[FK_Case07_Case07SetNull];[FK_Case07_Case07SetNull2];[FK_Case07_Case07Single];[FK_Case07_Case07Single2];[FK_Case07_Case07Single3];[FK_Case07_Case07Single4];[FK_Case07_Case07Single5];[FK_Case07_Case07Single6]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Foreign key renaming from a name with """ in it', FilterSchema = 'FromSpecialChar', FilterTable = 'Case08', Expected = '[FK_Case08_Case08Cascade];[FK_Case08_Case08Cascade2];[FK_Case08_Case08Multi];[FK_Case08_Case08SetDefault];[FK_Case08_Case08SetDefault2];[FK_Case08_Case08SetNull];[FK_Case08_Case08SetNull2];[FK_Case08_Case08Single];[FK_Case08_Case08Single2];[FK_Case08_Case08Single3];[FK_Case08_Case08Single4];[FK_Case08_Case08Single5];[FK_Case08_Case08Single6]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Foreign key renaming from a name with "," in it', FilterSchema = 'FromSpecialChar', FilterTable = 'Case09', Expected = '[FK_Case09_Case09Cascade];[FK_Case09_Case09Cascade2];[FK_Case09_Case09Multi];[FK_Case09_Case09SetDefault];[FK_Case09_Case09SetDefault2];[FK_Case09_Case09SetNull];[FK_Case09_Case09SetNull2];[FK_Case09_Case09Single];[FK_Case09_Case09Single2];[FK_Case09_Case09Single3];[FK_Case09_Case09Single4];[FK_Case09_Case09Single5];[FK_Case09_Case09Single6]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Foreign key renaming from a name with "." in it', FilterSchema = 'FromSpecialChar', FilterTable = 'Case10', Expected = '[FK_Case10_Case10Cascade];[FK_Case10_Case10Cascade2];[FK_Case10_Case10Multi];[FK_Case10_Case10SetDefault];[FK_Case10_Case10SetDefault2];[FK_Case10_Case10SetNull];[FK_Case10_Case10SetNull2];[FK_Case10_Case10Single];[FK_Case10_Case10Single2];[FK_Case10_Case10Single3];[FK_Case10_Case10Single4];[FK_Case10_Case10Single5];[FK_Case10_Case10Single6]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Foreign key renaming from a name with "*" in it', FilterSchema = 'FromSpecialChar', FilterTable = 'Case11', Expected = '[FK_Case11_Case11Cascade];[FK_Case11_Case11Cascade2];[FK_Case11_Case11Multi];[FK_Case11_Case11SetDefault];[FK_Case11_Case11SetDefault2];[FK_Case11_Case11SetNull];[FK_Case11_Case11SetNull2];[FK_Case11_Case11Single];[FK_Case11_Case11Single2];[FK_Case11_Case11Single3];[FK_Case11_Case11Single4];[FK_Case11_Case11Single5];[FK_Case11_Case11Single6]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Foreign key renaming from a name with "[" in it', FilterSchema = 'FromSpecialChar', FilterTable = 'Case12', Expected = '[FK_Case12_Case12Cascade];[FK_Case12_Case12Cascade2];[FK_Case12_Case12Multi];[FK_Case12_Case12SetDefault];[FK_Case12_Case12SetDefault2];[FK_Case12_Case12SetNull];[FK_Case12_Case12SetNull2];[FK_Case12_Case12Single];[FK_Case12_Case12Single2];[FK_Case12_Case12Single3];[FK_Case12_Case12Single4];[FK_Case12_Case12Single5];[FK_Case12_Case12Single6]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Foreign key renaming from a name with "]" in it', FilterSchema = 'FromSpecialChar', FilterTable = 'Case13', Expected = '[FK_Case13_Case13Cascade];[FK_Case13_Case13Cascade2];[FK_Case13_Case13Multi];[FK_Case13_Case13SetDefault];[FK_Case13_Case13SetDefault2];[FK_Case13_Case13SetNull];[FK_Case13_Case13SetNull2];[FK_Case13_Case13Single];[FK_Case13_Case13Single2];[FK_Case13_Case13Single3];[FK_Case13_Case13Single4];[FK_Case13_Case13Single5];[FK_Case13_Case13Single6]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Foreign key renaming from a name with "-" in it', FilterSchema = 'FromSpecialChar', FilterTable = 'Case14', Expected = '[FK_Case14_Case14Cascade];[FK_Case14_Case14Cascade2];[FK_Case14_Case14Multi];[FK_Case14_Case14SetDefault];[FK_Case14_Case14SetDefault2];[FK_Case14_Case14SetNull];[FK_Case14_Case14SetNull2];[FK_Case14_Case14Single];[FK_Case14_Case14Single2];[FK_Case14_Case14Single3];[FK_Case14_Case14Single4];[FK_Case14_Case14Single5];[FK_Case14_Case14Single6]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Foreign key renaming from a name with "+" in it', FilterSchema = 'FromSpecialChar', FilterTable = 'Case15', Expected = '[FK_Case15_Case15Cascade];[FK_Case15_Case15Cascade2];[FK_Case15_Case15Multi];[FK_Case15_Case15SetDefault];[FK_Case15_Case15SetDefault2];[FK_Case15_Case15SetNull];[FK_Case15_Case15SetNull2];[FK_Case15_Case15Single];[FK_Case15_Case15Single2];[FK_Case15_Case15Single3];[FK_Case15_Case15Single4];[FK_Case15_Case15Single5];[FK_Case15_Case15Single6]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Foreign key renaming from a name surrounded with ""', FilterSchema = 'FromSpecialChar', FilterTable = 'Case16', Expected = '[FK_Case16_Case16Cascade];[FK_Case16_Case16Cascade2];[FK_Case16_Case16Multi];[FK_Case16_Case16SetDefault];[FK_Case16_Case16SetDefault2];[FK_Case16_Case16SetNull];[FK_Case16_Case16SetNull2];[FK_Case16_Case16Single];[FK_Case16_Case16Single2];[FK_Case16_Case16Single3];[FK_Case16_Case16Single4];[FK_Case16_Case16Single5];[FK_Case16_Case16Single6]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Foreign key renaming from a name surrounded with []', FilterSchema = 'FromSpecialChar', FilterTable = 'Case17', Expected = '[FK_Case17_Case17Cascade];[FK_Case17_Case17Cascade2];[FK_Case17_Case17Multi];[FK_Case17_Case17SetDefault];[FK_Case17_Case17SetDefault2];[FK_Case17_Case17SetNull];[FK_Case17_Case17SetNull2];[FK_Case17_Case17Single];[FK_Case17_Case17Single2];[FK_Case17_Case17Single3];[FK_Case17_Case17Single4];[FK_Case17_Case17Single5];[FK_Case17_Case17Single6]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Foreign key renaming from a name surrounded with ''''', FilterSchema = 'FromSpecialChar', FilterTable = 'Case18', Expected = '[FK_Case18_Case18Cascade];[FK_Case18_Case18Cascade2];[FK_Case18_Case18Multi];[FK_Case18_Case18SetDefault];[FK_Case18_Case18SetDefault2];[FK_Case18_Case18SetNull];[FK_Case18_Case18SetNull2];[FK_Case18_Case18Single];[FK_Case18_Case18Single2];[FK_Case18_Case18Single3];[FK_Case18_Case18Single4];[FK_Case18_Case18Single5];[FK_Case18_Case18Single6]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Foreign key renaming from a name with "." in the middle', FilterSchema = 'FromSpecialChar', FilterTable = 'Case19', Expected = '[FK_Case19_Case19Cascade];[FK_Case19_Case19Cascade2];[FK_Case19_Case19Multi];[FK_Case19_Case19SetDefault];[FK_Case19_Case19SetDefault2];[FK_Case19_Case19SetNull];[FK_Case19_Case19SetNull2];[FK_Case19_Case19Single];[FK_Case19_Case19Single2];[FK_Case19_Case19Single3];[FK_Case19_Case19Single4];[FK_Case19_Case19Single5];[FK_Case19_Case19Single6]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Foreign key renaming from a name with " " in the middle',FilterSchema = 'FromSpecialChar', FilterTable = 'Case20', Expected = '[FK_Case20_Case20Cascade];[FK_Case20_Case20Cascade2];[FK_Case20_Case20Multi];[FK_Case20_Case20SetDefault];[FK_Case20_Case20SetDefault2];[FK_Case20_Case20SetNull];[FK_Case20_Case20SetNull2];[FK_Case20_Case20Single];[FK_Case20_Case20Single2];[FK_Case20_Case20Single3];[FK_Case20_Case20Single4];[FK_Case20_Case20Single5];[FK_Case20_Case20Single6]'

INSERT #TestCases (TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Foreign key renaming to a name with "_" in it', FilterSchema = 'ToSpecialChar', FilterTable = 'Case01_', Expected = '[FK_Case01__Case01_Cascade];[FK_Case01__Case01_Cascade2];[FK_Case01__Case01_Multi];[FK_Case01__Case01_SetDefault];[FK_Case01__Case01_SetDefault2];[FK_Case01__Case01_SetNull];[FK_Case01__Case01_SetNull2];[FK_Case01__Case01_Single];[FK_Case01__Case01_Single2];[FK_Case01__Case01_Single3];[FK_Case01__Case01_Single4];[FK_Case01__Case01_Single5];[FK_Case01__Case01_Single6]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Foreign key renaming to a name with leading space', FilterSchema = 'ToSpecialChar', FilterTable = '[ ]Case02', Expected = '[FK_ Case02_ Case02Cascade];[FK_ Case02_ Case02Cascade2];[FK_ Case02_ Case02Multi];[FK_ Case02_ Case02SetDefault];[FK_ Case02_ Case02SetDefault2];[FK_ Case02_ Case02SetNull];[FK_ Case02_ Case02SetNull2];[FK_ Case02_ Case02Single];[FK_ Case02_ Case02Single2];[FK_ Case02_ Case02Single3];[FK_ Case02_ Case02Single4];[FK_ Case02_ Case02Single5];[FK_ Case02_ Case02Single6]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Foreign key renaming to a name with trailing space', FilterSchema = 'ToSpecialChar', FilterTable = 'Case03[ ]', Expected = '[FK_Case03 _Case03 Cascade];[FK_Case03 _Case03 Cascade2];[FK_Case03 _Case03 Multi];[FK_Case03 _Case03 SetDefault];[FK_Case03 _Case03 SetDefault2];[FK_Case03 _Case03 SetNull];[FK_Case03 _Case03 SetNull2];[FK_Case03 _Case03 Single];[FK_Case03 _Case03 Single2];[FK_Case03 _Case03 Single3];[FK_Case03 _Case03 Single4];[FK_Case03 _Case03 Single5];[FK_Case03 _Case03 Single6]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Foreign key renaming to a name with "?" in it', FilterSchema = 'ToSpecialChar', FilterTable = 'Case04?', Expected = '[FK_Case04?_Case04?Cascade];[FK_Case04?_Case04?Cascade2];[FK_Case04?_Case04?Multi];[FK_Case04?_Case04?SetDefault];[FK_Case04?_Case04?SetDefault2];[FK_Case04?_Case04?SetNull];[FK_Case04?_Case04?SetNull2];[FK_Case04?_Case04?Single];[FK_Case04?_Case04?Single2];[FK_Case04?_Case04?Single3];[FK_Case04?_Case04?Single4];[FK_Case04?_Case04?Single5];[FK_Case04?_Case04?Single6]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Foreign key renaming to a name with "%" in it', FilterSchema = 'ToSpecialChar', FilterTable = 'Case05%', Expected = '[FK_Case05%_Case05%Cascade];[FK_Case05%_Case05%Cascade2];[FK_Case05%_Case05%Multi];[FK_Case05%_Case05%SetDefault];[FK_Case05%_Case05%SetDefault2];[FK_Case05%_Case05%SetNull];[FK_Case05%_Case05%SetNull2];[FK_Case05%_Case05%Single];[FK_Case05%_Case05%Single2];[FK_Case05%_Case05%Single3];[FK_Case05%_Case05%Single4];[FK_Case05%_Case05%Single5];[FK_Case05%_Case05%Single6]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Foreign key renaming to a name with "^" in it', FilterSchema = 'ToSpecialChar', FilterTable = 'Case06^', Expected = '[FK_Case06^_Case06^Cascade];[FK_Case06^_Case06^Cascade2];[FK_Case06^_Case06^Multi];[FK_Case06^_Case06^SetDefault];[FK_Case06^_Case06^SetDefault2];[FK_Case06^_Case06^SetNull];[FK_Case06^_Case06^SetNull2];[FK_Case06^_Case06^Single];[FK_Case06^_Case06^Single2];[FK_Case06^_Case06^Single3];[FK_Case06^_Case06^Single4];[FK_Case06^_Case06^Single5];[FK_Case06^_Case06^Single6]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Foreign key renaming to a name with "''" in it', FilterSchema = 'ToSpecialChar', FilterTable = 'Case07''', Expected = '[FK_Case07''_Case07''Cascade];[FK_Case07''_Case07''Cascade2];[FK_Case07''_Case07''Multi];[FK_Case07''_Case07''SetDefault];[FK_Case07''_Case07''SetDefault2];[FK_Case07''_Case07''SetNull];[FK_Case07''_Case07''SetNull2];[FK_Case07''_Case07''Single];[FK_Case07''_Case07''Single2];[FK_Case07''_Case07''Single3];[FK_Case07''_Case07''Single4];[FK_Case07''_Case07''Single5];[FK_Case07''_Case07''Single6]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Foreign key renaming to a name with """ in it', FilterSchema = 'ToSpecialChar', FilterTable = 'Case08"', Expected = '[FK_Case08"_Case08"Cascade];[FK_Case08"_Case08"Cascade2];[FK_Case08"_Case08"Multi];[FK_Case08"_Case08"SetDefault];[FK_Case08"_Case08"SetDefault2];[FK_Case08"_Case08"SetNull];[FK_Case08"_Case08"SetNull2];[FK_Case08"_Case08"Single];[FK_Case08"_Case08"Single2];[FK_Case08"_Case08"Single3];[FK_Case08"_Case08"Single4];[FK_Case08"_Case08"Single5];[FK_Case08"_Case08"Single6]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Foreign key renaming to a name with "," in it', FilterSchema = 'ToSpecialChar', FilterTable = 'Case09,,', Expected = '[FK_Case09,_Case09,Cascade];[FK_Case09,_Case09,Cascade2];[FK_Case09,_Case09,Multi];[FK_Case09,_Case09,SetDefault];[FK_Case09,_Case09,SetDefault2];[FK_Case09,_Case09,SetNull];[FK_Case09,_Case09,SetNull2];[FK_Case09,_Case09,Single];[FK_Case09,_Case09,Single2];[FK_Case09,_Case09,Single3];[FK_Case09,_Case09,Single4];[FK_Case09,_Case09,Single5];[FK_Case09,_Case09,Single6]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Foreign key renaming to a name with "." in it', FilterSchema = 'ToSpecialChar', FilterTable = 'Case10.', Expected = '[FK_Case10._Case10.Cascade];[FK_Case10._Case10.Cascade2];[FK_Case10._Case10.Multi];[FK_Case10._Case10.SetDefault];[FK_Case10._Case10.SetDefault2];[FK_Case10._Case10.SetNull];[FK_Case10._Case10.SetNull2];[FK_Case10._Case10.Single];[FK_Case10._Case10.Single2];[FK_Case10._Case10.Single3];[FK_Case10._Case10.Single4];[FK_Case10._Case10.Single5];[FK_Case10._Case10.Single6]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Foreign key renaming to a name with "*" in it', FilterSchema = 'ToSpecialChar', FilterTable = 'Case11*', Expected = '[FK_Case11*_Case11*Cascade];[FK_Case11*_Case11*Cascade2];[FK_Case11*_Case11*Multi];[FK_Case11*_Case11*SetDefault];[FK_Case11*_Case11*SetDefault2];[FK_Case11*_Case11*SetNull];[FK_Case11*_Case11*SetNull2];[FK_Case11*_Case11*Single];[FK_Case11*_Case11*Single2];[FK_Case11*_Case11*Single3];[FK_Case11*_Case11*Single4];[FK_Case11*_Case11*Single5];[FK_Case11*_Case11*Single6]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Foreign key renaming to a name with "[" in it', FilterSchema = 'ToSpecialChar', FilterTable = 'Case12[[]', Expected = '[FK_Case12[_Case12[Cascade];[FK_Case12[_Case12[Cascade2];[FK_Case12[_Case12[Multi];[FK_Case12[_Case12[SetDefault];[FK_Case12[_Case12[SetDefault2];[FK_Case12[_Case12[SetNull];[FK_Case12[_Case12[SetNull2];[FK_Case12[_Case12[Single];[FK_Case12[_Case12[Single2];[FK_Case12[_Case12[Single3];[FK_Case12[_Case12[Single4];[FK_Case12[_Case12[Single5];[FK_Case12[_Case12[Single6]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Foreign key renaming to a name with "]" in it', FilterSchema = 'ToSpecialChar', FilterTable = 'Case13]', Expected = '[FK_Case13]]_Case13]]Cascade];[FK_Case13]]_Case13]]Cascade2];[FK_Case13]]_Case13]]Multi];[FK_Case13]]_Case13]]SetDefault];[FK_Case13]]_Case13]]SetDefault2];[FK_Case13]]_Case13]]SetNull];[FK_Case13]]_Case13]]SetNull2];[FK_Case13]]_Case13]]Single];[FK_Case13]]_Case13]]Single2];[FK_Case13]]_Case13]]Single3];[FK_Case13]]_Case13]]Single4];[FK_Case13]]_Case13]]Single5];[FK_Case13]]_Case13]]Single6]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Foreign key renaming to a name with "-" in it', FilterSchema = 'ToSpecialChar', FilterTable = 'Case14-', Expected = '[FK_Case14-_Case14-Cascade];[FK_Case14-_Case14-Cascade2];[FK_Case14-_Case14-Multi];[FK_Case14-_Case14-SetDefault];[FK_Case14-_Case14-SetDefault2];[FK_Case14-_Case14-SetNull];[FK_Case14-_Case14-SetNull2];[FK_Case14-_Case14-Single];[FK_Case14-_Case14-Single2];[FK_Case14-_Case14-Single3];[FK_Case14-_Case14-Single4];[FK_Case14-_Case14-Single5];[FK_Case14-_Case14-Single6]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Foreign key renaming to a name with "+" in it', FilterSchema = 'ToSpecialChar', FilterTable = 'Case15+', Expected = '[FK_Case15+_Case15+Cascade];[FK_Case15+_Case15+Cascade2];[FK_Case15+_Case15+Multi];[FK_Case15+_Case15+SetDefault];[FK_Case15+_Case15+SetDefault2];[FK_Case15+_Case15+SetNull];[FK_Case15+_Case15+SetNull2];[FK_Case15+_Case15+Single];[FK_Case15+_Case15+Single2];[FK_Case15+_Case15+Single3];[FK_Case15+_Case15+Single4];[FK_Case15+_Case15+Single5];[FK_Case15+_Case15+Single6]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Foreign key renaming to a name surrounded with ""', FilterSchema = 'ToSpecialChar', FilterTable = '"Case16"', Expected = '[FK_"Case16"_"Case16"Cascade];[FK_"Case16"_"Case16"Cascade2];[FK_"Case16"_"Case16"Multi];[FK_"Case16"_"Case16"SetDefault];[FK_"Case16"_"Case16"SetDefault2];[FK_"Case16"_"Case16"SetNull];[FK_"Case16"_"Case16"SetNull2];[FK_"Case16"_"Case16"Single];[FK_"Case16"_"Case16"Single2];[FK_"Case16"_"Case16"Single3];[FK_"Case16"_"Case16"Single4];[FK_"Case16"_"Case16"Single5];[FK_"Case16"_"Case16"Single6]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Foreign key renaming to a name surrounded with []', FilterSchema = 'ToSpecialChar', FilterTable = '[[]Case17]', Expected = '[FK_[Case17]]_[Case17]]Cascade];[FK_[Case17]]_[Case17]]Cascade2];[FK_[Case17]]_[Case17]]Multi];[FK_[Case17]]_[Case17]]SetDefault];[FK_[Case17]]_[Case17]]SetDefault2];[FK_[Case17]]_[Case17]]SetNull];[FK_[Case17]]_[Case17]]SetNull2];[FK_[Case17]]_[Case17]]Single];[FK_[Case17]]_[Case17]]Single2];[FK_[Case17]]_[Case17]]Single3];[FK_[Case17]]_[Case17]]Single4];[FK_[Case17]]_[Case17]]Single5];[FK_[Case17]]_[Case17]]Single6]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Foreign key renaming to a name surrounded with ''''', FilterSchema = 'ToSpecialChar', FilterTable = '''Case18''', Expected = '[FK_''Case18''_''Case18''Cascade];[FK_''Case18''_''Case18''Cascade2];[FK_''Case18''_''Case18''Multi];[FK_''Case18''_''Case18''SetDefault];[FK_''Case18''_''Case18''SetDefault2];[FK_''Case18''_''Case18''SetNull];[FK_''Case18''_''Case18''SetNull2];[FK_''Case18''_''Case18''Single];[FK_''Case18''_''Case18''Single2];[FK_''Case18''_''Case18''Single3];[FK_''Case18''_''Case18''Single4];[FK_''Case18''_''Case18''Single5];[FK_''Case18''_''Case18''Single6]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Foreign key renaming to a name with "." in the middle', FilterSchema = 'ToSpecialChar', FilterTable = 'Case.19', Expected = '[FK_Case.19_Case.19Cascade];[FK_Case.19_Case.19Cascade2];[FK_Case.19_Case.19Multi];[FK_Case.19_Case.19SetDefault];[FK_Case.19_Case.19SetDefault2];[FK_Case.19_Case.19SetNull];[FK_Case.19_Case.19SetNull2];[FK_Case.19_Case.19Single];[FK_Case.19_Case.19Single2];[FK_Case.19_Case.19Single3];[FK_Case.19_Case.19Single4];[FK_Case.19_Case.19Single5];[FK_Case.19_Case.19Single6]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Foreign key renaming to a name with " " in the middle',FilterSchema = 'ToSpecialChar', FilterTable = 'Case 20', Expected = '[FK_Case 20_Case 20Cascade];[FK_Case 20_Case 20Cascade2];[FK_Case 20_Case 20Multi];[FK_Case 20_Case 20SetDefault];[FK_Case 20_Case 20SetDefault2];[FK_Case 20_Case 20SetNull];[FK_Case 20_Case 20SetNull2];[FK_Case 20_Case 20Single];[FK_Case 20_Case 20Single2];[FK_Case 20_Case 20Single3];[FK_Case 20_Case 20Single4];[FK_Case 20_Case 20Single5];[FK_Case 20_Case 20Single6]'

INSERT #TestCases (TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Foreign key renaming - filtered', FilterSchema = 'FilteredRenaming', FilterTable = 'Case01', Expected = '[FK_Case01_Case01Cascade];[FK_Case01_Case01Cascade2];[FK_Case01_Case01Multi];[FK_Case01_Case01SetDefault];[FK_Case01_Case01SetDefault2];[FK_Case01_Case01SetNull];[FK_Case01_Case01SetNull2];[FK_Case01_Case01Single];[FK_Case01_Case01Single2];[FK_Case01_Case01Single3];[FK_Case01_Case01Single4];[FK_Case01_Case01Single5];[FK_Case01_Case01Single6]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, NamingConvention, Expected) SELECT TestDesc = 'Foreign key renaming - with schema token', FilterSchema = 'CustomWithSchema', FilterTable = 'Case01', NamingConvention = 'FK_%PARENT_SCHEMA_NAME%_%PARENT_TABLE_NAME%~%REFERENCED_SCHEMA_NAME%_%REFERENCED_TABLE_NAME%', Expected = '[FK_CustomWithSchema_Case01~CustomWithSchema_Case01Cascade];[FK_CustomWithSchema_Case01~CustomWithSchema_Case01Cascade2];[FK_CustomWithSchema_Case01~CustomWithSchema_Case01Multi];[FK_CustomWithSchema_Case01~CustomWithSchema_Case01SetDefault];[FK_CustomWithSchema_Case01~CustomWithSchema_Case01SetDefault2];[FK_CustomWithSchema_Case01~CustomWithSchema_Case01SetNull];[FK_CustomWithSchema_Case01~CustomWithSchema_Case01SetNull2];[FK_CustomWithSchema_Case01~CustomWithSchema_Case01Single];[FK_CustomWithSchema_Case01~CustomWithSchema_Case01Single2];[FK_CustomWithSchema_Case01~CustomWithSchema_Case01Single3];[FK_CustomWithSchema_Case01~CustomWithSchema_Case01Single4];[FK_CustomWithSchema_Case01~CustomWithSchema_Case01Single5];[FK_CustomWithSchema_Case01~CustomWithSchema_Case01Single6]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, NamingConvention, Expected) SELECT TestDesc = 'Foreign key renaming - with parent columns', FilterSchema = 'CustomWithParCols', FilterTable = 'Case01', NamingConvention = 'FK_%PARENT_TABLE_NAME%~%REFERENCED_TABLE_NAME%:%PARENT_COLUMNS%', Expected = '[FK_Case01~Case01Cascade:ColB];[FK_Case01~Case01Cascade:ColF];[FK_Case01~Case01Multi:ColE_ColF_ColG_ColH];[FK_Case01~Case01SetDefault:ColD];[FK_Case01~Case01SetDefault:ColH];[FK_Case01~Case01SetNull:ColC];[FK_Case01~Case01SetNull:ColG];[FK_Case01~Case01Single:ColA];[FK_Case01~Case01Single:ColA2];[FK_Case01~Case01Single:ColA3];[FK_Case01~Case01Single:ColB];[FK_Case01~Case01Single:ColC];[FK_Case01~Case01Single:ColE]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, NamingConvention, Expected) SELECT TestDesc = 'Foreign key renaming - with refenced columns', FilterSchema = 'CustomWithRefCols', FilterTable = 'Case01', NamingConvention = 'FK_%PARENT_TABLE_NAME%~%REFERENCED_TABLE_NAME%:%REFERENCED_COLUMNS%', Expected = '[FK_Case01~Case01Cascade:Id];[FK_Case01~Case01Cascade:Id2];[FK_Case01~Case01Multi:ColW_ColX_ColY_ColZ];[FK_Case01~Case01SetDefault:Id];[FK_Case01~Case01SetDefault:Id2];[FK_Case01~Case01SetNull:Id];[FK_Case01~Case01SetNull:Id2];[FK_Case01~Case01Single:Id];[FK_Case01~Case01Single:Id2];[FK_Case01~Case01Single:Id3];[FK_Case01~Case01Single:Id4];[FK_Case01~Case01Single:Id5];[FK_Case01~Case01Single:Id6]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, ColumnsSeparator, NamingConvention, Expected) SELECT TestDesc = 'Foreign key renaming - with custom column separator', FilterSchema = 'CustomWithColSep', FilterTable = 'Case01', ColumnsSeparator = '-', NamingConvention = 'FK_%PARENT_TABLE_NAME%~%REFERENCED_TABLE_NAME%:%PARENT_COLUMNS%', Expected = '[FK_Case01~Case01Cascade:ColB];[FK_Case01~Case01Cascade:ColF];[FK_Case01~Case01Multi:ColE-ColF-ColG-ColH];[FK_Case01~Case01SetDefault:ColD];[FK_Case01~Case01SetDefault:ColH];[FK_Case01~Case01SetNull:ColC];[FK_Case01~Case01SetNull:ColG];[FK_Case01~Case01Single:ColA];[FK_Case01~Case01Single:ColA2];[FK_Case01~Case01Single:ColA3];[FK_Case01~Case01Single:ColB];[FK_Case01~Case01Single:ColC];[FK_Case01~Case01Single:ColE]'

INSERT #TestCases (TestDesc, FilterSchema, FilterTable, EnabledStates, NamingConvention, Expected) SELECT TestDesc = 'Foreign key renaming - with enabled states - both', FilterSchema = 'CustomWithEnabledState', FilterTable = 'Case01', EnabledStates = 'ENABLED_STATE_YES=_Enabled,ENABLED_STATE_NO=_Disabled', NamingConvention = 'FK_%PARENT_TABLE_NAME%~%REFERENCED_TABLE_NAME%%ENABLED_STATE%', Expected = '[FK_Case01~Case01Cascade_Enabled];[FK_Case01~Case01Cascade_Enabled2];[FK_Case01~Case01Multi_Enabled];[FK_Case01~Case01SetDefault_Enabled];[FK_Case01~Case01SetDefault_Enabled2];[FK_Case01~Case01SetNull_Enabled];[FK_Case01~Case01SetNull_Enabled2];[FK_Case01~Case01Single_Disabled];[FK_Case01~Case01Single_Enabled];[FK_Case01~Case01Single_Enabled2];[FK_Case01~Case01Single_Enabled3];[FK_Case01~Case01Single_Enabled4];[FK_Case01~Case01Single_Enabled5]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, EnabledStates, NamingConvention, Expected) SELECT TestDesc = 'Foreign key renaming - with enabled states - disabled only', FilterSchema = 'CustomWithEnabledState', FilterTable = 'Case02', EnabledStates = 'ENABLED_STATE_NO=_Disabled', NamingConvention = 'FK_%PARENT_TABLE_NAME%~%REFERENCED_TABLE_NAME%%ENABLED_STATE%', Expected = '[FK_Case02~Case02Cascade];[FK_Case02~Case02Cascade2];[FK_Case02~Case02Multi];[FK_Case02~Case02SetDefault];[FK_Case02~Case02SetDefault2];[FK_Case02~Case02SetNull];[FK_Case02~Case02SetNull2];[FK_Case02~Case02Single];[FK_Case02~Case02Single_Disabled];[FK_Case02~Case02Single2];[FK_Case02~Case02Single3];[FK_Case02~Case02Single4];[FK_Case02~Case02Single5]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, EnabledStates, NamingConvention, Expected) SELECT TestDesc = 'Foreign key renaming - with enabled states - empty', FilterSchema = 'CustomWithEnabledState', FilterTable = 'Case03', EnabledStates = '', NamingConvention = 'FK_%PARENT_TABLE_NAME%~%REFERENCED_TABLE_NAME%%ENABLED_STATE%', Expected = '[FK_Case03~Case03Cascade];[FK_Case03~Case03Cascade2];[FK_Case03~Case03Multi];[FK_Case03~Case03SetDefault];[FK_Case03~Case03SetDefault2];[FK_Case03~Case03SetNull];[FK_Case03~Case03SetNull2];[FK_Case03~Case03Single];[FK_Case03~Case03Single2];[FK_Case03~Case03Single3];[FK_Case03~Case03Single4];[FK_Case03~Case03Single5];[FK_Case03~Case03Single6]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, NamingConvention, Expected) SELECT TestDesc = 'Foreign key renaming - with enabled states - default', FilterSchema = 'CustomWithEnabledState', FilterTable = 'Case04', NamingConvention = 'FK_%PARENT_TABLE_NAME%~%REFERENCED_TABLE_NAME%%ENABLED_STATE%', Expected = '[FK_Case04~Case04Cascade];[FK_Case04~Case04Cascade2];[FK_Case04~Case04Multi];[FK_Case04~Case04SetDefault];[FK_Case04~Case04SetDefault2];[FK_Case04~Case04SetNull];[FK_Case04~Case04SetNull2];[FK_Case04~Case04Single];[FK_Case04~Case04Single_Disabled];[FK_Case04~Case04Single2];[FK_Case04~Case04Single3];[FK_Case04~Case04Single4];[FK_Case04~Case04Single5]'

INSERT #TestCases (TestDesc, FilterSchema, FilterTable, ReplicationStates, NamingConvention, Expected) SELECT TestDesc = 'Foreign key renaming - with replication states - all', FilterSchema = 'CustomWithReplicationState', FilterTable = 'Case01', ReplicationStates = 'REPLICATION_STATE_YES=_ForRepl,REPLICATION_STATE_NO=_NotForRepl', NamingConvention = 'FK_%PARENT_TABLE_NAME%~%REFERENCED_TABLE_NAME%%REPLICATION_STATE%', Expected = '[FK_Case01~Case01Cascade_ForRepl];[FK_Case01~Case01Cascade_ForRepl2];[FK_Case01~Case01Multi_ForRepl];[FK_Case01~Case01SetDefault_ForRepl];[FK_Case01~Case01SetDefault_ForRepl2];[FK_Case01~Case01SetNull_ForRepl];[FK_Case01~Case01SetNull_ForRepl2];[FK_Case01~Case01Single_ForRepl];[FK_Case01~Case01Single_ForRepl2];[FK_Case01~Case01Single_ForRepl3];[FK_Case01~Case01Single_ForRepl4];[FK_Case01~Case01Single_ForRepl5];[FK_Case01~Case01Single_NotForRepl]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, ReplicationStates, NamingConvention, Expected) SELECT TestDesc = 'Foreign key renaming - with replication states - not for repl only', FilterSchema = 'CustomWithReplicationState', FilterTable = 'Case02', ReplicationStates = 'REPLICATION_STATE_NO=_NotForRepl', NamingConvention = 'FK_%PARENT_TABLE_NAME%~%REFERENCED_TABLE_NAME%%REPLICATION_STATE%', Expected = '[FK_Case02~Case02Cascade];[FK_Case02~Case02Cascade2];[FK_Case02~Case02Multi];[FK_Case02~Case02SetDefault];[FK_Case02~Case02SetDefault2];[FK_Case02~Case02SetNull];[FK_Case02~Case02SetNull2];[FK_Case02~Case02Single];[FK_Case02~Case02Single_NotForRepl];[FK_Case02~Case02Single2];[FK_Case02~Case02Single3];[FK_Case02~Case02Single4];[FK_Case02~Case02Single5]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, ReplicationStates, NamingConvention, Expected) SELECT TestDesc = 'Foreign key renaming - with replication states - empty', FilterSchema = 'CustomWithReplicationState', FilterTable = 'Case03', ReplicationStates = '', NamingConvention = 'FK_%PARENT_TABLE_NAME%~%REFERENCED_TABLE_NAME%%REPLICATION_STATE%', Expected = '[FK_Case03~Case03Cascade];[FK_Case03~Case03Cascade2];[FK_Case03~Case03Multi];[FK_Case03~Case03SetDefault];[FK_Case03~Case03SetDefault2];[FK_Case03~Case03SetNull];[FK_Case03~Case03SetNull2];[FK_Case03~Case03Single];[FK_Case03~Case03Single2];[FK_Case03~Case03Single3];[FK_Case03~Case03Single4];[FK_Case03~Case03Single5];[FK_Case03~Case03Single6]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, NamingConvention, Expected) SELECT TestDesc = 'Foreign key renaming - with replication states - default', FilterSchema = 'CustomWithReplicationState', FilterTable = 'Case04', NamingConvention = 'FK_%PARENT_TABLE_NAME%~%REFERENCED_TABLE_NAME%%REPLICATION_STATE%', Expected = '[FK_Case04~Case04Cascade];[FK_Case04~Case04Cascade2];[FK_Case04~Case04Multi];[FK_Case04~Case04SetDefault];[FK_Case04~Case04SetDefault2];[FK_Case04~Case04SetNull];[FK_Case04~Case04SetNull2];[FK_Case04~Case04Single];[FK_Case04~Case04Single_NotForRepl];[FK_Case04~Case04Single2];[FK_Case04~Case04Single3];[FK_Case04~Case04Single4];[FK_Case04~Case04Single5]'

INSERT #TestCases (TestDesc, FilterSchema, FilterTable, TrustedStates, NamingConvention, Expected) SELECT TestDesc = 'Foreign key renaming - with trusted states - all', FilterSchema = 'CustomWithTrustedState', FilterTable = 'Case01', TrustedStates = 'TRUSTED_STATE_YES=_Trusted,TRUSTED_STATE_NO=_Untrusted', NamingConvention = 'FK_%PARENT_TABLE_NAME%~%REFERENCED_TABLE_NAME%%TRUSTED_STATE%', Expected = '[FK_Case01~Case01Cascade_Trusted];[FK_Case01~Case01Cascade_Trusted2];[FK_Case01~Case01Multi_Trusted];[FK_Case01~Case01SetDefault_Trusted];[FK_Case01~Case01SetDefault_Trusted2];[FK_Case01~Case01SetNull_Trusted];[FK_Case01~Case01SetNull_Trusted2];[FK_Case01~Case01Single_Trusted];[FK_Case01~Case01Single_Trusted2];[FK_Case01~Case01Single_Trusted3];[FK_Case01~Case01Single_Untrusted];[FK_Case01~Case01Single_Untrusted2];[FK_Case01~Case01Single_Untrusted3]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, TrustedStates, NamingConvention, Expected) SELECT TestDesc = 'Foreign key renaming - with trusted states - untrusted only', FilterSchema = 'CustomWithTrustedState', FilterTable = 'Case02', TrustedStates = 'TRUSTED_STATE_NO=_Untrusted', NamingConvention = 'FK_%PARENT_TABLE_NAME%~%REFERENCED_TABLE_NAME%%TRUSTED_STATE%', Expected = '[FK_Case02~Case02Cascade];[FK_Case02~Case02Cascade2];[FK_Case02~Case02Multi];[FK_Case02~Case02SetDefault];[FK_Case02~Case02SetDefault2];[FK_Case02~Case02SetNull];[FK_Case02~Case02SetNull2];[FK_Case02~Case02Single];[FK_Case02~Case02Single_Untrusted];[FK_Case02~Case02Single_Untrusted2];[FK_Case02~Case02Single_Untrusted3];[FK_Case02~Case02Single2];[FK_Case02~Case02Single3]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, TrustedStates, NamingConvention, Expected) SELECT TestDesc = 'Foreign key renaming - with trusted states - empty', FilterSchema = 'CustomWithTrustedState', FilterTable = 'Case03', TrustedStates = '', NamingConvention = 'FK_%PARENT_TABLE_NAME%~%REFERENCED_TABLE_NAME%%TRUSTED_STATE%', Expected = '[FK_Case03~Case03Cascade];[FK_Case03~Case03Cascade2];[FK_Case03~Case03Multi];[FK_Case03~Case03SetDefault];[FK_Case03~Case03SetDefault2];[FK_Case03~Case03SetNull];[FK_Case03~Case03SetNull2];[FK_Case03~Case03Single];[FK_Case03~Case03Single2];[FK_Case03~Case03Single3];[FK_Case03~Case03Single4];[FK_Case03~Case03Single5];[FK_Case03~Case03Single6]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, NamingConvention, Expected) SELECT TestDesc = 'Foreign key renaming - with trusted states - default', FilterSchema = 'CustomWithTrustedState', FilterTable = 'Case04', NamingConvention = 'FK_%PARENT_TABLE_NAME%~%REFERENCED_TABLE_NAME%%TRUSTED_STATE%', Expected = '[FK_Case04~Case04Cascade];[FK_Case04~Case04Cascade2];[FK_Case04~Case04Multi];[FK_Case04~Case04SetDefault];[FK_Case04~Case04SetDefault2];[FK_Case04~Case04SetNull];[FK_Case04~Case04SetNull2];[FK_Case04~Case04Single];[FK_Case04~Case04Single_Untrusted];[FK_Case04~Case04Single_Untrusted2];[FK_Case04~Case04Single_Untrusted3];[FK_Case04~Case04Single2];[FK_Case04~Case04Single3]'

INSERT #TestCases (TestDesc, FilterSchema, FilterTable, DeleteRefActions, NamingConvention, Expected) SELECT TestDesc = 'Foreign key renaming - with delete ref actions - all', FilterSchema = 'CustomWithDelRefActions', FilterTable = 'Case01', DeleteRefActions = 'DEL_REF_NO_ACTION=_DelRefNoAction,DEL_REF_CASCADE=_DelRefCascade,DEL_REF_SET_NULL=_DelRefSetNull,DEL_REF_SET_DEFAULT=_DelRefSetDefault', NamingConvention = 'FK_%PARENT_TABLE_NAME%~%REFERENCED_TABLE_NAME%%DEL_REF_ACTION%', Expected = '[FK_Case01~Case01Cascade_DelRefCascade];[FK_Case01~Case01Cascade_DelRefNoAction];[FK_Case01~Case01Multi_DelRefNoAction];[FK_Case01~Case01SetDefault_DelRefNoAction];[FK_Case01~Case01SetDefault_DelRefSetDefault];[FK_Case01~Case01SetNull_DelRefNoAction];[FK_Case01~Case01SetNull_DelRefSetNull];[FK_Case01~Case01Single_DelRefNoAction];[FK_Case01~Case01Single_DelRefNoAction2];[FK_Case01~Case01Single_DelRefNoAction3];[FK_Case01~Case01Single_DelRefNoAction4];[FK_Case01~Case01Single_DelRefNoAction5];[FK_Case01~Case01Single_DelRefNoAction6]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, DeleteRefActions, NamingConvention, Expected) SELECT TestDesc = 'Foreign key renaming - with delete ref actions - except no actions', FilterSchema = 'CustomWithDelRefActions', FilterTable = 'Case02', DeleteRefActions = 'DEL_REF_CASCADE=_DelRefCascade,DEL_REF_SET_NULL=_DelRefSetNull,DEL_REF_SET_DEFAULT=_DelRefSetDefault', NamingConvention = 'FK_%PARENT_TABLE_NAME%~%REFERENCED_TABLE_NAME%%DEL_REF_ACTION%', Expected = '[FK_Case02~Case02Cascade];[FK_Case02~Case02Cascade_DelRefCascade];[FK_Case02~Case02Multi];[FK_Case02~Case02SetDefault];[FK_Case02~Case02SetDefault_DelRefSetDefault];[FK_Case02~Case02SetNull];[FK_Case02~Case02SetNull_DelRefSetNull];[FK_Case02~Case02Single];[FK_Case02~Case02Single2];[FK_Case02~Case02Single3];[FK_Case02~Case02Single4];[FK_Case02~Case02Single5];[FK_Case02~Case02Single6]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, DeleteRefActions, NamingConvention, Expected) SELECT TestDesc = 'Foreign key renaming - with delete ref actions - empty', FilterSchema = 'CustomWithDelRefActions', FilterTable = 'Case03', DeleteRefActions = '', NamingConvention = 'FK_%PARENT_TABLE_NAME%~%REFERENCED_TABLE_NAME%%DEL_REF_ACTION%', Expected = '[FK_Case03~Case03Cascade];[FK_Case03~Case03Cascade2];[FK_Case03~Case03Multi];[FK_Case03~Case03SetDefault];[FK_Case03~Case03SetDefault2];[FK_Case03~Case03SetNull];[FK_Case03~Case03SetNull2];[FK_Case03~Case03Single];[FK_Case03~Case03Single2];[FK_Case03~Case03Single3];[FK_Case03~Case03Single4];[FK_Case03~Case03Single5];[FK_Case03~Case03Single6]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, NamingConvention, Expected) SELECT TestDesc = 'Foreign key renaming - with delete ref actions - default', FilterSchema = 'CustomWithDelRefActions', FilterTable = 'Case04', NamingConvention = 'FK_%PARENT_TABLE_NAME%~%REFERENCED_TABLE_NAME%%DEL_REF_ACTION%', Expected = '[FK_Case04~Case04Cascade];[FK_Case04~Case04Cascade_DelRefCascade];[FK_Case04~Case04Multi];[FK_Case04~Case04SetDefault];[FK_Case04~Case04SetDefault_DelRefSetDefault];[FK_Case04~Case04SetNull];[FK_Case04~Case04SetNull_DelRefSetNull];[FK_Case04~Case04Single];[FK_Case04~Case04Single2];[FK_Case04~Case04Single3];[FK_Case04~Case04Single4];[FK_Case04~Case04Single5];[FK_Case04~Case04Single6]'

INSERT #TestCases (TestDesc, FilterSchema, FilterTable, UpdateRefActions, NamingConvention, Expected) SELECT TestDesc = 'Foreign key renaming - with update ref actions - all', FilterSchema = 'CustomWithUpdRefActions', FilterTable = 'Case01', UpdateRefActions = 'UPD_REF_NO_ACTION=_UpdRefNoAction,UPD_REF_CASCADE=_UpdRefCascade,UPD_REF_SET_NULL=_UpdRefSetNull,UPD_REF_SET_DEFAULT=_UpdRefSetDefault', NamingConvention = 'FK_%PARENT_TABLE_NAME%~%REFERENCED_TABLE_NAME%%UPD_REF_ACTION%', Expected = '[FK_Case01~Case01Cascade_UpdRefCascade];[FK_Case01~Case01Cascade_UpdRefNoAction];[FK_Case01~Case01Multi_UpdRefNoAction];[FK_Case01~Case01SetDefault_UpdRefNoAction];[FK_Case01~Case01SetDefault_UpdRefSetDefault];[FK_Case01~Case01SetNull_UpdRefNoAction];[FK_Case01~Case01SetNull_UpdRefSetNull];[FK_Case01~Case01Single_UpdRefNoAction];[FK_Case01~Case01Single_UpdRefNoAction2];[FK_Case01~Case01Single_UpdRefNoAction3];[FK_Case01~Case01Single_UpdRefNoAction4];[FK_Case01~Case01Single_UpdRefNoAction5];[FK_Case01~Case01Single_UpdRefNoAction6]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, UpdateRefActions, NamingConvention, Expected) SELECT TestDesc = 'Foreign key renaming - with update ref actions - except no actions', FilterSchema = 'CustomWithUpdRefActions', FilterTable = 'Case02', UpdateRefActions = 'UPD_REF_CASCADE=_UpdRefCascade,UPD_REF_SET_NULL=_UpdRefSetNull,UPD_REF_SET_DEFAULT=_UpdRefSetDefault', NamingConvention = 'FK_%PARENT_TABLE_NAME%~%REFERENCED_TABLE_NAME%%UPD_REF_ACTION%', Expected = '[FK_Case02~Case02Cascade];[FK_Case02~Case02Cascade_UpdRefCascade];[FK_Case02~Case02Multi];[FK_Case02~Case02SetDefault];[FK_Case02~Case02SetDefault_UpdRefSetDefault];[FK_Case02~Case02SetNull];[FK_Case02~Case02SetNull_UpdRefSetNull];[FK_Case02~Case02Single];[FK_Case02~Case02Single2];[FK_Case02~Case02Single3];[FK_Case02~Case02Single4];[FK_Case02~Case02Single5];[FK_Case02~Case02Single6]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, UpdateRefActions, NamingConvention, Expected) SELECT TestDesc = 'Foreign key renaming - with update ref actions - empty', FilterSchema = 'CustomWithUpdRefActions', FilterTable = 'Case03', UpdateRefActions = '', NamingConvention = 'FK_%PARENT_TABLE_NAME%~%REFERENCED_TABLE_NAME%%UPD_REF_ACTION%', Expected = '[FK_Case03~Case03Cascade];[FK_Case03~Case03Cascade2];[FK_Case03~Case03Multi];[FK_Case03~Case03SetDefault];[FK_Case03~Case03SetDefault2];[FK_Case03~Case03SetNull];[FK_Case03~Case03SetNull2];[FK_Case03~Case03Single];[FK_Case03~Case03Single2];[FK_Case03~Case03Single3];[FK_Case03~Case03Single4];[FK_Case03~Case03Single5];[FK_Case03~Case03Single6]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, NamingConvention, Expected) SELECT TestDesc = 'Foreign key renaming - with update ref actions - default', FilterSchema = 'CustomWithUpdRefActions', FilterTable = 'Case04', NamingConvention = 'FK_%PARENT_TABLE_NAME%~%REFERENCED_TABLE_NAME%%UPD_REF_ACTION%', Expected = '[FK_Case04~Case04Cascade];[FK_Case04~Case04Cascade_UpdRefCascade];[FK_Case04~Case04Multi];[FK_Case04~Case04SetDefault];[FK_Case04~Case04SetDefault_UpdRefSetDefault];[FK_Case04~Case04SetNull];[FK_Case04~Case04SetNull_UpdRefSetNull];[FK_Case04~Case04Single];[FK_Case04~Case04Single2];[FK_Case04~Case04Single3];[FK_Case04~Case04Single4];[FK_Case04~Case04Single5];[FK_Case04~Case04Single6]'
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, ForceCaseSensitivity, Expected) SELECT TestDesc = 'Foreign key renaming - case sensitivity differences', FilterSchema = 'CasingRenaming', FilterTable = 'Case01', ForceCaseSensitivity = 0, Expected = '[FK_Case01_Case01Cascade];[FK_Case01_Case01Cascade2];[FK_CASE01_Case01CASING];[FK_Case01_Case01Multi];[FK_Case01_Case01SetDefault];[FK_Case01_Case01SetDefault2];[FK_Case01_Case01SetNull];[FK_Case01_Case01SetNull2];[FK_Case01_Case01Single];[FK_Case01_Case01Single2];[FK_Case01_Case01Single3];[FK_Case01_Case01Single4];[FK_Case01_Case01Single5];[FK_Case01_Case01Single6]' WHERE @DBIsCaseSensitive = 0
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, ForceCaseSensitivity, Expected) SELECT TestDesc = 'Foreign key renaming - case sensitivity differences', FilterSchema = 'CasingRenaming', FilterTable = 'Case01', ForceCaseSensitivity = 0, Expected = '[FK_Case01_Case01Cascade];[FK_Case01_Case01Cascade2];[FK_Case01_Case01Casing];[FK_Case01_Case01Multi];[FK_Case01_Case01SetDefault];[FK_Case01_Case01SetDefault2];[FK_Case01_Case01SetNull];[FK_Case01_Case01SetNull2];[FK_Case01_Case01Single];[FK_Case01_Case01Single2];[FK_Case01_Case01Single3];[FK_Case01_Case01Single4];[FK_Case01_Case01Single5];[FK_Case01_Case01Single6]'  WHERE @DBIsCaseSensitive = 1
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, ForceCaseSensitivity, Expected) SELECT TestDesc = 'Foreign key renaming - force case sensitivity differences', FilterSchema = 'CasingRenaming', FilterTable = 'Case02', ForceCaseSensitivity = 1, Expected = '[FK_Case02_Case02Cascade];[FK_Case02_Case02Cascade2];[FK_Case02_Case02Casing];[FK_Case02_Case02Multi];[FK_Case02_Case02SetDefault];[FK_Case02_Case02SetDefault2];[FK_Case02_Case02SetNull];[FK_Case02_Case02SetNull2];[FK_Case02_Case02Single];[FK_Case02_Case02Single2];[FK_Case02_Case02Single3];[FK_Case02_Case02Single4];[FK_Case02_Case02Single5];[FK_Case02_Case02Single6]'

INSERT #TestCases (TestDesc, FilterSchema, FilterTable, MaxNameLength, OversizedMode, NamingConvention, Expected) SELECT TestDesc = 'Foreign key renaming with max name length and truncate oversize mode', FilterSchema = 'MaxNameLength&Truncate', FilterTable = 'Case01', MaxNameLength = 20, OversizedMode = 'T', NamingConvention = 'FK_%PARENT_TABLE_NAME%~%REFERENCED_TABLE_NAME%:%PARENT_COLUMNS%', Expected = '[FK_Case01~Case01Casc];[FK_Case01~Case01Casc2];[FK_Case01~Case01Mult];[FK_Case01~Case01SetD];[FK_Case01~Case01SetD2];[FK_Case01~Case01SetN];[FK_Case01~Case01SetN2];[FK_Case01~Case01Sing];[FK_Case01~Case01Sing2];[FK_Case01~Case01Sing3];[FK_Case01~Case01Sing4];[FK_Case01~Case01Sing5];[FK_Case01~Case01Sing6]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, MaxNameLength, OversizedMode, NamingConvention, Expected) SELECT TestDesc = 'Foreign key renaming with max name length and skip oversize mode', FilterSchema = 'MaxNameLength&Skip', FilterTable = 'Case01', MaxNameLength = 20, OversizedMode = 'S', NamingConvention = 'FK_%PARENT_TABLE_NAME%~%REFERENCED_TABLE_NAME%:%PARENT_COLUMNS%', Expected = '[FK_Case01_DelRefCascade];[FK_Case01_DelRefNoAction];[FK_Case01_DelRefSetDefault];[FK_Case01_DelRefSetNull];[FK_Case01_Disabled];[FK_Case01_MultiCol];[FK_Case01_NotForRepl];[FK_Case01_SingleCol];[FK_Case01_Untrusted];[FK_Case01_UpdRefCascade];[FK_Case01_UpdRefNoAction];[FK_Case01_UpdRefSetDefault];[FK_Case01_UpdRefSetNull]'

INSERT #TestCases (TestDesc, FilterSchema, FilterTable, MaxParentColumns, NamingConvention, Expected) SELECT TestDesc = 'Foreign key renaming with max parent columns in name', FilterSchema = 'MaxParentColumns', FilterTable = 'Case01', MaxParentColumns = 2, NamingConvention = 'FK_%PARENT_TABLE_NAME%:%PARENT_COLUMNS%~%REFERENCED_TABLE_NAME%:%REFERENCED_COLUMNS%', Expected = '[FK_Case01:ColA~Case01Single:Id];[FK_Case01:ColA~Case01Single:Id2];[FK_Case01:ColA~Case01Single:Id3];[FK_Case01:ColB~Case01Cascade:Id];[FK_Case01:ColB~Case01Single:Id];[FK_Case01:ColC~Case01SetNull:Id];[FK_Case01:ColC~Case01Single:Id];[FK_Case01:ColD~Case01SetDefault:Id];[FK_Case01:ColE_ColF~Case01Multi:ColW_ColX_ColY_ColZ];[FK_Case01:ColE~Case01Single:Id];[FK_Case01:ColF~Case01Cascade:Id];[FK_Case01:ColG~Case01SetNull:Id];[FK_Case01:ColH~Case01SetDefault:Id]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, MaxReferencedColumns, NamingConvention, Expected) SELECT TestDesc = 'Foreign key renaming with max referenced columns in name', FilterSchema = 'MaxReferencedColumns', FilterTable = 'Case01', MaxReferencedColumns = 2, NamingConvention = 'FK_%PARENT_TABLE_NAME%:%PARENT_COLUMNS%~%REFERENCED_TABLE_NAME%:%REFERENCED_COLUMNS%', Expected = '[FK_Case01:ColA~Case01Single:Id];[FK_Case01:ColA~Case01Single:Id2];[FK_Case01:ColA~Case01Single:Id3];[FK_Case01:ColB~Case01Cascade:Id];[FK_Case01:ColB~Case01Single:Id];[FK_Case01:ColC~Case01SetNull:Id];[FK_Case01:ColC~Case01Single:Id];[FK_Case01:ColD~Case01SetDefault:Id];[FK_Case01:ColE_ColF_ColG_ColH~Case01Multi:ColW_ColX];[FK_Case01:ColE~Case01Single:Id];[FK_Case01:ColF~Case01Cascade:Id];[FK_Case01:ColG~Case01SetNull:Id];[FK_Case01:ColH~Case01SetDefault:Id]' 

INSERT #TestCases (TestDesc, FilterSchema, FilterTable, UniquifyNames, NamingConvention, Expected) SELECT TestDesc = 'Foreign key renaming with uniquifying constraint names', FilterSchema = 'UniquifyForeignKeys', FilterTable = 'Case01', UniquifyNames = 1, NamingConvention = 'FK_%PARENT_TABLE_NAME%', Expected = '[FK_Case01];[FK_Case0110];[FK_Case0111];[FK_Case0112];[FK_Case0113];[FK_Case012];[FK_Case013];[FK_Case014];[FK_Case015];[FK_Case016];[FK_Case017];[FK_Case018];[FK_Case019]'

INSERT #TestCases (TestDesc, FilterSchema, FilterTable, UseAliases, NamingConvention, Expected) SELECT TestDesc = 'Foreign key renaming with column aliasing', FilterSchema = 'ColumnAliasRenaming', FilterTable = 'Case01', UseAliases = 'C', NamingConvention = 'FK_%PARENT_TABLE_NAME%:%PARENT_COLUMNS%~%REFERENCED_TABLE_NAME%:%REFERENCED_COLUMNS%', Expected = '[FK_Case01:CAR1~Case01Single:CAR1];[FK_Case01:CAR1~Case01Single:CAR12];[FK_Case01:CAR1~Case01Single:CAR13];[FK_Case01:ColB~Case01Cascade:Id];[FK_Case01:ColB~Case01Single:Id];[FK_Case01:ColC~Case01SetNull:Id];[FK_Case01:ColC~Case01Single:Id];[FK_Case01:ColD~Case01SetDefault:Id];[FK_Case01:ColE_ColF_ColG_ColH~Case01Multi:ColW_ColX_ColY_ColZ];[FK_Case01:ColE~Case01Single:Id];[FK_Case01:ColF~Case01Cascade:Id];[FK_Case01:ColG~Case01SetNull:Id];[FK_Case01:ColH~Case01SetDefault:Id]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, UseAliases, NamingConvention, Expected) SELECT TestDesc = 'Foreign key renaming with column aliasing', FilterSchema = 'ColumnAliasRenaming', FilterTable = 'Case02', UseAliases = 'C', NamingConvention = 'FK_%PARENT_TABLE_NAME%:%PARENT_COLUMNS%~%REFERENCED_TABLE_NAME%:%REFERENCED_COLUMNS%', Expected = '[FK_Case02:CAR2~Case02Single:CAR2];[FK_Case02:CAR2~Case02Single:CAR22];[FK_Case02:CAR2~Case02Single:CAR23];[FK_Case02:ColB~Case02Cascade:Id];[FK_Case02:ColB~Case02Single:Id];[FK_Case02:ColC~Case02SetNull:Id];[FK_Case02:ColC~Case02Single:Id];[FK_Case02:ColD~Case02SetDefault:Id];[FK_Case02:ColE_ColF_ColG_ColH~Case02Multi:ColW_ColX_ColY_ColZ];[FK_Case02:ColE~Case02Single:Id];[FK_Case02:ColF~Case02Cascade:Id];[FK_Case02:ColG~Case02SetNull:Id];[FK_Case02:ColH~Case02SetDefault:Id]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, UseAliases, NamingConvention, Expected) SELECT TestDesc = 'Foreign key renaming with column aliasing', FilterSchema = 'ColumnAliasRenaming', FilterTable = 'Case03', UseAliases = 'C', NamingConvention = 'FK_%PARENT_TABLE_NAME%:%PARENT_COLUMNS%~%REFERENCED_TABLE_NAME%:%REFERENCED_COLUMNS%', Expected = '[FK_Case03:CAR3~Case03Single:CAR3];[FK_Case03:CAR3~Case03Single:CAR32];[FK_Case03:CAR3~Case03Single:CAR33];[FK_Case03:ColB~Case03Cascade:Id];[FK_Case03:ColB~Case03Single:Id];[FK_Case03:ColC~Case03SetNull:Id];[FK_Case03:ColC~Case03Single:Id];[FK_Case03:ColD~Case03SetDefault:Id];[FK_Case03:ColE_ColF_ColG_ColH~Case03Multi:ColW_ColX_ColY_ColZ];[FK_Case03:ColE~Case03Single:Id];[FK_Case03:ColF~Case03Cascade:Id];[FK_Case03:ColG~Case03SetNull:Id];[FK_Case03:ColH~Case03SetDefault:Id]'

INSERT #TestCases (TestDesc, FilterSchema, FilterTable, UseAliases, NamingConvention, Expected) SELECT TestDesc = 'Foreign key renaming with table aliasing', FilterSchema = 'TableAliasRenaming', FilterTable = 'Case01', UseAliases = 'T', NamingConvention = 'FK_%PARENT_TABLE_NAME%:%PARENT_COLUMNS%~%REFERENCED_TABLE_NAME%:%REFERENCED_COLUMNS%', Expected = '[FK_TAR1:ColA~Case01Single:Id];[FK_TAR1:ColA~Case01Single:Id2];[FK_TAR1:ColA~Case01Single:Id3];[FK_TAR1:ColB~Case01Cascade:Id];[FK_TAR1:ColB~Case01Single:Id];[FK_TAR1:ColC~Case01SetNull:Id];[FK_TAR1:ColC~Case01Single:Id];[FK_TAR1:ColD~Case01SetDefault:Id];[FK_TAR1:ColE_ColF_ColG_ColH~Case01Multi:ColW_ColX_ColY_ColZ];[FK_TAR1:ColE~Case01Single:Id];[FK_TAR1:ColF~Case01Cascade:Id];[FK_TAR1:ColG~Case01SetNull:Id];[FK_TAR1:ColH~Case01SetDefault:Id]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, UseAliases, NamingConvention, Expected) SELECT TestDesc = 'Foreign key renaming with table aliasing', FilterSchema = 'TableAliasRenaming', FilterTable = 'Case02', UseAliases = 'T', NamingConvention = 'FK_%PARENT_TABLE_NAME%:%PARENT_COLUMNS%~%REFERENCED_TABLE_NAME%:%REFERENCED_COLUMNS%', Expected = '[FK_TAR2:ColA~Case02Single:Id];[FK_TAR2:ColA~Case02Single:Id2];[FK_TAR2:ColA~Case02Single:Id3];[FK_TAR2:ColB~Case02Cascade:Id];[FK_TAR2:ColB~Case02Single:Id];[FK_TAR2:ColC~Case02SetNull:Id];[FK_TAR2:ColC~Case02Single:Id];[FK_TAR2:ColD~Case02SetDefault:Id];[FK_TAR2:ColE_ColF_ColG_ColH~Case02Multi:ColW_ColX_ColY_ColZ];[FK_TAR2:ColE~Case02Single:Id];[FK_TAR2:ColF~Case02Cascade:Id];[FK_TAR2:ColG~Case02SetNull:Id];[FK_TAR2:ColH~Case02SetDefault:Id]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, UseAliases, NamingConvention, Expected) SELECT TestDesc = 'Foreign key renaming with table aliasing', FilterSchema = 'TableAliasRenaming', FilterTable = 'Case03', UseAliases = 'T', NamingConvention = 'FK_%PARENT_TABLE_NAME%:%PARENT_COLUMNS%~%REFERENCED_TABLE_NAME%:%REFERENCED_COLUMNS%', Expected = '[FK_TAR3:ColA~Case03Single:Id];[FK_TAR3:ColA~Case03Single:Id2];[FK_TAR3:ColA~Case03Single:Id3];[FK_TAR3:ColB~Case03Cascade:Id];[FK_TAR3:ColB~Case03Single:Id];[FK_TAR3:ColC~Case03SetNull:Id];[FK_TAR3:ColC~Case03Single:Id];[FK_TAR3:ColD~Case03SetDefault:Id];[FK_TAR3:ColE_ColF_ColG_ColH~Case03Multi:ColW_ColX_ColY_ColZ];[FK_TAR3:ColE~Case03Single:Id];[FK_TAR3:ColF~Case03Cascade:Id];[FK_TAR3:ColG~Case03SetNull:Id];[FK_TAR3:ColH~Case03SetDefault:Id]'
                                                                                                                                                                                                                                                                                            
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, UseAliases, NamingConvention, Expected) SELECT TestDesc = 'Foreign key renaming with schema aliasing', FilterSchema = 'SchemaAliasRenaming01', FilterTable = 'Case01', UseAliases = 'S', NamingConvention = 'FK_%PARENT_SCHEMA_NAME%:%PARENT_COLUMNS%~%REFERENCED_SCHEMA_NAME%:%REFERENCED_COLUMNS%', Expected = '[FK_SchemaAliasRenaming01:ColA~SchemaAliasRenaming01:Id];[FK_SchemaAliasRenaming01:ColA~SchemaAliasRenaming01:Id2];[FK_SchemaAliasRenaming01:ColA~SchemaAliasRenaming01:Id3];[FK_SchemaAliasRenaming01:ColB~SchemaAliasRenaming01:Id];[FK_SchemaAliasRenaming01:ColB~SchemaAliasRenaming01:Id2];[FK_SchemaAliasRenaming01:ColC~SchemaAliasRenaming01:Id];[FK_SchemaAliasRenaming01:ColC~SchemaAliasRenaming01:Id2];[FK_SchemaAliasRenaming01:ColD~SchemaAliasRenaming01:Id];[FK_SchemaAliasRenaming01:ColE_ColF_ColG_ColH~SchemaAliasRenaming01:ColW_ColX_ColY_ColZ];[FK_SchemaAliasRenaming01:ColE~SchemaAliasRenaming01:Id];[FK_SchemaAliasRenaming01:ColF~SchemaAliasRenaming01:Id];[FK_SchemaAliasRenaming01:ColG~SchemaAliasRenaming01:Id];[FK_SchemaAliasRenaming01:ColH~SchemaAliasRenaming01:Id]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, UseAliases, NamingConvention, Expected) SELECT TestDesc = 'Foreign key renaming with schema aliasing', FilterSchema = 'SchemaAliasRenaming02', FilterTable = 'Case02', UseAliases = 'S', NamingConvention = 'FK_%PARENT_SCHEMA_NAME%:%PARENT_COLUMNS%~%REFERENCED_SCHEMA_NAME%:%REFERENCED_COLUMNS%', Expected = '[FK_SAR02:ColA~SAR02:Id];[FK_SAR02:ColA~SAR02:Id2];[FK_SAR02:ColA~SAR02:Id3];[FK_SAR02:ColB~SAR02:Id];[FK_SAR02:ColB~SAR02:Id2];[FK_SAR02:ColC~SAR02:Id];[FK_SAR02:ColC~SAR02:Id2];[FK_SAR02:ColD~SAR02:Id];[FK_SAR02:ColE_ColF_ColG_ColH~SAR02:ColW_ColX_ColY_ColZ];[FK_SAR02:ColE~SAR02:Id];[FK_SAR02:ColF~SAR02:Id];[FK_SAR02:ColG~SAR02:Id];[FK_SAR02:ColH~SAR02:Id]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, UseAliases, NamingConvention, Expected) SELECT TestDesc = 'Foreign key renaming with schema aliasing', FilterSchema = 'SchemaAliasRenaming03', FilterTable = 'Case03', UseAliases = 'S', NamingConvention = 'FK_%PARENT_SCHEMA_NAME%:%PARENT_COLUMNS%~%REFERENCED_SCHEMA_NAME%:%REFERENCED_COLUMNS%', Expected = '[FK_SAR03:ColA~SAR03:Id];[FK_SAR03:ColA~SAR03:Id2];[FK_SAR03:ColA~SAR03:Id3];[FK_SAR03:ColB~SAR03:Id];[FK_SAR03:ColB~SAR03:Id2];[FK_SAR03:ColC~SAR03:Id];[FK_SAR03:ColC~SAR03:Id2];[FK_SAR03:ColD~SAR03:Id];[FK_SAR03:ColE_ColF_ColG_ColH~SAR03:ColW_ColX_ColY_ColZ];[FK_SAR03:ColE~SAR03:Id];[FK_SAR03:ColF~SAR03:Id];[FK_SAR03:ColG~SAR03:Id];[FK_SAR03:ColH~SAR03:Id]'

INSERT #TestCases (TestDesc, FilterSchema, FilterTable, UseAliases, NamingConvention, Expected) SELECT TestDesc = 'Foreign key renaming with aliasing, wrong database rules, no alias match', FilterSchema = 'AliasRenaming01', FilterTable = 'Case01', UseAliases = 'STC', NamingConvention = 'FK_%PARENT_SCHEMA_NAME%_%PARENT_TABLE_NAME%:%PARENT_COLUMNS%~%REFERENCED_SCHEMA_NAME%_%REFERENCED_TABLE_NAME%:%REFERENCED_COLUMNS%', Expected = '[FK_AliasRenaming01_Case01:ColA~AliasRenaming01_Case01Single:Id];[FK_AliasRenaming01_Case01:ColA~AliasRenaming01_Case01Single:Id2];[FK_AliasRenaming01_Case01:ColA~AliasRenaming01_Case01Single:Id3];[FK_AliasRenaming01_Case01:ColB~AliasRenaming01_Case01Cascade:Id];[FK_AliasRenaming01_Case01:ColB~AliasRenaming01_Case01Single:Id];[FK_AliasRenaming01_Case01:ColC~AliasRenaming01_Case01SetNull:Id];[FK_AliasRenaming01_Case01:ColC~AliasRenaming01_Case01Single:Id];[FK_AliasRenaming01_Case01:ColD~AliasRenaming01_Case01SetDefault:Id];[FK_AliasRenaming01_Case01:ColE_ColF_ColG_ColH~AliasRenaming01_Case01Multi:ColW_ColX_ColY_ColZ];[FK_AliasRenaming01_Case01:ColE~AliasRenaming01_Case01Single:Id];[FK_AliasRenaming01_Case01:ColF~AliasRenaming01_Case01Cascade:Id];[FK_AliasRenaming01_Case01:ColG~AliasRenaming01_Case01SetNull:Id];[FK_AliasRenaming01_Case01:ColH~AliasRenaming01_Case01SetDefault:Id]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, UseAliases, NamingConvention, Expected) SELECT TestDesc = 'Foreign key renaming with aliasing, wrong database rules, no alias match', FilterSchema = 'AliasRenaming01', FilterTable = 'Case02', UseAliases = 'STC', NamingConvention = 'FK_%PARENT_SCHEMA_NAME%_%PARENT_TABLE_NAME%:%PARENT_COLUMNS%~%REFERENCED_SCHEMA_NAME%_%REFERENCED_TABLE_NAME%:%REFERENCED_COLUMNS%', Expected = '[FK_AliasRenaming01_Case02:ColA~AliasRenaming01_Case02Single:Id];[FK_AliasRenaming01_Case02:ColA~AliasRenaming01_Case02Single:Id2];[FK_AliasRenaming01_Case02:ColA~AliasRenaming01_Case02Single:Id3];[FK_AliasRenaming01_Case02:ColB~AliasRenaming01_Case02Cascade:Id];[FK_AliasRenaming01_Case02:ColB~AliasRenaming01_Case02Single:Id];[FK_AliasRenaming01_Case02:ColC~AliasRenaming01_Case02SetNull:Id];[FK_AliasRenaming01_Case02:ColC~AliasRenaming01_Case02Single:Id];[FK_AliasRenaming01_Case02:ColD~AliasRenaming01_Case02SetDefault:Id];[FK_AliasRenaming01_Case02:ColE_ColF_ColG_ColH~AliasRenaming01_Case02Multi:ColW_ColX_ColY_ColZ];[FK_AliasRenaming01_Case02:ColE~AliasRenaming01_Case02Single:Id];[FK_AliasRenaming01_Case02:ColF~AliasRenaming01_Case02Cascade:Id];[FK_AliasRenaming01_Case02:ColG~AliasRenaming01_Case02SetNull:Id];[FK_AliasRenaming01_Case02:ColH~AliasRenaming01_Case02SetDefault:Id]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, UseAliases, NamingConvention, Expected) SELECT TestDesc = 'Foreign key renaming with aliasing, wrong database rules, no alias match', FilterSchema = 'AliasRenaming01', FilterTable = 'Case03', UseAliases = 'STC', NamingConvention = 'FK_%PARENT_SCHEMA_NAME%_%PARENT_TABLE_NAME%:%PARENT_COLUMNS%~%REFERENCED_SCHEMA_NAME%_%REFERENCED_TABLE_NAME%:%REFERENCED_COLUMNS%', Expected = '[FK_AliasRenaming01_Case03:ColA~AliasRenaming01_Case03Single:Id];[FK_AliasRenaming01_Case03:ColA~AliasRenaming01_Case03Single:Id2];[FK_AliasRenaming01_Case03:ColA~AliasRenaming01_Case03Single:Id3];[FK_AliasRenaming01_Case03:ColB~AliasRenaming01_Case03Cascade:Id];[FK_AliasRenaming01_Case03:ColB~AliasRenaming01_Case03Single:Id];[FK_AliasRenaming01_Case03:ColC~AliasRenaming01_Case03SetNull:Id];[FK_AliasRenaming01_Case03:ColC~AliasRenaming01_Case03Single:Id];[FK_AliasRenaming01_Case03:ColD~AliasRenaming01_Case03SetDefault:Id];[FK_AliasRenaming01_Case03:ColE_ColF_ColG_ColH~AliasRenaming01_Case03Multi:ColW_ColX_ColY_ColZ];[FK_AliasRenaming01_Case03:ColE~AliasRenaming01_Case03Single:Id];[FK_AliasRenaming01_Case03:ColF~AliasRenaming01_Case03Cascade:Id];[FK_AliasRenaming01_Case03:ColG~AliasRenaming01_Case03SetNull:Id];[FK_AliasRenaming01_Case03:ColH~AliasRenaming01_Case03SetDefault:Id]'

INSERT #TestCases (TestDesc, FilterSchema, FilterTable, UseAliases, NamingConvention, Expected) SELECT TestDesc = 'Foreign key renaming with aliasing, specific database rules, match schema, table, column #1', FilterSchema = 'AliasRenaming02', FilterTable = 'Case01', UseAliases = 'STC', NamingConvention = 'FK_%PARENT_SCHEMA_NAME%_%PARENT_TABLE_NAME%:%PARENT_COLUMNS%~%REFERENCED_SCHEMA_NAME%_%REFERENCED_TABLE_NAME%:%REFERENCED_COLUMNS%', Expected = '[FK_AR04_AR05:AR06~AR04_Case01Single:AR06];[FK_AR04_AR05:AR06~AR04_Case01Single:AR062];[FK_AR04_AR05:AR06~AR04_Case01Single:AR063];[FK_AR04_AR05:ColB~AR04_Case01Cascade:Id];[FK_AR04_AR05:ColB~AR04_Case01Single:Id];[FK_AR04_AR05:ColC~AR04_Case01SetNull:Id];[FK_AR04_AR05:ColC~AR04_Case01Single:Id];[FK_AR04_AR05:ColD~AR04_Case01SetDefault:Id];[FK_AR04_AR05:ColE_ColF_ColG_ColH~AR04_Case01Multi:ColW_ColX_ColY_ColZ];[FK_AR04_AR05:ColE~AR04_Case01Single:Id];[FK_AR04_AR05:ColF~AR04_Case01Cascade:Id];[FK_AR04_AR05:ColG~AR04_Case01SetNull:Id];[FK_AR04_AR05:ColH~AR04_Case01SetDefault:Id]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, UseAliases, NamingConvention, Expected) SELECT TestDesc = 'Foreign key renaming with aliasing, specific database rules, match schema, table, column #2', FilterSchema = 'AliasRenaming02', FilterTable = 'Case02', UseAliases = 'STC', NamingConvention = 'FK_%PARENT_SCHEMA_NAME%_%PARENT_TABLE_NAME%:%PARENT_COLUMNS%~%REFERENCED_SCHEMA_NAME%_%REFERENCED_TABLE_NAME%:%REFERENCED_COLUMNS%', Expected = '[FK_AR04_AR07:AR08~AR04_Case02Single:AR08];[FK_AR04_AR07:AR08~AR04_Case02Single:AR082];[FK_AR04_AR07:AR08~AR04_Case02Single:AR083];[FK_AR04_AR07:ColB~AR04_Case02Cascade:Id];[FK_AR04_AR07:ColB~AR04_Case02Single:Id];[FK_AR04_AR07:ColC~AR04_Case02SetNull:Id];[FK_AR04_AR07:ColC~AR04_Case02Single:Id];[FK_AR04_AR07:ColD~AR04_Case02SetDefault:Id];[FK_AR04_AR07:ColE_ColF_ColG_ColH~AR04_Case02Multi:ColW_ColX_ColY_ColZ];[FK_AR04_AR07:ColE~AR04_Case02Single:Id];[FK_AR04_AR07:ColF~AR04_Case02Cascade:Id];[FK_AR04_AR07:ColG~AR04_Case02SetNull:Id];[FK_AR04_AR07:ColH~AR04_Case02SetDefault:Id]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, UseAliases, NamingConvention, Expected) SELECT TestDesc = 'Foreign key renaming with aliasing, specific database rules, match schema', FilterSchema = 'AliasRenaming02', FilterTable = 'Case03', UseAliases = 'STC', NamingConvention = 'FK_%PARENT_SCHEMA_NAME%_%PARENT_TABLE_NAME%:%PARENT_COLUMNS%~%REFERENCED_SCHEMA_NAME%_%REFERENCED_TABLE_NAME%:%REFERENCED_COLUMNS%', Expected = '[FK_AR04_Case03:ColA~AR04_Case03Single:Id];[FK_AR04_Case03:ColA~AR04_Case03Single:Id2];[FK_AR04_Case03:ColA~AR04_Case03Single:Id3];[FK_AR04_Case03:ColB~AR04_Case03Cascade:Id];[FK_AR04_Case03:ColB~AR04_Case03Single:Id];[FK_AR04_Case03:ColC~AR04_Case03SetNull:Id];[FK_AR04_Case03:ColC~AR04_Case03Single:Id];[FK_AR04_Case03:ColD~AR04_Case03SetDefault:Id];[FK_AR04_Case03:ColE_ColF_ColG_ColH~AR04_Case03Multi:ColW_ColX_ColY_ColZ];[FK_AR04_Case03:ColE~AR04_Case03Single:Id];[FK_AR04_Case03:ColF~AR04_Case03Cascade:Id];[FK_AR04_Case03:ColG~AR04_Case03SetNull:Id];[FK_AR04_Case03:ColH~AR04_Case03SetDefault:Id]'

INSERT #TestCases (TestDesc, FilterSchema, FilterTable, UseAliases, NamingConvention, Expected) SELECT TestDesc = 'Foreign key renaming with aliasing, generic database rules, match schema, table, column #1', FilterSchema = 'AliasRenaming03', FilterTable = 'Case01', UseAliases = 'STC', NamingConvention = 'FK_%PARENT_SCHEMA_NAME%_%PARENT_TABLE_NAME%:%PARENT_COLUMNS%~%REFERENCED_SCHEMA_NAME%_%REFERENCED_TABLE_NAME%:%REFERENCED_COLUMNS%', Expected = '[FK_AR09_AR10:AR11~AR09_Case01Single:AR11];[FK_AR09_AR10:AR11~AR09_Case01Single:AR112];[FK_AR09_AR10:AR11~AR09_Case01Single:AR113];[FK_AR09_AR10:ColB~AR09_Case01Cascade:Id];[FK_AR09_AR10:ColB~AR09_Case01Single:Id];[FK_AR09_AR10:ColC~AR09_Case01SetNull:Id];[FK_AR09_AR10:ColC~AR09_Case01Single:Id];[FK_AR09_AR10:ColD~AR09_Case01SetDefault:Id];[FK_AR09_AR10:ColE_ColF_ColG_ColH~AR09_Case01Multi:ColW_ColX_ColY_ColZ];[FK_AR09_AR10:ColE~AR09_Case01Single:Id];[FK_AR09_AR10:ColF~AR09_Case01Cascade:Id];[FK_AR09_AR10:ColG~AR09_Case01SetNull:Id];[FK_AR09_AR10:ColH~AR09_Case01SetDefault:Id]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, UseAliases, NamingConvention, Expected) SELECT TestDesc = 'Foreign key renaming with aliasing, generic database rules, match schema, table, column #2', FilterSchema = 'AliasRenaming03', FilterTable = 'Case02', UseAliases = 'STC', NamingConvention = 'FK_%PARENT_SCHEMA_NAME%_%PARENT_TABLE_NAME%:%PARENT_COLUMNS%~%REFERENCED_SCHEMA_NAME%_%REFERENCED_TABLE_NAME%:%REFERENCED_COLUMNS%', Expected = '[FK_AR09_AR12:AR13~AR09_Case02Single:AR13];[FK_AR09_AR12:AR13~AR09_Case02Single:AR132];[FK_AR09_AR12:AR13~AR09_Case02Single:AR133];[FK_AR09_AR12:ColB~AR09_Case02Cascade:Id];[FK_AR09_AR12:ColB~AR09_Case02Single:Id];[FK_AR09_AR12:ColC~AR09_Case02SetNull:Id];[FK_AR09_AR12:ColC~AR09_Case02Single:Id];[FK_AR09_AR12:ColD~AR09_Case02SetDefault:Id];[FK_AR09_AR12:ColE_ColF_ColG_ColH~AR09_Case02Multi:ColW_ColX_ColY_ColZ];[FK_AR09_AR12:ColE~AR09_Case02Single:Id];[FK_AR09_AR12:ColF~AR09_Case02Cascade:Id];[FK_AR09_AR12:ColG~AR09_Case02SetNull:Id];[FK_AR09_AR12:ColH~AR09_Case02SetDefault:Id]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, UseAliases, NamingConvention, Expected) SELECT TestDesc = 'Foreign key renaming with aliasing, generic database rules, match schema', FilterSchema = 'AliasRenaming03', FilterTable = 'Case03', UseAliases = 'STC', NamingConvention = 'FK_%PARENT_SCHEMA_NAME%_%PARENT_TABLE_NAME%:%PARENT_COLUMNS%~%REFERENCED_SCHEMA_NAME%_%REFERENCED_TABLE_NAME%:%REFERENCED_COLUMNS%', Expected = '[FK_AR09_Case03:ColA~AR09_Case03Single:Id];[FK_AR09_Case03:ColA~AR09_Case03Single:Id2];[FK_AR09_Case03:ColA~AR09_Case03Single:Id3];[FK_AR09_Case03:ColB~AR09_Case03Cascade:Id];[FK_AR09_Case03:ColB~AR09_Case03Single:Id];[FK_AR09_Case03:ColC~AR09_Case03SetNull:Id];[FK_AR09_Case03:ColC~AR09_Case03Single:Id];[FK_AR09_Case03:ColD~AR09_Case03SetDefault:Id];[FK_AR09_Case03:ColE_ColF_ColG_ColH~AR09_Case03Multi:ColW_ColX_ColY_ColZ];[FK_AR09_Case03:ColE~AR09_Case03Single:Id];[FK_AR09_Case03:ColF~AR09_Case03Cascade:Id];[FK_AR09_Case03:ColG~AR09_Case03SetNull:Id];[FK_AR09_Case03:ColH~AR09_Case03SetDefault:Id]'


-- #######################################################################################
-- ###### Execute the test schema initialization command
-- #######################################################################################
SET @I = 1
WHILE (1 = 1)
BEGIN
  SELECT @SchemaName = SchemaName FROM #TestSchemas WHERE No = @I
  IF @@ROWCOUNT = 0 BREAK

  RAISERROR ('TEST CASE INITIALIZATION #%0.2d. CREATING SCHEMA %s', 10, 1, @I, @SchemaName) WITH NOWAIT
  SET @ExecuteCommand = REPLACE('IF SCHEMA_ID(''%SCHEMANAME%'') IS NULL EXECUTE (''CREATE SCHEMA [%SCHEMANAME%] AUTHORIZATION dbo'')', '%SCHEMANAME%', @SchemaName)
  EXECUTE (@ExecuteCommand)

  SET @I = @I + 1
END
PRINT ''
PRINT ''

-- #######################################################################################
-- ###### Execute the test table pre cleanup command
-- #######################################################################################
SELECT 
  Number = ROW_NUMBER() OVER (ORDER BY s.name, t.name),
  ObjectName = QUOTENAME(s.name) + '.' + QUOTENAME(t.name)
  INTO #TestTablesPreCleanup 
FROM 
  #TestSchemas ts 
    JOIN sys.schemas s ON 
      ts.SchemaName = s.name  
    JOIN sys.tables t ON 
      s.schema_id = t.schema_id
WHERE
  ts.SchemaName != 'dbo' 


SET @I = 1
WHILE (1 = 1)
BEGIN
  SELECT @ObjectName = ObjectName FROM #TestTablesPreCleanup WHERE Number = @I  
  IF @@ROWCOUNT = 0 BREAK

  RAISERROR ('TEST CASE CLEANUP #%0.2d. DROPPING TABLE %s', 10, 1, @I, @ObjectName) WITH NOWAIT
  SET @ExecuteCommand = 'DROP TABLE %OBJECT_NAME%'
  
  SET @ExecuteCommand = REPLACE('DROP TABLE %OBJECT_NAME%', '%OBJECT_NAME%', @ObjectName)
  EXECUTE (@ExecuteCommand)
  
  SET @I = @I + 1
END
PRINT ''
PRINT ''


-- #######################################################################################
-- ###### Execute the test table initialization command
-- ####################################################################################### 
SET @ExecuteCommandTemplate = 
N'
CREATE TABLE %OBJECTNAME% 
(
  Id INT NOT NULL CONSTRAINT [PK_%TABLE_NAME%] PRIMARY KEY CLUSTERED (Id),
  ColA INT NULL,
  ColB INT NULL,
  ColC INT NULL,
  ColD INT NULL, 
  ColE INT NULL,
  ColF INT NULL,
  ColG INT NULL,
  ColH INT NULL 
);

CREATE TABLE [%SCHEMA_NAME%].[%TABLE_NAME%Multi] 
(
  ColW INT NOT NULL,
  ColX INT NOT NULL,
  ColY INT NOT NULL,
  ColZ INT NOT NULL, 
  CONSTRAINT [PK_%TABLE_NAME%Multi] PRIMARY KEY CLUSTERED (ColW, ColX, ColY, ColZ),
);

CREATE TABLE [%SCHEMA_NAME%].[%TABLE_NAME%Single] (Id INT NOT NULL CONSTRAINT [PK_%TABLE_NAME%Single] PRIMARY KEY CLUSTERED);
CREATE TABLE [%SCHEMA_NAME%].[%TABLE_NAME%Cascade] (Id INT NOT NULL CONSTRAINT [PK_%TABLE_NAME%Cascade] PRIMARY KEY CLUSTERED);
CREATE TABLE [%SCHEMA_NAME%].[%TABLE_NAME%SetNull] (Id INT NOT NULL CONSTRAINT [PK_%TABLE_NAME%SetNull] PRIMARY KEY CLUSTERED);
CREATE TABLE [%SCHEMA_NAME%].[%TABLE_NAME%SetDefault] (Id INT NOT NULL  CONSTRAINT [PK_%TABLE_NAME%SetDefault] PRIMARY KEY CLUSTERED);


ALTER TABLE %OBJECTNAME% ADD CONSTRAINT [%FOREIGNKEY_NAME%_SingleCol] FOREIGN KEY (ColA) REFERENCES [%SCHEMA_NAME%].[%TABLE_NAME%Single] (Id);
ALTER TABLE %OBJECTNAME% ADD CONSTRAINT [%FOREIGNKEY_NAME%_MultiCol] FOREIGN KEY (ColE, ColF, ColG, ColH) REFERENCES [%SCHEMA_NAME%].[%TABLE_NAME%Multi] (ColW,ColX,ColY,ColZ);
ALTER TABLE %OBJECTNAME% ADD CONSTRAINT [%FOREIGNKEY_NAME%_Disabled] FOREIGN KEY (ColA) REFERENCES [%SCHEMA_NAME%].[%TABLE_NAME%Single] (Id);
ALTER TABLE %OBJECTNAME% NOCHECK CONSTRAINT [%FOREIGNKEY_NAME%_Disabled];
ALTER TABLE %OBJECTNAME% ADD CONSTRAINT [%FOREIGNKEY_NAME%_NotForRepl] FOREIGN KEY (ColB) REFERENCES [%SCHEMA_NAME%].[%TABLE_NAME%Single] (Id) NOT FOR REPLICATION;
ALTER TABLE %OBJECTNAME% WITH NOCHECK ADD CONSTRAINT [%FOREIGNKEY_NAME%_Untrusted] FOREIGN KEY (ColC) REFERENCES [%SCHEMA_NAME%].[%TABLE_NAME%Single] (Id);
ALTER TABLE %OBJECTNAME% ADD CONSTRAINT [%FOREIGNKEY_NAME%_DelRefNoAction] FOREIGN KEY (ColA) REFERENCES [%SCHEMA_NAME%].[%TABLE_NAME%Single] ON DELETE NO ACTION;
ALTER TABLE %OBJECTNAME% ADD CONSTRAINT [%FOREIGNKEY_NAME%_DelRefCascade] FOREIGN KEY (ColB) REFERENCES [%SCHEMA_NAME%].[%TABLE_NAME%Cascade] ON DELETE CASCADE;
ALTER TABLE %OBJECTNAME% ADD CONSTRAINT [%FOREIGNKEY_NAME%_DelRefSetNull] FOREIGN KEY (ColC) REFERENCES [%SCHEMA_NAME%].[%TABLE_NAME%SetNull] ON DELETE SET NULL;
ALTER TABLE %OBJECTNAME% ADD CONSTRAINT [%FOREIGNKEY_NAME%_DelRefSetDefault] FOREIGN KEY (ColD) REFERENCES [%SCHEMA_NAME%].[%TABLE_NAME%SetDefault] ON DELETE SET DEFAULT;
ALTER TABLE %OBJECTNAME% ADD CONSTRAINT [%FOREIGNKEY_NAME%_UpdRefNoAction] FOREIGN KEY (ColE) REFERENCES [%SCHEMA_NAME%].[%TABLE_NAME%Single] ON UPDATE NO ACTION;
ALTER TABLE %OBJECTNAME% ADD CONSTRAINT [%FOREIGNKEY_NAME%_UpdRefCascade] FOREIGN KEY (ColF) REFERENCES [%SCHEMA_NAME%].[%TABLE_NAME%Cascade] (Id) ON UPDATE CASCADE;
ALTER TABLE %OBJECTNAME% ADD CONSTRAINT [%FOREIGNKEY_NAME%_UpdRefSetNull] FOREIGN KEY (ColG) REFERENCES [%SCHEMA_NAME%].[%TABLE_NAME%SetNull] (Id) ON UPDATE SET NULL;
ALTER TABLE %OBJECTNAME% ADD CONSTRAINT [%FOREIGNKEY_NAME%_UpdRefSetDefault] FOREIGN KEY (ColH) REFERENCES [%SCHEMA_NAME%].[%TABLE_NAME%SetDefault] (Id) ON UPDATE SET DEFAULT;
IF ''%SCHEMA_NAME%'' = ''CasingRenaming''
BEGIN
  CREATE TABLE [%SCHEMA_NAME%].[%TABLE_NAME%Casing] (Id INT NOT NULL  CONSTRAINT [PK_%TABLE_NAME%Casing] PRIMARY KEY CLUSTERED);
  ALTER TABLE [%SCHEMA_NAME%].[%TABLE_NAME%] ADD CONSTRAINT [FK_%UTABLE_NAME%_%TABLE_NAME%CASING] FOREIGN KEY (ColH) REFERENCES [%SCHEMA_NAME%].[%TABLE_NAME%Casing] (Id) 
END 
'
  
SET @I = 1
WHILE (1 = 1)
BEGIN
  SELECT @ObjectName = ObjectName, @SchemaName = SchemaName, @TableName = TableName, @ForeignKeyName = ForeignKeyName FROM #TestTables WHERE TestNo = @I
  IF @@ROWCOUNT = 0 BREAK

  RAISERROR ('TEST CASE INITIALIZATION #%0.2d. CREATING TABLE %s', 10, 1, @I, @ObjectName) WITH NOWAIT
  SET @ExecuteCommand =  
  REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(
    @ExecuteCommandTemplate, '%OBJECTNAME%', @ObjectName ), 
    '%TABLE_NAME%', REPLACE(@TableName, ']', ']]')),
    '%FOREIGNKEY_NAME%', REPLACE(@ForeignKeyName, ']', ']]')),
    '%UTABLE_NAME%', UPPER(REPLACE(@TableName, ']', ']]'))),
    '%SCHEMA_NAME%', @SchemaName) 
  --PRINT (@ExecuteCommand)
  EXECUTE (@ExecuteCommand)
  SET @I = @I + 1
END
PRINT ''
PRINT ''

-- #######################################################################################
-- ###### Execute the Test runner command
-- #######################################################################################
SET @ExecuteCommand = N'
SET @Statement = ''EXECUTE dbautils.spFixForeignKeyNaming @PerformUpdate = 2''
DECLARE @FilterExpression NVARCHAR(MAX) 
SET @FilterExpression = @FilterSchema + ''.'' + @FilterTable

IF (@FilterExpression IS NOT NULL) SET @Statement = @Statement + '', @FilterExpression = '''''' + REPLACE(@FilterExpression, '''''''', '''''''''''') + ''''''''    
IF (@NamingConvention IS NOT NULL) SET @Statement = @Statement + '', @NamingConvention = '''''' + REPLACE(@NamingConvention, '''''''', '''''''''''') + ''''''''  
IF (@EnabledStates IS NOT NULL) SET @Statement = @Statement + '', @EnabledStates = '''''' + REPLACE(@EnabledStates, '''''''', '''''''''''') + ''''''''  
IF (@ReplicationStates IS NOT NULL) SET @Statement = @Statement + '', @ReplicationStates = '''''' + REPLACE(@ReplicationStates, '''''''', '''''''''''') + ''''''''  
IF (@TrustedStates IS NOT NULL) SET @Statement = @Statement + '', @TrustedStates = '''''' + REPLACE(@TrustedStates, '''''''', '''''''''''') + ''''''''  
IF (@DeleteRefActions IS NOT NULL) SET @Statement = @Statement + '', @DeleteRefActions = '''''' + REPLACE(@DeleteRefActions, '''''''', '''''''''''') + ''''''''  
IF (@UpdateRefActions IS NOT NULL) SET @Statement = @Statement + '', @UpdateRefActions = '''''' + REPLACE(@UpdateRefActions, '''''''', '''''''''''') + ''''''''  
IF (@ColumnsSeparator IS NOT NULL) SET @Statement = @Statement + '', @ColumnsSeparator = '''''' + REPLACE(@ColumnsSeparator, '''''''', '''''''''''') + ''''''''
IF (@UseAliases IS NOT NULL) SET @Statement = @Statement + '', @UseAliases = '''''' +  @UseAliases + ''''''''  
IF (@ForceCaseSensitivity IS NOT NULL) SET @Statement = @Statement + '', @ForceCaseSensitivity = '' + CAST(@ForceCaseSensitivity AS NCHAR(1))   
IF (@OversizedMode IS NOT NULL) SET @Statement = @Statement + '', @OversizedMode = '''''' + @OversizedMode + ''''''''  
IF (@MaxNameLength IS NOT NULL) SET @Statement = @Statement + '', @MaxNameLength = '' + CAST(@MaxNameLength AS NVARCHAR(3)) 
IF (@MaxParentColumns IS NOT NULL) SET @Statement = @Statement + '', @MaxParentColumns = '' + CAST(@MaxParentColumns AS NVARCHAR(3)) 
IF (@MaxReferencedColumns IS NOT NULL) SET @Statement = @Statement + '', @MaxReferencedColumns = '' + CAST(@MaxReferencedColumns AS NVARCHAR(3)) 
IF (@UniquifyNames IS NOT NULL) SET @Statement = @Statement + '', @UniquifyNames = '' + CAST(@UniquifyNames AS NCHAR(1)) 
'
SET  @ExecuteCommand = @ExecuteCommand + 
'
EXECUTE (@Statement)
SET @Actual = ''''
SELECT 
  @Actual = @Actual + QUOTENAME(fk.name) + '';''
FROM  
  sys.foreign_keys fk 
    JOIN dbautils.fnGetFilteredTables(@FilterExpression) ft ON
      fk.parent_object_id = ft.ObjectId

ORDER BY
  ROW_NUMBER() OVER(ORDER BY ft.SchemaName, ft.TableName, fk.name)
IF Len(@Actual) > 0 SET @Actual = LEFT(@Actual, LEN(@Actual) - 1);
'

SET @Message = '### %s ###\t\tTEST CASE #%0.2d. - %s\n\tSTATEMENT: %s\n\tEXPECTED RESULT: %s\n\tACTUAL RESULT:   %s\n'
SET @I = 1
WHILE (1 = 1)
BEGIN
  SELECT @TestDesc = TestDesc, @FilterSchema = FilterSchema, @FilterTable = FilterTable, @NamingConvention = NamingConvention, @EnabledStates = EnabledStates, @ReplicationStates = ReplicationStates, @TrustedStates = TrustedStates, @DeleteRefActions = DeleteRefActions, @UpdateRefActions = UpdateRefActions, @ColumnsSeparator = ColumnsSeparator, @UseAliases = UseAliases, @ForceCaseSensitivity = ForceCaseSensitivity, @OversizedMode = OversizedMode, @MaxNameLength = MaxNameLength, @MaxParentColumns = MaxParentColumns, @MaxReferencedColumns = MaxReferencedColumns, @UniquifyNames = UniquifyNames, @Expected = Expected FROM #TestCases WHERE TestNo = @I
  IF @@ROWCOUNT = 0 BREAK

  EXECUTE sp_executesql 
    @ExecuteCommand, 
    N'@FilterSchema NVARCHAR(MAX), @FilterTable NVARCHAR(MAX), @NamingConvention NVARCHAR(MAX), @EnabledStates NVARCHAR(MAX), @ReplicationStates NVARCHAR(MAX), @TrustedStates NVARCHAR(MAX), @DeleteRefActions NVARCHAR(MAX), @UpdateRefActions NVARCHAR(MAX), @ColumnsSeparator NVARCHAR(50), @UseAliases CHAR(3), @ForceCaseSensitivity BIT, @OversizedMode NCHAR(1), @MaxNameLength TINYINT, @MaxParentColumns TINYINT, @MaxReferencedColumns TINYINT, @UniquifyNames BIT, @Actual NVARCHAR(MAX) OUTPUT, @Statement NVARCHAR(MAX) OUTPUT',
    @FilterSchema, @FilterTable, @NamingConvention, @EnabledStates, @ReplicationStates, @TrustedStates, @DeleteRefActions, @UpdateRefActions, @ColumnsSeparator, @UseAliases, @ForceCaseSensitivity, @OversizedMode, @MaxNameLength, @MaxParentColumns, @MaxReferencedColumns, @UniquifyNames, @Actual OUTPUT, @Statement OUTPUT

  SET @Message = REPLACE(REPLACE(@Message, '\n', CHAR(13)), '\t', CHAR(9)) 
  IF @Expected + '#'  COLLATE Latin1_General_BIN = @Actual + '#'  COLLATE Latin1_General_BIN-- Dirty hack, because comparing ' ' and '  ' is equal in sql server
    RAISERROR (@Message, 10, 1, 'SUCCESS!!!', @I, @TestDesc, @Statement, @Expected, @Actual) WITH NOWAIT
  ELSE                            
    RAISERROR (@Message, 16, 1, 'FAILURE!!!', @I, @TestDesc, @Statement, @Expected, @Actual) WITH NOWAIT

  SET @I = @I + 1
END
PRINT ''
PRINT ''

-- #######################################################################################
-- ###### Execute the test table post cleanup command
-- #######################################################################################
SELECT 
  Number = ROW_NUMBER() OVER (ORDER BY s.name, t.name),
  ObjectName = QUOTENAME(s.name) + '.' + QUOTENAME(t.name)
  INTO #TestTablesPostCleanup 
FROM 
  #TestSchemas ts 
    JOIN sys.schemas s ON 
      ts.SchemaName = s.name  
    JOIN sys.tables t ON 
      s.schema_id = t.schema_id
WHERE
  ts.SchemaName != 'dbo' 


SET @I = 1
WHILE (1 = 1)
BEGIN
  SELECT @ObjectName = ObjectName FROM #TestTablesPostCleanup WHERE Number = @I  
  IF @@ROWCOUNT = 0 BREAK

  RAISERROR ('TEST CASE CLEANUP #%0.2d. DROPPING TABLE %s', 10, 1, @I, @ObjectName) WITH NOWAIT
  SET @ExecuteCommand = REPLACE('DROP TABLE %OBJECT_NAME%', '%OBJECT_NAME%', @ObjectName)
  EXECUTE (@ExecuteCommand)
  
  SET @I = @I + 1
END
PRINT ''
PRINT ''


-- #######################################################################################
-- ###### Execute the test schema cleanup command
-- #######################################################################################
SET @I = 1
WHILE (1 = 1)
BEGIN
  SELECT @SchemaName = SchemaName FROM #TestSchemas WHERE No = @I
  IF @@ROWCOUNT = 0 BREAK

  RAISERROR ('TEST CASE CLEANUP #%0.2d. DROPPING SCHEMA %s', 10, 1, @I, @SchemaName) WITH NOWAIT
  SET @ExecuteCommand = REPLACE('IF SCHEMA_ID(''%SCHEMANAME%'') IS NOT NULL DROP SCHEMA %SCHEMANAME%', '%SCHEMANAME%', QUOTENAME(@SchemaName))
  EXECUTE (@ExecuteCommand)
  
  SET @I = @I + 1
END
PRINT ''
PRINT ''

IF (OBJECT_ID('tempdb..#TestSchemas', 'U') IS NOT NULL) DROP TABLE #TestSchemas
IF (OBJECT_ID('tempdb..#TestTables', 'U') IS NOT NULL) DROP TABLE #TestTables  
IF (OBJECT_ID('tempdb..#TestTablesPreCleanup', 'U') IS NOT NULL) DROP TABLE #TestTablesPreCleanup  
IF (OBJECT_ID('tempdb..#TestTablesPostCleanup', 'U') IS NOT NULL) DROP TABLE #TestTablesPostCleanup  
IF (OBJECT_ID('tempdb..#TestCases', 'U') IS NOT NULL) DROP TABLE #TestCases


GO
 
 