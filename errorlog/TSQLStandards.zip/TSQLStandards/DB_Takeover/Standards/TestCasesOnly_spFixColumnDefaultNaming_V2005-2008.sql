USE tempdb
GO
/*********************************************************************************

  File:         spFixColumnDefaultNaming - Test Cases.sql
  Author:       Michael S�ndergaard
  Date:         December 2009
  Build Date:   20 March 2011
  Homepage:     http://sql.soendergaard.info
  Version:      1.0.2
  Supported / 
  Tested on:    Microsoft SQL Server 2005 & 2008
  
  Description:  This file contains all the test cases used for developing the 
                stored procedure dbautils.spFixColumnDefaultNaming.
                
  Requirements: The stored procedure dbautils.spFixColumnDefaultNaming should be
                installed in the tempdb.
                
                All test cases will be created in tempdb. for ensuring better cleanup
                and avoiding permissions

  Usage:        See test cases

  -----------------------------------------------------------------------------------

  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF
  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
  TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
  PARTICULAR PURPOSE. YOU MAY USE AND MODIFY THIS CODE FREELY FOR
  YOUR OWN PURPOSE, IF YOU REMEMBER TO CREDIT MY WORK. HOWEVER YOU 
  MAY NOT REPUBLISH IT, AND CLAIM IT AS YOUR OWN WORK 


  -----------------------------------------------------------------------------------

  Revision History:

    Version 1.0.0 - December 6 , 2009 
      - Inital version 

    Version 1.0.1 - April 4, 2010 
      - Added test cases for column aliases
      - Added test cases for table aliases
      - Added test cases for schema aliases

    Version 1.0.2 - May 8, 2010 
      - Added test cases for MaxNameLenght
      - Added test cases for UniquifyNames
 
**********************************************************************************/
USE tempdb

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

SET NOCOUNT ON

-- #######################################################################################
-- ###### Verify all requirements for this test case script
-- #######################################################################################
IF OBJECT_ID('dbautils.fnGetFilteredTables', 'TF') IS NULL
BEGIN
  RAISERROR('The user defined function dbautils.fnGetFilteredTables is not installed in the tempdb', 16, 1)
  RETURN
END 

IF SCHEMA_ID('dbautils') IS NULL EXECUTE ('CREATE SCHEMA dbautils AUTHORIZATION dbo')

DECLARE @DBIsCaseSensitive BIT
SET @DBIsCaseSensitive = CASE WHEN 'a' = 'A' THEN CAST(0 AS BIT) ELSE 1 END

DELETE dbautils.AliasRulesSynonym  

-- #######################################################################################
-- ###### Create the AliasRules for the test cases
-- #######################################################################################
INSERT INTO dbautils.AliasRulesSynonym
(
  DatabaseName,
  SchemaName,
  TableName,
  ColumnName,
  AliasName
)
          SELECT DatabaseName = 'tempdb', SchemaName = 'ColumnAliasRenaming', TableName = 'Case01', ColumnName = 'ProductName', AliasName = 'CAR1' 
UNION ALL SELECT DatabaseName = 'tempdb', SchemaName = 'ColumnAliasRenaming', TableName = 'Case02', ColumnName = 'ProductName', AliasName = 'CAR2'
UNION ALL SELECT DatabaseName = 'tempdb', SchemaName = 'ColumnAliasRenaming', TableName = 'Case03', ColumnName = 'ProductName', AliasName = 'CAR3' 
UNION ALL SELECT DatabaseName = '%', SchemaName = 'ColumnAliasRenaming', TableName = '%', ColumnName = 'ProductName', AliasName = 'CAR' 

UNION ALL SELECT DatabaseName = 'tempdb', SchemaName = 'TableAliasRenaming', TableName = 'Case01', ColumnName = '', AliasName = 'TAR1' 
UNION ALL SELECT DatabaseName = 'tempdb', SchemaName = 'TableAliasRenaming', TableName = 'Case02', ColumnName = '', AliasName = 'TAR2'
UNION ALL SELECT DatabaseName = 'tempdb', SchemaName = 'TableAliasRenaming', TableName = 'Case03', ColumnName = '', AliasName = 'TAR3' 
UNION ALL SELECT DatabaseName = '%', SchemaName = '%', TableName = 'Case04', ColumnName = '', AliasName = 'TAR4' 

UNION ALL SELECT DatabaseName = 'msdb', SchemaName = 'SchemaAliasRenaming01', TableName = '', ColumnName = '', AliasName = 'SAR01' 
UNION ALL SELECT DatabaseName = 'tempdb', SchemaName = 'SchemaAliasRenaming02', TableName = '', ColumnName = '', AliasName = 'SAR02'
UNION ALL SELECT DatabaseName = '%', SchemaName = 'SchemaAliasRenaming03', TableName = '', ColumnName = '', AliasName = 'SAR03'

UNION ALL SELECT DatabaseName = 'msdb', SchemaName = 'AliasRenaming01', TableName = '', ColumnName = '', AliasName = 'AR01' 
UNION ALL SELECT DatabaseName = 'msdb', SchemaName = 'AliasRenaming01', TableName = 'Case01', ColumnName = '', AliasName = 'AR02' 
UNION ALL SELECT DatabaseName = 'msdb', SchemaName = 'AliasRenaming01', TableName = 'Case01', ColumnName = 'ProductName', AliasName = 'AR03' 
UNION ALL SELECT DatabaseName = 'tempdb', SchemaName = 'AliasRenaming02', TableName = '', ColumnName = '', AliasName = 'AR04'
UNION ALL SELECT DatabaseName = 'tempdb', SchemaName = 'AliasRenaming02', TableName = 'Case01', ColumnName = '', AliasName = 'AR05'
UNION ALL SELECT DatabaseName = 'tempdb', SchemaName = 'AliasRenaming02', TableName = 'Case01', ColumnName = 'ProductName', AliasName = 'AR06'
UNION ALL SELECT DatabaseName = 'tempdb', SchemaName = 'AliasRenaming02', TableName = 'Case02', ColumnName = '', AliasName = 'AR07'
UNION ALL SELECT DatabaseName = 'tempdb', SchemaName = 'AliasRenaming02', TableName = 'Case02', ColumnName = 'ProductName', AliasName = 'AR08'
UNION ALL SELECT DatabaseName = '%', SchemaName = 'AliasRenaming03', TableName = '', ColumnName = '', AliasName = 'AR09'
UNION ALL SELECT DatabaseName = '%', SchemaName = 'AliasRenaming03', TableName = 'Case01', ColumnName = '', AliasName = 'AR10'
UNION ALL SELECT DatabaseName = '%', SchemaName = 'AliasRenaming03', TableName = 'Case01', ColumnName = 'ProductName', AliasName = 'AR11'
UNION ALL SELECT DatabaseName = '%', SchemaName = 'AliasRenaming03', TableName = 'Case02', ColumnName = '', AliasName = 'AR12'
UNION ALL SELECT DatabaseName = '%', SchemaName = 'AliasRenaming03', TableName = 'Case02', ColumnName = 'ProductName', AliasName = 'AR13'


-- #######################################################################################
-- ###### Create a table for all schemas in test data
-- #######################################################################################
IF (OBJECT_ID('#TestSchemas', 'U') IS NOT NULL) DROP TABLE #TestSchemas 
CREATE TABLE #TestSchemas  
(
  IndexNo INT IDENTITY,
  SchemaName sysname NOT NULL
)

-- #######################################################################################
-- ###### Create a table containing all test tables
-- #######################################################################################
IF (OBJECT_ID('#TestTables', 'U') IS NOT NULL) DROP TABLE #TestTables 
CREATE TABLE #TestTables  
(
  TestNo INT IDENTITY PRIMARY KEY NOT NULL,
  SchemaName sysname NOT NULL,
  TableName sysname NOT NULL,
  ColumnName sysname NOT NULL,
  DefaultName sysname NOT NULL,
  ObjectName AS QUOTENAME(SchemaName) + '.' + QUOTENAME(TableName)  
)

-- #######################################################################################
-- ###### Insert all test cases into the test case table
-- #######################################################################################
INSERT #TestTables
(
  SchemaName, 
  TableName,
  ColumnName,
  DefaultName 
)
          SELECT SchemaName = 'FromSpecialChar', TableName = 'Case01', ColumnName = 'ProductName', DefaultName = 'DEFAULT_'
UNION ALL SELECT SchemaName = 'FromSpecialChar', TableName = 'Case02', ColumnName = 'ProductName', DefaultName = ' DEFAULT'
UNION ALL SELECT SchemaName = 'FromSpecialChar', TableName = 'Case03', ColumnName = 'ProductName', DefaultName = 'DEFAULT '
UNION ALL SELECT SchemaName = 'FromSpecialChar', TableName = 'Case04', ColumnName = 'ProductName', DefaultName = 'DEFAULT?'
UNION ALL SELECT SchemaName = 'FromSpecialChar', TableName = 'Case05', ColumnName = 'ProductName', DefaultName = 'DEFAULT%'
UNION ALL SELECT SchemaName = 'FromSpecialChar', TableName = 'Case06', ColumnName = 'ProductName', DefaultName = 'DEFAULT^'
UNION ALL SELECT SchemaName = 'FromSpecialChar', TableName = 'Case07', ColumnName = 'ProductName', DefaultName = 'DEFAULT'''
UNION ALL SELECT SchemaName = 'FromSpecialChar', TableName = 'Case08', ColumnName = 'ProductName', DefaultName = 'DEFAULT"'
UNION ALL SELECT SchemaName = 'FromSpecialChar', TableName = 'Case09', ColumnName = 'ProductName', DefaultName = 'DEFAULT,'
UNION ALL SELECT SchemaName = 'FromSpecialChar', TableName = 'Case10', ColumnName = 'ProductName', DefaultName = 'DEFAULT.'
UNION ALL SELECT SchemaName = 'FromSpecialChar', TableName = 'Case11', ColumnName = 'ProductName', DefaultName = 'DEFAULT*'
UNION ALL SELECT SchemaName = 'FromSpecialChar', TableName = 'Case12', ColumnName = 'ProductName', DefaultName = 'DEFAULT['
UNION ALL SELECT SchemaName = 'FromSpecialChar', TableName = 'Case13', ColumnName = 'ProductName', DefaultName = 'DEFAULT]'
UNION ALL SELECT SchemaName = 'FromSpecialChar', TableName = 'Case14', ColumnName = 'ProductName', DefaultName = 'DEFAULT-'
UNION ALL SELECT SchemaName = 'FromSpecialChar', TableName = 'Case15', ColumnName = 'ProductName', DefaultName = 'DEFAULT+'
UNION ALL SELECT SchemaName = 'FromSpecialChar', TableName = 'Case16', ColumnName = 'ProductName', DefaultName = '"DEFAULT"'
UNION ALL SELECT SchemaName = 'FromSpecialChar', TableName = 'Case17', ColumnName = 'ProductName', DefaultName = '[DEFAULT]'
UNION ALL SELECT SchemaName = 'FromSpecialChar', TableName = 'Case18', ColumnName = 'ProductName', DefaultName = '''DEFAULT'''
UNION ALL SELECT SchemaName = 'FromSpecialChar', TableName = 'Case19', ColumnName = 'ProductName', DefaultName = 'DEFAULT.VALUE'
UNION ALL SELECT SchemaName = 'FromSpecialChar', TableName = 'Case20', ColumnName = 'ProductName', DefaultName = 'DEFAULT VALUE'

UNION ALL SELECT SchemaName = 'ToSpecialChar', TableName = 'Case01', ColumnName = 'ProductName_', DefaultName = 'DEFAULT_'
UNION ALL SELECT SchemaName = 'ToSpecialChar', TableName = 'Case02', ColumnName = ' ProductName', DefaultName = ' DEFAULT'
UNION ALL SELECT SchemaName = 'ToSpecialChar', TableName = 'Case03', ColumnName = 'ProductName ', DefaultName = 'DEFAULT '
UNION ALL SELECT SchemaName = 'ToSpecialChar', TableName = 'Case04', ColumnName = 'ProductName?', DefaultName = 'DEFAULT?'
UNION ALL SELECT SchemaName = 'ToSpecialChar', TableName = 'Case05', ColumnName = 'ProductName%', DefaultName = 'DEFAULT%'
UNION ALL SELECT SchemaName = 'ToSpecialChar', TableName = 'Case06', ColumnName = 'ProductName^', DefaultName = 'DEFAULT^'
UNION ALL SELECT SchemaName = 'ToSpecialChar', TableName = 'Case07', ColumnName = 'ProductName''', DefaultName = 'DEFAULT'''
UNION ALL SELECT SchemaName = 'ToSpecialChar', TableName = 'Case08', ColumnName = 'ProductName"', DefaultName = 'DEFAULT"'
UNION ALL SELECT SchemaName = 'ToSpecialChar', TableName = 'Case09', ColumnName = 'ProductName,', DefaultName = 'DEFAULT,'
UNION ALL SELECT SchemaName = 'ToSpecialChar', TableName = 'Case10', ColumnName = 'ProductName.', DefaultName = 'DEFAULT.'
UNION ALL SELECT SchemaName = 'ToSpecialChar', TableName = 'Case11', ColumnName = 'ProductName*', DefaultName = 'DEFAULT*'
UNION ALL SELECT SchemaName = 'ToSpecialChar', TableName = 'Case12', ColumnName = 'ProductName[', DefaultName = 'DEFAULT['
UNION ALL SELECT SchemaName = 'ToSpecialChar', TableName = 'Case13', ColumnName = 'ProductName]', DefaultName = 'DEFAULT]'
UNION ALL SELECT SchemaName = 'ToSpecialChar', TableName = 'Case14', ColumnName = 'ProductName-', DefaultName = 'DEFAULT-'
UNION ALL SELECT SchemaName = 'ToSpecialChar', TableName = 'Case15', ColumnName = 'ProductName+', DefaultName = 'DEFAULT+'
UNION ALL SELECT SchemaName = 'ToSpecialChar', TableName = 'Case16', ColumnName = '"ProductName"', DefaultName = '"DEFAULT"'
UNION ALL SELECT SchemaName = 'ToSpecialChar', TableName = 'Case17', ColumnName = '[ProductName]', DefaultName = '[DEFAULT]'
UNION ALL SELECT SchemaName = 'ToSpecialChar', TableName = 'Case18', ColumnName = '''ProductName''', DefaultName = '''DEFAULT'''
UNION ALL SELECT SchemaName = 'ToSpecialChar', TableName = 'Case19', ColumnName = 'Product.Name', DefaultName = 'DEFAULT.VALUE'
UNION ALL SELECT SchemaName = 'ToSpecialChar', TableName = 'Case20', ColumnName = 'Product Name', DefaultName = 'DEFAULT VALUE'

UNION ALL SELECT SchemaName = 'FilteredRenaming', TableName = 'Case01', ColumnName = 'ProductName', DefaultName = 'DEFAULTNAME01'
UNION ALL SELECT SchemaName = 'FilteredRenaming', TableName = 'Case02', ColumnName = 'ProductName', DefaultName = 'DEFAULTNAME02'
UNION ALL SELECT SchemaName = 'FilteredRenaming', TableName = 'Case03', ColumnName = 'ProductName', DefaultName = 'DEFAULTNAME03'
UNION ALL SELECT SchemaName = 'FilteredRenaming', TableName = 'Case04', ColumnName = 'ProductName', DefaultName = 'DEFAULTNAME04'

UNION ALL SELECT SchemaName = 'CustomRenaming', TableName = 'Case01', ColumnName = 'ProductName', DefaultName = 'DEFAULTNAME01'
UNION ALL SELECT SchemaName = 'CustomRenaming', TableName = 'Case02', ColumnName = 'ProductName', DefaultName = 'DEFAULTNAME02'
UNION ALL SELECT SchemaName = 'CustomRenaming', TableName = 'Case03', ColumnName = 'ProductName', DefaultName = 'DEFAULTNAME03'
UNION ALL SELECT SchemaName = 'CustomRenaming', TableName = 'Case04', ColumnName = 'ProductName', DefaultName = 'DEFAULTNAME04'

UNION ALL SELECT SchemaName = 'MaxNameLength&Truncate', TableName = 'Case01', ColumnName = 'ProductName', CheckName = 'DEFAULTNAME01'
UNION ALL SELECT SchemaName = 'MaxNameLength&Skip', TableName = 'Case01', ColumnName = 'ProductName', CheckName = 'DEFAULTNAME01'
UNION ALL SELECT SchemaName = 'UniquifyCheckConstraints', TableName = 'Case01', ColumnName = 'ProductName', CheckName = 'DEFAULTNAME01'
UNION ALL SELECT SchemaName = 'UniquifyCheckConstraints', TableName = 'Case02', ColumnName = 'ProductName', CheckName = 'DEFAULTNAME02'
UNION ALL SELECT SchemaName = 'UniquifyCheckConstraints', TableName = 'Case03', ColumnName = 'ProductName', CheckName = 'DEFAULTNAME03'
UNION ALL SELECT SchemaName = 'UniquifyCheckConstraints', TableName = 'Case04', ColumnName = 'ProductName', CheckName = 'DEFAULTNAME04'

UNION ALL SELECT SchemaName = 'CasingRenaming', TableName = 'Case01', ColumnName = 'ProductName', DefaultName = 'DF_Case01_PRODUCTNAME'
UNION ALL SELECT SchemaName = 'CasingRenaming', TableName = 'Case02', ColumnName = 'ProductName', DefaultName = 'DF_Case02_PRODUCTNAME'

UNION ALL SELECT SchemaName = 'ColumnAliasRenaming', TableName = 'Case01', ColumnName = 'ProductName', CheckName = 'DF_Case01_ProductName'
UNION ALL SELECT SchemaName = 'ColumnAliasRenaming', TableName = 'Case02', ColumnName = 'ProductName', CheckName = 'DF_Case02_ProductName'
UNION ALL SELECT SchemaName = 'ColumnAliasRenaming', TableName = 'Case03', ColumnName = 'ProductName', CheckName = 'DF_Case03_ProductName'

UNION ALL SELECT SchemaName = 'TableAliasRenaming', TableName = 'Case01', ColumnName = 'ProductName', CheckName = 'DF_Case01_ProductName'
UNION ALL SELECT SchemaName = 'TableAliasRenaming', TableName = 'Case02', ColumnName = 'ProductName', CheckName = 'DF_Case02_ProductName'
UNION ALL SELECT SchemaName = 'TableAliasRenaming', TableName = 'Case03', ColumnName = 'ProductName', CheckName = 'DF_Case03_ProductName'
UNION ALL SELECT SchemaName = 'TableAliasRenaming', TableName = 'Case04', ColumnName = 'ProductName', CheckName = 'DF_Case04_ProductName'

UNION ALL SELECT SchemaName = 'SchemaAliasRenaming01', TableName = 'Case01', ColumnName = 'ProductName', CheckName = 'DF_Case01_ProductName'
UNION ALL SELECT SchemaName = 'SchemaAliasRenaming02', TableName = 'Case02', ColumnName = 'ProductName', CheckName = 'DF_Case02_ProductName'
UNION ALL SELECT SchemaName = 'SchemaAliasRenaming03', TableName = 'Case03', ColumnName = 'ProductName', CheckName = 'DF_Case03_ProductName'

UNION ALL SELECT SchemaName = 'AliasRenaming01', TableName = 'Case01', ColumnName = 'ProductName', CheckName = 'DF_Case01_ProductName'
UNION ALL SELECT SchemaName = 'AliasRenaming01', TableName = 'Case02', ColumnName = 'ProductName', CheckName = 'DF_Case02_ProductName'
UNION ALL SELECT SchemaName = 'AliasRenaming01', TableName = 'Case03', ColumnName = 'ProductName', CheckName = 'DF_Case03_ProductName'
UNION ALL SELECT SchemaName = 'AliasRenaming02', TableName = 'Case01', ColumnName = 'ProductName', CheckName = 'DF_Case01_ProductName'
UNION ALL SELECT SchemaName = 'AliasRenaming02', TableName = 'Case02', ColumnName = 'ProductName', CheckName = 'DF_Case02_ProductName'
UNION ALL SELECT SchemaName = 'AliasRenaming02', TableName = 'Case03', ColumnName = 'ProductName', CheckName = 'DF_Case03_ProductName'
UNION ALL SELECT SchemaName = 'AliasRenaming03', TableName = 'Case01', ColumnName = 'ProductName', CheckName = 'DF_Case01_ProductName'
UNION ALL SELECT SchemaName = 'AliasRenaming03', TableName = 'Case02', ColumnName = 'ProductName', CheckName = 'DF_Case02_ProductName'
UNION ALL SELECT SchemaName = 'AliasRenaming03', TableName = 'Case03', ColumnName = 'ProductName', CheckName = 'DF_Case03_ProductName'


-- #######################################################################################
-- ###### Create a table with all schemas used by the test cases
-- #######################################################################################
INSERT INTO #TestSchemas (SchemaName)
SELECT DISTINCT SchemaName FROM #TestTables WHERE SchemaName != 'dbo'

-- #######################################################################################
-- ###### Create a table containing all test cases
-- #######################################################################################
IF (OBJECT_ID('tempdb..#TestCases', 'U') IS NOT NULL) DROP TABLE #TestCases 
CREATE TABLE #TestCases  
(
  TestNo INT IDENTITY PRIMARY KEY NOT NULL,
  TestDesc NVARCHAR(MAX) NOT NULL,
  FilterSchema NVARCHAR(MAX) NULL,
  FilterTable NVARCHAR(MAX) NULL,
  NamingConvention NVARCHAR(MAX) NULL,
  OversizedMode NCHAR(1) NULL,
  ForceCaseSensitivity BIT NULL,
  UseAliases CHAR(3) NULL,
  MaxNameLength TINYINT NULL,
  UniquifyNames BIT NULL,
  Expected NVARCHAR(MAX) NOT NULL,
)

-- #######################################################################################
-- ###### Insert all test cases into the test case table
-- #######################################################################################

INSERT #TestCases( TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Check constraint renaming from a name with "_" in it', FilterSchema = 'FromSpecialChar', FilterTable = 'Case01', Expected = '[FromSpecialChar].[Case01].[ProductName].[DF_Case01_ProductName]'
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Check constraint renaming from a name with leading space', FilterSchema = 'FromSpecialChar', FilterTable = 'Case02', Expected = '[FromSpecialChar].[Case02].[ProductName].[DF_Case02_ProductName]'
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Check constraint renaming from a name with trailing space', FilterSchema = 'FromSpecialChar', FilterTable = 'Case03', Expected = '[FromSpecialChar].[Case03].[ProductName].[DF_Case03_ProductName]'
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Check constraint renaming from a name with "?" in it', FilterSchema = 'FromSpecialChar', FilterTable = 'Case04', Expected = '[FromSpecialChar].[Case04].[ProductName].[DF_Case04_ProductName]'
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Check constraint renaming from a name with "%" in it', FilterSchema = 'FromSpecialChar', FilterTable = 'Case05', Expected = '[FromSpecialChar].[Case05].[ProductName].[DF_Case05_ProductName]'
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Check constraint renaming from a name with "^" in it', FilterSchema = 'FromSpecialChar', FilterTable = 'Case06', Expected = '[FromSpecialChar].[Case06].[ProductName].[DF_Case06_ProductName]'
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Check constraint renaming from a name with "''" in it', FilterSchema = 'FromSpecialChar', FilterTable = 'Case07', Expected = '[FromSpecialChar].[Case07].[ProductName].[DF_Case07_ProductName]'
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Check constraint renaming from a name with """ in it', FilterSchema = 'FromSpecialChar', FilterTable = 'Case08', Expected = '[FromSpecialChar].[Case08].[ProductName].[DF_Case08_ProductName]'
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Check constraint renaming from a name with "," in it', FilterSchema = 'FromSpecialChar', FilterTable = 'Case09', Expected = '[FromSpecialChar].[Case09].[ProductName].[DF_Case09_ProductName]'
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Check constraint renaming from a name with "." in it', FilterSchema = 'FromSpecialChar', FilterTable = 'Case10', Expected = '[FromSpecialChar].[Case10].[ProductName].[DF_Case10_ProductName]'
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Check constraint renaming from a name with "*" in it', FilterSchema = 'FromSpecialChar', FilterTable = 'Case11', Expected = '[FromSpecialChar].[Case11].[ProductName].[DF_Case11_ProductName]'
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Check constraint renaming from a name with "[" in it', FilterSchema = 'FromSpecialChar', FilterTable = 'Case12', Expected = '[FromSpecialChar].[Case12].[ProductName].[DF_Case12_ProductName]'
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Check constraint renaming from a name with "]" in it', FilterSchema = 'FromSpecialChar', FilterTable = 'Case13', Expected = '[FromSpecialChar].[Case13].[ProductName].[DF_Case13_ProductName]'
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Check constraint renaming from a name with "-" in it', FilterSchema = 'FromSpecialChar', FilterTable = 'Case14', Expected = '[FromSpecialChar].[Case14].[ProductName].[DF_Case14_ProductName]'
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Check constraint renaming from a name with "+" in it', FilterSchema = 'FromSpecialChar', FilterTable = 'Case15', Expected = '[FromSpecialChar].[Case15].[ProductName].[DF_Case15_ProductName]'
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Check constraint renaming from a name surrouned with ""', FilterSchema = 'FromSpecialChar', FilterTable = 'Case16', Expected = '[FromSpecialChar].[Case16].[ProductName].[DF_Case16_ProductName]'
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Check constraint renaming from a name surrouned with []', FilterSchema = 'FromSpecialChar', FilterTable = 'Case17', Expected = '[FromSpecialChar].[Case17].[ProductName].[DF_Case17_ProductName]'
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Check constraint renaming from a name surrouned with ''''', FilterSchema = 'FromSpecialChar', FilterTable = 'Case18', Expected = '[FromSpecialChar].[Case18].[ProductName].[DF_Case18_ProductName]'
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Check constraint renaming from a name with "." in the middle', FilterSchema = 'FromSpecialChar', FilterTable = 'Case19', Expected = '[FromSpecialChar].[Case19].[ProductName].[DF_Case19_ProductName]'
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Check constraint renaming from a name with " " in the middle', FilterSchema = 'FromSpecialChar', FilterTable = 'Case20', Expected = '[FromSpecialChar].[Case20].[ProductName].[DF_Case20_ProductName]'

INSERT #TestCases( TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Check constraint renaming to a name with "_" in it', FilterSchema = 'ToSpecialChar', FilterTable = 'Case01', Expected = '[ToSpecialChar].[Case01].[ProductName_].[DF_Case01_ProductName_]'
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Check constraint renaming to a name with leading space', FilterSchema = 'ToSpecialChar', FilterTable = 'Case02', Expected = '[ToSpecialChar].[Case02].[ ProductName].[DF_Case02_ ProductName]'
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Check constraint renaming to a name with trailing space', FilterSchema = 'ToSpecialChar', FilterTable = 'Case03', Expected = '[ToSpecialChar].[Case03].[ProductName ].[DF_Case03_ProductName ]'
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Check constraint renaming to a name with "?" in it', FilterSchema = 'ToSpecialChar', FilterTable = 'Case04', Expected = '[ToSpecialChar].[Case04].[ProductName?].[DF_Case04_ProductName?]'
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Check constraint renaming to a name with "%" in it', FilterSchema = 'ToSpecialChar', FilterTable = 'Case05', Expected = '[ToSpecialChar].[Case05].[ProductName%].[DF_Case05_ProductName%]'
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Check constraint renaming to a name with "^" in it', FilterSchema = 'ToSpecialChar', FilterTable = 'Case06', Expected = '[ToSpecialChar].[Case06].[ProductName^].[DF_Case06_ProductName^]'
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Check constraint renaming to a name with "''" in it', FilterSchema = 'ToSpecialChar', FilterTable = 'Case07', Expected = '[ToSpecialChar].[Case07].[ProductName''].[DF_Case07_ProductName'']'
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Check constraint renaming to a name with """ in it', FilterSchema = 'ToSpecialChar', FilterTable = 'Case08', Expected = '[ToSpecialChar].[Case08].[ProductName"].[DF_Case08_ProductName"]'
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Check constraint renaming to a name with "," in it', FilterSchema = 'ToSpecialChar', FilterTable = 'Case09', Expected = '[ToSpecialChar].[Case09].[ProductName,].[DF_Case09_ProductName,]'
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Check constraint renaming to a name with "." in it', FilterSchema = 'ToSpecialChar', FilterTable = 'Case10', Expected = '[ToSpecialChar].[Case10].[ProductName.].[DF_Case10_ProductName.]'
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Check constraint renaming to a name with "*" in it', FilterSchema = 'ToSpecialChar', FilterTable = 'Case11', Expected = '[ToSpecialChar].[Case11].[ProductName*].[DF_Case11_ProductName*]'
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Check constraint renaming to a name with "[" in it', FilterSchema = 'ToSpecialChar', FilterTable = 'Case12', Expected = '[ToSpecialChar].[Case12].[ProductName[].[DF_Case12_ProductName[]'
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Check constraint renaming to a name with "]" in it', FilterSchema = 'ToSpecialChar', FilterTable = 'Case13', Expected = '[ToSpecialChar].[Case13].[ProductName]]].[DF_Case13_ProductName]]]'
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Check constraint renaming to a name with "-" in it', FilterSchema = 'ToSpecialChar', FilterTable = 'Case14', Expected = '[ToSpecialChar].[Case14].[ProductName-].[DF_Case14_ProductName-]'
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Check constraint renaming to a name with "+" in it', FilterSchema = 'ToSpecialChar', FilterTable = 'Case15', Expected = '[ToSpecialChar].[Case15].[ProductName+].[DF_Case15_ProductName+]'
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Check constraint renaming to a name surrouned with ""', FilterSchema = 'ToSpecialChar', FilterTable = 'Case16', Expected = '[ToSpecialChar].[Case16].["ProductName"].[DF_Case16_"ProductName"]'
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Check constraint renaming to a name surrouned with []', FilterSchema = 'ToSpecialChar', FilterTable = 'Case17', Expected = '[ToSpecialChar].[Case17].[[ProductName]]].[DF_Case17_[ProductName]]]'
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Check constraint renaming to a name surrouned with ''''', FilterSchema = 'ToSpecialChar', FilterTable = 'Case18', Expected = '[ToSpecialChar].[Case18].[''ProductName''].[DF_Case18_''ProductName'']'
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Check constraint renaming to a name with "." in the middle', FilterSchema = 'ToSpecialChar', FilterTable = 'Case19', Expected = '[ToSpecialChar].[Case19].[Product.Name].[DF_Case19_Product.Name]'
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Check constraint renaming to a name with " " in the middle', FilterSchema = 'ToSpecialChar', FilterTable = 'Case20', Expected = '[ToSpecialChar].[Case20].[Product Name].[DF_Case20_Product Name]'

INSERT #TestCases( TestDesc, FilterSchema, FilterTable, Expected) SELECT TestDesc = 'Check constraint renaming - filtered ', FilterSchema = 'FilteredRenaming', FilterTable = '%', Expected = '[FilteredRenaming].[Case01].[ProductName].[DF_Case01_ProductName];[FilteredRenaming].[Case02].[ProductName].[DF_Case02_ProductName];[FilteredRenaming].[Case03].[ProductName].[DF_Case03_ProductName];[FilteredRenaming].[Case04].[ProductName].[DF_Case04_ProductName]'
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, NamingConvention, Expected) SELECT TestDesc = 'Check constraint renaming - custom naming convention', FilterSchema = 'CustomRenaming', FilterTable = '%', NamingConvention = 'DF_%SCHEMA_NAME%_%TABLE_NAME%_%COLUMN_NAME%', Expected = '[CustomRenaming].[Case01].[ProductName].[DF_CustomRenaming_Case01_ProductName];[CustomRenaming].[Case02].[ProductName].[DF_CustomRenaming_Case02_ProductName];[CustomRenaming].[Case03].[ProductName].[DF_CustomRenaming_Case03_ProductName];[CustomRenaming].[Case04].[ProductName].[DF_CustomRenaming_Case04_ProductName]'
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, OversizedMode, MaxNameLength, Expected) SELECT TestDesc = 'Check constraint renaming - oversized mode skip', FilterSchema = 'MaxNameLength&Skip', FilterTable = '%', OversizedMode = 'S', MaxNameLength = 10, Expected = '[MaxNameLength&Skip].[Case01].[ProductName].[DEFAULTNAME01]'
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, OversizedMode, MaxNameLength, Expected) SELECT TestDesc = 'Check constraint renaming - oversized mode truncate', FilterSchema = 'MaxNameLength&Truncate', FilterTable = '%', OversizedMode = 'T', MaxNameLength = 10, Expected = '[MaxNameLength&Truncate].[Case01].[ProductName].[DF_Case01_]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, UniquifyNames, NamingConvention, Expected) SELECT TestDesc = 'Check constraint renaming with uniquifying constraint names', FilterSchema = 'UniquifyCheckConstraints', FilterTable = '%', UniquifyNames = 1, NamingConvention = 'DF_%COLUMN_NAME%', Expected = '[UniquifyCheckConstraints].[Case01].[ProductName].[DF_ProductName];[UniquifyCheckConstraints].[Case02].[ProductName].[DF_ProductName2];[UniquifyCheckConstraints].[Case03].[ProductName].[DF_ProductName3];[UniquifyCheckConstraints].[Case04].[ProductName].[DF_ProductName4]' 
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, ForceCaseSensitivity, Expected) SELECT TestDesc = 'Check constraint renaming - case sensitivity differences', FilterSchema = 'CasingRenaming', FilterTable = 'Case01', ForceCaseSensitivity = 0, Expected = '[CasingRenaming].[Case01].[ProductName].[DF_Case01_PRODUCTNAME]' WHERE @DBIsCaseSensitive = 0
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, ForceCaseSensitivity, Expected) SELECT TestDesc = 'Check constraint renaming - case sensitivity differences', FilterSchema = 'CasingRenaming', FilterTable = 'Case01', ForceCaseSensitivity = 0, Expected = '[CasingRenaming].[Case01].[ProductName].[DF_Case01_ProductName]' WHERE @DBIsCaseSensitive = 1
INSERT #TestCases( TestDesc, FilterSchema, FilterTable, ForceCaseSensitivity, Expected) SELECT TestDesc = 'Check constraint renaming - force case sensitivity differences', FilterSchema = 'CasingRenaming', FilterTable = 'Case02', ForceCaseSensitivity = 1, Expected = '[CasingRenaming].[Case02].[ProductName].[DF_Case02_ProductName]'

INSERT #TestCases (TestDesc, FilterSchema, FilterTable, UseAliases, Expected) SELECT TestDesc = 'Check constraint renaming with column aliasing', FilterSchema = 'ColumnAliasRenaming', FilterTable = 'Case01', UseAliases = 'C', Expected = '[ColumnAliasRenaming].[Case01].[ProductName].[DF_Case01_CAR1]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, UseAliases, Expected) SELECT TestDesc = 'Check constraint renaming with column aliasing', FilterSchema = 'ColumnAliasRenaming', FilterTable = 'Case02', UseAliases = 'C', Expected = '[ColumnAliasRenaming].[Case02].[ProductName].[DF_Case02_CAR2]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, UseAliases, Expected) SELECT TestDesc = 'Check constraint renaming with column aliasing', FilterSchema = 'ColumnAliasRenaming', FilterTable = 'Case03', UseAliases = 'C', Expected = '[ColumnAliasRenaming].[Case03].[ProductName].[DF_Case03_CAR3]'

INSERT #TestCases (TestDesc, FilterSchema, FilterTable, UseAliases, Expected) SELECT TestDesc = 'Check constraint renaming with table aliasing', FilterSchema = 'TableAliasRenaming', FilterTable = 'Case01', UseAliases = 'T', Expected = '[TableAliasRenaming].[Case01].[ProductName].[DF_TAR1_ProductName]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, UseAliases, Expected) SELECT TestDesc = 'Check constraint renaming with table aliasing', FilterSchema = 'TableAliasRenaming', FilterTable = 'Case02', UseAliases = 'T', Expected = '[TableAliasRenaming].[Case02].[ProductName].[DF_TAR2_ProductName]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, UseAliases, Expected) SELECT TestDesc = 'Check constraint renaming with table aliasing', FilterSchema = 'TableAliasRenaming', FilterTable = 'Case03', UseAliases = 'T', Expected = '[TableAliasRenaming].[Case03].[ProductName].[DF_TAR3_ProductName]'
                                                                                                                                                                                                                                                                                            
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, UseAliases, NamingConvention, Expected) SELECT TestDesc = 'Check constraint renaming with schema aliasing', FilterSchema = 'SchemaAliasRenaming01', FilterTable = 'Case01', UseAliases = 'S', NamingConvention = 'DF_%SCHEMA_NAME%_%TABLE_NAME%_%COLUMN_NAME%', Expected = '[SchemaAliasRenaming01].[Case01].[ProductName].[DF_SchemaAliasRenaming01_Case01_ProductName]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, UseAliases, NamingConvention, Expected) SELECT TestDesc = 'Check constraint renaming with schema aliasing', FilterSchema = 'SchemaAliasRenaming02', FilterTable = 'Case02', UseAliases = 'S', NamingConvention = 'DF_%SCHEMA_NAME%_%TABLE_NAME%_%COLUMN_NAME%', Expected = '[SchemaAliasRenaming02].[Case02].[ProductName].[DF_SAR02_Case02_ProductName]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, UseAliases, NamingConvention, Expected) SELECT TestDesc = 'Check constraint renaming with schema aliasing', FilterSchema = 'SchemaAliasRenaming03', FilterTable = 'Case03', UseAliases = 'S', NamingConvention = 'DF_%SCHEMA_NAME%_%TABLE_NAME%_%COLUMN_NAME%', Expected = '[SchemaAliasRenaming03].[Case03].[ProductName].[DF_SAR03_Case03_ProductName]'

INSERT #TestCases (TestDesc, FilterSchema, FilterTable, UseAliases, NamingConvention, Expected) SELECT TestDesc = 'Check constraint renaming with aliasing, wrong database rules, no alias match', FilterSchema = 'AliasRenaming01', FilterTable = 'Case01', UseAliases = 'STC', NamingConvention = 'DF_%SCHEMA_NAME%_%TABLE_NAME%_%COLUMN_NAME%', Expected = '[AliasRenaming01].[Case01].[ProductName].[DF_AliasRenaming01_Case01_ProductName]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, UseAliases, NamingConvention, Expected) SELECT TestDesc = 'Check constraint renaming with aliasing, wrong database rules, no alias match', FilterSchema = 'AliasRenaming01', FilterTable = 'Case02', UseAliases = 'STC', NamingConvention = 'DF_%SCHEMA_NAME%_%TABLE_NAME%_%COLUMN_NAME%', Expected = '[AliasRenaming01].[Case02].[ProductName].[DF_AliasRenaming01_Case02_ProductName]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, UseAliases, NamingConvention, Expected) SELECT TestDesc = 'Check constraint renaming with aliasing, wrong database rules, no alias match', FilterSchema = 'AliasRenaming01', FilterTable = 'Case03', UseAliases = 'STC', NamingConvention = 'DF_%SCHEMA_NAME%_%TABLE_NAME%_%COLUMN_NAME%', Expected = '[AliasRenaming01].[Case03].[ProductName].[DF_AliasRenaming01_Case03_ProductName]'

INSERT #TestCases (TestDesc, FilterSchema, FilterTable, UseAliases, NamingConvention, Expected) SELECT TestDesc = 'Check constraint renaming with aliasing, specific database rules, match schema, table, column #1', FilterSchema = 'AliasRenaming02', FilterTable = 'Case01', UseAliases = 'STC', NamingConvention = 'DF_%SCHEMA_NAME%_%TABLE_NAME%_%COLUMN_NAME%', Expected = '[AliasRenaming02].[Case01].[ProductName].[DF_AR04_AR05_AR06]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, UseAliases, NamingConvention, Expected) SELECT TestDesc = 'Check constraint renaming with aliasing, specific database rules, match schema, table, column #2', FilterSchema = 'AliasRenaming02', FilterTable = 'Case02', UseAliases = 'STC', NamingConvention = 'DF_%SCHEMA_NAME%_%TABLE_NAME%_%COLUMN_NAME%', Expected = '[AliasRenaming02].[Case02].[ProductName].[DF_AR04_AR07_AR08]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, UseAliases, NamingConvention, Expected) SELECT TestDesc = 'Check constraint renaming with aliasing, specific database rules, match schema', FilterSchema = 'AliasRenaming02', FilterTable = 'Case03', UseAliases = 'STC', NamingConvention = 'DF_%SCHEMA_NAME%_%TABLE_NAME%_%COLUMN_NAME%', Expected = '[AliasRenaming02].[Case03].[ProductName].[DF_AR04_Case03_ProductName]'

INSERT #TestCases (TestDesc, FilterSchema, FilterTable, UseAliases, NamingConvention, Expected) SELECT TestDesc = 'Check constraint renaming with aliasing, generic database rules, match schema, table, column #1', FilterSchema = 'AliasRenaming03', FilterTable = 'Case01', UseAliases = 'STC', NamingConvention = 'DF_%SCHEMA_NAME%_%TABLE_NAME%_%COLUMN_NAME%', Expected = '[AliasRenaming03].[Case01].[ProductName].[DF_AR09_AR10_AR11]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, UseAliases, NamingConvention, Expected) SELECT TestDesc = 'Check constraint renaming with aliasing, generic database rules, match schema, table, column #2', FilterSchema = 'AliasRenaming03', FilterTable = 'Case02', UseAliases = 'STC', NamingConvention = 'DF_%SCHEMA_NAME%_%TABLE_NAME%_%COLUMN_NAME%', Expected = '[AliasRenaming03].[Case02].[ProductName].[DF_AR09_AR12_AR13]'
INSERT #TestCases (TestDesc, FilterSchema, FilterTable, UseAliases, NamingConvention, Expected) SELECT TestDesc = 'Check constraint renaming with aliasing, generic database rules, match schema', FilterSchema = 'AliasRenaming03', FilterTable = 'Case03', UseAliases = 'STC', NamingConvention = 'DF_%SCHEMA_NAME%_%TABLE_NAME%_%COLUMN_NAME%', Expected = '[AliasRenaming03].[Case03].[ProductName].[DF_AR09_Case03_ProductName]'

DECLARE @ExecuteCommand NVARCHAR(MAX)
DECLARE @ExecuteCommandTemplate NVARCHAR(MAX)
DECLARE @SchemaName sysname
DECLARE @TableName sysname
DECLARE @ColumnName sysname
DECLARE @ObjectName NVARCHAR(256)
DECLARE @DefaultName sysname
DECLARE @I INT 



-- #######################################################################################
-- ###### Execute the test schema initialization command
-- #######################################################################################
SET @I = 1
WHILE (1 = 1)
BEGIN
  SELECT @SchemaName = SchemaName FROM #TestSchemas WHERE IndexNo = @I
  IF @@ROWCOUNT = 0 BREAK

  RAISERROR ('TEST CASE INITIALIZATION #%0.2d. CREATING SCHEMA %s', 10, 1, @I, @SchemaName) WITH NOWAIT
  SET @ExecuteCommand = REPLACE('IF SCHEMA_ID(''%SCHEMANAME%'') IS NULL EXECUTE (''CREATE SCHEMA [%SCHEMANAME%] AUTHORIZATION dbo'')', '%SCHEMANAME%', @SchemaName)
  EXECUTE (@ExecuteCommand)

  SET @I = @I + 1
END
PRINT ''
PRINT ''

-- #######################################################################################
-- ###### Execute the test table initialization command
-- #######################################################################################
SET @ExecuteCommandTemplate = N'IF (OBJECT_ID(''%ESCAPEDOBJECTNAME%'', ''U'') IS NOT NULL)\n\tDROP TABLE %OBJECTNAME%\nCREATE TABLE %OBJECTNAME% (%COLUMN_NAME% INT CONSTRAINT %DEFAULT_NAME% DEFAULT 0)\n'  
SET @I = 1
WHILE (1 = 1)
BEGIN
  SELECT @ObjectName = ObjectName, @ColumnName = QUOTENAME(ColumnName), @DefaultName = QUOTENAME(DefaultName) FROM #TestTables WHERE TestNo = @I
  IF @@ROWCOUNT = 0 BREAK

  RAISERROR ('TEST CASE INITIALIZATION #%0.2d. CREATING TABLE %s', 10, 1, @I, @ObjectName) WITH NOWAIT
  SET @ExecuteCommand =  REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(@ExecuteCommandTemplate, '%OBJECTNAME%', @ObjectName ), '%ESCAPEDOBJECTNAME%', REPLACE(@ObjectName, '''', '''''')), '%DEFAULT_NAME%', @DefaultName), '%COLUMN_NAME%', @ColumnName), '\t', CHAR(9)), '\n', CHAR(13))  
  EXECUTE (@ExecuteCommand)
  
  SET @I = @I + 1
END
PRINT ''
PRINT ''

DECLARE @TestDesc NVARCHAR(MAX)
DECLARE @Expected NVARCHAR(MAX)
DECLARE @Actual NVARCHAR(MAX)
DECLARE @Message NVARCHAR(MAX)
DECLARE @Filter NVARCHAR(MAX)
DECLARE @FilterTable NVARCHAR(MAX)
DECLARE @FilterSchema NVARCHAR(MAX)
DECLARE @NamingConvention NVARCHAR(MAX)
DECLARE @OversizedMode NCHAR(1)
DECLARE @UseAliases CHAR(3)
DECLARE @ForceCaseSensitivity BIT
DECLARE @MaxNameLength TINYINT
DECLARE @UniquifyNames BIT
DECLARE @Statement NVARCHAR(MAX)

-- #######################################################################################
-- ###### Execute the Test runner command
-- #######################################################################################
SET @ExecuteCommand = N'
SET @Statement = ''EXECUTE dbautils.spFixColumnDefaultNaming @PerformUpdate = 2''
DECLARE @FilterExpression NVARCHAR(MAX) 
SET @FilterExpression = @FilterSchema + ''.'' + @FilterTable

IF (@FilterExpression IS NOT NULL) SET @Statement = @Statement + '', @FilterExpression = '''''' + REPLACE(@FilterExpression, '''''''', '''''''''''') + ''''''''    
IF (@NamingConvention IS NOT NULL) SET @Statement = @Statement + '', @NamingConvention = '''''' + REPLACE(@NamingConvention, '''''''', '''''''''''') + ''''''''  
IF (@OversizedMode IS NOT NULL) SET @Statement = @Statement + '', @OversizedMode = '''''' + @OversizedMode + ''''''''  
IF (@ForceCaseSensitivity IS NOT NULL) SET @Statement = @Statement + '', @ForceCaseSensitivity = '' + CAST(@ForceCaseSensitivity AS NCHAR(1))  
IF (@UseAliases IS NOT NULL) SET @Statement = @Statement + '', @UseAliases = '''''' +  @UseAliases + ''''''''  
IF (@MaxNameLength IS NOT NULL) SET @Statement = @Statement + '', @MaxNameLength = '' + CAST(@MaxNameLength AS NVARCHAR(3)) 
IF (@UniquifyNames IS NOT NULL) SET @Statement = @Statement + '', @UniquifyNames = '' + CAST(@UniquifyNames AS NCHAR(1))
PRINT @Statement


EXECUTE (@Statement)
SET @Actual = ''''
SELECT 
  @Actual = @Actual + QUOTENAME(s.name) + ''.'' + QUOTENAME(t.name) + ''.'' + QUOTENAME(c.name) + ''.'' + QUOTENAME(dc.name) + '';''
FROM  
  sys.default_constraints dc 
    JOIN sys.columns c ON
      dc.parent_object_id = c.object_id AND
      dc.parent_column_id = c.column_id
    JOIN sys.tables t ON 
      t.object_id = c.object_id
    JOIN sys.schemas s ON 
      t.schema_id = s.schema_id
    JOIN dbautils.fnGetFilteredTables(@FilterExpression) ft ON
      dc.parent_object_id = ft.ObjectId
ORDER BY
  ROW_NUMBER() OVER(ORDER BY s.name, t.name, c.name, dc.name)
IF Len(@Actual) > 0 SET @Actual = LEFT(@Actual, LEN(@Actual) - 1);
'

SET @Message = '### %s ###\t\tTEST CASE #%0.2d. - %s\n\tSTATEMENT: %s\n\tEXPECTED RESULT: %s\n\tACTUAL RESULT:   %s\n'
SET @I = 1
WHILE (1 = 1)
BEGIN
  SELECT @TestDesc = TestDesc, @FilterSchema = FilterSchema, @FilterTable = FilterTable, @NamingConvention = NamingConvention,  @UseAliases = UseAliases, @ForceCaseSensitivity = ForceCaseSensitivity, @OversizedMode = OversizedMode, @MaxNameLength = MaxNameLength, @UniquifyNames = UniquifyNames, @Expected = Expected FROM #TestCases WHERE TestNo = @I
  IF @@ROWCOUNT = 0 BREAK

  EXECUTE sp_executesql 
    @ExecuteCommand, 
    N'@FilterSchema NVARCHAR(MAX), @FilterTable NVARCHAR(MAX), @NamingConvention NVARCHAR(MAX), @UseAliases CHAR(3), @ForceCaseSensitivity BIT, @OversizedMode NCHAR(1), @MaxNameLength TINYINT, @UniquifyNames BIT, @Actual NVARCHAR(MAX) OUTPUT, @Statement NVARCHAR(MAX) OUTPUT',
    @FilterSchema, @FilterTable, @NamingConvention, @UseAliases, @ForceCaseSensitivity, @OversizedMode, @MaxNameLength, @UniquifyNames, @Actual OUTPUT, @Statement OUTPUT

  SET @Message = REPLACE(REPLACE(@Message, '\n', CHAR(13)), '\t', CHAR(9)) 
  IF @Expected + '#'  COLLATE Latin1_General_BIN = @Actual + '#'  COLLATE Latin1_General_BIN-- Dirty hack, because comparing ' ' and '  ' is equal in sql server
    RAISERROR (@Message, 10, 1, 'SUCCESS!!!', @I, @TestDesc, @Statement, @Expected, @Actual) WITH NOWAIT
  ELSE                            
    RAISERROR (@Message, 16, 1, 'FAILURE!!!', @I, @TestDesc, @Statement, @Expected, @Actual) WITH NOWAIT

  SET @I = @I + 1
END
PRINT ''
PRINT ''

-- #######################################################################################
-- ###### Execute the test table cleanup command
-- #######################################################################################
SET @I = 1
WHILE (1 = 1)
BEGIN
  SELECT @ObjectName = ObjectName FROM #TestTables WHERE TestNo = @I
  IF @@ROWCOUNT = 0 BREAK

  RAISERROR ('TEST CASE CLEANUP #%0.2d. DROPPING TABLE %s', 10, 1, @I, @ObjectName) WITH NOWAIT
  SET @ExecuteCommand = REPLACE(REPLACE('IF OBJECT_ID(''%OBJECT_NAME%'', ''U'') IS NOT NULL DROP TABLE %OBJECTNAME%', '%OBJECTNAME%', @ObjectName), '%OBJECT_NAME%', REPLACE(@ObjectName, '''', ''''''))
  EXECUTE (@ExecuteCommand)
  
  SET @I = @I + 1
END
PRINT ''
PRINT ''


-- #######################################################################################
-- ###### Execute the test schema cleanup command
-- #######################################################################################
SET @I = 1
WHILE (1 = 1)
BEGIN
  SELECT @SchemaName = SchemaName FROM #TestSchemas WHERE IndexNo = @I
  IF @@ROWCOUNT = 0 BREAK

  RAISERROR ('TEST CASE CLEANUP #%0.2d. DROPPING SCHEMA %s', 10, 1, @I, @SchemaName) WITH NOWAIT
  SET @ExecuteCommand = REPLACE('IF SCHEMA_ID(''%SCHEMANAME%'') IS NOT NULL DROP SCHEMA %SCHEMANAME%', '%SCHEMANAME%', QUOTENAME(@SchemaName))
  EXECUTE (@ExecuteCommand)
  
  SET @I = @I + 1
END
PRINT ''
PRINT ''


IF (OBJECT_ID('#TestSchemas', 'U') IS NOT NULL) DROP TABLE #TestSchemas 
IF (OBJECT_ID('#TestTables', 'U') IS NOT NULL) DROP TABLE #TestTables 
IF (OBJECT_ID('#TestCases', 'U') IS NOT NULL) DROP TABLE #TestCases 

GO