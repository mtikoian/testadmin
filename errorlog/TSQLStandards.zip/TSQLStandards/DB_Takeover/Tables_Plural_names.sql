SELECT TABLE_NAME
FROM INFORMATION_SCHEMA.tables 
WHERE TABLE_NAME LIKE '%s'

--tables without primary key
SELECT   TableName=TABLE_SCHEMA + '.' + TABLE_NAME
FROM     information_schema.tables
WHERE    TABLE_TYPE = 'BASE TABLE'
         AND TABLE_SCHEMA + '.' +
         TABLE_NAME NOT IN (SELECT TABLE_SCHEMA + '.' + TABLE_NAME
                            FROM   information_schema.table_constraints
                            WHERE  constraint_type = 'PRIMARY KEY')
ORDER BY TABLE_SCHEMA + '.' + TABLE_NAME

select	*
from information_Schema.Columns c
	inner join information_schema.Tables t on 
		(t.Table_Schema = c.Table_Schema)
		and
		(t.Table_Name = c.Table_Name) 
where t.Table_Schema = 'dbo'
  --and t.Table_Name like '%Security%'
  and t.Table_Name = 'usersroles'
  and (Column_Name like '%createdate%'
  or Column_Name like '%create_date%'
  or Column_Name like '%created_date%'
  or Column_Name like '%createddate%'
  or Column_Name like '%create_dt%'
  or Column_Name like '%createdt%'
  )


  select	*
from information_Schema.Columns c
	inner join information_schema.Tables t on 
		(t.Table_Schema = c.Table_Schema)
		and
		(t.Table_Name = c.Table_Name) 
where t.Table_Schema = 'dbo'
  --and t.Table_Name like '%Security%'
  and t.Table_Name = 'usersroles'
  and (Column_Name like '%ModifiedDate%'
  or Column_Name like '%Modified_date%'
  or Column_Name like '%Modifieddt%'
  or Column_Name like '%Modified_dt%'
  or Column_Name like '%ModifyDate%'
  or Column_Name like '%Modify_date%'
  or Column_Name like '%Modifydt%'
  or Column_Name like '%Modify_dt%'
  or Column_Name like '%Modify_dt%'
  )