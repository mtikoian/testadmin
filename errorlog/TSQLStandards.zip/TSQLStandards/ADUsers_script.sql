
/****** Object:  Table [dbo].[ad_groups]    Script Date: 08/05/2009 08:49:35 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[ad_groups](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[login] [varchar](512) NULL,
	[acctname] [varchar](512) NULL,
	[distname] [varchar](512) NULL,
	[createddate] [datetime] NULL,
	[changeddate] [datetime] NULL,
	[mgr] [varchar](512) NULL,
	[sid] [varbinary](85) NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO


/****** Object:  Table [dbo].[ad_users]    Script Date: 08/05/2009 08:49:55 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[ad_users](
	[row_id] [int] IDENTITY(1,1) NOT NULL,
	[sid] [varbinary](85) NULL,
	[samaccountname] [nvarchar](256) NULL,
	[is_disabled] [nvarchar](256) NULL,
	[createtimestamp] [datetime] NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO


/****** Object:  Table [dbo].[ad_usergroups]    Script Date: 08/05/2009 08:50:10 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[ad_usergroups](
	[userlogin] [varbinary](85) NOT NULL,
	[grouplogin] [varbinary](85) NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO



/****** Object:  LinkedServer [ADSI]    Script Date: 02/04/2009 14:30:18 ******/
EXEC master.dbo.sp_addlinkedserver @server = N'ADSI', @srvproduct=N'Active Directory Services 2.5', @provider=N'ADSDSOObject', @datasrc=N'adsdatasource'
 /* For security reasons the linked server remote logins password is changed with ######## */
EXEC master.dbo.sp_addlinkedsrvlogin @rmtsrvname=N'ADSI',@useself=N'False',@locallogin=NULL,@rmtuser=N'<username>',@rmtpassword='########'

GO
EXEC master.dbo.sp_serveroption @server=N'ADSI', @optname=N'collation compatible', @optvalue=N'false'
GO
EXEC master.dbo.sp_serveroption @server=N'ADSI', @optname=N'data access', @optvalue=N'true'
GO
EXEC master.dbo.sp_serveroption @server=N'ADSI', @optname=N'dist', @optvalue=N'false'
GO
EXEC master.dbo.sp_serveroption @server=N'ADSI', @optname=N'pub', @optvalue=N'false'
GO
EXEC master.dbo.sp_serveroption @server=N'ADSI', @optname=N'rpc', @optvalue=N'false'
GO
EXEC master.dbo.sp_serveroption @server=N'ADSI', @optname=N'rpc out', @optvalue=N'false'
GO
EXEC master.dbo.sp_serveroption @server=N'ADSI', @optname=N'sub', @optvalue=N'false'
GO
EXEC master.dbo.sp_serveroption @server=N'ADSI', @optname=N'connect timeout', @optvalue=N'0'
GO
EXEC master.dbo.sp_serveroption @server=N'ADSI', @optname=N'collation name', @optvalue=null
GO
EXEC master.dbo.sp_serveroption @server=N'ADSI', @optname=N'lazy schema validation', @optvalue=N'false'
GO
EXEC master.dbo.sp_serveroption @server=N'ADSI', @optname=N'query timeout', @optvalue=N'0'
GO
EXEC master.dbo.sp_serveroption @server=N'ADSI', @optname=N'use remote collation', @optvalue=N'true'


/****** Object:  UserDefinedFunction [dbo].[udf_bin_me]    Script Date: 02/06/2009 11:38:20 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE FUNCTION [dbo].[udf_bin_me] (@IncomingNumber int)
RETURNS varchar(200)
as
BEGIN

        DECLARE @BinNumber        VARCHAR(200)
        SET @BinNumber = ''

        WHILE @IncomingNumber <> 0
        BEGIN
                SET @BinNumber = SUBSTRING('0123456789', (@IncomingNumber % 2) + 1, 1) + @BinNumber
                SET @IncomingNumber = @IncomingNumber / 2
        END

        RETURN @BinNumber

END 


-- Configure AD Domain to search  
   
DECLARE  @strDC           NVARCHAR(100)  
SET @strDC = '<domain>'  
  
 -- Declare Variables  
   
 DECLARE  @chvAlphaChars   VARCHAR(60),  
          @chvSearch       VARCHAR(10),  
          @chvSearchLevel1 VARCHAR(1),  
          @chvSearchLevel2 VARCHAR(1),  
          @chvSearchLevel3 VARCHAR(1),  
          @intcountLevel1  INT,  
          @intcountLevel2  INT,  
          @intcountLevel3  INT,  
           @intRowCount     INT,  
          @strSQL          NVARCHAR(4000),  
          @strADSISQL      NVARCHAR(4000),  
    @Login     VARBINARY(85),  
    @CN     VARCHAR(512),  
    @CT     INT,  
    @ADRoot    VARCHAR(255)  
   
                       
   
 -- POPULATION OF USERS  
   
 -- Search letters to cycle through               
 -- any chars, but the first char must be a space  
 SET @chvAlphaChars = ' ABCDEFGHIJKLMNOPQRSTUVWXYZ'  
 SET NOCOUNT ON  
   
 -- start on non space char  
 SET @intcountLevel1 = 2  
 -- first level loop  
 WHILE @intcountLevel1 <= LEN(@chvAlphaChars)  
   BEGIN  
     -- get first level char  
     SET @chvSearchLevel1 = SUBSTRING(@chvAlphaChars,@intcountLevel1,1)                             
     -- reset start on space  
     SET @intcountLevel2 = 2                            
     -- second level loop  
     WHILE @intcountLevel2 <= LEN(@chvAlphaChars)  
       BEGIN  
         -- reset start on space  
         SET @intcountLevel3 = 1  
         -- third level loop  
         WHILE @intcountLevel3 <= LEN(@chvAlphaChars)  
           BEGIN  
             -- setup the string to search for. By using the trim function we can form each level depending on no records  
             -- eg A 99, B 1000 > BA 9, BB 20 etc  
             -- trim the spaces forming just A, B, C ; AA, AB for search etc  
             SET @chvSearchLevel1 = SUBSTRING(@chvAlphaChars,@intcountLevel1,1)  
             SET @chvSearchLevel2 = RTRIM(SUBSTRING(@chvAlphaChars,@intcountLevel2,1))  
             SET @chvSearchLevel3 = RTRIM(SUBSTRING(@chvAlphaChars,@intcountLevel3,1))  
    SET @chvSearch = @chvSearchLevel1 + @chvSearchLevel2 + @chvSearchLevel3  
             SET @strADSISQL = 'select objectSid,sAMAccountName, userAccountControl, createTimeStamp '   
        + CHAR(13) + 'from  ''''LDAP://' + @strDC + '''''  '   
        + CHAR(13) + 'where objectCategory = ''''Person''''  '   
        + CHAR(13) + 'and   objectClass = ''''user'''' '   
        + CHAR(13) + 'and   sAMAccountName = ''''' + @chvSearch + '*'''' '                                                                                                                                                                                                                                                                                                                                                                                                        
             SET @strSQL = 'insert into ad_users (sid, sAMAccountName, is_disabled, createTimeStamp) '   
        + CHAR(13) + 'select objectSid, sAMAccountName, substring(dbo.udf_bin_me(userAccountControl),len(dbo.udf_bin_me(userAccountControl))-1,1), createTimeStamp '   
        + CHAR(13) + 'from openquery(ADSI,''' + @strADSISQL + ''' ) '   
        + CHAR(13) + 'order by sAMAccountName'  
               
             EXEC SP_EXECUTESQL @strSQL  
             --print @strSQL
    
             SET @intRowCount = @@ROWCOUNT  
                                  
             -- prints what string is being searched for : no of inserts  
             -- PRINT @chvSearch + ' : ' + CONVERT(VARCHAR,@intRowCount)  
               
             -- if searched on @chvSearchLevel1 and under 1000 then everything is fine so skip search2 to next search1 eg A > B  
             IF @intRowCount < 1000  
                AND @chvSearchLevel2 = ''  
               SET @intcountLevel2 = @intcountLevel2 + 100  
                                                         
             -- if searched on @chvSearchLevel2 and under 1000 then everything is fine so skip to next search2 eg AA > AB  
             IF @intRowCount < 1000  
                AND @chvSearchLevel3 = ''  
               SET @intcountLevel3 = @intcountLevel3 + 100  
                                                         
             -- else over 1000 so increment third level  
             SET @intcountLevel3 = @intcountLevel3 + 1  
           END  
             
         -- increment next second level char  
         SET @intcountLevel2 = @intcountLevel2 + 1  
       END  
         
     -- increment next first level char  
     SET @intcountLevel1 = @intcountLevel1 + 1  
   END  
     
   
 -- POPULATION OF GROUPS  
   
 SET @strADSISQL = 'select objectSid, managedBy, whenChanged, whenCreated, distinguishedName, name, samAccountName '   
        + CHAR(13) + 'FROM ''''LDAP://' + @strDC + '''''  '   
        + CHAR(13) + 'WHERE objectCategory = ''''Group'''' '  
                                                                                                                                                                                                                                                                                                                              
 SET @strSQL  = 'insert into ad_groups (sid,mgr,changeddate,createddate,distname,acctname,login) '   
       + CHAR(13) + 'select objectSid,managedBy,whenChanged,whenCreated,distinguishedName,name,samAccountName '   
       + CHAR(13) + 'from openquery(ADSI,''' + @strADSISQL + ''' ) '   
       + CHAR(13) + 'order by sAMAccountName'  
   
 -- PRINT @strSQL  
 EXEC SP_EXECUTESQL  @strSQL  

  
 -- POPULATION OF USER > GROUPS RELATIONSHIP TABLE  
                    
 IF EXISTS (SELECT *  
            FROM   TEMPDB.DBO.SYSOBJECTS  
            WHERE  ID = OBJECT_ID('tempdb.dbo.#CT'))  
   DROP TABLE #CT  
     
 -- Create a temporary table to hold AD user SID values  
 CREATE TABLE #CT (CT VARBINARY(85))  
   
 -- Declare and open a cursor to step through the list of Active Directory groups  
 DECLARE CURGROUPS CURSOR  FOR  
 SELECT   SID,  
          DISTNAME  
 FROM     ad_groups 
 ORDER BY LOGIN  
   
 OPEN CURGROUPS  
   
 FETCH NEXT FROM CURGROUPS  
 INTO @Login,  
      @CN  
   
 WHILE @@FETCH_STATUS = 0  
   BEGIN  
     -- Empty the temp table  
     TRUNCATE TABLE #CT  
       
     -- Build a SQL statement to insert the SID values directly from the linked server into the temp table  
     SET @strsql = 'INSERT #CT  
     SELECT *  
     FROM OPENQUERY (  
     ADSI,  
     ''SELECT objectSid  
     FROM ''''LDAP://' + @strDC + '''''    
     WHERE memberof=''''' + REPLACE(@CN,'''','''''''''') + ''''''')'  
       print @strsql
     --EXEC( @strsql)  
       
     -- Select the number of records inserted. If this value is less than 1000 then there is no need  
     -- to execute the OLE calls, and we simply copy the values into the correlation table.  
     SELECT @CT = COUNT(* )  
     FROM   #CT  
   
     --PRINT @ct      
     --PRINT @strsql  
       
     IF @CT <> 0  
       BEGIN  
         INSERT ad_usergroups  
               (USERLOGIN,  
                GROUPLOGIN)  
         SELECT CT,  
                @Login  
         FROM   #CT  
         WHERE  CT IS NOT NULL  
       END  
       
     FETCH NEXT FROM CURGROUPS  
     INTO @Login,  
          @CN  
   END  
     
 CURSORERROR:  
 CLOSE CURGROUPS  
 DEALLOCATE CURGROUPS  
 DROP TABLE #CT  
   
 /*  
 -- Individual SQL Statements to see users, groups & relationships  
select * from  ad_users  
select * from  ad_groups  
select * from  ad_UserGroups  
 */  
   
 -- Final Query to tie together the 3 tables and produce a report of group membership  
   
 SELECT ad_groups.ACCTNAME AS GROUPNAME,  
        ad_users.SAMACCOUNTNAME AS USERACCOUNT  
 FROM     ad_usergroups  
          INNER JOIN ad_users  
            ON ad_usergroups.USERLOGIN = ad_users.SID  
          INNER JOIN ad_groups  
            ON ad_usergroups.GROUPLOGIN = ad_groups.SID 
GROUP by  ad_users.SAMACCOUNTNAME, ad_groups.ACCTNAME
 ORDER BY ad_groups.ACCTNAME,  
          ad_users.SAMACCOUNTNAME


select * from ad_users 
where SAMACCOUNTNAME = ''

select SID,SAMACCOUNTNAME,count(*) from ad_users
group by SID,SAMACCOUNTNAME
having count(*) > 1


/*
select objectSid, sAMAccountName,  substring(dbo.udf_bin_me(userAccountControl),len(dbo.udf_bin_me(userAccountControl))-1,1) , createTimeStamp 
from openquery(ADSI,'select objectSid, sAMAccountName, userAccountControl, createTimeStamp 
from  ''<domain>''  
where objectCategory = ''Person''  
and   objectClass = ''user''
' ) 
where substring(dbo.udf_bin_me(userAccountControl),len(dbo.udf_bin_me(userAccountControl))-1,1) = 1
order by sAMAccountName
*/

/************* Incomplete group membership script *******************/
-- Configure AD Domain to search  
   
DECLARE  @strDC           NVARCHAR(100)  
SET @strDC = '<domain>'  
  
 -- Declare Variables  
   
 DECLARE  @strSQL          NVARCHAR(4000),
          @strSQL2          NVARCHAR(4000),  
          @strADSISQL      NVARCHAR(4000),  
			@Login     VARBINARY(85),  
			@CN     VARCHAR(2000),  
			@CT     INT,  
			@ADRoot    VARCHAR(255),
			@nAsciiValue smallint,
			 @nAsciiValue2 smallint,
			 @sChar char(1),
			 @sChar2 char(1),
			 @sChar3 char(4)  
   
IF EXISTS (SELECT *  
            FROM   TEMPDB.DBO.SYSOBJECTS  
            WHERE  ID = OBJECT_ID('tempdb.dbo.#CT'))  
   DROP TABLE #CT  
     
 -- Create a temporary table to hold AD user SID values  
 CREATE TABLE #CT (CT VARBINARY(85))
 
  
 -- Declare and open a cursor to step through the list of Active Directory groups  
 DECLARE CURGROUPS CURSOR  FOR  
 SELECT   SID,  
          DISTNAME  
 FROM     ad_groups 
 ORDER BY LOGIN  
   
 OPEN CURGROUPS  
   
 FETCH NEXT FROM CURGROUPS  
 INTO @Login,  
      @CN  
   
 WHILE @@FETCH_STATUS = 0  
   BEGIN  
     -- Empty the temp table  
     TRUNCATE TABLE #CT 
SELECT @nAsciiValue = 65
SELECT @nAsciiValue2 = 65

WHILE @nAsciiValue < 91
 BEGIN

  SELECT @sChar=  CHAR(@nAsciiValue)
  WHILE @nAsciiValue2 < 91
	BEGIN   
		SELECT @sChar2=  CHAR(@nAsciiValue2)
		
		select @sChar3 = '"'+@sChar+@sChar2+'"'
		select @strSQL2 = 'SELECT * FROM OPENQUERY (ADSI,''SELECT objectSid FROM ''''LDAP://' + @strDC + ''''' WHERE memberof=''''' + REPLACE(@CN,'''','''''''''') + ''''' AND sAMAccountName = ''''%s*'''''');' 

	--print @strSQL2
	--print @schar3
       
     -- Build a SQL statement to insert the SID values directly from the linked server into the temp table  
  EXEC xpSprintF @strSQL OUTPUT, @strSQL2, @sChar3
	
	--INSERT #CT
	--EXEC( @strSQL )
       print @strSQL
     -- Select the number of records inserted. If this value is less than 1000 then there is no need  
     -- to execute the OLE calls, and we simply copy the values into the correlation table.  
     SELECT @CT = COUNT(* )  
     FROM   #CT  
   
     --PRINT @ct      
     --PRINT @strsql  
       
     IF @CT <> 0  
       BEGIN  
         INSERT ad_usergroups  
               (USERLOGIN,  
                GROUPLOGIN)  
         SELECT CT,  
                @Login  
         FROM   #CT  
         WHERE  CT IS NOT NULL  
       END  
	  SELECT @nAsciiValue2 = @nAsciiValue2 + 1	
	END
  SELECT @nAsciiValue2 = 65
  SELECT @nAsciiValue = @nAsciiValue + 1
 END
       
     FETCH NEXT FROM CURGROUPS  
     INTO @Login,  
          @CN  
   END  
     
 CURSORERROR:  
 CLOSE CURGROUPS  
 DEALLOCATE CURGROUPS  
 DROP TABLE #CT  