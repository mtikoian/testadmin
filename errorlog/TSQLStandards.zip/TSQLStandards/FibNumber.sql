CREATE FUNCTION dbo.FibNumber
        (@End INT)
RETURNS TABLE WITH SCHEMABINDING AS
 RETURN 
   WITH 
      R3(N) AS (SELECT 1 UNION ALL SELECT 1 UNION ALL SELECT 1),
     R81(N) AS (SELECT 1 FROM R3 a, R3 b, R3 c, R3 d),
cteTally(N) AS (SELECT TOP (@End) ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) FROM R81)
     SELECT t.N, 
            FibNumber = CAST((1/SQRT(5))*(POWER((1+SQRT(5))/2,t.N)-POWER((1-SQRT(5))/2,t.N)) AS BIGINT)
       FROM cteTally t
      WHERE 1 = CASE 
                WHEN @End BETWEEN 1 AND 70 
                THEN 1 
                ELSE 1/'[Error: Parameter of FibNumber greater than 70]' 
                END
;

 --SELECT * FROM dbo.FibNumber(20);