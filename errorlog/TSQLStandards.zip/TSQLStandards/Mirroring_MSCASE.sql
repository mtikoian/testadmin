***** Case Id: SRX070913600723
*****   Title: 9.00.3042/DBM/Setting up Database mirroring on a Workgroup
*****   Owner: sudarn
*****   Status: Closed
*****   Severity: D - Monitor
*****   Priority: Not Applicable
***** Dynamic History Generated on 21-Sep-2007 00:46:41 India Standard Time
***** Sorted Ascending
***** Listing:  Phone, Note, Research, Email, Exchange and All Other Logs 


***** Create created by v_2frehe on 13-Sep-2007 21:33:59 India Standard Time

***** Set Product created by v_2frehe on 13-Sep-2007 21:52:46 India Standard Time

***** Set Support Program created by v_2frehe on 13-Sep-2007 21:52:46 India Standard Time

***** Log #1
***** Phone Log created by v_2frehe on 13-Sep-2007 21:54:24 India Standard Time

Case created by : PARTNERS\v-2frehe
============================================
Eligibility : Agreement  Access Id:  001246463
Eligible Product : SQL Svr Standard Edtn 2005 EN
Problem Product : SQL Svr Standard Edtn 2005 EN
Transfer Code : 83662 / 2002425 (OneCall)
Dispatch to Queue : SQL-Public

Customer Problem Description
============================================

Product/Version/Service Pack: SQL Server 2005 SP2
OS/Service Pack: Windows Server 2003 Standard Sp2
sev B

bus. impact:  web applic is down and they are trying to migrate it; it is causing an interruption in service for end users 


trying to establish  mirroring  between two databases through a private network 






***** Dispatch created by v_2frehe on 13-Sep-2007 21:54:42 India Standard Time

***** Log #2
***** Phone Log created by v_2frehe on 13-Sep-2007 21:55:36 India Standard Time

Carlos will call back in later to work on this issue


***** Yanked created by a_kestev on 14-Sep-2007 00:02:03 India Standard Time

***** Modify created by a_kestev on 14-Sep-2007 00:04:03 India Standard Time

***** Log #3
***** Phone Log created by a_kestev on 14-Sep-2007 01:01:09 India Standard Time

Carlos is utilizing the SQL user interface to establish database mirroring
database servers are in a workgroup
An error results requesting FQDN

determined that SQL Server Data Engine group supports Mirroring
calling DE team


***** Initial Response created by systrig on 14-Sep-2007 01:01:13 India Standard Time

***** Log #4
***** Phone Log created by a_kestev on 14-Sep-2007 01:45:35 India Standard Time

engaged sudarn - dropping off call


***** Chg Status created by a_kestev on 14-Sep-2007 05:10:37 India Standard Time

***** Modify created by a_kestev on 14-Sep-2007 05:10:57 India Standard Time

***** Yanked created by sudarn on 14-Sep-2007 05:32:16 India Standard Time

***** Log #5
***** Phone Log created by sudarn on 14-Sep-2007 06:27:36 India Standard Time

[PRO SOAP] http://prosoap

Customer Name:	Carlos Caneja
Case Number:	SRX070913600723
Phone Number:	5618869402
Customer Email:	carlosc@appliedi.net
Data Share:		

S: (Subjective)
===============
Trying to setup Database Mirroring to work in a Workgroup.


O: (Objective)[Environment]
===========================
PRODUCT VERSION AND SERVICE RELEASES
Windows 2003
Service Pack 1

 ROLES:
 SQL,

SQL Version: SQL2005 Standard Edition 
SQL Service Pack: 2 
SQL Build: 3042
SQL Platform: x86 
SQL Server Name: 
SQL Instance Name: 
  SQL Type: 


OTHER Info: 


A: (Assessment)
==============
DS2246 - Principal Server
DS2247 - Mirror Server

DS2246\SQLEXPRESS - Witness Server.

-> the main aim is to get DBM setup on a workgroup.
-> Since there is no FQDN, we cannot do the setup through the GUI
-> this was what the Cx was trying to do.

-> Checked if it was possible to have a witness on the same server, it was !
-> Cx was trying to setup DBM from GUI. i first removed the DBM to make sure we keep it clean.

-> Followed SOX070612700002 to setup the DBM.
{
1. Logged in to both box as local Admin.

2. Change SQL Server startup account to use "Network Service" Or �Local System Account�

3. Add NT AUTHORITY\NETWORK SERVICE to the admin group for both servers

4. On server A ( Principal server ) execute the following

It will Configure Outbound Connections

-- CREATE MASTER KEY ENCRYPTION BY PASSWORD = 'Password!';
GO

-- USE master
CREATE CERTIFICATE HOST_A_cert 
WITH SUBJECT = 'HOST_A certificate',
START_DATE = '04/10/2007'
GO

-- CREATE ENDPOINT Endpoint_Mirroring
STATE = STARTED
AS TCP ( LISTENER_PORT=5022, LISTENER_IP = ALL) 
FOR DATABASE_MIRRORING ( 
AUTHENTICATION = CERTIFICATE HOST_A_cert
, ENCRYPTION = REQUIRED ALGORITHM RC4
, ROLE = ALL
);
GO

BACKUP CERTIFICATE HOST_A_cert TO FILE = 'C:\HOST_A_cert.cer';
GO

5. Now copy HOST_A_cert.cer to server B (C:\HOST_A_cert.cer)
Copy HOST_A_cert.cer to server C (C:\HOST_A_cert.cer)
6. On server B (Mirror server) Execute the following

It will Configure Outbound Connections

USE master;
CREATE MASTER KEY ENCRYPTION BY PASSWORD = '<Strong_Password_#2>';
GO

CREATE CERTIFICATE HOST_B_cert 
WITH SUBJECT = 'HOST_B certificate for database mirroring',
START_DATE ='05/10/2007'
GO

CREATE ENDPOINT Endpoint_Mirroring
STATE = STARTED
AS TCP (
LISTENER_PORT=5022
, LISTENER_IP = ALL
) 
FOR DATABASE_MIRRORING ( 
AUTHENTICATION = CERTIFICATE HOST_B_cert
, ENCRYPTION = REQUIRED ALGORITHM RC4
, ROLE = ALL
);
GO


BACKUP CERTIFICATE HOST_B_cert TO FILE = 'C:\HOST_B_cert.cer';
GO 

7. Now copy HOST_B_cert.cer to server A (C:\HOST_B_cert.cer)
Copy HOST_A_cert.cer to server C (C:\HOST_A_cert.cer)


8. On server A ( Principal server ) Execute the following

It will Configure Inbound Connections

USE master;
CREATE LOGIN HOST_B_login WITH PASSWORD = '1Sample_Strong_Password!@#';
GO

CREATE USER HOST_B_user FOR LOGIN HOST_B_login;
GO
--Associate the certificate with the user.

CREATE CERTIFICATE HOST_B_cert
AUTHORIZATION HOST_B_user
FROM FILE = 'C:\HOST_B_cert.cer'
GO

GRANT CONNECT ON ENDPOINT::Endpoint_Mirroring TO [HOST_B_login];
GO

--Do it after completing Step 10 & Step 11
{
USE master;
CREATE LOGIN HOST_C_login WITH PASSWORD = '1Sample_Strong_Password!@#';
GO

CREATE USER HOST_C_user FOR LOGIN HOST_C_login;
GO
--Associate the certificate with the user.

CREATE CERTIFICATE HOST_C_cert
AUTHORIZATION HOST_C_user
FROM FILE = 'C:\HOST_C_cert.cer'
GO

GRANT CONNECT ON ENDPOINT::Endpoint_Mirroring TO [HOST_C_login];
GO
}
------

9. On server B ( Mirror server ) Execute the following

It will Configure Inbound Connections

USE master;
CREATE LOGIN HOST_A_login WITH PASSWORD = '=Sample#2_Strong_Password2';
GO

CREATE USER HOST_A_user FOR LOGIN HOST_A_login;
GO
--Associate the certificate with the user.

CREATE CERTIFICATE HOST_A_cert
AUTHORIZATION HOST_A_user
FROM FILE = 'C:\HOST_A_cert.cer'
GO

GRANT CONNECT ON ENDPOINT::Endpoint_Mirroring TO [HOST_A_login];
GO


------------Do it after completing Step 10 & Step 11
{
USE master;
CREATE LOGIN HOST_C_login WITH PASSWORD = '1Sample_Strong_Password!@#';
GO

CREATE USER HOST_C_user FOR LOGIN HOST_C_login;
GO
--Associate the certificate with the user.

CREATE CERTIFICATE HOST_C_cert
AUTHORIZATION HOST_C_user
FROM FILE = 'C:\HOST_C_cert.cer'
GO

GRANT CONNECT ON ENDPOINT::Endpoint_Mirroring TO [HOST_C_login];
GO
}

10.On server C ( Witness server ) execute the following

It will Configure Outbound Connections

CREATE MASTER KEY ENCRYPTION BY PASSWORD = 'Password!';
GO

USE master
CREATE CERTIFICATE HOST_C_cert 
WITH SUBJECT = 'HOST_C certificate',
START_DATE = '04/10/2007'
GO

-- CREATE ENDPOINT Endpoint_Mirroring
STATE = STARTED
AS TCP ( LISTENER_PORT=5022, LISTENER_IP = ALL) 
FOR DATABASE_MIRRORING ( 
AUTHENTICATION = CERTIFICATE HOST_C_cert
, ENCRYPTION = REQUIRED ALGORITHM RC4
, ROLE = Witness
);
GO

BACKUP CERTIFICATE HOST_C_cert TO FILE = 'C:\HOST_C_cert.cer';
GO

11. Now copy HOST_C_cert.cer to server B (C:\HOST_C_cert.cer)
Copy HOST_C_cert.cer to server A (C:\HOST_C_cert.cer)
12.On server C ( Witness server ) Execute the following

It will Configure Inbound Connections

USE master;
CREATE LOGIN HOST_A_login WITH PASSWORD = '1Sample_Strong_Password!@#';
GO

CREATE USER HOST_A_user FOR LOGIN HOST_B_login;
GO
--Associate the certificate with the user.

CREATE CERTIFICATE HOST_A_cert
AUTHORIZATION HOST_A_user
FROM FILE = 'C:\HOST_A_cert.cer'
GO

GRANT CONNECT ON ENDPOINT::Endpoint_Mirroring TO [HOST_A_login];
GO

On server C ( Witness server ) Execute the following

It will Configure Inbound Connections

USE master;
CREATE LOGIN HOST_B_login WITH PASSWORD = '1Sample_Strong_Password!@#';
GO

CREATE USER HOST_B_user FOR LOGIN HOST_B_login;
GO
--Associate the certificate with the user.

CREATE CERTIFICATE HOST_B_cert
AUTHORIZATION HOST_B_user
FROM FILE = 'C:\HOST_B_cert.cer'
GO

GRANT CONNECT ON ENDPOINT::Endpoint_Mirroring TO [HOST_B_login];
GO

10. Take a Full & Transaction log Backup of the Database (on Principal) 
and Restore on Mirror With NoRecovery.

11. On Mirror Server B Execute :

Alter Database <DB_Name>
Set Partner =�TCP://<ServerName>:5022�
Go

12. On Principal Server A Execute :

Alter Database <DB_Name>
Set Partner =�TCP://<ServerName>:5022�
Go
13. On Principal Server A Execute :

Alter Database <DB_Name>
Set Witness=�TCP://<ServerName>:5022�
Go

-> we ran into a problem while running alter database to set the WITNESS.
-> the port number was already in use.
-> since this witness also was on the same server, it was a problem.
-> Re-cleaned everything up to try from beginning.
-> dropped the endpoints, users, logins and certificates and the master key.
-> followed the same steps again, except these :-

create endpoint on witness_Server , i gave the tcp port as 5023
Alter Database <DB_Name>
Set Witness=�TCP://<ServerName>:5023�
Go

-> this worked fine and the DBM was setup fine
-> we tried to do the automatic failover to get this to work,
-> stopped the prinicpal instance and the mirror did not take over.
-> from the mirror server errorlog :-

"Error:1438 , severity: 16, state: 2"

-> cx wanted to leave at this point.
-> will continue this case tomorrow.


P: (Plan)
==============
Work with the Cx tomorrow to continue the troubleshooting.




***** Consulting Log created by kartika on 14-Sep-2007 06:27:44 India Standard Time

***** Consulting Log created by hemantsi on 14-Sep-2007 06:27:44 India Standard Time

***** Chg Status created by sudarn on 14-Sep-2007 06:27:52 India Standard Time

***** Modify created by sudarn on 14-Sep-2007 06:29:08 India Standard Time

***** Research Note created by sudarn on 15-Sep-2007 08:14:02 India Standard Time

Update
======

-> Setup a live meeting session.
-> Stopped the SQL server on both principal and Mirror and witness servers.
-> restarted all the 3 back.
-> we did the manual failover from the management studio
-> this worked and the mirror assumed the principal role
-> we stopped the mirror server and the failover happened automatically
-> So DBM was setup properly
-> Cx wanted to make this private network
-> he updated the lmhosts file and after this also DBM worked fine.
-> Cx had some Q's on DBM and answered them
-> Cx wanted to test this for a day/two
-> will callback and monday and close the case


***** Consulting Log created by dinm on 15-Sep-2007 08:14:12 India Standard Time

***** Chg Status created by sudarn on 15-Sep-2007 08:15:01 India Standard Time

***** Modify created by sudarn on 15-Sep-2007 08:15:25 India Standard Time

***** Severity created by sudarn on 15-Sep-2007 08:15:27 India Standard Time

***** Research Note created by sudarn on 17-Sep-2007 23:19:43 India Standard Time

-> spoke to the cx and everything was working fine
-> Customer's cx hasnt got back yet
-> told cx that we can archive it. he agreed.
-> will send archival email soon.


***** Research Note created by sudarn on 17-Sep-2007 23:43:54 India Standard Time

*** Case Archive ***

<EMAIL OUT>
From: Sudarshan Narasimhan
Sent: 9/17/2007 11:42:20 PM
To: 'Carlos Caneja'
CC: Harish Ravi
Subject: MS SRX070913600723 - Case ARCHIVE !
 
Hi Carlos,
 
It was my pleasure to serve you during your SQL Server issue. I hope that you were delighted with the service provided to you. 
 
I am delighted that we were able to get the Database Mirroring working on your workgroup. I hope you were able to get an understanding of DB Mirroring through this case.
 
I am providing you with a summary of the key points of the case for your records as well as the Detailed Steps to implement DBM on a workgroup. If you ever have any questions please feel free to call me. My contact information is below.
 
Thank you for choosing Microsoft.
 
 
PROBLEM
=========
Trying to setup Database Mirroring to work in a Workgroup including the Witness Server.
 
Environment
==========
DS2246 - Principal Server
DS2247 - Mirror Server
DS2246\SQLEXPRESS - Witness Server.

�  Since there is no FQDN, we cannot do the setup through the GUI
 
Things to keep in mind :
===================
1. The Database has to restored on the mirror server with the NORECOVERY option.
2. If setting up witness server on the same server, use a Different Port Number for the the endpoints.
3. If on a workgroup, edit the lmhosts file to add the entry.
 
STEPS TO FOLLOW :-
=================
1. Log in to both boxes as local Admin.
2. Change SQL Server startup account to use "Network Service" Or �Local System Account�
3. Add NT AUTHORITY\NETWORK SERVICE to the admin group for both servers
 
4. On server A ( Principal server ) execute the following
 
It will Configure Outbound Connections
 
-- CREATE MASTER KEY ENCRYPTION BY PASSWORD = 'Password!';
GO
 
-- USE master
CREATE CERTIFICATE HOST_A_cert 
WITH SUBJECT = 'HOST_A certificate',
START_DATE = '04/10/2007'
GO
 
-- CREATE ENDPOINT Endpoint_Mirroring
STATE = STARTED
AS TCP ( LISTENER_PORT=5022, LISTENER_IP = ALL) 
FOR DATABASE_MIRRORING ( 
AUTHENTICATION = CERTIFICATE HOST_A_cert
, ENCRYPTION = REQUIRED ALGORITHM RC4
, ROLE = ALL
);
GO
 
BACKUP CERTIFICATE HOST_A_cert TO FILE = 'C:\HOST_A_cert.cer';
GO
 
5. Now copy HOST_A_cert.cer to server B (C:\HOST_A_cert.cer) and Copy HOST_A_cert.cer to server C (C:\HOST_A_cert.cer)
 
6. On server B (Mirror server) Execute the following
 
It will Configure Outbound Connections
 
USE master;
CREATE MASTER KEY ENCRYPTION BY PASSWORD = '<Strong_Password_#2>';
GO
 
CREATE CERTIFICATE HOST_B_cert 
WITH SUBJECT = 'HOST_B certificate for database mirroring',
START_DATE ='05/10/2007'
GO
 
CREATE ENDPOINT Endpoint_Mirroring
STATE = STARTED
AS TCP (
LISTENER_PORT=5022
, LISTENER_IP = ALL
) 
FOR DATABASE_MIRRORING ( 
AUTHENTICATION = CERTIFICATE HOST_B_cert
, ENCRYPTION = REQUIRED ALGORITHM RC4
, ROLE = ALL
);
GO
 
BACKUP CERTIFICATE HOST_B_cert TO FILE = 'C:\HOST_B_cert.cer';
GO 
 
7. Now copy HOST_B_cert.cer to server A (C:\HOST_B_cert.cer) and Copy HOST_A_cert.cer to server C (C:\HOST_A_cert.cer)
 
8. On server A ( Principal server ) Execute the following
 
It will Configure Inbound Connections
 
USE master;
CREATE LOGIN HOST_B_login WITH PASSWORD = '1Sample_Strong_Password!@#';
GO
 
CREATE USER HOST_B_user FOR LOGIN HOST_B_login;
GO
--Associate the certificate with the user.
 
CREATE CERTIFICATE HOST_B_cert
AUTHORIZATION HOST_B_user
FROM FILE = 'C:\HOST_B_cert.cer'
GO
 
GRANT CONNECT ON ENDPOINT::Endpoint_Mirroring TO [HOST_B_login];
GO
 
9. On server B ( Mirror server ) Execute the following
 
It will Configure Inbound Connections
 
USE master;
CREATE LOGIN HOST_A_login WITH PASSWORD = '=Sample#2_Strong_Password2';
GO
 
CREATE USER HOST_A_user FOR LOGIN HOST_A_login;
GO
--Associate the certificate with the user.
 
CREATE CERTIFICATE HOST_A_cert
AUTHORIZATION HOST_A_user
FROM FILE = 'C:\HOST_A_cert.cer'
GO
 
GRANT CONNECT ON ENDPOINT::Endpoint_Mirroring TO [HOST_A_login];
GO
 
 
10.On server C ( Witness server ) execute the following
 
It will Configure Outbound Connections
 
CREATE MASTER KEY ENCRYPTION BY PASSWORD = 'Password!';
GO
 
USE master
CREATE CERTIFICATE HOST_C_cert 
WITH SUBJECT = 'HOST_C certificate',
START_DATE = '04/10/2007'
GO
 
-- CREATE ENDPOINT Endpoint_Mirroring
STATE = STARTED
AS TCP ( LISTENER_PORT=5023, LISTENER_IP = ALL) 
FOR DATABASE_MIRRORING ( 
AUTHENTICATION = CERTIFICATE HOST_C_cert
, ENCRYPTION = REQUIRED ALGORITHM RC4
, ROLE = Witness
);
GO
 
BACKUP CERTIFICATE HOST_C_cert TO FILE = 'C:\HOST_C_cert.cer';
GO
 
11. Now copy HOST_C_cert.cer to server B (C:\HOST_C_cert.cer) and Copy HOST_C_cert.cer to server A (C:\HOST_C_cert.cer)
 
12.  Execute the following  steps one by one �
On Principal Server
{
USE master;
CREATE LOGIN HOST_C_login WITH PASSWORD = '1Sample_Strong_Password!@#';
GO
 
CREATE USER HOST_C_user FOR LOGIN HOST_C_login;
GO
--Associate the certificate with the user.
 
CREATE CERTIFICATE HOST_C_cert
AUTHORIZATION HOST_C_user
FROM FILE = 'C:\HOST_C_cert.cer'
GO
 
GRANT CONNECT ON ENDPOINT::Endpoint_Mirroring TO [HOST_C_login];
GO
}
--
 
On Mirror Server
 
{
USE master;
CREATE LOGIN HOST_C_login WITH PASSWORD = '1Sample_Strong_Password!@#';
GO
 
CREATE USER HOST_C_user FOR LOGIN HOST_C_login;
GO
--Associate the certificate with the user.
 
CREATE CERTIFICATE HOST_C_cert
AUTHORIZATION HOST_C_user
FROM FILE = 'C:\HOST_C_cert.cer'
GO
 
GRANT CONNECT ON ENDPOINT::Endpoint_Mirroring TO [HOST_C_login];
GO
}
---
 
13.On server C ( Witness server ) Execute the following
 
It will Configure Inbound Connections
 
USE master;
CREATE LOGIN HOST_A_login WITH PASSWORD = '1Sample_Strong_Password!@#';
GO
 
CREATE USER HOST_A_user FOR LOGIN HOST_B_login;
GO
--Associate the certificate with the user.
 
CREATE CERTIFICATE HOST_A_cert
AUTHORIZATION HOST_A_user
FROM FILE = 'C:\HOST_A_cert.cer'
GO
 
GRANT CONNECT ON ENDPOINT::Endpoint_Mirroring TO [HOST_A_login];
GO
 
On server C ( Witness server ) Execute the following
 
It will Configure Inbound Connections
 
USE master;
CREATE LOGIN HOST_B_login WITH PASSWORD = '1Sample_Strong_Password!@#';
GO
 
CREATE USER HOST_B_user FOR LOGIN HOST_B_login;
GO
--Associate the certificate with the user.
 
CREATE CERTIFICATE HOST_B_cert
AUTHORIZATION HOST_B_user
FROM FILE = 'C:\HOST_B_cert.cer'
GO
 
GRANT CONNECT ON ENDPOINT::Endpoint_Mirroring TO [HOST_B_login];
GO
 
14. Take a Full & Transaction log Backup of the Database (on Principal) and Restore on Mirror With NoRecovery.
 
15. On Mirror Server B Execute :
 
Alter Database <DB_Name>
Set Partner =�TCP://<ServerName>:5022�
Go
 
16. On Principal Server A Execute :
 
Alter Database <DB_Name>
Set Partner =�TCP://<ServerName>:5022�
Go
13. On Principal Server A Execute :
 
Alter Database <DB_Name>
Set Witness=�TCP://<ServerName>:5023�
Go
 
� Test the DBM works, by shutting down the service on principal. Once we did this this mirror assumed the role of the principal.
� Automatic Failover will happen only if we have a witness server. Otherwise manual failover will have to be done.
 
 
RESOLUTION
============
We setup the database mirroring on a workgroup including the witness server following the above steps.
 
 
USEFUL KNOWLEDGE BASE ARTICLES
===================================
Example: Setting Up Database Mirroring Using Certificates (Transact-SQL)
http://msdn2.microsoft.com/en-us/library/ms191140.aspx
 
Monitoring Mirroring Status
http://msdn2.microsoft.com/en-us/library/ms365781.aspx
 
 Using Database Mirroring
http://msdn2.microsoft.com/en-us/library/ms131373.aspx
 
Connecting Clients to a Mirrored Database
http://msdn2.microsoft.com/en-us/library/ms175484.aspx
 
 sys.database_mirroring 
This view displays the database mirroring metadata for each mirrored database in a server instance. For more information, see sys.database_mirroring.
 
 sys.database_mirroring_endpoints 
The sys.database_mirroring_endpoints catalog view displays information about the database mirroring endpoint of the server instance. 
 
 sys.database_mirroring_witnesses 
This catalog view displays the database mirroring metadata for each session in which a server instance is the witness. 
 
 sys.dm_db_mirroring_connections
This a dynamic management view returns a row for each database mirroring network connection.
 
HYPERLINK "http://blogs.msdn.com/sharepoint/default.aspx"Microsoft SharePoint Products and Technologies Team Blog
 http://blogs.msdn.com/sharepoint/archive/2007/03/06/configuring-database-mirroring-failover-for-sharepoint-products-technologies.aspx
 
 
 
Thanks for your time and Patience in this matter.
 
Best  Regards,
Sudarshan N

</EMAIL OUT>


***** Case Close created by sudarn on 18-Sep-2007 00:19:09 India Standard Time

***** Dec Units : created by systrig on 18-Sep-2007 00:19:13 India Standard Time
