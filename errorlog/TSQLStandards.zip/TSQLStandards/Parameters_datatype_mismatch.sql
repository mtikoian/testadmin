;WITH userParameter AS  
( SELECT 
  c.NAME AS ParameterName,
  OBJECT_SCHEMA_NAME(c.object_ID) + '.' + OBJECT_NAME(c.object_ID) AS ObjectName,
  t.name + ' ' 
    + CASE 
    --we may have to put in the length   
         WHEN t.name IN ('char', 'varchar', 'nchar', 'nvarchar')
             THEN '(' 
              + CASE WHEN c.max_length = -1 THEN 'MAX'
                ELSE CONVERT(VARCHAR(4),
                    CASE WHEN t.name IN ('nchar', 'nvarchar')
                      THEN c.max_length / 2 ELSE c.max_length
                    END)
                END + ')'
         WHEN t.name IN ('decimal', 'numeric')
             THEN '(' + CONVERT(VARCHAR(4), c.precision) 
                  + ',' + CONVERT(VARCHAR(4), c.Scale) + ')'
         ELSE ''
      END  --we've done with putting in the length
      + CASE WHEN XML_collection_ID <> 0
         THEN --deal with object schema names
             '(' + CASE WHEN is_XML_Document = 1
                    THEN 'DOCUMENT '
                    ELSE 'CONTENT '
                   END 
             + COALESCE(
               (SELECT QUOTENAME(ss.name) + '.' + QUOTENAME(sc.name)
                FROM sys.xml_schema_collections sc
                INNER JOIN Sys.Schemas ss ON sc.schema_ID = ss.schema_ID
                WHERE sc.xml_collection_ID = c.XML_collection_ID),'NULL') + ')'
          ELSE ''
         END 
       AS [DataType]
  FROM sys.parameters c
  INNER JOIN sys.types t ON c.user_Type_ID = t.user_Type_ID
  WHERE OBJECT_SCHEMA_NAME(c.object_ID) <> 'sys'
   AND parameter_id>0)
SELECT CONVERT(CHAR(80),objectName+'.'+ParameterName),DataType FROM UserParameter
WHERE ParameterName IN 
  (SELECT ParameterName FROM UserParameter 
   GROUP BY ParameterName 
   HAVING MIN(Datatype)<>MAX(DataType))
ORDER BY ParameterName  