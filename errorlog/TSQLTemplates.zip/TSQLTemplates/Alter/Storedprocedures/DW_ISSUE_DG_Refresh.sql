use netikdp
go 

EXECUTE sp_refreshview N'dbo.DW_ISSUE_DG';
go