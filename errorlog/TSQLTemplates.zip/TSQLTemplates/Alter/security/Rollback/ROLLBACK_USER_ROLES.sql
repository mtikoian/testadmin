--Author name: PJoshi
--Date of origination: 12/04/2012
--Description of object: ROLLBACK of USER and ROLES
--Purpose of object: ROLLBACK of USER and ROLES 

USE $(DBName) 
GO

IF EXISTS (SELECT 1 FROM SYS.DATABASE_PRINCIPALS WHERE NAME = N'CRMRepUser')
	DROP USER CRMRepUser
GO

IF EXISTS (SELECT 1 FROM SYS.DATABASE_PRINCIPALS WHERE NAME = N'urole_SEI_Investments_MSCRM' AND TYPE = 'R')
	DROP ROLE urole_SEI_Investments_MSCRM
GO

IF EXISTS (SELECT 1 FROM SYS.DATABASE_PRINCIPALS WHERE NAME = N'prole_SEI_Investments_MSCRM' AND TYPE = 'R')
	DROP ROLE prole_SEI_Investments_MSCRM
GO



