

/****** Object:  MessageType [//DBA/DataCollector/MonitorDBMSSQLAgentRunningRequest]    Script Date: 06/09/2012 22:23:45 ******/
CREATE MESSAGE TYPE [//DBA/DataCollector/MonitorDBMSSQLAgentRunningRequest] AUTHORIZATION [dbo] VALIDATION = NONE
GO

/****** Object:  MessageType [//DBA/DataCollector/MonitorDBMSSQLConnectionRequest]    Script Date: 06/09/2012 22:23:45 ******/
CREATE MESSAGE TYPE [//DBA/DataCollector/MonitorDBMSSQLConnectionRequest] AUTHORIZATION [dbo] VALIDATION = NONE
GO

/****** Object:  MessageType [//DBA/DataCollector/MonitorServerPingRequest]    Script Date: 06/09/2012 22:23:46 ******/
CREATE MESSAGE TYPE [//DBA/DataCollector/MonitorServerPingRequest] AUTHORIZATION [dbo] VALIDATION = NONE
GO

/****** Object:  MessageType [//DBA/DataCollector/SQLBackupSummaryRequest]    Script Date: 06/09/2012 22:23:46 ******/
CREATE MESSAGE TYPE [//DBA/DataCollector/SQLBackupSummaryRequest] AUTHORIZATION [dbo] VALIDATION = NONE
GO

/****** Object:  MessageType [//DBA/DataCollector/SQLDBMSConfigurationInfoRequest]    Script Date: 06/09/2012 22:23:46 ******/
CREATE MESSAGE TYPE [//DBA/DataCollector/SQLDBMSConfigurationInfoRequest] AUTHORIZATION [dbo] VALIDATION = NONE
GO

/****** Object:  MessageType [//DBA/DataCollector/SQLDBMSInfoRequest]    Script Date: 06/09/2012 22:23:46 ******/
CREATE MESSAGE TYPE [//DBA/DataCollector/SQLDBMSInfoRequest] AUTHORIZATION [dbo] VALIDATION = NONE
GO

/****** Object:  MessageType [//DBA/DataCollector/SQLDatabaseMirroringInfoRequest]    Script Date: 06/09/2012 22:23:46 ******/
CREATE MESSAGE TYPE [//DBA/DataCollector/SQLDatabaseMirroringInfoRequest] AUTHORIZATION [dbo] VALIDATION = NONE
GO

/****** Object:  MessageType [//DBA/DataCollector/SQLDatabaseOptionsInfoRequest]    Script Date: 06/09/2012 22:23:46 ******/
CREATE MESSAGE TYPE [//DBA/DataCollector/SQLDatabaseOptionsInfoRequest] AUTHORIZATION [dbo] VALIDATION = NONE
GO

/****** Object:  MessageType [//DBA/DataCollector/SQLDatabaseSizeInfoRequest]    Script Date: 06/09/2012 22:23:46 ******/
CREATE MESSAGE TYPE [//DBA/DataCollector/SQLDatabaseSizeInfoRequest] AUTHORIZATION [dbo] VALIDATION = NONE
GO

/****** Object:  MessageType [//DBA/DataCollector/SQLDriveInfoRequest]    Script Date: 06/09/2012 22:23:46 ******/
CREATE MESSAGE TYPE [//DBA/DataCollector/SQLDriveInfoRequest] AUTHORIZATION [dbo] VALIDATION = NONE
GO

/****** Object:  MessageType [//DBA/DataCollector/SQLGuardiumAuditReportRequest]    Script Date: 06/09/2012 22:23:46 ******/
CREATE MESSAGE TYPE [//DBA/DataCollector/SQLGuardiumAuditReportRequest] AUTHORIZATION [dbo] VALIDATION = NONE
GO

/****** Object:  MessageType [//DBA/DataCollector/SQLJobScheduleInfoRequest]    Script Date: 06/09/2012 22:23:46 ******/
CREATE MESSAGE TYPE [//DBA/DataCollector/SQLJobScheduleInfoRequest] AUTHORIZATION [dbo] VALIDATION = NONE
GO

/****** Object:  MessageType [//DBA/DataCollector/SQLJobSummaryRequest]    Script Date: 06/09/2012 22:23:46 ******/
CREATE MESSAGE TYPE [//DBA/DataCollector/SQLJobSummaryRequest] AUTHORIZATION [dbo] VALIDATION = NONE
GO

/****** Object:  MessageType [//DBA/DataCollector/SQLLinkedServerInfoRequest]    Script Date: 06/09/2012 22:23:47 ******/
CREATE MESSAGE TYPE [//DBA/DataCollector/SQLLinkedServerInfoRequest] AUTHORIZATION [dbo] VALIDATION = NONE
GO

/****** Object:  MessageType [//DBA/DataCollector/SQLLogShippingInfoRequest]    Script Date: 06/09/2012 22:23:47 ******/
CREATE MESSAGE TYPE [//DBA/DataCollector/SQLLogShippingInfoRequest] AUTHORIZATION [dbo] VALIDATION = NONE
GO

/****** Object:  MessageType [//DBA/DataCollector/SQLReplicationInfoRequest]    Script Date: 06/09/2012 22:23:47 ******/
CREATE MESSAGE TYPE [//DBA/DataCollector/SQLReplicationInfoRequest] AUTHORIZATION [dbo] VALIDATION = NONE
GO

/****** Object:  MessageType [//DBA/DataCollector/SQLSecuritySummaryRequest]    Script Date: 06/09/2012 22:23:47 ******/
CREATE MESSAGE TYPE [//DBA/DataCollector/SQLSecuritySummaryRequest] AUTHORIZATION [dbo] VALIDATION = NONE
GO

/****** Object:  MessageType [//DBA/DataCollector/SQLServicesInfoRequest]    Script Date: 06/09/2012 22:23:47 ******/
CREATE MESSAGE TYPE [//DBA/DataCollector/SQLServicesInfoRequest] AUTHORIZATION [dbo] VALIDATION = NONE
GO

/****** Object:  MessageType [//DBA/DataCollector/SQLTSMBackupSummaryRequest]    Script Date: 06/09/2012 22:23:47 ******/
CREATE MESSAGE TYPE [//DBA/DataCollector/SQLTSMBackupSummaryRequest] AUTHORIZATION [dbo] VALIDATION = NONE
GO


