﻿CREATE MASTER KEY ENCRYPTION 
    BY PASSWORD = 'v{v|&xTEmwemqcmj8lz!fpjmmsFT7_&#$!~<Lbf|ykacklPe'
