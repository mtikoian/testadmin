﻿CREATE CERTIFICATE [Cert_DBAdmin_ProcSign]
	WITH SUBJECT = 'Certificate Used to Sign DBAdmin Stored Procedures';