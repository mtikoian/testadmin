-- Make sure SQL Agent is running
-- Active Processes Collector job is enabled
-- Wait Stats Collector job is disabled

USE Collectors;
GO

/******************************************************/
/* Let's create some blocking                         */
/******************************************************/

-- Run the wait stats collector (to get a clean starting point)
EXECUTE CollectWaitStats;
GO

-- Run this:
BEGIN TRANSACTION
UPDATE AdventureWorks2012.Sales.SalesOrderHeader
SET DueDate = DATEADD(DAY, 30, DueDate);

-- Go run this in another window:
SELECT * FROM AdventureWorks2012.Sales.SalesOrderHeader;

-- Now run this:
WAITFOR DELAY '00:00:20'
ROLLBACK TRANSACTION

-- Run the wait stats collector (vs waiting for SQL Agent)
EXECUTE CollectWaitStats;

-- What did the Collectors collect?
SELECT *
FROM Collectors.dbo.ActiveProcesses_Log_All
WHERE collection_time > DATEADD(SECOND, -30, GETDATE())
ORDER BY collection_time DESC, [dd hh:mm:ss.mss] DESC;

SELECT *
FROM Collectors.dbo.WaitStats_Log_All
WHERE Collection_Time > DATEADD(SECOND, -30, GETDATE())
ORDER BY Collection_Time DESC, Wait_Seconds DESC;

/******************************************************************/

/******************************************************/
/* Let's create a blocking tree                       */
/******************************************************/

-- Run the wait stats collector (to get a clean starting point)
EXECUTE CollectWaitStats;
GO

-- Create some contention
-- Run batch file CreateBlocking.bat
EXECUTE xp_cmdshell '"C:\Program Files\Microsoft SQL Server\MSSQL11.MSSQLSERVER\MSSQL\DATA\CreateBlocking.bat"'

-- Run the wait stats collector (vs waiting for SQL Agent)
EXECUTE CollectWaitStats;

-- What did the Collectors collect?
WITH ProcByTime
AS
	(
		SELECT *
		FROM Collectors.dbo.ActiveProcesses_Log_All
		WHERE collection_time >= DATEADD(SECOND, -40, GETDATE())
			AND collection_time < GETDATE()
	),
BlockingCTE
AS
	(
		SELECT blocker_level = 1, *
		FROM ProcByTime
		WHERE blocking_session_id IS NULL
		UNION ALL
		SELECT blocker_level = BlockingCTE.blocker_level + 1, ProcByTime.*
		FROM BlockingCTE
		INNER JOIN ProcByTime
			ON BlockingCTE.session_id = ProcByTime.blocking_session_id
				AND BlockingCTE.collection_time = ProcByTime.collection_time
	)
SELECT BlockingCTE.collection_time,BlockingCTE.blocker_level,BlockingCTE.session_id,BlockingCTE.blocking_session_id,BlockingCTE.*
FROM BlockingCTE
WHERE EXISTS(SELECT * FROM BlockingCTE AS victims WHERE victims.collection_time = BlockingCTE.collection_time AND victims.blocking_session_id = BlockingCTE.session_id)
OR blocker_level > 1
ORDER BY BlockingCTE.collection_time, BlockingCTE.blocker_level, BlockingCTE.[dd hh:mm:ss.mss] DESC

/******************************************************************/














/******************************************************************/
/* Look at some real-world data that I've collected               */
/******************************************************************/

USE Collectors_Demo_OLTP;
GO

-- What queries have caused blocking?
SELECT
	blocked_sessions = (SELECT COUNT(*) FROM ActiveProcesses_Log_All AS victims WHERE victims.collection_time = blockers.collection_time AND victims.blocking_session_id = blockers.session_id),
	blockers.*
FROM ActiveProcesses_Log_All AS blockers
WHERE EXISTS(SELECT * FROM ActiveProcesses_Log_All AS victims WHERE victims.collection_time = blockers.collection_time AND victims.blocking_session_id = blockers.session_id)
ORDER BY blockers.[dd hh:mm:ss.mss] DESC


USE Collectors_Demo_DW;
GO

-- What queries have caused blocking?
SELECT
	blocked_sessions = (SELECT COUNT(*) FROM ActiveProcesses_Log_All AS victims WHERE victims.collection_time = blockers.collection_time AND victims.blocking_session_id = blockers.session_id),
	blockers.*
FROM ActiveProcesses_Log_All AS blockers
WHERE EXISTS(SELECT * FROM ActiveProcesses_Log_All AS victims WHERE victims.collection_time = blockers.collection_time AND victims.blocking_session_id = blockers.session_id)
ORDER BY blockers.[dd hh:mm:ss.mss] DESC


USE Collectors_Demo_Async;
GO

-- What queries have caused blocking?
SELECT
	blocked_sessions = (SELECT COUNT(*) FROM ActiveProcesses_Log_All AS victims WHERE victims.collection_time = blockers.collection_time AND victims.blocking_session_id = blockers.session_id),
	blockers.*
FROM ActiveProcesses_Log_All AS blockers
WHERE EXISTS(SELECT * FROM ActiveProcesses_Log_All AS victims WHERE victims.collection_time = blockers.collection_time AND victims.blocking_session_id = blockers.session_id)
ORDER BY blockers.[dd hh:mm:ss.mss] DESC
