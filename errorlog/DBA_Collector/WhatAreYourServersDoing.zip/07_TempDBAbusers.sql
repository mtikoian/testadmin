-- Make sure SQL Agent is running
-- Active Processes Collector job is enabled
-- Wait Stats Collector job is disabled

USE Collectors;
GO

/******************************************************************/
/* Run a repeated query that writes to a temp table               */
/******************************************************************/

-- Run the wait stats collector (to get a clean starting point)
EXECUTE CollectWaitStats;
GO

-- Run the query multiple times
SELECT * INTO #temp FROM AdventureWorks2012.Sales.SalesOrderDetail;
DROP TABLE #temp;
GO 150

-- Run the wait stats collector (vs waiting for SQL Agent)
EXECUTE CollectWaitStats;

-- What did the Collectors collect?
SELECT *
FROM Collectors.dbo.ActiveProcesses_Log_All
WHERE collection_time > DATEADD(SECOND, -30, GETDATE())
ORDER BY collection_time DESC, [dd hh:mm:ss.mss] DESC;

SELECT *
FROM Collectors.dbo.WaitStats_Log_All
WHERE Collection_Time > DATEADD(SECOND, -30, GETDATE())
ORDER BY Collection_Time DESC, Wait_Seconds DESC;

/******************************************************************/


/******************************************************************/
/* Select a large dataset into a temp table                       */
/******************************************************************/

-- Run the wait stats collector (to get a clean starting point)
EXECUTE CollectWaitStats;

-- Run query (let run for 30 seconds or more)
SELECT TOP 15000000 TransactionHistory.*, ArchiveQuantity = TransactionHistoryArchive.Quantity
INTO #temp
FROM AdventureWorks2012.Production.TransactionHistory
INNER JOIN AdventureWorks2012.Production.TransactionHistoryArchive
	ON TransactionHistory.Quantity = TransactionHistoryArchive.Quantity;
DROP TABLE #temp;

-- Run the wait stats collector (vs waiting for SQL Agent)
EXECUTE CollectWaitStats;

-- What did the Collectors collect?
SELECT *
FROM Collectors.dbo.ActiveProcesses_Log_All
WHERE collection_time > DATEADD(SECOND, -30, GETDATE())
ORDER BY collection_time DESC, [dd hh:mm:ss.mss] DESC;

SELECT *
FROM Collectors.dbo.WaitStats_Log_All
WHERE Collection_Time > DATEADD(SECOND, -30, GETDATE())
ORDER BY Collection_Time DESC, Wait_Seconds DESC;

/******************************************************************/


/******************************************************************/
/* Sort a large dataset                                           */
/******************************************************************/

-- Run the wait stats collector (to get a clean starting point)
EXECUTE CollectWaitStats;

-- Run query (let run for 30 seconds or more)
SELECT *
FROM AdventureWorks2012.Sales.SalesOrderHeader
INNER JOIN (
	SELECT *
	FROM AdventureWorks2012.Sales.SalesOrderDetail
	UNION ALL
	SELECT *
	FROM AdventureWorks2012.Sales.SalesOrderDetail
	UNION ALL
	SELECT *
	FROM AdventureWorks2012.Sales.SalesOrderDetail
	UNION ALL
	SELECT *
	FROM AdventureWorks2012.Sales.SalesOrderDetail
	UNION ALL
	SELECT *
	FROM AdventureWorks2012.Sales.SalesOrderDetail
	UNION ALL
	SELECT *
	FROM AdventureWorks2012.Sales.SalesOrderDetail
	) AS BigSalesOrderDetail
	ON SalesOrderHeader.SalesOrderID = BigSalesOrderDetail.SalesOrderID
WHERE SalesOrderHeader.DueDate > SalesOrderHeader.ShipDate
ORDER BY SalesOrderHeader.OrderDate;

-- Run the wait stats collector (vs waiting for SQL Agent)
EXECUTE CollectWaitStats;

-- What did the Collectors collect?
SELECT *
FROM Collectors.dbo.ActiveProcesses_Log_All
WHERE collection_time > DATEADD(SECOND, -30, GETDATE())
ORDER BY collection_time DESC, [dd hh:mm:ss.mss] DESC;

SELECT *
FROM Collectors.dbo.WaitStats_Log_All
WHERE Collection_Time > DATEADD(SECOND, -30, GETDATE())
ORDER BY Collection_Time DESC, Wait_Seconds DESC;

/******************************************************************/


/******************************************************************/
/* Look at some real-world data that I've collected               */
/******************************************************************/

USE Collectors_Demo_OLTP;
GO

/* What are the worst TEMPDB consumers captured? */
SELECT TOP 10 *
FROM ActiveProcesses_Log_All
ORDER BY tempdb_allocations DESC

/* What did those sessions do? */
SELECT *
FROM ActiveProcesses_Log_All
WHERE session_id = 494
	AND start_time = '2014-08-20 14:05:02.537'
ORDER BY collection_time;


USE Collectors_Demo_DW;
GO

/* What are the worst TEMPDB consumers captured? */
SELECT TOP 10 *
FROM ActiveProcesses_Log_All
ORDER BY tempdb_allocations DESC

/* What did those sessions do? */
SELECT *
FROM ActiveProcesses_Log_All
WHERE session_id = 74
	AND start_time = '2014-08-26 10:44:14.983'
ORDER BY collection_time;


USE Collectors_Demo_Async;
GO

/* What are the worst TEMPDB consumers captured? */
SELECT TOP 10 *
FROM ActiveProcesses_Log_All
ORDER BY tempdb_allocations DESC

/* What did those sessions do? */
SELECT *
FROM ActiveProcesses_Log_All
WHERE session_id = 57
	AND start_time = '2014-09-14 00:00:01.843'
ORDER BY collection_time;
