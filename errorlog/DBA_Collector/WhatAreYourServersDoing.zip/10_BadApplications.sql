-- Make sure SQL Agent is running
-- Active Processes Collector job is enabled
-- Wait Stats Collector job is disabled

USE Collectors;
GO

-- Run the wait stats collector (to get a clean starting point)
EXECUTE CollectWaitStats;
GO

-- Retrieve a resultset row-by-agonizing-row
DECLARE @SalesOrderDetailID INT;

DECLARE SalesOrderDetailCursor CURSOR FOR
	SELECT SalesOrderDetailID
	FROM AdventureWorks2012.Sales.SalesOrderDetail
	ORDER BY SalesOrderDetailID
	OPTION (MAXDOP 1);

OPEN SalesOrderDetailCursor;
FETCH NEXT FROM SalesOrderDetailCursor INTO @SalesOrderDetailID;
WHILE @@FETCH_STATUS = 0
	BEGIN
	PRINT @SalesOrderDetailID;
	FETCH NEXT FROM SalesOrderDetailCursor INTO @SalesOrderDetailID;
	END
CLOSE SalesOrderDetailCursor;
DEALLOCATE SalesOrderDetailCursor;
GO 10

-- Run the wait stats collector (vs waiting for SQL Agent)
EXECUTE CollectWaitStats;

-- What did the Collectors collect?
SELECT *
FROM Collectors.dbo.ActiveProcesses_Log_All
WHERE collection_time > DATEADD(SECOND, -30, GETDATE())
ORDER BY collection_time DESC, [dd hh:mm:ss.mss] DESC;

SELECT *
FROM Collectors.dbo.WaitStats_Log_All
WHERE Collection_Time > DATEADD(SECOND, -30, GETDATE())
ORDER BY Collection_Time DESC, Wait_Seconds DESC;

/******************************************************************/


/******************************************************************/
/* Look at some real-world data that I've collected               */
/******************************************************************/

USE Collectors_Demo_Async;
GO

-- Look at a known problem session
SELECT *
FROM ActiveProcesses_Log_All
WHERE start_time = '2014-09-12 08:22:43.180'
	AND session_id = 63
ORDER BY collection_time

-- Another known problem
SELECT *
FROM ActiveProcesses_Log_All
WHERE start_time = '2014-09-10 12:35:27.477'
	AND session_id = 57
ORDER BY collection_time

-- How many sessions have we captured waiting on ASYNC_NETWORK_IO?
SELECT *
FROM ActiveProcesses_Log_All
WHERE wait_info LIKE '%ASYNC_NETWORK_IO%'

-- Any trends that we can spot?
SELECT *
FROM ActiveProcesses_Log_All
WHERE EXISTS(
	SELECT *
	FROM ActiveProcesses_Log_All AS asn
	WHERE wait_info LIKE '%ASYNC_NETWORK_IO%'
		AND asn.session_id = ActiveProcesses_Log_All.session_id
		AND asn.start_time = ActiveProcesses_Log_All.start_time
	)
ORDER BY collection_time
