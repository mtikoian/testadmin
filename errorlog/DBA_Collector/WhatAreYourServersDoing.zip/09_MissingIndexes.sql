-- Make sure SQL Agent is running
-- Active Processes Collector job is enabled
-- Wait Stats Collector job is disabled

-- Cleanup from earlier demo
IF EXISTS(SELECT * FROM AdventureWorks2012.sys.indexes WHERE name = 'IX_SalesOrderDetail_OrderQty')
	BEGIN
	DECLARE @Command VARCHAR(MAX);
	SET @Command = 'USE AdventureWorks2012;DROP INDEX Sales.SalesOrderDetail.IX_SalesOrderDetail_OrderQty;';
	EXECUTE (@Command);
	END
GO

USE Collectors;
GO

-- Run the wait stats collector (to get a clean starting point)
EXECUTE CollectWaitStats;
GO

-- Run a query repeatedly
DECLARE @Command VARCHAR(MAX);

SET @Command = '
	SELECT OrderQty
	INTO #temp
	FROM AdventureWorks2012.Sales.SalesOrderDetail 
	WHERE OrderQty > 500000 
	ORDER BY OrderQty DESC
	';

EXECUTE (@Command);
GO 5000

-- Run the wait stats collector (vs waiting for SQL Agent)
EXECUTE CollectWaitStats;

-- What did the Collectors collect?
SELECT *
FROM Collectors.dbo.ActiveProcesses_Log_All
WHERE collection_time > DATEADD(SECOND, -30, GETDATE())
ORDER BY collection_time DESC, [dd hh:mm:ss.mss] DESC;

SELECT *
FROM Collectors.dbo.WaitStats_Log_All
WHERE Collection_Time > DATEADD(SECOND, -30, GETDATE())
ORDER BY Collection_Time DESC, Wait_Seconds DESC;

/******************************************************************/

-- We're missing an index, so let's add it
CREATE INDEX IX_SalesOrderDetail_OrderQty ON AdventureWorks2012.Sales.SalesOrderDetail (OrderQty);
GO

-- Run the wait stats collector (to get a clean starting point)
EXECUTE CollectWaitStats;
GO

-- Run a same query repeatedly
DECLARE @Command VARCHAR(MAX);

SET @Command = '
	SELECT OrderQty
	INTO #temp
	FROM AdventureWorks2012.Sales.SalesOrderDetail 
	WHERE OrderQty > 500000 
	ORDER BY OrderQty DESC
	';

EXECUTE (@Command);
GO 5000

-- Run the wait stats collector (vs waiting for SQL Agent)
EXECUTE CollectWaitStats;

-- What did the Collectors collect?
SELECT *
FROM Collectors.dbo.ActiveProcesses_Log_All
WHERE collection_time > DATEADD(SECOND, -30, GETDATE())
ORDER BY collection_time DESC, [dd hh:mm:ss.mss] DESC;

SELECT *
FROM Collectors.dbo.WaitStats_Log_All
WHERE Collection_Time > DATEADD(SECOND, -30, GETDATE())
ORDER BY Collection_Time DESC, Wait_Seconds DESC;

/******************************************************************/

/******************************************************************/
/* Look at some real-world data that I've collected               */
/******************************************************************/

USE Collectors_Demo_OLTP;
GO

-- Latest queries suffering from a missing index
SELECT TOP 500 * 
FROM dbo.ActiveProcesses_Log_All 
WHERE MissingIndex = 1
ORDER BY collection_time DESC

-- Longest-running queries suffering from a missing index
SELECT TOP 500 * 
FROM dbo.ActiveProcesses_Log_All 
WHERE MissingIndex = 1
ORDER BY [dd hh:mm:ss.mss] DESC


USE Collectors_Demo_DW;
GO

-- Latest queries suffering from a missing index
SELECT TOP 500 * 
FROM dbo.ActiveProcesses_Log_All 
WHERE MissingIndex = 1
ORDER BY collection_time DESC

-- Longest-running queries suffering from a missing index
SELECT TOP 500 * 
FROM dbo.ActiveProcesses_Log_All 
WHERE MissingIndex = 1
ORDER BY [dd hh:mm:ss.mss] DESC


USE Collectors_Demo_Async;
GO

-- Latest queries suffering from a missing index
SELECT TOP 500 * 
FROM dbo.ActiveProcesses_Log_All 
WHERE MissingIndex = 1
ORDER BY collection_time DESC

-- Longest-running queries suffering from a missing index
SELECT TOP 500 * 
FROM dbo.ActiveProcesses_Log_All 
WHERE MissingIndex = 1
ORDER BY [dd hh:mm:ss.mss] DESC
