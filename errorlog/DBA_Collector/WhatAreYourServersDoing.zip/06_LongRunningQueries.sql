-- Make sure SQL Agent is running
-- Active Processes Collector job is enabled
-- Wait Stats Collector job is disabled

/******************************************************************/
/* Simulate a long-running process using WAITFOR                  */
/******************************************************************/
USE Collectors;
GO

-- Run the wait stats collector (to get a clean starting point)
EXECUTE CollectWaitStats;

-- Force session to wait for 30 seconds
SELECT GETDATE();
WAITFOR DELAY '00:00:30';
SELECT GETDATE();

-- Run the wait stats collector (vs waiting for SQL Agent)
EXECUTE CollectWaitStats;

-- What did the Collectors collect?
SELECT *
FROM Collectors.dbo.ActiveProcesses_Log_All
WHERE collection_time > DATEADD(SECOND, -30, GETDATE())
ORDER BY collection_time DESC, [dd hh:mm:ss.mss] DESC;

SELECT *
FROM Collectors.dbo.WaitStats_Log_All
WHERE Collection_Time > DATEADD(SECOND, -30, GETDATE())
ORDER BY Collection_Time DESC, Wait_Seconds DESC;

/******************************************************************/


/******************************************************************/
/* Run a long-running query against AdventureWorks                */
/******************************************************************/

-- Run the wait stats collector (to get a clean starting point)
EXECUTE CollectWaitStats;

-- Run query (let run for 30 seconds or more)
SELECT TOP 4000000 *
FROM AdventureWorks2012.Production.TransactionHistory
INNER JOIN AdventureWorks2012.Production.TransactionHistoryArchive
	ON TransactionHistory.Quantity = TransactionHistoryArchive.Quantity;

-- Run the wait stats collector (vs waiting for SQL Agent)
EXECUTE CollectWaitStats;

-- What did the Collectors collect?
SELECT *
FROM Collectors.dbo.ActiveProcesses_Log_All
WHERE collection_time > DATEADD(SECOND, -30, GETDATE())
ORDER BY collection_time DESC, [dd hh:mm:ss.mss] DESC;

SELECT *
FROM Collectors.dbo.WaitStats_Log_All
WHERE Collection_Time > DATEADD(SECOND, -30, GETDATE())
ORDER BY Collection_Time DESC, Wait_Seconds DESC;

/******************************************************************/


/******************************************************************/
/* Look at some real-world data that I've collected               */
/******************************************************************/

USE Collectors_Demo_OLTP;
GO

-- What are the 10 longest running queries that we've collected?
SELECT TOP 10 *
FROM ActiveProcesses_Log_All
WHERE 1=1
	--AND login_name NOT IN ('sys', 'backup', 'srvacct')
	--AND session_id > 50
	--AND CAST(sql_text AS NVARCHAR(MAX)) <> ''
ORDER BY [dd hh:mm:ss.mss] DESC;

-- What was SQL waiting on while these were running?
SELECT TOP 50 *
FROM WaitStats_Log_All
WHERE Collection_Time <= '2014-09-01 16:46'
ORDER BY Collection_Time DESC, Wait_Seconds DESC;

-- What did we wait on the most while query was running?
SELECT WaitType, SUM(Wait_Seconds)
FROM WaitStats_Log_All
WHERE Collection_Time > '2014-09-01 15:45'
	AND Collection_Time <= '2014-09-01 16:46'
GROUP BY WaitType
ORDER BY SUM(Wait_Seconds) DESC;

-- What are the 10 longest running UNIQUE queries that we've collected?
SELECT TOP 10 *
FROM (
	SELECT *, Ranking = ROW_NUMBER() OVER(PARTITION BY session_id, start_time ORDER BY [dd hh:mm:ss.mss] DESC)
	FROM ActiveProcesses_Log_All
WHERE 1=1
	AND login_name NOT IN ('sys', 'backup', 'srvacct')
	AND session_id > 50
	) AS top_rank
WHERE Ranking = 1
ORDER BY [dd hh:mm:ss.mss] DESC;


/******************************************************************/
/* Real-world data from another system                            */
/******************************************************************/

USE Collectors_Demo_DW;
GO

-- What are the 10 longest running queries that we've collected?
SELECT TOP 10 *
FROM ActiveProcesses_Log_All
WHERE 1=1
	AND login_name NOT IN ('sys')
	AND session_id > 50
	AND CAST(sql_text AS NVARCHAR(MAX)) <> ''
ORDER BY [dd hh:mm:ss.mss] DESC;

-- What was SQL waiting on while these were running?
SELECT TOP 50 *
FROM WaitStats_Log_All
WHERE Collection_Time >= '2014-08-08 03:30'
	AND Collection_Time <= '2014-09-01 05:40'
ORDER BY Collection_Time DESC, Wait_Seconds DESC;

-- What did we wait on the most while query was running?
SELECT WaitType, SUM(Wait_Seconds)
FROM WaitStats_Log_All
WHERE Collection_Time >= '2014-08-08 03:30'
	AND Collection_Time <= '2014-09-01 05:40'
GROUP BY WaitType
ORDER BY SUM(Wait_Seconds) DESC;


/******************************************************************/
/* Real-world data from a third system                            */
/******************************************************************/

USE Collectors_Demo_Async;
GO

-- What are the 10 longest running queries that we've collected?
SELECT TOP 10 *
FROM ActiveProcesses_Log_All
WHERE 1=1
	AND login_name NOT IN ('sys', 'backup', 'srvacct')
	AND session_id > 50
	AND program_name NOT IN ('SQLCMD')
	--AND CAST(sql_text AS NVARCHAR(MAX)) <> ''
ORDER BY [dd hh:mm:ss.mss] DESC;

-- What was SQL waiting on while these were running?
SELECT TOP 50 *
FROM WaitStats_Log_All
WHERE Collection_Time >= '2014-09-11 20:15'
	AND Collection_Time <= '2014-09-11 20:46'
ORDER BY Collection_Time DESC, Wait_Seconds DESC;

-- What did we wait on the most while query was running?
SELECT WaitType, SUM(Wait_Seconds)
FROM WaitStats_Log_All
WHERE Collection_Time >= '2014-09-11 20:15'
	AND Collection_Time <= '2014-09-11 20:46'
GROUP BY WaitType
ORDER BY SUM(Wait_Seconds) DESC;
