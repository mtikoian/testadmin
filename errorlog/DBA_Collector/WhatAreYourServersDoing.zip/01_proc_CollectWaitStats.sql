SET NOEXEC OFF;

IF DB_NAME() = 'master'
	BEGIN

	RAISERROR('Do you really want to create this in the ''master'' database?', 16, 1) WITH LOG;
	SET NOEXEC ON;

	END
GO

IF OBJECT_ID('dbo.CollectWaitStats', 'P') IS NOT NULL DROP PROCEDURE dbo.CollectWaitStats;
GO

CREATE PROCEDURE dbo.CollectWaitStats
	@DaysToRetain	INT				= 30
AS
BEGIN

-- Run this stored procedure from a SQL Agent job, recommend 15 minute intervals,
-- to collect wait stats over time

DECLARE @Now DATETIME = GETDATE();
DECLARE @Command VARCHAR(MAX);
DECLARE @NewTableName VARCHAR(255);
DECLARE @DropTableName VARCHAR(255);

SET @NewTableName = 'WaitStats_Log_' + CONVERT(VARCHAR(10), @Now, 112);
IF NOT EXISTS(SELECT * FROM sys.objects WHERE name = @NewTableName)
	BEGIN

	SET @Command = '
	CREATE TABLE dbo.' + @NewTableName + ' 
		(
			Collection_Time		DATETIME		NOT NULL,
			WaitType			VARCHAR(255)	NOT NULL,
			Wait_Seconds		DECIMAL(14,2),
			Resource_Seconds	DECIMAL(14,2),
			Signal_Seconds		DECIMAL(14,2),
			WaitCount			INT,
			Percentage			DECIMAL(5,2),
			AvgWait_Seconds		DECIMAL(14,4),
			AvgResource_Seconds	DECIMAL(14,4),
			AvgSignal_Seconds	DECIMAL(14,4),
			CONSTRAINT PK_' + @NewTableName + ' PRIMARY KEY CLUSTERED (Collection_Time, WaitType),
			CONSTRAINT CK_' + @NewTableName + ' CHECK (Collection_Time >= CAST(''' + CONVERT(VARCHAR(25), DATEADD(DAY, DATEDIFF(DAY, 0, @Now), 0), 102) + ''' AS DATETIME) AND Collection_Time < CAST(''' + CONVERT(VARCHAR(25), DATEADD(DAY, DATEDIFF(DAY, 0, @Now), 1), 102) + ''' AS DATETIME))
		);';
	EXECUTE (@Command);

     -- Drop existing "all" view before dropping old tables
	IF OBJECT_ID('dbo.WaitStats_Log_All', 'V') IS NOT NULL DROP VIEW WaitStats_Log_All;

	-- Remove tables after @DaysToRetain days
	SET @DropTableName = 'WaitStats_Log_' + CONVERT(VARCHAR(10), DATEADD(DAY, -@DaysToRetain, @Now), 112);
     SELECT @Command = STUFF((
		  SELECT ';DROP TABLE dbo.' + name
		  FROM sys.objects
		  WHERE name LIKE 'WaitStats_Log_%'
		    AND type = 'U'
		    AND name <= @DropTableName
		  FOR XML PATH('')), 1, 1, '');
	EXECUTE (@Command);

	END;

-- Create view across all collection tables if it doesn't already exist
IF OBJECT_ID('dbo.WaitStats_Log_All', 'V') IS NULL
    BEGIN

    SELECT @Command = STUFF((
	    SELECT ';SELECT * FROM dbo.' + name
	    FROM sys.objects
	    WHERE name LIKE 'WaitStats_Log%'
		  AND name <> @NewTableName
	      AND type = 'U'
	    FOR XML PATH('')), 1, 1, '');

    -- Build dynamic SQL statement to create view across all log tables
    SET @Command = '
    CREATE VIEW dbo.WaitStats_Log_All AS SELECT * FROM dbo.' + @NewTableName + COALESCE(' UNION ALL ' + REPLACE(@Command, ';', ' UNION ALL '), '') + ';';

    -- Execute dynamic SQL statement
    EXECUTE(@Command);

    END;

-- Insert current wait stats into collection table
SET @Command = '
WITH Waits AS
	(SELECT
		wait_type,
		wait_time_ms / 1000.0 AS WaitS,
		(wait_time_ms - signal_wait_time_ms) / 1000.0 AS ResourceS,
		signal_wait_time_ms / 1000.0 AS SignalS,
		waiting_tasks_count AS WaitCount,
		100.0 * wait_time_ms / SUM (wait_time_ms) OVER() AS Percentage,
		ROW_NUMBER() OVER(ORDER BY wait_time_ms DESC) AS RowNum
	FROM sys.dm_os_wait_stats
	WHERE FLOOR(wait_time_ms) > 0
		AND wait_type NOT IN (
			''CLR_SEMAPHORE'', ''LAZYWRITER_SLEEP'', ''RESOURCE_QUEUE'', ''SLEEP_TASK'',
			''SLEEP_SYSTEMTASK'', ''SQLTRACE_BUFFER_FLUSH'', ''DIRTY_PAGE_POLL'', ''LOGMGR_QUEUE'',
			''CHECKPOINT_QUEUE'', ''REQUEST_FOR_DEADLOCK_SEARCH'', ''XE_TIMER_EVENT'', ''BROKER_TO_FLUSH'',
			''BROKER_TASK_STOP'', ''CLR_MANUAL_EVENT'', ''CLR_AUTO_EVENT'', ''DISPATCHER_QUEUE_SEMAPHORE'',
			''FT_IFTS_SCHEDULER_IDLE_WAIT'',  ''BROKER_EVENTHANDLER'',
			''TRACEWRITE'', ''FT_IFTSHC_MUTEX'', ''SQLTRACE_INCREMENTAL_FLUSH_SLEEP'',
			''BROKER_RECEIVE_WAITFOR'', ''ONDEMAND_TASK_QUEUE'', ''DBMIRROR_EVENTS_QUEUE'',
			''DBMIRRORING_CMD'', ''BROKER_TRANSMITTER'', ''SQLTRACE_WAIT_ENTRIES'',
			''SLEEP_BPOOL_FLUSH'', ''SQLTRACE_LOCK'', ''DBMIRROR_WORKER_QUEUE'', ''XE_DISPATCHER_WAIT'',
			''SP_SERVER_DIAGNOSTICS_SLEEP'', ''HADR_FILESTREAM_IOMGR_IOCOMPLETION'')
	)
INSERT INTO dbo.' + @NewTableName + '
	(Collection_Time, WaitType, Wait_Seconds, Resource_Seconds, Signal_Seconds, WaitCount, Percentage, AvgWait_Seconds, AvgResource_Seconds, AvgSignal_Seconds)
SELECT
	Collection_Time		= GETDATE(),
	WaitType			= W1.wait_type, 
	Wait_Seconds		= CAST(W1.WaitS AS DECIMAL(14,2)),
	Resource_Seconds	= CAST(W1.ResourceS AS DECIMAL(14,2)),
	Signal_Seconds		= CAST(W1.SignalS AS DECIMAL(14,2)),
	WaitCount			= W1.WaitCount,
	Percentage			= CAST(W1.Percentage AS DECIMAL(5,2)),
	AvgWait_Seconds		= CAST(CASE WHEN COALESCE(W1.WaitCount, 0) = 0 THEN 0 ELSE W1.WaitS / W1.WaitCount END AS DECIMAL(14,4)),
	AvgResource_Seconds	= CAST(CASE WHEN COALESCE(W1.WaitCount, 0) = 0 THEN 0 ELSE W1.ResourceS / W1.WaitCount END AS DECIMAL(14,4)),
	AvgSignal_Seconds	= CAST(CASE WHEN COALESCE(W1.WaitCount, 0) = 0 THEN 0 ELSE W1.SignalS / W1.WaitCount END AS DECIMAL(14,4))
FROM Waits AS W1
INNER JOIN Waits AS W2
	ON W2.RowNum <= W1.RowNum
GROUP BY W1.RowNum, W1.wait_type, W1.WaitS, W1.ResourceS, W1.SignalS, W1.WaitCount, W1.Percentage
HAVING SUM (W2.Percentage) - W1.Percentage < 95;
';
EXECUTE (@Command);

-- Clear current wait stats
DBCC SQLPERF('WAITSTATS', CLEAR);

END
GO

EXECUTE dbo.CollectWaitStats;
GO
