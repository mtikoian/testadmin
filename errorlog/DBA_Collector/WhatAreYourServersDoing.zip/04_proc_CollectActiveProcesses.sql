SET NOEXEC OFF;

IF DB_NAME() = 'master'
	BEGIN

	RAISERROR('Do you really want to create this in the ''master'' database?', 16, 1) WITH LOG;
	SET NOEXEC ON;

	END
GO

IF OBJECT_ID('dbo.CollectActiveProcesses', 'P') IS NOT NULL DROP PROCEDURE dbo.CollectActiveProcesses;
GO

CREATE PROCEDURE dbo.CollectActiveProcesses
	@DaysToRetain	INT				= 30
AS
BEGIN

-- Run this stored procedure from a SQL Agent job, recommend 15 minute intervals,
-- to collect wait stats over time

DECLARE @Now DATETIME = GETDATE();
DECLARE @Command VARCHAR(MAX);
DECLARE @NewTableName VARCHAR(255);
DECLARE @DropTableName VARCHAR(255);

-- Create collection table if it doesn't already exist
SET @NewTableName = 'ActiveProcesses_Log_' + CONVERT(VARCHAR(10), @Now, 112);
IF NOT EXISTS(SELECT * FROM sys.objects WHERE name = @NewTableName)
	BEGIN

	SET @Command = '
	CREATE TABLE dbo.' + @NewTableName + '
		( 
			[dd hh:mm:ss.mss] VARCHAR(8000) NULL
			,[session_id] SMALLINT NOT NULL
			,[sql_text] XML NULL
			,[login_name] NVARCHAR(128) NOT NULL
			,[wait_info] NVARCHAR(4000) NULL
			,[tasks] VARCHAR(30) NULL
			,[tran_log_writes] NVARCHAR(4000) NULL
			,[CPU] VARCHAR(30) NULL
			,[tempdb_allocations] VARCHAR(30) NULL
			,[tempdb_current] VARCHAR(30) NULL
			,[blocking_session_id] SMALLINT NULL
			,[reads] VARCHAR(30) NULL
			,[writes] VARCHAR(30) NULL
			,[context_switches] VARCHAR(30) NULL
			,[physical_io] VARCHAR(30) NULL
			,[physical_reads] VARCHAR(30) NULL
			,[query_plan] XML NULL
			,[used_memory] VARCHAR(30) NULL
			,[status] VARCHAR(30) NOT NULL
			,[tran_start_time] DATETIME NULL
			,[open_tran_count] VARCHAR(30) NULL
			,[percent_complete] VARCHAR(30) NULL
			,[host_name] NVARCHAR(128) NULL
			,[database_name] NVARCHAR(128) NULL
			,[program_name] NVARCHAR(128) NULL
			,[start_time] DATETIME NOT NULL
			,[login_time] DATETIME NULL
			,[request_id] INT NULL
			,[collection_time] DATETIME NOT NULL
			,[MissingIndex] AS (SIGN(CHARINDEX(''MissingIndex'', CAST(query_plan AS NVARCHAR(MAX))))) PERSISTED
			,CONSTRAINT PK_' + @NewTableName + ' PRIMARY KEY CLUSTERED ([collection_time], [session_id])
			,CONSTRAINT CK_' + @NewTableName + ' CHECK ([collection_time] >= CAST(''' + CONVERT(VARCHAR(25), DATEADD(DAY, DATEDIFF(DAY, 0, @Now), 0), 102) + ''' AS DATETIME) AND [collection_time] < CAST(''' + CONVERT(VARCHAR(25), DATEADD(DAY, DATEDIFF(DAY, 0, @Now), 1), 102) + ''' AS DATETIME))
		);';
	EXECUTE (@Command);
	
	SET @Command = 'CREATE INDEX IX_' + @NewTableName + '_MissingIndex ON ' + @NewTableName + ' (MissingIndex);';
	EXECUTE (@Command);
	
     -- Drop existing "all" view before dropping old tables
	IF OBJECT_ID('ActiveProcesses_Log_All', 'V') IS NOT NULL DROP VIEW ActiveProcesses_Log_All;

	-- Remove tables after 30 days
	SET @DropTableName = 'ActiveProcesses_Log_' + CONVERT(VARCHAR(10), DATEADD(DAY, -@DaysToRetain, @Now), 112);
     SELECT @Command = STUFF((
	    SELECT ';DROP TABLE ' + name
	    FROM sys.objects
	    WHERE name LIKE 'ActiveProcesses_Log_%'
	      AND type = 'U'
	      AND name <= @DropTableName
	    FOR XML PATH('')), 1, 1, '');
	EXECUTE (@Command);
	
	END

-- Create view across all collection tables if it doesn't already exist
IF OBJECT_ID('ActiveProcesses_Log_All', 'V') IS NULL
    BEGIN

    SELECT @Command = STUFF((
	    SELECT ';SELECT * FROM ' + name
	    FROM sys.objects
	    WHERE name LIKE 'ActiveProcesses_Log_%'
		  AND name <> @NewTableName
	      AND type = 'U'
	    FOR XML PATH('')), 1, 1, '');

    -- Build dynamic SQL statement to create view across all log tables
    SET @Command = '
    CREATE VIEW ActiveProcesses_Log_All AS SELECT * FROM dbo.' + @NewTableName + COALESCE(' UNION ALL ' + REPLACE(@Command, ';', ' UNION ALL '), '') + ';';

    -- Execute dynamic SQL statement
    EXECUTE(@Command);

    END;

-- Run sp_WhoIsActive, saving results to collection table
EXECUTE sp_WhoIsActive 
    @get_transaction_info = 1,
	@get_task_info = 2, 
    @get_plans = 1,
    @destination_table = @NewTableName;

END
GO

EXECUTE dbo.CollectActiveProcesses;
GO
