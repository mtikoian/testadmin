<#
  This plug-in serves two purposes: 
    1. Connect to all listed servers and output any that are not responding.
    2. Get a unique list of physical host names for all SQL servers.
#>

$Title = "Connection to SQL CMS"
$Author = "Josh Feierman"
$PluginVersion = 1.0
$Header = "Connection Test"
$Comments = "The following servers are not currently responding."
$Display = "Table"


# Start of Settings 

# Filter for path of server in CMS (use "%" for a wildcard)
$FilterPath = ""

# End of Settings

# Find the CMS Server from the global settings file
$CMSServer = $Server

[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SQLServer.SMO") | Out-Null

Write-CustomOut "Connecting to CMS Server"

$CMSServerConn = New-Object Microsoft.SqlServer.Management.Smo.Server $CMSServer

$sqlQuery = @"
WITH ServerGroups AS
(
  SELECT  server_group_id,
          name,
          CAST('/' + name AS VARCHAR(128)) AS path
  FROM    dbo.sysmanagement_shared_server_groups
  WHERE   parent_id = 1
  UNION ALL
  SELECT  sg.server_group_id,
          sg.name,
          CAST(sg1.path + '/' + sg.name AS VARCHAR(128)) AS path
  FROM    dbo.sysmanagement_shared_server_groups sg
            JOIN ServerGroups sg1
              ON sg.parent_id = sg1.server_group_id
)
SELECT  serv.name,
          sgrp.path,
          serv.server_name
FROM    dbo.sysmanagement_shared_registered_servers serv
            JOIN ServerGroups sgrp
              ON serv.server_group_id = sgrp.server_group_id
"@

if ($FilterPath -ne "")
{
  $sqlQuery = $sqlQuery + "`nWHERE sgrp.path LIKE '$FilterPath'"
}

Write-CustomOut "Collecting SQL Server details from CMS"
$SQLServers = $CMSServerConn.Databases.Item("MSDB").ExecuteWithResults($sqlQuery).Tables[0]

Write-CustomOut "Calculating unique host names"
$hosts = @()
$params = @{}

$scriptBlock = 
{
	[Cmdletbinding()]
  param($sqlServer)
	
  Write-Verbose $sqlServer
  $sqlConn = New-Object system.Data.SqlClient.SqlConnection "Data Source=$SQLServer;Integrated Security=SSPI;Initial Catalog=msdb"
  $sqlCmd = New-Object System.Data.SqlClient.SqlCommand
  $sqlCmd.Connection = $sqlConn
  $sqlDA = New-Object System.Data.SqlClient.SqlDataAdapter
  $sqlDA.SelectCommand = $sqlCmd
  $dt = New-Object System.Data.DataTable

  $sqlCmd.CommandText = "SELECT SERVERPROPERTY('ComputerNamePhysicalNetBIOS')"

  try
  {
    $sqlConn.Open()
    $hostname = $sqlCmd.ExecuteScalar()
    Write-Debug "First attempt at host name is $hostname"
    # Begin workaround for SQL 2000
    if ($hostname.GetType().Name -eq "DBNull")
    {
      $sqlCmd.CommandText = @"
CREATE TABLE #regdata (VALUE VARCHAR(255),DATA VARCHAR(255));
INSERT #regdata exec master..xp_regread 'HKEY_LOCAL_Machine','SYSTEM\CurrentControlSet\Control\ComputerName\ComputerName\','ComputerName';
SELECT Data FROM #regdata;
DROP TABLE #regdata;
"@
      $hostname = $sqlCmd.ExecuteScalar()
    }
    Write-Verbose $hostname
    $sqlConn.Close()
    $serverConn = $null
    $responding = $true
  }
  catch
  {
    $responding = $false; 
  }
  finally
  {
    $sqlDA.Dispose()
    $sqlCmd.Dispose()
    $sqlConn.Dispose()
    $dt.Dispose()
  }
  
  "" | Select-Object @{n="ServerName";e={$sqlServer}},
                     @{n="HostName";e={$hostname}},
                     @{n="Responding";e={$responding}}
  
} 

foreach ($SQLServer in $SQLServers)
{
  $params.Add($SQLServer.server_name,@{"sqlServer" = "$($sqlServer.server_name)"})
}

$results = Execute-RunspaceJob -ScriptBlock $scriptBlock -ArgumentList $params -ThrottleLimit $MaxThreads

$hosts = $results | Select-Object -Property HostName -Unique

$notResponding = $results | Where-Object {$_.Responding -eq $false} | Select-Object ServerName

foreach ($notRespondingServer in $notResponding)
{
  $row = $SQLServers | Where-Object {$_.server_name -eq $notRespondingServer.ServerName}
  $SQLServers.Rows.Remove($row)
}

$notResponding

$date = Get-Date
$PluginCategory = "SQLServer"
