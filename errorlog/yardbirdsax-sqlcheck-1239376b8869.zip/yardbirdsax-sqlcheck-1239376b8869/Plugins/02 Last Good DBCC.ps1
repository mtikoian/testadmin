$Title = "Last Good DBCC"
$Author = "Josh Feierman"
$PluginVersion = 1.0
$Header =  "Databases Without Recent DBCC Checks"
$Comments = "The following databases have not had a DBCC integrity check within defined thresholds."
$Display = "Table"

$data = @()

# Start of Settings 

# The warning threshold (in number of days) for the last time a DBCC CHECKDB was run.
$DBCCCheckThreshold = 1

# End of Settings

$data = @()
$params = @{}
$scriptBlock = 
{
  param
  (
    $FriendlyName,
    $SQLServer,
    $DBCCCheckThreshold
  )

  $sqlConn = New-Object system.Data.SqlClient.SqlConnection "Data Source=$SQLServer;Integrated Security=SSPI;Initial Catalog=msdb"
  $sqlCmd = New-Object System.Data.SqlClient.SqlCommand
  $sqlCmd.Connection = $sqlConn
  $sqlDA = New-Object System.Data.SqlClient.SqlDataAdapter
  $sqlDA.SelectCommand = $sqlCmd
  $dt = New-Object System.Data.DataTable
   
  
  $sqlQuery = @"
DECLARE @DBCCResults TABLE
(
  ID INT IDENTITY(1,1),
  ParentObject VARCHAR(255),
  [Object] VARCHAR(255),
  Field VARCHAR(255),
  [Value] VARCHAR(255)
);
DECLARE @LastGoodDBCC TABLE
(
  DatabaseName SYSNAME,
  LastGoodDBCCDate DATETIME
);

DECLARE DBCursor CURSOR FAST_FORWARD FOR
  SELECT  name
  FROM    sys.databases
  WHERE   state_desc = 'ONLINE'
          AND name <> 'tempdb';

DECLARE @DBName SYSNAME;    

OPEN DBCursor;

WHILE 1=1 BEGIN

  FETCH DBCursor INTO @DBName;
  IF @@FETCH_STATUS <> 0 BREAK;

  DELETE FROM @DBCCResults;

  INSERT @DBCCResults
  EXEC('DBCC DBINFO(' + @DBName + ') WITH TABLERESULTS;');

  INSERT  @LastGoodDBCC
  SELECT  TOP 1 
          @DBName,
          VALUE
  FROM    @DBCCResults
  WHERE   Field = 'dbi_dbccLastKnownGood';

END

CLOSE DBCursor;
DEALLOCATE DBCursor;

SELECT * FROM @LastGoodDBCC WHERE LastGoodDBCCDate <= DATEADD(DAY,-7,DATEADD(DAY,0,DATEDIFF(d, 0,GETDATE())))
"@

  $sqlCmd.CommandText = $sqlQuery
  
  $sqlConn.Open()
  $sqlDA.Fill($dt) | Out-Null
  $sqlConn.Close()
  
  if ($dt.Rows.Count -ne 0)
  {
    $dt | Select-Object @{n="ServerName";e={$FriendlyName}},
                        DatabaseName,
                        LastGoodDBCCDate
  }
  $sqlDA.Dispose()
  $sqlCmd.Dispose()
  $sqlConn.Dispose()
  $dt.Dispose()
}

foreach ($SQLServer in $SQLServers)
{
  $params.Add($SQLServer.server_name,@{"FriendlyName" = "$($SQLServer.name)"
  	                               "SQLServer" = "$($SQLServer.server_name)"
                                       "DBCCCheckThreshold" = $DBCCCheckThreshold})
}

$data = Execute-RunspaceJob -ScriptBlock $scriptBlock -ArgumentList $params -ThrottleLimit $MaxThreads 

$data