$Title = "Disk Percent Free"
$Author = "Josh Feierman"
$PluginVersion = 1.0
$Header =  "Disk Percent Free Below Threshold"
$Comments = "The volumes are at or below the defined threshold for space percent free."
$Display = "Table"

$data = @()

# Start of Settings 

# The minimum acceptable percent free for disk space
$PercentThreshold = 15

# End of Settings

$data = @()
$params = @{}
$scriptBlock = 
{
  param($Computer)
  try
  {
    Get-WmiObject -Class Win32_Volume -ComputerName $computer -Filter "DriveType = 3"|
      Select-Object @{n="Computer";e={$computer}},
                    @{n="DiskName";e={$_.Name}},
                    @{n="Label";e={$_.Label}},
                    @{n="CapacityMB";e={($_.Capacity/1MB)}},
                    @{n="FreeSpaceMB";e={($_.FreeSpace/1MB)}},
                    @{n="PercentFree";e={[Math]::Round(($_.FreeSpace / $_.Capacity) * 100,2)}}
  }
  catch
  {
    throw $_.Exception
  }
}

foreach ($Computer in $hosts)
{
  $params.Add($Computer.HostName,@{"Computer" = "$($Computer.HostName)"})
}

$data = Execute-RunspaceJob -ScriptBlock $scriptBlock -ArgumentList $params -ThrottleLimit $MaxThreads |
          Where-Object {$_.PercentFree -le $PercentThreshold}

$data