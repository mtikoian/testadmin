$Title = "Last Backup Date"
$Author = "Josh Feierman"
$PluginVersion = 1.0
$Header =  "Databases Without Current Backups"
$Comments = "The following databases have not been backed up within defined thresholds."
$Display = "Table"

$data = @()

# Start of Settings 

# The warning threshold for full backups.
$FullBackupThreshold = 8
# The warning threshold for differential backups.
$DifferentialBackupThreshold = 1
# The warning threshold for log backups (in hours).
$LogBackupThreshold = 6

# End of Settings

$data = @()
$params = @{}
$scriptBlock = 
{
  param
  (
    $FriendlyName,
    $SQLServer,
    $FullBackupThreshold,
    $DifferentialBackupThreshold,
    $LogBackupThreshold
  )

  $sqlConn = New-Object system.Data.SqlClient.SqlConnection "Data Source=$SQLServer;Integrated Security=SSPI;Initial Catalog=msdb"
  $sqlCmd = New-Object System.Data.SqlClient.SqlCommand
  $sqlCmd.Connection = $sqlConn
  $sqlDA = New-Object System.Data.SqlClient.SqlDataAdapter
  $sqlDA.SelectCommand = $sqlCmd
  $dt = New-Object System.Data.DataTable

  $sqlQuery = @"
with all_backups as
(
  select  MAX(bset.backup_finish_date) backup_date,
          bset.database_name,
          bset.type
  from    dbo.backupset bset
  group by bset.database_name, bset.type
)
select  db.name database_name,
        db.recovery_model_desc,
        ISNULL(fullb.backup_date,'1-1-1900') full_backup_date,
        ISNULL(diffb.backup_date,'1-1-1900') diff_backup_date,
        ISNULL(logb.backup_date,'1-1-1900') log_backup_date
from    sys.databases db
          LEFT JOIN all_backups fullb
            ON db.name = fullb.database_name
            AND fullb.type = 'D'
          LEFT JOIN all_backups diffb
            ON db.name = diffb.database_name
            AND diffb.type = 'I'
          LEFT JOIN all_backups logb
            ON db.name = logb.database_name
            AND logb.type = 'L' 
where      (fullb.backup_date <= DATEADD(DAY,-$FullBackupThreshold,DATEADD(DAY,0,DATEDIFF(d, 0,GETDATE())))) 
        OR (  (diffb.backup_date <= DATEADD(DAY,-$DifferentialBackupThreshold,DATEADD(DAY,0,DATEDIFF(d, 0,GETDATE())))) 
          AND (fullb.backup_date <= DATEADD(DAY,-$DifferentialBackupThreshold,DATEADD(DAY,0,DATEDIFF(d, 0,GETDATE()))))
          )
        OR (  (db.recovery_model_desc IN ('FULL','BULK_LOGGED'))
          AND (logb.backup_date <= DATEADD(HOUR,-$LogBackupThreshold,GETDATE()))
          )
"@
  
  $sqlCmd.CommandText = $sqlQuery
  
  try 
  {
     
    $sqlConn.Open()
    $sqlDA.Fill($dt) | Out-Null
    $sqlConn.Close()
    
    if ($dt.Rows.Count -ne 0)
    {
      $dt | Select-Object   @{n="ServerName";e={$FriendlyName}},
                            @{n="DatabaseName";e={$_.database_name}},
                            @{n="RecoveryModel";e={$_.recovery_model_desc}},
                            @{n="LastFullBackup";e={$_.full_backup_date}},
                            @{n="LastDiffBackup";e={$_.diff_backup_date}},
                            @{n="LastLogBackup";e={$_.log_backup_date}}
    }                          
  }
  catch
  {
    throw $_.Exception
  }
  finally
  {
    $sqlDA.Dispose()
    $sqlCmd.Dispose()
    $sqlConn.Dispose()
    $dt.Dispose()
  }

}

foreach ($SQLServer in $SQLServers)
{
  $params.Add($SQLServer.server_name,@{"FriendlyName" = "$($SQLServer.name)"
  	  			       "SQLServer" = "$($SQLServer.server_name)"
                                       "FullBackupThreshold" = $FullBackupThreshold
                                       "DifferentialBackupThreshold" = $DifferentialBackupThreshold
                                       "LogBackupThreshold" = $LogBackupThreshold})
}

$data = Execute-RunspaceJob -ScriptBlock $scriptBlock -ArgumentList $params -ThrottleLimit $MaxThreads 

$data