# README #

### What is this? ###

This is my adaptation of Alan Renouf's excellent [vCheck](http://www.virtu-al.net/vcheck-pluginsheaders/vcheck/) framework for monitoring SQL Server.

### How do I get set up? ###

To use this you need three things: 

1. A [SQL Server Central Management Server](http://msdn.microsoft.com/en-us/library/bb934126.aspx).
2. A server with Powershell 2.0 (it should work on 3.0 or higher but I've not had time to test it).
3. A Windows account that has local admin and sysadmin rights across all the SQL servers you wish to monitor.

After downloading you can run vCheck.ps1 script, and it will prompt you to enter in all the information required. I recommend scheduling this to run on a daily basis using Windows task scheduler, under the account mentioned in step 2, and having the results e-mailed to you every morning.

Of note is that these plugins use two main connection methods: WMI and SQL, so make sure that you do not have firewalls blocking access to the machines your monitoring from where it is run.

While I've made every effort to test this and ensure no harm, be aware that you run this at your own risk, and I advise you to test in non production systems as well as dig into the code to see what it's doing. Don't trust me just because I wrote this!

### Contribution guidelines ###

If you find problems feel free to log them, or if you want to contribute a fix or a plugin, e-mail me at josh at sqljosh dot com. I'm not currently adding to the framework (though if there's enough demand I might start), but I welcome contributions!