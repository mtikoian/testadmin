IF NOT EXISTS (SELECT 1
                 FROM INFORMATION_SCHEMA.ROUTINES
                WHERE ROUTINE_NAME = 'sp_trace_helper'
                  AND ROUTINE_SCHEMA = 'dbo')
BEGIN
  EXEC ('CREATE PROCEDURE dbo.sp_trace_helper AS BEGIN PRINT ''STUB FOR PROCEDURE'' END');
END  
GO

/***
=help
sp_trace_helper v1.0
(c) 2014 Joshua Feierman

Feedback: mailto:josh@sqljosh.com

To receive updates of when I fix things or make this better, sign up at https://bit.ly/sqljosh.

Author: Josh Feierman

License:
  sp_trace_helper is free to download and use for personal, educational, and internal
  purposes, provided this license and all original attributions are included.
  Redistribution or sale in whole or in part is prohibited without the author's 
  express written consent. By installing and / or executing this procedure in your environment
  you accept any and all risk associated with running it. Always test in a non-production
  system first!


This stored procedure is used for easily setting up SQL traces for one or more
processes in SQL server.

Traces can be filtered in any one of several ways:
  1. By session (SPID) - specify a value for @SessionID
  2. By application name - specify a value for @Application. This can include
     wildcards ('%') but cannot be only a wildcard.
  3. By originating client host - specify a value for @Host. This can include
     wildcards ('%') but cannot be only a wildcard. Note that this value can be 
     arbitrarily set and may not be accurate.
  4. By database - specify a value for @Database.



The remainder of the parameters are:

@Action: Specifies which action to take on the trace.
  CREATE - Create the trace (but do not start it).
  START  - Start the trace (must be created).
  STOP   - Stop the trace if it is running.
  DELETE - Deletes the definition of the trace.
  READ   - Reads the trace file into a result set. If @TraceFilePath is specified,
           it will read the file from there. If not, it will try and find a created
           trace definition and read that file.

@TraceFilePath: Specifies the path at which traces will be created. The files will be named
"SPTRACEHELPER[_d].trc", where "[_d]" is an underscore and serial number that will be appended
by SQL's trace engine if multiple files are created or already present.

@TraceFileSize: Specifies the size of the trace file. The trace is created with four files by default,
and rollover is enabled (so when the fourth one fills up, the first one will be overriden).

@IncludeBatchLevel: The trace will include batch level events (Batch start and complete, RPC start and complete).

@IncludeStatementLevel: The trace will include statement level events (Statement start and complete, SP statement 
start and complete). This may generate significantly more trace data, use caution.

@TraceFileCount: The maximum number of trace files that will be created before the trace rolls over onto
the original file.

Example 1: Tracing one session
-------------------------------
The session you wish to trace is SPID number 101. You would execute the following:
  exec sp_trace_helper @action = 'CREATE',
                       @SessionID = 101,
                       @TraceFilePath = 'D:\Trace';
  exec sp_trace_helper @action = 'START';

Once you were done tracing the activity, you would run this:

  exec sp_trace_helper @action = 'STOP';

You could then read the trace data as follows:

  exec sp_trace_helper @action = 'READ';

Once you were completely done, you would run:

  exec sp_trace_helper @action = 'DELETE';

Note that this does not delete the trace files, only the trace definition. This step
is required if you want to move (or delete) the .TRC files.

Example 2: Tracing sessions for a given application
----------------------------------------------------
The commands above are essentially the same, except for the one to create the trace 
(the first one). If your application was named 'MyApp', you would execute as follows:

    exec sp_trace_helper @action = 'CREATE',
                         @Application = 'MyApp',
                         @TraceFilePath = 'D:\Trace';

=endhelp


Revisions    :
--------------------------------------------------------------------------------
Ini|   Date   | Description
--------------------------------------------------------------------------------
JF  12/14/2015  Updated to include collecting blocked process and deadlock graphs.

***/

ALTER PROCEDURE dbo.sp_trace_helper
--DECLARE
  @Action varchar(10) = 'CREATE',
  @TraceFilePath nvarchar(128) = NULL,
  @TraceFileSize bigint = 256,
  @SessionID int = NULL,
  @Application nvarchar(256) = NULL,
  @Host nvarchar(256) = NULL,
  @Database nvarchar(128) = NULL,
  @Help bit = 0,
  @IncludeBatchLevel bit = 1,
  @IncludeStatementLevel bit = 0,
  @TraceFileCount tinyint = 4
--  ;
AS

SET NOCOUNT ON;

DECLARE @ProductVersion  varchar(128),
        @SQLMajorVersion decimal(3,1),
        @MessageText varchar(4000),
        @MessageSev tinyint,
        @TraceFileName nvarchar(32),
        @TraceFileFullPath nvarchar(256),
        @TraceID int,
        @RC int,
        @SQL nvarchar(max);

DECLARE @TraceColumns TABLE
(
  ColumnID int PRIMARY KEY,
  ColumnName nvarchar(128)
);

DECLARE @TraceEvents TABLE
(
  EventID int PRIMARY KEY,
  EventName nvarchar(128)
)

SET @TraceFileName = 'SPTRACEHELPER';

BEGIN TRY

  -- Validate parameters
  
  IF @Help = 1
  BEGIN

    SELECT @SQL = dest.text
      FROM sys.dm_exec_requests r CROSS APPLY sys.dm_exec_sql_text(r.sql_handle) dest
     WHERE r.session_id = @@SPID;
    --PRINT @SQL;
    -- Cut up the SQL text and get the help section
    SET @MessageText = SUBSTRING(@SQL,
                         CHARINDEX('=help',@SQL),
                         CHARINDEX('=endhelp',@SQL)-CHARINDEX('=help',@SQL)+8
                        );

    PRINT @MessageText;
    RETURN;

  END;

  IF @Action = 'CREATE'
  BEGIN
    IF ISNULL(@Application,'') = '' AND @SessionID IS NULL AND @Host IS NULL AND @Database IS NULL
      RAISERROR('You must specify a value for either @Application, @Host, @Database, or @SessionID.',16,1) WITH NOWAIT;
    IF @Application = '%'
      RAISERROR('You cannot specify an empty wildcard for @Application.',16,1) WITH NOWAIT;
    IF @Database IS NOT NULL AND @SessionID IS NULL AND @Host IS NULL AND ISNULL(@Application,'') = ''
      RAISERROR('Warning: you have specified only a database name for filtering. This may produce a large volume of data and is not recommended.',
                10,
                1) WITH NOWAIT;
  END;
  
  -- Seed the two tables for generating the trace commands.
  INSERT INTO @TraceEvents
  (
      EventID,
      EventName
  )
  SELECT 10, 'RPC:Completed' WHERE @IncludeBatchLevel = 1
  UNION ALL
  SELECT 11, 'RPC:Starting' WHERE @IncludeBatchLevel = 1
  UNION ALL
  SELECT 13, 'SQL:BatchStarted' WHERE @IncludeBatchLevel = 1
  UNION ALL
  SELECT 12, 'SQL:BatchCompleted' WHERE @IncludeBatchLevel = 1
  UNION ALL
  SELECT 55, 'Hash Warning'
  UNION ALL
  SELECT 69, 'Sort Warning'
  UNION ALL
  SELECT 40, 'SQL:StmtStarting' WHERE @IncludeStatementLevel = 1
  UNION ALL
  SELECT 41, 'SQL:StmtCompleted' WHERE @IncludeStatementLevel = 1
  UNION ALL
  SELECT 44, 'SP:StmtStarting' WHERE @IncludeStatementLevel = 1
  UNION ALL
-- 12/14/2015 JFEIERMAN - Begin change to include deadlocks and blocked process reports.
  SELECT 45, 'SP:StmtCompleted' WHERE @IncludeStatementLevel = 1
  UNION ALL 
  SELECT 148, 'Deadlock graph'
  UNION ALL
  SELECT 137, 'Blocked process report';
-- 12/14/2015 JFEIERMAN - End change to include deadlocks and blocked process reports.

  INSERT INTO @TraceColumns
  (
      ColumnID,
      ColumnName
  )
  SELECT 51, 'Event Sequence'
  UNION ALL
  SELECT 14, 'StartTime'
  UNION ALL
  SELECT 15, 'EndTime'
  UNION ALL
  SELECT 12, 'SPID'
  UNION ALL
  SELECT 1, 'Text Data'
  UNION ALL
  SELECT 13, 'Duration (microseconds)'
  UNION ALL
  SELECT 18, 'CPU Used (milliseconds)'
  UNION ALL
  SELECT 16, 'Reads'
  UNION ALL
  SELECT 17, 'Writes'
  UNION ALL
  SELECT 10, 'ApplicationName'
  UNION ALL
  SELECT 8, 'HostName'
  UNION ALL
  SELECT 11, 'LoginName'
  UNION ALL
  SELECT 3, 'DatabaseID'
  UNION ALL
  SELECT 35, 'DatabaseName';

  SET @ProductVersion = CONVERT(varchar(128),SERVERPROPERTY('ProductVersion'));
  SET @SQLMajorVersion = SUBSTRING(@ProductVersion,1,CHARINDEX('.',@ProductVersion)+1);

  SET @MessageText = '**********************************************************' + CHAR(10) +
                     ' Beginning run of SP_TRACE_HELPER' + CHAR(10) +
                     ' (c) 2014 Joshua Feierman' + CHAR(10) +
                     ' SQL Major Version is: ' + CONVERT(varchar,@SQLMajorVersion)  + CHAR(10) +
                     ' ACTION is:   ' + @Action + char(10) +
                     ' SESSION is:  ' + ISNULL(CONVERT(varchar,@SessionID),'N/A') + char(10) +
                     '**********************************************************';
  RAISERROR(@MessageText,0,1) WITH NOWAIT;

  -- Add a trailing slash to the path if it's not there.
  IF RIGHT(@TraceFilePath,1) <> '\'
    SET @TraceFilePath = @TraceFilePath + '\';

  -- Create the full trace file name
  SET @TraceFileFullPath = @TraceFilePath + @TraceFileName;
  SET @MessageText = CHAR(10) +
                     '  Trace file full path is: %s';
  RAISERROR(@MessageText,0,1,@TraceFileFullPath) WITH NOWAIT;

  IF @Action = 'CREATE'
  BEGIN
    
    RAISERROR('  Beginning creation of trace.',0,1) WITH NOWAIT;
    
    -- Create the trace
    EXEC @RC = sp_trace_create @TraceID output,
                         2, -- rollover trace files
                         @TraceFileFullPath,
                         @TraceFileSize,
                         NULL, -- no stop time
                         4; -- four files max
    SET @MessageText = 'Return code for trace create is: ' + CONVERT(varchar,@RC) + '. ' +
                       CASE @RC
                         WHEN 0 THEN '  Trace created successfully. Trace ID is: ' + CONVERT(varchar,@TraceID)
                         WHEN 1 THEN '  Unknown error occurred during trace creation.'
                         WHEN 10 THEN '  Invalid trace options specified.'
                         WHEN 12 THEN '  Could not create trace file. Check to see if files with the same name already exist and ' +
                                      'that the SQL Server service account has write permissions to the location specified.'
                         WHEN 13 THEN '  System ran out of memory creating trace.'
                         WHEN 15 THEN '  Invalid parameters specified in trace creation.'
                         ELSE '  An unknown error occurred.'
                       END;
    SET @MessageSev = CASE
                        WHEN @RC > 0 THEN 16
                        ELSE 0
                      END;
    RAISERROR(@MessageText,@MessageSev,1);

    -- Add trace events
    -- We dynamically generate this so as to not have a lot of the same code.
    SET @SQL = (
      SELECT 'exec sp_trace_setevent @TraceID,' 
              + CONVERT(varchar,te.EventID) + ',' 
              + CONVERT(varchar,tc.ColumnID) + ',' 
              + '1;' + CHAR(10)
        FROM @TraceEvents te CROSS JOIN @TraceColumns tc
      FOR XML PATH('')
    );

    --PRINT @SQL;
    EXEC sp_executesql @SQL, N'@TraceID int', @TraceID;

    -- Set the trace filter
    IF @SessionID IS NOT NULL
      EXEC sp_trace_setfilter @TraceID,
                              12, -- SPID
                              0, -- AND
                              0, -- Equals
                              @SessionID;
    
    IF @Application IS NOT NULL BEGIN
      EXEC sp_trace_setfilter @TraceID,
                              10, -- Application Name
                              0, -- AND
                              6, -- LIKE
                              @Application;
      EXEC sp_trace_setfilter @TraceID,
                              10, -- Application Name
                              0, -- AND
                              1, -- Not Equal To
                              NULL; -- Filter out NULL
    END;
    IF @Host IS NOT NULL BEGIN
      EXEC sp_trace_setfilter @TraceID,
                              8, -- Host Name
                              0, -- AND
                              6, -- LIKE
                              @Host; 
      EXEC sp_trace_setfilter @TraceID,
                              8, -- Host Name
                              0, -- AND
                              1, -- Not Equal To
                              NULL; -- Filter out NULL
    END;
    IF @Database IS NOT NULL BEGIN
      EXEC sp_trace_setfilter @TraceID,
                              35, -- Database Name
                              0, -- AND
                              6, -- LIKE
                              @Database;
      EXEC sp_trace_setfilter @TraceID,
                              35, -- Database Name
                              0, -- AND
                              1, -- Not Equal To
                              NULL; -- Filter out NULL   
    END;                                                                                                                           

  END; -- End ACTION = 'CREATE'
  ELSE IF @Action = 'START'
  BEGIN
    -- Try and find a trace already created
    SELECT @TraceID = t.id
      FROM sys.traces t
     WHERE t.[path] LIKE '%\SPTRACEHELPER%.trc';
    RAISERROR('  Created trace for SP_TRACE_HELPER found, ID is: %i',0,1,@TraceID) WITH NOWAIT;

    IF @TraceID IS NULL
      RAISERROR('  Could not find a currently created trace.',16,1) WITH NOWAIT;
    
    -- Stop the trace
    EXEC sp_trace_setstatus @TraceID, 1;

    RAISERROR('  Trace has been successfully started.',0,1) WITH NOWAIT;

  END; -- End ACTION='START'
  ELSE IF @Action = 'STOP'
  BEGIN
    
    -- Try and find a trace already created
    SELECT @TraceID = t.id
      FROM sys.traces t
     WHERE t.[path] LIKE '%\SPTRACEHELPER%.trc';
    
    IF @TraceID IS NULL
      RAISERROR('  Could not find a currently created trace.',16,1) WITH NOWAIT;
    ELSE
      RAISERROR('  Created trace for SP_TRACE_HELPER found, ID is: %i',0,1,@TraceID) WITH NOWAIT;

    -- Stop the trace
    EXEC sp_trace_setstatus @TraceID, 0;

    RAISERROR('  Trace has been successfully stopped.',0,1) WITH NOWAIT;

  END; -- End ACTION='STOP'
  ELSE IF @Action = 'DELETE'
  BEGIN
    
    -- Try and find a trace already created
    SELECT @TraceID = t.id
      FROM sys.traces t
     WHERE t.[path] LIKE '%\SPTRACEHELPER%.trc';
    
    IF @TraceID IS NULL
      RAISERROR('  Could not find a currently created trace.',16,1) WITH NOWAIT;
    ELSE
      RAISERROR('  Created trace for SP_TRACE_HELPER found, ID is: %i',0,1,@TraceID) WITH NOWAIT;

    -- Delete the trace
    EXEC sp_trace_setstatus @TraceID, 2;

    RAISERROR('  Trace has been successfully deleted. Don''t forget to clean up any remaining trace files!',0,1) WITH NOWAIT;    

  END; -- End ACTION='DELETE'
  ELSE IF @Action = 'READ'
  BEGIN

    -- If we don't specify a path, let's see if we can find one from a running / created trace.
    IF @TraceFilePath IS NULL
    BEGIN
      -- Try and find a trace already created
      SELECT @TraceFilePath = substring(t.path,1,patindex('%SPTRACEHELPER%.trc',t.path)-1)
        FROM sys.traces t
        WHERE t.[path] LIKE '%\SPTRACEHELPER%.trc';
      RAISERROR('  Created trace for SP_TRACE_HELPER found, path is: %s',0,1,@TraceFilePath) WITH NOWAIT;

      IF @TraceFilePath IS NULL
        RAISERROR('Could not find a currently created trace, and a path was not specified.',16,1) WITH NOWAIT;
    END;

    SET @TraceFileFullPath = @TraceFilePath + @TraceFileName + '.trc';
    
    SELECT ftg.EventSequence,
           te.name AS [Event Class Name],
           ftg.StartTime,
           ftg.EndTime,
           ftg.SPID AS SessionID,
           ftg.HostName,
           ftg.LoginName,
           ftg.ApplicationName,
           ftg.TextData,
           ftg.Duration AS [Duration in MicroSeconds],
           ftg.CPU AS [CPU Usage in Milliseconds],
           ftg.Reads,
           ftg.Writes
      FROM sys.fn_trace_gettable(@TraceFileFullPath,null) ftg JOIN sys.trace_events te
             ON ftg.EventClass = te.trace_event_id
     WHERE (ftg.HostName LIKE @Host OR @Host IS NULL)
           AND (ftg.SPID = @SessionID OR @SessionID IS NULL)
           AND (ftg.ApplicationName LIKE @Application OR @Application IS NULL)
           AND (ftg.DatabaseName LIKE @Database OR @Database IS NULL)
    ORDER BY ftg.EventSequence ASC;

  END; -- END Action='READ'


END TRY
BEGIN CATCH

  DECLARE @ERROR_MESSAGE NVARCHAR(2048);
  DECLARE @ERROR_SEVERITY TINYINT;
  DECLARE @ERROR_NUMBER INT;
  
  SET @ERROR_MESSAGE = CASE ERROR_NUMBER()
                         WHEN 19067 THEN 'Unable to create a new trace since one for SP_TRACE_HELPER is already running.'
                         WHEN 19052 THEN 'We cannot delete a trace while it is running. Specify @ACTION = ''STOP'' first, then retry.'
                         ELSE 'LINE: ' + CONVERT(varchar,ERROR_LINE()) +
                              ', NUM: ' + CONVERT(varchar,ERROR_NUMBER()) + 
                              ', ' + ERROR_MESSAGE()
                       END;
  SET @ERROR_NUMBER = ERROR_NUMBER();
  SET @ERROR_SEVERITY = ERROR_SEVERITY();

  IF XACT_STATE() <> 0
    ROLLBACK;
  
  RAISERROR(@ERROR_MESSAGE,@ERROR_SEVERITY,1);
  
END CATCH;
