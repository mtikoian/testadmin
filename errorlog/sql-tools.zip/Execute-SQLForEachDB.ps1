﻿<#
.SYNOPSIS
Used to execute a query against all databases hosted on a Azure SQL server (i.e. a collection of Azure SQL Databases).
.DESCRIPTION
Allows a query to be executed against all Azure SQL Database instances for a particular "server". Note that
the concept of a "Server" is not the same as for traditional SQL, in that a "Server" in Azure SQL Database terms 
is merely a logical grouping of databases accessible under a specific connection.

The function returns all retrieved records as DataRow objects to the pipeline. If you want the name of the database retruned as a column, use the "@DatabaseName"
SQL variable in your query.

Note that unlike the built-in sp_msforeachdb, the query executes in the context of the selected database. No USE statement is necessary,
nor will it work if used due to limitations in Azure.

.PARAMETER SqlServerName
The name (FQDN) of the Azure SQL Server instance to connect to.

.PARAMETER UserNameText
The User ID to connect to the Azure SQL Server instance. It is usually best to use the global server 
administrator to ensure proper permissions.

.PARAMETER PasswordText
The Password to connect to the Azure SQL Server instance.

.PARAMETER QueryText
The text of the query to execute against all Azure SQL Databases.

.EXAMPLE
Execute-SqlForEachDB -SqlServerName myserver.database.windows.net -UserNameText MyServerAdmin -PasswordText MyPassword -QueryText "SELECT * FROM dbo.SomeTable";

.NOTES
Function is (c) 2016 Josh Feierman, all rights reserved. Free for personal, educational, and internal corporate use.
Any redistribution, in whole or in part, without the express written consent of the author, is prohibited.

#>
function Execute-SqlForEachDB
{
    [cmdletbinding()]
    param
    (
        [parameter(mandatory=$true,ValueFromPipelineByPropertyName=$true)]
        [string]$SqlServerName,
        [parameter(mandatory=$true)]
        $UserNameText,
        [parameter(mandatory=$true)]
        [object]$PasswordText,
        [parameter(mandatory=$true)]
        $QueryText
    )
    begin
    {
        Set-StrictMode -Version 2.0;
        
        [System.Data.SqlClient.SqlConnection]$masterSqlConn = $null;
        [System.Data.SqlClient.SqlCommand]$masterSqlCmd = $null;
        [System.Data.SqlClient.SqlDataReader]$masterDataReader = $null;

        [System.Data.SqlClient.SqlConnection]$dbSqlConn = $null;
        [System.Data.SqlClient.SqlCommand]$dbSqlCmd = $null;
        [System.Data.SqlClient.SqlDataReader]$dbDataReader = $null;
        [System.Data.DataTable]$dt = $null;
        [System.Data.DataRow]$row = $null;

        $QueryErrors = @();
        [System.Exception]$Exception = $null;
    }
    process
    {
        try
        {
            # Create and open master connection
            $masterSqlConn = New-Object System.Data.SqlClient.SqlConnection;
            $masterSqlConn.ConnectionString = "Data Source=$SqlServerName;Initial Catalog=master;User ID=$UserNameText;Password=$PasswordText;"
            $masterSqlConn.Open();

            # Retrieve a list of available databases
            $masterSqlCmd = $masterSqlConn.CreateCommand();
            $masterSqlCmd.CommandText = "SELECT name FROM sys.databases;";
            $masterDataReader = $masterSqlCmd.ExecuteReader();

            # Iterate over the databases
            if ($masterDataReader.HasRows)
            {
                # Instantiate DB specific components
                $dbSqlConn = New-Object System.Data.SqlClient.SqlConnection;

                while ($masterDataReader.Read())
                {
                    Write-Verbose "Starting on database $($masterDataReader[0]).";
                    $dbSqlConn.ConnectionString = "Data Source=$SqlServerName;Initial Catalog=$($masterDataReader[0]);User ID=$UserNameText;Password=$PasswordText;"
                    try
                    {
                        $dbSqlConn.Open();
                        $dbSqlCmd = $dbSqlConn.CreateCommand();
                        $dbSqlCmd.CommandText = $QueryText;
			            $dbSqlCmd.Parameters.Add("@DatabaseName",[System.Data.SqlDbType]::NVarChar,128).Value = $masterDataReader[0];
                        $dbDataReader = $dbSqlCmd.ExecuteReader();
                        if ($dbDataReader.HasRows)
                        {
                            $dt = New-Object System.Data.DataTable;
                            $dt.Load($dbDataReader);
                            foreach ($row in $dt.Rows)
                            {
                                Write-Output $row;
                            }
                            $dt.Dispose();
                        }
                    }
                    catch
                    {
                        $QueryErrors += New-Object System.Exception ("Error occurred processing database $($masterDataReader[0]): $($_.Exception.Message).");
                    }
                    finally
                    {
                        # This nested try is because Powershell attempts to iterate over the 
                        # Datareader object so I can't check if it is equal to $null.
                        # If this fails then the Datareader was likely never instantiated
                        # anyway.
                        try
                        {
                            if ($dbDataReader.IsClosed -eq $false)
                            {
                                $dbDataReader.Close();
                            }
                        }
                        catch
                        {
                            # Do nothing
                        }
                        if ($dbSqlConn.State -ne [System.Data.ConnectionState]::Closed)
                        {
                            $dbSqlConn.Close();
                        }
                    }
                }
            }
        }
        catch
        {
            throw $_;
        }
        finally
        {
            if ($masterDataReader -ne $null)
            {
                if ($masterDataReader.IsClosed -eq $false)
                {
                    $masterDataReader.Close();
                }
                $masterDataReader = $null;
            }
            if ($masterSqlConn -ne $null)
            {
                if ($masterSqlConn.State -ne [System.Data.ConnectionState]::Closed)
                {
                    $masterSqlConn.Close();
                }
                $masterSqlConn.ConnectionString = "";
                $masterSqlConn.Dispose();
            }
            if (-not ($masterSqlCmd -eq $null))
            {
                $masterSqlCmd = $null
            }
            if ($dbSqlConn -ne $null)
            {
                if ($dbSqlConn.State -ne [System.Data.ConnectionState]::Closed)
                {
                    $dbSqlConn.Close();
                }
                $dbSqlConn.ConnectionString = "";
                $dbSqlConn.Dispose();
            }
            if (-not ($dt -eq $null))
            {
                $dt.Dispose();
            }
        }
        
    }
    end
    {
        if ($QueryErrors.Count -gt 0)
        {
            foreach ($QueryError in $QueryErrors)
            {
                Write-Warning $QueryError.Message;
            }
            Write-Error "One or more errors occurred during execution. Review output for details.";
        }
    }
}