USE master;
GO

IF NOT EXISTS (
  SELECT 1
    FROM INFORMATION_SCHEMA.ROUTINES r
   WHERE r.SPECIFIC_SCHEMA = 'dbo'
         AND r.SPECIFIC_NAME = 'sp_get_block_chain'
)
  EXEC ('CREATE PROCEDURE dbo.sp_get_block_chain AS BEGIN PRINT ''This is a stub routine.''; END;');
GO

/**********************************************************************

=help
sp_get_block_chain v1.0
(c) 2014 Joshua Feierman

Feedback: mailto:josh@sqljosh.com

To receive updates of when I fix things or make this better, sign up at https://bit.ly/sqljosh.

Author: Josh Feierman

License:
  sp_get_block_chain is free to download and use for personal, educational, and internal
  purposes, provided this license and all original attributions are included.
  Redistribution or sale in whole or in part is prohibited without the author's 
  express written consent. By installing and / or executing this procedure in your environment
  you accept any and all risk associated with running it. Always test in a non-production
  system first!

About:
  This stored procedure helps to retrieve the blocking chain for blocked
  SQL Server processes as well as certain information which is useful in 
  troubleshooting locks.

Parameters:
  @show_locks - if specified as 1 (default), will collect detailed locks held (or trying
  to be acquired) by processes in the blocking chain. This can make the procedure
  run for an extended period of time, so you may want to try 0 if the procedure
  is not finishing within an acceptable amount of time.

  @show_sql - if specified as 1 (default), will collect the currently executing SQL statement
  of all processes in the block chain.

  ----
  The following parameters are for use when persisting block chains to a 
  table in the database.
  ----
  @create_table - if specified as 1 (0 is default), will attempt to create a table of appropriate
  setup for storing results from this procedure. @table_db, @table_schema, and @table_name must
  also be specified.

  @table_db - if specified (defaults to null) represents the database name in which the table to store
  results resides.

  @table_schema - if specified (defaults to null) represents the schema name in which the table to store
  results resides.

  @table_name - if specified (defaults to null) represents the name of the table in which to store results.

Examples:

  exec sp_block_chain @show_locks=1, @show_sql=1 - will simply show the blocking chain along with SQL and lock information.

  If you wish to store the results in a table, first execute:
    exec sp_get_block_chain @create_table = 1,
                        @table_db = '<database name>',
                        @table_schema = '<schema name>',
                        @table_name = '<table name>';
  
  This will create the table. Thereafter, use this:
    exec sp_get_block_chain @table_db = '<database name>',
                        @table_schema = '<schema name>',
                        @table_name = '<table name>';

  This will store the results in the table specified.

  When executing from SQL Management Studio, it's best to ensure that SSMS is configured to retrieve all of the XML data returned,
  so that complete results are captured. This is configured by selecting Options from the Tools menu, selecting Query Results,
  SQL Server, Results to Grid, then selecting "Maximum" under the "Maximum Characters To Be Retrieved" -> "XML" dropdown menu.

=endhelp

***********************************************************************/
ALTER PROCEDURE dbo.sp_get_block_chain 
  @show_locks bit = 1,
  @show_sql bit = 1,
  -- 1/5/2015 JFEIERMAN - Begin change to support storing results in table.
  @create_table bit = 0,
  @table_db sysname = null,
  @table_schema sysname = null,
  @table_name sysname = null,
  @help bit = 0
  -- 1/5/2015 JFEIERMAN - End change to support storing results in table.
AS

SET NOCOUNT ON;
DECLARE @database_name sysname,
        @sql nvarchar(max),
        @MessageText nvarchar(max),
        -- 1/5/2015 JFEIERMAN - Begin change to support storing results in table.
        @table_exists bit;
        -- 1/5/2015 JFEIERMAN - End change to support storing results in table.

IF @Help = 1
BEGIN

  SELECT @SQL = dest.text
    FROM sys.dm_exec_requests r CROSS APPLY sys.dm_exec_sql_text(r.sql_handle) dest
    WHERE r.session_id = @@SPID;
  --PRINT @SQL;
  -- Cut up the SQL text and get the help section
  SET @MessageText = SUBSTRING(@SQL,
                        CHARINDEX('=help',@SQL),
                        CHARINDEX('=endhelp',@SQL)-CHARINDEX('=help',@SQL)+8
                      );

  PRINT @MessageText;
  RETURN;

END;

if object_id('tempdb..#locks') is not null
  drop table #locks;
IF OBJECT_ID('tempdb..#sysprocesses') IS NOT NULL 
  DROP TABLE #sysprocesses;

BEGIN TRY

  SELECT * INTO #sysprocesses FROM sys.sysprocesses s
  ;WITH block_chain as
  (
    SELECT s.spid AS session_id,
           s.status,
           convert(int,NULL) AS blocking_session_id,
           s.spid AS lead_blocking_session_id,
           convert(varchar(100),convert(varchar,s.spid) + '/') AS block_chain,
           s.sql_handle,
           0 AS block_nest_level
      FROM #sysprocesses s
      --FROM sys.sysprocesses s
     WHERE s.blocked = 0
           AND EXISTS (
            SELECT 1
              FROM #sysprocesses s2
              --FROM sys.sysprocesses s2
             WHERE s2.blocked = s.spid
           )
    UNION ALL
    SELECT s.spid AS session_id,
           s.status,
           convert(int,b.session_id) AS blocking_session_id,
           b.lead_blocking_session_id AS lead_blocking_session_id,
           convert(varchar(100),b.block_chain + convert(varchar,s.spid) + '/') AS block_chain,
           s.sql_handle,
           b.block_nest_level + 1 AS block_nest_level         
      FROM #sysprocesses s JOIN block_chain b
      --FROM sys.sysprocesses s JOIN block_chain b
            ON s.blocked = b.session_id
     WHERE s.blocked > 0
  )
  SELECT tl.request_session_id AS session_id,
         des.program_name,
         des.host_name,
         s.status,
         s.blocking_session_id,
         s.lead_blocking_session_id,
         s.block_nest_level,
         tl.resource_type,
         tl.resource_subtype,
         tl.request_mode,
         tl.request_type,
         tl.request_status,
         tl.resource_description,
         der.wait_type,
         der.wait_time,
         coalesce(der.sql_handle,s.sql_handle) AS sql_handle,
         case des.transaction_isolation_level
          WHEN 0 THEN 'Unspecified'
	     WHEN 1 THEN 'ReadUncomitted'
	     WHEN 2 THEN 'ReadCommitted'
	     WHEN 3 THEN 'RepeatableRead'
	     WHEN 4 THEN 'Serializable'
	     WHEN 5 THEN 'Snapshot'
         END AS transaction_isolation_level,
         d.name AS database_name,
         CASE 
          WHEN tl.resource_type = 'OBJECT' THEN convert(int,tl.resource_associated_entity_id)
          -- 1/31/2016 JFEIERMAN - Begin change to include database principal locks
          WHEN resource_subtype = 'DATABASE_PRINCIPAL' THEN CONVERT(int,SUBSTRING(tl.resource_description,15,datalength(resource_description)-15))
          -- 1/31/2016 JFEIERMAN - End change to include database principal locks
          ELSE NULL
         END AS object_id,
         CASE 
          WHEN tl.resource_type = 'FILE' THEN CONVERT(varchar,tl.resource_description)
          WHEN tl.resource_type IN ('PAGE','EXTENT','RID') THEN LEFT(tl.resource_description,CHARINDEX(':',tl.resource_description)-1)
          ELSE NULL
         END AS file_id,
         CASE
          WHEN tl.resource_type IN ('PAGE', 'KEY', 'RID', 'HOBT') THEN tl.resource_associated_entity_id
	     ELSE NULL
	    END AS hobt_id,
         cast(NULL AS sysname) AS object_name,
         cast(NULL AS sysname) AS index_name,
         s.block_chain
    INTO #locks
    FROM sys.dm_tran_locks tl JOIN block_chain s
           ON tl.request_session_id = s.session_id
         INNER JOIN sys.dm_exec_sessions des
           ON s.session_id = des.session_id
         INNER JOIN sys.databases d
           ON tl.resource_database_id = d.database_id
         LEFT JOIN sys.dm_exec_requests der
           ON s.session_id = der.session_id
   --where tl.request_status = 'wait'
  OPTION (MAXRECURSION 1000)           ;

  IF @show_locks = 1 BEGIN
    DECLARE db_cursor CURSOR FAST_FORWARD FOR
      SELECT DISTINCT l.database_name 
        FROM #locks l;

    OPEN db_cursor;

    WHILE 1=1 BEGIN

      FETCH db_cursor INTO @database_name;

      IF @@FETCH_STATUS <> 0 BREAK;

      SET @SQL = '
      UPDATE l
-- 1/31/2016 JFEIERMAN - Begin change to include database principal locks
         SET l.object_name = coalesce(o.name,dp.name),
-- 1/31/2016 JFEIERMAN - End change to include database principal locks
             l.index_name = i.name
        FROM #locks l LEFT JOIN ' + quotename(@database_name) + '.sys.partitions p2 (NOLOCK)
              ON l.hobt_id = p2.hobt_id
-- 1/31/2016 JFEIERMAN - Begin change to include database principal locks
                 AND l.resource_type IN (''key'',''PAGE'',''RID'',''EXTENT'',''HOBT'')
-- 1/31/2016 JFEIERMAN - End change to include database principal locks
                 --AND l.request_status in (''wait'',''convert'')
              LEFT JOIN ' + quotename(@database_name) + '.sys.objects o (NOLOCK)
              ON o.object_id = COALESCE(l.object_id,
                                        p2.object_id) 
-- 1/31/2016 JFEIERMAN - Begin change to include database principal locks
              AND l.resource_type IN (''key'',''PAGE'',''RID'',''EXTENT'',''HOBT'')
-- 1/31/2016 JFEIERMAN - End change to include database principal locks
              LEFT JOIN ' + quotename(@database_name) + '.sys.indexes i (NOLOCK)
              ON i.object_id = COALESCE(l.object_id,
                                        p2.object_id) 
                  AND i.index_id = p2.index_id
-- 1/31/2016 JFEIERMAN - Begin change to include database principal locks
              LEFT JOIN ' + quotename(@database_name) + '.sys.database_principals dp WITH (NOLOCK)
              ON dp.principal_id = l.object_id
                 AND l.resource_subtype = ''DATABASE_PRINCIPAL''
-- 1/31/2016 JFEIERMAN - End change to include database principal locks
        WHERE l.database_name = @database_name;';
      BEGIN TRY
        EXEC sp_executesql @sql,N'@database_name sysname',@database_name;
      END TRY
      BEGIN CATCH

        UPDATE l
           SET l.object_name = '#Error: ' + ERROR_MESSAGE(),
               l.index_name  = '#Error: ' + ERROR_MESSAGE()
          FROM #locks l
         WHERE l.database_name = @database_name;
  
      END CATCH
    END;

  CLOSE db_cursor;
  DEALLOCATE db_cursor;

  END;

  -- 1/5/2015 JFEIERMAN - Begin change to support storing results in table.
  -- If a table is specified, check to make sure it exists.
  IF @table_db IS NOT NULL
     AND @table_schema IS NOT NULL
     AND @table_name IS NOT NULL
  BEGIN
    
    -- First we check if it exists or not.
    SET @sql = 'IF EXISTS (SELECT 1 ' + 
               '             FROM ' + QUOTENAME(@table_db) + '.INFORMATION_SCHEMA.TABLES ' + 
               '            WHERE TABLE_SCHEMA = @table_schema' +
               '                  AND TABLE_NAME = @table_name' +
               ')' +
               '  SET @table_exists = 1;' +
               'ELSE' +
               '  SET @table_exists = 0;';
    exec sp_executesql @sql,
                       N'@table_schema sysname,@table_name sysname,@table_exists bit output',
                       @table_schema,
                       @table_name,
                       @table_exists OUTPUT;
    IF @table_exists = 0
    BEGIN
      -- If we specified to create the table, go ahead and do it.
      IF @create_table = 1
      BEGIN
        SET @sql = 'USE ' + QUOTENAME(@table_db) + ';
                   CREATE TABLE ' + QUOTENAME(@table_schema) + '.' + QUOTENAME(@table_name) + '
                    (
                      collection_dt datetime NOT NULL default CURRENT_TIMESTAMP,
                      session_id int NOT NULL,
                      program_name nvarchar(256) NOT NULL,
                      host_name nvarchar(256) NOT NULL,
                      status nvarchar(30) NOT NULL,
                      transaction_isolation_level nvarchar(30) NOT NULL,
                      blocking_session_id int NULL,
                      block_chain nvarchar(1000) NOT NULL,
                      wait_type nvarchar(32) NULL,
                      wait_time bigint NULL,
                      sql_text nvarchar(max) NULL,
                      locks XML NULL
                    );
                    CREATE CLUSTERED INDEX [CI_' + @table_name + '] ON ' + QUOTENAME(@table_schema) + '.' + QUOTENAME(@table_name) + '
                    (
                      collection_dt
                    );';
        exec sp_executesql @sql;
      END;
      -- Otherwise we can't go on.
      ELSE
        RAISERROR('The table specified (%s.%s.%s) does not exist. Specify @create_table = 1 if you want it created.',
                  16,
                  1,
                  @table_db,
                  @table_schema,
                  @table_name) WITH NOWAIT;
    END; -- End if the table doesn't exist.
    
    -- Add the insert statement to the SELECT.
    SET @SQL = 'INSERT INTO ' + QUOTENAME(@table_db) + '.' + QUOTENAME(@table_schema) + '.' + QUOTENAME(@table_name) + '
                (
                  session_id,
                  program_name,
                  host_name,
                  status,
                  transaction_isolation_level,
                  blocking_session_id,
                  block_chain,
                  wait_type,
                  wait_time,
                  sql_text,
                  locks
                )';
  END; -- End if we specified a table to persist the data in.
  ELSE -- otherwise we need to clear out the @SQL variable
    SET @sql = '';

  -- Construct the final statement
  SET @SQL = @SQL + '
  SELECT s.session_id,
         s.program_name,
         s.host_name,
         s.status,
         s.transaction_isolation_level,
         s.blocking_session_id,
         RTRIM(ltrim(s.block_chain)) AS block_chain,
         s.wait_type,
         s.wait_time,
         case @show_sql
          when 1 then replace(replace(replace(dest.text,char(13),''\r''),char(9),''\t''),char(10),''\n'')
          ELSE NULL
         end AS sql_text,
         (
            SELECT  l2.database_name AS [database/@name],
                    (
                      SELECT COALESCE(l3.object_name,''DATABASE'') AS [object/@name],
                             l3.index_name as [object/@index],
                             l3.resource_type AS [object/request/@type],
                             l3.request_mode AS [object/request/@mode],
                             l3.request_status AS [object/request/@status],
                             case l3.resource_type 
                              when ''KEY'' then ltrim(rtrim(l3.resource_description))
                              else null
                             end AS [object/request/@lockres]
                        FROM #locks l3 
                       WHERE l3.session_id = l2.session_id
                             AND l3.database_name = l2.database_name
                      FOR XML PATH (''''),TYPE
                    ) as [database/locks]
              FROM #locks l2      
             WHERE l2.session_id = s.session_id
            GROUP BY l2.database_name,l2.session_id
            ORDER BY l2.database_name
            FOR XML PATH(''''),type
          ) AS locks
    FROM   (
              SELECT DISTINCT 
                     l.session_id, 
                     l.status,
                     l.program_name,
                     l.host_name,
                     l.transaction_isolation_level,
                     l.sql_handle,
                     l.wait_type,
                     l.wait_time,
                     l.blocking_session_id,
                     l.lead_blocking_session_id,
                     l.block_nest_level,
                     l.block_chain
                FROM #locks l
            ) s OUTER APPLY sys.dm_exec_sql_text(s.sql_handle) dest
  ORDER BY s.lead_blocking_session_id, s.block_chain;'

  EXEC sp_executesql @sql,
                     N'@show_locks bit,@show_sql bit',
                     @show_locks,
                     @show_sql;
  -- 1/5/2015 JFEIERMAN - End change to support storing results in table.

END TRY
BEGIN CATCH

  DECLARE @ERROR_MESSAGE NVARCHAR(2048);
  DECLARE @ERROR_SEVERITY TINYINT;
  DECLARE @ERROR_NUMBER INT;
  
  SET @ERROR_MESSAGE = ERROR_MESSAGE();
  SET @ERROR_NUMBER = ERROR_NUMBER();
  SET @ERROR_SEVERITY = ERROR_SEVERITY();

  RAISERROR(@ERROR_MESSAGE,@ERROR_SEVERITY,1);
  
END CATCH;

if object_id('tempdb..#locks') is not null
  drop table #locks;

GO