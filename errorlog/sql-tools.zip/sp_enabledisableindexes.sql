USE master;
GO

IF NOT EXISTS (SELECT 1
                 FROM INFORMATION_SCHEMA.ROUTINES
                WHERE ROUTINE_NAME = 'sp_enabledisableindexes'
                  AND ROUTINE_SCHEMA = 'dbo')
BEGIN
  EXEC ('CREATE PROCEDURE dbo.sp_enabledisableindexes AS BEGIN PRINT ''STUB FOR PROCEDURE'' END');
END  
GO

/***
================================================================================
=help
sp_enabledisableindexes v1.0
(c) 2014 Joshua Feierman

Feedback: mailto:josh@sqljosh.com

To receive updates of when I fix things or make this better, sign up at https://bit.ly/sqljosh.

Author: Josh Feierman

License:
  sp_enabledisableindexes is free to download and use for personal, educational, and internal
  purposes, provided this license and all original attributions are included.
  Redistribution or sale in whole or in part is prohibited without the author's 
  express written consent. By installing and / or executing this procedure in your environment
  you accept any and all risk associated with running it. Always test in a non-production
  system first!

About:
  A stored procedure for enabling / disabling all indices on a 
  particular table. Since it is installed in the 'master' database
  and marked as a system object it can be run in the context of any user
  database.

Parameters   : 
  @i_EnableDisable_Fl     :      A flag to designate whether we want to enable all disabled indices ('E')
                          :      or disable all enabled indices ('D').
  @i_Schema_Name          :      The schema name of the object to target.
  @i_Table_Name           :      The name of the object to target.
  @i_Exclude_Unique_Fl    :      If set to 1, will not disable unique indices. Useful when loading data to
                          :      ensure constraints are not violated.
  @i_ForReal_Fl           :      If set to 1, will actually perform the desired action. If set to 0,
                          :      the generated SQL is printed out and nothing is done. Defaults to 0.
  @i_Column_To_Exclude_Nm :      When a value is provided, any index with the provided column name
                          :      as a leading column is not disabled. Useful for purging data so that
                          :      a full table scan may not occur.
  @i_MaxDOP               :      Indicates the maximum parallel threads used when enabling indices.
                          :      When not specified option MAXDOP=1 will be used.
  @i_Online               :      When set to 1 and the edition of SQL is Enterprise or Developer,
                                 indexes will be rebuilt in online mode.
Revisions    :
--------------------------------------------------------------------------------
Ini|   Date   | Description
--------------------------------------------------------------------------------

================================================================================
***/

ALTER PROCEDURE dbo.sp_enabledisableindexes
  @i_EnableDisable_Fl char(1),
  @i_Schema_Name sysname,
  @i_Table_Name sysname,
  @i_Exclude_Unique_Fl bit = 1,
  @i_ForReal_Fl bit = 0,
  @i_Column_To_Exclude_Nm sysname = NULL,
  @i_MaxDOP tinyint = NULL,
  @i_Online bit = 1
AS

DECLARE @SQL nvarchar(max);

SET @SQL = (
    SELECT
      'RAISERROR('
      + QUOTENAME(CASE @i_EnableDisable_Fl
                    WHEN 'E' THEN 'Enabling '
                    ELSE 'Disabling '
                  END + ' index ' + sidx.name + ' on table ' + ssch.name + '.' + sobj.name,
                  '''') + ',10,1) with nowait;'
      +'ALTER INDEX ' 
        + quotename(sidx.name) 
        + ' ON ' 
        + quotename(ssch.name) 
        + '.' + quotename(sobj.name) 
        + ' '
        + case @i_EnableDisable_Fl
            when 'E' then 'REBUILD' + ' WITH (MAXDOP='+CASE
                                                        WHEN @i_MaxDOP IS NULL THEN convert(varchar,1)
                                                        ELSE convert(varchar,@i_MaxDOP)
                                                      END +
                                                      ',ONLINE=' + CASE
                                                                    WHEN (@i_Online = 1 AND SERVERPROPERTY('EngineEdition') = 3)
                                                                      THEN 'ON'
                                                                    ELSE 'OFF'
                                                                   END +
                                             ')'
            when 'D' then 'DISABLE'
          END
        + ';'
    FROM
      sys.schemas ssch join sys.objects sobj
        on ssch.schema_id = sobj.schema_id
           and ssch.name = @i_Schema_Name
           and (sobj.name = @i_Table_Name or @i_Table_Name = '')
      join sys.indexes sidx
        on sobj.object_id = sidx.object_id
           and sidx.is_primary_key = 0 -- exclude primary keys
           and sidx.is_unique = case when @i_Exclude_Unique_Fl = 1 then 0 else sidx.is_unique end -- exclude unique indexes
           and sidx.index_id > 1 -- exclude clustered index and heap
           and sidx.is_disabled = case @i_EnableDisable_Fl
                                    when 'E' then 1 -- only include disabled indexes when the "Enable" option is set
                                    when 'D' then 0 -- only include enabled indexes when the "Disable" option is set
                                  END
  WHERE
    NOT EXISTS (
      SELECT 1
        FROM sys.index_columns ic JOIN sys.columns c
              ON c.column_id = ic.column_id
                 AND c.object_id = ic.object_id
       WHERE ic.index_id = sidx.index_id
             AND ic.object_id = sidx.object_id
             AND c.name = @i_Column_To_Exclude_Nm
             AND ic.key_ordinal = 1
             AND ic.is_included_column = 0
    )
  FOR XML PATH('')
);

IF @i_ForReal_Fl = 1
  EXEC sp_executesql @SQL;
ELSE IF @SQL IS NOT NULL
  PRINT @SQL;

GO

-- We mark this as a system object so that it can be used in the context of any database.
EXEC sys.sp_MS_marksystemobject
	@objname = N'dbo.sp_enabledisableindexes';