USE master;
IF NOT EXISTS (SELECT 1
                 FROM INFORMATION_SCHEMA.ROUTINES
                WHERE ROUTINE_NAME = 'sp_balance_data_file'
                  AND ROUTINE_SCHEMA = 'dbo')
BEGIN
  EXEC ('CREATE PROCEDURE dbo.sp_balance_data_file AS BEGIN PRINT ''STUB FOR PROCEDURE'' END');
END  
GO

/***
=help
sp_balance_data_file v1.0
(c) 2014 Joshua Feierman

Author: Josh Feierman

License:
  sp_balance_data_file is free to download and use for personal, educational, and internal
  purposes, provided this license and all original attributions are included.
  Redistribution or sale in whole or in part is prohibited without the author's 
  express written consent. By installing and / or executing this procedure in your environment
  you accept any and all risk associated with running it. Always test in a non-production
  system first!

Feedback: mailto:josh@sqljosh.com

To receive updates of when I fix things or make this better, sign up at https://bit.ly/sqljosh.

About:

  This stored procedure is used to calculate the ideal size for data files in a SQL Server database.
  It does this by looking at the current size of the data, plus the size of the largest index (to 
  allow for index rebuilds). If a value for @Size_Pad_Pct is specified, the procedure then adds enough
  size to the files such that they will have this percent free when all operations are complete.
  It then proportionally balances the calculated size across all data files in the file group, so IO 
  is split evently between them. The procedure also generates the commands required to either grow or 
  shrink the data files. Use caution when executing (especially when shrinking) as these may generate 
  a lot of disk IO. Before growing data files consider ensuring that instant file initialization is enabled, 
  by following the instructions at this link: http://bit.ly/instantfileinitialization. 

================================================================================
=endhelp
***/

ALTER PROCEDURE dbo.sp_balance_data_file
  @Size_Pad_Pct float = 0.00,
  @Database_Nm sysname = null,
  @Help bit = 0
AS

DECLARE @SQL nvarchar(max);
DECLARE @MessageText nvarchar(max);

IF @Help = 1
  BEGIN

    SELECT @SQL = dest.text
      FROM sys.dm_exec_requests r CROSS APPLY sys.dm_exec_sql_text(r.sql_handle) dest
     WHERE r.session_id = @@SPID;
    --PRINT @SQL;
    -- Cut up the SQL text and get the help section
    SET @MessageText = SUBSTRING(@SQL,
                         CHARINDEX('=help',@SQL),
                         CHARINDEX('=endhelp',@SQL)-CHARINDEX('=help',@SQL)+8
                        );

    PRINT @MessageText;
    RETURN;

  END;

IF object_id('tempdb..#DatabaseFileGroups') is not null
  drop table #DatabaseFileGroups;
create table #DatabaseFileGroups 
(
  Database_Nm sysname,
  File_Group_Nm sysname,
  Size_Mb float,
  Used_Size_Mb float,
  Largest_Index_Size_Mb float
);


BEGIN TRY

  IF @Database_Nm IS NULL
    SET @Database_Nm = DB_NAME();

  SET @SQL = '
  INSERT #DatabaseFileGroups
  SELECT ' + QUOTENAME(@Database_Nm,'''') + ' as Database_Nm,
         ds.name COLLATE SQL_Latin1_General_CP1_CI_AS AS File_Group_Nm,
         df.Data_File_Size_Mb,
         sum(au.used_pages * 8.00 / 1024.00) AS Used_Size_Mb,
         NULL AS Largest_Index_Size_MB
    FROM ' + quotename(@Database_Nm) + '.sys.data_spaces ds JOIN ' + quotename(@Database_Nm) + '.sys.allocation_units au
          ON au.data_space_id = ds.data_space_id
         JOIN (
                SELECT df.data_space_id,
                       sum(df.size) * 8 / 1024.00 AS Data_File_Size_Mb
                  FROM ' + quotename(@Database_Nm) + '.sys.database_files df
                 WHERE df.type_desc COLLATE SQL_Latin1_General_CP1_CI_AS = ''ROWS''
                GROUP BY df.data_space_id
              ) df
          ON df.data_space_id = ds.data_space_id
   GROUP BY ds.name,df.Data_File_Size_Mb;'
  EXEC sp_executesql @SQL,N'@Size_Pad_Pct float',@Size_Pad_Pct;
  
  SET @SQL = '
  WITH Largest_Index AS 
  (
    SELECT ROW_NUMBER() OVER (PARTITION BY ds.name ORDER BY sum(au.total_pages) DESC) AS row_num,
           ds.name COLLATE SQL_Latin1_General_CP1_CI_AS AS File_Group_Nm,
           i.name COLLATE SQL_Latin1_General_CP1_CI_AS AS Index_Nm,
           sum(au.total_pages) * 8 / 1024 AS Largest_Index_Size_Mb
      FROM ' + quotename(@Database_Nm) + '.sys.allocation_units au JOIN ' + quotename(@Database_Nm) + '.sys.partitions p
             ON au.container_id = CASE au.type
                                      WHEN 1 THEN p.hobt_id
                                      WHEN 2 THEN p.partition_id
                                      WHEN 3 THEN p.hobt_id
                                  END
           JOIN ' + quotename(@Database_Nm) + '.sys.indexes i
             ON p.object_id = i.object_id
                AND p.index_id = i.index_id
           --JOIN sys.objects o
           --  ON o.object_id = i.object_id
           JOIN ' + quotename(@Database_Nm) + '.sys.data_spaces ds
             ON ds.data_space_id = au.data_space_id
    GROUP BY i.name,ds.name
  )
  UPDATE d
     SET d.Largest_Index_Size_Mb = l.Largest_Index_Size_Mb
    FROM #DatabaseFileGroups d JOIN Largest_Index l
          ON l.File_Group_Nm COLLATE SQL_Latin1_General_CP1_CI_AS = d.File_Group_Nm
   WHERE l.row_num = 1;'
  EXEC sp_executesql @SQL,N'@Size_Pad_Pct float',@Size_Pad_Pct;

  SET @SQL ='
  WITH File_Sizes AS
  (
    SELECT d.File_Group_Nm,
           d.Database_Nm,
            df.name COLLATE SQL_Latin1_General_CP1_CI_AS AS File_Nm,
            d.Size_Mb,
            d.Used_Size_Mb,
            d.Largest_Index_Size_Mb,
            d.Used_Size_Mb + d.Largest_Index_Size_Mb + d.Used_Size_Mb * @Size_Pad_Pct AS Total_Calc_Size_Mb,
            COUNT(1) OVER (PARTITION BY d.File_Group_Nm) AS File_Count,
            df.size * 8 / 1024 AS File_Size_Mb,
            convert(int,(d.Used_Size_Mb + d.Largest_Index_Size_Mb + d.Used_Size_Mb * @Size_Pad_Pct) / COUNT(1) OVER (PARTITION BY d.File_Group_Nm)) AS Calc_File_Size_Mb
      FROM #DatabaseFileGroups d JOIN ' + quotename(@Database_Nm) + '.sys.data_spaces ds
            ON ds.name COLLATE SQL_Latin1_General_CP1_CI_AS = d.File_Group_Nm
            JOIN ' + quotename(@Database_Nm) + '.sys.database_files df
            ON df.data_space_id = ds.data_space_id
  )
  SELECT  fs.Database_Nm,
          fs.File_Nm,
          fs.File_Size_Mb,
          fs.Used_Size_Mb,
          fs.Calc_File_Size_Mb,
          fs.Largest_Index_Size_Mb,
          CASE
          WHEN fs.Calc_File_Size_Mb > fs.File_Size_Mb THEN 1
          ELSE 0
          END AS Grow_Fl,
          CASE
            WHEN fs.Calc_File_Size_Mb > fs.File_Size_Mb THEN ''RAISERROR(''''Beginning grow operation for file '' + fs.File_Nm + '''''',10,1) with nowait;'' + 
                                                            ''ALTER DATABASE '' + QUOTENAME(DB_NAME()) + 
                                                            '' MODIFY FILE(NAME='' + QUOTENAME(fs.File_Nm,'''''''') + '',SIZE='' + convert(varchar(25),fs.Calc_File_Size_Mb) + ''mb);''
            ELSE ''RAISERROR(''''Beginning shrink operation for file '' + fs.File_Nm + '''''',10,1) with nowait;'' + 
                ''USE '' + QUOTENAME(fs.Database_Nm) + '';'' +
                ''DECLARE @CurrentSize bigint = '' + convert(varchar,fs.File_Size_Mb) + '','' +
                ''        @CalcSize bigint = '' + convert(varchar,fs.Calc_File_Size_Mb) + '';'' +
                ''WHILE @CurrentSize > @CalcSize BEGIN '' +
                ''  SET @CurrentSize = @CurrentSize - 4096; '' +
                ''  IF @CurrentSize < @CalcSize '' +
                ''    SET @CurrentSize = @CalcSize; '' +
                ''    RAISERROR(''''  Shrink size is %I64d MB'''',10,1,@CurrentSize) WITH NOWAIT; '' +
                ''  DBCC SHRINKFILE('' + QUOTENAME(fs.File_Nm,'''''''') + '',@CurrentSize);'' +
                ''END;''
          END  AS Alter_Cmd_Tx
    FROM File_Sizes fs
  ORDER BY 2 DESC;';

  EXEC sp_executesql @SQL,N'@Size_Pad_Pct float',@Size_Pad_Pct;

END TRY
BEGIN CATCH

  DECLARE @ERROR_MESSAGE NVARCHAR(2048);
  DECLARE @ERROR_SEVERITY TINYINT;
  DECLARE @ERROR_NUMBER INT;
  
  SET @ERROR_MESSAGE = ERROR_MESSAGE();
  SET @ERROR_NUMBER = ERROR_NUMBER();
  SET @ERROR_SEVERITY = ERROR_SEVERITY();

  --IF XACT_STATE() <> 0
  --  ROLLBACK;

  RAISERROR(@ERROR_MESSAGE,@ERROR_SEVERITY,1);
  
END CATCH;

IF object_id('tempdb..#DatabaseFileGroups') is not null
  drop table #DatabaseFileGroups;
GO

-- If this is installed in 'master', then mark it as a 
-- system object so it can be called in the context of 
-- any database.
IF DB_NAME() = 'master'
  EXEC sys.sp_MS_marksystemobject
	  @objname = N'dbo.sp_balance_data_file';