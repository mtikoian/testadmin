if exists(select 1 from master..sysprocesses where blocked<>0)
begin 

		select convert(char(24),getdate(),13)
		select 'Blockers causing the probelm'
		select distinct 
				'ID' = STR(SPID,5)
				,'Status' = convert(char(10),status)
				,'Blk' = str(blocked,2)
				,'Station' = convert(char(10), hostname)
				,'User'	   = convert(char(10), loginame)
				,'DBName'  = convert(char(10), db_name(dbid))
				,'Program' = convert(char(10), program_name)
				, 'Command'= convert(char(10), cmd)
				,'CPU'	   = STR(cpu,7)
				,'io'	   = STR(physical_io,7)
		from master..sysprocesses
		where spid in (select blocked from master..sysprocesses )
		and blocked = 0
		--order by str(spid,5)
		/*Victims*/

		select 'Victims of above Blockers'
		select distinct 
				'ID' = STR(SPID,5)
				,'Status' = convert(char(10),status)
				,'Blk' = str(blocked,2)
				,'Station' = convert(char(10), hostname)
				,'User'	   = convert(char(10), loginame)
				,'DBName'  = convert(char(10), db_name(dbid))
				,'Program' = convert(char(10), program_name)
				, 'Command'= convert(char(10), cmd)
				,'CPU'	   = STR(cpu,7)
				,'io'	   = STR(physical_io,7)
		from master..sysprocesses
		where blocked <> 0
		--order by spid 
END
	ELSE 
BEGIN
		Select 'There is no blocking at this time'
END