use msdb;
go
DECLARE @Jobname varchar(2000)
set @jobname  = 'Recreate historical stmts for backdated transactions'
--'Extract\Load Daily Statements for TD'
--'Extract\Load YTD Statements'
--'Extract\Load Daily Statements'
--'Load BSP Data Cache'
--'Adhoc Statement Load (Rob)'

--'DBAdmin_Daily_Maintenance_SystemDatabases'
---'DBAdmin_Daily_Maintenance_UserDatabases'
--'DBAdmin_Weekend_Maintenance_SystemDatabases'
--'DBAdmin_Weekend_Maintenance_UserDatabases'
SELECT 
     name,
     CONVERT(DATETIME,CONVERT(CHAR(8),run_date) + ' ' +  STUFF(STUFF((LEFT('000000',6-LEN(run_time))+ CONVERT(VARCHAR(6),run_time)),3,0,':'),6,0,':')) AS start_time,
     DATEADD(MINUTE,DATEDIFF(MINUTE, '0:00:00', CONVERT(dateTIME,STUFF(STUFF((LEFT('000000',6-LEN(run_duration))+ CONVERT(VARCHAR(6),run_duration)),3,0,':'),6,0,':'))),CONVERT(DATETIME,CONVERT(CHAR(8),run_date) + ' ' +  STUFF(STUFF((LEFT('000000',6-LEN(run_time))+ CONVERT(VARCHAR(6),run_time)),3,0,':'),6,0,':'))) AS end_time,
     run_status,
	 [Step]      = jh.step_id,
     [StepName]  = jh.step_name,
     [Message]   = jh.message,
     [Status]    = CASE WHEN jh.run_status = 0 THEN 'Failed'
            WHEN jh.run_status = 1 THEN 'Succeeded'
            WHEN jh.run_status = 2 THEN 'Retry'
            WHEN jh.run_status = 3 THEN 'Canceled'
            END,
	   durationHHMMSS = STUFF(STUFF(REPLACE(STR(jh.run_duration,7,0),
        ' ','0'),4,0,':'),7,0,':'),
    [start_date] = CONVERT(DATETIME, RTRIM(run_date) + ' '
        + STUFF(STUFF(REPLACE(STR(RTRIM(jh.run_time),6,0),
        ' ','0'),3,0,':'),6,0,':')),
     instance_id
FROM msdb.dbo.sysjobhistory jh
INNER JOIN msdb.dbo.sysjobs j ON jh.job_id = j.job_id
WHERE step_id = 0
and name = @jobname
ORDER BY 2


--DECLARE @Jobname1 varchar(2000)
--set @jobname  = 'Extract\Load Daily Statements'
SELECT  j.name JobName
      , h.step_name StepName
      , CAST(STR(h.run_date, 8, 0) AS DATETIME)
        + CAST(STUFF(STUFF(RIGHT('000000' + CAST (h.run_time AS VARCHAR(6)), 6),
                           5, 0, ':'), 3, 0, ':') AS DATETIME) AS StartDatetime
      , DATEADD(SECOND,
                ( ( h.run_duration / 1000000 ) * 86400 )
                + ( ( ( h.run_duration - ( ( h.run_duration / 1000000 )
                                           * 1000000 ) ) / 10000 ) * 3600 )
                + ( ( ( h.run_duration - ( ( h.run_duration / 10000 ) * 10000 ) )
                      / 100 ) * 60 ) + ( h.run_duration - ( h.run_duration
                                                            / 100 ) * 100 ),
                CAST(STR(h.run_date, 8, 0) AS DATETIME)
                + CAST(STUFF(STUFF(RIGHT('000000'
                                         + CAST (h.run_time AS VARCHAR(6)), 6),
                                   5, 0, ':'), 3, 0, ':') AS DATETIME)) AS EndDatetime
      , STUFF(STUFF(REPLACE(STR(run_duration, 6, 0), ' ', '0'), 3, 0, ':'), 6,
              0, ':') AS run_duration_formatted
      , ( ( h.run_duration / 1000000 ) * 86400 ) + ( ( ( h.run_duration
                                                         - ( ( h.run_duration
                                                              / 1000000 )
                                                             * 1000000 ) )
                                                       / 10000 ) * 3600 )
        + ( ( ( h.run_duration - ( ( h.run_duration / 10000 ) * 10000 ) )
              / 100 ) * 60 ) + ( h.run_duration - ( h.run_duration / 100 )
                                 * 100 ) AS RunDurationInSeconds
      , CASE h.run_status
          WHEN 0 THEN 'failed'
          WHEN 1 THEN 'Succeded'
          WHEN 2 THEN 'Retry'
          WHEN 3 THEN 'Cancelled'
          WHEN 4 THEN 'In Progress'
        END AS ExecutionStatus
      , h.message MessageGenerated
FROM    sysjobhistory h
        INNER JOIN sysjobs j
            ON j.job_id = h.job_id
	and name = @jobname

	where  ( ( h.run_duration / 1000000 ) * 86400 ) + ( ( ( h.run_duration
                                                         - ( ( h.run_duration
                                                              / 1000000 )
                                                             * 1000000 ) )
                                                       / 10000 ) * 3600 )
        + ( ( ( h.run_duration - ( ( h.run_duration / 10000 ) * 10000 ) )
              / 100 ) * 60 ) + ( h.run_duration - ( h.run_duration / 100 )
                                 * 100 ) > 60
ORDER BY h.run_date DESC
      , h.run_time desc