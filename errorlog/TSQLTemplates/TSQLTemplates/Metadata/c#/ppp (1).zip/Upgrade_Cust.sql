/* 
   *******************************************************************************
    ENVIRONMENT:    SQL 2000

	NAME:           2000_PREUPGRADE.SQL

    DESCRIPTION:    THIS SCRIPT IS TO HELP WITH UPGRADE SQL 2000 DATABASES TO 
                    SQL 2008.  IT REPORTS SOME SQL SERVER LEVEL INFORMATION AND
                    NOTIFIES YOU OF ANY POTENTIAL ISSUES THAT MAY OCCUR DURING
                    THE UPGRADE OR LIST ITEMS THAT ALSO NEEDS TO BE UPGRADED.  
                    BELOW ARE THE THINGS THAT IT REPORTS
                    
                        * IF INSTANCE IS DEFAULT
                        * COLLATION IS DIFFERENT
                        * NOT SP4
                        * LIST OF SP_CONFIGURE VALUES
                        * ANY CUSTOM EXTENDED PROCS
                        * ANY DATABASE THAT ARE USING FULL TEXT SEARCH
                        * ANY DATABASE SETUP FOR REPLICATION
                        * LIST OF ANY DTS PACKAGES ON SQL
                        * IF USING LOG SHIPPING
                        * ANY LINKED SERVERS 
                        * IF ANY STORED PROCEDURE SET FOR STARTUP
                        * DB OWNER IS NOT SA
                        * DB COMPATIBILITY CHECKS
                        * DB THAT DON'T HAVE AUTOGROWTH ON
                        * LIST OF DATABASES AND DATA & LOG LOCATION
                        * LIST OF SQL JOBS ON SQL 
                        * LIST OF MAIL PROFILES
                    
    AUTHOR         DATE       VERSION  DESCRIPTION
    -------------- ---------- -------- ------------------------------------------
    VBANDI         03/24/2015 1.0      INITIAL CREATION
    VBANDI         03/30/2015 1.1      UPDATE SP_CONFIGURE SECTION BASED ON VERSION
   *******************************************************************************
*/
USE [master]
GO
SET NOCOUNT ON
SET ANSI_WARNINGS OFF

DECLARE		@SQLVersion			varchar(15)

SET @SQLVersion = CAST(SERVERPROPERTY('ProductVersion') AS varchar(15))

IF LEFT(@SQLVersion, CHARINDEX('.', @SQLVersion) - 1) > '9'
	PRINT '*** THIS SCRIPT SHOULD BE RUN ON A SQL SERVER 2000 BOX, ONLY!!!!'
ELSE
	BEGIN		
		DECLARE		@WindowsVerison			varchar(20)
					,@PhysicalCPUCount		tinyint
					,@LogicalCPUCount		smallint
					,@PhysicalMemory		int
					,@Drive					char(1)
					,@FreeSpace				int
					,@ApproxStartDate		datetime
					,@Value					nvarchar(1024)
					,@SQLPath				varchar(256)
					,@DefaultDataPath		varchar(256)
					,@DefaultLogPath		varchar(256)
					,@Command				nvarchar(4000)
					,@ReturnValue			int
					,@IPAddress				varchar(256)
					,@DetailDomainName		varchar(128)
					,@FSOObjectToken		int
					,@OutputDrive			int
					,@Source				varchar(255)
					,@Description			varchar(255)
					,@TotalSize				varchar(20)
					,@Name					varchar(128)
					,@Run					int
					,@Default				int
					,@ExtSP					varchar(128)	
					,@Db					varchar(128)
					,@SQL					varchar(2000)
					,@CatName				varchar(128)
					,@Path					varchar(260)
					,@DTS					varchar(128)
					,@PrimarySrv			varchar(128)
					,@PrimaryDb				varchar(128)
					,@SecondarySrv			varchar(128)
					,@SecondaryDb			varchar(128)
					,@LinkServer			varchar(128)
					,@Owner					varchar(128)
					,@Cmpt					tinyint
					,@Logical				varchar(256)
					,@SP					varchar(128)
					,@Type					varchar(5)
					,@Size					dec(20, 4)
					,@PhysicalName			varchar(256)
					,@PrevDb				varchar(128)
					,@SQLJob				varchar(128)
					,@PrevSQLJob			varchar(128)
					,@Enabled				bit
					,@LastFailureDt			datetime
					,@LastSuccessDt			datetime
					,@NextRunDt				datetime
					,@ScheduleName			varchar(128)
					,@ScheduleInfo			varchar(128)
					

		PRINT 'Report Date:        ' + CONVERT(varchar(30), GETDATE(), 109)
		PRINT ''
					
		CREATE TABLE #ServerInfo
		(
			Id					int
			,Name				varchar(256)
			,InternalValue		int
			,Character_Value	varchar(2000)
		)

		INSERT INTO #ServerInfo
		EXECUTE master.dbo.xp_msver 


		SELECT		@WindowsVerison = ISNULL(Character_Value, '')
		FROM		#ServerInfo
		WHERE		Name = 'WindowsVersion'

		SELECT		@PhysicalCPUCount = InternalValue
		FROM		#ServerInfo
		WHERE		Name = 'ProcessorCount'

		SELECT		@PhysicalMemory = ISNULL(InternalValue, '')
		FROM		#ServerInfo
		WHERE		Name = 'PhysicalMemory'

		SELECT		@ApproxStartDate = crdate
		FROM		master.dbo.sysdatabases WITH (NOLOCK)
		WHERE		name = 'tempdb'

		PRINT 'MachineName:        ' + CAST(ISNULL(SERVERPROPERTY('MachineName'), 'NULL') AS varchar(128))

		SET @DetailDomainName = NULL

		EXEC master.dbo.xp_regread 'HKEY_LOCAL_MACHINE'
									,'SYSTEM\CurrentControlSet\Services\Tcpip\Parameters'
									,'Domain'
									,@DetailDomainName OUTPUT

		PRINT 'Domain:             ' +  ISNULL(@DetailDomainName, 'Unable to retrieve Domain Info')



		PRINT ''
		PRINT 'WindowsVersion:     ' +  @WindowsVerison
		PRINT 'CPU:                ' +  CAST(@PhysicalCPUCount AS varchar(128))
		PRINT 'PhysicalMemory:     ' +  CAST(@PhysicalMemory AS varchar(128))
		PRINT '' 

		CREATE TABLE #DriveInfo
		(
			Drive		char(1)
			,FreeSpace	int
		)

		INSERT INTO #DriveInfo
		EXECUTE xp_fixeddrives

		DECLARE CURSOR_DRIVES CURSOR FAST_FORWARD
		FOR
			SELECT		Drive
						,FreeSpace
			FROM		#DriveInfo

		OPEN CURSOR_DRIVES

		FETCH NEXT FROM CURSOR_DRIVES
		INTO @Drive, @FreeSpace

		PRINT 'Drives:          '

		EXECUTE @ReturnValue = sp_OACreate  'Scripting.FileSystemObject', @FSOObjectToken OUT

		WHILE @@FETCH_STATUS = 0
		BEGIN
			EXECUTE @ReturnValue = sp_OAMethod @FSOObjectToken, 'GetDrive', @OutputDrive OUT, @Drive

			IF @ReturnValue = 0
				BEGIN
					EXECUTE @ReturnValue = sp_OAGetProperty @OutputDrive, 'TotalSize', @TotalSize OUT

					IF @ReturnValue = 0
						PRINT '    ' + @Drive + ':              ' + CAST(CAST(CAST(@TotalSize AS numeric(20, 4))/1048576.0  AS int) AS varchar(25)) + ' MB in size and ' +  CAST(@FreeSpace AS varchar(25)) + ' MB of Free Space'
					ELSE
						PRINT '    ' + @Drive + ':              ' + CAST(@FreeSpace AS varchar(25)) + ' MB of Free Space (Unable to get TotalSize)'
				END
			ELSE
				PRINT '    ' + @Drive + ':              ' + CAST(@FreeSpace AS varchar(25)) + ' MB of Free Space (Unable to get TotalSize)'


			FETCH NEXT FROM CURSOR_DRIVES
			INTO @Drive, @FreeSpace
		END

		CLOSE CURSOR_DRIVES
		DEALLOCATE CURSOR_DRIVES

		EXECUTE @ReturnValue = sp_OADestroy @FSOObjectToken

		PRINT ''
		PRINT 'ServerName:         ' + CAST(ISNULL(SERVERPROPERTY('ServerName'), 'NULL') AS varchar(128))
		PRINT 'InstanceName:       ' + CAST(ISNULL(SERVERPROPERTY('InstanceName'), 'Default') AS varchar(128))

		IF UPPER(CAST(ISNULL(SERVERPROPERTY('InstanceName'), 'Default') AS varchar(128))) IN ('DEFAULT', 'MSSQLSERVER')
			BEGIN
				PRINT '>>>>>>>>>>>>>>>>>>>>>> THIS IS A DEFAULT INSTANCE, THERE MAYBE IMPACT WHEN MIGRATING DATABASE TO A NAME INSTANCE. ** YOU NEED TO MAKE SURE APPLICATION CAN CONNECT TO NAME INSTANCE & PORT NUMBER WHEN MIGRATING TO NEW SERVER.'
				PRINT ''
			END

		PRINT 'Approx Start Date:  ' + CONVERT(varchar(35), @ApproxStartDate, 109)
		PRINT 'SQL Edition:        ' + CAST(ISNULL(SERVERPROPERTY('Edition'), 'NULL') AS varchar(128))
		PRINT 'ProductVersion:     ' + ISNULL(@SQLVersion, 'NULL') 
		PRINT 'ProductLevel:       ' + CAST(ISNULL(SERVERPROPERTY('ProductLevel'), 'NULL') AS varchar(128))

		IF CAST(SERVERPROPERTY('ProductLevel') AS varchar(128)) < 'SP4'
			BEGIN
				PRINT '>>>>>>>>>>>>>>>>>>>>>> MUST BE AT LEAST SP4'
				PRINT ''
			END

		PRINT 'Collation:          ' + CAST(ISNULL(SERVERPROPERTY('Collation'), 'NULL') AS varchar(128))

		IF CAST(SERVERPROPERTY('Collation') AS varchar(128)) <> 'SQL_Latin1_General_CP1_CI_AS'
			BEGIN
				PRINT '>>>>>>>>>>>>>>>>>>>>>> COLLATION IS DIFFERENT FROM THE DEFAULT SQL_Latin1_General_CP1_CI_AS.  ** PLEASE MAKE SURE WHEN MIGRATING TO NEW SERVER THAT THIS COLLATION HAS BEEN INSTALLED.'
				PRINT ''
			END

			
		PRINT 'Is Clustered:       ' + CAST(ISNULL(SERVERPROPERTY('IsClustered'), 'NULL') AS varchar(128))
		PRINT '' 

		EXECUTE master.dbo.xp_instance_regread	'HKEY_LOCAL_MACHINE'
												,'SOFTWARE\Microsoft\MSSQLServer\Setup\'
												,'SQLProgramDir'
												,@Value OUTPUT
												,'no_output'
												
		PRINT 'SQL Program Dir:    ' + ISNULL(@Value, '')

		EXECUTE master.dbo.xp_instance_regread	'HKEY_LOCAL_MACHINE'
												,'SOFTWARE\Microsoft\MSSQLServer\Setup\'
												,'SQLPath'
												,@Value OUTPUT
												,'no_output'
												
		PRINT 'SQL Path:           ' + ISNULL(@Value, '')


		EXECUTE master.dbo.xp_instance_regread	'HKEY_LOCAL_MACHINE'
												,'SOFTWARE\Microsoft\MSSQLServer\Setup\'
												,'SQLBinRoot'
												,@Value OUTPUT
												,'no_output'
												
		PRINT 'SQL Binary Dir:     ' + ISNULL(@Value, '')
		PRINT '' 

		SET @SQLPath = NULL
		SET @DefaultDataPath = NULL
		SET @DefaultLogPath = NULL

		EXEC master.dbo.xp_instance_regread N'HKEY_LOCAL_MACHINE'
											,N'SOFTWARE\Microsoft\MSSQLServer\Setup'
											,N'SQLPath'
											,@SQLPath OUTPUT


		EXEC master.dbo.xp_instance_regread N'HKEY_LOCAL_MACHINE'
											,N'Software\Microsoft\MSSQLServer\MSSQLServer'
											,N'DefaultData'
											,@DefaultDataPath OUTPUT
											,NO_OUTPUT


		EXEC master.dbo.xp_instance_regread N'HKEY_LOCAL_MACHINE'
											,N'Software\Microsoft\MSSQLServer\MSSQLServer'
											,N'DefaultLog'
											,@DefaultLogPath OUTPUT
											,NO_OUTPUT

		IF RIGHT(@SQLPath, 1) <> '\'
			SET @SQLPath = @SQLPath + '\'

		SET @SQLPath = @SQLPath
		SET @DefaultDataPath = ISNULL(@DefaultDataPath, @SQLPath + 'DATA\')
		SET @DefaultLogPath = ISNULL(@DefaultLogPath, @SQLPath + 'DATA\')

		PRINT 'Default Data Dir:   ' + @DefaultDataPath
		PRINT 'Default Log Dir:    ' + @DefaultLogPath
				
		CREATE TABLE #ConfigReport
		(
			Name		varchar(128)
			,Min		int
			,Max		int
			,Config		int
			,Run		int
			,Dflt	int NULL
		)

		PRINT ''
		EXECUTE sp_configure 'show advanced options', 1
		RECONFIGURE WITH OVERRIDE;

		INSERT INTO #ConfigReport (Name, Min, Max, Config, Run)
		EXECUTE sp_configure

		UPDATE #ConfigReport SET Dflt = 0 WHERE Name = 'affinity mask'
		UPDATE #ConfigReport SET Dflt = 0 WHERE Name = 'allow updates'
		UPDATE #ConfigReport SET Dflt = 0 WHERE Name = 'awe enabled'
		UPDATE #ConfigReport SET Dflt = 0 WHERE Name = 'c2 audit mode'
		UPDATE #ConfigReport SET Dflt = 5 WHERE Name = 'cost threshold for parallelism'
		UPDATE #ConfigReport SET Dflt = 0 WHERE Name = 'Cross DB Ownership Chaining'
		UPDATE #ConfigReport SET Dflt = -1 WHERE Name = 'cursor threshold'
		UPDATE #ConfigReport SET Dflt = 1033 WHERE Name = 'default full-text language'
		UPDATE #ConfigReport SET Dflt = 0 WHERE Name = 'default language'
		UPDATE #ConfigReport SET Dflt = 0 WHERE Name = 'fill factor (%)'
		UPDATE #ConfigReport SET Dflt = 0 WHERE Name = 'index create memory (KB)'
		UPDATE #ConfigReport SET Dflt = 0 WHERE Name = 'lightweight pooling'
		UPDATE #ConfigReport SET Dflt = 0 WHERE Name = 'locks'
		UPDATE #ConfigReport SET Dflt = 0 WHERE Name = 'max degree of parallelism'
		UPDATE #ConfigReport SET Dflt = 2147483647 WHERE Name = 'max server memory (MB)'
		UPDATE #ConfigReport SET Dflt = 65536 WHERE Name = 'max text repl size (B)'
		UPDATE #ConfigReport SET Dflt = 255 WHERE Name = 'max worker threads'
		UPDATE #ConfigReport SET Dflt = 0 WHERE Name = 'media retention'
		UPDATE #ConfigReport SET Dflt = 1024 WHERE Name = 'min memory per query (KB)'
		UPDATE #ConfigReport SET Dflt = 0 WHERE Name = 'min server memory (MB)'
		UPDATE #ConfigReport SET Dflt = 1 WHERE Name = 'nested triggers'
		UPDATE #ConfigReport SET Dflt = 4096 WHERE Name = 'network packet size (B)'
		UPDATE #ConfigReport SET Dflt = 0 WHERE Name = 'open objects'
		UPDATE #ConfigReport SET Dflt = 0 WHERE Name = 'priority boost'
		UPDATE #ConfigReport SET Dflt = 0 WHERE Name = 'query governor cost limit'
		UPDATE #ConfigReport SET Dflt = -1 WHERE Name = 'query wait (s)'
		UPDATE #ConfigReport SET Dflt = 0 WHERE Name = 'recovery interval (min)'
		UPDATE #ConfigReport SET Dflt = 1 WHERE Name = 'remote access'
		UPDATE #ConfigReport SET Dflt = 20 WHERE Name = 'remote login timeout (s)'
		UPDATE #ConfigReport SET Dflt = 0 WHERE Name = 'remote proc trans'
		UPDATE #ConfigReport SET Dflt = 600 WHERE Name = 'remote query timeout (s)'
		UPDATE #ConfigReport SET Dflt = 0 WHERE Name = 'scan for startup procs'
		UPDATE #ConfigReport SET Dflt = 0 WHERE Name = 'set working set size'
		UPDATE #ConfigReport SET Dflt = 0 WHERE Name = 'show advanced options'
		UPDATE #ConfigReport SET Dflt = 2049 WHERE Name = 'two digit year cutoff'
		UPDATE #ConfigReport SET Dflt = 0 WHERE Name = 'user connections'
		UPDATE #ConfigReport SET Dflt = 0 WHERE Name = 'user options'

		DECLARE CURSOR_CONFIG CURSOR FAST_FORWARD
		FOR
			SELECT		Name
						,Run
						,Dflt
			FROM		#ConfigReport
			WHERE		Name <> 'show advanced options'
			ORDER BY	1
			
		OPEN CURSOR_CONFIG

		FETCH NEXT FROM CURSOR_CONFIG
		INTO @Name, @Run, @Default

		IF @@FETCH_STATUS = 0
			BEGIN
				PRINT ''
				PRINT 'Instance Configuration Information:     '
			END

		WHILE @@FETCH_STATUS = 0
		BEGIN
			IF @Run = @Default
				PRINT '                       ' + @Name + ' = ' + CAST(@Run AS varchar(15))
			ELSE
				PRINT '>>>>>>>>>>>>>>>>>>>>>> ' + @Name + ' = ' + CAST(@Run AS varchar(15)) + ' (default = ' + CAST(@Default AS varchar(15)) + ').  ** PLEASE MAKE SURE THIS CONFIGURAITON IS NEEDED ON NEW SERVER AND WHY ITS SET THIS WAY.  IF VALID SETTING TO BE CHANGE PLEASE DOCUMENT IT IN TOPOLOGY.'

			FETCH NEXT FROM CURSOR_CONFIG
			INTO @Name, @Run, @Default
		END

		CLOSE CURSOR_CONFIG
		DEALLOCATE CURSOR_CONFIG

		DECLARE CURSOR_EXTSP CURSOR FAST_FORWARD
		FOR
			SELECT		name
			FROM		master.dbo.sysobjects 
			WHERE		type = 'x'
			  AND		status > 0
			ORDER BY	1

		OPEN CURSOR_EXTSP

		FETCH NEXT FROM CURSOR_EXTSP
		INTO @ExtSP

		IF @@FETCH_STATUS = 0
			BEGIN
				PRINT ''
				PRINT 'Custom Extended SP: '		
			END
			
		WHILE @@FETCH_STATUS = 0
		BEGIN
			PRINT '>>>>>>>>>>>>>>>>>>>>>> ' + @ExtSP + ' - ** PLEASE VERIFY IF EXTENDED STORED PROCEDURE IS TRULY NEEDED.  IF SO, PLEASE MAKE SURE TO MIGRATE TO NEW SERVER.  ALSO, MAKE SURE ITS DOCUMENTED IN TOPOLOGY AND WHAT ITS USED FOR.'
			
			FETCH NEXT FROM CURSOR_EXTSP
			INTO @ExtSP
		END

		CLOSE CURSOR_EXTSP
		DEALLOCATE CURSOR_EXTSP
				
		CREATE TABLE #FTReport
		(
			DbName			varchar(128)
			,CatalogName	varchar(128)
			,Path			varchar(260)
		)

		SET @SQL = 'USE [?];SELECT ''?'', name, path FROM sysfulltextcatalogs'

		INSERT INTO #FTReport
		EXECUTE sp_MSforeachdb @SQL

		DECLARE CURSOR_DB CURSOR FAST_FORWARD
		FOR   
			SELECT		A.name
						,B.CatalogName
						,B.Path
			FROM		master.dbo.sysdatabases A
							JOIN #FTReport B ON A.name = B.DbName
			WHERE		DATABASEPROPERTYEX(name, 'IsFulltextEnabled')  = 1			
			ORDER BY	1

		OPEN CURSOR_DB

		FETCH NEXT FROM CURSOR_DB
		INTO @Db, @CatName, @Path

		IF @@FETCH_STATUS = 0
			BEGIN
				PRINT ''
				PRINT 'DB with Full-Text Enabled:  '		
			END
			
		WHILE @@FETCH_STATUS = 0
		BEGIN
			PRINT '    ' + @Db

			PRINT '>>>>>>>>>>>>>>>>>>>>>> Catalog Name = ' + ISNULL(@CatName, '') + ', Path = ' + ISNULL(@Path, '') + '.  ** WHEN MIGRATING FULL TEXT CATALOGS TO NEW SERVER, MAKE SURE THEY ARE REBUILT.'
					
			FETCH NEXT FROM CURSOR_DB
			INTO @Db, @CatName, @Path
		END

		CLOSE CURSOR_DB
		DEALLOCATE CURSOR_DB

		DECLARE CURSOR_DTS CURSOR FAST_FORWARD
		FOR
			SELECT		DISTINCT name
			FROM		msdb.dbo.sysdtspackages
			ORDER BY	1

		OPEN CURSOR_DTS

		FETCH NEXT FROM CURSOR_DTS
		INTO @DTS

		IF @@FETCH_STATUS = 0
			BEGIN
				PRINT ''
				PRINT 'DTS Packages:       '		
			END
			
		WHILE @@FETCH_STATUS = 0
		BEGIN
			PRINT '>>>>>>>>>>>>>>>>>>>>>> ' + @DTS + ' ** THIS DTS PACKAGE WOULD NEED TO BE CONVERTED TO SSIS AND BE CALLED FROM CTRL-M.'

			FETCH NEXT FROM CURSOR_DTS
			INTO @DTS
		END

		CLOSE CURSOR_DTS
		DEALLOCATE CURSOR_DTS

		CREATE TABLE #DBReplReport
		(
			DBName		varchar(128)
		)

		SET @SQL = '
					IF EXISTS(SELECT * FROM [?].dbo.sysobjects WHERE name = ''MSsubscription_agents'')				
						IF EXISTS(SELECT * FROM [?].dbo.MSsubscription_agents)
							SELECT ''?''
					
					IF EXISTS(SELECT * FROM [?].dbo.sysobjects WHERE name = ''syspublications'')
						IF EXISTS(SELECT * FROM [?].dbo.syspublications)
							SELECT ''?''
				  '

		INSERT INTO #DBReplReport
		EXECUTE master.dbo.sp_MSforeachdb @SQL

		DECLARE CURSOR_DB CURSOR FAST_FORWARD
		FOR
			SELECT		DISTINCT DBName 
			FROM		#DBReplReport

		OPEN CURSOR_DB

		FETCH NEXT FROM CURSOR_DB
		INTO @Db

		IF @@FETCH_STATUS = 0
			BEGIN
				PRINT ''
				PRINT 'DB with Replication:'		
			END
			
		WHILE @@FETCH_STATUS = 0
		BEGIN
			PRINT '>>>>>>>>>>>>>>>>>>>>>> ' + @Db + ' ** MAKE SURE REPLICATION IS SETUP AND WORKING PROPERTLY ON NEW SERVER WHEN MIGRATING THIS DATABASE.  ALSO, MAKE SURE ALERTS ARE SETUP.'

			FETCH NEXT FROM CURSOR_DB
			INTO @Db
		END

		CLOSE CURSOR_DB
		DEALLOCATE CURSOR_DB

		DECLARE CURSOR_LOGSHP CURSOR FAST_FORWARD
		FOR
			SELECT	A.primary_server_name
					,A.primary_database_name
					,ISNULL(B.secondary_server_name, '')
					,ISNULL(B.secondary_database_name, '')
			FROM	msdb.dbo.log_shipping_primaries A
						LEFT JOIN msdb.dbo.log_shipping_secondaries B ON A.primary_id = B.primary_id
					
		OPEN CURSOR_LOGSHP

		FETCH NEXT FROM CURSOR_LOGSHP 
		INTO @PrimarySrv, @PrimaryDb, @SecondarySrv, @SecondaryDb

		IF @@FETCH_STATUS = 0
			BEGIN
				PRINT ''
				PRINT 'Log Shipping:       '		
			END
			
		WHILE @@FETCH_STATUS = 0
		BEGIN
			PRINT '>>>>>>>>>>>>>>>>>>>>>> Primary (' + @PrimarySrv + ' - ' + @PrimaryDb + ') Secondary (' + @SecondarySrv + ' - ' + @SecondaryDb + ').  ** MAKE SURE LOG SHIPPING IS SETUP AND WORKING PROPERLY WHEN MIGRATING THIS DATABASE.'

			FETCH NEXT FROM CURSOR_LOGSHP 
			INTO @PrimarySrv, @PrimaryDb, @SecondarySrv, @SecondaryDb
		END

		CLOSE CURSOR_LOGSHP
		DEALLOCATE CURSOR_LOGSHP

		DECLARE CURSOR_LINKSRV CURSOR FAST_FORWARD
		FOR
			SELECT		srvname 
			FROM		sysservers 
			WHERE		srvname <> CAST(SERVERPROPERTY('MachineName') AS varchar(128)) + CASE WHEN CAST(SERVERPROPERTY('InstanceName') AS varchar(128)) IS NULL THEN '' ELSE '\' + CAST(SERVERPROPERTY('InstanceName') AS varchar(128)) END

		OPEN CURSOR_LINKSRV

		FETCH NEXT FROM CURSOR_LINKSRV
		INTO @LinkServer

		IF @@FETCH_STATUS = 0
			BEGIN
				PRINT ''
				PRINT 'Link Servers:       '		
			END

		WHILE @@FETCH_STATUS = 0
		BEGIN
			PRINT '>>>>>>>>>>>>>>>>>>>>>> ' + @LinkServer + ' - ** VALIDATE IF THIS LINKED SERVER IS BEING USED WITH CUSTOMER.  IF NOT, DO NOT MIGRATE.  IF SO, MAKE SURE ITS NOT A TEST SERVER.  LINK TEST SEVERS ARE NOT ALLOWED'

			FETCH NEXT FROM CURSOR_LINKSRV
			INTO @LinkServer
		END

		CLOSE CURSOR_LINKSRV
		DEALLOCATE CURSOR_LINKSRV


		DECLARE CURSOR_OWNER CURSOR FAST_FORWARD
		FOR
			SELECT		A.name
						,ISNULL(SUSER_SNAME(A.sid), 'UNKNOWN')
			FROM		sysdatabases A
			WHERE		A.sid <> 0x01 -- sa/ssaid

		OPEN CURSOR_OWNER 

		FETCH NEXT FROM CURSOR_OWNER 
		INTO @Db, @Owner

		IF @@FETCH_STATUS = 0
			BEGIN
				PRINT ''
				PRINT 'Db Owner Not SA:     '		
			END

		WHILE @@FETCH_STATUS = 0
		BEGIN
			PRINT '>>>>>>>>>>>>>>>>>>>>>> ' + QUOTENAME(@Owner) + ' IS OWNER OF DATABASE ' + QUOTENAME(@Db) + '.  ** CHANGE DATABASE OWNER TO ''SA'', IT ALSO MAYBE ''SSAID''.  IF THE OWNER WAS A NON-WDBS DBA, PLEASE MAKE SURE THE ACCOUNT HAS ACCESS IN THE DATABASE BEFORE CHANGING THE DATABASE OWNER.'

			FETCH NEXT FROM CURSOR_OWNER 
			INTO @Db, @Owner
		END

		CLOSE CURSOR_OWNER
		DEALLOCATE CURSOR_OWNER

IF LEFT(CONVERT(VARCHAR,SERVERPROPERTY('ProductVersion')), (CHARINDEX(CHAR(46),CONVERT(VARCHAR,SERVERPROPERTY('ProductVersion')),1)-1)) = 8
begin
		DECLARE CURSOR_DBCMPT CURSOR FAST_FORWARD 
		FOR
			SELECT		name
						,cmptlevel
			FROM		sysdatabases
			WHERE		cmptlevel <> 80
			ORDER BY	1

		OPEN CURSOR_DBCMPT 

		FETCH NEXT FROM CURSOR_DBCMPT 
		INTO @Db, @Cmpt

		IF @@FETCH_STATUS = 0
			BEGIN
				PRINT ''
				PRINT 'DB Compatibility not 80'
			END

		WHILE @@FETCH_STATUS = 0
		BEGIN
			PRINT '>>>>>>>>>>>>>>>>>>>>>> Database ' + QUOTENAME(@Db) + ' COMPATIBILITY LEVEL IS NOT 80, IT IS ' + CAST(@Cmpt AS varchar(3)) + '.  ** COMPATIBILITY LEVEL MUST BE SET TO 80 BEFORE MIGRATING IT TO NEW SERVER.'

			FETCH NEXT FROM CURSOR_DBCMPT 
			INTO @Db, @Cmpt
		END

		CLOSE CURSOR_DBCMPT
		DEALLOCATE CURSOR_DBCMPT

END;
ELSE 
IF LEFT(CONVERT(VARCHAR,SERVERPROPERTY('ProductVersion')), (CHARINDEX(CHAR(46),CONVERT(VARCHAR,SERVERPROPERTY('ProductVersion')),1)-1)) = 9
BEGIN
	DECLARE CURSOR_DBCMPT CURSOR FAST_FORWARD 
		FOR
			SELECT		name
						,cmptlevel
			FROM		sysdatabases
			WHERE		cmptlevel <> 90
			ORDER BY	1

		OPEN CURSOR_DBCMPT 

		FETCH NEXT FROM CURSOR_DBCMPT 
		INTO @Db, @Cmpt

		IF @@FETCH_STATUS = 0
			BEGIN
				PRINT ''
				PRINT 'DB Compatibility not 90'
			END

		WHILE @@FETCH_STATUS = 0
		BEGIN
			PRINT '>>>>>>>>>>>>>>>>>>>>>> Database ' + QUOTENAME(@Db) + ' COMPATIBILITY LEVEL IS NOT 90, IT IS ' + CAST(@Cmpt AS varchar(3)) + '.  ** COMPATIBILITY LEVEL MUST BE SET TO 80 BEFORE MIGRATING IT TO NEW SERVER.'

			FETCH NEXT FROM CURSOR_DBCMPT 
			INTO @Db, @Cmpt
		END

		CLOSE CURSOR_DBCMPT
		DEALLOCATE CURSOR_DBCMPT
END;
ELSE 
IF LEFT(CONVERT(VARCHAR,SERVERPROPERTY('ProductVersion')), (CHARINDEX(CHAR(46),CONVERT(VARCHAR,SERVERPROPERTY('ProductVersion')),1)-1)) = 10
BEGIN
		DECLARE CURSOR_DBCMPT CURSOR FAST_FORWARD 
		FOR
			SELECT		name
						,cmptlevel
			FROM		sysdatabases
			WHERE		cmptlevel <> 100
			ORDER BY	1

		OPEN CURSOR_DBCMPT 

		FETCH NEXT FROM CURSOR_DBCMPT 
		INTO @Db, @Cmpt

		IF @@FETCH_STATUS = 0
			BEGIN
				PRINT ''
				PRINT 'DB Compatibility not 100'
			END

		WHILE @@FETCH_STATUS = 0
		BEGIN
			PRINT '>>>>>>>>>>>>>>>>>>>>>> Database ' + QUOTENAME(@Db) + ' COMPATIBILITY LEVEL IS NOT 100, IT IS ' + CAST(@Cmpt AS varchar(3)) + '.  ** COMPATIBILITY LEVEL MUST BE SET TO 80 BEFORE MIGRATING IT TO NEW SERVER.'

			FETCH NEXT FROM CURSOR_DBCMPT 
			INTO @Db, @Cmpt
		END

		CLOSE CURSOR_DBCMPT
		DEALLOCATE CURSOR_DBCMPT
END;
ELSE 
IF LEFT(CONVERT(VARCHAR,SERVERPROPERTY('ProductVersion')), (CHARINDEX(CHAR(46),CONVERT(VARCHAR,SERVERPROPERTY('ProductVersion')),1)-1)) = 11
BEGIN
	DECLARE CURSOR_DBCMPT CURSOR FAST_FORWARD 
		FOR
			SELECT		name
						,cmptlevel
			FROM		sysdatabases
			WHERE		cmptlevel <> 110
			ORDER BY	1

		OPEN CURSOR_DBCMPT 

		FETCH NEXT FROM CURSOR_DBCMPT 
		INTO @Db, @Cmpt

		IF @@FETCH_STATUS = 0
			BEGIN
				PRINT ''
				PRINT 'DB Compatibility not 110'
			END

		WHILE @@FETCH_STATUS = 0
		BEGIN
			PRINT '>>>>>>>>>>>>>>>>>>>>>> Database ' + QUOTENAME(@Db) + ' COMPATIBILITY LEVEL IS NOT 110, IT IS ' + CAST(@Cmpt AS varchar(3)) + '.  ** COMPATIBILITY LEVEL MUST BE SET TO 80 BEFORE MIGRATING IT TO NEW SERVER.'

			FETCH NEXT FROM CURSOR_DBCMPT 
			INTO @Db, @Cmpt
		END

		CLOSE CURSOR_DBCMPT
		DEALLOCATE CURSOR_DBCMPT
END;
ELSE 
IF LEFT(CONVERT(VARCHAR,SERVERPROPERTY('ProductVersion')), (CHARINDEX(CHAR(46),CONVERT(VARCHAR,SERVERPROPERTY('ProductVersion')),1)-1)) =12
BEGIN
			DECLARE CURSOR_DBCMPT CURSOR FAST_FORWARD 
		FOR
			SELECT		name
						,cmptlevel
			FROM		sysdatabases
			WHERE		cmptlevel <> 120
			ORDER BY	1

		OPEN CURSOR_DBCMPT 

		FETCH NEXT FROM CURSOR_DBCMPT 
		INTO @Db, @Cmpt

		IF @@FETCH_STATUS = 0
			BEGIN
				PRINT ''
				PRINT 'DB Compatibility not 120'
			END

		WHILE @@FETCH_STATUS = 0
		BEGIN
			PRINT '>>>>>>>>>>>>>>>>>>>>>> Database ' + QUOTENAME(@Db) + ' COMPATIBILITY LEVEL IS NOT 120, IT IS ' + CAST(@Cmpt AS varchar(3)) + '.  ** COMPATIBILITY LEVEL MUST BE SET TO 80 BEFORE MIGRATING IT TO NEW SERVER.'

			FETCH NEXT FROM CURSOR_DBCMPT 
			INTO @Db, @Cmpt
		END

		CLOSE CURSOR_DBCMPT
		DEALLOCATE CURSOR_DBCMPT
END;

		CREATE TABLE #DBFileReport
		(
			DBName			varchar(128)
			,LogicalFile	varchar(256)
		)

		SET @SQL = '			
					SELECT		''?''
								,name
					FROM		[?].dbo.sysfiles
					WHERE		growth = 0
				  '

		INSERT INTO #DBFileReport
		EXECUTE master.dbo.sp_MSforeachdb @SQL

		DECLARE CURSOR_AUTOGROW CURSOR FAST_FORWARD
		FOR
			SELECT		DBName
						,LogicalFile
			FROM		#DBFileReport
			WHERE		DBName <> 'tempdb'
			ORDER BY	1, 2
			
		OPEN CURSOR_AUTOGROW

		FETCH NEXT FROM CURSOR_AUTOGROW
		INTO @Db, @Logical

		IF @@FETCH_STATUS = 0
			BEGIN
				PRINT ''
				PRINT 'DB with AutoGrow Off   '
			END

		WHILE @@FETCH_STATUS = 0
		BEGIN
			PRINT '>>>>>>>>>>>>>>>>>>>>>> DATABASE ' + QUOTENAME(@Db) + ' AUTO GROW FOR LOGICAL FILE ' + @Logical + ' IS TURNED OFF.  ** MAKE SURE WHEN MIGRATED TO NEW SERVER THIS IS TURNED ON AND APPROPRIATE GROWTH IS SET.'
			
			FETCH NEXT FROM CURSOR_AUTOGROW 
			INTO @Db, @Logical
		END

		CLOSE CURSOR_AUTOGROW
		DEALLOCATE CURSOR_AUTOGROW

		DECLARE CURSOR_SP CURSOR FAST_FORWARD
		FOR
			SELECT		name
			FROM		sysobjects
			WHERE		xtype IN ('P', 'X')
			  AND		OBJECTPROPERTY(id, 'ExecIsStartup') = 1
			
		OPEN CURSOR_SP

		FETCH NEXT FROM CURSOR_SP
		INTO @SP

		IF @@FETCH_STATUS = 0
			BEGIN
				PRINT ''
				PRINT 'SP set to Exec At Startup:'
			END

		WHILE @@FETCH_STATUS = 0
		BEGIN
			PRINT '>>>>>>>>>>>>>>>>>>>>>> ' + @SP + ' - ** VALIDATE IF THIS STARTUP PROCEDURE IS NEEDED, IGNORE [sp_MSrepl_startup], THIS IS USED FOR REPLICATION.  IF NEEDED, MAKE SURE TO DOCUMENT IT IN TOPOLOGY AND WHAT ITS USED FOR.'
			
			FETCH NEXT FROM CURSOR_SP 
			INTO @SP
		END

		CLOSE CURSOR_SP
		DEALLOCATE CURSOR_SP
				
		CREATE TABLE #DBDataFileInfo
		(
			DbName			varchar(128)
			,Type			varchar(5)		
			,Size			int
			,LogicalName	varchar(128)
			,PhysicalName	varchar(512)
		)
			
		SET @SQL = '	
						USE [?];
						SELECT		''?''
									,CASE WHEN (status & 0x40) > 0 THEN ''Log''
											ELSE ''Data''
									 END
									,size
									,name
									,filename
						FROM		sysfiles
				'
		INSERT INTO #DBDataFileInfo 
		EXECUTE dbo.sp_MSforeachdb @SQL

		DECLARE CURSOR_DB_INFO CURSOR FAST_FORWARD
		FOR
			SELECT		DbName
						,Type
						,(Size * 8.0)/1024.0
						,LogicalName
						,PhysicalName
			FROM		#DBDataFileInfo  
			ORDER BY	1, 2
			
		OPEN CURSOR_DB_INFO 

		FETCH NEXT FROM CURSOR_DB_INFO
		INTO @Db, @Type, @Size, @Logical, @PhysicalName

		PRINT ''
		PRINT 'Database File Information:'

		SET @PrevDb = ''

		WHILE @@FETCH_STATUS = 0
		BEGIN
			IF @PrevDb <> @Db
				BEGIN 
					PRINT '    ' + @Db
					SET @PrevDb = @Db
				END
				
			PRINT '        Type:           ' + @Type
			PRINT '        Size:           ' + CAST(@Size AS varchar(25)) + ' MB'
			PRINT '        Logical Name:   ' + @Logical
			PRINT '        Physical Name:  ' + @PhysicalName
			PRINT ''
			
			FETCH NEXT FROM CURSOR_DB_INFO
			INTO @Db, @Type, @Size, @Logical, @PhysicalName
		END	

		CLOSE CURSOR_DB_INFO
		DEALLOCATE CURSOR_DB_INFO
		
		--DECLARE CURSOR_SQLJOBS CURSOR FAST_FORWARD
		--FOR
		--	SELECT		J.name AS [Name]
		--				,P.name AS JobOwner
		--				,J.enabled AS [Enabled]
		--				,MAX(
		--						CASE WHEN H.run_status = 0 
		--							THEN
		--								CASE WHEN H.run_duration < 0 
		--									THEN NULL 
		--									ELSE									 
		--										DATEADD
		--										 (
		--											ss
		--											,CAST(RIGHT(REPLICATE('0', 6-LEN(CAST(H.run_duration AS varchar(6)))) + CAST(H.run_duration AS varchar(6)), 2) AS int)
		--											,DATEADD
		--												 (
		--													mi
		--													,CAST(SUBSTRING(REPLICATE('0', 6-LEN(CAST(H.run_duration AS varchar(6)))) + CAST(H.run_duration AS varchar(6)), 3, 2) AS int)
		--													,DATEADD
		--														(
		--															hh
		--															,CAST(LEFT(REPLICATE('0', 6-LEN(CAST(H.run_duration AS varchar(6)))) + CAST(H.run_duration AS varchar(6)), 2) AS int)
		--															,CONVERT(char(19), SUBSTRING(CAST(H.run_date AS char(8)), 5, 2) + '/' + SUBSTRING(CAST(H.run_date AS char(8)), 7, 2) + '/' + LEFT(CAST(H.run_date AS char(8)), 4) + ' ' + 
		--																LEFT(REPLICATE('0', 6 - LEN(CAST(H.run_time AS varchar(6)))) + CAST(H.run_time AS varchar(6)), 2) + ':' +
		--																SUBSTRING(REPLICATE('0', 6-LEN(CAST(H.run_time AS varchar(6)))) + CAST(H.run_time AS varchar(6)), 3, 2) + ':' + 
		--																RIGHT(REPLICATE('0', 6-LEN(CAST(H.run_time AS varchar(6)))) + CAST(H.run_time AS varchar(6)), 2), 120)								
		--														)
		--												 )
		--										 )
		--									END
		--							ELSE NULL
		--						END
		--					) AS LastFailureDate
		--				,MAX(
		--						CASE WHEN H.run_status = 1
		--							THEN 
		--								CASE WHEN H.run_duration < 0 
		--									THEN NULL
		--									ELSE 
		--										DATEADD
		--										 (
		--											ss
		--											,CAST(RIGHT(REPLICATE('0', 6-LEN(CAST(H.run_duration AS varchar(6)))) + CAST(H.run_duration AS varchar(6)), 2) AS int)
		--											,DATEADD
		--												 (
		--													mi
		--													,CAST(SUBSTRING(REPLICATE('0', 6-LEN(CAST(H.run_duration AS varchar(6)))) + CAST(H.run_duration AS varchar(6)), 3, 2) AS int)
		--													,DATEADD
		--														(
		--															hh
		--															,CAST(LEFT(REPLICATE('0', 6-LEN(CAST(H.run_duration AS varchar(6)))) + CAST(H.run_duration AS varchar(6)), 2) AS int)
		--															,CONVERT(char(19), SUBSTRING(CAST(H.run_date AS char(8)), 5, 2) + '/' + SUBSTRING(CAST(H.run_date AS char(8)), 7, 2) + '/' + LEFT(CAST(H.run_date AS char(8)), 4) + ' ' + 
		--																LEFT(REPLICATE('0', 6 - LEN(CAST(H.run_time AS varchar(6)))) + CAST(H.run_time AS varchar(6)), 2) + ':' +
		--																SUBSTRING(REPLICATE('0', 6-LEN(CAST(H.run_time AS varchar(6)))) + CAST(H.run_time AS varchar(6)), 3, 2) + ':' + 
		--																RIGHT(REPLICATE('0', 6-LEN(CAST(H.run_time AS varchar(6)))) + CAST(H.run_time AS varchar(6)), 2), 120)
		--														)
		--												 )
		--										 )
		--								END
		--							ELSE NULL
		--						END
		--					) AS LastSuccessDate
		--				,MIN(
		--						CASE WHEN S.next_run_date = 0
		--							THEN NULL
		--							ELSE
		--								CONVERT(char(19), SUBSTRING(CAST(S.next_run_date AS char(8)), 5, 2) + '/' + SUBSTRING(CAST(S.next_run_date AS char(8)), 7, 2) + '/' + LEFT(CAST(S.next_run_date AS char(8)), 4) + ' ' + 
		--									LEFT(REPLICATE('0', 6 - LEN(CAST(S.next_run_time AS varchar(6)))) + CAST(S.next_run_time AS varchar(6)), 2) + ':' +
		--									SUBSTRING(REPLICATE('0', 6-LEN(CAST(S.next_run_time AS varchar(6)))) + CAST(S.next_run_time AS varchar(6)), 3, 2) + ':' + 
		--									RIGHT(REPLICATE('0', 6-LEN(CAST(S.next_run_time AS varchar(6)))) + CAST(S.next_run_time AS varchar(6)), 2), 120)
		--						END
		--					) AS NextRunDate
		--				,S.name		AS [ScheduleName]
		--				,REPLACE(
		--						REPLACE(
		--									CASE S.freq_type
		--										WHEN   1 THEN 'Start on ' + SUBSTRING(CAST(active_start_date AS varchar(8)), 5, 2) + '/' + RIGHT(active_start_date, 2) + '/' + LEFT(active_start_date , 4) + ' ' + 
		--																		LEFT(REPLICATE('0', 6 - LEN(CAST(active_start_time AS varchar(6)))) + CAST(active_start_time AS varchar(6)), 2) + ':' +
		--																			SUBSTRING(REPLICATE('0', 6-LEN(CAST(active_start_time AS varchar(6)))) + CAST(active_start_time AS varchar(6)), 3, 2) + ':' + 
		--																			RIGHT(REPLICATE('0', 6-LEN(CAST(active_start_time AS varchar(6)))) + CAST(active_start_time AS varchar(6)), 2)
		--										WHEN   4 THEN 'Occurs every ' + CAST(freq_interval AS varchar(10)) + ' day(s)' 
		--										WHEN   8 THEN 'Occurs every ' + CAST(freq_recurrence_factor AS varchar(10)) + ' week(s) on ' +
		--																			CASE WHEN freq_interval &  1 = 1 	THEN 'Sunday, ' 	ELSE '' END +
		--																			CASE WHEN freq_interval &  2 = 2 	THEN 'Monday, ' 	ELSE '' END +
		--																			CASE WHEN freq_interval &  4 = 4 	THEN 'Tuesday, ' 	ELSE '' END +
		--																			CASE WHEN freq_interval &  8 = 8 	THEN 'Wednesday, '	ELSE '' END +
		--																			CASE WHEN freq_interval & 16 = 16	THEN 'Thursday, ' 	ELSE '' END +
		--																			CASE WHEN freq_interval & 32 = 32	THEN 'Friday, ' 	ELSE '' END +
		--																			CASE WHEN freq_interval & 64 = 64	THEN 'Saturday, ' 	ELSE '' END								
		--										WHEN  16 THEN 'Occurs every ' + CAST(freq_recurrence_factor AS varchar(10)) + ' month(s) on day ' +
		--																		CAST(freq_interval AS varchar(10)) + ' of that month'
		--										WHEN  32 THEN 'Occurs every ' + CAST(freq_recurrence_factor AS varchar(10)) + ' month(s) on the ' +
		--																			CASE freq_relative_interval 
		--																				WHEN  1 THEN 'First'
		--																				WHEN  2 THEN 'Second'
		--																				WHEN  4 THEN 'Third'
		--																				WHEN  8 THEN 'Fourth'
		--																				WHEN 16 THEN 'Last'
		--																				ELSE ''
		--																			END + ' ' +
		--																			CASE freq_interval
		--																				WHEN 1 THEN 'Sunday'
		--																				WHEN 2 THEN 'Monday'
		--																				WHEN 3 THEN 'Tuesday'
		--																				WHEN 4 THEN 'Wednesday'
		--																				WHEN 5 THEN 'Thursday'
		--																				WHEN 6 THEN 'Friday'
		--																				WHEN 7 THEN 'Saturday'
		--																				WHEN 8 THEN 'Day'
		--																				WHEN 9 THEN 'Weekday'
		--																				WHEN 10 THEN 'Weekend Day'
		--																				ELSE ''
		--																			END
		--										WHEN  64 THEN 'Start automatically when SQL Server Agent Starts'
		--										WHEN 128 THEN 'Start whenever CPU(s) becomes idle'
		--										ELSE ''
		--									END +
		--									CASE freq_subday_type
		--										WHEN 1 THEN ', at ' + LEFT(REPLICATE('0', 6 - LEN(CAST(active_start_time AS varchar(6)))) + CAST(active_start_time AS varchar(6)), 2) + ':' +
		--																SUBSTRING(REPLICATE('0', 6-LEN(CAST(active_start_time AS varchar(6)))) + CAST(active_start_time AS varchar(6)), 3, 2) + ':' + 
		--																RIGHT(REPLICATE('0', 6-LEN(CAST(active_start_time AS varchar(6)))) + CAST(active_start_time AS varchar(6)), 2)
		--										WHEN 2 THEN ', every ' + CAST(freq_subday_interval AS varchar(10)) + ' second(s) between ' + LEFT(REPLICATE('0', 6 - LEN(CAST(active_start_time AS varchar(6)))) + CAST(active_start_time AS varchar(6)), 2) + ':' +
		--																SUBSTRING(REPLICATE('0', 6-LEN(CAST(active_start_time AS varchar(6)))) + CAST(active_start_time AS varchar(6)), 3, 2) + ':' + 
		--																RIGHT(REPLICATE('0', 6-LEN(CAST(active_start_time AS varchar(6)))) + CAST(active_start_time AS varchar(6)), 2)
		--																	+ ' and ' + 
		--																			LEFT(REPLICATE('0', 6 - LEN(CAST(active_end_time AS varchar(6)))) + CAST(active_end_time AS varchar(6)), 2) + ':' +
		--																			SUBSTRING(REPLICATE('0', 6-LEN(CAST(active_end_time AS varchar(6)))) + CAST(active_end_time AS varchar(6)), 3, 2) + ':' + 
		--																			RIGHT(REPLICATE('0', 6-LEN(CAST(active_end_time AS varchar(6)))) + CAST(active_end_time AS varchar(6)), 2)
		--										WHEN 4 THEN ', every ' + CAST(freq_subday_interval AS varchar(10)) + ' minute(s) between ' + LEFT(REPLICATE('0', 6 - LEN(CAST(active_start_time AS varchar(6)))) + CAST(active_start_time AS varchar(6)), 2) + ':' +
		--																SUBSTRING(REPLICATE('0', 6-LEN(CAST(active_start_time AS varchar(6)))) + CAST(active_start_time AS varchar(6)), 3, 2) + ':' + 
		--																RIGHT(REPLICATE('0', 6-LEN(CAST(active_start_time AS varchar(6)))) + CAST(active_start_time AS varchar(6)), 2)
		--																+ ' and ' + 
		--																			LEFT(REPLICATE('0', 6 - LEN(CAST(active_end_time AS varchar(6)))) + CAST(active_end_time AS varchar(6)), 2) + ':' +
		--																			SUBSTRING(REPLICATE('0', 6-LEN(CAST(active_end_time AS varchar(6)))) + CAST(active_end_time AS varchar(6)), 3, 2) + ':' + 
		--																			RIGHT(REPLICATE('0', 6-LEN(CAST(active_end_time AS varchar(6)))) + CAST(active_end_time AS varchar(6)), 2)
		--										WHEN 8 THEN ', every ' + CAST(freq_subday_interval AS varchar(10)) + ' hour(s) between ' + LEFT(REPLICATE('0', 6 - LEN(CAST(active_start_time AS varchar(6)))) + CAST(active_start_time AS varchar(6)), 2) + ':' +
		--																SUBSTRING(REPLICATE('0', 6-LEN(CAST(active_start_time AS varchar(6)))) + CAST(active_start_time AS varchar(6)), 3, 2) + ':' + 
		--																RIGHT(REPLICATE('0', 6-LEN(CAST(active_start_time AS varchar(6)))) + CAST(active_start_time AS varchar(6)), 2)
		--																	+ ' and ' + 
		--																			LEFT(REPLICATE('0', 6 - LEN(CAST(active_end_time AS varchar(6)))) + CAST(active_end_time AS varchar(6)), 2) + ':' +
		--																			SUBSTRING(REPLICATE('0', 6-LEN(CAST(active_end_time AS varchar(6)))) + CAST(active_end_time AS varchar(6)), 3, 2) + ':' + 
		--																			RIGHT(REPLICATE('0', 6-LEN(CAST(active_end_time AS varchar(6)))) + CAST(active_end_time AS varchar(6)), 2)
		--											ELSE ''
		--									END, ', ,', ','
		--						), ', at', ' at'
		--				)		AS [ScheduleInfo]
		--	FROM		msdb.dbo.sysjobs				J WITH (NOLOCK)
		--				LEFT JOIN syslogins				P WITH (NOLOCK)		ON J.owner_sid		= P.sid
		--				LEFT JOIN msdb.dbo.sysjobhistory		H WITH (NOLOCK)		ON J.job_id		= H.job_id
		--													   AND H.step_id		= 0
		--				LEFT JOIN msdb.dbo.sysjobschedules		S WITH (NOLOCK)		ON J.job_id		= S.job_id
		--																			   AND S.enabled		= 1
		--	GROUP BY	J.name
		--				,P.name 
		--				,J.enabled
		--				,S.name	
		--				,S.freq_type
		--				,S.freq_interval
		--				,S.freq_recurrence_factor
		--				,S.freq_relative_interval
		--				,S.freq_subday_type
		--				,S.freq_subday_interval
		--				,S.active_start_date
		--				,S.active_start_time
		--				,S.active_end_date
		--				,S.active_end_time
		--	ORDER BY	J.Name


		--OPEN CURSOR_SQLJOBS
		
		--FETCH NEXT FROM CURSOR_SQLJOBS 
		--INTO @SQLJob, @Owner, @Enabled, @LastFailureDt, @LastSuccessDt
		--	 ,@NextRunDt, @ScheduleName, @ScheduleInfo
	
		--IF @@FETCH_STATUS = 0
		--	BEGIN
		--		PRINT ''
		--		PRINT 'SQL Jobs:'			
		--	END

		--SET @PrevSQLJob = ''
		
		--WHILE @@FETCH_STATUS = 0
		--BEGIN
		--		IF @SQLJob <> @PrevSQLJob
		--			BEGIN
		--				PRINT '    ' + @SQLJob
		--				SET @PrevSQLJob = @SQLJob
		--			END
				
		--	PRINT '        Job Owner:      ' + ISNULL(@Owner, 'Unknown')
		--	PRINT '        Enabled:        ' + CASE WHEN @Enabled = 1 THEN 'Yes' ELSE 'No' END
		--	PRINT '        Schedule Name:  ' + ISNULL(@ScheduleName, '')
		--	PRINT '        Schedule Info:  ' + ISNULL(@ScheduleInfo, '')
		--	PRINT '        Last Success:   ' + ISNULL(CONVERT(varchar(25), @LastSuccessDt, 120), '')
		--	PRINT '        Last Faileure:  ' + ISNULL(CONVERT(varchar(25), @LastFailureDt, 120), '')
		--	PRINT '        Next Run:       ' + ISNULL(CONVERT(varchar(25), @NextRunDt, 120), '')
		--	PRINT ''
			
		--	FETCH NEXT FROM CURSOR_SQLJOBS 
		--	INTO @SQLJob, @Owner, @Enabled, @LastFailureDt, @LastSuccessDt
		--		 ,@NextRunDt, @ScheduleName, @ScheduleInfo
		--END
		
		--CLOSE CURSOR_SQLJOBS
		--DEALLOCATE CURSOR_SQLJOBS			

		DROP TABLE #ConfigReport
		DROP TABLE #DriveInfo
		DROP TABLE #ServerInfo
		DROP TABLE #FTReport
		DROP TABLE #DBReplReport
		DROP TABLE #DBFileReport
		DROP TABLE #DBDataFileInfo
	END