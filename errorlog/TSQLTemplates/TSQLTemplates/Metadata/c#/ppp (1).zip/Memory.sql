/* Large Server: Total Memory: 32GB 


  Max Server Memory       28GB 

  Min Server Memory  2GB  */ 



--first you must ensure show advanced options is enabled 

exec sp_configure 'show advanced options', 1 

reconfigure 

--set max\min server memory 

exec sp_configure 'max server memory', 28672  

reconfigure 

exec sp_configure 'min server memory', 2048 

reconfigure 

--verify max\min server memory settings (config_value and run_value) 

exec sp_configure 'max server memory' 

exec sp_configure 'min server memory' 

--disable show advanced options is enabled 

exec sp_configure 'show advanced options', 0 

reconfigure 
