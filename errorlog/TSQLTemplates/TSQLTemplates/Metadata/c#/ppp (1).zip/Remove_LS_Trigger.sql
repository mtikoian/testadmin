 DECLARE @sql VARCHAR(max)
	,@Text VARCHAR(max)
	,@ProcName VARCHAR(500)
	,@ProcName1 VARCHAR(500)
DECLARE @T TABLE (
	ProcName VARCHAR(200)
	,sql VARCHAR(max)
	,ErrorMessage VARCHAR(4000)
	)
--DECLARE @sqlToRun VARCHAR(1000), @searchFor VARCHAR(100), @replaceWith VARCHAR(100)

---- text to search for
--SET @searchFor = '[MY-SERVER]'
---- text to replace with
--SET @replaceWith = '[MY-SERVER2]'

DECLARE c CURSOR
FOR
SELECT NAME
	,DEFINITION
FROM sys.all_objects a
INNER JOIN sys.sql_modules b ON a.object_id = b.object_id
WHERE type IN (
--'TT'	--TYPE_TABLE
--,'FN'	--SQL_SCALAR_FUNCTION
--,'R' 	--RULE
--,'IF'	--SQL_INLINE_TABLE_VALUED_FUNCTION
--,'C' 	--CHECK_CONSTRAINT
--,'UQ'	--UNIQUE_CONSTRAINT
--,'SQ'	--SERVICE_QUEUE
--,'F' 	--FOREIGN_KEY_CONSTRAINT
--,'U' 	--USER_TABLE
--,'FS'	--CLR_SCALAR_FUNCTION
--,'D' 	--DEFAULT_CONSTRAINT
--,'PK'	--PRIMARY_KEY_CONSTRAINT
--,'V' 	--VIEW
--,'S' 	--SYSTEM_TABLE
--,'AF'	--AGGREGATE_FUNCTION
--,'IT'	--INTERNAL_TABLE
--,'P' 	--SQL_STORED_PROCEDURE
--,'X' 	--EXTENDED_STORED_PROCEDURE
--,'TF'	--SQL_TABLE_VALUED_FUNCTION
'TR'	--SQL_TRIGGER
--,'PC'	--CLR_STORED_PROCEDURE
		)
	AND NAME NOT LIKE 'dt_%'
	AND NAME NOT LIKE 'sys_%'
	AND  (DEFINITION LIKE '%' + REPLACE(REPLACE('pensql11',']','\]'),'[','\[') + '%' ESCAPE '\'
	OR DEFINITION LIKE '%' + REPLACE(REPLACE('dcssql.',']','\]'),'[','\[') + '%' ESCAPE '\'
	OR DEFINITION LIKE '%' + REPLACE(REPLACE('dcssql_live.',']','\]'),'[','\[') + '%' ESCAPE '\'
	OR DEFINITION LIKE '%' + REPLACE(REPLACE('bspsql.',']','\]'),'[','\[') + '%' ESCAPE '\'
	OR DEFINITION LIKE '%' + REPLACE(REPLACE('pensql08.',']','\]'),'[','\[') + '%' ESCAPE '\')
OPEN C

FETCH NEXT
FROM c
INTO @ProcName
	,@Text

WHILE @@FETCH_STATUS = 0
BEGIN
	SET @text = replace (@text,'CREATE TRIGGER', 'ALTER TRIGGER' )
	SET @text = replace (@text,'CREATE  TRIGGER', 'ALTER TRIGGER' )
    SET @text = replace (@text,'CREATE   TRIGGER', 'ALTER TRIGGER' )
	SET @text = replace (@text,'CREATE    TRIGGER', 'ALTER TRIGGER' )
    SET @text = replace (@text,'CREATE     TRIGGER', 'ALTER TRIGGER' )
    SET @text = replace (@text,'CREATE      TRIGGER', 'ALTER TRIGGER' )
    SET @text = replace (@text,'CREATE       TRIGGER', 'ALTER TRIGGER' )
    SET @text = replace (@text,'CREATE        TRIGGER', 'ALTER TRIGGER' )
    SET @text = replace (@text,'CREATE         TRIGGER', 'ALTER TRIGGER' )
	SET @text = replace (@text,'CREATE          TRIGGER', 'ALTER TRIGGER' )
	SET @text = replace (@text,'CREATE           TRIGGER', 'ALTER TRIGGER' )
    SET @text = replace (@text,'CREATE            TRIGGER', 'ALTER TRIGGER' )
	SET @text = replace (@text,'CREATE             TRIGGER', 'ALTER TRIGGER' )
    SET @text = replace (@text,'CREATE              TRIGGER', 'ALTER TRIGGER' )
    SET @text = replace (@text,'CREATE               TRIGGER', 'ALTER TRIGGER' )
    SET @text = replace (@text,'CREATE                TRIGGER', 'ALTER TRIGGER' )
    SET @text = replace (@text,'CREATE                 TRIGGER', 'ALTER TRIGGER' )
    SET @text = replace (@text,'CREATE                  TRIGGER', 'ALTER TRIGGER' )
	SET @text = replace (@text,'CREATE                   TRIGGER', 'ALTER TRIGGER' )
	SET @text = replace (@text,'CREATE                    TRIGGER', 'ALTER TRIGGER' )
    SET @text = replace (@text,'CREATE                     TRIGGER', 'ALTER TRIGGER' )
	SET @text = replace (@text,'CREATE                      TRIGGER', 'ALTER TRIGGER' )
    SET @text = replace (@text,'CREATE                       TRIGGER', 'ALTER TRIGGER' )
    SET @text = replace (@text,'CREATE                        TRIGGER', 'ALTER TRIGGER' )
    SET @text = replace (@text,'CREATE                         TRIGGER', 'ALTER TRIGGER' )
    SET @text = replace (@text,'CREATE                          TRIGGER', 'ALTER TRIGGER' )
    SET @text = replace (@text,'CREATE                           TRIGGER', 'ALTER TRIGGER' )
	
	
	SET @text =  replace (@text,'pensql11.', '' )
	SET @text =  replace (@text,'dcssql.'  , '' )
	SET @text =  replace (@text,'pensql08.', '' )
	SET @text =  replace (@text,'bspsql.'  , '' )
	SET @text =  replace (@text,'DCSSQL_Live.'  , '' )
	--REPLACE(@text, @ProcName, @ProcName + 'CreateTest') -- change proc name 

	BEGIN TRY
		EXEC(@text) -- try to create the proc 
		INSERT @T
		VALUES (
			@ProcName
			,@text
			,ERROR_MESSAGE()
			) -- record procs that could be created 
			PRINT @ProcName
	END TRY

	BEGIN CATCH
		INSERT @T
		VALUES (
			@ProcName
			,@text
			,ERROR_MESSAGE()
			) -- record procs that couldn't be created 
	END CATCH
	FETCH NEXT
	FROM c
	INTO @ProcName
		,@Text
END

CLOSE c

DEALLOCATE c

SELECT *
FROM @T
WHERE errormessage IS NOT NULL
ORDER BY procname
GO