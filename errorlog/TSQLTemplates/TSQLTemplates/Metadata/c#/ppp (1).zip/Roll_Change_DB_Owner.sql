--Description:Script that change the database Owner to SA
SET NOCOUNT ON;
DECLARE @ScriptList TABLE (   Script VARCHAR(MAX))
INSERT INTO @ScriptList
SELECT
           '-- Revert database: [' + d.name + '] to owned by: ['+ SUSER_SNAME(owner_sid)  + ']' + CHAR(13) + CHAR(10)
        + 'ALTER AUTHORIZATION ON DATABASE::' + d.name + ' to [' + SUSER_SNAME(owner_sid) + '];'
FROM sys.databases  d
WHERE
        SUSER_SNAME(owner_sid) <> SUSER_SNAME(0x01);

		select * from @ScriptList

