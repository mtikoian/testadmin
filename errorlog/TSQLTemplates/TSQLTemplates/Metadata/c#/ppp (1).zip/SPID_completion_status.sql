select servername = @@servername 
,der.session_id
,der.start_time
,der.status
,der.percent_complete
,dbname = db_name(der.database_id)
,der.last_wait_type
,der.blocking_session_id
,runningsince = datediff(minute, der.start_time,getdate())
,runningforanother = case percent_complete
when 0 then 0
else ((( datediff(minute, start_time, getdate())*100)/percent_complete)-(datediff(minute,start_time,getdate()))) end
,der.command
,st.text
from sys.dm_exec_requests der
cross apply sys.dm_exec_sql_text(der.sql_handle) st
where session_id>50
and session_id <> @@spid