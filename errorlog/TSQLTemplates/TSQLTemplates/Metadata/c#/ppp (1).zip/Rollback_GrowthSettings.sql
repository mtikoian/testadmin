DECLARE @DbName VARCHAR(255);
DECLARE @FileName  VARCHAR(max);
DECLARE @GrowthOption  VARCHAR(12);
DECLARE @growth bigint;
DECLARE @size  bigint;
PRINT '/*****Rollback Growth Settings*****/';

DECLARE CURSOR_DBGrowthRb CURSOR FAST_FORWARD
FOR
SELECT 
 SD.name  as sDBName, 
 SF.name  as vFileName, 
 CASE is_percent_growth 
 WHEN 1 
	THEN 'Percentage' 
 WHEN 0 THEN 'MB' 
 END AS  vGrowthOption,
 case when is_percent_growth =1 then growth else growth*8/1024 end as vgrowth,
 size *8/1024 as vsize
FROM sys.master_files SF
INNER JOIN 
SYS.DATABASES SD 
ON 
SD.database_id = SF.database_id;

OPEN CURSOR_DBGrowthRb;

FETCH NEXT FROM CURSOR_DBGrowthRb
INTO @DbName, @FileName ,@GrowthOption , @growth , @size;  

 

WHILE @@FETCH_STATUS = 0
BEGIN

PRINT 	'ALTER DATABASE '+ @DbName +' MODIFY FILE (NAME = '+@FileName+',FILEGROWTH = '+ cast(@growth as varchar)+  CASE @GrowthOption 
 WHEN 'Percentage'
	THEN '%' 
 WHEN 'MB' THEN 'MB'  end  +')';

	FETCH NEXT FROM CURSOR_DBGrowthRb
	INTO @DbName, @FileName ,@GrowthOption , @growth , @size  ;
END;

CLOSE CURSOR_DBGrowthRb;
DEALLOCATE CURSOR_DBGrowthRb;