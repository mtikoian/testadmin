

-- pUtilDeleteStmtDemog @clearDemogDate = '10/7/2007'


CREATE    proc [pUtilDeleteStmtDemog] @clearDemogDate char(10)



as 



set nocount on 



declare @stmtDemogCnt int

declare @stmtFundCnt int

declare @stmtSrcCnt int

declare @stmtLoanCnt int

declare @stmtEquivShrsCnt int



select 'Clearing out ' + @clearDemogDate



-- declare @clearDemogDate char(10)

-- 

-- select @clearDemogDate = '11/13/2006'

if isdate(@clearDemogDate) = 0 

	Begin



	select @clearDemogDate + 'is not a valid date'



	return



	end 





if object_id('tempdb..#clearDemog') is not null drop table #clearDemog 



create table #clearDemog(demogId int)

create clustered index #ix_clearDemog on #clearDemog(demogId)



--print 'Getting demogIds to delete'



insert into #clearDemog(demogId)

select demogId from stmtDemog

where fromDate=@clearDemogDate

and toDate=@clearDemogDate





--print 'delete stmtFund'





delete child 

from stmtFund child

inner join #clearDemog c 

on c.demogId=child.demogId 



select @stmtFundCnt = @@rowCount 



--print 'delete stmtSrc'



delete child 

from stmtSrc child

inner join #clearDemog c 

on c.demogId=child.demogId 



select @stmtSrcCnt = @@rowCount 



--print 'delete stmtLoan'



delete child 

from stmtLoan child

inner join #clearDemog c 

on c.demogId=child.demogId 



select @stmtLoanCnt = @@rowCount 



--print 'delete stmtEquivShrs'



delete child 

from stmtEquivShrs child

inner join #clearDemog c 

on c.demogId=child.demogId 



select @stmtEquivShrsCnt = @@rowCount 



--print 'delete stmtDemog'



delete child 

from stmtDemog child

inner join #clearDemog c 

on c.demogId=child.demogId 



select @stmtDemogCnt = @@rowCount





select @stmtDemogCnt [Demog Records Deleted]

select @stmtFundCnt [Fund Records Deleted]

select @stmtSrcCnt [Source Records Deleted]

select @stmtLoanCnt [Loan Records Deleted]

select @stmtEquivShrsCnt [Equiv Shares Records Deleted]





drop table #clearDemog



-- write the last archive date to an extended property



-- 20100708 moved this to the [pUtilDeleteStmtDemogAutomated] job 



--if exists(	select 

--			convert(smalldatetime,value)

--		FROM   

--			::fn_listextendedproperty 

--				(

--				'lastDailyDemogDeleteDate'

--				, 'user'

--				, 'dbo'

--				, 'table'

--				, 'stmtDemog'

--				, null

--				,null)

--	)

--		exec sp_updateextendedproperty 

--			'lastDailyDemogDeleteDate'

--			,@clearDemogDate

--			,'user','dbo'

--			,'table','stmtDemog'

--else

--

--		exec sp_addextendedproperty 

--			'lastDailyDemogDeleteDate'

--			,@clearDemogDate

--			,'user'	,'dbo'

--			,'table','stmtDemog'







-- select * From stmtdemog sd 

-- inner join stmtequivshrs sl

-- on sd.demogID=sl.demogId

-- where sd.fromDate='12/29/2006'

-- and sd.toDate='12/29/2006'





set nocount off 










