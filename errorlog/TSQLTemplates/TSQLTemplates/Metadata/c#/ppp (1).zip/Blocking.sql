SELECT
Blocking.session_id as BlockingSessionId
, Sess.login_name AS BlockingUser
, BlockingSQL.text AS BlockingSQL
, Waits.wait_type WhyBlocked
, Blocked.session_id AS BlockedSessionId
, USER_NAME(Blocked.user_id) AS BlockedUser
, BlockedSQL.text AS BlockedSQL
, DB_NAME(Blocked.database_id) AS DatabaseName
FROM sys.dm_exec_connections AS Blocking
INNER JOIN sys.dm_exec_requests AS Blocked
ON Blocking.session_id = Blocked.blocking_session_id
INNER JOIN sys.dm_os_waiting_tasks AS Waits
ON Blocked.session_id = Waits.session_id
RIGHT OUTER JOIN sys.dm_exec_sessions Sess
ON Blocking.session_id = sess.session_id
CROSS APPLY sys.dm_exec_sql_text(Blocking.most_recent_sql_handle)
AS BlockingSQL
CROSS APPLY sys.dm_exec_sql_text(Blocked.sql_handle) AS BlockedSQL
ORDER BY BlockingSessionId, BlockedSessionId

sp_whoisactive @get_locks =1 , @find_block_leaders = 2,@get_plans = 1 ,@get_outer_command=1,@get_transaction_info=1

sp_whoisactive @get_locks =1 , @find_block_leaders = 2,@get_plans = 1 
SELECT o.name, i.name 
FROM sys.partitions p 
JOIN sys.objects o ON p.object_id = o.object_id 
JOIN sys.indexes i ON p.object_id = i.object_id 
AND p.index_id = i.index_id 
WHERE p.hobt_id =  72057595981004800

SELECT OBJECT_NAME(p.object_id) AS TableName , 
       i.name AS IndexName 
FROM sys.partitions AS p 
     INNER JOIN sys.indexes AS i ON p.object_id = i.object_id 
                                    AND p.index_id = i.index_id 
WHERE partition_id = 72057595660599296

SELECT OBJECT_NAME(ind.OBJECT_ID) AS TableName, 
ind.name AS IndexName, indexstats.index_type_desc AS IndexType, 
indexstats.avg_fragmentation_in_percent 
FROM sys.dm_db_index_physical_stats(DB_ID(), NULL, NULL, NULL, NULL) indexstats 
INNER JOIN sys.indexes ind  
ON ind.object_id = indexstats.object_id 
AND ind.index_id = indexstats.index_id 
WHERE ind.object_id = (select object_id from sys.objects where name = 'ACCTINVEST ')
--and indexstats.avg_fragmentation_in_percent > 30 
ORDER BY indexstats.avg_fragmentation_in_percent DESC

--example:  
--waitresource=KEY: 6:72057594057457664 
--dbid=6 objectname=AdventureWorks.dbo.T2 
--associatedObjectId=72057594057457664 
--keylock hobt_id=72057594057457664

--From the Hobt_id we get all information:

SELECT o.name, i.name 
FROM sys.partitions p 
JOIN sys.objects o ON p.object_id = o.object_id 
JOIN sys.indexes i ON p.object_id = i.object_id 
AND p.index_id = i.index_id 
WHERE p.hobt_id = 72057595981594624 --Change value 
--KEY: 2:1125899909070848 (08c7c0935e5f)                                                                                                                                                                                                                          
select object_id(261575970)

  
--Table      DatabaseID:ObjectID      TAB: 5:261575970 
--In this case, database ID 5 is the pubs sample database and object ID 261575970 is the titles table. 
--Page      DatabaseID:FileID:PageID      PAG: 5:1:104 
--In this case, database ID 5 is pubs, file ID 1 is the primary data file, and page 104 is a page belonging to the titles table. 
--Key      DatabaseID:ObjectID:IndexID (Hash value for index key)      KEY: 5:261575970:1 (5d0164fb1eac) 
--In this case, database ID 5 is pubs, object ID 261575970 is the titles table, index ID 1 is the clustered index, and the hash value indicates the index key value for the particular row.

select * from sys.indexes
where object_id = (select object_id from sys.objects where name = 'ACCTINVEST ')

select * from master..sysprocesses

where blocked <> 0

                   

sp_helpdb                            

sp_whoisactive                                                  
                                                                                                                                                                                                                       

--CREATE  NONCLUSTERED INDEX [PLANGROUP_IDX1] ON [dbo].[PLANGROUP]
--(
--       [plag_dir_lna] ASC
--)

--INCLUDE (plag_btch_ct, plag_cur_dt)
sp_whoisactive @get_locks =1 , @find_block_leaders = 2,@get_plans = 1 ,@get_outer_command=1,@get_transaction_info=1
								   
--ALTER INDEX PLANGROUP_IDX1 ON rkdb.[dbo].[PLANGROUP] REBUILD WITH (SORT_IN_TEMPDB = OFF, ONLINE = ON, MAXDOP = 0)

--ALTER INDEX PK_PLANGROUP ON rkdb.[dbo].[PLANGROUP] REBUILD WITH (SORT_IN_TEMPDB = OFF, ONLINE = ON, MAXDOP = 0)

--ALTER INDEX PLANGROUP_IDX2 ON rkdb.[dbo].[PLANGROUP] REBUILD WITH (SORT_IN_TEMPDB = OFF, ONLINE = ON, MAXDOP = 0)              

--select * from rkdb.[dbo].[PLANGROUP]                           


--Page locks             

--DBCC PAGE('MSSQLTIPS',1,143,3) WITH TABLERESULTS 
--DBCC PAGE (bsp1, 1, 8168212, 0);
DBCC TRACEON(3604)

DBCC PAGE (18, 1, 8168212,0);

DBCC PAGE
(
['database name'|database id], -- can be the actual name or id of the database
file number, -- the file number where the page is found
page number, -- the page number within the file 
print option = [0|1|2|3] -- display option; each option provides differing levels of information
)

SELECT o.name, i.name 
FROM sys.partitions p 
JOIN sys.objects o ON p.object_id = o.object_id 
JOIN sys.indexes i ON p.object_id = i.object_id 
AND p.index_id = i.index_id 
WHERE p.hobt_id = 72057594072465408  