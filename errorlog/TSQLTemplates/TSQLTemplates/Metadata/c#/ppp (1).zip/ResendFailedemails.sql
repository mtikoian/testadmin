 /*
--To view failures from log from past one day
SELECT * FROM msdb.dbo.sysmail_event_log
WHERE event_type = 'error'
AND log_date >= dateadd(d, -1, getdate())
--To view mail failures with details
SELECT * 
FROM msdb.dbo.sysmail_faileditems 
WHERE mailitem_id = 56299; 
*/
DECLARE @Value INT

DECLARE CURSOR_mailitems CURSOR FAST_FORWARD
FOR
--Get distinct mail id's to reprocess
SELECT DISTINCT a.mailitem_id
FROM msdb.dbo.sysmail_faileditems a
INNER JOIN msdb.dbo.sysmail_event_log b ON a.mailitem_id = b.mailitem_id
WHERE b.event_type = 'error'
	AND b.log_date >= dateadd(d, - 1, getdate()) -- Failed for last one day

OPEN CURSOR_mailitems

FETCH NEXT
FROM CURSOR_mailitems
INTO @Value

WHILE @@FETCH_STATUS = 0
BEGIN
	DECLARE @to VARCHAR(max)
	DECLARE @copy VARCHAR(max)
	DECLARE @title NVARCHAR(255)
	DECLARE @msg NVARCHAR(max)

	SELECT @to = recipients
		,@copy = copy_recipients
		,@title = [subject]
		,@msg = body
	FROM msdb.dbo.sysmail_faileditems
	WHERE mailitem_id = @Value

	SELECT @to
		,@copy
		,@msg
		,@title

	--EXEC msdb.dbo.sp_send_dbmail
	--@recipients = @to,
	--@copy_recipients = @copy,
	--@body = @msg,
	--@subject = @title,
	--@body_format = 'HTML';
	FETCH NEXT
	FROM CURSOR_mailitems
	INTO @Value
END

CLOSE CURSOR_mailitems

DEALLOCATE CURSOR_mailitems

