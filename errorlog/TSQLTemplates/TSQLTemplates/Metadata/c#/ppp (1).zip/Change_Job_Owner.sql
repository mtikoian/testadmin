--Change Job Owner
SET NOCOUNT ON;
DECLARE @loginame VARCHAR(100);
SET @loginame = N'PENTEGRA\pentdb4'
 
DECLARE @ScriptList TABLE ( ScriptType VARCHAR(20), Script VARCHAR(MAX))
INSERT INTO @ScriptList
SELECT
          'rollforward' as ScriptType
        , 'EXEC msdb..sp_update_job @job_id = ''' + CONVERT(VARCHAR(36), j.job_id) + ''''
        + ', @owner_login_name =''' +@loginame + '''' as Script
FROM msdb.dbo.sysjobs j
LEFT OUTER JOIN sys.syslogins sl
        ON j.owner_sid = sl.sid
WHERE j.enabled = 1  AND sl.name <> SUSER_SNAME(0x01);
  
SELECT Script  FROM @scriptlist WHERE ScriptType = 'rollforward';