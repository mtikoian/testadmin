DECLARE @DbName VARCHAR(255);
DECLARE @FileName  VARCHAR(max);
DECLARE @GrowthOption  VARCHAR(12);
DECLARE @growth bigint;
DECLARE @size  bigint;
PRINT '/*****Deploy Growth Settings*****/';

DECLARE CURSOR_DBGrowthRb CURSOR FAST_FORWARD
FOR
SELECT distinct 
 SD.name  as sDBName, 
 SF.name  as vFileName, 
 'MB' --Set to % or MB
AS  vGrowthOption,
 case when sf.size *8/1024 > 2000  or tbl.database_id = SF.database_id then 2 else 1 end as  vgrowth,
 sf.size *8/1024 as vsize

FROM sys.master_files SF
INNER JOIN 
SYS.DATABASES SD 
ON 
SD.database_id = SF.database_id
left join (select database_id from sys.master_files 
where size *8/1024 > 2000)tbl
on tbl.database_id = SF.database_id;

OPEN CURSOR_DBGrowthRb;

FETCH NEXT FROM CURSOR_DBGrowthRb
INTO @DbName, @FileName ,@GrowthOption , @growth , @size;  

 

WHILE @@FETCH_STATUS = 0
BEGIN

PRINT 	'ALTER DATABASE '+ @DbName +' MODIFY FILE (NAME = '+@FileName+',FILEGROWTH = '+ case when @growth= 1 then cast(64 as varchar) else cast (128 as varchar) end+  CASE @GrowthOption 
 WHEN 'Percentage'
	THEN '%' 
 WHEN 'MB' THEN 'MB'  end  +')';

	FETCH NEXT FROM CURSOR_DBGrowthRb
	INTO @DbName, @FileName ,@GrowthOption , @growth , @size  ;
END;

CLOSE CURSOR_DBGrowthRb;
DEALLOCATE CURSOR_DBGrowthRb;