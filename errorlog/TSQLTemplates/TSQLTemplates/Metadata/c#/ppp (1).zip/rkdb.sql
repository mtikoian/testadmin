select * from sys.tables 
--where type = 'u'
where name not like  '%2013%'
and name not like   '%2014%'
and name not like   '%2012%'
and name not like   '%2015%'
and name not like   '%2011%'
and name not like   '%2010%'
and name not like   '%2009%'
1168
241
927