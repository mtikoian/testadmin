 DECLARE @sql VARCHAR(max)
	,@Text VARCHAR(max)
	,@ProcName VARCHAR(500)
	,@ProcName1 VARCHAR(500)
DECLARE @T TABLE (
	ProcName VARCHAR(200)
	,sql VARCHAR(max)
	,ErrorMessage VARCHAR(4000)
	)

DECLARE c CURSOR
FOR
SELECT NAME
	,DEFINITION
FROM sys.all_objects
INNER JOIN sys.sql_modules ON all_objects.object_id = sql_modules.object_id
WHERE type IN (
		'p'
		,'tf'
		,'if'
		)
	AND NAME NOT LIKE 'dt_%'
	AND NAME NOT LIKE 'sys_%'

OPEN C

FETCH NEXT
FROM c
INTO @ProcName
	,@Text

WHILE @@FETCH_STATUS = 0
BEGIN
	SET @text = REPLACE(@text, @ProcName, @ProcName + 'CreateTest') -- change proc name 

	BEGIN TRY
		--EXEC(@text) -- try to create the proc 
		INSERT @T
		VALUES (
			@ProcName
			,@text
			,ERROR_MESSAGE()
			) -- record procs that could be created 
	END TRY

	BEGIN CATCH
		INSERT @T
		VALUES (
			@ProcName
			,@text
			,ERROR_MESSAGE()
			) -- record procs that couldn't be created 
	END CATCH

	IF EXISTS (
			SELECT *
			FROM sys.all_objects
			WHERE NAME LIKE '%' + @procname + 'createtest'
				AND type = 'p'
			)
	BEGIN
		SET @sql = 'drop procedure ' + (
				SELECT SPECIFIC_NAME
				FROM INFORMATION_SCHEMA.ROUTINES
				WHERE SPECIFIC_name LIKE '%' + @procname + 'createtest'
					AND ROUTINE_TYPE = 'PROCEDURE'
				)

		--(select name 
		--from sys.all_objects  
		--where name like '%' + @procname + 'createtest' 
		--and type = 'p') 
		EXEC (@sql)

		PRINT @sql
		PRINT ''
	END

	IF EXISTS (
			SELECT *
			FROM sys.all_objects
			WHERE NAME LIKE '%' + @procname + 'createtest'
				AND type IN (
					'if'
					,'tf'
					)
			)
	BEGIN
		SET @sql = 'drop function ' + (
				SELECT NAME
				FROM sys.all_objects
				WHERE NAME LIKE '%' + @procname + 'createtest'
					AND type IN (
						'if'
						,'tf'
						)
				)

		EXEC (@sql)

		PRINT @sql
		PRINT ''
	END

	FETCH NEXT
	FROM c
	INTO @ProcName
		,@Text
END

CLOSE c

DEALLOCATE c

SELECT *
FROM @T
WHERE errormessage IS NOT NULL
ORDER BY procname
GO



