DECLARE @Today char(10)

SET @Today = CONVERT(char(10), GETDATE(), 112) -- Today's Date 
 if object_id('tempdb..#temp1') is not null 
drop table #temp1 

SELECT  top 50 A.name AS [SQLJobName]
--CAST(h.run_date AS VARCHAR(8)) + CAST(h.run_time AS VARCHAR(6)) starttime
--,h.run_date
,CAST
		(
			SUBSTRING
			(
				CAST(run_date AS varchar(8)), 5, 2) + 
					'/' + RIGHT(run_date, 2) + '/' + 
					LEFT(run_date , 4) + ' ' + 
					LEFT(REPLICATE('0', 6 - LEN(CAST(run_time AS varchar(6)))) + 
					CAST(run_time AS varchar(6)), 2) + ':' +
					SUBSTRING(REPLICATE('0', 6-LEN(CAST(run_time AS varchar(6)))) + 
					CAST(run_time AS varchar(6)), 3, 2) + ':' + 
					RIGHT(REPLICATE('0', 6-LEN(CAST(run_time AS varchar(6)))) + 
					CAST(run_time AS varchar(6)), 2
			)
			AS datetime
		) AS [RunDate]
--,CONVERT(char(19), SUBSTRING(CAST(H.run_date AS varchar(8)), 5, 2) + '/' + SUBSTRING(CAST(H.run_date AS varchar(8)), 7, 2) + '/' + LEFT(CAST(H.run_date AS varchar(8)), 4) + ' ' + 
--															LEFT(REPLICATE('0', 6 - LEN(CAST(H.run_time AS varchar(6)))) + CAST(H.run_time AS varchar(6)), 2) + ':' +
--															SUBSTRING(REPLICATE('0', 6-LEN(CAST(H.run_time AS varchar(6)))) + CAST(H.run_time AS varchar(6)), 3, 2) + ':' + 
--															RIGHT(REPLICATE('0', 6-LEN(CAST(H.run_time AS varchar(6)))) + CAST(H.run_time AS varchar(6)), 2), 120)								
	,h.run_duration
	,h.sql_severity
	,h.message
	,h.sql_message_id
	INTO #TEMP1
FROM msdb..sysjobhistory h
INNER JOIN msdb..sysjobsteps b ON h.job_id = b.job_id
	AND h.step_id = b.step_id
INNER JOIN msdb.dbo.sysjobs A
ON A.job_id = H.job_id
WHERE 
--h.job_id = '475400df-512e-41f8-b65e-d6e0e44f8047'
--	AND
	 b.step_name = 'execute master..sqlbackup'
	AND h.run_date >= @Today
	and h.run_status =0
ORDER BY CONVERT(char(19), SUBSTRING(CAST(H.run_date AS varchar(8)), 5, 2) + '/' + SUBSTRING(CAST(H.run_date AS varchar(8)), 7, 2) + '/' + LEFT(CAST(H.run_date AS varchar(8)), 4) + ' ' + 
															LEFT(REPLICATE('0', 6 - LEN(CAST(H.run_time AS varchar(6)))) + CAST(H.run_time AS varchar(6)), 2) + ':' +
															SUBSTRING(REPLICATE('0', 6-LEN(CAST(H.run_time AS varchar(6)))) + CAST(H.run_time AS varchar(6)), 3, 2) + ':' + 
															RIGHT(REPLICATE('0', 6-LEN(CAST(H.run_time AS varchar(6)))) + CAST(H.run_time AS varchar(6)), 2), 120)	desc			 				


SELECT * FROM #TEMP1

WHERE RunDate between DATEADD(minute, -15, getdate())  and  getdate()
and SQLJOBNAME like '%Log Shipping%'
if object_id('tempdb..#temp1') is not null 
drop table #temp1 
