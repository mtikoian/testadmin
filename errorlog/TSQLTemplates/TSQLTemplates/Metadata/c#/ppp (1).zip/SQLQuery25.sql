DECLARE @sql VARCHAR(max)
DECLARE @Text VARCHAR(max)
DECLARE @Backupsql varchar(max)
DECLARE @ObjectName VARCHAR(500)
DECLARE @BkFilename char(30);
DECLARE @ProcName1 VARCHAR(500)
DECLARE @searchFor VARCHAR(100)
DECLARE @replaceWith VARCHAR(100)
set @Backupsql = ''
set @BkFilename = 'bk_' + convert(varchar, getdate(), 112)
select @BkFilename
-- text to search for
SET @searchFor = 'dcssql.'
-- text to replace with
SET @replaceWith = ''
DECLARE @errorlog TABLE (
	ProcName VARCHAR(200)
	,sql VARCHAR(max)
	,ErrorMessage VARCHAR(4000)
	)
CREATE TABLE  #test1(
	[NAME] [nvarchar](128) NOT NULL,
	[DEFINITION] [nvarchar](max) NULL,
	[DEFINITION_bk] [nvarchar](max) NULL,
	[type] [char](2) NOT NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

 
INSERT INTO #test1
SELECT  NAME
	,DEFINITION
	,DEFINITION
	, type 
FROM sys.all_objects AO
INNER JOIN sys.sql_modules  SM ON SM.object_id = AO.object_id
WHERE 
 
type IN (
'TR' --TRIGGER
,'FN' --SQL_SCALAR_FUNCTION
,'P ' --SQL_STORED_PROCEDURE
,'TF' --SQL_TABLE_VALUED_FUNCTION
,'R ' --RULES
,'IF' --SQL_INLINE_TABLE_VALUED_FUNCTION
,'V'  --VIEW
		)
	AND NAME NOT LIKE 'dt_%'
	AND NAME NOT LIKE 'sys_%'
	and DEFINITION LIKE '%' + REPLACE(REPLACE('dcssql.',']','\]'),'[','\[') + '%' ESCAPE '\'
 
 SELECT * FROM #test1
 where DEFINITION like '%create%'


 UPDATE #TEST1
 SET DEFINITION_BK = REPLACE (DEFINITION_BK , NAME , NAME+ '_BK')
-- DECLARE @searchFor VARCHAR(100)
--DECLARE @replaceWith VARCHAR(100)
-- SET @searchFor = 'dcssql.'
---- text to replace with
--SET @replaceWith = ''
 UPDATE  #TEST1
 SET DEFINITION  = REPLACE(DEFINITION, @searchFor , @replaceWith)
 WHERE   DEFINITION LIKE '%' + REPLACE(REPLACE('dcssql.',']','\]'),'[','\[') + '%' ESCAPE '\'

  UPDATE  #TEST1
 SET DEFINITION  = CASE WHEN TYPE = 'TR' THEN REPLACE(DEFINITION,'CREATE TRIGGER', 'ALTER TRIGGER') 
						WHEN TYPE IN ( 'FN','TF','IF') THEN REPLACE(DEFINITION,'CREATE FUNCTION', 'ALTER FUNCTION') 
						WHEN TYPE = 'P ' THEN REPLACE(DEFINITION,'CREATE PROCEDURE', 'ALTER PROCEDURE')			 
						WHEN TYPE = 'R ' THEN REPLACE(DEFINITION,'CREATE RULE', 'ALTER RULE')
						WHEN TYPE = 'V'  THEN REPLACE(DEFINITION,'CREATE VIEW', 'ALTER VIEW') END
-- WHERE   DEFINITION LIKE '%' + REPLACE(REPLACE('dcssql.',']','\]'),'[','\[') + '%' ESCAPE '\'
WHILE @@FETCH_STATUS = 0
BEGIN
    --SET @text = REPLACE(@text,'CREATE TRIGGER', 'ALTER TRIGGER')
	SET @Backupsql = REPLACE(@text, @ObjectName, @ObjectName + @BkFilename ) -- this creates a backup file
	--SET @text = REPLACE(@text, @searchFor , @replaceWith)
	BEGIN TRY
	PRINT @ObjectName + ' has been identified which has references to linked server' + @searchFor
		EXEC(@Backupsql) -- try to create the proc 
		INSERT @errorlog
		VALUES (
			@ObjectName
			,@Backupsql
			,ERROR_MESSAGE()
			) -- record procs that could be created 
	END TRY

	BEGIN CATCH
		INSERT @errorlog
		VALUES (
			@ObjectName
			,@Backupsql
			,ERROR_MESSAGE()
			) -- record procs that couldn't be created 
	END CATCH
	SET @text = REPLACE(@text,'CREATE TRIGGER', 'ALTER TRIGGER')
	SET @text = REPLACE(@text, @searchFor , @replaceWith)
	BEGIN TRY
	 
		EXEC(@text) -- try to create the proc 
		INSERT @errorlog
		VALUES (
			@ObjectName
			,@text
			,ERROR_MESSAGE()
			) -- record procs that could be created 
	END TRY

	BEGIN CATCH
		INSERT @errorlog
		VALUES (
			@ObjectName
			,@text
			,ERROR_MESSAGE()
			) -- record procs that couldn't be created 
	END CATCH






	--IF EXISTS (
	--		SELECT *
	--		FROM sys.all_objects
	--		WHERE NAME LIKE '%' + @ObjectName + 'createtest'
	--			AND type = 'p'
	--		)
	--BEGIN
	--	SET @sql = 'drop procedure ' + (
	--			SELECT SPECIFIC_NAME
	--			FROM INFORMATION_SCHEMA.ROUTINES
	--			WHERE SPECIFIC_name LIKE '%' + @ObjectName + 'createtest'
	--				AND ROUTINE_TYPE = 'PROCEDURE'
	--			)

	--	--(select name 
	--	--from sys.all_objects  
	--	--where name like '%' + @ObjectName + 'createtest' 
	--	--and type = 'p') 
	--	EXEC (@sql)

	--	PRINT @sql
	--	PRINT ''
	--END

	--IF EXISTS (
	--		SELECT *
	--		FROM sys.all_objects
	--		WHERE NAME LIKE '%' + @ObjectName + 'createtest'
	--			AND type IN (
	--				'if'
	--				,'tf'
	--				)
	--		)
	--BEGIN
	--	SET @sql = 'drop function ' + (
	--			SELECT NAME
	--			FROM sys.all_objects
	--			WHERE NAME LIKE '%' + @ObjectName + 'createtest'
	--				AND type IN (
	--					'if'
	--					,'tf'
	--					)
	--			)

	--	EXEC (@sql)

	--	PRINT @sql
	--	PRINT ''
	--END

	FETCH NEXT
	FROM c_trigger
	INTO @ObjectName
		,@Text
END

CLOSE c_trigger

DEALLOCATE c_trigger

SELECT *
FROM @errorlog
WHERE errormessage IS NOT NULL
ORDER BY procname
GO



