sp_whoisactive @find_block_leaders = 2

sp_whoisactive @find_block_leaders = 1
sp_whoisactive @get_locks =1 , @find_block_leaders = 2,@get_plans = 1 
sp_whoisactive 

sp_whoisactive @get_locks =1 , @find_block_leaders = 2,@get_plans = 1 ,@get_outer_command=1,@get_transaction_info=1

EXEC sp_WhoIsActive 
    @find_block_leaders = 1, 
    @sort_order = '[blocked_session_count] DESC'

	select * from master..sysprocesses
	where blocked <> 0 


