
/*
Update indexes off all tables @pi_Indexes = null
indexes of one table @pi_Indexes = 'dbname.schemaname.tablename'
specific index of one table @pi_Indexes = 'dbname.schemaname.tablename'



*/



/*System Databases

exec DBAdmin.dbo.p_admin_DatabaseMaintenance_Wrapper
@pi_Databases = 'msdb ',
@pi_opts = 2,--14 Index, Stats, DBCC  --2 Index
@pi_LockTimeout = NULL,
@pi_LogToTable = 'Y',
@pi_Execute = 'Y',

/* Index procedure input parameters */
@pi_FragmentationLow = NULL,
@pi_FragmentationMedium = 'INDEX_REORGANIZE,INDEX_REBUILD_ONLINE,INDEX_REBUILD_OFFLINE',
@pi_FragmentationHigh = 'INDEX_REBUILD_ONLINE,INDEX_REBUILD_OFFLINE',
@pi_FragmentationLevel1 = 10, --weekend 
@pi_FragmentationLevel2 = 20,--weekend 
@pi_PageCountLevel = 10,--weekend 
@pi_SortInTempdb = 'N',
@pi_MaxDOP = 1,
@pi_FillFactor = NULL,
@pi_PadIndex = NULL,
@pi_LOBCompaction = 'Y',
@pi_UpdateStatistics = 'all',--weekend 
@pi_OnlyModifiedStatistics = 'Y',
@pi_StatisticsSample = NULL,
@pi_StatisticsResample = 'N',
@pi_PartitionLevel = 'n',
@pi_MSShippedObjects = 'y',
@pi_Indexes = NULL,
@pi_TimeLimit = NULL,
@pi_Delay = NULL,
@pi_WaitAtLowPriorityMaxDuration = NULL,
@pi_WaitAtLowPriorityAbortAfterWait = NULL,


/* Databse Integrity Check */
@pi_CheckCommands = 'CHECKDB',
@pi_PhysicalOnly = 'Y',
@pi_NoIndex = 'Y',
@pi_ExtendedLogicalChecks = 'N',
@pi_TabLock = 'N',
@pi_FileGroups = NULL,
@pi_Objects = NULL,


/* Database Backup input parameters */
@pi_Directory = '',
@pi_BackupType = 'FULL',
@pi_Verify = 'Y',
@pi_CleanupTime = 24,
@pi_Compress = 'Y',
@pi_CopyOnly = 'Y',
@pi_ChangeBackupType = 'N',
@pi_BackupSoftware = NULL,
@pi_CheckSum = 'Y',
@pi_BlockSize = NULL,
@pi_BufferCount = NULL,
@pi_MaxTransferSize = NULL,
@pi_NumberOfFiles = 8,
@pi_CompressionLevel = NULL,
@pi_Description = NULL,
@pi_Threads = NULL,
@pi_Throttle = NULL,
@pi_Encrypt = 'N',
@pi_EncryptionAlgorithm = NULL,
@pi_ServerCertificate = NULL,
@pi_ServerAsymmetricKey = NULL,
@pi_EncryptionKey  = NULL,
@pi_ReadWriteFileGroups = 'N',
@pi_OverrideBackupPreference  = 'N',

@pi_PrimaryRecipient = 'vbandi@pentegra.com',
@pi_SecondaryRecipient  = 'vbandi@pentegra.com',
@pi_OnCallRecipient  = 'vbandi@pentegra.com'
*/

/* Only one index */
exec DBAdmin.dbo.p_admin_DatabaseMaintenance_Wrapper
@pi_Databases = 'SP_UsageAndHealth ',
@pi_opts = 2,--14 Index, Stats, DBCC  --2 Index
@pi_LockTimeout = NULL,
@pi_LogToTable = 'Y',
@pi_Execute = 'Y',

/* Index procedure input parameters */
@pi_FragmentationLow = NULL,
@pi_FragmentationMedium = 'INDEX_REORGANIZE,INDEX_REBUILD_ONLINE,INDEX_REBUILD_OFFLINE',
@pi_FragmentationHigh = 'INDEX_REBUILD_ONLINE,INDEX_REBUILD_OFFLINE',
@pi_FragmentationLevel1 = 10, --weekend 
@pi_FragmentationLevel2 = 20,--weekend 
@pi_PageCountLevel = 10,--weekend 
@pi_SortInTempdb = 'N',
@pi_MaxDOP = 1,
@pi_FillFactor = NULL,
@pi_PadIndex = NULL,
@pi_LOBCompaction = 'Y',
@pi_UpdateStatistics = 'all',--weekend 
@pi_OnlyModifiedStatistics = 'Y',
@pi_StatisticsSample = NULL,
@pi_StatisticsResample = 'N',
@pi_PartitionLevel = 'n',
@pi_MSShippedObjects = 'y',
@pi_Indexes = null,
@pi_TimeLimit = NULL,
@pi_Delay = NULL,
@pi_WaitAtLowPriorityMaxDuration = NULL,
@pi_WaitAtLowPriorityAbortAfterWait = NULL,


/* Databse Integrity Check */
@pi_CheckCommands = 'CHECKDB',
@pi_PhysicalOnly = 'Y',
@pi_NoIndex = 'Y',
@pi_ExtendedLogicalChecks = 'N',
@pi_TabLock = 'N',
@pi_FileGroups = NULL,
@pi_Objects = NULL,


/* Database Backup input parameters */
@pi_Directory = '',
@pi_BackupType = 'FULL',
@pi_Verify = 'Y',
@pi_CleanupTime = 24,
@pi_Compress = 'Y',
@pi_CopyOnly = 'Y',
@pi_ChangeBackupType = 'N',
@pi_BackupSoftware = NULL,
@pi_CheckSum = 'Y',
@pi_BlockSize = NULL,
@pi_BufferCount = NULL,
@pi_MaxTransferSize = NULL,
@pi_NumberOfFiles = 8,
@pi_CompressionLevel = NULL,
@pi_Description = NULL,
@pi_Threads = NULL,
@pi_Throttle = NULL,
@pi_Encrypt = 'N',
@pi_EncryptionAlgorithm = NULL,
@pi_ServerCertificate = NULL,
@pi_ServerAsymmetricKey = NULL,
@pi_EncryptionKey  = NULL,
@pi_ReadWriteFileGroups = 'N',
@pi_OverrideBackupPreference  = 'N',

@pi_PrimaryRecipient = 'vbandi@pentegra.com',
@pi_SecondaryRecipient  = 'vbandi@pentegra.com',
@pi_OnCallRecipient  = 'vbandi@pentegra.com'