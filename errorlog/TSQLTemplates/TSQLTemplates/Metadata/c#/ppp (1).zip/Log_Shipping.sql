SET NOCOUNT ON

SELECT      'Primary' ,
                CASE WHEN E.name IS NULL THEN '0' ELSE '1' END ,
                A.primary_server ,
                B.primary_database,
                C.secondary_server,
                C.secondary_database ,
                B.monitor_server ,
                B.backup_directory ,
                B.backup_share,
                ISNULL(B.last_backup_file, 'NULL') ,
                ISNULL(CONVERT(varchar(30), B.last_backup_date, 120), 'NULL') ,
                'NULL' ,
                'NULL' ,
                'NULL' ,
                'NULL' ,
                ISNULL(CAST(B.backup_retention_period AS varchar(20)), 'NULL') ,
                ISNULL(D.name, 'NULL') ,
                'NULL' ,
                'NULL'
FROM        msdb.dbo.log_shipping_monitor_primary A
                JOIN msdb.dbo.log_shipping_primary_databases B ON A.primary_id = B.primary_id
                JOIN msdb.dbo.log_shipping_primary_secondaries C ON A.primary_id = C.primary_Id
                LEFT JOIN msdb.dbo.sysjobs D ON B.backup_job_id = D.job_Id
                LEFT JOIN master.sys.databases E ON A.primary_database = E.name
UNION ALL                
SELECT      'Secondary' ,
                CASE WHEN E.name IS NULL THEN '0' ELSE '1' END ,
                A.primary_server ,
                A.primary_database ,
                A.secondary_server,
                A.secondary_database ,
                B.monitor_server ,
                B.backup_source_directory ,
                B.backup_destination_directory ,
                'NULL' ,
                'NULL' ,
                ISNULL(A.last_copied_file, 'NULL') ,
                ISNULL(CONVERT(varchar(30), A.last_copied_date, 120), 'NULL') ,
                ISNULL(A.last_restored_file, 'NULL') ,
                ISNULL(CONVERT(varchar(30), A.last_restored_date, 120), 'NULL'),
                CAST(B.file_retention_period AS varchar(10)) ,
                'NULL' ,
                ISNULL(C.name, 'NULL') ,
                ISNULL(D.name, 'NULL')
FROM        msdb.dbo.log_shipping_monitor_secondary A
                JOIN msdb.dbo.log_shipping_secondary B ON A.secondary_id = B.secondary_id
                LEFT JOIN msdb.dbo.sysjobs C ON B.copy_job_id = C.job_id
                LEFT JOIN msdb.dbo.sysjobs D ON B.restore_job_id = D.job_id
                LEFT JOIN master.sys.databases E ON A.secondary_database = E.name



