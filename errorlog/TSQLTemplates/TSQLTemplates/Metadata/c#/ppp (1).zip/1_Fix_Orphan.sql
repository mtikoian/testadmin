DECLARE @SQL NVARCHAR(MAX);
CREATE TABLE #OrphanedUsers ([Database] SYSNAME, [User] SYSNAME);
SET @SQL = '
	USE [?];
	IF ''?'' NOT IN (''master'',''tempdb'',''model'',''msdb'')
	BEGIN
		DECLARE User_Cursor CURSOR FAST_FORWARD FOR
			SELECT	dp.name 
			FROM	sys.database_principals dp
			WHERE	type = ''S''
					AND NOT EXISTS (SELECT 1 FROM master.sys.server_principals sp WHERE sp.SID = dp.SID)
					AND dp.principal_id > 4;
		DECLARE @UserName SYSNAME;
		
		OPEN User_Cursor;
		WHILE 1=1 BEGIN
		
			FETCH User_Cursor INTO @UserName;
			
			IF NOT @@FETCH_STATUS = 0 BREAK;
			
			IF @UserName NOT IN (''dbo'',''guest'',''sys'',''INFORMATION_SCHEMA'')
			BEGIN
				IF EXISTS (SELECT 1 FROM master.sys.server_principals WHERE name = @UserName)
				BEGIN
					EXEC sp_change_users_login ''auto_fix'',@UserName;
				END
				ELSE BEGIN
					INSERT #OrphanedUsers
					SELECT ''?'', @UserName;
				END
			END
		END
		
		CLOSE User_Cursor;
		DEALLOCATE User_Cursor;
	END
	'

EXEC sp_MSforeachdb @command1 = @SQL;
SELECT * FROM #OrphanedUsers ORDER BY [Database];
DROP TABLE #OrphanedUsers;