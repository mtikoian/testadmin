 --Search Text in any code
USE [aspnetdb];

SELECT o.NAME
	,m.DEFINITION
	,o.xtype
	,s.NAME
	,m.object_id
FROM [aspnetdb].sys.sql_modules m
INNER JOIN [aspnetdb]..sysobjects o ON m.object_id = o.id
INNER JOIN sys.schemas s ON o.uid = s.schema_id
WHERE lower([definition]) LIKE lower('%hi%')

USE [aspnetdb];

SELECT t.NAME
	,m.DEFINITION
	,m.object_id
FROM sys.triggers t
INNER JOIN sys.sql_modules m ON m.object_id = t.object_id
WHERE parent_class = 0
	AND lower([definition]) LIKE lower('%hi%')

--Object Name Search
USE [aspnetdb];

SELECT ps.NAME
	,p.NAME
	,p.type
	,s.NAME
	,o.NAME
	,o.type
FROM sys.all_objects o
INNER JOIN sys.all_objects p ON p.object_id = o.parent_object_id
INNER JOIN sys.schemas s ON s.schema_id = o.schema_id
INNER JOIN sys.schemas ps ON ps.schema_id = p.schema_id
WHERE lower(o.NAME) LIKE lower('%tran%')

UNION

SELECT NULL
	,NULL
	,NULL
	,s.NAME
	,o.NAME
	,o.type
FROM sys.all_objects o
INNER JOIN sys.schemas s ON o.schema_id = s.schema_id
WHERE o.parent_object_id = 0
	AND s.NAME <> 'INFORMATION_SCHEMA'
	AND lower(o.NAME) LIKE lower('%tran%')

USE [aspnetdb];

SELECT p.NAME AS 'parent'
	,p.type AS 'parenttype'
	,s.NAME AS 'schema'
	,c.NAME
FROM sys.columns c
INNER JOIN sys.all_objects p ON c.object_id = p.object_id
INNER JOIN sys.schemas s ON p.schema_id = s.schema_id
WHERE lower(c.NAME) LIKE lower('%tran%')

USE [aspnetdb];

SELECT default_schema_name
	,NAME
	,type
FROM sys.database_principals
WHERE lower(NAME) LIKE lower('%tran%')

USE [aspnetdb];

SELECT p.NAME AS 'parent'
	,p.type AS 'parentType'
	,s.NAME AS 'schema'
	,i.NAME
	,i.type
	,i.is_disabled
FROM sys.indexes i
INNER JOIN sys.all_objects p ON i.object_id = p.object_id
INNER JOIN sys.schemas s ON p.schema_id = s.schema_id
WHERE lower(i.NAME) LIKE lower('%tran%')

USE [aspnetdb];

SELECT NAME
	,type
	,is_disabled
FROM sys.triggers
WHERE parent_class = 0
	AND lower(NAME) LIKE lower('%tran%')

