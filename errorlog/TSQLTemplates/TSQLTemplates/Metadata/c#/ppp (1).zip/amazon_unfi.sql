
IF  EXISTS 
		(
			SELECT 1 
			FROM   information_schema.Tables 
			WHERE  Table_schema = 'dbo' 
				   AND Table_name = 'Product_Attribute'  
		)
		BEGIN
			DROP Table dbo.Product_Attribute
			PRINT 'Table dbo.Product_Attribute has been dropped.'
		END

CREATE TABLE dbo.Product_Attribute
(Product_Attribute_id INT identity(1,1) NOT NULL
,Product_Attribute_Cd CHAR(1) NOT NULL
,Product_Attribute_Desc VARCHAR(255) NOT NULL)
TRUNCATE TABLE dbo.Product_Attribute 
INSERT INTO dbo.Product_Attribute 

SELECT 

'a' ,'Artificial ingredients' UNION ALL SELECT 
'c' ,'Low carb' UNION ALL SELECT   
'd' ,'Dairy free' UNION ALL SELECT
'f' ,'Food service items' UNION ALL SELECT   
'g' ,'Gluten Free' UNION ALL SELECT         
'k' ,'Kosher' UNION ALL SELECT          
'l' ,'Low Sodium/No Salt' UNION ALL SELECT       
'm' ,'Non-GMO Project Verified' UNION ALL SELECT  
'o','Organic' UNION ALL SELECT   
'r','Refined Sugar' UNION ALL SELECT   
'v','Vegan' UNION ALL SELECT   
'w','Wheat Free' UNION ALL SELECT   
'y','Yeast Free' UNION ALL SELECT   
't','Fair Trade' UNION ALL SELECT   
'n','Natural Specialty' UNION ALL SELECT    
's','Specialty Only'

IF  EXISTS 
		(
			SELECT 1 
			FROM   information_schema.Tables 
			WHERE  Table_schema = 'dbo' 
				   AND Table_name = 'Sellable_Region'  
		)
		BEGIN
			DROP Table dbo.Sellable_Region
			PRINT 'Table dbo.Sellable_Region has been dropped.'
		END

CREATE TABLE dbo.Sellable_Region
(Sellable_Region_Id INT IDENTITY(1,1) NOT NULL,
Sellable_Region_Cd CHAR(1) NOT NULL,
Sellable_Region VARCHAR(255) NOT null
 )

 ALTER TABLE dbo.Sellable_Region
 ADD CONSTRAINT PK_Sellable_Region_Cd PRIMARY KEY (Sellable_Region_Cd)
 TRUNCATE TABLE dbo.Sellable_Region
 INSERT INTO dbo.Sellable_Region
 SELECT 'C','Chesterfield' UNION ALL
 SELECT 'Y','York' UNION ALL
 SELECT 'D','Dayville'   	 UNION ALL
 SELECT 'A','Atlanta'		 UNION ALL
 SELECT 'L','Leicester'		 UNION ALL
 SELECT 'I','Iowa'			 UNION ALL
 SELECT 'G','Greenwood'		 UNION ALL
 SELECT 'S','Sarasota'		 UNION ALL
 SELECT 'R','Racine'		 UNION ALL
 SELECT 'H','Hudson Valley'	 UNION ALL
 SELECT 'T','Twin Cities'    
 IF  EXISTS 
		(
			SELECT 1 
			FROM   information_schema.Tables 
			WHERE  Table_schema = 'dbo' 
				   AND Table_name = 'Organic_Status'  
		)
		BEGIN
			DROP Table dbo.Organic_Status
			PRINT 'Table dbo.Organic_Status has been dropped.'
		END
 CREATE TABLE dbo.Organic_Status
(Organic_Status_Cd CHAR(2) NOT NULL,
Organic_Status_Unfi_Cd CHAR(2) NOT NULL,
Organic_Status_Val VARCHAR(255) NOT NULL

 )
 INSERT INTO  dbo.Organic_Status
 SELECT 'O1',1,'100% organic'  UNION ALL     
 SELECT 'O2',2,'95+% organic'  UNION ALL      
 SELECT 'O3',3,'70%+ organic'
 IF  EXISTS 
		(
			SELECT 1 
			FROM   information_schema.Tables 
			WHERE  Table_schema = 'dbo' 
				   AND Table_name = 'Unit_Type'  
		)
		BEGIN
			DROP Table dbo.Unit_Type
			PRINT 'Table dbo.Unit_Type has been dropped.'
		END
 CREATE TABLE dbo.Unit_Type (
 Unit_Type_Cd CHAR(2) NOT NULL,
 Unit_Type_Desc VARCHAR(255) NOT NULL)
 INSERT INTO  dbo.Unit_Type
 SELECT 'CS', 'Case' UNION ALL 
 SELECT 'EA', 'Each' UNION ALL 
 SELECT 'LB', 'Pound'

  IF  EXISTS 
		(
			SELECT 1 
			FROM   information_schema.Tables 
			WHERE  Table_schema = 'dbo' 
				   AND Table_name = 'Unit_Type'  
		)
		BEGIN
			DROP Table dbo.Unit_Type
			PRINT 'Table dbo.Unit_Type has been dropped.'
		END
 CREATE TABLE dbo.Brand_Exclude_List (
 Brand_Exclude VARCHAR(255) NOT NULL 
 )
  IF  EXISTS 
		(
			SELECT 1 
			FROM   information_schema.Tables 
			WHERE  Table_schema = 'dbo' 
				   AND Table_name = 'Brand_Carriedby'  
		)
		BEGIN
			DROP Table dbo.Brand_Carriedby
			PRINT 'Table dbo.Brand_Carriedby has been dropped.'
		END

CREATE TABLE dbo.Brand_Carriedby
(Brand_Nm VARCHAR(250)
)

 ---below are for data manipulations

  DELETE FROM [gfree].[dbo].['Product Price List$']
  WHERE unfi = 'REFRIGERATED'
 OR  unfi = 'FROZEN'
 OR  unfi = 'GROCERY'
 OR  unfi = 'BULK'
 OR  unfi = 'REFRIGERATED'
 OR  unfi = 'SUPPLEMENTS'
 OR  unfi = 'PERSONAL CARE'

  ALTER TABLE [gfree].[dbo].['Product Price List$']
  ADD UPC_Cd CHAR(20)
  ALTER TABLE [gfree].[dbo].['Product Price List$']
  ADD Unit_Discount_Pct_10 FLOAT 
  ALTER TABLE [gfree].[dbo].['Product Price List$']
  ADD Unit_Discount_Pct_15 FLOAT 
  ALTER TABLE [gfree].[dbo].['Product Price List$']
  ADD Unit_Discount_Pct_20 FLOAT 
  ALTER TABLE [gfree].[dbo].['Product Price List$']
  ADD Unit_Discount_Pct_25 FLOAT 
  ALTER TABLE [gfree].[dbo].['Product Price List$']
  ADD Unit_Discount_Pct_30 FLOAT 
  ALTER TABLE [gfree].[dbo].['Product Price List$']
  ADD Unit_Discount_Pct_35 FLOAT 
  ALTER TABLE [gfree].[dbo].['Product Price List$']
  ADD Unit_Discount_Pct_40 FLOAT 
  ALTER TABLE [gfree].[dbo].['Product Price List$']
  ADD Unit_Discount_Pct_45 FLOAT 


  ALTER TABLE [dbo].['Product Price List$']
  ALTER COLUMN upc NVARCHAR(2000) NOT NULL
  ALTER TABLE [dbo].['Product Price List$']
  ALTER COLUMN unfi NVARCHAR(2000) NOT NULL
  ALTER TABLE [dbo].['Product Price List$']
  ADD CONSTRAINT pk_tbl_unfi PRIMARY KEY   ( unfi)



 UPDATE [gfree].[dbo].['Product Price List$']
 SET UPC_Cd = replace (upc, '-','')



 UPDATE [gfree].[dbo].['Product Price List$']
 SET   [Unit_Discount_Pct_15]    = [UNIT_PRICE] -[UNIT_PRICE]*0.15
	  ,[Unit_Discount_Pct_20]    = [UNIT_PRICE] -[UNIT_PRICE]*0.2
	  ,[Unit_Discount_Pct_25]    = [UNIT_PRICE] -[UNIT_PRICE]*0.25
      ,[Unit_Discount_Pct_35]  = [UNIT_PRICE] -[UNIT_PRICE]*0.35
      ,[Unit_Discount_Pct_40]  = [UNIT_PRICE] -[UNIT_PRICE]*0.4
      ,[Unit_Discount_Pct_45]  = [UNIT_PRICE] -[UNIT_PRICE]*0.45


	   DELETE FROM  [gfree].[dbo].[All$]

  WHERE [PROD #] IS  NULL
  

  DELETE FROM [gfree].[dbo].[All$]

  WHERE [PROD #] IN  (
  'SUPPLEMENTS'
,'BULK'
,'FROZEN'
,'REFRIGERATED'
,'PERSONAL CARE'
,'GROCERY'
  )