use rkprs;
go

set statistics io on
 declare @FromDate VARCHAR(10) = '1/13/2015'
	,@ToDate VARCHAR(10) = '1/13/2015'
	,@plnCode VARCHAR(15) = null
	,@ssn VARCHAR(15) = NULL
	,@WriteOutputToTemporaryTables CHAR(1) = 'N'
	,@stmtPeriodId TINYINT = 1
DECLARE @FDate AS DATETIME
DECLARE @TDate AS DATETIME
DECLARE @balDate DATETIME
DECLARE @balDateEnd DATETIME
DECLARE @EarliestDate DATETIME
declare @diff int 
DECLARE @rc INT
SET @rc = 0

set @diff = (select datediff(dd, @fromdate, @todate))
IF @FromDate IS NULL
	SELECT @FromDate = @ToDate

SELECT @FDate = @FromDate

-- baldate is used for month-ends because SRT monthly history records
--  are dated as of the start of the new month. 
DECLARE @Daybit AS TINYINT

SELECT @Daybit = day(@FDate)

SELECT @balDate = dateadd(dd, (@Daybit - 1) * (- 1), @FDate)

SELECT @TDate = @ToDate

SELECT @balDateEnd = dateadd(dd, + 1, @TDate)

IF day(@baldateEnd) > 1
	SELECT @balDateEnd = @TDate

DECLARE @pln VARCHAR(15)

SELECT @pln = @plnCode

IF @plnCode IS NULL
	AND @ssn IS NOT NULL
BEGIN
	SELECT @pln = pla.pla_code_cid
	FROM RKDB.dbo.Part par WITH (NOLOCK)
		,RKDB.dbo.Pla pla WITH (NOLOCK)
	WHERE par.par_SSN = @SSN
		AND par.pla_idi = pla.pla_idi
END

DECLARE @pla_idi INT
DECLARE @par_idb BIGINT

SELECT @pla_idi = NULL
	,@par_idb = NULL

IF @ssn IS NOT NULL
BEGIN
	SELECT @par_idb = par.par_idb
	FROM rkdb.dbo.part par WITH (NOLOCK)
	INNER JOIN rkdb.dbo.pla pla WITH (NOLOCK) ON par.pla_idi = pla.pla_idi
	WHERE @SSN = par.par_ssn
		AND @pln = pla.pla_code_cid
END

IF @pln IS NOT NULL
BEGIN
	SELECT @pla_idi = pla_idi
	FROM rkdb.dbo.pla pla WITH (NOLOCK)
	WHERE pla.pla_code_cid = @pln
END
IF OBJECT_ID('tempdb..#vwpln') IS NOT NULL DROP TABLE #vwpln
IF OBJECT_ID('tempdb..#PartnerPln') IS NOT NULL DROP TABLE #PartnerPln
IF OBJECT_ID('tempdb..#TEMPH') IS NOT NULL DROP TABLE #TEMPH
IF OBJECT_ID('tempdb..#textswap') IS NOT NULL DROP TABLE #textswap
select * into #textswap FROM qadcssql.bis.dbo.textswap
select * into #vwpln FROM qadcssql.bis.dbo.vwpln p
select * into #PartnerPln FROM  qadcssql.bis.dbo.PartnerPln

create index temp_vwpln_plnCode on #vwpln (plnCode)
create index temp_vwpln_plnid on #vwpln (plnid)
create index temp_plnId_PartnerPln on #PartnerPln (plnId)
create index temp_textswap_textswapdisplay on #textswap (textswapdisplay,textSwapGrpId)
-- 20110527 added a tracking log to at least identify when the job was run
DECLARE @runDtm DATETIME

SELECT @runDtm = CURRENT_TIMESTAMP
select datediff(dd, @fromdate, @todate)
INSERT INTO dbo.stmtExtractLog (
	runDt
	,FromDate
	,ToDate
	,plnCode
	,ssn
	,WriteOutputToTemporaryTables
	,stmtPeriodId
	)
SELECT @runDtm
	,@FromDate
	,@ToDate
	,@plnCode
	,@ssn
	,@WriteOutputToTemporaryTables
	,@stmtPeriodId

-- 20110527 end 
-- Create a temp table of the header, i.e. participant (StmtDemog), entries that will be
--  generated in this run
SELECT cast(NULL AS INT) AS demogId
	,par.pla_idi
	,pla.pla_code_cid AS plnCode
	,par.par_idb
	,par.par_SSN AS ssNbr
	,@TDate AS toDate
	,@FDate AS fromDate
	,convert(VARCHAR(50), (
			CASE 
				WHEN par.par_first_na = ' '
					THEN par.par_last_na
				ELSE rtrim(par.par_first_na) + ' ' + par.par_last_na
				END
			)) AS partName
	,cast(rtrim(pla.pla_1_na) + ' ' + coalesce(pla.pla_2_na, ' ') AS VARCHAR(80)) AS plnName
	,right('     ' + cast(convert(INT, par.par_divn_ss) AS VARCHAR(10)), 5) + '     ' AS divNbr
	,cast('X1110' AS CHAR(10)) AS shellNbr
	,cast(' ' AS VARCHAR(80)) AS addrLine1
	,cast(NULL AS VARCHAR(80)) AS addrLine2
	,cast(NULL AS VARCHAR(80)) AS addrLine3
	,cast(NULL AS DATETIME) AS dob
	,cast(NULL AS DATETIME) AS doh
	,cast(NULL AS DATETIME) AS dop
	,cast(NULL AS DATETIME) AS dot
	,cast(NULL AS DATETIME) AS doavest
	,cast(NULL AS DATETIME) AS doelig
	,cast(par.par_primary_cd AS VARCHAR(10)) AS statusCode
	,cast(NULL AS VARCHAR(10)) AS statusDesc
	,cast(0 AS REAL) AS alloc1
	,cast(0 AS REAL) AS alloc2
	,cast(0 AS REAL) AS alloc3
	,cast(0 AS REAL) AS alloc4
	,cast(0 AS REAL) AS alloc5
	,cast(0.00 AS MONEY) AS loanBal
	,cast(CASE 
			WHEN par_post88_cntrb_ret_amt > par_froz86_cntrb_amt
				THEN 0
			WHEN par_froz86_cntrb_amt = 0
				AND par_rollover_froz86_amt = 0
				THEN 0
			ELSE (par_froz86_cntrb_amt + par_rollover_froz86_amt - par_post88_cntrb_ret_amt)
			END AS MONEY) AS pre87Amt
	,cast(0.00 AS MONEY) AS eeComp
	,cast(0 AS REAL) AS dfPctEEPre
	,cast(0 AS REAL) AS dfPctEEAft
	,cast(0 AS REAL) AS dfPctERMatch
	,cast(0 AS REAL) AS dfPctPS
	,cast(par.par_last_na AS VARCHAR(40)) AS partLastName
INTO #tempH
FROM RKDB.dbo.Part par WITH (NOLOCK)
INNER JOIN RKDB.dbo.Pla pla WITH (NOLOCK) ON par.pla_idi = pla.pla_idi
INNER JOIN rkdb.dbo.CD_code_lk cde WITH (NOLOCK) ON par.par_primary_cd = cde.cod_cd
INNER JOIN RKDB.dbo.pla_plangroup ppg WITH (NOLOCK) ON par.pla_idi = ppg.pla_idi
INNER JOIN RKDB.dbo.plangroup pg WITH (NOLOCK) ON ppg.plag_idi = pg.plag_idi
WHERE (
		@SSN IS NULL
		OR @par_idb = par.par_idb
		)
	AND (
		@pln IS NULL
		OR @pla_idi = par.pla_idi
		)
	-- this plan group means terminated plans
	AND NOT pg.plag_dir_lna = 'TTT'
	-- only these meps (psi, thrift, nb psi, fidelity, reliance), unless
	--  - a specific plan has been requested 
	--  - its a test plan (Y99,L98,Y97)
	--  - its a non-qualified plan and this is a quarterly or annual run
	AND (
		(
			EXISTS (
				SELECT 1
				FROM rkdb.dbo.pla_logplangroup plpg WITH (NOLOCK)
				INNER JOIN rkdb.dbo.logplangroup lpg WITH (NOLOCK) ON plpg.logpg_idi = lpg.logpg_idi
				WHERE par.pla_idi = plpg.pla_idi
					AND lpg.logpg_legacy_scid IN (
						'002'
						,'003'
						,'005'
						,'006'
						,'007'
						,'008'
						,'009'
						,'010'
						,'011'
						,'012'
						,'019'
						,'013'
						,'020'
						)
				) -- 20141218 added 20 -- 20141117 added MEP 013  -- 20121212 added MEP 011 
			OR @plnCode IS NOT NULL
			)
			
		-- test data in production
		OR (
			pla.pla_code_cid IN (
				'Y99'
				,'L98'
				,'Y97'
				,'Y93'
				,'Y96'
				,'Y70'
				,'Y95'
				,'510'
				)
			) 
			-- 20091102 added 510 - not in a mep 
		-- Non-Qualified plans are included if quarterly or annual and all plans are requested
		OR (
			@plnCode IS NULL
			AND @diff> 33
			AND EXISTS (
				SELECT 1
				FROM #vwpln p
				WHERE p.plnCode = pla.pla_code_cid
					AND p.plnTypeDesc = 'Non-Qualified'
				)
			)

		-- First Bank balance forward plans, but not for dailies (picks up balance forward
		--  plans that are not in MEPs)
		OR (
			@plnCode IS NULL
			AND @diff > 25
			AND EXISTS (
				SELECT 1
				FROM #vwpln p
				INNER JOIN #PartnerPln pp ON p.plnId = pp.plnId
				WHERE p.plnCode = pla.pla_code_cid
					AND pp.partnerId = 77
				)
			)
		)
-- exclude participants who were paid out a month or more prior to the from date
--   and not (par.par_primary_cd = 765 and exists (select * from rkdb.dbo.parthist ph
--                                              where ph.par_idb = par.par_idb
--                                                and ph.parh_effect_dt = @balDate
--                                                and ph.parh_primary_cd = 765))  
ORDER BY par.pla_idi
	,par.par_idb
OPTION (MAXDOP 1)
CREATE UNIQUE INDEX IX1_tempH ON #tempH (par_idb)

CREATE INDEX IX2_tempH ON #tempH (
	plnCode
	,ssNbr
	)

CREATE INDEX IX3_tempH ON #tempH (
	pla_idi
	,par_idb
	)

CREATE NONCLUSTERED INDEX TEMP_tempH_plnCode
ON #tempH ([plnCode])
INCLUDE ([par_idb],[shellNbr])
CREATE NONCLUSTERED INDEX TEMP_tempH_dop_dob
ON #tempH (doh,dop,dob)
INCLUDE ([par_idb],[shellNbr])
-- historical participant status, if this is a backdated run
-- - only monthly status history available.
-- - this code will not work (perfectly) for a daily in a prior month
-- update #tempH
--   set statusCode = ph.parh_primary_cd
--  from #tempH h, rkdb.dbo.parthist ph, rkdb.dbo.CD_code_lk cde
-- where h.par_idb = ph.par_idb
--   and ph.parh_effect_dt = (select max(ph2.parh_effect_dt)
--                              from rkdb.dbo.parthist ph2
--                             where ph.par_idb = ph2.par_idb
--                               and ph2.parh_effect_dt <= @balDateEnd
--                               and ph2.parh_effect_dt >= @baldate)
--   and ph.parh_primary_cd = cde.cod_cd
--   and not @FDate = @TDate
-- add participant date information
UPDATE #tempH
SET dob = pd.pard_birth_dt
	,doh = pd.pard_service_dt
	,dop = pd.pard_part_dt
	,dot = pd.pard_term_dt
	,doavest = pd.pard_alt_vest_dt
	,doelig = pd.pard_elig_dt
FROM #tempH h
INNER JOIN RKDB.dbo.PartDate pd WITH (NOLOCK) ON h.par_idb = pd.par_idb
WHERE pd.pard_effect_dt = (
		SELECT max(pd2.pard_effect_dt)
		FROM RKDB.dbo.PartDate pd2 WITH (NOLOCK)
		WHERE pd.par_idb = pd2.par_idb
			AND pd2.pard_effect_dt <= @balDateEnd
		)

-- 20100310 - override plan 547 to always use the most recent partdate record 
UPDATE #tempH
SET dob = pd.pard_birth_dt
	,doh = pd.pard_service_dt
	,dop = pd.pard_part_dt
	,dot = pd.pard_term_dt
	,doavest = pd.pard_alt_vest_dt
	,doelig = pd.pard_elig_dt
FROM #tempH h
INNER JOIN RKDB.dbo.PartDate pd WITH (NOLOCK) ON h.par_idb = pd.par_idb
INNER JOIN RKDB.dbo.PARTMAX pm WITH (NOLOCK) ON pm.par_idb = pd.par_idb
	AND pm.pard_effect_dt = pd.pard_effect_dt
WHERE h.plnCode IN (
		'552'
		,'547'
		) -- 20100506 added 552

-- 20100310
-- 20090827 set invalid dates to null 
UPDATE [#tempH]
SET dob = NULL
WHERE dob > '06/06/2079'

UPDATE [#tempH]
SET doh = NULL
WHERE doh > '06/06/2079'

UPDATE [#tempH]
SET dop = NULL
WHERE dop > '06/06/2079'

UPDATE [#tempH]
SET dot = NULL
WHERE dot > '06/06/2079'

UPDATE [#tempH]
SET doavest = NULL
WHERE doavest > '06/06/2079'

UPDATE [#tempH]
SET doelig = NULL
WHERE doelig > '06/06/2079'

-- 20090827 end 
-- Eligibility date, if present, overrides participation date, but only for Thrift
UPDATE #tempH
SET dop = doelig
WHERE doelig IS NOT NULL
	AND plnCode >= 'M00'

-- add in address data, always using the latest info
UPDATE #tempH
SET addrLine1 = a.add_line1_na
	,addrLine2 = CASE 
		WHEN a.add_line2_na = ' '
			OR a.add_line2_na IS NULL
			THEN (
					CASE 
						WHEN a.state_st = '  '
							THEN convert(CHAR(20), a.add_ci) + '         '
						ELSE convert(CHAR(20), a.add_ci) + '     , ' + state_st
						END
					) + ' ' + add_zp
		ELSE a.add_line2_na
		END
	,addrline3 = CASE 
		WHEN a.add_line2_na = ' '
			OR a.add_line2_na IS NULL
			THEN ' '
		ELSE (
				CASE 
					WHEN a.state_st = '  '
						THEN convert(CHAR(15), a.add_ci) + '    '
					ELSE convert(CHAR(15), a.add_ci) + ', ' + state_st
					END
				) + ' ' + add_zp
		END
FROM #tempH t
INNER JOIN RKDB.dbo.Address a WITH (NOLOCK) ON t.par_idb = a.par_idb
WHERE a.add_effect_dt = (
		SELECT max(a2.add_effect_dt)
		FROM RKDB.dbo.Address a2 WITH (NOLOCK)
		WHERE a.par_idb = a2.par_idb
		)

--                             and a2.add_effect_dt <= @balDateEnd)     
UPDATE #tempH
SET addrLine2 = CASE 
		WHEN addrLine2 IS NULL
			THEN ' '
		ELSE addrLine2
		END
	,addrLine3 = CASE 
		WHEN addrline3 IS NULL
			THEN ' '
		ELSE addrLine3
		END
WHERE addrLine2 IS NULL
	OR addrLine3 IS NULL

-- add in status code descriptions
UPDATE #tempH
SET statusDesc = ts.textswapvalue
FROM #tempH t
INNER JOIN rkdb.dbo.CD_code_lk cde WITH (NOLOCK) ON t.statusCode = cde.cod_cd
INNER JOIN #textswap ts ON (
		cde.cod_de = upper(ts.textswapdisplay)
		AND ts.textSwapGrpId = 1
		)
		--vbandi
UPDATE #tempH
SET statusDesc = left(cde.cod_de, 3)
FROM #tempH t
	,rkdb.dbo.CD_code_lk cde
WHERE t.statusCode = cde.cod_cd

-- set the compensation for the current year (hidden for N01)
UPDATE #tempH
SET eeComp = coalesce(sal_5_amt, 0.00)
FROM #tempH t
INNER JOIN RKDB.dbo.Salary s WITH (NOLOCK) ON t.par_idb = s.par_idb
WHERE s.sal_effect_dt = (
		SELECT max(s2.sal_effect_dt)
		FROM RKDB.dbo.Salary s2 WITH (NOLOCK)
		WHERE s2.par_idb = s.par_idb
			AND s2.sal_effect_dt <= @TDate
			--                             and (s2.sal_5_amt is not null 
			--                                and s2.sal_5_amt > 0.00)
			AND year(s2.sal_effect_dt) = year(@TDate)
		)
	--   and (s.sal_5_amt is not null and s.sal_5_amt > 0.00)
	AND year(s.sal_effect_dt) = year(@TDate)
	AND NOT t.plnCode = 'N01'
	
-- Create a temp table of current deferral rates
SELECT h.pla_idi
	,h.par_idb
	,max(CASE 
			WHEN so.sou_tax_cd BETWEEN 150
					AND 158
				THEN ac.acc_defrl_rt --was 150 and 160
			ELSE 0
			END) AS dfPCTEEPre
	,max(CASE 
			WHEN so.sou_tax_cd BETWEEN 161
					AND 170
				THEN ac.acc_defrl_rt -- 20101220 back to 161 and 170 --was 161 and 170
			ELSE 0
			END) AS dfPCTEEAft
	,
	--max(case when so.sou_tax_cd between 171 and 180 then ac.acc_defrl_rt else 0 end) as dfPCTERMatch,
	0 AS dfPctERMatch
	,max(CASE 
			WHEN so.sou_tax_cd = 177
				THEN ac.acc_defrl_rt --was 172
			ELSE 0
			END) AS dfPCTPS
INTO #tempHdf
FROM #tempH h
INNER JOIN RKDB.dbo.Account ac WITH (NOLOCK) ON h.par_idb = ac.par_idb
INNER JOIN RKDB.dbo.Source so WITH (NOLOCK) ON ac.sou_idi = so.sou_idi
WHERE h.statusDesc IN (
		'ACT'
		,'LOA'
		,'NOT'
		,'SUS'
		,'INA'
		,'ELI'
		)
	AND h.dot IS NULL
	AND (
		(
			so.sou_tax_cd BETWEEN 150
				AND 170
			OR so.sou_tax_cd = 177 --was 172
			)
		AND NOT (
			so.sou_tax_cd IN (
				151
				,160
				) --was 151, 170
			OR so.sou_rollover_in = 1
			)
		)
	AND ac.acc_defrl_rt IS NOT NULL
	AND ac.acc_defrl_rt > 0.00
	AND NOT h.plnCode = 'N01'
GROUP BY h.pla_idi
	,h.par_idb

-- update deferral rates with historical values, if applicable.
-- . skip this routine for Non-Qualified plans
UPDATE #tempHdf
SET dfPCTEEPre = CASE 
		WHEN so.sou_tax_cd BETWEEN 150
				AND 158 --was 150 and 160
			THEN ah.acch_defrl_rt
		ELSE dfPctEEPre
		END
	,dfPCTEEAft = CASE 
		WHEN so.sou_tax_cd BETWEEN 161
				AND 170 -- 20101220 back to 161 and 170 -- was 161 and 170
			THEN ah.acch_defrl_rt
		ELSE dfPctEEAft
		END
	,
	--       dfPCTERMatch = case when so.sou_tax_cd between 171 and 180 then ah.acch_defrl_rt else dfPctERMatch end,
	dfPCTPS = CASE 
		WHEN so.sou_tax_cd = 177
			THEN ah.acch_defrl_rt --was 172
		ELSE dfPctPS
		END
FROM #tempHdf h
INNER JOIN RKDB.dbo.accthist ah WITH (NOLOCK) ON h.par_idb = ah.par_idb
INNER JOIN RKDB.dbo.Source so WITH (NOLOCK) ON ah.sou_idi = so.sou_idi
INNER JOIN RKDB.dbo.Pla pla WITH (NOLOCK) ON h.pla_idi = pla.pla_idi
WHERE NOT @FDate = @TDate
	AND (
		(
			so.sou_tax_cd BETWEEN 150
				AND 170
			OR so.sou_tax_cd = 177 --was 172
			)
		AND NOT (
			so.sou_tax_cd IN (
				151
				,160
				) --was 151,170
			OR so.sou_rollover_in = 1
			)
		)
	AND ah.acch_defrl_rt IS NOT NULL
	AND ah.acch_defrl_rt > 0.00
	AND ah.acch_effect_dt = @balDateEnd
	AND NOT EXISTS (
		SELECT 1
		FROM #vwpln p
		WHERE p.plnCode = pla.pla_code_cid
			AND p.plnTypeDesc = 'Non-Qualified'
		)

-- fill in the header (participant) table with the discovered deferral rates
UPDATE #tempH
SET dfPCTEEPre = hdf.dfPCTEEPre
	,dfPctEEAft = hdf.dfPctEEAft
	,dfPctERMatch = hdf.dfPctERMatch
	,dfPctPS = hdf.dfPctPS
FROM #tempH h
INNER JOIN #tempHdf hdf ON h.par_idb = hdf.par_idb

DROP TABLE #tempHdf

-- special override for ER deferral rates
UPDATE #tempH
--    set dfPctERMatch = convert(integer,fp.finp_amt * 10) / 10
SET dfPctERMatch = round(fp.finp_amt, 0)
FROM #tempH t
INNER JOIN rkdb.dbo.financialpad fp WITH (NOLOCK) ON t.par_idb = fp.par_idb
WHERE t.statusDesc IN (
		'ACT'
		,'LOA'
		,'NOT'
		,'SUS'
		,'INA'
		,'ELI'
		)
	AND t.dot IS NULL
	AND fp.finp_seq = 34
	AND fp.finp_amt IS NOT NULL
	AND NOT fp.finp_amt = 0.0
	AND NOT t.plnCode = 'N01'

-- Shell Number
-- Whom mailed to (2nd digit)
-- - Default is 1 (X1XXX), meaning to the client
-- - 3 is the client but 'unsealed' (no longer used)
-- - 2 is to the participant, for certain plans and various status codes
-- 20060711 added mail home to A33, D05, DB1, G11, I17, I19, K19, K20, M24, M50, N30, N45, PA4, Q54, R57
UPDATE #tempH
SET ShellNbr = 'X2110'
FROM #tempH h
WHERE h.plnCode IN (
		'A02'
		,'A05'
		,'A10'
		,'A15'
		,'A16'
		,'A21'
		,'A22'
		,'A28'
		,'A29'
		,'A30'
		,'A31'
		,'A32'
		,'A33'
		,'B06'
		,'B14'
		,'B19'
		,'B23'
		,'B27'
		,'B30'
		,'B33'
		,'B35'
		,'B36'
		,'B38'
		,'C01'
		,'C06'
		,'C07'
		,'C10'
		,'C11'
		,'C15'
		,'C16'
		,'C17'
		,'C21'
		,'C24'
		,'DA1'
		,'DA2'
		,'DA5'
		,'DA7'
		,'DA9'
		,'DB1'
		,'D05'
		,'D12'
		,'D17'
		,'D18'
		,'D25'
		,'D30'
		,'D32'
		,'D37'
		,'D50'
		,'D51'
		,'D52'
		,'D61'
		,'D62'
		,'D63'
		,'D64'
		,'D65'
		,'D83'
		,'D89'
		,'D91'
		,'D93'
		,'D95'
		,'D96'
		,'D97'
		,'D99'
		,'E25'
		,'E26'
		,'E27'
		,'E28'
		,'E29'
		,'E30'
		,'E51'
		,'E52'
		,'E53'
		,'E55'
		,'F05'
		,'F10'
		,'F15'
		,'F20'
		,'F26'
		,'F31'
		,'F37'
		,'F38'
		,'F39'
		,'F40'
		,'F41'
		,'F50'
		,'F51'
		,'F53'
		,'G06'
		,'G08'
		,'G09'
		,'G11'
		,'H04'
		,'I02'
		,'I11'
		,'I13'
		,'I14'
		,'I17'
		,'I18'
		,'I19'
		,'J13'
		,'J14'
		,'J15'
		,'J16'
		,'J17'
		,'K03'
		,'K04'
		,'K08'
		,'K09'
		,'K10'
		,'K11'
		,'K12'
		,'K13'
		,'K16'
		,'K17'
		,'K19'
		,'K20'
		,'L04'
		,'L11'
		,'L12'
		,'L13'
		,'L14'
		,'L15'
		,'L16'
		,'L17'
		,'L18'
		,'L19'
		,'L20'
		,'L21'
		,'L22'
		,'L23'
		,'L24'
		,'L25'
		,'L26'
		,'L27'
		,'L28'
		,'L29'
		,'L30'
		,'L31'
		,'M00'
		,'M01'
		,'M06'
		,'M22'
		,'M24'
		,'M25'
		,'M37'
		,'M38'
		,'M43'
		,'M49'
		,'M50'
		,'N00'
		,'N04'
		,'N10'
		,'N13'
		,'N16'
		,'N17'
		,'N22'
		,'N23'
		,'N25'
		,'N28'
		,'N30'
		,'N32'
		,'N42'
		,'N43'
		,'N44'
		,'N45'
		,'O00'
		,'O16'
		,'O22'
		,'O26'
		,'O28'
		,'O43'
		,'O48'
		,'O49'
		,'O50'
		,'O52'
		,'O53'
		,'PA4'
		,'PA9'
		,'PB1'
		,'PB2'
		,'P00'
		,'P03'
		,'P08'
		,'P13'
		,'P17'
		,'P18'
		,'P20'
		,'P23'
		,'P25'
		,'P36'
		,'P45'
		,'P46'
		,'P47'
		,'P50'
		,'P51'
		,'P53'
		,'P55'
		,'P56'
		,'P62'
		,'P65'
		,'P72'
		,'P77'
		,'P83'
		,'P85'
		,'P86'
		,'P88'
		,'P94'
		,'PB4'
		,'PB6'
		,'Q04'
		,'Q08'
		,'Q16'
		,'Q17'
		,'Q33'
		,'Q46'
		,'Q52'
		,'Q53'
		,'Q54'
		,'R00'
		,'R06'
		,'R07'
		,'R10'
		,'R13'
		,'R14'
		,'R15'
		,'R18'
		,'R19'
		,'R23'
		,'R27'
		,'R37'
		,'R39'
		,'R57'
		,'R59'
		,'R60'
		,'S00'
		,'S02'
		,'S09'
		,'S12'
		,'S15'
		,'S16'
		,'S25'
		,'S27'
		,'S32'
		,'S33'
		,'S35'
		,'T09'
		,'T26'
		,'U07'
		,'U16'
		,'U19'
		,'U32'
		,'U35'
		,'U36'
		,'V00'
		,'V03'
		,'V08'
		,'V22'
		,'W00'
		,'W01'
		,'X00'
		,'X02'
		,'X03'
		,'X07'
		,'X09'
		,'Z03'
		)
	OR (
		h.statusDesc IN (
			'TER'
			,'LOA'
			,'SAM'
			,'RET'
			,'DEC'
			,'QDR'
			,'PAY'
			)
		)

-- Shell Number
-- SAR Insert (3rd digit)
-- - Default is 1 (XX1XX), meaning 'yes'
-- - 0 is 'no'
UPDATE #tempH
SET ShellNbr = left(ShellNbr, 2) + '010'
FROM #tempH h
WHERE h.plnCode = 'O43'
	OR h.plnCode < 'M00'

-- Shell Number
-- Form number (1st digit)
-- - values are 1-9,A,B,C
-- - Default is 2 for thrift, 3 for PSI
UPDATE #tempH
SET ShellNbr = '2' + right(left(ShellNbr, 5), 4)
FROM #tempH h
WHERE h.plnCode >= 'M00'

UPDATE #tempH
SET ShellNbr = '3' + right(left(ShellNbr, 5), 4)
FROM #tempH h
WHERE h.plnCode < 'M00'
--vbandi 
UPDATE #tempH
SET ShellNbr = CASE 
		WHEN h.plnCode IN (
				'D05'
				,'D11'
				,'D27'
				,'D49'
				,'E05'
				,'L07'
				)
			THEN '1'
		WHEN h.plnCode IN (
				'A18'
				,'B07'
				,'C15'
				,'D07'
				,'D33'
				,'F06'
				,'J01'
				)
			THEN '2'
		WHEN h.plnCode IN (
				'C01'
				,'C10'
				,'D06'
				)
			THEN '4'
		WHEN h.plnCode IN ('C05')
			THEN '5'
		WHEN h.plnCode IN (
				'C09'
				,'D02'
				)
			THEN '6'
		WHEN h.plnCode IN ('B14')
			THEN '7'
		WHEN h.plnCode IN ('I03')
			THEN '8'
		WHEN h.plnCode IN ('F11')
			THEN '9'
		WHEN h.plnCode IN (
				'A02'
				,'A05'
				,'A10'
				,'A16'
				,'H15'
				)
			THEN 'A'
		WHEN h.plnCode IN ('D42')
			THEN 'B'
		WHEN h.plnCode IN ('C07')
			THEN 'C'
		ELSE left(ShellNbr, 1)
		END + right(left(ShellNbr, 5), 4)
FROM #tempH h
WHERE h.plnCode IN (
		'D05'
		,'D11'
		,'D15'
		,'D27'
		,'D49'
		,'E05'
		,'L07'
		,'A18'
		,'B07'
		,'C15'
		,'D07'
		,'D33'
		,'F06'
		,'J01'
		,'C01'
		,'C10'
		,'D06'
		,'C05'
		,'C09'
		,'D02'
		,'B14'
		,'I03'
		,'F11'
		,'A02'
		,'A05'
		,'A10'
		,'A16'
		,'H15'
		,'D42'
		,'C07'
		)

--
-- Pull the opening balances, per person, source and investment, 
--  from the balance history.
--print 'test1'
--select * from #tempH
SELECT max(sb.stab_ymd) AS stab_ymd
	,h.pla_idi
INTO #balDates
FROM RKDB.dbo.StateBal sb WITH (NOLOCK)
INNER JOIN #tempH AS h ON (h.par_idb = sb.par_idb)
WHERE stab_ymd <= @balDate
GROUP BY h.pla_idi

SELECT @EarliestDate = @balDate

SELECT h.pla_idi
	,h.par_idb
	,sb.inv_idi
	,sb.ipm_nid -- 20110113
	,sb.sou_idi
	,sb.stab_ymd
	,cast(sum(convert(DECIMAL(15, 4), sb.stab_un)) AS DECIMAL(15, 4)) AS Units
INTO #temp1
FROM RKDB.dbo.StateBal sb WITH (NOLOCK)
INNER JOIN #tempH AS h ON (h.par_idb = sb.par_idb)
--inner join #balDates b on (h.pla_idi = b.pla_idi and sb.stab_ymd = b.stab_ymd)
WHERE sb.stab_ymd = @baldate
	AND sb.stab_un IS NOT NULL
	AND (
		@pln IS NULL
		OR @pla_idi = h.pla_idi
		)
	AND (
		@ssn IS NULL
		OR @par_idb = sb.par_idb
		)
	AND NOT sb.stab_un = 0.0000
GROUP BY h.pla_idi
	,h.par_idb
	,sb.inv_idi
	,sb.ipm_nid -- 20110113 
	,sb.sou_idi
	,sb.stab_ymd
HAVING NOT sum(sb.stab_un) = 0.0000
ORDER BY h.pla_idi
	,h.par_idb
	,sb.inv_idi
	,sb.ipm_nid -- 20110113
	,sb.sou_idi
	,sb.stab_ymd
OPTION (MAXDOP 1)

CREATE INDEX IX1_temp1 ON #temp1 (
	pla_idi
	,par_idb
	,inv_idi
	,ipm_nid
	,sou_idi
	) -- 20110113 added ipm_nid

DROP TABLE #balDates

-- Pull the transactions between the balance history date and the
--  the requested from date
-- override the optimizer because its bad on trans cos no db maintenenace
--  is permitted on that table.
CREATE TABLE #temp2 (
	pla_idi INT NOT NULL
	,par_idb BIGINT NOT NULL
	,inv_idi INT NOT NULL
	,ipm_nid INT NULL -- 20110113 
	,sou_idi INT NOT NULL
	,Units DECIMAL(15, 4) NULL
	)

-- three versions of the trans read, because the table is massive and
--  massively in need of defraging/index rebuild
IF @SSN IS NULL
	AND @pln IS NULL
BEGIN
	INSERT #temp2
	SELECT tr.pla_idi
		,tr.par_idb
		,tr.inv_idi
		,tr.ipm_nid -- 20110113 
		,tr.sou_idi
		,sum(cast(tr.tra_un AS DECIMAL(15, 4)) * (
				CASE 
					WHEN tr.tran_cd IN (
							5
							,6
							)
						THEN - 1
					ELSE + 1
					END
				)) AS Units
	FROM RKDB.dbo.trans AS tr WITH (NOLOCK)
	INNER JOIN RKDB.dbo.part par WITH (NOLOCK) ON tr.par_idb = par.par_idb
	INNER JOIN RKDB.dbo.pla pla WITH (NOLOCK) ON tr.pla_idi = pla.pla_idi
	WHERE tr.tran_cd IN (
			2
			,3
			,5
			,6
			)
		--  and (@SSN is null or @SSN = par.par_SSN)
		--  and (@pln is null or @pln = pla.pla_code_cid)
		AND EXISTS (
			SELECT min(t.pla_idi)
			FROM #tempH t
			WHERE t.pla_idi = tr.pla_idi
			)
		-- new transactions
		AND tr.tra_process_dt >= @baldate
		-- no later than
		AND tr.tra_process_dt < @FDate
		--  and not pla.pla_code_cid in ('L98','L99','Z98','Z99')
		AND NOT tr.tra_memo_in = 1
	GROUP BY tr.pla_idi
		,tr.par_idb
		,tr.inv_idi
		,tr.ipm_nid -- 20110113 
		,tr.sou_idi
	OPTION (MAXDOP 1)
END

IF @SSN IS NULL
	AND @pln IS NOT NULL
BEGIN
	INSERT #temp2
	SELECT tr.pla_idi
		,tr.par_idb
		,tr.inv_idi
		,tr.ipm_nid -- 20110113 
		,tr.sou_idi
		,sum(cast(tr.tra_un AS DECIMAL(15, 4)) * (
				CASE 
					WHEN tr.tran_cd IN (
							5
							,6
							)
						THEN - 1
					ELSE + 1
					END
				)) AS Units
	FROM RKDB.dbo.trans AS tr WITH (NOLOCK)
	INNER JOIN RKDB.dbo.part par WITH (NOLOCK) ON tr.par_idb = par.par_idb
	INNER JOIN RKDB.dbo.pla pla WITH (NOLOCK) ON tr.pla_idi = pla.pla_idi
	WHERE tr.tran_cd IN (
			2
			,3
			,5
			,6
			)
		AND @pln = pla.pla_code_cid
		-- new transactions
		AND tr.tra_process_dt >= @baldate
		-- no later than
		AND tr.tra_process_dt < @FDate
		--  and not pla.pla_code_cid in ('L98','L99','Z98','Z99')
		AND NOT tr.tra_memo_in = 1
	GROUP BY tr.pla_idi
		,tr.par_idb
		,tr.inv_idi
		,tr.ipm_nid -- 20110113 
		,tr.sou_idi
END

IF @SSN IS NOT NULL
BEGIN
	INSERT #temp2
	SELECT tr.pla_idi
		,tr.par_idb
		,tr.inv_idi
		,tr.ipm_nid -- 20110113 
		,tr.sou_idi
		,sum(cast(tr.tra_un AS DECIMAL(15, 4)) * (
				CASE 
					WHEN tr.tran_cd IN (
							5
							,6
							)
						THEN - 1
					ELSE + 1
					END
				)) AS Units
	FROM RKDB.dbo.trans AS tr WITH (NOLOCK)
	INNER JOIN RKDB.dbo.part par WITH (NOLOCK) ON tr.par_idb = par.par_idb
	WHERE tr.tran_cd IN (
			2
			,3
			,5
			,6
			)
		AND @par_idb = par.par_idb
		-- new transactions
		AND tr.tra_process_dt >= @baldate
		-- no later than
		AND tr.tra_process_dt < @FDate
		--  and not pla.pla_code_cid in ('L98','L99','Z98','Z99')
		AND NOT tr.tra_memo_in = 1
	GROUP BY tr.pla_idi
		,tr.par_idb
		,tr.inv_idi
		,tr.ipm_nid -- 20110113 
		,tr.sou_idi
END

CREATE INDEX IX1_temp2 ON #temp2 (
	pla_idi
	,par_idb
	,inv_idi
	,ipm_nid
	,sou_idi
	) -- 20110113 added ipm_nid

-- Sum up the units to get the opening balances for the requested from date
--print 'test1'
UPDATE #temp1
SET Units = t1.Units + t2.Units
FROM #temp1 t1
	,#temp2 t2
WHERE t1.pla_idi = t2.pla_idi
	AND t1.inv_idi = t2.inv_idi
	AND t1.ipm_nid = t2.ipm_nid -- 201113
	AND t1.par_idb = t2.par_idb
	AND t1.sou_idi = t2.sou_idi

--print 'test2'
-- Add in blank opening balance entries for plans/funds/sources/people that are 
--  new between the last balance date and the requested from date
INSERT #temp1
SELECT t2.pla_idi
	,t2.par_idb
	,inv_idi
	,ipm_nid -- 20110113 
	,sou_idi
	,@baldate
	,sum(Units)
FROM #temp2 t2
WHERE NOT EXISTS (
		SELECT 1
		FROM #temp1 t1
		WHERE t1.pla_idi = t2.pla_idi
			AND t1.inv_idi = t2.inv_idi
			AND t1.ipm_nid = t2.ipm_nid -- 20110113
			AND t1.par_idb = t2.par_idb
			AND t1.sou_idi = t2.sou_idi
		)
GROUP BY pla_idi
	,par_idb
	,inv_idi
	,ipm_nid -- 20110113 
	,sou_idi
HAVING NOT sum(Units) = 0.0000

-- Pull the transactions between the from date and the to date
-- source override removed 12/2006 and revised 1/2007
CREATE TABLE #temp3A (
	pla_idi INT NOT NULL
	,par_idb BIGINT NOT NULL
	,inv_idi INT NOT NULL
	,ipm_nid INT NULL -- 20110113
	,sou_idi INT NOT NULL
	,Dollars DECIMAL(19, 2) NULL
	,Units DECIMAL(15, 4) NULL
	,UnitValue DECIMAL(14, 6) NULL
	,tax_cd SMALLINT
	)

IF @SSN IS NULL
	AND @pln IS NULL
BEGIN
	INSERT #temp3A
	SELECT tr.pla_idi
		,tr.par_idb
		,tr.inv_idi
		,tr.ipm_nid -- 20110113 
		,tr.sou_idi
		,sum((
				CASE 
					WHEN tr.tra_cash_amt = 0
						THEN (tr.tra_un * coalesce(ph.prih_pr, tr.tra_pr, 1.0000))
					ELSE tr.tra_cash_amt
					END
				) * (
				CASE 
					WHEN tr.tran_cd IN (
							5
							,6
							)
						THEN - 1
					ELSE + 1
					END
				)) AS Dollars
		,sum(cast(tr.tra_un AS DECIMAL(15, 4)) * (
				CASE 
					WHEN tr.tran_cd IN (
							5
							,6
							)
						THEN - 1
					ELSE + 1
					END
				)) AS Units
		,cast(max(coalesce(ph.prih_pr, tr.tra_pr)) AS DECIMAL(15, 5)) AS UnitValue
		,tr.tax_cd
	--into #temp3A
	FROM RKDB.dbo.trans AS tr WITH (NOLOCK)
	INNER JOIN RKDB.dbo.Part par WITH (NOLOCK) ON par.par_idb = tr.par_idb
	INNER JOIN RKDB.dbo.pla pla WITH (NOLOCK) ON pla.pla_idi = tr.pla_idi
	LEFT JOIN RKDB.dbo.pricehist ph WITH (NOLOCK) ON (
			ph.inv_idi = tr.inv_idi
			AND ph.prih_effect_dt = tr.tra_process_dt
			)
	WHERE tr.tran_cd IN (
			2
			,3
			,5
			,6
			)
		AND tr.tra_process_dt >= @FDate
		AND tr.tra_process_dt <= @TDate
		--  and (@pln is null or @pln = pla.pla_code_cid)
		--  and (@SSN is null or @ssn = par.par_SSN)
		AND EXISTS (
			SELECT *
			FROM #tempH t
			WHERE t.par_idb = tr.par_idb
			)
		--  and not pla.pla_code_cid in ('L98','L99','Z98','Z99')
		AND NOT tr.tra_memo_in = 1
	GROUP BY tr.pla_idi
		,tr.par_idb
		,tr.inv_idi
		,tr.ipm_nid -- 20110113
		,tr.sou_idi
		,tr.tax_cd
	OPTION (MAXDOP 1)
END
 
CREATE NONCLUSTERED INDEX temp_temph_idx_statusDesc
ON  #tempH  ([dot],[plnCode],[statusDesc])
include (par_idb)
  
---TEST1 VBANDI
IF @SSN IS NULL
	AND @pln IS NOT NULL
BEGIN
	INSERT #temp3A
	SELECT tr.pla_idi
		,tr.par_idb
		,tr.inv_idi
		,tr.ipm_nid -- 20110113 
		,tr.sou_idi
		,sum((
				CASE 
					WHEN tr.tra_cash_amt = 0
						THEN (tr.tra_un * coalesce(ph.prih_pr, tr.tra_pr, 1.0000))
					ELSE tr.tra_cash_amt
					END
				) * (
				CASE 
					WHEN tr.tran_cd IN (
							5
							,6
							)
						THEN - 1
					ELSE + 1
					END
				)) AS Dollars
		,sum(cast(tr.tra_un AS DECIMAL(15, 4)) * (
				CASE 
					WHEN tr.tran_cd IN (
							5
							,6
							)
						THEN - 1
					ELSE + 1
					END
				)) AS Units
		,cast(max(coalesce(ph.prih_pr, tr.tra_pr)) AS DECIMAL(15, 5)) AS UnitValue
		,tr.tax_cd
	--into #temp3A
	FROM RKDB.dbo.trans AS tr WITH (NOLOCK)
	INNER JOIN RKDB.dbo.Part par WITH (NOLOCK) ON par.par_idb = tr.par_idb
	INNER JOIN RKDB.dbo.pla pla WITH (NOLOCK) ON pla.pla_idi = tr.pla_idi
	LEFT JOIN RKDB.dbo.pricehist ph WITH (NOLOCK) ON (
			ph.inv_idi = tr.inv_idi
			AND ph.prih_effect_dt = tr.tra_process_dt
			)
	WHERE tr.tran_cd IN (
			2
			,3
			,5
			,6
			)
		AND tr.tra_process_dt >= @FDate
		AND tr.tra_process_dt <= @TDate
		AND @pln = pla.pla_code_cid
		-- and (@SSN is null or @ssn = par.par_SSN)
		AND EXISTS (
			SELECT 1
			FROM #tempH t
			WHERE t.par_idb = tr.par_idb
			)
		--  and not pla.pla_code_cid in ('L98','L99','Z98','Z99')
		AND NOT tr.tra_memo_in = 1
	GROUP BY tr.pla_idi
		,tr.par_idb
		,tr.inv_idi
		,tr.ipm_nid -- 20110113 
		,tr.sou_idi
		,tr.tax_cd
END

IF @SSN IS NOT NULL
BEGIN
	INSERT #temp3A
	SELECT tr.pla_idi
		,tr.par_idb
		,tr.inv_idi
		,tr.ipm_nid -- 20110113 
		,tr.sou_idi
		,sum((
				CASE 
					WHEN tr.tra_cash_amt = 0
						THEN (tr.tra_un * coalesce(ph.prih_pr, tr.tra_pr, 1.0000))
					ELSE tr.tra_cash_amt
					END
				) * (
				CASE 
					WHEN tr.tran_cd IN (
							5
							,6
							)
						THEN - 1
					ELSE + 1
					END
				)) AS Dollars
		,sum(cast(tr.tra_un AS DECIMAL(15, 4)) * (
				CASE 
					WHEN tr.tran_cd IN (
							5
							,6
							)
						THEN - 1
					ELSE + 1
					END
				)) AS Units
		,cast(max(coalesce(ph.prih_pr, tr.tra_pr)) AS DECIMAL(15, 5)) AS UnitValue
		,tr.tax_cd
	--into #temp3A
	FROM RKDB.dbo.trans AS tr WITH (NOLOCK)
	INNER JOIN RKDB.dbo.Part par WITH (NOLOCK) ON par.par_idb = tr.par_idb
	INNER JOIN RKDB.dbo.pla pla WITH (NOLOCK) ON pla.pla_idi = tr.pla_idi
	LEFT JOIN RKDB.dbo.pricehist AS ph WITH (NOLOCK) ON (
			ph.inv_idi = tr.inv_idi
			AND ph.prih_effect_dt = tr.tra_process_dt
			)
	WHERE tr.tran_cd IN (
			2
			,3
			,5
			,6
			)
		AND tr.tra_process_dt >= @FDate
		AND tr.tra_process_dt <= @TDate
		AND @pla_idi = tr.pla_idi
		AND @par_idb = tr.par_idb
		--  and exists (select * from #tempH t
		--               where t.par_idb = tr.par_idb)
		--  and not pla.pla_code_cid in ('L98','L99','Z98','Z99')
		AND NOT tr.tra_memo_in = 1
	GROUP BY tr.pla_idi
		,tr.par_idb
		,tr.inv_idi
		,tr.ipm_nid -- 20110113 
		,tr.sou_idi
		,tr.tax_cd
END

-- assign a transaction category to the transactions being reported
-- source override removed 12/2006
SELECT tr.pla_idi
	,tr.par_idb
	,tr.inv_idi
	,tr.ipm_nid -- 20110113 
	,tr.sou_idi
	,sum(tr.Dollars) AS Dollars
	,sum(tr.Units) AS Units
	,tr.UnitValue
	,(
		CASE 
			WHEN dbo.fnSRTRconCodeAssignV2(tr.tax_cd, @TDate) IN (
					1
					,2
					,3
					)
				THEN (
						CASE 
							WHEN so.sou_rollover_in = 1
								THEN 3
							WHEN so.sou_tax_cd IN (
									151
									,160
									)
								THEN 3 --was 151,170
							WHEN so.sou_roth_in = 1
								THEN 1
							WHEN so.sou_tax_cd BETWEEN 150
									AND 158
								THEN 1 --20101220 to and 158 was and 159 --was 150 and 160
							WHEN so.sou_tax_cd BETWEEN 161
									AND 170
								THEN 1 --was 161 and 169
							WHEN so.sou_tax_cd BETWEEN 171
									AND 180
								THEN 2
							ELSE 2
							END
						)
			WHEN dbo.fnSRTRconCodeAssignV2(tr.tax_cd, @TDate) = 6
				AND i.inv_cusip_ss LIKE 'loan%'
				THEN 8
			ELSE dbo.fnSRTRconCodeAssignV2(tr.tax_cd, @TDate)
			END
		) AS TranTypeCode
INTO #temp3
FROM #temp3A AS tr
INNER JOIN RKDB.dbo.invest AS i WITH (NOLOCK) ON i.inv_idi = tr.inv_idi
INNER JOIN RKDB.dbo.source AS so WITH (NOLOCK) ON so.sou_idi = tr.sou_idi
INNER JOIN RKDB.dbo.pla AS pla WITH (NOLOCK) ON pla.pla_idi = tr.pla_idi
GROUP BY tr.pla_idi
	,tr.par_idb
	,tr.inv_idi
	,tr.ipm_nid -- 20110113 
	,tr.sou_idi
	,tr.UnitValue
	,(
		CASE 
			WHEN dbo.fnSRTRconCodeAssignV2(tr.tax_cd, @TDate) IN (
					1
					,2
					,3
					)
				THEN (
						CASE 
							WHEN so.sou_rollover_in = 1
								THEN 3
							WHEN so.sou_tax_cd IN (
									151
									,160
									)
								THEN 3 --was 151, 170
							WHEN so.sou_roth_in = 1
								THEN 1
							WHEN so.sou_tax_cd BETWEEN 150
									AND 158
								THEN 1 -- 20101220 to and 158 was and 159 --was 150 and 160
							WHEN so.sou_tax_cd BETWEEN 161
									AND 170
								THEN 1 --was 161 and 169
							WHEN so.sou_tax_cd BETWEEN 171
									AND 180
								THEN 2
							ELSE 2
							END
						)
			WHEN dbo.fnSRTRconCodeAssignV2(tr.tax_cd, @TDate) = 6
				AND i.inv_cusip_ss LIKE 'loan%'
				THEN 8
			ELSE dbo.fnSRTRconCodeAssignV2(tr.tax_cd, @TDate)
			END
		)

CREATE INDEX IX1_temp3 ON #temp3 (
	pla_idi
	,par_idb
	,inv_idi
	,ipm_nid
	,sou_idi
	) -- 20110113 added ipm_nid

-- Load #temp1 (opening balances) into #temp3 (transactions)
INSERT INTO #temp3
SELECT pla_idi
	,par_idb
	,inv_idi
	,ipm_nid -- 20110113 
	,sou_idi
	,NULL
	,Units
	,NULL
	,99
FROM #temp1

-- Set the real plan, SSN and invest codes
-- 20110113 - the IPM_NID doesn't affect these since the inv_idi is the driver.  it is picked up in the t.*
SELECT t.*
	,pla.pla_code_cid AS plnCode
	,i.inv_cusip_ss AS FundCusip
	,par.par_SSN AS SSN
	,so.sou_si AS [Source]
	,cast(so.sou_upper_title_str AS CHAR(20)) AS srcAbbrev
	,souf.souf_fund_si AS FundNumber
	,pla.pla_1_na AS PlanName
INTO #temp3B
FROM #temp3 t
INNER JOIN RKDB.dbo.pla pla WITH (NOLOCK) ON t.pla_idi = pla.pla_idi
INNER JOIN RKDB.dbo.Part par WITH (NOLOCK) ON t.par_idb = par.par_idb
INNER JOIN RKDB.dbo.Source so WITH (NOLOCK) ON t.sou_idi = so.sou_idi
INNER JOIN RKDB.dbo.invest i WITH (NOLOCK) ON t.inv_idi = i.inv_idi
INNER JOIN RKDB.dbo.Fund fun WITH (NOLOCK) ON (
		t.pla_idi = fun.pla_idi
		AND (
			(
				t.inv_idi = fun.inv_idi
				AND t.ipm_nid IS NULL
				)
			OR (
				fun.inv_idi IS NULL
				AND fun.ipm_nid = t.ipm_nid
				)
			)
		)
INNER JOIN RKDB.dbo.SouFund souf WITH (NOLOCK) ON (
		t.sou_idi = souf.sou_idi
		AND fun.fun_idi = souf.fun_idi
		)

--      AND fun.ipm_nid=souf_ft.sou_idi = souf.sou_idi
--SELECT 1255,par_idb,inv_idi,ipm_nid,sum(units) units FROM #temp3 Group By par_idb,inv_idi,ipm_nid
--SELECT 1255,par_idb,sum(units) units FROM #temp3 Group By par_idb
--SELECT '1256_#temp3b',* FROM #temp3B
--RETURN 
---SELECT 1256,par_idb,sum(units) FROM #temp3b Group By par_idb 

CREATE NONCLUSTERED INDEX temp_temp3b_plnCode
ON  #temp3B([plnCode]);  --VBANDI2

DELETE #temp3B
WHERE plnCode IN (
		'L99'
		,'Z98'
		,'Z99'
		)

-- Consolidate transactions into plan/person/fund/source
--  entries with a pivot by Transaction Type
SELECT par_idb
	,cast(plnCode AS CHAR(10)) AS plnCode
	,cast(PlanName AS VARCHAR(100)) AS PlanName
	,SSN
	,cast(NULL AS INT) AS demogid
	,FundCusip AS FundCusip
	,cast(NULL AS VARCHAR(20)) AS FundAbbrev
	,FundNumber
	,[Source]
	,srcAbbrev
	,inv_idi -- 20110113
	,ipm_nid -- 20110113
	,sou_idi -- 20131028
	,cast(0.00000 AS DECIMAL(15, 5)) AS PriorUnitValue
	,cast(0.00 AS DECIMAL(15, 2)) AS OpeningDollars
	,sum(CASE 
			WHEN TranTypeCode = 99
				THEN Units
			ELSE 0
			END) AS OpeningUnits
	,cast(0.00000 AS DECIMAL(15, 5)) AS ClosingUnitValue
	,cast(0.00 AS DECIMAL(15, 2)) AS ClosingDollars
	,sum(convert(DECIMAL(15, 4), Units)) AS ClosingUnits
	,sum(CASE 
			WHEN TranTypeCode = 0
				THEN Dollars
			ELSE 0
			END) AS gnLossDollars
	,sum(CASE 
			WHEN TranTypeCode = 0
				THEN Units
			ELSE 0
			END) AS gnLossUnits
	,sum(CASE 
			WHEN TranTypeCode IN (
					1
					,22
					)
				THEN Dollars
			ELSE 0
			END) AS EmpeeContribDollars
	,sum(CASE 
			WHEN TranTypeCode IN (
					1
					,22
					)
				THEN Units
			ELSE 0
			END) AS EmpeeContribUnits
	,sum(CASE 
			WHEN TranTypeCode = 2
				THEN Dollars
			ELSE 0
			END) AS EmperContribDollars
	,sum(CASE 
			WHEN TranTypeCode = 2
				THEN Units
			ELSE 0
			END) AS EmperContribUnits
	,sum(CASE 
			WHEN TranTypeCode = 3
				THEN Dollars
			ELSE 0
			END) AS RollContribDollars
	,sum(CASE 
			WHEN TranTypeCode = 3
				THEN Units
			ELSE 0
			END) AS RollContribUnits
	,sum(CASE 
			WHEN TranTypeCode = 4
				THEN Dollars
			ELSE 0
			END) AS AssetTransInDollars
	,sum(CASE 
			WHEN TranTypeCode = 4
				THEN Units
			ELSE 0
			END) AS AssetTransInUnits
	,sum(CASE 
			WHEN TranTypeCode = 5
				THEN Dollars
			ELSE 0
			END) AS AssetTransOutDollars
	,sum(CASE 
			WHEN TranTypeCode = 5
				THEN Units
			ELSE 0
			END) AS AssetTransOutUnits
	,sum(CASE 
			WHEN TranTypeCode = 6
				THEN Dollars
			ELSE 0
			END) AS WithdrawalDollars
	,sum(CASE 
			WHEN TranTypeCode = 6
				THEN Units
			ELSE 0
			END) AS WithdrawalUnits
	,sum(CASE 
			WHEN TranTypeCode = 7
				THEN Dollars
			ELSE 0
			END) AS WdrwlCmplDollars
	,sum(CASE 
			WHEN TranTypeCode = 7
				THEN Units
			ELSE 0
			END) AS WdrwlCmplUnits
	,sum(CASE 
			WHEN TranTypeCode = 8
				THEN Dollars
			ELSE 0
			END) AS LoanDefaultDollars
	,sum(CASE 
			WHEN TranTypeCode = 8
				THEN Units
			ELSE 0
			END) AS LoanDefaultUnits
	,sum(CASE 
			WHEN TranTypeCode = 9
				THEN Dollars
			ELSE 0
			END) AS LoanTakenDollars
	,sum(CASE 
			WHEN TranTypeCode = 9
				THEN Units
			ELSE 0
			END) AS LoanTakenUnits
	,sum(CASE 
			WHEN TranTypeCode = 10
				THEN Dollars
			ELSE 0
			END) AS LoanRepayPrinDollars
	,sum(CASE 
			WHEN TranTypeCode = 10
				THEN Units
			ELSE 0
			END) AS LoanRepayPrinUnits
	,sum(CASE 
			WHEN TranTypeCode = 11
				THEN Dollars
			ELSE 0
			END) AS LoanRepayIntDollars
	,sum(CASE 
			WHEN TranTypeCode = 11
				THEN Units
			ELSE 0
			END) AS LoanRepayIntUnits
	,sum(CASE 
			WHEN TranTypeCode = 12
				THEN Dollars
			ELSE 0
			END) AS LoanAdminDollars
	,sum(CASE 
			WHEN TranTypeCode = 12
				THEN Units
			ELSE 0
			END) AS LoanAdminUnits
	,sum(CASE 
			WHEN TranTypeCode = 13
				THEN Dollars
			ELSE 0
			END) AS FundTransferDollars
	,sum(CASE 
			WHEN TranTypeCode = 13
				THEN Units
			ELSE 0
			END) AS FundTransferUnits
	,sum(CASE 
			WHEN TranTypeCode = 14
				THEN Dollars
			ELSE 0
			END) AS PCRAChangeDollars
	,sum(CASE 
			WHEN TranTypeCode = 14
				THEN Units
			ELSE 0
			END) AS PCRAChangeUnits
	,sum(CASE 
			WHEN TranTypeCode = 15
				THEN Dollars
			ELSE 0
			END) AS ForfeitureNCDollars
	,sum(CASE 
			WHEN TranTypeCode = 15
				THEN Units
			ELSE 0
			END) AS ForfeitureNCUnits
	,sum(CASE 
			WHEN TranTypeCode = 16
				THEN Dollars
			ELSE 0
			END) AS ForfeitureCDollars
	,sum(CASE 
			WHEN TranTypeCode = 16
				THEN Units
			ELSE 0
			END) AS ForfeitureCUnits
	,sum(CASE 
			WHEN TranTypeCode = 17
				THEN Dollars
			ELSE 0
			END) AS FeeDollars
	,sum(CASE 
			WHEN TranTypeCode = 17
				THEN Units
			ELSE 0
			END) AS FeeUnits
	,sum(CASE 
			WHEN TranTypeCode = 18
				THEN Dollars
			ELSE 0
			END) AS MiscDollars
	,sum(CASE 
			WHEN TranTypeCode = 18
				THEN Units
			ELSE 0
			END) AS MiscUnits
	,sum(CASE 
			WHEN TranTypeCode = 19
				THEN Dollars
			ELSE 0
			END) AS NonFundedDollars
	,sum(CASE 
			WHEN TranTypeCode = 19
				THEN Units
			ELSE 0
			END) AS NonFundedUnits
	,cast(0.00 AS DECIMAL(9, 2)) AS OldAdminFees
	,sum(abs(CASE 
				WHEN Dollars IS NULL
					THEN 0
				ELSE Dollars
				END)) AS absTrans
	,cast(NULL AS SMALLINT) AS fundType
INTO #temp4
FROM #temp3B
GROUP BY par_idb
	,plnCode
	,PlanName
	,SSN
	,FundNumber
	,FundCusip
	,[Source]
	,srcAbbrev
	,inv_idi -- 20110113
	,ipm_nid -- 20110113
	,sou_idi -- 20131028
ORDER BY par_idb
	,plnCode
	,PlanName
	,SSN
	,FundNumber
	,FundCusip
	,[Source]
	,srcAbbrev

CREATE NONCLUSTERED INDEX temp_temp4_FundCusip
ON  #temp4  ([FundCusip],[fundType])


--SELECT 1464,ee.par_last_na,t.* FROM #temp4 t INNER JOIN rkdb..vwPart ee ON t.par_idb=ee.par_idb order by par_idb,fundNumber
--RETURN 
-- set the fundType
UPDATE #temp4
SET fundType = f.fundType
FROM #temp4 t
INNER JOIN qadcssql.bis.dbo.Fund f ON t.FundCusip = f.tdilookup

UPDATE #temp4
SET fundType = CASE 
		WHEN FundCusip = 'SDBA'
			THEN 164
		WHEN FundCusip LIKE 'loan%'
			THEN 184
		ELSE NULL
		END
FROM #temp4
WHERE fundType IS NULL

-- Add prices for opening balances
UPDATE #temp4
SET PriorUnitValue = prh.prih_pr
FROM #temp4 t
INNER JOIN RKDB.dbo.Invest i WITH (NOLOCK) ON t.FundCusip = i.inv_cusip_ss
INNER JOIN RKDB.dbo.PriceHist prh WITH (NOLOCK) ON i.inv_idi = prh.inv_idi
WHERE prh.prih_effect_dt = (
		SELECT max(prh2.prih_effect_dt)
		FROM RKDB.dbo.PriceHist prh2 WITH (NOLOCK)
		WHERE prh2.inv_idi = prh.inv_idi
			AND prh2.prih_effect_dt < @FDate
			AND prh2.prih_pr IS NOT NULL
			AND prh2.prih_pr > 0.0000
		)

-- Add prices for closing balances
UPDATE #temp4
SET ClosingUnitValue = prh.prih_pr
FROM #temp4 t
INNER JOIN RKDB.dbo.Invest i WITH (NOLOCK) ON t.FundCusip = i.inv_cusip_ss
INNER JOIN RKDB.dbo.PriceHist prh WITH (NOLOCK) ON i.inv_idi = prh.inv_idi
WHERE prh.prih_effect_dt = (
		SELECT max(prh2.prih_effect_dt)
		FROM RKDB.dbo.PriceHist prh2 WITH (NOLOCK)
		WHERE prh2.inv_idi = prh.inv_idi
			AND prh2.prih_effect_dt <= convert(VARCHAR(10), @TDate, 101)
			AND prh2.prih_pr IS NOT NULL
			AND prh2.prih_pr > 0.0000
		)

-- Calculate dollars for balances
UPDATE #temp4
SET OpeningDollars = convert(DECIMAL(15, 2), OpeningUnits * (
			CASE 
				WHEN PriorUnitValue IS NULL
					THEN 0.0000
				ELSE PriorUnitValue
				END
			))
	,ClosingDollars = convert(DECIMAL(15, 2), ClosingUnits * (
			CASE 
				WHEN ClosingUnitValue IS NULL
					THEN 0.0000
				ELSE ClosingUnitValue
				END
			))
FROM #temp4

-- Clear unpriced data
UPDATE #temp4
SET OpeningDollars = 0.00
WHERE OpeningDollars IS NULL

UPDATE #temp4
SET ClosingDollars = 0.00
WHERE ClosingDollars IS NULL

-- delete blank entries (zero balances and no transactions)
-- delete #temp4
-- where (OpeningDollars + ClosingDollars) = 0.00
--   and absTrans = 0.00
-- If people are not on table #temp4, then they have no
--  financial numbers (opening balances or transactions),
--  therefore they are not needed
--print 'test2'
--select * from #temp4
DELETE #tempH
FROM #tempH h
WHERE NOT EXISTS (
		SELECT 1
		FROM #temp4 t
		WHERE t.plnCode = h.plnCode
			AND t.par_idb = h.par_idb
		)

--SELECT 1590,* FROM #temp4
--RETURN 
-- Create the Statement fund table 
--  - old loan admin fees are ignored
--  - fundType 264 means share accounting
SELECT cast(NULL AS INT) AS demogid
	,plnCode
	,par_idb
	,FundCusip
	-- 20110113 ,'FUND' + convert(varchar(4), FundNumber) as fundAbbrev
	,fundAbbrev = CASE 
		WHEN ipm_nid IS NULL
			THEN 'FUND' + convert(VARCHAR(4), FundNumber)
		ELSE 'IPM_' + convert(VARCHAR(4), FundNumber) -- there is a computed column called FundNumber that requires a fund number in pos 5-6
		END
	,cast(NULL AS INT) inv_idi -- 20110113 this hack was to allow for null values for totals and fund rollup
	,inv_idi AS inv_idi_noNull -- 20110113
	,ipm_nid -- 20110113
	,sum(coalesce(OpeningDollars, 0.00)) AS openBal
	,sum(coalesce(OpeningUnits, 0.0000)) AS openUnits
	,sum(EmpeeContribDollars + RollContribDollars) AS eeCont
	,sum(EmperContribDollars) AS erCont
	,sum(ClosingDollars
		--  + gnLossDollars
		- OpeningDollars - EmpeeContribDollars - EmperContribDollars - RollContribDollars - AssetTransInDollars - AssetTransOutDollars - WithdrawalDollars - WdrwlCmplDollars - LoanDefaultDollars - LoanTakenDollars - LoanRepayPrinDollars - LoanRepayIntDollars - LoanAdminDollars - FundTransferDollars - ForfeitureNCDollars - ForfeitureCDollars - FeeDollars - NonFundedDollars - (
			CASE 
				WHEN fundType = 264
					THEN 0
				ELSE MiscDollars
				END
			)) AS gnloss
	,sum(LoanRepayPrinDollars + LoanRepayIntDollars + LoanAdminDollars) AS loanRepay
	,sum(FundTransferDollars) AS fundTransfers
	,sum(WithdrawalDollars + WdrwlCmplDollars + LoanDefaultDollars + LoanTakenDollars) AS LoanWd
	,sum(ForfeitureNCDollars + ForfeitureCDollars + NonFundedDollars + AssetTransInDollars + AssetTransOutDollars + FeeDollars + (
			CASE 
				WHEN fundType = 264
					THEN 0
				ELSE MiscDollars
				END
			)) AS [misc]
	,sum(coalesce(ClosingDollars, 0.00)) AS endBal
	,sum(coalesce(ClosingUnits, 0.0000)) AS endUnits
	,cast(0 AS REAL) AS fundeepct
	,cast(0 AS REAL) AS funderpct
	,cast(0 AS REAL) AS fundmppct
	,cast(0 AS REAL) AS fundropct
	,cast(0 AS REAL) AS fundpspct
	,max(PriorUnitValue) AS openUnitValue
	,max(ClosingUnitValue) AS closeUnitValue
INTO #tempF
FROM #temp4 t
GROUP BY plnCode
	,par_idb
	,FundNumber
	,FundCusip
	,inv_idi -- 20110113
	,ipm_nid -- 20110113
ORDER BY plnCode
	,par_idb
	,FundNumber
	,FundCusip

--select * from #tempF where gnloss is null
CREATE INDEX IX1_tempF ON #tempF (
	par_idb
	,FundCusip
	)

CREATE NONCLUSTERED INDEX  temp_tempf_end_bal_ipm_nid
ON  #tempF  ([FundCusip],[endBal],[ipm_nid])
INCLUDE ([plnCode],[par_idb],[openBal]) 
 
CREATE NONCLUSTERED INDEX temp_tempf_idx3
ON  #tempF ([ipm_nid])
INCLUDE ([demogid],[plnCode],[par_idb],[fundAbbrev],[openBal],[openUnits],[eeCont],[erCont],[gnloss],[loanRepay],[fundTransfers],[LoanWd],[misc],[endBal],[endUnits],[fundeepct],[funderpct],[fundmppct],[fundropct],[fundpspct])

CREATE NONCLUSTERED INDEX  temp_tempf_demogid
ON  #tempF  ([demogid])

-- 2011013 this hack was used to get the inv-idi column to all nulls
UPDATE #tempF
SET inv_idi = inv_idi_noNull

ALTER TABLE #tempF

DROP COLUMN inv_idi_noNull

-- 20110113
--SELECT 1661,* FROM #tempF
--RETURN 
-- Calculate the personal balances, minus loans
SELECT ft.plnCode
	,ft.par_idb
	,sum(CASE 
			WHEN f.invType = 'Asset Allocation Funds'
				THEN endbal
			ELSE 0
			END) AS AssetBal
	,sum(CASE 
			WHEN f.invType = 'Stock Funds'
				THEN endbal
			ELSE 0
			END) AS StockBal
	,sum(CASE 
			WHEN f.invType = 'Bond Funds'
				THEN endbal
			ELSE 0
			END) AS BondBal
	,sum(CASE 
			WHEN f.invType = 'Fixed Income Funds'
				THEN endbal
			ELSE 0
			END) AS FixedBal
	,sum(CASE 
			WHEN f.invType = 'Personal Choice Retirement Account'
				THEN endbal
			ELSE 0
			END) AS PCRABal
	,sum(endbal) AS TotBal
	,sum(openBal) AS OpenBal
INTO #tempFtot
FROM #tempF ft
INNER JOIN qadcssql.bis.dbo.vwFund f ON ft.FundCusip = f.tdilookup
WHERE NOT ft.fundcusip LIKE '%loan%'
	AND NOT ft.fundcusip = 'SDBA'
GROUP BY ft.plnCode
	,par_idb
CREATE NONCLUSTERED INDEX temp_tempFtot_total_bal_openbal
ON #tempFtot ([TotBal],[OpenBal])  --VBANDI2
CREATE NONCLUSTERED INDEX temp_tempFtot_plnCode_par_idb
ON  #tempFtot  ([plnCode],[par_idb])

--SELECT 1699,* FROM #tempFTot 
--RETURN 
-- special entries for sdba/pcra
UPDATE #tempFtot
SET PCRABal = ft.PCRABal + f.endbal
	,TotBal = ft.TotBal + f.endbal
	,openBal = ft.openBal + f.OpenBal
FROM #tempFtot ft
	,#tempF f
WHERE ft.plnCode = f.plnCode
	AND ft.par_idb = f.par_idb
	AND f.fundcusip = 'SDBA'

INSERT INTO #tempFtot
SELECT f.plnCode
	,f.par_idb
	,0.00
	,0.00
	,0.00
	,0.00
	,sum(f.endbal) AS PCRABal
	,sum(f.endbal) AS TotBal
	,sum(f.openBal) AS OpenBal
FROM #tempF f
WHERE f.FundCusip = 'SDBA'
	AND NOT f.endbal = 0.00
	AND NOT EXISTS (
		SELECT *
		FROM #tempFtot ft
		WHERE f.plnCode = ft.plnCode
			AND f.par_idb = ft.par_idb
		)
GROUP BY f.plnCode
	,f.par_idb

-- calculate the allocations by asset type for the pie chart
UPDATE #tempH
SET Alloc1 = abs(round(((ft.AssetBal * 100) / TotBal), 0))
	,Alloc2 = abs(round(((ft.StockBal * 100) / TotBal), 0))
	,Alloc3 = abs(round(((ft.BondBal * 100) / TotBal), 0))
	,Alloc4 = abs(round(((ft.FixedBal * 100) / TotBal), 0))
	,Alloc5 = abs(round(((ft.PCRABal * 100) / TotBal), 0))
FROM #tempH h
	,#tempFtot ft
WHERE h.plnCode = ft.plnCode
	AND h.par_idb = ft.par_idb
	AND NOT totbal = 0.00

-- Remove roundings
UPDATE #tempH
SET Alloc5 = CASE 
		WHEN Alloc5 = 0
			THEN 0
		ELSE Alloc5 - ((alloc1 + alloc2 + alloc3 + alloc4 + alloc5) - 100)
		END
	,Alloc4 = CASE 
		WHEN Alloc4 = 0
			THEN 0
		WHEN Alloc5 > 0
			THEN Alloc4
		ELSE Alloc4 - ((alloc1 + alloc2 + alloc3 + alloc4) - 100)
		END
	,Alloc3 = CASE 
		WHEN Alloc3 = 0
			THEN 0
		WHEN Alloc5 > 0
			THEN Alloc3
		WHEN Alloc4 > 0
			THEN Alloc3
		ELSE Alloc3 - ((alloc1 + alloc2 + alloc3) - 100)
		END
	,Alloc2 = CASE 
		WHEN Alloc2 = 0
			THEN 0
		WHEN Alloc5 > 0
			THEN Alloc2
		WHEN Alloc4 > 0
			THEN Alloc2
		WHEN Alloc3 > 0
			THEN Alloc2
		ELSE Alloc2 - ((alloc1 + alloc2) - 100)
		END
	,Alloc1 = CASE 
		WHEN Alloc1 = 0
			THEN 0
		WHEN Alloc5 > 0
			THEN Alloc1
		WHEN Alloc4 > 0
			THEN Alloc1
		WHEN Alloc3 > 0
			THEN Alloc1
		WHEN Alloc2 > 0
			THEN Alloc1
		ELSE 100
		END
WHERE NOT (alloc1 + alloc2 + alloc3 + alloc4 + alloc5) IN (
		0
		,100
		)

-- clear out fund entries that net to zero balance and activity
DELETE #tempH
FROM #tempH t
	,#tempFtot f
WHERE t.par_idb = f.par_idb
	AND f.TotBal = 0.00
	AND f.OpenBal = 0.00
	AND NOT EXISTS (
		SELECT *
		FROM #tempF tf
		WHERE tf.par_idb = t.par_idb
			AND (
				tf.OpenBal > 0.00
				OR abs(tf.gnloss) > 0.00
				OR abs(tf.misc) > 0.00
				OR abs(fundTransfers) > 0.00 -- 20100409
				OR abs(tf.loanWd) > 0.00
				OR tf.EndBal > 0.00
				) --                      and tf.FundCusip like '%loan%'
		)

DELETE #tempF
FROM #tempF t
	,#tempFtot f
WHERE t.par_idb = f.par_idb
	AND f.TotBal = 0.00
	AND f.OpenBal = 0.00
	AND t.OpenBal = 0.00
	AND t.endbal = 0.00
	AND t.gnloss = 0.00
	AND t.misc = 0.00
	AND t.loanWd = 0.00
	AND NOT EXISTS (
		SELECT *
		FROM #tempF tf
		WHERE tf.par_idb = t.par_idb
			AND (
				tf.OpenBal > 0.00
				OR abs(tf.gnloss) > 0.00
				OR abs(tf.misc) > 0.00
				OR abs(fundTransfers) > 0.00 -- 20100409
				OR abs(tf.loanWd) > 0.00
				OR tf.EndBal > 0.00
				)
			AND tf.FundCusip LIKE '%loan%'
		)

DROP TABLE #tempFtot

-- set the balance in the loan fund on the participant header
UPDATE #tempH
SET loanBal = f.endBal
FROM #tempH h
	,#tempF f
WHERE h.par_idb = f.par_idb
	AND f.FundCusip IN (
		'loan'
		,'loan fund'
		)

-- Create the Statement Source table 
-- - srcLoans is not used
-- - fundType 264 is share accounting
SELECT cast(NULL AS INT) AS demogid
	,plnCode
	,par_idb
	,[Source]
	,'SOURCE' + convert(VARCHAR(2), [Source]) AS srcAbbrev
	,sum(OpeningDollars) AS openBal
	,sum(EmpeeContribDollars + EmperContribDollars + RollContribDollars) AS contrib
	,sum(LoanRepayPrinDollars + LoanRepayIntDollars + LoanAdminDollars) AS loanRepay
	,sum(ClosingDollars
		--  + gnLossDollars
		- OpeningDollars - EmpeeContribDollars - EmperContribDollars - RollContribDollars - AssetTransInDollars - AssetTransOutDollars - WithdrawalDollars - WdrwlCmplDollars - LoanDefaultDollars - LoanTakenDollars - LoanRepayPrinDollars - LoanRepayIntDollars - LoanAdminDollars - FundTransferDollars - ForfeitureNCDollars - ForfeitureCDollars - FeeDollars - NonFundedDollars - (
			CASE 
				WHEN fundType = 264
					THEN 0
				ELSE MiscDollars
				END
			)) AS gnloss
	,sum(WithdrawalDollars + WdrwlCmplDollars + LoanDefaultDollars + LoanTakenDollars) AS LoanWd
	,cast(0.00 AS MONEY) AS srcLoans
	,sum(AssetTransInDollars + AssetTransOutDollars + NonFundedDollars + ForfeitureCDollars + ForfeitureNCDollars + FeeDollars + FundTransferDollars + (
			CASE 
				WHEN fundType = 264
					THEN 0
				ELSE MiscDollars
				END
			)) AS [misc]
	,sum(ClosingDollars) AS endBal
	,cast(' ' AS CHAR(8)) AS vestedPct
	,cast(0.00 AS MONEY) AS vestedBal
	,cast(0.00 AS MONEY) AS ytdContrib
	,cast(0 AS INT) AS vs_sch
	,cast(0.00 AS MONEY) AS prior_withdrawal
	,cast(NULL AS DATETIME) AS Vesting_Enddate
	,cast(NULL AS DATETIME) AS Vesting_Startdate
	,sou_idi -- 20131028
INTO #tempS
FROM #temp4 t
GROUP BY plnCode
	,par_idb
	,[Source]
	,SrcAbbrev
	,sou_idi
ORDER BY plnCode
	,par_idb
	,[Source]
	,SrcAbbrev

CREATE INDEX IX1_tempS ON #tempS (
	par_idb
	,[Source]
	)
	/*vbandi2*/
CREATE NONCLUSTERED INDEX  temp_temps_endBal_demogid
ON  #tempS ([endBal],[demogid])
INCLUDE ([plnCode],[par_idb],[Source])
CREATE NONCLUSTERED INDEX  temp_idx1_temps_gnloss
ON  #tempS 
([openBal],[contrib],[loanRepay],[gnloss],[LoanWd],[misc],[endBal],[ytdContrib])
CREATE NONCLUSTERED INDEX  temp_idx2_temps_vestedPct
ON  #tempS  ([vestedPct],[vs_sch],[Vesting_Enddate],[Vesting_Startdate])

DROP TABLE #temp1

DROP TABLE #temp2

DROP TABLE #temp3

DROP TABLE #temp3A

DROP TABLE #temp3B

DROP TABLE #temp4

-- create temp table of source elections by fund,
--  summarizing some sources
SELECT h.par_idb
	,i.inv_cusip_ss AS FundCusip
	,souf.souf_fund_si AS FundNumber
	,so.sou_si
	,ipm_nid
	,max(CASE 
			WHEN so.sou_tax_cd = 150
				OR so.sou_tax_cd BETWEEN 152
					AND 158
				OR so.sou_tax_cd BETWEEN 161
					AND 170 -- 20101220 to and 158 was and 159 --was 150-169 <>151
				THEN eleh.eleh_dpct -- was and not so.sou_tax_cd = 151
			ELSE 0
			END) AS fundeepct
	,max(CASE 
			WHEN so.sou_tax_cd IN (
					171
					,172
					,174
					,176
					,177
					,178
					,--was 171-179
					179
					,180
					)
				THEN eleh.eleh_dpct
			ELSE 0
			END) AS funderpct
	,max(CASE 
			WHEN so.sou_tax_cd IN (
					151
					,160
					)
				THEN eleh.eleh_dpct --was 151,170
			ELSE 0
			END) AS fundropct
	,max(CASE 
			WHEN so.sou_tax_cd = 173
				THEN eleh.eleh_dpct --was 177
			ELSE 0
			END) AS fundpspct
	,max(CASE 
			WHEN so.sou_tax_cd = 175
				THEN eleh.eleh_dpct --was 180
			ELSE 0
			END) AS fundmppct
INTO #tempFelectByS
FROM #tempH h
INNER JOIN RKDB.dbo.ElectHist eleh WITH (NOLOCK) ON h.par_idb = eleh.par_idb
INNER JOIN RKDB.dbo.Source so WITH (NOLOCK) ON eleh.sou_idi = so.sou_idi
INNER JOIN RKDB.dbo.Fund fun WITH (NOLOCK) ON eleh.fun_idi = fun.fun_idi
INNER JOIN RKDB.dbo.soufund souf WITH (NOLOCK) ON (
		souf.sou_idi = eleh.sou_idi
		AND souf.fun_idi = eleh.fun_idi
		)
LEFT JOIN RKDB.dbo.Invest i WITH (NOLOCK) ON fun.inv_idi = i.inv_idi
WHERE h.statusDesc IN (
		'ACT'
		,'LOA'
		,'NOT'
		,'SUS'
		,'INA'
		,'ELI'
		)
	AND h.dot IS NULL
	AND EXISTS (
		SELECT 1
		FROM #tempS ts
		WHERE ts.par_idb = h.par_idb
			AND NOT ts.endbal = 0.00
			AND ts.[Source] = so.sou_si
		)
	AND eleh.eleh_effect_dt = (
		SELECT max(eleh2.eleh_effect_dt)
		FROM RKDB.dbo.ElectHist eleh2 WITH (NOLOCK)
		WHERE eleh2.eleh_effect_dt <= @TDate
			AND eleh2.par_idb = eleh.par_idb
		)
	AND eleh.eleh_dpct IS NOT NULL
	AND eleh.eleh_dpct > 0
GROUP BY h.par_idb
	,i.inv_cusip_ss
	,souf.souf_fund_si
	,so.sou_si
	,ipm_nid
CREATE NONCLUSTERED INDEX temp_tempFelectByS_fundeepct
ON  #tempFelectByS  ([fundeepct],[funderpct],[fundropct],[fundpspct],[fundmppct])

--SELECT 1998 rownum,* FROM #tempFelectByS order by par_idb,sou_si
--RETURN 
-- Clear out zeros
DELETE FbyS
FROM #tempFelectByS FbyS
WHERE (
		fundeepct IS NULL
		OR fundeepct = 0
		)
	AND (
		funderpct IS NULL
		OR funderpct = 0
		)
	AND (
		fundropct IS NULL
		OR fundropct = 0
		)
	AND (
		fundpspct IS NULL
		OR fundpspct = 0
		)
	AND (
		fundmppct IS NULL
		OR fundmppct = 0
		)

-- If multiple elections of each type, use the one with the lowest source number
-- Revised: just assume the elections can vary by source type, but not by source within type,
--  e.g. that ermatch 2 and basic safe harbor will not have different elections.
--  They could be different, but its very rare, and this data is not used anymore as we
--   have scicom for statements.
SELECT par_idb
	,FundCusip
	,FundNumber
	,ipm_nid
	,max(fundeepct) AS fundeepct
	,max(funderpct) AS funderpct
	,max(fundropct) AS fundropct
	,max(fundpspct) AS fundpspct
	,max(fundmppct) AS fundmppct
INTO #tempFelect
FROM #tempFelectByS te1
GROUP BY par_idb
	,FundCusip
	,FundNumber
	,ipm_nid

DROP TABLE #tempFelectByS

--SELECT 2057,* FROM #tempFelect
--RETURN 
-- Apply elections by source to fund records
UPDATE #tempF
SET fundeepct = coalesce(fe.fundeepct, 0)
	,funderpct = coalesce(fe.funderpct, 0)
	,fundropct = coalesce(fe.fundropct, 0)
	,fundpspct = coalesce(fe.fundpspct, 0)
	,fundmppct = coalesce(fe.fundmppct, 0)
FROM #tempF f
LEFT JOIN #tempFelect fe ON (
		f.par_idb = fe.par_idb
		AND f.FundCusip = fe.FundCusip
		)

--SELECT 2077,* FROM #tempF WHERE par_idb=333527 RETURN 
-- 20110113 elections for ipms 
UPDATE #tempF
SET fundeepct = coalesce(fe.fundeepct, 0)
	,funderpct = coalesce(fe.funderpct, 0)
	,fundropct = coalesce(fe.fundropct, 0)
	,fundpspct = coalesce(fe.fundpspct, 0)
	,fundmppct = coalesce(fe.fundmppct, 0)
FROM #tempF f
LEFT JOIN #tempFelect fe ON (
		f.par_idb = fe.par_idb
		AND f.ipm_nid = fe.ipm_nid
		)
WHERE f.ipm_nid IS NOT NULL

--SELECT 2097,* from #tempF return
--SELECT 2098,* FROM #tempFelect RETURN 
-- add dummy fund entries where there is an election but no balance
INSERT INTO #tempF
SELECT cast(NULL AS INT) AS demogid
	,h.plnCode
	,fe.par_idb
	,fe.FundCusip
	,'FUND' + convert(VARCHAR(4), fe.FundNumber) AS fundAbbrev
	,NULL AS inv_idi
	,NULL AS ipm_nid
	,0 AS openBal
	,0 AS openUnits
	,0 AS eeCont
	,0 AS erCont
	,0 AS gnloss
	,0 AS loanRepay
	,0 AS fundTransfers
	,0 AS LoanWd
	,0 AS [misc]
	,0 AS endBal
	,0 AS endUnits
	,coalesce(fe.fundeepct, 0)
	,coalesce(fe.funderpct, 0)
	,coalesce(fe.fundmppct, 0)
	,coalesce(fe.fundropct, 0)
	,coalesce(fe.fundpspct, 0)
	,0 AS openUnitValue
	,0 AS closeUnitValue
FROM #tempFelect fe
	,#tempH h
WHERE fe.par_idb = h.par_idb
	AND NOT EXISTS (
		SELECT *
		FROM #tempF f
		WHERE f.par_idb = fe.par_idb
			AND f.FundCusip = fe.FundCusip
		)
	AND (
		fe.fundeepct > 0
		OR fe.funderpct > 0
		OR fe.fundmppct > 0
		OR fe.fundropct > 0
		OR fe.fundpspct > 0
		)
	AND EXISTS (
		SELECT *
		FROM #tempS ts
		INNER JOIN rkdb.dbo.pla pla WITH (NOLOCK) ON ts.plnCode = pla.pla_code_cid
		INNER JOIN rkdb.dbo.source so WITH (NOLOCK) ON (
				ts.[Source] = so.sou_si
				AND so.pla_idi = pla.pla_idi
				)
		WHERE ts.par_idb = h.par_idb
			AND NOT ts.endbal = 0.00
			AND (
				(
					fe.fundeepct > 0
					AND so.sou_tax_cd < 171
					AND NOT so.sou_tax_cd IN (
						151
						,160
						) --and not so.sou_tax_cd = 151
					)
				OR (
					fe.fundmppct > 0
					AND so.sou_lower_title_str IN (
						'MP'
						,'MPP'
						)
					)
				OR (
					fe.funderpct > 0
					AND so.sou_tax_cd > 170
					AND NOT so.sou_tax_cd IN (
						173
						,176
						) --was <>177
					)
				OR (
					fe.fundropct > 0
					AND so.sou_tax_cd IN (
						151
						,176
						) --was 151,171
					)
				OR (
					fe.fundpspct > 0
					AND so.sou_tax_cd = 173 --was 177
					)
				)
		)
	AND NOT (
		fundCusip IS NULL
		AND ipm_nid IS NOT NULL
		)

--SELECT 2183,* FROM #tempF
--RETURN 
-- pull the opening and closing unit values from the price history
UPDATE #tempF
SET openUnitValue = prh.prih_pr
FROM #tempf t
INNER JOIN RKDB.dbo.Invest i WITH (NOLOCK) ON t.FundCusip = i.inv_cusip_ss
INNER JOIN RKDB.dbo.PriceHist prh WITH (NOLOCK) ON i.inv_idi = prh.inv_idi
WHERE t.openunitvalue = 0
	AND prh.prih_effect_dt = (
		SELECT max(prh2.prih_effect_dt)
		FROM RKDB.dbo.PriceHist prh2 WITH (NOLOCK)
		WHERE prh2.inv_idi = prh.inv_idi
			AND prh2.prih_effect_dt < @FDate
			AND prh2.prih_pr IS NOT NULL
			AND prh2.prih_pr > 0.0000
		)

UPDATE #tempF
SET closeUnitValue = prh.prih_pr
FROM #tempf t
INNER JOIN RKDB.dbo.Invest i WITH (NOLOCK) ON t.FundCusip = i.inv_cusip_ss
INNER JOIN RKDB.dbo.PriceHist prh WITH (NOLOCK) ON i.inv_idi = prh.inv_idi
WHERE t.closeunitvalue = 0
	AND prh.prih_effect_dt = (
		SELECT max(prh2.prih_effect_dt)
		FROM RKDB.dbo.PriceHist prh2 WITH (NOLOCK)
		WHERE prh2.inv_idi = prh.inv_idi
			AND prh2.prih_effect_dt <= @TDate
			AND prh2.prih_pr IS NOT NULL
			AND prh2.prih_pr > 0.0000
		)

DROP TABLE #tempFelect

--	UPDATE #tempF 
--	SET closeUnitValue = 0 
--	,openUnitValue = 0 
--	WHERE ipm_nid IS NOT NULL 
--SELECT 2244, * FROM #tempF RETURN 
-- Clear out old, inactive, no-balance entries.
DELETE #tempF
FROM #tempF f
WHERE f.OpenBal = 0
	AND f.EndBal = 0
	AND coalesce(f.fundeepct, 0) = 0
	AND coalesce(f.funderpct, 0) = 0
	AND coalesce(f.fundmppct, 0) = 0
	AND coalesce(f.fundropct, 0) = 0
	AND coalesce(f.fundpspct, 0) = 0
	AND f.fundTransfers = 0.00 -- 20100409 
	AND f.gnloss = 0.00
	AND f.misc = 0.00
	AND f.loanWd = 0.00

--SELECT 2268, * FROM #tempF RETURN 
DELETE #tempH
FROM #tempH h
WHERE NOT EXISTS (
		SELECT *
		FROM #tempF f
		WHERE h.par_idb = f.par_idb
		)

DELETE #tempS
FROM #tempS s
WHERE NOT EXISTS (
		SELECT *
		FROM #temph h
		WHERE h.par_idb = s.par_idb
		)

-- bug to match the old system
UPDATE #tempF
SET closeUnitValue = 0.0000
FROM #tempF f
WHERE f.closeUnitValue = 1.0000
	AND f.fundcusip LIKE '%loan%'

-- EE sources must be 100% vested
UPDATE s
SET vestedPct = '100'
FROM #tempS s
INNER JOIN rkdb.dbo.pla pla WITH (NOLOCK) ON s.plnCode = pla.pla_code_cid
INNER JOIN rkdb.dbo.source so WITH (NOLOCK) ON (
		s.[Source] = so.sou_si
		AND so.pla_idi = pla.pla_idi
		)
-- where s.[Source] in (1,3,4)
WHERE so.sou_tax_cd < 171 --no change

-- Vesting schedules for participants
-- 1 is primary, 2 is manual override, 4 is alternate schedule, 
-- 3 is pick the better of primary or alternate 
-- 
UPDATE #tempS
SET vestedPct = CASE 
		WHEN ac.acc_vstg_cntrl_ch = '2'
			THEN right('  ' + convert(VARCHAR(3), convert(INT, ac.acc_vstd_rt)), 3)
		ELSE vestedPct
		END
	,vs_sch = CASE 
		WHEN ac.acc_vstg_cntrl_ch IN (
				'3'
				,'4'
				)
			AND so.sou_vest_alt_schd_nid > 0
			THEN so.sou_vest_alt_schd_nid
		WHEN ac.acc_vstg_cntrl_ch = '2'
			THEN - 1
		ELSE so.vessch_nid
		END
	,prior_withdrawal = ac.acc_cuml_dstrb_amt
FROM #tempS t
INNER JOIN rkdb.dbo.account ac WITH (NOLOCK) ON t.par_idb = ac.par_idb
INNER JOIN rkdb.dbo.source so WITH (NOLOCK) ON (
		so.sou_idi = ac.sou_idi
		AND t.[Source] = so.sou_si
		)
INNER JOIN rkdb.dbo.pla pla WITH (NOLOCK) ON so.pla_idi = pla.pla_idi
INNER JOIN #tempH h ON t.par_idb = h.par_idb
WHERE t.vestedPct = ' '
	AND t.plnCode = pla.pla_code_cid

-- historical overrides of vesting info
IF dateadd(dd, + 1, @TDate) < @balDateEnd
BEGIN
	UPDATE #tempS
	SET vestedPct = CASE 
			WHEN acch.acch_vstg_cntrl_ch = '2'
				THEN right('   ' + convert(VARCHAR(3), convert(INT, acch.acch_vstd_rt)), 3)
			ELSE vestedPct
			END
		,vs_sch = CASE 
			WHEN acch.acch_vstg_cntrl_ch IN (
					'3'
					,'4'
					)
				THEN so.sou_vest_alt_schd_nid
			WHEN acch.acch_vstg_cntrl_ch = '2'
				THEN - 1
			ELSE so.vessch_nid
			END
		,prior_withdrawal = acch.acch_cuml_dstrb_amt
	FROM #tempS t
	INNER JOIN rkdb.dbo.accthist acch WITH (NOLOCK) ON t.par_idb = acch.par_idb
	INNER JOIN rkdb.dbo.source so WITH (NOLOCK) ON (
			so.sou_idi = acch.sou_idi
			AND t.[Source] = so.sou_si
			)
	INNER JOIN rkdb.dbo.pla pla WITH (NOLOCK) ON so.pla_idi = pla.pla_idi
	INNER JOIN #tempH h ON t.par_idb = h.par_idb
	WHERE t.vestedPct = ' '
		AND t.plnCode = pla.pla_code_cid
		AND acch.acch_effect_dt = (
			SELECT max(acch2.acch_effect_dt)
			FROM rkdb.dbo.accthist acch2 WITH (NOLOCK)
			WHERE acch2.par_idb = t.par_idb
				AND acch2.acch_effect_dt <= @balDateEnd
				AND acch2.sou_idi = acch.sou_idi
			)
		AND NOT @FDate = @TDate
END

-- set the dates that will be used in the vesting calc
UPDATE #tempS
SET Vesting_Enddate = coalesce(h.dot, @TDate)
	,Vesting_Startdate = CASE 
		WHEN so.sou_vst_mthd_cd = 511
			THEN coalesce(h.doh, h.dop, h.doelig)
		WHEN so.sou_vst_mthd_cd = 512
			THEN coalesce(h.dop, h.doelig)
		WHEN so.sou_vst_mthd_cd = 514
			THEN h.doavest
		ELSE NULL
		END
FROM #tempS s
INNER JOIN #tempH h ON s.par_idb = h.par_idb
INNER JOIN rkdb.dbo.source so WITH (NOLOCK) ON s.[Source] = so.sou_si
INNER JOIN rkdb.dbo.fund fun WITH (NOLOCK) ON h.pla_idi = fun.pla_idi
INNER JOIN rkdb.dbo.soufund sf WITH (NOLOCK) ON (
		fun.fun_idi = sf.fun_idi
		AND sf.sou_idi = so.sou_idi
		)

-- Default vesting schedules for plans if no schedule
-- present for a participant
UPDATE #tempS
SET vs_sch = so.vessch_nid
FROM #tempS t
INNER JOIN rkdb.dbo.part par WITH (NOLOCK) ON t.par_idb = par.par_idb
INNER JOIN rkdb.dbo.source so WITH (NOLOCK) ON t.[Source] = so.sou_si
INNER JOIN rkdb.dbo.fund fun WITH (NOLOCK) ON par.pla_idi = fun.pla_idi
INNER JOIN rkdb.dbo.soufund sf WITH (NOLOCK) ON (
		fun.fun_idi = sf.fun_idi
		AND sf.sou_idi = so.sou_idi
		)
WHERE t.vs_sch = 0

-- immediate vesting
UPDATE #tempS
SET vestedPct = '100'
FROM #tempS s
	,#tempH h
WHERE s.vs_sch = 1
	AND s.par_idb = h.par_idb
	AND NOT h.statusDesc = 'MAN'

-- determine the vesting percentage from the schedule
UPDATE #tempS
SET vestedPct = right('   ' + convert(VARCHAR(3), convert(INT, vs.vess_srt)), 3)
FROM #tempS t
INNER JOIN RKDB.dbo.VestStep vs WITH (NOLOCK) ON vs.vessch_nid = t.vs_sch
WHERE t.vestedPct = ' '
	AND t.Vesting_Startdate IS NOT NULL
	AND t.Vesting_Enddate IS NOT NULL
	AND t.Vesting_Enddate > t.Vesting_StartDate
	AND t.vs_sch > 0
	AND vs.vess_step_si = (
		SELECT max(vs2.vess_step_si)
		FROM RKDB.dbo.VestStep vs2 WITH (NOLOCK)
		WHERE vs2.vessch_nid = t.vs_sch
			AND vs2.vess_incrmnt_si < 100
			AND t.vesting_enddate >= dateadd(mm, vs2.vess_incrmnt_si, t.vesting_startdate)
		)

-- vesting percentage determined by hours worked rather than months of service, current runs
UPDATE #tempS
SET vestedPct = right('   ' + convert(VARCHAR(3), convert(INT, vs.vess_srt)), 3)
FROM #tempS t
INNER JOIN RKDB.dbo.VestStep vs WITH (NOLOCK) ON t.vs_sch = vs.vessch_nid
WHERE t.vestedPct = ' '
	--   and not t.endbal = 0
	AND t.vs_sch > 0
	AND NOT EXISTS (
		SELECT *
		FROM rkdb.dbo.hourshist hh WITH (NOLOCK)
		WHERE hh.par_idb = t.par_idb
			--and hh.houh_ltd_hrs_ct > 0
			--                      and dateadd(dd,+1,hh.houh_effect_dt) >= @toDate)
			AND hh.houh_effect_dt >= @toDate
		)
	AND vs.vess_step_si = (
		SELECT max(vs2.vess_step_si)
		FROM RKDB.dbo.VestStep vs2 WITH (NOLOCK)
		WHERE vs2.vessch_nid = t.vs_sch
			AND (
				vs2.vess_incrmnt_si > 100
				OR t.Vesting_StartDate IS NULL
				)
			AND vs2.vess_incrmnt_si <= (
				SELECT par.par_cuml_hrs_ct
				FROM RKDB.dbo.Part par WITH (NOLOCK)
				WHERE t.par_idb = par.par_idb
				)
		)

-- vesting percentage by hours worked for historical statements (i.e. reruns)
--print 'hourshist'
UPDATE #tempS
SET vestedPct = right('   ' + convert(VARCHAR(3), convert(INT, vs.vess_srt)), 3)
FROM #tempS t
INNER JOIN RKDB.dbo.VestStep vs WITH (NOLOCK) ON t.vs_sch = vs.vessch_nid
WHERE t.vs_sch > 0
	--   and not t.endbal = 0
	AND EXISTS (
		SELECT *
		FROM RKDB.dbo.hourshist hh3 WITH (NOLOCK)
		WHERE hh3.par_idb = t.par_idb
			--and hh3.houh_ltd_hrs_ct > 0
			AND hh3.houh_effect_dt >= @toDate
		)
	AND vs.vess_step_si = (
		SELECT max(vs2.vess_step_si)
		FROM RKDB.dbo.VestStep vs2 WITH (NOLOCK)
		WHERE vs2.vessch_nid = t.vs_sch
			AND (
				vs2.vess_incrmnt_si > 100
				OR t.Vesting_StartDate IS NULL
				)
			AND vs2.vess_incrmnt_si <= (
				SELECT hh.houh_ltd_hrs_ct
				FROM RKDB.dbo.hourshist hh WITH (NOLOCK)
				WHERE t.par_idb = hh.par_idb
					AND hh.houh_effect_dt = (
						SELECT max(hh2.houh_effect_dt)
						FROM RKDB.dbo.hourshist hh2 WITH (NOLOCK)
						WHERE hh.par_idb = hh2.par_idb
							AND dateadd(dd, - 1, hh2.houh_effect_dt) <= @toDate
						)
				)
		)

-- hack for 66.6%
UPDATE #tempS
SET vestedPct = ' 67'
WHERE vestedPct = ' 66'
	AND vs_sch IN (
		15
		,31
		,60
		)

UPDATE s
SET vestedPct = '  0'
FROM #tempS s
INNER JOIN #tempH h ON s.par_idb = h.par_idb
INNER JOIN rkdb.dbo.pla pla WITH (NOLOCK) ON s.plnCode = h.plnCode
INNER JOIN rkdb.dbo.source so WITH (NOLOCK) ON (
		s.[Source] = so.sou_si
		AND so.pla_idi = pla.pla_idi
		)
WHERE h.statusdesc = 'MAN'
	AND so.sou_tax_cd >= 171 --no change

-- hack for vesting percentages that are fractions rather than integers                            
UPDATE #tempS
SET vestedBal = convert(DECIMAL(15, 2), (
			(
				(endBal + prior_withdrawal) * (
					CASE 
						WHEN vs_sch IN (
								15
								,31
								,60
								)
							AND vestedPct = ' 33'
							THEN 33.3
						WHEN vs_sch = 31
							AND vestedPct = ' 67'
							THEN 66.6
						WHEN vs_sch IN (
								15
								,60
								)
							AND vestedPct = ' 67'
							THEN 66.7
						ELSE convert(INT, vestedPct)
						END
					)
				) / 100
			) - prior_withdrawal)
FROM #tempS
WHERE NOT vestedPct = ' '
	AND NOT vestedPct = ' N/A'
	AND NOT vestedPct = '0'
	AND NOT vestedPct = '  0'
	AND NOT vestedPct IS NULL

-- override for negative balances
UPDATE #tempS
SET vestedBal = endBal
WHERE endBal < 0
	AND NOT vestedPct IN (
		'  0'
		,'100'
		)

UPDATE #tempS
SET vestedPct = '  0'
WHERE vestedPct IN (
		'0'
		,' '
		)
	OR vestedPct IS NULL

-- when prior wdl exceeds balance and only partially vested
--  i.e. they got some money they shouldn't have.
UPDATE #tempS
SET vestedBal = 0.0000
WHERE vestedBal < 0.000
	AND NOT endbal < 0.00

-- Calculate ytd contributions.
-- - may not be using a comprehensive list of compliance codes
-- - is be checking the asof date as compliance trans
--   are often backdated to a different year.
CREATE TABLE #tempScontrib (
	pla_code_cid VARCHAR(15) NOT NULL
	,par_idb BIGINT NOT NULL
	,sou_si INT NOT NULL
	,ytdContrib DECIMAL(15, 2)
	)

IF @SSN IS NULL
	AND @pln IS NULL
BEGIN
	INSERT #tempSContrib
	SELECT pla.pla_code_cid
		,tr.par_idb
		,so.sou_si
		,sum(convert(DECIMAL(15, 2), tr.tra_cash_amt * (
					CASE 
						WHEN tr.tran_cd IN (
								5
								,6
								)
							THEN - 1
						ELSE + 1
						END
					))) AS ytdContrib
	--into #tempScontrib
	FROM rkdb.dbo.trans tr WITH (NOLOCK)
	INNER JOIN rkdb.dbo.source so WITH (NOLOCK) ON tr.sou_idi = so.sou_idi
	INNER JOIN rkdb.dbo.pla pla WITH (NOLOCK) ON tr.pla_idi = pla.pla_idi
	INNER JOIN rkdb.dbo.part par WITH (NOLOCK) ON tr.par_idb = par.par_idb
	WHERE tr.tran_cd IN (
			2
			,3
			,5
			,6
			)
		-- regular contrib and some compliance adjs to contrib (ignoring 262 264 for some reason)
		AND (
			tr.tax_cd BETWEEN 200
				AND 210
			OR tr.tax_cd IN (
				266
				,268
				,270
				)
			)
		AND tr.tra_process_dt >= '1/1/' + convert(VARCHAR(4), datepart(yyyy, @Tdate))
		AND (year(tr.tra_asof_dt) = year(@TDate))
		AND (
			pla.pla_code_cid = @pln
			OR @pln IS NULL
			)
		AND EXISTS (
			SELECT *
			FROM #tempH h
			WHERE h.pla_idi = tr.pla_idi
			)
		AND tr.tra_process_dt <= @TDate
		AND NOT tr.tra_memo_in = 1
	GROUP BY pla.pla_code_cid
		,tr.par_idb
		,so.sou_si
	ORDER BY pla.pla_code_cid
		,tr.par_idb
		,so.sou_si
	OPTION (MAXDOP 1)
END

IF @SSN IS NULL
	AND @pln IS NOT NULL
BEGIN
	INSERT #tempSContrib
	SELECT pla.pla_code_cid
		,tr.par_idb
		,so.sou_si
		,sum(convert(DECIMAL(15, 2), tr.tra_cash_amt * (
					CASE 
						WHEN tr.tran_cd IN (
								5
								,6
								)
							THEN - 1
						ELSE + 1
						END
					))) AS ytdContrib
	--into #tempScontrib
	FROM rkdb.dbo.trans tr WITH (NOLOCK)
	INNER JOIN rkdb.dbo.source so WITH (NOLOCK) ON tr.sou_idi = so.sou_idi
	INNER JOIN rkdb.dbo.pla pla WITH (NOLOCK) ON tr.pla_idi = pla.pla_idi
	INNER JOIN rkdb.dbo.part par WITH (NOLOCK) ON tr.par_idb = par.par_idb
	WHERE tr.tran_cd IN (
			2
			,3
			,5
			,6
			)
		AND @pla_idi = tr.pla_idi
		-- regular contrib and some compliance adjs to contrib (ignoring 262 264 for some reason)
		AND (
			tr.tax_cd BETWEEN 200
				AND 210
			OR tr.tax_cd IN (
				266
				,268
				,270
				)
			)
		AND tr.tra_process_dt >= '1/1/' + convert(VARCHAR(4), datepart(yyyy, @Tdate))
		AND (year(tr.tra_asof_dt) = year(@TDate))
		AND (
			pla.pla_code_cid = @pln
			OR @pln IS NULL
			)
		AND EXISTS (
			SELECT *
			FROM #tempH h
			WHERE h.pla_idi = tr.pla_idi
			)
		AND tr.tra_process_dt <= @TDate
		AND NOT tr.tra_memo_in = 1
	GROUP BY pla.pla_code_cid
		,tr.par_idb
		,so.sou_si
	ORDER BY pla.pla_code_cid
		,tr.par_idb
		,so.sou_si
END

IF @SSN IS NOT NULL
BEGIN
	INSERT #tempSContrib
	SELECT pla.pla_code_cid
		,tr.par_idb
		,so.sou_si
		,sum(convert(DECIMAL(15, 2), tr.tra_cash_amt * (
					CASE 
						WHEN tr.tran_cd IN (
								5
								,6
								)
							THEN - 1
						ELSE + 1
						END
					))) AS ytdContrib
	--into #tempScontrib
	FROM rkdb.dbo.trans tr WITH (NOLOCK)
	INNER JOIN rkdb.dbo.source so WITH (NOLOCK) ON tr.sou_idi = so.sou_idi
	INNER JOIN rkdb.dbo.pla pla WITH (NOLOCK) ON tr.pla_idi = pla.pla_idi
	INNER JOIN rkdb.dbo.part par WITH (NOLOCK) ON tr.par_idb = par.par_idb
	WHERE tr.tran_cd IN (
			2
			,3
			,5
			,6
			)
		AND @par_idb = tr.par_idb
		-- regular contrib and some compliance adjs to contrib (ignoring 262 264 for some reason)
		AND (
			tr.tax_cd BETWEEN 200
				AND 210
			OR tr.tax_cd IN (
				266
				,268
				,270
				)
			)
		AND tr.tra_process_dt >= '1/1/' + convert(VARCHAR(4), datepart(yyyy, @Tdate))
		AND (year(tr.tra_asof_dt) = year(@TDate))
		AND (
			pla.pla_code_cid = @pln
			OR @pln IS NULL
			)
		AND EXISTS (
			SELECT *
			FROM #tempH h
			WHERE h.pla_idi = tr.pla_idi
			)
		AND tr.tra_process_dt <= @TDate
		AND NOT tr.tra_memo_in = 1
	GROUP BY pla.pla_code_cid
		,tr.par_idb
		,so.sou_si
	ORDER BY pla.pla_code_cid
		,tr.par_idb
		,so.sou_si
END

UPDATE #tempS
SET ytdContrib = sc.ytdContrib
FROM #tempS t
	,#tempScontrib sc
WHERE t.par_idb = sc.par_idb
	AND t.[Source] = sc.sou_si

-- Add dummy entries to the source table where there is a ytd contrib
--  but no balance.
INSERT INTO #tempS
SELECT cast(NULL AS INT) AS demogid
	,sc.pla_code_cid
	,sc.par_idb
	,sc.sou_si
	,'SOURCE' + convert(VARCHAR(2), sc.sou_si) AS srcAbbrev
	,0.00 AS openBal
	,0.00 AS contrib
	,0.00 AS loanRepay
	,0.00 AS gnloss
	,0.00 AS LoanWd
	,cast(0.00 AS MONEY) AS srcLoans
	,0.00 AS [misc]
	,0.00 AS endBal
	,cast('100' AS CHAR(8)) AS vestedPct
	,cast(0.00 AS MONEY) AS vestedBal
	,sc.ytdContrib
	,0
	,0.00
	,NULL
	,NULL
	,- 999 -- 20131028
FROM #tempScontrib sc
WHERE NOT EXISTS (
		SELECT *
		FROM #tempS t
		WHERE t.par_idb = sc.par_idb
			AND t.[Source] = sc.sou_si
		)

DROP TABLE #tempScontrib

-- Create the Statement loan table
SELECT cast(NULL AS INT) AS demogid
	,t.plnCode
	,t.par_idb
	,l.loa_cid AS loanNbr
	,l.loa_amt AS loanAmt
	,l.loa_orgtn_dt AS origDate
	,l.loa_payoff_dt AS payoffDate
	,l.loa_int_rt AS intRate
	,l.loa_term_mths_qt AS [Term]
	,l.loa_paymnt_amt AS Payment
	,l.loa_principal_paid_amt AS prinPaid
	,l.loa_int_paid_amt AS intPaid
	,(l.loa_amt - l.loa_principal_paid_amt) AS loanBal
INTO #tempL
FROM #tempH t
INNER JOIN RKDB.dbo.Loan l WITH (NOLOCK) ON t.par_idb = l.par_idb
WHERE l.loa_payoff_dt >= @FDate
ORDER BY plnCode
	,t.par_idb
	,loanNbr
	,origDate

CREATE INDEX IX1_tempL ON #tempL (
	plnCode
	,par_idb
	,loanNbr
	)
CREATE NONCLUSTERED INDEX temp_idx2_templ_par_idb
ON  #tempL  ([par_idb],[loanNbr],[payoffDate],[origDate])
INCLUDE ([intPaid])  --VBANDI2

-- calculate loan interest paid adjustments
SELECT lp.par_idb
	,lp.loa_cid
	,sum(lp.loap_repay_fee_amt) AS intPaidOffset
INTO #loanWrk
FROM Rkdb.dbo.loanpay lp WITH (NOLOCK)
WHERE EXISTS (
		SELECT 1
		FROM #tempL l
		WHERE l.par_idb = lp.par_idb
			AND l.loanNbr = lp.loa_cid
		)
	AND lp.loap_paymnt_made_in = 1
	-- and lp.loap_paid_dt is not null
	AND lp.loap_repay_fee_amt > 0.00
GROUP BY lp.par_idb
	,lp.loa_cid

UPDATE #tempL
SET intPaid = l.intPaid - lw.intPaidOffset
FROM #tempL l
	,#loanWrk lw
WHERE l.par_idb = lw.par_idb
	AND l.loanNbr = lw.loa_cid

DROP TABLE #loanWrk

-- Temp fix for bad data
--delete #tempH where plnCode = 'C27'
--delete #tempF where plnCode = 'C27'
--delete #tempS where plnCode = 'C27'
--delete #tempL where plnCode = 'C27'
-- end temp fix
-- Start loading the data into the output tables
-- First, clear out existing data if this is a rerun
DECLARE @minId INT
DECLARE @maxId INT

SELECT @maxId = 0

IF @WriteOutputToTemporaryTables = 'N'
BEGIN
exec @rc = qadcssql.bis.dbo.p_Delete_stmtDemog_Extract
@minId = @minId
,@maxId = @maxId output
,@FDate = @FDate
,@TDate = @TDate
,@stmtPeriodId = @stmtPeriodId
,@pln = @pln
,@ssn = @ssn
SELECT @maxId
IF @RC <> 0
BEGIN 
RAISERROR ('Failed to delete records from stmtDemog qadcssql.bis.dbo.p_Delete_stmtDemog_Extract',16,1)
END 
	--SELECT @minId = coalesce(min(sd.demogid), 0)
	--FROM qadcssql.bis.dbo.stmtdemog sd
	--WHERE sd.Fromdate = @FDate
	--	AND sd.ToDate = @TDate
	--	AND (
	--		@pln IS NULL
	--		OR @pln = sd.plnCode
	--		)
	--	AND (
	--		@SSN IS NULL
	--		OR @SSN = sd.SSNbr
	--		)
	--OPTION (MAXDOP 1)

	--IF @minId > 0
	--BEGIN
	--	DELETE qadcssql.bis.dbo.stmtDemog
	--	FROM qadcssql.bis.dbo.stmtDemog sd
	--	WHERE sd.Fromdate = @FDate
	--		AND sd.ToDate = @TDate
	--		AND (
	--			@pln IS NULL
	--			OR @pln = sd.plnCode
	--			)
	--		AND (
	--			@SSN IS NULL
	--			OR @SSN = sd.SSNbr
	--			)
	--		AND sd.demogid >= @minId
	--		AND stmtPeriodId = @stmtPeriodId -- 201301028 only delete the ones that are for that period
	--	OPTION (MAXDOP 1)
	--END

	---- delete all YTD when a new one is run 20131112
	--IF @stmtPeriodId = 5
	--	DELETE
	--	FROM qadcssql.bis.dbo.stmtDemog
	--	WHERE stmtPeriodId = 5

	----and toDate >= DATEADD(DAY,-10,CURRENT_TIMESTAMP) -- might need to add this for performance 
	--SELECT @maxId = coalesce(max(demogid), 0)
	--FROM qadcssql.bis.dbo.stmtDemog
END

-- Hack so that bad date info in SRT does not knock out the smalldatetime
--  columns in stmtdemog
--
UPDATE x
SET dob = NULL
FROM #tempH x
WHERE x.dob IS NOT NULL
	AND year(x.dob) > 2077

UPDATE x
SET doh = NULL
FROM #tempH x
WHERE x.doh IS NOT NULL
	AND year(x.doh) > 2077

UPDATE x
SET dop = NULL
FROM #tempH x
WHERE x.dop IS NOT NULL
	AND year(x.dop) > 2077

UPDATE x
SET dot = NULL
FROM #tempH x
WHERE x.dot IS NOT NULL
	AND year(x.dot) > 2077

-- next two fields are defined as not null, so insert a junk data
UPDATE x
SET payoffDate = '12/31/2077'
FROM #tempL x
WHERE x.payoffDate IS NOT NULL
	AND year(x.payOffDate) > 2077

UPDATE x
SET origDate = '12/31/2077'
FROM #tempL x
WHERE x.origDate IS NOT NULL
	AND year(x.origDate) > 2077

-- add the header records
IF @WriteOutputToTemporaryTables = 'N'
BEGIN
	INSERT INTO qadcssql.bis.dbo.stmtDemog (
		plnCode
		,ssNbr
		,toDate
		,fromDate
		,partName
		,plnName
		,divNbr
		,shellNbr
		,addrLine1
		,addrLine2
		,addrLine3
		,dob
		,doh
		,dop
		,statusCode
		,statusDesc
		,alloc1
		,alloc2
		,alloc3
		,alloc4
		,alloc5
		,loanBal
		,pre87Amt
		,eeComp
		,dfPctEEPre
		,dfPctEEAft
		,dfPctERMatch
		,dfPctPS
		,partLastName
		,dot
		,stmtPeriodId -- 20131028
		)
	SELECT plnCode
		,ssNbr
		,toDate
		,fromDate
		,partName
		,plnName
		,divNbr
		,shellNbr
		,addrLine1
		,addrLine2
		,addrLine3
		,dob
		,doh
		,dop
		,statusCode
		,statusDesc
		,alloc1
		,alloc2
		,alloc3
		,alloc4
		,alloc5
		,loanBal
		,pre87Amt
		,eeComp
		,dfPctEEPre
		,dfPctEEAft
		,dfPctERMatch
		,dfPctPS
		,partLastName
		,dot
		,@stmtPeriodId -- 20131028
	FROM #tempH
	ORDER BY plnCode
		,ssNbr
END
ELSE
BEGIN
	INSERT INTO #tempstmtDemog (
		plnCode
		,ssNbr
		,toDate
		,fromDate
		,partName
		,plnName
		,divNbr
		,shellNbr
		,addrLine1
		,addrLine2
		,addrLine3
		,dob
		,doh
		,dop
		,statusCode
		,statusDesc
		,alloc1
		,alloc2
		,alloc3
		,alloc4
		,alloc5
		,loanBal
		,pre87Amt
		,eeComp
		,dfPctEEPre
		,dfPctEEAft
		,dfPctERMatch
		,dfPctPS
		,partLastName
		,dot
		)
	SELECT plnCode
		,ssNbr
		,toDate
		,fromDate
		,partName
		,plnName
		,divNbr
		,shellNbr
		,addrLine1
		,addrLine2
		,addrLine3
		,dob
		,doh
		,dop
		,statusCode
		,statusDesc
		,alloc1
		,alloc2
		,alloc3
		,alloc4
		,alloc5
		,loanBal
		,pre87Amt
		,eeComp
		,dfPctEEPre
		,dfPctEEAft
		,dfPctERMatch
		,dfPctPS
		,partLastName
		,dot
	FROM #tempH
	ORDER BY plnCode
		,ssNbr
END

-- add the output header's identity column data to the temp header table
IF @WriteOutputToTemporaryTables = 'N'
BEGIN
	UPDATE #tempH
	SET demogid = sd.demogid
	FROM #tempH h
		,qadcssql.bis.dbo.stmtDemog sd
	WHERE sd.plnCode = h.plnCode
		AND sd.SSNbr = h.SSNbr
		AND sd.Fromdate = @FDate
		AND sd.ToDate = @TDate
		AND sd.demogid > @maxID
END
ELSE
BEGIN
	UPDATE #tempH
	SET demogid = sd.demogid
	FROM #tempH h
		,#tempstmtDemog sd
	WHERE sd.plnCode = h.plnCode
		AND sd.SSNbr = h.SSNbr
		AND sd.Fromdate = @FDate
		AND sd.ToDate = @TDate
		AND sd.demogid > @maxID
END

-- update the data with the output header's identity info
UPDATE #tempF
SET demogid = h.demogid
FROM #tempF t
	,#tempH h
WHERE t.par_idb = h.par_idb

DELETE #tempS
WHERE openBal = 0.00
	AND endBal = 0.00
	AND ytdContrib = 0.00
	AND gnloss = 0.00
	AND loanWd = 0.00
	AND misc = 0.00
	AND contrib = 0.00
	AND loanrepay = 0.00

UPDATE #tempS
SET demogid = h.demogid
FROM #tempS t
	,#tempH h
WHERE t.par_idb = h.par_idb

UPDATE #tempL
SET demogid = h.demogid
FROM #tempL t
	,#tempH h
WHERE t.par_idb = h.par_idb
CREATE NONCLUSTERED INDEX #tempF_demogid  --VBANDI 04142015
ON  #tempL  ([demogid])    --VBANDI 04142015
-- clear out junk (just in case)
DELETE #tempF
WHERE demogid IS NULL
CREATE NONCLUSTERED INDEX #temps_demogid  --VBANDI 04142015
ON  #tempL  ([demogid])    --VBANDI 04142015
DELETE #tempS
WHERE demogid IS NULL
CREATE NONCLUSTERED INDEX #tempL_demogid  --VBANDI 04142015
ON  #tempL  ([demogid])    --VBANDI 04142015

DELETE #tempL
WHERE demogid IS NULL

--SELECT 3331,* FROM #tempF RETURN 
-- add total records by participant to the fund and source tables
INSERT INTO #tempF
SELECT demogId
	,plnCode
	,par_idb
	,NULL
	,'TOTAL'
	,NULL -- 20110113 inv_idi
	,NULL -- 20110113 ipm_nid
	,sum(openBal)
	,sum(OpenUnits)
	,sum(eeCont)
	,sum(erCont)
	,sum(gnLoss)
	,sum(loanRepay)
	,sum(fundTransfers)
	,sum(loanWd)
	,sum(misc)
	,sum(endBal)
	,sum(endUnits)
	,NULL
	,NULL
	,NULL
	,NULL
	,NULL
	,0.0000
	,0.0000
FROM #tempF
GROUP BY demogid
	,plnCode
	,par_idb

INSERT INTO #tempS
SELECT demogId
	,plnCode
	,par_idb
	,99
	,'TOTAL'
	,sum(openBal)
	,sum(contrib)
	,sum(loanRepay)
	,sum(gnLoss)
	,sum(loanWd)
	,sum(srcLoans)
	,sum(misc)
	,sum(endBal)
	,' N/A'
	,sum(vestedBal)
	,sum(ytdContrib)
	,0
	,0.00
	,NULL
	,NULL
	,- 999 -- 20131028
FROM #tempS
GROUP BY demogid
	,plnCode
	,par_idb

-- add a total record for the IPM 
-- add total records by participant to the fund and source tables
INSERT INTO #tempF
SELECT demogId
	,plnCode
	,par_idb
	,NULL
	--,'FUND' + substring(fundAbbrev,4,charindex('_', fundAbbrev)-4)
	,'FUND' + substring(fundAbbrev, 5, LEN(fundAbbrev) - charindex('_', fundAbbrev))
	,NULL -- inv_idi
	,ipm_nid
	,sum(openBal)
	,sum(OpenUnits)
	,sum(eeCont)
	,sum(erCont)
	,sum(gnLoss)
	,sum(loanRepay)
	,sum(fundTransfers)
	,sum(loanWd)
	,sum(misc)
	,sum(endBal)
	,sum(endUnits)
	,max(fundeepct) [fundeepct] -- all will be the same so max is ok
	,max(funderpct) [funderpct]
	,max(fundmppct) [fundmppct]
	,max(fundropct) [fundropct]
	,max(fundpspct) [fundpspct]
	,0.0000
	,0.0000
FROM #tempF
WHERE ipm_nid IS NOT NULL
GROUP BY demogid
	,plnCode
	,par_idb
	,ipm_nid
	,substring(fundAbbrev, 5, LEN(fundAbbrev) - charindex('_', fundAbbrev))

-- add the data to the output fund table
--select * from #tempF
--where gnLoss is null
IF @WriteOutputToTemporaryTables = 'N'
BEGIN
	INSERT INTO qadcssql.bis.dbo.stmtFund (
		demogId
		,fundAbbrev
		,openBal
		,eeCont
		,erCont
		,gnLoss
		,loanRepay
		,fundTransfers
		,loanWd
		,misc
		,endBal
		,endUnits
		,fundeepct
		,funderpct
		,fundmppct
		,fundropct
		,fundpspct
		,openUnits
		,openUnitValue
		,closeUnitValue
		,inv_idi
		,ipm_nid
		)
	SELECT demogId
		,fundAbbrev
		,openBal
		,eeCont
		,erCont
		,gnLoss
		,loanRepay
		,fundTransfers
		,loanWd
		,misc
		,endBal
		,endUnits
		,fundeepct
		,funderpct
		,fundmppct
		,fundropct
		,fundpspct
		,openUnits
		,openUnitValue
		,closeUnitValue
		,inv_idi
		,ipm_nid
	FROM #tempF
	ORDER BY demogid
		,FundAbbrev
END
ELSE
BEGIN
	INSERT INTO #tempstmtFund (
		demogId
		,fundAbbrev
		,openBal
		,eeCont
		,erCont
		,gnLoss
		,loanRepay
		,fundTransfers
		,loanWd
		,misc
		,endBal
		,endUnits
		,fundeepct
		,funderpct
		,fundmppct
		,fundropct
		,fundpspct
		,openUnits
		,openUnitValue
		,closeUnitValue
		)
	SELECT demogId
		,fundAbbrev
		,openBal
		,eeCont
		,erCont
		,gnLoss
		,loanRepay
		,fundTransfers
		,loanWd
		,misc
		,endBal
		,endUnits
		,fundeepct
		,funderpct
		,fundmppct
		,fundropct
		,fundpspct
		,openUnits
		,openUnitValue
		,closeUnitValue
	FROM #tempF
	ORDER BY demogid
		,FundAbbrev
END

-- add the data to the output source table
IF @WriteOutputToTemporaryTables = 'N'
BEGIN
	INSERT INTO qadcssql.bis.dbo.stmtSrc (
		demogId
		,srcAbbrev
		,openBal
		,contrib
		,loanRepay
		,gnLoss
		,loanWd
		,srcLoans
		,misc
		,endBal
		,vestedPct
		,vestedBal
		,ytdContrib
		,sou_idi
		)
	SELECT demogId
		,srcAbbrev
		,openBal
		,contrib
		,loanRepay
		,gnLoss
		,loanWd
		,srcLoans
		,misc
		,endBal
		,vestedPct
		,vestedBal
		,ytdContrib
		,sou_idi
	FROM #tempS
	ORDER BY demogid
		,srcAbbrev
END
ELSE
BEGIN
	INSERT INTO #tempstmtSrc (
		demogId
		,srcAbbrev
		,openBal
		,contrib
		,loanRepay
		,gnLoss
		,loanWd
		,srcLoans
		,misc
		,endBal
		,vestedPct
		,vestedBal
		,ytdContrib
		)
	SELECT demogId
		,srcAbbrev
		,openBal
		,contrib
		,loanRepay
		,gnLoss
		,loanWd
		,srcLoans
		,misc
		,endBal
		,vestedPct
		,vestedBal
		,ytdContrib
	FROM #tempS
	ORDER BY demogid
		,srcAbbrev
END

UPDATE #tempL
SET origDate = dateadd(dd, datediff(dd, 0, origDate), 0) -- on 20140117 we saw loans show up with time in the origination date this caused the job to bomb

-- add the data to the output loan table
IF @WriteOutputToTemporaryTables = 'N'
BEGIN
	INSERT INTO qadcssql.bis.dbo.stmtLoan (
		demogId
		,loanNbr
		,loanAmt
		,origDate
		,payoffDate
		,intRate
		,Term
		,Payment
		,prinPaid
		,intPaid
		,loanBal
		)
	SELECT demogId
		,loanNbr
		,loanAmt
		,origDate
		,payoffDate
		,intRate
		,Term
		,Payment
		,prinPaid
		,intPaid
		,loanBal
	FROM #tempL
	ORDER BY demogid
		,loanNbr
END
ELSE
BEGIN  --VBANDI This is irrelavent 
	INSERT INTO #tempstmtLoan (
		demogId
		,loanNbr
		,loanAmt
		,origDate
		,payoffDate
		,intRate
		,Term
		,Payment
		,prinPaid
		,intPaid
		,loanBal
		)
	SELECT demogId
		,loanNbr
		,loanAmt
		,origDate
		,payoffDate
		,intRate
		,Term
		,Payment
		,prinPaid
		,intPaid
		,loanBal
	FROM #tempL
	ORDER BY demogid
		,loanNbr
END

-- Clean up                  
DROP TABLE #tempH

DROP TABLE #tempF

DROP TABLE #tempS

DROP TABLE #tempL

UPDATE dbo.stmtExtractLog
SET endDt = CURRENT_TIMESTAMP
WHERE runDt = @runDtm

