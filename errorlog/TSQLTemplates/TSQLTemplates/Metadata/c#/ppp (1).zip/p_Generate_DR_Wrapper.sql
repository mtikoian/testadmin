CREATE PROCEDURE dbo.p_Generate_DR_Wrapper
AS
--linked servers,server logins and configuration settings,server alias

--
BEGIN
	DECLARE @return_value INT;
	DECLARE @DR_Dir VARCHAR(100);
	DECLARE @Today_DR_Dir VARCHAR(100);
	DECLARE @DR_MailProfile_Dir VARCHAR(100);
	DECLARE @DR_Permissions_Dir VARCHAR(100);
	DECLARE @DR_SQLJobs_Dir VARCHAR(100);
	DECLARE @DR_Report_Dir VARCHAR(100);
	DECLARE @folder_exists INT;
	-- Error message vars
	DECLARE @ErrorMessage NVARCHAR(4000);
	DECLARE @ErrorNumber INT;
	DECLARE @ErrorSeverity INT;
	DECLARE @ErrorState INT;
	DECLARE @ErrorLine INT;
	DECLARE @ErrorProcedure NVARCHAR(200);
	DECLARE @file_results TABLE (
		file_exists INT
		,file_is_a_directory INT
		,parent_directory_exists INT
		);

	SET @return_value = 0;
	SET @folder_exists = 0;
	SET @DR_Dir = '\\fs1\technology\SQLDR\'
	SET @Today_DR_Dir = @DR_Dir + convert(VARCHAR, getdate(), 112) + '\';
	SET @DR_MailProfile_Dir = @Today_DR_Dir + 'SQLMailProfiles'
	SET @DR_Permissions_Dir = @Today_DR_Dir + 'DatabasePermissions'
	SET @DR_SQLJobs_Dir = @Today_DR_Dir + 'SQLJobs'
	SET @DR_Report_Dir = @Today_DR_Dir + 'DRReport'

	--SELECT @Today_DR_Dir ,substring(@Today_DR_Dir,0,len(@Today_DR_Dir))
	BEGIN TRY
		--DIR 1 
		INSERT INTO @file_results (
			file_exists
			,file_is_a_directory
			,parent_directory_exists
			)
		EXEC master.dbo.xp_fileexist @Today_DR_Dir

		SELECT @folder_exists = file_is_a_directory
		FROM @file_results

		--script to create directory		
		IF @folder_exists = 0
		BEGIN
			PRINT 'Directory is not exists, creating new one'

			EXECUTE master.dbo.xp_create_subdir @Today_DR_Dir

			PRINT @Today_DR_Dir + 'created on' + substring(@Today_DR_Dir, 0, len(@Today_DR_Dir))
		END
		ELSE
			PRINT 'Directory already exists'

		--DIR 2
		DELETE
		FROM @file_results

		SET @folder_exists = 0

		INSERT INTO @file_results (
			file_exists
			,file_is_a_directory
			,parent_directory_exists
			)
		EXEC master.dbo.xp_fileexist @DR_MailProfile_Dir

		SELECT @folder_exists = file_is_a_directory
		FROM @file_results

		--script to create directory		
		IF @folder_exists = 0
		BEGIN
			PRINT 'Directory is not exists, creating new one'

			EXECUTE master.dbo.xp_create_subdir @DR_MailProfile_Dir

			PRINT @DR_MailProfile_Dir + 'created on' + substring(@Today_DR_Dir, 0, len(@Today_DR_Dir))
		END
		ELSE
			PRINT 'Directory already exists'

		--DIR 3	
		DELETE
		FROM @file_results

		SET @folder_exists = 0

		INSERT INTO @file_results (
			file_exists
			,file_is_a_directory
			,parent_directory_exists
			)
		EXEC master.dbo.xp_fileexist @DR_Permissions_Dir

		SELECT @folder_exists = file_is_a_directory
		FROM @file_results

		--script to create directory		
		IF @folder_exists = 0
		BEGIN
			PRINT 'Directory is not exists, creating new one'

			EXECUTE master.dbo.xp_create_subdir @DR_Permissions_Dir

			PRINT @DR_Permissions_Dir + 'created on' + substring(@Today_DR_Dir, 0, len(@Today_DR_Dir))
		END
		ELSE
			PRINT 'Directory already exists'

		--DIR 4
		DELETE
		FROM @file_results

		SET @folder_exists = 0

		INSERT INTO @file_results (
			file_exists
			,file_is_a_directory
			,parent_directory_exists
			)
		EXEC master.dbo.xp_fileexist @DR_SQLJobs_Dir

		SELECT @folder_exists = file_is_a_directory
		FROM @file_results

		--script to create directory		
		IF @folder_exists = 0
		BEGIN
			PRINT 'Directory is not exists, creating new one'

			EXECUTE master.dbo.xp_create_subdir @DR_SQLJobs_Dir

			PRINT @DR_SQLJobs_Dir + 'created on' + substring(@Today_DR_Dir, 0, len(@Today_DR_Dir))
		END
		ELSE
			PRINT 'Directory already exists'

		--DIR 4
		DELETE
		FROM @file_results

		SET @folder_exists = 0

		INSERT INTO @file_results (
			file_exists
			,file_is_a_directory
			,parent_directory_exists
			)
		EXEC master.dbo.xp_fileexist @DR_Report_Dir

		SELECT @folder_exists = file_is_a_directory
		FROM @file_results

		--script to create directory		
		IF @folder_exists = 0
		BEGIN
			PRINT 'Directory is not exists, creating new one'

			EXECUTE master.dbo.xp_create_subdir @DR_Report_Dir

			PRINT @DR_Report_Dir + 'created on' + substring(@Today_DR_Dir, 0, len(@Today_DR_Dir))
		END
		ELSE
			PRINT 'Directory already exists'

		EXEC @return_value = dbo.GenerateMailProfilesReport @BuildPath = @DR_MailProfile_Dir

		IF @return_value <> 0
		BEGIN
			RAISERROR (
					'Failed while generating MailProfiles '
					,16
					,1
					)

			RETURN
		END

		EXEC @return_value = dbo.GenerateSQLjobinfo @BuildPath = @DR_SQLJobs_Dir

		IF @return_value <> 0
		BEGIN
			RAISERROR (
					'Failed while generating SQLjobinfo '
					,16
					,1
					)

			RETURN
		END

		EXEC @return_value = dbo.GenerateUserpermissionsinfo @BuildPath = @DR_Permissions_Dir

		IF @return_value <> 0
		BEGIN
			RAISERROR (
					'Failed while generating Userpermissionsinfo '
					,16
					,1
					)

			RETURN
		END

		EXEC @return_value = dbo.GenerateDRReport @BuildPath = @DR_Report_Dir

		IF @return_value <> 0
		BEGIN
			RAISERROR (
					'Failed while generating DRReport '
					,16
					,1
					)

			RETURN
		END
	END TRY

	BEGIN CATCH
		SET @ErrorNumber = ERROR_NUMBER();
		SET @ErrorSeverity = ERROR_SEVERITY();
		SET @ErrorState = ERROR_STATE();
		SET @ErrorLine = ERROR_LINE();
		SET @ErrorProcedure = ISNULL(ERROR_PROCEDURE(), '-');

		RAISERROR (
				@ErrorMessage
				,@ErrorSeverity
				,1
				,@ErrorNumber	-- parameter: original error number.
				,@ErrorSeverity	-- parameter: original error severity.
				,@ErrorState		-- parameter: original error state.
				,@ErrorProcedure	-- parameter: original error procedure name.
				,@ErrorLine -- parameter: original error line number.
				);
	END CATCH;
END;

