select 
 distinct 
 name,
 database_name
from msdb..sysjobs sj
INNER JOIN msdb..sysjobsteps sjt on sj.job_id = sjt.job_id
where database_name  = 'bis'