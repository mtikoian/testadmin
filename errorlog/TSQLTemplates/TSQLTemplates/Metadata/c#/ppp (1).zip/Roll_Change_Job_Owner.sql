--Change Job owner
DECLARE @ScriptList TABLE ( ScriptType VARCHAR(20), Script VARCHAR(MAX))
--rollback scripts
INSERT INTO @ScriptList
SELECT
          'rollback' as ScriptType
        , '-- Revert job: [' + j.name + '] to owned by: ['+ sl.name  + ']' + CHAR(13) + CHAR(10)
        + 'EXEC msdb..sp_update_job @job_id = ''' + CONVERT(VARCHAR(36), j.job_id) + ''''
        + ', @owner_login_name = ''' + sl.name + '''' as Script
FROM msdb.dbo.sysjobs j
LEFT OUTER JOIN sys.syslogins sl
        ON j.owner_sid = sl.sid
WHERE j.enabled = 1  AND sl.name <> SUSER_SNAME(0x01);
SELECT Script FROM @scriptlist WHERE ScriptType = 'rollback';



