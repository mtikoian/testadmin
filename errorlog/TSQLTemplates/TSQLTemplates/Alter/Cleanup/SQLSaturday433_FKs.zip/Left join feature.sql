--� 2014 | ByrdNest Consulting

USE AdventureWorks2012
GO

SELECT * 
	FROM sales.customer c 
	WHERE NOT EXISTS (SELECT * 
						FROM [Sales].[SalesOrderHeader] soh 
						WHERE soh.CustomerID = c.CustomerID)
--1,2,3,4,5


SELECT c.customerid, COUNT(*) NumOfOrders
	FROM Sales.Customer c
	LEFT JOIN [Sales].[SalesOrderHeader] soh
	  ON soh.customerid = c.customerid
	GROUP BY c.customerid
	ORDER BY c.customerid
--oops, wrong answer


--try again
SELECT c.CustomerID, count(soh.CustomerID) NumOfOrders
	FROM Sales.Customer c
	LEFT JOIN Sales.[SalesOrderHeader] soh
	  ON soh.CustomerID = c.CustomerID
	GROUP BY c.CustomerID
	ORDER BY c.CustomerID
--need to be careful with left (right) joins -- I've gotten into trouble before with them.
--also include where criteria in ON clause for Left/Right Joins
