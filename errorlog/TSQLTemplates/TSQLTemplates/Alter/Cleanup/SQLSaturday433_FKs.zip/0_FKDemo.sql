--� 2014 | ByrdNest Consulting

/*  Don't forget Zoomit  */

USE master
GO

IF EXISTS (SELECT * From sys.sysdatabases WHERE name = 'FK_Demo')
	ALTER DATABASE [FK_Demo] SET  SINGLE_USER WITH ROLLBACK IMMEDIATE -- Close existing connections
GO
USE [master]
GO
IF EXISTS (SELECT * From sys.sysdatabases WHERE name = 'FK_Demo')
	DROP DATABASE FK_Demo
GO

CREATE DATABASE FK_Demo
 CONTAINMENT = NONE
 ON  PRIMARY 
( NAME = N'FK_Demo', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL11.MSSQLSERVER\MSSQL\DATA\FK_Demo.mdf' , SIZE = 4072KB , MAXSIZE = UNLIMITED, FILEGROWTH = 1024KB )
 LOG ON 
( NAME = N'FK_Demo_log', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL11.MSSQLSERVER\MSSQL\DATA\FK_Demo_log.ldf' , SIZE = 1024KB , MAXSIZE = 2048GB , FILEGROWTH = 10%)
GO

USE FK_Demo
Go

/*
IF OBJECT_ID(N'Person') IS NOT NULL DROP TABLE dbo.Person
IF OBJECT_ID(N'PersonAttribute') IS NOT NULL DROP TABLE dbo.PersonAttribute
IF OBJECT_ID(N'Attribute') IS NOT NULL DROP TABLE dbo.Attribute
GO
*/
CREATE TABLE dbo.Person(
	PersonID int IDENTITY(1,1) NOT NULL,
	LastName varchar(50) NOT NULL,
	FirstName varchar(50) NULL,
	CONSTRAINT PK_Person PRIMARY KEY (PersonID) )
GO

CREATE TABLE dbo.Attribute (
	AttributeID				INT IDENTITY(1,1) NOT NULL,
	[Description]			VARCHAR(50) NOT NULL,
	CONSTRAINT PK_Attribute PRIMARY KEY (AttributeID) )

CREATE TABLE dbo.PersonAttribute (
	PersonID				INT NOT NULL,
	AttributeID				INT NOT NULL,
	AttributeValue			VARCHAR(50) NOT NULL,
 CONSTRAINT PK_PersonAttribute PRIMARY KEY CLUSTERED (PersonID ASC,AttributeID ASC) )
GO
ALTER TABLE PersonAttribute WITH CHECK ADD
 CONSTRAINT FK_PersonAttribute_Attribute FOREIGN KEY (AttributeID) REFERENCES dbo.Attribute (AttributeID)
ALTER TABLE PersonAttribute WITH CHECK ADD
 CONSTRAINT FK_PersonAttribute_Person FOREIGN KEY (PersonID) REFERENCES dbo.Person (PersonID)
GO

--turn on query plan (CTRL + M)
--look at SSMS


--add data to tables
--Frequently child table FK columns are nullable -- variety of reasons (not applicable, data not available, etc.)
--Best practice is to make the column not nullable and add following rows (first two) to the parent table:
--frequently use in DWs, but also applicable for OLTP systems
SET IDENTITY_INSERT dbo.Attribute ON;
GO
INSERT dbo.Attribute (AttributeID,[Description])
	SELECT -1,'Not Available' UNION ALL		--
	SELECT 0,'Unknown' UNION ALL
	SELECT 1,'Address' UNION ALL
	SELECT 2,'City' UNION ALL
	SELECT 3,'State' UNION ALL
	SELECT 4,'Zip' UNION ALL
	SELECT 5,'Phone' UNION ALL
	SELECT 6,'Email' UNION ALL
	SELECT 7,'Gender';
GO
SET IDENTITY_INSERT dbo.Attribute OFF;
GO
--SELECT * from dbo.Attribute


--Populate dbo.Person and dbo.PersonAttribute

SET IDENTITY_INSERT dbo.Person ON;
GO
INSERT dbo.Person (PersonID,LastName,FirstName)
	SELECT 1,'Doe','John' UNION ALL
	SELECT 3,'Smith','Jim' UNION ALL
	SELECT 2,'Jones','Mary';
GO
SET IDENTITY_INSERT dbo.Person OFF;
GO

--SELECT * from dbo.Person

INSERT dbo.PersonAttribute (PersonID,AttributeID,AttributeValue)
	SELECT 1,1,'123 Easy St' UNION ALL
	SELECT 1,2,'Austin' UNION ALL
	SELECT 1,3,'TX' UNION ALL
	SELECT 1,4,'78746' UNION ALL
	SELECT 1,7,'F' UNION ALL
	SELECT 2,1,'456 Easy St' UNION ALL
	SELECT 2,2,'Austin' UNION ALL
	SELECT 2,3,'TX' UNION ALL
	SELECT 2,4,'78758' UNION ALL
	SELECT 2,5,'512-388-1234' UNION ALL
	SELECT 3,1,'789 Easy St' UNION ALL
	SELECT 3,2,'Sunrise Beach' UNION ALL
	SELECT 3,3,'TX' UNION ALL
	SELECT 3,4,'78643-9308';
GO

select * from dbo.Person
select * from dbo.Attribute
select * from dbo.PersonAttribute
GO

--bad FK reference; check estimated execution plan
UPDATE dbo.PersonAttribute
	SET AttributeID = 10
	WHERE PersonID = 3 
	  AND AttributeID = 4
--OR
INSERT dbo.PersonAttribute (PersonID,AttributeID,AttributeValue)
	SELECT 1,10,'123 Bad Data'
GO

--example of trying to delete a row in the parent table
DELETE dbo.Attribute
	WHERE [Description] = 'State';
GO

--example of when not having a FK leads to issues.

SELECT p.FirstName, p.LastName, a.[Description], pa.AttributeValue
	FROM dbo.Person p
	JOIN dbo.PersonAttribute pa
	  ON pa.PersonID = p.PersonID
	JOIN dbo.Attribute a
	  ON a.AttributeID = pa.AttributeID
	WHERE p.LastName = 'Jones'
--note there are 5 rows in result set
GO

--now disable PersonAttribute FK on AttributeID (we will go over syntax a little later)
ALTER TABLE dbo.PersonAttribute NOCHECK CONSTRAINT FK_PersonAttribute_Attribute
GO

--now suppose someone accidently deletes the State Attribute while the FK is disabled.
DELETE dbo.Attribute
	WHERE [Description] = 'State';
GO

--now rerun same query above
SELECT p.FirstName, p.LastName, a.[Description], pa.AttributeValue
	FROM dbo.Person p
	JOIN dbo.PersonAttribute pa
	  ON pa.PersonID = p.PersonID
	JOIN dbo.Attribute a
	  ON a.AttributeID = pa.AttributeID
	WHERE p.LastName = 'Jones'
--ouch!  We lost a row in the result set!

--reset FK_Demo for next set of demo scripts
USE master
GO

IF EXISTS (SELECT * From sys.sysdatabases WHERE name = 'FK_Demo')
	ALTER DATABASE [FK_Demo] SET  SINGLE_USER WITH ROLLBACK IMMEDIATE -- Close existing connections
GO
USE [master]
GO
IF EXISTS (SELECT * From sys.sysdatabases WHERE name = 'FK_Demo')
	DROP DATABASE FK_Demo
GO

CREATE DATABASE FK_Demo
 CONTAINMENT = NONE
 ON  PRIMARY 
( NAME = N'FK_Demo', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL11.MSSQLSERVER\MSSQL\DATA\FK_Demo.mdf' , SIZE = 4072KB , MAXSIZE = UNLIMITED, FILEGROWTH = 1024KB )
 LOG ON 
( NAME = N'FK_Demo_log', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL11.MSSQLSERVER\MSSQL\DATA\FK_Demo_log.ldf' , SIZE = 1024KB , MAXSIZE = 2048GB , FILEGROWTH = 10%)
GO

USE FK_Demo
Go

/*
IF OBJECT_ID(N'Person') IS NOT NULL DROP TABLE dbo.Person
IF OBJECT_ID(N'PersonAttribute') IS NOT NULL DROP TABLE dbo.PersonAttribute
IF OBJECT_ID(N'Attribute') IS NOT NULL DROP TABLE dbo.Attribute
GO
*/
CREATE TABLE dbo.Person(
	PersonID int IDENTITY(1,1) NOT NULL,
	LastName varchar(50) NOT NULL,
	FirstName varchar(50) NULL,
	CONSTRAINT PK_Person PRIMARY KEY (PersonID) )
GO

CREATE TABLE dbo.Attribute (
	AttributeID				INT IDENTITY(1,1) NOT NULL,
	[Description]			VARCHAR(50) NOT NULL,
	CONSTRAINT PK_Attribute PRIMARY KEY (AttributeID) )

CREATE TABLE dbo.PersonAttribute (
	PersonID				INT NOT NULL,
	AttributeID				INT NOT NULL,
	AttributeValue			VARCHAR(50) NOT NULL,
 CONSTRAINT PK_PersonAttribute PRIMARY KEY CLUSTERED (PersonID ASC,AttributeID ASC) )
GO
ALTER TABLE PersonAttribute WITH CHECK ADD
 CONSTRAINT FK_PersonAttribute_Attribute FOREIGN KEY (AttributeID) REFERENCES dbo.Attribute (AttributeID)
ALTER TABLE PersonAttribute WITH CHECK ADD
 CONSTRAINT FK_PersonAttribute_Person FOREIGN KEY (PersonID) REFERENCES dbo.Person (PersonID)
GO

--turn on query plan (CTRL + M)
--look at SSMS


--add data to tables
--Frequently child table FK columns are nullable -- variety of reasons (not applicable, data not available, etc.)
--Best practice is to make the column not nullable and add following rows (first two) to the parent table:
--frequently use in DWs, but also applicable for OLTP systems
SET IDENTITY_INSERT dbo.Attribute ON;
GO
INSERT dbo.Attribute (AttributeID,[Description])
	SELECT -1,'Not Available' UNION ALL		--
	SELECT 0,'Unknown' UNION ALL
	SELECT 1,'Address' UNION ALL
	SELECT 2,'City' UNION ALL
	SELECT 3,'State' UNION ALL
	SELECT 4,'Zip' UNION ALL
	SELECT 5,'Phone' UNION ALL
	SELECT 6,'Email' UNION ALL
	SELECT 7,'Gender';
GO
SET IDENTITY_INSERT dbo.Attribute OFF;
GO
--SELECT * from dbo.Attribute


--Populate dbo.Person and dbo.PersonAttribute

SET IDENTITY_INSERT dbo.Person ON;
GO
INSERT dbo.Person (PersonID,LastName,FirstName)
	SELECT 1,'Doe','John' UNION ALL
	SELECT 3,'Smith','Jim' UNION ALL
	SELECT 2,'Jones','Mary';
GO
SET IDENTITY_INSERT dbo.Person OFF;
GO

--SELECT * from dbo.Person

INSERT dbo.PersonAttribute (PersonID,AttributeID,AttributeValue)
	SELECT 1,1,'123 Easy St' UNION ALL
	SELECT 1,2,'Austin' UNION ALL
	SELECT 1,3,'TX' UNION ALL
	SELECT 1,4,'78746' UNION ALL
	SELECT 1,7,'F' UNION ALL
	SELECT 2,1,'456 Easy St' UNION ALL
	SELECT 2,2,'Austin' UNION ALL
	SELECT 2,3,'TX' UNION ALL
	SELECT 2,4,'78758' UNION ALL
	SELECT 2,5,'512-388-1234' UNION ALL
	SELECT 3,1,'789 Easy St' UNION ALL
	SELECT 3,2,'Sunrise Beach' UNION ALL
	SELECT 3,3,'TX' UNION ALL
	SELECT 3,4,'78643-9308';
GO
