--� 2014 | ByrdNest Consulting

USE AdventureWorks2012
GO

--turn on Include Actual Execution Plan (Ctrl - M)

--create new FK linking SpecialOfferId to Sales.SalesOrderDetail
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'Sales.FK_SalesOrderDetail_SpecialOfferID') AND parent_object_id = OBJECT_ID(N'Sales.SalesOrderDetail'))
ALTER TABLE Sales.SalesOrderDetail  WITH CHECK 
	ADD  CONSTRAINT FK_SalesOrderDetail_SpecialOfferID FOREIGN KEY(SpecialOfferID)
	REFERENCES Sales.SpecialOffer (SpecialOfferID)
GO



--TSQL statement to ensure FK is enabled and trusted
ALTER TABLE Sales.SalesOrderDetail 
	WITH CHECK CHECK CONSTRAINT FK_SalesOrderDetail_SpecialOfferID
GO
SELECT name,is_disabled, is_not_trusted FROM [sys].[foreign_keys] 
	WHERE name = 'FK_SalesOrderDetail_SpecialOfferID';
GO

--turn on Include Actual Query Plan (Ctrl-M)
SET STATISTICS IO ON
GO
select sod.*
	FROM Sales.SalesOrderDetail sod
	JOIN Sales.SpecialOffer so 
	  ON so.SpecialOfferID = sod.SpecialOfferID
GO
SET STATISTICS IO OFF
GO
/*
Table 'SalesOrderDetail'. Scan count 1, logical reads 1246, physical reads 0, read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.
*/

--disable FK
ALTER TABLE Sales.SalesOrderDetail NOCHECK 
	CONSTRAINT FK_SalesOrderDetail_SpecialOfferID
GO
SELECT name,is_disabled, is_not_trusted 
	FROM [sys].[foreign_keys] WHERE name = 'FK_SalesOrderDetail_SpecialOfferID';
GO

SET STATISTICS IO ON
GO
select sod.*
	FROM Sales.SalesOrderDetail sod
	JOIN Sales.SpecialOffer so 
	  ON so.SpecialOfferID = sod.SpecialOfferID
GO
SET STATISTICS IO OFF
GO
/*
Table 'Worktable'. Scan count 0, logical reads 0, physical reads 0, read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.
Table 'SalesOrderDetail'. Scan count 1, logical reads 1246, physical reads 0, read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.
Table 'SpecialOffer'. Scan count 1, logical reads 2, physical reads 0, read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.
*/

--partial FK enable, but still not trusted
ALTER TABLE Sales.SalesOrderDetail CHECK CONSTRAINT FK_SalesOrderDetail_SpecialOfferID
GO
SELECT name,is_disabled, is_not_trusted 
	FROM [sys].[foreign_keys] WHERE name = 'FK_SalesOrderDetail_SpecialOfferID';
GO

SET STATISTICS IO ON
GO
select sod.*
	FROM Sales.SalesOrderDetail sod
	JOIN Sales.SpecialOffer so 
	  ON so.SpecialOfferID = sod.SpecialOfferID
GO
SET STATISTICS IO OFF
GO
/*
Table 'Worktable'. Scan count 0, logical reads 0, physical reads 0, read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.
Table 'SalesOrderDetail'. Scan count 1, logical reads 1246, physical reads 0, read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.
Table 'SpecialOffer'. Scan count 1, logical reads 2, physical reads 0, read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.
*/

--And as final check get FK enabled and back to is trusted
ALTER TABLE Sales.SalesOrderDetail WITH CHECK CHECK 
	CONSTRAINT FK_SalesOrderDetail_SpecialOfferID
GO
SELECT is_disabled, is_not_trusted 
	FROM [sys].[foreign_keys] WHERE name = 'FK_SalesOrderDetail_SpecialOfferID';
GO

SET STATISTICS IO ON
GO
select sod.*
	FROM Sales.SalesOrderDetail sod
	JOIN Sales.SpecialOffer so 
	  ON so.SpecialOfferID = sod.SpecialOfferID
GO
SET STATISTICS IO OFF
GO 
/*
Table 'SalesOrderDetail'. Scan count 1, logical reads 1246, physical reads 0, read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.
*/

--almost impossible to get back to is_trusted status in 24x7 operation.  There is no good solution, just
--	have to test what works best for you.

--test, make sure get actual execution plan
select sod.*, c.*
	FROM Sales.SalesOrderDetail sod
	JOIN Sales.SalesOrderHeader soh
	  ON soh.SalesOrderID = sod.SalesOrderID
	JOIN Sales.Customer c
	  ON c.CustomerID = soh.CustomerID
--notice still have to go through Sales.SalesOrderHeader to get CustomerID/SalesOrderID join
--notice query uses IX_SalesOrderHeader_CustomerID to get CustomerID, but what about soh.SalesOrderID???
GO


--now test orphaned data
--turn off FK
ALTER TABLE Sales.SalesOrderDetail NOCHECK 
	CONSTRAINT [FK_SalesOrderDetail_SpecialOfferProduct_SpecialOfferIDProductID]
ALTER TABLE Sales.SalesOrderDetail NOCHECK 
	CONSTRAINT FK_SalesOrderDetail_SpecialOfferID
GO
--insert new row with bad SpecialOfferID (-2)
SELECT * FROM Sales.SalesOrderDetail WHERE SalesOrderID = 75123

INSERT Sales.SalesOrderDetail
	(SalesOrderID,CarrierTrackingNumber,OrderQty,ProductID,SpecialOfferID,UnitPrice,UnitPriceDiscount,rowguid,ModifiedDate)
	SELECT SalesOrderID,CarrierTrackingNumber,OrderQty,ProductID,-2 [SpecialOfferID],UnitPrice,UnitPriceDiscount,NEWID(),ModifiedDate
		FROM Sales.SalesOrderDetail sod
		WHERE SalesOrderID = 75123
		  AND SalesOrderDetailID = 121315

SELECT * FROM Sales.SalesOrderDetail WHERE SalesOrderID = 75123
GO

ALTER TABLE Sales.SalesOrderDetail CHECK CONSTRAINT FK_SalesOrderDetail_SpecialOfferID		--only checks new/updated data going forward
GO
SELECT is_disabled, is_not_trusted 
	FROM [sys].[foreign_keys] WHERE name = 'FK_SalesOrderDetail_SpecialOfferID';
GO


--note when checking old data, bad FK doesn't even let it do an estimated query plan.
ALTER TABLE Sales.SalesOrderDetail WITH CHECK CHECK 
	CONSTRAINT FK_SalesOrderDetail_SpecialOfferID
GO


--clean up back FK
DELETE Sales.SalesOrderDetail
	WHERE SpecialOfferID = -2
GO

ALTER TABLE Sales.SalesOrderDetail WITH CHECK CHECK 
	CONSTRAINT FK_SalesOrderDetail_SpecialOfferID
GO
SELECT name,is_disabled, is_not_trusted 
	FROM [sys].[foreign_keys] WHERE name = 'FK_SalesOrderDetail_SpecialOfferID';
GO

--with FK enabled, what happens when we try to delete row in parent table that has child rows in child table?
SELECT CustomerID, COUNT(*) 
	FROM Sales.SalesOrderHeader 
	GROUP BY CustomerID 
	ORDER BY 2 DESC;
--11091: 28
--14850: 1

DELETE From Sales.Customer WHERE CustomerID = 11091;
DELETE From Sales.Customer WHERE CustomerID = 14850;

--FKs help maintain data integrity (consistency); 
--this works if FK is enabled and doesn't matter if trusted or not


--and now for the UGLY:

--show estimated execution Plan
/*
DELETE soh
	FROM Sales.SalesOrderHeader soh
*/
--has to touch every child table referencing SalesOrderHeader

