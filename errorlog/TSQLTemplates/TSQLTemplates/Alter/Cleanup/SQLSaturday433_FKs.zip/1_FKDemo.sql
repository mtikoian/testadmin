--� 2014 | ByrdNest Consulting

USE AdventureWorks2012
GO

-- can create foreign key at table definition
CREATE TABLE Sales.SalesOrderHeader2(
	SalesOrderID int IDENTITY(1,1) NOT NULL,
	RevisionNumber tinyint NOT NULL,
	OrderDate datetime NOT NULL,
	DueDate datetime NOT NULL,
	ShipDate datetime NULL,
	[Status] tinyint NOT NULL,
	OnlineOrderFlag dbo.Flag NOT NULL,
	SalesOrderNumber  AS (isnull(N'SO'+CONVERT(nvarchar(23),SalesOrderID),N'*** ERROR ***')),
	PurchaseOrderNumber dbo.OrderNumber NULL,
	AccountNumber dbo.AccountNumber NULL,
	CustomerID int NOT NULL CONSTRAINT FK_SalesOrderHeader2_CustomerID REFERENCES Sales.Customer(CustomerID),
	SalesPersonID int NULL,
	TerritoryID int NULL,
	BillToAddressID int NOT NULL,
	ShipToAddressID int NOT NULL,
	ShipMethodID int NOT NULL,
	CreditCardID int NULL,
	CreditCardApprovalCode varchar(15) NULL,
	CurrencyRateID int NULL,
	SubTotal money NOT NULL,
	TaxAmt money NOT NULL,
	Freight money NOT NULL,
	TotalDue  AS (isnull((SubTotal+TaxAmt)+Freight,(0))),
	Comment nvarchar(128) NULL,
	rowguid uniqueidentifier ROWGUIDCOL  NOT NULL,
	ModifiedDate datetime NOT NULL,
 CONSTRAINT PK_SalesOrderHeader2_SalesOrderID PRIMARY KEY CLUSTERED 
	(SalesOrderID ASC) )
	GO
--check SSMS

--clean up
IF OBJECT_ID(N'Sales.SalesOrderHeader2') IS NOT NULL DROP TABLE Sales.SalesOrderHeader2
GO

--to drop Foreign Key
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'Sales.FK_SalesOrderHeader_CustomerID') AND parent_object_id = OBJECT_ID(N'Sales.SalesOrderHeader'))
ALTER TABLE Sales.SalesOrderHeader DROP CONSTRAINT FK_SalesOrderHeader_CustomerID
GO


--most people add FKs after table definition (this is what Microsoft does when creating table scripts)
ALTER TABLE Sales.SalesOrderHeader  WITH CHECK 
	ADD  CONSTRAINT FK_SalesOrderHeader_CustomerID FOREIGN KEY(CustomerID)
	REFERENCES Sales.Customer (CustomerID)
GO
--does not create an index in child table; show in SSMS; will cause a schema lock on the table during creation


--however for existing FK, to disable (but still leave definition of FK)
ALTER TABLE Sales.SalesOrderHeader NOCHECK CONSTRAINT FK_SalesOrderHeader_CustomerID

-- to reinstate FK, there is syntax to do so, but let's discuss FK attributes first.
SELECT * from sys.foreign_keys WHERE name = 'FK_SalesOrderHeader_CustomerID'

--discuss is_disabled and is_not_trusted columns of result set


--this turns on FK checking again, but only for new data
ALTER TABLE Sales.SalesOrderHeader CHECK CONSTRAINT FK_SalesOrderHeader_CustomerID
GO
SELECT * from sys.foreign_keys WHERE name = 'FK_SalesOrderHeader_CustomerID'
GO

--This turns on Fk checking again and also goes back to check existing data.  
--It fails if there are customerIDs in SalesOrderHeader that are not in Sales.Customer table

ALTER TABLE Sales.SalesOrderHeader WITH CHECK CHECK			--note stutter step here
	CONSTRAINT FK_SalesOrderHeader_CustomerID
GO
SELECT name,is_disabled,is_not_trusted 
	from sys.foreign_keys WHERE name = 'FK_SalesOrderHeader_CustomerID'
GO


--why turn off FKs:
--	Large data inserts/deletes

--go back to FK_Demo
USE FK_Demo
GO

--check to make sure both FKs are enabled
ALTER TABLE dbo.PersonAttribute WITH CHECK CHECK CONSTRAINT FK_PersonAttribute_Attribute
ALTER TABLE dbo.PersonAttribute WITH CHECK CHECK CONSTRAINT FK_PersonAttribute_Person
GO
SELECT name,is_disabled, is_not_trusted FROM [sys].[foreign_keys] 
	WHERE name IN ('FK_PersonAttribute_Attribute','FK_PersonAttribute_Person');
GO

--with FKs turned on, look at query plan for this insert (Ctrl-M)
BEGIN TRANSACTION
DECLARE @PersonID	INT
INSERT dbo.Person
	SELECT 'Bullock','Sandra';
SET @PersonID = SCOPE_IDENTITY();

--turn on Include Actual Query Plan
INSERT dbo.PersonAttribute (PersonID,AttributeID,AttributeValue)
	SELECT @PersonID,1,'9461 Lakeview Dr' UNION ALL
	SELECT @PersonID,2,'Lake Travis' UNION ALL
	SELECT @PersonID,3,'Texas' UNION ALL
	SELECT @PersonID,4,'78760';
GO
--review query plan; note that added dbo.Person and dbo.Attribute to check FK validity
ROLLBACK TRANSACTION

--now disable FK and re-run same query
ALTER TABLE dbo.PersonAttribute NOCHECK CONSTRAINT FK_PersonAttribute_Attribute
ALTER TABLE dbo.PersonAttribute NOCHECK CONSTRAINT FK_PersonAttribute_Person
GO
SELECT is_disabled, is_not_trusted FROM [sys].[foreign_keys] 
	WHERE name IN ('FK_PersonAttribute_Attribute','FK_PersonAttribute_Person');
GO

BEGIN TRANSACTION
DECLARE @PersonID	INT
INSERT dbo.Person
	SELECT 'Bullock','Sandra';
SET @PersonID = SCOPE_IDENTITY();

--turn on Include Actual Query Plan
INSERT dbo.PersonAttribute (PersonID,AttributeID,AttributeValue)
	SELECT @PersonID,1,'9461 Lakeview Dr' UNION ALL
	SELECT @PersonID,2,'Lake Travis' UNION ALL
	SELECT @PersonID,3,'Texas' UNION ALL
	SELECT @PersonID,4,'78760';
GO
--review query plan; note that added dbo.Person and dbo.Attribute are now missing from query plan


--clean up
ROLLBACK TRANSACTION
GO

--clean up DB
USE AdventureWorks2012
GO
IF OBJECT_ID(N'Sales.SalesOrderHeader2') IS NOT NULL Drop TABLE Sales.SalesOrderHeader2
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'Sales.FK_SalesOrderHeader_CustomerID') AND parent_object_id = OBJECT_ID(N'Sales.SalesOrderHeader'))
ALTER TABLE Sales.SalesOrderHeader DROP CONSTRAINT FK_SalesOrderHeader_CustomerID
GO

