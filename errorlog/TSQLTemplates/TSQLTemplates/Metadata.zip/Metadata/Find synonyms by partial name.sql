

select * 
from sys.synonyms 
where name like '%Price%'

