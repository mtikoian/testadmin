exec sp_configure @ConfigName = 'xp_Cmdshell', @ConfigValue = 1

reconfigure