
select max(Column_Id)
from Sys.Columns C 
    inner join Sys.Tables T