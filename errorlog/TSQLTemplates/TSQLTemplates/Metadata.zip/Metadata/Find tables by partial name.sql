
select * 
from information_Schema.Tables 
where Table_Name like '%Org%'      

select * 
from information_Schema.Tables 

  
  