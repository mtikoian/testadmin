use AdventureWorks
go
set nocount on
go

/* Show the data distribution
select ProductID, count(*)
from Production.TransactionHistory
group by ProductID
order by count(*)

ProductID
----------- -----------
843         1
849         1
855         1
...
921         2859
873         3003
870         4187
*/

--SHOW PROFILER with stmt completed and AUTO STATS EVENTS ON!

--set show actual execution plan on in SSMS
dbcc freeproccache
go
--set statistics io on
--go
declare @tab table (a int not null)
insert @tab values (843)
insert @tab values (849)
insert @tab values (855)

select *
from Production.TransactionHistory h
inner join @tab t on t.a = h.ProductID

--18 logical reads, nested loop plan

dbcc freeproccache
go
declare @tab table (a int not null)

insert @tab values (870)
--insert @tab values (873)
--insert @tab values (921)

select *
from Production.TransactionHistory h
inner join @tab t on t.a = h.ProductID

--30805 logical reads, nested loop plan

dbcc freeproccache
go
create table #tab (a int not null)
insert #tab values (843)
insert #tab values (849)
insert #tab values (855)

select *
from Production.TransactionHistory h
inner join #tab t on t.a = h.ProductID

--18 logical, nested loop plan

DROP TABLE #tab
GO
create table #tab (a int not null)
GO

dbcc freeproccache

insert #tab values (870)
--insert #tab values (873)
--insert #tab values (921)

select *
from #tab t
inner join Production.TransactionHistory h on t.a = h.ProductID

--792 logical reads, hash join plan

drop table #tab
