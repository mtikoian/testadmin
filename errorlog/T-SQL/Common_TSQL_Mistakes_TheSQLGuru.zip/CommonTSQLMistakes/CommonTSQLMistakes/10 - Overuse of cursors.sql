/* left for inquisitive reader
   KEY TAKEAWAY

   AVOID CURSORS IF POSSIBLE (unless they are the best solution - i.e. running totals prior to SQL 2012
   
*/


Use tempdb
set nocount on
go
IF OBJECT_ID(N'ProductPrices', N'U') IS NOT NULL
   DROP TABLE dbo.ProductPrices;
   
CREATE TABLE dbo.ProductPrices (
 sku INT NOT NULL,
 price DECIMAL(15, 2) NOT NULL,
 effective_start_date DATETIME NOT NULL,
 effective_end_date DATETIME,
 PRIMARY KEY(sku, effective_start_date));
 
INSERT dbo.ProductPrices VALUES(1, 10.50, '20090101', NULL);
INSERT dbo.ProductPrices VALUES(2, 11.50, '20090101', NULL);
INSERT dbo.ProductPrices VALUES(3, 19.00, '20090101', NULL);
INSERT dbo.ProductPrices VALUES(4, 11.25, '20090101', NULL);

IF OBJECT_ID(N'NewPrices', N'U') IS NOT NULL
   DROP TABLE dbo.NewPrices;
   
CREATE TABLE dbo.NewPrices (
 sku INT NOT NULL PRIMARY KEY,
 price DECIMAL(15, 2) NOT NULL);
 
INSERT dbo.NewPrices VALUES(2, 11.25);
INSERT dbo.NewPrices VALUES(4, 12.00);

SELECT sku, price, effective_start_date, effective_end_date 
FROM dbo.ProductPrices;

/*

sku  price  effective_start_date effective_end_date
---- ------ -------------------- ------------------
1    10.50  2009-01-01           NULL
2    11.50  2009-01-01           NULL
3    19.00  2009-01-01           NULL
4    11.25  2009-01-01           NULL

*/

SELECT sku, price
FROM dbo.NewPrices;

/*

sku  price
---- ------
2    11.25
4    12.00

*/


BEGIN TRANSACTION

-- Cursor solution
DECLARE @sku INT;
DECLARE @price DECIMAL(15, 2);

DECLARE PriceUpdates
CURSOR 
/*	   LOCAL
       FORWARD_ONLY
       STATIC
       READ_ONLY
*/
FOR SELECT sku, price
    FROM dbo.NewPrices;
 
OPEN PriceUpdates;
 
FETCH NEXT FROM PriceUpdates
      INTO @sku, @price;
 
WHILE @@FETCH_STATUS = 0
BEGIN

  UPDATE dbo.ProductPrices
  SET price = @price, 
      effective_start_date = CURRENT_TIMESTAMP
  WHERE sku = @sku; 

  FETCH NEXT FROM PriceUpdates
        INTO @sku, @price;
 
END
 
CLOSE PriceUpdates;
DEALLOCATE PriceUpdates;

SELECT sku, price, effective_start_date, effective_end_date 
FROM dbo.ProductPrices;

ROLLBACK TRANSACTION

BEGIN TRANSACTION

UPDATE dbo.ProductPrices
SET price = (SELECT N.price
             FROM dbo.NewPrices AS N
             WHERE N.sku = ProductPrices.sku),
    effective_start_date = CURRENT_TIMESTAMP
WHERE EXISTS(SELECT *
             FROM dbo.NewPrices AS N
             WHERE N.sku = ProductPrices.sku);
             
SELECT sku, price, effective_start_date, effective_end_date 
FROM dbo.ProductPrices;

ROLLBACK TRANSACTION
            
GO

DROP TABLE dbo.ProductPrices;
DROP TABLE dbo.NewPrices;

