USE AdventureWorks2008R2
GO
SET STATISTICS IO ON
GO

DECLARE @cnt int

SELECT @cnt = COUNT(*) FROM Sales.SalesOrderHeader WHERE RevisionNumber = 3

IF @cnt > 0
BEGIN
   PRINT 'yep, there is at least one'
END

0.579 cost
689 reads (TABLE scan)

--this can short-circuit, but hasn't always
IF (SELECT COUNT(*) FROM Sales.SalesOrderHeader WHERE RevisionNumber = 3) > 0
BEGIN
   PRINT 'yep, there is at least one'
END

--BEST!!
IF EXISTS (SELECT * FROM Sales.SalesOrderHeader WHERE RevisionNumber = 3) --NOT SPECIFIC COLUMN! Can use scalar too
BEGIN
   PRINT 'yep, there is at least one'
END

0.00329 cost
3 reads!

