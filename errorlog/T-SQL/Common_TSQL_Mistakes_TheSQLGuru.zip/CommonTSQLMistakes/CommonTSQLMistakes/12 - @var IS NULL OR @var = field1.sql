--look up Gail Shaw's "Catch All Query" blog post

USE tempdb
set nocount on
go
--drop table KGBIsNULLORTest

create table dbo.KGBIsNULLORTest (a int, b int, c char(50))

insert dbo.KGBIsNULLORTest
select Number, Number % 2000, 'dummy data'
from KGBTools.dbo.BigNumbers
where Number < 10000

create index idxa on dbo.KGBIsNULLORTest (a)
go
create index idxb on dbo.KGBIsNULLORTest (b)
go

create proc dbo.badIsNULLORProc (@a int, @b int)
AS
SET NOCOUNT ON

SELECT a, b, c
  FROM dbo.KGBIsNULLORTest
 WHERE (@a = a OR @a IS NULL)
   AND (@b = b OR @b IS NULL)
RETURN

--show actual query plan
set statistics IO on

dbcc freeproccache
go
exec dbo.badIsNULLORProc NULL, NULL --this uses optimal table scan 84 READS
go
exec dbo.badIsNULLORProc 1, NULL    --this uses same table scan, but now suboptimal 84 READS
go
exec dbo.badIsNULLORProc NULL, 1    --this uses same table scan, but now suboptimal 84 READS
go
exec dbo.badIsNULLORProc 1, 1       --this uses same table scan, but now suboptimal 84 READS
go

dbcc freeproccache
go
exec dbo.badIsNULLORProc 1, 1       --this plan uses suboptimal index scan(instead of seek)/lookup for 26 READS
go
exec dbo.badIsNULLORProc 1, NULL    --this plan uses suboptimal index scan(instead of seek)/lookup for 26 READS
go
exec dbo.badIsNULLORProc NULL, 1    --this uses same, now HORRIBLE, index scan/lookup and takes 10024 READS!
go
--show estimated vs. actual rows in query plan
exec dbo.badIsNULLORProc NULL, NULL --this uses same, now HORRIBLE, index scan/lookup and takes 10024 READS!
go

--YES, you STILL need the OPTION (RECOMPILES), although I believe this was fixed in a CU somewhere along the line
create proc dbo.BetterIsNullORProc (@a int, @b int)
as
SET NOCOUNT ON

IF @a IS NOT NULL AND @b IS NOT NULL
BEGIN
   SELECT a, b
     FROM dbo.KGBIsNULLORTest
    WHERE @a = a
      AND @b = b
   OPTION (RECOMPILE)
END
ELSE
BEGIN
   IF @a IS NULL AND @b IS NOT NULL
   BEGIN
      SELECT a, b
        FROM dbo.KGBIsNULLORTest
       WHERE @b = b
      OPTION (RECOMPILE)
   END
   ELSE
   BEGIN
      IF @a IS NOT NULL AND @b IS NULL
      BEGIN
         SELECT a, b
           FROM dbo.KGBIsNULLORTest
          WHERE @a = a
         OPTION (RECOMPILE)
      END
      ELSE
      BEGIN
         SELECT a, b
           FROM dbo.KGBIsNULLORTest
      END
   END
END

dbcc freeproccache
go
exec dbo.BetterIsNullORProc NULL, NULL
go
exec dbo.BetterIsNullORProc 1, NULL
go
exec dbo.BetterIsNullORProc NULL, 1
go
exec dbo.BetterIsNullORProc 1, 1
go

dbcc freeproccache
go
exec dbo.BetterIsNullORProc 1, 1
go
exec dbo.BetterIsNullORProc NULL, 1
go
exec dbo.BetterIsNullORProc 1, NULL
go
exec dbo.BetterIsNullORProc NULL, NULL
go

dbcc freeproccache
go
exec dbo.BetterIsNullORProc NULL, 1
go
exec dbo.BetterIsNullORProc 1, NULL
go
exec dbo.BetterIsNullORProc 1, 1
go
exec dbo.BetterIsNullORProc NULL, NULL
go

dbcc freeproccache
go
exec dbo.BetterIsNullORProc 1, NULL
go
exec dbo.BetterIsNullORProc NULL, 1
go
exec dbo.BetterIsNullORProc 1, 1
go
exec dbo.BetterIsNullORProc NULL, NULL
go

--this is best way with procedures
CREATE proc dbo.IsNullOR_BothNotNull (@a int, @b int)
as
SET NOCOUNT ON

SELECT a, b
  FROM dbo.KGBIsNULLORTest
 WHERE @a = a
   AND @b = b

GO

create proc dbo.IsNullOR_A_Null_B_NotNull (@b int)
as
SET NOCOUNT ON

SELECT a, b
  FROM dbo.KGBIsNULLORTest
 WHERE @b = b

GO

create proc dbo.IsNullOR_A_NotNull_B_Null (@a int)
as
SET NOCOUNT ON

SELECT a, b
  FROM dbo.KGBIsNULLORTest
 WHERE @a = a

GO

CREATE proc dbo.IsNullOR_BothNull
as
SET NOCOUNT ON

SELECT a, b
  FROM dbo.KGBIsNULLORTest

GO

create proc dbo.IsNullORSubSprocs (@a int, @b int)
as
SET NOCOUNT ON

IF @a IS NOT NULL AND @b IS NOT NULL
BEGIN
   EXEC dbo.IsNullOR_BothNotNull @a, @b
END
ELSE
BEGIN
   IF @a IS NULL AND @b IS NOT NULL
   BEGIN
      EXEC dbo.IsNullOR_A_Null_B_NotNull @b
   END
   ELSE
   BEGIN
      IF @a IS NOT NULL AND @b IS NULL
      BEGIN
         EXEC dbo.IsNullOR_A_NotNull_B_Null @a
      END
      ELSE
      BEGIN
         EXEC dbo.IsNullOR_BothNull
      END
   END
END
GO

dbcc freeproccache
go
exec dbo.IsNullORSubSprocs NULL, NULL
go
exec dbo.IsNullORSubSprocs 1, NULL
go
exec dbo.IsNullORSubSprocs NULL, 1
go
exec dbo.IsNullORSubSprocs 1, 1
go

dbcc freeproccache
go
exec dbo.IsNullORSubSprocs 1, 1
go
exec dbo.IsNullORSubSprocs NULL, 1
go
exec dbo.IsNullORSubSprocs 1, NULL
go
exec dbo.IsNullORSubSprocs NULL, NULL
go


NOTE: BEST SOLUTION CAN BE DYNAMIC SQL, ESPECIALLY IF YOU HAVE BAD DATA VALUE SKEW OR YOU
      JOIN TO TABLES JUST TO "POSSIBLY" FILTER OUT ROWS. BE SURE TO GUARD AGAINST SQL INJECTION THOUGH!
