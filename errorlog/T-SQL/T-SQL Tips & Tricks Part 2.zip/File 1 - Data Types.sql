-----
-- SIMPLE VARIABLE EXAMPLES
-- TURN ON ACTUAL EXECUTION PLAN (Ctrl-M)
-- Integer 
DECLARE 
	@MySmallInt SMALLINT = 5,
	@MyBigInt BIGINT = 5;

SELECT 'Matching Types'
WHERE @MySmallInt = @MySmallInt;

SELECT 'Mismatched Types'
WHERE @MySmallInt = @MyBigInt;
GO

-----
-- VARCHAR & NVARCHAR
DECLARE 
	@MyNVarChar NVARCHAR(50) = 'This is a string',
	@MyVarChar VARCHAR(50) = 'This is a string';

SELECT 'Matching Types'
WHERE @MyVarChar = @MyVarChar;

SELECT 'Mismatched Types'
WHERE @MyNVarChar = @MyVarChar;
GO

CREATE TABLE dbo.tbl_DataType_A (
	Field_A smallint,
	Field_B varchar(64)
	);

CREATE TABLE dbo.tbl_DataType_B (
	Field_A int,
	Field_B nvarchar(64)
	);

/* Bonus Tips:
	1. Always fully qualify table names
	2. Always specify fields for an insert
	3. Always use and alias even with a single table
*/
INSERT INTO dbo.tbl_DataType_A(Field_B, Field_A)
	SELECT sc.name, ROW_NUMBER() OVER(ORDER BY sc.name)
	FROM master.dbo.syscolumns sc
	WHERE sc.name > 'A';

INSERT INTO dbo.tbl_DataType_B(Field_A, Field_B)
	SELECT a.Field_A, a.Field_B
	FROM dbo.tbl_DataType_A a;

DECLARE @MyUpperLimit varchar(5);
SET @MyUpperLimit = 20;
SELECT @MyUpperLimit;

SELECT a.Field_A, a.Field_B
FROM dbo.tbl_DataType_A a
	INNER JOIN dbo.tbl_DataType_B b
	ON b.Field_B = a.Field_A
WHERE a.Field_A < @MyUpperLimit;