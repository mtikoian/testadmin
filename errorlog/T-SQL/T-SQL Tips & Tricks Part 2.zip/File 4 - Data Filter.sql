CREATE TABLE dbo.tbl_Patient (
	PatientID int NOT NULL,
	PostedDate date NOT NULL,
	LastName varchar(64) NULL,
	FirstName varchar(64) NULL,
	MiddleName varchar(64) NULL,
	NamePrefix varchar(8) NULL,
	NameSuffix varchar(8) NULL,
	Gender char(1) NULL,
	DOB date NULL,
	DOD date NULL,
	Age smallint,
	SSN varchar(16) NULL,
	InstitutionID int NULL,
	PatientNbr varchar(32) NULL,
	EffDateBeg date NULL,
	EffDateEnd date NULL,
	GroupNbr varchar(64) NULL,
	GroupName varchar(128) NULL,
	SubGroupNbr varchar(16) NULL,
	MedicareNbr varchar(16) NULL,
	AssignedPCP int NULL,
	AddressLine1 varchar(128) NULL,
	AddressLine2 varchar(128) NULL,
	CityName varchar(64) NULL,
	StateAbbr char(2) NULL,
	ZipCode varchar(16) NULL,
	CountyCode int NULL,
	PhoneNbr varchar(16) NULL,
	LastActivity date NULL,
	DataHash int NULL
	);

CREATE TABLE dbo.tbl_Calc_DataPool (
	PatientID int,
	EvidencePoolId int,
	ValueSetGroup varchar(16),
	EvidenceDate date,
	NbrMonths smallint,
	InstitutionID int,
 	EvidenceResult float,
	HasResult bit
	);

CREATE TABLE dbo.tbl_Calc_MeasureValueSet (
	MeasureId int,
	ValueSetGroup varchar(16),
	StandardTaxonomy varchar(16),
	StandardTerm varchar(16),
	NbrMonths smallint,
	UsePrior bit,
	UseRecent bit,
	MinRecords smallint
	);

CREATE TABLE dbo.tbl_EvidencePool (
	EvidencePoolId int,
	PatientId int,
	StandardTaxonomy varchar(16),
	StandardTerm varchar(16),
	EvidenceDate date,
	EvidenceResult float,
	InstitutionId int
	);

DECLARE @MeasureId int, @AsOfDate date, @AgeMin real, @AgeMax real;
--
--	Filter data as needed to just those records needed for this measure calculation
--
	WITH cteRawData(PatientID, EvidencePoolId, ValueSetGroup, EvidenceDate, InstitutionID,
					MinRecords, NbrMonths, EvidenceResult, HasResult) AS (
		SELECT ep.PatientId, ep.EvidencePoolId, vs.ValueSetGroup, ep.EvidenceDate,
				ep.InstitutionId, vs.MinRecords, vs.NbrMonths, ep.EvidenceResult,
				CASE WHEN ep.EvidenceResult IS NOT NULL THEN 1 ELSE 0 END
		FROM dbo.tbl_Patient p
			INNER JOIN dbo.tbl_Calc_MeasureValueSet vs ON vs.MeasureId = @MeasureId
			INNER JOIN dbo.tbl_EvidencePool ep ON ep.PatientID = p.PatientID
													AND ep.StandardTaxonomy = vs.StandardTaxonomy
													AND ep.StandardTerm = vs.StandardTerm
													AND ((vs.UseRecent=1 AND p.DOD IS NULL)
														OR ep.EvidenceDate <= @AsOfDate)
													AND (vs.NbrMonths IS NULL OR vs.UsePrior=1
														OR ep.EvidenceDate >=
															DATEADD(month, -vs.NbrMonths,
																DATEADD(day,1,@AsOfDate)))
		WHERE p.Age > @AgeMin-1 AND p.Age < @AgeMax+1
		),
	cteDataPool(PatientID, EvidencePoolId, ValueSetGroup, EvidenceDate, MinRecords, NbrMonths,
				InstitutionId, EvidenceResult, HasResult, RowNbr) AS (
		SELECT PatientID, EvidencePoolId, ValueSetGroup, EvidenceDate, MinRecords, NbrMonths,
				InstitutionId, EvidenceResult,HasResult,
				ROW_NUMBER() OVER(PARTITION BY PatientID, ValueSetGroup
									ORDER BY EventDate DESC, HasResult DESC, EvidenceResult)
		FROM cteRawData
		)
 	INSERT INTO tbl_Calc_DataPool(PatientID, EvidencePoolId, ValueSetGroup, EvidenceDate,
									NbrMonths, InstitutionId, EvidenceResult, HasResult)
 		SELECT PatientID, EvidencePoolId, ValueSetGroup, EvidenceDate, NbrMonths, InstitutionId,
				EvidenceResult, HasResult
		FROM cteDataPool
 		WHERE (MinRecords IS NULL OR RowNbr <= MinRecords);

--	Bonus Tip: If you use a temp table often enough, make it a real table to improve performance