CREATE TABLE dbo.tbl_Patient (
	PatientID int NOT NULL,
	PostedDate date NOT NULL,
	LastName varchar(64) NULL,
	FirstName varchar(64) NULL,
	MiddleName varchar(64) NULL,
	NamePrefix varchar(8) NULL,
	NameSuffix varchar(8) NULL,
	Gender char(1) NULL,
	DOB date NULL,
	DOD date NULL,
	Age smallint,
	SSN varchar(16) NULL,
	InstitutionID int NULL,
	PatientNbr varchar(32) NULL,
	EffDateBeg date NULL,
	EffDateEnd date NULL,
	GroupNbr varchar(64) NULL,
	GroupName varchar(128) NULL,
	SubGroupNbr varchar(16) NULL,
	MedicareNbr varchar(16) NULL,
	AssignedPCP int NULL,
	AddressLine1 varchar(128) NULL,
	AddressLine2 varchar(128) NULL,
	CityName varchar(64) NULL,
	StateAbbr char(2) NULL,
	ZipCode varchar(16) NULL,
	CountyCode int NULL,
	PhoneNbr varchar(16) NULL,
	LastActivity date NULL,
	DataHash int NULL
	);

CREATE TABLE dbo.tbl_Stg_Patient (
	PatientID int NOT NULL,
	PostedDate date NOT NULL,
	LastName varchar(64) NULL,
	FirstName varchar(64) NULL,
	MiddleName varchar(64) NULL,
	NamePrefix varchar(8) NULL,
	NameSuffix varchar(8) NULL,
	Gender char(1) NULL,
	DOB date NULL,
	DOD date NULL,
	SSN varchar(16) NULL,
	InstitutionID int NULL,
	PatientNbr varchar(32) NULL,
	EffDateBeg date NULL,
	EffDateEnd date NULL,
	GroupNbr varchar(64) NULL,
	GroupName varchar(128) NULL,
	SubGroupNbr varchar(16) NULL,
	MedicareNbr varchar(16) NULL,
	AssignedPCP int NULL,
	AddressLine1 varchar(128) NULL,
	AddressLine2 varchar(128) NULL,
	CityName varchar(64) NULL,
	StateAbbr char(2) NULL,
	ZipCode varchar(16) NULL,
	CountyCode int NULL,
	PhoneNbr varchar(16) NULL,
	LastActivity date NULL,
	DataHash int NULL
	);
GO

--	Update the data hash values for the staging data
	BEGIN TRANSACTION;
	UPDATE dbo.tbl_Stg_Patient SET
		DataHash = HASHBYTES('MD5', CAST(PatientID as varchar) +
									ISNULL(LastName,'') +
									ISNULL(FirstName,'') +
									ISNULL(MiddleName,'') +
									ISNULL(NamePrefix,'') +
									ISNULL(NameSuffix,'') +
									ISNULL(Gender,'') +
									ISNULL(CONVERT(varchar(10),
									ISNULL(DOB, '01/01/1900'),101),'') +
									ISNULL(CONVERT(varchar(10),DOD,101),'') +
									ISNULL(SSN,'') +
									ISNULL(CAST(InstitutionID as varchar),'') +
									ISNULL(PatientNbr,'') +
									ISNULL(CONVERT(varchar(10),EffDateBeg,101),'') +
									ISNULL(CONVERT(varchar(10),EffDateEnd,101),'') +
									ISNULL(GroupNbr,'') + ISNULL(GroupName,'') +
									ISNULL(SubGroupNbr,'') +
									ISNULL(MedicareNbr,'') +
									ISNULL(CAST(AssignedPCP as varchar),'') +
									ISNULL(AddressLine1,'') +
									ISNULL(AddressLine2,'') +
									ISNULL(CityName,'') +
									ISNULL(StateAbbr,'') +
									ISNULL(ZipCode,'') +
									ISNULL(CAST(CountyCode as varchar),'') +
									ISNULL(PhoneNbr,'') +
									ISNULL(CONVERT(varchar(10),LastActivity,101),''));
	COMMIT;

--	Create indexes on the staging table to improve performance
	IF object_id(N'IX_tbl_Stg_Patient_A') IS NULL
		CREATE NONCLUSTERED INDEX IX_tbl_Stg_Patient_A ON dbo.tbl_Stg_Patient (
			PatientID,
			DataHash
			) WITH( PAD_INDEX = OFF, FILLFACTOR = 80, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF,
					ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY];

--	Update records that have changed data
	BEGIN TRANSACTION;
		UPDATE dbo.tbl_Patient SET
			tbl_Patient.LastName = SP.LastName,
			tbl_Patient.FirstName = SP.FirstName,
			tbl_Patient.MiddleName = SP.MiddleName,
			tbl_Patient.NamePrefix = SP.NamePrefix,
			tbl_Patient.NameSuffix = SP.NameSuffix,
			tbl_Patient.Gender = SP.Gender,
			tbl_Patient.DOB = ISNULL(SP.DOB, '01/01/1900'),
			tbl_Patient.DOD = SP.DOD,
			tbl_Patient.SSN = SP.SSN,
			tbl_Patient.InstitutionID = SP.InstitutionID,
			tbl_Patient.PatientNbr = SP.PatientNbr,
			tbl_Patient.EffDateBeg = SP.EffDateBeg,
			tbl_Patient.EffDateEnd = SP.EffDateEnd,
			tbl_Patient.GroupNbr = SP.GroupNbr,
			tbl_Patient.GroupName = SP.GroupName,
			tbl_Patient.SubGroupNbr = SP.SubGroupNbr,
			tbl_Patient.MedicareNbr = SP.MedicareNbr,
			tbl_Patient.AddressLine1 = SP.AddressLine1,
			tbl_Patient.AddressLine2 = SP.AddressLine2,
			tbl_Patient.CityName = SP.CityName,
			tbl_Patient.StateAbbr = SP.StateAbbr,
			tbl_Patient.ZipCode = SP.ZipCode,
			tbl_Patient.CountyCode = SP.CountyCode,
			tbl_Patient.PhoneNbr = SP.PhoneNbr,
			tbl_Patient.LastActivity = SP.LastActivity,
			tbl_Patient.DataHash = SP.DataHash
		FROM dbo.tbl_Stg_Patient SP
		WHERE dbo.tbl_Patient.PatientID = SP.PatientID
		AND dbo.tbl_Patient.DataHash <> SP.DataHash;
	COMMIT;

--	Insert remaining records as Patient variations by doing a left join from staging to variations and using only
--	those records that don't exist in variations
	BEGIN TRANSACTION;
		INSERT INTO dbo.tbl_Patient (PatientID, LastName, FirstName, MiddleName, NamePrefix, NameSuffix,
									Gender, DOB, DOD, SSN, InstitutionID, PatientNbr, EffDateBeg, EffDateEnd,
									GroupNbr, GroupName, SubGroupNbr, MedicareNbr, AssignedPCP, AddressLine1,
									AddressLine2, CityName, StateAbbr, ZipCode, CountyCode, PhoneNbr, LastActivity,
									DataHash)
			SELECT DISTINCT SP.PatientID, SP.LastName, SP.FirstName, SP.MiddleName, SP.NamePrefix,
					SP.NameSuffix, SP.Gender, ISNULL(SP.DOB, '01/01/1900'), SP.DOD, SP.SSN, SP.InstitutionID,
					SP.PatientNbr, SP.EffDateBeg, SP.EffDateEnd, SP.GroupNbr, SP.GroupName, SP.SubGroupNbr,
					SP.MedicareNbr, SP.AssignedPCP, SP.AddressLine1, SP.AddressLine2, SP.CityName, SP.StateAbbr,
					SP.ZipCode, SP.CountyCode, SP.PhoneNbr, SP.LastActivity, SP.DataHash
			FROM dbo.tbl_Stg_Patient SP
				LEFT JOIN dbo.tbl_Patient P ON P.PatientID = SP.PatientID
			WHERE P.PatientID IS NULL;
	COMMIT;

--	Bonus tip: Here's how it could be done with a MERGE Statement for those who like to say "UPSERT"
	MERGE dbo.tbl_Patients AS P
	USING (SELECT	SP1.PatientID, SP1.LastName, SP1.FirstName, SP1.MiddleName, SP1.NamePrefix, SP1.NameSuffix,
					SP1.Gender, SP1.DOB, SP1.DOD, SP1.SSN, SP1.InstitutionID, SP1.PatientNbr, SP1.EffDateBeg,
					SP1.EffDateEnd, SP1.GroupNbr, SP1.GroupName, SP1.SubGroupNbr, SP1.MedicareNbr,
					SP1.AddressLine1, SP1.AddressLine2, SP1.CityName, SP1.StateAbbr, SP1.ZipCode, SP1.CountyCode,
					SP1.PhoneNbr, SP1.LastActivity, SP1.DataHash
			FROM dbo.tbl_Stg_Patient SP1
				LEFT dbo.tbl_Patient P1
					ON P1.PatientID = SP1.PatientID
					AND P1.DataHash = SP1.DataHash
			WHERE P1.PatientID IS NULL) as SP
	ON P.PatientID = SP.PatientID AND P.DataHash = SP.DataHash
	WHEN MATCHED THEN UPDATE SET 
					tbl_Patient.LastName = SP.LastName,
					tbl_Patient.FirstName = SP.FirstName,
					tbl_Patient.MiddleName = SP.MiddleName,
					tbl_Patient.NamePrefix = SP.NamePrefix,
					tbl_Patient.NameSuffix = SP.NameSuffix,
					tbl_Patient.Gender = SP.Gender,
					tbl_Patient.DOB = ISNULL(SP.DOB, '01/01/1900'),
					tbl_Patient.DOD = SP.DOD,
					tbl_Patient.SSN = SP.SSN,
					tbl_Patient.InstitutionID = SP.InstitutionID,
					tbl_Patient.PatientNbr = SP.PatientNbr,
					tbl_Patient.EffDateBeg = SP.EffDateBeg,
					tbl_Patient.EffDateEnd = SP.EffDateEnd,
					tbl_Patient.GroupNbr = SP.GroupNbr,
					tbl_Patient.GroupName = SP.GroupName,
					tbl_Patient.SubGroupNbr = SP.SubGroupNbr,
					tbl_Patient.MedicareNbr = SP.MedicareNbr,
					tbl_Patient.AddressLine1 = SP.AddressLine1,
					tbl_Patient.AddressLine2 = SP.AddressLine2,
					tbl_Patient.CityName = SP.CityName,
					tbl_Patient.StateAbbr = SP.StateAbbr,
					tbl_Patient.ZipCode = SP.ZipCode,
					tbl_Patient.CountyCode = SP.CountyCode,
					tbl_Patient.PhoneNbr = SP.PhoneNbr,
					tbl_Patient.LastActivity = SP.LastActivity,
					tbl_Patient.DataHash = SP.DataHash
	WHEN NOT MATCHED THEN INSERT(PatientID, LastName, FirstName, MiddleName, NamePrefix, NameSuffix, Gender,
									DOB, DOD, SSN, InstitutionID, PatientNbr, EffDateBeg, EffDateEnd,
									GroupNbr, GroupName, SubGroupNbr, MedicareNbr, AssignedPCP,
									AddressLine1, AddressLine2, CityName, StateAbbr, ZipCode, CountyCode,
									PhoneNbr, LastActivity, DataHash) 
						VALUES(SP.LastName, SP.FirstName, SP.MiddleName, SP.NamePrefix, SP.NameSuffix, SP.Gender,
								ISNULL(SP.DOB, '01/01/1900'), SP.DOD, SP.SSN, SP.InstitutionID, SP.PatientNbr,
								SP.EffDateBeg, SP.EffDateEnd, SP.GroupNbr, SP.GroupName, SP.SubGroupNbr,
								SP.MedicareNbr, SP.AddressLine1, SP.AddressLine2, SP.CityName, SP.StateAbbr,
								SP.ZipCode, SP.CountyCode, SP.PhoneNbr, SP.LastActivity, SP.DataHash);


--	Drop indexes created on staging TABLE
	DROP INDEX IX_tbl_Stg_Patient_A ON dbo.tbl_Stg_Patient;