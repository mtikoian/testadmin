CREATE FUNCTION dbo.fnMaskSSN (@ssn char(11))
RETURNS char(11) AS
BEGIN
	DECLARE @MaskedSSN char(11);

	SELECT @MaskedSSN = 'xxx-xx-' + right(@ssn,4);
	RETURN @MaskedSSN;
END;
GO

CREATE TABLE dbo.tbl_Patient (
	PatientID int,
	FirstName varchar(32),
	LastName varchar(64),
	SSN char(11)
	);

--	Instead of the following:
SELECT p.FirstName, p.LastName, dbo.fnMaskSSN(p.SSN) as MaskedSSN
FROM dbo.tbl_Patient p;

--	Do the following:

--	Code Segment: dbo.fnMaskSSN
SELECT p.FirstName, p.LastName, 'xxx-xx-' + RIGHT(p.SSN,4) as MaskedSSN
FROM dbo.tbl_Patient p;