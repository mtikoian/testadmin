CREATE TABLE Persons   
	(PersonID      int          NOT NULL IDENTITY,    
	FirstName     nvarchar(40) NOT NULL,    
	MiddleInitial char(1)      NULL,    
	LastName      nvarchar(40) NOT NULL,    
	DateOfBirth   date         NULL,
 CONSTRAINT [PK_Persons] PRIMARY KEY CLUSTERED 
(	[PersonID] ASC) 
	WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, 
		ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) 
	ON [PRIMARY]
) ON [PRIMARY] 

GO
