use LIMS
go

SELECT Sample.SampleID, Sample.SampleDate, Analysis.AnlCode , Analyte.Analyte
	FROM dbo.Sample, dbo.Analysis, Analyte
	WHERE Sample.SampleID = Analysis.SampleID
	  AND Analyte.SampleID = Analysis.SampleID
	  AND Analyte.AnlCode = Analysis.AnlCode
	
SELECT s.SampleID, s.SampleDate, a.AnlCode --, Analyte.Analyte
	FROM dbo.Sample s
	INNER JOIN dbo.Analysis a ON a.SampleID = s.SampleID