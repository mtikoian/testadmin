

--Set the options to support indexed views.
SET NUMERIC_ROUNDABORT OFF;
SET ANSI_PADDING, ANSI_WARNINGS, CONCAT_NULL_YIELDS_NULL, ARITHABORT,
    QUOTED_IDENTIFIER, ANSI_NULLS ON;
GO

--Create view with schemabinding.
IF OBJECT_ID ('dbo.vwLocations', 'view') IS NOT NULL
DROP VIEW dbo.vwLocations ;
GO
CREATE VIEW dbo.vwLocations
WITH SCHEMABINDING
AS
	SELECT lh.LocCode, la.LocName, la.Add1, la.Add2, 
		lh.DueDays, la.City, la.State, la.ZipCode
		FROM dbo.LocHead lh
			INNER JOIN dbo.LocAdd la
				ON la.LocCode = lh.LocCode
GO
--Create an index on the view.
CREATE UNIQUE CLUSTERED INDEX idxVwLocations
    ON dbo.vwLocations (LocCode, LocName)
WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, 
		IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) 
ON [INDEX];
GO
