USE [LIMSNormal]
GO

/****** Object:  Index [idxSampHead_LocCodeLocName_Include]    Script Date: 01/13/2010 14:16:39 ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[SampHead]') AND name = N'idxSampHead_LocCodeLocName_Include')
DROP INDEX [idxSampHead_LocCodeLocName_Include] ON [dbo].[SampHead] WITH ( ONLINE = OFF )
GO


--Create an index on the view.
CREATE NONCLUSTERED INDEX idxSampHead_LocCodeLocName_Include
    ON dbo.SampHead (LocCode, LocName)
    INCLUDE (SampDesc, SampDate)
WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, 
		IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) 
ON [INDEX];
GO
