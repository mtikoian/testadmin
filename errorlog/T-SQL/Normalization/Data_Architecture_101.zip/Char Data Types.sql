--  ptp  20150611  Character data types

WITH b AS (
SELECT N'Hello, world!' AS c
), primative AS (
SELECT 50 AS o, 'NVARCHAR Hex' AS t, Cast(     c             AS VARBINARY) AS h FROM b UNION
SELECT 40 AS o, 'NCHAR Hex' AS t,    Cast(Cast(c AS   NCHAR) AS VARBINARY) AS h FROM b UNION
SELECT 20 AS o, 'VARCHAR Hex' AS t,  Cast(Cast(c AS VARCHAR) AS VARBINARY) AS h FROM b UNION
SELECT 30 AS o, 'CHAR Hex' AS t,     Cast(Cast(c AS    CHAR) AS VARBINARY) AS h FROM b 
), bytes AS (
SELECT o, t, DATALENGTH(h) AS b, h
   FROM primative
)
SELECT b AS bytes, t AS DataType, h AS Hexadecimal
   FROM bytes
   ORDER BY o
