--  ptp  20150611  Numeric data types

WITH b AS (
SELECT Pi() AS f
), primative AS (
SELECT 20 AS o, 'L' AS c, 'TINYINT' AS T,    Cast(Cast(f AS TINYINT)    AS VARBINARY) AS H FROM b UNION
SELECT 20 AS o, 'R' AS c, 'SMALLINT' AS T,   Cast(Cast(f AS SMALLINT)   AS VARBINARY) AS H FROM b UNION
SELECT 30 AS o, 'L' AS c, 'INT' AS T,        Cast(Cast(f AS INT)        AS VARBINARY) AS H FROM b UNION
SELECT 30 AS o, 'R' AS c, 'BIGINT' AS T,     Cast(Cast(f AS BIGINT)     AS VARBINARY) AS H FROM b UNION
SELECT 40 AS o, 'L' AS c, 'SMALLMONEY' AS T, Cast(Cast(f AS SMALLMONEY) AS VARBINARY) AS H FROM b UNION
SELECT 40 AS o, 'R' AS c, 'MONEY' AS T,      Cast(Cast(f AS MONEY)      AS VARBINARY) AS H FROM b UNION
SELECT 50 AS o, 'L' AS c, 'DECIMAL' AS T,    Cast(Cast(f AS DECIMAL)    AS VARBINARY) AS H FROM b UNION
SELECT 50 AS o, 'R' AS c, 'NUMERIC' AS T,    Cast(Cast(f AS NUMERIC)    AS VARBINARY) AS H FROM b UNION
SELECT 60 AS o, 'L' AS c, 'FLOAT' AS T,      Cast(Cast(f AS FLOAT)      AS VARBINARY) AS H FROM b UNION
SELECT 60 AS o, 'R' AS c, 'REAL'  AS T,      Cast(Cast(f AS REAL)       AS VARBINARY) AS H FROM b
), with_bytes AS (
SELECT DataLength(H) AS bytes, *
   FROM primative
)
SELECT L.bytes, L.T AS DataType, L.H AS Hexadecimal, R.bytes, R.T AS DataType, R.H AS Hexadecimal
   FROM with_bytes AS L
   LEFT JOIN with_bytes AS R
      ON (R.o = L.o
	  AND 'R' = R.c)
   WHERE  'L' = L.c
   ORDER BY L.o
