--  ptp  20150611  Temporal data types

WITH b AS (
SELECT Cast('1969-07-20 20:18' AS DATETIME2) AS d
), primatives AS (
SELECT 20 AS o, 'datetime2'     AS t, Cast(d                        AS VARBINARY) AS h FROM b UNION
SELECT 50 AS o, 'datetime'      AS t, Cast(Cast(d AS DATETIME)      AS VARBINARY) AS h FROM b UNION
SELECT 60 AS o, 'smalldatetime' AS t, Cast(Cast(d AS SMALLDATETIME) AS VARBINARY) AS h FROM b UNION
SELECT 30 AS o, 'date'          AS t, Cast(Cast(d AS DATE)          AS VARBINARY) AS h FROM b UNION
SELECT 40 AS o, 'time'          AS t, Cast(Cast(d AS TIME)          AS VARBINARY) AS h FROM b
)
SELECT DATALENGTH(h) AS bytes, t AS DataType, h AS Hexadecimal
   FROM primatives
   ORDER BY o
