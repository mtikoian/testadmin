use ContosoRetailDW
go
-- based on AdventureWorks2014.Sales.SalesOrderDetail
/* dont run -- use go 50 only
CREATE TABLE [MKSalesOrderDetail](
	[SalesOrderID] [int] NOT NULL,
	[SalesOrderDetailID] [int]  NOT NULL,
	[CarrierTrackingNumber] [nvarchar](25) NULL,
	[OrderQty] [smallint] NOT NULL,
	[ProductID] [int] NOT NULL,
	[SpecialOfferID] [int] NOT NULL,
	[UnitPrice] [money] NOT NULL,
	[UnitPriceDiscount] [money] NOT NULL,
	[LineTotal]  numeric(38,6),
	[rowguid] [uniqueidentifier]   NOT NULL,
	[ModifiedDate] [datetime] NOT NULL
	) ON [PRIMARY]

	go

insert into [MKSalesOrderDetail] 
select * from AdventureWorks2014.Sales.SalesOrderDetail
go 50 -- will take 32 sec
*/
exec sp_spaceused 'MKSalesOrderDetail' -- base table

CREATE TABLE [MKSalesOrderDetail_Demo](
	[SalesOrderID] [int] NOT NULL,
	[SalesOrderDetailID] [int]  NOT NULL,
	[CarrierTrackingNumber] [nvarchar](25) NULL,
	[OrderQty] [smallint] NOT NULL,
	[ProductID] [int] NOT NULL,
	[SpecialOfferID] [int] NOT NULL,
	[UnitPrice] [money] NOT NULL,
	[UnitPriceDiscount] [money] NOT NULL,
	[LineTotal]  numeric(38,6),
	[rowguid] [uniqueidentifier]   NOT NULL,
	[ModifiedDate] [datetime] NOT NULL
	) ON [PRIMARY]

	go
	-- to show  imports
Create clustered columnstore   INDEX [cci_MKSalesOrderDetail] ON [dbo].[MKSalesOrderDetail_demo] 
go
-- Please remind me to Turn EXECUTION PLAN ON!!!!
set statistics io on
go
insert into [MKSalesOrderDetail_Demo] 
select * from MKSalesOrderDetail
go -- will take 21 sec -- note the plan
-- look at rowgroups informaation

insert into [MKSalesOrderDetail_Demo] with (tablock)
select * from MKSalesOrderDetail -- takes 13 sec

delete from MKSalesOrderDetail_Demo
where SalesOrderId> 70000 -- takes 7 sec
-- run the Demo3 again and note the deleted rows column but no changes made to other columns

update MKSalesOrderDetail_Demo
set SalesOrderID=1
where SalesOrderId between 40000 and 45000 -- takes 8 sec
-- note the open filegorups now
GO
update MKSalesOrderDetail_Demo
set SalesOrderID=1
where SalesOrderId between 10000 and 40000 -- takes 1 sec
-- note the open filegorups now
GO
-- This command will force all CLOSED and OPEN rowgroups into the columnstore.  
alter index [cci_MKSalesOrderDetail] on [MKSalesOrderDetail_demo] reorganize -- takes 36 sec
-- notice tombstone -- to be removed later
alter index [cci_MKSalesOrderDetail] on [MKSalesOrderDetail_demo] reorganize WITH (COMPRESS_ALL_ROW_GROUPS = ON) -- takes 6 sec
alter index [cci_MKSalesOrderDetail] on [MKSalesOrderDetail_demo] rebuild -- takes 23 sec
-- TADA!!!!

go
 
drop table [MKSalesOrderDetail_Demo]