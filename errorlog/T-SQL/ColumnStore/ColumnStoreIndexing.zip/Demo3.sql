use ContosoRetailDW
go
SELECT

csrg.object_id

,csrg.index_id

,csrg.row_group_id

,csrg.delta_store_hobt_id

,csrg.state_description

,csrg.total_rows

,csrg.deleted_rows

,size_in_MB = (csrg.size_in_bytes/1000000.00)

FROM

sys.column_store_row_groups AS csrg

WHERE

OBJECT_NAME(csrg.object_id) ='MKSalesOrderDetail_Demo'


--Tombstone Row Groups - the Delta-Stores that got compressed and needed to be removed by the Garbage Collector by the Tuple Mover.