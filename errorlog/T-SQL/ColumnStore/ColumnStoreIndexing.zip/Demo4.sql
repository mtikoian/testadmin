-- we have NCCI from Demo1 on ContosoRetailDW2014
----------------simple aggregae pushdown -- SalesQuantity int---------------------
set statistics time on
use ContosoRetailDW2014
go
select max(SalesQuantity)
    from dbo.FactOnlineSales;--CPU time = 0 ms,  elapsed time = 52 ms
	-- locally aggregated rows.
use ContosoRetailDW
go
select max(SalesQuantity)
    from dbo.FactOnlineSales;--CPU time = 0 ms,  elapsed time = 6 ms
set statistics time  on



----------------- String aggregate pushdown--SalesOrderNumber	nvarchar------------------------
use ContosoRetailDW2014
go
select max(SalesOrderNumber)
	from dbo.FactOnlineSales; --CPU time = 4407 ms,  elapsed time = 1619 ms.
---- Print 2016 results now
use ContosoRetailDW
go
select max(SalesOrderNumber)
	from dbo.FactOnlineSales; -- CPU time = 5031 ms,  elapsed time = 1584 ms

--	sp_help 'FactOnlineSales'
-----------------------------------CCI--------------------------------------------------------
-- clustered column store index and string aggregate push down?
--I have FactOnlineSales_CCI from FactOnlineSales with CCI



-- String aggregate pushdown--SalesOrderNumber	nvarchar
use ContosoRetailDW2014
go
select max(SalesOrderNumber)
	from dbo.FactOnlineSales_CCI; --CPU time = 4890 ms,  elapsed time = 1596 ms.
---- Print 2016 results now
use ContosoRetailDW --CPU time = 4640 ms,  elapsed time = 1436 ms
go
select max(SalesOrderNumber) --CPU time = 4640 ms,  elapsed time = 1436 ms
	from dbo.FactOnlineSales_CCI; 