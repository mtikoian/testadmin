-- turn execution plan on
set statistics IO on
go
use ContosoRetailDW
go
 DBCC DROPCLEANBUFFERS 
 go
WITH ContosoProducts
AS (SELECT *
    FROM   dbo.DimProduct
   -- WHERE  BrandName                    = 'Contoso'
	)
SELECT     cp.ProductName,
           dd.CalendarQuarter,
           COUNT(fos.SalesOrderNumber) AS NumOrders,
           SUM(fos.SalesQuantity)      AS QuantitySold
FROM       dbo.FactOnlineSales         AS fos
INNER JOIN dbo.DimDate                 AS dd
      ON   dd.Datekey                   = fos.DateKey
RIGHT JOIN ContosoProducts             AS cp
      ON   cp.ProductKey                = fos.ProductKey
GROUP BY   cp.ProductName,
           dd.CalendarQuarter
ORDER BY   cp.ProductName,
           dd.CalendarQuarter OPTION(IGNORE_NONCLUSTERED_COLUMNSTORE_INDEX) 
		   ;
/*
NOTE:
logical reads as opposed to Segment reads 13
Execution time
Execution mode 

*/
-- And then re-run with OPTION(IGNORE_NONCLUSTERED_COLUMNSTORE_INDEX) commented out

----------------------------------------Batch Execution v/s row execution---------------------
--OPTION (QUERYTRACEON 9453)
 DBCC DROPCLEANBUFFERS 
 go
WITH ContosoProducts
AS (SELECT *
    FROM   dbo.DimProduct
   -- WHERE  BrandName                    = 'Contoso'
	)
SELECT     cp.ProductName,
           dd.CalendarQuarter,
           COUNT(fos.SalesOrderNumber) AS NumOrders,
           SUM(fos.SalesQuantity)      AS QuantitySold
FROM       dbo.FactOnlineSales         AS fos
INNER JOIN dbo.DimDate                 AS dd
      ON   dd.Datekey                   = fos.DateKey
RIGHT JOIN ContosoProducts             AS cp
      ON   cp.ProductKey                = fos.ProductKey
GROUP BY   cp.ProductName,
           dd.CalendarQuarter
ORDER BY   cp.ProductName,
           dd.CalendarQuarter OPTION (QUERYTRACEON 9453)
go