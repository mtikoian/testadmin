-- to show rowgroups, segment
use contosoRetailDW
go
SELECT     OBJECT_NAME(rg.object_id)   AS TableName,
           i.name                      AS IndexName,
           i.type_desc                 AS IndexType,
           rg.partition_number,
           rg.row_group_id,
           rg.total_rows,
           rg.size_in_bytes
FROM       sys.column_store_row_groups AS rg
INNER JOIN sys.indexes                 AS i
      ON   i.object_id                  = rg.object_id
      AND  i.index_id                   = rg.index_id
WHERE      i.name IN (N'NCI_FactOnlineSales')
ORDER BY   TableName, IndexName,rg.partition_number, rg.row_group_id;

USE ContosoRetailDW;
GO

SELECT     OBJECT_NAME(i.object_id)          AS TableName,
           i.name                            AS IndexName,
           i.type_desc                       AS IndexType,
           COALESCE(c.name, '* Internal *')  AS ColumnName,
           p.partition_number,
           s.segment_id,
           s.row_count,
           s.on_disk_size,
           s.min_data_id,
           s.max_data_id
FROM       sys.column_store_segments         AS s
INNER JOIN sys.partitions                    AS p 
      ON   p.hobt_id                          = s.hobt_id
INNER JOIN sys.indexes                       AS i 
      ON   i.object_id                        = p.object_id
      AND  i.index_id                         = p.index_id
LEFT  JOIN sys.index_columns                 AS ic
      ON   ic.object_id                       = i.object_id
      AND  ic.index_id                        = i.index_id
      AND  ic.index_column_id                 = s.column_id
LEFT  JOIN sys.columns                       AS c
      ON   c.object_id                        = ic.object_id
      AND  c.column_id                        = ic.column_id
WHERE      i.name                            IN (N'NCI_FactOnlineSales')
ORDER BY   TableName, IndexName,
           s.column_id, p.partition_number, s.segment_id;