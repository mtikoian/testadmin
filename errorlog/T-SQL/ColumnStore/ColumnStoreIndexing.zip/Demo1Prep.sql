use ContosoRetailDW
go
-- I have this already -- just show, dont run
CREATE NONCLUSTERED COLUMNSTORE INDEX NCI_FactOnlineSales
ON dbo.FactOnlineSales
   (OnlineSalesKey,
    DateKey,
    StoreKey,
    ProductKey,
    PromotionKey,
    CurrencyKey,
    CustomerKey,
    SalesOrderNumber,
    SalesOrderLineNumber,
    SalesQuantity,
    SalesAmount,
    ReturnQuantity,
    ReturnAmount,
    DiscountQuantity,
    DiscountAmount,
    TotalCost,
    UnitCost,
    UnitPrice,
    ETLLoadID,
    LoadDate,
    UpdateDate);

	
-- if you want to create a clustered column store index, it will be as follows
CREATE clustered COLUMNSTORE INDEX CCI_FactOnlineSales ON dbo.FactOnlineSales

drop index CCI_FactOnlineSales ON dbo.FactOnlineSales
USE [ContosoRetailDW]
GO


ALTER TABLE [dbo].[FactOnlineSales] DROP CONSTRAINT [PK_FactOnlineSales_SalesKey]
GO

/****** Object:  Index [PK_FactOnlineSales_SalesKey]    Script Date: 9/27/2016 11:11:30 PM ******/
ALTER TABLE [dbo].[FactOnlineSales] ADD  CONSTRAINT [PK_FactOnlineSales_SalesKey] PRIMARY KEY CLUSTERED 
(
	[OnlineSalesKey] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO



USE [ContosoRetailDW]
GO
CREATE NONCLUSTERED INDEX idx_FactOnlineSales
ON [dbo].[FactOnlineSales] ([DateKey])
INCLUDE ([ProductKey],[SalesOrderNumber],[SalesQuantity])

drop   INDEX idx_FactOnlineSales
ON [dbo].[FactOnlineSales]

drop  INDEX NCI_FactOnlineSales
ON dbo.FactOnlineSales