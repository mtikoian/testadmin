use [AdventureWorksDW2012]
go

set statistics io on;
set statistics time on;
go

insert into [dbo].[FactInternetSales_ColumnStoreA]
	([ProductKey], [OrderDateKey], [DueDateKey], [ShipDateKey], [CustomerKey], [PromotionKey], [CurrencyKey], [SalesTerritoryKey], [SalesOrderNumber], [SalesOrderLineNumber], [RevisionNumber], [OrderQuantity], [UnitPrice], [ExtendedAmount], [UnitPriceDiscountPct], [DiscountAmount], [ProductStandardCost], [TotalProductCost], [SalesAmount], [TaxAmt], [Freight], [CarrierTrackingNumber], [CustomerPONumber], [OrderDate], [DueDate], [ShipDate])
select
	[ProductKey]
	,convert(varchar,dateadd(day,-1,convert(datetime,convert(varchar,[OrderDateKey]),112)),112) as [OrderDateKey]
	,convert(varchar,dateadd(day,-1,convert(datetime,convert(varchar,[DueDateKey]),112)),112) as [DueDateKey]
	,convert(varchar,dateadd(day,-1,convert(datetime,convert(varchar,[ShipDateKey]),112)),112) as [ShipDateKey]
	,[CustomerKey], [PromotionKey], [CurrencyKey], [SalesTerritoryKey], [SalesOrderNumber], [SalesOrderLineNumber], [RevisionNumber], [OrderQuantity], [UnitPrice], [ExtendedAmount], [UnitPriceDiscountPct], [DiscountAmount], [ProductStandardCost], [TotalProductCost], [SalesAmount], [TaxAmt], [Freight], [CarrierTrackingNumber], [CustomerPONumber]
	,dateadd(day,-1,[OrderDate]) as [OrderDate]
	,dateadd(day,-1,[DueDate]) as [DueDate]
	,dateadd(day,-1,[ShipDate]) as [ShipDate]
from
	[dbo].[FactInternetSales];

go

set statistics io off;
set statistics time off;
go
