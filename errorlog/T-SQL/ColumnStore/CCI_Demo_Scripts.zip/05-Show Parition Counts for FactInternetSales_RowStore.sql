use [AdventureWorksDW2012]
go

-- Show space used
exec [sp_spaceused] '[dbo].[FactInternetSales_RowStore]';
go

-- Show counts (and partition boundary values) for each non-empty partition
select
	$partition.[pf_Quarters_DateTime]([OrderDate]) as [PartitionNumber]
	,count(*) as [RecordCount]
	,min([OrderDate]) as [MinOrderDate]
	,max([OrderDate]) as [MaxOrderDate]
from
	[dbo].[FactInternetSales_RowStore]
group by
	$partition.[pf_Quarters_DateTime]([OrderDate])
order by
	[PartitionNumber];
go

