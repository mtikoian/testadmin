use [AdventureWorksDW2012]
go

-- Create table with primary key constraint and index
if not exists (select * from [sys].[objects] where [object_id] = object_id('[dbo].[FactInternetSales_RowStore]') and [type] in ('U'))
	create table [dbo].[FactInternetSales_RowStore]
		(
		[ProductKey] [int] not null
		,[OrderDateKey] [int] not null
		,[DueDateKey] [int] not null
		,[ShipDateKey] [int] not null
		,[CustomerKey] [int] not null
		,[PromotionKey] [int] not null
		,[CurrencyKey] [int] not null
		,[SalesTerritoryKey] [int] not null
		,[SalesOrderNumber] [nvarchar](20) not null
		,[SalesOrderLineNumber] [tinyint] not null
		,[RevisionNumber] [tinyint] not null
		,[OrderQuantity] [smallint] not null
		,[UnitPrice] [money] not null
		,[ExtendedAmount] [money] not null
		,[UnitPriceDiscountPct] [float] not null
		,[DiscountAmount] [float] not null
		,[ProductStandardCost] [money] not null
		,[TotalProductCost] [money] not null
		,[SalesAmount] [money] not null
		,[TaxAmt] [money] not null
		,[Freight] [money] not null
		,[CarrierTrackingNumber] [nvarchar](25) null
		,[CustomerPONumber] [nvarchar](25) null
		,[OrderDate] [datetime] not null
		,[DueDate] [datetime] null
		,[ShipDate] [datetime] null
		constraint [pk_FactInternetSales_RowStore__SalesOrderNumber_SalesOrderLineNumber_OrderDate] primary key clustered
			(
			[SalesOrderNumber] asc
			,[SalesOrderLineNumber] asc
			,[OrderDate] asc
			)
			with (pad_index = off, statistics_norecompute = off, ignore_dup_key = off, allow_row_locks = on, allow_page_locks = on, data_compression = page) on [ps_Quarters_DateTime]([OrderDate])
		) on [ps_Quarters_DateTime]([OrderDate]);
go

-- Create foreign key references
if not exists (select * from [sys].[foreign_keys] where [object_id] = object_id('[dbo].[fk_FactInternetSales_RowStore__CurrencyKey]') and [parent_object_id] = object_id('[dbo].[FactInternetSales_RowStore]'))
	begin
	alter table [dbo].[FactInternetSales_RowStore]
		with check add constraint [fk_FactInternetSales_RowStore__CurrencyKey] foreign key([CurrencyKey])
		references [dbo].[DimCurrency]([CurrencyKey]);
	alter table [dbo].[FactInternetSales_RowStore]
		check constraint [fk_FactInternetSales_RowStore__CurrencyKey];
	end
go

if not exists (select * from [sys].[foreign_keys] where [object_id] = object_id('[dbo].[fk_FactInternetSales_RowStore__CustomerKey]') and [parent_object_id] = object_id('[dbo].[FactInternetSales_RowStore]'))
	begin
	alter table [dbo].[FactInternetSales_RowStore]
		with check add constraint [fk_FactInternetSales_RowStore__CustomerKey] foreign key([CustomerKey])
		references [dbo].[DimCustomer]([CustomerKey]);
	alter table [dbo].[FactInternetSales_RowStore]
		check constraint [fk_FactInternetSales_RowStore__CustomerKey];
	end
go

if not exists (select * from [sys].[foreign_keys] where [object_id] = object_id('[dbo].[fk_FactInternetSales_RowStore__DueDateKey]') and [parent_object_id] = object_id('[dbo].[FactInternetSales_RowStore]'))
	begin
	alter table [dbo].[FactInternetSales_RowStore]
		with check add constraint [fk_FactInternetSales_RowStore__DueDateKey] foreign key([DueDateKey])
		references [dbo].[DimDate]([DateKey]);
	alter table [dbo].[FactInternetSales_RowStore]
		check constraint [fk_FactInternetSales_RowStore__DueDateKey];
	end
go

if not exists (select * from [sys].[foreign_keys] where [object_id] = object_id('[dbo].[fk_FactInternetSales_RowStore__OrderDateKey]') and [parent_object_id] = object_id('[dbo].[FactInternetSales_RowStore]'))
	begin
	alter table [dbo].[FactInternetSales_RowStore]
		with check add constraint [fk_FactInternetSales_RowStore__OrderDateKey] foreign key([OrderDateKey])
		references [dbo].[DimDate]([DateKey]);
	alter table [dbo].[FactInternetSales_RowStore]
		check constraint [fk_FactInternetSales_RowStore__OrderDateKey];
	end
go

if not exists (select * from [sys].[foreign_keys] where [object_id] = object_id('[dbo].[fk_FactInternetSales_RowStore__ProductKey]') and [parent_object_id] = object_id('[dbo].[FactInternetSales_RowStore]'))
	begin
	alter table [dbo].[FactInternetSales_RowStore]
		with check add constraint [fk_FactInternetSales_RowStore__ProductKey] foreign key([ProductKey])
		references [dbo].[DimProduct]([ProductKey]);
	alter table [dbo].[FactInternetSales_RowStore]
		check constraint [fk_FactInternetSales_RowStore__ProductKey];
	end
go

if not exists (select * from [sys].[foreign_keys] where [object_id] = object_id('[dbo].[fk_FactInternetSales_RowStore__PromotionKey]') and [parent_object_id] = object_id('[dbo].[FactInternetSales_RowStore]'))
	begin
	alter table [dbo].[FactInternetSales_RowStore]
		with check add constraint [fk_FactInternetSales_RowStore__PromotionKey] foreign key([PromotionKey])
		references [dbo].[DimPromotion]([PromotionKey]);
	alter table [dbo].[FactInternetSales_RowStore]
		check constraint [fk_FactInternetSales_RowStore__PromotionKey];
	end
go

if not exists (select * from [sys].[foreign_keys] where [object_id] = object_id('[dbo].[fk_FactInternetSales_RowStore__SalesTerritoryKey]') and [parent_object_id] = object_id('[dbo].[FactInternetSales_RowStore]'))
	begin
	alter table [dbo].[FactInternetSales_RowStore]
		with check add constraint [fk_FactInternetSales_RowStore__SalesTerritoryKey] foreign key([SalesTerritoryKey])
		references [dbo].[DimSalesTerritory]([SalesTerritoryKey]);
	alter table [dbo].[FactInternetSales_RowStore]
		check constraint [fk_FactInternetSales_RowStore__SalesTerritoryKey];
	end
go

if not exists (select * from [sys].[foreign_keys] where [object_id] = object_id('[dbo].[fk_FactInternetSales_RowStore__ShipDateKey]') and [parent_object_id] = object_id('[dbo].[FactInternetSales_RowStore]'))
	begin
	alter table [dbo].[FactInternetSales_RowStore]
		with check add constraint [fk_FactInternetSales_RowStore__ShipDateKey] foreign key([ShipDateKey])
		references [dbo].[DimDate]([DateKey]);
	alter table [dbo].[FactInternetSales_RowStore]
		check constraint [fk_FactInternetSales_RowStore__ShipDateKey];
	end
go

-- Create indexes to support foreign keys (for typical data warehouse join patterns)
if not exists (select * from [sys].[indexes] where [object_id] = object_id('[dbo].[FactInternetSales_RowStore]') and [name] = 'fk_FactInternetSales_RowStore__CurrencyKey')
	create nonclustered index [fk_FactInternetSales_RowStore__CurrencyKey] on [dbo].[FactInternetSales_RowStore]
		(
		[CurrencyKey] asc
		)
		with (pad_index = off, statistics_norecompute = off, sort_in_tempdb = off, drop_existing = off, online = off, allow_row_locks = on, allow_page_locks = on, data_compression = page) on [ps_Quarters_DateTime]([OrderDate]);
go

if not exists (select * from [sys].[indexes] where [object_id] = object_id('[dbo].[FactInternetSales_RowStore]') and [name] = 'fk_FactInternetSales_RowStore__CustomerKey')
	create nonclustered index [fk_FactInternetSales_RowStore__CustomerKey] on [dbo].[FactInternetSales_RowStore]
		(
		[CustomerKey] asc
		)
		with (pad_index = off, statistics_norecompute = off, sort_in_tempdb = off, drop_existing = off, online = off, allow_row_locks = on, allow_page_locks = on, data_compression = page) on [ps_Quarters_DateTime]([OrderDate]);
go

if not exists (select * from [sys].[indexes] where [object_id] = object_id('[dbo].[FactInternetSales_RowStore]') and [name] = 'fk_FactInternetSales_RowStore__DueDateKey')
	create nonclustered index [fk_FactInternetSales_RowStore__DueDateKey] on [dbo].[FactInternetSales_RowStore]
		(
		[DueDateKey] asc
		)
		with (pad_index = off, statistics_norecompute = off, sort_in_tempdb = off, drop_existing = off, online = off, allow_row_locks = on, allow_page_locks = on, data_compression = page) on [ps_Quarters_DateTime]([OrderDate]);
go

if not exists (select * from [sys].[indexes] where [object_id] = object_id('[dbo].[FactInternetSales_RowStore]') and [name] = 'fk_FactInternetSales_RowStore__OrderDateKey')
	create nonclustered index [fk_FactInternetSales_RowStore__OrderDateKey] on [dbo].[FactInternetSales_RowStore]
		(
		[OrderDateKey] asc
		)
		with (pad_index = off, statistics_norecompute = off, sort_in_tempdb = off, drop_existing = off, online = off, allow_row_locks = on, allow_page_locks = on, data_compression = page) on [ps_Quarters_DateTime]([OrderDate]);
go

if not exists (select * from [sys].[indexes] where [object_id] = object_id('[dbo].[FactInternetSales_RowStore]') and [name] = 'fk_FactInternetSales_RowStore__ProductKey')
	create nonclustered index [fk_FactInternetSales_RowStore__ProductKey] on [dbo].[FactInternetSales_RowStore]
		(
		[ProductKey] asc
		)
		with (pad_index = off, statistics_norecompute = off, sort_in_tempdb = off, drop_existing = off, online = off, allow_row_locks = on, allow_page_locks = on, data_compression = page) on [ps_Quarters_DateTime]([OrderDate]);
go

if not exists (select * from [sys].[indexes] where [object_id] = object_id('[dbo].[FactInternetSales_RowStore]') and [name] = 'fk_FactInternetSales_RowStore__PromotionKey')
	create nonclustered index [fk_FactInternetSales_RowStore__PromotionKey] on [dbo].[FactInternetSales_RowStore]
		(
		[PromotionKey] asc
		)
		with (pad_index = off, statistics_norecompute = off, sort_in_tempdb = off, drop_existing = off, online = off, allow_row_locks = on, allow_page_locks = on, data_compression = page) on [ps_Quarters_DateTime]([OrderDate]);
go

if not exists (select * from [sys].[indexes] where [object_id] = object_id('[dbo].[FactInternetSales_RowStore]') and [name] = 'fk_FactInternetSales_RowStore__SalesTerritoryKey')
	create nonclustered index [fk_FactInternetSales_RowStore__SalesTerritoryKey] on [dbo].[FactInternetSales_RowStore]
		(
		[SalesTerritoryKey] asc
		)
		with (pad_index = off, statistics_norecompute = off, sort_in_tempdb = off, drop_existing = off, online = off, allow_row_locks = on, allow_page_locks = on, data_compression = page) on [ps_Quarters_DateTime]([OrderDate]);
go

if not exists (select * from [sys].[indexes] where [object_id] = object_id('[dbo].[FactInternetSales_RowStore]') and [name] = 'fk_FactInternetSales_RowStore__ShipDateKey')
	create nonclustered index [fk_FactInternetSales_RowStore__ShipDateKey] on [dbo].[FactInternetSales_RowStore]
		(
		[ShipDateKey] asc
		)
		with (pad_index = off, statistics_norecompute = off, sort_in_tempdb = off, drop_existing = off, online = off, allow_row_locks = on, allow_page_locks = on, data_compression = page) on [ps_Quarters_DateTime]([OrderDate]);
go

