use [AdventureWorksDW2012]
go

set statistics io on;
set statistics time on;
go

select
	*
from
	dbo.FactInternetSales_RowStore
where
	[SalesOrderNumber] = 'SO51196'
	and [OrderDateKey] = 20071010
order by
	[SalesOrderLineNumber]
;
go

set statistics io off;
set statistics time off;
go
