use [AdventureWorksDW2012]
go

-- Create a new filegroup and file for partitioning
if not exists (select * from sys.filegroups where [name] = N'PartitionedData')
	begin
	alter database [AdventureWorksDW2012]
		add filegroup [PartitionedData];
	alter database [AdventureWorksDW2012]
		add file
			(
			name = N'PartitionedData'
			,filename = N'C:\Program Files\Microsoft SQL Server\MSSQL11.MSSQLSERVER\MSSQL\DATA\PartitionedData.ndf'
			,size = 4096MB
			,filegrowth = 512MB
			)
			to filegroup
				[PartitionedData];
	end
go

-- Create a new quarterly partition function for partitioning
if not exists (select * from sys.partition_functions where [name] = N'pf_Quarters_DateTime')
	create partition function [pf_Quarters_DateTime](datetime) as
		range right for values
			(
			N'2005-01-01T00:00:00.000',N'2005-04-01T00:00:00.000',N'2005-07-01T00:00:00.000',N'2005-10-01T00:00:00.000'
			,N'2006-01-01T00:00:00.000',N'2006-04-01T00:00:00.000',N'2006-07-01T00:00:00.000',N'2006-10-01T00:00:00.000'
			,N'2007-01-01T00:00:00.000',N'2007-04-01T00:00:00.000',N'2007-07-01T00:00:00.000',N'2007-10-01T00:00:00.000'
			,N'2008-01-01T00:00:00.000',N'2008-04-01T00:00:00.000',N'2008-07-01T00:00:00.000',N'2008-10-01T00:00:00.000'
			,N'2009-01-01T00:00:00.000',N'2009-04-01T00:00:00.000',N'2009-07-01T00:00:00.000',N'2009-10-01T00:00:00.000'
			,N'2010-01-01T00:00:00.000',N'2010-04-01T00:00:00.000',N'2010-07-01T00:00:00.000',N'2010-10-01T00:00:00.000'
			,N'2011-01-01T00:00:00.000',N'2011-04-01T00:00:00.000',N'2011-07-01T00:00:00.000',N'2011-10-01T00:00:00.000'
			,N'2012-01-01T00:00:00.000',N'2012-04-01T00:00:00.000',N'2012-07-01T00:00:00.000',N'2012-10-01T00:00:00.000'
			,N'2013-01-01T00:00:00.000',N'2013-04-01T00:00:00.000',N'2013-07-01T00:00:00.000',N'2013-10-01T00:00:00.000'
			,N'2014-01-01T00:00:00.000',N'2014-04-01T00:00:00.000',N'2014-07-01T00:00:00.000',N'2014-10-01T00:00:00.000'
			,N'2015-01-01T00:00:00.000',N'2015-04-01T00:00:00.000',N'2015-07-01T00:00:00.000',N'2015-10-01T00:00:00.000'
			);
go

-- Create a new partition scheme for the partition function, using the partitioned data filegroup
if not exists (select * from sys.partition_schemes where [name] = N'ps_Quarters_DateTime')
	create partition scheme [ps_Quarters_DateTime] as
		partition [pf_Quarters_DateTime] to
			(
			[PartitionedData],[PartitionedData],[PartitionedData],[PartitionedData]
			,[PartitionedData],[PartitionedData],[PartitionedData],[PartitionedData]
			,[PartitionedData],[PartitionedData],[PartitionedData],[PartitionedData]
			,[PartitionedData],[PartitionedData],[PartitionedData],[PartitionedData]
			,[PartitionedData],[PartitionedData],[PartitionedData],[PartitionedData]
			,[PartitionedData],[PartitionedData],[PartitionedData],[PartitionedData]
			,[PartitionedData],[PartitionedData],[PartitionedData],[PartitionedData]
			,[PartitionedData],[PartitionedData],[PartitionedData],[PartitionedData]
			,[PartitionedData],[PartitionedData],[PartitionedData],[PartitionedData]
			,[PartitionedData],[PartitionedData],[PartitionedData],[PartitionedData]
			,[PartitionedData],[PartitionedData],[PartitionedData],[PartitionedData]
			);
go
