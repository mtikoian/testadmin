use [AdventureWorksDW2012]
go

-- Review average fragmentation level of each index across the partitions of the table
select
	i.[name] as [IndexName]
	,round(avg(round(s.[avg_fragmentation_in_percent], 2)), 2) as [FragmentationPercent]
from
	sys.dm_db_index_physical_stats(db_id('AdventureWorksDW2012'), object_id('FactInternetSales_RowStore'), null, null, null) s
	inner join sys.indexes i on
		s.[object_id] = i.[object_id]
		and s.[index_id] = i.[index_id]
group by
	i.[name];
go

-- Rebuild all indexes to remove any fragmentation that exists
/*
alter index all on dbo.FactInternetSales_RowStore
	rebuild;
go
*/

-- Note that the same technique does not work for a table with a clustered columnstore index
select
	i.[name] as [IndexName]
	,round(avg(round(s.[avg_fragmentation_in_percent], 2)), 2) as [FragmentationPercent]
from
	sys.dm_db_index_physical_stats(db_id('AdventureWorksDW2012'), object_id('FactInternetSales_ColumnStoreA'), null, null, null) s
	inner join sys.indexes i on
		s.[object_id] = i.[object_id]
		and s.[index_id] = i.[index_id]
group by
	i.[name];
go
