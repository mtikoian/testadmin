use [AdventureWorksDW2012]
go

-- Create table (*without* any primary key constraint or other constraints)
if not exists (select * from [sys].[objects] where [object_id] = object_id('[dbo].[FactInternetSales_ColumnStoreB]') and [type] in ('U'))
	create table [dbo].[FactInternetSales_ColumnStoreB]
		(
		[ProductKey] [int] not null
		,[OrderDateKey] [int] not null
		,[DueDateKey] [int] not null
		,[ShipDateKey] [int] not null
		,[CustomerKey] [int] not null
		,[PromotionKey] [int] not null
		,[CurrencyKey] [int] not null
		,[SalesTerritoryKey] [int] not null
		,[SalesOrderNumber] [nvarchar](20) not null
		,[SalesOrderLineNumber] [tinyint] not null
		,[RevisionNumber] [tinyint] not null
		,[OrderQuantity] [smallint] not null
		,[UnitPrice] [money] not null
		,[ExtendedAmount] [money] not null
		,[UnitPriceDiscountPct] [float] not null
		,[DiscountAmount] [float] not null
		,[ProductStandardCost] [money] not null
		,[TotalProductCost] [money] not null
		,[SalesAmount] [money] not null
		,[TaxAmt] [money] not null
		,[Freight] [money] not null
		,[CarrierTrackingNumber] [nvarchar](25) null
		,[CustomerPONumber] [nvarchar](25) null
		,[OrderDate] [datetime] not null
		,[DueDate] [datetime] null
		,[ShipDate] [datetime] null
		) on [ps_Quarters_DateTime]([OrderDate]);
go

-- Create clustered columnstore index
if not exists (select * from [sys].[indexes] where [object_id] = object_id('[dbo].[FactInternetSales_ColumnStoreB]') and [name] = 'cci_FactInternetSales_ColumnStoreB')
	create clustered columnstore index [cci_FactInternetSales_ColumnStoreB] on [dbo].[FactInternetSales_ColumnStoreB]
		on [ps_Quarters_DateTime]([OrderDate]);
go
