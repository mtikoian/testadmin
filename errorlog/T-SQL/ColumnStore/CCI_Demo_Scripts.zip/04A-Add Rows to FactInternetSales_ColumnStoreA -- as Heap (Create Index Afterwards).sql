use [AdventureWorksDW2012]
go

-- Note:  This took 4:33 to load 6M+ rows on a VM running on my laptop

set nocount on;

if (select count(*) from [dbo].[FactInternetSales_ColumnStoreA]) = 0
	begin

	-- Add all rows from rowstore version of fact table
	insert into [dbo].[FactInternetSales_ColumnStoreA]
		([ProductKey], [OrderDateKey], [DueDateKey], [ShipDateKey], [CustomerKey], [PromotionKey], [CurrencyKey], [SalesTerritoryKey], [SalesOrderNumber], [SalesOrderLineNumber], [RevisionNumber], [OrderQuantity], [UnitPrice], [ExtendedAmount], [UnitPriceDiscountPct], [DiscountAmount], [ProductStandardCost], [TotalProductCost], [SalesAmount], [TaxAmt], [Freight], [CarrierTrackingNumber], [CustomerPONumber], [OrderDate], [DueDate], [ShipDate])
	select
		[ProductKey], [OrderDateKey], [DueDateKey], [ShipDateKey], [CustomerKey], [PromotionKey], [CurrencyKey], [SalesTerritoryKey], [SalesOrderNumber], [SalesOrderLineNumber], [RevisionNumber], [OrderQuantity], [UnitPrice], [ExtendedAmount], [UnitPriceDiscountPct], [DiscountAmount], [ProductStandardCost], [TotalProductCost], [SalesAmount], [TaxAmt], [Freight], [CarrierTrackingNumber], [CustomerPONumber], [OrderDate], [DueDate], [ShipDate]
	from
		[dbo].[FactInternetSales_RowStore];

	-- Create columnstore index
	if not exists (select * from [sys].[indexes] where [object_id] = object_id('[dbo].[FactInternetSales_ColumnStoreA]') and [name] = 'cci_FactInternetSales_ColumnStoreA')
		create clustered columnstore index [cci_FactInternetSales_ColumnStoreA] on [dbo].[FactInternetSales_ColumnStoreA]
			on [ps_Quarters_DateTime]([OrderDate]);

	end
go
