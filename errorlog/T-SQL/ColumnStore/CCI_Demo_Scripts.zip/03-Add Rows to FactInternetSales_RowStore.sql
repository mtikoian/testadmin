use [AdventureWorksDW2012]
go

-- Note:  This took 19:51 to load 6M+ rows on a VM running on my laptop

set nocount on;

if (select count(*) from [dbo].[FactInternetSales_RowStore]) = 0
	begin

	-- Add initial set of rows from original fact table
	insert into [dbo].[FactInternetSales_Rowstore]
		([ProductKey], [OrderDateKey], [DueDateKey], [ShipDateKey], [CustomerKey], [PromotionKey], [CurrencyKey], [SalesTerritoryKey], [SalesOrderNumber], [SalesOrderLineNumber], [RevisionNumber], [OrderQuantity], [UnitPrice], [ExtendedAmount], [UnitPriceDiscountPct], [DiscountAmount], [ProductStandardCost], [TotalProductCost], [SalesAmount], [TaxAmt], [Freight], [CarrierTrackingNumber], [CustomerPONumber], [OrderDate], [DueDate], [ShipDate])
	select
		[ProductKey], [OrderDateKey], [DueDateKey], [ShipDateKey], [CustomerKey], [PromotionKey], [CurrencyKey], [SalesTerritoryKey], [SalesOrderNumber], [SalesOrderLineNumber], [RevisionNumber], [OrderQuantity], [UnitPrice], [ExtendedAmount], [UnitPriceDiscountPct], [DiscountAmount], [ProductStandardCost], [TotalProductCost], [SalesAmount], [TaxAmt], [Freight], [CarrierTrackingNumber], [CustomerPONumber], [OrderDate], [DueDate], [ShipDate]
	from
		[dbo].[FactInternetSales];

	-- Now, ramp that up by 100x
	declare
		@Offset int = 1
		,@MaxOffset int = 101;

	while @Offset < @MaxOffset
		begin

		begin try

		insert into [dbo].[FactInternetSales_RowStore]
			([ProductKey], [OrderDateKey], [DueDateKey], [ShipDateKey], [CustomerKey], [PromotionKey], [CurrencyKey], [SalesTerritoryKey], [SalesOrderNumber], [SalesOrderLineNumber], [RevisionNumber], [OrderQuantity], [UnitPrice], [ExtendedAmount], [UnitPriceDiscountPct], [DiscountAmount], [ProductStandardCost], [TotalProductCost], [SalesAmount], [TaxAmt], [Freight], [CarrierTrackingNumber], [CustomerPONumber], [OrderDate], [DueDate], [ShipDate])
		select
			[ProductKey] - @Offset
			,convert(varchar,dateadd(day,@Offset,convert(datetime,convert(varchar,[OrderDateKey]),112)),112) as [OrderDateKey]
			,convert(varchar,dateadd(day,@Offset,convert(datetime,convert(varchar,[DueDateKey]),112)),112) as [DueDateKey]
			,convert(varchar,dateadd(day,@Offset,convert(datetime,convert(varchar,[ShipDateKey]),112)),112) as [ShipDateKey]
			,[CustomerKey], [PromotionKey], [CurrencyKey], [SalesTerritoryKey], [SalesOrderNumber], [SalesOrderLineNumber], [RevisionNumber], [OrderQuantity], [UnitPrice], [ExtendedAmount], [UnitPriceDiscountPct], [DiscountAmount], [ProductStandardCost], [TotalProductCost], [SalesAmount], [TaxAmt], [Freight], [CarrierTrackingNumber], [CustomerPONumber]
			,dateadd(day,@Offset,[OrderDate]) as [OrderDate]
			,dateadd(day,@Offset,[DueDate]) as [DueDate]
			,dateadd(day,@Offset,[ShipDate]) as [ShipDate]
		from
			[dbo].[FactInternetSales];

		set @Offset = @Offset + 1

		end try

		begin catch

		select
			@Offset as CurrentOffset
			,error_number() AS ErrorNumber
			,error_severity() AS ErrorSeverity
			,error_state() AS ErrorState
			,error_message() AS ErrorMessage;
		return;

		end catch

		end

	end
go