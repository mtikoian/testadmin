use [AdventureWorksDW2012]
go

set statistics io on;
set statistics time on;
go

-- Update all rows with dates in 2007 (partitions 10-13)
update
	[dbo].[FactInternetSales_RowStore]
set
	[RevisionNumber] = [RevisionNumber] + 1
where
	[OrderDate] between '1/1/2007' and '12/31/2007';
go

set statistics io off;
set statistics time off;
go
