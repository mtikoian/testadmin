use [AdventureWorksDW2012]
go

set statistics io on;
set statistics time on;
go

select
	isnull(pc.[EnglishProductCategoryName], '*N/A*') as [ProductCategoryName]
	,isnull(ps.[EnglishProductSubcategoryName], '*N/A*') as [ProductSubcategoryName]
	,p.[EnglishProductName] as [ProductName]
	,p.[Color] as [ProductColor]
	,count(distinct fis.[SalesOrderNumber]) as [DistinctSalesOrders]
	,sum(fis.[OrderQuantity]) as [TotalQuantityOrdered]
	,sum(fis.[SalesAmount]) as [TotalSalesAmount]
from
	[dbo].[FactInternetSales_ColumnStoreA] as fis
	inner join [dbo].[DimProduct] as p on
		fis.[ProductKey] = p.[ProductKey]
	left outer join [dbo].[DimProductSubcategory] as ps on
		p.[ProductSubcategoryKey] = ps.[ProductSubcategoryKey]
	left outer join [dbo].[DimProductCategory] as pc on
		ps.[ProductCategoryKey] = pc.[ProductCategoryKey]
where
	fis.[OrderDate] between '1/1/2007' and '12/31/2007'
group by
	pc.[EnglishProductCategoryName]
	,ps.[EnglishProductSubcategoryName]
	,p.[EnglishProductName]
	,p.[Color]
order by
	pc.[EnglishProductCategoryName]
	,ps.[EnglishProductSubcategoryName]
	,p.[EnglishProductName]
	,p.[Color]
--option (maxdop 1)
;
go

set statistics io off;
set statistics time off;
go
