use [AdventureWorksDW2012]
go

set statistics io on;
set statistics time on;
go

declare
	@CustomerKey int;

select
	@CustomerKey = CustomerKey
from
	dbo.DimCustomer
where
	CustomerAlternateKey = 'AW00023968';

select
	year(fis.OrderDate) as OrderYear
	,month(fis.OrderDate) as OrderMonth
	,p.[EnglishProductName] as ProductName
	,count(distinct fis.SalesOrderNumber) as DistinctSalesOrders
	,sum(fis.OrderQuantity) as TotalQuantityOrdered
	,sum(fis.SalesAmount) as TotalSalesAmount
from
	dbo.FactInternetSales_ColumnStoreA fis
	inner join dbo.DimProduct p on
		fis.ProductKey = p.ProductKey
where
	fis.CustomerKey = @CustomerKey
group by
	year(fis.OrderDate)
	,month(fis.OrderDate)
	,p.[EnglishProductName]
order by
	year(fis.OrderDate)
	,month(fis.OrderDate)
	,p.[EnglishProductName]
--option (maxdop 1)
;
go

set statistics io off;
set statistics time off;
go
