use [AdventureWorksDW2012]
go

-- Review status and size of row groups
select
	object_name(i.[object_id]) as [TableName]
	,i.[name] as [IndexName]
	,i.[type_desc] as [IndexType]
	,c.[partition_number] as [PartitionNumber]
	,c.[state_description] as [RowGroupState]
	,c.[total_rows] as [TotalRows]
	,c.[deleted_rows] as [DeletedRows]
	,c.[size_in_bytes] as [SizeInBytes]
from
	[sys].[indexes] as i
	inner join [sys].[column_store_row_groups] as c on
		i.[object_id] = c.[object_id]
		and i.[index_id] = c.[index_id]
where
	object_name(i.[object_id]) = 'FactInternetSales_ColumnStoreA'
order by
	object_name(i.[object_id])
	,i.[name]
	,c.[partition_number];
go

-- Reorganize index to compress any closed rowstores
/*
alter index [cci_FactInternetSales_ColumnStoreA] on [dbo].[FactInternetSales_ColumnStoreA]
	reorganize;
go
*/

-- Rebuild index to close open rowstores and then compress all non-compressed rowstores
/*
alter index [cci_FactInternetSales_ColumnStoreA] on [dbo].[FactInternetSales_ColumnStoreA]
	rebuild;
go
*/

-- Rebuild (or reorganize) specific partition if desired
/*
alter index [cci_FactInternetSales_ColumnStoreA] on [dbo].[FactInternetSales_ColumnStoreA]
	rebuild partition = xx;
go
*/
