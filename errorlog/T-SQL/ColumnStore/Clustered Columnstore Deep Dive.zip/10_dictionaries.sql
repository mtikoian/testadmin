/* 
 * Queries for testing SQL Server 2014 CTP improvements
 * by Niko Neugebauer (http://www.nikoport.com)
 * These queries are to be run on a Contoso BI Database (http://www.microsoft.com/en-us/download/details.aspx?displaylang=en&id=18279)
 *
 * This query shows the current status of the Columnstore Dictionaries
 */

-- Dictionaries count & type per each of the column
select t.name as 'Table Name'
	,dict.column_id
	,col.name
	,tp.name
	,case dict.dictionary_id
		when 0 then 'Global Dictionary'
		else 'Local Dictionary'
	end as 'Dictionary Type'
	,count(dict.type) as 'Count'
	,sum(dict.on_disk_size) as 'Size in Bytes'
	,cast(sum(dict.on_disk_size) / 1024.0 / 1024 as Decimal(16,3)) as 'Size in MBytes'
	from sys.column_store_dictionaries dict
	inner join sys.partitions as p 
		ON dict.partition_id = p.partition_id
	inner join sys.tables t
		ON t.object_id = p.object_id
	inner join sys.all_columns col
		on col.column_id = dict.column_id and col.object_id = t.object_id
	inner join sys.types tp 
		ON col.system_type_id = tp.system_type_id AND col.user_type_id = tp.user_type_id   
	where t.[is_ms_shipped] = 0 
	group by t.name,
			 case dict.dictionary_id
				when 0 then 'Global Dictionary'
				else 'Local Dictionary'
			 end, 
			 col.name,
			 tp.name,
			 dict.column_id
	order by t.name, dict.column_id;


-- Detailed information about Dictionaries
select 
	SCHEMA_NAME(t.schema_id) as 'Schema',
	OBJECT_NAME(t.object_id) as 'Table Name',
	i.name AS IndexName,	
	case dict.type
		when 1 then 'Hash dictionary containing int values'
		when 2 then 'Not used'
		when 3 then 'Hash dictionary containing string values'
		when 4 then 'Hash dictionary containing float values'
		else 'Unknown - Please Investigate'
	end as 'Dictionary values type',
	case dict.dictionary_id
		when 0 then 'Global Dictionary'
		else 'Local Dictionary'
	end as 'Dictionary Type',
	dict.column_id,
	dict.dictionary_id,
	dict.type,
	dict.entry_count,
	p.rows
	,dict.on_disk_size
	--,* 
	from sys.column_store_dictionaries dict
	inner join sys.partitions as p 
		ON dict.partition_id = p.partition_id
	inner join sys.tables t
		ON t.object_id = p.object_id
	inner join sys.indexes i
		ON i.object_id = t.object_id
	where i.type in (5,6) -- Clustered & Nonclustered Columnstore
	order by t.name;


