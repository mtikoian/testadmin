/* 
 * Queries for testing SQL Server 2014 CTP improvements
 * by Niko Neugebauer (http://www.nikoport.com)
 * These queries are to be run on a Contoso BI Database (http://www.microsoft.com/en-us/download/details.aspx?displaylang=en&id=18279)
 *
 * This queries demonstrate Locking and Blocking of the Clustered Columnstore Indexes (main part)
 */
 
-- Get HOBT
select * from sys.column_store_segments seg
	inner join sys.partitions as p 
		ON seg.partition_id = p.partition_id
	where OBJECT_id = OBJECT_ID('FactOnlineSales');

--72057594048544768

-- DB_ID
select db_id();

-- Print DBCC output into a new Window
dbcc traceon (3604);


-- Here ... We ... Go ... :)
dbcc csindex (
    8,  -- DB_ID()
    72057594048544768, -- HoBT or PartitionID
    3, -- column_id
    1, -- segment_id from sys.column_store_segments
    1, -- 1 (Segment), 2 (Dictionary),
    0 -- [0 or 1 or 2]
    --[, start]
    --[, end]
)
dbcc traceon (3604);

select * from sys.column_store_segments seg
	inner join sys.partitions as p 
		ON seg.partition_id = p.partition_id
	where OBJECT_id = OBJECT_ID('FactOnlineSales');

--72057594049986560

-- DB_ID
select db_id();

-- Lets see the dictionary
dbcc csindex (
    8,  -- DB_ID()
    72057594048544768, -- HoBT or PartitionID
    18, -- column_id
    0, -- segment_id from sys.column_store_segments
    1, -- 1 (Segment), 2 (Dictionary),
    0 -- [0 or 1 or 2]
    --[, start]
    --[, end]
);

-- Lets see the actual data

-- Lets see the dictionary of a Nvarchar field
-- Column Number 8
dbcc csindex (
    8,  -- DB_ID()
    72057594048544768, -- HoBT or PartitionID
    8, -- column_id
    0, -- segment_id from sys.column_store_segments
    2, -- 1 (Segment), 2 (Dictionary),
    0 -- [0 or 1 or 2]
    --[, start]
    --[, end]
);

-- Is there any actual data ?
select top 20 SalesOrderNumber, OnlineSalesKey, StoreKey
	from dbo.FactOnlineSales
	where SalesOrderNumber like '%8732%';

/*
Index 0 = 8732                      Index 1 = 17464                     Index 2 = 7419
Index 3 = 16151                     Index 4 = 6106                      Index 5 = 14838
Index 6 = 4793                      Index 7 = 13525                     Index 8 = 3480
Index 9 = 12212                     Index 10 = 2167                     Index 11 = 10899
Index 12 = 854                      Index 13 = 9586                     Index 14 = 18318
Index 15 = 8273                     Index 16 = 17005                    Index 17 = 6960
Index 18 = 15692                    Index 19 = 5647                     Index 20 = 14379
Index 21 = 13066                    Index 22 = 4334                     Index 23 = 3021
*/
