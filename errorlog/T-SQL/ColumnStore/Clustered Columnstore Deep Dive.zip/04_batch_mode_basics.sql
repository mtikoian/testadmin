/* 
 * Queries for testing SQL Server 2014 CTP improvements
 * by Niko Neugebauer (http://www.nikoport.com)
 * These queries are to be run on a Contoso BI Database (http://www.microsoft.com/en-us/download/details.aspx?displaylang=en&id=18279)
 *
 * This commands drop all Primary & Foreign Keys on the Contoso BI Database 
 */
 
 use ContosoRetailDW;
GO

-- Lets create a copy of our FactOnlineSales table with a purpose of showing difference between Parallel plan and a Batch Mode
select OnlineSalesKey, DateKey, StoreKey, ProductKey, PromotionKey, CurrencyKey, CustomerKey, SalesOrderNumber, SalesOrderLineNumber, SalesQuantity, SalesAmount, ReturnQuantity, ReturnAmount, DiscountQuantity, DiscountAmount, TotalCost, UnitCost, UnitPrice, ETLLoadID, LoadDate, UpdateDate
	into dbo.FactOnlineSales_NC
		from dbo.FactOnlineSales;

create unique clustered index PK_FactOnlineSales_NC
	on dbo.FactOnlineSales_NC (OnlineSalesKey)
	with (DATA_COMPRESSION = PAGE);



-- *****************************************************************
-- Lets compare all 3 plans, even though the first one is running on just 1 core

set statistics io on
set statistics time on

-- Row Mode
select count(OnlineSalesKey)
	from dbo.FactOnlineSales
	option(maxdop 1);

-- Parallel plan
select count(OnlineSalesKey)
	from dbo.FactOnlineSales_NC
	option(maxdop 2);

-- Batch Mode
select count(OnlineSalesKey)
	from dbo.FactOnlineSales
	option(maxdop 2);

-- *****************************************************************
-- A tender reminder about SQL Server 2012 and its Nonclustered Columnstore Indexes
-- This is how you have to write your query in order to get it working in Batch Mode in SQL Server 2012
with T (StoreKey, SalesKey) as(
	select StoreKey, count(OnlineSalesKey)
	from dbo.FactOnlineSales
	group by StoreKey
)
select sum(SalesKey)
	from T;
	