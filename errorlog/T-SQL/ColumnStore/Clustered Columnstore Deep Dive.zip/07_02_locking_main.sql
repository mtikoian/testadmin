/* 
 * Queries for testing SQL Server 2014 CTP improvements
 * by Niko Neugebauer (http://www.nikoport.com)
 *
 * This queries demonstrate Locking and Blocking of the Clustered Columnstore Indexes (main part)
 */

use ColumnstorePlay;
GO

begin tran
	insert into dbo.CCTest
		( id, name, lastname )
		values
		( 1, 'SomeName_', 'SomeLastName_' );
-- ******* STOP HERE ************************
-- Analyze
-- Run the same transaction in a different window. Commit it.
commit;
-- ******* COMMIT BEFORE PROCEEDING ********


-- *******************************************
-- Try opening this in a different transaction while holding a lock on an uncommited transaction
-- with id = 2
begin tran
	insert into dbo.CCTest
		( id, name, lastname )
		values
		( 2, 'SomeName_', 'SomeLastName_' );
COMMIT;

delete from dbo.CCTest
	where id = 1;
-- The result should be a blocked transaction


-- *******************************************
-- Lets insert a full Segment of data
declare @i as int;
declare @max as int;
select @max = isnull(max(id),0) from dbo.CCTest;
set @i = 1;

begin tran
while @i <= 1048576
begin
	insert into dbo.CCTest
		( id, name, lastname )
		values
		( @max + @i, 'SomeName_', 'SomeLastName_' );

	set @i = @i + 1;
end;
commit;

-- *******************************************
-- Invoke Tuple Mover to compress the data
alter index CCL_CCTest on dbo.CCTest
	reorganize;

-- *******************************************
-- You should have here 2 row groups with 1 row and 1 million rows

-- *******************************************
-- Update a row in a compressed segment
begin tran

	update dbo.CCTest
		set name = 'Updated Name'
		where id = 150;

Commit;

-- *******************************************
-- Enjoy both rowgroups being locked

-- *******************************************
-- But you can still insert data into the Delta-Store, because a parallel transaction will be using an IX lock
