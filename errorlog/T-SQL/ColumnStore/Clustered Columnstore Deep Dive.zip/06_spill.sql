/* 
 * Queries for testing SQL Server 2014 CTP improvements
 * by Niko Neugebauer (http://www.nikoport.com)
 * These queries are to be run on a Contoso BI Database (http://www.microsoft.com/en-us/download/details.aspx?displaylang=en&id=18279)
 *
 * This queries demonstrate TempDB Batch Mode improvements in SQL Server 2014
 * Attention: you will need to adjust your memory settings in order for spill to happen (otherwise feel free to modify RowCount) 
 */

set rowcount 1000

set statistics io on

-- SQL Server 2014 CTP version
-- You will need to include the actual execution plan to see that the spill functions in Batch Mode
-- while Sort operator is still running in RowMode
select sales.OnlineSalesKey, COUNT_BIG(*)
	from dbo.FactOnlineSales sales 
		inner join dbo.FactOnlineSales sales2 
			on sales.OnlineSalesKey = sales2.OnlineSalesKey
	group by sales.OnlineSalesKey
	order by sales.OnlineSalesKey;