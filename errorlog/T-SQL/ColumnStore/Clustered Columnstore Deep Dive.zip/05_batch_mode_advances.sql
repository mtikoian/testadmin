/* 
 * Queries for testing SQL Server 2014 CTP improvements
 * by Niko Neugebauer (http://www.nikoport.com)
 * These queries are to be run on a Contoso BI Database (http://www.microsoft.com/en-us/download/details.aspx?displaylang=en&id=18279)
 *
 * This queries demonstrate some of the improvements done for the SQL Server 2014 in the relation of the queries processing of Clustered Columnstore Indexes & Batch Mode
 */

-- Outer Join
select prod.ProductName, sum(sales.SalesAmount)
	from dbo.DimProduct prod
		right outer join dbo.FactOnlineSales sales
			on sales.ProductKey = prod.ProductKey
	group by prod.ProductName
	order by prod.ProductName

-- In
select (select store.StoreName from dbo.DimStore store where store.StoreKey = sales.StoreKey) as 'Store', sum(sales.SalesAmount) as 'Store Sales'
	from dbo.FactOnlineSales sales
		where sales.ProductKey  in ( select prod.ProductKey from dbo.DimProduct prod )
	group by sales.StoreKey
	order by sales.StoreKey

-- Exists 
select (select store.StoreName from dbo.DimStore store where store.StoreKey = sales.StoreKey) as 'Store', sum(sales.SalesAmount) as 'Store Sales'
	from dbo.FactOnlineSales sales
		where EXISTS ( select prod.ProductKey from dbo.DimProduct prod where sales.ProductKey = prod.ProductKey )
	group by sales.StoreKey
	order by sales.StoreKey

-- NOT IN
-- Sales without Luxury Products
select (select store.StoreName from dbo.DimStore store where store.StoreKey = sales.StoreKey) as 'Store', sum(sales.SalesAmount) as 'Non-Luxury Store Sales'
	from dbo.FactOnlineSales sales
		where sales.ProductKey  not in ( select prod.ProductKey from dbo.DimProduct prod where prod.ClassID = 3 )
	group by sales.StoreKey
	order by sales.StoreKey


-- *****************************************************
-- Let us create a view on the totality of the purchases 
create view dbo.vPurchases as
select [SalesQuantity], [TotalCost]
	from dbo.FactOnlineSales
union all
select [SalesQuantity], [TotalCost]
	from dbo.FactSales 

-- Lets get the totals out of this view
select sum([SalesQuantity]) as TotalSales, sum([TotalCost]) as TotalCosts
	from dbo.vPurchases


-- *****************************************************
-- Total count of the sales
select count(*)
	from dbo.FactOnlineSales



-- *****************************************************
-- Distinct Aggregates!
select count( distinct StoreKey ) as 'Distinct Stores'
	
	from dbo.FactOnlineSales sales
		inner join dbo.DimPromotion prom
			on sales.PromotionKey = prom.PromotionKey
	where prom.DiscountPercent = 0
	group by sales.LoadDate
union all
select count( distinct CurrencyKey ) as 'Distinct Currencies'
	from dbo.FactOnlineSales sales
		inner join dbo.DimPromotion prom
			on sales.PromotionKey = prom.PromotionKey
	where prom.DiscountPercent = 0
	group by sales.LoadDate