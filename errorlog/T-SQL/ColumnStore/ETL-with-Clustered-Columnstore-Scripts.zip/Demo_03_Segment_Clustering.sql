/* 
 * Queries for testing SQL Server 2014 Columnstore improvements
 * by Niko Neugebauer (http://www.nikoport.com)
 * These queries are to be run on a Contoso BI Database (http://www.microsoft.com/en-us/download/details.aspx?displaylang=en&id=18279)
 *
 * Testing Segment Clustering
 */
 use [ContosoRetailDW];

--create clustered columnstore index [PK_FactOnlineSales] 
--	on dbo.FactOnlineSales;

--alter index [PK_FactOnlineSales]
--	on dbo.FactOnlineSales
--		rebuild;

-- Check Segments (on my system I typically have around 13, but it will depend on the number of factors)
select segment_id, row_count, base_id, min_data_id, max_data_id
	from sys.column_store_segments seg
		inner join sys.partitions part
			on seg.partition_id = part.partition_id
	where column_id = 1
		and part.object_id = object_id('FactOnlineSales');

-- Test Query
set statistics io on 
select sum([UnitPrice]) as Sales
	from dbo.FactOnlineSales
	where OnlineSalesKey >= 27120879 and OnlineSalesKey <= 32181089;

/*
46802 logical Reads
*/

-- Create an ordered Rowstore index, droping Columnstore index
create clustered index [PK_FactOnlineSales] on dbo.FactOnlineSales (OnlineSalesKey)
	with (DROP_EXISTING = ON, DATA_COMPRESSION = PAGE);

-- Create a Columnstore, while dropping existing RowStore Index
create clustered columnstore index [PK_FactOnlineSales] on dbo.FactOnlineSales
	with (DROP_EXISTING = ON);

-- Check Segments
select segment_id, row_count, base_id, min_data_id, max_data_id
	from sys.column_store_segments seg
		inner join sys.partitions part
			on seg.partition_id = part.partition_id
	where column_id = 1
		and part.object_id = object_id('FactOnlineSales');

-- Test Query Again
set statistics io on 
select sum([UnitPrice]) as Sales
	from dbo.FactOnlineSales
	where OnlineSalesKey >= 27120879 and OnlineSalesKey <= 32181089;

/*
8595 logical Reads
*/

-- *****************************************************************************************

create clustered index [PK_FactOnlineSales] on dbo.FactOnlineSales (OnlineSalesKey)
	with (DROP_EXISTING = ON, DATA_COMPRESSION = PAGE);

-- Create a Columnstore with MAXDOP = 1, to get a perfect Segment Clustering
create clustered columnstore index [PK_FactOnlineSales] on dbo.FactOnlineSales
	with (DROP_EXISTING = ON, MAXDOP = 1);

-- Check our segments
select segment_id, row_count, base_id, min_data_id, max_data_id
	from sys.column_store_segments seg
		inner join sys.partitions part
			on seg.partition_id = part.partition_id
	where column_id = 1
		and part.object_id = object_id('FactOnlineSales');

-- Test Query Again
set statistics io on 
select sum([UnitPrice]) as Sales
	from dbo.FactOnlineSales
	where OnlineSalesKey >= 27120879 and OnlineSalesKey <= 32181089;

/*
4622 logical Reads
*/


