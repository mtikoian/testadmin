/* 
 * Queries for testing SQL Server 2014 Columnstore Improvements
 * by Niko Neugebauer (http://www.nikoport.com)
 * These queries are to be run on a Contoso BI Database (http://www.microsoft.com/en-us/download/details.aspx?displaylang=en&id=18279)
 *
 * This query creates a clustered columnstore index on the FactOnlineSales table
 */

use ContosoRetailDW;
 
create clustered columnstore Index PK_FactOnlineSales
	on dbo.FactOnlineSales;
