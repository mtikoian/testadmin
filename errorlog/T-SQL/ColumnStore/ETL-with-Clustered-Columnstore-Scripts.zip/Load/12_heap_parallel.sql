/* 
 * Queries for testing SQL Server 2014 Columnstore improvements
 * by Niko Neugebauer (http://www.nikoport.com)
 * These queries are to be run on a Contoso BI Database (http://www.microsoft.com/en-us/download/details.aspx?displaylang=en&id=18279)
 *
 * Load data into Heap Table Parallel Load
 */

use ContosoRetailDW;

--drop table dbo.FactOnlineSales_Staged_Parallel;

 select top 3000000
        OnlineSalesKey, DateKey, StoreKey, ProductKey, PromotionKey, CurrencyKey, CustomerKey, SalesOrderNumber, SalesOrderLineNumber, SalesQuantity, SalesAmount, ReturnQuantity, ReturnAmount, DiscountQuantity, DiscountAmount, TotalCost, UnitCost, UnitPrice, ETLLoadID, LoadDate, UpdateDate
	 into dbo.FactOnlineSales_Staged_Parallel
        from dbo.FactOnlineSales;


create Clustered Columnstore Index PK_FactOnlineSales_Staged_Parallel
	on dbo.FactOnlineSales_Staged_Parallel;