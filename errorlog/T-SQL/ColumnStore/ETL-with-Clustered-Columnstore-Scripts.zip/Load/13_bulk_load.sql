/* 
 * Queries for testing SQL Server 2014 Columnstore improvements
 * by Niko Neugebauer (http://www.nikoport.com)
 * These queries are to be run on a Contoso BI Database (http://www.microsoft.com/en-us/download/details.aspx?displaylang=en&id=18279)
 *
 * Load data into CCI Table with BULK Load API
 */

-- !!! Notice that You will need to enable the BCP first !!!
use ContosoRetailDW

-- Export 3 Million Rows into a C:\Install\ Folder
EXEC xp_cmdshell 'bcp "SELECT top 3000000 * FROM [ContosoRetailDW].dbo.FactOnlineSales order by OnlineSalesKey" queryout "C:\Install\FactOnlineSales.rpt" -T -c -t,'; 

--drop TABLE [dbo].[FactOnlineSales_Bulk_CCI];

CREATE TABLE [dbo].[FactOnlineSales_Bulk_CCI](
    [OnlineSalesKey] [int] NOT NULL,
    [DateKey] [datetime] NOT NULL,
    [StoreKey] [int] NOT NULL,
    [ProductKey] [int] NOT NULL,
    [PromotionKey] [int] NOT NULL,
    [CurrencyKey] [int] NOT NULL,
    [CustomerKey] [int] NOT NULL,
    [SalesOrderNumber] [nvarchar](20) NOT NULL,
    [SalesOrderLineNumber] [int] NULL,
    [SalesQuantity] [int] NOT NULL,
    [SalesAmount] [money] NOT NULL,
    [ReturnQuantity] [int] NOT NULL,
    [ReturnAmount] [money] NULL,
    [DiscountQuantity] [int] NULL,
    [DiscountAmount] [money] NULL,
    [TotalCost] [money] NOT NULL,
    [UnitCost] [money] NULL,
    [UnitPrice] [money] NULL,
    [ETLLoadID] [int] NULL,
    [LoadDate] [datetime] NULL,
    [UpdateDate] [datetime] NULL
);
 
create Clustered Columnstore Index PK_FactOnlineSales_Bulk_CCI
    on dbo.FactOnlineSales_Bulk_CCI
 
 
-- Import Bulk Data
BULK INSERT dbo.FactOnlineSales_Bulk_CCI
   FROM 'C:\Install\FactOnlineSales.rpt'
   WITH 
      (
         FIELDTERMINATOR =',',
         ROWTERMINATOR ='\n'
      );