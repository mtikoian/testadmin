/* 
 * Queries for testing SQL Server 2014 Columnstore improvements
 * by Niko Neugebauer (http://www.nikoport.com)
 * These queries are to be run on a Contoso BI Database (http://www.microsoft.com/en-us/download/details.aspx?displaylang=en&id=18279)
 *
 * Testing Updates vs Insert + Delete
 */
 
 use ContosoRetailDW;

CREATE TABLE [dbo].[FactOnlineSalesCopy](
	[OnlineSalesKey] [int] IDENTITY(1,1) NOT NULL,
	[DateKey] [datetime] NOT NULL,
	[StoreKey] [int] NOT NULL,
	[ProductKey] [int] NOT NULL,
	[PromotionKey] [int] NOT NULL,
	[CurrencyKey] [int] NOT NULL,
	[CustomerKey] [int] NOT NULL,
	[SalesOrderNumber] [nvarchar](20) NOT NULL,
	[SalesOrderLineNumber] [int] NULL,
	[SalesQuantity] [int] NOT NULL,
	[SalesAmount] [money] NOT NULL,
	[ReturnQuantity] [int] NOT NULL,
	[ReturnAmount] [money] NULL,
	[DiscountQuantity] [int] NULL,
	[DiscountAmount] [money] NULL,
	[TotalCost] [money] NOT NULL,
	[UnitCost] [money] NULL,
	[UnitPrice] [money] NULL,
	[ETLLoadID] [int] NULL,
	[LoadDate] [datetime] NULL,
	[UpdateDate] [datetime] NULL
);

Create Clustered Columnstore Index PK_FactOnlineSalesCopy on dbo.FactOnlineSalesCopy;
GO

-- Create a Copy of FactOnlineSales
set identity_insert dbo.FactOnlineSalesCopy ON

insert into dbo.FactOnlineSalesCopy
(OnlineSalesKey, DateKey, StoreKey, ProductKey, PromotionKey, CurrencyKey, CustomerKey, SalesOrderNumber, SalesOrderLineNumber, SalesQuantity, SalesAmount, ReturnQuantity, ReturnAmount, DiscountQuantity, DiscountAmount, TotalCost, UnitCost, UnitPrice, ETLLoadID, LoadDate, UpdateDate)
SELECT [OnlineSalesKey]
      ,[DateKey]
      ,[StoreKey]
      ,[ProductKey]
      ,[PromotionKey]
      ,[CurrencyKey]
      ,[CustomerKey]
      ,[SalesOrderNumber]
      ,[SalesOrderLineNumber]
      ,[SalesQuantity]
      ,[SalesAmount]
      ,[ReturnQuantity]
      ,[ReturnAmount]
      ,[DiscountQuantity]
      ,[DiscountAmount]
      ,[TotalCost]
      ,[UnitCost]
      ,[UnitPrice]
      ,[ETLLoadID]
      ,[LoadDate]
      ,[UpdateDate]
  FROM [ContosoRetailDW].[dbo].[FactOnlineSales]
  --order by OnlineSalesKey

set identity_insert dbo.FactOnlineSalesCopy OFF

-- Compress all Delta-Stores
Alter Index PK_FactOnlineSalesCopy on dbo.FactOnlineSalesCopy
	Reorganize with(COMPRESS_ALL_ROW_GROUPS = ON);
GO

-- ************************************************************************************************

dbcc dropcleanbuffers;

set statistics io on
set statistics time on

-- Check the Execution Plan for the Execution Mode
-- It should take around 25 Seconds on my VM
update top (1000000)
	dbo.[FactOnlineSalesCopy]
	set UpdateDate = GetDate();


-- See that you have truly deleted data from the compressed Row Groups and added into a new Delta-Store
SELECT rg.total_rows, 
		cast(100.0*(total_rows - ISNULL(deleted_rows,0))/iif(total_rows = 0, 1, total_rows) as Decimal(6,3)) AS PercentFull, 
		i.object_id, object_name(i.object_id) AS TableName, 
		i.name AS IndexName, i.index_id, i.type_desc, 
		rg.*
	FROM sys.indexes AS i
	INNEr JOIN sys.column_store_row_groups AS rg
		ON i.object_id = rg.object_id
	AND i.index_id = rg.index_id 
	WHERE object_name(i.object_id) = 'FactOnlineSalesCopy' 
	ORDER BY deleted_rows desc, object_name(i.object_id), i.name, row_group_id;

----------------------------------------------
-- Now we can compare with a delete operation
dbcc dropcleanbuffers;

set statistics io on
set statistics time on

-- Should take around 5 Seconds on my VM
delete top (1000000)
	dbo.[FactOnlineSalesCopy]



-- Insert 1 Million Rows Into Staging Table
dbcc dropcleanbuffers;
select top 1000000 [OnlineSalesKey]
      ,[DateKey]
      ,[StoreKey]
      ,[ProductKey]
      ,[PromotionKey]
      ,[CurrencyKey]
      ,[CustomerKey]
      ,[SalesOrderNumber]
      ,[SalesOrderLineNumber]
      ,[SalesQuantity]
      ,[SalesAmount]
      ,[ReturnQuantity]
      ,[ReturnAmount]
      ,[DiscountQuantity]
      ,[DiscountAmount]
      ,[TotalCost]
      ,[UnitCost]
      ,[UnitPrice]
      ,[ETLLoadID]
      ,[LoadDate]
      ,[UpdateDate]
	into dbo.FactOnlineSales_1M
  FROM [ContosoRetailDW].[dbo].[FactOnlineSalesCopy]
  --order by OnlineSalesKey;
  
  
 -- Now Finally advance with the real data insertion (~5 Seconds)
dbcc dropcleanbuffers;

set statistics io on
set statistics time on

set identity_insert dbo.FactOnlineSales ON

insert into dbo.FactOnlineSales
(OnlineSalesKey, DateKey, StoreKey, ProductKey, PromotionKey, CurrencyKey, CustomerKey, SalesOrderNumber, SalesOrderLineNumber, SalesQuantity, SalesAmount, ReturnQuantity, ReturnAmount, DiscountQuantity, DiscountAmount, TotalCost, UnitCost, UnitPrice, ETLLoadID, LoadDate, UpdateDate)
SELECT [OnlineSalesKey]
      ,[DateKey]
      ,[StoreKey]
      ,[ProductKey]
      ,[PromotionKey]
      ,[CurrencyKey]
      ,[CustomerKey]
      ,[SalesOrderNumber]
      ,[SalesOrderLineNumber]
      ,[SalesQuantity]
      ,[SalesAmount]
      ,[ReturnQuantity]
      ,[ReturnAmount]
      ,[DiscountQuantity]
      ,[DiscountAmount]
      ,[TotalCost]
      ,[UnitCost]
      ,[UnitPrice]
      ,[ETLLoadID]
      ,[LoadDate]
      ,[UpdateDate]
  FROM [ContosoRetailDW].[dbo].[FactOnlineSales_1M]
  order by OnlineSalesKey 

set identity_insert dbo.FactOnlineSales OFF 


-- CleanUp
drop table dbo.FactOnlineSalesCopy;
drop table dbo.FactOnlineSales_1M;