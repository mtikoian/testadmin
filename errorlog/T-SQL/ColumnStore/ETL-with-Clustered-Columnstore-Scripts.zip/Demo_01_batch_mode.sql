/* 
 * Queries for testing SQL Server 2014 Columnstore improvements
 * by Niko Neugebauer (http://www.nikoport.com)
 * These queries are to be run on a Contoso BI Database (http://www.microsoft.com/en-us/download/details.aspx?displaylang=en&id=18279)
 *
 * Testing Differences between Rowstore, Columnstore & Row vs Batch Execution Modes
 */
 
 use ContosoRetailDW;
GO

IF OBJECT_ID('dbo.FactOnlineSales_NC', 'U') IS NOT NULL
	DROP TABLE dbo.FactOnlineSales_NC;
GO

-- Lets create a copy of our FactOnlineSales table with a purpose of showing difference between Parallel plan and a Batch Mode
select OnlineSalesKey, DateKey, StoreKey, ProductKey, PromotionKey, CurrencyKey, CustomerKey, SalesOrderNumber, SalesOrderLineNumber, SalesQuantity, SalesAmount, ReturnQuantity, ReturnAmount, DiscountQuantity, DiscountAmount, TotalCost, UnitCost, UnitPrice, ETLLoadID, LoadDate, UpdateDate
	into dbo.FactOnlineSales_NC
		from dbo.FactOnlineSales;

-- Create a clustered index on it with PAGE Compression in order to get some IO improvements when comparing to Columnstore
create unique clustered index PK_FactOnlineSales_NC
	on dbo.FactOnlineSales_NC (OnlineSalesKey)
	with (DATA_COMPRESSION = PAGE);


-- *****************************************************************
-- Lets compare all 3 plans, even though the first one is running in Row Execution Mode
-- At this point you should include Actual Execution Plan (CTRL+M)

set statistics io on
set statistics time on

-- Row Mode
select count(OnlineSalesKey)
	from dbo.FactOnlineSales
	option( recompile, maxdop 2, querytraceon 9453 );

-- Parallel plan on Page Compression
select count(OnlineSalesKey)
	from dbo.FactOnlineSales_NC
	option(recompile,maxdop 2);

-- Batch Mode
select count(OnlineSalesKey)
	from dbo.FactOnlineSales
	option(recompile, maxdop 2);

-- *****************************************************************
-- Compare a more complex plan with Row Mode vs Batch Mode
-- You might consider running those queries in SQLSentry Plan Explorer (FREE) 

set statistics io ON
set statistics time ON

select prod.ProductName, sum(sales.SalesAmount) as SoldAmount
	from dbo.FactOnlineSales sales
		inner join dbo.DimProduct prod
			on sales.ProductKey = prod.ProductKey
		inner join dbo.DimCurrency cur
			on sales.CurrencyKey = cur.CurrencyKey
		inner join dbo.DimPromotion prom
			on sales.PromotionKey = prom.PromotionKey
		inner join dbo.DimCustomer cust
			on sales.CustomerKey = cust.CustomerKey
	where (cur.CurrencyName = 'USD')
		and prom.EndDate <= '2009-01-01'
	group by prod.ProductName
	order by sum(sales.SalesAmount) desc
	option( recompile, querytraceon 9453 );

select prod.ProductName, sum(sales.SalesAmount) as SoldAmount
	from dbo.FactOnlineSales sales
		inner join dbo.DimProduct prod
			on sales.ProductKey = prod.ProductKey
		inner join dbo.DimCurrency cur
			on sales.CurrencyKey = cur.CurrencyKey
		inner join dbo.DimPromotion prom
			on sales.PromotionKey = prom.PromotionKey
		inner join dbo.DimCustomer cust
			on sales.CustomerKey = cust.CustomerKey
	where (cur.CurrencyName = 'USD')
		and prom.EndDate <= '2009-01-01'
	group by prod.ProductName
	order by sum(sales.SalesAmount) desc
	option( recompile );
