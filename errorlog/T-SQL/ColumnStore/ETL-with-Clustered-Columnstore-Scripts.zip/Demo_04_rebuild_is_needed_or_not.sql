/* 
 * Queries for testing SQL Server 2014 improvements
 * by Niko Neugebauer (http://www.nikoport.com)
 */

 use ContosoRetailDW;

 -- Delete Some Rows
 --delete top (1000)
	--from dbo.FactOnlineSales;

-- Clustered Columnstore Indexes Analysis from the Deleted Perspective
SELECT object_name(p.object_id) as TableName,
	p.partition_number as Partition,
	count(distinct rg.row_group_id) as RowGroups,
	cast( Avg( (deleted_rows * 1. / row_count) * 100 ) as Decimal(5,2)) as 'Fragmentation (Percentage)',
	sum (case deleted_rows when row_count then 1 else 0 end ) as 'Deleted Segments Count',
	cast( (sum (case deleted_rows when row_count then 1 else 0 end ) * 1. / count(*)) * 100  as Decimal(5,2)) as 'DeletedSegments (Percentage)'
	FROM sys.column_store_segments AS seg 
		INNER JOIN sys.partitions AS p 
			ON seg.hobt_id = p.hobt_id 
		INNER JOIN sys.column_store_row_groups rg
			ON p.object_id = rg.object_id and seg.segment_id = rg.row_group_id
	group by p.object_id, p.partition_number
	order by object_name(p.object_id);

