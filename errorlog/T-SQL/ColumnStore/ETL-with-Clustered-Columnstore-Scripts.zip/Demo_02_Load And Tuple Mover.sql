/* 
 * Queries for testing SQL Server 2014 Columnstore improvements
 * by Niko Neugebauer (http://www.nikoport.com)
 * These queries are to be run on a Contoso BI Database (http://www.microsoft.com/en-us/download/details.aspx?displaylang=en&id=18279)
 *
 * Testing Load Process and necessary improvements and fixes
 */

-- I am using my standardDB, feel free to create new one for yourself or use an existing one 
use ColumnstorePlay;

--truncate table dbo.BigDataTest;

-- Create Test Table 
create table dbo.BigDataTest(
	id int not null );

-- Create Columnstore Index
create clustered columnstore index PK_BigDataTest
	on dbo.BigDatatest;


-- Load 1 Full Segment into the Test Table
declare @i as int;
set @i = 1;

begin tran
while @i <= 1048576
begin
	insert into dbo.BigDataTest
		values (@i);

	set @i = @i + 1;
end;
commit;

GO

-- Load extra 7 Segments into the test table
declare @i as int;
declare @max as int;
set @i = 1;

while @i <= 3
begin
	select @max = isnull(max(id),0) from dbo.BigDataTest;

	insert into dbo.BigDataTest
		select id + @max 
			from dbo.BigDataTest;
		
	checkpoint;
	set @i = @i + 1;
end;


-- Check Row Group situation - (You should see 8 total groups and depending on your system and Tuple Mover schedule 1 open and 7 closed Row Groups)
select state, state_description, count(*) as 'RowGroup Count'
from sys.column_store_row_groups
where object_id = object_id('BiGDataTest')
group by state, state_description
order by state;


-- Invoke Tuple Mover to compress open Row Groups
alter index PK_BigDataTest on dbo.BigDataTest
	reorganize;

-- Check Row Group situation - (You should have 7 compressed Row Groups and 1 Open one)
select state, state_description, count(*) as 'RowGroup Count'
	from sys.column_store_row_groups
	where object_id = object_id('BiGDataTest')
	group by state, state_description
	order by state;

-- Force closure of the Open Delta-Stores
alter index PK_BigDataTest on dbo.BiGDataTest
	Reorganize with (COMPRESS_ALL_ROW_GROUPS = ON);

-- Check Row Group situation - (You should have 8 compressed Row Groups now)
select state, state_description, count(*) as 'RowGroup Count'
	from sys.column_store_row_groups
	where object_id = object_id('BiGDataTest')
	group by state, state_description
	order by state;

