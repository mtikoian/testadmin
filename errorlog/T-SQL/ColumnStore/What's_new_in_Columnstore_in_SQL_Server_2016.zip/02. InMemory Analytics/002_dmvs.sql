/* 
 * Queries for testing SQL Server 2016 Columnstore Operational Analytics improvements
 * by Niko Neugebauer (http://www.nikoport.com)
 *
 */
 
-- Check operational statistics
Select object_name(st.object_id) as TableName, st.object_id, 
	ind.name as IndexName, st.index_id,
	st.partition_number, st.row_group_id, st.index_scan_count, st.scan_count,
	st.delete_buffer_scan_count, st.row_group_lock_count,
	st.row_group_lock_wait_count, st.row_group_lock_wait_in_ms
	, *
	from sys.dm_db_column_store_row_group_operational_stats st
		inner join sys.indexes ind
			on st.object_id = ind.object_id and st.index_id = ind.index_id
	order by st.object_id, st.partition_number, st.row_group_id

-- Check Physical Statistics
select object_name(phst.object_id) as TableName, phst.object_id, 
	ind.name as IndexName, phst.index_id, partition_number,
	delta_store_hobt_id,
	state, state_desc, total_rows, deleted_rows, size_in_bytes,
	trim_reason, trim_reason_desc,
	generation
	from sys.dm_db_column_store_row_group_physical_stats phst
		inner join sys.indexes ind
			on phst.object_id = ind.object_id and phst.index_id = ind.index_id
	order by phst.object_id, phst.partition_number, phst.row_group_id

-- Check internal structure and partitions (objects)
select object_name(part.object_id) as TableName, 
	part.object_id, part.partition_id,
	ind.name as IndexName, part.index_id, 
	part.hobt_id,
	part.internal_object_type, part.internal_object_type_desc,
	part.row_group_id, part.rows, part.data_compression, part.data_compression_desc
	from sys.internal_partitions part
		left outer join sys.indexes ind
			on part.object_id = ind.object_id and part.index_id = ind.index_id
	