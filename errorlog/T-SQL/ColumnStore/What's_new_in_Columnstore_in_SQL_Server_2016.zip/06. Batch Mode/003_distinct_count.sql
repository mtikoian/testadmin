GO
ALTER DATABASE [ContosoRetailDW] SET COMPATIBILITY_LEVEL = 130
GO


set statistics time on;

select prom.PromotionName,
	   count( distinct StoreKey ) as 'Distinct Stores',
  	   count( distinct CurrencyKey ) as 'Distinct Currencies',
	   count( distinct ProductKey ) as 'Distinct Products'
	from dbo.FactOnlineSales sales
		inner join dbo.DimPromotion prom
			on sales.PromotionKey = prom.PromotionKey
	where prom.DiscountPercent = 0
	group by prom.PromotionName


GO
ALTER DATABASE [ContosoRetailDW] SET COMPATIBILITY_LEVEL = 120
GO

set statistics time on;

select prom.PromotionName,
	   count( distinct StoreKey ) as 'Distinct Stores',
  	   count( distinct CurrencyKey ) as 'Distinct Currencies',
	   count( distinct ProductKey ) as 'Distinct Products'
	from dbo.FactOnlineSales sales
		inner join dbo.DimPromotion prom
			on sales.PromotionKey = prom.PromotionKey
	where prom.DiscountPercent = 0
	group by prom.PromotionName

ALTER DATABASE [ContosoRetailDW] SET COMPATIBILITY_LEVEL = 130
GO