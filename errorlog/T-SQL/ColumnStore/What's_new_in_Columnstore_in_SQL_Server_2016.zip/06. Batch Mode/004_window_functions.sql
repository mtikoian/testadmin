set statistics time, io on

ALTER DATABASE [ContosoRetailDW] SET COMPATIBILITY_LEVEL = 130
GO

declare @res as Decimal(9,3);
-- 1-3 Second			
select @res = Max(SalesAmount) over ( order by DateKey )
		from dbo.FactOnlineSales
	where DateKey < '2009-01-01';

ALTER DATABASE [ContosoRetailDW] SET COMPATIBILITY_LEVEL = 120
GO

-- 35-42 Seconds
declare @res as Decimal(9,3);
			
	select @res = Max(SalesAmount) over ( order by DateKey )
		from dbo.FactOnlineSales
	where DateKey < '2009-01-01';

ALTER DATABASE [ContosoRetailDW] SET COMPATIBILITY_LEVEL = 130
GO


--- Another Example
declare @resBigInt as BigInt;
			
select @resBigInt = ROW_NUMBER() over ( order by DateKey )
	from dbo.FactOnlineSales
	where DateKey < '2009-01-01';
