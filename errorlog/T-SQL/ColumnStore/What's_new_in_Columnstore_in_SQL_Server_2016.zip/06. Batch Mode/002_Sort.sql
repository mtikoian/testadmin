set statistics time, io on;

ALTER DATABASE [ContosoRetailDW] SET COMPATIBILITY_LEVEL = 130

declare @loadDate as DateTime;

select @loadDate = sales.loadDate
	from dbo.FactOnlineSales sales
		inner join dbo.DimPromotion prom
			on sales.PromotionKey = prom.PromotionKey
	where prom.DiscountPercent = 0
	order by sales.LoadDate;


GO
ALTER DATABASE [ContosoRetailDW] SET COMPATIBILITY_LEVEL = 120
GO

declare @loadDate as DateTime;

select @loadDate = sales.loadDate
	from dbo.FactOnlineSales sales
		inner join dbo.DimPromotion prom
			on sales.PromotionKey = prom.PromotionKey
	where prom.DiscountPercent = 0
	order by sales.LoadDate;

GO
ALTER DATABASE [ContosoRetailDW] SET COMPATIBILITY_LEVEL = 130
GO
