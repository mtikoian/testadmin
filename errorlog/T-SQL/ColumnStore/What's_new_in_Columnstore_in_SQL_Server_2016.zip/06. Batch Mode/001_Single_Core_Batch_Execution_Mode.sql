set statistics time, io on

-- MAXDOP = 2, Batch Mode
select sales.StoreKey, prod.ProductLabel, sum(SalesAmount)
	from dbo.FactOnlineSales sales
		inner join dbo.DimProduct prod
			on sales.ProductKey = prod.ProductKey
	where sales.UnitCost > 10
	group by sales.StoreKey,  prod.ProductLabel
	option (maxdop 2);

-- MAXDOP = 1, Batch Mode
select sales.StoreKey, prod.ProductLabel, sum(SalesAmount)
	from dbo.FactOnlineSales sales
		inner join dbo.DimProduct prod
			on sales.ProductKey = prod.ProductKey
	where sales.UnitCost > 10
	group by sales.StoreKey,  prod.ProductLabel
	option (maxdop 1);

-- MAXDOP = 1, Row Execution Mode
select sales.StoreKey, prod.ProductLabel, sum(SalesAmount)
	from dbo.FactOnlineSales sales
		inner join dbo.DimProduct prod
			on sales.ProductKey = prod.ProductKey
	where sales.UnitCost > 10
	group by sales.StoreKey,  prod.ProductLabel
	option (maxdop 1, querytraceon 9453 );