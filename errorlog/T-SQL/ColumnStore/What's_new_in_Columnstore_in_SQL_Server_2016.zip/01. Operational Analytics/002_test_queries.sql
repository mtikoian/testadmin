set statistics io, time on

SELECT Year([TransactionDate])
      ,Sum([Quantity]) as TotalQuantity
      ,Sum([ActualCost]) as TotalCost
  FROM [dbo].[bigTransactionHistory] tr
	inner join dbo.bigProduct prod
		on tr.ProductID = prod.ProductID
  where TransactionDate < '2009-01-01'
  group by Year(TransactionDate)
  having Sum([Quantity]) > 10000
  order by Year(TransactionDate)
  option (ignore_nonclustered_columnstore_index);

SELECT Year([TransactionDate])
      ,Sum([Quantity]) as TotalQuantity
      ,Sum([ActualCost]) as TotalCost
  FROM [dbo].[bigTransactionHistory] tr
	inner join dbo.bigProduct prod
		on tr.ProductID = prod.ProductID
  where TransactionDate < '2009-01-01'
  group by Year(TransactionDate)
  having Sum([Quantity]) > 10000
  order by Year(TransactionDate);