
-- Check out the space occupied by the Table
exec sp_spaceused 'dbo.bigTransactionHistory'

-- Create Updatable Nonclustered Columnstore
CREATE NONCLUSTERED COLUMNSTORE INDEX NCCI_bigTransactionHistory 
	on dbo.bigTransactionHistory
(
	[ProductID],
	[TransactionDate],
	[Quantity],
	[ActualCost]
);

-- View the internal structures
select object_name(part.object_id) as TableName, 
	ind.name as IndexName,
	part.internal_object_type, part.internal_object_type_desc,
	part.row_group_id, part.rows, part.data_compression, part.data_compression_desc
	--,*
	from sys.internal_partitions part
		left outer join sys.indexes ind
			on part.object_id = ind.object_id and part.index_id = ind.index_id
	where part.object_id = object_id('dbo.bigTransactionHistory');	

-- Create the best Nonclustered Rowstore Index possible
CREATE NONCLUSTERED INDEX [IX_ProductId_TransactionDate] ON [dbo].[bigTransactionHistory]
(
	[ProductID] ASC,
	[TransactionDate] ASC
)
INCLUDE ( 	[Quantity],
	[ActualCost]) WITH (DATA_COMPRESSION = PAGE); 