set statistics io, time on

-- This is a slow Query, it should take around 33 Seconds
-- It will not use the Columnstore Index
SELECT Year([TransactionDate])
      ,Sum([Quantity]) as TotalQuantity
      ,Sum([ActualCost]) as TotalCost
  FROM [dbo].[bigTransactionHistory] tr 
	inner join dbo.bigProduct prod
		on tr.ProductID = prod.ProductID
  where TransactionDate >= '2011-01-01'
  group by Year(TransactionDate)
  having Sum([Quantity]) > 10000
  order by Year(TransactionDate)
  option( recompile, ignore_nonclustered_columnstore_index );

-- Add a Primary Key
  ALTER TABLE [dbo].[bigTransactionHistory] 
	ADD  CONSTRAINT [pk_bigTransactionHistory] 
	PRIMARY KEY CLUSTERED ([TransactionID]) with (DATA_COMPRESSION = PAGE);


-- You can force Columnstore Index usage
-- 8 Seconds execution time, a great improvement from 33 seconds
SELECT Year([TransactionDate]) as Year
      ,Sum([Quantity]) as TotalQuantity
      ,Sum([ActualCost]) as TotalCost
  FROM [dbo].[bigTransactionHistory] tr with(index([ncci_bigTransactionHistory]))
	inner join dbo.bigProduct prod
		on tr.ProductID = prod.ProductID
  where TransactionDate >= '2011-01-01'
  group by Year(TransactionDate)
  having Sum([Quantity]) > 10000
  order by Year(TransactionDate)
  option (recompile);

-- You can add a Nonclustered Filtered Index that will cover the non-filtered part of the Columnstore
-- 3.30 Minutes to create
create nonclustered index IX_bigTransactionHistory_TranasctionDate_Filtered
	on dbo.bigTransactionHistory (
       [TransactionDate]
      ,[ProductID]
      ,[Quantity]
      ,[ActualCost] )
	where TransactionDate >= '2011-01-01'
	with (data_compression = page);

-- You can force Columnstore Index usage
-- 10 Seconds execution time, a great improvement from 22 seconds
SELECT Year([TransactionDate]) as Year
      ,Sum([Quantity]) as TotalQuantity
      ,Sum([ActualCost]) as TotalCost
  FROM [dbo].[bigTransactionHistory] tr with(index([IX_bigTransactionHistory_TranasctionDate_Filtered]))
	inner join dbo.bigProduct prod
		on tr.ProductID = prod.ProductID
  where TransactionDate >= '2011-01-01'
  group by Year(TransactionDate)
  having Sum([Quantity]) > 10000
  order by Year(TransactionDate)
  option (recompile);


-- Read from the table with filtered nonclustered columnstore index
SELECT Year([TransactionDate]) as Year
      ,Sum([Quantity]) as TotalQuantity
      ,Sum([ActualCost]) as TotalCost
  FROM [dbo].[bigTransactionHistory_filtered] tr --with(index([IX_bigTransactionHistory_TranasctionDate_Filtered]))
	inner join dbo.bigProduct prod
		on tr.ProductID = prod.ProductID
  where TransactionDate >= '2011-01-01'
  group by Year(TransactionDate)
  having Sum([Quantity]) > 10000
  order by Year(TransactionDate)
  option (recompile);