

set statistics time, io on

ALTER DATABASE [ContosoRetailDW] SET COMPATIBILITY_LEVEL = 130
GO

/* Great Data Tyope Support */
select max(SalesQuantity)
    from dbo.FactOnlineSales;

/* I said 8 Bytes at Maximum */
select max(SalesOrderNumber)
	from dbo.FactOnlineSales;

/* Group By Makes Aggregate Pushdown much slower */
select sales.ProductKey, 
	sum(sales.SalesQuantity)
	from dbo.FactOnlineSales sales
	group by sales.ProductKey;