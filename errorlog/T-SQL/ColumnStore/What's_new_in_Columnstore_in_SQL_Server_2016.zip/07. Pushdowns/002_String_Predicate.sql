set statistics time, io on
dbcc dropcleanbuffers
dbcc freeproccache

ALTER DATABASE [ContosoRetailDW] SET COMPATIBILITY_LEVEL = 130
GO

select sum(SalesAmount), sum(SalesAmount) - sum(SalesAmount*prom.DiscountPercent)
	from dbo.FactOnlineSales sales
		inner join dbo.DimPromotion prom
			on sales.PromotionKey = prom.PromotionKey
	where SalesOrderNumber like N'2008%' and
		SalesOrderNumber not like N'%000' 
	option (recompile, maxdop  2);

ALTER DATABASE [ContosoRetailDW] SET COMPATIBILITY_LEVEL = 120
GO
dbcc dropcleanbuffers
dbcc freeproccache


select sum(SalesAmount), sum(SalesAmount) - sum(SalesAmount*prom.DiscountPercent)
	from dbo.FactOnlineSales sales
		inner join dbo.DimPromotion prom
			on sales.PromotionKey = prom.PromotionKey
	where SalesOrderNumber like N'2008%' and
		SalesOrderNumber not like N'%000' 
	option (recompile, maxdop  2);

ALTER DATABASE [ContosoRetailDW] SET COMPATIBILITY_LEVEL = 130
GO