create table dbo.CCI_Indexes_2016(
	c1 bigint,
	c2 numeric (36,3),
	c3 bit,
	c4 smallint,
	Index PK_CCI_Indexes_2016 Clustered Columnstore ); 


-- Add 2 Nonclustered Indexes for Range & Point Lookups
create nonclustered index IX_CCI_Indexes_2016_1
	on dbo.CCI_Indexes_2016 (c1,c2);

create nonclustered index IX_CCI_Indexes_2016_2
	on dbo.CCI_Indexes_2016 (c2,c4) include(c3);


-- Insert some data
insert into dbo.CCI_Indexes_2016
	(c1,c2,c3,c4)
	values
	(1,16.,1,19),
	(2,7.21,1,256),
	(3,22.55,0,128),
	(4,3.94,1,31);

-- Check out the internal structures
select object_name(part.object_id) as TableName, 
	part.object_id, part.partition_id,
	ind.name as IndexName, part.index_id, 
	part.hobt_id,
	part.internal_object_type, part.internal_object_type_desc,
	part.row_group_id, part.rows, part.data_compression, part.data_compression_desc
	from sys.internal_partitions part
		left outer join sys.indexes ind
			on part.object_id = ind.object_id and part.index_id = ind.index_id
	where part.object_id = object_id('dbo.CCI_Indexes_2016');	

-- Rebuild our Columnstore
alter index PK_CCI_Indexes_2016
	on dbo.CCI_Indexes_2016
	Rebuild;

-- Check out the internal structures
select object_name(part.object_id) as TableName, 
	part.object_id, part.partition_id,
	ind.name as IndexName, part.index_id, 
	part.hobt_id,
	part.internal_object_type, part.internal_object_type_desc,
	part.row_group_id, part.rows, part.data_compression, part.data_compression_desc
	from sys.internal_partitions part
		left outer join sys.indexes ind
			on part.object_id = ind.object_id and part.index_id = ind.index_id
	where part.object_id = object_id('dbo.CCI_Indexes_2016');	


-- Add a full segment
set nocount on

declare @i as int;
declare @max as int;
select @max = isnull(max(C1),0) from dbo.CCI_Indexes_2016;
set @i = 1;

begin tran
while @i <= 1048577
begin
	insert into dbo.CCI_Indexes_2016
		default values

	set @i = @i + 1;
end;
commit;

checkpoint;

-- Check out the internal structures
select object_name(part.object_id) as TableName, 
	part.object_id, part.partition_id,
	ind.name as IndexName, part.index_id, 
	part.hobt_id,
	part.internal_object_type, part.internal_object_type_desc,
	part.row_group_id, part.rows, part.data_compression, part.data_compression_desc
	from sys.internal_partitions part
		left outer join sys.indexes ind
			on part.object_id = ind.object_id and part.index_id = ind.index_id
	where part.object_id = object_id('dbo.CCI_Indexes_2016');	

-- Rebuild our table
alter table dbo.CCI_Indexes_2016
   rebuild;

-- Check out the internal structures
select object_name(part.object_id) as TableName, 
	part.object_id, part.partition_id,
	ind.name as IndexName, part.index_id, 
	part.hobt_id,
	part.internal_object_type, part.internal_object_type_desc,
	part.row_group_id, part.rows, part.data_compression, part.data_compression_desc
	from sys.internal_partitions part
		left outer join sys.indexes ind
			on part.object_id = ind.object_id and part.index_id = ind.index_id
	where part.object_id = object_id('dbo.CCI_Indexes_2016');	

-- CISL Get Columnstore Row Groups
exec dbo.cstore_GetRowGroups @tableName = 'CCI_Indexes_2016';
exec dbo.cstore_GetRowGroupsDetails @tableName = 'CCI_Indexes_2016';

