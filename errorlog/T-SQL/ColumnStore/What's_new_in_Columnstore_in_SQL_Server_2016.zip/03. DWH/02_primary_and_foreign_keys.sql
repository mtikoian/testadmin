-- Create 2 tables with Foreign key
create table dbo.T1(
	c1 int identity(1,1),
	c2 varchar(20),
	constraint UQ_T1_C1 unique nonclustered (c1),
	index CCI_T1 clustered columnstore );

create table dbo.T2(
	id int,
	c1_t1 int not null,
	constraint FK_T2_T1_c1 
		foreign key (c1_t1) 
			references dbo.T1(c1) );

-- Insert some data
insert into dbo.T1 (c2)
	values ('Alex'), ('Brown'), ('Cat');

insert into dbo.T2 (id, c1_t1)
	values (1, 1 );

-- Test query
select *
	from dbo.T1
	inner join dbo.T2
		on T1.c1 = T2.c1_t1;

-- let�s add a clustered columnstore index to the T2 table, to see if the foreign key is compatible with Columnstore
create clustered columnstore index CCI_T2
	on dbo.T2;