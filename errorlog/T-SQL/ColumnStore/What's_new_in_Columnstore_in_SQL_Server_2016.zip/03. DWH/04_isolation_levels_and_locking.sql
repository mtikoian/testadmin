IF OBJECT_ID('dbo.CCTest', 'U') IS NOT NULL
	drop table dbo.CCTest;
 
create table dbo.CCTest(
	id int not null,-- primary key clustered,
	name varchar(50) not null,
	lastname varchar(50) not null );
GO
 
create clustered columnstore index CCL_CCTest
	on dbo.CCTest;
GO


-- Create Nonclustered Columnstore
create nonclustered index IX_CCTest_id
	on dbo.CCTest( id ) 
		Include ( lastname );

-- Set ContosoRetailDW to Read Commited Snapshot
alter database ContosoRetailDW
    set SINGLE_USER WITH ROLLBACK IMMEDIATE;

ALTER DATABASE ContosoRetailDW SET READ_COMMITTED_SNAPSHOT ON 
	WITH NO_WAIT
GO

alter database ContosoRetailDW
    set MULTI_USER;
GO

-- Data Insertion works
SET TRANSACTION ISOLATION LEVEL READ COMMITTED

declare @i as int;
declare @max as int;
select @max = isnull(max(id),0) from dbo.CCTest;
set @i = 1;

begin tran
while @i <= 50000
begin
	insert into dbo.CCTest
		( id, name, lastname )
		values
		( @max + @i, 'SomeName_', 'SomeLastName_' );

	set @i = @i + 1;
end;
commit;

-- Start a new transation
begin tran
		
	insert into dbo.CCTest
		( id, name, lastname )
		values
		( 100000, 'SomeName_', 'SomeLastName_' );

commit;

-- What's being locked, open it in a new window
SELECT dm_tran_locks.request_session_id,
       dm_tran_locks.resource_database_id,
       DB_NAME(dm_tran_locks.resource_database_id) AS dbname,
       CASE
           WHEN resource_type = 'object'
               THEN OBJECT_NAME(dm_tran_locks.resource_associated_entity_id)
           ELSE OBJECT_NAME(partitions.OBJECT_ID)
       END AS ObjectName,
       partitions.index_id,
       indexes.name AS index_name,
       dm_tran_locks.resource_type,
       dm_tran_locks.resource_description,
       dm_tran_locks.resource_associated_entity_id,
       dm_tran_locks.request_mode,
       dm_tran_locks.request_status
FROM sys.dm_tran_locks
LEFT JOIN sys.partitions ON partitions.hobt_id = dm_tran_locks.resource_associated_entity_id
JOIN sys.indexes ON indexes.OBJECT_ID = partitions.OBJECT_ID AND indexes.index_id = partitions.index_id
WHERE resource_associated_entity_id > 0
  AND resource_database_id = DB_ID()
ORDER BY request_session_id, resource_associated_entity_id 