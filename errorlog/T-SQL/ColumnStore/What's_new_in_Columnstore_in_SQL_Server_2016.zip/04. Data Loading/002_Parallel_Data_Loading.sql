use ContosoRetailDW;

truncate table [dbo].[FactOnlineSales_CCI];
  
set statistics time, io on;
 
-- This query is loading 10 Million Rows and it should take around 35 Seconds
insert into [dbo].[FactOnlineSales_CCI]  
                        (
                        OnlineSalesKey, StoreKey, ProductKey, PromotionKey, CurrencyKey, CustomerKey
                        ) 
 
select distinct top 10000000 OnlineSalesKey,  store.StoreKey, sales.ProductKey, PromotionKey, CurrencyKey, CustomerKey 
  FROM [dbo].[FactOnlineSales] sales
        inner join dbo.DimProduct prod
                                on sales.ProductKey = prod.ProductKey
        inner join dbo.DimStore store
                                on sales.StoreKey = store.StoreKey
  where prod.ProductSubcategoryKey >= 10
                        and store.StoreManager >= 30
  option (recompile);


-- Open ROW_GROUPS from CISL
exec dbo.cstore_GetRowGroupsDetails @tableName = 'FactOnlineSales_CCI'

select *
	from sys.column_store_row_groups
	where object_schema_name(object_id) + '.' + object_name(object_id) = 'dbo.FactOnlineSales_CCI'
	order by row_group_id asc;

-- Truncate table
truncate table [dbo].[FactOnlineSales_CCI];

-- This query should take around 10 Seconds vs 18 Seconds before (earlier releases it was 30 Seconds)
insert into [dbo].[FactOnlineSales_CCI] WITH (TABLOCK)
                        (
                        OnlineSalesKey, StoreKey, ProductKey, PromotionKey, CurrencyKey, CustomerKey
                        ) 
 
select distinct top 10000000 OnlineSalesKey,  store.StoreKey, sales.ProductKey, PromotionKey, CurrencyKey, CustomerKey 
  FROM [dbo].[FactOnlineSales] sales
        inner join dbo.DimProduct prod
                                on sales.ProductKey = prod.ProductKey
        inner join dbo.DimStore store
                                on sales.StoreKey = store.StoreKey
  where prod.ProductSubcategoryKey >= 10
                        and store.StoreManager >= 30
  option (recompile);

-- Open ROW_GROUPS from CISL
exec dbo.cstore_GetRowGroupsDetails;

select *
	from sys.column_store_row_groups
	where object_schema_name(object_id) + '.' + object_name(object_id) = 'dbo.FactOnlineSales_CCI'
	order by row_group_id asc;