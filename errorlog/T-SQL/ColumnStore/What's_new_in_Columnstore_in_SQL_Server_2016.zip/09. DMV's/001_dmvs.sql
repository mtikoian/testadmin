--dbcc dropcleanbuffers;

-- Columnstore Object Pool
select db_name(p.database_id) as DBname, p.database_id, 
	object_name(p.object_id) as TableName, p.object_id,
	ind.name as IndexName, p.index_id, p.partition_number,
	col.name, p.column_id,
	p.row_group_id, p.object_type, p.object_type_desc,
	p.access_count, p.memory_used_in_bytes, p.object_load_time
	from sys.dm_column_store_object_pool p
		inner join sys.columns col
			on p.object_id = col.object_id and p.column_id = col.column_id
		inner join sys.indexes ind
			on p.object_id = ind.object_id and p.index_id = ind.index_id
	order by p.object_id, partition_number, p.column_id, row_group_id

		
select object_name(st.object_id) as TableName, st.object_id, 
	ind.name as IndexName, st.index_id,
	st.partition_number, st.row_group_id, st.index_scan_count, st.scan_count,
	st.delete_buffer_scan_count, st.row_group_lock_count,
	st.row_group_lock_wait_count, st.row_group_lock_wait_in_ms
	, *
	from sys.dm_db_column_store_row_group_operational_stats st
		inner join sys.indexes ind
			on st.object_id = ind.object_id and st.index_id = ind.index_id
	order by st.object_id, st.partition_number, st.row_group_id


select object_name(phst.object_id) as TableName, phst.object_id, 
	ind.name as IndexName, phst.index_id, partition_number,
	delta_store_hobt_id,
	state, state_desc, total_rows, deleted_rows, size_in_bytes,
	trim_reason, trim_reason_desc, 
	phst.transition_to_compressed_state, phst.transition_to_compressed_state_desc,
	phst.has_vertipaq_optimization,
	generation
	from sys.dm_db_column_store_row_group_physical_stats phst
		inner join sys.indexes ind
			on phst.object_id = ind.object_id and phst.index_id = ind.index_id
	--where phst.object_id = object_id('dbo.CCI_Indexes_2016')	
	order by phst.object_id, phst.partition_number, phst.row_group_id


select object_name(part.object_id) as TableName, 
	part.object_id, part.partition_id,
	ind.name as IndexName, part.index_id, 
	part.hobt_id,
	part.internal_object_type, part.internal_object_type_desc,
	part.row_group_id, part.rows, part.data_compression, part.data_compression_desc
	,*
	from sys.internal_partitions part
		left outer join sys.indexes ind
			on part.object_id = ind.object_id and part.index_id = ind.index_id
	--where part.object_id = object_id('dbo.CCI_Indexes_2016')	


-- Old
select *
	from sys.column_store_segments

select *
	from sys.column_store_row_groups rg
	where rg.object_id = object_id('dbo.CCI_Indexes_2016')	

select *
	from sys.column_store_dictionaries


-- Hekaton
-- (just hash indexes)
select *
	from sys.dm_db_xtp_hash_index_stats;

-- Might contain some information, but apprently useless for Columnstore
select *
	from sys.dm_db_xtp_index_stats;

-- Consider to be interesting for Columnstore (should have InMemory Columnstore info)
select *
	from sys.dm_db_xtp_memory_consumers;

select *
	from sys.dm_db_xtp_nonclustered_index_stats;

select *
	from sys.dm_db_xtp_object_stats;
		
select *
	from sys.dm_db_xtp_table_memory_stats;