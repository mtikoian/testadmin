-- Enable CDC on 
exec sys.sp_cdc_enable_db;

-- This will generate an error message
exec sys.sp_cdc_enable_table
	@source_schema = N'dbo',
	@source_name   = N'FactOnlineSales',
	@role_name     = NULL,
	@filegroup_name = N'PRIMARY',
	@supports_net_changes = 1;

-- Let's create a Unique Nonclustered Index
create unique nonclustered index UQ_FactOnlineSales
	on dbo.FactOnlineSales (OnlineSalesKey)
	with (DATA_COMPRESSION = PAGE);
	
-- This will not work as well
EXEC sys.sp_cdc_enable_table
	@source_schema = N'dbo',
	@source_name   = N'FactOnlineSales',
	@role_name     = NULL,
	@filegroup_name = N'PRIMARY',
	@supports_net_changes = 1,
	@index_name = 'UQ_FactOnlineSales';

-- Drop Clustered Columnstroe
DROP INDEX [PK_FactOnlineSales] 
	ON [dbo].[FactOnlineSales];

-- Create NONCLUSTERED Columnstore
create nonclustered columnstore index [NCCI_FactSales_SalesKey]
	on [dbo].[FactSales] (SalesKey, DateKey, channelKey, StoreKey, ProductKey, PromotionKey, CurrencyKey, UnitCost, UnitPrice, SalesQuantity, ReturnQuantity, ReturnAmount, DiscountQuantity, DiscountAmount, TotalCost, SalesAmount, ETLLoadID, LoadDate, UpdateDate)

-- This time it will work
EXEC sys.sp_cdc_enable_table
	@source_schema = N'dbo',
	@source_name   = N'FactSales',
	@role_name     = NULL,
	@filegroup_name = N'PRIMARY',
	@supports_net_changes = 1

-- Just check it
exec sys.sp_cdc_help_change_data_capture;