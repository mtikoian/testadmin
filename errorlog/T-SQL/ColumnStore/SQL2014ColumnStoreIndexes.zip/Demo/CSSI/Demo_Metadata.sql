USE AdventureworksDW2008_4M
go

SELECT *
FROM sys.column_store_segments
ORDER BY column_id, segment_id

--note the min_data_id, max_data_id - can allow for segment elimination (columnid 3 and 4 for example)
--can actually identify segment elimination using XEvents

SELECT *
FROM sys.column_store_segments
WHERE column_id = 10
ORDER BY segment_id

SELECT encoding_type, COUNT(*)
FROM sys.column_store_segments
GROUP BY encoding_type

SELECT *
FROM sys.column_store_dictionaries

--note column 10 has huge dictionary
sp_help factresellersalespart


SELECT i.name, p.object_id, p.index_id, i.type_desc, 
    COUNT(*) AS number_of_segments
FROM sys.column_store_segments AS s 
INNER JOIN sys.partitions AS p 
    ON s.hobt_id = p.hobt_id 
INNER JOIN sys.indexes AS i 
    ON p.object_id = i.object_id
--WHERE i.type = 6
GROUP BY i.name, p.object_id, p.index_id, i.type_desc ;
GO

SELECT SUM(on_disk_size_MB) AS TotalSizeInMB
  FROM
  (
     (SELECT SUM(css.on_disk_size)/(1024.0*1024.0) on_disk_size_MB
      FROM sys.indexes AS i
      JOIN sys.partitions AS p
          ON i.object_id = p.object_id 
      JOIN sys.column_store_segments AS css
          ON css.hobt_id = p.hobt_id
      WHERE i.object_id = object_id('FactResellerSalesPartCCSI'))
--      AND i.type_desc = 'NONCLUSTERED COLUMNSTORE') 
    UNION ALL
     (SELECT SUM(csd.on_disk_size)/(1024.0*1024.0) on_disk_size_MB
      FROM sys.indexes AS i
      JOIN sys.partitions AS p
          ON i.object_id = p.object_id 
      JOIN sys.column_store_dictionaries AS csd
          ON csd.hobt_id = p.hobt_id
      WHERE i.object_id = object_id('FactResellerSalesPartCCSI'))
--      AND i.type_desc = 'NONCLUSTERED COLUMNSTORE') 
  ) AS SegmentsPlusDictionary

--what about index usage?
SELECT DB_NAME(Database_ID) DBName,
       SCHEMA_NAME(schema_id) AS SchemaName,
       OBJECT_NAME(ius.OBJECT_ID) ObjName,
       i.type_desc, i.name,
       user_seeks, user_scans,
       user_lookups, user_updates --,*
  FROM sys.dm_db_index_usage_stats ius
 INNER JOIN sys.indexes i ON i.index_id = ius.index_id
        AND ius.OBJECT_ID = i.OBJECT_ID
 INNER JOIN sys.tables t ON t.OBJECT_ID = i.OBJECT_ID
GO

SELECT * FROM sys.column_store_row_groups 

