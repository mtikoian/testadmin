USE AdventureworksDW2008_4M
go
SET STATISTICS IO ON
GO

DBCC DROPCLEANBUFFERS

DBCC freeproccache
go
--NOTE: this query is actually covered by a tight NC index on ProductKey!!
SELECT d.CalendarYear,
      d.CalendarQuarter,
      COUNT(*) AS NumberSold
  FROM dbo.FactResellerSalesPartCCSI AS f
--  FROM dbo.FactResellerSalesPart AS f
      JOIN dbo.DimDate AS d
      ON f.OrderDateKey = d.DateKey
--  WHERE ProductKey = 548 --some
  WHERE ProductKey = 256 --very few
--  WHERE ProductKey = 471 --quite a bit
  GROUP BY d.CalendarYear, d.CalendarQuarter
  ORDER BY d.CalendarYear, d.CalendarQuarter
OPTION (MAXDOP 1) --disables Batch Mode Processing
OPTION (MAXDOP 2) --shows just how awesome BMP is!!


DBCC DROPCLEANBUFFERS

DBCC freeproccache
go
SELECT d.CalendarYear,
      d.CalendarQuarter,
      COUNT(*) AS NumberSold, 
      SUM(SalesAmount) AS TotalSales --forces a hit on fact table
  FROM dbo.FactResellerSalesPartCCSI AS f
--  FROM dbo.FactResellerSalesPart AS f
      JOIN dbo.DimDate AS d
      ON f.OrderDateKey = d.DateKey
--  WHERE ProductKey = 548 --some
--  WHERE ProductKey = 256 --very few
--  WHERE ProductKey = 471 --quite a bit
  GROUP BY d.CalendarYear, d.CalendarQuarter
  ORDER BY d.CalendarYear, d.CalendarQuarter
--OPTION (MAXDOP 1) --disables Batch Mode Processing, EVEN IN 2014 CCSI!
OPTION (MAXDOP 2) --shows just how awesome BMP is!!



--partition elimination still works, obviously

DBCC freeproccache
go
--DBCC DROPCLEANBUFFERS
go
SELECT d.CalendarYear,
      d.CalendarQuarter,
      COUNT(*) AS NumberSold, 
      SUM(SalesAmount) AS TotalSales --forces a hit on fact table
--  FROM dbo.FactResellerSalesPartCCSI AS f
  FROM dbo.FactResellerSalesPart AS f
      JOIN dbo.DimDate AS d
      ON f.OrderDateKey = d.DateKey
WHERE OrderDateKey >= 20040101 and OrderDateKey < 20040201
  GROUP BY d.CalendarYear, d.CalendarQuarter
  ORDER BY d.CalendarYear, d.CalendarQuarter


--ORDERING can be suboptimal compared to clustered index
select top 10 * 
from FactResellerSalesPartCCSI
--from FactResellerSalesPart
order by OrderDateKey desc

20020701
20040708
