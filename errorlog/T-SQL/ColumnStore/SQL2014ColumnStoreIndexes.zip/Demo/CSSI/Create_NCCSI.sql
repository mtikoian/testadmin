CREATE NONCLUSTERED COLUMNSTORE INDEX [NCCSI_FactResellerSalesPart] ON [dbo].[FactResellerSalesPart]
(
	[ProductKey], 
	[OrderDateKey], 
	[DueDateKey],
	[ShipDateKey],
	[ResellerKey],
	[EmployeeKey],
	[PromotionKey], 
	[CurrencyKey],
	[SalesTerritoryKey],
	[SalesOrderNumber],
	[SalesOrderLineNumber],
	[RevisionNumber],
	[OrderQuantity],
	[UnitPrice],
	[ExtendedAmount], 
	[UnitPriceDiscountPct],
	[DiscountAmount],
	[ProductStandardCost],
	[TotalProductCost],
	[SalesAmount], 
	[TaxAmt],
	[Freight],
	[CarrierTrackingNumber],
	[CustomerPONumber]
)WITH (DROP_EXISTING = OFF)
GO


