USE AdventureworksDW2008_4M
go
SET STATISTICS IO ON
GO

DBCC freeproccache
go
--NOTE: this query is actually covered by a tight NC index on ProductKey!!
SELECT d.CalendarYear,
      d.CalendarQuarter,
      COUNT(*) AS NumberSold
  FROM dbo.FactResellerSalesPart AS f WITH (INDEX(NCCSI_FactResellerSalesPart))
      JOIN dbo.DimDate AS d
      ON f.OrderDateKey = d.DateKey
--  WHERE ProductKey = 215  --354K rows
--  WHERE ProductKey = 256 --1700 rows
--  WHERE ProductKey = 471 --830k rows
  GROUP BY d.CalendarYear, d.CalendarQuarter
  ORDER BY d.CalendarYear, d.CalendarQuarter
OPTION (IGNORE_NONCLUSTERED_COLUMNSTORE_INDEX)
--OPTION (MAXDOP 1) --disables Batch Mode Processing
OPTION (MAXDOP 2) --shows just how awesome BMP is!!

NO WHERE clause, cold cache: COLUMN store = 2 SECONDS, NO COLUMN store = 57 seconds

BUG?!? Note statsIO CHANGES, AND profiler cannot be correct!

anyone see a more efficient way TO WRITE the above query??
SELECT TOP 10 * FROM dbo.FactResellerSalesPart
can very frequently do this type of query in OLAP queries


DBCC freeproccache
go
--DBCC DROPCLEANBUFFERS
go
SELECT d.CalendarYear,
      d.CalendarQuarter,
      COUNT(*) AS NumberSold, 
      SUM(SalesAmount) AS TotalSales --forces a hit on fact table
  FROM dbo.FactResellerSalesPart AS f --WITH (INDEX(NCCSI_FactResellerSalesPart))
      JOIN dbo.DimDate AS d
      ON f.OrderDateKey = d.DateKey
--  WHERE ProductKey = 548 --115K approximate crossover point, but still slow! 580K reads, 80 seconds
--  WHERE ProductKey = 256 --1700 rows
--  WHERE ProductKey = 471 --830k rows - table scan!! 650K reads, 92 seconds
  GROUP BY d.CalendarYear, d.CalendarQuarter
  ORDER BY d.CalendarYear, d.CalendarQuarter
OPTION (IGNORE_NONCLUSTERED_COLUMNSTORE_INDEX)
--OPTION (MAXDOP 1) --disables Batch Mode Processing
OPTION (MAXDOP 2) --shows just how awesome BMP is!!

NO WHERE clause, cold cache: COLUMN store = 8 SECONDS, NO COLUMN store = 60 seconds
