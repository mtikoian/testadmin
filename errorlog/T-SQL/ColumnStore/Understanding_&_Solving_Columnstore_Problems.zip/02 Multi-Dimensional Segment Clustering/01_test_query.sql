/* 
 * Queries for testing SQL Server 2014 improvements
 * by Niko Neugebauer (http://www.nikoport.com)
 * These queries are to be run on a Contoso BI Database (http://www.microsoft.com/en-us/download/details.aspx?displaylang=en&id=18279)
 *
 * Measure IO for both of the queries
 */
 
use ContosoRetailDW;

set statistics io on

select sum(SalesAmount)
	from dbo.FactOnlineSales
	where (DateKey>'2008-01-01' and  DateKey <'2009-01-01')
		and StoreKey = 199;


select sum(SalesAmount)
	from dbo.FactOnlineSales
	where (DateKey>'2009-01-01' and  DateKey <'2010-01-01')
		and SalesAmount > 1000;