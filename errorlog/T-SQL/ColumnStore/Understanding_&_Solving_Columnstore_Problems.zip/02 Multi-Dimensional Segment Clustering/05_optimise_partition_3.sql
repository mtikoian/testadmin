/* 
 * Queries for testing SQL Server 2014 Columnstore improvements
 * by Niko Neugebauer (http://www.nikoport.com)
 * These queries are to be run on a Contoso BI Database (http://www.microsoft.com/en-us/download/details.aspx?displaylang=en&id=18279)
 *
 * Take out the data out of the 3rd partition, align its segments and switch it in back into the table
 */
 
 use ContosoRetailDW;

-- Load Data from the year 2008
SELECT * 
	into dbo.FactOnlineSales2008
FROM dbo.FactOnlineSales
WHERE $PARTITION.pfOnlineSalesDate(DateKey) = 3;

-- Creation of a traditional Clustered Index 
Create Clustered Index PK_FactOnlineSales2008
	on dbo.FactOnlineSales2008 (StoreKey) 
	WITH (DATA_COMPRESSION = PAGE)
		on Columnstore2008;

checkpoint

-- Create Partitioned Clustered Columnstore Index
Create Clustered Columnstore Index PK_FactOnlineSales2008 on dbo.FactOnlineSales2008
     with (DROP_EXISTING = ON, MAXDOP = 1);

-- Remove unordered data from the partition (We have a copy of the data in our staging table)
delete FROM dbo.FactOnlineSales
	WHERE $PARTITION.pfOnlineSalesDate(DateKey) = 3;

-- Add Constraint
alter table dbo.FactOnlineSales2008
	add Constraint CK_FactOnlineSales2008_Year CHECK (DateKey>='2008-01-01' and  DateKey <'2009-01-01');

-- Switch Data In
ALTER TABLE FactOnlineSales2008
	SWITCH TO FactOnlineSales PARTITION 3;

-- Check out the structure
select partition_number, segment_id, row_count, base_id, min_data_id, max_data_id
	from sys.column_store_segments seg
		inner join sys.partitions part
			on seg.partition_id = part.partition_id
	where column_id = 3
		and part.object_id = object_id('FactOnlineSales')
	order by partition_number, segment_id;

-- Measure the performance and compare with the baseline
set statistics io on

select sum(SalesAmount)
	from dbo.FactOnlineSales
	where (DateKey>'2008-01-01' and  DateKey <'2009-01-01')
		and StoreKey = 199;