/* 
 * Queries for testing SQL Server 2014 Columnstore improvements
 * by Niko Neugebauer (http://www.nikoport.com)
 * These queries are to be run on a Contoso BI Database (http://www.microsoft.com/en-us/download/details.aspx?displaylang=en&id=18279)
 *
 * Check partition information and measure IO performance
 */
 use ContosoRetailDW;

-- Check data for for columns 
select partition_number, segment_id, row_count, base_id, min_data_id, max_data_id
	from sys.column_store_segments seg
		inner join sys.partitions part
			on seg.partition_id = part.partition_id
	where column_id = 11
		and part.object_id = object_id('FactOnlineSales');


-- Partitioning Information
SELECT $PARTITION.pfOnlineSalesDate(DateKey) AS Partition,  COUNT(*) AS [Rows Count]
	, Min(Year(DateKey)) as [Min],  Max(Year(DateKey)) as [Max] 
	FROM dbo.FactOnlineSales
GROUP BY $PARTITION.pfOnlineSalesDate(DateKey)
ORDER BY Partition ;


-- Lets measure the performance through the reads
set statistics io on

select sum(SalesAmount)
	from dbo.FactOnlineSales
	where (DateKey>'2008-01-01' and  DateKey <'2009-01-01')
		and StoreKey = 199;
-- 1211 reads

select sum(SalesAmount)
	from dbo.FactOnlineSales
	where (DateKey>'2009-01-01' and  DateKey <'2010-01-01')
		and SalesAmount > 1000;
-- 1325 reads