/* 
 * Queries for testing SQL Server 2014 Columnstore improvements
 * by Niko Neugebauer (http://www.nikoport.com)
 * These queries are to be run on a Contoso BI Database (http://www.microsoft.com/en-us/download/details.aspx?displaylang=en&id=18279)
 *
 * Take out the data out of the 3rd partition, align its segments and switch it in back into the table
 */
 
 use ContosoRetailDW;

-- Load Data from the year 2009
SELECT * 
	into dbo.FactOnlineSales2009
FROM dbo.FactOnlineSales
WHERE $PARTITION.pfOnlineSalesDate(DateKey) = 4;

-- Creation of a traditional Clustered Index 
Create Clustered Index PK_FactOnlineSales2009
	on dbo.FactOnlineSales2009 (SalesAmount) 
	WITH (DATA_COMPRESSION = PAGE)
		on Columnstore2009;

checkpoint

-- Create Partitioned Clustered Columnstore Index
Create Clustered Columnstore Index PK_FactOnlineSales2009 on dbo.FactOnlineSales2009
     with (DROP_EXISTING = ON, MAXDOP = 1);

checkpoint

-- Remove unordered data from the partition (We have a copy of the data in our staging table)
delete FROM dbo.FactOnlineSales
	WHERE $PARTITION.pfOnlineSalesDate(DateKey) = 4;

-- Add Constraint
alter table dbo.FactOnlineSales2009
	add Constraint CK_FactOnlineSales2009_Year CHECK (DateKey>='2009-01-01' and  DateKey <'2010-01-01');

-- Switch Data In
ALTER TABLE FactOnlineSales2009
	SWITCH TO FactOnlineSales PARTITION 4;

-- Check out the structure
SELECT partition_number, segment_id, row_count, base_id, min_data_id, max_data_id
	from sys.column_store_segments seg
		inner join sys.partitions part
			on seg.partition_id = part.partition_id
	where column_id = 11
		and part.object_id = object_id('FactOnlineSales')
	order by partition_number, segment_id;

-- Measure the performance and compare with the baseline
set statistics io on

select sum(SalesAmount)
	from dbo.FactOnlineSales
	where (DateKey>'2009-01-01' and  DateKey <'2010-01-01')
		and SalesAmount > 1000;