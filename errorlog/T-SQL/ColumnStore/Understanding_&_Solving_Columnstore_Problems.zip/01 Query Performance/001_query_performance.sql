/* 
 * Queries for testing SQL Server 2014 Columnstore improvements
 * by Niko Neugebauer (http://www.nikoport.com)
 * These queries are to be run on a Contoso BI Database (http://www.microsoft.com/en-us/download/details.aspx?displaylang=en&id=18279)
 *
 * Compares performance of 2 similar queries, delivering the same results 
 */

set statistics time on

select sum(SalesAmount), sum(SalesAmount) - sum(SalesAmount*prom.DiscountPercent)
	from dbo.FactOnlineSales sales
		inner join dbo.DimPromotion prom
			on sales.PromotionKey = prom.PromotionKey
	where DateKey > '2008-01-01 00:00:00.000';

select sum(SalesAmount), sum(SalesAmount) - sum(SalesAmount*prom.DiscountPercent)
	from dbo.FactOnlineSales sales
		inner join dbo.DimPromotion prom
			on sales.PromotionKey = prom.PromotionKey
	where SalesOrderNumber > N'20080102127644';

-- There is a very significant difference in the execution times. 177 ms vs 558 ms (on my test VM)

-- 1. Let's blame it on the Segment Elimination
-- -> start CCI_SegmentElimination session and check


/* **** **** ***** */
-- Prove with the DMV Information
select column_id, segment_id, has_nulls, base_id, magnitude, min_data_id, max_data_id, row_count
	from sys.column_store_segments seg
		inner join sys.partitions part
	on part.hobt_id = seg.hobt_id
	where object_id = object_id('dbo.FactOnlineSales')
		and column_id = 8 /*SalesOrderNumber*/ or column_id = 2 /*DateKey*/
	order by column_id, segment_id
