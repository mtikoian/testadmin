/* 
 * Queries for testing SQL Server 2014 Columnstore improvements
 * by Niko Neugebauer (http://www.nikoport.com)
 * 
 * Creates a test table dbo.Pressure in the Columnstore_Play DB, which is then filled with data that will provoke Dictionary Pressure
 */
 use Columnstore_Play;

IF OBJECT_ID('dbo.Pressure', 'U') IS NOT NULL
  DROP TABLE dbo.Pressure;

CREATE TABLE dbo.Pressure (
    c1 int NOT NULL,
    c2 int NOT NULL,
    c3 char(40) NOT NULL,
    c4 varchar(800) NOT NULL,
	c5 int not null
);

set nocount on

declare @outerloop int = 0
declare @i int = 0

while (@outerloop < 1100000)
begin
       Select @i = 0

	   begin tran
       while (@i < 2000)
	   begin
           insert dbo.Pressure values (@i + @outerloop, @i + @outerloop, 'a', 
                     concat (CONVERT(varchar, @i + @outerloop), (replicate ('b', 750)))
					 ,ABS(CHECKSUM(NewId())) % 2000000 )
           set @i += 1;
       end
	   commit

       set @outerloop = @outerloop + @i
       set @i = 0
end
go


CREATE CLUSTERED COLUMNSTORE INDEX 
	CCI_Pressure ON dbo.Pressure with (maxdop = 1)


--CREATE CLUSTERED COLUMNSTORE INDEX t_colstore_cci ON dbo.t_colstore with (maxdop = 4);

--CREATE CLUSTERED INDEX CCI_Pressure ON dbo.Pressure (c4) with (maxdop = 4, drop_existing = on)


--CREATE CLUSTERED COLUMNSTORE INDEX t_colstore_cci ON dbo.t_colstore with (maxdop = 4, drop_existing = on)