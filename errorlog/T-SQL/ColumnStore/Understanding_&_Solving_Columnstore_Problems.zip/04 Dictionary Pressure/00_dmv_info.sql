/* 
 * Queries for testing SQL Server 2014 Columnstore improvements
 * by Niko Neugebauer (http://www.nikoport.com)
 *
 * Obtains information about dbo.Pressure table, that is stored in the Columnstore_Play database. Change name of the DB to the one that you are using.  
 */
 use Columnstore_Play;

select partition_number, row_group_id, total_rows, size_in_bytes
	from sys.column_store_row_groups
	where object_id = object_id('dbo.Pressure')
	order by row_group_id

select column_id, segment_id, primary_dictionary_id, secondary_dictionary_id, row_count, on_disk_size
	from sys.column_store_segments seg
	inner join sys.partitions p
		ON seg.hobt_id = p.hobt_id
	where object_id = object_id('dbo.Pressure')
		and (primary_dictionary_id <> -1 or
			secondary_dictionary_id <> -1 )

select column_id, dictionary_id, entry_count, on_disk_size --*
	from sys.column_store_dictionaries dict
	inner join sys.partitions p
		ON dict.hobt_id = p.hobt_id
	where object_id = object_id('dbo.Pressure')

