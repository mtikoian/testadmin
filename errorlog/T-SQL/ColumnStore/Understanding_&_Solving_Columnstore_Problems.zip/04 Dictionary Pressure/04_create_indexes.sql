/* 
 * Queries for testing SQL Server 2014 Columnstore improvements
 * by Niko Neugebauer (http://www.nikoport.com)
 * 
 * Creates Clustered Columnstore Index on the sample dbo.Pressure table
 */

-- Drop Existing Columnstore
DROP INDEX [CCI_Pressure] ON [dbo].[Pressure];

checkpoint

-- Create a Partitioned Rowstore Clustered Index
Create Clustered Index CCI_Pressure
	on dbo.Pressure (c1)
        with (DATA_COMPRESSION = PAGE)
	 ON ColumstorePartitioning (c1);

checkpoint

-- Create Partitioned Clustered Columnstore Index
Create Clustered Columnstore Index CCI_Pressure on dbo.Pressure
     with (DROP_EXISTING = ON, maxdop = 1)
	 ON ColumstorePartitioning (c1)

