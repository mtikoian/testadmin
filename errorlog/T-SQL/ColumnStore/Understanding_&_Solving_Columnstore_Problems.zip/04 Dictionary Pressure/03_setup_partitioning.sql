/* 
 * Queries for testing SQL Server 2014 Columnstore improvements
 * by Niko Neugebauer (http://www.nikoport.com)
 * 
 * Creates fixed number of File Groups for improving situation with the Dictionary Pressure. 
 */

declare @tsql as nvarchar(4000);
declare @partitions as nvarchar(4000) = '';
declare @filegroups as nvarchar(4000) = '';
declare @i as int = 1;
declare @maxFG as int = 13;

while @i <= @maxFG
begin
	set @tsql = 'alter database Columnstore_Play
					add filegroup fg' + cast(@i as varchar(2)) + ';
				 GO';
	print @tsql;

	set @tsql = 
		'alter database Columnstore_Play 
		add file 
		(
			NAME = ''f' + cast(@i as varchar(2)) + ''',
			FILENAME = ''C:\Data\f' + cast(@i as varchar(2)) + '.ndf'',
			SIZE = 10MB,
			FILEGROWTH = 10MB
		) to Filegroup [fg'  + cast(@i as varchar(2)) + ']
		GO';

	print @tsql;

	if( @i <> @maxFG )
		set @partitions += ',' + cast((1100000/@maxFG * @i ) as nvarchar(20));

	--if( @i <> @maxFG )
	set @filegroups += ', fg' + cast((@i ) as nvarchar(20));

	set @i += 1;
end

print 'create partition function pfIntPart (int)
AS RANGE RIGHT FOR VALUES ( ' + stuff(@partitions,1,1,'') + ' );
GO
'

print 'create partition scheme ColumstorePartitioning 
		AS PARTITION pfIntPart
		TO (  ' + stuff(@filegroups,1,1,'') + ' );'

-------------------------------------------------------------------
---- Create the Partitioning scheme
--create partition function pfIntPart (int)
--AS RANGE RIGHT FOR VALUES (
--	--110000, 
--	220000, 
--	--330000, 
--	440000, 
--	--550000, 
--	660000, 
--	770000, 
--	880000
--	,1099999
--	);

----drop partition function pfIntPart

---- Define the partitioning function for it, which will be mapping data to each of the corresponding filegroups
--create partition scheme ColumstorePartitioning 
--	AS PARTITION pfIntPart
--TO ( 
--	fg1, fg2, fg3, fg4, fg5 )--, fg6, fg6, fg7, fg8, fg9, fg10 );

