select * from sys.column_store_dictionaries

select * from sys.column_store_row_groups

select * from sys.column_store_segments