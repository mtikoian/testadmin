/* 
 * Queries for testing SQL Server 2014 CTP improvements
 * by Niko Neugebauer (http://www.nikoport.com)
 */

-- Returns tables suggested for using Clustered Columnstore for the Datawarehouse environments
select object_schema_name( t.object_id ) as 'Schema'
	, object_name (t.object_id) as 'Table'
	, sum(p.rows) as 'Row Count'
	, (select count(*) from sys.columns as col
		where t.object_id = col.object_id ) as 'Cols Count'
	, (select sum(col.max_length) 
			from sys.columns as col
			join sys.types as tp
			on col.system_type_id = tp.system_type_id
			where t.object_id = col.object_id 
	  ) as 'Cols Max Length'
	, (select count(*) 
			from sys.columns as col
			join sys.types as tp
			on col.system_type_id = tp.system_type_id
			where t.object_id = col.object_id and 
				 (UPPER(tp.name) in ('TEXT','NTEXT','TIMESTAMP','HIERARCHYID','SQL_VARIANT','XML','GEOGRAPHY','GEOMETRY') OR
				  (UPPER(tp.name) in ('VARCHAR','NVARCHAR') and (col.max_length = 8000 or col.max_length = -1)) 
				 )
	   ) as 'Unsupported Columns'
	, (select count(*)
			from sys.objects
			where type = 'PK' AND parent_object_id = t.object_id ) as 'Primary Key'
	, (select count(*)
			from sys.objects
			where type = 'F' AND parent_object_id = t.object_id ) as 'Foreign Keys'
	, (select count(*)
			from sys.objects
			where type in ('UQ','D','C') AND parent_object_id = t.object_id ) as 'Constraints'
	, (select count(*)
			from sys.objects
			where type in ('TA','TR') AND parent_object_id = t.object_id ) as 'Triggers'
	, t.is_tracked_by_cdc as 'CDC'
	, t.is_memory_optimized as 'Hekaton'
	, t.is_replicated as 'Replication'
	, coalesce(t.filestream_data_space_id,0,1) as 'FileStream'
	, t.is_filetable as 'FileTable'
	from sys.tables t
	inner join sys.partitions as p 
		ON t.object_id = p.object_id
	where p.data_compression in (0,1,2) -- None, Row, Page
	group by t.object_id, t.is_tracked_by_cdc,  t.is_memory_optimized, t.is_filetable, t.is_replicated, t.filestream_data_space_id
	having sum(p.rows) > 1000000
	order by sum(p.rows) desc