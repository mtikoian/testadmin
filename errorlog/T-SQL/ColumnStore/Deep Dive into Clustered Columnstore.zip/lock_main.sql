begin tran
	insert into dbo.CCTest
		( id, name, lastname )
		values
		( 1, 'SomeName_', 'SomeLastName_' );

-- rollback;


declare @i as int;
declare @max as int;
select @max = isnull(max(id),0) from dbo.CCTest;
set @i = 1;

begin tran
while @i <= 1048576
begin
	insert into dbo.CCTest
		( id, name, lastname )
		values
		( @max + @i, 'SomeName_', 'SomeLastName_' );

	set @i = @i + 1;
end;
commit;

-- Update
begin tran

update dbo.CCTest with(ROWLOCK)
	set name = 'Updated Name'
	where id = 150;

-- Rollback


-- What is this ? ;)
select top 5 %%lockres%%
from    dbo.CCTest