Due to the size, import data package for BCP is available for download from http://aboutsqlserver.com/presentations
