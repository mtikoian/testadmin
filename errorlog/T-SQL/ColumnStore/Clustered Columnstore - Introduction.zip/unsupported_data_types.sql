/* 
 * Queries for testing SQL Server 2014 CTP improvements
 * by Niko Neugebauer (http://www.nikoport.com)
 */


create table dbo.UnsupportedDatatypesTable(
	c1 text, 
	c2 timestamp,
	c3 hierarchyid,
	c4 sql_variant,
	c5 xml,
	c6 varchar(max),
	c7 nvarchar(max),
	c8 geography,
	c9 geometry
);	
GO

-- Lets create a Clustered Columnstore Index
Create Clustered Columnstore Index CC_UnsupportedDatatypesTable on dbo.UnsupportedDatatypesTable;
GO

-- Drop this test table
drop table dbo.UnsupportedDatatypesTable


-- Sparse
create table dbo.SparseTable(
	c1 int sparse NULL, 
	c2 varchar(10) sparse NULL,
	c3 char(4) sparse NULL
);
GO

Create Clustered Columnstore Index CC_SparseTable on dbo.SparseTable;
GO

drop table dbo.SparseTable