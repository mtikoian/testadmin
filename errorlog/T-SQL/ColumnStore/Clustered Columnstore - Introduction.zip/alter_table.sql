/* 
 * Queries for testing SQL Server 2014 CTP improvements
 * by Niko Neugebauer (http://www.nikoport.com)
 */

create table dbo.MaxDataTable(
	c1 bigint,
	c2 numeric (37,3),
	c3 bit,
	c4 smallint,
	c5 decimal (18,3),
	c6 smallmoney,
	c7 int,
	c8 tinyint,
	c9 money,
	c10 float(24),
	c11 real,
	c12 date,
	c13 datetimeoffset,
	c14 datetime2 (7),
	c15 smalldatetime,
	c16 datetime,
	c17 time (7),
	c18 char(100),
	c19 varchar(100),
	c20 nchar(100),
	c21 nvarchar(100),
	c22 binary(8),
	c23 varbinary(8),
	c24 uniqueidentifier,
);



-- Lets try out to create a new Clustered Columnstore Index:
Create Clustered Columnstore Index CC_MaxDataTable on dbo.MaxDataTable;

-- Insert some Null's by default into this table:
insert into dbo.MaxDataTable
	default values;

-- Select content of our table
select c1, c2, c3, c4, c5, c6, c7, c8, c9, c10, c11, c12, c13, c14, c15, c16, c17, c18, c19, c20, c21, c22, c23, c24
	from dbo.MaxDataTable; 


-- *****************************************************************

-- Let us add one more column
alter table dbo.MaxDataTable
	add c25 int NULL;
GO

update dbo.MaxDataTable
	set c25 = 23;

-- Can we actually modify it ?
alter table dbo.MaxDataTable
	alter column c25 int NOT NULL;

-- Drop it
alter table dbo.MaxDataTable
	drop column c25;

-- Since data is still in the Delta-store lets try to Rebuild the table to put everything into a Segment:
alter table dbo.MaxDataTable 
        rebuild;
GO