/*
Author:	Phil Helmer
		http://www.philhelmer.com
		phil@philhelmer.com

Please keep this comment with the file.
*/

USE OutputDemo;
GO
BEGIN TRANSACTION;
GO
CREATE TABLE #ProductListPriceChanges (
	ProductID BIGINT NOT NULL,
	ChangeDate DATE NOT NULL,
	ListPriceBefore DECIMAL(10,2) NOT NULL,
	ListPriceAfter DECIMAL(10,2) NOT NULL
);

UPDATE	dbo.Products
SET		ListPrice = ListPrice / 10.0

--For OUTPUT..INTO, the column aliases "AS ..." are optional
OUTPUT	inserted.ProductID,
		GETDATE(),
		deleted.ListPrice AS PrBef,
		inserted.ListPrice AS WontEverSeeThisAlias
		INTO #ProductListPriceChanges (
				ProductID, 
				ChangeDate, 
				ListPriceBefore, 
				ListPriceAfter
		)

--These aliases are used, just like in a SELECT statement
OUTPUT	deleted.ProductID AS PID,		--this column is available even though it wasn't modified
		deleted.ListPrice AS PriceWas,
		inserted.ListPrice AS PriceIsNow

WHERE	ProductID = 2090
;

SELECT * FROM #ProductListPriceChanges;
GO
ROLLBACK TRANSACTION;
GO