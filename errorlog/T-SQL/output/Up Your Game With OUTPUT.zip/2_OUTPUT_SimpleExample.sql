/*
Author:	Phil Helmer
		http://www.philhelmer.com
		phil@philhelmer.com

Please keep this comment with the file.
*/

USE OutputDemo;
GO

--==========================================
-- SCOPE_IDENTITY  (old school)
--==========================================
BEGIN TRANSACTION;

INSERT INTO OutputDemo.dbo.Products (Name, ListPrice, Created)
	VALUES ('New Demo Product', 44.25, GETDATE())
;

DECLARE @id BIGINT = SCOPE_IDENTITY();

SELECT SCOPE_IDENTITY();

SELECT	*
FROM	OutputDemo.dbo.Products
WHERE	ProductID = @id
;

ROLLBACK TRANSACTION;


--==========================================
--	OUTPUT to the caller
--==========================================
BEGIN TRANSACTION;

INSERT INTO OutputDemo.dbo.Products (Name, ListPrice, Created)
	OUTPUT	inserted.ProductID, inserted.Name, inserted.Created
	SELECT	Name, ListPrice, Created
	FROM	(VALUES 
					('New Demo Product', 44.25, GETDATE()), 
					('New Demo Product 2', 88.50, GETDATE())
			) AS NewProducts (Name, ListPrice, Created)
;

ROLLBACK TRANSACTION;


--==========================================
--	OUTPUT INTO a table
--==========================================
BEGIN TRANSACTION;

CREATE TABLE #Audit (
	ProductID BIGINT NOT NULL, 
	ProductName NVARCHAR(60) NOT NULL, 
	ListPrice DECIMAL (10,2) NOT NULL,
	Created DATE NOT NULL,
	CreatedBy NVARCHAR(40) NOT NULL
);

INSERT INTO OutputDemo.dbo.Products (Name, ListPrice, Created)
--In terms of atomicity, the OUTPUT..INTO is part of the INSERT command.
	OUTPUT	inserted.ProductID, 
			inserted.Name, 
			inserted.ListPrice, 
			inserted.Created, 
			'Phil'
				INTO #Audit (
					ProductID, 
					ProductName, 
					ListPrice, 
					Created, 
					CreatedBy
				)
	SELECT	Name, ListPrice, Created
	FROM	(VALUES 
					('New Demo Product', 44.25, GETDATE()), 
					('New Demo Product 2', 88.50, GETDATE())
			) AS NewProducts (Name, ListPrice, Created)
;

SELECT * FROM #Audit;

ROLLBACK TRANSACTION;
