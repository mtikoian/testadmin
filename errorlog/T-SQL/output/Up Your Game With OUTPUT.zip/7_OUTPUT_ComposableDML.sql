/*
Author:	Phil Helmer
		http://www.philhelmer.com
		phil@philhelmer.com

Please keep this comment with the file.
*/

--==============================================
--	Can I only log certain rows?
--==============================================

USE OutputDemo;
GO
BEGIN TRANSACTION;
GO

UPDATE	dbo.Products
SET		ListPrice = ListPrice / 10.0
OUTPUT	GETDATE() AS TimeOfChange,
		'Product - ' + CAST(inserted.ProductID AS NVARCHAR(20)) AS RecordType,
		'ListPrice' AS ValueChanged,
		deleted.ListPrice AS OldValue,
		inserted.ListPrice AS NewValue
			INTO dbo.ChangeLog (
				TimeOfChange,
				RecordType,
				ValueChanged,
				OldValue,
				NewValue
			)
-- Can I apply a WHERE clause for the OUTPUT rows?
--WHERE	deleted.ListPrice > 30000

--That red squiggly line should answer the question.
;

SELECT * FROM dbo.ChangeLog;

ROLLBACK TRANSACTION;
GO


--==============================================
--	You could output into a temp table then 
--	insert into your audit log from there. OR...
--==============================================

USE OutputDemo;
GO
BEGIN TRANSACTION;
GO

INSERT INTO dbo.ChangeLog (
		TimeOfChange,
		RecordType,
		ValueChanged,
		OldValue,
		NewValue
)
SELECT	RowsModified.TimeOfChange,
		RowsModified.RecordType,
		RowsModified.ValueChanged,
		RowsModified.OldValue,
		RowsModified.NewValue
FROM	(
			UPDATE	dbo.Products
			SET		ListPrice = ListPrice / 10.0
--went from OUTPUT..INTO to simply OUTPUT, which serves as the row source for the SELECT
			OUTPUT	GETDATE() AS TimeOfChange,
					'Product - ' + CAST(inserted.ProductID AS NVARCHAR(20)) AS RecordType,
					'ListPrice' AS ValueChanged,
					deleted.ListPrice AS OldValue,
					inserted.ListPrice AS NewValue
		) AS RowsModified

--apply the filter for the rows to be logged
WHERE	RowsModified.OldValue > 30000
;

SELECT * FROM dbo.ChangeLog;

ROLLBACK TRANSACTION;
GO
