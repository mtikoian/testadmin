/*
Author:	Phil Helmer
		http://www.philhelmer.com
		phil@philhelmer.com

Please keep this comment with the file.
*/

USE OutputDemo;
GO
BEGIN TRANSACTION;
GO

SELECT	* 
FROM	dbo.Products 
WHERE	Name LIKE 'Wine%'
--		AND Created < '20060101'
--		AND Discount IS NULL
		AND Discontinued IS NULL
ORDER BY Name
;

CREATE TABLE #NewDiscounts (
	ProductID BIGINT NOT NULL PRIMARY KEY
);


UPDATE	dbo.Products
SET		Discount = 0.3,
		DiscountExpiration = DATEADD(DAY, 7, getdate())
OUTPUT	inserted.ProductID INTO #NewDiscounts (ProductID)
WHERE	Name LIKE 'Wine%'
		AND Created < '20060101'
		AND Discount IS NULL
		AND Discontinued IS NULL
;

INSERT INTO ProductAdvertisements (
			ProductID,
			PublicationID,
			PublicationBegins,
			PublicationEnds,
			Created
			)
	SELECT	p.ProductID,
			62463 AS PublicationID,
			'20120418' AS PublicationBegins,
			'20120429' AS PublicationEnds,
			GETDATE() AS Created
	FROM	dbo.Products AS p
			INNER JOIN #NewDiscounts AS nd
				ON p.ProductID = nd.ProductID
;

INSERT INTO ChangeLog (
			TimeOfChange,
			RecordType,
			ValueChanged,
			OldValue,
			NewValue
			)
	SELECT	GETDATE() AS TimeOfChange,
			'Product - ' + CAST(p.ProductID AS NVARCHAR(20)) AS RecordType,
			'Discount' AS ValueChanged,
			NULL AS OldValue,
			'0.3' AS NewValue
	FROM	dbo.Products AS p
			INNER JOIN #NewDiscounts AS nd
				ON p.ProductID = nd.ProductID
;

SELECT	* 
FROM	dbo.Products 
WHERE	Name LIKE 'Wine%'
--		AND Created < '20060101'
--		AND Discount IS NULL
		AND Discontinued IS NULL
ORDER BY Name
;


SELECT p.* FROM dbo.Products AS p INNER JOIN #NewDiscounts AS nd ON p.ProductID = nd.ProductID;
SELECT * FROM dbo.ProductAdvertisements;
SELECT * FROM dbo.ChangeLog;

GO

ROLLBACK TRANSACTION;
GO