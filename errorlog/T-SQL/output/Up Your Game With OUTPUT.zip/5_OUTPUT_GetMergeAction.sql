/*
Author:	Phil Helmer
		http://www.philhelmer.com
		phil@philhelmer.com

Please keep this comment with the file.
*/

USE OutputDemo;
GO
BEGIN TRANSACTION;
GO

SELECT * FROM dbo.Colors;


MERGE	dbo.Colors AS tar
USING	(
			SELECT	Code, Name
			FROM	(VALUES 
						('YEL','Yellow'), 
						('RD','Maroon'), 
						('GRN','Green')
					) AS ColorsToMerge (Code, Name)
		) AS src (Code, Name)
		ON tar.Code = src.Code
WHEN MATCHED 
	THEN UPDATE SET tar.Name = src.Name
WHEN NOT MATCHED BY TARGET 
	THEN INSERT (Code, Name) VALUES (src.Code, src.Name)
WHEN NOT MATCHED BY SOURCE 
	THEN DELETE
--OUTPUT $action, deleted.Code, deleted.Name, inserted.Code, inserted.Name
;

SELECT * FROM dbo.Colors;

--Note that the output order cannot be controlled from the OUTPUT clause.
--If you require an ordered set, use OUTPUT..INTO and use a SELECT..ORDER BY
--on that target table.
GO
ROLLBACK TRANSACTION;
GO