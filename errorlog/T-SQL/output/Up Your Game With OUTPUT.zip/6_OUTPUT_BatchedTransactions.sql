
USE [OutputDemo]
GO

--Make sure the Log file is as small as possible before running the demo
DBCC SHRINKFILE (N'OutputDemo_log' , 0, TRUNCATEONLY)
GO


--=====================================================
--	Log file before the work is done
--=====================================================

SELECT	[file_id], 
		type_desc, 
		name, 
		physical_name, 
		CAST(size * 8192.0 / 1024.0 AS DECIMAL(8,1)) AS size_KB,
		CAST(growth * 8192.0 / 1024.0 AS DECIMAL(8,1)) AS growth_KB
FROM	OutputDemo.sys.database_files AS df
WHERE	type_desc = 'LOG'
;
GO

SELECT TOP 1 ZIP FROM dbo.CustomerAddresses;

--=====================================================
--	Option 1: All at once, lookout LDF!!!
--=====================================================
BEGIN TRANSACTION;

UPDATE	dbo.CustomerAddresses
SET		ZIP = LEFT(ZIP, 5) + '-0003'
;

COMMIT TRANSACTION;

--=====================================================
--	Option 2: Batched DML, stable LDF, less blocking
--=====================================================

--IF OBJECT_ID('tempdb..#AddrProcessed') IS NOT NULL
--BEGIN;
--	DROP TABLE #AddrProcessed;
--END;
--GO

--CREATE TABLE #AddrProcessed (
--	CustomerID BIGINT NOT NULL PRIMARY KEY
--);

--DECLARE @RowsChanged INT = 1;

--WHILE @RowsChanged > 0
--BEGIN;
--	BEGIN TRANSACTION;
	
--	UPDATE	TOP (100) ca
--	SET		ZIP = LEFT(ZIP, 5) + '-4444'

--	OUTPUT	inserted.CustomerID INTO #AddrProcessed (CustomerID)
----	OUTPUT	ap.CustomerID	--	Notice that this is available, 
--							--	even though it's not in the modified table
--	FROM	dbo.CustomerAddresses AS ca
--			LEFT JOIN #AddrProcessed AS ap
--				ON ca.CustomerID = ap.CustomerID
--	WHERE	ap.CustomerID IS NULL
--	;
	
--	SET @RowsChanged = @@ROWCOUNT;
	
--	COMMIT TRANSACTION;
--END;


--=====================================================
--	Log file after the work is done
--=====================================================

SELECT TOP 1 ZIP FROM dbo.CustomerAddresses;

SELECT	[file_id], 
		type_desc, 
		name, 
		physical_name, 
		CAST(size * 8192.0 / 1024.0 AS DECIMAL(8,1)) AS size_KB,
		CAST(growth * 8192.0 / 1024.0 AS DECIMAL(8,1)) AS growth_KB
FROM	OutputDemo.sys.database_files AS df
WHERE	type_desc = 'LOG'
;

GO
