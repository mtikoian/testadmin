SELECT
	*,
	RowNum = ROW_NUMBER() OVER()
FROM Ratings