SELECT
	new_key = ROW_NUMBER() OVER
	(
		ORDER BY transaction_date
	),
	*
FROM date_range_test;