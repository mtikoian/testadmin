WITH source_data AS
(	
	SELECT
		row_num = ROW_NUMBER() OVER
		(
			PARTITION BY
				transaction_date
			ORDER BY 
				(SELECT NULL)
		),
		*
	FROM date_range_test
)

SELECT 
	StartDate = transaction_date,
	EndDate = LEAD(transaction_date) OVER
	(
		ORDER BY
			transaction_date
	)
FROM source_data 
WHERE 
	row_num = 1