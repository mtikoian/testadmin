SELECT
	*,
	PreviousRating = SUM(Rating) OVER
	(
		PARTITION BY
			Category
		ORDER BY
			Rating
		ROWS
			BETWEEN 1 PRECEDING AND 1 PRECEDING
	)
FROM Ratings