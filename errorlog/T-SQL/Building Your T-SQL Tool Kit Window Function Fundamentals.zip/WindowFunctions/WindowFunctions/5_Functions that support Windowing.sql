/*

RANKING FUNCTIONS
-----------------------
rank()			| SQL 2005 | PARTITIONING optional | ORDER BY REQUIRED | Framing not supported
ntile()			| SQL 2005 | PARTITIONING optional | ORDER BY REQUIRED | Framing not supported
dense_rank()	| SQL 2005 | PARTITIONING optional | ORDER BY REQUIRED | Framing not supported
row_number()	| SQL 2005 | PARTITIONING optional | ORDER BY REQUIRED | Framing not supported


AGGREGATE FUNCTIONS
-----------------------
AVG(expression)				| SQL 2005 | PARTITIONING optional | ORDER BY optional | Framing optional As of SQL2012
MIN(expression)				| SQL 2005 | PARTITIONING optional | ORDER BY optional | Framing optional As of SQL2012
SUM(expression)				| SQL 2005 | PARTITIONING optional | ORDER BY optional | Framing optional As of SQL2012
COUNT(expression)			| SQL 2005 | PARTITIONING optional | ORDER BY optional | Framing optional As of SQL2012
STDEV(expression)			| SQL 2005 | PARTITIONING optional | ORDER BY optional | Framing optional As of SQL2012
COUNT_BIG(expression)		| SQL 2005 | PARTITIONING optional | ORDER BY optional | Framing optional As of SQL2012 
STDEVP(expression)			| SQL 2005 | PARTITIONING optional | ORDER BY optional | Framing optional As of SQL2012
VAR(expression)				| SQL 2005 | PARTITIONING optional | ORDER BY optional | Framing optional As of SQL2012
VARP(expression)			| SQL 2005 | PARTITIONING optional | ORDER BY optional | Framing optional As of SQL2012
MAX	(expression)			| SQL 2005 | PARTITIONING optional | ORDER BY optional | Framing optional As of SQL2012


OFFSET FUNCTIONS
-----------------------
LAG(expression)			| SQL 2012 | PARTITIONING optional | ORDER BY REQUIRED | Frame defaults to BETWEEN 1 PRECEDING AND 1 PRECEDING
LEAD(expression)		| SQL 2012 | PARTITIONING optional | ORDER BY REQUIRED | Frame defaults to BETWEEN 1 FOLLOWING AND 1 FOLLOWING
FIRST_VALUE(expression) | SQL 2012 | PARTITIONING optional | ORDER BY REQUIRED | Framing optional
LAST_VALUE(expression)	| SQL 2012 | PARTITIONING optional | ORDER BY REQUIRED | Framing optional


DISTRIBUTION FUNCTIONS
-----------------------

	Rank Distribution
	----------------------
	PERCENT_RANK()	| SQL 2012 | PARTITIONING optional | ORDER BY Required | Framing not supported
	CUME_DIST()		| SQL 2012 | PARTITIONING optional | ORDER BY Required | Framing not supported

	Inverse Distribution
	----------------------
	PERCENTILE_CONT(numeric_literal) | SQL 2012 | PARTITIONING optional | ORDER BY Required | Framing not supported 
	PERCENTILE_DISC(numeric_literal) | SQL 2012 | PARTITIONING optional | ORDER BY Required | Framing not supported 

*/