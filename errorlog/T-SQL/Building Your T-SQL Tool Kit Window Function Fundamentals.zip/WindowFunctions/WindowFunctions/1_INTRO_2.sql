


SELECT
	RecipeName,
	_Count = COUNT(*) 
FROM Ratings
GROUP BY
	RecipeName;



SELECT
	*,
	_Count = COUNT(*) OVER
	(
		PARTITION BY
			RecipeName
	)
FROM Ratings;
