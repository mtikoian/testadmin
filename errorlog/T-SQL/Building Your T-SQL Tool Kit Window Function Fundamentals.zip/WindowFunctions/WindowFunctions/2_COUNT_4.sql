SELECT
	*,
	_Count = COUNT(Rating) OVER
	(
		PARTITION BY
			Category
		ORDER BY
			Rating
		ROWS
			UNBOUNDED PRECEDING
	)
FROM Ratings