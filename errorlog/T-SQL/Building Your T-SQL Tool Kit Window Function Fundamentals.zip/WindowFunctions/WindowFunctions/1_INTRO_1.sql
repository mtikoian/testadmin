USE WindowFunctions;
GO

SELECT
	*
FROM Ratings;
