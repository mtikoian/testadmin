SELECT
	*,
	_Count = COUNT(Rating) OVER
	(
		PARTITION BY
			Category
		ORDER BY
			Rating
		ROWS
			1 PRECEDING
	)
FROM Ratings