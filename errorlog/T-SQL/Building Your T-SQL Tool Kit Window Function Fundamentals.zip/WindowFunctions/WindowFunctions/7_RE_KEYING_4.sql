SELECT DISTINCT	
	new_key,
	transaction_date
FROM
(
	SELECT
		new_key = DENSE_RANK() OVER
		(
			ORDER BY transaction_date
		),
		*
	FROM date_range_test
) AS source_data;