SELECT
	row_num = ROW_NUMBER() OVER
	(
		PARTITION BY
			transaction_date
		ORDER BY 
			(SELECT NULL)
	),
	*
FROM date_range_test
