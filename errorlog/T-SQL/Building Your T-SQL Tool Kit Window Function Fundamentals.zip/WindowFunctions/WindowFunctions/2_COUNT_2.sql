SELECT
	*,
	_Count = COUNT(Rating) OVER
	(
		PARTITION BY
			Category
	)
FROM Ratings