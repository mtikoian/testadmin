SELECT
	*,
	NextRating = SUM(Rating) OVER
	(
		PARTITION BY
			Category
		ORDER BY
			Rating
		ROWS
			BETWEEN 1 FOLLOWING AND 1 FOLLOWING
	)
FROM Ratings