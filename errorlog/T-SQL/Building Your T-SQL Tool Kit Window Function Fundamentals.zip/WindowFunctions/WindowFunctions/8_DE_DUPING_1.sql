SELECT
	row_num = ROW_NUMBER() OVER
	(
		ORDER BY 
			(SELECT NULL)
	),
	*
FROM date_range_test
