/*

-------------------------------------------------------------------------------
	OVER CLAUSE SYNTAX
-------------------------------------------------------------------------------

OVER 
( 

	PARTITION BY (defines working set based on the SELECT output)
		<column name>

	ORDER BY (Gives meaning to frame position OR calculation)
		<column name>

	RANGE or ROW (Frame Definition)			
		<extent boundary>
			BETWEEN <lower boundary> AND <upper boundary>
) 

-------------------------------------------------------------------------------
NOTES:

	If PARTITION columns are not specified, then the entire set is used.

	Frame Definition applies only to OFFSET and AGGREGATE functions in SQL 2012

	RANGE UNBOUNDED PRECEDING AND CURRENT ROW is the default frame definition if ORDER BY is specified 
	but no frame definition is indicated. RANGE calculates by value rather than position, so you can end up
	with unexpected results if the PARTITION contains duplicate ordering values.

	Boundary definitions include:
		CURRENT ROW
		UNBOUNDED PRECEDING
		UNBOUNDED FOLLOWING
		x PRECEDING 
		x FOLLOWING

	Boundary definitons can use "SHORT SYNTAX" where you specify the lower boundary only.
		Only works with PRECEDING
		BETWEEN is assumed
		UPPER BOUNDARY defaults to CURRENT ROW

		UNBOUNDED PRECEDING = BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
		5 PRECEDING = BETWEEN 5 PRECEDING AND CURRENT ROW


*/