SELECT
	*,
	RowNum = ROW_NUMBER() OVER
	(
		PARTITION BY
			Rating
		ORDER BY
			Rating 
	)
FROM Ratings