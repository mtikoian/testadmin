SELECT
	*,
	_Sum = SUM(Rating) OVER
	(
		PARTITION BY
			Category
		ORDER BY
			Rating
		ROWS
			UNBOUNDED PRECEDING
	)
FROM Ratings