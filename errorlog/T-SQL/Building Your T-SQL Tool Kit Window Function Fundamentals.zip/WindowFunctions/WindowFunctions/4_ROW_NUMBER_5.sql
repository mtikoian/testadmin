SELECT
	*,
	RowNum = ROW_NUMBER() OVER
	(
		PARTITION BY
			Rating
		ORDER BY
			RatingDate DESC
	)
FROM Ratings