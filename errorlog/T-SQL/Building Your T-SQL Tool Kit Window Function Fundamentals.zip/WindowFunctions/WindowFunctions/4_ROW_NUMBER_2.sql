SELECT
	*,
	RowNum = ROW_NUMBER() OVER
	(
		ORDER BY
			Rating
	)
FROM Ratings