SELECT
	*,
	_Count = COUNT(Rating) OVER()
FROM Ratings