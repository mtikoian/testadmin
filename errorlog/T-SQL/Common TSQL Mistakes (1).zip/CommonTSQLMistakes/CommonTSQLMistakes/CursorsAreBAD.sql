/*
show the below using profiler, with TSQL:Statement Complete on
each fetch (whether it be server cursor like this, ADO or ADO.NET)
is a MINIMUM of 8K reads, often 10-50 or more depending on size of
return from cursor SELECT statement
*/

use [20060330]

declare @type varchar(10), @empamt money, @fedtotal money, @statetotal money

set @fedtotal = 0
set @statetotal = 0

DECLARE workCursor CURSOR SCROLL DYNAMIC FOR
--DECLARE workCursor CURSOR FAST_FORWARD FOR  --TRY TO ALWAYS USE FF!
SELECT type, employeeamount
  FROM payrolltaxes
 WHERE paydate BETWEEN '6/1/2006' AND '8/31/2006'
   AND employeeid = '00000101'
   AND type in ('federal', 'state')

OPEN workCursor

FETCH NEXT FROM workCursor INTO @type, @empamt

WHILE (@@FETCH_STATUS <> -1)
BEGIN
   IF (@@FETCH_STATUS <> -2)
   BEGIN
      if @type = 'federal'
      begin
         set @fedtotal = @fedtotal + @empamt
      end

      if @type = 'state'
      begin
         set @statetotal = @statetotal + @empamt
      end

   END

   FETCH NEXT FROM workCursor INTO @type, @empamt
END

CLOSE workCursor
DEALLOCATE workCursor

select @fedtotal as FedTotal, @statetotal as StateTotal

174 total reads (111 with FF cursor).  and client was doing this 58 times (each employee) for one report!!

select 174 * 58 = > 10K database reads, plus the network traffic and client side processing effort!
they actually had one database with over 1200 employees, and were doing > 1MILLION reads!

--set based output

SELECT SUM(CASE WHEN Type = 'Federal' THEN EmployeeAmount ELSE 0 END) AS FedTotal,
       SUM(CASE WHEN Type = 'state' THEN EmployeeAmount ELSE 0 END) AS SUTATotal
  FROM dbo.PayrollTaxes WITH (NOLOCK)
 where paydate between '6/1/2006' and '8/31/2006'
   and employeeid = '00000101'
   and type in ('federal', 'state')

this was 61 total reads, but just ONE employee!


--lets try to combine output

SELECT EmployeeID,
       SUM(CASE WHEN Type = 'Federal' THEN EmployeeAmount ELSE 0 END) AS FedTotal,
       SUM(CASE WHEN Type = 'state' THEN EmployeeAmount ELSE 0 END) AS SUTATotal
  FROM dbo.PayrollTaxes WITH (NOLOCK)
 where paydate between '6/1/2006' and '8/31/2006'
--   and employeeid = '00000101'  want to do ALL of them
   and type in ('federal', 'state')
 GROUP BY EmployeeID

this uses only 79 reads!!  Down from over 10000!
would be MUCH faster if had covering index too