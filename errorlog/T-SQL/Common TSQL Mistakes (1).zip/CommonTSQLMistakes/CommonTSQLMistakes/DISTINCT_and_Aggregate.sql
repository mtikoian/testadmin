SET STATISTICS IO ON
go
use adventureworksdw2008R2
go
--
-- Use a distinct aggregate and a normal aggregate in the same select list
-- over some complex (one or more joins) derived table
--
with FISinFRS as (
 select * from factinternetsales FIS
  where ProductKey in
   (select ProductKey from FactResellerSales)
 
)
select
      count(*)                            as CountStar,
      count(distinct ProductKey)          as CountProductKeys
from FISinFRS
go

CountStar   CountProductKeys
----------- ----------------
39314       142

(1 row(s) affected)

Table 'Worktable'. Scan count 2, logical reads 79346, physical reads 0, read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.
Table 'FactInternetSales'. Scan count 1, logical reads 200, physical reads 0, read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.
Table 'FactResellerSales'. Scan count 38, logical reads 1615, physical reads 0, read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.
 
--
-- Now use partial aggregations in a new derived table
-- This is equivalent, but SQL Server 2008 does not do this transformation
-- for you
--
with FISinFRS as (
 select * from factinternetsales FIS
  where ProductKey in
   (select ProductKey from FactResellerSales)
 
)
, PartialSums as (
  select
      count(*)                            as CountStarPartialCount
  from FISinFRS
  group by ProductKey
)
select
      sum(CountStarPartialCount)          as CountStar,
      sum(1)                              as CountProductKeys
from PartialSums

CountStar   CountProductKeys
----------- ----------------
39314       142

(1 row(s) affected)

Table 'Worktable'. Scan count 0, logical reads 0, physical reads 0, read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.
Table 'FactResellerSales'. Scan count 38, logical reads 1615, physical reads 0, read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.
Table 'FactInternetSales'. Scan count 1, logical reads 200, physical reads 0, read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.
