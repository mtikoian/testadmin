USE AdventureWorks;
GO

IF EXISTS (SELECT 1 FROM sys.triggers AS T WHERE T.name = 'deny_create_user') 
	BEGIN
		DROP TRIGGER deny_create_user ON DATABASE;
	END
Go
	
CREATE TRIGGER deny_create_user
ON DATABASE 
FOR CREATE_USER
AS 
    IF SYSTEM_USER <> 'sa'
		BEGIN 
			SELECT 
				EVENTDATA().value('(/EVENT_INSTANCE/LoginName)[1]', 'nvarchar(128)') AS login_used,
				EVENTDATA().value('(/EVENT_INSTANCE/TSQLCommand/CommandText)[1]','nvarchar(max)') AS statement_executed;
		   
		   RAISERROR ('Only sa can create New Users in this database.', 16, 1) ;
		   
		   ROLLBACK;
	   END
;
GO

/* Test the trigger. */
CREATE USER test_user WITHOUT LOGIN;
GO

/* Clean up Trigger */
IF EXISTS (SELECT 1 FROM sys.triggers AS T WHERE T.name = 'deny_create_user') 
	BEGIN
		DROP TRIGGER deny_create_user ON DATABASE;
	END
Go

/* Clean up user */
IF EXISTS(SELECT 1 FROM sys.database_principals AS DP WHERE DP.name = N'test_user')
	BEGIN
		DROP USER test_user;
	END