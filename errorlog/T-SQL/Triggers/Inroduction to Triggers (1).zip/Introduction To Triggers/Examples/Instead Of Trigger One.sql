USE AdventureWorks ;
Go

IF EXISTS ( SELECT
                1
            FROM
                sys.triggers AS T
            WHERE
                T.name = N'Department_Instead_Of_Ins' ) 
    BEGIN
        DROP TRIGGER HumanResources.Department_Instead_Of_Ins ;
    END

Go

CREATE TRIGGER HumanResources.Department_Instead_Of_Ins
ON  HumanResources.Department
INSTEAD OF INSERT
AS 
BEGIN;
    SET NOCOUNT ON;
    
    IF Exists(Select Count(I.DepartmentId) 
              From inserted I Join 
                    HumanResources.Department D On
                        I.GroupName = D.GroupName 
              Group By I.GroupName Having Count(I.DepartmentId) >= 5)
         BEGIN;
			RAISERROR('You cannot have more than 5 departments in a group', 16 ,1);
          END;
END;
     

Go

/* 
How many rows in each group 
*/
SELECT
	COUNT(*) AS before_insert,
	D.GroupName
FROM
	HumanResources.Department AS D
WHERE 
	D.GroupName  IN ('Executive General and Administration', 'Inventory Management')
GROUP BY
	D.GroupName;

Go

/*
Insert into a 6th department into the Executive General and Administration Group
Which should fail
*/
INSERT INTO
    HumanResources.Department
    (
     Name,
     GroupName,
     ModifiedDate 
    )
VALUES
    (
     '#6', -- Name - Name
     'Executive General and Administration', -- GroupName - Name
     '2010-07-30 00:20:45'  -- ModifiedDate - datetime
    );

GO

/*
Insert into a 3rd department into the Inventory Management Group
Which should work
*/
INSERT INTO
    HumanResources.Department
    (
     Name,
     GroupName,
     ModifiedDate 
    )
VALUES
    (
     '#3', -- Name - Name
     'Inventory Management', -- GroupName - Name
     '2010-07-30 00:20:45'  -- ModifiedDate - datetime
    );
 
 Go
/* 
How many rows in the department table
*/
SELECT
	COUNT(*) AS after_insert,
	D.GroupName
FROM
	HumanResources.Department AS D
WHERE 
	D.GroupName  IN ('Executive General and Administration', 'Inventory Management')
GROUP BY
	D.GroupName;
	
GO

/* Clean up the rows */
DELETE
FROM
	HumanResources.Department
WHERE
	HumanResources.Department.Name Like '#%'	
	
IF EXISTS(SELECT 1 FROM sys.triggers AS T WHERE T.name = N'Department_Instead_Of_Ins')
	BEGIN
		DROP TRIGGER HumanResources.Department_Instead_Of_Ins; 
	END

Go

