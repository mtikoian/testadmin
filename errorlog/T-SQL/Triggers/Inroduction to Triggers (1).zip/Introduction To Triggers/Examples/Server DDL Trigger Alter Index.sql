USE master;

GO

IF EXISTS (SELECT 1 FROM sys.server_triggers AS ST WHERE ST.name = 'alter_index_denied')
	BEGIN
		DROP TRIGGER alter_index_denied ON ALL SERVER;
	END

Go 

CREATE TRIGGER alter_index_denied ON ALL SERVER
FOR ALTER_INDEX
AS

DECLARE @day_of_week INT = DATEPART(WeekDay, SYSDATETIME()),
		@time TIME(0) = CONVERT(TIME(0), SYSDATETIME()),
		@TSQL NVARCHAR(MAX);
		
SET @TSQL = EVENTDATA().value('(/EVENT_INSTANCE/TSQLCommand/CommandText)[1]','nvarchar(max)');
		
			
/* For US English as the language this will keep ALTER INDEX REBUILD from 
running weekdays from 8 am to 6 pm */
IF (@day_of_week BETWEEN 2 AND 6) AND @time BETWEEN CONVERT(TIME(0), '06:00:00') AND CONVERT(TIME(0), '18:00:00') 
	BEGIN
		IF @TSQL LIKE '%REBUILD%'
			BEGIN
				RAISERROR('Indexes can only be rebuilt on weekends or after business hours.', 16, 1);
				
				SELECT 
					EVENTDATA().value('(/EVENT_INSTANCE/LoginName)[1]', 'nvarchar(128)') AS login_used,
					@TSQL AS statement_executed;
					
				ROLLBACK;	
			END
		ELSE
			BEGIN
				PRINT 'Reorg Index Allowed';
				
				SELECT 
					EVENTDATA().value('(/EVENT_INSTANCE/LoginName)[1]', 'nvarchar(128)') AS login_used,
					@TSQL AS statement_executed;
			END
	END
	
	PRINT 'Index Maintenance Allowed' 
	
	SELECT 
		EVENTDATA().value('(/EVENT_INSTANCE/LoginName)[1]', 'nvarchar(128)') AS login_used,
		@TSQL AS statement_executed;
			

GO

USE AdventureWorks;
Go

ALTER INDEX AK_AddressType_Name ON  Person.AddressType REORGANIZE;
GO

ALTER INDEX AK_AddressType_Name ON Person.AddressType REBUILD;

USE master;
GO

IF EXISTS (SELECT 1 FROM sys.server_triggers AS ST WHERE ST.name = 'alter_index_denied')
	BEGIN
		DROP TRIGGER alter_index_denied ON ALL SERVER;
	END

Go 