USE AdventureWorks;
GO

/* Clean up the log table */
IF EXISTS(SELECT 1 FROM sys.tables AS T WHERE T.name = 'ContactLog' AND T.schema_id = SCHEMA_ID(N'Person'))
	BEGIN
		DROP TABLE Person.ContactLog;
	END

Go

/* Create the log table */
CREATE TABLE Person.ContactLog
	(
	ContactId INT,
	ACTION CHAR(6),
	ModifiedDate DATETIME CONSTRAINT DF_ContactLog_ModifiedDate DEFAULT SYSDATETIME(), 
	 CONSTRAINT CK_ContactLog_Action CHECK (ACTION IN ('Update', 'Delete'))
	);
	
Go
	
/* Delete the trigger if it exists */	
IF EXISTS(SELECT * FROM sys.triggers AS T WHERE T.name = N'Contact_Update')
	BEGIN
		DROP TRIGGER Person.Contact_Update;
	END

GO

/* Create the trigger for update */
Create Trigger Person.Contact_Update On Person.Contact
    AFTER Update
AS
    Declare @ContactId INT ;

    Select
        @ContactId = ContactId
    From
        INSERTED;
        
    IF @ContactID > 10 
        BEGIN
            Insert Into
                Person.ContactLog (ContactID, Action)
            Values
                (@ContactID, 'UPDATE');
        END
        
Go

/* update a row */
UPDATE Person.Contact
	SET MiddleName = 'Test1'
WHERE
	Person.Contact.ContactID = 12;

Go

/* Show the logged row */	
SELECT * FROM Person.ContactLog;

Go

/* Do a multi-row update */
UPDATE Person.Contact
	SET MiddleName = 'Test2'
WHERE
	Person.Contact.ContactID BETWEEN 12 AND 17;

Go

/* check the log table */
SELECT * FROM Person.ContactLog;

Go
	
/* check the actual rows updated */	
SELECT C.ContactID, C.MiddleName FROM Person.Contact AS C WHERE C.ContactID BETWEEN 12 AND 17

Go

/* clear the log table */
TRUNCATE TABLE Person.ContactLog;

GO

/* A different implementation of the trigger */
ALTER Trigger Person.Contact_Update On Person.Contact
    AFTER Update
AS
    IF Exists ( Select
                    *
                From
                    inserted
                Where
                    ContactId > 10 ) 
        BEGIN
            Insert Into
                Person.ContactLog (ContactID, Action)
                Select
                    ContactID, 'Update'
                From
                    inserted
                Where
                    ContactId > 10
        END

Go

/* update a row */
UPDATE Person.Contact
	SET MiddleName = 'Test3'
WHERE
	Person.Contact.ContactID = 12;        

Go	

/* Check the log table */
SELECT * FROM Person.ContactLog;

Go

/* do a multi-row update */
UPDATE Person.Contact
	SET MiddleName = 'Test4'
WHERE
	Person.Contact.ContactID BETWEEN 12 AND 17;

Go

/* Check the log table */
SELECT * FROM Person.ContactLog;

Go
	
/* Check the rows we tried to update */	
SELECT C.ContactID, C.MiddleName FROM Person.Contact AS C WHERE C.ContactID BETWEEN 12 AND 17

Go

/* Clear the log table */
TRUNCATE TABLE Person.ContactLog;

GO

/* Trigger with error to demonstrate rollback of original statement */
ALTER Trigger Person.Contact_Update On Person.Contact
    AFTER Update
AS
    IF Exists ( Select
                    *
                From
                    inserted
                Where
                    ContactId > 10 ) 
        BEGIN
            Insert Into
                Person.ContactLog (ContactID, Action)
                Select
                    ContactID, 'Update'
                From
                    insertd
                Where
                    ContactId > 10
        END
Go	

/* multi-row update which should fail */
UPDATE Person.Contact
	SET MiddleName = 'Test5'
WHERE
	Person.Contact.ContactID BETWEEN 12 AND 17;

Go

/* Check the log table */
SELECT * FROM Person.ContactLog;

Go
	
/* check the updated rows */	
SELECT C.ContactID, C.MiddleName FROM Person.Contact AS C WHERE C.ContactID BETWEEN 12 AND 17

Go

/* Trigger using UPDATE function */
ALTER Trigger Person.Contact_Update On Person.Contact
    AFTER Update
AS
    IF UPDATE(MiddleName) 
        BEGIN
            Insert Into
                Person.ContactLog (ContactID, Action)
                Select
                    ContactID, 'Update'
                From
                    inserted
                Where
                    ContactId > 10
        END
Go	

/* update middlename but don't actually change it */
UPDATE Person.Contact
	SET MiddleName = Person.Contact.MiddleName
WHERE
	Person.Contact.ContactID BETWEEN 12 AND 17;

Go

/* Check the log table */
SELECT * FROM Person.ContactLog;

Go
	
/* check the updated rows */	
SELECT C.ContactID, C.MiddleName FROM Person.Contact AS C WHERE C.ContactID BETWEEN 12 AND 17

Go

/* Clean Up */
IF EXISTS(SELECT * FROM sys.triggers AS T WHERE T.name = N'Contact_Update')
	BEGIN
		DROP TRIGGER Person.Contact_Update;
	END        
        
GO

IF EXISTS(SELECT 1 FROM sys.tables AS T WHERE T.name = 'ContactLog' AND T.schema_id = SCHEMA_ID(N'Person'))
	BEGIN
		DROP TABLE Person.ContactLog;
	END
	
GO

UPDATE Person.Contact
	SET MiddleName = NULL
WHERE
	Person.Contact.ContactID BETWEEN 12 AND 17;
	
Go	