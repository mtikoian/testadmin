USE master;
GO

IF EXISTS (SELECT 1 FROM sys.server_triggers AS T WHERE T.name = N'ddl_server_trigger')
	BEGIN
		DROP TRIGGER ddl_server_trigger ON ALL SERVER;
	END 
GO
	
CREATE TRIGGER ddl_server_trigger ON 
ALL SERVER FOR Create_Login
AS

BEGIN
	SET NOCOUNT ON;

	IF SYSTEM_USER <> 'sa' 
		BEGIN
			RAISERROR('Only sa can create logins', 16, 1);
			
			SELECT 
				EVENTDATA().value('(/EVENT_INSTANCE/LoginName)[1]', 'nvarchar(128)') AS login_used,
				EVENTDATA().value('(/EVENT_INSTANCE/TSQLCommand/CommandText)[1]', 'nvarchar(max)') AS statement_executed;
			ROLLBACK;
			
		END; 
	
	RETURN;
END

GO

CREATE LOGIN TestLogin WITH PASSWORD = 'test_1ogin';

Go
IF EXISTS (SELECT 1 FROM sys.server_triggers AS ST WHERE ST.name = N'ddl_server_trigger')
	BEGIN	
		DROP TRIGGER ddl_server_trigger ON ALL SERVER;
	END 

GO

IF EXISTS (SELECT 1 FROM sys.server_principals AS SP WHERE SP.name = 'testlogin')
	BEGIN
		DROP LOGIN testlogin;
	END