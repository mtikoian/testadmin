------------------------------------------------------------------------
-- Event:        SQL Saturday #264 - Ancona
-- Session:      Trigger: Utili o Dannosi?
-- Demo:         Disabilitare un Trigger...
-- Author:       Sergio Govoni
-- Notes:        -
------------------------------------------------------------------------

USE [AdventureWorks2012];
GO



-- Richiesta:

-- Mi chiedono di implementare un trigger sulla tabella Sales.SalesOrderHeader
-- per INSERT e UPDATE

-- Scopro che su tale tabella ci sono gi� altri trigger...


-- Elenco trigger
EXEC sp_helptrigger 'Sales.SalesOrderHeader';
GO











-- Non ho il tempo per studiare il codice degli altri trigger :(



-- Idea :)

-- Implemento un nuovo trigger che per prima cosa disabilita tutti
-- gli altri trigger, esegue le azioni che mi hanno chiesto e poi li
-- ri-abilita

-- In questo modo non mi dovr� preoccupare di collisioni,
-- gli atri trigger sono disabilitati!










------------------------------------------------------------------------
-- Disabilitare un Trigger all'interno di un altro
------------------------------------------------------------------------

IF OBJECT_ID('Sales.My_Trigger', 'TR') IS NOT NULL
  DROP TRIGGER Sales.My_Trigger;
GO


CREATE TRIGGER Sales.My_Trigger ON Sales.SalesOrderHeader
FOR INSERT, UPDATE
AS BEGIN
  BEGIN TRY

    -- Disabilito tutti i trigger
    ALTER TABLE Sales.SalesOrderHeader DISABLE TRIGGER ALL;

    -- Logica
    -- ...
    -- ...

    -- Abilito tutti i trigger
    ALTER TABLE Sales.SalesOrderHeader ENABLE TRIGGER ALL;

  END TRY

  BEGIN CATCH

    IF (@@TRANCOUNT > 0)
      ROLLBACK;
    THROW;

  END CATCH
END;
GO


-- Test
INSERT INTO Sales.SalesOrderHeader
(
  RevisionNumber, OrderDate, DueDate, ShipDate, Status, OnlineOrderFlag
  ,PurchaseOrderNumber, AccountNumber, CustomerID, SalesPersonID
  ,TerritoryID, BillToAddressID, ShipToAddressID, ShipMethodID
  ,CreditCardID, CreditCardApprovalCode, CurrencyRateID, SubTotal
  ,TaxAmt, Freight, Comment, rowguid, ModifiedDate
)
VALUES
(
  1, GETDATE(), GETDATE(), GETDATE(), 5, 1, NULL, N'4030-018759'
  ,18759, NULL, 6, 14024, 14024, 1, 10084, N'230370Vi51970', NULL, 155.9700
  ,15.1976, 4.7493, NULL, NEWID()
  ,GETDATE()
);
GO


ALTER TRIGGER Sales.My_Trigger ON Sales.SalesOrderHeader
FOR INSERT, UPDATE
AS BEGIN
  BEGIN TRY

    -- Disabilito i trigger
    --ALTER TABLE Sales.SalesOrderHeader DISABLE TRIGGER ALL;

    DECLARE
      @cmd_disable_trigger VARCHAR(MAX) = ''
      ,@cmd_enable_trigger VARCHAR(MAX) = '';

    SELECT
      -- Costruzione comandi per disabilitare i trigger
      @cmd_disable_trigger = @cmd_disable_trigger +
                             'ALTER TABLE Sales.SalesOrderHeader ' +
                             'DISABLE TRIGGER ' + T.name + ';' + CHAR(13) + CHAR(10)

      -- Costruzione comandi per abilitare i trigger
      ,@cmd_enable_trigger = @cmd_enable_trigger +
                             'ALTER TABLE Sales.SalesOrderHeader ' +
                             'ENABLE TRIGGER ' + T.name + ';' + CHAR(13) + CHAR(10)
    FROM
      sys.triggers AS T
    JOIN
      sys.objects AS O ON O.object_id=T.parent_id
    JOIN
      sys.schemas AS S ON S.schema_id=O.schema_id
    WHERE
      (S.name='Sales')
      AND (O.name='SalesOrderHeader')
      AND (T.is_disabled=0) -- Estraggo solo i trigger attivi (is_disabled=0)
      AND (T.name <> OBJECT_NAME(@@PROCID)) -- Escludo se stesso

    PRINT(@cmd_disable_trigger);
    EXEC(@cmd_disable_trigger);

    -- Logica
    -- ...
    -- ...

    -- Abilito i trigger
    --ALTER TABLE Sales.SalesOrderHeader ENABLE TRIGGER ALL;
    PRINT(@cmd_enable_trigger);
    EXEC(@cmd_enable_trigger);

  END TRY

  BEGIN CATCH

    IF (@@TRANCOUNT > 0)
      ROLLBACK;
    THROW;

  END CATCH
END;
GO


-- Sales.My_Trigger deve essere il primo ad attivarsi !!!

EXEC sp_settriggerorder
  @triggername = 'Sales.My_Trigger'
 ,@order = 'First'
 ,@stmttype = 'INSERT';
GO
EXEC sp_settriggerorder
  @triggername = 'Sales.My_Trigger'
 ,@order = 'First'
 ,@stmttype = 'UPDATE';
GO


-- Test
INSERT INTO Sales.SalesOrderHeader
(
  RevisionNumber, OrderDate, DueDate, ShipDate, Status, OnlineOrderFlag
  ,PurchaseOrderNumber, AccountNumber, CustomerID, SalesPersonID
  ,TerritoryID, BillToAddressID, ShipToAddressID, ShipMethodID
  ,CreditCardID, CreditCardApprovalCode, CurrencyRateID, SubTotal
  ,TaxAmt, Freight, Comment, rowguid, ModifiedDate
)
VALUES
(
  1, GETDATE(), GETDATE(), GETDATE(), 5, 1, NULL, N'4030-018759'
  ,18759, NULL, 6, 14024, 14024, 1, 10084, N'230370Vi51970', NULL, 155.9700
  ,15.1976, 4.7493, NULL, NEWID()
  ,GETDATE()
);
GO



-- Dopo aver portato in produzione il nuovo trigger, gli
-- utenti lamentano lentezze nella consultazione degli ordini

-- ????













ALTER TRIGGER Sales.My_Trigger ON Sales.SalesOrderHeader
FOR INSERT, UPDATE
AS BEGIN
  BEGIN TRY

    -- Disabilito i trigger
    --ALTER TABLE Sales.SalesOrderHeader DISABLE TRIGGER ALL;

    DECLARE
      @cmd_disable_trigger VARCHAR(MAX) = ''
      ,@cmd_enable_trigger VARCHAR(MAX) = '';

    SELECT
      -- Costruzione comandi per disabilitare i trigger
      @cmd_disable_trigger = @cmd_disable_trigger +
                             'ALTER TABLE Sales.SalesOrderHeader ' +
                             'DISABLE TRIGGER ' + T.name + ';' + CHAR(13) + CHAR(10)

      -- Costruzione comandi per abilitare i trigger
      ,@cmd_enable_trigger = @cmd_enable_trigger +
                             'ALTER TABLE Sales.SalesOrderHeader ' +
                             'ENABLE TRIGGER ' + T.name + ';' + CHAR(13) + CHAR(10)
    FROM
      sys.triggers AS T
    JOIN
      sys.objects AS O ON O.object_id=T.parent_id
    JOIN
      sys.schemas AS S ON S.schema_id=O.schema_id
    WHERE
      (S.name='Sales')
      AND (O.name='SalesOrderHeader')
      AND (T.is_disabled=0) -- Estraggo solo i trigger attivi (is_disabled=0)
      AND (T.name <> OBJECT_NAME(@@PROCID)) -- Escludo se stesso

    PRINT(@cmd_disable_trigger);
    EXEC(@cmd_disable_trigger);

    -- Logica
    -- ...
    -- ...

    -- Lock
    SELECT
      o.name
      ,o.type
      ,o.type_desc
      ,s.resource_type
      ,DB_NAME(s.resource_database_id) AS DBName
      ,s.request_mode
      ,s.request_type
      ,s.request_reference_count
      ,s.request_lifetime
      ,s.request_session_id
    FROM
      sys.dm_tran_locks AS s
    JOIN
      sys.objects AS o ON s.resource_associated_entity_id=o.object_id
    WHERE
      (s.request_session_id = @@SPID)
    -- ...
    -- ...

    -- Abilito i trigger
    --ALTER TABLE Sales.SalesOrderHeader ENABLE TRIGGER ALL;
    PRINT(@cmd_enable_trigger);
    EXEC(@cmd_enable_trigger);

  END TRY

  BEGIN CATCH

    IF (@@TRANCOUNT > 0)
      ROLLBACK;
    THROW;

  END CATCH
END;
GO

-- Sales.My_Trigger deve essere il primo ad attivarsi
EXEC sp_settriggerorder
  @triggername = 'Sales.My_Trigger'
 ,@order = 'First'
 ,@stmttype = 'INSERT';
GO
EXEC sp_settriggerorder
  @triggername = 'Sales.My_Trigger'
 ,@order = 'First'
 ,@stmttype = 'UPDATE';
GO

-- Test
INSERT INTO Sales.SalesOrderHeader
(
  RevisionNumber, OrderDate, DueDate, ShipDate, Status, OnlineOrderFlag
  ,PurchaseOrderNumber, AccountNumber, CustomerID, SalesPersonID
  ,TerritoryID, BillToAddressID, ShipToAddressID, ShipMethodID
  ,CreditCardID, CreditCardApprovalCode, CurrencyRateID, SubTotal
  ,TaxAmt, Freight, Comment, rowguid, ModifiedDate
)
VALUES
(
  1, GETDATE(), GETDATE(), GETDATE(), 5, 1, NULL, N'4030-018759'
  ,18759, NULL, 6, 14024, 14024, 1, 10084, N'230370Vi51970', NULL, 155.9700
  ,15.1976, 4.7493, NULL, NEWID()
  ,GETDATE()
);
GO