------------------------------------------------------------------------
-- Event:        SQL Saturday #264 - Ancona
-- Session:      Trigger: Utili o Dannosi?
-- Demo:         Trigger template
-- Author:       Sergio Govoni
-- Notes:        -
------------------------------------------------------------------------

USE [AdventureWorks2012];
GO

-- Template Trigger AFTER
CREATE TRIGGER <schema>.TR_<table>_<actions> ON <schema>.<table>
AFTER <actions> AS
BEGIN
  SET NOCOUNT ON; -- No messaggi circa il numero di righe modificate da un comando T-SQL
  SET ROWCOUNT 0; -- Nel caso il client abbia modificato il valore di rowcount (+MERGE)

  DECLARE
    @msg_error VARCHAR(1000)     -- Memorizza il messaggio di errore

    -- Contare i record nella tabella inserted per i trigger su INSERT o UPDATE,
    -- e quelli nella tabella deleted per i trigger UPDATE o DELETE in sostituzione
    -- di @@ROWCOUNT
    -- Il comando MERGE imposta @@ROWCOUNT con il numero di righe "merged" che pu�
    -- essere diverso dal numero di righe da controllare nel trigger
    ,@inserted_rows_affected INT
    ,@deleted_rows_affected INT;

  SET @inserted_rows_affected = (SELECT COUNT(*) FROM inserted);
  --SET @deleted_rows_affected = (SELECT COUNT(*) FROM deleted);

  -- Se non ci sono righe coinvolte nel comando che ha scatenato il trigger
  -- non c'� nulla da fare, se non restituire il controllo al chiamante
  IF @inserted_rows_affected = 0 RETURN;
  --IF @deleted_rows_affected = 0 RETURN;

  -- UPDATE Trigger
  -- Le colonne di interesse sono state aggiornate? Il valore � cambiato?
  -- Se le colonne di nostro interesse non sono state aggiornate
  -- avremo un'altra buona occasione per restituire il controllo
  -- al chiamante!
  IF UPDATE(<column_name>)
  BEGIN
    -- Azione
    -- ...
    -- ...
  END
  ELSE
	  RETURN;


  BEGIN TRY

    -- Validazione dei dati
    -- ...

    -- Implementazione della logica
    -- ...

  END TRY

  BEGIN CATCH

    IF @@TRANCOUNT > 0
      ROLLBACK TRANSACTION; -- Usare il terminatore di comando ";"

    -- [Log degli errori]

    DECLARE
      @ERROR_NUMBER INT = ERROR_NUMBER(),
      @ERROR_PROCEDURE SYSNAME = ERROR_PROCEDURE(),
      @ERROR_MESSAGE VARCHAR(4000) = ERROR_MESSAGE()

    --EXEC <schema>.usp_ErrorLog @ERROR_NUMBER, @ERROR_PROCEDURE, @ERROR_MESSAGE;

    THROW; -- Re-throw dell'errore

  END CATCH
END;
GO


-- Template Trigger INSTEAD OF
-- Template Trigger AFTER
CREATE TRIGGER <schema>.TR_<table>_<actions> ON <schema>.<table>
AFTER <actions> AS
BEGIN
  SET NOCOUNT ON; -- No messaggi circa il numero di righe modificate da un comando T-SQL
  SET ROWCOUNT 0; -- Nel caso il client abbia modificato il valore di rowcount (+MERGE)

  DECLARE
    @msg_error VARCHAR(1000)     -- Memorizza il messaggio di errore

    -- Contare i record nella tabella inserted per i trigger su INSERT o UPDATE,
    -- e quelli nella tabella deleted per i trigger UPDATE o DELETE in sostituzione
    -- di @@ROWCOUNT
    -- Il comando MERGE imposta @@ROWCOUNT con il numero di righe "merged" che pu�
    -- essere diverso dal numero di righe da controllare nel trigger
    ,@inserted_rows_affected INT
    ,@deleted_rows_affected INT;

  SET @inserted_rows_affected = (SELECT COUNT(*) FROM inserted);
  --SET @deleted_rows_affected = (SELECT COUNT(*) FROM deleted);

  -- Se non ci sono righe coinvolte nel comando che ha scatenato il trigger
  -- non c'� nulla da fare, se non restituire il controllo al chiamante
  IF @inserted_rows_affected = 0 RETURN;
  --IF @deleted_rows_affected = 0 RETURN;

  -- UPDATE Trigger
  -- Le colonne di interesse sono state aggiornate? Il valore � cambiato?
  -- Se le colonne di nostro interesse non sono state aggiornate
  -- avremo un'altra buona occasione per restituire il controllo
  -- al chiamante!
  IF UPDATE(<column_name>)
  BEGIN
    -- Azione
    -- ...
    -- ...
  END
  ELSE
	  RETURN;


  BEGIN TRY

    -- Validazione dei dati
    -- ...

    -- Implementazione della logica
    -- ...

    -- Azione sostitutiva
    -- ...

  END TRY

  BEGIN CATCH

    IF @@TRANCOUNT > 0
      ROLLBACK TRANSACTION; -- Usare il terminatore di comando ";"

    -- [Log degli errori]

    DECLARE
      @ERROR_NUMBER INT = ERROR_NUMBER(),
      @ERROR_PROCEDURE SYSNAME = ERROR_PROCEDURE(),
      @ERROR_MESSAGE VARCHAR(4000) = ERROR_MESSAGE()

    --EXEC <schema>.usp_ErrorLog @ERROR_NUMBER, @ERROR_PROCEDURE, @ERROR_MESSAGE;

    THROW; -- Re-throw dell'errore

  END CATCH
END;
GO