------------------------------------------------------------------------
-- Event:        SQL Saturday #264 - Ancona
-- Session:      Trigger: Utili o Dannosi?
-- Demo:         DDL Trigger
-- Author:       Sergio Govoni
-- Notes:        -
------------------------------------------------------------------------


DROP DATABASE [DBA];
GO


CREATE DATABASE [DBA];
GO


USE [DBA];
GO


/*
IF OBJECT_ID('dbo.DDLEvents') IS NOT NULL
  DROP TABLE dbo.DDLEvents;
GO
*/

CREATE TABLE dbo.DDLEvents
(
  EventType VARCHAR(MAX),
  EventDDL VARCHAR(MAX),
  EventXML XML,
  DatabaseName VARCHAR(MAX),
  SchemaName VARCHAR(MAX),
  ObjectName VARCHAR(MAX),
  HostName VARCHAR(MAX),
  IPAddress VARCHAR(MAX),
  ProgramName VARCHAR(MAX),
  LoginName VARCHAR(MAX)
);
GO


USE [master];
GO


CREATE TRIGGER [DDLTrigger_Modify_objects]
ON ALL SERVER
  FOR CREATE_DATABASE ,ALTER_DATABASE, DROP_DATABASE
AS
BEGIN
  SET NOCOUNT ON;
  BEGIN TRY
    DECLARE
      @EventData XML = EVENTDATA();

    DECLARE 
      @IP VARCHAR(32) =
      (
        SELECT client_net_address
        FROM sys.dm_exec_connections
        WHERE (session_id = @@SPID)
      );

     INSERT INTO DBA.dbo.DDLEvents
     (
       EventType,
       EventDDL,
       EventXML,
       DatabaseName,
       SchemaName,
       ObjectName,
       HostName,
       IPAddress,
       ProgramName,
       LoginName
     )
     SELECT
       @EventData.value('(/EVENT_INSTANCE/EventType)[1]', 'NVARCHAR(100)'), 
       @EventData.value('(/EVENT_INSTANCE/TSQLCommand)[1]', 'NVARCHAR(MAX)'),
       @EventData,
       DB_NAME(),
       @EventData.value('(/EVENT_INSTANCE/SchemaName)[1]', 'NVARCHAR(255)'), 
       @EventData.value('(/EVENT_INSTANCE/ObjectName)[1]', 'NVARCHAR(255)'),
       HOST_NAME(),
       @IP,
       PROGRAM_NAME(),
       SUSER_SNAME();
  END TRY
  BEGIN CATCH
    -- Gestione e notifica dell'errore
  END CATCH
END;
GO




SELECT * FROM sys.triggers;
GO




SELECT
  sm.definition
  ,st.*
FROM
  sys.server_triggers AS st
JOIN
  sys.server_sql_modules AS sm ON sm.object_id=st.object_id
WHERE
  (st.name = 'DDLTrigger_Modify_objects');
GO



-- Test
CREATE DATABASE [DBtest];
GO

USE [DBA];
GO


SELECT
  *
FROM
  dbo.DDLEvents;
GO


TRUNCATE TABLE dbo.DDLEvents;