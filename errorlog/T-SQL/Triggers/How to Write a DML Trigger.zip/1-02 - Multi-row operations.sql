--This demo is here to demonstrate the mechanics of multi-row operations. It is not intended
--to be a shining example of how to write a trigger.. That comes later :)
Use HowToWriteADmlTrigger;
go


--I�m going to demo code on a properly configured server with best practices code. 
--Then you�re all going to [complain] that it takes too long. --@peschkaj Jeremiah Peschka


--reset the objects for this section
IF EXISTS (SELECT * FROM sys.tables WHERE object_id = object_id('Characters.Person')) 
		DROP TABLE Characters.Person;
go
IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = 'Characters')
	EXEC ('CREATE SCHEMA Characters')
GO
--demo to show how inserted/deleted tables look

create table Characters.Person
(
	PersonId	int NOT NULL IDENTITY PRIMARY KEY,
	PersonNumber CHAR(2) UNIQUE,
	FirstName	nvarchar(20) null, 
	LastName	nvarchar(20) not null
)
go

CREATE TRIGGER Characters.Person$InsertTrigger
ON Characters.Person
AFTER INSERT AS
--trigger used to make sure that all names have a first and last name that is non-empty
--in a very common and reasonable looking manner
BEGIN
   --disabled for this demo only
   --IF @@rowcount = 0 RETURN; --if no rows affected by calling DML statement, exit

   SET NOCOUNT ON; --to avoid the rowcount messages
   SET ROWCOUNT 0; --in case the client has modified the rowcount

   DECLARE @msg varchar(2000),    --used to hold the error message
   --use inserted for insert or update trigger, deleted for update or delete trigger
   --count instead of @@rowcount due to merge behavior that sets @@rowcount to a number
   --that is equal to number of merged rows, not rows being checked in trigger
           @rowsAffected int = (SELECT COUNT(*) FROM inserted);
   --      @rowsAffected int = (SELECT COUNT(*) FROM deleted);

   --no need to continue on if no rows affected
   --disabled for this demo only
   --IF @rowsAffected = 0 RETURN;
   
   BEGIN TRY	 
          --[validation section] In this section, you should just look for issues and THROW errors

		  --first to show what is in these tables
		  SELECT CASE WHEN (SELECT COUNT(*) FROM inserted) > 0 THEN 'INSERT' 
					  ELSE 'INSERT-Nothing Modified' END
		  SELECT 'inserted    ', *
		  FROM   INSERTED;
		  SELECT 'deleted     ', *
		  FROM   DELETED;
		  SELECT 'actual table', *
		  FROM   Characters.Person
		  
          --[modification section] In this section, the goal is no errors and do any data mods here
		  
   END TRY
   BEGIN CATCH
		IF @@trancount > 0
			ROLLBACK TRANSACTION; --make sure to use semicolons to prevent THROW from being treated as a savepoint

		--[Error logging section] In this section, log any errors because you are outside of the transaction
						--due to the rollback
		DECLARE @ERROR_NUMBER int = ERROR_NUMBER(),
		        @ERROR_LOCATION sysname = ERROR_PROCEDURE(),
		        @ERROR_MESSAGE varchar(4000) = ERROR_MESSAGE()
		EXEC Utility.ErrorLog$Insert @ERROR_NUMBER,@ERROR_LOCATION,@ERROR_MESSAGE;

		THROW; --will halt the batch or be caught by the caller's catch block

  END CATCH
END;
GO
CREATE TRIGGER Characters.Person$UpdateTrigger
ON Characters.Person
AFTER UPDATE AS
--trigger used to make sure that all names have a first and last name that is non-empty
--in a very common and reasonable looking manner
BEGIN
   --disabled for this demo only
   --IF @@rowcount = 0 RETURN; --if no rows affected by calling DML statement, exit

   SET NOCOUNT ON; --to avoid the rowcount messages
   SET ROWCOUNT 0; --in case the client has modified the rowcount

   DECLARE @msg varchar(2000),    --used to hold the error message
   --use inserted for insert or update trigger, deleted for update or delete trigger
   --count instead of @@rowcount due to merge behavior that sets @@rowcount to a number
   --that is equal to number of merged rows, not rows being checked in trigger
           @rowsAffected int = (SELECT COUNT(*) FROM inserted);
   --      @rowsAffected int = (SELECT COUNT(*) FROM deleted);

   --no need to continue on if no rows affected
   --disabled for this demo only
   --IF @rowsAffected = 0 RETURN;
   
   BEGIN TRY	 
          --[validation section] In this section, you should just look for issues and THROW errors

		  --first to show what is in these tables
		  SELECT CASE WHEN (SELECT COUNT(*) FROM inserted) > 0 THEN 'UPDATE'
					  ELSE 'UPDATE-Nothing Modified' END
		  SELECT 'inserted    ', *
		  FROM   INSERTED;
		  SELECT 'deleted     ', *
		  FROM   DELETED;
		  SELECT 'actual table', *
		  FROM   Characters.Person
		  
          --[modification section] In this section, the goal is no errors and do any data mods here
		  
   END TRY
   BEGIN CATCH
		IF @@trancount > 0
			ROLLBACK TRANSACTION; --make sure to use semicolons to prevent THROW from being treated as a savepoint

		--[Error logging section] In this section, log any errors because you are outside of the transaction
						--due to the rollback
		DECLARE @ERROR_NUMBER int = ERROR_NUMBER(),
		        @ERROR_LOCATION sysname = ERROR_PROCEDURE(),
		        @ERROR_MESSAGE varchar(4000) = ERROR_MESSAGE()
		EXEC Utility.ErrorLog$Insert @ERROR_NUMBER,@ERROR_LOCATION,@ERROR_MESSAGE;

		THROW; --will halt the batch or be caught by the caller's catch block

  END CATCH
END;
GO
CREATE TRIGGER Characters.Person$DeleteTrigger
ON Characters.Person
AFTER DELETE AS
--trigger used to make sure that all names have a first and last name that is non-empty
--in a very common and reasonable looking manner
BEGIN
   --disabled for this demo only
   --IF @@rowcount = 0 RETURN; --if no rows affected by calling DML statement, exit

   SET NOCOUNT ON; --to avoid the rowcount messages
   SET ROWCOUNT 0; --in case the client has modified the rowcount

   DECLARE @msg varchar(2000),    --used to hold the error message
   --use inserted for insert or update trigger, deleted for update or delete trigger
   --count instead of @@rowcount due to merge behavior that sets @@rowcount to a number
   --that is equal to number of merged rows, not rows being checked in trigger
   --      @rowsAffected int = (SELECT COUNT(*) FROM inserted);
           @rowsAffected int = (SELECT COUNT(*) FROM deleted);

   --no need to continue on if no rows affected
   --disabled for this demo only
   --IF @rowsAffected = 0 RETURN;
   
   BEGIN TRY	 
          --[validation section] In this section, you should just look for issues and THROW errors

		  --first to show what is in these tables
		  SELECT CASE WHEN (SELECT COUNT(*) FROM deleted) > 0 THEN 'DELETE' 
			          ELSE 'DELETE-Nothing Modified' END
		  SELECT 'inserted    ', *
		  FROM   INSERTED;
		  SELECT 'deleted     ', *
		  FROM   DELETED;
		  SELECT 'actual table', *
		  FROM   Characters.Person
		  
          --[modification section] In this section, the goal is no errors and do any data mods here
		  
   END TRY
   BEGIN CATCH
		IF @@trancount > 0
			ROLLBACK TRANSACTION; --make sure to use semicolons to prevent THROW from being treated as a savepoint

		--[Error logging section] In this section, log any errors because you are outside of the transaction
						--due to the rollback
		DECLARE @ERROR_NUMBER int = ERROR_NUMBER(),
		        @ERROR_LOCATION sysname = ERROR_PROCEDURE(),
		        @ERROR_MESSAGE varchar(4000) = ERROR_MESSAGE()
		EXEC Utility.ErrorLog$Insert @ERROR_NUMBER,@ERROR_LOCATION,@ERROR_MESSAGE;

		THROW; --will halt the batch or be caught by the caller's catch block

  END CATCH
END;
GO
--one row...
INSERT INTO Characters.Person(PersonNumber, FirstName, LastName)
VALUES ('FF','Fred', 'Flintstone');
GO
--two rows...
INSERT INTO Characters.Person(PersonNumber, FirstName, LastName)
VALUES ('BR','Barney', 'Rubble'),
	   ('TR','Betty', 'Rubble');
go

UPDATE Characters.Person
SET FirstName = 'Frederick'
WHERE  PersonNumber = 'FF'
go

UPDATE Characters.Person
SET    firstName = UPPER(FirstName)
WHERE  LastName = 'Rubble'
go

UPDATE Characters.Person
SET    firstName = UPPER(FirstName)
WHERE  personNumber = '??'
go

INSERT INTO Characters.Person(PersonNumber, FirstName, LastName)
VALUES ('SM','Sam', 'Malone');
GO
DELETE FROM Characters.Person
WHERE  PersonNumber = 'SM' --Not a Bedrock citizen
go

--MERGE--

--run twice--

SELECT *
FROM   Characters.Person

--triggers called even when no changes...
;WITH   testMerge as (SELECT *
                     FROM   (Values('FF','Fred','Flintstone'), --Update (name was Frederick)
								   ('WF','Wilma','Flintstone'), --Insert
								   ('TR','Betty','Rubble'))  -- No change (case insensitive collation)
								    --Barney will be deleted
														as testMerge (PersonNumber,FirstName, LastName))
MERGE  Characters.Person
USING  (SELECT PersonNumber,FirstName, LastName FROM testMerge) AS source (PersonNumber,FirstName, LastName)
        ON (person.PersonNumber = source.personNumber
		    )
WHEN MATCHED AND (Person.FirstName <> source.FirstName 
                  OR (Person.FirstName IS NULL AND Source.FirstName IS NOT NULL)
				  OR (Person.FirstName IS NOT NULL AND Source.FirstName IS NULL)
				  OR Person.LastName <> Source.LastName) THEN  
	UPDATE SET FirstName = source.FirstName,
			 LastName = SOURCE.LastName
WHEN NOT MATCHED THEN
	INSERT (PersonNumber,FirstName,LastName) VALUES (Source.PersonNumber,Source.FirstName,Source.LastName)
WHEN NOT MATCHED BY SOURCE THEN 
     DELETE;
Go

SELECT *
FROM   Characters.Person

------------------------------------------------
--the problem with updatable keys. In this example, we scramble the unique key, and the only
--data we can use to figure out pre- and post- images is in the immutable surrogate key
UPDATE Characters.Person
SET    PersonNumber = CASE PersonNumber WHEN 'WF' THEN 'TR'
										WHEN 'FF' THEN 'WF'
										WHEN 'TR' THEN 'FF' END
 							




