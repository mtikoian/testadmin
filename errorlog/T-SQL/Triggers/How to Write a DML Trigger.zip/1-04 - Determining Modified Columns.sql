Use HowToWriteADmlTrigger;
go
--uses database from previous file

CREATE TRIGGER Characters.Person$updateTrigger
ON Characters.Person
AFTER UPDATE AS
--trigger used to make sure that all names have a first and last name that is non-empty
--in a very common and reasonable looking manner
BEGIN
   IF @@rowcount = 0 RETURN; --if no rows affected by calling DML statement, exit

   SET NOCOUNT ON; --to avoid the rowcount messages
   SET ROWCOUNT 0; --in case the client has modified the rowcount

   DECLARE @msg varchar(2000),    --used to hold the error message
   --use inserted for insert or update trigger, deleted for update or delete trigger
   --count instead of @@rowcount due to merge behavior that sets @@rowcount to a number
   --that is equal to number of merged rows, not rows being checked in trigger
           @rowsAffected int = (SELECT COUNT(*) FROM inserted);
   --      @rowsAffected int = (SELECT COUNT(*) FROM deleted);

   --no need to continue on if no rows affected
   IF @rowsAffected = 0 RETURN;
   
   BEGIN TRY	 
          --[validation section] In this section, you should just look for issues and THROW errors
		 
		 IF UPDATE(FirstName)  --There is a bitwise version: COLUMNS_UPDATED, but it is not a very good idea.
		  BEGIN
  			  --demo only
			  SELECT 'FirstName Validation';
          
			  --could do both checks in one pass but this is often 
			  --the easiest way to get best error messages
			  if exists (select *
						 from   Inserted
						 where  FirstName = '') 
				THROW 50000, N'First Name cannot be blank',1;
		  END          

		 IF UPDATE(LastName)
		  BEGIN
			  --demo only
			  SELECT 'LastName Validation';

			  if exists (select *
						 from   Inserted
						 where  LastName = '') 
				THROW 50000, N'Last Name cannot be blank',1;
		  END
          
          --[modification section] In this section, the goal is no errors and do any data mods here
		  
   END TRY
   BEGIN CATCH
		IF @@trancount > 0
			ROLLBACK TRANSACTION; --make sure to use semicolons to prevent THROW from being treated as a savepoint

		--[Error logging section] In this section, log any errors because you are outside of the transaction
						--due to the rollback
		  DECLARE @ERROR_NUMBER int = ERROR_NUMBER(),
		          @ERROR_LOCATION sysname = ERROR_PROCEDURE(),
		          @ERROR_MESSAGE varchar(4000) = ERROR_MESSAGE()
		  EXEC Utility.ErrorLog$Insert @ERROR_NUMBER,@ERROR_LOCATION,@ERROR_MESSAGE;

		THROW; --will halt the batch or be caught by the caller's catch block

  END CATCH
END;
GO

TRUNCATE TABLE Characters.Person
go
--first two statements are setup for the updates
--one correct row... no trigger messages yet :)
INSERT INTO Characters.Person(PersonNumber, FirstName, LastName)
VALUES ('FF','Fred', 'Flintstone');
GO
--two correct rows...
INSERT INTO Characters.Person(PersonNumber, FirstName, LastName)
VALUES ('BR','Barney', 'Rubble'),
	   ('TR','Betty', 'Rubble');
GO

UPDATE Characters.Person
SET    FirstName = 'Frederick'
WHERE  PersonNumber = 'FF'
GO
UPDATE Characters.Person
SET    LastName = 'Flintstoney' 
WHERE  PersonNumber = 'FF'
GO

UPDATE Characters.Person
SET    FirstName = 'Fred', 
	   LastName = 'Flintstone' 
WHERE  PersonNumber = 'FF'
GO

--nothing changes, but you still get the validation...
UPDATE Characters.Person
SET    FirstName = 'Fred', 
	   LastName = 'Flintstone' 
WHERE  PersonNumber = 'FF'
GO

--no trigger validations
UPDATE Characters.Person
SET    PersonNumber = 'FR'
WHERE  FirstName = 'Fred' 
  AND  LastName = 'Flintstone' 

GO
