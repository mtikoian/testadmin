USE HowToWriteADmlTrigger
go
set nocount on
GO
DROP TABLE Demo.TriggerOrder
go
CREATE TABLE Demo.TriggerOrder
(
	triggerOrderId INT PRIMARY KEY
)
GO
CREATE TRIGGER Demo.TriggerOrder$afterInsertA
ON Demo.TriggerOrder
AFTER INSERT, UPDATE AS 
BEGIN
	--error handling/template omitted for clarity
	SELECT object_name(@@procid),
		   CASE WHEN (SELECT COUNT(*) FROM DELETED) > 0 THEN 'Update' ELSE 'Insert' END 
END;
go 
CREATE TRIGGER Demo.TriggerOrder$afterInsertB
ON Demo.TriggerOrder
AFTER INSERT, UPDATE AS 
BEGIN
	--error handling/template omitted for clarity
	SELECT object_name(@@procid),
		   CASE WHEN (SELECT COUNT(*) FROM DELETED) > 0 THEN 'Update' ELSE 'Insert' END 
END;
GO
CREATE TRIGGER Demo.TriggerOrder$afterInsertC
ON Demo.TriggerOrder
AFTER INSERT, UPDATE AS 
BEGIN
	--error handling/template omitted for clarity
	SELECT object_name(@@procid),
		   CASE WHEN (SELECT COUNT(*) FROM DELETED) > 0 THEN 'Update' ELSE 'Insert' END 
END;
GO
CREATE TRIGGER Demo.TriggerOrder$afterInsertD
ON Demo.TriggerOrder
AFTER INSERT, UPDATE AS 
BEGIN
	--error handling/template omitted for clarity
	SELECT object_name(@@procid),
		   CASE WHEN (SELECT COUNT(*) FROM DELETED) > 0 THEN 'Update' ELSE 'Insert' END 
END;
GO
INSERT INTO Demo.TriggerOrder
VALUES (1)
GO
EXEC sp_settriggerorder 'Demo.TriggerOrder$afterInsertD','first','insert';
EXEC sp_settriggerorder 'Demo.TriggerOrder$afterInsertA','last','insert';
go
INSERT INTO Demo.TriggerOrder
VALUES (2)
GO
UPDATE Demo.TriggerOrder
SET  triggerOrderId = 2
WHERE triggerOrderId = 2;
GO
EXEC sp_settriggerorder 'Demo.TriggerOrder$afterInsertB','first','update';
EXEC sp_settriggerorder 'Demo.TriggerOrder$afterInsertC','last','update';
GO
UPDATE Demo.TriggerOrder
SET  triggerOrderId = 2
WHERE triggerOrderId = 2;
GO

--losing the ordering attribute, accidentally...
alter TRIGGER Demo.TriggerOrder$afterInsertB
ON Demo.TriggerOrder
AFTER INSERT, UPDATE AS 
BEGIN
	--error handling/template omitted for clarity
	SELECT object_name(@@procid),
		   CASE WHEN (SELECT COUNT(*) FROM DELETED) > 0 THEN 'Update' ELSE 'Insert' END 
END;
GO


--reverting the order on purpose
EXEC sp_settriggerorder 'Demo.TriggerOrder$afterInsertC','none','update';
GO
UPDATE Demo.TriggerOrder
SET  triggerOrderId = 2
WHERE triggerOrderId = 2;
GO

SELECT schemas.name as schema_name, triggers.name as trigger_name, objects.name as object_name, 
		lower(objects.type_desc) as object_type,
		triggers.is_disabled,
		max(case when trigger_events.type_desc = 'INSERT' then 1 else 0 end) as insert_event,
		max(case when trigger_events.type_desc = 'INSERT' then is_first else 0 end) as insert_first,
		max(case when trigger_events.type_desc = 'UPDATE' then 1 else 0 end) as update_event,
		max(case when trigger_events.type_desc = 'UPDATE' then is_first else 0 end) as update_first,
		max(case when trigger_events.type_desc = 'DELETE' then 1 else 0 end) as delete_event,
		max(case when trigger_events.type_desc = 'DELETE' then is_first else 0 end) as delete_first,
		max(object_definition(triggers.object_id)) as TriggerDefinition
FROM sys.triggers
		join sys.objects
			on objects.object_id = triggers.parent_id
		join sys.schemas
			on objects.schema_id = schemas.schema_id
         JOIN sys.trigger_events
                  ON sys.triggers.object_id = sys.trigger_events.object_id
WHERE parent_id = object_id('Demo.TriggerOrder')
group by schemas.name, triggers.is_disabled,triggers.name, objects.name, lower(objects.type_desc);
go