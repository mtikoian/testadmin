--15 seconds last run

use master
go
set nocount on
go
--reset server settings to defaults...
exec sp_configure 'show advanced options',1
go
reconfigure
go
exec sp_configure 'nested triggers',1
exec sp_configure 'disallow results from triggers',0 --allow results
go
reconfigure
go

--drop db if you are recreating it, dropping all connections to existing database.
if exists (select * from sys.databases where name = 'HowToWriteADmlTrigger')
 exec ('
alter database  HowToWriteADmlTrigger
	set single_user with rollback immediate;

drop database HowToWriteADmlTrigger;')
GO

CREATE DATABASE HowToWriteADmlTrigger
GO
USE HowToWriteADmlTrigger
go
--I rely on the default, no matter what the Model database may say
alter database HowToWriteADmlTrigger	
	set recursive_triggers off;
go
CREATE SCHEMA Utility
go
GRANT EXECUTE ON SCHEMA::Utility TO PUBLIC
go
--simple object to capture errors...
CREATE TABLE Utility.ErrorLog(
        ErrorLogId int NOT NULL IDENTITY CONSTRAINT PKErrorLog PRIMARY KEY,
		Number int NOT NULL,
        Location sysname NOT NULL,
        Message varchar(4000) NOT NULL,
        LogTime datetime2(3) NULL
              CONSTRAINT dfltErrorLog_error_date  DEFAULT (sysdatetime()),
        ServerPrincipal sysname NOT NULL
              --use original_login to capture the user name of the actual user
              --not a user they have impersonated
              CONSTRAINT dfltErrorLog_error_user_name DEFAULT (original_login())
);
GO
CREATE PROCEDURE Utility.ErrorLog$Insert
(
        @ERROR_NUMBER int,
        @ERROR_LOCATION sysname,
        @ERROR_MESSAGE varchar(4000)
) as
 BEGIN
        SET NOCOUNT ON;
        BEGIN TRY
           INSERT INTO utility.ErrorLog(Number, Location,Message)
           SELECT @ERROR_NUMBER,COALESCE(@ERROR_LOCATION,'No Object'),@ERROR_MESSAGE;
        END TRY
        BEGIN CATCH
           INSERT INTO utility.ErrorLog(Number, Location, Message)
           VALUES (-100, 'utility.ErrorLog$insert',
                        'An invalid call was made to the error log procedure ' + ERROR_MESSAGE());
        END CATCH
END;
GO

-----------------------------------------------------------------
--  Tools (Generally user facing that they can rely on)
-----------------------------------------------------------------

CREATE SCHEMA Tools
go

CREATE TABLE Tools.Number
(
    I   int CONSTRAINT PKTools_Number PRIMARY KEY
);
GO


;WITH DIGITS (I) as(--set up a set of numbers from 0-9
        SELECT I
        FROM   (VALUES (0),(1),(2),(3),(4),(5),(6),(7),(8),(9)) as digits (I))
--builds a table from 0 to 999999
,Integers (I) as (
        SELECT D1.I + (10*D2.I) + (100*D3.I) + (1000*D4.I) + (10000*D5.I)
               + (100000*D6.I)
        FROM digits AS D1 CROSS JOIN digits AS D2 CROSS JOIN digits AS D3
                CROSS JOIN digits AS D4 CROSS JOIN digits AS D5
                CROSS JOIN digits AS D6) 
INSERT INTO Tools.Number(I)
SELECT I
FROM   Integers;
GO



CREATE TRIGGER tr_server$noDboSchemaObjects
ON DATABASE
AFTER CREATE_TABLE, DROP_TABLE, ALTER_TABLE,
	  CREATE_PROCEDURE, ALTER_PROCEDURE,
	  CREATE_FUNCTION, ALTER_FUNCTION,
	  CREATE_SEQUENCE, ALTER_SEQUENCE,
	  CREATE_TRIGGER, ALTER_TRIGGER
AS
 BEGIN
   SET NOCOUNT ON --to avoid the rowcount messages
   SET ROWCOUNT 0 --in case the client has modified the rowcount

   BEGIN TRY
 
	IF EXISTS ( SELECT *
				FROM   sys.objects
				WHERE  SCHEMA_ID = SCHEMA_ID('dbo')
				  AND  type_desc NOT IN ('SERVICE_QUEUE'))
		THROW 50000,'Get your filthy hands off my desert, I mean, dbo schema',16
    END TRY
   BEGIN CATCH 
             IF @@trancount > 0 
                ROLLBACK TRANSACTION

              DECLARE @ERROR_MESSAGE varchar(8000)
              SET @ERROR_MESSAGE = ERROR_MESSAGE()
              RAISERROR (@ERROR_MESSAGE,16,1)

     END CATCH
END
GO

