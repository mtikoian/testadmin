USE TriggerDemo;
SET NOCOUNT ON;
GO

SELECT 
  [trigger] = tr.name,
  tr.is_instead_of_trigger,
  [table] = s.name + '.' + o.name,
  last_execution_time, execution_count,
  max_elapsed_time, max_logical_reads,
  avg_elapsed_time = ts.total_elapsed_time*1.0/execution_count 
FROM sys.dm_exec_trigger_stats AS ts
  INNER JOIN sys.triggers AS tr ON ts.[object_id] = tr.[object_id]
  INNER JOIN sys.objects  AS o ON tr.parent_id = o.[object_id]
  INNER JOIN sys.schemas AS s ON o.[schema_id] = s.[schema_id]
  WHERE ts.database_id = DB_ID()
  AND ts.[type] = N'TR' AND tr.is_disabled = 0;