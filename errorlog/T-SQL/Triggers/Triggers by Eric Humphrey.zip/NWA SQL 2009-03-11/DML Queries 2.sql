USE TriggerDemo;
go

--------------------------------------------------------------------------------
-- Test Summary Tables
--------------------------------------------------------------------------------
INSERT INTO dbo.Orders( description)
VALUES
	('My Order'),
	('My 2nd Order');

DECLARE @id1 INT, @id2 INT
SELECT @id1 = max(order_id), @id2 = MAX(order_id) - 1
FROM dbo.Orders;

SELECT @id1 id1, @id2 id2;

INSERT INTO dbo.OrderDetails( order_id, item_nbr, item_qty, item_price)
VALUES
	( @id1, 101, 2.0, 10.00),
	( @id1, 102, 15.0, 2.00),
	( @id2, 101, 3.0, 10.00),
	( @id2, 102, 6.0, 2.00);

SELECT * FROM dbo.Orders WHERE order_id IN (@id1, @id2);

