USE master;
GO

CREATE DATABASE TriggerDemo;
GO

USE TriggerDemo;
GO

CREATE TABLE dbo.Personnel
(
	personnel_id INT IDENTITY PRIMARY KEY,
	name_first VARCHAR(30) NOT NULL,
	name_last VARCHAR(30) NOT NULL,
	pay_rate MONEY NOT NULL DEFAULT 0,
	emp_status CHAR(1) NOT NULL DEFAULT 'A',
	last_modified DATETIME NOT NULL DEFAULT GETDATE(),
	last_modified_user VARCHAR(16) NOT NULL
);
GO

CREATE TABLE dbo.Personnel_Log
(
	personnel_id INT,
	name_first VARCHAR(30) NOT NULL,
	name_last VARCHAR(30) NOT NULL,
	pay_rate MONEY NOT NULL,
	emp_status CHAR(1) NOT NULL,
	last_modified DATETIME NOT NULL,
	last_modified_user VARCHAR(16) NOT NULL,
	log_action CHAR(1) NOT NULL,
	log_datetime DATETIME NOT NULL DEFAULT GETDATE()
);
GO

CREATE TABLE dbo.Orders
(
	order_id INT IDENTITY PRIMARY KEY,
	description VARCHAR(50) NOT NULL,
	subtotal MONEY NOT NULL DEFAULT 0
);

CREATE TABLE dbo.OrderDetails
(
	detail_id INT IDENTITY PRIMARY KEY,
	order_id INT NOT NULL REFERENCES dbo.Orders(order_id),
	item_nbr INT NOT NULL,
	item_qty DECIMAL(18,2) NOT NULL,
	item_price MONEY NOT NULL DEFAULT 0
);

--------------------------------------------------------------------------------
-- Create trigger for history table
--------------------------------------------------------------------------------
CREATE TRIGGER dbo.TR_Personnel_Log ON dbo.Personnel
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @log_action CHAR(1)
	IF EXISTS (SELECT * FROM INSERTED)
	BEGIN
		IF EXISTS (SELECT * FROM DELETED)
		BEGIN
			SET @log_action = 'U'
		END
		ELSE
		BEGIN
			SET @log_action = 'I'
		END

		INSERT INTO dbo.Personnel_Log(
			personnel_id,
			name_first,
			name_last,
			pay_rate,
			emp_status,
			last_modified,
			last_modified_user,
			log_action
		)
		SELECT
			personnel_id,
			name_first,
			name_last,
			pay_rate,
			emp_status,
			last_modified,
			last_modified_user,
			@log_action
		FROM INSERTED
	END
	ELSE
	BEGIN
		SET @log_action = 'D'

		INSERT INTO dbo.Personnel_Log(
			personnel_id,
			name_first,
			name_last,
			pay_rate,
			emp_status,
			last_modified,
			last_modified_user,
			log_action
		)
		SELECT
			personnel_id,
			name_first,
			name_last,
			pay_rate,
			emp_status,
			last_modified,
			last_modified_user,
			@log_action
		FROM DELETED
	END

END;
GO

--------------------------------------------------------------------------------
-- Create printName proc
--------------------------------------------------------------------------------
CREATE PROCEDURE dbo.printName
	@personnel_id INT,
	@name_first VARCHAR(30),
	@name_last VARCHAR(30)
AS
BEGIN
	PRINT 'Inserted or Updated ' + @name_first + ' ' + @name_last + '(' + convert(varchar, @personnel_id) + ')'
END;

