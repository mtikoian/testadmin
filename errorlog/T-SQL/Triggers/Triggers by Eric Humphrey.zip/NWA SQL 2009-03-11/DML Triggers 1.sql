USE TriggerDemo;
go

--------------------------------------------------------------------------------
-- Calling a proc on inserted rows
--------------------------------------------------------------------------------
IF  EXISTS (SELECT * FROM sys.triggers WHERE object_id = OBJECT_ID(N'[dbo].[TR_Personnel_CallProc]'))
DROP TRIGGER [dbo].[TR_Personnel_CallProc]
GO

CREATE TRIGGER [dbo].[TR_Personnel_CallProc] ON Personnel
AFTER INSERT, UPDATE
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE
		@personnel_id INT,
		@name_first VARCHAR(30),
		@name_last VARCHAR(30)

	DECLARE myCursor CURSOR FAST_FORWARD FOR
		SELECT personnel_id, name_first, name_last
		FROM INSERTED
	OPEN myCursor
	FETCH myCursor INTO @personnel_id, @name_first, @name_last
	WHILE @@FETCH_STATUS = 0
	BEGIN
		EXEC dbo.printName @personnel_id, @name_first, @name_last
		FETCH myCursor INTO @personnel_id, @name_first, @name_last
	END
	CLOSE myCursor
	DEALLOCATE myCursor
END;
GO
