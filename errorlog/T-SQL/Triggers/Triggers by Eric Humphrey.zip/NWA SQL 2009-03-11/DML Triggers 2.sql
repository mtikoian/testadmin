USE TriggerDemo;
go

--------------------------------------------------------------------------------
-- Summary Tables (BAD)
--------------------------------------------------------------------------------
IF  EXISTS (SELECT * FROM sys.triggers WHERE object_id = OBJECT_ID(N'[dbo].[TR_OrderDetail_Subtotal]'))
DROP TRIGGER [dbo].[TR_OrderDetail_Subtotal]
GO

CREATE TRIGGER dbo.TR_OrderDetail_Subtotal ON dbo.OrderDetails
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @order_id INT
	SELECT @order_id = order_id FROM INSERTED

	UPDATE dbo.Orders
	SET subtotal = (
		SELECT SUM(item_qty * item_price)
		FROM dbo.OrderDetails
		WHERE order_id = @order_id
	)
	WHERE order_id = @order_id
END;
GO


--------------------------------------------------------------------------------
-- Summary Tables (GOOD)
--------------------------------------------------------------------------------
IF  EXISTS (SELECT * FROM sys.triggers WHERE object_id = OBJECT_ID(N'[dbo].[TR_OrderDetail_Subtotal]'))
DROP TRIGGER [dbo].[TR_OrderDetail_Subtotal]
GO

CREATE TRIGGER dbo.TR_OrderDetail_Subtotal ON dbo.OrderDetails
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
	DECLARE @Count int;

	SET @Count = @@ROWCOUNT;
	IF @Count = 0
		RETURN;

	SET NOCOUNT ON;

	UPDATE dbo.Orders
	SET subtotal = (
		SELECT SUM(item_qty * item_price)
		FROM dbo.OrderDetails
		WHERE order_id = Orders.order_id
	)
	WHERE order_id IN (
		SELECT order_id FROM inserted
	)
END;
GO

