USE TriggerDemo;
go


--------------------------------------------------------------------------------
-- Logging for single row
--------------------------------------------------------------------------------
INSERT INTO dbo.Personnel( name_first, name_last, pay_rate, emp_status, last_modified_user)
VALUES( 'Eric', 'Humphrey', 50.00, 'A', 'erich');

WAITFOR DELAY '00:00:01'

UPDATE dbo.Personnel
SET pay_rate = 100.00,
	last_modified = GETDATE()
WHERE name_first = 'Eric'
	AND name_last = 'Humphrey';

WAITFOR DELAY '00:00:01'

DELETE dbo.Personnel
WHERE name_first = 'Eric'
	AND name_last = 'Humphrey';

WAITFOR DELAY '00:00:01'

SELECT *
FROM dbo.Personnel_Log
ORDER BY log_datetime DESC;



--------------------------------------------------------------------------------
-- Logging for multiple rows
--------------------------------------------------------------------------------
INSERT INTO dbo.Personnel( name_first, name_last, pay_rate, emp_status, last_modified_user)
VALUES
	('Eric', 'Humphrey', 50.00, 'A', 'erich'),
	('Jason', 'Pluenneke', 75.00, 'A', 'erich'),
	('Boyd', 'Evert', 100.00, 'A', 'erich');

WAITFOR DELAY '00:00:01'

UPDATE dbo.Personnel
SET pay_rate = pay_rate * 1.04,
	last_modified = GETDATE()
WHERE pay_rate < 100;

WAITFOR DELAY '00:00:01'

DELETE dbo.Personnel;

WAITFOR DELAY '00:00:01'

SELECT *
FROM dbo.Personnel_Log
ORDER BY log_datetime DESC;