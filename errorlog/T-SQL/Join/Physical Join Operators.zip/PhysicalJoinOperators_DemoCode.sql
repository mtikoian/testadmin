
---------------------------------------------------------------------------------
-- Physical Join Operators - Demo Code ---------------------------------=--------
-- By Ami Levin -----------------------------------------------------------------
---------------------------------------------------------------------------------
-- ** Use SQL Server 2008R2 SP1 ** ----------------------------------------------
---------------------------------------------------------------------------------
-- AdventureWorks2008R2 DB can be downloaded from:  -----------------------------
-- http://msftdbprodsamples.codeplex.com/releases/view/55926#DownloadId=174661 --
---------------------------------------------------------------------------------

USE AdventureWorks2008R2;
GO

---------------------------------------------------------------------------------
-- NESTED LOOPS -----------------------------------------------------------------
---------------------------------------------------------------------------------
GO
--------------------------------------------------------------------- Query #1 --
-- Simple 'no-brainer' example:                                                --
-- Products is the smallest possible 'blue input'.                             --
-- --> Just 1 row, filtered by ProductID - the primary key.                    --
-- Sales Order Detail as 'red input' is ideally indexed.                       --
-- --> Non-clustered, covering index on ProductID.                             --
---------------------------------------------------------------------------------

SELECT	SOD.SalesOrderID,	
		P.Name
FROM	Production.Product AS P
		INNER JOIN
		Sales.SalesOrderDetail AS SOD
		ON P.ProductID	= SOD.ProductID
WHERE	P.ProductID	= 870
GO

-------------------------------------------------------------------- Query #2a --
-- Let's try the same query with an additional column, OrderQty for example.   --
-- This makes the 'red input' less ideally indexed - no covering index...      --
-- However, since the 'blue input' is so small - just 1 row,                   --
-- --> it's still very efficient even to fully scan the 'red input', only once.--
---------------------------------------------------------------------------------

SELECT	SOD.SalesOrderID,
		P.Name,
		SOD.OrderQty
FROM	Production.Product AS P
		INNER JOIN
		Sales.SalesOrderDetail AS SOD
		ON P.ProductID = SOD.ProductID
WHERE	P.ProductID = 870
GO

-------------------------------------------------------------------- Query #2b --
-- But what happens when the 'blue input' becomes a bit larger?                --
-- --> Let's add 1 more product to the filter - 'Blue input' is now 2 rows     --
-- It is still best to use nested loops and full scan the 'red input'?         --
-- --> 2 full scans will be required if the same plan as as query #2a is used. --
---------------------------------------------------------------------------------

	SELECT	SOD.SalesOrderID,
			P.Name,
			SOD.OrderQty
	FROM	Production.Product AS P
			INNER JOIN
			Sales.SalesOrderDetail AS SOD
			ON P.ProductID = SOD.ProductID
	WHERE	P.ProductID IN (870,871)
	GO

-------------------------------------------------------------------- Query #2c --
-- Actually, there are more options for the optimizer here.                    --
-- Why wasn't nested loops used for query #2b?                                 --
-- --> Is it just because the 'blue input' was 2 rows?                         --
-- --> Or was there another reason?                                            --
-- Let's make the 'blue input' even larger - 3 rows.                           --
-- --> However, note that we're using different ProductIDs now...              --
-- --> What was the decisive factor for the optimizer here to use nested loops?--
---------------------------------------------------------------------------------

SELECT	SOD.SalesOrderID,
		P.Name,
		SOD.OrderQty
FROM	Production.Product AS P
		INNER JOIN
		Sales.SalesOrderDetail AS SOD
		ON P.ProductID = SOD.ProductID
WHERE	P.ProductID IN (897,942,943)
GO

---------------------------------------------------------------------------------
-- See index spool example in appendix 1 at the end of this demo script file. ---
---------------------------------------------------------------------------------

--------------------------------------------------------------------- Query #4 --
-- --> Pitfall Alert! <--                                                      --
-- An example of a Query that can trick the optimizer.                         --
-- Something causes it to select nested loops, when it's not the optimal plan. --
-- --> Can you see what is it? How can you easily spot this?                   --
---------------------------------------------------------------------------------

SELECT	SOD.SalesOrderID, 
		P.Name, 
		SOD.OrderQty
FROM	Production.Product AS P
		INNER JOIN
		Sales.SalesOrderDetail AS SOD
		ON P.ProductID = SOD.ProductID
WHERE	P.DaysToManufacture > 2
		AND
		ListPrice > 1350
		AND
		StandardCost > 750
GO

---------------------------------------------------------------------------------
-- See benchmark script that tests this query with all possible join hints ------
-- in appendix 1 at the end of this demo script file. ---------------------------
---------------------------------------------------------------------------------

---------------------------------------------------------------------------------
-- MERGE ------------------------------------------------------------------------
---------------------------------------------------------------------------------
GO
--------------------------------------------------------------------- Query #5 --
-- Simple 'no-brainer' example:                                                --
-- Both inputs are already sorted and 'ready to be merged',                    --
-- either via the clustered index which covers all columns...                  --
-- --> Side note: What are the 'compute scalar' operators doing here?          --
---------------------------------------------------------------------------------

SELECT	*
FROM	Sales.SalesOrderHeader AS SOH
		INNER JOIN
		Sales.SalesOrderDetail AS SOD
		ON SOH.SalesOrderID = SOD.SalesOrderID
GO

-------------------------------------------------------------------- Query #6a --
-- ...Or via non-clustered index on the join column,                           --
-- --> Especially if they cover the query.                                     --
-- --> Also, note the 'ordered' property of the scans. To be continued...      --
---------------------------------------------------------------------------------

SELECT	SOD.SalesOrderID, 
		P.ProductID, 
		P.name
FROM	Sales.SalesOrderDetail AS SOD
		INNER JOIN
		Production.Product AS P
		ON SOD.ProductID = P.ProductID
GO

-------------------------------------------------------------------- Query #6b --
-- But if the OrderQty column is added to the SELECT list,                     --
-- the query is no longer covered by the non-clustered index.                  --
-- That means that now MERGE will require a lot of table lookups,              --
-- if used in the same manner as in Query  #6a.                                --
-- --> What will the optimizer do?                                             --
---------------------------------------------------------------------------------

SELECT	SOD.SalesOrderID, 
		P.ProductID, 
		P.name,
		SOD.OrderQty
FROM	Sales.SalesOrderDetail AS SOD
		INNER JOIN
		Production.Product AS P
		ON SOD.ProductID = P.ProductID
GO 

-------------------------------------------------------------------- Query #6c --
-- Introducing a filter makes one of the inputs small enough.                  --
-- And again, this causes a choice of an alternative plan ...                  --
---------------------------------------------------------------------------------

SELECT	SOD.SalesOrderID, 
		P.ProductID, 
		P.name,
		SOD.OrderQty
FROM	Sales.SalesOrderDetail AS SOD
		INNER JOIN
		Production.Product AS P
		ON SOD.ProductID = P.ProductID
WHERE	SOD.OrderQty > 38
GO

--------------------------------------------------------------------- Query #7 --
-- MERGE is so efficient, that many times you will see the optimizer           --
-- sort the inputs, just for the sake of using MERGE join.                     --
-- And if you can 'Kill two birds with one stone'...                           --
-- What is better than sorting for MERGE, when the sorting is required anyway? --
---------------------------------------------------------------------------------

SELECT	SOD.SalesOrderID, 
		P.ProductID, 
		P.ListPrice,
		SOD.UnitPrice,
		SOD.OrderQty
FROM	Sales.SalesOrderDetail AS SOD
		INNER JOIN
		Production.Product AS P
		ON SOD.UnitPrice = P.Listprice
WHERE	SOD.OrderQty > 5
ORDER BY P.ListPrice DESC
GO

---------------------------------------------------------------------------------
-- See many-to-many MERGE and residual predicate examples in appendix 1 ---------
---------------------------------------------------------------------------------
GO
---------------------------------------------------------------------------------
-- HASH MATCH -------------------------------------------------------------------
---------------------------------------------------------------------------------
GO
--------------------------------------------------------------------- Query #8 --
-- Simple 'no-brainer' example:                                                --
-- Very large inputs - both 'red' and 'blue' are approx. 120K rows.            --
-- Although both inputs are properly indexed (and even covering both ways),    --
-- nested loops will require too many iterations to be effective.              --
----> Look closely at the selected indexes, What is ProductID doing here?      --
---------------------------------------------------------------------------------

SELECT	SOD.SalesOrderID, 
		TH.TRansactionID
FROM	Sales.SalesOrderDetail AS SOD
		INNER JOIN
		Production.TransactionHistory AS TH
		ON SOD.SalesOrderID = TH.ReferenceOrderID
GO

-------------------------------------------------------------------- Query #9a --
-- Even if we have one large input and one small one:                          --
-- Products is ~500 rows, Sales Order Detail is ~120,000 rows.                 --
-- However, the indexes do not cover the query,                                --
-- making the cost of lookups way too expensive for using nested loops.        --
---------------------------------------------------------------------------------

SELECT	SOD.SalesOrderID, 
		P.Name,
		SOD.OrderQty
FROM	Production.Product AS P
		INNER JOIN
		Sales.SalesOrderDetail AS SOD
		ON P.ProductID = SOD.ProductID
GO

-------------------------------------------------------------------- Query #9b --
-- But what happens if you remove the OrderQty column from the select list?    --
---------------------------------------------------------------------------------

SELECT	SOD.SalesOrderID, 
		P.Name 
FROM	Production.Product AS P
		INNER JOIN
		Sales.SalesOrderDetail AS SOD
		ON P.ProductID = SOD.ProductID
GO

-------------------------------------------------------------------------------
-------------------------------------------------------------------------------
---->                            -- END OF DEMO CODE --                   <----
-------------------------------------------------------------------------------
-------------------------------------------------------------------------------

-------------------------------------------------------------------------------
-- APPENDIX 1 - Additional code examples --------------------------------------
-------------------------------------------------------------------------------

-------------------------------------------------------------------------------
-- Index spool using self non-equi join and nested loops.                    --
-------------------------------------------------------------------------------

SELECT	ProductID,
		SalesOrderID
FROM	Sales.SalesOrderDetail AS SOD
WHERE	OrderQty >	(
						SELECT	AVG(OrderQty)
						FROM	Sales.SalesOrderDetail AS SOD2
						WHERE	SOD.ProductID = SOD2.ProductID
								AND
								SOD.SalesOrderID < SOD2.SalesOrderID
					)
		AND	ProductID = 870
GO

-------------------------------------------------------------------------------
-- Listen to the missing index recommendations (well, in most cases...)      --
-------------------------------------------------------------------------------

CREATE NONCLUSTERED INDEX IDX1
ON [Sales].[SalesOrderDetail] ([ProductID])
INCLUDE ([SalesOrderID],[OrderQty])
GO

SELECT	ProductID,
		SalesOrderID
FROM	Sales.SalesOrderDetail AS SOD
WHERE	OrderQty >	(
						SELECT	AVG(OrderQty)
						FROM	Sales.SalesOrderDetail AS SOD2
						WHERE	SOD.ProductID = SOD2.ProductID
								AND
								SOD.SalesOrderID < SOD2.SalesOrderID
					)
		AND	ProductID = 870
GO

DROP INDEX [Sales].[SalesOrderDetail].IDX1
GO

---------------------------------------------------------------------------------
-- Here is Query 4 set up to force each of the three possible join operators.  --
-- Execute each and use profiler to benchmark their performance.               --
-- Prove that the optimizer did not make the optimal choice in this case.      --
---------------------------------------------------------------------------------

DBCC FREEPROCCACHE		-- Flush the plan cache
DBCC DROPCLEANBUFFERS	-- Flush the buffer cache
GO

SELECT	SOD.SalesOrderID, 
		P.Name, 
		SOD.OrderQty
FROM	Production.Product AS P
		INNER LOOP JOIN          -- Force NESTED LOOPS (not required, default choice)
		Sales.SalesOrderDetail AS SOD
		ON P.ProductID = SOD.ProductID
WHERE	P.DaysToManufacture > 2
		AND
		ListPrice > 1350
		AND
		StandardCost > 750
OPTION(MAXDOP 1) -- Avoid potential parallelism differences
GO
---------------------------------------------------------------------------------
DBCC FREEPROCCACHE		-- Flush the plan cache
DBCC DROPCLEANBUFFERS	-- Flush the buffer cache
GO

SELECT	SOD.SalesOrderID, 
		P.Name, 
		SOD.OrderQty
FROM	Production.Product AS P
		INNER HASH JOIN          -- Force HASH MATCH join ---------
		Sales.SalesOrderDetail AS SOD
		ON P.ProductID = SOD.ProductID
WHERE	P.DaysToManufacture > 2
		AND
		ListPrice > 1350
		AND
		StandardCost > 750
OPTION (MAXDOP 1) -- Avoid potential parallelism differences
GO
---------------------------------------------------------------------------------
DBCC FREEPROCCACHE		-- Flush the plan cache
DBCC DROPCLEANBUFFERS	-- Flush the buffer cache   
GO

SELECT	SOD.SalesOrderID, 
		P.Name, 
		SOD.OrderQty
FROM	Production.Product AS P
		INNER MERGE JOIN          -- Force MERGE join -------------
		Sales.SalesOrderDetail AS SOD
		ON P.ProductID = SOD.ProductID
WHERE	P.DaysToManufacture > 2
		AND
		ListPrice > 1350
		AND
		StandardCost > 750
OPTION (MAXDOP 1) -- Avoid potential parallelism differences
GO

---------------------------------------------------------------------------------
-- Similar to #5a, but note the different join condition... (and an ORDER BY)  --
-- This makes it a many-to-many join.                                          --
-- --> Remember that duplicates will require a temporary worktable.            --
---------------------------------------------------------------------------------

SET STATISTICS IO ON
GO

SELECT	*
FROM	Sales.SalesOrderHeader AS SOH
		INNER JOIN
		Sales.SalesOrderDetail AS SOD
		ON	SOH.ModifiedDate = SOD.ModifiedDate
ORDER BY SOH.ModifiedDate DESC
GO

SET STATISTICS IO OFF
GO

---------------------------------------------------------------------------------
-- Similar to query #5a, but with an added join predicate.                     --
-- Note that the 'residual' property contains both the merged columns,         --
-- and the residual columns.                                                   --
-- The 'Where (Join Column)' property contains just the merged ones.           --
---------------------------------------------------------------------------------

SELECT	*
FROM	Sales.SalesOrderHeader AS SOH
		INNER JOIN
		Sales.SalesOrderDetail AS SOD
		ON	SOH.SalesOrderID = SOD.SalesOrderID
			AND
			SOH.SubTotal > SOD.LineTotal
GO

---------------------------------------------------------------------------------
/*...............................................................................
.................................................................................
.................................................................................
.................ZMMMMMMMNMMMMNM.8MMMM...MMM7O...MMM8ODMMMM?:....................
..................M=~ .MMO...MM...MM8= . MMMM....MMMM...+M$......................
...................~...MMO.... ...MMO=.. MMMM....MMMM...8.:......................
.......................MMO........MMO=...MMMM....MMMM::MN........................
.......................MMO.. ...MMMMMMMMMMMMM..MNMMMDDDMN........................
.......................MMO..... M.MM8~~~.MMMM... MMMM   D........................
.......................MMO........MMO=.. MMMM....MMMM............................
.......................MMO........MMO=.. MMMM....MMMM... MMM.....................
......................MMMMM .....MMMMM..:MMMM ..MMMMMMMMMMMMM ...................
.....................,MMMMMM.....MMMMMM.MMMMMM..MMMMMMMMMMMMMN...................
.................................................................................
.................................................................................
.................................................................................
.................................................................................
.............................. .. .....  ..... ....... ..........................
...................MMMMMMMMMMM....MMMM.M..MMM~O.ZMMMMMMMM  ......................
....................MMMM. ,MM::...=MMM~....M~,.. MMMM.7NMMN8.....................
....................MMMM..  .$ ...=MMMMM...MN....MMMM...,MMOO....................
....................MMMM  MM......=MMNMMM .MM....MMMM....MMMM....................
..................MMMMMMMMMM......=MM.MMMN.MM....MMMM....MMMM....................
..................M.MMMM..OM......=MM..MM..MM....MMMM... MMMM....................
....................MMMM..... ....=MM...MM:MM....MMMM....MMMM....................
....................MMMM... MNM...$MM...NMMMM....MMMM.. MMMD.....................
...................:MMMM=OMMMM?M .MM8 ...MMMM....MMMM DMMNM,.....................
................................N?????M...??N..+?????+ZMM= ......................
.................................................................................
.................................................................................
...............................................................................*/
---------------------------------------------------------------------------------