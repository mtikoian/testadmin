---------------------
-- Ami Levin, 2010 --
-------------------------------------------------------------------------------
-- PHYSICAL JOIN OPERATORS ARTICLE - DEMO CODE --------------------------------
-------------------------------------------------------------------------------
-- ** Use SQL Server 2005 SP3 ** ----------------------------------------------
-------------------------------------------------------------------------------
-- AdventureWorks DB can be downloaded from:  ---------------------------------
-- http://msftdbprodsamples.codeplex.com/releases/view/4004#DownloadId=11754 --
-------------------------------------------------------------------------------

USE AdventureWorks;
GO

-------------------------------------------------------------------------------
                                   -- NESTED LOOPS --
-------------------------------------------------------------------------------
SET STATISTICS IO ON
GO

--                                                                    Query  #1
-- Simple case:
-- Smallest possible 'blue input' (1 row, filtered by PK).
-- 'Red input' ideally indexed.
SELECT	SOD.SalesOrderID,	
		P.Name
FROM	Production.Product AS P
		INNER JOIN
		Sales.SalesOrderDetail AS SOD
		ON P.ProductID	= SOD.ProductID
WHERE	P.ProductID	= 870
GO


--                                                                    Query  #2
-- When the 'blue input' is so small,
-- even if the 'red input' requires additional columns (OrderQty)
-- It's very efficient even to scan the 'red input' - just once...
SELECT	SOD.SalesOrderID,
		P.Name,
		SOD.OrderQty
FROM	Production.Product AS P
		INNER JOIN
		Sales.SalesOrderDetail AS SOD
		ON P.ProductID = SOD.ProductID
WHERE	P.ProductID = 870
GO


	--                                                                Query  #2b
	-- But what if more than one scan is required?
	SELECT	SOD.SalesOrderID,
			P.Name,
			SOD.OrderQty
	FROM	Production.Product AS P
			INNER JOIN
			Sales.SalesOrderDetail AS SOD
			ON P.ProductID = SOD.ProductID
	WHERE	P.ProductID IN (870,871)
--   OPTION (LOOP JOIN)
	GO


--                                                                    Query  #3
-- Or perform an additional lookup operator if the 'blue input' is a bit larger,
-- but still not too many lookups are required (or at least so estimated...)
--show actual/estimated rows
SELECT	SOD.SalesOrderID,
		P.Name,
		SOD.OrderQty
FROM	Production.Product AS P
		INNER JOIN
		Sales.SalesOrderDetail AS SOD
		ON P.ProductID = SOD.ProductID
WHERE	P.ProductID IN (897,942,943)
GO


--                                                                    Query  #4
-- An example of a Query that can trick the optimizer into 
-- choosing a sub-optimal plan.
--show actual/estimated rows - this is reason get suboptimal plan!
SELECT	SOD.SalesOrderID, 
		P.Name, 
		SOD.OrderQty
FROM	Production.Product AS P
		INNER JOIN
		Sales.SalesOrderDetail AS SOD
		ON P.ProductID = SOD.ProductID
WHERE	P.DaysToManufacture > 2
		AND
		ListPrice > 1350
		AND
		StandardCost > 750
GO

-- Here is Query 4 set up to force each of the three possible join operators.
-- Execute each and use profiler to benchmark their performance.
-- You can see that the optimizer did not make the best choice in this case.

	--                                                                 Query  #4b
	DBCC FREEPROCCACHE		-- Flush the plan cache
	GO

	SELECT	SOD.SalesOrderID, 
			P.Name, 
			SOD.OrderQty
	FROM	Production.Product AS P
			INNER LOOP JOIN          -- Force NESTED LOOPS (not required)
			Sales.SalesOrderDetail AS SOD
			ON P.ProductID = SOD.ProductID
	WHERE	P.DaysToManufacture > 2
			AND
			ListPrice > 1350
			AND
			StandardCost > 750
	OPTION(MAXDOP 1) -- Avoid potential parallelism differences
	GO


	--                                                                 Query  #4c
	DBCC FREEPROCCACHE		-- Flush the plan cache
	GO

	SELECT	SOD.SalesOrderID, 
			P.Name, 
			SOD.OrderQty
	FROM	Production.Product AS P
			INNER HASH JOIN          -- Force HASH MATCH join ---------
			Sales.SalesOrderDetail AS SOD
			ON P.ProductID = SOD.ProductID
	WHERE	P.DaysToManufacture > 2
			AND
			ListPrice > 1350
			AND
			StandardCost > 750
	OPTION (MAXDOP 1) -- Avoid potential parallelism differences
	GO


	--                                                                 Query  #4d
	DBCC FREEPROCCACHE		-- Flush the plan cache
	GO

	SELECT	SOD.SalesOrderID, 
			P.Name, 
			SOD.OrderQty
	FROM	Production.Product AS P
			INNER MERGE JOIN          -- Force MERGE join -------------
			Sales.SalesOrderDetail AS SOD
			ON P.ProductID = SOD.ProductID
	WHERE	P.DaysToManufacture > 2
			AND
			ListPrice > 1350
			AND
			StandardCost > 750
	OPTION (MAXDOP 1) -- Avoid potential parallelism differences
	GO

-------------------------------------------------------------------------------
                                    -- MERGE JOINS --
-------------------------------------------------------------------------------

--                                                                    Query  #5
-- Simple case:
-- Obviously the most efficient operator when both inputs are already sorted,
-- either via the clustered index (which covers all columns)...
SELECT	DueDate --only 1 column to minimize amount of data returned to client
FROM	Sales.SalesOrderHeader AS SOH
		INNER JOIN
		Sales.SalesOrderDetail AS SOD
		ON SOH.SalesOrderID = SOD.SalesOrderID
GO


--                                                                    Query  #6
-- ...or via nonclustered indexes on the join column,
-- especially if they cover the query.
SELECT	SOD.SalesOrderID, 
		P.ProductID, 
		P.Name
FROM	Sales.SalesOrderDetail AS SOD
		INNER JOIN
		Production.Product AS P
		ON SOD.ProductID = P.ProductID
GO


	--                                                                 Query #6b
	-- But if a column such as SOD.OrderQty is added to the SELECT list,
	-- the query is not covered by the index data, and MERGE will require 
	-- a lot of table lookups.
	-- Now the optimizer reverts to the alternative hash match operator.
	SELECT	SOD.SalesOrderID, 
			P.ProductID, 
			P.Name,
			SOD.OrderQty
	FROM	Sales.SalesOrderDetail AS SOD
			INNER JOIN
			Production.Product AS P
			ON SOD.ProductID = P.ProductID
--   OPTION (MERGE JOIN)
	GO 


	--                                                                 Query #6c
	-- But once one of the inputs is small enough, due to the additional filter,
	-- the choice of alternative changes again to nested loops.
	SELECT	SOD.SalesOrderID, 
			P.ProductID, 
			P.Name,
			SOD.OrderQty
	FROM	Sales.SalesOrderDetail AS SOD
			INNER JOIN
			Production.Product AS P
			ON SOD.ProductID = P.ProductID
	WHERE	SOD.OrderQty > 38
	GO 


--                                                                    Query #7
-- MERGE it's so efficient that many times you will see that the optimizer 
-- sorts the input, just for using MERGE join.
-- And if you can 'Kill two birds with one stone'...
-- What could be better than sorting for MERGE when the sorting is required anyway?
-- NOTE that there is no final sort for output, because MERGE join is Order Preserving Operator

SELECT	SOD.SalesOrderID, 
		P.ProductID, 
		P.ListPrice,
		SOD.UnitPrice,
		SOD.OrderQty
FROM	Sales.SalesOrderDetail AS SOD
		INNER JOIN
		Production.Product AS P
		ON SOD.UnitPrice = P.ListPrice
WHERE SOD.SalesOrderID BETWEEN 40000 AND 45000
ORDER BY P.ListPrice DESC
GO

-------------------------------------------------------------------------------
                                   -- HASH JOINS --
-------------------------------------------------------------------------------

--                                                                    Query  #8
-- Simple case:
-- Very large inputs - both ~120,000 rows.
-- Although both inputs are properly indexed and covering,
-- Nested loops will require too many iterations 
SELECT SOD.SalesOrderID, 
		 TH.TransactionID
FROM	Sales.SalesOrderDetail AS SOD
		INNER JOIN
		Production.TransactionHistory AS TH
		ON SOD.SalesOrderID = TH.ReferenceOrderID
GO

--                                                                    Query  #9
-- Both inputs are not small enough for nested loops:
-- P ~500 rows, SOD ~120,000 rows, 
-- The indexes do not cover the query, 
-- making the cost of lookups too expensive
-- note read difference if force loop joins, and cost of Key Lookups
SELECT	SOD.SalesOrderID, 
		P.Name, 
		P.Color, 
		SOD.OrderQty
FROM	Production.Product AS P
		INNER JOIN
		Sales.SalesOrderDetail AS SOD
		ON P.ProductID = SOD.ProductID
--OPTION (LOOP JOIN)
GO

	--                                                                 Query #9b
	-- But what happens if you remove the OrderQty column 
	-- from the select list?
	SELECT	SOD.SalesOrderID, 
			P.Name, 
			P.Color
	FROM	Production.Product AS P
			INNER JOIN
			Sales.SalesOrderDetail AS SOD
			ON P.ProductID = SOD.ProductID
	GO


-------------------------------------------------------------------------------
                                 -- END OF DEMO CODE --
-------------------------------------------------------------------------------