USE AdventureWorks ;
go
--DBCC DROPCLEANBUFFERS 
--GO


--********************************************************
--** Copy PO Detail table - Random order
--********************************************************

IF OBJECT_ID('[TempDB]..[#Temp]') IS NOT NULL 
    DROP TABLE [#Temp] ;

SELECT  *
INTO    #Temp
FROM    Purchasing.PurchaseOrderDetail
ORDER BY NEWID() ; --Random order
--(8845 row(s) affected)

SELECT TOP 100 *
FROM    #Temp ;
go
--********************************************************
--** Turn On Stats, Include Execution Plan (Ctrl+M)
--********************************************************
SET STATISTICS IO ON
SET STATISTICS TIME ON 

--********************************************************
--** SCENARIO 2: Indexed tables (pseudo sorted)
--********************************************************

SELECT  poh.PurchaseOrderID,
        poh.OrderDate,
        pod.ProductID,
        pod.DueDate,
        poh.VendorID
FROM    Purchasing.PurchaseOrderHeader AS poh
        INNER LOOP  JOIN #Temp AS pod ON poh.PurchaseOrderID = pod.PurchaseOrderID ;

SELECT  poh.PurchaseOrderID,
        poh.OrderDate,
        pod.ProductID,
        pod.DueDate,
        poh.VendorID
FROM    Purchasing.PurchaseOrderHeader AS poh
        INNER HASH  JOIN #Temp AS pod ON poh.PurchaseOrderID = pod.PurchaseOrderID ;


SELECT  poh.PurchaseOrderID,
        poh.OrderDate,
        pod.ProductID,
        pod.DueDate,
        poh.VendorID
FROM    Purchasing.PurchaseOrderHeader AS poh
        INNER MERGE JOIN #Temp AS pod ON poh.PurchaseOrderID = pod.PurchaseOrderID ;



go


