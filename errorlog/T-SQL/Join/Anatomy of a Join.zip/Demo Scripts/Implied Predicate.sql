
USE AdventureWorks ;
GO
--DBCC DROPCLEANBUFFERS 
--GO

SET STATISTICS IO ON
SET STATISTICS TIME ON 

--********************************************************
--**Same query with an implied predicate hash and merge trigger
--**a query optimizer error
--Msg 8622, Level 16, State 1, Line 2
--Query processor could not produce a query plan because of the hints defined in this query. Resubmit the query without specifying any hints and without using SET FORCEPLAN.
--********************************************************

PRINT 'Nested Loops ------------------------------------------------------'
SELECT  poh.PurchaseOrderID,
        poh.OrderDate,
        pod.ProductID,
        pod.DueDate,
        poh.VendorID
FROM    Purchasing.PurchaseOrderHeader AS poh
        INNER LOOP  JOIN Purchasing.PurchaseOrderDetail AS pod ON poh.PurchaseOrderID = pod.PurchaseOrderID
WHERE   poh.PurchaseOrderID = 1 ;

PRINT 'Hash Join ---------------------------------------------------------'
SELECT  poh.PurchaseOrderID,
        poh.OrderDate,
        pod.ProductID,
        pod.DueDate,
        poh.VendorID
FROM    Purchasing.PurchaseOrderHeader AS poh
        INNER HASH  JOIN Purchasing.PurchaseOrderDetail AS pod ON poh.PurchaseOrderID = pod.PurchaseOrderID
WHERE   poh.PurchaseOrderID = 1 ;

PRINT 'Merge Join --------------------------------------------------------'
SELECT  poh.PurchaseOrderID,
        poh.OrderDate,
        pod.ProductID,
        pod.DueDate,
        poh.VendorID
FROM    Purchasing.PurchaseOrderHeader AS poh
        INNER MERGE JOIN Purchasing.PurchaseOrderDetail AS pod ON poh.PurchaseOrderID = pod.PurchaseOrderID
WHERE   poh.PurchaseOrderID = 1 ;
        
        
go         

--http://blogs.msdn.com/b/craigfr/archive/2009/04/28/implied-predicates-and-query-hints.aspx

