
USE AdventureWorks ;
GO
--DBCC DROPCLEANBUFFERS 
--GO

SET STATISTICS IO ON
SET STATISTICS TIME ON 

--********************************************************
--** SCENARIO 1: Indexed tables (pseudo sorted)
--********************************************************

PRINT 'Nested Loops ------------------------------------------------------'
SELECT  poh.PurchaseOrderID,
        poh.OrderDate,
        pod.ProductID,
        pod.DueDate,
        poh.VendorID
FROM    Purchasing.PurchaseOrderHeader AS poh
        INNER LOOP  JOIN Purchasing.PurchaseOrderDetail AS pod ON poh.PurchaseOrderID = pod.PurchaseOrderID ;

PRINT 'Hash Join ---------------------------------------------------------'
SELECT  poh.PurchaseOrderID,
        poh.OrderDate,
        pod.ProductID,
        pod.DueDate,
        poh.VendorID
FROM    Purchasing.PurchaseOrderHeader AS poh
        INNER HASH  JOIN Purchasing.PurchaseOrderDetail AS pod ON poh.PurchaseOrderID = pod.PurchaseOrderID ;

PRINT 'Merge Join --------------------------------------------------------'
SELECT  poh.PurchaseOrderID,
        poh.OrderDate,
        pod.ProductID,
        pod.DueDate,
        poh.VendorID
FROM    Purchasing.PurchaseOrderHeader AS poh
        INNER MERGE JOIN Purchasing.PurchaseOrderDetail AS pod ON poh.PurchaseOrderID = pod.PurchaseOrderID ;
        
go         


--SELECT  poh.PurchaseOrderID,
--        poh.OrderDate,
--        pod.ProductID,
--        pod.DueDate,
--        poh.VendorID
--FROM    Purchasing.PurchaseOrderHeader AS poh
--         JOIN Purchasing.PurchaseOrderDetail AS pod ON poh.PurchaseOrderID = pod.PurchaseOrderID ;
