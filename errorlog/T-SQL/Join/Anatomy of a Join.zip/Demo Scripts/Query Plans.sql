--List queries from plan cache

SELECT TOP 100
        cacheobjtype,
        objtype,
        p.size_in_bytes,
        LEFT([sql].[text], 100) AS [text],
        plan_handle
FROM    sys.dm_exec_cached_plans p
        CROSS  APPLY sys.dm_exec_sql_text(p.plan_handle) sql
ORDER BY usecounts DESC 
        
GO        

--List all queries containing %Purchasing.PurchaseOrderHeader% with XML query plan

SELECT  LEFT([sql].[text], 200) AS [text]
        ,*
FROM    sys.dm_exec_query_stats q
        CROSS  APPLY sys.dm_exec_sql_text(q.plan_handle) sql
         CROSS APPLY sys.dm_exec_query_plan(q.plan_handle) pl
WHERE   [sql].[text] LIKE '%Purchasing.PurchaseOrderHeader%'


GO
