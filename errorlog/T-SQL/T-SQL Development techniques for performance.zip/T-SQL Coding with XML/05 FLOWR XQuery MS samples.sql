--http://msdn.microsoft.com/en-us/library/ms345122(SQL.90).aspx
-- Thank you Microsoft

SELECT Resume.query('
   declare namespace RES="http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/Resume";
   for $EMP in /RES:Resume/RES:Employment
   return
     <Employer Organization = "{ $EMP/RES:Emp.OrgName }" >
      { $EMP/RES:Emp.StartDate }
      { $EMP/RES:Emp.EndDate }
      { $EMP/RES:Emp.JobTitle }
     </Employer>
') as Result
FROM [HumanResources].[JobCandidate]
WHERE JobCandidateID = 3



SELECT Resume.query('
   declare namespace RES="http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/Resume";
   for $EMP in /RES:Resume/RES:Employment
   return
     element Employer
     {
      attribute Organization { $EMP/RES:Emp.OrgName },
      element StartDate { string($EMP/RES:Emp.StartDate) },
      element EndDate { string($EMP/RES:Emp.EndDate) },
      element JobTitle { string($EMP/RES:Emp.JobTitle) }
     }
') as Result
FROM [HumanResources].[JobCandidate]
WHERE JobCandidateID = 3





SELECT Resume.query('
   declare namespace RES="http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/Resume";
   for $ED in /RES:Resume/RES:Education
   where xs:decimal( data($ED/RES:Edu.GPA) ) gt 3.5 
   return 
     element Education
     {
      element Level { data($ED/RES:Edu.Level) },
      element Degree { data($ED/RES:Edu.Degree) },
      element GPA { data($ED/RES:Edu.GPA) },
      element GPAScale { data($ED/RES:Edu.GPAScale) }
     }
') as Result
FROM [HumanResources].[JobCandidate]
WHERE JobCandidateID = 2
