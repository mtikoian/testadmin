--http://www.sqlserverandxml.com/2008/06/xquery-lab-2-example-using-outer-apply.html
-- Jacob Sebastian

DECLARE @x XML
SELECT @x = '
<Pupils>
  <Pupil>
    <PupilIdentifiers>
      <PupilID>12345</PupilID>
      <Surname>BOB</Surname>
      <Forename>HOPE</Forename>
      <Gender>M</Gender>
      <DOB>1997-02-18</DOB>
    </PupilIdentifiers>
    <Attendance>
      <TermlyAttendance>
        <SessionsPossible>96</SessionsPossible>
        <SessionDetails>
          <SessionDetail>
            <AttendanceReason>I</AttendanceReason>
            <AbsenceSessions>6</AbsenceSessions>
          </SessionDetail>
          <SessionDetail>
            <AttendanceReason>M</AttendanceReason>
            <AbsenceSessions>1</AbsenceSessions>
          </SessionDetail>
        </SessionDetails>
      </TermlyAttendance>
    </Attendance>
  </Pupil>
  <Pupil>
    <PupilIdentifiers>
      <PupilID>87389373</PupilID>
      <Surname>Shaun</Surname>
      <Forename>Allcock</Forename>
      <Gender>M</Gender>
      <DOB>1997-02-18</DOB>
    </PupilIdentifiers>
    <Attendance>
      <TermlyAttendance>
        <SessionsPossible>109</SessionsPossible>
      </TermlyAttendance>
    </Attendance>
  </Pupil>
  <Pupil>
    <PupilIdentifiers>
      <PupilID>1234eqwe5</PupilID>
      <Surname>BOBBY</Surname>
      <Forename>HOPE</Forename>
      <Gender>M</Gender>
      <DOB>1997-02-18</DOB>
    </PupilIdentifiers>
    <Attendance>
      <TermlyAttendance>
        <SessionsPossible>89</SessionsPossible>
        <SessionDetails>
          <SessionDetail>
            <AttendanceReason>S</AttendanceReason>
            <AbsenceSessions>60</AbsenceSessions>
          </SessionDetail>
          <SessionDetail>
            <AttendanceReason>X</AttendanceReason>
            <AbsenceSessions>30</AbsenceSessions>
          </SessionDetail>
        </SessionDetails>
      </TermlyAttendance>
    </Attendance>
  </Pupil>
</Pupils>'

SELECT
    Pupil.value('PupilID[1]' ,'varchar(15)') as UPN,
    Pupil.value('Surname[1]' ,'varchar(10)') as Surname,
    Pupil.value('Forename[1]' ,'varchar(10)') as Forename,
    att.value('SessionsPossible[1]' ,'int') as SessionsPossible,
    det.value('AttendanceReason[1]' ,'varchar(5)') as AttendanceReason,
    det.value('AbsenceSessions[1]' ,'varchar(5)') as AttendanceSessions
FROM 
@x.nodes('//Pupils/Pupil/PupilIdentifiers') Pupils(Pupil)
OUTER APPLY Pupil.nodes('../Attendance/TermlyAttendance') Term(att)
OUTER APPLY att.nodes('SessionDetails/SessionDetail') Sess(det)
