DECLARE @XML	XML


--Get xml data to use as list
SET @XML = (
	SELECT 
		  PC.LastName
	FROM 
		Person.Contact PC
	WHERE
		PC.FirstName LIKE 'Di%'
	FOR XML RAW,TYPE
	)
	
	
SELECT @XML.query('data(row/@LastName)')	

SELECT REPLACE(@XML.query('data(row/@LastName)').value('.','varchar(max)'),' ',',')	

