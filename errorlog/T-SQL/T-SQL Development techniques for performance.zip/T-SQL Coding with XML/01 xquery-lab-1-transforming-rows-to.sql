--http://www.sqlserverandxml.com/2008/06/xquery-lab-1-transforming-rows-to.html
-- Jacob Sebastian

DECLARE @x XML
SELECT @x = '
<QUOTE configID="arbu05_0X4fe77d8454141612">
  <CSTICS>
    <ORDER_CFGS_VALUE>
      <Field Name="CONFIG_ID" Value="arbu05_0X4fe77d8454141612" />
      <Field Name="INST_ID" Value="2" />
      <Field Name="CHARC" Value="A7J_ID_CONFIG" />
      <Field Name="VALUE" Value="0" />
    </ORDER_CFGS_VALUE>
    <ORDER_CFGS_VALUE>
      <Field Name="CONFIG_ID" Value="arbu05_0X4fe77d8454141612" />
      <Field Name="INST_ID" Value="2" />
      <Field Name="CHARC" Value="A7J_ID_ELECTRICAL" />
      <Field Name="VALUE" Value="0" />
    </ORDER_CFGS_VALUE>
  </CSTICS>
</QUOTE>'

--SELECT @x

SELECT	c.query('*') AS ColData
FROM @x.nodes('/') t(c)


SELECT	x.query('*')
FROM @x.nodes('/QUOTE') d(x)


SELECT	x.query('*') AS ColData
FROM @x.nodes('/QUOTE/CSTICS') d(x)


SELECT	x.query('*') AS ColData
, x.value('(Field[@Name="VALUE"]/@Value)[1]','INT') AS VALUE 
FROM @x.nodes('/QUOTE/CSTICS/ORDER_CFGS_VALUE') d(x)


SELECT	x.query('*') AS ColData
FROM @x.nodes('/QUOTE/CSTICS/ORDER_CFGS_VALUE/Field') d(x)


SELECT 
    x.value('(Field[@Name="CONFIG_ID"]/@Value)[1]','VARCHAR(20)') AS CONFIG_ID,
    x.value('(Field[@Name="INST_ID"]/@Value)[1]','INT') AS INST_ID,
    x.value('(Field[@Name="CHARC"]/@Value)[1]','VARCHAR(20)') AS CHARC,
    x.value('(Field[@Name="VALUE"]/@Value)[1]','INT') AS VALUE
FROM @x.nodes('/QUOTE/CSTICS/ORDER_CFGS_VALUE') d(x)




