IF OBJECT_ID('tempdb..#EmployeeToLoad') IS NOT NULL 
    DROP TABLE #EmployeeToLoad
GO

IF OBJECT_ID('tempdb..#LookupValidation') IS NOT NULL 
    DROP TABLE #LookupValidation
GO

IF OBJECT_ID('tempdb..#GroupTypeLookupValidation') IS NOT NULL 
    DROP TABLE #GroupTypeLookupValidation
GO





DECLARE @ID_Exec_Log		UNIQUEIDENTIFIER
DECLARE @CreateBy						nvarchar(50)

DECLARE @EmployeeXML		XML
DECLARE @IsEmployeeNumberUnique	int

DECLARE @IsDetailedLoggingEnabled		SmallINT --= 1
DECLARE @XMLResultsOut	XML
DECLARE @StatusMessageXML	XML
DECLARE @ErrorMsg			nvarchar(1024) --= NULL OUTPUT




SET @IsEmployeeNumberUnique = 0


SET NOCOUNT ON



SET @EmployeeXML = '<Employees>
<Employee ID="C848A8F2-5D9B-41BC-9B84-042EDC81E2D2"  EmployeeSSN="001-22-3344" EmployeeNumber="016495" ID_Client="10086"   ClientCode="SlateQ">
    <Name>
      <Salutation ID_lu_Salutation="2"></Salutation>
      <First>Fred</First>
      <Middle>R</Middle>
      <Last>Flintstone</Last>
    </Name>
    <Gender ID_lu_Gender="2">Dude</Gender>
    <DOB>1957-05-16T00:00:00</DOB>
    <Language ID_lu_Language="1">EN</Language>
    <Disability ID_lu_Disability="0" />
    <IsSmoker>0</IsSmoker>
    <LoginName>FredF@Slate.com</LoginName>
    <Addresses>
      <Address Use="Home4" DateStart="1900-01-01T00:00:00">
        <AddressLine1>123 Stone Dr.</AddressLine1>
        <City>Bedrock</City>
        <State>PA</State>
        <ZipCode>00001</ZipCode>
        <Country>United States</Country>
      </Address>
      <Address Use="Work4" DateStart="1900-01-01T00:00:00">
        <AddressLine1>1 Quary Dr</AddressLine1>
        <City>My City</City>
        <State>PA</State>
        <ZipCode>71111</ZipCode>
        <Country>United States</Country>
      </Address>
    </Addresses>
    <Phones>
      <Phone Use="Home5" DateStart="1900-01-01T00:00:00">
        <AreaCode>333</AreaCode>
        <PhoneNumber>1112244</PhoneNumber>
      </Phone>
    </Phones>
    <EmailAddresses>
      <EmailAddress Use="Work" DateStart="1900-01-01T00:00:00">FredF@Slate.com</EmailAddress>
    </EmailAddresses>
    <GroupTypes>
      <GroupType ID_lu_Group_Type_Type="3" IsValuePK="1">11612</GroupType>
    </GroupTypes>
    <Jobs>
      <Job>
        <EmployeeType ID_lu_Employee_Type="2">W-2</EmployeeType>
        <Occupation >Dino-Crane Opperator</Occupation>
        <Client_Site ID_Client_Site="22835">CHQ</Client_Site>
        <JobTitle JobCode="MT/FT-B">MT Full-Time Full Benefits</JobTitle>
        <ERClass ID_lu_Class="455" />
        <BenefitClass ID_lu_Benefit_Class="7527" />
        <DateHired>2006-11-15T00:00:00</DateHired>
        <StartDate>2006-11-15T00:00:00</StartDate>
        <Salary>
          <FrequencyOut ID_lu_Pay_Period="3">Semi-Monthly</FrequencyOut>
          <FrequencyIn ID_lu_Pay_Period_Hour="1">Annual</FrequencyIn>
          <Rate>20800.0000</Rate>
        </Salary>
      </Job>
    </Jobs>
  </Employee> 
  <Employee ID="CCE8A4A0-1D8A-47BD-865C-82E1A6A86BF0"  EmployeeSSN="999-80-4402" EmployeeNumber="345432" ID_Client="10086" ClientCode="SlateQ">
    <Name>
      <First>Barney</First>
      <Middle>t</Middle>
      <Last>Rubble</Last>
    </Name>
    <Gender ID_lu_Gender="7"></Gender>
	<Marital_Status>Widowed</Marital_Status>
    <DOB>1952-10-11T00:00:00</DOB>
    <Language ID_lu_Language="1">EN</Language>
    <Disability ID_lu_Disability="1" />
    <IsSmoker>0</IsSmoker>
    <LoginName>BarneyR@Slate.com</LoginName>
    <Addresses>
      <Address Use="Home" DateStart="1900-01-01T00:00:00">
        <AddressLine1>122 Stone Dr</AddressLine1>
        <City>Bedrock</City>
        <State>PA</State>
        <ZipCode>00001</ZipCode>
        <Country>United States</Country>
      </Address>
      <Address Use="Work" DateStart="1900-01-01T00:00:00">
        <AddressLine1>1500 Walnut st</AddressLine1>
        <City>Phileadelphia</City>
        <State>PA</State>
        <ZipCode>19102</ZipCode>
        <Country>United States</Country>
      </Address>
    </Addresses>
    <Phones>
      <Phone Use="Home" DateStart="1900-01-01T00:00:00">
        <AreaCode>331</AreaCode>
        <PhoneNumber>2314556</PhoneNumber>
      </Phone>
      <Phone Use="Work" DateStart="1900-01-01T00:00:00">
        <AreaCode>215</AreaCode>
        <PhoneNumber>555-1212</PhoneNumber>
      </Phone>
    </Phones>
    <EmailAddresses>
      <EmailAddress Use="Work35" DateStart="1900-01-01T00:00:00">newlogin@we-enroll.com</EmailAddress>
    </EmailAddresses>
    <GroupTypes>
      <GroupType ID_lu_Group_Type_Type="3" IsValuePK="1">11612</GroupType>
      <GroupType ID_lu_Group_Type_Type="2" IsValuePK="0">10</GroupType>
    </GroupTypes>
    <Jobs>
      <Job>
        <EmployeeType ID_lu_Employee_Type="2">W-2</EmployeeType>
        <Occupation ID_lu_Occupation="121"></Occupation>
        <Client_Site ID_Client_Site="22835">CHQ</Client_Site>
        <JobTitle JobCode="">MT Full-Time Full Benefits</JobTitle>
        <ERClass ID_lu_Class="455" />
        <BenefitClass ID_lu_Benefit_Class="15132" />
        <DateHired>2006-11-06T00:00:00</DateHired>
        <StartDate>2006-11-06T00:00:00</StartDate>
        <Salary>
          <FrequencyOut ID_lu_Pay_Period="3">Semi-Monthly</FrequencyOut>
          <FrequencyIn ID_lu_Pay_Period_Hour="1">Annual</FrequencyIn>
          <Rate>20800.0000</Rate>
        </Salary>
      </Job>
    </Jobs>
  </Employee>
</Employees>'


SELECT @EmployeeXML

---------------------------------------
-- Working Variables
DECLARE @ReturnValue		int
DECLARE @RowCount			int

SET @ReturnValue = 0
SET @RowCount = 0



---------------------------------------
-- Process Variables
DECLARE @ID_Exec_Log_StatusMessage	uniqueidentifier
DECLARE @ProcessingStepName		nvarchar(128)
DECLARE @ProcessingStepVersion	nvarchar(50)
DECLARE @CreateDate				datetime
DECLARE @TouchDate				datetime
DECLARE @TouchBy				nvarchar(50)
DECLARE @IsMarkedForPurge		bit	
DECLARE @LogDate				DATETIME 
DECLARE @LogDate_End			DATETIME 
DECLARE @StatusMsg				nvarchar(1024)
DECLARE @CodePhase				nvarchar(128)
DECLARE @CodePhase_Step			nvarchar(128)
DECLARE @CodePhaseID			nvarchar(10)




--SET fixed values
SET @CreateDate = GETDATE()
SET @TouchDate = @CreateDate
SET @TouchBy = @CreateBy
SET @IsMarkedForPurge = 0 



DECLARE @ID_Client			int
DECLARE @ClientCode			nvarchar(35)



--DECLARE @StatusMessageXML	XML -- moved to parameter
DECLARE @ValidationMessage	Varchar(1000)
DECLARE @TimeStamp			VARCHAR(30)
DECLARE @MessageSource		VARCHAR(128)
DECLARE @MessageType			VARCHAR(30)


SET @StatusMessageXML = '<StatusMessages></StatusMessages>'
SET @MessageSource = @ProcessingStepName



-------------------------------------------------------------------------------
-------------------------------------------------------------------------------
-- Create Local Working Tables 
-------------------------------------------------------------------------------
-------------------------------------------------------------------------------
-- DROP TABLE #EmployeeToLoad
CREATE TABLE #EmployeeToLoad	(
--DECLARE @EmployeeToLoad	TABLE(
	  row_num			int			NOT NULL IDENTITY(1,1)
	, RefID				varchar(36)	NULL
	, ID_Client			int			NULL
	, ClientCode		varchar(35) NULL
	, ID_Employee		int			NULL
	, SSN				varchar(11)	NULL
	, EmployeeNumber	varchar(25) NULL
	, ID_lu_Person_Type	int			NOT NULL
	, ID_lu_Salutation	int			NULL
	, NameSalutation	varchar(15) NULL
	, NameFirst			varchar(20) NULL
	, NameMiddle		varchar(15) NULL
	, NameLast			varchar(25) NULL
	, NameSuffix		varchar(15) NULL
	, ID_lu_Gender		int			NULL
	, Gender			varchar(35) NULL
	, DOB				DateTime	NULL
	, ID_lu_Marital_Status int		NULL
	, Marital_Status	varchar(35) NULL
	, ID_lu_Disability	int			NULL
	, Disability		varchar(35) NULL
	, ID_lu_Language	int			NULL
	, [Language]		varchar(35)	NULL 
	, IsSmoker			bit			NULL
	, LoginName			varchar(65)	NULL
	, PayrollNumber		varchar(25) NULL
	, IsExistingEmployee	int DEFAULT(0)
	, IsValid			int DEFAULT(1)
	, StatusMessage		xml DEFAULT('<StatusMessages></StatusMessages>')
)


DECLARE @AddressToLoad	TABLE(
	  row_num			int			NOT NULL IDENTITY(1,1)
	, RefID				varchar(36)	NULL
	, ID_Person_Address	int NULL
	, ID_lu_ContactInfo_Location_Type_Address	int NULL
	, [Use]				varchar(35)	NULL
	, DateStart			datetime NULL
	, AddressLine1		Varchar(40) NULL
	, AddressLine2		Varchar(40) NULL
	, AddressLine3		Varchar(40) NULL
	, City				Varchar(20) NULL
	, State				Varchar(25) NULL
	, ZipCode			Varchar(10) NULL
	, Country			Varchar(65) NULL
	, IsValid			int DEFAULT(1)
	, StatusMessage		xml DEFAULT('<StatusMessages></StatusMessages>')
	, ID_ContactInfo_X_Person_Address int NULL
	, RowReference		varchar(36) DEFAULT( newid() )
	)



DECLARE @PhoneToLoad	TABLE(
	  row_num			int			NOT NULL IDENTITY(1,1)
	, RefID				varchar(36)	NULL
	, ID_Person_Phone	int NULL
	, ID_lu_ContactInfo_Location_Type_Phone	int NULL
	, [Use]				varchar(35)	NULL
	, DateStart			datetime	NULL
	, AreaCode			Varchar(3)	NULL
	, PhoneNumber		Varchar(25) NULL
	, Extension			Varchar(6)	NULL
	, IsValid			int DEFAULT(1)
	, StatusMessage		xml DEFAULT('<StatusMessages></StatusMessages>')
	, ID_ContactInfo_X_Person_Phone int NULL
	, RowReference		varchar(36) DEFAULT( newid() )
	)

DECLARE @EmailToLoad	TABLE(
	  row_num			int			NOT NULL IDENTITY(1,1)
	, RefID				varchar(36)	NULL
	, ID_Person_Email	int NULL
	, ID_lu_ContactInfo_Location_Type_Email	int NULL
	, [Use]				varchar(35)	NULL
	, DateStart			datetime	NULL
	, EmailAddress		Varchar(1024)	NULL
	, IsValid			int DEFAULT(1)
	, ID_ContactInfo_X_Person_Email int NULL
	, StatusMessage		xml DEFAULT('<StatusMessages></StatusMessages>')
	, RowReference		varchar(36) DEFAULT( newid() )
	)


DECLARE @GroupTypesToLoad	TABLE(
	  row_num				int			NOT NULL IDENTITY(1,1)
	, RefID					varchar(36)	NULL
	, ID_lu_Group_Type_Type	int			NULL
	, Group_Type_Type_Code	varchar(35)	NULL
	, IsValuePK				int			NULL
	, Group_Type_Value		Varchar(35)	NULL
	, RowReference		varchar(36) DEFAULT( newid() )
--	, ID_Client_Group_Type	int			NULL  --this is unknow comming in since the element value can be either the ID or the Code for CGT 
--	, IsValid				int					DEFAULT(1)
--	, StatusMessage			xml					DEFAULT('<StatusMessages></StatusMessages>')
	)

-- DROP TABLE #GroupTypeLookupValidation
CREATE TABLE #GroupTypeLookupValidation (
	  Row_Num					int IDENTITY(1,1) NOT NULL
	, RefID						UNIQUEIDENTIFIER  NOT NULL
	, ID_lu_Group_Type_Type		int				NULL
	, Group_Type_Type_Code		nvarchar(35)	NULL
	, ID_Client_Group_Type		int				NULL
	, Client_Group_Type_Code	nvarchar(35)	NULL
	, Group_Type_Value			Varchar(35)		NULL
	, IsValuePK					int				NULL
	, FoundCode					nvarchar(60)	NULL
	, ID_Client_Group_Type_X_Employee	int		NULL
	, CGTxE_ID_Client_Group_Type int			NULL
	, CGTxE_Client_Group_Type_Code	nvarchar(35)	NULL
	, ID_Employee				int				NULL
	, StatusMessage				xml DEFAULT ('<StatusMessages/>')
	, IsValid					int NOT NULL DEFAULT(1)
	, IsWarning					int NOT NULL DEFAULT(0)
	, IsError					int NOT NULL DEFAULT(0)
	, RowReference		varchar(36) DEFAULT( newid() )
)


DECLARE @JobsToLoad	TABLE(
	  row_num				int			NOT NULL IDENTITY(1,1)
	, RefID					varchar(36)	NULL
	, ID_lu_Employee_Type	int	NULL
	, EmployeeType			Varchar(35)	NULL
	, ID_lu_Occupation		int	NULL
	, Occupation			Varchar(35)	NULL
	, ID_Client_Site		int	NULL
	, Client_Site			Varchar(35)	NULL
	, JobCode				Varchar(35)	NULL
	, JobTitle				Varchar(65)	NULL
	, ID_lu_Class			int	NULL
	, ERClass				Varchar(35)	NULL
	, ID_lu_Benefit_Class	int	NULL
	, BenefitClass			Varchar(35)	NULL
	, DateHired				datetime	NULL
	, StartDate				datetime	NULL
	, DateEligibility		datetime	NULL
	, KitNumber				varchar(25)	NULL
	, ID_lu_Pay_Period		int	NULL
	, FrequencyOut			Varchar(35)	NULL
	, ID_lu_Pay_Period_Hour	int	NULL
	, FrequencyIn			Varchar(35)	NULL
	, Rate					money	NULL
	, ID_Client_Site_X_Employee	int NULL
	, ID_Employee_Job_History int NULL
	, IsValid			int DEFAULT(1)
	, StatusMessage		xml DEFAULT('<StatusMessages></StatusMessages>')
	, RowReference		varchar(36) DEFAULT( newid() )
	)

-- DROP TABLE #LookupValidation
CREATE TABLE #LookupValidation (
	  Row_Num	int IDENTITY(1,1) NOT NULL
	, RefID		UNIQUEIDENTIFIER  NOT NULL
	, ID		int	NULL
	, Code		nvarchar(60) NULL
	, FoundCode	nvarchar(60) NULL
	, StatusMessage	xml DEFAULT ('<StatusMessages/>')
	, IsValid	int  NOT NULL DEFAULT(1)
	, IsWarning	int NOT NULL DEFAULT(0)
	, IsError	int NOT NULL DEFAULT(0)
)	

DECLARE @OutputTable Table (
	  ID	int NOT NULL
	, RefID	UNIQUEIDENTIFIER
)
-------------------------------------------------------------------------------
-------------------------------------------------------------------------------
-- 1 Load Working Tables From XML
-------------------------------------------------------------------------------
-------------------------------------------------------------------------------
SET @CodePhase	 = 'Load Working Tables From XML'

BEGIN TRY 
	SET @CodePhaseID = '1.1'
	SET @CodePhase_Step = 'Employee Data'
	-----------------------------------------------------
	-- 1.1 Employee Data
	-----------------------------------------------------
	INSERT INTO #EmployeeToLoad(
		  RefID				
		, ID_Client	
		, ClientCode		
		, ID_Employee
		, SSN		
		, EmployeeNumber	
		, ID_lu_Person_Type	
		, ID_lu_Salutation	
		, NameSalutation	
		, NameFirst			
		, NameMiddle		
		, NameLast			
		, NameSuffix		
		, ID_lu_Gender		
		, Gender	
		, DOB		
		, ID_lu_Marital_Status
		, Marital_Status	
		, ID_lu_Disability	
		, Disability		
		, ID_lu_Language	
		, [Language]		
		, IsSmoker			
		, LoginName			
		, PayrollNumber		
	)
	SELECT 
		  EE.c1.value( '@ID', 'varchar(36)') AS RefID
		, EE.c1.value( '@ID_Client', 'int') AS ID_Client 
		, EE.c1.value( '@ClientCode', 'varchar(35)') AS ClientCode 
		, EE.c1.value( '@ID_Employee', 'int') AS ID_Employee 
		, EE.c1.value( '@EmployeeSSN', 'varchar(11)') AS SSN 
		, EE.c1.value( '@EmployeeNumber', 'varchar(25)') AS EmployeeNumber 
		, 4 AS ID_lu_Person_Type
		, EE.c1.value( 'Name[1]/Salutation[1]/@ID_lu_Salutation', 'int' ) AS ID_lu_Salutation
		, EE.c1.value( 'Name[1]/Salutation[1]', 'varchar(35)' ) AS NameSalutation
		, EE.c1.value( 'Name[1]/First[1]', 'varchar(20)' ) AS NameFirst
		, EE.c1.value( 'Name[1]/Middle[1]', 'varchar(15)' ) AS NameMiddle
		, EE.c1.value( 'Name[1]/Last[1]', 'varchar(25)' ) AS NameLast
		, EE.c1.value( 'Name[1]/Suffix[1]', 'varchar(15)' ) AS NameSuffix
		, EE.c1.value( 'Gender[1]/@ID_lu_Gender', 'int' ) AS ID_lu_Gender
		, EE.c1.value( 'Gender[1]', 'varchar(35)' ) AS Gender
		, CASE 
			WHEN ISDATE(EE.c1.value( 'DOB[1]', 'varchar(35)'))=1 THEN EE.c1.value( 'DOB[1]', 'varchar(35)')
			ELSE NULL
		  END AS DOB
		, EE.c1.value( 'Marital_Status[1]/@ID_lu_Marital_Status', 'int' ) AS ID_lu_Marital_Status
		, EE.c1.value( 'Marital_Status[1]', 'varchar(35)' ) AS Marital_Status
		, EE.c1.value( 'Disability[1]/@ID_lu_Disability', 'int' ) AS ID_lu_Disability
		, EE.c1.value( 'Disability[1]', 'varchar(35)' ) AS Disability
		, EE.c1.value( 'Language[1]/@ID_lu_Language', 'int' ) AS ID_lu_Language
		, EE.c1.value( 'Language[1]', 'varchar(35)' ) AS [Language]
		, EE.c1.value( 'IsSmoker[1]', 'bit' ) AS IsSmoker
		, EE.c1.value( 'LoginName[1]', 'varchar(65)' ) AS LoginName
		, EE.c1.value( 'PayrollNumber[1]', 'varchar(25)' ) AS PayrollNumber
	FROM
		@EmployeeXML.nodes ('Employees/Employee') AS EE(c1)


	SELECT @RowCount = @@ROWCOUNT
	SELECT @TimeStamp = CONVERT(VARCHAR(30), GETDATE(),121), @MessageType = 'Statistic'
		 , @ValidationMessage	= 'Number of records #EmployeeToLoad = ' + CAST(@RowCount AS VARCHAR(10))
	SET @StatusMessageXML.modify( 'insert <StatusMessage Timestamp="{sql:variable("@TimeStamp")}" MessageSource = "{sql:variable("@MessageSource")}" MessageType = "{sql:variable("@MessageType")}">{sql:variable("@ValidationMessage")}</StatusMessage> as last into (StatusMessages[1])')


	SET @CodePhaseID = '1.2'
	SET @CodePhase_Step = 'Addresses'
	-----------------------------------------------------
	-- 1.2 Addresses
	-----------------------------------------------------
	;
	WITH AddressesToSplit AS(
		SELECT 
			  EE.c1.value( '@ID', 'nvarchar(36)') AS RefID
	--		, EE.c1.value( '@ID_Client', 'int') AS ID_Client 
	--		, EE.c1.value( '@ClientCode', 'varchar(35)') AS ClientCode 
	--		, EE.c1.value( '@EmployeeSSN', 'varchar(11)') AS SSN 
	--		, EE.c1.value( '@EmployeeNumber', 'varchar(25)') AS EmployeeNumber 
			, EE.c1.query('Addresses[1]' ) AS Addresses
		FROM
			@EmployeeXML.nodes ('Employees/Employee') AS EE(c1)
	)
	INSERT INTO @AddressToLoad	(
		  RefID				
		, ID_lu_ContactInfo_Location_Type_Address
		, [Use]	
		, DateStart			
		, AddressLine1		
		, AddressLine2		
		, AddressLine3		
		, City				
		, State				
		, ZipCode			
		, Country			
		)
	SELECT
		  gt.RefID
	--	, gt.ID_Client
	--	, gt.ClientCode
	--	, gt.SSN
	--	, gt.EmployeeNumber
		, T.c1.value( '@ID_lu_ContactInfo_Location_Type_Address', 'int') AS ID_lu_ContactInfo_Location_Type_Address
		, T.c1.value( '@Use', 'varchar(25)' ) AS [Use]
		, T.c1.value( '@DateStart', 'datetime' ) AS DateStart
		, T.c1.value( 'AddressLine1[1]', 'Varchar(40)' ) AS AddressLine1
		, T.c1.value( 'AddressLine2[1]', 'Varchar(40)' ) AS AddressLine2
		, T.c1.value( 'AddressLine3[1]', 'Varchar(40)' ) AS AddressLine3

		, T.c1.value( 'City[1]', 'Varchar(20)' ) AS City
		, T.c1.value( 'State[1]', 'Varchar(25)' ) AS State
		, T.c1.value( 'ZipCode[1]', 'Varchar(10)' ) AS ZipCode
		, T.c1.value( 'Country[1]', 'Varchar(65)' ) AS Country

	FROM
		AddressesToSplit gt
			CROSS APPLY Addresses.nodes('Addresses/Address') AS T(c1)

	SELECT @RowCount = @@ROWCOUNT
	SELECT @TimeStamp = CONVERT(VARCHAR(30), GETDATE(),121), @MessageType = 'Statistic'
		 , @ValidationMessage	= 'Number of records @AddressToLoad = ' + CAST(@RowCount AS VARCHAR(10))
	SET @StatusMessageXML.modify( 'insert <StatusMessage Timestamp="{sql:variable("@TimeStamp")}" MessageSource = "{sql:variable("@MessageSource")}" MessageType = "{sql:variable("@MessageType")}">{sql:variable("@ValidationMessage")}</StatusMessage> as last into (StatusMessages[1])')

	SET @CodePhaseID = '1.3'
	SET @CodePhase_Step = 'Phones'
	-----------------------------------------------------
	-- 1.3 Phones
	-----------------------------------------------------
	;
	WITH PhonesToSplit AS(
		SELECT 
			  EE.c1.value( '@ID', 'nvarchar(36)') AS RefID
	--		, EE.c1.value( '@ID_Client', 'int') AS ID_Client 
	--		, EE.c1.value( '@ClientCode', 'varchar(35)') AS ClientCode 
	--		, EE.c1.value( '@EmployeeSSN', 'varchar(11)') AS SSN 
	--		, EE.c1.value( '@EmployeeNumber', 'varchar(25)') AS EmployeeNumber 
			, EE.c1.query('Phones[1]' ) AS Phones
		FROM
			@EmployeeXML.nodes ('Employees/Employee') AS EE(c1)
	)
	INSERT INTO @PhoneToLoad(
		  RefID			
		, ID_lu_ContactInfo_Location_Type_Phone	
		, [Use]				
		, DateStart			
		, AreaCode			
		, PhoneNumber		
		, Extension			
		)
	SELECT
		  gt.RefID
	--	, gt.ID_Client
	--	, gt.ClientCode
	--	, gt.SSN
	--	, gt.EmployeeNumber
		, T.c1.value( '@ID_lu_ContactInfo_Location_Type_Phone', 'int') AS ID_lu_ContactInfo_Location_Type_Phone
		, T.c1.value( '@Use', 'varchar(25)' ) AS [Use]
		, T.c1.value( '@DateStart', 'datetime' ) AS DateStart
		, T.c1.value( 'AreaCode[1]', 'varchar(3)' ) AS AreaCode
		, T.c1.value( 'PhoneNumber[1]', 'varchar(25)' ) AS PhoneNumber
		, T.c1.value( 'Extension[1]', 'varchar(6)' ) AS Extension
	FROM
		PhonesToSplit gt
			CROSS APPLY Phones.nodes('Phones/Phone') AS T(c1)

	SELECT @RowCount = @@ROWCOUNT
	SELECT @TimeStamp = CONVERT(VARCHAR(30), GETDATE(),121), @MessageType = 'Statistic'
		 , @ValidationMessage	= 'Number of records @PhoneToLoad = ' + CAST(@RowCount AS VARCHAR(10))
	SET @StatusMessageXML.modify( 'insert <StatusMessage Timestamp="{sql:variable("@TimeStamp")}" MessageSource = "{sql:variable("@MessageSource")}" MessageType = "{sql:variable("@MessageType")}">{sql:variable("@ValidationMessage")}</StatusMessage> as last into (StatusMessages[1])')


	SET @CodePhaseID = '1.4'
	SET @CodePhase_Step = 'Email Addresses'
	-----------------------------------------------------
	-- 1.4 Email Addresses
	-----------------------------------------------------
	;
	WITH EmailAddressesToSplit AS(
		SELECT 
			  EE.c1.value( '@ID', 'nvarchar(36)') AS RefID
	--		, EE.c1.value( '@ID_Client', 'int') AS ID_Client 
	--		, EE.c1.value( '@ClientCode', 'varchar(35)') AS ClientCode 
	--		, EE.c1.value( '@EmployeeSSN', 'varchar(11)') AS SSN 
	--		, EE.c1.value( '@EmployeeNumber', 'varchar(25)') AS EmployeeNumber 
			, EE.c1.query('EmailAddresses[1]' ) AS EmailAddresses
		FROM
			@EmployeeXML.nodes ('Employees/Employee') AS EE(c1)
	)
	INSERT INTO @EmailToLoad(
		  RefID				
		, ID_lu_ContactInfo_Location_Type_Email
		, [Use]				
		, DateStart			
		, EmailAddress		
		)
	SELECT
		  gt.RefID
	--	, gt.ID_Client
	--	, gt.ClientCode
	--	, gt.SSN
	--	, gt.EmployeeNumber
		, T.c1.value( '@ID_lu_ContactInfo_Location_Type_Email', 'int') AS ID_lu_ContactInfo_Location_Type_Email
		, T.c1.value( '@Use', 'varchar(25)' ) AS [Use]
		, T.c1.value( '@DateStart', 'datetime' ) AS DateStart
		, T.c1.value( '.', 'varchar(1024)' ) AS EmailAddress
	FROM
		EmailAddressesToSplit gt
			CROSS APPLY EmailAddresses.nodes('EmailAddresses/EmailAddress') AS T(c1)

	SELECT @RowCount = @@ROWCOUNT
	SELECT @TimeStamp = CONVERT(VARCHAR(30), GETDATE(),121), @MessageType = 'Statistic'
		 , @ValidationMessage	= 'Number of records @EmailToLoad = ' + CAST(@RowCount AS VARCHAR(10))
	SET @StatusMessageXML.modify( 'insert <StatusMessage Timestamp="{sql:variable("@TimeStamp")}" MessageSource = "{sql:variable("@MessageSource")}" MessageType = "{sql:variable("@MessageType")}">{sql:variable("@ValidationMessage")}</StatusMessage> as last into (StatusMessages[1])')


	SET @CodePhaseID = '1.5'
	SET @CodePhase_Step = 'GroupTypes'
	-----------------------------------------------------
	-- 1.5 GroupTypes
	-----------------------------------------------------
	;
	WITH GroupTypesToSplit AS(
		SELECT 
			  EE.c1.value( '@ID', 'nvarchar(36)') AS RefID
	--		, EE.c1.value( '@ID_Client', 'int') AS ID_Client 
	--		, EE.c1.value( '@ClientCode', 'varchar(35)') AS ClientCode 
	--		, EE.c1.value( '@EmployeeSSN', 'varchar(11)') AS SSN 
	--		, EE.c1.value( '@EmployeeNumber', 'varchar(25)') AS EmployeeNumber 
			, EE.c1.query('GroupTypes[1]' ) AS GroupTypes
		FROM
			@EmployeeXML.nodes ('Employees/Employee') AS EE(c1)
	)
	INSERT INTO @GroupTypesToLoad(
		  RefID					
		, ID_lu_Group_Type_Type	
		, Group_Type_Type_Code
		, IsValuePK				
		, Group_Type_Value		
		)
	SELECT
		  gt.RefID
	--	, gt.ID_Client
	--	, gt.ClientCode
	--	, gt.SSN
	--	, gt.EmployeeNumber
		, T.c1.value( '@ID_lu_Group_Type_Type', 'int' ) AS ID_lu_Group_Type_Type
		, T.c1.value('@Group_Type_Type_Code','varchar(35)')AS Group_Type_Type_Code
		, T.c1.value( '@IsValuePK', 'int' ) AS IsValuePK
		, T.c1.value( '.', 'varchar(35)' ) AS Group_Type_Value
	FROM
		GroupTypesToSplit gt
			CROSS APPLY GroupTypes.nodes('GroupTypes/GroupType') AS T(c1)

	SELECT @RowCount = @@ROWCOUNT
	SELECT @TimeStamp = CONVERT(VARCHAR(30), GETDATE(),121), @MessageType = 'Statistic'
		 , @ValidationMessage	= 'Number of records @GroupTypesToLoad = ' + CAST(@RowCount AS VARCHAR(10))
	SET @StatusMessageXML.modify( 'insert <StatusMessage Timestamp="{sql:variable("@TimeStamp")}" MessageSource = "{sql:variable("@MessageSource")}" MessageType = "{sql:variable("@MessageType")}">{sql:variable("@ValidationMessage")}</StatusMessage> as last into (StatusMessages[1])')

	SET @CodePhaseID = '1.6'
	SET @CodePhase_Step = 'Job data'
	-----------------------------------------------------
	-- 1.6 Job data (Aparently for new hire only one job is accepted)
	-----------------------------------------------------
	;
	WITH JobsToSplit AS(
		SELECT 
			  EE.c1.value( '@ID', 'nvarchar(36)') AS RefID
	--		, EE.c1.value( '@ID_Client', 'int') AS ID_Client 
	--		, EE.c1.value( '@ClientCode', 'varchar(35)') AS ClientCode 
	--		, EE.c1.value( '@EmployeeSSN', 'varchar(11)') AS SSN 
	--		, EE.c1.value( '@EmployeeNumber', 'varchar(25)') AS EmployeeNumber 
			, EE.c1.query('Jobs[1]' ) AS Jobs
		FROM
			@EmployeeXML.nodes ('Employees/Employee') AS EE(c1)
	)
	INSERT INTO @JobsToLoad(
		  RefID					
		, ID_lu_Employee_Type	
		, EmployeeType			
		, ID_lu_Occupation		
		, Occupation			
		, ID_Client_Site		
		, Client_Site			
		, JobCode				
		, JobTitle				
		, ID_lu_Class			
		, ERClass				
		, ID_lu_Benefit_Class	
		, BenefitClass			
		, DateHired				
		, StartDate	
		, DateEligibility		
		, KitNumber							
		, ID_lu_Pay_Period		
		, FrequencyOut			
		, ID_lu_Pay_Period_Hour	
		, FrequencyIn			
		, Rate					
		)
	SELECT
		  gt.RefID
	--	, gt.ID_Client
	--	, gt.ClientCode
	--	, gt.SSN
	--	, gt.EmployeeNumber

		, T.c1.value( 'EmployeeType[1]/@ID_lu_Employee_Type', 'int' ) AS ID_lu_Employee_Type
		, T.c1.value( 'EmployeeType[1]', 'varchar(35)' ) AS EmployeeType

		, T.c1.value( 'Occupation[1]/@ID_lu_Occupation', 'int' ) AS ID_lu_Occupation
		, T.c1.value( 'Occupation[1]', 'varchar(35)' ) AS Occupation

		, T.c1.value( 'Client_Site[1]/@ID_Client_Site', 'int' ) AS ID_Client_Site
		, T.c1.value( 'Client_Site[1]', 'varchar(35)' ) AS Client_Site

		, T.c1.value( 'JobTitle[1]/@JobCode', 'varchar(35)' ) AS JobCode
		, T.c1.value( 'JobTitle[1]', 'varchar(65)' ) AS JobTitle

		, T.c1.value( 'ERClass[1]/@ID_lu_Class', 'int' ) AS ID_lu_Class
		, T.c1.value( 'ERClass[1]', 'varchar(35)' ) AS ERClass

		, T.c1.value( 'BenefitClass[1]/@ID_lu_Benefit_Class', 'int' ) AS ID_lu_Benefit_Class
		, T.c1.value( 'BenefitClass[1]', 'varchar(35)' ) AS BenefitClass

		, T.c1.value( 'DateHired[1]', 'datetime' ) AS DateHired
		, T.c1.value( 'StartDate[1]', 'datetime' ) AS StartDate
		, T.c1.value( 'DateEligibility[1]', 'datetime' ) AS DateEligibility
		, T.c1.value( 'KitNumber[1]', 'varchar(25)' ) AS KitNumber

		, T.c1.value( 'Salary[1]/FrequencyOut[1]/@ID_lu_Pay_Period', 'int' ) AS ID_lu_Pay_Period
		, T.c1.value( 'Salary[1]/FrequencyOut[1]', 'varchar(35)' ) AS FrequencyOut

		, T.c1.value( 'Salary[1]/FrequencyIn[1]/@ID_lu_Pay_Period_Hour', 'int' ) AS ID_lu_Pay_Period_Hour
		, T.c1.value( 'Salary[1]/FrequencyIn[1]', 'varchar(35)' ) AS FrequencyIn

		, T.c1.value( 'Salary[1]/Rate[1]', 'money' ) AS Rate
	FROM
		JobsToSplit gt
			CROSS APPLY Jobs.nodes('Jobs/Job') AS T(c1)

	SELECT @RowCount = @@ROWCOUNT
	SELECT @TimeStamp = CONVERT(VARCHAR(30), GETDATE(),121), @MessageType = 'Statistic'
		 , @ValidationMessage	= 'Number of records @JobsToLoad = ' + CAST(@RowCount AS VARCHAR(10))
	SET @StatusMessageXML.modify( 'insert <StatusMessage Timestamp="{sql:variable("@TimeStamp")}" MessageSource = "{sql:variable("@MessageSource")}" MessageType = "{sql:variable("@MessageType")}">{sql:variable("@ValidationMessage")}</StatusMessage> as last into (StatusMessages[1])')
END TRY
BEGIN CATCH
	---------------------------------------
	-- An error has occured that is not handled elsewhere
	SET @ReturnValue = -1
    SET @ErrorMsg = 'ErrorNumber: ' + CONVERT(nvarchar(10), ISNULL(ERROR_NUMBER(),-1))+ '
ErrorSeverity: ' + CONVERT(nvarchar(10), ISNULL(ERROR_SEVERITY(),-1))+ '
ErrorState: ' + CONVERT(nvarchar(10), ISNULL(ERROR_STATE(),-1))+ '
ErrorProcedure: ' +  ISNULL(ERROR_PROCEDURE(), 'Unknown') + '
ErrorLine: ' + CONVERT(nvarchar(10), ISNULL(ERROR_LINE(),-1)) + '
ErrorMessage: ' + ISNULL(ERROR_MESSAGE(), 'Unknown') + '
CodePhaseID: ' + @CodePhaseID + ' 
CodePhase: ' + @CodePhase + ' 
CodePhase_Step: ' + @CodePhase_Step 


END CATCH



SELECT * FROM #EmployeeToLoad	
SELECT * FROM @AddressToLoad
SELECT * FROM @PhoneToLoad
SELECT * FROM @EmailToLoad
SELECT * FROM @GroupTypesToLoad
SELECT * FROM @JobsToLoad
SELECT @StatusMessageXML

