USE AdventureWorks
GO
-------------------------------------------------------------------------------
-------------------------------------------------------------------------------
-- FOR XML RAW
-------------------------------------------------------------------------------
-------------------------------------------------------------------------------
/* Books On Line:

The RAW mode generates a single <row> element per row in the rowset that is 
returned by the SELECT statement. You can generate XML hierarchy by writing 
nested FOR XML queries.

*/

-------------------------------------------------------------------------------
-- FOR XML RAW
-------------------------------------------------------------------------------
SELECT TOP 12
	  ContactID
	, NameStyle
	, Title
	, FirstName 
--	, FirstName AS [First Name] -- Look at the attribute name for columns that require brackets
	, MiddleName
	, LastName
	, Suffix
	, EmailAddress
	, EmailPromotion
	, Phone
	, PasswordHash
	, PasswordSalt
--	, AdditionalContactInfo -- See what happens when the field is of Type XML
	, rowguid
	, ModifiedDate
FROM
    Person.Contact
FOR XML RAW



-------------------------------------------------------------------------------
-- FOR XML RAW, ELEMENTS
-------------------------------------------------------------------------------
SELECT TOP 12
	  ContactID
	, NameStyle
	, Title
	, FirstName
	, MiddleName
	, LastName
	, Suffix
	, EmailAddress
	, EmailPromotion
	, Phone
	, PasswordHash
	, PasswordSalt
--	, AdditionalContactInfo
	, rowguid
	, ModifiedDate
FROM
    Person.Contact AS NoEffectAlais --This has no impact on the output
FOR XML RAW, ELEMENTS




-------------------------------------------------------------------------------
-- FOR XML RAW('{row Element Name}'), ELEMENTS w/ Column Alias
-------------------------------------------------------------------------------
SELECT TOP 12
	  ContactID
	, NameStyle
	, Title
	, FirstName
	, MiddleName
	, LastName
	, Suffix
	, EmailAddress
	, EmailPromotion
	, Phone
	, PasswordHash AS PWHash
	, PasswordSalt AS PWSalt
--	, AdditionalContactInfo
	, rowguid
	, ModifiedDate
FROM
    Person.Contact
FOR XML RAW('Person'), ELEMENTS 


-------------------------------------------------------------------------------
-- FOR XML RAW('{row Element Name}'), ELEMENTS w/ Column Alias & Root element
-------------------------------------------------------------------------------
SELECT TOP 12
	  PC.ContactID
	, PC.NameStyle
	, PC.Title
	, PC.FirstName
	, PC.MiddleName
	, PC.LastName
	, PC.Suffix
	, PC.EmailAddress
	, PC.EmailPromotion
	, PC.Phone
	, PC.PasswordHash AS PWHash
	, PC.PasswordSalt AS PWSalt
--	, PC.AdditionalContactInfo
	, PC.rowguid
	, PC.ModifiedDate
FROM
    Person.Contact PC
FOR XML RAW('Person'), ELEMENTS , ROOT('Persons')


-------------------------------------------------------------------------------
-- FOR XML RAW('{row Element Name}'), ELEMENTS w/ Column Alias & Root element
-- And XSINIL Keyword
-------------------------------------------------------------------------------
-- NOTE: This is the same as the prvious query with the XSINIL keyword in the FOR XML Clause
SELECT TOP 12
	  PC.ContactID
	, PC.NameStyle
	, PC.Title
	, PC.FirstName
	, PC.MiddleName --Look for the MiddleName element
	, PC.LastName
	, PC.Suffix		--Look for the Suffix element
	, PC.EmailAddress
	, PC.EmailPromotion
	, PC.Phone
	, PC.PasswordHash AS PWHash
	, PC.PasswordSalt AS PWSalt
--	, PC.AdditionalContactInfo
	, PC.rowguid
	, PC.ModifiedDate
FROM
    Person.Contact PC
FOR XML RAW('Person'), ELEMENTS XSINIL, ROOT('Persons')  
--                              ^^^^^^
--                              ||||||


-------------------------------------------------------------------------------
-- FOR XML RAW with Joined Tables 2NF
-------------------------------------------------------------------------------
SELECT TOP 12
	  PC.ContactID
	, PC.NameStyle
	, PC.Title
	, PC.FirstName
	, PC.MiddleName
	, PC.LastName
	, PC.Suffix
	, PC.EmailAddress
	, PC.EmailPromotion
	, PC.Phone
	, PC.PasswordHash AS PWHash
	, PC.PasswordSalt AS PWSalt
--	, PC.AdditionalContactInfo
	, PC.rowguid
	, PC.ModifiedDate
	, SOH.SalesOrderID
	, SOH.OrderDate
	, SOH.DueDate
	, SOH.ShipDate
	, SOH.Status
	, SOH.SalesOrderNumber
	, SOH.PurchaseOrderNumber
	, SOH.SubTotal
	, SOH.TaxAmt
	, SOH.Freight
	, SOH.TotalDue
FROM
    Person.Contact PC
		INNER JOIN 
	Sales.SalesOrderHeader SOH
		ON PC.ContactID = SOH.ContactID
ORDER BY
	PC.ContactID
FOR XML RAW('Person'), ELEMENTS , ROOT('Persons')


-------------------------------------------------------------------------------
-- FOR XML RAW with Correlated Subquery 3NF
-------------------------------------------------------------------------------
SELECT TOP 12
	  PC.ContactID
	, PC.NameStyle
	, PC.Title
	, PC.FirstName
	, PC.MiddleName
	, PC.LastName
	, PC.Suffix
	, PC.EmailAddress
	, PC.EmailPromotion
	, PC.Phone
	, PC.PasswordHash AS PWHash
	, PC.PasswordSalt AS PWSalt
--	, PC.AdditionalContactInfo
	, PC.rowguid
	, PC.ModifiedDate
	, 
--	  CAST( --<<<----------------<<<<<< Notice explicit cast
		(  
		SELECT
			  SOH.SalesOrderID
			, SOH.OrderDate
			, SOH.DueDate
			, SOH.ShipDate
			, SOH.Status
			, SOH.SalesOrderNumber
			, SOH.PurchaseOrderNumber
			, SOH.SubTotal
			, SOH.TaxAmt
			, SOH.Freight
			, SOH.TotalDue
		FROM
			Sales.SalesOrderHeader SOH
		WHERE
			SOH.ContactID = PC.ContactID
		ORDER BY
			SOH.OrderDate
		FOR XML RAW('Order'), ELEMENTS --, ROOT('Orders')	
		--See what happens with root tag (This is why XML Fragments are OK)
		) 
--		AS XML) --<<<----------------<<<<<< Notice explicit cast
		AS Orders
FROM
    Person.Contact PC
ORDER BY
	PC.ContactID
FOR XML RAW('Person'), ELEMENTS , ROOT('Persons')





-------------------------------------------------------------------------------
-------------------------------------------------------------------------------
-- FOR XML AUTO
-------------------------------------------------------------------------------
-------------------------------------------------------------------------------
/* Books On Line:

The AUTO mode generates nesting in the resulting XML by using heuristics based 
on the way the SELECT statement is specified. You have minimal control over the 
shape of the XML generated. The nested FOR XML queries can be written to generate 
XML hierarchy beyond the XML shape that is generated by AUTO mode heuristics.

*/


-------------------------------------------------------------------------------
-- FOR XML AUTO
-------------------------------------------------------------------------------
-- Note: run the next two queries to compare side by side
-- Note: Remove comment from table alias as an alternative
SELECT TOP 12
	  ContactID
	, NameStyle
	, Title
	, FirstName
	, MiddleName
	, LastName
	, Suffix
	, EmailAddress
	, EmailPromotion
	, Phone
	, PasswordHash
	, PasswordSalt
--	, AdditionalContactInfo
	, rowguid
	, ModifiedDate
FROM
    Person.Contact --AS Person --The Alias is honored in the element names
FOR   
    XML AUTO


-------------------------------------------------------------------------------
-- FOR XML AUTO ELEMENTS
-------------------------------------------------------------------------------
-- Note: run the next two queries to compare side by side -- will difference between AUTO & RAW
SELECT TOP 12
	  ContactID
	, NameStyle
	, Title
	, FirstName
	, MiddleName
	, LastName
	, Suffix
	, EmailAddress
	, EmailPromotion
	, Phone
	, PasswordHash
	, PasswordSalt
--	, AdditionalContactInfo
	, rowguid
	, ModifiedDate
FROM
    Person.Contact AS Person --The Alias is honored in the element names
FOR   
    XML AUTO, ELEMENTS
    

 --The next query is a repeat of an earlier for easy comparison 
			-------------------------------------------------------------------------------
			-- FOR XML RAW, ELEMENTS
			-------------------------------------------------------------------------------
			SELECT TOP 12
				  ContactID
				, NameStyle
				, Title
				, FirstName
				, MiddleName
				, LastName
				, Suffix
				, EmailAddress
				, EmailPromotion
				, Phone
				, PasswordHash
				, PasswordSalt
			--	, AdditionalContactInfo
				, rowguid
				, ModifiedDate
			FROM
				Person.Contact AS NoEffectAlais --This has no impact on the output
			FOR XML RAW, ELEMENTS  
  
  
-------------------------------------------------------------------------------
-- FOR XML Auto with Joined Tables 2NF (But not in the XML)
-------------------------------------------------------------------------------
SELECT TOP 12
	  PC.ContactID
	, PC.NameStyle
	, PC.Title
	, PC.FirstName
	, PC.MiddleName
	, PC.LastName
	, PC.Suffix
	, PC.EmailAddress
	, PC.EmailPromotion
	, PC.Phone
	, PC.PasswordHash AS PWHash
	, PC.PasswordSalt AS PWSalt
--	, PC.AdditionalContactInfo
	, PC.rowguid
	, PC.ModifiedDate
	, SOH.SalesOrderID
	, SOH.OrderDate
	, SOH.DueDate
	, SOH.ShipDate
	, SOH.Status
	, SOH.SalesOrderNumber
	, SOH.PurchaseOrderNumber
	, SOH.SubTotal
	, SOH.TaxAmt
	, SOH.Freight
	, SOH.TotalDue
FROM
    Person.Contact PC -- Notice Alias table name is honored
		INNER JOIN 
	Sales.SalesOrderHeader SOH-- Notice Alias table name is honored
		ON PC.ContactID = SOH.ContactID
ORDER BY
	PC.ContactID
FOR XML AUTO, ELEMENTS , ROOT('Persons')--Root keyword also works


		--The next query is a repeat of an earlier for easy comparison 

		-------------------------------------------------------------------------------
		-- FOR XML RAW with Correlated Subquery 3NF
		-------------------------------------------------------------------------------
		SELECT TOP 12
			  PC.ContactID
			, PC.NameStyle
			, PC.Title
			, PC.FirstName
			, PC.MiddleName
			, PC.LastName
			, PC.Suffix
			, PC.EmailAddress
			, PC.EmailPromotion
			, PC.Phone
			, PC.PasswordHash AS PWHash
			, PC.PasswordSalt AS PWSalt
		--	, PC.AdditionalContactInfo
			, PC.rowguid
			, PC.ModifiedDate
			, 
			  CAST( --<<<----------------<<<<<< Notice explicit cast
				(  
				SELECT
					  SOH.SalesOrderID
					, SOH.OrderDate
					, SOH.DueDate
					, SOH.ShipDate
					, SOH.Status
					, SOH.SalesOrderNumber
					, SOH.PurchaseOrderNumber
					, SOH.SubTotal
					, SOH.TaxAmt
					, SOH.Freight
					, SOH.TotalDue
				FROM
					Sales.SalesOrderHeader SOH
				WHERE
					SOH.ContactID = PC.ContactID
				ORDER BY
					SOH.OrderDate
				FOR XML RAW('Order'), ELEMENTS --, ROOT('Orders')	
				--See what happens with root tag (This is why XML Fragments are OK)
				) 
				AS XML) --<<<----------------<<<<<< Notice explicit cast
				AS Orders
		FROM
			Person.Contact PC
		ORDER BY
			PC.ContactID
		FOR XML RAW('Person'), ELEMENTS , ROOT('Persons')

    


-------------------------------------------------------------------------------
-------------------------------------------------------------------------------
-- FOR XML EXPLICIT
-------------------------------------------------------------------------------
-------------------------------------------------------------------------------
/* Books On Line:

The EXPLICIT mode allows more control over the shape of the XML. You can mix 
attributes and elements at will in deciding the shape of the XML. It requires a 
specific format for the resulting rowset that is generated because of query 
execution. This rowset format is then mapped into XML shape. The power of 
EXPLICIT mode is to mix attributes and elements at will, create wrappers and 
nested complex properties, create space-separated values (for example, OrderID 
attribute may have a list of order ID values), and mixed contents. 

However, writing EXPLICIT mode queries can be cumbersome. You can use some of 
the new FOR XML capabilities, such as writing nested FOR XML RAW/AUTO/PATH mode 
queries and the TYPE directive, instead of using EXPLICIT mode to generate the 
hierarchies. The nested FOR XML queries can produce any XML that you can generate 
by using the EXPLICIT mode. For more information, see Nested FOR XML Queries and 
TYPE Directive in FOR XML Queries.



 ElementName!TagNumber!AttributeName!Directive
*/

-------------------------------------------------------------------------------
-- FOR XML Explicit  --Simple fragment as attributes
-------------------------------------------------------------------------------
SELECT TOP 12
	  1						AS Tag
    , NULL					AS Parent
	, ContactID				AS [Preson!1!ContactID]
	, NameStyle				AS [Preson!1!NameStyle]
	, Title					AS [Preson!1!Title]
	, FirstName				AS [Preson!1!FirstName]
	, MiddleName			AS [Preson!1!MiddleName]
	, LastName				AS [Preson!1!LastName]
	, Suffix				AS [Preson!1!Suffix]
	, EmailAddress			AS [Preson!1!EmailAddress]
	, EmailPromotion		AS [Preson!1!EmailPromotion]
	, Phone					AS [Preson!1!Phone]
	, PasswordHash			AS [Preson!1!PWHash]
	, PasswordSalt			AS [Preson!1!PWSalt]
--	, AdditionalContactInfo	AS [Preson!1!NameStyle]  --XML Data type uncomment to see what happens(Not quite available in SQL 2K)
	, rowguid				AS [Preson!1!rowguid]
	, ModifiedDate			AS [Preson!1!ModifiedDate]
FROM
    Person.Contact AS ZZZWWWEEEK --The Alias is meaningless in Explicit queries
FOR   
    XML EXPLICIT
    


-------------------------------------------------------------------------------
-- FOR XML Explicit  --Simple fragment as Attributes and Elements
-------------------------------------------------------------------------------
SELECT TOP 12
	  1						AS Tag
    , NULL					AS Parent
	, ContactID				AS [Preson!1!ContactID]  --This will be an attribute
	, NameStyle				AS [Preson!1!NameStyle!ELEMENT]
	, Title					AS [Preson!1!Title!ELEMENT]
	, FirstName				AS [Preson!1!FirstName!ELEMENT]
	, MiddleName			AS [Preson!1!MiddleName!elementxsinil]--Empty element for nill
	, LastName				AS [Preson!1!LastName!ELEMENT]
	, Suffix				AS [Preson!1!Suffix!elementxsinil]--Empty element for nill
	, EmailAddress			AS [Preson!1!EmailAddress!ELEMENT]
	, EmailPromotion		AS [Preson!1!EmailPromotion!ELEMENT]
	, Phone					AS [Preson!1!Phone!ELEMENT]
	, PasswordHash			AS [Preson!1!PWHash!cdata] --Use of CDATA directive
	, PasswordSalt			AS [Preson!1!PWSalt!ELEMENT]
-- XML
--	, AdditionalContactInfo	AS [Preson!1!ContactInfo!XML]	--Check out the different handeling options with XML data
--	, AdditionalContactInfo	AS [Preson!1!!XML] 				--Notice the missing element name
-- XMLTEXT
--	, AdditionalContactInfo	AS [Preson!1!ContactInfo!xmltext]
--	, AdditionalContactInfo	AS [Preson!1!!xmltext]			--Notice the missing element name
	, rowguid				AS [Preson!1!rowguid]--This will be an attribute
	, ModifiedDate			AS [Preson!1!ModifiedDate]--This will be an attribute
FROM
    Person.Contact AS ZZZWWWEEEK ---The Alias is meaningless in Explicit queries
FOR   
    XML EXPLICIT


-------------------------------------------------------------------------------
-- FOR XML Explicit  --More complex example
-------------------------------------------------------------------------------
-- Field aliases in queries after the first unnion are just there for positional reference they are optional
-- NOTE: Uncomment all instances of ContactInfo to keep column count and alignment in place to add output elements & Attributes

SELECT TOP 12
	  1						AS Tag
    , NULL					AS Parent
    , ''					AS [Presons!1] --Force root element with no data
	, NULL					AS [Preson!2!ContactID]
	, NULL					AS [Preson!2!NameStyle!ELEMENT]
	, NULL					AS [Preson!2!Title!ELEMENT]
	, NULL					AS [Name!3!FirstName!ELEMENT]
	, NULL					AS [Name!3!MiddleName!elementxsinil]
	, NULL					AS [Name!3!LastName!ELEMENT]
	, NULL					AS [Name!3!Suffix!elementxsinil]
	, NULL					AS [Preson!2!EmailAddress!ELEMENT]
	, NULL					AS [Preson!2!EmailPromotion!ELEMENT]
	, NULL					AS [Preson!2!Phone!ELEMENT]
	, NULL					AS [Preson!2!PWHash!cdata]
	, NULL					AS [Preson!2!PWSalt!ELEMENT]
--	, NULL					AS [Preson!2!ContactInfo]
	, NULL					AS [Preson!2!rowguid]
	, NULL					AS [Preson!2!ModifiedDate]
UNION ALL
SELECT TOP 12
	  2						AS Tag
    , 1						AS Parent
    , NULL					AS [Presons!1] --Force root element with no data
	, ContactID				AS [Preson!2!ContactID]
	, NameStyle				AS [Preson!2!NameStyle!ELEMENT]
	, Title					AS [Preson!2!Title!ELEMENT]
	, FirstName				AS [Name!3!FirstName!ELEMENT]
	, MiddleName			AS [Name!3!MiddleName!elementxsinil]
	, LastName				AS [Name!3!LastName!ELEMENT]
	, Suffix				AS [Name!3!Suffix!elementxsinil]
	, EmailAddress			AS [Preson!2!EmailAddress!ELEMENT]
	, EmailPromotion		AS [Preson!2!EmailPromotion!ELEMENT]
	, Phone					AS [Preson!2!Phone!ELEMENT]
	, PasswordHash			AS [Preson!2!PWHash!cdata]
	, PasswordSalt			AS [Preson!2!PWSalt!ELEMENT]
--	, AdditionalContactInfo	AS [Preson!2!ContactInfo]
	, rowguid				AS [Preson!2!rowguid]
	, ModifiedDate			AS [Preson!2!ModifiedDate]
FROM
    Person.Contact AS Person --The Alias is honored in the element names
UNION ALL
SELECT TOP 12
	  3						AS Tag
    , 2						AS Parent
    , NULL					AS [Presons!1] --Force root element with no data
	, ContactID				AS [Preson!2!ContactID]
	, NULL					AS [Preson!2!NameStyle!ELEMENT]
	, NULL					AS [Preson!2!Title!ELEMENT]
	, FirstName				AS [Name!3!FirstName!ELEMENT]
	, MiddleName			AS [Name!3!MiddleName!elementxsinil]
	, LastName				AS [Name!3!LastName!ELEMENT]
	, Suffix				AS [Name!3!Suffix!elementxsinil]
	, NULL					AS [Preson!2!EmailAddress!ELEMENT]
	, NULL					AS [Preson!2!EmailPromotion!ELEMENT]
	, NULL					AS [Preson!2!Phone!ELEMENT]
	, NULL					AS [Preson!2!PWHash!cdata]
	, NULL					AS [Preson!2!PWSalt!ELEMENT]
--	, NULL					AS [Preson!2!ContactInfo]
	, NULL					AS [Preson!2!rowguid]
	, NULL					AS [Preson!2!ModifiedDate]
FROM
    Person.Contact AS Person --The Alias is honored in the element namesORDER BY
ORDER BY
	[Preson!2!ContactID], Parent, [Name!3!LastName!ELEMENT]
FOR   
    XML EXPLICIT


/*
Clearly EXPLICIT mode is a pain
	* Building slowly requires constant maintenance on all UNIONS
	* Adding plural grouping tags requires a lot of extra steps
	* Adding other elements that change the parent sequence can be a lot of work
	
Explicit FOR XML queries works in SQL 2000, 2005, and 2008

However, check output carefully when working with the same code in different 
versions and compatibility mode.  The results and specifics of formatting may 
change between versions and compatibility modes.

Sorry I don't have specifics but the only real problems experienced migrating 
from 2000 to 2005 was with explicit queries.  There were differences that 
threw off other code in the middle tier and in XSLT.  Changing compatibility 
mode in 2005 to 2000 caused additional problems.  It was easier to rewrite them
using the next technique.

*/






-------------------------------------------------------------------------------
-------------------------------------------------------------------------------
-- FOR XML PATH
-------------------------------------------------------------------------------
-------------------------------------------------------------------------------
/* Books On Line:

The PATH mode together with the nested FOR XML query capability provides the 
flexibility of the EXPLICIT mode in a simpler manner. 


*/


-------------------------------------------------------------------------------
-- FOR XML PATH  -- Simple Elements and Attributes
-------------------------------------------------------------------------------
SELECT TOP 12
	  ContactID		AS "@ID"
	, rowguid		AS "@rowguid"
	, ModifiedDate	AS "@ModifiedDate"
	, NameStyle		AS "Name/@Style"
	, Title			AS "Name/Title"
	, FirstName		AS "Name/First"
	, MiddleName	AS "Name/Middle"
	, LastName		AS "Name/Last"
	, Suffix		AS "Name/Suffix"
	, EmailPromotion AS "Contacts/Contact/Email/@Promotion"
	, EmailAddress	AS "Contacts/Contact/Email"
	, Phone			AS "Contacts/Contact/Phone"
	, PasswordHash  AS "PWHash"
--	, '<PWHash><![CDATA['+PasswordHash+']]><PWHash>'  AS "data()" --sorry this doesn't work'
	, PasswordSalt AS PWSalt
--	, AdditionalContactInfo  -- XML Types go right to he output
FROM
    Person.Contact
FOR XML PATH('Person'), ROOT('Persons')



-------------------------------------------------------------------------------
-- FOR XML PATH  -- 2NF join 2NF output
-------------------------------------------------------------------------------
-- NOTE: This is an example of what not to do
SELECT TOP 12
	  PC.ContactID		AS "@ID"
	, PC.rowguid		AS "@rowguid"
	, PC.ModifiedDate	AS "@ModifiedDate"
	, PC.NameStyle		AS "Name/@Style"
	, PC.Title			AS "Name/Title"
	, PC.FirstName		AS "Name/First"
	, PC.MiddleName	AS "Name/Middle"
	, PC.LastName		AS "Name/Last"
	, PC.Suffix		AS "Name/Suffix"
	, PC.EmailPromotion AS "Contacts/Contact/Email/@Promotion"
	, PC.EmailAddress	AS "Contacts/Contact/Email"
	, PC.Phone			AS "Contacts/Contact/Phone"
	, PC.PasswordHash  AS "PWHash"
	, PC.PasswordSalt AS PWSalt
--	, PC.AdditionalContactInfo  -- XML Types go right to he output
	, SOH.SalesOrderID	AS "SalesOrders/SalesOrder/@SalesOrderID"
	, SOH.OrderDate		AS "SalesOrders/SalesOrder/OrderDate"
	, SOH.DueDate		AS "SalesOrders/SalesOrder/DueDate"
	, SOH.ShipDate		AS "SalesOrders/SalesOrder/ShipDate"
	, SOH.Status		AS "SalesOrders/SalesOrder/Status"
	, SOH.SalesOrderNumber		AS "SalesOrders/SalesOrder/SalesOrderNumber"
	, SOH.PurchaseOrderNumber		AS "SalesOrders/SalesOrder/PurchaseOrderNumber"
	, SOH.SubTotal		AS "SalesOrders/SalesOrder/SubTotal"
	, SOH.TaxAmt		AS "SalesOrders/SalesOrder/TaxAmt"
	, SOH.Freight		AS "SalesOrders/SalesOrder/Freight"
	, SOH.TotalDue		AS "SalesOrders/SalesOrder/TotalDue"
FROM
    Person.Contact PC 
		INNER JOIN 
	Sales.SalesOrderHeader SOH
		ON PC.ContactID = SOH.ContactID
ORDER BY
	PC.ContactID
FOR XML PATH('Person'), ROOT('Persons')




-------------------------------------------------------------------------------
-- FOR XML PATH  -- 3NF via Correlated Subquery
-------------------------------------------------------------------------------
-- NOTE: This is an example of what not to do
SELECT TOP 12
	  PC.ContactID		AS "@ID"
	, PC.rowguid		AS "@rowguid"
	, PC.ModifiedDate	AS "@ModifiedDate"
	, PC.NameStyle		AS "Name/@Style"
	, PC.Title			AS "Name/Title"
	, PC.FirstName		AS "Name/First"
	, PC.MiddleName	AS "Name/Middle"
	, PC.LastName		AS "Name/Last"
	, PC.Suffix		AS "Name/Suffix"
	, PC.EmailPromotion AS "Contacts/Contact/Email/@Promotion"
	, PC.EmailAddress	AS "Contacts/Contact/Email"
	, PC.Phone			AS "Contacts/Contact/Phone"
	, PC.PasswordHash  AS "PWHash"
	, PC.PasswordSalt AS PWSalt
--	, PC.AdditionalContactInfo  -- XML Types go right to he output
	,  (
		SELECT
			  SOH.SalesOrderID	AS "@SalesOrderID"
			, SOH.OrderDate		AS "OrderDate"
			, SOH.DueDate		AS "DueDate"
			, SOH.ShipDate		AS "ShipDate"
			, SOH.Status		AS "Status"
			, SOH.SalesOrderNumber		AS "SalesOrderNumber"
			, SOH.PurchaseOrderNumber		AS "PurchaseOrderNumber"
			, SOH.SubTotal		AS "SubTotal"
			, SOH.TaxAmt		AS "TaxAmt"
			, SOH.Freight		AS "Freight"
			, SOH.TotalDue		AS "TotalDue"
		FROM
			Sales.SalesOrderHeader SOH
		WHERE
			SOH.ContactID = PC.ContactID
			
		FOR XML PATH('SalesOrder'), TYPE  --<<------ Notice the Type declaration
		) AS "SalesOrders"
		-- The next 2 lines have the same outcome as the previous
		--FOR XML PATH('SalesOrder'), ROOT('SalesOrders'), TYPE
		--) 

FROM
    Person.Contact PC 
ORDER BY
	PC.ContactID
FOR XML PATH('Person'), ROOT('Persons')




WITH XMLNAMESPACES (
   'http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/ProductModelDescription' AS PD,
   'http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/ProductModelWarrAndMain' AS wm)
SELECT TOP 12
	  ContactID		AS "@ID"
	, rowguid		AS "@rowguid"
	, ModifiedDate	AS "@ModifiedDate"
	, NameStyle		AS "Name/@Style"
	, Title			AS "Name/Title"
	, FirstName		AS "Name/First"
	, MiddleName	AS "Name/Middle"
	, LastName		AS "Name/Last"
	, Suffix		AS "Name/Suffix"
	, EmailPromotion AS "Contacts/Contact/Email/@Promotion"
	, EmailAddress	AS "Contacts/Contact/Email"
	, Phone			AS "Contacts/Contact/Phone"
	, PasswordHash  AS "PD:PWHash"
--	, '<PWHash><![CDATA['+PasswordHash+']]><PWHash>'  AS "data()" --sorry this doesn't work'
	, PasswordSalt AS PWSalt
--	, AdditionalContactInfo  -- XML Types go right to he output
FROM
    Person.Contact
FOR XML PATH('Person'), ROOT('Persons')

/*
-------------------------------------------------------------------------------
-- FOR XML PATH  -- 3NF via CTE
-------------------------------------------------------------------------------
-- NOTE: This is an example of what not to do
;
WITH 



SalesOrders AS (
(
		SELECT
			  SOH.SalesOrderID	AS "@SalesOrderID"
			, SOH.OrderDate		AS "OrderDate"
			, SOH.DueDate		AS "DueDate"
			, SOH.ShipDate		AS "ShipDate"
			, SOH.Status		AS "Status"
			, SOH.SalesOrderNumber		AS "SalesOrderNumber"
			, SOH.PurchaseOrderNumber		AS "PurchaseOrderNumber"
			, SOH.SubTotal		AS "SubTotal"
			, SOH.TaxAmt		AS "TaxAmt"
			, SOH.Freight		AS "Freight"
			, SOH.TotalDue		AS "TotalDue"
		FROM
			Person.Contact PC 
				INNER JOIN 
			Sales.SalesOrderHeader SOH
				ON PC.ContactID = SOH.ContactID
			
		FOR XML PATH('SalesOrder'), TYPE  --<<------ Notice the Type declaration
		) AS "SalesOrders"

)
SELECT TOP 12
	  PC.ContactID		AS "@ID"
	, PC.rowguid		AS "@rowguid"
	, PC.ModifiedDate	AS "@ModifiedDate"
	, PC.NameStyle		AS "Name/@Style"
	, PC.Title			AS "Name/Title"
	, PC.FirstName		AS "Name/First"
	, PC.MiddleName	AS "Name/Middle"
	, PC.LastName		AS "Name/Last"
	, PC.Suffix		AS "Name/Suffix"
	, PC.EmailPromotion AS "Contacts/Contact/Email/@Promotion"
	, PC.EmailAddress	AS "Contacts/Contact/Email"
	, PC.Phone			AS "Contacts/Contact/Phone"
	, PC.PasswordHash  AS "PWHash"
	, PC.PasswordSalt AS PWSalt
--	, PC.AdditionalContactInfo  -- XML Types go right to he output
	,  

FROM
    Person.Contact PC -- Notice Alias table name is honored
ORDER BY
	PC.ContactID
FOR XML PATH('Person'), ROOT('Persons')
*/
