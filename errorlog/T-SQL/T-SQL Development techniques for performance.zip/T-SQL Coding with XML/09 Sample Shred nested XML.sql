DECLARE @clientOptions	XML


--encoding="utf-16"
SET @clientOptions = '<?xml version="1.0"?>
<PlanGroup xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" PlanGroupID="4F33D118-7F76-4E47-8E4B-E7DB5EA8C53B" EligibilityDeterminedByPlanID="00000000-0000-0000-0000-000000000001">
	<Plans PlanMapID="23e28a36-0c37-489d-9345-9f02ea246fd6" PlanID="09734551-8585-47cb-a693-38d162c028de" DisplayOrder="0">
		<OptionalChildren IsValid="true" PlanMapID="1e02e312-e364-480f-b867-bc34f34dc47c" PlanID="b5a5d176-82d1-4313-b42e-0bd475b8182d" DisplayOrder="1" />
		<OptionalChildren IsValid="true" PlanMapID="afe39c36-6f11-436f-ab8a-56602890e092" PlanID="17e02338-f748-4d73-852b-2e12b681a67e" DisplayOrder="1000" />
		<OptionalChildren IsValid="true" PlanMapID="98455f32-bbab-42cd-ad5a-4095b4e618a1" PlanID="38d94688-6e35-4db0-b5d2-67e65ff44e70" DisplayOrder="50">
			<OptionalChildren IsValid="true" PlanMapID="7d3c12d2-a048-44c4-b766-db6f1b66f249" PlanID="b4c14bda-8dc2-4a83-b957-1851f1a8c193" DisplayOrder="100" />
			<OptionalChildren IsValid="true" PlanMapID="d47f66bb-67e3-4b98-9036-9da7bbaf8c21" PlanID="4f4a1059-20ca-4d7c-a4eb-a64f6d10532b" DisplayOrder="100" />
		</OptionalChildren>
		<RequiredChildren IsValid="true" PlanMapID="be00aafa-f755-4a66-8f86-28d8d64d6404" PlanID="f28cd8b6-8c58-4b8a-9ceb-ce7686d56db6" DisplayOrder="0" />
		<RequiredChildren IsValid="true" PlanMapID="98aefc87-9cea-48c4-b910-49873ed676c7" PlanID="2479649f-0735-4147-b138-f0d3c6227d45" DisplayOrder="10" />
		<RequiredChildren IsValid="true" PlanMapID="14f78930-49da-43d1-ae66-bf79568eeb51" PlanID="1c55857b-8e1b-4f1c-bf02-589a0820d753" DisplayOrder="20" />
		<ExcludedPlans IsValid="true" PlanMapID="d5aeeeea-9bfb-43a9-bb9a-42c8e3e20d59" PlanID="a1c26fc5-85be-4ffb-8e31-e192db98024a" DisplayOrder="0" />
	</Plans>
</PlanGroup>
'



SELECT  Options.OptionValue.value(N'@PlanID', 'uniqueidentifier') AS PlanID,
        Options.OptionValue.value(N'@DisplayOrder', 'int') AS DisplayOrder,
        Options.OptionValue.query(N'OptionalChildren') AS OptionalPlans
FROM    @clientOptions.nodes(N'PlanGroup/Plans') AS Options ( OptionValue )
	
;
WITH AllOptionPlans(PlanID, DisplayOrder, OptionalPlans, [Type]) AS (
	SELECT 
		  Options.OptionValue.value(N'@PlanID', 'uniqueidentifier') as PlanID
		, Options.OptionValue.value(N'@DisplayOrder', 'int') as DisplayOrder
		, Options.OptionValue.query(N'OptionalChildren') as OptionalPlans
		, 'Root' as [Type]
	FROM     
		@clientOptions.nodes(N'PlanGroup/Plans') as Options ( OptionValue )
)
, ChildPlans AS (
	SELECT 
		  AOP.PlanID
		, AOP.DisplayOrder
		, AOP.OptionalPlans
		, AOP.[Type]
		--  Options2.OptionValue.value(N'@PlanID', 'uniqueidentifier') as PlanID
		--, Options2.OptionValue.value(N'@DisplayOrder', 'int') as DisplayOrder
		--, Options2.OptionValue.query(N'OptionalChildren') as OptionalPlans
		--, 'Optional' AS [Type]
	FROM 
		--AllOptionPlans.OptionalPlans.nodes('OptionalChildren') as Options2(OptionValue) 	
		--	INNER JOIN 
		AllOptionPlans AOP
			CROSS APPLY
		AOP.OptionalPlans.nodes('OptionalChildren') as Options2(OptionValue)
		--	ON AllOptionPlans.PlanID = Options2.PlanID
)
SELECT * FROM 
	--AllOptionPlans	
	ChildPlans
	


;
WITH AllOptionPlans(PlanID, DisplayOrder, OptionalPlans, [Type]) AS (
	SELECT 
		  Options.OptionValue.value(N'@PlanID', 'uniqueidentifier') as PlanID
		, Options.OptionValue.value(N'@DisplayOrder', 'int') as DisplayOrder
		, Options.OptionValue.query(N'OptionalChildren') as OptionalPlans
		, CAST('Root' AS VARCHAR(20)) as [Type]
	FROM     
		@clientOptions.nodes(N'PlanGroup/Plans') as Options ( OptionValue )
	UNION ALL
	SELECT 
		  Options2.OptionValue.value(N'@PlanID', 'uniqueidentifier') as PlanID
		, Options2.OptionValue.value(N'@DisplayOrder', 'int') as DisplayOrder
		, Options2.OptionValue.query(N'OptionalChildren') as OptionalPlans
		, CAST('Optional' AS VARCHAR(20)) AS [Type]
	FROM 
		AllOptionPlans AOP
			CROSS APPLY
		AOP.OptionalPlans.nodes('OptionalChildren') as Options2(OptionValue)
)
SELECT * FROM 
	AllOptionPlans	



--;
--WITH AllOptionPlans(PlanID, DisplayOrder, OptionalPlans, [Type]) AS (
--	SELECT 
--		  Options.OptionValue.value(N'@PlanID', 'uniqueidentifier') as PlanID
--		, Options.OptionValue.value(N'@DisplayOrder', 'int') as DisplayOrder
--		, Options.OptionValue.query(N'OptionalChildren') as OptionalPlans
--		, 'Root' as [Type]
--	FROM     
--		@clientOptions.nodes(N'PlanGroup/Plans') as Options ( OptionValue )
--	UNION 
--	SELECT 
--		  Options2.OptionValue.value(N'@PlanID', 'uniqueidentifier') as PlanID
--		, Options2.OptionValue.value(N'@DisplayOrder', 'int') as DisplayOrder
--		, Options2.OptionValue.query(N'OptionalChildren') as OptionalPlans
--		, 'Optional' AS [Type]
--	FROM 
--		AllOptionPlans.OptionalPlans.nodes('OptionalChildren') as Options2(OptionValue) 	
--		--	INNER JOIN 
--		--AllOptionPlans
--		--	ON AllOptionPlans.PlanID = Options2.PlanID
--)
--SELECT * FROM 
--	AllOptionPlans				
				
				
	

/*
 PlanID
, DisplayOrder
, ParentPlanID
, Type (Required, Optional, Excluded - they can be put in as literals based on the path)
*/

