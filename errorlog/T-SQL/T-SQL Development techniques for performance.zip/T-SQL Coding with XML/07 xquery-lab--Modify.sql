/*
Note: these example are of XML type variables thes example will also wokr in
T-sql update statements on XML columns.

TO use data from a column in the query instead of or in addtion to a variable 
use the {sql:column("columnName")} syntax
*/

-------------------------------------------------------------------------------
--  Insert Element
-------------------------------------------------------------------------------
-- http://www.sqlserverandxml.com/2008/07/xquery-lab-11-how-to-insert-element-to.html
-- Jacob Sebastian
DECLARE @x XML
SELECT @x = '
<Employee>
    <FirstName>Jacob</FirstName>
</Employee>'

DECLARE @LastName VARCHAR(15)
SELECT @LastName = 'Sebastian'

SELECT @x

-- insert an element -- last
SET @x.modify('
    insert element LastName {sql:variable("@LastName")} as last into
    (/Employee)[1]
')

/* Alternate versions of syntax
SELECT @LastName = 'Mr.'
-- insert an element -- First
SET @x.modify('
    insert element Prefix {sql:variable("@LastName")} as first into
    (/Employee)[1]
')

SELECT @LastName = 'Q'
-- insert an element -- After
SET @x.modify('
    insert element Prefix {sql:variable("@LastName")} 
    after (/Employee/FirstName)[1]
')
*/

-- test the results
SELECT @x

/*
output:
<Employee>
  <FirstName>Jacob</FirstName>
  <LastName>Sebastian</LastName>
</Employee>
*/



GO
-------------------------------------------------------------------------------
--  Insert Attribute
-------------------------------------------------------------------------------
-- http://www.sqlserverandxml.com/2008/07/xquery-lab-10-how-to-insert-attribute.html
-- Jacob Sebastian

DECLARE @x XML
SELECT @x = '<Employee FirstNam="Jacob"/>'

DECLARE @LastName VARCHAR(15)
SELECT @LastName = 'Sebastian'


SELECT @x

-- insert an attribute
SET @x.modify('
    insert attribute LastName {sql:variable("@LastName")} as last into
    (/Employee)[1]
')

-- test the results
SELECT @x

/*
output:
<Employee FirstNam="Jacob" LastName="Sebastian" />
*/



GO
-------------------------------------------------------------------------------
--  Sadly this does not work so you cant insert XML
-------------------------------------------------------------------------------

DECLARE @x XML
SELECT @x = '
<Employee>
    <FirstName>Jacob</FirstName>
</Employee>'

DECLARE @LastName	XML
SET @LastName = (SELECT 'Sebastian'  FOR XML PATH('LastName'))



SELECT @x,@LastName

-- insert an element
SET @x.modify('
    insert element LastName {sql:variable("@LastName")} as last into
    (/Employee)[1]
')

-- test the results
SELECT @x


GO
-------------------------------------------------------------------------------
--  Sadly this does not work either so you cant insert XML
-------------------------------------------------------------------------------
DECLARE @x XML
SELECT @x = '
<Employee>
    <FirstName>Jacob</FirstName>
</Employee>'

DECLARE @LastName	VARCHAR(1024)
SET @LastName = '<LastName>Sebastian</LastName>'



SELECT @x,@LastName

-- insert an element
SET @x.modify('
    insert element LastName {sql:variable("@LastName")} as last into
    (/Employee)[1]
')

-- test the results
SELECT @x



GO
-------------------------------------------------------------------------------
--  Update the value of an Element
-------------------------------------------------------------------------------
-- http://www.sqlserverandxml.com/2008/08/xquery-lab-17-how-to-update-value-of.html
-- Jacob Sebastian
DECLARE @x XML
SELECT @x = '
<Employees>
    <Employee>
        <FirstName>Jacob</FirstName>
        <MiddleName>V</MiddleName>
        <LastName>Sebastian</LastName>
    </Employee>
</Employees>'

DECLARE @MiddleName CHAR(1)
SELECT @MiddleName = 'J'

SELECT @x

SET @x.modify('
    replace value of (/Employees/Employee/MiddleName/text())[1]
    with sql:variable("@MiddleName")' )
    
SELECT @x
/*
<Employees>
  <Employee>
    <FirstName>Jacob</FirstName>
    <MiddleName>J</MiddleName>
    <LastName>Sebastian</LastName>
  </Employee>
</Employees>
*/



GO
-------------------------------------------------------------------------------
--  Update the value of an Attribute
-------------------------------------------------------------------------------
-- http://www.sqlserverandxml.com/2008/07/xquery-lab-8-how-to-update-attribute.html
-- Jacob Sebastian
DECLARE @x XML
SELECT @x = '<Employee FirstName="Jacob" LastName="Sebastian"/>'
DECLARE @Lastname VARCHAR(10)
SELECT @LastName = 'Seb'

SELECT @x

SET @x.modify(
'
    replace value of (/Employee/@LastName)[1] 
    with sql:variable("@LastName")
')

SELECT @x
/*
output:
<Employee FirstName="Jacob" LastName="Seb" />
*/


GO
-------------------------------------------------------------------------------
-- Delete an element 
-------------------------------------------------------------------------------
-- http://www.sqlserverandxml.com/2008/08/xquery-lab-18-how-do-i-delete-element.html
-- Jacob Sebastian
DECLARE @x XML
SELECT @x = '
<Employees>
    <Employee>
        <FirstName>Jacob</FirstName>
        <MiddleName>V</MiddleName>
        <LastName>Sebastian</LastName>
    </Employee>
</Employees>'

--DECLARE @MiddleName CHAR(1)
--SELECT @MiddleName = 'J'

SELECT @x

SET @x.modify('
    delete (/Employees/Employee/MiddleName)[1]'
 )
    
SELECT @x
/*
<Employees>
  <Employee>
    <FirstName>Jacob</FirstName>
    <LastName>Sebastian</LastName>
  </Employee>
</Employees>
*/


GO
-------------------------------------------------------------------------------
--  Delete an attribute
-------------------------------------------------------------------------------
-- http://www.sqlserverandxml.com/2008/07/xquery-lab-9-how-to-delete-attribute.html
-- Jacob Sebastian
DECLARE @x XML
SELECT @x = '<Employee FirstName="Jacob" LastName="Sebastian"/>'

SELECT @x

SET @x.modify(
'
    delete (/Employee/@LastName)[1] 
')

SELECT @x
/*
output:
<Employee FirstName="Jacob" />
*/

