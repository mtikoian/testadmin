DECLARE @EmployeeXML	XML

SET @EmployeeXML = '<Employees>
<Employee ID="C848A8F2-5D9B-41BC-9B84-042EDC81E2D2"  EmployeeSSN="001-22-3344" EmployeeNumber="016495" ID_Client="10086"   ClientCode="SlateQ">
    <Name>
      <Salutation ID_lu_Salutation="2"></Salutation>
      <First>Fred</First>
      <Middle>R</Middle>
      <Last>Flintstone</Last>
    </Name>
    <Gender ID_lu_Gender="2">Dude</Gender>
    <DOB>1957-05-16T00:00:00</DOB>
    <Language ID_lu_Language="1">EN</Language>
    <Disability ID_lu_Disability="0" />
    <IsSmoker>0</IsSmoker>
    <LoginName>FredF@Slate.com</LoginName>
    <Addresses>
      <Address Use="Home" DateStart="1900-01-01T00:00:00">
        <AddressLine1>123 Stone Dr.</AddressLine1>
        <City>Bedrock</City>
        <State>PA</State>
        <ZipCode>00001</ZipCode>
        <Country>United States</Country>
      </Address>
      <Address Use="Work" DateStart="1900-01-01T00:00:00">
        <AddressLine1>1 Quary Dr</AddressLine1>
        <City>My City</City>
        <State>PA</State>
        <ZipCode>71111</ZipCode>
        <Country>United States</Country>
      </Address>
    </Addresses>
    <Phones>
      <Phone Use="Home5" DateStart="1900-01-01T00:00:00">
        <AreaCode>333</AreaCode>
        <PhoneNumber>1112244</PhoneNumber>
      </Phone>
    </Phones>
    <EmailAddresses>
      <EmailAddress Use="Work" DateStart="1900-01-01T00:00:00">FredF@Slate.com</EmailAddress>
    </EmailAddresses>
    <GroupTypes>
      <GroupType ID_lu_Group_Type_Type="3" IsValuePK="1">11612</GroupType>
    </GroupTypes>
    <Jobs>
      <Job>
        <EmployeeType ID_lu_Employee_Type="2">W-2</EmployeeType>
        <Occupation >Dino-Crane Opperator</Occupation>
        <Client_Site ID_Client_Site="22835">CHQ</Client_Site>
        <JobTitle JobCode="MT/FT-B">MT Full-Time Full Benefits</JobTitle>
        <ERClass ID_lu_Class="455" />
        <BenefitClass ID_lu_Benefit_Class="7527" />
        <DateHired>2006-11-15T00:00:00</DateHired>
        <StartDate>2006-11-15T00:00:00</StartDate>
        <Salary>
          <FrequencyOut ID_lu_Pay_Period="3">Semi-Monthly</FrequencyOut>
          <FrequencyIn ID_lu_Pay_Period_Hour="1">Annual</FrequencyIn>
          <Rate>20800.0000</Rate>
        </Salary>
      </Job>
    </Jobs>
  </Employee> 
  <Employee ID="CCE8A4A0-1D8A-47BD-865C-82E1A6A86BF0"  EmployeeSSN="999-80-4402" EmployeeNumber="345432" ID_Client="10086" ClientCode="SlateQ">
    <Name>
      <First>Barney</First>
      <Middle>t</Middle>
      <Last>Rubble</Last>
    </Name>
    <Gender ID_lu_Gender="7"></Gender>
	<Marital_Status>Widowed</Marital_Status>
    <DOB>1952-10-11T00:00:00</DOB>
    <Language ID_lu_Language="1">EN</Language>
    <Disability ID_lu_Disability="1" />
    <IsSmoker>0</IsSmoker>
    <LoginName>BarneyR@Slate.com</LoginName>
    <Addresses>
      <Address Use="Home" DateStart="1900-01-01T00:00:00">
        <AddressLine1>122 Stone Dr</AddressLine1>
        <City>Bedrock</City>
        <State>PA</State>
        <ZipCode>00001</ZipCode>
        <Country>United States</Country>
      </Address>
      <Address Use="Work" DateStart="1900-01-01T00:00:00">
        <AddressLine1>1500 Walnut st</AddressLine1>
        <City>Phileadelphia</City>
        <State>PA</State>
        <ZipCode>19102</ZipCode>
        <Country>United States</Country>
      </Address>
    </Addresses>
    <Phones>
      <Phone Use="Home" DateStart="1900-01-01T00:00:00">
        <AreaCode>331</AreaCode>
        <PhoneNumber>2314556</PhoneNumber>
      </Phone>
      <Phone Use="Work" DateStart="1900-01-01T00:00:00">
        <AreaCode>215</AreaCode>
        <PhoneNumber>555-1212</PhoneNumber>
      </Phone>
    </Phones>
    <EmailAddresses>
      <EmailAddress Use="Work35" DateStart="1900-01-01T00:00:00">newlogin@we-enroll.com</EmailAddress>
    </EmailAddresses>
    <GroupTypes>
      <GroupType ID_lu_Group_Type_Type="3" IsValuePK="1">11612</GroupType>
      <GroupType ID_lu_Group_Type_Type="2" IsValuePK="0">10</GroupType>
    </GroupTypes>
    <Jobs>
      <Job>
        <EmployeeType ID_lu_Employee_Type="2">W-2</EmployeeType>
        <Occupation ID_lu_Occupation="121"></Occupation>
        <Client_Site ID_Client_Site="22835">CHQ</Client_Site>
        <JobTitle JobCode="">MT Full-Time Full Benefits</JobTitle>
        <ERClass ID_lu_Class="455" />
        <BenefitClass ID_lu_Benefit_Class="15132" />
        <DateHired>2006-11-06T00:00:00</DateHired>
        <StartDate>2006-11-06T00:00:00</StartDate>
        <Salary>
          <FrequencyOut ID_lu_Pay_Period="3">Semi-Monthly</FrequencyOut>
          <FrequencyIn ID_lu_Pay_Period_Hour="1">Annual</FrequencyIn>
          <Rate>20800.0000</Rate>
        </Salary>
      </Job>
    </Jobs>
  </Employee>
</Employees>'


SELECT @EmployeeXML

SELECT @EmployeeXML.query('Employees/Employee')

SELECT @EmployeeXML.query('Employees/Employee/Addresses')

SELECT @EmployeeXML.query('Employees/Employee/Addresses/Address')

SELECT @EmployeeXML.query('Employees/Employee/Addresses/Address[@Use = "Home"]')

SELECT @EmployeeXML.query('Employees[Employee/Addresses/Address/@Use = "Home"]')


SELECT @EmployeeXML.query('Employees/Employee/Addresses/Address[@Use = "Home"]/.')

SELECT @EmployeeXML.query('Employees/Employee/Addresses/Address[@Use = "Home"]/*')



