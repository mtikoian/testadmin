WITH CurrentInventory AS (SELECT * FROM dbo.Inventory) 
INSERT dbo.Inventory
SELECT ID, NumPurchased
FROM
(
MERGE CurrentInventory t
USING (
    select ID, Sum(NumPurchased) as NumPurchased 
    from dbo.Sales 
    group by ID
    ) s
ON s.ID = t.ID
WHEN MATCHED THEN
  --UPDATE SET StockLevel = t.StockLevel - s.NumPurchased
  UPDATE SET IsCurrent = CASE WHEN (s.Type2Col1 <> t.Type2Col1 OR s.Type2Col2 <> ...) THEN 0 ELSE 1 END
WHEN NOT MATCHED BY TARGET THEN
  INSERT (id, Name, StockLevel) values (s.id, 'TBA', -s.NumPurchased)
--WHEN NOT MATCHED BY SOURCE THEN
--  UPDATE SET IsCurrent = 0, EndDate = sysdatetime()
output $action as whatidid, inserted.IsCurrent as newIsCurrent, s.*
) m
WHERE whatidid = 'UPDATE'
AND newIsCurrent = 0
AND ID is not null
;
