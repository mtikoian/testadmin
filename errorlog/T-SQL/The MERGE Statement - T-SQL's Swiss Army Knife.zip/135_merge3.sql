--CREATE TABLE dbo.DemoInserts
--(id uniqueidentifier default newid(),
-- name varchar(50) not null)
 
insert dbo.DemoInserts (name)
output inserted.id, inserted.name
select name from Production.Product


insert dbo.SomeAuditStuff (someid, name, price)
select * 
from (
merge dbo.DemoInserts
using Production.Product s
on 1=0
when not matched by target then
   insert (name) values (s.Name)
output inserted.id, inserted.name, s.ListPrice
) m
where ListPrice > 0
;
   

create table dbo.SomeAuditStuff
(someid uniqueidentifier not null,
 name varchar(50) not null,
 price decimal(13,2) not null
)