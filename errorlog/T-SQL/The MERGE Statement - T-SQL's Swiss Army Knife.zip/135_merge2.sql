/*
create table dbo.Inventory
(id int primary key,
Name varchar(50) not null,
StockLevel int not null);

create table dbo.Sales
(id int primary key,
CustomerID int not null,
NumPurchased int not null);
*/

--declare @sales dbo.SalesList;
--insert @sales VALUES (1,17,4);
--exec dbo.ProcessSales @sales;


create proc dbo.ProcessSales (@sales dbo.SalesList readonly)
as 
begin 
    MERGE dbo.Inventory t
    USING @Sales s
    ON s.ID = t.ID
    WHEN MATCHED THEN
      UPDATE SET StockLevel = t.StockLevel - s.NumPurchased
    WHEN NOT MATCHED BY TARGET THEN
      INSERT (id, Name, StockLevel) values (s.id, 'TBA', -s.NumPurchased)
    ;
end

select * from dbo.Inventory

--insert dbo.Inventory (id, Name, StockLevel)
--values (1, 'Widgets', 15), (2, 'Gadgets', 20), (3, 'SomethingElse', 25)

--insert dbo.Sales (id, CustomerID, NumPurchased)
--values (1, 17, 3), (3, 18, 5), (4, 19, 2)




--create type dbo.SalesList as table
--(id int primary key,
--CustomerID int not null,
--NumPurchased int not null);

