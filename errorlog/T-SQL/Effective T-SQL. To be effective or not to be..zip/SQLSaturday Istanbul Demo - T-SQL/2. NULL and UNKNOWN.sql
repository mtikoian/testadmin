USE AdventureWorks2014
GO

SET STATISTICS IO ON
GO

-- General info (row count) about Product table
SELECT * FROM Production.Product;

-- "True" logic
SELECT * FROM Production.Product
WHERE Color = 'Black';

SELECT * FROM Production.Product
WHERE Color != 'Black';

SELECT * FROM Production.Product
WHERE Color IS NULL;


-- "Not False" logic
CREATE TABLE #temp (Color nvarchar(30))
GO

ALTER TABLE #temp
	ADD CONSTRAINT CH_TEMP_COLOR CHECK (Color = 'Black' OR Color = 'White')
GO

INSERT INTO #temp VALUES ('Black');

INSERT INTO #temp VALUES ('Red');

INSERT INTO #temp VALUES (NULL);

DROP TABLE #temp
GO
