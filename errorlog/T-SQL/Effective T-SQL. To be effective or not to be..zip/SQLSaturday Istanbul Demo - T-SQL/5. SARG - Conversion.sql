USE AdventureWorks2014
GO

-- Speakers Note:
-- 1) Turn on "Actual Execution Plan"

SET STATISTICS IO ON
GO

ALTER TABLE [dbo].[bigProduct]
	ALTER COLUMN Name varchar(80)
GO

CREATE INDEX IX_BIGPRODUCT_NAME
ON [dbo].[bigProduct] (Name)
GO

-- Implicit converts
SELECT * FROM dbo.bigProduct
WHERE Name = N'Blade1000'
GO

-- Correct type usage
SELECT * FROM dbo.bigProduct
WHERE Name = 'Blade1000'
GO

DROP INDEX IX_BIGPRODUCT_NAME
ON [dbo].[bigProduct]
GO

ALTER TABLE [dbo].[bigProduct]
	ALTER COLUMN Name nvarchar(80)
GO
