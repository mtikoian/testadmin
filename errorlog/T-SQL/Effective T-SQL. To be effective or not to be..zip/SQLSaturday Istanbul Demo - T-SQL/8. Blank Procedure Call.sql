USE AdventureWorks2014
GO

CREATE PROCEDURE #GetBigProductInfo(@id int)
AS
BEGIN
    IF (@id = -1)
	BEGIN
		SELECT NULL
	END
	ELSE
	BEGIN
		SELECT 'Name: ' + Name + ' Number: ' + ProductNumber
		FROM dbo.bigProduct
		WHERE ProductID = @id
	END
END
GO

EXEC #GetBigProductInfo -1
GO 1000

SELECT NULL
GO 1000

DROP PROCEDURE #dbo.GetBigProductInfo
GO