USE AdventureWorks2014
GO

-- Stupid SQL Server can't recognize alias in WHERE
SELECT t.ProductID, COUNT(*) AS TransactionCount 
FROM Production.TransactionHistory t
WHERE t.ActualCost > 100
	AND TransactionCount > 2000
GROUP BY t.ProductId

-- Query looks fine, but it is actualy not
SELECT t.ProductId, COUNT(*) AS TransactionCount 
FROM Production.TransactionHistory t
WHERE t.ActualCost > 100
	AND COUNT(*) > 2000
GROUP BY t.ProductId

-- Stupid SQL Server can't recognize alias in HAVING
SELECT t.ProductID, COUNT(*) AS TransactionCount 
FROM Production.TransactionHistory t
WHERE t.ActualCost > 100
GROUP BY t.ProductId
HAVING TransactionCount > 2000

-- We are already know why this query is correct, are we?
-- Q: How many times COUNT(*) is executed?
SELECT t.ProductID, COUNT(*) AS TransactionCount 
FROM Production.TransactionHistory t
WHERE t.ActualCost > 10
GROUP BY t.ProductId
HAVING COUNT(*) > 100
ORDER BY TransactionCount DESC
OPTION (MAXDOP 1)
