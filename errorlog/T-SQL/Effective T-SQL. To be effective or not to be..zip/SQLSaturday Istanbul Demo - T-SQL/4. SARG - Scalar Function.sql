USE AdventureWorks2014
GO

-- Speakers Note:
-- 1) Turn on "Actual Execution Plan"

SET STATISTICS IO ON
GO

CREATE INDEX IX_BIGPRODUCT_PRODUCTNUMBER
	ON [dbo].[bigProduct] (ProductNumber)
GO

-- Inefficient usage of function in query
SELECT ProductNumber FROM dbo.bigProduct
WHERE SUBSTRING(ProductNumber, 1, 2) = 'Bl';

-- Better alternative for this particular query
SELECT ProductNumber FROM dbo.bigProduct
WHERE ProductNumber LIKE 'Bl%';

DROP INDEX IX_BIGPRODUCT_PRODUCTNUMBER
	ON [dbo].[bigProduct]
GO
