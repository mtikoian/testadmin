USE AdventureWorks2014
GO

SET STATISTICS IO ON
GO

-- Not effective solution (subquery)
SELECT p.ProductID, COUNT(*)
FROM Production.TransactionHistory t
INNER LOOP JOIN Production.Product p
	ON t.ProductID = p.ProductID
WHERE (SELECT COUNT(*) FROM Production.TransactionHistory t1 WHERE t1.ProductId = p.ProductId) >= 100
GROUP BY p.ProductId
ORDER BY ProductID
OPTION (MAXDOP 1)

-- Effective solution (full power of T-SQL)
SELECT p.ProductId, COUNT(*)
FROM Production.TransactionHistory t
INNER JOIN Production.Product p
	ON t.ProductID = p.ProductID
GROUP BY p.ProductId
HAVING COUNT(*) >= 100
ORDER BY ProductID
OPTION (MAXDOP 1)

