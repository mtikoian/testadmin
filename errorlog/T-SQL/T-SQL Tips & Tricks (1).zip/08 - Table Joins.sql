IF OBJECT_ID('dbo.Table_A') IS NOT NULL DROP TABLE dbo.Table_A;
CREATE TABLE dbo.Table_A (
	Field_A varchar(50),
	Field_B int,
	Field_C varchar(32),
	Field_D int
	);

IF OBJECT_ID('dbo.Table_B') IS NOT NULL DROP TABLE dbo.Table_B;
CREATE TABLE dbo.Table_B (
	Field_A varchar(50),
	Field_B int,
	Field_C varchar(32),
	Field_D int
	);

IF OBJECT_ID('dbo.Table_C') IS NOT NULL DROP TABLE dbo.Table_C;
CREATE TABLE dbo.Table_C (
	Field_A varchar(50),
	Field_B int,
	Field_C varchar(32),
	Field_D int
	);

SELECT *
FROM dbo.Table_A AS a
	LEFT JOIN dbo.Table_B AS b
		ON b.Field_A = a.Field_A
	INNER JOIN dbo.Table_C AS c
		ON c.Field_B = b.Field_B
WHERE a.Field_A = 'Bob'
AND b.Field_D BETWEEN 1 AND 100;