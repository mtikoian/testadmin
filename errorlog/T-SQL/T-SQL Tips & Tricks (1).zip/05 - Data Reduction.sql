/*
 * Create some tables and data to work with during these examples
 */
IF OBJECT_ID('dbo.tbl_Source') IS NOT NULL DROP TABLE dbo.tbl_Source;
CREATE TABLE dbo.tbl_Source (
	SourceID int NOT NULL,
	Description varchar(40),
	InsType char(2)
	);

INSERT INTO tbl_Source (SourceID, Description, InsType)
	VALUES	(1, 'Commercial Health Insurance', 'CM'),
			(2, 'County Hospital', NULL),
			(3, 'City Hospital', NULL),
			(4, 'Medicare', 'MC');

IF OBJECT_ID('dbo.tbl_Patients') IS NOT NULL DROP TABLE dbo.tbl_Patients;
CREATE TABLE dbo.tbl_Patients (
	PatientKey int IDENTITY(1,1),
	PatientID int NOT NULL,
	LastName varchar(40) NOT NULL,
	FirstName varchar(40) NULL,
	MiddleInit char(1) NULL,
	Gender char(1) NULL,
	DOB date NULL,
	DOD date NULL,
	SourceID int NOT NULL
	);

/*
	Bonus Tip: Use VALUES clause to turn INSERT into a single transaction
*/
INSERT INTO dbo.tbl_Patients(PatientID, LastName, FirstName, MiddleInit, Gender, DOB, DOD, SourceID)
	VALUES  (123456, 'Duck', 'Daffy', 'D', 'M', '03/05/1964', NULL, 1),
			(234567, 'Bunny', 'Bugs', 'B', 'M', '02/29/1964', NULL, 1),
			(345678, 'Coyote', 'Wile', 'E', 'M', '01/15/1966', '12/06/1999', 2),
			(123456, 'Duck', 'Daffy', 'D', 'M', '03/05/1964', NULL, 1), -- Duplicate
			(456789, 'Runner', 'Road', NULL, 'F', '04/23/1974', NULL, 2),
			(345678, 'Coyote', 'Whylee', NULL, NULL, '01/15/1966', '12/07/1999', 2), -- Duplicate
			(123456, 'Duck', 'Daffy', 'D', 'M', '03/05/1964', NULL, 1), -- Duplicate
			(567890, 'Duck', 'Daisy', NULL, 'F', '05/03/1966', NULL, 1),
			(564231, 'Fudd', 'Elmer', NULL, 'M', '03/20/1946', NULL, 4),
			(853156, 'Bird', 'Tweety', NULL, 'M', '10/10/1960', NULL, 3),
			(462137, 'Cat', 'Sylvester', 'T', 'M', '12/15/1955', NULL, 3),
			(134679, 'LePue', 'Peppy', NULL, 'M', '11/11/1959', NULL, 3),
			(963741, 'Duck', 'Huey', NULL, 'M', '09/09/1979', NULL, 1),
			(963742, 'Duck', 'Louie', NULL, 'M', '09/09/1979', NULL, 1),
			(963743, 'Duck', 'Dewey', NULL, 'M', '09/09/1979', NULL, 1);

/*
 * Delete duplicate data -- typically used in staging tables without primary key
 */
SELECT * FROM tbl_Patients ORDER BY PatientID;

WITH cteDups AS (
	SELECT *, ROW_NUMBER() OVER(PARTITION BY P.PatientID ORDER BY P.PatientID, P.PatientKey) AS RowNbr
	FROM dbo.tbl_Patients P
	)
SELECT *
FROM cteDups D
WHERE D.RowNbr > 1;

WITH cteDups AS (
	SELECT *, ROW_NUMBER() OVER(PARTITION BY P.PatientID ORDER BY P.PatientID, P.PatientKey) AS RowNbr
	FROM dbo.tbl_Patients P
	)
DELETE
FROM cteDups
WHERE RowNbr > 1;

SELECT * FROM tbl_Patients ORDER BY PatientID;

/*
 * Return Random Rows From a Table
 * This is very very easy : you just have to select the top n rows(where n is the number of the rows you want to return) and order by NEWID()
 * NEWID is a system function that creates a unique value of type uniqueidentifier.
 */

SELECT TOP 5 *
FROM dbo.tbl_Patients
ORDER BY NEWID();

/*
 * Simplify usage of complicated expressions
 * This is super simple: when using an expression more than once, make use of a CTE
 */

WITH ctePatients(PatientID, LastName, FirstName, Age) AS (
	SELECT P.PatientID, P.LastName, P.FirstName,
		FLOOR((DATEDIFF(day, P.DOB, GETDATE())/3.65242199)*1.000005)/100
	FROM dbo.tbl_Patients P
	)
SELECT P.PatientID, P.LastName, P.FirstName, P.Age
FROM ctePatients P
WHERE P.Age >= 50
ORDER BY P.Age;
