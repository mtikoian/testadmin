-- =============================================
-- Author:		Aaron N. Cutshall
-- Create date: 14-Nov-2011
-- Description:	Identify columns of the same name in different databases having different datatypes.
--				Based upon code originally written by Ian Stirk on 01-Jun-2008
-- =============================================
-- Do not lock anything, and do not get held up by any locks.
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
-- Calculate prevalence of column name
	 WITH ctePrevalence(Column_Name, Pct) AS (
		SELECT Column_Name, CONVERT(DECIMAL(12,2),COUNT(Column_Name)* 100.0 / COUNT(*)OVER())
		FROM Information_Schema.Columns
		WHERE Table_Name NOT IN('sysdiagrams','dtproperties')
		GROUP BY Column_Name
		)
-- Do the columns differ on datatype across the schemas and tables?
	SELECT DISTINCT
		C1.Column_Name,
		C1.Table_Schema,
		C1.Table_Name,
		C1.Data_Type,
		C1.Character_Maximum_Length,
		C1.Numeric_Precision,
		C1.Numeric_Scale,
		P.Pct
	FROM Information_Schema.Columns C1
		INNER JOIN Information_Schema.Columns C2 ON C1.Column_Name = C2.Column_Name
		INNER JOIN ctePrevalence P ON P.Column_Name = C1.Column_Name
	WHERE ((C1.Data_Type != C2.Data_Type)
		OR (C1.Character_Maximum_Length != C2.Character_Maximum_Length)
		OR (C1.Numeric_Precision != C2.Numeric_Precision)
		OR (C1.Numeric_Scale != C2.Numeric_Scale))
	AND C1.Table_Name NOT IN('sysdiagrams','dtproperties')
	AND C2.Table_Name NOT IN('sysdiagrams','dtproperties')
	ORDER BY Pct DESC, C1.Column_Name, C1.Table_Schema, C1.Table_Name;
