/*
 * Use appropriate join criteria instead of using WHERE clause
 * This is really more usefull in large datasets
 */

-- Instead of this:
SELECT P.PatientID, P.LastName, P.FirstName, S.Description
FROM dbo.tbl_Patients P
	INNER JOIN dbo.tbl_Source S ON S.SourceID = P.SourceID
WHERE S.InsType IS NOT NULL;

-- Use this:
SELECT P.PatientID, P.LastName, P.FirstName, S.Description
FROM dbo.tbl_Patients P
	INNER JOIN dbo.tbl_Source S ON S.SourceID = P.SourceID AND S.InsType IS NOT NULL;


/*
 * Using LEFT JOIN for conditional joins
 */

IF OBJECT_ID('dbo.tbl_Employee') IS NOT NULL DROP TABLE dbo.tbl_Employee;
CREATE TABLE dbo.tbl_Employee (
	EmployeeID int,
	EmployeeName varchar(40),
	EmpType char(1),
	Department int
	);

INSERT INTO tbl_Employee (EmployeeID, EmployeeName, EmpType, Department)
	VALUES	(1, 'Professor X', 'A', 1),
			(2, 'Cyclops', 'A', 2),
			(3, 'Storm', 'B', 1),
			(4, 'Wolverine', 'B', 2),
			(5, 'Iceman', 'B', 2),
			(6, 'Beast', 'C', 1),
			(7, 'Nightcrawler', 'C', 2),
			(8, 'Kitty Pryde', 'C', 2);

IF OBJECT_ID('dbo.tbl_Rates') IS NOT NULL DROP TABLE dbo.tbl_Rates;
CREATE TABLE dbo.tbl_Rates (
	EmpType char(1),
	Department int,
	Rate money
	);

INSERT INTO tbl_Rates (EmpType, Department, Rate)
	VALUES	('A', NULL, 50),
			('A', 1, 55),
			('B', NULL, 40),
			('B', 1, 45),
			('C', NULL, 30),
			('C', 1, 35);

-- Instead of this:
SELECT E.EmployeeName, R.Rate as BillingRate
FROM dbo.tbl_Employee E
	INNER JOIN tbl_Rates R ON ((R.EmpType = E.EmpType AND R.Department = E.Department) OR
								(R.EmpType = E.EmpType AND R.Department IS NULL));

-- Use this:
SELECT E.EmployeeName, ISNULL(R.Rate, D.Rate) as BillingRate
FROM dbo.tbl_Employee E
	LEFT JOIN tbl_Rates R ON R.EmpType = E.EmpType AND R.Department = E.Department
	LEFT JOIN tbl_Rates D ON D.EmpType = E.EmpType AND D.Department IS NULL;
