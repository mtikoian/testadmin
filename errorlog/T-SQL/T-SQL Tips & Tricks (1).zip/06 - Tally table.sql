--=============================================================================
--      Setup
--=============================================================================
--    USE TempDB     --DB that everyone has where we can cause no harm
    SET NOCOUNT ON --Supress the auto-display of rowcounts for appearance/speed

DECLARE @StartTime DATETIME= GETDATE(); --Start the timer

--=============================================================================
--      Create and populate a Tally table
--=============================================================================
--===== Conditionally drop 
     IF OBJECT_ID('dbo.Tally') IS NOT NULL DROP TABLE dbo.Tally;

--===== Create and populate the Tally table
 SELECT TOP 100 IDENTITY(INT,1,1) AS N
   INTO dbo.Tally
   FROM Master.dbo.SysColumns;

/*
-- For over to 4 million records, do the following:
 SELECT TOP 100 IDENTITY(INT,1,1) AS N
   INTO dbo.Tally
   FROM Master.dbo.SysColumns sc1,
		Master.dbo.SysColumns sc2;

--===== Add a Primary Key to maximize performance
  ALTER TABLE dbo.Tally
    ADD CONSTRAINT PK_Tally_N 
        PRIMARY KEY CLUSTERED (N) WITH FILLFACTOR = 100;

--===== Let the public use it
  GRANT SELECT, REFERENCES ON dbo.Tally TO PUBLIC;

--===== Display the total duration
 SELECT STR(DATEDIFF(ms,@StartTime,GETDATE())) + ' Milliseconds duration';
*/
GO

/*
Example 1:	Let's say that you need to generate a list of all dates from 05/12/2008 to 06/02/2008
			inclusive. You might use a temp table or table variable, and construct a loop that
			inserts records for each date in the range. By using a tally table, all you need is
			this (using variables to make it flexible):
*/
DECLARE @start date = '05/12/2008', @end date = '06/02/2008';

SELECT DATEADD(d, (N - 1), @start) AS [Date]
FROM dbo.Tally
WHERE N < DATEDIFF(d, @start, @end) + 1;

/*
Example 2:	I want to find out how many people have a birthday in each month but I don't want to
			skip any months.
*/

--Normally I'd use this query
WITH cteBirthday(PatientID, DOB_Month) AS (
	SELECT PatientID, DATEPART(mm, DOB)
	FROM dbo.tbl_Patients
	)
SELECT b.DOB_Month as 'Month', COUNT(*)
FROM cteBirthday b
GROUP BY b.DOB_Month;

-- However, this will not return a row for any month that did not have a birthday.  You can use a
-- tally to ensure that you have totals for all 12 months, even for months without a birthday.

WITH cteBirthday(PatientID, DOB_Month) AS (
	SELECT PatientID, DATEPART(mm, DOB)
	FROM dbo.tbl_Patients
	)
SELECT t.N as 'Month', COUNT(DOB_Month)
FROM dbo.Tally t
	LEFT JOIN cteBirthday b on t.N = b.DOB_Month
WHERE t.N <= 12
GROUP BY t.N;