IF OBJECT_ID('dbo.fnMaskSSN') IS NOT NULL DROP FUNCTION dbo.fnMaskSSN;
GO
CREATE FUNCTION dbo.fnMaskSSN (@ssn char(11))
RETURNS char(11) AS
BEGIN
	RETURN 'xxx-xx-' + right(@ssn,4);;
END;
GO

IF OBJECT_ID('dbo.tbl_Patient') IS NOT NULL DROP TABLE dbo.tbl_Patient;
GO
CREATE TABLE dbo.tbl_Patient (
	PatientID int,
	FirstName varchar(32),
	LastName varchar(64),
	SSN char(11)
	);

INSERT INTO dbo.tbl_Patient ( PatientID, FirstName, LastName, SSN )
VALUES	( 1, 'Bob', 'Jones', '123-45-6789'),
		( 2, 'Steve', 'Smith', '234-56-7890'),
		( 3, 'Jane', 'Johnson', '345-67-8901');

--	Instead of the following:
SELECT p.FirstName, p.LastName, dbo.fnMaskSSN(p.SSN) as MaskedSSN
FROM dbo.tbl_Patient p;

--	Do the following:

--	Code Segment: dbo.fnMaskSSN
SELECT p.FirstName, p.LastName, 'xxx-xx-' + RIGHT(p.SSN,4) as MaskedSSN
FROM dbo.tbl_Patient p;