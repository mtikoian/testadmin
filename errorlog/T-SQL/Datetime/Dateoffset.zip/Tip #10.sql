DECLARE @DT2_3 AS DATETIME;

SET @DT2_3 = '2006-12-30 23:19:29.999'
SELECT @DT2_3
GO

-- Tip #10
-- DATETIME2 - Size dependent on accuracy level.

DECLARE @DT2_3 AS DATETIME2(3);

SET @DT2_3 = '2006-12-30 23:19:29.12375'
SELECT @DT2_3

SELECT DATALENGTH(@DT2_3) Size, @DT2_3 StoredValue
GO















-- Out of Range
DECLARE @DateString VARCHAR(30) = '01 JAN 1500 05:03:29';


SELECT 
	CAST(@DateString AS SMALLDATETIME)	AS SmallDateTimeConversion,
	CAST(@DateString AS DATETIME)		AS DateTimeConversion;
GO






-- This will fail: 
-- Msg 242, Level 16, State 3, Line 4
-- The conversion of a varchar data type to a smalldatetime data type resulted in an out-of-range value.





DECLARE @DateString VARCHAR(30) = '01 JAN 1500 05:03:29';
SELECT 
	TRY_CAST(@DateString AS SMALLDATETIME)	AS SmallDateTimeConversion,
	TRY_CAST(@DateString AS DATETIME)		AS DateTimeConversion;

GO

-- This will return NULL if it's not possible to convert the value.




DECLARE @DateString VARCHAR(30) = '01 JAN 1500 05:03:29 +10:00';

SELECT
	CAST(@DateString AS DATETIMEOFFSET)	AS DateTimeOffsetCast,
	CONVERT(DATETIME2, @DateString)		AS DateTime2Conversion;
-- This will return timezone default to 0




