USE EDW
GO

-- ###############################################################################
-- Create a schema to store functions
-- ###############################################################################
IF NOT EXISTS (SELECT * FROM sys.schemas (NOLOCK) WHERE name = 'UTIL')
BEGIN
	EXEC('CREATE SCHEMA [UTIL]')
END
GO

-- ###############################################################################
-- Drop UTIL.udf_nthWeekDay, if it exists
-- ###############################################################################
IF EXISTS (SELECT * FROM sysobjects (NOLOCK) WHERE id = object_id(N'UTIL.udf_nthWeekDay') AND xtype IN (N'FN', N'IF', N'TF'))
BEGIN
	DROP FUNCTION UTIL.udf_nthWeekDay
END
GO

-- ###############################################################################
-- Create UTIL.udf_nthWeekDay function to get dates for holidays on a specific day of the month
-- ###############################################################################
CREATE FUNCTION UTIL.udf_nthWeekDay
(
  @n       INT, 
  @weekDay CHAR(3),
  @year    INT, 
  @month   INT
)
RETURNS DATETIME
AS
BEGIN
  DECLARE @date    DATETIME,
    @dow         INT,
    @offset      INT,
    @wd          INT;
    
  SELECT @wd = CASE @weekDay
      WHEN 'SUN' THEN 1
      WHEN 'MON' THEN 2
      WHEN 'TUE' THEN 3
      WHEN 'WED' THEN 4
      WHEN 'THU' THEN 5
      WHEN 'FRI' THEN 6
      WHEN 'SAT' THEN 7
    END,
    @date = CAST
    (
      CAST(@year AS VARCHAR(4)) +
      RIGHT
      (
        '0' + CAST
        (
          @month AS VARCHAR(2)
        ), 2
      ) +
      '01' AS DATETIME
    ),
    @dow = DATEPART(dw, @date),
    @offset = @wd - @dow,
    @date = DATEADD(day, @offset + (@n - CASE WHEN @offset >= 0 THEN 1 ELSE 0 END) * 7, @date);
  RETURN @date;
END;
GO

-- ###############################################################################
-- Drop UTIL.udf_CalculateEaster, if it exists
-- ###############################################################################
IF EXISTS (SELECT * FROM sysobjects (NOLOCK) WHERE id = object_id(N'UTIL.udf_CalculateEaster') AND xtype IN (N'FN', N'IF', N'TF'))
BEGIN
	DROP FUNCTION UTIL.udf_CalculateEaster
END
GO

-- ###############################################################################
-- Create UTIL.udf_CalculateEaster function to return the date of Easter for any year. 
-- Uses calculations from NASA to determine lunar calendar which Easter is based on.
-- ###############################################################################
CREATE FUNCTION UTIL.udf_CalculateEaster 
(
  @Year INT
)
RETURNS DATETIME
AS
BEGIN
    DECLARE @Date DATETIME,
    @c INT, 
    @n INT, 
    @i INT, 
    @k INT, 
    @j INT, 
    @l INT, 
    @m INT, 
    @d INT;

    SELECT @n = @Year - 19 * (@Year / 19),
    @c = @Year / 100,
    @k = (@c - 17) / 25,
    @i = @c - @c / 4 - (@c - @k) / 3 + 19 * @n + 15,
    @i = @i - 30 * (@i / 30),
    @i = @i - (@i / 28) * (1 - (@i / 28) * (29 / (@i + 1)) * ((21 - @n) / 11)),
    @j = @Year + @Year / 4 + @i + 2 - @c + @c / 4,
    @j = @j - 7 * (@j / 7),
    @l = @i - @j,
    @m = 3 + (@l + 40) / 44,
    @d = @l + 28 - 31 * (@m / 4),
    @Date = CAST
    (
      CAST(@Year AS CHAR(4)) + 
      RIGHT
      (
        '0' + CAST
        (
          @m AS VARCHAR(2)
        ), 2
      ) + 
      RIGHT
      (
        '0' +CAST
        (
          @d AS VARCHAR(2)
        ), 2
      ) AS DATETIME
    );
    RETURN @Date;
END;
GO

-- ###############################################################################
-- Create CORE schema that all Date Dimension tables will be stored in.
-- ###############################################################################
IF NOT EXISTS (SELECT * FROM sys.schemas (NOLOCK) WHERE name = 'CORE')
BEGIN
	EXEC('CREATE SCHEMA [CORE]')
END
GO

-- ###############################################################################
-- Drop table DATE_DIM, if it currently exists and all Exptended Properties that go with it.
-- ###############################################################################
IF EXISTS (SELECT * FROM sys.tables (NOLOCK) WHERE name = 'DATE_DIM')
BEGIN
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'CORE', @level1type=N'TABLE',@level1name=N'DATE_DIM'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'CORE', @level1type=N'TABLE',@level1name=N'DATE_DIM', @level2type=N'COLUMN',@level2name=N'FISC_EOY_DT'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'CORE', @level1type=N'TABLE',@level1name=N'DATE_DIM', @level2type=N'COLUMN',@level2name=N'FISC_START_OF_YR_DT'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'CORE', @level1type=N'TABLE',@level1name=N'DATE_DIM', @level2type=N'COLUMN',@level2name=N'FISC_LAST_DAY_IN_YR_IND'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'CORE', @level1type=N'TABLE',@level1name=N'DATE_DIM', @level2type=N'COLUMN',@level2name=N'FISC_YR_NBR'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'CORE', @level1type=N'TABLE',@level1name=N'DATE_DIM', @level2type=N'COLUMN',@level2name=N'FISC_EOQ_DT'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'CORE', @level1type=N'TABLE',@level1name=N'DATE_DIM', @level2type=N'COLUMN',@level2name=N'FISC_START_OF_QTR_DT'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'CORE', @level1type=N'TABLE',@level1name=N'DATE_DIM', @level2type=N'COLUMN',@level2name=N'FISC_LAST_DAY_IN_QTR_IND'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'CORE', @level1type=N'TABLE',@level1name=N'DATE_DIM', @level2type=N'COLUMN',@level2name=N'FISC_YR_QTR_NM'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'CORE', @level1type=N'TABLE',@level1name=N'DATE_DIM', @level2type=N'COLUMN',@level2name=N'FISC_YR_QTR_NBR'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'CORE', @level1type=N'TABLE',@level1name=N'DATE_DIM', @level2type=N'COLUMN',@level2name=N'FISC_QTR_YR_NM'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'CORE', @level1type=N'TABLE',@level1name=N'DATE_DIM', @level2type=N'COLUMN',@level2name=N'FISC_QTR_YR_NBR'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'CORE', @level1type=N'TABLE',@level1name=N'DATE_DIM', @level2type=N'COLUMN',@level2name=N'FISC_QTR_NBR'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'CORE', @level1type=N'TABLE',@level1name=N'DATE_DIM', @level2type=N'COLUMN',@level2name=N'FISC_EOM_DT'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'CORE', @level1type=N'TABLE',@level1name=N'DATE_DIM', @level2type=N'COLUMN',@level2name=N'FISC_START_OF_MTH_DT'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'CORE', @level1type=N'TABLE',@level1name=N'DATE_DIM', @level2type=N'COLUMN',@level2name=N'FISC_LAST_DAY_IN_MTH_IND'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'CORE', @level1type=N'TABLE',@level1name=N'DATE_DIM', @level2type=N'COLUMN',@level2name=N'FISC_YR_MTH_ABRV_NM'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'CORE', @level1type=N'TABLE',@level1name=N'DATE_DIM', @level2type=N'COLUMN',@level2name=N'FISC_MTH_ABRV_YR_NM'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'CORE', @level1type=N'TABLE',@level1name=N'DATE_DIM', @level2type=N'COLUMN',@level2name=N'FISC_MTH_YR_NM'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'CORE', @level1type=N'TABLE',@level1name=N'DATE_DIM', @level2type=N'COLUMN',@level2name=N'FISC_MTH_YR_NBR'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'CORE', @level1type=N'TABLE',@level1name=N'DATE_DIM', @level2type=N'COLUMN',@level2name=N'FISC_YR_MTH_NM'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'CORE', @level1type=N'TABLE',@level1name=N'DATE_DIM', @level2type=N'COLUMN',@level2name=N'FISC_YR_MTH_NBR'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'CORE', @level1type=N'TABLE',@level1name=N'DATE_DIM', @level2type=N'COLUMN',@level2name=N'FISC_MTH_IN_YR_NBR'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'CORE', @level1type=N'TABLE',@level1name=N'DATE_DIM', @level2type=N'COLUMN',@level2name=N'FISC_MTH_IN_QTR_NBR'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'CORE', @level1type=N'TABLE',@level1name=N'DATE_DIM', @level2type=N'COLUMN',@level2name=N'FISC_EOW_DT'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'CORE', @level1type=N'TABLE',@level1name=N'DATE_DIM', @level2type=N'COLUMN',@level2name=N'FISC_START_OF_WK_DT'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'CORE', @level1type=N'TABLE',@level1name=N'DATE_DIM', @level2type=N'COLUMN',@level2name=N'FISC_LAST_DAY_IN_WK_IND'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'CORE', @level1type=N'TABLE',@level1name=N'DATE_DIM', @level2type=N'COLUMN',@level2name=N'FISC_WK_IN_YR_NBR'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'CORE', @level1type=N'TABLE',@level1name=N'DATE_DIM', @level2type=N'COLUMN',@level2name=N'FISC_WK_IN_QTR_NBR'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'CORE', @level1type=N'TABLE',@level1name=N'DATE_DIM', @level2type=N'COLUMN',@level2name=N'FISC_WK_IN_MTH_NBR'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'CORE', @level1type=N'TABLE',@level1name=N'DATE_DIM', @level2type=N'COLUMN',@level2name=N'FISC_DAY_IN_YR_NBR'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'CORE', @level1type=N'TABLE',@level1name=N'DATE_DIM', @level2type=N'COLUMN',@level2name=N'FISC_DAY_IN_QTR_NBR'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'CORE', @level1type=N'TABLE',@level1name=N'DATE_DIM', @level2type=N'COLUMN',@level2name=N'FISC_DAY_IN_MTH_NBR'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'CORE', @level1type=N'TABLE',@level1name=N'DATE_DIM', @level2type=N'COLUMN',@level2name=N'FISC_DAY_IN_WK_NBR'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'CORE', @level1type=N'TABLE',@level1name=N'DATE_DIM', @level2type=N'COLUMN',@level2name=N'CAL_EOY_DT'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'CORE', @level1type=N'TABLE',@level1name=N'DATE_DIM', @level2type=N'COLUMN',@level2name=N'CAL_START_OF_YR_DT'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'CORE', @level1type=N'TABLE',@level1name=N'DATE_DIM', @level2type=N'COLUMN',@level2name=N'CAL_LAST_DAY_IN_YR_IND'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'CORE', @level1type=N'TABLE',@level1name=N'DATE_DIM', @level2type=N'COLUMN',@level2name=N'CAL_YR_NBR'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'CORE', @level1type=N'TABLE',@level1name=N'DATE_DIM', @level2type=N'COLUMN',@level2name=N'CAL_EOQ_DT'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'CORE', @level1type=N'TABLE',@level1name=N'DATE_DIM', @level2type=N'COLUMN',@level2name=N'CAL_START_OF_QTR_DT'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'CORE', @level1type=N'TABLE',@level1name=N'DATE_DIM', @level2type=N'COLUMN',@level2name=N'CAL_LAST_DAY_IN_QTR_IND'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'CORE', @level1type=N'TABLE',@level1name=N'DATE_DIM', @level2type=N'COLUMN',@level2name=N'CAL_YR_QTR_NM'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'CORE', @level1type=N'TABLE',@level1name=N'DATE_DIM', @level2type=N'COLUMN',@level2name=N'CAL_YR_QTR_NBR'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'CORE', @level1type=N'TABLE',@level1name=N'DATE_DIM', @level2type=N'COLUMN',@level2name=N'CAL_QTR_YR_NM'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'CORE', @level1type=N'TABLE',@level1name=N'DATE_DIM', @level2type=N'COLUMN',@level2name=N'CAL_QTR_YR_NBR'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'CORE', @level1type=N'TABLE',@level1name=N'DATE_DIM', @level2type=N'COLUMN',@level2name=N'CAL_QTR_NBR'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'CORE', @level1type=N'TABLE',@level1name=N'DATE_DIM', @level2type=N'COLUMN',@level2name=N'CAL_EOM_DT'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'CORE', @level1type=N'TABLE',@level1name=N'DATE_DIM', @level2type=N'COLUMN',@level2name=N'CAL_START_OF_MTH_DT'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'CORE', @level1type=N'TABLE',@level1name=N'DATE_DIM', @level2type=N'COLUMN',@level2name=N'CAL_LAST_DAY_IN_MTH_IND'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'CORE', @level1type=N'TABLE',@level1name=N'DATE_DIM', @level2type=N'COLUMN',@level2name=N'CAL_YR_MTH_ABRV_NM'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'CORE', @level1type=N'TABLE',@level1name=N'DATE_DIM', @level2type=N'COLUMN',@level2name=N'CAL_MTH_ABRV_YR_NM'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'CORE', @level1type=N'TABLE',@level1name=N'DATE_DIM', @level2type=N'COLUMN',@level2name=N'CAL_MTH_YR_NM'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'CORE', @level1type=N'TABLE',@level1name=N'DATE_DIM', @level2type=N'COLUMN',@level2name=N'CAL_MTH_YR_NBR'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'CORE', @level1type=N'TABLE',@level1name=N'DATE_DIM', @level2type=N'COLUMN',@level2name=N'CAL_YR_MTH_NM'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'CORE', @level1type=N'TABLE',@level1name=N'DATE_DIM', @level2type=N'COLUMN',@level2name=N'CAL_YR_MTH_NBR'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'CORE', @level1type=N'TABLE',@level1name=N'DATE_DIM', @level2type=N'COLUMN',@level2name=N'CAL_MTH_IN_YR_NBR'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'CORE', @level1type=N'TABLE',@level1name=N'DATE_DIM', @level2type=N'COLUMN',@level2name=N'CAL_MTH_IN_QTR_NBR'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'CORE', @level1type=N'TABLE',@level1name=N'DATE_DIM', @level2type=N'COLUMN',@level2name=N'CAL_EOW_DT'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'CORE', @level1type=N'TABLE',@level1name=N'DATE_DIM', @level2type=N'COLUMN',@level2name=N'CAL_START_OF_WK_DT'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'CORE', @level1type=N'TABLE',@level1name=N'DATE_DIM', @level2type=N'COLUMN',@level2name=N'CAL_LAST_DAY_IN_WK_IND'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'CORE', @level1type=N'TABLE',@level1name=N'DATE_DIM', @level2type=N'COLUMN',@level2name=N'CAL_WK_IN_YR_NBR'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'CORE', @level1type=N'TABLE',@level1name=N'DATE_DIM', @level2type=N'COLUMN',@level2name=N'CAL_WK_IN_QTR_NBR'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'CORE', @level1type=N'TABLE',@level1name=N'DATE_DIM', @level2type=N'COLUMN',@level2name=N'CAL_WK_IN_MTH_NBR'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'CORE', @level1type=N'TABLE',@level1name=N'DATE_DIM', @level2type=N'COLUMN',@level2name=N'CAL_DAY_IN_YR_NBR'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'CORE', @level1type=N'TABLE',@level1name=N'DATE_DIM', @level2type=N'COLUMN',@level2name=N'CAL_DAY_IN_QTR_NBR'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'CORE', @level1type=N'TABLE',@level1name=N'DATE_DIM', @level2type=N'COLUMN',@level2name=N'CAL_DAY_IN_MTH_NBR'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'CORE', @level1type=N'TABLE',@level1name=N'DATE_DIM', @level2type=N'COLUMN',@level2name=N'CAL_DAY_IN_WK_NBR'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'CORE', @level1type=N'TABLE',@level1name=N'DATE_DIM', @level2type=N'COLUMN',@level2name=N'HOLIDAY_IND'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'CORE', @level1type=N'TABLE',@level1name=N'DATE_DIM', @level2type=N'COLUMN',@level2name=N'WKDAY_IND'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'CORE', @level1type=N'TABLE',@level1name=N'DATE_DIM', @level2type=N'COLUMN',@level2name=N'MTH_ABRV_NM'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'CORE', @level1type=N'TABLE',@level1name=N'DATE_DIM', @level2type=N'COLUMN',@level2name=N'MTH_NM'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'CORE', @level1type=N'TABLE',@level1name=N'DATE_DIM', @level2type=N'COLUMN',@level2name=N'DAY_ABRV_NM'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'CORE', @level1type=N'TABLE',@level1name=N'DATE_DIM', @level2type=N'COLUMN',@level2name=N'DAY_NM'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'CORE', @level1type=N'TABLE',@level1name=N'DATE_DIM', @level2type=N'COLUMN',@level2name=N'FULL_DT_DESC'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'CORE', @level1type=N'TABLE',@level1name=N'DATE_DIM', @level2type=N'COLUMN',@level2name=N'DAY_DT'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'CORE', @level1type=N'TABLE',@level1name=N'DATE_DIM', @level2type=N'COLUMN',@level2name=N'SORT_ORD_NBR'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'CORE', @level1type=N'TABLE',@level1name=N'DATE_DIM', @level2type=N'COLUMN',@level2name=N'DATE_ID'
	DROP TABLE [CORE].[DATE_DIM]
END
GO

-- ###############################################################################
-- Create table CORE.DATE_DIM
-- ###############################################################################
CREATE TABLE [CORE].[DATE_DIM] (
       DATE_ID					INT NOT NULL,
       SORT_ORD_NBR				INT NOT NULL,
       DAY_DT					DATE NOT NULL,
       FULL_DT_DESC				VARCHAR(18) NOT NULL,
       DAY_NM					VARCHAR(9) NOT NULL,
       DAY_ABRV_NM				VARCHAR(3) NOT NULL,
       MTH_NM					VARCHAR(9) NOT NULL,
       MTH_ABRV_NM				VARCHAR(3) NOT NULL,
       WKDAY_IND				BIT NOT NULL,
       HOLIDAY_IND				BIT NOT NULL,
       CAL_DAY_IN_WK_NBR		INT NOT NULL,
       CAL_DAY_IN_MTH_NBR		INT NOT NULL,
       CAL_DAY_IN_QTR_NBR		INT NOT NULL,
       CAL_DAY_IN_YR_NBR		INT NOT NULL,
       CAL_WK_IN_MTH_NBR		INT NOT NULL,
       CAL_WK_IN_QTR_NBR		INT NOT NULL,
       CAL_WK_IN_YR_NBR			INT NOT NULL,
       CAL_LAST_DAY_IN_WK_IND	BIT NOT NULL,
       CAL_START_OF_WK_DT		DATE NOT NULL,
       CAL_EOW_DT				DATE NOT NULL,
       CAL_MTH_IN_QTR_NBR		INT NOT NULL,
       CAL_MTH_IN_YR_NBR		INT NOT NULL,
       CAL_YR_MTH_NBR			VARCHAR(7) NOT NULL,
       CAL_YR_MTH_NM			VARCHAR(14) NOT NULL,
       CAL_MTH_YR_NBR			VARCHAR(7) NOT NULL,
       CAL_MTH_YR_NM			VARCHAR(14) NOT NULL,
       CAL_MTH_ABRV_YR_NM		VARCHAR(8) NOT NULL,
       CAL_YR_MTH_ABRV_NM		VARCHAR(8) NOT NULL,
       CAL_LAST_DAY_IN_MTH_IND	BIT NOT NULL,
       CAL_START_OF_MTH_DT		DATE NOT NULL,
       CAL_EOM_DT				DATE NOT NULL,
       CAL_QTR_NBR				INT NOT NULL,
       CAL_QTR_YR_NBR			VARCHAR(7) NOT NULL,
       CAL_QTR_YR_NM			VARCHAR(7) NOT NULL,
       CAL_YR_QTR_NBR			VARCHAR(7) NOT NULL,
       CAL_YR_QTR_NM			VARCHAR(7) NOT NULL,
       CAL_LAST_DAY_IN_QTR_IND	BIT NOT NULL,
       CAL_START_OF_QTR_DT		DATE NOT NULL,
       CAL_EOQ_DT				DATE NOT NULL,
       CAL_YR_NBR				INT NOT NULL,
       CAL_LAST_DAY_IN_YR_IND	BIT NOT NULL,
       CAL_START_OF_YR_DT		DATE NOT NULL,
       CAL_EOY_DT				DATE NOT NULL,
       FISC_DAY_IN_WK_NBR		INT NOT NULL,
       FISC_DAY_IN_MTH_NBR		INT NOT NULL,
       FISC_DAY_IN_QTR_NBR		INT NOT NULL,
       FISC_DAY_IN_YR_NBR		INT NOT NULL,
       FISC_WK_IN_MTH_NBR		INT NOT NULL,
       FISC_WK_IN_QTR_NBR		INT NOT NULL,
       FISC_WK_IN_YR_NBR		INT NOT NULL,
       FISC_LAST_DAY_IN_WK_IND	BIT NOT NULL,
       FISC_START_OF_WK_DT		DATE NOT NULL,
       FISC_EOW_DT				DATE NOT NULL,
       FISC_MTH_IN_QTR_NBR		INT NOT NULL,
       FISC_MTH_IN_YR_NBR		INT NOT NULL,
       FISC_YR_MTH_NBR			VARCHAR(7) NOT NULL,
       FISC_YR_MTH_NM			VARCHAR(14) NOT NULL,
       FISC_MTH_YR_NBR			VARCHAR(7) NOT NULL,
       FISC_MTH_YR_NM			VARCHAR(14) NOT NULL,
       FISC_MTH_ABRV_YR_NM		VARCHAR(8) NOT NULL,
       FISC_YR_MTH_ABRV_NM		VARCHAR(8) NOT NULL,
       FISC_LAST_DAY_IN_MTH_IND BIT NOT NULL,
       FISC_START_OF_MTH_DT		DATE NOT NULL,
       FISC_EOM_DT				DATE NOT NULL,
       FISC_QTR_NBR				INT NOT NULL,
       FISC_QTR_YR_NBR			VARCHAR(7) NOT NULL,
       FISC_QTR_YR_NM			VARCHAR(7) NOT NULL,
       FISC_YR_QTR_NBR			VARCHAR(7) NOT NULL,
       FISC_YR_QTR_NM			VARCHAR(7) NOT NULL,
       FISC_LAST_DAY_IN_QTR_IND BIT NOT NULL,
       FISC_START_OF_QTR_DT		DATE NOT NULL,
       FISC_EOQ_DT				DATE NOT NULL,
       FISC_YR_NBR				INT NOT NULL,
       FISC_LAST_DAY_IN_YR_IND	BIT NOT NULL,
       FISC_START_OF_YR_DT		DATE NOT NULL,
       FISC_EOY_DT				DATE NOT NULL,
	   CONSTRAINT PK_DATE_DIM
			PRIMARY KEY CLUSTERED (DATE_ID)
			WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
) ON [PRIMARY]
GO

ALTER TABLE [CORE].[DATE_DIM] ADD CONSTRAINT [DATE_DIM_U1] UNIQUE 
(
	[DAY_DT] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value='Date Dimension contains a calendar date and all attributes about that date. Note - Leap years are accounted for (e.g., FEBRUARY 29, 2008)'
	, @level0type = N'Schema', @level0name = 'CORE'
	, @level1type = N'Table', @level1name = N'DATE_DIM'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Key is a system-generated surrogate identifier. Reserved for data warehouse use, this key should be invisible to the typical business user.'
	, @level0type = N'Schema', @level0name = 'CORE'
	, @level1type = N'Table', @level1name = 'DATE_DIM'
	, @level2type = N'Column', @level2name = 'DATE_ID'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'A number that is used to sequence records, starting with the dummy Referential Integrity Null record values (starting at Zero). All valid data is sorted on the same value. Pre-defining a sort order for a row allows reports to easily sort data in that order.  It is an artificial sort rather than merely sorting on business data.  In the case of null dimension rows, it provides the unique ability to sort missing dimension rows to the top of a report to make facts with missing dimension values more visible. Example: NOT APPLICABLE = 0, NOT AVAILABLE = 1, UNKNOWN = 2, All other records = 3'
	, @level0type = N'Schema', @level0name = 'CORE'
	, @level1type = N'Table', @level1name = 'DATE_DIM'
	, @level2type = N'Column', @level2name = 'SORT_ORD_NBR'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Day Date is the actual date of the day.'
	, @level0type = N'Schema', @level0name = 'CORE'
	, @level1type = N'Table', @level1name = 'DATE_DIM'
	, @level2type = N'Column', @level2name = 'DAY_DT'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Full Date Description is the full description of the date - e.g., SEPTEMBER 30, 2006.'
	, @level0type = N'Schema', @level0name = 'CORE'
	, @level1type = N'Table', @level1name = 'DATE_DIM'
	, @level2type = N'Column', @level2name = 'FULL_DT_DESC'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Day Name is the name of the day - MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY, SUNDAY'
	, @level0type = N'Schema', @level0name = 'CORE'
	, @level1type = N'Table', @level1name = 'DATE_DIM'
	, @level2type = N'Column', @level2name = 'DAY_NM'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Day of Week Abbreviation Name is the abbreviation of the day - MON, TUE, WED, THU, FRI, SAT, SUN.'
	, @level0type = N'Schema', @level0name = 'CORE'
	, @level1type = N'Table', @level1name = 'DATE_DIM'
	, @level2type = N'Column', @level2name = 'DAY_ABRV_NM'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Calendar Month Name is the name of the calendar month - JANUARY, FEBRUARY, MARCH, APRIL, MAY, JUNE, JULY, AUGUST, SEPTEMBER, OCTOBER, NOVEMBER, DECEMBER.'
	, @level0type = N'Schema', @level0name = 'CORE'
	, @level1type = N'Table', @level1name = 'DATE_DIM'
	, @level2type = N'Column', @level2name = 'MTH_NM'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Calendar Month Abbreviation Name is the abbreviation of the calendar month - JAN, FEB, MAR, APR, MAY, JUN, JUL, AUG, SEP, OCT, NOV, DEC.'
	, @level0type = N'Schema', @level0name = 'CORE'
	, @level1type = N'Table', @level1name = 'DATE_DIM'
	, @level2type = N'Column', @level2name = 'MTH_ABRV_NM'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Weekday Indicator indicates if the date is a weekday (includes MONDAY through FRIDAY) - 1, 0.'
	, @level0type = N'Schema', @level0name = 'CORE'
	, @level1type = N'Table', @level1name = 'DATE_DIM'
	, @level2type = N'Column', @level2name = 'WKDAY_IND'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Holiday Indicator indicates if the date is a holiday - 1, 0. Note - If a holiday falls on a Saturday then it is observed on Friday and if a holiday falls on a Sunday then it is observed on Monday.'
	, @level0type = N'Schema', @level0name = 'CORE'
	, @level1type = N'Table', @level1name = 'DATE_DIM'
	, @level2type = N'Column', @level2name = 'HOLIDAY_IND'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Calendar Day in Week Number is the day in the calendar week - 1, 2, 3, 4, 5, 6, 7. Note - SUNDAY = 1, etc.'
	, @level0type = N'Schema', @level0name = 'CORE'
	, @level1type = N'Table', @level1name = 'DATE_DIM'
	, @level2type = N'Column', @level2name = 'CAL_DAY_IN_WK_NBR'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Calendar Day in Month Number is the day in the calendar month (1 - 31)'
	, @level0type = N'Schema', @level0name = 'CORE'
	, @level1type = N'Table', @level1name = 'DATE_DIM'
	, @level2type = N'Column', @level2name = 'CAL_DAY_IN_MTH_NBR'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Calendar Day in Quarter Number is the day in the calendar quarter. e.g., 1, 100, etc.'
	, @level0type = N'Schema', @level0name = 'CORE'
	, @level1type = N'Table', @level1name = 'DATE_DIM'
	, @level2type = N'Column', @level2name = 'CAL_DAY_IN_QTR_NBR'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Calendar Day in Year Number is the day in the calendar year. Starts with 1 for January 1st and up to 366 for leap years.'
	, @level0type = N'Schema', @level0name = 'CORE'
	, @level1type = N'Table', @level1name = 'DATE_DIM'
	, @level2type = N'Column', @level2name = 'CAL_DAY_IN_YR_NBR'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Calendar Week in Month Number is the week in the calendar month - 1, 2, 3, 4, 5. Note - The 1st - 7th is week one, 8th - 14th is week two, etc.  When you get past the 28th, week five. There is a week for every set of seven days from the start to the end of the calendar month.'
	, @level0type = N'Schema', @level0name = 'CORE'
	, @level1type = N'Table', @level1name = 'DATE_DIM'
	, @level2type = N'Column', @level2name = 'CAL_WK_IN_MTH_NBR'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Calendar Week in Quarter Number is the week in the calendar quarter - 1, 2, 3, 4, 5, etc. Note - The 1st - 7th is week one, 8th - 14th is week two, etc. There is a week for every set of seven days from the start to the end of the calendar quarter.'
	, @level0type = N'Schema', @level0name = 'CORE'
	, @level1type = N'Table', @level1name = 'DATE_DIM'
	, @level2type = N'Column', @level2name = 'CAL_WK_IN_QTR_NBR'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Calendar Week in Year Number is the number of the week in the calendar year - 1, 2, 3, 4, 5, etc. Note - JAN 1st - 7th is week one, 8th - 14th is week two, etc. There is a week for every set of seven days from the start to the end of the calendar year.'
	, @level0type = N'Schema', @level0name = 'CORE'
	, @level1type = N'Table', @level1name = 'DATE_DIM'
	, @level2type = N'Column', @level2name = 'CAL_WK_IN_YR_NBR'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Calendar Last Day in Week Indicator indicates if the date is the last day in the calendar week (which is on a Saturday)- 1, 0.'
	, @level0type = N'Schema', @level0name = 'CORE'
	, @level1type = N'Table', @level1name = 'DATE_DIM'
	, @level2type = N'Column', @level2name = 'CAL_LAST_DAY_IN_WK_IND'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Calendar Start of Week Date is the date the calendar week started (which is on a Sunday).'
	, @level0type = N'Schema', @level0name = 'CORE'
	, @level1type = N'Table', @level1name = 'DATE_DIM'
	, @level2type = N'Column', @level2name = 'CAL_START_OF_WK_DT'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Calendar End of Week Date is the date the calendar week ended (which is on a Saturday).'
	, @level0type = N'Schema', @level0name = 'CORE'
	, @level1type = N'Table', @level1name = 'DATE_DIM'
	, @level2type = N'Column', @level2name = 'CAL_EOW_DT'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Calendar Month in Quarter Number is the month in the calendar quarter - 1, 2, 3.'
	, @level0type = N'Schema', @level0name = 'CORE'
	, @level1type = N'Table', @level1name = 'DATE_DIM'
	, @level2type = N'Column', @level2name = 'CAL_MTH_IN_QTR_NBR'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Calendar Month in Year Number is the month in the calendar year - 1 through 12.'
	, @level0type = N'Schema', @level0name = 'CORE'
	, @level1type = N'Table', @level1name = 'DATE_DIM'
	, @level2type = N'Column', @level2name = 'CAL_MTH_IN_YR_NBR'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Calendar Year Month Number is the combination of the calendar year and month. e.g., 2006-03'
	, @level0type = N'Schema', @level0name = 'CORE'
	, @level1type = N'Table', @level1name = 'DATE_DIM'
	, @level2type = N'Column', @level2name = 'CAL_YR_MTH_NBR'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Calendar Year Month Name is the combination of the calendar year and month. e.g., 2006-MARCH'
	, @level0type = N'Schema', @level0name = 'CORE'
	, @level1type = N'Table', @level1name = 'DATE_DIM'
	, @level2type = N'Column', @level2name = 'CAL_YR_MTH_NM'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Calendar Month Year Number is the combination of the calendar month and year. e.g., 03-2006'
	, @level0type = N'Schema', @level0name = 'CORE'
	, @level1type = N'Table', @level1name = 'DATE_DIM'
	, @level2type = N'Column', @level2name = 'CAL_MTH_YR_NBR'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Calendar Month Year Name is the combination of the calendar month and year. e.g., MARCH-2006'
	, @level0type = N'Schema', @level0name = 'CORE'
	, @level1type = N'Table', @level1name = 'DATE_DIM'
	, @level2type = N'Column', @level2name = 'CAL_MTH_YR_NM'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Calendar Month Abbreviation Year Number is the combination of the abbreviated calendar month and the year. e.g., SEP-2006'
	, @level0type = N'Schema', @level0name = 'CORE'
	, @level1type = N'Table', @level1name = 'DATE_DIM'
	, @level2type = N'Column', @level2name = 'CAL_MTH_ABRV_YR_NM'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Calendar Month Abbreviation Year Number is the combination of the abbreviated calendar month and the year. e.g., 2006-SEP'
	, @level0type = N'Schema', @level0name = 'CORE'
	, @level1type = N'Table', @level1name = 'DATE_DIM'
	, @level2type = N'Column', @level2name = 'CAL_YR_MTH_ABRV_NM'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Calendar Last Day in Month Indicator indicates if the date is the last day in the calendar month - 1, 0.'
	, @level0type = N'Schema', @level0name = 'CORE'
	, @level1type = N'Table', @level1name = 'DATE_DIM'
	, @level2type = N'Column', @level2name = 'CAL_LAST_DAY_IN_MTH_IND'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Calendar Start of Month Date is the calendar date the month started.'
	, @level0type = N'Schema', @level0name = 'CORE'
	, @level1type = N'Table', @level1name = 'DATE_DIM'
	, @level2type = N'Column', @level2name = 'CAL_START_OF_MTH_DT'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Calendar End of Month Date is the date the calendar month ended.'
	, @level0type = N'Schema', @level0name = 'CORE'
	, @level1type = N'Table', @level1name = 'DATE_DIM'
	, @level2type = N'Column', @level2name = 'CAL_EOM_DT'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Calendar Quarter Number is the number of the calendar quarter - 1, 2, 3, 4'
	, @level0type = N'Schema', @level0name = 'CORE'
	, @level1type = N'Table', @level1name = 'DATE_DIM'
	, @level2type = N'Column', @level2name = 'CAL_QTR_NBR'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Calendar Quarter Year Number is the combination of the calendar quarter and year. e.g., 01-2006'
	, @level0type = N'Schema', @level0name = 'CORE'
	, @level1type = N'Table', @level1name = 'DATE_DIM'
	, @level2type = N'Column', @level2name = 'CAL_QTR_YR_NBR'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Calendar Quarter Year Name is the combination of the calendar quarter and year. e.g., Q1-2006'
	, @level0type = N'Schema', @level0name = 'CORE'
	, @level1type = N'Table', @level1name = 'DATE_DIM'
	, @level2type = N'Column', @level2name = 'CAL_QTR_YR_NM'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Calendar Year Quarter Number is the combination of the calendar year and quarter. e.g., 2006-01'
	, @level0type = N'Schema', @level0name = 'CORE'
	, @level1type = N'Table', @level1name = 'DATE_DIM'
	, @level2type = N'Column', @level2name = 'CAL_YR_QTR_NBR'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Calendar Year Quarter Name is the combination of the calendar year and quarter. e.g., 2006-Q1'
	, @level0type = N'Schema', @level0name = 'CORE'
	, @level1type = N'Table', @level1name = 'DATE_DIM'
	, @level2type = N'Column', @level2name = 'CAL_YR_QTR_NM'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Calendar Last Day in Quarter Indicator indicates if the date is the last day in the calendar quarter - 1, 0.'
	, @level0type = N'Schema', @level0name = 'CORE'
	, @level1type = N'Table', @level1name = 'DATE_DIM'
	, @level2type = N'Column', @level2name = 'CAL_LAST_DAY_IN_QTR_IND'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Calendar Start of Quarter Date is the date the calendar quarter started.'
	, @level0type = N'Schema', @level0name = 'CORE'
	, @level1type = N'Table', @level1name = 'DATE_DIM'
	, @level2type = N'Column', @level2name = 'CAL_START_OF_QTR_DT'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Calendar End of Quarter Date is the date the calendar quarter ended.'
	, @level0type = N'Schema', @level0name = 'CORE'
	, @level1type = N'Table', @level1name = 'DATE_DIM'
	, @level2type = N'Column', @level2name = 'CAL_EOQ_DT'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Calendar Year Number is the number of the calendar year. e.g., 2006'
	, @level0type = N'Schema', @level0name = 'CORE'
	, @level1type = N'Table', @level1name = 'DATE_DIM'
	, @level2type = N'Column', @level2name = 'CAL_YR_NBR'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Calendar Last Day in Year Indicator indicates if the date is the last day in the calendar year - 1, 0.'
	, @level0type = N'Schema', @level0name = 'CORE'
	, @level1type = N'Table', @level1name = 'DATE_DIM'
	, @level2type = N'Column', @level2name = 'CAL_LAST_DAY_IN_YR_IND'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Calendar Start of Year Date is the date the calendar year started.'
	, @level0type = N'Schema', @level0name = 'CORE'
	, @level1type = N'Table', @level1name = 'DATE_DIM'
	, @level2type = N'Column', @level2name = 'CAL_START_OF_YR_DT'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Calendar End of Year Date is the date the calendar year ended.'
	, @level0type = N'Schema', @level0name = 'CORE'
	, @level1type = N'Table', @level1name = 'DATE_DIM'
	, @level2type = N'Column', @level2name = 'CAL_EOY_DT'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Fiscal Day in Week Number is the day in the Fiscal week - 1, 2, 3, 4, 5, 6, 7. Note - SUNDAY = 1, etc.'
	, @level0type = N'Schema', @level0name = 'CORE'
	, @level1type = N'Table', @level1name = 'DATE_DIM'
	, @level2type = N'Column', @level2name = 'FISC_DAY_IN_WK_NBR'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Fiscal Day in Month Number is the day in the Fiscal month (1 - 31)'
	, @level0type = N'Schema', @level0name = 'CORE'
	, @level1type = N'Table', @level1name = 'DATE_DIM'
	, @level2type = N'Column', @level2name = 'FISC_DAY_IN_MTH_NBR'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Fiscal Day in Quarter Number is the day in the Fiscal quarter. e.g., 1, 100, etc.'
	, @level0type = N'Schema', @level0name = 'CORE'
	, @level1type = N'Table', @level1name = 'DATE_DIM'
	, @level2type = N'Column', @level2name = 'FISC_DAY_IN_QTR_NBR'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Fiscal Day in Year Number is the day in the Fiscal year. Starts with 1 for January 1st and up to 366 for leap years.'
	, @level0type = N'Schema', @level0name = 'CORE'
	, @level1type = N'Table', @level1name = 'DATE_DIM'
	, @level2type = N'Column', @level2name = 'FISC_DAY_IN_YR_NBR'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Fiscal Week in Month Number is the week in the Fiscal month - 1, 2, 3, 4, 5. Note - The 1st - 7th is week one, 8th - 14th is week two, etc.  When you get past the 28th, week five. There is a week for every set of seven days from the start to the end of the Fiscal month.'
	, @level0type = N'Schema', @level0name = 'CORE'
	, @level1type = N'Table', @level1name = 'DATE_DIM'
	, @level2type = N'Column', @level2name = 'FISC_WK_IN_MTH_NBR'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Fiscal Week in Quarter Number is the week in the Fiscal quarter - 1, 2, 3, 4, 5, etc. Note - The 1st - 7th is week one, 8th - 14th is week two, etc. There is a week for every set of seven days from the start to the end of the Fiscal quarter.'
	, @level0type = N'Schema', @level0name = 'CORE'
	, @level1type = N'Table', @level1name = 'DATE_DIM'
	, @level2type = N'Column', @level2name = 'FISC_WK_IN_QTR_NBR'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Fiscal Week in Year Number is the number of the week in the Fiscal year - 1, 2, 3, 4, 5, etc. Note - JAN 1st - 7th is week one, 8th - 14th is week two, etc. There is a week for every set of seven days from the start to the end of the Fiscal year.'
	, @level0type = N'Schema', @level0name = 'CORE'
	, @level1type = N'Table', @level1name = 'DATE_DIM'
	, @level2type = N'Column', @level2name = 'FISC_WK_IN_YR_NBR'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Fiscal Last Day in Week Indicator indicates if the date is the last day in the Fiscal week (which is on a Saturday)- 1, 0.'
	, @level0type = N'Schema', @level0name = 'CORE'
	, @level1type = N'Table', @level1name = 'DATE_DIM'
	, @level2type = N'Column', @level2name = 'FISC_LAST_DAY_IN_WK_IND'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Fiscal Start of Week Date is the date the Fiscal week started (which is on a Sunday).'
	, @level0type = N'Schema', @level0name = 'CORE'
	, @level1type = N'Table', @level1name = 'DATE_DIM'
	, @level2type = N'Column', @level2name = 'FISC_START_OF_WK_DT'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Fiscal End of Week Date is the date the Fiscal week ended (which is on a Saturday).'
	, @level0type = N'Schema', @level0name = 'CORE'
	, @level1type = N'Table', @level1name = 'DATE_DIM'
	, @level2type = N'Column', @level2name = 'FISC_EOW_DT'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Fiscal Month in Quarter Number is the month in the Fiscal quarter - 1, 2, 3.'
	, @level0type = N'Schema', @level0name = 'CORE'
	, @level1type = N'Table', @level1name = 'DATE_DIM'
	, @level2type = N'Column', @level2name = 'FISC_MTH_IN_QTR_NBR'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Fiscal Month in Year Number is the month in the Fiscal year - 1 through 12.'
	, @level0type = N'Schema', @level0name = 'CORE'
	, @level1type = N'Table', @level1name = 'DATE_DIM'
	, @level2type = N'Column', @level2name = 'FISC_MTH_IN_YR_NBR'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Fiscal Year Month Number is the combination of the Fiscal year and month. e.g., 2006-03'
	, @level0type = N'Schema', @level0name = 'CORE'
	, @level1type = N'Table', @level1name = 'DATE_DIM'
	, @level2type = N'Column', @level2name = 'FISC_YR_MTH_NBR'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Fiscal Year Month Name is the combination of the Fiscal year and month. e.g., 2006-MARCH'
	, @level0type = N'Schema', @level0name = 'CORE'
	, @level1type = N'Table', @level1name = 'DATE_DIM'
	, @level2type = N'Column', @level2name = 'FISC_YR_MTH_NM'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Fiscal Month Year Number is the combination of the Fiscal month and year. e.g., 03-2006'
	, @level0type = N'Schema', @level0name = 'CORE'
	, @level1type = N'Table', @level1name = 'DATE_DIM'
	, @level2type = N'Column', @level2name = 'FISC_MTH_YR_NBR'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Fiscal Month Year Name is the combination of the Fiscal month and year. e.g., MARCH-2006'
	, @level0type = N'Schema', @level0name = 'CORE'
	, @level1type = N'Table', @level1name = 'DATE_DIM'
	, @level2type = N'Column', @level2name = 'FISC_MTH_YR_NM'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Fiscal Month Abbreviation Year Number is the combination of the abbreviated Fiscal month and the year. e.g., SEP-2006'
	, @level0type = N'Schema', @level0name = 'CORE'
	, @level1type = N'Table', @level1name = 'DATE_DIM'
	, @level2type = N'Column', @level2name = 'FISC_MTH_ABRV_YR_NM'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Fiscal Month Abbreviation Year Number is the combination of the abbreviated Fiscal month and the year. e.g., 2006-SEP'
	, @level0type = N'Schema', @level0name = 'CORE'
	, @level1type = N'Table', @level1name = 'DATE_DIM'
	, @level2type = N'Column', @level2name = 'FISC_YR_MTH_ABRV_NM'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Fiscal Last Day in Month Indicator indicates if the date is the last day in the Fiscal month - 1, 0.'
	, @level0type = N'Schema', @level0name = 'CORE'
	, @level1type = N'Table', @level1name = 'DATE_DIM'
	, @level2type = N'Column', @level2name = 'FISC_LAST_DAY_IN_MTH_IND'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Fiscal Start of Month Date is the Fiscal date the month started.'
	, @level0type = N'Schema', @level0name = 'CORE'
	, @level1type = N'Table', @level1name = 'DATE_DIM'
	, @level2type = N'Column', @level2name = 'FISC_START_OF_MTH_DT'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Fiscal End of Month Date is the date the Fiscal month ended.'
	, @level0type = N'Schema', @level0name = 'CORE'
	, @level1type = N'Table', @level1name = 'DATE_DIM'
	, @level2type = N'Column', @level2name = 'FISC_EOM_DT'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Fiscal Quarter Number is the number of the Fiscal quarter - 1, 2, 3, 4'
	, @level0type = N'Schema', @level0name = 'CORE'
	, @level1type = N'Table', @level1name = 'DATE_DIM'
	, @level2type = N'Column', @level2name = 'FISC_QTR_NBR'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Fiscal Quarter Year Number is the combination of the Fiscal quarter and year. e.g., 01-2006'
	, @level0type = N'Schema', @level0name = 'CORE'
	, @level1type = N'Table', @level1name = 'DATE_DIM'
	, @level2type = N'Column', @level2name = 'FISC_QTR_YR_NBR'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Fiscal Quarter Year Name is the combination of the Fiscal quarter and year. e.g., Q1-2006'
	, @level0type = N'Schema', @level0name = 'CORE'
	, @level1type = N'Table', @level1name = 'DATE_DIM'
	, @level2type = N'Column', @level2name = 'FISC_QTR_YR_NM'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Fiscal Year Quarter Number is the combination of the Fiscal year and quarter. e.g., 2006-01'
	, @level0type = N'Schema', @level0name = 'CORE'
	, @level1type = N'Table', @level1name = 'DATE_DIM'
	, @level2type = N'Column', @level2name = 'FISC_YR_QTR_NBR'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Fiscal Year Quarter Name is the combination of the Fiscal year and quarter. e.g., 2006-Q1'
	, @level0type = N'Schema', @level0name = 'CORE'
	, @level1type = N'Table', @level1name = 'DATE_DIM'
	, @level2type = N'Column', @level2name = 'FISC_YR_QTR_NM'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Fiscal Last Day in Quarter Indicator indicates if the date is the last day in the Fiscal quarter - 1, 0.'
	, @level0type = N'Schema', @level0name = 'CORE'
	, @level1type = N'Table', @level1name = 'DATE_DIM'
	, @level2type = N'Column', @level2name = 'FISC_LAST_DAY_IN_QTR_IND'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Fiscal Start of Quarter Date is the date the Fiscal quarter started.'
	, @level0type = N'Schema', @level0name = 'CORE'
	, @level1type = N'Table', @level1name = 'DATE_DIM'
	, @level2type = N'Column', @level2name = 'FISC_START_OF_QTR_DT'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Fiscal End of Quarter Date is the date the Fiscal quarter ended.'
	, @level0type = N'Schema', @level0name = 'CORE'
	, @level1type = N'Table', @level1name = 'DATE_DIM'
	, @level2type = N'Column', @level2name = 'FISC_EOQ_DT'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Fiscal Year Number is the number of the Fiscal year. e.g., 2006'
	, @level0type = N'Schema', @level0name = 'CORE'
	, @level1type = N'Table', @level1name = 'DATE_DIM'
	, @level2type = N'Column', @level2name = 'FISC_YR_NBR'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Fiscal Last Day in Year Indicator indicates if the date is the last day in the Fiscal year - 1, 0.'
	, @level0type = N'Schema', @level0name = 'CORE'
	, @level1type = N'Table', @level1name = 'DATE_DIM'
	, @level2type = N'Column', @level2name = 'FISC_LAST_DAY_IN_YR_IND'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Fiscal Start of Year Date is the date the Fiscal year started.'
	, @level0type = N'Schema', @level0name = 'CORE'
	, @level1type = N'Table', @level1name = 'DATE_DIM'
	, @level2type = N'Column', @level2name = 'FISC_START_OF_YR_DT'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Fiscal End of Year Date is the date the Fiscal year ended.'
	, @level0type = N'Schema', @level0name = 'CORE'
	, @level1type = N'Table', @level1name = 'DATE_DIM'
	, @level2type = N'Column', @level2name = 'FISC_EOY_DT'
GO

-- ##################################################################
-- These are the standard null handling rows.
-- ##################################################################
INSERT INTO CORE.DATE_DIM (DATE_ID,SORT_ORD_NBR,DAY_DT,FULL_DT_DESC,DAY_NM,DAY_ABRV_NM,MTH_NM,MTH_ABRV_NM,WKDAY_IND,HOLIDAY_IND,CAL_DAY_IN_WK_NBR,CAL_DAY_IN_MTH_NBR,CAL_DAY_IN_QTR_NBR,CAL_DAY_IN_YR_NBR,CAL_WK_IN_MTH_NBR,CAL_WK_IN_QTR_NBR,CAL_WK_IN_YR_NBR,CAL_LAST_DAY_IN_WK_IND,CAL_START_OF_WK_DT,CAL_EOW_DT,CAL_MTH_IN_QTR_NBR,CAL_MTH_IN_YR_NBR,CAL_YR_MTH_NBR,CAL_YR_MTH_NM,CAL_MTH_YR_NBR,CAL_MTH_YR_NM,CAL_MTH_ABRV_YR_NM,CAL_YR_MTH_ABRV_NM,CAL_LAST_DAY_IN_MTH_IND,CAL_START_OF_MTH_DT,CAL_EOM_DT,CAL_QTR_NBR,CAL_QTR_YR_NBR,CAL_QTR_YR_NM,CAL_YR_QTR_NBR,CAL_YR_QTR_NM,CAL_LAST_DAY_IN_QTR_IND,CAL_START_OF_QTR_DT,CAL_EOQ_DT,CAL_YR_NBR,CAL_LAST_DAY_IN_YR_IND,CAL_START_OF_YR_DT,CAL_EOY_DT,FISC_DAY_IN_WK_NBR,FISC_DAY_IN_MTH_NBR,FISC_DAY_IN_QTR_NBR,FISC_DAY_IN_YR_NBR,FISC_WK_IN_MTH_NBR,FISC_WK_IN_QTR_NBR,FISC_WK_IN_YR_NBR,FISC_LAST_DAY_IN_WK_IND,FISC_START_OF_WK_DT,FISC_EOW_DT,FISC_MTH_IN_QTR_NBR,FISC_MTH_IN_YR_NBR,FISC_YR_MTH_NBR,FISC_YR_MTH_NM,FISC_MTH_YR_NBR,FISC_MTH_YR_NM,FISC_MTH_ABRV_YR_NM,FISC_YR_MTH_ABRV_NM,FISC_LAST_DAY_IN_MTH_IND,FISC_START_OF_MTH_DT,FISC_EOM_DT,FISC_QTR_NBR,FISC_QTR_YR_NBR,FISC_QTR_YR_NM,FISC_YR_QTR_NBR,FISC_YR_QTR_NM,FISC_LAST_DAY_IN_QTR_IND,FISC_START_OF_QTR_DT,FISC_EOQ_DT,FISC_YR_NBR,FISC_LAST_DAY_IN_YR_IND,FISC_START_OF_YR_DT,FISC_EOY_DT)
VALUES (99991231,0,'9999-12-31','NOT APPLICABLE','NA','NA','NA','NA',0,0,99,99,999,999,99,99,99,0,'9999-12-31','9999-12-31',99,99,'NA','NOT APPLICABLE','NA','NOT APPLICABLE','NA','NA',0,'9999-12-31','9999-12-31',99,'NA','NA','NA','NA',0,'9999-12-31','9999-12-31',9999,0,'9999-12-31','9999-12-31',99,99,999,999,99,99,99,0,'9999-12-31','9999-12-31',99,99,'NA','NOT APPLICABLE','NA','NOT APPLICABLE','NA','NA',0,'9999-12-31','9999-12-31',99,'NA','NA','NA','NA',0,'9999-12-31','9999-12-31',9999,0,'9999-12-31','9999-12-31')
GO

INSERT INTO CORE.DATE_DIM (DATE_ID,SORT_ORD_NBR,DAY_DT,FULL_DT_DESC,DAY_NM,DAY_ABRV_NM,MTH_NM,MTH_ABRV_NM,WKDAY_IND,HOLIDAY_IND,CAL_DAY_IN_WK_NBR,CAL_DAY_IN_MTH_NBR,CAL_DAY_IN_QTR_NBR,CAL_DAY_IN_YR_NBR,CAL_WK_IN_MTH_NBR,CAL_WK_IN_QTR_NBR,CAL_WK_IN_YR_NBR,CAL_LAST_DAY_IN_WK_IND,CAL_START_OF_WK_DT,CAL_EOW_DT,CAL_MTH_IN_QTR_NBR,CAL_MTH_IN_YR_NBR,CAL_YR_MTH_NBR,CAL_YR_MTH_NM,CAL_MTH_YR_NBR,CAL_MTH_YR_NM,CAL_MTH_ABRV_YR_NM,CAL_YR_MTH_ABRV_NM,CAL_LAST_DAY_IN_MTH_IND,CAL_START_OF_MTH_DT,CAL_EOM_DT,CAL_QTR_NBR,CAL_QTR_YR_NBR,CAL_QTR_YR_NM,CAL_YR_QTR_NBR,CAL_YR_QTR_NM,CAL_LAST_DAY_IN_QTR_IND,CAL_START_OF_QTR_DT,CAL_EOQ_DT,CAL_YR_NBR,CAL_LAST_DAY_IN_YR_IND,CAL_START_OF_YR_DT,CAL_EOY_DT,FISC_DAY_IN_WK_NBR,FISC_DAY_IN_MTH_NBR,FISC_DAY_IN_QTR_NBR,FISC_DAY_IN_YR_NBR,FISC_WK_IN_MTH_NBR,FISC_WK_IN_QTR_NBR,FISC_WK_IN_YR_NBR,FISC_LAST_DAY_IN_WK_IND,FISC_START_OF_WK_DT,FISC_EOW_DT,FISC_MTH_IN_QTR_NBR,FISC_MTH_IN_YR_NBR,FISC_YR_MTH_NBR,FISC_YR_MTH_NM,FISC_MTH_YR_NBR,FISC_MTH_YR_NM,FISC_MTH_ABRV_YR_NM,FISC_YR_MTH_ABRV_NM,FISC_LAST_DAY_IN_MTH_IND,FISC_START_OF_MTH_DT,FISC_EOM_DT,FISC_QTR_NBR,FISC_QTR_YR_NBR,FISC_QTR_YR_NM,FISC_YR_QTR_NBR,FISC_YR_QTR_NM,FISC_LAST_DAY_IN_QTR_IND,FISC_START_OF_QTR_DT,FISC_EOQ_DT,FISC_YR_NBR,FISC_LAST_DAY_IN_YR_IND,FISC_START_OF_YR_DT,FISC_EOY_DT)
VALUES (99981231,1,'9998-12-31','NOT AVAILABLE','NAV','NAV','NAV','NAV',0,0,98,98,998,998,98,98,98,0,'9998-12-31','9998-12-31',98,98,'NAV','NOT AVAILABLE','NAV','NOT AVAILABLE','NAV','NAV',0,'9998-12-31','9998-12-31',98,'NAV','NAV','NAV','NAV',0,'9998-12-31','9998-12-31',9998,0,'9998-12-31','9998-12-31',98,98,998,998,98,98,98,0,'9998-12-31','9998-12-31',98,98,'NAV','NOT AVAILABLE','NAV','NOT AVAILABLE','NAV','NAV',0,'9998-12-31','9998-12-31',98,'NAV','NAV','NAV','NAV',0,'9998-12-31','9998-12-31',9998,0,'9998-12-31','9998-12-31')
GO

INSERT INTO CORE.DATE_DIM (DATE_ID,SORT_ORD_NBR,DAY_DT,FULL_DT_DESC,DAY_NM,DAY_ABRV_NM,MTH_NM,MTH_ABRV_NM,WKDAY_IND,HOLIDAY_IND,CAL_DAY_IN_WK_NBR,CAL_DAY_IN_MTH_NBR,CAL_DAY_IN_QTR_NBR,CAL_DAY_IN_YR_NBR,CAL_WK_IN_MTH_NBR,CAL_WK_IN_QTR_NBR,CAL_WK_IN_YR_NBR,CAL_LAST_DAY_IN_WK_IND,CAL_START_OF_WK_DT,CAL_EOW_DT,CAL_MTH_IN_QTR_NBR,CAL_MTH_IN_YR_NBR,CAL_YR_MTH_NBR,CAL_YR_MTH_NM,CAL_MTH_YR_NBR,CAL_MTH_YR_NM,CAL_MTH_ABRV_YR_NM,CAL_YR_MTH_ABRV_NM,CAL_LAST_DAY_IN_MTH_IND,CAL_START_OF_MTH_DT,CAL_EOM_DT,CAL_QTR_NBR,CAL_QTR_YR_NBR,CAL_QTR_YR_NM,CAL_YR_QTR_NBR,CAL_YR_QTR_NM,CAL_LAST_DAY_IN_QTR_IND,CAL_START_OF_QTR_DT,CAL_EOQ_DT,CAL_YR_NBR,CAL_LAST_DAY_IN_YR_IND,CAL_START_OF_YR_DT,CAL_EOY_DT,FISC_DAY_IN_WK_NBR,FISC_DAY_IN_MTH_NBR,FISC_DAY_IN_QTR_NBR,FISC_DAY_IN_YR_NBR,FISC_WK_IN_MTH_NBR,FISC_WK_IN_QTR_NBR,FISC_WK_IN_YR_NBR,FISC_LAST_DAY_IN_WK_IND,FISC_START_OF_WK_DT,FISC_EOW_DT,FISC_MTH_IN_QTR_NBR,FISC_MTH_IN_YR_NBR,FISC_YR_MTH_NBR,FISC_YR_MTH_NM,FISC_MTH_YR_NBR,FISC_MTH_YR_NM,FISC_MTH_ABRV_YR_NM,FISC_YR_MTH_ABRV_NM,FISC_LAST_DAY_IN_MTH_IND,FISC_START_OF_MTH_DT,FISC_EOM_DT,FISC_QTR_NBR,FISC_QTR_YR_NBR,FISC_QTR_YR_NM,FISC_YR_QTR_NBR,FISC_YR_QTR_NM,FISC_LAST_DAY_IN_QTR_IND,FISC_START_OF_QTR_DT,FISC_EOQ_DT,FISC_YR_NBR,FISC_LAST_DAY_IN_YR_IND,FISC_START_OF_YR_DT,FISC_EOY_DT)
VALUES (99971231,2,'9997-12-31','UNKNOWN','UNK','UNK','UNK','UNK',0,0,97,97,997,997,97,97,97,0,'9997-12-31','9997-12-31',97,97,'UNK','UNKNOWN','UNK','UNKNOWN','UNK','UNK',0,'9997-12-31','9997-12-31',97,'UNK','UNK','UNK','UNK',0,'9997-12-31','9997-12-31',9997,0,'9997-12-31','9997-12-31',97,97,997,997,97,97,97,0,'9997-12-31','9997-12-31',97,97,'UNK','UNKNOWN','UNK','UNKNOWN','UNK','UNK',0,'9997-12-31','9997-12-31',97,'UNK','UNK','UNK','UNK',0,'9997-12-31','9997-12-31',9997,0,'9997-12-31','9997-12-31')
GO

INSERT INTO CORE.DATE_DIM (DATE_ID,SORT_ORD_NBR,DAY_DT,FULL_DT_DESC,DAY_NM,DAY_ABRV_NM,MTH_NM,MTH_ABRV_NM,WKDAY_IND,HOLIDAY_IND,CAL_DAY_IN_WK_NBR,CAL_DAY_IN_MTH_NBR,CAL_DAY_IN_QTR_NBR,CAL_DAY_IN_YR_NBR,CAL_WK_IN_MTH_NBR,CAL_WK_IN_QTR_NBR,CAL_WK_IN_YR_NBR,CAL_LAST_DAY_IN_WK_IND,CAL_START_OF_WK_DT,CAL_EOW_DT,CAL_MTH_IN_QTR_NBR,CAL_MTH_IN_YR_NBR,CAL_YR_MTH_NBR,CAL_YR_MTH_NM,CAL_MTH_YR_NBR,CAL_MTH_YR_NM,CAL_MTH_ABRV_YR_NM,CAL_YR_MTH_ABRV_NM,CAL_LAST_DAY_IN_MTH_IND,CAL_START_OF_MTH_DT,CAL_EOM_DT,CAL_QTR_NBR,CAL_QTR_YR_NBR,CAL_QTR_YR_NM,CAL_YR_QTR_NBR,CAL_YR_QTR_NM,CAL_LAST_DAY_IN_QTR_IND,CAL_START_OF_QTR_DT,CAL_EOQ_DT,CAL_YR_NBR,CAL_LAST_DAY_IN_YR_IND,CAL_START_OF_YR_DT,CAL_EOY_DT,FISC_DAY_IN_WK_NBR,FISC_DAY_IN_MTH_NBR,FISC_DAY_IN_QTR_NBR,FISC_DAY_IN_YR_NBR,FISC_WK_IN_MTH_NBR,FISC_WK_IN_QTR_NBR,FISC_WK_IN_YR_NBR,FISC_LAST_DAY_IN_WK_IND,FISC_START_OF_WK_DT,FISC_EOW_DT,FISC_MTH_IN_QTR_NBR,FISC_MTH_IN_YR_NBR,FISC_YR_MTH_NBR,FISC_YR_MTH_NM,FISC_MTH_YR_NBR,FISC_MTH_YR_NM,FISC_MTH_ABRV_YR_NM,FISC_YR_MTH_ABRV_NM,FISC_LAST_DAY_IN_MTH_IND,FISC_START_OF_MTH_DT,FISC_EOM_DT,FISC_QTR_NBR,FISC_QTR_YR_NBR,FISC_QTR_YR_NM,FISC_YR_QTR_NBR,FISC_YR_QTR_NM,FISC_LAST_DAY_IN_QTR_IND,FISC_START_OF_QTR_DT,FISC_EOQ_DT,FISC_YR_NBR,FISC_LAST_DAY_IN_YR_IND,FISC_START_OF_YR_DT,FISC_EOY_DT)
VALUES (99961231,3,'9996-12-31','ERROR VALUE','ERR','ERR','ERR','ERR',0,0,96,96,996,996,96,96,96,0,'9996-12-31','9996-12-31',96,96,'ERR','ERROR VALUE','ERR','ERROR VALUE','ERR','ERR',0,'9996-12-31','9996-12-31',96,'ERR','ERR','ERR','ERR',0,'9996-12-31','9996-12-31',9996,0,'9996-12-31','9996-12-31',96,96,996,996,96,96,96,0,'9996-12-31','9996-12-31',96,96,'ERR','ERROR VALUE','ERR','ERROR VALUE','ERR','ERR',0,'9996-12-31','9996-12-31',96,'ERR','ERR','ERR','ERR',0,'9996-12-31','9996-12-31',9996,0,'9996-12-31','9996-12-31')
GO

-- ###############################################################################
-- This section will insert the common "Date" information into the DATE_DIM table
-- ###############################################################################
DECLARE @i AS INT
DECLARE @Days AS INT
DECLARE @SortNbr AS INT
DECLARE @StartDate AS DATETIME
DECLARE @EndDate AS DATETIME
DECLARE @Date AS DATETIME
DECLARE @FiscalYearStartDate AS DATETIME
DECLARE @FiscalYearEndDate AS DATETIME
DECLARE @FiscalStartMonth AS INT
DECLARE @FiscalStartDay AS INT
SET @i = 1
SET @SortNbr = 9 -- this should be set to 9 to allow for additional custom rows.
SET @StartDate = '2001-01-01'
SET @EndDate = '2030-12-31'
SET @Date = @StartDate
SET @FiscalStartMonth = '10' -- Starting Fiscal Month
SET @FiscalStartDay = '01' -- Starting Fiscal Day
SET @FiscalYearStartDate = CAST(CAST(YEAR(@Date)-1 AS varchar) + '-' + CAST(@FiscalStartMonth AS varchar) + '-' + CAST(@FiscalStartDay AS varchar) AS DATETIME)
SET @FiscalYearEndDate = DATEADD(DAY,-1,(DATEADD(MONTH,12,@FiscalYearStartDate))) 
WHILE (@Date <= @EndDate)
	BEGIN
	  INSERT INTO CORE.DATE_DIM
		SELECT
			-- date key as integer [1]
			CAST(CAST(YEAR(@Date) AS NVARCHAR) + RIGHT('0' + CONVERT(VARCHAR(2), MONTH(@Date)), 2) + RIGHT('0' + CONVERT(VARCHAR(2), DAY(@Date)), 2) AS INT), 
			-- sort order number [2] 
	  		@SortNbr,
			-- date of day [3] 
   	 		@Date, 
			-- full date desc [4]
			UPPER(DATENAME(MONTH,@Date)) + ' ' + RIGHT('0' + CONVERT(VARCHAR(2), DAY(@Date)), 2) + ', ' + CAST(YEAR(@Date) AS NVARCHAR), 
			-- day name [5]
			UPPER(DATENAME(WEEKDAY,@Date)), 
			-- day abrv [6]
			UPPER(SUBSTRING(DATENAME(WEEKDAY,@Date),1,3)), 
	   		-- month name [7]
			UPPER(DATENAME(MONTH,@Date)), 
			-- month abrv name [8]
			UPPER(SUBSTRING(DATENAME(MONTH,@Date),1,3)), 
			-- Weekday Indicator [9]
			CASE 
				WHEN UPPER(DATENAME(WEEKDAY,@Date)) = 'SATURDAY' OR UPPER(DATENAME(WEEKDAY,@Date)) = 'SUNDAY' THEN 0
				ELSE 1
			END,
			-- Holiday ind - default 0 [10] 
			-- NOTE: the indicators below will be set to 1 based on US Holidays, comment out holidays that are not necessary or add new ones
			-- Holidays include: New Years, MLK, Good Friday, Memorial day, Independance, Labor day, Thanksgiving, Friday following Thanksgiving, Christmas Eve, Christmas Day
			CASE 
				-- New Years Day
				WHEN SUBSTRING(CONVERT(NVARCHAR(8),@Date,112),5,4) = '0101' AND (DATENAME(WEEKDAY,(@Date)) = 'MONDAY' OR DATENAME(WEEKDAY,(@Date)) = 'TUESDAY' OR DATENAME(WEEKDAY,(@Date)) = 'WEDNESDAY' OR DATENAME(WEEKDAY,(@Date)) = 'THURSDAY' OR DATENAME(WEEKDAY,(@Date)) = 'FRIDAY') THEN 1 
				-- Observed New Years Day if on a SUN
				WHEN SUBSTRING(CONVERT(NVARCHAR(8),@Date,112),5,4) = '0102' AND UPPER(DATENAME(WEEKDAY,(@Date))) = 'MONDAY' THEN 1   
				-- Observed New Years Day if on a SAT
				WHEN SUBSTRING(CONVERT(NVARCHAR(8),@Date,112),5,4) = '1231' AND UPPER(DATENAME(WEEKDAY,(@Date))) = 'FRIDAY' THEN 1  
				-- MLK Day: On November 2, 1983, President Ronald Reagan signed legislation establishing a legal holiday honoring the civil rights leader (born January 15)
				WHEN CAST(@Date AS DATE) = CAST(EDW.UTIL.udf_nthWeekDay(3,'MON',YEAR(@Date),1) AS DATE) AND YEAR(@Date) > 1982 THEN 1 
				 -- Good Friday: The Friday before Easter Sunday. 
				WHEN CAST(@Date AS DATE) = CAST(DATEADD(DAY,-2,(SELECT EDW.UTIL.udf_CalculateEaster(YEAR(@Date)))) AS DATE) THEN 1
				-- Memorial Day: The Uniform Holidays Act established a federal legal holiday, fixed on a Monday, beginning in 1971
				WHEN CAST(@Date AS DATE) = CAST(DATEADD(DAY,-7,EDW.UTIL.udf_nthWeekDay(1,'MON',YEAR(@Date),6)) AS DATE) AND YEAR(@Date) > 1970 THEN 1 
				-- Independence Day not on a weekend: The holiday was already widely observed throughout the nation when Congress declared it a federal legal holiday, in 1870.
				WHEN SUBSTRING(CONVERT(NVARCHAR(8),@Date,112),5,4) = '0704' AND (DATENAME(WEEKDAY,(@Date)) = 'MONDAY' OR DATENAME(WEEKDAY,(@Date)) = 'TUESDAY' OR DATENAME(WEEKDAY,(@Date)) = 'WEDNESDAY' OR DATENAME(WEEKDAY,(@Date)) = 'THURSDAY' OR DATENAME(WEEKDAY,(@Date)) = 'FRIDAY') THEN 1 
				-- Observed Independance Day if on a SUN
				WHEN SUBSTRING(CONVERT(NVARCHAR(8),@Date,112),5,4) = '0705' AND UPPER(DATENAME(WEEKDAY,(@Date))) = 'MONDAY' THEN 1 
				-- Observed Independance Day if on a SAT
				WHEN SUBSTRING(CONVERT(NVARCHAR(8),@Date,112),5,4) = '0703' AND UPPER(DATENAME(WEEKDAY,(@Date))) = 'FRIDAY' THEN 1  
				-- Labor Day: In 1894, President Grover Cleveland signed legislation establishing the federal holiday                        
				WHEN CAST(@Date AS DATE) = CAST(EDW.UTIL.udf_nthWeekDay(1,'MON',YEAR(@Date),9) AS DATE) THEN 1 
				-- Thanksgiving: In 1941, Congress moved the holiday from the last Thursday in November to the fourth Thursday
				WHEN CAST(@Date AS DATE) = CAST(EDW.UTIL.udf_nthWeekDay(4,'THU',YEAR(@Date),11) AS DATE) AND YEAR(@Date) > 1940 THEN 1
				-- Friday after Thanksgiving
				WHEN CAST(@Date AS DATE) = CAST(EDW.UTIL.udf_nthWeekDay(4,'FRI',YEAR(@Date),11) AS DATE) AND YEAR(@Date) > 1940 THEN 1 
				-- Christmas Eve day, not on a weekend
				WHEN SUBSTRING(CONVERT(NVARCHAR(8),@Date,112),5,4) = '1224' AND (DATENAME(WEEKDAY,(@Date)) = 'MONDAY' OR DATENAME(WEEKDAY,(@Date)) = 'TUESDAY' OR DATENAME(WEEKDAY,(@Date)) = 'WEDNESDAY' OR DATENAME(WEEKDAY,(@Date)) = 'THURSDAY' OR DATENAME(WEEKDAY,(@Date)) = 'FRIDAY') THEN 1 
				-- Christmas Eve Day, if on a SAT
				WHEN SUBSTRING(CONVERT(NVARCHAR(8),@Date,112),5,4) = '1223' AND UPPER(DATENAME(WEEKDAY,(@Date))) = 'FRIDAY' THEN 1  
				-- Christmas Eve Day, if on a SUN
				WHEN SUBSTRING(CONVERT(NVARCHAR(8),@Date,112),5,4) = '1222' AND UPPER(DATENAME(WEEKDAY,(@Date))) = 'FRIDAY' THEN 1  
				-- Christmas not on a weekend: Congress proclaimed Christmas a federal holiday in 1870.
				WHEN SUBSTRING(CONVERT(NVARCHAR(8),@Date,112),5,4) = '1225' AND (DATENAME(WEEKDAY,(@Date)) = 'MONDAY' OR DATENAME(WEEKDAY,(@Date)) = 'TUESDAY' OR DATENAME(WEEKDAY,(@Date)) = 'WEDNESDAY' OR DATENAME(WEEKDAY,(@Date)) = 'THURSDAY' OR DATENAME(WEEKDAY,(@Date)) = 'FRIDAY') THEN 1 
				-- Christmas if on a SAT
				WHEN SUBSTRING(CONVERT(NVARCHAR(8),@Date,112),5,4) = '1227' AND UPPER(DATENAME(WEEKDAY,(@Date))) = 'MONDAY' THEN 1  
				-- Christmas if on a SUN
				WHEN SUBSTRING(CONVERT(NVARCHAR(8),@Date,112),5,4) = '1226' AND UPPER(DATENAME(WEEKDAY,(@Date))) = 'MONDAY' THEN 1  
				-- -------------------------------------------------------------------------------------------------------------------------------
				-- Below are generally only bank and/or school holidays
				-- Columbus Day: he Uniform Holidays Act, passed by Congress in 1968 to take effect in 1971, fixed the holiday on a Monday
				WHEN CAST(@Date AS DATE) = CAST(EDW.UTIL.udf_nthWeekDay(2,'MON',YEAR(@Date),10) AS DATE) AND YEAR(@Date) > 1970 THEN 1 
				-- Washington's Birthday / Presidents Day: The Uniform Holidays Act, passed by Congress in 1968 to take effect in 1971, fixed the holiday on a Monday
				WHEN CAST(@Date AS DATE) = CAST(EDW.UTIL.udf_nthWeekDay(3,'MON',YEAR(@Date),2) AS DATE) AND YEAR(@Date) > 1970 THEN 1 
				-- Veterans Day not on a weekend:  Congress proclaimed a federal holiday in 1938 (originally Armistice Day - Name changed in 1954))
				WHEN SUBSTRING(CONVERT(NVARCHAR(8),@Date,112),5,4) = '1111' AND (DATENAME(WEEKDAY,(@Date)) = 'MONDAY' OR DATENAME(WEEKDAY,(@Date)) = 'TUESDAY' OR DATENAME(WEEKDAY,(@Date)) = 'WEDNESDAY' OR DATENAME(WEEKDAY,(@Date)) = 'THURSDAY' OR DATENAME(WEEKDAY,(@Date)) = 'FRIDAY') AND YEAR(@Date) > 1937 THEN 1 
				-- Veterans Day if on a SUN
				WHEN SUBSTRING(CONVERT(NVARCHAR(8),@Date,112),5,4) = '1112' AND UPPER(DATENAME(WEEKDAY,(@Date))) = 'MONDAY' AND YEAR(@Date) > 1937 THEN 1   
				-- Veterans Day if on a SAT
				WHEN SUBSTRING(CONVERT(NVARCHAR(8),@Date,112),5,4) = '1110' AND UPPER(DATENAME(WEEKDAY,(@Date))) = 'FRIDAY' AND YEAR(@Date) > 1937 THEN 1  
				-- -------------------------------------------------------------------------------------------------------------------------------
				ELSE 0   
			END,
			-- Calendar day of week number [11]																			
			CASE 
				WHEN UPPER(DATENAME(WEEKDAY,@Date)) = 'MONDAY' THEN 1
				WHEN UPPER(DATENAME(WEEKDAY,@Date)) = 'TUESDAY' THEN 2
				WHEN UPPER(DATENAME(WEEKDAY,@Date)) = 'WEDNESDAY' THEN 3
				WHEN UPPER(DATENAME(WEEKDAY,@Date)) = 'THURSDAY' THEN 4
				WHEN UPPER(DATENAME(WEEKDAY,@Date)) = 'FRIDAY' THEN 5
				WHEN UPPER(DATENAME(WEEKDAY,@Date)) = 'SATURDAY' THEN 6
				WHEN UPPER(DATENAME(WEEKDAY,@Date)) = 'SUNDAY' THEN 7
			END,
			-- day in month nbr [12] 
			DAY(@Date),
			-- day in qtr nbr [13] 
			DATEDIFF(DAY,CONVERT(DATE,DATEADD(QUARTER,DATEDIFF(QUARTER,0,@Date),0)),@Date) + 1, 
   			-- day in year nbr [14]
			DATEPART(DAYOFYEAR,@Date),
			-- week in month nbr [15] 
   			DATEDIFF(WEEK,CAST(CAST(DATEPART(MONTH,@Date) AS NVARCHAR(2)) + '/01/' + CAST(DATEPART(YEAR,@Date) AS NVARCHAR(4)) AS SMALLDATETIME),@Date) + 1, 
			-- week in qtr nbr [16]
			CASE 
				WHEN DATEPART(MONTH,@Date) >= 1 AND DATEPART(MONTH,@Date) <= 3 THEN DATEDIFF(WEEK,CAST('01/01/' + CAST(DATEPART(YEAR,@Date) AS NVARCHAR(4)) AS SMALLDATETIME),@Date) + 1
				WHEN DATEPART(MONTH,@Date) >= 4 AND DATEPART(MONTH,@Date) <= 6 THEN DATEDIFF(WEEK,CAST('04/01/' + CAST(DATEPART(YEAR,@Date) AS NVARCHAR(4)) AS SMALLDATETIME),@Date) + 1
				WHEN DATEPART(MONTH,@Date) >= 7 AND DATEPART(MONTH,@Date) <= 9 THEN DATEDIFF(WEEK,CAST('07/01/' + CAST(DATEPART(YEAR,@Date) AS NVARCHAR(4)) AS SMALLDATETIME),@Date) + 1
				ELSE DATEDIFF(WEEK,CAST('10/01/' + CAST(DATEPART(YEAR,@Date) AS NVARCHAR(4)) AS SMALLDATETIME),@Date) + 1
			END,
			-- week in year nbr [17] 
   			DATEPART(WEEK,@Date), 
			-- indicate last day of week [18]
			CASE 
				WHEN UPPER(DATENAME(WEEKDAY,@Date)) = 'SATURDAY' THEN 1
				ELSE 0
			END,
			-- start of week date [19] 
			DATEADD(DAY,-(DATEPART(WEEKDAY,@Date-1)-1),@Date),
			-- end of week date [20]
			DATEADD(DAY,(7-DATEPART(WEEKDAY,@Date-1)),@Date),
			-- month in qtr nbr [21]
			CASE 
				WHEN DATEPART(MONTH,@Date) >= 1 AND DATEPART(MONTH,@Date) <= 3 THEN DATEDIFF(MONTH,CAST('01/01/' + CAST(DATEPART(YEAR,@Date) AS NVARCHAR(4)) AS SMALLDATETIME),@Date) + 1
				WHEN DATEPART(MONTH,@Date) >= 4 AND DATEPART(MONTH,@Date) <= 6 THEN DATEDIFF(MONTH,CAST('04/01/' + CAST(DATEPART(YEAR,@Date) AS NVARCHAR(4)) AS SMALLDATETIME),@Date) + 1
				WHEN DATEPART(MONTH,@Date) >= 7 AND DATEPART(MONTH,@Date) <= 9 THEN DATEDIFF(MONTH,CAST('07/01/' + CAST(DATEPART(YEAR,@Date) AS NVARCHAR(4)) AS SMALLDATETIME),@Date) + 1
				ELSE DATEDIFF(MONTH,CAST('10/01/' + CAST(DATEPART(YEAR,@Date) AS NVARCHAR(4)) AS SMALLDATETIME),@Date) + 1
			END,
			-- month in year nbr [22] 
   			MONTH(@Date),
			-- year-month nbr [23] 
   			CAST(YEAR(@Date) AS NVARCHAR) + '-' + RIGHT('0' + CONVERT(VARCHAR(2),MONTH(@Date)),2), 
   			-- year-month name [24]
			CAST(YEAR(@Date) AS NVARCHAR) + '-' + UPPER(DATENAME(MONTH,@Date)), 
   			-- month-year nbr [25]
			RIGHT('0' + CONVERT(VARCHAR(2),MONTH(@Date)),2) + '-' + CAST(YEAR(@Date) AS NVARCHAR), 
   			-- month-year name [26]
			UPPER(DATENAME(MONTH,@Date)) + '-' + CAST(YEAR(@Date) AS NVARCHAR), 
   			-- month-year abrv [27]
			UPPER(SUBSTRING(DATENAME(MONTH,@Date),1,3)) + '-' + CAST(YEAR(@Date) AS NVARCHAR), 
   			-- year-month abrv [28]
			CAST(YEAR(@Date) AS NVARCHAR) + '-' + UPPER(SUBSTRING(DATENAME(MONTH,@Date),1,3)), 
			-- last day in month ind [29]
			CASE
				WHEN CAST(@Date AS DATE) = CAST(DATEADD(MS,-3,DATEADD(MONTH,DATEDIFF(MONTH,0,@Date)+1,0)) AS DATE) THEN 1
				ELSE 0	 				 				  	  		   		
			END,
			-- start of mnth date [30] 	
			CAST(DATEADD(MONTH,DATEDIFF(MONTH,0,@Date),0) AS DATE), 
			-- end of mnth date [31]
			CAST(DATEADD(MS,-3,DATEADD(MONTH,DATEDIFF(MONTH,0,@Date)+1,0)) AS DATE), 
			 -- quarter number [32]
			DATENAME(QUARTER,@Date),
			-- quarter-year nbr [33]
			DATENAME(QUARTER,@Date) + '-' + CAST(YEAR(@Date) AS NVARCHAR), 
			-- quarter-year nm [34]
			'Q' + DATENAME(QUARTER,@Date) + '-' + CAST(YEAR(@Date) AS NVARCHAR), 
			-- quarter-year nbr [35]
			CAST(YEAR(@Date) AS NVARCHAR) + '-' + DATENAME(QUARTER,@Date), 
			-- quarter-year name [36]
			CAST(YEAR(@Date) AS NVARCHAR) + '-Q' + DATENAME(QUARTER,@Date), 
			-- last day in qtr ind [37]
			CASE
				WHEN CAST(@Date AS DATE) = DATEADD(DAY,-1,DATEADD(MONTH,3,CAST(DATEADD(QUARTER,DATEDIFF(QUARTER,0,@Date),0) AS DATE))) THEN 1
				ELSE 0	 				 				  	  		   			
			END, 
			-- start date in qtr [38]
			CAST(DATEADD(QUARTER,DATEDIFF(QUARTER,0,@Date),0) AS DATE), 
			-- end date of qtr [39]
			DATEADD(DAY,-1,DATEADD(MONTH,3,CAST(DATEADD(QUARTER,DATEDIFF(QUARTER,0,@Date),0) AS DATE))), 
			-- year nbr   [40]
			YEAR(@Date), 
			-- last day in year ind [41]
			CASE
		 		WHEN MONTH(@Date) = 12 AND DAY(@Date) = 31 THEN 1
				ELSE 0
			END, 
			-- start of year date [42]
			CAST(DATEADD(YEAR,DATEDIFF(YEAR,0,@Date),0) AS DATE), 
			-- end of year date [43]
			DATEADD(DAY,-1,DATEADD(YEAR,1,CAST(DATEADD(YEAR,DATEDIFF(YEAR,0,@Date),0) AS DATE))), 
			-- Fiscal day of week number [44]
			CASE 
				WHEN UPPER(DATENAME(WEEKDAY,@Date)) = 'MONDAY' THEN 1
				WHEN UPPER(DATENAME(WEEKDAY,@Date)) = 'TUESDAY' THEN 2
				WHEN UPPER(DATENAME(WEEKDAY,@Date)) = 'WEDNESDAY' THEN 3
				WHEN UPPER(DATENAME(WEEKDAY,@Date)) = 'THURSDAY' THEN 4
				WHEN UPPER(DATENAME(WEEKDAY,@Date)) = 'FRIDAY' THEN 5
				WHEN UPPER(DATENAME(WEEKDAY,@Date)) = 'SATURDAY' THEN 6
				WHEN UPPER(DATENAME(WEEKDAY,@Date)) = 'SUNDAY' THEN 7
			END, 
			-- Fiscal day in month nbr [45]
			DAY(@Date), 
			-- Fiscal day in qtr nbr [46]
			DATEDIFF(DAY,CONVERT(DATE,DATEADD(QUARTER,DATEDIFF(QUARTER,0,@Date),0)),@Date) + 1, 
   			-- Fiscal day in year nbr [47]
			DATEDIFF(DAY,@FiscalYearStartDate,@Date), 
   			-- Fiscal week in month nbr [48]
			DATEDIFF(WEEK,CAST(CAST(DATEPART(MONTH,@Date) AS NVARCHAR(2)) + '/01/' + CAST(DATEPART(YEAR,@Date) AS NVARCHAR(4)) AS SMALLDATETIME),@Date) + 1, 
			-- Fiscal week in qtr nbr [49]
			CASE 
				WHEN DATEPART(MONTH,@Date) >= 1 AND DATEPART(MONTH,@Date) <= 3 THEN DATEDIFF(WEEK,CAST('01/01/' + CAST(DATEPART(YEAR,@Date) AS NVARCHAR(4)) AS SMALLDATETIME),@Date) + 1
				WHEN DATEPART(MONTH,@Date) >= 4 AND DATEPART(MONTH,@Date) <= 6 THEN DATEDIFF(WEEK,CAST('04/01/' + CAST(DATEPART(YEAR,@Date) AS NVARCHAR(4)) AS SMALLDATETIME),@Date) + 1
				WHEN DATEPART(MONTH,@Date) >= 7 AND DATEPART(MONTH,@Date) <= 9 THEN DATEDIFF(WEEK,CAST('07/01/' + CAST(DATEPART(YEAR,@Date) AS NVARCHAR(4)) AS SMALLDATETIME),@Date) + 1
				ELSE DATEDIFF(WEEK,CAST('10/01/' + CAST(DATEPART(YEAR,@Date) AS NVARCHAR(4)) AS SMALLDATETIME),@Date) + 1
			END, 
   			-- Fiscal week in year nbr [50]
			CASE
				WHEN DATEPART(MONTH,@Date) >= 1 AND DATEPART(MONTH,@Date) <= 9 THEN DATEPART(WEEK,@Date) + DATEDIFF(WEEK,@FiscalYearStartDate,DATEADD(DAY,-1,DATEADD(MONTH,3,@FiscalYearStartDate)))
				ELSE DATEDIFF(WEEK,@FiscalYearStartDate,@Date)+1
			END,
			-- indicate Fiscal last day of week [51]
			CASE 
				WHEN UPPER(DATENAME(WEEKDAY,@Date)) = 'SATURDAY' THEN 1
				ELSE 0
			END, 
			-- Fiscal start of week date [52]
			DATEADD(DAY,-(DATEPART(WEEKDAY,@Date-1)-1),@Date),
			-- Fiscal end of week date [53]
			DATEADD(DAY,(7-DATEPART(WEEKDAY,@Date-1)),@Date),
			-- Fiscal month in qtr nbr [54]
			CASE 
				WHEN DATEPART(MONTH,@Date) >= 1 AND DATEPART(MONTH,@Date) <= 3 THEN DATEDIFF(MONTH,CAST('01/01/' + CAST(DATEPART(YEAR,@Date) AS NVARCHAR(4)) AS SMALLDATETIME),@Date) + 1
				WHEN DATEPART(MONTH,@Date) >= 4 AND DATEPART(MONTH,@Date) <= 6 THEN DATEDIFF(MONTH,CAST('04/01/' + CAST(DATEPART(YEAR,@Date) AS NVARCHAR(4)) AS SMALLDATETIME),@Date) + 1
				WHEN DATEPART(MONTH,@Date) >= 7 AND DATEPART(MONTH,@Date) <= 9 THEN DATEDIFF(MONTH,CAST('07/01/' + CAST(DATEPART(YEAR,@Date) AS NVARCHAR(4)) AS SMALLDATETIME),@Date) + 1
				ELSE DATEDIFF(MONTH,CAST('10/01/' + CAST(DATEPART(YEAR,@Date) AS NVARCHAR(4)) AS SMALLDATETIME),@Date) + 1
			END, 
   			-- Fiscal month in year nbr [55]
			CASE
				WHEN DATEPART(MONTH,@Date) >= 1 AND DATEPART(MONTH,@Date) <= 9 THEN 3 + DATEPART(MONTH,@Date)
				ELSE DATEPART(MONTH,@Date) - 9
			END, 
   			-- Fiscal year-month nbr [56]
			CAST(YEAR(@FiscalYearStartDate) AS NVARCHAR) + '-' + RIGHT('0' + CONVERT(VARCHAR(2),MONTH(@Date)),2), 
   			-- Fiscal year-month name [57]
			CAST(YEAR(@FiscalYearStartDate) AS NVARCHAR) + '-' + UPPER(DATENAME(MONTH,@Date)), 
   			-- Fiscal month-year nbr [58]
			RIGHT('0' + CONVERT(VARCHAR(2),MONTH(@Date)),2) + '-' + CAST(YEAR(@FiscalYearStartDate) AS NVARCHAR), 
   			-- Fiscal month-year name [59]
			UPPER(DATENAME(MONTH,@Date)) + '-' + CAST(YEAR(@FiscalYearStartDate) AS NVARCHAR), 
   			-- Fiscal month-year abrv [60]
			UPPER(SUBSTRING(DATENAME(MONTH,@Date),1,3)) + '-' + CAST(YEAR(@FiscalYearStartDate) AS NVARCHAR), 
   			-- Fiscal year-month abrv [61]
			CAST(YEAR(@FiscalYearStartDate) AS NVARCHAR) + '-' + UPPER(SUBSTRING(DATENAME(MONTH,@Date),1,3)), 
			-- last Fiscal day in month ind [62]
			CASE
				WHEN CAST(@Date AS DATE) = CAST(DATEADD(MS,-3,DATEADD(MONTH,DATEDIFF(MONTH,0,@Date)+1,0)) AS DATE) THEN 1
				ELSE 0	 				 				  	  		   		
			END, 	
			-- Fiscal start of mnth date [63]
			CAST(DATEADD(MONTH,DATEDIFF(MONTH,0,@Date),0) AS DATE), 
			-- Fiscal end of mnth date [64]
			CAST(DATEADD(MS,-3,DATEADD(MONTH,DATEDIFF(MONTH,0,@Date)+1,0)) AS DATE), 
			-- Fiscal quarter number [65]
			CASE
				WHEN DATEPART(MONTH,@Date) >= 1 AND DATEPART(MONTH,@Date) <= 9 THEN DATEPART(QUARTER,@Date) + DATEDIFF(QUARTER,DATEADD(DAY,-1,DATEADD(MONTH,3,@FiscalYearStartDate)),@FiscalYearStartDate) + 1 
				ELSE 1
			END, 
			-- Fiscal quarter-year nbr [66]
			CASE
				WHEN DATEPART(MONTH,@Date) >= 1 AND DATEPART(MONTH,@Date) <= 9 THEN CAST(DATEPART(QUARTER,@Date) + DATEDIFF(QUARTER,@FiscalYearStartDate,DATEADD(DAY,-1,DATEADD(MONTH,3,@FiscalYearStartDate)) + 1) AS NVARCHAR) + '-' + CAST(YEAR(@FiscalYearStartDate) AS NVARCHAR)
				ELSE '1-' + CAST(YEAR(@FiscalYearStartDate) AS NVARCHAR)
			END,
			-- Fiscal quarter-year nm [67]
			CASE
				WHEN DATEPART(MONTH,@Date) >= 1 AND DATEPART(MONTH,@Date) <= 9 THEN 'Q' + CAST(DATEPART(QUARTER,@Date) + DATEDIFF(QUARTER,@FiscalYearStartDate,DATEADD(DAY,-1,DATEADD(MONTH,3,@FiscalYearStartDate)) + 1) AS NVARCHAR) + '-' + CAST(YEAR(@FiscalYearStartDate) AS NVARCHAR)
				ELSE 'Q1-' + CAST(YEAR(@FiscalYearStartDate) AS NVARCHAR)
			END,
			-- Fiscal quarter-year nbr [68]
			CASE
				WHEN DATEPART(MONTH,@Date) >= 1 AND DATEPART(MONTH,@Date) <= 9 THEN CAST(YEAR(@FiscalYearStartDate) AS NVARCHAR) + '-' + CAST(DATEPART(QUARTER,@Date) + DATEDIFF(QUARTER,@FiscalYearStartDate,DATEADD(DAY,-1,DATEADD(MONTH,3,@FiscalYearStartDate)) + 1) AS NVARCHAR)
				ELSE CAST(YEAR(@FiscalYearStartDate) AS NVARCHAR) + '-1'
			END,
			-- Fiscal quarter-year name [69]
			CASE
				WHEN DATEPART(MONTH,@Date) >= 1 AND DATEPART(MONTH,@Date) <= 9 THEN CAST(YEAR(@FiscalYearStartDate) AS NVARCHAR) + '-Q' + CAST(DATEPART(QUARTER,@Date) + DATEDIFF(QUARTER,@FiscalYearStartDate,DATEADD(DAY,-1,DATEADD(MONTH,3,@FiscalYearStartDate)) + 1) AS NVARCHAR) 
				ELSE CAST(YEAR(@FiscalYearStartDate) AS NVARCHAR) + '-Q1'
			END,
			-- Fiscal last day in qtr ind [70]
			CASE
				WHEN CAST(@Date AS DATE) = DATEADD(DAY,-1,DATEADD(MONTH,3,CAST(DATEADD(QUARTER,DATEDIFF(QUARTER,0,@Date),0) AS DATE))) THEN 1
				ELSE 0	 				 				  	  		   			
			END, 
			-- Fiscal start date in qtr [71]
			CAST(DATEADD(QUARTER,DATEDIFF(QUARTER,0,@Date),0) AS DATE), 
			-- Fiscal end date of qtr [72]
			DATEADD(DAY,-1,DATEADD(MONTH,3,CAST(DATEADD(QUARTER,DATEDIFF(QUARTER,0,@Date),0) AS DATE))), 
			-- Fiscal year nbr [73]
			YEAR(@FiscalYearStartDate), 
			-- last Fiscal day in year ind [74]
			CASE
		 		WHEN @Date = @FiscalYearEndDate THEN 1
				ELSE 0
			END, 
			-- Fiscal start of year date [75]
			@FiscalYearStartDate, 
			-- Fiscal end of year date [76]
			@FiscalYearEndDate
 
	SET @i = @i + 1
	SET @Date = DATEADD(DAY,1,@Date)
	
	IF @Date > @FiscalYearEndDate
		BEGIN
			SET @FiscalYearStartDate = DATEADD(YEAR,1,@FiscalYearStartDate)
			SET @FiscalYearEndDate = DATEADD(YEAR,1,@FiscalYearEndDate)
		END
END