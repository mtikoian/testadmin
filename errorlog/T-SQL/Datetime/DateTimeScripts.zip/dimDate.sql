USE EDW
GO

-- ###############################################################################
-- Create a schema to store functions
-- ###############################################################################
IF NOT EXISTS (SELECT * FROM sys.schemas (NOLOCK) WHERE name = 'util')
BEGIN
	EXEC('CREATE SCHEMA [util]')
END
GO

-- ###############################################################################
-- Drop util.udf_nthWeekDay, if it exists
-- ###############################################################################
IF EXISTS (SELECT * FROM sysobjects (NOLOCK) WHERE id = object_id(N'util.udf_nthWeekDay') AND xtype IN (N'FN', N'IF', N'TF'))
BEGIN
	DROP FUNCTION util.udf_nthWeekDay
END
GO

-- ###############################################################################
-- Create util.udf_nthWeekDay function to get dates for holidays on a specific day of the month
-- ###############################################################################
CREATE FUNCTION util.udf_nthWeekDay
(
  @n INT, 
  @weekDay CHAR(3),
  @year INT, 
  @month INT
)
RETURNS DATE
AS
BEGIN
  DECLARE @date DATE,
    @dow INT,
    @offset INT,
    @wd INT;
    
  SELECT @wd = CASE @weekDay
      WHEN 'SUN' THEN 1
      WHEN 'MON' THEN 2
      WHEN 'TUE' THEN 3
      WHEN 'WED' THEN 4
      WHEN 'THU' THEN 5
      WHEN 'FRI' THEN 6
      WHEN 'SAT' THEN 7
    END,
    @date = CAST
    (
      CAST(@year AS VARCHAR(4)) +
      RIGHT
      (
        '0' + CAST
        (
          @month AS VARCHAR(2)
        ), 2
      ) +
      '01' AS DATE
    ),
    @dow = DATEPART(dw, @date),
    @offset = @wd - @dow,
    @date = DATEADD(day, @offset + (@n - CASE WHEN @offset >= 0 THEN 1 ELSE 0 END) * 7, @date);
  RETURN @date;
END;
GO

-- ###############################################################################
-- Drop util.udf_CalculateEaster, if it exists
-- ###############################################################################
IF EXISTS (SELECT * FROM sysobjects (NOLOCK) WHERE id = object_id(N'util.udf_CalculateEaster') AND xtype IN (N'FN', N'IF', N'TF'))
BEGIN
	DROP FUNCTION util.udf_CalculateEaster
END
GO

-- ###############################################################################
-- Create util.udf_CalculateEaster function to return the date of Easter for any year. 
-- Uses calculations from NASA to determine lunar calendar which Easter is based on.
-- ###############################################################################
CREATE FUNCTION util.udf_CalculateEaster 
(
  @Year INT
)
RETURNS DATE
AS
BEGIN
    DECLARE @Date DATE,
    @c INT, 
    @n INT, 
    @i INT, 
    @k INT, 
    @j INT, 
    @l INT, 
    @m INT, 
    @d INT;

    SELECT @n = @Year - 19 * (@Year / 19),
    @c = @Year / 100,
    @k = (@c - 17) / 25,
    @i = @c - @c / 4 - (@c - @k) / 3 + 19 * @n + 15,
    @i = @i - 30 * (@i / 30),
    @i = @i - (@i / 28) * (1 - (@i / 28) * (29 / (@i + 1)) * ((21 - @n) / 11)),
    @j = @Year + @Year / 4 + @i + 2 - @c + @c / 4,
    @j = @j - 7 * (@j / 7),
    @l = @i - @j,
    @m = 3 + (@l + 40) / 44,
    @d = @l + 28 - 31 * (@m / 4),
    @Date = CAST
    (
      CAST(@Year AS CHAR(4)) + 
      RIGHT
      (
        '0' + CAST
        (
          @m AS VARCHAR(2)
        ), 2
      ) + 
      RIGHT
      (
        '0' +CAST
        (
          @d AS VARCHAR(2)
        ), 2
      ) AS DATE
    );
    RETURN @Date;
END;
GO

-- ###############################################################################
-- Create dm schema that all Date Dimension tables will be stored in.
-- ###############################################################################
IF NOT EXISTS (SELECT * FROM sys.schemas (NOLOCK) WHERE name = 'dm')
BEGIN
	EXEC('CREATE SCHEMA [dm]')
END
GO

-- ###############################################################################
-- Drop table dimDate, if it currently exists and all Exptended Properties that go with it.
-- ###############################################################################
IF EXISTS (SELECT * FROM sys.tables (NOLOCK) WHERE name = 'dimDate')
BEGIN
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimDate'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimDate', @level2type=N'COLUMN',@level2name=N'FiscalEndOfYearDate'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimDate', @level2type=N'COLUMN',@level2name=N'FiscalStartOfYearDate'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimDate', @level2type=N'COLUMN',@level2name=N'FiscalLastDayInYearInd'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimDate', @level2type=N'COLUMN',@level2name=N'FiscalYearNum'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimDate', @level2type=N'COLUMN',@level2name=N'FiscalEndOfQtrDate'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimDate', @level2type=N'COLUMN',@level2name=N'FiscalStartOfQtrDate'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimDate', @level2type=N'COLUMN',@level2name=N'FiscalLastDayInQtrInd'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimDate', @level2type=N'COLUMN',@level2name=N'FiscalYearQtrDesc'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimDate', @level2type=N'COLUMN',@level2name=N'FiscalYearQtrNum'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimDate', @level2type=N'COLUMN',@level2name=N'FiscalQtrYearDesc'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimDate', @level2type=N'COLUMN',@level2name=N'FiscalQtrYearNum'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimDate', @level2type=N'COLUMN',@level2name=N'FiscalQtrNum'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimDate', @level2type=N'COLUMN',@level2name=N'FiscalEndOfMonthDate'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimDate', @level2type=N'COLUMN',@level2name=N'FiscalStartOfMonthDate'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimDate', @level2type=N'COLUMN',@level2name=N'FiscalLastDayInMonthInd'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimDate', @level2type=N'COLUMN',@level2name=N'FiscalYearMonth3Desc'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimDate', @level2type=N'COLUMN',@level2name=N'FiscalMonth3YearDesc'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimDate', @level2type=N'COLUMN',@level2name=N'FiscalMonthYearDesc'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimDate', @level2type=N'COLUMN',@level2name=N'FiscalMonthYearNum'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimDate', @level2type=N'COLUMN',@level2name=N'FiscalYearMonthDesc'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimDate', @level2type=N'COLUMN',@level2name=N'FiscalYearMonthNum'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimDate', @level2type=N'COLUMN',@level2name=N'FiscalMonthInYearNum'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimDate', @level2type=N'COLUMN',@level2name=N'FiscalMonthInQtrNum'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimDate', @level2type=N'COLUMN',@level2name=N'FiscalEndOfWeekDate'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimDate', @level2type=N'COLUMN',@level2name=N'FiscalStartOfWeekDate'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimDate', @level2type=N'COLUMN',@level2name=N'FiscalLastDayInWeekInd'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimDate', @level2type=N'COLUMN',@level2name=N'FiscalWeekInYearNum'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimDate', @level2type=N'COLUMN',@level2name=N'FiscalWeekInQtrNum'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimDate', @level2type=N'COLUMN',@level2name=N'FiscalWeekInMonthNum'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimDate', @level2type=N'COLUMN',@level2name=N'FiscalDayInYearNum'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimDate', @level2type=N'COLUMN',@level2name=N'FiscalDayInQtrNum'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimDate', @level2type=N'COLUMN',@level2name=N'FiscalDayInMonthNum'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimDate', @level2type=N'COLUMN',@level2name=N'FiscalDayInWeekNum'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimDate', @level2type=N'COLUMN',@level2name=N'CalendarEndOfYearDate'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimDate', @level2type=N'COLUMN',@level2name=N'CalendarStartOfYearDate'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimDate', @level2type=N'COLUMN',@level2name=N'CalendarLastDayInYearInd'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimDate', @level2type=N'COLUMN',@level2name=N'CalendarYearNum'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimDate', @level2type=N'COLUMN',@level2name=N'CalendarEndOfQtrDate'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimDate', @level2type=N'COLUMN',@level2name=N'CalendarStartOfQtrDate'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimDate', @level2type=N'COLUMN',@level2name=N'CalendarLastDayInQtrInd'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimDate', @level2type=N'COLUMN',@level2name=N'CalendarYearQtrDesc'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimDate', @level2type=N'COLUMN',@level2name=N'CalendarYearQtrNum'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimDate', @level2type=N'COLUMN',@level2name=N'CalendarQtrYearDesc'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimDate', @level2type=N'COLUMN',@level2name=N'CalendarQtrYearNum'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimDate', @level2type=N'COLUMN',@level2name=N'CalendarQtrNum'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimDate', @level2type=N'COLUMN',@level2name=N'CalendarEndOfMonthDate'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimDate', @level2type=N'COLUMN',@level2name=N'CalendarStartOfMonthDate'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimDate', @level2type=N'COLUMN',@level2name=N'CalendarLastDayInMonthInd'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimDate', @level2type=N'COLUMN',@level2name=N'CalendarYearMonth3Desc'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimDate', @level2type=N'COLUMN',@level2name=N'CalendarMonth3YearDesc'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimDate', @level2type=N'COLUMN',@level2name=N'CalendarMonthYearDesc'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimDate', @level2type=N'COLUMN',@level2name=N'CalendarMonthYearNum'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimDate', @level2type=N'COLUMN',@level2name=N'CalendarYearMonthDesc'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimDate', @level2type=N'COLUMN',@level2name=N'CalendarYearMonthNum'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimDate', @level2type=N'COLUMN',@level2name=N'CalendarMonthInYearNum'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimDate', @level2type=N'COLUMN',@level2name=N'CalendarMonthInQtrNum'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimDate', @level2type=N'COLUMN',@level2name=N'CalendarEndOfWeekDate'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimDate', @level2type=N'COLUMN',@level2name=N'CalendarStartOfWeekDate'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimDate', @level2type=N'COLUMN',@level2name=N'CalendarLastDayInWeekInd'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimDate', @level2type=N'COLUMN',@level2name=N'CalendarWeekInYearNum'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimDate', @level2type=N'COLUMN',@level2name=N'CalendarWeekInQtrNum'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimDate', @level2type=N'COLUMN',@level2name=N'CalendarWeekInMonthNum'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimDate', @level2type=N'COLUMN',@level2name=N'CalendarDayInYearNum'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimDate', @level2type=N'COLUMN',@level2name=N'CalendarDayInQtrNum'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimDate', @level2type=N'COLUMN',@level2name=N'CalendarDayInMonthNum'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimDate', @level2type=N'COLUMN',@level2name=N'CalendarDayInWeekNum'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimDate', @level2type=N'COLUMN',@level2name=N'HolidayDesc'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimDate', @level2type=N'COLUMN',@level2name=N'HolidayInd'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimDate', @level2type=N'COLUMN',@level2name=N'WeekdayInd'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimDate', @level2type=N'COLUMN',@level2name=N'Month3Desc'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimDate', @level2type=N'COLUMN',@level2name=N'MonthDesc'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimDate', @level2type=N'COLUMN',@level2name=N'Day3Desc'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimDate', @level2type=N'COLUMN',@level2name=N'DayDesc'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimDate', @level2type=N'COLUMN',@level2name=N'DayDateDesc'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimDate', @level2type=N'COLUMN',@level2name=N'DayDate'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimDate', @level2type=N'COLUMN',@level2name=N'DatePK'
	DROP TABLE [dm].[dimDate]
END
GO

-- ###############################################################################
-- Create table dm.dimDate
-- ###############################################################################
CREATE TABLE [dm].[dimDate] (
       DatePK INT NOT NULL,
       DayDate DATE NOT NULL,
       DayDateDesc VARCHAR(18) NOT NULL,
       DayDesc VARCHAR(9) NOT NULL,
       Day3Desc VARCHAR(3) NOT NULL,
       MonthDesc VARCHAR(9) NOT NULL,
       Month3Desc VARCHAR(3) NOT NULL,
       WeekdayInd BIT NOT NULL,
       HolidayInd BIT NOT NULL,
	   HolidayDesc VARCHAR(50) NULL,
       CalendarDayInWeekNum	INT NOT NULL,
       CalendarDayInMonthNum INT NOT NULL,
       CalendarDayInQtrNum INT NOT NULL,
       CalendarDayInYearNum INT NOT NULL,
       CalendarWeekInMonthNum INT NOT NULL,
       CalendarWeekInQtrNum INT NOT NULL,
       CalendarWeekInYearNum INT NOT NULL,
       CalendarLastDayInWeekInd	BIT NOT NULL,
       CalendarStartOfWeekDate DATE NOT NULL,
       CalendarEndOfWeekDate DATE NOT NULL,
       CalendarMonthInQtrNum INT NOT NULL,
       CalendarMonthInYearNum INT NOT NULL,
       CalendarYearMonthNum VARCHAR(7) NOT NULL,
       CalendarYearMonthDesc VARCHAR(14) NOT NULL,
       CalendarMonthYearNum VARCHAR(7) NOT NULL,
       CalendarMonthYearDesc VARCHAR(14) NOT NULL,
       CalendarMonth3YearDesc VARCHAR(8) NOT NULL,
       CalendarYearMonth3Desc VARCHAR(8) NOT NULL,
       CalendarLastDayInMonthInd BIT NOT NULL,
       CalendarStartOfMonthDate	DATE NOT NULL,
       CalendarEndOfMonthDate DATE NOT NULL,
       CalendarQtrNum INT NOT NULL,
       CalendarQtrYearNum VARCHAR(7) NOT NULL,
       CalendarQtrYearDesc VARCHAR(7) NOT NULL,
       CalendarYearQtrNum VARCHAR(7) NOT NULL,
       CalendarYearQtrDesc VARCHAR(7) NOT NULL,
       CalendarLastDayInQtrInd BIT NOT NULL,
       CalendarStartOfQtrDate DATE NOT NULL,
       CalendarEndOfQtrDate	DATE NOT NULL,
       CalendarYearNum INT NOT NULL,
       CalendarLastDayInYearInd	BIT NOT NULL,
       CalendarStartOfYearDate DATE NOT NULL,
       CalendarEndOfYearDate DATE NOT NULL,
       FiscalDayInWeekNum INT NOT NULL,
       FiscalDayInMonthNum INT NOT NULL,
       FiscalDayInQtrNum INT NOT NULL,
       FiscalDayInYearNum INT NOT NULL,
       FiscalWeekInMonthNum INT NOT NULL,
       FiscalWeekInQtrNum INT NOT NULL,
       FiscalWeekInYearNum INT NOT NULL,
       FiscalLastDayInWeekInd BIT NOT NULL,
       FiscalStartOfWeekDate DATE NOT NULL,
       FiscalEndOfWeekDate DATE NOT NULL,
       FiscalMonthInQtrNum INT NOT NULL,
       FiscalMonthInYearNum INT NOT NULL,
       FiscalYearMonthNum VARCHAR(7) NOT NULL,
       FiscalYearMonthDesc VARCHAR(14) NOT NULL,
       FiscalMonthYearNum VARCHAR(7) NOT NULL,
       FiscalMonthYearDesc VARCHAR(14) NOT NULL,
       FiscalMonth3YearDesc VARCHAR(8) NOT NULL,
       FiscalYearMonth3Desc VARCHAR(8) NOT NULL,
       FiscalLastDayInMonthInd BIT NOT NULL,
       FiscalStartOfMonthDate DATE NOT NULL,
       FiscalEndOfMonthDate DATE NOT NULL,
       FiscalQtrNum INT NOT NULL,
       FiscalQtrYearNum VARCHAR(7) NOT NULL,
       FiscalQtrYearDesc VARCHAR(7) NOT NULL,
       FiscalYearQtrNum VARCHAR(7) NOT NULL,
       FiscalYearQtrDesc VARCHAR(7) NOT NULL,
       FiscalLastDayInQtrInd BIT NOT NULL,
       FiscalStartOfQtrDate DATE NOT NULL,
       FiscalEndOfQtrDate DATE NOT NULL,
       FiscalYearNum INT NOT NULL,
       FiscalLastDayInYearInd BIT NOT NULL,
       FiscalStartOfYearDate DATE NOT NULL,
       FiscalEndOfYearDate DATE NOT NULL,
	   CONSTRAINT PK_dimDate
			PRIMARY KEY CLUSTERED (DatePK)
			WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
) ON [PRIMARY]
GO

ALTER TABLE [dm].[dimDate] ADD CONSTRAINT [dimDate_U1] UNIQUE 
(
	[DayDate] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value='Date Dimension contains a calendar date and all attributes about that date. Note - Leap years are accounted for (e.g., February 29, 2008)'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = N'dimDate'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Key is a system-generated identifier. Reserved for data warehouse use, this key should be invisible to the typical business user.'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimDate'
	, @level2type = N'Column', @level2name = 'DatePK'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Day Date is the actual date of the day.'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimDate'
	, @level2type = N'Column', @level2name = 'DayDate'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Full Date Description is the full description of the date - e.g., September 30, 2006.'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimDate'
	, @level2type = N'Column', @level2name = 'DayDateDesc'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Day Name is the name of the day - Monday, Tuesday, Wednesday, Thursday, Friday, Saturday, Sunday'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimDate'
	, @level2type = N'Column', @level2name = 'DayDesc'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Day of Week Abbreviation Name is the abbreviation of the day - Mon, Tue, Wed, Thu, Fri, Sat, Sun.'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimDate'
	, @level2type = N'Column', @level2name = 'Day3Desc'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Calendar Month Name is the name of the calendar month - January, February, March, April, May, June, July, August, September, October, November, December.'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimDate'
	, @level2type = N'Column', @level2name = 'MonthDesc'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Calendar Month Abbreviation Name is the abbreviation of the calendar month - Jan, Feb, Mar, Apr, May, Jun, Jul, Aug, Sep, Oct, Nov, Dec.'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimDate'
	, @level2type = N'Column', @level2name = 'Month3Desc'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Weekday Indicator indicates if the date is a weekday (includes Monday through Friday) - 1, 0.'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimDate'
	, @level2type = N'Column', @level2name = 'WeekdayInd'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Holiday Indicator indicates if the date is a holiday - 1, 0. Note - If a holiday falls on a Saturday then it is observed on Friday and if a holiday falls on a Sunday then it is observed on Monday.'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimDate'
	, @level2type = N'Column', @level2name = 'HolidayInd'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Holiday Descriptor provides text description of the holiday.'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimDate'
	, @level2type = N'Column', @level2name = 'HolidayDesc'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Calendar Day in Week Number is the day in the calendar week - 1, 2, 3, 4, 5, 6, 7. Note - Sunday = 1, etc.'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimDate'
	, @level2type = N'Column', @level2name = 'CalendarDayInWeekNum'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Calendar Day in Month Number is the day in the calendar month (1 - 31)'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimDate'
	, @level2type = N'Column', @level2name = 'CalendarDayInMonthNum'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Calendar Day in Quarter Number is the day in the calendar quarter. e.g., 1, 100, etc.'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimDate'
	, @level2type = N'Column', @level2name = 'CalendarDayInQtrNum'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Calendar Day in Year Number is the day in the calendar year. Starts with 1 for January 1st and up to 366 for leap years.'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimDate'
	, @level2type = N'Column', @level2name = 'CalendarDayInYearNum'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Calendar Week in Month Number is the week in the calendar month - 1, 2, 3, 4, 5. Note - The 1st - 7th is week one, 8th - 14th is week two, etc.  When you get past the 28th, week five. There is a week for every set of seven days from the start to the end of the calendar month.'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimDate'
	, @level2type = N'Column', @level2name = 'CalendarWeekInMonthNum'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Calendar Week in Quarter Number is the week in the calendar quarter - 1, 2, 3, 4, 5, etc. Note - The 1st - 7th is week one, 8th - 14th is week two, etc. There is a week for every set of seven days from the start to the end of the calendar quarter.'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimDate'
	, @level2type = N'Column', @level2name = 'CalendarWeekInQtrNum'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Calendar Week in Year Number is the number of the week in the calendar year - 1, 2, 3, 4, 5, etc. Note - Jan 1st - 7th is week one, 8th - 14th is week two, etc. There is a week for every set of seven days from the start to the end of the calendar year.'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimDate'
	, @level2type = N'Column', @level2name = 'CalendarWeekInYearNum'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Calendar Last Day in Week Indicator indicates if the date is the last day in the calendar week (which is on a Saturday) - 1, 0.'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimDate'
	, @level2type = N'Column', @level2name = 'CalendarLastDayInWeekInd'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Calendar Start of Week Date is the date the calendar week started (which is on a Sunday).'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimDate'
	, @level2type = N'Column', @level2name = 'CalendarStartOfWeekDate'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Calendar End of Week Date is the date the calendar week ended (which is on a Saturday).'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimDate'
	, @level2type = N'Column', @level2name = 'CalendarEndOfWeekDate'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Calendar Month in Quarter Number is the month in the calendar quarter - 1, 2, 3.'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimDate'
	, @level2type = N'Column', @level2name = 'CalendarMonthInQtrNum'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Calendar Month in Year Number is the month in the calendar year - 1 through 12.'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimDate'
	, @level2type = N'Column', @level2name = 'CalendarMonthInYearNum'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Calendar Year Month Number is the combination of the calendar year and month. e.g., 2006-03'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimDate'
	, @level2type = N'Column', @level2name = 'CalendarYearMonthNum'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Calendar Year Month Name is the combination of the calendar year and month. e.g., 2006-March'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimDate'
	, @level2type = N'Column', @level2name = 'CalendarYearMonthDesc'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Calendar Month Year Number is the combination of the calendar month and year. e.g., 03-2006'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimDate'
	, @level2type = N'Column', @level2name = 'CalendarMonthYearNum'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Calendar Month Year Name is the combination of the calendar month and year. e.g., March-2006'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimDate'
	, @level2type = N'Column', @level2name = 'CalendarMonthYearDesc'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Calendar Month Abbreviation Year Number is the combination of the abbreviated calendar month and the year. e.g., Sep-2006'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimDate'
	, @level2type = N'Column', @level2name = 'CalendarMonth3YearDesc'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Calendar Month Abbreviation Year Number is the combination of the abbreviated calendar month and the year. e.g., 2006-Sep'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimDate'
	, @level2type = N'Column', @level2name = 'CalendarYearMonth3Desc'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Calendar Last Day in Month Indicator indicates if the date is the last day in the calendar month - 1, 0.'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimDate'
	, @level2type = N'Column', @level2name = 'CalendarLastDayInMonthInd'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Calendar Start of Month Date is the calendar date the month started.'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimDate'
	, @level2type = N'Column', @level2name = 'CalendarStartOfMonthDate'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Calendar End of Month Date is the date the calendar month ended.'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimDate'
	, @level2type = N'Column', @level2name = 'CalendarEndOfMonthDate'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Calendar Quarter Number is the number of the calendar quarter - 1, 2, 3, 4'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimDate'
	, @level2type = N'Column', @level2name = 'CalendarQtrNum'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Calendar Quarter Year Number is the combination of the calendar quarter and year. e.g., 01-2006'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimDate'
	, @level2type = N'Column', @level2name = 'CalendarQtrYearNum'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Calendar Quarter Year Name is the combination of the calendar quarter and year. e.g., Q1-2006'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimDate'
	, @level2type = N'Column', @level2name = 'CalendarQtrYearDesc'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Calendar Year Quarter Number is the combination of the calendar year and quarter. e.g., 2006-01'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimDate'
	, @level2type = N'Column', @level2name = 'CalendarYearQtrNum'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Calendar Year Quarter Name is the combination of the calendar year and quarter. e.g., 2006-Q1'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimDate'
	, @level2type = N'Column', @level2name = 'CalendarYearQtrDesc'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Calendar Last Day in Quarter Indicator indicates if the date is the last day in the calendar quarter - 1, 0.'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimDate'
	, @level2type = N'Column', @level2name = 'CalendarLastDayInQtrInd'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Calendar Start of Quarter Date is the date the calendar quarter started.'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimDate'
	, @level2type = N'Column', @level2name = 'CalendarStartOfQtrDate'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Calendar End of Quarter Date is the date the calendar quarter ended.'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimDate'
	, @level2type = N'Column', @level2name = 'CalendarEndOfQtrDate'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Calendar Year Number is the number of the calendar year. e.g., 2006'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimDate'
	, @level2type = N'Column', @level2name = 'CalendarYearNum'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Calendar Last Day in Year Indicator indicates if the date is the last day in the calendar year - 1, 0.'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimDate'
	, @level2type = N'Column', @level2name = 'CalendarLastDayInYearInd'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Calendar Start of Year Date is the date the calendar year started.'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimDate'
	, @level2type = N'Column', @level2name = 'CalendarStartOfYearDate'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Calendar End of Year Date is the date the calendar year ended.'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimDate'
	, @level2type = N'Column', @level2name = 'CalendarEndOfYearDate'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Fiscal Day in Week Number is the day in the Fiscal week - 1, 2, 3, 4, 5, 6, 7. Note - Sunday = 1, etc.'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimDate'
	, @level2type = N'Column', @level2name = 'FiscalDayInWeekNum'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Fiscal Day in Month Number is the day in the Fiscal month (1 - 31)'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimDate'
	, @level2type = N'Column', @level2name = 'FiscalDayInMonthNum'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Fiscal Day in Quarter Number is the day in the Fiscal quarter. e.g., 1, 100, etc.'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimDate'
	, @level2type = N'Column', @level2name = 'FiscalDayInQtrNum'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Fiscal Day in Year Number is the day in the Fiscal year. Starts with 1 for January 1st and up to 366 for leap years.'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimDate'
	, @level2type = N'Column', @level2name = 'FiscalDayInYearNum'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Fiscal Week in Month Number is the week in the Fiscal month - 1, 2, 3, 4, 5. Note - The 1st - 7th is week one, 8th - 14th is week two, etc.  When you get past the 28th, week five. There is a week for every set of seven days from the start to the end of the Fiscal month.'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimDate'
	, @level2type = N'Column', @level2name = 'FiscalWeekInMonthNum'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Fiscal Week in Quarter Number is the week in the Fiscal quarter - 1, 2, 3, 4, 5, etc. Note - The 1st - 7th is week one, 8th - 14th is week two, etc. There is a week for every set of seven days from the start to the end of the Fiscal quarter.'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimDate'
	, @level2type = N'Column', @level2name = 'FiscalWeekInQtrNum'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Fiscal Week in Year Number is the number of the week in the Fiscal year - 1, 2, 3, 4, 5, etc. Note - Jan 1st - 7th is week one, 8th - 14th is week two, etc. There is a week for every set of seven days from the start to the end of the Fiscal year.'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimDate'
	, @level2type = N'Column', @level2name = 'FiscalWeekInYearNum'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Fiscal Last Day in Week Indicator indicates if the date is the last day in the Fiscal week (which is on a Saturday) - 1, 0.'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimDate'
	, @level2type = N'Column', @level2name = 'FiscalLastDayInWeekInd'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Fiscal Start of Week Date is the date the Fiscal week started (which is on a Sunday).'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimDate'
	, @level2type = N'Column', @level2name = 'FiscalStartOfWeekDate'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Fiscal End of Week Date is the date the Fiscal week ended (which is on a Saturday).'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimDate'
	, @level2type = N'Column', @level2name = 'FiscalEndOfWeekDate'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Fiscal Month in Quarter Number is the month in the Fiscal quarter - 1, 2, 3.'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimDate'
	, @level2type = N'Column', @level2name = 'FiscalMonthInQtrNum'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Fiscal Month in Year Number is the month in the Fiscal year - 1 through 12.'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimDate'
	, @level2type = N'Column', @level2name = 'FiscalMonthInYearNum'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Fiscal Year Month Number is the combination of the Fiscal year and month. e.g., 2006-03'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimDate'
	, @level2type = N'Column', @level2name = 'FiscalYearMonthNum'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Fiscal Year Month Name is the combination of the Fiscal year and month. e.g., 2006-March'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimDate'
	, @level2type = N'Column', @level2name = 'FiscalYearMonthDesc'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Fiscal Month Year Number is the combination of the Fiscal month and year. e.g., 03-2006'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimDate'
	, @level2type = N'Column', @level2name = 'FiscalMonthYearNum'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Fiscal Month Year Name is the combination of the Fiscal month and year. e.g., March-2006'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimDate'
	, @level2type = N'Column', @level2name = 'FiscalMonthYearDesc'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Fiscal Month Abbreviation Year Number is the combination of the abbreviated Fiscal month and the year. e.g., Sep-2006'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimDate'
	, @level2type = N'Column', @level2name = 'FiscalMonth3YearDesc'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Fiscal Month Abbreviation Year Number is the combination of the abbreviated Fiscal month and the year. e.g., 2006-Sep'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimDate'
	, @level2type = N'Column', @level2name = 'FiscalYearMonth3Desc'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Fiscal Last Day in Month Indicator indicates if the date is the last day in the Fiscal month - 1, 0.'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimDate'
	, @level2type = N'Column', @level2name = 'FiscalLastDayInMonthInd'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Fiscal Start of Month Date is the Fiscal date the month started.'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimDate'
	, @level2type = N'Column', @level2name = 'FiscalStartOfMonthDate'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Fiscal End of Month Date is the date the Fiscal month ended.'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimDate'
	, @level2type = N'Column', @level2name = 'FiscalEndOfMonthDate'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Fiscal Quarter Number is the number of the Fiscal quarter - 1, 2, 3, 4'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimDate'
	, @level2type = N'Column', @level2name = 'FiscalQtrNum'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Fiscal Quarter Year Number is the combination of the Fiscal quarter and year. e.g., 01-2006'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimDate'
	, @level2type = N'Column', @level2name = 'FiscalQtrYearNum'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Fiscal Quarter Year Name is the combination of the Fiscal quarter and year. e.g., Q1-2006'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimDate'
	, @level2type = N'Column', @level2name = 'FiscalQtrYearDesc'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Fiscal Year Quarter Number is the combination of the Fiscal year and quarter. e.g., 2006-01'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimDate'
	, @level2type = N'Column', @level2name = 'FiscalYearQtrNum'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Fiscal Year Quarter Name is the combination of the Fiscal year and quarter. e.g., 2006-Q1'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimDate'
	, @level2type = N'Column', @level2name = 'FiscalYearQtrDesc'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Fiscal Last Day in Quarter Indicator indicates if the date is the last day in the Fiscal quarter - 1, 0.'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimDate'
	, @level2type = N'Column', @level2name = 'FiscalLastDayInQtrInd'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Fiscal Start of Quarter Date is the date the Fiscal quarter started.'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimDate'
	, @level2type = N'Column', @level2name = 'FiscalStartOfQtrDate'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Fiscal End of Quarter Date is the date the Fiscal quarter ended.'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimDate'
	, @level2type = N'Column', @level2name = 'FiscalEndOfQtrDate'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Fiscal Year Number is the number of the Fiscal year. e.g., 2006'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimDate'
	, @level2type = N'Column', @level2name = 'FiscalYearNum'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Fiscal Last Day in Year Indicator indicates if the date is the last day in the Fiscal year - 1, 0.'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimDate'
	, @level2type = N'Column', @level2name = 'FiscalLastDayInYearInd'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Fiscal Start of Year Date is the date the Fiscal year started.'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimDate'
	, @level2type = N'Column', @level2name = 'FiscalStartOfYearDate'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Fiscal End of Year Date is the date the Fiscal year ended.'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimDate'
	, @level2type = N'Column', @level2name = 'FiscalEndOfYearDate'
GO

-- ##################################################################
-- These are the standard error handling rows.
-- ##################################################################
INSERT INTO dm.dimDate (DatePK,DayDate,DayDateDesc,DayDesc,Day3Desc,MonthDesc,Month3Desc,WeekdayInd,HolidayInd,HolidayDesc,CalendarDayInWeekNum,CalendarDayInMonthNum,CalendarDayInQtrNum,CalendarDayInYearNum,CalendarWeekInMonthNum,CalendarWeekInQtrNum,CalendarWeekInYearNum,CalendarLastDayInWeekInd,CalendarStartOfWeekDate,CalendarEndOfWeekDate,CalendarMonthInQtrNum,CalendarMonthInYearNum,CalendarYearMonthNum,CalendarYearMonthDesc,CalendarMonthYearNum,CalendarMonthYearDesc,CalendarMonth3YearDesc,CalendarYearMonth3Desc,CalendarLastDayInMonthInd,CalendarStartOfMonthDate,CalendarEndOfMonthDate,CalendarQtrNum,CalendarQtrYearNum,CalendarQtrYearDesc,CalendarYearQtrNum,CalendarYearQtrDesc,CalendarLastDayInQtrInd,CalendarStartOfQtrDate,CalendarEndOfQtrDate,CalendarYearNum,CalendarLastDayInYearInd,CalendarStartOfYearDate,CalendarEndOfYearDate,FiscalDayInWeekNum,FiscalDayInMonthNum,FiscalDayInQtrNum,FiscalDayInYearNum,FiscalWeekInMonthNum,FiscalWeekInQtrNum,FiscalWeekInYearNum,FiscalLastDayInWeekInd,FiscalStartOfWeekDate,FiscalEndOfWeekDate,FiscalMonthInQtrNum,FiscalMonthInYearNum,FiscalYearMonthNum,FiscalYearMonthDesc,FiscalMonthYearNum,FiscalMonthYearDesc,FiscalMonth3YearDesc,FiscalYearMonth3Desc,FiscalLastDayInMonthInd,FiscalStartOfMonthDate,FiscalEndOfMonthDate,FiscalQtrNum,FiscalQtrYearNum,FiscalQtrYearDesc,FiscalYearQtrNum,FiscalYearQtrDesc,FiscalLastDayInQtrInd,FiscalStartOfQtrDate,FiscalEndOfQtrDate,FiscalYearNum,FiscalLastDayInYearInd,FiscalStartOfYearDate,FiscalEndOfYearDate)
VALUES (99991231,'9999-12-31','NOT APPLICABLE','NA','NA','NA','NA',0,0,'NA',99,99,999,999,99,99,99,0,'9999-12-31','9999-12-31',99,99,'NA','NOT APPLICABLE','NA','NOT APPLICABLE','NA','NA',0,'9999-12-31','9999-12-31',99,'NA','NA','NA','NA',0,'9999-12-31','9999-12-31',9999,0,'9999-12-31','9999-12-31',99,99,999,999,99,99,99,0,'9999-12-31','9999-12-31',99,99,'NA','NOT APPLICABLE','NA','NOT APPLICABLE','NA','NA',0,'9999-12-31','9999-12-31',99,'NA','NA','NA','NA',0,'9999-12-31','9999-12-31',9999,0,'9999-12-31','9999-12-31')
GO

-- ###############################################################################
-- This section will insert Date rows into the dimDate table.
-- ###############################################################################
DECLARE @i AS INT
DECLARE @Days AS INT
DECLARE @StartDate AS DATETIME -- Variables are DATETIME because some date functions used still require DATETIME, not DATE
DECLARE @EndDate AS DATETIME -- Variables are DATETIME because some date functions used still require DATETIME, not DATE
DECLARE @Date AS DATETIME -- Variables are DATETIME because some date functions used still require DATETIME, not DATE
DECLARE @FiscalYearStartDate AS DATETIME -- Variables are DATETIME because some date functions used still require DATETIME, not DATE
DECLARE @FiscalYearEndDate AS DATETIME -- Variables are DATETIME because some date functions used still require DATETIME, not DATE
DECLARE @FiscalStartMonth AS INT
DECLARE @FiscalStartDay AS INT

SET DATEFIRST 7 -- Set First day of the week to Sunday (default for US), otherwise DATEDIFF calcs for week num don't work correctly
SET @i = 1
SET @StartDate = '2000-01-01' -- Change to beginning date for dimDate (yyyy-mm-dd)
SET @EndDate = '2050-12-31' -- Change to end date for dimDate (yyyy-mm-dd)
SET @Date = @StartDate
SET @FiscalStartMonth = '10' -- Starting Fiscal Month (October)
SET @FiscalStartDay = '01' -- Starting Fiscal Day
SET @FiscalYearStartDate = CAST(DATEFROMPARTS(YEAR(@Date)-1,@FiscalStartMonth,@FiscalStartDay) AS DATETIME)
SET @FiscalYearEndDate = DATEADD(DAY,-1,(DATEADD(MONTH,12,@FiscalYearStartDate)))
 
WHILE (@Date <= @EndDate)
	BEGIN
	  INSERT INTO dm.dimDate
		SELECT
			-- date key as integer [1]
			CAST(CAST(YEAR(@Date) AS VARCHAR) + RIGHT('0' + CONVERT(VARCHAR(2), MONTH(@Date)), 2) + RIGHT('0' + CONVERT(VARCHAR(2), DAY(@Date)), 2) AS INT), 
			-- date of day [2] 
   	 		@Date, 
			-- full date desc [3]
			DATENAME(MONTH,@Date) + ' ' + RIGHT('0' + CONVERT(VARCHAR(2), DAY(@Date)), 2) + ', ' + CAST(YEAR(@Date) AS VARCHAR), 
			-- day name [4]
			DATENAME(WEEKDAY,@Date), 
			-- day abrv [5]
			SUBSTRING(DATENAME(WEEKDAY,@Date),1,3), 
	   		-- month name [6]
			DATENAME(MONTH,@Date), 
			-- month abrv name [7]
			SUBSTRING(DATENAME(MONTH,@Date),1,3), 
			-- Weekday Indicator [8]
			CASE 
				WHEN UPPER(DATENAME(WEEKDAY,@Date)) = 'SATURDAY' OR UPPER(DATENAME(WEEKDAY,@Date)) = 'SUNDAY' THEN 0
				ELSE 1
			END,
			-- Holiday ind - default 0 [9] 
			-- NOTE: the indicators below will be set to 1 based on US Holidays, comment out holidays that are not necessary or add new ones
			CASE 
				-- New Years Day
				WHEN SUBSTRING(CONVERT(VARCHAR(8),@Date,112),5,4) = '0101' THEN 1 
				-- Observed New Years Day if on a SUN
				WHEN SUBSTRING(CONVERT(VARCHAR(8),@Date,112),5,4) = '0102' AND UPPER(DATENAME(WEEKDAY,(@Date))) = 'MONDAY' THEN 1   
				-- Observed New Years Day if on a SAT
				WHEN SUBSTRING(CONVERT(VARCHAR(8),@Date,112),5,4) = '1231' AND UPPER(DATENAME(WEEKDAY,(@Date))) = 'FRIDAY' THEN 1  
				-- MLK Day: On November 2, 1983, President Ronald Reagan signed legislation establishing a legal holiday honoring the civil rights leader (born January 15)
				WHEN CAST(@Date AS DATE) = CAST(EDW.util.udf_nthWeekDay(3,'MON',YEAR(@Date),1) AS DATE) AND YEAR(@Date) > 1982 THEN 1 
				-- Washington's Birthday / Presidents Day: The Uniform Holidays Act, passed by Congress in 1968 to take effect in 1971, fixed the holiday on a Monday
				WHEN CAST(@Date AS DATE) = CAST(EDW.util.udf_nthWeekDay(3,'MON',YEAR(@Date),2) AS DATE) AND YEAR(@Date) > 1970 THEN 1 
				 -- Good Friday: The Friday before Easter Sunday. 
				WHEN CAST(@Date AS DATE) = CAST(DATEADD(DAY,-2,(SELECT EDW.util.udf_CalculateEaster(YEAR(@Date)))) AS DATE) THEN 1
				-- Memorial Day: The Uniform Holidays Act established a federal legal holiday, fixed on a Monday, beginning in 1971
				WHEN CAST(@Date AS DATE) = CAST(DATEADD(DAY,-7,EDW.util.udf_nthWeekDay(1,'MON',YEAR(@Date),6)) AS DATE) AND YEAR(@Date) > 1970 THEN 1 
				-- Independence Day not on a weekend: The holiday was already widely observed throughout the nation when Congress declared it a federal legal holiday, in 1870.
				WHEN SUBSTRING(CONVERT(VARCHAR(8),@Date,112),5,4) = '0704' THEN 1 
				-- Observed Independance Day if on a SUN
				WHEN SUBSTRING(CONVERT(VARCHAR(8),@Date,112),5,4) = '0705' AND UPPER(DATENAME(WEEKDAY,(@Date))) = 'MONDAY' THEN 1 
				-- Observed Independance Day if on a SAT
				WHEN SUBSTRING(CONVERT(VARCHAR(8),@Date,112),5,4) = '0703' AND UPPER(DATENAME(WEEKDAY,(@Date))) = 'FRIDAY' THEN 1  
				-- Labor Day: In 1894, President Grover Cleveland signed legislation establishing the federal holiday                        
				WHEN CAST(@Date AS DATE) = CAST(EDW.util.udf_nthWeekDay(1,'MON',YEAR(@Date),9) AS DATE) THEN 1 
				-- Columbus Day: he Uniform Holidays Act, passed by Congress in 1968 to take effect in 1971, fixed the holiday on a Monday
				WHEN CAST(@Date AS DATE) = CAST(EDW.util.udf_nthWeekDay(2,'MON',YEAR(@Date),10) AS DATE) AND YEAR(@Date) > 1970 THEN 1 
				-- Veterans Day not on a weekend:  Congress proclaimed a federal holiday in 1938 (originally Armistice Day - Name changed in 1954))
				WHEN SUBSTRING(CONVERT(VARCHAR(8),@Date,112),5,4) = '1111' AND (DATENAME(WEEKDAY,(@Date)) = 'MONDAY' OR DATENAME(WEEKDAY,(@Date)) = 'TUESDAY' OR DATENAME(WEEKDAY,(@Date)) = 'WEDNESDAY' OR DATENAME(WEEKDAY,(@Date)) = 'THURSDAY' OR DATENAME(WEEKDAY,(@Date)) = 'FRIDAY') AND YEAR(@Date) > 1937 THEN 1 
				-- Veterans Day if on a SUN
				WHEN SUBSTRING(CONVERT(VARCHAR(8),@Date,112),5,4) = '1112' AND UPPER(DATENAME(WEEKDAY,(@Date))) = 'MONDAY' AND YEAR(@Date) > 1937 THEN 1   
				-- Veterans Day if on a SAT
				WHEN SUBSTRING(CONVERT(VARCHAR(8),@Date,112),5,4) = '1110' AND UPPER(DATENAME(WEEKDAY,(@Date))) = 'FRIDAY' AND YEAR(@Date) > 1937 THEN 1  
				-- Thanksgiving: In 1941, Congress moved the holiday from the last Thursday in November to the fourth Thursday
				WHEN CAST(@Date AS DATE) = CAST(EDW.util.udf_nthWeekDay(4,'THU',YEAR(@Date),11) AS DATE) AND YEAR(@Date) > 1940 THEN 1
				-- Friday after Thanksgiving
				WHEN CAST(@Date AS DATE) = CAST(DATEADD(DAY,+1,EDW.util.udf_nthWeekDay(4,'THU',YEAR(@Date),11)) AS DATE) AND YEAR(@Date) > 1940 THEN 1 
				-- Christmas Eve day, not on a weekend
				WHEN SUBSTRING(CONVERT(VARCHAR(8),@Date,112),5,4) = '1224' THEN 1 
				-- Christmas Eve Day, if on a SAT
				WHEN SUBSTRING(CONVERT(VARCHAR(8),@Date,112),5,4) = '1223' AND UPPER(DATENAME(WEEKDAY,(@Date))) = 'FRIDAY' THEN 1  
				-- Christmas Eve Day, if on a SUN
				WHEN SUBSTRING(CONVERT(VARCHAR(8),@Date,112),5,4) = '1222' AND UPPER(DATENAME(WEEKDAY,(@Date))) = 'FRIDAY' THEN 1  
				-- Christmas not on a weekend: Congress proclaimed Christmas a federal holiday in 1870.
				WHEN SUBSTRING(CONVERT(VARCHAR(8),@Date,112),5,4) = '1225' THEN 1 
				-- Christmas if on a SAT
				WHEN SUBSTRING(CONVERT(VARCHAR(8),@Date,112),5,4) = '1227' AND UPPER(DATENAME(WEEKDAY,(@Date))) = 'MONDAY' THEN 1  
				-- Christmas if on a SUN
				WHEN SUBSTRING(CONVERT(VARCHAR(8),@Date,112),5,4) = '1226' AND UPPER(DATENAME(WEEKDAY,(@Date))) = 'MONDAY' THEN 1  
				ELSE 0   
			END,
			-- Holiday Descriptor [10] 
			CASE 
				-- New Years Day
				WHEN SUBSTRING(CONVERT(VARCHAR(8),@Date,112),5,4) = '0101' THEN 'US New Years Day' 
				-- Observed New Years Day if on a SUN
				WHEN SUBSTRING(CONVERT(VARCHAR(8),@Date,112),5,4) = '0102' AND UPPER(DATENAME(WEEKDAY,(@Date))) = 'MONDAY' THEN 'US New Years Day Observed'   
				-- Observed New Years Day if on a SAT
				WHEN SUBSTRING(CONVERT(VARCHAR(8),@Date,112),5,4) = '1231' AND UPPER(DATENAME(WEEKDAY,(@Date))) = 'FRIDAY' THEN 'US New Years Day Observed'  
				-- MLK Day: On November 2, 1983, President Ronald Reagan signed legislation establishing a legal holiday honoring the civil rights leader (born January 15)
				WHEN CAST(@Date AS DATE) = CAST(EDW.util.udf_nthWeekDay(3,'MON',YEAR(@Date),1) AS DATE) AND YEAR(@Date) > 1982 THEN 'US MLK Day' 
				-- Washington's Birthday / Presidents Day: The Uniform Holidays Act, passed by Congress in 1968 to take effect in 1971, fixed the holiday on a Monday
				WHEN CAST(@Date AS DATE) = CAST(EDW.util.udf_nthWeekDay(3,'MON',YEAR(@Date),2) AS DATE) AND YEAR(@Date) > 1970 THEN 'US Presidents Day' 
				 -- Good Friday: The Friday before Easter Sunday. 
				WHEN CAST(@Date AS DATE) = CAST(DATEADD(DAY,-2,(SELECT EDW.util.udf_CalculateEaster(YEAR(@Date)))) AS DATE) THEN 'US Good Friday'
				-- Memorial Day: The Uniform Holidays Act established a federal legal holiday, fixed on a Monday, beginning in 1971
				WHEN CAST(@Date AS DATE) = CAST(DATEADD(DAY,-7,EDW.util.udf_nthWeekDay(1,'MON',YEAR(@Date),6)) AS DATE) AND YEAR(@Date) > 1970 THEN 'US Memorial Day' 
				-- Independence Day not on a weekend: The holiday was already widely observed throughout the nation when Congress declared it a federal legal holiday, in 1870.
				WHEN SUBSTRING(CONVERT(VARCHAR(8),@Date,112),5,4) = '0704' THEN 'US Independance Day' 
				-- Observed Independance Day if on a SUN
				WHEN SUBSTRING(CONVERT(VARCHAR(8),@Date,112),5,4) = '0705' AND UPPER(DATENAME(WEEKDAY,(@Date))) = 'MONDAY' THEN 'US Independance Day Observed' 
				-- Observed Independance Day if on a SAT
				WHEN SUBSTRING(CONVERT(VARCHAR(8),@Date,112),5,4) = '0703' AND UPPER(DATENAME(WEEKDAY,(@Date))) = 'FRIDAY' THEN 'US Independance Day Observed'  
				-- Labor Day: In 1894, President Grover Cleveland signed legislation establishing the federal holiday                        
				WHEN CAST(@Date AS DATE) = CAST(EDW.util.udf_nthWeekDay(1,'MON',YEAR(@Date),9) AS DATE) THEN 'US Labor Day' 
				-- Columbus Day: he Uniform Holidays Act, passed by Congress in 1968 to take effect in 1971, fixed the holiday on a Monday
				WHEN CAST(@Date AS DATE) = CAST(EDW.util.udf_nthWeekDay(2,'MON',YEAR(@Date),10) AS DATE) AND YEAR(@Date) > 1970 THEN 'US Columbus Day' 
				-- Veterans Day not on a weekend:  Congress proclaimed a federal holiday in 1938 (originally Armistice Day - Name changed in 1954))
				WHEN SUBSTRING(CONVERT(VARCHAR(8),@Date,112),5,4) = '1111' AND (DATENAME(WEEKDAY,(@Date)) = 'MONDAY' OR DATENAME(WEEKDAY,(@Date)) = 'TUESDAY' OR DATENAME(WEEKDAY,(@Date)) = 'WEDNESDAY' OR DATENAME(WEEKDAY,(@Date)) = 'THURSDAY' OR DATENAME(WEEKDAY,(@Date)) = 'FRIDAY') AND YEAR(@Date) > 1937 THEN 'US Veterans Day' 
				-- Veterans Day if on a SUN
				WHEN SUBSTRING(CONVERT(VARCHAR(8),@Date,112),5,4) = '1112' AND UPPER(DATENAME(WEEKDAY,(@Date))) = 'MONDAY' AND YEAR(@Date) > 1937 THEN 'US Veterans Day Observed'   
				-- Veterans Day if on a SAT
				WHEN SUBSTRING(CONVERT(VARCHAR(8),@Date,112),5,4) = '1110' AND UPPER(DATENAME(WEEKDAY,(@Date))) = 'FRIDAY' AND YEAR(@Date) > 1937 THEN 'US Veterans Day Observed'  
				-- Thanksgiving: In 1941, Congress moved the holiday from the last Thursday in November to the fourth Thursday
				WHEN CAST(@Date AS DATE) = CAST(EDW.util.udf_nthWeekDay(4,'THU',YEAR(@Date),11) AS DATE) AND YEAR(@Date) > 1940 THEN 'US Thanksgiving Day'
				-- Friday after Thanksgiving
				WHEN CAST(@Date AS DATE) = CAST(DATEADD(DAY,+1,EDW.util.udf_nthWeekDay(4,'THU',YEAR(@Date),11)) AS DATE) AND YEAR(@Date) > 1940 THEN 'US Thanksgiving Friday' 
				-- Christmas Eve day, not on a weekend
				WHEN SUBSTRING(CONVERT(VARCHAR(8),@Date,112),5,4) = '1224' THEN 'US Christmas Eve Day' 
				-- Christmas Eve Day, if on a SAT
				WHEN SUBSTRING(CONVERT(VARCHAR(8),@Date,112),5,4) = '1223' AND UPPER(DATENAME(WEEKDAY,(@Date))) = 'FRIDAY' THEN 'US Christmas Eve Day Observed'  
				-- Christmas Eve Day, if on a SUN
				WHEN SUBSTRING(CONVERT(VARCHAR(8),@Date,112),5,4) = '1222' AND UPPER(DATENAME(WEEKDAY,(@Date))) = 'FRIDAY' THEN 'US Christmas Eve Day Observed'  
				-- Christmas not on a weekend: Congress proclaimed Christmas a federal holiday in 1870.
				WHEN SUBSTRING(CONVERT(VARCHAR(8),@Date,112),5,4) = '1225' THEN 'US Christmas Day' 
				-- Christmas if on a SAT
				WHEN SUBSTRING(CONVERT(VARCHAR(8),@Date,112),5,4) = '1227' AND UPPER(DATENAME(WEEKDAY,(@Date))) = 'MONDAY' THEN 'US Christmas Day Observed'  
				-- Christmas if on a SUN
				WHEN SUBSTRING(CONVERT(VARCHAR(8),@Date,112),5,4) = '1226' AND UPPER(DATENAME(WEEKDAY,(@Date))) = 'MONDAY' THEN 'US Christmas Day Observed'  
			END,			
			-- Calendar day of week number [11]																			
			CASE 
				WHEN UPPER(DATENAME(WEEKDAY,@Date)) = 'SUNDAY' THEN 1
				WHEN UPPER(DATENAME(WEEKDAY,@Date)) = 'MONDAY' THEN 2
				WHEN UPPER(DATENAME(WEEKDAY,@Date)) = 'TUESDAY' THEN 3
				WHEN UPPER(DATENAME(WEEKDAY,@Date)) = 'WEDNESDAY' THEN 4
				WHEN UPPER(DATENAME(WEEKDAY,@Date)) = 'THURSDAY' THEN 5
				WHEN UPPER(DATENAME(WEEKDAY,@Date)) = 'FRIDAY' THEN 6
				WHEN UPPER(DATENAME(WEEKDAY,@Date)) = 'SATURDAY' THEN 7
			END,
			-- day in month nbr [12] 
			DAY(@Date),
			-- day in qtr nbr [13] 
			DATEDIFF(DAY,CONVERT(DATE,DATEADD(QUARTER,DATEDIFF(QUARTER,0,@Date),0)),@Date) + 1, 
   			-- day in year nbr [14]
			DATEPART(DAYOFYEAR,@Date),
			-- week in month nbr [15] 
   			DATEDIFF(WEEK,CAST(CAST(DATEPART(MONTH,@Date) AS VARCHAR(2)) + '/01/' + CAST(DATEPART(YEAR,@Date) AS VARCHAR(4)) AS DATE),@Date) + 1, 
			-- week in qtr nbr [16]
			CASE 
				WHEN DATEPART(MONTH,@Date) >= 1 AND DATEPART(MONTH,@Date) <= 3 THEN DATEDIFF(WEEK,CAST('01/01/' + CAST(DATEPART(YEAR,@Date) AS VARCHAR(4)) AS DATE),@Date) + 1
				WHEN DATEPART(MONTH,@Date) >= 4 AND DATEPART(MONTH,@Date) <= 6 THEN DATEDIFF(WEEK,CAST('04/01/' + CAST(DATEPART(YEAR,@Date) AS VARCHAR(4)) AS DATE),@Date) + 1
				WHEN DATEPART(MONTH,@Date) >= 7 AND DATEPART(MONTH,@Date) <= 9 THEN DATEDIFF(WEEK,CAST('07/01/' + CAST(DATEPART(YEAR,@Date) AS VARCHAR(4)) AS DATE),@Date) + 1
				ELSE DATEDIFF(WEEK,CAST('10/01/' + CAST(DATEPART(YEAR,@Date) AS VARCHAR(4)) AS DATE),@Date) + 1
			END,
			-- week in year nbr [17] 
   			DATEPART(WEEK,@Date), 
			-- indicate last day of week [18]
			CASE 
				WHEN UPPER(DATENAME(WEEKDAY,@Date)) = 'SATURDAY' THEN 1
				ELSE 0
			END,
			-- start of week date [19] 
			DATEADD(DAY,(1-DATEPART(WEEKDAY,@Date)),@Date),
			-- end of week date [20]
			DATEADD(DAY,(7-DATEPART(WEEKDAY,@Date)),@Date),
			-- month in qtr nbr [21]
			CASE 
				WHEN DATEPART(MONTH,@Date) >= 1 AND DATEPART(MONTH,@Date) <= 3 THEN DATEDIFF(MONTH,CAST('01/01/' + CAST(DATEPART(YEAR,@Date) AS VARCHAR(4)) AS DATE),@Date) + 1
				WHEN DATEPART(MONTH,@Date) >= 4 AND DATEPART(MONTH,@Date) <= 6 THEN DATEDIFF(MONTH,CAST('04/01/' + CAST(DATEPART(YEAR,@Date) AS VARCHAR(4)) AS DATE),@Date) + 1
				WHEN DATEPART(MONTH,@Date) >= 7 AND DATEPART(MONTH,@Date) <= 9 THEN DATEDIFF(MONTH,CAST('07/01/' + CAST(DATEPART(YEAR,@Date) AS VARCHAR(4)) AS DATE),@Date) + 1
				ELSE DATEDIFF(MONTH,CAST('10/01/' + CAST(DATEPART(YEAR,@Date) AS VARCHAR(4)) AS DATE),@Date) + 1
			END,
			-- month in year nbr [22] 
   			MONTH(@Date),
			-- year-month nbr [23] 
   			CAST(YEAR(@Date) AS VARCHAR) + '-' + RIGHT('0' + CONVERT(VARCHAR(2),MONTH(@Date)),2), 
   			-- year-month name [24]
			CAST(YEAR(@Date) AS VARCHAR) + '-' + DATENAME(MONTH,@Date), 
   			-- month-year nbr [25]
			RIGHT('0' + CONVERT(VARCHAR(2),MONTH(@Date)),2) + '-' + CAST(YEAR(@Date) AS VARCHAR), 
   			-- month-year name [26]
			DATENAME(MONTH,@Date) + '-' + CAST(YEAR(@Date) AS VARCHAR), 
   			-- month-year abrv [27]
			SUBSTRING(DATENAME(MONTH,@Date),1,3) + '-' + CAST(YEAR(@Date) AS VARCHAR), 
   			-- year-month abrv [28]
			CAST(YEAR(@Date) AS VARCHAR) + '-' + SUBSTRING(DATENAME(MONTH,@Date),1,3), 
			-- last day in month ind [29]
			CASE
				WHEN CAST(@Date AS DATE) = CAST(DATEADD(MS,-3,DATEADD(MONTH,DATEDIFF(MONTH,0,@Date)+1,0)) AS DATE) THEN 1
				ELSE 0	 				 				  	  		   		
			END,
			-- start of mnth date [30] 	
			CAST(DATEADD(MONTH,DATEDIFF(MONTH,0,@Date),0) AS DATE), 
			-- end of mnth date [31]
			CAST(DATEADD(MS,-3,DATEADD(MONTH,DATEDIFF(MONTH,0,@Date)+1,0)) AS DATE), 
			 -- quarter number [32]
			DATENAME(QUARTER,@Date),
			-- quarter-year nbr [33]
			DATENAME(QUARTER,@Date) + '-' + CAST(YEAR(@Date) AS VARCHAR), 
			-- quarter-year nm [34]
			'Q' + DATENAME(QUARTER,@Date) + '-' + CAST(YEAR(@Date) AS VARCHAR), 
			-- quarter-year nbr [35]
			CAST(YEAR(@Date) AS VARCHAR) + '-' + DATENAME(QUARTER,@Date), 
			-- quarter-year name [36]
			CAST(YEAR(@Date) AS VARCHAR) + '-Q' + DATENAME(QUARTER,@Date), 
			-- last day in qtr ind [37]
			CASE
				WHEN CAST(@Date AS DATE) = DATEADD(DAY,-1,DATEADD(MONTH,3,CAST(DATEADD(QUARTER,DATEDIFF(QUARTER,0,@Date),0) AS DATE))) THEN 1
				ELSE 0	 				 				  	  		   			
			END, 
			-- start date in qtr [38]
			CAST(DATEADD(QUARTER,DATEDIFF(QUARTER,0,@Date),0) AS DATE), 
			-- end date of qtr [39]
			DATEADD(DAY,-1,DATEADD(MONTH,3,CAST(DATEADD(QUARTER,DATEDIFF(QUARTER,0,@Date),0) AS DATE))), 
			-- year nbr   [40]
			YEAR(@Date), 
			-- last day in year ind [41]
			CASE
		 		WHEN MONTH(@Date) = 12 AND DAY(@Date) = 31 THEN 1
				ELSE 0
			END, 
			-- start of year date [42]
			CAST(DATEADD(YEAR,DATEDIFF(YEAR,0,@Date),0) AS DATE), 
			-- end of year date [43]
			DATEADD(DAY,-1,DATEADD(YEAR,1,CAST(DATEADD(YEAR,DATEDIFF(YEAR,0,@Date),0) AS DATE))), 
			
			-- Fiscal day of week number [44]
			CASE 
				WHEN UPPER(DATENAME(WEEKDAY,@Date)) = 'SUNDAY' THEN 1
				WHEN UPPER(DATENAME(WEEKDAY,@Date)) = 'MONDAY' THEN 2
				WHEN UPPER(DATENAME(WEEKDAY,@Date)) = 'TUESDAY' THEN 3
				WHEN UPPER(DATENAME(WEEKDAY,@Date)) = 'WEDNESDAY' THEN 4
				WHEN UPPER(DATENAME(WEEKDAY,@Date)) = 'THURSDAY' THEN 5
				WHEN UPPER(DATENAME(WEEKDAY,@Date)) = 'FRIDAY' THEN 6
				WHEN UPPER(DATENAME(WEEKDAY,@Date)) = 'SATURDAY' THEN 7
			END, 
			-- Fiscal day in month nbr [45]
			DAY(@Date), 
			-- Fiscal day in qtr nbr [46]
			DATEDIFF(DAY,CONVERT(DATE,DATEADD(QUARTER,DATEDIFF(QUARTER,0,@Date),0)),@Date) + 1, 
   			-- Fiscal day in year nbr [47]
			DATEDIFF(DAY,@FiscalYearStartDate,@Date) + 1, 
   			-- Fiscal week in month nbr [48]
			DATEDIFF(WEEK,CAST(CAST(DATEPART(MONTH,@Date) AS VARCHAR(2)) + '/01/' + CAST(DATEPART(YEAR,@Date) AS VARCHAR(4)) AS DATE),@Date) + 1, 
			-- Fiscal week in qtr nbr [49]
			CASE 
				WHEN DATEPART(MONTH,@Date) >= 1 AND DATEPART(MONTH,@Date) <= 3 THEN DATEDIFF(WEEK,CAST('01/01/' + CAST(DATEPART(YEAR,@Date) AS VARCHAR(4)) AS DATE),@Date) + 1
				WHEN DATEPART(MONTH,@Date) >= 4 AND DATEPART(MONTH,@Date) <= 6 THEN DATEDIFF(WEEK,CAST('04/01/' + CAST(DATEPART(YEAR,@Date) AS VARCHAR(4)) AS DATE),@Date) + 1
				WHEN DATEPART(MONTH,@Date) >= 7 AND DATEPART(MONTH,@Date) <= 9 THEN DATEDIFF(WEEK,CAST('07/01/' + CAST(DATEPART(YEAR,@Date) AS VARCHAR(4)) AS DATE),@Date) + 1
				ELSE DATEDIFF(WEEK,CAST('10/01/' + CAST(DATEPART(YEAR,@Date) AS VARCHAR(4)) AS DATE),@Date) + 1
			END, 
   			-- Fiscal week in year nbr [50]
			CASE
				WHEN DATEPART(MONTH,@Date) >= 1 AND DATEPART(MONTH,@Date) <= 9 THEN DATEPART(WEEK,@Date) + DATEDIFF(WEEK,@FiscalYearStartDate,DATEADD(DAY,-1,DATEADD(MONTH,3,@FiscalYearStartDate)))
				ELSE DATEDIFF(WEEK,@FiscalYearStartDate,@Date)+1
			END,
			-- indicate Fiscal last day of week [51]
			CASE 
				WHEN UPPER(DATENAME(WEEKDAY,@Date)) = 'SATURDAY' THEN 1
				ELSE 0
			END, 
			-- Fiscal start of week date [52]
			DATEADD(DAY,(1-DATEPART(WEEKDAY,@Date)),@Date),
			-- Fiscal end of week date [53]
			DATEADD(DAY,(7-DATEPART(WEEKDAY,@Date)),@Date),
			-- Fiscal month in qtr nbr [54]
			CASE 
				WHEN DATEPART(MONTH,@Date) >= 1 AND DATEPART(MONTH,@Date) <= 3 THEN DATEDIFF(MONTH,CAST('01/01/' + CAST(DATEPART(YEAR,@Date) AS VARCHAR(4)) AS DATE),@Date) + 1
				WHEN DATEPART(MONTH,@Date) >= 4 AND DATEPART(MONTH,@Date) <= 6 THEN DATEDIFF(MONTH,CAST('04/01/' + CAST(DATEPART(YEAR,@Date) AS VARCHAR(4)) AS DATE),@Date) + 1
				WHEN DATEPART(MONTH,@Date) >= 7 AND DATEPART(MONTH,@Date) <= 9 THEN DATEDIFF(MONTH,CAST('07/01/' + CAST(DATEPART(YEAR,@Date) AS VARCHAR(4)) AS DATE),@Date) + 1
				ELSE DATEDIFF(MONTH,CAST('10/01/' + CAST(DATEPART(YEAR,@Date) AS VARCHAR(4)) AS DATE),@Date) + 1
			END, 
   			-- Fiscal month in year nbr [55]
			CASE
				WHEN DATEPART(MONTH,@Date) >= 1 AND DATEPART(MONTH,@Date) <= 9 THEN 3 + DATEPART(MONTH,@Date)
				ELSE DATEPART(MONTH,@Date) - 9
			END, 
   			-- Fiscal year-month nbr [56]
			CAST(YEAR(@FiscalYearStartDate) AS VARCHAR) + '-' + RIGHT('0' + CONVERT(VARCHAR(2),MONTH(@Date)),2), 
   			-- Fiscal year-month name [57]
			CAST(YEAR(@FiscalYearStartDate) AS VARCHAR) + '-' + DATENAME(MONTH,@Date), 
   			-- Fiscal month-year nbr [58]
			RIGHT('0' + CONVERT(VARCHAR(2),MONTH(@Date)),2) + '-' + CAST(YEAR(@FiscalYearStartDate) AS VARCHAR), 
   			-- Fiscal month-year name [59]
			DATENAME(MONTH,@Date) + '-' + CAST(YEAR(@FiscalYearStartDate) AS VARCHAR), 
   			-- Fiscal month-year abrv [60]
			SUBSTRING(DATENAME(MONTH,@Date),1,3) + '-' + CAST(YEAR(@FiscalYearStartDate) AS VARCHAR), 
   			-- Fiscal year-month abrv [61]
			CAST(YEAR(@FiscalYearStartDate) AS VARCHAR) + '-' + SUBSTRING(DATENAME(MONTH,@Date),1,3), 
			-- last Fiscal day in month ind [62]
			CASE
				WHEN CAST(@Date AS DATE) = CAST(DATEADD(MS,-3,DATEADD(MONTH,DATEDIFF(MONTH,0,@Date)+1,0)) AS DATE) THEN 1
				ELSE 0	 				 				  	  		   		
			END, 	
			-- Fiscal start of mnth date [63]
			CAST(DATEADD(MONTH,DATEDIFF(MONTH,0,@Date),0) AS DATE), 
			-- Fiscal end of mnth date [64]
			CAST(DATEADD(MS,-3,DATEADD(MONTH,DATEDIFF(MONTH,0,@Date)+1,0)) AS DATE), 
			-- Fiscal quarter number [65]
			CASE
				WHEN MONTH(@FiscalYearStartDate) IN (1,2,3) THEN
					CASE
						WHEN MONTH(@Date) IN (1,2,3) THEN 1
						WHEN MONTH(@Date) IN (4,5,6) THEN 2
						WHEN MONTH(@Date) IN (7,8,9) THEN 3
						WHEN MONTH(@Date) IN (10,11,12) THEN 4
					END
				WHEN MONTH(@FiscalYearStartDate) IN (4,5,6) THEN
					CASE
						WHEN MONTH(@Date) IN (1,2,3) THEN 4
						WHEN MONTH(@Date) IN (4,5,6) THEN 1
						WHEN MONTH(@Date) IN (7,8,9) THEN 2
						WHEN MONTH(@Date) IN (10,11,12) THEN 3
					END
				WHEN MONTH(@FiscalYearStartDate) IN (7,8,9) THEN
					CASE
						WHEN MONTH(@Date) IN (1,2,3) THEN 3
						WHEN MONTH(@Date) IN (4,5,6) THEN 4
						WHEN MONTH(@Date) IN (7,8,9) THEN 1
						WHEN MONTH(@Date) IN (10,11,12) THEN 2
					END
				WHEN MONTH(@FiscalYearStartDate) IN (10,11,12) THEN
					CASE
						WHEN MONTH(@Date) IN (1,2,3) THEN 2
						WHEN MONTH(@Date) IN (4,5,6) THEN 3
						WHEN MONTH(@Date) IN (7,8,9) THEN 4
						WHEN MONTH(@Date) IN (10,11,12) THEN 1
					END
			END,
			-- Fiscal quarter-year nbr [66]
			CASE
				WHEN MONTH(@FiscalYearStartDate) IN (1,2,3) THEN
					CASE
						WHEN MONTH(@Date) IN (1,2,3) THEN '1-' + CAST(YEAR(@FiscalYearStartDate) AS VARCHAR)
						WHEN MONTH(@Date) IN (4,5,6) THEN '2-' + CAST(YEAR(@FiscalYearStartDate) AS VARCHAR)
						WHEN MONTH(@Date) IN (7,8,9) THEN '3-' + CAST(YEAR(@FiscalYearStartDate) AS VARCHAR)
						WHEN MONTH(@Date) IN (10,11,12) THEN '4-' + CAST(YEAR(@FiscalYearStartDate) AS VARCHAR)
					END
				WHEN MONTH(@FiscalYearStartDate) IN (4,5,6) THEN
					CASE
						WHEN MONTH(@Date) IN (1,2,3) THEN '4-' + CAST(YEAR(@FiscalYearStartDate) AS VARCHAR)
						WHEN MONTH(@Date) IN (4,5,6) THEN '1-' + CAST(YEAR(@FiscalYearStartDate) AS VARCHAR)
						WHEN MONTH(@Date) IN (7,8,9) THEN '2-' + CAST(YEAR(@FiscalYearStartDate) AS VARCHAR)
						WHEN MONTH(@Date) IN (10,11,12) THEN '3-' + CAST(YEAR(@FiscalYearStartDate) AS VARCHAR)
					END
				WHEN MONTH(@FiscalYearStartDate) IN (7,8,9) THEN
					CASE
						WHEN MONTH(@Date) IN (1,2,3) THEN '3-' + CAST(YEAR(@FiscalYearStartDate) AS VARCHAR)
						WHEN MONTH(@Date) IN (4,5,6) THEN '4-' + CAST(YEAR(@FiscalYearStartDate) AS VARCHAR)
						WHEN MONTH(@Date) IN (7,8,9) THEN '1-' + CAST(YEAR(@FiscalYearStartDate) AS VARCHAR)
						WHEN MONTH(@Date) IN (10,11,12) THEN '2-' + CAST(YEAR(@FiscalYearStartDate) AS VARCHAR)
					END
				WHEN MONTH(@FiscalYearStartDate) IN (10,11,12) THEN
					CASE
						WHEN MONTH(@Date) IN (1,2,3) THEN '2-' + CAST(YEAR(@FiscalYearStartDate) AS VARCHAR)
						WHEN MONTH(@Date) IN (4,5,6) THEN '3-' + CAST(YEAR(@FiscalYearStartDate) AS VARCHAR)
						WHEN MONTH(@Date) IN (7,8,9) THEN '4-' + CAST(YEAR(@FiscalYearStartDate) AS VARCHAR)
						WHEN MONTH(@Date) IN (10,11,12) THEN '1-' + CAST(YEAR(@FiscalYearStartDate) AS VARCHAR)
					END
			END,
			-- Fiscal quarter-year nm [67]
			CASE
				WHEN MONTH(@FiscalYearStartDate) IN (1,2,3) THEN
					CASE
						WHEN MONTH(@Date) IN (1,2,3) THEN 'Q1-' + CAST(YEAR(@FiscalYearStartDate) AS VARCHAR)
						WHEN MONTH(@Date) IN (4,5,6) THEN 'Q2-' + CAST(YEAR(@FiscalYearStartDate) AS VARCHAR)
						WHEN MONTH(@Date) IN (7,8,9) THEN 'Q3-' + CAST(YEAR(@FiscalYearStartDate) AS VARCHAR)
						WHEN MONTH(@Date) IN (10,11,12) THEN 'Q4-' + CAST(YEAR(@FiscalYearStartDate) AS VARCHAR)
					END
				WHEN MONTH(@FiscalYearStartDate) IN (4,5,6) THEN
					CASE
						WHEN MONTH(@Date) IN (1,2,3) THEN 'Q4-' + CAST(YEAR(@FiscalYearStartDate) AS VARCHAR)
						WHEN MONTH(@Date) IN (4,5,6) THEN 'Q1-' + CAST(YEAR(@FiscalYearStartDate) AS VARCHAR)
						WHEN MONTH(@Date) IN (7,8,9) THEN 'Q2-' + CAST(YEAR(@FiscalYearStartDate) AS VARCHAR)
						WHEN MONTH(@Date) IN (10,11,12) THEN 'Q3-' + CAST(YEAR(@FiscalYearStartDate) AS VARCHAR)
					END
				WHEN MONTH(@FiscalYearStartDate) IN (7,8,9) THEN
					CASE
						WHEN MONTH(@Date) IN (1,2,3) THEN 'Q3-' + CAST(YEAR(@FiscalYearStartDate) AS VARCHAR)
						WHEN MONTH(@Date) IN (4,5,6) THEN 'Q4-' + CAST(YEAR(@FiscalYearStartDate) AS VARCHAR)
						WHEN MONTH(@Date) IN (7,8,9) THEN 'Q1-' + CAST(YEAR(@FiscalYearStartDate) AS VARCHAR)
						WHEN MONTH(@Date) IN (10,11,12) THEN 'Q2-' + CAST(YEAR(@FiscalYearStartDate) AS VARCHAR)
					END
				WHEN MONTH(@FiscalYearStartDate) IN (10,11,12) THEN
					CASE
						WHEN MONTH(@Date) IN (1,2,3) THEN 'Q2-' + CAST(YEAR(@FiscalYearStartDate) AS VARCHAR)
						WHEN MONTH(@Date) IN (4,5,6) THEN 'Q3-' + CAST(YEAR(@FiscalYearStartDate) AS VARCHAR)
						WHEN MONTH(@Date) IN (7,8,9) THEN 'Q4-' + CAST(YEAR(@FiscalYearStartDate) AS VARCHAR)
						WHEN MONTH(@Date) IN (10,11,12) THEN 'Q1-' + CAST(YEAR(@FiscalYearStartDate) AS VARCHAR)
					END
			END,
			-- Fiscal quarter-year nbr [68]
			CASE
				WHEN MONTH(@FiscalYearStartDate) IN (1,2,3) THEN
					CASE
						WHEN MONTH(@Date) IN (1,2,3) THEN CAST(YEAR(@FiscalYearStartDate) AS VARCHAR) + '-1'
						WHEN MONTH(@Date) IN (4,5,6) THEN CAST(YEAR(@FiscalYearStartDate) AS VARCHAR) + '-2'
						WHEN MONTH(@Date) IN (7,8,9) THEN CAST(YEAR(@FiscalYearStartDate) AS VARCHAR) + '-3'
						WHEN MONTH(@Date) IN (10,11,12) THEN CAST(YEAR(@FiscalYearStartDate) AS VARCHAR) + '-4'
					END
				WHEN MONTH(@FiscalYearStartDate) IN (4,5,6) THEN
					CASE
						WHEN MONTH(@Date) IN (1,2,3) THEN CAST(YEAR(@FiscalYearStartDate) AS VARCHAR) + '-4'
						WHEN MONTH(@Date) IN (4,5,6) THEN CAST(YEAR(@FiscalYearStartDate) AS VARCHAR) + '-1'
						WHEN MONTH(@Date) IN (7,8,9) THEN CAST(YEAR(@FiscalYearStartDate) AS VARCHAR) + '-2'
						WHEN MONTH(@Date) IN (10,11,12) THEN CAST(YEAR(@FiscalYearStartDate) AS VARCHAR) + '-3'
					END
				WHEN MONTH(@FiscalYearStartDate) IN (7,8,9) THEN
					CASE
						WHEN MONTH(@Date) IN (1,2,3) THEN CAST(YEAR(@FiscalYearStartDate) AS VARCHAR) + '-3'
						WHEN MONTH(@Date) IN (4,5,6) THEN CAST(YEAR(@FiscalYearStartDate) AS VARCHAR) + '-4'
						WHEN MONTH(@Date) IN (7,8,9) THEN CAST(YEAR(@FiscalYearStartDate) AS VARCHAR) + '-1'
						WHEN MONTH(@Date) IN (10,11,12) THEN CAST(YEAR(@FiscalYearStartDate) AS VARCHAR) + '-2'
					END
				WHEN MONTH(@FiscalYearStartDate) IN (10,11,12) THEN
					CASE
						WHEN MONTH(@Date) IN (1,2,3) THEN CAST(YEAR(@FiscalYearStartDate) AS VARCHAR) + '-2'
						WHEN MONTH(@Date) IN (4,5,6) THEN CAST(YEAR(@FiscalYearStartDate) AS VARCHAR) + '-3'
						WHEN MONTH(@Date) IN (7,8,9) THEN CAST(YEAR(@FiscalYearStartDate) AS VARCHAR) + '-4'
						WHEN MONTH(@Date) IN (10,11,12) THEN CAST(YEAR(@FiscalYearStartDate) AS VARCHAR) + '-1'
					END
			END,
			-- Fiscal quarter-year name [69]
			CASE
				WHEN MONTH(@FiscalYearStartDate) IN (1,2,3) THEN
					CASE
						WHEN MONTH(@Date) IN (1,2,3) THEN CAST(YEAR(@FiscalYearStartDate) AS VARCHAR) + '-Q1'
						WHEN MONTH(@Date) IN (4,5,6) THEN CAST(YEAR(@FiscalYearStartDate) AS VARCHAR) + '-Q2'
						WHEN MONTH(@Date) IN (7,8,9) THEN CAST(YEAR(@FiscalYearStartDate) AS VARCHAR) + '-Q3'
						WHEN MONTH(@Date) IN (10,11,12) THEN CAST(YEAR(@FiscalYearStartDate) AS VARCHAR) + '-Q4'
					END
				WHEN MONTH(@FiscalYearStartDate) IN (4,5,6) THEN
					CASE
						WHEN MONTH(@Date) IN (1,2,3) THEN CAST(YEAR(@FiscalYearStartDate) AS VARCHAR) + '-Q4'
						WHEN MONTH(@Date) IN (4,5,6) THEN CAST(YEAR(@FiscalYearStartDate) AS VARCHAR) + '-Q1'
						WHEN MONTH(@Date) IN (7,8,9) THEN CAST(YEAR(@FiscalYearStartDate) AS VARCHAR) + '-Q2'
						WHEN MONTH(@Date) IN (10,11,12) THEN CAST(YEAR(@FiscalYearStartDate) AS VARCHAR) + '-Q3'
					END
				WHEN MONTH(@FiscalYearStartDate) IN (7,8,9) THEN
					CASE
						WHEN MONTH(@Date) IN (1,2,3) THEN CAST(YEAR(@FiscalYearStartDate) AS VARCHAR) + '-Q3'
						WHEN MONTH(@Date) IN (4,5,6) THEN CAST(YEAR(@FiscalYearStartDate) AS VARCHAR) + '-Q4'
						WHEN MONTH(@Date) IN (7,8,9) THEN CAST(YEAR(@FiscalYearStartDate) AS VARCHAR) + '-Q1'
						WHEN MONTH(@Date) IN (10,11,12) THEN CAST(YEAR(@FiscalYearStartDate) AS VARCHAR) + '-Q2'
					END
				WHEN MONTH(@FiscalYearStartDate) IN (10,11,12) THEN
					CASE
						WHEN MONTH(@Date) IN (1,2,3) THEN CAST(YEAR(@FiscalYearStartDate) AS VARCHAR) + '-Q2'
						WHEN MONTH(@Date) IN (4,5,6) THEN CAST(YEAR(@FiscalYearStartDate) AS VARCHAR) + '-Q3'
						WHEN MONTH(@Date) IN (7,8,9) THEN CAST(YEAR(@FiscalYearStartDate) AS VARCHAR) + '-Q4'
						WHEN MONTH(@Date) IN (10,11,12) THEN CAST(YEAR(@FiscalYearStartDate) AS VARCHAR) + '-Q1'
					END
			END,
			-- Fiscal last day in qtr ind [70]
			CASE
				WHEN CAST(@Date AS DATE) = DATEADD(DAY,-1,DATEADD(MONTH,3,CAST(DATEADD(QUARTER,DATEDIFF(QUARTER,0,@Date),0) AS DATE))) THEN 1
				ELSE 0	 				 				  	  		   			
			END, 
			-- Fiscal start date in qtr [71]
			CAST(DATEADD(QUARTER,DATEDIFF(QUARTER,0,@Date),0) AS DATE), 
			-- Fiscal end date of qtr [72]
			DATEADD(DAY,-1,DATEADD(MONTH,3,CAST(DATEADD(QUARTER,DATEDIFF(QUARTER,0,@Date),0) AS DATE))), 
			-- Fiscal year nbr [73]
			YEAR(@FiscalYearStartDate), 
			-- last Fiscal day in year ind [74]
			CASE
		 		WHEN @Date = @FiscalYearEndDate THEN 1
				ELSE 0
			END, 
			-- Fiscal start of year date [75]
			@FiscalYearStartDate, 
			-- Fiscal end of year date [76]
			@FiscalYearEndDate
 
	SET @i = @i + 1
	SET @Date = DATEADD(DAY,1,@Date)
	
	IF @Date > @FiscalYearEndDate
		BEGIN
			SET @FiscalYearStartDate = DATEADD(YEAR,1,@FiscalYearStartDate)
			SET @FiscalYearEndDate = DATEADD(YEAR,1,@FiscalYearEndDate)
		END
END