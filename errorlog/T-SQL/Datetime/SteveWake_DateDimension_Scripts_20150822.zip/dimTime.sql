USE EDW
GO

-- ###############################################################################
-- Create CORE schema that all Time Dimension tables will be stored in.
-- ###############################################################################
IF NOT EXISTS (SELECT * FROM sys.schemas (NOLOCK) WHERE name = 'dm')
BEGIN
	EXEC('CREATE SCHEMA [dm]')
END
GO

-- ###############################################################################
-- Drop table dimTime, if it currently exists and all Exptended Properties that go with it.
-- ###############################################################################
IF EXISTS (SELECT * FROM sys.tables (NOLOCK) WHERE name = 'dimTime')
BEGIN
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimTime'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimTime', @level2type=N'COLUMN',@level2name=N'TimePK'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimTime', @level2type=N'COLUMN',@level2name=N'TimeSecond'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimTime', @level2type=N'COLUMN',@level2name=N'Time24Desc'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimTime', @level2type=N'COLUMN',@level2name=N'Time12Desc'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimTime', @level2type=N'COLUMN',@level2name=N'TimeAMInd'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimTime', @level2type=N'COLUMN',@level2name=N'TimePMInd'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimTime', @level2type=N'COLUMN',@level2name=N'TimeAMPMDesc'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimTime', @level2type=N'COLUMN',@level2name=N'Hour24Num'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimTime', @level2type=N'COLUMN',@level2name=N'Hour12Num'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimTime', @level2type=N'COLUMN',@level2name=N'MinuteNum'
	EXEC sys.sp_dropextendedproperty @name=N'Description' , @level0type=N'SCHEMA',@level0name=N'dm', @level1type=N'TABLE',@level1name=N'dimTime', @level2type=N'COLUMN',@level2name=N'SecondNum'
	DROP TABLE [dm].[dimTime]
END
GO

-- ###############################################################################
-- Create table dm.dimTime
-- ###############################################################################
CREATE TABLE [dm].[dimTime] (
       TimePK INT NOT NULL,
       TimeSecond TIME(0) NULL,
	   Time24Desc VARCHAR(8) NOT NULL,
	   Time12Desc VARCHAR(8) NOT NULL,
	   TimeAMInd BIT NOT NULL,
	   TimePMInd BIT NOT NULL,
	   TimeAMPMDesc	CHAR(2) NOT NULL,
       Hour24Num INT NOT NULL,
	   Hour12Num INT NOT NULL,
       MinuteNum INT NOT NULL,
       SecondNum INT NOT NULL
	   CONSTRAINT PK_dimTime
			PRIMARY KEY CLUSTERED (TimePK)
			WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
) ON [PRIMARY]
GO

ALTER TABLE [dm].[dimTime] ADD CONSTRAINT [dimTime_U1] UNIQUE 
(
	[TimeSecond] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value='Time Dimension contains a time down to seconds.'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = N'dimTime'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Key is a system-generated surrogate identifier. Reserved for data warehouse use, this key should be invisible to the typical business user.'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimTime'
	, @level2type = N'Column', @level2name = 'TimePK'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Time in Seconds is the actual time down to seconds.'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimTime'
	, @level2type = N'Column', @level2name = 'TimeSecond'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Full Time Description is the full description of the time in 24 hour clock format - e.g., 00:00:00 for Midnight.'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimTime'
	, @level2type = N'Column', @level2name = 'Time24Desc'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Full Time Description is the full description of the time in 12 hour clock format - e.g., 12:00:00 for Midnight'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimTime'
	, @level2type = N'Column', @level2name = 'Time12Desc'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Time AM (ante meridiem) indicator (1 = AM, 0 = PM), before midday'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimTime'
	, @level2type = N'Column', @level2name = 'TimeAMInd'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Time PM (post meridiem) indidcator (1 = PM, 0 = AM), after midday'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimTime'
	, @level2type = N'Column', @level2name = 'TimePMInd'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Time AM/PM Description, e.g., AM or PM'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimTime'
	, @level2type = N'Column', @level2name = 'TimeAMPMDesc'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Hour of time in 24 hour format, 0 thru 23 are the only valid values (24 can be used in place of 0)'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimTime'
	, @level2type = N'Column', @level2name = 'Hour24Num'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Hour of time in 12 hour format, 1 thru 12 are the only valid values'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimTime'
	, @level2type = N'Column', @level2name = 'Hour12Num'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Minute of time, 0 thru 59 are the only valid values'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimTime'
	, @level2type = N'Column', @level2name = 'MinuteNum'
GO

EXEC sp_addextendedproperty 
	  @name = N'Description', @value = 'Second of time, 0 thru 59 are the only valid values'
	, @level0type = N'Schema', @level0name = 'dm'
	, @level1type = N'Table', @level1name = 'dimTime'
	, @level2type = N'Column', @level2name = 'SecondNum'
GO

-- ##################################################################
-- Insert Rows
-- ##################################################################
DECLARE @Hour AS INT
DECLARE @Minute AS INT
DECLARE @Second AS INT

SET @Hour = 0
SET @Minute = 0
SET @Second = 0

WHILE (@Hour <= 23)
	BEGIN
	  INSERT INTO dm.dimTime
		SELECT
			-- Time key as integer [1]
			@Hour*10000+@Minute*100+@Second,
			-- Time down to seconds [2]
			CAST(RIGHT('0' + CONVERT(VARCHAR(2),@Hour),2) + ':' + RIGHT('0' + CONVERT(VARCHAR(2),@Minute),2) + ':' + RIGHT('0' + CONVERT(VARCHAR(2),@Second),2)AS TIME),
			-- Time in 24 hour clock format as text [3]
			RIGHT('0' + CONVERT(VARCHAR(2),@Hour), 2) + ':' + RIGHT('0' + CONVERT(VARCHAR(2),@Minute), 2) + ':' + RIGHT('0' + CONVERT(VARCHAR(2),@Second), 2),
			-- Time in 12 hour clock format as text [4]
			RIGHT('0' + CONVERT(VARCHAR(2),CASE WHEN @Hour <= 12 THEN @Hour ELSE @Hour-12 END), 2) + ':' + RIGHT('0' + CONVERT(VARCHAR(2),@Minute), 2) + ':' + RIGHT('0' + CONVERT(VARCHAR(2),@Second), 2),
			-- AM (ante meridiem) indicator - 0,1 [5]
			CASE
				WHEN @Hour <= 11 THEN 1
				ELSE 0
			END, 
			-- PM (post meridiem) indicator - 0,1 [6]
			CASE
				WHEN @Hour >= 12 THEN 1
				ELSE 0
			END,
			-- AM/PM text [7]
			CASE
				WHEN @Hour >= 12 THEN 'PM'
				ELSE 'AM'
			END,
			-- Hour as a number in 24 hour format - 0-23 [8]
			@Hour,
			-- Hour as a number in 12 hour format - 1-12 [9]
			CASE WHEN @Hour <= 12 THEN @Hour ELSE @Hour-12 END,
			-- Minutes as a number - 0-59 [10]
			@Minute,
			-- Seconds as a number - 0-59 [11]
			@Second 

			SET @Minute = 1

			WHILE (@Minute <= 59)
				BEGIN
					INSERT INTO dm.dimTime
						SELECT
							-- Time key as integer [1]
							@Hour*10000+@Minute*100+@Second,
							-- Time down to seconds [2]
							CAST(RIGHT('0' + CONVERT(VARCHAR(2),@Hour),2) + ':' + RIGHT('0' + CONVERT(VARCHAR(2),@Minute),2) + ':' + RIGHT('0' + CONVERT(VARCHAR(2),@Second),2)AS TIME),
							-- Time in 24 hour clock format as text [3]
							RIGHT('0' + CONVERT(VARCHAR(2),@Hour), 2) + ':' + RIGHT('0' + CONVERT(VARCHAR(2),@Minute), 2) + ':' + RIGHT('0' + CONVERT(VARCHAR(2),@Second), 2),
							-- Time in 12 hour clock format as text [4]
							RIGHT('0' + CONVERT(VARCHAR(2),CASE WHEN @Hour <= 12 THEN @Hour ELSE @Hour-12 END), 2) + ':' + RIGHT('0' + CONVERT(VARCHAR(2),@Minute), 2) + ':' + RIGHT('0' + CONVERT(VARCHAR(2),@Second), 2),
							-- AM (ante meridiem) indicator - 0,1 [5]
							CASE
								WHEN @Hour <= 11 THEN 1
								ELSE 0
							END, 
							-- PM (post meridiem) indicator - 0,1 [6]
							CASE
								WHEN @Hour >= 12 THEN 1
								ELSE 0
							END,
							-- AM/PM text [7]
							CASE
								WHEN @Hour >= 12 THEN 'PM'
								ELSE 'AM'
							END,
							-- Hour as a number in 24 hour format - 0-23 [8]
							@Hour,
							-- Hour as a number in 12 hour format - 1-12 [9]
							CASE WHEN @Hour <= 12 THEN @Hour ELSE @Hour-12 END,
							-- Minutes as a number - 0-59 [10]
							@Minute,
							-- Seconds as a number - 0-59 [11]
							@Second 

							SET @Second = 1

							WHILE (@Second <= 59)
								BEGIN
									INSERT INTO dm.dimTime
										SELECT
											-- Time key as integer [1]
											@Hour*10000+@Minute*100+@Second,
											-- Time down to seconds [2]
											CAST(RIGHT('0' + CONVERT(VARCHAR(2),@Hour),2) + ':' + RIGHT('0' + CONVERT(VARCHAR(2),@Minute),2) + ':' + RIGHT('0' + CONVERT(VARCHAR(2),@Second),2)AS TIME),
											-- Time in 24 hour clock format as text [3]
											RIGHT('0' + CONVERT(VARCHAR(2),@Hour), 2) + ':' + RIGHT('0' + CONVERT(VARCHAR(2),@Minute), 2) + ':' + RIGHT('0' + CONVERT(VARCHAR(2),@Second), 2),
											-- Time in 12 hour clock format as text [4]
											RIGHT('0' + CONVERT(VARCHAR(2),CASE WHEN @Hour <= 12 THEN @Hour ELSE @Hour-12 END), 2) + ':' + RIGHT('0' + CONVERT(VARCHAR(2),@Minute), 2) + ':' + RIGHT('0' + CONVERT(VARCHAR(2),@Second), 2),
											-- AM (ante meridiem) indicator - 0,1 [5]
											CASE
												WHEN @Hour <= 11 THEN 1
												ELSE 0
											END, 
											-- PM (post meridiem) indicator - 0,1 [6]
											CASE
												WHEN @Hour >= 12 THEN 1
												ELSE 0
											END,
											-- AM/PM text [7]
											CASE
												WHEN @Hour >= 12 THEN 'PM'
												ELSE 'AM'
											END,
											-- Hour as a number in 24 hour format - 0-23 [8]
											@Hour,
											-- Hour as a number in 12 hour format - 1-12 [9]
											CASE WHEN @Hour <= 12 THEN @Hour ELSE @Hour-12 END,
											-- Minutes as a number - 0-59 [10]
											@Minute,
											-- Seconds as a number - 0-59 [11]
											@Second 

										SET @Second = @Second + 1
									END

						SET @Minute = @Minute + 1
						SET @Second = 0

				END

	SET @Hour = @Hour + 1
	SET @Minute = 0
	SET @Second = 0
END