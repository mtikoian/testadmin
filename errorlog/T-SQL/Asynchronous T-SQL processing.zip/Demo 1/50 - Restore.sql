use master;
go

-- Disater recovery: database is restored from backup
--
restore database DemoAsyncExec 
    from disk = N'c:\temp\demoasync.bak' 
    with enable_broker;
go

use DemoAsyncExec;
go

alter queue [AsyncExecQueue]
    with activation (
    status = on);
go

waitfor delay '00:00:15';
go

select * from [AsyncExecResults];
go