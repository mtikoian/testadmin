use DemoAsyncExec;
go

-------------------------------------------
-- A procedure that simulates a long delay
------------------------------------------
create procedure [usp_MyLongRunningProcedure]
as
begin
    waitfor delay '00:00:05';
end
go

-------------------------------
-- Invoke the lengthy procedure
--
declare @token uniqueidentifier;
exec usp_AsyncExecInvoke N'usp_MyLongRunningProcedure', @token output;
select * from [AsyncExecResults] where [token] = @token;
go


waitfor delay '00:00:10';
select * from [AsyncExecResults];
go


--------------------------------------
-- A procedure that simulates a PK violation
---------------------------------------
create procedure [usp_MyFaultyProcedure]
as
begin
    set nocount on;
    declare @t table (id int primary key);
    insert into @t (id) values (1);
    insert into @t (id) values (1);
end
go

----------------------------------
-- Invoke async the faulty procedure
--
declare @token uniqueidentifier;
exec usp_AsyncExecInvoke N'usp_MyFaultyProcedure', @token output;
waitfor delay '00:00:02';
select * from [AsyncExecResults] where [token] = @token;
go


