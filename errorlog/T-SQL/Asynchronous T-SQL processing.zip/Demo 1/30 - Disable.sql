use DemoAsyncExec;
go

alter queue [AsyncExecQueue]
    with activation (
    status = off);
go

-------------------------------
-- Invoke the lengthy procedure
--
declare @token uniqueidentifier;
exec usp_AsyncExecInvoke N'usp_MyLongRunningProcedure', @token output;
select * from [AsyncExecResults] where [token] = @token;
go

select * from [AsyncExecResults];
go
