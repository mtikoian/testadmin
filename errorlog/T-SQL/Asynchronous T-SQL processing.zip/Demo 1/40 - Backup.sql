use master;
go

backup database DemoAsyncExec to disk = N'c:\temp\demoasync.bak' with init;
go

-- Simulate a disaster: database is lost
--
alter database DemoAsyncExec set read_only with rollback immediate;
drop database DemoAsyncExec;
go