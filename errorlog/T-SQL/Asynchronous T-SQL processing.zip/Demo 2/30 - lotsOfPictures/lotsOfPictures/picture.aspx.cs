using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

namespace lotsOfPictures
{
    public partial class picture : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            int pictureId = Convert.ToInt32(Request["id"]);
            short size = Convert.ToInt16(Request["size"]);

            string connStr = ConfigurationManager.ConnectionStrings[1].ConnectionString;

            using (SqlConnection conn = new SqlConnection(connStr))
            {
                conn.Open();

                SqlCommand cmd = new SqlCommand(
@"SELECT picture 
FROM resized_pictures 
WHERE picture_id = @id
AND picture_size = @size;", conn);
                cmd.Parameters.AddWithValue("@id", pictureId);
                cmd.Parameters.AddWithValue("@size", size);

                using (SqlDataReader rdr = cmd.ExecuteReader(
                    CommandBehavior.SequentialAccess))
                {
                    if (rdr.Read())
                    {
                        Response.ContentType = "image/jpeg";
                        byte[] bytes = new byte[1024];
                        long offSet = 0;
                        int countRead = (int) rdr.GetBytes(
                            0, offSet, bytes, 0, 1024);
                        while (countRead > 0)
                        {
                            Response.OutputStream.Write(bytes, 0, countRead);
                            offSet += countRead;
                            countRead = (int)rdr.GetBytes(
                                0, offSet, bytes, 0, 1024);
                        }
                    }
                }
            }
            
        }
    }
}
