using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Text;
using lotsOfPictures.Properties;

namespace lotsOfPictures
{
    public partial class _Default : System.Web.UI.Page
    {
        #region Show Pictures Grid
        protected string ShowPictures()
        {
            StringBuilder sb = new StringBuilder();
            
            string connStr = ConfigurationManager.ConnectionStrings[1].ConnectionString;

            using (SqlConnection conn = new SqlConnection(connStr))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(
@"SELECT picture_id FROM original_pictures;", conn);
                using (SqlDataReader rdr = cmd.ExecuteReader(CommandBehavior.SequentialAccess))
                {
                    int i = 0;
                    while (rdr.Read())
                    {

                        sb.Append("<tr>");
                        sb.AppendFormat("<td class=\"thumbnail\"><a href=\"Picture.aspx?id={0}&size=768\"><img src=\"Picture.aspx?id={0}&size=64\"/></a></td>", rdr.GetInt32(0));
                        switch (++i % 3)
                        {
                            case 0:
                                sb.AppendFormat("<td class=\"imagetext\">{0}</td>", Resources.Lorem1);
                                break;
                            case 1:
                                sb.AppendFormat("<td class=\"imagetext\">{0}</td>", Resources.Lorem2);
                                break;
                            case 2:
                                sb.AppendFormat("<td class=\"imagetext\">{0}</td>", Resources.Lorem3);
                                break;
                        }
                        sb.Append("</tr>");
                    }
                }
            }
            return sb.ToString();
        }
        #endregion

        #region Upload Picture
        protected void Submit_Click(object sender, EventArgs e)
        {
            if (image.HasFile)
            {
                string connStr = ConfigurationManager.ConnectionStrings[1].ConnectionString;
                bool fUseAsync = false;

                using (SqlConnection conn = new SqlConnection(connStr))
                {
                    conn.Open();

                    SqlCommand cmd = new SqlCommand(
                        @"usp_uploadPicture", conn);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue(
                        "@picture", 
                        new SqlBytes(image.PostedFile.InputStream));
                    cmd.Parameters.AddWithValue(
                        "@useAsync", 
                        fUseAsync);
                    cmd.ExecuteNonQuery();
                }
            }
            Response.Redirect("/Default.aspx");
        }
        #endregion
    }
}
