using System;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using Microsoft.SqlServer.Server;
using System.Drawing;
using System.IO;
using System.Drawing.Imaging;
using System.Drawing.Drawing2D;

public partial class UserDefinedFunctions
{
    [Microsoft.SqlServer.Server.SqlFunction]
    public static SqlBytes udfResizeBitmap(
        SqlBytes picture,
        int nWidth,
        int nHeight)
    {
        Image originalImage = null;
        originalImage = Image.FromStream(picture.Stream);
        
        Image newImage = new Bitmap(nWidth, nHeight);
        Graphics gdi = Graphics.FromImage(newImage);

        gdi.InterpolationMode = InterpolationMode.HighQualityBicubic;
        gdi.SmoothingMode = SmoothingMode.HighQuality;
        gdi.PixelOffsetMode = PixelOffsetMode.HighQuality;
        gdi.CompositingQuality = CompositingQuality.HighQuality;

        gdi.DrawImage(originalImage, 0, 0, nWidth, nHeight);

        MemoryStream streamOutput = new MemoryStream();
        newImage.Save(streamOutput, ImageFormat.Jpeg);
        return new SqlBytes(streamOutput); 
    }
};

