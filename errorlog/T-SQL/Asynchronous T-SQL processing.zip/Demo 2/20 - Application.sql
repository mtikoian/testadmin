use DemoAsyncSite;
go

--------------------------------
-- System.Drawing is an unsuported assembly
-- Is needed for GDI operations to involved 
-- in resizing an image
--
create assembly [System.Drawing]
from 'C:\WINDOWS\Microsoft.NET\Framework\v2.0.50727\System.Drawing.dll'
with permission_set = unsafe;
go

---------------------------------
-- This table will contain the 
-- original uploaded pictures
--
create table original_pictures (
    picture_id int identity(1,1) not null,
    picture varbinary(max),
    constraint pk_original_pictures primary key(picture_id));
go

-----------------------------------
-- This table will contain the 
-- thumbnail and fixed size images
--
create table resized_pictures (
    picture_id int not null,
    picture_size smallint not null,
    picture varbinary(max),
    constraint pk_resized_pictures primary key (picture_id, picture_size),
    constraint chk_size check (picture_size in (32, 64, 256, 512, 768, 1024, 2048)),
    constraint fk_resized_pictures_original_picture
        foreign key (picture_id) references original_pictures(picture_id));
go

---------------------------------
-- Creates the thumbnail and fixed
-- size images for a new upload
--
create procedure usp_resizeUpload
    @pictureId int
as
begin
	set nocount on;
	declare @trancount int;
	set @trancount = @@trancount;
	begin try
		if @trancount = 0
			begin transaction
		else
			save transaction usp_resizeUpload;
        
        -- Read the original image
        --
		declare @originalImage varbinary(max);
        select @originalImage = picture 
            from original_pictures
            where picture_id = @pictureId;

        -- Insert the resized images
        --
        insert into resized_pictures (picture_id, picture_size, picture)
            values (@pictureId, 32, dbo.udfResizeBitmap(@originalImage, 32, 32));
        insert into resized_pictures (picture_id, picture_size, picture)
            values (@pictureId, 256, dbo.udfResizeBitmap(@originalImage, 256, 256));
        insert into resized_pictures (picture_id, picture_size, picture)
            values (@pictureId, 512, dbo.udfResizeBitmap(@originalImage, 512, 512));
        insert into resized_pictures (picture_id, picture_size, picture)
            values (@pictureId, 768, dbo.udfResizeBitmap(@originalImage, 768, 768));
        insert into resized_pictures (picture_id, picture_size, picture)
            values (@pictureId, 1024, dbo.udfResizeBitmap(@originalImage, 1024, 1024));
        insert into resized_pictures (picture_id, picture_size, picture)
            values (@pictureId, 2048, dbo.udfResizeBitmap(@originalImage, 2048, 2048));
	
lbexit:
		if @trancount = 0	
			commit;
	end try
	begin catch
		declare @error int, @message varchar(4000), @xstate int;
		select @error = ERROR_NUMBER(), @message = ERROR_MESSAGE(), @xstate = XACT_STATE();
		if @xstate = -1
			rollback;
		if @xstate = 1 and @trancount = 0
			rollback
		if @xstate = 1 and @trancount > 0
			rollback transaction usp_resizeUpload;

		raiserror ('usp_resizeUpload: %d: %s', 16, 1, @error, @message) ;
		return;
	end catch	
end
go

----------------------------------
-- This procedure uploads a new 
-- image into the database
-- If useAsync is 1 then the
-- thumbnail and fixed size images
-- are generated async
--
create procedure usp_uploadPicture
    @picture varbinary(max)
    , @useAsync bit = 1
as
begin
	set nocount on;
    declare @id int, @token uniqueidentifier;
	declare @trancount int;
	set @trancount = @@trancount;
	begin try
		if @trancount = 0
			begin transaction
		else
			save transaction usp_uploadPicture;

        insert into original_pictures (picture)
            values (@picture);
        set @id = scope_identity();

        -- Insert the thumbnail immedeatly
        --
        insert into resized_pictures (picture_id, picture_size, picture)
            values (@id, 64, dbo.udfResizeBitmap(@picture, 64, 64));

        if (1 = @useAsync)
        begin
            exec usp_AsyncExecInvoke 
                @procedureName = N'usp_resizeUpload'
                , @p1 = @id
                , @n1 = N'@pictureId'
                , @token = @token output;
        end
        else
        begin
            exec usp_resizeUpload @pictureId = @id
        end
	
lbexit:
		if @trancount = 0	
			commit;
	end try
	begin catch
		declare @error int, @message varchar(4000), @xstate int;
		select @error = ERROR_NUMBER(), @message = ERROR_MESSAGE(), @xstate = XACT_STATE();
		if @xstate = -1
			rollback;
		if @xstate = 1 and @trancount = 0
			rollback
		if @xstate = 1 and @trancount > 0
			rollback transaction usp_uploadPicture;

		raiserror ('usp_uploadPicture: %d: %s', 16, 1, @error, @message) ;
		return;
	end catch	
end
go

