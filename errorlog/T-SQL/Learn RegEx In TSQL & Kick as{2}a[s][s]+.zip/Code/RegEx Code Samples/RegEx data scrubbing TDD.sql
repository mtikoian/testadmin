USE [RegEx]

DECLARE @Test TABLE(
	  [First Name]	VARCHAR(50)
	, [Last Name]	VARCHAR(50)
	, [MI]			VARCHAR(50)
)

DECLARE @Pattern	VARCHAR(128)
INSERT INTO @Test( [First Name], [Last Name], MI ) VALUES  ( 'John Thomas', '', '')
INSERT INTO @Test( [First Name], [Last Name], MI ) VALUES  ( 'John, Thomas', '', '')
INSERT INTO @Test( [First Name], [Last Name], MI ) VALUES  ( 'John,Thomas', '', '')
INSERT INTO @Test( [First Name], [Last Name], MI ) VALUES  ( 'John Th.', '', '')


INSERT INTO @Test( [First Name], [Last Name], MI ) VALUES  ( 'John, JR', '', '')
INSERT INTO @Test( [First Name], [Last Name], MI ) VALUES  ( 'John, JR.', '', '')
INSERT INTO @Test( [First Name], [Last Name], MI ) VALUES  ( 'John, jr', '', '')
INSERT INTO @Test( [First Name], [Last Name], MI ) VALUES  ( 'John, jr.', '', '')

INSERT INTO @Test( [First Name], [Last Name], MI ) VALUES  ( 'John,JR', '', '')
INSERT INTO @Test( [First Name], [Last Name], MI ) VALUES  ( 'John,JR.', '', '')
INSERT INTO @Test( [First Name], [Last Name], MI ) VALUES  ( 'John,jr', '', '')
INSERT INTO @Test( [First Name], [Last Name], MI ) VALUES  ( 'John,jr.', '', '')

INSERT INTO @Test( [First Name], [Last Name], MI ) VALUES  ( 'John JR', '', '')
INSERT INTO @Test( [First Name], [Last Name], MI ) VALUES  ( 'John JR.', '', '')
INSERT INTO @Test( [First Name], [Last Name], MI ) VALUES  ( 'John jr', '', '')
INSERT INTO @Test( [First Name], [Last Name], MI ) VALUES  ( 'John jr.', '', '')

INSERT INTO @Test( [First Name], [Last Name], MI ) VALUES  ( 'John I', '', '')
INSERT INTO @Test( [First Name], [Last Name], MI ) VALUES  ( 'John II.', '', '')
INSERT INTO @Test( [First Name], [Last Name], MI ) VALUES  ( 'John III', '', '')
INSERT INTO @Test( [First Name], [Last Name], MI ) VALUES  ( 'John IV', '', '')
INSERT INTO @Test( [First Name], [Last Name], MI ) VALUES  ( 'John V', '', '')
INSERT INTO @Test( [First Name], [Last Name], MI ) VALUES  ( 'John V.', '', '')
INSERT INTO @Test( [First Name], [Last Name], MI ) VALUES  ( 'John v', '', '')
INSERT INTO @Test( [First Name], [Last Name], MI ) VALUES  ( 'John v.', '', '')
INSERT INTO @Test( [First Name], [Last Name], MI ) VALUES  ( 'Johnv', '', '')
INSERT INTO @Test( [First Name], [Last Name], MI ) VALUES  ( 'JohnV', '', '')
   
SET @Pattern = '^(\S*),.*'
--																										SET @Pattern = '([^,]*)(, | |,| ,)(sr|jr|i|ii|iii|iv|v)\.?$'

/*
SELECT 
	  [First Name]
	, util.RegExIsMatch (@Pattern, t.[First Name],1) IsMatch
	, util.RegExReplace([First Name],@Pattern,'$1') [1]
	, util.RegExReplace([First Name],@Pattern,'$2') [2]
	, util.RegExReplace([First Name],@Pattern,'$3') [3]
	, LEN(util.RegExReplace([First Name],@Pattern,'$3')) SuffixLen
	, @Pattern AS Pattern
FROM 
	@Test AS t
*/	



SELECT
	  [t].[First Name]
	, util.RegExReplace([First Name],@Pattern,'$1') AS [First Name Scrubbed]
	, UPPER(util.RegExReplace([First Name],@Pattern,'$3')) AS [Suffix Extracted]
FROM 
	@Test AS t	
WHERE
	util.RegExIsMatch (@Pattern, t.[First Name],1) =1


GO


/*
DECLARE @Test TABLE(
	  [SSN]	VARCHAR(50)
)


INSERT INTO @Test VALUES('1')
INSERT INTO @Test VALUES('12')
INSERT INTO @Test VALUES('123')
INSERT INTO @Test VALUES('12345')
INSERT INTO @Test VALUES('123456')
INSERT INTO @Test VALUES('1234567')
INSERT INTO @Test VALUES('12345678')
INSERT INTO @Test VALUES('123456789')
INSERT INTO @Test VALUES('123456789777')
INSERT INTO @Test VALUES('12345678A')


DECLARE @Pattern	VARCHAR(128)

SET @Pattern = '^\d{9}$'


SELECT 
	  [ssn]
	 , util.RegExIsMatch(@Pattern,[SSN],1) 
	 , LEFT('000'+[SSN],9)
FROM 
	@Test
	
*/

/*
DECLARE @Test TABLE(
	  [name]	VARCHAR(50)
)


INSERT INTO @Test VALUES('jr')
INSERT INTO @Test VALUES('jR')
INSERT INTO @Test VALUES('Jr')
INSERT INTO @Test VALUES('JR')
INSERT INTO @Test VALUES('jr.')
INSERT INTO @Test VALUES('jR.')
INSERT INTO @Test VALUES('Jr.')
INSERT INTO @Test VALUES('JR.')


DECLARE @Pattern	VARCHAR(128)

SET @Pattern = '[a-z]|\W'


SELECT 
	  [name]
	 , util.RegExIsMatch(@Pattern,[name],0) 
	 , UPPER(util.RegExReplace([name],'\W',''))
FROM 
	@Test
*/	
	
--select	util.RegExOptionEnumeration(1,0,0,0,0,0,0,0,0)