USE [RegEx]
go

DECLARE @Test TABLE(
	  [word]	VARCHAR(50)
	, IsMatch	BIT
)


INSERT INTO @Test VALUES('ass',1)
INSERT INTO @Test VALUES('assume',1)
INSERT INTO @Test VALUES('passanger',1)
INSERT INTO @Test VALUES('class',1)

INSERT INTO @Test VALUES('as',0)
INSERT INTO @Test VALUES('fast',0)
INSERT INTO @Test VALUES('aardvark',0) 

INSERT INTO @Test VALUES('cucumber',1) --this one is wrong on purpose to show that the TDD is working


DECLARE @Pattern	VARCHAR(128)

/*
Try different patterns as you develope your RegEx in a test harnes until you get a clean test
*/
SET @Pattern = 'as+'				-- + matches at least one or more of preceding character
--SET @Pattern = 'as*'				-- * matches zero or more of preceding character
--SET @Pattern = 'as{2}'			-- {n} repeat preveding charecter exactily n times
--SET @Pattern = 'as{2}|a[s][s]+'	-- | alternation {this}|{that} as in {this} or {that}
--SET @Pattern = 'ass'				-- literal match of text

SELECT 
	  T.[word]
	 , @Pattern AS Pattern
	 , T.[IsMatch]
	 , util.RegExIsMatch(@Pattern,T.[word],0) AS [RegExIsMatch]
	 , CASE
		WHEN util.RegExIsMatch(@Pattern,T.[word],0) = T.[IsMatch] THEN 'ok'
		ELSE 'ERROR!'
	  END AS TDDOK
FROM 
	@Test T

	
