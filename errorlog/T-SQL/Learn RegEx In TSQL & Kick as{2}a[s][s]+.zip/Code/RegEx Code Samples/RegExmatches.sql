USE [RegEx]
go

DECLARE @RouteTable	VARCHAR(MAX)

--Output of CMD: Route PRINT
/*
===========================================================================
IPv4 Route Table
===========================================================================
Active Routes:
Network Destination        Netmask          Gateway       Interface  Metric
*/
SET @RouteTable = '
          0.0.0.0          0.0.0.0      192.168.1.1    192.168.1.138     10
        127.0.0.0        255.0.0.0         On-link         127.0.0.1    306
        127.0.0.1  255.255.255.255         On-link         127.0.0.1    306
  127.255.255.255  255.255.255.255         On-link         127.0.0.1    306
      192.168.1.0    255.255.255.0         On-link     192.168.1.138    266
    192.168.1.138  255.255.255.255         On-link     192.168.1.138    266
    192.168.1.255  255.255.255.255         On-link     192.168.1.138    266
        224.0.0.0        240.0.0.0         On-link         127.0.0.1    306
        224.0.0.0        240.0.0.0         On-link     192.168.1.138    266
  255.255.255.255  255.255.255.255         On-link         127.0.0.1    306
  255.255.255.255  255.255.255.255         On-link     192.168.1.138    266'


-- a simple shred of the matching data
/*
select 
	* 
from 
	util.RegExMatches(
		'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}'
		 --'(\d{1,3}\.){3}\d{1,3}'
		, @RouteTable
		,0
		)
*/


/*
The next set of CTEs shows different techniques for shredding the data and combining into one final output select.
*/
;
WITH tbl_NetworkDestination AS (
	SELECT
		  ROW_NUMBER()OVER(ORDER BY [MatchIndex]) AS RowNumber
		, Match AS [Network Destination] 
	FROM	
		util.RegExMatches(
			'(?<=^ *)((\d{1,3}\.){3}\d{1,3})'
			, @RouteTable
			, 2 --Allow multiline
			)
)
,
tbl_Netmask AS (
	SELECT
		  ROW_NUMBER()OVER(ORDER BY [MatchIndex]) AS RowNumber
		, Match AS [Netmask] 
	from 
		util.RegExMatches(
			'(?<=^ *(\d{1,3}\.){3}\d{1,3} *)(\d{1,3}\.){3}\d{1,3}'
			, @RouteTable
			, 2 --Allow multiline
			)
)
,
tbl_Gateway AS (
	SELECT
		  ROW_NUMBER()OVER(ORDER BY [MatchIndex]) AS RowNumber
		, Match AS [Gateway] 
	from 
		util.RegExMatches(
			'(?<=^ *(\d{1,3}\.){3}\d{1,3} *(\d{1,3}\.){3}\d{1,3}\s+)\S+'
			, @RouteTable
			, 2 --Allow multiline
			)
)
, 
tbl_Interface AS (
	SELECT
		  ROW_NUMBER()OVER(ORDER BY [MatchIndex]) AS RowNumber
		, Match AS [Interface] 
	from 
		util.RegExMatches(
			'(?<=^ *(\d{1,3}\.){3}\d{1,3} *(\d{1,3}\.){3}\d{1,3}\s+\S+\s+)\S+'
			, @RouteTable
			, 2 --Allow multiline
			)
)
, 
tbl_Metric AS (
	SELECT
		  ROW_NUMBER()OVER(ORDER BY [MatchIndex]) AS RowNumber
		, Match AS [Metric] 
	from 
		util.RegExMatches(
			'(?<=^ *(\d{1,3}\.){3}\d{1,3} *(\d{1,3}\.){3}\d{1,3}\s+\S+\s+\S+\s+)\S+'
			, @RouteTable
			, 2 --Allow multiline
			)
)
SELECT
	  [NWD].[RowNumber]
	, [NWD].[Network Destination]
	, [NM].[Netmask] 
	, [GW].[Gateway]
	, [INF].[Interface]
	, [Met].[Metric]
FROM 
	[tbl_NetworkDestination] NWD
		INNER JOIN 
	[tbl_Netmask] NM
		ON [NWD].[RowNumber] = [NM].[RowNumber]
		INNER JOIN 
	[tbl_Gateway] GW
		ON [NM].[RowNumber] = [GW].[RowNumber]
		INNER JOIN 
	[tbl_Interface] INF
		ON [GW].[RowNumber] = [INF].[RowNumber]
		INNER JOIN 
	[tbl_Metric] Met
		ON [INF].[RowNumber] = [Met].[RowNumber]

		


		


/*
-- A simple sample showing how to use the enumeration to return an int for controlling RegEx options
-- the above sample needed multi line enabled to mate the leading ^ work for each line.
SELECT
	util.RegExOptionEnumeration
     (
		  0	--@IgnoreCase bit,
        , 1	--@MultiLine bit,
        , 0	--@ExplicitCapture bit,
        , 0	--@Compiled  bit,
        , 0	--@SingleLine  bit,
        , 0	--@IgnorePatternWhitespace  bit,
        , 0	--@RightToLeft  bit,
        , 0	--@ECMAScript  bit,
        , 0	--@CultureInvariant  bit
        )
 */