-------------------------------------------------------------------------------
-------------------------------------------------------------------------------
-- Simple test if the RegEx CLR functions are working
-------------------------------------------------------------------------------
-------------------------------------------------------------------------------
USE [RegEx]
GO

--Will Macth
SELECT 
	  'as{2}' AS [Pattern]
	, 'passanger' AS [Input]
	, util.RegExIsMatch('as{2}','passanger',0) AS [RegExIsMatch]
UNION ALL
--wont Match
SELECT 
	  'as{2}' AS [Pattern]
	, 'fast' AS [Input]
	, util.RegExIsMatch('as{2}','fast',0) AS [RegExIsMatch]
	




-------------------------------------------------------------------------------
-- Use [util].[RegExIsMatch] Scalar Function in WHERE claues
-------------------------------------------------------------------------------

DECLARE @WordList TABLE(
	  [word]	VARCHAR(50)
)

INSERT INTO @WordList VALUES('ass')
INSERT INTO @WordList VALUES('assume')
INSERT INTO @WordList VALUES('passanger')
INSERT INTO @WordList VALUES('class')
INSERT INTO @WordList VALUES('as')
INSERT INTO @WordList VALUES('fast')
INSERT INTO @WordList VALUES('cucumber')

-- List of words that match my pattern
SELECT
	  [WL].[word] 
	, 'I match! :)' AS MySnarkyComment
FROM 
	@WordList AS WL
WHERE
	util.RegExIsMatch('as{2}',[word],0) = 1


-- List of words that don't macth my pattern
SELECT
	  [WL].[word] 
	, 'I don''t match! :(' AS MySnarkyComment
FROM 
	@WordList AS WL
WHERE
	util.RegExIsMatch('as{2}',[word],0) = 0
	