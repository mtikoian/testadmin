DECLARE @Test TABLE(
	  [word]	VARCHAR(50)
	, IsMatch	BIT
)


-------------------------------------------------------------------------------
-------------------------------------------------------------------------------
-- values to tes
-------------------------------------------------------------------------------
-------------------------------------------------------------------------------

INSERT INTO @Test VALUES('',1)

INSERT INTO @Test VALUES('',0) 

DECLARE @Pattern	VARCHAR(128)

/*
Try different patterns as you develope your RegEx in a test harnes until you get a clean test
*/
SET @Pattern = '.*'	
SELECT 
	  T.[word]
	 , @Pattern AS Pattern
	 , T.[IsMatch]
	 , util.RegExIsMatch(@Pattern,T.[word],0) AS [RegExIsMatch]
	 , CASE
		WHEN util.RegExIsMatch(@Pattern,T.[word],0) = T.[IsMatch] THEN 'ok'
		ELSE 'ERROR!'
	  END AS TDDOK
FROM 
	@Test T