USE [master]
GO

IF  EXISTS (SELECT name FROM sys.databases WHERE name = N'RegEx')
DROP DATABASE [RegEx]
GO


/*
sp_who2

kill 59
*/