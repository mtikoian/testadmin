USE [RegEx]
go

DECLARE @Test TABLE(
	  [PhoneNumber]	VARCHAR(50)
)

DECLARE @Pattern	VARCHAR(128)


INSERT INTO @Test 
		  SELECT '(610)555-1212'
UNION ALL SELECT '(610) 555-1212'
UNION ALL SELECT 'l(610) 555-1212'
UNION ALL SELECT '610.555.1212'
UNION ALL SELECT '610 555 1212'
UNION ALL SELECT '610 555-1212'
UNION ALL SELECT '6105551212'

UNION ALL SELECT '(610) 555-1212 x456'
UNION ALL SELECT '(610) 555-1212 ext:456'

UNION ALL SELECT '(610) 555-1212 (x456)'
UNION ALL SELECT '610 555-1212 456'
UNION ALL SELECT '610 555-1212 Bob'
UNION ALL SELECT '610 567-1212 Bob'

--UNION ALL SELECT '610 55s-1212 Bob' -- example of what won't work since there is a char where a digit is expexted
UNION ALL SELECT '(610) 555-1212 ext:4v6'  -- example of how the logic is set to take the next number after the last 4 as extension

-------------------------------------------------------------------------------
-- Simple case - Replace all non digits with blank
-------------------------------------------------------------------------------
--SET @Pattern = '\D'
--SELECT
--	  [PhoneNumber]
--	, util.RegExReplace([PhoneNumber],@Pattern,'') AS MyCleanPhoneNumber
--	, @Pattern AS Pattern
--FROM 
--	@Test AS T




SET @Pattern = '(\d{3})'		-- Macth 3 digits AND GROUP together
								-- Doesn't work becasue it can match mulptiple ways
/* -- Move this comment open mark down to see the effect of each variation in pattern								

SET @Pattern = '^(\d{3})'		-- leading ^ anchors to start of string
								-- Doesn't work becasue it can match mulptiple ways

SET @Pattern = '^(\d{3}).*'		-- .* says match any other charecters after first 3 digits
								-- works for some but not all
SET @Pattern = '^\D(\d{3}).*'	-- match start of string + 1 none digit char before 3 digits
								-- works for some but not all
								
								
SET @Pattern = '^\D?(\d{3}).*'	-- Same as last one but allows for firsst char to be optional hence the ?
								-- yeah we finaly got the first three numbers
								
SET @Pattern = '^\D*(\d{3}).*'	-- same as prvious but * means zero or more ? means previous optional
								-- This is better if there could be more than one non digit before the first 3


SET @Pattern = '^[^0-9]*([0-9][0-9][0-9]).*'  -- Same as previous but showing alt syntax for RegEx digit ranges

--Uncomment AS LocalExchange in ouput select below
SET @Pattern = '^\D*(\d{3})(\d{3}).*'	-- Now look for the next 3 digits
										-- Only works for the case that is all digits
														

SET @Pattern = '^\D*(\d{3})\D*(\d{3}).*'	-- Added \D* to allow for optional non digit chars betwen first and second set of 3 digits

--Uncomment more lines in the output select below.
SET @Pattern = '^\D*(\d{3})\D*(\d{3})\D*(\d{4})'	-- get next set of 4
													-- good for most but doesnt handle extra data at the end														
	

SET @Pattern = '^\D*(\d{3})\D*(\d{3})\D*(\d{4})\D*(\d*)$'  -- $ pins to end of string  Frouth group grabs last set of digits
SET @Pattern = '^\D*(\d{3})\D*(\d{3})\D*(\d{4})\D*(\d*).*$'  -- $ pins to end of string  Frouth group grabs last set of digits
SET @Pattern = '^\D*(\d{3})\D*(\d{3})\D*(\d{4})\D*(\d*).*'  -- $ doesn't pin to end of string  Frouth group grabs last set of digits
*/


-- Uncomment more of the output lines as the complexity of the pattern evolves
SELECT
	  [PhoneNumber]
	, util.RegExReplace([PhoneNumber],@Pattern,'$1') AS AreaCode --$1 means use the first BackReference group
	--, util.RegExReplace([PhoneNumber],@Pattern,'$2') AS LocalExchange
	--, util.RegExReplace([PhoneNumber],@Pattern,'$3') AS DNIS_DID
	--, util.RegExReplace([PhoneNumber],@Pattern,'$4') AS Extension 

	---- Replacment parameter can be complex with multiple backreferences
	--, util.RegExReplace([PhoneNumber],@Pattern,'($1) $2-$3') AS MyCleanPhoneNumber 
	--, util.RegExReplace([PhoneNumber],@Pattern,'DNIS:$3 Exchange: $1$2') AS SpecialFormatting
	--, util.RegExReplace([PhoneNumber],@Pattern,'($1) $2-$3 x$4 areacode=$1 ')  --reforamts extension but does it for all
	, @Pattern AS Pattern
FROM 
	@Test AS T
-- Where clause added at reques in session to find numbers where local exchange is 555	
--WHERE
--	util.RegExIsMatch('^\D*(\d{3})\D*(555)\D*(\d{4})\D*(\d*).*',[PhoneNumber],0) =0
