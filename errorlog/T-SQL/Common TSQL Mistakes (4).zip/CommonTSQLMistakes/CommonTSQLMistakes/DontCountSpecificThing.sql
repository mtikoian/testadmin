--DO NOT COUNT SPECIFIC THING UNLESS REALLY MEAN IT
--PROBABLY ONLY WHEN COUNTING DISTINCT

use AdventureWorks2012
go

set statistics io on

select count(CarrierTrackingNumber)
from Sales.SalesOrderDetail with (nolock)

-----------
60919   --Did you REALLY want to dismiss NULL values??
Warning: Null value is eliminated by an aggregate or other SET operation.

1.13 cost
Table 'SalesOrderDetail'. Scan count 1, logical reads 1245

select count(*)
from Sales.SalesOrderDetail with (nolock)

-----------
121317

0.367 cost  --optimizer picks the tightest index to count
Table 'SalesOrderDetail'. Scan count 1, logical reads 275, physical reads 0, read-ahead reads 284


select count(DISTINCT CarrierTrackingNumber)
from Sales.SalesOrderDetail with (nolock)

-----------
3806
Warning: Null value is eliminated by an aggregate or other SET operation.

1.97 cost
Table 'Worktable'. Scan count 0, logical reads 0, physical reads 0, read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.
Table 'Workfile'. Scan count 0, logical reads 0, physical reads 0, read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.
Table 'SalesOrderDetail'. Scan count 1, logical reads 1245, physical reads 0, read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.
