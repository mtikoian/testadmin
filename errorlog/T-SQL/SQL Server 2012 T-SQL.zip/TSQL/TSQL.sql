USE AdventureWorks2012;
GO

IF EXISTS(SELECT * FROM sys.objects WHERE NAME = 'Table1') DROP TABLE Table1;
IF EXISTS(SELECT * FROM sys.objects WHERE NAME = 'Table2') DROP TABLE Table2;

--Create a SEQUENCE
IF EXISTS(SELECT * FROM sys.objects WHERE NAME = 'mySequence')
	DROP SEQUENCE mySequence

CREATE SEQUENCE mySequence AS
	BIGINT --TINYINT, SMALLINT, INT, DECIMAL and NUMERIC (0 scale)
	START WITH 1
	INCREMENT BY 1;

--Select values from the sequence
SELECT NEXT VALUE FOR mySequence;
SELECT NEXT VALUE FOR mySequence;



/*
CREATE SEQUENCE [schema_name . ] sequence_name
        [ <sequence_property_assignment> [ ,�n ] ]
    [ ; ]

<sequence_property_assignment>::=
{
    [ AS { built_in_integer_type | user-defined_integer_type } ]
    | START WITH <constant> 
        | INCREMENT BY <constant> 
        | { MINVALUE <constant> | NO MINVALUE }
        | { MAXVALUE <constant> | NO MAXVALUE }
        | { CYCLE | NO CYCLE }
        | { CACHE [<constant> ] | NO CACHE }
}
*/

--A sequence with no options
IF EXISTS(SELECT * FROM sys.objects WHERE name = 'test1')
	DROP SEQUENCE test1;

CREATE SEQUENCE test1;


--View Properties of the sequences
SELECT * FROM sys.sequences;


--Restart
ALTER SEQUENCE mySequence RESTART WITH 1;
--Use in a query, numbers in order of ProductID
SELECT NEXT VALUE FOR mySequence 
OVER(ORDER BY ProductID) 
AS SEQ,
	Name, ProductID
FROM [Production].[Product]
ORDER BY ProductID;


ALTER SEQUENCE mySequence RESTART WITH 1;

--Numbers in order of ProductID, but sort results
--by Name
SELECT NEXT VALUE FOR mySequence 
OVER(ORDER BY ProductID) 
AS SEQ,Color,
	Name, ProductID
FROM [Production].[Product]
where Color is not null
order by Name;

--Use like an Identity in 2 tables
ALTER SEQUENCE mySequence RESTART WITH 1;
IF EXISTS(SELECT * FROM sys.objects WHERE NAME = 'Table1') DROP TABLE Table1;
IF EXISTS(SELECT * FROM sys.objects WHERE NAME = 'Table2') DROP TABLE Table2;
GO
CREATE TABLE Table1 (Col1 INT, Col2 INT DEFAULT (NEXT VALUE FOR mySequence));
CREATE TABLE Table2 (Col3 INT, Col4 INT DEFAULT (NEXT VALUE FOR mySequence));

INSERT INTO Table1 (Col1) VALUES(1),(2),(3),(4);
INSERT INTO Table2 (Col3) VALUES(5),(6),(7),(8);

SELECT * FROM Table1;
SELECT * FROM Table2;

INSERT INTO Table1 (Col1) VALUES (7);
INSERT INTO Table2 (Col3) VALUES (9);

SELECT * FROM Table1;
SELECT * FROM Table2;

IF EXISTS(SELECT * FROM sys.objects WHERE NAME = 'Table1') DROP TABLE Table1;
IF EXISTS(SELECT * FROM sys.objects WHERE NAME = 'Table2') DROP TABLE Table2;




--Cycling example
IF OBJECT_ID('cycling') IS NOT NULL DROP SEQUENCE cycling;
Go
CREATE SEQUENCE cycling AS INT
	MINVALUE 1
	MAXVALUE 5
	CYCLE;
	
SELECT NEXT VALUE FOR cycling 
OVER(ORDER BY ProductID) 
AS SEQ,
	Name, ProductID
FROM [Production].[Product]
ORDER BY ProductID;
--END SEQUENCE






--FUNCTIONS
--Date/Time functions
--Date Time from Parts
SELECT DATEFROMPARTS(2011,8,6);

--End of month
SELECT EOMONTH(GETDATE(),-1);
--END Date/Time


--Conversion functions
--PARSE ( string_value AS data_type [ USING culture ] )
SELECT PARSE('August 6, 2011' AS SMALLDATETIME);

SELECT PARSE('ABCDE' AS SMALLDATETIME);

--TRY_PARSE ( string_value AS data_type [ USING culture ] )
SELECT TRY_PARSE('August 6, 2011' AS SMALLDATETIME);
SELECT TRY_PARSE('ABCDE' AS SMALLDATETIME);

--TRY_CONVERT ( data_type [ ( length ) ], expression [, style ] )
SELECT CONVERT(VARCHAR,GETDATE(),101);
SELECT CONVERT(INT,'123');

SELECT CONVERT(INT, 'ABC');

SELECT TRY_CONVERT(INT, 'ABC');
--END CONVERSION

--Logical Functions
--IIF
--Current CASE
SELECT CASE WHEN 1 = 2 THEN '1 equals 2' ELSE '1 does not equal 2' END;
SELECT IIF(1 = 2, '1 equals 2','1 does not equal 2');

--CHOOSE
SELECT Name, ProductID, CHOOSE(ProductID % 3 + 1, 'Apples','Oranges','Pears')
FROM Production.Product
ORDER BY ProductID;
--END Logical functions


--String functions
--CONCAT
SELECT 'abc' + NULL + 'def' + 'ghi';
SELECT CONCAT('abc',NULL,'def' + 'ghi')


--FORMAT
SELECT FORMAT(GETdATE(),'MM/dd/yyyy');
SELECT FORMAT(GETDATE(),'MMMM dd, yyyy');
SELECT FORMAT(1234,'C');
--END functions


USE AdventureWorks2012;
GO
SET STATISTICS IO ON

--Today, Running total by customer
SELECT CustomerID, SalesOrderID, OrderDate, TotalDue,
	(SELECT SUM(TotalDue)
	FROM Sales.SalesOrderHeader B
	WHERE A.CustomerID = B.CustomerID 
	AND B.SalesOrderID <= A.SalesOrderID) AS RunningTotal
FROM Sales.SalesOrderHeader A
ORDER BY CustomerID, SalesOrderID

--Using ROWS
SELECT CustomerID, SalesOrderID, OrderDate, TotalDue,
	SUM(TotalDue) 	OVER(
		PARTITION BY CustomerID ORDER BY SalesOrderID
		  ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS RunningTotal
FROM Sales.SalesOrderHeader
ORDER BY CustomerID, SalesOrderID;


--Using Reverse running total
SELECT CustomerID, SalesOrderID, OrderDate, TotalDue,
	SUM(TotalDue) 
		OVER(PARTITION BY CustomerID ORDER BY SalesOrderID
		     ROWS BETWEEN CURRENT ROW AND UNBOUNDED FOLLOWING) 
			 AS ReverseRunningTotal
FROM Sales.SalesOrderHeader
ORDER BY CustomerID, SalesOrderID;

-- Traditional approach
--Find previous order
USE AdventureWorks2012;
GO
SELECT CustomerID, SalesOrderID, OrderDate,
	(SELECT TOP(1) OrderDate 
	FROM Sales.SalesOrderHeader b
	WHERE b.CustomerID = a.CustomerID
		AND b.OrderDate < a.OrderDate) AS PreviousOrder
FROM Sales.SalesOrderHeader a
ORDER BY CustomerID, OrderDate;
--Lag
SELECT CustomerID, SalesOrderID, OrderDate, 
	 LAG(OrderDate) OVER( PARTITION BY CustomerID 
		ORDER BY OrderDate) AS PreviousOrder
FROM Sales.SalesOrderHeader 
ORDER BY CustomerID, OrderDate;


--End OVER

--Ad-hoc Query Paging
USE AdventureWorksDWDenali;
GO
SELECT EnglishProductName, ProductAlternateKey
FROM dbo.DimProduct
ORDER BY ProductAlternateKey;

--Get rows 6 and on
SELECT EnglishProductName, ProductAlternateKey
FROM dbo.DimProduct
ORDER BY ProductAlternateKey
 OFFSET 5 ROWS;

--Start with 6th rows and fetch only 10
SELECT EnglishProductName, ProductAlternateKey
FROM dbo.DimProduct
ORDER BY ProductAlternateKey
	OFFSET 5 ROWS FETCH NEXT 10 ROWS ONLY;

--stored proc example
USE AdventureWorks2012
GO
IF OBJECT_ID('dbo.GetPagedProductsByColor') IS NOT NULL DROP PROC dbo.GetPagedProductsByColor;
GO

CREATE PROC GetPagedProductsByColor
	@PageNumber INT= 1,-- Default to first page
	@RowsPerPage INT= 10  -- Default to 10 rows per page

AS BEGIN
DECLARE @RowsToSkip INT= @RowsPerPage * (@PageNumber- 1);

SELECT ProductID, Name,Color, Size 
FROM Production.Product
ORDER BY Color,ProductID ASC
	OFFSET @RowsToSkip ROWS           -- New ORDER BY options
FETCH NEXT @RowsPerPage ROWS ONLY;
END;

GO
EXEC GetPagedProductsByColor @PageNumber = 1;
GO
EXEC GetPagedProductsByColor @PageNumber = 30;

--END PAGING





--THROW
SET STATISTICS IO OFF

IF EXISTS(SELECT * FROM sys.objects WHERE name = 'Table_PK') DROP TABLE Table_PK
CREATE TABLE Table_PK (Col1 INT PRIMARY KEY)

IF EXISTS(SELECT * FROM sys.objects WHERE name = 'ERROR_LOG') DROP TABLE ERROR_LOG
CREATE TABLE ERROR_LOG (ErrorDate DATETIME2, ErrorNumber INT, ErrorMessage NVARCHAR(256))

THROW 50001,'an error message',10

--inside TRY/CATCH
BEGIN TRY
	INSERT INTO Table_PK(Col1) VALUES(1);
	INSERT INTO Table_PK(Col1) VALUES(1);
END TRY
BEGIN CATCH
	INSERT INTO ERROR_LOG(ErrorDate,ErrorNumber,ErrorMessage)
	VALUES(getdate(),ERROR_NUMBER(),ERROR_MESSAGE());
	THROW;
END CATCH
--END THROW


--END T-SQL
