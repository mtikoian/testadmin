-- List all sales order numbers and line item totals with a line item total
-- over $100,000, using a subquery
SELECT 
	LineItemTotals.SalesOrderNumber, 
	LineItemTotals.LineItemTotal
FROM
	(
		SELECT 
			SalesOrderNumber	= SalesOrderHeader.SalesOrderNumber, 
			LineItemTotal		= SUM(SalesOrderDetail.LineTotal)
		FROM Sales.SalesOrderHeader
		INNER JOIN Sales.SalesOrderDetail
			ON SalesOrderHeader.SalesOrderID = SalesOrderDetail.SalesOrderID
		GROUP BY SalesOrderHeader.SalesOrderNumber
	) AS LineItemTotals
WHERE LineItemTotals.LineItemTotal > 100000;

-- Now create this standard, non-indexed view using to take the place
-- of our subquery
CREATE VIEW Sales.SalesOrderLineItemTotals_NormalView
AS
SELECT 
	SalesOrderNumber	= SalesOrderHeader.SalesOrderNumber, 
	LineItemTotal		= SUM(SalesOrderDetail.LineTotal)
FROM Sales.SalesOrderHeader
INNER JOIN Sales.SalesOrderDetail
	ON SalesOrderHeader.SalesOrderID = SalesOrderDetail.SalesOrderID
GROUP BY SalesOrderHeader.SalesOrderNumber;

-- List all sales order numbers and line item totals with a line item total
-- over $100,000, using a view
SELECT
	SalesOrderNumber,
	LineItemTotal
FROM Sales.SalesOrderLineItemTotals_NormalView
WHERE LineItemTotal > 100000;

-- Compare the query plans:
-- List all sales order numbers and line item totals with a line item total
-- over $100,000, using a subquery
SELECT 
	LineItemTotals.SalesOrderNumber, 
	LineItemTotals.LineItemTotal
FROM
	(
		SELECT 
			SalesOrderNumber	= SalesOrderHeader.SalesOrderNumber, 
			LineItemTotal		= SUM(SalesOrderDetail.LineTotal)
		FROM Sales.SalesOrderHeader
		INNER JOIN Sales.SalesOrderDetail
			ON SalesOrderHeader.SalesOrderID = SalesOrderDetail.SalesOrderID
		GROUP BY SalesOrderHeader.SalesOrderNumber
	) AS LineItemTotals
WHERE LineItemTotals.LineItemTotal > 100000;




-- Now create an indexed view using the same subquery
CREATE VIEW Sales.SalesOrderLineItemTotals_IndexedView
WITH SCHEMABINDING
AS
SELECT 
	SalesOrderNumber	= SalesOrderHeader.SalesOrderNumber, 
	LineItemTotal		= SUM(SalesOrderDetail.LineTotal), 
	LineCount			= COUNT_BIG(*)
FROM Sales.SalesOrderHeader
INNER JOIN Sales.SalesOrderDetail
	ON SalesOrderHeader.SalesOrderID = SalesOrderDetail.SalesOrderID
GROUP BY SalesOrderHeader.SalesOrderNumber;
GO
CREATE UNIQUE CLUSTERED INDEX CIX_SalesOrderLineItemTotals_SalesOrderNumber ON Sales.SalesOrderLineItemTotals_IndexedView (SalesOrderNumber);
GO


-- List all sales order numbers and line item totals with a line item total
-- over $100,000, using the indexed view
SELECT
	SalesOrderNumber,
	LineItemTotal
FROM Sales.SalesOrderLineItemTotals_IndexedView
WHERE LineItemTotal > 100000;

-- Compare the query plans:
-- List all sales order numbers and line item totals with a line item total
-- over $100,000, using a view
SELECT
	SalesOrderNumber,
	LineItemTotal
FROM Sales.SalesOrderLineItemTotals_NormalView
WHERE LineItemTotal > 100000;

-- List all sales order numbers and line item totals with a line item total
-- over $100,000, using a subquery
SELECT 
	LineItemTotals.SalesOrderNumber, 
	LineItemTotals.LineItemTotal
FROM
	(
		SELECT 
			SalesOrderNumber	= SalesOrderHeader.SalesOrderNumber, 
			LineItemTotal		= SUM(SalesOrderDetail.LineTotal)
		FROM Sales.SalesOrderHeader
		INNER JOIN Sales.SalesOrderDetail
			ON SalesOrderHeader.SalesOrderID = SalesOrderDetail.SalesOrderID
		GROUP BY SalesOrderHeader.SalesOrderNumber
	) AS LineItemTotals
WHERE LineItemTotals.LineItemTotal > 100000;
