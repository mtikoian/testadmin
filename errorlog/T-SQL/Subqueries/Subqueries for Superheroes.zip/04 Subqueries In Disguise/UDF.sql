-- List all sales order numbers and line item totals with a line item total
-- over $100,000, using a subquery
SELECT 
	LineItemTotals.SalesOrderNumber, 
	LineItemTotals.LineItemTotal
FROM
	(
		SELECT 
			SalesOrderNumber	= SalesOrderHeader.SalesOrderNumber, 
			LineItemTotal		= SUM(SalesOrderDetail.LineTotal)
		FROM Sales.SalesOrderHeader
		INNER JOIN Sales.SalesOrderDetail
			ON SalesOrderHeader.SalesOrderID = SalesOrderDetail.SalesOrderID
		GROUP BY SalesOrderHeader.SalesOrderNumber
	) AS LineItemTotals
WHERE LineItemTotals.LineItemTotal > 100000;

-- Create a user-defined function to calculate the line item 
-- total for a given sales order number
CREATE FUNCTION Sales.LineItemTotal(@SalesOrderNumber NVARCHAR(50))
RETURNS MONEY
AS
BEGIN

	RETURN (
		SELECT SUM(SalesOrderDetail.LineTotal)
		FROM Sales.SalesOrderHeader
		INNER JOIN Sales.SalesOrderDetail
			ON SalesOrderHeader.SalesOrderID = SalesOrderDetail.SalesOrderID
		WHERE SalesOrderHeader.SalesOrderNumber = @SalesOrderNumber
		)
END

-- List all sales order numbers and line item totals with a line item total
-- over $100,000, as calculated by a user-defined function
SELECT 
	SalesOrderNumber	= SalesOrderHeader.SalesOrderNumber, 
	LineItemTotal		= Sales.LineItemTotal(SalesOrderHeader.SalesOrderNumber)
FROM Sales.SalesOrderHeader
WHERE Sales.LineItemTotal(SalesOrderHeader.SalesOrderNumber) > 100000

-- Compare the query plans

-- List all sales order numbers and line item totals with a line item total
-- over $100,000, using a subquery
SELECT 
	LineItemTotals.SalesOrderNumber, 
	LineItemTotals.LineItemTotal
FROM
	(
		SELECT 
			SalesOrderNumber	= SalesOrderHeader.SalesOrderNumber, 
			LineItemTotal		= SUM(SalesOrderDetail.LineTotal)
		FROM Sales.SalesOrderHeader
		INNER JOIN Sales.SalesOrderDetail
			ON SalesOrderHeader.SalesOrderID = SalesOrderDetail.SalesOrderID
		GROUP BY SalesOrderHeader.SalesOrderNumber
	) AS LineItemTotals
WHERE LineItemTotals.LineItemTotal > 100000;

-- Whoa!?!?!? The query that uses the UDF is actually cheaper? What point is this guy trying to make?

-- Let's compare execution time and I/O stats

-- How can we see the true cost of the user-defined function?
