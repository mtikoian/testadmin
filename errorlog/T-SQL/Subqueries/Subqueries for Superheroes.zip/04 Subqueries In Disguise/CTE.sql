-- List all sales order numbers and line item totals with a line item total
-- over $100,000, using a subquery
SELECT 
	LineItemTotals.SalesOrderNumber, 
	LineItemTotals.LineItemTotal
FROM
	(
		SELECT 
			SalesOrderNumber	= SalesOrderHeader.SalesOrderNumber, 
			LineItemTotal		= SUM(SalesOrderDetail.LineTotal)
		FROM Sales.SalesOrderHeader
		INNER JOIN Sales.SalesOrderDetail
			ON SalesOrderHeader.SalesOrderID = SalesOrderDetail.SalesOrderID
		GROUP BY SalesOrderHeader.SalesOrderNumber
	) AS LineItemTotals
WHERE LineItemTotals.LineItemTotal > 100000;


-- List all sales order numbers and line item totals with a line item total
-- over $100,000, using a CTE
WITH LineItemTotals_CTE (SalesOrderNumber, LineItemTotal)
AS
	(
		SELECT 
			SalesOrderNumber	= SalesOrderHeader.SalesOrderNumber, 
			LineItemTotal		= SUM(SalesOrderDetail.LineTotal)
		FROM Sales.SalesOrderHeader
		INNER JOIN Sales.SalesOrderDetail
			ON SalesOrderHeader.SalesOrderID = SalesOrderDetail.SalesOrderID
		GROUP BY SalesOrderHeader.SalesOrderNumber
	)
SELECT 
	LineItemTotals_CTE.SalesOrderNumber, 
	LineItemTotals_CTE.LineItemTotal
FROM LineItemTotals_CTE
WHERE LineItemTotals_CTE.LineItemTotal > 100000;
