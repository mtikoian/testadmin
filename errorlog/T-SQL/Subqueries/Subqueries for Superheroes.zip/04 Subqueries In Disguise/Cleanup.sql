IF OBJECT_ID('Sales.SalesOrderLineItemTotals_NormalView', 'V') IS NOT NULL DROP VIEW Sales.SalesOrderLineItemTotals_NormalView;

IF OBJECT_ID('Sales.SalesOrderLineItemTotals_IndexedView', 'V') IS NOT NULL DROP VIEW Sales.SalesOrderLineItemTotals_IndexedView;

IF OBJECT_ID('Sales.LineItemTotal', 'FN') IS NOT NULL DROP FUNCTION Sales.LineItemTotal
