-- 13,500+ currency rates
SELECT * FROM Sales.CurrencyRate

-- 2,500 of those rate ID's are referenced by (i.e. "IN) sales orders
SELECT *
FROM Sales.CurrencyRate
WHERE CurrencyRateID IN (SELECT CurrencyRateID FROM Sales.SalesOrderHeader);

-- Simple math dictates that there should be ~11,000 NOT referenced by (i.e. NOT IN) sales orders
SELECT *
FROM Sales.CurrencyRate
WHERE CurrencyRateID NOT IN (SELECT CurrencyRateID FROM Sales.SalesOrderHeader);

-- A closer look at the sales order table
SELECT CurrencyRateID FROM Sales.SalesOrderHeader;

-- One possible alternative to NOT IN
SELECT *
FROM Sales.CurrencyRate
WHERE NOT EXISTS(SELECT * FROM Sales.SalesOrderHeader WHERE SalesOrderHeader.CurrencyRateID = CurrencyRate.CurrencyRateID);

-- NULL is not zero, and it's not blank. It's NULL.
SELECT COUNT(*) FROM Sales.SalesOrderHeader WHERE CurrencyRateID = '';
SELECT COUNT(*) FROM Sales.SalesOrderHeader WHERE CurrencyRateID = 0;
SELECT COUNT(*) FROM Sales.SalesOrderHeader WHERE CurrencyRateID IS NULL;

-- NULL values cannot be appended to or added to non-NULL values
SELECT NULL + 'Some value';
SELECT NULL + 1;
