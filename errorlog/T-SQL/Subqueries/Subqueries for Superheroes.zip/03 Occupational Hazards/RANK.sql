-- List products sold and order information for date of last
-- sale using SELECT/MIN subquery
SELECT
	Product.ProductNumber,
	Product.Name,
	SalesOrderHeader.SalesOrderID,
	SalesOrderHeader.OrderDate,
	SalesOrderHeader.ShipDate
FROM Production.Product
INNER JOIN Sales.SalesOrderDetail
	ON Product.ProductID = SalesOrderDetail.ProductID
INNER JOIN Sales.SalesOrderHeader
	ON SalesOrderDetail.SalesOrderID = SalesOrderHeader.SalesOrderID
INNER JOIN
	(
		SELECT
			ProductID,
			SalesOrderID = MIN(SalesOrderID)
		FROM Sales.SalesOrderDetail
		GROUP BY ProductID
	) AS FirstSalesOrderByProduct
	ON Product.ProductID = FirstSalesOrderByProduct.ProductID
		AND SalesOrderHeader.SalesOrderID = FirstSalesOrderByProduct.SalesOrderID
ORDER BY Product.ProductNumber, SalesOrderHeader.SalesOrderID;

-- This query could be considered inefficient because it hits the
-- SalesOrderDetail table twice. For very large tables, this can
-- be a significant problem.

-- How to avoid?

-- List products sold and order information for date of last
-- sale using RANK/OVER window function
SELECT
	Product.ProductNumber,
	Product.Name,
	SalesOrderHeader.SalesOrderID,
	SalesOrderHeader.OrderDate,
	SalesOrderHeader.ShipDate
FROM Production.Product
INNER JOIN 
	(
		SELECT
			ProductID,
			SalesOrderID,
			Ranking = RANK() OVER(PARTITION BY ProductID ORDER BY SalesOrderID)
		FROM Sales.SalesOrderDetail
	) AS RankedSales
	ON Product.ProductID = RankedSales.ProductID
INNER JOIN Sales.SalesOrderHeader
	ON SalesOrderHeader.SalesOrderID = RankedSales.SalesOrderID
WHERE RankedSales.Ranking = 1
ORDER BY Product.ProductNumber, SalesOrderHeader.SalesOrderID;

-- Another variation using RANK/OVER
SELECT
	RankedSales.ProductNumber,
	RankedSales.Name,
	RankedSales.SalesOrderID,
	RankedSales.OrderDate,
	RankedSales.ShipDate
FROM
	(
		SELECT
			Product.ProductNumber,
			Product.Name,
			SalesOrderHeader.SalesOrderID,
			SalesOrderHeader.OrderDate,
			SalesOrderHeader.ShipDate,
			Ranking = RANK() OVER(PARTITION BY SalesOrderDetail.ProductID ORDER BY SalesOrderDetail.SalesOrderID)
		FROM Production.Product
		INNER JOIN Sales.SalesOrderDetail
			ON Product.ProductID = SalesOrderDetail.ProductID
		INNER JOIN Sales.SalesOrderHeader
			ON SalesOrderHeader.SalesOrderID = SalesOrderDetail.SalesOrderID
	) AS RankedSales
WHERE RankedSales.Ranking = 1
ORDER BY RankedSales.ProductNumber, RankedSales.SalesOrderID;

-- Yet another variation, using a CTE (Common Table Expression), a fancy type of subquery
WITH RankedSales_CTE (ProductNumber, Name, SalesOrderID, OrderDate, ShipDate, Ranking)
AS
	(
		SELECT
			Product.ProductNumber,
			Product.Name,
			SalesOrderHeader.SalesOrderID,
			SalesOrderHeader.OrderDate,
			SalesOrderHeader.ShipDate,
			Ranking = RANK() OVER(PARTITION BY SalesOrderDetail.ProductID ORDER BY SalesOrderDetail.SalesOrderID)
		FROM Production.Product
		INNER JOIN Sales.SalesOrderDetail
			ON Product.ProductID = SalesOrderDetail.ProductID
		INNER JOIN Sales.SalesOrderHeader
			ON SalesOrderHeader.SalesOrderID = SalesOrderDetail.SalesOrderID
	)
SELECT
	RankedSales_CTE.ProductNumber,
	RankedSales_CTE.Name,
	RankedSales_CTE.SalesOrderID,
	RankedSales_CTE.OrderDate,
	RankedSales_CTE.ShipDate
FROM RankedSales_CTE
WHERE RankedSales_CTE.Ranking = 1
ORDER BY RankedSales_CTE.ProductNumber, RankedSales_CTE.SalesOrderID;

-- Of all of these, which variation is the LEAST expensive?
