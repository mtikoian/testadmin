-- List all "red" products and number of line items on which they appear
SELECT
	Product.ProductNumber,
	Product.Name,
	Product.Color,
	TotalUnitsSold = (SELECT COUNT(*) FROM Sales.SalesOrderDetail WHERE SalesOrderDetail.ProductID = Product.ProductID)
FROM Production.Product
WHERE Product.Color = 'Red';

-- List all "red" products sold and number of line items on which they appear
-- (discard products with line item count of zero)
SELECT
	Product.ProductNumber,
	Product.Name,
	Product.Color,
	TotalUnitsSold = (SELECT COUNT(*) FROM Sales.SalesOrderDetail WHERE SalesOrderDetail.ProductID = Product.ProductID)
FROM Production.Product
WHERE Product.Color = 'Red'
	AND (SELECT COUNT(*) FROM Sales.SalesOrderDetail WHERE SalesOrderDetail.ProductID = Product.ProductID) > 0;

-- List all "red" products sold (products with line item count greater than zero)
SELECT
	Product.ProductNumber,
	Product.Name,
	Product.Color
FROM Production.Product
WHERE Product.Color = 'Red'
	AND (SELECT COUNT(*) FROM Sales.SalesOrderDetail WHERE SalesOrderDetail.ProductID = Product.ProductID) > 0;

-- List all "red" products sold using EXISTS
SELECT
	Product.ProductNumber,
	Product.Name,
	Product.Color
FROM Production.Product
WHERE Product.Color = 'Red'
	AND EXISTS(SELECT 1 FROM Sales.SalesOrderDetail WHERE SalesOrderDetail.ProductID = Product.ProductID);

-- List all "red" products sold using GROUP BY (some versions of SQL will process COUNT vs EXISTS this way)
SELECT
	Product.ProductNumber,
	Product.Name,
	Product.Color
FROM Production.Product
INNER JOIN Sales.SalesOrderDetail
	ON Product.ProductID = SalesOrderDetail.ProductID
WHERE Product.Color = 'Red'
GROUP BY 
	Product.ProductNumber,
	Product.Name,
	Product.Color
HAVING COUNT(*) > 0;
