-- Return the sales order ID and order quantity for the largest
-- single order line item for "Sport-100 Helmet, Blue".
-- If no orders exists, return the same for "Sport-100 Helmet, Red" instead.

-- Get the product IDs
SELECT *
FROM Production.Product
WHERE Name IN ('Sport-100 Helmet, Blue', 'Sport-100 Helmet, Red');

-- Return the top single line item
SELECT TOP 1 SalesOrderID											-- We just want the top one
FROM Sales.SalesOrderDetail
WHERE ProductID = 711 OR ProductID = 707							-- Limit to the two product IDs
ORDER BY CASE WHEN ProductID = 711 THEN 1 ELSE 2 END;				-- Return the Blue helmet first, Red second

-- Is this the best way?
-- How might we use a subquery for this?

-- Return top single line item, using a subquery
SELECT TOP 1 SalesOrderID											-- We just want the top one
FROM Sales.SalesOrderDetail
WHERE ProductID IN
	(
		SELECT ProductID
		FROM Production.Product
		WHERE Name IN ('Sport-100 Helmet, Blue', 'Sport-100 Helmet, Red')
	)
ORDER BY CASE WHEN ProductID = 711 THEN 1 ELSE 2 END;				-- Return the "L" gloves first, "M" second

-- Is this the best way?
-- How does this compare to the original query in terms of expense?

-- How can we improve, yet still use a subquery?

SELECT TOP 1 SalesOrderID
FROM
	(
		SELECT SalesOrderID, RowSrc = 1
		FROM Sales.SalesOrderDetail
		WHERE ProductID = 711
		UNION ALL
		SELECT SalesOrderID, RowSrc = 2
		FROM Sales.SalesOrderDetail
		WHERE ProductID = 707
	) AS unioned
ORDER BY RowSrc;

-- How does this compare to the previous subquery?
-- Why are they different?


-- And, because somebody in the room will ask, here's what happens
-- if we join to Product and filter by product name
SELECT TOP 1 SalesOrderID
FROM
	(
		SELECT SalesOrderID, RowSrc = 1
		FROM Sales.SalesOrderDetail
		INNER JOIN Production.Product
			ON SalesOrderDetail.ProductID = Product.ProductID
		WHERE Product.Name = 'Sport-100 Helmet, Blue'
		UNION ALL
		SELECT SalesOrderID, RowSrc = 2
		FROM Sales.SalesOrderDetail
		INNER JOIN Production.Product
			ON SalesOrderDetail.ProductID = Product.ProductID
		WHERE Product.Name = 'Sport-100 Helmet, Red'
	) AS unioned
ORDER BY RowSrc;
