-- Return a list of all products sold during the month of August, 2008 that were black in color
SELECT
	Product.Name,
	Product.ProductNumber,
	Product.Color
FROM Production.Product
INNER JOIN Sales.SalesOrderDetail
	ON Product.ProductID = SalesOrderDetail.ProductID
INNER JOIN Sales.SalesOrderHeader
	ON SalesOrderDetail.SalesOrderID = SalesOrderHeader.SalesOrderID
WHERE SalesOrderHeader.ShipDate >= '2007-01-01'
	AND SalesOrderHeader.ShipDate < '2010-01-01'
	AND Product.Color = 'Black'
ORDER BY Product.Name;

-- Dupes? We don't need no stinkin' dupes!

-- Return a list of all products sold during the month of August, 2008 that were black in color
-- Without duplicates
SELECT DISTINCT
	Product.Name,
	Product.ProductNumber,
	Product.Color
FROM Production.Product
INNER JOIN Sales.SalesOrderDetail
	ON Product.ProductID = SalesOrderDetail.ProductID
INNER JOIN Sales.SalesOrderHeader
	ON SalesOrderDetail.SalesOrderID = SalesOrderHeader.SalesOrderID
WHERE SalesOrderHeader.ShipDate >= '2007-01-01'
	AND SalesOrderHeader.ShipDate < '2010-01-01'
	AND Product.Color = 'Black'
ORDER BY Product.Name;

-- Yay, no dupes! We're done here, right?
-- Wrong...  DISTINCT is a band-aid, there's a better way.

-- Avoiding DISTINCT with a non-correlated subquery
SELECT
	Product.Name,
	Product.ProductNumber,
	Product.Color
FROM Production.Product
WHERE Product.Color = 'Black'
	AND Product.ProductID IN
		(
			SELECT SalesOrderDetail.ProductID
			FROM Sales.SalesOrderDetail
			INNER JOIN Sales.SalesOrderHeader
				ON SalesOrderDetail.SalesOrderID = SalesOrderHeader.SalesOrderID
			WHERE SalesOrderHeader.ShipDate >= '2007-01-01'
				AND SalesOrderHeader.ShipDate < '2010-01-01'
		)
ORDER BY Product.Name;

-- Let's try another one!

-- Return list of salespersons who have sold red helmets
SELECT Person.LastName, Person.FirstName
FROM Production.Product
INNER JOIN Sales.SalesOrderDetail
	ON Product.ProductID = SalesOrderDetail.ProductID
INNER JOIN Sales.SalesOrderHeader
	ON SalesOrderDetail.SalesOrderID = SalesOrderHeader.SalesOrderID
INNER JOIN Person.Person
	ON SalesOrderHeader.SalesPersonID = Person.BusinessEntityID
WHERE Product.Name = 'Sport-100 Helmet, Red';

-- Ack! More dupes!
-- DISTINCT is the answer, right?

-- Return same list without duplicates
SELECT DISTINCT Person.LastName, Person.FirstName
FROM Production.Product
INNER JOIN Sales.SalesOrderDetail
	ON Product.ProductID = SalesOrderDetail.ProductID
INNER JOIN Sales.SalesOrderHeader
	ON SalesOrderDetail.SalesOrderID = SalesOrderHeader.SalesOrderID
INNER JOIN Person.Person
	ON SalesOrderHeader.SalesPersonID = Person.BusinessEntityID
WHERE Product.Name = 'Sport-100 Helmet, Red';

-- OK, no dupes this time, but that SQL nerd in the front of the room just
-- told me there's a better way. I should listen to him.

SELECT Person.LastName, Person.FirstName
FROM Person.Person
WHERE Person.BusinessEntityID IN
	(
		SELECT SalesOrderHeader.SalesPersonID
		FROM Sales.SalesOrderHeader
		INNER JOIN Sales.SalesOrderDetail
			ON SalesOrderHeader.SalesOrderID = SalesOrderDetail.SalesOrderID
		INNER JOIN Production.Product
			ON SalesOrderDetail.ProductID = Product.ProductID
		WHERE Product.Name = 'Sport-100 Helmet, Red'
	);


-- OK, OK, I get it, DISTINCT is a band-aid for lazy people who don't want
-- to write proper queries. So what, does it really matter?

-- YES!!!

-- Compare the estimated query plans for the three queries below. Which one is the most expensive?

-- Return list of salespersons who have sold red helmets
SELECT Person.LastName, Person.FirstName
FROM Production.Product
INNER JOIN Sales.SalesOrderDetail
	ON Product.ProductID = SalesOrderDetail.ProductID
INNER JOIN Sales.SalesOrderHeader
	ON SalesOrderDetail.SalesOrderID = SalesOrderHeader.SalesOrderID
INNER JOIN Person.Person
	ON SalesOrderHeader.SalesPersonID = Person.BusinessEntityID
WHERE Product.Name = 'Sport-100 Helmet, Red';

-- Return same list without duplicates.  Returning less data should require less work, right?
SELECT DISTINCT Person.LastName, Person.FirstName
FROM Production.Product
INNER JOIN Sales.SalesOrderDetail
	ON Product.ProductID = SalesOrderDetail.ProductID
INNER JOIN Sales.SalesOrderHeader
	ON SalesOrderDetail.SalesOrderID = SalesOrderHeader.SalesOrderID
INNER JOIN Person.Person
	ON SalesOrderHeader.SalesPersonID = Person.BusinessEntityID
WHERE Product.Name = 'Sport-100 Helmet, Red';

-- Another way to get the same data, with truly less work
SELECT Person.LastName, Person.FirstName
FROM Person.Person
WHERE Person.BusinessEntityID IN
	(
		SELECT SalesOrderHeader.SalesPersonID
		FROM Sales.SalesOrderHeader
		INNER JOIN Sales.SalesOrderDetail
			ON SalesOrderHeader.SalesOrderID = SalesOrderDetail.SalesOrderID
		INNER JOIN Production.Product
			ON SalesOrderDetail.ProductID = Product.ProductID
		WHERE Product.Name = 'Sport-100 Helmet, Red'
	);

-- Enable the following SET options and run the above three queries, examine
-- how the rows are being reduced.

SET STATISTICS IO ON
SET STATISTICS PROFILE ON
