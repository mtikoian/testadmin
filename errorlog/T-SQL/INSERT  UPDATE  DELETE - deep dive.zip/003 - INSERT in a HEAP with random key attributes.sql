/*============================================================================
	File:		003 - INSERT in a HEAP with random key attributes.sql

	Summary:	This script creates a relation dbo.tbl_massdata for the demonstration
				of INSERT-Internals for HEAPS

				THIS SCRIPT IS PART OF THE TRACK: "INSERT - UPDATE - DELETE internals"

	Date:		September 2013

	SQL Server Version: 2008 / 2012
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/

USE db_demo;
GO

IF OBJECT_ID('dbo.tbl_heap', 'U') IS NOT NULL
	DROP TABLE dbo.tbl_heap;
	GO

CREATE TABLE dbo.tbl_heap
(
	KeyId		uniqueidentifier	NOT NULL	DEFAULT (newid()),
	col1		char(200)			NOT NULL,
	col2		varchar(200)		NOT NULL,
	col3		datetime			NOT NULL	DEFAULT (getdate()),
	InsertPos	int					NOT NULL	Identity (1, 1)
);
GO

-- Clear the log for further investigation
CHECKPOINT;
GO

SET NOCOUNT ON;
GO

BEGIN TRANSACTION InsertRecord
DECLARE	@i int	=	1
WHILE @i <= 1000
BEGIN
	INSERT INTO dbo.tbl_heap(col1, col2)
	SELECT	'This is stuff ' + CAST(@i % 10 AS varchar(2)),
			'This is stuff ' + CAST(@i % 100 AS varchar(3)) + ', too';

	SET	@i += 1;
END
COMMIT TRANSACTION InsertRecord
GO

-- Output by order of insertion
SELECT sys.fn_PhysLocFormatter(%%physloc%%) AS Location, * FROM dbo.tbl_heap ORDER BY InsertPos;

-- does the random insertion of valued have any impact to fragmentation
SELECT	OBJECT_NAME(i.object_id)		AS	object_name,
		i.name							AS	index_name,
		i.type_desc						AS	index_type,
		ps.index_depth,
		ps.avg_fragmentation_in_percent,
		ps.avg_fragment_size_in_pages,
		ps.fragment_count,
		ps.page_count,
		ps.record_count
FROM	sys.indexes i INNER JOIN sys.dm_db_index_physical_stats(db_id(), OBJECT_ID('dbo.tbl_heap', 'U'), DEFAULT, DEFAULT, 'DETAILED') ps
		ON	(
				i.object_id = ps.object_id AND
				i.index_id = ps.index_id
			);

-- Select all allocated pages and records
SELECT	DISTINCT
		CAST	(
				LEFT	(
							SUBSTRING(sys.fn_PhysLocFormatter(%%physloc%%), CHARINDEX(':', sys.fn_PhysLocFormatter(%%physloc%%)) + 1, 20),
							CHARINDEX(':', SUBSTRING(sys.fn_PhysLocFormatter(%%physloc%%), CHARINDEX(':', sys.fn_PhysLocFormatter(%%physloc%%)) + 1, 20)) - 1
						) AS int
				) AS Location,
		COUNT_BIG(*)
FROM	dbo.tbl_heap
GROUP BY
		CAST	(
				LEFT	(
							SUBSTRING(sys.fn_PhysLocFormatter(%%physloc%%), CHARINDEX(':', sys.fn_PhysLocFormatter(%%physloc%%)) + 1, 20),
							CHARINDEX(':', SUBSTRING(sys.fn_PhysLocFormatter(%%physloc%%), CHARINDEX(':', sys.fn_PhysLocFormatter(%%physloc%%)) + 1, 20)) - 1
						) AS int
				)
ORDER BY
		CAST	(
				LEFT	(
							SUBSTRING(sys.fn_PhysLocFormatter(%%physloc%%), CHARINDEX(':', sys.fn_PhysLocFormatter(%%physloc%%)) + 1, 20),
							CHARINDEX(':', SUBSTRING(sys.fn_PhysLocFormatter(%%physloc%%), CHARINDEX(':', sys.fn_PhysLocFormatter(%%physloc%%)) + 1, 20)) - 1
						) AS int
				);

-- Let's see the transaction log
-- for INSERTED records only!
SELECT	[Current LSN],
		Operation,
		Context,
		AllocUnitId,
		AllocUnitName,
		[Page ID],
		[Slot ID],
		[Lock Information],
		[RowLog Contents 0]
FROM	sys.fn_dblog(NULL, NULL) 
WHERE	[Transaction ID] IN
		(
			SELECT [Transaction ID] FROM sys.fn_dblog(NULL, NULL) WHERE [Transaction Name] = 'InsertRecord'
		);

-- but what has happend overall?
SELECT	[Current LSN],
		Operation,
		Context,
		AllocUnitId,
		AllocUnitName,
		[Page ID],
		[Slot ID],
		[Lock Information],
		[RowLog Contents 0]
FROM	sys.fn_dblog(NULL, NULL);

-- see the amount of space each operation and context consumes!
SELECT	Context,
		Operation,
		COUNT_BIG(*)				AS	Num_Actions,
		SUM([Log Record Length])	AS	Num_Bytes,
		(SUM([Log Record Length]) * 1.0) / COUNT_BIG(*)	AS	Avg_Bytes
FROM	sys.fn_dblog(NULL, NULL)
GROUP BY
		Context,
		Operation
ORDER BY
		Context,
		Operation;
GO

-- see the total amount of space consumes!
SELECT	Context,
		Operation,
		COUNT_BIG(*)				AS	Num_Actions,
		SUM([Log Record Length])	AS	Num_Bytes,
		(SUM([Log Record Length]) * 1.0) / COUNT_BIG(*)	AS	Avg_Bytes
FROM	sys.fn_dblog(NULL, NULL)
GROUP BY
		Context,
		Operation
ORDER BY
		Context,
		Operation;
GO