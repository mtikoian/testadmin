/*============================================================================
	File:		0013 - UPDATE in a HEAP.sql

	Summary:	This script creates a relation dbo.demo_table for the demonstration
				of UPDATE-Internals for HEAPS

				THIS SCRIPT IS PART OF THE TRACK: "INSERT - UPDATE - DELETE internals"

	Date:		September 2013

	SQL Server Version: 2008 / 2012
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
USE demo_db;
GO

SET LANGUAGE us_english;
SET NOCOUNT ON;
GO


/*
	Demo 1:	Simple insert of data into a brand new HEAP
*/
IF OBJECT_ID('dbo.demo_table', 'U') IS NOT NULL
	DROP TABLE dbo.demo_table;
	GO

CREATE TABLE dbo.demo_table
(
	Id		int				NOT NULL,
	col1	char(200)		NOT NULL	DEFAULT ('some stuff'),
	col2	varchar(200)	NOT NULL	DEFAULT ('some more stuff'),
	col3	datetime		NOT NULL	DEFAULT (getdate()),
	OrdPos	int				NOT NULL	IDENTITY (1, 1)
);
GO

-- Insert 50 records
DECLARE	@i int = 1;
WHILE @i <= 50
BEGIN
	INSERT INTO dbo.demo_table (Id, col1, col2, col3) VALUES (@i, DEFAULT, DEFAULT, DEFAULT);
	SET @i += 1;
END
GO

CHECKPOINT;
GO

-- get the physical and logical location of the data
SELECT sys.fn_PhysLocFormatter(%%physloc%%) AS Location, * FROM dbo.demo_table
GO

/*
	Update a fixed width column and check the transaction log.
	Only the data length of the widest text is affected!

	If the update text is longer than the original text the
	amount of transaction log is definied by the length of the
	new text.

	Otherwise it is determined by the length of the original text
*/
BEGIN TRANSACTION UpdateRecord
GO
	UPDATE	dbo.demo_table
	SET		col1 = 'This is a brand new text for me!'
	WHERE	Id = 3;
	GO

	-- what resources are blocked?
	SELECT	resource_type,
			resource_description,
			resource_associated_entity_id,
			u.type,
			u.type_desc,
			OBJECT_NAME(ISNULL(p.object_id, l.resource_associated_entity_id))	AS	object_name,
			request_mode,
			request_type
	FROM	sys.dm_tran_locks l LEFT JOIN sys.allocation_units u
			ON	(l.resource_associated_entity_id = u.container_id) LEFT JOIN sys.partitions p
			ON	(
					u.container_id = 
						CASE WHEN u.type IN (1, 3)
							THEN p.hobt_id
							ELSE p.partition_id
						END
				)
	WHERE	resource_database_id = db_id() AND
			request_session_id = @@SPID;
	GO

	-- see the amount of operations which took place!
	SELECT	database_transaction_log_bytes_used,
			database_transaction_log_record_count
	FROM	sys.dm_tran_database_transactions
	WHERE	database_id = db_id();
	GO

COMMIT TRANSACTION UpdateRecord
GO

-- What happend inside the named transaction?
SELECT	[Current LSN],
		Operation,
		Context,
		[Log Record Length],
		AllocUnitId,
		AllocUnitName,
		[RowLog Contents 0]		AS	OldData,
		[RowLog Contents 1]		AS	NewData
FROM	sys.fn_dblog(NULL, NULL)
WHERE	Context != 'LCX_NULL' AND
		LEFT([Current LSN], LEN([Current LSN]) - 5) IN
		(
			SELECT	LEFT([Current LSN], LEN([Current LSN]) - 5)
			FROM	sys.fn_dblog(NULL, NULL)
			WHERE	[Transaction Name] = 'UpdateRecord'
		)
ORDER BY
		[Current LSN];
GO

-- although we have a char(200) only the exact length of the replaced stuff
-- will be logged!
SELECT	CAST (0x736F6D652073747566662020202020202020202020202020 AS varchar(200)),
		CAST (0x546869732069732061206272616E64206E65772074657874 AS varchar(200))

CHECKPOINT;
GO

-- Update column with the same data
BEGIN TRANSACTION UpdateRecord
GO
	UPDATE	dbo.demo_table
	SET		col1 = 'This is a brand new text for me!'
	WHERE	Id = 3;
	GO

	-- what resources are blocked?
	SELECT	resource_type,
			resource_description,
			resource_associated_entity_id,
			u.type,
			u.type_desc,
			OBJECT_NAME(ISNULL(p.object_id, l.resource_associated_entity_id))	AS	object_name,
			request_mode,
			request_type
	FROM	sys.dm_tran_locks l LEFT JOIN sys.allocation_units u
			ON	(l.resource_associated_entity_id = u.container_id) LEFT JOIN sys.partitions p
			ON	(
					u.container_id = 
						CASE WHEN u.type IN (1, 3)
							THEN p.hobt_id
							ELSE p.partition_id
						END
				)
	WHERE	resource_database_id = db_id() AND
			request_session_id = @@SPID;
	GO

	-- see the amount of operations which took place!
	SELECT	database_transaction_log_bytes_used,
			database_transaction_log_record_count
	FROM	sys.dm_tran_database_transactions
	WHERE	database_id = db_id();
	GO

COMMIT TRANSACTION UpdateRecord
GO

-- What happend inside the named transaction?
SELECT	[Current LSN],
		Operation,
		Context,
		[Log Record Length],
		AllocUnitId,
		AllocUnitName,
		[RowLog Contents 0]		AS	OldData,
		[RowLog Contents 1]		AS	NewData
FROM	sys.fn_dblog(NULL, NULL)
WHERE	Context != 'LCX_NULL' AND
		LEFT([Current LSN], LEN([Current LSN]) - 5) =
		(
			SELECT	LEFT([Current LSN], LEN([Current LSN]) - 5)
			FROM	sys.fn_dblog(NULL, NULL)
			WHERE	[Transaction Name] = 'UpdateRecord')
ORDER BY
		[Current LSN];
GO

CHECKPOINT;
GO

-- Update a record and check the amount of produced transaction log
BEGIN TRANSACTION UpdateRecord
GO

	UPDATE	dbo.demo_table
	SET		col1 = 'This'
	WHERE	Id = 1;

	UPDATE	dbo.demo_table
	SET		col1 = 'This is'
	WHERE	Id = 1;

	UPDATE	dbo.demo_table
	SET		col1 = 'This is a brand new text for me!'
	WHERE	Id = 1

	-- what resources are blocked?
	SELECT	resource_type,
			resource_description,
			resource_associated_entity_id,
			u.type,
			u.type_desc,
			OBJECT_NAME(ISNULL(p.object_id, l.resource_associated_entity_id))	AS	object_name,
			request_mode,
			request_type
	FROM	sys.dm_tran_locks l LEFT JOIN sys.allocation_units u
			ON	(l.resource_associated_entity_id = u.container_id) LEFT JOIN sys.partitions p
			ON	(
					u.container_id = 
						CASE WHEN u.type IN (1, 3)
							THEN p.hobt_id
							ELSE p.partition_id
						END
				)
	WHERE	resource_database_id = db_id() AND
			request_session_id = @@SPID;
	GO

	-- see the amount of operations which took place!
	SELECT	database_transaction_log_bytes_used,
			database_transaction_log_record_count
	FROM	sys.dm_tran_database_transactions
	WHERE	database_id = db_id();
	GO

COMMIT TRANSACTION UpdateRecord
GO

-- What happend inside the named transaction?
SELECT	[Current LSN],
		Operation,
		Context,
		[Log Record Length],
		AllocUnitId,
		AllocUnitName,
		[RowLog Contents 0]		AS	OldData,
		[RowLog Contents 1]		AS	NewData
FROM	sys.fn_dblog(NULL, NULL)
WHERE	Context != 'LCX_NULL' AND
		LEFT([Current LSN], LEN([Current LSN]) - 5) IN
		(
			SELECT	LEFT([Current LSN], LEN([Current LSN]) - 5)
			FROM	sys.fn_dblog(NULL, NULL)
			WHERE	[Transaction Name] = 'UpdateRecord')
ORDER BY
		[Current LSN];
GO

CHECKPOINT;
GO

-- clean the kitchen
IF OBJECT_ID('dbo.demo_table', 'U') IS NOT NULL
	DROP TABLE dbo.demo_table;
	GO


/*
	-- STOP HERE IF RUNNING OUT OF TIME!

	-- what happens if a variable column will be updated?
	-- Get the original record from the page BEFORE it will be updated

	-- get the physical and logical location of the data
	SELECT sys.fn_PhysLocFormatter(%%physloc%%) AS Location, * FROM dbo.demo_table WHERE Id = 1;
	GO

	DBCC TRACEON (3604);
	DBCC PAGE ('demo_db', 1, 177, 1);
	GO

	/*
		3000dc00 01000000 54686973 20612062 72616e64
		206e6577 20746578 7420666f 72206d65 21202020
		20202020 20202020 20202020 20202020 20202020
		20202020 20202020 20202020 20202020 20202020
		20202020 20202020 20202020 20202020 20202020
		20202020 20202020 20202020 20202020 20202020
		20202020 20202020 20202020 20202020 20202020
		20202020 20202020 20202020 20202020 20202020
		20202020 20202020 20202020 20202020 20202020
		20202020 20202020 20202020 20202020 20202020
		20202020 20202020 188f3b01 6aa20000 01000000
		05000001 00
		f200	<== Offset for end of values for col2
		-- data of col2
		73 6f6d6520 6d6f7265 20737475 6666
	*/
	SELECT	CAST(0xF2 AS int),
			CAST(0x736f6d65206d6f7265207374756666 AS varchar(200))	AS	Content_Col2

	-- Clear the log before the next operation
	CHECKPOINT;
	GO

	-- Update a variable length column
	BEGIN TRANSACTION UpdateRecord
	GO
		UPDATE	dbo.demo_table
		SET		col2 = 'This is a replacement for the old text'
		WHERE	Id = 1;
		GO

		-- what resources are blocked?
		SELECT	resource_type,
				resource_description,
				resource_associated_entity_id,
				u.type,
				u.type_desc,
				OBJECT_NAME(ISNULL(p.object_id, l.resource_associated_entity_id))	AS	object_name,
				request_mode,
				request_type
		FROM	sys.dm_tran_locks l LEFT JOIN sys.allocation_units u
				ON	(l.resource_associated_entity_id = u.container_id) LEFT JOIN sys.partitions p
				ON	(
						u.container_id = 
							CASE WHEN u.type IN (1, 3)
								THEN p.hobt_id
								ELSE p.partition_id
							END
					)
		WHERE	resource_database_id = db_id() AND
				request_session_id = @@SPID;
		GO

		-- see the amount of operations which took place!
		SELECT	database_transaction_log_bytes_used,
				database_transaction_log_record_count
		FROM	sys.dm_tran_database_transactions
		WHERE	database_id = db_id();
		GO

	COMMIT TRANSACTION UpdateRecord
	GO

	DBCC TRACEON (3604);
	DBCC PAGE ('demo_db', 1, 168, 1);
	GO

	/*
	0:		3000dc00 01000000 736f6d65 20737475 66662020
	21:		<snip>
	201:	20202020 20202020 15cd9700 6aa20000 01000000
	221:	05000001 00 -->0901 54 68697320 69732061 20726570
	241:	6c616365 6d656e74 20666f72 20746865 206f6c64
	261:	20746578 74
	*/

	SELECT	CAST(0x109 AS int),
			CAST(0x546869732069732061207265706c6163656d656e7420666f7220746865206f6c642074657874 AS varchar(200))

	/*
		DEMO: Update of a record in portions vs once
	*/
	-- PREPARE THE RECORD FOR DEMO!
	UPDATE	dbo.demo_table
	SET		col1 = 'This is a small test',		-- char(200)
			col2 = 'This is a small test'		-- varchar(200)
	WHERE	Id = 10;

	CHECKPOINT;
	GO

	-- now measure the amount of log bytes for each update
	BEGIN TRANSACTION UpdateRecord
	GO
		UPDATE	dbo.demo_table SET col1 = REPLICATE('A', 100) WHERE Id = 10;
		UPDATE	dbo.demo_table SET col2 = REPLICATE('A', 100) WHERE Id = 10;

		-- see the amount of operations which took place!
		SELECT	database_transaction_log_bytes_used,
				database_transaction_log_record_count
		FROM	sys.dm_tran_database_transactions
		WHERE	database_id = db_id();
		GO
	COMMIT TRANSACTION UpdateRecord
	GO

	-- What happend inside the named transaction?
	SELECT	[Current LSN],
			Operation,
			Context,
			[Log Record Length],
			AllocUnitId,
			AllocUnitName,
			[RowLog Contents 0]		AS	OldData,
			[RowLog Contents 1]		AS	NewData
	FROM	sys.fn_dblog(NULL, NULL)
	WHERE	LEFT([Current LSN], LEN([Current LSN]) - 5) =
			(
				SELECT	LEFT([Current LSN], LEN([Current LSN]) - 5)
				FROM	sys.fn_dblog(NULL, NULL)
				WHERE	[Transaction Name] = 'UpdateRecord')
	ORDER BY
			[Current LSN];
	GO


	-- PREPARE THE RECORD FOR DEMO!
	UPDATE	dbo.demo_table
	SET		col1 = 'This is a small test',		-- char(200)
			col2 = 'This is a small test'		-- varchar(200)
	WHERE	Id = 10;

	CHECKPOINT;
	GO

	-- now measure the amount of log bytes for each update
	BEGIN TRANSACTION UpdateRecord
	GO
		UPDATE	dbo.demo_table
		SET		col1 = REPLICATE('A', 100),
				col2 = REPLICATE('A', 100)
		WHERE	Id = 10;

		-- see the amount of operations which took place!
		SELECT	database_transaction_log_bytes_used,
				database_transaction_log_record_count
		FROM	sys.dm_tran_database_transactions
		WHERE	database_id = db_id();
		GO
	COMMIT TRANSACTION UpdateRecord
	GO

	-- What happend inside the named transaction?
	SELECT	[Current LSN],
			Operation,
			Context,
			[Log Record Length],
			AllocUnitId,
			AllocUnitName,
			[RowLog Contents 0]		AS	OldData,
			[RowLog Contents 1]		AS	NewData
	FROM	sys.fn_dblog(NULL, NULL)
	WHERE	LEFT([Current LSN], LEN([Current LSN]) - 5) =
			(
				SELECT	LEFT([Current LSN], LEN([Current LSN]) - 5)
				FROM	sys.fn_dblog(NULL, NULL)
				WHERE	[Transaction Name] = 'UpdateRecord')
	ORDER BY
			[Current LSN];
	GO
*/

CHECKPOINT;
GO