/*============================================================================
	File:		0016 - DELETE in a CLUSTERED.sql

	Summary:	This script creates a relation dbo.demo_table for the demonstration
				of DELETE-Internals for heaps

				THIS SCRIPT IS PART OF THE TRACK: "INSERT - UPDATE - DELETE internals"

	Date:		September 2013

	SQL Server Version: 2008 / 2012
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
USE demo_db;
GO

SET LANGUAGE us_english;
SET NOCOUNT ON;
GO

IF OBJECT_ID('dbo.demo_table', 'U') IS NOT NULL
	DROP TABLE dbo.demo_table;
	GO

CREATE TABLE dbo.demo_table
(
	Id		int				NOT NULL,
	col1	char(1000)		NOT NULL	DEFAULT ('some stuff'),
	col2	varchar(200)	NOT NULL	DEFAULT ('some more stuff'),
	col3	datetime		NOT NULL	DEFAULT (getdate()),
	OrdPos	int				NOT NULL	IDENTITY (1, 1)
);
GO

CREATE UNIQUE CLUSTERED INDEX cix_tbl_cluster_Id ON dbo.demo_table (Id);
GO

-- Insert 100 records
SET NOCOUNT ON
GO

DECLARE	@i int = 1;
WHILE @i <= 100
BEGIN
	INSERT INTO dbo.demo_table (Id, col1, col2, col3) VALUES (@i, DEFAULT, DEFAULT, DEFAULT);
	SET @i += 1;
END

-- get the physical and logical location of the data
SELECT sys.fn_PhysLocFormatter(%%physloc%%) AS Location, * FROM dbo.demo_table;
GO

CHECKPOINT;
GO

-- Delete one record from the clustered index and look to the transaction log
-- START THE SCRIPT 0100 - Track ghost cleanup background task.sql
BEGIN TRANSACTION DeleteRecord
GO
	DELETE	dbo.demo_table WHERE Id = 5;
	GO

	-- what resources are blocked?
	SELECT	resource_type,
			resource_description,
			resource_associated_entity_id,
			u.type,
			u.type_desc,
			OBJECT_NAME(ISNULL(p.object_id, l.resource_associated_entity_id))	AS	object_name,
			request_mode,
			request_type
	FROM	sys.dm_tran_locks l LEFT JOIN sys.allocation_units u
			ON	(l.resource_associated_entity_id = u.container_id) LEFT JOIN sys.partitions p
			ON	(
					u.container_id = 
						CASE WHEN u.type IN (1, 3)
							THEN p.hobt_id
							ELSE p.partition_id
						END
				)
	WHERE	resource_database_id = db_id() AND
			request_session_id = @@SPID;
	GO

COMMIT TRANSACTION DeleteRecord
GO

-- check the data page for "GHOSTED_RECORD(S)
DBCC TRACEON (3604);
DBCC PAGE ('demo_db', 1, 410, 1);
GO

-- Delete records of one page in the clustered and look to the transaction log
BEGIN TRANSACTION DeleteRecord
	DELETE	dbo.demo_table WHERE Id <= 7;

	SELECT * FROM sys.dm_tran_locks
	WHERE	resource_database_id = db_id();

	-- see the amount of operations which took place!
	SELECT	database_transaction_log_bytes_used,
			database_transaction_log_record_count
	FROM	sys.dm_tran_database_transactions
	WHERE	database_id = db_id();

COMMIT TRANSACTION DeleteRecord
GO

-- what has happend overall?
SELECT	Operation,
		Context,
		AllocUnitId,
		AllocUnitName,
		[Page ID],
		[Slot ID],
		[Lock Information],
		[Offset in Row],
		[RowLog Contents 0],
		[RowLog Contents 1],
		[Log Record Length]
FROM	sys.fn_dblog(NULL, NULL)
WHERE	Context != 'LCX_NULL' AND
		[Transaction ID] IN
		(
			SELECT	[Transaction ID]
			FROM	sys.fn_dblog(NULL, NULL)
			WHERE	[Transaction Name] = 'DeleteRecord'
		)
ORDER BY
		[Current LSN];
GO

CHECKPOINT;
GO

-- See the physical structure of the clustered index BEFORE the deletion of all data
SELECT	page_type,
		page_type_desc,
		allocated_page_page_id
FROM	sys.dm_db_database_page_allocations(db_id(), OBJECT_ID('dbo.demo_table', 'U'), NULL, NULL, 'DETAILED');
GO


-- Delete complete heap
BEGIN TRANSACTION DeleteRecord
	DELETE	dbo.demo_table;

	SELECT * FROM sys.dm_tran_locks
	WHERE	resource_database_id = db_id() AND
			request_session_id = @@SPID;

	-- see the amount of operations which took place!
	SELECT	database_transaction_log_bytes_used,
			database_transaction_log_record_count
	FROM	sys.dm_tran_database_transactions
	WHERE	database_id = db_id();
COMMIT TRANSACTION DeleteRecord
GO

-- what has happend overall?
SELECT	Operation,
		Context,
		AllocUnitId,
		AllocUnitName,
		[Page ID],
		[Slot ID],
		[Lock Information],
		[Offset in Row],
		[RowLog Contents 0],
		[RowLog Contents 1],
		[Log Record Length]
FROM	sys.fn_dblog(NULL, NULL)
WHERE	[Transaction ID] IN (SELECT [Transaction ID] FROM sys.fn_dblog(NULL, NULL) WHERE [Transaction Name] = 'DeleteRecord')
ORDER BY
		[Current LSN];
GO

-- See the physical structure of the heap
SELECT	page_type,
		page_type_desc,
		allocated_page_page_id
FROM	sys.dm_db_database_page_allocations(db_id(), OBJECT_ID('dbo.demo_table', 'U'), NULL, NULL, 'DETAILED');
GO

CHECKPOINT;
GO

-- Clean the kitchen
IF OBJECT_ID('dbo.demo_table', 'U') IS NOT NULL
	DROP TABLE dbo.demo_table;
	GO
