/*============================================================================
	File:		0003 - anatomy of a clustered index.sql

	Summary:	This script demonstrates the internal structure of a clustered index

				THIS SCRIPT IS PART OF THE TRACK: "INSERT - UPDATE - DELETE internals"

	Date:		September 2013

	SQL Server Version: 2008 / 2012
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH (Germany)

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
USE demo_db;
GO

SET LANGUAGE us_english;
SET NOCOUNT ON;
GO

-- Create a simple clustered index and fill it with data
IF OBJECT_ID('dbo.tbl_cluster', 'U') IS NOT NULL
	DROP TABLE dbo.tbl_cluster;
	GO

CREATE TABLE dbo.tbl_cluster
(
	Id	int			NOT NULL	IDENTITY (1, 1),
	c1	char(200)	NOT NULL	DEFAULT ('just stuff'),
	c2	char(200)	NOT NULl	DEFAULT ('the new fragrance'),
	c3	datetime	NOT NULL	DEFAULT (getdate())
);
GO

-- make the HEAP a clustered index!
CREATE UNIQUE CLUSTERED INDEX cix_tbl_cluster_id ON dbo.tbl_Cluster (Id);
GO

-- Now insert 1000 records and look to the internal structure
INSERT INTO dbo.tbl_cluster DEFAULT VALUES
GO 1000

-- Any fragmentation on the heap?
SELECT	page_count,
		record_count,
		fragment_count,
		avg_fragment_size_in_pages
FROM	sys.dm_db_index_physical_stats(db_id(), OBJECT_ID('dbo.tbl_cluster', 'U'), NULL, NULL, 'DETAILED');
GO

-- physical data structure of the clustered index
SELECT	page_type,
		page_type_desc,
		allocated_page_iam_page_id,
		allocated_page_file_id,
		allocated_page_page_id,
		previous_page_page_id,
		next_page_page_id
FROM	sys.dm_db_database_page_allocations(db_id(), OBJECT_ID('dbo.tbl_cluster', 'U'), NULL, NULL, 'DETAILED')
WHERE	is_allocated = 1
ORDER BY
		page_type DESC,
		previous_page_page_id ASC,
		allocated_page_page_id ASC;
GO

-- See the data in it's physical locatoin
SELECT	sys.fn_PhysLocFormatter(%%physloc%%)	AS	physical_location,
		*
FROM	dbo.tbl_cluster;
GO

-- Get deeper and have a look to the B-Tree and a data page
-- change the page numbers before execution by referring to the output
-- of the clustered index structure!
DBCC TRACEON (3604);
DBCC PAGE ('demo_db', 1, 165, 3);
GO

-- what's inside a b-tree page
DBCC PAGE ('demo_db', 1, 166, 3);	-- B-TREE (Intermediate)
GO

-- Clean the workbench
IF OBJECT_ID('dbo.tbl_cluster', 'U') IS NOT NULL
	DROP TABLE dbo.tbl_cluster;
	GO
