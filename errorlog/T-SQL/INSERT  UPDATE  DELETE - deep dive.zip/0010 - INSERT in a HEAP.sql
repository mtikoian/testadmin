/*============================================================================
	File:		0010 - INSERT in a HEAP.sql

	Summary:	This script creates a relation dbo.demo_table for the demonstration
				of INSERT-Internals for HEAPS

				THIS SCRIPT IS PART OF THE TRACK: "INSERT - UPDATE - DELETE internals"

	Date:		September 2013

	SQL Server Version: 2008 / 2012
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
USE demo_db;
GO

SET LANGUAGE us_english;
SET NOCOUNT ON;
GO

/*
	Demo 1:	Simple insert of data into a brand new table (HEAP / CLUSTER)
			Keep in mind that allocation of meta data information will not
			take place BEFORE any record will be inserted into the table!

*/

IF OBJECT_ID('dbo.demo_table', 'U') IS NOT NULL
	DROP TABLE dbo.demo_table;
	GO

CREATE TABLE dbo.demo_table
(
	Id			INT				NOT NULL,
	col1		CHAR(200)		NOT NULL	DEFAULT ('some stuff'),
	col2		VARCHAR(200)	NOT NULL	DEFAULT ('some more stuff'),
	col3		DATETIME		NOT NULL	DEFAULT (getdate()),
	InsertPos	INT				NOT NULl	IDENTITY (1, 1)
);
GO

-- When a table will be created NO pages have been allocated!
SELECT	index_id,
		page_type,
		page_type_desc,
		allocated_page_page_id
FROM	sys.dm_db_database_page_allocations
		(
			DB_ID(),
			OBJECT_ID('dbo.demo_table', 'U'),
			NULL,
			NULL,
			'DETAILED'
		)
ORDER BY
		Index_id;
GO

-- Flush the log and write the dirty pages to disc
CHECKPOINT;
GO

-- Insert ONE row into the HEAP and see the transactions
BEGIN TRANSACTION InsertRecord
GO
	INSERT INTO dbo.demo_table (Id, col1, col2, col3)
	VALUES (1, 'Uwe', 'Ricken', '19640218');
	GO

	/*
		what resources are blocked?
		overview of system objects:
		http://msdn.microsoft.com/en-us/library/ms179503.aspx
	*/

	SELECT	resource_type,
			resource_description,
			resource_associated_entity_id,
			u.type,
			u.type_desc,
			OBJECT_NAME(ISNULL(p.object_id, l.resource_associated_entity_id))	AS	object_name,
			request_mode,
			request_type
	FROM	sys.dm_tran_locks l LEFT JOIN sys.allocation_units u
			ON	(l.resource_associated_entity_id = u.container_id) LEFT JOIN sys.partitions p
			ON	(
					u.container_id = 
						CASE WHEN u.type IN (1, 3)
							THEN p.hobt_id
							ELSE p.partition_id
						END
				)
	WHERE	resource_database_id = db_id() AND
			request_session_id = @@SPID;
	GO

COMMIT TRANSACTION InsertRecord
GO

-- Where has the record been stored?
SELECT	p.*, h.*
FROM	dbo.demo_table h CROSS APPLY sys.fn_PhysLocCracker(%%physloc%%) p;
GO

-- What happend inside the named transaction?
-- keep in mind that with the first record the
-- data structure will be created too!
SELECT	[Current LSN],
		Operation,
		Context,
		[Log Record Length],
		AllocUnitId,
		AllocUnitName,
		[Page ID],
		[Slot ID],
		[Lock Information]
FROM	sys.fn_dblog(NULL, NULL)
WHERE	Context != 'LCX_NULL' AND
		LEFT([Current LSN], LEN([Current LSN]) - 5) IN
		(
			SELECT	LEFT([Current LSN], LEN([Current LSN]) - 5)
			FROM	sys.fn_dblog(NULL, NULL)
			WHERE	[Transaction Name] = 'InsertRecord')
ORDER BY
		[Current LSN];
GO


-- See the physical structure of the heap
SELECT	index_id,
		page_type,
		page_type_desc,
		allocated_page_page_id
FROM	sys.dm_db_database_page_allocations(db_id(), OBJECT_ID('dbo.demo_table', 'U'), NULL, NULL, 'DETAILED')
ORDER BY
		Index_id;
GO

-- Get details concerning the space allocation inside the PFS
DBCC TRACEON (3604);
DBCC PAGE ('demo_db', 1, 1, 3);
GO

-- Get details concerning the IAM
DBCC PAGE ('demo_db', 1, 121, 3);
GO

-- ... and the data page itself
-- check the space what is really needed in the page
-- and compare it to the filling in PFS!
DBCC PAGE ('demo_db', 1, 120, 1);
GO


/*
	===================================================================================
	Demo 2:	Storage by using PFS for checking free space!
	===================================================================================
*/

-- Demo 2: Recreate the HEAP and fill it again with a few data
IF OBJECT_ID('dbo.demo_table', 'U') IS NOT NULL
	DROP TABLE dbo.demo_table;
	GO

CREATE TABLE dbo.demo_table
(
	Id	int			NOT NULL	IDENTITY (1, 1),
	c1	char(2500)	NOT NULL
);

CHECKPOINT;
GO

-- Calculation for the amount of data for one page:
/*
	Pagesize:	8192 Bytes
	Header:		  96 Bytes
	SlotArray:	  36 Bytes
	Data:		8060 Bytes

	1 Record has a size of 2510 Bytes (4 + 2500 + 4 (RowHeader) + 2 (Slot Array))
	8096 Bytes / 2510 Bytes = 3 records + 1556 Bytes!
*/ 

-- Let's insert 3 rows!
INSERT INTO dbo.demo_table (c1)
VALUES
('Uwe Ricken'),
('Beate Ricken'),
('Alicia Ricken');
GO

-- What pages will be allocated by the table
SELECT	p.*, h.*
FROM	dbo.demo_table AS h
		CROSS APPLY sys.fn_PhysLocCracker(%%physloc%%) AS p;
GO

-- flush the changes to disk
CHECKPOINT;
GO

INSERT INTO dbo.demo_table (c1)
VALUES
('Katharina Ricken')
GO

INSERT INTO dbo.demo_table (c1)
VALUES
('Emma Ricken');
GO

INSERT INTO dbo.demo_table (c1)
VALUES
('Josie Ricken');
GO

-- What pages will be allocated by the table
SELECT	p.*, h.*
FROM	dbo.demo_table AS h
		CROSS APPLY sys.fn_PhysLocCracker(%%physloc%%) AS p;
GO

-- what is the free space on the data page of the first two records?
DBCC TRACEON (3604);
DBCC PAGE ('demo_db', 1, 1, 3);
GO

-- Look on the page header of both affected pages
DBCC TRACEON (3604);
DBCC PAGE ('demo_db', 1, 126, 0);
DBCC PAGE ('demo_db', 1, 127, 0);
GO

-- Clean the kitchen!
IF OBJECT_ID('dbo.demo_table', 'U') IS NOT NULL
	DROP TABLE dbo.demo_table;
	GO