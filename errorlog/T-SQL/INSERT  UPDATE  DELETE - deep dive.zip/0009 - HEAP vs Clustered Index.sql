/*============================================================================
	File:		0009 - HEAP vs Clustered Index.sql

	Summary:	This script creates a relation dbo.demo_table for the demonstration
				of INSERT-Internals for HEAPS

				THIS SCRIPT IS PART OF THE TRACK: "INSERT - UPDATE - DELETE internals"

	Date:		September 2013

	SQL Server Version: 2008 / 2012
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
USE demo_db;
GO

IF OBJECT_ID('dbo.Customer', 'U') IS NOT NULL
	DROP TABLE dbo.Customer;
	GO

-- First step is the creation of a HEAP
CREATE TABLE dbo.Customer
(
	Id		INT			NOT NULL	IDENTITY (1, 1),
	Name	CHAR(200)	NOT NULL,
	Street	CHAR(100)	NOT NULL,
	ZIP		CHAR(10)	NOT NULL,
	City	CHAR(100)	NOT NULL
);
GO

-- Fill the table with a few data with SQL Data Generator

-- get the information about the data structures from
-- a database management object