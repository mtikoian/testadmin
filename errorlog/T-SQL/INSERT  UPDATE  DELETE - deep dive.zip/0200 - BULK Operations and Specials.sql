/*============================================================================
	File:		0200 - BULK Operations.sql

	Summary:	This script shows the differences between DML operations
				concerning BULK operations

				THIS SCRIPT IS PART OF THE TRACK: "INSERT - UPDATE - DELETE internals"

	Date:		September 2013

	SQL Server Version: 2008 / 2012
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
USE demo_db;
GO

-- clean the kitchen
IF OBJECT_ID('dbo.source', 'U') IS NOT NULL
	DROP TABLE dbo.[source];
	GO

IF OBJECT_ID('dbo.target', 'U') IS NOT NULL
	DROP TABLE dbo.[target];
	GO

CREATE TABLE dbo.[source]
(
	Id	uniqueidentifier	NOT NULL	DEFAULT (newid())	ROWGUIDCOL,
	c1	char(20)			NOT NULL	DEFAULT ('just stuff'),
	c2	char(20)			NOT NULl	DEFAULT ('new fragrance'),
	c3	date				NOT NULL	DEFAULT (getdate()),
	c4	int					NOT NULL	IDENTITY (1, 1),

	CONSTRAINT pk_tbl_cluster_Id PRIMARY KEY CLUSTERED (Id)
);
GO

CREATE TABLE dbo.[target]
(
	Id	uniqueidentifier	NOT NULL	ROWGUIDCOL,
	c1	char(20)			NOT NULL	DEFAULT ('just stuff'),
	c2	char(20)			NOT NULl	DEFAULT ('new fragrance'),
	c3	date				NOT NULL	DEFAULT (getdate()),
	c4	int					NOT NULL
);
GO


-- Fill with 10.000 records
SET NOCOUNT ON;
GO

DECLARE	@i int = 1;
WHILE @i <= 10000
BEGIN
	INSERT INTO dbo.[source] (c1, c2, c3)
	VALUES (DEFAULT, DEFAULT, DATEADD(dd, (@i % 500) * -1, getdate()))

	SET	@i += 1;
END
GO

SELECT * FROM dbo.[source] AS TC;

-- Insert data into dbo.tbl_clusterNew
BEGIN TRANSACTION
GO
	INSERT INTO dbo.[target] (Id, c1, c2, c3, c4)
	SELECT * FROM dbo.[source];

	SELECT * FROM sys.dm_tran_locks
	WHERE	resource_database_id = db_id();

	-- see the amount of operations which took place!
	SELECT	database_transaction_log_bytes_used,
			database_transaction_log_record_count
	FROM	sys.dm_tran_database_transactions
	WHERE	database_id = db_id();
ROLLBACK TRANSACTION
GO

-- Insert data into dbo.tbl_clusterNew
BEGIN TRANSACTION
GO
	-- activate the execution plan !
	INSERT INTO dbo.[target] (Id, c1, c2, c3, c4)
	SELECT * FROM dbo.[source];

	SELECT * FROM sys.dm_tran_locks
	WHERE	resource_database_id = db_id();

	-- see the amount of operations which took place!
	SELECT	database_transaction_log_bytes_used,
			database_transaction_log_record_count
	FROM	sys.dm_tran_database_transactions
	WHERE	database_id = db_id();
ROLLBACK TRANSACTION
GO

-- TRUNCATE the target relation because it has to be completly empty!
TRUNCATE TABLE dbo.[target];
GO

-- Now exact the same situation as before with exclusive lock!
-- Insert data into dbo.tbl_clusterNew
BEGIN TRANSACTION
GO
	INSERT INTO dbo.[target] WITH (TABLOCK) (Id, c1, c2, c3, c4)
	SELECT * FROM dbo.[source];

	SELECT * FROM sys.dm_tran_locks
	WHERE	resource_database_id = db_id() AND
			request_session_id = @@SPID;

	-- see the amount of operations which took place!
	SELECT	database_transaction_log_bytes_used,
			database_transaction_log_record_count
	FROM	sys.dm_tran_database_transactions
	WHERE	database_id = db_id();
COMMIT TRANSACTION
GO

-- WOWWWWW!!! --
CHECKPOINT;
GO

-- clean the kitchen
IF OBJECT_ID('dbo.source', 'U') IS NOT NULL
	DROP TABLE dbo.[source];
	GO

IF OBJECT_ID('dbo.target', 'U') IS NOT NULL
	DROP TABLE dbo.[target];
	GO
