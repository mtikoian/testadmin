/* 
 Filename:     TSQL_Queries.sql
 Created on:   1/26/2012 4:00 PM
 Created by:   Max Trinidad

 Comment: T-SQL Query samples for the PowerShell vs T-SQL session.
*/
-- Basic T-SQL Query:
-- or /* .. */ are comments






-- Creating Variables:
Declare @Astring as varchar(20), @Astring2 as varchar(20), @num as Int
Set @Astring = 'This is a string'
Set @num = 213
Set @Astring2 = '$Test01!';

Select @Astring; Select @num; Select @Astring2;





-- Get Count of records in the table:
Select Count(*) from Production.Location;






-- Displaying Data:
Select * from Production.Location






-- Selecting some Columns/Fields:
Select [LocationID], [Name], [Availability] 
	from Production.Location;





-- Adding Custom fields:
Select [Name], [Availability] as 'Available'
	from Production.Location;





--Using Where Clause:
Select [LocationID], [Name] from Production.Location
	Where [Availability] = 0;





-- Select only locations '30','40','50'
Select [LocationID], [Name], [Availability] 
	from Production.Location
	Where [LocationID] in ('30','40','50');





-- Select only the Cost Rate  <= $13.00 and not equal 0
SELECT [LocationID]
      ,[Name]
      ,[CostRate]
      ,[Availability]
  FROM [AdventureWorks].[Production].[Location]
  where [CostRate] <= '13.00' and  [CostRate] <> '0'





-- Select Case to add a 'CostIndicator':
SELECT [LocationID]
      ,[Name]
      ,[CostRate]
	  ,Case [CostRate]
		When '0.00' then 'x'
		Else ''
	  End as 'CostIndicator'
      ,[Availability]
      ,[ModifiedDate]
  FROM [AdventureWorks].[Production].[Location]





  SELECT * FROM [AdventureWorks].[Production].[Location]
  Order by [LocationID] desc





  Select Distinct [Availability], COUNT(*) AS Totalrec FROM [AdventureWorks].[Production].[Location]
  Group by [Availability]

/***** - The End - *****/