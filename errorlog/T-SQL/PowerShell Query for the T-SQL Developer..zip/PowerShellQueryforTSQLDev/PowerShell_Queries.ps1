﻿#========================================================================
# Created with: SAPIEN Technologies, Inc., PrimalForms 2011 v2.0.18
# Created on:   1/26/2012 4:00 PM
# Created by:   Max Trinidad
# Organization: PutItTogether
# Filename:     PowerShell_Queries.ps1
#
# Comment: Basic PowerShell Query Demo
#========================================================================
## ->Here's an example of PowerShell comments.
## - Creating a string Variables (double-quote):
$Astring = "This is a String"
$Astring
## - A strong-Typed variable:
[string] $Astring = "This is a String"; 
$Astring.GetType()
$Astring
## - String storing special characters using single-quote):
$Astring2 = '$test01!';
$Astring2
"$test01!";
## - Storing Numeric, getting object type, and display value - (Oneliner):
$num = 213; $num; $num.GetType();
$num = "213"; $num; $num.GetType();
## - Load PowerShell SQLPS Module:
Import-Module SQLPS -DisableNameChecking; cd c:\;
## - Loading a SQL Table data into a PowerShell Object:
$Data = Invoke-SQLCmd -serverInstance WIN8Server1\SQLExpress -Database AdventureWorks -Query "Select * from Production.Location";
## - Get Count of records in object:
$Data.count
## - Type of .NET PSobject:
$Data.GetType()
## - Displaying Data all objects properties (fields):
$Data
# or
$Data | FT -AutoSize  
## valid line"
"$Data | Select $_ | FT -AutoSize"
## - Discovery process through .NET reflection:
$Data | Get-Member 
## - Get result to a gridview:
$Data | gm | Out-GridView
## - Select few properties (Columns/Fields)
$Data | Select LocationID, Name, Availability | FT -auto
## - Adding Custom fields:
$Data | Select LocationID, Name, @{Label = 'Available';Expression = {$_.Availability}} | FT -auto
## - Using the Where command:
$Data | Where {$_.Availability -eq 0} | Select Availability, LocationID, Name |  FT -auto
## - Select only locations '30','40','50'
$Data | Where {$_.LocationID -match "30|40|50"} | Select LocationID, Name, Availability |  FT -auto
## - Select only the contactID <= 1003 with continuation lines:
$Data `
| Where {($_.CostRate -le '13.00') -and ($_.CostRate -ne '0')} `
| Select LocationID `
      ,Name `
      ,CostRate `
      ,Availability |  FT -auto;
## - Select only the contactID <= 1003 with continuation lines:
$Data `
| Select LocationID `
      ,Name `
      ,CostRate `
	  ,@{Label = 'CostIndicator';Expression =  `
	  { `
		 $x = Switch( [int] $_.CostRate) `
		  { `
			0 {"x"} `
			Default {"-"} `
		  }; $x; `
	  }} `
      ,Availability |  FT -auto;
## - Using basic sort:
$Data | Sort-Object LocationID -Descending | FT -AutoSize;
## - Using basic Grouping:
$Data | Group-Object Availability | FT -AutoSize;
$Data | Group-Object Availability | Select-Object count, Name | FT -AutoSize;
## - Exporting data to file:
$Data | Export-CSv -Path 'C:\PowerShellQuery\DataReport.csv' -NoTypeInformation -Encoding Ascii -Force;
Invoke-Item 'C:\PowerShellQuery\DataReport.csv';
## -- -----------------------------------------------------------------------------------------------
## - PowerShell Help is always at your finger tip, look at the list of availables 'About_*' topics:
## -
Get-Help About_* | Select-Object Name
##
## --    End of DEMO1!
##
