USE [SQLSaturday425]
GO

/****** Object:  StoredProcedure [dbo].[cursorr]    Script Date: 6/1/2016 10:12:28 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE procedure [dbo].[cursorr] as 
--declare @Kount as int
--declare @Kounter as int
--declare @City as varchar(20)
--declare @lastCity as varchar(20)
--declare @Province as varchar(20)
--declare @amount as int

/*
Insert into [dbo].[beersalesWhileLoop]
select Province, City, Monthh, Amount from [dbo].[beersales]
order by province,city
*/

CREATE TABLE #rawdata2(
	[Province] [varchar](40) NULL,
	[City] [varchar](40) NULL,
	[Amount] [int] NULL,
	Cumulative int
)
SELECT  
       [Province]
      ,[City]
      ,[Monthh]
      ,[Amount]
	  Into #rawdata1
  FROM [SQLSaturday425].[dbo].[beersalesWhileLoop]
  order by rownumber asc

  DECLARE @Revenue TABLE (
     Rownumber int ,
	 Province varchar(20) ,
	 City varchar(20) ,
	 Amount int,
	 RunningTotal int	  
	 )

DECLARE @Province varchar(20),
        @City Varchar(20),
		@LastCity Varchar(20),
        @Revenue1 int,
        @RunningTotal int,
		@Amount int,
		@Kountt int
SET @RunningTotal = 0
Set @Kountt =1
 
DECLARE rt_cursor CURSOR
FOR
SELECT Province, City, Amount
FROM [dbo].[beersalesWhileLoop] 
order by Rownumber asc



OPEN rt_cursor
FETCH NEXT FROM rt_cursor INTO @Province, @City,@Amount 
WHILE @@FETCH_STATUS = 0
 BEGIN
  SET @RunningTotal = case when @City = @LastCity then @RunningTotal + @Amount else @Amount end
 INSERT @Revenue VALUES (@Kountt,@Province,@City,@Amount,@RunningTotal)
 set  @lastCity   =  @City
 Set @Kountt = @Kountt + 1
 FETCH NEXT FROM rt_cursor INTO  @Province, @City, @Amount
 END
CLOSE rt_cursor
DEALLOCATE rt_cursor
  
SELECT  * into #rawdata3 FROM @Revenue 
Select * from #rawdata3
 
order by Rownumber



GO


