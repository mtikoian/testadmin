USE [SQLSaturday425]
GO

/****** Object:  StoredProcedure [dbo].[ChartFormat]    Script Date: 6/24/2015 1:01:06 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

--IF OBJECT_ID(N'tempdb..#rawdata1') IS NOT NULL
--BEGIN
--     DROP TABLE #rawdata1
--END
--IF OBJECT_ID(N'tempdb..#rawdata2') IS NOT NULL
--BEGIN
--     DROP TABLE #rawdata2
--END
--go
Alter procedure [dbo].[ChartFormat] as

declare @Yearr as varchar(4)
declare @month01 varchar(6)
declare @month02 varchar(6)
declare @month03 varchar(6)
declare @month04 varchar(6)
declare @month05 varchar(6)
declare @month06 varchar(6)
declare @month07 varchar(6)
declare @month08 varchar(6)
declare @month09 varchar(6)
declare @month10 varchar(6)
declare @month11 varchar(6)
declare @month12 varchar(6) 
declare @SQL nvarchar(2000)
set @Yearr =  convert(varchar(4),datePart(Year,convert(date,GetDate())))
Set @Month01 = @Yearr + '01'
Set @Month02 = @Yearr + '02'
Set @Month03 = @Yearr + '03'
Set @Month04 = @Yearr + '04'
Set @Month05 = @Yearr + '05'
Set @Month06 = @Yearr + '06'
Set @Month07 = @Yearr + '07'
Set @Month08 = @Yearr + '08'
Set @Month09 = @Yearr + '09'
Set @Month10 = @Yearr + '10'
Set @Month11 = @Yearr + '11'
Set @Month12 = @Yearr + '12'

select sum(amount) as Revenue
,case when monthh = '01' then @Month01
      when monthh = '02' then @Month02
	  when monthh = '03' then @Month03
      when monthh = '04' then @Month04
	  when monthh = '05' then @Month05
      when monthh = '06' then @Month06
	  when monthh = '07' then @Month07
      when monthh = '08' then @Month08
	  when monthh = '09' then @Month09
      when monthh = '10' then @Month10
	  when monthh = '11' then @Month11
      when monthh = '12' then @Month12 end as Yearmth
	  ,case when monthh = '01' then 'Jan'
      when monthh = '02' then 'Feb'
	  when monthh = '03' then 'Mar'
      when monthh = '04' then 'Apr'
	  when monthh = '05' then 'May'
      when monthh = '06' then 'Jun'
	  when monthh = '07' then 'Jul'
      when monthh = '08' then 'Aug'
	  when monthh = '09' then 'Sep'
      when monthh = '10' then 'Oct'
	  when monthh = '11' then 'Nov'
      when monthh = '12' then 'Dec' end as Monthee
	 , province, city 
	
from [dbo].[beersales]
group by province, city, monthh
order by Province, city,monthh
