use [SQLSaturday425]
go
--go
--IF OBJECT_ID(N'tempdb..#rawdata1') IS NOT NULL
--BEGIN
--     DROP TABLE #rawdata1
--END
--IF OBJECT_ID(N'tempdb..#rawdata2') IS NOT NULL
--BEGIN
--     DROP TABLE #rawdata2
--END
--go
alter procedure PivotMatrix as

declare @Yearr as varchar(4)
declare @month01 varchar(6)
declare @month02 varchar(6)
declare @month03 varchar(6)
declare @month04 varchar(6)
declare @month05 varchar(6)
declare @month06 varchar(6)
declare @month07 varchar(6)
declare @month08 varchar(6)
declare @month09 varchar(6)
declare @month10 varchar(6)
declare @month11 varchar(6)
declare @month12 varchar(6) 
declare @SQL nvarchar(2000)
set @Yearr =  convert(varchar(4),datePart(Year,convert(date,GetDate())))
Set @Month01 = @Yearr + '01'
Set @Month02 = @Yearr + '02'
Set @Month03 = @Yearr + '03'
Set @Month04 = @Yearr + '04'
Set @Month05 = @Yearr + '05'
Set @Month06 = @Yearr + '06'
Set @Month07 = @Yearr + '07'
Set @Month08 = @Yearr + '08'
Set @Month09 = @Yearr + '09'
Set @Month10 = @Yearr + '10'
Set @Month11 = @Yearr + '11'
Set @Month12 = @Yearr + '12'

select sum(amount) as Revenue
,case when monthh = '01' then @Month01
      when monthh = '02' then @Month02
	  when monthh = '03' then @Month03
      when monthh = '04' then @Month04
	  when monthh = '05' then @Month05
      when monthh = '06' then @Month06
	  when monthh = '07' then @Month07
      when monthh = '08' then @Month08
	  when monthh = '09' then @Month09
      when monthh = '10' then @Month10
	  when monthh = '11' then @Month11
      when monthh = '12' then @Month12 end as Yearmth
	 , province, city 
	 into #rawdata1
from [dbo].[beersales]
group by province, city, monthh
order by Province, city,monthh

set @sql = 
' select  City, [' +  @month01+ '] ,[' + @month02+ '],[' +@month03+ '],[' +@month04+ '],[' +@month05 +'],[' 
 + @month06+ '],[' +@month07+ '],[' +@month08+ '],[' +@month09+ '],[' +@month10+ '],[' +  
  @month11+ '],[' +@month12 +
']   from ' +
' ( ' +
'  select Yearmth,City, name, value ' +
'  from #rawdata1 ' +
'  unpivot ' +
'  ( ' +
'    value for name in (Revenue) ' +
'  ) unpiv '+
' ) src ' +
' pivot ' +
' ( ' +
'  sum(value) ' +
'  for YearMth in (['  
 + @month01+ '],[' + @month02+ '],[' +@month03+ '],[' +@month04+ '],[' +@month05 +'],[' 
 + @month06+ '],[' +@month07+ '],[' +@month08+ '],[' +@month09+ '],[' +@month10+ '],['  
 + @month11+ '],[' +@month12  +'] )) piv ' 
 + '  order by name asc ' 

 CREATE TABLE #rawdata2(
	[City] [varchar](75) NULL,
	[Month01] [decimal](10, 2) NULL,
	[Month02] [decimal](10, 2) NULL,
	[Month03] [decimal](10, 2) NULL,
	[Month04] [decimal](10, 2) NULL,
	[Month05] [decimal](10, 2) NULL,
	[Month06] [decimal](10, 2) NULL,
	[Month07] [decimal](10, 2) NULL,
	[Month08] [decimal](10, 2) NULL,
	[Month09] [decimal](10, 2) NULL,
	[Month10] [decimal](10, 2) NULL,
	[Month11] [decimal](10, 2) NULL,
	[Month12] [decimal](10, 2) NULL
)
 --select   City,[201501],[201502],[201503],[201504],[201505],[201506],[201507],[201508],[201509],[201510],[201511],[201512] 
 --  from  (   select Yearmth,City, name, value   from #rawdata1   unpivot   (     value for name in (Revenue)   ) unpiv  ) src  
 --  pivot  (   sum(value)   for YearMth in ([201501],[201502],[201503],[201504],[201505],[201506],[201507],[201508],[201509],[201510],[201511],[201512]
 --  ) )  piv    order by name asc 

insert #rawdata2
exec sp_executesql @SQL  with recompile 
select City,Month01 as 'Jan',
       Month02 as 'Feb',
       Month03 as 'Mar',
       Month04 as 'Apr',
	   Month05 as 'May',
       Month06 as 'Jun',
       Month07 as 'Jul',
       Month08 as 'Aug',
	   Month09 as 'Sep',
	   Month10 as 'Oct',
	   Month11 as 'Nov',
	   Month12 as 'Dec'

 from #rawdata2
