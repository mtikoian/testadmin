USE [SQLSaturday425]
GO

CHECKPOINT; 
GO 
DBCC DROPCLEANBUFFERS; 
GO

/****** Object:  StoredProcedure [dbo].[whileloop]    Script Date: 6/1/2016 8:31:10 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


IF OBJECT_ID(N'tempdb..#rawdata1') IS NOT NULL
BEGIN
     DROP TABLE #rawdata1
END
IF OBJECT_ID(N'tempdb..#rawdata2') IS NOT NULL
BEGIN
     DROP TABLE #rawdata2
END
 --alter procedure [dbo].[whileloop] as 
declare @Kount as int
declare @Kounter as int
declare @City as varchar(20)
declare @lastCity as varchar(20)
declare @Province as varchar(20)
declare @amount as int
declare @RunningTotal as int
set @Kounter = 1
Set @RunningTotal=0
/*
Insert into [dbo].[beersalesWhileLoop]
select Province, City, Monthh, Amount from [dbo].[beersales]
order by province,city
*/

CREATE TABLE #rawdata2(
    [RowNumber] int null,
	[Province] [varchar](40) NULL,
	[City] [varchar](40) NULL,
	[Amount] [int] NULL,
	Cumulative int
)
SELECT  rownumber
       ,[Province]
      ,[City]
      ,[Monthh]
      ,[Amount]
	  Into #rawdata1
  FROM [SQLSaturday425].[dbo].[beersalesWhileLoop]
  order by rownumber asc

  set @Kount = @@ROWCOUNT
  
  while @Kounter <= @kount
  begin
  set @Province=(select Province from #rawdata1 where rownumber = @Kounter)
  set @City=(select city from #rawdata1 where rownumber = @Kounter)
  set @amount = (select amount from #rawdata1 where rownumber = @Kounter)
  set @RunningTotal = (case when @City = @LastCity then @RunningTotal + @amount else @Amount end)
  Insert into #rawdata2
  select @Kounter, @Province,@City,@Amount,@RunningTotal
  set @lastCity = @City
  set @Kounter = @Kounter +1
  
  end
  select * from #rawdata2
  --where province = 'Free state'
  --order by rownumber
GO


