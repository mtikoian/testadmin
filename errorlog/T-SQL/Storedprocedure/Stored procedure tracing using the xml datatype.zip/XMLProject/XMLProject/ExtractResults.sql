-- Find all of the log entries with errors in them

select * from dbo.XMLLog x
where x.xmlData.exist ('//error') = 1;

-- Get a list of the errors

select x.* 
, xl.d.value ('@number', 'int') as ErrorNumber
, xl.d.value ('@line', 'int') as ErrorLine
, xl.d.value ('@severity', 'int') as ErrorSeverity
, xl.d.value ('@procedure', 'nvarchar(255)') as ErrorProcedure
, xl.d.value ('../@time', 'datetime2') as ErrorTime
 from dbo.XMLLog x
cross apply x.xmlData.nodes ('/procLog/steps/step/error') xl (d)
where x.ObjectName = 'uspAddCustomer';

select x.* 
, xl.d.value ('@number', 'int') as ErrorNumber
, xl.d.value ('@line', 'int') as ErrorLine
, xl.d.value ('@severity', 'int') as ErrorSeverity
, xl.d.value ('@procedure', 'nvarchar(255)') as ErrorProcedure
, xl.d.value ('(text())[1]', 'nvarchar(255)') as ErrorMessage
, xl.d.value ('../@time', 'datetime2') as ErrorTime
 from dbo.XMLLog x
cross apply x.xmlData.nodes ('/procLog/steps/step/error[@severity > 14]') xl (d)
where x.ObjectName = 'uspAddCustomer';

-- Get all of the records, including those that don't have a severe error
-- But show the values if there is an error of such severity
select x.* 
, xl.d.value ('@number', 'int') as ErrorNumber
, xl.d.value ('@line', 'int') as ErrorLine
, xl.d.value ('@severity', 'int') as ErrorSeverity
, xl.d.value ('@procedure', 'nvarchar(255)') as ErrorProcedure
, xl.d.value ('../@time', 'datetime2') as ErrorTime
 from dbo.XMLLog x
outer apply x.xmlData.nodes ('/procLog/steps/step/error[@severity > 14]') xl (d)
where x.ObjectName = 'uspAddCustomer';

-- Get information about all of the null errors
-- I suspect that it has something to StateParameter
select x.* 
, xl.d.value ('@number', 'int') as ErrorNumber
, xl.d.value ('@line', 'int') as ErrorLine
, xl.d.value ('@severity', 'int') as ErrorSeverity
, xl.d.value ('@procedure', 'nvarchar(255)') as ErrorProcedure
, xl.d.value ('(text())[1]', 'nvarchar(255)') as ErrorMessage
, xl.d.value ('../@time', 'datetime2') as ErrorTime
, x.xmlData.value ('fn:data((/procLog/steps/step[1]/Parameters/State)[1])', 'nvarchar(255)') as StateParameter
, x.xmlData.value ('fn:data((/procLog/steps/step[@name = "after state insert"]/Variables/StateID)[1])', 'int') as StateIDVariable
 from dbo.XMLLog x
cross apply x.xmlData.nodes ('/procLog/steps/step/error[@severity > 14]') xl (d)
where x.ObjectName = 'uspAddCustomer';

-- Get information about all of the null errors
-- I suspect that it has something to StateParameter
select x.* 
, xl.d.value ('@number', 'int') as ErrorNumber
, xl.d.value ('@line', 'int') as ErrorLine
, xl.d.value ('@severity', 'int') as ErrorSeverity
, xl.d.value ('@procedure', 'nvarchar(255)') as ErrorProcedure
, xl.d.value ('(text())[1]', 'nvarchar(255)') as ErrorMessage
, xl.d.value ('../@time', 'datetime2') as ErrorTime
, x.xmlData.value ('for $i in /procLog/steps/step
  return fn:concat($i/@name, ":  ", $i/@time, ", ")
', 'nvarchar(1000)') as StateIDValues
 from dbo.XMLLog x
cross apply x.xmlData.nodes ('/procLog/steps/step/error[@severity > 14]') xl (d)
where x.ObjectName = 'uspAddCustomer';

