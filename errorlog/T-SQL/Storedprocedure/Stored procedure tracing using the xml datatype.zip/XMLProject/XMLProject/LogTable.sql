use AdventureWorksDemo 
go

-- Build the table

CREATE TABLE [dbo].[XMLLog](
	[LogID] [int] IDENTITY(1,1) NOT NULL PRIMARY KEY ,
	[ObjectID] [int] NULL,
	[DatabaseName] [nvarchar](255) NULL,
	[ObjectType] [char](5) NULL,
	[ObjectSchema] [nvarchar](255) NULL,
	[ObjectName] [nvarchar](255) NULL,
	[xmlData] [xml] NULL,
	[StartDate] [datetime2](7) NOT NULL -- Use Datetime for pre-2008
	      default(sysdatetime()),
	EndDate datetime2 (7) null
	)