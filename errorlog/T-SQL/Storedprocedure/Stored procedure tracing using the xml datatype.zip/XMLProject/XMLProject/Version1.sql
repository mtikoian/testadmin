USE [AdventureWorksDemo]
GO
/****** Object:  StoredProcedure [dbo].[uspAddCustomer]    Script Date: 09/30/2010 07:41:43 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Russel Loski
-- Create date: September 18, 2010
-- Description:	Routine to add a customer
-- =============================================
ALTER PROCEDURE [dbo].[uspAddCustomer] 
	-- Add the parameters for the stored procedure here
             @FirstName  Name 
           , @MiddleName Name 
           , @LastName Name
           , @AddressLine1 nvarchar(60) 
           , @AddressLine2 nvarchar(60) 
           , @City nvarchar(30)
           , @State nchar(3)
           , @PostalCode nvarchar(15) 
            
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
    declare @errorMsg nvarchar(1000);
    declare @xmlLog xml;
    declare @data xml;
    
    set @xmlLog  = (select SYSDATETIME() as [@startDate]
      , @FirstName  as [Parameters/FirstName]
           , @MiddleName as [Parameters/MiddleName]
           , @LastName as [Parameters/LastName]
           , @AddressLine1 as [Parameters/AddressLine1]
           , @AddressLine2 as [Parameters/AddressLine2] 
           , @City as [Parameters/City]
           , @State as [Parameters/State]
           , @PostalCode as [Parameters/PostalCode]
        for xml path ('procLog'), Elements  xsinil, type)
    

    begin try 
    begin tran 
		declare @BusinessEntityID int;
		declare @StateID int;
		declare @AddressID int;

      set @data = (
      select  'before BusinessEntity insert' as [@name]
        , SYSDATETIME() as [@time]
        , @BusinessEntityID as [Variables/BusinessEntityID]
        , @StateID as [Variables/StateID]
        , @AddressID as [Variables/AddressID]
        for XML Path ('step'), elements xsinil, type
      );
      set @xmlLog.modify ('insert    
         sql:variable("@data")
         into (/procLog)[1]');
		-- Insert BusinessEntity record
		insert into Person.BusinessEntity (rowguid )
		  values (NEWID () ) ;
	      
		 set @BusinessEntityID = SCOPE_IDENTITY () ;
      set @data = (
      select  'after BusinessEntity insert' as [@name]
        , SYSDATETIME() as [@time]
        , @BusinessEntityID as [Variables/BusinessEntityID]
        , @StateID as [Variables/StateID]
        , @AddressID as [Variables/AddressID]
        for XML Path ('step'), elements xsinil, type
      );
      set @xmlLog.modify ('insert    
         sql:variable("@data")
         into (/procLog)[1]');
		-- Insert the person record
		insert into Person.Person (	BusinessEntityID
		, FirstName 
		, MiddleName 
		, LastName
		, PersonType
		, NameStyle ) 
		values (
		@BusinessEntityID 
		, @FirstName 
		, @MiddleName 
		, @LastName
		, 'IN' -- Individual customer
		, '0' -- Western style
		)
      set @data = (
      select  'after Person insert' as [@name]
        , SYSDATETIME() as [@time]
        , @BusinessEntityID as [Variables/BusinessEntityID]
        , @StateID as [Variables/StateID]
        , @AddressID as [Variables/AddressID]
        for XML Path ('step'), elements xsinil, type
      );
      set @xmlLog.modify ('insert    
         sql:variable("@data")
         into (/procLog)[1]');
		 -- Insert the customer record
	     
		 insert into  Sales.Customer (PersonID)
		 values (@BusinessEntityID);
	  
      set @data = (
      select  'after customer insert' as [@name]
        , SYSDATETIME() as [@time]
        , @BusinessEntityID as [Variables/BusinessEntityID]
        , @StateID as [Variables/StateID]
        , @AddressID as [Variables/AddressID]
        for XML Path ('step'), elements xsinil, type
      );
      set @xmlLog.modify ('insert    
         sql:variable("@data")
         into (/procLog)[1]');
		-- Insert the address
		
		-- Get the state
		select  @StateID =  StateProvinceID
		from Person.StateProvince
		where StateProvinceCode = @State ;
		
      set @data = (
      select  'after state insert' as [@name]
        , SYSDATETIME() as [@time]
        , @BusinessEntityID as [Variables/BusinessEntityID]
        , @StateID as [Variables/StateID]
        , @AddressID as [Variables/AddressID]
        for XML Path ('step'), elements xsinil, type
      );
      set @xmlLog.modify ('insert    
         sql:variable("@data")
         into (/procLog)[1]');
		-- Insert the address
		
		insert into Person.Address ( AddressLine1
		  , AddressLine2
		  , City
		  , StateProvinceID
		  , PostalCode
		   )
		   values ( @AddressLine1  
		   , @AddressLine2  
		   , @City  
		   , @StateID  
		   , @PostalCode  
			);
	      
		  set @AddressID = SCOPE_IDENTITY ();
	      
      set @data = (
      select  'after Address insert' as [@name]
        , SYSDATETIME() as [@time]
        , @BusinessEntityID as [Variables/BusinessEntityID]
        , @StateID as [Variables/StateID]
        , @AddressID as [Variables/AddressID]
        for XML Path ('step'), elements xsinil, type
      );
      set @xmlLog.modify ('insert    
         sql:variable("@data")
         into (/procLog)[1]');
		  -- Link the address to the customer
	      
		  insert into Person.BusinessEntityAddress (BusinessEntityID
			, AddressID
			, AddressTypeID
		  )
			values ( @BusinessEntityID 
			, @AddressID 
			, 1 -- Home address
			) ;
      set @data = (
      select  'after BusinessEntityAddress insert' as [@name]
        , SYSDATETIME() as [@time]
        , @BusinessEntityID as [Variables/BusinessEntityID]
        , @StateID as [Variables/StateID]
        , @AddressID as [Variables/AddressID]
        for XML Path ('step'), elements xsinil, type
      );
      set @xmlLog.modify ('insert    
         sql:variable("@data")
         into (/procLog)[1]');
 			if @@TRANCOUNT > 0 commit tran
      set @data = (
      select  'after commit' as [@name]
        , SYSDATETIME() as [@time]
        , @BusinessEntityID as [Variables/BusinessEntityID]
        , @StateID as [Variables/StateID]
        , @AddressID as [Variables/AddressID]
        for XML Path ('step'), elements xsinil, type
      );
      set @xmlLog.modify ('insert    
         sql:variable("@data")
         into (/procLog)[1]');
       end try
        begin catch
        -- Handle the error
			if @@TRANCOUNT > 0 rollback tran
			set @errorMsg = ERROR_MESSAGE ();
      set @data = ( select  
          'Error handler' as [@name]
        , SYSDATETIME() as [@time]
        , ERROR_NUMBER() as [error/@number]
        , ERROR_LINE () as [error/@line]
        , ERROR_PROCEDURE () as [error/@procedure]
        , ERROR_SEVERITY () as [error/@severity]
        , ERROR_STATE () as [error/@state]
        , @errorMsg as [error]
        , @BusinessEntityID as [Variables/BusinessEntityID]
        , @StateID as [Variables/StateID]
        , @AddressID as [Variables/AddressID]
        for XML Path ('step'), elements xsinil, type
      );
      set @xmlLog.modify ('insert    
         sql:variable("@data")
         into (/procLog)[1]');
			
        end catch
endOfRoutine:
			if @@TRANCOUNT > 0 rollback tran

        INSERT INTO  [dbo].[XMLLog]
           ([ObjectID]
           ,[ObjectType]
           ,[ObjectSchema]
           ,[ObjectName]
           ,[xmlLog])
     VALUES
           ( @@PROCID 
           , 'PROC'
           , OBJECT_SCHEMA_NAME(@@ProcID)
           , OBJECT_NAME(@@Procid)
            , @xmlLog 
            )

        
	    if @errorMsg is not null raiserror (@errorMsg , 16, 1);
 
END
