<procLog startDate='20101002T08:30'>
<Parameters>
  <FirstName>Russ</FirstName>
</Parameters>
<step name="first" time="20101002T08:30">
   <Variables>
     <BusinessEntityID>45</BusinessEntityID>
   </Variables>
</step>
<step name="error" time="20101002T08:30">
  <error line="1">This is the error message</error>
   <Variables>
     <BusinessEntityID>45</BusinessEntityID>
   </Variables>
</step>

</procLog>