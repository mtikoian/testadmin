
	
if @@TRANCOUNT > 0 rollback tran
select @xmlLog;
return

declare @xmlLog xml;
declare @logID int;
declare @data xml;
-- First pass
set @xmlLog =
    (select  @FirstName  as [Parameters/FirstName]
        for xml path ('procLog'), Elements  xsinil, type);
-- Second pass       
set @xmlLog =
    (select  @FirstName  as [Parameters/FirstName]
           , @MiddleName as [Parameters/MiddleName]
           , @LastName as [Parameters/LastName]
           , @AddressLine1 as [Parameters/AddressLine1]
           , @AddressLine2 as [Parameters/AddressLine2] 
           , @City as [Parameters/City]
           , @State as [Parameters/State]
           , @PostalCode as [Parameters/PostalCode]
        for xml path ('procLog'), Elements  xsinil, type);
-- Final pass       
set @xmlLog =
    (select  @FirstName  as [Parameters/FirstName]
           , @MiddleName as [Parameters/MiddleName]
           , @LastName as [Parameters/LastName]
           , @AddressLine1 as [Parameters/AddressLine1]
           , @AddressLine2 as [Parameters/AddressLine2] 
           , @City as [Parameters/City]
           , @State as [Parameters/State]
           , @PostalCode as [Parameters/PostalCode]
           , 'start' as [steps/step/@name]
           , SYSDATETIME() as [steps/step/@time]
        for xml path ('procLog'), Elements  xsinil, type);
        
-- Insert the initial value into the log       
       INSERT INTO  [dbo].[XMLLog]
           ([ObjectID]
           ,[ObjectType]
           ,[DatabaseName]
           ,[ObjectSchema]
           ,[ObjectName]
           , [xmlData]
           , [StartDate])
     VALUES
           ( @@PROCID 
           , 'PROC'
           , DB_NAME()
           , OBJECT_SCHEMA_NAME(@@ProcID)
           , OBJECT_NAME(@@Procid)
           , @xmlLog 
           , SYSDATETIME()

            );
     set @logID = SCOPE_IDENTITY ();
     
  -- Final statement to load the data in   
     update dbo.XMLLog 
         set [xmlData] = @xmlLog,
           EndDate = SYSDATETIME()
         where LogID= @logID ;
         
-- Log one entry
set @data = (select 'create business entity' [@name] 
            , SYSDATETIME () [@time]
            for XML path ('step'), type);
set @xmlLog.modify('insert sql:variable("@data") 
    into (/procLog/steps)[1]');

-- Alternate ways to insert records
      declare @systime datetime2  
      set @systime = SYSDATETIME();
      set @xmlLog.modify ('insert    
         element step
         {attribute name {"before BusinessEntity insert"} , 
         attribute time {sql:variable("@systime")} }
         into (/procLog/steps)[1]');        
         
 
-- Store the variables for a step 
       set @data = (
       select 'before BusinessEntity insert' as [@name]
         , SYSDATETIME () as [@time]
         , @BusinessEntityID as [Variables/BusinessEntityID]
         , @StateID as [Variables/StateID]
         , @AddressID as [Variables/AddressID]
         for XML path ('step'), Elements xsinil
      );
      set @xmlLog.modify ('insert    
          sql:variable("@data")
         into (/procLog/steps)[1]');        
 
       set @data = (
       select 'error' as [@name]
         , SYSDATETIME () as [@time]
         , ERROR_LINE() as [error/@line]
         , ERROR_NUMBER () as [error/@number]
         , ERROR_PROCEDURE () as [error/@procedure]
         , ERROR_SEVERITY () as [error/@severity]
         , ERROR_STATE () as [error/@state]
         , @errorMsg as [error/text()]
         for XML path ('step'), Elements xsinil
      );
      set @xmlLog.modify ('insert    
          sql:variable("@data")
         into (/procLog/steps)[1]');   
 
 -- Full record of the error
      set @data = (
       select 'error' as [@name]
         , SYSDATETIME () as [@time]
         , @BusinessEntityID as [Variables/BusinessEntityID]
         , @StateID as [Variables/StateID]
         , @AddressID as [Variables/AddressID]
         , ERROR_LINE() as [error/@line]
         , ERROR_NUMBER () as [error/@number]
         , ERROR_PROCEDURE () as [error/@procedure]
         , ERROR_SEVERITY () as [error/@severity]
         , ERROR_STATE () as [error/@state]
         , @errorMsg as [error/text()]
         for XML path ('step'), Elements xsinil
      );
      set @xmlLog.modify ('insert    
          sql:variable("@data")
         into (/procLog)[1]');   

-- Find the values
select x.xmlData.value('/procLog/Parameters/FirstName', 'nvarchar(50)') as FirstName,
*
from dbo.XMLLog x







-- Right way
select x.xmlData.value('(/procLog/Parameters/FirstName)[1]', 'nvarchar(50)') as FirstName,
*
from dbo.XMLLog x

-- Full version
select x.xmlData.value('(/procLog/Parameters/FirstName)[1]', 'nvarchar(50)') as FirstName,
x.xmlData.value('(/procLog/Parameters/MiddleName)[1]', 'nvarchar(50)') as MiddleName,
x.xmlData.value('(/procLog/Parameters/LastName)[1]', 'nvarchar(50)') as LastName,
x.xmlData.value('(/procLog/Parameters/AddressLine1)[1]', 'nvarchar(50)') as AddressLine1,
x.xmlData.value('(/procLog/Parameters/AddressLine2)[1]', 'nvarchar(50)') as AddressLine2,
x.xmlData.value('(/procLog/Parameters/City)[1]', 'nvarchar(50)') as City,
x.xmlData.value('(/procLog/Parameters/PostalCode)[1]', 'nvarchar(50)') as PostalCode,
*
from dbo.XMLLog x

-- Get the error information
select 
x.xmlData.value('(/procLog/steps/step/error)[1]', 'nvarchar(255)') as ErrorMessage,
x.xmlData.value('(/procLog/Parameters/FirstName)[1]', 'nvarchar(50)') as FirstName,
x.xmlData.value('(/procLog/Parameters/MiddleName)[1]', 'nvarchar(50)') as MiddleName,
x.xmlData.value('(/procLog/Parameters/LastName)[1]', 'nvarchar(50)') as LastName,
x.xmlData.value('(/procLog/Parameters/AddressLine1)[1]', 'nvarchar(50)') as AddressLine1,
x.xmlData.value('(/procLog/Parameters/AddressLine2)[1]', 'nvarchar(50)') as AddressLine2,
x.xmlData.value('(/procLog/Parameters/City)[1]', 'nvarchar(50)') as City,
x.xmlData.value('(/procLog/Parameters/PostalCode)[1]', 'nvarchar(50)') as PostalCode,
*
from dbo.XMLLog x


-- Get the error information
select 
x.xmlData.value('(/procLog/steps/step/error)[1]', 'nvarchar(255)') as ErrorMessage,
x.xmlData.value('(/procLog/steps/step/@time)[1]', 'datetime2') as Errortime,
x.xmlData.value('(/procLog/Parameters/FirstName)[1]', 'nvarchar(50)') as FirstName,
x.xmlData.value('(/procLog/Parameters/MiddleName)[1]', 'nvarchar(50)') as MiddleName,
x.xmlData.value('(/procLog/Parameters/LastName)[1]', 'nvarchar(50)') as LastName,
x.xmlData.value('(/procLog/Parameters/AddressLine1)[1]', 'nvarchar(50)') as AddressLine1,
x.xmlData.value('(/procLog/Parameters/AddressLine2)[1]', 'nvarchar(50)') as AddressLine2,
x.xmlData.value('(/procLog/Parameters/City)[1]', 'nvarchar(50)') as City,
x.xmlData.value('(/procLog/Parameters/PostalCode)[1]', 'nvarchar(50)') as PostalCode,
*
from dbo.XMLLog x

select 
x.xmlData.value('(/procLog/steps/step/error)[1]', 'nvarchar(255)') as ErrorMessage,
x.xmlData.value('(/procLog/steps/step/@time[../@name="error"])[1]', 'datetime2') as Errortime,
x.xmlData.value('(/procLog/Parameters/FirstName)[1]', 'nvarchar(50)') as FirstName,
x.xmlData.value('(/procLog/Parameters/MiddleName)[1]', 'nvarchar(50)') as MiddleName,
x.xmlData.value('(/procLog/Parameters/LastName)[1]', 'nvarchar(50)') as LastName,
x.xmlData.value('(/procLog/Parameters/AddressLine1)[1]', 'nvarchar(50)') as AddressLine1,
x.xmlData.value('(/procLog/Parameters/AddressLine2)[1]', 'nvarchar(50)') as AddressLine2,
x.xmlData.value('(/procLog/Parameters/City)[1]', 'nvarchar(50)') as City,
x.xmlData.value('(/procLog/Parameters/PostalCode)[1]', 'nvarchar(50)') as PostalCode,
*
from dbo.XMLLog x


select 
x.xmlData.value('(/procLog/steps/step/error)[1]', 'nvarchar(255)') as ErrorMessage,
x.xmlData.value('(/procLog/steps/step/@time[../@name="error"])[1]', 'datetime2') as Errortime,
x.xmlData.value('(/procLog/Parameters/FirstName)[1]', 'nvarchar(50)') as FirstName,
x.xmlData.value('(/procLog/Parameters/MiddleName)[1]', 'nvarchar(50)') as MiddleName,
x.xmlData.value('(/procLog/Parameters/LastName)[1]', 'nvarchar(50)') as LastName,
x.xmlData.value('(/procLog/Parameters/AddressLine1)[1]', 'nvarchar(50)') as AddressLine1,
x.xmlData.value('(/procLog/Parameters/AddressLine2)[1]', 'nvarchar(50)') as AddressLine2,
x.xmlData.value('(/procLog/Parameters/City)[1]', 'nvarchar(50)') as City,
x.xmlData.value('(/procLog/Parameters/PostalCode)[1]', 'nvarchar(50)') as PostalCode,
*
from dbo.XMLLog x
where x.xmlData.exist('//error') = 1


select 
d.step.value('@name', 'varchar(50)') as StepName,
d.step.value('@time', 'datetime2') as StepTime,
x.xmlData.value('(/procLog/steps/step/error)[1]', 'nvarchar(255)') as ErrorMessage,
x.xmlData.value('(/procLog/steps/step/@time[../@name="error"])[1]', 'datetime2') as Errortime,
x.xmlData.value('(/procLog/Parameters/FirstName)[1]', 'nvarchar(50)') as FirstName,
x.xmlData.value('(/procLog/Parameters/MiddleName)[1]', 'nvarchar(50)') as MiddleName,
x.xmlData.value('(/procLog/Parameters/LastName)[1]', 'nvarchar(50)') as LastName,
x.xmlData.value('(/procLog/Parameters/AddressLine1)[1]', 'nvarchar(50)') as AddressLine1,
x.xmlData.value('(/procLog/Parameters/AddressLine2)[1]', 'nvarchar(50)') as AddressLine2,
x.xmlData.value('(/procLog/Parameters/City)[1]', 'nvarchar(50)') as City,
x.xmlData.value('(/procLog/Parameters/PostalCode)[1]', 'nvarchar(50)') as PostalCode,
x.*
from dbo.XMLLog x
cross apply x.xmlData.nodes ('/procLog/steps/step') d (step)
where x.xmlData.exist('//error') = 1

 


select * from dbo.XMLLog x
where x.xmlData .exist ('//error') = 1;

         
-- Find all of the log entries with errors in them

select * from dbo.XMLLog x
where x.xmlData .exist ('//error') = 1;
select * from dbo.XMLLog x
where x.xmlData.exist ('/procLog/steps/step/error[@severity > 14]') = 1;

-- Get a list of the errors

select x.* 
, xl.d.value ('@number', 'int') as ErrorNumber
, xl.d.value ('@line', 'int') as ErrorLine
, xl.d.value ('@severity', 'int') as ErrorSeverity
, xl.d.value ('@procedure', 'nvarchar(255)') as ErrorProcedure
, xl.d.value ('../@time', 'datetime2') as ErrorTime
 from dbo.XMLLog x
cross apply x.xmlData.nodes ('/procLog/steps/step/error') xl (d)
where x.ObjectName = 'uspAddCustomer';

select x.* 
, xl.d.value ('@number', 'int') as ErrorNumber
, xl.d.value ('@line', 'int') as ErrorLine
, xl.d.value ('@severity', 'int') as ErrorSeverity
, xl.d.value ('@procedure', 'nvarchar(255)') as ErrorProcedure
, xl.d.value ('(text())[1]', 'nvarchar(255)') as ErrorMessage
, xl.d.value ('../@time', 'datetime2') as ErrorTime
 from dbo.XMLLog x
cross apply x.xmlData.nodes ('/procLog/steps/step/error[@severity > 14]') xl (d)
where x.ObjectName = 'uspAddCustomer';

-- Get all of the records, including those that don't have a severe error
-- But show the values if there is an error of such severity
select x.* 
, xl.d.value ('@number', 'int') as ErrorNumber
, xl.d.value ('@line', 'int') as ErrorLine
, xl.d.value ('@severity', 'int') as ErrorSeverity
, xl.d.value ('@procedure', 'nvarchar(255)') as ErrorProcedure
, xl.d.value ('../@time', 'datetime2') as ErrorTime
 from dbo.XMLLog x
outer apply x.xmlData.nodes ('/procLog/steps/step/error[@severity > 14]') xl (d)
where x.ObjectName = 'uspAddCustomer';

-- Get information about all of the null errors
-- I suspect that it has something to StateParameter
select x.* 
, xl.d.value ('@number', 'int') as ErrorNumber
, xl.d.value ('@line', 'int') as ErrorLine
, xl.d.value ('@severity', 'int') as ErrorSeverity
, xl.d.value ('@procedure', 'nvarchar(255)') as ErrorProcedure
, xl.d.value ('(text())[1]', 'nvarchar(255)') as ErrorMessage
, xl.d.value ('../@time', 'datetime2') as ErrorTime
, x.xmlData.value ('fn:data((/procLog/steps/step[1]/Parameters/State)[1])', 'nvarchar(255)') as StateParameter
, x.xmlData.value ('fn:data((/procLog/steps/step[@name = "after state insert"]/Variables/StateID)[1])', 'int') as StateIDVariable
 from dbo.XMLLog x
cross apply x.xmlData.nodes ('/procLog/steps/step/error[@severity > 14]') xl (d)
where x.ObjectName = 'uspAddCustomer';

-- Get information about all of the null errors
-- I suspect that it has something to StateParameter
select x.* 
, xl.d.value ('@number', 'int') as ErrorNumber
, xl.d.value ('@line', 'int') as ErrorLine
, xl.d.value ('@severity', 'int') as ErrorSeverity
, xl.d.value ('@procedure', 'nvarchar(255)') as ErrorProcedure
, xl.d.value ('(text())[1]', 'nvarchar(255)') as ErrorMessage
, xl.d.value ('../@time', 'datetime2') as ErrorTime
 from dbo.XMLLog x
cross apply x.xmlData.nodes ('/procLog/steps/step/error[@severity > 14]') xl (d)
where x.ObjectName = 'uspAddCustomer';

