select top 10 FirstName as [@FirstName] from Person.Person
for xml path ('procLog')


declare @xmlLog xml;
set @xmlLog = '<procLog></procLog>';

set @xmlLog.modify ('insert (
    element step {
     attribute name {"first"}, 
     attribute time {} 
     } 
     )
 into (/procLog)[1]
');
select @xmlLog ;