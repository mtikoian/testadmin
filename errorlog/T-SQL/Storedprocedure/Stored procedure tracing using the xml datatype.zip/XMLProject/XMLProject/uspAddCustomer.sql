-- ================================================
-- Template generated from Template Explorer using:
-- Create Procedure (New Menu).SQL
--
-- Use the Specify Values for Template Parameters 
-- command (Ctrl-Shift-M) to fill in the parameter 
-- values below.
--
-- This block of comments will not be included in
-- the definition of the procedure.
-- ================================================
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Russel Loski
-- Create date: September 18, 2010
-- Description:	Routine to add a customer
-- =============================================
alter PROCEDURE uspAddCustomer 
	-- Add the parameters for the stored procedure here
           @FirstName  Name 
           , @MiddleName Name 
           , @LastName Name
           , @AddressLine1 nvarchar(60) 
           , @AddressLine2 nvarchar(60) 
           , @City nvarchar(30)
           , @State nchar(3)
           , @PostalCode nvarchar(15) 
            
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
    declare @errorMsg nvarchar(1000);
    declare @xmlLog xml = '';
    goto endOfRoutine;
    
    
   
    begin try 
    begin tran 
		declare @BusinessEntityID int;
		declare @StateID int;
		declare @AddressID int;

		-- Insert BusinessEntity record
		insert into Person.BusinessEntity (rowguid )
		  values (NEWID () ) ;
	      
		 set @BusinessEntityID = SCOPE_IDENTITY () ;
	     
		-- Insert the person record
		insert into Person.Person (	BusinessEntityID
		, FirstName 
		, MiddleName 
		, LastName
		, PersonType
		, NameStyle ) 
		values (
		@BusinessEntityID 
		, @FirstName 
		, @MiddleName 
		, @LastName
		, 'IN' -- Individual customer
		, '0' -- Western style
		)
	     
		 -- Insert the customer record
	     
		 insert into  Sales.Customer (PersonID)
		 values (@BusinessEntityID);
	  
		
		-- Insert the address
		
		-- Get the state
		select  @StateID =  StateProvinceID
		from Person.StateProvince
		where StateProvinceCode = @State ;
		
		-- Insert the address
		
		insert into Person.Address ( AddressLine1
		  , AddressLine2
		  , City
		  , StateProvinceID
		  , PostalCode
		   )
		   values ( @AddressLine1  
		   , @AddressLine2  
		   , @City  
		   , @StateID  
		   , @PostalCode  
			);
	      
		  set @AddressID = SCOPE_IDENTITY ();
	      
		  -- Link the address to the customer
	      
		  insert into Person.BusinessEntityAddress (BusinessEntityID
			, AddressID
			, AddressTypeID
		  )
			values ( @BusinessEntityID 
			, @AddressID 
			, 1 -- Home address
			) ;
 			if @@TRANCOUNT > 0 commit tran
       end try
        begin catch
        -- Handle the error
			if @@TRANCOUNT > 0 rollback tran
			set @errorMsg = ERROR_MESSAGE ();
			
        
        end catch
endOfRoutine:
			if @@TRANCOUNT > 0 rollback tran

        select @xmlLog ; 
	    if @errorMsg is not null raiserror (@errorMsg , 16, 1);
	    
END
