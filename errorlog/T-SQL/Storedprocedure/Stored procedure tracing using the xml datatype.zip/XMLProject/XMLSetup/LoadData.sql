Use AdventureWorksDemo
go
set identity_insert [Person].[BusinessEntity] on  
 insert into [Person].[BusinessEntity] ([BusinessEntityID], [rowguid], [ModifiedDate])  
  select [BusinessEntityID], [rowguid], [ModifiedDate] from [AdventureWorks2008R2].[Person].[BusinessEntity]  set identity_insert [Person].[BusinessEntity] off   

insert into [Person].[Person] ([BusinessEntityID], [PersonType], [NameStyle], [Title], [FirstName], [MiddleName], [LastName], [Suffix], [EmailPromotion], [AdditionalContactInfo], [Demographics], [rowguid], [ModifiedDate])   select [BusinessEntityID], [PersonType], [NameStyle], [Title], [FirstName], [MiddleName], [LastName], [Suffix], 
[EmailPromotion],
 cast([AdditionalContactInfo] as [xml](CONTENT [Person].[AdditionalContactInfoSchemaCollection])),
  cast([Demographics] as [xml](CONTENT [Person].[IndividualSurveySchemaCollection])), 
  [rowguid], [ModifiedDate] from [AdventureWorks2008R2].[Person].[Person]  



set identity_insert [Person].[AddressType] on   insert into [Person].[AddressType] ([AddressTypeID], [Name], [rowguid], [ModifiedDate])   select [AddressTypeID], [Name], [rowguid], [ModifiedDate] from [AdventureWorks2008R2].[Person].[AddressType]  set identity_insert [Person].[AddressType] off   
insert into [Person].[CountryRegion] ([CountryRegionCode], [Name], [ModifiedDate])   select [CountryRegionCode], [Name], [ModifiedDate] from [AdventureWorks2008R2].[Person].[CountryRegion]  

set identity_insert [Person].[StateProvince] on   insert into [Person].[StateProvince] ([StateProvinceID], [StateProvinceCode], [CountryRegionCode], [IsOnlyStateProvinceFlag], [Name], [TerritoryID], [rowguid], [ModifiedDate])   select [StateProvinceID], [StateProvinceCode], [CountryRegionCode], [IsOnlyStateProvinceFlag], [Name], [TerritoryID], [rowguid], [ModifiedDate] from [AdventureWorks2008R2].[Person].[StateProvince]  set identity_insert [Person].[StateProvince] off   
set identity_insert [Person].[Address] on   insert into [Person].[Address] ([AddressID], [AddressLine1], [AddressLine2], [City], [StateProvinceID], [PostalCode], [SpatialLocation], [rowguid], [ModifiedDate])   select [AddressID], [AddressLine1], [AddressLine2], [City], [StateProvinceID], [PostalCode], [SpatialLocation], [rowguid], [ModifiedDate] from [AdventureWorks2008R2].[Person].[Address]  set identity_insert [Person].[Address] off   
insert into [Person].[BusinessEntityAddress] ([BusinessEntityID], [AddressID], [AddressTypeID], [rowguid], [ModifiedDate])   select [BusinessEntityID], [AddressID], [AddressTypeID], [rowguid], [ModifiedDate] from [AdventureWorks2008R2].[Person].[BusinessEntityAddress]  
set identity_insert [Sales].[Customer] on   insert into [Sales].[Customer] ([CustomerID], [PersonID], [StoreID], [TerritoryID],  [rowguid], [ModifiedDate])   select [CustomerID], [PersonID], [StoreID], [TerritoryID],   [rowguid], [ModifiedDate] from [AdventureWorks2008R2].[Sales].[Customer]  set identity_insert [Sales].[Customer] off   