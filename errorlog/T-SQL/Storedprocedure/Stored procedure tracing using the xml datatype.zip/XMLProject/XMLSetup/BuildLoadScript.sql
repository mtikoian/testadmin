select 
case when OBJECTPROPERTY(OBJECT_ID('[' +TABLE_SCHEMA + '].[' + TABLE_NAME + ']' ),
 'TableHasIdentity') = 1 then 
'set identity_insert ' 
+ '[' +TABLE_SCHEMA + '].[' + TABLE_NAME + ']' 
+ ' on 
'
else '' end
+ 'insert into '
+ '[' + TABLE_SCHEMA + '].[' + TABLE_NAME + '] (' + Columns + ')
' 
+ ' select ' + COLUMNS + ' from [AdventureWorks2008R2].' 
+ '[' + TABLE_SCHEMA + '].[' + TABLE_NAME + ']
' 
+ 
case when OBJECTPROPERTY(OBJECT_ID('[' + TABLE_SCHEMA + '].[' + TABLE_NAME + ']' ),
 'TableHasIdentity') = 1 then 
 'set identity_insert ' + 
'[' +TABLE_SCHEMA + '].[' + TABLE_NAME + ']' +
' off 
'
else 
''
end 
  from 
  (select *,
  substring((Select ', [' + Column_Name + ']'
  from INFORMATION_SCHEMA.COLUMNS c 
  where c.TABLE_SCHEMA = t1.TABLE_SCHEMA and c.TABLE_NAME = t1.TABLE_NAME 
  for XML path ('') 
  ), 3, 2000) as Columns
  
   from INFORMATION_SCHEMA.TABLES as t1
  where TABLE_TYPE = 'BASE TABLE'
  ) as t 
