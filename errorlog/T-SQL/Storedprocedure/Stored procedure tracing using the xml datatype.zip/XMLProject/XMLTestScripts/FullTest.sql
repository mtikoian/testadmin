declare @firstT table (ID int, Name nvarchar(50))
declare @middleT table (ID int, Name nvarchar(50))
declare @lastT table (ID int, Name nvarchar(50))
declare @CityT table (ID int, Name nvarchar(30))
declare @StateT table (id int, Name nvarchar(30))
declare @first  nvarchar(50) 
declare @middle    nvarchar(50) 
declare @last  nvarchar(50) 
declare @City   nvarchar(30) 
declare @State  nvarchar(30)

insert into @firstT values (0, 'Russ'), (1, 'John'), (2, 'Frank'), (3, 'Peter')
insert into @middleT values (0, 'Charles'), (1, 'James'), (2, 'William'), (3, 'Peter')
insert into @lastT values (0, 'Smith'), (1, 'Jones'), (2, 'Covey'), (3, 'Peters')

insert into @CityT values (0, 'Boston') , (1, 'Kansas City'), (2, 'St Louis'), (3, 'New York')
insert into @StateT values (0, 'MO'), (1, 'TX') , (2, 'Missouri'), (3, 'Texas'), (4, 'Georgia')

declare @count int = 0;
declare @rnd int;

while (@count < 4000) 
begin
set @rnd = 1000 * RAND (@count * datepart (millisecond, sysdatetime()))
set @first = (select Name from @firstT where ID = @rnd % 4)
set @rnd = 1000 * RAND ( )
set @middle = (select Name from @middleT where ID = @rnd % 4)
set @rnd = 1000 * RAND ( )
set @last = (select Name from @lastT where ID = @rnd % 4)
set @rnd = 1000 * RAND ( )
set @city = (select Name from @cityT where ID = @rnd % 4)
set @rnd = 1000 * RAND ()
set @state = (select Name from @stateT where ID = @rnd % 5)

exec dbo.uspAddCustomer
@First , @Middle , @Last , '555 55', null, @City, @State, '99999'

set @count = @count + 1
end
