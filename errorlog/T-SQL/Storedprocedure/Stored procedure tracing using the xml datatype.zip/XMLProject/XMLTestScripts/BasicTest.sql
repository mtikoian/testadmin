exec uspAddCustomer 
	-- Add the parameters for the stored procedure here
             'Russ' 
           , 'A'
           , 'Loski'
           , '555 NW 55th'
           , null
           , 'Houston'
           , 'TX'
           , '77060'

select top 10 * from dbo.XMLLog
order by StartDate desc