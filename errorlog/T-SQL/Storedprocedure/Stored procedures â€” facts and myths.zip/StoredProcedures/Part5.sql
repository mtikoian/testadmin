DBCC FREEPROCCACHE
GO

USE AdventureWorks2008R2;
GO

IF EXISTS (SELECT 1 FROM sys.procedures WHERE name ='uspGetSpecialOfferHistory')
	 DROP PROCEDURE uspGetSpecialOfferHistory
GO

CREATE PROCEDURE uspGetSpecialOfferHistory (
    @SpecialOfferID int = NULL)
AS
IF @SpecialOfferID IS NULL
    SELECT SUM([SubTotal])
    FROM Sales.SalesOrderHeader h JOIN Sales.SalesOrderDetail d
        ON h.SalesOrderID = d.SalesOrderId; 
ELSE
    SELECT SUM([SubTotal])
    FROM Sales.SalesOrderHeader h JOIN Sales.SalesOrderDetail d
        ON h.SalesOrderID = d.SalesOrderId
    WHERE [SpecialOfferID] = @SpecialOfferID;
GO

--Ctrl+M
EXEC uspGetSpecialOfferHistory;
GO

SELECT cp.usecounts, qt.text, qp.query_plan
FROM sys.dm_exec_cached_plans AS cp
CROSS APPLY sys.dm_exec_sql_text(plan_handle) AS qt
CROSS APPLY sys.dm_exec_query_plan(plan_handle) AS qp
WHERE qt.text LIKE '%Sales.SalesOrderHeader%'
AND qt.text NOT like '%dm_exec_sql_text%';
GO

SET STATISTICS IO ON;
GO
DBCC FREEPROCCACHE;
GO

EXEC uspGetSpecialOfferHistory;
GO
EXEC uspGetSpecialOfferHistory @SpecialOfferID = 1;
GO

SELECT cp.usecounts, qt.text, qp.query_plan
FROM sys.dm_exec_cached_plans AS cp
CROSS APPLY sys.dm_exec_sql_text(plan_handle) AS qt
CROSS APPLY sys.dm_exec_query_plan(plan_handle) AS qp
WHERE qt.text LIKE '%Sales.SalesOrderHeader%'
AND qt.text NOT like '%dm_exec_sql_text%';
GO

DBCC FREEPROCCACHE;
GO
EXEC uspGetSpecialOfferHistory @SpecialOfferID =1;
GO
EXEC uspGetSpecialOfferHistory;
GO

SET STATISTICS IO OFF
GO

SELECT cp.usecounts, qt.text, qp.query_plan
FROM sys.dm_exec_cached_plans AS cp
CROSS APPLY sys.dm_exec_sql_text(plan_handle) AS qt
CROSS APPLY sys.dm_exec_query_plan(plan_handle) AS qp
WHERE qt.text LIKE '%Sales.SalesOrderHeader%'
AND qt.text NOT like '%dm_exec_sql_text%';
GO

ALTER PROCEDURE uspGetSpecialOfferHistory (
	@SpecialOfferID int = NULL)
AS
IF @SpecialOfferID IS NULL
	SELECT SUM([SubTotal])
	FROM Sales.SalesOrderHeader h JOIN Sales.SalesOrderDetail d
		ON h.SalesOrderID = d.SalesOrderId
	OPTION (OPTIMIZE FOR UNKNOWN); 
ELSE
	SELECT SUM([SubTotal])
	FROM Sales.SalesOrderHeader h JOIN Sales.SalesOrderDetail d
		ON h.SalesOrderID = d.SalesOrderId
	WHERE [SpecialOfferID] = @SpecialOfferID
	OPTION (OPTIMIZE FOR UNKNOWN);
GO

EXEC uspGetSpecialOfferHistory;
GO
EXEC uspGetSpecialOfferHistory @SpecialOfferID = 1;
GO

SELECT cp.usecounts, qt.text, qp.query_plan
FROM sys.dm_exec_cached_plans AS cp
CROSS APPLY sys.dm_exec_sql_text(plan_handle) AS qt
CROSS APPLY sys.dm_exec_query_plan(plan_handle) AS qp
WHERE qt.text LIKE '%Sales.SalesOrderHeader%'
AND qt.text NOT like '%dm_exec_sql_text%';
GO

CREATE PROCEDURE uspGetSpecialOfferHistoryV2 (
	@SpecialOfferID int = NULL)
AS
IF @SpecialOfferID IS NOT NULL 
	EXEC _uspGetSpecialOfferHistoryForOffer @_SpecialOfferID = @SpecialOfferID;
ELSE
	EXEC _uspGetSpecialOfferHistoryForTotal;
GO

CREATE PROCEDURE _uspGetSpecialOfferHistoryForOffer (
	@_SpecialOfferID int)
AS
	SELECT SUM([SubTotal])
	FROM Sales.SalesOrderHeader h JOIN Sales.SalesOrderDetail d
		ON h.SalesOrderID = d.SalesOrderId
	WHERE [SpecialOfferID] = @_SpecialOfferID; 
GO
CREATE PROCEDURE _uspGetSpecialOfferHistoryForTotal
AS
	SELECT SUM([SubTotal])
	FROM Sales.SalesOrderHeader h JOIN Sales.SalesOrderDetail d
		ON h.SalesOrderID = d.SalesOrderId;
GO

DBCC FREEPROCCACHE
GO
EXEC uspGetSpecialOfferHistoryV2;
GO
EXEC uspGetSpecialOfferHistoryV2 @SpecialOfferID =1;
GO

SELECT cp.usecounts, qt.text, qp.query_plan
FROM sys.dm_exec_cached_plans AS cp
CROSS APPLY sys.dm_exec_sql_text(plan_handle) AS qt
CROSS APPLY sys.dm_exec_query_plan(plan_handle) AS qp
WHERE qt.text LIKE '%Sales.SalesOrderHeader%'
AND qt.text NOT like '%dm_exec_sql_text%';
GO

DBCC FREEPROCCACHE
GO
EXEC uspGetSpecialOfferHistoryV2;
GO
EXEC uspGetSpecialOfferHistoryV2 @SpecialOfferID =5;
GO

DROP PROCEDURE uspGetSpecialOfferHistory;
DROP PROCEDURE _uspGetSpecialOfferHistoryForTotal;
DROP PROCEDURE _uspGetSpecialOfferHistoryForOffer;
DROP PROCEDURE uspGetSpecialOfferHistoryV2
GO
