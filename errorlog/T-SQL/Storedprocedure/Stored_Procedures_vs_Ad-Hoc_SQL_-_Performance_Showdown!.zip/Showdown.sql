-- Showdown: Plan Caching & Memory Usage (two in one shot!)

-- Let's drop the plan cache and the buffer pool - we want a clean environment for our tests to be somewhat scientific

DBCC DROPCLEANBUFFERS;
DBCC FREEPROCCACHE;
GO

-- Server default: Optimize for Ad-Hoc Workloads set to false.

SELECT  *
FROM    sys.configurations
WHERE   name = 'optimize for ad hoc workloads';
GO

-- If it's enabled, we need to set it to 0.

EXEC sp_configure 'advanced', 1;
RECONFIGURE

EXEC sp_configure 'optimize for ad hoc workloads', 0;
RECONFIGURE
GO

-- Run the query tool (Ad-Hoc)

-- Let's check what kind of caching took place

SELECT  COUNT(*)
FROM    sys.dm_exec_query_stats qs
        CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle) AS st
WHERE   st.text LIKE '%SalesOrderID%';
GO


SELECT  SUM(cp.size_in_bytes) AS total_bytes
FROM    sys.dm_exec_query_stats qs
        JOIN sys.dm_exec_cached_plans cp ON cp.plan_handle = qs.plan_handle
        CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle) AS st
WHERE   st.text LIKE '%SalesOrderID%'
        AND st.text NOT LIKE '%dm_exec_query_stats%';
GO

-- Restart clean!

DBCC DROPCLEANBUFFERS;
DBCC FREEPROCCACHE;
GO

-- Enable Optimize for Ad-Hoc Workloads

EXEC sp_configure 'optimize for ad hoc workloads', 1;
RECONFIGURE
GO

-- Run the query tool (Ad-Hoc)

-- Did this help?

SELECT  COUNT(*)
FROM    sys.dm_exec_query_stats qs
        CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle) AS st
WHERE   st.text LIKE '%SalesOrderID%';
GO

SELECT  SUM(cp.size_in_bytes) AS total_bytes
FROM    sys.dm_exec_query_stats qs
        JOIN sys.dm_exec_cached_plans cp ON cp.plan_handle = qs.plan_handle
        CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle) AS st
WHERE   st.text LIKE '%SalesOrderID%'
        AND st.text NOT LIKE '%dm_exec_query_stats%';
GO

-- Do it again now, and see the effect of stubs turning into full plans cached.

-- Do it a third time, and see the _actual_ benefits of cached plans.

-- Restart clean!

DBCC DROPCLEANBUFFERS;
DBCC FREEPROCCACHE;
GO

-- Disable Optimize for Ad-Hoc and Enable forced parameterization

EXEC sp_configure 'optimize for ad hoc workloads', 0;
RECONFIGURE

ALTER DATABASE AdventureWorks2014 SET PARAMETERIZATION FORCED;
GO

-- Check dat plan cache

SELECT  COUNT(*)
FROM    sys.dm_exec_query_stats qs
        CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle) AS st
WHERE   st.text LIKE '%SalesOrderID%';
GO

SELECT  SUM(cp.size_in_bytes) AS total_bytes
FROM    sys.dm_exec_query_stats qs
        JOIN sys.dm_exec_cached_plans cp ON cp.plan_handle = qs.plan_handle
        CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle) AS st
WHERE   st.text LIKE '%SalesOrderID%'
        AND st.text NOT LIKE '%dm_exec_query_stats%';
GO


-- Set it back to simple...

ALTER DATABASE AdventureWorks2014 SET PARAMETERIZATION SIMPLE;
GO

-- Let's look at stored procs now.

-- Start fresh! 

DBCC DROPCLEANBUFFERS;
DBCC FREEPROCCACHE;
GO

-- Run the query tool (stored procedure)

-- Run the same plan cache queries as above


SELECT  COUNT(*)
FROM    sys.dm_exec_query_stats qs
        CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle) AS st
WHERE   st.text LIKE '%SalesOrderID%';
GO


SELECT  SUM(cp.size_in_bytes) AS total_bytes
FROM    sys.dm_exec_query_stats qs
        JOIN sys.dm_exec_cached_plans cp ON cp.plan_handle = qs.plan_handle
        CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle) AS st
WHERE   st.text LIKE '%SalesOrderID%'
        AND st.text NOT LIKE '%dm_exec_query_stats%';
GO


