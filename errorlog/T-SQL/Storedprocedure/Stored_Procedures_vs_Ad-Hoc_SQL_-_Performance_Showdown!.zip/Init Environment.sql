RESTORE DATABASE AdventureWorks2014 FROM DISK = 'C:\Backups\AdventureWorks2014-Full Database Backup.bak'
WITH MOVE 'AdventureWorks2014_Data' TO 'C:\LocalDatabases\AdventureWorks2014_Data.mdf',
     MOVE 'AdventureWorks2014_Log' TO 'C:\LocalDatabases\AdventureWorks2014_log.ldf',
     RECOVERY,
     REPLACE,
     STATS = 5;
GO

USE AdventureWorks2014;
GO

CREATE PROC demo_Get_SalesOrder (@OrderID int) AS
SET NOCOUNT ON;

SELECT sh.[SalesOrderID]
      ,sh.[RevisionNumber]
      ,sh.[OrderDate]
      ,sh.[DueDate]
      ,sh.[ShipDate]
      ,sh.[Status]
      ,sh.[OnlineOrderFlag]
      ,sh.[SalesOrderNumber]
      ,sh.[PurchaseOrderNumber]
      ,sh.[AccountNumber]
      ,sh.[CustomerID]
      ,sh.[SalesPersonID]
      ,sh.[TerritoryID]
      ,sh.[BillToAddressID]
      ,sh.[ShipToAddressID]
      ,sh.[ShipMethodID]
      ,sh.[CreditCardID]
      ,sh.[CreditCardApprovalCode]
      ,sh.[CurrencyRateID]
      ,sh.[SubTotal]
      ,sh.[TaxAmt]
      ,sh.[Freight]
      ,sh.[TotalDue]
      ,sh.[Comment]
      ,sh.[rowguid]
      ,sh.[ModifiedDate]
	  ,sd.[SalesOrderID] AS SalesOrderID2
      ,sd.[SalesOrderDetailID]
      ,sd.[CarrierTrackingNumber]
      ,sd.[OrderQty]
      ,sd.[ProductID]
      ,sd.[SpecialOfferID]
      ,sd.[UnitPrice]
      ,sd.[UnitPriceDiscount]
      ,sd.[LineTotal]
      ,sd.[rowguid] AS rowguid2
      ,sd.[ModifiedDate] AS ModifiedDate2
	FROM Sales.SalesOrderHeader sh
	JOIN Sales.SalesOrderDetail sd
	ON sh.SalesOrderID = sd.SalesOrderID
	WHERE sh.SalesOrderID = @OrderID;
