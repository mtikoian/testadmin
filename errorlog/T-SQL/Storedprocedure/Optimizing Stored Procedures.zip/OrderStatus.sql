
/****** Object:  Stored Procedure dbo.CrystalRpt_Acct_037    Script Date: 01/04/2005 1:15:04 PM ******/
/*if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[OrderStatus]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[OrderStatus]*/
--GO


--CREATE        PROCEDURE dbo.[OrderStatus](
DEclare
	@sDate varchar(10),
	@eDate VARCHAR(10),
	@Customer_LastName varchar(150),
	@SalesPerson_LastName varchar(150)
--) AS

/*-------------------------------------------
Created By    :  Mark Rosenberg
Modified By   :  Mark Rosenberg
Date Created  :  07/28/2005
Date Modified :  
	Date  			Author				Comments
	07/28/2005		Mark Rosenberg		Created
---------------------------*/

SET @sDate = '01/01/2000'
SET @eDate = '12/31/2006'
SET @Customer_LastName = '%'
SET @SalesPerson_LastName = '%'

BEGIN

DECLARE @TEMP_1 TABLE
	(
	SalesOrderID INT,
	SalesOrderNumber VARCHAR(25),
	OrderDate VARCHAR(50),
	Customer_FirstName VARCHAR(100),
	Customer_MiddleName VARCHAR(100),
	Customer_LastName VARCHAR(100),
	DueDate VARCHAR(10),
	SalesPerson_FirstName VARCHAR(100),
	SalesPerson_LastName varchar(100)
	)

DECLARE @TEMP_2 TABLE
	(
	SalesID INT,
	PRINTED BIT,
	PRINTED_BY VARCHAR(50),
	PRINTED_DATE VARCHAR(50),
	SIGNED BIT,
	SIGNED_BY VARCHAR(50),
	SIGNED_DATE VARCHAR(50),
	BOXED BIT,
	BOXED_BY VARCHAR(50),
	BOXED_DATE VARCHAR(50),
	SHIPPED BIT,
	SHIPPED_BY VARCHAR(50),
	SHIPPED_DATE VARCHAR(50),
	RECEIVED BIT,
	RECEIVED_BY VARCHAR(50),
	RECEIVED_DATE VARCHAR(50)
	)

DECLARE @TEMP TABLE
	(
	SalesOrderID INT,
	SalesOrderNumber VARCHAR(25),
	OrderDate VARCHAR(50),
	Customer_FirstName VARCHAR(100),
	Customer_MiddleName VARCHAR(100),
	Customer_LastName VARCHAR(100),
	DueDate VARCHAR(10),
	SalesPerson_FirstName VARCHAR(100),
	SalesPerson_LastName varchar(100),
	SalesID INT,
	PRINTED BIT,
	PRINTED_BY VARCHAR(50),
	PRINTED_DATE VARCHAR(50),
	SIGNED BIT,
	SIGNED_BY VARCHAR(50),
	SIGNED_DATE VARCHAR(50),
	BOXED BIT,
	BOXED_BY VARCHAR(50),
	BOXED_DATE VARCHAR(50),
	SHIPPED BIT,
	SHIPPED_BY VARCHAR(50),
	SHIPPED_DATE VARCHAR(50),
	RECEIVED BIT,
	RECEIVED_BY VARCHAR(50),
	RECEIVED_DATE VARCHAR(50)
	)

DECLARE @PRINTED INT
SELECT @PRINTED = Type_Status_Id FROM Type_Status WHERE Description = 'Printed'

DECLARE	@SIGNED INT
SELECT @SIGNED = Type_Status_Id FROM Type_Status WHERE Description = 'Signed'

DECLARE	@BOXED INT
SELECT @BOXED = Type_Status_Id FROM Type_Status WHERE Description = 'Boxed'

DECLARE	@SHIPPED INT
SELECT @SHIPPED = Type_Status_Id FROM Type_Status WHERE Description = 'Shipped'

DECLARE	@RECEIVED INT
SELECT @RECEIVED = Type_Status_Id FROM Type_Status WHERE Description = 'Received'

INSERT INTO @TEMP_1
	(
	SalesOrderID,
	SalesOrderNumber,
	OrderDate,
	Customer_FirstName,
	Customer_MiddleName,
	Customer_LastName,
	DueDate,
	SalesPerson_FirstName,
	SalesPerson_LastName
	)
select SOH.SalesOrderID AS 'SalesOrderID', 
	SOH.SalesOrderNumber AS 'SalesOrderNumber',
	CONVERT(VARCHAR(10), SOH.OrderDate, 101) AS 'OrderDate',
	IsNull(IC.FirstName, '') AS 'Customer_FirstName',
	ISNULL(IC.MiddleName, '') AS 'Customer_MiddleName',
	ISNULL(IC.LastName, '') AS 'Customer_LastName',
	CONVERT(VARCHAR(10), SOH.DueDate, 101) AS 'DueDate',
	IsNull(SP.FirstName, '') AS 'SalesPerson_FirstName',
	ISNULL(SP.LastName, '') AS 'SalesPerson_LastName'
FROM Sales.SalesOrderHeader AS SOH
	LEFT OUTER JOIN Sales.vIndividualCustomer AS IC ON SOH.CustomerID = IC.CustomerID
	LEFT OUTER JOIN Sales.vSalesPerson AS SP ON SOH.SalesPersonID = SP.SalesPersonID
WHERE SOH.OrderDate BETWEEN convert(datetime, '1/1/1900') AND convert(datetime, '12/31/2006')
	--AND IsNull(IC.LastName, '') LIKE '%'--@Customer_LastName
	AND IsNull(SP.LastName, '') LIKE '%'--@SalesPerson_LastName

--select * from @temp_1

INSERT INTO @TEMP_2
	(
	SalesID,
	PRINTED,
	PRINTED_BY,
	PRINTED_DATE,
	SIGNED,
	SIGNED_BY,
	SIGNED_DATE,
	BOXED,
	BOXED_BY,
	BOXED_DATE,
	SHIPPED,
	SHIPPED_BY,
	SHIPPED_DATE,
	RECEIVED,
	RECEIVED_BY,
	RECEIVED_DATE
	)
SELECT 
	CASE
		WHEN OS_1.ACTIVE = 1 THEN OS_1.SalesOrderID
		WHEN OS_2.ACTIVE = 1 THEN OS_2.SalesOrderID
		WHEN OS_3.ACTIVE = 1 THEN OS_3.SalesOrderID
		WHEN OS_4.ACTIVE = 1 THEN OS_4.SalesOrderID
		WHEN OS_5.ACTIVE = 1 THEN OS_5.SalesOrderID
	END AS SalesID, 
	OS_1.ACTIVE AS PRINTED, 
	UPPER(OS_1.CREATE_BY) AS PRINTED_BY, 
	CONVERT(VARCHAR(10), OS_1.CREATE_DATE, 101) + ' ' + LEFT(RIGHT(CONVERT(VARCHAR(25), OS_1.CREATE_DATE, 0), 7), 5) + ' ' + RIGHT(CONVERT(VARCHAR(25), OS_1.CREATE_DATE, 0), 2) AS PRINTED_DATE, 
	OS_2.ACTIVE AS SIGNED, 
	UPPER(OS_2.CREATE_BY) AS SIGNED_BY, 
	CONVERT(VARCHAR(10), OS_2.CREATE_DATE, 101) + ' ' + LEFT(RIGHT(CONVERT(VARCHAR(25), OS_2.CREATE_DATE, 0), 7), 5) + ' ' + RIGHT(CONVERT(VARCHAR(25), OS_2.CREATE_DATE, 0), 2) AS SIGNED_DATE,
	OS_3.ACTIVE AS BOXED,
	UPPER(OS_3.CREATE_BY) AS BOXED_BY, 
	CONVERT(VARCHAR(10), OS_3.CREATE_DATE, 101) + ' ' + LEFT(RIGHT(CONVERT(VARCHAR(25), OS_3.CREATE_DATE, 0), 7), 5) + ' ' + RIGHT(CONVERT(VARCHAR(25), OS_3.CREATE_DATE, 0), 2) AS BOXED_DATE,
	OS_4.ACTIVE AS SHIPPED, 
	UPPER(OS_4.CREATE_BY) AS SHIPPED_BY, 
	CONVERT(VARCHAR(10), OS_4.CREATE_DATE, 101) + ' ' + LEFT(RIGHT(CONVERT(VARCHAR(25), OS_4.CREATE_DATE, 0), 7), 5) + ' ' + RIGHT(CONVERT(VARCHAR(25), OS_4.CREATE_DATE, 0), 2) AS SHIPPED_DATE,
	OS_5.ACTIVE AS RECEIVED, 
	UPPER(OS_5.CREATE_BY) AS RECEIVED_BY, 
	CONVERT(VARCHAR(10), OS_5.CREATE_DATE, 101) + ' ' + LEFT(RIGHT(CONVERT(VARCHAR(25), OS_5.CREATE_DATE, 0), 7), 5) + ' ' + RIGHT(CONVERT(VARCHAR(25), OS_5.CREATE_DATE, 0), 2) AS RECEIVED_DATE
FROM 
	(SELECT * FROM OrderStatus WHERE Type_Status_ID = @PRINTED AND ACTIVE = 1) AS OS_1
	LEFT OUTER JOIN (SELECT * FROM OrderStatus WHERE Type_Status_ID = @SIGNED AND ACTIVE = 1) AS OS_2 ON OS_1.ID = OS_2.ID
	LEFT OUTER JOIN (SELECT * FROM OrderStatus WHERE Type_Status_ID = @BOXED AND ACTIVE = 1) AS OS_3 ON OS_2.ID = OS_3.ID
	LEFT OUTER JOIN (SELECT * FROM OrderStatus WHERE Type_Status_ID = @SHIPPED AND ACTIVE = 1) AS OS_4 ON OS_3.ID = OS_4.ID
	LEFT OUTER JOIN (SELECT * FROM OrderStatus WHERE Type_Status_ID = @RECEIVED AND ACTIVE = 1) AS OS_5 ON OS_4.ID = OS_5.ID

--SELECT * FROM @TEMP_2

INSERT INTO @TEMP
SELECT DISTINCT * 
FROM @TEMP_1 AS Status_1 
	LEFT OUTER JOIN @TEMP_2 AS Status_2 ON Status_1.SalesOrderID = Status_2.SalesID

SELECT * FROM @TEMP


END

GO


--GRANT EXECUTE ON [OrderStatus] to [public]
--GO
