
/*-------------------------------------------
Created By    :  Mark Rosenberg
Modified By   :  Mark Rosenberg
Date Created  :  11/02/2006
Date Modified :  
	Date  			Author				Comments
	11/02/2006		Mark Rosenberg		Created
---------------------------*/

CREATE PROCEDURE TagsInsert(
	@Tag	[nvarchar](100),
	@Image	[image],
	@UrlId	[bigint],
	@TagId	[bigint] OUTPUT
) AS

BEGIN

	INSERT INTO Tags
	([Tag],
	[Image],
	[UrlId],
	[DateCreated],
	[DateModified])
	VALUES
	(@Tag,
	@Image,
	@UrlId,
	GetDate(),
	GetDate())

SET @TagId = @@IDENTITY

END

GO


