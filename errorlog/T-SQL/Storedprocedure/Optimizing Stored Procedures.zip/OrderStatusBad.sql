
/****** Object:  Stored Procedure dbo.CrystalRpt_Acct_037    Script Date: 01/04/2005 1:15:04 PM ******/
/*if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[OrderStatus]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[OrderStatus]*/
--GO


--CREATE        PROCEDURE dbo.[OrderStatus](
DEclare
	@sDate varchar(10),
	@eDate VARCHAR(10),
	@Customer_LastName varchar(150),
	@SalesPerson_LastName varchar(150)
--) AS

/*-------------------------------------------
Created By    :  Mark Rosenberg
Modified By   :  Mark Rosenberg
Date Created  :  07/28/2005
Date Modified :  
	Date  			Author				Comments
	07/28/2005		Mark Rosenberg		Created
---------------------------*/

SET @sDate = '01/01/2000'
SET @eDate = '12/31/2006'
SET @Customer_LastName = '%'
SET @SalesPerson_LastName = '%'

BEGIN

DECLARE @PRINTED INT
SELECT @PRINTED = Type_Status_Id FROM Type_Status WHERE Description = 'Printed'

DECLARE	@SIGNED INT
SELECT @SIGNED = Type_Status_Id FROM Type_Status WHERE Description = 'Signed'

DECLARE	@BOXED INT
SELECT @BOXED = Type_Status_Id FROM Type_Status WHERE Description = 'Boxed'

DECLARE	@SHIPPED INT
SELECT @SHIPPED = Type_Status_Id FROM Type_Status WHERE Description = 'Shipped'

DECLARE	@RECEIVED INT
SELECT @RECEIVED = Type_Status_Id FROM Type_Status WHERE Description = 'Received'

select SOH.SalesOrderID AS 'SalesOrderID', 
	SOH.SalesOrderNumber AS 'SalesOrderNumber',
	CONVERT(VARCHAR(10), SOH.OrderDate, 101) AS 'OrderDate',
	IsNull(IC.FirstName, '') AS 'Customer_FirstName',
	ISNULL(IC.MiddleName, '') AS 'Customer_MiddleName',
	ISNULL(IC.LastName, '') AS 'Customer_LastName',
	CONVERT(VARCHAR(10), SOH.DueDate, 101) AS 'DueDate',
	IsNull(SP.FirstName, '') AS 'SalesPerson_FirstName',
	ISNULL(SP.LastName, '') AS 'SalesPerson_LastName',
	(SELECT ACTIVE FROM OrderStatus WHERE Type_Status_ID = @PRINTED AND ACTIVE = 1 AND SalesOrderId = SOH.SalesOrderID) AS PRINTED, 
	(SELECT UPPER(CREATE_BY) FROM OrderStatus WHERE Type_Status_ID = @PRINTED AND ACTIVE = 1 AND SalesOrderId = SOH.SalesOrderID) AS PRINTED_BY, 
	(SELECT CONVERT(VARCHAR(10), CREATE_DATE, 101) + ' ' + LEFT(RIGHT(CONVERT(VARCHAR(25), CREATE_DATE, 0), 7), 5) + ' ' + RIGHT(CONVERT(VARCHAR(25), CREATE_DATE, 0), 2) FROM OrderStatus WHERE Type_Status_ID = @PRINTED AND ACTIVE = 1 AND SalesOrderId = SOH.SalesOrderID) AS PRINTED_DATE, 
	(SELECT ACTIVE FROM OrderStatus WHERE Type_Status_ID = @SIGNED AND ACTIVE = 1 AND SalesOrderId = SOH.SalesOrderID) AS SIGNED, 
	(SELECT UPPER(CREATE_BY) FROM OrderStatus WHERE Type_Status_ID = @SIGNED AND ACTIVE = 1 AND SalesOrderId = SOH.SalesOrderID) AS SIGNEDD_BY, 
	(SELECT CONVERT(VARCHAR(10), CREATE_DATE, 101) + ' ' + LEFT(RIGHT(CONVERT(VARCHAR(25), CREATE_DATE, 0), 7), 5) + ' ' + RIGHT(CONVERT(VARCHAR(25), CREATE_DATE, 0), 2) FROM OrderStatus WHERE Type_Status_ID = @SIGNED AND ACTIVE = 1 AND SalesOrderId = SOH.SalesOrderID) AS SIGNED_DATE, 
	(SELECT ACTIVE FROM OrderStatus WHERE Type_Status_ID = @BOXED AND ACTIVE = 1 AND SalesOrderId = SOH.SalesOrderID) AS BOXED, 
	(SELECT UPPER(CREATE_BY) FROM OrderStatus WHERE Type_Status_ID = @BOXED AND ACTIVE = 1 AND SalesOrderId = SOH.SalesOrderID) AS BOXED_BY, 
	(SELECT CONVERT(VARCHAR(10), CREATE_DATE, 101) + ' ' + LEFT(RIGHT(CONVERT(VARCHAR(25), CREATE_DATE, 0), 7), 5) + ' ' + RIGHT(CONVERT(VARCHAR(25), CREATE_DATE, 0), 2) FROM OrderStatus WHERE Type_Status_ID = @BOXED AND ACTIVE = 1 AND SalesOrderId = SOH.SalesOrderID) AS BOXED_DATE, 
	(SELECT ACTIVE FROM OrderStatus WHERE Type_Status_ID = @SHIPPED AND ACTIVE = 1 AND SalesOrderId = SOH.SalesOrderID) AS SHIPPED, 
	(SELECT UPPER(CREATE_BY) FROM OrderStatus WHERE Type_Status_ID = @SHIPPED AND ACTIVE = 1 AND SalesOrderId = SOH.SalesOrderID) AS SHIPPED_BY, 
	(SELECT CONVERT(VARCHAR(10), CREATE_DATE, 101) + ' ' + LEFT(RIGHT(CONVERT(VARCHAR(25), CREATE_DATE, 0), 7), 5) + ' ' + RIGHT(CONVERT(VARCHAR(25), CREATE_DATE, 0), 2) FROM OrderStatus WHERE Type_Status_ID = @SHIPPED AND ACTIVE = 1 AND SalesOrderId = SOH.SalesOrderID) AS SHIPPED_DATE, 
	(SELECT ACTIVE FROM OrderStatus WHERE Type_Status_ID = @RECEIVED AND ACTIVE = 1 AND SalesOrderId = SOH.SalesOrderID) AS RECEIVED, 
	(SELECT UPPER(CREATE_BY) FROM OrderStatus WHERE Type_Status_ID = @RECEIVED AND ACTIVE = 1 AND SalesOrderId = SOH.SalesOrderID) AS RECEIVED_BY, 
	(SELECT CONVERT(VARCHAR(10), CREATE_DATE, 101) + ' ' + LEFT(RIGHT(CONVERT(VARCHAR(25), CREATE_DATE, 0), 7), 5) + ' ' + RIGHT(CONVERT(VARCHAR(25), CREATE_DATE, 0), 2) FROM OrderStatus WHERE Type_Status_ID = @RECEIVED AND ACTIVE = 1 AND SalesOrderId = SOH.SalesOrderID) AS RECEIVED_DATE
FROM Sales.SalesOrderHeader AS SOH
	LEFT OUTER JOIN Sales.vIndividualCustomer AS IC ON SOH.CustomerID = IC.CustomerID
	LEFT OUTER JOIN Sales.vSalesPerson AS SP ON SOH.SalesPersonID = SP.SalesPersonID
WHERE SOH.OrderDate BETWEEN convert(datetime, @sDate) AND convert(datetime, @eDate)
	AND IsNull(IC.LastName, '') LIKE @Customer_LastName
	AND IsNull(SP.LastName, '') LIKE @SalesPerson_LastName
ORDER BY SalesOrderId

END

GO


--GRANT EXECUTE ON [OrderStatus] to [public]
--GO
