Use NorthWind
go
create table records (ID int identity NOT NULL, MyField varchar(10))
create table audittable (ID int NOT NULL, MyFieldOrig varchar(10), MyFieldNew varchar(10), recdate datetime)
go

insert records values ('aaa')
insert records values ('bbb')
insert records values ('ccc')

select * from records

create trigger dbo.badrecordaudit on records for update as
DECLARE @id int, @mycharorig varchar(10), @mycharnew varchar(10)

SELECT @id = i.ID, @myCharorig = d.myfield, @mycharnew = i.myfield
  FROM INSERTED i inner join DELETED d on d.ID = i.ID

INSERT AuditTable
VALUES (@id, @myCharorig, @mycharnew, getdate())
GO


update records
set myfield = 'zzz'
where id <= 2

select * from records

select * from audittable

drop trigger dbo.badrecordaudit
go

create trigger dbo.goodrecordaudit on records for update as
--SET-based approach to ensure get ALL records affected!

INSERT AuditTable
SELECT i.ID, d.myfield, i.myfield, getdate()
  FROM INSERTED i inner join DELETED d on d.ID = i.ID

--error handling?? :-)
GO

update records
set myfield = '123'
where id >= 2

select * from records

select * from audittable

drop table records
drop table audittable
