Use tempdb
set nocount on
go

IF OBJECT_ID(N'Accounts', N'U') IS NOT NULL
   DROP TABLE Accounts;
   
CREATE TABLE Accounts (
 account_nbr INT NOT NULL PRIMARY KEY,
 account_type VARCHAR(20) NOT NULL 
 CHECK (account_type IN ('Personal', 'Business Basic', 'Business Plus')),
 account_reference VARCHAR(30) NOT NULL);
 
INSERT INTO Accounts VALUES(1, 'Personal', 'abc');
INSERT INTO Accounts VALUES(2, 'Business Basic', '101');
INSERT INTO Accounts VALUES(3, 'Personal', 'def');
INSERT INTO Accounts VALUES(4, 'Business Plus', '5'); 

SELECT account_nbr, account_type, account_reference
FROM Accounts;

/*

account_nbr account_type    account_reference
----------- --------------- -----------------
1           Personal        abc
2           Business Basic  101
3           Personal        def
4           Business Plus   5

*/

-- uncomment the following query to see the error
/*

SELECT account_nbr, account_reference AS account_ref_nbr
FROM Accounts
WHERE account_type LIKE 'Business%'
  AND CAST(account_reference AS INT) > 20;

*/


/*

StmtText
----------------------------------------------------------------------------------------------
  |--Clustered Index Scan(OBJECT:([Testing].[dbo].[Accounts].[PK__Accounts__49DA791725B97030]), 
  WHERE:(CONVERT(int,[Testing].[dbo].[Accounts].[account_reference],0)>(20) 
    AND [Testing].[dbo].[Accounts].[account_type] like 'Business%'))


*/

/*

Error:
Conversion failed when converting the varchar value 'abc' to data type int.

*/

-- uncomment the following query to see the error

/*

SELECT account_nbr, account_ref_nbr
FROM (SELECT account_nbr, 
             CAST(account_reference AS INT) AS account_ref_nbr
      FROM Accounts
      WHERE account_type LIKE 'Business%') AS A
WHERE account_ref_nbr > 20;

*/

/*

Error:
Conversion failed when converting the varchar value 'abc' to data type int.

*/

SELECT account_nbr, account_reference AS account_ref_nbr
FROM Accounts
WHERE account_type LIKE 'Business%'
  AND CASE WHEN account_reference NOT LIKE '%[^0-9]%' 
           THEN CAST(account_reference AS INT)
      END > 20;
   
/*

account_nbr account_ref_nbr
----------- ----------------
2           101

*/
 
DROP TABLE Accounts;