use tempdb
set nocount on
go


IF OBJECT_ID(N'Colors', N'U') IS NOT NULL
   DROP TABLE Colors;
   
CREATE TABLE Colors (
 color VARCHAR(10) NOT NULL PRIMARY KEY);
 
INSERT INTO Colors VALUES('Blue');
INSERT INTO Colors VALUES('Red');
INSERT INTO Colors VALUES('Green');
INSERT INTO Colors VALUES('Black');

SELECT color FROM Colors;

/*

color
----------
Black
Blue
Green
Red

*/

IF OBJECT_ID(N'Products', N'U') IS NOT NULL
   DROP TABLE Products;

CREATE TABLE Products (
 sku INT NOT NULL PRIMARY KEY,
 product_description VARCHAR(30) NOT NULL,
 color VARCHAR(10));
 
INSERT INTO Products VALUES(1, 'Ball', 'Red');
INSERT INTO Products VALUES(2, 'Bike', 'Blue');
INSERT INTO Products VALUES(3, 'Tent', NULL);

SELECT sku, product_description, color
FROM Products;

/*

sku  product_description  color
---- -------------------- ------
1    Ball                 Red
2    Bike                 Blue
3    Tent                 NULL

*/


SELECT C.color
FROM Colors AS C
WHERE C.color NOT IN (SELECT P.color 
                      FROM Products AS P);

/*

color
----------

(0 row(s) affected)

*/

/* EXISTS */
SELECT C.color
FROM Colors AS C
WHERE NOT EXISTS(SELECT * 
                 FROM Products AS P
                 WHERE C.color = P.color);

/*

color
----------
Black
Green

*/


/* IS NOT NULL in the subquery */
SELECT C.color
FROM Colors AS C
WHERE C.color NOT IN (SELECT P.color 
                      FROM Products AS P 
                      WHERE P.color IS NOT NULL);

/* EXCEPT */
SELECT color
FROM Colors
EXCEPT
SELECT color
FROM Products;

/* LEFT OUTER JOIN */
SELECT C.color
FROM Colors AS C
LEFT OUTER JOIN Products AS P
  ON C.color = P.color
WHERE P.color IS NULL;
  
DROP TABLE Colors, Products; 
 
 