Use tempdb
set nocount on
go

IF OBJECT_ID(N'Sales', N'U') IS NOT NULL
   DROP TABLE Sales;

CREATE TABLE Sales (
 transaction_nbr INT NOT NULL PRIMARY KEY,
 sale_date DATETIME NOT NULL,
 sale_amount DECIMAL(15, 2) NOT NULL);

IF OBJECT_ID(N'Calendar', N'U') IS NOT NULL
   DROP TABLE Calendar;

CREATE TABLE Calendar (
 calendar_date DATETIME NOT NULL PRIMARY KEY,
 holiday_name VARCHAR(30));

INSERT INTO Sales VALUES(1, '20090101', 120.50);
INSERT INTO Sales VALUES(2, '20090102', 115.00);
INSERT INTO Sales VALUES(3, '20090103', 140.80);
INSERT INTO Sales VALUES(4, '20090104', 100.50);

/*

sale_date  sale_amount
---------- -----------
2009-01-01 120.50
2009-01-02 115.00
2009-01-03 140.80
2009-01-04 100.50

*/

INSERT INTO Calendar VALUES('20090101', 'New Year''s Day');
INSERT INTO Calendar VALUES('20090102', NULL);
INSERT INTO Calendar VALUES('20090103', NULL);
INSERT INTO Calendar VALUES('20090104', NULL);
INSERT INTO Calendar VALUES('20090105', NULL);

SELECT calendar_date, holiday_name
FROM Calendar;

/*

calendar_date holiday_name
------------- ---------------
2009-01-01    New Year's Day
2009-01-02    NULL
2009-01-03    NULL
2009-01-04    NULL
2009-01-05    NULL

*/


SELECT sale_date, sale_amount
FROM Sales AS S
WHERE sale_date IN (SELECT sale_date
                    FROM Calendar AS C
                    WHERE holiday_name IS NOT NULL);

/*

sale_date  sale_amount
---------- -----------
2009-01-01 120.50
2009-01-02 115.00
2009-01-03 140.80
2009-01-04 100.50

*/

/*

Error: Invalid column name 'sale_date'.

SELECT sale_date, sale_amount
FROM Sales AS S
WHERE sale_date IN (SELECT C.sale_date
                    FROM Calendar AS C
                    WHERE holiday_name IS NOT NULL);

*/

SELECT s.sale_date, s.sale_amount
FROM Sales AS S
WHERE sale_date IN (SELECT C.calendar_date
                    FROM Calendar AS C
                    WHERE C.holiday_name IS NOT NULL);

/*

sale_date  sale_amount
---------- -----------
2009-01-01 120.50

*/

DROP TABLE Sales;
DROP TABLE Calendar;
