use timeplus
set nocount on 
go
--drop table KGBIsNULLORTest 

create table KGBIsNULLORTest (a int, b int, c char(50))

insert KGBIsNULLORTest 
select Number, Number % 2000, 'dummy data'
from dbatools.dbo.Numbers
where Number < 10000

create index idxa on KGBIsNULLORTest (a)
go
create index idxb on KGBIsNULLORTest (b)
go

create proc badIsNULLORProc (@a int, @b int)
AS
SET NOCOUNT ON

SELECT a, b, c
  FROM dbo.KGBIsNULLORTest 
 WHERE (@a = a OR @a IS NULL)
   AND (@b = b OR @b IS NULL)
RETURN

--show actual query plan
set statistics IO on

dbcc freeproccache
go
exec badIsNULLORProc NULL, NULL --this uses optimal table scan 84 READS
exec badIsNULLORProc 1, NULL    --this uses same table scan, but now suboptimal 84 READS
exec badIsNULLORProc NULL, 1    --this uses same table scan, but now suboptimal 84 READS
exec badIsNULLORProc 1, 1       --this uses same table scan, but now suboptimal 84 READS

dbcc freeproccache
go
exec badIsNULLORProc 1, 1       --this plan uses suboptimal index scan(instead of seek)/lookup for 26 READS
exec badIsNULLORProc 1, NULL    --this plan uses suboptimal index scan(instead of seek)/lookup for 26 READS
exec badIsNULLORProc NULL, 1    --this uses same, now HORRIBLE, index scan/lookup and takes 10024 READS!
exec badIsNULLORProc NULL, NULL --this uses same, now HORRIBLE, index scan/lookup and takes 10024 READS!

create proc BetterIsNullORProc (@a int, @b int)
as
SET NOCOUNT ON

IF @a IS NOT NULL AND @b IS NOT NULL
BEGIN
   SELECT a, b
     FROM dbo.KGBIsNULLORTest 
    WHERE @a = a
      AND @b = b
END
ELSE
BEGIN
   IF @a IS NULL AND @b IS NOT NULL
   BEGIN
      SELECT a, b
        FROM dbo.KGBIsNULLORTest 
       WHERE @b = b
   END
   ELSE
   BEGIN
      IF @a IS NOT NULL AND @b IS NULL
      BEGIN
         SELECT a, b
           FROM dbo.KGBIsNULLORTest 
          WHERE @a = a
      END
      ELSE
      BEGIN
         SELECT a, b
           FROM dbo.KGBIsNULLORTest 
      END
   END      
END

dbcc freeproccache
go
exec BetterIsNullORProc NULL, NULL 
exec BetterIsNullORProc 1, NULL    
exec BetterIsNullORProc NULL, 1
exec BetterIsNullORProc 1, 1    

dbcc freeproccache
go
exec BetterIsNullORProc 1, 1    
exec BetterIsNullORProc NULL, 1 
exec BetterIsNullORProc 1, NULL 
exec BetterIsNullORProc NULL, NULL 

dbcc freeproccache
go
exec BetterIsNullORProc NULL, 1 
exec BetterIsNullORProc 1, NULL
exec BetterIsNullORProc 1, 1    
exec BetterIsNullORProc NULL, NULL 

dbcc freeproccache
go
exec BetterIsNullORProc 1, NULL
exec BetterIsNullORProc NULL, 1 
exec BetterIsNullORProc 1, 1    
exec BetterIsNullORProc NULL, NULL 
