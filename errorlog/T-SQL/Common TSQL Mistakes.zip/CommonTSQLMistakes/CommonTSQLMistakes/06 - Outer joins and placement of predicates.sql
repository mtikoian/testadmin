Use tempdb
set nocount on
go

IF OBJECT_ID(N'Customers', N'U') IS NOT NULL
   DROP TABLE Customers;
   
CREATE TABLE Customers (
 customer_nbr INT NOT NULL PRIMARY KEY,
 customer_name VARCHAR(35) NOT NULL);
 
INSERT INTO Customers VALUES(1, 'Jim Brown');
INSERT INTO Customers VALUES(2, 'Jeff Gordon');
INSERT INTO Customers VALUES(3, 'Peter Green');
INSERT INTO Customers VALUES(4, 'Julie Peters');

SELECT customer_nbr, customer_name FROM Customers;

/*

customer_nbr customer_name
------------ --------------
1            Jim Brown
2            Jeff Gordon
3            Peter Green
4            Julie Peters

*/

IF OBJECT_ID(N'Orders', N'U') IS NOT NULL
   DROP TABLE Orders;

CREATE TABLE Orders (
 order_nbr INT NOT NULL PRIMARY KEY,
 order_date DATETIME NOT NULL,
 customer_nbr INT NOT NULL REFERENCES Customers(customer_nbr),
 order_amt DECIMAL(10, 2) NOT NULL);
 
INSERT INTO Orders VALUES(1, '20081001', 1, 15.50); 
INSERT INTO Orders VALUES(2, '20081215', 2, 25.00);
INSERT INTO Orders VALUES(3, '20090102', 1, 18.00);
INSERT INTO Orders VALUES(4, '20090220', 3, 10.25);
INSERT INTO Orders VALUES(5, '20090305', 1, 30.00);

SELECT order_nbr, order_date, customer_nbr, order_amt FROM Orders;

/*

order_nbr   order_date customer_nbr order_amt
----------- ---------- ------------ ----------
1           2008-10-01 1            15.50
2           2008-12-15 2            25.00
3           2009-01-02 1            18.00
4           2009-02-20 3            10.25
5           2009-03-05 1            30.00

*/

-- Incorrect filtering in WHERE
SELECT C.customer_name, SUM(COALESCE(O.order_amt, 0)) AS total_2009
FROM Customers AS C
LEFT OUTER JOIN Orders AS O
  ON C.customer_nbr = O.customer_nbr
WHERE O.order_date >= '20090101'
GROUP BY C.customer_name;  
 
/*

customer_name  total_2009
-------------- ------------
Jim Brown      48.00
Peter Green    10.25

*/

-- step 1: cross join (Cartesian product)
SELECT C.customer_name, O.order_amt, O.order_date
FROM Customers AS C
CROSS JOIN Orders AS O;
 
/*

customer_name    order_amt  order_date
---------------- ---------- ----------
Jim Brown        15.50      2008-10-01
Jim Brown        25.00      2008-12-15
Jim Brown        18.00      2009-01-02
Jim Brown        10.25      2009-02-20
Jim Brown        30.00      2009-03-05
Jeff Gordon      15.50      2008-10-01
Jeff Gordon      25.00      2008-12-15
Jeff Gordon      18.00      2009-01-02
Jeff Gordon      10.25      2009-02-20
Jeff Gordon      30.00      2009-03-05
Peter Green      15.50      2008-10-01
Peter Green      25.00      2008-12-15
Peter Green      18.00      2009-01-02
Peter Green      10.25      2009-02-20
Peter Green      30.00      2009-03-05
Julie Peters     15.50      2008-10-01
Julie Peters     25.00      2008-12-15
Julie Peters     18.00      2009-01-02
Julie Peters     10.25      2009-02-20
Julie Peters     30.00      2009-03-05

*/

-- step 2: ON predicates
SELECT C.customer_name, O.order_amt, O.order_date
FROM Customers AS C
INNER JOIN Orders AS O
   ON C.customer_nbr = O.customer_nbr;

/*

customer_name  order_amt  order_date
-------------- ---------- ----------
Jim Brown      15.50      2008-10-01
Jeff Gordon    25.00      2008-12-15
Jim Brown      18.00      2009-01-02
Peter Green    10.25      2009-02-20
Jim Brown      30.00      2009-03-05

*/
   
-- step 3: add OUTER rows
SELECT C.customer_name, O.order_amt, O.order_date
FROM Customers AS C
LEFT OUTER JOIN Orders AS O
   ON C.customer_nbr = O.customer_nbr;
      
/*

customer_name  order_amt  order_date
-------------- ---------- ----------
Jim Brown      15.50      2008-10-01
Jim Brown      18.00      2009-01-02
Jim Brown      30.00      2009-03-05
Jeff Gordon    25.00      2008-12-15
Peter Green    10.25      2009-02-20
Julie Peters   NULL       NULL

*/
    
-- step 4: WHERE predicates
SELECT C.customer_name, O.order_amt, O.order_date
FROM Customers AS C
LEFT OUTER JOIN Orders AS O
   ON C.customer_nbr = O.customer_nbr
WHERE O.order_date >= '20090101';

/*

customer_name  order_amt  order_date
-------------- ---------- ----------
Jim Brown      18.00      2009-01-02
Peter Green    10.25      2009-02-20
Jim Brown      30.00      2009-03-05

*/
         
-- Correct predicate in join conditions
SELECT C.customer_name, SUM(COALESCE(O.order_amt, 0)) AS total_2009
FROM Customers AS C
LEFT OUTER JOIN Orders AS O
  ON C.customer_nbr = O.customer_nbr
 AND O.order_date >= '20090101'
GROUP BY C.customer_name;  

/*

customer_name  total_2009
-------------- ------------
Jeff Gordon    0.00
Jim Brown      48.00
Julie Peters   0.00
Peter Green    10.25

*/

IF OBJECT_ID(N'OrderDetails', N'U') IS NOT NULL
   DROP TABLE OrderDetails;

CREATE TABLE OrderDetails (
 order_nbr INT NOT NULL REFERENCES Orders(order_nbr),
 sku INT NOT NULL,
 qty INT NOT NULL,
 PRIMARY KEY(order_nbr, sku));

INSERT INTO OrderDetails VALUES(1, 101, 5); 
INSERT INTO OrderDetails VALUES(2, 102, 10); 
INSERT INTO OrderDetails VALUES(3, 103, 100); 
INSERT INTO OrderDetails VALUES(4, 104, 20); 
INSERT INTO OrderDetails VALUES(5, 105, 19); 
INSERT INTO OrderDetails VALUES(1, 110, 10); 
 
-- incorrect: the INNER JOIN transforms the OUTER JOIN to INNER JOIN 
SELECT C.customer_name, O.order_amt, D.qty
FROM Customers AS C
LEFT OUTER JOIN Orders AS O
  ON C.customer_nbr = O.customer_nbr
INNER JOIN OrderDetails AS D
  ON D.order_nbr = O.order_nbr
 AND D.sku = 101;   

/*

customer_name  order_amt  qty
-------------- ---------- ----
Jim Brown      15.50      5

*/

-- Correct with OUTER join
SELECT C.customer_name, O.order_amt, D.qty
FROM Customers AS C
LEFT OUTER JOIN Orders AS O
  ON C.customer_nbr = O.customer_nbr
LEFT OUTER JOIN OrderDetails AS D
  ON D.order_nbr = O.order_nbr
 AND D.sku = 101;   
 
/*

customer_name  order_amt  qty
-------------- ---------- ------
Jim Brown      15.50      5
Jim Brown      18.00      NULL
Jim Brown      30.00      NULL
Jeff Gordon    25.00      NULL
Peter Green    10.25      NULL
Julie Peters   NULL       NULL

*/

DROP TABLE OrderDetails;
DROP TABLE Orders;
DROP TABLE Customers; 
