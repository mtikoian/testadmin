Use tempdb
set nocount on
go

IF OBJECT_ID(N'Products', N'U') IS NOT NULL
   DROP TABLE Products;

CREATE TABLE Products (
 sku INT NOT NULL PRIMARY KEY,
 product_description VARCHAR(35) NOT NULL);

IF OBJECT_ID(N'ProductPlants', N'U') IS NOT NULL
   DROP TABLE ProductPlants;
    
CREATE TABLE ProductPlants (
 sku INT NOT NULL,
 plant_nbr INT NOT NULL,
 PRIMARY KEY (sku, plant_nbr));
 
INSERT INTO Products VALUES(1, 'Bike');
INSERT INTO Products VALUES(2, 'Ball');
INSERT INTO Products VALUES(3, 'Phone');

SELECT sku, product_description FROM Products;

/*

sku   product_description
----- -------------------
1     Bike
2     Ball
3     Phone

*/

INSERT INTO ProductPlants VALUES(1, 1);
INSERT INTO ProductPlants VALUES(2, 1);
INSERT INTO ProductPlants VALUES(3, 2);

SELECT sku, plant_nbr FROM ProductPlants;
/*

sku   plant_nbr
----- -----------
1     1
2     1
3     2

*/

SELECT sku, product_description,
      (SELECT plant_nbr
       FROM ProductPlants AS B
       WHERE B.sku = A.sku) AS plant_nbr
FROM Products AS A;

/*


sku  product_description plant_nbr
---- ------------------- -----------
1    Bike                1
2    Ball                1
3    Phone               2

*/

INSERT INTO ProductPlants VALUES(2, 3);

SELECT sku, plant_nbr FROM ProductPlants;

/*

sku   plant_nbr
----- -----------
1     1
2     1
2     3
3     2

*/

/*

-- Query will produce error
SELECT sku, product_description,
      (SELECT plant_nbr
       FROM ProductPlants AS B
       WHERE B.sku = A.sku) AS plant_nbr
FROM Products AS A;

*/

/*

Subquery returned more than 1 value. This is not permitted when the subquery follows =, !=, <, <= , >, >= or when the subquery is used as an expression.

*/

SELECT A.sku, A.product_description, B.plant_nbr
FROM Products AS A
JOIN ProductPlants AS B
  ON A.sku = B.sku;

/*

sku  product_description  plant_nbr
---- -------------------- -----------
1    Bike                 1
2    Ball                 1
2    Ball                 3
3    Phone                2

*/

/*

Same problem in WHERE clause: use IN, JOIN, EXISTS to solve

SELECT A.sku, A.product_description, B.plant_nbr
FROM Products AS A
JOIN ProductPlants AS B
  ON A.sku = B.sku
WHERE B.sku = (SELECT C.sku  --this query MUST return one row MAX
               FROM Products AS C
               WHERE C.product_description LIKE '%ball%');
               
*/
  

DROP TABLE Products, ProductPlants;
