/* 
	Which table does this query from?
*/
SELECT *
FROM Ben
GO

EXECUTE AS user='testlogin'
GO

SELECT *
FROM Ben
GO

REVERT
