use Northwind
go

/*

CREATE FUNCTION [dbo].[fn_TotalPrice] (@OrderID int)
RETURNS money WITH SCHEMABINDING
AS 
BEGIN
   DECLARE @result money
   SELECT @result = SUM(UnitPrice * Quantity) FROM dbo.[Order Details] WHERE OrderID = @OrderID
   RETURN @result
END

ALTER PROC [dbo].[UDFsAreBad]
AS
SET NOCOUNT ON
SELECT c.CompanyName, o.OrderDate, SUM(dbo.fn_TotalPrice(o.OrderID)) as TotalPrice
  FROM dbo.Orders o
 INNER JOIN dbo.Customers C ON O.CustomerID = c.CustomerID
 WHERE dbo.fn_TotalPrice(o.OrderID) > 10
 GROUP BY c.CompanyName, o.OrderDate
 ORDER BY c.CompanyName, o.OrderDate

*/

--show actual execution plan, IO stats first then statement-level profiler trace
SET STATISTICS IO OFF

EXEC dbo.UDFsAreBad

/*
--compare this to Profiler!!
Table 'Worktable'. Scan count 0, logical reads 0, physical reads 0, read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.
Table 'Order Details'. Scan count 1, logical reads 5, physical reads 0, read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.
Table 'Orders'. Scan count 1, logical reads 22, physical reads 0, read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.
Table 'Customers'. Scan count 1, logical reads 2, physical reads 0, read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.

NOTE: 1662 rows in profiler on statement level trace!!!
*/

--INLINE Table Function, using CROSS APPLY (There are some VERY interesting uses for CROSS APPLY! Search SSC.com for Paul White's stuff)

ALTER FUNCTION [dbo].[fn_TotalPrice_TVF] (@OrderID int)
RETURNS TABLE WITH SCHEMABINDING 
AS 
   RETURN SELECT SUM(UnitPrice * Quantity) AS TotalPrice 
            FROM dbo.[Order Details] 
           WHERE OrderID = @OrderID

ALTER PROC [dbo].[TVFsAreBetter]
AS
SET NOCOUNT ON
SELECT c.CompanyName, o.OrderDate, SUM(fn.TotalPrice) AS TotalPrice
  FROM dbo.Orders o
 INNER JOIN dbo.Customers C ON o.CustomerID = c.CustomerID
 CROSS APPLY dbo.fn_TotalPrice_TVF(o.OrderID) as fn
 GROUP BY c.CompanyName,  o.OrderDate
HAVING SUM(dbo.fn_totalprice(o.OrderID)) > 10
 ORDER BY c.CompanyName, o.OrderDate

EXEC dbo.TVFsAreBetter

/*
--compare this to Profiler!!
Table 'Worktable'. Scan count 0, logical reads 0, physical reads 0, read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.
Table 'Orders'. Scan count 1, logical reads 22, physical reads 0, read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.
Table 'Customers'. Scan count 1, logical reads 2, physical reads 0, read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.

NOTE: 832 rows in profiler on statement level trace!
*/

--BEST though is a SET-BASED SOLUTION!!

SELECT c.CompanyName, o.OrderDate, SUM(od.UnitPrice*od.Quantity) as TotalPrice
  FROM dbo.Orders o
 INNER JOIN dbo.[Order Details] od ON o.OrderID = od.OrderID
 INNER JOIN dbo.Customers c ON o.CustomerID = c.CustomerID
 GROUP BY CompanyName,  OrderDate
HAVING SUM(od.UnitPrice*od.Quantity) > 10
 ORDER BY c.CompanyName, o.OrderDate

/* THIS is actually representative of what profiler says REALLY happened!
Table 'Worktable'. Scan count 0, logical reads 0, physical reads 0, read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.
Table 'Order Details'. Scan count 1, logical reads 11, physical reads 0, read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.
Table 'Orders'. Scan count 1, logical reads 22, physical reads 0, read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.
Table 'Customers'. Scan count 1, logical reads 2, physical reads 0, read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.

NOTE: ONE roww in profiler on statement level trace!!!
*/

/* KEY TAKEAWAY

   Just don't use UDFs if at all possible. This sample just touches on the ways they can harm you 
   
*/

