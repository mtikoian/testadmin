SET STATISTICS IO ON; 
SET STATISTICS TIME ON; 

--What does a self-referencing table look like, anyway?  
SELECT GenreKey, ParentGenreKey, GenreName
FROM Genre

/*Show Genre and Immediate Parent Genre Names*/
--Old School (remember - occasionally, old school is the best school)
SELECT pg.GenreKey as ParentGenreKey, pg.GenreName as ParentGenreName, cg.GenreKey, cg.GenreName
FROM Genre cg
	LEFT JOIN Genre pg
		ON cg.ParentGenreKey = pg.GenreKey
ORDER BY GenreName;

	--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

--New School
WITH GenreHierarchy 																													--Define/Name your CTE
AS
(
	SELECT ParentGenreKey, cast('' as varchar(100)) as ParentGenreName, GenreKey, GenreName			--ANCHOR MEMBER - Give it a starting point... top of the chain, where node has no parent
	FROM Genre
	WHERE ParentGenreKey IS NULL																									
		UNION ALL																																--UNION ALL working in wondrous ways
	SELECT gh.GenreKey, gh.GenreName, g.GenreKey, g.GenreName		
	FROM Genre g																
		JOIN GenreHierarchy gh																									--RECURSIVE MEMBER - Join the bottom query back to the top query in the UNION ALL - This is how it knows to get recursive
			ON g.ParentGenreKey = gh.GenreKey
)

SELECT ParentGenreKey, ParentGenreName, GenreKey, GenreName													--SELECT the results of the CTE
FROM GenreHierarchy; 

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
/* Show Hierarchy Level relative to the starting point */
--Old School
PRINT 'Old School'; 

DECLARE @GenreLevel TABLE
	(
	 ParentGenreKey int 
	,ParentGenreName varchar(100)
	,GenreKey int
	,GenreName varchar(100)
	,GenreLevel tinyint								--include a column for the relative hierarchy level
	)

--Grab all nodes
INSERT INTO @GenreLevel(ParentGenreKey, ParentGenreName, GenreKey, GenreName, GenreLevel)
SELECT ParentGenreKey, NULL, GenreKey, GenreName, NULL as GenreLevel
FROM Genre

--Update Level 0 - starting point
UPDATE @GenreLevel
SET GenreLevel = 0
WHERE ParentGenreKey IS NULL

--Loop trough to set subsequent hierarchy levels
WHILE (SELECT COUNT(*) FROM @GenreLevel WHERE GenreLevel IS NULL) > 0

BEGIN

	UPDATE c 
	SET c.GenreLevel = (SELECT MAX(GenreLevel)+1 FROM @GenreLevel)
		,c.ParentGenreName = p.GenreName
	FROM @GenreLevel p
		JOIN @GenreLevel c
			ON p.GenreKey = c.ParentGenreKey
	WHERE p.GenreLevel = (SELECT MAX(GenreLevel) FROM @GenreLevel)

END

--Select results
SELECT ParentGenreKey, ParentGenreName, GenreKey, GenreName, GenreLevel
FROM @GenreLevel
ORDER BY GenreLevel, GenreName; 

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

--New School
PRINT 'New School'; 

WITH GenreLevel as (
	SELECT ParentGenreKey, cast('' as varchar(100)) as ParentGenreName, GenreKey, GenreName, 0 as GenreLevel
	FROM Genre
	WHERE ParentGenreKey IS NULL
UNION ALL
	SELECT gh.GenreKey, gh.GenreName, g.GenreKey, g.GenreName, gh.GenreLevel + 1
	FROM Genre g
		JOIN GenreLevel gh
			ON g.ParentGenreKey = gh.GenreKey
)

SELECT ParentGenreKey, ParentGenreName, GenreKey, GenreName, GenreLevel
FROM GenreLevel
ORDER BY GenreLevel, GenreName; 


---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
/* Order hierarchy in business-format*/
--Old School

DECLARE @GenreHierarchy TABLE
	(
	 GenreKey int PRIMARY KEY CLUSTERED
	,GenreName varchar(100)
	 ,ParentGenreKey int 
	,ParentGenreName varchar(100)
	,GenreLevel tinyint
	,OrderingColumn varchar(4000)
	)

--Grab all nodes
INSERT INTO @GenreHierarchy(ParentGenreKey, ParentGenreName, GenreKey, GenreName, GenreLevel, OrderingColumn)
SELECT ParentGenreKey, NULL, GenreKey, GenreName, NULL as GenreLevel, NULL as OrderingColumn
FROM Genre

--Update Level 0 - starting point
UPDATE @GenreHierarchy
SET 
	  GenreLevel = 0
	 ,OrderingColumn = GenreName
WHERE ParentGenreKey IS NULL

--Loop trough to set subsequent hierarchy levels
WHILE (SELECT COUNT(*) FROM @GenreHierarchy WHERE GenreLevel IS NULL) > 0

BEGIN

	UPDATE c 
	SET c.GenreLevel = (SELECT MAX(GenreLevel)+1 FROM @GenreHierarchy)
		,c.ParentGenreName = p.GenreName
		,c.OrderingColumn = p.OrderingColumn + ' - ' + c.GenreName
	FROM @GenreHierarchy p
		JOIN @GenreHierarchy c
			ON p.GenreKey = c.ParentGenreKey
	WHERE p.GenreLevel = (SELECT MAX(GenreLevel) FROM @GenreHierarchy)

END

--Select results
SELECT SPACE(GenreLevel*3)+GenreName as GenreList, ParentGenreKey, ParentGenreName, GenreKey, GenreName, GenreLevel, OrderingColumn
FROM @GenreHierarchy
ORDER BY OrderingColumn;

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

--New School - Order within Hierarchy
WITH GenreHierarchy as (
	SELECT ParentGenreKey, cast('' as varchar(100)) as ParentGenreName,GenreKey, GenreName, 0 as GenreLevel, cast(GenreName as varchar(max)) as OrderingColumn
	FROM Genre
	WHERE ParentGenreKey IS NULL
UNION ALL
	SELECT g.ParentGenreKey, gh.GenreName, g.GenreKey, g.GenreName, gh.GenreLevel + 1, cast(gh.OrderingColumn+' - '+g.GenreName as varchar(max))
	FROM Genre g
		JOIN GenreHierarchy gh
			ON g.ParentGenreKey = gh.GenreKey
)

SELECT SPACE(GenreLevel*3)+GenreName as FormattedGenreList, ParentGenreKey, ParentGenreName, GenreKey, GenreName, GenreLevel, OrderingColumn
FROM GenreHierarchy 
ORDER BY OrderingColumn; 

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

--Set starting point within hierarchy
DECLARE @GenreName varchar(100)  = 'Westerns'; 

WITH GenreHierarchy as (
	SELECT ParentGenreKey, cast('' as varchar(100)) as ParentGenreName,GenreKey, GenreName, 0 as GenreLevel, cast(GenreName as varchar(max)) as OrderingColumn
	FROM Genre
	WHERE GenreName = @GenreName
UNION ALL
	SELECT g.ParentGenreKey, gh.GenreName, g.GenreKey, g.GenreName, gh.GenreLevel + 1, cast(gh.OrderingColumn+' - '+g.GenreName as varchar(max))
	FROM Genre g
		JOIN GenreHierarchy gh
			ON g.ParentGenreKey = gh.GenreKey
)

SELECT SPACE(GenreLevel*3)+GenreName as FormattedGenreList, ParentGenreKey, ParentGenreName, GenreKey, GenreName, GenreLevel, OrderingColumn
FROM GenreHierarchy 
ORDER BY OrderingColumn; 

---------------------------------------------------------------------------------------------------------------------------------------------------------------

--Lineage
--Set starting point within hierarchy
DECLARE @LineageGenreName varchar(100)  = 'Steampunk'; 

WITH Lineage as (
	SELECT GenreKey, GenreName, ParentGenreKey, 0 as GenreLevel, cast(GenreName as varchar(max)) as OrderingColumn
	FROM Genre
	WHERE GenreName = @LineageGenreName
UNION ALL
	SELECT g.GenreKey, g.GenreName, g.ParentGenreKey, l.GenreLevel + 1, cast(g.GenreName + ' - ' +l.OrderingColumn as varchar(max))
	FROM Genre g
		JOIN Lineage l
			ON g.GenreKey = l.ParentGenreKey
)

SELECT SPACE(GenreLevel*3)+GenreName as FormattedGenreList, ParentGenreKey, GenreKey, GenreName, GenreLevel, OrderingColumn as Lineage
FROM Lineage
ORDER BY GenreLevel; 
