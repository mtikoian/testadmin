/***** CREATE DATABASE *****/
USE [master]
GO

IF  EXISTS (SELECT name FROM sys.databases WHERE name = N'IHeartBooks')
DROP DATABASE [IHeartBooks]
GO


CREATE DATABASE [IHeartBooks] --ON  PRIMARY 
--( NAME = N'IHeartBooks', FILENAME = N'C:\Database\Data\IHeartBooks.mdf' , SIZE = 6144KB , MAXSIZE = UNLIMITED, FILEGROWTH = 1024KB )
-- LOG ON 
--( NAME = N'IHeartBooks_log', FILENAME = N'C:\Database\Log\IHeartBooks_log.ldf' , SIZE = 1024KB , MAXSIZE = 2048GB , FILEGROWTH = 10%)
GO

/***** CREATE OBJECTS *****/
--CREATE Author table
USE [IHeartBooks]
GO

IF EXISTS (SELECT name FROM sys.tables WHERE name = N'Author')
BEGIN 
	DROP TABLE Author
END	
GO

CREATE TABLE [dbo].[Author](
	[AuthorKey] [int] IDENTITY(1,1) NOT NULL,
	[AuthorFirstName] [varchar](50) NOT NULL,
	[AuthorMiddleName] [varchar](25) NULL,
	[AuthorLastName] [varchar](50) NOT NULL,
CONSTRAINT PK_Author PRIMARY KEY CLUSTERED 
(
	[AuthorKey] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

--CREATE Format table
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Format]') AND type in (N'U'))
DROP TABLE [dbo].[Format]
GO

CREATE TABLE [dbo].[Format](
	[FormatKey] [int] IDENTITY(1,1) NOT NULL,
	[FormatName] [varchar](50) NOT NULL,
CONSTRAINT PK_Format PRIMARY KEY CLUSTERED 
(
	[FormatKey] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

--CREATE Series table
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Series]') AND type in (N'U'))
DROP TABLE [dbo].[Series]
GO

CREATE TABLE [dbo].[Series](
	[SeriesKey] [int] IDENTITY(1,1) NOT NULL,
	[SeriesName] [varchar](75) NOT NULL,
CONSTRAINT PK_Series PRIMARY KEY CLUSTERED 
(
	[SeriesKey] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

--CREATE Genre table
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Genre_ParentGenreKey]') AND parent_object_id = OBJECT_ID(N'[dbo].[Genre]'))
ALTER TABLE [dbo].[Genre] DROP CONSTRAINT FK_Genre_ParentGenreKey
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_Genre_Archaic]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[Genre] DROP CONSTRAINT [DF_Genre_Archaic]
END
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Genre]') AND type in (N'U'))
DROP TABLE [dbo].[Genre]
GO

CREATE TABLE [dbo].[Genre](
	[GenreKey] [int] IDENTITY(1,1) NOT NULL,
	[ParentGenreKey] [int] NULL,
	[GenreName] [varchar](100) NOT NULL,
	[Archaic] [bit] NOT NULL,
	[Defined] [varchar](1500) NULL,
	[DefinitionSource] [varchar](250) NULL,
CONSTRAINT PK_Genre PRIMARY KEY CLUSTERED 
(
	[GenreKey] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[Genre]  WITH CHECK 
	ADD CONSTRAINT FK_Genre_ParentGenreKey FOREIGN KEY([ParentGenreKey])
		REFERENCES [dbo].[Genre] ([GenreKey])
GO

ALTER TABLE [dbo].[Genre] ADD CONSTRAINT DF_Genre_Archaic DEFAULT ((0)) FOR [Archaic]
GO

--CREATE Title table
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Title_AuthorKey]') AND parent_object_id = OBJECT_ID(N'[dbo].[Title]'))
ALTER TABLE [dbo].[Title] DROP CONSTRAINT FK_Title_AuthorKey
GO

IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Title_FormatKey]') AND parent_object_id = OBJECT_ID(N'[dbo].[Title]'))
ALTER TABLE [dbo].[Title] DROP CONSTRAINT FK_Title_FormatKey
GO

IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Title_GenreKey]') AND parent_object_id = OBJECT_ID(N'[dbo].[Title]'))
ALTER TABLE [dbo].[Title] DROP CONSTRAINT FK_Title_GenreKey
GO

IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Title_SeriesKey]') AND parent_object_id = OBJECT_ID(N'[dbo].[Title]'))
ALTER TABLE [dbo].[Title] DROP CONSTRAINT FK_Title_SeriesKey
GO

IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Title_SubGenreKey]') AND parent_object_id = OBJECT_ID(N'[dbo].[Title]'))
ALTER TABLE [dbo].[Title] DROP CONSTRAINT FK_Title_SubGenreKey
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_Title_Completed]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[Title] DROP CONSTRAINT DF_Title_Completed
END
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Title]') AND type in (N'U'))
DROP TABLE [dbo].[Title]
GO

CREATE TABLE [dbo].[Title](
	[TitleKey] [int] IDENTITY(1,1) NOT NULL,
	[TitleName] [varchar](250) NOT NULL,
	[AuthorKey] [int] NOT NULL,
	[SeriesKey] [int] NULL,
	[FormatKey] [int] NULL,
	[GenreKey] [int] NULL,
	[SubGenreKey] [int] NULL,
	[Completed] [bit] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[TitleKey] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[Title]  WITH CHECK ADD CONSTRAINT FK_Title_AuthorKey FOREIGN KEY([AuthorKey])
REFERENCES [dbo].[Author] ([AuthorKey])
GO

ALTER TABLE [dbo].[Title]  WITH CHECK ADD CONSTRAINT FK_Title_FormatKey FOREIGN KEY([FormatKey])
REFERENCES [dbo].[Format] ([FormatKey])
GO

ALTER TABLE [dbo].[Title]  WITH CHECK ADD CONSTRAINT FK_Title_GenreKey FOREIGN KEY([GenreKey])
REFERENCES [dbo].[Genre] ([GenreKey])
GO

ALTER TABLE [dbo].[Title]  WITH CHECK ADD CONSTRAINT FK_Title_SeriesKey FOREIGN KEY([SeriesKey])
REFERENCES [dbo].[Series] ([SeriesKey])
GO

ALTER TABLE [dbo].[Title]  WITH CHECK ADD CONSTRAINT FK_Title_SubgenreKey FOREIGN KEY([SubGenreKey])
REFERENCES [dbo].[Genre] ([GenreKey])
GO

ALTER TABLE [dbo].[Title] ADD CONSTRAINT DF_Title_Completed DEFAULT ((0)) FOR [Completed]
GO

--CREATE ImportBookList
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ImportBookList]') AND type in (N'U'))
DROP TABLE [dbo].[ImportBookList]
GO

CREATE TABLE [dbo].[ImportBookList](
	[GenreKey] [float] NULL,
	[Genre] [nvarchar](255) NULL,
	[SubGenreKey] [nvarchar](255) NULL,
	[SubGenre] [nvarchar](255) NULL,
	[Title] [nvarchar](255) NULL,
	[Author] [nvarchar](255) NULL,
	[Co-Author] [nvarchar](255) NULL,
	[Series Name] [nvarchar](255) NULL,
	[F9] [nvarchar](255) NULL,
	[Number in Series] [nvarchar](255) NULL,
	[Format] [nvarchar](255) NULL,
	[Year Read] [nvarchar](255) NULL,
	[AuthorFirstName] [varchar](50) NULL,
	[AuthorLastName] [varchar](50) NULL,
	[AuthorMiddleName] [varchar](50) NULL
) ON [PRIMARY]
GO

--CREATE ImportBookONE
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ImportBookONE]') AND type in (N'U'))
DROP TABLE [dbo].[ImportBookONE]
GO

CREATE TABLE [dbo].[ImportBookONE](
	[Title] [varchar](150) NULL,
	[AuthorFirstName] [varchar](50) NULL,
	[AuthorMiddleName] [varchar](50) NULL,
	[AuthorLastName] [varchar](50) NULL,
	[Format] [varchar](50) NULL,
	[SeriesName] [varchar](100) NULL,
	[Genre] [varchar](50) NULL,
	[FirstParentGenre] [varchar](50) NULL,
	[ImportDate] [datetime] NULL
) ON [PRIMARY]
GO

--CREATE ImportBookTWO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ImportBookTWO]') AND type in (N'U'))
DROP TABLE [dbo].[ImportBookTWO]
GO

CREATE TABLE [dbo].[ImportBookTWO](
	[Title] [varchar](150) NULL,
	[AuthorFirstName] [varchar](50) NULL,
	[AuthorMiddleName] [varchar](50) NULL,
	[AuthorLastName] [varchar](50) NULL,
	[Format] [varchar](50) NULL,
	[SeriesName] [varchar](100) NULL,
	[Genre] [varchar](50) NULL,
	[FirstParentGenre] [varchar](50) NULL,
	[ImportDate] [datetime] NULL
) ON [PRIMARY]
GO


/***** POPULATE TABLES *****/
--Populate Author table
SET IDENTITY_INSERT [dbo].[Author] ON;

BEGIN TRANSACTION;
INSERT INTO [dbo].[Author]([AuthorKey], [AuthorFirstName], [AuthorMiddleName], [AuthorLastName])
SELECT 3, N'A. ', N'Lee', N'Martinez' UNION ALL
SELECT 4, N'Anne ', NULL, N'Lamott' UNION ALL
SELECT 5, N'Barbara ', NULL, N'Kingsolver' UNION ALL
SELECT 6, N'Bill ', NULL, N'Bryson' UNION ALL
SELECT 7, N'Brandon ', NULL, N'Sanderson' UNION ALL
SELECT 8, N'Brent ', NULL, N'Weeks' UNION ALL
SELECT 9, N'Charlaine ', NULL, N'Harris' UNION ALL
SELECT 10, N'Chelsea ', NULL, N'Handler' UNION ALL
SELECT 11, N'Christopher ', NULL, N'Moore' UNION ALL
SELECT 12, N'Dave ', NULL, N'Duncan' UNION ALL
SELECT 13, N'David ', NULL, N'Wong' UNION ALL
SELECT 14, N'Dexter ', NULL, N'Palmer' UNION ALL
SELECT 15, N'Diana ', NULL, N'Gabaldon' UNION ALL
SELECT 16, N'Elizabeth ', NULL, N'Gilbert' UNION ALL
SELECT 17, N'Elizabeth ', NULL, N'Strout' UNION ALL
SELECT 18, N'Emily ', NULL, N'St. John Mandel' UNION ALL
SELECT 19, N'Erik ', NULL, N'Larson' UNION ALL
SELECT 20, N'Felix ', NULL, N'Gilman' UNION ALL
SELECT 21, N'Francis ', NULL, N'Fukuyama' UNION ALL
SELECT 22, N'Geoff ', NULL, N'Dyer' UNION ALL
SELECT 23, N'Gregory ', NULL, N'Maguire' UNION ALL
SELECT 24, N'Hilary ', NULL, N'Mantel' UNION ALL
SELECT 25, N'Irene ', NULL, N'Nemirovsky' UNION ALL
SELECT 26, N'Jeffrey ', NULL, N'Eugenides' UNION ALL
SELECT 27, N'Jess ', NULL, N'Walter' UNION ALL
SELECT 28, N'Jhumpa ', NULL, N'Lahiri' UNION ALL
SELECT 29, N'Joe ', NULL, N'Abercrombie' UNION ALL
SELECT 30, N'John ', NULL, N'Connolly' UNION ALL
SELECT 31, N'Jonathan ', N'L.', N'Howard' UNION ALL
SELECT 32, N'Joshua ', NULL, N'Ferris' UNION ALL
SELECT 33, N'Kathryn ', NULL, N'Stockett' UNION ALL
SELECT 34, N'Khaled ', NULL, N'Hosseini' UNION ALL
SELECT 35, N'Laurell ', N'K.', N'Hamilton' UNION ALL
SELECT 36, N'Les ', NULL, N'Grossman' UNION ALL
SELECT 37, N'Malcom ', NULL, N'Gladwell' UNION ALL
SELECT 38, N'Marcus ', N'Alexander', N'Hart' UNION ALL
SELECT 39, N'Mark ', NULL, N'Haddon' UNION ALL
SELECT 40, N'Mary ', N'Ann', N'Shaffer' UNION ALL
SELECT 41, N'Max ', NULL, N'Brooks' UNION ALL
SELECT 42, N'Michael ', NULL, N'Ignatieff' UNION ALL
SELECT 43, N'Mike ', NULL, N'Carey' UNION ALL
SELECT 44, N'Neal ', NULL, N'Stephenson' UNION ALL
SELECT 45, N'Neil ', NULL, N'Gaiman' UNION ALL
SELECT 46, N'Nic ', NULL, N'Pizzolatto' UNION ALL
SELECT 47, N'Nicola ', NULL, N'Keegan' UNION ALL
SELECT 48, N'Orson ', N'Scott', N'Card' UNION ALL
SELECT 49, N'Patrick ', NULL, N'Rothfuss' UNION ALL
SELECT 50, N'Paulo ', NULL, N'Coelho' UNION ALL
SELECT 51, N'Penelope ', N'J.', N'Stokes' UNION ALL
SELECT 52, N'Peter ', N'V.', N'Brett'
COMMIT;
RAISERROR (N'[dbo].[Author]: Insert Batch: 1.....Done!', 10, 1) WITH NOWAIT;
GO

BEGIN TRANSACTION;
INSERT INTO [dbo].[Author]([AuthorKey], [AuthorFirstName], [AuthorMiddleName], [AuthorLastName])
SELECT 53, N'Richard ', NULL, N'Castle' UNION ALL
SELECT 54, N'Richard ', NULL, N'Yates' UNION ALL
SELECT 55, N'Rick ', NULL, N'Moody' UNION ALL
SELECT 56, N'Robert ', NULL, N'Heinlein' UNION ALL
SELECT 57, N'Robert ', NULL, N'Jordan' UNION ALL
SELECT 58, N'Robert ', NULL, N'Pirsig' UNION ALL
SELECT 59, N'Sam ', NULL, N'Wasson' UNION ALL
SELECT 60, N'Sarah ', NULL, N'Waters' UNION ALL
SELECT 61, N'Scott ', NULL, N'Lynch' UNION ALL
SELECT 62, N'Stephen ', NULL, N'King' UNION ALL
SELECT 63, N'Stephenie ', NULL, N'Meyer' UNION ALL
SELECT 64, N'Stieg ', NULL, N'Larsson' UNION ALL
SELECT 65, N'Terry ', NULL, N'Pratchett' UNION ALL
SELECT 66, N'Thomas ', N'L.', N'Friedman' UNION ALL
SELECT 67, N'Wells ', NULL, N'Tower' UNION ALL
SELECT 68, N'William ', NULL, N'Gibson' UNION ALL
SELECT 69, N'Paul', NULL, N'Murray' UNION ALL
SELECT 70, N'Patrick', NULL, N'Jordan' UNION ALL
SELECT 71, N'Robert', NULL, N'Sanderson'
COMMIT;
RAISERROR (N'[dbo].[Author]: Insert Batch: 2.....Done!', 10, 1) WITH NOWAIT;
GO

SET IDENTITY_INSERT [dbo].[Author] OFF;

--Populate Format table
SET IDENTITY_INSERT [dbo].[Format] ON;

BEGIN TRANSACTION;
INSERT INTO [dbo].[Format]([FormatKey], [FormatName])
SELECT 1, N'Audio' UNION ALL
SELECT 2, N'Hardback' UNION ALL
SELECT 3, N'Kindle' UNION ALL
SELECT 4, N'Paperback'
COMMIT;
RAISERROR (N'[dbo].[Format]: Insert Batch: 1.....Done!', 10, 1) WITH NOWAIT;
GO

SET IDENTITY_INSERT [dbo].[Format] OFF;

--Populate Series table
SET IDENTITY_INSERT [dbo].[Series] ON;

BEGIN TRANSACTION;
INSERT INTO [dbo].[Series]([SeriesKey], [SeriesName])
SELECT 1, N'Anita Blake: Vampire Hunter' UNION ALL
SELECT 2, N'Bigend Trilogy' UNION ALL
SELECT 3, N'Bridge Trilogy' UNION ALL
SELECT 4, N'Demon Cycle' UNION ALL
SELECT 5, N'Discworld' UNION ALL
SELECT 6, N'Felix Castor' UNION ALL
SELECT 7, N'Future History' UNION ALL
SELECT 8, N'Lazarus Long' UNION ALL
SELECT 9, N'Lightbringer Series' UNION ALL
SELECT 10, N'Millenium Series' UNION ALL
SELECT 11, N'Mistborn Trilogy' UNION ALL
SELECT 12, N'Night Angel Trilogy' UNION ALL
SELECT 13, N'Outlander Series' UNION ALL
SELECT 14, N'Seventh Sword' UNION ALL
SELECT 15, N'Southern Vampire' UNION ALL
SELECT 16, N'Sprawl Trilogy' UNION ALL
SELECT 17, N'Baroque Cycle' UNION ALL
SELECT 18, N'Dark Tower' UNION ALL
SELECT 19, N'Ender Saga' UNION ALL
SELECT 20, N'First Law' UNION ALL
SELECT 21, N'Shadow Saga' UNION ALL
SELECT 22, N'Stormlight Archive' UNION ALL
SELECT 23, N'Tales of Alvin Maker' UNION ALL
SELECT 24, N'Wheel of Time'
COMMIT;
RAISERROR (N'[dbo].[Series]: Insert Batch: 1.....Done!', 10, 1) WITH NOWAIT;
GO

SET IDENTITY_INSERT [dbo].[Series] OFF;

--Populate Genre table
ALTER TABLE dbo.Genre
	DROP CONSTRAINT FK_Genre_ParentGenreKey; 
GO

SET IDENTITY_INSERT [dbo].[Genre] ON;
BEGIN TRANSACTION;
INSERT INTO [dbo].[Genre]([GenreKey], [ParentGenreKey], [GenreName], [Archaic], [Defined], [DefinitionSource])
SELECT 1, NULL, N'Fiction', 0, N'Something invented by the imagination or feigned; specifically, an invented story', N'http://www.merriam-webster.com/' UNION ALL
SELECT 2, NULL, N'Non-Fiction', 0, N'http://www.merriam-webster.com/', NULL UNION ALL
SELECT 3, 1, N'Speculative Fiction', 0, NULL, NULL UNION ALL
SELECT 4, 3, N'Science Fiction', 0, NULL, NULL UNION ALL
SELECT 5, 3, N'Fantasy', 0, NULL, NULL UNION ALL
SELECT 6, 3, N'Horror', 0, NULL, NULL UNION ALL
SELECT 7, 1, N'Absurdist', 0, N'Absurdist Fiction is any fictional material that is comedic because of the absurdity of its content. Whereas much comedy can be brought from real-life situations and observations, absurdists choose to instead find comedy in completly impractical or unrealistic situations. Often, absurdist comedy is viewed as simply not making sense, but this is not always the case. ', N'http://www.knowledgerush.com/kr/encyclopedia/Absurdist_fiction/' UNION ALL
SELECT 8, 1, N'Adventure', 0, N'The adventure novel is a genre of novels that has adventure, an exciting undertaking involving risk and physical danger, as its main theme. ', N'en.wikipedia.org/wiki/Adventure_fiction' UNION ALL
SELECT 9, 1, N'African-American', 0, N'African-American literature is the body of literature produced in the United States by writers of African descent.', N'http://en.wikipedia.org/wiki/African-American_literature' UNION ALL
SELECT 10, 1, N'Airport Novels', 0, N'Airport novels represent a literary genre that is not so much defined by its plot or cast of stock characters, as much as it is by the social function it serves. An airport novel is typically a fairly long but fast-paced novel of intrigue or adventure that is stereotypically found in the reading. ', N'http://www.tutorvista.com/bow/define-novel' UNION ALL
SELECT 11, 1, N'Allegorical', 0, N'An allegory is a work of fiction in which the symbols, characters, and events come to represent, in a somewhat point-by-point fashion, a different metaphysical, political, or social situation.', N'http://bcs.bedfordstmartins.com/virtualit/fiction/elements.asp?e=7' UNION ALL
SELECT 12, 1, N'Alternative History', 0, N'Alternative history or alternate history is fiction that is set in a world in which history has diverged from history as it is generally known, or simply put "What If?". While to some extent, all fiction can be classified as alternative history, this genre is used to denote fiction in which a change happens which causes history to diverge.', N'http://www.wordiq.com/definition/Alternate_history_(fiction)' UNION ALL
SELECT 13, 1, N'Americana', 0, N'Americana refers books related to the history, geography, folklore and cultural heritage of the United States.', N'http://en.wikipedia.org/wiki/Americana' UNION ALL
SELECT 14, 1, N'Asian-American', 0, NULL, NULL UNION ALL
SELECT 15, 1, N'Autobiographical Ficton', 0, NULL, NULL UNION ALL
SELECT 16, 1, N'Campus', 0, NULL, NULL UNION ALL
SELECT 17, 1, N'Canadiana', 0, NULL, NULL UNION ALL
SELECT 18, 1, N'Chick Lit', 0, NULL, NULL UNION ALL
SELECT 19, 1, N'Children''s Literature', 0, NULL, NULL UNION ALL
SELECT 20, 1, N'Classic Inspirational', 0, NULL, NULL UNION ALL
SELECT 21, 1, N'Coming of Age', 0, NULL, NULL UNION ALL
SELECT 22, 1, N'Commercial Fiction', 0, NULL, NULL UNION ALL
SELECT 23, 1, N'Constrained', 0, NULL, NULL UNION ALL
SELECT 24, 1, N'Cotierie/Cult Novel', 0, NULL, NULL UNION ALL
SELECT 25, 1, N'Crime', 0, NULL, NULL UNION ALL
SELECT 26, 1, N'Decadent', 0, NULL, NULL UNION ALL
SELECT 27, 1, N'Detective', 0, NULL, NULL UNION ALL
SELECT 28, 1, N'Dickensian', 1, NULL, NULL UNION ALL
SELECT 29, 1, N'Drama/Realistic', 0, NULL, NULL UNION ALL
SELECT 30, 1, N'Economic/Financial', 0, NULL, NULL UNION ALL
SELECT 31, 1, N'Ecotopian', 0, NULL, NULL UNION ALL
SELECT 32, 1, N'Erotica', 0, NULL, NULL UNION ALL
SELECT 33, 1, N'Epistolary', 0, NULL, NULL UNION ALL
SELECT 34, 1, N'Existentialist', 0, NULL, NULL UNION ALL
SELECT 35, 1, N'Experimental', 0, NULL, NULL UNION ALL
SELECT 36, 1, N'Fable', 0, NULL, NULL UNION ALL
SELECT 37, 1, N'Fairy Tales', 0, NULL, NULL UNION ALL
SELECT 38, 1, N'False Autobiography', 0, NULL, NULL UNION ALL
SELECT 39, 1, N'FanFic', 0, NULL, NULL UNION ALL
SELECT 40, 1, N'Folklore', 0, NULL, NULL UNION ALL
SELECT 41, 1, N'Frame Story', 0, NULL, NULL UNION ALL
SELECT 42, 1, N'Frat Lit', 0, NULL, NULL UNION ALL
SELECT 43, 1, N'Gothic Fiction', 0, NULL, NULL UNION ALL
SELECT 44, 1, N'Historical', 0, NULL, NULL UNION ALL
SELECT 45, 1, N'Historiographical Metafiction', 0, NULL, NULL UNION ALL
SELECT 46, 1, N'Humor/Comedy', 0, NULL, NULL UNION ALL
SELECT 47, 1, N'Inspirational', 0, NULL, NULL UNION ALL
SELECT 48, 1, N'Interactive Invasion Literature', 0, NULL, NULL UNION ALL
SELECT 49, 1, N'Lab Lit', 0, NULL, NULL UNION ALL
SELECT 50, 1, N'Latino/Hispanic', 0, NULL, NULL
COMMIT;
RAISERROR (N'[dbo].[Genre]: Insert Batch: 1.....Done!', 10, 1) WITH NOWAIT;
GO

BEGIN TRANSACTION;
INSERT INTO [dbo].[Genre]([GenreKey], [ParentGenreKey], [GenreName], [Archaic], [Defined], [DefinitionSource])
SELECT 51, 1, N'Literary Fiction', 0, NULL, NULL UNION ALL
SELECT 52, 1, N'Luciferian', 0, NULL, NULL UNION ALL
SELECT 53, 1, N'Magical Realism', 0, NULL, NULL UNION ALL
SELECT 54, 1, N'Mainstream/Blockbuster', 0, NULL, NULL UNION ALL
SELECT 55, 1, N'Maritime/Nautical', 0, NULL, NULL UNION ALL
SELECT 56, 1, N'Military Action', 0, NULL, NULL UNION ALL
SELECT 57, 1, N'Musical', 0, NULL, NULL UNION ALL
SELECT 58, 1, N'Mystery', 0, NULL, NULL UNION ALL
SELECT 59, 1, N'Mythology', 0, NULL, NULL UNION ALL
SELECT 60, 1, N'Neuronovel', 0, NULL, NULL UNION ALL
SELECT 61, 1, N'Non-Narrative', 0, NULL, NULL UNION ALL
SELECT 62, 1, N'Nouveau Roman', 0, NULL, NULL UNION ALL
SELECT 63, 1, N'Novela del Dictador', 0, NULL, NULL UNION ALL
SELECT 64, 1, N'Philosophical', 0, NULL, NULL UNION ALL
SELECT 65, 1, N'Picaresque', 0, NULL, NULL UNION ALL
SELECT 66, 1, N'Postcolonial', 0, NULL, NULL UNION ALL
SELECT 67, 1, N'Prehistoric', 0, NULL, NULL UNION ALL
SELECT 68, 1, N'Proletarian', 1, NULL, NULL UNION ALL
SELECT 69, 1, N'Prompt Stories', 0, NULL, NULL UNION ALL
SELECT 70, 1, N'Proto-Novel', 0, NULL, NULL UNION ALL
SELECT 71, 1, N'Psychological', 0, NULL, NULL UNION ALL
SELECT 72, 1, N'Pulp', 0, NULL, NULL UNION ALL
SELECT 73, 1, N'Regional', 0, NULL, NULL UNION ALL
SELECT 74, 1, N'Roman a clef', 0, NULL, NULL UNION ALL
SELECT 75, 1, N'Romance', 0, NULL, NULL UNION ALL
SELECT 76, 1, N'Roman a These', 0, NULL, NULL UNION ALL
SELECT 77, 1, N'Romantic', 1, NULL, NULL UNION ALL
SELECT 78, 1, N'Saga/Epic', 0, NULL, NULL UNION ALL
SELECT 79, 1, N'Satire/Lampoon', 0, NULL, NULL UNION ALL
SELECT 80, 1, N'Sensation Novel', 1, NULL, NULL UNION ALL
SELECT 81, 1, N'Sentimental', 1, NULL, NULL UNION ALL
SELECT 82, 1, N'Short Fiction', 0, NULL, NULL UNION ALL
SELECT 83, 1, N'Slave Narrative', 0, NULL, NULL UNION ALL
SELECT 84, 1, N'Slipstream', 0, NULL, NULL UNION ALL
SELECT 85, 1, N'Sports', 0, NULL, NULL UNION ALL
SELECT 86, 1, N'Spy', 0, NULL, NULL UNION ALL
SELECT 87, 1, N'Stream of Consciousness', 0, NULL, NULL UNION ALL
SELECT 88, 1, N'Tall Tale', 0, NULL, NULL UNION ALL
SELECT 89, 1, N'Thriller/Suspense', 0, NULL, NULL UNION ALL
SELECT 90, 1, N'Tragedy', 0, NULL, NULL UNION ALL
SELECT 91, 1, N'Transrealism', 0, NULL, NULL UNION ALL
SELECT 92, 1, N'True Crime', 0, NULL, NULL UNION ALL
SELECT 93, 1, N'Urban/Hip-Hop Lit', 0, NULL, NULL UNION ALL
SELECT 94, 1, N'Upmarket', 0, NULL, NULL UNION ALL
SELECT 95, 1, N'Verse Novels', 0, NULL, NULL UNION ALL
SELECT 96, 1, N'War Stories', 0, NULL, NULL UNION ALL
SELECT 97, 1, N'Westerns', 0, NULL, NULL UNION ALL
SELECT 98, 1, N'Young Adult', 0, NULL, NULL UNION ALL
SELECT 99, 8, N'Milesian', 1, N'The Milesian tale originates in ancient Greek and Roman literature. According to most authorities, it is a short story, fable, or folktale featuring love and adventure, usually being erotic and titillating. The name Milesian tale originates from the Milesiaka of Aristides of Miletus (a Greek who lived around the second century BCE). Later, in the first century BCE, Lucius Cornelius Sisenna translated Aristides into Latin under the title Milesiae fabulae (Milesian Fables) and the term Milesian ta', N'http://www.artandpopularculture.com/Milesian_tales' UNION ALL
SELECT 100, 8, N'Robinsonade', 0, N'Robinsonade is a literary genre that takes its name from the 1719 novel Robinson Crusoe by Daniel Defoe. The success of this novel spawned enough imitations that its name was used to define a genre, which is sometimes described simply as a "desert island story".', N'http://en.wikipedia.org/wiki/Robinsonade'
COMMIT;
RAISERROR (N'[dbo].[Genre]: Insert Batch: 2.....Done!', 10, 1) WITH NOWAIT;
GO

BEGIN TRANSACTION;
INSERT INTO [dbo].[Genre]([GenreKey], [ParentGenreKey], [GenreName], [Archaic], [Defined], [DefinitionSource])
SELECT 101, 13, N'Road Trip', 0, N'Used for works in which a journey, as a life-changing experience, is a central part of the action.', N'http://www.worldcat.org/genres/road-fiction.html' UNION ALL
SELECT 102, 16, N'Varsity', 0, NULL, NULL UNION ALL
SELECT 103, 18, N'Matron Lit', 0, NULL, NULL UNION ALL
SELECT 104, 18, N'Ethnic', 0, NULL, NULL UNION ALL
SELECT 105, 19, N'By Children', 0, NULL, NULL UNION ALL
SELECT 106, 19, N'Early Readers', 0, NULL, NULL UNION ALL
SELECT 107, 19, N'Middle/Junior Readers', 0, NULL, NULL UNION ALL
SELECT 108, 19, N'Picture Books', 0, NULL, NULL UNION ALL
SELECT 109, 19, N'Pop-Up Picture Books', 0, NULL, NULL UNION ALL
SELECT 110, 19, N'Traditional Stories', 0, NULL, NULL UNION ALL
SELECT 111, 21, N'bildungsroman', 0, NULL, NULL UNION ALL
SELECT 112, 25, N'Newgate Novels', 0, NULL, NULL UNION ALL
SELECT 113, 25, N'Mafia', 0, NULL, NULL UNION ALL
SELECT 114, 25, N'Prison Literature', 0, NULL, NULL UNION ALL
SELECT 115, 25, N'Renegade Cops', 0, NULL, NULL UNION ALL
SELECT 116, 29, N'Over-the-Top', 0, NULL, NULL UNION ALL
SELECT 117, 32, N'Chinese', 0, NULL, NULL UNION ALL
SELECT 118, 32, N'Contemporary', 0, NULL, NULL UNION ALL
SELECT 119, 32, N'Early Works', 0, NULL, NULL UNION ALL
SELECT 120, 32, N'Faux Memoirs', 0, NULL, NULL UNION ALL
SELECT 121, 32, N'Fetish', 0, NULL, NULL UNION ALL
SELECT 122, 32, N'BDSM', 0, NULL, NULL UNION ALL
SELECT 123, 35, N'Anti-Novel', 1, NULL, NULL UNION ALL
SELECT 124, 36, N'Apologue', 0, NULL, NULL UNION ALL
SELECT 125, 36, N'Legend', 0, NULL, NULL UNION ALL
SELECT 126, 36, N'Parable', 0, NULL, NULL UNION ALL
SELECT 127, 5, N'Alternate Worlds', 0, NULL, NULL UNION ALL
SELECT 128, 5, N'Arthurian', 0, NULL, NULL UNION ALL
SELECT 129, 5, N'Bangsian', 0, NULL, NULL UNION ALL
SELECT 130, 5, N'Celtic', 0, NULL, NULL UNION ALL
SELECT 131, 5, N'Christian', 0, NULL, NULL UNION ALL
SELECT 132, 5, N'Comedic', 0, NULL, NULL UNION ALL
SELECT 133, 5, N'Contemporary', 0, NULL, NULL UNION ALL
SELECT 134, 5, N'Court Intrigue', 0, NULL, NULL UNION ALL
SELECT 135, 5, N'Dark', 0, NULL, NULL UNION ALL
SELECT 136, 5, N'Dying Earth', 0, NULL, NULL UNION ALL
SELECT 137, 5, N'Erotic', 0, NULL, NULL UNION ALL
SELECT 138, 5, N'Fairy Tale', 0, NULL, NULL UNION ALL
SELECT 139, 5, N'Fantasy of Manners/Mannerpunk', 0, NULL, NULL UNION ALL
SELECT 140, 5, N'Feghoot', 0, NULL, NULL UNION ALL
SELECT 141, 5, N'Heroic', 0, NULL, NULL UNION ALL
SELECT 142, 5, N'High/Epic Fantasy', 0, NULL, NULL UNION ALL
SELECT 143, 5, N'Historical', 0, NULL, NULL UNION ALL
SELECT 144, 5, N'Historical High Fantasy', 0, NULL, NULL UNION ALL
SELECT 145, 5, N'Juvenile', 0, NULL, NULL UNION ALL
SELECT 146, 5, N'Low Fantasy', 0, NULL, NULL UNION ALL
SELECT 147, 5, N'Media Tie-In', 0, NULL, NULL UNION ALL
SELECT 148, 5, N'Medieval', 0, NULL, NULL UNION ALL
SELECT 149, 5, N'Mythic', 0, NULL, NULL UNION ALL
SELECT 150, 5, N'Prehistoric', 0, NULL, NULL
COMMIT;
RAISERROR (N'[dbo].[Genre]: Insert Batch: 3.....Done!', 10, 1) WITH NOWAIT;
GO

BEGIN TRANSACTION;
INSERT INTO [dbo].[Genre]([GenreKey], [ParentGenreKey], [GenreName], [Archaic], [Defined], [DefinitionSource])
SELECT 151, 5, N'Quest', 0, NULL, NULL UNION ALL
SELECT 152, 5, N'Romantic', 1, NULL, NULL UNION ALL
SELECT 153, 5, N'Science Fantasy', 0, NULL, NULL UNION ALL
SELECT 154, 5, N'Series', 0, NULL, NULL UNION ALL
SELECT 155, 5, N'Superhero', 0, NULL, NULL UNION ALL
SELECT 156, 5, N'Sword & Sorcery', 0, NULL, NULL UNION ALL
SELECT 157, 5, N'Urban Fantasy', 0, NULL, NULL UNION ALL
SELECT 158, 5, N'Wuxia', 0, NULL, NULL UNION ALL
SELECT 159, 149, N'Mythopoeia', 0, NULL, NULL UNION ALL
SELECT 160, 149, N'Mythpunk', 0, NULL, NULL UNION ALL
SELECT 161, 40, N'Contemporary', 0, NULL, NULL UNION ALL
SELECT 162, 40, N'International', 0, NULL, NULL UNION ALL
SELECT 163, 40, N'Old European', 0, NULL, NULL UNION ALL
SELECT 164, 6, N'Aliens', 0, NULL, NULL UNION ALL
SELECT 165, 6, N'Creepy Kids', 0, NULL, NULL UNION ALL
SELECT 166, 6, N'Cross Genre', 0, NULL, NULL UNION ALL
SELECT 167, 6, N'Cutting Edge', 0, NULL, NULL UNION ALL
SELECT 168, 6, N'Dark Fantasy', 0, NULL, NULL UNION ALL
SELECT 169, 6, N'Dark Fiction', 0, NULL, NULL UNION ALL
SELECT 170, 6, N'Erotic', 0, NULL, NULL UNION ALL
SELECT 171, 6, N'Extreme', 0, NULL, NULL UNION ALL
SELECT 172, 6, N'Fabulist', 0, NULL, NULL UNION ALL
SELECT 173, 6, N'Gothic', 0, NULL, NULL UNION ALL
SELECT 174, 6, N'Hauntings', 0, NULL, NULL UNION ALL
SELECT 175, 6, N'Holocaust', 0, NULL, NULL UNION ALL
SELECT 176, 6, N'Humorous', 0, NULL, NULL UNION ALL
SELECT 177, 6, N'Lovecraftian', 0, NULL, NULL UNION ALL
SELECT 178, 6, N'Media Tie-In', 0, NULL, NULL UNION ALL
SELECT 179, 6, N'Mind Control', 0, NULL, NULL UNION ALL
SELECT 180, 6, N'Noir', 0, NULL, NULL UNION ALL
SELECT 181, 6, N'Supernatural', 0, NULL, NULL UNION ALL
SELECT 182, 6, N'Paranormal', 0, NULL, NULL UNION ALL
SELECT 183, 6, N'Psychological', 0, NULL, NULL UNION ALL
SELECT 184, 6, N'Quiet/Soft', 0, NULL, NULL UNION ALL
SELECT 185, 6, N'Rampant Animals', 0, NULL, NULL UNION ALL
SELECT 186, 6, N'Rampant Technology', 0, NULL, NULL UNION ALL
SELECT 187, 6, N'Satanic Bargains', 0, NULL, NULL UNION ALL
SELECT 188, 6, N'Suspense/Dark Suspense', 0, NULL, NULL UNION ALL
SELECT 189, 6, N'Weird', 0, NULL, NULL UNION ALL
SELECT 190, 171, N'Splatterpunk', 0, NULL, NULL UNION ALL
SELECT 191, 171, N'Viceral', 0, NULL, NULL UNION ALL
SELECT 192, 173, N'English Gothic', 0, NULL, NULL UNION ALL
SELECT 193, 173, N'Southern Gothic', 0, NULL, NULL UNION ALL
SELECT 194, 181, N'Demons', 0, NULL, NULL UNION ALL
SELECT 195, 181, N'Zombies', 0, NULL, NULL UNION ALL
SELECT 196, 181, N'Vampires', 0, NULL, NULL UNION ALL
SELECT 197, 181, N'Werewolves', 0, NULL, NULL UNION ALL
SELECT 198, 183, N'Surreal', 0, NULL, NULL UNION ALL
SELECT 199, 46, N'Comedy of Manners', 0, NULL, NULL UNION ALL
SELECT 200, 46, N'Dark Comedy', 0, NULL, NULL
COMMIT;
RAISERROR (N'[dbo].[Genre]: Insert Batch: 4.....Done!', 10, 1) WITH NOWAIT;
GO

BEGIN TRANSACTION;
INSERT INTO [dbo].[Genre]([GenreKey], [ParentGenreKey], [GenreName], [Archaic], [Defined], [DefinitionSource])
SELECT 201, 46, N'Screwball', 0, NULL, NULL UNION ALL
SELECT 202, 46, N'Sentimental', 1, NULL, NULL UNION ALL
SELECT 203, 46, N'Slapstick', 0, NULL, NULL UNION ALL
SELECT 204, 50, N'Transborder', 0, NULL, NULL UNION ALL
SELECT 205, 56, N'Fictional Settings', 0, NULL, NULL UNION ALL
SELECT 206, 56, N'Real Settings', 0, NULL, NULL UNION ALL
SELECT 207, 56, N'Near Future', 0, NULL, NULL UNION ALL
SELECT 208, 58, N'Amateur Investigator', 0, NULL, NULL UNION ALL
SELECT 209, 58, N'Bumbling Detective', 0, NULL, NULL UNION ALL
SELECT 210, 58, N'Caper', 0, NULL, NULL UNION ALL
SELECT 211, 58, N'Child/Woman in Peril', 0, NULL, NULL UNION ALL
SELECT 212, 58, N'Cozy', 0, NULL, NULL UNION ALL
SELECT 213, 58, N'Culinary', 0, NULL, NULL UNION ALL
SELECT 214, 58, N'Doctor Detective', 0, NULL, NULL UNION ALL
SELECT 215, 58, N'Handicapped', 0, NULL, NULL UNION ALL
SELECT 216, 58, N'Hardboiled/Noir', 0, NULL, NULL UNION ALL
SELECT 217, 58, N'Historical Mystery', 0, NULL, NULL UNION ALL
SELECT 218, 58, N'Inverted/Howdunit', 0, NULL, NULL UNION ALL
SELECT 219, 58, N'Legal/Courtroom', 0, NULL, NULL UNION ALL
SELECT 220, 58, N'Locked Room/Puzzle', 0, NULL, NULL UNION ALL
SELECT 221, 58, N'Police Procedural', 0, NULL, NULL UNION ALL
SELECT 222, 58, N'Private Detectives', 0, NULL, NULL UNION ALL
SELECT 223, 58, N'Serials/Series', 0, NULL, NULL UNION ALL
SELECT 224, 58, N'Supernatural Mystery', 0, NULL, NULL UNION ALL
SELECT 225, 58, N'Whodunit', 0, NULL, NULL UNION ALL
SELECT 226, 217, N'Chinese', 0, NULL, NULL UNION ALL
SELECT 227, 217, N'Elizabethan', 0, NULL, NULL UNION ALL
SELECT 228, 221, N'Forensic', 0, NULL, NULL UNION ALL
SELECT 229, 221, N'Serial Killer', 0, NULL, NULL UNION ALL
SELECT 230, 221, N'Stalker', 0, NULL, NULL UNION ALL
SELECT 231, 222, N'Femal PI', 0, NULL, NULL UNION ALL
SELECT 232, 66, N'Postcolonial Gothic', 0, NULL, NULL UNION ALL
SELECT 233, 69, N'Designated First Line', 0, NULL, NULL UNION ALL
SELECT 234, 69, N'Precise Theme', 0, NULL, NULL UNION ALL
SELECT 235, 69, N'Three-Six-Nine', 0, NULL, NULL UNION ALL
SELECT 236, 75, N'Action', 0, NULL, NULL UNION ALL
SELECT 237, 75, N'Americana', 0, NULL, NULL UNION ALL
SELECT 238, 75, N'American West', 0, NULL, NULL UNION ALL
SELECT 239, 75, N'Baby Love', 0, NULL, NULL UNION ALL
SELECT 240, 75, N'Bodice Ripper', 0, NULL, NULL UNION ALL
SELECT 241, 75, N'Civil War', 0, NULL, NULL UNION ALL
SELECT 242, 75, N'Colonial America', 0, NULL, NULL UNION ALL
SELECT 243, 75, N'Contemporary', 0, NULL, NULL UNION ALL
SELECT 244, 75, N'Exotic Locales', 0, NULL, NULL UNION ALL
SELECT 245, 75, N'Family Saga', 0, NULL, NULL UNION ALL
SELECT 246, 75, N'Futuristic', 0, NULL, NULL UNION ALL
SELECT 247, 75, N'Glitz/Glamour', 0, NULL, NULL UNION ALL
SELECT 248, 75, N'Gothic', 0, NULL, NULL UNION ALL
SELECT 249, 75, N'Historical', 0, NULL, NULL UNION ALL
SELECT 250, 75, N'Indigenous/Primitive', 0, NULL, NULL
COMMIT;
RAISERROR (N'[dbo].[Genre]: Insert Batch: 5.....Done!', 10, 1) WITH NOWAIT;
GO

BEGIN TRANSACTION;
INSERT INTO [dbo].[Genre]([GenreKey], [ParentGenreKey], [GenreName], [Archaic], [Defined], [DefinitionSource])
SELECT 251, 75, N'Inspirational/Spiritual', 0, NULL, NULL UNION ALL
SELECT 252, 75, N'Lesbian', 0, NULL, NULL UNION ALL
SELECT 253, 75, N'Medical', 0, NULL, NULL UNION ALL
SELECT 254, 75, N'Men''s', 0, NULL, NULL UNION ALL
SELECT 255, 75, N'Multicultural', 0, NULL, NULL UNION ALL
SELECT 256, 75, N'Paranormal', 0, NULL, NULL UNION ALL
SELECT 257, 75, N'Regency', 0, NULL, NULL UNION ALL
SELECT 258, 75, N'Romantic Suspense', 0, NULL, NULL UNION ALL
SELECT 259, 75, N'Romentics', 0, NULL, NULL UNION ALL
SELECT 260, 75, N'Ruritanian', 1, NULL, NULL UNION ALL
SELECT 261, 75, N'Sensual/Spicy', 0, NULL, NULL UNION ALL
SELECT 262, 75, N'Sweet/Gentle', 0, NULL, NULL UNION ALL
SELECT 263, 75, N'Time Travel', 0, NULL, NULL UNION ALL
SELECT 264, 238, N'Precolombian', 0, NULL, NULL UNION ALL
SELECT 265, 246, N'Other Planets', 0, NULL, NULL UNION ALL
SELECT 266, 249, N'Elizabethan', 0, NULL, NULL UNION ALL
SELECT 267, 249, N'Georgian', 0, NULL, NULL UNION ALL
SELECT 268, 249, N'Medieval', 0, NULL, NULL UNION ALL
SELECT 269, 249, N'Tudor', 0, NULL, NULL UNION ALL
SELECT 270, 249, N'Viking', 0, NULL, NULL UNION ALL
SELECT 271, 251, N'Christian', 0, NULL, NULL UNION ALL
SELECT 272, 251, N'New Age', 0, NULL, NULL UNION ALL
SELECT 273, 78, N'Family', 0, NULL, NULL UNION ALL
SELECT 274, 78, N'Gaweda', 0, NULL, NULL UNION ALL
SELECT 275, 78, N'Mock', 0, NULL, NULL UNION ALL
SELECT 276, 78, N'Roman Fleuve', 0, NULL, NULL UNION ALL
SELECT 277, 79, N'Burlesque/Travesty', 0, NULL, NULL UNION ALL
SELECT 278, 79, N'Farce', 0, NULL, NULL UNION ALL
SELECT 279, 79, N'Horatian', 0, NULL, NULL UNION ALL
SELECT 280, 79, N'Juvenalian', 0, NULL, NULL UNION ALL
SELECT 281, 79, N'Parody', 0, NULL, NULL UNION ALL
SELECT 282, 4, N'Age Regression', 0, NULL, NULL UNION ALL
SELECT 283, 4, N'Alien Invasion', 0, NULL, NULL UNION ALL
SELECT 284, 4, N'Alternate Histories', 0, NULL, NULL UNION ALL
SELECT 285, 4, N'Apocalyptic', 0, NULL, NULL UNION ALL
SELECT 286, 4, N'Artificial Intelligence', 0, NULL, NULL UNION ALL
SELECT 287, 4, N'Astrobiology', 0, NULL, NULL UNION ALL
SELECT 288, 4, N'Astrosociobiology', 0, NULL, NULL UNION ALL
SELECT 289, 4, N'Biopunk', 0, NULL, NULL UNION ALL
SELECT 290, 4, N'Biorobotics', 0, NULL, NULL UNION ALL
SELECT 291, 4, N'Christian', 0, NULL, NULL UNION ALL
SELECT 292, 4, N'Clerical', 0, NULL, NULL UNION ALL
SELECT 293, 4, N'Communalness', 0, NULL, NULL UNION ALL
SELECT 294, 4, N'Cosy Catastrophe', 0, NULL, NULL UNION ALL
SELECT 295, 4, N'Cybernetic Revolt', 0, NULL, NULL UNION ALL
SELECT 296, 4, N'Cyberpunk', 0, NULL, NULL UNION ALL
SELECT 297, 4, N'Cyberspace', 0, NULL, NULL UNION ALL
SELECT 298, 4, N'Cyborg', 0, NULL, NULL UNION ALL
SELECT 299, 4, N'Detective', 0, NULL, NULL UNION ALL
SELECT 300, 4, N'Dying Earth', 0, NULL, NULL
COMMIT;
RAISERROR (N'[dbo].[Genre]: Insert Batch: 6.....Done!', 10, 1) WITH NOWAIT;
GO

BEGIN TRANSACTION;
INSERT INTO [dbo].[Genre]([GenreKey], [ParentGenreKey], [GenreName], [Archaic], [Defined], [DefinitionSource])
SELECT 301, 4, N'Dystopian', 0, NULL, NULL UNION ALL
SELECT 302, 4, N'Edisonade', 1, NULL, NULL UNION ALL
SELECT 303, 4, N'Environmental', 0, NULL, NULL UNION ALL
SELECT 304, 4, N'Erotica', 0, NULL, NULL UNION ALL
SELECT 305, 4, N'Exotic Ecosystems', 0, NULL, NULL UNION ALL
SELECT 306, 4, N'Extraterrestrial Life', 0, NULL, NULL UNION ALL
SELECT 307, 4, N'Firm Science', 0, NULL, NULL UNION ALL
SELECT 308, 4, N'First Encounters', 0, NULL, NULL UNION ALL
SELECT 309, 4, N'First Landings', 0, NULL, NULL UNION ALL
SELECT 310, 4, N'Frontier', 0, NULL, NULL UNION ALL
SELECT 311, 4, N'Gay', 0, NULL, NULL UNION ALL
SELECT 312, 4, N'Generation Ship', 0, NULL, NULL UNION ALL
SELECT 313, 4, N'Gothic', 0, NULL, NULL UNION ALL
SELECT 314, 4, N'Hard', 0, NULL, NULL UNION ALL
SELECT 315, 4, N'Hollow Earth', 0, NULL, NULL UNION ALL
SELECT 316, 4, N'Horrific', 0, NULL, NULL UNION ALL
SELECT 317, 4, N'Hyperspace', 0, NULL, NULL UNION ALL
SELECT 318, 4, N'Immortality', 0, NULL, NULL UNION ALL
SELECT 319, 4, N'Invisibility', 0, NULL, NULL UNION ALL
SELECT 320, 4, N'Kaiju/Tokusatsu', 0, NULL, NULL UNION ALL
SELECT 321, 4, N'Lesbian', 0, NULL, NULL UNION ALL
SELECT 322, 4, N'Light/Humorous', 0, NULL, NULL UNION ALL
SELECT 323, 4, N'Lost Worlds', 0, NULL, NULL UNION ALL
SELECT 324, 4, N'Math', 0, NULL, NULL UNION ALL
SELECT 325, 4, N'Media Tie-In', 0, NULL, NULL UNION ALL
SELECT 326, 4, N'Microbiological', 0, NULL, NULL UNION ALL
SELECT 327, 4, N'Military', 0, NULL, NULL UNION ALL
SELECT 328, 4, N'Mind Transfer', 0, NULL, NULL UNION ALL
SELECT 329, 4, N'Multiverse', 0, NULL, NULL UNION ALL
SELECT 330, 4, N'Mundane', 0, NULL, NULL UNION ALL
SELECT 331, 4, N'Mythological', 0, NULL, NULL UNION ALL
SELECT 332, 4, N'New Wave', 0, NULL, NULL UNION ALL
SELECT 333, 4, N'Nanopunk', 0, NULL, NULL UNION ALL
SELECT 334, 4, N'Occupational', 0, NULL, NULL UNION ALL
SELECT 335, 4, N'Parallel Universe', 0, NULL, NULL UNION ALL
SELECT 336, 4, N'Pastoral/Small Town', 0, NULL, NULL UNION ALL
SELECT 337, 4, N'Planes of Existence', 0, NULL, NULL UNION ALL
SELECT 338, 4, N'Planetary Romance', 0, NULL, NULL UNION ALL
SELECT 339, 4, N'Post-Apocalyptic', 0, NULL, NULL UNION ALL
SELECT 340, 4, N'Postcyberpunk', 0, NULL, NULL UNION ALL
SELECT 341, 4, N'Posthumanism', 0, NULL, NULL UNION ALL
SELECT 342, 4, N'Progenitive', 0, NULL, NULL UNION ALL
SELECT 343, 4, N'Pulp', 0, NULL, NULL UNION ALL
SELECT 344, 4, N'Recursive', 0, NULL, NULL UNION ALL
SELECT 345, 4, N'Religious', 0, NULL, NULL UNION ALL
SELECT 346, 4, N'Restored Eden', 0, NULL, NULL UNION ALL
SELECT 347, 4, N'Retro-Futurism', 0, NULL, NULL UNION ALL
SELECT 348, 4, N'Robot', 0, NULL, NULL UNION ALL
SELECT 349, 4, N'Science Fantasy', 0, NULL, NULL UNION ALL
SELECT 350, 4, N'Science Tales', 0, NULL, NULL
COMMIT;
RAISERROR (N'[dbo].[Genre]: Insert Batch: 7.....Done!', 10, 1) WITH NOWAIT;
GO

BEGIN TRANSACTION;
INSERT INTO [dbo].[Genre]([GenreKey], [ParentGenreKey], [GenreName], [Archaic], [Defined], [DefinitionSource])
SELECT 351, 4, N'Scientific Romance', 1, NULL, NULL UNION ALL
SELECT 352, 4, N'Shapeshifting', 0, NULL, NULL UNION ALL
SELECT 353, 4, N'Shrinking/Enlarging Humans', 0, NULL, NULL UNION ALL
SELECT 354, 4, N'Social', 0, NULL, NULL UNION ALL
SELECT 355, 4, N'Soft', 0, NULL, NULL UNION ALL
SELECT 356, 4, N'Space Opera', 0, NULL, NULL UNION ALL
SELECT 357, 4, N'Sports', 0, NULL, NULL UNION ALL
SELECT 358, 4, N'Spunky Heroine', 0, NULL, NULL UNION ALL
SELECT 359, 4, N'SpyFi', 0, NULL, NULL UNION ALL
SELECT 360, 4, N'Steampunk', 0, NULL, NULL UNION ALL
SELECT 361, 4, N'Stylistic', 0, NULL, NULL UNION ALL
SELECT 362, 4, N'Sword and Planet', 0, NULL, NULL UNION ALL
SELECT 363, 4, N'Synthetic Biology', 0, NULL, NULL UNION ALL
SELECT 364, 4, N'Terraforming', 0, NULL, NULL UNION ALL
SELECT 365, 4, N'Time Travel', 0, NULL, NULL UNION ALL
SELECT 366, 4, N'Transhumanism', 0, NULL, NULL UNION ALL
SELECT 367, 4, N'Undersea', 0, NULL, NULL UNION ALL
SELECT 368, 4, N'Utopian', 0, NULL, NULL UNION ALL
SELECT 369, 4, N'Voyages Extrraordinaires', 0, NULL, NULL UNION ALL
SELECT 370, 4, N'Wetware Computer', 0, NULL, NULL UNION ALL
SELECT 371, 4, N'World-Building', 0, NULL, NULL UNION ALL
SELECT 372, 4, N'World Government', 0, NULL, NULL UNION ALL
SELECT 373, 4, N'Xenofiction', 0, NULL, NULL UNION ALL
SELECT 374, 285, N'Asteroid Hit', 0, NULL, NULL UNION ALL
SELECT 375, 285, N'Gonzo Apocalypse', 0, NULL, NULL UNION ALL
SELECT 376, 285, N'Nuclear War', 0, NULL, NULL UNION ALL
SELECT 377, 285, N'Pandemic', 0, NULL, NULL UNION ALL
SELECT 378, 299, N'Robotic Police', 0, NULL, NULL UNION ALL
SELECT 379, 299, N'Telepathic Investigation', 0, NULL, NULL UNION ALL
SELECT 380, 301, N'Crowded World', 0, NULL, NULL UNION ALL
SELECT 381, 301, N'Gilded Cage', 0, NULL, NULL UNION ALL
SELECT 382, 301, N'Jaded Society', 0, NULL, NULL UNION ALL
SELECT 383, 301, N'Theocracy', 0, NULL, NULL UNION ALL
SELECT 384, 309, N'Mars', 0, NULL, NULL UNION ALL
SELECT 385, 309, N'Other Planets', 0, NULL, NULL UNION ALL
SELECT 386, 309, N'Return to Moon', 0, NULL, NULL UNION ALL
SELECT 387, 310, N'Asteroid Miners', 0, NULL, NULL UNION ALL
SELECT 388, 310, N'Rough Colony', 0, NULL, NULL UNION ALL
SELECT 389, 310, N'Theme Park', 0, NULL, NULL UNION ALL
SELECT 390, 323, N'Mysterious Islands', 0, NULL, NULL UNION ALL
SELECT 391, 334, N'Accountants', 0, NULL, NULL UNION ALL
SELECT 392, 334, N'Drivers', 0, NULL, NULL UNION ALL
SELECT 393, 334, N'Plumbers', 0, NULL, NULL UNION ALL
SELECT 394, 334, N'Sales Reps', 0, NULL, NULL UNION ALL
SELECT 395, 337, N'Altered Conciousness', 0, NULL, NULL UNION ALL
SELECT 396, 345, N'Alien Faiths', 0, NULL, NULL UNION ALL
SELECT 397, 345, N'Hindu', 0, NULL, NULL UNION ALL
SELECT 398, 345, N'Islamic', 0, NULL, NULL UNION ALL
SELECT 399, 345, N'Jewish', 0, NULL, NULL UNION ALL
SELECT 400, 353, N'Endless', 0, NULL, NULL
COMMIT;
RAISERROR (N'[dbo].[Genre]: Insert Batch: 8.....Done!', 10, 1) WITH NOWAIT;
GO

BEGIN TRANSACTION;
INSERT INTO [dbo].[Genre]([GenreKey], [ParentGenreKey], [GenreName], [Archaic], [Defined], [DefinitionSource])
SELECT 401, 353, N'Episodic', 0, NULL, NULL UNION ALL
SELECT 402, 353, N'Endless', 0, NULL, NULL UNION ALL
SELECT 403, 356, N'Noir', 0, NULL, NULL UNION ALL
SELECT 404, 360, N'Gaslight', 0, NULL, NULL UNION ALL
SELECT 405, 360, N'Weird West', 0, NULL, NULL UNION ALL
SELECT 406, 361, N'Dickian', 0, NULL, NULL UNION ALL
SELECT 407, 361, N'Gonzo', 0, NULL, NULL UNION ALL
SELECT 408, 365, N'Timepunk', 0, NULL, NULL UNION ALL
SELECT 409, 368, N'19th Century Visions', 1, NULL, NULL UNION ALL
SELECT 410, 368, N'Ideological', 0, NULL, NULL UNION ALL
SELECT 411, 368, N'New Age', 0, NULL, NULL UNION ALL
SELECT 412, 82, N'55 Fiction', 0, NULL, NULL UNION ALL
SELECT 413, 82, N'Drabble', 0, NULL, NULL UNION ALL
SELECT 414, 82, N'Flash', 0, NULL, NULL UNION ALL
SELECT 415, 82, N'Microfiction', 0, NULL, NULL UNION ALL
SELECT 416, 82, N'Pinhead', 0, NULL, NULL UNION ALL
SELECT 417, 82, N'Six Word', 0, NULL, NULL UNION ALL
SELECT 418, 82, N'Twitterfic', 0, NULL, NULL UNION ALL
SELECT 419, 86, N'Contemporary', 0, NULL, NULL UNION ALL
SELECT 420, 86, N'Historical', 0, NULL, NULL UNION ALL
SELECT 421, 89, N'Aviation', 0, NULL, NULL UNION ALL
SELECT 422, 89, N'Comedic', 0, NULL, NULL UNION ALL
SELECT 423, 89, N'Conspiracy', 0, NULL, NULL UNION ALL
SELECT 424, 89, N'Disaster', 0, NULL, NULL UNION ALL
SELECT 425, 89, N'Ecothriller', 0, NULL, NULL UNION ALL
SELECT 426, 89, N'Espionage', 0, NULL, NULL UNION ALL
SELECT 427, 89, N'Legal', 0, NULL, NULL UNION ALL
SELECT 428, 89, N'Medical', 0, NULL, NULL UNION ALL
SELECT 429, 89, N'Mercenary', 0, NULL, NULL UNION ALL
SELECT 430, 89, N'Paranormal/Supernatural', 0, NULL, NULL UNION ALL
SELECT 431, 89, N'Political', 0, NULL, NULL UNION ALL
SELECT 432, 89, N'Psychological', 0, NULL, NULL UNION ALL
SELECT 433, 89, N'Religious', 0, NULL, NULL UNION ALL
SELECT 434, 89, N'Survivalist', 0, NULL, NULL UNION ALL
SELECT 435, 89, N'Technothriller', 0, NULL, NULL UNION ALL
SELECT 436, 89, N'Treasure Hunter', 0, NULL, NULL UNION ALL
SELECT 437, 90, N'Revenge', 0, NULL, NULL UNION ALL
SELECT 438, 90, N'Romance', 0, NULL, NULL UNION ALL
SELECT 439, 97, N'Australian', 0, NULL, NULL UNION ALL
SELECT 440, 97, N'Black Cowboy', 0, NULL, NULL UNION ALL
SELECT 441, 97, N'Bounty Hunter', 0, NULL, NULL UNION ALL
SELECT 442, 97, N'Cattle Drive', 0, NULL, NULL UNION ALL
SELECT 443, 97, N'Civil War', 0, NULL, NULL UNION ALL
SELECT 444, 97, N'Cowpunk', 0, NULL, NULL UNION ALL
SELECT 445, 97, N'Doctor and Preacher', 0, NULL, NULL UNION ALL
SELECT 446, 97, N'Eurowestern', 0, NULL, NULL UNION ALL
SELECT 447, 97, N'Gunfighter', 0, NULL, NULL UNION ALL
SELECT 448, 97, N'Humorous/Parody', 0, NULL, NULL UNION ALL
SELECT 449, 97, N'Indian Wars', 0, NULL, NULL UNION ALL
SELECT 450, 97, N'Land Rush', 0, NULL, NULL
COMMIT;
RAISERROR (N'[dbo].[Genre]: Insert Batch: 9.....Done!', 10, 1) WITH NOWAIT;
GO

BEGIN TRANSACTION;
INSERT INTO [dbo].[Genre]([GenreKey], [ParentGenreKey], [GenreName], [Archaic], [Defined], [DefinitionSource])
SELECT 451, 97, N'Lawmen', 0, NULL, NULL UNION ALL
SELECT 452, 97, N'Mexican Wars', 0, NULL, NULL UNION ALL
SELECT 453, 97, N'Modern Indians', 0, NULL, NULL UNION ALL
SELECT 454, 97, N'Mormon', 0, NULL, NULL UNION ALL
SELECT 455, 97, N'Outlaw', 0, NULL, NULL UNION ALL
SELECT 456, 97, N'Prairie Settlement', 0, NULL, NULL UNION ALL
SELECT 457, 97, N'Prospecting', 0, NULL, NULL UNION ALL
SELECT 458, 97, N'Quest', 0, NULL, NULL UNION ALL
SELECT 459, 97, N'Railroad', 0, NULL, NULL UNION ALL
SELECT 460, 97, N'Range Wars', 0, NULL, NULL UNION ALL
SELECT 461, 97, N'Revenge', 0, NULL, NULL UNION ALL
SELECT 462, 97, N'Romance', 0, NULL, NULL UNION ALL
SELECT 463, 97, N'Town-Tamer', 0, NULL, NULL UNION ALL
SELECT 464, 97, N'Trapper/Mountain Man', 0, NULL, NULL UNION ALL
SELECT 465, 97, N'Wagon Train', 0, NULL, NULL UNION ALL
SELECT 466, 97, N'Women', 0, NULL, NULL UNION ALL
SELECT 467, 440, N'Buffalo Soldier', 0, NULL, NULL UNION ALL
SELECT 468, 451, N'Texas Rangers', 0, NULL, NULL UNION ALL
SELECT 469, 452, N'Texan Independence', 0, NULL, NULL UNION ALL
SELECT 470, 457, N'Gold Rushes', 0, NULL, NULL UNION ALL
SELECT 471, 460, N'Sheepmen', 0, NULL, NULL UNION ALL
SELECT 472, 98, N'Amateur Sleuth', 0, NULL, NULL UNION ALL
SELECT 473, 98, N'Christian/Jewish', 0, NULL, NULL UNION ALL
SELECT 474, 98, N'Fantasy', 0, NULL, NULL UNION ALL
SELECT 475, 98, N'Gay Teen', 0, NULL, NULL UNION ALL
SELECT 476, 98, N'Historical', 0, NULL, NULL UNION ALL
SELECT 477, 98, N'Other', 0, NULL, NULL UNION ALL
SELECT 478, 98, N'Realistic Life', 0, NULL, NULL UNION ALL
SELECT 479, 98, N'Science Fiction', 0, NULL, NULL UNION ALL
SELECT 480, 474, N'Comedic', 0, NULL, NULL UNION ALL
SELECT 481, 474, N'Scary', 0, NULL, NULL UNION ALL
SELECT 482, 475, N'Lesbian', 0, NULL, NULL
COMMIT;
RAISERROR (N'[dbo].[Genre]: Insert Batch: 10.....Done!', 10, 1) WITH NOWAIT;
GO

SET IDENTITY_INSERT [dbo].[Genre] OFF;

ALTER TABLE dbo.Genre WITH CHECK
	ADD CONSTRAINT FK_Genre_ParentGenreKey FOREIGN KEY (ParentGenreKey)
    REFERENCES dbo.Genre (GenreKey) ;

--Populate Title table
SET IDENTITY_INSERT [dbo].[Title] ON;
BEGIN TRANSACTION;
INSERT INTO [dbo].[Title]([TitleKey], [TitleName], [AuthorKey], [SeriesKey], [FormatKey], [GenreKey], [SubGenreKey], [Completed])
SELECT 1, N'In the Company of Ogres', 3, NULL, 3, 327, NULL, 1 UNION ALL
SELECT 2, N'Imperfect Birds', 4, NULL, 3, 29, NULL, 1 UNION ALL
SELECT 3, N'Rosie', 4, NULL, 4, 51, NULL, 1 UNION ALL
SELECT 4, N'Joe Jones', 4, NULL, 4, 51, NULL, 1 UNION ALL
SELECT 5, N'All New People', 4, NULL, 4, 51, NULL, 1 UNION ALL
SELECT 6, N'Crooked Little Heart', 4, NULL, 4, 51, NULL, 1 UNION ALL
SELECT 7, N'Operating Instructions: A Journal of my Son''s First Year', 4, NULL, 4, NULL, NULL, 1 UNION ALL
SELECT 8, N'Bird by Bird: Some Instructions on Writing and Life', 4, NULL, 4, NULL, NULL, 1 UNION ALL
SELECT 9, N'Traveling Mercies: Some Thoughts on Faith', 4, NULL, 1, NULL, NULL, 1 UNION ALL
SELECT 10, N'Plan B: Further Thoughts on Faith', 4, NULL, 4, NULL, NULL, 1 UNION ALL
SELECT 11, N'The Poisonwood Bible: A Novel', 5, NULL, 4, 44, NULL, 1 UNION ALL
SELECT 12, N'A Walk in the Woods: Rediscovering America on the Appalachian Trail', 6, NULL, 1, NULL, NULL, 1 UNION ALL
SELECT 13, N'A Short History of Nearly Everything', 6, NULL, 2, NULL, NULL, 1 UNION ALL
SELECT 14, N'The Life and Times of the Thunderbolt Kid', 6, NULL, 4, NULL, NULL, 1 UNION ALL
SELECT 15, N'The Way of Kings', 7, NULL, 3, 142, NULL, 1 UNION ALL
SELECT 16, N'The Well of Ascension', 7, 11, 3, 142, NULL, 1 UNION ALL
SELECT 17, N'Mistborn', 7, 11, 4, 142, NULL, 1 UNION ALL
SELECT 18, N'The Hero of Ages', 7, 11, 3, 142, NULL, 1 UNION ALL
SELECT 19, N'Elantris', 7, NULL, 4, 142, NULL, 1 UNION ALL
SELECT 20, N'Warbreaker', 7, NULL, 2, 142, NULL, 1 UNION ALL
SELECT 21, N'The Black Prism', 8, 9, 3, 142, NULL, 1 UNION ALL
SELECT 22, N'The Way of Shadows', 8, 12, 3, 146, NULL, 1 UNION ALL
SELECT 23, N'Shadow''s Edge', 8, 12, 3, 146, NULL, 1 UNION ALL
SELECT 24, N'Beyond the Shadows', 8, 12, 3, 146, NULL, 1 UNION ALL
SELECT 25, N'Dead in the Family: A Sookie Stackhouse Novel', 9, 15, 3, 154, NULL, 1 UNION ALL
SELECT 26, N'Dead and Gone', 9, 15, 3, 154, NULL, 1 UNION ALL
SELECT 27, N'From Dead to Worse: A Sookie Stackhouse Novel', 9, 15, 3, 154, NULL, 1 UNION ALL
SELECT 28, N'Dead Until Dark', 9, 15, 4, 154, NULL, 1 UNION ALL
SELECT 29, N'Living Dead in Dallas', 9, 15, 4, 154, NULL, 1 UNION ALL
SELECT 30, N'Club Dead', 9, 15, 4, 154, NULL, 1 UNION ALL
SELECT 31, N'Dead to the World', 9, 15, 4, 154, NULL, 1 UNION ALL
SELECT 32, N'Dead as a Doornail', 9, 15, 4, 154, NULL, 1 UNION ALL
SELECT 33, N'Definitely Dead', 9, 15, 4, 154, NULL, 1 UNION ALL
SELECT 34, N'All Together Dead', 9, 15, 4, 154, NULL, 1 UNION ALL
SELECT 35, N'My Horizontal Life', 10, NULL, 3, NULL, NULL, 1 UNION ALL
SELECT 36, N'Fool', 11, NULL, 3, 7, NULL, 1 UNION ALL
SELECT 37, N'Practical Demonkeeping', 11, NULL, 3, 132, NULL, 1 UNION ALL
SELECT 38, N'The Stupidest Angel', 11, NULL, 3, 132, NULL, 1 UNION ALL
SELECT 39, N'Lust Lizard of Melancholy Cove', 11, NULL, 3, 132, NULL, 1 UNION ALL
SELECT 40, N'Island of the Sequined Love Nun', 11, NULL, 3, 132, NULL, 1 UNION ALL
SELECT 41, N'A Dirty Job', 11, NULL, 3, 132, NULL, 1 UNION ALL
SELECT 42, N'Fluke', 11, NULL, 3, 7, NULL, 1 UNION ALL
SELECT 43, N'Bloodsucking Fiends', 11, NULL, 4, 152, NULL, 1 UNION ALL
SELECT 44, N'Reluctant Swordsman', 12, 14, 3, 151, NULL, 1 UNION ALL
SELECT 45, N'Coming of Wisdom', 12, 14, 3, 151, NULL, 1 UNION ALL
SELECT 46, N'Destiny of the Sword', 12, 14, 3, 151, NULL, 1 UNION ALL
SELECT 47, N'John Dies at the End', 13, NULL, 3, 176, NULL, 1 UNION ALL
SELECT 48, N'The Dream of Perpetual Motion', 14, NULL, 3, 126, NULL, 1 UNION ALL
SELECT 49, N'Outlander', 15, 13, 4, 249, NULL, 1 UNION ALL
SELECT 50, N'Dragonfly in Amber', 15, 13, 4, 249, NULL, 1
COMMIT;
RAISERROR (N'[dbo].[Title]: Insert Batch: 1.....Done!', 10, 1) WITH NOWAIT;
GO

BEGIN TRANSACTION;
INSERT INTO [dbo].[Title]([TitleKey], [TitleName], [AuthorKey], [SeriesKey], [FormatKey], [GenreKey], [SubGenreKey], [Completed])
SELECT 51, N'Voyager', 15, 13, 4, 249, NULL, 1 UNION ALL
SELECT 52, N'Drums of Autumn', 15, 13, 4, 249, NULL, 1 UNION ALL
SELECT 53, N'The Fiery Cross', 15, 13, 4, 249, NULL, 1 UNION ALL
SELECT 54, N'A Breath of Snow and Ashes', 15, 13, 4, 249, NULL, 1 UNION ALL
SELECT 55, N'Lord John and the Private Matter', 15, 13, 4, 249, NULL, 1 UNION ALL
SELECT 56, N'Eat, Pray, Love: One Woman''s Search for Everything Across Italy, India, and Indonesia', 16, NULL, 4, NULL, NULL, 1 UNION ALL
SELECT 57, N'Olive Kitteridge: Fiction', 17, NULL, 3, 51, NULL, 1 UNION ALL
SELECT 58, N'Last Night in Montreal', 18, NULL, 3, 437, NULL, 1 UNION ALL
SELECT 59, N'The Devil in the White City: Murder, Magic, and Madness at the Fair that Changed America', 19, NULL, 4, NULL, NULL, 1 UNION ALL
SELECT 60, N'The Half-Made World', 20, NULL, 3, 126, 404, 1 UNION ALL
SELECT 61, N'The End of History and the Last Man', 21, NULL, 4, NULL, NULL, 1 UNION ALL
SELECT 62, N'Jeff in Venice, Death in Varanasi: A Novel', 22, NULL, 3, 34, NULL, 1 UNION ALL
SELECT 63, N'Wicked: The Life and Times of the Wicked Witch of the West', 23, NULL, 4, 138, NULL, 1 UNION ALL
SELECT 64, N'Wolf Hall: A Novel', 24, NULL, 3, 44, NULL, 1 UNION ALL
SELECT 65, N'Suite Francais', 25, NULL, 2, 51, NULL, 1 UNION ALL
SELECT 66, N'Middlesex: A Novel', 26, NULL, 3, 273, NULL, 1 UNION ALL
SELECT 67, N'The Financial Lives of the Poets', 27, NULL, 3, 115, NULL, 1 UNION ALL
SELECT 68, N'Interpreter of Maladies', 28, NULL, 3, 82, NULL, 1 UNION ALL
SELECT 69, N'The Namesake: A Novel', 28, NULL, 3, NULL, NULL, 1 UNION ALL
SELECT 70, N'The Blade Itself', 29, NULL, 3, 142, NULL, 1 UNION ALL
SELECT 71, N'Before They are Hanged', 29, NULL, 3, 142, NULL, 1 UNION ALL
SELECT 72, N'Last Argument of Kings', 29, NULL, 3, 142, NULL, 1 UNION ALL
SELECT 73, N'The Book of Lost Things', 30, NULL, 3, 126, 137, 1 UNION ALL
SELECT 74, N'Johannes Cabal the Necromancer', 31, NULL, 3, 187, 5, 1 UNION ALL
SELECT 75, N'Then We Came to the End: A Novel', 32, NULL, 2, 277, NULL, 1 UNION ALL
SELECT 76, N'The Help', 33, NULL, 3, 51, NULL, 1 UNION ALL
SELECT 77, N'A Thousand Splendid Suns', 34, NULL, 2, 51, NULL, 1 UNION ALL
SELECT 78, N'The Laughing Corpse', 35, 1, 3, 196, NULL, 1 UNION ALL
SELECT 79, N'Circus of the Damned', 35, 1, 3, 196, NULL, 1 UNION ALL
SELECT 80, N'The Lunatic Caf�', 35, 1, 3, 196, NULL, 1 UNION ALL
SELECT 81, N'Bloody Bones', 35, 1, 3, 196, NULL, 1 UNION ALL
SELECT 82, N'The Killing Dance', 35, 1, 3, 196, NULL, 1 UNION ALL
SELECT 83, N'Burnt Offerings', 35, 1, 3, 196, NULL, 1 UNION ALL
SELECT 84, N'Blue Moon', 35, 1, 3, 196, NULL, 1 UNION ALL
SELECT 85, N'Obsidian Butterfly', 35, 1, 3, 196, NULL, 1 UNION ALL
SELECT 86, N'Narcissus in Chains', 35, 1, 3, 196, NULL, 1 UNION ALL
SELECT 87, N'Cerulean Sins', 35, 1, 3, 196, NULL, 1 UNION ALL
SELECT 88, N'Guilty Pleasures', 35, 1, 4, 196, NULL, 1 UNION ALL
SELECT 89, N'The Magicians: A Novel', 36, NULL, 3, 132, NULL, 1 UNION ALL
SELECT 90, N'Outliers: The Story of Success', 37, NULL, 3, NULL, NULL, 1 UNION ALL
SELECT 91, N'The Oblivion Society', 38, NULL, 3, 176, NULL, 1 UNION ALL
SELECT 92, N'The Curious Incident of the Dog in the Night-Time', 39, NULL, 4, 225, NULL, 1 UNION ALL
SELECT 93, N'The Guernsey Literary and Potato Peel Pie Society', 40, NULL, 3, 51, NULL, 1 UNION ALL
SELECT 94, N'The Zombie Survival Guide: Complete Protection from the Living Dead', 41, NULL, 3, 280, NULL, 1 UNION ALL
SELECT 95, N'The Lesser Evil: Political Ethics in an Age of Terror', 42, NULL, 4, NULL, NULL, 1 UNION ALL
SELECT 96, N'The Devil you Know', 43, 6, 3, 135, NULL, 1 UNION ALL
SELECT 97, N'Vicious Circle', 43, 6, 3, 135, NULL, 1 UNION ALL
SELECT 98, N'Dead Men''s Boots', 43, 6, 3, 135, NULL, 1 UNION ALL
SELECT 99, N'Thicker Than Water', 43, 6, 3, 135, NULL, 1 UNION ALL
SELECT 100, N'The Naming of the Beasts', 43, 6, 3, 135, NULL, 1
COMMIT;
RAISERROR (N'[dbo].[Title]: Insert Batch: 2.....Done!', 10, 1) WITH NOWAIT;
GO

BEGIN TRANSACTION;
INSERT INTO [dbo].[Title]([TitleKey], [TitleName], [AuthorKey], [SeriesKey], [FormatKey], [GenreKey], [SubGenreKey], [Completed])
SELECT 101, N'Zodiac', 44, NULL, 4, 303, NULL, 1 UNION ALL
SELECT 102, N'Snow Crash', 44, NULL, 4, 296, NULL, 1 UNION ALL
SELECT 103, N'The Diamond Age: or A Young Lady''s Illustrated Primer', 44, NULL, 4, 340, NULL, 1 UNION ALL
SELECT 104, N'Cryptonomicon', 44, NULL, 2, 324, NULL, 1 UNION ALL
SELECT 105, N'Quicksilver', 44, NULL, 2, 44, NULL, 1 UNION ALL
SELECT 106, N'The Confusion', 44, NULL, 2, 44, NULL, 1 UNION ALL
SELECT 107, N'The System of the World', 44, NULL, 2, 44, NULL, 1 UNION ALL
SELECT 108, N'Anathem', 44, NULL, 2, 324, NULL, 1 UNION ALL
SELECT 109, N'Good Omens', 45, NULL, 4, 132, NULL, 1 UNION ALL
SELECT 110, N'Neverwhere', 45, NULL, 4, 157, NULL, 1 UNION ALL
SELECT 111, N'Stardust', 45, NULL, 2, 138, NULL, 1 UNION ALL
SELECT 112, N'American Gods', 45, NULL, 4, 159, NULL, 1 UNION ALL
SELECT 113, N'Anasasi Boys', 45, NULL, 4, 159, NULL, 1 UNION ALL
SELECT 114, N'The Graveyard Book', 45, NULL, 1, 145, NULL, 1 UNION ALL
SELECT 115, N'Galveston', 46, NULL, 3, 43, NULL, 1 UNION ALL
SELECT 116, N'Swimming', 47, NULL, 3, 21, NULL, 1 UNION ALL
SELECT 117, N'Ender''s Game', 48, NULL, 4, 327, NULL, 1 UNION ALL
SELECT 118, N'Speaker for the Dead', 48, NULL, 4, 381, NULL, 1 UNION ALL
SELECT 119, N'Xenocide', 48, NULL, 4, 306, NULL, 1 UNION ALL
SELECT 120, N'Ender''s Shadow', 48, NULL, 2, 327, NULL, 1 UNION ALL
SELECT 121, N'Shadow of the Hegemon', 48, NULL, 2, 4, NULL, 1 UNION ALL
SELECT 122, N'Seventh Son', 48, NULL, 4, 12, 154, 1 UNION ALL
SELECT 123, N'Red Prophet', 48, NULL, 4, 12, 154, 1 UNION ALL
SELECT 124, N'Prentice Alvin', 48, NULL, 4, 12, 154, 1 UNION ALL
SELECT 125, N'Alvin Journeyman', 48, NULL, 4, 12, 154, 1 UNION ALL
SELECT 126, N'The Name of the Wind', 49, NULL, 3, 141, NULL, 1 UNION ALL
SELECT 127, N'The Alchemist', 50, NULL, 4, 64, NULL, 1 UNION ALL
SELECT 128, N'The Blue Bottle Club', 51, NULL, 4, 18, NULL, 1 UNION ALL
SELECT 129, N'The Warded Man', 52, 4, 3, 168, NULL, 1 UNION ALL
SELECT 130, N'The Desert Spear', 52, 4, 3, 168, NULL, 1 UNION ALL
SELECT 131, N'Heat Wave', 53, NULL, 3, 220, NULL, 1 UNION ALL
SELECT 132, N'Revolutionary Road', 54, NULL, 4, 51, NULL, 1 UNION ALL
SELECT 133, N'The Four Fingers of Death: A Novel', 55, NULL, 3, 199, 383, 1 UNION ALL
SELECT 134, N'The Man who Sold the Moon', 56, 7, 4, 309, NULL, 1 UNION ALL
SELECT 135, N'Methuselah''s Children', 56, 7, 4, 318, NULL, 1 UNION ALL
SELECT 136, N'Time Enough for Love', 56, 7, 4, 293, NULL, 1 UNION ALL
SELECT 137, N'To Sail Beyond the Sunset', 56, 7, 4, 365, NULL, 1 UNION ALL
SELECT 138, N'The Number of the Beast', 56, 8, 4, 335, NULL, 1 UNION ALL
SELECT 139, N'The Cat Who Walks Through Walls', 56, 8, 4, 299, NULL, 1 UNION ALL
SELECT 140, N'The Moon is a Harsh Mistress', 56, 7, 4, 310, NULL, 1 UNION ALL
SELECT 141, N'Starship Troopers', 56, NULL, 4, 327, NULL, 1 UNION ALL
SELECT 142, N'Stranger in a Strange Land', 56, 8, 2, 347, NULL, 1 UNION ALL
SELECT 143, N'Glory Road', 56, NULL, 4, 349, NULL, 1 UNION ALL
SELECT 144, N'Friday', 56, NULL, 2, 290, NULL, 1 UNION ALL
SELECT 145, N'Job: A Comedy of Justice', 56, NULL, 4, 345, NULL, 1 UNION ALL
SELECT 146, N'Expanded Universe', 56, NULL, 4, NULL, NULL, 1 UNION ALL
SELECT 147, N'The Eye of the World', 57, 24, 4, 142, NULL, 1 UNION ALL
SELECT 148, N'The Great Hunt', 57, 24, 4, 142, NULL, 1 UNION ALL
SELECT 149, N'The Dragon Reborn', 57, 24, 4, 142, NULL, 1 UNION ALL
SELECT 150, N'The Shadow Rising', 57, 24, 4, 142, NULL, 1
COMMIT;
RAISERROR (N'[dbo].[Title]: Insert Batch: 3.....Done!', 10, 1) WITH NOWAIT;
GO

BEGIN TRANSACTION;
INSERT INTO [dbo].[Title]([TitleKey], [TitleName], [AuthorKey], [SeriesKey], [FormatKey], [GenreKey], [SubGenreKey], [Completed])
SELECT 151, N'The Fires of Heaven', 57, 24, 4, 142, NULL, 1 UNION ALL
SELECT 152, N'Lord of Chaos', 57, 24, 4, 142, NULL, 1 UNION ALL
SELECT 153, N'A Crown of Swords', 57, 24, 4, 142, NULL, 1 UNION ALL
SELECT 154, N'The Path of Daggers', 57, 24, 2, 142, NULL, 1 UNION ALL
SELECT 155, N'Winter''s Heart', 57, 24, 2, 142, NULL, 1 UNION ALL
SELECT 156, N'Crossroads of Twilight', 57, 24, 2, 142, NULL, 1 UNION ALL
SELECT 157, N'Knife of Dreams', 57, 24, 2, 142, NULL, 1 UNION ALL
SELECT 158, N'The Gathering Storm', 57, 24, 2, 142, NULL, 1 UNION ALL
SELECT 159, N'Towers of Midnight', 57, 24, 2, 142, NULL, 1 UNION ALL
SELECT 160, N'Zen and the Art of Motorcycle Maintenance: An Inquiry into Values', 58, NULL, 4, NULL, NULL, 1 UNION ALL
SELECT 161, N'Lila: An Inquiry into Morals', 58, NULL, 4, NULL, NULL, 1 UNION ALL
SELECT 162, N'Fifth Avenue, 5 A.M.: Audrey Hepburn, Breakfast at Tiffany�s, and the Dawn of the Modern Woman', 59, NULL, 3, NULL, NULL, 1 UNION ALL
SELECT 163, N'The Little Stranger', 60, NULL, 3, 192, NULL, 1 UNION ALL
SELECT 164, N'The Lies of Locke Lamora', 61, NULL, 3, 146, NULL, 1 UNION ALL
SELECT 165, N'Red Skies Under Red Seas', 61, NULL, 3, 146, NULL, 1 UNION ALL
SELECT 166, N'The Dark Tower: The Gunslinger', 62, NULL, 1, 135, NULL, 1 UNION ALL
SELECT 167, N'The Drawing of the Three', 62, NULL, 4, 135, NULL, 1 UNION ALL
SELECT 168, N'The Waste Lands', 62, NULL, 4, 135, NULL, 1 UNION ALL
SELECT 169, N'Wizard and Glass', 62, NULL, 4, 135, NULL, 1 UNION ALL
SELECT 170, N'Wolves of the Calla', 62, NULL, 4, 135, NULL, 1 UNION ALL
SELECT 171, N'Song of Susannah', 62, NULL, 4, 135, NULL, 1 UNION ALL
SELECT 172, N'The Dark Tower  ', 62, NULL, 4, 135, NULL, 1 UNION ALL
SELECT 173, N'Twilight', 63, NULL, 4, 152, NULL, 1 UNION ALL
SELECT 174, N'The Girl with the Dragon Tattoo', 64, 10, 3, 25, NULL, 1 UNION ALL
SELECT 175, N'The Girl who Played with Fire', 64, 10, 3, 25, NULL, 1 UNION ALL
SELECT 176, N'The Girl who Kicked the Hornet''s Nest', 64, 10, 3, 25, NULL, 1 UNION ALL
SELECT 177, N'Nation', 65, NULL, 3, 145, NULL, 1 UNION ALL
SELECT 178, N'The Colour of Magic', 65, 5, 4, 132, NULL, 1 UNION ALL
SELECT 179, N'The Light Fantastic', 65, 5, 4, 132, NULL, 1 UNION ALL
SELECT 180, N'Equal Rites', 65, 5, 4, 132, NULL, 1 UNION ALL
SELECT 181, N'Mort', 65, 5, 4, 132, NULL, 1 UNION ALL
SELECT 182, N'Sourcery', 65, 5, 4, 132, NULL, 1 UNION ALL
SELECT 183, N'Wyrd Sisters', 65, 5, 4, 132, NULL, 1 UNION ALL
SELECT 184, N'Pyramids', 65, 5, 4, 132, NULL, 1 UNION ALL
SELECT 185, N'Guards! Guards!', 65, 5, 4, 132, NULL, 1 UNION ALL
SELECT 186, N'Eric', 65, 5, 4, 132, NULL, 1 UNION ALL
SELECT 187, N'Moving Pictures', 65, 5, 4, 132, NULL, 1 UNION ALL
SELECT 188, N'Reaper Man', 65, 5, 4, 132, NULL, 1 UNION ALL
SELECT 189, N'Witches Abroad', 65, 5, 4, 132, NULL, 1 UNION ALL
SELECT 190, N'Small Gods', 65, 5, 4, 132, NULL, 1 UNION ALL
SELECT 191, N'Lords and Ladies', 65, 5, 4, 132, NULL, 1 UNION ALL
SELECT 192, N'Men at Arms', 65, 5, 4, 132, NULL, 1 UNION ALL
SELECT 193, N'Soul Music', 65, 5, 4, 132, NULL, 1 UNION ALL
SELECT 194, N'Interesting Times', 65, 5, 4, 132, NULL, 1 UNION ALL
SELECT 195, N'Maskerade', 65, 5, 4, 132, NULL, 1 UNION ALL
SELECT 196, N'Feet of Clay', 65, 5, 4, 132, NULL, 1 UNION ALL
SELECT 197, N'Hogfather', 65, 5, 4, 132, NULL, 1 UNION ALL
SELECT 198, N'Jingo', 65, 5, 4, 132, NULL, 1 UNION ALL
SELECT 199, N'The Last Continent', 65, 5, 4, 132, NULL, 1 UNION ALL
SELECT 200, N'Carpe Jugulum', 65, 5, 4, 132, NULL, 1
COMMIT;
RAISERROR (N'[dbo].[Title]: Insert Batch: 4.....Done!', 10, 1) WITH NOWAIT;
GO

BEGIN TRANSACTION;
INSERT INTO [dbo].[Title]([TitleKey], [TitleName], [AuthorKey], [SeriesKey], [FormatKey], [GenreKey], [SubGenreKey], [Completed])
SELECT 201, N'The Fifth Elephant', 65, 5, 4, 132, NULL, 1 UNION ALL
SELECT 202, N'The Truth', 65, 5, 4, 132, NULL, 1 UNION ALL
SELECT 203, N'Thief of Time', 65, 5, 4, 132, NULL, 1 UNION ALL
SELECT 204, N'The Last Hero', 65, 5, 4, 132, NULL, 1 UNION ALL
SELECT 205, N'Night Watch', 65, 5, 4, 132, NULL, 1 UNION ALL
SELECT 206, N'Monstrous Regiment', 65, 5, 4, 132, NULL, 1 UNION ALL
SELECT 207, N'Going Postal', 65, 5, 4, 132, NULL, 1 UNION ALL
SELECT 208, N'Thud!', 65, 5, 4, 132, NULL, 1 UNION ALL
SELECT 209, N'Making Money', 65, 5, 4, 132, NULL, 1 UNION ALL
SELECT 210, N'Unseen Academicals', 65, 5, 4, 132, NULL, 1 UNION ALL
SELECT 211, N'The World is Flat 3.0: A Brief History of the 21st Century', 66, NULL, 4, NULL, NULL, 1 UNION ALL
SELECT 212, N'Everything Ravaged, Everything Burned: Stories', 67, NULL, 3, 82, NULL, 1 UNION ALL
SELECT 213, N'Zero History', 68, 2, 3, 30, NULL, 1 UNION ALL
SELECT 214, N'Pattern Recognition', 68, 2, 3, 354, NULL, 1 UNION ALL
SELECT 215, N'Spook Country', 68, 2, 3, 431, NULL, 1 UNION ALL
SELECT 216, N'Neuromancer', 68, 16, 4, 296, NULL, 1 UNION ALL
SELECT 217, N'Count Zero', 68, 16, 4, 296, NULL, 1 UNION ALL
SELECT 218, N'Mona Lisa Overdrive', 68, 16, 4, 296, NULL, 1 UNION ALL
SELECT 219, N'Virtual Light', 68, 3, 4, 301, NULL, 1 UNION ALL
SELECT 220, N'Idoru', 68, 3, 4, 301, NULL, 1 UNION ALL
SELECT 221, N'All Tomorrow''s Parties', 68, 3, 4, 301, NULL, 1 UNION ALL
SELECT 222, N'Skippy Dies', 69, NULL, 1, 16, 81, 1
COMMIT;
RAISERROR (N'[dbo].[Title]: Insert Batch: 5.....Done!', 10, 1) WITH NOWAIT;
GO

SET IDENTITY_INSERT [dbo].[Title] OFF;

--Populate ImportBookList

BEGIN TRANSACTION;
INSERT INTO [dbo].[ImportBookList]([GenreKey], [Genre], [SubGenreKey], [SubGenre], [Title], [Author], [Co-Author], [Series Name], [F9], [Number in Series], [Format], [Year Read], [AuthorFirstName], [AuthorLastName], [AuthorMiddleName])
SELECT N'327', N'Military', NULL, NULL, N'In the Company of Ogres', N'A. Lee Martinez', NULL, NULL, NULL, NULL, N'Kindle', NULL, N'A. ', N'Martinez', N'Lee' UNION ALL
SELECT N'29', N'Drama/Realistic', NULL, NULL, N'Imperfect Birds', N'Anne Lamott', NULL, NULL, NULL, NULL, N'Kindle', NULL, N'Anne ', N'Lamott', NULL UNION ALL
SELECT N'51', N'Literary Fiction', NULL, NULL, N'Rosie', N'Anne Lamott', NULL, NULL, NULL, NULL, N'Paperback', NULL, N'Anne ', N'Lamott', NULL UNION ALL
SELECT N'51', N'Literary Fiction', NULL, NULL, N'Joe Jones', N'Anne Lamott', NULL, NULL, NULL, NULL, N'Paperback', NULL, N'Anne ', N'Lamott', NULL UNION ALL
SELECT N'51', N'Literary Fiction', NULL, NULL, N'All New People', N'Anne Lamott', NULL, NULL, NULL, NULL, N'Paperback', NULL, N'Anne ', N'Lamott', NULL UNION ALL
SELECT N'51', N'Literary Fiction', NULL, NULL, N'Crooked Little Heart', N'Anne Lamott', NULL, NULL, NULL, NULL, N'Paperback', NULL, N'Anne ', N'Lamott', NULL UNION ALL
SELECT NULL, N'Parenting', NULL, NULL, N'Operating Instructions: A Journal of my Son''s First Year', N'Anne Lamott', NULL, NULL, NULL, NULL, N'Paperback', NULL, N'Anne ', N'Lamott', NULL UNION ALL
SELECT NULL, N'Writing', NULL, NULL, N'Bird by Bird: Some Instructions on Writing and Life', N'Anne Lamott', NULL, NULL, NULL, NULL, N'Paperback', NULL, N'Anne ', N'Lamott', NULL UNION ALL
SELECT NULL, N'Religion', NULL, NULL, N'Traveling Mercies: Some Thoughts on Faith', N'Anne Lamott', NULL, NULL, NULL, NULL, N'Audio', NULL, N'Anne ', N'Lamott', NULL UNION ALL
SELECT NULL, N'Religion', NULL, NULL, N'Plan B: Further Thoughts on Faith', N'Anne Lamott', NULL, NULL, NULL, NULL, N'Paperback', NULL, N'Anne ', N'Lamott', NULL UNION ALL
SELECT N'44', N'Historical', NULL, NULL, N'The Poisonwood Bible: A Novel', N'Barbara Kingsolver', NULL, NULL, NULL, NULL, N'Paperback', NULL, N'Barbara ', N'Kingsolver', NULL UNION ALL
SELECT NULL, N'Outdoors', NULL, NULL, N'A Walk in the Woods: Rediscovering America on the Appalachian Trail', N'Bill Bryson', NULL, NULL, NULL, NULL, N'Audio', NULL, N'Bill ', N'Bryson', NULL UNION ALL
SELECT NULL, N'History', NULL, NULL, N'A Short History of Nearly Everything', N'Bill Bryson', NULL, NULL, NULL, NULL, N'Hardback', NULL, N'Bill ', N'Bryson', NULL UNION ALL
SELECT NULL, N'Memoir', NULL, NULL, N'The Life and Times of the Thunderbolt Kid', N'Bill Bryson', NULL, NULL, NULL, NULL, N'Paperback', NULL, N'Bill ', N'Bryson', NULL UNION ALL
SELECT N'142', N'High/Epic Fantasy', NULL, NULL, N'The Way of Kings', N'Brandon Sanderson', NULL, N'The Stormlight Archive', NULL, N'1', N'Kindle', NULL, N'Brandon ', N'Sanderson', NULL UNION ALL
SELECT N'142', N'High/Epic Fantasy', NULL, NULL, N'The Well of Ascension', N'Brandon Sanderson', NULL, N'Mistborn Trilogy', NULL, N'2', N'Kindle', NULL, N'Brandon ', N'Sanderson', NULL UNION ALL
SELECT N'142', N'High/Epic Fantasy', NULL, NULL, N'Mistborn', N'Brandon Sanderson', NULL, N'Mistborn Trilogy', NULL, N'1', N'Paperback', NULL, N'Brandon ', N'Sanderson', NULL UNION ALL
SELECT N'142', N'High/Epic Fantasy', NULL, NULL, N'The Hero of Ages', N'Brandon Sanderson', NULL, N'Mistborn Trilogy', NULL, N'3', N'Kindle', NULL, N'Brandon ', N'Sanderson', NULL UNION ALL
SELECT N'142', N'High/Epic Fantasy', NULL, NULL, N'Elantris', N'Brandon Sanderson', NULL, NULL, NULL, NULL, N'Paperback', NULL, N'Brandon ', N'Sanderson', NULL UNION ALL
SELECT N'142', N'High/Epic Fantasy', NULL, NULL, N'Warbreaker', N'Brandon Sanderson', NULL, NULL, NULL, NULL, N'Hardback', NULL, N'Brandon ', N'Sanderson', NULL UNION ALL
SELECT N'142', N'High/Epic Fantasy', NULL, NULL, N'The Black Prism', N'Brent Weeks', NULL, N'Lightbringer Series', NULL, NULL, N'Kindle', NULL, N'Brent ', N'Weeks', NULL UNION ALL
SELECT N'146', N'Low Fantasy', NULL, NULL, N'The Way of Shadows', N'Brent Weeks', NULL, N'Night Angel Trilogy', NULL, N'1', N'Kindle', NULL, N'Brent ', N'Weeks', NULL UNION ALL
SELECT N'146', N'Low Fantasy', NULL, NULL, N'Shadow''s Edge', N'Brent Weeks', NULL, N'Night Angel Trilogy', NULL, N'2', N'Kindle', NULL, N'Brent ', N'Weeks', NULL UNION ALL
SELECT N'146', N'Low Fantasy', NULL, NULL, N'Beyond the Shadows', N'Brent Weeks', NULL, N'Night Angel Trilogy', NULL, N'3', N'Kindle', NULL, N'Brent ', N'Weeks', NULL UNION ALL
SELECT N'154', N'Series', NULL, NULL, N'Dead in the Family: A Sookie Stackhouse Novel', N'Charlaine Harris', NULL, N'Southern Vampire', NULL, NULL, N'Kindle', NULL, N'Charlaine ', N'Harris', NULL UNION ALL
SELECT N'154', N'Series', NULL, NULL, N'Dead and Gone', N'Charlaine Harris', NULL, N'Southern Vampire', NULL, NULL, N'Kindle', NULL, N'Charlaine ', N'Harris', NULL UNION ALL
SELECT N'154', N'Series', NULL, NULL, N'From Dead to Worse: A Sookie Stackhouse Novel', N'Charlaine Harris', NULL, N'Southern Vampire', NULL, NULL, N'Kindle', NULL, N'Charlaine ', N'Harris', NULL UNION ALL
SELECT N'154', N'Series', NULL, NULL, N'Dead Until Dark', N'Charlaine Harris', NULL, N'Southern Vampire ', NULL, N'1', N'Paperback', NULL, N'Charlaine ', N'Harris', NULL UNION ALL
SELECT N'154', N'Series', NULL, NULL, N'Living Dead in Dallas', N'Charlaine Harris', NULL, N'Southern Vampire ', NULL, N'2', N'Paperback', NULL, N'Charlaine ', N'Harris', NULL UNION ALL
SELECT N'154', N'Series', NULL, NULL, N'Club Dead', N'Charlaine Harris', NULL, N'Southern Vampire ', NULL, N'3', N'Paperback', NULL, N'Charlaine ', N'Harris', NULL UNION ALL
SELECT N'154', N'Series', NULL, NULL, N'Dead to the World', N'Charlaine Harris', NULL, N'Southern Vampire ', NULL, N'4', N'Paperback', NULL, N'Charlaine ', N'Harris', NULL UNION ALL
SELECT N'154', N'Series', NULL, NULL, N'Dead as a Doornail', N'Charlaine Harris', NULL, N'Southern Vampire ', NULL, N'5', N'Paperback', NULL, N'Charlaine ', N'Harris', NULL UNION ALL
SELECT N'154', N'Series', NULL, NULL, N'Definitely Dead', N'Charlaine Harris', NULL, N'Southern Vampire ', NULL, N'6', N'Paperback', NULL, N'Charlaine ', N'Harris', NULL UNION ALL
SELECT N'154', N'Series', NULL, NULL, N'All Together Dead', N'Charlaine Harris', NULL, N'Southern Vampire ', NULL, N'7', N'Paperback', NULL, N'Charlaine ', N'Harris', NULL UNION ALL
SELECT NULL, N'Memoir', NULL, NULL, N'My Horizontal Life', N'Chelsea Handler', NULL, NULL, NULL, NULL, N'Kindle', NULL, N'Chelsea ', N'Handler', NULL UNION ALL
SELECT N'7', N'Absurdist', NULL, NULL, N'Fool', N'Christopher Moore', NULL, NULL, NULL, NULL, N'Kindle', NULL, N'Christopher ', N'Moore', NULL UNION ALL
SELECT N'132', N'Comedic', NULL, NULL, N'Practical Demonkeeping', N'Christopher Moore', NULL, NULL, NULL, NULL, N'Kindle', NULL, N'Christopher ', N'Moore', NULL UNION ALL
SELECT N'132', N'Comedic', NULL, NULL, N'The Stupidest Angel', N'Christopher Moore', NULL, NULL, NULL, NULL, N'Kindle', NULL, N'Christopher ', N'Moore', NULL UNION ALL
SELECT N'132', N'Comedic', NULL, NULL, N'Lust Lizard of Melancholy Cove', N'Christopher Moore', NULL, NULL, NULL, NULL, N'Kindle', NULL, N'Christopher ', N'Moore', NULL UNION ALL
SELECT N'132', N'Comedic', NULL, NULL, N'Island of the Sequined Love Nun', N'Christopher Moore', NULL, NULL, NULL, NULL, N'Kindle', NULL, N'Christopher ', N'Moore', NULL UNION ALL
SELECT N'132', N'Comedic', NULL, NULL, N'A Dirty Job', N'Christopher Moore', NULL, NULL, NULL, NULL, N'Kindle', NULL, N'Christopher ', N'Moore', NULL UNION ALL
SELECT N'7', N'Absurdist', NULL, NULL, N'Fluke', N'Christopher Moore', NULL, NULL, NULL, NULL, N'Kindle', NULL, N'Christopher ', N'Moore', NULL UNION ALL
SELECT N'152', N'Romantic', NULL, NULL, N'Bloodsucking Fiends', N'Christopher Moore', NULL, NULL, NULL, NULL, N'Paperback', N'2011', N'Christopher ', N'Moore', NULL UNION ALL
SELECT N'151', N'Quest', NULL, NULL, N'Reluctant Swordsman', N'Dave Duncan', NULL, N'Seventh Sword', NULL, N'1', N'Kindle', NULL, N'Dave ', N'Duncan', NULL UNION ALL
SELECT N'151', N'Quest', NULL, NULL, N'Coming of Wisdom', N'Dave Duncan', NULL, N'Seventh Sword', NULL, N'2', N'Kindle', NULL, N'Dave ', N'Duncan', NULL UNION ALL
SELECT N'151', N'Quest', NULL, NULL, N'Destiny of the Sword', N'Dave Duncan', NULL, N'Seventh Sword', NULL, N'3', N'Kindle', NULL, N'Dave ', N'Duncan', NULL UNION ALL
SELECT N'175', N'Humorous', NULL, NULL, N'John Dies at the End', N'David Wong', NULL, NULL, NULL, NULL, N'Kindle', NULL, N'David ', N'Wong', NULL UNION ALL
SELECT N'126', N'Alternate Worlds', NULL, NULL, N'The Dream of Perpetual Motion', N'Dexter Palmer', NULL, NULL, NULL, NULL, N'Kindle', N'2010', N'Dexter ', N'Palmer', NULL UNION ALL
SELECT N'249', N'Historical', NULL, NULL, N'Outlander', N'Diana Gabaldon', NULL, N'Outlander Series', NULL, N'1', N'Paperback', NULL, N'Diana ', N'Gabaldon', NULL UNION ALL
SELECT N'249', N'Historical', NULL, NULL, N'Dragonfly in Amber', N'Diana Gabaldon', NULL, N'Outlander Series', NULL, N'2', N'Paperback', NULL, N'Diana ', N'Gabaldon', NULL
COMMIT;
RAISERROR (N'[dbo].[ImportBookList]: Insert Batch: 1.....Done!', 10, 1) WITH NOWAIT;
GO

BEGIN TRANSACTION;
INSERT INTO [dbo].[ImportBookList]([GenreKey], [Genre], [SubGenreKey], [SubGenre], [Title], [Author], [Co-Author], [Series Name], [F9], [Number in Series], [Format], [Year Read], [AuthorFirstName], [AuthorLastName], [AuthorMiddleName])
SELECT N'249', N'Historical', NULL, NULL, N'Voyager', N'Diana Gabaldon', NULL, N'Outlander Series', NULL, N'3', N'Paperback', NULL, N'Diana ', N'Gabaldon', NULL UNION ALL
SELECT N'249', N'Historical', NULL, NULL, N'Drums of Autumn', N'Diana Gabaldon', NULL, N'Outlander Series', NULL, N'4', N'Paperback', NULL, N'Diana ', N'Gabaldon', NULL UNION ALL
SELECT N'249', N'Historical', NULL, NULL, N'The Fiery Cross', N'Diana Gabaldon', NULL, N'Outlander Series', NULL, N'5', N'Paperback', NULL, N'Diana ', N'Gabaldon', NULL UNION ALL
SELECT N'249', N'Historical', NULL, NULL, N'A Breath of Snow and Ashes', N'Diana Gabaldon', NULL, N'Outlander Series', NULL, N'6', N'Paperback', NULL, N'Diana ', N'Gabaldon', NULL UNION ALL
SELECT N'249', N'Historical', NULL, NULL, N'Lord John and the Private Matter', N'Diana Gabaldon', NULL, N'Outlander Series', NULL, NULL, N'Paperback', NULL, N'Diana ', N'Gabaldon', NULL UNION ALL
SELECT NULL, N'Travel', NULL, NULL, N'Eat, Pray, Love: One Woman''s Search for Everything Across Italy, India, and Indonesia', N'Elizabeth Gilbert', NULL, NULL, NULL, NULL, N'Paperback', N'2007', N'Elizabeth ', N'Gilbert', NULL UNION ALL
SELECT N'51', N'Literary Fiction', NULL, NULL, N'Olive Kitteridge: Fiction', N'Elizabeth Strout', NULL, NULL, NULL, NULL, N'Kindle', NULL, N'Elizabeth ', N'Strout', NULL UNION ALL
SELECT N'437', N'Romance', NULL, NULL, N'Last Night in Montreal', N'Emily St. John Mandel', NULL, NULL, NULL, NULL, N'Kindle', NULL, N'Emily ', N'St. John Mandel', NULL UNION ALL
SELECT NULL, N'Serial Killer', NULL, NULL, N'The Devil in the White City: Murder, Magic, and Madness at the Fair that Changed America', N'Erik Larson', NULL, NULL, NULL, NULL, N'Paperback', NULL, N'Erik ', N'Larson', NULL UNION ALL
SELECT N'126', N'Alternate Worlds', N'404', N'Weird West', N'The Half-Made World', N'Felix Gilman', NULL, NULL, NULL, NULL, N'Kindle', N'2010', N'Felix ', N'Gilman', NULL UNION ALL
SELECT NULL, N'Political', NULL, NULL, N'The End of History and the Last Man', N'Francis Fukuyama', NULL, NULL, NULL, NULL, N'Paperback', N'2008', N'Francis ', N'Fukuyama', NULL UNION ALL
SELECT N'34', N'Existentialist', NULL, NULL, N'Jeff in Venice, Death in Varanasi: A Novel', N'Geoff Dyer', NULL, NULL, NULL, NULL, N'Kindle', NULL, N'Geoff ', N'Dyer', NULL UNION ALL
SELECT N'138', N'Fairy Tale', NULL, NULL, N'Wicked: The Life and Times of the Wicked Witch of the West', N'Gregory Maguire', NULL, NULL, NULL, NULL, N'Paperback', N'2005', N'Gregory ', N'Maguire', NULL UNION ALL
SELECT N'44', N'Historical', NULL, NULL, N'Wolf Hall: A Novel', N'Hilary Mantel', NULL, NULL, NULL, NULL, N'Kindle', NULL, N'Hilary ', N'Mantel', NULL UNION ALL
SELECT N'51', N'Literary Fiction', NULL, NULL, N'Suite Francais', N'Irene Nemirovsky', NULL, NULL, NULL, NULL, N'Hardback', N'2007', N'Irene ', N'Nemirovsky', NULL UNION ALL
SELECT N'273', N'Family', NULL, NULL, N'Middlesex: A Novel', N'Jeffrey Eugenides', NULL, NULL, NULL, NULL, N'Kindle', NULL, N'Jeffrey ', N'Eugenides', NULL UNION ALL
SELECT N'115', N'Over-the-Top', NULL, NULL, N'The Financial Lives of the Poets', N'Jess Walter', NULL, NULL, NULL, NULL, N'Kindle', NULL, N'Jess ', N'Walter', NULL UNION ALL
SELECT N'82', N'Short Fiction', NULL, NULL, N'Interpreter of Maladies', N'Jhumpa Lahiri', NULL, NULL, NULL, NULL, N'Kindle', NULL, N'Jhumpa ', N'Lahiri', NULL UNION ALL
SELECT NULL, NULL, NULL, NULL, N'The Namesake: A Novel', N'Jhumpa Lahiri', NULL, NULL, NULL, NULL, N'Kindle', NULL, N'Jhumpa ', N'Lahiri', NULL UNION ALL
SELECT N'142', N'High/Epic Fantasy', NULL, NULL, N'The Blade Itself', N'Joe Abercrombie', NULL, N'The First Law', NULL, N'1', N'Kindle', NULL, N'Joe ', N'Abercrombie', NULL UNION ALL
SELECT N'142', N'High/Epic Fantasy', NULL, NULL, N'Before They are Hanged', N'Joe Abercrombie', NULL, N'The First Law', NULL, N'2', N'Kindle', NULL, N'Joe ', N'Abercrombie', NULL UNION ALL
SELECT N'142', N'High/Epic Fantasy', NULL, NULL, N'Last Argument of Kings', N'Joe Abercrombie', NULL, N'The First Law', NULL, N'3', N'Kindle', NULL, N'Joe ', N'Abercrombie', NULL UNION ALL
SELECT N'126', N'Alternate Worlds', N'137', N'Fairy Tale', N'The Book of Lost Things', N'John Connolly', NULL, NULL, NULL, NULL, N'Kindle', NULL, N'John ', N'Connolly', NULL UNION ALL
SELECT N'186', N'Satanic Bargains', N'5', N'Fantasy', N'Johannes Cabal the Necromancer', N'Jonathan L. Howard', NULL, NULL, NULL, NULL, N'Kindle', NULL, N'Jonathan ', N'Howard', N'L.' UNION ALL
SELECT N'277', N'Burlesque/Travesty', NULL, NULL, N'Then We Came to the End: A Novel', N'Joshua Ferris', NULL, NULL, NULL, NULL, N'Hardback', N'2007', N'Joshua ', N'Ferris', NULL UNION ALL
SELECT N'51', N'Literary Fiction', NULL, NULL, N'The Help', N'Kathryn Stockett', NULL, NULL, NULL, NULL, N'Kindle', NULL, N'Kathryn ', N'Stockett', NULL UNION ALL
SELECT N'51', N'Literary Fiction', NULL, NULL, N'A Thousand Splendid Suns', N'Khaled Hosseini', NULL, NULL, NULL, NULL, N'Hardback', N'2007', N'Khaled ', N'Hosseini', NULL UNION ALL
SELECT N'196', N'Vampires', NULL, NULL, N'The Laughing Corpse', N'Laurell K. Hamilton', NULL, N'Anita Blake: Vampire Hunter', NULL, NULL, N'Kindle', NULL, N'Laurell ', N'Hamilton', N'K.' UNION ALL
SELECT N'196', N'Vampires', NULL, NULL, N'Circus of the Damned', N'Laurell K. Hamilton', NULL, N'Anita Blake: Vampire Hunter', NULL, NULL, N'Kindle', NULL, N'Laurell ', N'Hamilton', N'K.' UNION ALL
SELECT N'196', N'Vampires', NULL, NULL, N'The Lunatic Caf�', N'Laurell K. Hamilton', NULL, N'Anita Blake: Vampire Hunter', NULL, NULL, N'Kindle', NULL, N'Laurell ', N'Hamilton', N'K.' UNION ALL
SELECT N'196', N'Vampires', NULL, NULL, N'Bloody Bones', N'Laurell K. Hamilton', NULL, N'Anita Blake: Vampire Hunter', NULL, NULL, N'Kindle', NULL, N'Laurell ', N'Hamilton', N'K.' UNION ALL
SELECT N'196', N'Vampires', NULL, NULL, N'The Killing Dance', N'Laurell K. Hamilton', NULL, N'Anita Blake: Vampire Hunter', NULL, NULL, N'Kindle', NULL, N'Laurell ', N'Hamilton', N'K.' UNION ALL
SELECT N'196', N'Vampires', NULL, NULL, N'Burnt Offerings', N'Laurell K. Hamilton', NULL, N'Anita Blake: Vampire Hunter', NULL, NULL, N'Kindle', NULL, N'Laurell ', N'Hamilton', N'K.' UNION ALL
SELECT N'196', N'Vampires', NULL, NULL, N'Blue Moon', N'Laurell K. Hamilton', NULL, N'Anita Blake: Vampire Hunter', NULL, NULL, N'Kindle', NULL, N'Laurell ', N'Hamilton', N'K.' UNION ALL
SELECT N'196', N'Vampires', NULL, NULL, N'Obsidian Butterfly', N'Laurell K. Hamilton', NULL, N'Anita Blake: Vampire Hunter', NULL, NULL, N'Kindle', NULL, N'Laurell ', N'Hamilton', N'K.' UNION ALL
SELECT N'196', N'Vampires', NULL, NULL, N'Narcissus in Chains', N'Laurell K. Hamilton', NULL, N'Anita Blake: Vampire Hunter', NULL, NULL, N'Kindle', NULL, N'Laurell ', N'Hamilton', N'K.' UNION ALL
SELECT N'196', N'Vampires', NULL, NULL, N'Cerulean Sins', N'Laurell K. Hamilton', NULL, N'Anita Blake: Vampire Hunter', NULL, NULL, N'Kindle', NULL, N'Laurell ', N'Hamilton', N'K.' UNION ALL
SELECT N'196', N'Vampires', NULL, NULL, N'Guilty Pleasures', N'Laurell K. Hamilton', NULL, N'Anita Blake: Vampire Hunter', NULL, NULL, N'Paperback', NULL, N'Laurell ', N'Hamilton', N'K.' UNION ALL
SELECT N'132', N'Contemporary', NULL, NULL, N'The Magicians: A Novel', N'Les Grossman', NULL, NULL, NULL, NULL, N'Kindle', NULL, N'Les ', N'Grossman', NULL UNION ALL
SELECT NULL, N'Social Sciences', NULL, NULL, N'Outliers: The Story of Success', N'Malcom Gladwell', NULL, NULL, NULL, NULL, N'Kindle', NULL, N'Malcom ', N'Gladwell', NULL UNION ALL
SELECT N'175', N'Humorous', NULL, NULL, N'The Oblivion Society', N'Marcus Alexander Hart', NULL, NULL, NULL, NULL, N'Kindle', NULL, N'Marcus ', N'Hart', N'Alexander' UNION ALL
SELECT N'225', N'Whodunit', NULL, NULL, N'The Curious Incident of the Dog in the Night-Time', N'Mark Haddon', NULL, NULL, NULL, NULL, N'Paperback', N'2007', N'Mark ', N'Haddon', NULL UNION ALL
SELECT N'51', N'Literary Fiction', NULL, NULL, N'The Guernsey Literary and Potato Peel Pie Society', N'Mary Ann Shaffer', N'Annie Barrows', NULL, NULL, NULL, N'Kindle', NULL, N'Mary ', N'Shaffer', N'Ann' UNION ALL
SELECT N'280', N'Parody', NULL, NULL, N'The Zombie Survival Guide: Complete Protection from the Living Dead', N'Max Brooks', NULL, NULL, NULL, NULL, N'Kindle', NULL, N'Max ', N'Brooks', NULL UNION ALL
SELECT NULL, N'Political', NULL, NULL, N'The Lesser Evil: Political Ethics in an Age of Terror', N'Michael Ignatieff', NULL, NULL, NULL, NULL, N'Paperback', N'2008', N'Michael ', N'Ignatieff', NULL UNION ALL
SELECT N'135', N'Dark', NULL, NULL, N'The Devil you Know', N'Mike Carey', NULL, N'Felix Castor', NULL, N'1', N'Kindle', NULL, N'Mike ', N'Carey', NULL UNION ALL
SELECT N'135', N'Dark', NULL, NULL, N'Vicious Circle', N'Mike Carey', NULL, N'Felix Castor', NULL, N'2', N'Kindle', NULL, N'Mike ', N'Carey', NULL UNION ALL
SELECT N'135', N'Dark', NULL, NULL, N'Dead Men''s Boots', N'Mike Carey', NULL, N'Felix Castor', NULL, NULL, N'Kindle', NULL, N'Mike ', N'Carey', NULL UNION ALL
SELECT N'135', N'Dark', NULL, NULL, N'Thicker Than Water', N'Mike Carey', NULL, N'Felix Castor', NULL, NULL, N'Kindle', NULL, N'Mike ', N'Carey', NULL UNION ALL
SELECT N'135', N'Dark', NULL, NULL, N'The Naming of the Beasts', N'Mike Carey', NULL, N'Felix Castor', NULL, NULL, N'Kindle', NULL, N'Mike ', N'Carey', NULL
COMMIT;
RAISERROR (N'[dbo].[ImportBookList]: Insert Batch: 2.....Done!', 10, 1) WITH NOWAIT;
GO

BEGIN TRANSACTION;
INSERT INTO [dbo].[ImportBookList]([GenreKey], [Genre], [SubGenreKey], [SubGenre], [Title], [Author], [Co-Author], [Series Name], [F9], [Number in Series], [Format], [Year Read], [AuthorFirstName], [AuthorLastName], [AuthorMiddleName])
SELECT N'303', N'Environmental', NULL, NULL, N'Zodiac', N'Neal Stephenson', NULL, NULL, NULL, NULL, N'Paperback', NULL, N'Neal ', N'Stephenson', NULL UNION ALL
SELECT N'296', N'Cyberpunk', NULL, NULL, N'Snow Crash', N'Neal Stephenson', NULL, NULL, NULL, NULL, N'Paperback', NULL, N'Neal ', N'Stephenson', NULL UNION ALL
SELECT N'340', N'Postcyberpunk', NULL, NULL, N'The Diamond Age: or A Young Lady''s Illustrated Primer', N'Neal Stephenson', NULL, NULL, NULL, NULL, N'Paperback', NULL, N'Neal ', N'Stephenson', NULL UNION ALL
SELECT N'324', N'Math', NULL, NULL, N'Cryptonomicon', N'Neal Stephenson', NULL, NULL, NULL, NULL, N'Hardback', NULL, N'Neal ', N'Stephenson', NULL UNION ALL
SELECT N'44', N'Historical', NULL, NULL, N'Quicksilver', N'Neal Stephenson', NULL, N'The Baroque Cycle', NULL, N'1', N'Hardback', NULL, N'Neal ', N'Stephenson', NULL UNION ALL
SELECT N'44', N'Historical', NULL, NULL, N'The Confusion', N'Neal Stephenson', NULL, N'The Baroque Cycle', NULL, N'2', N'Hardback', NULL, N'Neal ', N'Stephenson', NULL UNION ALL
SELECT N'44', N'Historical', NULL, NULL, N'The System of the World', N'Neal Stephenson', NULL, N'The Baroque Cycle', NULL, N'3', N'Hardback', NULL, N'Neal ', N'Stephenson', NULL UNION ALL
SELECT N'324', N'Math', NULL, NULL, N'Anathem', N'Neal Stephenson', NULL, NULL, NULL, NULL, N'Hardback', NULL, N'Neal ', N'Stephenson', NULL UNION ALL
SELECT N'132', N'Comedic', NULL, NULL, N'Good Omens', N'Neil Gaiman', N'Terry Pratchett', NULL, NULL, NULL, N'Paperback', NULL, N'Neil ', N'Gaiman', NULL UNION ALL
SELECT N'157', N'Urban Fantasy', NULL, NULL, N'Neverwhere', N'Neil Gaiman', NULL, NULL, NULL, NULL, N'Paperback', NULL, N'Neil ', N'Gaiman', NULL UNION ALL
SELECT N'138', N'Fairy Tale', NULL, NULL, N'Stardust', N'Neil Gaiman', NULL, NULL, NULL, NULL, N'Hardback', NULL, N'Neil ', N'Gaiman', NULL UNION ALL
SELECT N'159', N'Mythopoeia', NULL, NULL, N'American Gods', N'Neil Gaiman', NULL, NULL, NULL, NULL, N'Paperback', NULL, N'Neil ', N'Gaiman', NULL UNION ALL
SELECT N'159', N'Mythopoeia', NULL, NULL, N'Anasasi Boys', N'Neil Gaiman', NULL, NULL, NULL, NULL, N'Paperback', NULL, N'Neil ', N'Gaiman', NULL UNION ALL
SELECT N'145', N'Juvenile', NULL, NULL, N'The Graveyard Book', N'Neil Gaiman', NULL, NULL, NULL, NULL, N'Audio', NULL, N'Neil ', N'Gaiman', NULL UNION ALL
SELECT N'43', N'Gothic Fiction', NULL, NULL, N'Galveston', N'Nic Pizzolatto', NULL, NULL, NULL, NULL, N'Kindle', NULL, N'Nic ', N'Pizzolatto', NULL UNION ALL
SELECT N'21', N'Coming of Age', NULL, NULL, N'Swimming', N'Nicola Keegan', NULL, NULL, NULL, NULL, N'Kindle', NULL, N'Nicola ', N'Keegan', NULL UNION ALL
SELECT N'327', N'Military', NULL, NULL, N'Ender''s Game', N'Orson Scott Card', NULL, N'The Ender Saga', NULL, N'1', N'Paperback', NULL, N'Orson ', N'Card', N'Scott' UNION ALL
SELECT N'381', N'Gilded Cage', NULL, NULL, N'Speaker for the Dead', N'Orson Scott Card', NULL, N'The Ender Saga', NULL, N'2', N'Paperback', NULL, N'Orson ', N'Card', N'Scott' UNION ALL
SELECT N'306', N'Extraterrestrial Life', NULL, NULL, N'Xenocide', N'Orson Scott Card', NULL, N'The Ender Saga', NULL, N'3', N'Paperback', NULL, N'Orson ', N'Card', N'Scott' UNION ALL
SELECT N'327', N'Military', NULL, NULL, N'Ender''s Shadow', N'Orson Scott Card', NULL, N'The Shadow Saga', NULL, N'1', N'Hardback', NULL, N'Orson ', N'Card', N'Scott' UNION ALL
SELECT N'4', N'Science Fiction', NULL, NULL, N'Shadow of the Hegemon', N'Orson Scott Card', NULL, N'The Shadow Saga', NULL, N'2', N'Hardback', NULL, N'Orson ', N'Card', N'Scott' UNION ALL
SELECT N'12', N'Alternative History', N'154', N'Series', N'Seventh Son', N'Orson Scott Card', NULL, N'The Tales of Alvin Maker', NULL, N'1', N'Paperback', NULL, N'Orson ', N'Card', N'Scott' UNION ALL
SELECT N'12', N'Alternative History', N'154', N'Series', N'Red Prophet', N'Orson Scott Card', NULL, N'The Tales of Alvin Maker', NULL, N'2', N'Paperback', NULL, N'Orson ', N'Card', N'Scott' UNION ALL
SELECT N'12', N'Alternative History', N'154', N'Series', N'Prentice Alvin', N'Orson Scott Card', NULL, N'The Tales of Alvin Maker', NULL, N'3', N'Paperback', NULL, N'Orson ', N'Card', N'Scott' UNION ALL
SELECT N'12', N'Alternative History', N'154', N'Series', N'Alvin Journeyman', N'Orson Scott Card', NULL, N'The Tales of Alvin Maker', NULL, N'4', N'Paperback', NULL, N'Orson ', N'Card', N'Scott' UNION ALL
SELECT N'141', N'Heroic', NULL, NULL, N'The Name of the Wind', N'Patrick Rothfuss', NULL, NULL, NULL, NULL, N'Kindle', NULL, N'Patrick ', N'Rothfuss', NULL UNION ALL
SELECT N'64', N'Philosophical', NULL, NULL, N'The Alchemist', N'Paulo Coelho', NULL, NULL, NULL, NULL, N'Paperback', NULL, N'Paulo ', N'Coelho', NULL UNION ALL
SELECT N'18', N'Chick Lit', NULL, NULL, N'The Blue Bottle Club', N'Penelope J. Stokes', NULL, NULL, NULL, NULL, N'Paperback', NULL, N'Penelope ', N'Stokes', N'J.' UNION ALL
SELECT N'168', N'Dark Fantasy', NULL, NULL, N'The Warded Man', N'Peter V. Brett', NULL, N'Demon Cycle', NULL, N'1', N'Kindle', NULL, N'Peter ', N'Brett', N'V.' UNION ALL
SELECT N'168', N'Dark Fantasy', NULL, NULL, N'The Desert Spear', N'Peter V. Brett', NULL, N'Demon Cycle', NULL, N'2', N'Kindle', NULL, N'Peter ', N'Brett', N'V.' UNION ALL
SELECT N'220', N'Police Procedural', NULL, NULL, N'Heat Wave', N'Richard Castle', NULL, NULL, NULL, NULL, N'Kindle', NULL, N'Richard ', N'Castle', NULL UNION ALL
SELECT N'51', N'Literary Fiction', NULL, NULL, N'Revolutionary Road', N'Richard Yates', NULL, NULL, NULL, NULL, N'Paperback', N'2008', N'Richard ', N'Yates', NULL UNION ALL
SELECT N'199', N'Dark Comedy', N'383', N'Mars', N'The Four Fingers of Death: A Novel', N'Rick Moody', NULL, NULL, NULL, NULL, N'Kindle', NULL, N'Rick ', N'Moody', NULL UNION ALL
SELECT N'309', N'First Landings', NULL, NULL, N'The Man who Sold the Moon', N'Robert Heinlein', NULL, N'Future History', NULL, NULL, N'Paperback', NULL, N'Robert ', N'Heinlein', NULL UNION ALL
SELECT N'318', N'Immortality', NULL, NULL, N'Methuselah''s Children', N'Robert Heinlein', NULL, N'Future History', NULL, NULL, N'Paperback', NULL, N'Robert ', N'Heinlein', NULL UNION ALL
SELECT N'293', N'Communalness', NULL, NULL, N'Time Enough for Love', N'Robert Heinlein', NULL, N'Future History', N'Lazarus Long', NULL, N'Paperback', NULL, N'Robert ', N'Heinlein', NULL UNION ALL
SELECT N'365', N'Time Travel', NULL, NULL, N'To Sail Beyond the Sunset', N'Robert Heinlein', NULL, N'Future History', N'Lazarus Long', NULL, N'Paperback', NULL, N'Robert ', N'Heinlein', NULL UNION ALL
SELECT N'335', N'Parallel Universe', NULL, NULL, N'The Number of the Beast', N'Robert Heinlein', NULL, N'Lazarus Long', NULL, NULL, N'Paperback', NULL, N'Robert ', N'Heinlein', NULL UNION ALL
SELECT N'299', N'Detective', NULL, NULL, N'The Cat Who Walks Through Walls', N'Robert Heinlein', NULL, N'Lazarus Long', NULL, NULL, N'Paperback', NULL, N'Robert ', N'Heinlein', NULL UNION ALL
SELECT N'310', N'Frontier', NULL, NULL, N'The Moon is a Harsh Mistress', N'Robert Heinlein', NULL, N'Future History', NULL, NULL, N'Paperback', NULL, N'Robert ', N'Heinlein', NULL UNION ALL
SELECT N'327', N'Military', NULL, NULL, N'Starship Troopers', N'Robert Heinlein', NULL, NULL, NULL, NULL, N'Paperback', NULL, N'Robert ', N'Heinlein', NULL UNION ALL
SELECT N'347', N'Retro-Futurism', NULL, NULL, N'Stranger in a Strange Land', N'Robert Heinlein', NULL, N'Lazarus Long', NULL, NULL, N'Hardback', NULL, N'Robert ', N'Heinlein', NULL UNION ALL
SELECT N'349', N'Science Fantasy', NULL, NULL, N'Glory Road', N'Robert Heinlein', NULL, NULL, NULL, NULL, N'Paperback', NULL, N'Robert ', N'Heinlein', NULL UNION ALL
SELECT N'290', N'Biorobotics', NULL, NULL, N'Friday', N'Robert Heinlein', NULL, NULL, NULL, NULL, N'Hardback', NULL, N'Robert ', N'Heinlein', NULL UNION ALL
SELECT N'345', N'Religious', NULL, NULL, N'Job: A Comedy of Justice', N'Robert Heinlein', NULL, NULL, NULL, NULL, N'Paperback', NULL, N'Robert ', N'Heinlein', NULL UNION ALL
SELECT NULL, N'Social Sciences', NULL, NULL, N'Expanded Universe', N'Robert Heinlein', NULL, NULL, NULL, NULL, N'Paperback', NULL, N'Robert ', N'Heinlein', NULL UNION ALL
SELECT N'142', N'High/Epic Fantasy', NULL, NULL, N'The Eye of the World', N'Robert Jordan', NULL, N'Wheel of Time', NULL, N'1', N'Paperback', NULL, N'Robert ', N'Jordan', NULL UNION ALL
SELECT N'142', N'High/Epic Fantasy', NULL, NULL, N'The Great Hunt', N'Robert Jordan', NULL, N'Wheel of Time', NULL, N'2', N'Paperback', NULL, N'Robert ', N'Jordan', NULL UNION ALL
SELECT N'142', N'High/Epic Fantasy', NULL, NULL, N'The Dragon Reborn', N'Robert Jordan', NULL, N'Wheel of Time', NULL, N'3', N'Paperback', NULL, N'Robert ', N'Jordan', NULL UNION ALL
SELECT N'142', N'High/Epic Fantasy', NULL, NULL, N'The Shadow Rising', N'Robert Jordan', NULL, N'Wheel of Time', NULL, N'4', N'Paperback', NULL, N'Robert ', N'Jordan', NULL
COMMIT;
RAISERROR (N'[dbo].[ImportBookList]: Insert Batch: 3.....Done!', 10, 1) WITH NOWAIT;
GO

BEGIN TRANSACTION;
INSERT INTO [dbo].[ImportBookList]([GenreKey], [Genre], [SubGenreKey], [SubGenre], [Title], [Author], [Co-Author], [Series Name], [F9], [Number in Series], [Format], [Year Read], [AuthorFirstName], [AuthorLastName], [AuthorMiddleName])
SELECT N'142', N'High/Epic Fantasy', NULL, NULL, N'The Fires of Heaven', N'Robert Jordan', NULL, N'Wheel of Time', NULL, N'5', N'Paperback', NULL, N'Robert ', N'Jordan', NULL UNION ALL
SELECT N'142', N'High/Epic Fantasy', NULL, NULL, N'Lord of Chaos', N'Robert Jordan', NULL, N'Wheel of Time', NULL, N'6', N'Paperback', NULL, N'Robert ', N'Jordan', NULL UNION ALL
SELECT N'142', N'High/Epic Fantasy', NULL, NULL, N'A Crown of Swords', N'Robert Jordan', NULL, N'Wheel of Time', NULL, N'7', N'Paperback', NULL, N'Robert ', N'Jordan', NULL UNION ALL
SELECT N'142', N'High/Epic Fantasy', NULL, NULL, N'The Path of Daggers', N'Robert Jordan', NULL, N'Wheel of Time', NULL, N'8', N'Hardback', NULL, N'Robert ', N'Jordan', NULL UNION ALL
SELECT N'142', N'High/Epic Fantasy', NULL, NULL, N'Winter''s Heart', N'Robert Jordan', NULL, N'Wheel of Time', NULL, N'9', N'Hardback', NULL, N'Robert ', N'Jordan', NULL UNION ALL
SELECT N'142', N'High/Epic Fantasy', NULL, NULL, N'Crossroads of Twilight', N'Robert Jordan', NULL, N'Wheel of Time', NULL, N'10', N'Hardback', NULL, N'Robert ', N'Jordan', NULL UNION ALL
SELECT N'142', N'High/Epic Fantasy', NULL, NULL, N'Knife of Dreams', N'Robert Jordan', NULL, N'Wheel of Time', NULL, N'11', N'Hardback', NULL, N'Robert ', N'Jordan', NULL UNION ALL
SELECT N'142', N'High/Epic Fantasy', NULL, NULL, N'The Gathering Storm', N'Robert Jordan', N'Brandon Sanderson', N'Wheel of Time', NULL, N'12', N'Hardback', NULL, N'Robert ', N'Jordan', NULL UNION ALL
SELECT N'142', N'High/Epic Fantasy', NULL, NULL, N'Towers of Midnight', N'Robert Jordan', N'Brandon Sanderson', N'Wheel of Time', NULL, N'13', N'Hardback', NULL, N'Robert ', N'Jordan', NULL UNION ALL
SELECT NULL, N'Philosophy', NULL, NULL, N'Zen and the Art of Motorcycle Maintenance: An Inquiry into Values', N'Robert Pirsig', NULL, NULL, NULL, NULL, N'Paperback', NULL, N'Robert ', N'Pirsig', NULL UNION ALL
SELECT NULL, N'Philosophy', NULL, NULL, N'Lila: An Inquiry into Morals', N'Robert Pirsig', NULL, NULL, NULL, NULL, N'Paperback', NULL, N'Robert ', N'Pirsig', NULL UNION ALL
SELECT NULL, NULL, NULL, NULL, N'Fifth Avenue, 5 A.M.: Audrey Hepburn, Breakfast at Tiffany�s, and the Dawn of the Modern Woman', N'Sam Wasson', NULL, NULL, NULL, NULL, N'Kindle', NULL, N'Sam ', N'Wasson', NULL UNION ALL
SELECT N'192', N'English Gothic', NULL, NULL, N'The Little Stranger', N'Sarah Waters', NULL, NULL, NULL, NULL, N'Kindle', NULL, N'Sarah ', N'Waters', NULL UNION ALL
SELECT N'146', N'Low Fantasy', NULL, NULL, N'The Lies of Locke Lamora', N'Scott Lynch', NULL, NULL, NULL, N'1', N'Kindle', NULL, N'Scott ', N'Lynch', NULL UNION ALL
SELECT N'146', N'Low Fantasy', NULL, NULL, N'Red Skies Under Red Seas', N'Scott Lynch', NULL, NULL, NULL, N'2', N'Kindle', NULL, N'Scott ', N'Lynch', NULL UNION ALL
SELECT N'135', N'Dark', NULL, NULL, N'The Dark Tower: The Gunslinger', N'Stephen King', NULL, N'The Dark Tower', NULL, N'1', N'Audio', NULL, N'Stephen ', N'King', NULL UNION ALL
SELECT N'135', N'Dark', NULL, NULL, N'The Drawing of the Three', N'Stephen King', NULL, N'The Dark Tower', NULL, N'2', N'Paperback', NULL, N'Stephen ', N'King', NULL UNION ALL
SELECT N'135', N'Dark', NULL, NULL, N'The Waste Lands', N'Stephen King', NULL, N'The Dark Tower', NULL, N'3', N'Paperback', NULL, N'Stephen ', N'King', NULL UNION ALL
SELECT N'135', N'Dark', NULL, NULL, N'Wizard and Glass', N'Stephen King', NULL, N'The Dark Tower', NULL, N'4', N'Paperback', NULL, N'Stephen ', N'King', NULL UNION ALL
SELECT N'135', N'Dark', NULL, NULL, N'Wolves of the Calla', N'Stephen King', NULL, N'The Dark Tower', NULL, N'5', N'Paperback', NULL, N'Stephen ', N'King', NULL UNION ALL
SELECT N'135', N'Dark', NULL, NULL, N'Song of Susannah', N'Stephen King', NULL, N'The Dark Tower', NULL, N'6', N'Paperback', NULL, N'Stephen ', N'King', NULL UNION ALL
SELECT N'135', N'Dark', NULL, NULL, N'The Dark Tower  ', N'Stephen King', NULL, N'The Dark Tower', NULL, N'7', N'Paperback', NULL, N'Stephen ', N'King', NULL UNION ALL
SELECT N'152', N'Romantic', NULL, NULL, N'Twilight', N'Stephenie Meyer', NULL, NULL, NULL, N'1', N'Paperback', N'2008', N'Stephenie ', N'Meyer', NULL UNION ALL
SELECT N'25', N'Crime', NULL, NULL, N'The Girl with the Dragon Tattoo', N'Stieg Larsson', NULL, N'Millenium Series', NULL, N'1', N'Kindle', NULL, N'Stieg ', N'Larsson', NULL UNION ALL
SELECT N'25', N'Crime', NULL, NULL, N'The Girl who Played with Fire', N'Stieg Larsson', NULL, N'Millenium Series', NULL, N'2', N'Kindle', NULL, N'Stieg ', N'Larsson', NULL UNION ALL
SELECT N'25', N'Crime', NULL, NULL, N'The Girl who Kicked the Hornet''s Nest', N'Stieg Larsson', NULL, N'Millenium Series', NULL, N'3', N'Kindle', NULL, N'Stieg ', N'Larsson', NULL UNION ALL
SELECT N'145', N'Juvenile', NULL, NULL, N'Nation', N'Terry Pratchett', NULL, NULL, NULL, NULL, N'Kindle', NULL, N'Terry ', N'Pratchett', NULL UNION ALL
SELECT N'132', N'Comedic', NULL, NULL, N'The Colour of Magic', N'Terry Pratchett', NULL, N'Discworld', NULL, N'1', N'Paperback', NULL, N'Terry ', N'Pratchett', NULL UNION ALL
SELECT N'132', N'Comedic', NULL, NULL, N'The Light Fantastic', N'Terry Pratchett', NULL, N'Discworld', NULL, N'2', N'Paperback', NULL, N'Terry ', N'Pratchett', NULL UNION ALL
SELECT N'132', N'Comedic', NULL, NULL, N'Equal Rites', N'Terry Pratchett', NULL, N'Discworld', NULL, N'3', N'Paperback', NULL, N'Terry ', N'Pratchett', NULL UNION ALL
SELECT N'132', N'Comedic', NULL, NULL, N'Mort', N'Terry Pratchett', NULL, N'Discworld', NULL, N'4', N'Paperback', NULL, N'Terry ', N'Pratchett', NULL UNION ALL
SELECT N'132', N'Comedic', NULL, NULL, N'Sourcery', N'Terry Pratchett', NULL, N'Discworld', NULL, N'5', N'Paperback', NULL, N'Terry ', N'Pratchett', NULL UNION ALL
SELECT N'132', N'Comedic', NULL, NULL, N'Wyrd Sisters', N'Terry Pratchett', NULL, N'Discworld', NULL, N'6', N'Paperback', NULL, N'Terry ', N'Pratchett', NULL UNION ALL
SELECT N'132', N'Comedic', NULL, NULL, N'Pyramids', N'Terry Pratchett', NULL, N'Discworld', NULL, N'7', N'Paperback', NULL, N'Terry ', N'Pratchett', NULL UNION ALL
SELECT N'132', N'Comedic', NULL, NULL, N'Guards! Guards!', N'Terry Pratchett', NULL, N'Discworld', NULL, N'8', N'Paperback', NULL, N'Terry ', N'Pratchett', NULL UNION ALL
SELECT N'132', N'Comedic', NULL, NULL, N'Eric', N'Terry Pratchett', NULL, N'Discworld', NULL, N'9', N'Paperback', NULL, N'Terry ', N'Pratchett', NULL UNION ALL
SELECT N'132', N'Comedic', NULL, NULL, N'Moving Pictures', N'Terry Pratchett', NULL, N'Discworld', NULL, N'10', N'Paperback', NULL, N'Terry ', N'Pratchett', NULL UNION ALL
SELECT N'132', N'Comedic', NULL, NULL, N'Reaper Man', N'Terry Pratchett', NULL, N'Discworld', NULL, N'11', N'Paperback', NULL, N'Terry ', N'Pratchett', NULL UNION ALL
SELECT N'132', N'Comedic', NULL, NULL, N'Witches Abroad', N'Terry Pratchett', NULL, N'Discworld', NULL, N'12', N'Paperback', NULL, N'Terry ', N'Pratchett', NULL UNION ALL
SELECT N'132', N'Comedic', NULL, NULL, N'Small Gods', N'Terry Pratchett', NULL, N'Discworld', NULL, N'13', N'Paperback', NULL, N'Terry ', N'Pratchett', NULL UNION ALL
SELECT N'132', N'Comedic', NULL, NULL, N'Lords and Ladies', N'Terry Pratchett', NULL, N'Discworld', NULL, N'14', N'Paperback', NULL, N'Terry ', N'Pratchett', NULL UNION ALL
SELECT N'132', N'Comedic', NULL, NULL, N'Men at Arms', N'Terry Pratchett', NULL, N'Discworld', NULL, N'15', N'Paperback', NULL, N'Terry ', N'Pratchett', NULL UNION ALL
SELECT N'132', N'Comedic', NULL, NULL, N'Soul Music', N'Terry Pratchett', NULL, N'Discworld', NULL, N'16', N'Paperback', NULL, N'Terry ', N'Pratchett', NULL UNION ALL
SELECT N'132', N'Comedic', NULL, NULL, N'Interesting Times', N'Terry Pratchett', NULL, N'Discworld', NULL, N'17', N'Paperback', NULL, N'Terry ', N'Pratchett', NULL UNION ALL
SELECT N'132', N'Comedic', NULL, NULL, N'Maskerade', N'Terry Pratchett', NULL, N'Discworld', NULL, N'18', N'Paperback', NULL, N'Terry ', N'Pratchett', NULL UNION ALL
SELECT N'132', N'Comedic', NULL, NULL, N'Feet of Clay', N'Terry Pratchett', NULL, N'Discworld', NULL, N'19', N'Paperback', NULL, N'Terry ', N'Pratchett', NULL UNION ALL
SELECT N'132', N'Comedic', NULL, NULL, N'Hogfather', N'Terry Pratchett', NULL, N'Discworld', NULL, N'20', N'Paperback', NULL, N'Terry ', N'Pratchett', NULL UNION ALL
SELECT N'132', N'Comedic', NULL, NULL, N'Jingo', N'Terry Pratchett', NULL, N'Discworld', NULL, N'21', N'Paperback', NULL, N'Terry ', N'Pratchett', NULL UNION ALL
SELECT N'132', N'Comedic', NULL, NULL, N'The Last Continent', N'Terry Pratchett', NULL, N'Discworld', NULL, N'22', N'Paperback', NULL, N'Terry ', N'Pratchett', NULL UNION ALL
SELECT N'132', N'Comedic', NULL, NULL, N'Carpe Jugulum', N'Terry Pratchett', NULL, N'Discworld', NULL, N'23', N'Paperback', NULL, N'Terry ', N'Pratchett', NULL
COMMIT;
RAISERROR (N'[dbo].[ImportBookList]: Insert Batch: 4.....Done!', 10, 1) WITH NOWAIT;
GO

BEGIN TRANSACTION;
INSERT INTO [dbo].[ImportBookList]([GenreKey], [Genre], [SubGenreKey], [SubGenre], [Title], [Author], [Co-Author], [Series Name], [F9], [Number in Series], [Format], [Year Read], [AuthorFirstName], [AuthorLastName], [AuthorMiddleName])
SELECT N'132', N'Comedic', NULL, NULL, N'The Fifth Elephant', N'Terry Pratchett', NULL, N'Discworld', NULL, N'24', N'Paperback', NULL, N'Terry ', N'Pratchett', NULL UNION ALL
SELECT N'132', N'Comedic', NULL, NULL, N'The Truth', N'Terry Pratchett', NULL, N'Discworld', NULL, N'25', N'Paperback', NULL, N'Terry ', N'Pratchett', NULL UNION ALL
SELECT N'132', N'Comedic', NULL, NULL, N'Thief of Time', N'Terry Pratchett', NULL, N'Discworld', NULL, N'26', N'Paperback', NULL, N'Terry ', N'Pratchett', NULL UNION ALL
SELECT N'132', N'Comedic', NULL, NULL, N'The Last Hero', N'Terry Pratchett', NULL, N'Discworld', NULL, N'27', N'Paperback', NULL, N'Terry ', N'Pratchett', NULL UNION ALL
SELECT N'132', N'Comedic', NULL, NULL, N'Night Watch', N'Terry Pratchett', NULL, N'Discworld', NULL, N'28', N'Paperback', NULL, N'Terry ', N'Pratchett', NULL UNION ALL
SELECT N'132', N'Comedic', NULL, NULL, N'Monstrous Regiment', N'Terry Pratchett', NULL, N'Discworld', NULL, N'29', N'Paperback', NULL, N'Terry ', N'Pratchett', NULL UNION ALL
SELECT N'132', N'Comedic', NULL, NULL, N'Going Postal', N'Terry Pratchett', NULL, N'Discworld', NULL, N'30', N'Paperback', NULL, N'Terry ', N'Pratchett', NULL UNION ALL
SELECT N'132', N'Comedic', NULL, NULL, N'Thud!', N'Terry Pratchett', NULL, N'Discworld', NULL, N'31', N'Paperback', NULL, N'Terry ', N'Pratchett', NULL UNION ALL
SELECT N'132', N'Comedic', NULL, NULL, N'Making Money', N'Terry Pratchett', NULL, N'Discworld', NULL, N'32', N'Paperback', NULL, N'Terry ', N'Pratchett', NULL UNION ALL
SELECT N'132', N'Comedic', NULL, NULL, N'Unseen Academicals', N'Terry Pratchett', NULL, N'Discworld', NULL, N'33', N'Paperback', NULL, N'Terry ', N'Pratchett', NULL UNION ALL
SELECT NULL, N'Globalization', NULL, NULL, N'The World is Flat 3.0: A Brief History of the 21st Century', N'Thomas L. Friedman', NULL, NULL, NULL, NULL, N'Paperback', N'2008', N'Thomas ', N'Friedman', N'L.' UNION ALL
SELECT N'82', N'Short Fiction', NULL, NULL, N'Everything Ravaged, Everything Burned: Stories', N'Wells Tower', NULL, NULL, NULL, NULL, N'Kindle', NULL, N'Wells ', N'Tower', NULL UNION ALL
SELECT N'30', N'Economic/Financial', NULL, NULL, N'Zero History', N'William Gibson', NULL, N'Bigend Trilogy', NULL, N'3', N'Kindle', NULL, N'William ', N'Gibson', NULL UNION ALL
SELECT N'354', N'Social', NULL, NULL, N'Pattern Recognition', N'William Gibson', NULL, N'Bigend Trilogy', NULL, N'1', N'Kindle', NULL, N'William ', N'Gibson', NULL UNION ALL
SELECT N'431', N'Political', NULL, NULL, N'Spook Country', N'William Gibson', NULL, N'Bigend Trilogy', NULL, N'2', N'Kindle', NULL, N'William ', N'Gibson', NULL UNION ALL
SELECT N'296', N'Cyberpunk', NULL, NULL, N'Neuromancer', N'William Gibson', NULL, N'Sprawl Trilogy', NULL, N'1', N'Paperback', NULL, N'William ', N'Gibson', NULL UNION ALL
SELECT N'296', N'Cyberpunk', NULL, NULL, N'Count Zero', N'William Gibson', NULL, N'Sprawl Trilogy', NULL, N'2', N'Paperback', NULL, N'William ', N'Gibson', NULL UNION ALL
SELECT N'296', N'Cyberpunk', NULL, NULL, N'Mona Lisa Overdrive', N'William Gibson', NULL, N'Sprawl Trilogy', NULL, N'3', N'Paperback', NULL, N'William ', N'Gibson', NULL UNION ALL
SELECT N'301', N'Dystopian', NULL, NULL, N'Virtual Light', N'William Gibson', NULL, N'Bridge Trilogy', NULL, N'1', N'Paperback', NULL, N'William ', N'Gibson', NULL UNION ALL
SELECT N'301', N'Dystopian', NULL, NULL, N'Idoru', N'William Gibson', NULL, N'Bridge Trilogy', NULL, N'2', N'Paperback', NULL, N'William ', N'Gibson', NULL UNION ALL
SELECT N'301', N'Dystopian', NULL, NULL, N'All Tomorrow''s Parties', N'William Gibson', NULL, N'Bridge Trilogy', NULL, N'3', N'Paperback', NULL, N'William ', N'Gibson', NULL
COMMIT;
RAISERROR (N'[dbo].[ImportBookList]: Insert Batch: 5.....Done!', 10, 1) WITH NOWAIT;
GO

--Populate ImportBookONE
BEGIN TRANSACTION;
INSERT INTO [dbo].[ImportBookONE]([Title], [AuthorFirstName], [AuthorMiddleName], [AuthorLastName], [Format], [SeriesName], [Genre], [FirstParentGenre], [ImportDate])
SELECT N'Red Mars', N'Kim', N'Stanley', N'Robinson', N'Paperback', N'Mars Trilogy', N'Mars', N'First Landings', '20110102 00:00:00.000' UNION ALL
SELECT N'Green Mars', N'Kim', N'Stanley', N'Robinson', N'Paperback', N'Mars Trilogy', N'Mars', N'First Landings', '20110117 00:00:00.000' UNION ALL
SELECT N'Blue Mars', N'Kim', N'Stanley', N'Robinson', N'Paperback', N'Mars Trilogy', N'Mars', N'First Landings', '20110115 00:00:00.000' UNION ALL
SELECT N'The Years of Rice and Salt', N'Kim', N'Stanley', N'Robinson', N'Hardback', NULL, N'Alternative History', N'Fiction', '20110104 00:00:00.000' UNION ALL
SELECT N'Forty Signs of Rain', N'Kim', N'Stanley', N'Robinson', N'Hardback', N'Science in the Capital', N'Hard', N'Science Fiction', '20110113 00:00:00.000' UNION ALL
SELECT N'The Kite Runner', N'Khaled', NULL, N'Hosseini', N'Hardback', NULL, N'Coming of Age', N'Fiction', '20110120 00:00:00.000' UNION ALL
SELECT N'Nine Princes in Amber', N'Roger', NULL, N'Zelazny', N'Omnibus', N'Chronicles of Amber', N'Series', N'Fantasy', '20110116 00:00:00.000' UNION ALL
SELECT N'The Guns of Avalon', N'Roger', NULL, N'Zelazny', N'Omnibus', N'Chronicles of Amber', N'Series', N'Fantasy', '20110130 00:00:00.000' UNION ALL
SELECT N'Sign of fthe Unicorn', N'Roger', NULL, N'Zelazny', N'Omnibus', N'Chronicles of Amber', N'Series', N'Fantasy', '20110123 00:00:00.000' UNION ALL
SELECT N'The Hand of Oberon', N'Roger', NULL, N'Zelazny', N'Omnibus', N'Chronicles of Amber', N'Series', N'Fantasy', '20110129 00:00:00.000' UNION ALL
SELECT N'The Courts of Chaos', N'Roger', NULL, N'Zelazny', N'Omnibus', N'Chronicles of Amber', N'Series', N'Fantasy', '20110118 00:00:00.000'
COMMIT;
RAISERROR (N'[dbo].[ImportBookONE]: Insert Batch: 1.....Done!', 10, 1) WITH NOWAIT;
GO

--Populate ImportBookTWO
BEGIN TRANSACTION;
INSERT INTO [dbo].[ImportBookTWO]([Title], [AuthorFirstName], [AuthorMiddleName], [AuthorLastName], [Format], [SeriesName], [Genre], [FirstParentGenre], [ImportDate])
SELECT N'The Years of Rice and Salt', N'Kim', N'Stanley', N'Robinson', N'Hardback', NULL, N'Alternative History', N'Fiction', '20110226 00:00:00.000' UNION ALL
SELECT N'Forty Signs of Rain', N'Kim', N'Stanley', N'Robinson', N'Hardback', N'Science in the Capital', N'Hard', N'Science Fiction', '20110215 00:00:00.000' UNION ALL
SELECT N'Ill Met in Lankhmar', N'Fritz', NULL, N'Lieber', N'Hardback', NULL, N'Sword & Sorcery', N'Fantasy', '20110205 00:00:00.000' UNION ALL
SELECT N'Something from the Nightside', N'Simon', N'R.', N'Green', N'Kindle', N'Nightside', N'Urban Fantasy', N'Fantasy', '20110210 00:00:00.000' UNION ALL
SELECT N'The Heroes', N'Joe', NULL, N'Abercrombie', N'Kindle', NULL, N'Fictional Settings', N'Military Action', '20110222 00:00:00.000'
COMMIT;
RAISERROR (N'[dbo].[ImportBookTWO]: Insert Batch: 1.....Done!', 10, 1) WITH NOWAIT;
GO


/***** CREATE TABLE-VALUED FUNCTIONS *****/
--CREATE udfBooksInSeries
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[udfBooksInSeries]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[udfBooksInSeries]
GO

CREATE FUNCTION [dbo].[udfBooksInSeries]
(	
	@SeriesKey int
)
RETURNS TABLE 
AS
RETURN 
(
SELECT s.SeriesName, s.SeriesKey, COUNT(*) as TotalInSeries
FROM Series s 
	JOIN Title t
		ON s.SeriesKey = t.SeriesKey
WHERE t.SeriesKey = @SeriesKey		
GROUP BY s.SeriesName, s.SeriesKey
)
GO

--Create udfGenreHierarchy
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[udfGenreHierarchy]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[udfGenreHierarchy]
GO

CREATE FUNCTION [dbo].[udfGenreHierarchy] 
(	
	@ParentGenreKey varchar(100)
)
RETURNS TABLE 
AS
RETURN 
(
	
WITH GenreHierarchy as (
	SELECT ParentGenreKey, cast('' as varchar(100)) as ParentGenreName,GenreKey, GenreName, 0 as GenreLevel, cast(GenreName as varchar(max)) as OrderingColumn
	FROM Genre
	WHERE GenreKey = @ParentGenreKey
UNION ALL
	SELECT g.ParentGenreKey, gh.GenreName, g.GenreKey, g.GenreName, gh.GenreLevel + 1, cast(gh.OrderingColumn+' - '+g.GenreName as varchar(max))
	FROM Genre g
		JOIN GenreHierarchy gh
			ON g.ParentGenreKey = gh.GenreKey
)

SELECT SPACE(GenreLevel*3)+GenreName as FormattedGenreList, ParentGenreKey, ParentGenreName, GenreKey, GenreName, GenreLevel, OrderingColumn
FROM GenreHierarchy	

)
GO

--CREATE udfNodeInfo
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[udfNodeInfo]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[udfNodeInfo]
GO

CREATE FUNCTION [dbo].[udfNodeInfo](@GenreKey int)

RETURNS @retNodeInfo TABLE 
(
    GenreKey int NOT NULL,
    NodeType varchar(35) NOT NULL, 
    NumberImmediateChildren smallint NOT NULL DEFAULT(0)
)     

AS

BEGIN

	INSERT INTO @retNodeInfo(GenreKey, NodeType)
	SELECT GenreKey, 
		CASE	
			WHEN ParentGenreKey IS NULL THEN 'Root'
			WHEN (SELECT COUNT(GenreKey) FROM Genre WHERE ParentGenreKey = @GenreKey) = 0 THEN 'Leaf'
			ELSE 'Non-Leaf'
		END as NodeType
	FROM dbo.Genre
	WHERE GenreKey = @GenreKey
	
	UPDATE @retNodeInfo
	SET NumberImmediateChildren = 
		(
		SELECT COUNT(ParentGenreKey)
		FROM Genre 
		WHERE ParentGenreKey = @GenreKey
		)
   
   RETURN
END
GO




