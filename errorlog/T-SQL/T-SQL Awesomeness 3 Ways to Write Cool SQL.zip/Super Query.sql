--Question:  Which authors have written both Science Fiction and Historical titles?  


--Example 1 - using a Recursive CTE wrapped up in a Table-valued function (2 birds... one stone) and an INTERSECT
SELECT DISTINCT a.AuthorFirstName, a.AuthorMiddleName, a.AuthorLastName
FROM Genre g
	CROSS APPLY udfGenreHierarchy(g.GenreKey) gh
	JOIN Title t
		ON t.GenreKey = gh.GenreKey			
	JOIN Author a
		ON t.AuthorKey = a.AuthorKey		
WHERE g.GenreName = 'Science Fiction'	
	INTERSECT
SELECT DISTINCT a.AuthorFirstName, a.AuthorMiddleName, a.AuthorLastName
FROM Genre g
	CROSS APPLY udfGenreHierarchy(g.GenreKey) gh
	JOIN Title t
		ON t.GenreKey = gh.GenreKey			
	JOIN Author a
		ON t.AuthorKey = a.AuthorKey		
WHERE g.GenreName = 'Historical'	


--Example 2 - Okay, I totally cheated by using the Table-Valued Function.  Here's a less readable, but much more death-defying example:  

DECLARE @GenreName1 varchar(100)  = 'Science Fiction'; 
DECLARE @GenreName2 varchar(100)  = 'Historical'; 

WITH 
	ScienceFictionHierarchy as 
	(
	SELECT ParentGenreKey, cast('' as varchar(100)) as ParentGenreName,GenreKey, GenreName, 0 as GenreLevel, cast(GenreName as varchar(max)) as OrderingColumn
	FROM Genre
	WHERE GenreName = @GenreName1
		UNION ALL
	SELECT g.ParentGenreKey, gh.GenreName, g.GenreKey, g.GenreName, gh.GenreLevel + 1, cast(gh.OrderingColumn+' - '+g.GenreName as varchar(max))
	FROM Genre g
		JOIN ScienceFictionHierarchy gh
			ON g.ParentGenreKey = gh.GenreKey
	)
, 
	HistoricalHierarchy as
    (
	SELECT ParentGenreKey, cast('' as varchar(100)) as ParentGenreName,GenreKey, GenreName, 0 as GenreLevel, cast(GenreName as varchar(max)) as OrderingColumn
	FROM Genre
	WHERE GenreName = @GenreName2
		UNION ALL
	SELECT g.ParentGenreKey, gh.GenreName, g.GenreKey, g.GenreName, gh.GenreLevel + 1, cast(gh.OrderingColumn+' - '+g.GenreName as varchar(max))
	FROM Genre g
		JOIN HistoricalHierarchy gh
			ON g.ParentGenreKey = gh.GenreKey
	)

SELECT a.AuthorFirstName, a.AuthorMiddleName, a.AuthorLastName, n.NodeType
FROM ScienceFictionHierarchy g1
	JOIN Title t 
		ON g1.GenreKey = t.GenreKey
	JOIN Author a 
		ON t.AuthorKey = a.AuthorKey
	CROSS APPLY dbo.udfNodeInfo(t.GenreKey) n													--udfNodeInfo tells me if the node is Root, Non-Leaf, or Leaf
	
	INTERSECT 
	
SELECT a.AuthorFirstName, a.AuthorMiddleName, a.AuthorLastName, n.NodeType
FROM HistoricalHierarchy g2
		JOIN Title t 
		ON g2.GenreKey = t.GenreKey
	JOIN Author a 
		ON t.AuthorKey = a.AuthorKey
	CROSS APPLY dbo.udfNodeInfo(t.GenreKey) n										
	
-------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	
--And, if you're curious about how Neal Stephenson ended up with books in both hierarchy branches...
SELECT gh.GenreName, t.TitleName, a.AuthorFirstName, a.AuthorLastName
FROM Genre g
	CROSS APPLY udfGenreHierarchy(g.GenreKey) gh
	JOIN Title t
		ON t.GenreKey = gh.GenreKey			
	JOIN Author a
		ON t.AuthorKey = a.AuthorKey		
WHERE g.GenreName in ('Science Fiction'	, 'Historical')
  AND a.AuthorLastName = 'Stephenson'
ORDER BY gh.OrderingColumn  

	 