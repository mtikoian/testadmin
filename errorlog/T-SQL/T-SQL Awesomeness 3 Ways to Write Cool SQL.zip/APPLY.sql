SET STATISTICS IO ON; 
SET STATISTICS TIME ON; 

--SELECT a branch of the hierarchy
--Basic CROSS APPLY
SELECT gh.FormattedGenreList, gh.GenreKey, g.GenreName as FirstLevelNode
FROM Genre g
	CROSS APPLY dbo.udfGenreHierarchy(g.GenreKey) gh
WHERE g.GenreName = 'Humor/Comedy'	
ORDER BY gh.OrderingColumn; 

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

--Basic CROSS APPLY - Add Title & Author
--Note that with a CROSS APPLY, only nodes that have corresponding titles come back, and the node is repeated if there are multiple associated titles
SELECT  gh.FormattedGenreList, gh.GenreKey, gh.GenreName, t.TitleName, a.AuthorFirstName, a.AuthorLastName
FROM Genre g
	CROSS APPLY udfGenreHierarchy(g.GenreKey) gh
	JOIN Title t
		ON t.GenreKey = gh.GenreKey			
	JOIN Author a
		ON t.AuthorKey = a.AuthorKey		
WHERE g.GenreName = 'Science Fiction'	
ORDER BY gh.OrderingColumn; 

-------------------------------------------------------------------------------------------------------------------------------------------------------------

--Basic OUTER APPLY
SELECT t.TitleKey, t.TitleName, s.SeriesName, s.TotalInSeries
FROM Title t
	OUTER APPLY udfBooksInSeries(t.SeriesKey) s 
ORDER BY t.TitleName; 

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
----Derived Table - How many titles are in a series?
PRINT 'Inner Join Solution: '

--Basic INNER JOIN Solution
SELECT s.SeriesName, COUNT(*) as TotalInSeries
FROM Series s 
	JOIN Title t
		ON s.SeriesKey = t.SeriesKey		
GROUP BY s.SeriesName; 

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
PRINT 'Cross Apply Solution:  '; 

--CROSS APPLY a Derived Table Solution
SELECT s.SeriesName, t.TotalInSeries
FROM Series s 
	CROSS APPLY  
		(
		SELECT i.SeriesKey, COUNT(*) as TotalInSeries
		FROM Title i 
		WHERE s.SeriesKey = i.SeriesKey
		GROUP BY 	i.SeriesKey
		) t; 	

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
		
--But, you can get the same execution plan with an inner join to the derived table		
SELECT s.SeriesName, t.TotalInSeries
FROM Series s 
	JOIN   
		(
		SELECT i.SeriesKey, COUNT(*) as TotalInSeries
		FROM Title i 
		GROUP BY 	i.SeriesKey
		) t
			ON s.SeriesKey = t.SeriesKey		
		
--Moral of the story:  Try multiple approaches - don't assume that CROSS APPLY always performs better than INNER JOIN... it just happens to in this example
		




















--CTE Way
USE msdb
GO

WITH LatestBackupSet (database_name, BackupsAgo, backup_start_date, media_set_id)
AS
(
SELECT database_name
            , ROW_NUMBER() OVER (PARTITION BY database_name ORDER BY backup_start_date DESC) AS 'BackupsAgo'
            , backup_start_date
            , media_set_id
  FROM msdb.dbo.backupset bs
WHERE type != 'L'
)
SELECT bf.physical_device_name, lbs.* 
  FROM dbo.backupmediafamily bf
  JOIN LatestBackupSet lbs
    ON lbs.media_set_id = bf.media_set_id
   AND family_sequence_number = 1
 
 
 
--Here�s the Outer Apply way to do it:
SELECT bf.physical_device_name ,
       name ,
       bs.backup_start_date ,
       bs.media_set_id
  FROM sys.databases d
OUTER APPLY (SELECT TOP 1
                     backup_start_date ,
                     media_set_id
                FROM msdb.dbo.backupset
               WHERE type != 'L'
                 AND database_name = d.name
               ORDER BY backup_start_date DESC
            ) bs
INNER JOIN msdb.dbo.backupmediafamily bf ON bf.media_set_id = bs.media_set_id
WHERE owner_sid != '0x01'
  AND family_sequence_number = 1











	