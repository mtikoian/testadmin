SET STATISTICS IO ON; 
SET STATISTICS TIME ON; 

/** COMPARE TWO OVERLAPPING DATA SOURCES **/
SELECT Title, AuthorFirstName, AuthorMiddleName, AuthorLastName, Format, SeriesName, ImportDate
FROM dbo.ImportBookONE
ORDER BY AuthorLastName, SeriesName; 

SELECT Title, AuthorFirstName, AuthorMiddleName, AuthorLastName, Format, SeriesName, ImportDate
FROM dbo.ImportBookTWO
ORDER BY AuthorLastName, SeriesName; 

/* 
ONLY IN LIST ONE
1) The Kite Runner - Khaled Hosseini
2) Mars Trilogy - Kim Stanley Robinson (Red Mars, Green Mars, Blue Mars) 
3) Chronicles of Amber - Roger Zelazny (Nine Princes in Amber, The Guns of Avalon, Sign of the Unicorn, The Hand of Oberon, The Courts of Chaos)

IN LISTS ONE AND TWO
1) The Years of Rice and Salt - Kim Stanley Robinson
2) Forty Signs of Rain - Kim Stanley Robinson

ONLY IN LIST TWO
1) Ill Met in Lankhmar - Fritz Lieber
2) Somthing From the Nightside - Simon R. Green
3) The Heroes - Joe Abercrombie
*/

----------------------------------------------------------------------------------------------------------------------------------------

/** EXCEPT **/
--SELECT what's in ONE but not in TWO - 9 Titles

--Old School, Attempt #1 -- I lose all of Kim Stanley Robinson's books - only 6 Titles returnes
SELECT Title, AuthorLastName 
FROM dbo.ImportBookONE 
WHERE Title NOT IN 
		(
		SELECT Title 
		FROM dbo.ImportBookTWO
		)
  AND AuthorLastName NOT IN 
	  (
	  SELECT AuthorLastName 
	  FROM dbo.ImportBookTWO
	  ); 

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

--Old School, Attempt #2 -- I get what I want, but it was ugly - 9 Titles returned
SELECT Title, AuthorLastName
FROM dbo.ImportBookONE
WHERE Title +'--'+ AuthorLastName NOT IN 
	(
	SELECT Title +'--'+ AuthorLastName 
	FROM dbo.ImportBookTWO
	)
ORDER BY AuthorLastName; 

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

--New School - 9 Titles returned
SELECT Title, AuthorLastName
FROM dbo.ImportBookONE
	EXCEPT
SELECT Title, AuthorLastName 
FROM dbo.ImportBookTWO
ORDER BY AuthorLastName; 

----------------------------------------------------------------------------------------------------------------------------------
	
/** INTERSECT **/	
--SELECT what's in ONE and TWO (Identify Duplicates)

--Old School
SELECT Title, AuthorLastName
FROM dbo.ImportBookONE
WHERE Title IN 
	(
	SELECT Title 
	FROM dbo.ImportBookTWO
	)
  AND AuthorLastName IN 
	(
	SELECT AuthorLastName 
	FROM dbo.ImportBookTWO
	); 
 
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  
--New School
SELECT Title, AuthorLastName
FROM dbo.ImportBookONE
	INTERSECT
SELECT Title, AuthorLastName 
FROM dbo.ImportBookTWO; 


------------------------------------------------------------------------------------------------------------------------------------
	
--SELECT full list, but give priority to ImportBookONE
WITH OnlyInTwoCTE as 
	(
	SELECT Title, AuthorLastName				--SELECT everything that is only in ImportBookTWO
	FROM dbo.ImportBookTWO
		EXCEPT 
	SELECT Title, AuthorLastName
	FROM dbo.ImportBookONE	
	)

															--SELECT ALL of ImportBookONE	
SELECT 'ONE' as Source, o.Title, o.AuthorFirstName, o.AuthorMiddleName, o.AuthorLastName, o.Format, o.SeriesName, o.Genre, o.FirstParentGenre, o.ImportDate
FROM ImportBookONE o

	UNION ALL
															--ONLY SELECT from ImportBookTWO where it doesn't exist in ImportBookONE (via JOIN to CTE)	
SELECT 'TWO', t.Title, t.AuthorFirstName, t.AuthorMiddleName, t.AuthorLastName, t.Format, t.SeriesName, t.Genre, t.FirstParentGenre, t.ImportDate
FROM ImportBookTWO t
	JOIN OnlyInTwoCTE c
		ON t.Title = t.Title
		  AND t.AuthorLastName = c.AuthorLastName; 
		 
----------------------------------------------------------------------------------------------------------------------------------------

/** PRECEDENCE **/
--Return book information where title contains the string "king", except for titles where Author Middle Name is NULL and Format is Kindle

SELECT t.TitleName, a.AuthorFirstName, a.AuthorMiddleName, a.AuthorLastName, f.FormatName					--4 titles containing 'king'
FROM dbo.Title t
	JOIN dbo.Author a
		ON t.AuthorKey = a.AuthorKey
	JOIN dbo.Format f 
		ON t.FormatKey = f.FormatKey
WHERE TitleName like '%King%'																													
	EXCEPT
SELECT t.TitleName, a.AuthorFirstName, a.AuthorMiddleName, a.AuthorLastName, f.FormatName					--194 titles where Author Middle Name is NULL
FROM dbo.Title t
	JOIN dbo.Author a
		ON t.AuthorKey = a.AuthorKey
	JOIN dbo.Format f 
		ON t.FormatKey = f.FormatKey
WHERE a.AuthorMiddleName IS NULL										
	INTERSECT 
SELECT t.TitleName, a.AuthorFirstName, a.AuthorMiddleName, a.AuthorLastName, f.FormatName					--79 in Kindle format
FROM dbo.Title t
	JOIN dbo.Author a
		ON t.AuthorKey = a.AuthorKey
	JOIN dbo.Format f 
		ON t.FormatKey = f.FormatKey
WHERE f.FormatName = 'Kindle'																														

--What's happening?  
-- 1) GIVE PRECEDENCE TO THE INTERSECT - Get all rows where Author Middle Name IS NULL that INTERSECT all rows where Format Name = Kindle
-- 2) THEN apply EXCEPT - Get all rows where the title includes the string "king", EXCEPT for the results of the INTERSECT statement

-- STEP 1:  Run the INTERSECT - RETURNS 63 ROWS
SELECT t.TitleName, a.AuthorFirstName, a.AuthorMiddleName, a.AuthorLastName, f.FormatName					--194 titles where Author Middle Name is NULL
FROM dbo.Title t
	JOIN dbo.Author a
		ON t.AuthorKey = a.AuthorKey
	JOIN dbo.Format f 
		ON t.FormatKey = f.FormatKey
WHERE a.AuthorMiddleName IS NULL										
	INTERSECT
SELECT t.TitleName, a.AuthorFirstName, a.AuthorMiddleName, a.AuthorLastName, f.FormatName					--79 in Kindle format
FROM dbo.Title t
	JOIN dbo.Author a
		ON t.AuthorKey = a.AuthorKey
	JOIN dbo.Format f 
		ON t.FormatKey = f.FormatKey
WHERE f.FormatName = 'Kindle'			

--STEP 2:  Run the EXCEPT against the results of the INTERSECT - RETURNS 2 ROWS
SELECT t.TitleName, a.AuthorFirstName, a.AuthorMiddleName, a.AuthorLastName, f.FormatName					--4 titles containing 'king'
FROM dbo.Title t
	JOIN dbo.Author a
		ON t.AuthorKey = a.AuthorKey
	JOIN dbo.Format f 
		ON t.FormatKey = f.FormatKey
WHERE TitleName like '%King%'																													
	EXCEPT 
/* [RESULTS FROM INTERSECT IN STEP 1] */																											


--Forcing precedence with parenthesis -- 0 rows returned
(
SELECT t.TitleName, a.AuthorFirstName, a.AuthorMiddleName, a.AuthorLastName, f.FormatName					--4 titles containing 'king'
FROM dbo.Title t
	JOIN dbo.Author a
		ON t.AuthorKey = a.AuthorKey
	JOIN dbo.Format f 
		ON t.FormatKey = f.FormatKey
WHERE TitleName like '%King%'																													
	EXCEPT
SELECT t.TitleName, a.AuthorFirstName, a.AuthorMiddleName, a.AuthorLastName, f.FormatName					--194 titles where Author Middle Name is NULL
FROM dbo.Title t
	JOIN dbo.Author a
		ON t.AuthorKey = a.AuthorKey
	JOIN dbo.Format f 
		ON t.FormatKey = f.FormatKey
WHERE a.AuthorMiddleName IS NULL										
)
	INTERSECT 
SELECT t.TitleName, a.AuthorFirstName, a.AuthorMiddleName, a.AuthorLastName, f.FormatName					--79 in Kindle format
FROM dbo.Title t
	JOIN dbo.Author a
		ON t.AuthorKey = a.AuthorKey
	JOIN dbo.Format f 
		ON t.FormatKey = f.FormatKey
WHERE f.FormatName = 'Kindle';																														
 
--Why no rows?  There are no titles where TitleName contains "king" and AuthorMiddleName IS NOT NULL - there is nothing to INTERSESCT with		