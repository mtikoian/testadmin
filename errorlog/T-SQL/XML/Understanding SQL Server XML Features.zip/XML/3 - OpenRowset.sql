DECLARE @xml xml

select 
	@xml = BulkColumn 
from openrowset(bulk 'C:\Users\rknight.SSG\Desktop\XML\SampleData.xml', single_blob) as xmldata

select @xml



GO


