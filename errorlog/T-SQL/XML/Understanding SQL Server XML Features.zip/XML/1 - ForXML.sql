USE AdventureWorks
GO

--Relational
SELECT * 
FROM HumanResources.Employee
WHERE EmployeeID IN (2,3)

SELECT *
FROM Person.Contact
WHERE ContactID IN (SELECT ContactID FROM HumanResources.Employee WHERE EmployeeID IN (2,3))


SELECT 
	emp.EmployeeID
	,emp.HireDate
	,per.LastName
	,per.FirstName
	,per.MiddleName
FROM HumanResources.Employee emp
	INNER JOIN Person.Contact per ON emp.ContactID = per.ContactID
WHERE emp.EmployeeID IN ( 2, 3 )

--Raw
SELECT 
	emp.EmployeeID
	,emp.HireDate
	,per.LastName
	,per.FirstName
	,per.MiddleName
FROM HumanResources.Employee emp
	INNER JOIN Person.Contact per ON emp.ContactID = per.ContactID
WHERE emp.EmployeeID IN ( 2, 3 )
FOR XML RAW 
	('EmployeeNode') --name the node
	 ,ROOT('EmployeeRoot') --add a root node
	, ELEMENTS --elements instead of attributes
	,XMLSCHEMA --inline schema

--Auto
SELECT 
	emp.EmployeeID
	,emp.HireDate
	,per.LastName
	,per.FirstName
	,per.MiddleName
FROM HumanResources.Employee emp
	INNER JOIN Person.Contact per ON emp.ContactID = per.ContactID
WHERE emp.EmployeeID IN ( 2, 3 )
FOR XML AUTO
	,ELEMENTS --elements instead of attributes
	,ROOT('EmployeeRoot') --add root element
	,XMLSCHEMA	-- inline schema

--Path
SELECT 
	emp.EmployeeID AS "Employee/@ID",
	emp.HireDate AS "Employee/Hire-Date",
	per.LastName AS "Employee/Name/Last",
	per.FirstName AS "Employee/Name/First",
	per.MiddleName AS "Employee/Name/Middle"
FROM HumanResources.Employee emp
	INNER JOIN Person.Contact per ON emp.ContactID = per.ContactID
WHERE emp.EmployeeID IN ( 2, 3 )
FOR XML PATH 
	('Employee')			-- name node
	,ROOT('EmployeeRoot')	--add root element
	,ELEMENTS XSINIL		--include empty element

	