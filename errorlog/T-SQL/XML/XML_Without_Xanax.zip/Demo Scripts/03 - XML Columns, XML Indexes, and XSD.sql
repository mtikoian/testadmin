use XMLWithoutXanax;
Go

-- Create a table to store some XML Data
create table XMLData (
	ID int identity(1,1) not null primary key clustered
	, Data xml null
);
GO

-- Insert XML data into the XML column
insert XMLData (Data)
select (
	select
		ih.InvoiceNumber '@Number'
		, ih.InvoiceDate '@Date'
		, ih.InvoiceStatus '@Status'
		, ih.CustomerNumber 'Customer/@Number'
		, ih.CustomerFirstName 'Customer/FirstName'
		, ih.CustomerLastName 'Customer/LastName'
		, (
			select
				id.ProductNumber 'Product/Number'
				, id.ProductDescription 'Product/Description'
				, id.Quantity
				, id.LineTotal 'Price/@LineTotal'
				, id.UnitPrice 'Price/UnitPrice'
				, id.UnitDiscount 'Price/UnitDiscount'
				, id.UnitSubTotal 'Price/UnitSubTotal'
			from InvoiceDetail id
			where id.InvoiceNumber = ih.InvoiceNumber
			order by id.LineNumber
			for xml path('LineItem'), type
		) 'LineItems'
		, ih.Total 'Amount/@Total'
		, ih.SubTotal 'Amount/SubTotal'
		, ih.TaxAmount 'Amount/Tax'
		, ih.ShippingAmount 'Amount/Shipping'
	from InvoiceHeader ih
	order by ih.InvoiceNumber
	for xml path ('Invoice'), root ('Invoices'), type
);
Go

-- Select XML data from the XML column
select
	Data
from XMLData;
Go

-- Apply an XSD to the XML column
---- Create XML Schema Collection (XSD)
create xml schema collection InvoiceData as
	N'<xs:schema attributeFormDefault="unqualified" elementFormDefault="qualified" xmlns:xs="http://www.w3.org/2001/XMLSchema">
		  <xs:element name="Invoices">
			<xs:complexType>
			  <xs:sequence>
				<xs:element name="Invoice" maxOccurs="unbounded" minOccurs="0">
				  <xs:complexType>
					<xs:sequence>
					  <xs:element name="Customer">
						<xs:complexType>
						  <xs:sequence>
							<xs:element type="xs:string" name="FirstName"/>
							<xs:element type="xs:string" name="LastName"/>
						  </xs:sequence>
						  <xs:attribute type="xs:byte" name="Number" use="optional"/>
						</xs:complexType>
					  </xs:element>
					  <xs:element name="LineItems">
						<xs:complexType>
						  <xs:sequence>
							<xs:element name="LineItem" maxOccurs="unbounded" minOccurs="0">
							  <xs:complexType>
								<xs:sequence>
								  <xs:element name="Product">
									<xs:complexType>
									  <xs:sequence>
										<xs:element type="xs:byte" name="Number"/>
										<xs:element type="xs:string" name="Description"/>
									  </xs:sequence>
									</xs:complexType>
								  </xs:element>
								  <xs:element type="xs:byte" name="Quantity"/>
								  <xs:element name="Price">
									<xs:complexType>
									  <xs:sequence>
										<xs:element type="xs:float" name="UnitPrice"/>
										<xs:element type="xs:float" name="UnitDiscount"/>
										<xs:element type="xs:float" name="UnitSubTotal"/>
									  </xs:sequence>
									  <xs:attribute type="xs:float" name="LineTotal" use="optional"/>
									</xs:complexType>
								  </xs:element>
								</xs:sequence>
							  </xs:complexType>
							</xs:element>
						  </xs:sequence>
						</xs:complexType>
					  </xs:element>
					  <xs:element name="Amount">
						<xs:complexType>
						  <xs:sequence>
							<xs:element type="xs:float" name="SubTotal"/>
							<xs:element type="xs:float" name="Tax"/>
							<xs:element type="xs:float" name="Shipping"/>
						  </xs:sequence>
						  <xs:attribute type="xs:float" name="Total" use="optional"/>
						</xs:complexType>
					  </xs:element>
					</xs:sequence>
					<xs:attribute type="xs:byte" name="Number" use="optional"/>
					<xs:attribute type="xs:dateTime" name="Date" use="optional"/>
					<xs:attribute type="xs:string" name="Status" use="optional"/>
				  </xs:complexType>
				</xs:element>
			  </xs:sequence>
			</xs:complexType>
		  </xs:element>
		</xs:schema>';
Go

---- Alter the column to be constrained by a schema collection (XSD)
alter table XMLData alter column Data xml (InvoiceData) not null;
Go

-- Try to insert good XML again (should still work)
insert XMLData (Data)
select (
	select
		ih.InvoiceNumber '@Number'
		, ih.InvoiceDate '@Date'
		, ih.InvoiceStatus '@Status'
		, ih.CustomerNumber 'Customer/@Number'
		, ih.CustomerFirstName 'Customer/FirstName'
		, ih.CustomerLastName 'Customer/LastName'
		, (
			select
				id.ProductNumber 'Product/Number'
				, id.ProductDescription 'Product/Description'
				, id.Quantity
				, id.LineTotal 'Price/@LineTotal'
				, id.UnitPrice 'Price/UnitPrice'
				, id.UnitDiscount 'Price/UnitDiscount'
				, id.UnitSubTotal 'Price/UnitSubTotal'
			from InvoiceDetail id
			where id.InvoiceNumber = ih.InvoiceNumber
			order by id.LineNumber
			for xml path('LineItem'), type
		) 'LineItems'
		, ih.Total 'Amount/@Total'
		, ih.SubTotal 'Amount/SubTotal'
		, ih.TaxAmount 'Amount/Tax'
		, ih.ShippingAmount 'Amount/Shipping'
	from InvoiceHeader ih
	order by ih.InvoiceNumber
	for xml path ('Invoice'), root ('Invoices'), type
);
Go

select * from XMLData;
Go

-- Try to insert some XML that doesn't conform to the XSD (should fail)
declare @BadXML xml = '<root>Hello world!</root>';

insert XMLData (Data)
values (@BadXML);
Go

select * from XMLData;
Go

-- Indexing an XML column
---- Primary XML index
create primary xml index IX_XMLData_Data on XMLData (Data); 

---- Secondary XML index
create xml index IX_XMLData_Data_ForValue
	on XMLData (Data)
	using xml index IX_XMLData_Data
	for value;

create xml index IX_XMLData_Data_ForPath
	on XMLData (Data)
	using xml index IX_XMLData_Data
	for path;

create xml index IX_XMLData_Data_ForProperty
	on XMLData (Data)
	using xml index IX_XMLData_Data
	for property;

-- Notes:
-- for value: helps queries that search element or attribute values
-- for path: helps queries that use path expressions (especially the exist() expression)
-- for property: similar to path, but especially useful when returning multiple values from the XML data

-- Remove the duplicate row (cleanup for the next demo)
delete XMLData where ID = 2;
Go

select * from XMLData;
Go