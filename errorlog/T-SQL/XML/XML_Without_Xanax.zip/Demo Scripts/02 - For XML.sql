use XMLWithoutXanax;
GO

-- The source data
select * from InvoiceHeader;
select * from InvoiceDetail;
Go

-- FOR XML examples:
---- Basic syntax
select
	ih.InvoiceNumber
	, ih.InvoiceDate
	, ih.InvoiceStatus
	, ih.CustomerFirstName
	, ih.CustomerLastName
	, ih.SubTotal
	, ih.TaxAmount
	, ih.ShippingAmount
	, ih.Total
from InvoiceHeader ih
for xml path ('Invoice'), root ('Invoices'), type;
Go

---- Attributes and elements
select
	ih.InvoiceNumber '@Number'
	, ih.InvoiceDate '@Date'
	, ih.InvoiceStatus '@Status'
	, ih.CustomerNumber 'Customer/@Number'
	, ih.CustomerFirstName 'Customer/FirstName'
	, ih.CustomerLastName 'Customer/LastName'
	, ih.Total 'Amount/@Total'
	, ih.SubTotal 'Amount/SubTotal'
	, ih.TaxAmount 'Amount/Tax'
	, ih.ShippingAmount 'Amount/Shipping'
from InvoiceHeader ih
for xml path ('Invoice'), root ('Invoices'), type;
Go

---- Nested FOR XML statements
select
	ih.InvoiceNumber '@Number'
	, ih.InvoiceDate '@Date'
	, ih.InvoiceStatus '@Status'
	, ih.CustomerNumber 'Customer/@Number'
	, ih.CustomerFirstName 'Customer/FirstName'
	, ih.CustomerLastName 'Customer/LastName'
	, (
		select
			id.ProductNumber 'Product/Number'
			, id.ProductDescription 'Product/Description'
			, id.Quantity
			, id.LineTotal 'Price/@LineTotal'
			, id.UnitPrice 'Price/UnitPrice'
			, id.UnitDiscount 'Price/UnitDiscount'
			, id.UnitSubTotal 'Price/UnitSubTotal'
		from InvoiceDetail id
		where id.InvoiceNumber = ih.InvoiceNumber
		order by id.LineNumber
		for xml path('LineItem'), type
	) 'LineItems'
	, ih.Total 'Amount/@Total'
	, ih.SubTotal 'Amount/SubTotal'
	, ih.TaxAmount 'Amount/Tax'
	, ih.ShippingAmount 'Amount/Shipping'
from InvoiceHeader ih
order by ih.InvoiceNumber
for xml path ('Invoice'), root ('Invoices'), type;
Go