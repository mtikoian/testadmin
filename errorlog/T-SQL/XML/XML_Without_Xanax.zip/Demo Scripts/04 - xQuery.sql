use XMLWithoutXanax;
GO

-- xQuery: value() - Get scalar values
select
	d.Data.value('local-name((/*/*)[1])', 'varchar(10)') ExampleElementName
	, d.Data.value('local-name((/*/*/@*)[1])', 'varchar(10)') ExampleAttributeName
	, d.Data.value(N'(/Invoices/Invoice/Customer/FirstName)[1]', 'varchar(25)') CustomerFirstName
	, d.Data.value(N'(/Invoices/Invoice/@Status)[1]', 'varchar(25)') InvoiceStatus
from XMLData d;
Go

-- xQuery: nodes() - Get elements and their children.
-- Returns XML-typed data that can only be used by another xQuery function.
select
	i.invoice.value('(Customer/FirstName)[1]', 'varchar(25)') CustomerFirstName
	, i.invoice.value(N'(@Status)[1]', 'varchar(25)') InvoiceStatus
from XMLData d
	cross apply d.Data.nodes('/Invoices/Invoice') i(invoice);
Go

-- xQuery: exist() - Check for the existance of an element or attribute
-- with a specific name or value
select
	i.invoice.value('(@Number)[1]', 'int') InvoiceNumber
	, i.invoice.value('(Customer/FirstName)[1]', 'varchar(25)') CustomerFirstName
	, i.invoice.value('(Customer/LastName)[1]', 'varchar(25)') CustomerLastName
	, i.invoice.value('(Amount/@Total)[1]', 'money') Total
from XMLData d
	cross apply d.Data.nodes('/Invoices/Invoice') i(invoice)
where
	i.invoice.exist('Customer/FirstName[.="SQL"]') = 1;
Go

-- xQuery: query() - Get elements and their children.
-- Returns XML-typed data that can be returned to the user
select
	d.Data.query('(/Invoices/Invoice)[1]') InvoiceLineItems
from XMLData d;
Go

-- Modify some XML
---- Invalid (will fail):
update d
set d.Data = d.Data.modify(N'insert <Status>Active</Status> into (/Invoice/Customer)[1]')
from XMLData d;
Go

---- Insert an element
------ into
declare @xml xml = (select top 1 Data.query('(/Invoices/Invoice)[1]') from XMLData);

set @xml.modify(N'insert <Status>Active</Status> into (/Invoice/Customer)[1]');

select @xml ModifiedXML;
Go

------ before
declare @xml xml = (select top 1 Data.query('(/Invoices/Invoice)[1]') from XMLData);

set @xml.modify(N'insert <Status>Active</Status> before (/Invoice/Customer/FirstName)[1]');

select @xml ModifiedXML;
Go

------ after
declare @xml xml = (select top 1 Data.query('(/Invoices/Invoice)[1]') from XMLData);

set @xml.modify(N'insert <Status>Active</Status> after (/Invoice/Customer/FirstName)[1]');

select @xml ModifiedXML;
Go

---- Insert an attribute
------ value from text
declare @xml xml = (select top 1 Data.query('(/Invoices/Invoice)[1]') from XMLData);

set @xml.modify(N'insert attribute Status {"Active"} into (/Invoice/Customer)[1]');

select @xml ModifiedXML;
Go

------ value from variable
declare @xml xml = (select top 1 Data.query('(/Invoices/Invoice)[1]') from XMLData);
declare @Status varchar(25) = 'Active';

set @xml.modify(N'insert attribute Status {sql:variable("@Status")} into (/Invoice/Customer)[1]');

select @xml ModifiedXML;
Go

---- Update an element's value
declare @xml xml = (select top 1 Data.query('(/Invoices/Invoice)[1]') from XMLData);

set @xml.modify(N'replace value of (/Invoice/Customer/FirstName/text())[1] with "Adam"');

select @xml ModifiedXML;
Go

---- Update an attribute's value
declare @xml xml = (select top 1 Data.query('(/Invoices/Invoice)[1]') from XMLData);

set @xml.modify(N'replace value of (/Invoice/@Status)[1] with "Returned"');

select @xml ModifiedXML;

--update XMLData set Data = @xml where id = 1;
Go

---- Delete an element
declare @xml xml = (select top 1 Data.query('(/Invoices/Invoice)[1]') from XMLData);

set @xml.modify(N'delete (/Invoice/Customer)[1]');

select @xml ModifiedXML;
Go

---- Delete an attribute
declare @xml xml = (select top 1 Data.query('(/Invoices/Invoice)[1]') from XMLData);

set @xml.modify(N'delete (/Invoice/@Status)[1]');

select @xml ModifiedXML;
Go