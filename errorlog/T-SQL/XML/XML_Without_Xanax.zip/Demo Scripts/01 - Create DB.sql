use master;
GO

-- Drop database if it exists
if exists (select top 1 'x' from sys.databases where name = 'XMLWithoutXanax')
	begin
		drop database [XMLWithoutXanax];
	end;
GO

-- Create the database
CREATE DATABASE [XMLWithoutXanax]
	ON PRIMARY (
		NAME = N'XMLWithoutXanax'
		, FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL11.MSSQLSERVER\MSSQL\DATA\XMLWithoutXanax.mdf'
		, SIZE = 10240KB
		, FILEGROWTH = 10240KB
	)
	LOG ON (
		NAME = N'XMLWithoutXanax_log'
		, FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL11.MSSQLSERVER\MSSQL\DATA\XMLWithoutXanax_log.ldf'
		, SIZE = 10240KB
		, FILEGROWTH = 10240KB
	);
GO

use XMLWithoutXanax;
GO

-- Create a couple tables with some tabular data to play with (I know, these aren't exactly normalized...)
create table InvoiceHeader
(
	InvoiceNumber int
	, InvoiceDate datetime not null default getdate()
	, InvoiceStatus varchar(25) not null default 'new'
	, CustomerNumber int not null
	, CustomerFirstName varchar(50) not null
	, CustomerLastName varchar(50) not null
	, SubTotal money not null default $0
	, TaxAmount money not null default $0
	, ShippingAmount money not null default $0
	, Total money not null default $0
	, constraint PK_InvoiceHeader primary key clustered (InvoiceNumber)
);
GO

create table InvoiceDetail
(
	InvoiceNumber int not null
	, LineNumber int not null
	, Quantity int not null default 1
	, ProductNumber int not null
	, ProductDescription varchar(100) not null
	, UnitPrice money not null
	, UnitDiscount money not null default $0
	, UnitSubTotal as UnitPrice - UnitDiscount persisted
	, LineTotal as Quantity * (UnitPrice - UnitDiscount) persisted
	, constraint PK_InvoiceDetail primary key clustered (InvoiceNumber, LineNumber)
	, constraint FK_InvoiceDetail_InvoiceHeader foreign key (InvoiceNumber) references InvoiceHeader (InvoiceNumber)
);
GO

insert InvoiceHeader
(
	InvoiceNumber
	, InvoiceDate
	, InvoiceStatus
	, CustomerNumber
	, CustomerFirstName
	, CustomerLastName
	, SubTotal
	, TaxAmount
	, ShippingAmount
	, Total
)
values
	(1, '2013-11-01 13:01', 'Delivered', 1, 'Lester', 'Tester', $184.2, $13.82, $5, $203.02)
	, (2, '2013-11-02 14:02', 'Shipped', 2, 'Jake', 'Fake', $251.3, $18.85, $10, $280.15)
	, (3, '2013-11-03 15:03', 'Picked', 3, 'SQL', 'Diablo', $577.5, $43.31, $20, $640.81)
	, (4, '2013-11-04 16:04', 'Pending', 2, 'Jake', 'Fake', $543.6, $40.77, $20, $604.37)
	, (5, '2013-11-05 17:05', 'New', 3, 'SQL', 'Diablo', $1034.9, $77.62, $40, $1152.52);
GO

insert InvoiceDetail
(
	InvoiceNumber
	, LineNumber
	, Quantity
	, ProductNumber
	, ProductDescription
	, UnitPrice
	, UnitDiscount
)
values
	(1, 1, 10, 1, 'Whacky Widget', $10, $1.1) -- Line Total: $89
	, (1, 2, 4, 2, 'Rockin'' Ratchet', $25, $1.2) -- Line Total: $95.2

	, (2, 1, 20, 1, 'Whacky Widget', $10, $2.1) -- Line Total: $158
	, (2, 2, 2, 2, 'Rockin'' Ratchet', $25, $2.2) -- Line Total: $45.6
	, (2, 3, 1, 3, 'Crazy Carving', $50, $2.3) -- Line Total: $47.7

	, (3, 1, 30, 1, 'Whacky Widget', $10, $3.1) -- Line Total: $207
	, (3, 2, 3, 2, 'Rockin'' Ratchet', $25, $3.2) -- Line Total: $65.4
	, (3, 3, 5, 3, 'Crazy Carving', $50, $3.3) -- Line Total: $233.5
	, (3, 4, 1, 4, 'Fantastic Fan', $75, $3.4) -- Line Total: $71.6

	, (4, 1, 40, 1, 'Whacky Widget', $10, $4.1) -- Line Total: $236
	, (4, 2, 6, 2, 'Rockin'' Ratchet', $25, $4.2) -- Line Total: $124.8
	, (4, 3, 4, 3, 'Crazy Carving', $50, $4.3) -- Line Total: $182.8

	, (5, 1, 50, 1, 'Whacky Widget', $10, $5.1) -- Line Total: $245
	, (5, 2, 6, 2, 'Rockin'' Ratchet', $25, $5.2) -- Line Total: $118.8
	, (5, 3, 2, 3, 'Crazy Carving', $50, $5.3) -- Line Total: $89.4
	, (5, 4, 7, 4, 'Fantastic Fan', $75, $5.4) -- Line Total: $487.2
	, (5, 5, 1, 5, 'Tremendous Trampoline', $100, $5.5); -- Line Total: $94.5
GO