USE [PM2]
GO

/****** Object:  StoredProcedure [dbo].[LoadPersonPersonV1]    Script Date: 03/23/2011 10:59:38 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO






ALTER PROC [dbo].[LoadPersonPersonV1]
	@UserID UNIQUEIDENTIFIER
	,@SourceID BIGINT
	,@ProfileData XML
	,@Debug TINYINT = 0
AS
BEGIN

	SET NOCOUNT ON

	DECLARE 
		@BatchID		BIGINT
		,@Type			CHAR(1)
	

	
	--Validate SourceID
	IF @SourceID NOT IN (512,513,3,5,9,17,33)
	BEGIN
		RAISERROR('Invalid @SourceID',16,1)
		RETURN 0
	END	
	
	
	--Create a Batch
	INSERT  dbo.Batch (SourceID, BatchDescription)
	SELECT	@SourceID, 
		CASE 
			WHEN @UserID IS NOT NULL THEN 'Contacts' 
			ELSE 'Profile' 
		END
		
	SET @BatchID = SCOPE_IDENTITY();
	
	IF @Debug > 0
		SELECT 'BatchID', @BatchID

	--StagePersonPerson
	INSERT dbo.StagePersonPerson
	        ( BatchID ,
	          SourceID ,
	          SourceKey ,
	          UserID ,
	          Strength
	        )
	        
	SELECT DISTINCT	@BatchID AS BatchID
			,@SourceID AS SourceID
			,REPLACE(CONVERT(NVARCHAR(255),@UserID),'-','')
				+ '|' + ArrayOfContact.Contact.query('*:Profile/*:FirstName').value('.','nvarchar(4000)') 
				+ '|' + ArrayOfContact.Contact.query('*:Profile/*:LastName').value('.','nvarchar(4000)') AS SourceKey
			,@UserID AS UserID
			,dbo.StandardizeStrength(ArrayOfContact.Contact.query('*:ConnectionStrength').value('.','nvarchar(4000)')) AS Strength
	FROM @ProfileData.nodes(N'/*:ArrayOfContact/*:Contact') as ArrayOfContact(Contact)
	
	IF @Debug > 0
		SELECT 'StagePersonPerson', * FROM dbo.StagePersonPerson WHERE BatchID = @BatchID

	--StageStrengthData
	INSERT dbo.StageStrengthData
	        ( BatchID ,
	          SourceID ,
	          UserID ,
	          FirstName ,
	          MiddleName ,
	          LastName ,
	          DataType ,
	          DataValue
	        )
	SELECT DISTINCT 
			@BatchID AS BatchID
			,CASE 
				WHEN SourceID = 'LinkedIn' AND @UserID IS NULL THEN 512
				WHEN SourceID = 'LinkedIn' AND @UserID IS NOT NULL THEN 513
				WHEN SourceID = 'FaceBook' AND @UserID IS NOT NULL THEN 3
				WHEN SourceID = 'Gmail' AND @UserID IS NOT NULL THEN 5
				WHEN SourceID = 'Yahoo' AND @UserID IS NOT NULL THEN 9
				WHEN SourceID = 'Outlook' AND @UserID IS NOT NULL THEN 17
				WHEN SourceID = 'Manual' AND @UserID IS NOT NULL THEN 33
				ELSE 0
			END AS SourceID
			,@UserID AS UserID
			,FirstName
			,MiddleName
			,LastName	
			,DataType
			,DataValue
	FROM
		(SELECT			
			ArrayOfContact.Contact.query('*:Sources').value('.','nvarchar(4000)') as SourceID
			,ArrayOfContact.Contact.query('../../*:Profile/*:FirstName').value('.','nvarchar(4000)') as FirstName
			,ArrayOfContact.Contact.query('../../*:Profile/*:MiddleName').value('.','nvarchar(4000)') as MiddleName
			,ArrayOfContact.Contact.query('../../*:Profile/*:LastName').value('.','nvarchar(4000)') as LastName
			,ArrayOfContact.Contact.query('*:Name').value('.','nvarchar(4000)') as DataType
			,ArrayOfContact.Contact.query('*:Value').value('.','nvarchar(4000)') as DataValue
		FROM @ProfileData.nodes(N'/*:ArrayOfContact/*:Contact/*:ConnectionStrengthData/*:OtherData') as ArrayOfContact(Contact)
		) a
	
	IF @Debug > 0
		SELECT 'StageStrengthData', * FROM dbo.StageStrengthData WHERE BatchID = @BatchID
		
	--StagePersonSelf
	INSERT dbo.StagePersonSelf
	        ( BatchID ,
	          SourceID ,
	          SourceKey ,
	          UserID
	        )
	SELECT DISTINCT
			@BatchID AS BatchID
			,@SourceID AS SourceID
			,REPLACE(CONVERT(NVARCHAR(255),@UserID),'-','')
			+ '|' + ArrayOfContact.Contact.query('*:Profile/*:FirstName').value('.','nvarchar(4000)') 
			+ '|' + ArrayOfContact.Contact.query('*:Profile/*:LastName').value('.','nvarchar(4000)')  AS SourceKey
			,@UserID AS UserID
	FROM @ProfileData.nodes(N'/*:ArrayOfContact/*:Contact') as ArrayOfContact(Contact)
	WHERE ArrayOfContact.Contact.query('*:Profile/*:Connectivity').value('.','nvarchar(4000)') = 'Self'
	
	IF @Debug > 0
		SELECT 'StagePersonSelf', * FROM dbo.StagePersonSelf WHERE BatchID = @BatchID

		
	--StageImageURL
	INSERT dbo.StageImageURL
        ( BatchID ,
          SourceID ,
          SourceKey ,
          UserID ,
          NodeTypeID ,
          ImageURL
        )
	SELECT DISTINCT 
		@BatchID AS BatchID
		,@SourceID AS SourceID
		,REPLACE(CONVERT(NVARCHAR(255),@UserID),'-','')
			+ '|' + ArrayOfContact.Contact.query('*:Profile/*:FirstName').value('.','nvarchar(4000)') 
			+ '|' + ArrayOfContact.Contact.query('*:Profile/*:LastName').value('.','nvarchar(4000)')  AS SourceKey
		,@UserID as UserID
		,1 as NodeTypeID
		,dbo.StandardizeImageURL(ArrayOfContact.Contact.query('*:Profile/*:ImageUrl').value('.','nvarchar(4000)')) AS ImageURL
	FROM @ProfileData.nodes(N'/*:ArrayOfContact/*:Contact') as ArrayOfContact(Contact)
	WHERE dbo.StandardizeImageURL(ArrayOfContact.Contact.query('*:Profile/*:ImageUrl').value('.','nvarchar(4000)')) is NOT NULL
	
	IF @Debug > 0
		SELECT 'StageImageURL', * FROM dbo.StageImageURL WHERE BatchID = @BatchID

	--StagePersonName
	INSERT dbo.StagePersonName
        ( BatchID ,
          SourceID ,
          SourceKey ,
          UserID ,
          NodeTypeID ,
          LastName ,
          FirstName ,
          MiddleName 
        )
	SELECT DISTINCT
		@BatchID as BatchID
		,@SourceID as SourceID
		,REPLACE(CONVERT(NVARCHAR(255),@UserID),'-','')
			+ '|' + ArrayOfContact.Contact.query('*:Profile/*:FirstName').value('.','nvarchar(4000)') 
			+ '|' + ArrayOfContact.Contact.query('*:Profile/*:LastName').value('.','nvarchar(4000)')  AS SourceKey
		,@UserID as UserID
		,1 as NodeTypeID
		,ArrayOfContact.Contact.query('*:Profile/*:LastName').value('.','nvarchar(4000)') as LastName
		,ArrayOfContact.Contact.query('*:Profile/*:FirstName').value('.','nvarchar(4000)') as FirstName
		,ArrayOfContact.Contact.query('*:Profile/*:MiddleName').value('.','nvarchar(4000)') as MiddleName
	FROM @ProfileData.nodes(N'/*:ArrayOfContact/*:Contact') as ArrayOfContact(Contact)
	
	IF @Debug > 0
		SELECT 'StagePersonName', * FROM dbo.StagePersonName WHERE BatchID = @BatchID

	--StageMiscellany
	INSERT dbo.StageMiscellany
        ( BatchID ,
          SourceID ,
          SourceKey ,
          UserID ,
          NodeTypeID ,
          Descr ,
          Miscellany
        )
	SELECT DISTINCT
		@BatchID as BatchID
		,CASE 
				WHEN SourceID = 'LinkedIn' AND @UserID IS NULL THEN 512
				WHEN SourceID = 'LinkedIn' AND @UserID IS NOT NULL THEN 513
				WHEN SourceID = 'FaceBook' AND @UserID IS NOT NULL THEN 3
				WHEN SourceID = 'Gmail' AND @UserID IS NOT NULL THEN 5
				WHEN SourceID = 'Yahoo' AND @UserID IS NOT NULL THEN 9
				WHEN SourceID = 'Outlook' AND @UserID IS NOT NULL THEN 17
				ELSE 0
			END AS SourceID
		,SourceKey
		,@UserID AS UserID
		,1 AS NodeTypeID
		,Descr
		,Miscellany
	FROM
		(SELECT 		
			ArrayOfContact.Contact.query('*:Sources').value('.','nvarchar(4000)')  as SourceID --convert
			,REPLACE(CONVERT(NVARCHAR(255),@UserID),'-','')
				+ '|' + ArrayOfContact.Contact.query('../../*:FirstName').value('.','nvarchar(4000)') 
				+ '|' + ArrayOfContact.Contact.query('../../*:LastName').value('.','nvarchar(4000)')  AS SourceKey
			,ArrayOfContact.Contact.query('*:Name').value('.','nvarchar(4000)')  as Descr
			,ArrayOfContact.Contact.query('*:Value').value('.','nvarchar(4000)')  as Miscellany
		FROM @ProfileData.nodes(N'/*:ArrayOfContact/*:Contact/*:Profile/*:AdditionalData/*:OtherData') as ArrayOfContact(Contact)	
		WHERE LEN(ArrayOfContact.Contact.query('*:Name').value('.','nvarchar(4000)')) > 0
		) a					
		
	IF @Debug > 0
		SELECT 'StageMiscellany', * FROM dbo.StageMiscellany WHERE BATCHID = @BatchID
		
	--StageEmail
	INSERT dbo.StageEmail
	        ( BatchID ,
	          SourceID ,
	          SourceKey ,
	          UserID ,
	          NodeTypeID ,
	          Email ,
	          Descr
	        )
	SELECT DISTINCT
			@BatchID AS BatchID
			,CASE 
				WHEN SourceID = 'LinkedIn' AND @UserID IS NULL THEN 512
				WHEN SourceID = 'LinkedIn' AND @UserID IS NOT NULL THEN 513
				WHEN SourceID = 'FaceBook' AND @UserID IS NOT NULL THEN 3
				WHEN SourceID = 'Gmail' AND @UserID IS NOT NULL THEN 5
				WHEN SourceID = 'Yahoo' AND @UserID IS NOT NULL THEN 9
				WHEN SourceID = 'Outlook' AND @UserID IS NOT NULL THEN 17
				ELSE 0
			END AS SourceID
			,SourceKey
			,@UserID AS UserID
			,1 AS NodeTypeID
			,dbo.StandardizeEmail(Email)
			,Descr
	FROM
		(
			SELECT
				ArrayOfContact.Contact.query('*:Sources').value('.','nvarchar(4000)') AS SourceID 
				,REPLACE(CONVERT(NVARCHAR(255),@UserID),'-','')
					+ '|' + ArrayOfContact.Contact.query('../../*:FirstName').value('.','nvarchar(4000)') 
					+ '|' + ArrayOfContact.Contact.query('../../*:LastName').value('.','nvarchar(4000)')  AS SourceKey
				,ArrayOfContact.Contact.query('*:Value').value('.','nvarchar(4000)') AS Email
				,ArrayOfContact.Contact.query('*:Description').value('.','nvarchar(4000)') AS Descr
			FROM @ProfileData.nodes(N'/*:ArrayOfContact/*:Contact/*:Profile/*:ContactInfo/*:ContactItem') as ArrayOfContact(Contact)
			WHERE ArrayOfContact.Contact.query('*:Type').value('.','nvarchar(4000)') = 'Email'
		) a			
		
	IF @Debug > 0
		SELECT 'StageEmail', * FROM dbo.StageEmail WHERE BATCHID = @BatchID		
			
	--StagePhone
	INSERT dbo.StagePhone
	        ( BatchID ,
	          SourceID ,
	          SourceKey ,
	          UserID ,
	          NodeTypeID ,
	          Phone,
	          Descr
	        )
	SELECT DISTINCT
			@BatchID AS BatchID
			,CASE 
				WHEN SourceID = 'LinkedIn' AND @UserID IS NULL THEN 512
				WHEN SourceID = 'LinkedIn' AND @UserID IS NOT NULL THEN 513
				WHEN SourceID = 'FaceBook' AND @UserID IS NOT NULL THEN 3
				WHEN SourceID = 'Gmail' AND @UserID IS NOT NULL THEN 5
				WHEN SourceID = 'Yahoo' AND @UserID IS NOT NULL THEN 9
				WHEN SourceID = 'Outlook' AND @UserID IS NOT NULL THEN 17
				ELSE 0
			END AS SourceID	
			,SourceKey
			,@UserID AS UserID
			,1 AS NodeTypeID
			,dbo.StandardizePhone(Phone) 
			,Descr 
	FROM (
			SELECT
				ArrayOfContact.Contact.query('*:Sources').value('.','nvarchar(4000)') AS SourceID --need to convert
				,REPLACE(CONVERT(NVARCHAR(255),@UserID),'-','')
					+ '|' + ArrayOfContact.Contact.query('../../*:FirstName').value('.','nvarchar(4000)') 
					+ '|' + ArrayOfContact.Contact.query('../../*:LastName').value('.','nvarchar(4000)')  AS SourceKey
				,ArrayOfContact.Contact.query('*:Value').value('.','nvarchar(4000)') AS Phone
				,ArrayOfContact.Contact.query('*:Description').value('.','nvarchar(4000)') AS Descr
			FROM @ProfileData.nodes(N'/*:ArrayOfContact/*:Contact/*:Profile/*:ContactInfo/*:ContactItem') as ArrayOfContact(Contact)
			WHERE ArrayOfContact.Contact.query('*:Type').value('.','nvarchar(4000)') = 'Phone'
		) a 
		
	IF @Debug > 0
		SELECT 'StagePhone', * FROM dbo.StagePhone WHERE BATCHID = @BatchID		
		
	--StageFax
	INSERT dbo.StageFax
	        ( BatchID ,
	          SourceID ,
	          SourceKey ,
	          UserID ,
	          NodeTypeID ,
	          Fax,
	          Descr
	        )
	SELECT DISTINCT
			@BatchID AS BatchID
			,CASE 
				WHEN SourceID = 'LinkedIn' AND @UserID IS NULL THEN 512
				WHEN SourceID = 'LinkedIn' AND @UserID IS NOT NULL THEN 513
				WHEN SourceID = 'FaceBook' AND @UserID IS NOT NULL THEN 3
				WHEN SourceID = 'Gmail' AND @UserID IS NOT NULL THEN 5
				WHEN SourceID = 'Yahoo' AND @UserID IS NOT NULL THEN 9
				WHEN SourceID = 'Outlook' AND @UserID IS NOT NULL THEN 17
				ELSE 0
			END AS SourceID 
			,SourceKey 
			,@UserID AS UserID
			,1 AS NodeTypeID
			,dbo.StandardizePhone(Fax)
			,Descr 
	FROM 
	(
		SELECT 				
			ArrayOfContact.Contact.query('*:Sources').value('.','nvarchar(4000)') AS SourceID --need to convert
			,REPLACE(CONVERT(NVARCHAR(255),@UserID),'-','')
				+ '|' + ArrayOfContact.Contact.query('../../*:FirstName').value('.','nvarchar(4000)') 
				+ '|' + ArrayOfContact.Contact.query('../../*:LastName').value('.','nvarchar(4000)')  AS SourceKey
			,ArrayOfContact.Contact.query('*:Value').value('.','nvarchar(4000)') AS Fax
			,ArrayOfContact.Contact.query('*:Description').value('.','nvarchar(4000)') AS Descr
		FROM @ProfileData.nodes(N'/*:ArrayOfContact/*:Contact/*:Profile/*:ContactInfo/*:ContactItem') as ArrayOfContact(Contact)
		WHERE ArrayOfContact.Contact.query('*:Type').value('.','nvarchar(4000)') = 'Fax'
	) a 	
	
	IF @Debug > 0
		SELECT 'StageFax', * FROM dbo.StageFax WHERE BATCHID = @BatchID
	
	--StageContactItem
	INSERT dbo.StageContactItem
	        ( BatchID ,
	          SourceID ,
	          SourceKey ,
	          UserID ,
	          NodeTypeID ,
	          Value ,
	          Descr
	        )
	SELECT DISTINCT
			@BatchID AS BatchID
			,CASE 
				WHEN SourceID = 'LinkedIn' AND @UserID IS NULL THEN 512
				WHEN SourceID = 'LinkedIn' AND @UserID IS NOT NULL THEN 513
				WHEN SourceID = 'FaceBook' AND @UserID IS NOT NULL THEN 3
				WHEN SourceID = 'Gmail' AND @UserID IS NOT NULL THEN 5
				WHEN SourceID = 'Yahoo' AND @UserID IS NOT NULL THEN 9
				WHEN SourceID = 'Outlook' AND @UserID IS NOT NULL THEN 17
				ELSE 0
			END AS SourceID 
			,SourceKey 
			,@UserID AS UserID
			,1 AS NodeTypeID
			,Value
			,Descr
	FROM 
	(
		SELECT 
			ArrayOfContact.Contact.query('*:Sources').value('.','nvarchar(4000)') AS SourceID --need to convert
			,REPLACE(CONVERT(NVARCHAR(255),@UserID),'-','')
				+ '|' + ArrayOfContact.Contact.query('../../*:FirstName').value('.','nvarchar(4000)') 
				+ '|' + ArrayOfContact.Contact.query('../../*:LastName').value('.','nvarchar(4000)')  AS SourceKey
			,ArrayOfContact.Contact.query('*:Value').value('.','nvarchar(4000)') AS Value
			,ArrayOfContact.Contact.query('*:Description').value('.','nvarchar(4000)') AS Descr
		FROM @ProfileData.nodes(N'/*:ArrayOfContact/*:Contact/*:Profile/*:ContactInfo/*:ContactItem') as ArrayOfContact(Contact)
		WHERE ArrayOfContact.Contact.query('*:Type').value('.','nvarchar(4000)') NOT IN ('Email','Phone','Fax')
	) a		

	IF @Debug > 0
		SELECT 'StageContactItem', * FROM dbo.StageContactItem WHERE BATCHID = @BatchID	
	
		
	--EducationItem GroupName
	INSERT dbo.StageGroupName
	        ( BatchID ,
	          SourceID ,
	          SourceKey ,
	          UserID ,
	          NodeTypeID ,
	          GroupName
	        )
	SELECT DISTINCT 
			@BatchID AS BatchID
			,CASE 
				WHEN SourceID = 'LinkedIn' AND @UserID IS NULL THEN 512
				WHEN SourceID = 'LinkedIn' AND @UserID IS NOT NULL THEN 513
				WHEN SourceID = 'FaceBook' AND @UserID IS NOT NULL THEN 3
				WHEN SourceID = 'Gmail' AND @UserID IS NOT NULL THEN 5
				WHEN SourceID = 'Yahoo' AND @UserID IS NOT NULL THEN 9
				WHEN SourceID = 'Outlook' AND @UserID IS NOT NULL THEN 17
				ELSE 0
			END AS SourceID
			,SourceKey
			,@UserID AS UserID
			,2 AS NodeTypeID
			,GroupName
	FROM 
	( 
		SELECT 			
			ArrayOfContact.Contact.query('*:Sources').value('.','nvarchar(4000)') AS SourceID --need to convert
			,REPLACE(CONVERT(NVARCHAR(255),@UserID),'-','')
				+ '|' + ArrayOfContact.Contact.query('../../*:FirstName').value('.','nvarchar(4000)') 
				+ '|' + ArrayOfContact.Contact.query('../../*:LastName').value('.','nvarchar(4000)') 
				+ '|' + ArrayOfContact.Contact.query('*:Name').value('.','nvarchar(4000)')  AS SourceKey
			,ArrayOfContact.Contact.query('*:Name').value('.','nvarchar(4000)') AS GroupName
		FROM @ProfileData.nodes(N'/*:ArrayOfContact/*:Contact/*:Profile/*:Education/*:EducationItem') as ArrayOfContact(Contact)
	) a
	
	IF @Debug > 0
		SELECT 'StageGroupName', * FROM dbo.StageGroupName WHERE BATCHID = @BatchID
		
	--EducationItem StagePersonGroup
	INSERT dbo.StagePersonGroup
	        ( BatchID ,
	          SourceID ,
	          UserID ,
	          AssociationTypeID ,
	          PersonSourceKey ,
	          GroupSourceKey ,
	          GroupName ,
	          Title ,
	          StartDate ,
	          EndDate
	        )
	SELECT DISTINCT 
			@BatchID AS BatchID
			,CASE 
				WHEN SourceID = 'LinkedIn' AND @UserID IS NULL THEN 512
				WHEN SourceID = 'LinkedIn' AND @UserID IS NOT NULL THEN 513
				WHEN SourceID = 'FaceBook' AND @UserID IS NOT NULL THEN 3
				WHEN SourceID = 'Gmail' AND @UserID IS NOT NULL THEN 5
				WHEN SourceID = 'Yahoo' AND @UserID IS NOT NULL THEN 9
				WHEN SourceID = 'Outlook' AND @UserID IS NOT NULL THEN 17
				ELSE 0
			END AS SourceID
			,@UserID AS UserID
			,2 AS AssociationTypeID
			,PersonSourceKey
			,GroupSourceKey
			,GroupName 
			,dbo.StandardizeTitle(Title) 
			,StartDate
			,EndDate
	FROM 
	(
		SELECT 		
			ArrayOfContact.Contact.query('*:Sources').value('.','nvarchar(4000)') AS SourceID --need to convert
			,REPLACE(CONVERT(NVARCHAR(255),@UserID),'-','')
				+ '|' + ArrayOfContact.Contact.query('../../*:FirstName').value('.','nvarchar(4000)') 
				+ '|' + ArrayOfContact.Contact.query('../../*:LastName').value('.','nvarchar(4000)')   AS PersonSourceKey
			,REPLACE(CONVERT(NVARCHAR(255),@UserID),'-','')
				+ '|' + ArrayOfContact.Contact.query('../../*:FirstName').value('.','nvarchar(4000)') 
				+ '|' + ArrayOfContact.Contact.query('../../*:LastName').value('.','nvarchar(4000)') 
				+ '|' + REPLACE(ArrayOfContact.Contact.query('*:Name').value('.','nvarchar(4000)'),' ','')  AS GroupSourceKey
			,ArrayOfContact.Contact.query('*:Name').value('.','nvarchar(4000)') AS GroupName
			,ArrayOfContact.Contact.query('*:Degree').value('.','nvarchar(4000)') AS Title
			,ArrayOfContact.Contact.query('*:StartYear').value('.','nvarchar(4000)') AS StartDate
			,CASE WHEN ArrayOfContact.Contact.query('*:EndYear').value('.','nvarchar(4000)') = 0 THEN NULL ELSE ArrayOfContact.Contact.query('*:EndYear').value('.','nvarchar(4000)') END AS EndDate
		FROM @ProfileData.nodes(N'/*:ArrayOfContact/*:Contact/*:Profile/*:Education/*:EducationItem') as ArrayOfContact(Contact)
	) a 	
	
	IF @Debug > 0
		SELECT 'StagePersonGroup', * FROM dbo.StagePersonGroup WHERE BATCHID = @BatchID	
	
	--WorkItem StageGroupName
	INSERT dbo.StageGroupName
	        ( BatchID ,
	          SourceID ,
	          SourceKey ,
	          UserID ,
	          NodeTypeID ,
	          GroupName
	        )
	SELECT DISTINCT 
			@BatchID AS BatchID
			,CASE 
				WHEN SourceID = 'LinkedIn' AND @UserID IS NULL THEN 512
				WHEN SourceID = 'LinkedIn' AND @UserID IS NOT NULL THEN 513
				WHEN SourceID = 'FaceBook' AND @UserID IS NOT NULL THEN 3
				WHEN SourceID = 'Gmail' AND @UserID IS NOT NULL THEN 5
				WHEN SourceID = 'Yahoo' AND @UserID IS NOT NULL THEN 9
				WHEN SourceID = 'Outlook' AND @UserID IS NOT NULL THEN 17
				ELSE 0
			END AS SourceID
			,SourceKey
			,@UserID AS UserID
			,2 AS NodeTypeID
			,GroupName 
	FROM 
	(
		SELECT 
			ArrayOfContact.Contact.query('*:Sources').value('.','nvarchar(4000)') AS SourceID --need to convert
			,REPLACE(CONVERT(NVARCHAR(255),@UserID),'-','')
				+ '|' + ArrayOfContact.Contact.query('../../*:FirstName').value('.','nvarchar(4000)') 
				+ '|' + ArrayOfContact.Contact.query('../../*:LastName').value('.','nvarchar(4000)') 
				+ '|' + replace(ArrayOfContact.Contact.query('*:Name').value('.','nvarchar(4000)'),' ','')  AS SourceKey
			,ArrayOfContact.Contact.query('*:Name').value('.','nvarchar(4000)') AS GroupName
		FROM @ProfileData.nodes(N'/*:ArrayOfContact/*:Contact/*:Profile/*:Employment/*:WorkItem') as ArrayOfContact(Contact)
	) a	
	
	IF @Debug > 0
		SELECT 'StageGroupName', * FROM dbo.StageGroupName WHERE BATCHID = @BatchID
	
	--WorkItem StageIndustry
	INSERT dbo.StageIndustry
	        ( BatchID ,
	          SourceID ,
	          SourceKey ,
	          UserID ,
	          NodeTypeID ,
	          Industry
	        )
	SELECT DISTINCT
			@BatchID AS BatchID
			,CASE 
				WHEN SourceID = 'LinkedIn' AND @UserID IS NULL THEN 512
				WHEN SourceID = 'LinkedIn' AND @UserID IS NOT NULL THEN 513
				WHEN SourceID = 'FaceBook' AND @UserID IS NOT NULL THEN 3
				WHEN SourceID = 'Gmail' AND @UserID IS NOT NULL THEN 5
				WHEN SourceID = 'Yahoo' AND @UserID IS NOT NULL THEN 9
				WHEN SourceID = 'Outlook' AND @UserID IS NOT NULL THEN 17
				ELSE 0
			END AS SourceID
			,SourceKey
			,@UserID AS UserID
			,2 AS NodeTypeID
			,dbo.StandardizeIndustry(Industry) 
	FROM 
	(
		SELECT 
			ArrayOfContact.Contact.query('*:Sources').value('.','nvarchar(4000)') AS SourceID --need to convert
			,REPLACE(CONVERT(NVARCHAR(255),@UserID),'-','')
				+ '|' + ArrayOfContact.Contact.query('../../*:FirstName').value('.','nvarchar(4000)') 
				+ '|' + ArrayOfContact.Contact.query('../../*:LastName').value('.','nvarchar(4000)') 
				+ '|' + REPLACE(ArrayOfContact.Contact.query('*:Name').value('.','nvarchar(4000)'),' ','')  AS SourceKey
			,ArrayOfContact.Contact.query('*:Industry').value('.','nvarchar(4000)') AS Industry
		FROM @ProfileData.nodes(N'/*:ArrayOfContact/*:Contact/*:Profile/*:Employment/*:WorkItem') as ArrayOfContact(Contact)
	) a		
	
	IF @Debug > 0
		SELECT 'StageIndustry', * FROM dbo.StageIndustry WHERE BATCHID = @BatchID
		
	--WorkItem StagePersonGroup
	INSERT dbo.StagePersonGroup
	        ( BatchID ,
	          SourceID ,
	          UserID ,
	          AssociationTypeID ,
	          PersonSourceKey ,
	          GroupSourceKey ,
	          GroupName ,
	          Title ,
	          StartDate ,
	          EndDate
	        )
	SELECT 
			@BatchID AS BatchID
			,CASE 
				WHEN SourceID = 'LinkedIn' AND @UserID IS NULL THEN 512
				WHEN SourceID = 'LinkedIn' AND @UserID IS NOT NULL THEN 513
				WHEN SourceID = 'FaceBook' AND @UserID IS NOT NULL THEN 3
				WHEN SourceID = 'Gmail' AND @UserID IS NOT NULL THEN 5
				WHEN SourceID = 'Yahoo' AND @UserID IS NOT NULL THEN 9
				WHEN SourceID = 'Outlook' AND @UserID IS NOT NULL THEN 17
				ELSE 0
			END AS SourceID
			,@UserID AS UserID
			,1 AS AssociationTypeID
			,PersonSourceKey
			,GroupSourceKey 
			,GroupName 
			,dbo.StandardizeTitle(Title) 
			,StartDate
			,EndDate
	FROM 
	(
		SELECT 			
			ArrayOfContact.Contact.query('*:Sources').value('.','nvarchar(4000)') AS SourceID --need to convert
			,REPLACE(CONVERT(NVARCHAR(255),@UserID),'-','')
				+ '|' + ArrayOfContact.Contact.query('../../*:FirstName').value('.','nvarchar(4000)') 
				+ '|' + ArrayOfContact.Contact.query('../../*:LastName').value('.','nvarchar(4000)')   AS PersonSourceKey
			,REPLACE(CONVERT(NVARCHAR(255),@UserID),'-','')
				+ '|' + ArrayOfContact.Contact.query('../../*:FirstName').value('.','nvarchar(4000)') 
				+ '|' + ArrayOfContact.Contact.query('../../*:LastName').value('.','nvarchar(4000)') 
				+ '|' + REPLACE(ArrayOfContact.Contact.query('*:Name').value('.','nvarchar(4000)'),' ','')  AS GroupSourceKey
			,ArrayOfContact.Contact.query('*:Name').value('.','nvarchar(4000)') AS GroupName
			,ArrayOfContact.Contact.query('*:Position').value('.','nvarchar(4000)') AS Title
			,ArrayOfContact.Contact.query('*:StartYear').value('.','nvarchar(4000)') AS StartDate
			,CASE WHEN ArrayOfContact.Contact.query('*:EndYear').value('.','nvarchar(4000)') = 0 THEN NULL ELSE ArrayOfContact.Contact.query('*:EndYear').value('.','nvarchar(4000)') END AS EndDate
		FROM @ProfileData.nodes(N'/*:ArrayOfContact/*:Contact/*:Profile/*:Employment/*:WorkItem') as ArrayOfContact(Contact)
	) a
	
	IF @Debug > 0
		SELECT 'StagePersonGroup', * FROM dbo.StagePersonGroup WHERE BATCHID = @BatchID
END




GO


