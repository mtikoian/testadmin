SELECT TOP 10 * FROM PeopleMaps.dbo.contacts
SELECT TOP 10 * FROM PeopleMaps.dbo.contact_company
SELECT TOP 10 * FROM PeopleMaps.dbo.contact_email


DECLARE @userid UNIQUEIDENTIFIER, @xml xml

DECLARE cur CURSOR FOR 
	SELECT TOP 1 user_id
	FROM PeopleMaps.dbo.contacts
	GROUP BY user_id
	HAVING COUNT(*) > 10 
OPEN cur
WHILE 1=1
BEGIN	
	FETCH NEXT FROM cur INTO @userid
	IF @@fetch_status !=0
		BREAK

	SELECT @xml = (	
	SELECT TOP 50
		CASE strength WHEN 'High' THEN 1 WHEN 'Medium' THEN 2 WHEN 'Low' THEN 3 END AS "ConnectionStrength"
		, -- connectionstrengthdata
		(
			SELECT 
				Item AS "Name"
				,Sources AS "Sources"
				,Val AS "Value"
			FROM			
			(SELECT 
				'NumEmailsFrom' AS Item
				,'Manual' AS Sources
				,10 AS Val
			UNION ALL
			SELECT 
				'NumEmailsTo' 
				,'Manual' 
				,34 
			) a
		 FOR XML PATH('OtherData'), ROOT('ConnectionStrengthData'),  TYPE
		)	 
		,CASE WHEN users_own_contact = 1 THEN 'Self' ELSE '' END AS "Profile/Connectivity"
		,'http://images.google.com/images?q=motgomery+burns' AS "Profile/ImageUrl"
		,0 AS "Profile/NodeId"
		,'PersonCard' AS "Profile/Type"
		,(SELECT TOP 1 company_name FROM PeopleMaps.dbo.contact_company cc WHERE contact_id = c.contact_id AND to_time > GETDATE()) AS "Profile/Company"
		,0 AS "Profile/CompanyNodeID"
		,first_name AS "Profile/FirstName" 
		,'false'AS "Profile/IsRequestor"
		,last_name AS "Profile/LastName"
		,middle_name AS "Profile/MiddleName" 
		,NULL AS "Profile/PeopleInCommon"
		,(SELECT TOP 1 cc.company_role FROM PeopleMaps.dbo.contact_company cc WHERE contact_id = c.contact_id AND to_time > GETDATE()) AS "Profile/Position"
		, -- AdditionalData
		(
			SELECT 
				Item AS "Name"
				,Sources AS "Sources"
				,Val AS "Value"
			FROM			
			(SELECT 
				'OD1' AS Item
				,'Manual' AS Sources
				,'Some other data' AS Val
			UNION ALL
			SELECT 
				'OD2' 
				,'Manual' 
				,'Some other data 2' 
			) a
		 FOR XML PATH('OtherData'), TYPE
		) AS "Profile/AdditionalData"
		, --email
		(
			SELECT 
				Descr AS "Descr"
				,Sources AS "Sources"
				,Type AS "Type"
				,VALUE AS "Value"
			FROM 			
			(
				SELECT  
					'work email' AS Descr
					,'Manual' AS Sources
					,'Email' AS "Type"
					,email AS "Value"
				FROM PeopleMaps.dbo.contact_email
				WHERE contact_id = c.contact_id
				UNION ALL
				SELECT	
					'fax'
					,'Manual'
					,'Fax'
					,'801-555-1234'
				UNION ALL
				SELECT	
					'business phone'
					,'Manual'
					,'Phone'
					,'801-555-1235'
				UNION ALL
				SELECT	
					'home phone'
					,'Manual'
					,'Phone'
					,'801-555-1236'
			) a	 
		FOR XML PATH('ContactItem'), TYPE
		) AS "Profile/ContactInfo"
		,--education
		(SELECT 
			'PHD' AS "Degree"
			,CASE WHEN to_time < GETDATE() THEN datepart(year,to_time) ELSE null END AS "EndYear"
			,company_name AS "Name"
			,0 AS NodeID
			,'Manual' AS Sources
			,DATEPART(YEAR,from_time) AS "StartYear"
		FROM PeopleMaps.dbo.contact_company cc
		WHERE cc.contact_id = c.contact_id
			AND cc.is_school = 1
		FOR XML PATH ('EducationItem'), TYPE
		) AS "Profile/Education"
		,--Employment
		(
		 SELECT 
			'XML Hacking' AS "Department"
			,CASE WHEN to_time < GETDATE() THEN datepart(year,to_time) ELSE null END AS "EndYear"
			,1 AS "ExecLevel"
			,'Piracy' AS "Industry"
			,CASE WHEN to_time > GETDATE() OR to_time IS NULL THEN 'true' ELSE 'false' END AS "IsCurrent"
			,company_name AS "Name"
			,0 AS NodeID
			,company_role AS "Position"
			,'Manual' AS Sources
			,DATEPART(YEAR,from_time) AS "StartYear"
		FROM PeopleMaps.dbo.contact_company cc
		WHERE cc.contact_id = c.contact_id
			AND cc.is_school != 1
		FOR XML PATH ('WorkItem'), TYPE
		) AS "Profile/Employment"
	FROM PeopleMaps.dbo.contacts c
	WHERE user_id = @userid
	ORDER BY contact_id
	FOR XML PATH ('Contact'), 
		ROOT ('ArrayOfContact'),
		ELEMENTS XSINIL
	)
	--INSERT dbo.UploadedContactsTemp
	SELECT @userID, 33, @xml
	
END
CLOSE cur
DEALLOCATE cur

