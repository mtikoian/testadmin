USE AdventureWorks
go

--get XML
SELECT 
	emp.EmployeeID AS "Employee/@ID",
	emp.HireDate AS "Employee/Hire-Date",
	per.LastName AS "Employee/Name/Last",
	per.FirstName AS "Employee/Name/First",
	per.MiddleName AS "Employee/Name/Middle"
FROM HumanResources.Employee emp
	INNER JOIN Person.Contact per ON emp.ContactID = per.ContactID
WHERE emp.EmployeeID IN ( 2, 3 )
FOR XML PATH 
	('Employee')			-- name node
	,ROOT('EmployeeRoot')	--add root element
	,ELEMENTS XSINIL		--include empty element
go

--get into variable
DECLARE @xml XML

SELECT @xml = 
	(SELECT 
		emp.EmployeeID AS "Employee/@ID",
		emp.HireDate AS "Employee/Hire-Date",
		per.LastName AS "Employee/Name/Last",
		per.FirstName AS "Employee/Name/First",
		per.MiddleName AS "Employee/Name/Middle"
	FROM HumanResources.Employee emp
		INNER JOIN Person.Contact per ON emp.ContactID = per.ContactID
	WHERE emp.EmployeeID IN ( 2, 3 )
	FOR XML PATH 
		('EmployeeNode')			-- name node
		,ROOT('EmployeeRoot')	--add root element
	)

SELECT @xml
go

--query()
DECLARE @xml XML; SELECT @xml = (SELECT emp.EmployeeID AS "Employee/@ID",emp.HireDate AS "Employee/Hire-Date",per.LastName AS "Employee/Name/Last",per.FirstName AS "Employee/Name/First",per.MiddleName AS "Employee/Name/Middle" FROM HumanResources.Employee emp INNER JOIN Person.Contact per ON emp.ContactID = per.ContactID WHERE emp.EmployeeID IN ( 2, 3 )FOR XML PATH ('EmployeeNode') ,ROOT('EmployeeRoot'))

SELECT @xml.query(N'//Hire-Date')
SELECT @xml.query(N'//Last')
SELECT @xml.query(N'/EmployeeRoot/EmployeeNode/Employee/Name/First')

go

--value()
DECLARE @xml XML; SELECT @xml = (SELECT emp.EmployeeID AS "Employee/@ID",emp.HireDate AS "Employee/Hire-Date",per.LastName AS "Employee/Name/Last",per.FirstName AS "Employee/Name/First",per.MiddleName AS "Employee/Name/Middle" FROM HumanResources.Employee emp INNER JOIN Person.Contact per ON emp.ContactID = per.ContactID WHERE emp.EmployeeID IN ( 2, 3 )FOR XML PATH ('EmployeeNode') ,ROOT('EmployeeRoot'))

SELECT @xml.value(N'(//Hire-Date)[1]','datetime')
SELECT @xml.value(N'(//Hire-Date)[2]','datetime')

go

--exist()
DECLARE @xml XML; SELECT @xml = (SELECT emp.EmployeeID AS "Employee/@ID",emp.HireDate AS "Employee/Hire-Date",per.LastName AS "Employee/Name/Last",per.FirstName AS "Employee/Name/First",per.MiddleName AS "Employee/Name/Middle" FROM HumanResources.Employee emp INNER JOIN Person.Contact per ON emp.ContactID = per.ContactID WHERE emp.EmployeeID IN ( 2, 3 )FOR XML PATH ('EmployeeNode') ,ROOT('EmployeeRoot'))

SELECT 
	@xml.exist(N'//Employee[@ID eq "2"]')
	,@xml.value(N'(//Hire-Date)[1]','datetime')

go

--nodes()
DECLARE @xml XML; SELECT @xml = (SELECT emp.EmployeeID AS "Employee/@ID",emp.HireDate AS "Employee/Hire-Date",per.LastName AS "Employee/Name/Last",per.FirstName AS "Employee/Name/First",per.MiddleName AS "Employee/Name/Middle" FROM HumanResources.Employee emp INNER JOIN Person.Contact per ON emp.ContactID = per.ContactID WHERE emp.EmployeeID IN ( 2, 3 )FOR XML PATH ('EmployeeNode') ,ROOT('EmployeeRoot'))

SELECT *
FROM @xml.nodes(N'//Name') AS tbl(col)

go

DECLARE @xml XML; SELECT @xml = (SELECT emp.EmployeeID AS "Employee/@ID",emp.HireDate AS "Employee/Hire-Date",per.LastName AS "Employee/Name/Last",per.FirstName AS "Employee/Name/First",per.MiddleName AS "Employee/Name/Middle" FROM HumanResources.Employee emp INNER JOIN Person.Contact per ON emp.ContactID = per.ContactID WHERE emp.EmployeeID IN ( 2, 3 )FOR XML PATH ('EmployeeNode') ,ROOT('EmployeeRoot'))

SELECT 
	tbl.col.value(N'(First)[1]',N'varchar(100)') AS FirstName
	,tbl.col.value(N'(Last)[1]',N'varchar(100)') AS LastName
FROM @xml.nodes(N'//Name') AS tbl(col)
go

--modify()
DECLARE @xml XML; SELECT @xml = (SELECT emp.EmployeeID AS "Employee/@ID",emp.HireDate AS "Employee/Hire-Date",per.LastName AS "Employee/Name/Last",per.FirstName AS "Employee/Name/First",per.MiddleName AS "Employee/Name/Middle" FROM HumanResources.Employee emp INNER JOIN Person.Contact per ON emp.ContactID = per.ContactID WHERE emp.EmployeeID IN ( 2, 3 )FOR XML PATH ('EmployeeNode') ,ROOT('EmployeeRoot'))

SET @xml.modify(N'delete(//Employee[@ID eq "2"])');

SELECT @xml
go

--Table Direct
SELECT [Resume].query(N'//*:Employment')
FROM HumanResources.JobCandidate
go

