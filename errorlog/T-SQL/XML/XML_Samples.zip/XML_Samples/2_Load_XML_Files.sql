USE SQLSaturday
GO

-- ENABLE xp_cmdshell EXECUTION
EXEC master.dbo.sp_configure 'show advanced options', 1

RECONFIGURE

EXEC master.dbo.sp_configure 'xp_cmdshell', 1

RECONFIGURE

SET NOCOUNT ON

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[_XML]') AND type in (N'U'))
	CREATE TABLE _XML (XMLFileName nvarchar(300), XML_LOAD XML)
	
	TRUNCATE TABLE _XML

DECLARE	@DOS nvarchar(300),
		@DirBaseLocation nvarchar(500),
		@FileName nvarchar(300),
		@SQL nvarchar(1000)

declare @files table (tID int IDENTITY(1,1), XMLFile nvarchar(300))

SELECT @SQL = '', @DOS = ''

SET @DirBaseLocation = 'C:\PSSUG_Presentations\@XML_Shreding_Presantation\2_XML_Files\'

SET @DOS = 'dir /B /O:-D ' + @DirBaseLocation  
INSERT @files
EXEC master..xp_cmdshell @DOS

--SELECT @DirBaseLocation + XMLFile AS XMLFile
--FROM @files 
--WHERE XMLFile like '%.xml'
		 
DECLARE cur CURSOR
	FOR  SELECT XMLFile
		 FROM @files 
		 WHERE XMLFile like '%.xml'
OPEN cur

FETCH NEXT FROM cur INTO @FileName

WHILE @@FETCH_STATUS = 0
BEGIN

BEGIN TRY
	SET @SQL = 'INSERT INTO _XML SELECT ''' + @FileName 
	+ ''', X  FROM OPENROWSET(BULK N''' + @DirBaseLocation + @FileName 
	+ ''', SINGLE_BLOB) as tempXML(X)'

print @sql
	--exec sp_executesql @SQL
	
	FETCH NEXT FROM cur INTO @FileName
END TRY
BEGIN CATCH
	SELECT @SQL, ERROR_MESSAGE()
END CATCH
END	

DEALLOCATE cur

-- DISABLE xp_cmdshell EXECUTION
EXEC master.dbo.sp_configure 'show advanced options', 1

RECONFIGURE

EXEC master.dbo.sp_configure 'xp_cmdshell', 0

RECONFIGURE

/*
INSERT INTO _XML 
SELECT 'C:\PSSUG_Presentations\@XML_Shreding_Presantation\1_XML_Files\InvestmentProperty.xml', X  
FROM OPENROWSET(BULK N'C:\PSSUG_Presentations\@XML_Shreding_Presantation\1_XML_Files\InvestmentProperty.xml', SINGLE_BLOB) as tempXML(X)
*/


-- select * from _XML