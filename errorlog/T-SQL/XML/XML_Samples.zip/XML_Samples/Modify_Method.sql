--	INSERTING **********************************************************************************************************************
DECLARE @myDoc xml;       
SET @myDoc = '<Root>       
    <ProductDescription ProductID="1" ProductName="Road Bike">       
        <Features>       
        </Features>       
    </ProductDescription>       
</Root>';
SELECT @myDoc;

-- insert first feature child (no need to specify as first or as last)       
SET @myDoc.modify('insert <Maintenance>3 year parts and labor extended maintenance is available</Maintenance> into (/Root/ProductDescription/Features)[1]') ;
SELECT @myDoc;

-- insert second feature. We want this to be the first in sequence so use 'as first'       
set @myDoc.modify('insert <Warranty>1 year parts and labor</Warranty> as first  into (/Root/ProductDescription/Features)[1]');
SELECT @myDoc;

-- insert third feature child. This one is the last child of <Features> so use 'as last'       
SET @myDoc.modify('insert <Material>Aluminium</Material> as last into (/Root/ProductDescription/Features)[1]');
SELECT @myDoc;

-- 'after' keyword is used (instead of as first or as last child)       
set @myDoc.modify('insert <BikeFrame>Strong long lasting</BikeFrame> after (/Root/ProductDescription/Features/Material)[1]')
SELECT @myDoc;

DECLARE @newFeatures xml;
SET @newFeatures = N'<Location LocationID="10" >           
        <step>Manufacturing step 1 at this work center</step>           
        <step>Manufacturing step 2 at this work center</step>           
    </Location>';         
-- insert new features from specified variable          
SET @myDoc.modify('           
insert sql:variable("@newFeatures")           
into (/Root)[1] ')           
SELECT @myDoc;

-- insert LaborHours attribute           
SET @myDoc.modify('insert attribute LaborHours {".5" } into (/Root/Location[@LocationID=10])[1] ');           
SELECT @myDoc;   
        
-- insert MachineHours attribute but its value is retrived from a sql variable @Hrs           
DECLARE @Hrs float;           
SET @Hrs =.2;           
SET @myDoc.modify('insert attribute MachineHours {sql:variable("@Hrs") } into (/Root/Location[@LocationID=10])[1] ');           
SELECT @myDoc;           
-- insert sequence of attribute nodes (note the use of ',' and ()            
-- around the attributes.           
SET @myDoc.modify('
insert (            
           attribute SetupHours {".5" },           
           attribute SomeOtherAtt {".2"}           
        )           
into (/Root/Location[@LocationID=10])[1]');           
SELECT @myDoc;

GO


-- DELETING nodes from a document stored in an xml variable **********************************************************************************************************

 DECLARE @myDoc xml
SET @myDoc = '<?Instructions for=TheWC.exe ?> 
<Root>
 <!-- instructions for the 1st work center -->
<Location LocationID="10" 
            LaborHours="1.1"
            MachineHours=".2" >Some text 1
<step>Manufacturing step 1 at this work center</step>
<step>Manufacturing step 2 at this work center</step>
</Location>
</Root>'
SELECT @myDoc

-- delete an attribute
SET @myDoc.modify('delete /Root/Location/@MachineHours')
SELECT @myDoc

-- delete an element
SET @myDoc.modify('delete /Root/Location/step[2]')
SELECT @myDoc

-- delete text node in <Location>
SET @myDoc.modify('delete /Root/Location/text()')
SELECT @myDoc

-- delete all processing instructions
SET @myDoc.modify('delete //processing-instruction()')
SELECT @myDoc

GO



-- REPLACING values in an XML instance **********************************************************************************************************

 DECLARE @myDoc xml
SET @myDoc = '<Root>
<Location LocationID="10" 
            LaborHours="1.1"
            MachineHours=".2" >Manufacturing steps are described here.
<step>Manufacturing step 1 at this work center</step>
<step>Manufacturing step 2 at this work center</step>
</Location>
</Root>'
SELECT @myDoc

-- update text in the first manufacturing step
SET @myDoc.modify('replace value of (/Root/Location/step[1]/text())[1] with "new text describing the manu step"')
SELECT @myDoc

-- update attribute value
SET @myDoc.modify('replace value of (/Root/Location/@LaborHours)[1] with "100.0"')
SELECT @myDoc

SET @myDoc.modify('
  replace value of (/Root/Location[1]/@LaborHours)[1]
  with (
       if (count(/Root/Location[1]/step) > 3) then
         "3.0"
       else
          "1.0"
      )
')
SELECT @myDoc
