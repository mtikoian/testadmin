declare @x xml  = 
'<SOAP-ENV:Envelope xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/">
  <SOAP-ENV:Header>
    <ns1:technicalFields xmlns:ns1="http://icc.pharma.TEST.com/xmlns/amm/ctp/techFields/v1_0">
      <ns1:publicationTimestamp>2011-03-18T10:48:07</ns1:publicationTimestamp>
      <ns1:correlationId>1-1T2R8F 03/18/2011 10:48:07</ns1:correlationId>
    </ns1:technicalFields>
  </SOAP-ENV:Header>
  <SOAP-ENV:Body>
    <ns0:notifyMergeCountry xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ns0="http://iip.TEST.com/cmm/xmlns/2009/Country" operation="Upsert">
      <ns0:countryKey>
        <ns0:CountryCode>US</ns0:CountryCode>
        <ns0:KeyNum>ABCD00123</ns0:KeyNum>
      </ns0:countryKey>
      <countryAttributes id="1-1T1SW9" lastModificationDateTime="2011-03-18T09:33:38" modificationCount="9">
        <AccountableTESTParty>PD</AccountableTESTParty>
        <ActualNumActiveSites>1</ActualNumActiveSites>
        <ActualNumClosedSites>0</ActualNumClosedSites>
        <ActualNumCompletedStudy>0</ActualNumCompletedStudy>
        <ActualNumEnrolled>0</ActualNumEnrolled>
        <ActualNumFollowUpSites>0</ActualNumFollowUpSites>
      </countryAttributes>
    </ns0:notifyMergeCountry>
  </SOAP-ENV:Body>
</SOAP-ENV:Envelope>'

declare @t table (publicationTimestamp datetime, correlationId varchar(30), CountryCode varchar(10))

;WITH XMLNAMESPACES ('http://schemas.xmlsoap.org/soap/envelope/' as [SOAPENV],
			'http://icc.pharma.TEST.com/xmlns/amm/ctp/techFields/v1_0' as ns1,
			'http://iip.TEST.com/cmm/xmlns/2009/Country' as ns0)
INSERT @t			
SELECT c.value('ns1:publicationTimestamp[1]', 'datetime') as publicationTimestamp,
	c.value('ns1:correlationId[1]', 'varchar(30)') as correlationId,
	c.value('../../SOAPENV:Body[1]/ns0:notifyMergeCountry[1]/ns0:countryKey[1]/ns0:CountryCode[1]', 'varchar(10)') as CountryCode
FROM @x.nodes('/SOAPENV:Envelope/SOAPENV:Header/ns1:technicalFields') as t(c)

SELECT * FROM @T

