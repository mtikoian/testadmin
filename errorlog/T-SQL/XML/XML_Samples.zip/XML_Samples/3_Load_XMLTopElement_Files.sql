-- ENABLE xp_cmdshell EXECUTION
EXEC master.dbo.sp_configure 'show advanced options', 1

RECONFIGURE

EXEC master.dbo.sp_configure 'xp_cmdshell', 1

RECONFIGURE

SET NOCOUNT ON

IF OBJECT_ID('tempDB..#XML') IS NOT NULL
	DROP TABLE #XML
	
CREATE TABLE #XML(
	[XMLFileName] [nvarchar](300) NULL,
	[XML_LOAD] [xml] NULL
	)

TRUNCATE TABLE dbo._XMLTopElement

DECLARE	@x xml,
		@DOS nvarchar(300),
		@FileName nvarchar(300),
		@DirBaseLocation nvarchar(500),
		@SQL nvarchar(1000)

declare @files table (tID int IDENTITY(1,1), XMLFile nvarchar(300))

SELECT @SQL = '', @DOS = ''

SET @DirBaseLocation = 'C:\PSSUG_Presentations\@XML_Shreding_Presantation\2_XML_Files\'

SET @DOS = 'dir /C /O:-D ' + @DirBaseLocation  
INSERT @files
EXEC master..xp_cmdshell @DOS

 --SELECT LTRIM(SUBSTRING(LTRIM(SUBSTRING(XMLFile, 25, 300)), CHARINDEX(' ',LTRIM(SUBSTRING(XMLFile, 25, 300))), 300)) AS XMLFile--, LEFT(XMLFile, 10) AS Created
 --FROM @files 
 --WHERE XMLFile IS NOT NULL and (XMLFile like '%.xml' OR XMLFile like '%.dat')

DECLARE cur CURSOR
	FOR  SELECT LTRIM(SUBSTRING(LTRIM(SUBSTRING(XMLFile, 25, 300)), CHARINDEX(' ',LTRIM(SUBSTRING(XMLFile, 25, 300))), 300)) AS XMLFile
		 FROM @files 
		 WHERE XMLFile IS NOT NULL and (XMLFile like '%.xml' OR XMLFile like '%.dat')
OPEN cur

FETCH NEXT FROM cur INTO @FileName

WHILE @@FETCH_STATUS = 0
BEGIN
	BEGIN TRY
		SET @SQL = 'INSERT INTO #XML SELECT ''' + @FileName + ''', X  FROM OPENROWSET(BULK N''' + @DirBaseLocation + @FileName + ''', SINGLE_BLOB) as tempXML(X)'
		exec sp_executesql @SQL
	END TRY
	BEGIN CATCH
		SELECT @SQL, ERROR_MESSAGE()
	END CATCH
	
	FETCH NEXT FROM cur INTO @FileName
END	

DEALLOCATE cur


;WITH CTE_XML AS
(
	SELECT XMLFileName, XML_LOAD, x.value('local-name(.)','NVARCHAR(MAX)') AS TopElementName
	FROM #XML CROSS APPLY XML_LOAD.nodes('/*') a(x)
)
INSERT _XMLTopElement(XMLFileName, XML_LOAD, TopElementName, Direction, Created, Processed, FileTime)
SELECT XMLFileName, XML_LOAD, TopElementName, REPLACE(REPLACE(TopElementName, 'notifyMerge', ''),'notifyUpsert', '') AS  Direction, GETDATE(), 0,
		c.value('.', 'datetime') lastModificationDateTime  
FROM CTE_XML CROSS APPLY XML_LOAD.nodes('/*/*/@lastModificationDateTime') t(c)
	UNION ALL
SELECT XMLFileName, XML_LOAD, TopElementName, REPLACE(REPLACE(TopElementName, 'notifyMerge', ''),'notifyUpsert', '') AS  Direction, GETDATE(), 0,
		null lastModificationDateTime  
FROM CTE_XML CROSS APPLY XML_LOAD.nodes('/notifyUpsertEmployeeInfo') t(c)

-- DISABLE xp_cmdshell EXECUTION
EXEC master.dbo.sp_configure 'show advanced options', 1

RECONFIGURE

EXEC master.dbo.sp_configure 'xp_cmdshell', 0

RECONFIGURE

-- TRUNCATE TABLE dbo._XMLTopElement
--  select * from _XMLTopElement where direction not in ('Contact', 'Site', 'Account', 'Study', 'Country') order by direction





