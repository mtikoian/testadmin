-- element centric
declare @x xml
set @x = 
'<root>
	<personinfo>
	<person id="outer">
		<LN>Grinberg</LN>
		<FN>Alex</FN>
		<address>9200 Welsh Road</address>
		<address>Phila, PA, 19115</address>
	</person>
	<person id="outer">
		<LN>Smith</LN>
		<FN>John</FN>
		<address>519 Elm Street</address>
		<address>Phila, PA, 19116</address>		
	</person>
	<person id="outer">
		<LN>Adams</LN>
		<FN>Debie</FN>
	</person>
	<innerper>
		<person id="inner">
			<LN>inner Adams</LN>
			<FN>inner Debie</FN>
		</person>
	</innerper>
</personinfo>
</root>'
--select @x
select	C.value('LN[1]', 'varchar(20)') as LastName,
		C.value('FN[1]', 'varchar(20)') as FirstName,
		C.value('address[1]', 'varchar(50)') + ' ' + C.value('address[2]', 'varchar(50)') as Address
from @x.nodes('/root/personinfo/person') as T(C)




/*
declare @v varchar(20)
SET @v = 'inner'
--select @x
select	C.value('LN[1]', 'varchar(20)') as LastName,
		C.value('FN[1]', 'varchar(20)') as FirstName,
		C.value('address[1]', 'varchar(50)') + ' ' + C.value('address[2]', 'varchar(50)') as Address
from @x.nodes('//person[@id=sql:variable("@v")]') as T(C)
*/
GO

-- attribute centric
declare @x xml
set @x = '<root>
<person LN="Grinberg" FN="Alex" />
<person LN="Smith" FN="John" />
<person LN="Adams" FN="Debie" />
</root>'
select T.C.value('@LN', 'varchar(20)') as LastName,
		T.C.value('@FN', 'varchar(20)') as FirstName
from @x.nodes('root/person') as T(C)





















/*
XQuery methodes
1. value  -- reads an XML data
2. node	  -- provides path to an XML data
3. query  -- retuns subset from an XML
4. exist  -- check boolean coundition of element, attribute or XML data
5. modify -- allows to make change within an XML data

-- modify methods
declare @xml xml
set @xml =' 
<ROOT>
	<customersCompanyName>Alfreds Futterkiste</customersCompanyName>
	<ContactTitle>Sales Representative</ContactTitle>
	<City>Berlin</City>
	<CompanyName>Ana Trujillo Emparedados y helados</CompanyName>
	<ContactTitle>Owner</ContactTitle>
</ROOT>'

SET @xml.modify('insert <price>0.00</price> before(/ROOT/CompanyName) [1] ')
select @xml
SET @xml.modify('insert <price>0.00</price> after(/ROOT/CompanyName) [1] ')
select @xml
SET @xml.modify('replace value of (/ROOT/price[1]/text())[1] with 9.99 ')
select @xml
SET @xml.modify('delete (/ROOT/price)[1]')
select @xml

*/
declare @xml xml = '<root xmlns:ns0="http://sqlserver/2009">
<ns0:Location LocationID="100" SetupHours="10.4" MachineHours="8.4" LaborHours="9.4" LotSize="11.4" />
</root>';

;WITH XMLNAMESPACES ('http://sqlserver/2009' as ns0)
select C.value('@LocationID', 'int'),
	C.value('@SetupHours', 'float'),
	C.value('@MachineHours', 'float'),
	C.value('@LaborHours', 'float'),
	C.value('@LotSize', 'float') 
from @xml.nodes('//ns0:Location') as T(C)


declare @xml xml 

SET @xml = '<root xmlns:ns0="http://sqlserver/2009">
<Location LocationID="100" SetupHours="10.4" MachineHours="8.4" LaborHours="9.4" LotSize="11.4" />
</root>';

--;WITH XMLNAMESPACES ('http://sqlserver/2009' as ns0)
select C.value('@LocationID', 'int'),
	C.value('@SetupHours', 'float'),
	C.value('@MachineHours', 'float'),
	C.value('@LaborHours', 'float'),
	C.value('@LotSize', 'float') 
from @xml.nodes('root/Location') as T(C)