
--search procs without add-in
SELECT  name ,
        definition
FROM    sys.sql_modules sm
        INNER JOIN sys.objects o ON o.object_id = sm.object_id
WHERE   definition LIKE '%SELECT *%'

--Find mismatches
--Script is from Jonathan Kehayias on SQLSkills Blog
--https://www.sqlskills.com/blogs/jonathan/finding-implicit-column-conversions-in-the-plan-cache/
WITH XMLNAMESPACES 

(DEFAULT 'http://schemas.microsoft.com/sqlserver/2004/07/showplan') 

SELECT cp.usecounts,stmt.value('(@StatementText)[1]', 'varchar(max)') TSQL_Statement, 
t.value('(ScalarOperator/Identifier/ColumnReference/@Schema)[1]', 'varchar(128)') Converted_Schema, 
t.value('(ScalarOperator/Identifier/ColumnReference/@Table)[1]', 'varchar(128)') Converted_Table, 
t.value('(ScalarOperator/Identifier/ColumnReference/@Column)[1]', 'varchar(128)') Converted_Column, 
ic.DATA_TYPE AS ConvertFrom, 
ic.CHARACTER_MAXIMUM_LENGTH AS ConvertFromLength, 
t.value('(@DataType)[1]', 'varchar(128)') AS ConvertTo, 
t.value('(@Length)[1]', 'int') AS ConvertToLength, 
objtype, query_plan 
FROM sys.dm_exec_cached_plans AS cp 
CROSS APPLY sys.dm_exec_query_plan(plan_handle) AS qp 
CROSS APPLY query_plan.nodes('/ShowPlanXML/BatchSequence/Batch/Statements/StmtSimple') AS batch(stmt) 
CROSS APPLY stmt.nodes('.//Convert[@Implicit="1"]') AS n(t) 
JOIN INFORMATION_SCHEMA.COLUMNS AS ic 
ON QUOTENAME(ic.TABLE_SCHEMA) = t.value('(ScalarOperator/Identifier/ColumnReference/@Schema)[1]', 'varchar(128)') 
AND QUOTENAME(ic.TABLE_NAME) = t.value('(ScalarOperator/Identifier/ColumnReference/@Table)[1]', 'varchar(128)') 
AND ic.COLUMN_NAME = t.value('(ScalarOperator/Identifier/ColumnReference/@Column)[1]', 'varchar(128)') 
WHERE t.exist('ScalarOperator/Identifier/ColumnReference[@Database="[SQLMD]"][@Schema!="[sys]"]') = 1 
AND objtype <> 'adhoc'


--Find All the functions being used in stored procs

SELECT o.name Code_Module,fn.name Function_Name,definition 
FROM sys.sql_modules m INNER JOIN sys.objects o ON o.object_id = m.object_id 
CROSS JOIN (SELECT name FROM sys.objects 
WHERE type IN ('fn','tf')) fn 
WHERE definition LIKE '%' + fn.name + '%' AND o.name <> fn.name 
ORDER BY o.name,fn.name 


-- Find Poor Performing queires
--Top 10 by Disk I/O
SELECT TOP 10
[Average IO] = ( total_logical_reads + total_logical_writes )
/ qs.execution_count ,
[Total IO] = ( total_logical_reads + total_logical_writes ) ,
[Execution count] = qs.execution_count ,
[Individual Query] = SUBSTRING(qt.text, qs.statement_start_offset / 2,
( CASE WHEN qs.statement_end_offset = -1
THEN LEN(CONVERT(NVARCHAR(MAX), qt.text))
* 2
ELSE qs.statement_end_offset
END - qs.statement_start_offset ) / 2) ,
[Parent Query] = qt.text ,
DatabaseName = DB_NAME(CONVERT(SMALLINT,att.value))
FROM sys.dm_exec_query_stats qs
CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle) AS qt
CROSS APPLY sys.dm_exec_plan_attributes(qs.plan_handle) att
WHERE att.attribute='dbid'
AND att.value > 4
ORDER BY [Average IO] DESC;

--Top 10 by CPU
SELECT TOP 10
[Average CPU used] = total_worker_time / qs.execution_count ,
[Total CPU used] = total_worker_time ,
[Execution count] = qs.execution_count ,
[Individual Query] = SUBSTRING(qt.text, qs.statement_start_offset / 2,
( CASE WHEN qs.statement_end_offset = -1
THEN LEN(CONVERT(NVARCHAR(MAX), qt.text))
* 2
ELSE qs.statement_end_offset
END - qs.statement_start_offset ) / 2) ,
[Parent Query] = qt.text ,
DatabaseName = DB_NAME(CONVERT(SMALLINT,att.value))
FROM sys.dm_exec_query_stats qs
CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle) AS qt
CROSS APPLY sys.dm_exec_plan_attributes(qs.plan_handle) att
WHERE att.attribute='dbid'
AND att.value > 4
ORDER BY [Average CPU used] DESC;

--Top 10 most run queries
SELECT TOP 10
[Execution count] = execution_count ,
[Individual Query] = SUBSTRING(qt.text, qs.statement_start_offset / 2,
( CASE WHEN qs.statement_end_offset = -1
THEN LEN(CONVERT(NVARCHAR(MAX), qt.text))
* 2
ELSE qs.statement_end_offset
END - qs.statement_start_offset ) / 2) ,
[Parent Query] = qt.text ,
DatabaseName = DB_NAME(CONVERT(SMALLINT,att.value))
FROM sys.dm_exec_query_stats qs
CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle) AS qt
CROSS APPLY sys.dm_exec_plan_attributes(qs.plan_handle) att
WHERE att.attribute='dbid'
AND att.value > 4
ORDER BY [Execution count] DESC;



--Create Extended event session to find deprecatd events
CREATE EVENT SESSION [Deprecated] ON SERVER 
ADD EVENT sqlserver.deprecation_announcement(
    ACTION(sqlserver.sql_text)),
ADD EVENT sqlserver.deprecation_final_support(
    ACTION(sqlserver.sql_text)) 
ADD TARGET package0.ring_buffer(SET max_events_limit=(10))
WITH (MAX_MEMORY=4096 KB,EVENT_RETENTION_MODE=ALLOW_SINGLE_EVENT_LOSS,MAX_DISPATCH_LATENCY=30 SECONDS,MAX_EVENT_SIZE=0 KB,MEMORY_PARTITION_MODE=NONE,TRACK_CAUSALITY=OFF,STARTUP_STATE=OFF)
GO




