use JonTest;
go
-- script 001: valid column data types and properties for identity columns
-- NOTE: that the identity columns do NOT have to be the primary key
--   in the examples in this script, all of the tables are heaps without a primary key.
--   Also, note that a value is not specified for the identity column

----------------------------------------------------------
-- 1. create an identity column of type bigint
if (object_id(N'dbo.bigint_ident', N'U') is not null) drop table dbo.bigint_ident;

create table dbo.bigint_ident (
	bigint_wk bigint not null identity(1,1),
	some_value varchar(50) null
	);

-- insert some data and take a look at it
declare @i bigint = 10000000000;		-- 10,000,000,000 (ten billion)
declare @j int = 1;

while (@j < 15) begin
	insert dbo.bigint_ident (some_value) select cast((@i*@j)+@j as varchar(20));
	set @j = @j+1; 
end
select * from bigint_ident;

drop table dbo.bigint_ident;


go
----------------------------------------------------------
-- 2. create an identity column of type tinyint
if (object_id(N'dbo.tinyint_ident', N'U') is not null) drop table dbo.tinyint_ident;

create table dbo.tinyint_ident (
	tinyint_wk tinyint not null identity(1,1),
	some_value char(10) null
	);

-- insert some data and take a look at it
declare @i tinyint = 100;
declare @j int = 1;

while (@j < 15) begin
	insert dbo.tinyint_ident (some_value) select cast(@i+@j as varchar(20));
	set @j = @j+1; 
end
select * from tinyint_ident;

drop table dbo.tinyint_ident;


go
----------------------------------------------------------
-- 3. create an identity column of type decimal
if (object_id(N'dbo.decimal_ident', N'U') is not null) drop table dbo.decimal_ident;

create table dbo.decimal_ident (
	decimal_wk decimal(16,0) not null identity(1,1),
	some_value char(10) null
	);

-- insert some data and take a look at it
declare @i decimal(16,0) = 1000.0;
declare @j int = 1;

while (@j < 15) begin
	insert dbo.decimal_ident (some_value) select cast(@i+@j as varchar(20));
	set @j = @j+1; 
end
select * from decimal_ident;

drop table dbo.decimal_ident;



go
----------------------------------------------------------
-- 4. create an identity column of type integer with a negative seed
if (object_id(N'dbo.weird_ident', N'U') is not null) drop table dbo.weird_ident;

create table dbo.weird_ident (
	weird_ident_wk int not null identity(-2001002,3),
	some_value char(10) null
	);

-- insert some data and take a look at it
declare @i int = 100;
declare @j int = 1;

while (@j < 15) begin
	insert dbo.weird_ident (some_value) select cast(@i+@j as varchar(20));
	set @j = @j+1; 
end
select * from weird_ident;

--update weird_ident set weird_ident_wk = 3 where weird_ident_wk = -2000999

drop table dbo.weird_ident;


go
----------------------------------------------------------
-- 5. invalid identity definition, cannot have a non-integer identity column
create table dbo.BAD_decimal_ident (
	decimal_wk decimal(16,6) not null identity(1,1),
	some_value char(10) null
	);



go
----------------------------------------------------------
-- 6. invalid, cannot have an inexact data type as an identity column
create table dbo.BAD_float_ident (
	float_wk float not null identity(1,1),
	some_value char(10) null
	);

go



go
----------------------------------------------------------
-- 7. invalid, cannot have a nullable column as with identity property
create table dbo.nullable_ident (
	int_wk int null identity(1,1),
	some_value char(10) null
	);

go
