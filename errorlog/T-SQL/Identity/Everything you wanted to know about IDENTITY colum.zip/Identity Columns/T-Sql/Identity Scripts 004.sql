use JonTest;
go
-- script 004: identity column property functions
-- ident_seed()
-- ident_increment()
-- identity() function
-- ObjectPropertyEx
-- ColumnProperty
-- sys.columns
-- sys.identity_columns


-----------------------------------------------------------------
-- ident_seed()
-- ident_increment()
select
	ident_seed(N'dbo.SqlSaturday') as [ident_seed],
	ident_incr(N'dbo.SqlSaturday') as [ident_incr],
	ident_current(N'dbo.SqlSaturday') as [ident_current]


-----------------------------------------------------------------
-- identity() function
-- used with SELECT ... INTO to add an identity column to the newly created table
if (object_id(N'dbo.new_sqlSaturday', N'U') is not null) drop table dbo.new_sqlSaturday;

select
	identity(int, 1000, 1) as new_wk,
	ss.some_value,
	cast(ss.sqlSaturday_wk as int) as old_wk	-- need to cast; otherwise it will have identity property
into
	dbo.new_sqlSaturday
from
	dbo.sqlSaturday ss

select * from dbo.new_sqlSaturday;

go
sp_help 'dbo.new_sqlSaturday';
go



-----------------------------------------------------------------
-- ObjectPropertyEx
select
	schema_name(t.schema_id) as table_schema,
	t.name as table_name,
	t.create_date
from
	sys.tables t
where
	objectpropertyex(t.object_id, 'TableHasIdentity') = 1
order by
	1,2;



-- ColumnProperty and sys.columns
select
	c.column_id,
	object_name(c.object_id) as table_name,
	c.name as column_name,
	c.is_identity,		-- new to sql2k8
	type_name(c.system_type_id) as data_type,
	c.max_length,
	c.is_nullable,
	columnproperty(c.object_id, c.name, 'IsIdentity') as is_identity,
	columnproperty(c.object_id, c.name, 'IsIdNotForRepl') as is_identity_not_for_replication
from
	sys.columns c
where
	c.object_id = object_id(N'dbo.sqlSaturday', N'U')
order by
	c.column_id;



-- check out this new catalog view for identity columns
-- it is extended from sys.columns
-- NOTE that the seed_value on dbo.sqlSaturday is 1 even though it was reseeded.

select
	ic.column_id,
	object_schema_name(ic.object_id) as schema_name,
	object_name(ic.object_id) as table_name,
	ic.name as column_name,
	ic.is_identity,		-- new to sql2k8
	type_name(ic.system_type_id) as data_type,
	ic.max_length,
	ic.is_nullable,
	ic.seed_value,
	ic.increment_value,
	ic.last_value,
	ic.is_not_for_replication
from
	sys.identity_columns ic
order by
	2,3,4;
