use JonTest;
go
-- script 002: basic workings of an identity column in a table
-- examining @@identity, scope_identity, ident_current

--------------------------------------
-- create a plain table with an identity column

if (object_id(N'dbo.sqlSaturday', N'U') is not null) drop table dbo.sqlSaturday;

create table dbo.sqlSaturday (
	sqlSaturday_wk int not null identity(1,1)
		constraint pk_sqlSaturday primary key clustered,
	some_value varchar(50) not null
	) on [Primary];

-- insert some data and take a look at it
declare @i bigint = 10000000000;		-- 10,000,000,000 (ten billion)
declare @j int = 1;

while (@j < 15) begin
	insert dbo.sqlSaturday (some_value) select cast((@i*@j)+@j as varchar(20));
	set @j = @j+1; 
end

select
	'test one: initial insert' as when_,
	@@identity as [@@IDENTITY],
	scope_identity() as [scope_identity],
	ident_current(N'dbo.sqlSaturday') as [ident_current];

-- look at the last row inserted
select top (1)
	*
from
	dbo.sqlSaturday ss with (readuncommitted)
order by
	ss.sqlSaturday_wk desc;



go
--------------------------------------
-- create an audit table
-- NOTE: the value of the identity seed for the PK

if (object_id(N'dbo.sqlSaturday_audit', N'U') is not null) drop table dbo.sqlSaturday_audit;

create table dbo.sqlSaturday_audit (
	sqlSaturday_audit_wk int identity(1000,1) not null constraint pk_sqlSaturday_audit primary key,
	update_type char(1) not null,
	sqlSaturday_wk int not null,
	some_value_old varchar(50) null,
	some_value_new varchar(50) null,
	audit_dt datetime not null constraint df_sqlSaturday_audit_audit_dt default(getdate())
	) on [Primary];

go

--------------------------------------
-- place a trigger on sqlSaturday to audit changes
-- we're only putting a single trigger here for time
create trigger tI_sqlSaturday 
	on dbo.sqlSaturday
	after insert
as 
begin
	set nocount on;
	
	insert  dbo.sqlSaturday_audit (
		sqlSaturday_wk,
		update_type,
		some_value_old,
		some_value_new
	) select
		ins.sqlSaturday_wk,
		'i' as update_type,
		null as some_value_old,
		ins.some_value as some_value_new
	from
		inserted ins
	
end

go

--------------------------------------
-- insert ANOTHER ten rows of data
declare @idx int = 1;

while (@idx < 11) begin
	insert dbo.sqlSaturday (some_value)
	select CAST(@idx as varchar(20));
	
	set @idx = @idx+1;
end

--------------------------------------
-- notice that the value of @@identity displays the value from the audit table
select
	'test two: insert with trigger' as when_,
	@@identity as [@@IDENTITY],
	scope_identity() as [scope_identity],
	ident_current(N'sqlSaturday') as [ident_current_sqlSaturday],
	ident_current(N'sqlSaturday_audit') as [ident_current_sqlSaturday_audit]

-- look at the last row in sqlSaturday
select top (1)
	*
from
	dbo.sqlSaturday ss with (readuncommitted)
order by
	ss.sqlSaturday_wk desc;

select top (3)
	*
from
	dbo.sqlSaturday_audit ssa with (readuncommitted)
order by
	ssa.sqlSaturday_audit_wk desc;

go
drop table sqlSaturday;
drop table sqlSaturday_audit;
