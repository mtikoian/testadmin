use JonTest;
go
-- script 005: kangaroo increment

--------------------------------------
-- create a table with an identity column; use an identity increment of 5

if (object_id(N'dbo.sqlSaturday', N'U') is not null) drop table dbo.sqlSaturday;

create table dbo.sqlSaturday (
	sqlSaturday_wk int not null identity(0,5)
		constraint pk_sqlSaturday primary key clustered,
	some_value varchar(50) not null
	) on [Primary];

-- insert some data and take a look at it
declare @i bigint = 10000000000;		-- 10,000,000,000 (ten billion)
declare @j int = 1;

while (@j < 15) begin
	insert dbo.sqlSaturday (some_value) select cast((@i*@j)+@j as varchar(20));
	set @j = @j+1; 
end

select
	'kangaroo insert' as when_,
	@@identity as [@@IDENTITY],
	scope_identity() as [scope_identity],
	ident_current(N'dbo.sqlSaturday') as [ident_current],
	ident_seed(N'dbo.SqlSaturday') as [ident_seed],
	ident_incr(N'dbo.SqlSaturday') as [ident_incr];

-- look at the last row inserted
select
	*
from
	dbo.sqlSaturday ss with (readuncommitted)
order by
	ss.sqlSaturday_wk;


go
drop table sqlSaturday;
