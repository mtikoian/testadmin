use JonTest;
go
-- script 003: working with identity columns

-- inserting a value in an identity column using SET IDENTITY_INSERT ON
-- reseeding an identity value: DBCC CHECKIDENT
-- running out of room with an identity column

--------------------------------------
-- create a plain table with an identity column

if (object_id(N'dbo.sqlSaturday', N'U') is not null) drop table dbo.sqlSaturday;

create table dbo.sqlSaturday (
	sqlSaturday_wk int not null identity(1,1)
		constraint pk_sqlSaturday primary key clustered,
	some_value varchar(50) not null,
	create_dt datetime not null constraint df_sqlSaturday_create_dt default (getdate())
	) on [Primary];

-- insert some data
declare @i bigint = 10000000000;		-- 10,000,000,000 (ten billion)
declare @j int = 1;

while (@j < 16) begin
	insert dbo.sqlSaturday (some_value) select cast((@i*@j)+@j as varchar(20));
	set @j = @j+1; 
end

-- look at the last row inserted
select top (1)
	'simple insert' as what_happened,
	scope_identity() as [scope_identity],
	ident_current(N'dbo.sqlSaturday') as [ident_current],
	ss.sqlSaturday_wk,
	ss.some_value,
	ss.create_dt
from
	dbo.sqlSaturday ss with (readuncommitted)
order by
	ss.sqlSaturday_wk desc;



-- now to force a value into the identity column
-- using <<SET IDENTITY_INSERT ON>>

set identity_insert dbo.sqlSaturday on;

insert dbo.sqlSaturday (
	sqlSaturday_wk,
	some_value
	)
select
	92 as sqlSaturday_wk,
	'identity insert ninety two' as some_value;

go
-- Note you cannot update an identity value even if IDENTITY INSERT is on
update dbo.sqlSaturday set sqlSaturday_wk = 993 where sqlSaturday_wk = 92;
go

-- turn the identity insert OFF (don't forget to do this)
set identity_insert dbo.sqlSaturday off;

-- look at the last rows inserted
select
	ss.sqlSaturday_wk,
	ss.some_value,
	ss.create_dt
from
	dbo.sqlSaturday ss with (readuncommitted)
order by
	ss.sqlSaturday_wk desc;


-----------------------------------------------
-- after it is turned back on what happens?
insert dbo.sqlSaturday (
	some_value
	)
select
	'inserting to identity after identity_insert' as some_value;

-- look at the last rows inserted
select
	ss.sqlSaturday_wk,
	ss.some_value,
	ss.create_dt
from
	dbo.sqlSaturday ss with (readuncommitted)
order by
	ss.sqlSaturday_wk desc;



-- NOTE: the identity_insert option resets the identity property
-- ***ONLY*** when the identity value specified is greater than the current maximum value


-- here we set the value to a value less than the current seed
set identity_insert dbo.sqlSaturday on;

insert dbo.sqlSaturday (
	sqlSaturday_wk,
	some_value
	)
select
	-100 as sqlSaturday_wk,
	'system data (-100)' as some_value;

go

-- turn the identity insert OFF (don't forget to do this)
set identity_insert dbo.sqlSaturday off;

-- look at the last rows inserted
select
	ss.sqlSaturday_wk,
	ss.some_value,
	ss.create_dt
from
	dbo.sqlSaturday ss with (readuncommitted)
order by
	ss.create_dt desc;


-----------------------------------------------
-- after it is turned back on what happens?
insert dbo.sqlSaturday (
	some_value
	)
select
	'inserting to identity after -100 identity_insert' as some_value;

-- look at the last rows inserted
select
	ss.sqlSaturday_wk,
	ss.some_value,
	ss.create_dt
from
	dbo.sqlSaturday ss with (readuncommitted)
order by
	ss.create_dt desc;




go
--------------------------------------
-- turn identity insert on for two tables
set identity_insert dbo.sqlSaturday on;
set identity_insert dbo.AllDataType on;
-- turn identity insert off for two tables
set identity_insert dbo.sqlSaturday off;
set identity_insert dbo.AllDataType off;
go




--------------------------------------
-- reseeding an identity value

-- look at the last rows inserted
select
	ss.sqlSaturday_wk,
	ss.some_value
from
	dbo.sqlSaturday ss with (readuncommitted)
order by
	ss.sqlSaturday_wk desc;

-- change identity seed to -50,000
dbcc checkident ('dbo.sqlSaturday', reseed, -50000);

-- look at the Messages tab for additional information
-- also a NORESEED option which is superfluous (replaced by ident_current)



go
-- running out of room with an identity column
-- change identity seed to -2,147,483,648 (minimum value for an integer column)
dbcc checkident ('dbo.sqlSaturday', reseed, -2147483648);

-- insert five new rows
declare @idx int = 0;

while (@idx < 5) begin
	insert dbo.sqlSaturday (
		some_value
		)
	select
		'running out of room reseed' as some_value;
	set @idx = @idx+1;
end

-- look at the last ten rows inserted
select top (20)
	ss.sqlSaturday_wk,
	ss.some_value,
	ss.create_dt
from
	dbo.sqlSaturday ss with (readuncommitted)
order by
	ss.create_dt desc;


-- don't drop table; it will be used in the next script
