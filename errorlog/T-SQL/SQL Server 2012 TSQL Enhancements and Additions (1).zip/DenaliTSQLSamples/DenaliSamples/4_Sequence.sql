SET NOCOUNT ON
USE AdventureWorks2012
GO

/*
ALTER SEQUENCE dbo.SeqOrderIDs
  RESTART WITH <constant>
  INCREMENT BY <constant>
  MINVALUE <constant> | NO MINVALUE
  MAXVALUE <constant> | NO MAXVALUE
  CYCLE | NO CYCLE
  CACHE <constant> | NO CACHE;
*/

/* 1. Creating a sequence Object */
IF EXISTS (select 1 from sys.sequences where name='MyFirstSequence')
DROP SEQUENCE MyFirstSequence;
GO

CREATE SEQUENCE MyFirstSequence START WITH 1;
GO

---- Now with a different Increment.
IF EXISTS (select 1 from sys.sequences where name='MySecondSequence')
DROP SEQUENCE MySecondSequence;
GO

CREATE SEQUENCE MySecondSequence START WITH 0 INCREMENT BY 2;
GO

-- Now with Min Value and Cycle.
IF EXISTS (select 1 from sys.sequences where name='MyThirdSequence')
DROP SEQUENCE MyThirdSequence;
GO

CREATE SEQUENCE MyThirdSequence START WITH 0 INCREMENT BY 2 MINVALUE -11 MAXVALUE 10 CYCLE;
GO


-- Now with Min Value and Cycle.
IF EXISTS (select 1 from sys.sequences where name='MyFourthSequence')
DROP SEQUENCE MyFourthSequence;
GO
CREATE SEQUENCE MyFourthSequence START WITH 0 INCREMENT BY -1 MINVALUE -11 MAXVALUE 10 CYCLE;
GO


/* 2. using NEXT VALUE FOR */

--Simple
DECLARE @Value INT = NEXT VALUE FOR MyFirstSequence
SELECT @Value

GO

--In a select list
SELECT NEXT VALUE FOR MyFirstSequence,object_id
FROM sys.all_columns

GO

---Let's see how it works with the cycle sequence
SELECT NEXT VALUE FOR MyThirdSequence,object_id
FROM sys.all_columns

GO

---Let's see how it works with the cycle sequence in the other way
SELECT NEXT VALUE FOR MyFourthSequence,object_id
FROM sys.all_columns

GO


--In a select list using ORDER BY
SELECT NEXT VALUE FOR MyFirstSequence,object_id
FROM sys.all_columns
ORDER BY name

GO

--- OH NO!! here is how to do it.  SHOW ACTUAL EXECUTION PLAN FOR NEXT 2
SELECT NEXT VALUE FOR MyFirstSequence OVER (ORDER BY Name),object_id
FROM sys.all_columns

SELECT NEXT VALUE FOR MyFirstSequence OVER (ORDER BY (SELECT NULL)),OBJECT_ID --did you know you could do that??
FROM sys.all_columns

GO

---Twice in the same row?
SELECT NEXT VALUE FOR MyFirstSequence OVER (ORDER BY Name),NEXT VALUE FOR MyFirstSequence OVER (ORDER BY Name),object_id
FROM sys.all_columns

GO

---Create a table with DEFAULT constraint of NEXT VALUE FOR
CREATE TABLE SequenceTempTable
(ID INT NOT NULL DEFAULT NEXT VALUE FOR MySecondSequence)

INSERT INTO SequenceTempTable
DEFAULT VALUES
INSERT INTO SequenceTempTable
DEFAULT VALUES
INSERT INTO SequenceTempTable
DEFAULT VALUES

SELECT * FROM SequenceTempTable

DROP TABLE SequenceTempTable
GO

--- doesn't rollback with the trnsaction. run from here down to CAST(@Current...
DECLARE @Current sql_variant --try int type here

SELECT @Current=current_value
FROM sys.sequences
where name='MyFirstSequence'

SELECT @Current as [Current]

BEGIN TRAN

SELECT NEXT VALUE FOR MyFirstSequence as value

ROLLBACK TRAN

SELECT @Current as Last,current_value as [Current]
FROM sys.sequences
where name='MyFirstSequence'

--show query plan - WATCH OUT FOR CONVERT_IMPLICIT!!
SELECT *
FROM sys.objects
WHERE object_id = @Current

SELECT *
FROM sys.objects
WHERE object_id = CAST(@Current AS int)


---How using NEXT VALUE FOR doesn't force no gaps(Open 2 sessions)
--can't do this on laptop - too fast??
select NEXT VALUE FOR MyFirstSequence as value
--into #table
from sys.all_columns a
cross join
sys.all_columns b

GO

--- See the gaps
WITH CTE AS
(
SELECT *,ROW_NUMBER() OVER (ORDER BY Value) as [row]
FROM #table
)

SELECT a.Value,b.Value
FROM CTE a
JOIN CTE b
ON a.[row]=b.[row]-1
WHERE a.Value + 1 <b.Value

GO

/* 3. using sp_sequence_get_range */

---Let's see the current value
SELECT current_value FROM sys.sequences
WHERE name = 'MyFirstSequence'


--- for some reason the output is SQL_Variant
DECLARE @start sql_variant
DECLARE @Last sql_variant

EXEC sp_sequence_get_range MyFirstSequence,10,@Start OUT,@Last OUT

SELECT @Start,@Last

---Let's see the current value
SELECT current_value FROM sys.sequences
WHERE name = 'MyFirstSequence'

GO
