/*
BEWARE!!  NEVER forget that SQL Server is a SINGLE SILO OF POWER!  
Anything you do there can ONLY be done there!  
Consider doing formatting type stuff (and other stuff too!) out closer to the user, which can be scaled-out!
*/

SET NOCOUNT ON
USE AdventureWorks2012
GO

/******************** 
**String functions***
********************/


/* FORMAT - Date and time  */

--Standard format strings

SELECT FORMAT(GETDATE(),'d'); ---Short date


--- implicit session language

SELECT FORMAT(GETDATE(),'D'); ---long date


--- explicit session language 
SET LANGUAGE RUSSIAN

SELECT FORMAT(GETDATE(),'D');

SET LANGUAGE ENGLISH

---explicit culture only to the formatting

SELECT FORMAT(GETDATE(),'D','he'); ---WOW! hebrew :)


SELECT FORMAT(GETDATE(),'f'); ---without seconds


SELECT FORMAT(GETDATE(),'F'); --- with seconds


GO

--Custom format strings

SELECT FORMAT(GETDATE(),'dd.MM.yyyy'); 

GO

---Riddle
SELECT FORMAT(GETDATE(),'dd.mm.yyyy HH:MM') as FORMAT;  

SELECT GETDATE() as NOW, FORMAT(GETDATE(),'dd.mm.yyyy HH:MM') as FORMAT;  -- Clue ?








 -- don't confuse between month and minutes - it's all case sensitive!
SELECT FORMAT(GETDATE(),'dd.MM.yyyy HH:mm'); 



SELECT FORMAT(GETDATE(),'The date is, dddd, MMMM dd yyyy');    ---OOPS, WTH?? 







SELECT FORMAT(GETDATE(),'"The date is, "dddd, MMMM dd yyyy'); 

GO

--- NUmeric formatting

---standard format strings

SELECT FORMAT(1000 ,'C')  ---$$$$

SELECT FORMAT(1000 ,'C','he')

SELECT FORMAT(1000 ,'D8');  --decimal

SELECT FORMAT(1000 ,'E');  --exponential

SELECT FORMAT(1000 ,'F2'); ---Fixed point

SELECT FORMAT(0.567 ,'P'); ---percent

SELECT FORMAT(1457 ,'X'); ---For the Hexa lovers


---Custom format strings

SELECT FORMAT(1457 ,'#####.####');  --- # - digit replacer, only if the digit exist

SELECT FORMAT(1457.45 ,'#####.####');

SELECT FORMAT(1457 ,'0000.0000');  --- 0- digit replacer, if no digit exist, writes 0.

SELECT FORMAT(14 ,'0000.0000');  --- 0- digit replacer, if no digit exist, writes 0.

SELECT FORMAT(1457.45 ,'0000.0000');

SELECT FORMAT(524444333 ,'000-0000000');   --- cell phone (?)

SELECT FORMAT(0.45 ,'##%'); -- % - similar to P

GO


/* PARSE */

SELECT PARSE('2011-12-31' AS DATETIME)

SELECT PARSE('2011 Jun 21' AS DATE USING 'En-US')

SELECT PARSE(N'��������� 31 ������ 2011' AS DATE USING 'He')

SELECT PARSE('$345.98' AS money)

GO


/* TRY_PARSE */

SELECT PARSE('2d011-12-31' AS DATETIME)

SELECT TRY_PARSE('2d011-12-31' AS DATETIME)

SELECT TRY_PARSE(N'��������� 31 ������ 2011' AS DATE USING 'En-US')


GO


/* TRY_CONVERT */

CREATE TABLE #temp (Num VARCHAR(2))

INSERT INTO #temp 
VALUES ('10'),('15'),('12'),('9'),('2'),('1a')

SELECT  Try_Convert(integer,Num)
FROM #temp

DROP TABLE #temp
 
SELECT TRY_CONVERT(DATETIME, '20120101') 

SELECT TRY_CONVERT(DATETIME, '20120101a') 

SELECT TRY_CONVERT(XML, 1) 


/* CONCAT */

SELECT CONCAT('a','pple')

SELECT 'a' + 'pple'

SELECT CONCAT('a',NULL,'pple',' 2') ---doesn't return NULL - turns the NULL to empty string

SELECT 'a' + NULL + 'pple' + ' 2'  ---- Returns NULL

GO

SELECT CONCAT('Today is ',GETDATE() , ' and the tempreture is ', 29.5, ' Celsius') --- Dates and numbers implicit conversions

GO

---Using CONCAT to aggregate string values

DECLARE   @String NVARCHAR(MAX); 

SELECT    @String=CONCAT(@String,', ',FirstName) 
FROM      Person.Person; 

SELECT     RIGHT(@String,LEN(@String)-2);


