SET NOCOUNT ON

/******************** 
**Logical functions**
********************/

/* IIF */

DECLARE @A INT = 12

SELECT IIF(@A=1,'true','false')

GO

SELECT IIF(12=1,'true',NULL)   --- ERROR ?

SELECT IIF(12=1,NULL,NULL) --- ERROR !

GO

DECLARE @NULLA INT,@NULLB INT
SELECT IIF(1=1,@NULLA,@NULLB) --- ERROR ?!

GO

DECLARE @A INT = 12

SELECT IIF(@A=1,'true',IIF(@A=12,'Yeah!','Oh NO!'))  ---- nesting is fun.

GO

/* CHOOSE */

SELECT CHOOSE(2,'Insert','Update','Delete')

GO

CREATE TABLE #Voters
(VoterID INT, Voted BIT)

INSERT INTO #Voters(VoterID,Voted)
VALUES (1,0),(2,1),(3,0),(4,1),(5,1)

SELECT VoterID,CHOOSE(CAST(Voted as TINYINT)+1 ,'NO','YES') as Voted
FROM #Voters

DROP TABLE #Voters
GO

Both of these are like syntactic sugar to replace my favorite 4-letter TSQL word!! :-(
