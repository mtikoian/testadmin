SET NOCOUNT ON
GO
USE tempdb
GO
/*

- message_id not required to be existent in sys.messages
- THROW does not accept parameters for substitution (can use FORMATMESSAGE to work around)
- message_id must be INT >= 50000
- severity always 16 unless in CATCH to retrow error
- no WITH NOWAIT option
- honors XACT_ABORT
- acts like RETHROW preserving error number, severity, state, error text, line, etc.

*/

BEGIN TRY
   -- divide by zero error
   SELECT 1/0;

END TRY
BEGIN CATCH
   -- inside CATCH rethrow the original error
   THROW;

END CATCH

/*

Msg 8134, Level 16, State 1, Line 5
Divide by zero error encountered.

*/

CREATE TABLE Foo (
 keycol INT NOT NULL PRIMARY KEY,
 datacol CHAR(1) NULL);

GO

SET XACT_ABORT ON;

BEGIN TRAN

INSERT INTO Foo VALUES(1, 'a');
-- if error is raised the transaction will not roll back
RAISERROR('Some error', 16, 1);
INSERT INTO Foo VALUES(2, 'b');

COMMIT

GO

SELECT keycol, datacol FROM Foo;

GO

SET XACT_ABORT ON;

BEGIN TRAN

INSERT INTO Foo VALUES(3, 'c');
-- if error is raised the transaction is rolled back
THROW 51000, 'Another error', 1;
INSERT INTO Foo VALUES(4, 'd');

COMMIT

GO

SELECT keycol, datacol FROM Foo;

GO

DROP TABLE Foo;


-- e.g., deal with some errors in current level, and let upper level deal with rest
DECLARE @r AS tinyint, @i AS VARCHAR(10) = '0'; -- try with '1', '0', '0.0001', 'A';
SET @i = '0'

SET NOCOUNT ON;
BEGIN TRY

  PRINT 'Entering TRY';

  SET @r = 10./CAST(@i AS NUMERIC(20, 10));
  PRINT '  @r = ' + CAST(@r AS VARCHAR(11));

  PRINT 'Leaving TRY';

END TRY
BEGIN CATCH

  PRINT 'Entering CATCH';

  IF ERROR_NUMBER() = 8134
  BEGIN
    PRINT '  Handling Divide by zero error...';
  END
  ELSE
  IF ERROR_NUMBER() = 8115
  BEGIN
    PRINT '  Handling Arithmetic overflow error converting expression to data type tinyint...';
  END
  ELSE
  BEGIN

    PRINT '  Let upper level deal with error...';
    THROW;

  END;

  PRINT 'Leaving CATCH';

END CATCH;

-- multiple errors
BACKUP DATABASE master TO DISK = 'c:\Nonexistent Folder\master.bak';

-- error functions identify only the last error:
BEGIN TRY
  BACKUP DATABASE master TO DISK = 'c:\Nonexistent Folder\master.bak';
END TRY
BEGIN CATCH
  PRINT '  Error Number: ' + CAST(ERROR_NUMBER() AS VARCHAR(10));
  PRINT '  Error Message: ' + ERROR_MESSAGE();
END CATCH;

-- THROW rethrows all errors
BEGIN TRY
  BACKUP DATABASE master TO DISK = 'c:\Nonexistent Folder\master.bak';
END TRY
BEGIN CATCH
  THROW;
END CATCH;

-- example without a saved message
THROW 54321, 'This is a user error.', 1;

-- example with saved message

-- add message
EXEC sp_addmessage 43112609, 16, '%s is prime. It''s not an error but it sure deserves attention!';

-- format a message and raise an error
DECLARE @msg AS NVARCHAR(2048);
SET @msg = FORMATMESSAGE(43112609, '2^43112609');
THROW 43112609, @msg, 1;

EXEC sp_dropmessage 43112609

