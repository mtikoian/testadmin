SELECT  
	*
FROM transaction_history_old

INTERSECT

SELECT 
	* 
FROM transaction_history_new



SELECT  
	*
FROM transaction_history_new

INTERSECT

SELECT 
	* 
FROM transaction_history_old