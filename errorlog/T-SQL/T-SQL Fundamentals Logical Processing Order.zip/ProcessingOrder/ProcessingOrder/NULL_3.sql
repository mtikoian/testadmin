


SELECT 
	*
FROM Nulls 
ORDER BY 
	col3





SELECT 
	col3, 
	SUM(col1) 
FROM Nulls 
GROUP BY 
	col3