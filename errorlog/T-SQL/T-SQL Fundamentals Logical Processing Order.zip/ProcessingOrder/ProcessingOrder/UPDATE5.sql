IF OBJECT_ID('tempDB..#change_set') IS NOT NULL
	DROP TABLE #change_set


SELECT
	COALESCE(new.transaction_id, old.transaction_id) As transaction_id,
	COALESCE(new.store_id, old.store_id) As store_id,
	COALESCE(new.product_id, old.product_id) As product_id,
	COALESCE(new.transaction_date, old.transaction_date) As transaction_date,
	new.quantity,
	new.actual_cost
INTO #change_set
FROM
(
	SELECT
		x.transaction_id,
		x.store_id,
		x.product_id,
		x.transaction_date,
		x.quantity,
		x.actual_cost
	FROM transaction_history_new AS x
)AS new
FULL OUTER JOIN
(
	SELECT
		y.transaction_id,
		y.store_id,
		y.product_id,
		y.transaction_date,
		y.quantity,
		y.actual_cost
	FROM transaction_history AS y
) AS old ON
	new.transaction_id = old.transaction_id   
	AND new.store_id = old.store_id
	AND new.product_id = old.product_id
	AND new.transaction_date = old.transaction_date


WHERE EXISTS
	(
		SELECT 
			new.quantity,
			new.actual_cost
		EXCEPT
		SELECT
			old.quantity,
			old.actual_cost
	)


BEGIN TRAN
	
	/*
	remove all records from the destination table where they have a match in source. Remember,
	we filtered out exact matches from our change set. The only matching transaction IDs are the ones
	that we need to replace with new values  or the ones we need to delete
	*/ 
	       
	DELETE old
	--SELECT * /*run with select instead of delete to see what will be removed.*/
	FROM transaction_history as old
	INNER JOIN #change_set AS new ON
		old.transaction_id = new.transaction_id;

	/*This section inserts the new values as well as the replacedment values for the changed rows*/ 
	INSERT INTO transaction_history
	(
		transaction_id,
		store_id,
		product_id,
		transaction_date,
		quantity,
		actual_cost
	)
		
	SELECT 
		new.transaction_id,
		new.store_id,
		new.product_id,
		new.transaction_date,
		new.quantity,
		new.actual_cost 
	FROM #change_set AS new
	WHERE
		new.quantity IS NOT NULL;
		
COMMIT TRAN


