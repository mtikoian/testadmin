SELECT  
	*
FROM transaction_history_old

UNION 

SELECT 
	* 
FROM transaction_history_new

ORDER BY transaction_date