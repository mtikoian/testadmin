SELECT  
	*
FROM test_data_2

EXCEPT

SELECT 
	* 
FROM test_data_1




























SELECT  
	*
FROM test_data_2
EXCEPT
SELECT 
	* 
FROM test_data_1