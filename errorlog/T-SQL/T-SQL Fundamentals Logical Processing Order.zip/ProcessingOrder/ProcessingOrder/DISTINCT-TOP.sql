
SELECT DISTINCT 
	*
FROM transaction_history;



SELECT TOP 5 
* 
FROM transaction_history
ORDER BY 
	transaction_date DESC;