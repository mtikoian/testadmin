SELECT
	/*Use COALESCE to merge the columns that do not change into a single column*/
	COALESCE(new.transaction_id, old.transaction_id) As transaction_id,
	COALESCE(new.store_id, old.store_id) As store_id,
	COALESCE(new.product_id, old.product_id) As product_id,
	COALESCE(new.transaction_date, old.transaction_date) As transaction_date,
	new.quantity,
	old.quantity,
	new.actual_cost,
	old.actual_cost
FROM
(
	SELECT
		x.transaction_id,
		x.store_id,
		x.product_id,
		x.transaction_date,
		x.quantity,
		x.actual_cost
	FROM transaction_history_new AS x
)AS new
FULL OUTER JOIN /*gives us the unmatched rows from both sides of the operator, represented by NULL*/
(
	SELECT
		y.transaction_id,
		y.store_id,
		y.product_id,
		y.transaction_date,
		y.quantity,
		y.actual_cost
	FROM transaction_history AS y
) AS old ON /* Join on the key columns, meaning, the rows that stay constant in the sets */        
	new.transaction_id = old.transaction_id   
	AND new.store_id = old.store_id
	AND new.product_id = old.product_id
	AND new.transaction_date = old.transaction_date
