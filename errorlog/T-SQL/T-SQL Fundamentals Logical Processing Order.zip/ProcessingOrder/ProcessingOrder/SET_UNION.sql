SELECT  
	*
FROM transaction_history_old

UNION ALL

SELECT 
	* 
FROM transaction_history_new

ORDER BY transaction_date