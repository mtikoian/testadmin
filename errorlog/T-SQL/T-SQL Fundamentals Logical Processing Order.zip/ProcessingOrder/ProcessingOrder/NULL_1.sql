/*
Before we go further, we need to talk about how NULL values get handled in SQL. 
Most programming language have two states, either true or false. 
But the guy who designed the relational model upon which SQL is built, knew that data isn�t always 
that cut and dried. He knew there could be completely valid reasons for a value to be missing. 
So NULL was included to serve as a placeholder when a value is unknown. 

As a result, we end up with what�s called Three-Valued logic. You can have true, false, or unknown.

Now, this matters because SQL Server handles NULLS differently depending on what it�s doing. 
This inconsistent treatment can give you a real headache if you�re not aware of it, so let�s talk about it quickly.

All query filters: ON, WHERE, or HAVING look at NULL as being = FALSE. 
So if the column on which you�re filtering contains NULLS, then they�ll get kicked out in any sort of comparison. 

The only way to get them included is to use IS NULL

For unique constraints, set operators like UNION and EXCEPT or sorting or grouping operations, 
NULLS are treated as equal to one another.

We�ll look at how set operators are affected in a later demo. 
*/




SELECT * 
FROM Nulls 
ORDER BY 
	col3

