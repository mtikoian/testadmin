SELECT * FROM transaction_history_new
EXCEPT
SELECT * FROM transaction_history_old

