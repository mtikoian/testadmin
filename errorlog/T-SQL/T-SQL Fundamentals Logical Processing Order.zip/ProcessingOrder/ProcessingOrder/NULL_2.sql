SELECT 
	*
FROM Nulls 
WHERE 
	col3 = 2343





SELECT 
	* 
FROM Nulls 
WHERE 
	col3 <> 2343