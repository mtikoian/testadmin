SELECT
	COALESCE(new.transaction_id, old.transaction_id) As transaction_id,
	COALESCE(new.store_id, old.store_id) As store_id,
	COALESCE(new.product_id, old.product_id) As product_id,
	COALESCE(new.transaction_date, old.transaction_date) As transaction_date,
	new.quantity AS new_quant,
	new.actual_cost AS new_cost,
	old.quantity AS old_quant,
	old.actual_cost AS old_cost,
	CASE 
		WHEN new.quantity IS NULL THEN 'delete because they no longer exist in source'
		WHEN old.quantity IS NULL THEN 'add because they are not present in destination'
		WHEN old.quantity <> new.quantity THEN 'requires update in destination'
		WHEN old.quantity = new.quantity THEN 'no change - so exclude from processing'
	END as Status
FROM
(
	SELECT
		x.transaction_id,
		x.store_id,
		x.product_id,
		x.transaction_date,
		x.quantity,
		x.actual_cost
	FROM transaction_history_new AS x
)AS new
FULL OUTER JOIN
(
	SELECT
		y.transaction_id,
		y.store_id,
		y.product_id,
		y.transaction_date,
		y.quantity,
		y.actual_cost
	FROM transaction_history AS y
) AS old ON
	new.transaction_id = old.transaction_id   
	AND new.store_id = old.store_id
	AND new.product_id = old.product_id
	AND new.transaction_date = old.transaction_date

/*
	The JOIN filter helped me identify the rows that match the key columns.
	Now we're going to further filter that set by saying, "Out of the rows that match exactly,
	get rid of any rows where the destination quantity and cost do not match the source quantity and cost.

*/
WHERE EXISTS 
	(
		SELECT 
			new.quantity,
			new.actual_cost
		EXCEPT /*creates a set of all the rows in the new set that are not represented in the old set*/
		SELECT
			old.quantity,
			old.actual_cost
	)


ORDER BY 
	status,
	new.quantity