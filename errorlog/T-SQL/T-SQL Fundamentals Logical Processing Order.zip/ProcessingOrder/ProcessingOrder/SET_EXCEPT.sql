SELECT  
	*
FROM transaction_history_old

EXCEPT

SELECT 
	* 
FROM transaction_history_new



SELECT  
	*
FROM transaction_history_new

EXCEPT

SELECT 
	* 
FROM transaction_history_old
