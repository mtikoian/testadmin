SELECT
	new.transaction_id, 
	old.transaction_id,
	new.store_id, 
	old.store_id,
	new.product_id, 
	old.product_id,
	new.transaction_date, 
	old.transaction_date,
	new.quantity,
	old.quantity,
	new.actual_cost,
	old.actual_cost
FROM
(
	SELECT
		x.transaction_id,
		x.store_id,
		x.product_id,
		x.transaction_date,
		x.quantity,
		x.actual_cost
	FROM transaction_history_new AS x
)AS new
FULL OUTER JOIN
(
	SELECT
		y.transaction_id,
		y.store_id,
		y.product_id,
		y.transaction_date,
		y.quantity,
		y.actual_cost
	FROM transaction_history AS y
) AS old ON
	new.transaction_id = old.transaction_id   
	AND new.store_id = old.store_id
	AND new.product_id = old.product_id
	AND new.transaction_date = old.transaction_date
ORDER BY 
	new.transaction_id