SELECT
	s.store_id,
	COUNT(txh.transaction_id) as tx_count
FROM store AS s
LEFT JOIN transaction_history AS txh ON
	s.store_id = txh.store_id
WHERE 
	s.state = 'CA'
GROUP BY
	s.store_id,
	DATEPART(MONTH,txh.transaction_date)
HAVING 
	COUNT(txh.transaction_id) < 750
ORDER BY
	store_id

