SELECT
	s.store_id,
	COUNT(txh.transaction_id) as tx_count
FROM store AS s
LEFT OUTER JOIN transaction_history AS txh ON
	s.store_id = txh.store_id
WHERE 
	s.state = 'CA'
GROUP BY
	s.store_id
HAVING 
	COUNT(txh.transaction_id) < 4
ORDER BY tx_count