SELECT 
	s.*,
	thx.*
FROM store AS s
INNER JOIN transaction_history AS thx ON
	s.store_id = thx.store_id
ORDER BY
	s.store_id



