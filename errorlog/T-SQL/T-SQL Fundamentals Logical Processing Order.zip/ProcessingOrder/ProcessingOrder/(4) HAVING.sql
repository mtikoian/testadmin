

/*HAVING */
SELECT
	DENSE_RANK() OVER
	(
		ORDER BY
			s.store_id
	) as group_num,
	s.*,
	thx.*
FROM store AS s
LEFT OUTER JOIN transaction_history AS thx ON
	s.store_id = thx.store_id
WHERE 
	s.state = 'CA'
	AND s.store_id <> 40
