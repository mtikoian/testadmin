
/*WHERE */
SELECT 
	s.*,
	thx.*
FROM store AS s
LEFT OUTER JOIN transaction_history AS thx ON
	s.store_id = thx.store_id
WHERE 
	s.state = 'CA'

