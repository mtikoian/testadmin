USE ProcessingOrder;
GO

/*JOIN phase 1 - Cartesian product */

SELECT 
	store.*,
	transaction_history.*
FROM store
CROSS JOIN transaction_history
ORDER BY
	store.store_id,
	transaction_history.store_id

