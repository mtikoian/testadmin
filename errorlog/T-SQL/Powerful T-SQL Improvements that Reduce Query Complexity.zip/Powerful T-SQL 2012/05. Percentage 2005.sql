USE AdventureWorks2012;
go

-- Since SQL Server 2005, the OVER clause comes to the rescue
-- Here's a quick demo to show the syntax and results:
SELECT      SalesPersonID, Name, TerritoryID,
            TotalSaleAmt,
            SUM(TotalSaleAmt) OVER (PARTITION BY SalesPersonID)
FROM        Sales.SalesPersonSalesByTerritory
ORDER BY    SalesPersonID, Name, TerritoryID;





-- And here's the real thing:
SELECT      SalesPersonID, Name, TerritoryID,
            TotalSaleAmt,
            100 * (TotalSaleAmt / SUM(TotalSaleAmt) OVER (PARTITION BY SalesPersonID)) AS PercOfTotal
FROM        Sales.SalesPersonSalesByTerritory
ORDER BY    SalesPersonID, Name, TerritoryID;


-- So what if management wants results as a percentage overall?
-- Simply use an "empty" OVER clause to disable partitioning
-- (Or, rather, treat the entire result set as one single partition)
-- Here's a quick demo to show the syntax and results:
SELECT      SalesPersonID, Name, TerritoryID,
            TotalSaleAmt,
            SUM(TotalSaleAmt) OVER ()
FROM        Sales.SalesPersonSalesByTerritory
ORDER BY    SalesPersonID, Name, TerritoryID;

-- And here's the real thing:
SELECT      SalesPersonID, Name, TerritoryID,
            TotalSaleAmt,
            100 * (TotalSaleAmt / (SUM(TotalSaleAmt) OVER ())) AS PercOfTotal
FROM        Sales.SalesPersonSalesByTerritory
ORDER BY    SalesPersonID, Name, TerritoryID;



-- You can even mix OVER clause and regular GROUP BY aggregates,
-- e.g. to report totals per salesperson as percentage overall:
-- Here's a quick demo to show the syntax and results:
-- This will not work...
SELECT      SalesPersonID, Name,
            SUM(TotalSaleAmt)         AS TotalSales,
            SUM(TotalSaleAmt) OVER () AS GrandTotal
FROM        Sales.SalesPersonSalesByTerritory
GROUP BY    SalesPersonID, Name
ORDER BY    SalesPersonID, Name;

-- This will:
SELECT      SalesPersonID, Name,
            SUM(TotalSaleAmt)              AS TotalSales,
            SUM(SUM(TotalSaleAmt)) OVER () AS GrandTotal
FROM        Sales.SalesPersonSalesByTerritory
GROUP BY    SalesPersonID, Name
ORDER BY    SalesPersonID, Name;

-- You can even use different aggregate functions (may even be more useful)
SELECT      SalesPersonID, Name,
            SUM(TotalSaleAmt)              AS TotalSales,
            AVG(SUM(TotalSaleAmt)) OVER () AS AverageOfTotalSales
FROM        Sales.SalesPersonSalesByTerritory
GROUP BY    SalesPersonID, Name
ORDER BY    SalesPersonID, Name;

-- And here's the final query:
SELECT      SalesPersonID, Name,
            SUM(TotalSaleAmt)              AS TotalSales,
            100 * SUM(TotalSaleAmt) / (AVG(SUM(TotalSaleAmt)) OVER ()) AS RelativeToOthers
FROM        Sales.SalesPersonSalesByTerritory
GROUP BY    SalesPersonID, Name
ORDER BY    SalesPersonID, Name;
