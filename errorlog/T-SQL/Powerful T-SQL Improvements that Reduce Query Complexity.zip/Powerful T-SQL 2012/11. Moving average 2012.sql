USE AdventureWorks2012;
go

-- For a standard moving average, we only have to change
-- the ROWS BETWEEN specification to not look all the way back.
SELECT       SalesPersonID, Name, OrderDate,
             OrderCount,
             AVG(CAST(OrderCount AS decimal(3,0)))
                               OVER (PARTITION BY SalesPersonID
                                     ORDER BY OrderDate
                                     ROWS BETWEEN 4 PRECEDING AND CURRENT ROW) AS AvgOrderCount,
             TotalSaleAmt,
             AVG(TotalSaleAmt) OVER (PARTITION BY SalesPersonID
                                     ORDER BY OrderDate
                                     ROWS BETWEEN 4 PRECEDING AND CURRENT ROW) AS AvgTotalSales
FROM         Sales.SalesPersonSalesByDate
ORDER BY     SalesPersonID, OrderDate;


-- Shorter version (just syntactical suger)
SELECT       SalesPersonID, Name, OrderDate,
             OrderCount,
             AVG(CAST(OrderCount AS decimal(3,0)))
                               OVER (PARTITION BY SalesPersonID
                                     ORDER BY OrderDate
                                     ROWS 4 PRECEDING) AS AvgOrderCount,
             TotalSaleAmt,
             AVG(TotalSaleAmt) OVER (PARTITION BY SalesPersonID
                                     ORDER BY OrderDate
                                     ROWS 4 PRECEDING) AS AvgTotalSales
FROM         Sales.SalesPersonSalesByDate
ORDER BY     SalesPersonID, OrderDate;




-- Only a minor adjustment to use different specs
SELECT       SalesPersonID, Name, OrderDate,
             OrderCount,
             AVG(CAST(OrderCount AS decimal(3,0)))
                               OVER (PARTITION BY SalesPersonID
                                     ORDER BY OrderDate
                                     ROWS BETWEEN 3 PRECEDING AND CURRENT ROW) AS AvgOrderCount,
             TotalSaleAmt,
             AVG(TotalSaleAmt) OVER (PARTITION BY SalesPersonID
                                     ORDER BY OrderDate
                                     ROWS BETWEEN 4 PRECEDING AND CURRENT ROW) AS AvgTotalSales
FROM         Sales.SalesPersonSalesByDate
ORDER BY     SalesPersonID, OrderDate;


-- Shorter version (just syntactical suger)
SELECT       SalesPersonID, Name, OrderDate,
             OrderCount,
             AVG(CAST(OrderCount AS decimal(3,0)))
                               OVER (PARTITION BY SalesPersonID
                                     ORDER BY OrderDate
                                     ROWS 3 PRECEDING) AS AvgOrderCount,
             TotalSaleAmt,
             AVG(TotalSaleAmt) OVER (PARTITION BY SalesPersonID
                                     ORDER BY OrderDate
                                     ROWS 4 PRECEDING) AS AvgTotalSales
FROM         Sales.SalesPersonSalesByDate
ORDER BY     SalesPersonID, OrderDate;






-- Looking backwards and forward a bit - still simple
SELECT       SalesPersonID, Name, OrderDate,
             OrderCount,
             AVG(CAST(OrderCount AS decimal(3,0)))
                               OVER (PARTITION BY SalesPersonID
                                     ORDER BY OrderDate
                                     ROWS BETWEEN 2 PRECEDING AND 2 FOLLOWING) AS AvgOrderCount,
             TotalSaleAmt,
             AVG(TotalSaleAmt) OVER (PARTITION BY SalesPersonID
                                     ORDER BY OrderDate
                                     ROWS BETWEEN 3 PRECEDING AND 3 FOLLOWING) AS AvgTotalSales
FROM         Sales.SalesPersonSalesByDate
ORDER BY     SalesPersonID, OrderDate;
