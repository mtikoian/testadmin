USE AdventureWorks2012;
go

-- Check data used in this example
SELECT * FROM Sales.SalesPersonSalesByDate
ORDER BY SalesPersonID, OrderDate;


-- Add a running total of OrderCount and SaleAmount;
-- order by salesperson / date.

-- Before SQL Server 2005, the best way to do this was a
-- join of each row to all preceding rows - can be very slow!
-- So slow, in fact, that most people would create a temp table
-- and use a cursor or other procedural code to fill it.
-- (That code could be long and complex too - but it's out of scope for this session)
SELECT       s1.SalesPersonID, s1.Name, s1.OrderDate,
             s1.OrderCount,
             SUM(s2.OrderCount) AS RunningTotalCount,
             s1.TotalSaleAmt,
             SUM(s2.TotalSaleAmt) AS RunningTotalSales
FROM         Sales.SalesPersonSalesByDate AS s1
INNER JOIN   Sales.SalesPersonSalesByDate AS s2
      ON     s2.SalesPersonID <= s1.SalesPersonID
      AND NOT
        (    s2.SalesPersonID = s1.SalesPersonID
         AND s2.OrderDate > s1.OrderDate)
GROUP BY     s1.SalesPersonID, s1.Name, s1.OrderDate, s1.OrderCount, s1.TotalSaleAmt
ORDER BY     s1.SalesPersonID, s1.OrderDate;

-- (And if the ordering column(s) are not unique in the set,
--  the query would have been even more complex...)




-- But what if we have running totals with different specification?
-- Example: two running totals of SaleAmount,
-- one that resets for each sales person, and one overall.

-- The "self-join" used before will not work;
-- we would need two self-joins, but then we would get many extra rows
-- as a result of the cartesian product between the first and second self-join.

-- The only way to do this in a single query requires correlated subqueries.
-- Especially on large tables, this can be very slow!
-- (You could replace one of the subqueries with a self-join,
--  but that would neither simplify nor speed up the query).
SELECT       s1.SalesPersonID, s1.Name, s1.OrderDate,
             s1.OrderCount,
             s1.TotalSaleAmt,
            (SELECT SUM(s2.TotalSaleAmt)
             FROM   Sales.SalesPersonSalesByDate AS s2
             WHERE  s2.SalesPersonID = s1.SalesPersonID
             AND    s2.OrderDate <= s1.OrderDate) AS RunningBySalesPerson,
            (SELECT SUM(s3.TotalSaleAmt)
             FROM   Sales.SalesPersonSalesByDate AS s3
             WHERE  s3.SalesPersonID <= s1.SalesPersonID
             AND NOT
               (    s3.SalesPersonID = s1.SalesPersonID
                AND s3.OrderDate > s1.OrderDate)) AS RunningOverall
FROM         Sales.SalesPersonSalesByDate AS s1
ORDER BY     s1.SalesPersonID, s1.OrderDate;

-- (And if the ordering column(s) are not unique in the set,
--  the query would have been even more complex...)

-- Note that if you need running totals with two different specifications,
-- but for three columns each - things start to get REALLY painful (and slow!)
