USE AdventureWorks2012;
go

-- Check data used in this example
SELECT * FROM Sales.SalesPersonSalesByTerritory
ORDER BY SalesPersonID, TerritoryID;

-- Show sales by territory for each salesperson
SELECT      SalesPersonID, Name, TerritoryID,
            TotalSaleAmt
FROM        Sales.SalesPersonSalesByTerritory
ORDER BY    SalesPersonID, Name, TerritoryID;

-- Show total sales for each salesperson
SELECT      SalesPersonID, Name,
            SUM(TotalSaleAmt) AS TotalSales
FROM        Sales.SalesPersonSalesByTerritory
GROUP BY    SalesPersonID, Name
ORDER BY    SalesPersonID, Name;



-- Show sales by territory as percentage of total sales for each salesperson

-- Before SQL Server 2005, this required either a subquery or a join to a derived table
-- (Test on your own server which one performs best for you!)

-- Subquery:
SELECT      s1.SalesPersonID, s1.Name, s1.TerritoryID,
            s1.TotalSaleAmt,
            100 * (s1.TotalSaleAmt / (SELECT SUM(s2.TotalSaleAmt)
                                      FROM   Sales.SalesPersonSalesByTerritory AS s2
                                      WHERE  s2.SalesPersonID = s1.SalesPersonID)) AS PercOfTotal
FROM        Sales.SalesPersonSalesByTerritory AS s1
ORDER BY    s1.SalesPersonID, s1.Name, s1.TerritoryID;

-- Join to derived table:
SELECT      s1.SalesPersonID, s1.Name, s1.TerritoryID,
            s1.TotalSaleAmt,
            100 * (s1.TotalSaleAmt / s2.TotalSales) AS  PercOfTotal
FROM        Sales.SalesPersonSalesByTerritory       AS  s1
INNER JOIN (SELECT      SalesPersonID,
                        SUM(TotalSaleAmt)           AS  TotalSales
            FROM        Sales.SalesPersonSalesByTerritory
            GROUP BY    SalesPersonID)              AS  s2
      ON    s2.SalesPersonID = s1.SalesPersonID
ORDER BY    s1.SalesPersonID, s1.Name, s1.TerritoryID;
go