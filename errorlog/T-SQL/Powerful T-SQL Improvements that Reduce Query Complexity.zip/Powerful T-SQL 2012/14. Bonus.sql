USE AdventureWorks2012;
go

-- Check data used in this example
SELECT * FROM Sales.SalesPersonSalesByDate
ORDER BY SalesPersonID, OrderDate;


-- Now we need a report, sorted by salesperson, orderdate, that includes:
-- * Count of orders per salesperson per day,
--   plus running total by salesperson,
--   plus running total overall
-- * Count of orders per salesperson per day as percentage of total for day
-- * Total amount of sales per salesperson per day,
--   plus moving average by salesperson of current + 3 before + 3 after
-- * Increase or decrease of sales since previous day for same salesperson
-- * Total amount of sales per salesperson for the whole month,
--   plus what percentage of the yearly sales for the same salesperson
--
-- The report should support server-side pagination.

-- Here is how you could write this if you need to support SQL Server 2000
DECLARE @RowsToSkip int,
        @RowsToServe int;
SET @RowsToSkip = 200;
SET @RowsToServe = 20;

SELECT      s1.SalesPersonID, s1.Name, s1.OrderDate,
            s1.OrderCount,
           (SELECT   SUM(s2.OrderCount)
            FROM     Sales.SalesPersonSalesByDate AS s2
            WHERE    s2.SalesPersonID = s1.SalesPersonID
            AND      s2.OrderDate <= s1.OrderDate) AS RunningSalesPerson,
           (SELECT   SUM(s3.OrderCount)
            FROM     Sales.SalesPersonSalesByDate AS s3
            WHERE    s3.SalesPersonID <= s1.SalesPersonID
            AND NOT (s3.SalesPersonID = s1.SalesPersonID AND s3.OrderDate > s1.OrderDate)) AS RunningOverall,
           (100.0 * s1.OrderCount) / (SELECT SUM(s4.OrderCount)
                                      FROM   Sales.SalesPersonSalesByDate AS s4
                                      WHERE  s4.OrderDate = s1.OrderDate) AS PercentageOfSales,
            s1.TotalSaleAmt,
           (SELECT AVG(d3.TotalSaleAmt)
            FROM  (SELECT d1.TotalSaleAmt
                   FROM  (SELECT TOP(3)
                                   s5.TotalSaleAmt
                          FROM     Sales.SalesPersonSalesByDate AS s5
                          WHERE    s5.SalesPersonID = s1.SalesPersonID
                          AND      s5.OrderDate <= s1.OrderDate
                          ORDER BY s5.OrderDate DESC) AS d1
                   UNION ALL
                   SELECT d2.TotalSaleAmt
                   FROM  (SELECT TOP(2)
                                   s6.TotalSaleAmt
                          FROM     Sales.SalesPersonSalesByDate AS s6
                          WHERE    s6.SalesPersonID = s1.SalesPersonID
                          AND      s6.OrderDate > s1.OrderDate
                          ORDER BY s6.OrderDate ASC) AS d2) AS d3) AS MovAvgSales,
            s1.TotalSaleAmt - (SELECT TOP(1) s7.TotalSaleAmt
                               FROM          Sales.SalesPersonSalesByDate AS s7
                               WHERE         s7.SalesPersonID = s1.SalesPersonID
                               AND           s7.OrderDate < s1.OrderDate
                               ORDER BY      s7.OrderDate DESC) AS SalesDiff,
            d4.SalesThisMonth,
            d4.SalesThisMonth / d5.SalesThisYear * 100 AS PercMonthSalesOfYear
FROM        Sales.SalesPersonSalesByDate AS s1
INNER JOIN (SELECT   s8.SalesPersonID, YEAR(s8.OrderDate) AS OrderYear, MONTH(s8.OrderDate) AS OrderMonth,
                     SUM(s8.TotalSaleAmt) AS SalesThisMonth
            FROM     Sales.SalesPersonSalesByDate AS s8
            GROUP BY s8.SalesPersonID, YEAR(s8.OrderDate), MONTH(s8.OrderDate)) AS d4
      ON    d4.SalesPersonID = s1.SalesPersonID
      AND   d4.OrderYear = YEAR(s1.OrderDate)
      AND   d4.OrderMonth = MONTH(s1.OrderDate)
INNER JOIN (SELECT   s9.SalesPersonID, YEAR(s9.OrderDate) AS OrderYear,
                     SUM(s9.TotalSaleAmt) AS SalesThisYear
            FROM     Sales.SalesPersonSalesByDate AS s9
            GROUP BY s9.SalesPersonID, YEAR(s9.OrderDate)) AS d5
      ON    d5.SalesPersonID = s1.SalesPersonID
      AND   d5.OrderYear = YEAR(s1.OrderDate)
WHERE      (SELECT     COUNT(*)
            FROM       Sales.SalesPersonSalesByDate AS s10
            WHERE      s10.SalesPersonID <= s1.SalesPersonID
            AND NOT(   s10.SalesPersonID = s1.SalesPersonID
                   AND s10.OrderDate > s1.OrderDate)) BETWEEN @RowsToSkip + 1 AND @RowsToSkip + @RowsToServe
ORDER BY    s1.SalesPersonID, s1.OrderDate;
go


-- Here is the SQL Server 2012 version:
DECLARE @RowsToSkip int,
        @RowsToServe int;
SET @RowsToSkip = 200;
SET @RowsToServe = 20;

SELECT     SalesPersonID, Name, OrderDate,
           OrderCount,
           SUM(OrderCount) OVER (PARTITION BY SalesPersonID ORDER BY OrderDate)                   AS RunningSalesPerson,
           SUM(OrderCount) OVER (ORDER BY SalesPersonID, OrderDate)                               AS RunningOverall,
           100.0 * OrderCount / SUM(OrderCount) OVER (PARTITION BY OrderDate)                     AS PercentageOfSales,
           TotalSaleAmt,
           AVG(TotalSaleAmt) OVER (PARTITION BY SalesPersonID ORDER BY OrderDate
                                   ROWS BETWEEN 2 PRECEDING AND 2 FOLLOWING)                      AS MovAvgSales,
           TotalSaleAmt - LAG(TotalSaleAmt) OVER (PARTITION BY SalesPersonID ORDER BY OrderDate)  AS SalesDiff,
           SUM(TotalSaleAmt) OVER (PARTITION BY SalesPersonID, YEAR(OrderDate), MONTH(OrderDate)) AS SalesThisMonth,
          (SUM(TotalSaleAmt) OVER (PARTITION BY SalesPersonID, YEAR(OrderDate), MONTH(OrderDate))
         / SUM(TotalSaleAmt) OVER (PARTITION BY SalesPersonID, YEAR(OrderDate))) * 100            AS PercMonthSalesOfYear
FROM       Sales.SalesPersonSalesByDate
ORDER BY   SalesPersonID, OrderDate
    OFFSET @RowsToSkip ROWS
FETCH NEXT @RowsToServe ROWS ONLY;
go
