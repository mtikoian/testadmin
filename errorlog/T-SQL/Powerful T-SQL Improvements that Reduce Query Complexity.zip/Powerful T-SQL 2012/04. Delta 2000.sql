USE AdventureWorks2012;
go

-- Check data used in this example
SELECT * FROM Sales.SalesPersonSalesByDate
ORDER BY SalesPersonID, OrderDate;


-- Report now needs to include the difference in OrderCount and TotalSaleAmt
-- since the "previous" OrderDate for the same salesperson.

-- In SQL Server 2000, solving this with a join is hard,
-- because we then would need to add nested subqueries
-- to make sure we join to "the", not "a" previous row.
-- Better to use a subquery with TOP.
-- (Unfortunately, this subquery needs to be repeated)
SELECT       s1.SalesPersonID, s1.Name, s1.OrderDate,
             s1.OrderCount,
             s1.OrderCount - (SELECT TOP(1) s2.OrderCount
                              FROM          Sales.SalesPersonSalesByDate AS s2
                              WHERE         s2.SalesPersonID = s1.SalesPersonID
                              AND           s2.OrderDate < s1.OrderDate
                              ORDER BY      s2.OrderDate DESC) AS DeltaCount,
             s1.TotalSaleAmt,
             s1.TotalSaleAmt - (SELECT TOP(1) s3.TotalSaleAmt
                                FROM          Sales.SalesPersonSalesByDate AS s3
                                WHERE         s3.SalesPersonID = s1.SalesPersonID
                                AND           s3.OrderDate < s1.OrderDate
                                ORDER BY      s3.OrderDate DESC) AS DeltaSale
FROM         Sales.SalesPersonSalesByDate AS s1
ORDER BY     s1.SalesPersonID, s1.OrderDate;




-- So you need ANSI compliance too?
--
--
--
-- ... good luck with that! ;-)
