-- All demos in this session are based on the AdventureWorks2012 demo database
-- The demos could probably work on the previous version (AdventureWorks2008) too,
-- though some may need modification to cater for schema changes between the two
-- versions of the sample database.
--
-- Demos that showcase new SQL Server 2012 features only work on that version,
-- though they probably still would work on the older version of AdventureWorks.
--
-- All AdventureWorks sample databases can be downloaded from http://msftdbprodsamples.codeplex.com/.



-- Switch to tempdb before switching to AdventureWorks2012.
-- If someone accidentally runs this script on an instance where AdventureWorks2012
-- is not avilable, or has been renamed, the USE statement would fail, but the next
-- batch would still run, possibly causing objects to be created in other databases.
-- Switching to tempdb first ensures those objects will be created there,
-- where they won't cause harm (and will automatically be removed when the service restarts)
USE tempdb;
go
USE AdventureWorks2012
go
IF EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'Sales.SalesPersonSalesByDate'))
BEGIN;
   DROP VIEW Sales.SalesPersonSalesByDate;
END;
go
CREATE VIEW Sales.SalesPersonSalesByDate
AS
SELECT      soh.SalesPersonID,
            MAX(p.FirstName + ' '
          + COALESCE(p.MiddleName + ' ', '')
          + p.LastName)                      AS  Name,         -- MAX() required for syntactical reasons only
            soh.OrderDate,
            COUNT(*)                         AS  OrderCount,
            SUM(soh.SubTotal)                AS  TotalSaleAmt
FROM        Sales.SalesOrderHeader           AS  soh
INNER JOIN  Person.Person                    AS  p
      ON    p.BusinessEntityID                =  soh.SalesPersonID
WHERE       soh.SalesPersonID                IS  NOT NULL
GROUP BY    soh.SalesPersonID,
            soh.OrderDate;
go

IF EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'Sales.SalesPersonSalesByTerritory'))
BEGIN;
   DROP VIEW Sales.SalesPersonSalesByTerritory;
END;
go
CREATE VIEW Sales.SalesPersonSalesByTerritory
AS
SELECT      soh.SalesPersonID,
            MAX(p.FirstName + ' '
          + COALESCE(p.MiddleName + ' ', '')
          + p.LastName)                      AS  Name,         -- MAX() required for syntactical reasons only
            soh.TerritoryID,
            COUNT(*)                         AS  OrderCount,
            SUM(soh.SubTotal)                AS  TotalSaleAmt
FROM        Sales.SalesOrderHeader           AS  soh
INNER JOIN  Person.Person                    AS  p
      ON    p.BusinessEntityID                =  soh.SalesPersonID
WHERE       soh.SalesPersonID                IS  NOT NULL
GROUP BY    soh.SalesPersonID,
            soh.TerritoryID;
go
