USE AdventureWorks2012;
go

-- For SQL Server 2012, we could go fancy with
-- OVER and a window to just the previous row.
SELECT       SalesPersonID, Name, OrderDate,
             OrderCount,
             OrderCount - SUM(OrderCount) OVER(PARTITION BY SalesPersonID
                                               ORDER BY OrderDate
                                               ROWS BETWEEN 1 PRECEDING AND 1 PRECEDING) AS DeltaCount,
             TotalSaleAmt,
             TotalSaleAmt - SUM(TotalSaleAmt) OVER(PARTITION BY SalesPersonID
                                                   ORDER BY OrderDate
                                                   ROWS BETWEEN 1 PRECEDING AND 1 PRECEDING) AS DeltaSale
FROM         Sales.SalesPersonSalesByDate
ORDER BY     SalesPersonID, OrderDate;



-- But it's even easier with the new LAG function
SELECT       SalesPersonID, Name, OrderDate,
             OrderCount,
             OrderCount - LAG(OrderCount) OVER(PARTITION BY SalesPersonID
                                               ORDER BY OrderDate) AS DeltaCount,
             TotalSaleAmt,
             TotalSaleAmt - LAG(TotalSaleAmt) OVER(PARTITION BY SalesPersonID
                                                   ORDER BY OrderDate) AS DeltaSale
FROM         Sales.SalesPersonSalesByDate
ORDER BY     SalesPersonID, OrderDate;
