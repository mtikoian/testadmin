USE AdventureWorks2012;
go

-- In SQL Server 2005, the OVER clause did not help for running totals.
-- But the APPLY clause did help (a bit) - at the cost of performance and ANSI compliance.
SELECT       s1.SalesPersonID, s1.Name, s1.OrderDate,
             s1.OrderCount,
             d1.RunningTotalCount,
             s1.TotalSaleAmt,
             d1.RunningTotalSales
FROM         Sales.SalesPersonSalesByDate AS s1
CROSS APPLY (SELECT SUM(s2.OrderCount) AS RunningTotalCount,
                    SUM(s2.TotalSaleAmt) AS RunningTotalSales
             FROM   Sales.SalesPersonSalesByDate AS s2
             WHERE  s2.SalesPersonID <= s1.SalesPersonID
             AND NOT
               (    s2.SalesPersonID = s1.SalesPersonID
                AND s2.OrderDate > s1.OrderDate)) AS d1
ORDER BY     s1.SalesPersonID, s1.OrderDate;






-- The APPLY version can also be used for running totals with different specs,
-- because the aggregation is done in the subquery, before the join.
-- This eliminates the cartesian product proble we had earlier.
-- (In this case, the performance is roughly the same as the previous version,
--  and you really start winning when you need running totals for multiple columns).
SELECT       s1.SalesPersonID, s1.Name, s1.OrderDate,
             s1.OrderCount,
             s1.TotalSaleAmt,
             d1.RunningBySalesPerson,
             d2.RunningOverall
FROM         Sales.SalesPersonSalesByDate AS s1
CROSS APPLY (SELECT SUM(s2.TotalSaleAmt) AS RunningBySalesPerson
             FROM   Sales.SalesPersonSalesByDate AS s2
             WHERE  s2.SalesPersonID = s1.SalesPersonID
             AND    s2.OrderDate <= s1.OrderDate) AS d1
CROSS APPLY (SELECT SUM(s3.TotalSaleAmt) AS RunningOverall
             FROM   Sales.SalesPersonSalesByDate AS s3
             WHERE  s3.SalesPersonID <= s1.SalesPersonID
             AND NOT
               (    s3.SalesPersonID = s1.SalesPersonID
                AND s3.OrderDate > s1.OrderDate)) AS d2
ORDER BY     s1.SalesPersonID, s1.OrderDate;
