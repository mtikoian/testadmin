USE AdventureWorks2012;
go

-- Even in SQL2000, moving average was (relatively) easy when you had
-- a column that provided you with a guaranteed gapless numbering.
-- In SQL Server 2005, you could simply use the new ROW_NUMBER function
-- (with the unavoidable OVER clause!) to provide such a gapless numbering,
-- combined with a CTE (common table expression - also new in SQL Server 2005).
WITH NumberedRows
AS (SELECT   SalesPersonID, Name, OrderDate, OrderCount, TotalSaleAmt,
             ROW_NUMBER() OVER (PARTITION BY SalesPersonID
                                ORDER BY OrderDate) AS rn
    FROM     Sales.SalesPersonSalesByDate)
SELECT       s1.SalesPersonID, s1.Name, s1.OrderDate,
             s1.OrderCount,
             AVG(CAST(s2.OrderCount AS decimal(3,0))) AS AvgOrderCount,
             s1.TotalSaleAmt,
             AVG(s2.TotalSaleAmt) AS AvgTotalSales
FROM         NumberedRows AS s1
INNER JOIN   NumberedRows AS s2
      ON     s2.SalesPersonID = s1.SalesPersonID
      AND    s2.rn BETWEEN s1.rn - 4 AND s1.rn
GROUP BY     s1.SalesPersonID, s1.Name, s1.OrderDate, s1.OrderCount, s1.TotalSaleAmt
ORDER BY     s1.SalesPersonID, s1.OrderDate;

-- However, for better performance you would forego the ROW_NUMBER,
-- and instead use a combination of TOP and APPLY - both not ANSI standard, though
SELECT       s1.SalesPersonID, s1.Name, s1.OrderDate,
             s1.OrderCount,
             AVG(CAST(d1.OrderCount AS decimal(3,0))) AS AvgOrderCount,
             s1.TotalSaleAmt,
             AVG(d1.TotalSaleAmt) AS AvgTotalSales
FROM         Sales.SalesPersonSalesByDate AS s1
CROSS APPLY (SELECT TOP(5)               -- Current row + 4 previous = 5
                      s2.OrderCount, s2.TotalSaleAmt
             FROM     Sales.SalesPersonSalesByDate AS s2
             WHERE    s2.SalesPersonID = s1.SalesPersonID
             AND      s2.OrderDate <= s1.OrderDate
             ORDER BY s2.OrderDate DESC) AS d1
GROUP BY     s1.SalesPersonID, s1.Name, s1.OrderDate, s1.OrderCount, s1.TotalSaleAmt
ORDER BY     s1.SalesPersonID, s1.OrderDate;





-- Multiple moving averages with different specs was still painful in SQL2005.
-- You could use ROW_NUMBER, combined with either subqueries or APPLY (but not JOIN!)
-- (Unfortunately, both versions have terrible performance)
WITH NumberedRows
AS (SELECT   SalesPersonID, Name, OrderDate, OrderCount, TotalSaleAmt,
             ROW_NUMBER() OVER (PARTITION BY SalesPersonID
                                ORDER BY OrderDate) AS rn
    FROM     Sales.SalesPersonSalesByDate)
SELECT       s1.SalesPersonID, s1.Name, s1.OrderDate,
             s1.OrderCount,
            (SELECT AVG(CAST(s2.OrderCount AS decimal(3,0)))
             FROM   NumberedRows AS s2
             WHERE  s2.SalesPersonID = s1.SalesPersonID
             AND    s2.rn BETWEEN s1.rn - 3 AND s1.rn) AS AvgOrderCount,
             s1.TotalSaleAmt,
            (SELECT AVG(s3.TotalSaleAmt)
             FROM   NumberedRows AS s3
             WHERE  s3.SalesPersonID = s1.SalesPersonID
             AND    s3.rn BETWEEN s1.rn - 4 AND s1.rn) AS AvgTotalSales
FROM         NumberedRows AS s1
ORDER BY     s1.SalesPersonID, s1.OrderDate;

WITH NumberedRows
AS (SELECT   SalesPersonID, Name, OrderDate, OrderCount, TotalSaleAmt,
             ROW_NUMBER() OVER (PARTITION BY SalesPersonID
                                ORDER BY OrderDate) AS rn
    FROM     Sales.SalesPersonSalesByDate)
SELECT       s1.SalesPersonID, s1.Name, s1.OrderDate,
             s1.OrderCount,
             d1.AvgOrderCount,
             s1.TotalSaleAmt,
             d2.AvgTotalSales
FROM         NumberedRows AS s1
CROSS APPLY (SELECT AVG(CAST(s2.OrderCount AS decimal(3,0))) AS AvgOrderCount
             FROM   NumberedRows AS s2
             WHERE  s2.SalesPersonID = s1.SalesPersonID
             AND    s2.rn BETWEEN s1.rn - 3 AND s1.rn) AS d1
CROSS APPLY (SELECT AVG(s2.TotalSaleAmt) AS AvgTotalSales
             FROM   NumberedRows AS s2
             WHERE  s2.SalesPersonID = s1.SalesPersonID
             AND    s2.rn BETWEEN s1.rn - 4 AND s1.rn) AS d2
ORDER BY     s1.SalesPersonID, s1.OrderDate;

-- The fastest alternative for SQL 2005 doesn't use ROW_NUMBER at all,
-- but does use a combination of TOP and APPLY.
-- This time, we have to APPLY multiple subqueries,
-- and aggregate within them - which requires an extra nesting level.
-- (query inspired by Peter Larsson)
SELECT       s1.SalesPersonID, s1.Name, s1.OrderDate,
             s1.OrderCount,
             d2.AvgOrderCount,
             s1.TotalSaleAmt,
             d4.AvgTotalSales
FROM         Sales.SalesPersonSalesByDate AS s1
CROSS APPLY (SELECT   AVG(CAST(d1.OrderCount AS decimal(3,0))) AS AvgOrderCount
             FROM    (SELECT TOP(4)
                               s2.OrderCount
                      FROM     Sales.SalesPersonSalesByDate AS s2
                      WHERE    s2.SalesPersonID = s1.SalesPersonID
                      AND      s2.OrderDate <= s1.OrderDate
                      ORDER BY s2.OrderDate DESC) AS d1) AS d2
CROSS APPLY (SELECT   AVG(d3.TotalSaleAmt) AS AvgTotalSales
             FROM    (SELECT TOP(5)
                               s3.TotalSaleAmt
                      FROM     Sales.SalesPersonSalesByDate AS s3
                      WHERE    s3.SalesPersonID = s1.SalesPersonID
                      AND      s3.OrderDate <= s1.OrderDate
                      ORDER BY s3.OrderDate DESC) AS d3) AS d4
ORDER BY     s1.SalesPersonID, s1.OrderDate;




-- The "slow" version for SQL Server 2005 can be very easily
-- adapted to have a moving average that looks forwards and backwards
WITH NumberedRows
AS (SELECT   SalesPersonID, Name, OrderDate, OrderCount, TotalSaleAmt,
             ROW_NUMBER() OVER (PARTITION BY SalesPersonID
                                ORDER BY OrderDate) AS rn
    FROM     Sales.SalesPersonSalesByDate)
SELECT       s1.SalesPersonID, s1.Name, s1.OrderDate,
             s1.OrderCount,
             d1.AvgOrderCount,
             s1.TotalSaleAmt,
             d2.AvgTotalSales
FROM         NumberedRows AS s1
CROSS APPLY (SELECT AVG(CAST(s2.OrderCount AS decimal(3,0))) AS AvgOrderCount
             FROM   NumberedRows AS s2
             WHERE  s2.SalesPersonID = s1.SalesPersonID
             AND    s2.rn BETWEEN s1.rn - 2 AND s1.rn + 2) AS d1
CROSS APPLY (SELECT AVG(s3.TotalSaleAmt) AS AvgTotalSales
             FROM   NumberedRows AS s3
             WHERE  s3.SalesPersonID = s1.SalesPersonID
             AND    s3.rn BETWEEN s1.rn - 3 AND s1.rn + 3) AS d2
ORDER BY     s1.SalesPersonID, s1.OrderDate;



-- The "fast" version for SQL Server 2005, however, needs more change
-- and pity the one who gets to inherit this code one day...
-- (query inspired by Peter Larsson)
SELECT       s1.SalesPersonID, s1.Name, s1.OrderDate,
             s1.OrderCount,
             d4.AvgOrderCount,
             s1.TotalSaleAmt,
             d8.AvgTotalSales
FROM         Sales.SalesPersonSalesByDate AS s1
CROSS APPLY (SELECT AVG(CAST(d3.OrderCount AS decimal(3,0))) AS AvgOrderCount
             FROM  (SELECT   d1.OrderCount
                    FROM    (SELECT TOP(3)    -- Current and previous 2
                                      s2.OrderCount
                             FROM     Sales.SalesPersonSalesByDate AS s2
                             WHERE    s2.SalesPersonID = s1.SalesPersonID
                             AND      s2.OrderDate <= s1.OrderDate  -- Includes current
                             ORDER BY s2.OrderDate DESC) AS d1
                    UNION ALL
                    SELECT   d2.OrderCount
                    FROM    (SELECT TOP(2)    -- Next 2
                                      s3.OrderCount
                             FROM     Sales.SalesPersonSalesByDate AS s3
                             WHERE    s3.SalesPersonID = s1.SalesPersonID
                             AND      s3.OrderDate > s1.OrderDate  -- Excludes current
                             ORDER BY s3.OrderDate ASC) AS d2) AS d3) AS d4
CROSS APPLY (SELECT AVG(d7.TotalSaleAmt) AS AvgTotalSales
             FROM  (SELECT   d5.TotalSaleAmt
                    FROM    (SELECT TOP(4)    -- Current and previous 3
                                      s4.TotalSaleAmt
                             FROM     Sales.SalesPersonSalesByDate AS s4
                             WHERE    s4.SalesPersonID = s1.SalesPersonID
                             AND      s4.OrderDate <= s1.OrderDate  -- Includes current
                             ORDER BY s4.OrderDate DESC) AS d5
                    UNION ALL
                    SELECT   d6.TotalSaleAmt
                    FROM    (SELECT TOP(3)    -- Next 3
                                      s5.TotalSaleAmt
                             FROM     Sales.SalesPersonSalesByDate AS s5
                             WHERE    s5.SalesPersonID = s1.SalesPersonID
                             AND      s5.OrderDate > s1.OrderDate  -- Excludes current
                             ORDER BY s5.OrderDate ASC) AS d6) AS d7) AS d8
ORDER BY     s1.SalesPersonID, s1.OrderDate;
