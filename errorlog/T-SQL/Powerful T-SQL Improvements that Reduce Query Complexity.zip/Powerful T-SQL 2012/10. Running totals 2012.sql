USE AdventureWorks2012;
go

-- But SQL Server 2012 really simplifies things!
-- (and all ANSI standard!)
SELECT       SalesPersonID, Name, OrderDate,
             OrderCount,
             SUM(OrderCount)   OVER (ORDER BY SalesPersonID, OrderDate
                                     ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS RunningTotalCount,
             TotalSaleAmt,
             SUM(TotalSaleAmt) OVER (ORDER BY SalesPersonID, OrderDate
                                     ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS RunningTotalSales
FROM         Sales.SalesPersonSalesByDate
ORDER BY     SalesPersonID, OrderDate;


-- This can be shortened to just ROWS UNBOUNDED PRECEDING
-- (because CURRENT ROW is default end specification)
-- Do *NOT* shorten it to ue only the ORDER BY clause;
-- that would imply RANGE UNBOUNDED PRECEDING - same results
-- in this case, but RANGE is far slower than ROWS!!
SELECT       SalesPersonID, Name, OrderDate,
             OrderCount,
             SUM(OrderCount)   OVER (ORDER BY SalesPersonID, OrderDate
                                     ROWS UNBOUNDED PRECEDING) AS RunningTotalCount,
             TotalSaleAmt,
             SUM(TotalSaleAmt) OVER (ORDER BY SalesPersonID, OrderDate
                                     ROWS UNBOUNDED PRECEDING) AS RunningTotalSales
FROM         Sales.SalesPersonSalesByDate
ORDER BY     SalesPersonID, OrderDate;




-- Having different specs is as easy as changing the PARTITION BY
-- and ORDER BY specifications of each individual OVER specification.
-- SQL Server will all sort it out for you, and always quite efficient.
SELECT       SalesPersonID, Name, OrderDate,
             OrderCount,
             TotalSaleAmt,
             SUM(TotalSaleAmt) OVER (PARTITION BY SalesPersonID
                                     ORDER BY OrderDate
                                     ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS RunningBySalesPerson,
             SUM(TotalSaleAmt) OVER (ORDER BY SalesPersonID, OrderDate
                                     ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS RunningOverall
FROM         Sales.SalesPersonSalesByDate
ORDER BY     SalesPersonID, OrderDate;


-- (Or the shortened version)
SELECT       SalesPersonID, Name, OrderDate,
             OrderCount,
             TotalSaleAmt,
             SUM(TotalSaleAmt) OVER (PARTITION BY SalesPersonID
                                     ORDER BY OrderDate
                                     ROWS UNBOUNDED PRECEDING) AS RunningBySalesPerson,
             SUM(TotalSaleAmt) OVER (ORDER BY SalesPersonID, OrderDate
                                     ROWS UNBOUNDED PRECEDING) AS RunningOverall
FROM         Sales.SalesPersonSalesByDate
ORDER BY     SalesPersonID, OrderDate;



-- Note that using incompatible specifications will force SQL Server
-- to add extra sorting steps in the plan.
-- Don't be afraid to do so when required - but don't go overboard.
SELECT       SalesPersonID, Name, OrderDate,
             OrderCount,
             TotalSaleAmt,
             SUM(TotalSaleAmt) OVER (PARTITION BY SalesPersonID
                                     ORDER BY OrderDate
                                     ROWS UNBOUNDED PRECEDING) AS RunningBySalesPerson,
             AVG(TotalSaleAmt) OVER (PARTITION BY Name
                                     ORDER BY OrderDate
                                     ROWS UNBOUNDED PRECEDING) AS AvgBySalesPerson
FROM         Sales.SalesPersonSalesByDate
ORDER BY     SalesPersonID, OrderDate;

SELECT       SalesPersonID, Name, OrderDate,
             OrderCount,
             TotalSaleAmt,
             SUM(TotalSaleAmt) OVER (PARTITION BY SalesPersonID
                                     ORDER BY OrderDate
                                     ROWS UNBOUNDED PRECEDING) AS RunningBySalesPerson,
             AVG(TotalSaleAmt) OVER (PARTITION BY SalesPersonID
                                     ORDER BY OrderDate
                                     ROWS UNBOUNDED PRECEDING) AS AvgBySalesPerson
FROM         Sales.SalesPersonSalesByDate
ORDER BY     SalesPersonID, OrderDate;
