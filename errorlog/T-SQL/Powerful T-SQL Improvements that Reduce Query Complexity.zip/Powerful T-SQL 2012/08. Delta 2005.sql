USE AdventureWorks2012;
go

-- In SQL Server 2005, you can use ROW_NUMBER() to easily
-- join to the "previous" row and calculate the difference.
WITH NumberedRows
AS (SELECT   SalesPersonID, Name, OrderDate, OrderCount, TotalSaleAmt,
             ROW_NUMBER() OVER (PARTITION BY SalesPersonID
                                ORDER BY OrderDate) AS rn
    FROM     Sales.SalesPersonSalesByDate)
SELECT       s1.SalesPersonID, s1.Name, s1.OrderDate,
             s1.OrderCount,
             s1.OrderCount - s2.OrderCount AS DeltaCount,
             s1.TotalSaleAmt,
             s1.TotalSaleAmt - s2.TotalSaleAmt AS DeltaSale
FROM         NumberedRows AS s1
LEFT  JOIN   NumberedRows AS s2
      ON     s2.SalesPersonID = s1.SalesPersonID
      AND    s2.rn = s1.rn - 1
ORDER BY     s1.SalesPersonID, s1.OrderDate;




-- There's also a non-ANSI compliant alternative with APPLY and TOP;
-- it's a bit shorter but not really less complex - and slower. So why bother?
SELECT       s1.SalesPersonID, s1.Name, s1.OrderDate,
             s1.OrderCount,
             s1.OrderCount - d1.OrderCount AS DeltaCount,
             s1.TotalSaleAmt,
             s1.TotalSaleAmt - d1.TotalSaleAmt AS DeltaSale
FROM         Sales.SalesPersonSalesByDate AS s1
OUTER APPLY (SELECT TOP(1) s2.OrderCount, s2.TotalSaleAmt
             FROM          Sales.SalesPersonSalesByDate AS s2
             WHERE         s2.SalesPersonID = s1.SalesPersonID
             AND           s2.OrderDate < s1.OrderDate
             ORDER BY      s2.OrderDate DESC) AS d1
ORDER BY     s1.SalesPersonID, s1.OrderDate;
