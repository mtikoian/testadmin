USE AdventureWorks2012;
go

-- Check data used in this example
SELECT * FROM Sales.SalesPersonSalesByDate
ORDER BY SalesPersonID, OrderDate;


-- Add the average of current and four previous SaleAmount and OrderCount values;
-- order by date and restart for each salesperson.
-- If we KNOW that every date is in the table, we can use DATEDIFF ... but alas!

-- Before SQL Server 2005, we could use the same
-- self-join technique as for running totals,
-- but with a subquery to limit the number of rows:
SELECT       s1.SalesPersonID, s1.Name, s1.OrderDate,
             s1.OrderCount,
             AVG(CAST(s2.OrderCount AS decimal(3,0))) AS AvgOrderCount,
             s1.TotalSaleAmt,
             AVG(s2.TotalSaleAmt) AS AvgTotalSales
FROM         Sales.SalesPersonSalesByDate AS s1
INNER JOIN   Sales.SalesPersonSalesByDate AS s2
      ON     s2.SalesPersonID = s1.SalesPersonID
      AND    s2.OrderDate <= s1.OrderDate
      AND   (SELECT COUNT(*)
             FROM   Sales.SalesPersonSalesByDate AS s3
             WHERE  s3.SalesPersonID = s2.SalesPersonID
             AND    s3.OrderDate BETWEEN s2.OrderDate AND s1.OrderDate) <= 5         -- Current row + 4 previous = 5
GROUP BY     s1.SalesPersonID, s1.Name, s1.OrderDate, s1.OrderCount, s1.TotalSaleAmt
ORDER BY     s1.SalesPersonID, s1.OrderDate;

-- (And, again, this would get nasty with non-unique criteria)






-- Just as with running totals, the pre-SQL 2005 self-join
-- can not be used for multiple moving aggregates with different specification.
-- Or for a combination of moving aggregates and running totals.

-- So let's say we need to look back four rows for SaleAmount, but three for OrderCount.
-- We now need correlated subqueries for each aggregate,
-- with a NESTED(!!) correlated subquery to find the last row to include.
SELECT       s1.SalesPersonID, s1.Name, s1.OrderDate,
             s1.OrderCount,
            (SELECT AVG(CAST(s2.OrderCount AS decimal(3,0)))
             FROM   Sales.SalesPersonSalesByDate AS s2
             WHERE  s2.SalesPersonID = s1.SalesPersonID
             AND    s2.OrderDate <= s1.OrderDate
             AND   (SELECT COUNT(*)
                    FROM   Sales.SalesPersonSalesByDate AS s3
                    WHERE  s3.SalesPersonID = s2.SalesPersonID
                    AND    s3.OrderDate BETWEEN s2.OrderDate
                                            AND s1.OrderDate) <= 4)
                                                            AS AvgOrderCount,
             s1.TotalSaleAmt,
            (SELECT AVG(s4.TotalSaleAmt)
             FROM   Sales.SalesPersonSalesByDate AS s4
             WHERE  s4.SalesPersonID = s1.SalesPersonID
             AND    s4.OrderDate <= s1.OrderDate
             AND   (SELECT COUNT(*)
                    FROM   Sales.SalesPersonSalesByDate AS s5
                    WHERE  s5.SalesPersonID = s4.SalesPersonID
                    AND    s5.OrderDate BETWEEN s4.OrderDate
                                            AND s1.OrderDate) <= 5)
                                                            AS AvgTotalSales
FROM         Sales.SalesPersonSalesByDate AS s1
ORDER BY     s1.SalesPersonID, s1.OrderDate;

-- (And if the ordering column(s) are not unique in the set,
--  the query would have been even more complex...)

-- If ANSI compliance is not an issue, you can instead use the TOP operator
-- (query inspired by Peter Larsson)
SELECT       s1.SalesPersonID, s1.Name, s1.OrderDate,
             s1.OrderCount,
            (SELECT AVG(CAST(d1.OrderCount AS decimal(3,0)))
             FROM  (SELECT TOP(4)
                             s2.OrderCount
                    FROM     Sales.SalesPersonSalesByDate AS s2
                    WHERE    s2.SalesPersonID = s1.SalesPersonID
                    AND      s2.OrderDate <= s1.OrderDate
                    ORDER BY s2.OrderDate DESC) AS d1) AS AvgOrderCount,
            s1.TotalSaleAmt,
            (SELECT AVG(d2.TotalSaleAmt)
             FROM  (SELECT TOP(5)
                             s3.TotalSaleAmt
                    FROM     Sales.SalesPersonSalesByDate AS s3
                    WHERE    s3.SalesPersonID = s1.SalesPersonID
                    AND      s3.OrderDate <= s1.OrderDate
                    ORDER BY s3.OrderDate DESC) AS d2) AS AvgTotalSales
FROM         Sales.SalesPersonSalesByDate AS s1
ORDER BY     s1.SalesPersonID, s1.OrderDate;






-- Traditional moving average always lags behind.
-- You can solve that by using the average of a group of rows
-- that is centered around the "current" row.

-- For instance:
-- * average of current, two previous, and two next rows for OrderCount
-- * average of current, three previous, and three next rows for SaleAmount


-- The SQL Server 2000 code that uses TOP (giving up ANSI compliance)
-- is the "fastest" (for some definition of fast) option.
-- (query by Peter Larsson)
SELECT       s1.SalesPersonID, s1.Name, s1.OrderDate,
             s1.OrderCount,
            (SELECT AVG(CAST(d3.OrderCount AS decimal(3,0)))
             FROM  (SELECT d1.OrderCount
                    FROM  (SELECT TOP(3)    -- Current and previous 2
                                    s2.OrderCount
                           FROM     Sales.SalesPersonSalesByDate AS s2
                           WHERE    s2.SalesPersonID = s1.SalesPersonID
                           AND      s2.OrderDate <= s1.OrderDate  -- Includes current
                           ORDER BY s2.OrderDate DESC) AS d1
                    UNION ALL
                    SELECT d2.OrderCount
                    FROM  (SELECT TOP(2)    -- Next 2
                                    s3.OrderCount
                           FROM     Sales.SalesPersonSalesByDate AS s3
                           WHERE    s3.SalesPersonID = s1.SalesPersonID
                           AND      s3.OrderDate > s1.OrderDate  -- Excludes current
                           ORDER BY s3.OrderDate ASC) AS d2) AS d3) AS AvgOrderCount,
             s1.TotalSaleAmt,
            (SELECT AVG(d6.TotalSaleAmt)
             FROM  (SELECT d4.TotalSaleAmt
                    FROM  (SELECT TOP(4)    -- Current and previous 3
                                    s4.TotalSaleAmt
                           FROM     Sales.SalesPersonSalesByDate AS s4
                           WHERE    s4.SalesPersonID = s1.SalesPersonID
                           AND      s4.OrderDate <= s1.OrderDate  -- Includes current
                           ORDER BY s4.OrderDate DESC) AS d4
                    UNION ALL
                    SELECT d5.TotalSaleAmt
                    FROM  (SELECT TOP(3)    -- Next 3
                                    s5.TotalSaleAmt
                           FROM     Sales.SalesPersonSalesByDate AS s5
                           WHERE    s5.SalesPersonID = s1.SalesPersonID
                           AND      s5.OrderDate > s1.OrderDate  -- Excludes current
                           ORDER BY s5.OrderDate ASC) AS d5) AS d6) AS AvgTotalSales
FROM         Sales.SalesPersonSalesByDate AS s1
ORDER BY     s1.SalesPersonID, s1.OrderDate;


-- And finally, an ANSI-compliant version for SQL 2000.
-- The code is a lot cleaner, but it is slower than using TOP
SELECT       s1.SalesPersonID, s1.Name, s1.OrderDate,
             s1.OrderCount,
            (SELECT AVG(CAST(s2.OrderCount AS decimal(3,0)))
             FROM   Sales.SalesPersonSalesByDate AS s2
             WHERE  s2.SalesPersonID = s1.SalesPersonID
             AND   (SELECT COUNT(*)
                    FROM   Sales.SalesPersonSalesByDate AS s3
                    WHERE  s3.SalesPersonID = s2.SalesPersonID
                    AND    s3.OrderDate BETWEEN s2.OrderDate
                                            AND s1.OrderDate) <= 3   -- Current row + 2 previous = 3
             AND   (SELECT COUNT(*)
                    FROM   Sales.SalesPersonSalesByDate AS s4
                    WHERE  s4.SalesPersonID = s2.SalesPersonID
                    AND    s4.OrderDate BETWEEN s1.OrderDate
                                            AND s2.OrderDate) <= 3)  -- Current row + 2 next = 3
                                                            AS AvgTotalSales,
             s1.TotalSaleAmt,
            (SELECT AVG(s5.TotalSaleAmt)
             FROM   Sales.SalesPersonSalesByDate AS s5
             WHERE  s5.SalesPersonID = s1.SalesPersonID
             AND   (SELECT COUNT(*)
                    FROM   Sales.SalesPersonSalesByDate AS s6
                    WHERE  s6.SalesPersonID = s5.SalesPersonID
                    AND    s6.OrderDate BETWEEN s5.OrderDate
                                            AND s1.OrderDate) <= 4   -- Current row + 3 previous = 4
             AND   (SELECT COUNT(*)
                    FROM   Sales.SalesPersonSalesByDate AS s7
                    WHERE  s7.SalesPersonID = s5.SalesPersonID
                    AND    s7.OrderDate BETWEEN s1.OrderDate
                                            AND s5.OrderDate) <= 4)  -- Current row + 3 next = 4
                                                            AS AvgTotalSales
FROM         Sales.SalesPersonSalesByDate AS s1
ORDER BY     s1.SalesPersonID, s1.OrderDate;
