USE AdventureWorks2012;
go

-- Check (part of) data used in this example
SELECT TOP(1000)
         SalesOrderID, OrderDate, CustomerID, TerritoryID, SubTotal, Freight, TaxAmt, TotalDue
FROM     Sales.SalesOrderHeader
ORDER BY SalesOrderID;


-- We need a report for a specific territory; it should include
-- the amount payable BEFORE tax (but including freight),
-- and it should be sorted by CustomerID / OrderDate.
-- (For test, I use territory Canada)
DECLARE @MyTerritoryName nvarchar(50);
SET @MyTerritoryName = N'Canada';

SELECT     s.SalesOrderID, s.OrderDate, s.CustomerID, (s.SubTotal + s.Freight) AS BeforeTax
FROM       Sales.SalesOrderHeader AS s
INNER JOIN Sales.SalesTerritory AS t
      ON   t.TerritoryID = s.TerritoryID
WHERE      t.Name = @MyTerritoryName
ORDER BY   CustomerID, OrderDate;
go

-- The report is fine, but it should support paging.
-- Parameters passed in: @RowsToSkip and @RowsToServe.
-- For this, we need a sort key with unique values;
-- I'll add the primary key, SalesOrderID, as tiebreaker.

-- Here is a pre-SQL2005 version that "almost" works
-- In reality, SQL Server 2000 did not support using a variable with TOP,
-- so you needed to use dynamic SQL if you wanted to use this version.
DECLARE @MyTerritoryName nvarchar(50),
        @RowsToSkip int,
        @RowsToServe int;
SET @MyTerritoryName = N'Canada';
SET @RowsToSkip = 2850;
SET @RowsToServe = 50;

SELECT TOP (@RowsToServe)
           s1.SalesOrderID, s1.OrderDate, s1.CustomerID, (s1.SubTotal + s1.Freight) AS BeforeTax
FROM       Sales.SalesOrderHeader AS s1
INNER JOIN Sales.SalesTerritory AS t1
      ON   t1.TerritoryID = s1.TerritoryID
WHERE      t1.Name = @MyTerritoryName
AND        s1.SalesOrderID NOT IN (SELECT TOP (@RowsToSkip)
                                              s2.SalesOrderID
                                   FROM       Sales.SalesOrderHeader AS s2
                                   INNER JOIN Sales.SalesTerritory AS t2
                                         ON   t2.TerritoryID = s2.TerritoryID
                                   WHERE      t2.Name = @MyTerritoryName
                                   ORDER BY   s2.CustomerID, s2.OrderDate, s2.SalesOrderID)
ORDER BY   s1.CustomerID, s1.OrderDate, s1.SalesOrderID;
go

-- Here is a version that really worked (without dynamic SQL) on SQL Server 2000
-- ... if you had the patience to let it finish.
-- (Because it's so slow, real implementations usually used procedural code.
--  Very popular was insert into temp table with IDENTITY,
--  ensuring that identity values are handed out in sorting order;
--  then select from temp table with filter on identity column).
DECLARE @MyTerritoryName nvarchar(50),
        @RowsToSkip int,
        @RowsToServe int;
SET @MyTerritoryName = N'Canada';
SET @RowsToSkip = 2850;
SET @RowsToServe = 50;

SELECT     s1.SalesOrderID, s1.OrderDate, s1.CustomerID, (s1.SubTotal + s1.Freight) AS BeforeTax
FROM       Sales.SalesOrderHeader AS s1
INNER JOIN Sales.SalesTerritory AS t1
      ON   t1.TerritoryID = s1.TerritoryID
WHERE      t1.Name = @MyTerritoryName
AND       (SELECT     COUNT(*)
           FROM       Sales.SalesOrderHeader AS s2
           INNER JOIN Sales.SalesTerritory AS t2
                 ON   t2.TerritoryID = s2.TerritoryID
           WHERE      t2.Name = @MyTerritoryName
           AND        s2.CustomerID <= s1.CustomerID
           AND NOT(   s2.CustomerID = s1.CustomerID
                  AND s2.OrderDate > s1.OrderDate)
           AND NOT(   s2.CustomerID = s1.CustomerID
                  AND s2.OrderDate = s1.OrderDate
                  AND s2.SalesOrderID > s1.SalesOrderID)) BETWEEN @RowsToSkip + 1
                                                              AND @RowsToSkip + @RowsToServe
ORDER BY   s1.CustomerID, s1.OrderDate, s1.SalesOrderID;
go



-- On SQL Server 2005, we could use EXCEPT to get results faster.
-- Down side: Some computations in SELECT clause have to be repeated.
--           (And they are done for skipped rows. Twice.)
DECLARE @MyTerritoryName nvarchar(50),
        @RowsToSkip int,
        @RowsToServe int;
SET @MyTerritoryName = N'Canada';
SET @RowsToSkip = 2850;
SET @RowsToServe = 50;

SELECT   d1.SalesOrderID, d1.OrderDate, d1.CustomerID, d1.BeforeTax
FROM    (SELECT TOP (@RowsToServe + @RowsToSkip)
                    s1.SalesOrderID, s1.OrderDate, s1.CustomerID, (s1.SubTotal + s1.Freight) AS BeforeTax
         FROM       Sales.SalesOrderHeader AS s1
         INNER JOIN Sales.SalesTerritory AS t1
               ON   t1.TerritoryID = s1.TerritoryID
         WHERE      t1.Name = @MyTerritoryName
         ORDER BY   s1.CustomerID, s1.OrderDate, s1.SalesOrderID) AS d1
EXCEPT
SELECT   d2.SalesOrderID, d2.OrderDate, d2.CustomerID, d2.BeforeTax
FROM    (SELECT TOP (@RowsToSkip)
                    s2.SalesOrderID, s2.OrderDate, s2.CustomerID, (s2.SubTotal + s2.Freight) AS BeforeTax
         FROM       Sales.SalesOrderHeader AS s2
         INNER JOIN Sales.SalesTerritory AS t2
               ON   t2.TerritoryID = s2.TerritoryID
         WHERE      t2.Name = @MyTerritoryName
         ORDER BY   s2.CustomerID, s2.OrderDate, s2.SalesOrderID) AS d2
ORDER BY CustomerID, OrderDate, SalesOrderID;
go

-- Or we could rely on our old friend, ROW_NUMBER.
-- (Appears to be faster, though the data set is too small to really tell)
DECLARE @MyTerritoryName nvarchar(50),
        @RowsToSkip int,
        @RowsToServe int;
SET @MyTerritoryName = N'Canada';
SET @RowsToSkip = 2850;
SET @RowsToServe = 50;

WITH NumberedRows
AS (SELECT     s.SalesOrderID, s.OrderDate, s.CustomerID, s.SubTotal, s.Freight,
               ROW_NUMBER() OVER (ORDER BY s.CustomerID, s.OrderDate, s.SalesOrderID) AS rn
    FROM       Sales.SalesOrderHeader AS s
    INNER JOIN Sales.SalesTerritory AS t
          ON   t.TerritoryID = s.TerritoryID
    WHERE      t.Name = @MyTerritoryName)
SELECT   SalesOrderID, OrderDate, CustomerID, (SubTotal + Freight) AS BeforeTax
FROM     NumberedRows
WHERE    rn BETWEEN @RowsToSkip + 1 AND @RowsToSkip + @RowsToServe
ORDER BY CustomerID, OrderDate, SalesOrderID;
go



-- And in SQL Server 2012 - Guess what?
-- Simple! Not with OVER, this time, but with OFFSET and FETCH
DECLARE @MyTerritoryName nvarchar(50),
        @RowsToSkip int,
        @RowsToServe int;
SET @MyTerritoryName = N'Canada';
SET @RowsToSkip = 2850;
SET @RowsToServe = 50;

SELECT     s.SalesOrderID, s.OrderDate, s.CustomerID, (s.SubTotal + s.Freight) AS BeforeTax
FROM       Sales.SalesOrderHeader AS s
INNER JOIN Sales.SalesTerritory AS t
      ON   t.TerritoryID = s.TerritoryID
WHERE      t.Name = @MyTerritoryName
ORDER BY   s.CustomerID, s.OrderDate, s.SalesOrderID
     OFFSET @RowsToSkip ROWS
     FETCH NEXT @RowsToServe ROWS ONLY;
go
