/*
 * Create some tables and data to work with during these examples
 */
CREATE TABLE Source (
	SourceID int NOT NULL,
	Description varchar(40),
	InsType char(2)
	);

INSERT INTO Source (SourceID, Description, InsType)
	VALUES	(1, 'Commercial Health Insurance', 'CM'),
			(2, 'County Hospital', NULL),
			(3, 'City Hospital', NULL),
			(4, 'Medicare', 'MC');

CREATE TABLE Patients (
	PatientID int NOT NULL,
	LastName varchar(40) NOT NULL,
	FirstName varchar(40) NULL,
	MiddleInit char(1) NULL,
	Gender char(1) NULL,
	DOB date NULL,
	DOD date NULL,
	SourceID int NOT NULL
	);

INSERT INTO Patients(PatientID, LastName, FirstName, MiddleInit, Gender, DOB, DOD, SourceID)
	VALUES  (123456, 'Duck', 'Daffy', 'D', 'M', '03/05/1964', NULL, 1),
			(234567, 'Bunny', 'Bugs', 'B', 'M', '02/29/1964', NULL, 1),
			(345678, 'Coyote', 'Wile', 'E', 'M', '01/15/1966', '12/06/1999', 2),
			(123456, 'Duck', 'Daffy', 'D', 'M', '03/05/1964', NULL, 1), -- Duplicate
			(456789, 'Runner', 'Road', NULL, 'F', '04/23/1974', NULL, 2),
			(345678, 'Coyote', 'Whylee', NULL, NULL, '01/15/1966', '12/07/1999', 2), -- Duplicate
			(123456, 'Duck', 'Daffy', 'D', 'M', '03/05/1964', NULL, 1), -- Duplicate
			(567890, 'Duck', 'Daisy', NULL, 'F', '05/03/1966', NULL, 1),
			(564231, 'Fudd', 'Elmer', NULL, 'M', '03/20/1946', NULL, 4),
			(853156, 'Bird', 'Tweety', NULL, 'M', '10/10/1960', NULL, 3),
			(462137, 'Cat', 'Sylvester', 'T', 'M', '12/15/1955', NULL, 3),
			(134679, 'LePue', 'Peppy', NULL, 'M', '11/11/1959', NULL, 3),
			(963741, 'Duck', 'Huey', NULL, 'M', '09/09/1979', NULL, 1),
			(963742, 'Duck', 'Louie', NULL, 'M', '09/09/1979', NULL, 1),
			(963743, 'Duck', 'Dewey', NULL, 'M', '09/09/1979', NULL, 1);

/*
 * Delete duplicate data -- typically used in staging tables without primary key
 */
SELECT * FROM Patients ORDER BY PatientID;

WITH cteDups AS (
	SELECT *,ROW_NUMBER() OVER(PARTITION BY PatientID ORDER BY PatientID) AS RowNbr
	FROM Patients
	)
DELETE
FROM cteDups
WHERE RowNbr > 1;

SELECT * FROM Patients ORDER BY PatientID;

/*
 * Return Random Rows From a Table
 * This is very very easy : you just have to select the top n rows(where n is the number of the rows you want to return) and order by NEWID()
 * NEWID is a system function that creates a unique value of type uniqueidentifier.
 */

SELECT TOP 5 *
FROM Patients
ORDER BY NEWID();

-- =============================================
-- Author:		Aaron N. Cutshall
-- Create Date: 21-Jun-2007
-- Modify Date: 27-Jun-2011 ANC -- Adjust for more accurate calculation
-- Description:	Determine the age of a patient rounded down to the nearest 3 months (quarter year)
-- =============================================
CREATE FUNCTION [dbo].[fnCalcAge] (@DOB date, @AsOfDate date) RETURNS real
AS
BEGIN
	DECLARE @Anniversary_yy date,
			@Anniversary_mm date,
			@yyCount int,
			@mmCount int;

	SET @Anniversary_yy = DATEADD(yy, DATEDIFF(yy, @DOB, @AsOfDate), @DOB);
	SET @Anniversary_mm = DATEADD(mm, DATEDIFF(mm, @DOB, @AsOfDate), @DOB);

	SET @yyCount = CASE WHEN @Anniversary_yy <= @AsOfDate
						THEN DATEDIFF(yy, @DOB, @AsOfDate)
						ELSE DATEDIFF(yy, @DOB, @AsOfDate)-1
						END;
	SET @mmCount = CASE WHEN @Anniversary_mm <= @AsOfDate
						THEN DATEDIFF(mm, DATEADD(yy, @yyCount, @DOB), @AsOfDate)
						ELSE DATEDIFF(mm, DATEADD(yy, @yyCount, @DOB), @AsOfDate)-1
						END;
		
	RETURN FLOOR((@yyCount + (@mmCount / 12.0))/0.25)*0.25;
END

/*
 * Simplify usage of complicated expressions
 * This is super simple: when using an expression more than once, make use of a CTE
 */

WITH ctePatients(PatientID, LastName, FirstName, Age) AS (
	SELECT PatientID, LastName, FirstName, dbo.fnCalcAge(DOB, GETDATE())
	FROM Patients
	)
SELECT PatientID, LastName, FirstName, Age
FROM ctePatients
WHERE Age >= 50
ORDER BY Age;
