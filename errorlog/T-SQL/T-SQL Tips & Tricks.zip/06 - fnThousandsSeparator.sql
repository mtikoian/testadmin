-- =============================================
-- Author:		Aaron N. Cutshall
-- Create date: 03-Jan-2012
-- Description:	Convert an integer to a string with embedded thousands separators
--				and right justified.  There is a max lenth of 19 character
--				(15 digit with separators) because of the upper limit of MONEY.
-- =============================================
CREATE FUNCTION fnThousandsSeparator
(
	@intValue money
)
RETURNS varchar(19)
AS
BEGIN
	DECLARE @Result varchar(22) = CONVERT(varchar(22), @intValue, 1);
	SET @Result = SUBSTRING(@Result,1,LEN(@Result)-3);
	RETURN SPACE(19-LEN(@Result)) + @Result;
END
GO

SELECT dbo.fnThousandsSeparator(COUNT(*))
FROM sys.syscolumns A, sys.syscolumns B;