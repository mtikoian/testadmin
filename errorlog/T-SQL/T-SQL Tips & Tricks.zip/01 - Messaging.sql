CREATE TABLE [dbo].[tbLog_Group] (
	[LogGroupID] [int] IDENTITY(1,1) NOT NULL,
	[GroupName] [varchar](64) NULL,
	[GroupIdentifier] [varchar](64) NULL,
	[TimeStamp] [datetime] NULL,
 CONSTRAINT [PK_tbLog_Group] PRIMARY KEY CLUSTERED (
	[LogGroupID] ASC
	) WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF,
			ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY];
GO
ALTER TABLE [dbo].[tbLog_Group]
	ADD CONSTRAINT [DF_tbLog_Group_TimeStamp]
		DEFAULT (getdate()) FOR [TimeStamp];
GO


CREATE TABLE [dbo].[tbLog_Message] (
	[LogMsgID] [int] IDENTITY(1,1) NOT NULL,
	[LogGroupID] [int] NULL,
	[ProcedureName] [varchar](64) NULL,
	[Description] [varchar](256) NULL,
	[MsgLevel] [tinyint] NULL,
	[StartTime] [datetime] NOT NULL,
	[StopTime] [datetime] NULL,
	[RowCnt] [int] NULL,
	[ErrorMsg] [varchar](max) NULL,
 CONSTRAINT [PK_tbLog_Message] PRIMARY KEY CLUSTERED (
	[LogMsgID] ASC
	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF,
			ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY];
GO
ALTER TABLE [dbo].[tbLog_Message] WITH CHECK
	ADD CONSTRAINT [FK_tbLog_Message_tbLog_Group]
		FOREIGN KEY([LogGroupID]) REFERENCES [dbo].[tbLog_Group] ([LogGroupID]);
GO
ALTER TABLE [dbo].[tbLog_Message]
	CHECK CONSTRAINT [FK_tbLog_Message_tbLog_Group];
GO
ALTER TABLE [dbo].[tbLog_Message]
	ADD CONSTRAINT [DF_tbLog_Message_StartTime]
		DEFAULT (getdate()) FOR [StartTime];
GO

-- =============================================
-- Author:		Julian Kuiters
-- Site:		www.julian-kuiters.id.au
-- Create date: 03-Jul-2007
-- Modified:	15-May-2008 ANC -- Corrected to allow a % sign to be in the message text and added
--									depth indentation
-- Description:	Print this current time and optionally a message without waiting for your current
--				batch / transation to complete
-- Example:		EXEC dbo.sp_PrintTrace 'Started Loop'
-- =============================================
CREATE PROCEDURE spdb_PrintTrace (@Message varchar(2048) = NULL, @Depth int = 0) AS
BEGIN
	SET @Message = LEFT(CONVERT(varchar(10), GETDATE() ,101) + ' ' +
					CONVERT(varchar(8), GETDATE(), 8) + ' ' +
					SPACE(@Depth*4) + REPLACE(ISNULL(@Message, ''),'%','%%'), 2048);
	RAISERROR (@Message, 0, 1) WITH NOWAIT;
END
GO

-- =============================================
-- Author:		Aaron N. Cutshall
-- Create Date: 29-Sep-2011
-- Description:	Create or retrieve a log group ID
-- =============================================
CREATE PROCEDURE spdb_LogGroup
	@GroupName varchar(64),
	@GroupIdentifier varchar(64),
	@IsNew bit = 0,
	@LogGroupID int OUTPUT
AS
BEGIN
	IF @IsNew = 0
		SELECT TOP 1 @LogGroupID = LogGroupID
		FROM tbLog_Group
		WHERE GroupName = @GroupName
		AND (@GroupIdentifier IS NULL OR GroupIdentifier = @GroupIdentifier)
		ORDER BY [TimeStamp] DESC;

	IF @IsNew = 1 OR @LogGroupID IS NULL BEGIN
		DECLARE @tblOutput table(LogGroupID int);

		INSERT INTO tbLog_Group (GroupName, GroupIdentifier)
			OUTPUT Inserted.LogGroupID INTO @tblOutput
			VALUES (@GroupName, @GroupIdentifier);

		SELECT @LogGroupID = LogGroupID FROM @tblOutput;
		END

	RETURN @LogGroupID;
END
GO


-- =============================================
-- Author:		Aaron N. Cutshall
-- Create date: 29-Sep-2011
-- Description:	Start a log message and return its ID
-- =============================================
CREATE PROCEDURE spdb_LogStart
	@LogGroupID int,
	@ProcedureName varchar(64),
	@Description varchar(256),
	@MsgLevel tinyint = 1,
	@LogMsgID int OUTPUT
AS
BEGIN
	DECLARE @tblOutput table(LogMsgID int);

	INSERT INTO tbLog_Message (LogGroupID, ProcedureName, Description, MsgLevel)
		OUTPUT Inserted.LogMsgID INTO @tblOutput
		VALUES (@LogGroupID, @ProcedureName, @Description, @MsgLevel);

	SELECT @LogMsgID = LogMsgID FROM @tblOutput;
	SET @Description = @Description + '...';
	EXEC spdb_PrintTrace @Description, @MsgLevel;
END
GO


-- =============================================
-- Author:		Aaron N. Cutshall
-- Create date: 29-Sep-2011
-- Description:	Complete a log message
-- =============================================
CREATE PROCEDURE spdb_LogStop
	@LogMsgID int,
	@RowCnt int = NULL,
	@ErrorMsg varchar(max) = NULL
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @MsgLevel int,
			@TraceMsg varchar(max),
			@StartTime datetime,
			@StopTime datetime;

	UPDATE tbLog_Message SET StopTime = GETDATE(), RowCnt = @RowCnt, ErrorMsg = @ErrorMsg
		WHERE LogMsgID = @LogMsgID;

	SELECT @MSgLevel = MsgLevel+1, @StartTime = StartTime, @StopTime = StopTime
	FROM tbLog_Message
	WHERE LogMsgID = @LogMsgID;

	IF @MsgLevel IS NULL
		SET @TraceMsg = 'Unknown message ID: ' + CAST(@LogMsgID as varchar);
	ELSE
		SET @TraceMsg = ISNULL('Records Processed: ' + CAST(@RowCnt as varchar), 'Completed.') +
				'  Elapsed Time: ' + CONVERT(varchar, DATEDIFF(DAY, @StopTime, @StartTime)) + 'd ' +
				RIGHT(CONVERT(varchar, @StopTime - @StartTime, 113),12);
	EXEC spdb_PrintTrace @TraceMsg, @MsgLevel;
END
GO

--	Usage Example:

	SET NOCOUNT ON;

	DECLARE @LogGroupID int, @LogMsgID int;

	EXEC spdb_LogGroup 'SampleGroupName', 'spSampleProgram', 1, @LogGroupID OUTPUT;

	EXEC spdb_LogStart @LogGroupID, 'spSampleProgram', 'Start Calculation', 1, @LogMsgID OUTPUT;

	SELECT * FROM sys.syscolumns;

	EXEC spdb_LogStop @LogMsgID, @@ROWCOUNT;
