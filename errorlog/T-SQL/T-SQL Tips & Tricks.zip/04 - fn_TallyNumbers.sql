-- =============================================
-- Author:		Aaron N. Cutshall
-- Create date: 16-Feb-2009
-- Description:	Generate a tally number table
-- =============================================
CREATE FUNCTION dbo.fn_TallyNumbers (@MaxCount int)
RETURNS TABLE AS RETURN (
	SELECT TOP(@MaxCount) ROW_NUMBER() OVER(ORDER BY (SELECT 0)) as N
	FROM master.dbo.syscolumns SC1, master.dbo.syscolumns SC2
)
GO

/*
Example 1:	Let's say that you need to generate a list of all dates from 05/12/2008 to 06/02/2008
			inclusive. You might use a temp table or table variable, and construct a loop that
			inserts records for each date in the range. By using a tally table, all you need is
			this (using variables to make it flexible):
*/
DECLARE @start date = '05/12/2008', @end date = '06/02/2008';

SELECT DATEADD(d, (N - 1), @start) as [Date]
FROM dbo.fn_TallyNumbers(DATEDIFF(d, @start, @end) + 1);

/*
Example 2:	I want to find out how many people have a birthday in each month but I don't want to
			skip any months.
*/

--Normally I'd use this query
WITH cteBirthday(PatientID, DOB_Month) AS (
	SELECT PatientID, DATEPART(mm, DOB)
	FROM Patients
	)
SELECT DOB_Month as 'Month', COUNT(*)
FROM cteBirthday
GROUP BY DOB_Month;

-- However, this will not return a row for any month that did not have a birthday.  You can use a
-- tally to ensure that you have totals for all 12 months, even for months without a birthday.

WITH cteBirthday(PatientID, DOB_Month) AS (
	SELECT PatientID, DATEPART(mm, DOB)
	FROM Patients
	)
SELECT N as 'Month', COUNT(DOB_Month)
FROM dbo.fn_TallyNumbers(12) T
	LEFT JOIN cteBirthday B on T.N = B.DOB_Month
GROUP BY N;