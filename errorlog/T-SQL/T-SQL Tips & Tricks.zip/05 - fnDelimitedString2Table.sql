-- =============================================
-- Author:		Aaron N. Cutshall
-- Create date: 03-Jan-2012
-- Description:	Convert a delimited string into a table of values
-- =============================================
CREATE FUNCTION fnDelimitedString2Table (
	@StringList varchar(max),
	@Delimiter char(1)
)
RETURNS TABLE 
AS
RETURN 
(
	WITH cteList(Element, List) AS (
		SELECT CASE WHEN CHARINDEX(@Delimiter, @StringList, 1) = 0 THEN @StringList
					ELSE SUBSTRING(@StringList, 1, CHARINDEX(@Delimiter, @StringList, 1) - 1)
					END AS Element,
				CASE WHEN CHARINDEX(@Delimiter, @StringList, 1) = 0 THEN ''
					ELSE SUBSTRING(@StringList, CHARINDEX(@Delimiter, @StringList, 1) + 1, LEN(@StringList)) + @Delimiter
					END AS List

		UNION ALL

		SELECT SUBSTRING(L.List, 1, CHARINDEX(@Delimiter, L.List, 1) - 1) AS Element,
				SUBSTRING(L.List, CHARINDEX(@Delimiter, L.List, 1) + 1, LEN(L.List)) AS List
		FROM cteList L
		WHERE LEN(L.List) > 0
		)
	SELECT Element
	FROM cteList
)
GO

SELECT PatientID, LastName, FirstName, DOB
FROM dbo.fnDelimitedString2Table('Huey,Louie,Dewey',',') A
	INNER JOIN Patients B ON B.FirstName = A.Element;