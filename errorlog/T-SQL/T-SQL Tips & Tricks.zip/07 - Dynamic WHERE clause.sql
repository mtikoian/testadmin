DECLARE @PatientID int = NULL;
DECLARE @Gender char(1) = NULL;
--DECLARE @PatientID int = 134679;
--DECLARE @Gender char(1) = 'M';

SELECT *
FROM Patients
WHERE PatientID = ISNULL(@PatientID, PatientID)
AND Gender = ISNULL(@Gender, Gender);

SELECT *
FROM Patients
WHERE (@PatientID IS NULL OR PatientID = @PatientID)
AND (@Gender IS NULL OR Gender = @Gender);