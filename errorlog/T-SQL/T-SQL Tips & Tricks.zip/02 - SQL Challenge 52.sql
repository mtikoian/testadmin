/*
TSQL Challenge 52 - Recursive Wage Calculation in a Parent-Child Dimension 

from Beyond Relational
http://beyondrelational.com/puzzles/challenges/89/recursive-wage-calculation-in-a-parent-child-
	dimension.aspx

Description
In an Employee Parent-Child dimension, where each employee has his own identification number and a
parent number to his manager. This challenge is intended to calculate company's wage spent below a
top level manager.

Rules 
1.	Note that the tree is not balanced.
2.	Note that there is no flag to determine if an employee is a leaf employee.
3.	'Max wage employees' is a comma separated list of people (in alphabetical order) earning that
	maximum wage.
4.	Employee Names will contain only letters a-z in upper, lower or mixed case.
5.	The output should be ordered by name in a case insensitive alphabetical order.
6.	When the top level manager has no employee, the output should be 0.00 for the max wage amount
	and an empty string for the max wage employees.

Restrictions 
1.	The solution should be a single query that starts with a "SELECT" or �;WITH� 
*/
IF object_id(N'TempDB..#TC52') IS NOT NULL DROP TABLE #TC52;

CREATE TABLE #TC52(
	Employee_Name VARCHAR(20),
	Number INT,
	ManagerNumber INT,
	Wage MONEY
	);

INSERT INTO #TC52(Employee_Name, Number, ManagerNumber, wage)
	VALUES  ('Jacob', 345, NULL, 3000),
			('Marco', 873, NULL, 3000),
			('John', 844, 345, 1880),
			('James', 139, 844, 2010),
			('Ruth', 111, 873, 1550),
			('Margaret', 622, 345, 1300),
			('Mike', 999, 622, 2010),
			('Paul', 611, 139, 1400);

SELECT * FROM #TC52;


/*
Expected Results:

Name   Total Wage  Max wage amount  Max wage employees
-----  ----------  ---------------  ------------------
Jacob  11600.00    2010.00          James,Mike
Marco  4550.00     1550.00          Ruth
*/
WITH
-- Note the use of recursion in this CTE
-- Get all the top managers first (those without a manager)
cteEmpList(TopMgrNbr, TopMgrName, TopMgrWage, MgrNbr, EmpNbr, EmpName, EmpWage, Wage) AS (
	SELECT Number, Employee_Name, Wage, Number, Number, Employee_Name, CAST(0.0 as Money), Wage
	FROM #TC52
	WHERE ManagerNumber IS NULL
-- UNION ALL does not eliminate perceived duplicates and is important in recursive CTEs
UNION ALL
-- Get the employees of each manager keeping track of the top manager
	SELECT L.TopMgrNbr, L.TopMgrName, L.TopMgrWage, T.ManagerNumber, T.Number, T.Employee_Name,
			T.Wage, T.Wage
	FROM #TC52 AS T
		INNER JOIN cteEmpList AS L ON L.EmpNbr = T.ManagerNumber
	WHERE T.ManagerNumber IS NOT NULL
	),
-- Perform a ranking of each top manager according to the employee wages in descending order
cteFinal(TopMgrNbr, TopMgrName, TopMgrWage, MgrNbr, EmpNbr, EmpName, EmpWage, Wage, RankNbr) AS (
	SELECT TopMgrNbr, TopMgrName, TopMgrWage, MgrNbr, EmpNbr, EmpName, EmpWage, Wage,
			RANK() OVER (PARTITION BY TopMgrNbr ORDER BY EmpWage DESC) as RankNbr
	FROM cteEmpList
	)
-- Select each of the top managers and their top earners in a comma-separated string
SELECT A.TopMgrName as Name, SUM(A.Wage) as [Total Wage], MAX(A.EmpWage) as [Max wage Amount],
		ISNULL(STUFF((SELECT ',' + B.EmpName
				FROM cteFinal B
				WHERE B.TopMgrName = A.TopMgrName
				AND B.RankNbr = 1
				AND B.EmpWage > 0
				ORDER BY B.EmpName
				FOR XML PATH('')),1 ,1, ''),'') as [Max wage Employees]
FROM cteFinal A
GROUP BY A.TopMgrName
ORDER BY A.TopMgrName;

/*
In general, if you want to select values from a table and create a comma separated string you can
follow this example:
*/
--Step 01: Generate Temp table to store source data
DECLARE @NamesTable TABLE (
	Id INT,
	Name NVARCHAR(50)
	);

--Step 02: Generate test data
INSERT INTO @NamesTable
	VALUES (1,'A'), (2,'D'), (2,'C'), (3,'E'), (3,'H'), (3,'G');

--Step 03: Query the data (STUFF eliminates the beginning comma)
SELECT STUFF((SELECT (',' + nt.Name)
              FROM @NamesTable nt
              FOR XML PATH('')), 1, 1, '');
GO