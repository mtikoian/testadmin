
USE northwind
GO

-- Get running SUM 
WITH CTE AS
(

	SELECT  dbo.Customers.CompanyName
			, cast(dbo.Orders.OrderDate as date) OrderDate
			, SUM(dbo.[Order Details].UnitPrice * dbo.[Order Details].Quantity) OrderTotal
	FROM dbo.Customers INNER JOIN
		dbo.Orders ON dbo.Customers.CustomerID = dbo.Orders.CustomerID INNER JOIN
		dbo.[Order Details] ON dbo.Orders.OrderID = dbo.[Order Details].OrderID
	GROUP BY dbo.Customers.CompanyName, cast(dbo.Orders.OrderDate as date)
)
SELECT CompanyName, OrderDate, OrderTotal
	 ,RunningSumByCompany =  SUM(OrderTotal) OVER (PARTITION BY CompanyName ORDER BY CompanyName, OrderDate ROWS UNBOUNDED PRECEDING)
	 ,RunningSumALL =  SUM(OrderTotal) OVER ( ORDER BY CompanyName, OrderDate ROWS UNBOUNDED PRECEDING)
FROM CTE

-- 
;WITH CTE AS
(

	SELECT  dbo.Customers.CompanyName
			, cast(dbo.Orders.OrderDate as date) OrderDate
			, SUM(dbo.[Order Details].UnitPrice * dbo.[Order Details].Quantity) OrderTotal
	FROM dbo.Customers INNER JOIN
		dbo.Orders ON dbo.Customers.CustomerID = dbo.Orders.CustomerID INNER JOIN
		dbo.[Order Details] ON dbo.Orders.OrderID = dbo.[Order Details].OrderID
	GROUP BY dbo.Customers.CompanyName, cast(dbo.Orders.OrderDate as date)
)
SELECT CompanyName, OrderDate, OrderTotal
	 ,RunningSumByCompany =  SUM(OrderTotal) OVER (PARTITION BY convert(char(6), OrderDate, 112)  ORDER BY OrderDate ROWS UNBOUNDED PRECEDING)
FROM CTE


-- Totals Based Upon a Subset of Rows  *** RANGE UNBOUNDED PRECEDING - default
;WITH CTE AS
(

	SELECT  dbo.Customers.CompanyName
			, cast(dbo.Orders.OrderDate as date) OrderDate
			, SUM(dbo.[Order Details].UnitPrice * dbo.[Order Details].Quantity) OrderTotal
	FROM dbo.Customers INNER JOIN
		dbo.Orders ON dbo.Customers.CustomerID = dbo.Orders.CustomerID INNER JOIN
		dbo.[Order Details] ON dbo.Orders.OrderID = dbo.[Order Details].OrderID
	GROUP BY dbo.Customers.CompanyName, cast(dbo.Orders.OrderDate as date)
)
SELECT CompanyName, LEFT(OrderDate, 7) OrderDate, OrderTotal
	 ,RunningSumByCompany =  SUM(OrderTotal) OVER (ORDER BY CompanyName, LEFT(OrderDate, 7) ROWS UNBOUNDED PRECEDING)
	 ,RunningSumALL =  SUM(OrderTotal) OVER ( ORDER BY CompanyName, LEFT(OrderDate, 7) RANGE UNBOUNDED PRECEDING)
FROM CTE
ORDER BY CompanyName



-- Show slide row calculation
;WITH CTE AS
(

	SELECT  dbo.Customers.CompanyName
			, cast(dbo.Orders.OrderDate as date) OrderDate
			, SUM(dbo.[Order Details].UnitPrice * dbo.[Order Details].Quantity) OrderTotal
	FROM dbo.Customers INNER JOIN
		dbo.Orders ON dbo.Customers.CustomerID = dbo.Orders.CustomerID INNER JOIN
		dbo.[Order Details] ON dbo.Orders.OrderID = dbo.[Order Details].OrderID
	GROUP BY dbo.Customers.CompanyName, cast(dbo.Orders.OrderDate as date)
)
SELECT CompanyName, OrderDate, OrderTotal,
-- average of the current and previous 2 transactions
	SlideAvg = AVG(OrderTotal) OVER (PARTITION BY CompanyName ORDER BY OrderDate ROWS BETWEEN 2 PRECEDING AND CURRENT ROW),
-- total # of the current and previous 2 transactions
	SlideQty = COUNT(*) OVER (PARTITION BY CompanyName ORDER BY OrderDate ROWS BETWEEN 2 PRECEDING AND CURRENT ROW),
-- smallest of the current and previous 2 transactions
	SlideMin = MIN(OrderTotal) OVER (PARTITION BY CompanyName ORDER BY OrderDate ROWS BETWEEN 2 PRECEDING AND CURRENT ROW),
-- largest of the current and previous 2 transactions
	SlideMax = MAX(OrderTotal) OVER (PARTITION BY CompanyName ORDER BY OrderDate ROWS BETWEEN 2 PRECEDING AND CURRENT ROW),
-- total of the current and previous 2 transactions
	SlideTotal = SUM(OrderTotal) OVER (PARTITION BY CompanyName ORDER BY OrderDate ROWS BETWEEN 2 PRECEDING AND CURRENT ROW)
FROM CTE
ORDER BY CompanyName




-- LEAD and LAG functions
SELECT  Year(dbo.Orders.OrderDate) SalesYear
		, SUM(dbo.[Order Details].UnitPrice * dbo.[Order Details].Quantity) Sales
		, LEAD(SUM(dbo.[Order Details].UnitPrice * dbo.[Order Details].Quantity)) OVER(ORDER BY Year(dbo.Orders.OrderDate)) AS [Next Year Sale]
        , LAG(SUM(dbo.[Order Details].UnitPrice * dbo.[Order Details].Quantity)) OVER(ORDER BY Year(dbo.Orders.OrderDate))AS [Prev Year Sale]

		, LEAD(SUM(dbo.[Order Details].UnitPrice * dbo.[Order Details].Quantity),2,0) OVER(ORDER BY Year(dbo.Orders.OrderDate)) AS [2nd Next Year Sale]
        , LAG(SUM(dbo.[Order Details].UnitPrice * dbo.[Order Details].Quantity),2,0) OVER(ORDER BY Year(dbo.Orders.OrderDate))AS [2nd Prev Year Sale]
FROM dbo.Customers INNER JOIN
	dbo.Orders ON dbo.Customers.CustomerID = dbo.Orders.CustomerID INNER JOIN
	dbo.[Order Details] ON dbo.Orders.OrderID = dbo.[Order Details].OrderID
GROUP BY Year(dbo.Orders.OrderDate)



USE Northwind
GO

/******************************** Conventional: CURSOR based method ***********************************************************/
PRINT '***************************Conventional: CURSOR based method***************************************'
GO
SET STATISTICS TIME ON

declare @x xml
-- get XML
SELECT @x = 
(
	SELECT Products.ProductName, 
			Customers.CompanyName, 
			Shippers.CompanyName AS ShippersName, 
			convert(varchar(20),GETDATE(),101) as OrderDate, 
		   [Order Details].UnitPrice, 
		   [Order Details].Quantity, 
		   CAST([Order Details].Discount as varchar(9)) as Discount
	FROM  Products INNER JOIN
		   [Order Details] ON Products.ProductID = [Order Details].ProductID INNER JOIN
		   Orders ON [Order Details].OrderID = Orders.OrderID INNER JOIN
		   Customers ON Orders.CustomerID = Customers.CustomerID INNER JOIN
		   Shippers ON Orders.ShipVia = Shippers.ShipperID
	WHERE  Orders.OrderDate = '1998-05-05'
	FOR XML PATH('Product'), ROOT('Orders')
)	

-- Created cursor
DECLARE @CustomerID varchar(20), @OrderDate datetime, @ShippersID int, @OrderID int 
DECLARE cur CURSOR 
	FOR	SELECT DISTINCT	Customers.CustomerID, 
				c.value('OrderDate[1]', 'datetime') as OrderDate, 
				Shippers.ShipperID
		FROM @x.nodes('Orders/Product') as T(C)
			JOIN Products ON Products.ProductName = c.value('ProductName[1]', 'nvarchar(100)')
			JOIN Shippers ON Shippers.CompanyName =  c.value('ShippersName[1]', 'nvarchar(100)')
			JOIN Customers ON Customers.CompanyName = c.value('CompanyName[1]', 'nvarchar(100)')
OPEN cur
FETCH NEXT FROM cur INTO @CustomerID, @OrderDate, @ShippersID

-- Check @@FETCH_STATUS to see if there are any more rows to fetch.
WHILE @@FETCH_STATUS = 0
BEGIN

-- INSERT into Orders table
INSERT Orders (CustomerID, OrderDate, ShipVia)
SELECT		@CustomerID, @OrderDate, @ShippersID

SET @OrderID = SCOPE_IDENTITY()

-- INSERT into Order Details table
INSERT [Order Details] (OrderID, ProductID, UnitPrice, Quantity, Discount)
SELECT @OrderID, Products.ProductID,
		c.value('UnitPrice[1]', 'money') as UnitPrice, 
		c.value('Quantity[1]', 'int') as Quantity, 
		c.value('Discount[1]', 'real') as Discount
FROM @x.nodes('Orders/Product') as T(C)
	JOIN Products ON Products.ProductName = c.value('ProductName[1]', 'nvarchar(100)')
	JOIN Shippers ON Shippers.CompanyName =  c.value('ShippersName[1]', 'nvarchar(100)')
	JOIN Customers ON Customers.CompanyName = c.value('CompanyName[1]', 'nvarchar(100)')
WHERE Customers.CustomerID = @CustomerID
	
FETCH NEXT FROM cur INTO @CustomerID, @OrderDate, @ShippersID

END

DEALLOCATE cur;

SET STATISTICS TIME OFF


/**************************************************** OUTPUT Clause ******************************************************************************/

SET NOCOUNT ON

SET STATISTICS TIME ON
PRINT '*************************** OUTPUT Clause based method***************************************'
declare @x xml
-- get XML
SELECT @x = 
(
	SELECT Products.ProductName, 
			Customers.CompanyName, 
			Shippers.CompanyName AS ShippersName, 
			convert(varchar(20),GETDATE(),101) as OrderDate, 
		   [Order Details].UnitPrice, 
		   [Order Details].Quantity, 
		   CAST([Order Details].Discount as varchar(9)) as Discount
	FROM  Products INNER JOIN
		   [Order Details] ON Products.ProductID = [Order Details].ProductID INNER JOIN
		   Orders ON [Order Details].OrderID = Orders.OrderID INNER JOIN
		   Customers ON Orders.CustomerID = Customers.CustomerID INNER JOIN
		   Shippers ON Orders.ShipVia = Shippers.ShipperID
	WHERE  Orders.OrderDate = '1998-05-05'
	FOR XML PATH('Product'), ROOT('Orders')
)	
/*
-- Create then Shred XML
SELECT c.value('ProductName[1]', 'nvarchar(100)') as ProductName, 
		c.value('CompanyName[1]', 'nvarchar(100)') as CompanyName, 
		c.value('ShippersName[1]', 'nvarchar(100)') as ShippersName, 
		c.value('OrderDate[1]', 'datetime') as OrderDate, 
		c.value('UnitPrice[1]', 'money') as UnitPrice, 
		c.value('Quantity[1]', 'int') as Quantity, 
		c.value('Discount[1]', 'real') as Discount,
		Products.ProductID,
		Shippers.ShipperID,
		Customers.CustomerID
FROM @x.nodes('Orders/Product') as T(C)
	JOIN Products ON Products.ProductName = c.value('ProductName[1]', 'nvarchar(100)')
	JOIN Shippers ON Shippers.CompanyName =  c.value('ShippersName[1]', 'nvarchar(100)')
	JOIN Customers ON Customers.CompanyName = c.value('CompanyName[1]', 'nvarchar(100)')
*/
-- Created output storage table
DECLARE @NewOrder TABLE(OrderID int, CustomerID nchar(5))

-- INSERT into Orders table
INSERT Orders (CustomerID, OrderDate, ShipVia)
		OUTPUT inserted.OrderID, inserted.CustomerID INTO @NewOrder (OrderID, CustomerID)
SELECT distinct	Customers.CustomerID, 
		c.value('OrderDate[1]', 'datetime') as OrderDate, 
		Shippers.ShipperID
FROM @x.nodes('Orders/Product') as T(C)
	JOIN Products ON Products.ProductName = c.value('ProductName[1]', 'nvarchar(100)')
	JOIN Shippers ON Shippers.CompanyName =  c.value('ShippersName[1]', 'nvarchar(100)')
	JOIN Customers ON Customers.CompanyName = c.value('CompanyName[1]', 'nvarchar(100)')
	
-- INSERT into Order Details table
INSERT [Order Details] (OrderID, ProductID, UnitPrice, Quantity, Discount)
SELECT NewOrder.OrderID, Products.ProductID,
		c.value('UnitPrice[1]', 'money') as UnitPrice, 
		c.value('Quantity[1]', 'int') as Quantity, 
		c.value('Discount[1]', 'real') as Discount
FROM @x.nodes('Orders/Product') as T(C)
	JOIN Products ON Products.ProductName = c.value('ProductName[1]', 'nvarchar(100)')
	JOIN Shippers ON Shippers.CompanyName =  c.value('ShippersName[1]', 'nvarchar(100)')
	JOIN Customers ON Customers.CompanyName = c.value('CompanyName[1]', 'nvarchar(100)')
	JOIN @NewOrder NewOrder ON NewOrder.CustomerID = Customers.CustomerID

SET STATISTICS TIME OFF

/****************************  Verify then archive ***************************************
	SELECT Products.ProductName, 
			Customers.CompanyName, 
			Shippers.CompanyName AS ShippersName, 
			convert(varchar(20),GETDATE(),101) as OrderDate, 
		   [Order Details].UnitPrice, 
		   [Order Details].Quantity, 
		   CAST([Order Details].Discount as varchar(9)) as Discount
	FROM  Products INNER JOIN
		   [Order Details] ON Products.ProductID = [Order Details].ProductID INNER JOIN
		   Orders ON [Order Details].OrderID = Orders.OrderID INNER JOIN
		   Customers ON Orders.CustomerID = Customers.CustomerID INNER JOIN
		   Shippers ON Orders.ShipVia = Shippers.ShipperID
	WHERE  Orders.OrderDate >= convert(varchar(20),GETDATE(),101)
	
	DELETE [Order Details]
		OUTPUT deleted.*,GETDATE() INTO Archive_OrderDetails
	FROM [Order Details] JOIN Orders ON [Order Details].OrderID = Orders.OrderID
	WHERE  Orders.OrderDate >= convert(varchar(20),GETDATE(),101)
	
	DELETE Orders
		OUTPUT deleted.*, GETDATE() INTO [Archive_Orders]
	FROM Orders WHERE  Orders.OrderDate >= convert(varchar(20),GETDATE(),101)
	
	SELECT * FROM Archive_OrderDetails
	SELECT * FROM Archive_Orders
	

	TRUNCATE TABLE Archive_OrderDetails
	TRUNCATE TABLE Archive_Orders
		
*/

/************************************************ Archive using OUTPUT Clause *******************************************************************/		

DECLARE @PhoneBook TABLE (
	tID int identity(1,1),
	PhoneNumber varchar (30),
	FirstName varchar (30),
	LastName varchar (30),
	Company varchar (100)
)

DECLARE @OUT TABLE (
	tID int,
	PhoneNumber varchar (30),
	FirstName varchar (30),
	LastName varchar (30),
	Company varchar (100),
	cAction VARCHAR(20)
)

INSERT @PhoneBook 
	OUTPUT INSERTED.*, 'INSERT' INTO @OUT
SELECT '215 902-2345','Sam','Long','SM Soft Inc.'
UNION 
SELECT '215 905-8766','John','Smith','Company LLC'
UNION
SELECT '215 909-4563','Joe','Garner','IT United Inc.'

UPDATE P
	SET FIRSTNAME = 'Samuel'
	OUTPUT INSERTED.*, 'UPDATE' INTO @OUT
FROM @PhoneBook P WHERE FIRSTNAME = 'SAM'

DELETE @PhoneBook
	OUTPUT DELETED.*, 'DELETE' INTO @OUT
FROM @PhoneBook WHERE FIRSTNAME = 'Samuel'

SELECT * FROM  @OUT

GO		




/************************************************ Get newly generated GIUD using OUTPUT Clause *******************************************************************/		


DECLARE @PhoneBook TABLE (
	tID uniqueidentifier default NEWSEQUENTIALID() PRIMARY KEY CLUSTERED,
	PhoneNumber varchar (30),
	FirstName varchar (30),
	LastName varchar (30),
	Company varchar (100)
)		

DECLARE @OUT TABLE (
	tID uniqueidentifier,
	PhoneNumber varchar (30),
	FirstName varchar (30),
	LastName varchar (30),
	Company varchar (100),
	cAction VARCHAR(20)
)

INSERT @PhoneBook (	PhoneNumber, FirstName, LastName, Company)
	OUTPUT INSERTED.*, 'INSERT' INTO @OUT
SELECT '215 902-2345','Sam','Long','SM Soft Inc.'
UNION ALL
SELECT '215 905-8766','John','Smith','Company LLC'
UNION ALL
SELECT '215 909-4563','Joe','Garner','IT United Inc.'

SELECT * FROM @OUT



/****************************** One in a group ****************************************/
DECLARE @PhoneBook TABLE (
	tID int identity(1,1),
	PhoneNumber varchar (30),
	FirstName varchar (30),
	LastName varchar (30),
	Company varchar (100)
)

INSERT @PhoneBook SELECT '215 902-2345','Sam','Long','SM Soft Inc.'
INSERT @PhoneBook SELECT '215 905-8766','John','Smith','Company LLC'
INSERT @PhoneBook SELECT '215 909-4563','Joe','Garner','IT United Inc.'
-- Duplicate insert 1
INSERT @PhoneBook SELECT '215 902-2345','Sam','Long','SM Soft Inc.'
INSERT @PhoneBook SELECT '215 905-8766','John','Smith','Company LLC'
INSERT @PhoneBook SELECT '215 909-4563','Joe','Garner','IT United Inc.'
-- Duplicate insert 2
INSERT @PhoneBook SELECT '215 902-2345','Sam','Long','SM Soft Inc.'
INSERT @PhoneBook SELECT '215 905-8766','John','Smith','Company LLC'
INSERT @PhoneBook SELECT '215 909-4563','Joe','Garner','IT United Inc.'
-- Duplicate insert 3
INSERT @PhoneBook SELECT '215 902-2345','Sam','Long','SM Soft Inc.'
INSERT @PhoneBook SELECT '215 902-2345','Sam','Long','SM Soft Inc.'
INSERT @PhoneBook SELECT '215 902-2345','Sam','Long','SM Soft Inc.'
-- Duplicate insert 4
INSERT @PhoneBook SELECT '215 905-8766','John','Smith','Company LLC'
INSERT @PhoneBook SELECT '215 905-8766','John','Smith','Company LLC'
INSERT @PhoneBook SELECT '215 905-8766','John','Smith','Company LLC'
-- Duplicate insert 5
INSERT @PhoneBook SELECT '215 909-4563','Joe','Garner','IT United Inc.'
INSERT @PhoneBook SELECT '215 909-4563','Joe','Garner','IT United Inc.'
INSERT @PhoneBook SELECT '215 909-4563','Joe','Garner','IT United Inc.';

-- Rankig function
;WITH CTE_Rank AS
(
	select ROW_NUMBER() over(partition by PhoneNumber, FirstName, LastName order by  tID) as RN, tID, PhoneNumber, FirstName,	LastName
	from @PhoneBook
)
select *
from CTE_Rank
where RN = 1
