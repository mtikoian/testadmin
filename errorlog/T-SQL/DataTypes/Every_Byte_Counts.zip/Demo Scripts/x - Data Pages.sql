/*-------------------------------------------------------------------
-- 2 - Exploring Data Pages
-- 
-- Written By: Andy Yun
-- Created On: 2014-03-17
-------------------------------------------------------------------*/
USE EveryByteCounts;
GO

-----
-- DMV Query: sys.dm_db_index_physical_stats
SELECT 
	OBJECT_NAME(object_id) AS TblName,
	index_type_desc, 
	record_count, 
	page_count, avg_page_space_used_in_percent, 
	min_record_size_in_bytes,max_record_size_in_bytes, avg_record_size_in_bytes
FROM sys.dm_db_index_physical_stats (
	DB_ID('EveryByteCounts'),			-- database_id
	OBJECT_ID(N'Employee_Large'),	-- object_id
	NULL,						-- index_id
	NULL,						-- partition_number
	'DETAILED'					-- mode: DEFAULT, NULL, LIMITED, SAMPLED, DETAILED
)
WHERE index_level = 0	-- Only show Leaf Level
	AND alloc_unit_type_desc = 'IN_ROW_DATA';
GO

SELECT 
	OBJECT_NAME(object_id) AS TblName,
	index_type_desc, 
	record_count, 
	page_count, avg_page_space_used_in_percent, 
	min_record_size_in_bytes,max_record_size_in_bytes, avg_record_size_in_bytes
FROM sys.dm_db_index_physical_stats (
	DB_ID('EveryByteCounts'),			-- database_id
	OBJECT_ID(N'Employee_Narrow'),	-- object_id
	NULL,						-- index_id
	NULL,						-- partition_number
	'DETAILED'					-- mode: DEFAULT, NULL, LIMITED, SAMPLED, DETAILED
)
WHERE index_level = 0	-- Only show Leaf Level
	AND alloc_unit_type_desc = 'IN_ROW_DATA';
GO

-----
-- Using STATISTICS IO
SET STATISTICS IO ON;
GO

-- Let's query a small set of data
SELECT TOP 100 *
FROM dbo.Employee_Large
ORDER BY EmployeeID;

SELECT TOP 100 *
FROM dbo.Employee_Narrow
ORDER BY EmployeeID;
GO


-- Let's query a larger set of data
SELECT TOP 50000 * 
FROM dbo.Employee_Large
ORDER BY EmployeeID;

SELECT TOP 50000 *
FROM dbo.Employee_Narrow
ORDER BY EmployeeID;
GO


-- Let's only query a handful of columns
SELECT TOP 50000 FirstName, LastName
FROM dbo.Employee_Large

SELECT TOP 50000 FirstName, LastName
FROM dbo.Employee_Narrow
GO

