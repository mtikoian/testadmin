DECLARE @MyIntVariable tinyint = 10
DECLARE @MyCharVariable char(2) = '25'

--Implicit Conversion
SELECT @MyIntVariable + @MyCharVariable

--Converting Error
SELECT 'This is text: ' + @MyIntVariable

--Explicit Convert using CAST function
SELECT 'This is text: ' + CAST(@MyIntVariable as char(3))

--Explicit Convert using CONVERT function
SELECT 'This is text: ' + CONVERT(char(3), @MyIntVariable)