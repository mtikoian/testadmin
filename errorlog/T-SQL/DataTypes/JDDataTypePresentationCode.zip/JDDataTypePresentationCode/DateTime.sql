--Incorrect way of using dates.
DECLARE @dtVar1 as DATETIME
SET @dtVar1 = 2-16-2012
SELECT @dtVar1
GO

--Only using partial dates or times (Using DateTime)
DECLARE @dtVar1 AS DATETIME
DECLARE @dtVar2 AS DATETIME
SET @dtVar1 = '02/16/2012'
SET @dtVar2 = '13:30:00'
SELECT @dtVar1 AS 'Date'
SELECT @dtVar2 AS 'Time'
GO

--Only using partial dates or times
DECLARE @dtVar1 AS DATE
DECLARE @dtVar2 AS TIME
SET @dtVar1 = '02/16/2012'
SET @dtVar2 = '13:30:00'
SELECT @dtVar1 AS 'Date'
SELECT @dtVar2 AS 'Time'
SELECT FORMAT(@dtVar1,'yy/MM/dd')
SELECT FORMAT(@dtVar2,'HH:mm:ss')
GO

--Formating Dates and Times (Time must be DATETIME)
DECLARE @dtVar1 AS DATE
DECLARE @dtVar2 AS TIME
SET @dtVar1 = '02/16/2012'
SET @dtVar2 = '13:30:00'
SELECT FORMAT(@dtVar1,'MM/dd//yy')
SELECT FORMAT(@dtVar2,'HH:mm:ss')
GO












