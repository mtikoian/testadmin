DECLARE @String1 AS char(10)
DECLARE @String2 AS varchar(10)

SET @String1 = 'Hello'
SET @String2 = 'World'

SELECT @String1 + @String2 --Concatenation
SELECT LEN(@String1), LEN(@String2) -- How many characters per string.
SELECT DATALENGTH(@String1), DATALENGTH(@String2) -- How many bytes per string
