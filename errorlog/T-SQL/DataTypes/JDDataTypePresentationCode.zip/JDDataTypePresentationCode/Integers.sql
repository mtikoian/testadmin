--Tiny Integer Example
DECLARE @tinyint1 as tinyint = 0
DECLARE @tinyint2 as tinyint = 255
SELECT @tinyint1 as LowValue,
	@tinyint2 as HighValue,
	DataLength(@tinyint1) as Bytes


--Small Integer Example
DECLARE @smallint1 as smallint = -32678
DECLARE @smallint2 as smallint = 32767
SELECT @smallint1 as LowValue,
	@smallint2 as HighValue,
	DataLength(@smallint1) as Bytes


--Integer Example
DECLARE @integer1 as int = -2147483648
DECLARE @integer2 as int = 2147483647
SELECT @integer1 as LowValue,
	@integer2 as HighValue,
	DataLength(@integer1) as Bytes


--Big Integer Example
DECLARE @bigint1 as bigint = -9223372036854775808
DECLARE @bigint2 as bigint = 9223372036854775807
SELECT @bigint1 as LowValue,
	@bigint2 as HighValue,
	DataLength(@bigint1) as Bytes
