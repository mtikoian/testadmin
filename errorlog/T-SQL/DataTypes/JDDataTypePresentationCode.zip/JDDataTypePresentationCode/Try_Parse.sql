--Parse can convert character to Dates or Money
SELECT PARSE('7 February 2015 3:30pm' as datetime2 USING 'en-US') AS Result
SELECT PARSE('$85.22' as money USING 'en-US') as Result

--If PARSE cannot convert it will give and ERROR
SELECT PARSE('20 dollars' as money USING 'en-US') as Result

--The Try_Parse and Try_Convert Functions will return NULL if an Error
SELECT TRY_PARSE('20 dollars' as money USING 'en-US') as Result

SELECT 
	CASE WHEN TRY_CONVERT(int,'test') IS NULL
	THEN 'Convert Failed'
	ELSE 'Convert Succeeded'
	END AS Result