USE [SQLSaturday244]
GO
/****** Object:  StoredProcedure [dbo].[13a_Warp_in_Autobots]    Script Date: 09/16/2013 09:59:51 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE procedure [dbo].[13a_Warp_in_Autobots]
as

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Optimus]') AND type in (N'U'))
BEGIN
	DROP TABLE [dbo].[Optimus]
END

CREATE TABLE [dbo].[Optimus](
	[OptimusID] [int] IDENTITY(1,1) NOT NULL,
	[TACFAC] [varchar](8) NOT NULL,
	[EDGE] [bit] NOT NULL,
	[WAP_VER] [varchar](20) NOT NULL,
	[CAMERA] [bit] NOT NULL,
	[CAMERA_MP] [decimal](18, 2) NULL,
	[OPERATING_SYSTEM] [varchar](30) NOT NULL,
	[SMARTPHONE] [bit] NOT NULL,
	[WCDMA_FDD] [bit] NOT NULL,
	[WCDMA_FDD_BAND1] [bit] NOT NULL,
	[WCDMA_FDD_BAND3] [bit] NOT NULL,
	[WCDMA_FDD_BAND7] [bit] NOT NULL,
	[WCDMA_FDD_BAND8] [bit] NOT NULL,
	[LTE_FDD] [bit] NOT NULL,
	[LTE_FDD_BAND1] [bit] NOT NULL,
	[LTE_FDD_BAND3] [bit] NOT NULL,
	[LTE_FDD_BAND7] [bit] NOT NULL,
	[LTE_FDD_BAND8] [bit] NOT NULL,
	[LTE_FDD_BAND20] [bit] NOT NULL,
	[LTE_TDD] [bit] NOT NULL,
	[LTE_TDD_BAND34] [bit] NOT NULL,
	[LTE_TDD_BAND38] [bit] NOT NULL,
	[LTE_TDD_BAND40] [bit] NOT NULL,
	[WCDMA_AMR_WB] [bit] NOT NULL,
	[DEVICE] [varchar](20) NOT NULL,
	[MAKE] [varchar](40) NOT NULL,
	[MODEL] [varchar](40) NOT NULL,
	[WAP] [bit] NOT NULL,
	[GPRS] [bit] NOT NULL,
	[GSM850] [bit] NOT NULL,
	[GSM900] [bit] NOT NULL,
	[GSM1800] [bit] NOT NULL,
	[PCS1900] [bit] NOT NULL,
	[SATELITE] [bit] NOT NULL,
	[BLUETOOTH] [bit] NOT NULL
) ON [PRIMARY]

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[Rodimus_GUID]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[Rodimus_GUID] DROP CONSTRAINT [DF_Rodimus]
END

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Rodimus_GUID]') AND type in (N'U'))
Begin
	DROP TABLE [dbo].[Rodimus_GUID]
END

CREATE TABLE [dbo].[Rodimus_GUID](
	[RodimusID] [uniqueidentifier] NOT NULL,
	[TACFAC] [varchar](8) NOT NULL,
	[EDGE] [bit] NOT NULL,
	[WAP_VER] [varchar](20) NOT NULL,
	[CAMERA] [bit] NOT NULL,
	[CAMERA_MP] [decimal](18, 2) NULL,
	[OPERATING_SYSTEM] [varchar](30) NOT NULL,
	[SMARTPHONE] [bit] NOT NULL,
	[WCDMA_FDD] [bit] NOT NULL,
	[WCDMA_FDD_BAND1] [bit] NOT NULL,
	[WCDMA_FDD_BAND3] [bit] NOT NULL,
	[WCDMA_FDD_BAND7] [bit] NOT NULL,
	[WCDMA_FDD_BAND8] [bit] NOT NULL,
	[LTE_FDD] [bit] NOT NULL,
	[LTE_FDD_BAND1] [bit] NOT NULL,
	[LTE_FDD_BAND3] [bit] NOT NULL,
	[LTE_FDD_BAND7] [bit] NOT NULL,
	[LTE_FDD_BAND8] [bit] NOT NULL,
	[LTE_FDD_BAND20] [bit] NOT NULL,
	[LTE_TDD] [bit] NOT NULL,
	[LTE_TDD_BAND34] [bit] NOT NULL,
	[LTE_TDD_BAND38] [bit] NOT NULL,
	[LTE_TDD_BAND40] [bit] NOT NULL,
	[WCDMA_AMR_WB] [bit] NOT NULL,
	[DEVICE] [varchar](20) NOT NULL,
	[MAKE] [varchar](40) NOT NULL,
	[MODEL] [varchar](40) NOT NULL,
	[WAP] [bit] NOT NULL,
	[GPRS] [bit] NOT NULL,
	[GSM850] [bit] NOT NULL,
	[GSM900] [bit] NOT NULL,
	[GSM1800] [bit] NOT NULL,
	[PCS1900] [bit] NOT NULL,
	[SATELITE] [bit] NOT NULL,
	[BLUETOOTH] [bit] NOT NULL
) ON [PRIMARY]

ALTER TABLE [dbo].[Rodimus_GUID] ADD  CONSTRAINT [DF_Rodimus]  DEFAULT (newid()) FOR [RodimusID]
GO
