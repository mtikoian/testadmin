USE [SQLSaturday244]
GO
/****** Object:  StoredProcedure [dbo].[13b_Warp_in_Deceptacons]    Script Date: 09/16/2013 09:59:51 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE procedure [dbo].[13b_Warp_in_Deceptacons]
as
If exists (Select top 1 * from sys.sysobjects where id = OBJECT_ID('StarScream_Char'))
Begin
	DROP TABLE [dbo].[StarScream_Char]
END
CREATE TABLE [dbo].[StarScream_Char](
	[TACFAC] [char](8) NOT NULL,
	[EDGE] [char](1) NULL,
	[WAP_VER] [char](20) NULL,
	[CAMERA] [char](1) NULL,
	[CAMERA_MP] [char](5) NULL,
	[OPERATING_SYSTEM] [char](30) NULL,
	[SMARTPHONE] [char](1) NULL,
	[WCDMA_FDD] [char](1) NULL,
	[WCDMA_FDD_BAND1] [char](1) NULL,
	[WCDMA_FDD_BAND3] [char](1) NULL,
	[WCDMA_FDD_BAND7] [char](1) NULL,
	[WCDMA_FDD_BAND8] [char](1) NULL,
	[LTE_FDD] [char](1) NULL,
	[LTE_FDD_BAND1] [char](1) NULL,
	[LTE_FDD_BAND3] [char](1) NULL,
	[LTE_FDD_BAND7] [char](1) NULL,
	[LTE_FDD_BAND8] [char](1) NULL,
	[LTE_FDD_BAND20] [char](1) NULL,
	[LTE_TDD] [char](1) NULL,
	[LTE_TDD_BAND34] [char](1) NULL,
	[LTE_TDD_BAND38] [char](1) NULL,
	[LTE_TDD_BAND40] [char](1) NULL,
	[WCDMA_AMR_WB] [char](1) NULL,
	[DEVICE] [char](20) NOT NULL,
	[MAKE] [char](40) NOT NULL,
	[MODEL] [char](40) NOT NULL,
	[WAP] [char](1) NULL,
	[GPRS] [char](1) NULL,
	[GSM850] [char](1) NULL,
	[GSM900] [char](1) NULL,
	[GSM1800] [char](1) NULL,
	[PCS1900] [char](1) NULL,
	[SATELITE] [char](1) NULL,
	[BLUETOOTH] [char](1) NULL
) ON [PRIMARY]


If exists (Select top 1 * from sys.sysobjects where id = OBJECT_ID('Soundwave_Vchar'))
Begin
	DROP TABLE [dbo].[Soundwave_Vchar]
END
CREATE TABLE [dbo].[Soundwave_Vchar](
	[TACFAC] [varchar](8) NOT NULL,
	[EDGE] [varchar](1) NULL,
	[WAP_VER] [varchar](20) NULL,
	[CAMERA] [varchar](1) NULL,
	[CAMERA_MP] [varchar](5) NULL,
	[OPERATING_SYSTEM] [varchar](30) NULL,
	[SMARTPHONE] [varchar](1) NULL,
	[WCDMA_FDD] [varchar](1) NULL,
	[WCDMA_FDD_BAND1] [varchar](1) NULL,
	[WCDMA_FDD_BAND3] [varchar](1) NULL,
	[WCDMA_FDD_BAND7] [varchar](1) NULL,
	[WCDMA_FDD_BAND8] [varchar](1) NULL,
	[LTE_FDD] [varchar](1) NULL,
	[LTE_FDD_BAND1] [varchar](1) NULL,
	[LTE_FDD_BAND3] [varchar](1) NULL,
	[LTE_FDD_BAND7] [varchar](1) NULL,
	[LTE_FDD_BAND8] [varchar](1) NULL,
	[LTE_FDD_BAND20] [varchar](1) NULL,
	[LTE_TDD] [varchar](1) NULL,
	[LTE_TDD_BAND34] [varchar](1) NULL,
	[LTE_TDD_BAND38] [varchar](1) NULL,
	[LTE_TDD_BAND40] [varchar](1) NULL,
	[WCDMA_AMR_WB] [varchar](1) NULL,
	[DEVICE] [varchar](20) NOT NULL,
	[MAKE] [varchar](40) NOT NULL,
	[MODEL] [varchar](40) NOT NULL,
	[WAP] [varchar](1) NULL,
	[GPRS] [varchar](1) NULL,
	[GSM850] [varchar](1) NULL,
	[GSM900] [varchar](1) NULL,
	[GSM1800] [varchar](1) NULL,
	[PCS1900] [varchar](1) NULL,
	[SATELITE] [varchar](1) NULL,
	[BLUETOOTH] [varchar](1) NULL
) ON [PRIMARY]

If exists (Select top 1 * from sys.sysobjects where id = OBJECT_ID('Shockwave_nVchar'))
Begin
	DROP TABLE [dbo].[Shockwave_nVchar]
END
CREATE TABLE [dbo].[Shockwave_nVchar](
	[TACFAC] [nvarchar](8) NOT NULL,
	[EDGE] [nvarchar](1) NULL,
	[WAP_VER] [nvarchar](20) NULL,
	[CAMERA] [nvarchar](1) NULL,
	[CAMERA_MP] [nvarchar](5) NULL,
	[OPERATING_SYSTEM] [nvarchar](30) NULL,
	[SMARTPHONE] [nvarchar](1) NULL,
	[WCDMA_FDD] [nvarchar](1) NULL,
	[WCDMA_FDD_BAND1] [nvarchar](1) NULL,
	[WCDMA_FDD_BAND3] [nvarchar](1) NULL,
	[WCDMA_FDD_BAND7] [nvarchar](1) NULL,
	[WCDMA_FDD_BAND8] [nvarchar](1) NULL,
	[LTE_FDD] [nvarchar](1) NULL,
	[LTE_FDD_BAND1] [nvarchar](1) NULL,
	[LTE_FDD_BAND3] [nvarchar](1) NULL,
	[LTE_FDD_BAND7] [nvarchar](1) NULL,
	[LTE_FDD_BAND8] [nvarchar](1) NULL,
	[LTE_FDD_BAND20] [nvarchar](1) NULL,
	[LTE_TDD] [nvarchar](1) NULL,
	[LTE_TDD_BAND34] [nvarchar](1) NULL,
	[LTE_TDD_BAND38] [nvarchar](1) NULL,
	[LTE_TDD_BAND40] [nvarchar](1) NULL,
	[WCDMA_AMR_WB] [nvarchar](1) NULL,
	[DEVICE] [nvarchar](20) NOT NULL,
	[MAKE] [nvarchar](40) NOT NULL,
	[MODEL] [nvarchar](40) NOT NULL,
	[WAP] [nvarchar](1) NULL,
	[GPRS] [nvarchar](1) NULL,
	[GSM850] [nvarchar](1) NULL,
	[GSM900] [nvarchar](1) NULL,
	[GSM1800] [nvarchar](1) NULL,
	[PCS1900] [nvarchar](1) NULL,
	[SATELITE] [nvarchar](1) NULL,
	[BLUETOOTH] [nvarchar](1) NULL
) ON [PRIMARY]


If exists (Select top 1 * from sys.sysobjects where id = OBJECT_ID('RatBat_Bits'))
Begin
	DROP TABLE [dbo].[RatBat_Bits]
END
CREATE TABLE [dbo].[RatBat_Bits](
	[TACFAC] [varchar](8) NOT NULL,
	[EDGE] [bit] NOT NULL,
	[WAP_VER] [varchar](20) NOT NULL,
	[CAMERA] [bit] NOT NULL,
	[CAMERA_MP] [decimal](18, 2) NULL,
	[OPERATING_SYSTEM] [varchar](30) NOT NULL,
	[SMARTPHONE] [bit] NOT NULL,
	[WCDMA_FDD] [bit] NOT NULL,
	[WCDMA_FDD_BAND1] [bit] NOT NULL,
	[WCDMA_FDD_BAND3] [bit] NOT NULL,
	[WCDMA_FDD_BAND7] [bit] NOT NULL,
	[WCDMA_FDD_BAND8] [bit] NOT NULL,
	[LTE_FDD] [bit] NOT NULL,
	[LTE_FDD_BAND1] [bit] NOT NULL,
	[LTE_FDD_BAND3] [bit] NOT NULL,
	[LTE_FDD_BAND7] [bit] NOT NULL,
	[LTE_FDD_BAND8] [bit] NOT NULL,
	[LTE_FDD_BAND20] [bit] NOT NULL,
	[LTE_TDD] [bit] NOT NULL,
	[LTE_TDD_BAND34] [bit] NOT NULL,
	[LTE_TDD_BAND38] [bit] NOT NULL,
	[LTE_TDD_BAND40] [bit] NOT NULL,
	[WCDMA_AMR_WB] [bit] NOT NULL,
	[DEVICE] [varchar](20) NOT NULL,
	[MAKE] [varchar](40) NOT NULL,
	[MODEL] [varchar](40) NOT NULL,
	[WAP] [bit] NOT NULL,
	[GPRS] [bit] NOT NULL,
	[GSM850] [bit] NOT NULL,
	[GSM900] [bit] NOT NULL,
	[GSM1800] [bit] NOT NULL,
	[PCS1900] [bit] NOT NULL,
	[SATELITE] [bit] NOT NULL,
	[BLUETOOTH] [bit] NOT NULL
) ON [PRIMARY]

If exists (Select top 1 * from sys.sysobjects where id = OBJECT_ID('Megatron_nChar'))
Begin
	DROP TABLE [dbo].[Megatron_nChar]
END
CREATE TABLE [dbo].[Megatron_nChar](
	[TACFAC] [nchar](8) NOT NULL,
	[EDGE] [nchar](1) NULL,
	[WAP_VER] [nchar](20) NULL,
	[CAMERA] [nchar](1) NULL,
	[CAMERA_MP] [nchar](5) NULL,
	[OPERATING_SYSTEM] [nchar](30) NULL,
	[SMARTPHONE] [nchar](1) NULL,
	[WCDMA_FDD] [nchar](1) NULL,
	[WCDMA_FDD_BAND1] [nchar](1) NULL,
	[WCDMA_FDD_BAND3] [nchar](1) NULL,
	[WCDMA_FDD_BAND7] [nchar](1) NULL,
	[WCDMA_FDD_BAND8] [nchar](1) NULL,
	[LTE_FDD] [nchar](1) NULL,
	[LTE_FDD_BAND1] [nchar](1) NULL,
	[LTE_FDD_BAND3] [nchar](1) NULL,
	[LTE_FDD_BAND7] [nchar](1) NULL,
	[LTE_FDD_BAND8] [nchar](1) NULL,
	[LTE_FDD_BAND20] [nchar](1) NULL,
	[LTE_TDD] [nchar](1) NULL,
	[LTE_TDD_BAND34] [nchar](1) NULL,
	[LTE_TDD_BAND38] [nchar](1) NULL,
	[LTE_TDD_BAND40] [nchar](1) NULL,
	[WCDMA_AMR_WB] [nchar](1) NULL,
	[DEVICE] [nchar](20) NOT NULL,
	[MAKE] [nchar](40) NOT NULL,
	[MODEL] [nchar](40) NOT NULL,
	[WAP] [nchar](1) NULL,
	[GPRS] [nchar](1) NULL,
	[GSM850] [nchar](1) NULL,
	[GSM900] [nchar](1) NULL,
	[GSM1800] [nchar](1) NULL,
	[PCS1900] [nchar](1) NULL,
	[SATELITE] [nchar](1) NULL,
	[BLUETOOTH] [nchar](1) NULL
) ON [PRIMARY]
GO
