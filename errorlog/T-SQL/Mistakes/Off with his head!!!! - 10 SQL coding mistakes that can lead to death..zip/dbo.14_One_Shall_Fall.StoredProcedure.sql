USE [SQLSaturday244]
GO
/****** Object:  StoredProcedure [dbo].[14_One_Shall_Fall]    Script Date: 09/16/2013 09:59:51 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE procedure [dbo].[14_One_Shall_Fall]
as

/*
ALTER FUNCTION DBO.udf_WhatTHE
(@Make AS Varchar(30))
RETURNS INT
AS
BEGIN
	Declare @maxID varchar(20)
	SELECT @maxID = max(optimusid) FROM Optimus WHERE make = @make and device = 'handset'
	RETURN @maxID
END	
	;

CREATE FUNCTION DBO.udf_FunctionsAreEvil
(@partID AS int)
RETURNS varchar(30)
AS
BEGIN
	Declare @Make varchar(20)
	SELECT @make = make FROM Optimus WHERE OptimusID = @partID
	RETURN @make
END	
	;
	
alter procedure SpaceBridge
@make varchar(30)
as
SELECT max(OptimusID) FROM Optimus WHERE make = @make
*/

set statistics IO on
set statistics time off

--give every query a fair chance
dbcc freeproccache
dbcc dropcleanbuffers

----------------------------------------------------------------------------------------------------------------
--THIS IS WHAT WE WILL BE ASKING
dbcc freeproccache
dbcc dropcleanbuffers
Select MAX(optimusid)
from Optimus qry
where MAKE = 'Apple'
  and DEVICE = 'handset'

--A PROC
dbcc freeproccache
dbcc dropcleanbuffers
Execute dbo.SpaceBridge 'Apple'

--HERE IS THE FUNTION
dbcc freeproccache
dbcc dropcleanbuffers
select DBO.udf_WhatTHE('APPLE')

--WHERE IS THE REST of the IO STATS? ---WEIRD

----------------------------------------------------------------------------------------------------------------
--give every query a fair chance
dbcc freeproccache
dbcc dropcleanbuffers
  
--THIS IS WHAT WE WILL BE ASKING
Select top 100 (select make from Optimus where OptimusID = qry.optimusid) as make
from Optimus qry
where MAKE = 'Apple'
  and DEVICE = 'handset'

--HERE IS THE FUNTION
--Declare @partid int = 43330879
dbcc freeproccache
dbcc dropcleanbuffers
select DBO.udf_FunctionsAreEvil(OptimusID)
from Optimus
where MAKE = 'Apple'
  and DEVICE = 'handset'

--WHERE IS THE REST of the IO STATS? ---WEIRD

----------------------------------------------------------------------------------------------------------------
GO
