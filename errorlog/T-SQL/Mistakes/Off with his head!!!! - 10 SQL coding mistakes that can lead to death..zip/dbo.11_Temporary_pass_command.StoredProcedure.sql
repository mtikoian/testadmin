USE [SQLSaturday244]
GO
/****** Object:  StoredProcedure [dbo].[11_Temporary_pass_command]    Script Date: 09/16/2013 09:59:51 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE procedure [dbo].[11_Temporary_pass_command]
as

select *
into #bumblebee
from Optimus
where MAKE = 'Nokia'

--give every query a fair chance
dbcc freeproccache
dbcc dropcleanbuffers

set statistics IO on
set statistics time on

begin transaction
Update o
set smartphone = 0
from  Optimus o
inner join #bumblebee b on b.OptimusID = o.OptimusID
rollback

Create nonclustered index ix_bumblebee
on #bumblebee(OptimusID)


drop table #bumblebee
/*

VS.

*/
--Part 2
select *
into #Rachet
from Optimus

--give every query a fair chance
dbcc freeproccache
dbcc dropcleanbuffers

begin transaction
update #Rachet
set camera_mp = 0
where MAKE = 'Nokia'

rollback

Create nonclustered index ix_Rachet_make
on #Rachet(Make)

drop table #Rachet

/* 

VS.

*/
-------------------------------------------------------------------
--THE MAGIC TABLE
--give every query a fair chance
dbcc freeproccache
dbcc dropcleanbuffers
declare @OrionPax as Table
([OptimusID] [int] NOT NULL  PRIMARY KEY ,	[TACFAC] [varchar](8) NOT NULL,	[EDGE] [bit] NOT NULL,	[WAP_VER] [varchar](20) NOT NULL,	[CAMERA] [bit] NOT NULL,	[CAMERA_MP] [decimal](18, 2) NULL,
	[OPERATING_SYSTEM] [varchar](30) NOT NULL,	[SMARTPHONE] [bit] NOT NULL,	[WCDMA_FDD] [bit] NOT NULL,	[WCDMA_FDD_BAND1] [bit] NOT NULL,	[WCDMA_FDD_BAND3] [bit] NOT NULL,	[WCDMA_FDD_BAND7] [bit] NOT NULL,
	[WCDMA_FDD_BAND8] [bit] NOT NULL,	[LTE_FDD] [bit] NOT NULL,	[LTE_FDD_BAND1] [bit] NOT NULL,	[LTE_FDD_BAND3] [bit] NOT NULL,	[LTE_FDD_BAND7] [bit] NOT NULL,	[LTE_FDD_BAND8] [bit] NOT NULL,
	[LTE_FDD_BAND20] [bit] NOT NULL,	[LTE_TDD] [bit] NOT NULL,	[LTE_TDD_BAND34] [bit] NOT NULL,	[LTE_TDD_BAND38] [bit] NOT NULL,	[LTE_TDD_BAND40] [bit] NOT NULL,	[WCDMA_AMR_WB] [bit] NOT NULL,
	[DEVICE] [varchar](20) NOT NULL,	[MAKE] [varchar](40) NOT NULL,	[MODEL] [varchar](40) NOT NULL,	[WAP] [bit] NOT NULL,	[GPRS] [bit] NOT NULL,	[GSM850] [bit] NOT NULL,
	[GSM900] [bit] NOT NULL,	[GSM1800] [bit] NOT NULL,	[PCS1900] [bit] NOT NULL,	[SATELITE] [bit] NOT NULL,	[BLUETOOTH] [bit] NOT NULL)
	
insert into @OrionPax
select OptimusID,TACFAC,EDGE,WAP_VER,CAMERA,CAMERA_MP,OPERATING_SYSTEM,SMARTPHONE,WCDMA_FDD,WCDMA_FDD_BAND1,WCDMA_FDD_BAND3
,WCDMA_FDD_BAND7,WCDMA_FDD_BAND8,LTE_FDD,LTE_FDD_BAND1,LTE_FDD_BAND3,LTE_FDD_BAND7,LTE_FDD_BAND8,LTE_FDD_BAND20,LTE_TDD
,LTE_TDD_BAND34,LTE_TDD_BAND38,LTE_TDD_BAND40,WCDMA_AMR_WB,DEVICE,MAKE,MODEL,WAP,GPRS,GSM850,GSM900,GSM1800,PCS1900,SATELITE
,BLUETOOTH
from Optimus

update @OrionPax
set CAMERA_MP = 0
where MAKE <> 'Nokia'
/*
--Always remember the execution plan
*/

-------------------------------------------
--THE WAYS OF OLD
--give every query a fair chance
dbcc freeproccache
dbcc dropcleanbuffers

Create table #OrionPax
([OptimusID] [int] NOT NULL  PRIMARY KEY ,	[TACFAC] [varchar](8) NOT NULL,	[EDGE] [bit] NOT NULL,	[WAP_VER] [varchar](20) NOT NULL,	[CAMERA] [bit] NOT NULL,	[CAMERA_MP] [decimal](18, 2) NULL,
	[OPERATING_SYSTEM] [varchar](30) NOT NULL,	[SMARTPHONE] [bit] NOT NULL,	[WCDMA_FDD] [bit] NOT NULL,	[WCDMA_FDD_BAND1] [bit] NOT NULL,	[WCDMA_FDD_BAND3] [bit] NOT NULL,	[WCDMA_FDD_BAND7] [bit] NOT NULL,
	[WCDMA_FDD_BAND8] [bit] NOT NULL,	[LTE_FDD] [bit] NOT NULL,	[LTE_FDD_BAND1] [bit] NOT NULL,	[LTE_FDD_BAND3] [bit] NOT NULL,	[LTE_FDD_BAND7] [bit] NOT NULL,	[LTE_FDD_BAND8] [bit] NOT NULL,
	[LTE_FDD_BAND20] [bit] NOT NULL,	[LTE_TDD] [bit] NOT NULL,	[LTE_TDD_BAND34] [bit] NOT NULL,	[LTE_TDD_BAND38] [bit] NOT NULL,	[LTE_TDD_BAND40] [bit] NOT NULL,	[WCDMA_AMR_WB] [bit] NOT NULL,
	[DEVICE] [varchar](20) NOT NULL,	[MAKE] [varchar](40) NOT NULL,	[MODEL] [varchar](40) NOT NULL,	[WAP] [bit] NOT NULL,	[GPRS] [bit] NOT NULL,	[GSM850] [bit] NOT NULL,
	[GSM900] [bit] NOT NULL,	[GSM1800] [bit] NOT NULL,	[PCS1900] [bit] NOT NULL,	[SATELITE] [bit] NOT NULL,	[BLUETOOTH] [bit] NOT NULL)
	
insert into #OrionPax
select OptimusID,TACFAC,EDGE,WAP_VER,CAMERA,CAMERA_MP,OPERATING_SYSTEM,SMARTPHONE,WCDMA_FDD,WCDMA_FDD_BAND1,WCDMA_FDD_BAND3
,WCDMA_FDD_BAND7,WCDMA_FDD_BAND8,LTE_FDD,LTE_FDD_BAND1,LTE_FDD_BAND3,LTE_FDD_BAND7,LTE_FDD_BAND8,LTE_FDD_BAND20,LTE_TDD
,LTE_TDD_BAND34,LTE_TDD_BAND38,LTE_TDD_BAND40,WCDMA_AMR_WB,DEVICE,MAKE,MODEL,WAP,GPRS,GSM850,GSM900,GSM1800,PCS1900,SATELITE
,BLUETOOTH
from Optimus

update #OrionPax
set CAMERA_MP = 0
where MAKE <> 'Nokia'
/*
--Always remember the execution plan
*/

drop table #OrionPax


-----------------------------------------------------------------------------------
--LET THE MAGIC HAPPEN
--give every query a fair chance
dbcc freeproccache
dbcc dropcleanbuffers

declare @OrionPaxAgain as Table
([OptimusID] [int] NOT NULL  PRIMARY KEY ,	[TACFAC] [varchar](8) NOT NULL,	[EDGE] [bit] NOT NULL,	[WAP_VER] [varchar](20) NOT NULL,	[CAMERA] [bit] NOT NULL,	[CAMERA_MP] [decimal](18, 2) NULL,
	[OPERATING_SYSTEM] [varchar](30) NOT NULL,	[SMARTPHONE] [bit] NOT NULL,	[WCDMA_FDD] [bit] NOT NULL,	[WCDMA_FDD_BAND1] [bit] NOT NULL,	[WCDMA_FDD_BAND3] [bit] NOT NULL,	[WCDMA_FDD_BAND7] [bit] NOT NULL,
	[WCDMA_FDD_BAND8] [bit] NOT NULL,	[LTE_FDD] [bit] NOT NULL,	[LTE_FDD_BAND1] [bit] NOT NULL,	[LTE_FDD_BAND3] [bit] NOT NULL,	[LTE_FDD_BAND7] [bit] NOT NULL,	[LTE_FDD_BAND8] [bit] NOT NULL,
	[LTE_FDD_BAND20] [bit] NOT NULL,	[LTE_TDD] [bit] NOT NULL,	[LTE_TDD_BAND34] [bit] NOT NULL,	[LTE_TDD_BAND38] [bit] NOT NULL,	[LTE_TDD_BAND40] [bit] NOT NULL,	[WCDMA_AMR_WB] [bit] NOT NULL,
	[DEVICE] [varchar](20) NOT NULL,	[MAKE] [varchar](40) NOT NULL,	[MODEL] [varchar](40) NOT NULL,	[WAP] [bit] NOT NULL,	[GPRS] [bit] NOT NULL,	[GSM850] [bit] NOT NULL,
	[GSM900] [bit] NOT NULL,	[GSM1800] [bit] NOT NULL,	[PCS1900] [bit] NOT NULL,	[SATELITE] [bit] NOT NULL,	[BLUETOOTH] [bit] NOT NULL)
	
insert into @OrionPaxAgain
select OptimusID,TACFAC,EDGE,WAP_VER,CAMERA,CAMERA_MP,OPERATING_SYSTEM,SMARTPHONE,WCDMA_FDD,WCDMA_FDD_BAND1,WCDMA_FDD_BAND3
,WCDMA_FDD_BAND7,WCDMA_FDD_BAND8,LTE_FDD,LTE_FDD_BAND1,LTE_FDD_BAND3,LTE_FDD_BAND7,LTE_FDD_BAND8,LTE_FDD_BAND20,LTE_TDD
,LTE_TDD_BAND34,LTE_TDD_BAND38,LTE_TDD_BAND40,WCDMA_AMR_WB,DEVICE,MAKE,MODEL,WAP,GPRS,GSM850,GSM900,GSM1800,PCS1900,SATELITE
,BLUETOOTH
from Optimus

Begin Transaction
Update o
set smartphone = 0
from  Optimus o
inner join @OrionPaxAgain b on b.OptimusID = o.OptimusID
--rollback
-----------------------------------------------------------------
--AND THEY LIED

--give every query a fair chance
dbcc freeproccache
dbcc dropcleanbuffers

Create table #Arcee
([OptimusID] [int] NOT NULL  PRIMARY KEY ,	[TACFAC] [varchar](8) NOT NULL,	[EDGE] [bit] NOT NULL,	[WAP_VER] [varchar](20) NOT NULL,	[CAMERA] [bit] NOT NULL,	[CAMERA_MP] [decimal](18, 2) NULL,
	[OPERATING_SYSTEM] [varchar](30) NOT NULL,	[SMARTPHONE] [bit] NOT NULL,	[WCDMA_FDD] [bit] NOT NULL,	[WCDMA_FDD_BAND1] [bit] NOT NULL,	[WCDMA_FDD_BAND3] [bit] NOT NULL,	[WCDMA_FDD_BAND7] [bit] NOT NULL,
	[WCDMA_FDD_BAND8] [bit] NOT NULL,	[LTE_FDD] [bit] NOT NULL,	[LTE_FDD_BAND1] [bit] NOT NULL,	[LTE_FDD_BAND3] [bit] NOT NULL,	[LTE_FDD_BAND7] [bit] NOT NULL,	[LTE_FDD_BAND8] [bit] NOT NULL,
	[LTE_FDD_BAND20] [bit] NOT NULL,	[LTE_TDD] [bit] NOT NULL,	[LTE_TDD_BAND34] [bit] NOT NULL,	[LTE_TDD_BAND38] [bit] NOT NULL,	[LTE_TDD_BAND40] [bit] NOT NULL,	[WCDMA_AMR_WB] [bit] NOT NULL,
	[DEVICE] [varchar](20) NOT NULL,	[MAKE] [varchar](40) NOT NULL,	[MODEL] [varchar](40) NOT NULL,	[WAP] [bit] NOT NULL,	[GPRS] [bit] NOT NULL,	[GSM850] [bit] NOT NULL,
	[GSM900] [bit] NOT NULL,	[GSM1800] [bit] NOT NULL,	[PCS1900] [bit] NOT NULL,	[SATELITE] [bit] NOT NULL,	[BLUETOOTH] [bit] NOT NULL)

insert into #Arcee
select OptimusID,TACFAC,EDGE,WAP_VER,CAMERA,CAMERA_MP,OPERATING_SYSTEM,SMARTPHONE,WCDMA_FDD,WCDMA_FDD_BAND1,WCDMA_FDD_BAND3
,WCDMA_FDD_BAND7,WCDMA_FDD_BAND8,LTE_FDD,LTE_FDD_BAND1,LTE_FDD_BAND3,LTE_FDD_BAND7,LTE_FDD_BAND8,LTE_FDD_BAND20,LTE_TDD
,LTE_TDD_BAND34,LTE_TDD_BAND38,LTE_TDD_BAND40,WCDMA_AMR_WB,DEVICE,MAKE,MODEL,WAP,GPRS,GSM850,GSM900,GSM1800,PCS1900,SATELITE
,BLUETOOTH
from Optimus
where MAKE = 'Nokia'

Begin Transaction
Update o
set smartphone = 0
from  Optimus o
inner join #arcee b on b.OptimusID = o.OptimusID
--rollback
GO
