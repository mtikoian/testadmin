USE [SQLSaturday244]
GO
/****** Object:  UserDefinedFunction [dbo].[udf_FunctionsAreEvil]    Script Date: 09/16/2013 09:59:52 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE FUNCTION [dbo].[udf_FunctionsAreEvil]
(@partID AS int)
RETURNS varchar(30)
AS
BEGIN
	Declare @Make varchar(20)
	SELECT @make = make FROM Optimus WHERE OptimusID = @partID
	RETURN @make
END	
	;
GO
