USE [SQLSaturday244]
GO
/****** Object:  UserDefinedFunction [dbo].[udf_WhatTHE]    Script Date: 09/16/2013 09:59:52 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE FUNCTION [dbo].[udf_WhatTHE]
(@Make AS Varchar(30))
RETURNS INT
AS
BEGIN
	Declare @maxID varchar(20)
	SELECT @maxID = max(optimusid) FROM Optimus WHERE make = @make and device = 'handset'
	RETURN @maxID
END	
	;
GO
