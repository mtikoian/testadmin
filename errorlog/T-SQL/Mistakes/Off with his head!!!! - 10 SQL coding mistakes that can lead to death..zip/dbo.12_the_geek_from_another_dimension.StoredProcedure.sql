USE [SQLSaturday244]
GO
/****** Object:  StoredProcedure [dbo].[12_the_geek_from_another_dimension]    Script Date: 09/16/2013 09:59:51 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE procedure [dbo].[12_the_geek_from_another_dimension]
as
CREATE NONCLUSTERED INDEX [ix_optimus]
ON [dbo].[Optimus] ([MAKE])
INCLUDE ([OptimusID],[TACFAC],[EDGE],[WAP_VER],[CAMERA],[CAMERA_MP],[OPERATING_SYSTEM],[SMARTPHONE],[WCDMA_FDD],[WCDMA_FDD_BAND1],[WCDMA_FDD_BAND3],[WCDMA_FDD_BAND7],[WCDMA_FDD_BAND8],[LTE_FDD],[LTE_FDD_BAND1],[LTE_FDD_BAND3],[LTE_FDD_BAND7],[LTE_FDD_BAND8],[LTE_FDD_BAND20],[LTE_TDD],[LTE_TDD_BAND34],[LTE_TDD_BAND38],[LTE_TDD_BAND40],[WCDMA_AMR_WB],[DEVICE],[MODEL],[WAP],[GPRS],[GSM850],[GSM900],[GSM1800],[PCS1900],[SATELITE],[BLUETOOTH])


set statistics IO on
set statistics time on

--give every query a fair chance
dbcc freeproccache
dbcc dropcleanbuffers

--Luke Meets Optimus
select *
into #Luke
from Optimus
where MAKE = 'Nokia'

drop table #Luke
----------------------------------------------------------------
--give every query a fair chance
dbcc freeproccache
dbcc dropcleanbuffers

--Now use the force LUKE!
select *
into #DarthVader
from Optimus with (index = ix_Optimus_Make)
where MAKE = 'Nokia'

drop table #DarthVader


----------------------------------------------------------------
--But WAIT if you join now we will include this Merged Hashed NEsted "gemors" for free

--give every query a fair chance
dbcc freeproccache
dbcc dropcleanbuffers

Select top 1000 o.*, r.RodimusID
from Optimus o
inner join Rodimus_GUID r
on o.TACFAC = r.TACFAC


------------------------------
--give every query a fair chance
dbcc freeproccache
dbcc dropcleanbuffers

Select top 1000 o.*, r.RodimusID
from Optimus o
inner join Rodimus_GUID r
on o.TACFAC = r.TACFAC
OPTION (MERGE JOIN)


------------------------------
--give every query a fair chance
dbcc freeproccache
dbcc dropcleanbuffers

Select top 1000 o.*, r.RodimusID
from Optimus o
inner join Rodimus_GUID r
on o.TACFAC = r.TACFAC
OPTION (LOOP JOIN)
GO
