USE [SQLSaturday244]
GO
/****** Object:  StoredProcedure [dbo].[13c_Optimus_Prepare_For_WAR]    Script Date: 09/16/2013 09:59:51 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE procedure [dbo].[13c_Optimus_Prepare_For_WAR]
as
declare @i int = 1
while @i <> 10
begin
	INSERT INTO Optimus
	(TACFAC,EDGE,WAP_VER,CAMERA,CAMERA_MP,OPERATING_SYSTEM,SMARTPHONE,WCDMA_FDD,WCDMA_FDD_BAND1
	,WCDMA_FDD_BAND3,WCDMA_FDD_BAND7,WCDMA_FDD_BAND8,LTE_FDD,LTE_FDD_BAND1,LTE_FDD_BAND3,LTE_FDD_BAND7
	,LTE_FDD_BAND8,LTE_FDD_BAND20,LTE_TDD,LTE_TDD_BAND34,LTE_TDD_BAND38,LTE_TDD_BAND40,WCDMA_AMR_WB
	,DEVICE,MAKE,MODEL,WAP,GPRS,GSM850,GSM900,GSM1800,PCS1900,SATELITE,BLUETOOTH)
	SELECT
	 TACFAC
	,ISNULL(case EDGE when 'Y' Then 1 else 0 end,0) AS EDGE
	,ISNULL(case WAP_VER when 'Y' Then 1 else 0 end,0) AS WAP_VER
	,ISNULL(case CAMERA when 'Y' Then 1 else 0 end,0) AS CAMERA
	,CASE
		WHEN CAMERA_MP = 'NA' THEN NULL
		when ISNUMERIC(CAMERA_MP) = 1 THEN convert(decimal(18,2),replace(camera_mp,',','.'))
		ELSE NULL
	 END AS CAMERA_MP
	,ISNULL(OPERATING_SYSTEM,'Not Known') AS OPERATING_SYSTEM
	,ISNULL(Case SMARTPHONE when 'Y' Then 1 else 0 end,0) AS SMARTPHONE
	,ISNULL(case WCDMA_FDD when 'Y' Then 1 else 0 end,0) AS WCDMA_FDD
	,ISNULL(case WCDMA_FDD_BAND1 when 'Y' Then 1 else 0 end,0) AS WCDMA_FDD_BAND1
	,ISNULL(case WCDMA_FDD_BAND3 when 'Y' Then 1 else 0 end,0) AS WCDMA_FDD_BAND3
	,ISNULL(case WCDMA_FDD_BAND7 when 'Y' Then 1 else 0 end,0) AS WCDMA_FDD_BAND7
	,ISNULL(case WCDMA_FDD_BAND8 when 'Y' Then 1 else 0 end,0) AS WCDMA_FDD_BAND8
	,ISNULL(case LTE_FDD when 'Y' Then 1 else 0 end,0) AS LTE_FDD
	,ISNULL(case LTE_FDD_BAND1 when 'Y' Then 1 else 0 end,0) AS LTE_FDD_BAND1
	,ISNULL(case LTE_FDD_BAND3 when 'Y' Then 1 else 0 end,0) AS LTE_FDD_BAND3
	,ISNULL(case LTE_FDD_BAND7 when 'Y' Then 1 else 0 end,0) AS LTE_FDD_BAND7
	,ISNULL(case LTE_FDD_BAND8 when 'Y' Then 1 else 0 end,0) AS LTE_FDD_BAND8
	,ISNULL(case LTE_FDD_BAND20 when 'Y' Then 1 else 0 end,0) AS LTE_FDD_BAND20
	,ISNULL(case LTE_TDD when 'Y' Then 1 else 0 end,0) AS LTE_TDD
	,ISNULL(case LTE_TDD_BAND34 when 'Y' Then 1 else 0 end,0) AS LTE_TDD_BAND34
	,ISNULL(case LTE_TDD_BAND38 when 'Y' Then 1 else 0 end,0) AS LTE_TDD_BAND38
	,ISNULL(case LTE_TDD_BAND40 when 'Y' Then 1 else 0 end,0) AS LTE_TDD_BAND40
	,ISNULL(case WCDMA_AMR_WB when 'Y' Then 1 else 0 end,0) AS WCDMA_AMR_WB
	,ISNULL(DEVICE,'HANDSET') AS DEVICE
	,MAKE AS MAKE
	,ISNULL(MODEL,'UnknownModel') AS MODEL
	,ISNULL(case WAP when 'Y' Then 1 else 0 end,0) AS WAP
	,ISNULL(case GPRS when 'Y' Then 1 else 0 end,0) AS GPRS
	,ISNULL(case GSM850 when 'Y' Then 1 else 0 end,0) AS GSM850
	,ISNULL(case GSM900 when 'Y' Then 1 else 0 end,0) AS GSM900
	,ISNULL(case GSM1800 when 'Y' Then 1 else 0 end,0) AS GSM1800
	,ISNULL(case PCS1900 when 'Y' Then 1 else 0 end,0) AS PCS1900
	,ISNULL(case SATELITE when 'Y' Then 1 else 0 end,0) AS SATELITE
	,ISNULL(case BLUETOOTH when 'Y' Then 1 else 0 end,0) AS BLUETOOTH
	FROM MetroPlex
	set @i = @i+1
end

--drop index optimus.ix_Optimus_ID
--create nonclustered index ix_Optimus_ID
--on optimus(optimusID)
GO
