USE [SQLSaturday244]
GO
/****** Object:  StoredProcedure [dbo].[SpaceBridge]    Script Date: 09/16/2013 09:59:51 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE procedure [dbo].[SpaceBridge]
@make varchar(30)
as
SELECT max(OptimusID) FROM Optimus WHERE make = @make
GO
