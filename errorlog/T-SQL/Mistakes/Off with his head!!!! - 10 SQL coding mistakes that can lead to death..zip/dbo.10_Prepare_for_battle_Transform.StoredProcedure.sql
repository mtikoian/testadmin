USE [SQLSaturday244]
GO
/****** Object:  StoredProcedure [dbo].[10_Prepare_for_battle_Transform]    Script Date: 09/16/2013 09:59:51 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE procedure [dbo].[10_Prepare_for_battle_Transform]
as
Create Nonclustered index IX_RatBat_PK
on Ratbat_Bits(TACFAC, DEVICE, MAKE, MODEL)

Create Nonclustered index IX_soundwave_PK
on Soundwave_Vchar(TACFAC, DEVICE, MAKE, MODEL)

Create Nonclustered index IX_Rodimus_PK
on Rodimus_GUID(RodimusID)

Create Nonclustered index IX_Optimus_PK
on Optimus(OptimusID)
GO
