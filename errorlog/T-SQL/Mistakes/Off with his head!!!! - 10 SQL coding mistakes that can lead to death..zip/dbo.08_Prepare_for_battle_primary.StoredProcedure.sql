USE [SQLSaturday244]
GO
/****** Object:  StoredProcedure [dbo].[08_Prepare_for_battle_primary]    Script Date: 09/16/2013 09:59:51 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
Create procedure [dbo].[08_Prepare_for_battle_primary]
as
Create Nonclustered index IX_RatBat_Camera
on Ratbat_Bits(Camera)

Create Nonclustered index IX_soundwave_Camera
on Soundwave_Vchar(Camera)

Create Nonclustered index IX_Rodimus_Camera
on Rodimus_GUID(Camera)

Create Nonclustered index IX_Optimus_Camera
on Optimus(Camera)
GO
