USE [SQLSaturday244]
GO
/****** Object:  StoredProcedure [dbo].[07_DeceptaconScum]    Script Date: 09/16/2013 09:59:51 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
create procedure [dbo].[07_DeceptaconScum]
as
Drop table Megatron_nChar
drop table StarScream_Char
drop table Shockwave_nVchar
GO
