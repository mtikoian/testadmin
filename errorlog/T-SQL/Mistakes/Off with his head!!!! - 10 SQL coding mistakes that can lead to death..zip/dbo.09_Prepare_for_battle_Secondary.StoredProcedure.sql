USE [SQLSaturday244]
GO
/****** Object:  StoredProcedure [dbo].[09_Prepare_for_battle_Secondary]    Script Date: 09/16/2013 09:59:51 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
Create procedure [dbo].[09_Prepare_for_battle_Secondary]
as
Create Nonclustered index IX_RatBat_Make
on Ratbat_Bits(Make)

Create Nonclustered index IX_soundwave_Make
on Soundwave_Vchar(make)

Create Nonclustered index IX_Rodimus_Make
on Rodimus_GUID(Make)

Create Nonclustered index IX_Optimus_Make
on Optimus(Make)
GO
