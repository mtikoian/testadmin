USE [SQLSaturday244]
GO
/****** Object:  StoredProcedure [dbo].[theMission]    Script Date: 09/16/2013 09:59:51 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE procedure [dbo].[theMission]
as

/*Data Type*/
--dbo.Warp_in_Deceptacons

--dbo.Warp_in_Autobots

--dbo.MetroPlex_vs_Deceptacons

--dbo.Deceptacons_WhosIndexIsBigger

--dbo.Deceptacons_vs_Primes
-----------------------------------------------

/*Primary Keys*/
--dbo.Matrix_of_Leadership

--dbo.DeceptaconScum

--dbo.Prepare_for_battle_primary

--dbo.Prepare_for_battle_Secondary

--dbo.Prepare_for_battle_Transform

-----------------------------------------------
/*Temp tables and Variable Table*/
--dbo.Temporary_pass_command

-----------------------------------------------
/*using the Force*/
--dbo.the_geek_from_another_dimension

-----------------------------------------------
--LETS RESTART
--dbo.Warp_in_Deceptacons
--dbo.Warp_in_Autobots

--[dbo].[Optimus_Prepare_For_WAR]

-----------------------------------------------
/*Functions*/
--dbo.One_Shall_Fall
GO
