IF OBJECT_ID(N'Products', N'U') IS NOT NULL
   DROP TABLE Products;
   
CREATE TABLE Products (
 sku INT NOT NULL PRIMARY KEY,
 material_type VARCHAR(10) NOT NULL,
 product_description VARCHAR(35) NOT NULL);
 
 
INSERT INTO Products VALUES(1, 'metal', 'Bike');
INSERT INTO Products VALUES(2, 'plastic', 'Ball');
INSERT INTO Products VALUES(3, 'plastic', 'Phone'); 

IF OBJECT_ID(N'PlasticProducts', N'U') IS NOT NULL
   DROP TABLE PlasticProducts;
   
CREATE TABLE PlasticProducts ( 
 sku INT NOT NULL PRIMARY KEY,
 material_type VARCHAR(10) NOT NULL,
 product_description VARCHAR(35) NOT NULL);
 
INSERT INTO PlasticProducts
SELECT *
FROM Products
WHERE material_type = 'plastic';

ALTER TABLE Products
ADD effective_start_date DATETIME,
    effective_end_date DATETIME;

DELETE FROM PlasticProducts;
/*    
INSERT INTO PlasticProducts
SELECT *
FROM Products
WHERE material_type = 'plastic';
*/

/*

Column name or number of supplied values does not match table definition.

*/

INSERT INTO PlasticProducts (sku, product_description, material_type)
SELECT sku, product_description, material_type
FROM Products
WHERE material_type = 'plastic';

GO

CREATE VIEW MetalProducts
AS
SELECT *
FROM Products
WHERE material_type = 'metal';

GO

SELECT * 
FROM MetalProducts;

GO

ALTER TABLE Products
DROP COLUMN product_description;

GO

SELECT * 
FROM MetalProducts;

/*

View or function 'MetalProducts' has more column names specified than columns defined.

*/

GO

DROP VIEW MetalProducts;

GO

DROP TABLE Products, PlasticProducts; 