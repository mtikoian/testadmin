IF OBJECT_ID(N'Products', N'U') IS NOT NULL
   DROP TABLE Products;
   
CREATE TABLE Products (
 sku INT NOT NULL PRIMARY KEY,
 material_type VARCHAR(10) NOT NULL,
 product_description VARCHAR(35) NOT NULL);
 
INSERT INTO Products VALUES(1, 'metal', 'Bike');
INSERT INTO Products VALUES(2, 'plastic', 'Ball');
INSERT INTO Products VALUES(3, 'plastic', 'Phone');

IF OBJECT_ID(N'Sales', N'U') IS NOT NULL
   DROP TABLE Sales;

CREATE TABLE Sales (
 transaction_nbr INT NOT NULL PRIMARY KEY,
 sale_date DATETIME NOT NULL,
 sku INT NOT NULL REFERENCES Products(sku),
 sale_amount DECIMAL(15, 2) NOT NULL);

INSERT INTO Sales VALUES(1, '20090101', 1, 10.50);
INSERT INTO Sales VALUES(2, '20090102', 2, 11.50);
INSERT INTO Sales VALUES(3, '20090103', 1, 10.50);
INSERT INTO Sales VALUES(4, '20090104', 1, 10.50);
INSERT INTO Sales VALUES(5, '20090105', 3, 13.00);

GO

-- scalar function
CREATE FUNCTION dbo.GetTotalSales(@sku INT)
RETURNS DECIMAL(15, 2)
AS
BEGIN
  RETURN(SELECT SUM(sale_amount)
         FROM Sales 
         WHERE sku = @sku);
END

GO

-- query using scalar function
SELECT sku, product_description, dbo.GetTotalSales(sku) AS total_sales
FROM Products;

GO

-- direct calculation in the query
SELECT P.sku, P.product_description, SUM(S.sale_amount) As total_sales
FROM Products AS P
JOIN Sales AS S
  ON P.sku = S.sku
GROUP BY P.sku, P.product_description;
  
GO

DROP FUNCTION dbo.GetTotalSales;

GO

-- table-valued function
CREATE FUNCTION dbo.GetTotalSales(@sku INT)
RETURNS TABLE
AS
RETURN(SELECT SUM(sale_amount) AS total_sales
       FROM Sales 
       WHERE sku = @sku);
         
GO

-- query using table-valued function with CROSS APPLY
SELECT sku, product_description, total_sales
FROM Products AS P
CROSS APPLY dbo.GetTotalSales(P.sku) AS S;

GO

DROP FUNCTION dbo.GetTotalSales;

GO

DROP TABLE Sales;
DROP TABLE Products;