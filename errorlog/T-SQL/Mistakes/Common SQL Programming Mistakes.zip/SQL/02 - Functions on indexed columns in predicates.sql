IF OBJECT_ID(N'Customers', N'U') IS NOT NULL
   DROP TABLE Customers;
   
CREATE TABLE Customers (
 customer_nbr INT NOT NULL PRIMARY KEY,
 customer_name VARCHAR(35) NOT NULL);
 
CREATE NONCLUSTERED INDEX ix_customers
ON Customers(customer_name);
 
INSERT INTO Customers VALUES(1, 'Joe');
INSERT INTO Customers VALUES(2, 'Leo');
INSERT INTO Customers VALUES(3, 'Dave');

GO

SET SHOWPLAN_TEXT ON;

GO

SELECT customer_name
FROM Customers
WHERE LEFT(customer_name, 1) = 'L';

/*

StmtText
--------------------------------------------------------------------------------------------------------------------------------------------------
  |--Index Scan(OBJECT:([Testing].[dbo].[Customers].[ix_customers]),  WHERE:(substring([Testing].[dbo].[Customers].[customer_name],(1),(1))='L'))

*/

SELECT customer_name
FROM Customers
WHERE customer_name LIKE 'L%';

/*

StmtText
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  |--Index Seek(OBJECT:([Testing].[dbo].[Customers].[ix_customers]), SEEK:([Testing].[dbo].[Customers].[customer_name] >= 'K�' AND [Testing].[dbo].[Customers].[customer_name] < 'M'),  WHERE:([Testing].[dbo].[Customers].[customer_name] like 'L%') ORDERED FO

*/

GO

SET SHOWPLAN_TEXT OFF;

GO

DROP TABLE Customers;

IF OBJECT_ID(N'Sales', N'U') IS NOT NULL
   DROP TABLE Sales;

CREATE TABLE Sales (
 transaction_nbr INT NOT NULL PRIMARY KEY NONCLUSTERED,
 sale_date DATETIME NOT NULL,
 sale_amount DECIMAL(10, 2) NOT NULL);
 
CREATE CLUSTERED INDEX ix_sales
ON Sales(sale_date);
 
INSERT INTO Sales VALUES(1, '20090101', 10.50);
INSERT INTO Sales VALUES(2, '20080504', 11.25);
INSERT INTO Sales VALUES(3, '20090304', 15.50);
INSERT INTO Sales VALUES(4, '20090104', 11.50);
INSERT INTO Sales VALUES(5, '20080504', 11.25);
INSERT INTO Sales VALUES(6, '20090304', 15.50);
INSERT INTO Sales VALUES(7, '20090201', 10.50);
INSERT INTO Sales VALUES(8, '20080504', 11.25);
INSERT INTO Sales VALUES(9, '20090304', 15.50);

GO

SET SHOWPLAN_TEXT ON;

GO

SELECT SUM(sale_amount) AS total_sales
FROM Sales
WHERE DATEPART(YEAR, sale_date) = 2009
  AND DATEPART(MONTH, sale_date) = 1;

/*

StmtText
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  |--Compute Scalar(DEFINE:([Expr1004]=CASE WHEN [Expr1007]=(0) THEN NULL ELSE [Expr1008] END))
       |--Stream Aggregate(DEFINE:([Expr1007]=Count(*), [Expr1008]=SUM([Testing].[dbo].[Sales].[sale_amount])))
            |--Clustered Index Scan(OBJECT:([Testing].[dbo].[Sales].[ix_sales]), WHERE:(datepart(year,[Testing].[dbo].[Sales].[sale_date])=(2009) AND datepart(month,[Testing].[dbo].[Sales].[sale_date])=(1)))

*/

SELECT SUM(sale_amount) AS total_sales
FROM Sales
WHERE sale_date >= '20090101'
  AND sale_date <  '20090201';

/*

StmtText
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  |--Compute Scalar(DEFINE:([Expr1004]=CASE WHEN [Expr1007]=(0) THEN NULL ELSE [Expr1008] END))
       |--Stream Aggregate(DEFINE:([Expr1007]=Count(*), [Expr1008]=SUM([Testing].[dbo].[Sales].[sale_amount])))
            |--Clustered Index Seek(OBJECT:([Testing].[dbo].[Sales].[ix_sales]), SEEK:([Testing].[dbo].[Sales].[sale_date] >= CONVERT_IMPLICIT(datetime,[@1],0) AND [Testing].[dbo].[Sales].[sale_date] < CONVERT_IMPLICIT(datetime,[@2],0)) ORDERED FORWARD)

*/

/* SQL Server 2008 only */
SELECT SUM(sale_amount) AS total_sales
FROM Sales
WHERE CAST(sale_date AS DATE) = '20090101';

/*

StmtText
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  |--Compute Scalar(DEFINE:([Expr1004]=CASE WHEN [Expr1010]=(0) THEN NULL ELSE [Expr1011] END))
       |--Stream Aggregate(DEFINE:([Expr1010]=Count(*), [Expr1011]=SUM([Testing].[dbo].[Sales].[sale_amount])))
            |--Nested Loops(Inner Join, OUTER REFERENCES:([Expr1008], [Expr1009], [Expr1007]))
                 |--Compute Scalar(DEFINE:(([Expr1008],[Expr1009],[Expr1007])=GetRangeThroughConvert(CONVERT_IMPLICIT(date,[@1],0),CONVERT_IMPLICIT(date,[@1],0),(62))))
                 |    |--Constant Scan
                 |--Clustered Index Seek(OBJECT:([Testing].[dbo].[Sales].[ix_sales]), SEEK:([Testing].[dbo].[Sales].[sale_date] > [Expr1008] AND [Testing].[dbo].[Sales].[sale_date] < [Expr1009]),  WHERE:(CONVERT(date,[Testing].[dbo].[Sales].[sale_date],0)=

*/

GO

SET SHOWPLAN_TEXT OFF;

GO

DROP TABLE Sales; 
