IF OBJECT_ID(N'Customers', N'U') IS NOT NULL
   DROP TABLE Customers;
   
CREATE TABLE Customers (
 customer_nbr INT NOT NULL PRIMARY KEY,
 first_name VARCHAR(35) NOT NULL,
 last_name VARCHAR(35) NOT NULL);
 
INSERT INTO Customers VALUES(1, 'Jeff', 'Hull');
INSERT INTO Customers VALUES(2, 'George', 'Brown');
INSERT INTO Customers VALUES(3, 'Peter', 'Green');
INSERT INTO Customers VALUES(4, 'Dona', 'Johnson');

CREATE NONCLUSTERED INDEX ix_customer_last_name
ON Customers (last_name);

GO

SET SHOWPLAN_TEXT ON;

GO

SELECT first_name, last_name
FROM Customers
WHERE last_name = N'Brown';

/*

StmtText
-----------------------------------
  |--Clustered Index Scan(OBJECT:([Testing].[dbo].[Customers].[PK__Customer__C5F5E0D6166152B0]), 
  WHERE:(CONVERT_IMPLICIT(nvarchar(35),[Testing].[dbo].[Customers].[last_name],0)=[@1]))

*/

SELECT first_name, last_name
FROM Customers
WHERE last_name = 'Brown';

/*

StmtText
-----------------------------------
  |--Clustered Index Scan(OBJECT:([Testing].[dbo].[Customers].[PK__Customer__C5F5E0D6166152B0]), 
  WHERE:([Testing].[dbo].[Customers].[last_name]='Brown'))

*/

GO

SET SHOWPLAN_TEXT OFF;

GO

/* incorrect parameter data type */
CREATE PROCEDURE GetCustomerByLastName
 @last_name NVARCHAR(35)
AS
 SELECT first_name, last_name
 FROM Customers
 WHERE last_name = @last_name;
 
GO

GO

SET SHOWPLAN_TEXT ON;

GO

EXEC GetCustomerByLastName @last_name = 'Brown';

/*

StmtText
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
       |--Clustered Index Scan(OBJECT:([Testing].[dbo].[Customers].[PK__Customer__C5F5E0D651CCFC98]), WHERE:(CONVERT_IMPLICIT(nvarchar(35),[Testing].[dbo].[Customers].[last_name],0)=[@last_name]))

*/


GO

SET SHOWPLAN_TEXT OFF;

GO

DROP PROCEDURE GetCustomerByLastName;

GO

/* correct parameter data type */
CREATE PROCEDURE GetCustomerByLastName
 @last_name VARCHAR(35)
AS
 SELECT first_name, last_name
 FROM Customers
 WHERE last_name = @last_name;

GO

SET SHOWPLAN_TEXT ON;

GO

EXEC GetCustomerByLastName @last_name = 'Brown';

/*

StmtText
--------------------------------------------------------------------------------------------------------------------------------------------------------------------
       |--Clustered Index Scan(OBJECT:([Testing].[dbo].[Customers].[PK__Customer__C5F5E0D651CCFC98]), WHERE:([Testing].[dbo].[Customers].[last_name]=[@last_name]))

*/


GO

SET SHOWPLAN_TEXT OFF;

GO

DROP PROCEDURE GetCustomerByLastName;

DROP TABLE Customers; 