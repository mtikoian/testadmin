-- Function Call In Column List
USE AdventureWorks2012;
GO

CREATE FUNCTION dbo.fn_GetName 
     (
       @BusinessEntityID INT
      ) 
RETURNS VARCHAR(100)
AS
BEGIN
  DECLARE @PersonName VARCHAR(100);
  SELECT @PersonName =  PP.LastName + ', ' + PP.FirstName
  FROM Person.Person PP
    WHERE PP.BusinessEntityID = @BusinessEntityID;
  RETURN @PersonName;
END
GO

-- Run Function in SELECT and Review I/O and Time
SET STATISTICS IO ON;
SET STATISTICS TIME ON;
GO

SELECT TOP 1000 dbo.fn_GetName(BusinessEntityID) as FullName
    FROM Person.Person
WHERE dbo.fn_GetName(BusinessEntityID) IS NOT NULL;
GO

-- Rewrite as join in SELECT list
SELECT TOP 1000 PP.LastName + ', ' + PP.FirstName as FullName
FROM Person.Person PP;
GO

-- Use and Inline Table Value Function
CREATE FUNCTION fn_GetNameTable(@BusinessEntityID int)
RETURNS TABLE
AS 
RETURN (
  SELECT  PP.LastName + ', ' +  PP.FirstName As FullName
  FROM Person.Person PP
  WHERE PP.BusinessEntityID = @BusinessEntityID 
 );
GO

-- Using CROSS APPLY
SELECT FN.[FullName]
FROM 
(SELECT TOP 1000 BusinessEntityID FROM Person.Person) PP
CROSS APPLY fn_GetNameTable(PP.BusinessEntityID) FN;


GO
-- Using View to replace Scalar Function
CREATE VIEW vw_GetName
AS
  SELECT PP.LastName + ', ' + PP.FirstName as FullName
    FROM Person.Person PP;
GO

-- Rewrite using View  
SELECT TOP 1000 V.FullName
FROM vw_GetName V;


-- Also if function call in WHERE statement it can also be slow
SELECT PP.LastName + ', ' + PP.FirstName [FullName]
FROM Person.Person PP
WHERE dbo.fn_GetName(PP.BusinessEntityID) = 'Abbas, Syed';
GO

-- Rewrite using view
SELECT V.FullName 
FROM vw_GetName V
WHERE V.FullName = 'Abbas, Syed';
GO



-- Clean Up
DROP VIEW vw_GetName;
DROP FUNCTION fn_GetNameTable;
DROP FUNCTION fn_GetName;
DROP FUNCTION fn_GetCurrentTime;


 