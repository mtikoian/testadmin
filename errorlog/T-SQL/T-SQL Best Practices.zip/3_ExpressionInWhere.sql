-- Expression in Where Clause Causes Index Scan
USE AdventureWorks2012;
GO
CREATE INDEX IX_SalesOrderHeader_OrderDate on Sales.SalesOrderHeader(OrderDate);
GO 
SET STATISTICS IO ON;
-- Performs Index Scan
SELECT * FROM Sales.SalesOrderHeader
	WHERE DATEADD(DAY,15,OrderDate) = '03/14/2007';
GO
-- Performs Index Seek
SELECT * FROM Sales.SalesOrderHeader
   WHERE OrderDate = DATEADD(DAY,-15,'03/14/2007');
GO   
DROP INDEX IX_SalesOrderHeader_OrderDate on Sales.SalesOrderHeader;