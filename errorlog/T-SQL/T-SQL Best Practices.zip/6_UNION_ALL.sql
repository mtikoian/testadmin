USE TempDB;
GO
-- Create DEMO data
CREATE TABLE Produce1 (ProduceName varchar(20));
INSERT INTO Produce1 VALUES ('Carrots'),('Peas'),('Corn');
CREATE TABLE Produce2 (ProduceName varchar(20));
INSERT INTO Produce2 VALUES ('Lettuce'),('Tomatoes'),('Cucumber');
GO
-- IF distinct set don't use UNION, instead use UNION ALL
SELECT * FROM PRODUCE1 
UNION 
SELECT * FROM PRODUCE2;
GO
SELECT * FROM PRODUCE1
UNION ALL 
SELECT * FROM PRODUCE2;
GO
-- Clean up 
DROP TABLE PRODUCE1, PRODUCE2;