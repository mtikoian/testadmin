
USE AdventureWorks2012;
GO
-- Turn on client statistics

--Trial 1
SELECT TOP 10 * FROM Sales.SalesOrderDetail;

-- Trial 2
SELECT TOP 10 SalesOrderID FROM Sales.SalesOrderDetail;

-- Trial 3
SELECT TOP 10 SalesOrderID, SalesOrderDetailID FROM Sales.SalesOrderDetail;