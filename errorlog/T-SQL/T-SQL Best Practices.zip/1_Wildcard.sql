
USE AdventureWorks2012;
GO
CREATE INDEX LastName_IDX on Person.Person(LastName);

SELECT Distinct LastName 
	FROM Person.Person
		WHERE LastName LIKE '%sen' 
		
SELECT Distinct LastName 
	FROM Person.Person
		WHERE LastName LIKE '_____sen'

SELECT Distinct LastName 
	FROM Person.Person
		WHERE LastName LIKE 'A%sen' 
		
SELECT Distinct LastName 
	FROM Person.Person
		WHERE LastName LIKE '[AW]%sen'
		
SELECT Distinct LastName 
	FROM Person.Person
		WHERE LastName LIKE '[A-Z]%sen' 
		
		
DROP INDEX LastName_IDX on Person.Person