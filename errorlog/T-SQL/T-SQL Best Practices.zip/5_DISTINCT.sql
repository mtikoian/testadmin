SET STATISTICS IO ON;
SET STATISTICS TIME ON;
-- Requires Sort Operation
SELECT   LargePhotoFileName 
        FROM AdventureWorks2012.Production.ProductPhoto;
GO
SELECT DISTINCT LargePhotoFileName 
        FROM  AdventureWorks2012.Production.ProductPhoto;
GO

