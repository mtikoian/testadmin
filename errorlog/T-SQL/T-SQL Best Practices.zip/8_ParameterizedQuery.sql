USE AdventureWorks2012;
GO
-- simple parameterization

DBCC FREEPROCCACHE;
GO

SELECT *
FROM	AdventureWorks2012.Sales.SalesOrderHeader  
WHERE	SalesOrderID = 56000;
GO

SELECT *
FROM	AdventureWorks2012.Sales.SalesOrderHeader
WHERE	SalesOrderID = 56001;
GO


-- note the size of the cached plan
select  stats.execution_count AS exec_count, 
	p.size_in_bytes as [size], 
	[sql].[text] as [plan_text]
from sys.dm_exec_cached_plans p
outer apply sys.dm_exec_sql_text (p.plan_handle) sql
join sys.dm_exec_query_stats stats ON stats.plan_handle = p.plan_handle
WHERE [sql].[text] LIKE '%SELECT *%';
GO

-- even query strings that are slightly different can sometimes reuse plans
DBCC FREEPROCCACHE;
GO

SELECT	*
FROM	AdventureWorks2012.Sales.SalesOrderHeader
WHERE	SalesOrderID = 56000;
GO

SELECT	* FROM	AdventureWorks2012.Sales.SalesOrderHeader WHERE	SalesOrderID = 56001;
GO

select	*
from	AdventureWorks2012.Sales.SalesOrderHeader
where	SalesOrderID = 56002;
GO

select  stats.execution_count AS exec_count, 
	p.size_in_bytes as [size], 
	[sql].[text] as [plan_text]
from sys.dm_exec_cached_plans p
outer apply sys.dm_exec_sql_text (p.plan_handle) sql
join sys.dm_exec_query_stats stats ON stats.plan_handle = p.plan_handle
WHERE [sql].[text] LIKE '%SELECT *%';
GO



-- can more complicated queries be parameterized?
DBCC FREEPROCCACHE;
GO

SELECT  SUM(LineTotal) AS LineTotal
FROM	AdventureWorks2012.Sales.SalesOrderHeader H
JOIN	AdventureWorks2012.Sales.SalesOrderDetail D ON D.SalesOrderID = H.SalesOrderID
WHERE	H.SalesOrderID = 56000;
GO

SELECT  SUM(LineTotal) AS LineTotal
FROM	AdventureWorks2012.Sales.SalesOrderHeader H
JOIN	AdventureWorks2012.Sales.SalesOrderDetail D ON D.SalesOrderID = H.SalesOrderID
WHERE	H.SalesOrderID = 56001;
GO

-- How many plans will there be?
select  stats.execution_count AS exec_count, 
	p.size_in_bytes as [size], 
	LEFT([sql].[text], 400) as [plan_text]
from sys.dm_exec_cached_plans p
outer apply sys.dm_exec_sql_text (p.plan_handle) sql
join sys.dm_exec_query_stats stats ON stats.plan_handle = p.plan_handle
WHERE [sql].[text] LIKE '%SELECT  SUM%';
GO




-- but you can create a parameterize queries for the more complex query statements.
DBCC FREEPROCCACHE;
GO

EXEC sp_executesql N'SELECT  SUM(LineTotal) AS LineTotal
FROM	AdventureWorks2012.Sales.SalesOrderHeader H
JOIN AdventureWorks2012.Sales.SalesOrderDetail D ON D.SalesOrderID = H.SalesOrderID
WHERE	H.SalesOrderID = @SalesOrderID', N'@SalesOrderID INT', @SalesOrderID = 56000;
GO

EXEC sp_executesql N'SELECT  SUM(LineTotal) AS LineTotal
FROM	AdventureWorks2012.Sales.SalesOrderHeader H
JOIN AdventureWorks2012.Sales.SalesOrderDetail D ON D.SalesOrderID = H.SalesOrderID
WHERE	H.SalesOrderID = @SalesOrderID', N'@SalesOrderID INT', @SalesOrderID = 56005;
GO

select  stats.execution_count AS exec_count, 
	[sql].[text] as [plan_text]
from sys.dm_exec_cached_plans p
outer apply sys.dm_exec_sql_text (p.plan_handle) sql
join sys.dm_exec_query_stats stats ON stats.plan_handle = p.plan_handle
WHERE [sql].[text] LIKE '%SELECT  SUM%';

-- Force Parameterization at Database
ALTER DATABASE [AdventureWorks2012] SET PARAMETERIZATION FORCED;
DBCC FREEPROCCACHE;
GO

SELECT  SUM(LineTotal) AS LineTotal
FROM	AdventureWorks2012.Sales.SalesOrderHeader H
JOIN	AdventureWorks2012.Sales.SalesOrderDetail D ON D.SalesOrderID = H.SalesOrderID
WHERE	H.SalesOrderID = 56000;
GO

SELECT  SUM(LineTotal) AS LineTotal
FROM	AdventureWorks2012.Sales.SalesOrderHeader H
JOIN	AdventureWorks2012.Sales.SalesOrderDetail D ON D.SalesOrderID = H.SalesOrderID
WHERE   H.SalesOrderID = 56001;

select  stats.execution_count AS exec_count, 
	p.size_in_bytes as [size], 
	LEFT([sql].[text], 400) as [plan_text]
from sys.dm_exec_cached_plans p
outer apply sys.dm_exec_sql_text (p.plan_handle) sql
join sys.dm_exec_query_stats stats ON stats.plan_handle = p.plan_handle
WHERE [sql].[text] LIKE '%SELECT SUM%';
GO
-- Turn off Forced parameterization
ALTER DATABASE [AdventureWorks2012] SET PARAMETERIZATION SIMPLE;


