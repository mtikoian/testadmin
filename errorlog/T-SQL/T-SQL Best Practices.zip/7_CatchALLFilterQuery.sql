-- Catch All Filter Query
USE AdventureWorks2012
GO
-- Use a number of ISNULL conditions causes SCAN operation
CREATE PROCEDURE CatchAll_V1 (@SalesOrderID int = NULL
                             ,@SalesOrderDetailID int = NULL
                             ,@CarrierTrackingNumber nvarchar(25) = NULL)
AS  
SELECT * FROM AdventureWorks2012.Sales.SalesOrderDetail
WHERE 
	  (SalesOrderID = @SalesOrderID or @SalesOrderID IS NULL)
  AND (SalesOrderDetailID = @SalesOrderDetailID or @SalesOrderDetailID IS NULL)
  AND (CarrierTrackingNumber = @CarrierTrackingNumber or @CarrierTrackingNumber IS NULL) 
GO

SET STATISTICS IO ON 
GO
EXEC CatchAll_V1 @SalesOrderID = 43659
GO
-- Use Dynamic SQL allows for SEEK operations
CREATE PROCEDURE CatchAll_V2 (@SalesOrderID int = NULL
                             ,@SalesOrderDetailID int = NULL
                             ,@CarrierTrackingNumber nvarchar(25) = NULL)
AS  
DECLARE @CMD NVARCHAR(max)
DECLARE @WHERE NVARCHAR(max)
SET @CMD = 'SELECT * FROM AdventureWorks2012.Sales.SalesOrderDetail '
SET @WHERE = ''
IF @SalesOrderID IS NOT NULL 
   SET @WHERE = @WHERE + 'AND SalesOrderID = @SalesOrderID '
IF @SalesOrderDetailID IS NOT NULL
   SET @WHERE = @WHERE + 'AND SalesOrderDetailID  = @SalesOrderDetailID '
IF @CarrierTrackingNumber IS NOT NULL
   SET @WHERE = @WHERE + 'AND CarrierTrackingNumber  = @CarrierTrackingNumber '
IF LEN(@WHERE) > 0 
   SET @CMD = @CMD + ' WHERE ' + RIGHT(@WHERE,LEN(@WHERE) - 3)
EXEC sp_executesql @CMD 
	               , N'@SalesOrderID int
	                  ,@SalesOrderDetailID int
	                  ,@CarrierTrackingNumber nvarchar(25)'
                   ,@SalesOrderID = @SalesOrderID
                   ,@SalesOrderDetailID = @SalesOrderDetailID
                   ,@CarrierTrackingNumber = @CarrierTrackingNumber
GO

EXEC CatchAll_V2 @SalesOrderID = 43659
GO

EXEC CatchAll_V1 @SalesOrderID = 43659
GO
