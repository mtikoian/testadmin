--DO NOT COUNT SPECIFIC THING UNLESS REALLY MEAN IT
--PROBABLY ONLY WHEN COUNTING DISTINCT

use adventureworks
go

set statistics io on

select count(CarrierTrackingNumber)
from Sales.SalesOrderDetail with (nolock)

-----------
60919   --Did you REALLY want to dismiss NULL values??
Warning: Null value is eliminated by an aggregate or other SET operation.

1.122 cost
Table 'SalesOrderDetail'. Scan count 1, logical reads 1237, physical reads 0, read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.

select count(*)
from Sales.SalesOrderDetail with (nolock)

-----------
121317

0.367 cost  --optimizer picks the tightest index to count
Table 'SalesOrderDetail'. Scan count 1, logical reads 227, physical reads 0, read-ahead reads 248, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.


select count(DISTINCT CarrierTrackingNumber)
from Sales.SalesOrderDetail with (nolock)

-----------
3806
Warning: Null value is eliminated by an aggregate or other SET operation.

1.969 cost
Table 'Worktable'. Scan count 0, logical reads 0, physical reads 0, read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.
Table 'SalesOrderDetail'. Scan count 1, logical reads 1237, physical reads 0, read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.
