/* save for inquisitive reader

   KEY TAKEAWAY:  If you need some data condition to remain for your code to work, 
   ensure that condition ALWAYS exists, or build a box around it with your code
   
*/

Use tempdb
set nocount on
go

IF OBJECT_ID(N'Products', N'U') IS NOT NULL
   DROP TABLE dbo.Products;

CREATE TABLE dbo.Products (
 sku INT NOT NULL PRIMARY KEY,
 product_description VARCHAR(35) NOT NULL);

IF OBJECT_ID(N'ProductPlants', N'U') IS NOT NULL
   DROP TABLE dbo.ProductPlants;
    
CREATE TABLE dbo.ProductPlants (
 sku INT NOT NULL,
 plant_nbr INT NOT NULL,
 PRIMARY KEY (sku, plant_nbr));
 
INSERT dbo.Products VALUES(1, 'Bike');
INSERT dbo.Products VALUES(2, 'Ball');
INSERT dbo.Products VALUES(3, 'Phone');

SELECT sku, product_description FROM dbo.Products;

/*

sku   product_description
----- -------------------
1     Bike
2     Ball
3     Phone

*/

INSERT dbo.ProductPlants VALUES(1, 1);
INSERT dbo.ProductPlants VALUES(2, 1);
INSERT dbo.ProductPlants VALUES(3, 2);

SELECT sku, plant_nbr FROM dbo.ProductPlants;
/*

sku   plant_nbr
----- -----------
1     1
2     1
3     2

*/

SELECT sku, product_description,
      (SELECT plant_nbr
       FROM dbo.ProductPlants AS B
       WHERE B.sku = A.sku) AS plant_nbr
FROM dbo.Products AS A;

/*


sku  product_description plant_nbr
---- ------------------- -----------
1    Bike                1
2    Ball                1
3    Phone               2

*/

INSERT dbo.ProductPlants VALUES(2, 3);

SELECT sku, plant_nbr FROM dbo.ProductPlants;

/*

sku   plant_nbr
----- -----------
1     1
2     1
2     3
3     2

*/

/*

-- Query will produce error
SELECT sku, product_description,
      (SELECT plant_nbr
       FROM dbo.ProductPlants AS B
       WHERE B.sku = A.sku) AS plant_nbr
FROM dbo.Products AS A;

*/

/*

Subquery returned more than 1 value. This is not permitted when the subquery follows =, !=, <, <= , >, >= or when the subquery is used as an expression.

*/

SELECT A.sku, A.product_description, B.plant_nbr
FROM dbo.Products AS A
JOIN dbo.ProductPlants AS B
  ON A.sku = B.sku;

/*

sku  product_description  plant_nbr
---- -------------------- -----------
1    Bike                 1
2    Ball                 1
2    Ball                 3
3    Phone                2

*/

/*

Same problem in WHERE clause: use IN, JOIN, EXISTS to solve

SELECT A.sku, A.product_description, B.plant_nbr
FROM dbo.Products AS A
JOIN dbo.ProductPlants AS B
  ON A.sku = B.sku
WHERE B.sku = (SELECT C.sku  --this query MUST return one row MAX
               FROM dbo.Products AS C
               WHERE C.product_description LIKE '%ball%');
               
*/
  

DROP TABLE dbo.Products, dbo.ProductPlants;
