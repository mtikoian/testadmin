/* A Game of Hierarchies
 * JOINS
 * (c) Markus Ehrenmueller-Jensen
 */

USE AdventureWorksDW2014
GO

-- joining the tables
SELECT
	CASE
		WHEN GROUPING(GoT_Region.RegionName)		= 0 THEN GoT_Region.RegionName
		WHEN GROUPING(GoT_Continent.ContinentName)  = 0 THEN '* SUBTOTAL (' + GoT_Continent.ContinentName + ')'
		WHEN GROUPING(GoT_World.WorldName)			= 0 THEN '** TOTAL (' + GoT_World.WorldName + ')'
		ELSE												 '<UNKNOWN>'
		END as Name,
	count(*) as POICounter
FROM
	dbo.GoT_POI
INNER JOIN
	dbo.GoT_Region on
		GoT_Region.ID=GoT_POI.RegionID
INNER JOIN
	dbo.GoT_Continent on
		GoT_Continent.ID=GoT_Region.ContinentID
INNER JOIN
	dbo.GoT_World on
		GoT_World.ID=GoT_Continent.WorldID
GROUP BY GROUPING SETS (
	(GoT_World.WorldName),
	(GoT_World.WorldName, GoT_Continent.ContinentName),
	(GoT_World.WorldName, GoT_Continent.ContinentName, GoT_Region.RegionName)
	)
ORDER BY
	ISNULL(GoT_World.WorldName,			CASE WHEN GROUPING(GoT_World.WorldName)			= 0 THEN NULL ELSE MAX(GoT_World.WorldName)			+'a' END),
	ISNULL(GoT_Continent.ContinentName, CASE WHEN GROUPING(GoT_Continent.ContinentName) = 0 THEN NULL ELSE MAX(GoT_Continent.ContinentName)	+'a' END),
	ISNULL(GoT_Region.RegionName,		CASE WHEN GROUPING(GoT_Region.RegionName)		= 0 THEN NULL ELSE MAX(GoT_Region.RegionName)		+'a' END);
/*
Name                                                            POICounter
--------------------------------------------------------------- -----------
Asshai, the Jade Sea, and lands of the far east                 4
Bay of Dragons                                                  3
Dothraki Sea                                                    1
Lhazar                                                          1
Qarth                                                           1
The Free Cities                                                 9
The Red Waste                                                   1
The Rhoyne River                                                1
Valyrian Peninsula                                              1
* SUBTOTAL (Essos)                                              22
...
*/