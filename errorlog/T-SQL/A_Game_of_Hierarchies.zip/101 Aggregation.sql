/* A Game of Hierarchies
 * Aggregation
 * (c) Markus Ehrenmueller-Jensen
 */

USE AdventureWorksDW2014
GO

-- let's have a look onto the data
SELECT
	POIName,
	RegionName,
	ContinentName,
	WorldName
FROM
	dbo.GoT_POI
ORDER BY
	WorldName,
	ContinentName,
	RegionName,
	POIName;
/*
POIName                                            RegionName                                         ContinentName                                      WorldName
-------------------------------------------------- -------------------------------------------------- -------------------------------------------------- --------------------------------------------------
Asshai                                             Asshai, the Jade Sea, and lands of the far east    Essos                                              The Known World
Ibben                                              Asshai, the Jade Sea, and lands of the far east    Essos                                              The Known World
Shadow Lands                                       Asshai, the Jade Sea, and lands of the far east    Essos                                              The Known World
Yi Ti                                              Asshai, the Jade Sea, and lands of the far east    Essos                                              The Known World
Astapor                                            Bay of Dragons                                     Essos                                              The Known World
Meereen                                            Bay of Dragons                                     Essos                                              The Known World
Yunkai                                             Bay of Dragons                                     Essos                                              The Known World
...
*/

-- easy aggregation by counting them all
SELECT
	count(*) as CountOfAll
FROM
	dbo.GoT_POI;
/*
CountOfAll
-----------
148
*/

-- trying to count specific rows
SELECT
	POIName,
	RegionName,
	ContinentName,
	WorldName,
	count(*) as CountOfSomething
FROM
	dbo.GoT_POI;



/*
Msg 8120, Level 16, State 1, Line 42
Column 'dbo.GoT_POI.POIName' is invalid in the select list because it is 
not contained in either an aggregate function or the GROUP BY clause.
*/

-- -> slides

-- introducing GROUP BY
SELECT
	POIName,
	RegionName,
	ContinentName,
	WorldName,
	count(*) as CountOfSomething
FROM
	dbo.GoT_POI
GROUP BY
	POIName,
	RegionName,
	ContinentName,
	WorldName
ORDER BY
	WorldName,
	ContinentName,
	RegionName,
	POIName;
/*
POIName                                            RegionName                                         ContinentName                                      WorldName                                          CountOfSomething
-------------------------------------------------- -------------------------------------------------- -------------------------------------------------- -------------------------------------------------- ----------------
Asshai                                             Asshai, the Jade Sea, and lands of the far east    Essos                                              The Known World                                    1
Ibben                                              Asshai, the Jade Sea, and lands of the far east    Essos                                              The Known World                                    1
Shadow Lands                                       Asshai, the Jade Sea, and lands of the far east    Essos                                              The Known World                                    1
Yi Ti                                              Asshai, the Jade Sea, and lands of the far east    Essos                                              The Known World                                    1
Astapor                                            Bay of Dragons                                     Essos                                              The Known World                                    1
Meereen                                            Bay of Dragons                                     Essos                                              The Known World                                    1
Yunkai                                             Bay of Dragons                                     Essos                                              The Known World                                    1
...
*/

-- reverse order of elements in GROUP BY
SELECT
	POIName,
	RegionName,
	ContinentName,
	WorldName,
	count(*) as CountOfSomething
FROM
	dbo.GoT_POI
GROUP BY
	WorldName,
	ContinentName,
	RegionName,
	POIName
ORDER BY
	WorldName,
	ContinentName,
	RegionName,
	POIName;
/*
POIName                                            RegionName                                         ContinentName                                      WorldName                                          CountOfSomething
-------------------------------------------------- -------------------------------------------------- -------------------------------------------------- -------------------------------------------------- ----------------
Asshai                                             Asshai, the Jade Sea, and lands of the far east    Essos                                              The Known World                                    1
Ibben                                              Asshai, the Jade Sea, and lands of the far east    Essos                                              The Known World                                    1
Shadow Lands                                       Asshai, the Jade Sea, and lands of the far east    Essos                                              The Known World                                    1
Yi Ti                                              Asshai, the Jade Sea, and lands of the far east    Essos                                              The Known World                                    1
Astapor                                            Bay of Dragons                                     Essos                                              The Known World                                    1
Meereen                                            Bay of Dragons                                     Essos                                              The Known World                                    1
Yunkai                                             Bay of Dragons                                     Essos                                              The Known World                                    1
...
*/

-- GROUP BY on Continent
SELECT
	ContinentName,
	count(*) as CountByContinent
FROM
	dbo.GoT_POI
GROUP BY
	ContinentName
ORDER BY
	ContinentName;
/*
ContinentName                                      CountByContinent
-------------------------------------------------- ----------------
Essos                                              22
Sothoryos                                          2
Westeros                                           124
*/

-- introducing OVER()
SELECT
	POIName,
	RegionName,
	ContinentName,
	WorldName,
	count(*) OVER() as CountAll
FROM
	dbo.GoT_POI
ORDER BY
	WorldName,
	ContinentName,
	RegionName,
	POIName;
/*
POIName                                            RegionName                                         ContinentName                                      WorldName                                          CountAll
-------------------------------------------------- -------------------------------------------------- -------------------------------------------------- -------------------------------------------------- -----------
Asshai                                             Asshai, the Jade Sea, and lands of the far east    Essos                                              The Known World                                    148
Ibben                                              Asshai, the Jade Sea, and lands of the far east    Essos                                              The Known World                                    148
Shadow Lands                                       Asshai, the Jade Sea, and lands of the far east    Essos                                              The Known World                                    148
Yi Ti                                              Asshai, the Jade Sea, and lands of the far east    Essos                                              The Known World                                    148
Astapor                                            Bay of Dragons                                     Essos                                              The Known World                                    148
Meereen                                            Bay of Dragons                                     Essos                                              The Known World                                    148
Yunkai                                             Bay of Dragons                                     Essos                                              The Known World                                    148
...
*/

-- -> slides

-- introducing OVER(PARTITION BY)
SELECT
	POIName,
	count(*) OVER(PARTITION BY POIName) as CountByPOI,
	RegionName,
	count(*) OVER(PARTITION BY RegionName) as CountByRegion,
	ContinentName,
	count(*) OVER(PARTITION BY ContinentName) as CountByContinent,
	WorldName,
	count(*) OVER(PARTITION BY WorldName) as CountByWorld
FROM
	dbo.GoT_POI
ORDER BY
	WorldName,
	ContinentName,
	RegionName,
	POIName;
/*
POIName                                            CountByPOI  RegionName                                         CountByRegion ContinentName                                      CountByContinent WorldName                                          CountByWorld
-------------------------------------------------- ----------- -------------------------------------------------- ------------- -------------------------------------------------- ---------------- -------------------------------------------------- ------------
Asshai                                             1           Asshai, the Jade Sea, and lands of the far east    4             Essos                                              22               The Known World                                    148
Ibben                                              1           Asshai, the Jade Sea, and lands of the far east    4             Essos                                              22               The Known World                                    148
Shadow Lands                                       1           Asshai, the Jade Sea, and lands of the far east    4             Essos                                              22               The Known World                                    148
Yi Ti                                              1           Asshai, the Jade Sea, and lands of the far east    4             Essos                                              22               The Known World                                    148
Astapor                                            1           Bay of Dragons                                     3             Essos                                              22               The Known World                                    148
Meereen                                            1           Bay of Dragons                                     3             Essos                                              22               The Known World                                    148
Yunkai                                             1           Bay of Dragons                                     3             Essos                                              22               The Known World                                    148
...
*/

-- -> slides

-- introducing GROUP BY ROLLUP
SELECT
	RegionName,
	ContinentName,
	WorldName,
	count(*) as CountByGroup
FROM
	dbo.GoT_POI
GROUP BY ROLLUP (
	RegionName,
	ContinentName,
	WorldName
	)
ORDER BY
	RegionName,
	ContinentName,
	WorldName;
/*
RegionName                                         ContinentName                                      WorldName                                          CountByGroup
-------------------------------------------------- -------------------------------------------------- -------------------------------------------------- ------------
NULL                                               NULL                                               NULL                                               148
Asshai, the Jade Sea, and lands of the far east    NULL                                               NULL                                               4
Asshai, the Jade Sea, and lands of the far east    Essos                                              NULL                                               4
Asshai, the Jade Sea, and lands of the far east    Essos                                              The Known World                                    4
Bay of Dragons                                     NULL                                               NULL                                               3
Bay of Dragons                                     Essos                                              NULL                                               3
Bay of Dragons                                     Essos                                              The Known World                                    3
...
*/

-- -> slides

-- reordering GROUP BY ROLLUP
SELECT
	RegionName,
	ContinentName,
	WorldName,
	count(*) as CountByGroup
FROM
	dbo.GoT_POI
GROUP BY ROLLUP (
	WorldName,
	ContinentName,
	RegionName
	)
ORDER BY
	RegionName,
	ContinentName,
	WorldName;
/*
RegionName                                         ContinentName                                      WorldName                                          CountByGroup
-------------------------------------------------- -------------------------------------------------- -------------------------------------------------- ------------
NULL                                               NULL                                               NULL                                               148
NULL                                               NULL                                               The Known World                                    148
NULL                                               Essos                                              The Known World                                    22
NULL                                               Sothoryos                                          The Known World                                    2
NULL                                               Westeros                                           The Known World                                    124
Asshai, the Jade Sea, and lands of the far east    Essos                                              The Known World                                    4
Bay of Dragons                                     Essos                                              The Known World                                    3
...
*/

-- introducing GROUP BY CUBE
SELECT
	RegionName,
	ContinentName,
	WorldName,
	count(*) as CountByGroup
FROM
	dbo.GoT_POI
GROUP BY CUBE (
	RegionName,
	ContinentName,
	WorldName
	)
ORDER BY
	RegionName,
	ContinentName,
	WorldName;
/*
RegionName                                         ContinentName                                      WorldName                                          CountByGroup
-------------------------------------------------- -------------------------------------------------- -------------------------------------------------- ------------
NULL                                               NULL                                               NULL                                               148
NULL                                               NULL                                               The Known World                                    148
NULL                                               Essos                                              NULL                                               22
NULL                                               Essos                                              The Known World                                    22
NULL                                               Sothoryos                                          NULL                                               2
NULL                                               Sothoryos                                          The Known World                                    2
NULL                                               Westeros                                           NULL                                               124
NULL                                               Westeros                                           The Known World                                    124
Asshai, the Jade Sea, and lands of the far east    NULL                                               NULL                                               4
Asshai, the Jade Sea, and lands of the far east    NULL                                               The Known World                                    4
Asshai, the Jade Sea, and lands of the far east    Essos                                              NULL                                               4
Asshai, the Jade Sea, and lands of the far east    Essos                                              The Known World                                    4
Bay of Dragons                                     NULL                                               NULL                                               3
Bay of Dragons                                     NULL                                               The Known World                                    3
Bay of Dragons                                     Essos                                              NULL                                               3
Bay of Dragons                                     Essos                                              The Known World                                    3
...
*/

-- -> slides

-- introducing GROUP BY GROUPING SETS
SELECT
	RegionName,
	ContinentName,
	WorldName,
	count(*) as CountByGroup
FROM
	dbo.GoT_POI
GROUP BY GROUPING SETS (
	(RegionName, ContinentName, WorldName),
	(RegionName, ContinentName),
	(RegionName, WorldName),
	(ContinentName, WorldName),
	(RegionName),
	(ContinentName),
	(WorldName),
	()
	)
ORDER BY
	RegionName,
	ContinentName,
	WorldName;
/*
RegionName                                         ContinentName                                      WorldName                                          CountByGroup
-------------------------------------------------- -------------------------------------------------- -------------------------------------------------- ------------
NULL                                               NULL                                               The Known World                                    148
NULL                                               Essos                                              The Known World                                    22
NULL                                               Sothoryos                                          The Known World                                    2
NULL                                               Westeros                                           The Known World                                    124
Asshai, the Jade Sea, and lands of the far east    Essos                                              The Known World                                    4
Bay of Dragons                                     Essos                                              The Known World                                    3
...
*/

-- get rid of unneccessary rows of GROUP BY GROUPING SETS
SELECT
	RegionName,
	ContinentName,
	WorldName,
	count(*) as CountByGroup
FROM
	dbo.GoT_POI
GROUP BY GROUPING SETS (
	(RegionName, ContinentName, WorldName),
	--(RegionName, ContinentName)
	--(RegionName, WorldName),
	(ContinentName, WorldName),
	--(RegionName)
	--(ContinentName),
	(WorldName)
	--()
	)
ORDER BY
	RegionName,
	ContinentName,
	WorldName;
/*
RegionName                                         ContinentName                                      WorldName                                          CountByGroup
-------------------------------------------------- -------------------------------------------------- -------------------------------------------------- ------------
NULL                                               NULL                                               The Known World                                    148
NULL                                               Essos                                              The Known World                                    22
NULL                                               Sothoryos                                          The Known World                                    2
NULL                                               Westeros                                           The Known World                                    124
Asshai, the Jade Sea, and lands of the far east    Essos                                              The Known World                                    4
Bay of Dragons                                     Essos                                              The Known World                                    3
...
*/

-- simulating GROUP BY GROUPING SETS via UNION ALL
SELECT
	RegionName,
	ContinentName,
	WorldName,
	count(*) as CountByGroup,
	'Region' as QueryName
FROM
	dbo.GoT_POI
GROUP BY 
	WorldName, ContinentName, RegionName
UNION ALL
SELECT
	null RegionName,
	ContinentName,
	WorldName,
	count(*) as CountByGroup,
	'Continent' as QueryName
FROM
	dbo.GoT_POI
GROUP BY 
	WorldName, ContinentName
UNION ALL
SELECT
	null RegionName,
	null ContinentName,
	WorldName,
	count(*) as CountByGroup,
	'World' as QueryName
FROM
	dbo.GoT_POI
GROUP BY 
	WorldName
ORDER BY
	RegionName,
	ContinentName,
	WorldName;
/*
RegionName                                         ContinentName                                      WorldName                                          CountByGroup QueryName
-------------------------------------------------- -------------------------------------------------- -------------------------------------------------- ------------ ---------
NULL                                               NULL                                               The Known World                                    148          World
NULL                                               Essos                                              The Known World                                    22           Continent
NULL                                               Sothoryos                                          The Known World                                    2            Continent
NULL                                               Westeros                                           The Known World                                    124          Continent
Asshai, the Jade Sea, and lands of the far east    Essos                                              The Known World                                    4            Region
Bay of Dragons                                     Essos                                              The Known World                                    3            Region
...
*/


--Include Actual Execution Plan (Ctrl-M)
--& re-run the past 2 queries


-- introducing GROUPING
SELECT
	RegionName,
	GROUPING(RegionName) as GroupingRegionName,
	ContinentName,
	GROUPING(ContinentName) as GroupingContinentName,
	WorldName,
	GROUPING(WorldName) as GroupingWorldName,
	count(*) as CountByGroup
FROM
	dbo.GoT_POI
GROUP BY GROUPING SETS (
	(WorldName),
	(WorldName, ContinentName),
	(WorldName, ContinentName, RegionName)
	)
ORDER BY
	RegionName,
	ContinentName,
	WorldName;
/*
RegionName                                         GroupingRegionName ContinentName                                      GroupingContinentName WorldName                                          GroupingWorldName CountByGroup
-------------------------------------------------- ------------------ -------------------------------------------------- --------------------- -------------------------------------------------- ----------------- ------------
NULL                                               1                  NULL                                               1                     The Known World                                    0                 148
NULL                                               1                  Essos                                              0                     The Known World                                    0                 22
NULL                                               1                  Sothoryos                                          0                     The Known World                                    0                 2
NULL                                               1                  Westeros                                           0                     The Known World                                    0                 124
Asshai, the Jade Sea, and lands of the far east    0                  Essos                                              0                     The Known World                                    0                 4
Bay of Dragons                                     0                  Essos                                              0                     The Known World                                    0                 3
...
*/

-- rename NULL to UNKNOWN or ALL according the context
SELECT
	ISNULL(RegionName,    CASE WHEN GROUPING(RegionName)    = 1 THEN '<ALL>' ELSE '<UNKNOWN>' END) as RegionName,
	ISNULL(ContinentName, CASE WHEN GROUPING(ContinentName) = 1 THEN '<ALL>' ELSE '<UNKNOWN>' END) as ContinentName,
	ISNULL(WorldName,     CASE WHEN GROUPING(WorldName)     = 1 THEN '<ALL>' ELSE '<UNKNOWN>' END) as WorldName,
	count(*) as CountByGroup
FROM
	dbo.GoT_POI
GROUP BY GROUPING SETS (
	(WorldName),
	(WorldName, ContinentName),
	(WorldName, ContinentName, RegionName)
	)
ORDER BY
	RegionName,
	ContinentName,
	WorldName;
/*
RegionName                                         ContinentName                                      WorldName                                          CountByGroup
-------------------------------------------------- -------------------------------------------------- -------------------------------------------------- ------------
<ALL>                                              <ALL>                                              The Known World                                    148
<ALL>                                              Essos                                              The Known World                                    22
<ALL>                                              Sothoryos                                          The Known World                                    2
<ALL>                                              Westeros                                           The Known World                                    124
Asshai, the Jade Sea, and lands of the far east    Essos                                              The Known World                                    4
Bay of Dragons                                     Essos                                              The Known World                                    3
...
*/

-- bring rows in a logical order
SELECT
	ISNULL(RegionName,    CASE WHEN GROUPING(RegionName)    = 1 THEN '<ALL>' ELSE '<UNKNOWN>' END) as RegionName,
	ISNULL(ContinentName, CASE WHEN GROUPING(ContinentName) = 1 THEN '<ALL>' ELSE '<UNKNOWN>' END) as ContinentName,
	ISNULL(WorldName,     CASE WHEN GROUPING(WorldName)     = 1 THEN '<ALL>' ELSE '<UNKNOWN>' END) as WorldName,
	count(*) as CountByGroup
FROM
	dbo.GoT_POI
GROUP BY GROUPING SETS (
	(WorldName),
	(WorldName, ContinentName),
	(WorldName, ContinentName, RegionName)
	)
ORDER BY
	WorldName,
	ContinentName,
	RegionName;
/*
RegionName                                         ContinentName                                      WorldName                                          CountByGroup
-------------------------------------------------- -------------------------------------------------- -------------------------------------------------- ------------
<ALL>                                              <ALL>                                              The Known World                                    148
<ALL>                                              Essos                                              The Known World                                    22
Asshai, the Jade Sea, and lands of the far east    Essos                                              The Known World                                    4
Bay of Dragons                                     Essos                                              The Known World                                    3
...
*/

-- showing the aggregations at the end of each block
SELECT
	ISNULL(RegionName,    CASE WHEN GROUPING(RegionName)    = 1 THEN '<ALL>' ELSE '<UNKNOWN>' END) as RegionName,
	ISNULL(ContinentName, CASE WHEN GROUPING(ContinentName) = 1 THEN '<ALL>' ELSE '<UNKNOWN>' END) as ContinentName,
	ISNULL(WorldName,     CASE WHEN GROUPING(WorldName)     = 1 THEN '<ALL>' ELSE '<UNKNOWN>' END) as WorldName,
	count(*) as CountByGroup
FROM
	dbo.GoT_POI
GROUP BY GROUPING SETS (
	(WorldName),
	(WorldName, ContinentName),
	(WorldName, ContinentName, RegionName)
	)
ORDER BY
	ISNULL(WorldName,     CASE WHEN GROUPING(WorldName)     = 1 THEN MAX(WorldName)    +'a' ELSE NULL END),
	ISNULL(ContinentName, CASE WHEN GROUPING(ContinentName) = 1 THEN MAX(ContinentName)+'a' ELSE NULL END),
	ISNULL(RegionName,    CASE WHEN GROUPING(RegionName)    = 1 THEN MAX(RegionName)   +'a' ELSE NULL END);
/*
RegionName                                         ContinentName                                      WorldName                                          CountByGroup
-------------------------------------------------- -------------------------------------------------- -------------------------------------------------- ------------
Asshai, the Jade Sea, and lands of the far east    Essos                                              The Known World                                    4
Bay of Dragons                                     Essos                                              The Known World                                    3
Dothraki Sea                                       Essos                                              The Known World                                    1
Lhazar                                             Essos                                              The Known World                                    1
Qarth                                              Essos                                              The Known World                                    1
The Free Cities                                    Essos                                              The Known World                                    9
The Red Waste                                      Essos                                              The Known World                                    1
The Rhoyne River                                   Essos                                              The Known World                                    1
Valyrian Peninsula                                 Essos                                              The Known World                                    1
<ALL>                                              Essos                                              The Known World                                    22
*/

-- slimming down the columns
SELECT
	CASE
		WHEN GROUPING(RegionName)		= 0 THEN RegionName
		WHEN GROUPING(ContinentName)    = 0 THEN '* SUBTOTAL (' + ContinentName + ')'
		WHEN GROUPING(WorldName)		= 0 THEN '** TOTAL (' + WorldName + ')'
		ELSE									 '<UNKNOWN>'
		END as Name,
	count(*) as POICounter
FROM
	dbo.GoT_POI
GROUP BY GROUPING SETS (
	(WorldName),
	(WorldName, ContinentName),
	(WorldName, ContinentName, RegionName)
	)
ORDER BY
	ISNULL(WorldName,     CASE WHEN GROUPING(WorldName)     = 0 THEN NULL ELSE MAX(WorldName)    +'a' END),
	ISNULL(ContinentName, CASE WHEN GROUPING(ContinentName) = 0 THEN NULL ELSE MAX(ContinentName)+'a' END),
	ISNULL(RegionName,    CASE WHEN GROUPING(RegionName)    = 0 THEN NULL ELSE MAX(RegionName)   +'a' END);
/*
Name                                                            POICounter
--------------------------------------------------------------- -----------
Asshai, the Jade Sea, and lands of the far east                 4
Bay of Dragons                                                  3
Dothraki Sea                                                    1
Lhazar                                                          1
Qarth                                                           1
The Free Cities                                                 9
The Red Waste                                                   1
The Rhoyne River                                                1
Valyrian Peninsula                                              1
* SUBTOTAL (Essos)                                              22
...
*/