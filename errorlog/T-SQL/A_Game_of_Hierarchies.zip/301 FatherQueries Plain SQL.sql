/* A Game of Hierarchies
 * Father Queries Plain SQL
 * (c) Markus Ehrenmueller-Jensen
 */

use AdventureWorksDW2014
go

--
--Children of a Edward Stark
--

--Edward Stark himself
SELECT
	ID, FirstName, FatherID
FROM
	dbo.GoT_Family
WHERE
	ID = 116 --Edward Stark
/*
ID          FirstName                                          FatherID
----------- -------------------------------------------------- -----------
116         Eddard                                             114
*/

--plain SQL
SELECT
	ID, FirstName, FatherID
FROM
	dbo.GoT_Family
WHERE
	FatherID = 116 --Edward Stark
/*
ID          FirstName                                          FatherID
----------- -------------------------------------------------- -----------
118         Robb                                               116
120         Sansa                                              116
121         Arya                                               116
122         Brandon                                            116
123         Rickon                                             116
124         John                                               116
*/

--including Father
SELECT
	ID, FirstName, 1 Lvl, FatherID
FROM
	dbo.GoT_Family
WHERE
	ID = 116 --Edward Stark

UNION ALL

SELECT
	ID, ' | ' + FirstName, 2 Lvl, FatherID
FROM
	dbo.GoT_Family
WHERE
	FatherID = 116 --Edward Stark
/*
ID          FirstName                                             Lvl         FatherID
----------- ----------------------------------------------------- ----------- -----------
116         Eddard                                                1           114
118          | Robb                                               2           116
120          | Sansa                                              2           116
121          | Arya                                               2           116
122          | Brandon                                            2           116
123          | Rickon                                             2           116
124          | John                                               2           116
*/

--
--Tree of Family Stark
--

--plain SQL
SELECT
	ID, FirstName, 1 Lvl, FatherID
FROM
	dbo.GoT_Family
WHERE
	ID = 100 --Benjen Stark

UNION ALL

SELECT
	ID, ' | ' + FirstName, 2 Lvl, FatherID
FROM
	dbo.GoT_Family
WHERE
	FatherID = 100 --Benjen Stark

UNION ALL

SELECT
	ID, ' |  | ' + FirstName, 3 Lvl, FatherID
FROM
	dbo.GoT_Family
WHERE
	FatherID = 102 --Rickon Stark
/*
ID          FirstName                                                Lvl         FatherID
----------- -------------------------------------------------------- ----------- -----------
100         Benjen                                                   1           NULL
102          | Rickon                                                2           100
104          |  | Cregan                                             3           102
*/