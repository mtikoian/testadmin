use AdventureWorksDW2014
go

IF OBJECT_ID(N'dbo.GoT_Family', N'U') IS NOT NULL DROP TABLE dbo.GoT_Family;
GO
CREATE TABLE dbo.GoT_Family (
ID			int NOT NULL,
FirstName	varchar(50),
LastName	varchar(50),
Titles		varchar(255),
Sex			char(1),
FatherID	int,
MotherID	int,
FatherLvl	int,
MotherLvl	int,
FatherPath	varchar(255),
MotherPath	varchar(255),
FatherHID	hierarchyid,
MotherHID	hierarchyid,
CHECK (ID <> FatherID), --no one can be his own father
CHECK (ID <> MotherID)  --no one can be his own mother
)
GO
--depth-first & breadth-first indexes
CREATE UNIQUE CLUSTERED INDEX idx_GoT_Family_depth_first_Father ON dbo.GoT_Family(FatherPath);
CREATE UNIQUE INDEX idx_GoT_Family_depth_first_Mother ON dbo.GoT_Family(MotherPath);
CREATE UNIQUE INDEX idx_GoT_Family_breadth_first_Father ON dbo.GoT_Family(FatherLvl, FatherPath);
CREATE UNIQUE INDEX idx_GoT_Family_breadth_first_Mother ON dbo.GoT_Family(MotherLvl, MotherPath);
ALTER TABLE dbo.GoT_Family 
	ADD CONSTRAINT PK_GoT_Family 
		PRIMARY KEY NONCLUSTERED(ID);

IF OBJECT_ID(N'dbo.AddGoT_Family', N'P') IS NOT NULL DROP PROC dbo.AddGoT_Family;
GO
CREATE PROC dbo.AddGoT_Family
@ID			int,
@FirstName	varchar(50),
@LastName	varchar(50),
@Titles		varchar(255),
@Sex		char(1),
@FatherID	int,
@MotherID	int
AS

SET NOCOUNT ON;

DECLARE
  @FatherPath			varchar(255),
  @MotherPath			varchar(255),
  @FatherHID			AS HIERARCHYID,
  @MotherHID			AS HIERARCHYID,
  @FathersHID			AS HIERARCHYID,
  @MothersHID			AS HIERARCHYID,
  @FathersLastChildHID	AS HIERARCHYID,
  @MothersLastChildHID	AS HIERARCHYID;

BEGIN TRAN;

IF @FatherID IS NULL
BEGIN
  SET @FatherPath = '.' + CAST(@ID AS VARCHAR(10)) + '.';
  SET @FatherHID = hierarchyid::GetRoot().GetDescendant((select MAX(FatherHID) from dbo.GoT_Family where FatherHID.GetAncestor(1) = hierarchyid::GetRoot()), NULL);
END
ELSE
BEGIN
  SET @FathersHID = (SELECT FatherHID FROM dbo.GoT_Family WITH (UPDLOCK) WHERE ID = @FatherID);
  SET @FathersLastChildHID = (SELECT MAX(FatherHID) FROM dbo.GoT_Family WHERE FatherHID.GetAncestor(1) = @FathersHID);
  SET @FatherHID = @FathersHID.GetDescendant(@FathersLastChildHID, NULL);
END

IF @MotherID IS NULL
BEGIN
  SET @MotherPath = '.' + CAST(@ID AS VARCHAR(10)) + '.';
  SET @MotherHID = hierarchyid::GetRoot().GetDescendant((select MAX(MotherHID) from dbo.GoT_Family where MotherHID.GetAncestor(1) = hierarchyid::GetRoot()), NULL);
END
ELSE
BEGIN
  SET @MothersHID = (SELECT MotherHID FROM dbo.GoT_Family WITH (UPDLOCK) WHERE ID = @MotherID);
  SET @MothersLastChildHID = (SELECT MAX(MotherHID) FROM dbo.GoT_Family WHERE MotherHID.GetAncestor(1) = @MothersHID);
  SET @MotherHID = @MothersHID.GetDescendant(@MothersLastChildHID, NULL);
END
-- Handle case where the new GoT has no ascendant (root)
IF @FatherID IS NULL and @MotherID IS NULL
  INSERT INTO dbo.GoT_Family(ID, FirstName, LastName, Titles, Sex, FatherID, MotherID, FatherLvl, MotherLvl, FatherPath, MotherPath, FatherHID, MotherHID)
    VALUES(@ID, @Firstname, @LastName, @Titles, @Sex, @FatherID, @MotherID, 
      0, 0, '.' + CAST(@ID AS VARCHAR(10)) + '.', '.' + CAST(@ID AS VARCHAR(10)) + '.',
	  @FatherHID, @MotherHID);
-- Handle descendants case (non-root)
ELSE
  INSERT INTO dbo.GoT_Family(ID, FirstName, LastName, Titles, Sex, FatherID, MotherID, FatherLvl, MotherLvl, FatherPath, MotherPath, FatherHID, MotherHID)
  SELECT @ID, @Firstname, @LastName, @Titles, @Sex, @FatherID, @MotherID, 
	MAX(ISNULL(x.FatherLvl, 0)), 
	MAX(ISNULL(x.MotherLvl, 0)), 
	ISNULL(@FatherPath, MAX(ISNULL(x.FatherPath, '.'))), 
	ISNULL(@MotherPath, MAX(ISNULL(x.MotherPath, '.'))), 
	@FatherHID, @MotherHID
  FROM (
    SELECT FatherLvl + 1 FatherLvl, null MotherLvl, FatherPath + CAST(@ID AS VARCHAR(10)) + '.' FatherPath, null MotherPath
    FROM dbo.GoT_Family
    WHERE ID = @FatherID
	UNION ALL
    SELECT null FatherLvl, MotherLvl + 1 MotherLvl, null FatherPath, MotherPath + CAST(@ID AS VARCHAR(10)) + '.' MotherPath
    FROM dbo.GoT_Family
    WHERE ID = @MotherID
	) x;

COMMIT;

GO

exec dbo.AddGoT_Family
@ID			= 100,
@FirstName	= 'Benjen',
@LastName	= 'Stark',
@Titles		= '',
@Sex		= 'M',
@FatherID	= null,
@MotherID	= null

exec dbo.AddGoT_Family
@ID			= 101,
@FirstName	= 'Lysa',
@LastName	= 'Locke',
@Titles		= '',
@Sex		= 'F',
@FatherID	= null,
@MotherID	= null

exec dbo.AddGoT_Family
@ID			= 102,
@FirstName	= 'Rickon',
@LastName	= 'Stark',
@Titles		= '',
@Sex		= 'M',
@FatherID	= 100,
@MotherID	= 101

exec dbo.AddGoT_Family
@ID			= 103,
@FirstName	= 'Gilliane',
@LastName	= 'Glover',
@Titles		= '',
@Sex		= 'F',
@FatherID	= null,
@MotherID	= null

exec dbo.AddGoT_Family
@ID			= 104,
@FirstName	= 'Cregan',
@LastName	= 'Stark',
@Titles		= 'The Old Man Of The North',
@Sex		= 'M',
@FatherID	= 102,
@MotherID	= 103

exec dbo.AddGoT_Family
@ID			= 105,
@FirstName	= 'Lynara',
@LastName	= 'Stark',
@Titles		= '',
@Sex		= 'F',
@FatherID	= null,
@MotherID	= null

exec dbo.AddGoT_Family
@ID			= 106,
@FirstName	= 'Brandon',
@LastName	= 'Stark',
@Titles		= '',
@Sex		= 'M',
@FatherID	= 104,
@MotherID	= 105

exec dbo.AddGoT_Family
@ID			= 107,
@FirstName	= 'Alys',
@LastName	= 'Karstark',
@Titles		= '',
@Sex		= 'F',
@FatherID	= null,
@MotherID	= null

exec dbo.AddGoT_Family
@ID			= 108,
@FirstName	= 'Beron',
@LastName	= 'Stark',
@Titles		= '',
@Sex		= 'M',
@FatherID	= 106,
@MotherID	= 107

exec dbo.AddGoT_Family
@ID			= 109,
@FirstName	= 'Lorra',
@LastName	= 'Royce',
@Titles		= '',
@Sex		= 'F',
@FatherID	= null,
@MotherID	= null

exec dbo.AddGoT_Family
@ID			= 110,
@FirstName	= 'William',
@LastName	= 'Stark',
@Titles		= '',
@Sex		= 'M',
@FatherID	= 108,
@MotherID	= 109

exec dbo.AddGoT_Family
@ID			= 111,
@FirstName	= 'Melantha',
@LastName	= 'Blackwood',
@Titles		= '',
@Sex		= 'F',
@FatherID	= null,
@MotherID	= null

exec dbo.AddGoT_Family
@ID			= 112,
@FirstName	= 'Edwyle',
@LastName	= 'Stark',
@Titles		= '',
@Sex		= 'M',
@FatherID	= 110,
@MotherID	= 111

exec dbo.AddGoT_Family
@ID			= 113,
@FirstName	= 'Marna',
@LastName	= 'Locke',
@Titles		= '',
@Sex		= 'F',
@FatherID	= null,
@MotherID	= null

exec dbo.AddGoT_Family
@ID			= 114,
@FirstName	= 'Rickard',
@LastName	= 'Stark',
@Titles		= '',
@Sex		= 'M',
@FatherID	= 112,
@MotherID	= 113

exec dbo.AddGoT_Family
@ID			= 115,
@FirstName	= 'Lyarra',
@LastName	= 'Stark',
@Titles		= '',
@Sex		= 'F',
@FatherID	= null,
@MotherID	= null

exec dbo.AddGoT_Family
@ID			= 116,
@FirstName	= 'Eddard',
@LastName	= 'Stark',
@Titles		= '',
@Sex		= 'M',
@FatherID	= 114,
@MotherID	= 115

--
exec dbo.AddGoT_Family
@ID			= 132,
@FirstName	= '???',
@LastName	= 'Tully',
@Titles		= '',
@Sex		= 'M',
@FatherID	= null,
@MotherID	= null

exec dbo.AddGoT_Family
@ID			= 130,
@FirstName	= 'Hoster',
@LastName	= 'Tully',
@Titles		= '',
@Sex		= 'M',
@FatherID	= 132,
@MotherID	= null

exec dbo.AddGoT_Family
@ID			= 131,
@FirstName	= 'Minisa',
@LastName	= 'Whent',
@Titles		= '',
@Sex		= 'M',
@FatherID	= null,
@MotherID	= null
--

exec dbo.AddGoT_Family
@ID			= 117,
@FirstName	= 'Catelyn',
@LastName	= 'Tully',
@Titles		= 'Lady Stoneheart',
@Sex		= 'F',
@FatherID	= 130,
@MotherID	= 131

exec dbo.AddGoT_Family
@ID			= 118,
@FirstName	= 'Robb',
@LastName	= 'Stark',
@Titles		= 'The Young Wolf',
@Sex		= 'M',
@FatherID	= 116,
@MotherID	= 117

exec dbo.AddGoT_Family
@ID			= 119,
@FirstName	= 'Jayne',
@LastName	= 'Westerling',
@Titles		= '',
@Sex		= 'F',
@FatherID	= null,
@MotherID	= null

exec dbo.AddGoT_Family
@ID			= 120,
@FirstName	= 'Sansa',
@LastName	= 'Stark',
@Titles		= '',
@Sex		= 'F',
@FatherID	= 116,
@MotherID	= 117

exec dbo.AddGoT_Family
@ID			= 121,
@FirstName	= 'Arya',
@LastName	= 'Stark',
@Titles		= '',
@Sex		= 'F',
@FatherID	= 116,
@MotherID	= 117

exec dbo.AddGoT_Family
@ID			= 122,
@FirstName	= 'Brandon',
@LastName	= 'Stark',
@Titles		= '',
@Sex		= 'M',
@FatherID	= 116,
@MotherID	= 117

exec dbo.AddGoT_Family
@ID			= 123,
@FirstName	= 'Rickon',
@LastName	= 'Stark',
@Titles		= '',
@Sex		= 'M',
@FatherID	= 116,
@MotherID	= 117

exec dbo.AddGoT_Family
@ID			= 124,
@FirstName	= 'John',
@LastName	= 'Snow',
@Titles		= '',
@Sex		= 'M',
@FatherID	= 116,
@MotherID	= null

ALTER TABLE dbo.GoT_Family
  ADD CONSTRAINT FK_GoT_Family_Father
    FOREIGN KEY(FatherID) REFERENCES dbo.GoT_Family(ID);
ALTER TABLE dbo.GoT_Family
  ADD CONSTRAINT FK_GoT_Family_Mother
    FOREIGN KEY(MotherID) REFERENCES dbo.GoT_Family(ID);

SELECT * FROM dbo.GoT_Family;

