use AdventureWorksDW2014
go

IF OBJECT_ID(N'dbo.GoT_POI', N'U') IS NOT NULL DROP TABLE dbo.GoT_POI;
IF OBJECT_ID(N'dbo.GoT_Region', N'U') IS NOT NULL DROP TABLE dbo.GoT_Region;
IF OBJECT_ID(N'dbo.GoT_Continent', N'U') IS NOT NULL DROP TABLE dbo.GoT_Continent;
IF OBJECT_ID(N'dbo.GoT_World', N'U') IS NOT NULL DROP TABLE dbo.GoT_World;
GO
CREATE TABLE dbo.GoT_World (
ID				int NOT NULL,
WorldName		nvarchar(50)
)
ALTER TABLE dbo.GoT_World ADD CONSTRAINT PK_GoT_World PRIMARY KEY NONCLUSTERED(ID);

GO
CREATE TABLE dbo.GoT_Continent (
ID				int NOT NULL,
ContinentName	nvarchar(50),
WorldID			int
)
ALTER TABLE dbo.GoT_Continent ADD CONSTRAINT PK_GoT_Continent PRIMARY KEY NONCLUSTERED(ID);
ALTER TABLE dbo.GoT_Continent
  ADD CONSTRAINT FK_GoT_Continent_World
    FOREIGN KEY(WorldID) REFERENCES dbo.GoT_World(ID);

GO
CREATE TABLE dbo.GoT_Region (
ID				int NOT NULL,
RegionName		nvarchar(50),
ContinentID		int
)
ALTER TABLE dbo.GoT_Region ADD CONSTRAINT PK_GoT_Region PRIMARY KEY NONCLUSTERED(ID);
ALTER TABLE dbo.GoT_Region
  ADD CONSTRAINT FK_GoT_Region_Continent
    FOREIGN KEY(ContinentID) REFERENCES dbo.GoT_Continent(ID);

GO
CREATE TABLE dbo.GoT_POI (
ID				int NOT NULL,
POIName			nvarchar(50),
RegionName		nvarchar(50),
ContinentName	nvarchar(50),
WorldName		nvarchar(50),
RegionID		int,
ContinentID		int,
WorldID			int
)
ALTER TABLE dbo.GoT_POI ADD CONSTRAINT PK_GoT_POI PRIMARY KEY NONCLUSTERED(ID);
ALTER TABLE dbo.GoT_POI
  ADD CONSTRAINT FK_GoT_POI_Region
    FOREIGN KEY(RegionID) REFERENCES dbo.GoT_Region(ID);
ALTER TABLE dbo.GoT_POI
  ADD CONSTRAINT FK_GoT_POI_Continent
    FOREIGN KEY(ContinentID) REFERENCES dbo.GoT_Continent(ID);
ALTER TABLE dbo.GoT_POI
  ADD CONSTRAINT FK_GoT_POI_World
    FOREIGN KEY(WorldID) REFERENCES dbo.GoT_World(ID);


--DATA
INSERT INTO dbo.GoT_World (ID, WorldName)
VALUES	(1, 'The Known World')

INSERT INTO dbo.GoT_Continent (ID, ContinentName, WorldID)
VALUES	(1, 'Westeros', 1),
		(2, 'Essos', 1),
		(3, 'Sothoryos', 1)

INSERT INTO dbo.GoT_Region (ID, RegionName, ContinentID)
VALUES	(1, 'The North', 1),
		(2, 'The Vale of Arryn', 1),
		(3, 'The Riverlands', 1),
		(4, 'The Westerlands', 1),
		(5, 'The Iron Islands', 1),
		(6, 'The Crownlands', 1),
		(7, 'The Stormlands', 1),
		(8, 'The Reach', 1),
		(9, 'Dorne', 1),
		(10, 'Beyond the Wall', 1),
		(11, 'The Free Cities', 2),
		(12, 'The Rhoyne River', 2),
		(13, 'Valyrian Peninsula', 2),
		(14, 'Bay of Dragons', 2),
		(15, 'Dothraki Sea', 2),
		(16, 'Lhazar', 2),
		(17, 'The Red Waste', 2),
		(18, 'Qarth', 2),
		(19, 'Asshai, the Jade Sea, and lands of the far east', 2),
		(20, 'Summer Islands', 3)

INSERT INTO dbo.GoT_POI (ID, POIName, RegionName, ContinentName, WorldName, RegionID, ContinentID, WorldID)
VALUES	(1, 'Winterfell', 'The North', 'Westeros', 'The Known World', 1, 1, 1),
		(2, 'Bear Island', 'The North', 'Westeros', 'The Known World', 1, 1, 1),
		(3, 'Castle Cerwyn', 'The North', 'Westeros', 'The Known World', 1, 1, 1),
		(4, 'Deepwood Motte', 'The North', 'Westeros', 'The Known World', 1, 1, 1),
		(5, 'The Dreadfort', 'The North', 'Westeros', 'The Known World', 1, 1, 1),
		(6, 'Greywater Watch', 'The North', 'Westeros', 'The Known World', 1, 1, 1),
		(7, 'The Hornwood', 'The North', 'Westeros', 'The Known World', 1, 1, 1),
		(8, 'Karhold', 'The North', 'Westeros', 'The Known World', 1, 1, 1),
		(9, 'Last Hearth', 'The North', 'Westeros', 'The Known World', 1, 1, 1),
		(10, 'Torrhen''s Square', 'The North', 'Westeros', 'The Known World', 1, 1, 1),
		(11, 'White Harbor', 'The North', 'Westeros', 'The Known World', 1, 1, 1),
		(12, 'Flint''s Finger', 'The North', 'Westeros', 'The Known World', 1, 1, 1),
		(13, 'Moat Cailin', 'The North', 'Westeros', 'The Known World', 1, 1, 1),
		(14, 'Barrowton', 'The North', 'Westeros', 'The Known World', 1, 1, 1),
		(15, 'Oldcastle', 'The North', 'Westeros', 'The Known World', 1, 1, 1),
		(16, 'Ramsgate', 'The North', 'Westeros', 'The Known World', 1, 1, 1),
		(17, 'Widow''s Watch', 'The North', 'Westeros', 'The Known World', 1, 1, 1),
		(18, 'Ironrath', 'The North', 'Westeros', 'The Known World', 1, 1, 1),
		(19, 'Highpoint', 'The North', 'Westeros', 'The Known World', 1, 1, 1),
		(20, 'Rillwater Crossing', 'The North', 'Westeros', 'The Known World', 1, 1, 1),
		(22, 'The Eyrie', 'The Vale of Arryn', 'Westeros', 'The Known World', 2, 1, 1),
		(23, 'Bloody Gate', 'The Vale of Arryn', 'Westeros', 'The Known World', 2, 1, 1),
		(24, 'Runestone', 'The Vale of Arryn', 'Westeros', 'The Known World', 2, 1, 1),
		(25, 'Baelish Keep', 'The Vale of Arryn', 'Westeros', 'The Known World', 2, 1, 1),
		(26, 'Redfort', 'The Vale of Arryn', 'Westeros', 'The Known World', 2, 1, 1),
		(27, 'Riverrun', 'The Riverlands', 'Westeros', 'The Known World', 3, 1, 1),
		(28, 'Harrenhal', 'The Riverlands', 'Westeros', 'The Known World', 3, 1, 1),
		(29, 'Raventree Hall', 'The Riverlands', 'Westeros', 'The Known World', 3, 1, 1),
		(30, 'Seagard', 'The Riverlands', 'Westeros', 'The Known World', 3, 1, 1),
		(31, 'Stone Hedge', 'The Riverlands', 'Westeros', 'The Known World', 3, 1, 1),
		(32, 'The Twins', 'The Riverlands', 'Westeros', 'The Known World', 3, 1, 1),
		(33, 'Pinkmaiden', 'The Riverlands', 'Westeros', 'The Known World', 3, 1, 1),
		(34, 'Acorn Hall', 'The Riverlands', 'Westeros', 'The Known World', 3, 1, 1),
		(35, 'Casterly Rock', 'The Westerlands', 'Westeros', 'The Known World', 4, 1, 1),
		(36, 'Ashemark', 'The Westerlands', 'Westeros', 'The Known World', 4, 1, 1),
		(37, 'The Crag', 'The Westerlands', 'Westeros', 'The Known World', 4, 1, 1),
		(38, 'Golden Tooth', 'The Westerlands', 'Westeros', 'The Known World', 4, 1, 1),
		(39, 'Lannisport', 'The Westerlands', 'Westeros', 'The Known World', 4, 1, 1),
		(40, 'Clegan''s Keep', 'The Westerlands', 'Westeros', 'The Known World', 4, 1, 1),
		(41, 'Crakehall', 'The Westerlands', 'Westeros', 'The Known World', 4, 1, 1),
		(42, 'Cornfield', 'The Westerlands', 'Westeros', 'The Known World', 4, 1, 1),
		(43, 'Banefort', 'The Westerlands', 'Westeros', 'The Known World', 4, 1, 1),
		(44, 'Deep Den', 'The Westerlands', 'Westeros', 'The Known World', 4, 1, 1),
		(45, 'Silverhall', 'The Westerlands', 'Westeros', 'The Known World', 4, 1, 1),
		(46, 'Hornvale', 'The Westerlands', 'Westeros', 'The Known World', 4, 1, 1),
		(47, 'Sarsfield', 'The Westerlands', 'Westeros', 'The Known World', 4, 1, 1),
		(48, 'Feastfires', 'The Westerlands', 'Westeros', 'The Known World', 4, 1, 1),
		(49, 'Faircastle', 'The Westerlands', 'Westeros', 'The Known World', 4, 1, 1),
		(50, 'Oxcross', 'The Westerlands', 'Westeros', 'The Known World', 4, 1, 1),
		(51, 'Castamere', 'The Westerlands', 'Westeros', 'The Known World', 4, 1, 1),
		(52, 'Pyke', 'Iron Islands', 'Westeros', 'The Known World', 5, 1, 1),
		(53, 'Lordsport', 'Iron Islands', 'Westeros', 'The Known World', 5, 1, 1),
		(54, 'Ten Towers', 'Iron Islands', 'Westeros', 'The Known World', 5, 1, 1),
		(55, 'Red Harbor', 'Iron Islands', 'Westeros', 'The Known World', 5, 1, 1),
		(56, 'King''s Landing', 'The Crownlands', 'Westeros', 'The Known World', 6, 1, 1),
		(57, 'The Red Keep', 'The Crownlands', 'Westeros', 'The Known World', 6, 1, 1),
		(58, 'Duskendale', 'The Crownlands', 'Westeros', 'The Known World', 6, 1, 1),
		(59, 'Rosby', 'The Crownlands', 'Westeros', 'The Known World', 6, 1, 1),
		(60, 'Castle Stokeworth', 'The Crownlands', 'Westeros', 'The Known World', 6, 1, 1),
		(61, 'Antlers', 'The Crownlands', 'Westeros', 'The Known World', 6, 1, 1),
		(62, 'Sow''s Horn', 'The Crownlands', 'Westeros', 'The Known World', 6, 1, 1),
		(63, 'Rook''s Rest', 'The Crownlands', 'Westeros', 'The Known World', 6, 1, 1),
		(64, 'The Whispers', 'The Crownlands', 'Westeros', 'The Known World', 6, 1, 1),
		(65, 'Dragonstone', 'The Crownlands', 'Westeros', 'The Known World', 6, 1, 1),
		(66, 'Sharp Point', 'The Crownlands', 'Westeros', 'The Known World', 6, 1, 1),
		(67, 'Stonedance', 'The Crownlands', 'Westeros', 'The Known World', 6, 1, 1),
		(68, 'Storm''s End', 'The Stormlands', 'Westeros', 'The Known World', 7, 1, 1),
		(69, 'Haystack Hall', 'The Stormlands', 'Westeros', 'The Known World', 7, 1, 1),
		(70, 'Bronzegate', 'The Stormlands', 'Westeros', 'The Known World', 7, 1, 1),
		(71, 'Felwood', 'The Stormlands', 'Westeros', 'The Known World', 7, 1, 1),
		(72, 'Evenfall Hall', 'The Stormlands', 'Westeros', 'The Known World', 7, 1, 1),
		(73, 'Rain House', 'The Stormlands', 'Westeros', 'The Known World', 7, 1, 1),
		(74, 'Mistwood', 'The Stormlands', 'Westeros', 'The Known World', 7, 1, 1),
		(75, 'Stonehelm', 'The Stormlands', 'Westeros', 'The Known World', 7, 1, 1),
		(76, 'Griffin''s Roost', 'The Stormlands', 'Westeros', 'The Known World', 7, 1, 1),
		(77, 'Nightsong', 'The Stormlands', 'Westeros', 'The Known World', 7, 1, 1),
		(78, 'Blackhaven', 'The Stormlands', 'Westeros', 'The Known World', 7, 1, 1),
		(79, 'Crow''s Nest', 'The Stormlands', 'Westeros', 'The Known World', 7, 1, 1),
		(80, 'Summerhall', 'The Stormlands', 'Westeros', 'The Known World', 7, 1, 1),
		(81, 'Highgarden', 'The Reach', 'Westeros', 'The Known World', 8, 1, 1),
		(82, 'Oldtown', 'The Reach', 'Westeros', 'The Known World', 8, 1, 1),
		(83, 'Brightwater Keep', 'The Reach', 'Westeros', 'The Known World', 8, 1, 1),
		(84, 'Bitterbridge', 'The Reach', 'Westeros', 'The Known World', 8, 1, 1),
		(85, 'Grassy Vale', 'The Reach', 'Westeros', 'The Known World', 8, 1, 1),
		(86, 'Long Table', 'The Reach', 'Westeros', 'The Known World', 8, 1, 1),
		(87, 'Cider Hall', 'The Reach', 'Westeros', 'The Known World', 8, 1, 1),
		(88, 'Goldengrove', 'The Reach', 'Westeros', 'The Known World', 8, 1, 1),
		(89, 'Red Lake', 'The Reach', 'Westeros', 'The Known World', 8, 1, 1),
		(90, 'Old Oak', 'The Reach', 'Westeros', 'The Known World', 8, 1, 1),
		(91, 'Horn Hill', 'The Reach', 'Westeros', 'The Known World', 8, 1, 1),
		(92, 'Uplands', 'The Reach', 'Westeros', 'The Known World', 8, 1, 1),
		(93, 'Honeyholt', 'The Reach', 'Westeros', 'The Known World', 8, 1, 1),
		(94, 'Sun House', 'The Reach', 'Westeros', 'The Known World', 8, 1, 1),
		(95, 'Three Towers', 'The Reach', 'Westeros', 'The Known World', 8, 1, 1),
		(96, 'Blackcrown', 'The Reach', 'Westeros', 'The Known World', 8, 1, 1),
		(97, 'Bandallon', 'The Reach', 'Westeros', 'The Known World', 8, 1, 1),
		(98, 'Sunspear', 'Dorne', 'Westeros', 'The Known World', 9, 1, 1),
		(99, 'Planky Town', 'Dorne', 'Westeros', 'The Known World', 9, 1, 1),
		(100, 'Blackmont', 'Dorne', 'Westeros', 'The Known World', 9, 1, 1),
		(101, 'Starfall', 'Dorne', 'Westeros', 'The Known World', 9, 1, 1),
		(102, 'Kingsgrave', 'Dorne', 'Westeros', 'The Known World', 9, 1, 1),
		(103, 'Vulture''s Roost', 'Dorne', 'Westeros', 'The Known World', 9, 1, 1),
		(104, 'Wyl', 'Dorne', 'Westeros', 'The Known World', 9, 1, 1),
		(105, 'Yronwood', 'Dorne', 'Westeros', 'The Known World', 9, 1, 1),
		(106, 'Sandstone', 'Dorne', 'Westeros', 'The Known World', 9, 1, 1),
		(107, 'Hellholt', 'Dorne', 'Westeros', 'The Known World', 9, 1, 1),
		(108, 'The Tor', 'Dorne', 'Westeros', 'The Known World', 9, 1, 1),
		(109, 'Vaith', 'Dorne', 'Westeros', 'The Known World', 9, 1, 1),
		(110, 'Godsgrace', 'Dorne', 'Westeros', 'The Known World', 9, 1, 1),
		(111, 'Saltshore', 'Dorne', 'Westeros', 'The Known World', 9, 1, 1),
		(112, 'Lemonwood', 'Dorne', 'Westeros', 'The Known World', 9, 1, 1),
		(113, 'Ghost Hill', 'Dorne', 'Westeros', 'The Known World', 9, 1, 1),
		(114, 'The Water Gardens', 'Dorne', 'Westeros', 'The Known World', 9, 1, 1),
		(115, 'Haunted Forest', 'Beyond the Wall', 'Westeros', 'The Known World', 10, 1, 1),
		(116, 'Fist of the First Man', 'Beyond the Wall', 'Westeros', 'The Known World', 10, 1, 1),
		(117, 'Frostfangs', 'Beyond the Wall', 'Westeros', 'The Known World', 10, 1, 1),
		(118, 'Milkwater', 'Beyond the Wall', 'Westeros', 'The Known World', 10, 1, 1),
		(119, 'Lands of Always Winter', 'Beyond the Wall', 'Westeros', 'The Known World', 10, 1, 1),
		(120, 'Frozen Shore', 'Beyond the Wall', 'Westeros', 'The Known World', 10, 1, 1),
		(121, 'Storrold''s Point', 'Beyond the Wall', 'Westeros', 'The Known World', 10, 1, 1),
		(122, 'The Valley of the Thenn', 'Beyond the Wall', 'Westeros', 'The Known World', 10, 1, 1),
		(123, 'The Cave of the three-eyed raven', 'Beyond the Wall', 'Westeros', 'The Known World', 10, 1, 1),
		(124, 'Hardhome', 'Beyond the Wall', 'Westeros', 'The Known World', 10, 1, 1),
		(125, 'The North Grove', 'Beyond the Wall', 'Westeros', 'The Known World', 10, 1, 1),
		(126, 'Braavos', 'The Free Cities', 'Essos', 'The Known World', 11, 2, 1),
		(127, 'Lorath', 'The Free Cities', 'Essos', 'The Known World', 11, 2, 1),
		(128, 'Lys', 'The Free Cities', 'Essos', 'The Known World', 11, 2, 1),
		(129, 'Myr', 'The Free Cities', 'Essos', 'The Known World', 11, 2, 1),
		(130, 'Norvos', 'The Free Cities', 'Essos', 'The Known World', 11, 2, 1),
		(131, 'Pentos', 'The Free Cities', 'Essos', 'The Known World', 11, 2, 1),
		(132, 'Qohor', 'The Free Cities', 'Essos', 'The Known World', 11, 2, 1),
		(133, 'Tyrosh', 'The Free Cities', 'Essos', 'The Known World', 11, 2, 1),
		(134, 'Volantis', 'The Free Cities', 'Essos', 'The Known World', 11, 2, 1),
		(135, 'The Rhoyne River', 'The Rhoyne River', 'Essos', 'The Known World', 12, 2, 1),
		(136, 'Valyrian Peninsula', 'Valyrian Peninsula', 'Essos', 'The Known World', 13, 2, 1),
		(137, 'Meereen', 'Bay of Dragons', 'Essos', 'The Known World', 14, 2, 1),
		(138, 'Yunkai', 'Bay of Dragons', 'Essos', 'The Known World', 14, 2, 1),
		(139, 'Astapor', 'Bay of Dragons', 'Essos', 'The Known World', 14, 2, 1),
		(140, 'Vaes Dothrak', 'Dothraki Sea', 'Essos', 'The Known World', 15, 2, 1),
		(141, 'Shahadazhan', 'Lhazar', 'Essos', 'The Known World', 16, 2, 1),
		(142, 'The Red Waste', 'The Red Waste', 'Essos', 'The Known World', 17, 2, 1),
		(143, 'Qarth', 'Qarth', 'Essos', 'The Known World', 18, 2, 1),
		(144, 'Asshai', 'Asshai, the Jade Sea, and lands of the far east', 'Essos', 'The Known World', 19, 2, 1),
		(145, 'Yi Ti', 'Asshai, the Jade Sea, and lands of the far east', 'Essos', 'The Known World', 19, 2, 1),
		(146, 'Shadow Lands', 'Asshai, the Jade Sea, and lands of the far east', 'Essos', 'The Known World', 19, 2, 1),
		(147, 'Ibben', 'Asshai, the Jade Sea, and lands of the far east', 'Essos', 'The Known World', 19, 2, 1),
		(148, 'Summer Islands', 'Summer Islands', 'Sothoryos', 'The Known World', 20, 3, 1),
		(149, 'Naath', 'Summer Islands', 'Sothoryos', 'The Known World', 20, 3, 1)

GO

IF OBJECT_ID(N'dbo.BinaryToInteger', N'FN') IS NOT NULL DROP FUNCTION dbo.[BinaryToInteger];
GO
CREATE FUNCTION [dbo].[BinaryToInteger]
--http://improve.dk/converting-between-base-2-10-and-16-in-t-sql/
(
	@Input varchar(255)
)
RETURNS bigint
AS
BEGIN

	DECLARE @Cnt tinyint = 1
	DECLARE @Len tinyint = LEN(@Input)
	DECLARE @Output bigint = CAST(SUBSTRING(@Input, @Len, 1) AS bigint)

	WHILE(@Cnt < @Len) BEGIN
		SET @Output = @Output + POWER(CAST(SUBSTRING(@Input, @Len - @Cnt, 1) * 2 AS bigint), @Cnt)

		SET @Cnt = @Cnt + 1
	END

	RETURN @Output	

END
