USE [IndexBacon];

SELECT BBB.[flavor], BBB.Brand, BBB.City
FROM [dbo].[baconbitsbytes] BBB INNER JOIN dbo.[Distributors] D 
	ON [BBB].[distributor_id] = [D].[id]
	
--This will cause 10 clustered index scans for the clustered index on the BBB primary key column
GO 10

--Turn on Execution Plan:
SELECT BBB.[flavor], BBB.Brand, BBB.City
FROM [dbo].[baconbitsbytes] BBB INNER JOIN dbo.[Distributors] D 
	ON [BBB].[distributor_id] = [D].[id]
WHERE D.[distributor_name] = 'Toys R Us'
	
/*
This will cause 10 clustered index scans for the clustered index on the BBB primary key column
	and 10 index seeks on the distributor_name column in D
*/
GO 10

--====================================================
--Add activity to Brand and City Indexes of BBB table
--====================================================
SELECT DISTINCT [brand]
FROM [dbo].[baconbitsbytes]
ORDER BY [brand];

--Causes an index scan against Brand non-clustered index on BBB table

SELECT [flavor], [brand]
FROM [dbo].[baconbitsbytes]
WHERE [city] = 'Kalamazoo'
ORDER BY [flavor], [brand];

--Causes an clustered index scan against BBB table.  City index not discrete-enough to warrant being used in this fashion.


