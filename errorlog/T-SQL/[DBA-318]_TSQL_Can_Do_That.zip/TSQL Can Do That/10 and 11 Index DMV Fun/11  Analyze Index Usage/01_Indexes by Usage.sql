--=========================================================
--This is how many days of activity are stored in cache:
--=========================================================
SELECT  DATEDIFF(dd, [create_date], GETDATE())
FROM    sys.databases
WHERE   [name] = 'tempdb' ;


--=========================================================
--Return usage results for all indexes in current database
--=========================================================
SELECT  OBJECT_NAME(ixUS.[object_id]) AS [Object Name]
      , S.[name] AS [index name]
      , S.[rowcnt] AS [index rows]
      , ixUS.[user_updates]
      , ixUS.[user_seeks]
      , ixUS.[user_scans]
      , ixUS.[user_lookups]
      , ixUS.[system_updates]
      , ixUS.[system_seeks]
      , ixUS.[system_scans]
      , ixUS.[system_lookups]
FROM    sys.[dm_db_index_usage_stats] ixUS
        INNER JOIN sys.[sysindexes] S
            ON ixUS.[object_id] = S.[id]
               AND ixUS.[index_id] = S.[indid]
WHERE   ixUS.[database_id] = DB_ID()
ORDER BY OBJECT_NAME(ixUS.[object_id])
      , S.[name]
      , ixUS.[user_updates] DESC ;
GO


--=========================================================
--Return results for all indexes not being read, but are written to
--=========================================================
SELECT  OBJECT_NAME(ixUS.[object_id]) AS [Object Name]
      , S.[name] AS [index name]
      , S.[rowcnt] AS [index rows]
      , ixUS.[user_updates]
      , ixUS.[user_seeks] + ixUS.[user_scans] + ixUS.[user_lookups] AS [user_reads]
FROM    sys.[dm_db_index_usage_stats] ixUS
        INNER JOIN [IndexBacon]..[sysindexes] S
            ON ixUS.[object_id] = S.[id]
               AND ixUS.[index_id] = S.[indid]
WHERE   ixUS.[database_id] = DB_ID()
        AND ixUS.[index_id] > 0
        AND ixUS.[user_seeks] + ixUS.[user_scans] + ixUS.[user_lookups] = 0
        AND ixUS.[user_updates] > 0
ORDER BY OBJECT_NAME(ixUS.[object_id])
      , S.[name]
      , ixUS.[user_updates] DESC ;
GO


--=========================================================
--Include generation of drop command
--=========================================================
SELECT  '[' + DB_NAME() + '].[' + SSU.[name] + '].[' + SO.[name] + ']' AS [statement]
      , SI.name AS [index_name]
      , SI.index_id
      , SUM(SP.rows) AS [total_rows]
      , (ixUS.user_seeks + ixUS.user_scans + ixUS.user_lookups) AS [user_reads]
      , ixUS.user_updates AS [user_writes]
      , 'DROP INDEX [' + SI.[name] + '] ON [' + SSU.[name] + '].[' + SO.[name] + '] WITH ( ONLINE = OFF )' AS [drop_command]
FROM    sys.dm_db_index_usage_stats ixUS
        INNER JOIN sys.indexes SI
            ON ixUS.OBJECT_ID = SI.OBJECT_ID
               AND SI.index_id = ixUS.index_id
        INNER JOIN sys.partitions SP
            ON ixUS.OBJECT_ID = SP.OBJECT_ID
               AND SP.index_id = ixUS.index_id
        INNER JOIN sys.objects SO
            ON ixUS.[object_id] = SO.[object_id]
        INNER JOIN sys.sysusers SSU
            ON SO.[schema_id] = SSU.UID
WHERE   OBJECTPROPERTY(ixUS.OBJECT_ID, 'IsUserTable') = 1
        AND ixUS.index_id > 0
        AND ixUS.database_id = DB_ID()
GROUP BY SI.name
      , SI.index_id
      , user_seeks + user_scans + user_lookups
      , user_updates
      , SSU.[name]
      , SO.[name]
HAVING  (ixUS.user_seeks + ixUS.user_scans + ixUS.user_lookups) = 0
ORDER BY SO.[name]
      , SI.[name] ;
GO


--=========================================================
--Estimate storage impact for unused indexes
--=========================================================
WITH    index_space
          AS (
              SELECT    ixPS.object_id
                      , ixPS.index_id
                      , SUM(ixPS.[record_count]) AS [record_count]
                      , SUM(ixPS.[record_count] * ixPS.[avg_record_size_in_bytes]) AS [est_index_size_bytes]
              FROM      sys.[dm_db_index_physical_stats](DB_ID(), NULL, NULL, NULL, 'detailed') ixPS
              GROUP BY  ixPS.[object_id]
                      , ixPS.[index_id]
             )
    SELECT  OBJECT_NAME(ixUS.[object_id]) AS [Object Name]
          , S.[name] AS [index name]
          , S.[rowcnt] AS [leaf-level rows]
          , ixUS.[user_updates]
          , (ixUS.[user_seeks] + ixUS.[user_scans] + ixUS.[user_lookups]) AS [user_reads]
          , I.[record_count]
          , CAST(I.[est_index_size_bytes] AS BIGINT) AS [est_index_size_bytes]
    FROM    sys.[dm_db_index_usage_stats] ixUS
            INNER JOIN [IndexBacon]..[sysindexes] S
                ON ixUS.[object_id] = S.[id]
                   AND ixUS.[index_id] = S.[indid]
            INNER JOIN index_space I
                ON ixUS.[object_id] = I.[object_id]
                   AND ixUS.[index_id] = I.[index_id]
    WHERE   ixUS.[database_id] = DB_ID()
            AND ixUS.[index_id] > 0
            AND ixUS.[user_seeks] + ixUS.[user_scans] + ixUS.[user_lookups] = 0
            AND ixUS.[user_updates] > 0
    ORDER BY OBJECT_NAME(ixUS.[object_id])
          , S.[name]
          , ixUS.[user_updates] DESC ;
GO

