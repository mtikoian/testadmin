CREATE DATABASE [IndexBacon] ON  PRIMARY 
		(
			NAME = N'IndexBacon', 
			FILENAME = N'C:\SpecData\MSSQL\Data\IndexBacon.mdf' , 
			SIZE = 128MB , 
			FILEGROWTH = 128MB 
		)
		LOG ON 
			( 
				NAME = N'IndexBacon_log', 
				FILENAME = N'C:\SpecData\MSSQL\Logs\IndexBacon_log.ldf' , 
				SIZE = 64MB , 
				FILEGROWTH = 64MB 
		);

ALTER DATABASE [IndexBacon] SET RECOVERY SIMPLE; 
