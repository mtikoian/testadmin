USE [IndexBacon]
SET NOCOUNT ON 

CREATE TABLE dbo.Distributors 
	(
	[id] int NOT NULL, 
	[distributor_name] varchar(30) NOT NULL
	);

USE IndexBacon
GO

ALTER TABLE [dbo].Distributors ADD PRIMARY KEY (id);
CREATE INDEX nx_distributors_distributor_name ON dbo.Distributors (distributor_name);

INSERT INTO dbo.[Distributors] ([id], [distributor_name])
VALUES  (1, 'Spartan Stores');

INSERT INTO dbo.[Distributors] ([id], [distributor_name])
VALUES  (5, 'Kroger');

INSERT INTO dbo.[Distributors] ([id], [distributor_name])
VALUES  (3, 'Meijer');

INSERT INTO dbo.[Distributors] ([id], [distributor_name])
VALUES  (2, 'Toys R Us');
	
INSERT INTO dbo.[Distributors] ([id], [distributor_name])
VALUES  (4, 'Choke N Puke');

SELECT * FROM dbo.[Distributors];



USE [IndexBacon]
SET NOCOUNT ON 

CREATE TABLE dbo.baconbitsbytes 
	(
	[id] int NOT NULL, 
	[flavor] varchar(20) NOT NULL, 
	[column_not_used] decimal(10,4) NOT NULL, 
	[city] varchar(30) NULL, 
	[distributor_id] int NOT NULL,
	[brand] varchar(30) NOT NULL
	);

USE IndexBacon
GO

ALTER TABLE [dbo].baconbitsbytes ADD PRIMARY KEY (id);
CREATE INDEX nx_baconbitsbytes_column_not_used ON dbo.baconbitsbytes (column_not_used);
CREATE INDEX nx_baconbitsbytes_city ON dbo.baconbitsbytes (city);
CREATE INDEX nx_baconbitsbytes_distributor_id ON dbo.baconbitsbytes (distributor_id);
CREATE INDEX nx_baconbitsbytes_brand ON dbo.baconbitsbytes (brand);

DECLARE @id int

SELECT @id = 1

WHILE @id < 100000
	BEGIN
		INSERT INTO dbo.[baconbitsbytes] ([id], [flavor],[column_not_used],[city], [distributor_id], [brand])
		VALUES  (@id, 
			CASE 
				WHEN @id < 20000 THEN 'Hickory'
				WHEN @id BETWEEN 20000 AND 40000 THEN 'Maple'
				WHEN @id BETWEEN 40001 AND 60000 THEN 'Thick Sliced'
				WHEN @id BETWEEN 60001 AND 80000 THEN 'Applewood'
				WHEN @id BETWEEN 80001 AND 90000 THEN 'Plain'
				WHEN @id BETWEEN 90001 AND 99998 THEN 'Mesquite'
				WHEN @id > 99998 THEN 'Canadian'
			END, 
			1.0 * CAST(@id / 2 AS decimal(10,4)), 
			CASE 
				WHEN @id < 30000 THEN 'Kalamazoo'
				WHEN @id BETWEEN 30000 AND 40000 THEN 'Plainwell'
				WHEN @id BETWEEN 40001 AND 50000 THEN 'Christmas'
				WHEN @id BETWEEN 50001 AND 60000 THEN 'Wyandotte'
				WHEN @id BETWEEN 60001 AND 70000 THEN 'Bad Axe'
				WHEN @id BETWEEN 70001 AND 80000 THEN 'Climax'
				WHEN @id BETWEEN 80001 AND 85000 THEN 'Vicksburg'
				WHEN @id BETWEEN 85001 AND 90000 THEN 'Portage'
				WHEN @id BETWEEN 90001 AND 95000 THEN 'Texas Corners'
				ELSE NULL
			END,
			CASE
				WHEN @id < 20000 THEN 1
				WHEN @id BETWEEN 20001 AND 30000 THEN 3
				WHEN @id BETWEEN 30001 AND 50000 THEN 2
				WHEN @id BETWEEN 50001 AND 80000 THEN 4
				WHEN @id > 80000 THEN 5
				ELSE 3
			END,
			CASE 
				WHEN @id < 10000 THEN 'Thornapple Valley'
				WHEN @id BETWEEN 10000 AND 20000 THEN 'Ekrich'
				WHEN @id BETWEEN 20001 AND 30000 THEN 'Oscar Meyer'
				WHEN @id BETWEEN 30001 AND 40000 THEN 'Oscar Grouch'
				WHEN @id BETWEEN 40001 AND 50000 THEN 'Bar T'
				WHEN @id BETWEEN 50001 AND 60000 THEN 'Chunky Fat Inc.'
				WHEN @id BETWEEN 60001 AND 70000 THEN 'Rind-a-Rific'
				WHEN @id BETWEEN 70001 AND 80000 THEN 'Meet Not Meat'
				WHEN @id BETWEEN 80001 AND 90000 THEN 'Do Not Ask'
				WHEN @id > 90000 THEN 'House of Snouts n Things'
				ELSE 'Parts and Stuff'
			END
			)
		
		SELECT @id = @id + 2
	END

SELECT @id = 2

WHILE @id < 100000
	BEGIN
		INSERT INTO dbo.[baconbitsbytes] ([id], [flavor],[column_not_used],[city], [distributor_id], [brand])
		VALUES  (@id, 
			CASE 
				WHEN @id < 20000 THEN 'Hickory'
				WHEN @id BETWEEN 20000 AND 40000 THEN 'Maple'
				WHEN @id BETWEEN 40001 AND 60000 THEN 'Thick Sliced'
				WHEN @id BETWEEN 60001 AND 80000 THEN 'Applewood'
				WHEN @id BETWEEN 80001 AND 90000 THEN 'Plain'
				WHEN @id BETWEEN 90001 AND 99998 THEN 'Mesquite'
				WHEN @id > 99998 THEN 'Canadian'
			END, 
			1.0 * CAST(@id / 2 AS decimal(10,4)), 
			CASE 
				WHEN @id < 30000 THEN 'Kalamazoo'
				WHEN @id BETWEEN 30000 AND 40000 THEN 'Plainwell'
				WHEN @id BETWEEN 40001 AND 50000 THEN 'Christmas'
				WHEN @id BETWEEN 50001 AND 60000 THEN 'Wyandotte'
				WHEN @id BETWEEN 60001 AND 70000 THEN 'Bad Axe'
				WHEN @id BETWEEN 70001 AND 80000 THEN 'Climax'
				WHEN @id BETWEEN 80001 AND 85000 THEN 'Vicksburg'
				WHEN @id BETWEEN 85001 AND 90000 THEN 'Portage'
				WHEN @id BETWEEN 90001 AND 95000 THEN 'Texas Corners'
				ELSE NULL
			END,
			CASE
				WHEN @id < 20000 THEN 1
				WHEN @id BETWEEN 20001 AND 30000 THEN 3
				WHEN @id BETWEEN 30001 AND 50000 THEN 2
				WHEN @id BETWEEN 50001 AND 80000 THEN 4
				WHEN @id > 80000 THEN 5
				ELSE 3
			END,
			CASE 
				WHEN @id < 10000 THEN 'Thornapple Valley'
				WHEN @id BETWEEN 10000 AND 20000 THEN 'Ekrich'
				WHEN @id BETWEEN 20001 AND 30000 THEN 'Oscar Meyer'
				WHEN @id BETWEEN 30001 AND 40000 THEN 'Oscar Grouch'
				WHEN @id BETWEEN 40001 AND 50000 THEN 'Bar T'
				WHEN @id BETWEEN 50001 AND 60000 THEN 'Chunky Fat Inc.'
				WHEN @id BETWEEN 60001 AND 70000 THEN 'Rind-a-Rific'
				WHEN @id BETWEEN 70001 AND 80000 THEN 'Meet Not Meat'
				WHEN @id BETWEEN 80001 AND 90000 THEN 'Do Not Ask'
				WHEN @id > 90000 THEN 'House of Snouts n Things'
				ELSE 'Parts and Stuff'
			END
			)
		
		SELECT @id = @id + 2
	END

ALTER TABLE dbo.baconbitsbytes ADD CONSTRAINT FK_baconbitsbytes_distributors FOREIGN KEY
	(distributor_id) REFERENCES dbo.Distributors (id);


SELECT * FROM dbo.[baconbitsbytes];