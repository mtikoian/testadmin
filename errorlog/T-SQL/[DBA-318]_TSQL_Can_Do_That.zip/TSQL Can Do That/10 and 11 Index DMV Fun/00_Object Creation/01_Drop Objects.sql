USE [IndexBacon];

IF EXISTS (SELECT name FROM sys.[objects] WHERE name = 'baconbitsbytes')
DROP TABLE dbo.[baconbitsbytes];

IF EXISTS (SELECT name FROM sys.[objects] WHERE name = 'Distributors')
DROP TABLE dbo.[Distributors];