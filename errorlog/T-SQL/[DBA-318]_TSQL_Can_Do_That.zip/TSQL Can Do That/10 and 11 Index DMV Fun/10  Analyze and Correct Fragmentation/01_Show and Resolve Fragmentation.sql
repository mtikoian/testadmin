USE [IndexBacon];

--===================================
--Before resolving fragmentation:
--===================================

SELECT db_name(DDIPS.[database_id]) AS [Database], 
	object_name(DDIPS.[object_id], 
	db_id()) AS [Object],
	DDIPS.[page_count],
	I.[name] AS [Index], 
	DDIPS.[avg_fragmentation_in_percent] AS [Frag %]
FROM sys.[dm_db_index_physical_stats](db_id(), NULL, NULL, NULL, 'limited') DDIPS
	INNER JOIN sys.[indexes] I ON DDIPS.[object_id] = I.[object_id] AND DDIPS.[index_id] = I.[index_id]
ORDER BY object_name(DDIPS.[object_id]), [DDIPS].[index_id];

--====================================
--Resolve targetted fragmentation:
--====================================

EXECUTE iDBA.indexBOT.usp_rebuild_indexes_by_db 
	'<DB_NAME, nvarchar(100), Foo>', 
	<ReorgLimit, tinyint, 15>,
	<RebuildLimit, tinyint, 29>,
	<PageLimit, smallint, 10>,
	<SortInTempdb, bit, 0>,
	<DoOnline, bit, 0>,
	<ByPartition, bit, 0>,
	<LOBCompaction, bit, 1>,
	<DoCIOnly, bit, 0>,
	<UpdateStats, bit, 1>,
	<MaxDegP, tinyint, 0>,
	<ExcludedTables, nvarchar(2000), NULL>


--===================================
--After resolving fragmentation:
--===================================

SELECT db_name(DDIPS.[database_id]) AS [Database], 
	object_name(DDIPS.[object_id], 
	db_id()) AS [Object],
	DDIPS.[page_count],
	I.[name] AS [Index], 
	DDIPS.[avg_fragmentation_in_percent] AS [Frag %]
FROM sys.[dm_db_index_physical_stats](db_id(), NULL, NULL, NULL, 'limited') DDIPS
	INNER JOIN sys.[indexes] I ON DDIPS.[object_id] = I.[object_id] AND DDIPS.[index_id] = I.[index_id]
ORDER BY object_name(DDIPS.[object_id]), [DDIPS].[index_id];




