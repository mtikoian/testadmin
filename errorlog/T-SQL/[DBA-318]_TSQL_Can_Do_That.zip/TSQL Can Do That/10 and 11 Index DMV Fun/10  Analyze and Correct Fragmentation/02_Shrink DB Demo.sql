--=======================================================
--Why Don't You Shrink Databases?
--=======================================================
USE IndexBacon;
GO

SELECT db_name(DDIPS.[database_id]) AS [Database], 
	object_name(DDIPS.[object_id], 
	db_id()) AS [Object],
	I.[name] AS [Index], 
	DDIPS.[alloc_unit_type_desc], 
	DDIPS.[avg_fragmentation_in_percent] AS [Frag %],
	DDIPS.[fragment_count],
	DDIPS.[avg_fragment_size_in_pages],
	DDIPS.[page_count]
FROM sys.[dm_db_index_physical_stats](db_id(), NULL, NULL, NULL, 'limited') DDIPS
	INNER JOIN sys.[indexes] I ON DDIPS.[object_id] = I.[object_id] AND DDIPS.[index_id] = I.[index_id]
ORDER BY object_name(DDIPS.[object_id]), [DDIPS].[index_id];


--Let's cause some FRAG-MEN-TATION!!!!  ==============================
USE [IndexBacon];
DBCC SHRINKFILE (N'IndexBacon' , 1);
GO


SELECT db_name(DDIPS.[database_id]) AS [Database], 
	object_name(DDIPS.[object_id], 
	db_id()) AS [Object],
	I.[name] AS [Index], 
	DDIPS.[alloc_unit_type_desc], 
	DDIPS.[avg_fragmentation_in_percent] AS [Frag %],
	DDIPS.[fragment_count],
	DDIPS.[avg_fragment_size_in_pages],
	DDIPS.[page_count]
FROM sys.[dm_db_index_physical_stats](db_id('IndexBacon'), NULL, NULL, NULL, 'limited') DDIPS
	INNER JOIN sys.[indexes] I ON DDIPS.[object_id] = I.[object_id] AND DDIPS.[index_id] = I.[index_id]
ORDER BY object_name(DDIPS.[object_id]), [DDIPS].[index_id];



--============================================================
/*Cleaning up our toys when done playing with them*/
ALTER DATABASE [IndexBacon] MODIFY FILE ( NAME = N'IndexBacon', SIZE = 64MB )

EXECUTE iDBA.indexBOT.usp_rebuild_indexes_by_db 
	'IndexBacon', 
	15,
	29,
	2,
	0,
	0,
	0,
	1,
	0,
	0,
	0,
	NULL


--===================================
--After resolving fragmentation:
--===================================

SELECT db_name(DDIPS.[database_id]) AS [Database], 
	object_name(DDIPS.[object_id], 
	db_id()) AS [Object],
	DDIPS.[page_count],
	I.[name] AS [Index], 
	DDIPS.[avg_fragmentation_in_percent] AS [Frag %]
FROM sys.[dm_db_index_physical_stats](db_id(), NULL, NULL, NULL, 'limited') DDIPS
	INNER JOIN sys.[indexes] I ON DDIPS.[object_id] = I.[object_id] AND DDIPS.[index_id] = I.[index_id]
ORDER BY object_name(DDIPS.[object_id]), [DDIPS].[index_id];



--============================================================