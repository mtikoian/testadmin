
/*
-------------------------------------------------------------
#13  Execution Plans Via TSQL

-------------------------------------------------------------
*/


--------------------------------------------------------------------
--Requests and performance hits and query text/plan - You Get it ALL
--------------------------------------------------------------------
SELECT 'This statement is no longer executing';

SELECT  eS.session_id
      , eS.host_name
      , eS.program_name
      , eS.login_name
      , eR.logical_reads
      , eR.cpu_time
      , eR.reads
      , eR.writes
      , ST.text
      , QP.query_plan
FROM    sys.dm_exec_sessions eS
        INNER JOIN sys.dm_exec_requests eR
            ON es.session_id = eR.session_id
        CROSS APPLY sys.dm_exec_sql_text(eR.sql_handle) ST
        CROSS APPLY sys.dm_exec_query_plan(eR.plan_handle) QP
WHERE   eS.is_user_process = 1
ORDER BY eR.session_id ;

SELECT 'This statement has not executed';





--=====================================================
--Limit only to the active statement in the request
--=====================================================
SELECT 'This statement is no longer executing';

SELECT  eS.session_id
      , eS.host_name
      , eS.program_name
      , eS.login_name
      , eR.logical_reads
      , eR.cpu_time
      , eR.reads
      , eR.writes
      , SUBSTRING(ST.text, eR.statement_start_offset / 2, (CASE WHEN eR.statement_end_offset = -1 THEN DATALENGTH(ST.text)
                                                                ELSE eR.statement_end_offset
                                                           END - eR.statement_start_offset) / 2) AS statement_executing
      , CAST(TQP.query_plan AS XML)
FROM    sys.dm_exec_sessions eS
        INNER JOIN sys.dm_exec_requests eR
            ON es.session_id = eR.session_id
        CROSS APPLY sys.dm_exec_sql_text(eR.sql_handle) ST
        CROSS APPLY sys.dm_exec_text_query_plan(eR.plan_handle, eR.statement_start_offset, eR.statement_end_offset) TQP
WHERE   eS.is_user_process = 1
ORDER BY eR.session_id ;

SELECT 'This statement has not executed';
 