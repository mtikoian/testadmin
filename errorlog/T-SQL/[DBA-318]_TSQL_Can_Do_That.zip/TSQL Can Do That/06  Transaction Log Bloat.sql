
/*
-------------------------------------------------------------
#6  Determine Which Databases May Be Experiencing Log "Bloat"

-------------------------------------------------------------


-------------------------------------------------------------
NOTE: This script relies on Aaron Betrand's sp_foreachdb 
presented as script #5 in this presentation.

Download it here:  
	http://www2.sqlblog.com/blogs/aaron_bertrand/archive/2010/12/29/a-more-reliable-and-more-flexible-sp-msforeachdb.aspx
-------------------------------------------------------------
*/

USE [<user scripts db name, , iDBA>];
GO

CREATE PROCEDURE [usp_identify_log_bloat] AS
--+-----------------------------------------------
--Create necessary temp table for results
--+-----------------------------------------------
IF EXISTS 
 (
 SELECT name 
 FROM tempdb.sys.[tables] 
 WHERE name LIKE '#trx_log_size%'
 )
 DROP TABLE #trx_log_size;
CREATE TABLE #trx_log_size
 (
 database_name nvarchar(128) NOT NULL,
 [name] nvarchar(128) NOT NULL,
 physical_name nvarchar(260) NOT NULL,
 size_mb int NOT NULL
 )
 
--+-----------------------------------------------
--Populate temp table with current log file sizes 
--+-----------------------------------------------
EXEC [dbo].[sp_foreachdb] 
 @command = 'INSERT INTO [#trx_log_size] ([database_name], [name], 
                    [physical_name], [size_mb]) 
                    SELECT N''?'', name, physical_name, size*8/1024 
                    FROM [?].sys.database_files WHERE type = 1;',
  @suppress_quotename = 1



SELECT
	L.[database_name], 
	L.[physical_name], 
	L.[size_mb], 
	MAX(CEILING(BF.[backup_size]/1024/1024)) AS max_backup_file_size_mb,
	L.[size_mb] - MAX(CEILING(BF.[backup_size]/1024/1024)) AS file_excess_mb
FROM msdb.dbo.[backupfile] BF 
	INNER JOIN msdb.dbo.[backupset] BS ON [BF].[backup_set_id] = [BS].[backup_set_id]
	INNER JOIN [#trx_log_size] L ON [BS].[database_name] = L.[database_name]
	INNER JOIN master.sys.[databases] SD ON L.[database_name] = SD.[name]
WHERE BS.[type] = 'L'
	AND SD.[recovery_model_desc] = 'FULL'
GROUP BY SD.[name], L.[database_name], L.[physical_name], L.[size_mb]
HAVING  L.[size_mb] > MAX(CEILING(BF.[backup_size]/1024/1024))
ORDER BY L.[size_mb] - MAX(CEILING(BF.[backup_size]/1024/1024)) DESC;



--+-----------------------------------------------
--Clean up your messes when you're done!
--+-----------------------------------------------
DROP TABLE #trx_log_size;

GO


--+-----------------------------------------------
--Now Can Execute As:
--+-----------------------------------------------
USE [<user scripts db name, , iDBA>];
GO

EXEC usp_identify_log_bloat;
