-------------------------------------------------------------
--Simple Wait Stats Differential for a 1 minute period
/* 
Robert Davis, MCM, Idera Software
*/
-------------------------------------------------------------
DECLARE @Waits TABLE
    (
     WaitID INT IDENTITY(1, 1) NOT NULL PRIMARY KEY
	, wait_type NVARCHAR(60)
	, wait_time_s DECIMAL(12, 2)
    ) ;    

WITH Waits
	AS (
		SELECT wait_type
			, wait_time_ms / 1000. AS wait_time_s
			, 100. * wait_time_ms / SUM(wait_time_ms) OVER () AS pct
			, ROW_NUMBER() OVER (ORDER BY wait_time_ms DESC) AS rn
		FROM sys.dm_os_wait_stats
		WHERE wait_type NOT IN 
			( -- filter out additional irrelevant waits
				'BROKER_TASK_STOP', 'BROKER_RECEIVE_WAITFOR', 'BROKER_EVENTHANDLER', 
				'BROKER_TO_FLUSH', 'BROKER_TRANSMITTER', 'CHECKPOINT_QUEUE', 
				'CHKPT', 'DISPATCHER_QUEUE_SEMAPHORE', 'CLR_AUTO_EVENT', 
				'CLR_MANUAL_EVENT','FT_IFTS_SCHEDULER_IDLE_WAIT', 'KSOURCE_WAKEUP', 
				'LAZYWRITER_SLEEP', 'LOGMGR_QUEUE', 'MISCELLANEOUS', 'ONDEMAND_TASK_QUEUE',
				'REQUEST_FOR_DEADLOCK_SEARCH', 'SLEEP_TASK', 'TRACEWRITE',
				'SQLTRACE_BUFFER_FLUSH', 'XE_DISPATCHER_WAIT', 'XE_TIMER_EVENT', 'WAITFOR'
			)
		)
INSERT  INTO @Waits
        (
         wait_type
       , wait_time_s
        )
        SELECT  W1.wait_type
              , CAST(W1.wait_time_s AS DECIMAL(12, 2)) AS wait_time_s
        FROM    Waits AS W1
                INNER JOIN Waits AS W2
                    ON W2.rn <= W1.rn
        GROUP BY W1.rn
              , W1.wait_type
              , W1.wait_time_s
              , W1.pct
        HAVING  SUM(W2.pct) - W1.pct < 95 ;	 -- percentage threshold


----------------------------------------------------
WAITFOR DELAY '0:<minutes to analyze, two-digit integer, 01>:00';
----------------------------------------------------


WITH Waits
	AS (
		SELECT wait_type
			, wait_time_ms / 1000. AS wait_time_s
			, 100. * wait_time_ms / SUM(wait_time_ms) OVER () AS pct
			, ROW_NUMBER() OVER (ORDER BY wait_time_ms DESC) AS rn
		FROM sys.dm_os_wait_stats
		WHERE wait_type NOT IN 
			( -- filter out additional irrelevant waits
				'BROKER_TASK_STOP', 'BROKER_RECEIVE_WAITFOR', 'BROKER_EVENTHANDLER', 
				'BROKER_TO_FLUSH', 'BROKER_TRANSMITTER', 'CHECKPOINT_QUEUE', 
				'CHKPT', 'DISPATCHER_QUEUE_SEMAPHORE', 'CLR_AUTO_EVENT', 
				'CLR_MANUAL_EVENT','FT_IFTS_SCHEDULER_IDLE_WAIT', 'KSOURCE_WAKEUP', 
				'LAZYWRITER_SLEEP', 'LOGMGR_QUEUE', 'MISCELLANEOUS', 'ONDEMAND_TASK_QUEUE',
				'REQUEST_FOR_DEADLOCK_SEARCH', 'SLEEP_TASK', 'TRACEWRITE',
				'SQLTRACE_BUFFER_FLUSH', 'XE_DISPATCHER_WAIT', 'XE_TIMER_EVENT', 'WAITFOR'
				
			)
		)
INSERT  INTO @Waits
        (
         wait_type
       , wait_time_s
        )
        SELECT  W1.wait_type
              , CAST(W1.wait_time_s AS DECIMAL(12, 2)) AS wait_time_s
        FROM    Waits AS W1
                INNER JOIN Waits AS W2
                    ON W2.rn <= W1.rn
        GROUP BY W1.rn
              , W1.wait_type
              , W1.wait_time_s
              , W1.pct
        HAVING  SUM(W2.pct) - W1.pct < 95 ;	 -- percentage threshold



-------------------------------------------------
SELECT  wait_type
      , MAX(wait_time_s) - MIN(wait_time_s) WaitDelta
FROM    @Waits
GROUP BY wait_Type
ORDER BY WaitDelta DESC
-------------------------------------------------