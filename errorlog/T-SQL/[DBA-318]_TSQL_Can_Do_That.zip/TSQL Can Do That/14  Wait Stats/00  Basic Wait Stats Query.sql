-------------------------------------------------------------
--Basic Wait Stats Query
/* 
Glenn Berry, Paul Randal, Tim Ford, Ben Nevarez, Joe Sack
Brent Ozar and many others...
*/
-------------------------------------------------------------
WITH Waits AS
	(
	SELECT 
		wait_type, 
		wait_time_ms / 1000. AS wait_time_s,
		signal_wait_time_ms / 1000 AS signal_wait_time_s, 
		(wait_time_ms - signal_wait_time_ms) / 1000 AS resource_wait_time_s,
		waiting_tasks_count, 
		CASE waiting_tasks_count
			WHEN 0 THEN 0
			ELSE [wait_time_ms]/[waiting_tasks_count]
		END AS avg_wait_time_ms,
		 		
		100. * wait_time_ms / SUM(wait_time_ms) OVER() AS pct,
		ROW_NUMBER() OVER(ORDER BY (wait_time_ms - signal_wait_time_ms) DESC) AS rn
	FROM sys.dm_os_wait_stats
	WHERE wait_type 
		NOT IN ( -- filter out additional irrelevant waits
				'BROKER_TASK_STOP', 'BROKER_RECEIVE_WAITFOR', 'BROKER_EVENTHANDLER', 
				'BROKER_TO_FLUSH', 'BROKER_TRANSMITTER', 'CHECKPOINT_QUEUE', 
				'CHKPT', 'DISPATCHER_QUEUE_SEMAPHORE', 'CLR_AUTO_EVENT', 
				'CLR_MANUAL_EVENT','FT_IFTS_SCHEDULER_IDLE_WAIT', 'KSOURCE_WAKEUP', 
				'LAZYWRITER_SLEEP', 'LOGMGR_QUEUE', 'MISCELLANEOUS', 'ONDEMAND_TASK_QUEUE',
				'REQUEST_FOR_DEADLOCK_SEARCH', 'SLEEP_TASK', 'TRACEWRITE',
				'SQLTRACE_BUFFER_FLUSH', 'XE_DISPATCHER_WAIT', 'XE_TIMER_EVENT'
				)
		)
						
SELECT W1.wait_type,
	CAST(W1.wait_time_s AS DECIMAL(10, 0)) AS wait_time_s,
	CAST(W1.signal_wait_time_s AS DECIMAL(10, 0)) AS signal_wait_time_s,
	CAST(W1.resource_wait_time_s AS DECIMAL(10, 0)) AS resource_wait_time_s,
	W1.waiting_tasks_count,
	W1.avg_wait_time_ms,
	CAST(W1.pct AS DECIMAL(5, 2)) AS pct,
	CAST(SUM(W2.pct) AS DECIMAL(5, 2)) AS running_pct
FROM Waits AS W1
	INNER JOIN Waits AS W2 ON W2.rn <= W1.rn
GROUP BY W1.rn, 
	W1.wait_type, 
	W1.wait_time_s,
	W1.signal_wait_time_s,
	W1.resource_wait_time_s,
	W1.avg_wait_time_ms, 
	W1.waiting_tasks_count,
	W1.pct
HAVING SUM(W2.pct) - W1.pct < 95; -- percentage threshold