SET NOCOUNT ON;
GO


--Make Sure you're in the right database!


--==================================================================
--DETERMINE WHAT INFORMATION FOR WAITS HAS BEEN PERSISTED TO DISK--
--==================================================================
SELECT DISTINCT [wait_id], [date_stamp] 
FROM [wait_history]
ORDER BY [wait_id] DESC;
GO


/*
This will give you the values for the starting and ending wait_ids 
to use when replacing the template parameters below via Ctl+Shift+M  Be sure to only
run the statement below through the end to avoid an error b/c of the CTE and
the WITH keyword needing to be the first statement in a batch.

Can manually run the _ReportBOT Wait Stats Collection job to create a recent bookmark
so you can capture the wait info for the period since the last collection if the aging
is too old.
*/




WITH first_waits AS 
(
SELECT  [wait_type]
      , [wait_time_s]
      , [signal_wait_time_s]
      , [resource_wait_time_s]
      , [waiting_task_count]
      , [avg_resource_wait_time_ms]
      , [pct]
      , [running_pct] 
FROM [wait_history] 
WHERE [wait_id] = <wait_id_1st,int,>
)

SELECT LW.[wait_type]
      , LW.[wait_time_s] - FW.wait_time_s AS wait_time_s
      , LW.[signal_wait_time_s] - FW.[signal_wait_time_s] AS signal_wait_time_s
      , LW.[resource_wait_time_s] - FW.[resource_wait_time_s] AS resource_wait_time_s
      , LW.[waiting_task_count] - FW.[waiting_task_count] AS waiting_task_count
      , (LW.[resource_wait_time_s] - FW.[resource_wait_time_s])/(LW.[waiting_task_count] - FW.[waiting_task_count])AS avg_resource_wait_time_ms
FROM [wait_history] LW
	LEFT JOIN [first_waits] FW ON LW.[wait_type] = FW.[wait_type]  	
WHERE LW.[wait_id] = <wait_id_2nd,int,>
	AND LW.wait_type NOT IN
		(
			'BROKER_TASK_STOP', 'BROKER_RECEIVE_WAITFOR', 
			'BROKER_TO_FLUSH', 'BROKER_TRANSMITTER', 'CHECKPOINT_QUEUE', 
			'CHKPT', 'DISPATCHER_QUEUE_SEMAPHORE', 'CLR_AUTO_EVENT', 
			'CLR_MANUAL_EVENT','FT_IFTS_SCHEDULER_IDLE_WAIT', 'KSOURCE_WAKEUP', 
			'LAZYWRITER_SLEEP', 'LOGMGR_QUEUE', 'MISCELLANEOUS', 'ONDEMAND_TASK_QUEUE',
			'REQUEST_FOR_DEADLOCK_SEARCH', 'SLEEP_TASK', 'TRACEWRITE',
			'SQLTRACE_BUFFER_FLUSH', 'XE_DISPATCHER_WAIT', 'XE_TIMER_EVENT'
		)
	AND (LW.[resource_wait_time_s] - FW.[resource_wait_time_s]) <> 0 
ORDER BY [FW].[resource_wait_time_s] DESC;


SET NOCOUNT OFF;
