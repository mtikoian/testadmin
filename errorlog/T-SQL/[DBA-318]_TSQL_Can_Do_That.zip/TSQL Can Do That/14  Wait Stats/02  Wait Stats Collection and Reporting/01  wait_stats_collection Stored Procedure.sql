-------------------------------------------------
-- Code to place into SQL Agent Job
-------------------------------------------------
USE [<metadata database name, ,iDBA>]
GO

CREATE PROCEDURE [wait_stats_collection] 
AS

CREATE TABLE #waits (date_stamp datetime, wait_type varchar(1000), 
	wait_time_s bigint, signal_wait_time_s bigint, 
	resource_wait_time_s bigint, waiting_task_count bigint, 
	avg_resource_wait_time_ms bigint, pct decimal(5,2), running_pct decimal(5,2)
	);

DECLARE @service_start datetime
SELECT @service_start = create_date FROM master.sys.databases WHERE name = 'tempdb';

/* Isolate top waits for server instance since last restart or statistics clear */
--DBCC SQLPERF('sys.dm_os_wait_stats', CLEAR);
WITH Waits AS
	(
	SELECT 
		wait_type, 
		wait_time_ms / 1000. AS wait_time_s,
		signal_wait_time_ms / 1000 AS signal_wait_time_s, 
		(wait_time_ms - signal_wait_time_ms) / 1000 AS resource_wait_time_s,
		waiting_tasks_count, 
		CASE waiting_tasks_count
			WHEN 0 THEN 0
			ELSE (wait_time_ms - signal_wait_time_ms)/[waiting_tasks_count]
		END AS avg_resource_wait_time_ms,
		 		
		100. * wait_time_ms / SUM(wait_time_ms) OVER() AS pct,
		ROW_NUMBER() OVER(ORDER BY (wait_time_ms - signal_wait_time_ms) DESC) AS rn
	FROM sys.dm_os_wait_stats
	WHERE wait_type 
		NOT IN (	-- filter out additional irrelevant waits
				'BROKER_TASK_STOP', 'BROKER_RECEIVE_WAITFOR', 
				'BROKER_TO_FLUSH', 'BROKER_TRANSMITTER', 'CHECKPOINT_QUEUE', 
				'CHKPT', 'DISPATCHER_QUEUE_SEMAPHORE', 'CLR_AUTO_EVENT', 
				'CLR_MANUAL_EVENT','FT_IFTS_SCHEDULER_IDLE_WAIT', 'KSOURCE_WAKEUP', 
				'LAZYWRITER_SLEEP', 'LOGMGR_QUEUE', 'MISCELLANEOUS', 'ONDEMAND_TASK_QUEUE',
				'REQUEST_FOR_DEADLOCK_SEARCH', 'SLEEP_TASK', 'TRACEWRITE',
				'SQLTRACE_BUFFER_FLUSH', 'XE_DISPATCHER_WAIT', 'XE_TIMER_EVENT'
				,'BROKER_EVENTHANDLER'
				)
		)

--Insert collected values into temporary table:
INSERT INTO #waits
	(
		date_stamp, wait_type, wait_time_s, 
		signal_wait_time_s, resource_wait_time_s, 
		waiting_task_count, avg_resource_wait_time_ms, pct, running_pct
	)
SELECT 
	GETDATE(), 
	W1.wait_type,
	CAST(W1.wait_time_s AS DECIMAL(10, 0)) AS wait_time_s,
	CAST(W1.signal_wait_time_s AS DECIMAL(10, 0)) AS signal_wait_time_s,
	CAST(W1.resource_wait_time_s AS DECIMAL(10, 0)) AS resource_wait_time_s,
	W1.waiting_tasks_count,
	W1.avg_resource_wait_time_ms,
	CAST(W1.pct AS DECIMAL(5, 2)) AS pct,
	CAST(SUM(W2.pct) AS DECIMAL(5, 2)) AS running_pct
FROM Waits AS W1
	INNER JOIN Waits AS W2 ON W2.rn <= W1.rn
GROUP BY W1.rn, 
	W1.wait_type, 
	W1.wait_time_s,
	W1.signal_wait_time_s,
	W1.resource_wait_time_s,
	W1.avg_resource_wait_time_ms, 
	W1.waiting_tasks_count,
	W1.pct
HAVING SUM(W2.pct) - W1.pct < 95; -- percentage threshold 


DECLARE @collection_id int
SELECT @collection_id = COALESCE(MAX(wait_id),0) + 1 FROM wait_history

-----------------------------------------------------------------------
--If this is the first time values have been collected:
-----------------------------------------------------------------------
IF (SELECT COUNT(date_stamp) FROM wait_hash) = 0
	BEGIN
		--Insert the values into the wait_hash table
		INSERT INTO wait_hash
			(
				date_stamp, wait_type, wait_time_s, 
				signal_wait_time_s, resource_wait_time_s, 
				waiting_task_count, avg_resource_wait_time_ms, pct, running_pct
			)
		SELECT date_stamp, wait_type, wait_time_s, 
				signal_wait_time_s, resource_wait_time_s, 
				waiting_task_count, avg_resource_wait_time_ms, pct, running_pct
		FROM #waits
			
		
		--Then also insert the values into the wait_history table
		INSERT INTO wait_history
			(
				wait_id, date_stamp, wait_type, wait_time_s, 
				signal_wait_time_s, resource_wait_time_s, 
				waiting_task_count, avg_resource_wait_time_ms, pct, running_pct
			)
		SELECT @collection_id, date_stamp, wait_type, wait_time_s, 
				signal_wait_time_s, resource_wait_time_s, 
				waiting_task_count, avg_resource_wait_time_ms, pct, running_pct
		FROM #waits
	END
	
ELSE

	BEGIN
		/*---------------------------------------------------------------------
			History already exists.  
			Has there been a service restart since the last collection?  
			Populate History Accordingly
		*/-----------------------------------------------------------------------
		IF (SELECT TOP 1 date_stamp FROM #waits) < @service_start
			BEGIN
				--A restart has occurred at some point since the last collection
				INSERT INTO wait_history
					(
						wait_id, date_stamp, wait_type, wait_time_s, 
						signal_wait_time_s, resource_wait_time_s, 
						waiting_task_count, avg_resource_wait_time_ms, pct, running_pct
					)
				SELECT @collection_id, WS.date_stamp, WS.wait_type, 
					(WS.wait_time_s + WH.wait_time_s) AS wait_time_s, 
					(WS.signal_wait_time_s + WH.signal_wait_time_s) AS signal_wait_time_s, 
					(WS.resource_wait_time_s + WH.resource_wait_time_s) AS resource_wait_time_s, 
					(WS.waiting_task_count + WH.waiting_task_count) AS waiting_task_count, 
					CASE (WS.waiting_task_count + WH.waiting_task_count)
						WHEN 0 THEN 0
						ELSE ((WS.resource_wait_time_s + WH.resource_wait_time_s)/(WS.waiting_task_count + WH.waiting_task_count))
				END AS avg_resource_wait_time_ms, 
					pct, running_pct
				FROM #waits WS
					LEFT JOIN wait_history WH ON WS.wait_type = WH.wait_type
				WHERE WH.wait_id = (@collection_id - 1)
			END
		ELSE
			BEGIN
				--No restart has occurred
				INSERT INTO wait_history
					(
						wait_id, date_stamp, wait_type, wait_time_s, 
						signal_wait_time_s, resource_wait_time_s, 
						waiting_task_count, avg_resource_wait_time_ms, pct, running_pct
					)
				SELECT @collection_id, date_stamp, wait_type, wait_time_s, 
						signal_wait_time_s, resource_wait_time_s, 
						waiting_task_count, avg_resource_wait_time_ms, pct, running_pct
				FROM #waits 
			END
	END

-----------------------------------------------------------------------
--Clean and reload Hash table
-----------------------------------------------------------------------
TRUNCATE TABLE wait_hash;

INSERT INTO wait_hash
	(
		date_stamp, wait_type, wait_time_s, 
		signal_wait_time_s, resource_wait_time_s, 
		waiting_task_count, avg_resource_wait_time_ms, pct, running_pct
	)
SELECT date_stamp, wait_type, wait_time_s, 
		signal_wait_time_s, resource_wait_time_s, 
		waiting_task_count, avg_resource_wait_time_ms, pct, running_pct
FROM #waits;


DROP TABLE #waits;

GO