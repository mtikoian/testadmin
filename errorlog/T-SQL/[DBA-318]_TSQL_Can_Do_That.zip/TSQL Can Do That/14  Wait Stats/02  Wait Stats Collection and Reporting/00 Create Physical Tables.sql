-------------------------------------------------
-- Create Table to Persist Wait Stats
-------------------------------------------------
USE [<metadata database name, ,iDBA>]
GO

-- Physical Table for hashing results

CREATE TABLE [wait_hash](
	[date_stamp] [datetime] NULL,
	[wait_type] [varchar](1000) NULL,
	[wait_time_s] [bigint] NULL,
	[signal_wait_time_s] [bigint] NULL,
	[resource_wait_time_s] [bigint] NULL,
	[waiting_task_count] [bigint] NULL,
	[avg_resource_wait_time_ms] [bigint] NULL,
	[pct] [decimal](5, 2) NULL,
	[running_pct] [decimal](5, 2) NULL
) ON [PRIMARY];




--History Table (periodically clean up metadata)
CREATE TABLE [wait_history]
    (
     [wait_id] [int] NULL
   , [date_stamp] [datetime] NULL
   , [wait_type] [varchar](1000) NULL
   , [wait_time_s] [bigint] NULL
   , [signal_wait_time_s] [bigint] NULL
   , [resource_wait_time_s] [bigint] NULL
   , [waiting_task_count] [bigint] NULL
   , [avg_resource_wait_time_ms] [bigint] NULL
   , [pct] [decimal](5, 2) NULL
   , [running_pct] [decimal](5, 2) NULL
    ) ON  [PRIMARY];
GO

