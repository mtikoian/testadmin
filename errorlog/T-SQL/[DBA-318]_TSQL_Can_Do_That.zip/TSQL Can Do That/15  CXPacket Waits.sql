
/*
-------------------------------------------------------------
#15  What is Going on In Parallel Queries?

-------------------------------------------------------------
*/


SELECT  
	db_name(eR.[database_id]) AS [database_name]
		, eS.[login_name]
		, [oWT].[session_id]
		, [oWT].[exec_context_id]
		, [oWT].[wait_duration_ms]
		, [oWT].[wait_type]
		, [oWT].[resource_address]
		, [oWT].[blocking_task_address]
		, [oWT].[blocking_session_id]
		, [oWT].[blocking_exec_context_id]
		
		, SUBSTRING
		(ST.text, 
		eR.statement_start_offset / 2,
        ( 
			CASE 
				WHEN eR.statement_end_offset = -1 THEN DATALENGTH(ST.text)
				ELSE eR.statement_end_offset
			END - eR.statement_start_offset 
		) / 2) AS statement_executing,
	cast(TQP.query_plan as XML)
		
		
FROM    sys.[dm_os_waiting_tasks] oWT
	LEFT JOIN sys.[dm_exec_requests] eR
		ON [oWT].[session_id] = [eR].[session_id]
	INNER JOIN sys.[dm_exec_sessions] eS
		ON [eR].[session_id] = [eS].[session_id]
	CROSS APPLY sys.dm_exec_sql_text(eR.sql_handle) ST
	CROSS APPLY sys.dm_exec_text_query_plan(eR.plan_handle,eR.statement_start_offset, eR.statement_end_offset) TQP 
WHERE   [oWT].[session_id] IN 
			(
				SELECT DISTINCT [session_id]
                FROM sys.[dm_os_waiting_tasks]
                WHERE [wait_type] = 'CXPACKET'
			)
			AND [oWT].[wait_type] <> 'CXPACKET' 
ORDER BY [oWT].[session_id]
      , [oWT].[exec_context_id];