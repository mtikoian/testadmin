
/*
-------------------------------------------------------------
#7  Estimate File Growth Based Upon Past Backup File Sizes

-------------------------------------------------------------
*/

SET NOCOUNT ON;

SELECT 
	BS.database_name 
	, CAST(BF.file_size/1024/1024 AS bigint) AS file_size_mb
	, CAST(BF.backup_size/1024/1024 AS bigint) AS consumed_size_mb
	, BF.logical_name
	, BF.physical_name
	, BS.backup_finish_date AS polling_date
FROM msdb.dbo.backupset BS 
	INNER JOIN msdb.dbo.backupfile BF ON BS.backup_set_id = BF.backup_set_id
WHERE  BS.type = 'D' 
	AND BF.physical_name LIKE '%.mdf'
ORDER BY BS.database_name, BF.logical_name, BS.backup_finish_date DESC;

SET NOCOUNT OFF;
