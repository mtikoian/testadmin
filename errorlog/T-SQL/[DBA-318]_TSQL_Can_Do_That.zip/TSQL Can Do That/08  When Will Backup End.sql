/*
-------------------------------------------------------------
#8  When Will the Backup / Restore / Index Rebuild / DBCC Process End
		(Estimated, of course)
-------------------------------------------------------------
*/

SET NOCOUNT ON;

SELECT eR.session_id, 
	eR.percent_complete, 
	eR.total_elapsed_time/1000 AS elapsed_secs, 
	--(eR.percent_complete)/ (eR.total_elapsed_time/1000) AS pct_per_sec,
	DATEADD(s,100/((eR.percent_complete)/ (eR.total_elapsed_time/1000)), eR.start_time) AS estim_completion_time,
	eST.text 
FROM sys.dm_exec_requests eR
	CROSS APPLY sys.dm_exec_sql_text(eR.sql_handle) eST
WHERE eR.percent_complete > 0
	AND eR.session_id <> @@spid
	



-------------------------------------------------------------
--If you know the session ID:
-------------------------------------------------------------
/*

SELECT eR.percent_complete, 
	eR.total_elapsed_time/1000 AS elapsed_secs, 
	(eR.percent_complete)/ (eR.total_elapsed_time/1000) AS pct_per_sec,
	DATEADD(s,100/((eR.percent_complete)/ (eR.total_elapsed_time/1000)), eR.start_time) AS estim_completion_time,
	dest.text 
FROM sys.dm_exec_requests eR
	CROSS APPLY sys.dm_exec_sql_text(eR.sql_handle) dest
WHERE session_id = <session_id,int,>;

*/
SET NOCOUNT OFF;