
/*
-------------------------------------------------------------
#20  Instance Information Functions

-------------------------------------------------------------
*/

--+------------------------------------------------
-- CREATE INSTANCE FUNCTIONS
--+------------------------------------------------
/*
Gert Drapers content: Copyright (C) 1991-2002 SQLDEV.NET

-- file: SQL Server location functions.sql
-- descr.: SQL Server Location Functions
-- author: Gert E.R. Drapers (GertD@SQLDev.Net)
--
-- nvarchar(4000) = dbo.fn_SQLServerInstallDir()
-- nvarchar(4000) = dbo.fn_SQLServerDataDir()
-- nvarchar(4000) = dbo.fn_SQLServerLogDir()
-- nvarchar(4000) = dbo.fn_SQLServerBackupDir()
--
-- @@bof_revsion_marker
-- revision history
-- yyyy/mm/dd by description

--==========================================================
-- 2003/07/06 gertd v1.0.0.0 created
-- @@eof_revsion_marker
--***************************************************************************
--Additional  fn_SQLServerErrorLogDir  
--and alterations of output format by Timothy Ford (thesqlagentman@gmail.com)
--http://thesqlagentman.com
--03/02/2010
--****************************************************************************
*/

USE iDBA;
GO

SET NOCOUNT ON 

--***************************************************************************
-- nvarchar(4000) = dbo.fn_SQLServerInstallDir()
--author: Gert E.R. Drapers (GertD@SQLDev.Net)
--formatting: Timothy Ford (thesqlagentman@gmail.com) 
---------http://thesqlagentman.com
--***************************************************************************
IF OBJECT_ID('dbo.fn_SQLServerInstallDir') IS NOT NULL
DROP FUNCTION dbo.fn_SQLServerInstallDir
GO

CREATE FUNCTION dbo.fn_SQLServerInstallDir()
RETURNS nvarchar(4000)
AS
BEGIN

DECLARE @rc int,
@dir nvarchar(4000)

EXEC @rc = master.dbo.xp_instance_regread
	N'HKEY_LOCAL_MACHINE',
	N'Software\Microsoft\MSSQLServer\Setup',
	N'SQLPath',
	@dir OUTPUT, 
	'no_output'
RETURN @dir

END
GO

--TEST IT OUT:
SELECT fn_SQLServerInstallDir = dbo.fn_SQLServerInstallDir();
GO



--***************************************************************************
-- nvarchar(4000) = dbo.fn_SQLServerErrorLogDir_UNC()
--author: Timothy Ford (thesqlagentman@gmail.com) 
---------http://thesqlagentman.com
--***************************************************************************
if OBJECT_ID('dbo.fn_SQLServerErrorLogDir_UNC') IS NOT NULL
DROP FUNCTION dbo.fn_SQLServerErrorLogDir_UNC;
GO

CREATE FUNCTION dbo.fn_SQLServerErrorLogDir_UNC()
RETURNS nvarchar(4000)
AS
BEGIN

DECLARE @rc int, @dir nvarchar(4000), @servername varchar(100)

SELECT @servername = @@SERVERNAME

EXEC @rc = master.dbo.xp_instance_regread 
	N'HKEY_LOCAL_MACHINE',N'Software\Microsoft\MSSQLServer\Setup',N'SQLDataRoot',
	@dir OUTPUT, 
	'no_output'

--Convert result to UNC	
SELECT @dir = REPLACE(@dir,':','$') + N'\LOG'

--Resolve for named instance if applicable
IF CHARINDEX('\', @@SERVERNAME) = 0
	SELECT @dir = '\\' + @@SERVERNAME + '\' + @dir
ELSE
	SELECT @dir = '\\' + LEFT(@@SERVERNAME, CHARINDEX('\', @@SERVERNAME) - 1)  + '\' + @dir

RETURN @dir

END
GO

--TEST IT OUT:
SELECT fn_SQLServerErrorLogDir_UNC = dbo.fn_SQLServerErrorLogDir_UNC();


--***************************************************************************
-- nvarchar(4000) = dbo.fn_SQLServerErrorLogDir()
--author: Timothy Ford (thesqlagentman@gmail.com) 
---------http://thesqlagentman.com
--***************************************************************************
if OBJECT_ID('dbo.fn_SQLServerErrorLogDir') IS NOT NULL
DROP FUNCTION dbo.fn_SQLServerErrorLogDir;
GO

CREATE FUNCTION dbo.fn_SQLServerErrorLogDir()
RETURNS nvarchar(4000)
AS
BEGIN

DECLARE @rc int, @dir nvarchar(4000)

EXEC @rc = master.dbo.xp_instance_regread 
	N'HKEY_LOCAL_MACHINE',N'Software\Microsoft\MSSQLServer\Setup',N'SQLDataRoot',
	@dir OUTPUT, 
	'no_output'
	
SELECT @dir = @dir + N'\LOG'

RETURN @dir

END
GO

--TEST IT OUT:
SELECT fn_SQLServerErrorLogDir = dbo.fn_SQLServerErrorLogDir();
GO


--***************************************************************************
-- nvarchar(4000) = dbo.fn_SQLServerLogDir()
--author: Gert E.R. Drapers (GertD@SQLDev.Net)
--formatting: Timothy Ford (thesqlagentman@gmail.com) 
---------http://thesqlagentman.com
--***************************************************************************
if OBJECT_ID('dbo.fn_SQLServerLogDir') IS NOT NULL
DROP FUNCTION dbo.fn_SQLServerLogDir;
GO

CREATE FUNCTION dbo.fn_SQLServerLogDir()
RETURNS nvarchar(4000)
AS
BEGIN

DECLARE @rc int, @dir nvarchar(4000)

EXEC @rc = master.dbo.xp_instance_regread
	N'HKEY_LOCAL_MACHINE',
	N'Software\Microsoft\MSSQLServer\MSSQLServer',
	N'DefaultLog', 
	@dir OUTPUT, 
	'no_output'

IF (@dir IS NULL)
BEGIN

EXEC @rc = master.dbo.xp_instance_regread 
	N'HKEY_LOCAL_MACHINE',N'Software\Microsoft\MSSQLServer\Setup',
	N'SQLDataRoot',
	@dir OUTPUT, 
	'no_output'
	
SELECT @dir = @dir + N'\Data'
END

RETURN @dir

END
GO

--TEST IT OUT:
SELECT fn_SQLServerLogDir = dbo.fn_SQLServerLogDir();
GO



--***************************************************************************
-- nvarchar(4000) = dbo.fn_SQLServerBackupDir()
--Author: Timothy Ford (thesqlagentman@gmail.com) 
---------http://thesqlagentman.com
--***************************************************************************
IF OBJECT_ID('dbo.fn_SQLServerBackupDir') IS NOT NULL
DROP FUNCTION dbo.fn_SQLServerBackupDir
GO

CREATE FUNCTION dbo.fn_SQLServerBackupDir()
RETURNS nvarchar(4000)
AS
BEGIN

DECLARE @rc int,
@dir nvarchar(4000)

EXEC @rc = master.dbo.xp_instance_regread
	N'HKEY_LOCAL_MACHINE',
	N'Software\Microsoft\MSSQLServer\MSSQLServer',N'BackupDirectory',
	@dir OUTPUT, 
	'no_output'
RETURN @dir

END
GO

--TEST IT OUT:
SELECT fn_SQLServerBackupDir = dbo.fn_SQLServerBackupDir()
GO


--***************************************************************************
-- nvarchar(4000) = dbo.fn_SQLServerDataDir()
--author: Gert E.R. Drapers (GertD@SQLDev.Net)
--formatting: Timothy Ford (thesqlagentman@gmail.com) 
---------http://thesqlagentman.com
--***************************************************************************
IF OBJECT_ID('dbo.fn_SQLServerDataDir') IS NOT NULL
DROP FUNCTION dbo.fn_SQLServerDataDir
GO

CREATE FUNCTION dbo.fn_SQLServerDataDir()
RETURNS nvarchar(4000)
AS
BEGIN

DECLARE @rc int, @dir nvarchar(4000)

EXEC @rc = master.dbo.xp_instance_regread
	N'HKEY_LOCAL_MACHINE',
	N'Software\Microsoft\MSSQLServer\MSSQLServer',N'DefaultData',
	@dir OUTPUT, 
	'no_output'

IF (@dir is null)
BEGIN
EXEC @rc = master.dbo.xp_instance_regread
	N'HKEY_LOCAL_MACHINE',
	N'Software\Microsoft\MSSQLServer\Setup',
	N'SQLDataRoot',
	@dir OUTPUT, 
	'no_output'
	
SELECT @dir = @dir + N'\Data'
END

RETURN @dir

END
GO

--TEST IT OUT:
SELECT fn_SQLServerDataDir = dbo.fn_SQLServerDataDir()
GO

--***************************************************************************
-- nvarchar(4000) = dbo.fn_SQLServerTrxLogDir()
--author: Gert E.R. Drapers (GertD@SQLDev.Net)
--formatting: Timothy Ford (thesqlagentman@gmail.com) 
---------http://thesqlagentman.com
--***************************************************************************
IF OBJECT_ID('dbo.fn_SQLServerTrxLogDir') IS NOT NULL
DROP FUNCTION dbo.fn_SQLServerTrxLogDir
GO

CREATE FUNCTION dbo.fn_SQLServerTrxLogDir()
RETURNS nvarchar(4000)
AS
BEGIN

DECLARE @rc int, @dir nvarchar(4000)

EXEC @rc = master.dbo.xp_instance_regread
	N'HKEY_LOCAL_MACHINE',
	N'Software\Microsoft\MSSQLServer\MSSQLServer',N'DefaultLog',
	@dir OUTPUT, 
	'no_output'

IF (@dir is null)
BEGIN
EXEC @rc = master.dbo.xp_instance_regread
	N'HKEY_LOCAL_MACHINE',
	N'Software\Microsoft\MSSQLServer\Setup',
	N'SQLLogRoot',
	@dir OUTPUT, 
	'no_output'
	
SELECT @dir = @dir + N'\Logs'
END

RETURN @dir

END
GO

--TEST IT OUT:
SELECT fn_SQLServerTrxLogDir = dbo.fn_SQLServerTrxLogDir();
GO