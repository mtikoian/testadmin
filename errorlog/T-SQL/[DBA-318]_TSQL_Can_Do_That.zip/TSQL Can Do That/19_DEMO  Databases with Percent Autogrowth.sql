
/*
-------------------------------------------------------------
#19  Databases with Percent Autogrowth Settings

-------------------------------------------------------------
*/



CREATE TABLE #Results
(
[Database Name] nvarchar(128),
[File Name] nvarchar(128),
[Physical Name] nvarchar(500),
[File Type] varchar(4),
[DB Size (Mb)] int,
[DB Free (Mb)] int,
[Free Space %] int,
[Growth Units] varchar(28),
[Grow Max Size (Mb)] int
)

INSERT INTO #Results
EXEC iDBA.MetaBOT.usp_sizing NULL, NULL

--Where growth units in %
SELECT *
FROM #Results
WHERE [Growth Units] NOT LIKE '%Mb' OR [Growth Units] = '0Mb'
ORDER BY [Database Name];

DROP TABLE #Results;
