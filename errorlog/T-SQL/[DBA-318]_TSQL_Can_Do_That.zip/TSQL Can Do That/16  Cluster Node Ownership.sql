
/*
-------------------------------------------------------------
#16  Who Owns What in the Cluster?

(
-------------------------------------------------------------
*/

-- Get all cluster shared drive letters
SELECT Drivename
FROM sys.dm_io_cluster_shared_drives;

-- Get all cluster node machine names
SELECT NodeName
FROM sys.dm_os_cluster_nodes;

-- What machine owns the cluster resources
SELECT SERVERPROPERTY('ComputerNamePhysicalNetBIOS');