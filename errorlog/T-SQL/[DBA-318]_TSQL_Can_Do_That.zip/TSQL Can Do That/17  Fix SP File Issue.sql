
/*
-------------------------------------------------------------
#17  Fixes Poor File Configuration Setting in Sharepoint

(
-------------------------------------------------------------
*/

USE [WebAnalyticsServiceApplication_ReportingDB_<assigned guid,guid, 8675309a-2112-1968-tfaf-sql201212345>];
GO

CREATE SCHEMA [<schema, varchar(30), Foo>] AUTHORIZATION dbo;
GO


EXEC [<schema, varchar(30), Foo>].[usp_fix_poor_sharepoint_file_settings] 
    @set_size = 512
  , @set_filegrowth = 64



CREATE PROCEDURE [<schema, varchar(30), Foo>].usp_fix_poor_sharepoint_file_settings (@set_size INT, @set_filegrowth INT) 
AS
DECLARE @file_name sysname;
DECLARE @sql NVARCHAR(3000);
DECLARE @size INT;
DECLARE @filegrowth INT;
DECLARE @is_pct_growth BIT;

--FOR DEBUG-----------------
--DECLARE @set_size INT;
--DECLARE @set_filegrowth INT;

--SELECT @set_size = 512	--MB
--SELECT @set_filegrowth = 64
-----------------------------


--Assign variable values
SELECT TOP 1 @file_name = NAME 
FROM sys.[database_files] AS DF 
WHERE [type_desc] = 'ROWS' 
ORDER BY [file_id] DESC; 

SELECT @size = (size * 8 / 1024) 
FROM sys.[database_files] AS DF 
WHERE [name] = @file_name;


SELECT @filegrowth = [growth] 
FROM sys.[database_files] AS DF 
WHERE [name] = @file_name;


SELECT @is_pct_growth = [is_percent_growth] 
FROM sys.[database_files] AS DF 
WHERE [name] = @file_name;


--Check variable values:
--SELECT @file_name AS [logical_name], @size AS [file_size], @filegrowth AS [growth], @is_pct_growth AS [is_pct_growth];


--Fix File Size and Autogrowth
IF @size < @set_size AND (@filegrowth <> @set_filegrowth OR @is_pct_growth = 1)
	BEGIN
		SELECT @sql = 'ALTER DATABASE [' + db_name() + '] MODIFY FILE ( NAME = N' + '''' + @file_name + '''' + ', SIZE = ' + CAST(@set_size AS NVARCHAR(4)) + 'MB, FILEGROWTH = ' + CAST(@set_filegrowth AS NVARCHAR(3)) + 'MB )'
	END


--Size is fine, but autogrowth is not.  Fix it.
IF @size !< @set_size AND (@filegrowth <> @set_filegrowth OR @is_pct_growth = 1)
	BEGIN
		SELECT @sql = 'ALTER DATABASE [' + db_name() + '] MODIFY FILE ( NAME = N' + '''' + @file_name + '''' + ', FILEGROWTH = ' + CAST(@set_filegrowth AS NVARCHAR(3)) + 'MB )'
	END

EXEC [sys].[sp_executesql] @sql;
GO
