
/*
-------------------------------------------------------------
#2 Latest Log Backup for All Databases 

-------------------------------------------------------------
*/


---------------------------------------------------------------------
--Which databases should be receiving transaction log backup luvin'?
---------------------------------------------------------------------
SELECT NAME FROM sys.databases WHERE recovery_model_desc <> 'SIMPLE' ORDER BY name;
GO



WITH log_backups AS 
(
SELECT 
	ROW_NUMBER() OVER(PARTITION BY database_name ORDER BY database_name ASC, backup_finish_date DESC) AS [Row Number],
	database_name, 
	backup_set_id,
	backup_finish_date
FROM msdb.dbo.[backupset] 
WHERE [type] = 'L'
)

SELECT 
	BS.server_name, 
	BS.database_name, 
	FB.backup_finish_date,
	DATEDIFF(minute, FB.backup_finish_date ,getdate()) as [age_of_backup_in_minutes],
	BMF.physical_device_name,
	BMF.logical_device_name AS [backup_device_name]
FROM log_backups FB 
 INNER JOIN msdb.dbo.[backupset] BS ON FB.backup_set_id = BS.backup_set_id
 INNER JOIN msdb.dbo.backupmediafamily BMF ON BS.media_set_id = BMF.media_set_id
WHERE FB.[Row Number] = 1
ORDER BY FB.database_name;