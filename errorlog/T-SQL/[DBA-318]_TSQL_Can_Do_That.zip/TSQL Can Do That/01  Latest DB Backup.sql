
/*
-------------------------------------------------------------
#1  Latest Full Backup Information for All Databases

-------------------------------------------------------------
*/


WITH full_backups AS 
(
SELECT 
	ROW_NUMBER() OVER(PARTITION BY database_name ORDER BY database_name ASC, backup_finish_date DESC) AS [Row Number],
	database_name, 
	backup_set_id,
	backup_finish_date
FROM msdb.dbo.[backupset] 
WHERE [type] = 'D'
)

SELECT 
	BS.server_name, 
	BS.database_name, 
	FB.backup_finish_date,
	DATEDIFF(hour, FB.backup_finish_date ,getdate()) as [age_of_backup_in_hours],
	BMF.physical_device_name,
	BMF.logical_device_name AS [backup_device_name]
FROM full_backups FB 
 INNER JOIN msdb.dbo.[backupset] BS ON FB.backup_set_id = BS.backup_set_id
 INNER JOIN msdb.dbo.backupmediafamily BMF ON BS.media_set_id = BMF.media_set_id
WHERE FB.[Row Number] = 1
ORDER BY FB.database_name;