
/*
-------------------------------------------------------------
#18  Fun With Dates - Beginning and End of Month

(
-------------------------------------------------------------
*/


---------------------------------------
-- To Get First Day of Previous Month
---------------------------------------
SELECT DATEADD(MONTH, DATEDIFF(MONTH, '19000101', GETDATE()) - 1, '19000101')
AS [First Day Previous Month];
GO 



---------------------------------------
-- To Get First Day of Current Month
---------------------------------------
SELECT DATEADD(MONTH, DATEDIFF(MONTH, '19000101', GETDATE()), '19000101')
AS [First Day Current Month];
GO



---------------------------------------
-- To Get First Day of Next Month
---------------------------------------
SELECT DATEADD(MONTH, DATEDIFF(MONTH, '19000101', GETDATE()) + 1, '19000101')
AS [First Day Next Month];
GO



---------------------------------------
-- To Get Last Day of Previous Month
---------------------------------------
SELECT DATEADD(DAY, -1, DATEADD(MONTH, DATEDIFF(MONTH, '19000101', GETDATE()), '19000101'))
AS [Last Day Previous Month];
GO 



---------------------------------------
-- To Get Last Day of Current Month
---------------------------------------
SELECT DATEADD(DAY, -1, DATEADD(MONTH, DATEDIFF(MONTH, '19000101', GETDATE()) + 1, '19000101'))
AS [Last Day Current Month];
GO



---------------------------------------
-- To Get Last Day of Next Month
---------------------------------------
SELECT DATEADD(DAY, -1, DATEADD(MONTH, DATEDIFF(MONTH, '19000101', GETDATE()) + 2, '19000101'))
AS [Last Day Next Month];
GO
