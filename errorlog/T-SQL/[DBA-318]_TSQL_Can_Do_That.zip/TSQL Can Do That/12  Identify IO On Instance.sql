
/*
-------------------------------------------------------------
#12  IO, BUFFER, PLAN CACHE, AND PLE INTERPLAY

-------------------------------------------------------------
*/

-------------------------------------------------------------
--IO BY FILE
-------------------------------------------------------------
--How many days are in the sample?
SELECT TOP 1 (ioFS.sample_ms/1000/60/60/24) AS days_sampled
	, DATEADD(d, ((ioFS.sample_ms/1000/60/60/24)), getdate()) AS initiation_date
FROM sys.dm_io_virtual_file_stats(NULL,NULL) ioFS;



--What does the "raw" DMF data look like?
SELECT 
	db_name(ioFS.database_id) as database_name
	, MF.name as file_name 
	, MF.physical_name
	, ioFS.[num_of_reads]
	, ioFS.[num_of_bytes_read]
	, ioFS.[io_stall_read_ms]
	, CASE ioFS.[num_of_bytes_read]
		WHEN 0 THEN 0
		ELSE CAST(ioFS.[io_stall_read_ms] / (1.0 * ioFS.[num_of_reads]) AS DECIMAL(10,1)) 
	END AS [avg_read_io_stall]
	, ioFS.[num_of_writes]
	, ioFS.[num_of_bytes_written]
	, ioFS.[io_stall_write_ms]
	, CASE ioFS.[num_of_bytes_written]
		WHEN 0 THEN 0
		ELSE CAST(ioFS.[io_stall_write_ms] / (1.0 * ioFS.[num_of_writes]) AS DECIMAL(10,1))  
	END AS [avg_write_io_stall]
	, ioFS.[size_on_disk_bytes]
FROM sys.dm_io_virtual_file_stats(NULL,NULL) ioFS 
	INNER JOIN sys.master_files MF 
		ON ioFS.database_id = MF.database_id 
			AND ioFS.file_id = MF.file_id
ORDER BY ioFS.[num_of_bytes_read] DESC	






-------------------------------------------------------------
--IO LOAD BY DAY COMPARED TO BUFFER SIZE/AVAILABLE RAM
-------------------------------------------------------------
DECLARE @plan_cache_gb INT;
DECLARE @max_ram_gb INT;

SELECT @plan_cache_gb = SUM(CAST([size_in_bytes] AS BIGINT))/1024/1024/1024  FROM sys.dm_exec_cached_plans;

SELECT @max_ram_gb = (CONVERT(INT, SC.value)/1024)
FROM sys.[configurations] SC 
WHERE SC.[name] = 'max server memory (MB)';


SELECT 
	@max_ram_gb AS [Max Server Memory Setting (Gb)]
	, @plan_cache_gb as [Plan Cache Size (Gb)]
	, ioFS.sample_ms/1000/60/60/24 AS [Days in Sample]
	, ((SUM(ioFS.[num_of_reads]))/(ioFS.sample_ms/1000/60/60/24)) AS [Total Reads \Day]
	, ((SUM(ioFS.[num_of_writes]))/(ioFS.sample_ms/1000/60/60/24)) AS [Total Writes \Day]
	, ((SUM(ioFS.num_of_bytes_read))/1024/1024/1024/(ioFS.sample_ms/1000/60/60/24)) AS [Gb Read \Day]
	, ((SUM(ioFS.num_of_bytes_written))/1024/1024/1024/(ioFS.sample_ms/1000/60/60/24)) AS [Gb Written \Day]
	, (((SUM(ioFS.num_of_bytes_read))/1024/1024/1024/(ioFS.sample_ms/1000/60/60/24)))/(@max_ram_gb - @plan_cache_gb)  AS [Read IO :: Buffer Size]
FROM sys.dm_io_virtual_file_stats(NULL,NULL) ioFS 
GROUP BY ioFS.sample_ms;





-------------------------------------------------------------
--MEMORY LEVELS INFO AVAILABLE FROM DMVs
-------------------------------------------------------------
SELECT (physical_memory_in_bytes/1024/1024/1024) AS physical_memory_gb, (bpool_committed * 8/1024/1024) AS buffer_pool_committed_gb 
FROM sys.dm_os_sys_info;


--SQL 2008+ only:
SELECT total_physical_memory_kb/1024/1024 AS physical_memory_gb, available_physical_memory_kb/1024/1024 AS avail_physical_memory_gb 
FROM sys.dm_os_sys_memory;



-------------------------------------------------------------
--PLE
-------------------------------------------------------------
SELECT [object_name]
	, [counter_name]
	, [instance_name]
	, [cntr_value]
	, getdate() AS [date_stamp] 
FROM sys.[dm_os_performance_counters] 
WHERE [object_name] = 'SQLServer:Buffer Manager'
	AND [counter_name] = 'Page life expectancy'
