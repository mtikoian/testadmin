
/*
-------------------------------------------------------------
#3  Backup History for a Single Database

-------------------------------------------------------------
*/
-------------------------------------------------------------
--  Note that this is only as good as the history in msdb
-------------------------------------------------------------


SELECT 
	BS.server_name, 
	BS.database_name,
	CASE BS.type
		WHEN 'L' THEN 'Log'
		WHEN 'D' THEN 'Full'
		WHEN 'I' THEN 'Differential'
	END AS [backup_type], 
	BS.backup_finish_date,
	BMF.physical_device_name,
	BMF.logical_device_name AS [backup_device_name]
FROM msdb.dbo.[backupset] BS 
	INNER JOIN msdb.dbo.backupmediafamily BMF 
		ON BS.media_set_id = BMF.media_set_id
WHERE [database_name] = '<database_name, ,Foo>'
ORDER BY BS.database_backup_lsn DESC 

