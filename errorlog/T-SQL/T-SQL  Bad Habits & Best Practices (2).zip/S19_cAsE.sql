USE AdventureWorks2014;
GO

DBCC FREEPROCCACHE WITH NO_INFOMSGS;

GO
DECLARE @i INT = (SELECT TOP (1) StoreID FROM Sales.Customer);
GO
DECLARE @i INT = (SELECT TOP (1)  StoreID FROM Sales.Customer);
GO ------------ extra space -----^
GO
DECLARE @i INT = (SELECT TOP (1) storeid FROM sales.customer);
GO --------- lower case names ---^^^^^^^
GO
declare @i int = (select top (1) StoreID from Sales.Customer);
GO ---------------^^^^^^^^^^-- lower case keywords
GO

-- four different plans for the *same* query:

SELECT t.[text], p.size_in_bytes, p.usecounts
FROM sys.dm_exec_cached_plans AS p
CROSS APPLY sys.dm_exec_sql_text(p.plan_handle) AS t
WHERE LOWER(t.[text]) LIKE N'%sales'+'.'+'customer%';

-- this problem does *NOT* involve collation