USE AdventureWorks2014;
GO

DECLARE @i SYSNAME, @d DATETIME2 = SYSDATETIME();
-- run this with & without the cursor options commented.

DECLARE c CURSOR LOCAL FAST_FORWARD
FOR SELECT c1.name FROM sys.objects AS c1
 CROSS JOIN (SELECT TOP (400) name FROM sys.objects) AS c2;

OPEN c; FETCH c INTO @i;

WHILE @@FETCH_STATUS <> -1
BEGIN
  SET @i += N'';
  FETCH c INTO @i;
END

CLOSE c; DEALLOCATE c;

SELECT DATEDIFF(MILLISECOND, @d, SYSDATETIME());