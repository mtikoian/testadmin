-- POP QUIZ : what will these yield?
 
DECLARE @x VARCHAR = 'aaron';

SELECT 
  [variable] = @x,
  [cast_var] = CAST(@x AS VARCHAR(MAX)),
  [cast]     = CAST('aaron' AS VARCHAR),
  [convert]  = CONVERT(VARCHAR, 'aaron');













-- in some cases VARCHAR is 1, others 30.
-- some violations get silent truncation, others error

-- silent truncation

USE tempdb;
GO
CREATE PROCEDURE dbo.foo
  @bar VARCHAR
AS
BEGIN
  SET NOCOUNT ON;
  PRINT @bar;
END
GO
EXEC dbo.foo @bar = 'more than one character';
GO
DROP PROCEDURE dbo.foo;
GO

-- truncation yielding an error

DECLARE @t TABLE(x VARCHAR);

INSERT @t(x) SELECT 'aaron';





