--Reset Snapshot Isolation
USE master;
GO
DECLARE @snapshot_isolation bit, @is_rcsi_on bit
SELECT @snapshot_isolation = snapshot_isolation_state, @is_rcsi_on = is_read_committed_snapshot_on FROM sys.Databases where name = 'AdventureWorks2014'
IF @is_rcsi_on = 1
BEGIN
	PRINT 'Disabling RCSI'
	ALTER DATABASE AdventureWorks2014 SET READ_COMMITTED_SNAPSHOT OFF WITH ROLLBACK IMMEDIATE
END
IF @snapshot_isolation = 1
BEGIN
	PRINT 'Disabling SNAPSHOT'
	ALTER DATABASE AdventureWorks2014 SET ALLOW_SNAPSHOT_ISOLATION OFF
END
GO

USE AdventureWorks2014
GO
--This also will demonstrate Dirty Reads/Non-Repeatable Reads and Phantom Reads
--Make sure the first section of EnlargeAdventureWorks is run that creates the table
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
BEGIN TRANSACTION
SELECT COUNT(*) FROM Sales.SalesOrderHeaderEnlarged  --31465
COMMIT TRANSACTION
GO
---Start Enlarge AdventureWorks (1:28 to execute)

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
BEGIN TRANSACTION
SELECT COUNT(*) FROM Sales.SalesOrderHeaderEnlarged  --31465....  --table created and initial values vales inserted
GO
WAITFOR DELAY '00:00:15'
GO
SELECT COUNT(*) FROM Sales.SalesOrderHeaderEnlarged --31465 -- still the same! (Dirty Reads)
WAITFOR DELAY '00:00:35'
GO
SELECT COUNT(*) FROM Sales.SalesOrderHeaderEnlarged  -- Random large number based on what the script does.  
GO

IF @@trancount >0 
BEGIN
	COMMIT TRANSACTION
END
ELSE
BEGIN
	ROLLBACK TRANSACTION
END
GO
WAITFOR DELAY '00:00:39'
SELECT COUNT(*) FROM Sales.SalesOrderHeaderEnlarged  -- same as the count after the 35 second delay...
GO