/****************************************/
/*	Basic Checks for Isolation levels	*/
/****************************************/

--Check the current connection's isolation level:
dbcc useroptions

--Set the isolation level in a specific query:
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED 
DBCC USEROPTIONS


--Different options from sys.dm_exec_sessions for transaction_isolation_level
select CASE WHEN Transaction_isolation_level = 1 THEN 'ReadUncommitted'
WHEN transaction_isolation_level = 2 THEN 'ReadCommitted'
WHEN transaction_isolation_level = 3 THEN 'RepeatableRead' 
WHEN transaction_isolation_level = 4 THEN 'Serializable'
WHEN transaction_isolation_level = 5 THEN 'Snapshot' 
END, transaction_isolation_level from sys.dm_exec_sessions where session_id = @@spid

SELECT name,snapshot_isolation_state, snapshot_isolation_state_desc, is_read_committed_snapshot_on FROM sys.databases --WHERE name = 'AdventureWorks2014'

