--Show Blocked Process Report
EXEC sp_configure 'show advanced options',1
GO
RECONFIGURE WITH OVERRIDE 
GO
EXEC sp_configure 'blocked process threshold'
GO
EXEC sp_configure 'blocked process threshold',5
GO
RECONFIGURE WITH OVERRIDE
GO
EXEC sp_configure 'blocked process threshold'
GO
CREATE EVENT SESSION [Blocked_Process_Recording] ON SERVER 
ADD EVENT sqlserver.blocked_process_report
WITH (MAX_MEMORY=4096 KB,EVENT_RETENTION_MODE=ALLOW_SINGLE_EVENT_LOSS,MAX_DISPATCH_LATENCY=30 SECONDS,MAX_EVENT_SIZE=0 KB,MEMORY_PARTITION_MODE=NONE,TRACK_CAUSALITY=OFF,STARTUP_STATE=ON)
GO

--Start Serializable select
--Start Repeatable Read insert (Repeatable Read Part 2)
--Wait for results to show up in XE
