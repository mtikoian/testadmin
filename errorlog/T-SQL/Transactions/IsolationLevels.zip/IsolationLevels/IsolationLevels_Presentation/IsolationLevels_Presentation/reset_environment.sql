/* Reset Environment */
IF EXISTS (select * from sys.dm_xe_sessions where name = 'Blocked_Process_Tracking') 
BEGIN
	DROP EVENT SESSION [Blocked_Process_Tracking]
	ON SERVER
END
GO
sp_configure 'blocked process threshold',0
go
reconfigure with override
go
IF db_id('AdventureWorks2014') IS NOT NULL
BEGIN
	PRINT 'Dropping Database AdventureWorks 2014'
	DROP DATABASE AdventureWorks2014
END 
GO