USE AdventureWorks2014
SET TRANSACTION ISOLATION LEVEL SNAPSHOT

BEGIN TRANSACTION 

	DECLARE @bi_id int
	
	SELECT @bi_id = MAX(BusinessEntityID) FROM Person.Person WHERE FirstName = 'Bob' and LastName = 'Smith'

	DELETE FROM Person.Person WHERE BusinessEntityID = @bi_id

COMMIT TRANSACTION 
GO

