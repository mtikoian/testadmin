USE master;
GO
DECLARE @snapshot_isolation bit, @is_rcsi_on bit
SELECT @snapshot_isolation = snapshot_isolation_state, @is_rcsi_on = is_read_committed_snapshot_on FROM sys.Databases where name = 'AdventureWorks2014'
IF @is_rcsi_on = 0
BEGIN
	PRINT 'Enabling RCSI'
	ALTER DATABASE AdventureWorks2014 SET READ_COMMITTED_SNAPSHOT ON WITH ROLLBACK IMMEDIATE
END
IF @snapshot_isolation = 1
BEGIN
	PRINT 'Disabling SNAPSHOT'
	ALTER DATABASE AdventureWorks2014 SET ALLOW_SNAPSHOT_ISOLATION OFF
END
GO
USE AdventureWorks2014
GO
SET TRANSACTION ISOLATION LEVEL READ COMMITTED
BEGIN TRANSACTION
SELECT COUNT(*) FROM Person.Person WHERE LastName = 'Smith' and FirstName = 'Agent'
--Start 6.Demo_Read_Committed_Snapshot_part_2.sql
SELECT COUNT(*) FROM Person.Person WHERE LastName = 'Smith' and FirstName = 'Bob'
COMMIT
