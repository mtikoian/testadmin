uSE AdventureWorks2014
go
SET TRANSACTION ISOLATION LEVEL READ COMMITTED

BEGIN TRANSACTION 

	DECLARE @bi_id int
	
	SELECT @bi_id = MAX(BusinessEntityID) FROM Person.Person WHERE FirstName = 'Bob' and LastName = 'Smith'
	DELETE FROM Person.Person WHERE BusinessEntityID = @bi_id

COMMIT TRANSACTION 
GO

