USE AdventureWorks2014
GO
SET TRANSACTION ISOLATION LEVEL READ COMMITTED

BEGIN TRANSACTION 

	DECLARE @bi_id int
	
	SELECT @bi_id = MAX(BusinessEntityID) FROM Person.Person WHERE FirstName='Bob' AND LastName='Smith'

	DELETE FROM Person.Person WHERE BusinessEntityID = @bi_id

COMMIT TRANSACTION 
GO

SET TRANSACTION ISOLATION LEVEL READ COMMITTED
BEGIN TRANSACTION

	DECLARE @bi_id int

	INSERT INTO person.BusinessEntity DEFAULT VALUES
	SET @bi_id = SCOPE_IDENTITY()

	INSERT INTO Person.Person (BusinessEntityID,PersonType,NameStyle,FirstName,LastName)
	VALUES
	(@bi_id,'IN',0,'Bob','Smith')
COMMIT TRANSACTION 
GO