--Reset Snapshot Isolation
USE master;
GO
DECLARE @snapshot_isolation bit, @is_rcsi_on bit
SELECT @snapshot_isolation = snapshot_isolation_state, @is_rcsi_on = is_read_committed_snapshot_on FROM sys.Databases where name = 'AdventureWorks2014'
IF @is_rcsi_on = 1
BEGIN
	PRINT 'Disabling RCSI'
	ALTER DATABASE AdventureWorks2014 SET READ_COMMITTED_SNAPSHOT OFF WITH ROLLBACK IMMEDIATE
END
IF @snapshot_isolation = 1
BEGIN
	PRINT 'Disabling SNAPSHOT'
	ALTER DATABASE AdventureWorks2014 SET ALLOW_SNAPSHOT_ISOLATION OFF
END
GO
USE AdventureWorks2014
GO
SET TRANSACTION ISOLATION LEVEL REPEATABLE READ
BEGIN TRANSACTION
SELECT count(*) FROM Person.Person WHERE LastName = 'Smith' --105 rows
--Start insert in different window
SELECT count(*) FROM Person.Person WHERE LastName = 'Smith' --106 rows
SELECT count(*) FROM Person.Person WHERE LastName = 'Smith' -- 107 rows (phantom reads)
COMMIT