--Reset Snapshot Isolation
USE master;
GO
DECLARE @snapshot_isolation bit, @is_rcsi_on bit
SELECT @snapshot_isolation = snapshot_isolation_state, @is_rcsi_on = is_read_committed_snapshot_on FROM sys.Databases where name = 'AdventureWorks2014'
IF @is_rcsi_on = 1
BEGIN
	PRINT 'Disabling RCSI'
	ALTER DATABASE AdventureWorks2014 SET READ_COMMITTED_SNAPSHOT OFF WITH ROLLBACK IMMEDIATE
END
IF @snapshot_isolation = 1
BEGIN
	PRINT 'Disabling SNAPSHOT'
	ALTER DATABASE AdventureWorks2014 SET ALLOW_SNAPSHOT_ISOLATION OFF
END
GO
USE AdventureWorks2014
GO

SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
BEGIN TRANSACTION
SELECT COUNT(*) FROM Person.Person WHERE LastName = 'Smith' and FirstName = 'Agent' -- 3
--Start 5.Demo_Serializable_Part_2.sql
SELECT COUNT(*) FROM Person.Person WHERE LastName = 'Smith' and FirstName = 'Agent' --still 3, no dirty reads, no non-repeatable reads, no phantom reads
COMMIT

SELECT COUNT(*) FROM Person.Person WHERE LastName = 'Smith' and FirstName = 'Agent' --still 3, no dirty reads, no non-repeatable reads, no phantom reads