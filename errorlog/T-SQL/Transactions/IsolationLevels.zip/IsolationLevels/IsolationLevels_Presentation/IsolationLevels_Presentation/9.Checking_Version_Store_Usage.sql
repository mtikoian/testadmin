---Use RCSI demos to show this
SELECT version_store_reserved_page_count*8 AS Version_Store_kb FROM tempdb.sys.dm_db_file_space_usage

SELECT Object_name,counter_name,cntr_value FROM sys.dm_os_performance_counters WHERE Counter_name IN ('Version Generation rate (KB/s)','Version Cleanup rate (KB/s)','Version Store Size (KB)')

SELECT * FROM sys.dm_tran_version_store

SELECT * FROM sys.dm_tran_current_snapshot