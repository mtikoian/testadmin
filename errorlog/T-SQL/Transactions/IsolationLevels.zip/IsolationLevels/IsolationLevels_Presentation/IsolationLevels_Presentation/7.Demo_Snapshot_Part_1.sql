USE master;
GO
DECLARE @snapshot_isolation bit, @is_rcsi_on bit
SELECT @snapshot_isolation = snapshot_isolation_state, @is_rcsi_on = is_read_committed_snapshot_on FROM sys.Databases where name = 'AdventureWorks2014'
IF @is_rcsi_on = 1
BEGIN
	PRINT 'Disabling RCSI'
	ALTER DATABASE AdventureWorks2014 SET READ_COMMITTED_SNAPSHOT OFF WITH ROLLBACK IMMEDIATE
END
IF @snapshot_isolation = 0
BEGIN
	PRINT 'Enabling SNAPSHOT'
	ALTER DATABASE AdventureWorks2014 SET ALLOW_SNAPSHOT_ISOLATION ON 
END
GO
USE AdventureWorks2014
GO
SET TRANSACTION ISOLATION LEVEL SNAPSHOT
BEGIN TRANSACTION
SELECT COUNT(*) FROM Person.Person WHERE LastName = 'Smith' and FirstName = 'Bob'
--Run 7.Demo_Snapshot_Part_2.sql
SELECT COUNT(*) FROM Person.Person WHERE LastName = 'Smith' and FirstName = 'Bob'
COMMIT
--Run again
SELECT COUNT(*) FROM Person.Person WHERE LastName = 'Smith' and FirstName = 'Bob'