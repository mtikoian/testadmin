USE AdventureWorks2014
GO
SET TRANSACTION ISOLATION LEVEL REPEATABLE READ

BEGIN TRANSACTION 

	DECLARE @bi_id int

	INSERT INTO person.BusinessEntity DEFAULT VALUES
	SET @bi_id = SCOPE_IDENTITY()

	INSERT INTO Person.Person (BusinessEntityID,PersonType,NameStyle,FirstName,LastName)
	VALUES
	(@bi_id,'IN',0,'Agent','Smith')

COMMIT TRANSACTION 
GO

WAITFOR DELAY '00:00:10'

SET TRANSACTION ISOLATION LEVEL REPEATABLE READ
BEGIN TRANSACTION

	DECLARE @bi_id int

	INSERT INTO person.BusinessEntity DEFAULT VALUES
	SET @bi_id = SCOPE_IDENTITY()

	INSERT INTO Person.Person (BusinessEntityID,PersonType,NameStyle,FirstName,LastName)
	VALUES
	(@bi_id,'IN',0,'Bob','Smith')
COMMIT TRANSACTION 
GO

WAITFOR DELAY '00:00:10'

SET TRANSACTION ISOLATION LEVEL REPEATABLE READ
BEGIN TRANSACTION

	DECLARE @bi_id int

	INSERT INTO person.BusinessEntity DEFAULT VALUES
	SET @bi_id = SCOPE_IDENTITY()

	INSERT INTO Person.Person (BusinessEntityID,PersonType,NameStyle,FirstName,LastName)
	VALUES
	(@bi_id,'IN',0,'Roger','Smith')
COMMIT TRANSACTION 
GO

WAITFOR DELAY '00:00:10'

SET TRANSACTION ISOLATION LEVEL REPEATABLE READ
BEGIN TRANSACTION

	DECLARE @bi_id int

	INSERT INTO person.BusinessEntity DEFAULT VALUES
	SET @bi_id = SCOPE_IDENTITY()

	INSERT INTO Person.Person (BusinessEntityID,PersonType,NameStyle,FirstName,LastName)
	VALUES
	(@bi_id,'IN',0,'Jerry','Smith')
COMMIT TRANSACTION 
GO

WAITFOR DELAY '00:00:10'

SET TRANSACTION ISOLATION LEVEL REPEATABLE READ
BEGIN TRANSACTION

	DECLARE @bi_id int

	INSERT INTO person.BusinessEntity DEFAULT VALUES
	SET @bi_id = SCOPE_IDENTITY()

	INSERT INTO Person.Person (BusinessEntityID,PersonType,NameStyle,FirstName,LastName)
	VALUES
	(@bi_id,'IN',0,'Richard','Smith')
COMMIT TRANSACTION 
GO

WAITFOR DELAY '00:00:10'

SET TRANSACTION ISOLATION LEVEL REPEATABLE READ
BEGIN TRANSACTION

	DECLARE @bi_id int

	INSERT INTO person.BusinessEntity DEFAULT VALUES
	SET @bi_id = SCOPE_IDENTITY()

	INSERT INTO Person.Person (BusinessEntityID,PersonType,NameStyle,FirstName,LastName)
	VALUES
	(@bi_id,'IN',0,'Ted','Smith')
COMMIT TRANSACTION
GO

SET TRANSACTION ISOLATION LEVEL REPEATABLE READ
BEGIN TRANSACTION

	DECLARE @bi_id int

	INSERT INTO person.BusinessEntity DEFAULT VALUES
	SET @bi_id = SCOPE_IDENTITY()

	INSERT INTO Person.Person (BusinessEntityID,PersonType,NameStyle,FirstName,LastName)
	VALUES
	(@bi_id,'IN',0,'Ted','Smith')
COMMIT TRANSACTION
GO
