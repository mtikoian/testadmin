USE master;
GO
DECLARE @snapshot_isolation bit, @is_rcsi_on bit
SELECT @snapshot_isolation = snapshot_isolation_state, @is_rcsi_on = is_read_committed_snapshot_on FROM sys.Databases where name = 'AdventureWorks2014'
IF @is_rcsi_on = 1
BEGIN
	PRINT 'Disabling RCSI'
	ALTER DATABASE AdventureWorks2014 SET READ_COMMITTED_SNAPSHOT OFF WITH ROLLBACK IMMEDIATE
END
IF @snapshot_isolation = 1
BEGIN
	PRINT 'Disabling SNAPSHOT'
	ALTER DATABASE AdventureWorks2014 SET ALLOW_SNAPSHOT_ISOLATION OFF
END
GO
USE AdventureWorks2014
GO
SET TRANSACTION ISOLATION LEVEL READ COMMITTED
BEGIN TRANSACTION
SELECT COUNT(*) FROM Person.Person WHERE LastName = 'Smith' and FirstName = 'Bob'  -- 2 rows
--Run 3.Demo_Read_Committed_Part_2.sql delete statement
SELECT COUNT(*) FROM Person.Person WHERE LastName = 'Smith' and FirstName = 'Bob'	--1, no dirty reads allowed, but still non-repeatable
--Run 3.Demo_Read_Committed_Part_2.sql insert statement, but don't commit
SELECT COUNT(*) FROM Person.Person WHERE LastName = 'Smith' and FirstName = 'Bob'	--Can't read it because the data is not committed
SELECT COUNT(*) FROM Person.Person WITH (NOLOCK) WHERE LastName = 'Smith' and FirstName = 'Bob'	-- 2 rows, it's a phantom read
COMMIT
SELECT COUNT(*) FROM Person.Person WHERE LastName = 'Smith' and FirstName = 'Bob'	