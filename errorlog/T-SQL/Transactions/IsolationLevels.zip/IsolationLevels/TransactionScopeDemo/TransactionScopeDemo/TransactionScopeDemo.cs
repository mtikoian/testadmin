﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TransactionScopeDemo
{
    public partial class TransactionScopeDemo : Form
    {
       
        public TransactionScopeDemo()
        {
            InitializeComponent();
        }
        
        //string xacttype;
        private GroupBox groupBox1;
        private RadioButton btnxactReadUncommitted;
        private RadioButton btnxactReadCommitted;
        private RadioButton btnxactRepeatableRead;
        private RadioButton btnxactSerializable;
        private RadioButton btnxactSnapshot;
        private RadioButton selectedoption;
        private Button btnstartDemo;

        
        private void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // TransactionScopeDemo
            // 
            {
                this.groupBox1 = new System.Windows.Forms.GroupBox();
                this.btnxactReadUncommitted = new System.Windows.Forms.RadioButton();
                this.btnxactReadCommitted = new System.Windows.Forms.RadioButton();
                this.btnxactRepeatableRead = new System.Windows.Forms.RadioButton();
                this.btnxactSerializable = new System.Windows.Forms.RadioButton();
                this.btnxactSnapshot = new System.Windows.Forms.RadioButton();
                this.btnstartDemo = new System.Windows.Forms.Button();


                this.groupBox1.Controls.Add(this.btnxactReadUncommitted);
                this.groupBox1.Controls.Add(this.btnxactReadCommitted);
                this.groupBox1.Controls.Add(this.btnxactRepeatableRead);
                this.groupBox1.Controls.Add(this.btnxactSerializable);
                this.groupBox1.Controls.Add(this.btnxactSnapshot);
                this.groupBox1.Location = new System.Drawing.Point(25, 20);
                this.groupBox1.Size = new System.Drawing.Size(200, 125);
                this.groupBox1.Text = "Isolation Level";

                this.btnxactReadUncommitted.Location = new System.Drawing.Point(20, 13);
                this.btnxactReadUncommitted.Size = new System.Drawing.Size(150, 20);
                this.btnxactReadUncommitted.Text = "ReadUncommitted";
                this.btnxactReadUncommitted.CheckedChanged += new EventHandler(radioButton_CheckedChanged);

                this.btnxactReadCommitted.Location = new System.Drawing.Point(20, 33);
                this.btnxactReadCommitted.Size = new System.Drawing.Size(150, 20);
                this.btnxactReadCommitted.Text = "ReadCommitted";
                this.btnxactReadCommitted.CheckedChanged += new EventHandler(radioButton_CheckedChanged);

                this.btnxactRepeatableRead.Location = new System.Drawing.Point(20, 53);
                this.btnxactRepeatableRead.Size = new System.Drawing.Size(150, 20);
                this.btnxactRepeatableRead.Text = "RepeatableRead";
                this.btnxactRepeatableRead.CheckedChanged += new EventHandler(radioButton_CheckedChanged);

                this.btnxactSerializable.Location = new System.Drawing.Point(20, 73);
                this.btnxactSerializable.Size = new System.Drawing.Size(150, 20);
                this.btnxactSerializable.Text = "Serializable";
                this.btnxactSerializable.CheckedChanged += new EventHandler(radioButton_CheckedChanged);

                this.btnxactSnapshot.Location = new System.Drawing.Point(20, 93);
                this.btnxactSnapshot.Size = new System.Drawing.Size(150, 20);
                this.btnxactSnapshot.Text = "Snapshot";
                this.btnxactSnapshot.CheckedChanged += new EventHandler(radioButton_CheckedChanged);

                //this.btnstartDemo = new System.Windows.Forms.Button();
                this.btnstartDemo.Location = new System.Drawing.Point(25,175);
                this.btnstartDemo.Size = new System.Drawing.Size(100, 25);
                this.btnstartDemo.Text = "Start Demo";
                this.btnstartDemo.Click += new EventHandler(getSelectedRB_Click);

                //this.ClientSize = new System.Drawing.Size(450, 250);
                this.Controls.Add(this.groupBox1);
                this.Controls.Add(this.btnstartDemo);
                this.Name = "TransactionScopeDemo";
                this.Text = "TransactionScopeDemo";
                this.ClientSize = new System.Drawing.Size(425, 275);
                //this.Load += new System.EventHandler(this.TransactionScopeDemo_Load);
                this.ResumeLayout(false);


            }
        }
       void radioButton_CheckedChanged(object sender, EventArgs e)
        {
            RadioButton rb = sender as RadioButton;

            if (rb == null)
            {
                MessageBox.Show("Sender is not a RadioButton");
                return;
            }

            // Ensure that the RadioButton.Checked property
            // changed to true.
            if (rb.Checked)
            {
                // Keep track of the selected RadioButton by saving a reference
                // to it.
                selectedoption = rb;
            }
        }

        // Show the text of the selected RadioButton.
        void getSelectedRB_Click(object sender, EventArgs e)
        {
            if (selectedoption != null)
            {
                MessageBox.Show(selectedoption.Text);
            }
            if (selectedoption == null)
            {
                MessageBox.Show("No option Selected");
            }
        }

        }

        //private void TransactionScopeDemo_Load(object sender, EventArgs e)
        //{
        //    //InitializeObjects();
        //    //initializeButtons();
        //}

    }

