--SQL Server Concurrency
--Phantom Read - Session 1
USE TSQL2012
SET TRANSACTION ISOLATION LEVEL
READ COMMITTED
BEGIN TRAN
	SELECT AcctID, AcctName, 
		Balance, ModifiedDate
	FROM Accounting.BankAccounts
WAITFOR DELAY '00:00:10:000'
	SELECT AcctID, AcctName, 
		Balance, ModifiedDate
	FROM Accounting.BankAccounts
COMMIT TRAN