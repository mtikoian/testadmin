--	SQL Server Concurrency 
-- Dirty Read - Session 1
USE TSQL2012
GO
SET TRANSACTION ISOLATION LEVEL
READ UNCOMMITTED
BEGIN TRAN
	UPDATE Accounting.BankAccounts
	SET Balance -= 300
	WHERE AcctID = 1
		WAITFOR DELAY '00:00:10:000'
	ROLLBACK TRAN
	SELECT AcctID, AcctName, Balance
	FROM Accounting.BankAccounts
	WHERE AcctID = 1





