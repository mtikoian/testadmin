--SQL Server Concurrency
--Dirty Read - Session 2
USE TSQL2012
SET TRANSACTION ISOLATION LEVEL
READ UNCOMMITTED
	SELECT * FROM Accounting.BankAccounts
	WHERE AcctID = 1



