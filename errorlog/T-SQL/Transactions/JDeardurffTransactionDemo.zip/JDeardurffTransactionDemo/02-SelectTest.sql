USE TSQL2012
GO

SELECT * FROM Accounting.BankAccounts

CREATE SYNONYM dbo.AcctBal
FOR Accounting.BankAccounts
