USE AdventureWorks2012
GO
SET STATISTICS IO ON
GO


DBCC freeproccache
go
SELECT *
FROM Production.TransactionHistory WITH (FORCESCAN)
WHERE ProductID = 995;

/* can force index used for seek too if desired
   or let engine decide on best */
DBCC freeproccache
go
SELECT *
FROM Production.TransactionHistory WITH (FORCESEEK) 
WHERE ProductID = 995;

DBCC freeproccache
go
SELECT *
FROM Production.TransactionHistory
WHERE ProductID = 995;

SELECT COUNT(*) FROM Production.TransactionHistory

SELECT 307.0/113443
