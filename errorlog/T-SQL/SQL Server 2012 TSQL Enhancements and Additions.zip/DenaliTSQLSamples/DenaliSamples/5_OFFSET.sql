SET NOCOUNT ON

/* OFFSET */
USE AdventureWorks2012
GO
--use profiler
--SET STATISTICS IO ON
--SET STATISTICS TIME ON

/* SQL 2000 */

DECLARE @StartRow INT=11
DECLARE @PageSize INT=10

DECLARE @FirstBusinessEntityIDInPage INT

SELECT @FirstBusinessEntityIDInPage=MAX(BusinessEntityID) FROM
(
   SELECT TOP (@StartRow-1) BusinessEntityID
     FROM HumanResources.Employee
    ORDER BY BusinessEntityID ASC
) a


SELECT TOP (@PageSize) *
  FROM HumanResources.Employee
 WHERE BusinessEntityID>@FirstBusinessEntityIDInPage
 ORDER BY BusinessEntityID ASC


---Problems: rows can get in the middle or be deleted. performance not so good.
--- must be based on unique row/s

/* SQL 2005-2008 */

DECLARE @StartRow INT=11
DECLARE @PageSize INT=10

;
WITH Page as
(
SELECT *, ROW_NUMBER() OVER (ORDER BY JobTitle ASC) as RowNum
  FROM HumanResources.Employee
)
SELECT * FROM Page
WHERE RowNum Between @StartRow AND @StartRow + @PageSize -1


GO
---- Sorting based on an indexed column
DECLARE @StartRow INT=11
DECLARE @PageSize INT=10;

WITH Page as
(
SELECT *, ROW_NUMBER() OVER (ORDER BY BusinessEntityID) as RowNum
   FROM HumanResources.Employee
)
SELECT *
  FROM Page
 WHERE RowNum Between @StartRow AND @StartRow + @PageSize -1

GO

--- Complex writing using a CTE/ Subquery. -- sorting based on not-indexed column


/* SQL Denali */


DECLARE @StartRow INT=101
DECLARE @PageSize BIGINT=10

SELECT *
  FROM HumanResources.Employee
 ORDER BY JobTitle OFFSET @StartRow-1 ROWS FETCH NEXT @PageSize ROWS ONLY

GO

/* The sort is still here, and so is the full scan... */
/* What about order by an indexed column ? */


DECLARE @StartRow INT=101
DECLARE @PageSize BIGINT=10

SELECT *
  FROM HumanResources.Employee
 ORDER BY BusinessEntityID OFFSET @StartRow-1 ROWS FETCH NEXT @PageSize ROWS ONLY

-- any 3 rows?
SELECT *
  FROM HumanResources.Employee
 ORDER BY (SELECT NULL)
OFFSET 0 ROWS FETCH NEXT 3 ROWS ONLY;

GO

