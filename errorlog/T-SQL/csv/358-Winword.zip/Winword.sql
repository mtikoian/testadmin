/*
e.g.
Create table #MyContent  (Paragraph_ID int,
						Style varchar(20),
						Content Varchar(8000))
Insert into #myContent
	Exec spWord_Document_content @documentFile ='C:\MyDocs\FooBar.doc'
Select * from #mycontent

Execute spWord_Document_content 'C:\MyDocs\FooBar.doc'
*/
alter procedure spWord_Document_content 
@documentFile varchar(100)
as
Declare 
	@objWord int,		--the OLE Word object
	@objdocument int,	--the OLE Document object
	@objdocuments int,	--the OLE Documents collection
	@objParagraphs int,	--the OLE Paragraphs collection
	@objParagraph int,	--the OLE Word object
	@hr int,
	@command varchar(255),
	@strErrorMessage varchar(255),
	@objErrorObject int,
	@objConnection int,
	@bucket int,
	@ii int,
	@Style varchar(100),
	@Text varchar(8000),
	@iiMax int,
	@wdAlertsNone int
Set nocount on
Declare @Content Table (Paragraph_ID int identity(1,1),
						Style varchar(20),
						Content Varchar(8000))
Select @wdAlertsNone=0
Select @strErrorMessage='instantiating Word application ',
			@objErrorObject=null
EXEC @hr=sp_OACreate 'Word.Application', @objWord OUT
if @hr=0 Select @strErrorMessage='Ensuring no alerts',
			@objErrorObject=@objWord
if @hr=0 EXEC @hr=sp_OASetProperty @objWord, 
			'DisplayAlerts', @wdAlertsNone
if @hr=0 Select @strErrorMessage='Ensuring Word invisible',
			@objErrorObject=@objWord
if @hr=0 EXEC @hr=sp_OASetProperty @objWord, 
			'Visible', 0

if @hr=0 Select @strErrorMessage ='Opening the file',
			@objErrorObject=@objDocuments,
			@command='FileName:="'+@DocumentFile+'"'
if @hr=0 EXEC @hr=sp_OAGetProperty @objWord, 'documents.open', 
		@objDocument output ,@Documentfile

if @hr=0 Select @strErrorMessage ='Getting the paragraph object',
		@objErrorObject=@objDocument
if @hr=0 EXEC @hr=sp_OAGetProperty @objDocument,'Paragraphs', 
		@objParagraphs output

if @hr=0 Select @strErrorMessage ='Getting the number of paragraphs',
			@objErrorObject=@objParagraphs
if @hr=0 EXEC @hr=sp_OAGetProperty 
		@objParagraphs, 'Count', @iiMax output

--and loop arount
Select @ii=1
While @ii<=@iiMax and @hr=0
	begin
	if @hr=0 Select @strErrorMessage ='Getting the paragraph',
				@objErrorObject=@objDocument,
				@Command='paragraphs('+cast(@ii as varchar(5))+')'
	if @hr=0 EXEC @hr=sp_OAGetProperty @objDocument, 
		@Command, @objParagraph output
	if @hr=0 Select @strErrorMessage ='Getting the Range Text',
				@objErrorObject=@objParagraph
	if @hr=0 EXEC @hr=sp_OAGetProperty 
		@objParagraph, 'Range.Text', @Text output
	if @hr=0 Select @strErrorMessage ='Getting the Style',
				@objErrorObject=@objParagraph
	if @hr=0 EXEC @hr=sp_OAGetProperty 
		@objParagraph, 'Range.Style.NameLocal', @Style output
	insert into @Content (Style,content) select @style, @Text
	select @ii=@ii+1
	end

EXEC sp_OAMethod @objWord, 'Quit'
if @hr<>0
	begin
	Declare 
		@Source varchar(255),
		@Description Varchar(255),
		@Helpfile Varchar(255),
		@HelpID int
	EXECUTE sp_OAGetErrorInfo  @objErrorObject, @source output,
		@Description output,@Helpfile output,@HelpID output
	Select @strErrorMessage='Error whilst '
		+coalesce(@strErrorMessage,'doing something')+', '
		+coalesce(@Description,'')
	raiserror (@strErrorMessage,16,1)
	end
EXEC sp_OADestroy @objParagraph
EXEC sp_OADestroy @objParagraphs
EXEC sp_OADestroy @objDocuments
EXEC sp_OADestroy @objWord
EXEC sp_OAStop
Select * from @content
go

