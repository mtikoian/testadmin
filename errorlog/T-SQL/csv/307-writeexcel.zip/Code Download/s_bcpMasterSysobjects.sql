use tempdb
go
create proc s_bcpMasterSysobjects
as
   select   '"' + name + '"'
            + ',' + '"' + convert(varchar(8), crdate, 112) + '"'
            + ',' + '"' + convert(varchar(8), crdate, 108) + '"'
   from master..sysobjects
   order by crdate desc
go
declare @sql varchar(8000)
select @sql = 'bcp "exec tempdb..s_bcpMasterSysobjects" queryout c:\bcp\sysobjects.txt -c -t, -T -S' + @@servername
exec master..xp_cmdshell @sql

use tempdb
go
alter proc s_bcpMasterSysobjects
as
	set nocount on
	
	create table #a (seq int, crdate datetime, s varchar(1000))
	-- header - column headers
	insert	#a (seq, crdate, s)
	select	1, null,
			'"name","crdate","crtime"'
	
	-- data
	insert	#a (seq, crdate, s)
	select	2, crdate,
					'"' + name + '"'
			+ ',' +	'"' + convert(varchar(8), crdate, 112) + '"'
			+ ',' +	'"' + convert(varchar(8), crdate, 108) + '"'
	from master..sysobjects

	-- trailer - rowcount
	insert	#a (seq, crdate, s)
	select	3, null,
			'rowcount = ' + convert(varchar(20),count(*)-1)
	from #a

	select	s
	from	#a
	order by seq, crdate desc
go

declare @sql varchar(8000)
select @sql = 'bcp "set fmtonly off exec tempdb..s_bcpMasterSysobjects" queryout c:\bcp\sysobjects.txt -c -T -S' + @@servername
exec master..xp_cmdshell @sql

use tempdb
go
create table Extract
	(
	Extract_ID	int ,
	Seq1		varchar(100) null ,
	Seq2		varchar(100) null ,
	Seq3		varchar(100) null ,
	Data		varchar(8000) ,
	InsertDate	datetime default getdate()
	)
go
alter proc s_bcpMasterSysobjects
@ExtractID int
as
declare @rowcount int
	set nocount on
	
	-- header - column headers
	insert	Extract (Extract_ID, Seq1, Data)
	select	@ExtractID,
			'01' ,
			'"name","crdate","crtime"'
	
	-- data
	insert	Extract (Extract_ID, Seq1, Seq2, Data)
	select	@ExtractID,
			'02' ,
			+ convert(varchar(100), '99990101' - crdate, 121) ,
					'"' + name + '"'
			+ ',' +	'"' + convert(varchar(8), crdate, 112) + '"'
			+ ',' +	'"' + convert(varchar(8), crdate, 108) + '"'
	from master..sysobjects

	select @rowcount = @@rowcount
	
	-- trailer - rowcount
	insert	Extract (Extract_ID, Seq1, Data)
	select	@ExtractID,
			'03' ,
			'rowcount = ' + convert(varchar(20),@rowcount)
go
create proc s_Extract
@ExtractID int
as
	select	Data
	from	Extract
	where	Extract_ID = @ExtractID
	order	by Seq1, Seq2, Seq3
go

Create table ExportLog (Export_id int, Status varchar(20))

Insert ExportLog select 25, 'Extracting'
exec tempdb..s_bcpMasterSysobjects 25
update ExportLog set Status = 'Exporting' where Export_id = 25
declare @sql varchar(8000)
select @sql = 'bcp "exec tempdb..s_Extract 25" queryout c:\bcp\sysobjects.txt -c -T -S' + @@servername
exec master..xp_cmdshell @sql
update ExportLog set Status = 'complete' where Export_id = 25

exec tempdb..s_Extract 25

select * from tempdb..Extract order by Seq1, Seq2, Seq3