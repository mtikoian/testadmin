--*******************************************
-- Presentation to SQLSaturday #26, Redmond, Oct 03, 2009
-- Arnie Rowland, MVP (SQL Server)
--*******************************************


--*******************************************
-- Problem: Numerically Sort AlphaNumeric Data
-- 1        NULL first, Then Alpha, Then Numeric
--*******************************************

SET NOCOUNT ON;

DECLARE @MyTable table
   (  RowID    int         IDENTITY,
      MyData   varchar(12)
   );

INSERT INTO @MyTable VALUES ( '95' );
INSERT INTO @MyTable VALUES ( '2' );
INSERT INTO @MyTable VALUES ( 'N/A' );
INSERT INTO @MyTable VALUES ( 'Bill' );
INSERT INTO @MyTable VALUES ( '14' );
INSERT INTO @MyTable VALUES ( '$25' );
INSERT INTO @MyTable VALUES ( '2.5' );
INSERT INTO @MyTable VALUES ( '0.5' );
INSERT INTO @MyTable VALUES ( NULL );

SELECT
   RowID,
   MyData
FROM @MyTable
ORDER BY
   CASE WHEN MyDATA IS NULL THEN 1 ELSE 2 END,
   CASE WHEN MyData LIKE '%[^$.0-9]%' THEN 1 ELSE 2 END,
   CASE WHEN MyData NOT LIKE '%[^$.0-9]%' THEN cast( MyData AS money ) END;

/*
RowID       MyData
----------- ------------
7           NULL
3           N/A
2           2
6           2.5
4           14
5           $25
1           95
*/


--*********************************************
-- Problem: Table Recursion using CTE
-- 2        Find all Paths related to INPUT
--       show query plan spooling
--    SQL 2008+ can do this with Hierarchy datatype
--*********************************************

DECLARE @Ancestor varchar(10);

DECLARE @Family table
   (  Parent varchar(10) ,
      Child  varchar(10)
   );

INSERT INTO @Family VALUES( 'X', 'Y' );
INSERT INTO @Family VALUES( 'X', 'Z' );
INSERT INTO @Family VALUES( 'Y', 'A' );
INSERT INTO @Family VALUES( 'Y', 'B' );
INSERT INTO @Family VALUES( 'B', 'C' );
INSERT INTO @Family VALUES( 'B', 'D' );
INSERT INTO @Family VALUES( 'C', 'E' );
INSERT INTO @Family VALUES( 'C', 'F' );
INSERT INTO @Family VALUES( 'F', 'G' );

SET @Ancestor = 'Y'

;WITH CTE
   (  Parent,
      Child,
      Level,
      Lineage
   )
AS
   (  SELECT
         Parent,
         Child,
         1 AS [Level],
         cast(Parent + '\' + Child as varchar(100)) AS [Lineage]
      FROM @Family
      WHERE Parent = @Ancestor

      UNION ALL

      SELECT
         data.Parent,
         data.Child,
         Level + 1,
         cast( Lineage + '\' + data.Child AS varchar(100) )
      FROM @Family Data
         JOIN CTE
            ON Data.Parent = CTE.Child
   )

SELECT
   Parent,
   Child,
   Lineage,
   Level
FROM CTE
ORDER BY Lineage;

/*
Parent Child Lineage        Level
------ ----- -------------- -----
Y      A     Y\A            1
Y      B     Y\B            1
B      C     Y\B\C          2
C      E     Y\B\C\E        3
C      F     Y\B\C\F        3
F      G     Y\B\C\F\G      4
B      D     Y\B\D          2
*/


--********************************************************
-- Problem: Delete All BUT the MOST RECENT Row for each
-- 3        Client Record
--********************************************************

SET NOCOUNT ON;

DECLARE @MyTable table
   (  [ID]               int IDENTITY,
      MemberID           int,
      [Name]             varchar(20),
      SurName            varchar(20),
      DateOfAssessment   datetime
   );

INSERT INTO @MyTable VALUES ( 2, 'Bill', 'Jones', '2007/05/25' );
INSERT INTO @MyTable VALUES ( 3, 'Mary', 'Smith', '2007/05/26' );
INSERT INTO @MyTable VALUES ( 4, 'Susy', 'Williams', '2007/05/22' );
INSERT INTO @MyTable VALUES ( 2, 'Bill', 'Jones', '2007/05/27' );
INSERT INTO @MyTable VALUES ( 2, 'Bill', 'Jones', '2007/04/26' );
INSERT INTO @MyTable VALUES ( 3, 'Mary', 'Smith', '2007/05/21' );
INSERT INTO @MyTable VALUES ( 3, 'Mary', 'Smith', '2007/04/30' );

SELECT *
FROM   @MyTable;

DELETE @MyTable  --proprietery TSQL syntax - beware of incorrect data, especially on UPDATE FROM ...
   FROM @MyTable m
    JOIN (SELECT  --another possible solution is using ROW_NUMBER
            MemberID,
            DateOfAssessment = max( DateOfAssessment )
         FROM @MyTable
         GROUP BY MemberID ) dt
      ON (   m.MemberID = dt.MemberID
         AND m.DateOfAssessment <> dt.DateOfAssessment
         );

SELECT *
FROM   @MyTable
ORDER BY MemberID;

/*
ID     MemberID  Name      SurName     DateOfAssessment
------ --------- --------- ----------- ------------------------
4      2         Bill      Jones       2007-05-27 00:00:00.000
2      3         Mary      Smith       2007-05-26 00:00:00.000
3      4         Susy      Williams    2007-05-22 00:00:00.000
*/


--********************************************************
-- Problem: SELECT Every nth Row of Data in Time Sequence
-- 4
--********************************************************

SET NOCOUNT ON;

DECLARE @nthRow int
SET @nthRow = 12

DECLARE @MyTable table
   (  [Time]  datetime,
      [Close] decimal(8,2),
      [Value] int
  );

INSERT INTO @MyTable VALUES ( '04 Jul 2008 14:39', 4008.70, 0 );
INSERT INTO @MyTable VALUES ( '04 Jul 2008 14:40', 4007.40, 0 );
INSERT INTO @MyTable VALUES ( '04 Jul 2008 14:41', 4017.15, 0 );
INSERT INTO @MyTable VALUES ( '04 Jul 2008 14:42', 4019.90, 0 );
INSERT INTO @MyTable VALUES ( '04 Jul 2008 14:43', 4018.10, 0 );
INSERT INTO @MyTable VALUES ( '04 Jul 2008 14:44', 4016.70, 0 );
INSERT INTO @MyTable VALUES ( '04 Jul 2008 14:45', 4021.80, 0 );
INSERT INTO @MyTable VALUES ( '04 Jul 2008 14:46', 4022.20, 0 );
INSERT INTO @MyTable VALUES ( '04 Jul 2008 14:47', 4022.40, 0 );
INSERT INTO @MyTable VALUES ( '04 Jul 2008 14:48', 4024.15, 0 );
INSERT INTO @MyTable VALUES ( '04 Jul 2008 14:49', 4021.15, 0 );
INSERT INTO @MyTable VALUES ( '04 Jul 2008 14:50', 4017.55, 0 );
INSERT INTO @MyTable VALUES ( '04 Jul 2008 14:51', 4018.65, 0 );
INSERT INTO @MyTable VALUES ( '04 Jul 2008 14:52', 4014.85, 0 );
INSERT INTO @MyTable VALUES ( '04 Jul 2008 14:53', 4013.70, 0 );
INSERT INTO @MyTable VALUES ( '04 Jul 2008 14:54', 4017.65, 0 );
INSERT INTO @MyTable VALUES ( '04 Jul 2008 14:55', 4019.70, 0 );
INSERT INTO @MyTable VALUES ( '04 Jul 2008 14:56', 4015.15, 0 );
INSERT INTO @MyTable VALUES ( '04 Jul 2008 14:57', 4015.70, 0 );
INSERT INTO @MyTable VALUES ( '04 Jul 2008 14:58', 4019.10, 0 );
INSERT INTO @MyTable VALUES ( '04 Jul 2008 14:59', 4023.65, 0 );
INSERT INTO @MyTable VALUES ( '04 Jul 2008 15:00', 4029.75, 0 );
INSERT INTO @MyTable VALUES ( '04 Jul 2008 15:01', 4030.00, 0 );
INSERT INTO @MyTable VALUES ( '04 Jul 2008 15:02', 4029.75, 0 );
INSERT INTO @MyTable VALUES ( '04 Jul 2008 15:03', 4026.45, 0 );
INSERT INTO @MyTable VALUES ( '04 Jul 2008 15:04', 4023.60, 0 );
INSERT INTO @MyTable VALUES ( '04 Jul 2008 15:05', 4022.00, 0 );
INSERT INTO @MyTable VALUES ( '04 Jul 2008 15:06', 4024.45, 0 );
INSERT INTO @MyTable VALUES ( '04 Jul 2008 15:07', 4023.90, 0 );
INSERT INTO @MyTable VALUES ( '04 Jul 2008 15:08', 4021.60, 0 );
INSERT INTO @MyTable VALUES ( '04 Jul 2008 15:09', 4018.55, 0 );
INSERT INTO @MyTable VALUES ( '04 Jul 2008 15:10', 4020.95, 0 );
INSERT INTO @MyTable VALUES ( '04 Jul 2008 15:11', 4019.50, 0 );
INSERT INTO @MyTable VALUES ( '04 Jul 2008 15:12', 4022.20, 0 );
INSERT INTO @MyTable VALUES ( '04 Jul 2008 15:13', 4022.85, 0 );
INSERT INTO @MyTable VALUES ( '04 Jul 2008 15:14', 4026.55, 0 );
INSERT INTO @MyTable VALUES ( '04 Jul 2008 15:15', 4024.55, 0 );
INSERT INTO @MyTable VALUES ( '04 Jul 2008 15:16', 4021.55, 0 );
INSERT INTO @MyTable VALUES ( '04 Jul 2008 15:17', 4016.95, 0 );
INSERT INTO @MyTable VALUES ( '04 Jul 2008 15:18', 4012.10, 0 );
INSERT INTO @MyTable VALUES ( '04 Jul 2008 15:19', 4015.65, 0 );
INSERT INTO @MyTable VALUES ( '04 Jul 2008 15:20', 4013.10, 0 );
INSERT INTO @MyTable VALUES ( '04 Jul 2008 15:21', 4017.65, 0 );
INSERT INTO @MyTable VALUES ( '04 Jul 2008 15:22', 4016.15, 0 );
INSERT INTO @MyTable VALUES ( '04 Jul 2008 15:23', 4012.60, 0 );
INSERT INTO @MyTable VALUES ( '04 Jul 2008 15:24', 4007.00, 0 );
INSERT INTO @MyTable VALUES ( '04 Jul 2008 15:25', 4000.25, 0 );
INSERT INTO @MyTable VALUES ( '04 Jul 2008 15:26', 4001.25, 0 );
INSERT INTO @MyTable VALUES ( '04 Jul 2008 15:27', 4006.00, 0 );
INSERT INTO @MyTable VALUES ( '04 Jul 2008 15:28', 4004.70, 0 );
INSERT INTO @MyTable VALUES ( '04 Jul 2008 15:29', 4002.00, 0 );
INSERT INTO @MyTable VALUES ( '04 Jul 2008 15:30', 4001.15, 0 );
INSERT INTO @MyTable VALUES ( '04 Jul 2008 15:31', 4001.15, 0 );
INSERT INTO @MyTable VALUES ( '04 Jul 2008 15:32', 4001.15, 0 );
INSERT INTO @MyTable VALUES ( '04 Jul 2008 15:33', 4001.15, 0 );

SELECT *
FROM (SELECT
         [RowNum] = ROW_NUMBER() OVER( ORDER BY [Time] ),
         [Time],
         [Close],
         [Value]
      FROM @MyTable
     ) dt
WHERE ( [RowNum] % @nthRow ) = 0;

/*
RowNum   Time                    Close    Value
5        2008-07-04 14:43:00.000 4018.10  0
10       2008-07-04 14:48:00.000 4024.15  0
15       2008-07-04 14:53:00.000 4013.70  0
20       2008-07-04 14:58:00.000 4019.10  0
25       2008-07-04 15:03:00.000 4026.45  0
30       2008-07-04 15:08:00.000 4021.60  0
35       2008-07-04 15:13:00.000 4022.85  0
40       2008-07-04 15:18:00.000 4012.10  0
45       2008-07-04 15:23:00.000 4012.60  0
50       2008-07-04 15:28:00.000 4004.70  0
55       2008-07-04 15:33:00.000 4001.15  0
*/


--********************************************************
-- Problem: Retrieve Summary and Activity Data
-- 5        From Activity Data (Log)
--********************************************************

SET NOCOUNT ON;

DECLARE @MyTable table
   (  RecordID  int IDENTITY,
      UserID    int,
      SaleDate  datetime,
      SaleAmt   money
    );

INSERT @MyTable VALUES ( 1111, '01/01/09 09:30 AM', 25 )
INSERT @MyTable VALUES ( 2222, '01/01/09 12:30 PM', 0 )
INSERT @MyTable VALUES ( 3333, '01/02/09 05:00 AM', 0 )
INSERT @MyTable VALUES ( 2222, '01/02/09 07:00 AM', 0 )
INSERT @MyTable VALUES ( 3333, '01/03/09 10:00 AM', 0 )
INSERT @MyTable VALUES ( 2222, '01/03/09 01:30 PM', 15 )
INSERT @MyTable VALUES ( 1111, '01/04/09 12:30 AM', 10 )
INSERT @MyTable VALUES ( 2222, '01/05/09 05:00 PM', 0 )
INSERT @MyTable VALUES ( 1111, '01/05/09 11:00 PM', 30 )

SELECT
   [UserID],
   min( [SaleDate] ) AS [First Visit],
   max( [SaleDate] ) AS [Last Visit],
   count( [RecordID] ) AS [Total Visits],
   sum( CASE SaleAmt WHEN 0 THEN 0 ELSE 1 END ) AS [Sales],
   sum( SaleAmt ) AS [Total Sales]
FROM @MyTable
GROUP BY [UserID];

/*
UserID   First Visit             Last Visit              Total Visits Sales Total Sales
1111     2009-01-01 09:30:00.000 2009-01-05 23:00:00.000 3            3     65.00
2222     2009-01-01 12:30:00.000 2009-01-05 17:00:00.000 4            1     15.00
3333     2009-01-02 05:00:00.000 2009-01-03 10:00:00.000 2            0     0.00
*/


--********************************************************
-- Problem: SELECT Item Data, Total Number of Items, Number
-- 6        of Pages, and which Items Belong on Which Pages
--          Row Zero returns the counts
-- NOTE 1: including the totals is expensive
-- NOTE 2: Paging can often be MUCH more efficient using
--         Dynamic SQL, especially when complex and multi-table
--********************************************************

USE AdventureWorks;
GO

DECLARE @PageSize    decimal(5,1),
        @PriceFilter decimal(8,2);
SELECT @PageSize    = 10,
        @PriceFilter = 1000;

;WITH CTE
AS
   (  SELECT
         row_number() OVER ( ORDER BY ProductID) AS [RowNumber],
         p.ProductID,
         p.Name,
         p.ListPrice
      FROM Production.Product p
      WHERE ListPrice >= @PriceFilter
   )

   SELECT
      RowNumber,
      ceiling( RowNumber / @PageSize ) AS [Page],
      ProductID,
      Name,
      ListPrice
   FROM CTE

   UNION

   SELECT
      0,
      max( ceiling( RowNumber / @PageSize )),
      count( 1 ),
      'Page and Row Count',
      0
   FROM CTE

   ORDER BY RowNumber;

/*
RowNumber Page ProductId   Name                  ListPrice
0          4          35   Page and Row Count    0.00
1          1         749   Road-150 Red, 62      3578.27
2          1         750   Road-150 Red, 44      3578.27
3          1         751   Road-150 Red, 48      3578.27
4          1         752   Road-150 Red, 52      3578.27
...
33         4         967   Touring-1000 Blue, 50 2384.07
34         4         968   Touring-1000 Blue, 54 2384.07
35         4         969   Touring-1000 Blue, 60 2384.07
*/


--********************************************************
-- Problem: Create Sequencing Numbers
-- 7        Such as Invoice Line Item Numbering
--********************************************************
/* skip
SET NOCOUNT ON;

DECLARE @Orders TABLE
   (  InvoiceNumber int,
      ItemNumber    int
   );

INSERT INTO @Orders VALUES ( 1, 10 );
INSERT INTO @Orders VALUES ( 1, 50 );
INSERT INTO @Orders VALUES ( 1, 30 );
INSERT INTO @Orders VALUES ( 2, 10000 );
INSERT INTO @Orders VALUES ( 2, 500 );
INSERT INTO @Orders VALUES ( 2, 30 );

SELECT
   o1.InvoiceNumber,
   count(1) AS [LineNumber],
   o1.ItemNumber
FROM @Orders o1
   JOIN @Orders o2
      ON (   o1.InvoiceNumber  = o2.InvoiceNumber
         AND o1.ItemNumber    >= o2.ItemNumber --be careful, 'triangular join'
         )
GROUP BY
   o1.InvoiceNumber,
   o1.ItemNumber
ORDER BY
   o1.InvoiceNumber,
   [LineNumber];

/*
InvoiceNumber  LineNumber  ItemNumber
1              1           10
1              2           30
1              3           50
2              1           30
2              2           500
2              3           10000
*/
*/

--********************************************************
-- Problem: Aggregating Data Totals by Month, Quarter, Year
-- 8
-- Can also use PIVOT, but I prefer CASE, which is my
--   favorite 4-letter TSQL word!
--********************************************************

USE AdventureWorks;
GO

DECLARE @Now datetime
SET @Now = '06/25/2004';

SELECT
   CustomerID,
   max( OrderDate ) AS [OrderDate],
   sum( TotalDue ) AS [TotalDue],
   SUM(CASE
          WHEN OrderDate >= dateadd( month, datediff( month, 0, @Now), 0 ) THEN TotalDue  --note not a function on column!! :-)
          ELSE 0
      END) AS [MonthToDate],
   SUM(CASE
          WHEN OrderDate >= dateadd( quarter, datediff( quarter, 0, @Now), 0 ) THEN TotalDue
          ELSE 0
      END) AS [QuarterToDate],
   SUM(CASE
          WHEN OrderDate >= dateadd( year, datediff( year, 0, @Now), 0 ) THEN TotalDue
          ELSE 0
      END) AS [YearToDate]
FROM    Sales.SalesOrderHeader
WHERE CustomerID IN ( 11001, 11013, 11017, 11018, 11019 )
GROUP BY CustomerID
ORDER BY CustomerID;

/*
CustomerID  OrderDate                TotalDue   MonthToDate QuarterToDate  YearToDate
11001       2004-06-12 00:00:00.000  7054.1875  650.8008    650.8008       650.8008
11013       2004-07-24 00:00:00.000  125.9258   82.8529     82.8529        82.8529
11017       2004-04-16 00:00:00.000  7109.9127  0.00        820.2968       820.2968
11018       2004-04-26 00:00:00.000  7219.2745  0.00        874.4086       874.4086
11019       2004-07-15 00:00:00.000  975.384    460.6856    540.533        638.1599
*/


-- ****************************************************************
-- Problem: Value Reassignments
-- 9        Using CASE to resign Values
-- ****************************************************************

SET NOCOUNT ON;

DECLARE @MyTable table
   (  RowID     int     IDENTITY,
      Num       int,
      Affirmed  varchar(10)
   );

INSERT INTO @MyTable ( Num ) VALUES ( 1 );
INSERT INTO @MyTable ( Num ) VALUES ( 0 );
INSERT INTO @MyTable ( Num ) VALUES ( NULL );

-- Value Re-assignments in a SELECT query
SELECT
   RowID,
   Affirmed = CASE Num
                 WHEN 0 THEN 'Yes'
                 WHEN 1 THEN 'No'
                 ELSE 'n/a'
              END,
   Num
FROM @MyTable;

/*
RowID       Affirmed Num
----------- -------- -----------
1           No       1
2           Yes      0
3           n/a      NULL
*/

SELECT
   RowId,
   Affirmed,
   Num
FROM @MyTable;

/*
RowId Affirmed Num
1     NULL     1
2     NULL     0
3     NULL     NULL
*/

-- Value Re-assignments in an UPDATE query
UPDATE @MyTable
   SET
      Affirmed = CASE Num
                    WHEN 0 THEN 'Yes'
                    WHEN 1 THEN 'No'
                    ELSE 'n/a'
                 END;

SELECT *
FROM   @MyTable;

/*
RowID       Affirmed Num
----------- -------- -----------
1           No       1
2           Yes      0
3           n/a      NULL
*/


--********************************************************
-- Problem: Display TOP 5 Amounts and Total of All Remaining Rows
-- 10
--********************************************************

SET NOCOUNT ON;

DECLARE @MyDataTable table
   (  [ID]     int          IDENTITY,
      [Amount] decimal(10,2)
   );

DECLARE @MyResultsTable table
   (  RowID    int          IDENTITY,
      [ID]     varchar(10),
      [Amount] decimal(10,2)
   );

INSERT INTO @MyDataTable VALUES ( 5 );
INSERT INTO @MyDataTable VALUES ( 200 );
INSERT INTO @MyDataTable VALUES ( 15 );
INSERT INTO @MyDataTable VALUES ( 325 );
INSERT INTO @MyDataTable VALUES ( 12 );
INSERT INTO @MyDataTable VALUES ( 37 );
INSERT INTO @MyDataTable VALUES ( 121 );
INSERT INTO @MyDataTable VALUES ( 32 );
INSERT INTO @MyDataTable VALUES ( 31 );
INSERT INTO @MyDataTable VALUES ( 177 );

-- First, get the TOP 5
INSERT INTO @MyResultsTable
   SELECT TOP 5
      [ID],
      [Amount]
   FROM @MyDataTable
   ORDER BY [Amount] DESC;

-- Then, Calculate the Remaining Total
INSERT INTO @MyResultsTable ( [ID], [Amount] )
   SELECT 'Remainder',
          ((  SELECT sum( Amount )
             FROM @MyDataTable
           )
          -
           (  SELECT sum( [Amount] )
             FROM   @MyResultsTable
           )
          );

-- Return the data
SELECT
   [ID],
   [Amount]
FROM   @MyResultsTable
ORDER BY RowID;

/*
ID         Amount
---------- ------------
4          325.00
2          200.00
10         177.00
7          121.00
6          37.00
Remainder  95.00
*/


--********************************************************
-- Problem: Create a Comma Delimited list from values in
-- 11         multiple rows
-- SQLServerCentral.com has a HUGE thread on this with lots of code and benchmarks
-- *******************************************************

SET NOCOUNT ON;

DECLARE @MyTable table
   (  RowID         int      IDENTITY,
      CustomerName  varchar(20)
   );

DECLARE @MyList varchar(1000);

INSERT INTO @MyTable VALUES( 'Smith' );
INSERT INTO @MyTable VALUES( 'Williams' );
INSERT INTO @MyTable VALUES( 'O''Reilly' );
INSERT INTO @MyTable VALUES( 'Jones' );
INSERT INTO @MyTable VALUES( 'Johnson' );
INSERT INTO @MyTable VALUES( 'Marvin' );

SELECT DISTINCT
   @MyList = substring( ( SELECT ', ' + CustomerName as [text()]
                       FROM @MyTable t2
                       WHERE t2.CustomerName <= t1.CustomerName
                       ORDER BY CustomerName
                       FOR XML path(''), elements --anyone think of a problem with this?
                     ), 3, 1000
                   )
FROM @MyTable t1;

SELECT @MyList;

/*
-------------------------------------------------
Johnson, Jones, Marvin, O'Reilly, Smith, Williams
*/


--********************************************************
-- Problem: Conditionally Select FROM Two Child Tables
-- 12
-- NOTE: PLEASE don't design this on purpose!!  :-)
-- ****************************************************************

SET NOCOUNT ON;

DECLARE @MasterTable table
   (    MasterID          integer,
        Column1           integer,
        Column2           integer,
        ConditionalField  varchar(5)
   );

INSERT INTO @MasterTable VALUES ( 1, 11, 21, 'True' );
INSERT INTO @MasterTable VALUES ( 2, 12, 22, 'False' );
INSERT INTO @MasterTable VALUES ( 3, 13, 23, 'True' );

DECLARE @TableA table
   (    MasterID        integer,
        Column3         integer
   );

INSERT INTO @TableA VALUES ( 1, 101 );
INSERT INTO @TableA VALUES ( 2, 102 );
INSERT INTO @TableA VALUES ( 3, 103 );

DECLARE @TableB table
   (    MasterID        integer,
        Column3         integer
   );

INSERT INTO @TableB VALUES ( 1, 201 );
INSERT INTO @TableB VALUES ( 2, 202 );
INSERT INTO @TableB VALUES ( 3, 203 );

SELECT
   m.MasterID,
   m.Column1,
   m.Column2,
   coalesce( a.Column3, b.Column3 ) AS [Column3]
FROM @MasterTable m
   LEFT JOIN @TableA a
      ON (   m.MasterID = a.MasterID
         AND m.ConditionalField = 'True'
         )
   LEFT JOIN @TableB b
      ON (   m.MasterID = b.MasterID
         AND m.ConditionalField = 'False'
         );

/*
MasterID Col1  Col2  Col3
1        11    21    101
2        12    22    202
3        13    23    103
*/


--*************************************************************************
-- Problem: Insert Data into two tables with a single INSERT statement
-- 13       Uses OUTPUT (a very powerful and useful 6 letters!)
--*************************************************************************

USE tempdb;
GO

SET NOCOUNT ON;

DECLARE @MyTable table
   (  RowId   int  IDENTITY(101,1),
      MyData varchar(20)
   );

DECLARE @MyArchiveTable table
   (  ArchiveID    int  IDENTITY,
      RowId        int,
      MyData       varchar(20),
      ArchiveDate  datetime,
      ArchiveUser  varchar(50)
   );

INSERT INTO @MyTable
      OUTPUT
         inserted.RowId,
         inserted.MyData,
         getdate(),
         system_user
      INTO @MyArchiveTable
   VALUES
      ( 'This is my Test Data' );

SELECT
   RowID,
   MyData
FROM @MyTable;

SELECT
   ArchiveID,
   RowID,
   MyData,
   ArchiveDate,
   ArchiveUser
FROM @MyArchiveTable;

/*
RowID t1Value
101   This is my Test Data
*/

/*
ArchiveID RowID MyData               ArchiveDate             ArchiveUser
1         101   This is my Test Data 2009-03-11 15:24:35.723 WESTWOOD\Arnie
*/

--*************************************************************************
-- Problem: UPDATE one table, save Old/New values to archive table
-- 14       Uses: OUTPUT
--*************************************************************************

USE tempdb;
GO

SET NOCOUNT ON;

DECLARE @Order TABLE
   (  RowID       int  IDENTITY,
      CustomerID  int,
      OrderNo     varchar(5),
      OrderDate   datetime,
      OrderAmt    decimal(7,2)
   );

DECLARE @OrderArchive TABLE
   (  ArchiveID    int  IDENTITY,
      OrderRowID   int,
      CustomerID   int,
      OrderNo      varchar(5),
      OrderDate    datetime,
      PrevOrderAmt decimal(7,2),
      NewOrderAmt  decimal(7,2),
      ChgDate      datetime,
      ChgUser      varchar(50)
   );

INSERT INTO @Order VALUES ( 1001, 25, '2009/03/09', 125.50 );
INSERT INTO @Order VALUES ( 1001, 26, '2009/03/09', 100.00 );

UPDATE @Order
   SET OrderAmt = 150
   OUTPUT
      inserted.RowID,
      inserted.CustomerID,
      inserted.OrderNo,
      inserted.OrderDate,
      deleted.OrderAmt,
      inserted.OrderAmt,
      getdate(),
      system_user
   INTO @OrderArchive
   WHERE OrderNo = 25;

SELECT *
FROM @Order;

SELECT *
FROM @OrderArchive;

/*
RowID CustomerID  OrderNo  OrderDate               OrderAmt
1     1001        25       2009-03-09 00:00:00.000 150.00
2     1001        26       2009-03-09 00:00:00.000 100.00
*/

/*
ArchiveID   OrderRowID  CustomerID  OrderNo  OrderDate               PrevOrderAmt   NewOrderAmt ChgDate                 ChgUser
1           1           1001        25       2009-03-09 00:00:00.000 125.50         150.00      2009-03-26 12:11:22.113 WESTWOOD\Arnie
*/

--*************************************************************************
-- Problem: Get and Use Next Sequence Number
-- 16       Uses: OUTPUT
--*************************************************************************

SET NOCOUNT ON;

USE tempdb;
GO

IF object_id( 'dbo.Invoices', 'U' ) IS NOT NULL
   DROP TABLE dbo.Invoices;
GO

CREATE TABLE dbo.Invoices
   (  InvoiceID  int NOT NULL,
      CustomerID int NOT NULL,
      InvDate    datetime NOT NULL,
      InvAmount  money NOT NULL,
      CONSTRAINT PK_Invoices PRIMARY KEY( InvoiceID )
   );
GO

IF object_id( 'dbo.Sequence', 'U' ) IS NOT NULL
   DROP TABLE dbo.Sequence;
GO

CREATE TABLE dbo.Sequence
   (  SeqVal int NOT NULL  );
GO

-- Seed the Sequence Numbers
INSERT INTO dbo.Sequence( SeqVal )
   VALUES( 1000 );
GO

CREATE PROCEDURE dbo.InsertInvoice
   @CustomerID  int,
   @InvDate     datetime,
   @InvAmount   money,
   @InvoiceID   int OUTPUT
AS
--ALERT!! Proprietary TSQL 'trick' here, not guaranteed to do what you expect with > 1 row!!!
--search sqlservercentral.com for Jeff Moden Quirky Update for numerous caveats and provisos
   UPDATE dbo.Sequence
      SET @InvoiceID = SeqVal = SeqVal + 1
   OUTPUT
      inserted.SeqVal,
      @CustomerID,
      @InvDate,
      @InvAmount
   INTO dbo.Invoices;
GO


/* Test
   DECLARE @NewInvoiceID int;

   EXEC dbo.InsertInvoice
      @CustomerID  = 1,
      @InvDate     = '20090212',
      @InvAmount   = 1000.00,
      @InvoiceID   = @NewInvoiceID OUTPUT;

   SELECT @NewInvoiceID;

   SELECT *
   FROM dbo.Invoices;

   SELECT *
   FROM dbo.Sequence;

*/

/* Clean Up
   DROP TABLE dbo.Invoices
   DROP TABLE dbo.Sequence
   DROP PROCEDURE dbo.InsertInvoice
*/


--*************************************************************************
-- Problem: Find the Missing Parts of a List of Requirements
-- 17       Uses: CROSS JOIN
--          Use with Caution: Requires Table or Index scans
--*************************************************************************

-- Suppress data loading messages
SET NOCOUNT ON

DECLARE @Employees table
   (  RowID     int  IDENTITY,
      PersonID  int,
      LastName  varchar(20),
      FirstName varchar(15)
   )

INSERT INTO @Employees VALUES ( 6349, 'Smith', 'Bill' )
INSERT INTO @Employees VALUES ( 6345, 'Jones', 'Jane' )
INSERT INTO @Employees VALUES ( 6301, 'Williams', 'Robert' )

DECLARE @Requirements table
   (  RowID        int   IDENTITY,
      EventCodeID  int,
      EventCode    varchar(25)
   )

INSERT INTO @Requirements VALUES ( 13, 'Criminal History' )
INSERT INTO @Requirements VALUES ( 31, 'DL' )
INSERT INTO @Requirements VALUES ( 30, 'CDL' )
INSERT INTO @Requirements VALUES ( 75, 'Employer Referral' )
INSERT INTO @Requirements VALUES ( 74, 'Drivers License' )
INSERT INTO @Requirements VALUES ( 2, 'CDA' )
INSERT INTO @Requirements VALUES ( 4, 'Employee Suggestions' )

DECLARE @RequirementsSatisfied table
   (  RowID        int   IDENTITY,
      PersonID     int,
      EventCodeID  int
   )

INSERT INTO @RequirementsSatisfied VALUES ( 6349, 13 )
INSERT INTO @RequirementsSatisfied VALUES ( 6349, 31 )
INSERT INTO @RequirementsSatisfied VALUES ( 6349, 30 )
INSERT INTO @RequirementsSatisfied VALUES ( 6349, 75 )
INSERT INTO @RequirementsSatisfied VALUES ( 6349, 74 )
INSERT INTO @RequirementsSatisfied VALUES ( 6345, 75 )
INSERT INTO @RequirementsSatisfied VALUES ( 6349, 4 )
INSERT INTO @RequirementsSatisfied VALUES ( 6345, 13 )

SELECT DISTINCT
   e.PersonID,
   e.LastName,
   e.FirstName,
   r.EventCodeID,
   r.EventCode
FROM @Employees e
   CROSS JOIN @Requirements r
   LEFT JOIN @RequirementsSatisfied rs
      ON (   rs.PersonID    = e.PersonID
         AND rs.EventCodeID = r.EventCodeID
         )
WHERE rs.PersonID IS NULL
ORDER BY
   e.PersonID,
   r.EventCodeID

/*
PersonID LastName FirstName EventCodeID EventCode
6301     Williams Robert    2           CDA
6301     Williams Robert    4           Employee Suggestions
6301     Williams Robert    13          Criminal History
6301     Williams Robert    30          CDL
6301     Williams Robert    31          DL
6301     Williams Robert    74          Drivers License
6301     Williams Robert    75          Employer Referral
6345     Jones    Jane      2           CDA
6345     Jones    Jane      4           Employee Suggestions
6345     Jones    Jane      30          CDL
6345     Jones    Jane      31          DL
6345     Jones    Jane      74          Drivers License
6349     Smith    Bill      2           CDA
*/


--*************************************************************************
-- Problem: Select the TOP n Rows For Each Group
-- 18
--*************************************************************************

-- Suppress data loading messages
SET NOCOUNT ON

-- Create Sample Data using a Table Varable
DECLARE @MyTable table
   (  RowID         int   IDENTITY,
      Category      varchar(5),
      [ID]          varchar(5),
      [Description] varchar(25),
      Price         decimal(10,2)
   )

-- Load Sample Data

INSERT INTO @MyTable VALUES ( 'Pot', 'A1', 'Small Saucepan', 21.50 )
INSERT INTO @MyTable VALUES ( 'Pot', 'A2', '1 Qt Saucepan', 29.95 )
INSERT INTO @MyTable VALUES ( 'Pot', 'A3', '1.5 Qt Saucepan', 33.95 )
INSERT INTO @MyTable VALUES ( 'Pot', 'A4', 'Double Boiler', 39.50 )
INSERT INTO @MyTable VALUES ( 'Pot', 'A5', 'Stewpot', 49.50 )
INSERT INTO @MyTable VALUES ( 'Pot', 'A6', 'Pressure Cooker', 79.95 )
INSERT INTO @MyTable VALUES ( 'Pan', 'B1', '8"" Pie', 6.95 )
INSERT INTO @MyTable VALUES ( 'Pan', 'B2', '8"" Sq Cake', 7.50 )
INSERT INTO @MyTable VALUES ( 'Pan', 'B3', 'Bundt Cake', 12.50 )
INSERT INTO @MyTable VALUES ( 'Pan', 'B4', '9x12 Brownie', 7.95 )
INSERT INTO @MyTable VALUES ( 'Bowl', 'C1', 'Lg Mixing', 27.50 )
INSERT INTO @MyTable VALUES ( 'Bowl', 'C2', 'Sm Mixing', 17.50 )
INSERT INTO @MyTable VALUES ( 'Tools', 'T1', '14"" Spatula', 9.95 )

-- Method One
-- Query to Retrieve Desired Data
SELECT
   RowID,
   Category,
   [ID],
   [Description],
   Price
FROM (SELECT
         ROW_NUMBER() OVER ( PARTITION BY Category ORDER BY Price DESC ) AS 'RowNumber',
         RowID,
         Category,
         [ID],
         [Description],
         Price
      FROM @MyTable
      ) dt
WHERE RowNumber <= 2

/* Results  --point out that order is NOT guaranteed here, just a byproduct of particular plan (Show query plan).  SETS ARE NOT ORDERED!
RowID Category  ID Description     Price
11    Bowl      C1 Lg Mixing       27.50
12    Bowl      C2 Sm Mixing       17.50
9     Pan       B3 Bundt Cake      12.50
10    Pan       B4 9x12 Brownie    7.95
6     Pot       A6 Pressure Cooker 79.95
5     Pot       A5 Stewpot         49.50
13    Tools     T1 14" Spatula     9.95
*/

-- Method Two --what query plans will be picked for each query?
-- Use a Common Table Expression (CTE).  I presonally prefer derived table syntax - "old school" SQL guy
;WITH dt AS (
     SELECT
         ROW_NUMBER() OVER ( PARTITION BY Category ORDER BY Price DESC ) AS 'RowNumber',
         RowID,
         Category,
         [ID],
         [Description],
         Price
      FROM @MyTable
)
-- and select the data from the CTE
SELECT
   RowID,
   Category,
   [ID],
   [Description],
   Price
FROM dt
WHERE RowNumber <= 2

/* Results
RowID Category  ID Description     Price
11    Bowl      C1 Lg Mixing       27.50
12    Bowl      C2 Sm Mixing       17.50
9     Pan       B3 Bundt Cake      12.50
10    Pan       B4 9x12 Brownie    7.95
6     Pot       A6 Pressure Cooker 79.95
5     Pot       A5 Stewpot         49.50
13    Tools     T1 14" Spatula     9.95
*/

 --*************************************************************************
-- Problem: Find the First Available Timeslot for Scheduling
-- 20
--*************************************************************************

-- Suppress data loading messages
SET NOCOUNT ON;

DECLARE @Schedule table
   (  AppID      int   IDENTITY,
      AppTeam    varchar(20),
      AppStart   datetime,
      AppFinish  datetime
   );

INSERT INTO @Schedule VALUES ( 'Start', NULL, '01/11/2007 09:00' );
INSERT INTO @Schedule VALUES ( 'Smith', '01/11/2007 09:00', '01/11/2007 09:30' );
INSERT INTO @Schedule VALUES ( 'Smith', '01/11/2007 10:00', '01/11/2007 10:15' );
INSERT INTO @Schedule VALUES ( 'Jones', '01/11/2007 11:00', '01/11/2007 12:00' );
INSERT INTO @Schedule VALUES ( 'Williams', '01/11/2007 12:00', '01/11/2007 14:45' );
INSERT INTO @Schedule VALUES ( 'Hsiao', '01/11/2007 15:30', '01/11/2007 16:00' );
INSERT INTO @Schedule VALUES ( 'Lopez', '01/11/2007 16:00', '01/11/2007 17:30' );
INSERT INTO @Schedule VALUES ( 'Green', '01/11/2007 17:30', '01/11/2007 18:30' );
INSERT INTO @Schedule VALUES ( 'Alphonso', '01/11/2007 20:00', '01/11/2007 20:30' );
INSERT INTO @Schedule VALUES ( 'End', '01/11/2007 21:00', NULL );

-- Determine the Length of Time Required
DECLARE @ApptNeed int;
SET @ApptNeed = 45;
--SET @ApptNeed = 60; --comment out Lopez and run this one

--Find FIRST Available Time Slot
;WITH CTE
AS (  SELECT
         *,
         RowNumber = ROW_NUMBER() OVER( ORDER BY AppStart ASC )
      FROM @Schedule
   )
   SELECT FirstApptAvail = min( a.AppFinish )
   FROM CTE a
      INNER JOIN CTE b  --be SURE you cover endpoints on self-joins like this!!
         ON a.RowNumber = b.RowNumber - 1
   WHERE datediff( minute, a.AppFinish, b.AppStart) >= @ApptNeed;

/*
FirstApptAvail
2007-01-11 10:15:00.000
*/

--Find All Available Time Slots
;WITH CTE
AS (  SELECT
         *,
         RowNumber = ROW_NUMBER() OVER( ORDER BY AppStart ASC )
      FROM @Schedule
   )
   SELECT TOP 3 ApptOptions = a.AppFinish
   FROM CTE a
      INNER JOIN CTE b
         ON a.RowNumber = b.RowNumber - 1
   WHERE datediff( minute, a.AppFinish, b.AppStart) >= @ApptNeed;

/*
ApptOptions
2007-01-11 10:15:00.000
2007-01-11 14:45:00.000
2007-01-11 18:30:00.000
*/


 --*************************************************************************
-- Problem: Use Collation to Help Find 'Bad' Data
-- 21
--*************************************************************************

-- Suppress data loading messages
SET NOCOUNT ON;

DECLARE @MyTable table
   (  MyColumn VARCHAR(10) );

INSERT INTO @MyTable VALUES('Ca3se');
INSERT INTO @MyTable VALUES('caSE');
INSERT INTO @MyTable VALUES('ca3se');
INSERT INTO @MyTable VALUES('5case');
INSERT INTO @MyTable VALUES(' ');
INSERT INTO @MyTable VALUES('casE');
INSERT INTO @MyTable VALUES('ca3e');
INSERT INTO @MyTable VALUES('cAse');
INSERT INTO @MyTable VALUES('case');
INSERT INTO @MyTable VALUES('ca se');

SELECT mycolumn
FROM @MyTable
WHERE (  mycolumn COLLATE Latin1_General_CS_AS <> lower( mycolumn )
      OR patindex( '%[^a-z]%', mycolumn  ) <> 0
      );

/*
mycolumn
Ca3se
caSE
ca3se
5case

casE
ca3e
cAse
ca se
*/

 --*************************************************************************
-- Problem: How to Pass and Handle a Delimited String similar to handling
-- 22       an Array() of Values
--*************************************************************************

Reference http://www.sommarskog.se/arrays-in-sql.htm


--Use tempdb;
--GO
--
----Creates an 'InLine' Table Valued Function (TVF)
----NOTE: there are MANY ways to do this.  SQLServerCentral.com has a great thread on this too!
--CREATE FUNCTION dbo.Split
--   (  @Delimiter varchar(5),
--      @List      varchar(8000)
--   )
--   RETURNS @TableOfValues table
--      (  RowID   smallint IDENTITY(1,1),
--         [Value] varchar(50)
--      )
--AS
--   BEGIN
--
--      DECLARE @LenString int
--
--      WHILE len( @List ) > 0
--         BEGIN
--
--            SELECT @LenString =
--               (CASE charindex( @Delimiter, @List )
--                   WHEN 0 THEN len( @List )
--                   ELSE ( charindex( @Delimiter, @List ) -1 )
--                END
--               )
--
--            INSERT INTO @TableOfValues
--               SELECT substring( @List, 1, @LenString )
--
--            SELECT @List =
--               (CASE ( len( @List ) - @LenString )
--                   WHEN 0 THEN ''
--                   ELSE right( @List, len( @List ) - @LenString - 1 )
--                END
--               )
--         END
--
--      RETURN
--
--   END;
--GO
--
---- Suppress data loading messages
--SET NOCOUNT ON;
--
---- Create Table for  Sample Data
--CREATE TABLE #MyTable
--   (  RowID    int  IDENTITY,
--      LastName varchar(20),
--      FirstName varchar(20)
--    );
--
---- Load Sample Data
--INSERT INTO #MyTable VALUES ( 'Davolio', 'Nancy' );
--INSERT INTO #MyTable VALUES ( 'Fuller', 'Andrew' );
--INSERT INTO #MyTable VALUES ( 'Leverling', 'Janet' );
--INSERT INTO #MyTable VALUES ( 'Peacock', 'Margaret' );
--INSERT INTO #MyTable VALUES ( 'Buchanan', 'Steven' );
--INSERT INTO #MyTable VALUES ( 'Suyama', 'Michael' );
--INSERT INTO #MyTable VALUES ( 'King', 'Robert' );
--INSERT INTO #MyTable VALUES ( 'Callahan', 'Laura' );
--INSERT INTO #MyTable VALUES ( 'Dodsworth', 'Anne' );
--
----Usage Examples
--SELECT *
--FROM dbo.Split( ',', '11,23,3,14' ) AS s
--ORDER BY cast( s.[Value] AS int );
--
--/*
--RowID Value
--3     3
--1     11
--4     14
--2     23
--*/
--
--SELECT *
--FROM dbo.Split( '|', 'Bob|Jane|Mary|Li|Hsiao|Lubor' ) AS s
--ORDER BY s.[Value];
--
--/*
--RowID Value
--1     Bob
--5     Hsiao
--2     Jane
--4     Li
--6     Lubor
--3     Mary
--*/
--
--DECLARE @MyList varchar(50);
--SET @MyList = ( '2,4,7,8' );
--
--SELECT
--   m.RowID,
--   m.LastName,
--   m.FirstName
--FROM #MyTable AS m
--   JOIN dbo.Split( ',', @MyList ) AS l
--      ON m.RowID = cast( l.[Value] AS int )
--ORDER BY
--   m.LastName,
--   m.FirstName;
--
--/*
--RowID LastName FirstName
--8     Callahan Laura
--2     Fuller   Andrew
--7     King     Robert
--4     Peacock  Margaret
--*/
--
--/* Clean UP
--DROP TABLE #MyTable
--DROP FUNCTION dbo.Split
--*/


 --*************************************************************************
-- Problem: Return XML data as Tabular Data
-- 23
--*************************************************************************

-- Suppress data loading messages
SET NOCOUNT ON

USE AdventureWorks;
GO

DECLARE @XMLDepartments XML;

SET @XMLDepartments =
   '<Departments>
      <Department Name="Accounting">
         <GroupName>Executive General and Administration</GroupName>
      </Department>
      <Department Name="International Sales">
         <GroupName>Sales and Marketing</GroupName>
      </Department>
      <Department Name="Software Development">
         <GroupName>Research and Development</GroupName>
      </Department>
   </Departments>';

SELECT Doc.Dep.value('@Name', 'NVARCHAR(50)') AS DeparmentName,
       Doc.Dep.value('GroupName[1]','NVARCHAR(50)') AS GroupName
FROM @XMLDepartments.nodes('//Departments/Department') AS Doc(Dep);


 --*************************************************************************
-- Problem: Grouping Ranges, from Plamen Ratchev
--          also see gaps and islands topic in Itzik Ben-Gans book
--*************************************************************************


CREATE TABLE #Events(
  event_date DATETIME NOT NULL PRIMARY KEY,
  event_venue VARCHAR(20) NOT NULL);

-- Insert venue event dates
INSERT #Events VALUES ('20080101', 'The Palace');
INSERT #Events VALUES ('20080201', 'The Palace');
INSERT #Events VALUES ('20080301', 'The Palace');
INSERT #Events VALUES ('20080401', 'The Palace');
INSERT #Events VALUES ('20080501', 'The Palace');
INSERT #Events VALUES ('20080601', 'Fox Theater');
INSERT #Events VALUES ('20080701', 'Fox Theater');
INSERT #Events VALUES ('20080801', 'Grand Hall');
INSERT #Events VALUES ('20080901', 'Grand Hall');
INSERT #Events VALUES ('20081001', 'Grand Hall');
INSERT #Events VALUES ('20081101', 'The Palace');
INSERT #Events VALUES ('20071201', 'The River Place');
INSERT #Events VALUES ('20081202', 'The River Place');

-- Group the event period dates at each venue
SELECT MIN(event_venue) AS venue,
       MIN(event_date) AS venue_start_date,
       MAX(event_date) AS venue_end_date
FROM (SELECT event_venue,
             event_date,
             ROW_NUMBER() OVER (ORDER BY event_venue, event_date) -
             ROW_NUMBER() OVER (PARTITION BY event_venue
                                ORDER BY event_date),
             ROW_NUMBER() OVER (ORDER BY event_date) -
             ROW_NUMBER() OVER (PARTITION BY event_venue
                                ORDER BY event_date)
      FROM #Events) AS X(event_venue, event_date, grp1, grp2)
GROUP BY grp1, grp2

drop table #Events



/* BAD QUERY OPTIMIZATION FOR DISTINCT AGGREGATES 
   This one isn't too bad - pair of table scans instead of a single scan.
   You can get some REALLY bad plans involving Spool operators!
*/

USE AdventureWorks
go
--show actual query plan
SET STATISTICS IO ON
GO
select TransactionType,
       COUNT(DISTINCT ProductID),
       SUM(ActualCost)
 from  Production.TransactionHistory
group by TransactionType

/*
2.99
Table 'Worktable'. Scan count 0, logical reads 0, physical reads 0, read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.
Table 'TransactionHistory'. Scan count 2, logical reads 1584, physical reads 0, read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.
*/

select TransactionType,
       COUNT(ProductID),
       SUM(ac)
 from  (SELECT TransactionType, ProductID, SUM(ActualCost) as ac
          FROM Production.TransactionHistory
         GROUP BY TransactionType, ProductID) as t
group by TransactionType

/*
1.54 query cost
Table 'Worktable'. Scan count 0, logical reads 0, physical reads 0, read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.
Table 'TransactionHistory'. Scan count 1, logical reads 792, physical reads 0, read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.
*/

