USE MergeDemo;
go

IF OBJECT_ID(N'dbo.Table1') IS NOT NULL
  BEGIN;
  DROP TABLE dbo.Table1;
  END;

IF OBJECT_ID(N'dbo.Table2') IS NOT NULL
  BEGIN;
  DROP TABLE dbo.Table2;
  END;
go

CREATE TABLE dbo.Table1
  (KeyCol int NOT NULL PRIMARY KEY,
   DataCol1 int NOT NULL,
   DataCol2 int NOT NULL,
   DataCol3 int NOT NULL);

CREATE TABLE dbo.Table2
  (KeyCol int NOT NULL,
   DataCol1 int NOT NULL,
   DataCol2 int NOT NULL,
   DataCol3 int NOT NULL);
go

INSERT INTO dbo.Table1
      (KeyCol, DataCol1, DataCol2, DataCol3)
SELECT 1,      1,        1,        1 UNION ALL
SELECT 2,      2,        2,        2 UNION ALL
SELECT 3,      3,        3,        3 UNION ALL
SELECT 4,      4,        4,        4;

-- "Good" data
INSERT INTO dbo.Table2
      (KeyCol, DataCol1, DataCol2, DataCol3)
SELECT 1,      11,       11,       11 UNION ALL
SELECT 2,      12,       12,       12 UNION ALL
SELECT 3,      13,       13,       13 UNION ALL   -- Note the "incorrect" (?) KeyCol value!
SELECT 4,      14,       14,       14;

/*
-- "Bad" data
INSERT INTO dbo.Table2
      (KeyCol, DataCol1, DataCol2, DataCol3)
SELECT 1,      11,       11,       11 UNION ALL
SELECT 2,      12,       12,       12 UNION ALL
SELECT 2,      13,       13,       13 UNION ALL   -- Note the "incorrect" (?) KeyCol value!
SELECT 4,      14,       14,       14;
*/
go

-- UPDATE FROM: will succeed (with "random" result) on "bad" data
UPDATE     dbo.Table1
SET        DataCol1 = b.DataCol1,
           DataCol2 = b.DataCol2,
           DataCol3 = b.DataCol3
FROM       dbo.Table1 AS a
INNER JOIN dbo.Table2 AS b
      ON   b.KeyCol = a.KeyCol;

SELECT * FROM Table1;
go

-- ANSI-compliant UPDATE: will result in an error on "bad" data
--   ... but what a terrible query and a terrible execution plan!
UPDATE     dbo.Table1
SET        DataCol1 = (SELECT b.DataCol1
                       FROM   dbo.Table2 AS b
                       WHERE  b.KeyCol = Table1.KeyCol),
           DataCol2 = (SELECT b.DataCol2
                       FROM   dbo.Table2 AS b
                       WHERE  b.KeyCol = Table1.KeyCol),
           DataCol3 = (SELECT b.DataCol3
                       FROM   dbo.Table2 AS b
                       WHERE  b.KeyCol = Table1.KeyCol)
WHERE EXISTS          (SELECT *
                       FROM   dbo.Table2 AS b
                       WHERE  b.KeyCol = Table1.KeyCol)
SELECT * FROM Table1;
go

-- MERGE: Will result in an error on "bad" data
MERGE
INTO   dbo.Table1 AS a
USING  dbo.Table2 AS b
   ON  b.KeyCol = a.KeyCol
  WHEN MATCHED
  THEN UPDATE
       SET     DataCol1 = b.DataCol1,
               DataCol2 = b.DataCol2,
               DataCol3 = b.DataCol3;

SELECT * FROM Table1;
go
