USE MergeDemo;
go

IF OBJECT_ID(N'dbo.Products') IS NOT NULL
  BEGIN;
  DROP TABLE dbo.Products;
  END;

IF OBJECT_ID(N'dbo.StagingProducts') IS NOT NULL
  BEGIN;
  DROP TABLE dbo.StagingProducts;
  END;
go

CREATE TABLE dbo.Products
  (ProductID int NOT NULL PRIMARY KEY,
   ProductName varchar(40) NOT NULL UNIQUE,
   Price decimal(9,2) NOT NULL,
   TotalSold int NOT NULL);

CREATE TABLE dbo.StagingProducts
  (ProductID int NOT NULL PRIMARY KEY,
   NewProductName varchar(40) NULL,     -- NULL means no change
   Price decimal(9,2) NOT NULL);
go

INSERT INTO dbo.Products
      (ProductID, ProductName, Price, TotalSold)
SELECT 1,        'First' ,     10.00,        17 UNION ALL
SELECT 2,        'Second',     10.00,         8 UNION ALL
SELECT 3,        'Third' ,     10.00,       953 UNION ALL
SELECT 4,        'Fourth',     10.00,        88;

INSERT INTO dbo.StagingProducts
      (ProductID, NewProductName, Price)
SELECT 1,         NULL,           12.99 UNION ALL
SELECT 3,        'NewThird',      10.00 UNION ALL
SELECT 4,         NULL,           10.00 UNION ALL
SELECT 5,        'NewProduct',     7.95;
go

SELECT * FROM dbo.Products;
SELECT * FROM dbo.StagingProducts;
go
