USE MergeDemo;
BEGIN TRANSACTION;
SELECT * FROM dbo.Products;
go

MERGE
INTO   dbo.Products AS p
USING  dbo.StagingProducts AS sp
   ON  sp.ProductID = p.ProductID
  WHEN MATCHED AND sp.Discontinued = 'Y'
  THEN DELETE
  WHEN MATCHED
  THEN UPDATE
       SET     Price = COALESCE(sp.NewPrice, p.Price),
               ProductName = COALESCE(sp.NewProductName, p.ProductName)
  WHEN NOT MATCHED BY TARGET
  THEN INSERT (ProductID,    ProductName,       Price,       TotalSold)
       VALUES (sp.ProductID, sp.NewProductName, sp.NewPrice, 0);
go

-- Show results, then roll back
SELECT * FROM dbo.Products;
ROLLBACK TRANSACTION;
go
