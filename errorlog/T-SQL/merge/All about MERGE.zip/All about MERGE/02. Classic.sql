USE MergeDemo;
BEGIN TRANSACTION;
SELECT * FROM dbo.Products;
go

-- Insert, update, delete - but not in that order.
-- First, delete rows that are not in staging
DELETE FROM dbo.Products
WHERE NOT EXISTS
 (SELECT *
  FROM   dbo.StagingProducts AS sp
  WHERE  sp.ProductID = Products.ProductID);

-- Next, update existing rows with modified data
-- CAUTION: UPDATE ... FROM is a dangerous statement!
UPDATE dbo.Products
SET    ProductName = COALESCE(sp.NewProductName, Products.ProductName),
       Price = sp.Price
FROM   dbo.StagingProducts AS sp
WHERE  sp.ProductID = Products.ProductID
AND(   sp.NewProductName IS NOT NULL
    OR sp.Price <> Products.Price);

-- Finally, insert new rows
INSERT dbo.Products
      (ProductID,    ProductName,       Price,    TotalSold)
SELECT sp.ProductID, sp.NewProductName, sp.Price, 0
FROM   dbo.StagingProducts AS sp
WHERE NOT EXISTS
 (SELECT *
  FROM   dbo.Products AS p
  WHERE  p.ProductID = sp.ProductID);
go

-- Show results, then roll back
SELECT * FROM dbo.Products;
ROLLBACK TRANSACTION;
go
