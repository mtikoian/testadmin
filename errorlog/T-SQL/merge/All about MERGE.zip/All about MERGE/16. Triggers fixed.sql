USE MergeDemo;
go

ALTER TRIGGER i_Products
ON dbo.Products AFTER INSERT
AS
  IF @@ROWCOUNT = 0 RETURN;
  IF NOT EXISTS (SELECT * FROM inserted) RETURN;
  SET NOCOUNT ON;
  SELECT * FROM inserted;
go

ALTER TRIGGER u_Products
ON dbo.Products AFTER UPDATE
AS
  IF @@ROWCOUNT = 0 RETURN;
  IF NOT EXISTS (SELECT * FROM inserted) RETURN;
  SET NOCOUNT ON;
  SELECT * FROM deleted;
  SELECT * FROM inserted;
go

ALTER TRIGGER d_Products
ON dbo.Products AFTER DELETE
AS
  IF @@ROWCOUNT = 0 RETURN;
  IF NOT EXISTS (SELECT * FROM deleted) RETURN;
  SET NOCOUNT ON;
  SELECT * FROM deleted;
go
