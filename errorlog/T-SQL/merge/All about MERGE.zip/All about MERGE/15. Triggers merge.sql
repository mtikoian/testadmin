USE MergeDemo;
BEGIN TRANSACTION;
go

-- First run - we have deletes, updates, and inserts.

MERGE
INTO   dbo.Products AS p
USING  dbo.StagingProducts AS sp
   ON  sp.ProductID = p.ProductID
  WHEN MATCHED
   AND (sp.NewProductName IS NOT NULL OR sp.Price <> p.Price)
  THEN UPDATE
       SET     Price = sp.Price,
               ProductName = COALESCE(sp.NewProductName, p.ProductName)
  WHEN NOT MATCHED BY TARGET
  THEN INSERT (ProductID,    ProductName,       Price,    TotalSold)
       VALUES (sp.ProductID, sp.NewProductName, sp.Price, 0)
  WHEN NOT MATCHED BY SOURCE
  THEN DELETE;
go

-- Second run - we still have updates (just different ones),
--  but we have no inserts or deletes anymore.

MERGE
INTO   dbo.Products AS p
USING  dbo.StagingProducts AS sp
   ON  sp.ProductID = p.ProductID
  WHEN MATCHED
   AND (sp.NewProductName IS NOT NULL OR sp.Price <> p.Price)
  THEN UPDATE
       SET     Price = sp.Price,
               ProductName = COALESCE(sp.NewProductName, p.ProductName)
  WHEN NOT MATCHED BY TARGET
  THEN INSERT (ProductID,    ProductName,       Price,    TotalSold)
       VALUES (sp.ProductID, sp.NewProductName, sp.Price, 0)
  WHEN NOT MATCHED BY SOURCE
  THEN DELETE;
go

-- Roll back
ROLLBACK TRANSACTION;
go
