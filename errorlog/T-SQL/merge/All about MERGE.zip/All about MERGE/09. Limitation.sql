USE MergeDemo;
go

MERGE
INTO   dbo.Products AS p
USING  dbo.StagingProducts AS sp
   ON  sp.ProductID = p.ProductID
  WHEN MATCHED AND sp.Discontinued = 'Y'
  THEN DELETE
  WHEN MATCHED AND sp.NewPrice IS NOT NULL
  THEN UPDATE
       SET     Price = sp.NewPrice
  WHEN MATCHED AND sp.NewProductName IS NOT NULL
  THEN UPDATE
       SET     ProductName = sp.NewProductName
  WHEN NOT MATCHED BY TARGET
  THEN INSERT (ProductID,    ProductName,       Price,       TotalSold)
       VALUES (sp.ProductID, sp.NewProductName, sp.NewPrice, 0);
go
