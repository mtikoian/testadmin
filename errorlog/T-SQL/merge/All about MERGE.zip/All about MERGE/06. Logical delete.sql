USE MergeDemo;
BEGIN TRANSACTION;
SELECT * FROM dbo.Products;
go

MERGE
INTO   dbo.Products AS p
USING  dbo.StagingProducts AS sp
   ON  sp.ProductID = p.ProductID
  WHEN MATCHED
  THEN UPDATE
       SET     Price = sp.Price,
               ProductName = COALESCE(sp.NewProductName, p.ProductName)
  WHEN NOT MATCHED BY TARGET
  THEN INSERT (ProductID,    ProductName,       Price,    TotalSold)
       VALUES (sp.ProductID, sp.NewProductName, sp.Price, 0)
  WHEN NOT MATCHED BY SOURCE
  THEN UPDATE
       SET     Is_Deleted = 'Y';
go

-- Show results, then roll back
SELECT * FROM dbo.Products;
ROLLBACK TRANSACTION;
go
