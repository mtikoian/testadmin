USE master;
SET NOCOUNT ON;

-- Create test database
IF EXISTS (SELECT * FROM sys.databases WHERE name = 'MergeDemo')
	ALTER DATABASE MergeDemo SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
GO
IF EXISTS (SELECT * FROM sys.databases WHERE name = 'MergeDemo')
	DROP DATABASE MergeDemo;
GO
CREATE DATABASE MergeDemo;
GO
USE MergeDemo;
GO
IF OBJECT_ID('tempdb..#MergeData')     IS NOT NULL DROP TABLE #MergeData;
IF OBJECT_ID('tempdb..#OutputCapture') IS NOT NULL DROP TABLE #OutputCapture;
GO
CREATE SCHEMA demo;
GO

-- ==================================================================================================
-- Tables
-- ==================================================================================================
-- Create table to store marketing "data points"
CREATE TABLE demo.DataPoint (
    DataPointID     int                 NOT NULL    IDENTITY    PRIMARY KEY,
    ExternalGUID    uniqueidentifier    NOT NULL,
    DataPointValue  varchar(18)         NOT NULL,
    DemoID          tinyint             NOT NULL
);

-- ==================================================================================================
-- "Current" Data
-- ==================================================================================================
-- Insert DataPoint records
DECLARE @i  int     = 0;
WHILE @i < 10
BEGIN
    SET @i += 1;
    INSERT INTO demo.DataPoint (
        DataPointValue,
        ExternalGUID,
        DemoID
    )
    SELECT
        'DataPoint ' + CONVERT(varchar(11), @i),
        NEWID(),
        @i;     -- DemoID
END;

SELECT * FROM demo.DataPoint ORDER BY DataPointID;

-- ==================================================================================================
-- "Merge" Data
-- ==================================================================================================
-- Create the "merge" table
CREATE TABLE #MergeData (
    ExternalGUID    uniqueidentifier    NOT NULL,
    DataPointValue  varchar(18)         NOT NULL,
    DemoID          tinyint             NOT NULL
);

-- ==================================================================================================
-- Add 8 of 10 current records
-- ==================================================================================================
INSERT INTO #MergeData (
    ExternalGUID,
    DataPointValue,
    DemoID
)
SELECT
    ExternalGUID,
    DataPointValue,
    DemoID
FROM demo.DataPoint
WHERE DataPointID BETWEEN 2 AND 9;

SELECT * FROM #MergeData ORDER BY DemoID;

-- ==================================================================================================
-- Add a new record
-- ==================================================================================================
INSERT INTO #MergeData (
    ExternalGUID,
    DataPointValue,
    DemoID
)
SELECT
    'ADD00000-ADD0-ADD0-ADD0-ADD000000000',
    'DataPoint +++',
    MAX(DemoID) + 1
FROM demo.DataPoint;

SELECT * FROM #MergeData ORDER BY DemoID;

-- ==================================================================================================
-- Updates
-- ==================================================================================================
-- Update DataPointValue in records 4 and 5
UPDATE #MergeData
SET DataPointValue = REPLACE(DataPointValue, 'DataPoint', 'Updated__')
WHERE DemoID IN (4, 5);

SELECT * FROM #MergeData ORDER BY DemoID;

-- ==================================================================================================
-- MERGE
-- ==================================================================================================
SELECT * FROM demo.DataPoint ORDER BY DemoID;

MERGE demo.DataPoint AS t
USING #MergeData     AS s
ON t.ExternalGUID = s.ExternalGUID 
WHEN NOT MATCHED
    THEN INSERT (
        --DataPointID
        ExternalGUID,
        DataPointValue,
        DemoID
    )
    VALUES (
        s.ExternalGUID,
        s.DataPointValue,
        s.DemoID
    )
WHEN MATCHED
  AND t.DataPointValue <> s.DataPointValue
    THEN UPDATE
    SET t.DataPointValue = s.DataPointValue
WHEN NOT MATCHED BY SOURCE
    THEN DELETE;

SELECT * FROM demo.DataPoint ORDER BY DemoID;

---- ==================================================================================================
---- MERGE with captured OUTPUT
---- ==================================================================================================
--CREATE TABLE #OutputCapture (
--    ActionType          varchar(6)     NOT NULL,
--    d_DataPointID       int,                -- The old
--    d_ExternalGUID      uniqueidentifier,
--    d_DataPointValue    varchar(18),
--    d_DemoID            tinyint,
--    i_DataPointID       int,                -- The new
--    i_ExternalGUID      uniqueidentifier,
--    i_DataPointValue    varchar(18),
--    i_DemoID            tinyint
--);

--INSERT INTO #OutputCapture
--SELECT *
--FROM (
--    MERGE demo.DataPoint AS t
--    USING #MergeData    AS s
--    ON t.ExternalGUID = s.ExternalGUID 
--    WHEN NOT MATCHED
--        THEN INSERT (
--            --DataPointID
--            ExternalGUID,
--            DataPointValue,
--            DemoID
--        )
--        VALUES (
--            s.ExternalGUID,
--            s.DataPointValue,
--            s.DemoID
--        )
--    WHEN MATCHED
--      AND t.DataPointValue <> s.DataPointValue
--        THEN UPDATE
--        SET t.DataPointValue = s.DataPointValue
--    WHEN NOT MATCHED BY SOURCE
--        THEN DELETE
--    OUTPUT
--        $action,
--        DELETED.DataPointID,
--        DELETED.ExternalGUID,
--        DELETED.DataPointValue,
--        DELETED.DemoID,
--        INSERTED.DataPointID,
--        INSERTED.ExternalGUID,
--        INSERTED.DataPointValue,
--        INSERTED.DemoID
--) AS m (
--    ActionType,
--    d_DataPointID,
--    d_ExternalGUID,
--    d_DataPointValue,
--    d_DemoID,
--    i_DataPointID,
--    i_ExternalGUID,
--    i_DataPointValue,
--    i_DemoID
--);

--PRINT '@@ROWCOUNT: ' + CONVERT(varchar(10), @@ROWCOUNT);
--SELECT * FROM #OutputCapture WHERE ActionType = 'INSERT' ORDER BY i_DemoID;
--SELECT * FROM #OutputCapture WHERE ActionType = 'UPDATE' ORDER BY i_DemoID;
--SELECT * FROM #OutputCapture WHERE ActionType = 'DELETE' ORDER BY d_DemoID;
--SELECT * FROM demo.DataPoint ORDER BY DemoID;
