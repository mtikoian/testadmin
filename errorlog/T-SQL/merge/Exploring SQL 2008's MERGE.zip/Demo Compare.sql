USE master;
SET NOCOUNT ON;

-- Create test database
IF EXISTS (SELECT * FROM sys.databases WHERE name = 'MergeDemo')
	ALTER DATABASE MergeDemo SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
GO
IF EXISTS (SELECT * FROM sys.databases WHERE name = 'MergeDemo')
	DROP DATABASE MergeDemo;
GO
CREATE DATABASE MergeDemo;
GO
USE MergeDemo;
GO
IF OBJECT_ID('tempdb..#MergeData') IS NOT NULL DROP TABLE #MergeData;
GO
CREATE SCHEMA demo;
GO

-- Number generator utility function
CREATE FUNCTION dbo.fn_nums (
    @max AS INT
) RETURNS TABLE AS
RETURN
WITH
    C0 AS(SELECT 0 AS const UNION ALL SELECT 0),
    C1 AS(SELECT 0 AS const FROM C0 AS A, C0 AS B),
    C2 AS(SELECT 0 AS const FROM C1 AS A, C1 AS B),
    C3 AS(SELECT 0 AS const FROM C2 AS A, C2 AS B),
    C4 AS(SELECT 0 AS const FROM C3 AS A, C3 AS B),
    C5 AS(SELECT 0 AS const FROM C4 AS A, C4 AS B),
    C6 AS(SELECT 0 AS const FROM C5 AS A, C5 AS B)
SELECT TOP(@max) ROW_NUMBER()
   OVER(ORDER BY const) AS n
FROM C6;
GO

DECLARE @RecordsCtCurrentData   int = 1000;

-- ==================================================================================================
-- Tables
-- ==================================================================================================
-- Create table to store marketing "data points"
CREATE TABLE demo.DataPoint1 (
    DataPointID     int                 NOT NULL    IDENTITY    PRIMARY KEY,
    ExternalGUID    uniqueidentifier    NOT NULL,
    DataPointValue  varchar(18)         NOT NULL,
    DemoID          int                 NOT NULL
);

CREATE TABLE demo.DataPoint2 (
    DataPointID     int                 NOT NULL    IDENTITY    PRIMARY KEY,
    ExternalGUID    uniqueidentifier    NOT NULL,
    DataPointValue  varchar(18)         NOT NULL,
    DemoID          int                 NOT NULL
);

-- ==================================================================================================
-- "Current" Data
-- ==================================================================================================
-- Insert DataPoint records
DECLARE @GUID   uniqueidentifier
DECLARE @i      int                 = 0;
WHILE @i < @RecordsCtCurrentData
BEGIN
    SET @i += 1;
    SET @GUID = NEWID();

    -- DataPoint1
    INSERT INTO demo.DataPoint1 (
        DataPointValue,
        ExternalGUID,
        DemoID
    )
    SELECT
        'DataPoint ' + CONVERT(varchar(11), @i),
        @GUID,
        @i;     -- DemoID

    -- DataPoint2
    INSERT INTO demo.DataPoint2 (
        DataPointValue,
        ExternalGUID,
        DemoID
    )
    SELECT
        'DataPoint ' + CONVERT(varchar(11), @i),
        @GUID,
        @i;     -- DemoID
END;

CREATE INDEX IDX_DataPoint1_ExternalGUID ON demo.DataPoint1 (ExternalGUID);
CREATE INDEX IDX_DataPoint2_ExternalGUID ON demo.DataPoint2 (ExternalGUID);

--SELECT TOP (10) * FROM demo.DataPoint1 ORDER BY DemoID;
--SELECT TOP (10) * FROM demo.DataPoint1 ORDER BY DemoID;

RAISERROR ('Records added to DataPoint1 and DataPoint2: %d', 10, 1, @RecordsCtCurrentData) WITH NOWAIT;

-- ==================================================================================================
-- "Merge" Data
-- ==================================================================================================
-- Create the "merge" table
CREATE TABLE #MergeData (
    ExternalGUID    uniqueidentifier    NOT NULL    PRIMARY KEY,
    DataPointValue  varchar(18)         NOT NULL,
    DemoID          int                 NOT NULL
);
    
-- ==================================================================================================
-- Add n% of current records
-- ==================================================================================================
INSERT INTO #MergeData (
    ExternalGUID,
    DataPointValue,
    DemoID
)
SELECT
    ExternalGUID,
    DataPointValue,
    DemoID
FROM demo.DataPoint1
WHERE DataPointID BETWEEN 1 AND (0.95 * @RecordsCtCurrentData);

RAISERROR ('Current records added to #MergeData: %d', 10, 1, @@ROWCOUNT) WITH NOWAIT;

-- ==================================================================================================
-- Add new records (n%)
-- ==================================================================================================
INSERT INTO #MergeData (
    ExternalGUID,
    DataPointValue,
    DemoID
)
SELECT
    NEWID(),                    -- ExternalGUID
    'DataPoint +++',            -- DataPointValue
    @RecordsCtCurrentData + n   -- DemoID
FROM dbo.fn_nums(0.05 * @RecordsCtCurrentData);

RAISERROR ('New     records added to #MergeData: %d', 10, 1, @@ROWCOUNT) WITH NOWAIT;

-- ==================================================================================================
-- Updates (n%)
-- ==================================================================================================
-- Update DataPointValue in 10% of records
UPDATE #MergeData
SET DataPointValue = REPLACE(DataPointValue, 'DataPoint', 'Updated__')
WHERE DemoID BETWEEN 1 AND (0.1 * @RecordsCtCurrentData);

RAISERROR ('Records updated       in #MergeData: %d', 10, 1, @@ROWCOUNT) WITH NOWAIT;

--SELECT COUNT(*) AS [Ct: DataPoint1] FROM demo.DataPoint1 WITH (NOLOCK);
--SELECT COUNT(*) AS [Ct: DataPoint2] FROM demo.DataPoint2 WITH (NOLOCK);
--SELECT COUNT(*) AS [Ct: #MergeData] FROM demo.#MergeData WITH (NOLOCK);

-- ==================================================================================================
-- MERGE (full)
-- ==================================================================================================
MERGE demo.DataPoint1   AS t
USING #MergeData        AS s
ON t.ExternalGUID = s.ExternalGUID 
WHEN NOT MATCHED
    THEN INSERT (
        --DataPointID
        ExternalGUID,
        DataPointValue,
        DemoID
    )
    VALUES (
        s.ExternalGUID,
        s.DataPointValue,
        s.DemoID
    )
WHEN MATCHED
  AND t.DataPointValue <> s.DataPointValue
    THEN UPDATE
    SET t.DataPointValue = s.DataPointValue
WHEN NOT MATCHED BY SOURCE
    THEN DELETE;

RAISERROR ('MERGE  Count: %d', 10, 1, @@ROWCOUNT) WITH NOWAIT;

-- ==================================================================================================
-- Hand-MERGE (full)
-- ==================================================================================================
-- DELETE
DELETE t
FROM demo.DataPoint2        AS t
LEFT OUTER JOIN #MergeData  AS s
  ON t.ExternalGUID = s.ExternalGUID
WHERE s.ExternalGUID IS NULL;

RAISERROR ('DELETE Count: %d', 10, 1, @@ROWCOUNT) WITH NOWAIT;
--SELECT @i = COUNT(*) FROM demo.DataPoint2; PRINT 'Count after DELETE: ' + CONVERT(varchar(11), @i);

-- UPDATE
UPDATE t
SET t.DataPointValue = s.DataPointValue
FROM demo.DataPoint2    AS t
JOIN #MergeData         AS s
  ON t.ExternalGUID = s.ExternalGUID
WHERE t.DataPointValue <> s.DataPointValue;

RAISERROR ('UPDATE Count: %d', 10, 1, @@ROWCOUNT) WITH NOWAIT;
--SELECT @i = COUNT(*) FROM demo.DataPoint2; PRINT 'Count after UPDATE: ' + CONVERT(varchar(11), @i);

-- INSERT
INSERT INTO demo.DataPoint2 (
    --DataPointID
    ExternalGUID,
    DataPointValue,
    DemoID
)
SELECT
    s.ExternalGUID,
    s.DataPointValue,
    s.DemoID
FROM #MergeData                 AS s
LEFT OUTER JOIN demo.DataPoint2 AS t
  ON t.ExternalGUID = s.ExternalGUID
WHERE t.ExternalGUID IS NULL;

RAISERROR ('INSERT Count: %d', 10, 1, @@ROWCOUNT) WITH NOWAIT;
--SELECT @i = COUNT(*) FROM demo.DataPoint2; PRINT 'Count after INSERT: ' + CONVERT(varchar(11), @i);

------ ==================================================================================================
------ INSERT only
------ ==================================================================================================
---- MERGE
--MERGE demo.DataPoint1   AS t
--USING #MergeData        AS s
--ON t.ExternalGUID = s.ExternalGUID 
--WHEN NOT MATCHED
--    THEN INSERT (
--        --DataPointID
--        ExternalGUID,
--        DataPointValue,
--        DemoID
--    )
--    VALUES (
--        s.ExternalGUID,
--        s.DataPointValue,
--        s.DemoID
--    );

--RAISERROR ('MERGE  Count: %d', 10, 1, @@ROWCOUNT) WITH NOWAIT;

---- INSERT
--INSERT INTO demo.DataPoint2 (
--    --DataPointID
--    ExternalGUID,
--    DataPointValue,
--    DemoID
--)
--SELECT
--    ExternalGUID,
--    DataPointValue,
--    DemoID
--FROM #MergeData;

--RAISERROR ('INSERT Count: %d', 10, 1, @@ROWCOUNT) WITH NOWAIT;
