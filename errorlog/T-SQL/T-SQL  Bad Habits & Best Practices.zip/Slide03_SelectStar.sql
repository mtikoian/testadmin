USE AdventureWorks2012; -- this requires AdventureWorks2008, 2008R2 or 2012

-- drag columns node

-- show in Plan Explorer or turn Execution Plan on
-- note huge differences and also spatial results

SELECT *
FROM Person.[Address] 
WHERE AddressLine1 LIKE '1% Napa%';

SELECT AddressID, AddressLine1, AddressLine2, 
  City, StateProvinceID, PostalCode
FROM Person.[Address] 
WHERE AddressLine1 LIKE '1% Napa%';