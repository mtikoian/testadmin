CREATE LOGIN KZoo1 WITH PASSWORD = 'x', CHECK_POLICY = OFF;
CREATE USER KZoo1 FROM LOGIN KZoo1 WITH DEFAULT_SCHEMA = Sales;
GO
CREATE LOGIN KZoo2 WITH PASSWORD = 'x', CHECK_POLICY = OFF;
CREATE USER KZoo2 FROM LOGIN KZoo2 WITH DEFAULT_SCHEMA = Person;
GO
GRANT SELECT ON dbo.ErrorLog TO Kzoo1, KZoo2;
GO

DBCC FREEPROCCACHE;
GO

EXECUTE AS User = 'KZoo1';
GO
-- add dbo. prefix and run again:
SELECT ErrorTime, ErrorMessage FROM dbo.ErrorLog;
GO
REVERT;
GO
EXECUTE AS User = 'KZoo2';
GO
-- add dbo. prefix and run again:
SELECT ErrorTime, ErrorMessage FROM ErrorLog;
GO
REVERT;
GO


SELECT t.[text], p.size_in_bytes, p.usecounts, pa.value, [schema] = SCHEMA_NAME(CONVERT(INT, pa.[value]))
FROM sys.dm_exec_cached_plans AS p
CROSS APPLY sys.dm_exec_sql_text(p.plan_handle) AS t
CROSS APPLY sys.dm_exec_plan_attributes(p.plan_handle) AS pa
WHERE t.[text] LIKE N'%Error'+'Log%' AND pa.attribute = N'user_id';

GO
DROP USER KZoo1;
DROP USER KZoo2;
DROP LOGIN KZoo1;
DROP LOGIN KZoo2;
