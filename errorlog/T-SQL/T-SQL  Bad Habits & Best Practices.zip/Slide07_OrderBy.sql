CREATE TABLE dbo.what(ID INT PRIMARY KEY, name VARCHAR(32));

INSERT dbo.what(ID,name) VALUES(1,'sam'),(2,'frank'),(3,'bob');

SELECT name FROM dbo.what;

CREATE INDEX x ON dbo.what(name);

SELECT name FROM dbo.what;

DROP TABLE dbo.what;