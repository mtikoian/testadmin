USE AdventureWorks2012;
GO

-- what happens when you use unsargeable search criteria?

-- check these in Plan Explorer:

SELECT COUNT(*) FROM Sales.SalesOrderHeader 
WHERE YEAR(OrderDate) = 2005 
AND MONTH(OrderDate) = 7;

SELECT COUNT(*) FROM Sales.SalesOrderHeader 
WHERE OrderDate >= '20050701'
  AND OrderDate < '20050801';

-- ALWAYS use an open-ended range

-- what happens when you try to find the "end" of a period?

DECLARE @start DATETIME, @end DATETIME;

SELECT 
  @start = DATEADD(DAY, DATEDIFF(DAY, 1, CURRENT_TIMESTAMP), 0),
  @end   = DATEADD(MILLISECOND, -3, DATEADD(DAY, 1, @start));

SELECT @start, [Datetime] = @end;

SELECT @start, [Smalldatetime] = CONVERT(SMALLDATETIME, @end);

SELECT @start, [Date] = CONVERT(DATE, @end);

SELECT @start, [Datetime2] = CONVERT(DATETIME2(7), @end);


-- Always use open-ended range.
-- Instead of:

SELECT ... WHERE col BETWEEN @start AND @end;

-- Use:

SELECT ... WHERE col >= @start AND col < DATEADD(DAY, 1, @end);


GO
-- NEVER use shorthand
-- POP QUIZ: what will this yield?

DECLARE @d DATE = '20121225';

SELECT DATEPART(w, @d);

/*
  (a) 51
  (b) 3
  (c) 52
*/ 

GO

DECLARE @d DATE = '20121225';

SELECT DATEPART(y, @d);

/*
  (a) 12
  (b) 2012
  (c) 360
*/

GO
DECLARE @dt DATETIME = GETDATE();
SELECT @dt + 1;
GO
DECLARE @d DATE = GETDATE();
SELECT @d + 1;


SET LANGUAGE FRENCH;
SET LANGUAGE ENGLISH;
SET LANGUAGE BRITISH;
SET DATEFORMAT YDM;
SET DATEFORMAT MDY;

-- unsafe:

SELECT CONVERT(DATETIME, '2012-09-08');
SELECT CONVERT(DATETIME, '09/08/2012');
SELECT CONVERT(DATETIME, '2012-09-08 12:34:56.789');

-- safe:

SELECT CONVERT(DATETIME, '20120908');
SELECT CONVERT(DATETIME, '2012-09-08T12:34:56.789');

-- always safe but only for DATE data type:

SELECT CONVERT(DATE, '2012-09-08');
SELECT CONVERT(DATE, '20120908');

