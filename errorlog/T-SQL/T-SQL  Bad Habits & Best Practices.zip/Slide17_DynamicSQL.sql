-- with EXEC, you need to build a string,
-- and it is prone to SQL injection,
-- especially if you make it "easy" by
-- changing all parameters to strings:


DECLARE @sql NVARCHAR(MAX) = N'',
  @name NVARCHAR(32) = N'Bob',
  @CustomerID VARCHAR(32) = '1;DROP TABLE dbo.x;';

SET @sql = 'SELECT * FROM wherever WHERE 
  name = ''' + REPLACE(@name, '''', '''''') + '''
  AND CustomerID = ' + @CustomerID + ';';

PRINT @sql;
--EXEC(@sql);
GO

-- with sp_executesql, you can use proper parameters
-- and no (or at least less) string concatenation:

DECLARE @sql NVARCHAR(MAX) = N'',
  @name NVARCHAR(32) = N'Bob',
  @CustomerID INT = 5;

SET @sql = 'SELECT * FROM wherever WHERE 
  name = @name AND CustomerID = @CustomerID;';

EXEC sp_executesql 
    @sql, 
    N'@name NVARCHAR(32), @CustomerID INT;',
	@name, @CustomerID;
GO

-- POP QUIZ: will this work?

DECLARE @sql NVARCHAR(MAX) = N'SELECT 1;';

EXEC @sql;
GO

-- how about this?

EXEC('SELECT ' + DB_ID());