-- POP QUIZ : will these yield the same result?

DECLARE @x VARCHAR = 'xyz';

  SELECT 
    [variable] = @x,
    [cast]     = CAST('xyz' AS VARCHAR),
    [convert]  = CONVERT(VARCHAR, 'xyz');
