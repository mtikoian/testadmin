﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Threading;

namespace ProblematicApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            SqlConnection Connection = new SqlConnection(Properties.Settings.Default.ConnectionString);
            Connection.Open();

            SqlCommand Command = new SqlCommand();
            Command.Connection = Connection;

            Command.CommandType = CommandType.Text;
            Command.CommandText = "DBCC FREEPROCCACHE;";
            Command.ExecuteNonQuery();
                        
            Command.CommandType = CommandType.StoredProcedure;
            Command.CommandText = "Operation.usp_GetInvitationsByStatus";
            Command.Parameters.Add("@inStatusId", SqlDbType.TinyInt);

            SqlDataReader DataReader;

            Random RandomNumber = new Random();

            Command.Parameters["@inStatusId"].Value = 4;
            DataReader = Command.ExecuteReader();
            DataReader.Close();

            while (true)
            {
                Thread.Sleep(1000);
                Command.Parameters["@inStatusId"].Value = RandomNumber.Next() % 3 + 1;
                DataReader = Command.ExecuteReader();
                DataReader.Close();
            }
        }
    }
}
