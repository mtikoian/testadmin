USE
	SQLSaturday360;
GO


SET STATISTICS IO ON;
GO


-- Check the partition count in this query

SELECT
	Id ,
	URL ,
	ReferenceCode ,
	SessionId ,
	DateAndTime
FROM
	Web.PageViews
WHERE
	DateAndTime >= '2015-01-01'
AND
	DateAndTime < '2015-01-02';
GO


-- Now check again...

SELECT
	Id ,
	URL ,
	ReferenceCode ,
	SessionId ,
	DateAndTime
FROM
	Web.PageViews
WHERE
	DateAndTime >= CAST ('2015-01-01' AS DATETIME2(0))
AND
	DateAndTime < CAST ('2015-01-02' AS DATETIME2(0));
GO
