-- Create the "C:\SQLSaturday360" folder to hold the database files

USE
	master;
GO


EXECUTE sys.sp_configure
	@configname		= 'show advanced options' ,
	@configvalue	= 1;
GO


RECONFIGURE;
GO


EXECUTE sys.sp_configure
	@configname		= 'xp_cmdshell' ,
	@configvalue	= 1;
GO


RECONFIGURE;
GO


EXECUTE sys.xp_cmdshell
	N'md C:\SQLSaturday360' ,
	no_output;
GO


EXECUTE sys.sp_configure
	@configname		= 'xp_cmdshell' ,
	@configvalue	= 0;
GO


RECONFIGURE;
GO


EXECUTE sys.sp_configure
	@configname		= 'show advanced options' ,
	@configvalue	= 0;
GO


RECONFIGURE;
GO


-- Create the "SQLSaturday360" database

IF
	DB_ID (N'SQLSaturday360') IS NOT NULL
BEGIN

	ALTER DATABASE
		SQLSaturday360
	SET
		SINGLE_USER
	WITH
		ROLLBACK IMMEDIATE;

	DROP DATABASE
		SQLSaturday360;

END;
GO


CREATE DATABASE
	SQLSaturday360
ON PRIMARY
(
	NAME		= N'SQLSaturday360_Data' ,
	FILENAME	= N'C:\SQLSaturday360\SQLSaturday360_Data.mdf' ,
	SIZE		= 1GB ,
	FILEGROWTH	= 10%
)
LOG ON
(
	NAME		= N'SQLSaturday360_Log' ,
	FILENAME	= N'C:\SQLSaturday360\SQLSaturday360_Log.ldf' ,
	SIZE		= 500MB ,
	FILEGROWTH	= 10%
);
GO


ALTER DATABASE
	SQLSaturday360
SET RECOVERY
	SIMPLE;
GO


USE
	SQLSaturday360;
GO


-- Create list tables

CREATE SCHEMA
	Lists;
GO


CREATE TABLE
	Lists.Countries
(
	Id		TINYINT			NOT NULL ,
	Name	NVARCHAR(50)	NOT NULL ,

	CONSTRAINT
		pk_Countries_c_Id
	PRIMARY KEY CLUSTERED
		(Id ASC)
	ON
		[PRIMARY]
)
ON
	[PRIMARY];
GO


CREATE TABLE
	Lists.Genders
(
	Id		TINYINT			NOT NULL ,
	Name	NVARCHAR(50)	NOT NULL

	CONSTRAINT
		pk_Genders_c_Id
	PRIMARY KEY CLUSTERED
		(Id ASC)
	ON
		[PRIMARY]
)
ON
	[PRIMARY];
GO


CREATE TABLE
	Lists.MaritalStatuses
(
	Id		TINYINT			NOT NULL ,
	Name	NVARCHAR(50)	NOT NULL

	CONSTRAINT
		pk_MaritalStatuses_c_Id
	PRIMARY KEY CLUSTERED
		(Id ASC)
	ON
		[PRIMARY]
)
ON
	[PRIMARY];
GO


CREATE TABLE
	Lists.SessionEndReasons
(
	Id		TINYINT			NOT NULL ,
	Name	NVARCHAR(50)	NOT NULL

	CONSTRAINT
		pk_SessionEndReasons_c_Id
	PRIMARY KEY CLUSTERED
		(Id ASC)
	ON
		[PRIMARY]
)
ON
	[PRIMARY];
GO


CREATE TABLE
	Lists.InvitationStatuses
(
	Id		TINYINT			NOT NULL ,
	Name	NVARCHAR(50)	NOT NULL

	CONSTRAINT
		pk_InvitationStatuses_c_Id
	PRIMARY KEY CLUSTERED
		(Id ASC)
	ON
		[PRIMARY]
)
ON
	[PRIMARY];
GO


CREATE TABLE
	Lists.EventTypes
(
	Id		TINYINT			NOT NULL ,
	Name	NVARCHAR(50)	NOT NULL ,

	CONSTRAINT
		pk_EventTypes_c_Id
	PRIMARY KEY CLUSTERED
		(Id ASC)
	ON
		[PRIMARY]
)
ON
	[PRIMARY];
GO


-- Poppulate the list tables with data

INSERT INTO
	Lists.Countries
(
	Id ,
	Name
)
SELECT
	Id		= 1 ,
	Name	= N'Israel'

UNION ALL

SELECT
	Id		= 2 ,
	Name	= N'USA'

UNION ALL

SELECT
	Id		= 3 ,
	Name	= N'England'

UNION ALL

SELECT
	Id		= 4 ,
	Name	= N'France'

UNION ALL

SELECT
	Id		= 5 ,
	Name	= N'Italy';
GO


INSERT INTO
	Lists.Genders
(
	Id ,
	Name
)
SELECT
	Id		= 1 ,
	Name	= N'Male'

UNION ALL

SELECT
	Id		= 2 ,
	Name	= N'Female';
GO


INSERT INTO
	Lists.MaritalStatuses
(
	Id ,
	Name
)
SELECT
	Id		= 1 ,
	Name	= N'Single'

UNION ALL

SELECT
	Id		= 2 ,
	Name	= N'Married'

UNION ALL

SELECT
	Id		= 3 ,
	Name	= N'Divorced'

UNION ALL

SELECT
	Id		= 4 ,
	Name	= N'Widowed';
GO


INSERT INTO
	Lists.SessionEndReasons
(
	Id ,
	Name
)
SELECT
	Id		= 1 ,
	Name	= N'Logout'

UNION ALL

SELECT
	Id		= 2 ,
	Name	= N'Disconnection'

UNION ALL

SELECT
	Id		= 3 ,
	Name	= N'Inactive'

UNION ALL

SELECT
	Id		= 4 ,
	Name	= N'Another Session Opened';
GO


INSERT INTO
	Lists.InvitationStatuses
(
	Id ,
	Name
)
SELECT
	Id		= 1 ,
	Name	= N'Sent'

UNION ALL

SELECT
	Id		= 2 ,
	Name	= N'Accepted'

UNION ALL

SELECT
	Id		= 3 ,
	Name	= N'Denied'

UNION ALL

SELECT
	Id		= 4 ,
	Name	= N'Cancelled';
GO


INSERT INTO
	Lists.EventTypes
(
	Id ,
	Name
)
SELECT
	Id		= 1 ,
	Name	= N'Click'

UNION ALL

SELECT
	Id		= 2 ,
	Name	= N'Mouse Move'

UNION ALL

SELECT
	Id		= 3 ,
	Name	= N'Refresh'

UNION ALL

SELECT
	Id		= 4 ,
	Name	= N'Open'

UNION ALL

SELECT
	Id		= 5 ,
	Name	= N'Close';
GO


-- Create operational tables

CREATE SCHEMA
	Operation;
GO


CREATE TABLE
	Operation.Members
(
	Id						INT				NOT NULL	IDENTITY (1,1) ,
	Username				NVARCHAR(10)	NOT NULL ,
	Password				NVARCHAR(10)	NOT NULL ,
	FirstName				NVARCHAR(20)	NOT NULL ,
	LastName				NVARCHAR(20)	NOT NULL ,
	StreetAddress			NVARCHAR(100)	NULL ,
	CountryId				TINYINT			NOT NULL ,
	PhoneNumber				NVARCHAR(20)	NULL ,
	EmailAddress			NVARCHAR(100)	NOT NULL ,
	GenderId				TINYINT			NOT NULL ,
	BirthDate				DATE			NOT NULL ,
	SexualPreferenceId		TINYINT			NULL ,
	MaritalStatusId			TINYINT			NULL ,
	Picture					VARBINARY(MAX)	NULL ,
	RegistrationDateTime	DATETIME2(0)	NOT NULL ,
	ReferringMemberId		INT				NULL ,

	CONSTRAINT
		pk_Members_c_Id
	PRIMARY KEY CLUSTERED
		(Id ASC)
	ON
		[PRIMARY] ,

	CONSTRAINT
		fk_Members_CountryId_Countries_Id
	FOREIGN KEY
		(CountryId)
	REFERENCES
		Lists.Countries (Id) ,

	CONSTRAINT
		fk_Members_GenderId_Genders_Id
	FOREIGN KEY
		(GenderId)
	REFERENCES
		Lists.Genders (Id) ,

	CONSTRAINT
		fk_Members_SexualPreferenceId_Genders_Id
	FOREIGN KEY
		(SexualPreferenceId)
	REFERENCES
		Lists.Genders (Id) ,

	CONSTRAINT
		fk_Members_MaritalStatusId_MaritalStatuses_Id
	FOREIGN KEY
		(MaritalStatusId)
	REFERENCES
		Lists.MaritalStatuses (Id) ,

	CONSTRAINT
		fk_Members_ReferringMemberId_Members_Id
	FOREIGN KEY
		(ReferringMemberId)
	REFERENCES
		Operation.Members (Id)
)
ON
	[PRIMARY];
GO


CREATE TABLE
	Operation.MemberSessions
(
	Id				INT				NOT NULL	IDENTITY (1,1) ,
	MemberId		INT				NOT NULL ,
	LoginDateTime	DATETIME2(0)	NOT NULL ,
	EndDateTime		DATETIME2(0)	NULL ,
	EndReasonId		TINYINT			NULL ,

	CONSTRAINT
		pk_MemberSessions_c_Id
	PRIMARY KEY CLUSTERED
		(Id ASC)
	ON
		[PRIMARY] ,

	CONSTRAINT
		fk_MemberSessions_MemberId_Members_Id
	FOREIGN KEY
		(MemberId)
	REFERENCES
		Operation.Members (Id) ,

	CONSTRAINT
		fk_MemberSessions_EndReasonId_SessionEndReasons_Id
	FOREIGN KEY
		(EndReasonId)
	REFERENCES
		Lists.SessionEndReasons (Id)
)
ON
	[PRIMARY];
GO


CREATE TABLE
	Operation.Invitations
(
	Id					INT				NOT NULL	IDENTITY(1,1) ,
	RequestingSessionId	INT				NOT NULL ,
	ReceivingMemberId	INT				NOT NULL ,
	CreationDateTime	DATETIME2(0)	NOT NULL ,
	StatusId			TINYINT			NOT NULL ,
	ResponseDateTime	DATETIME2(0)	NULL ,

	CONSTRAINT
		pk_Invitations_c_Id
	PRIMARY KEY CLUSTERED
		(Id ASC)
	ON
		[PRIMARY] ,

	CONSTRAINT
		fk_Invitations_RequestingSessionId_MemberSessions_Id
	FOREIGN KEY
		(RequestingSessionId)
	REFERENCES
		Operation.MemberSessions (Id) ,

	CONSTRAINT
		fk_Invitations_ReceivingMemberId_Members_Id
	FOREIGN KEY
		(ReceivingMemberId)
	REFERENCES
		Operation.Members (Id) ,

	CONSTRAINT
		fk_Invitations_StatusId_InvitationStatuses_Id
	FOREIGN KEY
		(StatusId)
	REFERENCES
		Lists.InvitationStatuses (Id)
)
ON
	[PRIMARY];
GO


-- Populate the operational tables with data

DECLARE
	@tblFirstNames
TABLE
(
	Name		NVARCHAR(20)	NOT NULL ,
	GenderId	TINYINT			NOT NULL
);

INSERT INTO
	@tblFirstNames
(
	Name ,
	GenderId
)
SELECT
	Name		= N'John' ,
	GenderId	= 1

UNION ALL

SELECT
	Name		= N'David' ,
	GenderId	= 1

UNION ALL

SELECT
	Name		= N'James' ,
	GenderId	= 1

UNION ALL

SELECT
	Name		= N'Ron' ,
	GenderId	= 1

UNION ALL

SELECT
	Name		= N'Bruce' ,
	GenderId	= 1

UNION ALL

SELECT
	Name		= N'Bryan' ,
	GenderId	= 1

UNION ALL

SELECT
	Name		= N'Gimmy' ,
	GenderId	= 1

UNION ALL

SELECT
	Name		= N'Rick' ,
	GenderId	= 1

UNION ALL

SELECT
	Name		= N'Paul' ,
	GenderId	= 1

UNION ALL

SELECT
	Name		= N'Phil' ,
	GenderId	= 1

UNION ALL

SELECT
	Name		= N'Laura' ,
	GenderId	= 2

UNION ALL

SELECT
	Name		= N'Jane' ,
	GenderId	= 2

UNION ALL

SELECT
	Name		= N'Sara' ,
	GenderId	= 2

UNION ALL

SELECT
	Name		= N'Lian' ,
	GenderId	= 2

UNION ALL

SELECT
	Name		= N'Rita' ,
	GenderId	= 2

UNION ALL

SELECT
	Name		= N'Samantha' ,
	GenderId	= 2

UNION ALL

SELECT
	Name		= N'Suzan' ,
	GenderId	= 2

UNION ALL

SELECT
	Name		= N'Marry' ,
	GenderId	= 2

UNION ALL

SELECT
	Name		= N'Monica' ,
	GenderId	= 2

UNION ALL

SELECT
	Name		= N'Julia' ,
	GenderId	= 2

UNION ALL

SELECT
	Name		= N'Shila' ,
	GenderId	= 2

UNION ALL

SELECT
	Name		= N'Angela' ,
	GenderId	= 2;

DECLARE
	@tblLastNames
TABLE
(
	Name NVARCHAR(20) NOT NULL
);

INSERT INTO @tblLastNames
(
	Name
)
SELECT
	Name = N'Jones'

UNION ALL

SELECT
	Name = N'McDonald'

UNION ALL

SELECT
	Name = N'Simon'

UNION ALL

SELECT
	Name = N'Petty'

UNION ALL

SELECT
	Name = N'Bond'

UNION ALL

SELECT
	Name = N'Simpson'

UNION ALL

SELECT
	Name = N'Polsky'

UNION ALL

SELECT
	Name = N'Mayers'

UNION ALL

SELECT
	Name = N'Taylor'

UNION ALL

SELECT
	Name = N'Austin'

UNION ALL

SELECT
	Name = N'Ramsfeld';

INSERT INTO
	Operation.Members WITH (TABLOCK)
(
	UserName ,
	Password ,
	FirstName ,
	LastName ,
	StreetAddress ,
	CountryId ,
	PhoneNumber ,
	EmailAddress ,
	GenderId ,
	BirthDate ,
	SexualPreferenceId ,
	MaritalStatusId ,
	Picture ,
	RegistrationDateTime ,
	ReferringMemberId
)
SELECT TOP (100000)
	UserName				= REPLICATE (N'X' , ABS (CHECKSUM (NEWID ())) % 10 + 1) ,
	Password				= CAST (ROW_NUMBER () OVER (ORDER BY (SELECT NULL) ASC) AS NVARCHAR(10)) ,
	FirstName				= FirstNames.Name ,
	LastName				= LastNames.Name ,
	StreetAddress			=	CASE
									WHEN ABS (CHECKSUM (NEWID ())) % 100 < 20
										THEN NULL
									ELSE
										REPLICATE (N'X' , ABS (CHECKSUM (NEWID ())) % 100 + 1)
								END ,
	CountryId				= ABS (CHECKSUM (NEWID ())) % 5 + 1 ,
	PhoneNumber				=	CASE
									WHEN ABS (CHECKSUM (NEWID ())) % 100 < 20
										THEN NULL
									ELSE
										CAST ((ABS (CHECKSUM (NEWID ())) % 1000000000 + 100000000) AS NVARCHAR(20))
								END ,
	EmailAddress			= REPLICATE (N'x' , ABS (CHECKSUM (NEWID ())) % 10 + 1) + N'@gmail.com' ,
	GenderId				= FirstNames.GenderId ,
	BirthDate				= CAST (DATEADD (DAY , DATEDIFF (DAY , '1900-01-01' , SYSDATETIME ()) - (19 * 365) - (ABS (CHECKSUM (NEWID ())) % (30 * 365)) , '1900-01-01') AS DATE) ,
	SexualPreferenceId		=	CASE RandomValueTable.RandomValue
									WHEN 1
										THEN 1
									WHEN 2
										THEN 2
									WHEN 3
										THEN NULL
								END ,	
	MaritalStatusId			=	CASE
									WHEN ABS (CHECKSUM (NEWID ())) % 100 < 20
										THEN NULL
									ELSE
										ABS (CHECKSUM (NEWID ())) % 4 + 1
								END ,
	Picture					=	CASE
									WHEN ABS (CHECKSUM (NEWID ())) % 100 < 30
										THEN NULL
									ELSE
										CAST (REPLICATE (N'Picture' , ABS (CHECKSUM (NEWID ())) % 1000 + 1) AS VARBINARY(MAX))
								END ,
	RegistrationDateTime	= SYSDATETIME () ,
	ReferringMemberId		= NULL
FROM
	sys.all_columns
CROSS JOIN
	@tblFirstNames AS FirstNames
CROSS JOIN
	@tblLastNames AS LastNames
CROSS JOIN
	(
		SELECT
			RandomValue = ABS (CHECKSUM (NEWID ())) % 3 + 1
	)
	AS
		RandomValueTable
ORDER BY
	NEWID () ASC;
GO


UPDATE
	Operation.Members
SET
	RegistrationDateTime	= DATEADD (SECOND , (19 * 365 * 24 * 60 * 60) + (ABS (CHECKSUM (NEWID ())) % DATEDIFF (SECOND , DATEADD (SECOND , 19 * 365 * 24 * 60 * 60 , CAST (BirthDate AS DATETIME2(0))) , SYSDATETIME ())) , CAST (BirthDate AS DATETIME2(0))) ,
	ReferringMemberId		=	CASE
									WHEN Id = 1
										THEN NULL
									WHEN ABS (CHECKSUM (NEWID ())) % 100 < 30
										THEN NULL
									ELSE
										ABS (CHECKSUM (NEWID ())) % (Id - 1) + 1
								END
GO


INSERT INTO
	Operation.MemberSessions WITH (TABLOCK)
(
	MemberId ,
	LoginDateTime ,
	EndDateTime ,
	EndReasonId
)
SELECT TOP (1000000)
	MemberId		= Members.Id ,
	LoginDateTime	= DATEADD (SECOND , ABS (CHECKSUM (NEWID ())) % DATEDIFF (SECOND , Members.RegistrationDateTime , SYSDATETIME ()) , Members.RegistrationDateTime) ,
	EndDateTime		= NULL ,
	EndReasonId		= NULL
FROM
	Operation.Members AS Members
CROSS JOIN
	sys.objects
ORDER BY
	NEWID () ASC;
GO


UPDATE
	Operation.MemberSessions
SET
	EndDateTime	= DATEADD (SECOND , ABS (CHECKSUM (NEWID ())) % (5 * 60 * 60) + 1 , LoginDateTime) ,
	EndReasonId	= ABS (CHECKSUM (NEWID ())) % 4 + 1
WHERE
	LoginDateTime < DATEADD (MINUTE , - (5 * 60) , SYSDATETIME ());
GO


INSERT INTO
	Operation.Invitations WITH (TABLOCK)
(
	RequestingSessionId ,
	ReceivingMemberId ,
	CreationDateTime ,
	StatusId ,
	ResponseDateTime
)
SELECT TOP (5000000)
	RequestingSessionId	= MemberSessions.Id ,
	ReceivingMemberId	= ABS (CHECKSUM (NEWID ())) % 100000 + 1 ,
	CreationDateTime	= DATEADD (SECOND , ABS (CHECKSUM (NEWID ())) % DATEDIFF (SECOND , MemberSessions.LoginDateTime , ISNULL (MemberSessions.EndDateTime , SYSDATETIME ())) , MemberSessions.LoginDateTime) ,
	StatusId			= ABS (CHECKSUM (NEWID ())) % 3 + 1 ,
	ResponseDateTime	= NULL
FROM
	Operation.MemberSessions AS MemberSessions
CROSS JOIN
	sys.tables
ORDER BY
	NEWID () ASC;
GO


UPDATE
	Operation.Invitations
SET
	ResponseDateTime = DATEADD (SECOND , ABS (CHECKSUM (NEWID ())) % DATEDIFF (SECOND , CreationDateTime , SYSDATETIME ()) , CreationDateTime)
WHERE
	StatusId != 1;	-- Sent
GO


-- Setup the Problematic Application problem

CREATE PROCEDURE
	Operation.usp_GetInvitationsByStatus
(
	@inStatusId AS TINYINT
)
AS

SELECT TOP (10)
	Id ,
	RequestingSessionId ,
	ReceivingMemberId ,
	CreationDateTime ,
	StatusId ,
	ResponseDateTime
FROM
	Operation.Invitations
WHERE
	StatusId = @inStatusId
ORDER BY
	CreationDateTime ASC;
GO


INSERT INTO
	Operation.Invitations
(
	RequestingSessionId ,
	ReceivingMemberId ,
	CreationDateTime ,
	StatusId ,
	ResponseDateTime
)
SELECT TOP (10)
	RequestingSessionId	= ABS (CHECKSUM (NEWID ())) % 1000000 + 1 ,
	ReceivingMemberId	= ABS (CHECKSUM (NEWID ())) % 100000 + 1 ,
	CreationDateTime	= DATEADD (SECOND , - ABS (CHECKSUM (NEWID ())) % (365 * 24 * 60 * 60) , SYSDATETIME ()) ,
	StatusId			= 4 ,
	ResponseDateTime	= NULL
FROM
	sys.all_columns;
GO


CREATE NONCLUSTERED INDEX
	ix_Invitations_nc_nu_StatusId
ON
	Operation.Invitations (StatusId ASC);
GO


-- Create the "Operation.usp_SendFakeInvitations" stored procedure

CREATE PROCEDURE
	Operation.usp_SendFakeInvitations
AS

DECLARE
	@tblPotentialCouples
TABLE
(
	RequestingMemberId	INT	NOT NULL ,
	ReceivingMemberId	INT	NOT NULL
);

INSERT INTO
	@tblPotentialCouples
(
	RequestingMemberId ,
	ReceivingMemberId
)
SELECT
	RequestingMemberId	= RequestingMembers.Id ,
	ReceivingMemberId	= ReceivingMembers.Id
FROM
	(
		SELECT TOP (200)
			Id ,
			CountryId ,
			BirthDate ,
			SexualPreferenceId
		FROM
			Operation.Members
		ORDER BY
			NEWID () ASC
	)
	AS
		RequestingMembers
CROSS JOIN
	(
		SELECT TOP (200)
			Id ,
			CountryId ,
			GenderId ,
			BirthDate
		FROM
			Operation.Members
		WHERE
			MaritalStatusId != 2
		OR
			MaritalStatusId IS NULL
		ORDER BY
			NEWID () ASC
	)
	AS
		ReceivingMembers
WHERE
	RequestingMembers.CountryId = ReceivingMembers.CountryId
AND
	(RequestingMembers.SexualPreferenceId = ReceivingMembers.GenderId OR RequestingMembers.SexualPreferenceId IS NULL)
AND
	ABS (DATEDIFF (YEAR , RequestingMembers.BirthDate , ReceivingMembers.BirthDate)) <= 5
AND
	RequestingMembers.Id != ReceivingMembers.Id;

INSERT INTO
	Operation.Invitations
(
	RequestingSessionId ,
	ReceivingMemberId ,
	CreationDateTime ,
	StatusId ,
	ResponseDateTime
)
SELECT
	RequestingSessionId	= RequestingSessions.Id ,
	ReceivingMemberId	= PotentialCouples.ReceivingMemberId ,
	CreationDateTime	= DATEADD (SECOND , 5 , RequestingSessions.LoginDateTime) ,
	StatusId			= 1 ,	-- Sent
	ResponseDateTime	= NULL
FROM
	@tblPotentialCouples AS PotentialCouples
CROSS APPLY
	(
		SELECT TOP (1)
			MemberSessions.Id ,
			MemberSessions.LoginDateTime
		FROM
			Operation.MemberSessions AS MemberSessions
		WHERE
			MemberSessions.MemberId = PotentialCouples.RequestingMemberId
		ORDER BY
			MemberSessions.LoginDateTime DESC
	)
	AS
		RequestingSessions;
GO


-- Setup the Partition Elimination example

CREATE SCHEMA
	Web;
GO


DECLARE
	@DatesTable TABLE
(
	DateValue DATETIME2(0) NOT NULL
);

INSERT INTO
	@DatesTable
(
	DateValue
)
SELECT TOP (100)
	DateValue = CAST (DATEADD (DAY , 4 - (ROW_NUMBER () OVER (ORDER BY (SELECT NULL))) , SYSDATETIME ()) AS DATETIME2(0))
FROM
	sys.all_columns AS T1
CROSS JOIN
	sys.all_columns AS T2;

DECLARE 
	@Statement AS NVARCHAR(MAX) =
		N'
			CREATE PARTITION FUNCTION
				pf_EveryDay (DATETIME2(0))
			AS RANGE
				RIGHT
			FOR VALUES
				(
					';

SELECT
	@Statement += N'''' + CONVERT (NCHAR(8) , DateValue , 112) + N''' ,
					'
FROM
	@DatesTable
ORDER BY
	DateValue ASC;

SET
	@Statement = LEFT (@Statement , LEN (@Statement) - 9) + N'
				);
		';

EXECUTE sys.sp_executesql
	@statement = @Statement;
GO


CREATE PARTITION SCHEME
	ps_EveryDay
AS
	PARTITION pf_EveryDay
ALL TO
	([PRIMARY]);
GO


CREATE SEQUENCE
	Web.PageViewIDs
AS
	BIGINT
START WITH
	1
INCREMENT BY
	1
MINVALUE
	1
NO MAXVALUE
CACHE
	10000;
GO


CREATE TABLE
	Web.PageViews
(
	Id				BIGINT			NOT NULL ,
	URL				NVARCHAR(100)	NOT NULL ,
	ReferenceCode	BIGINT			NULL ,
	SessionId		BIGINT			NOT NULL ,
	DateAndTime		DATETIME2(0)	NOT NULL
)
ON
	ps_EveryDay (DateAndTime);
GO


CREATE CLUSTERED INDEX
	ix_PageViews_c_DateAndTime
ON
	Web.PageViews (DateAndTime ASC)
ON
	ps_EveryDay (DateAndTime);
GO


ALTER TABLE
	Web.PageViews
ADD CONSTRAINT
	pk_PageViews_nc_Id#DateAndTime
PRIMARY KEY NONCLUSTERED
	(
		Id			ASC ,
		DateAndTime	ASC
	)
ON
	ps_EveryDay (DateAndTime);
GO


ALTER TABLE
	Web.PageViews
ADD CONSTRAINT
	df_PageViews_Id
DEFAULT
	NEXT VALUE FOR Web.PageViewIDs
FOR
	Id;
GO


CREATE TABLE
	Web.RandomDateTimeValues
(
	RandomDateTime DATETIME2(0) NOT NULL
);
GO


INSERT INTO
	Web.RandomDateTimeValues
(
	RandomDateTime
)
SELECT TOP (500000)
	RandomDateTime = DATEADD (SECOND , ABS (CHECKSUM (NEWID ())) % (24 * 60 * 60) , DATEADD (DAY , - (ABS (CHECKSUM (NEWID ())) % 100) , CAST (CAST (SYSDATETIME () AS DATE) AS DATETIME2(0))))
FROM
	sys.all_objects AS T1
CROSS JOIN
	sys.all_objects AS T2;
GO


DELETE FROM
	Web.RandomDateTimeValues
WHERE
	RandomDateTime > SYSDATETIME ();
GO


INSERT INTO
	Web.PageViews WITH (TABLOCK)
(
	URL ,
	ReferenceCode ,
	SessionId ,
	DateAndTime
)
SELECT
	URL				= N'www.' + REPLICATE (N'x' , ABS (CHECKSUM (NEWID ())) % 90) + N'.com' ,
	ReferenceCode	= ABS (CHECKSUM (NEWID ())) % 1000000 + 1 ,
	SessionId		= ABS (CHECKSUM (NEWID ())) % 1000000 + 1 ,
	DateAndTime		= RandomDateTime
FROM
	Web.RandomDateTimeValues
ORDER BY
	RandomDateTime ASC;
GO
