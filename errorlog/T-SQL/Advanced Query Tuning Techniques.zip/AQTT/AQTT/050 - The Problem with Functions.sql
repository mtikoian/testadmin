USE
	SQLSaturday360;
GO


SET STATISTICS IO ON;
GO


-- Create the "Operation.udf_InvitationRank" scalar function

CREATE FUNCTION
	Operation.udf_InvitationRank
(
	@inStatusId			AS TINYINT ,
	@inCreationDateTime	AS DATETIME2(0) ,
	@inResponseDateTime	AS DATETIME2(0)
)
RETURNS
	NVARCHAR(10)
AS
BEGIN

	DECLARE
		@Result AS NVARCHAR(10);

	IF
		@inStatusId = 1	-- Sent
	BEGIN

		IF
			DATEDIFF (DAY , @inCreationDateTime , SYSDATETIME ()) > 30
		BEGIN

			SET @Result = N'Very Poor';

		END;

		IF
			DATEDIFF (DAY , @inCreationDateTime , SYSDATETIME ()) <= 30
		AND
			DATEDIFF (DAY , @inCreationDateTime , SYSDATETIME ()) > 10
		BEGIN

			SET @Result = N'Poor';

		END;

		IF
			DATEDIFF (DAY , @inCreationDateTime , SYSDATETIME ()) <= 10
		BEGIN

			SET @Result = N'Maybe';

		END;

	END;

	IF
		@inStatusId = 2	-- Accepted
	BEGIN

		IF
			DATEDIFF (DAY , @inCreationDateTime , @inResponseDateTime) > 30
		BEGIN

			SET @Result = N'Nice';

		END;

		IF
			DATEDIFF (DAY , @inCreationDateTime , @inResponseDateTime) <= 30
		AND
			DATEDIFF (DAY , @inCreationDateTime , @inResponseDateTime) > 10
		BEGIN

			SET @Result = N'Good';

		END;

		IF
			DATEDIFF (DAY , @inCreationDateTime , @inResponseDateTime) <= 10
		BEGIN

			SET @Result = N'Excellent';

		END;

	END;

	IF
		@inStatusId = 3	-- Denied
	BEGIN

		IF
			DATEDIFF (DAY , @inCreationDateTime , @inResponseDateTime) > 30
		BEGIN

			SET @Result = N'Not Good';

		END;

		IF
			DATEDIFF (DAY , @inCreationDateTime , @inResponseDateTime) <= 30
		AND
			DATEDIFF (DAY , @inCreationDateTime , @inResponseDateTime) > 10
		BEGIN

			SET @Result = N'Bad';

		END;

		IF
			DATEDIFF (DAY , @inCreationDateTime , @inResponseDateTime) <= 10
		BEGIN

			SET @Result = N'Basa';

		END;

	END;

	RETURN @Result;

END;
GO


-- Check out the execution plan of the following query

SELECT
	InvitationId		= Invitations.Id ,
	InvitationStatus	= InvitationStatuses.Name ,
	CreationDateTime	= Invitations.CreationDateTime ,
	ResponseDateTime	= Invitations.ResponseDateTime
FROM
	Operation.Invitations AS Invitations
INNER JOIN
	Lists.InvitationStatuses AS InvitationStatuses
ON
	Invitations.StatusId = InvitationStatuses.Id
WHERE
	Operation.udf_InvitationRank (StatusId , CreationDateTime , ResponseDateTime) = N'Excellent';
GO


-- Put the function logic inside the query

SELECT
	InvitationId		= Invitations.Id ,
	InvitationStatus	= InvitationStatuses.Name ,
	CreationDateTime	= Invitations.CreationDateTime ,
	ResponseDateTime	= Invitations.ResponseDateTime
FROM
	Operation.Invitations AS Invitations
INNER JOIN
	Lists.InvitationStatuses AS InvitationStatuses
ON
	Invitations.StatusId = InvitationStatuses.Id
WHERE
	Invitations.StatusId = 2	-- Accepted
AND
	DATEDIFF (DAY , Invitations.CreationDateTime , Invitations.ResponseDateTime) <= 10;
GO


-- Rewrite the scalar function as an inline function

CREATE FUNCTION
	Operation.udf_InvitationRank_Inline
(
	@inStatusId			AS TINYINT ,
	@inCreationDateTime	AS DATETIME2(0) ,
	@inResponseDateTime	AS DATETIME2(0)
)
RETURNS
	TABLE
AS

RETURN
(
	SELECT
		InvitationRank =
			CASE
				WHEN @inStatusId = 1 AND DATEDIFF (DAY , @inCreationDateTime , SYSDATETIME ()) > 30
					THEN N'Very Poor'
				WHEN @inStatusId = 1 AND DATEDIFF (DAY , @inCreationDateTime , SYSDATETIME ()) <= 30 AND DATEDIFF (DAY , @inCreationDateTime , SYSDATETIME ()) > 10
					THEN N'Poor'
				WHEN @inStatusId = 1 AND DATEDIFF (DAY , @inCreationDateTime , SYSDATETIME ()) <= 10
					THEN N'Maybe'
				WHEN @inStatusId = 2 AND DATEDIFF (DAY , @inCreationDateTime , @inResponseDateTime) > 30
					THEN N'Nice'
				WHEN @inStatusId = 2 AND DATEDIFF (DAY , @inCreationDateTime , @inResponseDateTime) <= 30 AND DATEDIFF (DAY , @inCreationDateTime , @inResponseDateTime) > 10
					THEN N'Good'
				WHEN @inStatusId = 2 AND DATEDIFF (DAY , @inCreationDateTime , @inResponseDateTime) <= 10
					THEN N'Excellent'
				WHEN @inStatusId = 3 AND DATEDIFF (DAY , @inCreationDateTime , @inResponseDateTime) > 30
					THEN N'Not Good'
				WHEN @inStatusId = 3 AND DATEDIFF (DAY , @inCreationDateTime , @inResponseDateTime) <= 30 AND DATEDIFF (DAY , @inCreationDateTime , @inResponseDateTime) > 10
					THEN N'Bad'
				WHEN @inStatusId = 3 AND DATEDIFF (DAY , @inCreationDateTime , @inResponseDateTime) <= 10
					THEN N'Basa'
			END
);
GO


SELECT
	InvitationId		= Invitations.Id ,
	InvitationStatus	= InvitationStatuses.Name ,
	CreationDateTime	= Invitations.CreationDateTime ,
	ResponseDateTime	= Invitations.ResponseDateTime
FROM
	Operation.Invitations AS Invitations
INNER JOIN
	Lists.InvitationStatuses AS InvitationStatuses
ON
	Invitations.StatusId = InvitationStatuses.Id
CROSS APPLY
	Operation.udf_InvitationRank_Inline (StatusId , CreationDateTime , ResponseDateTime) AS InvitationRanks
WHERE
	InvitationRanks.InvitationRank = N'Excellent';
GO
