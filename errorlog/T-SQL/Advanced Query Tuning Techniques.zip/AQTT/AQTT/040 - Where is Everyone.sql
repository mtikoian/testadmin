USE
	SQLSaturday360;
GO


SET STATISTICS IO ON;
GO


-- Where is all the information in the tooltip?

SELECT
	*
FROM
	Operation.Members
WHERE
	CountryId = 4	-- France
AND
	PhoneNumber LIKE N'1%'
AND
	GenderId = 2	-- Female
AND
	DATEDIFF (YEAR , BirthDate , SYSDATETIME()) > 25
AND
	MONTH (BirthDate) = 3
AND
	SexualPreferenceId = 1	-- Male
AND
	MaritalStatusId IN (1,3)
AND
	RegistrationDateTime >= DATEADD (YEAR , -1 , SYSDATETIME ());
GO
