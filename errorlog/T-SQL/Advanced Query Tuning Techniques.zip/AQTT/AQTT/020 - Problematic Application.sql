USE
	SQLSaturday360;
GO


SET STATISTICS IO ON;
GO


-- Use Profiler to monitor the problematic stored procedure in the problematic application
-- Copy and paste an instance of the stored procedure call and execute it

exec Operation.usp_GetInvitationsByStatus @inStatusId=2


-- Check how many execution plans are in cache for this stored procedure

SELECT
	ExecutionPlan			= QueryPlans.query_plan ,
	CachedDateTime			= ProcedureStats.cached_time ,
	LastExecutionDateTime	= ProcedureStats.last_execution_time ,
	ExecutionCount			= ProcedureStats.execution_count ,
	AverageElapsedTime		= CAST ((CAST (ProcedureStats.total_elapsed_time AS DECIMAL(19,2)) / CAST (ProcedureStats.execution_count AS DECIMAL(19,2)) / 1000.0) AS DECIMAL(19,2))
FROM
	sys.dm_exec_procedure_stats AS ProcedureStats
CROSS APPLY
	sys.dm_exec_query_plan (ProcedureStats.plan_handle) AS QueryPlans
WHERE
	database_id = DB_ID (N'SQLSaturday360')
AND
	object_id = OBJECT_ID (N'Operation.usp_GetInvitationsByStatus');
GO


-- Compare the values of the set options for both plans

SELECT
	ExecutionPlan			= QueryPlans.query_plan ,
	CachedDateTime			= ProcedureStats.cached_time ,
	LastExecutionDateTime	= ProcedureStats.last_execution_time ,
	ExecutionCount			= ProcedureStats.execution_count ,
	AverageElapsedTime		= CAST ((CAST (ProcedureStats.total_elapsed_time AS DECIMAL(19,2)) / CAST (ProcedureStats.execution_count AS DECIMAL(19,2)) / 1000.0) AS DECIMAL(19,2)) ,
	SetOptions				= PlanAttributes.value
FROM
	sys.dm_exec_procedure_stats AS ProcedureStats
CROSS APPLY
	sys.dm_exec_query_plan (ProcedureStats.plan_handle) AS QueryPlans
CROSS APPLY
	sys.dm_exec_plan_attributes (ProcedureStats.plan_handle) AS PlanAttributes
WHERE
	database_id = DB_ID (N'SQLSaturday360')
AND
	object_id = OBJECT_ID (N'Operation.usp_GetInvitationsByStatus')
AND
	PlanAttributes.attribute = 'set_options';
GO


-- Compare each set option between the two execution plans and find which one is guilty...

SELECT
	ExecutionPlan					= QueryPlans.query_plan ,
	CachedDateTime					= ProcedureStats.cached_time ,
	LastExecutionDateTime			= ProcedureStats.last_execution_time ,
	ExecutionCount					= ProcedureStats.execution_count ,
	AverageElapsedTime				= CAST ((CAST (ProcedureStats.total_elapsed_time AS DECIMAL(19,2)) / CAST (ProcedureStats.execution_count AS DECIMAL(19,2)) / 1000.0) AS DECIMAL(19,2)) ,
	ANSI_NULLS_Value				= IIF (CAST (PlanAttributes.value AS INT) & 32 = 32 , N'True' , N'False') ,
	ANSI_PADDING_Value				= IIF (CAST (PlanAttributes.value AS INT) & 1 = 1 , N'True' , N'False') ,
	ANSI_WARNINGS_Value				= IIF (CAST (PlanAttributes.value AS INT) & 16 = 16 , N'True' , N'False') ,
	ARITHABORT_Value				= IIF (CAST (PlanAttributes.value AS INT) & 4096 = 4096 , N'True' , N'False') ,
	CONCAT_NULL_YIELDS_NULL_Value	= IIF (CAST (PlanAttributes.value AS INT) & 8 = 8 , N'True' , N'False') ,
	NUMERIC_ROUNDABORT_Value		= IIF (CAST (PlanAttributes.value AS INT) & 8192 = 8192 , N'True' , N'False') ,
	QUOTED_IDENTIFIER_Value			= IIF (CAST (PlanAttributes.value AS INT) & 64 = 64 , N'True' , N'False')
FROM
	sys.dm_exec_procedure_stats AS ProcedureStats
CROSS APPLY
	sys.dm_exec_query_plan (ProcedureStats.plan_handle) AS QueryPlans
CROSS APPLY
	sys.dm_exec_plan_attributes (ProcedureStats.plan_handle) AS PlanAttributes
WHERE
	database_id = DB_ID (N'SQLSaturday360')
AND
	object_id = OBJECT_ID (N'Operation.usp_GetInvitationsByStatus')
AND
	PlanAttributes.attribute = 'set_options';
GO


-- Change the setting of the ARITHABORT option

SET ARITHABORT OFF;
GO


-- Execute the problematic stored procedure again

exec Operation.usp_GetInvitationsByStatus @inStatusId=2
