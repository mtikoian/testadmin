--http://www.techrepublic.com/blog/the-enterprise-cloud/comparing-cursor-vs-while-loop-performance-in-sql-server-2008/
use tempdb
GO
DBCC FREESESSIONCACHE WITH NO_INFOMSGS;
GO
SET STATISTICS IO ON

----The cursor example above produces 11114 logical reads from the database
/*
IF OBJECT_ID('tempdb..CursorTest','u') IS NOT NULL
DROP TABLE CursorTest


GO
CREATE TABLE CursorTest
(
idcol INT IDENTITY(1,1) PRIMARY KEY CLUSTERED,
fld1 INT,
fld2 INT,
fld3 CHAR(800)
)
GO

SET NOCOUNT ON
DECLARE  @x INT = 10000
WHILE @x > 0
BEGIN
INSERT INTO CursorTest (fld1, fld2, fld3)
SELECT 1, RAND() * 100 * DATEPART(ms, GETDATE()), LEFT(REPLICATE(CAST(NEWID() AS VARCHAR(36)),30),800)
SET @x -= 1
END

*/
--select * from cursortest
--DECLARE @Variable1 INT, @Variable2 INT
--DECLARE CursorName CURSOR FAST_FORWARD
--FOR
--SELECT idcol
--FROM CursorTest
--OPEN CursorName
--FETCH NEXT FROM CursorName
--INTO @Variable1
--WHILE @@FETCH_STATUS = 0
--BEGIN
--PRINT CAST(@Variable1 AS VARCHAR(5))
--FETCH NEXT FROM CursorName
--INTO @Variable1
--END
--CLOSE CursorName
--DEALLOCATE CursorName

------To get a true look at how many reads are performed on the database, 
------I'll need to use SQL Server Profiler. 
------This tool will give me a combined aggregation of the reads taken 
------for each record rather than each individual record, 
------as would be indicated through SET STATISTICS IO ON. 
------The cursor example above produces 11114 logical reads from the database.

------The following snippet performs the same operation as the cursor 
------above but through the use of a WHILE loop. 
------Notice that it is necessary to perform a query on the base table
------ for each record returned. Also, the use of an ORDER BY statement 
------is necessary, as is the use of a primary key column.

DECLARE @Rows INT, @IdCol INT
SET @Rows = 1
SET @IdCol = 0
WHILE @Rows > 0
BEGIN
SELECT TOP 1
@idcol = idcol
FROM CursorTest
WHERE
idcol >= @IdCol
ORDER BY idcol
SET @Rows = @@ROWCOUNT
PRINT CAST(@IdCol AS VARCHAR(5))
SET @IdCol += 1
END
