use ProvidenceSQLServerUG
go

select * into dbo.Dim_Dateee from [ANC-DW].dbo.Dim_Date