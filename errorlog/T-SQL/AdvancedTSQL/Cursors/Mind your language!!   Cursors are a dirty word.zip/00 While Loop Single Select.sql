USE [ProvidenceSQLServerUG]
GO
DBCC FREESESSIONCACHE WITH NO_INFOMSGS;
--SET STATISTICS IO ON
GO

/****** Object:  StoredProcedure [dbo].[BillingGrowthVsGoalDated]    Script Date: 03/05/2014 09:13:20 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID(N'tempdb..#rawdatafinal') IS NOT NULL
BEGIN
     DROP TABLE #rawdatafinal
END
IF OBJECT_ID(N'tempdb..#rawdata18') IS NOT NULL
BEGIN
     DROP TABLE #rawdata18
END
IF OBJECT_ID(N'tempdb..#rawdata19') IS NOT NULL
BEGIN
     DROP TABLE #rawdata19
END
IF OBJECT_ID(N'tempdb..#rawdata18c') IS NOT NULL
BEGIN
     DROP TABLE #rawdata18c
END

IF OBJECT_ID(N'tempdb..#rawdata9') IS NOT NULL
BEGIN
     DROP TABLE #rawdata9
END
IF OBJECT_ID(N'tempdb..#rawdataloop') IS NOT NULL
BEGIN
     DROP TABLE #rawdataloop
END

IF OBJECT_ID(N'tempdb..#rawdata55') IS NOT NULL
BEGIN
     DROP TABLE #rawdata55
END
IF OBJECT_ID(N'tempdb..#rawdata18p') IS NOT NULL
BEGIN
     DROP TABLE #rawdata18p
END
IF OBJECT_ID(N'tempdb..#rawdata18z') IS NOT NULL
BEGIN
     DROP TABLE #rawdata18z
END
 
/*
 drop table #rawdata18
 drop table #rawdata19
  drop table #rawdata18c
 drop table #rawdataLoop
 drop table #rawdata9
 drop table #rawdata55
 drop table #RAWDATA18p
drop table #RAWDATA18z
 */
  --drop table #rawdata18
--Declare variables and set start and end dates
 --CREATE procedure [dbo].[BillingGrowthVsGoalDated]  
--(
--@SolutionsArea varchar(75)
--,@YearIncoming Varchar(4)
--)
 --as
declare @sql nvarchar(max)
declare @sql1 nvarchar(max)
declare @beginFiscal datetime
declare @endFiscal datetime
declare @month01 varchar(6)
declare @month02 varchar(6)
declare @month03 varchar(6)
declare @month04 varchar(6)
declare @month05 varchar(6)
declare @month06 varchar(6)
declare @month07 varchar(6)
declare @month08 varchar(6)
declare @month09 varchar(6)
declare @month10 varchar(6)
declare @month11 varchar(6)
declare @month12 varchar(6)
declare @YearIncoming varchar(4)
declare @solutionsArea varchar(75)
set @solutionsArea ='Applications and Information'
set @YearIncoming ='2014'

set @beginfiscal= (select Min(datee) from .dbo.Dim_Date
where convert(int,datepart(year,datee)) + 1 = @yearincoming)
set @beginfiscal =
(case 
When @yearIncoming<> '2013' then dateadd(month,6,@beginFiscal) else @beginfiscal 
end)  

set @endfiscal= (select Min(datee) from .dbo.Dim_Date
where convert(int,datepart(year,datee)) = @yearincoming)
set @endfiscal =dateadd(month,6,@endFiscal)


set @month01  =
  convert(varchar(4),datepart(Year,@beginFiscal)) + 
  case 
  when len(convert(varchar(2),datepart(Month,@beginFiscal))) = 1 then 
   convert(varchar(2),'0' + convert(varchar(2),datepart(Month,@beginFiscal)))  else
   convert(varchar(2),datepart(Month,@beginFiscal))
  end

set @month02  =
  convert(varchar(4),datepart(Year,@beginFiscal)) + 
  case 
  when len(convert(varchar(2),datepart(Month,dateadd(mm,1,@beginFiscal))))  = 1 then 
   convert(varchar(2),'0' + convert(varchar(2),datepart(Month,dateadd(mm,1,@beginFiscal))))  else
   convert(varchar(2),datepart(Month,dateadd(mm,1,@beginFiscal)))
  end   
  
set @month03  =
  convert(varchar(4),datepart(Year,@beginFiscal)) + 
  case 
  when len(convert(varchar(2),datepart(Month,dateadd(mm,2,@beginFiscal))))  = 1 then 
   convert(varchar(2),'0' + convert(varchar(2),datepart(Month,dateadd(mm,2,@beginFiscal))))  else
   convert(varchar(2),datepart(Month,dateadd(mm,2,@beginFiscal)))
  end   
  
set @month04  =
  convert(varchar(4),datepart(Year,@beginFiscal)) + 
  case 
  when len(convert(varchar(2),datepart(Month,dateadd(mm,3,@beginFiscal))))  = 1 then 
   convert(varchar(2),'0' + convert(varchar(2),datepart(Month,dateadd(mm,3,@beginFiscal))))  else
   convert(varchar(2),datepart(Month,dateadd(mm,3,@beginFiscal)))
  end   
  
  set @month05  =
  convert(varchar(4),datepart(Year,@beginFiscal)) + 
  case 
  when len(convert(varchar(2),datepart(Month,dateadd(mm,4,@beginFiscal))))  = 1 then 
   convert(varchar(2),'0' + convert(varchar(2),datepart(Month,dateadd(mm,4,@beginFiscal))))  else
   convert(varchar(2),datepart(Month,dateadd(mm,4,@beginFiscal)))
  end   
  set @month06  =
  convert(varchar(4),datepart(Year,@beginFiscal)) + 
  case 
  when len(convert(varchar(2),datepart(Month,dateadd(mm,5,@beginFiscal))))  = 1 then 
   convert(varchar(2),'0' + convert(varchar(2),datepart(Month,dateadd(mm,5,@beginFiscal))))  else
   convert(varchar(2),datepart(Month,dateadd(mm,5,@beginFiscal)))
  end   

set @month07  =
  convert(varchar(4),datepart(Year,@endFiscal)) + 
  case 
  when len(convert(varchar(2),datepart(Month,dateadd(mm,-6,@endFiscal))))  = 1 then 
   convert(varchar(2),'0' + convert(varchar(2),datepart(Month,dateadd(mm,-6,@endFiscal))))  else
   convert(varchar(2),datepart(Month,dateadd(mm,-6,@endFiscal)))
  end 

set @month08  =
  convert(varchar(4),datepart(Year,@endFiscal)) + 
  case 
  when len(convert(varchar(2),datepart(Month,dateadd(mm,-5,@endFiscal))))  = 1 then 
   convert(varchar(2),'0' + convert(varchar(2),datepart(Month,dateadd(mm,-5,@endFiscal))))  else
   convert(varchar(2),datepart(Month,dateadd(mm,-5,@endFiscal)))
  end 
set @month09  =
  convert(varchar(4),datepart(Year,@endFiscal)) + 
  case 
  when len(convert(varchar(2),datepart(Month,dateadd(mm,-4,@endFiscal))))  = 1 then 
   convert(varchar(2),'0' + convert(varchar(2),datepart(Month,dateadd(mm,-4,@endFiscal))))  else
   convert(varchar(2),datepart(Month,dateadd(mm,-4,@endFiscal)))
  end 
set @month10  =
  convert(varchar(4),datepart(Year,@endFiscal)) + 
  case 
  when len(convert(varchar(2),datepart(Month,dateadd(mm,-3,@endFiscal))))  = 1 then 
   convert(varchar(2),'0' + convert(varchar(2),datepart(Month,dateadd(mm,-3,@endFiscal))))  else
   convert(varchar(2),datepart(Month,dateadd(mm,-3,@endFiscal)))
  end 

set @month11  =
  convert(varchar(4),datepart(Year,@endFiscal)) + 
  case 
  when len(convert(varchar(2),datepart(Month,dateadd(mm,-2,@endFiscal))))  = 1 then 
   convert(varchar(2),'0' + convert(varchar(2),datepart(Month,dateadd(mm,-2,@endFiscal))))  else
   convert(varchar(2),datepart(Month,dateadd(mm,-2,@endFiscal)))
  end 
set @month12  =
  convert(varchar(4),datepart(Year,@endFiscal)) + 
  case 
  when len(convert(varchar(2),datepart(Month,dateadd(mm,-1,@endFiscal))))  = 1 then 
   convert(varchar(2),'0' + convert(varchar(2),datepart(Month,dateadd(mm,-1,@endFiscal))))  else
   convert(varchar(2),datepart(Month,dateadd(mm,-1,@endFiscal)))
  end 
  
--Take off 5 millisec to ensure that records with no times for July1 are taken as a part of the year end
 set @endFiscal = DATEADD(ms,-5,@endFiscal)

 --Main query starts here
 

DECLARE @RevenueTable TABLE (YearMth Varchar(6), Month varchar(12), 
[Revenue] decimal(10,2), [Cumulative] decimal(10,2))

DECLARE @YearMth Varchar(6),
        @Month Varchar(12),
        @Revenue decimal(10,2),
        @RunningTotal int
SET @RunningTotal = 0 
--DECLARE rt_cursor CURSOR
--FOR
--SELECT yearmth,Month, [Revenue]   
--FROM ProvidenceSQLServerUG.[dbo].[rawdata8]
--ORDER BY YearMth

Select Identity(int, 1,1) AS PK,  yearmth,Month,Revenue 
Into   #rawdataLoop
From   dbo.rawdata8

declare @kounter as int
declare @rowcount as int
set @kounter = 1
Set @Rowcount = (select count(month) from #rawdataLoop)

While @Kounter <= @Rowcount
Begin
      Select @RunningTotal = @RunningTotal + Revenue,
          @Revenue      = Revenue, 
          @YearMth      = YEarMth,
          @Month        = [Month] from (
     select YearMth,Revenue,[Month] from #rawdataLoop
     where PK = @Kounter)a
     
      
 INSERT @RevenueTable VALUES (@YearMth,@Month,@Revenue,@RunningTotal)
    Select @Kounter = @Kounter + 1
End

--Create the PIVOT TABLE

SELECT * into #rawdata9 FROM @RevenueTable
   --select * from #rawdata9
set @sql = 
' select  name, [' +  @month01+ '],[' + @month02+ '],[' +@month03+ '],[' +@month04+ '],[' +@month05 +'],[' 
 + @month06+ '],[' +@month07+ '],[' +@month08+ '],[' +@month09+ '],[' +@month10+ '],[' +  
  @month11+ '],[' +@month12 +
']   from ' +
' ( ' +
'  select Yearmth, name, value ' +
'  from #rawdata9 ' +
'  unpivot ' +
'  ( ' +
'    value for name in ([Cumulative],[Revenue]) ' +
'  ) unpiv '+
' ) src ' +
' pivot ' +
' ( ' +
'  sum(value) ' +
'  for YearMth in (['  
 + @month01+ '],[' + @month02+ '],[' +@month03+ '],[' +@month04+ '],[' +@month05 +'],[' 
 + @month06+ '],[' +@month07+ '],[' +@month08+ '],[' +@month09+ '],[' +@month10+ '],['  
 + @month11+ '],[' +@month12  +'] )) piv ' 
 + '  order by name asc ' 
set @sql1 =  
' create table dbo.testjunk  ( ' +
' name varchar(75) null, ' + 
'Month01 decimal(10,2) null, ' +
'Month02 decimal(10,2) null,' +
'Month03 decimal(10,2) null, ' +
'Month04 decimal(10,2) null, ' +
'Month05 decimal(10,2) null, ' +
'Month06 decimal(10,2) null, ' +
'Month07 decimal(10,2) null, ' +
'Month08 decimal(10,2) null, ' +
'Month09 decimal(10,2) null, ' +
'Month10 decimal(10,2) null, ' +
'Month11 decimal(10,2) null, ' +
'Month12 decimal(10,2) null, ' +
' )'
--exec sp_executesql @sql1

CREATE TABLE #rawdata55(
	[name] [varchar](75) NULL,
	[Month01] [decimal](10, 2) NULL,
	[Month02] [decimal](10, 2) NULL,
	[Month03] [decimal](10, 2) NULL,
	[Month04] [decimal](10, 2) NULL,
	[Month05] [decimal](10, 2) NULL,
	[Month06] [decimal](10, 2) NULL,
	[Month07] [decimal](10, 2) NULL,
	[Month08] [decimal](10, 2) NULL,
	[Month09] [decimal](10, 2) NULL,
	[Month10] [decimal](10, 2) NULL,
	[Month11] [decimal](10, 2) NULL,
	[Month12] [decimal](10, 2) NULL
)

--select @sql
insert #rawdata55
exec sp_executesql @SQL  with recompile
--select * from #rawdata55
SELECT  [name] 
      ,[Month01] 
      ,[Month02] 
      ,[Month03] 
      ,[Month04] 
      ,[Month05] 
      ,[Month06] 
      ,[Month07] 
      ,[Month08] 
      ,[Month09] 
      ,[Month10] 
      ,[Month11] 
      ,[Month12] 
      into #rawdata18
  FROM #rawdata55
  where name = 'Cumulative'
  union all
  select * from #rawdata55
  where name = 'Revenue'
  order by name desc
 
 SELECT 1 AS KEYY, * INTO #RAWDATA18p from #Rawdata18 where name = 'Revenue'
SELECT 1 AS KEYY, * INTO #RAWDATA18c FROM #rawdata18 where name = 'Cumulative'


Select 1 as sortkey, 'Monthly Billing' as Name
,isnull(Month01,0) as Month01 
,isnull(Month02,0) as Month02
,isnull(Month03,0) as Month03
,isnull(Month04,0) as Month04
,isnull(Month05,0) as Month05
,isnull(Month06,0) as Month06
,isnull(Month07,0) as Month07
,isnull(Month08,0) as Month08
,isnull(Month09,0) as Month09
,isnull(Month10,0) as Month10
,isnull(Month11,0) as Month11
,isnull(Month12,0) as Month12
 into #rawdata18z from #RAWDATA18p
union all
select 2 as sortkey,  'Cumulative Billings' as Name, Month01, Month02, Month03, Month04, Month05, Month06, Month07
,Month08,Month09,Month10,Month11 , Month12
from #RAWDATA18c
 
select * into #rawdata19 from #rawdata18z
union all

select 3 as sortkey, 'Billings Goal' as goal,
--goal,
month01,
month02,
month03,
month04,
month05,
month06,
month07,
month08,
month09,
month10,
month11,
month12
from ProvidenceSQLServerUG.[dbo].[FactGoals]
where solutionsarea = @SolutionsArea
and goal = 'Billings Goal' 
and [Year] = @YearIncoming

select * from #rawdata19


 









--GO


