use tempdb
GO
SET STATISTICS IO ON
IF OBJECT_ID('tempdb..CursorTest','u') IS NOT NULL
DROP TABLE CursorTest

GO
CREATE TABLE CursorTest
(
idcol INT IDENTITY(1,1) PRIMARY KEY CLUSTERED,
fld1 INT,
fld2 INT,
fld3 CHAR(800)
)
GO
SET NOCOUNT ON
DECLARE  @x INT = 10000
WHILE @x > 0
BEGIN
INSERT INTO CursorTest (fld1, fld2, fld3)
SELECT 1, RAND() * 100 * DATEPART(ms, GETDATE()), LEFT(REPLICATE(CAST(NEWID() AS VARCHAR(36)),30),800)
SET @x -= 1
END



----
---- cursor
----
--DECLARE @Variable1 INT, @Variable2 INT
--DECLARE CursorName CURSOR FAST_FORWARD
--FOR
--SELECT idcol
--FROM CursorTest
--OPEN CursorName
--FETCH NEXT FROM CursorName
--INTO @Variable1
--WHILE @@FETCH_STATUS = 0
--BEGIN
--PRINT CAST(@Variable1 AS VARCHAR(5))
--FETCH NEXT FROM CursorName
--INTO @Variable1
--END
--CLOSE CursorName
--DEALLOCATE CursorName

----
---- WHile Loop
----
--DECLARE @Rows INT, @IdCol INT
--SET @Rows = 1
--SET @IdCol = 0
--WHILE @Rows > 0
--BEGIN
--SELECT TOP 1
--@idcol = idcol
--FROM CursorTest
--WHERE
--idcol >= @IdCol
--ORDER BY idcol
--SET @Rows = @@ROWCOUNT
--PRINT CAST(@IdCol AS VARCHAR(5))
--SET @IdCol += 1
--END

