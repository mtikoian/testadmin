DECLARE @sqlcmd nvarchar(4000)
DECLARE @filename nvarchar(4000)

SET @sqlcmd = 'select * from sys.objects'
SET @filename = 'c:\object_export.txt'

EXECUTE [dbo].[WriteResultsToCsvFile] 
 @sqlcmd
 ,@filename

