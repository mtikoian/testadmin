﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices
Imports System.Data.Sql

' General Information about an assembly is controlled through the following
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("SQLCLRNet_BCPReplacement")>
<Assembly: AssemblyDescription("")>
<Assembly: AssemblyCompany("OSI Restaurant Partners, Inc.")>
<Assembly: AssemblyProduct("SQLCLRNet_BCPReplacement")>
<Assembly: AssemblyCopyright("Copyright © OSI Restaurant Partners, Inc. 2009")>
<Assembly: AssemblyTrademark("")>
<Assembly: CLSCompliant(True)>
<Assembly: ComVisible(False)>

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("c1691af8-2862-4ba5-9938-682e23eb79a3")>

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:

<Assembly: AssemblyVersion("1.0.*")> 
