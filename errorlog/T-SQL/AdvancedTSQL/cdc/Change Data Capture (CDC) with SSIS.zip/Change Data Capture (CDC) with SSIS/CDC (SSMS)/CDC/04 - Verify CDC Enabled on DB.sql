--Verify CDC is enabled, you will see a 1 for the database that have CDC enabled
Select [Name] as DBName, is_cdc_enabled from sys.databases