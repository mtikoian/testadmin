-- change the selected Database to CDCTest !!!!
USE [CDCTest]
GO

--Load some data into new DimCustomer_CDC table from AdventureWorksDW2012 database
SELECT * INTO DimCustomer_CDC
FROM [AdventureWorksDW2012].[dbo].[DimCustomer]
WHERE CustomerKey < 11500