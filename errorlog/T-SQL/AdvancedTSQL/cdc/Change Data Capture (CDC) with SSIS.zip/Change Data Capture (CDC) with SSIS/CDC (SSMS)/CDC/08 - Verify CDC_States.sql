-- change the selected Database to CDCTest !!!!
USE [CDCTest]
GO

--After creating the CDC Initial package and running it successfully, use this query to check that the CDC State is populated.
SELECT * FROM cdc_states
