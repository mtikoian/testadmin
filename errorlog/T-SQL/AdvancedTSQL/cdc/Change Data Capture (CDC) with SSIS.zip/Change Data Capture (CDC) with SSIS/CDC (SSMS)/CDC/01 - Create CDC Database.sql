--Create a new Database for CDC
USE [master]
GO
Create Database CDCTest