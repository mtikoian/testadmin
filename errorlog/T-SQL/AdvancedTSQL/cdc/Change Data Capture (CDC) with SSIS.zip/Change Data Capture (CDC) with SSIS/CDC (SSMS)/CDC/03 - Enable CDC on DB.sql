-- change the selected Database to CDCTest !!!!
USE [CDCTest]
GO

--Must be sysadmin to enable CDC
exec sp_cdc_enable_db