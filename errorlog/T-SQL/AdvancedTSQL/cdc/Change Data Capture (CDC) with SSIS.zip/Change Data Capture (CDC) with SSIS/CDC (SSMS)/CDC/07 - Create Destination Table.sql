-- change the selected Database to CDCTest !!!!
USE [CDCTest]
GO

--Create a table we can use as the destination (normally this would be on a different server/database, but this is for demo)
SELECT TOP 0 * INTO DimCustomer_Destination
FROM DimCustomer_CDC