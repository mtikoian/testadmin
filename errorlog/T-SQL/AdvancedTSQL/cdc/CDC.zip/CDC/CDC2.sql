USE [DBCDC]
GO

IF OBJECT_ID('[tblCustomer_Copy]') IS NOT NULL DROP TABLE [tblCustomer_Copy]

CREATE TABLE [dbo].[tblCustomer_Copy](
	[CustomerID] [int] NOT NULL,
	[FirstName] [varchar](50) NOT NULL,
	[Lastname] [varchar](50) NOT NULL,
	[IsActive] [bit] NULL,
	[CustomerTypeID] [int] NULL,
 CONSTRAINT [PK_tblCustomer_Copy] PRIMARY KEY CLUSTERED ([CustomerID])
)


SELECT * FROM [tblCustomer]
SELECT * FROM [tblCustomer_Copy]
SELECT * FROM [dbo].[cdc_states]
SELECT * FROM cdc.dbo_tblCustomer_CT

update [tblCustomer] set Lastname=Lastname+'.'

