--USE master
--CREATE DATABASE DBCDC
--ALTER DATABASE DBCDC SET RECOVERY SIMPLE;
--DROP DATABASE DBCDC

USE DBCDC

IF OBJECT_ID('dbo.tblCustomer') IS NOT NULL DROP TABLE dbo.tblCustomer

create table dbo.tblCustomer
(	CustomerID	INT NOT NULL IDENTITY,
	FirstName		VARCHAR(50) NOT NULL,
	Lastname		VARCHAR(50) NOT NULL,
	IsActive		BIT NULL,
	CONSTRAINT PK_tblCustomer PRIMARY KEY (CustomerID)
)
go
-- populate table
INSERT dbo.tblCustomer(FirstName,LastName) VALUES ('Ze','Pereira'), ('Chico','Tripa')


SELECT * FROM sys.tables
SELECT * FROM dbo.tblCustomer


EXEC sys.sp_cdc_enable_db
EXEC sys.sp_cdc_enable_table  @source_schema = N'dbo', @source_name = N'tblCustomer', @role_name = N'cdcRole' -- , @capture_instance='dbo_tblCustomer'

SELECT * FROM sys.tables
Select name From sys.sysusers Where issqlrole = 1
SELECT * FROM msdb.dbo.sysjobs


SELECT * FROM cdc.dbo_tblCustomer_CT

INSERT dbo.tblCustomer(FirstName,LastName) VALUES ('Joao','Silva')
SELECT * FROM cdc.dbo_tblCustomer_CT

DELETE dbo.tblCustomer WHERE FirstName='Ze'
SELECT * FROM cdc.dbo_tblCustomer_CT

UPDATE dbo.tblCustomer SET FirstName='Francisco' WHERE FirstName='Chico'
SELECT * FROM cdc.dbo_tblCustomer_CT

UPDATE dbo.tblCustomer SET FirstName=FirstName
SELECT * FROM cdc.dbo_tblCustomer_CT

UPDATE dbo.tblCustomer SET IsActive=1
SELECT * FROM cdc.dbo_tblCustomer_CT

-- Showing transaction time
SELECT	c.*, t.tran_begin_time
FROM	cdc.dbo_tblCustomer_CT c
	JOIN cdc.lsn_time_mapping t ON c.[__$start_lsn]=t.start_lsn


/**************************************************************************************************
* Adding a column
***************************************************************************************************/
ALTER TABLE dbo.tblCustomer ADD CustomerTypeID SMALLINT
go

UPDATE dbo.tblCustomer SET CustomerTypeID=1
SELECT * FROM cdc.dbo_tblCustomer_CT


-- 1. creates a new CDC table
EXEC sys.sp_cdc_enable_table @source_schema = N'dbo', @source_name = N'tblCustomer', @role_name = 'CDCRole', @capture_instance = 'TempCDC'
EXEC sys.sp_cdc_help_change_data_capture
SELECT * FROM [cdc].[TempCDC_CT] 

-- 2. copy from old to new CDC table
INSERT	[cdc].[TempCDC_CT] 
SELECT	*,NULL 
FROM	cdc.dbo_tblCustomer_CT Old
WHERE	NOT EXISTS (SELECT * FROM [cdc].[TempCDC_CT] New WHERE New.[__$start_lsn]=old.[__$start_lsn] AND new.[__$seqval]=old.[__$seqval] AND new.[__$operation]=old.[__$operation])


-- 3. drop old CDC (EXEC sys.sp_cdc_help_change_data_capture to see instance names)
EXEC sys.sp_cdc_disable_table @source_schema='dbo', @source_name='tblCustomer', @capture_instance='dbo_tblCustomer' -- InstanceName_TableName


-- 4. re-creates CDC with original name
EXEC sys.sp_cdc_enable_table @source_schema = N'dbo', @source_name = N'tblCustomer', @role_name = 'CDCRole'

-- 5. copy transactions
INSERT	cdc.dbo_tblCustomer_CT
SELECT	*
FROM	[cdc].[TempCDC_CT] Old
WHERE	NOT EXISTS (SELECT * FROM [cdc].[dbo_tblCustomer_CT] New WHERE New.[__$start_lsn]=old.[__$start_lsn] AND new.[__$seqval]=old.[__$seqval] AND new.[__$operation]=old.[__$operation])

-- 6. drop Temp CDC
EXEC sys.sp_cdc_disable_table @source_schema='dbo', @source_name='tblCustomer', @capture_instance='TempCDC'

-- 7. Done (is it really?)
SELECT * FROM cdc.dbo_tblCustomer_CT



/**************************************************************************************************
* breaking CDC
***************************************************************************************************/
SET ANSI_WARNINGS OFF
SET NOCOUNT ON
DECLARE @msg VARCHAR(100), @maxID INT
WHILE 1=1 BEGIN
	INSERT dbo.tblCustomer(FirstName,LastName) VALUES ('Raimundo','Souza')
	SET @msg='CustomerID: Source Table='+CONVERT(VARCHAR(9), Scope_Identity())
	SELECT @maxID=MAX(CustomerID) FROM cdc.dbo_tblCustomer_CT
	SET @msg=@msg + '  tracking table='+CONVERT(VARCHAR(9),@maxID)
	RAISERROR(@msg, 0,1) WITH NOWAIT
	DELETE dbo.tblCustomer WHERE FirstName='Raimundo'
END






-- CDC retention
-- sp_cdc_scan job scans the log and processes up to (max_trans * max_scans) transactions. 
-- It then waits the number of seconds specified in polling_interval before beginning the next log scan.
-- retention maximum value is 52494800 (100 years)
SELECT	j.name JobName, cj.maxtrans, cj.maxscans, cj.continuous, cj.pollinginterval, cj.retention
FROM	msdb.dbo.cdc_jobs cj 
	JOIN msdb.dbo.sysjobs j ON cj.job_id=j.job_id
WHERE	cj.database_id=DB_ID()

-- change CDC default values
EXEC sys.sp_cdc_change_job @job_type = N'cleanup', @retention = 7200 -- 5*24*60
EXECUTE sys.sp_cdc_change_job  @job_type = N'capture', @maxscans = 1000, @maxtrans = 15;
-- Changes to a job do not take effect until the job is stopped by using sp_cdc_stop_job and restarted by using sp_cdc_start_job.
EXEC sys.sp_cdc_stop_job @job_type = N'capture'
EXEC sys.sp_cdc_start_job @job_type = N'capture'




