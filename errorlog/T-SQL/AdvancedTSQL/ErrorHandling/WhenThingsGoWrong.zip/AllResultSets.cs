using System.Data.SqlClient;

public static class SqlErrorRepro {
   private static string sqlBatchText = @"
   -- BEGIN TRY
       SELECT name, log(max_length) FROM sys.columns
   -- END TRY
   -- BEGIN CATCH
   --    ; THROW
   -- END CATCH";


   public static void Main() {
      using (SqlConnection cn = new SqlConnection(
           @"Data Source=.;Integrated Security=SSPI;Database=tempdb"))
      using (SqlCommand cmd = new SqlCommand(sqlBatchText, cn)) {
         try {
            int rowCount = 0;
            cn.Open();
            using (SqlDataReader reader = cmd.ExecuteReader()) {
               while(reader.Read()) { ++rowCount; };
//               while(reader.NextResult());
            }
            System.Console.WriteLine("{0} rows read", rowCount);
         }
         catch (System.Exception ex){
            cmd.CommandText = @"IF @@trancount > 0 ROLLBACK TRANSACTION";
            cmd.ExecuteNonQuery();
            System.Console.WriteLine("ERROR: " + ex.Message);
         }
      }
   }
}