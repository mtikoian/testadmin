USE JProCo
GO

--These two statments appear to be identical
RAISERROR('Your bad!', 16, 1) 
;THROW 50000, 'Your bad!', 1 







--Both will say "Violation of PRIMARY KEY constraint" So what is the difference?
BEGIN TRY 
  INSERT INTO PayRates (EmpID, YearlySalary, MonthlySalary, HourlyRate, BonusPoints)
  VALUES (1, 50000, NULL, NULL,  0) 
END TRY 
BEGIN CATCH 
  PRINT ERROR_MESSAGE() 
END CATCH; 

BEGIN TRY
  INSERT INTO PayRates (EmpID, YearlySalary, MonthlySalary, HourlyRate, BonusPoints)
  VALUES (1, 50000, NULL, NULL,  0)
END TRY
BEGIN CATCH
 THROW --Changed this
END CATCH;


---------------Using TRY/CATCH in Stored Procedures (Section 0:00 to 3:19)
--Look at the Employee table and PayRates table and notice Employee #20 and 21 don't have a pay rate yet
SELECT * FROM Employee
SELECT * FROM PayRates

--Create a SPROC that insert new records to the PayRates table
CREATE PROC InsertYearlyPay @EmpID INT, @YrSalary MONEY
AS 
	BEGIN TRY 
		BEGIN TRAN 
	  INSERT INTO [dbo].[PayRates] (EmpID, YearlySalary, MonthlySalary, HourlyRate, BonusPoints) 
	  VALUES (@EmpID, @YrSalary, NULL, NULL,  0) 
		COMMIT TRAN 
	END TRY 
	BEGIN CATCH 
		ROLLBACK TRAN 
	END CATCH 
GO 

EXEC InsertYearlyPay 20, 50000 

--Now that Employee has pay set to Active
UPDATE Employee
SET [status] = 'Active'
WHERE EmpID = 20

--Check she is active with pay
SELECT * FROM Employee WHERE EmpID = 20
SELECT * FROM PayRates WHERE EmpID = 20

---------------Nesting Structured Error Handling (Section 0:00 to 3:19)
--Set all EmpID 1 to Null so we can try to set it with the sproc
UPDATE Employee SET [Status] = NULL WHERE EmpID = 1

SELECT * FROM Employee

--Make a stored proc that sets to Employee active and calls the InsertYearlyPay Sproc
CREATE PROC MakeYearlyEmployeePay @EmpID INT, @YrSalary MONEY 
AS 
	BEGIN TRY 
		BEGIN TRAN 
			UPDATE Employee 
			SET [status] = 'Active' 
			WHERE EmpID = @EmpID 

			EXEC InsertYearlyPay @EmpID, @YrSalary 

		COMMIT TRAN 
	END TRY 
	BEGIN CATCH 
		ROLLBACK TRAN 
		SELECT ERROR_MESSAGE() 
	END CATCH 
GO 

--Error but one statement updates
EXEC MakeYearlyEmployeePay 1, 91000

--Call on this and pass it EmpID 21 and 51000 per year
EXEC MakeYearlyEmployeePay 21, 51000 
GO

 



---------------THROW the calling code
--Have the InsertYearlyPay sproc THROW the error up to the calling code so it knows why the call failed.
ALTER PROC InsertYearlyPay @EmpID INT, @YrSalary MONEY
AS 
	BEGIN TRY
		BEGIN TRAN
	  INSERT INTO [dbo].[PayRates] (EmpID, YearlySalary, MonthlySalary, HourlyRate, BonusPoints)
	  VALUES (@EmpID, @YrSalary, NULL, NULL,  0)
		COMMIT TRAN
	END TRY
	BEGIN CATCH
		THROW; --This has been added
	END CATCH
GO

EXEC MakeYearlyEmployeePay 1, 11000
GO
