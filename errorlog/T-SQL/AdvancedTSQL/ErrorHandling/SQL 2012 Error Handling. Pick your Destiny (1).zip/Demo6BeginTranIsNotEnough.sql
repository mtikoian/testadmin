/*
** Joes2Pros.com 2012
** All Rights Reserved.
*/
USE JProCo
GO

------------------------BEGIN TRAN withOUT TRY CATCH (it's not enough)
UPDATE [Grant] SET Amount = 18100 WHERE GrantID = '003'
UPDATE Employee SET LatestGrantActivity = '1/1/2000' WHERE EmpID = 7


EXEC AddGrantAmount '003', NULL

--Yea Yea, what if you put this error in an explicit transaction?
ALTER PROC AddGrantAmount @GrantID char(3), @MoreAmount Money 
AS
	BEGIN TRAN
	DECLARE @GrantINT INT
	SET @GrantINT = CAST(@GrantID as INT)
	UPDATE [Grant] SET Amount = Amount + @MoreAmount
	WHERE GrantID = @GrantINT 
	RAISERROR('Increased %i Grant records', 10, 1, @@ROWCOUNT	)
	
	UPDATE em SET Em.LatestGrantActivity = CURRENT_TIMESTAMP
	FROM Employee as em INNER JOIN [Grant] as gr
	ON em.EmpID = gr.EmpID
	WHERE GrantID = @GrantID
	RAISERROR('Updated %i Employee records', 10, 1, @@ROWCOUNT	)
	COMMIT TRAN
GO	



--Run and test
UPDATE [Grant] SET Amount = 18100 WHERE GrantID = '003'
UPDATE Employee SET LatestGrantActivity = '1/1/2000' WHERE EmpID = 7

EXEC AddGrantAmount '003', NULL

--Check data
SELECT * 
FROM [Grant]
WHERE GrantID = '003'

SELECT *
FROM Employee
Where EmpID = 7









------------------BEGIN TRAN with TRY CATCH (Explicit Tran with Structured Error handling)
UPDATE [Grant] SET Amount = 18100 WHERE GrantID = '003'
UPDATE Employee SET LatestGrantActivity = '1/1/2000' WHERE EmpID = 7


ALTER PROC AddGrantAmount @GrantID char(3), @MoreAmount Money 
AS
 BEGIN TRY
	BEGIN TRAN
	DECLARE @GrantINT INT
	SET @GrantINT = CAST(@GrantID as INT)
	UPDATE [Grant] SET Amount = Amount + @MoreAmount
	WHERE GrantID = @GrantINT 
	RAISERROR('Increased %i Grant records',10,1,@@ROWCOUNT	)
	
	UPDATE em SET Em.LatestGrantActivity = CURRENT_TIMESTAMP
	FROM Employee as em INNER JOIN [Grant] as gr
	ON em.EmpID = gr.EmpID
	WHERE GrantID = @GrantID
	RAISERROR('Updated %i Employee records',10,1,@@ROWCOUNT	)
	COMMIT TRAN
  END TRY
  BEGIN CATCH
	ROLLBACK TRAN
  END CATCH	
GO

--Run and test
EXEC AddGrantAmount '003', NULL



--Check data
SELECT * 
FROM [Grant]
WHERE GrantID = '003'

SELECT *
FROM Employee
Where EmpID = 7