/*
** Joes2Pros.com 2012
** All Rights Reserved.
*/
USE JProCo
GO
	
--Roll back to $18,100 and the year 2000
UPDATE [Grant] SET Amount = 18100 WHERE GrantID = '003'
UPDATE Employee SET LatestGrantActivity = '1/1/2000' WHERE EmpID = 7


EXEC AddGrantAmount '003', NULL --SQL picks the error action

--Check is there were updates
SELECT *
FROM [Grant] 
WHERE GrantID = '003' --Still $18,100

SELECT *
FROM Employee 
WHERE EmpID = 7 --Yikes! Updated to today????













--Roll back to $18,100 and the year 2000
UPDATE [Grant] SET Amount = 18100 WHERE GrantID = '003'
UPDATE Employee SET LatestGrantActivity = '1/1/2000' WHERE EmpID = 7

SET XACT_ABORT ON;
EXEC AddGrantAmount '003', NULL --XACT_ABORT ON - Errors (11+) Always gets Batch Abortion


--Check is there were updates
SELECT *
FROM [Grant] 
WHERE GrantID = '003' --Still $18,100

SELECT *
FROM Employee 
WHERE EmpID = 7 --Update is Still yr 2000












SET XACT_ABORT OFF;
EXEC AddGrantAmount '003', NULL --XACT_ABORT OFF - SQL picks the error action


--Check is there were updates
SELECT *
FROM [Grant] 
WHERE GrantID = '003' --Still $18,100

SELECT *
FROM Employee 
WHERE EmpID = 7 --Yikes! Updated to today????