/*
** Joes2Pros.com 2012
** All Rights Reserved.
*/
USE JProCo
GO

SELECT * FROM [Grant] WHERE GrantID = '001'

UPDATE [Grant] SET GrantName = '93 Per-cents %% team'
WHERE GrantID = '001' --Works fine

UPDATE [Grant] SET GrantName = NULL
WHERE GrantID = '001' --Msg 515 Cant insert null into non null column



--Try runs but not the catch.
BEGIN TRY
	UPDATE [Grant] SET GrantName = '94 Per-cents %% team'
	WHERE GrantID = '001'
END TRY
BEGIN CATCH
	PRINT 'No Change was made'
END CATCH


SELECT * FROM [Grant] WHERE GrantID = '001'


--This will fire off the Catch block
BEGIN TRY
	UPDATE [Grant] SET GrantName = null --Change this to make an error
	WHERE GrantID = '001'
END TRY
BEGIN CATCH
	PRINT 'No Change was made'
END CATCH


SELECT * FROM [Grant] WHERE GrantID = '001'












----Severity of 11 or higher will fire off.
BEGIN TRY
	RAISERROR('Bad Stuff', 16, 1)
END TRY
BEGIN CATCH
	PRINT 'Catch Ran'
	PRINT Error_Message() 
	PRINT Error_Severity() --Add this
END CATCH




BEGIN TRY
	RAISERROR('Sort of Bad Stuff', 11, 1)
END TRY
BEGIN CATCH
	PRINT 'Catch Ran'
	PRINT Error_Message() 
	PRINT Error_Severity() --Add this
END CATCH




BEGIN TRY
	RAISERROR('1 Millon rows effected',10,1)
END TRY
BEGIN CATCH
	PRINT 'Catch Ran'
	PRINT Error_Message() 
	PRINT Error_Severity() --Add this
END CATCH