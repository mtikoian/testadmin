/*
** Joes2Pros.com 2012
** All Rights Reserved.
*/
USE JProCo
GO

--Level 11 and higher is an error. 10 and below is a message
RAISERROR('Hello',16,1)
RAISERROR('Hello',10,1)


--Notice Grant 005 is worth 22180.00
SELECT * FROM [Grant] 
GO

--Proc that adds to the Grant Amount
ALTER PROC AddGrantAmount @GrantID char(3), @MoreAmount Money
AS
	DECLARE @GrantINT INT
	SET @GrantINT = CAST(@GrantID AS INT)
	UPDATE [Grant] SET Amount = Amount + @MoreAmount
	WHERE GrantID = @GrantINT
GO


--Opps! Looks like you can take money away from Charity
EXEC AddGrantAmount '005', -80 
SELECT * FROM [Grant] WHERE GrantID = '005'
EXEC AddGrantAmount '005', 80 
SELECT * FROM [Grant] WHERE GrantID = '005'


--Only Allow Grants to go up in Value
ALTER PROC AddGrantAmount @GrantID char(3), @MoreAmount Money
AS
	DECLARE @GrantINT INT
	SET @GrantINT = CAST(@GrantID AS INT)
	IF (@MoreAmount < 0)
	BEGIN
	RAISERROR('Grants must go up in value', 16, 1)
	END
	UPDATE [Grant] SET Amount = Amount + @MoreAmount
	WHERE GrantID = @GrantINT
GO

---More below
















EXEC AddGrantAmount '005', -80 
EXEC AddGrantAmount '005', 80 
EXEC AddGrantAmount '005', 'Eighty'
--Comments below










EXEC AddGrantAmount '005', -80 --User supplied Error
EXEC AddGrantAmount '005', 80 --Works
EXEC AddGrantAmount '005', 'Eighty' --does not Work
GO


--Give all executions a informational message
ALTER PROC AddGrantAmount @GrantID char(3), @MoreAmount Money
AS
	DECLARE @GrantINT INT
	SET @GrantINT = CAST(@GrantID AS INT)
	IF (@MoreAmount < 0)
	BEGIN
	RAISERROR('Grants must go up in value',16,1)
	END
	UPDATE [Grant] SET Amount = Amount + @MoreAmount
	WHERE GrantID = @GrantINT
	RAISERROR('Updated %i Grant(s) in the Grant table',10,1,@@RowCount) --Added this
GO


EXEC AddGrantAmount '001', 80
EXEC AddGrantAmount '000', 80