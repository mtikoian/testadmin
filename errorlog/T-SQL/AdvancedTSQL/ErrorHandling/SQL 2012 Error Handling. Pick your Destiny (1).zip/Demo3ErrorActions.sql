/*
** Joes2Pros.com 2012
** All Rights Reserved.
*/
USE JProCo
GO

--------------------Statement Termination and Batch level Termination
SELECT * FROM Employee 
SELECT * FROM [Grant] 
GO

SELECT *
FROM [Grant] 
WHERE GrantID = '003' --$18,100

SELECT *
FROM Employee 
WHERE EmpID = 7 --The latest is the year 2000


--If an employee finds a grant then update Their "LatestGrantActivity" to today
ALTER PROC AddGrantAmount @GrantID char(3), @MoreAmount Money
AS
	DECLARE @GrantINT INT
	SET @GrantINT = CAST(@GrantID AS INT)
	IF (@MoreAmount < 0)
	BEGIN
	RAISERROR('Grants must go up in value',16,1)
	END
	UPDATE [Grant] SET Amount = Amount + @MoreAmount
	WHERE GrantID = @GrantINT
	RAISERROR('Updated %i Charity in the Grant table',10,1,@@RowCount)
	
	UPDATE em SET Em.LatestGrantActivity = CURRENT_TIMESTAMP
	FROM Employee as em INNER JOIN [Grant] as gr
	ON em.EmpID = gr.EmpID
	WHERE GrantID = @GrantID
	RAISERROR('Updated %i Employee records',10,1, @@ROWCOUNT)
GO

SELECT *
FROM [Grant] 
WHERE GrantID = '003' --$18,100

SELECT *
FROM Employee 
WHERE EmpID = 7 --The latest is the year 2000


------Example Runs fine
--Take the $18,100 grant and add $1000 to it
EXEC AddGrantAmount '003', 1000
--Now $19,100 and todays date
SELECT *
FROM [Grant] 
WHERE GrantID = '003' --$19,100

SELECT *
FROM Employee 
WHERE EmpID = 7 --The latest is the year (updated from 2000)



--Roll back to $18,100 and the year 2000
UPDATE [Grant] SET Amount = 18100 WHERE GrantID = '003'
UPDATE Employee SET LatestGrantActivity = '1/1/2000' WHERE EmpID = 7








------Example causes error with what kind of action?
EXEC AddGrantAmount '003', 'One Thousand' 

--Check is there were updates
SELECT *
FROM [Grant] 
WHERE GrantID = '003' --Still $18,100

SELECT *
FROM Employee 
WHERE EmpID = 7 --Update is Still yr 2000










------Example causes error with what kind of action?
EXEC AddGrantAmount '003', NULL



SELECT *
FROM [Grant] 
WHERE GrantID = '003' 

SELECT *
FROM Employee 
WHERE EmpID = 7 
