SET NOCOUNT ON
USE Northgale
go
IF object_id('static_search_6') IS NULL EXEC ('CREATE PROCEDURE static_search_6 AS PRINT 1')
go
ALTER PROCEDURE static_search_6
              @orderid     int          = NULL,
              @status      char(1)      = NULL,
              @fromdate    date         = NULL,
              @todate      date         = NULL,
              @custid      nchar(5)     = NULL,
              @custname    nvarchar(40) = NULL,
              @city        nvarchar(25) = NULL,
              @region      nvarchar(15) = NULL,
              @prodid      int          = NULL,
              @prodname    nvarchar(40) = NULL AS

IF @orderid IS NOT NULL
BEGIN
   SELECT o.OrderID, o.OrderDate, od.UnitPrice, od.Quantity,
          c.CustomerID, c.CustomerName, c.Address, c.City, c.Region,
          c.PostalCode, c.Country, c.Phone, p.ProductID,
          p.ProductName, p.UnitsInStock, p.UnitsOnOrder, o.EmployeeID
   FROM   Orders o
   JOIN   [Order Details] od ON o.OrderID = od.OrderID
   JOIN   Customers c ON o.CustomerID = c.CustomerID
   JOIN   Products p ON p.ProductID = od.ProductID
   WHERE  o.OrderID = @orderid
     AND  (o.Status = @status OR @status IS NULL)
     AND  (o.OrderDate >= @fromdate OR @fromdate IS NULL)
     AND  (o.OrderDate <= @todate OR @todate IS NULL)
     AND  (o.CustomerID = @custid OR @custid IS NULL)
     AND  (c.CustomerName LIKE @custname + '%' OR @custname IS NULL)
     AND  (c.City = @city OR @city IS NULL)
     AND  (c.Region = @region OR @region IS NULL)
     AND  (od.ProductID = @prodid OR @prodid IS NULL)
     AND  (p.ProductName LIKE @prodname + '%' OR @prodname IS NULL)
END
ELSE IF @custid IS NOT NULL AND
     datediff(DAY, @fromdate, getdate()) <= 7
BEGIN
   SELECT o.OrderID, o.OrderDate, od.UnitPrice, od.Quantity,
          c.CustomerID, c.CustomerName, c.Address, c.City, c.Region,
          c.PostalCode, c.Country, c.Phone, p.ProductID,
          p.ProductName, p.UnitsInStock, p.UnitsOnOrder, o.EmployeeID
   FROM   Orders o
   JOIN   [Order Details] od ON o.OrderID = od.OrderID
   JOIN   Customers c ON o.CustomerID = c.CustomerID
   JOIN   Products p ON p.ProductID = od.ProductID
   WHERE  o.CustomerID = @custid
     AND  o.OrderDate >= @fromdate
     AND  (o.OrderDate <= @todate OR @todate IS NULL)
     AND  (o.Status = @status OR @status IS NULL)
     AND  (c.CustomerName LIKE @custname + '%' OR @custname IS NULL)
     AND  (c.City = @city OR @city IS NULL)
     AND  (c.Region = @region OR @region IS NULL)
     AND  (od.ProductID = @prodid OR @prodid IS NULL)
     AND  (p.ProductName LIKE @prodname + '%' OR @prodname IS NULL)
END
ELSE
BEGIN
   SELECT o.OrderID, o.OrderDate, od.UnitPrice, od.Quantity,
          c.CustomerID, c.CustomerName, c.Address, c.City, c.Region,
          c.PostalCode, c.Country, c.Phone, p.ProductID,
          p.ProductName, p.UnitsInStock, p.UnitsOnOrder, o.EmployeeID
   FROM   Orders o
   JOIN   [Order Details] od ON o.OrderID = od.OrderID
   JOIN   Customers c ON o.CustomerID = c.CustomerID
   JOIN   Products p ON p.ProductID = od.ProductID
   WHERE  (o.Status = @status OR @status IS NULL)
     AND  (o.OrderDate >= @fromdate OR @fromdate IS NULL)
     AND  (o.OrderDate <= @todate OR @todate IS NULL)
     AND  (o.CustomerID = @custid OR @custid IS NULL)
     AND  (c.CustomerName LIKE @custname + '%' OR @custname IS NULL)
     AND  (c.City = @city OR @city IS NULL)
     AND  (c.Region = @region OR @region IS NULL)
     AND  (od.ProductID = @prodid OR @prodid IS NULL)
     AND  (p.ProductName LIKE @prodname + '%' OR @prodname IS NULL)
   ORDER  BY o.OrderID
   OPTION (RECOMPILE)
END
go
-- First run this to get a plan in the cache.
EXEC static_search_6 @orderid = 11000
go
-- Enable "Actual Execution Plan" och and compare the plans. Pay 
-- attention to that they are different.
DECLARE @d2 datetime2(3) = sysdatetime()
DECLARE @today date = convert(date, sysdatetime())
EXEC static_search_6 @custid = 'ERNTC', @fromdate = @today
EXEC static_search_4 @custid = 'ERNTC', @fromdate = @today
go
