USE Northgale
go
SET NOCOUNT ON
-- SELECT * FROM sys.objects
-- SELECT * FROM sys.databases
go
PRINT 'Searching for ERNTC in a single day: '
go
DECLARE @d2 datetime2(3) = sysdatetime()
EXEC static_search_4 @custid = 'ERNTC',
                     @fromdate = '19980218', @todate = '19980218'
PRINT 'static_search_4: ' + ltrim(str(datediff(ms, @d2, sysdatetime()))) + ' ms.'
go
DECLARE @d2 datetime2(3) = sysdatetime()
EXEC dynamic_search_1 @custid = 'ERNTC',
                      @fromdate = '19980218', @todate = '19980218'
PRINT 'dynamic_search_1: ' + ltrim(str(datediff(ms, @d2, sysdatetime()))) + ' ms.'
go
DECLARE @d2 datetime2(3) = sysdatetime()
EXEC dynamic_search_bad @custid = 'ERNTC',
                      @fromdate = '19980218', @todate = '19980218'
PRINT 'dynamic_search_bad: ' + ltrim(str(datediff(ms, @d2, sysdatetime()))) + ' ms.'
go

PRINT ''
PRINT 'Searching for BOLSR in a full year: '
DECLARE @d2 datetime2(3) = sysdatetime()
EXEC static_search_4 @custid = 'BOLSR',
                     @fromdate = '19980101', @todate = '19981231'
PRINT 'static_search_4: ' + ltrim(str(datediff(ms, @d2, sysdatetime()))) + ' ms.'
go
DECLARE @d2 datetime2(3) = sysdatetime()
EXEC dynamic_search_1 @custid = 'BOLSR',
                      @fromdate = '19980101', @todate = '19981231'
PRINT 'dynamic_search_1: ' + ltrim(str(datediff(ms, @d2, sysdatetime()))) + ' ms.'
go
DECLARE @d2 datetime2(3) = sysdatetime()
EXEC dynamic_search_bad @custid = 'BOLSR',
                      @fromdate = '19980101', @todate = '19981231'
PRINT 'dynamic_search_bad: ' + ltrim(str(datediff(ms, @d2, sysdatetime()))) + ' ms.'
go
PRINT ''
PRINT 'Searching for error orders:'
DECLARE @d2 datetime2(3) = sysdatetime()
EXEC static_search_4 @status = 'E'
PRINT 'static_search_4: ' + ltrim(str(datediff(ms, @d2, sysdatetime()))) + ' ms.'
go
DECLARE @d2 datetime2(3) = sysdatetime()
EXEC dynamic_search_1 @status = 'E'
PRINT 'dynamic_search_1: ' + ltrim(str(datediff(ms, @d2, sysdatetime()))) + ' ms.'
go
DECLARE @d2 datetime2(3) = sysdatetime()
EXEC dynamic_search_bad @status = 'E'
PRINT 'dynamic_search_bad: ' + ltrim(str(datediff(ms, @d2, sysdatetime()))) + ' ms.'
go
