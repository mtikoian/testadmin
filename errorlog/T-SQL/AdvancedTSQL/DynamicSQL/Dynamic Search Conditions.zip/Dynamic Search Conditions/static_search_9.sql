SET NOCOUNT ON
USE Northgale
go
IF object_id('static_search_9') IS NULL EXEC ('CREATE PROCEDURE static_search_9 AS PRINT 1')
go
ALTER PROCEDURE static_search_9
              @orderid     int          = NULL,
              @status      char(1)      = NULL,
              @fromdate    date         = NULL,
              @todate      date         = NULL,
              @custid      nchar(5)     = NULL,
              @custname    nvarchar(40) = NULL,
              @city        nvarchar(25) = NULL,
              @region      nvarchar(15) = NULL,
              @prodid      int          = NULL,
              @prodname    nvarchar(40) = NULL,
              @employeetbl intlist_tbltype READONLY AS

DECLARE @cnt      int,
        @emp1     int,
        @emp2     int,
        @emp3     int,
        @hastable bit = 0

SELECT @cnt = (SELECT COUNT(*) FROM @employeetbl)

IF @cnt BETWEEN 1 AND 3
BEGIN
   SELECT @emp1 = MIN(val) FROM @employeetbl
   SELECT @emp2 = MIN(val) FROM @employeetbl WHERE val > @emp1
   SELECT @emp3 = MIN(val) FROM @employeetbl WHERE val > @emp2
END
ELSE IF @cnt > 3
   SELECT @hastable = 1


SELECT o.OrderID, o.OrderDate, od.UnitPrice, od.Quantity,
       c.CustomerID, c.CustomerName, c.Address, c.City, c.Region,
       c.PostalCode, c.Country, c.Phone, p.ProductID,
       p.ProductName, p.UnitsInStock, p.UnitsOnOrder, o.EmployeeID
FROM   Orders o
JOIN   [Order Details] od ON o.OrderID = od.OrderID
JOIN   Customers c ON o.CustomerID = c.CustomerID
JOIN   Products p ON p.ProductID = od.ProductID
WHERE  (o.OrderID = @orderid OR @orderid IS NULL)
  AND  (o.Status = @status OR @status IS NULL)
  AND  (o.OrderDate >= @fromdate OR @fromdate IS NULL)
  AND  (o.OrderDate <= @todate OR @todate IS NULL)
  AND  (o.CustomerID = @custid OR @custid IS NULL)
  AND  (c.CustomerName LIKE @custname + '%' OR @custname IS NULL)
  AND  (c.City = @city OR @city IS NULL)
  AND  (c.Region = @region OR @region IS NULL)
  AND  (od.ProductID = @prodid OR @prodid IS NULL)
  AND  (p.ProductName LIKE @prodname + '%' OR @prodname IS NULL)

  AND  (o.EmployeeID IN (@emp1, @emp2, @emp3) OR @emp1 IS NULL)

  AND  (o.EmployeeID IN (SELECT val FROM @employeetbl) OR 
        @hastable = 0)
ORDER  BY o.OrderID
OPTION (RECOMPILE)
go
-- Compare the plans for #8 (where the optimizer only knows the number
-- or rows in the TVP) with #9. 901, 902 and 903 have in total 64 orders
-- while 304 has several thousand.
DECLARE @tbl intlist_tbltype
INSERT @tbl (val) VALUES (901), (902), (903)
--INSERT @tbl (val) VALUES (304)
EXEC static_search_8 @employeetbl = @tbl
EXEC static_search_9 @employeetbl = @tbl


