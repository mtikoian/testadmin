SET NOCOUNT ON
USE Northgale
go
IF object_id('static_search_8') IS NULL EXEC ('CREATE PROCEDURE static_search_8 AS PRINT 1')
go
ALTER PROCEDURE static_search_8
              @orderid     int          = NULL,
              @status      char(1)      = NULL,
              @fromdate    date         = NULL,
              @todate      date         = NULL,
              @custid      nchar(5)     = NULL,
              @custname    nvarchar(40) = NULL,
              @city        nvarchar(25) = NULL,
              @region      nvarchar(15) = NULL,
              @prodid      int          = NULL,
              @prodname    nvarchar(40) = NULL,
              -- Extra parameters for CSV och TVP.
              @employeestr nvarchar(MAX)= NULL,
              @employeetbl intlist_tbltype READONLY AS

DECLARE @hastable bit = CASE WHEN EXISTS (SELECT * FROM @employeetbl)
                             THEN 1
                             ELSE 0
                        END

SELECT o.OrderID, o.OrderDate, od.UnitPrice, od.Quantity,
       c.CustomerID, c.CustomerName, c.Address, c.City, c.Region,
       c.PostalCode, c.Country, c.Phone, p.ProductID,
       p.ProductName, p.UnitsInStock, p.UnitsOnOrder, o.EmployeeID
FROM   Orders o
JOIN   [Order Details] od ON o.OrderID = od.OrderID
JOIN   Customers c ON o.CustomerID = c.CustomerID
JOIN   Products p ON p.ProductID = od.ProductID
WHERE  (o.OrderID = @orderid OR @orderid IS NULL)
  AND  (o.Status = @status OR @status IS NULL)
  AND  (o.OrderDate >= @fromdate OR @fromdate IS NULL)
  AND  (o.OrderDate <= @todate OR @todate IS NULL)
  AND  (o.CustomerID = @custid OR @custid IS NULL)
  AND  (c.CustomerName LIKE @custname + '%' OR @custname IS NULL)
  AND  (c.City = @city OR @city IS NULL)
  AND  (c.Region = @region OR @region IS NULL)
  AND  (od.ProductID = @prodid OR @prodid IS NULL)
  AND  (p.ProductName LIKE @prodname + '%' OR @prodname IS NULL)

  -- Extra conditions for the new parameters.
  AND  (o.EmployeeID IN (SELECT n FROM intlist_to_tbl(@employeestr)) OR
        @employeestr IS NULL)

  AND  (o.EmployeeID IN (SELECT val FROM @employeetbl) OR 
       @hastable = 0)

ORDER  BY o.OrderID
OPTION (RECOMPILE)
go
-- Test executions.
EXEC static_search_8 @employeestr = '402,109,207', @custid = 'PERTH'

DECLARE @tbl intlist_tbltype
INSERT @tbl (val) VALUES(402), (109), (207)
EXEC static_search_8 @employeetbl = @tbl, @custid = 'PERTH'
