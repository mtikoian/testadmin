SET NOCOUNT ON
USE Northgale
go
IF object_id('static_search_10') IS NULL EXEC ('CREATE PROCEDURE static_search_10 AS PRINT 1')
go
ALTER PROCEDURE static_search_10
              @orderid     int          = NULL,
              @status      char(1)      = NULL,
              @fromdate    date         = NULL,
              @todate      date         = NULL,
              @custid      nchar(5)     = NULL,
              @custname    nvarchar(40) = NULL,
              @city        nvarchar(25) = NULL,
              @region      nvarchar(15) = NULL,
              @prodid      int          = NULL,
              @prodname    nvarchar(40) = NULL,
              @suppl_city  nvarchar(15) = NULL AS

SELECT o.OrderID, o.OrderDate, od.UnitPrice, od.Quantity,
       c.CustomerID, c.CustomerName, c.Address, c.City, c.Region,
       c.PostalCode, c.Country, c.Phone, p.ProductID,
       p.ProductName, p.UnitsInStock, p.UnitsOnOrder, o.EmployeeID
FROM   Orders o
JOIN   [Order Details] od ON o.OrderID = od.OrderID
JOIN   Customers c ON o.CustomerID = c.CustomerID
JOIN   Products p ON p.ProductID = od.ProductID
WHERE  (o.OrderID = @orderid OR @orderid IS NULL)
  AND  (o.Status = @status OR @status IS NULL)
  AND  (o.OrderDate >= @fromdate OR @fromdate IS NULL)
  AND  (o.OrderDate <= @todate OR @todate IS NULL)
  AND  (o.CustomerID = @custid OR @custid IS NULL)
  AND  (c.CustomerName LIKE @custname + '%' OR @custname IS NULL)
  AND  (c.City = @city OR @city IS NULL)
  AND  (c.Region = @region OR @region IS NULL)
  AND  (od.ProductID = @prodid OR @prodid IS NULL)
  AND  (p.ProductName LIKE @prodname + '%' OR @prodname IS NULL)
  AND  (@suppl_city IS NULL OR
        EXISTS (SELECT *
                FROM   Suppliers s
                WHERE  s.SupplierID = p.SupplierID
                  AND  s.City       = @suppl_city))
ORDER  BY o.OrderID
--OPTION (RECOMPILE) 
go                   
-- Please enabling display of query plans.
SET STATISTICS IO ON
go
DECLARE @d2 datetime2(3) = sysdatetime()
EXEC static_search_10 @city = 'Paris'
PRINT 'Searching on @city ' + ltrim(str(datediff(ms, @d2, sysdatetime()))) + ' ms.'
go
DECLARE @d2 datetime2(3) = sysdatetime()
EXEC static_search_10 @suppl_city = 'Paris'
PRINT 'Searching on @suppl_city ' + ltrim(str(datediff(ms, @d2, sysdatetime()))) + ' ms.'
go
SET STATISTICS IO OFF
