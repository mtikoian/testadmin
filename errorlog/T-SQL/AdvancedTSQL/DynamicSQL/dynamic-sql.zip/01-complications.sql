/*
Dynamic SQL

Jeremiah Peschka, Brent Ozar Unlimited
v1.0 - January 2014

(C) 2014, Brent Ozar Unlimited. 
See http://BrentOzar.com/go/eula for the End User Licensing Agreement.
*/

USE AdventureWorks2012_CS;
GO

DBCC FREEPROCCACHE
GO

/* Let's look at the effect that string concatenation has on the plan cache */
DECLARE @first INT, @next INT;

DECLARE c CURSOR FOR 
    SELECT number, number +1 AS NumberPlus1
    FROM master..spt_values
    WHERE type = 'P' AND number < 100;
            

OPEN c;

FETCH NEXT FROM c 
INTO @first, @next;

WHILE @@FETCH_STATUS = 0
BEGIN
    DECLARE @sql VARCHAR(MAX);

    SET @sql = N'
    SELECT *
    FROM HumanResources.Employee
    WHERE BusinessEntityID IN (' + 
      CONVERT(VARCHAR, @first) + ', ' +
      CONVERT(VARCHAR, @next) + ')';

    EXEC(@sql);
    
    FETCH NEXT FROM c 
    INTO @first, @next; 
END

CLOSE c;
DEALLOCATE c;














/* What did that do to the plan cache? */
SELECT  ecp.objtype,
        p.text
FROM    sys.dm_exec_cached_plans AS ecp
        CROSS APPLY (SELECT * FROM sys.dm_exec_sql_text(ecp.plan_handle)) AS p
WHERE   p.text LIKE '%HumanResources%'
        AND p.text NOT LIKE '%sys.dm_exec_cached_plans%'
OPTION (RECOMPILE) ;











DBCC FREEPROCCACHE;
GO










/* Here's one way to fix that. We'll get to a better one soon. */
DECLARE @first INT, @next INT;

DECLARE c CURSOR FOR 
    SELECT number, number +1 AS NumberPlus1
    FROM master..spt_values
    WHERE type = 'P' AND number < 100;
            

OPEN c;

FETCH NEXT FROM c 
INTO @first, @next;

WHILE @@FETCH_STATUS = 0
BEGIN
    DECLARE @sql VARCHAR(MAX);

    SET @sql = N'DECLARE @first INT = ' + CAST(@first AS VARCHAR(50)) + '
    DECLARE @next INT = ' + CAST(@next AS VARCHAR(50)) + '
    SELECT *
    FROM HumanResources.Employee
    WHERE BusinessEntityID IN (@first, @next)';

    EXEC(@sql);
    
    FETCH NEXT FROM c 
    INTO @first, @next; 
END

CLOSE c;
DEALLOCATE c;














/* A careful examination of the plan cache will show that we've completely 
   failed to make things better. 
 */
SELECT  ecp.objtype,
        p.text
FROM    sys.dm_exec_cached_plans AS ecp
        CROSS APPLY (SELECT * FROM sys.dm_exec_sql_text(ecp.plan_handle)) AS p
WHERE   p.text LIKE '%HumanResources%'
        AND p.text NOT LIKE '%sys.dm_exec_cached_plans%'
OPTION (RECOMPILE) ;












DBCC FREEPROCCACHE;
GO

















/* By switching to sp_executesql we can finally get plan re-use! */
DECLARE @first INT, @next INT;

DECLARE c CURSOR FOR 
    SELECT number, number +1 AS NumberPlus1
    FROM master..spt_values
    WHERE type = 'P' AND number < 100;
            

OPEN c;

FETCH NEXT FROM c 
INTO @first, @next;

WHILE @@FETCH_STATUS = 0
BEGIN
    DECLARE @sql NVARCHAR(MAX);

    SET @sql = N'
    SELECT *
    FROM HumanResources.Employee
    WHERE BusinessEntityID IN (@first, @next)';

    EXEC sp_executesql @sql, N'@first INT, @next INT', @first, @next;
    
    FETCH NEXT FROM c 
    INTO @first, @next; 
END

CLOSE c;
DEALLOCATE c;














SELECT  ecp.objtype,
        p.text
FROM    sys.dm_exec_cached_plans AS ecp
        CROSS APPLY (SELECT * FROM sys.dm_exec_sql_text(ecp.plan_handle)) AS p
WHERE   p.text LIKE '%HumanResources%'
        AND p.text NOT LIKE '%sys.dm_exec_cached_plans%'
OPTION (RECOMPILE) ;












DBCC FREEPROCCACHE;
GO

/* END OF DEMO! */
