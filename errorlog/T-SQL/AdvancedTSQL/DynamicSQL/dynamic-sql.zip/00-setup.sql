USE AdventureWorks2012_CS;
GO

/*
Dynamic SQL Support Files

Jeremiah Peschka, Brent Ozar Unlimited
v1.0 - January 2014


Assumptions:
You are using SQL Server 2012 or SQL Server 2014.
You are using a copy of the AdventureWorks sample database.
Sample databases can be obtained from Microsoft.
See our blog post http://www.brentozar.com/archive/2013/11/getting-started-with-sql-server-sample-databases/ for more information.


(C) 2014, Brent Ozar Unlimited. 
See http://BrentOzar.com/go/eula for the End User Licensing Agreement.
*/

/* For dealing with dynamic PIVOTs, amongst other things, a Calendar table
   is an absolute must
 */

IF OBJECT_ID('dbo.Calendar') IS NOT NULL 
  DROP TABLE dbo.Calendar ;
GO

CREATE TABLE [dbo].[Calendar]
  (
   [Date] datetime NOT NULL,
   [FirstDayOfMonth] datetime NULL,
   [LastDayOfMonth] datetime NULL,
   [IsWeekday] bit NULL,
   [IsHoliday] bit NULL,
   [Y] smallint NULL,
   [FY] smallint NULL,
   [Q] tinyint NULL,
   [M] tinyint NULL,
   [D] tinyint NULL,
   [DW] tinyint NULL,
   [monthname] varchar(9) COLLATE SQL_Latin1_General_CP1_CI_AS
                          NULL,
   [dayname] varchar(9) COLLATE SQL_Latin1_General_CP1_CI_AS
                        NULL,
   [W] tinyint NULL,
   [Number] int IDENTITY(1, 1)
                NOT NULL,
   PRIMARY KEY NONCLUSTERED ([Date] ASC)
    WITH (PAD_INDEX = OFF, FILLFACTOR = 100, IGNORE_DUP_KEY = OFF,
          STATISTICS_NORECOMPUTE = OFF, ALLOW_ROW_LOCKS = ON,
          ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
  )
ON
  [PRIMARY] ;
GO

/* You'll also probably find yourself needing a numbers table... */
IF OBJECT_ID('dbo.Nums') IS NOT NULL 
  DROP TABLE dbo.Nums ;
GO

CREATE TABLE [dbo].[Nums]
  (
   [n] int NOT NULL,
   PRIMARY KEY CLUSTERED ([n] ASC)
    WITH (PAD_INDEX = OFF, FILLFACTOR = 100, IGNORE_DUP_KEY = OFF,
          STATISTICS_NORECOMPUTE = OFF, ALLOW_ROW_LOCKS = ON,
          ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
  )
ON
  [PRIMARY] ;
GO

/* fill your numbers table, this takes about 15 seconds */
DECLARE @max AS INT,
  @rc AS INT ;
SET @max = 1000000 ;
SET @rc = 1 ;

INSERT  INTO dbo.Nums (n)
VALUES  (1) ;
WHILE @rc * 2 <= @max
  BEGIN
    INSERT  INTO dbo.Nums (n)
            SELECT  n + @rc
            FROM    dbo.Nums ;
    SET @rc = @rc * 2 ;
  END

INSERT  INTO dbo.Nums (n)
        SELECT  n + @rc
        FROM    dbo.Nums
        WHERE   n + @rc <= @max ;
GO

/* It is also possible to use the following function to create a dynamic 
   numbers table, if it isn't possible or feasible to create a static table
   Can generate 2^2^n rows, where n is the number of levels of recursion.
   five levels will yield up to 4,294,967,296 rows
 */
IF OBJECT_ID('dbo.fn_nums') IS NOT NULL 
  DROP FUNCTION db.fn_nums ;
GO

CREATE FUNCTION dbo.fn_nums (@n AS BIGINT)
RETURNS TABLE
AS
RETURN
  WITH  L0
          AS (SELECT  1 AS c
              UNION ALL
              SELECT  1
             ) ,
        L1
          AS (SELECT  1 AS c
              FROM    L0 AS A,
                      L0 AS B
             ) ,
        L2
          AS (SELECT  1 AS c
              FROM    L1 AS A,
                      L1 AS B
             ) ,
        L3
          AS (SELECT  1 AS c
              FROM    L2 AS A,
                      L2 AS B
             ) ,
        L4
          AS (SELECT  1 AS c
              FROM    L3 AS A,
                      L3 AS B
             ) ,
        L5
          AS (SELECT  1 AS c
              FROM    L4 AS A,
                      L4 AS B
             ) ,
        Nums
          AS (SELECT  ROW_NUMBER() OVER (ORDER BY c) AS n
              FROM    L5
             )
  SELECT  n
  FROM    Nums
  WHERE   n <= @n ;
GO


/* Now, to fill the table... */
TRUNCATE TABLE Calendar ;

INSERT  INTO Calendar (Date)
        SELECT  DATEADD(DAY, n, '19990101')
        FROM    Nums
        WHERE   n <= 10597
        ORDER BY n ;

UPDATE  dbo.Calendar
SET     IsWeekday = CASE WHEN DATEPART(DW, Date) IN (1, 7) THEN 0
                         ELSE 1
                    END,
        IsHoliday = 0,
        Y = YEAR(Date),
        FY = YEAR(Date), 
    /* 
    -- if our fiscal year 
    -- starts on May 1st: 
    FY = CASE  
        WHEN MONTH(date) < 5 
        THEN YEAR(date)-1  
        ELSE YEAR(date) END, 
    */  Q = CASE WHEN MONTH(Date) <= 3 THEN 1
                 WHEN MONTH(Date) <= 6 THEN 2
                 WHEN MONTH(Date) <= 9 THEN 3
                 ELSE 4
            END,
        M = MONTH(Date),
        D = DAY(Date),
        DW = DATEPART(DW, Date),
        monthname = DATENAME(MONTH, Date),
        dayname = DATENAME(DW, Date),
        W = DATEPART(WK, Date) ;

UPDATE  Calendar
SET     FirstDayOfMonth = DATEADD(mm, DATEDIFF(mm, 0, Date), 0),
        LastDayOfMonth = DATEADD(ss, -1,
                                 DATEADD(mm, 1,
                                         DATEADD(mm, DATEDIFF(mm, 0, Date), 0))) ;

-- New Year's Day - easy 
 
UPDATE  Calendar
SET     IsHoliday = 1
WHERE   M = 1
        AND D = 1 
 
-- Memorial Day - last Monday in May 
 
UPDATE  Calendar
SET     IsHoliday = 1
FROM    Calendar c1
WHERE   M = 5
        AND DW = 2
        AND NOT EXISTS ( SELECT 1
                         FROM   Calendar c2
                         WHERE  M = 5
                                AND DW = 2
                                AND c2.Y = c1.Y
                                AND c2.Date > c1.Date ) 
 
-- Labor Day - first Monday in September 
 
UPDATE  Calendar
SET     IsHoliday = 1
FROM    Calendar c1
WHERE   M = 9
        AND DW = 2
        AND NOT EXISTS ( SELECT 1
                         FROM   Calendar c2
                         WHERE  M = 9
                                AND DW = 2
                                AND c2.Y = c1.Y
                                AND c2.Date < c1.Date ) 
         
-- Thanksgiving Thursday - 4th Thursday in November 
 
UPDATE  Calendar
SET     IsHoliday = 1
FROM    Calendar c1
WHERE   M = 11
        AND DW = 5
        AND (SELECT COUNT(*)
             FROM   Calendar c2
             WHERE  M = 11
                    AND DW = 5
                    AND c2.Y = c1.Y
                    AND c2.Date < c1.Date
            ) = 3 
 
-- Traditionally, Thanksgiving Friday, as well 
-- as long as you haven't pre-configured any  
-- other Thursday in November to be isHoliday 
 
UPDATE  Calendar
SET     IsHoliday = 1
FROM    Calendar c1
WHERE   M = 11
        AND DW = 6
        AND EXISTS ( SELECT 1
                     FROM   Calendar c2
                     WHERE  M = 11
                            AND DW = 5
                            AND c2.Date = (c1.Date - 1)
                            AND c2.Y = c1.Y
                            AND IsHoliday = 1 ) 
 
-- Veterans' Day - easy 
-- however do this AFTER Thanksgiving calculation 
-- in case it happens to fall on a Thursday 
 
UPDATE  Calendar
SET     IsHoliday = 1
WHERE   M = 11
        AND D = 11 
 
-- Christmas Day - easy 
 
UPDATE  Calendar
SET     IsHoliday = 1
WHERE   M = 12
        AND D = 25


GO

IF OBJECT_ID('dbo.GetEasterSunday') IS NOT NULL 
  DROP FUNCTION dbo.GetEasterSunday ;
GO

CREATE FUNCTION dbo.GetEasterSunday (@Y INT)
RETURNS SMALLDATETIME
AS BEGIN 
    DECLARE @EpactCalc INT,
      @PaschalDaysCalc INT,
      @NumOfDaysToSunday INT,
      @EasterMonth INT,
      @EasterDay INT 
 
    SET @EpactCalc = (24 + 19 * (@Y % 19)) % 30 
 
    SET @PaschalDaysCalc = @EpactCalc - (@EpactCalc / 28) 
 
    SET @NumOfDaysToSunday = @PaschalDaysCalc - ((@Y + @Y / 4
                                                  + @PaschalDaysCalc - 13) % 7) 
 
    SET @EasterMonth = 3 + (@NumOfDaysToSunday + 40) / 44 
 
    SET @EasterDay = @NumOfDaysToSunday + 28 - (31 * (@EasterMonth / 4)) 
 
    RETURN (SELECT  CONVERT 
        (SMALLDATETIME, RTRIM(@Y) + RIGHT('0' + RTRIM(@EasterMonth), 2)
                    + RIGHT('0' + RTRIM(@EasterDay), 2))
           ) 
   END 
GO

IF OBJECT_ID('dbo.GetEasterMonday') IS NOT NULL 
  DROP FUNCTION dbo.GetEasterMonday ;
GO

CREATE FUNCTION dbo.GetEasterMonday (@Y INT)
RETURNS SMALLDATETIME
AS BEGIN 
    RETURN (SELECT  dbo.GetEasterSunday(@Y) + 1
           ) 
   END 
GO 

IF OBJECT_ID('dbo.GetGoodFriday') IS NOT NULL 
  DROP FUNCTION dbo.GetGoodFriday ;
GO

CREATE FUNCTION dbo.GetGoodFriday (@Y INT)
RETURNS SMALLDATETIME
AS BEGIN 
    RETURN (SELECT  dbo.GetEasterSunday(@Y) - 2
           ) 
   END 
GO

UPDATE  Calendar
SET     IsHoliday = 1
WHERE   Date = dbo.GetGoodFriday(Y) 
 
UPDATE  Calendar
SET     IsHoliday = 1
WHERE   Date = dbo.GetEasterMonday(Y)
GO
    
    
/* the built-in print dies around 8000 characters, 4000 for NVARCHAR
   helper_longprint will iterate through a string and display its contents

   This is reproduced from Yildirim Kocdag's <ykocdag80@yahoo.com>
   code available at
   http://www.codeproject.com/Articles/18881/SQL-String-Printing
   
   This is not copyright Brent Ozar Unlimited but is distributed
   under the Code Project Open License
   http://www.codeproject.com/info/cpol10.aspx
 */
CREATE PROCEDURE [dbo].[Helper_LongPrint] (@string nvarchar(MAX))
  WITH EXECUTE AS CALLER
AS 
  SET NOCOUNT ON
  SET @string = rtrim(@string)
  DECLARE @cr char(1),
    @lf char(1)
  SET @cr = char(13)
  SET @lf = char(10)

  DECLARE @len int,
    @cr_index int,
    @lf_index int,
    @crlf_index int,
    @has_cr_and_lf bit,
    @left nvarchar(4000),
    @reverse nvarchar(4000)

  SET @len = 4000

  WHILE (len(@string) > @len)
    BEGIN

      SET @left = left(@string, @len)
      SET @reverse = reverse(@left)
      SET @cr_index = @len - charindex(@cr, @reverse) + 1
      SET @lf_index = @len - charindex(@lf, @reverse) + 1
      SET @crlf_index = case when @cr_index < @lf_index then @cr_index
                             else @lf_index
                        end

      SET @has_cr_and_lf = case when @cr_index < @len
                                     and @lf_index < @len then 1
                                else 0
                           end

      PRINT left(@string, @crlf_index - 1)

      SET @string = right(@string, len(@string) - @crlf_index - @has_cr_and_lf)

    END

  PRINT @string
GO
