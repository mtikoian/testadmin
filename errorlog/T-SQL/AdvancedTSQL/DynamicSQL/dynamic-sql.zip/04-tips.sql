/*
Dynamic SQL

Jeremiah Peschka, Brent Ozar Unlimited
v1.0 - January 2014

(C) 2014, Brent Ozar Unlimited. 
See http://BrentOzar.com/go/eula for the End User Licensing Agreement.
*/
/* One use of QUOTENAME */
DECLARE @sql NVARCHAR(MAX) =
 N'SELECT * FROM Sales.SalesOrderHeader WHERE AccountNumber = ';

SELECT @sql += QUOTENAME(']''; SELECT * FROM sys.objects;')

PRINT @sql;
EXEC @sql;
GO



/* What about PARSENAME? */
SELECT PARSENAME('Person.Pe3rson', 1) AS 'Object Name';
SELECT PARSENAME('Person.Per3son', 2) AS 'Schema Name';
SELECT PARSENAME('Person.Pers3on', 3) AS 'Database Name';
SELECT PARSENAME('Person.Perso3n', 4) AS 'Server Name';





/* And now for real fun... both! */
SELECT QUOTENAME(PARSENAME('Person.Person', 2)) + '.' + QUOTENAME(PARSENAME('Person.Person', 1))
GO


















SELECT MIN(OrderDate), MAX(OrderDate) FROM Sales.SalesOrderHeader


/* Using dynamic SQL to build an effective PIVOT */
DECLARE @sql AS NVARCHAR(MAX) = N'';
DECLARE @newline AS NVARCHAR(2);
DECLARE @start AS DATETIME;
DECLARE @end AS DATETIME;

SET @newline = NCHAR(13) + NCHAR(10);

SET @start = '20060701';
SET @end = '20070702';


DECLARE @columns AS NVARCHAR(MAX) = N'';
DECLARE @coalesceColumns AS NVARCHAR(MAX) = N'';



SELECT @columns = STUFF(
(
  SELECT N', ' + QUOTENAME(CAST([FirstDayOfMonth] AS NVARCHAR(50)), N'[')
     FROM ( SELECT  FirstDayOfMonth
            FROM    dbo.Calendar AS c
                    INNER JOIN Sales.SalesOrderHeader AS soh ON c.Date = soh.OrderDate
            WHERE   c.Date BETWEEN @start AND @end
            ) AS x
            GROUP BY FirstDayOfMonth
            ORDER BY [FirstDayOfMonth] FOR XML PATH('')
), 1, 1, N'');

SELECT @coalesceColumns = STUFF(
(
  SELECT N', COALESCE('
         + QUOTENAME(CAST([FirstDayOfMonth] AS NVARCHAR(50)), N'[')
         + N', 0) AS '
         + QUOTENAME(LEFT(DATENAME(mm, [FirstDayOfMonth]), 3)
                     + N' '
                     + CAST(DATEPART(yyyy, [FirstDayOfMonth]) AS NVARCHAR(4)), N']')
         AS [text()]
  FROM  (   SELECT  FirstDayOfMonth
            FROM    dbo.Calendar AS c
                    INNER JOIN Sales.SalesOrderHeader AS soh ON c.Date = soh.OrderDate
            WHERE   c.Date BETWEEN @start AND @end
            GROUP BY FirstDayOfMonth) AS x
  ORDER BY [FirstDayOfMonth] FOR XML PATH(N'')), 1, 1, N'');
  


PRINT @columns;
PRINT @coalesceColumns;

SET @sql = N'
SELECT SalesPersonID, ' + @coalesceColumns + @newline;
SET @sql = @sql + N'  FROM (SELECT c.FirstDayOfMonth AS OrderMonth,
               soh.SalesPersonID,
               soh.SubTotal
          FROM Sales.SalesOrderHeader AS soh
               INNER JOIN Sales.SalesOrderDetail AS sod ' + N'
                  ON soh.SalesOrderID = sod.SalesOrderID
               INNER JOIN Calendar AS c
                  ON c.Date BETWEEN @start_date AND @end_date
                     AND soh.OrderDate = c.Date
          WHERE SalesPersonID IS NOT NULL
) AS x
PIVOT (AVG(SubTotal) FOR OrderMonth IN (' + @columns + N')) AS pivot1
ORDER BY SalesPersonID';

PRINT @sql;

EXEC sp_executesql @sql,
     N'@start_date DATETIME, @end_date DATETIME',
     @start, @end;
