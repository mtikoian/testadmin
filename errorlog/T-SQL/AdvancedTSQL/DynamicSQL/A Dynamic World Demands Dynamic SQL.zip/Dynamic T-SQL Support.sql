-- For dealing with dynamic PIVOTs, amongst other things, a Calendar table
-- is an absolute must
USE DynamicSQL;
GO

IF OBJECT_ID('dbo.Calendar') IS NOT NULL
  DROP TABLE dbo.Calendar;
GO

CREATE TABLE [dbo].[Calendar] (
  [Date] datetime NOT NULL,
  [FirstDayOfMonth] datetime NULL,
  [LastDayOfMonth] datetime NULL,
  [IsWeekday] bit NULL,
  [IsHoliday] bit NULL,
  [Y] smallint NULL,
  [FY] smallint NULL,
  [Q] tinyint NULL,
  [M] tinyint NULL,
  [D] tinyint NULL,
  [DW] tinyint NULL,
  [monthname] varchar(9) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [dayname] varchar(9) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [W] tinyint NULL,
  [Number] int IDENTITY(1, 1) NOT NULL,
PRIMARY KEY NONCLUSTERED ([Date] ASC)
WITH ( PAD_INDEX = OFF,
FILLFACTOR = 100,
IGNORE_DUP_KEY = OFF,
STATISTICS_NORECOMPUTE = OFF,
ALLOW_ROW_LOCKS = ON,
ALLOW_PAGE_LOCKS = ON )
 ON [PRIMARY]
)
ON [PRIMARY];
GO
EXEC [sys].[sp_addextendedproperty] @name = N'MS_Description', @value = N'An arbitrary date number, starts with January 1, 1999 as day 1', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Calendar', @level2type = N'COLUMN', @level2name = N'Number';
GO

-- You'll also probably find yourself needing a numbers table...
IF OBJECT_ID('dbo.Nums') IS NOT NULL
  DROP TABLE dbo.Nums;
GO

CREATE TABLE [dbo].[Nums] (
[n] int NOT NULL,
PRIMARY KEY CLUSTERED ([n] ASC)
WITH ( PAD_INDEX = OFF,
FILLFACTOR = 100,
IGNORE_DUP_KEY = OFF,
STATISTICS_NORECOMPUTE = OFF,
ALLOW_ROW_LOCKS = ON,
ALLOW_PAGE_LOCKS = ON )
 ON [PRIMARY]
)
ON [PRIMARY];
GO

-- And fill the numbers table...
-- takes 15 seconds to 
DECLARE @max AS INT, @rc AS INT;
SET @max = 1000000;
SET @rc = 1;

INSERT INTO dbo.Nums(n) VALUES(1);
WHILE @rc * 2 <= @max
BEGIN
  INSERT INTO dbo.Nums(n) SELECT n + @rc FROM dbo.Nums;
  SET @rc = @rc * 2;
END

INSERT INTO dbo.Nums(n)
  SELECT n + @rc FROM dbo.Nums WHERE n + @rc <= @max;
GO

-- It is also possible to use the following function to create a dynamic 
-- numbers table, if it isn't possible or feasible to create a static table
-- Can generate 2^2^n rows, where n is the number of levels of recursion.
--  five levels will yield up to 4,294,967,296 rows
IF OBJECT_ID('dbo.fn_nums') IS NOT NULL
  DROP FUNCTION db.fn_nums;
GO

CREATE FUNCTION dbo.fn_nums(@n AS BIGINT) RETURNS TABLE
AS
RETURN
  WITH
    L0   AS (SELECT 1 AS c UNION ALL SELECT 1),
    L1   AS (SELECT 1 AS c FROM L0 AS A, L0 AS B),
    L2   AS (SELECT 1 AS c FROM L1 AS A, L1 AS B),
    L3   AS (SELECT 1 AS c FROM L2 AS A, L2 AS B),
    L4   AS (SELECT 1 AS c FROM L3 AS A, L3 AS B),
    L5   AS (SELECT 1 AS c FROM L4 AS A, L4 AS B),
    Nums AS (SELECT ROW_NUMBER() OVER(ORDER BY c) AS n FROM L5)
    SELECT n FROM Nums WHERE n <= @n;
GO


-- Now, to fill the table...
-- This takes ~4 seconds on my virtual machine
TRUNCATE TABLE Calendar;

INSERT INTO Calendar (date)
SELECT DATEADD(DAY, n, '19990101')
  FROM nums
 WHERE n <= 10597
 ORDER BY n;

UPDATE dbo.Calendar SET 
    isWeekday = CASE  
        WHEN DATEPART(DW, date) IN (1,7)  
        THEN 0 
        ELSE 1 END, 
    isHoliday = 0, 
    Y = YEAR(date),  
    FY = YEAR(date), 
    /* 
    -- if our fiscal year 
    -- starts on May 1st: 
    FY = CASE  
        WHEN MONTH(date) < 5 
        THEN YEAR(date)-1  
        ELSE YEAR(date) END, 
    */ 
    Q = CASE 
        WHEN MONTH(date) <= 3 THEN 1 
        WHEN MONTH(date) <= 6 THEN 2 
        WHEN MONTH(date) <= 9 THEN 3 
        ELSE 4 END,  
    M = MONTH(date),  
    D = DAY(date),  
    DW = DATEPART(DW, date),  
    monthname = DATENAME(MONTH, date),  
    dayname = DATENAME(DW, date),  
    W = DATEPART(WK, date);

UPDATE Calendar
   SET FirstDayOfMonth = DATEADD(mm,DATEDIFF(mm,0,Date),0),
       LastDayOfMonth = DATEADD(ss,-1,DATEADD(mm,1,DATEADD(mm,DATEDIFF(mm,0,Date),0)));

-- New Year's Day - easy 
 
UPDATE Calendar 
    SET 
        isHoliday = 1
    WHERE M = 1 
    AND D = 1 
 
-- Memorial Day - last Monday in May 
 
UPDATE Calendar 
    SET 
        isHoliday = 1
    FROM Calendar c1 
    WHERE M = 5 
    AND DW = 2 
    AND NOT EXISTS (SELECT 1 FROM Calendar c2 
        WHERE M = 5 AND DW = 2 
        AND c2.Y = c1.Y 
        AND c2.date > c1.date) 
 
-- Labor Day - first Monday in September 
 
UPDATE Calendar 
    SET 
        isHoliday = 1
    FROM Calendar c1 
    WHERE M = 9 
    AND DW = 2 
    AND NOT EXISTS (SELECT 1 FROM Calendar c2 
        WHERE M = 9 AND DW = 2 
        AND c2.Y = c1.Y 
        AND c2.date < c1.date) 
         
-- Thanksgiving Thursday - 4th Thursday in November 
 
UPDATE Calendar 
    SET 
        isHoliday = 1
    FROM Calendar c1 
    WHERE M = 11 
    AND DW = 5 
    AND (SELECT COUNT(*) FROM Calendar c2 
        WHERE M = 11 AND DW = 5 
        AND c2.Y = c1.Y 
        AND c2.date < c1.date) = 3 
 
-- Traditionally, Thanksgiving Friday, as well 
-- as long as you haven't pre-configured any  
-- other Thursday in November to be isHoliday 
 
UPDATE Calendar 
    SET 
        isHoliday = 1
    FROM Calendar c1 
    WHERE M = 11 
    AND DW = 6 
    AND EXISTS (SELECT 1 FROM Calendar c2 
        WHERE M = 11 AND DW = 5 
        AND c2.date = (c1.date - 1) 
        AND c2.Y = c1.Y 
        AND isHoliday = 1) 
 
-- Veterans' Day - easy 
-- however do this AFTER Thanksgiving calculation 
-- in case it happens to fall on a Thursday 
 
UPDATE Calendar 
    SET 
        isHoliday = 1
    WHERE M = 11 AND D = 11 
 
-- Christmas Day - easy 
 
UPDATE Calendar 
    SET 
        isHoliday = 1
    WHERE M = 12 
    AND D = 25


GO

IF OBJECT_ID('dbo.GetEasterSunday') IS NOT NULL
  DROP FUNCTION dbo.GetEasterSunday;
GO

CREATE FUNCTION dbo.GetEasterSunday 
( 
    @Y INT 
) 
RETURNS SMALLDATETIME 
AS 
BEGIN 
    DECLARE     @EpactCalc INT,  
        @PaschalDaysCalc INT, 
        @NumOfDaysToSunday INT, 
        @EasterMonth INT, 
        @EasterDay INT 
 
    SET @EpactCalc = (24 + 19 * (@Y % 19)) % 30 
 
    SET @PaschalDaysCalc = @EpactCalc - (@EpactCalc / 28) 
 
    SET @NumOfDaysToSunday = @PaschalDaysCalc - ( 
        (@Y + @Y / 4 + @PaschalDaysCalc - 13) % 7 
    ) 
 
    SET @EasterMonth = 3 + (@NumOfDaysToSunday + 40) / 44 
 
    SET @EasterDay = @NumOfDaysToSunday + 28 - ( 
        31 * (@EasterMonth / 4) 
    ) 
 
    RETURN 
    ( 
        SELECT CONVERT 
        ( 
            SMALLDATETIME, 
 
            RTRIM(@Y)  
            + RIGHT('0'+RTRIM(@EasterMonth), 2)  
            + RIGHT('0'+RTRIM(@EasterDay), 2) 
        ) 
    ) 
END 
GO

IF OBJECT_ID('dbo.GetEasterMonday') IS NOT NULL
  DROP FUNCTION dbo.GetEasterMonday;
GO

CREATE FUNCTION dbo.GetEasterMonday 
( 
    @Y INT 
) 
RETURNS SMALLDATETIME 
AS 
BEGIN 
    RETURN (SELECT dbo.GetEasterSunday(@Y) + 1) 
END 
GO 

IF OBJECT_ID('dbo.GetGoodFriday') IS NOT NULL
  DROP FUNCTION dbo.GetGoodFriday;
GO

CREATE FUNCTION dbo.GetGoodFriday 
( 
    @Y INT 
) 
RETURNS SMALLDATETIME 
AS 
BEGIN 
    RETURN (SELECT dbo.GetEasterSunday(@Y) - 2) 
END 
GO

UPDATE Calendar 
    SET 
        isHoliday = 1
    WHERE date = dbo.GetGoodFriday(Y) 
 
UPDATE Calendar 
    SET 
        isHoliday = 1
    WHERE date = dbo.GetEasterMonday(Y)
    
    
    
-- the built-in print dies around 8000 characters, 4000 for NVARCHAR
-- helper_longprint will iterate through a string and display its contents
CREATE PROCEDURE [dbo].[Helper_LongPrint]
(@string nvarchar(MAX))
WITH 
EXECUTE AS CALLER
AS
  SET NOCOUNT ON
  SET @string = rtrim( @string )
  DECLARE @cr char(1), @lf char(1)
  SET @cr = char(13)
  SET @lf = char(10)

  DECLARE @len int, 
          @cr_index int, 
          @lf_index int, 
          @crlf_index int, 
          @has_cr_and_lf bit, 
          @left nvarchar(4000), 
          @reverse nvarchar(4000)

  SET @len = 4000

  WHILE ( len( @string ) > @len )
  BEGIN

    SET @left = left( @string, @len )
    SET @reverse = reverse( @left )
    SET @cr_index = @len - charindex( @cr, @reverse ) + 1
    SET @lf_index = @len - charindex( @lf, @reverse ) + 1
    SET @crlf_index = case when @cr_index < @lf_index then @cr_index else @lf_index end

    SET @has_cr_and_lf = case when @cr_index < @len and @lf_index < @len then 1 else 0 end

    PRINT left( @string, @crlf_index - 1 )

    SET @string = right( @string, len( @string ) - @crlf_index - @has_cr_and_lf )

  END

  PRINT @string
GO