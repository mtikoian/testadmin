USE DynamicSQL;
GO

/******************************************************************************
 * Demonstrating plan caching
 *****************************************************************************/
DBCC FREEPROCCACHE
GO

SET STATISTICS TIME ON;
GO

SELECT * 
  FROM HumanResources.Employee
 WHERE EmployeeId IN (1, 2);
GO

-- If we run the query again a second time, the parse and compile time will be less.
-- An interesting side effect, if you select an empty line when running the SELECT
--  an extra plan will be generated for the query because of the newline.

SELECT * 
  FROM HumanResources.Employee
 WHERE EmployeeId IN (1, 2);
GO

-- Examine query plans
SELECT ecp.objtype,
       p.text
  FROM sys.dm_exec_cached_plans AS ecp
       CROSS APPLY (SELECT * FROM sys.dm_exec_sql_text(ecp.plan_handle)) AS p
 WHERE p.text LIKE '%HumanResources%'
   AND p.text NOT LIKE '%sys.dm_exec_cached_plans%';
   


/******************************************************************************
 * Parameterization and caching in action
 *****************************************************************************/
-- query to be parameterized
SELECT *
FROM HumanResources.Employee
WHERE EmployeeId IN (@empid1, @empid2);

-- query for parameter values
SELECT number, number +1 AS NumberPlus1
FROM master..spt_values
WHERE Type = 'P';

-- second query to be parameterized
DECLARE @sql VARCHAR(MAX);

SET @sql = '
SELECT *
FROM HumanResources.Employee
WHERE EmployeeId IN (' + 
  CONVERT(VARCHAR, @EmpId1) + ', ' +
  CONVERT(VARCHAR, @EmpId2) + ')';

EXEC(@sql);



/******************************************************************************
 * Static Parameters in T-SQL (How not to be dynamic)
 *****************************************************************************/
-- Basic Query
SELECT SalesPersonID,
       SUM(TotalDue) AS TotalSales,
       COUNT(SalesOrderId) AS NumberOfSales
  FROM Sales.SalesOrderHeader
 WHERE SalesPersonID = 280
   AND OrderDate BETWEEN '20010601' AND '20010901'
 GROUP BY SalesPersonID;

-- If we want just to search by SalesPersonID we need
SELECT SalesPersonID,
       SUM(TotalDue) AS TotalSales,
       COUNT(SalesOrderId) AS NumberOfSales
  FROM Sales.SalesOrderHeader
 WHERE SalesPersonID = 280
 GROUP BY SalesPersonID;
 
-- likewise to search by a date range
SELECT SalesPersonID,
       SUM(TotalDue) AS TotalSales,
       COUNT(SalesOrderId) AS NumberOfSales
  FROM Sales.SalesOrderHeader
 WHERE OrderDate BETWEEN '20010601' AND '20010901'
 GROUP BY SalesPersonID;

-- There are very different execution plans between the three previous queries

-- One solution to search by either EmployeeId or NationalIDNumber is
-- to make use of IF/ELSE blocks:
CREATE PROCEDURE GetSalesData
  @SalesPersonID AS INT = NULL,
  @StartDate AS DATETIME = NULL,
  @EndDate AS DATETIME = NULL
AS
SET NOCOUNT ON;

IF @SalesPersonID IS NOT NULL AND @StartDate IS NOT NULL
BEGIN
  SELECT SalesPersonID,
         SUM(TotalDue) AS TotalSales,
         COUNT(SalesOrderId) AS NumberOfSales
    FROM Sales.SalesOrderHeader
   WHERE SalesPersonID = @SalesPersonID
     AND OrderDate BETWEEN @StartDate AND @EndDate
   GROUP BY SalesPersonID;
END
ELSE IF @SalesPersonID IS NOT NULL
BEGIN
  SELECT SalesPersonID,
         SUM(TotalDue) AS TotalSales,
         COUNT(SalesOrderId) AS NumberOfSales
    FROM Sales.SalesOrderHeader
   WHERE SalesPersonID = @SalesPersonID
   GROUP BY SalesPersonID;
END
ELSE IF @StartDate IS NOT NULL
BEGIN
  SELECT SalesPersonID,
         SUM(TotalDue) AS TotalSales,
         COUNT(SalesOrderId) AS NumberOfSales
    FROM Sales.SalesOrderHeader
   WHERE OrderDate BETWEEN @StartDate AND @EndDate
   GROUP BY SalesPersonID;
END
ELSE
BEGIN
  SELECT SalesPersonID,
         SUM(TotalDue) AS TotalSales,
         COUNT(SalesOrderId) AS NumberOfSales
    FROM Sales.SalesOrderHeader;
END
GO


-- An alternate solution using COALESCE
SELECT SalesPersonID,
       SUM(TotalDue) AS TotalSales,
       COUNT(SalesOrderId) AS NumberOfSales
  FROM Sales.SalesOrderHeader
 WHERE SalesPersonID = COALESCE(@SalesPersonID, SalesPersonID)
   AND OrderDate BETWEEN COALESCE(@StartDate, OrderDate) AND COALESCE(@EndDate, OrderDate)
 GROUP BY SalesPersonID;

-- Because COALESCE is a scalar function, the function will be evaluated once
-- for each row of the table, which causes a full table scan



-- What about using IS NULL and OR?
SELECT SalesPersonID,
       SUM(TotalDue) AS TotalSales,
       COUNT(SalesOrderId) AS NumberOfSales
  FROM Sales.SalesOrderHeader
 WHERE (@SalesPersonID IS NULL 
        OR SalesPersonId = @SalesPersonId
   AND (@StartDate IS NULL 
        OR OrderDate BETWEEN @StartDate AND @EndDate)
 GROUP BY SalesPersonID;

-- Well, the long term results depend on the first plan that is run and compiled.
-- SQL Server's implementation of SQL also doesn't have short-circuiting like other languages,
--  so there's no guarantee that only one portion of the OR will be evaluated

-- So, what's the next best option? EXEC?
DECLARE @SalesPersonID AS INT;
DECLARE @StartDate AS DATETIME;
DECLARE @EndDate AS DATETIME;

SET @SalesPersonID = 280;
SET @StartDate = '20010601';
SET @EndDate = '20010901';

DECLARE @sql AS NVARCHAR(MAX);

SET @sql = '
SELECT SalesPersonID,
       SUM(TotalDue) AS TotalSales,
       COUNT(SalesOrderId) AS NumberOfSales
  FROM Sales.SalesOrderHeader';

IF @SalesPersonId IS NOT NULL
   AND @StartDate IS NOT NULL
BEGIN
  SET @sql = @sql + 'WHERE SalesPersonID = ' + CONVERT(NVARCHAR, @SalesPersonID) +
                    '  AND OrderDate BETWEEN ' + QUOTENAME(CONVERT(NVARCHAR, @StartDate, 101), '''') +
                    '  AND ' + QUOTENAME(CONVERT(NVARCHAR, @EndDate, 101), '''');
END

SET @sql = @sql + ' GROUP BY SalesPersonID ';

PRINT @sql;

-- there will be no plan cache re-use here, either, since EXEC simply 
-- executes this the same as if it were ad hoc SQL
EXEC(@sql);




/******************************************************************************
 * Clearly, there are some problems using EXEC. 
 * The best approach is to use sp_executesql.
 *****************************************************************************/
DECLARE @SalesPersonID AS INT;
DECLARE @StartDate AS DATETIME;
DECLARE @EndDate AS DATETIME;

SET @SalesPersonID = 280;
SET @StartDate = '20010601';
SET @EndDate = '20010901';

DECLARE @sql AS NVARCHAR(MAX);
DECLARE @newline AS NVARCHAR(2);

SET @newline = NCHAR(13) + NCHAR(10);

SET @sql = '
SELECT SalesPersonID,
       SUM(TotalDue) AS TotalSales,
       COUNT(SalesOrderId) AS NumberOfSales
  FROM Sales.SalesOrderHeader
 WHERE 1 = 1 ' + @newline; 
-- SQL Server will optimize out the WHERE 1 = 1, this is a safe way to account for 
--  multiple potential search predicates
  
IF @SalesPersonID IS NOT NULL
  SET @sql = @sql + '   AND SalesPersonId = @sales_person_id ' + @newline;

IF @StartDate IS NOT NULL
  SET @sql = @sql + '   AND OrderDate BETWEEN @start_date AND @end_date ' + @newline;

SET @sql = @sql + ' GROUP BY SalesPersonID ';

PRINT @sql;

EXEC sp_executesql @sql,
     N'@sales_person_id INT, @start_date DATETIME, @end_date DATETIME',
     @SalesPersonID, @StartDate, @EndDate;
     




-- And now... A DYNAMIC PIVOT!
-- MIN 20010701
-- MAX 20040731
DECLARE @sql AS NVARCHAR(MAX);
DECLARE @newline AS NVARCHAR(2);
DECLARE @start AS DATETIME;
DECLARE @end AS DATETIME;

SET @newline = NCHAR(13) + NCHAR(10);

SET @start = '20030701';
SET @end = '20040702';

DECLARE @columns AS NVARCHAR(MAX);
DECLARE @coalesceColumns AS NVARCHAR(MAX);

SELECT @columns = STUFF(
  (SELECT N', ' + QUOTENAME(CAST([FirstDayOfMonth] AS VARCHAR(50)), N'[') AS [text()]
     FROM (SELECT DISTINCT [FirstDayOfMonth]
             FROM dbo.Calendar AS c
                  INNER JOIN Sales.SalesOrderHeader AS soh
                     ON c.Date = soh.OrderDate
            WHERE c.Date BETWEEN @start AND @end) AS x
    ORDER BY [FirstDayOfMonth] FOR XML PATH(N'')), 1, 1, N'');

SELECT @coalesceColumns = STUFF(
  (SELECT N', COALESCE('
          + QUOTENAME(CAST([FirstDayOfMonth] AS VARCHAR(50)), N'[')
          + N', 0) AS '
          + QUOTENAME(LEFT(DATENAME(mm, [FirstDayOfMonth]), 3)
                      + N' '
                      + CAST(DATEPART(yyyy, [FirstDayOfMonth]) AS NVARCHAR(4)), N']')
          AS [text()]
     FROM (SELECT DISTINCT [FirstDayOfMonth]
             FROM dbo.Calendar AS c
                  INNER JOIN Sales.SalesOrderHeader AS soh
                     ON c.Date = soh.OrderDate
            WHERE c.Date BETWEEN @start AND @end) AS x
    ORDER BY [FirstDayOfMonth] FOR XML PATH(N'')), 1, 1, N'');

--PRINT @columns;
--PRINT @coalesceColumns;

SET @sql = '
SELECT OnlineOrderFlag, ' + @coalesceColumns + @newline;
SET @sql = @sql + '  FROM (SELECT c.FirstDayOfMonth AS OrderMonth,
               soh.OnlineOrderFlag,
               soh.SubTotal
          FROM Sales.SalesOrderHeader AS soh
               INNER JOIN Sales.SalesOrderDetail AS sod
                  ON soh.SalesOrderID = sod.SalesOrderID
               INNER JOIN Calendar AS c
                  ON c.Date BETWEEN @start_date AND @end_date
                 AND soh.OrderDate = c.Date
) AS x
PIVOT (AVG(SubTotal) FOR OrderMonth IN (' + @columns + ')) AS pivot1';

EXEC dbo.helper_longprint @sql;

EXEC sp_executesql @sql,
     N'@start_date DATETIME, @end_date DATETIME',
     @start, @end;




-- How to execute dynamic sprocs dynamically
-- can be found online at http://facility9.com/2009/02/16/automating-t-sql-testing/
USE DynamicSQL;
GO

IF OBJECT_ID('test.Procedures') IS NULL
BEGIN
  CREATE TABLE [test].[Procedures](
  	[ProceduresId] [INT] IDENTITY(1,1) NOT NULL PRIMARY KEY,
  	[ProcedureName] [NVARCHAR](128) NOT NULL,
  	[Run] [INT] NOT NULL,
  	[ParameterName] [NVARCHAR](255) NULL,
  	[ParameterType] [NVARCHAR](255) NULL,
  	[ParameterOrder] [INT] NULL,
  	[ParameterValue] [NVARCHAR](255) NULL
  );
END
GO

/* 
ProcedureName - clearly this stores the name of the procedure.
Run - if a procedure has optional parameters, the Run column can be used to 
      distinguish between different combinations of parameters and group them together.
ParameterName - the name of the parameter.
ParameterType - this isn’t used in the dynamic code coming up later, but it does help 
      to sort things out in your brain.
ParameterOrder - again, like ParameterType, this isn’t used in the dynamic code that 
      I wrote, but it does help to keep things in mind. You could easily modify the T-SQL 
      to write the parameters out in order instead of using named parameters.
ParameterValue - the value of the parameter being passed in during the test run. You 
      could increase this to VARCHAR(4000) or something like that, depending on your needs.
*/

-- Create a procedure to test
IF OBJECT_ID('dbo.FindCustomer') IS NOT NULL
  DROP PROCEDURE dbo.FindCustomer;
GO

CREATE PROCEDURE [dbo].[FindCustomer] (
  @CompanyName NVARCHAR(40) = NULL,
  @ContactName NVARCHAR(30) = NULL
)
AS
SET NOCOUNT ON;

IF @CompanyName IS NULL AND @ContactName IS NULL
BEGIN
  RAISERROR('Either Company Name, Contact Name, or both must be supplied', 16, 0);
  RETURN
END

DECLARE @SQL AS NVARCHAR(MAX);
DECLARE @newline AS NVARCHAR(2);

SET @newline = NCHAR(13) + NCHAR(10);

SET @SQL = '
SELECT CustomerID, 
       CompanyName, 
       ContactName
  FROM dbo.Customers
 WHERE 1 = 1 ' + @newline;

IF @CompanyName IS NOT NULL
BEGIN
  SET @CompanyName = @CompanyName + '%';
  SET @SQL += '   AND CompanyName LIKE @company_name ' + @newline;
END

IF @ContactName IS NOT NULL
BEGIN
  SET @ContactName = @ContactName + '%';
  SET @SQL += '   AND ContactName LIKE @contact_name ' + @newline;
END

EXEC SP_EXECUTESQL @SQL,
     N'@company_name AS NVARCHAR(40), @contact_name AS NVARCHAR(30)',
     @CompanyName, @ContactName;
GO


-- Empty the test table, just to be safe
TRUNCATE TABLE test.Procedures;

-- Fill the test table
INSERT INTO test.Procedures VALUES
  ('FindCustomer', 1,	NULL,	NULL,	NULL,	NULL);
INSERT INTO test.Procedures VALUES
  ('FindCustomer', 2, '@CompanyName',	'NVARCHAR(40)',	1, 'A');
INSERT INTO test.Procedures VALUES
  ('FindCustomer', 3, '@CompanyName', 'NVARCHAR(40)', 1, 'A');
INSERT INTO test.Procedures VALUES
  ('FindCustomer', 3, '@ContactName', 'NVARCHAR(30)', 2, 'Maria');


-- And... test!
SET NOCOUNT ON;

IF OBJECT_ID(N'tempdb..temp') IS NOT NULL
  DROP TABLE #temp;

IF OBJECT_ID(N'tempdb..procs') IS NOT NULL
  DROP TABLE #procs;

DECLARE @s AS NVARCHAR(1);
DECLARE @SQL AS NVARCHAR(MAX);
DECLARE @newline AS NVARCHAR(2);
DECLARE @proc_sql AS NVARCHAR(MAX);

SET @s = N'''';
SET @SQL = N'';
SET @newline = NCHAR(13) + NCHAR(10);

IF OBJECT_ID('tempdb..#temp') IS NOT NULL
  DROP TABLE #temp;

IF OBJECT_ID('tempdb..#procs') IS NOT NULL
  DROP TABLE #procs;

SET @SQL = N'
DECLARE @error AS BIT;
DECLARE @errors TABLE (
  ErrorNumber INT,
  ErrorSeverity INT,
  ErrorState INT,
  ErrorProcedure NVARCHAR(126),
  ErrorLine INT,
  ErrorMessage NVARCHAR(2048)
);

SET @error = 0;

BEGIN TRANSACTION;' + @newline + @newline;

SET @proc_sql = N'BEGIN TRY
  --myproc--
END TRY
BEGIN CATCH
  SET @error = 1;

  INSERT INTO @errors VALUES 
  (
	  ERROR_NUMBER(),
    ERROR_SEVERITY(),
    ERROR_STATE(),
    ERROR_PROCEDURE(),
    ERROR_LINE(),
    ERROR_MESSAGE()
  );
END CATCH' + @newline + @newline;

SELECT ProcedureName,
       Run,
       ParameterOrder,
       ParameterName 
       + N' = '
       + QUOTENAME(ParameterValue, @s) AS x
  INTO #temp
  FROM test.[Procedures]
 ORDER BY Run, ParameterOrder;

--SELECT * FROM #temp;

SELECT N'EXEC '
       + x.ProcedureName
       + N' '
       + COALESCE(x.[params], '') AS command
  INTO #procs
  FROM (SELECT t.ProcedureName,
               t.Run,
               STUFF((SELECT N', ' + t2.x AS [text()]
                        FROM #temp AS t2
                       WHERE t2.ProcedureName = t.ProcedureName
                         AND t2.Run = t.Run
                       ORDER BY t2.ParameterOrder
                         FOR XML PATH('')), 1, 1, '') AS [params]
          FROM #temp AS t) AS x
 GROUP BY x.ProcedureName, x.[params], x.Run
 ORDER BY x.Run

--SELECT * FROM #procs;

SELECT @SQL += REPLACE(@proc_sql, N'--myproc--', command)
  FROM #procs;

SET @SQL += @newline + @newline
          + 'IF @error = 1
  SELECT * FROM @errors;

  ROLLBACK TRANSACTION;'

EXEC Helper_LongPrint @SQL;

EXEC SP_EXECUTESQL @SQL;
-- Because of the table variables being used,
-- any sprocs that error will actually be displayed last.
-- Keep that in mind when looking at your output ;)


--
-- TIPS & TRICKS
--

-- Some convenience variables
DECLARE @newline AS NVARCHAR(2);
SET @newline = NCHAR(13) + NCHAR(10);

DECLARE @s AS NVARCHAR(1);
SET @s = '''';

-- QUOTENAME
SELECT QUOTENAME('MyTable', '[');
SELECT QUOTENAME(NEWID(), '{');

-- scoping example
SELECT ContactID
  INTO #people
  FROM Person.Contacts
 WHERE Title = 'Admiral';

IF (SELECT COUNT(*) FROM #people) > 0
BEGIN
  SET @sql = @sql + 'INNER JOIN dbo.Ships AS s ON s.CommandingOfficerID = #people.ContactID ';
END

-- procedure name hint
DECLARE @sql AS NVARCHAR(MAX);
SET @sql = ' /* dbo.Proc_Name */
SELECT 4 ';'