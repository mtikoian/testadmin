/*
********************************************************************************************************************
Object: Populate_DataView
Description:  Populate the dataview tables with views and columns.
	Possible but not included in this demo would be the ability for the application to allow existing
	views to be opened and closed.  Those events would trigger a rebuild of the user's procedure to account for
	any new or removed columns.
Author: Dan Holmes 
	dnhlms@gmail.com
	sql.dnhlms.com
Part of:
	The Last Mile:  Dynamically Created Objects
	SQL Saturday 220, May 18th Atlanta
	SQL Saturday 521, May 21th Atlanta
2016-05-18
********************************************************************************************************************
*/
DELETE FROM dbo.DataViews;
DELETE FROM dbo.DataFields;
DELETE FROM dbo.DataViewFields;
INSERT INTO dbo.DataFields(FieldName, Description)
SELECT DISTINCT c.name, c.name
FROM sys.tables t 
INNER JOIN sys.columns c ON c.object_id = t.object_id
WHERE t.name IN (
	'SalesOrderHeader'
	,'SalesOrderDetail'
	,'SpecialOffer'
	,'Product'
	,'Customer'
	,'Address'
	,'StateProvince'
	,'SalesTerritory'
	,'ProductPhoto'
	,'ShipMethod'
	,'Person');

INSERT INTO dbo.DataViews (Id,Caption, UserID, PublicView)
VALUES (1, 'Shipping', NULL, 1)
	, (2, 'Dan', 1 , 0)
	, (3, 'Sean', 1 , 0)
	--this view isn't open by any of the current users
	, (4, 'Logistics', NULL, 0);

INSERT INTO dbo.DataViewFields(DataViewID,DataFieldID,Width, ColumnPosition )
SELECT 1, id, 30, ROW_NUMBER() OVER(ORDER BY ID)
FROM dbo.dataFields
WHERE fieldname IN('FirstName', 'LastName', 'MiddleName', 'Title', 'AddressLine1', 'City', 'PostalLocation', 'CarrierTrackingNumber');

INSERT INTO dbo.DataViewFields(DataViewID,DataFieldID,Width, ColumnPosition )
SELECT 2, id, 30, ROW_NUMBER() OVER(ORDER BY ID)
FROM dbo.dataFields
WHERE fieldname IN('StockLevel', 'ProductStandardCost', 'ThumbNailPhoto', 'LargePhoto', 'UnitPrice', 'UnitPriceDiscount', 'SafetyStockLevel');

INSERT INTO dbo.DataViewFields(DataViewID,DataFieldID,Width, ColumnPosition )
SELECT 3, id, 30, ROW_NUMBER() OVER(ORDER BY ID)
FROM dbo.dataFields
WHERE fieldname IN('LineTotal', 'Class', 'Color', 'ListPrice', 'Name', 'ProductNumber', 'StandardCost', 'UnitPrice');

INSERT INTO dbo.DataViewFields(DataViewID,DataFieldID,Width, ColumnPosition )
SELECT 4, id, 30, ROW_NUMBER() OVER(ORDER BY ID)
FROM dbo.dataFields
WHERE fieldname IN('AddressLine1', 'City', 'PostalLocation', 'SpatialLocation');

GO