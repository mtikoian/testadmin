extract all files from the zip
change to the adventureworks database
open apply_all_objects.sql in SSMS
turn on sqlcmd mode (Alt-Q -> M)
Change the path on line 31.
Execute

now all required objects exist.
Use the worksheet_example.sql to run the demo.

Included also is the "Create enlarged adventureworks tables.sql" script.
Run that to before the worksheet execution to see 'enlarged' proc work.

Dan Holmes
dnhlms@gmail.com
http://sql.dnhlms.com
SQL Saturday 521