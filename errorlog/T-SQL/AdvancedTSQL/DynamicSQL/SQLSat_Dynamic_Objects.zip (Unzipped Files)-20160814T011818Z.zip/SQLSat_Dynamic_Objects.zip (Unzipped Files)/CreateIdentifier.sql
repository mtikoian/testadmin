/*
********************************************************************************************************************
Object: CreateIdentifier
Description: Ensures that the text supplied can be used as a legal SQL Server identifier.
Author: Dan Holmes 
	dnhlms@gmail.com
	sql.dnhlms.com
Part of:
	The Last Mile:  Dynamically Created Objects
	SQL Saturday 220, May 18th Atlanta
	SQL Saturday 521, May 21th Atlanta
2016-05-18
********************************************************************************************************************
*/
IF EXISTS (SELECT * FROM sys.objects WHERE name = 'CreateIdentifier')
	DROP FUNCTION dbo.CreateIdentifier;
GO
CREATE FUNCTION dbo.CreateIdentifier(@value VARCHAR(128))
RETURNS sysname
WITH SCHEMABINDING
AS
BEGIN
/*
The goal is to accept a string value and turn it into a legal TSQL identifier.

The rules for Identifiers are here: http://msdn.microsoft.com/en-us/library/ms175874.aspx

I have abbreviated these.  I am only allowing digits and letters in the name.  Everything else is being
turned into underscores.  Now this can result in collisions because the username a_j would then be equal 
to a.j because they will both get turned into a_j.  If that becomes a problem then these rules can be relaxed
and some of the special characters can be left as they are.

The only issue right now is the dot in the username when creating the specialized proc name.
*/
	DECLARE @newvalue sysname;
	SET @newvalue = '';
	WITH numbers (number)
	AS (
		SELECT 1
		UNION ALL
		SELECT Number + 1
		FROM Numbers
		WHERE Number <= 256
	)
	, CharSet (id, origchr, chr)
	AS (
		--48..57  digits
		--65..90  ucase letters
		--97..122 lcase letters
		--that is the valid range of chars.  the following creates an alternate character set where everything that isn't a 
		--digit or a letter is an underscore.
		SELECT number, CHAR(number), CASE WHEN number BETWEEN 1 AND 47 OR number BETWEEN 58 AND 64 OR number BETWEEN 91 AND 96 OR number > 122 THEN '_' ELSE CHAR(number) END
		FROM Numbers
	)
	SELECT @newvalue = @newvalue + cs.chr
	FROM numbers c
	INNER JOIN charset cs ON ASCII(SUBSTRING(@value, c.number, 1)) = ASCII(cs.origchr)
	WHERE c.number BETWEEN 1 AND LEN(@value)
	ORDER BY c.number
	OPTION(MAXRECURSION 256);
	RETURN @newvalue
END;
GO