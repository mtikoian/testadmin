/*
********************************************************************************************************************
Object: Users
Description:  table to hold the application's login and user information.
	The users Dan and Sean as also created.
Author: Dan Holmes 
	dnhlms@gmail.com
	sql.dnhlms.com
Part of:
	The Last Mile:  Dynamically Created Objects
	SQL Saturday 220, May 18th Atlanta
	SQL Saturday 521, May 21th Atlanta
2016-05-18
********************************************************************************************************************
*/
CREATE TABLE dbo.Users(
	UserName VARCHAR(30) NOT NULL
		CONSTRAINT UQ_Users_UserName UNIQUE
	, UserID INT NOT NULL
		CONSTRAINT PK_Users PRIMARY KEY (UserID)
	--, FirstName VARCHAR(50) NOT NULL
	--, LastName VARCHAR(50) NOT NULL
);
INSERT INTO dbo.Users (UserName, UserID)
VALUES ('Dan', 1)
	, ('Sean', 2);

GO