/*
********************************************************************************************************************
Object: CreateSpecializedOrderReviewProcedure
Author: Dan Holmes 
	dnhlms@gmail.com
	sql.dnhlms.com
Part of:
	The Last Mile:  Dynamically Created Objects
	SQL Saturday 220, May 18th Atlanta
	SQL Saturday 521, May 21th Atlanta
2016-05-18
********************************************************************************************************************
*/
IF OBJECT_ID('CreateSpecializedOrderReviewProcedure') IS NOT NULL
	DROP PROC dbo.CreateSpecializedOrderReviewProcedure;
GO

CREATE PROC dbo.CreateSpecializedOrderReviewProcedure
	@UserID            INT 
	, @SpecializedArea   VARCHAR(30)
	, @Operation         VARCHAR(200)
	, @Data              VARCHAR(MAX)
	, @proccontents      VARCHAR(MAX) OUTPUT
AS 
/**********************************************************************************************************************
** Object:
**    CreateSpecializedOrderReviewProcedure
**
** Description:
**    Template processor for creating the individual user stored procedures for retrieving data in Dispatching.
**
**********************************************************************************************************************/
BEGIN
	--replace the variable name tokens in the template.  if the token isn't used put the 
	--unused value in the spot.
	SELECT @proccontents = REPLACE(@proccontents, '$v(' + t.token + ')', CASE WHEN f.FieldName IS NULL THEN t.unusedvalue ELSE t.value END)
	FROM dbo.SpecializedProcedureTemplateTokens t
	LEFT JOIN (
		SELECT df.FieldName
		FROM dbo.DataViews dv
		INNER JOIN dbo.DataViewFields dvf ON dv.ID = dvf.DataViewID
		INNER JOIN dbo.DataFields df ON df.ID = dvf.DataFieldID
		WHERE (dv.UserID = @UserID OR dv.PublicView = 1) 
		) f ON f.FieldName = t.token
	WHERE SpecializedArea = @SpecializedArea;
	----dataviews are shared, check for other users that use the same views and
	----rebuild their procs too.
	----The possible values for @operation are: OPEN_VIEW, CLOSE_VIEW and MODIFY_VIEW
	----the open and close do not warrant a change to everyone's procs.  The modify might.
	----if the view in the @data parameter is a public view then anyone that can see that view
	----will need to be rebuilt
	IF @operation = 'MODIFY_VIEW' AND EXISTS (SELECT * FROM dbo.DataViews WHERE ID = CAST(@Data AS INT) AND publicview = 1)
	BEGIN
		BEGIN TRY
			DECLARE c CURSOR LOCAL READ_ONLY FAST_FORWARD FOR
				SELECT DISTINCT UserID 
				FROM dbo.DataViews sp
				WHERE UserID <> @UserID AND ID = CAST(@Data AS INT);
			OPEN c;
			WHILE 1=1
			BEGIN
				FETCH NEXT FROM c INTO @UserID;
				IF @@FETCH_STATUS <> 0 BREAK;
				EXEC dbo.CreateSpecializedProcedureForUserID @UserID, @SpecializedArea, NULL, NULL;  --don't want recursive actions
			END;
			CLOSE c;
			DEALLOCATE c;
		END TRY
		BEGIN CATCH
			DECLARE @err VARCHAR(2000);
			SET @err = ERROR_MESSAGE() + ' at line ' + CAST (ERROR_LINE() AS VARCHAR(5)) + ' in ' + ERROR_PROCEDURE();
			RAISERROR (@err, 16, 10);
		END CATCH;
	END;
END;
GO