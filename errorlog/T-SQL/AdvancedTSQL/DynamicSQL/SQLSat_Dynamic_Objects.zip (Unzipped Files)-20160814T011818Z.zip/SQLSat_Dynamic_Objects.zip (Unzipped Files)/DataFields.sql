/*
********************************************************************************************************************
Object: DataFields
Description: List of fields in each view.  Sort and column width and position, possibly header type could
	be added as columns and were removed for simplification.
Author: Dan Holmes 
	dnhlms@gmail.com
	sql.dnhlms.com
Part of:
	The Last Mile:  Dynamically Created Objects
	SQL Saturday 220, May 18th Atlanta
	SQL Saturday 521, May 21th Atlanta
2016-05-18
********************************************************************************************************************
*/
CREATE TABLE dbo.DataFields(
	ID INT IDENTITY(1,1) NOT NULL,
	FieldName VARCHAR(255) NOT NULL,
	Description VARCHAR(255) NOT NULL,
	CONSTRAINT PK_DataFields PRIMARY KEY CLUSTERED (ID),
	CONSTRAINT UQ_DataFields_Field UNIQUE (FieldName)
);
GO