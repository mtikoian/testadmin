/*
***********************************************************************************************************************************************
Object: DataViewFields
Description: Fields available for each defined DataView
Author: Dan Holmes 
	dnhlms@gmail.com
	sql.dnhlms.com
Part of:
	The Last Mile:  Dynamically Created Objects
	SQL Saturday 220, May 18th Atlanta
	SQL Saturday 521, May 21th Atlanta
2016-05-18
***********************************************************************************************************************************************
*/
CREATE TABLE dbo.DataViewFields(
	DataViewID  int NOT NULL,
	DataFieldID  int NOT NULL,
	Width  int NOT NULL,
	ColumnPosition INT NOT NULL,
	CONSTRAINT PK_DataViewFields PRIMARY KEY (DataViewID, DataFieldID),
	CONSTRAINT FK_DataViewFields_DataFields FOREIGN KEY(DataFieldID) REFERENCES dbo.DataFields(ID)
		ON DELETE CASCADE,
	CONSTRAINT FK_DataViewFields_DataViews FOREIGN KEY(DataViewID) REFERENCES dbo.DataViews(ID)
		ON DELETE CASCADE
);
GO