/*
********************************************************************************************************************
Object: CreateSpecializedProcedure
Description: Populate the SpecializeProcedureTable and tokens tables.  This table holds the procedure TSQL which is used
	'templated' and then processed and finally compiled into the proc actually used by the user.  There are two templates
	in this INSERT set.  One for the regular SalesOrder tables and a second one for the Enlarged versions of those same
	tables.
Author: Dan Holmes 
	dnhlms@gmail.com
	sql.dnhlms.com
Part of:
	The Last Mile:  Dynamically Created Objects
	SQL Saturday 220, May 18th Atlanta
	SQL Saturday 521, May 21th Atlanta
2016-05-18
********************************************************************************************************************
*/
DELETE FROM dbo.SpecializedProcedureTemplates ;
INSERT INTO dbo.SpecializedProcedureTemplates (SpecializedArea, ProcedureName, TemplateProcessorProcedureName, TemplateContents)
VALUES ('OrderReview_1', 'OrderReviewSpecialized_1_$v(UserName)', 'CreateSpecializedOrderReviewProcedure', '' );

-- Update the template procedure for 'Dispatch_1'
UPDATE SpecializedProcedureTemplates SET TemplateContents = '
CREATE PROCEDURE dbo.[$v(ProcedureName)]  @startdate DATETIME, @enddate DATETIME
AS
/*
This procedure was auto-created so any manual modification here will not last.  You should change the proc contents for OrderReview_1 in 
SpecializedProcedureTemplates and rebuild this procedure for each user.
*/
BEGIN
	SET NOCOUNT ON;
	SELECT soh.Comment
		, soh.DueDate
		, soh.Freight
		, soh.OnlineOrderFlag
		, soh.OrderDate
		, soh.PurchaseOrderNumber
		, soh.RevisionNumber
		, soh.SalesOrderNumber
		, soh.ShipDate
		, soh.Status
		, soh.SubTotal
		, soh.TaxAmt
		, soh.TotalDue
		, sod.CarrierTrackingNumber
		, sod.LineTotal
		, sod.ModifiedDate
		, sod.OrderQty
		, sod.SalesOrderDetailID
		, sod.UnitPrice
		, sod.UnitPriceDiscount
		, so.Category
		, so.Description
		, so.DiscountPct
		, so.EndDate
		, so.MinQty
		, so.MaxQty
		, so.StartDate
		, so.Type
		, p.Class
		, p.Color
		, p.ListPrice
		, p.Name
		, p.ProductLine
		, p.ProductNumber
		, p.Size
		, p.StandardCost
		, p.Style
		, p.Weight
		, p.WeightUnitMeasureCode
		, p.SafetyStockLevel
		, $v(StockLevel) StockLevel
		, c.AccountNumber
		, a.AddressLine1
		, a.City
		, a.PostalCode
		, $v(SpatialLocation) SpatialLocation
		, sp.StateProvinceCode
		, st.CostLastYear
		, st.SalesLastYear
		, st.SalesYTD
		, $v(LargePhoto) LargePhoto
		, $v(ThumbNailPhoto) ThumbNailPhoto
		--you can save the metadata cost that is returned to client by not including the column at all
		$v(ProductStandardCost) 
		, sm.Name ShipMethod
		, sm.ShipBase
		, sm.ShipRate
		, per.Demographics
		, per.FirstName
		, per.LastName
		, per.MiddleName
		, per.Title
	FROM Sales.SalesOrderHeader soh
	INNER JOIN Sales.SalesOrderDetail sod ON soh.SalesOrderID = sod.SalesOrderID
	LEFT JOIN Sales.SpecialOffer so ON so.SpecialOfferID = sod.SpecialOfferID
	INNER JOIN Production.Product p ON p.ProductID = sod.ProductID
	INNER JOIN Sales.Customer c ON c.CustomerID = soh.CustomerID
	INNER JOIN Person.Person per ON per.BusinessEntityID = c.PersonID
	INNER JOIN Person.Address a ON a.AddressID = soh.ShipToAddressID
	INNER JOIN Person.StateProvince sp ON sp.StateProvinceID = a.StateProvinceID
	INNER JOIN Sales.SalesTerritory st ON sp.TerritoryID = st.TerritoryID
	LEFT JOIN Production.ProductProductPhoto ppp ON ppp.ProductID = p.ProductID AND ppp.[Primary] = 1
	LEFT JOIN Production.ProductPhoto pp ON pp.ProductPhotoID = ppp.ProductPhotoID
	LEFT JOIN Purchasing.ShipMethod sm ON sm.ShipMethodID = soh.ShipMethodID
	WHERE soh.OrderDate BETWEEN @startdate AND @enddate;
END;'
WHERE SpecializedArea = 'OrderReview_1';

-- Insert the tokens for the 'Dispatch_1' template
INSERT INTO SpecializedProcedureTemplateTokens (SpecializedArea, token, datatype, value, unusedvalue)
SELECT 'OrderReview_1', 'StockLevel', 'INT'
   , 'dbo.ufnGetStock(sod.productid)'
   , 'CAST(null AS INT)'
UNION ALL
SELECT 'OrderReview_1', 'LargePhoto', 'VARBINARY(MAX)'
   , 'pp.LargePhoto'
   , 'CAST(null AS VARBINARY(MAX))'
UNION ALL
SELECT 'OrderReview_1', 'ThumbNailPhoto', 'VARBINARY(MAX)'
   , 'pp.ThumbNailPhoto'
   , 'CAST(null AS VARBINARY(MAX))'
UNION ALL
SELECT 'OrderReview_1', 'ProductStandardCost', 'MONEY'
   , ', dbo.ufnGetProductStandardCost(sod.productid, soh.OrderDate)  ProductStandardCost'
   , ''
UNION ALL
SELECT 'OrderReview_1', 'SpatialLocation', 'GEOGRAPHY'
   , 'a.SpatialLocation'
   , 'CAST(null AS GEOGRAPHY)'

INSERT INTO dbo.SpecializedProcedureTemplates (SpecializedArea, ProcedureName, TemplateProcessorProcedureName, TemplateContents)
VALUES ('OrderReviewEnlarged_1', 'OrderReviewEnlargedSpecialized_1_$v(UserName)', 'CreateSpecializedOrderReviewProcedure', '' );

-- Update the template procedure for 'Dispatch_1'
UPDATE SpecializedProcedureTemplates SET TemplateContents = '
CREATE PROCEDURE dbo.[$v(ProcedureName)]  @startdate DATETIME, @enddate DATETIME
AS
BEGIN
	SET NOCOUNT ON;
	SELECT soh.Comment
		, soh.DueDate
		, soh.Freight
		, soh.OnlineOrderFlag
		, soh.OrderDate
		, soh.PurchaseOrderNumber
		, soh.RevisionNumber
		, soh.SalesOrderNumber
		, soh.ShipDate
		, soh.Status
		, soh.SubTotal
		, soh.TaxAmt
		, soh.TotalDue
		, sod.CarrierTrackingNumber
		, sod.LineTotal
		, sod.ModifiedDate
		, sod.OrderQty
		, sod.SalesOrderDetailID
		, sod.UnitPrice
		, sod.UnitPriceDiscount
		, so.Category
		, so.Description
		, so.DiscountPct
		, so.EndDate
		, so.MinQty
		, so.MaxQty
		, so.StartDate
		, so.Type
		, p.Class
		, p.Color
		, p.ListPrice
		, p.Name
		, p.ProductLine
		, p.ProductNumber
		, p.Size
		, p.StandardCost
		, p.Style
		, p.Weight
		, p.WeightUnitMeasureCode
		, p.SafetyStockLevel
		, $v(StockLevel) StockLevel
		, c.AccountNumber
		, a.AddressLine1
		, a.City
		, a.PostalCode
		, $v(SpatialLocation) SpatialLocation
		, sp.StateProvinceCode
		, st.CostLastYear
		, st.SalesLastYear
		, st.SalesYTD
		, $v(LargePhoto) LargePhoto
		, $v(ThumbNailPhoto) ThumbNailPhoto
		, $v(ProductStandardCost) ProductStandardCost
		, sm.Name ShipMethod
		, sm.ShipBase
		, sm.ShipRate
		, per.Demographics
		, per.FirstName
		, per.LastName
		, per.MiddleName
		, per.Title
	FROM Sales.SalesOrderHeaderEnlarged soh
	INNER JOIN Sales.SalesOrderDetailEnlarged sod ON soh.SalesOrderID = sod.SalesOrderID
	LEFT JOIN Sales.SpecialOffer so ON so.SpecialOfferID = sod.SpecialOfferID
	INNER JOIN Production.Product p ON p.ProductID = sod.ProductID
	INNER JOIN Sales.Customer c ON c.CustomerID = soh.CustomerID
	INNER JOIN Person.Person per ON per.BusinessEntityID = c.PersonID
	INNER JOIN Person.Address a ON a.AddressID = soh.ShipToAddressID
	INNER JOIN Person.StateProvince sp ON sp.StateProvinceID = a.StateProvinceID
	INNER JOIN Sales.SalesTerritory st ON sp.TerritoryID = st.TerritoryID
	LEFT JOIN Production.ProductProductPhoto ppp ON ppp.ProductID = p.ProductID AND ppp.[Primary] = 1
	LEFT JOIN Production.ProductPhoto pp ON pp.ProductPhotoID = ppp.ProductPhotoID
	LEFT JOIN Purchasing.ShipMethod sm ON sm.ShipMethodID = soh.ShipMethodID
	WHERE soh.OrderDate BETWEEN @startdate AND @enddate;
END;'
WHERE SpecializedArea = 'OrderReviewEnlarged_1';

-- Insert the tokens for the 'Dispatch_1' template
INSERT INTO SpecializedProcedureTemplateTokens (SpecializedArea, token, datatype, value, unusedvalue)
SELECT 'OrderReviewEnlarged_1', 'StockLevel', 'INT'
   , 'dbo.ufnGetStock(sod.productid)'
   , 'CAST(null AS INT)'
UNION ALL
SELECT 'OrderReviewEnlarged_1', 'LargePhoto', 'VARBINARY(MAX)'
   , 'pp.LargePhoto'
   , 'CAST(null AS VARBINARY(MAX))'
UNION ALL
SELECT 'OrderReviewEnlarged_1', 'ThumbNailPhoto', 'VARBINARY(MAX)'
   , 'pp.ThumbNailPhoto'
   , 'CAST(null AS VARBINARY(MAX))'
UNION ALL
SELECT 'OrderReviewEnlarged_1', 'ProductStandardCost', 'MONEY'
   , 'dbo.ufnGetProductStandardCost(sod.productid, soh.OrderDate)'
   , 'CAST(null AS MONEY)'
UNION ALL
SELECT 'OrderReviewEnlarged_1', 'SpatialLocation', 'GEOGRAPHY'
   , 'a.SpatialLocation'
   , 'CAST(null AS GEOGRAPHY)'

GO