/*
********************************************************************************************************************
Object: CreateSpecializedProcedureForUserID
Description : Based on @UserID and @SpecializedArea get the stored procedure name and build it if it doesn't exist
Author: Dan Holmes 
	dnhlms@gmail.com
	sql.dnhlms.com
Part of:
	The Last Mile:  Dynamically Created Objects
	SQL Saturday 220, May 18th Atlanta
	SQL Saturday 521, May 21th Atlanta
2016-05-18
********************************************************************************************************************
*/
IF OBJECT_ID('GetSpecializedProcedureName') IS NOT NULL
	DROP PROC dbo.GetSpecializedProcedureName;
GO
CREATE PROC dbo.GetSpecializedProcedureName
	@UserID INT
	, @SpecializedArea VARCHAR(30)
AS 
/***************************************************************
Object: GetSpecializedProcedureName

Result set
	ProcedureName SYSNAME
****************************************************************
*/
BEGIN
	/*
	If the proc asked for doesn't exist then create it.
	*/
	DECLARE @userName VARCHAR(20), @procname SYSNAME;
	BEGIN TRY
		SELECT @username = UserName 
		FROM dbo.users 
		WHERE UserID = @UserID;
		
		SELECT @procname = REPLACE(ProcedureName, '$v(UserName)', dbo.CreateIdentifier(@Username))
		FROM dbo.SpecializedProcedureTemplates
		WHERE SpecializedArea = @SpecializedArea;

		/*
		sys.procedures
		
		The visibility of the metadata in catalog views is limited to securables that a user either owns or on which the user has been granted
		some permission. For more information, see Metadata Visibility Configuration.
		
		http://msdn.microsoft.com/en-us/library/ms188737(v=sql.105).aspx
		*/
		IF NOT EXISTS (SELECT * FROM sys.procedures WHERE name = @procname)
			EXEC dbo.CreateSpecializedProcedureForUserID @UserID, @SpecializedArea, null, null;
		SELECT @procname AS ProcedureName;
	END TRY
	BEGIN CATCH
		DECLARE @err VARCHAR(2000);
		SET @err = ERROR_MESSAGE() + ' at line ' + CAST (ERROR_LINE() AS VARCHAR(5)) + ' in ' + ERROR_PROCEDURE();
		RAISERROR (@err, 16, 10);
	END CATCH;
END;
GO