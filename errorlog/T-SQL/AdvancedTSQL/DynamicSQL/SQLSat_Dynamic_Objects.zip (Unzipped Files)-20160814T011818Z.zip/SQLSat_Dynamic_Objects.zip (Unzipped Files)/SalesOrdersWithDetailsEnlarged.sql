/*
********************************************************************************************************************
Object: SalesOrdersWithDetailsEnlarged
Description: Returns the data for the grids DataViews.  This is the before version.  None of the columns have been removed.  This
	will be what is created on-the-fly by the knowledge about what columns are for what views and what view are for which user.
	This is the same set of columns, joins and predicate as SalesOrdersWithDetails proc.  This one was built to show the 
	difference when a much larger dataset is returned.
Author: Dan Holmes 
	dnhlms@gmail.com
	sql.dnhlms.com
Part of:
	The Last Mile:  Dynamically Created Objects
	SQL Saturday 220, May 18th Atlanta
	SQL Saturday 521, May 21th Atlanta
2016-05-18
********************************************************************************************************************
*/
IF EXISTS(SELECT * FROM sys.procedures WHERE name = 'SalesOrdersWithDetailsEnlarged ')
	DROP PROCEDURE dbo.SalesOrdersWithDetailsEnlarged ;
GO
CREATE PROCEDURE dbo.SalesOrdersWithDetailsEnlarged @startdate DATETIME, @enddate DATETIME
AS
BEGIN
	SET NOCOUNT ON;
	SELECT soh.Comment
		, soh.DueDate
		, soh.Freight
		, soh.OnlineOrderFlag
		, soh.OrderDate
		, soh.PurchaseOrderNumber
		, soh.RevisionNumber
		, soh.SalesOrderNumber
		, soh.ShipDate
		, soh.Status
		, soh.SubTotal
		, soh.TaxAmt
		, soh.TotalDue
		, sod.CarrierTrackingNumber
		, sod.LineTotal
		, sod.ModifiedDate
		, sod.OrderQty
		, sod.SalesOrderDetailID
		, sod.UnitPrice
		, sod.UnitPriceDiscount
		, so.Category
		, so.Description
		, so.DiscountPct
		, so.EndDate
		, so.MinQty
		, so.MaxQty
		, so.StartDate
		, so.Type
		, p.Class
		, p.Color
		, p.ListPrice
		, p.Name
		, p.ProductLine
		, p.ProductNumber
		, p.Size
		, p.StandardCost
		, p.Style
		, p.Weight
		, p.WeightUnitMeasureCode
		, p.SafetyStockLevel
		, dbo.ufnGetStock(sod.productid) StockLevel
		, c.AccountNumber
		, a.AddressLine1
		, a.City
		, a.PostalCode
		, a.SpatialLocation
		, sp.StateProvinceCode
		, st.CostLastYear
		, st.SalesLastYear
		, st.SalesYTD
		, pp.LargePhoto
		, pp.ThumbNailPhoto
		, dbo.ufnGetProductStandardCost(sod.productid, soh.OrderDate) ProductStandardCost
		, sm.Name ShipMethod
		, sm.ShipBase
		, sm.ShipRate
		, per.Demographics
		, per.FirstName
		, per.LastName
		, per.MiddleName
		, per.Title
	FROM Sales.SalesOrderHeaderEnlarged soh
	INNER JOIN Sales.SalesOrderDetailEnlarged sod ON soh.SalesOrderID = sod.SalesOrderID
	LEFT JOIN Sales.SpecialOffer so ON so.SpecialOfferID = sod.SpecialOfferID
	INNER JOIN Production.Product p ON p.ProductID = sod.ProductID
	INNER JOIN Sales.Customer c ON c.CustomerID = soh.CustomerID
	INNER JOIN Person.Person per ON per.BusinessEntityID = c.PersonID
	INNER JOIN Person.Address a ON a.AddressID = soh.ShipToAddressID
	INNER JOIN Person.StateProvince sp ON sp.StateProvinceID = a.StateProvinceID
	INNER JOIN Sales.SalesTerritory st ON sp.TerritoryID = st.TerritoryID
	LEFT JOIN Production.ProductProductPhoto ppp ON ppp.ProductID = p.ProductID AND ppp.[Primary] = 1
	LEFT JOIN Production.ProductPhoto pp ON pp.ProductPhotoID = ppp.ProductPhotoID
	LEFT JOIN Purchasing.ShipMethod sm ON sm.ShipMethodID = soh.ShipMethodID
	WHERE soh.OrderDate BETWEEN @startdate AND @enddate;
END;
GO