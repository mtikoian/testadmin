/*
********************************************************************************************************************
Object: SpecializedProcedureTemplateTokens
	This holds the tokens that are valid for each template area.	
	More description is available in the SpecializedProcedureTemplates table definition.
Author: Dan Holmes 
	dnhlms@gmail.com
	sql.dnhlms.com
Part of:
	The Last Mile:  Dynamically Created Objects
	SQL Saturday 220, May 18th Atlanta
	SQL Saturday 521, May 21th Atlanta
2016-05-18
********************************************************************************************************************
*/
CREATE TABLE dbo.SpecializedProcedureTemplateTokens
(
	SpecializedArea VARCHAR(30)
	--this is the value to be searched for.  The $v() syntax is not included.  It is only the variable name
	--There are two reserved tokens:  UserName and ProcedureName.  Those are used by the template procs to 
	--create the name of the procedure.  Don't use those here or they will not get replaced as the replacement for
	--those happens earlier in the process.  in fact any usage of those values in here will very likely result in 
	--an incorrect replacement.
	, token varchar(255)
	--the datatype in SQL syntax form.  INT, VARCHAR(200), ...
	--This currently isn't used but if there is a need for temp tables or casting, the value here would be necessary
	, datatype varchar(15)
	--this is the replacement value when the value is to be used.
	, value varchar(MAX)
	--this is the replacement value when the value is not to be used.
	, unusedvalue varchar(MAX)
	, CONSTRAINT PK_SpecializedProcedureTemplateTokens PRIMARY KEY (SpecializedArea, Token)
	, CONSTRAINT FK_SpecializedProcedureTemplateTokens_SpecializedProcedureTemplates
		FOREIGN KEY (SpecializedArea)
		REFERENCES SpecializedProcedureTemplates (SpecializedArea)
		ON DELETE CASCADE
);
GO