/*
********************************************************************************************************************
Object: CreateSpecializedProcedure
Description: 	This was created to supply a mechanism to create and apply stored procs specific to the users Order Review
	requirements.  It has been implemented such that this scaffolding could be used in other areas of the app.
	
	Currently the only processing for the template is value replacements $v(?).  Those are simple lookup and replace
	actions.  Others could be the results of function calls $f(?,?) or anything else that could be dreamed up (loops, conditionals,...).
Author: Dan Holmes 
	dnhlms@gmail.com
	sql.dnhlms.com
Part of:
	The Last Mile:  Dynamically Created Objects
	SQL Saturday 220, May 18th Atlanta
	SQL Saturday 521, May 21th Atlanta
2016-05-18
********************************************************************************************************************
*/
CREATE TABLE dbo.SpecializedProcedureTemplates
(
	--contains the name of the area that will be templated.  the only value
	--currently defined is 'Dispatch'.  That is the proc that is created
	--per user based on the views he is currently viewing.
	SpecializedArea VARCHAR(30) NOT NULL PRIMARY KEY
	--This is the name of the procedure that will be created.  It is marked up with a 
	--$v(Username) token.  That value is replaced with the username at runtime.
	--128 is the maximum length of a db object
	, ProcedureName SYSNAME NOT NULL
	--this is the stored procedure that is marked up.  The first mark up is the procedure name $v(procedurename).
	--other tokens are defined by the processor
	, TemplateContents VARCHAR(MAX) NOT NULL
	--this is the name of the proc what will process the templatecontents.
	--this proc has a definition of 
		--@ContextStr VARCHAR(255)	
		--, @UserID INT 
		--, @Operation VARCHAR(200)
		--, @Data VARCHAR(MAX)
		--, @proccontents VARCHAR(MAX) OUTPUT
	--each of those values are passed from the Specialized entry point - spCreateSpecializedProcedure.
	--the called proc uses those along with its own logic to complete the template processing and compile
	--the object.
	, TemplateProcessorProcedureName SYSNAME NOT NULL
);
GO
