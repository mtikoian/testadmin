/*
********************************************************************************************************************
Object: CreateSpecializedProcedure
Description: This is the UI's entry point.  For proc creation.  It may never use this proc as it should first call
	GetSpecializedProcName first.  That will return the proc name and create it if it doesn't exist.  That would bypass
	the need for a call to this proc.
Author: Dan Holmes 
	dnhlms@gmail.com
	sql.dnhlms.com
Part of:
	The Last Mile:  Dynamically Created Objects
	SQL Saturday 220, May 18th Atlanta
	SQL Saturday 521, May 21th Atlanta
2016-05-18
********************************************************************************************************************
*/
IF OBJECT_ID('CreateSpecializedProcedure') IS NOT NULL
	DROP PROC dbo.CreateSpecializedProcedure;
GO
CREATE PROC dbo.CreateSpecializedProcedure
	/*
	Production code from which this is dervied has a ContextStr parameter as the first of every proc.  That string supplies the DB
	with data like the user's id and other information.  that removes the need for a UserID and other parameters for each proc.  This
	is why there is a CreateSpecializedProcedureForUserID proc.  Since the UserID isn't supplied, it wouldn't be possible to create a 
	proc for anyone other than the caller.  That is necessary in the situation that the current user changed a public view.  That proc 
	also doesn't return the name of each proc created.  only the UI in interested in that information.
	--@contextstr VARCHAR(255)
	*/
	--SpecializedProcedureTemplates.SpecializedArea
	@SpecializedArea VARCHAR(30)
	--Users.UserID
	, @UserID INT
	/*
	Called in response to what UI action?
	OPEN_VIEW - An existing view was added to the current list
	CLOSE_VIEW - An existing view was removed from the current list
	MODIFY_VIEW - A view is modified or created.
	*/
	, @Operation VARCHAR(200)
	/*
	For current actions this is the DataView.ID value.  As the Operation values are expanded, these values could 
	also expand to accomodate those values too.  You can get more specific but not more generic.
	*/
	, @Data VARCHAR(MAX)
AS
/*
	The ProcName just created is returned.  
*/ 
BEGIN
	/*
	This is the UI entry point.  The call is forwarded to the proc with the userid supplied.  That proc doesn't return the proc name
	generated.  Only the UI is interested in that data.  For other actions internally (db wise) the ForUserID proc is used.
	
	The UI wants to compile 'my' views (UID from context str).  In the db however, the context string doesn't help with knowing who to compile 
	for because it can compile other procs based on what data caused the recompile.  In that case the context string is still the context of 
	the original caller but the user to compile for is different.
	*/
	BEGIN TRY
		EXEC dbo.CreateSpecializedProcedureForUserID @UserID, @SpecializedArea, @Operation, @Data;
		--return the name of the proc just created.
		EXEC dbo.GetSpecializedProcedureName @UserID, @SpecializedArea;
	END TRY
	BEGIN CATCH
		DECLARE @msg VARCHAR(2000);
		SET @msg = ERROR_MESSAGE() + ' in ' + ERROR_PROCEDURE() + ' at line: ' + CAST(ERROR_LINE() AS VARCHAR(5));
		RAISERROR(@msg, 16,10);
	END CATCH;
END;
GO