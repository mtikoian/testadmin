/*
********************************************************************************************************************
Object: DataViews
Description:  Defines the name and owning user of the dataviews available to each user.
	The table not created in this demo is the one that would contain which views the user currently has open.  the 
	current implementation uses this table and assumes all views created are open.  A more realistic scenario would
	be to build the procs based on what the user has open and not everything that is defined.
Author: Dan Holmes 
	dnhlms@gmail.com
	sql.dnhlms.com
Part of:
	The Last Mile:  Dynamically Created Objects
	SQL Saturday 220, May 18th Atlanta
	SQL Saturday 521, May 21th Atlanta
2016-05-18
********************************************************************************************************************
*/
CREATE TABLE dbo.DataViews(
	ID INT NOT NULL CONSTRAINT PK_DataViews PRIMARY KEY (ID),
	Caption VARCHAR(255) NOT NULL
		CONSTRAINT UQ_DataViews_User_Description UNIQUE (Caption, UserID),
	UserID INT NULL,
	--public views are not owned can be opened by any user.  Yes it would also be possible to allow
	--the NULL userid to define public but you might want to restrict modification of a view to the user
	--that created it so that would mean that UserID could be NOT NULL and this column is then required.
	PublicView BIT NOT NULL,
	CONSTRAINT FK_DataViews_Users FOREIGN KEY (UserID) REFERENCES dbo.Users(UserID)
);
GO