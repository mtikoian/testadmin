/*
********************************************************************************************************************
Object: CreateSpecializedProcedureForUserID
Author: Dan Holmes 
	dnhlms@gmail.com
	sql.dnhlms.com
Part of:
	The Last Mile:  Dynamically Created Objects
	SQL Saturday 220, May 18th Atlanta
	SQL Saturday 521, May 21th Atlanta
2016-05-18
********************************************************************************************************************
*/
IF OBJECT_ID('CreateSpecializedProcedureForUserID') IS NOT NULL
	DROP PROC dbo.CreateSpecializedProcedureForUserID;
GO
CREATE PROC dbo.CreateSpecializedProcedureForUserID
	@UserID            INT
	, @SpecializedArea   VARCHAR(30)
	, @Operation         VARCHAR(200)
	, @Data              VARCHAR(MAX)
AS 
/**********************************************************************************************************************
Object:
	CreateSpecializedProcedureForUserID

Description:
	SpecializedProcedureTemplates is the table that has the template for the Area that is being Specialized. First
	retrieve the template and replace the known tokens for the name $v(UserName). Prep a drop statement and forward 
	the template to the procedure that will process the template. Upon return execute the DROP and CREATE statements.  

	The template should include the code to create the proc. The drop will be created automatically based on the name.

	The Template Processor name is in the same table.

	Tokens look like $v(tokenname). That is a value token and is a simple replace. Other tokens (not currently 
	implemented) may call functions or invoke loops or conditional logic.

	The difference in purpose of this proc against CreateSpecializedProcedure, is that in the production code which this 
	is based on, the userid isn't supplied to the latter.  Only a 'context' string which contains id of the logged in user.
	Then because the user could modify a public view, the remaining user's procedures would have to be recompiled on their
	behalf.  This proc can then be called specifying the userid so a proc for a specific user an not just the one
	from the context string could be built. 
**********************************************************************************************************************/
BEGIN
	DECLARE @dropproc VARCHAR(1000)
		, @proccontents VARCHAR(MAX)
		, @procname VARCHAR(200)
		, @userName VARCHAR(20)
		, @TemplateProcessorProcedureName NVARCHAR(200)
		, @debug INT = 0
		;
	BEGIN TRY
		SELECT @username = UserName FROM dbo.Users WHERE UserID = @UserID;
		SELECT @proccontents  = TemplateContents
			, @procname = REPLACE(ProcedureName, '$v(UserName)', dbo.CreateIdentifier(@username))
			--notice the calling paramter list here is standardized.  Each different template processor
			--will need to implement this interface to be called correctly.
			, @TemplateProcessorProcedureName = N'EXEC ' + TemplateProcessorProcedureName + N' @UserID, @SpecializedArea, @Operation, @data, @proccontents OUTPUT;'
		FROM dbo.SpecializedProcedureTemplates
		WHERE SpecializedArea = @SpecializedArea;

		SET @proccontents = REPLACE(@proccontents, '$v(ProcedureName)', @ProcName);
		SET @dropproc =	'IF EXISTS (SELECT * FROM sys.procedures WHERE name = '''+ @procname + ''') DROP PROCEDURE '+ @procname + ';';
		--forward the formatting to the Template Processor.
		EXEC sp_executesql @TemplateProcessorProcedureName
			, N'@UserID INT, @SpecializedArea VARCHAR(30), @Operation VARCHAR(255), @data VARCHAR(MAX), @proccontents VARCHAR(MAX) OUTPUT'
			, @UserID, @SpecializedArea, @Operation, @data, @proccontents OUTPUT
			;
IF @debug = 1
BEGIN
	PRINT @dropproc;
	PRINT @proccontents;
END;
		EXEC (@dropproc);
		EXEC (@proccontents);
	END TRY
	BEGIN CATCH
		DECLARE @msg VARCHAR(2000);
		SET @msg = ERROR_MESSAGE() + ' in ' + ERROR_PROCEDURE() + ' at line: ' + CAST(ERROR_LINE() AS VARCHAR(5));
		RAISERROR(@msg, 16,10);
	END CATCH;
END;
GO