/*
********************************************************************************************************************
Object: Worksheet
Description: Walkthrough of each step as a demo
Author: Dan Holmes 
	dnhlms@gmail.com
	sql.dnhlms.com
Part of:
	The Last Mile:  Dynamically Created Objects
	SQL Saturday 220, May 18th Atlanta
	SQL Saturday 521, May 21th Atlanta
2016-05-18
********************************************************************************************************************
*/
--set even though there is a spatial column returned we can't Discard results for the connection because that also discards IO and TIME data
--DROP INDEX [IX_SalesOrderHeader_OrderDate] ON [Sales].[SalesOrderHeader] ;
SET STATISTICS IO, TIME ON;
SELECT * FROM Sales.SalesOrderHeader
--check the plan
EXEC dbo.SalesOrdersWithDetails '2014-06-01 00:00:00.000', '2014-06-30 00:00:00.000'
--first pass DBA creates a new index.  (the purpose of this index isn't intended to fix everything just an example of a non-invasive fix)
CREATE NONCLUSTERED INDEX [IX_SalesOrderHeader_OrderDate] ON [Sales].[SalesOrderHeader] 
(OrderDate) INCLUDE (TotalDue); 
/*************************

Changes get applied
apply_all_objects.sql
Creates 3 views:  Shipping which is public
Dan(1): private and drops the spatial column, and UDFs stocklevel and productStandardCost. Keep the images
Sean(2): private and drops what Dan's did and the images.

populate_dataviews.sql
*************************/
--new changes added such that the procedures for the application.  the application now calls the proc that 
--is created dynamically.  This shows -the dynamic creation of the first call for dan and sean
DECLARE @userID INT = 1;  --dan
EXEC dbo.CreateSpecializedProcedure 'OrderReview_1', @userID, 'OPEN_VIEW', 1;
SET @userID = 2; --Sean
EXEC dbo.CreateSpecializedProcedure 'OrderReview_1', @userID, 'OPEN_VIEW', 1;

EXEC dbo.GetSpecializedProcedureName 2, 'OrderReview_1';

SET STATISTICS IO, TIME ON;
EXEC dbo.SalesOrdersWithDetails '2014-06-01 00:00:00.000', '2014-06-30 00:00:00.000'

EXEC dbo.OrderReviewSpecialized_1_Dan  '2014-06-01 00:00:00.000', '2014-06-30 00:00:00.000'

EXEC dbo.OrderReviewSpecialized_1_Sean '2014-06-01 00:00:00.000', '2014-06-30 00:00:00.000'
SET STATISTICS IO, TIME OFF

--the data in the provided tables is small.  Using the script from Jonathan Kehayias to enlarge the sales order tables.
--add the same index as the one added earlier
--CREATE NONCLUSTERED INDEX [IX_SalesOrderHeaderEnlarged_OrderDate] ON [Sales].[SalesOrderHeaderEnlarged] 
--(OrderDate) INCLUDE (TotalDue) ;
EXEC dbo.SalesOrdersWithDetailsEnlarged '2014-06-01 00:00:00.000', '2014-06-30 00:00:00.000'
SET STATISTICS IO, TIME OFf;

--now do the same
DECLARE @userID INT = 1;  --dan
EXEC dbo.CreateSpecializedProcedure 'OrderReviewEnlarged_1', @userID, 'OPEN_VIEW', 1;
SET @userID =2; --Sean
EXEC dbo.CreateSpecializedProcedure 'OrderReviewEnlarged_1', @userID, 'OPEN_VIEW', 1;

SET STATISTICS IO, TIME ON;
EXEC dbo.SalesOrdersWithDetailsEnlarged '2014-06-01 00:00:00.000', '2014-06-30 00:00:00.000'

EXEC dbo.OrderReviewEnlargedSpecialized_1_Dan  '2014-06-01 00:00:00.000', '2014-06-30 00:00:00.000'

EXEC dbo.OrderReviewEnlargedSpecialized_1_Sean '2014-06-01 00:00:00.000', '2014-06-30 00:00:00.000'


--at an upgrade for bugfix you have UPDATE the data in the Specialized table(s).  once that is done
--you then DROP all the procs.  if after hours leave it alone they will get a new proc in th e morning.  if
--systems are still active, you can immediately recreate the proc just like the users do.  Iterate over all the 
--users with dataview and call CreateSpecializedProcedure
DECLARE @n SYSNAME;
DECLARE c CURSOR FOR SELECT name FROM sys.procedures WHERE name LIKE '%Specialized_1%';
OPEN c;
WHILE 1=1
BEGIN
	FETCH NEXT FROM c INTO @n;
	IF @@FETCH_STATUS <> 0 BREAK;
	EXEC('DROP PROCEDURE dbo.' + @n);
END;
CLOSE c;DEALLOCATE c;