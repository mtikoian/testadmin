/*
********************************************************************************************************************
Object: apply_all_objects.sql
Description:  file that will execute all the objects in the correct order.  You must set SQLCMD mode on.  Alt-Q,m.
	in addition, the server name on line 17 should be changed as well as the directory containing all the code at 
	line 31
Author: Dan Holmes 
	dnhlms@gmail.com
	sql.dnhlms.com
Part of:
	The Last Mile:  Dynamically Created Objects
	SQL Saturday 220, May 18th Atlanta
	SQL Saturday 521, May 21th Atlanta
2016-05-18
********************************************************************************************************************
*/
:connect .\sql2014
USE AdventureWorks2014
DROP PROCEDURE dbo.CreateSpecializedOrderReviewProcedure;
DROP PROCEDURE dbo.CreateSpecializedProcedure;
DROP PROCEDURE dbo.CreateSpecializedProcedureForUserID
DROP PROCEDURE dbo.GetSpecializedProcedureName;
DROP PROCEDURE dbo.SalesOrdersWithDetails;
DROP FUNCTION dbo.CreateIdentifier;
DROP TABLE dbo.SpecializedProcedureTemplateTokens;
DROP TABLE dbo.SpecializedProcedureTemplates;
DROP TABLE dbo.DataViewFields;
DROP TABLE dbo.DataViews;
DROP TABLE dbo.DataFields;
DROP TABLE dbo.Users;

:setvar p D:\Sandbox\SQLSat_Dynamic_Objects\
:r $(p)Users.sql
:r $(p)DataFields.sql
:r $(p)DataViews.sql
:r $(p)DataViewFields.sql
:r $(p)SpecializedProcedureTemplates.sql
:r $(p)SpecializedProcedureTemplateTokens.sql
:r $(p)CreateIdentifier.sql
:r $(p)SalesOrdersWithDetails.sql
:r $(p)SalesOrdersWithDetailsEnlarged.sql
:r $(p)CreateSpecializedProcedureForUserID.sql
:r $(p)GetSpecializedProcedureName.sql
:r $(p)CreateSpecializedProcedure.sql
:r $(p)CreateSpecializedOrderReviewProcedure.sql
:r $(p)Populate_Dataview.sql
:r $(p)Populate_SpecializedTables.sql
