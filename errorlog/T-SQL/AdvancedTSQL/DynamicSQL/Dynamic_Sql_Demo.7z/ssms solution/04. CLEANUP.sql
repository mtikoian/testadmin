
/*
	Dynamic Sql. Not so scary?

		04. DELETE TEMP OBJECTS
*/

USE master;

DECLARE
	@SQL			VARCHAR(MAX),
	@CURSOR			INT = 1,
	@DATABASENAME	SYSNAME,
	@PROCESSID		INT;

DECLARE
	@DATABASES TABLE
	(
		ID INT IDENTITY(1, 1) NOT NULL,
		DATABASENAME SYSNAME
	);

INSERT INTO @DATABASES
SELECT DISTINCT
	tarDatabase
FROM
	dbo.dynamic_Sql_Import_Settings
WHERE
	ISNULL(dropExisting, 1) = 1
AND DB_ID(tarDatabase) IS NOT NULL;

WHILE @CURSOR <= (SELECT COUNT(1) FROM @DATABASES)
BEGIN;

SELECT
	@DATABASENAME = DATABASENAME
FROM
	@DATABASES
WHERE
	ID = @CURSOR;

BEGIN;--SHUT DOWN ANY OPEN CONNECTIONS ON THE DATABASE

SELECT  
	@PROCESSID = MIN(spid)
FROM    
	master.dbo.sysprocesses
WHERE   
	dbid = DB_ID(@DATABASENAME);

WHILE @processid IS NOT NULL 
BEGIN;
        
	EXEC ('KILL ' + @PROCESSID);

	SELECT  
		@PROCESSID = MIN(spid)
	FROM    
		master.dbo.sysprocesses
	WHERE   
		dbid = DB_ID(@DATABASENAME);

END;

END;--SHUT DOWN ANY OPEN CONNECTIONS ON THE DATABASE

SET @Sql = 
	'DROP DATABASE [' + @DATABASENAME + '];';
EXEC (@Sql);

SET @CURSOR += 1;

END;

IF OBJECT_ID('dbo.dynamic_Sql_Import_Settings') IS NOT NULL
	DROP TABLE dbo.dynamic_Sql_Import_Settings;
GO

IF OBJECT_ID('dbo.dynamic_Sql_Import') IS NOT NULL
	DROP PROCEDURE dbo.dynamic_Sql_Import;
GO

IF OBJECT_ID('dbo.dynamic_InsertRequest') IS NOT NULL
	DROP PROCEDURE dbo.dynamic_InsertRequest;
GO