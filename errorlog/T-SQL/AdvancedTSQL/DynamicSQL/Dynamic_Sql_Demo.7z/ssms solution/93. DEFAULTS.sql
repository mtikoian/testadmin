USE [Northwind];

IF OBJECT_ID('TEMPDB..##DYNAMIC_DEFAULTS') IS NOT NULL
	DROP TABLE ##DYNAMIC_DEFAULTS;

CREATE TABLE ##DYNAMIC_DEFAULTS
(
	Id					INT IDENTITY(1,1),
	FullObjectName		VARCHAR(500),
	ColumnName			SYSNAME,
	DefaultConstraint	VARCHAR(MAX)
);

WITH CTE AS (
SELECT
	FullObjectName				= '[' + SCHEMA_NAME(schema_id) + '].[' + t.name + ']',
	ColumnName					= c.name,
	DefaultConstraint			= ISNULL(dc.name, ''),
	DefaultConstraintValue		= ISNULL(dc.definition, '')
FROM
	sys.tables t
INNER JOIN
	sys.columns c
ON
	t.object_id = c.object_id
INNER JOIN
	(
		SELECT 
			name, 
			parent_object_id,
			parent_column_id ,
			definition
		FROM 
			sys.default_constraints 
	) dc
ON
	t.object_id = dc.parent_object_id
AND	c.column_id = dc.parent_column_id
WHERE
	ISNULL(dc.name, '') <> '')
INSERT INTO ##DYNAMIC_DEFAULTS
SELECT
	FullObjectName,
	ColumnName,
	DefaultConstraint	= 
		'ALTER TABLE ' + FullObjectName + ' ADD  CONSTRAINT [' + DefaultConstraint + ']  DEFAULT ' + DefaultConstraintValue + ' FOR [' + ColumnName + '];' 
		+ CHAR(10)
FROM
	CTE;

SELECT * FROM ##DYNAMIC_DEFAULTS;