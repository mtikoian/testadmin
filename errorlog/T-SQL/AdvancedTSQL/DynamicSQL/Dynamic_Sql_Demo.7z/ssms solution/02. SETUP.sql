
/*
	Dynamic Sql. Not so scary?
		0. CREATE DEMO PROCEDURE
*/

USE master;

IF OBJECT_ID('dbo.dynamic_Sql_Import') IS NOT NULL
	DROP PROCEDURE dbo.dynamic_Sql_Import;
GO

CREATE PROCEDURE dbo.dynamic_Sql_Import(@JobId INT = NULL)
AS

BEGIN;

SET NOCOUNT ON;

BEGIN;--DECLARE VARIABLES

DECLARE
	@srcDatabase		SYSNAME,
	@tarDatabase		SYSNAME,
	@dropExisting		INT,
	@exeQueryType		VARCHAR(10),
	@exeShowCoreScripts	INT,
	@exeFullImport		INT,
	@exeTableImport		INT,
	@exeTablePKImport	INT,
	@exeTableDFImport	INT,
	@exeTableCKImport	INT,
	@exeTableFKImport	INT,
	@exeTableIXImport	INT,
	@exeViewImport		INT,
	@exeFunctionImport	INT,
	@exeProcedureImport	INT,
	@exeTriggerImport	INT,
	@exeSampleSize		INT,
	@exeCursorT			INT,
	@exeCursorDF		INT,
	@exeCursorCK		INT,
	@exeCursorFK		INT,
	@exeCursorIX		INT,
	@processid			INT,
	@device_directory	NVARCHAR(MAX),
	@EXEC				VARCHAR(MAX),
	@Sql				VARCHAR(MAX),
	@Sql_Types			VARCHAR(MAX),
	@Sql_Schemas		VARCHAR(MAX),
	@Sql_Tables			VARCHAR(MAX),
	@Sql_PKeys			VARCHAR(MAX),
	@Sql_Defaults		VARCHAR(MAX),
	@Sql_CKConstraints	VARCHAR(MAX),
	@Sql_FKConstraints	VARCHAR(MAX),
	@Sql_Indexes		VARCHAR(MAX),
	@IndexName			VARCHAR(MAX),
	@IndexType			VARCHAR(20),
	@Sql_PModules		VARCHAR(MAX),
	@Sql_VModules		VARCHAR(MAX),
	@Sql_FModules		VARCHAR(MAX),
	@Sql_TModules		VARCHAR(MAX),
	@Cursor				INT,
	@Cursor2			INT,
	@TableName			SYSNAME;

END;--DECLARE VARIABLES

BEGIN;--CHECK FOR PREDEFINED JOB ID

IF @JobId IS NULL
SELECT TOP (1)
	@srcDatabase		= srcDatabase,
	@tarDatabase		= tarDatabase,
	@dropExisting		= dropExisting,
	@exeQueryType		= exeQueryType,
	@exeShowCoreScripts = exeShowCoreScripts,
	@exeFullImport		= exeFullImport,
	@exeTableImport		= exeTableImport,
	@exeTablePKImport	= exeTablePKImport,
	@exeTableDFImport	= exeTableDFImport,
	@exeTableCKImport	= exeTableCKImport,
	@exeTableFKImport	= exeTableFKImport,
	@exeTableIXImport	= exeTableIXImport,
	@exeViewImport		= exeViewImport,
	@exeFunctionImport	= exeFunctionImport,
	@exeProcedureImport = exeProcedureImport,
	@exeTriggerImport	= exeTriggerImport,
	@exeSampleSize		= exeSampleSize
FROM
	dbo.dynamic_Sql_Import_Settings
ORDER BY
	id DESC;
ELSE
SELECT TOP (1)
	@srcDatabase		= srcDatabase,
	@tarDatabase		= tarDatabase,
	@dropExisting		= dropExisting,
	@exeQueryType		= exeQueryType,
	@exeShowCoreScripts = exeShowCoreScripts,
	@exeFullImport		= exeFullImport,
	@exeTableImport		= exeTableImport,
	@exeTablePKImport	= exeTablePKImport,
	@exeTableDFImport	= exeTableDFImport,
	@exeTableCKImport	= exeTableCKImport,
	@exeTableFKImport	= exeTableFKImport,
	@exeTableIXImport	= exeTableIXImport,
	@exeViewImport		= exeViewImport,
	@exeFunctionImport	= exeFunctionImport,
	@exeProcedureImport = exeProcedureImport,
	@exeTriggerImport	= exeTriggerImport,
	@exeSampleSize		= exeSampleSize
FROM
	dbo.dynamic_Sql_Import_Settings
WHERE
	id  = @JobId;

END;--CHECK FOR PREDEFINED JOB ID

BEGIN;--CLEAN THE SUPPLIED PARAMETERS

SELECT
	@exeShowCoreScripts	= ISNULL(@exeShowCoreScripts, 1),
	@srcDatabase		= REPLACE(REPLACE(LTRIM(RTRIM(ISNULL(@srcDatabase, ''))), '[', ''), ']', ''),
	@tarDatabase		= REPLACE(REPLACE(LTRIM(RTRIM(ISNULL(@tarDatabase, ''))), '[', ''), ']', ''),
	@dropExisting		= ISNULL(@dropExisting, 0),
	@exeQueryType		= ISNULL(@exeQueryType, 'SYNTAX'),
	@exeFullImport		= ISNULL(@exeFullImport, CASE WHEN @exeQueryType = 'SYNTAX' THEN 1 ELSE 0 END),
	@exeTableImport		= ISNULL(@exeTableImport, CASE WHEN @exeQueryType = 'SYNTAX' THEN 1 ELSE 0 END),
	@exeTablePKImport	= ISNULL(@exeTablePKImport, CASE WHEN @exeQueryType = 'SYNTAX' THEN @exeTableImport ELSE 0 END),
	@exeTableDFImport	= ISNULL(@exeTableDFImport, CASE WHEN @exeQueryType = 'SYNTAX' THEN @exeTableImport ELSE 0 END),
	@exeTableCKImport	= ISNULL(@exeTableCKImport, CASE WHEN @exeQueryType = 'SYNTAX' THEN @exeTableImport ELSE 0 END),
	@exeTableFKImport	= ISNULL(@exeTableFKImport, CASE WHEN @exeQueryType = 'SYNTAX' THEN @exeTableImport ELSE 0 END),
	@exeTableIXImport	= ISNULL(@exeTableIXImport, CASE WHEN @exeQueryType = 'SYNTAX' THEN @exeTableImport ELSE 0 END),
	@exeViewImport		= ISNULL(@exeViewImport, CASE WHEN @exeQueryType = 'SYNTAX' THEN 1 ELSE 0 END),
	@exeFunctionImport	= ISNULL(@exeFunctionImport, CASE WHEN @exeQueryType = 'SYNTAX' THEN 1 ELSE 0 END),
	@exeProcedureImport	= ISNULL(@exeProcedureImport, CASE WHEN @exeQueryType = 'SYNTAX' THEN 1 ELSE 0 END),
	@exeTriggerImport	= ISNULL(@exeTriggerImport, CASE WHEN @exeQueryType = 'SYNTAX' THEN 1 ELSE 0 END),
	@exeSampleSize		= ISNULL(@exeSampleSize, 2);

SELECT
	@exeTablePKImport	= CASE WHEN @exeTableImport = 0 THEN 0 ELSE @exeTablePKImport END,
	@exeTableDFImport	= CASE WHEN @exeTableImport = 0 THEN 0 ELSE @exeTableDFImport END,
	@exeTableCKImport	= CASE WHEN @exeTableImport = 0 THEN 0 ELSE @exeTableCKImport END,
	@exeTableFKImport	= CASE WHEN @exeTableImport = 0 THEN 0 ELSE @exeTableFKImport END,
	@exeTableIXImport	= CASE WHEN @exeTableImport = 0 THEN 0 ELSE @exeTableIXImport END,
	@exeViewImport		= CASE WHEN @exeTableImport = 0 THEN 0 ELSE @exeViewImport END;

SELECT
	@exeTableImport		= CASE WHEN @exeFullImport = 1 THEN 1 ELSE @exeTableImport END,
	@exeTablePKImport	= CASE WHEN @exeFullImport = 1 THEN 1 ELSE @exeTablePKImport END,
	@exeTableDFImport	= CASE WHEN @exeFullImport = 1 THEN 1 ELSE @exeTableDFImport END,
	@exeTableCKImport	= CASE WHEN @exeFullImport = 1 THEN 1 ELSE @exeTableCKImport END,
	@exeTableFKImport	= CASE WHEN @exeFullImport = 1 THEN 1 ELSE @exeTableFKImport END,
	@exeTableIXImport	= CASE WHEN @exeFullImport = 1 THEN 1 ELSE @exeTableIXImport END,
	@exeViewImport		= CASE WHEN @exeFullImport = 1 THEN 1 ELSE @exeViewImport END,
	@exeFunctionImport	= CASE WHEN @exeFullImport = 1 THEN 1 ELSE @exeFunctionImport END,
	@exeProcedureImport	= CASE WHEN @exeFullImport = 1 THEN 1 ELSE @exeProcedureImport END,
	@exeTriggerImport	= CASE WHEN @exeFullImport = 1 THEN 1 ELSE @exeTriggerImport END;

END;--CLEAN THE SUPPLIED PARAMETERS

BEGIN;--CHECK IF SOURCE & TARGET DATABASES HAVE BEEN SPECIFIED
IF @srcDatabase = '' OR @tarDatabase = ''
BEGIN;
	RAISERROR ('Incomplete parameters supplied!', 16, 1);
	RETURN;
END;
END;--CHECK IF SOURCE & TARGET DATABASES HAVE BEEN SPECIFIED

BEGIN;--CHECK IF TARGET DATABASE EXISTS

IF EXISTS (SELECT name FROM sysdatabases WHERE name = @tarDatabase)
BEGIN;

	--TARGET DATABASE EXISTS : CHECK IF THE OVERWRITE FLAG IS ACTIVE
	IF @dropExisting = 0
	BEGIN;
		RAISERROR ('Database already exists!', 16, 1);
		RETURN;
	END;
	
	BEGIN;--OVERWRITE FLAG IS ACTIVE : DROP THE EXISTING DATABASE

	BEGIN;--SHUT DOWN ANY OPEN CONNECTIONS ON THE DATABASE
	
	SELECT  
		@processid = MIN(spid)
	FROM    
		master.dbo.sysprocesses
	WHERE   
		dbid = DB_ID(@tarDatabase);
	
	IF @exeQueryType = 'EXECUTE'
	WHILE @processid IS NOT NULL 
	BEGIN;
        
		EXEC ('KILL ' + @processid);

		SELECT  
			@processid = MIN(spid)
		FROM    
			master.dbo.sysprocesses
		WHERE   
			dbid = DB_ID(@tarDatabase);
	END;
	
	END;--SHUT DOWN ANY OPEN CONNECTIONS ON THE DATABASE

	SET @Sql = '
DROP DATABASE [' + @tarDatabase + '];';
	IF @exeQueryType = 'EXECUTE'
		EXEC (@Sql);
	ELSE
		IF @exeShowCoreScripts = 1
			PRINT (@Sql);

	END;--OVERWRITE FLAG IS ACTIVE : DROP THE EXISTING DATABASE
END;

END;--CHECK IF TARGET DATABASE EXISTS

BEGIN;--GET THE DIRECTORY TO WHICH FILES ARE TO BE CREATED

SELECT 
	@device_directory = SUBSTRING(filename, 1, CHARINDEX(N'master.mdf', LOWER(filename)) - 1)
FROM 
	master.dbo.sysaltfiles 
WHERE 
	dbid = 1 
AND fileid = 1;

END;--GET THE DIRECTORY TO WHICH FILES ARE TO BE CREATED

BEGIN;--CREATE TARGET DATABASE

SET @Sql = '
CREATE DATABASE ' + @tarDatabase + '
ON PRIMARY 
	(
		NAME = N''' + @tarDatabase + ''', 
		FILENAME = N''' + @device_directory + N'' + LOWER(@tarDatabase) + '.mdf''
	)
LOG ON 
	(
		NAME = N''' + @tarDatabase + '_log'',  
		FILENAME = N''' + @device_directory + N'' + LOWER(@tarDatabase) + '.ldf''
	);';

IF @exeQueryType = 'EXECUTE'
	EXEC (@Sql);
ELSE 
	IF @exeShowCoreScripts = 1
		PRINT (@Sql);

END;--CREATE TARGET DATABASE

BEGIN;--CREATE RUN TIME OBJECTS

IF OBJECT_ID('dbo.dynamic_GetLiteralDataType') IS NOT NULL
	DROP FUNCTION dbo.dynamic_GetLiteralDataType;

SET @Sql = '
IF OBJECT_ID(''dbo.dynamic_Print_Sql'') IS NOT NULL
	DROP PROCEDURE dbo.dynamic_Print_Sql;'
EXEC (@Sql);

SET @Sql = '
CREATE PROCEDURE dbo.dynamic_Print_Sql
(@Sql VARCHAR(MAX))
AS
BEGIN;
	
	IF LEN(@Sql) > 0
	PRINT SUBSTRING(@Sql, 0, 4000);
	IF LEN(@Sql) > 4000
	PRINT SUBSTRING(@Sql, 4001, 8000);
	IF LEN(@Sql) > 8000
	PRINT SUBSTRING(@Sql, 8001, 12000);
	IF LEN(@Sql) > 12000
	PRINT SUBSTRING(@Sql, 12001, 16000);
	IF LEN(@Sql) > 16000
	PRINT SUBSTRING(@Sql, 16001, 20000);
	IF LEN(@Sql) > 20000
	PRINT SUBSTRING(@Sql, 20001, 24000);
	IF LEN(@Sql) > 24000
	PRINT SUBSTRING(@Sql, 24001, 28000);

END;'
EXEC (@Sql);

SET @Sql = '
CREATE FUNCTION [dbo].[dynamic_GetLiteralDataType](@TableName as SYSNAME, @ColumnName as SYSNAME)
    RETURNS VARCHAR(100)
    AS
    BEGIN;

        DECLARE 
			@DataType		AS VARCHAR(100),
			@FullDataType	AS VARCHAR(100),
			@MaxLength		AS INT,
			@Precision		AS INT,
			@Scale			AS INT;

		IF @TableName IS NOT NULL
		BEGIN;

		IF (
		SELECT COUNT(1)
		FROM 
			' + @srcDatabase + '.SYS.TABLES t
		INNER JOIN 
			' + @srcDatabase + '.SYS.COLUMNS c 
		ON 
			t.object_id = c.object_id
		WHERE 
			t.name				= @TableName
		AND c.name				= @ColumnName
		AND	c.system_type_id	= c.user_type_id) = 1
		SELECT TOP 1 
			@DataType		= y.name,
			@MaxLength		= c.max_length,
			@Precision		= c.precision,
			@Scale			= c.scale
		FROM 
			' + @srcDatabase + '.SYS.TABLES t
		INNER JOIN 
			' + @srcDatabase + '.SYS.COLUMNS c 
		ON 
			t.object_id		= c.object_id
		INNER JOIN 
			' + @srcDatabase + '.SYS.TYPES y 
		ON y.system_type_id = c.system_type_id
		WHERE 
			t.name			= @TableName
		AND c.name			= @ColumnName
		ELSE
		BEGIN;

		SELECT
			@DataType		= ''[dbo].['' + name + '']''
		FROM
			' + @srcDatabase + '.SYS.TYPES
		WHERE
			user_type_id = (
		SELECT TOP 1 
			c.user_type_id
		FROM 
			' + @srcDatabase + '.SYS.TABLES t
		INNER JOIN 
			' + @srcDatabase + '.SYS.COLUMNS c 
		ON 
			t.object_id = c.object_id
		WHERE 
			t.name = @TableName 
		AND c.name = @ColumnName);

        RETURN @DataType;

		END;

		END;
		ELSE
		BEGIN;

			SET @DataType =(SELECT TOP 1 y.name FROM ' + @srcDatabase + '.SYS.TYPES t
			INNER JOIN ' + @srcDatabase + '.sys.types y ON y.system_type_id = t.system_type_id			
			WHERE t.name = @ColumnName);

			SELECT TOP 1 
				@MaxLength = max_length,
				@Precision = precision,
				@Scale = scale
			FROM 
				' + @srcDatabase + '.sys.types
			WHERE 
				name = @ColumnName;

		END;

        IF @DataType =''decimal'' OR @DataType = ''NUMERIC''
        BEGIN;
            RETURN @DataType + ''(''+ CAST(@Precision AS VARCHAR(10)) + '','' + CAST(@Scale AS VARCHAR(10)) + '')'';
        END;

        IF @DataType LIKE ''%var%'' OR @DataType LIKE ''%char%''
        BEGIN;
            RETURN @DataType + ''(''+ CASE @MaxLength WHEN -1 THEN ''MAX'' ELSE CAST(@MaxLength AS VARCHAR(10)) END + '')''
        END;

        RETURN @DataType;
    END;';
EXEC (@Sql);

SET @Sql = '
IF OBJECT_ID(''TEMPDB..##DYNAMIC_OBJECTS'') IS NOT NULL
	DROP TABLE ##DYNAMIC_OBJECTS;';
EXEC (@Sql);

SET @Sql = '
CREATE TABLE ##DYNAMIC_OBJECTS
(
	Id		INT IDENTITY(1,1),
	name	SYSNAME
);';
EXEC (@Sql);

SET @Sql = '
IF OBJECT_ID(''TEMPDB..##DYNAMIC_MODULES'') IS NOT NULL
	DROP TABLE ##DYNAMIC_MODULES;';
EXEC (@Sql);

SET @Sql = '
USE ' + @srcDatabase + ';' + CHAR(10) + '
CREATE TABLE ##DYNAMIC_MODULES
(
	[Id]				INT IDENTITY(1,1),
	[definition]		VARCHAR(MAX)
);'
EXEC (@Sql);

SELECT
	@srcDatabase	= '[' + @srcDatabase + ']',
	@tarDatabase	= '[' + @tarDatabase + ']';

END;--CREATE RUN TIME OBJECTS

BEGIN;--CREATE USER DEFINED TYPES

TRUNCATE TABLE ##DYNAMIC_OBJECTS;

SET @Sql = '
SELECT
	name = ''CREATE TYPE [dbo].['' + name + ''] FROM '' 
	+ master.[dbo].[dynamic_GetLiteralDataType](NULL, name) 
	+ CASE is_nullable WHEN 0 THEN '' NOT NULL;'' ELSE '' NULL;'' END 
	+ CHAR(10)
FROM 
	' + @srcDatabase + '.sys.types
WHERE 
	is_user_defined = 1;';

INSERT INTO ##DYNAMIC_OBJECTS
	EXEC (@Sql);

SELECT @Sql_Types = (
SELECT
	'USE ' + @tarDatabase + ';' + CHAR(10) + CHAR(10) + 
	LEFT(txt, LEN(txt) - 1)
FROM
	(
		SELECT
			name + CHAR(10)
		FROM 
			##DYNAMIC_OBJECTS
		FOR XML 
			PATH('')
	) t(txt));

IF @exeQueryType = 'EXECUTE'
	EXEC (@Sql_Types);
ELSE
	IF @exeShowCoreScripts = 1
		BEGIN; 
			SET @EXEC = 'EXEC dbo.dynamic_Print_Sql ''' + REPLACE(@Sql_Types, '''', '''''') + ''''; 
			EXEC (@EXEC);
		END;

END;--CREATE USER DEFINED TYPES

BEGIN;--CREATE SCHEMAS

TRUNCATE TABLE ##DYNAMIC_OBJECTS;

SET @Sql = '
SELECT
	name
FROM
	' + @srcDatabase + '.sys.schemas;';

INSERT INTO ##DYNAMIC_OBJECTS
	EXEC (@Sql);

SELECT @Sql_Schemas = (
SELECT
	'USE ' + @tarDatabase + ';' + CHAR(10) + CHAR(10) + 
	LEFT(txt, LEN(txt) - 1)
FROM
	(
		SELECT
			'IF SCHEMA_ID(''' + name + ''') IS NULL' + CHAR(10) + 
			'EXEC(''CREATE SCHEMA [' + name + '];'');' + CHAR(10) + CHAR(10)
		FROM 
			##DYNAMIC_OBJECTS
		FOR XML 
			PATH('')
	) t(txt));

IF @exeQueryType = 'EXECUTE'
	EXEC (@Sql_Schemas);
ELSE
	IF @exeShowCoreScripts = 1
		BEGIN; 
			SET @EXEC = 'EXEC dbo.dynamic_Print_Sql ''' + REPLACE(@Sql_Schemas, '''', '''''') + ''''; 
			EXEC (@EXEC);
		END;

END;--CREATE SCHEMAS

BEGIN;--GET COLUMNS

SET @Sql = '
IF OBJECT_ID(''TEMPDB..##DYNAMIC_COLUMNS'') IS NOT NULL
	DROP TABLE ##DYNAMIC_COLUMNS;';

EXEC (@Sql);

SET @Sql = '
USE ' + @srcDatabase + ';' + CHAR(10) + '
CREATE TABLE ##DYNAMIC_COLUMNS
(
	Id					INT IDENTITY(1,1),
	FullObjectName		VARCHAR(500),
	ColumnName			SYSNAME,
	FullColumnName		VARCHAR(500)
);

WITH CTE AS (
SELECT
	FullObjectName				= ''['' + SCHEMA_NAME(schema_id) + ''].['' + t.name + '']'',
	ColumnName					= c.name,
	FullDataType				= master.dbo.dynamic_GetLiteralDataType(t.name, c.name),
	IsIdentity					= ISNULL(ic.parent_column_id, 0), 	
	SeedValue					= ISNULL(ic.seed_value, 0), 
	IncrementValue				= ISNULL(ic.increment_value, 0),
	IsNullable					= c.is_nullable
FROM
	sys.tables t
INNER JOIN
	sys.columns c
ON
	t.object_id = c.object_id
LEFT OUTER JOIN
	(
		SELECT 
			parent_object_id = object_id,
			parent_column_id = column_id,
			seed_value, 
			increment_value
		FROM 
			sys.identity_columns
	) ic
ON
	t.object_id = ic.parent_object_id
AND	c.column_id = ic.parent_column_id)
INSERT INTO ##DYNAMIC_COLUMNS
SELECT
	FullObjectName,
	ColumnName,
	FullColumnName		= 
		''['' + ColumnName + ''] '' + 
		FullDataType + 
		CASE IsIdentity 
			WHEN 0 THEN '' '' 
		ELSE '' IDENTITY('' + CAST(SeedValue AS VARCHAR(10)) + '','' + CAST(IncrementValue AS VARCHAR(10)) + '') ''
		END + CASE IsNullable WHEN 0 THEN ''NOT NULL'' ELSE ''NULL'' END +
		+ CHAR(10)
FROM
	CTE;';

IF @exeTableImport = 1 AND @exeQueryType <> 'EXECUTE'
BEGIN; 
	SET @EXEC = 'EXEC dbo.dynamic_Print_Sql ''' + REPLACE(@Sql, '''', '''''') + ''''; 
	EXEC (@EXEC);
END;

EXEC (@Sql);

END;--GET COLUMNS

BEGIN;--GET PRIMARY KEYS

SET @Sql = '
IF OBJECT_ID(''TEMPDB..##DYNAMIC_PRIMARYKEYS'') IS NOT NULL
	DROP TABLE ##DYNAMIC_PRIMARYKEYS;';

EXEC (@Sql);

SET @Sql = '
USE ' + @srcDatabase + ';' + CHAR(10) + '
CREATE TABLE ##DYNAMIC_PRIMARYKEYS
(
	Id					INT IDENTITY(1,1),
	FullObjectName		VARCHAR(500),
	ColumnName			SYSNAME,
	PrimaryKey			SYSNAME,
	PrimaryKeyColumn	SYSNAME,
	PrimaryKeyOrdinal	INT
);

WITH CTE AS (
SELECT
	FullObjectName				= ''['' + SCHEMA_NAME(schema_id) + ''].['' + t.name + '']'',
	ColumnName					= c.name,
	PrimaryKey					= ISNULL(pk.CONSTRAINT_NAME, ''''),
	PrimaryKeyOrdinal			= ISNULL(ix.index_column_id, 0),
	PrimaryKeyIsDescending		= ISNULL(ix.is_descending_key, '''')
FROM
	sys.tables t
INNER JOIN
	sys.columns c
ON
	t.object_id = c.object_id
INNER JOIN
	(
		SELECT 
			parent_object_id = OBJECT_ID(ccu.TABLE_SCHEMA + ''.'' + ccu.TABLE_NAME),
			ccu.COLUMN_NAME,
			ccu.CONSTRAINT_NAME					 
		FROM 
			INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE ccu
		INNER JOIN
			INFORMATION_SCHEMA.TABLE_CONSTRAINTS tc
		ON
			ccu.TABLE_SCHEMA	= tc.TABLE_SCHEMA
		AND	ccu.TABLE_NAME		= tc.TABLE_NAME
		AND	ccu.CONSTRAINT_NAME = tc.CONSTRAINT_NAME			
		WHERE
			constraint_type = ''PRIMARY KEY''
	) AS pk
ON
	t.object_id = pk.parent_object_id
AND	c.name		= pk.COLUMN_NAME
INNER JOIN
	(
		SELECT
			parent_object_id	= i.object_id,
			name				= i.name,
			index_type			= type_desc,
			index_column_id		= ic.index_column_id ,
			column_id			= ic.column_id, 
			is_descending_key	= ic.is_descending_key 
		FROM 
			sys.indexes i
		INNER JOIN 
			sys.index_columns ic
		ON
			i.object_id = ic.object_id
		AND	i.index_id = ic.index_id
		WHERE
			name IS NOT NULL
		AND	is_primary_key = 1
	) AS ix
ON
	t.object_id = ix.parent_object_id
AND	c.column_id = ix.column_id)
INSERT INTO ##DYNAMIC_PRIMARYKEYS
SELECT
	FullObjectName,
	ColumnName,
	PrimaryKey			= PrimaryKey,
	PrimaryKeyColumn	= 
		''['' + ColumnName + ''] '' + CASE WHEN PrimaryKeyIsDescending = 0 THEN ''ASC'' ELSE ''DESC'' END
		+ CHAR(10),
	PrimaryKeyOrdinal
FROM
	CTE;';

IF @exeTablePKImport = 1 AND @exeQueryType <> 'EXECUTE'
BEGIN; 
	SET @EXEC = 'EXEC dbo.dynamic_Print_Sql ''' + REPLACE(@Sql, '''', '''''') + ''''; 
	EXEC (@EXEC);
END;

EXEC (@Sql);

END;--GET PRIMARY KEYS

BEGIN;--GET DEFAULT CONSTRAINTS

SET @Sql = '
IF OBJECT_ID(''TEMPDB..##DYNAMIC_DEFAULTS'') IS NOT NULL
	DROP TABLE ##DYNAMIC_DEFAULTS;';

EXEC (@Sql);

SET @Sql = '
USE ' + @srcDatabase + ';' + CHAR(10) + '
CREATE TABLE ##DYNAMIC_DEFAULTS
(
	Id					INT IDENTITY(1,1),
	FullObjectName		VARCHAR(500),
	ColumnName			SYSNAME,
	DefaultConstraint	VARCHAR(MAX)
);

WITH CTE AS (
SELECT
	FullObjectName				= ''['' + SCHEMA_NAME(schema_id) + ''].['' + t.name + '']'',
	ColumnName					= c.name,
	DefaultConstraint			= ISNULL(dc.name, ''''),
	DefaultConstraintValue		= ISNULL(dc.definition, '''')
FROM
	sys.tables t
INNER JOIN
	sys.columns c
ON
	t.object_id = c.object_id
INNER JOIN
	(
		SELECT 
			name, 
			parent_object_id,
			parent_column_id ,
			definition
		FROM 
			sys.default_constraints 
	) dc
ON
	t.object_id = dc.parent_object_id
AND	c.column_id = dc.parent_column_id
WHERE
	ISNULL(dc.name, '''') <> '''')
INSERT INTO ##DYNAMIC_DEFAULTS
SELECT
	FullObjectName,
	ColumnName,
	DefaultConstraint	= 
		''ALTER TABLE '' + FullObjectName + '' ADD  CONSTRAINT ['' + DefaultConstraint + '']  DEFAULT '' + DefaultConstraintValue + '' FOR ['' + ColumnName + ''];'' 
		+ CHAR(10)
FROM
	CTE;';

IF @exeTableDFImport = 1 AND @exeQueryType <> 'EXECUTE'
BEGIN; 
	SET @EXEC = 'EXEC dbo.dynamic_Print_Sql ''' + REPLACE(@Sql, '''', '''''') + ''''; 
	EXEC (@EXEC);
END;

EXEC (@Sql);

END;--GET DEFAULT CONSTRAINTS

BEGIN;--GET CHECK CONSTRAINTS

SET @Sql = '
IF OBJECT_ID(''TEMPDB..##DYNAMIC_CHECKS'') IS NOT NULL
	DROP TABLE ##DYNAMIC_CHECKS;';

EXEC (@Sql);

SET @Sql = '
USE ' + @srcDatabase + ';' + CHAR(10) + '
CREATE TABLE ##DYNAMIC_CHECKS
(
	Id					INT IDENTITY(1,1),
	FullObjectName		VARCHAR(500),
	ColumnName			SYSNAME,
	CheckConstraint		VARCHAR(MAX)
);

WITH CTE AS (
SELECT
	FullObjectName				= ''['' + SCHEMA_NAME(schema_id) + ''].['' + t.name + '']'',
	ColumnName					= c.name,
	CheckConstraint				= ISNULL(ckc.name, ''''),
	CheckConstraintValue		= ISNULL(ckc.definition, ''''),
	DefaultConstraint			= ISNULL(dc.name, '''')
FROM
	sys.tables t
INNER JOIN
	sys.columns c
ON
	t.object_id = c.object_id
INNER JOIN
	(
		SELECT 
			name,
			object_id,
			parent_object_id,
			parent_column_id ,
			definition
		FROM 
			sys.check_constraints 
	) ckc
ON
	t.object_id = ckc.parent_object_id
AND	c.column_id = ckc.parent_column_id
INNER JOIN
	(
		SELECT 
			name, 
			parent_object_id,
			object_id
		FROM 
			sys.objects 
	) dc
ON
	ckc.parent_object_id = dc.parent_object_id
AND	ckc.object_id = dc.object_id
WHERE
	ISNULL(ckc.name, '''') <> '''')
INSERT INTO ##DYNAMIC_CHECKS
SELECT
	FullObjectName,
	ColumnName,
	CheckConstraint		= 
		''ALTER TABLE '' + FullObjectName + '' WITH NOCHECK ADD CONSTRAINT ['' + DefaultConstraint + ''] CHECK '' + CheckConstraintValue + '';'' + CHAR(10) + 
		''ALTER TABLE '' + FullObjectName + '' CHECK CONSTRAINT ['' + DefaultConstraint + ''];'' 
		+ CHAR(10)
FROM
	CTE;';

IF @exeTableCKImport = 1 AND @exeQueryType <> 'EXECUTE'
BEGIN; 
	SET @EXEC = 'EXEC dbo.dynamic_Print_Sql ''' + REPLACE(@Sql, '''', '''''') + ''''; 
	EXEC (@EXEC);
END;

EXEC (@Sql);

END;--GET CHECK CONSTRAINTS

BEGIN;--GET FOREIGN KEYS

SET @Sql = '
IF OBJECT_ID(''TEMPDB..##DYNAMIC_FOREIGNKEYS'') IS NOT NULL
	DROP TABLE ##DYNAMIC_FOREIGNKEYS;';

EXEC (@Sql);

SET @Sql = '
USE ' + @srcDatabase + ';' + CHAR(10) + '
CREATE TABLE ##DYNAMIC_FOREIGNKEYS
(
	Id					INT IDENTITY(1,1),
	FullObjectName		VARCHAR(500),
	ColumnName			SYSNAME,
	ForeignKey			VARCHAR(MAX)
);

WITH CTE AS (
SELECT
	FullObjectName				= ''['' + SCHEMA_NAME(schema_id) + ''].['' + t.name + '']'',
	ColumnName					= c.name,
	ForeignKey					= ISNULL(fk.name, ''''),
	ForeignKeyReference			= ISNULL(fk.referenced_object, ''''),
	ForeignKeyColumn			= ISNULL(fk.referenced_column, '''')
FROM
	sys.tables t
INNER JOIN
	sys.columns c
ON
	t.object_id = c.object_id
INNER JOIN
	(
		SELECT 
			name = OBJECT_NAME(constraint_object_id),
			parent_object_id,
			referenced_object = OBJECT_SCHEMA_NAME(referenced_object_id) + ''.'' + OBJECT_NAME(referenced_object_id),
			parent_column_id,
			referenced_column = c.name
		FROM 
			sys.foreign_key_columns fkc
		INNER JOIN
			sys.columns c
		ON
			fkc.referenced_object_id = c.object_id
		AND	fkc.referenced_column_id = c.column_id
	) fk
ON
	t.object_id = fk.parent_object_id
AND	c.column_id = fk.parent_column_id
WHERE
	ISNULL(fk.name, '''') <> '''')
INSERT INTO ##DYNAMIC_FOREIGNKEYS
SELECT
	FullObjectName,
	ColumnName,
	ForeignKey		=  
			''ALTER TABLE '' + FullObjectName + '' WITH NOCHECK ADD  CONSTRAINT ['' + ForeignKey + ''] FOREIGN KEY(['' + ColumnName + ''])''  + CHAR(10) + 
			''REFERENCES '' + ForeignKeyReference + '' (['' + ForeignKeyColumn + '']);'' + CHAR(10) + 
			''ALTER TABLE '' + FullObjectName + '' CHECK CONSTRAINT ['' + ForeignKey + ''];'' 
			+ CHAR(10)
FROM
	CTE;';

IF @exeTableFKImport = 1 AND @exeQueryType <> 'EXECUTE'
BEGIN; 
	SET @EXEC = 'EXEC dbo.dynamic_Print_Sql ''' + REPLACE(@Sql, '''', '''''') + ''''; 
	EXEC (@EXEC);
END;

EXEC (@Sql);

END;--GET FOREIGN KEYS

BEGIN;--GET INDEXES

SET @Sql = '
IF OBJECT_ID(''TEMPDB..##DYNAMIC_INDEXES'') IS NOT NULL
	DROP TABLE ##DYNAMIC_INDEXES;';

EXEC (@Sql);

SET @Sql = '
USE ' + @srcDatabase + ';' + CHAR(10) + '
CREATE TABLE ##DYNAMIC_INDEXES
(
	Id					INT IDENTITY(1,1),
	FullObjectName		VARCHAR(500),
	ColumnName			SYSNAME,
	IndexName			SYSNAME,
	IndexType			SYSNAME,
	IndexColumnOrdinal	INT,
	IndexIsDescending	INT
);

WITH CTE AS (
SELECT
	FullObjectName				= ''['' + SCHEMA_NAME(schema_id) + ''].['' + t.name + '']'',
	ColumnName					= c.name,
	IndexName					= ISNULL(ix.name, ''''),
	IndexType					= ISNULL(ix.index_type, ''''),
	IndexColumnOrdinal			= ISNULL(ix.index_column_id, 0),
	IndexIsDescending			= ISNULL(ix.is_descending_key, 0)
FROM
	sys.tables t
INNER JOIN
	sys.columns c
ON
	t.object_id = c.object_id
INNER JOIN
	(
		SELECT
			parent_object_id	= i.object_id,
			name				= i.name,
			index_type			= type_desc,
			index_column_id		= ic.index_column_id ,
			column_id			= ic.column_id, 
			is_descending_key	= ic.is_descending_key 
		FROM 
			sys.indexes i
		INNER JOIN 
			sys.index_columns ic
		ON
			i.object_id = ic.object_id
		AND	i.index_id = ic.index_id
		WHERE
			name IS NOT NULL
		AND	is_primary_key = 0
	) AS ix
ON
	t.object_id = ix.parent_object_id
AND	c.column_id = ix.column_id)
INSERT INTO ##DYNAMIC_INDEXES
SELECT
	FullObjectName,
	ColumnName,
	IndexName			= IndexName,
	IndexType			= IndexType,
	IndexColumnOrdinal	= IndexColumnOrdinal,
	IndexIsDescending	= IndexIsDescending
FROM
	CTE;';

IF @exeTableIXImport = 1 AND @exeQueryType <> 'EXECUTE'
BEGIN; 
	SET @EXEC = 'EXEC dbo.dynamic_Print_Sql ''' + REPLACE(@Sql, '''', '''''') + ''''; 
	EXEC (@EXEC);
END;

EXEC (@Sql);

END;--GET INDEXES

BEGIN;--CREATE TABLE OBJECTS

TRUNCATE TABLE ##DYNAMIC_OBJECTS;

SET @Sql = '
USE ' + @srcDatabase + ';' + CHAR(10) + CHAR(10) + '
SELECT
	''['' + SCHEMA_NAME(schema_id) + ''].['' + name + '']''
FROM
	sys.tables;';

IF @exeTableImport = 1 AND @exeQueryType <> 'EXECUTE'
BEGIN; 
	SET @EXEC = 'EXEC dbo.dynamic_Print_Sql ''' + REPLACE(@Sql, '''', '''''') + ''''; 
	EXEC (@EXEC);
END;

INSERT INTO ##DYNAMIC_OBJECTS
EXEC (@Sql);

SELECT
	@Cursor			= 1,
	@exeCursorT		= 1,
	@exeCursorDF	= 1,
	@exeCursorCK	= 1,
	@exeCursorFK	= 1,
	@exeCursorIX	= 1;

WHILE @Cursor <= (SELECT COUNT(1) FROM ##DYNAMIC_OBJECTS)
BEGIN;

BEGIN;--GET CURRENT TABLE NAME
SELECT 
	@TableName = name 
FROM 
	##DYNAMIC_OBJECTS
WHERE
	id = @Cursor;
END;--GET CURRENT TABLE NAME

BEGIN;--CREATE TABLES

SELECT @Sql_Tables = (
SELECT
	'USE ' + @tarDatabase + ';' + CHAR(10) + CHAR(10) + 
	'CREATE TABLE ' + @TableName + '(' + CHAR(10) + 
	LEFT(txt, LEN(txt) - 1) + CHAR(10)
FROM
	(
		SELECT
			FullColumnName + ','
		FROM 
			##DYNAMIC_COLUMNS
		WHERE
			FullObjectName = @TableName
		FOR XML 
			PATH('')
	) t(txt));

BEGIN;--CREATE PRIMARY KEYS

SELECT @Sql_PKeys = (
SELECT
	'CONSTRAINT [' + 
	(
		SELECT DISTINCT
			PrimaryKey
		FROM 
			##DYNAMIC_PRIMARYKEYS
		WHERE
			FullObjectName = @TableName	
	) + '] PRIMARY KEY CLUSTERED' + CHAR(10) + 
	'(' + CHAR(10) +
	LEFT(txt, LEN(txt) - 1)  + 
	')WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]' +
	') ON [PRIMARY];' + CHAR(10)
FROM
	(
		SELECT
			PrimaryKeyColumn + ','
		FROM 
			##DYNAMIC_PRIMARYKEYS
		WHERE
			FullObjectName = @TableName
		ORDER BY
			PrimaryKeyOrdinal
		FOR XML 
			PATH('')
	) t(txt));

END;--CREATE PRIMARY KEYS

SET @Sql_Tables = @Sql_Tables + 
					CASE WHEN @exeTablePKImport = 1 
						THEN CASE WHEN ISNULL(LTRIM(RTRIM(@Sql_PKeys)), '') = '' THEN ');' 
						ELSE @Sql_PKeys END ELSE ');' 
					END;

IF @exeTableImport = 1 AND @exeQueryType = 'EXECUTE'
	EXEC (@Sql_Tables);

IF @exeTableImport = 1 AND @exeQueryType <> 'EXECUTE' AND @exeCursorT <= @exeSampleSize
BEGIN; 
	SET @EXEC = 'EXEC dbo.dynamic_Print_Sql ''' + REPLACE(@Sql_Tables, '''', '''''') + ''''; 
	EXEC (@EXEC);
	SET @exeCursorT += 1;
END;

END;--CREATE TABLES

BEGIN;--CREATE DEFAULTS

SELECT @Sql_Defaults = (
SELECT
	'USE ' + @tarDatabase + ';' + CHAR(10) + CHAR(10) + 
	LEFT(txt, LEN(txt) - 1)  + CHAR(10)
FROM
	(
		SELECT
			DefaultConstraint + ''
		FROM 
			##DYNAMIC_DEFAULTS
		WHERE
			FullObjectName = @TableName
		FOR XML 
			PATH('')
	) t(txt));

IF ISNULL(@Sql_Defaults, '') <> ''
BEGIN;

IF @exeTableDFImport = 1 AND @exeQueryType = 'EXECUTE'
	EXEC (@Sql_Defaults);

IF @exeTableDFImport = 1 AND @exeQueryType <> 'EXECUTE' AND @exeCursorDF <= @exeSampleSize
BEGIN; 
	SET @EXEC = 'EXEC dbo.dynamic_Print_Sql ''' + REPLACE(@Sql_Defaults, '''', '''''') + ''''; 
	EXEC (@EXEC);
	SET @exeCursorDF += 1;
END;

END;

END;--CREATE DEFAULTS

BEGIN;--CREATE CHECK CONSTRAINTS

SELECT 
	@Sql = 'USE ' + @tarDatabase + ';' + CHAR(10) + CHAR(10),
	@Sql_CKConstraints = '';

SELECT
	@Sql_CKConstraints += CASE WHEN ISNULL(CheckConstraint, '') = '' THEN '' ELSE
	CheckConstraint + CHAR(10) END
FROM 
	##DYNAMIC_CHECKS
WHERE
	FullObjectName = @TableName;

IF ISNULL(@Sql_CKConstraints, '') <> ''
BEGIN;
	
	SET @Sql_CKConstraints = @Sql + @Sql_CKConstraints;

	IF @exeTableCKImport = 1 AND @exeQueryType = 'EXECUTE'
		EXEC (@Sql_CKConstraints);

	IF @exeTableCKImport = 1 AND @exeQueryType <> 'EXECUTE' AND @exeCursorCK <= @exeSampleSize
	BEGIN; 
		SET @EXEC = 'EXEC dbo.dynamic_Print_Sql ''' + REPLACE(@Sql_CKConstraints, '''', '''''') + ''''; 
		EXEC (@EXEC);
		SET @exeCursorCK += 1;
	END;

END;

END;--CREATE CHECK CONSTRAINTS

SET @Cursor += 1;

END;

SET @Cursor = 1;

WHILE @Cursor <= (SELECT COUNT(1) FROM ##DYNAMIC_OBJECTS)
BEGIN;

BEGIN;--GET CURRENT TABLE NAME

SELECT 
	@TableName = name 
FROM 
	##DYNAMIC_OBJECTS
WHERE
	id = @Cursor;

END;--GET CURRENT TABLE NAME

BEGIN;--CREATE FOREIGN KEYS

SELECT @Sql_FKConstraints = (
SELECT
	'USE ' + @tarDatabase + ';' + CHAR(10) + CHAR(10) + 
	LEFT(txt, LEN(txt) - 1)  + CHAR(10)
FROM
	(
		SELECT
			ForeignKey + ''
		FROM 
			##DYNAMIC_FOREIGNKEYS
		WHERE
			FullObjectName = @TableName
		FOR XML 
			PATH('')
	) t(txt));

IF ISNULL(@Sql_FKConstraints, '') <> ''
BEGIN;

IF @exeTableFKImport = 1 AND @exeQueryType = 'EXECUTE'
	EXEC (@Sql_FKConstraints);

IF @exeTableFKImport = 1 AND @exeQueryType <> 'EXECUTE' AND @exeCursorFK <= @exeSampleSize
BEGIN; 
	SET @EXEC = 'EXEC dbo.dynamic_Print_Sql ''' + REPLACE(@Sql_FKConstraints, '''', '''''') + ''''; 
	EXEC (@EXEC);
	SET @exeCursorFK += 1;
END;

END;

END;--CREATE FOREIGN KEYS

BEGIN;--CREATE INDEXES

SET @Sql = '
IF OBJECT_ID(''TEMPDB..##DYNAMIC_INDEXNAMES'') IS NOT NULL
	DROP TABLE ##DYNAMIC_INDEXNAMES;';

EXEC (@Sql);

SET @Sql = '
USE ' + @srcDatabase + ';' + CHAR(10) + '
CREATE TABLE ##DYNAMIC_INDEXNAMES
(
	Id					INT IDENTITY(1,1),
	ColumnName			SYSNAME,
	IndexName			SYSNAME,
	IndexType			SYSNAME,
	IndexColumnOrdinal	INT,
	IndexIsDescending	INT
);';

EXEC (@Sql);

INSERT INTO ##DYNAMIC_INDEXNAMES
SELECT
	ColumnName,
	IndexName,
	IndexType,
	IndexColumnOrdinal,
	IndexIsDescending
FROM 
	##DYNAMIC_INDEXES
WHERE
	FullObjectName = @TableName;

SET @Cursor2 = 1;
SET @exeCursorIX = 1;

DECLARE @INDEXLIST TABLE (NAME SYSNAME);

WHILE @Cursor2 <= (SELECT COUNT(1) FROM ##DYNAMIC_INDEXNAMES)
BEGIN;

SELECT
	@IndexName			= IndexName,
	@IndexType			= IndexType
FROM 
	##DYNAMIC_INDEXNAMES
WHERE
	Id = @Cursor2;

IF (SELECT NAME FROM @INDEXLIST WHERE NAME = @IndexName) IS NULL
BEGIN;

INSERT INTO @INDEXLIST
SELECT @IndexName;

SELECT @Sql_Indexes = (
SELECT
	'USE ' + @tarDatabase + ';' + CHAR(10) + CHAR(10) + 
	'CREATE ' + @IndexType + ' INDEX [' + @IndexName + '] ON ' + @TableName + '' + CHAR(10) + 
	'(' + CHAR(10) + 
LEFT(txt, LEN(txt) - 2)  + CHAR(10)
FROM
	(
		SELECT
			ColumnName + CASE WHEN IndexIsDescending = 0 THEN ' ASC' ELSE ' DESC' END + ',' + CHAR(10)
		FROM 
			##DYNAMIC_INDEXNAMES
		WHERE
			IndexName = @IndexName
		AND	IndexType = @IndexType
		ORDER BY
			IndexColumnOrdinal
		FOR XML 
			PATH('')
	) t(txt));

IF ISNULL(@Sql_Indexes, '') <> ''
BEGIN;
	
	SET @Sql_Indexes += 
	')WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY];'
	 + CHAR(10);

	IF @exeTableIXImport = 1 AND @exeQueryType = 'EXECUTE'
		EXEC (@Sql_Indexes);

	IF @exeTableIXImport = 1 AND @exeQueryType <> 'EXECUTE' AND @exeCursorIX <= @exeSampleSize
	BEGIN; 
		SET @EXEC = 'EXEC dbo.dynamic_Print_Sql ''' + REPLACE(@Sql_Indexes, '''', '''''') + ''''; 
		EXEC (@EXEC);
		SET @exeCursorIX += 1;
	END;

END;

END;

SET @Cursor2 += 1;

END;

END;--CREATE INDEXES

SET @Cursor += 1;

END;

END;--CREATE TABLE OBJECTS

BEGIN;--CREATE MODULE TYPE OBJECTS

BEGIN;--CREATE FUNCTIONS

SET @Sql = '
USE ' + @srcDatabase + ';' + CHAR(10) + '
TRUNCATE TABLE ##DYNAMIC_MODULES;' + CHAR(10) + '

INSERT INTO ##DYNAMIC_MODULES
SELECT
	LTRIM(RTRIM([definition]))
FROM
	sys.sql_modules m
INNER JOIN
	sys.objects o
ON
	m.object_id = o.object_id
WHERE
	o.type IN (''TF'', ''FN'');';

EXEC (@Sql);

SET @Cursor = 1;

WHILE @Cursor <= (SELECT COUNT(1) FROM ##DYNAMIC_MODULES)
BEGIN;

SELECT
	@Sql_FModules = 
	'USE ' + @tarDatabase + ';' + CHAR(10) + 
	'DECLARE @SQL VARCHAR(MAX);' + CHAR(10) + 
	'SET @SQL = ''' + 
	REPLACE([definition],'''', '''''') + '''' + ';
	EXEC (@SQL);'
FROM
	##DYNAMIC_MODULES
WHERE
	Id = @Cursor;

IF @exeFunctionImport = 1 AND @exeQueryType = 'EXECUTE'
	EXEC (@Sql_FModules);

IF @exeFunctionImport = 1 AND @exeQueryType <> 'EXECUTE' AND @Cursor <= @exeSampleSize
BEGIN; 
	SET @EXEC = 'EXEC dbo.dynamic_Print_Sql ''' + REPLACE(@Sql_FModules, '''', '''''') + ''''; 
	EXEC (@EXEC);
END;

SET @Cursor += 1;

END;

END;--CREATE FUNCTIONS

BEGIN;--CREATE VIEWS

SET @Sql = '
USE ' + @srcDatabase + ';' + CHAR(10) + '
TRUNCATE TABLE ##DYNAMIC_MODULES;' + CHAR(10) + '

INSERT INTO ##DYNAMIC_MODULES
SELECT
	LTRIM(RTRIM([definition]))
FROM
	sys.sql_modules m
INNER JOIN
	sys.objects o
ON
	m.object_id = o.object_id
WHERE
	o.type IN (''V'');';

EXEC (@Sql);

SET @Cursor = 1;

WHILE @Cursor <= (SELECT COUNT(1) FROM ##DYNAMIC_MODULES)
BEGIN;

SELECT
	@Sql_VModules = 
	'USE ' + @tarDatabase + ';' + CHAR(10) + 
	'DECLARE @SQL VARCHAR(MAX);' + CHAR(10) + 
	'SET @SQL = ''' + 
	REPLACE([definition],'''', '''''') + '''' + ';
	EXEC (@SQL);'
FROM
	##DYNAMIC_MODULES
WHERE
	Id = @Cursor;

IF @exeViewImport = 1 AND @exeQueryType = 'EXECUTE'
	EXEC (@Sql_VModules);

IF @exeViewImport = 1 AND @exeQueryType <> 'EXECUTE' AND @Cursor <= @exeSampleSize
BEGIN; 
	SET @EXEC = 'EXEC dbo.dynamic_Print_Sql ''' + REPLACE(@Sql_VModules, '''', '''''') + ''''; 
	EXEC (@EXEC);
END;

SET @Cursor += 1;

END;

END;--CREATE VIEWS

BEGIN;--CREATE PROCEDURES

SET @Sql = '
USE ' + @srcDatabase + ';' + CHAR(10) + '
TRUNCATE TABLE ##DYNAMIC_MODULES;' + CHAR(10) + '

INSERT INTO ##DYNAMIC_MODULES
SELECT
	LTRIM(RTRIM([definition]))
FROM
	sys.sql_modules m
INNER JOIN
	sys.objects o
ON
	m.object_id = o.object_id
WHERE
	o.type IN (''P'');';

EXEC (@Sql);

SET @Cursor = 1;

WHILE @Cursor <= (SELECT COUNT(1) FROM ##DYNAMIC_MODULES)
BEGIN;

SELECT
	@Sql_PModules = 
	'USE ' + @tarDatabase + ';' + CHAR(10) + 
	'DECLARE @SQL VARCHAR(MAX);' + CHAR(10) + 
	'SET @SQL = ''' + 
	REPLACE([definition],'''', '''''') + '''' + ';
	EXEC (@SQL);'
FROM
	##DYNAMIC_MODULES
WHERE
	Id = @Cursor;

IF @exeProcedureImport = 1 AND @exeQueryType = 'EXECUTE'
	EXEC (@Sql_PModules);

IF @exeProcedureImport = 1 AND @exeQueryType <> 'EXECUTE' AND @Cursor <= @exeSampleSize
BEGIN; 
	SET @EXEC = 'EXEC dbo.dynamic_Print_Sql ''' + REPLACE(@Sql_PModules, '''', '''''') + ''''; 
	EXEC (@EXEC);
END;

SET @Cursor += 1;

END;

END;--CREATE PROCEDURES

BEGIN;--CREATE TRIGGERS

SET @Sql = '
USE ' + @srcDatabase + ';' + CHAR(10) + '
TRUNCATE TABLE ##DYNAMIC_MODULES;' + CHAR(10) + '

INSERT INTO ##DYNAMIC_MODULES
SELECT
	LTRIM(RTRIM([definition]))
FROM
	sys.sql_modules m
INNER JOIN
	sys.objects o
ON
	m.object_id = o.object_id
WHERE
	o.type IN (''TR'');';

EXEC (@Sql);

SET @Cursor = 1;

WHILE @Cursor <= (SELECT COUNT(1) FROM ##DYNAMIC_MODULES)
BEGIN;

SELECT
	@Sql_TModules = 
	'USE ' + @tarDatabase + ';' + CHAR(10) + 
	'DECLARE @SQL VARCHAR(MAX);' + CHAR(10) + 
	'SET @SQL = ''' + 
	REPLACE([definition],'''', '''''') + '''' + ';
	EXEC (@SQL);'
FROM
	##DYNAMIC_MODULES
WHERE
	Id = @Cursor;

IF @exeTriggerImport = 1 AND @exeQueryType = 'EXECUTE'
	EXEC (@Sql_TModules);

IF @exeTriggerImport = 1 AND @exeQueryType <> 'EXECUTE' AND @Cursor <= @exeSampleSize
BEGIN; 
	SET @EXEC = 'EXEC dbo.dynamic_Print_Sql ''' + REPLACE(@Sql_TModules, '''', '''''') + ''''; 
	EXEC (@EXEC);
END;

SET @Cursor += 1;

END;

END;--CREATE TRIGGERS

END;--CREATE MODULE TYPE OBJECTS

BEGIN;--DELETE TEMP OBJECTS
SET @Sql = '
IF OBJECT_ID(''TEMPDB..##DYNAMIC_OBJECTS'') IS NOT NULL
	DROP TABLE ##DYNAMIC_OBJECTS;';
EXEC (@Sql);
SET @Sql = '
IF OBJECT_ID(''TEMPDB..##DYNAMIC_COLUMNS'') IS NOT NULL
	DROP TABLE ##DYNAMIC_COLUMNS;';
EXEC (@Sql);
SET @Sql = '
IF OBJECT_ID(''TEMPDB..##DYNAMIC_PRIMARYKEYS'') IS NOT NULL
	DROP TABLE ##DYNAMIC_PRIMARYKEYS;';
EXEC (@Sql);
SET @Sql = '
IF OBJECT_ID(''TEMPDB..##DYNAMIC_DEFAULTS'') IS NOT NULL
	DROP TABLE ##DYNAMIC_DEFAULTS;';
EXEC (@Sql);
SET @Sql = '
IF OBJECT_ID(''TEMPDB..##DYNAMIC_CHECKS'') IS NOT NULL
	DROP TABLE ##DYNAMIC_CHECKS;';
EXEC (@Sql);
SET @Sql = '
IF OBJECT_ID(''TEMPDB..##DYNAMIC_INDEXES'') IS NOT NULL
	DROP TABLE ##DYNAMIC_INDEXES;';
EXEC (@Sql);
SET @Sql = '
IF OBJECT_ID(''TEMPDB..##DYNAMIC_INDEXNAMES'') IS NOT NULL
	DROP TABLE ##DYNAMIC_INDEXNAMES;';
EXEC (@Sql);
SET @Sql = '
IF OBJECT_ID(''TEMPDB..##DYNAMIC_FOREIGNKEYS'') IS NOT NULL
	DROP TABLE ##DYNAMIC_FOREIGNKEYS;';
EXEC (@Sql);
SET @Sql = '
IF OBJECT_ID(''TEMPDB..##DYNAMIC_MODULES'') IS NOT NULL
	DROP TABLE ##DYNAMIC_MODULES;';
EXEC (@Sql);
--IF OBJECT_ID('dbo.dynamic_GetLiteralDataType') IS NOT NULL
--	DROP FUNCTION dbo.dynamic_GetLiteralDataType;
IF OBJECT_ID('dbo.dynamic_Print_Sql') IS NOT NULL
	DROP PROCEDURE dbo.dynamic_Print_Sql;
END;--DELETE TEMP OBJECTS

SET NOCOUNT OFF;

END;

GO