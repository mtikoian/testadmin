USE [Northwind];

IF OBJECT_ID('TEMPDB..##DYNAMIC_CHECKS') IS NOT NULL
	DROP TABLE ##DYNAMIC_CHECKS;

CREATE TABLE ##DYNAMIC_CHECKS
(
	Id					INT IDENTITY(1,1),
	FullObjectName		VARCHAR(500),
	ColumnName			SYSNAME,
	CheckConstraint		VARCHAR(MAX)
);

WITH CTE AS (
SELECT
	FullObjectName				= '[' + SCHEMA_NAME(schema_id) + '].[' + t.name + ']',
	ColumnName					= c.name,
	CheckConstraint				= ISNULL(ckc.name, ''),
	CheckConstraintValue		= ISNULL(ckc.definition, ''),
	DefaultConstraint			= ISNULL(dc.name, '')
FROM
	sys.tables t
INNER JOIN
	sys.columns c
ON
	t.object_id = c.object_id
INNER JOIN
	(
		SELECT 
			name,
			object_id,
			parent_object_id,
			parent_column_id ,
			definition
		FROM 
			sys.check_constraints 
	) ckc
ON
	t.object_id = ckc.parent_object_id
AND	c.column_id = ckc.parent_column_id
INNER JOIN
	(
		SELECT 
			name, 
			parent_object_id,
			object_id
		FROM 
			sys.objects 
	) dc
ON
	ckc.parent_object_id = dc.parent_object_id
AND	ckc.object_id = dc.object_id
WHERE
	ISNULL(ckc.name, '') <> '')
INSERT INTO ##DYNAMIC_CHECKS
SELECT
	FullObjectName,
	ColumnName,
	CheckConstraint		= 
		'ALTER TABLE ' + FullObjectName + '  WITH NOCHECK ADD CONSTRAINT [' + DefaultConstraint + '] CHECK ' + CheckConstraintValue + CHAR(10) + 
		'ALTER TABLE ' + FullObjectName + ' CHECK CONSTRAINT [' + DefaultConstraint + '];' 
		+ CHAR(10)
FROM
	CTE;

SELECT * FROM ##DYNAMIC_CHECKS;