
USE master;

IF OBJECT_ID('[dbo].[temp_IQWORLD\tmakoni]') IS NOT NULL
DROP TABLE [dbo].[temp_IQWORLD\tmakoni];

CREATE TABLE [dbo].[temp_IQWORLD\tmakoni]
(
	ID		INT IDENTITY(1, 1),
	NAME	VARCHAR(50),
	SURNAME	VARCHAR(50)
);

INSERT INTO [dbo].[temp_IQWORLD\tmakoni] (NAME, SURNAME) VALUES
('TREVOR', 'MAKONI');

INSERT INTO [dbo].[temp_IQWORLD\tmakoni] (NAME, SURNAME) VALUES
('FIRST NAME', 'SURNAME');

SELECT * FROM [dbo].[temp_IQWORLD\tmakoni];