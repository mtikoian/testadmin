USE [Northwind];

IF OBJECT_ID('TEMPDB..##DYNAMIC_FOREIGNKEYS') IS NOT NULL
	DROP TABLE ##DYNAMIC_FOREIGNKEYS;

CREATE TABLE ##DYNAMIC_FOREIGNKEYS
(
	Id					INT IDENTITY(1,1),
	FullObjectName		VARCHAR(500),
	ColumnName			SYSNAME,
	ForeignKey			VARCHAR(MAX)
);

WITH CTE AS (
SELECT
	FullObjectName				= '[' + SCHEMA_NAME(schema_id) + '].[' + t.name + ']',
	ColumnName					= c.name,
	ForeignKey					= ISNULL(fk.name, ''),
	ForeignKeyReference			= ISNULL(fk.referenced_object, ''),
	ForeignKeyColumn			= ISNULL(fk.referenced_column, '')
FROM
	sys.tables t
INNER JOIN
	sys.columns c
ON
	t.object_id = c.object_id
INNER JOIN
	(
		SELECT 
			name = OBJECT_NAME(constraint_object_id),
			parent_object_id,
			referenced_object = OBJECT_SCHEMA_NAME(referenced_object_id) + '.' + OBJECT_NAME(referenced_object_id),
			parent_column_id,
			referenced_column = c.name
		FROM 
			sys.foreign_key_columns fkc
		INNER JOIN
			sys.columns c
		ON
			fkc.referenced_object_id = c.object_id
		AND	fkc.referenced_column_id = c.column_id
	) fk
ON
	t.object_id = fk.parent_object_id
AND	c.column_id = fk.parent_column_id
WHERE
	ISNULL(fk.name, '') <> '')
INSERT INTO ##DYNAMIC_FOREIGNKEYS
SELECT
	FullObjectName,
	ColumnName,
	ForeignKey		=  
			'ALTER TABLE ' + FullObjectName + ' WITH NOCHECK ADD  CONSTRAINT [' + ForeignKey + '] FOREIGN KEY([' + ColumnName + '])'  + CHAR(10) + 
			'REFERENCES ' + ForeignKeyReference + ' ([' + ForeignKeyColumn + ']);' + CHAR(10) + 
			'ALTER TABLE ' + FullObjectName + ' CHECK CONSTRAINT [' + ForeignKey + '];' 
			+ CHAR(10)
FROM
	CTE;

SELECT * FROM ##DYNAMIC_FOREIGNKEYS;