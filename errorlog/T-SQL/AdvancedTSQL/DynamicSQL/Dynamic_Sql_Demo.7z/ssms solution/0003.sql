DECLARE
	@SQL		VARCHAR(MAX),
	@PARAM1		VARCHAR(50),
	@PARAM2		VARCHAR(50),
	@PARAM3		VARCHAR(50),
	@COLUMNS	VARCHAR(MAX),
	@COLS	VARCHAR(MAX);

SELECT
	@PARAM1 = 'master',
	@PARAM2 = 'dbo',
	@PARAM3 = 'temp_' + SUSER_NAME(),
	@COLUMNS = '!ID~INT IDENTITY(1, 1)|NAME~VARCHAR(50)|SURNAME~VARCHAR(50)';

SELECT
	A.ID,
	A.LINE,
	B.ID,
	B.LINE
FROM master.dbo.[ufn_SplitStringToArray] (@COLUMNS, '|') A
CROSS APPLY master.dbo.[ufn_SplitStringToArray] (A.LINE, '~') B
WHERE
	B.ID = 1
AND LEFT(B.LINE, 1) <> '!';

SELECT
	A.ID,
	A.LINE,
	B.ID,
	B.LINE
FROM master.dbo.[ufn_SplitStringToArray] (@COLUMNS, '|') A
CROSS APPLY master.dbo.[ufn_SplitStringToArray] (A.LINE, '~') B;

SELECT
	LEFT(txt, LEN(txt) - 2)
FROM
	(
		SELECT
			REPLACE(REPLACE(A.LINE, '!', ''), '~', ' ') + ',' + CHAR(10)
		FROM master.dbo.[ufn_SplitStringToArray] (@COLUMNS, '|') A
		FOR XML 
			PATH('')
	) t(txt);

SELECT @COLS = '(' + (
SELECT
	LEFT(txt, LEN(txt) - 1) + ')'
FROM
	(
		SELECT
			B.LINE + ', '
		FROM master.dbo.[ufn_SplitStringToArray] (@COLUMNS, '|') A
		CROSS APPLY master.dbo.[ufn_SplitStringToArray] (A.LINE, '~') B
		WHERE
			B.ID = 1
		AND LEFT(B.LINE, 1) <> '!'
		FOR XML 
			PATH('')
	) t(txt));

SET @SQL = '
USE ' + @PARAM1 + ';

IF OBJECT_ID(''[' + @PARAM2 + '].[' + @PARAM3 + ']'') IS NOT NULL
DROP TABLE [' + @PARAM2 + '].[' + @PARAM3 + '];

CREATE TABLE [' + @PARAM2 + '].[' + @PARAM3 + ']
(' + CHAR(10)

SELECT @SQL = @SQL + (
SELECT
	LEFT(txt, LEN(txt) - 2)
FROM
	(
		SELECT
			REPLACE(REPLACE(A.LINE, '!', ''), '~', ' ') + ',' + CHAR(10)
		FROM master.dbo.[ufn_SplitStringToArray] (@COLUMNS, '|') A
		FOR XML 
			PATH('')
	) t(txt));

SELECT @SQL = @SQL +  + CHAR(10) + 
');

INSERT INTO [' + @PARAM2 + '].[' + @PARAM3 + '] ' + @COLS + ' VALUES
(''TREVOR'', ''MAKONI'');

INSERT INTO [' + @PARAM2 + '].[' + @PARAM3 + '] ' + @COLS + ' VALUES
(''FIRST NAME'', ''SURNAME'');

SELECT * FROM [' + @PARAM2 + '].[' + @PARAM3 + '];
'

PRINT (@SQL);
EXEC (@SQL);