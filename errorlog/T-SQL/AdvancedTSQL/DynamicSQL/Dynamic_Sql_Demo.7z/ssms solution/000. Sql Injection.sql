USE [Northwind_Sql_Injection];
GO

IF OBJECT_ID('dbo.Sql_Injection_Demo') IS NOT NULL
	DROP PROCEDURE dbo.Sql_Injection_Demo;
GO

CREATE PROCEDURE dbo.Sql_Injection_Demo(
	@EmployeeID VARCHAR(50))
AS
BEGIN;
SET NOCOUNT ON;

DECLARE
	@Sql VARCHAR(MAX);

SET @Sql = '
SELECT
	[Title] + '' '' + [FirstName] + '' '' + [LastName] as Name
FROM
	[dbo].[Employees] WITH (NOLOCK)
WHERE
	[EmployeeID] = ' + @EmployeeID + ';';

EXEC (@Sql);

SET NOCOUNT OFF;

END;

GO

DECLARE
	@EmployeeID VARCHAR(50) = '6;DROP TABLE dbo.test';

EXEC dbo.Sql_Injection_Demo @EmployeeID;
GO