
/*
	Dynamic Sql. Not so scary?

		11. COPY TRIGGERS
*/

USE master;

SET NOCOUNT ON;

DECLARE 
	@srcDatabase		SYSNAME		= 'Northwind',
	@tarDatabase		SYSNAME		= 'Northwind_Copy',
	@dropExisting		INT		= 1,
	@exeQueryType		VARCHAR(10)	= 'EXECUTE',
	@exeShowCoreScripts	INT			= 0,--INVOKES SELECTED PURPOSE
	@exeFullImport		INT			= 0,
	@exeTableImport		INT			= 1,--INVOKES SELECTED PURPOSE
	@exeTablePKImport	INT			= 0,
	@exeTableDFImport	INT			= 0,
	@exeTableCKImport	INT			= 0,
	@exeTableFKImport	INT			= 0,
	@exeTableIXImport	INT			= 0,
	@exeViewImport		INT			= 0,
	@exeFunctionImport	INT			= 0,
	@exeProcedureImport	INT			= 0,
	@exeTriggerImport	INT			= 1,--INVOKES SELECTED PURPOSE
	@exeSampleSize		INT			= 2;

BEGIN;--EXECUTE

INSERT INTO dbo.dynamic_Sql_Import_Settings
(
	srcDatabase			,
	tarDatabase			,
	dropExisting		,
	exeQueryType		,
	exeShowCoreScripts	,
	exeFullImport		,
	exeTableImport		,
	exeTablePKImport	,
	exeTableDFImport	,
	exeTableCKImport	,
	exeTableFKImport	,
	exeTableIXImport	,
	exeViewImport		,
	exeFunctionImport	,
	exeProcedureImport	,
	exeTriggerImport	,
	exeSampleSize
)
SELECT 
	@srcDatabase		,
	@tarDatabase		,
	@dropExisting		,
	@exeQueryType		,
	@exeShowCoreScripts	,
	@exeFullImport		,
	@exeTableImport		,
	@exeTablePKImport	,
	@exeTableDFImport	,
	@exeTableCKImport	,
	@exeTableFKImport	,
	@exeTableIXImport	,
	@exeViewImport		,
	@exeFunctionImport	,
	@exeProcedureImport	,
	@exeTriggerImport	,
	@exeSampleSize;

EXEC dbo.dynamic_Sql_Import;

END;--EXECUTE

SET NOCOUNT OFF;

GO