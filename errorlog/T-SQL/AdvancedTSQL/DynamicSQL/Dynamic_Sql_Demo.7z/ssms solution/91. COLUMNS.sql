USE [Northwind];

IF OBJECT_ID('TEMPDB..##DYNAMIC_COLUMNS') IS NOT NULL
	DROP TABLE ##DYNAMIC_COLUMNS;

CREATE TABLE ##DYNAMIC_COLUMNS
(
	Id					INT IDENTITY(1,1),
	FullObjectName		VARCHAR(500),
	ColumnName			SYSNAME,
	FullColumnName		VARCHAR(500)
);

WITH CTE AS (
SELECT
	FullObjectName				= '[' + SCHEMA_NAME(schema_id) + '].[' + t.name + ']',
	ColumnName					= c.name,
	FullDataType				= master.dbo.GetLiteralDataType(t.name, c.name),
	IsIdentity					= ISNULL(ic.parent_column_id, 0), 	
	SeedValue					= ISNULL(ic.seed_value, 0), 
	IncrementValue				= ISNULL(ic.increment_value, 0),
	IsNullable					= c.is_nullable
FROM
	sys.tables t
INNER JOIN
	sys.columns c
ON
	t.object_id = c.object_id
LEFT OUTER JOIN
	(
		SELECT 
			parent_object_id = object_id,
			parent_column_id = column_id,
			seed_value, 
			increment_value
		FROM 
			sys.identity_columns
	) ic
ON
	t.object_id = ic.parent_object_id
AND	c.column_id = ic.parent_column_id)
INSERT INTO ##DYNAMIC_COLUMNS
SELECT
	FullObjectName,
	ColumnName,
	FullColumnName		= 
		'[' + ColumnName + '] ' + 
		FullDataType + 
		CASE IsIdentity 
			WHEN 0 THEN ' ' 
		ELSE ' IDENTITY(' + CAST(SeedValue AS VARCHAR(10)) + ',' + CAST(IncrementValue AS VARCHAR(10)) + ') '
		END + CASE IsNullable WHEN 0 THEN 'NOT NULL' ELSE 'NULL' END +
		+ CHAR(10)
FROM
	CTE;

SELECT * FROM ##DYNAMIC_COLUMNS;