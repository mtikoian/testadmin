
/*
	Dynamic Sql. Not so scary?
		0. CREATE DEMO PROCEDURE SETTINGS TABLE
*/

USE master;

IF OBJECT_ID('dbo.dynamic_InsertRequest') IS NOT NULL
	DROP PROCEDURE dbo.dynamic_InsertRequest;
GO

CREATE PROCEDURE [dbo].[dynamic_InsertRequest](
	@srcDatabase		SYSNAME,
	@tarDatabase		SYSNAME,
	@dropExisting		INT,
	@exeFullImport		INT,
	@exeTableImport		INT,
	@exeTablePKImport	INT,
	@exeTableDFImport	INT,
	@exeTableCKImport	INT,
	@exeTableFKImport	INT,
	@exeTableIXImport	INT,
	@exeViewImport		INT,
	@exeFunctionImport	INT,
	@exeProcedureImport	INT,
	@exeTriggerImport	INT)
AS

BEGIN;--EXECUTE

DECLARE
	@exeShowCoreScripts	INT			= 0,
	@exeQueryType		VARCHAR(10)	= 'EXECUTE',
	@exeSampleSize		INT			= 2;

INSERT INTO dbo.dynamic_Sql_Import_Settings
(
	srcDatabase			,
	tarDatabase			,
	dropExisting		,
	exeQueryType		,
	exeShowCoreScripts	,
	exeFullImport		,
	exeTableImport		,
	exeTablePKImport	,
	exeTableDFImport	,
	exeTableCKImport	,
	exeTableFKImport	,
	exeTableIXImport	,
	exeViewImport		,
	exeFunctionImport	,
	exeProcedureImport	,
	exeTriggerImport	,
	exeSampleSize
)
SELECT 
	@srcDatabase		,
	@tarDatabase		,
	@dropExisting		,
	@exeQueryType		,
	@exeShowCoreScripts	,
	@exeFullImport		,
	@exeTableImport		,
	@exeTablePKImport	,
	@exeTableDFImport	,
	@exeTableCKImport	,
	@exeTableFKImport	,
	@exeTableIXImport	,
	@exeViewImport		,
	@exeFunctionImport	,
	@exeProcedureImport	,
	@exeTriggerImport	,
	@exeSampleSize;

EXEC master.dbo.dynamic_Sql_Import;

END;--EXECUTE

SET NOCOUNT OFF;

GO

IF OBJECT_ID('dbo.dynamic_Sql_Import_Settings') IS NOT NULL
	DROP TABLE dbo.dynamic_Sql_Import_Settings;
GO

CREATE TABLE dbo.dynamic_Sql_Import_Settings
(
	id					INT IDENTITY(1, 1) NOT NULL,
	srcDatabase			SYSNAME,
	tarDatabase			SYSNAME,
	dropExisting		INT,
	exeQueryType		VARCHAR(10) DEFAULT 'SYNTAX' NOT NULL,
	exeShowCoreScripts	INT DEFAULT 1 NOT NULL,
	exeFullImport		INT DEFAULT 1 NOT NULL,
	exeTableImport		INT	DEFAULT 1 NOT NULL,
	exeTablePKImport	INT DEFAULT 1 NOT NULL,
	exeTableDFImport	INT DEFAULT 1 NOT NULL,
	exeTableCKImport	INT DEFAULT 1 NOT NULL,
	exeTableFKImport	INT DEFAULT 1 NOT NULL,
	exeTableIXImport	INT DEFAULT 1 NOT NULL,
	exeViewImport		INT DEFAULT 1 NOT NULL,
	exeFunctionImport	INT DEFAULT 1 NOT NULL,
	exeProcedureImport	INT DEFAULT 1 NOT NULL,
	exeTriggerImport	INT DEFAULT 1 NOT NULL,
	exeSampleSize		INT DEFAULT 2 NOT NULL
);

GO

WITH CTE AS (
SELECT
	id						= 1,
	srcDatabase				= 'Northwind',
	tarDatabase				= 'Northwind_Copy',
	dropExisting			= 1,
	exeQueryType			= 'SYNTAX',-- * THEN CHANGE TO 'EXECUTE'
	exeShowCoreScripts		= 1,--INVOKES SELECTED PURPOSE
	exeFullImport			= 0,
	exeTableImport			= 0,
	exeTablePKImport		= 0,
	exeTableDFImport		= 0,
	exeTableCKImport		= 0,
	exeTableFKImport		= 0,
	exeTableIXImport		= 0,
	exeViewImport			= 0,
	exeFunctionImport		= 0,
	exeProcedureImport		= 0,
	exeTriggerImport		= 0,
	exeSampleSize			= 2
UNION ALL 
SELECT
	id						= 2,
	srcDatabase				= 'Northwind',
	tarDatabase				= 'Northwind_Copy',
	dropExisting			= 1,
	exeQueryType			= 'SYNTAX',-- * THEN CHANGE TO 'EXECUTE'
	exeShowCoreScripts		= 0,
	exeFullImport			= 0,
	exeTableImport			= 1,--INVOKES SELECTED PURPOSE
	exeTablePKImport		= 0,
	exeTableDFImport		= 0,
	exeTableCKImport		= 0,
	exeTableFKImport		= 0,
	exeTableIXImport		= 0,
	exeViewImport			= 0,
	exeFunctionImport		= 0,
	exeProcedureImport		= 0,
	exeTriggerImport		= 0,
	exeSampleSize			= 2
UNION ALL 
SELECT
	id						= 3,
	srcDatabase				= 'Northwind',
	tarDatabase				= 'Northwind_Copy',
	dropExisting			= 1,
	exeQueryType			= 'SYNTAX',-- * THEN CHANGE TO 'EXECUTE'
	exeShowCoreScripts		= 0,
	exeFullImport			= 0,
	exeTableImport			= 1,--INVOKES SELECTED PURPOSE
	exeTablePKImport		= 1,--INVOKES SELECTED PURPOSE
	exeTableDFImport		= 0,
	exeTableCKImport		= 0,
	exeTableFKImport		= 0,
	exeTableIXImport		= 0,
	exeViewImport			= 0,
	exeFunctionImport		= 0,
	exeProcedureImport		= 0,
	exeTriggerImport		= 0,
	exeSampleSize			= 2
UNION ALL 
SELECT
	id						= 4,
	srcDatabase				= 'Northwind',
	tarDatabase				= 'Northwind_Copy',
	dropExisting			= 1,
	exeQueryType			= 'SYNTAX',-- * THEN CHANGE TO 'EXECUTE'
	exeShowCoreScripts		= 0,
	exeFullImport			= 0,
	exeTableImport			= 1,--INVOKES SELECTED PURPOSE
	exeTablePKImport		= 0,
	exeTableDFImport		= 1,--INVOKES SELECTED PURPOSE
	exeTableCKImport		= 0,
	exeTableFKImport		= 0,
	exeTableIXImport		= 0,
	exeViewImport			= 0,
	exeFunctionImport		= 0,
	exeProcedureImport		= 0,
	exeTriggerImport		= 0,
	exeSampleSize			= 2
UNION ALL 
SELECT
	id						= 5,
	srcDatabase				= 'Northwind',
	tarDatabase				= 'Northwind_Copy',
	dropExisting			= 1,
	exeQueryType			= 'SYNTAX',-- * THEN CHANGE TO 'EXECUTE'
	exeShowCoreScripts		= 0,
	exeFullImport			= 0,
	exeTableImport			= 1,--INVOKES SELECTED PURPOSE
	exeTablePKImport		= 0,
	exeTableDFImport		= 0,
	exeTableCKImport		= 1,--INVOKES SELECTED PURPOSE
	exeTableFKImport		= 0,
	exeTableIXImport		= 0,
	exeViewImport			= 0,
	exeFunctionImport		= 0,
	exeProcedureImport		= 0,
	exeTriggerImport		= 0,
	exeSampleSize			= 2
UNION ALL 
SELECT
	id						= 6,
	srcDatabase				= 'Northwind',
	tarDatabase				= 'Northwind_Copy',
	dropExisting			= 1,
	exeQueryType			= 'SYNTAX',-- * THEN CHANGE TO 'EXECUTE'
	exeShowCoreScripts		= 0,--INVOKES SELECTED PURPOSE
	exeFullImport			= 0,
	exeTableImport			= 1,--INVOKES SELECTED PURPOSE
	exeTablePKImport		= 0,
	exeTableDFImport		= 0,
	exeTableCKImport		= 0,
	exeTableFKImport		= 1,--INVOKES SELECTED PURPOSE
	exeTableIXImport		= 0,
	exeViewImport			= 0,
	exeFunctionImport		= 0,
	exeProcedureImport		= 0,
	exeTriggerImport		= 0,
	exeSampleSize			= 2
UNION ALL 
SELECT
	id						= 7,
	srcDatabase				= 'Northwind',
	tarDatabase				= 'Northwind_Copy',
	dropExisting			= 1,
	exeQueryType			= 'SYNTAX',-- * THEN CHANGE TO 'EXECUTE'
	exeShowCoreScripts		= 0,
	exeFullImport			= 0,
	exeTableImport			= 1,--INVOKES SELECTED PURPOSE
	exeTablePKImport		= 0,
	exeTableDFImport		= 0,
	exeTableCKImport		= 0,
	exeTableFKImport		= 0,
	exeTableIXImport		= 1,--INVOKES SELECTED PURPOSE
	exeViewImport			= 0,
	exeFunctionImport		= 0,
	exeProcedureImport		= 0,
	exeTriggerImport		= 0,
	exeSampleSize			= 2
UNION ALL 
SELECT
	id						= 8,
	srcDatabase				= 'Northwind',
	tarDatabase				= 'Northwind_Copy',
	dropExisting			= 1,
	exeQueryType			= 'SYNTAX',-- * THEN CHANGE TO 'EXECUTE'
	exeShowCoreScripts		= 0,
	exeFullImport			= 0,
	exeTableImport			= 0,
	exeTablePKImport		= 0,
	exeTableDFImport		= 0,
	exeTableCKImport		= 0,
	exeTableFKImport		= 0,
	exeTableIXImport		= 0,
	exeViewImport			= 0,
	exeFunctionImport		= 1,--INVOKES SELECTED PURPOSE
	exeProcedureImport		= 0,
	exeTriggerImport		= 0,
	exeSampleSize			= 2
UNION ALL 
SELECT
	id						= 9,
	srcDatabase				= 'Northwind',
	tarDatabase				= 'Northwind_Copy',
	dropExisting			= 1,
	exeQueryType			= 'SYNTAX',-- * THEN CHANGE TO 'EXECUTE'
	exeShowCoreScripts		= 0,
	exeFullImport			= 0,
	exeTableImport			= 1,--INVOKES SELECTED PURPOSE
	exeTablePKImport		= 0,
	exeTableDFImport		= 0,
	exeTableCKImport		= 0,
	exeTableFKImport		= 0,
	exeTableIXImport		= 0,
	exeViewImport			= 1,--INVOKES SELECTED PURPOSE
	exeFunctionImport		= 0,
	exeProcedureImport		= 0,
	exeTriggerImport		= 0,
	exeSampleSize			= 2
UNION ALL 
SELECT
	id						= 10,
	srcDatabase				= 'Northwind',
	tarDatabase				= 'Northwind_Copy',
	dropExisting			= 1,
	exeQueryType			= 'SYNTAX',-- * THEN CHANGE TO 'EXECUTE'
	exeShowCoreScripts		= 0,
	exeFullImport			= 0,
	exeTableImport			= 0,
	exeTablePKImport		= 0,
	exeTableDFImport		= 0,
	exeTableCKImport		= 0,
	exeTableFKImport		= 0,
	exeTableIXImport		= 0,
	exeViewImport			= 0,
	exeFunctionImport		= 0,
	exeProcedureImport		= 1,--INVOKES SELECTED PURPOSE
	exeTriggerImport		= 0,
	exeSampleSize			= 2
UNION ALL 
SELECT
	id						= 11,
	srcDatabase				= 'Northwind',
	tarDatabase				= 'Northwind_Copy',
	dropExisting			= 1,
	exeQueryType			= 'SYNTAX',-- * THEN CHANGE TO 'EXECUTE'
	exeShowCoreScripts		= 0,--INVOKES SELECTED PURPOSE
	exeFullImport			= 0,
	exeTableImport			= 1,--INVOKES SELECTED PURPOSE
	exeTablePKImport		= 0,
	exeTableDFImport		= 0,
	exeTableCKImport		= 0,
	exeTableFKImport		= 0,
	exeTableIXImport		= 0,
	exeViewImport			= 0,
	exeFunctionImport		= 0,
	exeProcedureImport		= 0,
	exeTriggerImport		= 1,--INVOKES SELECTED PURPOSE
	exeSampleSize			= 2
UNION ALL 
SELECT
	id						= 12,
	srcDatabase				= 'Northwind',
	tarDatabase				= 'Northwind_Copy',
	dropExisting			= 1,
	exeQueryType			= 'SYNTAX',-- * THEN CHANGE TO 'EXECUTE'
	exeShowCoreScripts		= 0,
	exeFullImport			= 1,--INVOKES SELECTED PURPOSE
	exeTableImport			= 0,
	exeTablePKImport		= 0,
	exeTableDFImport		= 0,
	exeTableCKImport		= 0,
	exeTableFKImport		= 0,
	exeTableIXImport		= 0,
	exeViewImport			= 0,
	exeFunctionImport		= 0,
	exeProcedureImport		= 0,
	exeTriggerImport		= 0,
	exeSampleSize			= 2
UNION ALL 
SELECT
	id						= 13,
	srcDatabase				= 'pubs',
	tarDatabase				= 'pubs_dynamic',
	dropExisting			= 1,
	exeQueryType			= 'SYNTAX',-- * THEN CHANGE TO 'EXECUTE'
	exeShowCoreScripts		= 0,
	exeFullImport			= 1,--INVOKES SELECTED PURPOSE
	exeTableImport			= 0,
	exeTablePKImport		= 0,
	exeTableDFImport		= 0,
	exeTableCKImport		= 0,
	exeTableFKImport		= 0,
	exeTableIXImport		= 0,
	exeViewImport			= 0,
	exeFunctionImport		= 0,
	exeProcedureImport		= 0,
	exeTriggerImport		= 0,
	exeSampleSize			= 2)

INSERT INTO dbo.dynamic_Sql_Import_Settings
(
	srcDatabase			,
	tarDatabase			,
	dropExisting		,
	exeQueryType		,
	exeShowCoreScripts	,
	exeFullImport		,
	exeTableImport		,
	exeTablePKImport	,
	exeTableDFImport	,
	exeTableCKImport	,
	exeTableFKImport	,
	exeTableIXImport	,
	exeViewImport		,
	exeFunctionImport	,
	exeProcedureImport	,
	exeTriggerImport	,
	exeSampleSize
)
SELECT
	srcDatabase			,
	tarDatabase			,
	dropExisting		,
	exeQueryType		,
	exeShowCoreScripts	,
	exeFullImport		,
	exeTableImport		,
	exeTablePKImport	,
	exeTableDFImport	,
	exeTableCKImport	,
	exeTableFKImport	,
	exeTableIXImport	,
	exeViewImport		,
	exeFunctionImport	,
	exeProcedureImport	,
	exeTriggerImport	,
	exeSampleSize
FROM 
	CTE
ORDER BY
	id;

GO