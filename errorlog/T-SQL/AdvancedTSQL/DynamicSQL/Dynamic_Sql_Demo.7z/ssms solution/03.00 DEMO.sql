
/*
	Dynamic Sql. Not so scary?
		0. EXECUTE PREPAGED PARAMETERS
*/

USE master;

EXEC master.dbo.dynamic_Sql_Import 1;--01. COPY DATABASE AND SCHEMAS
GO

EXEC master.dbo.dynamic_Sql_Import 2;--02. COPY TABLES
GO

EXEC master.dbo.dynamic_Sql_Import 3;--03. COPY TABLES AND PRIMARY KEYS
GO

EXEC master.dbo.dynamic_Sql_Import 4;--04. COPY TABLES AND DEFAULT CONSTRAINTS
GO

EXEC master.dbo.dynamic_Sql_Import 5;--05. COPY TABLES AND CHECK CONSTRAINTS
GO

EXEC master.dbo.dynamic_Sql_Import 6;--06. COPY TABLES AND FOREIGN KEYS
GO

EXEC master.dbo.dynamic_Sql_Import 7;--07. COPY TABLES AND INDEXES
GO

EXEC master.dbo.dynamic_Sql_Import 8;--08. COPY FUNCTIONS
GO

EXEC master.dbo.dynamic_Sql_Import 9;--09. COPY VIEWS
GO

EXEC master.dbo.dynamic_Sql_Import 10;--10. COPY STORED PROCEDURES
GO

EXEC master.dbo.dynamic_Sql_Import 11;--11. COPY TRIGGERS
GO

EXEC master.dbo.dynamic_Sql_Import 12;--12. COPY ALL OBJECTS
GO

EXEC master.dbo.dynamic_Sql_Import 13;--13. PUBS : COPY ALL OBJECTS
GO