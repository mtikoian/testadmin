USE [Northwind];

IF OBJECT_ID('TEMPDB..##DYNAMIC_PRIMARYKEYS') IS NOT NULL
	DROP TABLE ##DYNAMIC_PRIMARYKEYS;

CREATE TABLE ##DYNAMIC_PRIMARYKEYS
(
	Id					INT IDENTITY(1,1),
	FullObjectName		VARCHAR(500),
	ColumnName			SYSNAME,
	PrimaryKey			SYSNAME,
	PrimaryKeyColumn	SYSNAME,
	PrimaryKeyOrdinal	INT
);

WITH CTE AS (
SELECT
	FullObjectName				= '[' + SCHEMA_NAME(schema_id) + '].[' + t.name + ']',
	ColumnName					= c.name,
	PrimaryKey					= ISNULL(pk.CONSTRAINT_NAME, ''),
	PrimaryKeyOrdinal			= ISNULL(ix.index_column_id, 0),
	PrimaryKeyIsDescending		= ISNULL(ix.is_descending_key, '')
FROM
	sys.tables t
INNER JOIN
	sys.columns c
ON
	t.object_id = c.object_id
INNER JOIN
	(
		SELECT 
			parent_object_id = OBJECT_ID(ccu.TABLE_SCHEMA + '.' + ccu.TABLE_NAME),
			ccu.COLUMN_NAME,
			ccu.CONSTRAINT_NAME					 
		FROM 
			INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE ccu
		INNER JOIN
			INFORMATION_SCHEMA.TABLE_CONSTRAINTS tc
		ON
			ccu.TABLE_SCHEMA	= tc.TABLE_SCHEMA
		AND	ccu.TABLE_NAME		= tc.TABLE_NAME
		AND	ccu.CONSTRAINT_NAME = tc.CONSTRAINT_NAME			
		WHERE
			constraint_type = 'PRIMARY KEY'
	) AS pk
ON
	t.object_id = pk.parent_object_id
AND	c.name		= pk.COLUMN_NAME
INNER JOIN
	(
		SELECT
			parent_object_id	= i.object_id,
			name				= i.name,
			index_type			= type_desc,
			index_column_id		= ic.index_column_id ,
			column_id			= ic.column_id, 
			is_descending_key	= ic.is_descending_key 
		FROM 
			sys.indexes i
		INNER JOIN 
			sys.index_columns ic
		ON
			i.object_id = ic.object_id
		AND	i.index_id = ic.index_id
		WHERE
			name IS NOT NULL
		AND	is_primary_key = 1
	) AS ix
ON
	t.object_id = ix.parent_object_id
AND	c.column_id = ix.column_id)
INSERT INTO ##DYNAMIC_PRIMARYKEYS
SELECT
	FullObjectName,
	ColumnName,
	PrimaryKey			= PrimaryKey,
	PrimaryKeyColumn	= 
		'[' + ColumnName + '] ' + CASE WHEN PrimaryKeyIsDescending = 0 THEN 'ASC' ELSE 'DESC' END
		+ CHAR(10),
	PrimaryKeyOrdinal
FROM
	CTE;

SELECT * FROM ##DYNAMIC_PRIMARYKEYS;