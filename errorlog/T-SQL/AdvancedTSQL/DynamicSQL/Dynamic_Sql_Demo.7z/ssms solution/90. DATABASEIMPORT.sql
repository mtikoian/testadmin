
/*
	Dynamic Sql. Not so scary?
*/
SET NOCOUNT ON;

USE master;

DECLARE
	@srcDatabase	SYSNAME = 'Northwind',
	@tarDatabase	SYSNAME = 'Northwind_Copy',
	@dropExisting	INT		= 1;

DECLARE
	@processid			INT,
	@device_directory	NVARCHAR(MAX),
	@Sql				VARCHAR(MAX),
	@Sql_Schemas		VARCHAR(MAX),
	@Sql_Tables			VARCHAR(MAX),
	@Sql_PKeys			VARCHAR(MAX),
	@Sql_Defaults		VARCHAR(MAX),
	@Sql_CConstraints	VARCHAR(MAX),
	@Sql_FKConstraints	VARCHAR(MAX),
	@Sql_Indexes		VARCHAR(MAX),
	@IndexName			VARCHAR(MAX),
	@IndexType			VARCHAR(20),
	@Sql_Modules		VARCHAR(MAX),
	@Cursor				INT,
	@Cursor2			INT,
	@TableName			SYSNAME;

--CLEAN THE SUPPLIED PARAMTERS
SELECT
	@srcDatabase	= REPLACE(REPLACE(LTRIM(RTRIM(ISNULL(@srcDatabase, ''))), '[', ''), ']', ''),
	@tarDatabase	= REPLACE(REPLACE(LTRIM(RTRIM(ISNULL(@tarDatabase, ''))), '[', ''), ']', ''),
	@dropExisting	= ISNULL(@dropExisting, 0);

--CHECK IF SOURCE & TARGET DATABASES HAVE BEEN SPECIFIED
IF @srcDatabase = '' OR @tarDatabase = ''
BEGIN;
	RAISERROR ('Incomplete parameters supplied!', 16, 1);
	RETURN;
END;

--CHECK IF TARGET DATABASE EXISTS
IF EXISTS (SELECT name FROM sysdatabases WHERE name = @tarDatabase)
BEGIN;
	--TARGET DATABASE EXISTS : CHECK IF THE OVERWRITE FLAG IS ACTIVE
	IF @dropExisting = 0
	BEGIN;
		RAISERROR ('Database already exists!', 16, 1);
		RETURN;
	END;

	--OVERWRITE FLAG IS ACTIVE : DROP THE EXISTING DATABASE
	BEGIN;

	SELECT  
		@processid = MIN(spid)
	FROM    
		master.dbo.sysprocesses
	WHERE   
		dbid = DB_ID(@tarDatabase);

	WHILE @processid IS NOT NULL 
	BEGIN;
        
		EXEC ('KILL ' + @processid);

		SELECT  
			@processid = MIN(spid)
		FROM    
			master.dbo.sysprocesses
		WHERE   
			dbid = DB_ID(@tarDatabase);
	END;
	
	SET @Sql = '
DROP DATABASE [' + @tarDatabase + '];';
	EXEC (@Sql);
	END;
END;

--GET THE DIRECTORY TO WHICH FILES ARE TO BE CREATED
SELECT 
	@device_directory = SUBSTRING(filename, 1, CHARINDEX(N'master.mdf', LOWER(filename)) - 1)
FROM 
	master.dbo.sysaltfiles 
WHERE 
	dbid = 1 
AND fileid = 1;

BEGIN;--CREATE TARGET DATABASE
SET @Sql = '
CREATE DATABASE ' + @tarDatabase + '
ON PRIMARY 
	(
		NAME = N''' + @tarDatabase + ''', 
		FILENAME = N''' + @device_directory + N'' + LOWER(@tarDatabase) + '.mdf''
	)
LOG ON 
	(
		NAME = N''' + @tarDatabase + '_log'',  
		FILENAME = N''' + @device_directory + N'' + LOWER(@tarDatabase) + '.ldf''
	);';
EXEC (@Sql);
END;--CREATE TARGET DATABASE

BEGIN;--CREATE RUN TIME OBJECTS
IF OBJECT_ID('dbo.dynamic_GetLiteralDataType') IS NOT NULL
	DROP FUNCTION dbo.dynamic_GetLiteralDataType;
SET @Sql = '
CREATE FUNCTION dbo.dynamic_GetLiteralDataType(@TableName as SYSNAME, @ColumnName as SYSNAME)
    RETURNS VARCHAR(100)
    AS
    BEGIN;

        DECLARE @DataType as VARCHAR(100)
        DECLARE @FullDataType as VARCHAR(100)
        DECLARE @MaxLength AS INT
        DECLARE @Precision AS INT
        DECLARE @Scale AS INT

        SET @DataType =(SELECT TOP 1 y.name FROM ' + @srcDatabase + '.SYS.TABLES t
        INNER JOIN ' + @srcDatabase + '.SYS.COLUMNS c ON t.object_id = c.object_id
        INNER JOIN ' + @srcDatabase + '.SYS.TYPES y ON y.system_type_id = c.system_type_id
        WHERE t.name = @TableName AND c.name = @ColumnName)

        SET @MaxLength =(SELECT TOP 1 c.max_length FROM ' + @srcDatabase + '.SYS.TABLES t
        INNER JOIN ' + @srcDatabase + '.SYS.COLUMNS c ON t.object_id = c.object_id
        INNER JOIN ' + @srcDatabase + '.SYS.TYPES y ON y.system_type_id = c.system_type_id
        WHERE t.name = @TableName AND c.name = @ColumnName)

        SET @Precision =(SELECT TOP 1 c.precision FROM ' + @srcDatabase + '.SYS.TABLES t
        INNER JOIN ' + @srcDatabase + '.SYS.COLUMNS c ON t.object_id = c.object_id
        INNER JOIN ' + @srcDatabase + '.SYS.TYPES y ON y.system_type_id = c.system_type_id
        WHERE t.name = @TableName AND c.name = @ColumnName)

        SET @Scale =(SELECT TOP 1 c.scale FROM ' + @srcDatabase + '.SYS.TABLES t
        INNER JOIN ' + @srcDatabase + '.SYS.COLUMNS c ON t.object_id = c.object_id
        INNER JOIN ' + @srcDatabase + '.SYS.TYPES y ON y.system_type_id = c.system_type_id
        WHERE t.name = @TableName AND c.name = @ColumnName)

        IF @DataType =''decimal'' OR @DataType = ''NUMERIC''
        BEGIN
            RETURN @DataType + ''(''+ @Precision + '','' + @Scale + '')'';
        END

        IF @DataType LIKE ''%var%'' OR @DataType LIKE ''%char%''
        BEGIN
            RETURN @DataType + ''(''+ CASE @MaxLength WHEN -1 THEN ''MAX'' ELSE CAST(@MaxLength AS VARCHAR(10)) END + '')''
        END

        RETURN @DataType
    END;';
EXEC (@Sql);
END;

SELECT
	@srcDatabase	= '[' + @srcDatabase + ']',
	@tarDatabase	= '[' + @tarDatabase + ']';

BEGIN;--CREATE SCHEMAS

SET @Sql = '
IF OBJECT_ID(''TEMPDB..##DYNAMIC_OBJECTS'') IS NOT NULL
	DROP TABLE ##DYNAMIC_OBJECTS;';
EXEC (@Sql);
SET @Sql = '
CREATE TABLE ##DYNAMIC_OBJECTS
(
	name SYSNAME
);';
EXEC (@Sql);

SET @Sql = '
SELECT
	name
FROM
	' + @srcDatabase + '.sys.schemas;';
INSERT INTO ##DYNAMIC_OBJECTS
EXEC (@Sql);

SELECT @Sql_Schemas = (
SELECT
	'USE ' + @tarDatabase + ';' + CHAR(10) + CHAR(10) + 
	LEFT(txt, LEN(txt) - 1)
FROM
	(
		SELECT
			'IF SCHEMA_ID(''' + name + ''') IS NULL' + CHAR(10) + 
			'EXEC(''CREATE SCHEMA [' + name + '];'')' + CHAR(10)
		FROM 
			##DYNAMIC_OBJECTS
		FOR XML 
			PATH('')
	) t(txt));
EXEC (@Sql_Schemas);

END;--CREATE SCHEMAS

BEGIN;--GET COLUMNS
SET @Sql = '
IF OBJECT_ID(''TEMPDB..##DYNAMIC_COLUMNS'') IS NOT NULL
	DROP TABLE ##DYNAMIC_COLUMNS;';
EXEC (@Sql);
SET @Sql = '
USE ' + @srcDatabase + ';' + CHAR(10) + '
CREATE TABLE ##DYNAMIC_COLUMNS
(
	Id					INT IDENTITY(1,1),
	FullObjectName		VARCHAR(500),
	ColumnName			SYSNAME,
	FullColumnName		VARCHAR(500)
);

WITH CTE AS (
SELECT
	FullObjectName				= ''['' + SCHEMA_NAME(schema_id) + ''].['' + t.name + '']'',
	ColumnName					= c.name,
	FullDataType				= master.dbo.dynamic_GetLiteralDataType(t.name, c.name),
	IsIdentity					= ISNULL(ic.parent_column_id, 0), 	
	SeedValue					= ISNULL(ic.seed_value, 0), 
	IncrementValue				= ISNULL(ic.increment_value, 0),
	IsNullable					= c.is_nullable
FROM
	sys.tables t
INNER JOIN
	sys.columns c
ON
	t.object_id = c.object_id
LEFT OUTER JOIN
	(
		SELECT 
			parent_object_id = object_id,
			parent_column_id = column_id,
			seed_value, 
			increment_value
		FROM 
			sys.identity_columns
	) ic
ON
	t.object_id = ic.parent_object_id
AND	c.column_id = ic.parent_column_id)
INSERT INTO ##DYNAMIC_COLUMNS
SELECT
	FullObjectName,
	ColumnName,
	FullColumnName		= 
		''['' + ColumnName + ''] '' + 
		FullDataType + 
		CASE IsIdentity 
			WHEN 0 THEN '' '' 
		ELSE '' IDENTITY('' + CAST(SeedValue AS VARCHAR(10)) + '','' + CAST(IncrementValue AS VARCHAR(10)) + '') ''
		END + CASE IsNullable WHEN 0 THEN ''NOT NULL'' ELSE ''NULL'' END +
		+ CHAR(10)
FROM
	CTE;';
EXEC (@Sql);
END;--GET COLUMNS

BEGIN;--GET PRIMARY KEYS
SET @Sql = '
IF OBJECT_ID(''TEMPDB..##DYNAMIC_PRIMARYKEYS'') IS NOT NULL
	DROP TABLE ##DYNAMIC_PRIMARYKEYS;';
EXEC (@Sql);
SET @Sql = '
USE ' + @srcDatabase + ';' + CHAR(10) + '
CREATE TABLE ##DYNAMIC_PRIMARYKEYS
(
	Id					INT IDENTITY(1,1),
	FullObjectName		VARCHAR(500),
	ColumnName			SYSNAME,
	PrimaryKey			SYSNAME,
	PrimaryKeyColumn	SYSNAME,
	PrimaryKeyOrdinal	INT
);

WITH CTE AS (
SELECT
	FullObjectName				= ''['' + SCHEMA_NAME(schema_id) + ''].['' + t.name + '']'',
	ColumnName					= c.name,
	PrimaryKey					= ISNULL(pk.CONSTRAINT_NAME, ''''),
	PrimaryKeyOrdinal			= ISNULL(ix.index_column_id, 0),
	PrimaryKeyIsDescending		= ISNULL(ix.is_descending_key, '''')
FROM
	sys.tables t
INNER JOIN
	sys.columns c
ON
	t.object_id = c.object_id
INNER JOIN
	(
		SELECT 
			parent_object_id = OBJECT_ID(ccu.TABLE_SCHEMA + ''.'' + ccu.TABLE_NAME),
			ccu.COLUMN_NAME,
			ccu.CONSTRAINT_NAME					 
		FROM 
			INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE ccu
		INNER JOIN
			INFORMATION_SCHEMA.TABLE_CONSTRAINTS tc
		ON
			ccu.TABLE_SCHEMA	= tc.TABLE_SCHEMA
		AND	ccu.TABLE_NAME		= tc.TABLE_NAME
		AND	ccu.CONSTRAINT_NAME = tc.CONSTRAINT_NAME			
		WHERE
			constraint_type = ''PRIMARY KEY''
	) AS pk
ON
	t.object_id = pk.parent_object_id
AND	c.name		= pk.COLUMN_NAME
INNER JOIN
	(
		SELECT
			parent_object_id	= i.object_id,
			name				= i.name,
			index_type			= type_desc,
			index_column_id		= ic.index_column_id ,
			column_id			= ic.column_id, 
			is_descending_key	= ic.is_descending_key 
		FROM 
			sys.indexes i
		INNER JOIN 
			sys.index_columns ic
		ON
			i.object_id = ic.object_id
		AND	i.index_id = ic.index_id
		WHERE
			name IS NOT NULL
		AND	is_primary_key = 1
	) AS ix
ON
	t.object_id = ix.parent_object_id
AND	c.column_id = ix.column_id)
INSERT INTO ##DYNAMIC_PRIMARYKEYS
SELECT
	FullObjectName,
	ColumnName,
	PrimaryKey			= PrimaryKey,
	PrimaryKeyColumn	= 
		''['' + ColumnName + ''] '' + CASE WHEN PrimaryKeyIsDescending = 0 THEN ''ASC'' ELSE ''DESC'' END
		+ CHAR(10),
	PrimaryKeyOrdinal
FROM
	CTE;';
EXEC (@Sql);
END;--GET PRIMARY KEYS

BEGIN;--GET DEFAULT CONSTRAINTS
SET @Sql = '
IF OBJECT_ID(''TEMPDB..##DYNAMIC_DEFAULTS'') IS NOT NULL
	DROP TABLE ##DYNAMIC_DEFAULTS;';
EXEC (@Sql);
SET @Sql = '
USE ' + @srcDatabase + ';' + CHAR(10) + '
CREATE TABLE ##DYNAMIC_DEFAULTS
(
	Id					INT IDENTITY(1,1),
	FullObjectName		VARCHAR(500),
	ColumnName			SYSNAME,
	DefaultConstraint	VARCHAR(MAX)
);

WITH CTE AS (
SELECT
	FullObjectName				= ''['' + SCHEMA_NAME(schema_id) + ''].['' + t.name + '']'',
	ColumnName					= c.name,
	DefaultConstraint			= ISNULL(dc.name, ''''),
	DefaultConstraintValue		= ISNULL(dc.definition, '''')
FROM
	sys.tables t
INNER JOIN
	sys.columns c
ON
	t.object_id = c.object_id
INNER JOIN
	(
		SELECT 
			name, 
			parent_object_id,
			parent_column_id ,
			definition
		FROM 
			sys.default_constraints 
	) dc
ON
	t.object_id = dc.parent_object_id
AND	c.column_id = dc.parent_column_id
WHERE
	ISNULL(dc.name, '''') <> '''')
INSERT INTO ##DYNAMIC_DEFAULTS
SELECT
	FullObjectName,
	ColumnName,
	DefaultConstraint	= 
		''ALTER TABLE '' + FullObjectName + '' ADD  CONSTRAINT ['' + DefaultConstraint + '']  DEFAULT '' + DefaultConstraintValue + '' FOR ['' + ColumnName + ''];'' 
		+ CHAR(10)
FROM
	CTE;';
EXEC (@Sql);
END;--GET DEFAULT CONSTRAINTS

BEGIN;--GET CHECK CONSTRAINTS
SET @Sql = '
IF OBJECT_ID(''TEMPDB..##DYNAMIC_CHECKS'') IS NOT NULL
	DROP TABLE ##DYNAMIC_CHECKS;';
EXEC (@Sql);
SET @Sql = '
USE ' + @srcDatabase + ';' + CHAR(10) + '
CREATE TABLE ##DYNAMIC_CHECKS
(
	Id					INT IDENTITY(1,1),
	FullObjectName		VARCHAR(500),
	ColumnName			SYSNAME,
	CheckConstraint		VARCHAR(MAX)
);

WITH CTE AS (
SELECT
	FullObjectName				= ''['' + SCHEMA_NAME(schema_id) + ''].['' + t.name + '']'',
	ColumnName					= c.name,
	CheckConstraint				= ISNULL(ckc.name, ''''),
	CheckConstraintValue		= ISNULL(ckc.definition, ''''),
	DefaultConstraint			= ISNULL(dc.name, '''')
FROM
	sys.tables t
INNER JOIN
	sys.columns c
ON
	t.object_id = c.object_id
INNER JOIN
	(
		SELECT 
			name,
			object_id,
			parent_object_id,
			parent_column_id ,
			definition
		FROM 
			sys.check_constraints 
	) ckc
ON
	t.object_id = ckc.parent_object_id
AND	c.column_id = ckc.parent_column_id
INNER JOIN
	(
		SELECT 
			name, 
			parent_object_id,
			object_id
		FROM 
			sys.objects 
	) dc
ON
	ckc.parent_object_id = dc.parent_object_id
AND	ckc.object_id = dc.object_id
WHERE
	ISNULL(ckc.name, '''') <> '''')
INSERT INTO ##DYNAMIC_CHECKS
SELECT
	FullObjectName,
	ColumnName,
	CheckConstraint		= 
		''ALTER TABLE '' + FullObjectName + '' WITH NOCHECK ADD CONSTRAINT ['' + DefaultConstraint + ''] CHECK '' + CheckConstraintValue + '';'' + CHAR(10) + 
		''ALTER TABLE '' + FullObjectName + '' CHECK CONSTRAINT ['' + DefaultConstraint + ''];'' 
		+ CHAR(10)
FROM
	CTE;';
EXEC (@Sql);
END;--GET CHECK CONSTRAINTS

BEGIN;--GET FOREIGN KEYS
SET @Sql = '
IF OBJECT_ID(''TEMPDB..##DYNAMIC_FOREIGNKEYS'') IS NOT NULL
	DROP TABLE ##DYNAMIC_FOREIGNKEYS;';
EXEC (@Sql);
SET @Sql = '
USE ' + @srcDatabase + ';' + CHAR(10) + '
CREATE TABLE ##DYNAMIC_FOREIGNKEYS
(
	Id					INT IDENTITY(1,1),
	FullObjectName		VARCHAR(500),
	ColumnName			SYSNAME,
	ForeignKey			VARCHAR(MAX)
);

WITH CTE AS (
SELECT
	FullObjectName				= ''['' + SCHEMA_NAME(schema_id) + ''].['' + t.name + '']'',
	ColumnName					= c.name,
	ForeignKey					= ISNULL(fk.name, ''''),
	ForeignKeyReference			= ISNULL(fk.referenced_object, ''''),
	ForeignKeyColumn			= ISNULL(fk.referenced_column, '''')
FROM
	sys.tables t
INNER JOIN
	sys.columns c
ON
	t.object_id = c.object_id
INNER JOIN
	(
		SELECT 
			name = OBJECT_NAME(constraint_object_id),
			parent_object_id,
			referenced_object = OBJECT_SCHEMA_NAME(referenced_object_id) + ''.'' + OBJECT_NAME(referenced_object_id),
			parent_column_id,
			referenced_column = c.name
		FROM 
			sys.foreign_key_columns fkc
		INNER JOIN
			sys.columns c
		ON
			fkc.referenced_object_id = c.object_id
		AND	fkc.referenced_column_id = c.column_id
	) fk
ON
	t.object_id = fk.parent_object_id
AND	c.column_id = fk.parent_column_id
WHERE
	ISNULL(fk.name, '''') <> '''')
INSERT INTO ##DYNAMIC_FOREIGNKEYS
SELECT
	FullObjectName,
	ColumnName,
	ForeignKey		=  
			''ALTER TABLE '' + FullObjectName + '' WITH NOCHECK ADD  CONSTRAINT ['' + ForeignKey + ''] FOREIGN KEY(['' + ColumnName + ''])''  + CHAR(10) + 
			''REFERENCES '' + ForeignKeyReference + '' (['' + ForeignKeyColumn + '']);'' + CHAR(10) + 
			''ALTER TABLE '' + FullObjectName + '' CHECK CONSTRAINT ['' + ForeignKey + ''];'' 
			+ CHAR(10)
FROM
	CTE;';
EXEC (@Sql);
END;--GET FOREIGN KEYS

BEGIN;--GET INDEXES
SET @Sql = '
IF OBJECT_ID(''TEMPDB..##DYNAMIC_INDEXES'') IS NOT NULL
	DROP TABLE ##DYNAMIC_INDEXES;';
EXEC (@Sql);
SET @Sql = '
USE ' + @srcDatabase + ';' + CHAR(10) + '
CREATE TABLE ##DYNAMIC_INDEXES
(
	Id					INT IDENTITY(1,1),
	FullObjectName		VARCHAR(500),
	ColumnName			SYSNAME,
	IndexName			SYSNAME,
	IndexType			SYSNAME,
	IndexColumnOrdinal	INT,
	IndexIsDescending	INT
);

WITH CTE AS (
SELECT
	FullObjectName				= ''['' + SCHEMA_NAME(schema_id) + ''].['' + t.name + '']'',
	ColumnName					= c.name,
	IndexName					= ISNULL(ix.name, ''''),
	IndexType					= ISNULL(ix.index_type, ''''),
	IndexColumnOrdinal			= ISNULL(ix.index_column_id, 0),
	IndexIsDescending			= ISNULL(ix.is_descending_key, 0)
FROM
	sys.tables t
INNER JOIN
	sys.columns c
ON
	t.object_id = c.object_id
INNER JOIN
	(
		SELECT
			parent_object_id	= i.object_id,
			name				= i.name,
			index_type			= type_desc,
			index_column_id		= ic.index_column_id ,
			column_id			= ic.column_id, 
			is_descending_key	= ic.is_descending_key 
		FROM 
			sys.indexes i
		INNER JOIN 
			sys.index_columns ic
		ON
			i.object_id = ic.object_id
		AND	i.index_id = ic.index_id
		WHERE
			name IS NOT NULL
		AND	is_primary_key = 0
	) AS ix
ON
	t.object_id = ix.parent_object_id
AND	c.column_id = ix.column_id)
INSERT INTO ##DYNAMIC_INDEXES
SELECT
	FullObjectName,
	ColumnName,
	IndexName			= IndexName,
	IndexType			= IndexType,
	IndexColumnOrdinal	= IndexColumnOrdinal,
	IndexIsDescending	= IndexIsDescending
FROM
	CTE;';
EXEC (@Sql);
END;--GET INDEXES

BEGIN;--CREATE TABLE OBJECTS

SET @Sql = '
IF OBJECT_ID(''TEMPDB..##DYNAMIC_OBJECTS'') IS NOT NULL
	DROP TABLE ##DYNAMIC_OBJECTS;';
EXEC (@Sql);
SET @Sql = '
CREATE TABLE ##DYNAMIC_OBJECTS
(
	Id		INT IDENTITY(1,1),
	name	SYSNAME
);';
EXEC (@Sql);

SET @Sql = '
USE ' + @srcDatabase + ';' + CHAR(10) + CHAR(10) + '
SELECT
	''['' + SCHEMA_NAME(schema_id) + ''].['' + name + '']''
FROM
	sys.tables;';
INSERT INTO ##DYNAMIC_OBJECTS
EXEC (@Sql);

SET @Cursor = 1;

WHILE @Cursor <= (SELECT COUNT(1) FROM ##DYNAMIC_OBJECTS)
BEGIN;
BEGIN;--GET CURRENT TABLE NAME
SELECT 
	@TableName = name 
FROM 
	##DYNAMIC_OBJECTS
WHERE
	id = @Cursor;
END;--GET CURRENT TABLE NAME

BEGIN;--CREATE TABLES
SELECT @Sql_Tables = (
SELECT
	'USE ' + @tarDatabase + ';' + CHAR(10) + CHAR(10) + 
	'CREATE TABLE ' + @TableName + '(' + CHAR(10) + 
	LEFT(txt, LEN(txt) - 1) + CHAR(10)
FROM
	(
		SELECT
			FullColumnName + ','
		FROM 
			##DYNAMIC_COLUMNS
		WHERE
			FullObjectName = @TableName
		FOR XML 
			PATH('')
	) t(txt));

BEGIN;--CREATE PRIMARY KEYS
SELECT @Sql_PKeys = (
SELECT
	'CONSTRAINT [' + 
	(
		SELECT DISTINCT
			PrimaryKey
		FROM 
			##DYNAMIC_PRIMARYKEYS
		WHERE
			FullObjectName = @TableName	
	) + '] PRIMARY KEY CLUSTERED' + CHAR(10) + 
	'(' + CHAR(10) +
	LEFT(txt, LEN(txt) - 1)  + 
	')WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]' +
	') ON [PRIMARY];' + CHAR(10)
FROM
	(
		SELECT
			PrimaryKeyColumn + ','
		FROM 
			##DYNAMIC_PRIMARYKEYS
		WHERE
			FullObjectName = @TableName
		ORDER BY
			PrimaryKeyOrdinal
		FOR XML 
			PATH('')
	) t(txt));
END;--CREATE PRIMARY KEYS

SET @Sql_Tables = @Sql_Tables + @Sql_PKeys;

EXEC (@Sql_Tables);
END;--CREATE TABLES

BEGIN;--CREATE DEFAULTS
SELECT @Sql_Defaults = (
SELECT
	'USE ' + @tarDatabase + ';' + CHAR(10) + CHAR(10) + 
	LEFT(txt, LEN(txt) - 1)  + CHAR(10)
FROM
	(
		SELECT
			DefaultConstraint + ''
		FROM 
			##DYNAMIC_DEFAULTS
		WHERE
			FullObjectName = @TableName
		FOR XML 
			PATH('')
	) t(txt));
IF ISNULL(@Sql_Defaults, '') <> ''
	EXEC (@Sql_Defaults);
END;--CREATE DEFAULTS

BEGIN;--CREATE CHECK CONSTRAINTS
SELECT 
	@Sql = 'USE ' + @tarDatabase + ';' + CHAR(10) + CHAR(10),
	@Sql_CConstraints = '';

SELECT
	@Sql_CConstraints += CASE WHEN ISNULL(CheckConstraint, '') = '' THEN '' ELSE
	CheckConstraint + CHAR(10) END
FROM 
	##DYNAMIC_CHECKS
WHERE
	FullObjectName = @TableName;

IF ISNULL(@Sql_CConstraints, '') <> ''
BEGIN;
	SET @Sql_CConstraints = @Sql + @Sql_CConstraints;
	EXEC (@Sql_CConstraints);
END;
END;--CREATE CHECK CONSTRAINTS

SET @Cursor += 1;
END;

SET @Cursor = 1;

WHILE @Cursor <= (SELECT COUNT(1) FROM ##DYNAMIC_OBJECTS)
BEGIN;
BEGIN;--GET CURRENT TABLE NAME
SELECT 
	@TableName = name 
FROM 
	##DYNAMIC_OBJECTS
WHERE
	id = @Cursor;
END;--GET CURRENT TABLE NAME

BEGIN;--CREATE FOREIGN KEYS
SELECT @Sql_FKConstraints = (
SELECT
	'USE ' + @tarDatabase + ';' + CHAR(10) + CHAR(10) + 
	LEFT(txt, LEN(txt) - 1)  + CHAR(10)
FROM
	(
		SELECT
			ForeignKey + ''
		FROM 
			##DYNAMIC_FOREIGNKEYS
		WHERE
			FullObjectName = @TableName
		FOR XML 
			PATH('')
	) t(txt));
IF ISNULL(@Sql_FKConstraints, '') <> ''
	EXEC (@Sql_FKConstraints);
END;--CREATE FOREIGN KEYS

BEGIN;--CREATE INDEXES

SET @Sql = '
IF OBJECT_ID(''TEMPDB..##DYNAMIC_INDEXNAMES'') IS NOT NULL
	DROP TABLE ##DYNAMIC_INDEXNAMES;';
EXEC (@Sql);
SET @Sql = '
USE ' + @srcDatabase + ';' + CHAR(10) + '
CREATE TABLE ##DYNAMIC_INDEXNAMES
(
	Id					INT IDENTITY(1,1),
	ColumnName			SYSNAME,
	IndexName			SYSNAME,
	IndexType			SYSNAME,
	IndexColumnOrdinal	INT,
	IndexIsDescending	INT
);';
EXEC (@Sql);

INSERT INTO ##DYNAMIC_INDEXNAMES
SELECT
	ColumnName,
	IndexName,
	IndexType,
	IndexColumnOrdinal,
	IndexIsDescending
FROM 
	##DYNAMIC_INDEXES
WHERE
	FullObjectName = @TableName;

SET @Cursor2 = 1;

WHILE @Cursor2 <= (SELECT COUNT(1) FROM ##DYNAMIC_INDEXNAMES)
BEGIN;
SELECT
	@IndexName			= IndexName,
	@IndexType			= IndexType
FROM 
	##DYNAMIC_INDEXNAMES
WHERE
	Id = @Cursor2;

SELECT @Sql_Indexes = (
SELECT
	'USE ' + @tarDatabase + ';' + CHAR(10) + CHAR(10) + 
	'CREATE ' + @IndexType + ' INDEX [' + @IndexName + '] ON ' + @TableName + '' + CHAR(10) + 
	'(' + CHAR(10) + 
LEFT(txt, LEN(txt) - 2)  + CHAR(10)
FROM
	(
		SELECT
			ColumnName + CASE WHEN IndexIsDescending = 0 THEN ' ASC' ELSE ' DESC' END + ',' + CHAR(10)
		FROM 
			##DYNAMIC_INDEXNAMES
		WHERE
			IndexName = @IndexName
		AND	IndexType = @IndexType
		ORDER BY
			IndexColumnOrdinal
		FOR XML 
			PATH('')
	) t(txt));

IF ISNULL(@Sql_Indexes, '') <> ''
BEGIN;
	SET @Sql_Indexes += 
	')WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY];'
	 + CHAR(10);
	EXEC (@Sql_Indexes);
END;
SET @Cursor2 += 1;
END;

END;--CREATE INDEXES

SET @Cursor += 1;
END;

END;--CREATE TABLE OBJECTS

SET @Sql = '
IF OBJECT_ID(''TEMPDB..##DYNAMIC_MODULES'') IS NOT NULL
	DROP TABLE ##DYNAMIC_MODULES;';
EXEC (@Sql);
SET @Sql = '
USE ' + @srcDatabase + ';' + CHAR(10) + '
CREATE TABLE ##DYNAMIC_MODULES
(
	[Id]				INT IDENTITY(1,1),
	[definition]		VARCHAR(MAX)
);'
EXEC (@Sql);

SET @Sql = '
USE ' + @srcDatabase + ';' + CHAR(10) + '
INSERT INTO ##DYNAMIC_MODULES
SELECT
	LTRIM(RTRIM([definition]))
FROM
	sys.sql_modules;';
EXEC (@Sql);

SET @Cursor = 1;

WHILE @Cursor <= (SELECT COUNT(1) FROM ##DYNAMIC_MODULES)
BEGIN;

SELECT
	@Sql_Modules = 
	'USE ' + @tarDatabase + ';' + CHAR(10) + 
	'DECLARE @SQL VARCHAR(MAX);' + CHAR(10) + 
	'SET @SQL = ''' + 
	REPLACE([definition],'''', '''''') + '''' + ';
	EXEC (@SQL);'
FROM
	##DYNAMIC_MODULES
WHERE
	Id = @Cursor;

EXEC (@Sql_Modules);

SET @Cursor += 1;
END;

BEGIN;--DELETE TEMP OBJECTS
SET @Sql = '
IF OBJECT_ID(''TEMPDB..##DYNAMIC_OBJECTS'') IS NOT NULL
	DROP TABLE ##DYNAMIC_OBJECTS;';
EXEC (@Sql);
SET @Sql = '
IF OBJECT_ID(''TEMPDB..##DYNAMIC_COLUMNS'') IS NOT NULL
	DROP TABLE ##DYNAMIC_COLUMNS;';
EXEC (@Sql);
SET @Sql = '
IF OBJECT_ID(''TEMPDB..##DYNAMIC_PRIMARYKEYS'') IS NOT NULL
	DROP TABLE ##DYNAMIC_PRIMARYKEYS;';
EXEC (@Sql);
SET @Sql = '
IF OBJECT_ID(''TEMPDB..##DYNAMIC_DEFAULTS'') IS NOT NULL
	DROP TABLE ##DYNAMIC_DEFAULTS;';
EXEC (@Sql);
SET @Sql = '
IF OBJECT_ID(''TEMPDB..##DYNAMIC_CHECKS'') IS NOT NULL
	DROP TABLE ##DYNAMIC_CHECKS;';
EXEC (@Sql);
SET @Sql = '
IF OBJECT_ID(''TEMPDB..##DYNAMIC_INDEXES'') IS NOT NULL
	DROP TABLE ##DYNAMIC_INDEXES;';
EXEC (@Sql);
SET @Sql = '
IF OBJECT_ID(''TEMPDB..##DYNAMIC_INDEXNAMES'') IS NOT NULL
	DROP TABLE ##DYNAMIC_INDEXNAMES;';
EXEC (@Sql);
SET @Sql = '
IF OBJECT_ID(''TEMPDB..##DYNAMIC_FOREIGNKEYS'') IS NOT NULL
	DROP TABLE ##DYNAMIC_FOREIGNKEYS;';
EXEC (@Sql);
SET @Sql = '
IF OBJECT_ID(''TEMPDB..##DYNAMIC_MODULES'') IS NOT NULL
	DROP TABLE ##DYNAMIC_MODULES;';
EXEC (@Sql);
IF OBJECT_ID('dbo.dynamic_GetLiteralDataType') IS NOT NULL
	DROP FUNCTION dbo.dynamic_GetLiteralDataType;
END;--DELETE TEMP OBJECTS

SET NOCOUNT OFF;

GO