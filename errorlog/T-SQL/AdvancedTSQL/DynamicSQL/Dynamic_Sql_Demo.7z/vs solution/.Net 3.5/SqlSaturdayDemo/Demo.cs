﻿using System;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;

namespace SqlSaturdayDemo
{
    public partial class Demo : Form
    {
        BackgroundWorker worker;
        bool complete;
        string srv;
        string srcdb;
        string tardb;
        bool over;
        bool exeFullImport;
        bool exeTableImport;
        bool exeTablePKImport;
        bool exeTableDFImport;
        bool exeTableCKImport;
        bool exeTableFKImport;
        bool exeTableIXImport;
        bool exeViewImport;
        bool exeFunctionImport;
        bool exeProcedureImport;
        bool exeTriggerImport;
        int tips = 1;
        bool showing = false;

        public Demo()
        {
            InitializeComponent();
        }

        private void on_Load(object sender, EventArgs e)
        {
            this.timer1.Start();
            this.Refresh();
        }

        private void txtSrc_TextChanged(object sender, EventArgs e)
        {
            this.Refresh();
        }

        private void txtTar_TextChanged(object sender, EventArgs e)
        {
            this.Refresh();
        }

        private void btnExecute_Click(object sender, EventArgs e)
        {
            if (this.worker == null)
                this.doTheWork();
        }

        private void doTheWork()
        {
            this.srv = this.txtSrv.Text;
            this.srcdb = this.txtSrc.Text;
            this.tardb = this.txtTar.Text;
            this.over = this.overwrite.Checked;
            this.exeFullImport = this.full.Checked;
            this.exeFunctionImport = this.functions.Checked;
            this.exeProcedureImport = this.procedures.Checked;
            this.exeTableCKImport = this.checks.Checked;
            this.exeTableDFImport = this.defaults.Checked;
            this.exeTableFKImport = this.foreign.Checked;
            this.exeTableImport = this.tables.Checked;
            this.exeTableIXImport = this.indexes.Checked;
            this.exeTablePKImport = this.primary.Checked;
            this.exeTriggerImport = this.triggers.Checked;
            this.exeViewImport = this.views.Checked;
            this.complete = false;
            this.worker = new BackgroundWorker();
            this.worker.DoWork += worker_DoWork;
            this.worker.RunWorkerCompleted += worker_RunWorkerCompleted;
            this.grpRequests.Text = "Executing ...";
            this.grpRequests.ForeColor = Color.Blue;
            this.treeSrc.Nodes.Clear();
            this.treeTar.Nodes.Clear();
            this.worker.RunWorkerAsync();
        }

        private void worker_DoWork(object sender, DoWorkEventArgs e)
        {
            e.Result = this.work();
        }

        private object work()
        {
            string cmdText = "dbo.dynamic_InsertRequest";
            SqlParameter prm = null;
            SqlCommand cmd = null;
            try
            {
                string conStr = string.Format("data source={0};initial catalog ={1};integrated security = true",
                    this.srv, "master");
                using (SqlConnection con = new SqlConnection(conStr))
                {
                    con.Open();
                    cmd = new SqlCommand(cmdText, con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    prm = new SqlParameter(@"srcDatabase", srcdb); cmd.Parameters.Add(prm);
                    prm = new SqlParameter(@"tarDatabase", tardb); cmd.Parameters.Add(prm);
                    prm = new SqlParameter(@"dropExisting", this.over ? 1 : 0); cmd.Parameters.Add(prm);
                    prm = new SqlParameter(@"exeFullImport", this.exeFullImport ? 1 : 0); cmd.Parameters.Add(prm);
                    prm = new SqlParameter(@"exeTableImport", this.exeTableImport ? 1 : 0); cmd.Parameters.Add(prm);
                    prm = new SqlParameter(@"exeTablePKImport", this.exeTablePKImport ? 1 : 0); cmd.Parameters.Add(prm);
                    prm = new SqlParameter(@"exeTableDFImport", this.exeTableDFImport ? 1 : 0); cmd.Parameters.Add(prm);
                    prm = new SqlParameter(@"exeTableCKImport", this.exeTableCKImport ? 1 : 0); cmd.Parameters.Add(prm);
                    prm = new SqlParameter(@"exeTableFKImport", this.exeTableFKImport ? 1 : 0); cmd.Parameters.Add(prm);
                    prm = new SqlParameter(@"exeTableIXImport", this.exeTableIXImport ? 1 : 0); cmd.Parameters.Add(prm);
                    prm = new SqlParameter(@"exeViewImport", this.exeViewImport ? 1 : 0); cmd.Parameters.Add(prm);
                    prm = new SqlParameter(@"exeFunctionImport", this.exeFunctionImport ? 1 : 0); cmd.Parameters.Add(prm);
                    prm = new SqlParameter(@"exeProcedureImport", this.exeProcedureImport ? 1 : 0); cmd.Parameters.Add(prm);
                    prm = new SqlParameter(@"exeTriggerImport", this.exeTriggerImport ? 1 : 0); cmd.Parameters.Add(prm);
                    cmd.ExecuteNonQuery();
                }
            }
            catch { return false; }
            return true;
        }

        private void worker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (!this.complete)
            {
                this.complete = true;
                this.worker.Dispose();
                this.worker = null;
                this.grpRequests.Text = (bool)e.Result ? "Requests" : "Failed";
                this.grpRequests.ForeColor = (bool)e.Result ? Color.Black : Color.Red;
                this.Refresh();
            }
        }

        public override void Refresh()
        {
            DataSet src = this.getDataSet(this.txtSrc.Text);
            this.buildTree(this.treeSrc, src);
            DataSet tar = this.getDataSet(this.txtTar.Text);
            this.buildTree(this.treeTar, tar);
        }

        private void buildTree(TreeView treeView, DataSet ds)
        {
            treeView.Nodes.Clear();
            if (ds != null)
            {
                DataTable tables = ds.Tables["tables"];
                DataTable views = ds.Tables["views"];
                DataTable procedures = ds.Tables["procedures"];
                DataTable sfunctions = ds.Tables["sfunctions"];
                DataTable tfunctions = ds.Tables["tfunctions"];
                DataTable columns = ds.Tables["columns"];
                DataTable vcolumns = ds.Tables["vcolumns"];
                DataTable defaults = ds.Tables["defaults"];
                DataTable checks = ds.Tables["checks"];
                DataTable foreign = ds.Tables["foreign"];
                DataTable primary = ds.Tables["primary"];
                DataTable index = ds.Tables["index"];
                DataTable triggers = ds.Tables["triggers"];

                #region tables
                if (tables != null)
                {
                    TreeNode node = treeView.Nodes["Tables"];
                    if (node == null)
                    {
                        node = new TreeNode("Tables");
                        node.Name = node.Text;
                        treeView.Nodes.Add(node);
                        node.Tag = node.FullPath;
                    }

                    foreach (DataRow row in tables.Rows)
                    {
                        TreeNode tnode = node.Nodes[row[0].ToString()];
                        if (tnode == null)
                        {
                            tnode = new TreeNode(row[0].ToString());
                            tnode.Name = tnode.Text;
                            node.Nodes.Add(tnode);
                            tnode.Tag = tnode.FullPath;
                        }
                    }
                    node.Expand();
                }
                #endregion tables

                #region views
                if (views != null)
                {
                    TreeNode node = treeView.Nodes["Views"];
                    if (node == null)
                    {
                        node = new TreeNode("Views");
                        node.Name = node.Text;
                        treeView.Nodes.Add(node);
                        node.Tag = node.FullPath;
                    }

                    foreach (DataRow row in views.Rows)
                    {
                        TreeNode tnode = node.Nodes[row[0].ToString()];
                        if (tnode == null)
                        {
                            tnode = new TreeNode(row[0].ToString());
                            tnode.Name = tnode.Text;
                            node.Nodes.Add(tnode);
                            tnode.Tag = tnode.FullPath;
                        }
                    }
                    node.Expand();
                }
                #endregion tables

                #region procedures
                if (procedures != null)
                {
                    TreeNode node = treeView.Nodes["Procedures"];
                    if (node == null)
                    {
                        node = new TreeNode("Procedures");
                        node.Name = node.Text;
                        treeView.Nodes.Add(node);
                        node.Tag = node.FullPath;
                    }

                    foreach (DataRow row in procedures.Rows)
                    {
                        TreeNode tnode = node.Nodes[row[0].ToString()];
                        if (tnode == null)
                        {
                            tnode = new TreeNode(row[0].ToString());
                            tnode.Name = tnode.Text;
                            node.Nodes.Add(tnode);
                            tnode.Tag = tnode.FullPath;
                        }
                    }
                    node.Expand();
                }
                #endregion procedures

                #region sfunctions
                if (sfunctions != null)
                {
                    TreeNode node = treeView.Nodes["Scalar Functions"];
                    if (node == null)
                    {
                        node = new TreeNode("Scalar Functions");
                        node.Name = node.Text;
                        treeView.Nodes.Add(node);
                        node.Tag = node.FullPath;
                    }

                    foreach (DataRow row in sfunctions.Rows)
                    {
                        TreeNode tnode = node.Nodes[row[0].ToString()];
                        if (tnode == null)
                        {
                            tnode = new TreeNode(row[0].ToString());
                            tnode.Name = tnode.Text;
                            node.Nodes.Add(tnode);
                            tnode.Tag = tnode.FullPath;
                        }
                    }
                    node.Expand();
                }
                #endregion sfunctions

                #region tfunctions
                if (tfunctions != null)
                {
                    TreeNode node = treeView.Nodes["Table Functions"];
                    if (node == null)
                    {
                        node = new TreeNode("Table Functions");
                        node.Name = node.Text;
                        treeView.Nodes.Add(node);
                        node.Tag = node.FullPath;
                    }
                    foreach (DataRow row in tfunctions.Rows)
                    {
                        TreeNode tnode = node.Nodes[row[0].ToString()];
                        if (tnode == null)
                        {
                            tnode = new TreeNode(row[0].ToString());
                            tnode.Name = tnode.Text;
                            node.Nodes.Add(tnode);
                            tnode.Tag = tnode.FullPath;
                        }
                    }
                    node.Expand();
                }
                #endregion tfunctions

                #region columns
                if (columns != null)
                {
                    TreeNode node = treeView.Nodes["Tables"];
                    if (node == null)
                    {
                        node = new TreeNode("Tables");
                        node.Name = node.Text;
                        treeView.Nodes.Add(node);
                        node.Tag = node.FullPath;
                    }
                    foreach (DataRow row in columns.Rows)
                    {
                        TreeNode tnode = node.Nodes[row[0].ToString()];
                        if (tnode == null)
                        {
                            tnode = new TreeNode(row[0].ToString());
                            tnode.Name = tnode.Text;
                            node.Nodes.Add(tnode);
                            tnode.Tag = tnode.FullPath;
                        }
                        TreeNode ccnode = tnode.Nodes["Columns"];
                        if (ccnode == null)
                        {
                            ccnode = new TreeNode("Columns");
                            ccnode.Name = ccnode.Text;
                            tnode.Nodes.Add(ccnode);
                            ccnode.Tag = ccnode.FullPath;
                        }
                        TreeNode cnode = ccnode.Nodes[row[1].ToString()];
                        if (cnode == null)
                        {
                            cnode = new TreeNode(row[1].ToString());
                            cnode.Name = cnode.Text;
                            ccnode.Nodes.Add(cnode);
                            cnode.Tag = cnode.FullPath;

                            #region primary keys
                            if (primary != null)
                            {
                                foreach (DataRow rw in primary.Rows)
                                {
                                    if (rw[0].ToString().ToLower() == row[0].ToString().ToLower())
                                    {
                                        if (rw[1].ToString().ToLower() == row[1].ToString().ToLower())
                                        {
                                            cnode.Text = cnode.Text + " [" + rw[2].ToString() + "]";
                                        }
                                    }
                                }
                            }
                            #endregion primary keys

                            #region defaults
                            if (defaults != null)
                            {
                                foreach (DataRow rw in defaults.Rows)
                                {
                                    if (rw[0].ToString().ToLower() == row[0].ToString().ToLower())
                                    {
                                        if (rw[1].ToString().ToLower() == row[1].ToString().ToLower())
                                        {
                                            cnode.Text += " [" + rw[2].ToString() + "]";
                                        }
                                    }
                                }
                            }
                            #endregion defaults

                            #region checks
                            if (checks != null)
                            {
                                foreach (DataRow rw in checks.Rows)
                                {
                                    if (rw[0].ToString().ToLower() == row[0].ToString().ToLower())
                                    {
                                        if (rw[1].ToString().ToLower() == row[1].ToString().ToLower())
                                        {
                                            cnode.Text += " [" + rw[2].ToString() + "]";
                                        }
                                    }
                                }
                            }
                            #endregion checks

                            #region foreign
                            if (foreign != null)
                            {
                                foreach (DataRow rw in foreign.Rows)
                                {
                                    if (rw[0].ToString().ToLower() == row[0].ToString().ToLower())
                                    {
                                        if (rw[1].ToString().ToLower() == row[1].ToString().ToLower())
                                        {
                                            cnode.Text = cnode.Text + " [" + rw[2].ToString() + "]";
                                        }
                                    }
                                }
                            }
                            #endregion foreign
                        }
                    }
                    node.Expand();
                }
                #endregion columns

                #region indexes
                if (index != null)
                {
                    TreeNode node = treeView.Nodes["Tables"];
                    if (node == null)
                    {
                        node = new TreeNode("Tables");
                        node.Name = node.Text;
                        treeView.Nodes.Add(node);
                        node.Tag = node.FullPath;
                    }
                    foreach (DataRow row in index.Rows)
                    {
                        TreeNode tnode = node.Nodes[row[0].ToString()];
                        if (tnode == null)
                        {
                            tnode = new TreeNode(row[0].ToString());
                            tnode.Name = tnode.Text;
                            node.Nodes.Add(tnode);
                            tnode.Tag = tnode.FullPath;
                        }
                        TreeNode ccnode = tnode.Nodes["Indexes"];
                        if (ccnode == null)
                        {
                            ccnode = new TreeNode("Indexes");
                            ccnode.Name = ccnode.Text;
                            tnode.Nodes.Add(ccnode);
                            ccnode.Tag = ccnode.FullPath;
                        }
                        TreeNode cnode = ccnode.Nodes[row[1].ToString()];
                        if (cnode == null)
                        {
                            cnode = new TreeNode(row[1].ToString());
                            cnode.Name = cnode.Text;
                            ccnode.Nodes.Add(cnode);
                            cnode.Tag = cnode.FullPath;
                        }
                    }
                    node.Expand();
                }
                #endregion columns

                #region triggers
                if (triggers != null)
                {
                    TreeNode node = treeView.Nodes["Tables"];
                    if (node == null)
                    {
                        node = new TreeNode("Tables");
                        node.Name = node.Text;
                        treeView.Nodes.Add(node);
                        node.Tag = node.FullPath;
                    }
                    foreach (DataRow row in triggers.Rows)
                    {
                        TreeNode tnode = node.Nodes[row[0].ToString()];
                        if (tnode == null)
                        {
                            tnode = new TreeNode(row[0].ToString());
                            tnode.Name = tnode.Text;
                            node.Nodes.Add(tnode);
                            tnode.Tag = tnode.FullPath;
                        }
                        TreeNode ccnode = tnode.Nodes["Triggers"];
                        if (ccnode == null)
                        {
                            ccnode = new TreeNode("Triggers");
                            ccnode.Name = ccnode.Text;
                            tnode.Nodes.Add(ccnode);
                            ccnode.Tag = ccnode.FullPath;
                        }
                        TreeNode cnode = ccnode.Nodes[row[1].ToString()];
                        if (cnode == null)
                        {
                            cnode = new TreeNode(row[1].ToString());
                            cnode.Name = cnode.Text;
                            ccnode.Nodes.Add(cnode);
                            cnode.Tag = cnode.FullPath;
                        }
                    }
                    node.Expand();
                }
                #endregion columns

                #region vcolumns
                if (vcolumns != null)
                {
                    TreeNode node = treeView.Nodes["Views"];
                    if (node == null)
                    {
                        node = new TreeNode("Views");
                        node.Name = node.Text;
                        treeView.Nodes.Add(node);
                        node.Tag = node.FullPath;
                    }
                    foreach (DataRow row in vcolumns.Rows)
                    {
                        TreeNode vnode = node.Nodes[row[0].ToString()];
                        if (vnode == null)
                        {
                            vnode = new TreeNode(row[0].ToString());
                            vnode.Name = vnode.Text;
                            node.Nodes.Add(vnode);
                            vnode.Tag = vnode.FullPath;
                        }
                        TreeNode cnode = vnode.Nodes[row[1].ToString()];
                        if (cnode == null)
                        {
                            cnode = new TreeNode(row[1].ToString());
                            cnode.Name = cnode.Text;
                            vnode.Nodes.Add(cnode);
                            cnode.Tag = cnode.FullPath;
                        }
                    }
                    node.Expand();
                }
                #endregion vcolumns
            }
            if (treeView.Nodes.Count > 0)
                treeView.SelectedNode = treeView.Nodes[0];
        }

        private DataSet getDataSet(string database)
        {
            DataSet ds = new DataSet(); 
            SqlDataAdapter adp = null;
            DataTable table = null;
            try
            {
                string conStr = string.Format("data source={0};initial catalog ={1};integrated security = true",
                    this.txtSrv.Text, database);
                using (SqlConnection con = new SqlConnection(conStr))
                {
                    con.Open();
                    table = new DataTable("tables");
                    adp = new SqlDataAdapter("select object_schema_name(object_id) + '.' + name from sys.tables", con);
                    adp.Fill(table);
                    ds.Tables.Add(table);

                    table = new DataTable("views");
                    adp = new SqlDataAdapter("select object_schema_name(object_id) + '.' + name from sys.views", con);
                    adp.Fill(table);
                    ds.Tables.Add(table);

                    table = new DataTable("procedures");
                    adp = new SqlDataAdapter("select object_schema_name(object_id) + '.' + name from sys.procedures", con);
                    adp.Fill(table);
                    ds.Tables.Add(table);

                    table = new DataTable("sfunctions");
                    adp = new SqlDataAdapter("select object_schema_name(object_id) + '.' + name from sys.objects where type in ('fn')", con);
                    adp.Fill(table);
                    ds.Tables.Add(table);

                    table = new DataTable("tfunctions");
                    adp = new SqlDataAdapter("select object_schema_name(object_id) + '.' + name from sys.objects where type in ('tf')", con);
                    adp.Fill(table);
                    ds.Tables.Add(table);

                    table = new DataTable("columns");
                    adp = new SqlDataAdapter("select object_schema_name(t.object_id) + '.' + t.name tablename, c.name  from sys.tables t inner join sys.columns c on t.object_id = c.object_id ", con);
                    adp.Fill(table);
                    ds.Tables.Add(table);

                    table = new DataTable("vcolumns");
                    adp = new SqlDataAdapter("select object_schema_name(t.object_id) + '.' + t.name tablename, c.name  from sys.views t inner join sys.columns c on t.object_id = c.object_id ", con);
                    adp.Fill(table);
                    ds.Tables.Add(table);

                    table = new DataTable("defaults");
                    adp = new SqlDataAdapter("select object_schema_name(d.parent_object_id) + '.' + object_name(d.parent_object_id) tablename, c.name columnname, d.name from sys.default_constraints d inner join sys.columns c on c.object_id = d.parent_object_id and c.column_id = d.parent_column_id", con);
                    adp.Fill(table);
                    ds.Tables.Add(table);

                    table = new DataTable("checks");
                    adp = new SqlDataAdapter("select object_schema_name(parent_object_id) + '.' + object_name(parent_object_id) tablename, c.name columnname, f.name from sys.check_constraints f inner join sys.columns c on c.object_id = f.parent_object_id and c.column_id = f.parent_column_id ", con);
                    adp.Fill(table);
                    ds.Tables.Add(table);

                    table = new DataTable("foreign");
                    adp = new SqlDataAdapter("select object_schema_name(parent_object_id) + '.' + object_name(parent_object_id) tablename, c.name columnname, OBJECT_NAME(constraint_object_id) name from sys.foreign_key_columns f inner join sys.columns c on c.object_id = f.parent_object_id and c.column_id = f.parent_column_id", con);
                    adp.Fill(table);
                    ds.Tables.Add(table);

                    table = new DataTable("primary");
                    adp = new SqlDataAdapter("select object_schema_name(i.object_id) + '.' + object_name(i.object_id) indexname,_c.name columnname, i.name from sys.indexes i inner join sys.tables t on i.object_id = t.object_id inner join sys.index_columns c on c.object_id = i.object_id and i.index_id = c.index_id inner join sys.columns _c on _c.object_id = c.object_id and _c.column_id = c.column_id where is_primary_key = 1", con);
                    adp.Fill(table);
                    ds.Tables.Add(table);

                    table = new DataTable("index");
                    adp = new SqlDataAdapter("select object_schema_name(i.object_id) + '.' + object_name(i.object_id) indexname, i.name from sys.indexes i inner join sys.tables t on i.object_id = t.object_id where is_primary_key = 0", con);
                    adp.Fill(table);
                    ds.Tables.Add(table);

                    table = new DataTable("triggers");
                    adp = new SqlDataAdapter("select object_schema_name(parent_id) + '.' + object_name(parent_id) tablename, name from sys.triggers ", con);
                    adp.Fill(table);
                    ds.Tables.Add(table);
                }
                return ds;
            }
            catch
            {
                return null;
            }
        }

        private void toolStripStatusLabel1_Click(object sender, EventArgs e)
        {
            string url = "www.iqbusiness.co.za";
            Process.Start(url);
        }

        private void toolStripStatusLabel4_Click(object sender, EventArgs e)
        {
            string url = "https://za.linkedin.com/pub/trevor-makoni/46/288/859";
            Process.Start(url);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (showing) return;
            showing = true;
            string msg = "";
            if (tips == 1)
                msg = "Our Team. Your Advantage";
            if (tips == 2)
                msg = "Please follow the provided links to:\n\nOur company website\nTrevor's LinkedIn profile";
            if (tips == 3)
                msg = "WE HELP BUSINESSES GROW\n\nOur team helps businesses grow by solving problems and finding new and better ways of doing things.";
            if (tips == 4)
                msg = "Please call us on +27 11 259 4000";
            tips += 1;
            if (tips > 4)
                tips = 1;
            this.notifyIcon1.BalloonTipText = msg;
            notifyIcon1.Visible = true;
            this.notifyIcon1.ShowBalloonTip(10000);
        }

        private void notifyIcon1_BalloonTipClosed(object sender, EventArgs e)
        {
            showing = false;
        }
    }
}