﻿namespace SqlSaturdayDemo
{
    partial class Demo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.grpRequests = new System.Windows.Forms.GroupBox();
            this.indexes = new System.Windows.Forms.CheckBox();
            this.btnExecute = new System.Windows.Forms.Button();
            this.triggers = new System.Windows.Forms.CheckBox();
            this.foreign = new System.Windows.Forms.CheckBox();
            this.tables = new System.Windows.Forms.CheckBox();
            this.views = new System.Windows.Forms.CheckBox();
            this.checks = new System.Windows.Forms.CheckBox();
            this.defaults = new System.Windows.Forms.CheckBox();
            this.functions = new System.Windows.Forms.CheckBox();
            this.procedures = new System.Windows.Forms.CheckBox();
            this.primary = new System.Windows.Forms.CheckBox();
            this.full = new System.Windows.Forms.CheckBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtSrv = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtSrc = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.treeSrc = new System.Windows.Forms.TreeView();
            this.grpTar = new System.Windows.Forms.GroupBox();
            this.overwrite = new System.Windows.Forms.CheckBox();
            this.txtTar = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.treeTar = new System.Windows.Forms.TreeView();
            this.statusStrip = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel3 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel4 = new System.Windows.Forms.ToolStripStatusLabel();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.notifyIcon1 = new System.Windows.Forms.NotifyIcon(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.grpRequests.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.grpTar.SuspendLayout();
            this.statusStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer1.IsSplitterFixed = true;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.grpRequests);
            this.splitContainer1.Panel1.Controls.Add(this.groupBox2);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.splitContainer2);
            this.splitContainer1.Size = new System.Drawing.Size(1031, 379);
            this.splitContainer1.SplitterDistance = 90;
            this.splitContainer1.TabIndex = 0;
            // 
            // grpRequests
            // 
            this.grpRequests.Controls.Add(this.indexes);
            this.grpRequests.Controls.Add(this.triggers);
            this.grpRequests.Controls.Add(this.foreign);
            this.grpRequests.Controls.Add(this.tables);
            this.grpRequests.Controls.Add(this.views);
            this.grpRequests.Controls.Add(this.checks);
            this.grpRequests.Controls.Add(this.defaults);
            this.grpRequests.Controls.Add(this.functions);
            this.grpRequests.Controls.Add(this.procedures);
            this.grpRequests.Controls.Add(this.primary);
            this.grpRequests.Controls.Add(this.full);
            this.grpRequests.Location = new System.Drawing.Point(258, 3);
            this.grpRequests.Name = "grpRequests";
            this.grpRequests.Size = new System.Drawing.Size(364, 84);
            this.grpRequests.TabIndex = 2;
            this.grpRequests.TabStop = false;
            this.grpRequests.Text = "Requests";
            // 
            // indexes
            // 
            this.indexes.AutoSize = true;
            this.indexes.Location = new System.Drawing.Point(263, 39);
            this.indexes.Name = "indexes";
            this.indexes.Size = new System.Drawing.Size(63, 17);
            this.indexes.TabIndex = 10;
            this.indexes.Text = "Indexes";
            this.indexes.UseVisualStyleBackColor = true;
            // 
            // btnExecute
            // 
            this.btnExecute.Location = new System.Drawing.Point(331, 11);
            this.btnExecute.Name = "btnExecute";
            this.btnExecute.Size = new System.Drawing.Size(93, 23);
            this.btnExecute.TabIndex = 1;
            this.btnExecute.Text = "Copy Database";
            this.btnExecute.UseVisualStyleBackColor = true;
            this.btnExecute.Click += new System.EventHandler(this.btnExecute_Click);
            // 
            // triggers
            // 
            this.triggers.AutoSize = true;
            this.triggers.Location = new System.Drawing.Point(96, 62);
            this.triggers.Name = "triggers";
            this.triggers.Size = new System.Drawing.Size(64, 17);
            this.triggers.TabIndex = 5;
            this.triggers.Text = "Triggers";
            this.triggers.UseVisualStyleBackColor = true;
            // 
            // foreign
            // 
            this.foreign.AutoSize = true;
            this.foreign.Location = new System.Drawing.Point(263, 16);
            this.foreign.Name = "foreign";
            this.foreign.Size = new System.Drawing.Size(87, 17);
            this.foreign.TabIndex = 9;
            this.foreign.Text = "Foreign Keys";
            this.foreign.UseVisualStyleBackColor = true;
            // 
            // tables
            // 
            this.tables.AutoSize = true;
            this.tables.Location = new System.Drawing.Point(6, 39);
            this.tables.Name = "tables";
            this.tables.Size = new System.Drawing.Size(58, 17);
            this.tables.TabIndex = 1;
            this.tables.Text = "Tables";
            this.tables.UseVisualStyleBackColor = true;
            // 
            // views
            // 
            this.views.AutoSize = true;
            this.views.Location = new System.Drawing.Point(6, 62);
            this.views.Name = "views";
            this.views.Size = new System.Drawing.Size(54, 17);
            this.views.TabIndex = 2;
            this.views.Text = "Views";
            this.views.UseVisualStyleBackColor = true;
            // 
            // checks
            // 
            this.checks.AutoSize = true;
            this.checks.Location = new System.Drawing.Point(173, 39);
            this.checks.Name = "checks";
            this.checks.Size = new System.Drawing.Size(62, 17);
            this.checks.TabIndex = 7;
            this.checks.Text = "Checks";
            this.checks.UseVisualStyleBackColor = true;
            // 
            // defaults
            // 
            this.defaults.AutoSize = true;
            this.defaults.Location = new System.Drawing.Point(173, 16);
            this.defaults.Name = "defaults";
            this.defaults.Size = new System.Drawing.Size(65, 17);
            this.defaults.TabIndex = 6;
            this.defaults.Text = "Defaults";
            this.defaults.UseVisualStyleBackColor = true;
            // 
            // functions
            // 
            this.functions.AutoSize = true;
            this.functions.Location = new System.Drawing.Point(96, 39);
            this.functions.Name = "functions";
            this.functions.Size = new System.Drawing.Size(72, 17);
            this.functions.TabIndex = 4;
            this.functions.Text = "Functions";
            this.functions.UseVisualStyleBackColor = true;
            // 
            // procedures
            // 
            this.procedures.AutoSize = true;
            this.procedures.Location = new System.Drawing.Point(96, 16);
            this.procedures.Name = "procedures";
            this.procedures.Size = new System.Drawing.Size(80, 17);
            this.procedures.TabIndex = 3;
            this.procedures.Text = "Procedures";
            this.procedures.UseVisualStyleBackColor = true;
            // 
            // primary
            // 
            this.primary.AutoSize = true;
            this.primary.Location = new System.Drawing.Point(173, 62);
            this.primary.Name = "primary";
            this.primary.Size = new System.Drawing.Size(86, 17);
            this.primary.TabIndex = 8;
            this.primary.Text = "Primary Keys";
            this.primary.UseVisualStyleBackColor = true;
            // 
            // full
            // 
            this.full.AutoSize = true;
            this.full.Location = new System.Drawing.Point(6, 16);
            this.full.Name = "full";
            this.full.Size = new System.Drawing.Size(74, 17);
            this.full.TabIndex = 0;
            this.full.Text = "Full Import";
            this.full.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txtSrv);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Location = new System.Drawing.Point(3, 3);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(249, 48);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Connection";
            // 
            // txtSrv
            // 
            this.txtSrv.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtSrv.Location = new System.Drawing.Point(71, 19);
            this.txtSrv.Name = "txtSrv";
            this.txtSrv.Size = new System.Drawing.Size(172, 20);
            this.txtSrv.TabIndex = 1;
            this.txtSrv.Text = "N_TMAKONI\\SQLEXPRESS";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(24, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Server:";
            // 
            // splitContainer2
            // 
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer2.Location = new System.Drawing.Point(0, 0);
            this.splitContainer2.Name = "splitContainer2";
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.groupBox1);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.grpTar);
            this.splitContainer2.Size = new System.Drawing.Size(1031, 285);
            this.splitContainer2.SplitterDistance = 507;
            this.splitContainer2.TabIndex = 0;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtSrc);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.treeSrc);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(507, 285);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Source Database";
            // 
            // txtSrc
            // 
            this.txtSrc.Location = new System.Drawing.Point(74, 19);
            this.txtSrc.Name = "txtSrc";
            this.txtSrc.Size = new System.Drawing.Size(172, 20);
            this.txtSrc.TabIndex = 5;
            this.txtSrc.Text = "Northwind";
            this.txtSrc.TextChanged += new System.EventHandler(this.txtSrc_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 22);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Database:";
            // 
            // treeSrc
            // 
            this.treeSrc.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.treeSrc.HideSelection = false;
            this.treeSrc.Location = new System.Drawing.Point(6, 45);
            this.treeSrc.Name = "treeSrc";
            this.treeSrc.Size = new System.Drawing.Size(498, 234);
            this.treeSrc.TabIndex = 0;
            // 
            // grpTar
            // 
            this.grpTar.Controls.Add(this.overwrite);
            this.grpTar.Controls.Add(this.btnExecute);
            this.grpTar.Controls.Add(this.txtTar);
            this.grpTar.Controls.Add(this.label2);
            this.grpTar.Controls.Add(this.treeTar);
            this.grpTar.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grpTar.Location = new System.Drawing.Point(0, 0);
            this.grpTar.Name = "grpTar";
            this.grpTar.Size = new System.Drawing.Size(520, 285);
            this.grpTar.TabIndex = 1;
            this.grpTar.TabStop = false;
            this.grpTar.Text = "Target Database";
            // 
            // overwrite
            // 
            this.overwrite.AutoSize = true;
            this.overwrite.Location = new System.Drawing.Point(254, 15);
            this.overwrite.Name = "overwrite";
            this.overwrite.Size = new System.Drawing.Size(71, 17);
            this.overwrite.TabIndex = 11;
            this.overwrite.Text = "Overwrite";
            this.overwrite.UseVisualStyleBackColor = true;
            // 
            // txtTar
            // 
            this.txtTar.Location = new System.Drawing.Point(76, 13);
            this.txtTar.Name = "txtTar";
            this.txtTar.Size = new System.Drawing.Size(172, 20);
            this.txtTar.TabIndex = 9;
            this.txtTar.Text = "Northwind_Copy";
            this.txtTar.TextChanged += new System.EventHandler(this.txtTar_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(14, 16);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 13);
            this.label2.TabIndex = 8;
            this.label2.Text = "Database:";
            // 
            // treeTar
            // 
            this.treeTar.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.treeTar.HideSelection = false;
            this.treeTar.Location = new System.Drawing.Point(8, 39);
            this.treeTar.Name = "treeTar";
            this.treeTar.Size = new System.Drawing.Size(504, 234);
            this.treeTar.TabIndex = 7;
            // 
            // statusStrip
            // 
            this.statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1,
            this.toolStripStatusLabel2,
            this.toolStripStatusLabel3,
            this.toolStripStatusLabel4});
            this.statusStrip.Location = new System.Drawing.Point(0, 379);
            this.statusStrip.Name = "statusStrip";
            this.statusStrip.ShowItemToolTips = true;
            this.statusStrip.Size = new System.Drawing.Size(1031, 22);
            this.statusStrip.TabIndex = 6;
            this.statusStrip.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.IsLink = true;
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(70, 17);
            this.toolStripStatusLabel1.Text = "IQ Business:";
            this.toolStripStatusLabel1.ToolTipText = "Visit our company website";
            this.toolStripStatusLabel1.Click += new System.EventHandler(this.toolStripStatusLabel1_Click);
            // 
            // toolStripStatusLabel2
            // 
            this.toolStripStatusLabel2.Name = "toolStripStatusLabel2";
            this.toolStripStatusLabel2.Size = new System.Drawing.Size(154, 17);
            this.toolStripStatusLabel2.Text = "Our Team. Your Advantage.";
            this.toolStripStatusLabel2.ToolTipText = "                  WE HELP BUSINESSES GROW\r\n\r\nOur team helps businesses grow by so" +
    "lving problems\r\n     and finding new and better ways of doing things.";
            // 
            // toolStripStatusLabel3
            // 
            this.toolStripStatusLabel3.Name = "toolStripStatusLabel3";
            this.toolStripStatusLabel3.Size = new System.Drawing.Size(90, 17);
            this.toolStripStatusLabel3.Text = "+27 11 259 4000";
            this.toolStripStatusLabel3.ToolTipText = "or, Give us a call on this number.";
            // 
            // toolStripStatusLabel4
            // 
            this.toolStripStatusLabel4.IsLink = true;
            this.toolStripStatusLabel4.Name = "toolStripStatusLabel4";
            this.toolStripStatusLabel4.Size = new System.Drawing.Size(406, 17);
            this.toolStripStatusLabel4.Spring = true;
            this.toolStripStatusLabel4.Text = "by Trevor Makoni";
            this.toolStripStatusLabel4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.toolStripStatusLabel4.ToolTipText = "View me on LinkedIn";
            this.toolStripStatusLabel4.Click += new System.EventHandler(this.toolStripStatusLabel4_Click);
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // notifyIcon1
            // 
            this.notifyIcon1.BalloonTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            this.notifyIcon1.BalloonTipTitle = "IQ Business";
            this.notifyIcon1.Text = "IQ Business";
            this.notifyIcon1.Visible = true;
            this.notifyIcon1.BalloonTipClosed += new System.EventHandler(this.notifyIcon1_BalloonTipClosed);
            // 
            // Demo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1031, 401);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.statusStrip);
            this.Name = "Demo";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Sql Saturday Demo - Dynamic Sql (Not so scary?)";
            this.Load += new System.EventHandler(this.on_Load);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.grpRequests.ResumeLayout(false);
            this.grpRequests.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.grpTar.ResumeLayout(false);
            this.grpTar.PerformLayout();
            this.statusStrip.ResumeLayout(false);
            this.statusStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TreeView treeSrc;
        private System.Windows.Forms.GroupBox grpTar;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtSrv;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnExecute;
        private System.Windows.Forms.TextBox txtSrc;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckBox full;
        private System.Windows.Forms.TextBox txtTar;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TreeView treeTar;
        private System.Windows.Forms.GroupBox grpRequests;
        private System.Windows.Forms.CheckBox indexes;
        private System.Windows.Forms.CheckBox triggers;
        private System.Windows.Forms.CheckBox foreign;
        private System.Windows.Forms.CheckBox tables;
        private System.Windows.Forms.CheckBox views;
        private System.Windows.Forms.CheckBox checks;
        private System.Windows.Forms.CheckBox defaults;
        private System.Windows.Forms.CheckBox functions;
        private System.Windows.Forms.CheckBox procedures;
        private System.Windows.Forms.CheckBox primary;
        private System.Windows.Forms.CheckBox overwrite;
        private System.Windows.Forms.StatusStrip statusStrip;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel2;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel3;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel4;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.NotifyIcon notifyIcon1;
    }
}

