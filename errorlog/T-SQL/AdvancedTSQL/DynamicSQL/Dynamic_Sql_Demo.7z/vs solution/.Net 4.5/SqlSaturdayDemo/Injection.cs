﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SqlSaturdayDemo
{
    public partial class Injection : Form
    {
        public Injection()
        {
            InitializeComponent();
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Injection_Load(object sender, EventArgs e)
        {
            string cmdText = "select definition from sys.sql_modules where object_schema_name(object_id) = 'dbo' and object_name(object_id) = 'Sql_Injection_Demo';";
            SqlCommand cmd = null;
            string conStr = string.Format("data source={0};initial catalog ={1};integrated security = true",
                    "N_TMAKONI\\SQLEXPRESS", "Northwind_Sql_Injection");
            using (SqlConnection con = new SqlConnection(conStr))
            {
                con.Open();
                cmd = new SqlCommand(cmdText, con);
                cmd.CommandType = CommandType.Text;
                object o = cmd.ExecuteScalar();
                if (o != null)
                    this.richTextBox1.Text = o.ToString();
                else this.richTextBox1.Text = string.Empty;
            }
        }

        private void Execute()
        {
            try
            {
                string cmdText = "dbo.Sql_Injection_Demo";
                SqlParameter prm = null;
                SqlCommand cmd = null;
                string conStr = string.Format("data source={0};initial catalog ={1};integrated security = true",
                        "N_TMAKONI\\SQLEXPRESS", "Northwind_Sql_Injection");
                using (SqlConnection con = new SqlConnection(conStr))
                {
                    con.Open();
                    cmd = new SqlCommand(cmdText, con);

                    cmd.CommandType = CommandType.StoredProcedure;

                    prm = new SqlParameter(@"EmployeeID", this.richTextBox2.Text); cmd.Parameters.Add(prm);
                    
                    object o = cmd.ExecuteScalar();
                    if (o != null)
                        this.richTextBox3.Text = string.Format("Success\n\n{0}", o);
                    else this.richTextBox3.Text = string.Format("Success\n\nNULL Result", o);
                }
            }
            catch (Exception ex)
            {
                this.richTextBox3.Text = string.Format("Failed\n\n{0}", ex.Message);
            }

            try
            {
                string cmdText = string.Format("exec dbo.Sql_Injection_Demo @EmployeeID = '{0}'", this.richTextBox5.Text);
                
                SqlCommand cmd = null;
                string conStr = string.Format("data source={0};initial catalog ={1};integrated security = true",
                        "N_TMAKONI\\SQLEXPRESS", "Northwind_Sql_Injection");
                using (SqlConnection con = new SqlConnection(conStr))
                {
                    con.Open();
                    cmd = new SqlCommand(cmdText, con);

                    cmd.CommandType = CommandType.Text;

                    object o = cmd.ExecuteScalar();
                    if (o != null)
                        this.richTextBox4.Text = string.Format("Success\n\n{0}", o);
                    else this.richTextBox4.Text = string.Format("Success\n\nNULL Result", o);
                }
            }
            catch (Exception ex)
            {
                this.richTextBox4.Text = string.Format("Failed\n\n{0}", ex.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Execute();
        }
    }
}
