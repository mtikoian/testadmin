USE AdventureWorks2008R2
GO

SET STATISTICS IO ON

DECLARE @SearchHeaderID INT 		

EXEC DEMO.DynamicSearch3
	@SearchHeaderID = @SearchHeaderID OUT,
	@Title  = NULL,
	@FirstName = 'DAVID',
	@LastName = NULL,
	@AddressType = NULL,
	@State = NULL, 
	@City = NULL, 
	@emailDomain = ''

SELECT
	@SearchHeaderID 
	
SELECT
	*
FROM
	DEMO.SEARCHHEADER
	
SELECT
	*
FROM
	DEMO.SearchDetail
	

			
EXEC DEMO.SimpleSearchAllParameterSupplied 'Trinity', 'Rogers', 1

EXEC DEMO.SimpleSearchNormal 'Trinity',NULL, 1

EXEC DEMO.SimpleSearchFirstNameSupplied 'Trinity', 1


EXEC DEMO.SimpleSearchDynamic2
	@Title  = NULL,
	@FirstName = 'DAVID',
	@LastName = NULL,
	@AddressType = NULL,
	@State = NULL, 
	@City = NULL, 
	@emailDomain = NULL, 
	@SORTBY = 2

	
-- NEED TO WORK ON SORT!!!

DECLARE @SearchParameter AS DEMO.SearchParameter

DELETE @SearchParameter
INSERT INTO @SearchParameter ( SearchKey, SearchValue ) VALUES ( 'FirstName', 'DAVID'), ( 'SUFFIX', '2' )
EXEC [DEMO].[SimpleSearchDynamic4] 'PERSON-Search', @SearchParameter
DELETE @SearchParameter
INSERT INTO @SearchParameter ( SearchKey, SearchValue ) VALUES ( 'FirstName', 'DAVID'), ( 'City', 'Westminster' )
EXEC [DEMO].[SimpleSearchDynamic4] 'PERSON-Search', @SearchParameter
DELETE @SearchParameter
INSERT INTO @SearchParameter ( SearchKey, SearchValue ) VALUES ( 'City', 'Westminster' )
EXEC [DEMO].[SimpleSearchDynamic4] 'PERSON-Search', @SearchParameter
/*
SELECT
	*
FROM
	@SearchParameter 
	
DECLARE @SQL AS VARCHAR(MAX) = null 
SELECT
	@SQL = ISNULL(NULLIF(@SQL,'') + ' INTERSECT ','') + QP.QueryPartText
FROM
		DEMO.QueryPart QP
	INNER JOIN
		@SearchParameter P
	ON QP.QueryPartKey = SearchKey
	
select
	@sql
	
*/	

