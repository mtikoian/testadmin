USE AdventureWorks2008R2
GO

SET STATISTICS IO ON


DECLARE @SearchParameter AS DEMO.SearchParameter

DELETE @SearchParameter
INSERT INTO @SearchParameter ( SearchKey, SearchValue ) VALUES ( 'FirstName', 'DAVID'), ( 'Sort', '2' )
EXEC [DEMO].[DynamicSearch4] 'PERSON-Search', @SearchParameter

DELETE @SearchParameter
INSERT INTO @SearchParameter ( SearchKey, SearchValue ) VALUES ( 'FirstName', 'DAVID'), ( 'City', 'Westminster' )
EXEC [DEMO].[DynamicSearch4] 'PERSON-Search', @SearchParameter

DELETE @SearchParameter
INSERT INTO @SearchParameter ( SearchKey, SearchValue ) VALUES ( 'City', 'Westminster' )
EXEC [DEMO].[DynamicSearch4] 'PERSON-Search', @SearchParameter

-- Look at meata data tables...