USE [AdventureWorks2008R2]
GO

-- USER DEMO HAS THE RIGHT TO EXECUTE THE STORED PROCEDURE

SELECT 
	*
FROM
	Person.BusinessEntity
	
EXECUTE AS USER = 'DemoUser'

SELECT 
	*
FROM
	Person.BusinessEntity
	


-- Demouser has execute permission on Demo schenma
-- No dirrect rights for base tables


-- USER CAN RUN STATIC STORED PROCEDURE

EXEC DEMO.ComplexSearch
	@Title  = NULL,
	@FirstName  = 'DAVID',
	@LastName  = NULL,
	@AddressType  = NULL,
	@State  = NULL,
	@City  = NULL,
	@emailDomain  = NULL,
	@SORTBY = 1

EXEC DEMO.DynamicSearch1
	@Title  = NULL,
	@FirstName = 'DAVID',
	@LastName = NULL,
	@SORTBY = 1

REVERT



-- FIX USING A CERTIFICATE AND CODE SIGNING

-- CREATE A CERTIFICATE


USE [AdventureWorks2008R2]
GO

CREATE CERTIFICATE CodeSigningCert
   ENCRYPTION BY PASSWORD = 'pGFD4bb925DGvbd2439587y'
   WITH SUBJECT = 'Code signing', 
   EXPIRY_DATE = '20131231';
GO

-- CREATE A USER WITHOUT A LOGIN

CREATE USER CodeSigningUser
	FROM CERTIFICATE CodeSigningCert
GO

-- GRANT USER SELECT RIGHT

GRANT SELECT ON SCHEMA::[Person] TO [CodeSigningUser]
GO

-- SIGN THE STORED PROCEDURE
-- SAME PASSWORD REQUIRED

ADD SIGNATURE TO DEMO.DynamicSearch1 
   BY CERTIFICATE CodeSigningCert
    WITH PASSWORD = 'pGFD4bb925DGvbd2439587y';
GO

-- CAN RUN PROCEDURE NOW

-- RE-RUN CODE ABOVE




-- REMOVE SIGNATURE, CERT AND USER


USE [AdventureWorks2008R2]
GO

DROP SIGNATURE 
	FROM DEMO.DynamicSearch1 
	BY CERTIFICATE [CodeSigningCert]
GO

DROP USER [CodeSigningUser]
GO


DROP CERTIFICATE [CodeSigningCert]
GO