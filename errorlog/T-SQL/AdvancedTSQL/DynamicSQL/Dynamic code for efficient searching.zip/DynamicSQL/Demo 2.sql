USE AdventureWorks2008R2
GO

SET STATISTICS IO ON


-- IMPLEMENTING EQUIVALENT QUERY USING DYNAMIC CODE

EXEC DEMO.ComplexSearch
	@Title  = NULL,
	@FirstName  = 'DAVID',
	@LastName  = NULL,
	@AddressType  = NULL,
	@State  = NULL,
	@City  = NULL,
	@emailDomain  = NULL,
	@SORTBY = 1

EXEC DEMO.DynamicSearch1
	@Title  = NULL,
	@FirstName = 'DAVID',
	@LastName = NULL,
	@SORTBY = 1
	
DECLARE @FirstName NVARCHAR(50) = 'DAVID'
SELECT     
	P.Title,     P.FirstName,     P.MiddleName,     P.LastName,     AT.Name AS AddressType,     ADR.AddressLine1,     ADR.AddressLine2,     ADR.City,     SP.StateProvinceCode    
FROM     
	Person.Person P    
INNER JOIN     
	Person.BusinessEntity BE    
ON P.BusinessEntityID = BE.BusinessEntityID    
INNER JOIN     
	Person.BusinessEntityAddress A    
ON BE.BusinessEntityID = A.BusinessEntityID    
INNER JOIN     
	Person.[Address] ADR    
ON A.AddressID = ADR.AddressID    
INNER JOIN     
	Person.AddressType AT     
ON A.AddressTypeID =  AT.AddressTypeID    
INNER JOIN     
	Person.StateProvince SP    
ON ADR.StateProvinceID = SP.StateProvinceID    
WHERE     
	P.FirstName = @FirstName  
ORDER BY ADR.City, SP.StateProvinceCode


-- ADDING SECOND PARAMETER TO SAME SEARCHES

EXEC DEMO.ComplexSearch
	@Title  = NULL,
	@FirstName  = 'DAVID',
	@LastName  = 'Bryant',
	@AddressType  = NULL,
	@State  = NULL,
	@City  = NULL,
	@emailDomain  = NULL,
	@SORTBY = 1

EXEC DEMO.DynamicSearch1
	@Title  = NULL,
	@FirstName = 'DAVID',
	@LastName = 'Bryant',
	@SORTBY = 1





-- MORE COMPLETE SET OF PARAMETERS
-- AND CHANGES TO HOW THE FILTER IS APPLIED


EXEC DEMO.DynamicSearch2
	@Title  = NULL,
	@FirstName = 'DAVID',
	@LastName = NULL,
	@AddressType = NULL,
	@State = NULL, 
	@City = NULL, 
	@emailDomain = '', 
	@SORTBY = 2


