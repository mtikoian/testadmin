USE AdventureWorks2008R2
GO

SET STATISTICS IO ON

-- SAMPLE SEARCH QUERIES 
-- A FEW PARAEMETERS
-- HARD CODED 
-- MORE PARAMETERS


-- Search with 3 parameters
-- Hardcoded query for all parameters

EXEC DEMO.SimpleSearchNormal 'Trinity', 'Rogers', 1


EXEC DEMO.SimpleSearchNormal 'Trinity',NULL, 1

---EXEC DEMO.SimpleSearchAllParameterSupplied 'Trinity', 'Rogers', 1


EXEC DEMO.SimpleSearchNormal 'Trinity',NULL, 1

-- HARDCODE FOR SEARCH PARAMETERS
EXEC DEMO.SimpleSearchFirstNameSupplied 'Trinity', 1

-- HARDCODE FOR SEARCH AND SORT PARAMETERS 
EXEC DEMO.SimpleSearchFirstNameSuppliedSortedByCityStateProvinceCode 'Trinity'


EXEC DEMO.SimpleSearchNormal 'Trinity',NULL, 1

EXEC DEMO.SimpleSearchNormalHardCodeWrapper 'Trinity',NULL, 1






-- More parameters
EXEC DEMO.SimpleSearchNormalMoreParameters 


EXEC DEMO.ComplexSearch
	@Title  = NULL,
	@FirstName  = 'Trinity',
	@LastName  = NULL,
	@AddressType  = NULL,
	@State  = NULL,
	@City  = NULL,
	@emailDomain  = NULL,
	@SORTBY = 1
	

EXEC DEMO.ComplexSearch
	@Title  = NULL,
	@FirstName  = NULL,
	@LastName  = NULL,
	@AddressType  = NULL,
	@State  = NULL,
	@City  = 'DUBLIN',
	@emailDomain  = 'test',
	@SORTBY = 1
	
	
EXEC DEMO.SimpleSearchNormal 'Trinity',NULL, 1
EXEC DEMO.SimpleSearchNormal 'Trinity',NULL, 1



















-- DBCC FREEPROCCACHE	
