/*
Dynamic SQL

Jeremiah Peschka, Brent Ozar Unlimited
v1.0 - January 2014

(C) 2014, Brent Ozar Unlimited. 
See http://BrentOzar.com/go/eula for the End User Licensing Agreement.
*/

DBCC FREEPROCCACHE
GO


/* Step 1:
   Create a TVF that we will use for security.
   We don't join to this for two reasons:
   1) TVFs produce bizarro estimates (1 row on SQL Server <= 2012, 100 rows
      on anything newer).
   2) The business requirement is that if a customer has security restrictions
      then we join to the security table, otherwise we assume they are a
      super user and can ruin everything.
 */

IF OBJECT_ID('dbo.AllowedCustomers', 'TF') IS NULL
    EXEC('CREATE FUNCTION dbo.AllowedCustomers (@SalesPersonID INT) RETURNS TABLE AS RETURN SELECT 1 AS CustomerID;');
GO

ALTER FUNCTION dbo.AllowedCustomers(@SalesPersonID INT)
RETURNS TABLE
AS
    RETURN
    SELECT  CustomerID
    FROM    Sales.SalesOrderHeader
    WHERE   SalesPersonID = @SalesPersonID
    GROUP BY CustomerID ;

GO


SELECT SalesPersonID
FROM Sales.SalesOrderHeader









/* In this version of the procedure, we've added row level security.
   However, our security requirements state that if a user is provided, 
   we check for security. If that user has row restrictions, use them.
   Otherwise, we return all rows.

   Yes, this is a real business requirement from a real job I had.
 */
ALTER PROCEDURE bou.GetSalesData
  @SalesPersonID AS INT = NULL,
  @StartDate AS DATETIME = NULL,
  @EndDate AS DATETIME = NULL
AS
BEGIN
    SET NOCOUNT ON;

    CREATE TABLE #accounts 
    (
        CustomerID INT
    );

    INSERT INTO #accounts
    SELECT  CustomerID 
    FROM    dbo.AllowedCustomers(@SalesPersonID);

    DECLARE @sql AS NVARCHAR(MAX) = N'';

    SET @sql += N'/* bou.GetSalesData */
    SELECT  soh.SalesPersonID,
            SUM(soh.TotalDue) AS TotalSales,
            COUNT(soh.SalesOrderID) AS NumberOfSales
    FROM    Sales.SalesOrderHeader soh ';

    IF ((SELECT COUNT(*) FROM #accounts) > 0)
        SET @sql += ' JOIN #accounts a ON soh.CustomerID = a.CustomerID '

    IF @SalesPersonID IS NOT NULL 
       OR @StartDate IS NOT NULL
    BEGIN
        /* N.B. This won't work with forced parameterization */
        SET @sql += N' WHERE 1 = 1';
    END

    IF @SalesPersonID IS NOT NULL
    BEGIN
        SET @sql += N' AND soh.SalesPersonID = @sales_person_id';
    END

    IF @StartDate IS NOT NULL
    BEGIN
        SET @sql += N' AND soh.OrderDate BETWEEN @start_date AND @end_date '
    END

    SET @sql += N' GROUP BY soh.SalesPersonID ';

    PRINT @sql;

    EXEC sp_executesql @sql, 
                       N'@sales_person_id INT, @start_date DATETIME, @end_date DATETIME',
                       @SalesPersonID, @StartDate, @EndDate;
END
GO













EXEC bou.GetSalesData @StartDate = '20010601', @EndDate = '20120101' ;
EXEC bou.GetSalesData ;
EXEC bou.GetSalesData @SalesPersonID = 290, @StartDate = '20010601', @EndDate = '20120101' ;







/* Might as well leave this here... just in case */
SELECT  ecp.objtype,
        p.text,
        qp.query_plan
FROM    sys.dm_exec_cached_plans AS ecp
        CROSS APPLY sys.dm_exec_sql_text(ecp.plan_handle) AS p
        CROSS APPLY sys.dm_exec_query_plan(ecp.plan_handle) AS qp
WHERE   p.text LIKE '%Sales%'
        AND p.text NOT LIKE '%sys.dm_exec_cached_plans%'
OPTION (RECOMPILE) ;
GO














DBCC FREEPROCCACHE;
GO
















/* Let's look at using dynamic SQL to hit filtered indexes */
DROP INDEX [IX_SalesOrderHeader_OrderDate_Store] ON [Sales].[SalesOrderHeader]
DROP INDEX [IX_SalesOrderHeader_OrderDate_Online] ON [Sales].[SalesOrderHeader]
GO

CREATE NONCLUSTERED INDEX [IX_SalesOrderHeader_OrderDate_Online] ON [Sales].[SalesOrderHeader]
(
    [OrderDate] ASC
)
INCLUDE (TotalDue, SalesOrderID, SalesPersonID)
WHERE ([SalesPersonID] IS NULL)
GO

CREATE NONCLUSTERED INDEX [IX_SalesOrderHeader_OrderDate_Store] ON [Sales].[SalesOrderHeader]
(
    [OrderDate] ASC
)
INCLUDE (TotalDue, SalesOrderID, SalesPersonID)
WHERE ([SalesPersonID] IS NOT NULL)
GO





IF OBJECT_ID('bou.MonthlySalesReport') IS NULL
    EXEC('CREATE PROCEDURE bou.MonthlySalesReport AS RETURN 0;');
GO

ALTER PROCEDURE bou.MonthlySalesReport
  @Online AS BIT = 0,
  @CurrentUserID INT = NULL,
  @StartDate AS DATETIME = NULL,
  @EndDate AS DATETIME = NULL
AS
BEGIN
    SET NOCOUNT ON;

    CREATE TABLE #accounts 
    (
        CustomerID INT
    );

    INSERT INTO #accounts
    SELECT  CustomerID 
    FROM    dbo.AllowedCustomers(@CurrentUserID);

    DECLARE @sql AS NVARCHAR(MAX) = N'';

    SELECT @sql += N'
    SELECT  ' + CASE @Online WHEN 0 THEN N' soh.SalesPersonID, ' ELSE N'' END + N'
            YEAR(soh.OrderDate) AS Year,
            MONTH(soh.OrderDate) AS Month,
            SUM(soh.TotalDue) AS TotalSales,
            COUNT(soh.SalesOrderID) AS NumberOfSales
    FROM    Sales.SalesOrderHeader soh ';

    IF ((SELECT COUNT(*) FROM #accounts) > 0)
        SET @sql += ' JOIN #accounts a ON soh.CustomerID = a.CustomerID '

    SET @sql += N' WHERE 1 = 1';
    
    IF @Online = 1
    BEGIN
        SET @sql += N' AND SalesPersonID IS NULL '
    END
    ELSE
    BEGIN
        SET @sql += N' AND SalesPersonID IS NOT NULL '
    END

    IF @StartDate IS NOT NULL
    BEGIN
        SET @sql += N' AND soh.OrderDate BETWEEN @start_date AND @end_date '
    END

    SET @sql += N' GROUP BY ' + CASE @Online WHEN 0 THEN N' soh.SalesPersonID, ' ELSE N'' END + N' YEAR(soh.OrderDate), MONTH(soh.OrderDate) ';

    PRINT @sql;

    EXEC sp_executesql @sql, 
                       N'@start_date DATETIME, @end_date DATETIME',
                       @StartDate, @EndDate;
END
GO














EXEC bou.MonthlySalesReport @Online = 1;
EXEC bou.MonthlySalesReport @Online = 0;
GO






























/* This second iteration doesn't add any new functionality, but it does add
   significant convenience.

   The name of the generating stored procedure is added in a comment.
   A @newline convenience variable is added.
 */
ALTER PROCEDURE bou.MonthlySalesReport
  @Online AS BIT = 0,
  @CurrentUserID INT = NULL,
  @StartDate AS DATETIME = NULL,
  @EndDate AS DATETIME = NULL
AS
BEGIN
    SET NOCOUNT ON;

    CREATE TABLE #accounts 
    (
        CustomerID INT
    );

    INSERT INTO #accounts
    SELECT  CustomerID 
    FROM    dbo.AllowedCustomers(@CurrentUserID);

    DECLARE @sql AS NVARCHAR(MAX) = N'';
    DECLARE @newline AS NVARCHAR(2) = NCHAR(13) + NCHAR(10);

    SELECT @sql += N'/* bou.MonthlySalesReport */
SELECT  ' + CASE @Online WHEN 0 THEN N' soh.SalesPersonID, ' ELSE N'' END + N'
        YEAR(soh.OrderDate) AS Year,
        MONTH(soh.OrderDate) AS Month,
        SUM(soh.TotalDue) AS TotalSales,
        COUNT(soh.SalesOrderID) AS NumberOfSales
FROM    Sales.SalesOrderHeader soh ' + @newline;

    IF ((SELECT COUNT(*) FROM #accounts) > 0)
        SET @sql += 'JOIN #accounts a ON soh.CustomerID = a.CustomerID ' + @newline

    SET @sql += N' WHERE 1 = 1' + @newline;
    
    IF @Online = 1
    BEGIN
        SET @sql += N' AND SalesPersonID IS NULL ' + @newline
    END
    ELSE
    BEGIN
        SET @sql += N' AND SalesPersonID IS NOT NULL ' + @newline
    END

    IF @StartDate IS NOT NULL
    BEGIN
        SET @sql += N' AND soh.OrderDate BETWEEN @start_date AND @end_date ' + @newline
    END

    SET @sql += N' GROUP BY ' 
                + CASE @Online WHEN 0 THEN N' soh.SalesPersonID, ' ELSE N'' END 
                + N' YEAR(soh.OrderDate), MONTH(soh.OrderDate) ' + @newline;

    PRINT @sql;

    EXEC sp_executesql @sql, 
                       N'@start_date DATETIME, @end_date DATETIME',
                       @StartDate, @EndDate;
END
GO





















