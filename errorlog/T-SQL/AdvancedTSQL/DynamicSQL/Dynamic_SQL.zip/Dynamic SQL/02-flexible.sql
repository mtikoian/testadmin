/*
Dynamic SQL

Jeremiah Peschka, Brent Ozar Unlimited
v1.0 - January 2014

(C) 2014, Brent Ozar Unlimited. 
See http://BrentOzar.com/go/eula for the End User Licensing Agreement.
*/

DBCC FREEPROCCACHE;
GO
CREATE SCHEMA bou;

/* Let's try something that requires a bit more flexibility. */
IF OBJECT_ID('bou.GetSalesData') IS NULL
    EXEC('CREATE PROCEDURE bou.GetSalesData AS RETURN 0;');
GO

ALTER PROCEDURE bou.GetSalesData
  @SalesPersonID AS INT = NULL,
  @StartDate AS DATETIME = NULL,
  @EndDate AS DATETIME = NULL
AS
SET NOCOUNT ON;

IF @SalesPersonID IS NOT NULL AND @StartDate IS NOT NULL
BEGIN
    SELECT  SalesPersonID,
            SUM(TotalDue) AS TotalSales,
            COUNT(SalesOrderID) AS NumberOfSales
    FROM    Sales.SalesOrderHeader
    WHERE   SalesPersonID = @SalesPersonID
            AND OrderDate BETWEEN @StartDate AND @EndDate
    GROUP BY SalesPersonID;
END
ELSE IF @SalesPersonID IS NOT NULL
BEGIN
    SELECT  SalesPersonID,
            SUM(TotalDue) AS TotalSales,
            COUNT(SalesOrderID) AS NumberOfSales
    FROM    Sales.SalesOrderHeader
    WHERE   SalesPersonID = @SalesPersonID
    GROUP BY SalesPersonID;
END
ELSE IF @StartDate IS NOT NULL
BEGIN
    SELECT  SalesPersonID,
            SUM(TotalDue) AS TotalSales,
            COUNT(SalesOrderID) AS NumberOfSales
    FROM    Sales.SalesOrderHeader
    WHERE   OrderDate BETWEEN @StartDate AND @EndDate
    GROUP BY SalesPersonID;
END
ELSE
BEGIN
    SELECT  SalesPersonID,
            SUM(TotalDue) AS TotalSales,
            COUNT(SalesOrderID) AS NumberOfSales
    FROM    Sales.SalesOrderHeader
    GROUP BY SalesPersonID;
END
GO













EXEC bou.GetSalesData @StartDate = '20010601', @EndDate = '20120101' ;
EXEC bou.GetSalesData ;
EXEC bou.GetSalesData @SalesPersonID = 271, @StartDate = '20010601', @EndDate = '20120101' ;







/* Hey, that's not so bad! 
   We'll just have to change code in 4 places if the query ever changes.

   Of course... We won't really know which branch is the biggest problem
   without looking at actual execution plans.
 */
SELECT  ecp.objtype,
        p.text,
        qp.query_plan
FROM    sys.dm_exec_cached_plans AS ecp
        CROSS APPLY sys.dm_exec_sql_text(ecp.plan_handle) AS p
        CROSS APPLY sys.dm_exec_query_plan(ecp.plan_handle) AS qp
WHERE   p.text LIKE '%Sales%'
        AND p.text NOT LIKE '%sys.dm_exec_cached_plans%'
OPTION (RECOMPILE) ;
GO











/* We've been asked to help the developers simplify the query. Let's 
   face it, nobody wants to handle multiple branches of logic.
 */
ALTER PROCEDURE bou.GetSalesData
  @SalesPersonID AS INT = NULL,
  @StartDate AS DATETIME = NULL,
  @EndDate AS DATETIME = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SELECT  SalesPersonID,
            SUM(TotalDue) AS TotalSales,
            COUNT(SalesOrderID) AS NumberOfSales
    FROM    Sales.SalesOrderHeader
    WHERE   SalesPersonID = COALESCE(@SalesPersonID, SalesPersonID)
            AND OrderDate BETWEEN COALESCE(@StartDate, OrderDate) 
                                AND COALESCE(@EndDate, OrderDate)
    GROUP BY SalesPersonID;
END
GO












EXEC bou.GetSalesData @StartDate = '20010601', @EndDate = '20120101' ;
EXEC bou.GetSalesData ;
EXEC bou.GetSalesData @SalesPersonID = 271, @StartDate = '20010601', @EndDate = '20120101' ;







/* Hey, that's not so bad! 
   We'll just have to change code in 4 places if the query ever changes.

   Of course... We won't really know which branch is the biggest problem
   without looking at actual execution plans.
 */
SELECT  ecp.objtype,
        p.text,
        qp.query_plan
FROM    sys.dm_exec_cached_plans AS ecp
        CROSS APPLY sys.dm_exec_sql_text(ecp.plan_handle) AS p
        CROSS APPLY sys.dm_exec_query_plan(ecp.plan_handle) AS qp
WHERE   p.text LIKE '%Sales%'
        AND p.text NOT LIKE '%sys.dm_exec_cached_plans%'
OPTION (RECOMPILE) ;
GO













DBCC FREEPROCCACHE;
GO


















/* Let's concatenate those strings! */
ALTER PROCEDURE bou.GetSalesData
  @SalesPersonID AS INT = NULL,
  @StartDate AS DATETIME = NULL,
  @EndDate AS DATETIME = NULL
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @sql AS NVARCHAR(MAX) = N'';

    SET @sql += N'
    SELECT  SalesPersonID,
            SUM(TotalDue) AS TotalSales,
            COUNT(SalesOrderID) AS NumberOfSales
    FROM    Sales.SalesOrderHeader ';

    IF @SalesPersonID IS NOT NULL 
       OR @StartDate IS NOT NULL
    BEGIN
        /* N.B. This won't work with forced parameterization */
        SET @sql += N' WHERE 1 = 1';
    END

    IF @SalesPersonID IS NOT NULL
    BEGIN
        SET @sql += N' AND SalesPersonID = ';
        SET @sql += CONVERT(NVARCHAR, @SalesPersonID)
        SET @sql += N' '
    END

    IF @StartDate IS NOT NULL
    BEGIN
        SET @sql += N' AND OrderDate BETWEEN '
        SET @sql += QUOTENAME(CONVERT(NVARCHAR, @StartDate, 101), N'''') 
        SET @sql += N' AND ' 
        SET @sql += QUOTENAME(CONVERT(NVARCHAR, @EndDate, 101), N'''');
    END

    SET @sql += N' GROUP BY SalesPersonID ';

    PRINT @sql;

    EXEC(@sql);
END













EXEC bou.GetSalesData @StartDate = '20010601', @EndDate = '20120101' ;
EXEC bou.GetSalesData ;
EXEC bou.GetSalesData @SalesPersonID = 271, @StartDate = '20010601', @EndDate = '20120101' ;







/* It worked... for values of worked.

   The downside is that the plan cache will fill up with literal values
   and grow at a rapid pace. These should be expired relatively quickly,
   but this will cause problems on an active system.
 */
SELECT  ecp.objtype,
        p.text,
        qp.query_plan
FROM    sys.dm_exec_cached_plans AS ecp
        CROSS APPLY sys.dm_exec_sql_text(ecp.plan_handle) AS p
        CROSS APPLY sys.dm_exec_query_plan(ecp.plan_handle) AS qp
WHERE   p.text LIKE '%Sales%'
        AND p.text NOT LIKE '%sys.dm_exec_cached_plans%'
OPTION (RECOMPILE) ;
GO













DBCC FREEPROCCACHE;
GO


















ALTER PROCEDURE bou.GetSalesData
  @SalesPersonID AS INT = NULL,
  @StartDate AS DATETIME = NULL,
  @EndDate AS DATETIME = NULL
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @sql AS NVARCHAR(MAX) = N'';

    SET @sql += N'
    SELECT  SalesPersonID,
            SUM(TotalDue) AS TotalSales,
            COUNT(SalesOrderID) AS NumberOfSales
    FROM    Sales.SalesOrderHeader ';

    IF @SalesPersonID IS NOT NULL 
       OR @StartDate IS NOT NULL
    BEGIN
        /* N.B. This won't work with forced parameterization */
        SET @sql += N' WHERE 1 = 1';
    END

    IF @SalesPersonID IS NOT NULL
    BEGIN
        SET @sql += N' AND SalesPersonID = @sales_person_id';
    END

    IF @StartDate IS NOT NULL
    BEGIN
        SET @sql += N' AND OrderDate BETWEEN @start_date AND @end_date '
    END

    SET @sql += N' GROUP BY SalesPersonID ';

    PRINT @sql;

    EXEC sp_executesql @sql, 
                       N'@sales_person_id INT, @start_date DATETIME, @end_date DATETIME',
                       @SalesPersonID, @StartDate, @EndDate;
END













EXEC bou.GetSalesData @StartDate = '20010601', @EndDate = '20120101' ;
EXEC bou.GetSalesData ;
EXEC bou.GetSalesData @SalesPersonID = 271, @StartDate = '20010601', @EndDate = '20120101' ;







/* That's much better.

   Yes, this will lead to more plans in the plan cache, but they'll be
   effective execution plans, as opposed to a small plan cache 
   containing poorly performing plans.
 */
SELECT  ecp.objtype,
        p.text,
        qp.query_plan
FROM    sys.dm_exec_cached_plans AS ecp
        CROSS APPLY sys.dm_exec_sql_text(ecp.plan_handle) AS p
        CROSS APPLY sys.dm_exec_query_plan(ecp.plan_handle) AS qp
WHERE   p.text LIKE '%Sales%'
        AND p.text NOT LIKE '%sys.dm_exec_cached_plans%'
OPTION (RECOMPILE) ;
GO














DBCC FREEPROCCACHE;
GO



















/* Let's make it easier to figure out where this code came from. */

ALTER PROCEDURE bou.GetSalesData
  @SalesPersonID AS INT = NULL,
  @StartDate AS DATETIME = NULL,
  @EndDate AS DATETIME = NULL
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @sql AS NVARCHAR(MAX) = N'';

    SET @sql += N'/* bou.GetSalesData */
    SELECT  SalesPersonID,
            SUM(TotalDue) AS TotalSales,
            COUNT(SalesOrderID) AS NumberOfSales
    FROM    Sales.SalesOrderHeader ';

    IF @SalesPersonID IS NOT NULL 
       OR @StartDate IS NOT NULL
    BEGIN
        /* N.B. This won't work with forced parameterization */
        SET @sql += N' WHERE 1 = 1';
    END

    IF @SalesPersonID IS NOT NULL
    BEGIN
        SET @sql += N' AND SalesPersonID = @sales_person_id';
    END

    IF @StartDate IS NOT NULL
    BEGIN
        SET @sql += N' AND OrderDate BETWEEN @start_date AND @end_date '
    END

    SET @sql += N' GROUP BY SalesPersonID ';

    PRINT @sql;

    EXEC sp_executesql @sql, 
                       N'@sales_person_id INT, @start_date DATETIME, @end_date DATETIME',
                       @SalesPersonID, @StartDate, @EndDate;
END
GO
