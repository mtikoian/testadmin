Create procedure spAllAvailableServers
as
declare @hr int,		--the HRESULT returned from the OLE operation
	@ii int,		--a simple counter
	@iimax int,		--the max of the iteration
	@objApplication int,	--the application object
	@ErrorObject int,	--the error object
	@ErrorMessage varchar(255),--the potential error message
	@command varchar(255),	--the command
	@Server Varchar(255)	--The String with the current server

set nocount on

exec @hr = sp_OACreate 'SQLDMO.Application', @objApplication OUT
Select @errorMessage='Getting the number of available servers in the collection',
	@ErrorObject=@objApplication
if @HR=0  EXEC @hr = sp_OAGetProperty @objApplication, 'ListAvailableSQLServers.Count', 
	@iimax OUT
Select @errorMessage='Getting each item',@ii=1
create table #Servers (MyID int identity(1,1), Server varchar(255))
while @hr=0 and @ii<=@iiMax --FOR EACH in
	begin
	select @command='ListAvailableSQLServers.item('+cast (@ii as varchar)+')'
	EXEC @hr = sp_OAGetProperty @objApplication, @command, 
		@Server OUT
	insert into #servers(server) select @Server
	Select @ii=@ii+1
	end
--shared error-handling code
if @hr<>0
	begin
	Declare 
		@Source varchar(255),
		@Description Varchar(255),
		@Helpfile Varchar(255),
		@HelpID int
	
	EXECUTE sp_OAGetErrorInfo  @errorObject, 
		@source output,@Description output,@Helpfile output,@HelpID output

	Select @ErrorMessage='Error whilst '+@Errormessage+', '+@Description
	raiserror (@ErrorMessage,16,1)
	end
exec sp_OADestroy @objApplication
Select * from #servers
return @hr
go

