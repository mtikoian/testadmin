SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

/****** Object:  Stored Procedure dbo.spCreateDatabase    Script Date: 23/11/2006 16:51:06 ******/
ALTER  procedure spCreateDatabase
@strServer Varchar(100),
@login  Varchar(100)=null,
@password Varchar(100)=null,
@DatabaseName Varchar(100),
@DataFileName Varchar(100),
@DataFilePath Varchar(100),
@LogFileName Varchar(100),
@LogFilePath Varchar(100)

/*
--with SQL Server Authentication
spCreateDatabase 'Server',MyUserID,MyPassword,
		'MyDatabaseName',
		'MyLogicalDataFileName',
		'MyPhysicalDataPathandfilename',
		'MyLogicalLogFileName',
		'MyPhysicalLogPathandfilename'

--with Windows Authentication
spCreateDatabase 'Server',default,default,
		'MyDatabaseName',
		'MyLogicalDataFileName',
		'MyPhysicalDataPathandfilename',
		'MyLogicalLogFileName',
		'MyPhysicalLogPathandfilename'

*/

as
declare @hr int,		--the HRESULT returned from the OLE operation
	@ii int,		--a simple counter
	@iimax int,		--the max of the iteration
	@objServer int,		--the Server object
	@objDatabase int,	--the Database object
	@objDBfileData int,	--the Database file
	@objLogFile int,	--the log file
	@ErrorObject int,	--the error object
	@strErrorMessage varchar(255)--the potential error message

--and our 'constants'
DECLARE @SQLDMOGrowth_MB int SET @SQLDMOGrowth_MB = 0
DECLARE @SQLDMOGrowth_Percent int SET @SQLDMOGrowth_Percent = 1
DECLARE @SQLDMOGrowth_Invalid int SET @SQLDMOGrowth_Invalid = 99


set nocount on

exec @hr = sp_OACreate 'SQLDMO.SQLServer', @objServer OUT

if @password is null or @login is null
	begin
	--use a trusted connection 
	if @hr=0 Select @strErrorMessage='Setting login to windows authentication on '+@strServer,@ErrorObject=@objServer
	if @hr=0 exec @hr = sp_OASetProperty @objServer, 'LoginSecure', 1
	if @hr=0 Select @strErrorMessage='logging in to the requested server using windows authentication on '+@strServer
	if @login is null and @hr=0 exec @hr = sp_OAMethod @objServer, 'Connect', NULL, @strServer 
	if @login is not null and @hr=0 exec @hr = sp_OAMethod @objServer, 'Connect', NULL, @strServer ,@Login
	end
else
	begin
	Select @strErrorMessage='logging in to the requested server using SQL Server authentication to '+@strServer,
		@ErrorObject=@objServer
	if @hr=0 exec @hr = sp_OAMethod @objServer, 'Connect', NULL, @strServer ,
						 @login , @password
	end

if @hr=0 Select @strErrorMessage='creating new database'+@strServer,
	@ErrorObject =null
if @hr=0 exec @hr = sp_OACreate 'SQLDMO.Database', @objDatabase OUT
if @hr=0 Select @strErrorMessage='creating new DBFile'+@strServer
if @hr=0 exec @hr = sp_OACreate 'SQLDMO.DBFile', @objDBfileData OUT
if @hr=0 Select @strErrorMessage='creating new Logfile'+@strServer
if @hr=0 exec @hr = sp_OACreate 'SQLDMO.LogFile', @objLogFile OUT

if @hr=0 SELECT @strErrorMessage = 'setting the Database name',
		@ErrorObject=@objDatabase
if @hr=0 EXEC @hr= sp_OASetProperty @objDatabase, 'Name',@DatabaseName

if @hr=0 SELECT @strErrorMessage = 'setting the DataFile properties',
		@ErrorObject=@objDBFileData
if @hr=0 EXEC @hr= sp_OASetProperty @objDBFileData, 'Name',@DataFileName
if @hr=0 EXEC @hr= sp_OASetProperty @objDBFileData, 'PhysicalName',
		@DataFilePath
if @hr=0 EXEC @hr= sp_OASetProperty @objDBFileData, 'PrimaryFile',1
--Specify file growth in chunks of fixed size for all data files.
if @hr=0 EXEC @hr= sp_OASetProperty @objDBFileData, 'FileGrowthType',
	@SQLDMOGrowth_MB
if @hr=0 EXEC @hr= sp_OASetProperty @objDBFileData, 'FileGrowth',1

if @hr=0 select @strErrorMessage='using method to add '+@DataFileName,
		@ErrorObject=@objDatabase
if @hr=0 exec @hr = sp_OAMethod @objDatabase, 'FileGroups("PRIMARY").DBFiles.Add',null,
		@objDBFileData

if @hr=0 select @strErrorMessage='Setting the logfile properties of '+@LogFileName,
		@ErrorObject=@objLogFile
if @hr=0 EXEC @hr= sp_OASetProperty @objLogFile, 'Name',@LogFileName
if @hr=0 EXEC @hr= sp_OASetProperty @objLogFile, 'PhysicalName',
		@LogFilePath
if @hr=0 select @strErrorMessage='using method to add '+@LogFileName,
		@ErrorObject=@objDatabase
if @hr=0 exec @hr = sp_OAMethod @objDatabase, 'TransactionLog.LogFiles.Add',null,
		@objLogFile

if @hr=0 select @strErrorMessage='using method to add '+@DatabaseName+' to the server',
		@ErrorObject=@objServer
if @hr=0 exec @hr = sp_OAMethod @objServer, 'Databases.Add',null,
		@objDatabase

--and handling any errors
if @hr<>0
	begin
	Declare 
		@Source varchar(255),
		@Description Varchar(255),
		@Helpfile Varchar(255),
		@HelpID int
	
	EXECUTE sp_OAGetErrorInfo  @errorObject, 
		@source output,@Description output,@Helpfile output,@HelpID output

	Select @strErrorMessage='Error whilst '+@strErrorMessage+', '+@Description
	raiserror (@strErrorMessage,16,1)
	end
exec sp_OADestroy @objServer
exec sp_OADestroy @objDatabase   --the Database object
exec sp_OADestroy @objDBfileData --the Database file
exec sp_OADestroy @objLogFile



GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

