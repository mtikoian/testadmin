SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

/****** Object:  Stored Procedure dbo.spEnumerateDatabases    Script Date: 23/11/2006 17:14:35 ******/
ALTER  procedure spEnumerateDatabases
@strServer Varchar(100),
@login  Varchar(100)=null,
@password Varchar(100)=null

/*
--SQL Server Authentication
execute spEnumerateDatabases 'MyServer','MyLogin','MyPassword'
--Windows Authentication
execute spEnumerateDatabases 'MyServer'

*/
as
declare @hr int,		--the HRESULT returned from the OLE operation
	@ii int,		--a simple counter
	@iimax int,		--the max of the iteration
	@objServer int,		--the Server object
	@objDatabase int,	--the Database object
	@ErrorObject int,	--the error object
	@ErrorMessage varchar(255),--the potential error message
	@command varchar(255),	--the command
	@DatabaseName Varchar(255),	--The String with the current Database
	@DatabaseSize int	--The String with the current Database

set nocount on

exec @hr = sp_OACreate 'SQLDMO.SQLServer', @objServer OUT
if @password is null or @login is null
	begin
	--use a trusted connection 
	if @hr=0 Select @ErrorMessage='Setting login to windows authentication on '+@strServer,
	@ErrorObject=@objServer
	if @hr=0 exec @hr = sp_OASetProperty @objServer, 'LoginSecure', 1
	if @hr=0 Select @ErrorMessage='logging in to the requested server using windows authentication on '+@strServer
	if @login is null and @hr=0 exec @hr = sp_OAMethod @objServer, 'Connect', NULL, @strServer 
	if @login is not null and @hr=0 exec @hr = sp_OAMethod @objServer, 'Connect', NULL, @strServer ,@Login
	end
else
	Begin
	if @hr=0 SELECT @ErrorMessage = 'Connecting to '''+@strServer+
		''' with user ID '''+@login+'''', @ErrorObject=@objServer
	if @hr=0 exec @hr = sp_OAMethod @objServer, 'Connect', NULL, @strServer ,
						 @login , @password
	end
Select @errorMessage='finding the number of databases in '+@strServer,
	@ErrorObject=@objServer
if @HR=0  EXEC @hr = sp_OAGetProperty @objServer, 'databases.Count', 
	@iimax OUT
Select @errorMessage='Getting each item',@ii=1
create table #Databases (MyID int identity(1,1), TheName varchar(255),theSize int)
while @hr=0 and @ii<=@iiMax
	begin
	select @command='databases.item('+cast (@ii as varchar)+').name'
	EXEC @hr = sp_OAGetProperty @objServer, @command, 
		@DatabaseName OUT
	select @command='databases.item('+cast (@ii as varchar)+').size'
	if @HR=0  EXEC @hr = sp_OAGetProperty @objServer, @command, 
		@DatabaseSize OUT
	insert into #Databases(thename,thesize) select @DatabaseName,@DatabaseSize
	Select @ii=@ii+1
	end
if @hr<>0
	begin
	Declare 
		@Source varchar(255),
		@Description Varchar(255),
		@Helpfile Varchar(255),
		@HelpID int
	
	EXECUTE sp_OAGetErrorInfo  @errorObject, 
		@source output,@Description output,@Helpfile output,@HelpID output

	Select @ErrorMessage='Error whilst '+@Errormessage+', '+@Description
	raiserror (@ErrorMessage,16,1)
	end
exec sp_OADestroy @objServer
Select * from #databases
return @hr

/*
Sub call_enumerate_databases()
'Pass along server name, login, and password
'to routine to enumerate databases on a server
enumerate_databases "cabarmada", "sa", ""

End Sub


Sub enumerate_databases(srvname As String, _
    login As String, password As String)
Dim srv1 As SQLDMO.SQLServer
Dim dbs As SQLDMO.Database

'Connect to a SQL Server
Set srv1 = New SQLDMO.SQLServer
srv1.Connect srvname, login, password

'Enumerate the databases on connected server
For Each dbs In SQLDMO.SQLServers(srvname).Databases
    Debug.Print dbs.Name & " uses " & dbs.Size & _
        "MB of storage."
Next

'Cleanup routine
srv1.Disconnect
Set srv1 = Nothing

End Sub

*/

GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

