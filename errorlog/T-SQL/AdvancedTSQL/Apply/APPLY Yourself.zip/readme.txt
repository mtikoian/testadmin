Thank you for your interest in getting the APPLY Yourself slides and demonstration code.  You can find these files at http://www.catallaxyservices.com/presentations/apply-yourself/.

Please contact me if you have any questions.  You can reach me at feasel@catallaxyservices.com or via Twitter at @feaselkl.

Thanks again,

Kevin Feasel