APPLY-Yourself
==============

This is demo code for my APPLY Yourself presentation.  You can see the presentation at http://www.catallaxyservices.com/presentations/APPLY-Yourself.

All source code is licensed under the terms offered by the GPL (http://www.gnu.org/licenses/gpl.html) unless otherwise mentioned.
