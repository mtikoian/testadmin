/*
Demo Script #4

SQL Saturday #440, Pittsburgh

October 3rd, 2015

Get Familiar with Spatial Data. 

Slava Murygin

Drawing American Flag
*/
/*
Used specifications from:
http://www.usflag.org/flagspecs.html
*/

DECLARE @A FLOAT = 100; -- Flag Width
DECLARE @B FLOAT = 190; -- Flag Length
DECLARE @UA FLOAT = @A * 7 / 13; -- Union Length
DECLARE @UB FLOAT = 76; -- Union Length
DECLARE @s TINYINT = 1; -- Stripe Count

DECLARE @StripePolygon VARCHAR(MAX) = '';
DECLARE @r FLOAT = 6.16/2; -- Star Radius
DECLARE @hd FLOAT = @UB/12; -- Horisontal distance between stars
DECLARE @vd FLOAT = 5.4; -- Vertical distance between stars

DECLARE @h TINYINT = 0, @v TINYINT = 0; -- Horisontal & Vertical Star counters
DECLARE @x FLOAT;
DECLARE @y FLOAT;

DECLARE @rad18 FLOAT = RADIANS(18.);
DECLARE @rad36 FLOAT = RADIANS(36.);
DECLARE @SIN18 FLOAT = SIN(@rad18);
DECLARE @COS18 FLOAT = COS(@rad18);
DECLARE @SIN36 FLOAT = SIN(@rad36);
DECLARE @COS36 FLOAT = COS(@rad36);
DECLARE @TAN36 FLOAT = TAN(@rad36);

DECLARE @StarPolygon VARCHAR(MAX) = '';

DECLARE @Flag TABLE(Polygon GEOMETRY, ID INT IDENTITY(1,1))

-- Building Set of 50 stars
WHILE @h < 11
BEGIN
  SET @h += 1;
  WHILE @v < 9
  BEGIN
	SET @v += 2;
	SELECT 
		@x = @hd * (@h - 1 + (@v + 1) % 2), 
		@y = @vd * (@v - 1 + (@h + 1) % 2) * (-1);  

	-- Building Individual star
	SET @StarPolygon += ',('
	+ CONVERT(varchar, @x) + ' ' + CONVERT(varchar, @y + @r) + ','
	+ CONVERT(varchar, @x + @r * @SIN18 * @TAN36 ) + ' ' + CONVERT(varchar, @y + @r * @SIN18 ) + ','
	+ CONVERT(varchar, @x + @r * COS(RADIANS(18.)) ) + ' ' + CONVERT(varchar, @y + @r * SIN(RADIANS(18.))) + ','
	+ CONVERT(varchar, @x + @r * @SIN18 * @COS18 / @COS36 ) + ' ' + CONVERT(varchar, @y - @r * @SIN18 * @SIN18 / @COS36 ) + ','
	+ CONVERT(varchar, @x + @r * SIN(RADIANS(36.))) + ' ' + CONVERT(varchar, @y - @r * COS(RADIANS(36.))) + ','
	+ CONVERT(varchar, @x) + ' ' + CONVERT(varchar, @y - @r * @SIN18 / @COS36 ) + ','
	+ CONVERT(varchar, @x - @r * SIN(RADIANS(36.))) + ' ' + CONVERT(varchar, @y - @r * COS(RADIANS(36.))) + ','
	+ CONVERT(varchar, @x - @r * @SIN18 * @COS18 / @COS36 ) + ' ' + CONVERT(varchar, @y - @r * @SIN18 * @SIN18 / @COS36 ) + ','
	+ CONVERT(varchar, @x - @r * COS(RADIANS(18.))) + ' ' + CONVERT(varchar, @y + @r * SIN(RADIANS(18.))) + ','
	+ CONVERT(varchar, @x - @r * @SIN18 * @TAN36 ) + ' ' + CONVERT(varchar, @y + @r * @SIN18 ) + ','
	+ CONVERT(varchar, @x) + ' ' + CONVERT(varchar, @y + @r) 
	+ ')';

	IF @v = 8 and @h % 2 = 0 SET @v = 9;
  END
  SET @v = 0;
END

-- Building set of 13 stripes
WHILE @s <= 13
BEGIN
  -- Building Individual stripe
  SELECT @StripePolygon += ',(' 
  + CASE WHEN @s < 9 THEN CONVERT(varchar, @UB) ELSE '0' END + ' '  + CONVERT(varchar, (@s - 1) * @A / -13) + ','
  + CASE WHEN @s < 9 THEN CONVERT(varchar, @UB) ELSE '0' END + ' '  + CONVERT(varchar, @s * @A / -13) + ','
  + CONVERT(varchar, @B) + ' '  + CONVERT(varchar, @s * @A / -13) + ','
  + CONVERT(varchar, @B) + ' '  + CONVERT(varchar, (@s - 1) * @A / -13) + ','
  + CASE WHEN @s < 9 THEN CONVERT(varchar, @UB) ELSE '0' END + ' '  + CONVERT(varchar, (@s - 1) * @A / -13) + ')'
  , @s += 2;
END

---------------------------------------------------------------------------------------------------------------

-- Adjust Frame Color
INSERT INTO @Flag(Polygon)
SELECT TOP 149 CAST('POLYGON((0 0, 0 0.0000001, 0.0000001 0.0000001, 0 0))' as geometry) FROM sys.messages

-- Adding Frame
INSERT INTO @Flag(Polygon)
SELECT CAST('POLYGON((0 0, 0 ' 
+ CONVERT(varchar, -@A) + ', ' 
+ CONVERT(varchar, @B) + ' ' + CONVERT(varchar, -@A) + ', ' 
+ CONVERT(varchar, @B) + ' 0,0 0),' 
+ '(0.1 -0.1,0.1 '
+ CONVERT(varchar, 0.1 - @A ) + ', ' 
+ CONVERT(varchar, @B - 0.1) + ' ' + CONVERT(varchar, 0.1 - @A) + ', ' 
+ CONVERT(varchar, @B - 0.1) + ' -0.1,0.1 -0.1)' 
+ ')' as geometry)

-- Adjust Union Color
INSERT INTO @Flag(Polygon)
SELECT TOP 140 CAST('POLYGON((0 0, 0 0.0000001, 0.0000001 0.0000001, 0 0))' as geometry) FROM sys.messages

-- Adding Union 
INSERT INTO @Flag(Polygon)
SELECT CAST('POLYGON(' 
+ '(0 0,0 ' + CONVERT(varchar, @vd * -10) 
+ ',' + CONVERT(varchar, @hd * 12) + ' ' + CONVERT(varchar, @vd * -10) 
+ ',' + CONVERT(varchar, @hd * 12) + ' 0,0 0),'
+ SUBSTRING(@StarPolygon, 2, @@TEXTSIZE) +  ')' as geometry);

-- Adjust Stripe's Color
INSERT INTO @Flag(Polygon)
SELECT TOP 4 CAST('POLYGON((0 0, 0 0.0000001, 0.0000001 0.0000001, 0 0))' as geometry) FROM sys.messages

-- Adding Strips
INSERT INTO @Flag(Polygon)
SELECT CAST('POLYGON(' + SUBSTRING(@StripePolygon, 2, @@TEXTSIZE) +  ')' as geometry);

-- Adjust Stars' Color
INSERT INTO @Flag(Polygon)
SELECT TOP 28 CAST('POLYGON((0 0, 0 0.0000001, 0.0000001 0.0000001, 0 0))' as geometry) FROM sys.messages

-- Adding Stars 
INSERT INTO @Flag(Polygon)
SELECT CAST('POLYGON(' + SUBSTRING(@StarPolygon, 2, @@TEXTSIZE) +  ')' as geometry);

SELECT * FROM @Flag;
