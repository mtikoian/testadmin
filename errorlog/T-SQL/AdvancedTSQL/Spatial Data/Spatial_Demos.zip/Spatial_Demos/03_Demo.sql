/*
Demo Script #3

SQL Saturday #440, Pittsburgh

October 3rd, 2015

Get Familiar with Spatial Data. 

Slava Murygin

Building Sky Map in SSMS using GeoSpatial methods.
http://slavasql.blogspot.com/2015/01/skymap.html
*/


/*
http://www.astronexus.com/hyg
http://www.astronexus.com/files/downloads/hygdata_v3.csv.gz
HYG 3.0: Database containing all stars in Hipparcos, Yale Bright Star, and Gliese catalogs (almost 120,000 stars, 14 MB)
*/

/*--------------------------------------------------------------------------------------------------------
/* Recreate a Stellar DB*/
USE MASTER;
GO
IF EXISTS (SELECT TOP 1 1 FROM sys.databases WHERE name = 'Stars_DB')
BEGIN
  ALTER DATABASE Stars_DB SET RESTRICTED_USER WITH ROLLBACK IMMEDIATE 
  DROP DATABASE Stars_DB
END
GO
CREATE DATABASE Stars_DB;
GO

--------------------------------------------------------------------------------------------------------*/


/*
0. Create Stars_DB
1. Run SQL Server Import/Export wizard
2. Select Flat file as a source L:\SQLPASS\MyPresents\Spatial_Data\Spatial_Demos\hygdata_v3.csv
3. Select SQL Stars_DB as Target
4. Choose "tbl_Stellar_List" as a target
5. Run Package
*/

/*--------------------------------------------------------------------------------------------------------*/
-USE Stars_DB;
GO


/* Full Star Map */
DECLARE @SpatialTable TABLE (
       Object varchar(50),
       Constellation varchar(50),
       Latitude Float,
       Longitude Float,
       Magnitude Float,
       g geography);

INSERT INTO @SpatialTable(Object, Constellation, Latitude, Longitude, Magnitude, g)
SELECT Proper, Con, CAST(ra as FLOAT)*(-15), [dec], CAST(mag as FLOAT),
       geography::STGeomFromText('POINT('
              + CONVERT(VARCHAR,CAST(ra as FLOAT)*-15)
              + ' ' + CONVERT(VARCHAR,[dec])
              + ')',104001).STBuffer((CAST(mag as FLOAT)*(-1)+5) * 0.002)
FROM dbo.tbl_Stellar_List
WHERE CAST(mag as FLOAT) <= 4.5 and Con != '';

INSERT INTO @SpatialTable(Object, g)
SELECT 'North Pole', geography::STGeomFromText('POINT(0 90)',104001)
UNION ALL
SELECT 'South Pole', geography::STGeomFromText('POINT(0 -90)',104001)
UNION ALL
SELECT 'Map Center', geography::STGeomFromText('POINT(0 0)',104001)
UNION ALL
SELECT 'Map Left', geography::STGeomFromText('POINT(-179.999 0)',104001)
UNION ALL
SELECT 'Map Right', geography::STGeomFromText('POINT(179.999 0)',104001)

SELECT * FROM @SpatialTable;
GO
/*-------------------------------------------------------------------------------------------------------*/

/* Extract Ursa Major */
DECLARE @SpatialTable TABLE (
	Id INT,
	Object varchar(50),
	Constellation varchar(50),
	Latitude Float,
	Longitude Float,
	Magnitude Float,
	g geography);

INSERT INTO @SpatialTable(Id, Object, Constellation, Latitude, Longitude, Magnitude, g)
SELECT Id, Proper, Con, CAST(ra as FLOAT)*(-15), [dec], CAST(mag as FLOAT),
       geography::STGeomFromText('POINT('
              + CONVERT(VARCHAR,CAST(ra as FLOAT)*-15+90)
              + ' ' + CONVERT(VARCHAR,[dec])
              + ')',104001).STBuffer((CAST(mag as FLOAT)*(-1)+5) * 0.002)
FROM dbo.tbl_Stellar_List
WHERE CAST(mag as FLOAT) <= 4.5 and Con = 'Uma';

SELECT * FROM @SpatialTable;
GO

/*--------------------------------------------------------------------------------------------------------*/

/* Extract Ursa Major with lines */
DECLARE @SpatialTable TABLE (
	Id INT,
	Object varchar(50),
	Constellation varchar(50),
	Latitude Float,
	Longitude Float,
	Magnitude Float,
	g geography);

DECLARE @Constellation TABLE (Star1 INT, Star2 INT);
INSERT INTO @Constellation(Star1, Star2) VALUES
	(67088, 65173),	(65173, 62757),	(62757, 59592),
	(59592, 53905),	(59592, 57828),	(53905, 46600),
	(53905, 53754),	(46600, 41586),	(46600, 48182),
	(41586, 48182),	(57828, 53754),	(57828, 57226),
	(53754, 48182),	(48182, 46720),	(57226, 54380),
	(54380, 50655),	(50655, 50230),	(46720, 44000),
	(57226, 55055),	(55055, 118742), (46720, 44343);

INSERT INTO @SpatialTable(Id, Object, Constellation, Latitude, Longitude, Magnitude, g)
SELECT Id, Proper, Con, CAST(ra as FLOAT)*(-15), [dec], CAST(mag as FLOAT),
       geography::STGeomFromText('POINT('
              + CONVERT(VARCHAR,CAST(ra as FLOAT)*-15+90)
              + ' ' + CONVERT(VARCHAR,[dec])
              + ')',104001).STBuffer((CAST(mag as FLOAT)*(-1)+5) * 0.002)
FROM dbo.tbl_Stellar_List
WHERE CAST(mag as FLOAT) <= 4.5 and Con = 'Uma';

SELECT * FROM @SpatialTable
UNION ALL  
SELECT 0, 'Line', 'Uma', 0, 0, 0,
	geography::STGeomFromText('MULTILINESTRING(' + SUBSTRING((
		SELECT ',('
			+ CONVERT(VARCHAR,CAST(s1.ra as FLOAT)*-15+90)
			+ ' ' + CONVERT(VARCHAR,s1.[dec])
			+ ', '
			+ CONVERT(VARCHAR,CAST(s2.ra as FLOAT)*-15+90)
			+ ' ' + CONVERT(VARCHAR,s2.[dec])
			+ ')'
		FROM @Constellation as c
		INNER JOIN dbo.tbl_Stellar_List as s1 ON s1.ID = c.Star1
		INNER JOIN dbo.tbl_Stellar_List as s2 ON s2.ID = c.Star2
		FOR XML PATH('')
		), 2, 8000) +')',104001).STBuffer(0.0001)
GO