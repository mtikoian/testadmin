/*
Demo Script #4

SQL Saturday #440, Pittsburgh

October 3rd, 2015

Get Familiar with Spatial Data. 

Slava Murygin

Drawing Some Geometry figures
*/
SET NOCOUNT ON

/* Ellipse */
DECLARE @MP VARCHAR(MAX)='';

DECLARE @theta DECIMAL(8,4) = 0;-- angle that will be increased each loop
DECLARE @h DECIMAL(8,4) = 0;	-- x coordinate of center
DECLARE @k DECIMAL(8,4) = 0;	-- y coordinate of center
DECLARE @step DECIMAL(8,4) = 2 * PI()/100;  -- amount to add to theta each time (degrees)

DECLARE @a DECIMAL(8,4) = 10;	-- major axis
DECLARE @b DECIMAL(8,4) = 5;	-- minor axis

DECLARE @x1 DECIMAL(8,4), @y1 DECIMAL(8,4);
DECLARE @x2 DECIMAL(8,4) = @h + @a * COS(@theta);
DECLARE @y2 DECIMAL(8,4) = @k + @b * SIN(@theta);

WHILE @theta <= 2 * PI()
SELECT 
	@x1 = @x2, @y1 = @y2,
	@x2 = @h + @a * COS(@theta), 
	@y2 = @k + @b * SIN(@theta), 
	@theta += @step, 
	@MP = @MP + '(' 
		+ CAST(@x1 as VARCHAR) +  ' ' 
		+ CAST(@y1 as VARCHAR) + ',' 
		+ CAST(@x2 as VARCHAR) +  ' ' 
		+ CAST(@y2 as VARCHAR) + '),';

SELECT CAST('MULTILINESTRING(' + LEFT(@MP,LEN(@MP)-1) + ')' as geometry).MakeValid().STBuffer(0.01)
GO

/*-------------------------------------------------------------------------------------------------*/

/* Parabola */
DECLARE @MP VARCHAR(MAX)='';

DECLARE @l DECIMAL(8,4) = 1;	-- Slope
DECLARE @bx DECIMAL(8,4) = 0;	-- X-bottom point
DECLARE @by DECIMAL(8,4) = 0;	-- Y-bottom point
DECLARE @p DECIMAL(8,4) = 2;	-- Parabola's Power
DECLARE @Step DECIMAL(8,4) = 0.01;	-- Step
DECLARE @s DECIMAL(8,4) = 5;	-- X-Span of Parabola

DECLARE @cx DECIMAL(8,4) = -@s;	-- X-Current point
DECLARE @x1 DECIMAL(19,4);
DECLARE @y1 DECIMAL(19,4);
DECLARE @x2 DECIMAL(19,4) = @cx + @bx;
DECLARE @y2 DECIMAL(19,4) = @by + @l * POWER(ABS(@x2 - @bx),@p);

WHILE @cx < @s
SELECT 
	@cx += @Step,
	@x1 = @x2, @y1 = @y2,
	@x2 = @cx + @bx, 
	@y2 = @by + @l * POWER(ABS(@x2 - @bx),@p), 
	@MP = @MP + '(' 
		+ CAST(@x1 as VARCHAR) +  ' ' 
		+ CAST(@y1 as VARCHAR) + ',' 
		+ CAST(@x2 as VARCHAR) +  ' ' 
		+ CAST(@y2 as VARCHAR) + '),';

SELECT CAST('MULTILINESTRING(' + LEFT(@MP,LEN(@MP)-1) + ')' as geometry).STBuffer(0.01);
GO
DECLARE @MP VARCHAR(MAX)='';

DECLARE @l DECIMAL(8,4) = -0.5;	-- Slope
DECLARE @bx DECIMAL(8,4) = 7;	-- X-bottom point
DECLARE @by DECIMAL(8,4) = 3;	-- Y-bottom point
DECLARE @p DECIMAL(8,4) = 1.5;	-- Parabola's Power
DECLARE @Step DECIMAL(8,4) = 0.01;	-- Step
DECLARE @s DECIMAL(8,4) = 5;	-- X-Span of Parabola

DECLARE @cx DECIMAL(8,4) = -@s;	-- X-Current point
DECLARE @x1 DECIMAL(19,4);
DECLARE @y1 DECIMAL(19,4);
DECLARE @x2 DECIMAL(19,4) = @cx + @bx;
DECLARE @y2 DECIMAL(19,4) = @by + @l * POWER(ABS(@x2 - @bx),@p);

WHILE @cx < @s
SELECT 
	@cx += @Step,
	@x1 = @x2, @y1 = @y2,
	@x2 = @cx + @bx, 
	@y2 = @by + @l * POWER(ABS(@x2 - @bx),@p), 
	@MP = @MP + '(' 
		+ CAST(@x1 as VARCHAR) +  ' ' 
		+ CAST(@y1 as VARCHAR) + ',' 
		+ CAST(@x2 as VARCHAR) +  ' ' 
		+ CAST(@y2 as VARCHAR) + '),';

SELECT CAST('MULTILINESTRING(' + LEFT(@MP,LEN(@MP)-1) + ')' as geometry).STBuffer(0.01);
GO

/*-------------------------------------------------------------------------------------------------*/

/* Hyperbola */
DECLARE @MP VARCHAR(MAX)='';

DECLARE @l DECIMAL(8,4) = 1;	-- Slope
DECLARE @bx DECIMAL(8,4) = 0;	-- X-Center point
DECLARE @by DECIMAL(8,4) = 0;	-- Y-Center point
DECLARE @s DECIMAL(8,4) = 10;	-- X-Span of Hyperbola
DECLARE @Step DECIMAL(8,4) = 0.1;	-- Step

DECLARE @cx DECIMAL(8,4) = -@s;	-- X-Current point
DECLARE @x1 DECIMAL(19,9);
DECLARE @y1 DECIMAL(19,9);
DECLARE @x2 DECIMAL(19,9) = @cx + @bx;
DECLARE @y2 DECIMAL(19,9) = @by + @l / (@x2 - @bx);

WHILE @cx < @s
SELECT 
	@cx += @Step,
	@x1 = @x2, @y1 = @y2,
	@x2 = @cx + @bx, 
	@y2 = CASE @cx WHEN 0 THEN @y1 ELSE @by + @l / (@x2 - @bx) END, 
	@MP = @MP + CASE WHEN @x2 = @bx OR (@x1 <= @bx and @x2 >= @bx ) THEN '' ELSE '(' 
		+ CAST(@x1 as VARCHAR) +  ' ' 
		+ CAST(@y1 as VARCHAR) + ',' 
		+ CAST(@x2 as VARCHAR) +  ' ' 
		+ CAST(@y2 as VARCHAR) + '),' END ;

SELECT CAST('MULTILINESTRING(' + LEFT(@MP,LEN(@MP)-1) + ')' as geometry).STBuffer(0.01);
GO
DECLARE @MP VARCHAR(MAX)='';

DECLARE @l DECIMAL(8,4) = -2;	-- Slope
DECLARE @bx DECIMAL(8,4) = 12;	-- X-Center point
DECLARE @by DECIMAL(8,4) = 3;	-- Y-Center point
DECLARE @s DECIMAL(8,4) = 20;	-- X-Span of Hyperbola
DECLARE @Step DECIMAL(8,4) = 0.1;	-- Step
DECLARE @k DECIMAL(8,4) = 0.5;

DECLARE @cx DECIMAL(8,4) = -@s;	-- X-Current point
DECLARE @x1 DECIMAL(19,9);
DECLARE @y1 DECIMAL(19,9);
DECLARE @x2 DECIMAL(19,9) = @cx + @bx;
DECLARE @y2 DECIMAL(19,9) = @by + @k*@x2 + @l / (@x2 - @bx);

WHILE @cx < @s
SELECT 
	@cx += @Step,
	@x1 = @x2, @y1 = @y2,
	@x2 = @cx + @bx, 
	@y2 = CASE @cx WHEN 0 THEN @y1 ELSE @by + @k*@x2 + @l / (@x2 - @bx) END, 
	@MP = @MP + CASE WHEN @x2 = @bx OR (@x1 <= @bx and @x2 >= @bx ) THEN '' ELSE '(' 
		+ CAST(@x1 as VARCHAR) +  ' ' 
		+ CAST(@y1 as VARCHAR) + ',' 
		+ CAST(@x2 as VARCHAR) +  ' ' 
		+ CAST(@y2 as VARCHAR) + '),' END ;

SELECT CAST('MULTILINESTRING(' + LEFT(@MP,LEN(@MP)-1) + ')' as geometry).STBuffer(0.01);
GO
