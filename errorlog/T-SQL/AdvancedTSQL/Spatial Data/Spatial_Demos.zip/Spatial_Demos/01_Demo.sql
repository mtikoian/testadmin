/*
Demo Script #1

SQL Saturday #440, Pittsburgh

October 3rd, 2015

Get Familiar with Spatial Data. 

Slava Murygin

Basic Spatial Objects and Methods.
*/

/* Draw single Point */
DECLARE @g geometry;
SET @g = geometry::STGeomFromText('POINT(1 1)', 4326);
SELECT @g.STBuffer(0.01), @g.STAsText(); 
GO

/* Draw MultiPoint */
DECLARE @g geometry;
SET @g = geometry::STGeomFromText('MULTIPOINT((0.01 0.01),(0.02 0.02))', 4326);
SELECT @g.STBuffer(0.001), @g.STAsText(); 
GO

/* Draw a Union of Points */
SELECT CAST('POINT(1 1)' as geometry).STBuffer(0.01)
UNION ALL
SELECT CAST('MULTIPOINT((0.1 0.1),(0.2 0.2))' as geometry).STBuffer(0.01)
GO

/* Draw single Line */
DECLARE @g geometry;
SET @g = geometry::STGeomFromText('LINESTRING(0 0, 0 10)', 4326);
SELECT @g, @g.STAsText(); 
GO

/* Draw Union of single Lines - two objects */
SELECT CAST('LINESTRING(0 0, 10 10)' as geometry)
UNION ALL
SELECT CAST('LINESTRING(0 10, 10 0)' as geometry)
GO

/* Draw Multi-Lines - one object */
SELECT CAST('MULTILINESTRING((0 0, 10 10),(0 10, 10 0))' as geometry)

/* Draw CircularString */
DECLARE @g geometry;
SET @g = geometry::STGeomFromText('CIRCULARSTRING(0 0, 0.6 0.3, 1 1)', 4326);
SELECT @g, @g.STAsText(); 
GO

/* Draw CompoundCurve */
DECLARE @g geometry;
SET @g = geometry::STGeomFromText('COMPOUNDCURVE(CIRCULARSTRING(1 1, 0.6 0.3, 0 0), (0 0, 0 1), (0 1, 1 2))', 4326);
SELECT @g, @g.STAsText(); 
GO

/* Draw a Polygon */
DECLARE @g geometry;
SET @g = geometry::STGeomFromText('POLYGON((0 0, 0 10, 10 10, 10 0, 0 0))', 4326);
SELECT @g, @g.STAsText(); 
GO

/* Draw Union of two Polygons */
SELECT CAST('POLYGON((0 0, 0 10, 10 10, 10 0, 0 0))' as geometry)
UNION ALL
SELECT CAST('POLYGON((2 5, 5 8, 8 5, 5 2, 2 5))' as geometry)
GO

/* Draw a MultiPolygon */
DECLARE @g geometry;
SET @g = geometry::STGeomFromText('MULTIPOLYGON(((0 0, 0 10, 10 10, 10 0, 0 0)),((2 5, 5 8, 8 5, 5 2, 2 5)))', 4326);
SELECT @g, @g.STAsText(); 
GO

/* Draw a Collection */
DECLARE @g geometry;
SET @g = geometry::STGeomFromText('GEOMETRYCOLLECTION(POLYGON((0 0, 0 2, 2 2, 2 0, 0 0)), LINESTRING(1 -1, 2 3))', 4326);
SELECT @g, @g.STAsText(); 
GO

/*-----------------------------------------------------------------------------------------------*/
/* Geo Spatial Methods                                                                           */
/*-----------------------------------------------------------------------------------------------*/

/* Example of Invalid LineString and making it Valid*/
DECLARE @g geometry;
SET @g = geometry::STGeomFromText('LINESTRING(0 1, 0 0, 0 1, 1 1)', 0);
SELECT @g as GemetricalFigure, @g.STIsValid() as IsValid, @g.STAsText() as "Well-Known Text";
SET @g = @g.MakeValid();
SELECT @g as GemetricalFigure, @g.STIsValid() as IsValid, @g.STAsText() as "Well-Known Text";
GO

/* Example of Generating Polygons from 0D and 1D objects and making a border around a Polygon */
DECLARE @g geometry;
SET @g = geometry::STGeomFromText('GEOMETRYCOLLECTION(POINT(0 5), LINESTRING(0 0, 2 10), POLYGON((2 0, 2 2, 4 2, 4 0, 2 0)))', 4326);
SELECT @g.STBuffer(0.2) 
UNION ALL
SELECT @g;
GO

/* Example of Generating Polygons from 1D objects */
/* Example of Length, Area, Dimension methods */
DECLARE @g geometry;
SET @g = geometry::STGeomFromText('LINESTRING(0 0, 0 5)', 4326);
SELECT	@g.STBuffer(0.2) as GeometryObject, 
		@g.STDimension() as LineDimension, 
		@g.STBuffer(0.2).STDimension() as ExtendedLineDimension, 
		@g.STBuffer(0.2).STArea() as PolygonArea, 
		@g.STLength() as LineLength, 
		@g.STBuffer(0.2).STLength() as ExtendedLinePerimeter;
GO

/* Example of Merging two Polygons; Getting Center and Boundary of the new object */
DECLARE @g geometry;
DECLARE @h geometry;
SET @g = geometry::STGeomFromText('POLYGON((0 0, 0 10, 10 10, 10 0, 0 0))', 4326);
SET @h = geometry::STGeomFromText('POINT(14 5)', 4326).STBuffer(5);
SET @g = @g.STUnion(@h);
SELECT @g
UNION ALL
SELECT @g.STCentroid().STBuffer(.1);
/* Example of Boundary method */
SELECT @g.STBoundary ( )
UNION ALL
SELECT @g.STCentroid().STBuffer(.1);
/* New Object specifications */
SELECT @g.STArea() as PolygonArea, @g.STLength() as Perimeter, @g.STCentroid().STAsText() as CenterPointText
GO

/* Example of Getting distance between two objects */
DECLARE @g geometry;
DECLARE @h geometry;
SET @g = geometry::STGeomFromText('POLYGON((0 0, 0 10, 10 10, 10 0, 0 0))', 4326);
SET @h = geometry::STGeomFromText('POINT(16 13)', 4326).STBuffer(5);
SELECT @g UNION ALL SELECT @h;
SELECT @g.STDistance(@h);
GO

/* Examples of Intersection & Difference */
DECLARE @g geometry;
DECLARE @h geometry;
SET @g = geometry::STGeomFromText('POLYGON((0 0, 0 10, 10 10, 10 0, 0 0))', 4326);
SET @h = geometry::STGeomFromText('POINT(14 5)', 4326).STBuffer(5);
SELECT @g.STBoundary() UNION ALL SELECT @h.STBoundary()
/* Intersection of two Objects */
SELECT @g.STIntersection(@h);
/* Difference of two Objects */
SELECT @g.STSymDifference(@h);
GO

/* Example of Containing Objects */
DECLARE @g geometry;
DECLARE @h TABLE(g geometry);
SET @g = geometry::STGeomFromText('POLYGON((0 0, 0 10, 10 10, 10 0, 0 0))', 4326);
INSERT INTO @h(g) VALUES(@g);
INSERT INTO @h(g) VALUES(geometry::STGeomFromText('POINT(9 3)', 4326).STBuffer(2));
INSERT INTO @h(g) VALUES(geometry::STGeomFromText('POINT(13 7)', 4326).STBuffer(2));
INSERT INTO @h(g) VALUES(geometry::STGeomFromText('POINT(3 7)', 4326).STBuffer(2));
INSERT INTO @h(g) VALUES(geometry::STGeomFromText('POINT(7 14)', 4326).STBuffer(2));
SELECT g, CASE @g.STContains(g) WHEN 0 THEN 'No' ELSE 'Yes' END as IsContain FROM @h;
GO

/* List of SRIDs */
SELECT * FROM sys.spatial_reference_systems
GO

/* SRID = 4326 */
SELECT * FROM sys.spatial_reference_systems
WHERE spatial_reference_id = 4326;
GO
/*
GEOGCS["WGS 84", 
	DATUM["World Geodetic System 1984", 
		ELLIPSOID["WGS 84", 6378137, 298.257223563]
	], 
	PRIMEM["Greenwich", 0], 
	UNIT["Degree", 0.0174532925199433]
]
*/

/* List of SRIDs - non Metres */
SELECT * FROM sys.spatial_reference_systems
WHERE unit_of_measure != 'metre';
GO

/* SRID - non EPSG */
SELECT * FROM sys.spatial_reference_systems
WHERE authority_name != 'EPSG';
GO

/* List of SRIDs for NAD83 */
SELECT * FROM sys.spatial_reference_systems
WHERE well_known_text like '%NAD83%';
GO
