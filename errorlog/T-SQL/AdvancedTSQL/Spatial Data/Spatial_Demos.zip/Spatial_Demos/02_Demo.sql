/*
Demo Script #2

SQL Saturday #440, Pittsburgh

October 3rd, 2015

Get Familiar with Spatial Data. 

Slava Murygin

Geometry vs Geography.
*/

/* Draw Several figures in both Geometry & Geography */
DECLARE @G Table (WKT VARCHAR(1000));
INSERT INTO @G(WKT) VALUES 
	('MULTIPOINT((0 90),(0 -90),(179 0),(-180 0))'),
	('POLYGON((20 0, 65 45, 20 90, 20 0))'),
	('POLYGON((80 0, 125 45, 80 90, 80 0))'),
	('POLYGON((140 0, 180 40, 140 80, 140 0))'),
	('POLYGON((-60 0, -15 45, -60 90, -60 0))'),
	('POLYGON((-120 0, -75 45, -120 89.9, -120 0))'),
	('POLYGON((-180 0, -135 45, -180 89, -180 0))'),
	('POLYGON((-10 0, 10 0, 10 90, -10 90,  -10 0))');
SELECT geometry::STGeomFromText(WKT, 4326) FROM @G;
SELECT geography::STGeomFromText(WKT, 4326) FROM @G;

/*
Trip from NYC to Seattle:
NYC: 40.638555 -73.750706
Seattle: 47.531159 -122.297659
*/
SELECT geometry::STGeomFromText('LINESTRING(-73.750706 40.638555, -122.297659 47.531159)', 4326)
SELECT geography::STGeomFromText('LINESTRING(-73.750706 40.638555, -122.297659 47.531159)', 4326)
/*
Equirectangular/Robinson -> Bonne
vs
Mercator -> Bonne
*/
UNION ALL
SELECT geography::STGeomFromText('MULTIPOINT((179.999 0),(-180 0))', 4326)
UNION ALL
SELECT geography::STGeomFromText('MULTIPOINT((0 90),(0 -90))', 4326);
GO

/* Different Shapes */
SELECT geography::STGeomFromText('POLYGON((-90 0, 89.99999 0, 0 90, -90 0))', 4326)
UNION ALL
SELECT geography::STGeomFromText('MULTIPOINT((0 90),(120 0),(140 83.5),(0 -90),(45 45),(-60 60),(-80 -80),(179.999 0),(-180 0))', 4326).STBuffer(300000)
UNION ALL
SELECT geography::STGeomFromText('POLYGON((0 -72, 45 -89.9999, 80 -72, 0 -72))', 4326);
