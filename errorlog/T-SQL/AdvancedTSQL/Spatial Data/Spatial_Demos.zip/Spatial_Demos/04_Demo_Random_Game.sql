/*
Demo Script #4

SQL Saturday #440, Pittsburgh

October 3rd, 2015

Get Familiar with Spatial Data. 

Slava Murygin

Drawing Game figures
*/

/* Drawing Squares with Golden ratio */
DECLARE @i FLOAT = 1;
DECLARE @x FLOAT = 0, @y FLOAT = 0;
DECLARE @d TINYINT = 0;
DECLARE @Square VARCHAR(MAX) = '';
DECLARE @inc FLOAT = (1 + SQRT(5)) /2;
DECLARE @Squares TABLE ([Square] GEOMETRY, ID INT IDENTITY(1,1))

WHILE @i <= 100000
BEGIN
  INSERT INTO @Squares([Square])
  SELECT 
	'POLYGON((' + CONVERT(VARCHAR,@x) + ' ' + CONVERT(VARCHAR,@y) + 
	+ ',' + CONVERT(VARCHAR,@x + @i) + ' ' + CONVERT(VARCHAR,@y) + 
	+ ',' + CONVERT(VARCHAR,@x + @i) + ' ' + CONVERT(VARCHAR,@y + @i) + 
	+ ',' + CONVERT(VARCHAR,@x) + ' ' + CONVERT(VARCHAR,@y + @i) + 
	+ ',' + CONVERT(VARCHAR,@x) + ' ' + CONVERT(VARCHAR,@y) + '))';

  SELECT 
	@x = CASE @d 
		WHEN 0 THEN  @x + @i 
		WHEN 1 THEN  @x - @i * (@inc - 1) 
		WHEN 2 THEN  @x - @i * @inc
		WHEN 3 THEN  @x
	END,
	@y = CASE @d 
		WHEN 0 THEN  @y - @i * (@inc - 1) 
		WHEN 1 THEN  @y - @i*@inc 
		WHEN 2 THEN  @y
		WHEN 3 THEN  @y + @i
	END,
	@d = CASE @d WHEN 3 THEN 0 ELSE @d + 1 END

  SET @i *= @inc;
END

SELECT * FROM @Squares
GO

/*-------------------------------------------------------------------------------------------------*/

/* Spiral */

DECLARE @i FLOAT = 0;
DECLARE @inc FLOAT = 0.1;

DECLARE @Spiral VARCHAR(MAX) = '';

WHILE @i <= 100
BEGIN
  SELECT @Spiral += ',' + CONVERT(VARCHAR,COS(@i)*@i) + ' ' + CONVERT(VARCHAR,SIN(@i)*@i), @i += @inc;
END

SELECT CONVERT(GEOMETRY,'LINESTRING(' + SUBSTRING(@Spiral,2,@@TEXTSIZE) + ')')
GO

/*-------------------------------------------------------------------------------------------------*/

/* Random Lines */ 
DECLARE @l FLOAT = 1;
DECLARE @r FLOAT;
DECLARE @x FLOAT = 0, @y FLOAT = 0;
DECLARE @Line VARCHAR(MAX) = '';


DECLARE @i INT = 1;
DECLARE @d TINYINT = 0;
DECLARE @inc FLOAT = (1 + SQRT(5)) /2;

WHILE @i <= 10000
BEGIN
  SELECT @Line += ',' + CONVERT(VARCHAR,@x) + ' ' + CONVERT(VARCHAR,@y)
	, @r = RAND(CAST( CAST(CAST(NEWID() as BINARY(16)) as BIGINT)/ POWER(CAST(2 AS BIGINT),32)  as INT))
	, @x += SIN( 2*PI()*@r)*@l
	, @Y += COS( 2*PI()*@r)*@l
	, @i += 1;
  PRINT CONVERT(VARCHAR,@r)
END

SELECT CONVERT(GEOMETRY,'LINESTRING(' + SUBSTRING(@Line,2,@@TEXTSIZE) + ')')
GO
