USE AdventureWorksDW2014
GO
DECLARE @Square GEOGRAPHY =                       'LINESTRING(-10 -10,10 -10,10 10,-10 10,-10 -10 )';
DECLARE @Circle GEOGRAPHY =                   'CIRCULARSTRING(-10 -10,10 -10,10 10,-10 10,-10 -10 )';
DECLARE @FilledCircle GEOGRAPHY ='CURVEPOLYGON(CIRCULARSTRING(-10 -10,10 -10,10 10,-10 10,-10 -10 ))';
--/*
SELECT @Square as SpatialColumn,@Square.AsBinaryZM() WKB ,'Square' as LabelColumn,@Square.AsTextZM () WKT,@Square.AsGml() GML
UNION ALL
SELECT @Circle as SpatialColumn,@Circle.AsBinaryZM() WKB ,'Circle' as LabelColumn,@Circle.AsTextZM() WKT,@Circle.AsGml() GML
UNION ALL
SELECT @FilledCircle as SpatialColumn,@FilledCircle.AsBinaryZM() WKB ,'FilledCircle' as LabelColumn,@FilledCircle.AsTextZM() WKT,@FilledCircle.AsGml() GML
--*/
GO
/*
SELECT GEOGRAPHY::Parse('CURVEPOLYGON(CIRCULARSTRING(-10 -10,-10 10,10 10,10 -10,-10 -10  ))') as SpatialColumn,'InverseCircle' as LabelColumn

SELECT GEOGRAPHY::Parse('CURVEPOLYGON(CIRCULARSTRING(-10 -10,-10 10,10 10,10 -10,-10 -10  ),CIRCULARSTRING(-20 -20,20 -20,20 20,-20 20,-20 -20))') as SpatialColumn,'Torus' as LabelColumn
--*/
/*
DECLARE @FirstCircle GEOGRAPHY  ='CURVEPOLYGON(CIRCULARSTRING(-10 -10,10 -10,10 10,-10 10,-10 -10 ))';
DECLARE @SecondCircle GEOGRAPHY ='CURVEPOLYGON(CIRCULARSTRING(-0 -10,20 -10,20 10,-0 10,-0 -10 ))';

--SELECT @FirstCircle as SpatialColumn,@FirstCircle.ToString() AS WKT,'Circle 1' as LabelColumn
--union all
--SELECT @SecondCircle as SpatialColumn,@FirstCircle.ToString() AS WKT,'Circle 2' as LabelColumn
--union all
--SELECT @SecondCircle.STUnion (@FirstCircle) as SpatialColumn,@SecondCircle.STUnion (@FirstCircle).ToString() AS WKT,'STUnion' as LabelColumn
--union all
SELECT @SecondCircle.STDifference (@FirstCircle) as SpatialColumn,@SecondCircle.STDifference (@FirstCircle).ToString() AS WKT,'STDifference Circle  2 minus Circle 1' as LabelColumn
union all
SELECT @SecondCircle.STIntersection (@FirstCircle) as SpatialColumn,@SecondCircle.STIntersection (@FirstCircle).ToString() AS WKT,'STIntersection' as LabelColumn
--union all
SELECT @SecondCircle.STSymDifference (@FirstCircle) as SpatialColumn,@SecondCircle.STSymDifference (@FirstCircle).ToString() AS WKT,'STSymDifference' as LabelColumn
union all 
SELECT @SecondCircle.STUnion (@FirstCircle).STConvexHull () as SpatialColumn,@SecondCircle.STUnion (@FirstCircle).STConvexHull ().ToString() AS WKT,'STConvexHull' as LabelColumn
--*/

GO
/*
--Imagine you stand on the North Pole:
-- then at the northern solstice (around 21st of June) the sun will be on a line at  23.44�,
--      at the southern solstice (around 21st of December)                       at -23.44� 
--          and at the equinoxes (around 21st of March and 23rd of September)    at   0�
--Exactly the same picture, but instead of looking on a sphere you look into an (imagined) sphere.
-- Note 0� is now true North, -180� and 180� is true South
--Fill out the gap between the solstices, we get the area where the sun could be over the year
SELECT geography::Parse('CIRCULARSTRING(0   0   , 90   0   ,180   0   , -90  0   ,0   0   )') as SpatialColumn,'Equinox' as LabelColumn
UNION ALL 
SELECT geography::Parse('CIRCULARSTRING(0  23.44, 90  23.44,180  23.44,-90  23.44,0  23.44)') as SpatialColumn,'Northern Solstice' as LabelColumn
UNION ALL 
SELECT geography::Parse('CIRCULARSTRING(0 -23.44, 90 -23.44,180 -23.44,-90 -23.44,0 -23.44)') as SpatialColumn,'Southern Solstice' as LabelColumn
UNION ALL 
SELECT geography::Parse('CURVEPOLYGON(
                          CIRCULARSTRING(0  23.44,-90  23.44,180  23.44, 90  23.44,0  23.44),
						  CIRCULARSTRING(0 -23.44, 90 -23.44,180 -23.44,-90 -23.44,0 -23.44)
						  )') as SpatialColumn,'Sun Band' as LabelColumn;

--*/
/*
--Now we move to another latitude e.g. 45�
SELECT geography::Parse('CIRCULARSTRING(0   -45   , 90   0   ,180   45   , -90  0   ,0   -45   )') as SpatialColumn,'Equinox' as LabelColumn
UNION ALL 
--SELECT geography::Parse('CIRCULARSTRING(0  -45+23.44/sqrt(2), 90-23.44/sqrt(2)  23.44/sqrt(2),0  45+23.44/sqrt(2)....)') as SpatialColumn,'Northern Solstice' as LabelColumn
SELECT geography::Parse('CIRCULARSTRING(0  -21.56, 73.425  16.57,180  68.44, -73.425  16.57,0  -21.56)') as SpatialColumn,'Northern Solstice' as LabelColumn
UNION ALL 
SELECT geography::Parse('CIRCULARSTRING(0 -68.44, 106.575  -16.57,180 21.56,-106.575  -16.57,0 -68.44)') as SpatialColumn,'Southern Solstice' as LabelColumn
UNION ALL 
SELECT geography::Parse('CURVEPOLYGON(
                          CIRCULARSTRING(0 -21.56,-73.425   16.57,180 68.44, 73.425   16.57,0 -21.56),
						  CIRCULARSTRING(0 -68.44,106.575  -16.57,180 21.56,-106.575 -16.57,0 -68.44)
						  )') as SpatialColumn,'Sun Band' as LabelColumn
-- looks nice but what an ugly work to translate coordinates! Is there an easy method to move elements? No, at last nothing builtin so we have to do it ourselves. 
-- CLR? quite likely possible as these are .NET objects or have a .NET object representation in the first place. 
-- Too much effort for a demo, so I'll try in SQL


--*/