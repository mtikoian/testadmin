USE AdventureWorksDW2014
 GO

DECLARE @Equinox		  GEOGRAPHY='CIRCULARSTRING(45   0   , 135   0   ,-135   0   , -45  0   ,45   0   )';
DECLARE @NorthernSolstice GEOGRAPHY='CIRCULARSTRING(45  23.44, 135  23.44,-135  23.44,-45  23.44,45  23.44)';
DECLARE @SouthernSolstice GEOGRAPHY='CIRCULARSTRING(45 -23.44, 135 -23.44,-135 -23.44,-45 -23.44,45 -23.44)';
DECLARE @SunBand GEOGRAPHY=('CURVEPOLYGON(
                          CIRCULARSTRING(45  23.44,-45  23.44,-135  23.44, 135  23.44,45  23.44),
						  CIRCULARSTRING(45 -23.44, 135 -23.44,-135 -23.44,-45 -23.44,45 -23.44)
						  )');

--What of this can we see? Everything above our local horizon. -> See  horizon 1 slide
DECLARE  @Ground geography='CURVEPOLYGON(CIRCULARSTRING(0  2.5,-90  2.5,180  2.5, 90  2.5,0  2.5))'
--SELECT @Ground;
 
 DROP TABLE #temp
 
 DECLARE	@Here GEOGRAPHY='Point( -10.1795 56.1975 65)';
 --DECLARE	@Here GEOGRAPHY='Point( -10.1795 -0 65)';
 --DECLARE	@Here GEOGRAPHY='Point( -10.1795 -56.1975 65)';
 

 
 CREATE TABLE #temp
    (
      GeoObject GEOGRAPHY ,
      ObjectName VARCHAR(255)
    )
--SELECT @Ground;


 INSERT INTO #temp
        ( GeoObject, ObjectName )
 VALUES ( 'CURVEPOLYGON(CIRCULARSTRING(0 2.5 1 2,-45 2.5 1 2,-90 2.5 1 2, -135 2.5 1 2, 180 2.5 1 2, 90 2.5 1 2, 0 2.5 1 2))','Night' ),
        (dbo.TiltGeographyObject(@SunBand,90.0-@Here.Lat),'Sun Band' ),
        (dbo.TiltGeographyObject(@NorthernSolstice,90.0-@Here.Lat),'Northern Solstice' ),
        (dbo.TiltGeographyObject(@Equinox,90.0-@Here.Lat),'Equator'),
        (dbo.TiltGeographyObject(@SouthernSolstice,90.0-@Here.Lat),'Southern Solstice' ),
        (dbo.TiltGeographyObject(@SunBand,90.0-@Here.Lat).STDifference(@Ground),'Daylight'),
		( 'CURVEPOLYGON(CIRCULARSTRING(90 9,  91 10, 90 11, 89 10, 90 9 ))','CPolygon Turbine1' ),
        ( 'CURVEPOLYGON(CIRCULARSTRING(90 10, 91 11, 90 12, 89 11, 90 10))','CPolygon Turbine2' ),
        ( 'CURVEPOLYGON(CIRCULARSTRING(91 10, 92 11, 91 12,  90 11, 91 10))','CPolygon Turbine3' ),
        ( 'CURVEPOLYGON(CIRCULARSTRING(91 9,  92 10, 91 11,  90 10, 91 9 ))','CPolygon Turbine4' )

 DECLARE @g GEOGRAPHY ,
    @h GEOGRAPHY ,
    @i GEOGRAPHY ,
    @j GEOGRAPHY
 SELECT @g = GeoObject
 FROM   #temp
 WHERE  ObjectName LIKE 'CPolygon Turbine1'
 SELECT @h = GeoObject
 FROM   #temp
 WHERE  ObjectName LIKE 'CPolygon Turbine2'
 SELECT @i = GeoObject
 FROM   #temp
 WHERE  ObjectName LIKE 'CPolygon Turbine3'
 SELECT @j = GeoObject
 FROM   #temp
 WHERE  ObjectName LIKE 'CPolygon Turbine4'

--SELECT @g.STIntersection(@h).ToString();
 INSERT INTO #temp	SELECT  @g.STUnion(@h.STUnion(@i.STUnion(@j))).STConvexHull() ,'Turbine on one estate'

 SELECT GeoObject,ObjectName,GeoObject.ToString(),GeoObject.AsGml()
 FROM   #temp
SELECT dbo.TiltGeographyObject(GeoObject,@Here.Lat-90),ObjectName,dbo.TiltGeographyObject(GeoObject,@Here.Lat-90).ToString()
 FROM   #temp

 --SET @h=geography::Parse('LINESTRING(10 -20 1 2,20 15 1 2)')
 --SELECT GeoObject.STIntersection(@h),GeoObject.STIntersection(@h).ToString() FROM #temp WHERE ObjectName='Night'
 --union ALL SELECT GeoObject,GeoObject.ToString() FROM #temp WHERE ObjectName='Night'
 --union ALL SELECT @h,@h.ToString() FROM #temp WHERE ObjectName='Night'
 


 SELECT dbo.TiltGeographyObject(@SunBand,90.0+80).STDifference(@Ground),'-80' AS objectname  UNION ALL 
 SELECT dbo.TiltGeographyObject(@SunBand,90.0-00).STDifference(@Ground),'Equator' AS objectname UNION ALL
 SELECT dbo.TiltGeographyObject(@SunBand,90.0-10).STDifference(@Ground),'10' AS objectname UNION ALL
 SELECT dbo.TiltGeographyObject(@SunBand,90.0-20).STDifference(@Ground),'20' AS objectname UNION ALL
 SELECT dbo.TiltGeographyObject(@SunBand,90.0-30).STDifference(@Ground),'30' AS objectname UNION ALL
 SELECT dbo.TiltGeographyObject(@SunBand,90.0-40).STDifference(@Ground),'40' AS objectname UNION ALL
 SELECT dbo.TiltGeographyObject(@SunBand,90.0-50).STDifference(@Ground),'50' AS objectname UNION ALL
 SELECT dbo.TiltGeographyObject(@SunBand,90.0-60).STDifference(@Ground),'60' AS objectname UNION ALL
 SELECT dbo.TiltGeographyObject(@SunBand,90.0-70).STDifference(@Ground),'70' AS objectname UNION ALL
 SELECT dbo.TiltGeographyObject(@SunBand,90.0-80).STDifference(@Ground),'80' AS objectname UNION ALL
 SELECT dbo.TiltGeographyObject(@SunBand,90.0-90).STDifference(@Ground),'NorthPole' AS objectname 
 SELECT dbo.TiltGeographyObject(@SunBand,90.0-70).STDifference(@Ground).ToString(),'70' AS objectname
 
 SELECT dbo.TiltGeographyObject(@NorthernSolstice,90-10)
 UNION ALL SELECT dbo.TiltGeographyObject(@NorthernSolstice,90-20)
 UNION ALL SELECT dbo.TiltGeographyObject(@NorthernSolstice,90-30)
 UNION ALL SELECT dbo.TiltGeographyObject(@NorthernSolstice,90-45)
 UNION ALL SELECT dbo.TiltGeographyObject(@NorthernSolstice,90-50)
 UNION ALL SELECT dbo.TiltGeographyObject(@NorthernSolstice,90-60)
 UNION ALL SELECT dbo.TiltGeographyObject(@NorthernSolstice,90-70)
 UNION ALL SELECT dbo.TiltGeographyObject(@NorthernSolstice,90-80)
 UNION ALL SELECT dbo.TiltGeographyObject(@NorthernSolstice,90-85)
 UNION ALL SELECT dbo.TiltGeographyObject(@NorthernSolstice,90+10)
 UNION ALL SELECT dbo.TiltGeographyObject(@NorthernSolstice,90+20)
 UNION ALL SELECT dbo.TiltGeographyObject(@NorthernSolstice,90+30)
 UNION ALL SELECT dbo.TiltGeographyObject(@NorthernSolstice,90+45)
 UNION ALL SELECT dbo.TiltGeographyObject(@NorthernSolstice,90+50)
 UNION ALL SELECT dbo.TiltGeographyObject(@NorthernSolstice,90+60)
 UNION ALL SELECT dbo.TiltGeographyObject(@NorthernSolstice,90+70)
 UNION ALL SELECT dbo.TiltGeographyObject(@NorthernSolstice,90+80)
SELECT dbo.TiltGeographyObject(@SouthernSolstice,90-10)
 UNION ALL SELECT dbo.TiltGeographyObject(@SouthernSolstice,90-20)
 UNION ALL SELECT dbo.TiltGeographyObject(@SouthernSolstice,90-30)
 UNION ALL SELECT dbo.TiltGeographyObject(@SouthernSolstice,90-45)
 UNION ALL SELECT dbo.TiltGeographyObject(@SouthernSolstice,90-50)
 UNION ALL SELECT dbo.TiltGeographyObject(@SouthernSolstice,90-60)
 UNION ALL SELECT dbo.TiltGeographyObject(@SouthernSolstice,90-70)
 UNION ALL SELECT dbo.TiltGeographyObject(@SouthernSolstice,90-80)
SELECT dbo.TiltGeographyObject(@Equinox,90-90),'NorthPole' AS objectname
UNION ALL SELECT dbo.TiltGeographyObject(@Equinox,90-80),'80' AS objectname
UNION ALL SELECT dbo.TiltGeographyObject(@Equinox,90-70),'70'
UNION ALL SELECT dbo.TiltGeographyObject(@Equinox,90-60),'60' AS objectname
UNION ALL SELECT dbo.TiltGeographyObject(@Equinox,90-50),'50' AS objectname
UNION ALL SELECT dbo.TiltGeographyObject(@Equinox,90-40),'40' AS objectname
UNION ALL SELECT dbo.TiltGeographyObject(@Equinox,90-30),'30' AS objectname
UNION ALL SELECT dbo.TiltGeographyObject(@Equinox,90-20),'20' AS objectname
UNION ALL SELECT dbo.TiltGeographyObject(@Equinox,90-10),'10' AS objectname
UNION ALL SELECT dbo.TiltGeographyObject(@Equinox,90-00.0000),'Equator' AS objectname
UNION ALL SELECT dbo.TiltGeographyObject(@Equinox,90+90),'SouthPole' AS objectname
UNION ALL SELECT dbo.TiltGeographyObject(@Equinox,90+80),'-80' AS objectname
UNION ALL SELECT dbo.TiltGeographyObject(@Equinox,90+70),'-70' AS objectname
UNION ALL SELECT dbo.TiltGeographyObject(@Equinox,90+60),'-60' AS objectname
UNION ALL SELECT dbo.TiltGeographyObject(@Equinox,90+50),'-50' AS objectname
UNION ALL SELECT dbo.TiltGeographyObject(@Equinox,90+40),'-40' AS objectname
UNION ALL SELECT dbo.TiltGeographyObject(@Equinox,90+30),'-30' AS objectname
UNION ALL SELECT dbo.TiltGeographyObject(@Equinox,90+20),'-20' AS objectname
UNION ALL SELECT dbo.TiltGeographyObject(@Equinox,90+10),'-10' AS objectname


