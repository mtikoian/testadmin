use AdventureWorksDW2014
go
-- some astronomy---------------------
IF OBJECT_ID(N'dbo.GetSunElevation', N'FN') IS NOT NULL
    DROP FUNCTION dbo.GetSunElevation;
GO
CREATE FUNCTION dbo.GetSunElevation(@TimeUtc DATETIME)
    
RETURNS FLOAT
AS
BEGIN
--https://en.wikipedia.org/wiki/Position_of_the_Sun
	DECLARE @FirstJan DATETIME = FORMAT(@TimeUtc,'yyyy-01-01 00:00:00');
	DECLARE @DayFrom1Jan FLOAT = DATEDIFF(s,@FirstJan,@TimeUtc)/3600.0/24.0;
	Declare @W FLOAT=360.0/365.24
	Declare @A FLOAT=@W*(@DayFrom1Jan+10.0)
	Declare @B FLOAT=@A+1.914*SIN(RADIANS(@W*(@DayFrom1Jan-2.0)))
--In reality every year starts not exactly 10 days after December solstice, but this is not implemented here
	RETURN -DEGREES(ASIN( SIN(RADIANS(23.44))*COS( RADIANS(@B)) ));
	--https://en.wikipedia.org/wiki/Position_of_the_Sun
	--https://en.wikipedia.org/wiki/Perihelion_and_aphelion
	
END
GO
--well mostly geometry again
IF OBJECT_ID(N'dbo.GetSunPath') IS NOT NULL
    DROP FUNCTION dbo.GetSunPath;
GO
CREATE FUNCTION dbo.GetSunPath
    (
      @BeginOfYear DATE ,
      @Longitude FLOAT
    )
RETURNS @output TABLE
    (
      Position GEOGRAPHY ,
      [DayofYear] DATE
    )
AS
    BEGIN
        DECLARE @DayDiff INT ,
            @i INT= 0 ,
            @DateTimeUTC DATETIME=@BeginOfYear;
        SELECT  @DayDiff = DATEDIFF(DAY, @BeginOfYear,DATEADD(YEAR, 1, @BeginOfYear));
        WHILE @i < @DayDiff
            BEGIN
                SELECT  @DateTimeUTC = DATEADD(MILLISECOND, -@Longitude * 240*1000,DATEADD(day,@i,CAST(@BeginOfYear AS DATETIME)));--15� East equals UTC is 1h less, 1�<-> 1/15 h=240s=240000ms
                DECLARE @PathString VARCHAR(255) = 'CIRCULARSTRING(';
                SET @PathString = @PathString + '-180 '+ FORMAT(dbo.GetSunElevation(DATEADD(HOUR, -12, @DateTimeUTC)), 'N18','en-US');
                SET @PathString = @PathString + ', ';
                SET @PathString = @PathString + '-90 '+ FORMAT(dbo.GetSunElevation(DATEADD(HOUR, -6,@DateTimeUTC)), 'N18','en-US');
                SET @PathString = @PathString + ', ';
                SET @PathString = @PathString + '0 '+ FORMAT(dbo.GetSunElevation(DATEADD(HOUR, 0, @DateTimeUTC)),'N18', 'en-US');
                SET @PathString = @PathString + ', ';
                SET @PathString = @PathString + '90 ' + FORMAT(dbo.GetSunElevation(DATEADD(HOUR, 6, @DateTimeUTC)),'N18', 'en-US');
                SET @PathString = @PathString + ', ';
                SET @PathString = @PathString + '180 '+ FORMAT(dbo.GetSunElevation(DATEADD(HOUR, 12,@DateTimeUTC)), 'N18','en-US');
                SET @PathString = @PathString + ')';
                INSERT  INTO @output
                        SELECT  Geography::Parse(@PathString) ,DATEADD(day,@i,@BeginOfYear);
                SET @i = @i + 1;
            END;
        RETURN; 
    END;
GO

IF OBJECT_ID(N'dbo.EquationOfTime') IS NOT NULL
    DROP FUNCTION dbo.EquationOfTime;
GO
 CREATE FUNCTION dbo.EquationOfTime
    (
       @DayOfYear DATETIME
    )
RETURNS FLOAT
 AS
    BEGIN
		DECLARE @FirstJan DATETIME = FORMAT(@DayOfYear,'yyyy-01-01 00:00:00');
		DECLARE @DayFrom1Jan FLOAT = DATEDIFF(s,@FirstJan,@DayOfYear)/3600.0/24.0;

		Declare @W FLOAT=360.0/365.24
		Declare @A FLOAT=@W*(@DayFrom1Jan+10.0)
		Declare @B FLOAT=@A+1.914*SIN(RADIANS(@W*(@DayFrom1Jan-2.0)))


		DECLARE @C FLOAT=(@A-DEGREES(ATAN(TAN( RADIANS(@B))/COS(RADIANS(23.44)))))/180.0;
/*--https://en.wikipedia.org/wiki/Equation_of_time*/
	      RETURN 720.0*(@C-ROUND(@C,0));
    END;
GO
GO

IF OBJECT_ID(N'dbo.TimeFromLongitude') IS NOT NULL
    DROP FUNCTION dbo.TimeFromLongitude;
GO
 CREATE FUNCTION dbo.TimeFromLongitude
    (
      @Longitude FLOAT ,
      @DayOfYear DATETIME ,
      @RefLongitude FLOAT
    )
RETURNS DATETIME
 AS
        BEGIN
            RETURN DATEADD(MILLISECOND,(IIF(@Longitude<0,@Longitude+360,@Longitude)-@RefLongitude)*240000.0-dbo.EquationOfTime(@DayOfYear)*60000.0,CAST(CAST(@DayOfYear AS DATE) AS DATETIME));
        END;
GO

DECLARE @Equinox		  GEOGRAPHY='CIRCULARSTRING(45   0   , 135   0   ,-135   0   , -45  0   ,45   0   )';
DECLARE @NorthernSolstice GEOGRAPHY='CIRCULARSTRING(45  23.44, 135  23.44,-135  23.44,-45  23.44,45  23.44)';
DECLARE @SouthernSolstice GEOGRAPHY='CIRCULARSTRING(45 -23.44, 135 -23.44,-135 -23.44,-45 -23.44,45 -23.44)';
DECLARE  @Ground geography='CURVEPOLYGON(CIRCULARSTRING(0  -0.045,-90  -0.045,180  -0.045, 90  -0.045,0  -0.045))'
--/*
DECLARE @SunBand GEOGRAPHY=('CURVEPOLYGON(
                          CIRCULARSTRING(45  23.44,-45  23.44,-135  23.44, 135  23.44,45  23.44),
						  CIRCULARSTRING(45 -23.44, 135 -23.44,-135 -23.44,-45 -23.44,45 -23.44)
						  )');

--What of this can we see? Everything above our local horizon. -> See  horizon 1 slide
DECLARE @Tilt FLOAT=0
--SET @Tilt=90-90--North Pole
--SET @Tilt=90-66.56--Polar Circle
--SET @Tilt=90-23.44--Tropic of Cancer
--SET @Tilt=90-0    --Equator
--SET @Tilt=90-(-23.44)--Tropic of Capricorn
--SET @Tilt=90-(-90) --SouthPole
SET @Tilt=90-55.726957--Tuborg Blvd. 12
--We can even show the daily path of the sun at any point of the earth
SELECT dbo.TiltGeographyObject(@NorthernSolstice,@Tilt)as SpatialColumn,'Northern Solstice' as LabelColumn
UNION ALL 
SELECT dbo.TiltGeographyObject(@Equinox,@Tilt)as SpatialColumn,'Equinox' as LabelColumn
UNION ALL
SELECT dbo.TiltGeographyObject(@SouthernSolstice,@Tilt)as SpatialColumn,'Southern Solstice' as LabelColumn
UNION ALL 
SELECT dbo.TiltGeographyObject(Position,@Tilt)--tilt to the proper latitude
		.STDifference(@Ground)as SpatialColumn,CAST([DayOfYear] as varchar(20)) as LabelColumn 
FROM dbo.GetSunPath('2015', 10.181168)--select the correct year (doesn't matter actually) and longitude
--*/


--But which days? We get the paths of the sun over the year combined with the mask for daylight from the previous example 
 --/*
drop table #ShadowedPoints
drop table #Turbines
drop table #Shadows
drop table #SunPath
drop table #PolarShadowEvents;


SELECT * INTO #Turbines  FROM (
 SELECT 'Turbine 1' AS Turbine,  geography::Parse('POINT ( 12.620401 55.697775 100 82)' ) GeoObject
 UNION ALL 
 SELECT 'Turbine 3' AS Turbine,  geography::Parse('POINT ( 12.625319 55.697486 100 82)' ) GeoObject
 UNION ALL 
 SELECT 'Turbine 5' AS Turbine,  geography::Parse('POINT ( 12.629272 55.697232 100 82)' ) GeoObject
 UNION ALL 
 SELECT 'Turbine 7' AS Turbine,  geography::Parse('POINT ( 12.630111 55.695035 100 82)' ) GeoObject
  ) d 	


CREATE TABLE #ShadowedPoints(
	  ShadowedPointID INTEGER IDENTITY(1,1)  ,
      GeoObject GEOGRAPHY ,
      ObjectName VARCHAR(255)
    ) 
 
 INSERT INTO #ShadowedPoints( ObjectName ,GeoObject)
 SELECT  'Microsoft Danmark ApS' ,Geography::Parse('POINT(12.580864 55.726957 10 50)')--4km 144deg

 INSERT INTO #ShadowedPoints( ObjectName ,GeoObject)
 SELECT  'Havfrue Park' ,Geography::Parse('MULTIPOINT(
 (12.599720 55.693279 3 1),
 (12.598873 55.693133 3 1),
 (12.599742 55.691009 3 1),
 (12.598406 55.689747 3 1)
 )')
 DECLARE @ReferencePoint GEOGRAPHY
 SELECT TOP 1 @ReferencePoint = GeoObject FROM #ShadowedPoints


  SELECT dbo.ProjectTurbine(i.GeoObject, t.GeoObject, .25) Shadow ,
        t.Turbine ,
        i.ObjectName ShadowedPointName,i.ShadowedPointID
 INTO #Shadows 
 FROM   #Turbines t    
 CROSS  JOIN #ShadowedPoints i


 --But which days? We get the paths of the sun over the year combined with the mask for daylight from the previous example 

-- /*
 SELECT --cut away everything under the horizon
		dbo.TiltGeographyObject(Position,90.0-@ReferencePoint.Lat)--tilt to the proper latitude
		.STDifference(@Ground)as DailySunPath,CAST([DayOfYear] as varchar(20)) as [DayOfYear] 
INTO #SunPath
FROM dbo.GetSunPath('2015', @ReferencePoint.Long)--select the correct year (doesn't matter actually) and longitude
SELECT sp.DailySunPath.STIntersection(s.Shadow) ShadowedDay
      ,Shadow
	  ,Turbine
	  ,ShadowedPointName
	  ,ShadowedPointID
	  ,DailySunPath
	  ,[DayOfYear] 
	  FROM #Shadows s 
	  CROSS JOIN #SunPath sp 
	  WHERE sp.DailySunPath.STIntersects(s.Shadow)=1 
	  ORDER BY [DayOfYear],Turbine
 --*/
 --/*
 -- now tilt the column ShadowedDay back to the polar system. Why? You'll see.
SELECT sp.DailySunPath.STIntersection(s.Shadow) ShadowedDay ,dbo.TiltGeographyObject(sp.DailySunPath.STIntersection(s.Shadow),@ReferencePoint.Lat-90.0) ShadowedDayCelestielCoordinates
	  ,Turbine
	  ,ShadowedPointName
	  ,ShadowedPointID
	  ,[DayOfYear] 
	  INTO #PolarShadowEvents FROM #Shadows s 
	  CROSS JOIN #SunPath sp WHERE sp.DailySunPath.STIntersects(s.Shadow)=1 
	  ORDER BY [DayOfYear],Turbine

--Now the longitude of the linestart marks the beginning of the shadow event, and the end of the line the end of the event respectively

SELECT ShadowedDay,ShadowedDayCelestielCoordinates,
	Turbine,ShadowedPointName
	,dbo.TimeFromLongitude(ShadowedDayCelestielCoordinates.STStartPoint().Long,[DayOfYear],@ReferencePoint.Long) ShadowEnterTimeUTC
	,dbo.TimeFromLongitude(ShadowedDayCelestielCoordinates.STEndPoint().Long ,[DayOfYear],@ReferencePoint.Long) ShadowExitTimeUTC
	FROM #PolarShadowEvents
	ORDER BY [DayOfYear],ShadowedDayCelestielCoordinates.STStartPoint().Long
	--*/