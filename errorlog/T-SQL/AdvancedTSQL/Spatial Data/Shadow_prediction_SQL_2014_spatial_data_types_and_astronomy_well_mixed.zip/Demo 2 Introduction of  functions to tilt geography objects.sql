use AdventureWorksDW2014
go
-- a bit of (spherical) geometry---
IF OBJECT_ID(N'dbo.TiltGMLObject', N'FN') IS NOT NULL
    DROP FUNCTION dbo.TiltGMLObject;
GO
CREATE FUNCTION dbo.TiltGMLObject
    (
      @GMl XML ,
      @Tilt FLOAT
    )
RETURNS XML
AS
    BEGIN
	DECLARE @InString VARCHAR(MAX)= CAST(@GMl as varchar(max)) ,
		@PosListString VARCHAR(MAX)= '' ,
		@OutString VARCHAR(MAX)= '';
	DECLARE @posListPos BIGINT = 0,@spacepos int;
	DECLARE @OldLongitude FLOAT,@OldLatitude FLOAT;
	DECLARE @NewLongitude FLOAT,@NewLatitude FLOAT;

	SET @Tilt = RADIANS(@Tilt);
	SET @posListPos = PATINDEX('%posList%', @InString);
	WHILE @posListPos > 0
		BEGIN
			SET @OutString = @OutString + SUBSTRING(@InString, 1, @posListPos - 2);
			SET @InString = SUBSTRING(@InString, @posListPos - 1, LEN(@InString));
			SET @PosListString = SUBSTRING(@InString, 1,PATINDEX('%/posList%', @InString) + 8);
			SET @InString = REPLACE(@InString, @PosListString, '');
			SET @PosListString = LTRIM(REPLACE(REPLACE(@PosListString,'<posList>',''),'</posList>',''))+' ';
			SET @OutString = @OutString + '<posList>';     
			WHILE LEN(@PosListString)>0
			BEGIN
				SET @spacepos      = charindex(' ',@PosListString);
				SET @OldLatitude   = RADIANS(try_cast(LEFT(@PosListString,@spacepos) as float))
				SET @PosListString = LTRIM(RIGHT(@PosListString,LEN(@PosListString)-@spacepos+1))
	      
				SET @spacepos      = charindex(' ',@PosListString);
				SET @OldLongitude  = RADIANS(try_cast(substring(@PosListString,1,@spacepos) as float) )
				SET @PosListString = LTRIM(RIGHT(@PosListString,LEN(@PosListString)-@spacepos+1))
		
				SET @NewLatitude    = COS(@Tilt) * SIN(@OldLatitude) - SIN(@Tilt) * COS(@OldLatitude) * COS(@OldLongitude);
				SELECT @NewLatitude = IIF(@NewLatitude> 1,1,IIF(@NewLatitude<-1,-1,@NewLatitude));
				SET @NewLatitude    = ASIN(@NewLatitude);
				SET @NewLongitude   = ATN2(SIN(@OldLongitude),COS(@Tilt) * COS(@OldLongitude)+SIN(@Tilt)*TAN(@OldLatitude));

				SELECT  @OutString = @OutString+FORMAT(DEGREES(@NewLatitude),'N18','en-US')+ ' ' +FORMAT(DEGREES(@NewLongitude),'N18','en-US')+' ';
			END
			SET @OutString = @OutString + '</posList>';     
			SELECT  @posListPos = PATINDEX('%posList%', @InString);
		END;
	RETURN @OutString + @InString
    END

go
/*
<PolygonPatch xmlns="http://www.opengis.net/gml">
  <exterior>
    <Ring>
      <curveMember>
        <ArcString>
          <posList>-21.56 0 16.57 -73.425 68.44 180 16.57 73.425 -21.56 0</posList>
        </ArcString>
      </curveMember>
    </Ring>
  </exterior>
  <interior>
    <Ring>
      <curveMember>
        <ArcString>
          <posList>-68.44 0 -16.57 106.575 21.56 180 -16.57 -106.575 -68.44 0</posList>
        </ArcString>
      </curveMember>
    </Ring>
  </interior>
</PolygonPatch>'
*/
/*
<ArcString xmlns="http://www.opengis.net/gml">
  <posList>-21.56 0 16.57 -73.425 68.44 180 16.57 73.425 -21.56 0</posList>
</ArcString>
*/
IF OBJECT_ID(N'dbo.TiltGeographyObject', N'FN') IS NOT NULL
    DROP FUNCTION dbo.TiltGeographyObject;
GO
CREATE FUNCTION dbo.TiltGeographyObject
    (
      @GeographyObject GEOGRAPHY ,
      @Tilt FLOAT
    )
RETURNS GEOGRAPHY
AS
    BEGIN
	     RETURN GEOGRAPHY::GeomFromGml(dbo.TiltGMLObject(@GeographyObject.AsGml(),@Tilt), @GeographyObject.STSrid);
    END

go

DECLARE @Equinox		  GEOGRAPHY='CIRCULARSTRING(45   0   , 135   0   ,-135   0   , -45  0   ,45   0   )';
DECLARE @NorthernSolstice GEOGRAPHY='CIRCULARSTRING(45  23.44, 135  23.44,-135  23.44,-45  23.44,45  23.44)';
DECLARE @SouthernSolstice GEOGRAPHY='CIRCULARSTRING(45 -23.44, 135 -23.44,-135 -23.44,-45 -23.44,45 -23.44)';
DECLARE @SunBand GEOGRAPHY=('CURVEPOLYGON(
                          CIRCULARSTRING(45  23.44,-45  23.44,-135  23.44, 135  23.44,45  23.44),
						  CIRCULARSTRING(45 -23.44, 135 -23.44,-135 -23.44,-45 -23.44,45 -23.44)
						  )');

--What of this can we see? Everything above our local horizon. -> See  horizon 1 slide
DECLARE  @Ground geography='CURVEPOLYGON(CIRCULARSTRING(0  -0.045,-90  -0.045,180  -0.045, 90  -0.045,0  -0.045))'
--SELECT @Ground;
DECLARE @Tilt FLOAT=0
SET @Tilt=90-90--North Pole
SET @Tilt=90-66.56--Polar Circle
SET @Tilt=90-23.44--Tropic of Cancer
SET @Tilt=90-0    --Equator
SET @Tilt=90-(-23.44)--Tropic of Capricorn
--SET @Tilt=90-(-90) --SouthPole
SET @Tilt=90-55.726957--Tuborg Blvd. 12
--/*
SELECT dbo.TiltGeographyObject(@NorthernSolstice,@Tilt)as SpatialColumn,'Northern Solstice' as LabelColumn
UNION ALL 
SELECT dbo.TiltGeographyObject(@Equinox,@Tilt)as SpatialColumn,'Equinox' as LabelColumn
UNION ALL
SELECT dbo.TiltGeographyObject(@SouthernSolstice,@Tilt)as SpatialColumn,'Southern Solstice' as LabelColumn
UNION ALL 
SELECT dbo.TiltGeographyObject(@SunBand,@Tilt).STDifference(@Ground) as SpatialColumn,'Sun above horizon (aka "day")' as LabelColumn
--*/


--That was all about sky , horizon and sun? Where does the turbine come in?