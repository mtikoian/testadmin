USE AdventureWorksDW2014
GO
IF OBJECT_ID(N'dbo.ProjectTurbine', N'FN') IS NOT NULL
    DROP FUNCTION dbo.ProjectTurbine;
GO
CREATE FUNCTION dbo.ProjectTurbine
    (
      @Reference GEOGRAPHY ,
      @Turbine GEOGRAPHY ,
      @SunRadius FLOAT 
    )
RETURNS GEOGRAPHY
AS
    BEGIN
        DECLARE @TurbinePictureString VARCHAR(max) ,
            @ReturnPicture GEOGRAPHY ='GEOMETRYCOLLECTION EMPTY',
            @Distance FLOAT ,
            @Azimuth FLOAT ,
            @Altitude FLOAT ,
            @Radius FLOAT ,
            @PointNumber INT= 1,
			@Arc float ;
        IF @Reference IS NULL
            RETURN NULL;
        IF @Turbine IS NULL
            RETURN NULL;

        IF @Reference.STGeometryType() <> 'Point'
            AND @Reference.STGeometryType() <> 'MultiPoint'
            RETURN NULL
		WHILE @PointNumber <= @Reference.STNumPoints()
            BEGIN
				SET @Distance = @Turbine.STDistance(@Reference.STPointN(@PointNumber));
				set @Arc=DEGREES(@Distance/6371000);
                SET @Azimuth = DEGREES(ATN2(COS(RADIANS( @Turbine.Lat))*( @Turbine.Long - @Reference.STPointN(@PointNumber).Long ),
                                            @Turbine.Lat - @Reference.STPointN(@PointNumber).Lat));
				--SET @Azimuth = DEGREES(ATN2(
				--SIN(RADIANS(@Turbine.Long - @Reference.STPointN(@PointNumber).Long)),
				--COS(RADIANS(@Reference.STPointN(@PointNumber).Lat))*TAN(RADIANS(@Turbine.Lat))-SIN(RADIANS(@Reference.STPointN(@PointNumber).Lat))*COS(RADIANS(@Turbine.Long - @Reference.STPointN(@PointNumber).Long))
				--));--https://en.wikipedia.org/wiki/Great-circle_navigation

			   SET @Altitude = 0;
                IF @Turbine.HasZ = 1 AND @Reference.STPointN(@PointNumber).HasZ = 1
				BEGIN
                   SET @Altitude = DEGREES(ATN2(@Turbine.Z - @Reference.STPointN(@PointNumber).Z,@Distance))-(@arc)/2.0
				   SET @Distance =SQRT(@Distance*@Distance+(@Turbine.Z - @Reference.STPointN(@PointNumber).Z)*(@Turbine.Z - @Reference.STPointN(@PointNumber).Z));
				END
                    
                
                SET @Radius = 0;
                IF @Turbine.HasM = 1
                    SET @Radius = @Radius + @Turbine.M;
                IF @Reference.STPointN(@PointNumber).HasM = 1
                    SET @Radius = @Radius + @Reference.STPointN(@PointNumber).M;
				SET @Radius=DEGREES(ASIN(@Radius/@Distance))+@SunRadius;

                IF(@Radius>0)
				BEGIN
					SELECT  @TurbinePictureString = 'CircularString( ';
					SELECT  @TurbinePictureString = @TurbinePictureString +     FORMAT(@Azimuth- @Radius,'N18', 'en-US') + ' ' + FORMAT(@Altitude,'N18', 'en-US');
					SELECT  @TurbinePictureString = @TurbinePictureString + ','+FORMAT(@Azimuth,'N18', 'en-US') + ' ' + FORMAT(@Altitude- @Radius,'N18', 'en-US');
					SELECT  @TurbinePictureString = @TurbinePictureString + ','+FORMAT(@Azimuth+ @Radius,'N18', 'en-US') + ' ' + FORMAT(@Altitude,'N18', 'en-US');
					SELECT  @TurbinePictureString = @TurbinePictureString + ','+FORMAT(@Azimuth,'N18', 'en-US') + ' ' + FORMAT(@Altitude+ @Radius,'N18', 'en-US');
					SELECT  @TurbinePictureString = @TurbinePictureString + ','+FORMAT(@Azimuth- @Radius,'N18', 'en-US') + ' ' + FORMAT(@Altitude,'N18', 'en-US')+ ')';
					SET @ReturnPicture = @ReturnPicture.STUnion(geography::Parse(@TurbinePictureString));
				END
				SET @PointNumber = @PointNumber + 1;
            END
    RETURN @ReturnPicture.STConvexHull()
    END
GO

drop table #ShadowedPoints
drop table #Turbines
drop table #Shadows

SELECT * INTO #Turbines  FROM (
 SELECT 'Turbine 1' AS Turbine,  geography::Parse('POINT ( 12.620401 55.697775 100 82)' ) GeoObject
 UNION ALL 
 --SELECT 'Turbine 2' AS Turbine,  geography::Parse('POINT ( 12.622401 55.697666 100 82)' ) GeoObject
 --UNION ALL 
 SELECT 'Turbine 3' AS Turbine,  geography::Parse('POINT ( 12.625319 55.697486 100 82)' ) GeoObject
 UNION ALL 
 --SELECT 'Turbine 4' AS Turbine,  geography::Parse('POINT ( 12.627357 55.697364 100 82)' ) GeoObject
 --UNION ALL 
 SELECT 'Turbine 5' AS Turbine,  geography::Parse('POINT ( 12.629272 55.697232 100 82)' ) GeoObject
 UNION ALL 
 --SELECT 'Turbine 6' AS Turbine,  geography::Parse('POINT ( 12.629722 55.696131 100 82)' ) GeoObject
 --UNION ALL 
 SELECT 'Turbine 7' AS Turbine,  geography::Parse('POINT ( 12.630111 55.695035 100 82)' ) GeoObject
  ) d 	


/*
55.697775, 12.620401 Turbine 1
55.697666, 12.622401 Turbine 2
55.697486, 12.625319 Turbine 3
55.697364, 12.627357 Turbine 4
55.697232, 12.629272 Turbine 5
55.696131, 12.629722 Turbine 6
55.695035, 12.630111 Turbine 7

55.726957, 12.580864 Microsoft Danmark ApS

55.692878, 12.599284 den lille havfrue

55.693279, 12.599720
55.693133, 12.598873
55.691009, 12.599742
55.689747, 12.598406
*/

CREATE TABLE #ShadowedPoints(
	  ShadowedPointID INTEGER IDENTITY(1,1)  ,
      GeoObject GEOGRAPHY ,
      ObjectName VARCHAR(255)
    ) 
 
 INSERT INTO #ShadowedPoints( ObjectName ,GeoObject)
 SELECT  'Microsoft Danmark ApS' ,Geography::Parse('POINT(12.580864 55.726957 10 50)')--4km 144deg

 INSERT INTO #ShadowedPoints( ObjectName ,GeoObject)
 SELECT  'Havfrue Park' ,Geography::Parse('MULTIPOINT(
 (12.599720 55.693279 3 1),
 (12.598873 55.693133 3 1),
 (12.599742 55.691009 3 1),
 (12.598406 55.689747 3 1)
 )')
 DECLARE @ReferencePoint GEOGRAPHY
 SELECT TOP 1 @ReferencePoint = GeoObject FROM #ShadowedPoints


  SELECT dbo.ProjectTurbine(i.GeoObject, t.GeoObject, .25) Shadow ,
        t.Turbine ,
        i.ObjectName ShadowedPointName,i.ShadowedPointID
 INTO #Shadows FROM   #Turbines t    CROSS  JOIN #ShadowedPoints i

DECLARE @SunBand GEOGRAPHY=('CURVEPOLYGON(
                          CIRCULARSTRING(45  23.44,-45  23.44,-135  23.44, 135  23.44,45  23.44),
						  CIRCULARSTRING(45 -23.44, 135 -23.44,-135 -23.44,-45 -23.44,45 -23.44)
						  )');
DECLARE @Ground GEOGRAPHY='CURVEPOLYGON(CIRCULARSTRING(0  -0.045,-90  -0.045,180  -0.045, 90  -0.045,0  -0.045))'
SET @SunBand = dbo.TiltGeographyObject(@SunBand,90-@ReferencePoint.Lat).STDifference(@Ground);



SELECT @SunBand as SpatialColumn,'Sun above horizon (aka "day")' as LabelColumn, 'Day' as Name
UNION ALL
SELECT Shadow,Turbine,ShadowedPointName
FROM #Shadows
 --we can see that in the winter mornings the turbine will shadow the Microsoft building, also note they appear low as the buliding is high
 --and in the morning hours in summer they shadow the park around the small mermaid
 


 --But which days? We get the paths of the sun over the year combined with the mask for daylight from the previous example 
 /*
 SELECT --cut away everything under the horizon
		dbo.TiltGeographyObject(Position,90.0-@ReferencePoint.Lat)--tilt to the proper latitude
		.STDifference(@Ground)as DailySunPath,CAST([DayOfYear] as varchar(20)) as [DayOfYear] 
INTO #SunPath
FROM dbo.GetSunPath('2015', @ReferencePoint.Long)--select the correct year (doesn't matter actually) and longitude
SELECT sp.DailySunPath.STIntersection(s.Shadow) ShadowedDay
      ,Shadow
	  ,Turbine
	  ,ShadowedPointName
	  ,ShadowedPointID
	  ,DailySunPath
	  ,[DayOfYear] 
	  FROM #Shadows s 
	  CROSS JOIN #SunPath sp 
	  WHERE sp.DailySunPath.STIntersects(s.Shadow)=1 
	  ORDER BY [DayOfYear],Turbine
 
 -- now tilt the column ShadowedDay back to the polar system. Why? You'll see.
SELECT dbo.TiltGeographyObject(sp.DailySunPath.STIntersection(s.Shadow),@ReferencePoint.Lat-90.0) ShadowedDay
	  ,Turbine
	  ,ShadowedPointName
	  ,ShadowedPointID
	  ,[DayOfYear] 
	  INTO #PolarShadowEvents FROM #Shadows s 
	  CROSS JOIN #SunPath sp WHERE sp.DailySunPath.STIntersects(s.Shadow)=1 
	  ORDER BY [DayOfYear],Turbine

--Now the longitude of the linestart marks the beginning of the shadow event, and the end of the line the end of the event respectively

SELECT ShadowedDay,
	Turbine,ShadowedPointName
	,dbo.TimeFromLongitude(ShadowedDay.STStartPoint().Long,[DayOfYear],@ReferencePoint.Long) ShadowEnterTimeUTC
	,dbo.TimeFromLongitude(ShadowedDay.STEndPoint().Long ,[DayOfYear],@ReferencePoint.Long) ShadowExitTimeUTC
	FROM #PolarShadowEvents
	ORDER BY [DayOfYear],ShadowedDay.STStartPoint().Long
	--*/