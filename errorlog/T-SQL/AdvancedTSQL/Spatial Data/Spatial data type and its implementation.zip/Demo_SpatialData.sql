
----------------------------------------D E M O  1--------------------------------------------------------------------------------------
declare @point geometry ='POINT(5 3)'
select @point
go
declare @LineStrings geometry  = 'LINESTRING(2 3,4 6 ,6 6 , 10 4)'
select @LineStrings
go
DECLARE @CircularString1 geometry = 'CIRCULARSTRING (1 3, 4 1, 9 4)';
select @CircularString1
go
DECLARE @Compoundcurve geometry ='COMPOUNDCURVE( (2 3, 2 8), CIRCULARSTRING(2 8, 4 10, 6 8), (6 8, 6 3), CIRCULARSTRING(6 3, 4 1, 2 3) ) '
select @Compoundcurve
go

DECLARE @Polygon geometry ='POLYGON((10 1, 10 9, 4 9, 10 1), (9 4, 9 8, 6 8, 9 4),(1 1, 3 1, 3 7, 1 7, 1 1)   )'
select @Polygon
go
-----------------------------------------------D E M O  2-------------------------------------------------------------------------------------------

--STX,STY,ToString()
declare @point geometry ='POINT(5 3)'
select @point.ToString() as 'Point in String', @point as 'Point in Hex'
select @point.STX as X ,@point.STY as Y
go

--Buffer
declare @point geometry ='POINT(5 3)'
SELECT @point.STBuffer(5);
go
--Intersection / Intersects
declare @LineStrings1 geometry  = 'LINESTRING(2 3,5 3)'
declare @LineStrings2 geometry  = 'LINESTRING(3 2,3 4)'
declare @point geometry ='POINT(3 3)'
select @LineStrings1.STIntersection(@point).ToString()

SELECT @LineStrings1
Union ALL 
Select @LineStrings2


select @LineStrings1.STIntersection(@LineStrings2).ToString()


select @LineStrings1.STIntersects(@LineStrings2) -- 1 if 2 lines are Intersects .
go

--Length
declare @LineStrings geometry  = 'LINESTRING(2 3,5 3)'
select @LineStrings.STLength();
go

--Difference
declare @LineStrings1 geometry  = 'LINESTRING(2 3,5 3)'
DECLARE @Polygon geometry ='POLYGON((3 2, 3 4, 4 4, 4 2,3 2) )'
select @LineStrings1 union all select @Polygon
select @LineStrings1.STDifference(@Polygon)
go

--Union
--Difference

DECLARE @Compoundcurve geometry ='COMPOUNDCURVE( (2 3, 2 8), CIRCULARSTRING(2 8, 4 10, 6 8), (6 8, 6 3), CIRCULARSTRING(6 3, 4 1, 2 3) ) '
DECLARE @Polygon geometry ='POLYGON((0 2, 0 4, 4 4, 4 2,0 2) )'
select @Compoundcurve  union all select @Polygon
select @Compoundcurve.STDifference(@Polygon)
select @Compoundcurve.STUnion(@Polygon)
go

--Center 
DECLARE @Polygon geometry ='POLYGON((3 2, 3 4, 4 4, 4 2,3 2) )'
select @Polygon
union all
select @Polygon.STCentroid().STBuffer(0.1) 

select @Polygon.STCentroid().ToString()
 

 -- With in
DECLARE @Polygon geometry ='POLYGON((3 2, 3 4, 4 4, 4 2,3 2) )'
declare @Point geometry ='POINT(3.5 3)'
select @Point.STWithin(@Polygon)

GO
-- Contains
DECLARE @Polygon1 geometry ='POLYGON((1 1, 1 5, 7 5, 7 1,1 1) )' --BIG polygon
declare @Polygon2 geometry ='POLYGON((3 2, 3 4, 4 4, 4 2,3 2) )' -- Small polygon

Select @Polygon1
union all 
Select @Polygon2

select @Polygon1.STContains(@Polygon2)

------------------------------GEOGRAPHY -----------------------

DECLARE @Paris geography = geography::Point(48.87, 2.33, 4326); 
DECLARE @Berlin geography = geography::Point(52.52, 13.4, 4326); 
SELECT format(@Paris.STDistance(@Berlin),'#,###')+ ' Meters';  --880km

go
DECLARE @Paris geography = geography::Point(48.87, 2.33, 4326); 
DECLARE @TelAviv geography = geography::Point(34.769497, 32.064543, 4326); 
SELECT 
@Paris.STBuffer(40000), 'Paris' 
UNION ALL SELECT 
@TelAviv.STBuffer(40000), 'TelAviv' 
UNION ALL SELECT 
@Paris.ShortestLineTo(@TelAviv).STBuffer(10000), 'ShortestLineTo'; 