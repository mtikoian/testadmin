USE [Data_Archive_Purge]
GO

/****** Object:  Table [dbo].[tbl_Sales_detail]    Script Date: 2/13/2015 5:56:56 PM ******/
DROP TABLE [dbo].[tbl_Sales_detail]
GO

/****** Object:  Table [dbo].[tbl_Purchase_detail]    Script Date: 2/13/2015 5:56:56 PM ******/
DROP TABLE [dbo].[tbl_Purchase_detail]
GO

/****** Object:  Table [dbo].[tbl_Order_detail]    Script Date: 2/13/2015 5:56:56 PM ******/
DROP TABLE [dbo].[tbl_Order_detail]
GO

/****** Object:  Table [dbo].[tbl_customer_detail]    Script Date: 2/13/2015 5:56:56 PM ******/
DROP TABLE [dbo].[tbl_customer_detail]
GO

/****** Object:  Table [dbo].[MetaData_Detail]    Script Date: 2/13/2015 5:56:56 PM ******/
DROP TABLE [dbo].[MetaData_Detail]
GO

/****** Object:  Table [dbo].[AllTables]    Script Date: 2/13/2015 5:56:56 PM ******/
DROP TABLE [dbo].[AllTables]
GO

/****** Object:  Table [dbo].[AllTables]    Script Date: 2/13/2015 5:56:56 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[AllTables](
	[server_name] [varchar](200) NULL,
	[DbName] [varchar](200) NULL,
	[SchemaName] [varchar](200) NULL,
	[TableName] [varchar](200) NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[MetaData_Detail]    Script Date: 2/13/2015 5:56:57 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[MetaData_Detail](
	[Server_Name] [varchar](200) NULL,
	[Database_Name] [varchar](200) NULL,
	[Table_Name] [varchar](200) NULL,
	[Table_type] [varchar](50) NULL,
	[Data_Retention_days] [int] NULL,
	[Column_refered] [varchar](200) NULL,
	[Table_Archive] [bit] NULL,
	[Table_purge] [bit] NULL,
	[Approach_Method] [varchar](50) NULL,
	[Custom_Job_Name] [varchar](200) NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[tbl_customer_detail]    Script Date: 2/13/2015 5:56:57 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[tbl_customer_detail](
	[a] [int] NULL,
	[b] [varchar](2000) NULL,
	[c] [varchar](2000) NULL,
	[Transaction_date_time] [datetime] NULL,
	[Transaction_expire_date] [datetime] NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[tbl_Order_detail]    Script Date: 2/13/2015 5:56:57 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[tbl_Order_detail](
	[a] [int] NULL,
	[b] [varchar](2000) NULL,
	[c] [varchar](2000) NULL,
	[Transaction_date_time] [datetime] NULL,
	[Transaction_expire_date] [datetime] NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[tbl_Purchase_detail]    Script Date: 2/13/2015 5:56:57 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[tbl_Purchase_detail](
	[a] [int] NULL,
	[b] [varchar](2000) NULL,
	[c] [varchar](2000) NULL,
	[Transaction_date_time] [datetime] NULL,
	[Transaction_expire_date] [datetime] NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[tbl_Sales_detail]    Script Date: 2/13/2015 5:56:57 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[tbl_Sales_detail](
	[a] [int] NULL,
	[b] [varchar](2000) NULL,
	[c] [varchar](2000) NULL,
	[Transaction_date_time] [datetime] NULL,
	[Transaction_expire_date] [datetime] NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

