use Data_Archive_Purge
go

update  MetaData_Detail set Table_type ='Transactional_Table' where  Table_name like 'tbl%'
update  MetaData_Detail set Table_type ='Unstractured_Data' where  Table_name like '%task%'
update  MetaData_Detail set Table_type ='Log_Table' where  Table_name like '%log%'
update  MetaData_Detail set Table_type ='Audit_Table' where  Table_name like '%audit%'
update  MetaData_Detail set Table_type ='Encrypted_Table' where  Table_name like 'encry%'
update  MetaData_Detail set Table_type ='Config_Table' where  Table_name like '%config%'
update  MetaData_Detail set Table_type ='Unstractured_Data' where  database_name='Orchestrator' and Table_Name like '%Event%' and table_type='Undefined'






