with
 RecursiveSample as
 (
 /*The anchor member returns the first row of values. */
  select
   String = cast('*' as varchar(10)),
   Counter = 1
  union all
/* The recursive member builds first on the anchor and then on itself. */
  select
   String = cast(RecursiveSample.String + '*' as varchar(10)),
   Counter = RecursiveSample.Counter + 1
  from
   RecursiveSample
/* Use a WHERE condition on a counter-type column to control
   the end of the recursive loop. */
  where
   RecursiveSample.Counter < 10)
   
 select String, Counter from RecursiveSample

 Go

/******* 
   Script Name:: Christmas Tree from CTE
   Created On::  October 15, 2011
   Created by::  Geoff Johnson
   Description:: Uses a recursive CTE to generate a Christmas Tree figure.
********/

with ChristmasTree as 
 (select cast(space(15) + 'X' as varchar(30)) as TreeBranch, 15 as LeftSpace, 11 as Height
  union all
  select case when Height = 11 then cast(space(12) + 'OOO' as varchar(30)) when Height = 1 then space(5) + 'Merry Christmas!!!' when Height < 5 then cast(space(13) + 'MMM' as varchar(30)) else cast(space(LeftSpace - 3) + LTrim(TreeBranch) + 'OO' as varchar(30)) end, LeftSpace - 2, Height - 1 from ChristmasTree where Height > 0)
  
  
 select TreeBranch as [      Happy Holidays] from ChristmasTree


 /* The following query is based on the proprietary database of the 
church management software sold by Shelby Systems, Inc. For more
information, visit http://www.shelbysystems.com. */

 use ShelbyDB;


 /****  A Review of the contents of the SGOrgLvl self-referencing table. */
 select * from Shelby.SGOrgLvl
Go 


with
 OrganizationLevels as
 (
/* Anchor member returns all the top level items, i.e. where the Lvl 
   column value equals 5. The levels are numbered in reverse. The top
   is 5 and the bottom is 1. */
 select
   Levels.Counter,
   SGOrgLvlAbove,
   /* The VerboseBreadcrumb column includes every possible level,
      even those that are unused and therefore have only a one-character
      placeholder for their ID information. */
   VerboseBreadcrumb = cast(Orgs.Descr + ' : ' + IDLevel as varchar(255)),
   /* The ShortBreadcumb column uses a CASE statement to suppress the 
      one-character placeholders for unused levels. */
   ShortBreadcrumb = cast(Orgs.Descr + case when len(IDLevel) = 1 then '' else ' : ' + IDLevel end as varchar(255)),
   LevelName = cast(case when len(Levels.IDLevel) = 1 then '' else Levels.Descr end as varchar(255)),
   LevelCounter = 4
  from
   Shelby.SGOrgLvl as Levels inner join
   Shelby.SGOrg as Orgs on Levels.SGOrgCounter = Orgs.Counter
  where
   Lvl = 5
/* The recursive member uses the SGOrgLvlAbove self-referential column
   to join to the anchor member or to the prior iteration of the recursive
   member.*/  
  union all
  select
   Levels.Counter,
   Levels.SGOrgLvlAbove,
   cast(VerboseBreadcrumb + ' : ' + Levels.IDLevel as varchar(255)),
   cast(ShortBreadcrumb + case when len(Levels.IDLevel) = 1 then '' else ' : ' + Levels.IDLevel end as varchar(255)),  
   cast(space(3 * (5 - OrganizationLevels.LevelCounter)) + case when len(Levels.IDLevel) = 1 then '' else Levels.Descr end as varchar(255)),
   LevelCounter = LevelCounter - case when len(Levels.IDLevel) = 1 then 0 else 1 end
  from
   Shelby.SGOrgLvl Levels inner join
   OrganizationLevels on Levels.SGOrgLvlAbove = OrganizationLevels.Counter)

select
 VerboseBreadcrumb,
 ShortBreadcrumb,
 LevelName
from
 OrganizationLevels
order by
  VerboseBreadcrumb