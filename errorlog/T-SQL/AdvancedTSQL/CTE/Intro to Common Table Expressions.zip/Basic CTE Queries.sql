with
/* First CTE creates a "TallyTable" using a technique inspired by Jeff Moden. */
 TallyTable as 
 (select top 4000 N = -1 * row_number() over (order by (select null)) from master.sys.all_columns
union all
select N = 0
union all
select top 4000 N = row_number() over (order by (select null)) from master.sys.all_columns
)
/* Second CTE leverages the first to create a "Dates" table that can be used for many purposes. */
 , Dates as
(select
  CalendarYear = year(dateadd(day, N, getdate())),
  CalendarMonth = month(dateadd(day, N, getdate())),
  CalendarDay = day(dateadd(day, N, getdate())),
  ISODate = convert(varchar(10), dateadd(day, N, getdate()), 112)
 from
  TallyTable)
  
select CalendarYear, CalendarMonth, CalendarDay, ISODate from Dates



use AdventureWorks2008R2;

with
/* CTE calculates total quantity of items purchased per order */
 QtyPerOrder as
 (select
 Orders.SalesOrderID,
 Addresses.PostalCode,
 TotalQty = sum(OrderDetails.OrderQty)
from
 Sales.SalesOrderDetail as OrderDetails inner join
 Sales.SalesOrderHeader as Orders on OrderDetails.SalesOrderID = Orders.SalesOrderID inner join
 Person.Address as Addresses on Orders.ShipToAddressID = Addresses.AddressID
group by
 Orders.SalesOrderID, Addresses.PostalCode)
 
/* Primary query uses the CTE and averages the total quantity per order per postal code. */
 select
  PostalCode,
  AverageQtyPerOrder = avg(TotalQty),
  NumberOfOrders = count(SalesOrderID)
 from
  QtyPerOrder
 group by
  PostalCode
 order by
  AverageQtyPerOrder Desc


/* The following query is based on the proprietary database of the 
church management software sold by Shelby Systems, Inc. For more
information, visit http://www.shelbysystems.com. */

  use ShelbyDB;

/*CTEs can take advantage of variable values that are defined above the 
  WITH clause in which they appear. */
declare @OrganizationName as varchar(40), @TargetDate as datetime;
set @OrganizationName = 'Worship';
set @TargetDate = '2/15/2011';

with
/* The first CTE pulls together the columns and yields all attendance history.
   Adding the QuarterDiff column simplifies filtering later and avoids 
   putting a column reference into a WHERE clause. */
 AttendanceHistory as
 (select
 NameCounter = N.NameCounter,
 AttendeeName = N.LastName + ', ' + N.FirstMiddle,
 AttendanceDate = O.SGDate,
 AttendanceYear = year(O.SGDate),
 AttendanceQuarter = datepart(quarter, O.SGDate),
 QuarterDiff = datediff(quarter, O.SGDate, @TargetDate),
 AttendanceType = A.SGAttTyp
from
 Shelby.SGMstOrgAtt as A inner join
 Shelby.SGOrgGrpDat as G on A.SGOrgGrpDatCounter = G.Counter inner join
 Shelby.SGOrgDat as O on G.SGOrgDatCounter = O.Counter inner join
 Shelby.SGOrg as Orgs on O.SGOrgCounter = Orgs.Counter inner join
 Shelby.SGMstOrg as M on A.SGMstOrgCounter = M.Counter inner join
 Shelby.NANames as N on M.NameCounter = N.NameCounter
where Orgs.Descr = @OrganizationName),

/* The second CTE pulls data from the first only for the quarter that
   is "current" as of the @TargetDate. */
CurrentQuarter as
(select
 NameCounter,
 AttendeeName,
 TimesPresent = sum(case when AttendanceType <> 'A' then 1 else 0 end),
 TimesPossible = count(AttendanceType),
 PercentPresent = sum(case when AttendanceType <> 'A' then 1 else 0 end) / cast(count(AttendanceType) as decimal(5, 2)) * 100
from
 AttendanceHistory
where
 QuarterDiff = 0
group by
 NameCounter, AttendeeName),

/* The third CTE is identical to the second, except that it is pulling the
   prior quarter values, i.e. QuarterDiff = 1. */ 
 PriorQuarter as
 (select
 NameCounter,
 AttendeeName,
 TimesPresent = sum(case when AttendanceType <> 'A' then 1 else 0 end),
 TimesPossible = count(AttendanceType),
 PercentPresent = sum(case when AttendanceType <> 'A' then 1 else 0 end) / cast(count(AttendanceType) as decimal(5, 2)) * 100
from
 AttendanceHistory
where
 QuarterDiff = 1
group by
 NameCounter, AttendeeName)
 
/*The main query takes the results of CTE2 and CTE3 and compares them to
  arrive at the change in percent attended values. */
 select
  CQ.NameCounter,
  CQ.AttendeeName,
  CurrentPercentPresent = CQ.PercentPresent,
  PriorPercentPresent = PQ.PercentPresent,
  ChangeInPercent = CQ.PercentPresent - PQ.PercentPresent
 from
 CurrentQuarter as CQ left join
 PriorQuarter as PQ on CQ.NameCounter = PQ.NameCounter