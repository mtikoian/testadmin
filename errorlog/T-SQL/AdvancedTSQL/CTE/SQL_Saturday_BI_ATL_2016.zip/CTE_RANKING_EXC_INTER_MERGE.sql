DECLARE @PhoneBook TABLE (
	tID int identity(1,1),
	PhoneNumber varchar (30),
	FirstName varchar (30),
	LastName varchar (30),
	Company varchar (100)
)

INSERT @PhoneBook SELECT '215 902-2345','Sam','Long','SM Soft Inc.'
INSERT @PhoneBook SELECT '215 905-8766','John','Smith','Company LLC'
INSERT @PhoneBook SELECT '215 909-4563','Joe','Garner','IT United Inc.'
-- Duplicate insert 1
INSERT @PhoneBook SELECT '215 902-2345','Sam','Long','SM Soft Inc.'
INSERT @PhoneBook SELECT '215 905-8766','John','Smith','Company LLC'
INSERT @PhoneBook SELECT '215 909-4563','Joe','Garner','IT United Inc.'
-- Duplicate insert 2
INSERT @PhoneBook SELECT '215 902-2345','Sam','Long','SM Soft Inc.'
INSERT @PhoneBook SELECT '215 905-8766','John','Smith','Company LLC'
INSERT @PhoneBook SELECT '215 909-4563','Joe','Garner','IT United Inc.'
-- Duplicate insert 3
INSERT @PhoneBook SELECT '215 902-2345','Sam','Long','SM Soft Inc.'
INSERT @PhoneBook SELECT '215 902-2345','Sam','Long','SM Soft Inc.'
INSERT @PhoneBook SELECT '215 902-2345','Sam','Long','SM Soft Inc.'
-- Duplicate insert 4
INSERT @PhoneBook SELECT '215 905-8766','John','Smith','Company LLC'
INSERT @PhoneBook SELECT '215 905-8766','John','Smith','Company LLC'
INSERT @PhoneBook SELECT '215 905-8766','John','Smith','Company LLC'
-- Duplicate insert 5
INSERT @PhoneBook SELECT '215 909-4563','Joe','Garner','IT United Inc.'
INSERT @PhoneBook SELECT '215 909-4563','Joe','Garner','IT United Inc.'
INSERT @PhoneBook SELECT '215 909-4563','Joe','Garner','IT United Inc.';

select tID, PhoneNumber, FirstName,	LastName
from @PhoneBook

-- Rankig function
;WITH CTE_Rank AS
(
	select ROW_NUMBER() over(partition by PhoneNumber, FirstName, LastName order by  tID) as RN, tID, PhoneNumber, FirstName,	LastName
	from @PhoneBook
)
select *
from CTE_Rank
where RN = 1







/*********************** RANK - DENSE_RANK *************************/
DECLARE @SUV TABLE (Vehicle varchar(40), Score decimal(5,1)) 
INSERT @SUV 
VALUES ('2016 Volvo XC90', 9.3),('2016 Lexus RX 450', 8.8), ('2016 Porsche Cayenne', 8.8), ('2016 Lexus RX 350', 8.7), 
	('2016 Acura MDX', 8.6), ('2016 BMW X5', 8.6), ('2016 Land Rover Range Rover Sport', 8.6), ('2016 Lincoln MKX', 8.6), 
	('2016 Mercedes-Benz GLE-Class', 8.5), ('2016 Infiniti QX70', 8.3), ('2016 Cadillac SRX', 8.1)

SELECT RANK() OVER(ORDER BY Score DESC) [Rank#], Vehicle, Score
FROM @SUV

SELECT DENSE_RANK() OVER(ORDER BY Score DESC) [Rank#], Vehicle, Score
FROM @SUV








/*********************** NTILE ********************/


-- DELETE TOP 10000 FROM [XML_SQLSaturday].dbo.RankTest

-- NTILE() breaks the results into groups.
;WITH CTE AS 
(
SELECT NTILE(10) OVER(ORDER BY Date_Completed) Tile, *
FROM [XML_SQLSaturday].dbo.RankTest
WHERE Description = 'Exempt'
)
SELECT * FROM CTE WHERE Tile = 5














/************************************* Test EXCEPT and INTERSECT ****************/

declare @t1 table(tID int)
declare @t2 table(tID int)

insert @t1
select 1
union
select 3
union
select 5
union
select 6

insert @t2
select 1
union
select 2
union
select 4
union
select 6

/*
select tId from @t1
intersect
select tId from @t2

select *
from @t1 t1 join @t2 t2 on t1.tID = t2.tID
*/

select tId from @t1
except
select tId from @t2

select * from @t1 where tID NOT IN (select tID from @t2)













/**************************************************** OUTPUT Clause ******************************************************************************/
USE Northwind
GO

SET NOCOUNT ON

SET STATISTICS TIME ON
PRINT '*************************** OUTPUT Clause based method***************************************'
declare @x xml, @start datetime2 = getdate()
-- get XML
SELECT @x = 
(
	SELECT Products.ProductName, 
			Customers.CompanyName, 
			Shippers.CompanyName AS ShippersName, 
			convert(varchar(20),GETDATE(),101) as OrderDate, 
		   [Order Details].UnitPrice, 
		   [Order Details].Quantity, 
		   CAST([Order Details].Discount as varchar(9)) as Discount
	FROM  Products INNER JOIN
		   [Order Details] ON Products.ProductID = [Order Details].ProductID INNER JOIN
		   Orders ON [Order Details].OrderID = Orders.OrderID INNER JOIN
		   Customers ON Orders.CustomerID = Customers.CustomerID INNER JOIN
		   Shippers ON Orders.ShipVia = Shippers.ShipperID
	WHERE  Orders.OrderDate = '1998-05-05'
	FOR XML PATH('Product'), ROOT('Orders')
)	
/*
-- Create then Shred XML
SELECT c.value('ProductName[1]', 'nvarchar(100)') as ProductName, 
		c.value('CompanyName[1]', 'nvarchar(100)') as CompanyName, 
		c.value('ShippersName[1]', 'nvarchar(100)') as ShippersName, 
		c.value('OrderDate[1]', 'datetime') as OrderDate, 
		c.value('UnitPrice[1]', 'money') as UnitPrice, 
		c.value('Quantity[1]', 'int') as Quantity, 
		c.value('Discount[1]', 'real') as Discount,
		Products.ProductID,
		Shippers.ShipperID,
		Customers.CustomerID
FROM @x.nodes('Orders/Product') as T(C)
	JOIN Products ON Products.ProductName = c.value('ProductName[1]', 'nvarchar(100)')
	JOIN Shippers ON Shippers.CompanyName =  c.value('ShippersName[1]', 'nvarchar(100)')
	JOIN Customers ON Customers.CompanyName = c.value('CompanyName[1]', 'nvarchar(100)')
*/
-- Created output storage table
DECLARE @NewOrder TABLE(OrderID int, CustomerID nchar(5))

-- INSERT into Orders table
INSERT Orders (CustomerID, OrderDate, ShipVia)
		OUTPUT inserted.OrderID, inserted.CustomerID INTO @NewOrder (OrderID, CustomerID)
SELECT distinct	Customers.CustomerID, 
		c.value('OrderDate[1]', 'datetime') as OrderDate, 
		Shippers.ShipperID
FROM @x.nodes('Orders/Product') as T(C)
	JOIN Products ON Products.ProductName = c.value('ProductName[1]', 'nvarchar(100)')
	JOIN Shippers ON Shippers.CompanyName =  c.value('ShippersName[1]', 'nvarchar(100)')
	JOIN Customers ON Customers.CompanyName = c.value('CompanyName[1]', 'nvarchar(100)')
	
-- INSERT into Order Details table
INSERT [Order Details] (OrderID, ProductID, UnitPrice, Quantity, Discount)
SELECT NewOrder.OrderID, Products.ProductID,
		c.value('UnitPrice[1]', 'money') as UnitPrice, 
		c.value('Quantity[1]', 'int') as Quantity, 
		c.value('Discount[1]', 'real') as Discount
FROM @x.nodes('Orders/Product') as T(C)
	JOIN Products ON Products.ProductName = c.value('ProductName[1]', 'nvarchar(100)')
	JOIN Shippers ON Shippers.CompanyName =  c.value('ShippersName[1]', 'nvarchar(100)')
	JOIN Customers ON Customers.CompanyName = c.value('CompanyName[1]', 'nvarchar(100)')
	JOIN @NewOrder NewOrder ON NewOrder.CustomerID = Customers.CustomerID

SET STATISTICS TIME OFF
select DATEDIFF(MILLISECOND, @start, GETDATE())

/****************************  Verify then archive ***************************************
	SELECT Products.ProductName, 
			Customers.CompanyName, 
			Shippers.CompanyName AS ShippersName, 
			convert(varchar(20),GETDATE(),101) as OrderDate, 
		   [Order Details].UnitPrice, 
		   [Order Details].Quantity, 
		   CAST([Order Details].Discount as varchar(9)) as Discount
	FROM  Products INNER JOIN
		   [Order Details] ON Products.ProductID = [Order Details].ProductID INNER JOIN
		   Orders ON [Order Details].OrderID = Orders.OrderID INNER JOIN
		   Customers ON Orders.CustomerID = Customers.CustomerID INNER JOIN
		   Shippers ON Orders.ShipVia = Shippers.ShipperID
	WHERE  Orders.OrderDate >= convert(varchar(20),GETDATE(),101)
	
	DELETE [Order Details]
		OUTPUT deleted.*,GETDATE() INTO Archive_OrderDetails
	FROM [Order Details] JOIN Orders ON [Order Details].OrderID = Orders.OrderID
	WHERE  Orders.OrderDate >= convert(varchar(20),GETDATE(),101)
	
	DELETE Orders
		OUTPUT deleted.*, GETDATE() INTO [Archive_Orders]
	FROM Orders WHERE  Orders.OrderDate >= convert(varchar(20),GETDATE(),101)
	
	SELECT * FROM Archive_OrderDetails
	SELECT * FROM Archive_Orders
	

	TRUNCATE TABLE Archive_OrderDetails
	TRUNCATE TABLE Archive_Orders



			
*/


/******************************** Conventional: CURSOR based method ***********************************************************/
PRINT '***************************Conventional: CURSOR based method***************************************'
GO
SET STATISTICS TIME ON

declare @x xml, @start datetime2 = getdate()
-- get XML
SELECT @x = 
(
	SELECT Products.ProductName, 
			Customers.CompanyName, 
			Shippers.CompanyName AS ShippersName, 
			convert(varchar(20),GETDATE(),101) as OrderDate, 
		   [Order Details].UnitPrice, 
		   [Order Details].Quantity, 
		   CAST([Order Details].Discount as varchar(9)) as Discount
	FROM  Products INNER JOIN
		   [Order Details] ON Products.ProductID = [Order Details].ProductID INNER JOIN
		   Orders ON [Order Details].OrderID = Orders.OrderID INNER JOIN
		   Customers ON Orders.CustomerID = Customers.CustomerID INNER JOIN
		   Shippers ON Orders.ShipVia = Shippers.ShipperID
	WHERE  Orders.OrderDate = '1998-05-05'
	FOR XML PATH('Product'), ROOT('Orders')
)	

-- Created cursor
DECLARE @CustomerID varchar(20), @OrderDate datetime, @ShippersID int, @OrderID int 
DECLARE cur CURSOR 
	FOR	SELECT DISTINCT	Customers.CustomerID, 
				c.value('OrderDate[1]', 'datetime') as OrderDate, 
				Shippers.ShipperID
		FROM @x.nodes('Orders/Product') as T(C)
			JOIN Products ON Products.ProductName = c.value('ProductName[1]', 'nvarchar(100)')
			JOIN Shippers ON Shippers.CompanyName =  c.value('ShippersName[1]', 'nvarchar(100)')
			JOIN Customers ON Customers.CompanyName = c.value('CompanyName[1]', 'nvarchar(100)')
OPEN cur
FETCH NEXT FROM cur INTO @CustomerID, @OrderDate, @ShippersID

-- Check @@FETCH_STATUS to see if there are any more rows to fetch.
WHILE @@FETCH_STATUS = 0
BEGIN

-- INSERT into Orders table
INSERT Orders (CustomerID, OrderDate, ShipVia)
SELECT		@CustomerID, @OrderDate, @ShippersID

SET @OrderID = SCOPE_IDENTITY()

-- INSERT into Order Details table
INSERT [Order Details] (OrderID, ProductID, UnitPrice, Quantity, Discount)
SELECT @OrderID, Products.ProductID,
		c.value('UnitPrice[1]', 'money') as UnitPrice, 
		c.value('Quantity[1]', 'int') as Quantity, 
		c.value('Discount[1]', 'real') as Discount
FROM @x.nodes('Orders/Product') as T(C)
	JOIN Products ON Products.ProductName = c.value('ProductName[1]', 'nvarchar(100)')
	JOIN Shippers ON Shippers.CompanyName =  c.value('ShippersName[1]', 'nvarchar(100)')
	JOIN Customers ON Customers.CompanyName = c.value('CompanyName[1]', 'nvarchar(100)')
WHERE Customers.CustomerID = @CustomerID
	
FETCH NEXT FROM cur INTO @CustomerID, @OrderDate, @ShippersID

END

DEALLOCATE cur;

SET STATISTICS TIME OFF
		
select DATEDIFF(MILLISECOND, @start, GETDATE())		
		
		
		
/******************************************************* More OUTPUT Clause *********************************************/
declare @t TABLE(tID uniqueidentifier not null primary key default NEWSEQUENTIALID(), num1 int)

declare @newid table (New_ID uniqueidentifier)
insert @t (num1)
	OUTPUT inserted.tID into @newid
values (1),(2),(3)

select * from @newid n join @t t ON n.New_ID = t.tID

	
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
/******************************** MERGE STATEMENT ******************************************/


SET NOCOUNT ON

IF OBJECT_ID (N'dbo.Departments', N'U') IS NOT NULL 
    DROP TABLE dbo.Departments;
GO
CREATE TABLE dbo.Departments (DeptID tinyint NOT NULL PRIMARY KEY, DeptName nvarchar(30), Manager nvarchar(50));
GO
INSERT INTO dbo.Departments 
VALUES (1, 'Human Resources', 'Mark'),
		(2, 'Sales', 'Steve'), 
		(3, 'Finance', 'Gill'),
		(4, 'Purchasing', 'Barber'),
		(5, 'Manufacturing', 'Brewer');

IF OBJECT_ID (N'dbo.Departments_delta', N'U') IS NOT NULL 
    DROP TABLE dbo.Departments_delta;
GO
CREATE TABLE dbo.Departments_delta (DeptID tinyint NOT NULL PRIMARY KEY, DeptName nvarchar(30), Manager nvarchar(50));
GO
INSERT INTO dbo.Departments_delta VALUES 
    (1, 'Human Resources', 'Mark'), 
    (2, 'Sales', 'Erickson'),
    (3, 'Accounting', 'Varkey'),
    (4, 'Purchasing', 'Barber'), 
    (6, 'Production', 'Jones'), 
    (7, 'Customer Relations', 'Smith');
    
SET STATISTICS IO, TIME ON

; MERGE dbo.Departments AS d
USING dbo.Departments_delta AS dd
	ON (d.DeptID = dd.DeptID)
WHEN MATCHED AND d.Manager != dd.Manager OR d.DeptName != dd.DeptName
    THEN UPDATE SET d.Manager = dd.Manager, 
					d.DeptName = dd.DeptName
WHEN NOT MATCHED THEN
    INSERT (DeptID, DeptName, Manager)
    VALUES (dd.DeptID, dd.DeptName, dd.Manager)
WHEN NOT MATCHED BY SOURCE THEN -- SOURCE - DELETE; TARGET - INSERT
    DELETE
OUTPUT $action, 
       inserted.DeptID AS SourceDeptID, inserted.DeptName AS SourceDeptName, inserted.Manager AS SourceManager, 
       deleted.DeptID AS TargetDeptID, deleted.DeptName AS TargetDeptName, deleted.Manager AS TargetManager;
       
SET STATISTICS IO, TIME OFF


select * from Departments
select * from Departments_delta

SET NOCOUNT OFF



/*


create table #Archive (
	ActionType varchar(20), 
	SourceDeptID int, 
	SourceDeptName nvarchar(50), 
	SourceManager nvarchar(50),
	TargetDeptID int, 
	TargetDeptName nvarchar(50), 
	TargetManager nvarchar(50)
)

;MERGE dbo.Departments AS d
USING dbo.Departments_delta AS dd
	ON (d.DeptID = dd.DeptID)
WHEN MATCHED AND d.Manager <> dd.Manager OR d.DeptName <> dd.DeptName
    THEN UPDATE SET d.Manager = dd.Manager, 
					d.DeptName = dd.DeptName
WHEN NOT MATCHED THEN
    INSERT (DeptID, DeptName, Manager)
    VALUES (dd.DeptID, dd.DeptName, dd.Manager)
WHEN NOT MATCHED BY SOURCE THEN
    DELETE   
OUTPUT $action, 
       inserted.DeptID AS SourceDeptID, inserted.DeptName AS SourceDeptName, inserted.Manager AS SourceManager, 
       deleted.DeptID AS TargetDeptID, deleted.DeptName AS TargetDeptName, deleted.Manager AS TargetManager
INTO #Archive;

SELECT * FROM #archive

*/




/**********************************	Concatenate column values USING CTE***************************************/

DECLARE @tblTest TABLE (tID int, TestValue varchar(20))
INSERT @tblTest VALUES(2,'A'), (4,'B'),(5,'C'),(6,'D'),(8,'E'),(9, 'F'),(10,'G'), (11,'H'),(12,'J'),(13,'J'),(14,'K'),(15, 'L'),
(16,'M'), (17,'N'),(18,'O'),(19,'P'),(20,'Q'),(21, 'R'),(22,'A'), (23,'S'),(24,'T'),(25,'U'),(26,'W'),(27, 'X')

SET STATISTICS IO, TIME ON

;WITH ABC (FId, FName) AS
(
    SELECT 1, CAST('' AS VARCHAR(8000)) 
    UNION ALL
    SELECT B.FId + 1,  B.FName + ', ' + A.TestValue 
    FROM (SELECT Row_Number() OVER (ORDER BY tID) AS RN, TestValue FROM @tblTest) A 
    INNER JOIN ABC B ON A.RN = B.FId 
)
SELECT top 1 FName = STUFF(FName, 1, 2, '') FROM ABC ORDER BY FId DESC
-- DROP TABLE tblTest

/**********************************	Concatenate column values using XML PATH ***************************************/

SELECT STUFF((SELECT ', ' + TestValue
FROM @tblTest FOR XML PATH('')), 1, 2,'') as FName

SET STATISTICS IO, TIME OFF