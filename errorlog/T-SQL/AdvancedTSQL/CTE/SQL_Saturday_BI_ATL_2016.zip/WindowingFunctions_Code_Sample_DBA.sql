USE northwind
GO
-- Kathi Kellenberger "Expert T-SQL Window Functions in SQL Server"
/*

<window frame preceding> ::= 
{
    UNBOUNDED PRECEDING
  | <unsigned_value_specification> PRECEDING
  | CURRENT ROW
}

<window frame following> ::= 
{
    UNBOUNDED FOLLOWING
  | <unsigned_value_specification> FOLLOWING
  | CURRENT ROW
}

*/
/**************************************************  Windowing Functions  ******************************************************/
-- Enables cumulative calculations within each window
-- Get running SUM 
WITH CTE AS
(
	SELECT  dbo.Customers.CompanyName
			, cast(dbo.Orders.OrderDate as date) OrderDate
			, SUM(dbo.[Order Details].UnitPrice * dbo.[Order Details].Quantity) OrderTotal
	FROM dbo.Customers INNER JOIN
		dbo.Orders ON dbo.Customers.CustomerID = dbo.Orders.CustomerID INNER JOIN
		dbo.[Order Details] ON dbo.Orders.OrderID = dbo.[Order Details].OrderID
	GROUP BY dbo.Customers.CompanyName, cast(dbo.Orders.OrderDate as date)
)
SELECT CompanyName, OrderDate, OrderTotal
	 ,RunningSumByCompany =  SUM(OrderTotal) OVER (PARTITION BY CompanyName ORDER BY CompanyName, OrderDate ROWS UNBOUNDED PRECEDING)
	 ,RunningSumALL =  SUM(OrderTotal) OVER ( ORDER BY CompanyName, OrderDate ROWS UNBOUNDED PRECEDING)
FROM CTE


-- ROWS BETWEEN CURRENT ROW AND [N] FOLLOWING
;WITH CTE AS
(

	SELECT  dbo.Customers.CompanyName
			, cast(dbo.Orders.OrderDate as date) OrderDate
			, SUM(dbo.[Order Details].UnitPrice * dbo.[Order Details].Quantity) OrderTotal
	FROM dbo.Customers INNER JOIN
		dbo.Orders ON dbo.Customers.CustomerID = dbo.Orders.CustomerID INNER JOIN
		dbo.[Order Details] ON dbo.Orders.OrderID = dbo.[Order Details].OrderID
	GROUP BY dbo.Customers.CompanyName, cast(dbo.Orders.OrderDate as date)
)
SELECT CompanyName, convert(char(6), OrderDate, 112) OrderDate, OrderTotal
	 ,RunningSumByFoll =  SUM(OrderTotal) OVER (PARTITION BY convert(char(6), OrderDate, 112)   ORDER BY OrderDate ROWS BETWEEN CURRENT ROW AND 1 FOLLOWING)
	 ,Running1F2F =  SUM(OrderTotal) OVER (PARTITION BY convert(char(6), OrderDate, 112)   ORDER BY OrderDate ROWS BETWEEN CURRENT ROW AND 2 FOLLOWING)
	 ,Running2P1F =  SUM(OrderTotal) OVER (PARTITION BY convert(char(6), OrderDate, 112)   ORDER BY OrderDate ROWS BETWEEN 2 PRECEDING AND CURRENT ROW)
FROM CTE




-- Totals Based Upon a Subset of Rows  *** RANGE UNBOUNDED PRECEDING - default
;WITH CTE AS
(
	SELECT  dbo.Customers.CompanyName
			, cast(dbo.Orders.OrderDate as date) OrderDate
			, SUM(dbo.[Order Details].UnitPrice * dbo.[Order Details].Quantity) OrderTotal
	FROM dbo.Customers INNER JOIN
		dbo.Orders ON dbo.Customers.CustomerID = dbo.Orders.CustomerID INNER JOIN
		dbo.[Order Details] ON dbo.Orders.OrderID = dbo.[Order Details].OrderID
	GROUP BY dbo.Customers.CompanyName, cast(dbo.Orders.OrderDate as date)
)
SELECT CompanyName, LEFT(OrderDate, 7) OrderDate, OrderTotal
	 ,RunningSumByCompany =  SUM(OrderTotal) OVER (PARTITION BY CompanyName ORDER BY CompanyName, LEFT(OrderDate, 7) ROWS UNBOUNDED PRECEDING)
	 ,RunningSumALL =  SUM(OrderTotal) OVER ( ORDER BY CompanyName, LEFT(OrderDate, 7) RANGE UNBOUNDED PRECEDING)
FROM CTE
ORDER BY CompanyName



--- RANGE vs ROWS
--With the ROWS option you define on a physical level how many rows are included in your window frame. 
--With the RANGE option how many rows are included in the window frame depends on the ORDER BY values.
SELECT * FROM _Window ORDER BY CustomerName, OrderDate, OrderID

SELECT OrderID, CustomerName,OrderDate
	, OrderAmt
	,SUM(OrderAmt) OVER (ORDER BY CustomerName) as OrderByName
	,SUM(OrderAmt) OVER (PARTITION BY CustomerName ORDER BY OrderDate, OrderID  RANGE BETWEEN UNBOUNDED PRECEDING and CURRENT ROW) as RangeByDate
	,SUM(OrderAmt) OVER (PARTITION BY CustomerName ORDER BY OrderDate, OrderID 	ROWS BETWEEN 1 FOLLOWING and 2 FOLLOWING) as NextTwoAmts
FROM _Window;


-- Show slide row calculation
;WITH CTE AS
(
	SELECT  dbo.Customers.CompanyName
			, cast(dbo.Orders.OrderDate as date) OrderDate
			, SUM(dbo.[Order Details].UnitPrice * dbo.[Order Details].Quantity) OrderTotal
	FROM dbo.Customers INNER JOIN
		dbo.Orders ON dbo.Customers.CustomerID = dbo.Orders.CustomerID INNER JOIN
		dbo.[Order Details] ON dbo.Orders.OrderID = dbo.[Order Details].OrderID
	GROUP BY dbo.Customers.CompanyName, cast(dbo.Orders.OrderDate as date)
)
SELECT CompanyName, OrderDate, OrderTotal,
-- average of the current and previous 2 transactions
	SlideAvg = AVG(OrderTotal) OVER (PARTITION BY CompanyName ORDER BY OrderDate ROWS BETWEEN 2 PRECEDING AND CURRENT ROW),
-- total # of the current and previous 2 transactions
	SlideQty = COUNT(*) OVER (PARTITION BY CompanyName ORDER BY OrderDate ROWS BETWEEN 2 PRECEDING AND CURRENT ROW),
-- smallest of the current and previous 2 transactions
	SlideMin = MIN(OrderTotal) OVER (PARTITION BY CompanyName ORDER BY OrderDate ROWS BETWEEN 2 PRECEDING AND CURRENT ROW),
-- largest of the current and previous 2 transactions
	SlideMax = MAX(OrderTotal) OVER (PARTITION BY CompanyName ORDER BY OrderDate ROWS BETWEEN 2 PRECEDING AND CURRENT ROW),
-- total of the current and previous 2 transactions
	SlideTotal = SUM(OrderTotal) OVER (PARTITION BY CompanyName ORDER BY OrderDate ROWS BETWEEN 2 PRECEDING AND CURRENT ROW)
FROM CTE
ORDER BY CompanyName



/************************************************** Analytic functions LEAD, LAG, FIRST_VALUE and LAST_VALUE functions  ******************************************************/

SELECT  Year(dbo.Orders.OrderDate) SalesYear
		, SUM(dbo.[Order Details].UnitPrice * dbo.[Order Details].Quantity) Sales
		, LEAD(SUM(dbo.[Order Details].UnitPrice * dbo.[Order Details].Quantity),1,0) OVER(ORDER BY Year(dbo.Orders.OrderDate)) AS [Next Year Sale]
        , LAG(SUM(dbo.[Order Details].UnitPrice * dbo.[Order Details].Quantity))  OVER(ORDER BY Year(dbo.Orders.OrderDate))AS [Prev Year Sale]

		, LEAD(SUM(dbo.[Order Details].UnitPrice * dbo.[Order Details].Quantity),2,0) OVER(ORDER BY Year(dbo.Orders.OrderDate)) AS [2nd Next Year Sale]
        , LAG(SUM(dbo.[Order Details].UnitPrice * dbo.[Order Details].Quantity),2,0) OVER(ORDER BY Year(dbo.Orders.OrderDate))AS [2nd Prev Year Sale]
FROM dbo.Customers INNER JOIN
	dbo.Orders ON dbo.Customers.CustomerID = dbo.Orders.CustomerID INNER JOIN
	dbo.[Order Details] ON dbo.Orders.OrderID = dbo.[Order Details].OrderID
--WHERE Year(dbo.Orders.OrderDate) = 1996
GROUP BY Year(dbo.Orders.OrderDate)


/*************************************** OFFSET and FETCH 
	SELECT  dbo.Customers.CompanyName
			, cast(dbo.Orders.OrderDate as date) OrderDate
			, SUM(dbo.[Order Details].UnitPrice * dbo.[Order Details].Quantity) OrderTotal
	FROM dbo.Customers INNER JOIN
		dbo.Orders ON dbo.Customers.CustomerID = dbo.Orders.CustomerID INNER JOIN
		dbo.[Order Details] ON dbo.Orders.OrderID = dbo.[Order Details].OrderID
	GROUP BY dbo.Customers.CompanyName, cast(dbo.Orders.OrderDate as date)
	ORDER BY dbo.Customers.CompanyName


DECLARE @OffsetRows tinyint = 50
		, @FetchRows tinyint = 10;

	SELECT  dbo.Customers.CompanyName
			, cast(dbo.Orders.OrderDate as date) OrderDate
			, SUM(dbo.[Order Details].UnitPrice * dbo.[Order Details].Quantity) OrderTotal
	FROM dbo.Customers INNER JOIN
		dbo.Orders ON dbo.Customers.CustomerID = dbo.Orders.CustomerID INNER JOIN
		dbo.[Order Details] ON dbo.Orders.OrderID = dbo.[Order Details].OrderID
	GROUP BY dbo.Customers.CompanyName, cast(dbo.Orders.OrderDate as date)
	ORDER BY dbo.Customers.CompanyName
	OFFSET (@OffsetRows) ROWS FETCH NEXT @FetchRows ROWS ONLY


****************************************/