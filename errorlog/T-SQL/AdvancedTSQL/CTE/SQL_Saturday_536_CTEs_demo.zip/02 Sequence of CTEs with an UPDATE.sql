USE Flygbolaget;




--- Find passengers where the lastname consists of two
--- words, the second of which starts with a lower-case
--- character.
SELECT PassengerID, FirstName, LastName
FROM Booking.Passengers
WHERE LastName COLLATE Finnish_Swedish_BIN LIKE '% [a-z]%';













--- Find passengers where the lastname consists of two
--- words, the second of which starts with a lower-case
--- character.
WITH c1 AS (
    SELECT PassengerID, FirstName, LastName
    FROM Booking.Passengers
    WHERE LastName COLLATE Finnish_Swedish_BIN LIKE '% [a-z]%'
    )

--- Split those lastnames into two words,
--- FirstWord and SecondWord:
SELECT PassengerID,
        LastName,
        LEFT(LastName, CHARINDEX(' ', LastName)-1) AS FirstWord,
        SUBSTRING(LastName, CHARINDEX(' ', LastName)+1, 100) AS SecondWord
FROM c1;














--- Find passengers where the lastname consists of two
--- words, the second of which starts with a lower-case
--- character.
WITH c1 AS (
    SELECT PassengerID, FirstName, LastName
    FROM Booking.Passengers
    WHERE LastName COLLATE Finnish_Swedish_BIN LIKE '% [a-z]%'
    ),

--- Split those lastnames into two words,
--- FirstWord and SecondWord:
     c2 AS (
    SELECT PassengerID,
           LastName,
           LEFT(LastName, CHARINDEX(' ', LastName)-1) AS FirstWord,
           SUBSTRING(LastName, CHARINDEX(' ', LastName)+1, 100) AS SecondWord
    FROM c1)

--- ProperLastName = the first word
---                + the second word (proper case)
SELECT PassengerID,
       LastName,
       FirstWord+' '+
		    UPPER(LEFT(SecondWord, 1))+
			LOWER(SUBSTRING(SecondWord, 2, 100)) AS ProperLastName
FROM c2;













--- Find passengers where the lastname consists of two
--- words, the second of which starts with a lower-case
--- character.
WITH c1 AS (
    SELECT PassengerID, FirstName, LastName
    FROM Booking.Passengers
    WHERE LastName COLLATE Finnish_Swedish_BIN LIKE '% [a-z]%'
    ),

--- Split those lastnames into two words,
--- FirstWord and SecondWord:
     c2 AS (
    SELECT PassengerID,
           LastName,
           LEFT(LastName, CHARINDEX(' ', LastName)-1) AS FirstWord,
           SUBSTRING(LastName, CHARINDEX(' ', LastName)+1, 100) AS SecondWord
    FROM c1),

--- ProperLastName = the first word
---                + the second word (proper case)
     c3 AS (
    SELECT PassengerID,
           LastName,
           FirstWord+' '+
		      UPPER(LEFT(SecondWord, 1))+
			  LOWER(SUBSTRING(SecondWord, 2, 100)) AS ProperLastName
    FROM c2)

--- You could try this:
UPDATE p
SET p.LastName=c3.ProperLastName
FROM Booking.Passengers AS p
INNER JOIN c3 ON p.PassengerID=c3.PassengerID;


--> Estimated cost = 20,9
--  two Index Scan operators on Booking.Passenger









--- Find passengers where the lastname consists of two
--- words, the second of which starts with a lower-case
--- character.
WITH c1 AS (
    SELECT PassengerID, FirstName, LastName
    FROM Booking.Passengers
    WHERE LastName COLLATE Finnish_Swedish_BIN LIKE '% [a-z]%'
    ),

--- Split those lastnames into two words,
--- FirstWord and SecondWord:
     c2 AS (
    SELECT PassengerID,
           LastName,
           LEFT(LastName, CHARINDEX(' ', LastName)-1) AS FirstWord,
           SUBSTRING(LastName, CHARINDEX(' ', LastName)+1, 100) AS SecondWord
    FROM c1),

--- ProperLastName = the first word
---                + the second word (proper case)
     c3 AS (
    SELECT PassengerID,
           LastName,
           FirstWord+' '+
		      UPPER(LEFT(SecondWord, 1))+
			  LOWER(SUBSTRING(SecondWord, 2, 100)) AS ProperLastName
    FROM c2)

--- Apply the UPDATE:
UPDATE c3
SET c3.LastName=c3.ProperLastName
FROM c3;

--> Estimated cost = 15,6
--  _single_ Index Scan operators on Booking.Passenger
