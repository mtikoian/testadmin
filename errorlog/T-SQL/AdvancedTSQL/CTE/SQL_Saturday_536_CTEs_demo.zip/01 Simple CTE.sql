USE Flygbolaget;



--- A simple subquery (actually called a "derived table")
SELECT PassengerID, DisplayName
FROM (
    SELECT PassengerID,
           FirstName+' '+LastName AS DisplayName
    FROM Booking.Passengers
    WHERE ContractID IS NOT NULL
    ) AS x
WHERE DisplayName='Alonso Vasquez';







--- Same query, written as a common table expression,
--- which we've aliased "x":
WITH x AS (
    SELECT PassengerID,
           FirstName+' '+LastName AS DisplayName
    FROM Booking.Passengers
    WHERE ContractID IS NOT NULL
    )

--- ... used here:
SELECT PassengerID, DisplayName
FROM x
WHERE DisplayName='Alonso Vasquez';





