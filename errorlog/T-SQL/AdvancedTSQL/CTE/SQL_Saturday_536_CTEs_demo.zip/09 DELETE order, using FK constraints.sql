USE Flygbolaget;



--- Tables:
WITH tbl AS (
    SELECT o.[object_id], s.name+'.'+o.name AS name
    FROM sys.tables AS o
    INNER JOIN sys.schemas AS s ON o.[schema_id]=s.[schema_id]),

--- Foreign key constraints:
     refs AS (
    SELECT DISTINCT parent_object_id, referenced_object_id
    FROM sys.foreign_keys
    WHERE parent_object_id!=referenced_object_id),

--- Recursive CTE:
     rcte AS (
	--- Anchor: every table that isn't REFERENCED by a
	---         foreign key constraint. These are "lvl" 1:
    SELECT 1 AS lvl, tbl.[object_id], tbl.name
    FROM tbl
    WHERE tbl.[object_id] NOT IN (SELECT referenced_object_id FROM refs)

    UNION ALL

    --- Recursion: work our way "up" through the FK
	---            constraints, adding 1 to "lvl" each step:
	SELECT rcte.lvl+1, tbl.[object_id], tbl.name
    FROM rcte
    INNER JOIN refs ON refs.parent_object_id=rcte.[object_id]
    INNER JOIN tbl ON refs.referenced_object_id=tbl.[object_id])

SELECT MAX(lvl) AS lvl, 'DELETE FROM '+name AS referencing_table

		--- ... for verification purposes:
		  ,SUBSTRING(ISNULL(CAST(
		   (SELECT ', '+tbl.name
			FROM refs
			INNER JOIN tbl ON refs.referenced_object_id=tbl.[object_id]
			WHERE refs.parent_object_id=rcte.[object_id]
			ORDER BY tbl.name
			FOR XML PATH(''), TYPE) AS varchar(max)), ''), 3, 1000) AS referenced_tables

FROM rcte
GROUP BY [object_id], name
ORDER BY MAX(lvl), name;
