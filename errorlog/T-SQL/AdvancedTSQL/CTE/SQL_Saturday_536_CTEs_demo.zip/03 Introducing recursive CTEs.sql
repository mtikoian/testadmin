
--- A very simple CTE
WITH rcte AS (
    SELECT 1 AS i
    )

SELECT * FROM rcte;












--- A very simple recursive CTE
WITH rcte AS (
    SELECT 1 AS i			-- Anchor

    UNION ALL

    SELECT i+1 FROM rcte    -- Recursion
    )

SELECT * FROM rcte
/*
Msg 530, Level 16, State 1, Line 15
The statement terminated. The maximum recursion 100 has been exhausted before statement completion.
*/











--- Recursive CTE with an anchor, recursion AND stop condition:
WITH rcte AS (
    SELECT 1 AS i			-- Anchor

    UNION ALL

    SELECT i+1 FROM rcte    -- Recursion
    WHERE i<50				-- Stop condition
	)

SELECT * FROM rcte;













--- Recursive CTE with an anchor, recursion AND stop condition:
--- What about 5000 recursions?
WITH rcte AS (
    SELECT 1 AS i			-- Anchor

    UNION ALL

    SELECT i+1 FROM rcte    -- Recursion
    WHERE i<5000			-- Stop condition
	)

SELECT * FROM rcte;













--- OPTION (MAXRECURSION) sets the upper recursion limit,
--- which is 100 by default:
WITH rcte AS (
    SELECT 1 AS i			-- Anchor

    UNION ALL

    SELECT i+1 FROM rcte    -- Recursion
    WHERE i<5000			-- Stop condition
	)

SELECT * FROM rcte
OPTION (MAXRECURSION 4999);	-- MAXRECURSION










--- OPTION (MAXRECURSION 0) allows for an infinite number of
--- recursion. Because of this, we also no longer require
--- the "Assert" operator in the queryplan:
WITH rcte AS (
    SELECT 1 AS i			-- Anchor

    UNION ALL

    SELECT i+1 FROM rcte    -- Recursion
    WHERE i<5000			-- Stop condition
	)

SELECT * FROM rcte
OPTION (MAXRECURSION 0);	-- MAXRECURSION 0=allow infinite
