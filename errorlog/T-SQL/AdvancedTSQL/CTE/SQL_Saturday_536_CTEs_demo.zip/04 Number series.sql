
/*
	Fibonacci series:

	a	  b
	--- ---
	0	  1 =  1
	1	0+1 =  1
	1	1+1 =  2
	2	2+1 =  3
	3	3+2 =  5
	5	5+3 =  8
	8	8+5 = 13

	...
*/

WITH fibonacci AS (
    SELECT 0 AS a, 1 AS b	-- Anchor

    UNION ALL

    SELECT b AS a, a+b AS b
    FROM fibonacci			-- Recursion
    WHERE a<100000000)		-- Stop condition

SELECT a
FROM fibonacci;
