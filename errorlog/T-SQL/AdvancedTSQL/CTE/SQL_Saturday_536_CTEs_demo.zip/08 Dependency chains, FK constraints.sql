USE Flygbolaget;



--- These are all the tables in the database:
WITH tbl AS (
    SELECT o.[object_id], s.name+'.'+o.name AS name
    FROM sys.tables AS o
    INNER JOIN sys.schemas AS s ON
		o.[schema_id]=s.[schema_id])

SELECT * FROM tbl;






--- .. and all the foreign key constraints between them:
WITH refs AS (
    SELECT DISTINCT parent_object_id, referenced_object_id
    FROM sys.foreign_keys
    WHERE parent_object_id!=referenced_object_id)

SELECT * FROM refs;












--- Tables:
WITH tbl AS (
    SELECT o.[object_id], s.name+'.'+o.name AS name
    FROM sys.tables AS o
    INNER JOIN sys.schemas AS s ON
		o.[schema_id]=s.[schema_id]),

--- Foreign key constraints:
     refs AS (
    SELECT DISTINCT parent_object_id, referenced_object_id
    FROM sys.foreign_keys
    WHERE parent_object_id!=referenced_object_id),



--- Recursive common table expression...
     rcte AS (

	--- Anchor: all tables that do not reference any
	---         other tables:
    SELECT 1 AS lvl,
	       tbl.[object_id],
		   tbl.name,
		   CAST(tbl.name AS varchar(max)) AS [path]
    FROM tbl
    WHERE tbl.[object_id] NOT IN (SELECT parent_object_id FROM refs)

    UNION ALL

    --- Recursion: join the CTE to the dependencies, and
	---            then the referenced table(s):
	SELECT rcte.lvl+1,
		   tbl.[object_id],
		   tbl.name,
		   --- Build up "path"
		   CAST(rcte.[path] + ' ---< '+tbl.name AS varchar(max))
    FROM rcte
    INNER JOIN refs ON refs.referenced_object_id=rcte.[object_id]
    INNER JOIN tbl ON refs.parent_object_id=tbl.[object_id])

SELECT DISTINCT [path]
FROM rcte
ORDER BY [path];
