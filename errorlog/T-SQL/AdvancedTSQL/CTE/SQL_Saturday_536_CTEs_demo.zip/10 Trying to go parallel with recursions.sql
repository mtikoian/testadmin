USE Flygbolaget;
/*
	Timings measured on a SQL Server 2014 SP1 on an
	Azure Standard DS14 v2 (16 cores, 112 GB memory)
	with striped solid state drives.
*/

--- Setting up a work table:
SELECT DENSE_RANK() OVER (ORDER BY tl.TicketID, tl.PassengerID) AS TicketNumber,
	   ROW_NUMBER() OVER (PARTITION BY tl.TicketID, tl.PassengerID ORDER BY tl.Departure) AS LegNumber,
	   COUNT(*) OVER (PARTITION BY tl.TicketID, tl.PassengerID) AS LegCount,
	   l1.IATACode AS FromLocation, l2.IATACode AS ToLocation
INTO #legs
FROM Booking.TicketLegs AS tl
INNER JOIN Schedule.RouteSchedule AS rs ON tl.ScheduleID=rs.ScheduleID
INNER JOIN Schedule.[Routes] AS r ON rs.RouteID=r.RouteID
INNER JOIN Schedule.Locations AS l1 ON r.FromLocationID=l1.LocationID
INNER JOIN Schedule.Locations AS l2 ON r.ToLocationID=l2.LocationID
WHERE tl.Departure>={d '2015-01-01'} AND tl.Departure<{d '2015-04-01'};

CREATE UNIQUE CLUSTERED INDEX PK ON #legs (TicketNumber, LegNumber) WITH (DATA_COMPRESSION=PAGE);

SET STATISTICS IO, TIME ON;

--------------------------------------------------------------------------------------









--- Straing recursive common table expression:
WITH rcte AS (
	--- Anchor: Start with LegNumber=1 for each ticket.
	SELECT TicketNumber, LegNumber, LegCount,
	       CAST(FromLocation+'-'+ToLocation AS varchar(100)) AS Itinerary
	FROM #legs
	WHERE LegNumber=1

	UNION ALL

	--- Recursion: Get the next leg (LegNumber+1), add
	---            to the "Itinerary" column.
	SELECT rcte.TicketNumber, l.LegNumber, rcte.LegCount,
		   CAST(rcte.Itinerary+'-'+l.ToLocation AS varchar(100))
	FROM rcte
	INNER JOIN #legs AS l ON
		rcte.TicketNumber=l.TicketNumber AND
		rcte.LegNumber+1=l.LegNumber)

SELECT Itinerary, COUNT(*)
FROM rcte
WHERE LegCount=LegNumber		--- Only show the complete itinerary.
GROUP BY Itinerary
ORDER BY COUNT(*) DESC;

--- * 11,8 million reads
--- * 15.4 seconds
--- * won't go parallel
--- * 1,5 MB memory grant.














--- Can it be parallelized using CROSS APPLY?
WITH rcte AS (
	--- Anchor: Start with LegNumber=1 for each ticket.
	SELECT TicketNumber, LegNumber, LegCount, FromLocation,
	       CAST(FromLocation+'-'+ToLocation AS varchar(100)) AS Itinerary
	FROM #legs
	WHERE LegNumber=1

	UNION ALL

	--- Recursion: Get the next leg (LegNumber+1), add
	---            to the "Itinerary" column.
	SELECT rcte.TicketNumber, l.LegNumber, rcte.LegCount, rcte.FromLocation,
		   CAST(rcte.Itinerary+'-'+l.ToLocation AS varchar(100))
	FROM rcte
	INNER JOIN #legs AS l ON
		rcte.TicketNumber=l.TicketNumber AND
		rcte.LegNumber+1=l.LegNumber)

SELECT x.Itinerary, x.[count]
FROM Schedule.Locations AS l
CROSS APPLY (
	--- CROSS APPLY this query once for each location code (we have 14 of those):
	SELECT Itinerary, COUNT(*) AS [count]
	FROM rcte
	WHERE rcte.FromLocation=l.IATACode AND
		  rcte.LegCount=rcte.LegNumber		--- Only show the complete itinerary.
	GROUP BY Itinerary) AS x
ORDER BY [count] DESC;

--- About the same as the original query:
--- * 11,8 million reads (same as baseline)
--- * 16.6 seconds (1.2 seconds slower)
--- * still not parallel, though.
--- * 2 MB memory grant (0.5 MB more than baseline)
















--- Ok, let's force a Loop Join using hints (ok, getting weird now).
WITH rcte AS (
	--- Anchor: Start with LegNumber=1 for each ticket.
	SELECT TicketNumber, LegNumber, LegCount, FromLocation,
	       CAST(FromLocation+'-'+ToLocation AS varchar(100)) AS Itinerary
	FROM #legs
	WHERE LegNumber=1

	UNION ALL

	--- Recursion: Get the next leg (LegNumber+1), add
	---            to the "Itinerary" column.
	SELECT rcte.TicketNumber, l.LegNumber, rcte.LegCount, rcte.FromLocation,
		   CAST(rcte.Itinerary+'-'+l.ToLocation AS varchar(100))
	FROM rcte
	INNER JOIN #legs AS l ON
		rcte.TicketNumber=l.TicketNumber AND
		rcte.LegNumber+1=l.LegNumber)

SELECT rcte.Itinerary, COUNT(*)
FROM Schedule.Locations AS l
--- Forcing a LOOP JOIN:
INNER LOOP JOIN rcte ON rcte.FromLocation=l.IATACode
WHERE rcte.LegCount=rcte.LegNumber		--- Only show the complete itinerary.
GROUP BY rcte.Itinerary
ORDER BY COUNT(*) DESC;

--- * 190 million reads! (almost exactly 16 times the benchmark)
--- * This time, it's parallel.
--- * 223 cpu seconds, 18.9 seconds elapsed (still 3.5 seconds slower)
--- * 12 MB memory grant (about 8 times that of the benchmark)










--- Maybe a good index can speed things up?
CREATE INDEX IX_Location ON #legs (FromLocation, TicketNumber)
	INCLUDE (LegNumber, LegCount, ToLocation)
	WHERE (LegNumber=1)
	WITH (DATA_COMPRESSION=PAGE);

--- After applying the index:

--- * 190 million reads (no change with the index)
--- * still parallel
--- * 220 cpu seconds, ran for 18.4 seconds (marginally faster with the index, still 3 seconds slower than benchmark)
--- * 12 MB memory grant (same as without the index)









--- OFF-TOPIC:







--- What about a "step-by-step" recursion, using a temp table?

--- "Anchor": Start with LegNumber=1 for each ticket.
SELECT TicketNumber, LegNumber, LegCount, FromLocation,
	    CAST(FromLocation+'-'+ToLocation AS varchar(100)) AS Itinerary
INTO #tickets
FROM #legs
WHERE LegNumber=1;

CREATE UNIQUE CLUSTERED INDEX PK ON #tickets (TicketNumber);

DECLARE @LegNumber tinyint=2;
WHILE (1=1) BEGIN;
	--- "Recursion": Get the next leg (LegNumber+1), add
	---            to the "Itinerary" column.
	UPDATE rcte
	SET rcte.Itinerary=CAST(rcte.Itinerary+'-'+l.ToLocation AS varchar(100))
	FROM #tickets AS rcte
	INNER JOIN #legs AS l ON
		rcte.TicketNumber=l.TicketNumber AND
		@LegNumber=l.LegNumber;

	IF (@@ROWCOUNT=0) BREAK;
	SET @LegNumber=@LegNumber+1;
END;

SELECT Itinerary, COUNT(*)
FROM #tickets
GROUP BY Itinerary
ORDER BY COUNT(*) DESC;

DROP TABLE #tickets;

--- * Just 55 000 reads (as opposed to 11.8 million)
--- * anchor, index and output was parallel, the recursions were too cheap.
--- * 4.8 cpu seconds, ran for just 3.0 seconds! 
--- * The index comes with a massive 200+ MB memory grant,
---   the output step uses about 30 MB. The recursions required none.















--- The chimpanzee approach: hard-coded "recursions":
WITH cte AS (
	SELECT l1.FromLocation+'-'+l1.ToLocation+
		   ISNULL('-'+l2.ToLocation, '')+
		   ISNULL('-'+l3.ToLocation, '')+
		   ISNULL('-'+l4.ToLocation, '')+
		   ISNULL('-'+l5.ToLocation, '')+
		   ISNULL('-'+l6.ToLocation, '')+
		   ISNULL('-'+l7.ToLocation, '')+
		   ISNULL('-'+l8.ToLocation, '') AS Itinerary
	FROM #legs AS l1
	LEFT JOIN #legs AS l2 ON l1.TicketNumber=l2.TicketNumber AND l2.LegNumber=2 AND l1.LegCount>=2
	LEFT JOIN #legs AS l3 ON l1.TicketNumber=l3.TicketNumber AND l3.LegNumber=3 AND l1.LegCount>=3
	LEFT JOIN #legs AS l4 ON l1.TicketNumber=l4.TicketNumber AND l4.LegNumber=4 AND l1.LegCount>=4
	LEFT JOIN #legs AS l5 ON l1.TicketNumber=l5.TicketNumber AND l5.LegNumber=5 AND l1.LegCount>=5
	LEFT JOIN #legs AS l6 ON l1.TicketNumber=l6.TicketNumber AND l6.LegNumber=6 AND l1.LegCount>=6
	LEFT JOIN #legs AS l7 ON l1.TicketNumber=l7.TicketNumber AND l7.LegNumber=7 AND l1.LegCount>=7
	LEFT JOIN #legs AS l8 ON l1.TicketNumber=l8.TicketNumber AND l8.LegNumber=8 AND l1.LegCount>=8
	WHERE l1.LegNumber=1)

SELECT Itinerary, COUNT(*)
FROM cte
GROUP BY Itinerary
ORDER BY COUNT(*) DESC;

--- * Just 14 000 reads (as opposed to 11.8 million)
--- * parallel indeed.
--- * 4.5 cpu seconds, runs for just .8 seconds! 
--- * .. but comes with a whopping 293 MB memory grant!

