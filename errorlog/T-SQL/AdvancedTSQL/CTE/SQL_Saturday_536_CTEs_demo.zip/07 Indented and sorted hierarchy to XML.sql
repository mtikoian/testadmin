USE Flygbolaget;


WITH emp AS (
	--- These are all our employees:
    SELECT e.EmployeeID, e.FirstName+' '+e.LastName AS DisplayName, ep.ManagerID
    FROM Staff.EmployeePositions AS ep
    INNER JOIN Staff.Employees AS e ON ep.EmployeeID=e.EmployeeID
    WHERE ep.StartDate<={d '2015-01-01'} AND
          ep.EndDate>={d '2015-01-01'}),

     rcte AS (
    --- Anchor: The top level of the hierarchy.
	--- In this case, employees where ManagerID=NULL
    SELECT EmployeeID,
	       DisplayName,
		   ManagerID,
		   0 AS lvl,
		   --- Sort column
		   CAST(STR(ROW_NUMBER() OVER (ORDER BY DisplayName), 4, 0)
		            AS varchar(max)) AS sort
	FROM emp
	WHERE ManagerID IS NULL

	UNION ALL

	--- Recursion: Get all employees that belong
	--- to "this" manager:
    SELECT emp.EmployeeID,
		   emp.DisplayName,
		   emp.ManagerID,
		   rcte.lvl+1,
		   --- Append to the sort column
		   CAST(rcte.sort+
		        STR(ROW_NUMBER() OVER (
						PARTITION BY rcte.EmployeeID
						ORDER BY      emp.DisplayName), 4, 0)
				    AS varchar(max)) AS sort
    FROM rcte
    INNER JOIN emp ON emp.ManagerID=rcte.EmployeeID)

SELECT '<Employee ID="' AS xml_1,
	   EmployeeID AS xml_2,
	   '" DisplayName="' AS xml_3,
	   DisplayName AS xml_4,
	   '">' AS xml_5,
       --- If the next (LEAD'ing) "lvl" is less than the current,
	   --- we want to close that number of <Employee> elements:
       (CASE WHEN LEAD(lvl, 1, 0) OVER (ORDER BY sort)<=lvl
             --- Close (1+ {current "lvl"} - {next "lvl"}) elements:
             THEN REPLICATE('</Employee>', 1+lvl-LEAD(lvl, 1, 0) OVER (ORDER BY sort))
             ELSE '' END) AS xml_6,
	   lvl,
	   LEAD(lvl, 1, 0) OVER (ORDER BY sort) AS [LEAD(lvl, 1, 0)]
FROM rcte
ORDER BY sort;






















WITH emp AS (
	--- These are all our employees:
    SELECT e.EmployeeID, e.FirstName+' '+e.LastName AS DisplayName, ep.ManagerID
    FROM Staff.EmployeePositions AS ep
    INNER JOIN Staff.Employees AS e ON ep.EmployeeID=e.EmployeeID
    WHERE ep.StartDate<={d '2015-01-01'} AND
          ep.EndDate>={d '2015-01-01'}),

     rcte AS (
    --- Anchor: The top level of the hierarchy.
	--- In this case, employees where ManagerID=NULL
    SELECT EmployeeID,
	       DisplayName,
		   ManagerID,
		   0 AS lvl,
		   --- Sort column
		   CAST(STR(ROW_NUMBER() OVER (ORDER BY DisplayName), 4, 0)
		            AS varchar(max)) AS sort
	FROM emp
	WHERE ManagerID IS NULL

	UNION ALL

	--- Recursion: Get all employees that belong
	--- to "this" manager:
    SELECT emp.EmployeeID,
		   emp.DisplayName,
		   emp.ManagerID,
		   rcte.lvl+1,
		   --- Append to the sort column
		   CAST(rcte.sort+
		        STR(ROW_NUMBER() OVER (
						PARTITION BY rcte.EmployeeID
						ORDER BY      emp.DisplayName), 4, 0)
				    AS varchar(max)) AS sort
    FROM rcte
    INNER JOIN emp ON emp.ManagerID=rcte.EmployeeID)

SELECT CONCAT(
		   '<Employee ID="',
		   EmployeeID,
		   '" DisplayName="',
		   DisplayName,
		   '">',
		   --- If the next (LEAD'ing) "lvl" is less than the current,
		   --- we want to close that number of <Employee> elements:
		   (CASE WHEN LEAD(lvl, 1, 0) OVER (ORDER BY sort)<=lvl
				 --- Close (1+ {current "lvl"} - {next "lvl"}) elements:
				 THEN REPLICATE('</Employee>', 1+lvl-LEAD(lvl, 1, 0) OVER (ORDER BY sort))
				 ELSE '' END)
	   ) AS xml_string
FROM rcte
ORDER BY sort;


















DECLARE @xml varchar(max)='';

WITH emp AS (
	--- These are all our employees:
    SELECT e.EmployeeID, e.FirstName+' '+e.LastName AS DisplayName, ep.ManagerID
    FROM Staff.EmployeePositions AS ep
    INNER JOIN Staff.Employees AS e ON ep.EmployeeID=e.EmployeeID
    WHERE ep.StartDate<={d '2015-01-01'} AND
          ep.EndDate>={d '2015-01-01'}),

     rcte AS (
    --- Anchor: The top level of the hierarchy.
	--- In this case, employees where ManagerID=NULL
    SELECT EmployeeID,
	       DisplayName,
		   ManagerID,
		   0 AS lvl,
		   --- Sort column
		   CAST(STR(ROW_NUMBER() OVER (ORDER BY DisplayName), 4, 0)
		            AS varchar(max)) AS sort
	FROM emp
	WHERE ManagerID IS NULL

	UNION ALL

	--- Recursion: Get all employees that belong
	--- to "this" manager:
    SELECT emp.EmployeeID,
		   emp.DisplayName,
		   emp.ManagerID,
		   rcte.lvl+1,
		   --- Append to the sort column
		   CAST(rcte.sort+
		        STR(ROW_NUMBER() OVER (
						PARTITION BY rcte.EmployeeID
						ORDER BY      emp.DisplayName), 4, 0)
				    AS varchar(max)) AS sort
    FROM rcte
    INNER JOIN emp ON emp.ManagerID=rcte.EmployeeID)

SELECT @xml=@xml+CONCAT(
		   '<Employee ID="',
		   EmployeeID,
		   '" DisplayName="',
		   DisplayName,
		   '">',
		   --- If the next (LEAD'ing) "lvl" is less than the current,
		   --- we want to close that number of <Employee> elements:
		   (CASE WHEN LEAD(lvl, 1, 0) OVER (ORDER BY sort)<=lvl
				 --- Close (1+ {current "lvl"} - {next "lvl"}) elements:
				 THEN REPLICATE('</Employee>', 1+lvl-LEAD(lvl, 1, 0) OVER (ORDER BY sort))
				 ELSE '' END)
	   )
FROM rcte
ORDER BY sort;

SELECT CAST(@xml AS xml);
