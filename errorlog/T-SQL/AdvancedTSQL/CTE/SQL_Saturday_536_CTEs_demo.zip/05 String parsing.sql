
DECLARE @text varchar(max)='Lorem ipsum dolor sit amet, cum te debet deseruisse. Inani labitur mea te, eu nusquam
scriptorem instructior mel, mei in accumsan efficiendi. In detracto adipisci atomorum eam, meis probatus reprimique
has ex, eu liber mediocrem vim. Ius eu assum soluta debitis, per primis molestie ad. Ut per quodsi mandamus, inani
commune honestatis usu in. His cu adhuc eripuit. At eros dicam populo vis, ut modo simul voluptatibus eam, quando
interpretaris ut pri.

Eros noluisse convenire per ad, ne cibo detracto democritum eum, case apeirian adipiscing ad mei. Ea nam illum nostrum
intellegebat, iudico bonorum no quo. Est ea dolore tincidunt, te nec prompta iudicabit. Meis impedit vis no, ei facilisis
reprehendunt eos, et veniam theophrastus eum.

Mei malis intellegebat no, adhuc blandit vis ex. Vis mundi ceteros id, id unum laboramus mel. At tation nominati pri, at
usu mazim explicari. Atqui concludaturque mea ne. Vim eu quando forensibus. Hinc cetero concludaturque pri et.

Propriae evertitur ea usu. Id nam tempor dolorem interpretaris. Veniam audire blandit nec ne. Sed legere verterem ne.
Ut nam numquam noluisse, ex nostrud scribentur mei. Et quando quaerendum definitiones eum, usu iriure aliquam id. Habemus
adipiscing et nec, an vix posse clita oportere.

Nam at dictas invidunt antiopam, nam ut feugiat iracundia. In petentium accommodare nam, quaeque ceteros ex his. Qui zril
audire recusabo no, omnis ceteros vis id, est id soluta complectitur. Eam eros audire ad, cu quo nostro viderer, homero
honestatis mel id.

Vim eu affert mentitum assentior, pro omnis tibique referrentur at per.';



WITH rcte AS (
    --- Anchor:
	--- "word" is blank, "remain" is the entire text string.
    SELECT CAST(NULL AS varchar(100)) AS word,
           @text AS remain

    UNION ALL

    --- Recursion:
	--- 1. Find the offset in the "remain" column where the first non-alphanumeric
	---    character is found. This is "x.offset"
	--- 2. LEFT(remain, offset) becomes "word"
	--- 3. SUBSTRIG(remain, offset) becomes the new "remain"
	--- 4. Rinse, repeat.
    SELECT CAST(     LEFT(rcte.remain, x.offset-1)                   AS varchar(100)) AS word,
           CAST(SUBSTRING(rcte.remain, x.offset+1, LEN(rcte.remain)) AS varchar(max)) AS remain
    FROM rcte
    CROSS APPLY (
        --- What is the offset of the first non-alphanumeric
		--- character in "remain"?
        VALUES (PATINDEX('%[^a-z0-9]%', rcte.remain+'.'))
        ) AS x(offset)

    --- Stop condition: keep going until "remain" is empty.
	WHERE rcte.remain!='')

SELECT word
FROM rcte
WHERE word!=''
OPTION (MAXRECURSION 0);














--- OFF-TOPIC:

--- Is this really a recursive problem?
--- Isn't there a better way to write this?

--- Actually, this task is not strictly recursive, but rather
--- a serial problem. As such, we could just batch process it
--- by converting the text string to an XML blob and parsing
--- the XML.

--- 1. Convert:
DECLARE @xml xml=
     CAST('<word>'
	     +REPLACE(
			REPLACE(
				REPLACE(
					REPLACE(@text,
						CHAR(13)+CHAR(10), ' '),
						'.', ' '),
						',', ' '),
						' ', '</word><word>')
	     +'</word>' AS xml);

--- 2. Parse:
WITH word_cte AS (
	SELECT word.blob.value('.', 'varchar(100)') AS word
	FROM @xml.nodes('/word') AS word(blob)
	)

--- 3. Filter and return:
SELECT word
FROM word_cte
WHERE word!='';
