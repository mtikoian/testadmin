USE Flygbolaget;





--- Here are some employees and managers.
---
--- We'll package them neatly in a CTE do avoid having to
--- re-write all the join and filter clause.
WITH emp AS (
    SELECT e.EmployeeID, e.FirstName+' '+e.LastName AS DisplayName, ep.ManagerID
    FROM Staff.EmployeePositions AS ep
    INNER JOIN Staff.Employees AS e ON ep.EmployeeID=e.EmployeeID
    WHERE ep.StartDate<={d '2015-01-01'} AND
          ep.EndDate>={d '2015-01-01'})

SELECT * FROM emp;







WITH emp AS (
	--- These are all our employees:
    SELECT e.EmployeeID, e.FirstName+' '+e.LastName AS DisplayName, ep.ManagerID
    FROM Staff.EmployeePositions AS ep
    INNER JOIN Staff.Employees AS e ON ep.EmployeeID=e.EmployeeID
    WHERE ep.StartDate<={d '2015-01-01'} AND
          ep.EndDate>={d '2015-01-01'}),

     rcte AS (
    --- Anchor: The top level of the hierarchy.
	--- In this case, employees where ManagerID=NULL
    SELECT EmployeeID,
	       DisplayName,
		   ManagerID,
		   0 AS lvl
	FROM emp
	WHERE ManagerID IS NULL

	UNION ALL

	--- Recursion: Get all employees that belong
	--- to "this" manager:
    SELECT emp.EmployeeID,
		   emp.DisplayName,
		   emp.ManagerID,
		   rcte.lvl+1
    FROM rcte
    INNER JOIN emp ON emp.ManagerID=rcte.EmployeeID)

SELECT *
FROM rcte;














--- Let's add a sort column:

WITH emp AS (
	--- These are all our employees:
    SELECT e.EmployeeID, e.FirstName+' '+e.LastName AS DisplayName, ep.ManagerID
    FROM Staff.EmployeePositions AS ep
    INNER JOIN Staff.Employees AS e ON ep.EmployeeID=e.EmployeeID
    WHERE ep.StartDate<={d '2015-01-01'} AND
          ep.EndDate>={d '2015-01-01'}),

     rcte AS (
    --- Anchor: The top level of the hierarchy.
	--- In this case, employees where ManagerID=NULL
    SELECT EmployeeID,
	       DisplayName,
		   ManagerID,
		   0 AS lvl,
		   --- Sort column
		   CAST(STR(ROW_NUMBER() OVER (ORDER BY DisplayName), 4, 0)
		            AS varchar(max)) AS sort
	FROM emp
	WHERE ManagerID IS NULL

	UNION ALL

	--- Recursion: Get all employees that belong
	--- to "this" manager:
    SELECT emp.EmployeeID,
		   emp.DisplayName,
		   emp.ManagerID,
		   rcte.lvl+1,
		   --- Append to the sort column
		   CAST(rcte.sort+
		        STR(ROW_NUMBER() OVER (
						PARTITION BY rcte.EmployeeID
						ORDER BY      emp.DisplayName), 4, 0)
				    AS varchar(max)) AS sort
    FROM rcte
    INNER JOIN emp ON emp.ManagerID=rcte.EmployeeID)

SELECT *
FROM rcte;













--- ORDER BY that sort column and add
--- an indent that uses the "lvl" column:

WITH emp AS (
	--- These are all our employees:
    SELECT e.EmployeeID, e.FirstName+' '+e.LastName AS DisplayName, ep.ManagerID
    FROM Staff.EmployeePositions AS ep
    INNER JOIN Staff.Employees AS e ON ep.EmployeeID=e.EmployeeID
    WHERE ep.StartDate<={d '2015-01-01'} AND
          ep.EndDate>={d '2015-01-01'}),

     rcte AS (
    --- Anchor: The top level of the hierarchy.
	--- In this case, employees where ManagerID=NULL
    SELECT EmployeeID,
	       DisplayName,
		   ManagerID,
		   0 AS lvl,
		   --- Sort column
		   CAST(STR(ROW_NUMBER() OVER (ORDER BY DisplayName), 4, 0)
		            AS varchar(max)) AS sort
	FROM emp
	WHERE ManagerID IS NULL

	UNION ALL

	--- Recursion: Get all employees that belong
	--- to "this" manager:
    SELECT emp.EmployeeID,
		   emp.DisplayName,
		   emp.ManagerID,
		   rcte.lvl+1,
		   --- Append to the sort column
		   CAST(rcte.sort+
		        STR(ROW_NUMBER() OVER (
						PARTITION BY rcte.EmployeeID
						ORDER BY      emp.DisplayName), 4, 0)
				    AS varchar(max)) AS sort
    FROM rcte
    INNER JOIN emp ON emp.ManagerID=rcte.EmployeeID)

SELECT EmployeeID,
       REPLICATE('   ', lvl)+DisplayName AS IndentedDisplayName
FROM rcte
ORDER BY sort;
