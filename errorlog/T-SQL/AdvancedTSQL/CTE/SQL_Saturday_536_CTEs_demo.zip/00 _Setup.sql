USE Flygbolaget;
GO

UPDATE Booking.Passengers
SET LastName=UPPER(LEFT(LastName, 1))+LOWER(SUBSTRING(LastName, 2, LEN(LastName)))
WHERE LastName LIKE '% %'
