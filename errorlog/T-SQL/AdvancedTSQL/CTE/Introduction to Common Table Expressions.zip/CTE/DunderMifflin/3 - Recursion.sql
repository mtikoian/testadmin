/**************************************
***************************************
 CTE Demo
 Presenter: Vicky Harp
***************************************
***************************************/

set nocount on
set statistics io on

use DunderMifflin
	
	
/**************************************
 List Dwight's manager
***************************************/	
;with cte_Manager(ManagerEmployeeID)
as
(
	select 
	     ManagerID 
	from Employee
	where
	     FirstName = 'Dwight'
	     and LastName = 'Schrute'
)
select
     FirstName,
     LastName
from Employee
	inner join cte_Manager
	on Employee.EmployeeID = cte_Manager.ManagerEmployeeID
	

/**************************************
 List Michael's manager
***************************************/	
;with cte_Manager(ManagerEmployeeID)
as
(
	select 
	     ManagerID 
	from Employee
	where
	     FirstName = 'Michael'
	     and LastName = 'Scott'
)
select
     FirstName,
     LastName
from Employee
	inner join cte_Manager
	on Employee.EmployeeID = cte_Manager.ManagerEmployeeID	


/**************************************
 Recursively list all managers 
 to Dwight
***************************************/
;with cte_Managers(ManagerEmployeeID)
as
(
	select 
	     EmployeeID 
	from Employee
	where
	     FirstName = 'Dwight'
	     and LastName = 'Schrute'
	union all
	select
		 ManagerID
	from Employee
		 inner join cte_Managers
	on 
		 Employee.EmployeeID = cte_Managers.ManagerEmployeeID
)
select
	EmployeeID,
	FirstName,
	LastName,
	ManagerID
from cte_Managers
	 inner join Employee
	 on Employee.EmployeeID = cte_Managers.ManagerEmployeeID
	
	


