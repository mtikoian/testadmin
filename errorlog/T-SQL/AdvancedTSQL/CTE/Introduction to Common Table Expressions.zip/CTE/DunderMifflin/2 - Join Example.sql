/**************************************
***************************************
 CTE Demo
 Presenter: Vicky Harp
***************************************
***************************************/

set nocount on
set statistics io on

use DunderMifflin

exec sp_help 'SalesInvoice'

/***************************************
 Regular Join
***************************************/
select
	LastName,
	FirstName,
	count(*) as InvoiceCount
from SalesInvoice si
	inner join Employee e
	on si.EmployeeID = e.EmployeeID
where SalesDate between '1/1/2004' and '12/31/2004'
group by LastName,
	FirstName

/***************************************
 Same query with a CTE
***************************************/

;with cte_Invoices2004(EmployeeID, InvoiceCount)
as
(
	select
		EmployeeID,
		count(*)
	from SalesInvoice
	where SalesDate between '1/1/2004' and '12/31/2004'
	group by EmployeeID
)
select
	FirstName,
	LastName,
	InvoiceCount
from Employee e
	inner join cte_Invoices2004	cte_I
	on e.EmployeeID = cte_I.EmployeeID

/***************************************
 Imagine we wanted the total sales 
 number and the average monthly sales?
***************************************/

-- Step 1
;with cte_Invoices2004(EmployeeID, InvoiceCount, SalesMonth)
as
(
	select
		EmployeeID,
		count(*),
		datepart(month,SalesDate)  -- Add month
	from
		SalesInvoice
	where
		SalesDate between '1/1/2004' and '12/31/2004'
	group by
		EmployeeID,
		datepart(month, SalesDate) -- Add month
)
select
	FirstName,
	LastName,
	InvoiceCount,
	SalesMonth -- Add month
from
	Employee e
	inner join cte_Invoices2004	cte_I
	on e.EmployeeID = cte_I.EmployeeID


-- Now add a second CTE

;with cte_Invoices2004(EmployeeID, InvoiceCount, SalesMonth)
as
(
	select
		EmployeeID,
		count(*),
		datepart(month,SalesDate)
	from
		SalesInvoice
	where
		SalesDate between '1/1/2004' and '12/31/2004'
	group by EmployeeID, datepart(month, SalesDate)
),
cte_AverageSalesMonth(EmployeeID, TotalInvoiceCount, AvgMonthlySales)
as
(
	select
		EmployeeID,
		sum(InvoiceCount),
		avg(InvoiceCount)
	from
		cte_Invoices2004  -- This CTE is referencing the CTE above
	group by
		EmployeeID
)
select
	FirstName,
	LastName,
	TotalInvoiceCount,
	AvgMonthlySales
from
	Employee e
	inner join cte_AverageSalesMonth cte_A  -- The outer query references only 1 CTE
	on e.EmployeeID = cte_A.EmployeeID
