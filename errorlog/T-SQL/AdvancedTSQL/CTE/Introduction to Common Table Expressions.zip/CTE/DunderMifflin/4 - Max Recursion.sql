/**************************************
***************************************
 CTE Demo
 Presenter: Vicky Harp
***************************************
***************************************/

set nocount on
set statistics io on
set statistics time off

use DunderMifflin

/**************************************
 Incorrect recursion causes 
 an infinite loop
***************************************/	
;with cte_Managers(ManagerEmployeeID)
as
(
	select 
	     EmployeeID 
	from 
	     Employee
	where
	     FirstName = 'Dwight'
	     and LastName = 'Schrute'
	union all
	select
		EmployeeID  --- Not correct
	from
		Employee
		inner join cte_Managers
	on 
		Employee.EmployeeID = cte_Managers.ManagerEmployeeID
)
select
	EmployeeID,
	FirstName,
	LastName,
	ManagerID
from
	cte_Managers
	inner join Employee
	on Employee.EmployeeID = cte_Managers.ManagerEmployeeID



/**************************************
 By setting maxrecursion to 0 we can 
 create a true infinite loop
***************************************/	
;with cte_Managers(ManagerEmployeeID)
as
(
	select 
	     EmployeeID 
	from 
	     Employee
	where
	     FirstName = 'Dwight'
	     and LastName = 'Schrute'
	union all
	select
		EmployeeID  --- Not correct
	from
		Employee
		inner join cte_Managers
	on 
		Employee.EmployeeID = cte_Managers.ManagerEmployeeID
)
select
	EmployeeID,
	FirstName,
	LastName,
	ManagerID
from
	cte_Managers
	inner join Employee
	on Employee.EmployeeID = cte_Managers.ManagerEmployeeID
option (maxrecursion 0)		
	
/**************************************
 By setting maxrecursion to 10 
 we exit the loop a bit more quickly
***************************************/	
;with cte_Managers(ManagerEmployeeID)
as
(
	select 
	     EmployeeID 
	from 
	     Employee
	where
	     FirstName = 'Dwight'
	     and LastName = 'Schrute'
	union all
	select
		EmployeeID  --- Not correct
	from
		Employee
		inner join cte_Managers
	on 
		Employee.EmployeeID = cte_Managers.ManagerEmployeeID
)
select
	EmployeeID,
	FirstName,
	LastName,
	ManagerID
from
	cte_Managers
	inner join Employee
	on Employee.EmployeeID = cte_Managers.ManagerEmployeeID
option (maxrecursion 10)		

