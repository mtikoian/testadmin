/**************************************
***************************************
 CTE Demo
 Presenter: Vicky Harp
***************************************
***************************************/

use DunderMifflin
drop index Employee.IX_Employee_LastName_FirstName