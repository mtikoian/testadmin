/**************************************
***************************************
 CTE Demo
 Presenter: Vicky Harp
***************************************
***************************************/

set nocount on
set statistics io on

use DunderMifflin

/***************************************
 Example Data
***************************************/

select * from Employee

create index IX_Employee_LastName_FirstName on
Employee(LastName,FirstName) include (ManagerID)

/***************************************
 Subquery
***************************************/

select
     FirstName,
     LastName
from Employee
where
     ManagerID = (
	select EmployeeID
	from Employee
	where
	     FirstName = 'Michael' and LastName = 'Scott'
	);


/***************************************
  Common Table Expression
***************************************/

;with cte_Manager(EmployeeID)
as
(
	select EmployeeID
	from Employee
	where
	     FirstName = 'Michael' and LastName = 'Scott'
)
select
     FirstName,
     LastName
from Employee
	inner join cte_Manager
	on Employee.ManagerID = cte_Manager.EmployeeID


/***************************************
 These do not have the same plan 
 because they would have different
 behavior if there was more than 
 one Michael Scott
***************************************/


select
     FirstName,
     LastName
from Employee
where
     ManagerID = (
	select EmployeeID
	from Employee
	--where
	--   FirstName = 'Michael' and LastName = 'Scott'
	);


;with cte_Manager(EmployeeID)
as
(
	select EmployeeID
	from Employee
	--where
	--     FirstName = 'Michael' and LastName = 'Scott'
)
select
     FirstName,
     LastName
from Employee
	inner join cte_Manager
	on Employee.ManagerID = cte_Manager.EmployeeID


/***************************************
 Let's change our index to a unique 
 index so the the optimizer knows that 
 is not going to happen
***************************************/

drop index Employee.IX_Employee_LastName_FirstName

create unique index IX_Employee_LastName_FirstName
on Employee(LastName,FirstName) include (ManagerID)


/***************************************
 And now let's try again
***************************************/

select
     FirstName,
     LastName
from Employee
where
     ManagerID = (
	select
	     EmployeeID
	from Employee
	where
	     FirstName = 'Michael'
	     and LastName = 'Scott'
	);

with cte_Manager(EmployeeID)
as
(
	select
	     EmployeeID
	from Employee
	where
	     FirstName = 'Michael'
	     and LastName = 'Scott'
)
select
     FirstName,
     LastName
from Employee
	inner join cte_Manager
	on Employee.ManagerID = cte_Manager.EmployeeID


