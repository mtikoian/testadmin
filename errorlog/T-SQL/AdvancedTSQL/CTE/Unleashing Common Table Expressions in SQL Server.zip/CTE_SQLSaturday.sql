-- SAMPLE CODE for the SQL Saturday Presentation in Redmond WA
-- Created by Steve Stedman
--    http://SteveStedman.com
--    twitter:   @SqlEmt



--USE [Master];
--set statistics io off;

--ALTER DATABASE [cte_demo] SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
--IF EXISTS(SELECT name FROM sys.databases WHERE name = 'cte_demo')
--	DROP DATABASE [cte_demo];
--CREATE DATABASE [cte_demo];
--GO

--USE [cte_demo];


---- create a table to use for CTE query demo
--CREATE TABLE [Departments] (
--	id int,  --would normally be an INT IDENTITY
--	department VARCHAR (200),
--	parent int
--	);
	
---- insert top level departments
--insert into [Departments] (id, department, parent)
--values (1, 'Camping', null),
--       (2, 'Cycle', null),
--       (3, 'Snowsports', null),
--       (4, 'Fitness', null);
      
---- now some sub-departments for camping
--insert into [Departments] (id, department, parent)
--values (5, 'Tents', 1),
--       (6, 'Backpacks', 1),
--       (7, 'Sleeping Bags', 1),
--       (8, 'Cooking', 1);
       
---- now some sub-departments for cycle
--insert into [Departments] (id, department, parent)
--values (9, 'Bikes', 2),
--       (10, 'Helmets', 2),
--       (11, 'Locks', 2);

---- now some sub-departments for snowsports
--insert into [Departments] (id, department, parent)
--values (12, 'Ski', 3),
--       (13, 'Snowboard', 3),
--       (14, 'Snowshoe', 3);
       
---- now some sub-departments for fitness
--insert into [Departments] (id, department, parent)
--values (15, 'Running', 4),
--       (16, 'Swimming', 4),
--       (17, 'Yoga', 4);







USE [cte_demo];

-- just see what is in the Departments table
select * from Departments;

---Demo:  Simple CTE
-- ; before the with is important or could be a GO
;WITH deptCTE(id, department, parent) AS 
(
  SELECT id, department, parent 
    FROM Departments
) 
SELECT * FROM deptCTE;












-- Subquery - NO CTE
SELECT q1.department, q2.department as subDepartment
FROM   (SELECT id, department, parent 
	     FROM Departments) as q1
INNER JOIN (SELECT id, department, parent 
	     FROM Departments) as q2 
	   ON q1.id = q2.parent
WHERE q1.parent is null; 



---CTE for Subquery Re-use
;WITH deptCTE(id, department, parent) AS 
(	SELECT id, department, parent
	  FROM Departments) 
SELECT q1.department, q2.department as subDepartment
  FROM deptCTE q1
 INNER JOIN deptCTE q2 on q1.id = q2.parent
 WHERE q1.parent is null; 

















-- Non CTE to get department levels
select d1.department as 'Top_level',
       d2.department as 'Child_level'
  from Departments d1
  right join Departments d2 on d1.id = d2.parent;






-- Recursive CTE
;WITH DepartmentCTE(id, Department, Parent, Level) AS 
( SELECT id, Department, parent, 0 as Level 
    FROM Departments
   WHERE parent is NULL 
   UNION ALL -- and now for the recursive part 
  SELECT d.id, d.Department, d.parent,
         DepartmentCTE.Level + 1 as Level 
    FROM Departments d
    INNER JOIN DepartmentCTE
    ON DepartmentCTE.id = d.parent) 
SELECT * 
  FROM DepartmentCTE
 ORDER BY parent; 
 
 
 
 
 
 
 
 

delete from Departments where id > 17; 
 --now add 2 more levels of depth
insert into [Departments] (id, department, parent)
values (18, '1 Person', 5),
       (19, '2 Person', 5),
       (20, '3 Person', 5),
       (21, '4 Person', 5);

insert into [Departments] (id, department, parent)
values (22, 'Backpacking', 19),
       (23, 'Family Camping', 19),
       (24, 'Mountaineering', 19);

insert into [Departments] (id, department, parent)
values (25, 'Ultra-lightweight', 24),
       (26, 'Lightweight', 24),
       (27, 'Standard', 24);



insert into [Departments] (id, department, parent)
values (28, 'Gifts', null),
       (29, 'Clearance', null);


















-- Recursive CTE with TreePath
;WITH DepartmentCTE(DeptId, Department, Parent, Level, TreePath) AS 
( SELECT id as DeptId, Department, parent, 0 as Level,
		 cast(Department as varchar(1024)) as TreePath
    FROM Departments
   WHERE parent is NULL 
   UNION ALL -- and now for the recursive part 
  SELECT d.id as DeptId, d.Department, d.parent,
         DepartmentCTE.Level + 1 as Level,
         cast(DepartmentCTE.TreePath + ' -> ' + 
              cast(d.department as varchar(1024)) 
            as varchar(1024)) as TreePath
    FROM Departments d
    INNER JOIN DepartmentCTE
    ON DepartmentCTE.DeptId = d.parent) 
SELECT DeptId, Parent, Level, TreePath
  FROM DepartmentCTE
 ORDER BY TreePath; 
 
 
 
 
 
 
 
 
 
 
 
 
 
-- using the REPLICATE function
select REPLICATE('abc', 3);
 
 
-- Recursive CTE with indentation
-- Using the REPLICATE function to indent with a '.  ' for each level
;WITH DepartmentCTE(DeptId, Department, Parent, Level, TreePath) AS 
( SELECT id as DeptId, Department, parent, 0 as Level,
		 cast(Department as varchar(1024)) as TreePath
    FROM Departments
   WHERE parent is NULL 
   UNION ALL -- and now for the recursive part 
  SELECT d.id as DeptId, d.Department, d.parent,
         DepartmentCTE.Level + 1 as Level,
         cast(DepartmentCTE.TreePath + ' -> ' + 
              cast(d.department as varchar(1024)) 
            as varchar(1024)) as TreePath
    FROM Departments d
    INNER JOIN DepartmentCTE
    ON DepartmentCTE.DeptId = d.parent) 
SELECT REPLICATE('.     ', Level) + Department as Department
  FROM DepartmentCTE
 ORDER BY TreePath; 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 

-- Performance Differences 
-- Remember Ctrl+M to turn on Execution Plan 
-- Recursive CTE compared to Multiple Self Joins 
;WITH DepartmentCTE(DeptId, Department, Parent, Level, TreePath) AS 
( SELECT id as DeptId, Department, parent, 0 as Level, 
     cast(Department as varchar(1024)) as TreePath 
    FROM Departments 
   WHERE parent is NULL 
   UNION ALL -- and now for the recursive part  
  SELECT d.id as DeptId, d.Department, d.parent, 
         DepartmentCTE.Level + 1 as Level, 
         cast(DepartmentCTE.TreePath + ' -> ' + 
              cast(d.department as varchar(1024)) 
            as varchar(1024)) as TreePath 
    FROM Departments d 
    INNER JOIN DepartmentCTE 
    ON DepartmentCTE.DeptId = d.parent
) 
SELECT DeptId, TreePath 
  FROM DepartmentCTE 
 ORDER BY TreePath; 
  
  
-- Multiple Self Joins Unioned 
-- Difficult to display Parent categories 
select d.id as DeptId, d.department as TreePath 
  from Departments d 
  where d.parent is null 
UNION ALL 
select da2.id as DeptId, 
       da1.department + ' -> ' + 
       da2.department as TreePath 
  from Departments da1 
  INNER JOIN Departments da2 on da1.id = da2.parent 
  where da1.parent is null 
UNION ALL 
select db3.id as DeptId, 
       db1.department + ' -> ' + 
       db2.department + ' -> ' + 
       db3.department as TreePath 
  from Departments db1 
  INNER JOIN Departments db2 on db1.id = db2.parent 
  INNER JOIN Departments db3 on db2.id = db3.parent 
  where db1.parent is null 
UNION ALL 
select dc3.id as DeptId, 
       dc1.department + ' -> ' + 
       dc2.department + ' -> ' + 
       dc3.department + ' -> ' + 
       dc4.department as TreePath 
  from Departments dc1 
  INNER JOIN Departments dc2 on dc1.id = dc2.parent 
  INNER JOIN Departments dc3 on dc2.id = dc3.parent 
  INNER JOIN Departments dc4 on dc3.id = dc4.parent 
  where dc1.parent is null 
UNION ALL 
select dd3.id as DeptId, 
       dd1.department + ' -> ' + 
       dd2.department + ' -> ' + 
       dd3.department + ' -> ' + 
       dd4.department + ' -> ' + dd5.department as TreePath 
  from Departments dd1 
  INNER JOIN Departments dd2 on dd1.id = dd2.parent 
  INNER JOIN Departments dd3 on dd2.id = dd3.parent 
  INNER JOIN Departments dd4 on dd3.id = dd4.parent 
  INNER JOIN Departments dd5 on dd4.id = dd5.parent 
  where dd1.parent is null 
   
ORDER by TreePath 
; 


 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 --Demo: Multiple CTE
;WITH Fnames (Name) AS (SELECT 'John' UNION Select 'Mary' UNION Select 'Bill'),
Minitials (initial) AS (SELECT 'A' UNION SELECT 'B' UNION SELECT 'C'),
Lnames (Name) AS (SELECT 'Anderson' UNION Select 'Hanson' UNION Select 'Jones')

 SELECT F.Name FirstName, M.initial, L.Name LastName
   FROM Fnames F
  CROSS JOIN Lnames as L
  CROSS JOIN Minitials m;
 
  
  
  
  
-- Data Paging


-- query with no data paging  Shows all tables on this database, and all columns
select OBJECT_NAME(sc.object_id) as TableName, name as ColumnName
from sys.columns sc
order by OBJECT_NAME(sc.object_id);
  

-- CTE Example to get data paging
-- Assume that page size is 10 the first page would display the first 10 rows
--   the second page would display rows 11 to 20,
--   third page would display rows 21 to 30
  
declare @pageNum as int;
declare @pageSize as int;
set @pageNum = 2;
set @pageSize = 10;

;WITH TablesAndColumns AS 
( 
SELECT OBJECT_NAME(sc.object_id) AS TableName, 
       name AS ColumnName, 
       ROW_NUMBER() OVER (ORDER BY OBJECT_NAME(sc.object_id)) AS RowNum 
  FROM sys.columns sc 
) 
SELECT * 
  FROM TablesAndColumns 
  WHERE RowNum BETWEEN (@pageNum - 1) * @pageSize + 1 
               AND @pageNum * @pageSize ; 

  
  
GO  
  -- now simplify it by creating a stored procedure.
ALTER PROCEDURE TablesAndColumnsPager
	@pageNum int,
	@pageSize int
AS
BEGIN
	SET NOCOUNT ON;

	;WITH TablesAndColumns AS 
	( 
	SELECT OBJECT_NAME(sc.object_id) AS TableName, 
		   name AS ColumnName, 
		   ROW_NUMBER() OVER (ORDER BY OBJECT_NAME(sc.object_id)) AS RowNum 
	  FROM sys.columns sc 
	) 
	SELECT * 
	  FROM TablesAndColumns 
	  WHERE RowNum BETWEEN (@pageNum - 1) * @pageSize + 1 
				   AND @pageNum * @pageSize ; 
END
GO
  
exec TablesAndColumnsPager 1, 10;
exec TablesAndColumnsPager 2, 10;
exec TablesAndColumnsPager 3, 10;
  
  
  
  
  
  
  
  
  
  
-- Recursive CTE for dates in the year
;WITH Dates as (
   SELECT cast('2011-01-01' as date) as CalendarDate
   UNION ALL
   SELECT dateadd(day , 1, CalendarDate) AS CalendarDate FROM Dates
   WHERE dateadd (day, 1, CalendarDate) < '2012-01-01'
)
SELECT * FROM Dates
OPTION (MAXRECURSION 366);


  
  
 -- Recursive CTE for dates in the year
 -- with extended details.
 ;WITH Dates as (
   SELECT cast('2011-01-01' as date) as CalendarDate
   UNION ALL
   SELECT dateadd(day , 1, CalendarDate) AS CalendarDate FROM Dates
   WHERE dateadd (day, 1, CalendarDate) < '2012-01-01'
)
SELECT
   CalendarDate,
   CalendarYear=year(CalendarDate),
   CalendarQuarter=datename(quarter, CalendarDate),
   CalendarMonth=month(CalendarDate),
   CalendarWeek=datepart(wk, CalendarDate),
   CalendarDay=day(CalendarDate),
   CalendarMonthName=datename(month, CalendarDate),
   Weekday=datename(weekday, CalendarDate),
   DayOfWeek=datepart(weekday, CalendarDate)
FROM Dates
OPTION (MAXRECURSION 366);












-- Replacing a numbers table with a recursive CTE
WITH Numbers (N) AS 
( SELECT 1 
   UNION ALL 
  SELECT 1 + N FROM Numbers 
   WHERE N < 1000
) 
 SELECT N 
   FROM Numbers 
 OPTION (MAXRECURSION 0);












-- Calculating the Fibonacci sequence 
-- http://stevestedman.com/?p=1142
;WITH Fibonacci (PrevN, N) AS 
( SELECT 0, 1
   UNION ALL 
  SELECT N, PrevN + N 
    FROM Fibonacci 
   WHERE N < 1000000000
) 
 SELECT PrevN as Fibo
   FROM Fibonacci 
 OPTION (MAXRECURSION 0);



-- Fibonacci with output as a csv
-- http://stevestedman.com/?p=320
WITH Fibonacci (PrevN, N) AS 
( SELECT 0, 1
   UNION ALL 
  SELECT N, PrevN + N 
    FROM Fibonacci 
   WHERE N < 1000000000
) 
 SELECT Substring((SELECT cast(', ' as varchar(max)) + 
		cast(PrevN as varchar(max))
   FROM Fibonacci 
  FOR XML PATH('')),3,10000000) AS list
  
  




-- Calculating Factorials with a CTE : Step 1
-- http://stevestedman.com/?p=1166
-- Not yet recursive, only calculates 1!
--   A start, but not very interesting
WITH Factorial (N, Factorial) AS 
(
 SELECT 1, 1
) 
 SELECT N, Factorial
   FROM Factorial;

 

  
-- Calculating Factorials with a CTE : Step 2
-- http://stevestedman.com/?p=1166
-- This works great for 5!
;WITH Factorial (N, Factorial) AS 
( SELECT 1, 1
   UNION ALL -- here is where it gets recursive
  SELECT N + 1, (N + 1) * Factorial
    FROM Factorial -- reference back to the CTE
   WHERE N < 5 -- abort when we get to 5!
) 
 SELECT N, Factorial
   FROM Factorial;
 
 
  
  
-- Calculating Factorials with a CTE : Step 3
-- http://stevestedman.com/?p=1166
-- this one throws an error of "Arithmetic overflow error converting expression to data type int."
WITH Factorial (N, Factorial) AS 
( SELECT 1, 1
   UNION ALL -- here is where it gets recursive
  SELECT N + 1, (N + 1) * Factorial
    FROM Factorial -- reference back to the CTE
   WHERE N < 20 -- abort when we get to 20!
) 
 SELECT N, Factorial
   FROM Factorial;
   
   
   
   
   
   
   
-- Calculating Factorials with a CTE  : Step 4  - GO BIG
-- http://stevestedman.com/?p=1166
WITH Factorial (N, Factorial) AS 
( SELECT 1, cast(1 as BIGINT) -- Cast to BIGINT to avoid overflow
   UNION ALL -- here is where it gets recursive
  SELECT N + 1, (N + 1) * Factorial
    FROM Factorial -- reference back to the CTE
   WHERE N < 20 -- abort when we get to 20!
) 
 SELECT N, Factorial
   FROM Factorial;
   
   
   
   
   
   
   
   
 
 
 
-- Calculating Factorials with a CTE  : Step 5  - GO REALLY BIG
-- http://stevestedman.com/?p=1166
;WITH Factorial (N, Factorial) AS 
( SELECT 1, cast(1 as NUMERIC(38,0)) -- Cast to NUMERIC to avoid overflow
   UNION ALL -- here is where it gets recursive
  SELECT N + 1, (N + 1) * Factorial
    FROM Factorial -- reference back to the CTE
   WHERE N < 33 -- abort when we get to 33!
) 
 SELECT N, Factorial
   FROM Factorial; 
 
 
 
 --previous query, try 34...  What now?
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 --Insert Statements from a CTE, but not inside the CTE
 -- http://stevestedman.com/?p=1153
DECLARE @NumTableVar TABLE(n int);

;WITH Numbers (N) AS 
( SELECT 1 
   UNION ALL 
  SELECT 1 + N FROM Numbers 
   WHERE N < 1000
) 
INSERT INTO @NumTableVar(n)
 SELECT N 
   FROM Numbers 
 OPTION (MAXRECURSION 0);
  
 select * from @NumTableVar;
 
 
 
 
 
 
 

--proving that the CTE is run multiple times.
-- Remember Ctrl+M to turn on Execution Plan
;WITH deptCTE(id, department, parent) AS 
(	SELECT id, department, parent
	  FROM Departments) 
SELECT q1.department, q2.department as subDepartment
  FROM deptCTE q1
 INNER JOIN deptCTE q2 on q1.id = q2.parent
 WHERE q1.parent is null; 

 
 
 
 
 
 
 
 ---CTE for Subquery Re-use
;WITH deptCTE(id, department, parent) AS 
(	SELECT id, department, parent
	  FROM Departments) 
SELECT q1.department, q2.department as subDepartment
  FROM deptCTE q1
 INNER JOIN deptCTE q2 on q1.id = q2.parent
 WHERE q1.parent is null; 
 
 
GO
CREATE VIEW [dbo].[DeptView]
AS 
 SELECT id, department, parent
	  FROM Departments;
GO

SELECT q1.department, q2.department as subDepartment
  FROM DeptView q1
 INNER JOIN DeptView q2 on q1.id = q2.parent
 WHERE q1.parent is null; 
 
GO	  
DROP VIEW [dbo].[DeptView];
 
 
 
 
 --THE END---------------------------------------------------