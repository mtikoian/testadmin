use tempdb
if OBJECT_ID('test1') is not null
	drop table test1
go
create table test1(id int identity(1,1) primary key)
go

if OBJECT_ID('proc1') is not null
	drop procedure proc1
truncate table test1
go
create procedure proc1
as
begin
	begin transaction A
	select @@TRANCOUNT as TranCount
	insert into test1 default values
	rollback transaction A
end
go
exec proc1
select * from test1
go
begin transaction
exec proc1
rollback 
select @@TRANCOUNT
go
if @@TRANCOUNT > 0
	rollback transaction

go
alter procedure proc1
as
begin
	save transaction A
	select @@TRANCOUNT as TranCount
	insert into test1 default values
	rollback transaction A
end
go
truncate table test1
begin transaction 
insert into test1 default values
exec proc1
commit transaction
select @@IDENTITY, * from test1
go

go
truncate table test1
set implicit_transactions on
select @@trancount
insert into test default values
select @@trancount
exec proc1
select @@TRANCOUNT
commit
select @@TRANCOUNT

go
select * from test1
select @@TRANCOUNT
rollback
select @@TRANCOUNT

exec proc1
set implicit_transactions off
go
---transaction performance

use master -- do some clean-up
go
if DB_ID('test') is not null
begin
	alter database test set single_user with rollback immediate
	drop database test
end
go
create database test
go
use test
set nocount on
go
create table table1 (id int)
go

truncate table table1
declare @i int = 0, @StartTime datetime2(3) = sysdatetime()
while @i< 3000
begin
	insert into table1 values (CHECKSUM(NEWID()))
	select @i = @i +1
end
select DATEDIFF(millisecond, @StartTime, sysdatetime())
--529
go
truncate table table1
declare @i int = 0, @StartTime datetime2(3) = sysdatetime()
begin transaction
while @i< 3000
begin
	insert into table1 values (CHECKSUM(NEWID()))
	select @i = @i +1
end
commit
select DATEDIFF(millisecond, @StartTime, sysdatetime())
--50
go
--Chatty/Chunky 
--Chatty: most of the developers do
--Chunky: 
--	1. only when doing large amount of modification
--  2. use set implicit_transactions on

