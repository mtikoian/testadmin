use tempdb
go
--demo 1
set xact_abort off
select POWER(2, 32)
print 'This will be printed'
---this is statement level exception
go
--demo 2
set xact_abort off
select CAST('aaa' as int)
print 'This will be not printed'
---this is batch level exception
go
--demo 3
set xact_abort off
selct top 1 * from sysobjects
print 'This will be not printed'
---Error at compile time
---this is batch level exception
go
--demo 4
set xact_abort off -- on
exec('selct top 1 * from sysobjects')
print 'This will be printed'
---Error at compile time within a sub-scope
---batch level exception will become to statement level exception
go
--demo 5
set xact_abort off 
go
if OBJECT_ID('ErrorTest') is not null
	drop procedure ErrorTest
go
create procedure ErrorTest
as
begin
	select top 1 * from NoSuchTable
end
go
exec ErrorTest
print 'This will be printed'

---Error at compile time within a sub-scope
---batch level exception will become to statement level exception
go
--demo 6
set xact_abort off
select POWER(2, 32)
print 'This will not be printed'

set xact_abort on
select POWER(2, 32)
print 'This will not be printed'


set xact_abort on
raiserror('customized exception', 16, 1)
print 'This will be printed'

--very inconsistent, use try catch
--same severity level but different exception level

go
--demo 8, Uncommittable transaction
set xact_abort off
begin transaction
create table #test(i int)
begin try
	insert into #test values(CAST('abc' as int))
end try
begin catch
	--error code: 3998 
	--select @@TRANCOUNT
	--insert into #test values(100)
	
	rollback
end catch
go
if @@TRANCOUNT > 0
	commit
go
if @@TRANCOUNT > 0
	rollback
	
