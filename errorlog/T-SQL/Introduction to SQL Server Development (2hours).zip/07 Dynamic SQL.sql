use AdventureWorks2008R2
go
exec ('
		SELECT BusinessEntityID, LoginID, JobTitle 
		FROM HumanResources.Employee 
		where BusinessEntityID = 20'
	)
go
exec sp_executesql N'
					SELECT BusinessEntityID, LoginID, JobTitle 
					FROM HumanResources.Employee 
					where BusinessEntityID = 20
					'
					
exec sp_executesql N'
					SELECT BusinessEntityID, LoginID, JobTitle 
					FROM HumanResources.Employee 
					where BusinessEntityID = @BusinessEntityID',
					N'@BusinessEntityID int', @BusinessEntityID = 20

go
--- which one is better?



if OBJECT_ID('vwPlanCache') is not null
	drop view vwPlanCache
go
create view vwPlanCache
as
	SELECT	cp.objtype,cp.refcounts,usecounts,	st.text
	FROM sys.dm_exec_cached_plans cp
		CROSS APPLY sys.dm_exec_sql_text(cp.plan_handle) st
	WHERE st.text LIKE '%HumanResources%'
	AND st.text NOT LIKE '%sys.dm_exec_cached_plans%'
go
select * from vwPlanCache

DBCC FREEPROCCACHE -- clean up procedure cache

select * from vwPlanCache

go

exec ('
		SELECT BusinessEntityID, LoginID, JobTitle 
		FROM HumanResources.Employee 
		where BusinessEntityID = 20'
	)
go
select * from vwPlanCache

go
exec ('
		SELECT BusinessEntityID, LoginID, JobTitle 
		FROM HumanResources.Employee 
		where BusinessEntityID = 21'
	)
go
select * from vwPlanCache


exec sp_executesql N'
		SELECT BusinessEntityID, LoginID, JobTitle 
		FROM HumanResources.Employee 
		where BusinessEntityID = 26'
select * from vwPlanCache
go
DBCC FREEPROCCACHE -- clean up procedure cache

select * from vwPlanCache
go
exec sp_executesql N'
					SELECT BusinessEntityID, LoginID, JobTitle 
					FROM HumanResources.Employee 
					where BusinessEntityID = @BusinessEntityID',
					N'@BusinessEntityID int', @BusinessEntityID = 26
go
select * from vwPlanCache
go
exec sp_executesql N'
					SELECT BusinessEntityID, LoginID, JobTitle 
					FROM HumanResources.Employee 
					where BusinessEntityID = @BusinessEntityID',
					N'@BusinessEntityID int', @BusinessEntityID = 27
go
select * from vwPlanCache


go  -- out put parameters
if OBJECT_ID('tempdb..#1') is not null
	drop table #1

create table #1 (id int identity(1,1) primary key)
insert into #1 default values
select SCOPE_IDENTITY(), @@IDENTITY
exec sp_executesql N'insert into #1 default values'
select SCOPE_IDENTITY(), @@IDENTITY
---Why scope_identity() is 1 where @@identity is 2?
go
declare @id int
exec sp_executesql N'
						insert into #1 default values
						select @id = SCOPE_IDENTITY()
					', N'@id int output', @id = @id output
select @id, SCOPE_IDENTITY() , @@IDENTITY
go

---execute procedures dynamically
exec sp_helptext 'vwPlanCache'
go
exec sp_executesql	N'exec sp_helptext @objname', 
					N'@objname sysname', 
					N'vwPlanCache'
go
declare @proc sysname = 'sp_helptext', 
		@objname sysname = 'vwPlanCache'
exec @proc @objname
go
use tempdb
go
declare @proc sysname = 'AdventureWorks2008R2..sp_helptext', 
		@objname sysname = 'vwPlanCache'
exec @proc @objname
go
-- over linked server
declare @proc sysname = 'DTCDEMO.AdventureWorks2008R2..sp_helptext', @objname sysname = 'vwPlanCache'
exec @proc @objname
go

