use tempdb
go
---temp object supports transactions
create table #t (id int)
begin transaction
insert into #t values(1)
rollback
select * from #t

go
declare @t table(id int)
begin transaction
insert into @t values(1)
rollback
select * from @t
go

use tempdb
alter database [tempdb] set auto_create_statistics on 
alter database [tempdb] set auto_update_statistics on 
set nocount on
go
declare @table1 table (id int identity(1,1), v int, MyColumn int)
select OBJECT_NAME(object_id)
from sys.columns 
where name = 'MyColumn'

select *
from sys.columns
where object_id in (
					select object_id
					from sys.columns 
					where name = 'MyColumn'
)
go
if object_id('tempdb..#table1') is not null
	drop table #table1
go
set nocount on
create table #table1 (id int identity(1,1), v int)
declare @i int = 0
while @i< 1000
begin
	insert into #table1 (v) values(CHECKSUM(NEWID()))
	select @i = @i +1
end
select * from sys.stats where object_id = object_id('tempdb..#table1')
select * from #table1 where id = 6
select * from sys.stats where object_id = object_id('tempdb..#table1')

dbcc show_statistics ('tempdb..#table1', _WA_Sys_00000001_14E61A24)
go

go
declare @table1 table (id int identity(1,1), v int, MyColumn int)
declare @i int = 0
while @i< 1000
begin
	insert into @table1(v) values(CHECKSUM(NEWID()))
	select @i = @i +1
end
select * 
from sys.stats 
where object_id in(
					select object_id
					from sys.columns 
					where name = 'MyColumn'
				)
select * from @table1 where id = 6
select * 
from sys.stats 
where object_id in(
					select object_id
					from sys.columns 
					where name = 'MyColumn'
				)
go

--Why do we care about stats?
use tempdb
go
if object_id('tempdb..#SalesOrderHeader') is not null
	drop table #SalesOrderHeader
go
create table #SalesOrderHeader (SalesOrderID int unique,RevisionNumber tinyint,OrderDate datetime,DueDate datetime,ShipDate datetime,Status tinyint,OnlineOrderFlag varchar(100),SalesOrderNumber  varchar(100),PurchaseOrderNumber varchar(100),AccountNumber varchar(100),CustomerID int ,ContactID int ,SalesPersonID int ,TerritoryID int ,BillToAddressID int ,ShipToAddressID int ,ShipMethodID int,CreditCardID int,CreditCardApprovalCode varchar(15),CurrencyRateID int ,SubTotal money,TaxAmt money,Freight money,TotalDue  money,Comment nvarchar(128),rowguid uniqueidentifier,ModifiedDate datetime)
insert into #SalesOrderHeader(SalesOrderID, RevisionNumber, OrderDate, DueDate, ShipDate, Status, OnlineOrderFlag, SalesOrderNumber, PurchaseOrderNumber, AccountNumber, CustomerID, ContactID, SalesPersonID, TerritoryID, BillToAddressID, ShipToAddressID, ShipMethodID, CreditCardID, CreditCardApprovalCode, CurrencyRateID, SubTotal, TaxAmt, Freight, TotalDue, Comment, rowguid, ModifiedDate)
	select SalesOrderID, RevisionNumber, OrderDate, DueDate, ShipDate, Status, OnlineOrderFlag, SalesOrderNumber, PurchaseOrderNumber, AccountNumber, CustomerID, ContactID, SalesPersonID, TerritoryID, BillToAddressID, ShipToAddressID, ShipMethodID, CreditCardID, CreditCardApprovalCode, CurrencyRateID, SubTotal, TaxAmt, Freight, TotalDue, Comment, rowguid, ModifiedDate
	from AdventureWorks.Sales.SalesOrderHeader
go
select * from #SalesOrderHeader 
go
--enable execution plan
set statistics io on
select * from #SalesOrderHeader  where SalesOrderID between 63696 and 63696 + 1
set statistics io off
--3
go
set nocount on
set statistics xml off
declare @SalesOrderHeader table(SalesOrderID int unique,RevisionNumber tinyint,OrderDate datetime,DueDate datetime,ShipDate datetime,Status tinyint,OnlineOrderFlag varchar(100),SalesOrderNumber  varchar(100),PurchaseOrderNumber varchar(100),AccountNumber varchar(100),CustomerID int ,ContactID int ,SalesPersonID int ,TerritoryID int ,BillToAddressID int ,ShipToAddressID int ,ShipMethodID int,CreditCardID int,CreditCardApprovalCode varchar(15),CurrencyRateID int ,SubTotal money,TaxAmt money,Freight money,TotalDue  money,Comment nvarchar(128),rowguid uniqueidentifier,ModifiedDate datetime)
insert into @SalesOrderHeader(SalesOrderID, RevisionNumber, OrderDate, DueDate, ShipDate, Status, OnlineOrderFlag, SalesOrderNumber, PurchaseOrderNumber, AccountNumber, CustomerID, ContactID, SalesPersonID, TerritoryID, BillToAddressID, ShipToAddressID, ShipMethodID, CreditCardID, CreditCardApprovalCode, CurrencyRateID, SubTotal, TaxAmt, Freight, TotalDue, Comment, rowguid, ModifiedDate)
	select SalesOrderID, RevisionNumber, OrderDate, DueDate, ShipDate, Status, OnlineOrderFlag, SalesOrderNumber, PurchaseOrderNumber, AccountNumber, CustomerID, ContactID, SalesPersonID, TerritoryID, BillToAddressID, ShipToAddressID, ShipMethodID, CreditCardID, CreditCardApprovalCode, CurrencyRateID, SubTotal, TaxAmt, Freight, TotalDue, Comment, rowguid, ModifiedDate
	from AdventureWorks.Sales.SalesOrderHeader
set statistics xml on
set statistics io on
select * from @SalesOrderHeader  where SalesOrderID between 63696 and 63696 +1 
set statistics io off
set statistics xml off
--718
go
---perfromance of temp objects
go
use master
go
if DB_ID('test') is not null
begin
	alter database test set single_user with rollback immediate
	drop database test
end
go
create database test
go
use test
set nocount on
set statistics xml off
go
create table table1 (id int)
go
if object_id('tempdb..#table1') is not null
	drop table #table1
go
create table #table1 (id int)
go
truncate table table1
declare @i int = 0, @StartTime datetime2(3) = sysdatetime()
while @i< 3000
begin
	insert into table1 values (CHECKSUM(NEWID()))
	select @i = @i +1
end
select DATEDIFF(millisecond, @StartTime, sysdatetime())
go
--1000
truncate table #table1
declare @i int = 0, @StartTime datetime2(3) = sysdatetime()
while @i< 3000
begin
	insert into #table1 values (CHECKSUM(NEWID()))
	select @i = @i +1
end
select DATEDIFF(millisecond, @StartTime, sysdatetime())
go
-- 71
declare @table1 table (id int)
declare @i int = 0, @StartTime datetime2(3) = sysdatetime()
while @i< 3000
begin
	insert into @table1 values (CHECKSUM(NEWID()))
	select @i = @i +1
end
select DATEDIFF(millisecond, @StartTime, sysdatetime())
--60