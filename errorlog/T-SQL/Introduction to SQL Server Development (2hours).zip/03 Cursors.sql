use AdventureWorks
go
declare MyCursor cursor global for 
	select * from Person.Address
open MyCursor
fetch next from MyCursor
select * from sys.dm_exec_cursors(0)
close MyCursor
deallocate MyCursor
go





declare MyCursor cursor local for 
	select * from Person.Address
open MyCursor
fetch next from MyCursor
--go
select * from sys.dm_exec_cursors(0)
close MyCursor
deallocate MyCursor
go




--- don't confuse yourself
-- Global and Local can share the same name
declare MyCursor cursor global for 
	select * from Person.Address
open MyCursor
select 'First Fetch - Global'
fetch next from MyCursor

declare MyCursor cursor local for 
	select * from Person.Contact
open MyCursor

select 'Second Fetch - ?'
fetch next from MyCursor

close MyCursor
deallocate MyCursor

select 'Third Fetch with MyCursor released'
fetch next from MyCursor

close MyCursor
deallocate MyCursor
go
--local cursor
if OBJECT_ID('CursorTest') is not null
	drop procedure CursorTest
go
create procedure CursorTest
as
begin
	if @@NESTLEVEL > 3
		return;
	
	declare MyCursor cursor for 
		select * from Person.Address
	open MyCursor
	
	select @@NESTLEVEL
	fetch next from MyCursor
	select * from sys.dm_exec_cursors(0)
	--select * from sys.syscursors
	exec CursorTest	
	close MyCursor
	deallocate MyCursor
end
go
-- see the scop of cursor

exec CursorTest

if OBJECT_ID('CursorTest') is not null
	drop procedure CursorTest
go

