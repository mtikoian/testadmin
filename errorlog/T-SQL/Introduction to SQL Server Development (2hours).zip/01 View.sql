use master
go
if DB_ID('test') is not null
begin
	alter database test set single_user with rollback immediate
	drop database test
end
go
create database test
go
use test
go
create table Employee 
(
	EmployeeID int primary key, 
	EmployeeName varchar(50) not null, 
	Data varchar(200)
)
go
insert into Employee values(1, 'CEO',  'sensitive')
insert into Employee values(2, 'Employee', 'not sensitive')
go
create table EmployeeGroup(
	RoleName varchar(128), 
	EmployeeID int, 
	primary key (RoleName, EmployeeID)
)
go
insert into EmployeeGroup values('Executives', 1)
insert into EmployeeGroup values('Executives', 2)
insert into EmployeeGroup values('Employees', 2)
go
create role Executives
create role Employees
go
create view vEmployee 
as
select EmployeeID, EmployeeName, Data
from Employee e
where exists(
				select 1 
				from EmployeeGroup eg
				where eg.EmployeeID = e.EmployeeID
					and is_member(eg.RoleName) = 1
			)
--with check option
go
grant all on vEmployee to public
grant all on EmployeeGroup to public
go
create user ceo without login
create user emp1 without login
go
exec sp_addrolemember 'Executives', 'ceo'
exec sp_addrolemember 'Employees', 'emp1'
go
select * from vEmployee
go
Execute as user = 'ceo'
go
select user
go
select * from Employee

select * from vEmployee
go
update vEmployee 
	set Data = 'sensitive  A' 
where EmployeeID = 1

update vEmployee 
	set Data = 'not sensitive  A' 
where EmployeeID = 2
go
select * from vEmployee
go
revert
go
execute as user = 'emp1'
go
select user
go
select * from Employee
select * from vEmployee

update vEmployee set EmployeeName = 'Employee A'
select * from vEmployee

update vEmployee set EmployeeID = 3

select * from vEmployee

go
revert