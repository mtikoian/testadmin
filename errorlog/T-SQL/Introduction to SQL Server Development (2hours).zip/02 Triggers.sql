use master
go
if DB_ID('test') is not null
begin
	alter database test set single_user with rollback immediate
	drop database test
end
go
create database test
go
use test
go
create table Settings
(
	SettingName varchar(128) primary key,
	SettingValue varchar(128)
)
go
insert into Settings values('Setting1', 'Value1')
insert into Settings values('Setting2', 'Value2')
go
create trigger TRI_Settings_Instead on Settings
instead of insert, delete, update
as
begin
	if @@rowcount = 0
		return;
	set nocount on
	update s
		set SettingValue = null
	from Settings s
		inner join deleted d on d.SettingName = s.SettingName

	update s
		set SettingValue = i.SettingValue
	from Settings s
		inner join inserted i on i.SettingName = s.SettingName
end
go
select * from Settings
go
delete settings
go
select * from Settings
go
insert into Settings values('Setting3', 'Value3')
select * from Settings
go
insert into Settings values('Setting2', 'Value2')
select * from Settings
go
update Settings set SettingValue = 20 where SettingName = 'Setting1'
select * from Settings
go

--- what if admins want to add values to this table?

alter trigger TRI_Settings_Instead on Settings
instead of insert, delete, update
as
begin
	if @@rowcount = 0
		return;
	set nocount on
	update s
		set SettingValue = null
	from Settings s
		inner join deleted d on d.SettingName = s.SettingName

	update s
		set SettingValue = i.SettingValue
	from Settings s
		inner join inserted i on i.SettingName = s.SettingName
	
	if(left(context_info(), 4) = 0x12345678)
	begin
		insert into Settings(SettingName, SettingValue)
			select i.SettingName, i.SettingValue
			from inserted i
			where not exists(select 1 from Settings s where s.SettingName = i.SettingName)
		set context_info 0
	end
end
go
insert into Settings values('Setting3', 'New value')
go
set context_info 0x12345678
insert into Settings values('Setting3', 'New value')
go
select * from Settings 
go
select CONTEXT_INFO()
go
insert into Settings values('Setting4', 'New value')
go
select * from Settings 
