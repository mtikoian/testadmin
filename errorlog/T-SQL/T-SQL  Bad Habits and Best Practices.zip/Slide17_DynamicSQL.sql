-- with EXEC, you need to build a string:

DECLARE @sql NVARCHAR(MAX) = N'',
  @name NVARCHAR(32) = N'Bob',
  @CustomerID INT = 5;

SET @sql = 'SELECT * FROM wherever WHERE 
  name = ''' + REPLACE(@name, '''', '''''') + '''
  AND CustomerID = ' + CONVERT(VARCHAR(12), @CustomerID) + ';';

EXEC(@sql);
GO

-- with sp_executesql, you can use proper parameters:

DECLARE @sql NVARCHAR(MAX) = N'',
  @name NVARCHAR(32) = N'Bob',
  @CustomerID INT = 5;

SET @sql = 'SELECT * FROM wherever WHERE 
  name = @name AND CustomerID = @CustomerID;';

EXEC sp_executesql 
    @sql, 
    N'@name NVARCHAR(32), @CustomerID INT;',
	@name, @CustomerID;