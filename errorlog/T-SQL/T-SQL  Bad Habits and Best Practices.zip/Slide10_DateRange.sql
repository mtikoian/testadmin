SELECT COUNT(*) FROM Sales.SalesOrderHeader 
WHERE YEAR(OrderDate) = 2005 
AND MONTH(OrderDate) = 7;

SELECT COUNT(*) FROM Sales.SalesOrderHeader 
WHERE OrderDate >= '20050701'
  AND OrderDate < '20050801';



DECLARE @start DATETIME, @end DATETIME;

SELECT 
  @start = DATEADD(DAY, DATEDIFF(DAY, 1, CURRENT_TIMESTAMP), 0),
  @end   = DATEADD(MILLISECOND, -3, DATEADD(DAY, 1, @start));

SELECT @start, [Datetime] = @end;

SELECT @start, [Smalldatetime] = CONVERT(SMALLDATETIME, @end);

SELECT @start, [Date] = CONVERT(DATE, @end);

SELECT @start, [Datetime2] = CONVERT(DATETIME2(7), @end);

/*
Big difference between:

SELECT ... WHERE col BETWEEN @start AND @end;

...and...

SELECT ... WHERE col >= @start AND col < DATEADD(DAY, 1, @end);


DECLARE @d DATE = GETDATE(), @dt DATETIME = GETDATE();
SELECT @dt + 1;
SELECT @d + 1; -- <-- this breaks

SELECT DATEPART(y, CURRENT_TIMESTAMP);-- DATEPART(yyyy, CURRENT_TIMESTAMP);

*/