﻿CREATE TABLE [dbo].Ranking
(
	RankingId INT NOT NULL PRIMARY KEY, 
    [RankName] VARCHAR(20) NOT NULL,
	[Description] VARCHAR(MAX) NOT NULL
)
