-- this requires AventureWorks2008, 2008R2 or 2012
-- you can substitute with your own tables of course

DBCC FREEPROCCACHE;

GO
SELECT TOP (1) SalesOrderID FROM Sales.SalesOrderDetail;
GO
SELECT TOP (1)  SalesOrderID FROM Sales.SalesOrderDetail;
GO
SELECT TOP (1) salesorderid FROM sales.salesorderdetail;
GO
select top (1) SalesOrderID from Sales.SalesOrderDetail;
GO

SELECT t.[text], p.size_in_bytes, p.usecounts
FROM sys.dm_exec_cached_plans AS p
CROSS APPLY sys.dm_exec_sql_text(p.plan_handle) AS t
WHERE t.[text] LIKE '%SalesOrderDetail%'
AND t.[text] NOT LIKE '%cached%';