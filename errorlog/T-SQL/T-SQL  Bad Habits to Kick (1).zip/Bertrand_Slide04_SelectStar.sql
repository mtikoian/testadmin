-- this requires AdventureWorks2008, 2008R2 or 2012

SELECT *
FROM Person.[Address] WHERE AddressLine1 LIKE '1% Napa%';

SELECT AddressID, AddressLine1, AddressLine2, City, StateProvinceID, PostalCode
FROM Person.[Address] WHERE AddressLine1 LIKE '1% Napa%';