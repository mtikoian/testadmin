DECLARE @i INT;
-- run this with and without the second line commented:

DECLARE c CURSOR 
--LOCAL STATIC READ_ONLY FORWARD_ONLY
FOR 
  SELECT c1.[object_id] 
  FROM sys.objects AS c1
  CROSS JOIN (SELECT TOP 250 name FROM sys.objects) AS c2;

OPEN c;
FETCH c INTO @i;

WHILE @@FETCH_STATUS = 0
BEGIN
  SET @i = @i + 1;
  FETCH c INTO @i;
END

CLOSE c; DEALLOCATE c;