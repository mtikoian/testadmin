-- make a list of all of the user tables currently active in the 
-- TempDB database
if object_id('tempdb..#tempTables') is not null 
	drop table #tempTables
select name into #tempTables from tempdb..sysobjects 
 where type = 'U'
-- prove that even this new temporary table is in the list.
-- Note the suffix at the end of it to uniquely identify the table across sessions.
select * from #tempTables where name like '#tempTables%'
GO
-- create a table variable
declare @MyTableVariable table (RowID int)
-- show all of the new user tables in the TempDB database.
select name from tempdb..sysobjects 
 where type = 'U' and name not in (select name from #tempTables)
GO

-- Note: this works for 2000-2008R2.
-- you can use sys.tables instead, but it won't work for 2000.
