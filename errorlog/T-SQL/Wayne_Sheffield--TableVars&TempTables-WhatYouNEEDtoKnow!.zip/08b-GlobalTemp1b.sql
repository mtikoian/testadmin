declare @ErrString varchar(100);
while 1=1 begin
  select * from ##temp;
  set @ErrString = convert(char(12), GetDate(), 114) + 
      ' - Select succeeded against the global temp table';
  RaisError(@ErrString, 10, 1) WITH NOWAIT;
  waitfor delay '00:00:02';
end
