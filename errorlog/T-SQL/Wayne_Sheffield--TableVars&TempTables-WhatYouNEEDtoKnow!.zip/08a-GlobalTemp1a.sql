CREATE TABLE ##temp (RowID int);
INSERT INTO ##temp VALUES (1);
