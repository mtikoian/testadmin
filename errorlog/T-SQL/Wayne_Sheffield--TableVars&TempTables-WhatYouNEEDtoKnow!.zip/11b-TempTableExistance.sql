/* run from another connection
CREATE TABLE #TestTable (RowID INT);
*/

IF EXISTS (SELECT 1 FROM tempdb.sys.tables 
            WHERE name like '#TestTable%') 
   PRINT 'Hi';
IF EXISTS (SELECT 1 FROM tempdb.sys.tables 
            WHERE name like '#TestTable%') 
   SELECT * FROM #TestTable;

IF EXISTS (SELECT * FROM #TestTable) 
   PRINT 'Hi';

IF EXISTS (SELECT * FROM sys.objects 
            WHERE NAME = '#TestTable') 
   PRINT 'Hi';

IF EXISTS (SELECT * FROM tempdb.INFORMATION_SCHEMA.Tables 
            WHERE Table_Name Like'#TestTable%') 
   PRINT 'Hi';
IF EXISTS (SELECT * FROM tempdb.INFORMATION_SCHEMA.Tables 
            WHERE Table_Name Like'#TestTable%') 
   SELECT * FROM #TestTable;























select name from tempdb.sys.tables where name like '#TestTable%'
























IF OBJECT_ID('tempdb..#TestTable') IS NOT NULL
PRINT '#TestTable Table Exists'
ELSE
PRINT '#TestTable Table Does Not Exist'