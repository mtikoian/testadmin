SET NOCOUNT ON;
-- get the object_id's from all tables in tempdb
SELECT object_id 
  INTO #test 
  FROM tempdb.sys.tables;
GO

-- make a new table variable
DECLARE @TestTable TABLE (
  RowID   INT IDENTITY PRIMARY KEY CLUSTERED,
  SSN     CHAR(9) NOT NULL UNIQUE,
  Age     TINYINT NULL CHECK (Age > 18),
  rowguid UNIQUEIDENTIFIER NOT NULL DEFAULT(newid()));

-- get the object_id of any table now in tempdb
-- that isn't in the #test temp table.
DECLARE @object_id INT;
SELECT @object_id = 
  (SELECT object_id 
     FROM tempdb.sys.tables
   EXCEPT
   SELECT object_id 
     FROM #test);

-- get the index definitions of this table
SELECT name, index_id
  FROM tempdb.sys.indexes 
 WHERE object_id = @object_id;

-- get the columns in the indexes
SELECT sc.name, sic.*
  FROM tempdb.sys.index_columns sic
       JOIN tempdb.sys.columns sc
         ON sic.object_id = sc.object_id
        AND sic.column_id = sc.column_id
 WHERE sic.object_id = @object_id; 


GO
DROP TABLE #test;
GO

