DECLARE @LargeTable TABLE (
	id INT IDENTITY PRIMARY KEY,
	LargeStringColumn1 CHAR(100),
	LargeStringColumn2 CHAR(100)
);

INSERT INTO @LargeTable (
  LargeStringColumn1, 
  LargeStringColumn2)
SELECT TOP (100000) 
       'Table Variable Test',
       'SQL Saturday #111... HotLanta is... hot!'
  FROM master.sys.columns a 
       CROSS JOIN master.sys.columns b;

RAISERROR('INSERTS FINISHED',10,1) WITH NOWAIT;
-- so that the table var doesn't go out of scope 
-- and get deallocated too quickly.
WAITFOR DELAY '00:05:00'; 