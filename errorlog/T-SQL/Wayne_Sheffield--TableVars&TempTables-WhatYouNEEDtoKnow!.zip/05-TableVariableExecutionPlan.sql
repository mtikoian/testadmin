DECLARE @TestTable TABLE (RowID int);
INSERT INTO @TestTable
SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 0))
  FROM master.sys.all_columns;

SELECT RowID 
  FROM @TestTable;























SELECT RowID 
  FROM @TestTable 
OPTION (RECOMPILE);

SELECT RowID 
  FROM @TestTable;
