CREATE TABLE #TestTable (
  RowID INT IDENTITY CONSTRAINT PK_TestTable PRIMARY KEY CLUSTERED,
  SSN char(9) NOT NULL CONSTRAINT UQ_TestTable UNIQUE,
  Age tinyint CHECK(Age>18));

/*
DROP TABLE #TestTable
*/

CREATE TABLE #TestTable (
  RowID INT IDENTITY PRIMARY KEY CLUSTERED,
  SSN char(9) NOT NULL UNIQUE,
  Age tinyint CHECK(Age>18));
CREATE INDEX IX_TestTable ON #TestTable (Age, SSN);









declare @object_id int;
set @object_id = object_id('tempdb..#TestTable');
select * from tempdb.sys.tables where object_id = @object_id;
select * from tempdb.sys.key_constraints 
 where parent_object_id = @object_id;
select * from tempdb.sys.check_constraints 
 where parent_object_id = @object_id;
select * from tempdb.sys.indexes where object_id = @object_id;
select * from tempdb.sys.objects where type = 'U';
