/*
This demo is courtesy of Gail Shaw, SQL Server MVP/MCM, on her
TSQL Tuesday "Myths" blog post of "A Trio of Table Variables" 
at http://sqlinthewild.co.za/index.php/2010/10/12/a-trio-of-table-variables/
*/
USE tempdb -- make sure that the correct database is in use
GO
-- To truncate the log and indicate the start of the test
CHECKPOINT 

DECLARE @TransactionTest TABLE (
ID INT PRIMARY KEY,
SomeCol VARCHAR(20)
);

INSERT INTO @TransactionTest (ID, SomeCol) VALUES (0,'Row1');
INSERT INTO @TransactionTest (ID, SomeCol) VALUES (1,'Row2');

BEGIN TRANSACTION;
INSERT INTO @TransactionTest (ID, SomeCol) VALUES (2,'Row3');
ROLLBACK TRANSACTION;
SELECT * FROM @TransactionTest;
SELECT Operation, AllocUnitName, [Begin Time], [End Time] 
  FROM fn_dblog(NULL, NULL);
GO

















USE tempdb -- make sure that the correct database is in use
GO
-- To truncate the log and indicate the start of the test
CHECKPOINT 

DECLARE @TransactionTest TABLE (
ID INT PRIMARY KEY,
SomeCol VARCHAR(20)
);

INSERT INTO @TransactionTest (ID, SomeCol)
VALUES
(0,'Row1'),
(1,'Row2'),
(1,'Row3');
SELECT * FROM @TransactionTest;
SELECT Operation, AllocUnitName, [Begin Time], [End Time] 
  FROM fn_dblog(NULL, NULL);
