SET NOCOUNT ON;
DECLARE @TestTable TABLE (
  RowID   INT IDENTITY PRIMARY KEY CLUSTERED,
  SSN     CHAR(9) NOT NULL UNIQUE,
  Age     TINYINT NULL CHECK (Age > 18),
  rowguid UNIQUEIDENTIFIER NOT NULL DEFAULT(newid()));

INSERT INTO @TestTable (SSN, Age) VALUES ('123456789', 25);
INSERT INTO @TestTable (SSN, Age) VALUES ('987654321', 21);

SELECT 'Insert rows', * FROM @TestTable;

-- Add a duplicate SSN - violates Unique constraint
INSERT INTO @TestTable (SSN, Age) VALUES ('123456789', 28);
SELECT 'Insert dupe SSN', * FROM @TestTable;

-- updates are allowed
UPDATE @TestTable
   SET Age = Age - 3
 WHERE SSN = '123456789';
SELECT 'Perform update', * FROM @TestTable;

-- deletes are allowed
DELETE @TestTable
 WHERE SSN = '123456789';
SELECT 'Delete Rows', * FROM @TestTable;

-- show violating the check constraint on Age
INSERT INTO @TestTable (SSN, Age) VALUES ('951456753', 15);
SELECT 'Insert violates Check constraint', * FROM @TestTable;

-- show violating the NOT NULL constraint on SSN
INSERT INTO @TestTable (SSN, Age) VALUES (null, 28);
SELECT 'Insert NULL into a NOT NULL column', * FROM @TestTable;
GO

