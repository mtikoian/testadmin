SET NOCOUNT ON
GO
USE Sandbox
GO

IF EXISTS (SELECT 1 FROM sys.tables WHERE name = 'TestTable') 
   DROP TABLE dbo.TestTable;
GO

CREATE TABLE dbo.TestTable (
  RowID INT IDENTITY PRIMARY KEY CLUSTERED,
  SSN   char(9) UNIQUE,
  Age   tinyint CHECK(Age > 18));
GO

CREATE TRIGGER trgInsert ON dbo.TestTable 
FOR INSERT AS
PRINT 'Start of Trigger';
DECLARE @TestTable TABLE (
  RowID INT,
  SSN char(9),
  Age tinyint);

IF EXISTS (SELECT 1 FROM inserted WHERE Age = 21) BEGIN
  INSERT INTO @TestTable 
  SELECT RowID, SSN, Age 
    FROM inserted;
  SELECT '@TestTable in IF', * FROM @TestTable;
  ROLLBACK TRANSACTION;
  PRINT 'Transaction Rolled Back';
END;

SELECT '@TestTable after rollback', * FROM @TestTable;
GO

INSERT INTO dbo.TestTable (SSN, Age)
VALUES ('123456789', 25),
       ('987654321', 21);
GO

SELECT 'TestTable', * FROM dbo.TestTable ;
GO
IF EXISTS (SELECT 1 FROM sys.tables WHERE name = 'TestTable') 
   DROP TABLE dbo.TestTable;
GO
