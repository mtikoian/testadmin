CREATE TABLE #test (col1 INTEGER);
SELECT @@SERVERNAME, OBJECT_ID('tempdb..#test');
GO
