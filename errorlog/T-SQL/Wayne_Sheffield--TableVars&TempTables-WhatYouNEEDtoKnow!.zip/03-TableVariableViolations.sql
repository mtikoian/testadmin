









-- can't SELECT INTO a table variable
SELECT name 
  INTO @TestTable
  FROM master.sys.tables;
GO

















-- can't assign contents of one table variable
-- to a different table variable.
DECLARE @TestTable TABLE (
  RowID INT IDENTITY PRIMARY KEY CLUSTERED,
  SSN   char(9) NOT NULL UNIQUE,
  Age   tinyint NULL CHECK (Age > 18));

INSERT INTO @TestTable VALUES ('123456789', 25);
INSERT INTO @TestTable VALUES ('987654321', 21);

DECLARE @TestTable2 TABLE (
  RowID INT IDENTITY PRIMARY KEY CLUSTERED,
  SSN   char(9) NOT NULL UNIQUE,
  Age   tinyint NULL CHECK (Age > 18));

SET @TestTable2 = @TestTable;

GO












-- can't truncate a table variable
DECLARE @TestTable TABLE (
  RowID INT IDENTITY PRIMARY KEY CLUSTERED,
  SSN   char(9) NOT NULL UNIQUE,
  Age   tinyint NULL CHECK (Age > 18));
INSERT INTO @TestTable VALUES ('123456789', 25);
INSERT INTO @TestTable VALUES ('987654321', 21);

TRUNCATE TABLE @TestTable;

GO













-- can't use named constraints on a table variable
DECLARE @TestTable TABLE (
  RowID INT IDENTITY CONSTRAINT [PK_TestTable] PRIMARY KEY CLUSTERED,
  SSN   char(9) NOT NULL CONSTRAINT [UQ_TestTable] UNIQUE,
  Age   tinyint NULL CHECK (Age > 18));

-- same syntax does work for a temporary table
CREATE TABLE #Constraints(
  RowID INT IDENTITY CONSTRAINT [PK_TestTable] PRIMARY KEY CLUSTERED,
  SSN   char(9) NOT NULL CONSTRAINT [UQ_TestTable] UNIQUE,
  Age   tinyint NULL CHECK (Age > 18));
SELECT * FROM #Constraints;
DROP TABLE #Constraints;
GO













-- can't insert explicit values into an 
-- identity column on a table variable.
DECLARE @TestTable TABLE (
  RowID INT IDENTITY PRIMARY KEY CLUSTERED,
  SSN   char(9) NOT NULL UNIQUE,
  Age   tinyint NULL CHECK (Age > 18));
INSERT INTO @TestTable VALUES ('123456789', 25);
INSERT INTO @TestTable VALUES ('987654321', 21);

SET IDENTITY_INSERT @TestTable ON;
INSERT INTO @TestTable (RowID, SSN, Age) 
VALUES (100, '123456987', 25);
SET IDENTITY_INSERT @TestTable OFF;

GO





