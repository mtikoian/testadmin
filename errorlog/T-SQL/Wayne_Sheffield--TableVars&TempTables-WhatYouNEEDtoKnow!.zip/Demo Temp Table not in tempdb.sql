IF OBJECT_ID('tempdb..#test') IS NOT NULL DROP TABLE #test;
CREATE TABLE #test (Col1 char(5));
INSERT INTO #test VALUES ('Wayne');
SELECT * FROM #test;