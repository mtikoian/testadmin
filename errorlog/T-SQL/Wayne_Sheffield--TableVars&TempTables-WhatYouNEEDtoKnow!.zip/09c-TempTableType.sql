USE tempdb
GO
if object_id('tempdb..#TestTable') IS NOT NULL 
DROP TABLE #TestTable;
if exists (select 1 from sys.types WHERE name = 'SSN') 
DROP TYPE dbo.SSN;
if exists (select 1 from sys.types WHERE name = 'AGE') 
DROP TYPE dbo.AGE;

USE Sandbox;
GO
if exists (select 1 from sys.types WHERE name = 'SSN') 
DROP TYPE dbo.SSN;
if exists (select 1 from sys.types WHERE name = 'AGE') 
DROP TYPE dbo.AGE;
GO

USE tempdb
GO
-- create the UDDTs in the tempdb database.
CREATE TYPE dbo.SSN 
  FROM CHAR(9) NOT NULL;
GO
CREATE TYPE dbo.AGE
  FROM TINYINT NOT NULL;
GO

USE Sandbox;
GO

-- create the UDDTs in the Sandbox database.
CREATE TYPE dbo.SSN 
  FROM CHAR(9) NOT NULL; 
GO
CREATE TYPE dbo.AGE
  FROM TINYINT NOT NULL; 
GO

-- now the temporary table can be created
RAISERROR('CREATE TEMPORARY TABLE',10,1) WITH NOWAIT;
CREATE TABLE #TestTable (
  RowID INT IDENTITY,
  AGE AGE,
  SSN SSN)

-- notice that a table variable can now be created 
-- with the UDDTs in the local database.
RAISERROR('DECLARE TABLE VARIABLE',10,1) WITH NOWAIT;
DECLARE @TestTable TABLE (
  RowID INT IDENTITY,
  AGE AGE,
  SSN SSN)
