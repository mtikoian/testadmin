-- Can you get a table variable to have an estimated row count <> 1?
-- ... without using the OPTION(RECOMPILE) query hint 
--     or the WITH RECOMPILE option on the stored procedure?

-- This demo is from Dave Ballentine and his blog post:
-- http://sqlblogcasts.com/blogs/sqlandthelike/archive/2011/12/02/mythbusting-table-variables-have-no-statistics.aspx

USE Sandbox;
GO

IF OBJECT_ID('dbo.IDs', 'U') IS NOT NULL 
   DROP TABLE dbo.IDs;
IF OBJECT_ID('dbo.TableVarTest', 'P') IS NOT NULL 
   DROP PROCEDURE dbo.TableVarTest;
GO

CREATE TABLE dbo.IDs
       (
        ID INTEGER PRIMARY KEY,
        Padding CHAR(255)
       );
INSERT  INTO IDs
VALUES  (1, 'XXX');
GO

CREATE PROCEDURE dbo.TableVarTest
AS 
DECLARE @TableVar TABLE (
    ID INTEGER NOT NULL,
    Mod10 INTEGER NOT NULL
);

INSERT  INTO @TableVar (ID, Mod10)
SELECT  TOP (20)
        N, N % 10
FROM    dbo.Tally
ORDER BY N;

-- this is just to complicate the procedure, and to make it have more query plans
SELECT  COUNT(*)
FROM    AdventureWorks2012.Sales.Customer C
        JOIN AdventureWorks2012.Sales.SalesOrderHeader CO
            ON C.CustomerId = CO.CustomerId;
   
SELECT  tv.Id, IDs.id
FROM    @TableVar tv
        JOIN IDs
            ON tv.ID = IDs.Id
WHERE   mod10 = 0;
GO

/*
-- turn on the actual execution plan, then execute the procedure.
EXECUTE dbo.TableVarTest;
*/


/*
-- add more records to IDs:
INSERT INTO IDs (ID, Padding)
SELECT TOP (1000) N, 'XXX'
FROM   dbo.Tally
WHERE N NOT IN (SELECT ID FROM dbo.IDs)
ORDER BY N;

-- force a recompile
EXECUTE sp_recompile IDs;

-- execute the procedure again
EXECUTE dbo.TableVarTest;
*/