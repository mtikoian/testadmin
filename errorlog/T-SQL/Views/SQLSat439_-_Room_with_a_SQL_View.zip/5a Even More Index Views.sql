USE AdventureWorks2012; 
GO 

-- The normal query (with aggregate)
SELECT CUST.CustomerID
	,SOH.SalesOrderID
	,SOD.ProductID
	,SUM(SOD.OrderQty) AS TotalOrderQty
	,SUM(LineTotal) AS TotalValue
FROM Sales.SalesOrderHeader SOH
JOIN Sales.SalesOrderDetail SOD ON SOH.SalesOrderID = SOD.SalesOrderID
JOIN Production.Product PROD ON PROD.ProductID = SOD.ProductID
JOIN Sales.Customer CUST ON SOH.CustomerID = CUST.CustomerID
JOIN Person.Person PER ON PER.BusinessEntityID = CUST.PersonID
GROUP BY CUST.CustomerID
	,SOH.SalesOrderID
	,SOD.ProductID;




-- Create the new view for the aggregates
IF OBJECT_ID ('Sales.vSalesSummaryCustomerProduct', 'V') IS NOT NULL DROP VIEW Sales.vSalesSummaryCustomerProduct; 
GO 

CREATE VIEW Sales.vSalesSummaryCustomerProduct
WITH SCHEMABINDING
AS
	SELECT CUST.CustomerID
		,SOH.SalesOrderID
		,SOD.ProductID
		,SUM(SOD.OrderQty) AS TotalOrderQty
		,SUM(LineTotal) AS TotalValue
		,COUNT_BIG(*) AS CountLines
	FROM Sales.SalesOrderHeader SOH
	JOIN Sales.SalesOrderDetail SOD ON SOH.SalesOrderID = SOD.SalesOrderID
	JOIN Production.Product PROD ON PROD.ProductID = SOD.ProductID
	JOIN Sales.Customer CUST ON SOH.CustomerID = CUST.CustomerID
	JOIN Person.Person PER ON PER.BusinessEntityID = CUST.PersonID
	GROUP BY CUST.CustomerID
		,SOH.SalesOrderID
		,SOD.ProductID;
		
GO



-- Creating clustered index for the nice aggregate...
CREATE UNIQUE CLUSTERED INDEX CX_vSalesSummaryCustomerProduct
  ON Sales.vSalesSummaryCustomerProduct(CustomerID, SalesOrderID, ProductID); 
GO


-- Notice how well we're executing...
SET STATISTICS IO ON;
GO

SELECT  CustomerID ,
        SalesOrderID ,
        TotalOrderQty ,
        TotalValue
FROM    Sales.vSalesSummaryCustomerProduct WITH (NOEXPAND);


SET STATISTICS IO OFF;
GO






-- But are we using all the indexes that we can to make the best query results?
SELECT  CustomerID ,
        COUNT(SalesOrderID) AS OrderCount ,
        SUM(TotalValue) AS OrderValue
FROM    Sales.vSalesSummaryCustomerProduct WITH (NOEXPAND)
WHERE   CustomerID = 30103
GROUP BY CustomerID; 






-- Creating Non-Clustered indexes to help things out....
DECLARE @ProductName VARCHAR(50) 
SET @ProductName = 'LL Mountain Frame - Black, 44'

SELECT  CustomerID ,
        SalesOrderID ,
        OrderQty ,
        Name
FROM    Sales.vCustomerOrders WITH (NOEXPAND)
WHERE   Name = @ProductName;

CREATE NONCLUSTERED INDEX IX_vCustomerOrders_Name
  ON Sales.vCustomerOrders(Name);






-- Didn't do any good, did it? Let's try again...
DROP INDEX IX_vCustomerOrders_Name ON Sales.vCustomerOrders;
GO

CREATE NONCLUSTERED INDEX IX_vCustomerOrders_Name
                          ON Sales.vCustomerOrders(Name)
INCLUDE (SalesOrderID, CustomerID, OrderQty);
GO






-- So what happens when we get rid of all indexes and try to run the query with hints?
DROP INDEX [CIX_vCustomerOrders] ON Sales.vCustomerOrders;
GO

