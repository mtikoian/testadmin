USE AdventureWorks2012; 
GO 

IF OBJECT_ID ('hiredate_view', 'V') IS NOT NULL DROP VIEW hiredate_view; 
GO 

CREATE VIEW hiredate_view AS 

	SELECT p.FirstName, p.LastName, e.BusinessEntityID, e.HireDate 
	FROM HumanResources.Employee e 
	JOIN Person.Person AS p ON e.BusinessEntityID = p.BusinessEntityID; 

GO 

-- Easily calling the recently created view
SELECT * FROM hiredate_view 


-- How can I work with a view?
SELECT HV.*, E.JobTitle
FROM hiredate_view HV
JOIN HumanResources.Employee E ON e.BusinessEntityID = HV.BusinessEntityID
