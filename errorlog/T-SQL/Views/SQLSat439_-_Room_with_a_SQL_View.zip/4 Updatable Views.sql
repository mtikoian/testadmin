USE AdventureWorks2012; 
GO 

IF OBJECT_ID ('hiredate_view', 'V') IS NOT NULL DROP VIEW hiredate_view; 
GO 

CREATE VIEW hiredate_view AS 

	SELECT p.FirstName, p.LastName, e.BusinessEntityID, e.HireDate 
	FROM HumanResources.Employee e 
	JOIN Person.Person AS p ON e.BusinessEntityID = p.BusinessEntityID; 

GO 

SELECT * FROM hiredate_view 





-- Updating via the view
UPDATE hiredate_view
SET HireDate = '1/1/2015'
WHERE LastName = 'Williams'
AND FirstName = 'Jill'

UPDATE hiredate_view
SET LastName = 'Williams-Sherman'
WHERE LastName = 'Williams'
AND FirstName = 'Jill'





-- Does this work?
UPDATE hiredate_view
SET LastName = 'Williams-Sherman',
	HireDate = '1/1/2015'
WHERE LastName = 'Williams'
AND FirstName = 'Jill'

/* Resetting data 
UPDATE hiredate_view
SET HireDate = '2/19/2003'
WHERE LastName = 'Williams'
AND FirstName = 'Jill'

UPDATE hiredate_view
SET LastName = 'Williams'
WHERE LastName = 'Williams-Sherman' */
