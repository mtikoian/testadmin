USE AdventureWorks2012; 
GO 

-- The normal query
SELECT CUST.CustomerID
	,PER.FirstName
	,PER.LastName
	,SOH.SalesOrderID
	,SOH.OrderDate
	,SOH.[Status]
	,SOD.ProductID
	,PROD.NAME
	,SOD.OrderQty
FROM Sales.SalesOrderHeader SOH 
JOIN Sales.SalesOrderDetail SOD ON SOH.SalesOrderID = SOD.SalesOrderID
JOIN Production.Product PROD ON PROD.ProductID = SOD.ProductID
JOIN Sales.Customer CUST ON SOH.CustomerID = CUST.CustomerID
JOIN Person.Person PER ON PER.BusinessEntityID = CUST.PersonID;
GO


-- Inside a view (Notice the Schema Binding)
IF OBJECT_ID ('Sales.vCustomerOrders', 'V') IS NOT NULL DROP VIEW Sales.vCustomerOrders; 
GO 

CREATE VIEW Sales.vCustomerOrders
WITH SCHEMABINDING
AS

SELECT CUST.CustomerID
	,PER.FirstName
	,PER.LastName
	,SOH.SalesOrderID
	,SOH.OrderDate
	,SOH.[Status]
	,SOD.ProductID
	,PROD.NAME
	,SOD.OrderQty
FROM Sales.SalesOrderHeader SOH
JOIN Sales.SalesOrderDetail SOD ON SOH.SalesOrderID = SOD.SalesOrderID
JOIN Production.Product PROD ON PROD.ProductID = SOD.ProductID
JOIN Sales.Customer CUST ON SOH.CustomerID = CUST.CustomerID
JOIN Person.Person PER ON PER.BusinessEntityID = CUST.PersonID

GO


-- Now let's run it and see how well it performs
SET STATISTICS IO ON;
GO

SELECT * FROM Sales.vCustomerOrders;

SET STATISTICS IO OFF;
GO





-- Create an index up in here
CREATE UNIQUE CLUSTERED INDEX CIX_vCustomerOrders 
	ON Sales.vCustomerOrders(CustomerID, SalesOrderID, ProductID);



-- Now let's run it and see how well it performs
SET STATISTICS IO ON;
GO

SELECT * FROM Sales.vCustomerOrders

SET STATISTICS IO OFF;
GO





-- Are we using lots of disk space or just a little
SELECT i.[name] AS IndexName
    ,SUM(s.[used_page_count]) * 8 AS IndexSizeKB
FROM sys.dm_db_partition_stats AS s
INNER JOIN sys.indexes AS i ON s.[object_id] = i.[object_id]
    AND s.[index_id] = i.[index_id]
WHERE name = 'CIX_vCustomerOrders'
GROUP BY i.[name]
ORDER BY i.[name]
GO