USE AdventureWorks2012; 
GO 

IF OBJECT_ID ('hiredate_view', 'V') IS NOT NULL DROP VIEW hiredate_view; 
GO 

CREATE VIEW hiredate_view AS 

	SELECT p.FirstName, p.LastName, e.BusinessEntityID, e.HireDate 
	FROM HumanResources.Employee e 
	JOIN Person.Person AS p ON e.BusinessEntityID = p.BusinessEntityID
	UNION
	SELECT 'First Name' AS FirstName, 'Last Name' AS LastName, 
			0 AS BusinessEntityID, CONVERT(varchar(10), GetDate(), 101) AS HireDate
GO 

SELECT * FROM hiredate_view 

UPDATE hiredate_view SET LastName = 'Boise' WHERE LastName = 'Wright'








-- Changing order of views....
IF OBJECT_ID ('hiredate_view', 'V') IS NOT NULL DROP VIEW hiredate_view; 
GO 

CREATE VIEW hiredate_view AS 

	SELECT  * 
	FROM (
		SELECT p.FirstName, p.LastName, e.BusinessEntityID, e.HireDate 
		FROM HumanResources.Employee e 
		JOIN Person.Person AS p ON e.BusinessEntityID = p.BusinessEntityID
		UNION
		SELECT 'First Name' AS FirstName, 'Last Name' AS LastName, 
				0 AS BusinessEntityID, CONVERT(varchar(10), GetDate(), 101) AS HireDate
		) Z
	ORDER BY BusinessEntityID
GO 

SELECT * FROM hiredate_view 







/** "Fixed" in SQL Server 2005/2008. Not after
Fix can be found at https://support.microsoft.com/en-us/kb/926292
*/

/* What else can't we do in views?

 1) Use INTOs
 2) Reference a temp table or table variable