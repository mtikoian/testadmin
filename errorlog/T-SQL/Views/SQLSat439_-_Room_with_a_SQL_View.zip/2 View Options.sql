USE AdventureWorks2012; 
GO 

IF OBJECT_ID ('Salaried_view', 'V') IS NOT NULL DROP VIEW Salaried_view; 
GO 

CREATE VIEW Salaried_view AS 
(
	SELECT p.FirstName, p.LastName, e.BusinessEntityID, e.SalariedFlag
	FROM HumanResources.Employee e 
	JOIN Person.Person AS p ON e.BusinessEntityID = p.BusinessEntityID
	WHERE SalariedFlag = 1
)
WITH CHECK OPTION

GO 







-- Even if will make nothing show in the view, will SQL Server let us perform an update?
UPDATE Salaried_view SET SalariedFlag = 0

