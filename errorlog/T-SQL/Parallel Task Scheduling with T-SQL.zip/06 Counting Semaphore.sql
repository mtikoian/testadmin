use test
go
if object_id('AcquireSemaphore') is not null
	drop procedure AcquireSemaphore
if OBJECT_ID('ReleaseSemaphore') is not null
	drop procedure ReleaseSemaphore
go
create procedure AcquireSemaphore
(
	@Resource nvarchar(200),
	@TotalCount int = 3
)
as
begin
	declare @ResourceInternal nvarchar(255)
	declare @i int = 1, @ret int = -1
	if(applock_mode('public', @Resource, 'session') = 'IntentExclusive')
	begin
		raiserror('You have acquired semaphore', 16,1)
		return -1;
	end
	exec sp_getapplock	@Resource = @Resource,  
						@LockMode = 'IntentExclusive', 
						@LockOwner = 'Session', 
						@LockTimeout = -1
	while 1=1
	begin
		select @i = 1
		while @i <= @TotalCount
		begin
			-- @ResourceInternal will be the slot number + resource string passed in
			select @ResourceInternal = cast(@i as varchar(10)) + '-' + @Resource
			exec @ret = sp_getapplock	@Resource = @ResourceInternal,  
										@LockMode = 'Exclusive', 
										@LockOwner = 'Session', 
										@LockTimeout = 0 -- this will not cause blocking
			if @ret >=0
				return @i;
			select @i = @i +1
		end
		waitfor delay '00:00:00.050' --sleep(10)
	end
end
go
create procedure ReleaseSemaphore
(
	@Resource nvarchar(200), 
	@Slot int
)
as
begin
	declare @ResourceInternal nvarchar(255) = cast(@Slot as varchar(10)) + '-' + @Resource
	exec sp_releaseapplock @ResourceInternal, 'Session'
	exec sp_releaseapplock @Resource, 'Session'
end
go
/* test */
/*
declare @slot int
exec @slot = AcquireSemaphore 'CountingSemaphore'
select @slot

--exec ReleaseSemaphore 'CountingSemaphore', 1
*/