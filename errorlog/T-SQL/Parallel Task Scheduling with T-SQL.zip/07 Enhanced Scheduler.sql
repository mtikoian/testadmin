use master
go
if DB_ID('test') is not null
begin
	alter database test set single_user with rollback immediate
	drop  database test
end
go
create database test
alter database test set enable_broker
go
use test
go
create table ExecutoinLog
(
	ExecutinLogID int identity(1,1) primary key,
	SQL nvarchar(max),
	StartTime datetime2(7) default(sysdatetime()),
	EndTime datetime2(7)
)
go
create procedure ExecSQL(@SQL nvarchar(max))
as
begin
	set nocount on
	declare @ExecutionLogID int
	insert into ExecutoinLog (SQL)
		values(@SQL)
	select @ExecutionLogID = SCOPE_IDENTITY();
	exec(@SQL)
	update ExecutoinLog 
		set EndTime = sysdatetime()
	where ExecutinLogID = @ExecutionLogID
end

go
create procedure ActivationSchedulerQueue
as
begin
	declare @Handle uniqueidentifier, @Type sysname, @msg xml
	begin transaction
	waitfor(
		Receive top (1)
			@Handle = conversation_handle,
			@Type = message_type_name,
			@msg = cast(message_body as xml)
		from SchedulerQueue
	), timeout 500
	if @Handle is null
	begin
		rollback
		return;
	end
	if @Type = 'DEFAULT' and @msg is not null
	begin
		declare @SQL nvarchar(max), @PreviousOrder int, @CurrentOrder int, 
				@ResourcePrevious nvarchar(255),
				@ResourceCurrent nvarchar(255)
		select	@SQL = @msg.value('(//@SQL)[1]', 'nvarchar(max)'),
				@PreviousOrder = @msg.value('(//@PreviousOrder)[1]', 'int'),
				@CurrentOrder = @msg.value('(//@CurrentOrder)[1]', 'int')
				
		select @ResourceCurrent = 'SchedulerQueue - ' + CAST(@CurrentOrder as varchar(20))
		exec sp_getapplock @Resource = @ResourceCurrent,  @LockMode = 'Shared', @LockOwner = 'Session', @LockTimeout = -1
		
		commit
		
		select @ResourcePrevious = 'SchedulerQueue - ' + CAST(@PreviousOrder as varchar(20))
		exec sp_getapplock @Resource = @ResourcePrevious,  @LockMode = 'IntentExclusive', @LockOwner = 'Session', @LockTimeout = -1
		
		begin try
		exec ExecSQL @SQL
		end try
		begin catch
			-- place your error handling code here
		end catch
		
		exec sp_releaseapplock @ResourcePrevious, 'Session'
		exec sp_releaseapplock @ResourceCurrent, 'Session'
	end
	else
	begin
		commit
		end conversation @Handle;
	end
end
go
create queue SchedulerQueue 
	with status = on, 
	activation(
				status = on, 
				procedure_name = ActivationSchedulerQueue, 
				max_queue_readers = 5, 
				execute as self
				)
go
create service ServiceScheduler on queue SchedulerQueue([DEFAULT])
go
create procedure ExecAsync (@msg xml)
as
begin
	if @msg is null
		return;
	declare @handle uniqueidentifier
	select @handle = conversation_handle 
	from sys.conversation_endpoints 
	where is_initiator = 1 
		and far_service = 'ServiceScheduler'
		and state <> 'CD'
	if @@ROWCOUNT = 0
	begin
		begin dialog conversation @handle
		from service ServiceScheduler
		to service  'ServiceScheduler'
		on contract [DEFAULT]
		with encryption = off;
	end;
	send on conversation @handle message type [DEFAULT](@msg)
	return
end
go
--test
if object_id('tempdb..#SQLs') is not null
	drop table #SQLs
create table #SQLs (SQL nvarchar(max) not null, ExecutionOrder int not null)
create clustered index ExecutionOrder on #SQLs(ExecutionOrder)
go
declare @SQL nvarchar(max) = 'waitfor delay ''00:00:10.100'''
insert into #SQLs(SQL, ExecutionOrder) values(@SQL, 100)
insert into #SQLs(SQL, ExecutionOrder) values(@SQL, 100)
insert into #SQLs(SQL, ExecutionOrder) values(@SQL, 100)
insert into #SQLs(SQL, ExecutionOrder) values(@SQL, 100)
go
declare @SQL nvarchar(max) = 'waitfor delay ''00:00:09.200'''
insert into #SQLs(SQL, ExecutionOrder) values(@SQL, 200)
insert into #SQLs(SQL, ExecutionOrder) values(@SQL, 200)
go
declare @SQL nvarchar(max) = 'waitfor delay ''00:00:08.300'''
insert into #SQLs(SQL, ExecutionOrder) values(@SQL, 300)
go
declare @SQL nvarchar(max) = 'waitfor delay ''00:00:07.400'''
insert into #SQLs(SQL, ExecutionOrder) values(@SQL, 400)
insert into #SQLs(SQL, ExecutionOrder) values(@SQL, 400)
go
declare @SQL nvarchar(max) = 'waitfor delay ''00:00:06.500'''
insert into #SQLs(SQL, ExecutionOrder) values(@SQL, 500)
go
select * from #SQLs
go
set nocount on
declare @SQL nvarchar(max), @CurrentOrder int, @PreviousOrder int, @msg xml
declare c cursor for
	select  SQL [SQL], ExecutionOrder [CurrentOrder], 
			isnull(
				(select top 1 
					ExecutionOrder 
				from #SQLs s2
				where s1.ExecutionOrder > s2.ExecutionOrder
				order by ExecutionOrder desc
				), 0) [PreviousOrder]
	from #SQLs s1
	order by ExecutionOrder
open c
fetch next from c into @SQL, @CurrentOrder, @PreviousOrder
while @@fetch_status = 0
begin
	select @msg = (select @SQL [@SQL], @CurrentOrder [@CurrentOrder], @PreviousOrder [@PreviousOrder] for xml path('Command'));
	--select @msg
	exec ExecAsync @msg
	fetch next from c into @SQL, @CurrentOrder, @PreviousOrder
end
close c
deallocate c
go
select * from #SQLs
select * from ExecutoinLog 
select * from sys.conversation_endpoints


