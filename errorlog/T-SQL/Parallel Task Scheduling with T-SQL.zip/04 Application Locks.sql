-- locks are supported: Shared, eXclusive, Intent Shared, Intent Exclusive, Update
use msdb
select resource_type, resource_description, request_mode, request_type, request_owner_type, request_reference_count,request_status 
from sys.dm_tran_locks 
where request_session_id = @@spid

use tempdb
select resource_type, resource_description, request_mode, request_type, request_owner_type, request_reference_count,request_status 
from sys.dm_tran_locks 
where request_session_id = @@spid


--Demo 1
exec sp_getapplock 	@Resource = 'MyRes is a loooooooooooong string', 
					@LockMode = 'Shared',
					@LockOwner = 'Session'
select resource_type, resource_description, request_mode, request_type, request_owner_type, request_reference_count,request_status from sys.dm_tran_locks where request_session_id = @@spid
exec sp_releaseapplock @Resource = 'MyRes is a loooooooooooong string', @LockOwner = 'Session'
select resource_type, resource_description, request_mode, request_type, request_owner_type, request_reference_count,request_status from sys.dm_tran_locks where request_session_id = @@spid

go

--Demo 2
begin transaction
exec sp_getapplock 	@Resource = 'MyRes is a loooooooooooong string', 
					@LockMode = 'Exclusive',
					@LockOwner = 'Transaction'
exec sp_getapplock 	@Resource = 'MyRes is a loooooooooooong string', 
					@LockMode = 'Shared',
					@LockOwner = 'Session'
select resource_type, resource_description, request_mode, request_type, request_owner_type, request_reference_count,request_status from sys.dm_tran_locks where request_session_id = @@spid
rollback
select resource_type, resource_description, request_mode, request_type, request_owner_type, request_reference_count,request_status from sys.dm_tran_locks where request_session_id = @@spid
exec sp_releaseapplock @Resource = 'MyRes is a loooooooooooong string', @LockOwner = 'Session'
select resource_type, resource_description, request_mode, request_type, request_owner_type, request_reference_count,request_status from sys.dm_tran_locks where request_session_id = @@spid
go

--Demo 3
begin transaction
exec sp_getapplock 	@Resource = 'MyRes is a loooooooooooong string', 
					@LockMode = 'Shared',
					@LockOwner = 'Transaction'
select resource_type, resource_description, request_mode, request_type, request_owner_type, request_reference_count,request_status from sys.dm_tran_locks where request_session_id = @@spid

exec sp_getapplock 	@Resource = 'MyRes is a loooooooooooong string', 
					@LockMode = 'Exclusive',
					@LockOwner = 'Transaction'
select resource_type, resource_description, request_mode, request_type, request_owner_type, request_reference_count,request_status from sys.dm_tran_locks where request_session_id = @@spid
exec sp_releaseapplock @Resource = 'MyRes is a loooooooooooong string', @LockOwner = 'Transaction'
select resource_type, resource_description, request_mode, request_type, request_owner_type, request_reference_count,request_status from sys.dm_tran_locks where request_session_id = @@spid
rollback
select resource_type, resource_description, request_mode, request_type, request_owner_type, request_reference_count,request_status from sys.dm_tran_locks where request_session_id = @@spid

--Demo 4
begin transaction
exec sp_getapplock 	@Resource = 'MyRes is a loooooooooooong string', 
					@LockMode = 'IntentExclusive',
					@LockOwner = 'Transaction'
select resource_type, resource_description, request_mode, request_type, request_owner_type, request_reference_count,request_status from sys.dm_tran_locks where request_session_id = @@spid

exec sp_getapplock 	@Resource = 'MyRes is a loooooooooooong string', 
					@LockMode = 'Shared',
					@LockOwner = 'Transaction'
select resource_type, resource_description, request_mode, request_type, request_owner_type, request_reference_count,request_status from sys.dm_tran_locks where request_session_id = @@spid
exec sp_releaseapplock @Resource = 'MyRes is a loooooooooooong string', @LockOwner = 'Transaction'
select resource_type, resource_description, request_mode, request_type, request_owner_type, request_reference_count,request_status from sys.dm_tran_locks where request_session_id = @@spid
rollback
select resource_type, resource_description, request_mode, request_type, request_owner_type, request_reference_count,request_status from sys.dm_tran_locks where request_session_id = @@spid

