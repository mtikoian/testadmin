use master
go
if DB_ID('test') is not null
begin
	alter database test set single_user with rollback immediate
	drop  database test
end
go
create database test
alter database test set enable_broker
go
use test
go
create table ExecutionLog
(
	ExecutinLogID int identity(1,1) primary key,
	SQL nvarchar(max),
	StartTime datetime default(getdate()),
	EndTime datetime
)
go
create procedure ExecSQL(@SQL nvarchar(max))
as
begin
	set nocount on
	declare @ExecutionLogID int
	insert into ExecutionLog (SQL)
		values(@SQL)
	select @ExecutionLogID = SCOPE_IDENTITY();
	begin try
	exec(@SQL)
	end try
	begin catch
		--- error handling
	end catch
	update ExecutionLog 
		set EndTime = GETDATE()
	where ExecutinLogID = @ExecutionLogID
end

go
create procedure ActivationTarget
as
begin
	declare @Handle uniqueidentifier, @Type sysname, @msg nvarchar(max)
	waitfor(
		Receive top (1)
			@Handle = conversation_handle,
			@Type = message_type_name,
			@msg = message_body 
		from QueueTarget
	), timeout 5000
	if @Handle is null
		return;
	if @Type = 'DEFAULT' and @msg is not null
		exec ExecSQL @msg
	end conversation @Handle;
end
go
create queue QueueTarget 
	with status = on, 
	activation(
				status = on, 
				procedure_name = ActivationTarget, 
				max_queue_readers = 5, 
				execute as self
			)
go
create service ServiceTarget on queue QueueTarget([DEFAULT])
go
create queue QueueInitiator 
go
create service ServiceInitiator on queue QueueInitiator([DEFAULT])
go
create procedure ExecAsync (@SQL nvarchar(max), @handle uniqueidentifier = null output)
as
begin
	select @handle = null;
	if rtrim(isnull(@SQL, '')) = ''
		return;
	begin dialog conversation @handle
	from service ServiceInitiator
	to service 'ServiceTarget'
	on contract [DEFAULT]
	with encryption = off;
	send on conversation @handle message type [DEFAULT](@SQL)
	return
end
go
--test
if object_id('tempdb..#handles') is not null
	drop table #handles
create table #handles (handle uniqueidentifier primary key)
go
declare @SQL nvarchar(max) = 'waitfor delay ''00:00:10'''
declare @i int = 1, @handle uniqueidentifier
while @i<=10
begin
	exec ExecAsync @SQL, @handle output
	insert into #handles values(@handle)
	select @i +=1
end
go
---

--synchronization
declare @handle uniqueidentifier
while exists(select * from #handles)
begin
	waitfor(
		receive top (1) 
				@handle = conversation_handle 
		from QueueInitiator
	), timeout -1;
	end conversation @handle;
	delete #handles where handle = @handle
end
go
-- check
select * from ExecutionLog 
select datediff(second, min(StartTime), max(EndTime))  from ExecutionLog 
go
truncate table ExecutionLog 
go
-- if you don't care about when the process returns
------automatically end the conversation
create procedure ActivationInitiator
as
begin
	declare @Handle uniqueidentifier;
	waitfor(
		Receive top (1)
			@Handle = conversation_handle
		from QueueInitiator
	), timeout 50
	if @Handle is null
		return;
	end conversation @Handle;
end
go
alter queue QueueInitiator 
	with status = on, 
	activation(
				status = on, 
				procedure_name = ActivationInitiator, 
				max_queue_readers = 1, 
				execute as self
			)
go
declare @SQL nvarchar(max) = 'waitfor delay ''00:00:10''', 
		@i int = 1
while @i<=10
begin
	exec ExecAsync @SQL
	select @i +=1
end
go
select * from ExecutionLog 

select datediff(second, min(StartTime), max(EndTime))  from ExecutionLog 
select COUNT(*) from sys.conversation_endpoints  --overhead?
select * from sys.conversation_endpoints 