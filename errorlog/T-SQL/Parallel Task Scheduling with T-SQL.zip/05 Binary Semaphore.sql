use test
go
if object_id('dbo.MonitorEnter') is not null
	drop procedure dbo.MonitorEnter
go
if object_id('dbo.MonitorExit') is not null
	drop procedure dbo.MonitorExit
go
create procedure dbo.MonitorEnter (@SyncObject nvarchar(255))
as
begin
	declare @ret int
	exec @ret = sp_getapplock @Resource = @SyncObject, @LockMode = 'Exclusive', @LockOwner = 'Session'
	return @ret
end
go 
create procedure dbo.MonitorExit(@SyncObject nvarchar(255))
as
begin
	begin try
		exec sp_releaseapplock @Resource = @SyncObject, @LockOwner = 'Session'
	end try
	begin catch
		-- I don't care exceptions here
	end catch
end 

go
---- open 2 new seesions  to test
exec MonitorEnter 'Code 1'
print 'Code 1'
exec MonitorExit 'Code 1'

--select resource_type, resource_description, request_mode, request_type, request_owner_type, request_reference_count,request_status from sys.dm_tran_locks where request_session_id = @@spid

select blocking_session_id, l1.request_mode, l1.request_status, session_id, l2.request_mode, l2.request_status, a.wait_type, a.wait_resource, b.text
from sys.dm_exec_requests a
	cross apply sys.dm_exec_sql_text(a.sql_handle) b
	inner join sys.dm_tran_locks l1 on l1.request_session_id = a.blocking_session_id and l1.resource_type = 'Application'
	inner join sys.dm_tran_locks l2 on l2.request_session_id = a.session_id and l2.resource_type = 'Application'
