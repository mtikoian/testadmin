--do some cleanup 
use master
go
if DB_ID('test') is not null
begin
	alter database test set single_user with rollback immediate
	drop database test
end
go
create database test
go
alter database test set enable_broker
go
---Interfaces
use test
go
create table Tasks
(
    TaskID int identity(1,1) primary key,
    ExecutionOrder int null,
    TaskBody varchar(max) not null,
    Status varchar(20) not null default('Pending') -- can be Pending, Running, and Finished
)
go
create index IX_ExecutionOrder on Tasks(ExecutionOrder)
create index IX_Status on Tasks(Status)
go
create table Logs
(
	LogId bigint identity(1,1) primary key,
	TaskID int not null,
	ExecutionOrder int not null,
	TaskBody varchar(max),
	SPID int not null default(@@SPID),
	StartTime datetime not null default(getdate()),
	Endtime datetime
)
go
create procedure ExecuteTask(@TaskID int, @ExecutionOrder int, @TaskBody nvarchar(max))
as
begin
	declare @LogID bigint
	insert into Logs(TaskID, TaskBody, ExecutionOrder)
		values(@TaskID, @TaskBody, @ExecutionOrder)
	select @LogID = scope_identity()
	begin try
		exec(@TaskBody )
	end try
	begin catch
		-- your error handling logics
	end catch
	update Logs set EndTime = getdate() where LogID = @LogID
end
go
--- Scheduler
create queue QueueScheduler
create service ServiceScheduler on queue QueueScheduler([DEFAULT])
go
create procedure ActivationQueueScheduler
as
begin
	declare @Handle uniqueidentifier, @Type sysname, @msg nvarchar(max)
	waitfor(
		Receive top (1)
			@Handle = conversation_handle,
			@Type = message_type_name
		from QueueScheduler
	), timeout 5000  -- wait for 5 seconds
	if @Handle is null -- no message received
		return;
	if @Type = 'http://schemas.microsoft.com/SQL/ServiceBroker/DialogTimer'
	begin
		begin conversation timer (@Handle) timeout = 10; -- 10 seconds, you can specify 0, 1, etc
		exec LoadTask
	end
	else
		end conversation @Handle;
end
go

create procedure LoadTask
(
	@WaitingTime int = 30 -- when queue is empty, it waits for 30 second by default before quitting.
)
as
begin
	declare @StartTime datetime, @TaskID int, @TaskBody nvarchar(max), @ExecutionOrder int
	select @StartTime = getdate()
	while(1=1)
	begin
		begin transaction
		update top (1) t
			set @TaskID = TaskID,
				@TaskBody = TaskBody,
				@ExecutionOrder = ExecutionOrder,
				Status = 'Running'
		from Tasks t with (readpast)
		where t.Status = 'Pending'
			and not exists(
								select *
								from Tasks t1 with (nolock)
								where t1.ExecutionOrder < t.ExecutionOrder
									and t1.Status != 'Finished'
						)
		if @@rowcount = 1
		begin
			exec ExecuteTask @TaskID, @ExecutionOrder, @TaskBody
			update Tasks set Status = 'Finished'  where TaskID = @TaskID
			-- you can also remove finished tasks
			select @StartTime = getdate()
		end
		else
			waitfor delay '00:00:00:100' -- wait for 100 milliseconds
		commit -- we can commit anyways here
		if datediff(second, @StartTime, getdate()) > @WaitingTime
			break; -- if there is no task in the queue in last @WaitingTime seconds
	end
end
go
alter queue QueueScheduler
	with status = on , retention = off ,
	activation (
		status = on ,
		procedure_name = ActivationQueueScheduler,
		max_queue_readers = 3,
        execute as 'dbo'
        )
go

create procedure ExecAsync (@SQL varchar(max), @ExecutionOrder int)
as
begin
	insert into Tasks(TaskBody, ExecutionOrder) values(@SQL, @ExecutionOrder)
end
go
create procedure StartScheduler
as
begin
	declare @handle uniqueidentifier
	select @handle = conversation_handle
	from sys.conversation_endpoints
	where is_initiator = 1
		and far_service = 'ServiceScheduler'
		and state <> 'CD'
	if @@ROWCOUNT = 0
	begin
		begin dialog conversation @handle
		from service ServiceScheduler
		to service  'ServiceScheduler'
		on contract [DEFAULT]
		with encryption = off;

		declare @i int = 0, @MaxReaders int = 0
		select @MaxReaders = max_readers from sys.service_queues where name = 'QueueScheduler'
		while @i< @MaxReaders
		begin
			begin conversation timer (@Handle) timeout = 1;
			select @i = @i + 1
		end
	end;
end
go
create procedure StopScheduler
as
begin
	declare @handle uniqueidentifier
	select @handle = conversation_handle
	from sys.conversation_endpoints
	where is_initiator = 1
		and far_service = 'ServiceScheduler'
		and state <> 'CD'
	if @@ROWCOUNT <> 0
		end conversation @handle
end
go

---test
exec StartScheduler

exec ExecAsync 'Waitfor delay ''00:00:10.100''', 100
exec ExecAsync 'Waitfor delay ''00:00:10.100''', 100
exec ExecAsync 'Waitfor delay ''00:00:10.200''', 200
exec ExecAsync 'Waitfor delay ''00:00:10.200''', 200
exec ExecAsync 'Waitfor delay ''00:00:10.200''', 200
exec ExecAsync 'Waitfor delay ''00:00:10.300''', 300
exec ExecAsync 'Waitfor delay ''00:00:10.400''', 400
exec ExecAsync 'Waitfor delay ''00:00:10.400''', 400
exec ExecAsync 'Waitfor delay ''00:00:10.500''', 500
--wait for few seconds and then run
select * from Logs with (nolock)
select* from sys.dm_broker_activated_tasks