USE DemoDB
GO
/*
-- Used to Create the demo environment

CREATE TABLE dbo.TestTable (field VARCHAR(20))
GO
INSERT INTO dbo.TestTable ( field )
VALUES  ( 'Ben' ), ( 'George' ) 
GO
*/
DECLARE @id INT , @name VARCHAR(10)
SET @id = 1  -- Single assignment statement - ANSI way
SELECT @id
GO
DECLARE @id INT , @name VARCHAR(10)
SELECT @id = 1, @name = 'Ben'  -- Multiple assignment statement
SELECT @id, @name
GO
DECLARE @id INT , @name VARCHAR(10)
SET @id = (SELECT 1 FROM dbo.TestTable) -- ANSI way
SELECT @id
GO
-- multiple selects in a table


SELECT *
FROM dbo.testtable
GO
-- No WHERE clause and SQL gets to decide the order
-- because we know that the only way to get the data
-- back in a specific order, use ORDER BY
DECLARE @name VARCHAR(10)

SELECT @name = field
FROM dbo.TestTable

SELECT @name AS NAME
GO

-- Gets the last row value
DECLARE @name VARCHAR(10)

SELECT field
FROM dbo.TestTable

SELECT @name = field
FROM dbo.TestTable
ORDER BY field DESC

SELECT @name AS NAME
GO
-- Now let's be specific
DECLARE @name VARCHAR(10)

SELECT @name = field
FROM dbo.TestTable
WHERE field = 'Ben'

SELECT @name AS NAME

SELECT (SELECT TOP 1 field FROM dbo.TestTable)
FROM dbo.TestTable

GO
-- ANSI way throws an error
DECLARE @name VARCHAR(10)

SELECT field
FROM dbo.TestTable

SET @name = (SELECT field FROM dbo.TestTable)

SELECT @name AS NAME
GO

/* Assignment by UPDATE statement */
declare @name varchar(10)
update dbo.testtable
set @name = field,
field = 'Bob'

select @name

select *
from dbo.TestTable
GO
/*
Contact Information:
Ben Miller
ben@benmiller.net
@DBAduck

CREATE TABLE TestTable (
	field VARCHAR(10)
)
GO
CREATE TABLE dbo.TestSchema (
	field1 VARCHAR(10)
)
GO
insert into dbo.TestSchema
values ('dbo')
GO
CREATE SCHEMA dba AUTHORIZATION [dbo]
GO
CREATE TABLE dba.TestSchema (
	field2 varchar(10)
)
insert into dba.TestSchema
values ('dba')
GO
grant select on schema::dba to testlogin

*/
use demodb
GO

-- Which table do I get?
SELECT *
FROM TestSchema

-- Lets try as testlogin
EXECUTE AS USER = 'testlogin'

select suser_name()

GO
SELECT *
FROM dbo.TestSchema
GO
REVERT
GO

-- If I am DBO or db_owner then I will get the dbo copy
-- If I have a default schema that is NOT dbo, then I will get dbo
-- If I have a default schema that is dba then it will get dba.TestSchema
