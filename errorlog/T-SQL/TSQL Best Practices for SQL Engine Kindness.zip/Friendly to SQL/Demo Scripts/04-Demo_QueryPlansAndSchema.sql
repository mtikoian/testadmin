
EXEC sys.sp_configure N'show advanced options', N'1'  RECONFIGURE WITH OVERRIDE
GO
EXEC sys.sp_configure N'optimize for ad hoc workloads', N'0'
GO
RECONFIGURE WITH OVERRIDE
GO
EXEC sys.sp_configure N'show advanced options', N'0'  RECONFIGURE WITH OVERRIDE
GO

DBCC freeproccache

-- View the cached plans
SELECT *
FROM sys.dm_exec_cached_plans

SELECT *
FROM sys.syscacheobjects

-- Let's do a basic query
SELECT *
FROM  dbo.testtable

-- Let's do the same query, Kind Of
SELECT *
FROM dbo.TestTable

-- View the cached plans
SELECT *
FROM sys.dm_exec_cached_plans

SELECT *
FROM sys.syscacheobjects


-- You will see queries that have their own plan because of 
-- Case Sensitivity

EXEC sys.sp_configure N'show advanced options', N'1'  RECONFIGURE WITH OVERRIDE
GO
EXEC sys.sp_configure N'optimize for ad hoc workloads', N'1'
GO
RECONFIGURE WITH OVERRIDE
GO
EXEC sys.sp_configure N'show advanced options', N'0'  RECONFIGURE WITH OVERRIDE
GO

DBCC freeproccache

-- View the cached plans
SELECT *
FROM sys.dm_exec_cached_plans

SELECT *
FROM sys.syscacheobjects

-- Let's do a basic query
SELECT *
FROM  dbo.testtable

-- Let's do the same query, Kind Of
SELECT *
FROM dbo.TestTable

-- You will see queries that have their own plan because of 
-- Case Sensitivity
