USE AdventureWorks2012
GO
CREATE INDEX IX_PurchaseOrderHeader_OrderDate ON Purchasing.PurchaseOrderHeader (
	OrderDate
)
GO
SET STATISTICS IO ON

SELECT OrderDate
FROM Purchasing.PurchaseOrderHeader
WHERE OrderDate BETWEEN GETDATE()-3631 AND GETDATE()-3600


DECLARE @date1 DATETIME, @date2 DATETIME
SELECT @date1 = GETDATE()-3631, @date2 = GETDATE()-3600

SELECT OrderDate
FROM Purchasing.PurchaseOrderHeader
WHERE OrderDate BETWEEN @date1 AND @date2

