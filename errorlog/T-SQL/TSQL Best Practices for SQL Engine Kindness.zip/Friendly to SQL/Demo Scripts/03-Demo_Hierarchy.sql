/*
-- Use the features that come with SQL Server. Not all features
-- match up to things you will do or will scale the way you want,
-- but it is a best practice to utilize features that help when possible.
-- BEGIN
-- This will give me a count of All offices under the root.
-- We currently have a table of Offices
CREATE TABLE [dbo].[Offices](
	[Id] [varchar](5) NOT NULL,
	[NAME] [nvarchar](50) NULL,
	[ParentId] [varchar](5) NULL
) ON [PRIMARY]
SELECT *
FROM dbo.Offices
	 b
INSERT INTO dbo.Offices
VALUES ('OFF1', 'Main Office 1', NULL),
('OFF2', 'Second Office', 'OFF1'),
('OFF3', 'Third Office', 'OFF1'),
('OFF4', 'Fourth Office', 'OFF2'),
('OFF5', 'Fifth Office', 'OFF3'),
('OFF6', 'Sixth Office', 'OFF3'),
('OFF7', 'Seventh Office', 'OFF3'),
('OFF8', 'Eighth Office', 'OFF4'),
('OFF9', 'Ninth Office', 'OFF4'),
('OFF10', 'Tenth Office', 'OFF5'),
('OFF11', 'T Office', 'OFF3'),
('OFF12', 'Twelfth Office', 'OFF6'),
('OFF13', 'Thirteenth Office', 'OFF7'),
('OFF14', 'Fourteenth Office', 'OFF19'),
('OFF15', 'Fifteenth Office', 'OFF20'),
('OFF16', 'Sixteenth Office', 'OFF21'),
('OFF17', 'Seventeenth Office', 'OFF27'),
('OFF18', 'Eighteenth Office', 'OFF14'),
('OFF19', 'Nineteenth Office', 'OFF19'),
('OFF20', 'Twentieth Office', 'OFF11'),
('OFF21', 'Twenty-First Office', 'OFF12'),
('OFF22', 'Twenty-Second Office', 'OFF11'),
('OFF23', 'Twenty-Third Office', 'OFF2'),
('OFF24', 'Twenty-Fourth Office', 'OFF18'),
('OFF25', 'Twenty-Fifth Office', 'OFF18'),
('OFF26', 'Twenty-Sixth Office', 'OFF10'),
('OFF27', 'Twenty-Seventh Office', 'OFF9')

GO
ALTER TABLE dbo.Offices ADD CONSTRAINT PK_Offices_Id PRIMARY KEY CLUSTERED ([id])
GO
*/

SET STATISTICS IO ON
GO

WITH paths(OfficeId) 
AS (
-- This section provides the value for the root of the hierarchy
	SELECT 
		Id 
	FROM dbo.Offices AS C 
	WHERE ParentId IS NULL 
	UNION ALL 
		-- This section provides values for all nodes except the root
	SELECT 
	C.Id
	FROM dbo.Offices AS C 
	JOIN paths AS p ON C.ParentId = P.OfficeId 
)
SELECT COUNT(*)
FROM paths;

/*
Table 'Offices'. Scan count 2, logical reads 47, physical reads 0, read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.
Table 'Worktable'. Scan count 2, logical reads 133, physical reads 0, read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.
*/
-- Now let's get a specific one

WITH paths(OfficeId) 
AS (
-- This section provides the value for the root of the hierarchy
	SELECT 
		Id 
	FROM dbo.Offices AS C 
	WHERE Id = 'OFF14' 
	UNION ALL 
		-- This section provides values for all nodes except the root
	SELECT 
	C.Id
FROM dbo.Offices AS C 
JOIN paths AS p ON C.ParentId = P.OfficeId 
)
SELECT *
FROM paths
WHERE OfficeId = 'OFF14'

-- Now look at the reads
use AdventureWorks2012
GO
DECLARE @currentNode HIERARCHYID;
	
SELECT @currentNode = OrganizationNode
FROM HumanResources.Employee
WHERE LoginId = 'adventure-works\ken0'

SELECT COUNT(*)
FROM HumanResources.Employee TU
WHERE TU.OrganizationNode.IsDescendantOf(@currentNode) = 1
