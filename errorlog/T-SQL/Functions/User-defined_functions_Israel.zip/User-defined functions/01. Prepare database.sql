USE master;
go

-- Remove old version of demo database. Use brute force if necessary.
IF EXISTS (SELECT * FROM sys.databases WHERE name = N'UdfDemo')
  BEGIN;
  ALTER DATABASE UdfDemo SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
  DROP DATABASE UdfDemo;
  END;
go

-- Create the empty demo database, with sufficient size for the demo table.
-- To make the script run on all databases, I don't hardcode the directory,
-- but use the directory where the master database lives;
-- this gives me the guarantee that the directory exists
-- and is accessible by SQL Server.
--
-- Unfortunately, this requires the use of dynamic SQL,
-- which I normally avoid. In this case, though, the risk is acceptable.
-- The only way to exploit this dynamic SQL is to install an instance
-- with the master database in a directory with a carefully crafted pathname;
-- whoever can do that must have admin rights
-- and doesn't need the SQL injection attack.
DECLARE @master_directory nvarchar(260);
SET @master_directory =
 (SELECT REPLACE(physical_name, 'master.mdf', '')
  FROM   sys.database_files
  WHERE  name='master'
  AND    type=0);
EXECUTE
 (N'CREATE DATABASE UdfDemo
    ON PRIMARY
      (NAME = UdfDemo,
       FILENAME = ''' + @master_directory + N'UdfDemo.mdf'',
       SIZE = 150MB)
    LOG ON
      (NAME = UdfDemoLog,
       FILENAME = ''' + @master_directory + N'UdfDemo.ldf'',
       SIZE = 15MB);');
go

-- Switch to tempdb before switching to IndexDemo.
-- If IndexDemo was not created, the USE statement fails,
-- but the next batch will still execute.
-- Switching to tempdb first ensures spurious tables will be created there.

USE tempdb;
go
USE UdfDemo;
go

--
-- Create five tables as exact copies from AdventureWorks2012
-- (including the same indexes and the relevant foreign key constraints)
--
CREATE TABLE dbo.Person
      (BusinessEntityID   int               NOT NULL,
       PersonType         nchar(2)          NOT NULL,
       NameStyle          bit               NOT NULL,
       Title              nvarchar(8)       NULL,
       FirstName          nvarchar(50)      NOT NULL,
       MiddleName         nvarchar(50)      NULL,
       LastName           nvarchar(50)      NOT NULL,
       Suffix             nvarchar(10)      NULL,
       EmailPromotion     int               NOT NULL,
       AdditionalContactInfo
                          xml               NULL,
       Demographics       xml               NULL,
       rowguid            uniqueidentifier  NOT NULL ROWGUIDCOL DEFAULT (NEWID()),
       ModifiedDate       datetime          NOT NULL,
       CONSTRAINT PK_Person
                          PRIMARY KEY (BusinessEntityID),
       CONSTRAINT UQ_Person_rowguid
                          UNIQUE (rowguid)
      );

CREATE NONCLUSTERED INDEX IX_Person_LastName_FirstName_MiddleName
    ON dbo.Person (LastName, FirstName, MiddleName);

-- XML indexes omitted, as they are irrelevant for this presentation
go



CREATE TABLE dbo.Employee
      (BusinessEntityID   int               NOT NULL,
       NationalIDNumber   nvarchar(15)      NOT NULL,
       LoginID            nvarchar(256)     NOT NULL,
       OrganizationNode   hierarchyid       NULL,
       OrganizationLevel  AS (OrganizationNode.GetLevel()),
       JobTitle           nvarchar(50)      NOT NULL,
       BirthDate          date              NOT NULL,
       MaritalStatus      nchar(1)          NOT NULL,
       Gender             nchar(1)          NOT NULL,
       HireDate           date              NOT NULL,
       SalariedFlag       bit               NOT NULL,
       VacationHours      smallint          NOT NULL,
       SickLeaveHours     smallint          NOT NULL,
       CurrentFlag        bit               NOT NULL,
       rowguid            uniqueidentifier  NOT NULL ROWGUIDCOL DEFAULT (NEWID()),
       ModifiedDate       datetime          NOT NULL,
       CONSTRAINT PK_Employee
                          PRIMARY KEY (BusinessEntityID),
       CONSTRAINT UQ_Employee_LoginID
                          UNIQUE (LoginID),
       CONSTRAINT UQ_Employee_NationalIDNumber
                          UNIQUE (NationalIDNumber),
       CONSTRAINT UQ_Employee_rowguid
                          UNIQUE (rowguid),
       CONSTRAINT FK_Employee_Person
                          FOREIGN KEY (BusinessEntityID)
                          REFERENCES dbo.Person(BusinessEntityID)
      );

CREATE NONCLUSTERED INDEX IX_Employee_OrganizationLevel_OrganizationNode
    ON dbo.Employee (OrganizationLevel, OrganizationNode);

CREATE NONCLUSTERED INDEX IX_Employee_OrganizationNode
    ON dbo.Employee (OrganizationNode);
go



CREATE TABLE dbo.EmployeePayHistory
      (BusinessEntityID   int               NOT NULL,
       RateChangeDate     datetime          NOT NULL,
       Rate               money             NOT NULL,
       PayFrequency       tinyint           NOT NULL,
       ModifiedDate       datetime          NOT NULL,
       CONSTRAINT PK_EmployeePayHistory
                          PRIMARY KEY (BusinessEntityID, RateChangeDate),
       CONSTRAINT FK_EmployeePayHistory_Employee
                          FOREIGN KEY (BusinessEntityID)
                          REFERENCES dbo.Employee(BusinessEntityID)
      );
go



CREATE TABLE dbo.EmployeeDepartmentHistory
      (BusinessEntityID   int               NOT NULL,
       DepartmentID       smallint          NOT NULL,
       ShiftID            tinyint           NOT NULL,
       StartDate          date              NOT NULL,
       EndDate            date              NULL,
       ModifiedDate       datetime          NOT NULL,
       CONSTRAINT PK_EmployeeDepartmentHistory
                          PRIMARY KEY (BusinessEntityID, StartDate),
       CONSTRAINT FK_EmployeeDepartmentHistory_Employee
                          FOREIGN KEY (BusinessEntityID)
                          REFERENCES dbo.Employee(BusinessEntityID)
      );

CREATE NONCLUSTERED INDEX IX_EmployeeDepartmentHistory_DepartmentID
    ON dbo.EmployeeDepartmentHistory (DepartmentID);

CREATE NONCLUSTERED INDEX IX_EmployeeDepartmentHistory_ShiftID
    ON dbo.EmployeeDepartmentHistory (ShiftID);
go



CREATE TABLE dbo.SalesPerson
      (BusinessEntityID   int               NOT NULL,
       TerritoryID        int               NULL,
       SalesQuota         money             NULL,
       Bonus              money             NOT NULL,
       CommissionPct      smallmoney        NOT NULL,
       SalesYTD           money             NOT NULL,
       SalesLastYear      money             NOT NULL,
       rowguid            uniqueidentifier  NOT NULL ROWGUIDCOL DEFAULT (NEWID()),
       ModifiedDate       datetime          NOT NULL,
       CONSTRAINT PK_SalesPerson
                     PRIMARY KEY (BusinessEntityID),
       CONSTRAINT UQ_SalesPerson_rowguid
                          UNIQUE (rowguid),
       CONSTRAINT FK_SalesPerson_Employee
                          FOREIGN KEY (BusinessEntityID)
                          REFERENCES dbo.Employee(BusinessEntityID)
      );
go



--
-- Fill tables with 50 copies of original AdventureWorks2012 population
--
DECLARE @rpt int = 0;
WHILE @rpt <= 49
BEGIN;
  INSERT INTO dbo.Person
        (BusinessEntityID, PersonType, NameStyle, Title, FirstName, MiddleName, LastName, Suffix,
         EmailPromotion, AdditionalContactInfo, Demographics, ModifiedDate)
  SELECT BusinessEntityID + @rpt * 1000, PersonType, NameStyle, Title, FirstName, MiddleName, LastName + CAST(@rpt AS varchar(3)), Suffix,
         EmailPromotion, AdditionalContactInfo, Demographics, ModifiedDate
  FROM   AdventureWorks2012.Person.Person
  WHERE  BusinessEntityID <= 900;

  INSERT INTO dbo.Employee
        (BusinessEntityID, NationalIDNumber, LoginID, OrganizationNode, JobTitle, BirthDate, MaritalStatus,
         Gender, HireDate, SalariedFlag, VacationHours, SickLeaveHours, CurrentFlag, ModifiedDate)
  SELECT BusinessEntityID + @rpt * 1000, NationalIDNumber + CAST(@rpt AS varchar(3)), LoginID + CAST(@rpt AS varchar(3)), OrganizationNode, JobTitle, BirthDate, MaritalStatus,
         Gender, HireDate, SalariedFlag, VacationHours, SickLeaveHours, CurrentFlag, ModifiedDate
  FROM   AdventureWorks2012.HumanResources.Employee;

  INSERT INTO dbo.EmployeePayHistory
        (BusinessEntityID, RateChangeDate, Rate, PayFrequency, ModifiedDate)
  SELECT BusinessEntityID + @rpt * 1000, RateChangeDate, Rate, PayFrequency, ModifiedDate
  FROM   AdventureWorks2012.HumanResources.EmployeePayHistory;

  INSERT INTO dbo.EmployeeDepartmentHistory
        (BusinessEntityID, DepartmentID, ShiftID, StartDate, EndDate, ModifiedDate)
  SELECT BusinessEntityID + @rpt * 1000, DepartmentID, ShiftID, StartDate, EndDate, ModifiedDate
  FROM   AdventureWorks2012.HumanResources.EmployeeDepartmentHistory;

  INSERT INTO dbo.SalesPerson
        (BusinessEntityID, TerritoryID, SalesQuota, Bonus, CommissionPct, SalesYTD, SalesLastYear, ModifiedDate)
  SELECT BusinessEntityID + @rpt * 1000, TerritoryID, SalesQuota, Bonus, CommissionPct, SalesYTD, SalesLastYear, ModifiedDate
  FROM   AdventureWorks2012.Sales.SalesPerson;

  SET @rpt += 1;
END;
go

EXEC sys.sp_MSforeachtable 'UPDATE STATISTICS ? WITH FULLSCAN;';
go

SELECT COUNT(*) FROM dbo.Person;
SELECT COUNT(*) FROM dbo.Employee;
SELECT COUNT(*) FROM dbo.EmployeePayHistory;
SELECT COUNT(*) FROM dbo.EmployeeDepartmentHistory;
SELECT COUNT(*) FROM dbo.SalesPerson;
go
