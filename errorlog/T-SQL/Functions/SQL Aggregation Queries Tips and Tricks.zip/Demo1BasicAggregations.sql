--Look at all the grants.
SELECT *
FROM [Grant]




--Let�s get just 2 fields.
SELECT GrantName, Amount
FROM [Grant]





--Now with 1 field you still have 10 records as before.
SELECT EmpID 
FROM [Grant]
-- The same EmpID is listed many times.



--Let�s see all the distinct values.
SELECT DISTINCT EmpID
FROM [Grant]




--This is another way to get the distinct values.
SELECT EmpID
FROM [Grant]
GROUP BY EmpID




---------------Sum aggregation (Section 1:42 to 3:02)
--Let�s query from last example without the GROUP BY.
SELECT EmpID
FROM [Grant]




--Let�s show just two fields but all records.
SELECT EmpID, Amount
FROM [Grant]




--What is the total for each employee?
SELECT EmpID, SUM(Amount)
FROM [Grant]
GROUP BY EmpID






---------------Other Aggregating functions (Section 3:02 to 4:12)
--How many grants did each employee bring in?
SELECT EmpID, COUNT(Amount)
FROM [Grant]
GROUP BY EmpID



--What is the largest grant ever received?
SELECT EmpID, MAX(Amount)
FROM [Grant]
GROUP BY EmpID



--Notice that this total field does not have a name.
SELECT EmpID, SUM(Amount) 
FROM [Grant]
GROUP BY EmpID



--Let's give this field a name.
SELECT EmpID, SUM(Amount) AS TotalAmount
FROM [Grant]
GROUP BY EmpID

---------------Counting Records vs. Values (Section 4:12 to 7:42)
--We get our 12 employees with locations.
SELECT * 
FROM Employee AS emp
INNER JOIN Location AS loc
ON emp.LocationID = loc.LocationID



--We get our 14 records (13 employees plus an empty Chicago record).
SELECT * 
FROM Employee AS emp
FULL OUTER JOIN Location AS loc
ON emp.LocationID = loc.LocationID



--Let�s get City and FirstName.
SELECT City, FirstName
FROM Employee AS emp
FULL OUTER JOIN Location AS loc
ON emp.LocationID = loc.LocationID



--Now count the number of names in each city.
SELECT City, COUNT(FirstName) 
FROM Employee AS emp
FULL OUTER JOIN Location AS loc
ON emp.LocationID = loc.LocationID
GROUP BY City
--Notice Chicago has no names to count.



--If you change to COUNT(*) then it will count records (not values).
SELECT City, COUNT(*) 
FROM Employee AS emp
FULL OUTER JOIN Location AS loc
ON emp.LocationID = Loc.LocationID
GROUP BY City  




---------------Composite Grouping (Section 7:42 to 9:38)
--Show all employees who brought in grants.
SELECT * 
FROM Employee AS emp
INNER JOIN [Grant] AS gr
ON emp.EmpID = gr.EmpID 



--Group this on FirstName.
SELECT FirstName, COUNT(GrantName)
FROM Employee AS emp
INNER JOIN [Grant] AS gr
ON emp.EmpID = gr.EmpID 
GROUP BY FirstName

--There are 4 David�s (3 are David Lonning, 1 is David Kennson)



--Let�s group by FirstName and LastName.
SELECT FirstName, LastName, COUNT(GrantName) AS GrantCt
FROM Employee AS emp
INNER JOIN [Grant] AS gr
ON emp.EmpID = gr.EmpID 
GROUP BY FirstName, LastName  



--Also show the total by FirstName and LastName.
SELECT FirstName, LastName, COUNT(GrantName) AS GrantCt , SUM(Amount) AS TotalAmount
FROM Employee AS emp
INNER JOIN [Grant] AS gr
ON emp.EmpID = gr.EmpID 
GROUP BY FirstName, LastName  

