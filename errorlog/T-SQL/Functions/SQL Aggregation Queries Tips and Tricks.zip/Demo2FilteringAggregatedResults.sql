---------------Filtering aggregated results (Section 0:00 to 1:05)
--Look at all Employees.
SELECT * 
FROM Employee



--Let�s count how many employees at each LocationID.
SELECT LocationID, COUNT(*) AS EmpCt
FROM Employee
GROUP BY LocationID



--ERROR Example Next:
--How many locations have more than 2 employees? (WHERE does not support this)
SELECT LocationID, COUNT(*) AS EmpCt
FROM Employee
WHERE COUNT(*) > 2 
GROUP BY LocationID



--This is the way to filter aggregated results.
SELECT LocationID, COUNT(*) AS EmpCt
FROM Employee 
GROUP BY LocationID 
HAVING COUNT(*) > 2 






---------------Filtering aggregated results with Joins (Section 1:05 to 2:39)
--Join Location and Employee.
SELECT *
FROM Location AS loc
FULL OUTER JOIN Employee AS emp
ON loc.LocationID = emp.LocationID



--Itemize down to State and FirstName.
SELECT loc.[State], emp.FirstName
FROM Location AS loc
FULL OUTER JOIN Employee AS emp
ON loc.LocationID = emp.LocationID



--Let�s find how many people in each state.
SELECT loc.[State], COUNT(emp.FirstName)
FROM Location AS loc
FULL OUTER JOIN Employee AS emp
ON loc.LocationId = emp.LocationID
GROUP BY loc.[State]



--How many states have more than 2 people?
SELECT loc.[State], COUNT(emp.FirstName) 
FROM Location AS Loc 
FULL OUTER JOIN Employee AS emp 
ON loc.LocationId = emp.LocationID 
GROUP BY loc.[State] 
HAVING COUNT(emp.FirstName) > 2 


----Example Concept Summary:
-- �	The HAVING clause always appears after the GROUP BY clause.






---------------Comparing WHERE and HAVING (Section 2:39 to 4:33)
--Find all Grant amounts and the employee who found them.
SELECT FirstName, LastName, Amount
FROM Employee AS emp
INNER JOIN [Grant] AS gra
ON emp.EmpID = gra.EmpID




--How many employees have procured a total of more than $40,000?
SELECT FirstName, LastName, SUM(Amount) 
FROM Employee AS emp 
INNER JOIN [Grant] AS gra 
ON emp.EmpID = gra.EmpID 
GROUP BY FirstName, LastName 
HAVING SUM(Amount) > 40000 
--Only 2 employees have aggregated totals that are that high.




--If you put the filter on the WHERE, you will only get the rows of individual grants over $40,000.
SELECT FirstName, LastName, SUM(Amount)
FROM Employee AS emp
INNER JOIN [Grant] AS gra
ON emp.EmpID = gra.EmpID
WHERE Amount > 40000  
GROUP BY FirstName, LastName
--Only 1 employee has a grant over 40,000.






---------------Pre-Filtering Aggregated results (Section 4:33 to 6:00)
--Show all customers.
SELECT * 
FROM Customer



--How many customers have bought from us before?
SELECT * 
FROM Customer AS cu
INNER JOIN SalesInvoice AS sv
ON cu.CustomerID = sv.CustomerID



--Only some have ordered from us in 2009.
SELECT * 
FROM Customer AS cu
INNER JOIN SalesInvoice AS sv
ON cu.CustomerID = sv.CustomerID
WHERE OrderDate BETWEEN '1/1/2009' AND '1/1/2010'



--Let�s get just the customer list.
SELECT DISTINCT cu.* 
FROM Customer AS cu 
INNER JOIN SalesInvoice AS sv 
ON cu.CustomerID = sv.CustomerID 
WHERE OrderDate BETWEEN '1/1/2009' AND '1/1/2010' 



----Example Concept Summary:
-- � The DISTINCT clause is useful to show all items in your query once, regardless of how many times they are listed. 
-- � Use DISTINCT to eliminate duplicates or multiple listings of the same entity value when they are not relevant to your report.



