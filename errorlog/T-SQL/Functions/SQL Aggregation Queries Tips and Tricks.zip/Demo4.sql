---------------Using OVER with table totals (Section 0:00 to 3:11)
--Look at all the grants.
SELECT *
FROM [Grant]



--What is the total of grants in the table?
SELECT SUM(Amount)
FROM [Grant]



--ERROR Example Next:Does not work to put aggregated and non-aggregated results in the same record.
--Putting totals on each iterative line does not work normally.
SELECT *, SUM(Amount)
FROM [Grant] 




--The table total with each record works with the OVER clause.
SELECT *, SUM(Amount) OVER()
FROM [Grant] 



--It's best to give this expression field an alias.
SELECT *, SUM(Amount) OVER() AS CompanyTotal
FROM [Grant] 



--------Example Concept Summary:
-- �	With the OVER() clause you can integrate both actual base fields and aggregates in the same row.
-- �	OVER() allows aggregation without requiring you to use a GROUP BY clause.




--Use the table total in an expression field with the row values.
SELECT *, SUM(Amount) OVER() AS CompanyTotal,
Amount/ SUM(Amount) OVER()
FROM [Grant] 



--Change your ratio into a percentage.
SELECT *, SUM(Amount) OVER() AS CompanyTotal, 
Amount/ SUM(Amount) OVER() * 100 AS PctOfTotal 
FROM [Grant]  






---------------Using OVER with PARTITION (Section 3:11 to 7:10)
--Let�s look at all employees.
SELECT FirstName, LastName, LocationID
FROM Employee

--Let�s put a total employee count next to each name.
SELECT FirstName, LastName, LocationID, COUNT(*) OVER()
FROM Employee



--Clean up with an Expression field alias.
SELECT FirstName, LastName, LocationID, COUNT(*) OVER() AS TotalEmployee
FROM Employee



--Find the total employee count based on the location they are in.
SELECT FirstName, LastName, LocationID, COUNT(*) OVER() AS TotalEmployee,
COUNT(*) OVER(PARTITION BY LocationID) AS LocationCount
FROM Employee








--ERROR Example Next: You think this will give you a percentage but with integers 7/12 is less than 1. An integer less than 1 is in fact zero.
--Find the ratio of your location count to the total of the company count.
--Why do they all show zero?
SELECT FirstName, LastName, LocationID, COUNT(*) OVER() AS TotalEmployee,
COUNT(*) OVER(PARTITION BY LocationID) AS LocationCount,
COUNT(*) OVER(PARTITION BY LocationID)/ COUNT(*) OVER() 
FROM Employee




--Turn this into a decimal ratio.
SELECT FirstName, LastName, LocationID, COUNT(*) OVER() AS TotalEmployee,
COUNT(*) OVER(PARTITION BY LocationID) AS LocationCount,
COUNT(*) OVER(PARTITION BY LocationID) * 1.0 / COUNT(*) OVER()  
FROM Employee  



--Let�s turn this ratio into a percentage.
SELECT FirstName, LastName, LocationID, COUNT(*) OVER() AS TotalEmployee,
COUNT(*) OVER(PARTITION BY LocationID) AS LocationCount,
COUNT(*) OVER(PARTITION BY LocationID) * 100.0 / COUNT(*) OVER() 
FROM Employee







--Now let�s alias the field.
SELECT FirstName, LastName, LocationID, COUNT(*) OVER() AS TotalEmployee,
COUNT(*) OVER(PARTITION BY LocationID) AS LocationCount,
COUNT(*) OVER(PARTITION BY LocationID) * 100.0 / COUNT(*) OVER() AS Pct
FROM Employee




