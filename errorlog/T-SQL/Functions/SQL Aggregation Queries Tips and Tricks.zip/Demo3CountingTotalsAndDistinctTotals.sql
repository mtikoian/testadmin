---------------Using Distinct Aggregations
---Look at all the employees
SELECT *
FROM Employee

--Just show LocationID
SELECT LocationID
FROM Employee


--12 of the 13 values have records
SELECT COUNT(LocationID)
FROM Employee


--There are only 3 different 
SELECT COUNT(DISTINCT LocationID)
FROM Employee





---------------Example 2: Using Distinct Aggregations (Section 6:00 to 8:17)
--Look at the vSales record set.
SELECT * 
FROM vSales



--Just get 2 fields.
SELECT ProductID, CustomerID
FROM vSales



--ProductID 33 has sold 29 times to 27 different people (Cust 185 and 597 bought twice)
SELECT ProductID, CustomerID
FROM vSales
WHERE ProductID = 33
ORDER BY ProductID, CustomerID




--How many times has each ProductID sold?
SELECT ProductID, COUNT(CustomerID)
FROM vSales
GROUP BY ProductID




--To how many different customers?
SELECT ProductID, COUNT(DISTINCT CustomerID)
FROM vSales 
GROUP BY ProductID 



--See both at the same time?
SELECT ProductID, 
COUNT(CustomerID), 
COUNT(DISTINCT CustomerID) 
FROM vSales 
GROUP BY ProductID 

--Add the Field alias
SELECT ProductID, 
COUNT(CustomerID) AS TotalOrder, 
COUNT(DISTINCT CustomerID) AffectedCustomers
FROM vSales 
GROUP BY ProductID 






