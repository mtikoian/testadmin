USE UdfDemo2;
go

IF EXISTS (SELECT * FROM sys.objects WHERE name = 'GetLocationInline')
BEGIN;
  DROP FUNCTION dbo.GetLocationInline;
END;
go
CREATE FUNCTION dbo.GetLocationInline
      (@LocationType       char(1),
       @LocationID         int)
RETURNS TABLE
AS
RETURN
 (SELECT     COALESCE (c.CountryName, s.StateName, a.AreaName,
                       r.RegionName, o.ContinentName) AS LocationName
  FROM      (SELECT 1)      AS  d(Dummy)
  LEFT  JOIN dbo.Countries  AS  c
        ON   c.CountryID     =  @LocationID
        AND  @LocationType   = 'C'
  LEFT  JOIN dbo.States     AS  s
        ON   s.StateID       =  @LocationID
        AND  @LocationType   = 'S'
  LEFT  JOIN dbo.Areas      AS  a
        ON   a.AreaID        =  @LocationID
        AND  @LocationType   = 'A'
  LEFT  JOIN dbo.Regions    AS  r
        ON   r.RegionID      =  @LocationID
        AND  @LocationType   = 'R'
  LEFT  JOIN dbo.Continents AS  o
        ON   o.ContinentID   =  @LocationID
        AND  @LocationType   = 'O');
go


-- Test
SELECT *
FROM   dbo.GetLocationInline ('C',1);
go


SELECT      s.SalesID, s.LocationType, s.LocationID,
            l.LocationName AS "Location name"
FROM        dbo.Sales AS s
CROSS JOIN  dbo.GetLocationInline (s.LocationType, s.LocationID) AS l
ORDER BY    s.SalesID;
go






SET STATISTICS IO ON;
go

SELECT      s.SalesID, s.LocationType, s.LocationID,
            l.LocationName AS "Location name"
FROM        dbo.Sales AS s
CROSS APPLY dbo.GetLocationInline (s.LocationType, s.LocationID) AS l
ORDER BY    s.SalesID;
go

SELECT      r.SalesRepID, r.LocationType, r.LocationID,
            l.LocationName AS "Location name"
FROM        dbo.SalesReps AS r
CROSS APPLY dbo.GetLocationInline (r.LocationType, r.LocationID) AS l
ORDER BY    r.SalesRepID;
go

SELECT      d.DirectorID, d.LocationType, d.LocationID,
            l.LocationName AS "Location name"
FROM        dbo.Directors AS d
CROSS APPLY dbo.GetLocationInline (d.LocationType, d.LocationID) AS l
ORDER BY    d.DirectorID;
go

SELECT      b.BigTableID, b.LocationType, b.LocationID,
            l.LocationName AS "Location name"
FROM        dbo.BigTable AS b
CROSS APPLY dbo.GetLocationInline (b.LocationType, b.LocationID) AS l
ORDER BY    b.BigTableID;
go
