USE UdfDemo;
go


SET STATISTICS IO ON;
go

WITH EmployeePayRanked
AS (SELECT BusinessEntityID, Rate,
           RANK() OVER (PARTITION BY BusinessEntityID ORDER BY RateChangeDate DESC) AS rn
    FROM   dbo.EmployeePayHistory)
SELECT     e.BusinessEntityID, e.JobTitle,
           p.FirstName, p.LastName,
           CAST(CASE
                  WHEN sp.BusinessEntityID IS NOT NULL
                    THEN 1800 * (ep.Rate * 0.75) + (sp.CommissionPct * 1.25) * (sp.SalesYTD * 1.5)
                  WHEN e.SalariedFlag = 1
                    THEN 1800 * ep.Rate
                    ELSE 1800 * (ep.Rate * 1.03)
                END AS money)  AS "Projected Wage"
FROM       dbo.Employee        AS e
INNER JOIN dbo.Person          AS p
	  ON   p.BusinessEntityID   = e.BusinessEntityID
INNER JOIN EmployeePayRanked   AS ep
      ON   ep.BusinessEntityID  = e.BusinessEntityID
      AND  ep.rn                = 1
LEFT  JOIN dbo.SalesPerson     AS sp
      ON   sp.BusinessEntityID  = e.BusinessEntityID
ORDER BY   BusinessEntityID;
go














WITH EmployeePayRanked
AS (SELECT BusinessEntityID, Rate,
           RANK() OVER (PARTITION BY BusinessEntityID ORDER BY RateChangeDate DESC) AS rn
    FROM   dbo.EmployeePayHistory)
SELECT     SUM(CAST(CASE
                      WHEN sp.BusinessEntityID IS NOT NULL
                        THEN 1800 * (ep.Rate * 0.75) + (sp.CommissionPct * 1.25) * (sp.SalesYTD * 1.5)
                      WHEN e.SalariedFlag = 1
                        THEN 1800 * ep.Rate
                        ELSE 1800 * (ep.Rate * 1.03)
                    END AS money)) AS "Total Projected Wage"
FROM       dbo.Employee        AS e
INNER JOIN EmployeePayRanked   AS ep
      ON   ep.BusinessEntityID  = e.BusinessEntityID
      AND  ep.rn                = 1
LEFT  JOIN dbo.SalesPerson     AS sp
      ON   sp.BusinessEntityID  = e.BusinessEntityID;
go












WITH EmployeePayRanked
AS (SELECT BusinessEntityID, Rate,
           RANK() OVER (PARTITION BY BusinessEntityID ORDER BY RateChangeDate DESC) AS rn
    FROM   dbo.EmployeePayHistory)
SELECT     ed.DepartmentID,
           SUM(CAST(CASE
                      WHEN sp.BusinessEntityID IS NOT NULL
                        THEN 1800 * (ep.Rate * 0.75) + (sp.CommissionPct * 1.25) * (sp.SalesYTD * 1.5)
                      WHEN e.SalariedFlag = 1
                        THEN 1800 * ep.Rate
                        ELSE 1800 * (ep.Rate * 1.03)
                    END AS money)) AS "Projected Wage"
FROM       dbo.Employee          AS e
INNER JOIN EmployeePayRanked     AS ep
      ON   ep.BusinessEntityID   = e.BusinessEntityID
      AND  ep.rn                 = 1
LEFT  JOIN dbo.SalesPerson      AS sp
      ON   sp.BusinessEntityID   = e.BusinessEntityID
INNER JOIN dbo.EmployeeDepartmentHistory AS ed
      ON   ed.BusinessEntityID   = e.BusinessEntityID
      AND  ed.EndDate           IS NULL
GROUP BY   ed.DepartmentID
ORDER BY   ed.DepartmentID;
go



DECLARE @BusinessEntityID int = 1234;
WITH EmployeePayRanked
AS (SELECT BusinessEntityID, Rate,
           RANK() OVER (PARTITION BY BusinessEntityID ORDER BY RateChangeDate DESC) AS rn
    FROM   dbo.EmployeePayHistory)
SELECT     e.JobTitle,
           p.FirstName, p.LastName,
           CAST(CASE
                  WHEN sp.BusinessEntityID IS NOT NULL
                    THEN 1800 * (ep.Rate * 0.75) + (sp.CommissionPct * 1.25) * (sp.SalesYTD * 1.5)
                  WHEN e.SalariedFlag = 1
                    THEN 1800 * ep.Rate
                    ELSE 1800 * (ep.Rate * 1.03)
                END AS money)  AS "Projected Wage"
FROM       dbo.Employee        AS e
INNER JOIN dbo.Person          AS p
	  ON   p.BusinessEntityID   = e.BusinessEntityID
INNER JOIN EmployeePayRanked   AS ep
      ON   ep.BusinessEntityID  = e.BusinessEntityID
      AND  ep.rn                = 1
LEFT  JOIN dbo.SalesPerson     AS sp
      ON   sp.BusinessEntityID  = e.BusinessEntityID
WHERE      e.BusinessEntityID   = @BusinessEntityID;
go
