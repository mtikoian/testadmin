USE UdfDemo2;
go

IF EXISTS (SELECT * FROM sys.objects WHERE name = 'GetAllLocationsBigTable')
BEGIN;
  DROP FUNCTION dbo.GetAllLocationsBigTable;
END;
go
CREATE FUNCTION dbo.GetAllLocationsBigTable()
RETURNS TABLE
AS
RETURN
 (SELECT     BigTableID,
             COALESCE (c.CountryName, s.StateName, a.AreaName,
                       r.RegionName, o.ContinentName) AS LocationName
  FROM       dbo.BigTable   AS  t
  LEFT  JOIN dbo.Countries  AS  c
        ON   c.CountryID     =  t.LocationID
        AND  t.LocationType  = 'C'
  LEFT  JOIN dbo.States     AS  s
        ON   s.StateID       =  t.LocationID
        AND  t.LocationType  = 'S'
  LEFT  JOIN dbo.Areas      AS  a
        ON   a.AreaID        =  t.LocationID
        AND  t.LocationType  = 'A'
  LEFT  JOIN dbo.Regions    AS  r
        ON   r.RegionID      =  t.LocationID
        AND  t.LocationType  = 'R'
  LEFT  JOIN dbo.Continents AS  o
        ON   o.ContinentID   =  t.LocationID
        AND  t.LocationType  = 'O');
go


IF EXISTS (SELECT * FROM sys.objects WHERE name = 'GetAllLocationsSales')
BEGIN;
  DROP FUNCTION dbo.GetAllLocationsSales;
END;
go
CREATE FUNCTION dbo.GetAllLocationsSales()
RETURNS TABLE
AS
RETURN
 (SELECT     SalesID,
             COALESCE (c.CountryName, s.StateName, a.AreaName,
                       r.RegionName, o.ContinentName) AS LocationName
  FROM       dbo.Sales      AS  t
  LEFT  JOIN dbo.Countries  AS  c
        ON   c.CountryID     =  t.LocationID
        AND  t.LocationType  = 'C'
  LEFT  JOIN dbo.States     AS  s
        ON   s.StateID       =  t.LocationID
        AND  t.LocationType  = 'S'
  LEFT  JOIN dbo.Areas      AS  a
        ON   a.AreaID        =  t.LocationID
        AND  t.LocationType  = 'A'
  LEFT  JOIN dbo.Regions    AS  r
        ON   r.RegionID      =  t.LocationID
        AND  t.LocationType  = 'R'
  LEFT  JOIN dbo.Continents AS  o
        ON   o.ContinentID   =  t.LocationID
        AND  t.LocationType  = 'O');
go

-- Repeat the above for Directors, SalesReps, and any other tables ...



SET STATISTICS IO ON;
go

SELECT * FROM dbo.GetAllLocationsBigTable();
SELECT * FROM dbo.GetAllLocationsSales();
