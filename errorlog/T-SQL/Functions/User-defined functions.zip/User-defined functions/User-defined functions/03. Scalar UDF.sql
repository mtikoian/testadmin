USE UdfDemo;
go

IF EXISTS (SELECT * FROM sys.objects WHERE name = 'GetProjectedCommission')
BEGIN;
  DROP FUNCTION dbo.GetProjectedCommission;
END;
go
CREATE FUNCTION dbo.GetProjectedCommission
      (@BusinessEntityID  int,
       @FactorCommission  decimal(5,3),
       @FactorSalesYTD    decimal(5,3))
RETURNS money
AS
BEGIN;
  DECLARE @CommissionPct decimal(7,4),
          @SalesYTD money,
          @ProjectedCommission money;
  -- Get current commission percentage and sales YTD
  SELECT @CommissionPct = CommissionPct,
         @SalesYTD = SalesYTD
  FROM   dbo.SalesPerson
  WHERE  BusinessEntityID = @BusinessEntityID;

  SET @ProjectedCommission = (@CommissionPct * @FactorCommission) * (@SalesYTD * @FactorSalesYTD);
  RETURN @ProjectedCommission;
END;
go

IF EXISTS (SELECT * FROM sys.objects WHERE name = 'GetProjectedWage')
BEGIN;
  DROP FUNCTION dbo.GetProjectedWage;
END;
go
CREATE FUNCTION dbo.GetProjectedWage
      (@BusinessEntityID  int,
       @HoursPerYear      int,
       @FactorSalesPerson decimal(5,3),
       @FactorCommission  decimal(5,3),
       @FactorSalesYTD    decimal(5,3),
       @FactorSalaried1   decimal(5,3),
       @FactorSalaried0   decimal(5,3))
RETURNS money
AS
BEGIN;
  DECLARE @SalariedFlag bit,
          @IsSalesPerson bit,
          @Rate money,
          @ProjectedWage money;
  -- Is the employee a sales person?
  IF EXISTS (SELECT * FROM dbo.SalesPerson WHERE BusinessEntityID= @BusinessEntityID)
    BEGIN;
    SET  @IsSalesPerson = 1;
    END;
  ELSE
    BEGIN;
    SET  @IsSalesPerson = 0;
    END;
  -- Get salaried flag (not for sales persons)
  IF @IsSalesPerson = 0
    BEGIN;
    SELECT @SalariedFlag = SalariedFlag
    FROM   dbo.Employee
    WHERE  BusinessEntityID = @BusinessEntityID;
    END;
  -- Get most recent pay rate
  SELECT TOP(1)
           @Rate = Rate
  FROM     dbo.EmployeePayHistory
  WHERE    BusinessEntityID = @BusinessEntityID
  ORDER BY RateChangeDate DESC;

  -- Calculate projected wage, by type:
  IF @IsSalesPerson = 1
    BEGIN;
    SET @ProjectedWage = @HoursPerYear * (@Rate * @FactorSalesPerson)
                       + dbo.GetProjectedCommission(@BusinessEntityID, @FactorCommission, @FactorSalesYTD);
    END;
  ELSE IF @SalariedFlag = 1
    BEGIN;
    SET @ProjectedWage = @HoursPerYear * (@Rate * @FactorSalaried1);
    END;
  ELSE
    BEGIN;
    SET @ProjectedWage = @HoursPerYear * (@Rate * @FactorSalaried0);
    END;
  RETURN @ProjectedWage;
END;
go



SET STATISTICS IO ON;
go

SELECT     e.BusinessEntityID, e.JobTitle,
           p.FirstName, p.LastName,
           dbo.GetProjectedWage(e.BusinessEntityID, 1800, 0.75, 1.25, 1.5, 1, 1.03) AS "Projected Wage"
FROM       dbo.Employee        AS e
INNER JOIN dbo.Person          AS p
	  ON   p.BusinessEntityID   = e.BusinessEntityID
ORDER BY   e.BusinessEntityID;
go


SELECT     SUM(dbo.GetProjectedWage(e.BusinessEntityID, 1800, 0.75, 1.25, 1.5, 1, 1.03)) AS "Total Projected Wage"
FROM       dbo.Employee AS e;
go


SELECT     ed.DepartmentID,
           SUM(dbo.GetProjectedWage(e.BusinessEntityID, 1800, 0.75, 1.25, 1.5, 1, 1.03)) AS "Projected Wage"
FROM       dbo.Employee AS e
INNER JOIN dbo.EmployeeDepartmentHistory AS ed
      ON   ed.BusinessEntityID = e.BusinessEntityID
      AND  ed.EndDate IS NULL
GROUP BY   ed.DepartmentID
ORDER BY   ed.DepartmentID;
go



DECLARE @BusinessEntityID int = 1234;
SELECT     e.BusinessEntityID, e.JobTitle,
           p.FirstName, p.LastName,
           dbo.GetProjectedWage(e.BusinessEntityID, 1800, 0.75, 1.25, 1.5, 1, 1.03) AS "Projected Wage"
FROM       dbo.Employee        AS e
INNER JOIN dbo.Person          AS p
	  ON   p.BusinessEntityID   = e.BusinessEntityID
WHERE      e.BusinessEntityID   = @BusinessEntityID;
go
