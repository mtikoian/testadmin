use [�e�X�g]
go

-- ���ʕt��
with [cte] ( [seq] ) as ( 
  select 1 as [seq] 
  union all 
  select [cte].[seq] + 1 from [cte] where [cte].[seq] < 10  
)
select 
  [seq]
  , lag([seq], 2, -1) over (order by [seq]) as [lag]
  , lead([seq], 3, -1) over (order by [seq]) as [lead] 
  , first_value([seq]) over (order by [seq]) as [first_value]
  , last_value([seq]) over (order by [seq]) as [last_value]
from [cte] 
go