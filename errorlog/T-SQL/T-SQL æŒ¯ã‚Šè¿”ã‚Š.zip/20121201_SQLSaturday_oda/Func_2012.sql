select 
  parse('Dec 1 2012' as date)
  , parse('1,234' as int)
  , try_parse('qbd2' as int) 
  , try_convert(date, '2011/11/34')
  , format(1234, '#,0.#0') 
select
  choose(2, 'A', 'B', 'C', 'D') 
  , iif(1 = 2, 'A', 'B')
  , 'A' + null + 'C'
  , concat('A', null, 'C')
  , eomonth(getdate(), 1)