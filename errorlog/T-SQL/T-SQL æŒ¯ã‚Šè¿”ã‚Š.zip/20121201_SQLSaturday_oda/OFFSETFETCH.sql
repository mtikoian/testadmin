use [�e�X�g]
go
declare @offset int = 10
declare @fetch int = 5;

with [cte] ( [seq] ) as ( 
  select 1 as [seq]
  union all 
  select [cte].[seq] + 1 from [cte] where [seq] <= 100
)
select 
  * 
from 
  [cte] 
order by 
  [seq] offset @offset rows fetch next @fetch rows only
;
with [cte] ( [seq] ) as ( 
  select 1 as [seq]
  union all 
  select [cte].[seq] + 1 from [cte] where [seq] <= 100
)
select top (@fetch)
  [seq]
from 
  ( select *, row_number() over (order by [seq]) as [rownum] from [cte] ) as [tmp]
where 
  [rownum] > @offset