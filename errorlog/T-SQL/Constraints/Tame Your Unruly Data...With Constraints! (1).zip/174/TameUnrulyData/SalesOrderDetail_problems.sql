-- Untrusted or non-existent constraints - data violation
USE AdventureWorks;

--[Sales].[SalesOrderDetail]
--CK_SalesOrderDetail_OrderQty			([OrderQty]>(0))
--CK_SalesOrderDetail_UnitPrice			([UnitPrice]>=(0.00))
--CK_SalesOrderDetail_UnitPriceDiscount	([UnitPriceDiscount]>=(0.00))
--FK_SalesOrderDetail_SalesOrderHeader_SalesOrderID

select SalesOrderID, SalesOrderDetailID, UnitPrice, UnitPriceDiscount, OrderQty, ProductID 
from [Sales].[SalesOrderDetail]
where SalesOrderID=43659

BEGIN TRAN

ALTER TABLE [Sales].[SalesOrderDetail] DISABLE TRIGGER ALL

-- discount can exceed price
UPDATE [Sales].[SalesOrderDetail]
SET UnitPriceDiscount=UnitPriceDiscount+1000000
WHERE SalesOrderID=43659

-- price can be exhorbitantly high
UPDATE [Sales].[SalesOrderDetail]
SET UnitPrice=UnitPrice*1000000000
WHERE SalesOrderID=43659

-- turn off constraints (or not have them in the first place)
alter table [Sales].[SalesOrderDetail] NOCHECK CONSTRAINT CK_SalesOrderDetail_OrderQty,			
CK_SalesOrderDetail_UnitPrice,			
CK_SalesOrderDetail_UnitPriceDiscount,
FK_SalesOrderDetail_SalesOrderHeader_SalesOrderID

--negative quantity, price, discount, non-existent sales order
UPDATE [Sales].[SalesOrderDetail]
SET UnitPrice=-UnitPrice, UnitPriceDiscount=-UnitPriceDiscount,
OrderQty=-OrderQty, SalesOrderID=-SalesOrderID
WHERE SalesOrderID=43659

select SalesOrderID, SalesOrderDetailID, UnitPrice, UnitPriceDiscount, OrderQty, ProductID 
from [Sales].[SalesOrderDetail]
where SalesOrderID=-43659

ROLLBACK TRAN

alter table [Sales].[SalesOrderDetail] WITH CHECK CHECK CONSTRAINT CK_SalesOrderDetail_OrderQty,			
CK_SalesOrderDetail_UnitPrice,			
CK_SalesOrderDetail_UnitPriceDiscount,
FK_SalesOrderDetail_SalesOrderHeader_SalesOrderID

ALTER TABLE [Sales].[SalesOrderDetail] ENABLE TRIGGER ALL
