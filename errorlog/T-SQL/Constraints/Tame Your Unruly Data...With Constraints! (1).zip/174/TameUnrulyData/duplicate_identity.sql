-- Duplicate identity w/o primary key/unique constraint

IF OBJECT_ID('tempdb..#dupe_ident') IS NOT NULL DROP TABLE #dupe_ident;
CREATE TABLE #dupe_ident(i INT NOT NULL IDENTITY(1,1));

INSERT #dupe_ident DEFAULT VALUES;
INSERT #dupe_ident DEFAULT VALUES;

SELECT * FROM #dupe_ident;

-- this can happen
SET IDENTITY_INSERT #dupe_ident ON;
INSERT #dupe_ident(i) VALUES(1);
SET IDENTITY_INSERT #dupe_ident OFF;

SELECT * FROM #dupe_ident;

--or this
DBCC CHECKIDENT(#dupe_ident, RESEED,1);
INSERT #dupe_ident DEFAULT VALUES;

SELECT * FROM #dupe_ident;

--or even this
TRUNCATE TABLE #dupe_ident;
INSERT #dupe_ident DEFAULT VALUES;

SELECT * FROM #dupe_ident;

--and if I get a hold of your DB...
DBCC CHECKIDENT(#dupe_ident, RESEED,-667);
INSERT #dupe_ident DEFAULT VALUES;

SELECT * FROM #dupe_ident;

--clean up
DROP TABLE #dupe_ident;