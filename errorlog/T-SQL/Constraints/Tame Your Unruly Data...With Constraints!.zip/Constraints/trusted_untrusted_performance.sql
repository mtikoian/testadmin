-- Trusted vs. untrusted PERFORMANCE
USE AdventureWorks;

-- get IO stats
SET STATISTICS IO ON
SET NOCOUNT ON

DBCC DROPCLEANBUFFERS WITH NO_INFOMSGS;
print '***FK-Start';

-- run with show exec plan
SELECT TOP 1 OBJECTPROPERTY(object_id('[Sales].[FK_SalesOrderDetail_SalesOrderHeader_SalesOrderID]'),'CnstIsNotTrusted') Not_Trusted, OBJECTPROPERTY(object_id('[Sales].[FK_SalesOrderDetail_SalesOrderHeader_SalesOrderID]'),'CnstIsDisabled') Disabled, * FROM Sales.SalesOrderDetail SOD
WHERE EXISTS(SELECT * FROM Sales.SalesOrderHeader WHERE SalesOrderID=SOD.SalesOrderID)

DBCC DROPCLEANBUFFERS WITH NO_INFOMSGS;
print '***FK-Nocheck';
ALTER TABLE Sales.SalesOrderDetail NOCHECK CONSTRAINT FK_SalesOrderDetail_SalesOrderHeader_SalesOrderID;

SELECT TOP 1 OBJECTPROPERTY(object_id('[Sales].[FK_SalesOrderDetail_SalesOrderHeader_SalesOrderID]'),'CnstIsNotTrusted') Not_Trusted, OBJECTPROPERTY(object_id('[Sales].[FK_SalesOrderDetail_SalesOrderHeader_SalesOrderID]'),'CnstIsDisabled') Disabled, * FROM Sales.SalesOrderDetail SOD
WHERE EXISTS(SELECT * FROM Sales.SalesOrderHeader WHERE SalesOrderID=SOD.SalesOrderID)

ALTER TABLE Sales.SalesOrderDetail CHECK CONSTRAINT FK_SalesOrderDetail_SalesOrderHeader_SalesOrderID;

DBCC DROPCLEANBUFFERS WITH NO_INFOMSGS;
print '***FK-Check';
SELECT TOP 1 OBJECTPROPERTY(object_id('[Sales].[FK_SalesOrderDetail_SalesOrderHeader_SalesOrderID]'),'CnstIsNotTrusted') Not_Trusted, OBJECTPROPERTY(object_id('[Sales].[FK_SalesOrderDetail_SalesOrderHeader_SalesOrderID]'),'CnstIsDisabled') Disabled, * FROM Sales.SalesOrderDetail SOD
WHERE EXISTS(SELECT * FROM Sales.SalesOrderHeader WHERE SalesOrderID=SOD.SalesOrderID)

DBCC DROPCLEANBUFFERS WITH NO_INFOMSGS;
print '***FK-Check With Check';
ALTER TABLE Sales.SalesOrderDetail WITH CHECK CHECK CONSTRAINT FK_SalesOrderDetail_SalesOrderHeader_SalesOrderID;

DBCC DROPCLEANBUFFERS WITH NO_INFOMSGS;
print '***FK-RunAgain';

SELECT TOP 1 OBJECTPROPERTY(object_id('[Sales].[FK_SalesOrderDetail_SalesOrderHeader_SalesOrderID]'),'CnstIsNotTrusted') Not_Trusted, OBJECTPROPERTY(object_id('[Sales].[FK_SalesOrderDetail_SalesOrderHeader_SalesOrderID]'),'CnstIsDisabled') Disabled,* FROM Sales.SalesOrderDetail SOD
WHERE EXISTS(SELECT * FROM Sales.SalesOrderHeader WHERE SalesOrderID=SOD.SalesOrderID)

-- now test CHECK constraints
--CREATE NONCLUSTERED INDEX [OrderQty] ON [Sales].[SalesOrderDetail] ([OrderQty]);

DBCC DROPCLEANBUFFERS WITH NO_INFOMSGS;
print '***CHK-Start';
SELECT OBJECTPROPERTY(object_id('[Sales].[CK_SalesOrderDetail_OrderQty]'),'CnstIsNotTrusted') Not_Trusted, OBJECTPROPERTY(object_id('[Sales].[CK_SalesOrderDetail_OrderQty]'),'CnstIsDisabled') Disabled, * FROM Sales.SalesOrderDetail SOD WHERE OrderQty<0;

ALTER TABLE Sales.SalesOrderDetail NOCHECK CONSTRAINT CK_SalesOrderDetail_OrderQty;

DBCC DROPCLEANBUFFERS WITH NO_INFOMSGS;
print '***CHK-NoCheck';
SELECT OBJECTPROPERTY(object_id('[Sales].[CK_SalesOrderDetail_OrderQty]'),'CnstIsNotTrusted') Not_Trusted, OBJECTPROPERTY(object_id('[Sales].[CK_SalesOrderDetail_OrderQty]'),'CnstIsDisabled') Disabled, * FROM Sales.SalesOrderDetail SOD WHERE OrderQty<0;

ALTER TABLE Sales.SalesOrderDetail CHECK CONSTRAINT CK_SalesOrderDetail_OrderQty;

DBCC DROPCLEANBUFFERS WITH NO_INFOMSGS;
print '***CHK-Check';
SELECT OBJECTPROPERTY(object_id('[Sales].[CK_SalesOrderDetail_OrderQty]'),'CnstIsNotTrusted') Not_Trusted, OBJECTPROPERTY(object_id('[Sales].[CK_SalesOrderDetail_OrderQty]'),'CnstIsDisabled') Disabled, * FROM Sales.SalesOrderDetail SOD WHERE OrderQty<0;

DBCC DROPCLEANBUFFERS WITH NO_INFOMSGS;
print 'ALTER WITH CHECK';

ALTER TABLE Sales.SalesOrderDetail WITH CHECK CHECK CONSTRAINT CK_SalesOrderDetail_OrderQty;

DBCC DROPCLEANBUFFERS WITH NO_INFOMSGS;
print '***CHK- Run Again';

SELECT OBJECTPROPERTY(object_id('[Sales].[CK_SalesOrderDetail_OrderQty]'),'CnstIsNotTrusted') Not_Trusted, OBJECTPROPERTY(object_id('[Sales].[CK_SalesOrderDetail_OrderQty]'),'CnstIsDisabled') Disabled, * FROM Sales.SalesOrderDetail SOD WHERE OrderQty<0;

-- DROP INDEX [OrderQty] ON [Sales].[SalesOrderDetail];
