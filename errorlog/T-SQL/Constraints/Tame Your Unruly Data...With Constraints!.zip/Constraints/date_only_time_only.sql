-- Constraint datetime to date-only or time-only values, for SQL 2005 and earlier

IF OBJECT_ID('tempdb..#test') IS NOT NULL DROP TABLE #test;
CREATE TABLE #test(
	date DATETIME NOT NULL
	CHECK (DATEPART(HOUR,date)=0 AND DATEPART(MINUTE,date)=0 
	AND DATEPART(SECOND,date)=0 AND DATEPART(ms,date)=0),
	time DATETIME NOT NULL
	CHECK (DATEPART(DAY,time)=1 AND DATEPART(MONTH,time)=1 
	AND DATEPART(YEAR,time)=1900) );

INSERT #test(DATE,TIME) VALUES('2/2/2012','02:02:02');	--succeeds
INSERT #test(DATE,TIME) VALUES(GETDATE(),GETDATE());	--fails

SELECT * FROM #test;

--clean up
DROP TABLE #test;
