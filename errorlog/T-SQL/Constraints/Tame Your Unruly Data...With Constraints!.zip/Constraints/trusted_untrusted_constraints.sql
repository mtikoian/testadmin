-- Trusted vs. untrusted constraints
USE AdventureWorks;

SELECT 'Start' stage, name, is_not_trusted FROM sys.check_constraints 
WHERE parent_object_id=OBJECT_ID('[Sales].[SalesOrderDetail]')
UNION
SELECT 'Start' stage, name, is_not_trusted FROM sys.foreign_keys
WHERE parent_object_id=OBJECT_ID('[Sales].[SalesOrderDetail]');

ALTER TABLE Sales.SalesOrderDetail NOCHECK CONSTRAINT CK_SalesOrderDetail_OrderQty,CK_SalesOrderDetail_UnitPrice,CK_SalesOrderDetail_UnitPriceDiscount,FK_SalesOrderDetail_SalesOrderHeader_SalesOrderID,FK_SalesOrderDetail_SpecialOfferProduct_SpecialOfferIDProductID;

SELECT 'Nocheck' stage, name, is_not_trusted FROM sys.check_constraints 
WHERE parent_object_id=OBJECT_ID('[Sales].[SalesOrderDetail]')
UNION
SELECT 'Nocheck' stage, name, is_not_trusted FROM sys.foreign_keys
WHERE parent_object_id=OBJECT_ID('[Sales].[SalesOrderDetail]');

ALTER TABLE Sales.SalesOrderDetail CHECK CONSTRAINT CK_SalesOrderDetail_OrderQty,CK_SalesOrderDetail_UnitPrice,CK_SalesOrderDetail_UnitPriceDiscount,FK_SalesOrderDetail_SalesOrderHeader_SalesOrderID,FK_SalesOrderDetail_SpecialOfferProduct_SpecialOfferIDProductID;

SELECT 'Check' stage, name, is_not_trusted FROM sys.check_constraints 
WHERE parent_object_id=OBJECT_ID('[Sales].[SalesOrderDetail]')
UNION
SELECT 'Check' stage, name, is_not_trusted FROM sys.foreign_keys
WHERE parent_object_id=OBJECT_ID('[Sales].[SalesOrderDetail]');

ALTER TABLE Sales.SalesOrderDetail WITH CHECK CHECK CONSTRAINT CK_SalesOrderDetail_OrderQty,CK_SalesOrderDetail_UnitPrice,CK_SalesOrderDetail_UnitPriceDiscount,FK_SalesOrderDetail_SalesOrderHeader_SalesOrderID,FK_SalesOrderDetail_SpecialOfferProduct_SpecialOfferIDProductID;

SELECT 'CheckWithCheck' stage, name, is_not_trusted FROM sys.check_constraints 
WHERE parent_object_id=OBJECT_ID('[Sales].[SalesOrderDetail]')
UNION
SELECT 'CheckWithCheck' stage, name, is_not_trusted FROM sys.foreign_keys
WHERE parent_object_id=OBJECT_ID('[Sales].[SalesOrderDetail]');
