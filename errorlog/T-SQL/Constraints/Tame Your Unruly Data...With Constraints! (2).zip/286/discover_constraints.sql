-- Find constraints in your database
USE AdventureWorks;

-- Domain constraints - data type, nullability, default
SELECT TABLE_NAME, COLUMN_NAME, DATA_TYPE, IS_NULLABLE, COLUMN_DEFAULT
FROM INFORMATION_SCHEMA.COLUMNS
ORDER BY TABLE_NAME, ORDINAL_POSITION

--PRIMARY KEY and UNIQUE constraints
SELECT OBJECT_SCHEMA_NAME(t.object_id) + N'.' + t.name table_name, 
k.name constraint_name, k.type_desc constraint_type
FROM sys.key_constraints k
INNER JOIN sys.tables t ON k.parent_object_id=t.object_id
ORDER BY 1,2

-- FOREIGN KEY constraints
SELECT OBJECT_SCHEMA_NAME(t1.object_id) + N'.' + t1.name table_name, 
fk.name constraint_name, OBJECT_SCHEMA_NAME(t2.object_id) + N'.' + t2.name referenced_table_name,
fk.is_not_trusted, fk.delete_referential_action_desc on_delete, fk.update_referential_action_desc on_update
FROM sys.foreign_keys fk
INNER JOIN sys.tables t1 ON fk.parent_object_id=t1.object_id
INNER JOIN sys.tables t2 ON fk.referenced_object_id=t2.object_id
ORDER BY 1,2

-- CHECK constraints
SELECT OBJECT_SCHEMA_NAME(t.object_id) + N'.' + t.name table_name, 
cc.name constraint_name, cc.definition, cc.is_not_trusted
FROM sys.check_constraints cc
INNER JOIN sys.tables t ON cc.parent_object_id=t.object_id
ORDER BY 1,2,3

-- DEFAULT constraints
SELECT OBJECT_SCHEMA_NAME(t.object_id) + N'.' + t.name table_name, 
d.name constraint_name, COL_NAME(d.parent_object_id, d.parent_column_id) column_name, d.definition
FROM sys.default_constraints d
INNER JOIN sys.tables t ON d.parent_object_id=t.object_id

-- INFORMATION_SCHEMA (warning: MS says these may not be accurate)
-- table constraints
SELECT CONSTRAINT_TYPE, COUNT(*) # 
FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS 
GROUP BY CONSTRAINT_TYPE

-- foreign key constraints, this is empty in third-party databases :)
SELECT * FROM INFORMATION_SCHEMA.REFERENTIAL_CONSTRAINTS

-- columns
SELECT * FROM INFORMATION_SCHEMA.COLUMNS


-- sp_help procedures
EXEC sp_help 'Sales.SalesOrderDetail'
EXEC sp_helpconstraint 'Sales.SalesOrderDetail'
EXEC sp_check_constraints_rowset 'CK_SalesOrderDetail_OrderQty'

