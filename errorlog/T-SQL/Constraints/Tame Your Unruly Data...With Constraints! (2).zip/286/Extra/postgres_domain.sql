﻿select * from information_schema.domains;
drop domain us_postal_code;
CREATE DOMAIN us_postal_code AS varchar(10)
NOT NULL
DEFAULT('00000')
CHECK(
   VALUE ~ '^\\d{5}$'
OR VALUE ~ '^\\d{5}-\\d{4}$'
);