-- Trusted vs. untrusted PERFORMANCE
USE AdventureWorks;

-- get IO stats
SET STATISTICS IO ON
SET NOCOUNT ON

DBCC DROPCLEANBUFFERS WITH NO_INFOMSGS;

-- run with show exec plan
-- Foreign key trusted/untrusted - compare reads

print '
***FK-Start - 1';


SELECT TOP 1 OBJECTPROPERTY(object_id('[Sales].[FK_SalesOrderDetail_SalesOrderHeader_SalesOrderID]'),'CnstIsNotTrusted') Not_Trusted, 
	OBJECTPROPERTY(object_id('[Sales].[FK_SalesOrderDetail_SalesOrderHeader_SalesOrderID]'),'CnstIsDisabled') Disabled, * 
	FROM Sales.SalesOrderDetail SOD
	WHERE EXISTS(SELECT * FROM Sales.SalesOrderHeader WHERE SalesOrderID=SOD.SalesOrderID)

DBCC DROPCLEANBUFFERS WITH NO_INFOMSGS;
print '
***FK-Nocheck - 2';
ALTER TABLE Sales.SalesOrderDetail NOCHECK CONSTRAINT FK_SalesOrderDetail_SalesOrderHeader_SalesOrderID;

SELECT TOP 1 OBJECTPROPERTY(object_id('[Sales].[FK_SalesOrderDetail_SalesOrderHeader_SalesOrderID]'),'CnstIsNotTrusted') Not_Trusted, 
	OBJECTPROPERTY(object_id('[Sales].[FK_SalesOrderDetail_SalesOrderHeader_SalesOrderID]'),'CnstIsDisabled') Disabled, * 
	FROM Sales.SalesOrderDetail SOD
	WHERE EXISTS(SELECT * FROM Sales.SalesOrderHeader WHERE SalesOrderID=SOD.SalesOrderID)

ALTER TABLE Sales.SalesOrderDetail CHECK CONSTRAINT FK_SalesOrderDetail_SalesOrderHeader_SalesOrderID;

DBCC DROPCLEANBUFFERS WITH NO_INFOMSGS;


print '
***FK-Check - 3';
SELECT TOP 1 OBJECTPROPERTY(object_id('[Sales].[FK_SalesOrderDetail_SalesOrderHeader_SalesOrderID]'),'CnstIsNotTrusted') Not_Trusted, 
	OBJECTPROPERTY(object_id('[Sales].[FK_SalesOrderDetail_SalesOrderHeader_SalesOrderID]'),'CnstIsDisabled') Disabled, * 
	FROM Sales.SalesOrderDetail SOD
	WHERE EXISTS(SELECT * FROM Sales.SalesOrderHeader WHERE SalesOrderID=SOD.SalesOrderID)

DBCC DROPCLEANBUFFERS WITH NO_INFOMSGS;
print '
***FK-Check With Check - 4';
ALTER TABLE Sales.SalesOrderDetail WITH CHECK 
	CHECK CONSTRAINT FK_SalesOrderDetail_SalesOrderHeader_SalesOrderID;

DBCC DROPCLEANBUFFERS WITH NO_INFOMSGS;
print '
***FK-RunAgain - 5';

SELECT TOP 1 OBJECTPROPERTY(object_id('[Sales].[FK_SalesOrderDetail_SalesOrderHeader_SalesOrderID]'),'CnstIsNotTrusted') Not_Trusted, 
	OBJECTPROPERTY(object_id('[Sales].[FK_SalesOrderDetail_SalesOrderHeader_SalesOrderID]'),'CnstIsDisabled') Disabled,* 
	FROM Sales.SalesOrderDetail SOD
	WHERE EXISTS(SELECT * FROM Sales.SalesOrderHeader WHERE SalesOrderID=SOD.SalesOrderID)



-- CHECK constraint trusted/untrusted, compare reads

--CREATE NONCLUSTERED INDEX [OrderQty] ON [Sales].[SalesOrderDetail] ([OrderQty]);

DBCC DROPCLEANBUFFERS WITH NO_INFOMSGS;
print '
***CHK-Start - 1';
SELECT OBJECTPROPERTY(object_id('[Sales].[CK_SalesOrderDetail_OrderQty]'),'CnstIsNotTrusted') Not_Trusted, 
	OBJECTPROPERTY(object_id('[Sales].[CK_SalesOrderDetail_OrderQty]'),'CnstIsDisabled') Disabled, * 
	FROM Sales.SalesOrderDetail SOD WHERE OrderQty<0;

ALTER TABLE Sales.SalesOrderDetail NOCHECK CONSTRAINT CK_SalesOrderDetail_OrderQty;

DBCC DROPCLEANBUFFERS WITH NO_INFOMSGS;
print '
***CHK-NoCheck - 2';
SELECT OBJECTPROPERTY(object_id('[Sales].[CK_SalesOrderDetail_OrderQty]'),'CnstIsNotTrusted') Not_Trusted, 
	OBJECTPROPERTY(object_id('[Sales].[CK_SalesOrderDetail_OrderQty]'),'CnstIsDisabled') Disabled, * 
	FROM Sales.SalesOrderDetail SOD WHERE OrderQty<0;

ALTER TABLE Sales.SalesOrderDetail CHECK CONSTRAINT CK_SalesOrderDetail_OrderQty;

DBCC DROPCLEANBUFFERS WITH NO_INFOMSGS;
print '
***CHK-Check - 3';
SELECT OBJECTPROPERTY(object_id('[Sales].[CK_SalesOrderDetail_OrderQty]'),'CnstIsNotTrusted') Not_Trusted, 
	OBJECTPROPERTY(object_id('[Sales].[CK_SalesOrderDetail_OrderQty]'),'CnstIsDisabled') Disabled, * 
	FROM Sales.SalesOrderDetail SOD WHERE OrderQty<0;

DBCC DROPCLEANBUFFERS WITH NO_INFOMSGS;
print '
ALTER WITH CHECK - 4';

ALTER TABLE Sales.SalesOrderDetail WITH CHECK CHECK CONSTRAINT CK_SalesOrderDetail_OrderQty;

DBCC DROPCLEANBUFFERS WITH NO_INFOMSGS;
print '
***CHK- Run Again - 5';

SELECT OBJECTPROPERTY(object_id('[Sales].[CK_SalesOrderDetail_OrderQty]'),'CnstIsNotTrusted') Not_Trusted, 
	OBJECTPROPERTY(object_id('[Sales].[CK_SalesOrderDetail_OrderQty]'),'CnstIsDisabled') Disabled, * 
	FROM Sales.SalesOrderDetail SOD WHERE OrderQty<0;

-- DROP INDEX [OrderQty] ON [Sales].[SalesOrderDetail];
