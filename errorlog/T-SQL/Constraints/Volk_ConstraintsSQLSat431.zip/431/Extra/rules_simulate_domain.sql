-- Simulate DOMAIN support
CREATE TYPE date_only FROM DATETIME NOT NULL;
GO
CREATE RULE date_only AS (
	DATEPART(HOUR,@value)=0 AND 
	DATEPART(MINUTE,@value)=0 AND 
	DATEPART(SECOND,@value)=0 AND 
	DATEPART(ms,@value)=0);
GO
CREATE DEFAULT today AS DATEADD(DAY, DATEDIFF(DAY, 0, GETDATE()), 0);
GO
EXEC sp_bindrule 'date_only', 'date_only';
EXEC sp_bindefault 'today', 'date_only';
GO

CREATE TABLE DateTest1(
	DateOfBirth DATETIME NOT NULL
	DEFAULT(DATEADD(DAY, DATEDIFF(DAY, 0, GETDATE()), 0))
	CHECK( DATEPART(HOUR,DateOfBirth)=0 AND DATEPART(MINUTE,DateOfBirth)=0 
	AND DATEPART(SECOND,DateOfBirth)=0 AND DATEPART(ms,DateOfBirth)=0) );

CREATE TABLE DateTest2(
	UDT date_only);

CREATE TABLE DateTest3(
	DateRule DATETIME NOT NULL);

-- rules can be bound to columns too
EXEC sp_bindrule 'date_only', 'dbo.DateTest3.DateRule';

INSERT DateTest1 VALUES('1/1/2011');	--succeeds
INSERT DateTest2 VALUES('2/2/2012');	--succeeds
INSERT DateTest3 VALUES('3/3/2013');	--succeeds

INSERT DateTest1 VALUES(GETDATE());		--fails
INSERT DateTest2 VALUES(GETDATE());		--fails
INSERT DateTest3 VALUES(GETDATE());		--fails

SELECT * FROM DateTest1;
SELECT * FROM DateTest2;
SELECT * FROM DateTest3;

-- clean up
DROP TABLE DateTest1,DateTest2,DateTest3;
DROP TYPE date_only;
DROP DEFAULT today;
DROP RULE date_only;
