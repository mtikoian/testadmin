-- Constraint datetime to date-only or time-only values, for SQL 2005 and earlier

IF OBJECT_ID('tempdb..#test') IS NOT NULL DROP TABLE #test;
CREATE TABLE #test(
	date DATETIME NOT NULL
	CHECK (DATEPART(HOUR,date)=0 AND DATEPART(MINUTE,date)=0 
	AND DATEPART(SECOND,date)=0 AND DATEPART(ms,date)=0),
	time DATETIME NOT NULL
	CHECK (DATEPART(DAY,time)=1 AND DATEPART(MONTH,time)=1 
	AND DATEPART(YEAR,time)=1900) );

INSERT #test(DATE,TIME) VALUES('2/2/2012','02:02:02');	--succeeds
INSERT #test(DATE,TIME) VALUES(GETDATE(),GETDATE());	--fails

SELECT * FROM #test;

--clean up
DROP TABLE #test;


-- AdventureWorks:

USE AdventureWorks;

ALTER TABLE HumanResources.Employee WITH CHECK
	ADD CONSTRAINT DateOnly_BirthDate   
	CHECK (DATEPART(HOUR,BirthDate)=0 AND DATEPART(MINUTE,BirthDate)=0 
		AND DATEPART(SECOND,BirthDate)=0 AND DATEPART(ms,BirthDate)=0);

ALTER TABLE HumanResources.Employee WITH CHECK
	ADD CONSTRAINT DateOnly_HireDate   
	CHECK (DATEPART(HOUR,HireDate)=0 AND DATEPART(MINUTE,HireDate)=0 
		AND DATEPART(SECOND,HireDate)=0 AND DATEPART(ms,HireDate)=0);

-- clean up
ALTER TABLE HumanResources.Employee 
	DROP CONSTRAINT DateOnly_BirthDate, DateOnly_HireDate;