create table US_States_0(
	StateID int, 
	State varchar(2), 
	StateName varchar(max));
-- no PK
-- everything is nullable unless the default setting was changed
-- State is reserved word (not technically a constraint issue)
-- varchar(2): state codes are only 2 characters in length, not more or less
-- State name will never approach 2 billion characters in length
-- unicode/nvarchar is another discussion, but make sure not to overuse it (e.g. zip codes or phone numbers)

create table US_States_1(
	StateID int NOT NULL PRIMARY KEY, 
	StateCode char(2) NOT NULL, 
	StateName varchar(50) NOT NULL);
-- 50 states + a few dozen territories <<<<< 2 billion ID values (or 4 billion if including negatives)
-- State code is defined externally by USPS and is unique, no unique constraint
-- State name is also unique (but not defined as such, it just is)

create table US_States_2(
	StateID tinyint NOT NULL PRIMARY KEY, 
	StateCode char(2) NOT NULL UNIQUE, 
	StateName varchar(50) NOT NULL UNIQUE);
-- tinyint limits ID values, but 256 >>> 50 states + a few dozen territories
-- what generates StateID value?

create table US_States_3(
	StateID tinyint NOT NULL PRIMARY KEY IDENTITY(1,1), 
	StateCode char(2) NOT NULL UNIQUE, 
	StateName varchar(50) NOT NULL UNIQUE,
	CHECK (StateID BETWEEN 1 AND 100));
-- all problems addressed, but is this ideal?
-- since StateCode is unique, is StateID redundant?
-- since StateCode is defined unique by outside agency, and StateID is internally generated,
-- could this cause data integrity issues? (delete a State but reinsert under new StateID?)
-- is there a valid case to change StateID? what if state name or code changes?
-- State name is also unique, could that be used as primary key?

create table US_States_4(
	StateCode char(2) NOT NULL PRIMARY KEY, 
	StateName varchar(50) NOT NULL UNIQUE);
-- all problems addressed
-- redundant StateID removed, as well as supporting constraints
-- no data type imposed limit on number of states, and no need to constrain for such
-- "natural" key also more useful for joins, especially with foreign key (trusted constraint)
-- still feels like something's missing...

create table US_States(
	StateCode char(2) NOT NULL CONSTRAINT PK_US_States PRIMARY KEY, 
	StateName varchar(50) NOT NULL CONSTRAINT UNQ_US_States_StateName UNIQUE,
	CONSTRAINT CHK_US_States_StateCode CHECK (StateCode LIKE '[A-W][A-Z]'),
	CONSTRAINT CHK_US_States_StateName CHECK (StateName NOT LIKE '[^A-Za-z ]'));
-- constraints are explicitly named
-- additional check constraints to prevent invalid characters
-- could this be even MORE anal?

create table US_States_Volk(
	StateCode char(2) NOT NULL CONSTRAINT PK_US_States PRIMARY KEY, 
	StateName varchar(50) NOT NULL CONSTRAINT UNQ_US_States_StateName UNIQUE,
	CONSTRAINT CHK_US_States_StateCode CHECK (StateCode LIKE '[A-W][A-Z]'),
	CONSTRAINT CHK_US_States_StateName CHECK (StateName NOT LIKE '[^A-Za-z ]'),
	CONSTRAINT CHK_US_States_WhyBother CHECK (StateCode IN('AL','AK','AZ','AR','CA','CO','CT','DE','DC','FL','GA',
	'HI','ID','IL','IN','IA','KS','KY','LA','ME','MD','MA','MI','MN','MS','MO',	'MT','NE','NV','NH','NJ','NM','NY',
	'NC','ND','OH','OK','OR','PA','RI','SC','SD','TN','TX','UT','VT','VA','WA','WV','WI','WY'))
	);
-- why bother? Foreign key to related tables would ensure valid codes
-- additional constraint has to be checked, and modified if new codes are added
-- or, CHECK constraint could be put on any table that actually stores state codes (addresses, etc.) and skip this table
-- guess what? ADD THIS CHECK CONSTRAINT TO THOSE TABLES TOO! (over-constraining to protect against drop or disable)

-- by the way, does this level of constraint only apply to regular tables?
-- NOPE!
-- temp tables have same constraints except for foreign keys
-- table variables allow primary key, unique, and check constraints (plus null and default)

declare @states table(a char(2) not null primary key, b varchar(50) not null unique);
insert @states(b,a) select 'Alabama','AL' union all select 
'Alaska','AK' union all select 
'Arizona','AZ' union all select 
'Arkansas','AR' union all select 
'California','CA' union all select 
'Colorado','CO' union all select 
'Connecticut','CT' union all select 
'District of Columbia','DC' union all select 
'Delaware','DE' union all select 
'Florida','FL' union all select 
'Georgia','GA' union all select 
'Hawaii','HI' union all select 
'Idaho','ID' union all select 
'Illinois','IL' union all select 
'Indiana','IN' union all select 
'Iowa','IA' union all select 
'Kansas','KS' union all select 
'Kentucky','KY' union all select 
'Louisiana','LA' union all select 
'Maine','ME' union all select 
'Massachusetts','MA' union all select 
'Maryland','MD' union all select 
'Michigan','MI' union all select 
'Minnesota','MN' union all select 
'Mississippi','MS' union all select 
'Missouri','MO' union all select 
'Montana','MT' union all select 
'North Carolina','NC' union all select 
'New Hampshire','NH' union all select 
'New Jersey','NJ' union all select 
'New York','NY' union all select 
'North Dakota','ND' union all select 
'New Mexico','NM' union all select 
'Nebraska','NE' union all select 
'Nevada','NV' union all select 
'Ohio','OH' union all select 
'Oklahoma','OK' union all select 
'Oregon','OR' union all select 
'Pennsylvania','PA' union all select 
'Rhode Island','RI' union all select 
'South Carolina','SC' union all select 
'South Dakota','SD' union all select 
'Tennessee','TN' union all select 
'Texas','TX' union all select 
'Utah','UT' union all select 
'Virginia','VA' union all select 
'Vermont','VT' union all select 
'West Virginia','WV' union all select 
'Washington','WA' union all select 
'Wisconsin','WI' union all select 
'Wyoming','WY';
