USE AdventureWorks;

-- check data type
SELECT table_schema, table_name, column_name, data_type, column_default 
	FROM INFORMATION_SCHEMA.COLUMNS WHERE column_name='CommissionPct';

-- look for check constraints
SELECT * FROM sys.check_constraints WHERE object_id=object_id('Sales.SalesPerson');

-- check data
SELECT CommissionPct, CommissionPct*100 Pct FROM Sales.SalesPerson;

-- OK, no problems here....YET
BEGIN TRAN

UPDATE Sales.SalesPerson SET CommissionPct=CommissionPct*10000;

-- check data again....whoops
SELECT CommissionPct, CommissionPct*100 Pct FROM Sales.SalesPerson;

ROLLBACK TRAN;

-- please be fixed, please be fixed...
SELECT CommissionPct, CommissionPct*100 Pct FROM Sales.SalesPerson;

-- how do we prevent?
ALTER TABLE Sales.SalesPerson 
	ADD CONSTRAINT CHK_SalesCommissionPct CHECK (CommissionPct BETWEEN 0 AND 0.99);
