USE tempdb;

SET NOCOUNT ON;

CREATE TABLE parent(table_name AS 'parent', 
	parent_id int not null constraint PK_Parent PRIMARY KEY);

CREATE TABLE child_cascade(table_name AS 'child_cascade', 
	child_id int not null,
	parent_id int null 
	CONSTRAINT FK_child_cascade_parent 
	FOREIGN KEY REFERENCES parent(parent_id) ON DELETE CASCADE ON UPDATE CASCADE);

CREATE TABLE child_null(table_name AS 'child_null', 
	child_id int not null,
	parent_id int null 
	CONSTRAINT FK_child_null_parent 
	FOREIGN KEY REFERENCES parent(parent_id) ON DELETE SET NULL ON UPDATE SET NULL);

CREATE TABLE child_default(table_name AS 'child_default', 
	child_id int not null,
	parent_id int null CONSTRAINT DF_child_default_parent_id DEFAULT(0)
	CONSTRAINT FK_child_default_parent 
	FOREIGN KEY REFERENCES parent(parent_id) ON DELETE SET DEFAULT ON UPDATE SET DEFAULT);

INSERT parent(parent_id) VALUES(1),(2),(3),(0);

INSERT child_cascade(parent_id,child_id) SELECT parent_id,parent_id FROM parent;
INSERT child_null(parent_id,child_id) SELECT parent_id,parent_id FROM parent;
INSERT child_default(parent_id,child_id) SELECT parent_id,parent_id FROM parent;

SELECT * FROM parent;
SELECT * FROM child_cascade;
SELECT * FROM child_null;
SELECT * FROM child_default;

DELETE parent WHERE parent_id=2;

SELECT * FROM parent;
SELECT * FROM child_cascade;
SELECT * FROM child_null;
SELECT * FROM child_default;

UPDATE parent SET parent_id=-parent_id;

SELECT * FROM parent;
SELECT * FROM child_cascade;
SELECT * FROM child_null;
SELECT * FROM child_default;


-- clean up
DROP TABLE child_cascade, child_default, child_null;
DROP TABLE parent;
