USE tempdb;

SET NOCOUNT ON;

CREATE TABLE parent(table_name AS 'parent', 
	parent_id int not null constraint PK_Parent PRIMARY KEY);

CREATE TABLE child_cascade(table_name AS 'child_cascade', 
	child_id int not null,
	parent_id int null);

CREATE TABLE child_null(table_name AS 'child_null', 
	child_id int not null,
	parent_id int null);

CREATE TABLE child_default(table_name AS 'child_default', 
	child_id int not null,
	parent_id int null CONSTRAINT DF_child_default_parent_id DEFAULT(0));

GO

-- equivalent triggers
CREATE TRIGGER trg_parent_delete ON parent AFTER DELETE AS
SET NOCOUNT ON;

DELETE c FROM child_cascade c
WHERE EXISTS(SELECT * FROM deleted WHERE parent_id=c.parent_id);

UPDATE d SET parent_id=0
FROM child_default d
WHERE EXISTS(SELECT * FROM deleted WHERE parent_id=d.parent_id);

UPDATE n SET parent_id=null
FROM child_null n
WHERE EXISTS(SELECT * FROM deleted WHERE parent_id=n.parent_id);
GO

-- and again for updates
CREATE TRIGGER trg_parent_update ON parent AFTER UPDATE AS
SET NOCOUNT ON;

UPDATE c SET parent_id=i.parent_id
FROM child_cascade c
INNER JOIN deleted d on c.parent_id=d.parent_id
INNER JOIN inserted i on c.parent_id=i.parent_id;	-- hang on, the key was updated, this join won't work!

UPDATE c SET parent_id=0
FROM child_default c
INNER JOIN deleted d on c.parent_id=d.parent_id;

UPDATE c SET parent_id=null
FROM child_null c
INNER JOIN deleted d on c.parent_id=d.parent_id;
GO


INSERT parent(parent_id) VALUES(1),(2),(3),(0);

INSERT child_cascade(parent_id,child_id) SELECT parent_id,parent_id FROM parent;
INSERT child_null(parent_id,child_id) SELECT parent_id,parent_id FROM parent;
INSERT child_default(parent_id,child_id) SELECT parent_id,parent_id FROM parent;

SELECT * FROM parent;
SELECT * FROM child_cascade;
SELECT * FROM child_null;
SELECT * FROM child_default;

DELETE parent WHERE parent_id=2;

-- DELETE cascades fine
SELECT * FROM parent;
SELECT * FROM child_cascade;
SELECT * FROM child_null;
SELECT * FROM child_default;

UPDATE parent SET parent_id=-parent_id

-- UPDATE not so much...
SELECT * FROM parent;
SELECT * FROM child_cascade;	-- join issues
SELECT * FROM child_null;		-- how about this one?
SELECT * FROM child_default;

-- by the way, if I change the default value in the child_default table, I have to change the triggers on parent!
-- oh yeah, did I mention you also need insert and update triggers on all the child tables to enforce referential integrity?
-- I'll leave that as an exercise for you!

DROP TABLE child_cascade, child_default, child_null;
DROP TABLE parent;
