Use AdventureWorks;

CREATE TABLE Sales.Sales_2008(
	SalesOrderID int not null,
	OrderDate date not null, 
	TotalDue money not null,
	CONSTRAINT CHK_Sales_2008 
	CHECK (OrderDate BETWEEN '2008-01-01' AND '2008-12-31'));

CREATE TABLE Sales.Sales_2007(
	SalesOrderID int not null,
	OrderDate date not null, 
	TotalDue money not null,
	CONSTRAINT CHK_Sales_2007 
	CHECK (OrderDate BETWEEN '2007-01-01' AND '2007-12-31'));

CREATE TABLE Sales.Sales_2006(
	SalesOrderID int not null,
	OrderDate date not null, 
	TotalDue money not null,
	CONSTRAINT CHK_Sales_2006 
	CHECK (OrderDate BETWEEN '2006-01-01' AND '2006-12-31'));

INSERT Sales.Sales_2006(SalesOrderID, OrderDate, TotalDue)
SELECT SalesOrderID, OrderDate, TotalDue
	FROM Sales.SalesOrderHeader
	WHERE OrderDate BETWEEN '2006-01-01' AND '2006-12-31';
INSERT Sales.Sales_2007(SalesOrderID, OrderDate, TotalDue)
SELECT SalesOrderID, OrderDate, TotalDue
	FROM Sales.SalesOrderHeader
	WHERE OrderDate BETWEEN '2007-01-01' AND '2007-12-31';
INSERT Sales.Sales_2008(SalesOrderID, OrderDate, TotalDue)
SELECT SalesOrderID, OrderDate, TotalDue
	FROM Sales.SalesOrderHeader
	WHERE OrderDate BETWEEN '2008-01-01' AND '2008-12-31';
GO
CREATE VIEW Sales.PartitionedView AS
SELECT SalesOrderID, OrderDate, TotalDue FROM Sales.Sales_2006
UNION ALL
SELECT SalesOrderID, OrderDate, TotalDue FROM Sales.Sales_2007
UNION ALL
SELECT SalesOrderID, OrderDate, TotalDue FROM Sales.Sales_2008;
GO

-- turn on show plan
SELECT * FROM Sales.PartitionedView;  -- no WHERE

SELECT * FROM Sales.PartitionedView 
	WHERE OrderDate>'1/1/2008';  -- Jan 1 2008 w/ check

-- drop constraints
ALTER TABLE Sales.Sales_2008 DROP CONSTRAINT CHK_Sales_2008;
ALTER TABLE Sales.Sales_2007 DROP CONSTRAINT CHK_Sales_2007;
-- ALTER TABLE Sales.Sales_2006 DROP CONSTRAINT CHK_Sales_2006;

SELECT * FROM Sales.PartitionedView 
	WHERE OrderDate>'1/1/2008';  -- Jan 1 2008 w/o check

-- put them back
ALTER TABLE Sales.Sales_2008 ADD CONSTRAINT CHK_Sales_2008 
	CHECK (OrderDate BETWEEN '2008-01-01' AND '2008-12-31');
ALTER TABLE Sales.Sales_2007 ADD CONSTRAINT CHK_Sales_2007 
	CHECK (OrderDate BETWEEN '2007-01-01' AND '2007-12-31');
ALTER TABLE Sales.Sales_2006 ADD CONSTRAINT CHK_Sales_2006 
	CHECK (OrderDate BETWEEN '2006-01-01' AND '2006-12-31');

SELECT * FROM Sales.PartitionedView 
	WHERE OrderDate>'1/1/2008';  -- Jan 1 2008 w/ check

-- what about data out of range?
SELECT * FROM Sales.PartitionedView 
	WHERE OrderDate<'1/1/2006';  -- 2006


-- Available in all editions!
SELECT SERVERPROPERTY('Edition') SQLEdition;

-- clean up 
DROP VIEW Sales.PartitionedView;
DROP TABLE Sales.Sales_2006, Sales.Sales_2007, Sales.Sales_2008;

