/* Querying System Tables */ 

select  TOP 10 
        s.name as SchemaName
       ,t.name as TableName
       ,c.name as ColumnName
       ,c.is_identity
       ,c.is_nullable
       ,c.user_type_id
       ,ty.name
  from sys.schemas as s
inner join sys.tables as t
on (s.schema_id = t.schema_id)
inner join sys.columns as c
on (t.object_id = c.object_id)
inner join sys.types ty
on (ty.user_type_id = c.user_type_id) 
--WHERE is_identity = 1
--WHERE c.is_nullable = 0
WHERE ty.name = 'datetime' and c.name NOT IN ('ModifiedDate')



