/*
T-SQL Basics Demo Scripts
Carlton Ramsey
twitter: @eccentircDBA 
blog: http://www.eccentricDBA.com
*/

/*
How to create localdb DEMO instance after installing local db.
C:\sqllocaldb create "DEMO" -s

Returns:
LocalDB instance "DEMO" created with version 14.0.1000.169.
LocalDB instance "DEMO" started.

Verify Instance Information
C:\sqllocaldb info DEMO

Returns:
Name:               DEMO
Version:            14.0.1000.169
Shared name:
Owner:              COMPUTERNAME\USERNAME
Auto-create:        No
State:              Running
Last start time:    1/6/2018 7:45:40 PM
Instance pipe name: np:\\.\pipe\LOCALDB#E2AA9331\tsql\query
*/

/*
To connect to the instance use (localdb)\DEMO for the server name.
*/

/* Restore AdventureWorks2017 OLTP Sample Databaes Backup */
/*
USE [master]
RESTORE DATABASE [AdventureWorks2017] 
   FROM DISK = N'C:\Downloads\AdventureWorks2017.bak' 
   WITH FILE = 1,
   MOVE N'AdventureWorks2017' TO N'C:\Databases\AdventureWorks2017.mdf',
   MOVE N'AdventureWorks2017_log' TO N'C:\Databases\AdventureWorks2017_log.ldf',
   NOUNLOAD,  STATS = 5 */

/* Find the Top 5 Last Names in the Person Table. */
SELECT TOP 5 LastName
            , COUNT(*) AS NumberOf
  FROM [AdventureWorks2017].[Person].[Person]
GROUP BY LastName
ORDER BY 2 DESC  


/*List Employee by Department */
SELECT TOP 5 BusinessEntityID 
            ,JobTitle
  FROM [AdventureWorks2017].[HumanResources].[Employee];

SELECT TOP 5 BusinessEntityID 
    ,Title
    ,FirstName 
    ,MiddleName 
    ,LastName 
    ,Suffix
FROM [AdventureWorks2017].[Person].[Person];

SELECT TOP 5 DepartmentID 
            ,Name AS Department
            ,GroupName
  FROM [AdventureWorks2017].[HumanResources].[Department];

SELECT TOP 5 BusinessEntityID 
            ,DepartmentID 
            ,StartDate
            ,EndDate
  FROM [AdventureWorks2017].[HumanResources].[EmployeeDepartmentHistory]
WHERE EndDate IS NULL /* Only show the employee's current department */;

/* Put it all together and it becomes the vEmployeeDepartment Veiw */
SELECT 
    e.[BusinessEntityID] 
    ,p.[Title] 
    ,p.[FirstName] 
    ,p.[MiddleName] 
    ,p.[LastName] 
    ,p.[Suffix] 
    ,e.[JobTitle]
    ,d.[Name] AS [Department] 
    ,d.[GroupName] 
    ,edh.[StartDate] 
FROM [AdventureWorks2017].[HumanResources].[Employee] e
	INNER JOIN [AdventureWorks2017].[Person].[Person] p
	ON p.[BusinessEntityID] = e.[BusinessEntityID]
    INNER JOIN [AdventureWorks2017].[HumanResources].[EmployeeDepartmentHistory] edh 
    ON e.[BusinessEntityID] = edh.[BusinessEntityID] 
    INNER JOIN [AdventureWorks2017].[HumanResources].[Department] d 
    ON edh.[DepartmentID] = d.[DepartmentID] 
WHERE edh.EndDate IS NULL;

/* 
Find the Deparment with two managers with the same JobTitle
*/

SELECT Department
       ,JobTitle 
       ,COUNT(*) NumberOf
  FROM AdventureWorks2017.HumanResources.vEmployeeDepartment
WHERE JobTitle LIKE '%Manager%'
GROUP BY Department, JobTitle HAVING COUNT(*) > 1
ORDER BY Department, JobTitle

/* Products */
SELECT Name, ProductNumber, Color 
  FROM Production.Product

/* Find all the Black and Silver Bikess */
SELECT Name, Color, ProductNumber 
  FROM Production.Product
WHERE Color IN ('Black', 'Silver')
AND ProductNumber LIKE 'BK%'
ORDER BY Name, Color

/* Date Example */
SELECT TOP 5 ProductNumber
       ,Name
       ,SellStartDate
       ,SellEndDate
  FROM Production.Product
 WHERE '2010-01-31' BETWEEN SellStartDate AND IsNULL(SellEndDate, GETDATE())
 ORDER BY SellEndDate DESC, SellStartDate DESC

/* Pivot Example 
https://technet.microsoft.com/en-us/library/ms177410(v=sql.105).aspx
*/
SELECT DaysToManufacture, AVG(StandardCost) AS AverageCost 
FROM Production.Product
GROUP BY DaysToManufacture;

-- Pivot table with one row and five columns
SELECT 'AverageCost' AS Cost_Sorted_By_Production_Days, 
[0], [1], [2], [3], [4]
FROM
(SELECT DaysToManufacture, StandardCost 
    FROM Production.Product) AS SourceTable
PIVOT
(
AVG(StandardCost)
FOR DaysToManufacture IN ([0], [1], [2], [3], [4])
) AS PivotTable;


