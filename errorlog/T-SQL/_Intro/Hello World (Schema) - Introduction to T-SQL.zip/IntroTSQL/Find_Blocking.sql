--Connect to SQLPresentations!
USE SQLPresentations;
GO

SELECT DTL.resource_type
	,CASE WHEN DTL.resource_type IN ('DATABASE','FILE','METADATA')
			THEN DTL.resource_type
		  WHEN DTL.resource_type = 'OBJECT'
			THEN OBJECT_NAME(DTL.resource_associated_entity_id)
		  WHEN DTL.resource_type IN ('KEY','PAGE','RID')
			THEN (SELECT OBJECT_NAME(object_id) FROM sys.partitions WHERE sys.partitions.hobt_id = DTL.resource_associated_entity_id)
		  ELSE 'Unidentified'
		END AS [Parent Object]
	,DTL.request_mode AS [Lock Type]
	,DTL.request_status AS [Request Status]
--	,DOWT.wait_type
	,DOWT.session_id AS [Blocked Session ID]
	,SUBSTRING(DEST_Blocked.[text], der.statement_start_offset / 2,
		(CASE WHEN DER.statement_end_offset = -1
			THEN DATALENGTH(DEST_Blocked.[text])
		 ELSE DER.statement_end_offset END - DER.statement_start_offset) / 2) AS [Blocked Command]
	,DOWT.blocking_session_id
	,DEST_Blocking.[text] AS [Blocking Command]
--	,DOWT.resource_description AS [Blocking Detail]
FROM sys.dm_tran_locks AS DTL
INNER JOIN sys.dm_os_waiting_tasks AS DOWT
	ON DTL.lock_owner_address = DOWT.resource_address
INNER JOIN sys.dm_exec_requests AS DER
	ON DOWT.session_id = DER.session_id
INNER JOIN sys.dm_exec_sessions AS DES_Blocked
	ON DOWT.session_id = DES_Blocked.session_id
INNER JOIN sys.dm_exec_sessions AS DES_Blocking
	ON DOWT.blocking_session_id = DES_Blocking.session_id
INNER JOIN sys.dm_exec_connections AS DEC
	ON DTL.request_session_id = DEC.most_recent_session_id
CROSS APPLY sys.dm_exec_sql_text(DEC.most_recent_sql_handle) AS DEST_Blocking
CROSS APPLY sys.dm_exec_sql_text(DER.sql_handle) AS DEST_Blocked
WHERE DTL.resource_database_id = DB_ID()





--SELECT [resource_type]
--	,DB_NAME([resource_database_id]) AS [Database Name]
--	,CASE WHEN DTL.resource_type IN ('DATABASE','FILE','METADATA')
--			THEN DTL.resource_type
--		  WHEN DTL.resource_type = 'OBJECT'
--			THEN OBJECT_NAME(DTL.resource_associated_entity_id, DTL.resource_database_id)
--		  WHEN DTL.resource_type IN ('KEY','PAGE','RID')
--			THEN (SELECT OBJECT_NAME(object_id) FROM sys.partitions WHERE sys.partitions.hobt_id = DTL.resource_associated_entity_id)
--		  ELSE 'Unidentified'
--		END AS [Requested Object Name]
--	,[request_mode]
--	,[resource_description]
--FROM sys.dm_tran_locks AS DTL
--WHERE DTL.[resource_type] <> 'DATABASE'



--SELECT DTST.session_id
--	,DB_NAME(DTDT.database_id) AS [Database]
--	,CASE DTAT.transaction_type
--		WHEN 1 THEN 'Read/Write'
--		WHEN 2 THEN 'Read-only'
--		WHEN 3 THEN 'System'
--		WHEN 4 THEN 'Distributed'
--	 END AS [Transaction Type]
--	,CASE DTAT.transaction_state
--		WHEN 0 THEN 'Not fully initialized'
--		WHEN 1 THEN 'Initialized, not started'
--		WHEN 2 THEN 'Active'
--		WHEN 3 THEN 'Ended'
--		WHEN 4 THEN 'Connit initialized'
--		WHEN 5 THEN 'Prepared, awaiting resolution'
--		WHEN 6 THEN 'Committed'
--		WHEN 7 THEN 'Rolling back'
--		WHEN 8 THEN 'Rolled back'
--	 END AS [Transaction State]
--	,DEST.[text] AS [Last Transaction Text] 
--	,DEQP.[query_plan] AS [Last Query Plan] 
--FROM sys.dm_tran_database_transactions AS DTDT
--INNER JOIN sys.dm_tran_session_transactions AS DTST
--	ON DTST.transaction_id = DTDT.transaction_id
--INNER JOIN sys.dm_tran_active_transactions AS DTAT
--	ON DTST.transaction_id = DTAT.transaction_id
--INNER JOIN sys.dm_exec_sessions AS DES
--	ON DES.session_id = DTST.session_id
--INNER JOIN sys.dm_exec_connections AS DEC
--	ON DEC.session_id = DTST.session_id
--LEFT JOIN sys.dm_exec_requests AS DER
--	ON DER.session_id = DTST.session_id
--CROSS APPLY sys.dm_exec_sql_text (DEC.most_recent_sql_handle) AS DEST
--OUTER APPLY sys.dm_exec_query_plan (DER.plan_handle) AS DEQP