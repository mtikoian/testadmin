--Creating a new database
	
CREATE DATABASE SQLPresentations





--Creating our first table inside our database

USE SQLPresentations
GO

CREATE TABLE dbo.Speakers(
	SpeakerID	smallint	NOT NULL	IDENTITY(1,1) PRIMARY KEY
	,LastName	varchar(50) NOT NULL
	,FirstName	varchar(20) NOT NULL
)

CREATE TABLE dbo.Presentations(
	PresentationID	smallint		NOT NULL	IDENTITY PRIMARY KEY
	,PresentationName varchar(255)	NOT NULL
	,SessionLevel	varchar(12)		NOT NULL
	,SpeakerID		smallint		NOT NULL	CONSTRAINT FK_SpeakerID FOREIGN KEY REFERENCES dbo.Speakers(SpeakerID)
	,PresentationDescription varchar(4000)	NOT NULL
)

--Another way you might apply a Foreign Key, after the fact

ALTER TABLE dbo.Presentations
ADD CONSTRAINT FK_SpeakerID FOREIGN KEY (SpeakerID)
REFERENCES dbo.Speakers(SpeakerID)





--DML Start

--Inserting Speaker Data

INSERT INTO dbo.Speakers (LastName, FirstName)
VALUES('Leonard','Andy'),
('Wilson','Ed'),
('Little','Kendra'),
('Lowder','Shannon'),
('Lopez','Karen'),
('Chinchilla','Jose'),
('Velic','Matthew')

--Presentation data

INSERT INTO dbo.Presentations (PresentationName, SessionLevel, SpeakerID, PresentationDescription)
VALUES
('Windows PoSh Best Practices for DBAs','Beginner',2,'Learn Windows PowerShell best practices as they apply to each stage of the script development lifecycle. See the differences between working interactively from the Windows PowerShell prompt, writing an inline script, adding basic function, advanced functions and finally the implementation of Windows PowerShell Modules. What is a local best practice for Windows PowerShell development is not the same as a global best practice, and this talk covers those differences.'),
('Hello World (Schema) - Introduction to T-SQL','Beginner',7,'So you�re ready to dump that Excel �database� and join the SQL Server crowd? Matt Velic will guide you on a whirlwind tour of Transact-SQL. You�ll learn a little about its history, what Data Definition Language (DDL) and Data Manipulation Language (DML) are, and how to write basic statements of your own. Finally, Matt will leave you with some resources that will take your T-SQL skills to the next level.'),
('0 to SSRS under 1 hour','Beginner',6,'In this session I will do an intro to Reporting Services 2008. Attendees will learn how to build reports and dashboards based on SQL Sever OLTP datasources as well as Analysis Services OLAP cubes.'),
('0 to SSAS under 1 hour','Beginner',6,'This is an intro session on SSAS 2008 to help attendees understand multidimensional modeling and OLAP cube development. I will do a quick overview on how to design a multidimensional data warehouse and how to build a basic SSAS cube.'),
('�I See a Control Flow Tab. Now What?�','Beginner',1,'This highly-interactive, demo-intense presentation is for beginners and developers just getting started with SSIS. Attend and learn how to build SSIS packages from the ground up.'),
('Designing an SSIS Framework','Advanced',1,'In this �demo-tastic� presentation, SSIS trainer, author, and consultant Andy Leonard explains the what, why, and how of an SSIS framework that delivers metadata-driven package execution, connections management, and centralizes logging. Key takeaways: 1) Developers can migrate packages from Development, through their lifecycle, to Production without editing SSIS Connection Managers properties. 2) A metadata-driven approach to SSIS package execution. 3) Demonstration of a centralized logging reporting application.'),
('Lessons Learned: Starting your career as a DBA','Beginner',4,'A brief introduction to your life as a DBA. From the topics you''ll want to be familiar with, to choosing third party tools to help you do your job with less effort, this is the bootstrap guide to getting started as a DBA.'),
('Windows PowerShell Best Practices for DBAs Part 2','Beginner',20,'Learn Windows PowerShell best practices as they apply to each stage of the script development lifecycle. See the differences between working interactively from the Windows PowerShell prompt, writing an inline script, adding basic function, advanced functions and finally the implementation of Windows PowerShell Modules. What is a local best practice for Windows PowerShell development is not the same as a global best practice, and this talk covers those differences.')

--Let's quickly check our data

SELECT SpeakerID, LastName, FirstName
FROM dbo.Speakers

SELECT PresentationID, PresentationName, SessionLevel, SpeakerID, PresentationDescription
FROM dbo.Presentations





--Updating a typo can be done in multiple ways

BEGIN TRANSACTION
UPDATE dbo.Presentations
SET PresentationName = 'Windows PowerShell Best Practices for DBAs'
WHERE PresentationName = 'Windows PoSh Best Practices for DBAs'

ROLLBACK

BEGIN TRANSACTION
UPDATE dbo.Presentations
SET PresentationName = 'Windows PowerShell Best Practices for DBAs'
WHERE PresentationID = 9

COMMIT TRANSACTION

SELECT p.PresentationID, p.PresentationName, p.SessionLevel, p.SpeakerID, p.PresentationDescription
FROM dbo.Presentations AS p





--Deleting unnecessary data. Also, constraints prevent orphaned records
BEGIN TRANSACTION
DELETE FROM dbo.Speakers
WHERE LastName = 'Velic'

BEGIN TRANSACTION
DELETE FROM dbo.Presentations
WHERE PresentationName = 'Hello World (Schema) - Introduction to T-SQL'

DELETE FROM dbo.Speakers
WHERE LastName = 'Velic'

ROLLBACK

SELECT p.PresentationID, p.PresentationName, p.SessionLevel, p.SpeakerID, p.PresentationDescription
FROM dbo.Presentations AS p

SELECT s.SpeakerID, s.LastName, s.FirstName
FROM dbo.Speakers AS s





-- Breaking down the Select Statement
SELECT s.SpeakerID, s.LastName, s.FirstName
FROM dbo.Speakers AS s

--Columns can be concatenated

SELECT s.SpeakerID, s.FirstName + ' ' + s.LastName AS FullName
FROM dbo.Speakers AS s

--You have flexibility in Ordering your data

SELECT s.SpeakerID, s.FirstName + ' ' + s.LastName AS FullName
FROM dbo.Speakers AS s
ORDER BY FullName

SELECT s.SpeakerID, s.FirstName + ' ' + s.LastName AS FullName
FROM dbo.Speakers AS s
ORDER BY s.LastName

SELECT s.SpeakerID, s.FirstName
FROM dbo.Speakers AS s
ORDER BY s.LastName

--Queries are Limited by the WHERE clause
SELECT s.SpeakerID, s.FirstName + ' ' + s.LastName AS FullName
FROM dbo.Speakers AS s
WHERE s.LastName LIKE 'L%'
ORDER BY s.LastName

SELECT s.SpeakerID, s.FirstName + ' ' + s.LastName AS FullName
FROM dbo.Speakers AS s
WHERE s.SpeakerID >= 5
ORDER BY s.LastName




--Joins of all kinds!

SELECT s.FirstName + ' ' + s.LastName AS FullName, p.PresentationName
FROM dbo.Speakers AS s
INNER JOIN dbo.Presentations AS p
	ON p.SpeakerID = s.SpeakerID
ORDER BY s.LastName

SELECT s.FirstName + ' ' + s.LastName AS FullName, p.PresentationName
FROM dbo.Speakers AS s
LEFT OUTER JOIN dbo.Presentations AS p
	ON p.SpeakerID = s.SpeakerID
ORDER BY s.LastName

SELECT s.FirstName + ' ' + s.LastName AS FullName, p.PresentationName
FROM dbo.Speakers AS s
RIGHT OUTER JOIN dbo.Presentations AS p
	ON p.SpeakerID = s.SpeakerID
ORDER BY s.LastName

SELECT s.FirstName + ' ' + s.LastName AS FullName, p.PresentationName
FROM dbo.Speakers AS s
FULL OUTER JOIN dbo.Presentations AS p
	ON p.SpeakerID = s.SpeakerID
ORDER BY s.LastName

SELECT s.FirstName + ' ' + s.LastName AS FullName, p.PresentationName
FROM dbo.Speakers AS s
CROSS JOIN dbo.Presentations AS p
ORDER BY s.LastName

--Aliases are important. SQL Server will not guess for you.

SELECT SpeakerID, FirstName + ' ' + LastName AS FullName, PresentationName
FROM dbo.Presentations AS p
INNER JOIN dbo.Speakers AS s
	ON p.SpeakerID = s.SpeakerID
ORDER BY s.LastName





--Aggregate Information
SELECT COUNT(*) AS [Speaker Count]
FROM dbo.Speakers

SELECT s.FirstName + ' ' + s.LastName AS FullName, Count(p.PresentationName) AS [Presentation Count]
FROM dbo.Speakers AS s
INNER JOIN dbo.Presentations AS p
	ON p.SpeakerID = s.SpeakerID
WHERE s.SpeakerID > 0
GROUP BY s.LastName, s.FirstName
--HAVING Count(p.SpeakerID) > 1
ORDER BY s.LastName




--Joining everything together to get back to our Excel Spreadsheet

SELECT p.PresentationName AS Presentation, s.FirstName + ' ' + s.LastName AS Speaker, p.SessionLevel AS [Session Level], p.PresentationDescription AS [Description]
FROM dbo.Presentations AS p
INNER JOIN dbo.Speakers AS s
	ON p.SpeakerID = s.SpeakerID
ORDER BY s.LastName, Presentation

--Sure, that's a lot, but not if we make it a View

CREATE VIEW dbo.PresentationInfo (Presentation, Speaker, [Session Level], [Description])
AS
SELECT p.PresentationName AS Presentation, s.FirstName + ' ' + s.LastName AS Speaker, p.SessionLevel AS [Session Level], p.PresentationDescription AS [Description]
FROM dbo.Presentations AS p
INNER JOIN dbo.Speakers AS s
	ON p.SpeakerID = s.SpeakerID

SELECT p.Presentation, p.Speaker, p.[Session Level], p.[Description]
FROM dbo.PresentationInfo AS p
WHERE p.Speaker LIKE 'E%'