READ ME! (or not...)

Hey folks: thanks again for coming to my presentation!

These materials will also be available on my blog at the following address:
http://mattvelic.com/intro-tsql

See you again soon!