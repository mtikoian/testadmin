--Connect to SQLPresentations!
USE SQLPresentations;
GO

SELECT p.PresentationID, p.PresentationName, p.SessionLevel, p.SpeakerID, p.PresentationDescription
FROM dbo.Presentations AS p
--WHERE p.PresentationID <> 1