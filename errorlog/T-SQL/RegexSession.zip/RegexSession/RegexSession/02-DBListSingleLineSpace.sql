/*
Simple comma-delimited list.
To turn into a regular list:
Search for: ,   -- that's comma-space
Replace with: \n
*/

HouseHold, CPAM, Recipe, ITBookworm, Evidence, ReportServer, ReportServerTempDB, WSS_Config, WSS_AdminContent, WSS_Content, TfsVersionControl, TfsActivityLogging, TfsBuild, TfsIntegration, TfsWorkItemTracking, TfsWorkItemTrackingAttachments, TfsWarehouse, NinjaReporting, CPAMdev, Minion, BF3, BF1, DB2, BF2, MidnightSQL, ReindexTest