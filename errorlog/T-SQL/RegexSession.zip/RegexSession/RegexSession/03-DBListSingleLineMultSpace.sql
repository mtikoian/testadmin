
/*
This one has mixed spaces and tabs... and sometimes none.
To make this into a list:
Search for: ,:b*
Replace with: \n
:b -- space or tab
* -- zero or more.

*/

HouseHold,  CPAM, Recipe,		ITBookworm, Evidence,ReportServer, ReportServerTempDB, WSS_Config, WSS_AdminContent,			WSS_Content,	TfsVersionControl, TfsActivityLogging, TfsBuild, TfsIntegration,					TfsWorkItemTracking, TfsWorkItemTrackingAttachments, TfsWarehouse, NinjaReporting, CPAMdev, Minion, BF3, BF1, DB2, BF2, MidnightSQL, ReindexTest