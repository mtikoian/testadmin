USE IsolationLevelTest;
GO
-- READ COMMITTED
-- Run this in query window 2 while the 1st query is running
SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
SELECT * FROM dbo.IsolationTests;