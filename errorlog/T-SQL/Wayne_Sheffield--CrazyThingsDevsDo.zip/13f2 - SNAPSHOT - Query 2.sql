-- Run this in query window 2 while the 1st query is running
USE IsolationLevelTest;
GO
INSERT INTO dbo.IsolationTests(ColA) 
VALUES ('X');
-- Notice this is immediately executed, but this row is not returned in query window 1.
SELECT * FROM dbo.IsolationTests;