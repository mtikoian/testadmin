USE IsolationLevelTest;
GO
-- READ UNCOMMITTED
-- Run this in query window 2 while the 1st query is running
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
SELECT * FROM dbo.IsolationTests;


-- How about this in query window 2?
/*
SELECT * FROM dbo.IsolationTests WITH (NOLOCK);
*/
