/*
From: http://explainextended.com/2009/10/15/constraints-and-the-optimizer-in-sql-server-foreign-key/
*/


/*
A TRUSTED Foreign Key constraint guarantees two things:
1. each value of t_foreign.pid will be found in t_primary.id
2. each value of t_foreign.pid will be found in t_primary.id only once
*/

/*
Optimizations that SQL Server can make
If the foreign key is trusted, and the primary table is only used to ensure a record exists 
(only the columns used in the unique/pk are used in the join, no other columns anywhere else)
then the primary table can be completely removed from the query.
*/

USE ConstraintsTest;
GO

SELECT  TOP 10 f.*
FROM    dbo.t_primary p
JOIN    dbo.t_foreign f
ON      p.id = f.pid;

SELECT  TOP 10 f.*
FROM    dbo.t_foreign f
WHERE   f.pid IN
        (
        SELECT  id
        FROM    dbo.t_primary p
        );

/*
-- disable the constraint, but leave it in the database
ALTER TABLE dbo.t_foreign NOCHECK CONSTRAINT FK_foreign_pid_primary;

-- enable the constraint
ALTER TABLE dbo.t_foreign CHECK CONSTRAINT FK_foreign_pid_primary;

-- enable AND verify the constraint, making it trusted
ALTER TABLE dbo.t_foreign WITH CHECK CHECK CONSTRAINT FK_foreign_pid_primary;
*/
