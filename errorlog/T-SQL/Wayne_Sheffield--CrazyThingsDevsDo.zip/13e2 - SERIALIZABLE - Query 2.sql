-- Run this in query window 2 while the 1st query is running
USE IsolationLevelTest;
GO
INSERT INTO dbo.IsolationTests(ColA) 
VALUES ('W');
-- Notice this statement waits until query 1 is finished.
SELECT  * 
FROM    dbo.IsolationTests;
