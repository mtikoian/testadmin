USE IsolationLevelTest;
GO
EXECUTE dbo.db_reset;
GO

-- SERIALIZABLE
-- Run this in query window 1
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE;
--SET TRANSACTION ISOLATION LEVEL REPEATABLE READ;  -- what will happen if this is set instead?
BEGIN TRANSACTION; 
SELECT * FROM dbo.IsolationTests; 
WAITFOR DELAY '00:00:10';
SELECT * FROM dbo.IsolationTests; 
ROLLBACK;
SELECT * FROM dbo.IsolationTests; 
