USE tempdb;
GO
SET STATISTICS XML OFF;
GO

IF OBJECT_ID('tempdb..#testcheck') IS NOT NULL
    DROP TABLE #testcheck;
GO

CREATE TABLE #testcheck (
      RowID INTEGER IDENTITY PRIMARY KEY ,
      Age   TINYINT CONSTRAINT CK_test CHECK ( Age < 21 )
    );
GO

INSERT  INTO #testcheck ( Age )
        SELECT  ( ROW_NUMBER() OVER ( ORDER BY ( SELECT NULL ) ) % 20 ) + 1
        FROM    sys.all_columns;
GO

/*
ALTER TABLE #testcheck NOCHECK CONSTRAINT CK_test;
ALTER TABLE #testcheck CHECK CONSTRAINT CK_test;
ALTER TABLE #testcheck WITH CHECK CHECK CONSTRAINT CK_test;
GO
*/

SET STATISTICS XML ON;
GO

SELECT  *
FROM    #testcheck
WHERE   Age = 20;
GO

SELECT  *
FROM    #testcheck
WHERE   Age = 25;
GO

SET STATISTICS XML OFF;
GO
