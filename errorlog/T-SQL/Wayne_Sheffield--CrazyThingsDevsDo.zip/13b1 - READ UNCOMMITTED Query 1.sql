USE IsolationLevelTest;
GO
EXECUTE dbo.db_reset;
GO

BEGIN TRANSACTION;
UPDATE  dbo.IsolationTests 
SET     ColA = 'Z';
--Simulate having some intensive processing here with a wait 
WAITFOR DELAY '00:00:10';
ROLLBACK;
GO

SELECT *
FROM dbo.IsolationTests;
GO
