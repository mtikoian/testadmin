-- Run this in query window 2 while the 1st query is running
USE IsolationLevelTest;
GO
UPDATE dbo.IsolationTests SET ColA = 'W';
-- Notice that this waits until query 1 is finished (Repeatable Read)
-- Repeatable Read guarantees no changes or deletes - but inserts are possible, so you can still have phantom reads!
SELECT * FROM dbo.IsolationTests;
