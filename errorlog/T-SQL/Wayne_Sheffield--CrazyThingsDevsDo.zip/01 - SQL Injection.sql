IF DB_ID('SQLi') IS NULL 
    CREATE DATABASE SQLi;
GO

USE SQLi;
GO

IF OBJECT_ID('dbo.Users','U') IS NOT NULL DROP TABLE dbo.Users;
GO

CREATE TABLE dbo.Users (
    UserID INTEGER IDENTITY UNIQUE,
    UserName VARCHAR(50) NOT NULL,
    Password VARCHAR(50) NOT NULL,
    PRIMARY KEY (UserName, Password)
    );

INSERT INTO dbo.Users
VALUES  ('Mickey', 'Mouse'),
        ('Donald', 'Duck'),
        ('Minnie', 'Mouse');
GO
SELECT * FROM dbo.Users;

IF OBJECT_ID('dbo.PaymentInfo', 'U') IS NOT NULL DROP TABLE dbo.PaymentInfo;
CREATE TABLE dbo.PaymentInfo
    (AccountID  INTEGER,
     CC_Number  VARCHAR(20),
     CC_ExpDate DATE,
     CC_CID     VARCHAR(5));
INSERT INTO dbo.PaymentInfo
VALUES (1, '1111-2222-3333-4444', GETDATE(), '123');

IF OBJECT_ID('dbo.Login','P') IS NOT NULL DROP PROCEDURE dbo.Login;
GO
CREATE PROCEDURE dbo.Login
    @UserName VARCHAR(50),
    @Password VARCHAR(50)
AS
SELECT  UserName,
        Password
FROM    dbo.Users
WHERE   UserName = @UserName
AND     Password = @Password;
GO

IF OBJECT_ID('dbo.BadLogin','P') IS NOT NULL DROP PROCEDURE dbo.BadLogin;
GO
CREATE PROCEDURE dbo.BadLogin
    @UserName VARCHAR(50),
    @Password VARCHAR(50)
AS
DECLARE @SQLCmd VARCHAR(MAX);
SET @SQLCmd = 'SELECT  UserName, Password FROM dbo.Users WHERE UserName = ''' + @UserName + ''' AND Password = ''' + @Password + ''';';
EXECUTE (@SQLCmd);
GO

IF OBJECT_ID('dbo.InsertLogin','P') IS NOT NULL DROP PROCEDURE dbo.InsertLogin;
GO
CREATE PROCEDURE dbo.InsertLogin
    @UserName VARCHAR(50),
    @Password VARCHAR(50)
AS
IF NOT EXISTS (SELECT 1 FROM dbo.Users WHERE UserName = @UserName AND Password = @Password)
INSERT INTO dbo.Users (UserName, Password)
VALUES  (@UserName, @Password);
GO

IF OBJECT_ID('dbo.PaymentInfo', 'U') IS NOT NULL DROP TABLE dbo.PaymentInfo;
CREATE TABLE dbo.PaymentInfo
    (AccountID  INTEGER,
     CC_Number  VARCHAR(20),
     CC_ExpDate DATE,
     CC_CID     VARCHAR(5));
INSERT INTO dbo.PaymentInfo
VALUES (1, '1111-2222-3333-4444', GETDATE(), '123');

/*
Test Strings:
' OR 1=1;--
' OR 1=1;DROP PROC dbo.Login;--
*/