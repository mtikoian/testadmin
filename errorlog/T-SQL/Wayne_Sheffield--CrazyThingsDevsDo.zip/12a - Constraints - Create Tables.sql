/*
From: http://explainextended.com/2009/10/14/constraints-and-the-optimizer-in-sql-server-unique/
This took 41 seconds to run on my system. Your Mileage May Vary.
*/
USE master;
GO
IF DB_ID('ConstraintsTest') IS NOT NULL 
    DROP DATABASE ConstraintsTest;
GO
IF DB_ID('ConstraintsTest') IS NULL 
    CREATE DATABASE ConstraintsTest;
GO
USE ConstraintsTest;
GO
SET NOCOUNT ON;

CREATE TABLE dbo.t_primary (
        id INT NOT NULL,
        name VARCHAR(30) NOT NULL,
        CONSTRAINT PK_primary_id PRIMARY KEY (id)
)
CREATE TABLE dbo.t_foreign (
        id INT NOT NULL,
        pid INT NOT NULL,
        uval INT NOT NULL,
        dval INT NOT NULL,
        name VARCHAR(30) NOT NULL,
        CONSTRAINT PK_foreign_id PRIMARY KEY (id),
        CONSTRAINT FK_foreign_pid_primary FOREIGN KEY (pid) REFERENCES dbo.t_primary,
        CONSTRAINT UQ_foreign_uval UNIQUE (uval),
        CONSTRAINT CK_foreign_uval_dval CHECK (uval = dval)
)
GO
CREATE INDEX IX_foreign_dval ON dbo.t_foreign (dval)
GO
BEGIN TRANSACTION
SELECT  RAND(20091014)
DECLARE @cnt INT
DECLARE @ld INT
DECLARE @r INT
SET @cnt = 1
WHILE @cnt <= 100000
BEGIN
        INSERT
        INTO    dbo.t_primary
        VALUES  (@cnt, 'Primary ' + CAST(@cnt AS VARCHAR))
        SET @ld = (@cnt - 1) * 10 + 1
        WHILE @ld <= @cnt * 10
        BEGIN
                SET @r = @ld * 100 + FLOOR(RAND() * 100)
                INSERT
                INTO    dbo.t_foreign
                VALUES  (
                        @ld,
                        @cnt,
                        @r,
                        @r,
                        'Foreign ' + CAST(@ld AS VARCHAR)
                        )
                SET @ld = @ld + 1
        END
        SET @cnt = @cnt + 1
END
COMMIT
GO

SELECT TOP 100 * FROM dbo.t_primary;
SELECT TOP 100 * FROM dbo.t_foreign;
