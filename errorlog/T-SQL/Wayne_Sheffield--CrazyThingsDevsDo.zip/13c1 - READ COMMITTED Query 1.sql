USE IsolationLevelTest;
GO
EXECUTE dbo.db_reset;
GO

-- Run this in query window 1
BEGIN TRANSACTION;
UPDATE  dbo.IsolationTests 
SET     ColA = 'Y';
--Simulate having some intensive processing here with a wait 
WAITFOR DELAY '00:00:10';
ROLLBACK;
