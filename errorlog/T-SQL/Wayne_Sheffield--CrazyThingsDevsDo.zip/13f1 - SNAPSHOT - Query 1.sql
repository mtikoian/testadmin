USE IsolationLevelTest;
GO
EXECUTE dbo.db_reset;
GO

-- SNAPSHOT
ALTER DATABASE IsolationLevelTest SET ALLOW_SNAPSHOT_ISOLATION ON;
GO


-- Run this in query window 1
SET TRANSACTION ISOLATION LEVEL SNAPSHOT;
BEGIN TRANSACTION; 
SELECT * FROM dbo.IsolationTests; 
WAITFOR DELAY '00:00:10';
SELECT * FROM dbo.IsolationTests; 
ROLLBACK;
