/*
From: http://explainextended.com/2009/10/14/constraints-and-the-optimizer-in-sql-server-unique/
*/

USE ConstraintsTest;
GO

/*
Differences between a PK and UNIQUE constraints
1. Only 1 PK allowed, up to 999 Unique constraints allowed.
2. Columns in PK don't allow null values; UQ columns do, but must maintain uniqueness (NULL counts as a distinct value).


Optimizations that SQL Server can make:
1. If there is a UNIQUE column in the SELECT clause, DISTINCT is ignored
2. If there is a sort on a UNIQUE column, all subsequent sort expressions are ignored
*/


/*
Difference between using DISTINCT on a UNIQUE column vs. non-UNIQUE column.
*/
SET STATISTICS IO,TIME ON;
GO

RAISERROR('DISTINCT on a UNIQUE column', 10, 1) WITH NOWAIT;
SELECT  SUM(LEN(name)) AS usum
FROM    (
        SELECT  DISTINCT uval, name
        FROM    dbo.t_foreign
        ) q;

RAISERROR('




', 10, 1) WITH NOWAIT;
RAISERROR('DISTINCT on a non-UNIQUE column', 10, 1) WITH NOWAIT;
SELECT  SUM(LEN(name)) AS usum
FROM    (
        SELECT  DISTINCT dval, name
        FROM    dbo.t_foreign
        ) q;

SET STATISTICS IO,TIME OFF;
GO









/*
Difference between using ORDER BY on a UNIQUE column vs. non-UNIQUE column.
*/
SET STATISTICS IO,TIME ON;
GO
SELECT  TOP 10 *
FROM    dbo.t_foreign
ORDER BY uval, dval;

SELECT  TOP 10 *
FROM    dbo.t_foreign
ORDER BY dval, uval;

SET STATISTICS IO,TIME OFF;
GO
