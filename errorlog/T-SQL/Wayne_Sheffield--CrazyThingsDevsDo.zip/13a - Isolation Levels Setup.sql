USE master;
GO
IF DB_ID('IsolationLevelTest') IS NOT NULL 
BEGIN
    ALTER DATABASE IsolationLevelTest SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
    DROP DATABASE IsolationLevelTest;
END;
CREATE DATABASE IsolationLevelTest;
GO
USE IsolationLevelTest;
GO

CREATE PROCEDURE dbo.db_reset AS
IF OBJECT_ID('dbo.IsolationTests','U') IS NOT NULL DROP TABLE dbo.IsolationTests;
CREATE TABLE dbo.IsolationTests (     
    Id      INTEGER IDENTITY,     
    ColA    CHAR(1));
INSERT INTO dbo.IsolationTests(ColA) 
SELECT 'A' UNION ALL 
SELECT 'A' UNION ALL 
SELECT 'A' UNION ALL 
SELECT 'A' UNION ALL 
SELECT 'A' UNION ALL 
SELECT 'A' UNION ALL 
SELECT 'A';

SELECT  *
FROM    dbo.IsolationTests;

IF EXISTS (SELECT 1 FROM sys.databases WHERE database_id = DB_ID('IsolationLevelTest') AND snapshot_isolation_state = 1)
    ALTER DATABASE IsolationLevelTest SET ALLOW_SNAPSHOT_ISOLATION OFF;
GO
EXECUTE dbo.db_reset;
GO

