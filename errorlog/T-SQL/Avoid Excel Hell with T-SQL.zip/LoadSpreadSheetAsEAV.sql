DROP PROCEDURE  DBO.LoadSpreadSheetAsEAV;
GO
 CREATE PROCEDURE dbo.LoadSpreadSheetAsEAV 
/**********************************************************************************************************************
 Purpose:
 Load and "unpivot" virtually any spreadsheet that has a 3 row header where the 3rd row is the row with actual column
 names even if the column names are repeated and the first two rows form some type of temporal or other partition.
 The results are stored in a Global Temporary table (##FinalTable) that should be consumed and dropped as soon as 
 possible to prevent concurrency issues.

 ===============
 IMPORTANT NOTE:
 ===============
 This is NOT a complete solution.  It is ONLY meant to be a demonstrable proof-of-principle to demonstrate how even
 complex spreadsheets can be imported without changing code. There are things missing like a parameter for the sheet
 name (hard coded to [Sheet1$]), considerations for concurrent runs (sp_getapplock), an auto-sensing "Header Row 0"
 detector (hardccoded at 3), and contains virtually no error checking or TRY/CATCH.

 Revision History:
 Rev 00 - 01 Apr 2017 - Jeff Moden
        - Rewrite to combine 2 stored procedures into 1 because SQL Server 2012 changed the rules on nested calls
          where Global Temp tables were used. It was a great "April Fools" present.
**********************************************************************************************************************/
--===== Parameters for this procedure
         @SSFullPath VARCHAR(1000) --Full path and file name of the spreadsheet source.  May be a UNC.
        ,@pSheetName VARCHAR(128) = 'Sheet1$'
AS
--=====================================================================================================================
--      Prevent conncurrent runs because we use Global Temp Tables
--=====================================================================================================================
--===== Error variables
DECLARE  @ProcName      SYSNAME
        ,@InfoMessage   NVARCHAR(1000)
;
 SELECT  @ProcName      = OBJECT_NAME(@@PROCID)
        ,@InfoMessage   = 'Presets'
;
  BEGIN TRY
  BEGIN TRANSACTION
;
--===== Get the lock on this proc or wait 60 seconds.
     -- Ref: https://docs.microsoft.com/en-us/sql/relational-databases/system-stored-procedures/sp-getapplock-transact-sql
     -- Ref: http://rusanu.com/2015/03/06/the-cost-of-a-transactions-that-has-only-applocks/
   EXEC sp_getapplock 
             @Resource      = 'LoadSpreadSheetAsEAV'
            ,@LockMode      = 'Exclusive'
            ,@LockTimeout   = '60000' --60 Seconds
;
--=====================================================================================================================
--      Presets
--=====================================================================================================================
--===== Environmental presets
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

--===== Local variables
DECLARE  @SQL           VARCHAR(MAX)
;
--===== Conditionally drop the temp tables if they exist.
     IF OBJECT_ID('tempdb..##SSRawData'  ,'U') IS NOT NULL DROP TABLE ##SSRawData;
     IF OBJECT_ID('tempdb..#MappingTable','U') IS NOT NULL DROP TABLE #MappingTable;
     IF OBJECT_ID('tempdb..##FinalTable' ,'U') IS NOT NULL DROP TABLE ##FinalTable;

--=====================================================================================================================
--      Check for SQL and DOS Injection
--=====================================================================================================================
 SELECT @InfoMessage = 'Pre-Check'
;
--===== If any characters other than those explicitly allowed exist, 
     -- return with no error or other clues to a potential attacker.
     IF @SSFullPath+@pSheetName LIKE '%[^_-__\:.a-zA-Z 0-9$]%' ESCAPE '_'
  BEGIN 
             IF @@TRANCOUNT <> 0 ROLLBACK;
         RETURN;
    END
;
--=====================================================================================================================
--      STEP1: IMPORT THE WHOLE SPREADSHEET.
--=====================================================================================================================
 SELECT @InfoMessage = 'STEP1: IMPORT THE WHOLE SPREADSHEET.'
;
--===== Create the dynamic SQL to create and load the Global Temp Table from the spreadsheet on the fly.
     -- Had to use SELECT/INTO because we don't know the column names yet and had to use dynamic SQL because
     -- OPENROWSET won't take variables. That leads us to a Global Temp table.
SELECT @SQL = REPLACE(REPLACE(REPLACE('
 SELECT *
        ,RowNum = ROW_NUMBER() OVER (ORDER BY (SELECT NULL))-3 --LOOK! Here"s the RowNum-3 Offset 
   INTO ##SSRawData
   FROM OPENROWSET
            ( 
             "Microsoft.ACE.OLEDB.12.0"
            ,"Excel 12.0;
              Database=<<@SSFullPath>>;
              HDR=No;
              IMEX=1;"
            ,"SELECT * FROM [<<@pSheetName>>];" 
            )
 OPTION (MAXDOP 1)
;'      ,'"','''')
        ,'<<@SSFullPath>>',@SSFullPath)
        ,'<<@pSheetName>>',@pSheetName)
;
--===== Execute the dynamic SQL to create and load the Global Temp Table from the spreadsheet on the fly.
   EXEC (@SQL)
;
--=====================================================================================================================
--      STEP 2: CREATE AND PREPOPULATE THE MAPPING TABLE
--      Create a table to relate the actual "Fn%" column names to the column names from the
--      spreadsheet.  As a reminder, the column names from this spreadsheet will be found on
--      on ROWNUM=0 in the ##SSRawData table.
--=====================================================================================================================
 SELECT @InfoMessage = 'STEP 2: CREATE AND PREPOPULATE THE MAPPING TABLE.'
;
--===== Create a temp table for the spreadsheet (mapping data) column names and related dates.
 CREATE TABLE #MappingTable
        (
         ColID          INT             PRIMARY KEY CLUSTERED --From tempdb.sys.columns.
        ,ColName        SYSNAME         NOT NULL --"Fn%" column name in the ##SSRawData table.
        ,SSColName      SYSNAME         NOT NULL --Column Name from row "0".
        ,SSGroupName    VARCHAR(200)    NULL     --Group Name created from row -2 and -1.
        )
;
--===== Reset the dynamic SQL variable so we can use a Pseudo-Cursor to over-load it.
 SELECT @SQL = NULL
;
--===== This creates the list of SELECTs that will go into a CROSS APPLY, which is used to unpivot the "Fn%" and 
     -- SSColName column names regardless of how many there may be.
     -- Note that we don't care about the order because we have the column ID.
 SELECT @SQL = ISNULL(@SQL +' UNION ALL','') 
             + REPLACE(REPLACE(REPLACE('
 SELECT <<column_id>>, <<ColName>>, <<SSColName>>'
               ,'<<column_id>>',CONVERT(VARCHAR(10),column_id))
               ,'<<ColName>>'  ,QUOTENAME(name,''''))
               ,'<<SSColName>>',name)
   FROM tempdb.sys.columns col
   WHERE object_id = OBJECT_ID('tempdb..##SSRawData','U')
     AND name LIKE 'F[0-9]%'
;
--===== This adds the rest of the code before and after the SELECT list for the CROSS APPLY.
 SELECT @SQL = '
 SELECT  ca.ColID
        ,ca.ColName
        ,ca.SSColName
   FROM ##SSRawData
  CROSS APPLY
        ('
       + @SQL 
       + '
        )ca(ColID,ColName,SSColName)
  WHERE RowNum = 0
;'
;
--===== Execute the dynamic SQL to populate the mapping data table with related real and spreadsheet column names 
     -- regardless of how many there are.
 INSERT INTO #MappingTable
        (ColID, ColName, SSColName)
   EXEC (@SQL)
;
--=====================================================================================================================
--      STEP 3: GET THE MONTHLY PARTITION NAMES
--      Find the grouped headers and assign them to the related columns in the mapping data table.
--      Yeah... we have to do this with dynamic SQL again in case someone expands the spreadsheet.
--      Again, the CTE does a DYNAMIC UNPIVOT.
--=====================================================================================================================
 SELECT @InfoMessage = 'STEP 3: GET THE MONTHLY PARTITION NAMES.'
;
--===== Clear the dynamic variable
 SELECT @SQL = NULL
;
--===== This creates the list of SELECTs that will go into the CROSS APPLY, which is used to unpivot the column names
     -- regardless of how many there may be.
     -- "h1" is an alias for "header row 1" (row -2 in this case).
     -- "h2" is an alias for "header row 2" (row -1 in this case)
 SELECT @SQL = ISNULL(@SQL+' UNION ALL','') 
             + REPLACE(REPLACE('
        SELECT <<qColName>>, h1.<<ColName>>, h2.<<ColName>>'
               ,'<<qColName>>',QUOTENAME(ColName,''''))
               ,'<<ColName>>' ,ColName)
   FROM #MappingTable col
   WHERE ColName LIKE 'F[0-9]%'
;
--===== Add the SQL that goes in before and after the CROSS APPLY.
 SELECT @SQL = REPLACE('
--===== Create and preset a local variable in preparation for a Quirky Update
DECLARE  @PrevSSGroupName1 VARCHAR(200)
        ,@PrevSSGroupName2 VARCHAR(200)
;
 SELECT  @PrevSSGroupName1 = "Common"
        ,@PrevSSGroupName2 = "Common"
;
--===== Use a Quirky Update to do a "data smear" to fill in the SSGroupName for columns that
     -- are missing group names.
     -- REF: http://www.sqlservercentral.com/articles/T-SQL/68467/
WITH
cteGroups AS
(
 SELECT  ca.ColName
        ,ca.SSGroupName1
        ,ca.SSGroupName2
   FROM ##SSRawData h1
   JOIN ##SSRawData h2 ON h1.RowNum + 1 = h2.RowNum --Two rows make up the group name
    AND h1.RowNum = -2 --Two rows make up the group name
  CROSS APPLY ('
      + @SQL
      + '
              )ca(ColName,SSGroupName1,SSGroupName2)
)
 UPDATE meta
    SET  @PrevSSGroupName1 = 
            CASE
            WHEN @PrevSSGroupName1 = ISNULL(grp.SSGroupName1,"Common")
            THEN @PrevSSGroupName1
            ELSE ISNULL(grp.SSGroupName1,@PrevSSGroupName1)
            END
        ,@PrevSSGroupName2 = 
            CASE
            WHEN @PrevSSGroupName2 = ISNULL(grp.SSGroupName2,"Common")
            THEN @PrevSSGroupName2
            ELSE ISNULL(grp.SSGroupName2,@PrevSSGroupName2)
            END
        ,SSGroupName = 
            CASE
            WHEN @PrevSSGroupName1 = @PrevSSGroupName2 THEN @PrevSSGroupName1
            ELSE @PrevSSGroupName1 + " " + @PrevSSGroupName2
            END
   FROM #MappingTable meta WITH(INDEX(1),TABLOCKX)
   JOIN cteGroups grp
     ON meta.ColName = grp.ColName 
 OPTION (MAXDOP 1)
;'
        ,'"','''') --End of REPLACE
;
--===== Execute the dynamic SQL to expresss the group names over the related columns 
     -- in the mapping data.
   EXEC (@SQL)
;
--=====================================================================================================================
--      STEP 4: UNPIVOT THE DATA
--      At this point, we have all the mapping data that we need and SQL Server now "knows" what this spreadsheet table
--      looks like for headers, group headers, etc.  Let's use that information to unpivot this spreadsheet and put it
--      into an almost normal form known as an EAV. Of course, we could normalize the Name, ID, and Status, but you've
--      gotta have some of the fun!  ;-)  At this point, it's trivial anyway.
--=====================================================================================================================
 SELECT @InfoMessage = 'STEP 4: UNPIVOT THE DATA'
;
--===== Create another dynamic SQL variable to hold the "Common" information columns.
DECLARE @SQLSelect VARCHAR(MAX)
;
--===== Clear the original dynamic variable
 SELECT @SQL = NULL
;
--===== This creates the list of 'Common' columns that will go into the SELECT.
     -- Note that it is necessary to leave a trailing comma here.
 SELECT @SQLSelect = ISNULL(@SQLSelect,'')
             + REPLACE(REPLACE('
        <<qSSColName>> = detail.<<ColName>>,'
               ,'<<qSSColName>>',QUOTENAME(SSColName))
               ,'<<ColName>>'   ,ColName)
   FROM #MappingTable col
   WHERE ColName LIKE 'F[0-9]%'
     AND SSGroupName = 'Common'
;
--===== This creates the list of SELECTs that will go into the CROSS APPLY, which is used to unpivot the column names
     -- regardless of how many there may be.
 SELECT @SQL = ISNULL(@SQL+' UNION ALL','') 
             + REPLACE(REPLACE(REPLACE('
        SELECT <<qSSGroupName>>,<<qSSColName>>,detail.<<ColName>>'
               ,'<<qSSGroupName>>',QUOTENAME(SSGroupName,''''))
               ,'<<qSSColName>>',QUOTENAME(SSColName,''''))
               ,'<<ColName>>'   ,ColName)
   FROM #MappingTable col
   WHERE ColName LIKE 'F[0-9]%'
     AND SSGroupName <> 'Common'
;
--===== Put all the SQL together
 SELECT @SQL = '
 SELECT '
      + @SQLSelect
      + '
        unpvt.*
   INTO ##FinalTable
   FROM ##SSRawData detail
  CROSS APPLY
        ('
      + @SQL
      + '
        ) unpvt (SSGroupName,ColName,Value)
  WHERE RowNum > 0
    AND detail.F1 > ''''
;'
;
--===== Create the final result set.  Final output is in the ##FinalTable table
   EXEC (@SQL)
;
--=====================================================================================================================
--      Housekeeping
--=====================================================================================================================
 SELECT @InfoMessage = 'Housekeeping'
;
--===== Drop the Global Temp table that we no longer need.
     IF OBJECT_ID('tempdb..##SSRawData'  ,'U') IS NOT NULL DROP TABLE ##SSRawData
;
 COMMIT
;
    END TRY
--=====================================================================================================================
--      Error Handling 
--=====================================================================================================================
  BEGIN CATCH
        --===== Create a more informative error message
        DECLARE @ErrorMessage  NVARCHAR(4000),
                @ErrorSeverity INT;
         SELECT @ErrorMessage = 
                    '[' 
                    + '('
                        + ISNULL(CONVERT(VARCHAR(10),ERROR_NUMBER()),'?') + ':'
                        + ISNULL(CONVERT(VARCHAR(10),ERROR_SEVERITY()), '?') + ':'
                        + ISNULL(CONVERT(VARCHAR(10),ERROR_STATE()), '?') 
                    + ') at ' + COALESCE(ERROR_PROCEDURE() ,@ProcName, '(no proc)') 
                    + '(' + ISNULL(CONVERT(VARCHAR(10),ERROR_LINE()) ,'?')  + '). '
                    + ISNULL(ERROR_MESSAGE(),'(no message)') 
                    + ISNULL(' (' + @InfoMessage + ')','')
                    + ']',
                @ErrorSeverity = ERROR_SEVERITY()
        ;
        --===== If there are any open transactions open, do a rollback
             IF @@TRANCOUNT <> 0 ROLLBACK
        ;
        --======= Rethrow the error and exit the proc
        RAISERROR ('ERROR: %s: %s',@ErrorSeverity,1,@ProcName,@ErrorMessage) WITH NOWAIT;
        RETURN;
   END CATCH
;
