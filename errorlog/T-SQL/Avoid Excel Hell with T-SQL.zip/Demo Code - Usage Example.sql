   --DROP TABLE ##FinalTable;

    EXEC dbo.LoadSpreadSheetAsEAV 'C:\ImportExcel\Sample Spreadsheet for Import 20140301.xlsx'
  SELECT * FROM ##FinalTable;

    EXEC dbo.LoadSpreadSheetAsEAV 'C:\ImportExcel\Sample Spreadsheet for Import 20140401.xlsx'
  SELECT * FROM ##FinalTable;

    EXEC dbo.LoadSpreadSheetAsEAV 'C:\ImportExcel\Sample Spreadsheet for Import 20141201.xlsx'
  SELECT * FROM ##FinalTable;

    EXEC dbo.LoadSpreadSheetAsEAV 'C:\ImportExcel\Sample Spreadsheet for Import 20150101.xlsx'
  SELECT * FROM ##FinalTable;

    EXEC dbo.LoadSpreadSheetAsEAV 'C:\ImportExcel\Sample Spreadsheet for Import 20150102.xlsx'
  SELECT * FROM ##FinalTable;

    EXEC dbo.LoadSpreadSheetAsEAV 'C:\ImportExcel\Totally Different.xlsx'
  SELECT * FROM ##FinalTable;

    EXEC dbo.LoadSpreadSheetAsEAV 'C:\ImportExcel\Sample Spreadsheet for Import 20140301 with Named Sheet.xlsx'
                                  ,'Classes$'
  SELECT * FROM ##FinalTable;

    EXEC dbo.LoadSpreadSheetAsEAV 'C:\ImportExcel\Sample Spreadsheet for Import 20140301 with Named Sheet.xlsx'
                                  ,'Totally Different$'
  SELECT * FROM ##FinalTable;

   DROP TABLE ##FinalTable;


