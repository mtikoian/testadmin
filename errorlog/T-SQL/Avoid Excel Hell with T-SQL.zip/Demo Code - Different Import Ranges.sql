--=====================================================================================================================
--      Import the Just the Data and Attribute headers with fixed range
--=====================================================================================================================
--===== Conditionally drop the temp table if it exists.
     IF OBJECT_ID('tempdb..##SSData','U') IS NOT NULL
        DROP TABLE ##SSData
;
 SELECT *
        ,RowNum = ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) 
   INTO ##SSData
   FROM OPENROWSET
            ( 
             'Microsoft.ACE.OLEDB.12.0'
            ,'Excel 12.0;
              Database=C:\ImportExcel\Sample Spreadsheet for Import 20140301.xlsx;
              HDR=Yes;
              IMEX=1;'
            ,'SELECT * FROM [Sheet1$B5:P9];'  --< LOOK!
            )
 OPTION (MAXDOP 1)
;
 SELECT * FROM ##SSData
;
GO
--=====================================================================================================================
--      Import the Just a Named Range.  Again, fixed range.
--=====================================================================================================================
--===== Conditionally drop the temp table if it exists.
     IF OBJECT_ID('tempdb..##SSData','U') IS NOT NULL
        DROP TABLE ##SSData
;
 SELECT *
        ,RowNum = ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) 
   INTO ##SSData
   FROM OPENROWSET
            ( 
             'Microsoft.ACE.OLEDB.12.0'
            ,'Excel 12.0;
              Database=C:\ImportExcel\Sample Spreadsheet for Import 20140301.xlsx;
              HDR=Yes;
              IMEX=1;'
            ,'SELECT * FROM [JustData];' --< LOOK!
            )
 OPTION (MAXDOP 1)
;
 SELECT * FROM ##SSData
;
GO
--=====================================================================================================================
--      Import the Just the Data and Attribute headers that can grow but fixed top left (origin).
--=====================================================================================================================
--===== Conditionally drop the temp table if it exists.
     IF OBJECT_ID('tempdb..##SSData','U') IS NOT NULL
        DROP TABLE ##SSData
;
 SELECT *
        ,RowNum = ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) 
   INTO ##SSData
   FROM OPENROWSET
            ( 
             'Microsoft.ACE.OLEDB.12.0'
            ,'Excel 12.0;
              Database=C:\ImportExcel\Sample Spreadsheet for Import 20140301.xlsx;
              HDR=Yes;
              IMEX=1;' --< LOOK!
            ,'SELECT * FROM [Sheet1$B5:IV];'  --< LOOK!
            )
 OPTION (MAXDOP 1)
;
 SELECT * FROM ##SSData
;
GO
--=====================================================================================================================
--      Import the WHOLE Spreadsheet. Totally flexible
--=====================================================================================================================
--===== Conditionally drop the temp table if it exists.
     IF OBJECT_ID('tempdb..##SSData','U') IS NOT NULL
        DROP TABLE ##SSData
;
 SELECT *
        ,RowNum = ROW_NUMBER() OVER (ORDER BY (SELECT NULL))-3 --LOOK! Here's the RowNum-3 Offset 
   INTO ##SSData
   FROM OPENROWSET
            ( 
             'Microsoft.ACE.OLEDB.12.0'
            ,'Excel 12.0;
              Database=C:\ImportExcel\Sample Spreadsheet for Import 20140301.xlsx;
              HDR=No;
              IMEX=1;'
            ,'SELECT * FROM [Sheet1$];' --< LOOK!
            )
 OPTION (MAXDOP 1)
;
 SELECT * FROM ##SSData
;
GO
