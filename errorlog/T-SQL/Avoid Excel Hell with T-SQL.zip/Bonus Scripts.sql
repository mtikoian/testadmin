--===== This variable would be a parameter for a stored procedure
DECLARE @pSSFileName VARCHAR(1000);
 SELECT @pSSFileName = 'C:\ImportExcel\Sample Spreadsheet for Import 20140301 with Named Sheet.xlsx'
;
--=====================================================================================================================
--      Presets
--=====================================================================================================================
--===== If the spreadsheet sheet name table already exists, drop it.
     IF OBJECT_ID('tempdb..#SheetName','U') IS NOT NULL
   DROP TABLE #SheetName
;
--===== Create the spreadsheet sheet name table
 CREATE TABLE #SheetName
        (
         RowNum         INT             IDENTITY(1,1) PRIMARY KEY CLUSTERED
        ,table_cat      SYSNAME         NULL     --Always NULL for spreadsheets
        ,table_schem    SYSNAME         NULL     --Always NULL for spreadsheets
        ,table_name     SYSNAME         NOT NULL -- Never NULL
        ,table_type     VARCHAR(32)     NULL     --Always NULL for spreadsheets
        ,remarks        VARCHAR(254)    NULL     --Always NULL for spreadsheets
        ,TableType AS CASE WHEN table_name LIKE '%$%' THEN 'Sheet' ELSE 'Range' END PERSISTED
        ,TableName AS REPLACE(table_name,'''','') PERSISTED
        )
;
--===== Local variables
DECLARE @SQL VARCHAR(8000)
;
--=====================================================================================================================
--      Open the given spreadsheet file as a linked server
--=====================================================================================================================
--===== If the linked server for Excel files already exists, drop it.
     IF EXISTS (SELECT * FROM sys.servers WHERE name = 'ExcelFile')
   EXEC sp_dropserver 'ExcelFile', 'droplogins'
;
--===== Create the command that will open the given spreadsheet file as a linked server.
 SELECT @SQL = REPLACE(REPLACE('
   EXEC sp_addlinkedserver 
             @server    = "ExcelFile"
            ,@srvproduct= "ACE 12.0"
            ,@provider  = "Microsoft.ACE.OLEDB.12.0"
            ,@datasrc   = "<<@pSSFileName>>"
            ,@provstr   = "Excel 12.0;"
'           -- Other end of REPLACEs
            ,'"','''')
            ,'<<@pSSFileName>>',@pSSFileName)
;
--===== Create the linked server using the dynamic SQL
   EXEC (@SQL)
;            
--===== Create the necessary login for the linked server (Always just 'Admin" for ACE)
   EXEC sp_addlinkedsrvlogin 
             @rmtsrvname    = 'ExcelFile'
            ,@rmtuser       = 'Admin'
;
--=====================================================================================================================
--      Return all of the sheet and range names
--=====================================================================================================================
--===== Load the meta-data from the given spreadsheet file (linked server).
 INSERT INTO #SheetName
   EXEC sp_tables_ex 'ExcelFile'
;
--===== Let's see the tables names in the sheet.
     -- Names with $ signs are sheets.
     -- Other names are "range names"
 SELECT RowNum, TableType, TableName
   FROM #SheetName
;
--=====================================================================================================================
--      Bonus-bonus code. Find out which spreadsheets probably don't need to be loaded by counting columns!
--=====================================================================================================================
--===== Just in case you ever need it, CHECK THIS OUT!
   EXEC sp_columns_ex ExcelFile
;
--===== If the spreadsheet column metat-data table exists, drop it.
     IF OBJECT_ID('tempdb..#SpreadSheetColumnInfo','U') IS NOT NULL
   DROP TABLE #SpreadSheetColumnInfo
;
--===== Lets determine the spreadsheets and ranges that have more than one column
 CREATE TABLE #SpreadSheetColumnInfo
        (
         TABLE_CAT          SYSNAME         NULL
        ,TABLE_SCHEM        SYSNAME         NULL
        ,TABLE_NAME         SYSNAME         NULL
        ,COLUMN_NAME        SYSNAME         NULL
        ,DATA_TYPE          SMALLINT        NULL
        ,TYPE_NAME          VARCHAR(13)     NULL
        ,COLUMN_SIZE        INT             NULL
        ,BUFFER_LENGTH      INT             NULL
        ,DECIMAL_DIGITS     SMALLINT        NULL
        ,NUM_PREC_RADIX     SMALLINT        NULL
        ,NULLABLE           SMALLINT        NULL
        ,REMARKS            VARCHAR(254)    NULL
        ,COLUMN_DEF         VARCHAR(254)    NULL
        ,SQL_DATA_TYPE      SMALLINT        NULL
        ,SQL_DATETIME_SUB   SMALLINT        NULL
        ,CHAR_OCTET_LENGTH  INT             NULL
        ,ORDINAL_POSITION   INT             NULL
        ,IS_NULLABLE        VARCHAR(254)    NULL
        ,SS_DATA_TYPE       TINYINT         NULL
        ,TableType AS CASE WHEN table_name LIKE '%$%' THEN 'Sheet' ELSE 'Range' END PERSISTED
        ,TableName AS REPLACE(table_name,'''','') PERSISTED
        )
;
--===== Load the table with the spreadsheet column meta-data.
 INSERT INTO #SpreadSheetColumnInfo
   EXEC sp_columns_ex ExcelFile
;
--===== Return the spreadsheet and range names along with a column count.
 SELECT  TableName
        ,TableType
        ,ColumnCount = COUNT(*)
   FROM #SpreadSheetColumnInfo
  GROUP BY TableName,TableType
;
--=====================================================================================================================
--      Housekeeping.  Drop the linked server we used.
--=====================================================================================================================
   EXEC sp_dropserver 'ExcelFile', 'droplogins'
;
--=====================================================================================================================
--      Bonus-bonus-bonus code. What are the names of the spreadsheets in a given directory?
--=====================================================================================================================
--===== If the file related tables already exist, drop them
     IF OBJECT_ID('tempdb..#DirInfo' ,'U') IS NOT NULL DROP TABLE #DirInfo;
     IF OBJECT_ID('tempdb..#FileName','U') IS NOT NULL DROP TABLE #FileName;

--===== Create the directory information table
 CREATE TABLE #DirInfo
        (
        DirObjectName VARCHAR(500)
        ,Depth  TINYINT
        ,IsFile TINYINT
        )
;
--===== Get the directory information
 INSERT INTO #DirInfo
   EXEC xp_dirtree 'C:\ImportExcel',1,1 --Only current level and list files. Doesn't take wild cards.
;
--===== Let's see what we have
 SELECT * FROM #DirInfo
;
--===== Create the table to hold the enumerated spreadsheet file names in name order
 CREATE TABLE #FileName
        (
         RowNum     INT IDENTITY(1,1)
        ,FileName   VARCHAR(500) NOT NULL
        )
;
--===== Populate the file name table with only spreadsheet file names
 INSERT INTO #FileName
 SELECT FileName = DirObjectName
   FROM #DirInfo
  WHERE IsFile = 1
    AND DirObjectName LIKE '%.xls_'
  ORDER BY FileName
;
--===== Let's see what we've got.
 SELECT * FROM #FileName
  ORDER BY RowNum
;
