--===== Parameters for this procedure
DECLARE @SSFullPath VARCHAR(1000); --Full path and file name of the spreadsheet source.  May be a UNC.
 SELECT @SSFullPath = 'C:\ImportExcel\Sample Spreadsheet for Import 20140301.xlsx'
;
--=====================================================================================================================
--      Presets
--=====================================================================================================================
--===== Environmental presets
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

--===== Local variables
DECLARE @SQL VARCHAR(MAX)
;
--===== Conditionally drop the temp tables if they exist.
     IF OBJECT_ID('tempdb..##SSRawData'  ,'U') IS NOT NULL DROP TABLE ##SSRawData;
     IF OBJECT_ID('tempdb..#MappingTable','U') IS NOT NULL DROP TABLE #MappingTable;
     IF OBJECT_ID('tempdb..##FinalTable' ,'U') IS NOT NULL DROP TABLE ##FinalTable;

PRINT '
--=====================================================================================================================
--      STEP1: IMPORT THE WHOLE SPREADSHEET.
--=====================================================================================================================
';
--===== Create the dynamic SQL to create and load the Global Temp Table from the spreadsheet on the fly.
SELECT @SQL = REPLACE(REPLACE('
 SELECT *
        ,RowNum = ROW_NUMBER() OVER (ORDER BY (SELECT NULL))-3 --LOOK! Here"s the RowNum-3 Offset 
   INTO ##SSRawData
   FROM OPENROWSET
            ( 
             "Microsoft.ACE.OLEDB.12.0"
            ,"Excel 12.0;
              Database=<<@SSFullPath>>;
              HDR=No;
              IMEX=1;"
            ,"SELECT * FROM [Sheet1$];" --< LOOK! Could make this a parameter!
            )
 OPTION (MAXDOP 1)
;'      ,'"','''')
        ,'<<@SSFullPath>>',@SSFullPath)
;
  PRINT @SQL
;
--===== Execute the dynamic SQL to create and load the Global Temp Table from the spreadsheet on the fly.
   EXEC (@SQL)
;
 SELECT '##SSRawData ------------------------------------------------------------------------------------------------';
 SELECT * FROM ##SSRawData
;
PRINT '
--=====================================================================================================================
--      STEP 2: CREATE AND PREPOPULATE THE MAPPING TABLE
--      Create a table to relate the actual "Fn%" column names to the column names from the
--      spreadsheet.  As a reminder, the column names from this spreadsheet will be found on
--      on ROWNUM=0 in the ##SSRawData table.
--=====================================================================================================================
';
--===== Create a temp table for the spreadsheet (mapping data) column names and related dates.
 CREATE TABLE #MappingTable
        (
         ColID          INT             PRIMARY KEY CLUSTERED --From tempdb.sys.columns.
        ,ColName        SYSNAME         NOT NULL --"Fn%" column name in the ##SSRawData table.
        ,SSColName      SYSNAME         NOT NULL --Column Name from row "0".
        ,SSGroupName    VARCHAR(200)    NULL     --Group Name created from row -2 and -1.
        )
;
--===== Reset the dynamic SQL variable so we can use a Pseudo-Cursor to over-load it.
 SELECT @SQL = NULL
;
--===== This creates the list of SELECTs that will go into a CROSS APPLY, which is used to unpivot the "Fn%" and 
     -- SSColName column names regardless of how many there may be.
     -- Note that we don't care about the order because we have the column ID.
 SELECT @SQL = ISNULL(@SQL +' UNION ALL','') 
             + REPLACE(REPLACE(REPLACE('
 SELECT <<column_id>>, <<ColName>>, <<SSColName>>'
               ,'<<column_id>>',CONVERT(VARCHAR(10),column_id))
               ,'<<ColName>>'  ,QUOTENAME(name,''''))
               ,'<<SSColName>>',name)
   FROM tempdb.sys.columns col
   WHERE object_id = OBJECT_ID('tempdb..##SSRawData','U')
     AND name LIKE 'F[0-9]%'
;
  PRINT '===== CROSS APPLY code to upivot FN% and SSColName columns =====';
  PRINT @SQL
;
--===== This adds the rest of the code before and after the SELECT list for the CROSS APPLY.
 SELECT @SQL = '
 SELECT  ca.ColID
        ,ca.ColName
        ,ca.SSColName
   FROM ##SSRawData
  CROSS APPLY
        ('
       + @SQL 
       + '
        )ca(ColID,ColName,SSColName)
  WHERE RowNum = 0
;'
;
  PRINT '===== Full Code to upivot FN% and SSColName columns =====';
  PRINT @SQL
;
--===== Execute the dynamic SQL to populate the mapping data table with related real and spreadsheet column names 
     -- regardless of how many there are.
 INSERT INTO #MappingTable
        (ColID, ColName, SSColName)
   EXEC (@SQL)
;
 SELECT '#MappingTable before group names added ---------------------------------------------------------------------';
 SELECT * FROM #MappingTable
;
PRINT '
--=====================================================================================================================
--      STEP 3: GET THE MONTHLY PARTITION NAMES
--      Find the grouped headers and assign them to the related columns in the mapping data table.
--      Yeah... we have to do this with dynamic SQL again in case someone expands the spreadsheet.
--      Again, the CTE does a DYNAMIC UNPIVOT.
--=====================================================================================================================
';
--===== Clear the dynamic variable
 SELECT @SQL = NULL
;
--===== This creates the list of SELECTs that will go into the CROSS APPLY, which is used to unpivot the column names
     -- regardless of how many there may be.
     -- "h1" is an alias for "header row 1" (row -2 in this case).
     -- "h2" is an alias for "header row 2" (row -1 in this case)
 SELECT @SQL = ISNULL(@SQL+' UNION ALL','') 
             + REPLACE(REPLACE('
        SELECT <<qColName>>, h1.<<ColName>>, h2.<<ColName>>'
               ,'<<qColName>>',QUOTENAME(ColName,''''))
               ,'<<ColName>>' ,ColName)
   FROM #MappingTable col
   WHERE ColName LIKE 'F[0-9]%'
;
  PRINT '===== List of SELECTs for CROSS APPLY =====';
  PRINT @SQL
;
--===== Add the SQL that goes in before and after the CROSS APPLY.
 SELECT @SQL = REPLACE('
--===== Create and preset a local variable in preparation for a Quirky Update
DECLARE  @PrevSSGroupName1 VARCHAR(200)
        ,@PrevSSGroupName2 VARCHAR(200)
;
 SELECT  @PrevSSGroupName1 = "Common"
        ,@PrevSSGroupName2 = "Common"
;
--===== Use a Quirky Update to do a "data smear" to fill in the SSGroupName for columns that
     -- are missing group names.
     -- REF: http://www.sqlservercentral.com/articles/T-SQL/68467/
WITH
cteGroups AS
(
 SELECT  ca.ColName
        ,ca.SSGroupName1
        ,ca.SSGroupName2
   FROM ##SSRawData h1
   JOIN ##SSRawData h2 ON h1.RowNum + 1 = h2.RowNum --Two rows make up the group name
    AND h1.RowNum = -2 --Two rows make up the group name
  CROSS APPLY ('
      + @SQL
      + '
              )ca(ColName,SSGroupName1,SSGroupName2)
)
 UPDATE meta
    SET  @PrevSSGroupName1 = 
            CASE
            WHEN @PrevSSGroupName1 = ISNULL(grp.SSGroupName1,"Common")
            THEN @PrevSSGroupName1
            ELSE ISNULL(grp.SSGroupName1,@PrevSSGroupName1)
            END
        ,@PrevSSGroupName2 = 
            CASE
            WHEN @PrevSSGroupName2 = ISNULL(grp.SSGroupName2,"Common")
            THEN @PrevSSGroupName2
            ELSE ISNULL(grp.SSGroupName2,@PrevSSGroupName2)
            END
        ,SSGroupName = 
            CASE
            WHEN @PrevSSGroupName1 = @PrevSSGroupName2 THEN @PrevSSGroupName1
            ELSE @PrevSSGroupName1 + " " + @PrevSSGroupName2
            END
   FROM #MappingTable meta WITH(INDEX(1),TABLOCKX)
   JOIN cteGroups grp
     ON meta.ColName = grp.ColName 
 OPTION (MAXDOP 1)
;'
        ,'"','''') --End of REPLACE
;
  PRINT '===== CROSS APPLY added to the QUIRKY UPDATE code  =====';
  PRINT @SQL
;
--===== Execute the dynamic SQL to expresss the group names over the related columns 
     -- in the mapping data.
   EXEC (@SQL)
;
 SELECT '#MappingTable after group names added ---------------------------------------------------------------------';
 SELECT * FROM #MappingTable
;
  PRINT '
--=====================================================================================================================
--      STEP 4: UNPIVOT THE DATA
--      At this point, we have all the mapping data that we need and SQL Server now "knows" what this spreadsheet table
--      looks like for headers, group headers, etc.  Let''s use that information to unpivot this spreadsheet and put it
--      into an denormalized form known as an EAV. Of course, we could normalize the Name, ID, and Status, but you''ve
--      gotta have some of the fun!  ;-)  At this point, it''s trivial anyway.
--=====================================================================================================================
';
--===== Create another dynamic SQL variable to hold the "Common" information columns.
DECLARE @SQLSelect VARCHAR(MAX)
;
--===== Clear the original dynamic variable
 SELECT @SQL = NULL
;
--===== This creates the list of 'Common' columns that will go into the SELECT.
     -- Note that it is necessary to leave a trailing comma here.
 SELECT @SQLSelect = ISNULL(@SQLSelect,'')
             + REPLACE(REPLACE('
        <<qSSColName>> = detail.<<ColName>>,'
               ,'<<qSSColName>>',QUOTENAME(SSColName))
               ,'<<ColName>>'   ,ColName)
   FROM #MappingTable col
   WHERE ColName LIKE 'F[0-9]%'
     AND SSGroupName = 'Common'
;
  PRINT '===== Code to get the common columns (@SQLSelect)  =====';
  PRINT @SQLSelect
;
--===== This creates the list of SELECTs that will go into the CROSS APPLY, which is used to unpivot the column names
     -- and data regardless of how many there may be.
 SELECT @SQL = ISNULL(@SQL+' UNION ALL','') 
             + REPLACE(REPLACE(REPLACE('
        SELECT <<qSSGroupName>>,<<qSSColName>>,detail.<<ColName>>'
               ,'<<qSSGroupName>>',QUOTENAME(SSGroupName,''''))
               ,'<<qSSColName>>',QUOTENAME(SSColName,''''))
               ,'<<ColName>>'   ,ColName)
   FROM #MappingTable col
   WHERE ColName LIKE 'F[0-9]%'
     AND SSGroupName <> 'Common'
;
  PRINT '===== Code to create the CROSS APPLY to unpivot (@SQL)  =====';
  PRINT @SQL
;
--===== Put all the SQL together
 SELECT @SQL = '
 SELECT '
      + @SQLSelect
      + '
        unpvt.*
   INTO ##FinalTable
   FROM ##SSRawData detail
  CROSS APPLY
        ('
      + @SQL
      + '
        ) unpvt (SSGroupName,ColName,Value)
  WHERE RowNum > 0
    AND detail.F1 > ''''
;'
;
  PRINT '===== The final SQL to create/populate ##FinalTable =====';
  PRINT @SQL
;
--===== Create the final result set.  Final output is in the ##FinalTable table
   EXEC (@SQL)
;
 SELECT '##FinalTable as an EAV -------------------------------------------------------------------------------------';
 SELECT * FROM ##FinalTable
;