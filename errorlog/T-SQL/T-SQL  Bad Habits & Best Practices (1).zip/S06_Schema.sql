USE AdventureWorks2014;
GO

CREATE USER PVD1 WITHOUT LOGIN WITH DEFAULT_SCHEMA = Sales;
GO

CREATE USER PVD2 WITHOUT LOGIN WITH DEFAULT_SCHEMA = Person;
GO

CREATE TABLE dbo.AnErrorLog(id INT);
GO
GRANT SELECT ON dbo.AnErrorLog TO PVD1, PVD2;
GO

DBCC FREEPROCCACHE;
GO

/*
-- run this batch once, then add dbo. prefix
*/

EXECUTE AS USER = N'PVD1';
GO
-- add dbo. prefix and run again:
SELECT id FROM /*dbo.*/AnErrorLog;
GO
REVERT;
GO
EXECUTE AS USER = N'PVD2';
GO
-- add dbo. prefix and run again:
SELECT id FROM /*dbo.*/AnErrorLog;
GO
REVERT;
GO



-- now check the plan cache; how many plans?

SELECT t.[text], p.size_in_bytes, p.usecounts, 
  [schema_id] = pa.value, 
  [schema] = SCHEMA_NAME(CONVERT(INT, pa.[value]))
FROM sys.dm_exec_cached_plans AS p
CROSS APPLY 
  sys.dm_exec_sql_text(p.plan_handle) AS t
CROSS APPLY 
  sys.dm_exec_plan_attributes(p.plan_handle) AS pa
WHERE t.[text] LIKE N'%AnError'+'Log%' 
AND pa.attribute = N'user_id';

GO
DROP TABLE dbo.AnErrorLog;
DROP USER PVD1;
DROP USER PVD2;