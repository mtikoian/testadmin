USE AdventureWorks2014;
GO

-- laziness is not an excuse! drag columns node

-- let's say I want to print address labels
-- do I need all columns?

-- note huge differences and also spatial results
-- this could be XML, VARBINARY(MAX), etc.

SELECT *
FROM Person.[Address] 
WHERE AddressLine1 LIKE '1% Napa%';

SELECT AddressID, AddressLine1, AddressLine2, 
  City, StateProvinceID, PostalCode
FROM Person.[Address] 
WHERE AddressLine1 LIKE '1% Napa%';




-- schema stability 
-- view does not reflect changed table

USE tempdb;
GO
CREATE TABLE dbo.x(a INT, b INT);
GO
INSERT dbo.x(a,b) VALUES(1,2);
GO

CREATE VIEW dbo.v_x
AS
  SELECT * FROM dbo.x;
GO

-- view will not be updated to see these changes:
EXEC sys.sp_rename N'dbo.x.b', N'c', N'COLUMN';
ALTER TABLE dbo.x ADD b DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP;
GO

-- view still shows wrong data
SELECT * FROM dbo.v_x;
GO

EXEC sys.sp_refreshview N'dbo.v_x';
GO

-- now view is correct
SELECT * FROM dbo.v_x;
GO

DROP VIEW dbo.v_x;
DROP TABLE dbo.x;