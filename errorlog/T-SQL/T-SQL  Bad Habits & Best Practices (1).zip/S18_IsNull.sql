USE AdventureWorks2014;
GO

SELECT COALESCE((SELECT MAX(TotalDue) 
  FROM Sales.SalesOrderHeader),0);

SELECT ISNULL((SELECT MAX(TotalDue) 
  FROM Sales.SalesOrderHeader),0);

-- show that the first query has two 
-- branches with independent CI scans;
-- the second query has one.

-- only case I recommend ISNULL over COALESCE.