USE AdventureWorks2014;
GO

CREATE TABLE dbo.what
(
  ID INT PRIMARY KEY, 
  name VARCHAR(32)
);

-- purposely out of alphabetical order
INSERT dbo.what(ID,name) 
  VALUES(1,'mike'),(2,'grant'),(3,'aaron');

-- ordered by primary key, since cheapest method is CI scan
SELECT name FROM dbo.what;

-- now, someone creates an index
CREATE INDEX x ON dbo.what(name);

-- cheapest method changed; now index scan is used, ordered alpha
SELECT name FROM dbo.what;
GO


-- TOP 100 PERCENT in a view is optimized away
CREATE VIEW dbo.v_what
AS
  SELECT TOP 100 PERCENT ID,name
  FROM dbo.what
  ORDER BY ID;
GO

SELECT ID,name FROM dbo.v_what; -- not ordered by ID

SELECT ID,name FROM dbo.v_what ORDER BY ID;

GO
DROP VIEW dbo.v_what;
DROP TABLE dbo.what;
GO