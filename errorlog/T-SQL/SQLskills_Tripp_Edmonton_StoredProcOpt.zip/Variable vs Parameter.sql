alter proc foo
    (@p1    varchar(15))
as
declare @v1 varchar(15)
select @v1 = @p1
select * from member where lastname = @v1 --> unknown value (24.42) 24.4267086712
select * from member where lastname = @p1 
OPTION (OPTIMIZE FOR UNKNOWN) --> SQL 2008+
select * from member where lastname = @p1 --> known / sniffed (2.5)
go

foo 'Tripp'

sp_helpindex member
dbcc show_statistics(member,MemberLastName)

Alldensity
select 29996 * 0.0008143322