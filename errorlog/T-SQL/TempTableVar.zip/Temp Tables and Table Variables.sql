
-- don't accidentally run the entire script
SET NOEXEC ON;

-- SET NOEXEC OFF;

/*************************************************************
Statistics
*************************************************************/

USE AdventureWorks2014;
GO

IF OBJECT_ID('tempdb..#TempStats', N'U') IS NOT NULL DROP TABLE #TempStats;
GO

CREATE TABLE #TempStats (i int,
	CONSTRAINT PKTempStats PRIMARY KEY (i));
GO

INSERT INTO #TempStats
SELECT N.Number
	FROM Utility.dbo.Numbers AS N
	WHERE N.Number <= 1000;
GO

-- turn on Actual Execution Plan

-- show estimated vs. actual
SELECT * FROM #TempStats;
GO

-- show estimated vs. actual
DECLARE @VarStats TABLE (i int);
INSERT INTO @VarStats
SELECT N.Number
	FROM Utility.dbo.Numbers AS N
	WHERE N.Number <= 1000;
SELECT * FROM @VarStats;
GO

-- with OPTION (RECOMPILE), show estimated vs. actual
DECLARE @VarStats TABLE (i int);
INSERT INTO @VarStats
SELECT N.Number
	FROM Utility.dbo.Numbers AS N
	WHERE N.Number <= 1000;
SELECT * FROM @VarStats
	OPTION (RECOMPILE);
GO

-- histogram stats for temp table
-- show estimated vs. actual
SELECT * FROM #TempStats
	WHERE i BETWEEN 100 AND 105;
GO

-- histotram stats for table variable, using OPTION (RECOMPILE)
DECLARE @VarStats TABLE (i int);
INSERT INTO @VarStats
SELECT N.Number
	FROM Utility.dbo.Numbers AS N
	WHERE N.Number <= 1000;
SELECT * FROM @VarStats
	WHERE i BETWEEN 100 AND 105
	OPTION (RECOMPILE);
GO

-- change the BETWEEN values, and the estimate doesn't change
DECLARE @VarStats TABLE (i int);
INSERT INTO @VarStats
SELECT N.Number
	FROM Utility.dbo.Numbers AS N
	WHERE N.Number <= 1000;
SELECT * FROM @VarStats
	WHERE i BETWEEN 80 AND 300
	OPTION (RECOMPILE);
GO

/****************************************
Temp Table vs. Table Variable logging
****************************************/

-- turn off Actual Execution Plan
SET NOEXEC OFF;
SET NOCOUNT ON;
GO

USE AdventureWorks2014;
GO

IF OBJECT_ID('dbo.PermTable', N'U') IS NOT NULL DROP TABLE dbo.PermTable;
CREATE TABLE dbo.PermTable (i int NOT NULL);

IF OBJECT_ID('tempdb..#TempTable', N'U') IS NOT NULL DROP TABLE #TempTable;
CREATE TABLE #TempTable (i int NOT NULL);
GO

DECLARE @RecordCount int,
	@TLogLength bigint,
	@SysTime datetime2(7);

DECLARE @Results TABLE (
	TableType char(9),
	TLogRows int,
	TLogRecordLength bigint);

DECLARE @TableVariable TABLE (i int NOT NULL);

TRUNCATE TABLE dbo.PermTable;

CHECKPOINT;

BEGIN TRAN;

SELECT @RecordCount = COUNT(*),
	@TLogLength = SUM(CAST([Log Record Length] AS bigint))
	FROM sys.fn_dblog(NULL, NULL);

INSERT INTO dbo.PermTable (i)
SELECT N.Number
	FROM Utility.dbo.Numbers AS N
	WHERE N.Number < 100000;

INSERT INTO @Results (TableType, TLogRecordLength, TLogRows)
SELECT 'Permanent' AS TableType,
	SUM(CAST([Log Record Length] AS bigint)) - @TLogLength AS TLogRecordLength,
	COUNT(*) - @RecordCount AS TLogRows
	FROM sys.fn_dblog(NULL, NULL);

ROLLBACK;

CHECKPOINT;

BEGIN TRAN;

SELECT @RecordCount = COUNT(*),
	@TLogLength = SUM(CAST([Log Record Length] AS bigint))
	FROM sys.fn_dblog(NULL, NULL);
	
INSERT INTO @TableVariable (i)
SELECT N.Number
	FROM Utility.dbo.Numbers AS N
	WHERE N.Number < 100000;

INSERT INTO @Results (TableType, TLogRecordLength, TLogRows)
SELECT 'Variable' AS TableType,
	SUM(CAST([Log Record Length] AS bigint)) - @TLogLength AS TLogRecordLength,
	COUNT(*) - @RecordCount AS TLogRows
	FROM sys.fn_dblog(NULL, NULL);

ROLLBACK;

TRUNCATE TABLE #TempTable;

CHECKPOINT;

BEGIN TRAN;

SELECT @RecordCount = COUNT(*),
	@TLogLength = SUM(CAST([Log Record Length] AS bigint))
	FROM sys.fn_dblog(NULL, NULL);

INSERT INTO #TempTable (i)
SELECT N.Number
	FROM Utility.dbo.Numbers AS N
	WHERE N.Number < 100000;

INSERT INTO @Results (TableType, TLogRecordLength, TLogRows)
SELECT 'Temporary' AS TableType,
	SUM(CAST([Log Record Length] AS bigint)) - @TLogLength AS TLogRecordLength,
	COUNT(*) - @RecordCount AS TLogRows
	FROM sys.fn_dblog(NULL, NULL);

ROLLBACK;

SELECT R.TableType,
	R.TLogRecordLength,
	R.TLogRows AS TLogRows
	FROM @Results AS R;
GO

/*************************************************************
Small vs. Large data sets
*************************************************************/

-- turn OFF actual execution plan

SET NOCOUNT ON;

IF OBJECT_ID('tempdb..#TempTable', N'U') IS NOT NULL DROP TABLE #TempTable;
CREATE TABLE #TempTable (i int NOT NULL);
GO

DECLARE @BeginTimestamp datetime2(7),
	@EndTimestamp datetime2(7),
	@BatchSize int = 10,
	@LoopCount int = 150,
	@Count int;

DECLARE @Results TABLE (
	TableType char(9),
	Action varchar(20),
	BatchSize int,
	BeginTimestamp datetime2(7),
	EndTimestamp datetime2(7));

DECLARE @TableVariable TABLE (i int NOT NULL);

WHILE @BatchSize <= 10000000
BEGIN
	SET @Count = @LoopCount
	WHILE @Count > 0
	BEGIN
		-- table variable
		BEGIN TRAN;

		CHECKPOINT;

		SELECT @BeginTimestamp = SYSDATETIME();
	
		INSERT INTO @TableVariable (i)
		SELECT N.Number
			FROM Utility.dbo.Numbers AS N
			WHERE N.Number < @BatchSize;

		SELECT @EndTimestamp = SYSDATETIME();

		INSERT INTO @Results (TableType, Action, BatchSize, BeginTimestamp, EndTimestamp)
		SELECT 'Variable' AS TableType,
			'Insert' AS Action,
			@BatchSize,
			@BeginTimestamp,
			@EndTimestamp;

		ROLLBACK;

		BEGIN TRAN;

		CHECKPOINT;

		SELECT @BeginTimestamp = SYSDATETIME();
	
		UPDATE @TableVariable
			SET i += 1;;

		SELECT @EndTimestamp = SYSDATETIME();

		INSERT INTO @Results (TableType, Action, BatchSize, BeginTimestamp, EndTimestamp)
		SELECT 'Variable' AS TableType,
			'Update' AS Action,
			@BatchSize,
			@BeginTimestamp,
			@EndTimestamp;

		ROLLBACK;

		BEGIN TRAN;

		CHECKPOINT;

		SELECT @BeginTimestamp = SYSDATETIME();
	
		DELETE @TableVariable;

		SELECT @EndTimestamp = SYSDATETIME();

		INSERT INTO @Results (TableType, Action, BatchSize, BeginTimestamp, EndTimestamp)
		SELECT 'Variable' AS TableType,
			'Delete' AS Action,
			@BatchSize,
			@BeginTimestamp,
			@EndTimestamp;

		ROLLBACK;

		-- temp table
		BEGIN TRAN;

		TRUNCATE TABLE #TempTable;

		CHECKPOINT;

		SELECT @BeginTimestamp = SYSDATETIME();
	
		INSERT INTO #TempTable (i)
		SELECT N.Number
			FROM Utility.dbo.Numbers AS N
			WHERE N.Number < @BatchSize;

		SELECT @EndTimestamp = SYSDATETIME();

		INSERT INTO @Results (TableType, Action, BatchSize, BeginTimestamp, EndTimestamp)
		SELECT 'Temporary' AS TableType,
			'Insert' AS Action,
			@BatchSize,
			@BeginTimestamp,
			@EndTimestamp;

		ROLLBACK;

		BEGIN TRAN;

		CHECKPOINT;

		SELECT @BeginTimestamp = SYSDATETIME();
	
		UPDATE #TempTable
			SET i += 1;;

		SELECT @EndTimestamp = SYSDATETIME();

		INSERT INTO @Results (TableType, Action, BatchSize, BeginTimestamp, EndTimestamp)
		SELECT 'Temporary' AS TableType,
			'Update' AS Action,
			@BatchSize,
			@BeginTimestamp,
			@EndTimestamp;

		ROLLBACK;

		BEGIN TRAN;

		CHECKPOINT;

		SELECT @BeginTimestamp = SYSDATETIME();
	
		DELETE #TempTable;

		SELECT @EndTimestamp = SYSDATETIME();

		INSERT INTO @Results (TableType, Action, BatchSize, BeginTimestamp, EndTimestamp)
		SELECT 'Temporary' AS TableType,
			'Delete' AS Action,
			@BatchSize,
			@BeginTimestamp,
			@EndTimestamp;

		ROLLBACK;
		
		SET @Count -= 1;
	END;

	SET @BatchSize = 10 * @BatchSize;
END;

IF OBJECT_ID('Utility.dbo.Results', N'U') IS NOT NULL DROP TABLE Utility.dbo.Results;
SELECT * INTO Utility.dbo.Results FROM @Results;

SELECT *, DATEDIFF(MS, BeginTimestamp, EndTimestamp) AS Diff
FROM Utility.dbo.Results WHERE TableType = 'Temporary' AND BatchSize = 10000000
AND Action = 'Delete'

SELECT R.TableType, R.Action, R.BatchSize,
	AVG(DATEDIFF(millisecond, BeginTimestamp, EndTimestamp)) AS AvgDurationMS
	FROM Utility.dbo.Results AS R
	GROUP BY R.TableType, R.Action, R.BatchSize
	ORDER BY CASE Action WHEN 'Delete' THEN 1 ELSE 0 END, Action, BatchSize, TableType;
GO

/****************************************
Transaction Scope
****************************************/

-- turn OFF actual execution plan

USE AdventureWorks2014;
GO

IF OBJECT_ID('tempdb..#TxnScope', N'U') IS NOT NULL DROP TABLE #TxnScope;

CREATE TABLE #TxnScope (i int);
DECLARE @TxnScope TABLE (i int);

BEGIN TRAN

INSERT INTO #TxnScope
	SELECT N.Number
	FROM Utility.dbo.Numbers AS N
	WHERE N.Number < 10;

INSERT INTO @TxnScope
	SELECT N.Number
	FROM Utility.dbo.Numbers AS N
	WHERE N.Number < 10;

ROLLBACK;

SELECT i AS TempI FROM #TxnScope;
SELECT i AS VarI FROM @TxnScope;
GO

/*************************************************************
Cleanup
*************************************************************/

SET NOEXEC ON;
GO

IF OBJECT_ID('tempdb..#TxnScope', N'U') IS NOT NULL DROP TABLE #TxnScope;

IF OBJECT_ID('tempdb..#TempStats', N'U') IS NOT NULL DROP TABLE #TempStats;

IF OBJECT_ID('dbo.PermTable', N'U') IS NOT NULL DROP TABLE dbo.PermTable;

IF OBJECT_ID('tempdb..#TempTable', N'U') IS NOT NULL DROP TABLE #TempTable;

IF OBJECT_ID('Utility.dbo.Results', N'U') IS NOT NULL DROP TABLE Utility.dbo.Results;
GO

SET NOEXEC OFF;