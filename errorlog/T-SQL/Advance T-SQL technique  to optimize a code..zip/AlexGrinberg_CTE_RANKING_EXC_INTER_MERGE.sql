

/*
CHECKPOINT
DBCC DROPCLEANBUFFERS
DBCC FREEPROCCACHE
*/



/**********************************	Concatenate column values USING CTE***************************************/

DECLARE @tblTest TABLE (tID int, TestValue varchar(20))
INSERT @tblTest VALUES(2,'A'), (4,'B'),(5,'C'),(6,'D'),(8,'E'),(9, 'F'),(10,'G'), (11,'H'),(12,'J'),(13,'J'),(14,'K'),(15, 'L'),
(16,'M'), (17,'N'),(18,'O'),(19,'P'),(20,'Q'),(21, 'R'),(22,'A'), (23,'S'),(24,'T'),(25,'U'),(26,'W'),(27, 'X')

SET STATISTICS IO, TIME ON

;WITH ABC (FId, FName) AS
(
    SELECT 1, CAST('' AS VARCHAR(8000)) 
    UNION ALL
    SELECT B.FId + 1, B.FName +  A.TestValue + ', ' 
    FROM (SELECT Row_Number() OVER (ORDER BY tID) AS RN, TestValue FROM @tblTest) A 
    INNER JOIN ABC B ON A.RN = B.FId 
)
SELECT top 1 * FROM ABC ORDER BY FId DESC
-- DROP TABLE tblTest

/**********************************	Concatenate column values using XML PATH ***************************************/

SELECT STUFF((SELECT ', ' + TestValue
		FROM @tblTest FOR XML PATH('')), 1, 2,'')

SET STATISTICS IO, TIME OFF

/**********************************	Concatenate Columns within a table ***************************************/
SET STATISTICS IO, TIME ON
-- derived
SELECT U.UserID, Username, Date_Completed ,
	STUFF((SELECT ', ' + CAST(Course_Status_ID as varchar(9)) FROM dbo.RankTest where rt.Username = RankTest.Username FOR XML PATH('')), 1, 2,'')
FROM dbo.RankTest rt
	JOIN (SELECT MAX(Course_Status_ID) AS Course_Status_ID, UserID FROM dbo.RankTest GROUP BY UserID) AS U ON rt.Course_Status_ID = U.Course_Status_ID
-- CTE
;WITH CTE_UNO AS
(
	SELECT ROW_NUMBER() OVER(PARTITION BY UserID ORDER BY Course_Status_ID DESC) AS RN, UserID, Username, Date_Completed FROM dbo.RankTest
)
SELECT UserID, Username, Date_Completed ,
	STUFF((SELECT ', ' + CAST(Course_Status_ID as varchar(9)) FROM dbo.RankTest where CTE_UNO.Username = RankTest.Username FOR XML PATH('')), 1, 2,'')
FROM CTE_UNO WHERE RN = 1

SET STATISTICS IO, TIME OFF















-- Deduping - USING Ranking function and derived table technique

SET STATISTICS IO, TIME ON

SELECT U.UserID, Username--, Date_Completed, u.Row_Version 
FROM dbo.RankTest 
	JOIN (SELECT MAX(Row_Version) AS Row_Version, UserID 
			FROM dbo.RankTest GROUP BY UserID) AS U ON dbo.RankTest.Row_Version = U.Row_Version

--SET STATISTICS IO, TIME OFF

--SET STATISTICS IO, TIME ON

; WITH CTE_UNO AS
(
	SELECT ROW_NUMBER() OVER(PARTITION BY UserID ORDER BY Course_Status_ID DESC) AS RN, UserID, Username, Date_Completed FROM dbo.RankTest
)
SELECT UserID, Username  FROM CTE_UNO WHERE RN = 1
ORDER BY 1

SET STATISTICS IO, TIME OFF

SET STATISTICS IO, TIME ON


;WITH CTE1 AS
(
SELECT U.UserID, Username, Date_Completed
FROM dbo.RankTest rt
	JOIN (SELECT MAX(Course_Status_ID) AS Course_Status_ID, UserID FROM dbo.RankTest GROUP BY UserID) AS U ON rt.Course_Status_ID = U.Course_Status_ID
), CTE2 AS
(
	SELECT ROW_NUMBER() OVER(PARTITION BY UserID ORDER BY Course_Status_ID DESC) AS RN, UserID, Username, Date_Completed FROM dbo.RankTest
)
SELECT UserID FROM CTE2 WHERE RN = 1
EXCEPT
SELECT UserID --, Username, Date_Completed
FROM CTE1 


SET STATISTICS IO, TIME OFF


















/************************************* Test EXCEPT and INTERSECT ****************/

declare @t1 table(tID int)
declare @t2 table(tID int)

insert @t1
select 1
union
select 3
union
select 5
union
select 6

insert @t2
select 1
union
select 2
union
select 4
union
select 6

/*
select tId from @t1
intersect
select tId from @t2

select *
from @t1 t1 join @t2 t2 on t1.tID = t2.tID
*/

select tId from @t1
except
select tId from @t2

select * from @t1 where tID NOT IN (select tID from @t2)


SELECT top 644000 * 
INTO #test
FROM dbo.RankTest


SET STATISTICS IO, TIME ON


SELECT Row_Version FROM RankTest
EXCEPT
SELECT Row_Version FROM #test

SELECT COUNT(Row_Version) FROM RankTest
WHERE Row_Version NOT IN (SELECT Row_Version FROM #test)

SET STATISTICS IO, TIME OFF

SET STATISTICS IO, TIME ON

SELECT Row_Version FROM RankTest
INTERSECT
SELECT Row_Version FROM #test


SELECT RankTest.Row_Version 
FROM RankTest JOIN #test ON RankTest.Row_Version = #test.Row_Version

SET STATISTICS IO, TIME OFF

/*
CHECKPOINT
DBCC DROPCLEANBUFFERS
DBCC FREEPROCCACHE
*/
-- drop table #test

/*

CREATE INDEX IX_RankTest_Row_Version ON RankTest (Row_Version);
CREATE INDEX TIX_Test_Row_Version ON #test (Row_Version);

DROP INDEX IX_RankTest_Row_Version ON RankTest;
DROP INDEX TIX_Test_Row_Version ON #test;

*/
















/**************************************************** OUTPUT Clause ******************************************************************************/
USE Northwind
GO

SET NOCOUNT ON

SET STATISTICS TIME ON
PRINT '*************************** OUTPUT Clause based method***************************************'
declare @x xml
-- get XML
SELECT @x = 
(
	SELECT Products.ProductName, 
			Customers.CompanyName, 
			Shippers.CompanyName AS ShippersName, 
			convert(varchar(20),GETDATE(),101) as OrderDate, 
		   [Order Details].UnitPrice, 
		   [Order Details].Quantity, 
		   CAST([Order Details].Discount as varchar(9)) as Discount
	FROM  Products INNER JOIN
		   [Order Details] ON Products.ProductID = [Order Details].ProductID INNER JOIN
		   Orders ON [Order Details].OrderID = Orders.OrderID INNER JOIN
		   Customers ON Orders.CustomerID = Customers.CustomerID INNER JOIN
		   Shippers ON Orders.ShipVia = Shippers.ShipperID
	WHERE  Orders.OrderDate = '1998-05-05'
	FOR XML PATH('Product'), ROOT('Orders')
)	
/*
-- Create then Shred XML
SELECT c.value('ProductName[1]', 'nvarchar(100)') as ProductName, 
		c.value('CompanyName[1]', 'nvarchar(100)') as CompanyName, 
		c.value('ShippersName[1]', 'nvarchar(100)') as ShippersName, 
		c.value('OrderDate[1]', 'datetime') as OrderDate, 
		c.value('UnitPrice[1]', 'money') as UnitPrice, 
		c.value('Quantity[1]', 'int') as Quantity, 
		c.value('Discount[1]', 'real') as Discount,
		Products.ProductID,
		Shippers.ShipperID,
		Customers.CustomerID
FROM @x.nodes('Orders/Product') as T(C)
	JOIN Products ON Products.ProductName = c.value('ProductName[1]', 'nvarchar(100)')
	JOIN Shippers ON Shippers.CompanyName =  c.value('ShippersName[1]', 'nvarchar(100)')
	JOIN Customers ON Customers.CompanyName = c.value('CompanyName[1]', 'nvarchar(100)')
*/
-- Created output storage table
DECLARE @NewOrder TABLE(OrderID int, CustomerID nchar(5))

-- INSERT into Orders table
INSERT Orders (CustomerID, OrderDate, ShipVia)
		OUTPUT inserted.OrderID, inserted.CustomerID INTO @NewOrder (OrderID, CustomerID)
SELECT distinct	Customers.CustomerID, 
		c.value('OrderDate[1]', 'datetime') as OrderDate, 
		Shippers.ShipperID
FROM @x.nodes('Orders/Product') as T(C)
	JOIN Products ON Products.ProductName = c.value('ProductName[1]', 'nvarchar(100)')
	JOIN Shippers ON Shippers.CompanyName =  c.value('ShippersName[1]', 'nvarchar(100)')
	JOIN Customers ON Customers.CompanyName = c.value('CompanyName[1]', 'nvarchar(100)')
	
-- INSERT into Order Details table
INSERT [Order Details] (OrderID, ProductID, UnitPrice, Quantity, Discount)
SELECT NewOrder.OrderID, Products.ProductID,
		c.value('UnitPrice[1]', 'money') as UnitPrice, 
		c.value('Quantity[1]', 'int') as Quantity, 
		c.value('Discount[1]', 'real') as Discount
FROM @x.nodes('Orders/Product') as T(C)
	JOIN Products ON Products.ProductName = c.value('ProductName[1]', 'nvarchar(100)')
	JOIN Shippers ON Shippers.CompanyName =  c.value('ShippersName[1]', 'nvarchar(100)')
	JOIN Customers ON Customers.CompanyName = c.value('CompanyName[1]', 'nvarchar(100)')
	JOIN @NewOrder NewOrder ON NewOrder.CustomerID = Customers.CustomerID

SET STATISTICS TIME OFF

/****************************  Verify then archive ***************************************
	SELECT Products.ProductName, 
			Customers.CompanyName, 
			Shippers.CompanyName AS ShippersName, 
			convert(varchar(20),GETDATE(),101) as OrderDate, 
		   [Order Details].UnitPrice, 
		   [Order Details].Quantity, 
		   CAST([Order Details].Discount as varchar(9)) as Discount
	FROM  Products INNER JOIN
		   [Order Details] ON Products.ProductID = [Order Details].ProductID INNER JOIN
		   Orders ON [Order Details].OrderID = Orders.OrderID INNER JOIN
		   Customers ON Orders.CustomerID = Customers.CustomerID INNER JOIN
		   Shippers ON Orders.ShipVia = Shippers.ShipperID
	WHERE  Orders.OrderDate >= convert(varchar(20),GETDATE(),101)
	
	DELETE [Order Details]
		OUTPUT deleted.*,GETDATE() INTO Archive_OrderDetails
	FROM [Order Details] JOIN Orders ON [Order Details].OrderID = Orders.OrderID
	WHERE  Orders.OrderDate >= convert(varchar(20),GETDATE(),101)
	
	DELETE Orders
		OUTPUT deleted.*, GETDATE() INTO [Archive_Orders]
	FROM Orders WHERE  Orders.OrderDate >= convert(varchar(20),GETDATE(),101)
	
	SELECT * FROM Archive_OrderDetails
	SELECT * FROM Archive_Orders
	

	TRUNCATE TABLE Archive_OrderDetails
	TRUNCATE TABLE Archive_Orders
		
*/


/******************************** Conventional: CURSOR based method ***********************************************************/
PRINT '***************************Conventional: CURSOR based method***************************************'
GO
SET STATISTICS TIME ON

declare @x xml
-- get XML
SELECT @x = 
(
	SELECT Products.ProductName, 
			Customers.CompanyName, 
			Shippers.CompanyName AS ShippersName, 
			convert(varchar(20),GETDATE(),101) as OrderDate, 
		   [Order Details].UnitPrice, 
		   [Order Details].Quantity, 
		   CAST([Order Details].Discount as varchar(9)) as Discount
	FROM  Products INNER JOIN
		   [Order Details] ON Products.ProductID = [Order Details].ProductID INNER JOIN
		   Orders ON [Order Details].OrderID = Orders.OrderID INNER JOIN
		   Customers ON Orders.CustomerID = Customers.CustomerID INNER JOIN
		   Shippers ON Orders.ShipVia = Shippers.ShipperID
	WHERE  Orders.OrderDate = '1998-05-05'
	FOR XML PATH('Product'), ROOT('Orders')
)	

-- Created cursor
DECLARE @CustomerID varchar(20), @OrderDate datetime, @ShippersID int, @OrderID int 
DECLARE cur CURSOR 
	FOR	SELECT DISTINCT	Customers.CustomerID, 
				c.value('OrderDate[1]', 'datetime') as OrderDate, 
				Shippers.ShipperID
		FROM @x.nodes('Orders/Product') as T(C)
			JOIN Products ON Products.ProductName = c.value('ProductName[1]', 'nvarchar(100)')
			JOIN Shippers ON Shippers.CompanyName =  c.value('ShippersName[1]', 'nvarchar(100)')
			JOIN Customers ON Customers.CompanyName = c.value('CompanyName[1]', 'nvarchar(100)')
OPEN cur
FETCH NEXT FROM cur INTO @CustomerID, @OrderDate, @ShippersID

-- Check @@FETCH_STATUS to see if there are any more rows to fetch.
WHILE @@FETCH_STATUS = 0
BEGIN

-- INSERT into Orders table
INSERT Orders (CustomerID, OrderDate, ShipVia)
SELECT		@CustomerID, @OrderDate, @ShippersID

SET @OrderID = SCOPE_IDENTITY()

-- INSERT into Order Details table
INSERT [Order Details] (OrderID, ProductID, UnitPrice, Quantity, Discount)
SELECT @OrderID, Products.ProductID,
		c.value('UnitPrice[1]', 'money') as UnitPrice, 
		c.value('Quantity[1]', 'int') as Quantity, 
		c.value('Discount[1]', 'real') as Discount
FROM @x.nodes('Orders/Product') as T(C)
	JOIN Products ON Products.ProductName = c.value('ProductName[1]', 'nvarchar(100)')
	JOIN Shippers ON Shippers.CompanyName =  c.value('ShippersName[1]', 'nvarchar(100)')
	JOIN Customers ON Customers.CompanyName = c.value('CompanyName[1]', 'nvarchar(100)')
WHERE Customers.CustomerID = @CustomerID
	
FETCH NEXT FROM cur INTO @CustomerID, @OrderDate, @ShippersID

END

DEALLOCATE cur;

SET STATISTICS TIME OFF
		
		
		
		
		
/******************************************************* More OUTPUT Clause *********************************************/
declare @t TABLE(tID uniqueidentifier not null primary key default NEWSEQUENTIALID(), num1 int)

declare @newid table (tID uniqueidentifier)
insert @t (num1)
	OUTPUT inserted.tID into @newid
values (1),(2),(3)

select * from @newid
	
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
/******************************** MERGE STATEMENT ******************************************/


SET NOCOUNT ON

IF OBJECT_ID (N'dbo.Departments', N'U') IS NOT NULL 
    DROP TABLE dbo.Departments;
GO
CREATE TABLE dbo.Departments (DeptID tinyint NOT NULL PRIMARY KEY, DeptName nvarchar(30), Manager nvarchar(50));
GO
INSERT INTO dbo.Departments 
VALUES (1, 'Human Resources', 'Mark'),
		(2, 'Sales', 'Steve'), 
		(3, 'Finance', 'Gill'),
		(4, 'Purchasing', 'Barber'),
		(5, 'Manufacturing', 'Brewer');

IF OBJECT_ID (N'dbo.Departments_delta', N'U') IS NOT NULL 
    DROP TABLE dbo.Departments_delta;
GO
CREATE TABLE dbo.Departments_delta (DeptID tinyint NOT NULL PRIMARY KEY, DeptName nvarchar(30), Manager nvarchar(50));
GO
INSERT INTO dbo.Departments_delta VALUES 
    (1, 'Human Resources', 'Mark'), 
    (2, 'Sales', 'Erickson'),
    (3, 'Accounting', 'Varkey'),
    (4, 'Purchasing', 'Barber'), 
    (6, 'Production', 'Jones'), 
    (7, 'Customer Relations', 'Smith');
    
SET STATISTICS IO, TIME ON

; MERGE dbo.Departments AS d
USING dbo.Departments_delta AS dd
	ON (d.DeptID = dd.DeptID)
WHEN MATCHED AND d.Manager != dd.Manager OR d.DeptName != dd.DeptName
    THEN UPDATE SET d.Manager = dd.Manager, 
					d.DeptName = dd.DeptName
WHEN NOT MATCHED THEN
    INSERT (DeptID, DeptName, Manager)
    VALUES (dd.DeptID, dd.DeptName, dd.Manager)
WHEN NOT MATCHED BY SOURCE THEN -- SOURCE - DELETE; TARGET - INSERT
    DELETE
OUTPUT $action, 
       inserted.DeptID AS SourceDeptID, inserted.DeptName AS SourceDeptName, inserted.Manager AS SourceManager, 
       deleted.DeptID AS TargetDeptID, deleted.DeptName AS TargetDeptName, deleted.Manager AS TargetManager;
       
SET STATISTICS IO, TIME OFF


select * from Departments
select * from Departments_delta

SET NOCOUNT OFF



/*


create table #Archive (
	ActionType varchar(20), 
	SourceDeptID int, 
	SourceDeptName nvarchar(50), 
	SourceManager nvarchar(50),
	TargetDeptID int, 
	TargetDeptName nvarchar(50), 
	TargetManager nvarchar(50)
)

;MERGE dbo.Departments AS d
USING dbo.Departments_delta AS dd
	ON (d.DeptID = dd.DeptID)
WHEN MATCHED AND d.Manager <> dd.Manager OR d.DeptName <> dd.DeptName
    THEN UPDATE SET d.Manager = dd.Manager, 
					d.DeptName = dd.DeptName
WHEN NOT MATCHED THEN
    INSERT (DeptID, DeptName, Manager)
    VALUES (dd.DeptID, dd.DeptName, dd.Manager)
WHEN NOT MATCHED BY SOURCE THEN
    DELETE   
OUTPUT $action, 
       inserted.DeptID AS SourceDeptID, inserted.DeptName AS SourceDeptName, inserted.Manager AS SourceManager, 
       deleted.DeptID AS TargetDeptID, deleted.DeptName AS TargetDeptName, deleted.Manager AS TargetManager
INTO #Archive;

SELECT * FROM #archive

*/
