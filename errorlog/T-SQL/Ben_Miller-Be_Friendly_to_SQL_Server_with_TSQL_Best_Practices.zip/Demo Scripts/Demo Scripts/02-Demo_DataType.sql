USE DemoDB
GO
/*
Used to create my accounts table

CREATE TABLE dbo.Accounts (
	AccountNumber NVARCHAR(100) NOT NULL,
	AcctName VARCHAR(50) NOT NULL,
	Address1 VARCHAR(25) NOT NULL,
	Address2 VARCHAR(25) NULL,
	City VARCHAR(25) NOT NULL,
	StateCode CHAR(2) NOT NULL,
	PostalCode VARCHAR(10) NOT NULL
)
GO

CREATE SEQUENCE dbo.Sequence1
    START WITH 1
    INCREMENT BY 2 ;
GO

INSERT INTO dbo.Accounts (AccountNumber, AcctName, Address1, Address2, City, StateCode, PostalCode)
SELECT NEXT VALUE FOR dbo.Sequence1, 'Acct Name'+CONVERT(varchar(12),NEXT VALUE FOR dbo.Sequence1), 'Address '+CONVERT(varchar(12), Next Value for dbo.Sequence1),
'Address '+CONVERT(varchar(12), Next Value for dbo.Sequence1),'City '+CONVERT(varchar(12), Next value for dbo.Sequence1), 'OH', '45142'
GO 900000

CREATE UNIQUE CLUSTERED INDEX PK_Accounts_AccountNumber ON dbo.Accounts (
	AccountNumber
)
GO

SELECT COUNT(*)
from dbo.Accounts

*/


SET NOCOUNT ON
SET STATISTICS IO ON
-- Data type precedence will convert the AccountNumber to Int
-- Which causes a table scan to implicitly convert the values.

DECLARE @DistributorId INT
SET @DistributorId = 120021

SELECT *
FROM dbo.Accounts 
WHERE AccountNumber = @DistributorId
GO

-- Now with a specific datatype converted.
DECLARE @DistributorId INT
SET @DistributorId = 120021

SELECT *
FROM dbo.Accounts 
WHERE AccountNumber = CONVERT(NVARCHAR(100), @DistributorId)
GO

/*
Table 'Accounts'. Scan count 1, logical reads 3814, physical reads 0, read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.
 SQL Server Execution Times:
   CPU time = 108 ms,  elapsed time = 32 ms.
   
Table 'Accounts'. Scan count 0, logical reads 3, physical reads 0, read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.
 SQL Server Execution Times:
   CPU time = 0 ms,  elapsed time = 0 ms.
*/
