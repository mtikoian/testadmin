USE tempdb
SET NOCOUNT on
GO
CREATE TABLE	dbo.T4
		( UserID bigint NOT NULL, --user identifier
		  SocketID bigint NOT NULL, --"application" identifier
        APIDateTime datetime NOT NULL --an API hit occurred by user for app
		)
CREATE CLUSTERED INDEX idx1 ON T4 (userid, socketid, APIDateTime) --note "POC" index - NO SORTS!!

--TRUNCATE TABLE T4

INSERT	dbo.T4
VALUES
   (1, 295, '20130101 00:00'),
   (1, 295, '20130101 00:01'),
   (1, 295, '20130101 00:02'),
   (1, 295, '20130101 00:03'),
   (1, 295, '20130101 00:15'),
   (1, 295, '20130101 00:30:01'),
   (1, 295, '20130101 01:00'),
   (1, 295, '20130101 01:10'),
   (1, 295, '20130101 01:10'),
   (1, 295, '20130101 01:11'),
   (2, 295, '20130101 00:00'),
   (2, 295, '20130101 00:00'),
   (2, 295, '20130101 00:01'),
   (2, 295, '20130101 00:02'),
   (2, 295, '20130101 00:03'),
   (2, 295, '20130101 00:15'),
   (2, 295, '20130101 00:30:01'),
   (2, 295, '20130101 01:00'),
   (2, 295, '20130101 01:10'),
   (2, 295, '20130101 01:10'),
   (2, 295, '20130101 01:11'),
   (2, 295, '20130101 00:00'),

   (1, 110, '20130101 00:00'),
   (1, 110, '20130101 00:01'),
   (1, 110, '20130101 00:02'),
   (1, 110, '20130101 00:03'),
   (1, 110, '20130101 00:15'),
   (1, 110, '20130101 00:30:01'),
   (1, 110, '20130101 01:00'),
   (1, 110, '20130101 01:10'),
   (1, 110, '20130101 01:10'),
   (1, 110, '20130101 01:11'),
   (2, 110, '20130101 00:00'),
   (2, 110, '20130101 00:00'),
   (2, 110, '20130101 00:01'),
   (2, 110, '20130101 00:02'),
   (2, 110, '20130101 00:03'),
   (2, 110, '20130101 00:15'),
   (2, 110, '20130101 00:30:01'),
   (2, 110, '20130101 01:00'),
   (2, 110, '20130101 01:10'),
   (2, 110, '20130101 01:10'),
   (2, 110, '20130101 01:11'),
   (2, 110, '20130101 00:00')

--crossing midnight?
INSERT	dbo.T4
VALUES
   (1, 295, '20130101 23:45'),
   (1, 295, '20130101 23:56'),
   (1, 295, '20130102 00:03'),
   (1, 110, '20130101 23:56'),
   (1, 110, '20130102 00:00'),
   (1, 110, '20130102 00:07')

SELECT * FROM T4
ORDER BY userid, socketid, apidatetime

DECLARE  @GapAllowed INT = 15*60 --15 minutes contiguous defines a single session within the app?
;WITH cteSource(UserID, SocketID, RangeStart, RangeEnd)
AS (
   SELECT  UserID, SocketID, RangeStart,
      LEAD(RangeEnd) OVER (PARTITION BY UserID, SocketID ORDER BY APIDateTime) AS RangeEnd
        FROM   (
         SELECT UserID,  SocketID, APIDateTime,
            CASE
               WHEN DATEDIFF(ss, LAG(APIDateTime) OVER (PARTITION BY UserID, SocketID ORDER BY APIDateTime), APIDateTime) <= @GapAllowed THEN NULL
               ELSE APIDateTime
            END AS RangeStart,
            CASE
               WHEN DATEDIFF(ss, APIDateTime, LEAD(APIDateTime) OVER (PARTITION BY UserID, SocketID ORDER BY APIDateTime)) <= @GapAllowed THEN NULL
               ELSE APIDateTime
            END AS RangeEnd
          FROM T4) AS d
   WHERE RangeStart IS NOT NULL
      OR RangeEnd IS NOT NULL
)
--select * from ctesource ORDER BY userid, socketid, rangestart, rangeend
SELECT  UserID, SocketID, RangeStart,
        ISNULL(RangeEnd, RangeStart) AS RangeEnd
  FROM  cteSource
 WHERE RangeStart IS NOT NULL
 ORDER BY UserID, SocketID, RangeStart, RangeEnd

UserID               SocketID             RangeStart              RangeEnd
-------------------- -------------------- ----------------------- -----------------------
1                    110                  2013-01-01 00:00:00.000 2013-01-01 00:15:00.000
 --we want a minimum usage time so we will add 10 seconds to each zero-second interval
1                    110                  2013-01-01 00:30:01.000 2013-01-01 00:30:01.000
1                    110                  2013-01-01 01:00:00.000 2013-01-01 01:11:00.000
1                    110                  2013-01-01 23:56:00.000 2013-01-02 00:07:00.000
1                    295                  2013-01-01 00:00:00.000 2013-01-01 00:15:00.000
1                    295                  2013-01-01 00:30:01.000 2013-01-01 00:30:01.000
1                    295                  2013-01-01 01:00:00.000 2013-01-01 01:11:00.000
1                    295                  2013-01-01 23:45:00.000 2013-01-02 00:03:00.000
2                    110                  2013-01-01 00:00:00.000 2013-01-01 00:15:00.000
2                    110                  2013-01-01 00:30:01.000 2013-01-01 00:30:01.000
2                    110                  2013-01-01 01:00:00.000 2013-01-01 01:11:00.000
2                    295                  2013-01-01 00:00:00.000 2013-01-01 00:15:00.000
2                    295                  2013-01-01 00:30:01.000 2013-01-01 00:30:01.000
2                    295                  2013-01-01 01:00:00.000 2013-01-01 01:11:00.000


DECLARE  @GapAllowed INT = 15*60 --what happens when change contiguous time interval to say 10 mins?
;WITH a (UserID, SocketID, RangeStart, RangeEnd)
AS (
   SELECT  UserID, SocketID, RangeStart,
      LEAD(RangeEnd) OVER (PARTITION BY UserID, SocketID ORDER BY APIDateTime) AS RangeEnd
        FROM   (
         SELECT UserID,  SocketID, APIDateTime,
            CASE
               WHEN DATEDIFF(ss, LAG(APIDateTime) OVER (PARTITION BY UserID, SocketID ORDER BY APIDateTime), APIDateTime) <= @GapAllowed THEN NULL
               ELSE APIDateTime
            END AS RangeStart,
            CASE
               WHEN DATEDIFF(ss, APIDateTime, LEAD(APIDateTime) OVER (PARTITION BY UserID, SocketID ORDER BY APIDateTime)) <= @GapAllowed THEN NULL
               ELSE APIDateTime
            END AS RangeEnd
          FROM T4) AS d
   WHERE RangeStart IS NOT NULL
      OR RangeEnd IS NOT NULL)
--SELECT * FROM a WHERE RangeStart IS NOT NULL
, b as (SELECT  UserID, SocketID, DATEDIFF(ss, RangeStart, CASE WHEN RangeEnd <> RangeStart THEN ISNULL(RangeEnd, RangeStart) ELSE DATEADD(ss, 10, ISNULL(RangeEnd, RangeStart)) END)*1.0 AS SessionSeconds
          FROM  a
         WHERE RangeStart IS NOT NULL)
--SELECT * FROM b
/* since can't do average of average, Store count and session total per UserID/SocketID 
then do further analytics based off of those two known keys*/
SELECT UserID, SocketID, SUM(SessionSeconds)/60.0 AS SUMSessionMinutes, COUNT(*) AS SessionCount
 FROM b
GROUP BY UserID, SocketID
ORDER BY UserID, SocketID

b OUTPUT:
UserID               SocketID             SessionSeconds
-------------------- -------------------- ---------------------------------------
1                    110                  900.0
1                    110                  10.0
1                    110                  660.0
1                    110                  660.0
1                    295                  900.0
1                    295                  10.0
1                    295                  660.0
1                    295                  1080.0
2                    110                  900.0
2                    110                  10.0
2                    110                  660.0
2                    295                  900.0
2                    295                  10.0
2                    295                  660.0

