USE [master];
GO

-- create the database
IF DB_ID('RunningTotals') IS NOT NULL
BEGIN
	ALTER DATABASE RunningTotals SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
	DROP DATABASE RunningTotals;
END
GO
CREATE DATABASE RunningTotals;
GO

USE RunningTotals;
GO
SET NOCOUNT ON;
GO

-- create a skinny table
CREATE TABLE dbo.SpeedingTickets
(
	[Date]      DATE NOT NULL,
	TicketCount INT
);
GO

-- populate the table with fictitious data
;WITH x(d,h) AS
(
	SELECT TOP (250) 
		ROW_NUMBER() OVER (ORDER BY [object_id]),
		CONVERT(INT, RIGHT([object_id], 2)) 
	FROM sys.all_objects
	ORDER BY [object_id]
)
INSERT dbo.SpeedingTickets([Date], TicketCount)
SELECT TOP (10000) 
	d = DATEADD(DAY, x2.d + ((x.d-1)*250), '19831231'), 
	x2.h 
FROM x CROSS JOIN x AS x2
ORDER BY d;
GO

-- make the [Date] column the clustered PK
ALTER TABLE dbo.SpeedingTickets ADD CONSTRAINT pk PRIMARY KEY CLUSTERED ([Date]);
GO
 
-- validate 10,000 rows
SELECT [Date], TicketCount
	FROM dbo.SpeedingTickets 
	ORDER BY [Date];
GO

-- 7 procedures for various "running totals" approaches
CREATE PROCEDURE [dbo].[RunningTotals_Cursor]
	@debug TINYINT = 0 
	-- @debug = 1 : show top/bottom 3
	-- @debug = 2 : show all 50k
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @st TABLE
	(
		[Date]		 DATE PRIMARY KEY,
		TicketCount  INT, 
		RunningTotal INT
	);

	DECLARE 
		@Date         DATE,
		@TicketCount  INT,
		@RunningTotal INT = 0;

	DECLARE c CURSOR
		LOCAL STATIC FORWARD_ONLY READ_ONLY
		FOR
			SELECT [Date], TicketCount
				FROM dbo.SpeedingTickets
				ORDER BY [Date];

	OPEN c;

	FETCH NEXT FROM c INTO @Date, @TicketCount;

	WHILE @@FETCH_STATUS = 0
	BEGIN
		SET @RunningTotal = @RunningTotal + @TicketCount;

		INSERT @st([Date], TicketCount,  RunningTotal)
			SELECT @Date, @TicketCount, @RunningTotal;

		FETCH NEXT FROM c INTO @Date, @TicketCount;
	END

	CLOSE c;
	DEALLOCATE c;

	IF @debug = 1
	BEGIN
		;WITH d AS
		(
			SELECT [Date], TicketCount, RunningTotal,
				rn = ROW_NUMBER() OVER (ORDER BY [Date])
			FROM @st
		)

		SELECT [Date], TicketCount, RunningTotal
			FROM d
			WHERE rn < 4 OR rn > 9997
			ORDER BY [Date];
	END

	IF @debug = 2
	BEGIN
		SELECT [Date], TicketCount, RunningTotal
			FROM @st
			ORDER BY [Date];
	END
END
GO
CREATE PROCEDURE [dbo].[RunningTotals_DateCTE]
	@debug TINYINT = 0 
	-- @debug = 1 : show top/bottom 3
	-- @debug = 2 : show all 50k
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @st TABLE
	(
		[Date] DATE PRIMARY KEY,
		TicketCount INT, 
		RunningTotal INT
	);

	;WITH x AS
	(
		SELECT [Date], TicketCount, RunningTotal = TicketCount
			FROM dbo.SpeedingTickets
			WHERE [Date] = '19840101'
		UNION ALL
		SELECT y.[Date], y.TicketCount, x.RunningTotal + y.TicketCount
			FROM x INNER JOIN dbo.SpeedingTickets AS y
			ON y.[Date] = DATEADD(DAY, 1, x.[Date])
	)
	INSERT @st([Date], TicketCount, RunningTotal)
	SELECT [Date], TicketCount, RunningTotal 
		FROM x 
		ORDER BY [Date]
		OPTION (MAXRECURSION 10000);

	IF @debug = 1
	BEGIN
		;WITH d AS
		(
			SELECT [Date], TicketCount, RunningTotal,
				rn = ROW_NUMBER() OVER (ORDER BY [Date])
				FROM @st
		)
		SELECT [Date], TicketCount, RunningTotal
			FROM d
			WHERE rn < 4 OR rn > 9997
			ORDER BY [Date];
	END

	IF @debug = 2
	BEGIN
		SELECT [Date], TicketCount, RunningTotal
			FROM @st
			ORDER BY [Date];
	END
END
GO
CREATE PROCEDURE [dbo].[RunningTotals_InnerJoin]
	@debug TINYINT = 0 
	-- @debug = 1 : show top/bottom 3
	-- @debug = 2 : show all 50k
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @st TABLE
	(
		[Date] DATE PRIMARY KEY,
		TicketCount INT, 
		RunningTotal INT
	);

	INSERT @st([Date], TicketCount, RunningTotal)
	SELECT
		st1.[Date],
		st1.TicketCount,
		RunningTotal = SUM(st2.TicketCount)
	FROM
		dbo.SpeedingTickets AS st1
	INNER JOIN 
		dbo.SpeedingTickets AS st2
		ON st2.[Date] <= st1.[Date]
	GROUP BY st1.[Date], st1.TicketCount
	ORDER BY st1.[Date];

	IF @debug = 1
	BEGIN
		;WITH d AS
		(
			SELECT [Date], TicketCount, RunningTotal,
			rn = ROW_NUMBER() OVER (ORDER BY [Date])
			FROM @st
		)
		SELECT [Date], TicketCount, RunningTotal
			FROM d
			WHERE rn < 4 OR rn > 9997
			ORDER BY [Date];
	END

	IF @debug = 2
	BEGIN
		SELECT [Date], TicketCount, RunningTotal
			FROM @st
			ORDER BY [Date];
	END
END

GO
CREATE PROCEDURE [dbo].[RunningTotals_QuirkyUpdate]
	@debug TINYINT = 0 
	-- @debug = 1 : show top/bottom 3
	-- @debug = 2 : show all 50k
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @st TABLE
	(
		[Date] DATE PRIMARY KEY,
		TicketCount INT, 
		RunningTotal INT
	);

	DECLARE @RunningTotal INT = 0;

	INSERT @st([Date], TicketCount, RunningTotal)
	SELECT [Date], TicketCount, RunningTotal = 0
		FROM dbo.SpeedingTickets
		ORDER BY [Date];

	UPDATE @st
		SET @RunningTotal = RunningTotal = @RunningTotal + TicketCount
		FROM @st;

	IF @debug = 1
	BEGIN
		;WITH d AS
		(
			SELECT [Date], TicketCount, RunningTotal,
				rn = ROW_NUMBER() OVER (ORDER BY [Date])
				FROM @st
		)
		SELECT [Date], TicketCount, RunningTotal
			FROM d
			WHERE rn < 4 OR rn > 9997
			ORDER BY [Date];
	END

	IF @debug = 2
	BEGIN
		SELECT [Date], TicketCount, RunningTotal
			FROM @st
			ORDER BY [Date];
	END
END
GO
CREATE PROCEDURE [dbo].[RunningTotals_Subquery]
	@debug TINYINT = 0 
	-- @debug = 1 : show top/bottom 3
	-- @debug = 2 : show all 50k
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @st TABLE
	(
		[Date]		 DATE PRIMARY KEY,
		TicketCount  INT, 
		RunningTotal INT
	);

	INSERT @st([Date], TicketCount, RunningTotal)
	SELECT 
		[Date],
		TicketCount,
		RunningTotal = TicketCount + COALESCE(
		(
			SELECT SUM(TicketCount) 
				FROM dbo.SpeedingTickets AS s
				WHERE s.[Date] < o.[Date]), 0
		)
	FROM dbo.SpeedingTickets AS o
	ORDER BY [Date];

	IF @debug = 1
	BEGIN
		;WITH d AS
		(
			SELECT [Date], TicketCount, RunningTotal,
				rn = ROW_NUMBER() OVER (ORDER BY [Date])
			FROM @st
		)
		SELECT [Date], TicketCount, RunningTotal
			FROM d
			WHERE rn < 4 OR rn > 9997
			ORDER BY [Date];
	END

	IF @debug = 2
	BEGIN
		SELECT [Date], TicketCount, RunningTotal
			FROM @st
			ORDER BY [Date];
	END
END
GO
CREATE PROCEDURE [dbo].[RunningTotals_Windowed_Range]
	@debug TINYINT = 0 
	-- @debug = 1 : show top/bottom 3
	-- @debug = 2 : show all 50k
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @st TABLE
	(
		[Date] DATE PRIMARY KEY,
		TicketCount INT, 
		RunningTotal INT
	);

	INSERT @st([Date], TicketCount, RunningTotal)
	SELECT
		[Date], 
		TicketCount,
		SUM(TicketCount) OVER (ORDER BY [Date] RANGE UNBOUNDED PRECEDING)
	FROM dbo.SpeedingTickets
	ORDER BY [Date];

	IF @debug = 1
	BEGIN
		;WITH d AS
		(
			SELECT [Date], TicketCount, RunningTotal,
				rn = ROW_NUMBER() OVER (ORDER BY [Date])
				FROM @st
		)
		SELECT [Date], TicketCount, RunningTotal
			FROM d
			WHERE rn < 4 OR rn > 9997
			ORDER BY [Date];
	END

	IF @debug = 2
	BEGIN
		SELECT [Date], TicketCount, RunningTotal
			FROM @st
			ORDER BY [Date];
	END
END
GO
CREATE PROCEDURE [dbo].[RunningTotals_Windowed_Rows]
	@debug TINYINT = 0 
	-- @debug = 1 : show top/bottom 3
	-- @debug = 2 : show all 50k
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @st TABLE
	(
		[Date] DATE PRIMARY KEY,
		TicketCount INT, 
		RunningTotal INT
	);

	INSERT @st([Date], TicketCount, RunningTotal)
	SELECT
		[Date], 
		TicketCount,
		SUM(TicketCount) OVER (ORDER BY [Date] ROWS UNBOUNDED PRECEDING)
	FROM dbo.SpeedingTickets
	ORDER BY [Date];

	IF @debug = 1
	BEGIN
		;WITH d AS
		(
			SELECT [Date], TicketCount, RunningTotal,
				rn = ROW_NUMBER() OVER (ORDER BY [Date])
				FROM @st
		)
		SELECT [Date], TicketCount, RunningTotal
			FROM d
			WHERE rn < 4 OR rn > 9997
			ORDER BY [Date];
	END

	IF @debug = 2
	BEGIN
		SELECT [Date], TicketCount, RunningTotal
			FROM @st
			ORDER BY [Date];
	END
END
GO

-- a set of batches to test
EXEC dbo.RunningTotals_DateCTE @debug = 0;
GO
EXEC dbo.RunningTotals_Cursor @debug = 0;
GO
EXEC dbo.RunningTotals_Subquery @debug = 0;
GO
EXEC dbo.RunningTotals_InnerJoin @debug = 0;
GO
EXEC dbo.RunningTotals_QuirkyUpdate @debug = 0;
GO
EXEC dbo.RunningTotals_Windowed_Range @debug = 0;
GO
EXEC dbo.RunningTotals_Windowed_Rows @debug = 0;
GO