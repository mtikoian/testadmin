USE tempdb
GO
SET NOCOUNT ON
go

CREATE SEQUENCE dbo.TestSequence AS INTEGER START WITH 1;

SELECT NEXT VALUE FOR dbo.TestSequence;

DECLARE @TestScore TABLE (Grade TINYINT)
INSERT INTO @TestScore
VALUES (100),
       (89 ),
       (98 ),
       (82 ),
       (95 ),
       (90 ),
       (83 ),
       (89 ),
       (85 ),
       (91 ),
       (85 );

SELECT Grade,
       RowNbr     = ROW_NUMBER() OVER (ORDER BY Grade DESC),
       Seq        = NEXT VALUE FOR dbo.TestSequence OVER (ORDER BY Grade ASC)
  FROM @TestScore;

DROP SEQUENCE dbo.TestSequence;
