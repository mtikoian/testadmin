DECLARE @SampleData TABLE (
  AccountId INTEGER,
  TranDate  DATE,
  TranAmt   NUMERIC(8,2));

INSERT INTO @SampleData 
            (AccountId, TranDate, TranAmt)
     VALUES (1, '2011-01-01', 500),
            (1, '2011-01-15', 50),
            (1, '2011-01-22', 250),
            (1, '2011-01-24', 75),
            (1, '2011-01-26', 125),
            (1, '2011-01-28', 175),
            
            (2, '2011-01-01', 500),
            (2, '2011-01-15', 50),
            (2, '2011-01-22', 25),
            (2, '2011-01-23', 125),
            (2, '2011-01-26', 200),
            (2, '2011-01-29', 250),

            (3, '2011-01-01', 500),
            (3, '2011-01-15', 50 ),
            (3, '2011-01-22', 5000),
            (3, '2011-01-25', 550),
            (3, '2011-01-27', 95 ),
            (3, '2011-01-30', 2500);

SELECT AccountId ,
       TranDate ,
       TranAmt,
       -- average of the current and previous 2 transactions
       SlideAvg      = AVG(TranAmt) OVER (PARTITION BY AccountId
                                              ORDER BY TranDate
                                               ROWS BETWEEN 2 PRECEDING AND CURRENT ROW),
       -- total # of the current and previous 2 transactions
       SlideTranQty  = COUNT(*)     OVER (PARTITION BY AccountId 
                                              ORDER BY TranDate
                                               ROWS BETWEEN 2 PRECEDING AND CURRENT ROW),
       -- smallest of the current and previous 2 transactions
       SlideSmallAmt = MIN(TranAmt) OVER (PARTITION BY AccountId 
                                              ORDER BY TranDate
                                               ROWS BETWEEN 2 PRECEDING AND CURRENT ROW),
       -- largest of the current and previous 2 transactions
       SlideLargeAmt = MAX(TranAmt) OVER (PARTITION BY AccountId 
                                              ORDER BY TranDate
                                               ROWS BETWEEN 2 PRECEDING AND CURRENT ROW),
       -- total of the current and previous 2 transactions
       SlideTotalAmt = SUM(TranAmt) OVER (PARTITION BY AccountId 
                                              ORDER BY TranDate
                                               ROWS BETWEEN 2 PRECEDING AND CURRENT ROW)
  FROM @SampleData
 ORDER BY AccountId, TranDate;
