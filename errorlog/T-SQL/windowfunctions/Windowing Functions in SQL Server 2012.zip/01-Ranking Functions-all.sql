DECLARE @ClassRank TABLE (
    StudentID TINYINT, 
    Grade TINYINT);
INSERT INTO @ClassRank
VALUES (1, 100),
       (2, 100),
       (3, 99 ),
       (4, 98 ),
       (5, 95 ),
       (6, 95 ),
       (7, 90 ),
       (8, 89 ),
       (9, 89 ),
       (10, 85),
       (11, 85),
       (12, 82);

DECLARE @Tile INT;
SET @Tile = 5;

SELECT StudentID,
       Grade,
       RowNbr     = ROW_NUMBER() OVER (ORDER BY Grade DESC),
       [Rank]     = RANK()       OVER (ORDER BY Grade DESC),
       DenseRank  = DENSE_RANK() OVER (ORDER BY Grade DESC),
       [NTile]    = NTILE(@Tile) OVER (ORDER BY Grade DESC)
  FROM @ClassRank;
