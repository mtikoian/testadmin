DECLARE @SampleData TABLE (
  AccountId INTEGER,
  TranDate  DATE,
  TranAmt   NUMERIC(8,2));

INSERT INTO @SampleData 
            (AccountId, TranDate, TranAmt)
     VALUES (1, '2011-01-01', 500),
            (1, '2011-01-15', 50),
            (1, '2011-01-22', 250),
            (1, '2011-01-24', 75),
            (1, '2011-01-26', 125),
            (1, '2011-01-28', 175),
            
            (2, '2011-01-01', 500),
            (2, '2011-01-15', 50),
            (2, '2011-01-22', 25),
            (2, '2011-01-23', 125),
            (2, '2011-01-26', 200),
            (2, '2011-01-29', 250),

            (3, '2011-01-01', 500),
            (3, '2011-01-15', 50 ),
            (3, '2011-01-22', 5000),
            (3, '2011-01-25', 550),
            (3, '2011-01-27', 95 ),
            (3, '2011-01-30', 2500);

SELECT AccountId ,
       TranDate ,
       TranAmt,
       -- running average of all transactions
       RunAvg      = AVG(TranAmt) OVER (PARTITION BY AccountId
                                            ORDER BY TranDate),
       -- running total # of transactions
       RunTranQty  = COUNT(*)     OVER (PARTITION BY AccountId 
                                            ORDER BY TranDate),
       -- smallest of the transactions so far
       RunSmallAmt = MIN(TranAmt) OVER (PARTITION BY AccountId 
                                            ORDER BY TranDate),
       -- largest of the transactions so far
       RunLargeAmt = MAX(TranAmt) OVER (PARTITION BY AccountId 
                                            ORDER BY TranDate),
       -- running total of all transactions
       RunTotalAmt = SUM(TranAmt) OVER (PARTITION BY AccountId 
                                            ORDER BY TranDate)
  FROM @SampleData
 ORDER BY AccountId, TranDate;
