USE tempdb;
GO
IF EXISTS (SELECT sch.name + '.' + seq.name AS [Sequence schema and name]
             FROM sys.sequences AS seq
			      JOIN sys.schemas AS sch
				    ON seq.schema_id = sch.schema_id
			WHERE sch.name = 'dbo'
			  and seq.name = 'TestSequence')
   DROP SEQUENCE dbo.TestSequence;

CREATE SEQUENCE dbo.TestSequence AS INTEGER START WITH 1;

SELECT NEXT VALUE FOR dbo.TestSequence;

DECLARE @ClassRank TABLE (StudentID TINYINT, Grade TINYINT)
INSERT INTO @ClassRank
VALUES (1, 100),
       (2, 100),
       (3, 99 ),
       (4, 98 ),
       (5, 95 ),
       (6, 95 ),
       (7, 90 ),
       (8, 89 ),
       (9, 89 ),
       (10, 85),
       (11, 85),
       (12, 82);

DECLARE @Tile INT;
SET @Tile = 5;

SELECT StudentID,
       Grade,
       RowNbr     = ROW_NUMBER() OVER (ORDER BY Grade DESC),
       [Rank]     = RANK()       OVER (ORDER BY Grade DESC),
       DenseRank  = DENSE_RANK() OVER (ORDER BY Grade DESC),
       [NTile]    = NTILE(@Tile) OVER (ORDER BY Grade DESC),
	   Seq        = NEXT VALUE FOR dbo.TestSequence OVER (ORDER BY Grade ASC)
  FROM @ClassRank;