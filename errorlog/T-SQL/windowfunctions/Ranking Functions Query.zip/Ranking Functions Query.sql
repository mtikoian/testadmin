USE AdventureWorks2014;
GO

-- Slide 4
SELECT  BusinessEntityID AS SalesID,
  FirstName + ' ' + LastName AS FullName,
  SalesLastYear,
  ROW_NUMBER() OVER(ORDER BY SalesLastYear ASC) 
AS RowNumber
FROM Sales.vSalesPerson;

-- Slide 7
SELECT
  BusinessEntityID AS SalesID,
  FirstName + ' ' + LastName AS FullName,
  SalesLastYear, TerritoryGroup,
  ROW_NUMBER() OVER(PARTITION BY TerritoryGroup ORDER BY SalesLastYear ASC) AS RowNumber
FROM Sales.vSalesPerson;


-- start with ROW_NUMBER, similar to an identity
SELECT
  BusinessEntityID AS SalesID,
  TerritoryGroup,
  SalesLastYear,
  ROW_NUMBER() OVER(ORDER BY SalesLastYear DESC, BusinessEntityID ASC) AS RowNumber
FROM  Sales.vSalesPerson
ORDER BY RowNumber;

-- next RANK - note certain ranks will be the same
SELECT
  BusinessEntityID AS SalesID,
  TerritoryGroup,
  SalesLastYear,
  ROW_NUMBER() OVER(ORDER BY SalesLastYear DESC, BusinessEntityID ASC) AS RowNumber,
  RANK() OVER(ORDER BY SalesLastYear Desc) AS BaseRank
FROM Sales.vSalesPerson
ORDER BY RowNumber;

-- using RANK will often to lead to gaps
select BusinessEntityID, SalesQuota,
RANK() OVER (ORDER BY SalesQuota DESC) AS QuotaRank
from Sales.vSalesPerson;

-- but not if you use DENSE_RANK
select BusinessEntityID, SalesQuota,
DENSE_RANK() OVER (ORDER BY SalesQuota DESC) AS QuotaRank
from Sales.vSalesPerson;

-- NTILE allows you to separate rankings within groups
-- specified by the number of tiles you want
-- in this case each group is split into 3 separate piles
-- and labeled accordingly
SELECT TerritoryName, TerritoryGroup,
  SalesLastYear,
  ROW_NUMBER() OVER(ORDER BY SalesLastYear DESC) AS RowNumber,
  NTILE(3) OVER(PARTITION BY TerritoryGroup ORDER BY SalesLastYear DESC) AS NTileRank
FROM  Sales.vSalesPerson
ORDER BY TerritoryGroup;




SELECT
  BusinessEntityID AS SalesID,
  TerritoryGroup,
  SalesLastYear,
  ROW_NUMBER() OVER(ORDER BY SalesLastYear DESC, BusinessEntityID ASC) AS RowNumber,
  RANK() OVER(ORDER BY SalesLastYear Desc) AS BaseRank,
  ROW_NUMBER() OVER(PARTITION BY TerritoryGroup
    ORDER BY SalesLastYear DESC) AS RowNumberByTerritory,
  RANK() OVER(PARTITION BY TerritoryGroup
    ORDER BY SalesLastYear DESC) AS SalesRank,
  DENSE_RANK() OVER(PARTITION BY TerritoryGroup
    ORDER BY SalesLastYear DESC) AS DenseRank,
  NTILE(3) OVER(PARTITION BY TerritoryGroup
    ORDER BY SalesLastYear DESC) AS NTileRank
FROM
  Sales.vSalesPerson
ORDER BY RowNumber;


	-- get all peaks/valleys
	-- calculate true peaks
	select EpochID, DefuzzificationResult, 'P' AS TheType
	into #temp
	FROM dbo.DefuzzificationResults dr
	WHERE DefuzzificationResult > (SELECT DefuzzificationResult FROM dbo.DefuzzificationResults WHERE EpochID = dr.EpochID - 1)
	AND DefuzzificationResult > (SELECT DefuzzificationResult FROM dbo.DefuzzificationResults WHERE EpochID = dr.EpochID + 1)
	
	UNION
	-- calculate true valleys
	SELECT EpochID, DefuzzificationResult, 'V' AS TheType
	FROM dbo.DefuzzificationResults dr
	WHERE DefuzzificationResult < (SELECT DefuzzificationResult FROM dbo.DefuzzificationResults WHERE EpochID = dr.EpochID - 1)
	AND DefuzzificationResult < (SELECT DefuzzificationResult FROM dbo.DefuzzificationResults WHERE EpochID = dr.EpochID + 1)
	
	UNION
	-- calculate left plateaus
	SELECT EpochID, DefuzzificationResult, 'P' AS TheType
	FROM dbo.DefuzzificationResults dr
	WHERE DefuzzificationResult > (SELECT DefuzzificationResult FROM dbo.DefuzzificationResults WHERE EpochID = dr.EpochID - 1)
	AND DefuzzificationResult = (SELECT DefuzzificationResult FROM dbo.DefuzzificationResults WHERE EpochID = dr.EpochID + 1)
	
	UNION
	-- calculate right plateaus
	SELECT EpochID, DefuzzificationResult, 'P' AS TheType
	FROM dbo.DefuzzificationResults dr
	WHERE DefuzzificationResult = (SELECT DefuzzificationResult FROM dbo.DefuzzificationResults WHERE EpochID = dr.EpochID - 1)
	AND DefuzzificationResult > (SELECT DefuzzificationResult FROM dbo.DefuzzificationResults WHERE EpochID = dr.EpochID + 1)
	
	UNION
	-- calculate left depression
	SELECT EpochID, DefuzzificationResult, 'V' AS TheType
	FROM dbo.DefuzzificationResults dr
	WHERE DefuzzificationResult < (SELECT DefuzzificationResult FROM dbo.DefuzzificationResults WHERE EpochID = dr.EpochID - 1)
	AND DefuzzificationResult = (SELECT DefuzzificationResult FROM dbo.DefuzzificationResults WHERE EpochID = dr.EpochID + 1)
	
	UNION
	-- calculate right depression
	SELECT EpochID, DefuzzificationResult, 'V' AS TheType
	FROM dbo.DefuzzificationResults dr
	WHERE DefuzzificationResult = (SELECT DefuzzificationResult FROM dbo.DefuzzificationResults WHERE EpochID = dr.EpochID - 1)
	AND DefuzzificationResult < (SELECT DefuzzificationResult FROM dbo.DefuzzificationResults WHERE EpochID = dr.EpochID + 1)
	
	UNION
	-- flat top or bottom
	SELECT EpochID, DefuzzificationResult, 'U' AS TheType
	FROM dbo.DefuzzificationResults dr
	WHERE DefuzzificationResult = (SELECT DefuzzificationResult FROM dbo.DefuzzificationResults WHERE EpochID = dr.EpochID - 1)
	AND DefuzzificationResult = (SELECT DefuzzificationResult FROM dbo.DefuzzificationResults WHERE EpochID = dr.EpochID + 1)

	-- because we have a number of plateaus/depressions, we need to combine them, we do this by grouping on the result
	-- and also counting on the epochId, we count in reverse, that way epochId + rowNumber = constant value
	-- by grouping on that constant value we group the individual peaks/valleys without mixing them up with other peaks/valleys
	-- that happen to have the same value
	SELECT DefuzzificationResult, EpochID, TheType, RANK() OVER(Partition BY DefuzzificationResult ORDER By EpochId DESC) AS 'row number'
	INTO #temp_rows
	FROM #temp t
	ORDER BY EpochID

	DROP TABLE #temp
	DECLARE @firstVal DECIMAL(8, 4)

	SELECT @firstVal = DefuzzificationResult
	FROM dbo.DefuzzificationResults
	WHERE EpochID = 1

	-- assume the second value is either a peak or valley, depending upon whether it is bigger or smaller than the first value
	UPDATE #temp_rows
	SET TheType = CASE
		WHEN DefuzzificationResult <= @firstVal THEN 'P'
		ELSE 'V'
	END
	WHERE EpochID = 2

	-- now we create the artificial group so we can separate all the peaks and valleys
	SELECT *, EpochID + [row number] AS TheGroup
	INTO #temp_rows_group
	FROM #temp_rows
	ORDER BY EpochID

	DROP TABLE #temp_rows

	-- create a dense ranking ordering peaks/valleys
	-- this will allow us to determine endpoints of respective plateaus/depressions
	SELECT DefuzzificationResult, EpochID, TheType, TheGroup, DENSE_RANK() OVER(ORDER BY TheGroup ASC) AS 'Dense Rank'
	INTO #temp_dense
	FROM #temp_rows_group
	ORDER BY EpochID

	DROP TABLE #temp_rows_group

	-- get the endpoints for any plateau/depression
	-- although we really only need the start point
	SELECT Min(EpochID) AS StartEpoch
		, Max(EpochID) AS EndEpoch
		, Max(DefuzzificationResult) AS Result
		, Floor(AVG(EpochID)) AS MidID
		, 'X' AS TheType
		, [Dense Rank]
	INTO #temp_start_end
	FROM #temp_dense
	GROUP By [Dense Rank]
	ORDER BY Min(EpochID)

	-- update all the points, now all should be either P or V
	UPDATE tse
	SET tse.TheType = td.TheType
	FROM #temp_start_end tse
	INNER JOIN #temp_dense td
	ON tse.StartEpoch = td.EpochID

	DROP TABLE #temp_dense

	-- now we can take another look, grouping on whether a point belongs to a particular P or V
	SELECT StartEpoch
		, EndEpoch
		, TheType
		, Result
		, ROW_NUMBER() OVER (ORDER BY StartEpoch ASC ) AS RowNumber
	INTO #temp_se_rows
	FROM #temp_start_end
	ORDER BY StartEpoch

	DROP TABLE #temp_start_end

	-- isolate each peak/valley get start/end points
	-- again, we are going to play the trick of creating rownumbers per peak/valley in reverse
	-- so we can create a grouping number
	SELECT StartEpoch
		, EndEpoch
		, TheType
		, Result
		, RowNumber
		, ROW_NUMBER() OVER (PARTITION BY TheType ORDER BY RowNumber DESC ) AS NewRowNumber
	INTO #temp_se_rows_new
	FROM #temp_se_rows
	ORDER BY StartEpoch

	DROP TABLE #temp_se_rows

	-- now create the combined number so we can group on it
	SELECT RowNumber + NewRowNumber AS CombRowNumber
		, TheType
		, Min(Result) AS MinResult
		, Max(Result) AS MaxResult
		, count(*) AS RecCount
	INTO #temp_se_rows_comb
	FROM #temp_se_rows_new
	GROUP BY RowNumber + NewRowNumber, TheType
	ORDER BY RowNumber + NewRowNumber

	-- we need to get the midpoint, which is where we set the actual peak or valley
	SELECT Floor((tn.StartEpoch + tn.EndEpoch) / 2) AS EpochID
		, tn.TheType
		, tn.Result
		, ROW_NUMBER() OVER (ORDER BY StartEpoch ASC ) AS RowNumber
	INTO #peaks_valleys
	FROM #temp_se_rows_comb tc
	INNER JOIN #temp_se_rows_new tn
	ON tc.CombRowNumber = (tn.RowNumber + tn.NewRowNumber)
	AND tc.TheType = tn.TheType
	WHERE (tc.MaxResult = tn.Result AND tc.TheType = 'P')
	OR (tc.MinResult = tn.Result AND tc.TheType = 'V')
	ORDER BY tn.StartEpoch

	DROP TABLE #temp_se_rows_new
	DROP TABLE #temp_se_rows_comb

	-- now that we have the peak/valley point
	-- set the desired value at that point to be the value halfway between
	-- the current peak/valley and the next peak/valley 
	UPDATE tr
	SET tr.OptimalValue = (pv1.Result + pv2.Result) / 2
	FROM dbo.TestResults tr
	INNER JOIN #peaks_valleys pv1
	ON tr.EpochID = pv1.EpochID
	LEFT JOIN #peaks_valleys pv2
	ON pv1.RowNumber = pv2.RowNumber - 1

	-- calculate the slope of the line connecting the points
	-- this becomes the 2nd derivative, which we will use
	-- to calculate more optimal values for each point
	SELECT tr1.EpochID AS X1
		, tr2.EpochID AS X2
		, tr1.OptimalValue AS Y1
		, tr2.OptimalValue AS Y2
		, CASE WHEN tr2.EpochID = tr1.EpochID THEN 0
		ELSE (tr2.OptimalValue - tr1.OptimalValue) / (tr2.EpochID - tr1.EpochID) 
		END AS Slope
	INTO #slopes
	FROM dbo.TestResults tr1
	INNER JOIN #peaks_valleys pv1
	ON tr1.EpochID = pv1.EpochID
	LEFT JOIN #peaks_valleys pv2
	ON pv1.RowNumber = pv2.RowNumber - 1
	LEFT JOIN dbo.TestResults tr2
	ON tr2.EpochID = pv2.EpochID
	WHERE tr1.OptimalValue IS NOT NULL

	DROP TABLE #peaks_valleys

	-- apply the second derivative to calculate the new first derivative
	-- of our 'optimal' function
	UPDATE tr
	SET tr.OptimalValue = (EpochID - X1) * Slope + Y1
	FROM #slopes s
	INNER JOIN dbo.TestResults tr
	ON tr.EpochID BETWEEN s.X1 AND s.X2
	WHERE tr.OptimalValue IS NULL

	DROP TABLE #slopes

	-- for those values not calculate, fill in with 'real' value by default
	UPDATE dbo.TestResults
	SET OptimalValue = ValueAfterInference
	WHERE OptimalValue IS NULL

	-- calculate error
	UPDATE dbo.TestResults
	SET Error = ABS(ValueAfterInference - OptimalValue)

	SELECT Sum(Error) As TotalError
	FROM dbo.TestResults
