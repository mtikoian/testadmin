DECLARE @SampleData TABLE (
  AccountId INTEGER,
  TranDate  DATE,
  TranAmt   NUMERIC(8,2));

INSERT INTO @SampleData 
            (AccountId, TranDate, TranAmt)
     VALUES (1, '2011-01-01', 500),
            (1, '2011-01-15', 50),
            (1, '2011-01-22', 250),
            (1, '2011-01-24', 75),
            (1, '2011-01-26', 125),
            (1, '2011-01-28', 175),
            
            (2, '2011-01-01', 500),
            (2, '2011-01-15', 50),
            (2, '2011-01-22', 25),
            (2, '2011-01-23', 125),
            (2, '2011-01-26', 200),
            (2, '2011-01-29', 250),

            (3, '2011-01-01', 500),
            (3, '2011-01-15', 50 ),
            (3, '2011-01-22', 5000),
            (3, '2011-01-25', 550),
            (3, '2011-01-27', 95 ),
            (3, '2011-01-30', 2500);

SELECT AccountId ,
       TranDate ,
       TranAmt,
       -- average of all transactions
       Average  = AVG(TranAmt) OVER (PARTITION BY AccountId),
       -- total # of transactions
       TranQty  = COUNT(*)     OVER (PARTITION BY AccountId),
       -- smallest of the transactions
       SmallAmt = MIN(TranAmt) OVER (PARTITION BY AccountId),
       -- largest of the transactions
       LargeAmt = MAX(TranAmt) OVER (PARTITION BY AccountId),
       -- total of all transactions
       TotalAmt = SUM(TranAmt) OVER (PARTITION BY AccountId)
  FROM @SampleData
 ORDER BY AccountId, TranDate;
