-- determine the gaps in a column
DECLARE @Gaps TABLE (col1 int PRIMARY KEY CLUSTERED);
 
INSERT INTO @Gaps (col1)
VALUES (1), (2), (3),
       (50), (51), (52), (53), (54), (55),
       (100), (101), (102),
       (500),
       (950), (951), (952),
	   (954);

-- Compare the value of the current row to the next row. 
-- If > 1, then there is a gap.
WITH cte AS
(
SELECT curr = col1,
       nxt = LEAD(col1, 1, NULL)
             OVER (ORDER BY col1)
  FROM @Gaps
)
SELECT [Start of Gap] = cte.curr + 1,
       [End of Gap] = cte.nxt - 1
  FROM cte
 WHERE cte.nxt- cte.curr > 1;