DECLARE @Grades TABLE (
    StudentID INT,
    Grade     INT);

INSERT INTO @Grades
VALUES (1, 100),
       (2, 100),
       (3, 99),
       (4, 99),
       (5, 95),
       (6, 90),
       (7, 88),
       (8, 85),
       (9, 82),
       (10,78)
 
SELECT StudentID,
       Grade,
       CumeDist    = CUME_DIST()
                     OVER (ORDER BY Grade),
       PercentRank = PERCENT_RANK()
                     OVER (ORDER BY Grade)
  FROM @Grades;