DECLARE @SampleData TABLE (
  AccountId INTEGER,
  TranDate  DATE,
  TranAmt   NUMERIC(8,2));

INSERT INTO @SampleData 
            (AccountId, TranDate, TranAmt)
     VALUES (1, '20110101', 500),
            (1, '20110115', 50),
            (1, '20110122', 250),
            (1, '20110124', 75),
            (1, '20110126', 125),
            (1, '20110128', 175),
            
            (2, '20110101', 500),
            (2, '20110115', 50),
            (2, '20110122', 25),
            (2, '20110123', 125),
            (2, '20110126', 200),
            (2, '20110129', 250),

            (3, '20110101', 500),
            (3, '20110115', 50 ),
            (3, '20110122', 5000),
            (3, '20110125', 550),
            (3, '20110127', 95 ),
            (3, '20110130', 2500);

SELECT AccountId ,
       TranDate ,
       TranAmt,
       -- average of the current and previous 2 transactions
       SlideAvg      = AVG(TranAmt) OVER (PARTITION BY AccountId
                                              ORDER BY TranDate
                                               ROWS BETWEEN 2 PRECEDING AND CURRENT ROW),
       -- total # of the current and previous 2 transactions
       SlideTranQty  = COUNT(*)     OVER (PARTITION BY AccountId 
                                              ORDER BY TranDate
                                               ROWS BETWEEN 2 PRECEDING AND CURRENT ROW),
       -- smallest of the current and previous 2 transactions
       SlideSmallAmt = MIN(TranAmt) OVER (PARTITION BY AccountId 
                                              ORDER BY TranDate
                                               ROWS BETWEEN 2 PRECEDING AND CURRENT ROW),
       -- largest of the current and previous 2 transactions
       SlideLargeAmt = MAX(TranAmt) OVER (PARTITION BY AccountId 
                                              ORDER BY TranDate
                                               ROWS BETWEEN 2 PRECEDING AND CURRENT ROW),
       -- total of the current and previous 2 transactions
       SlideTotalAmt = SUM(TranAmt) OVER (PARTITION BY AccountId 
                                              ORDER BY TranDate
                                               ROWS BETWEEN 2 PRECEDING AND CURRENT ROW)
  FROM @SampleData
 ORDER BY AccountId, TranDate;
