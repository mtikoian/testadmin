IF OBJECT_ID('tempdb..#HistoryLoc','U') IS NOT NULL DROP TABLE #HistoryLoc;

CREATE TABLE #HistoryLoc (
  TagNo         INTEGER,
  FirstSeen     DATETIME,
  LocationGroup VARCHAR(50)
);

INSERT INTO #HistoryLoc (TagNo, FirstSeen, LocationGroup) 
     VALUES (1,'2011-02-24T06:12:55.420','InED'),
            (1,'2011-02-24T06:43:49.540','InOther'),
            (1,'2011-02-24T07:06:50.053','InED'),
            (1,'2011-02-24T07:32:09.593','InOther'), 
            (1,'2011-02-25T00:01:25.343','InOther'),
            (1,'2011-02-25T14:48:01.417','InOther'),
			
			
			(2,'2011-03-14T16:52:39.623','InOther'),
            (2,'2011-03-14T16:53:51.843','InED'),
            (2,'2011-03-14T16:55:33.577','InED'),
            (2,'2011-03-14T16:58:06.387','InED'),
            (2,'2011-03-14T17:00:24.873','InRadiology'),
            (2,'2011-03-14T17:02:59.747','InED'),
            (2,'2011-03-14T17:04:57.993','InOther'),
            (2,'2011-03-14T19:21:09.213','InED'),
            (2,'2011-03-14T19:22:28.493','InOther'),
            (2,'2011-03-14T19:23:09.117','InOther'),
            (2,'2011-04-05T19:34:37.017','InOther');

SELECT * 
  FROM #HistoryLoc
 ORDER BY TagNo, FirstSeen;

/*  Goal:
For each tag number, return the trip number for each visit to a location.
Visits are sorted by FirstSeen date by tag number.
Multiple rows that sequentially are in the same location are to be the same trip.
Return trip as: LocationGroup + "_Trip" + Trip #
*/

WITH cte AS
(
SELECT *,
       RN1 = ROW_NUMBER() 
             OVER (PARTITION BY TagNo 
                       ORDER BY FirstSeen),
       RN2 = ROW_NUMBER() 
             OVER (PARTITION BY TagNo, LocationGroup 
                       ORDER BY FirstSeen)
  FROM #HistoryLoc 
)
SELECT * 
  FROM cte
 ORDER BY TagNo, FirstSeen;



WITH cte AS
(
SELECT *,
       RN1 = ROW_NUMBER() 
             OVER (PARTITION BY TagNo 
                       ORDER BY FirstSeen),
       RN2 = ROW_NUMBER() 
             OVER (PARTITION BY TagNo, LocationGroup 
                       ORDER BY FirstSeen)
  FROM #HistoryLoc 
)
, cte2 AS (
SELECT *, Grp = RN1 - RN2
  FROM cte
)
SELECT *
  FROM cte2
ORDER BY TagNo, FirstSeen;



WITH cte AS
(
SELECT *,
       RN1 = ROW_NUMBER() 
             OVER (PARTITION BY TagNo 
                       ORDER BY FirstSeen),
       RN2 = ROW_NUMBER() 
             OVER (PARTITION BY TagNo, LocationGroup 
                       ORDER BY FirstSeen)
  FROM #HistoryLoc 
)
, cte2 AS (
SELECT *, Grp = RN1 - RN2
  FROM cte
)
, cte3 AS (
SELECT *, 
       Ranking   = RANK() 
                   OVER (PARTITION BY TagNo, LocationGroup 
                             ORDER BY Grp)
  FROM cte2
)
SELECT *
  FROM cte3
 ORDER BY TagNo, FirstSeen;


WITH cte AS
(
SELECT *,
       RN1 = ROW_NUMBER() 
             OVER (PARTITION BY TagNo 
                       ORDER BY FirstSeen),
       RN2 = ROW_NUMBER() 
             OVER (PARTITION BY TagNo, LocationGroup 
                       ORDER BY FirstSeen)
  FROM #HistoryLoc 
)
, cte2 AS (
SELECT *, Grp = RN1 - RN2
  FROM cte
)
, cte3 AS (
SELECT *, 
       Ranking   = RANK() 
                   OVER (PARTITION BY TagNo, LocationGroup 
                             ORDER BY Grp),
       DenseRank = DENSE_RANK() 
                   OVER (PARTITION BY TagNo, LocationGroup 
                             ORDER BY Grp)
  FROM cte2
)
SELECT *
  FROM cte3
 ORDER BY TagNo, FirstSeen;



WITH cte AS
(
SELECT *,
       RN1 = ROW_NUMBER() 
             OVER (PARTITION BY TagNo 
                       ORDER BY FirstSeen),
       RN2 = ROW_NUMBER() 
             OVER (PARTITION BY TagNo, LocationGroup 
                       ORDER BY FirstSeen)
  FROM #HistoryLoc 
)
, cte2 AS (
SELECT *, Grp = RN1 - RN2
  FROM cte
)
, cte3 AS (
SELECT *, 
       Ranking   = RANK() 
                   OVER (PARTITION BY TagNo, LocationGroup 
                             ORDER BY Grp),
       DenseRank = DENSE_RANK() 
                   OVER (PARTITION BY TagNo, LocationGroup 
                             ORDER BY Grp)
  FROM cte2
)
, cte4 AS
(
SELECT *, Trip = LocationGroup + '_Trip' + CONVERT(VARCHAR(10), DenseRank)
  FROM cte3
)
SELECT *
  FROM cte4
 ORDER BY TagNo, FirstSeen;
