DECLARE @SalesByQty TABLE (
    Dept  int,
    FY    char(4),
    Qtr   tinyint,
    Sales money
);

INSERT INTO @SalesByQty
VALUES (1, '2005', 1, 8461.89),
       (1, '2005', 2, 9164.86),
       (1, '2005', 3, 9987.78),
       (1, '2005', 4, 12817.96),
       (1, '2006', 1, 9517.85),
       (1, '2006', 2, 9625.45),
       (1, '2006', 3, 10852.68),
       (1, '2006', 4, 14578.12);

SELECT Dept, 
       FY, 
       Qtr, 
       Sales,
       DeltaLastQtr = Sales - LAG(Sales, 1) 
                              OVER (PARTITION BY Dept 
                                        ORDER BY FY, Qtr),
       DeltaLastFY  = Sales - LAG(Sales, 4) 
                              OVER (PARTITION BY Dept 
                                        ORDER BY FY, Qtr)
  FROM @SalesByQty s
  ORDER BY Dept, FY, Qtr;