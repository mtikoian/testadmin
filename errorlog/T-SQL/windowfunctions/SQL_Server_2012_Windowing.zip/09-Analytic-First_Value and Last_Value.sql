USE AdventureWorks2008R2;

/*
In this database, there is a Sales.SalesOrderHeader table, 
which has information about each order. This information 
includes CustomerID, OrderDate, and TotalDue columns.

Let�s run a query that shows, for each CustomerID, the 
OrderDate for when they placed their least and most 
expensive orders.
*/

SELECT DISTINCT TOP (20)
       CustomerID,
       OrderDateLow  = FIRST_VALUE(OrderDate)
                       OVER (PARTITION BY CustomerID
                                 ORDER BY TotalDue
                                  ROWS BETWEEN UNBOUNDED PRECEDING
                                           AND UNBOUNDED FOLLOWING),
       OrderDateHigh = LAST_VALUE(OrderDate)
                       OVER (PARTITION BY CustomerID
                                 ORDER BY TotalDue
                                  ROWS BETWEEN UNBOUNDED PRECEDING
                                           AND UNBOUNDED FOLLOWING)
  FROM Sales.SalesOrderHeader
 ORDER BY CustomerID;