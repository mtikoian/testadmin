USE master;
GO

SET NOCOUNT ON;

SELECT NAME
	, CASE [TYPE]
		WHEN 'V'
			THEN 'DMV'
		WHEN 'IF'
			THEN 'DMF'
		ELSE 'ERROR?'
		END AS [DMO TYPE]
FROM sys.sysobjects
WHERE NAME LIKE 'dm_%'
ORDER BY NAME;
GO
