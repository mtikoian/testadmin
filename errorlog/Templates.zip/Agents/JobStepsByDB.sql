USE msdb;
GO

--
-- Agent Schedule Report
-- Nem W Schlecht
-- Multiband Corp., Copyright (C) 2013
--

SET NOCOUNT ON;

SELECT
	sj.name
	, js.step_id
	, js.command
	--, msdb.dbo.agent_datetime(ss.active_start_date, ss.active_start_time) AS 'StartDate'
	--, sjs.next_run_date
	--, CASE WHEN sjs.next_run_date = '0'
	--				THEN '19010101'
	--			ELSE sjs.next_run_date
	--	END as 'next date'
	--, sjs.next_run_time
	, CASE WHEN ss.freq_type = 1
			THEN 'Once'
		WHEN ss.freq_type = 4
			THEN 'Daily'
		WHEN ss.freq_type = 8
			THEN 'Weekly'
		WHEN ss.freq_type = 16
			THEN 'Monthly'
		WHEN ss.freq_type = 32
			THEN 'Monthly (rel)'
		WHEN ss.freq_type = 64
			THEN 'Startup'
		WHEN ss.freq_type = 128
			THEN 'Idle'
		ELSE 'UNKNOWN'
	END AS 'FrequencyEvery'
	, CASE WHEN ss.freq_subday_interval = 0
			THEN '-'
		ELSE CAST(ss.freq_subday_interval AS VARCHAR(50)) + ' ' + CASE WHEN ss.freq_subday_type = 1
				THEN 'Specified Time'
			WHEN ss.freq_subday_type = 2
				THEN 'Seconds'
			WHEN ss.freq_subday_type = 4
				THEN 'Minutes'
			WHEN ss.freq_subday_type = 8
				THEN 'Hours'
			ELSE 'UNKNOWN'
		END
	END AS 'SubdayEvery'
	, CASE WHEN sj.enabled = 1
			THEN msdb.dbo.agent_datetime(
				CASE WHEN sjs.next_run_date = '0'
					THEN '19010101'
				ELSE sjs.next_run_date
				END
				, sjs.next_run_time)
		ELSE '19010101 00:00:00'
	END AS 'NextRun'
	--, *
FROM sysjobschedules AS sjs
	JOIN sysjobs sj
		ON sjs.job_id = sj.job_id
	JOIN sysschedules as ss
		ON sjs.schedule_id = ss.schedule_id
	JOIN sysjobsteps AS js
		ON sj.job_id = js.job_id
WHERE js.database_name = 'BIDataWareHouse'
ORDER BY sj.name
-- ORDER BY  msdb.dbo.agent_datetime(active_start_date, active_start_time)
;

GO
