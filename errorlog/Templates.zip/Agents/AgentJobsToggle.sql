USE msdb;
GO

SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @Action VARCHAR(100) = 'Enable';
--DECLARE @Action VARCHAR(100) = 'Disable';

PRINT 'USE msdb
GO';

DECLARE @ActionBit VARCHAR(1);
DECLARE @ToggleBit VARCHAR(1);
IF (@Action = 'Enable')
BEGIN
	SET @ActionBit = 1;
	SET @ToggleBit = 0;
	PRINT CHAR(10) + '-- Enable all disabled jobs' + CHAR(10);
END;
ELSE
BEGIN
	SET @ActionBit = 0;
	SET @ToggleBit = 1;
	PRINT CHAR(10) + '-- Disable all enabled jobs' + CHAR(10);
END;

SELECT
	'-- ' + CHAR(10)
	+ '-- '
	+ sj.name + ' '
	+ REPLICATE('-', 50 - DATALENGTH(sj.name)/2)
	+ ' '
	+ CAST(msdb.dbo.agent_datetime(js.next_run_date, js.next_run_time) AS VARCHAR(50))
	+ CHAR(10)
	--+ 'USE [msdb]' + CHAR(10)
	--+ 'GO' + CHAR(10)
	--+ '-- '
	+ 'EXEC msdb.dbo.sp_update_job ' + CHAR(10)
	+ '    @job_id=N''' + CAST(sj.job_id AS VARCHAR(40)) + '''' + CHAR(10)
	+ '--    @job_name=N''' + sj.name + '''' + CHAR(10)
	+ '    , @enabled=' + @ActionBit + CHAR(10)
	+ ';' + CHAR(10)
	+ CASE WHEN (@ActionBit = 1)
			THEN '--  EXEC msdb.dbo.sp_start_job @job_id = '''
				+ CAST(sj.job_id AS VARCHAR(40))
				+ ''';' + CHAR(10)
			ELSE ''
		END
FROM sysjobs AS sj
	INNER JOIN sysjobschedules AS js
		ON sj.job_id = js.job_id
WHERE 1=1
	--AND sj.enabled = @ToggleBit
	AND js.next_run_date > 0
	AND js.schedule_id = (SELECT MIN(schedule_id) FROM sysjobschedules WHERE job_id = sj.job_id)
--	AND msdb.dbo.agent_datetime(next_run_date, next_run_time) > GETDATE()
--ORDER BY msdb.dbo.agent_datetime(next_run_date, next_run_time) DESC
ORDER BY sj.name
;

GO
