USE msdb;
GO

SET NOCOUNT ON;

DECLARE @Search VARCHAR(100) = '';-- search job names

SELECT j.NAME
	, jh.step_id
	, jh.step_name
	--, sql_severity
	, jh.message
	, jh.run_status
	, jh.run_duration
	, jh.operator_id_emailed AS 'email'
	, jh.retries_attempted AS 'retries'
	, msdb.dbo.agent_datetime(jh.run_date, jh.run_time) AS 'RunDateTime'
--, *
FROM sysjobhistory AS jh
	JOIN sysjobs AS j
		ON j.job_id = jh.job_id
WHERE j.NAME LIKE '%' + @Search + '%'
ORDER BY msdb.dbo.agent_datetime(jh.run_date, jh.run_time) DESC
;

GO
