USE msdb;
GO

SET NOCOUNT ON;

SELECT j.NAME AS 'JobName'
	, s.step_id AS 'Step'
	, s.step_name AS 'StepName'
	, msdb.dbo.agent_datetime(h.run_date, h.run_time) AS 'RunDateTime'
	--, msdb.dbo.agent_datetime() AS 'EndDateTime'
	, ((h.run_duration / 10000 * 3600 + (h.run_duration / 100) % 100 * 60 + h.run_duration % 100 + 31) / 60) AS 'RunDurationMinutes'
	, CAST(s.command AS VARCHAR(1000)) AS command
	, CAST(h.message AS VARCHAR(1000)) AS message
FROM msdb.dbo.sysjobs AS j
	INNER JOIN msdb.dbo.sysjobsteps AS s
		ON j.job_id = s.job_id
	INNER JOIN msdb.dbo.sysjobhistory AS h
		ON s.job_id = h.job_id
			AND s.step_id = h.step_id
			AND h.step_id <> 0
WHERE j.enabled = 1
	AND CAST(CAST(h.run_date AS VARCHAR(30)) AS DATETIME) >= DATEADD(day, - 4, GETDATE())
ORDER BY JobName
	, RunDateTime;
GO


