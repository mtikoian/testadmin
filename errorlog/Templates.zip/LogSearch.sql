USE master;
GO

SET NOCOUNT ON;

DECLARE @log_type INT;
DECLARE @log_depth INT;
DECLARE @Search1 VARCHAR(200);
DECLARE @Search2 VARCHAR(200);

SET @log_type = 1;				-- 1=error log, 2=agent log
SET @log_depth = 1;				-- max log + 1 to search
SET @Search1 = '';
SET @Search2 = '';

--DECLARE @ServerProductVersion VARCHAR(100);
--SET @ServerProductVersion = CAST(SERVERPROPERTY('ProductVersion') AS VARCHAR(100));
--DECLARE @ServerProductVersionMajor INT;
--SET @ServerProductVersionMajor = PARSENAME(@ServerProductVersion, 4);

DECLARE @logfiles TABLE (
	fileno INT NULL
	, filedate DATETIME NULL
	, filesize INT NULL
);

DECLARE @log TABLE (
	LogDate DATETIME NULL
	, ErrorLevel VARCHAR(100) NULL
	, LogText VARCHAR(max) NULL
);

INSERT INTO @logfiles
EXEC sp_enumerrorlogs
	@p1 = @log_type
;

DECLARE lfcur CURSOR LOCAL READ_ONLY FORWARD_ONLY
FOR
SELECT fileno
FROM @logfiles
WHERE fileno < @log_depth
ORDER BY fileno
;

OPEN lfcur;

DECLARE @cur_fileno INT;

FETCH NEXT
FROM lfcur
INTO @cur_fileno
;

WHILE (@@FETCH_STATUS = 0)
BEGIN
	INSERT INTO @log
	EXEC sp_readerrorlog
		@p1 = @cur_fileno
		, @p2 = @log_type
		, @p3 = @Search1
		, @p4 = @Search2
	;

	FETCH NEXT
	FROM lfcur
	INTO @cur_fileno
	;
END;

CLOSE lfcur;
DEALLOCATE lfcur;

SELECT LogDate
	, ErrorLevel
	, LogText
FROM @log
ORDER BY LogDate DESC
;

GO
