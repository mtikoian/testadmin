USE master;
GO

SET NOCOUNT ON;

DECLARE @DatabaseName VARCHAR(50)
	, @SnapshotName VARCHAR(50)
;

PRINT 'USE master' + CHAR(10)
	+ 'GO' + CHAR(10) + CHAR(10)
;
		
DECLARE snapdbs CURSOR LOCAL READ_ONLY FORWARD_ONLY
FOR
SELECT orig.NAME
	, snap.NAME
FROM sys.databases AS orig
JOIN sys.databases AS snap
	ON snap.source_database_id = orig.database_id
;


OPEN snapdbs;

FETCH NEXT FROM snapdbs
INTO @DatabaseName
	, @SnapshotName
;

WHILE (@@FETCH_STATUS = 0)
BEGIN
	PRINT 'PRINT ''Restoring database: ' + @DatabaseName + '''';
	PRINT 'RESTORE DATABASE ' + @DatabaseName + CHAR(10)
		+ 'FROM DATABASE_SNAPSHOT = ''' + @SnapshotName + ''';' + CHAR(10)
		+ 'GO' + CHAR(10) + CHAR(10)
	;
		
	FETCH NEXT FROM snapdbs
	INTO @DatabaseName
		, @SnapshotName
	;
END;

CLOSE snapdbs;
DEALLOCATE snapdbs;

GO
