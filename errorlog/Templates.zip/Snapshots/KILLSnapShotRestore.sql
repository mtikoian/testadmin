USE master;
GO

SET NOCOUNT ON;


DECLARE @rootDBname VARCHAR(100) = 'ReportServer2008';


DECLARE @SQL NVARCHAR(200);

DECLARE auto_kill CURSOR LOCAL FORWARD_ONLY READ_ONLY
FOR
SELECT 'KILL ' + CAST(sp.spid AS VARCHAR(10)) AS killcmd
FROM dbo.sysprocesses AS sp
	INNER JOIN sys.databases AS sd
		ON sd.database_id = sp.dbid
WHERE sp.hostprocess <> ''
	AND sp.program_name <> 'sqlcheck'
	and sd.name = @rootDBname
ORDER BY sp.spid
;

OPEN auto_kill;

FETCH NEXT
FROM auto_kill
INTO @SQL;

WHILE (@@FETCH_STATUS = 0)
BEGIN
	PRINT @SQL;
	
	EXEC sp_executesql @SQL;

	FETCH NEXT
	FROM auto_kill
	INTO @SQL;
END

CLOSE auto_kill;
DEALLOCATE auto_kill;


PRINT 'Restoring database: ' + @rootDBname
DECLARE @SQLS NVARCHAR(1000) = '
RESTORE DATABASE [' + @rootDBname + ']
FROM DATABASE_SNAPSHOT = ''' + @rootDBname + '_snapshot''
'
EXECUTE sys.sp_executesql @SQLS;
PRINT 'Done'