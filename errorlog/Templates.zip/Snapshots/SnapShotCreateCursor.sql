:out STDOUT

USE master;
GO

SET NOCOUNT ON;

DECLARE @DatabaseName VARCHAR(50)
	, @FileName VARCHAR(50)
	, @SnapshotName VARCHAR(50)
	, @FilePath VARCHAR(100) = 'E:\MSSQL14\Snapshots'
	, @DBPatternSearch VARCHAR(50) = ''
;

PRINT 'USE master
GO

';

DECLARE dbnamecur CURSOR LOCAL READ_ONLY FORWARD_ONLY
FOR
SELECT db.NAME AS [DATABASE Name]
	, mf.NAME AS [FileName]
	, db.NAME + '_snapshot' AS SnapshotName
FROM sys.master_files AS mf
	INNER JOIN sys.databases AS db
		ON mf.database_id = db.database_id
WHERE db.NAME LIKE '%' + @DBPatternSearch + '%'
	AND mf.type_desc = 'ROWS'
	AND db.source_database_id IS NULL
	AND db.NAME NOT IN (
		'master'
		, 'model'
		, 'msdb'
		, 'tempdb'
		)
ORDER BY db.NAME;


OPEN dbnamecur;

FETCH NEXT
FROM dbnamecur
INTO @DatabaseName
	, @FileName
	, @SnapshotName
;

WHILE (@@FETCH_STATUS = 0)
BEGIN
	PRINT 'CREATE DATABASE ' + @SnapshotName + CHAR(10)
		+ '    ON ( ' + CHAR(10)
		+ '         NAME = ' + @FileName + CHAR(10)
		+ '         , FILENAME = ''' + @FilePath + '\' + @SnapshotName + '''' + CHAR(10)
		+ '    )' + CHAR(10)
		+ '    AS SNAPSHOT OF ' + @DatabaseName + CHAR(10)
		+ ';';
	PRINT 'GO
	';

	FETCH NEXT
	FROM dbnamecur
	INTO @DatabaseName
		, @FileName
		, @SnapshotName
	;
END;

CLOSE dbnamecur;

DEALLOCATE dbnamecur;

GO
