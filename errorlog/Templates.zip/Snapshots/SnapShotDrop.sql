:out STDOUT

USE master;
GO

SET NOCOUNT ON;

PRINT 'USE master';
PRINT 'GO

';

SELECT  'DROP DATABASE ' + name + ';'
FROM    sys.databases
--WHERE name LIKE '%_snapshot'
WHERE source_database_id IS NOT NULL
	AND is_read_only = 1
;

GO
