
SET NOCOUNT ON;

--
-- Dump all objects in a schema
--

SELECT *
FROM sys.objects
--WHERE schema_id = SCHEMA_ID('<Schema Name,,>');
