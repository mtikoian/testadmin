USE freetds;
GO
-- =========================================================================
-- Title: Info on DB objects
-- Author: novial\nem
-- Create Date: 2017-05-07 12:33:52
-- Copyright: Border States Electric, Copyright (C) 2015
-- Description: 
-- =========================================================================
SET XACT_ABORT ON;
SET NOCOUNT ON;
-- Make sure we're not in a transaction
IF (@@TRANCOUNT > 0)
BEGIN
	ROLLBACK;
END;

BEGIN TRAN;
SAVE TRAN nws_ssms;

-- this works for tables and stored procedures
exec sp_help 'dbo.dbsizelog';

select * from Information_schema.Columns
where table_name = 'dbsizelog'

-- Comment the next line to commit this query
ROLLBACK TRAN nws_ssms;
COMMIT;

GO