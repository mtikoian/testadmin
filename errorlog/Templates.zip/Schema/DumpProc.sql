USE freetds;
GO
-- =========================================================================
-- Title: <Title,,>
-- Author: novial\nem
-- Create Date: 2017-05-07 12:40:44
-- Copyright: Border States Electric, Copyright (C) 2015
-- Description: <Description,,>
-- =========================================================================
SET XACT_ABORT ON;
SET NOCOUNT ON;
-- Make sure we're not in a transaction
IF (@@TRANCOUNT > 0)
BEGIN
	ROLLBACK;
END;

BEGIN TRAN;
SAVE TRAN nws_ssms;

-- :out stdout

--exec sp_helptext 'dbo.big_proc'  --- THIS IS BUGGY

-- SELECT OBJECT_DEFINITION (OBJECT_ID(N'big_proc'));  
--SELECT OBJECT_DEFINITION (OBJECT_ID(N'big_proc'));  
exec sp_helptext2 'dbo.big_proc'

--select * from sys.sql_modules

-- Comment the next line to commit this query
ROLLBACK TRAN nws_ssms;
COMMIT;

GO