USE freetds;
GO

--select * from sys.synonyms;
SELECT 'USE ' + DB_NAME() + ';' + CHAR(13) + 'GO' + CHAR(13) + CHAR(13)
	+ 'CREATE SYNONYM [' + sch.NAME + '].[' + syn.NAME + ']' + CHAR(13)
	+ 'FOR ' + syn.base_object_name + ';' + CHAR(13)
	+ 'GO' + CHAR(13)
FROM sys.synonyms AS syn
INNER JOIN sys.objects AS obj
	ON syn.object_id = obj.object_id
INNER JOIN sys.schemas AS sch
	ON syn.schema_id = sch.schema_id
WHERE syn.NAME = 'testsyn';
