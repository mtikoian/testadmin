SET NOEXEC OFF;
:setvar IsSqlCmdEnabled "True"
GO
IF ('$(IsSqlCmdEnabled)' = '$' + '(IsSqlCmdEnabled)')
BEGIN
  PRINT('Use SqlCmd-mode!!');
  SET NOEXEC ON;
  -- RAISERROR ('This script must be run in SQLCMD mode.', 20, 1) WITH LOG
END

SELECT 'Running'
