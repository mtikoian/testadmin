-- =========================================================================
-- Title: Process Missing AX 
-- Author: Russ Conklin
-- Create Date: 2014-01-01
-- Copyright: Goodman Networks/Multiband, Copyright (C) 2014
-- Description: Update the date time and transaction ID
-- Modified: Nem W Schlecht / 2014-11-17 / Add logic/config
-- =========================================================================

-- :connect mb-nd01-sc-002
USE SPIdb
GO
SET NOCOUNT ON;


-- UPDATE THESE
DECLARE @triggeredDateStart DATETIME = '2014-11-12'
DECLARE @triggeredDateEnd DATETIME = '2014-11-14'
DECLARE @typeID INT = 13;
DECLARE @doUpdates BIT = 0;
DECLARE @delay INT = 0;		-- set to zero for no sleeping


DECLARE @tranID BIGINT;

DECLARE unsentCursor CURSOR LOCAL FORWARD_ONLY READ_ONLY 
FOR
SELECT t.intASDTTransactionID
--t.intTransactionTypeID, CONVERT(date, t.dtetriggeredDateTime), COUNT(1)
FROM dbo.tblASDTTransaction AS t
	INNER JOIN dbo.tblASDTErrorLog AS e
		ON e.intASDTTransactionID = t.intASDTTransactionID
WHERE CONVERT(DATE, t.dtetriggeredDateTime) >= @triggeredDateStart
	AND CONVERT(DATE, t.dtetriggeredDateTime) <= @triggeredDateEnd
	AND t.dteDateSent IS NULL
	AND t.intTransactionTypeID = @typeID
	AND t.intASDTDetailID IS NULL
	AND e.txtDescription = 'sp_OAMethod http status        500'
;

--GROUP BY t.intTransactionTypeID, CONVERT(date, t.dtetriggeredDateTime)
--ORDER BY CONVERT(date, t.dtetriggeredDateTime)
OPEN unsentCursor;

FETCH NEXT
FROM unsentCursor
INTO @tranID
;

DECLARE @count INT = 0;

WHILE @@FETCH_STATUS = 0
BEGIN
	SET @count = @count + 1;
	
	PRINT CAST(@count AS VARCHAR(10)) + ' - ' + CAST(@tranID AS VARCHAR(40));
	
	IF (@doUpdates = 1)
	BEGIN
		EXECUTE sp_xmlPost
			sp_sel_XML_ASDT13
			, @tranID
		;

		UPDATE dbo.tblASDTTransaction
		SET dteDateSent = GETDATE()
			, bitSentAfterError = 1
		WHERE intASDTTransactionID = @tranID
		;

		UPDATE dbo.tblASDTErrorLog
		SET bitErrorFixed = 1
		WHERE intASDTTransactionID = @tranID
		;
		
		IF (@delay > 0)
		BEGIN
			DECLARE @sleep VARCHAR(20) = '00:00:' + CAST(@delay AS VARCHAR(2));
			WAITFOR DELAY @sleep;
		END
	END;

	FETCH NEXT
	FROM unsentCursor
	INTO @tranID
	;
END;

CLOSE unsentCursor;

DEALLOCATE unsentCursor;

--SELECT  *
--FROM    dbo.tblASDTErrorLog
--WHERE dteErrorDateTime >= '2013-09-24'
--SELECT  *
--FROM    dbo.tblASDTTransaction
--WHERE intASDTTransactionID = 28164797
