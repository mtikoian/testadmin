USE AXDB_Prod
GO
-- =========================================================================
-- Title: <Title,,>
-- Author: Nem W Schlecht
-- Create Date: <Create Date,,>
-- Copyright: Goodman Networks Field Services, Copyright (C) 2015
-- Description: <Description,,>
-- =========================================================================
SET XACT_ABORT ON;
SET NOCOUNT ON;

-- Make sure we're not in a transaction
IF (@@TRANCOUNT > 0)
BEGIN
	ROLLBACK;
END;

BEGIN TRANSACTION;

SAVE TRAN nws_ssms;

SELECT a.USERID AS [User]
	, a.CMPNYNAM AS [Company]
	, LEFT(CONVERT(VARCHAR, LOGINDAT, 120), 10) AS LoginDate
	, (
		SELECT count(*)
		FROM dynamics.dbo.activity
		) AS TotalUserCount
FROM dynamics.dbo.activity AS a
WHERE DATEPART(day, a.logindat) < DATEPART(day, GETDATE())
ORDER BY a.Logindat;

-- Comment the next line to commit this query
ROLLBACK TRANSACTION nws_ssms;

COMMIT;
GO


