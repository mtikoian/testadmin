-- =========================================================================
-- Title: Identify Missing AX transaction
-- Author: Nem W Schlecht
-- Create Date: 2014-11-17
-- Copyright: Goodman Networks/Multiband, Copyright (C) 2014
-- Description: Query from Kyle
-- =========================================================================

USE SPIdb
GO

DECLARE @triggeredDateStart DATETIME = '2014-11-12'
DECLARE @triggeredDateEnd DATETIME = '2014-11-19'

SELECT --t.intASDTTransactionID
	t.intTransactionTypeID
	, CONVERT(DATE, t.dtetriggeredDateTime)
	, COUNT(1) AS CS
FROM dbo.tblASDTTransaction AS t
	INNER JOIN dbo.tblASDTErrorLog AS e
		ON e.intASDTTransactionID = t.intASDTTransactionID
WHERE CONVERT(DATE, t.dtetriggeredDateTime) >= @triggeredDateStart
	AND CONVERT(DATE, t.dtetriggeredDateTime) <= @triggeredDateEnd
	AND t.dteDateSent IS NULL
	AND t.intASDTDetailID IS NULL
	AND e.txtDescription = 'sp_OAMethod http status        500'
GROUP BY t.intTransactionTypeID
	, CONVERT(DATE, t.dtetriggeredDateTime)
;
