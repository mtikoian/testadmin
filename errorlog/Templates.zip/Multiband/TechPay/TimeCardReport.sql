USE TechPayAppData
GO
-- =========================================================================
-- Title: Timecard Report
-- Author: Nem W Schlecht
-- Create Date: 2015-03-20
-- Copyright: Goodman Networks Field Services, Copyright (C) 2015
-- Description: Originally from Jeremy Dobler, for requests from Loretta
--     Claypool concerning Tempus Carta
-- =========================================================================
SET XACT_ABORT ON;
SET NOCOUNT ON;
-- Make sure we're not in a transaction
IF (@@TRANCOUNT > 0)
BEGIN
	ROLLBACK;
END;

BEGIN TRAN;
SAVE TRAN nws_ssms;

SELECT TC.intTimecardID [Timecard ID]
	, TC.intUserID [User ID]
	, TC.dteStart [Time Card Start]
	, TC.dteEnd [Time Card Stop]
	, TC.txtComment [Comments]
	, TC.intReviewByUserID [Reviewed By]
	, TCT.txtTimecardItemType [Action]
	, TCT.txtAbbreviation [Short Code]
	, TCI.fltHours [Hours]
	, TCI.mnyPay [Pay]
	, TCI.dteStartTime [Action Start Time]
	, TCI.dteEndTime [Action End Time]
	, TCI.intPaySheetID [TechPay PaySheet ID]
FROM tblTimeCard AS TC
	INNER JOIN tblTimeCardItems AS TCI
		ON TC.intTimecardID = TCI.intTimeCardID
	INNER JOIN tblTimeCardItemTypes AS TCT
		ON TCT.intTimecardItemTypeID = TCI.intTimeCardItemTypeID
WHERE TC.intUserID = 37171
	--AND TC.dteStart > '2011-04-05'
	--AND TC.dteEnd < '2011-07-07'
ORDER BY TC.intTimecardID


-- Comment the next line to commit this query
ROLLBACK TRAN nws_ssms;
COMMIT;

GO
