-- =========================================================================
-- Title: CDR Summary
-- Author: Nem W Schlecht
-- Create Date: 2014-01-01
-- Copyright: Goodman Networks/Multiband, Copyright (C) 2014
-- Description: Export CDR Data for Dave Ekman
-- =========================================================================

:CONNECT MB-ND01-VMD-001

USE Phones

DECLARE @DateFrom DATE
	, @DateTo DATE

SELECT @DateFrom = '2014-09-26'
	, @DateTo = '2014-10-26';

WITH Pilots
AS (
	SELECT DISTINCT globalCallID_callId
		, p.fldPM_PilotMapNo AS Pilot
		, p.fldPM_Company AS Company
		, p.fldPM_PhoneNo
	FROM dbo.tblCallDetailRecord c
		INNER JOIN dbo.tblPilotMappingCDR p
			ON p.fldPM_PilotMapNo = c.originalCalledPartyNumber
	WHERE DATEADD(hh, - 5, dteTimeOfCallUTC) >= @DateFrom
		AND DATEADD(hh, - 5, dteTimeOfCallUTC) < @DateTo
		--AND originalCalledPartyNumber IN ('88615', '88620', '88624', '88619')
	)
SELECT p.Company
	, p.Pilot
	, p.fldPM_PhoneNo Phone#
	, CONVERT(VARCHAR(10), CONVERT(DATE, DATEADD(hh, -5, cdr.dteTimeOfCallUTC)), 101) AS DATE
	, COUNT(DISTINCT cdr.globalCallID_callId) AS CallCount
	, CAST(ROUND(SUM(CASE 
					WHEN cdr.finalCalledPartyUnicodeLoginUserID <> '\'
						THEN cdr.duration
					ELSE 0
					END * 1.00) / 60, 2) AS DECIMAL(19, 2)) TalkTime
	, CAST(ROUND(SUM(CASE 
					WHEN cdr.finalCalledPartyUnicodeLoginUserID = '\'
						THEN cdr.duration
					ELSE 0
					END * 1.00) / 60, 2) AS DECIMAL(19, 2)) HoldTime
	, CAST(ROUND(SUM(cdr.duration) * 1.0 / 60, 2) AS DECIMAL(19, 2)) Duration
FROM dbo.tblCallDetailRecord cdr
	INNER JOIN Pilots p
		ON p.globalCallID_callId = cdr.globalCallID_callId
WHERE --cdr.finalCalledPartyUnicodeLoginUserID <> '\'
	--AND 
	DATEADD(hh, - 5, cdr.dteTimeOfCallUTC) >= @DateFrom
	AND DATEADD(hh, - 5, cdr.dteTimeOfCallUTC) < @DateTo
GROUP BY p.Pilot
	, p.Company
	, CONVERT(DATE, DATEADD(hh, - 5, cdr.dteTimeOfCallUTC))
	, fldPM_PhoneNo
ORDER BY p.Company
	, CONVERT(DATE, DATEADD(hh, - 5, cdr.dteTimeOfCallUTC))
	--SELECT top 1000 * from dbo.tblCallDetailRecord order by dteTimeOfCallUTC desc
;

GO
