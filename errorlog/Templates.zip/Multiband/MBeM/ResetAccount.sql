USE MBeM_Master;
GO

SET NOCOUNT ON;

BEGIN TRANSACTION;

UPDATE MB.tblAuthUser
SET fldAU_Password = 'egBfQVDOvsSBGBFX0p44jye9e8WjhMsCruhoSobt+10=' -- Multiband1
	, fldAU_IsActive = 1
	, fldAU_AuthFail = 0
--, fldAU_LastPasswordChange = GETDATE()
OUTPUT DELETED.*
WHERE fldAU_LName = '' -- Set this
	AND fldAU_FName = '' -- and this
;

ROLLBACK;
--COMMIT;
GO


