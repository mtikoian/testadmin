USE MBeM_Master;
GO

SET NOCOUNT ON;

SELECT fldDB_DatabaseID
	, fldDB_Name
	, fldDB_DatabaseNumber
	, fldDB_Description
	, fldDB_IsActive
	, fldDB_CreateBy
	, fldDB_CreateOn
	, fldDB_ModifiedBy
	, fldDB_ModifiedOn
FROM MB.tblDatabase
--ORDER BY fldDB_Name
ORDER BY fldDB_DatabaseNumber;
GO


