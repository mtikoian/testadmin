USE SPIdb
GO

-- =========================================================================
-- Title: <Title,,>
-- Author: Nem W Schlecht
-- Create Date: <Create Date,,>
-- Copyright: Goodman Networks Field Services, Copyright (C) 2015
-- Description: <Description,,>
-- =========================================================================
SET XACT_ABORT ON;
SET NOCOUNT ON;

-- Make sure we're not in a transaction
IF (@@TRANCOUNT > 0)
BEGIN
	ROLLBACK;
END;

BEGIN TRANSACTION;

SAVE TRAN nws_ssms;

SELECT *
FROM tblSiebelCompleteLastUpdated

SELECT TOP (100) *
FROM tblContractorConsumptionDateLog
ORDER BY dteLogDate DESC

DECLARE @LastNight VARCHAR(30) = CONVERT(VARCHAR(10), DATEADD(d, - 2, GETDATE()), 120);

SET @LastNight = @LastNight + ' 23:01:01';

UPDATE tblSiebelCompleteLastUpdated
SET dteSCLastUpdated = @LastNight
	, dteECLastUpdated = @LastNight
	, dteNELastUpdated = @LastNight
	, dteNCLastUpdated = @LastNight
	, dteConsumptionLastUpdated = @LastNight
OUTPUT INSERTED.*
WHERE 1 = 1;

UPDATE tblContractorConsumptionDateLog
SET dteLogDate = CAST(DATEADD(d, - 1, GETDATE()) AS DATE)
OUTPUT DELETED.*
	, INSERTED.*
WHERE dteLogDate = CAST(GETDATE() AS DATE);

DELETE
FROM tblContractorConsumptionDateLog
WHERE intCompanyBranchID = 30
	AND dteLogDate = '2015-03-23 00:00:00.000'

-- Comment the next line to commit this query
ROLLBACK TRAN nws_ssms;
COMMIT;
GO


