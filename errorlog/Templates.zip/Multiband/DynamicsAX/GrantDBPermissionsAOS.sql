PRINT 'Grant-DbPermissionsToAosAccount';
PRINT 'USAGE:';
PRINT 'You have to be in SQL SERVER/DB context.';
PRINT 'Run the script for main database, temporary database, and baseline model store database';
PRINT 'Set parameter ''@createStoredProcedures'' to 1 for main database and to 0 for other databases';
PRINT 'Set parameter ''@loginName'' to AOS account in ''domain\username'' format'
PRINT 'Set parameter ''@aosServerName'' to the machine name, where AOS is running'
PRINT 'Set parameter ''@aosInstance'' to AOS ID, like ''01'' to distinguish temp stored procedures for different AOS instances'
PRINT '';

-- PARAMETERS: PLEASE ALTER BY YOUR NEED
DECLARE @createStoredProcedures BIT = 1;
DECLARE @loginName NVARCHAR(128) = N'domain\user';
DECLARE @aosServerName NVARCHAR(128) = N'aosserver';
DECLARE @aosInstance NVARCHAR(128) = N'01';
--
DECLARE @tempDBName NVARCHAR(128) = N'tempdb';

-- SCRIPT VARIABLES
DECLARE @sql nvarchar(MAX);

-- PREPARE PROCEDURES FOR THE SCRIPT
PRINT 'PREPARING PROCEDURES FOR THE SCRIPT'
-- PROCEDURE, WHICH CREATES OTHER PROCEDURES (CreateProc)
IF NOT EXISTS(select * from dbo.sysobjects where id = object_id('CreateProc') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
	SET @sql='CREATE PROCEDURE [dbo].[CreateProc] AS';
	EXEC sp_executesql @sql;
END

SET @sql='ALTER PROCEDURE [dbo].[CreateProc](@dbName nvarchar(128), @procName nvarchar(128), @procBody nvarchar(MAX), @userName nvarchar(256)=NULL) AS BEGIN
	print ''Altering procedure: ''+@dbName+''.''+@procName+''...'';
	DECLARE @useSql varchar(100) = ''USE ''+@dbName+'';'';
	DECLARE @sql nvarchar(MAX);
	SET @sql=''
		IF NOT EXISTS(select * from dbo.sysobjects where id = object_id(''''''+@procName+'''''') and OBJECTPROPERTY(id, N''''IsProcedure'''') = 1)
		BEGIN
			EXEC sp_executesql N''''CREATE PROCEDURE ''+@procName+'' AS'''';
		END '';
	SET @sql = @useSql+@sql;
	EXEC sp_executesql @sql;

	DECLARE @procBodySql NVARCHAR(MAX) = @useSql+N''EXEC sp_executesql @procBody'';
	EXEC sp_executesql @procBodySql, N''@procBody nvarchar(MAX)'', @procBody;
	
	IF @userName IS NOT NULL
	BEGIN
		SET @sql=@useSql+''GRANT EXECUTE ON '' + @procName + '' TO ['' + @userName + '']'';
		EXEC sp_executesql @sql;
	END
END';

EXEC sp_executesql @sql;


DECLARE @currDB NVARCHAR(128) = DB_NAME();
PRINT 'Current database is: '+@currDB;

EXEC dbo.CreateProc @currDB, '[dbo].[IsServerLogin]', 'ALTER PROCEDURE [dbo].[IsServerLogin](@Login varchar(128))
AS
BEGIN
	PRINT ''Checking if user ''''''+@Login+'''''' has DB server login...'';
	DECLARE @cnt INT;
	SELECT @cnt = COUNT(*) FROM master..syslogins where name = @Login;
	IF @cnt = 0
	BEGIN
		PRINT ''FALSE'';
		RETURN 0;
	END
	PRINT ''TRUE'';
	RETURN 1;
END';

EXEC dbo.CreateProc @currDB, '[dbo].[GrantServerLogin]', 'ALTER PROCEDURE [dbo].[GrantServerLogin](@Login varchar(128))
AS
BEGIN
	PRINT ''Granting server login to user ''''''+@Login+''''''...'';
	EXEC sp_grantlogin @Login;
	RETURN;
END';

EXEC dbo.CreateProc @currDB, '[dbo].[IsDatabaseLogin]', 'ALTER PROCEDURE [dbo].[IsDatabaseLogin](@Login varchar(128))
AS
BEGIN
	PRINT ''Checking if user ''''''+@Login+'''''' has active database login...'';
	CREATE TABLE #tmpUsers
   (
    UserName        sysname        collate database_default Null
   ,RoleName        sysname        collate database_default Null
   ,LoginName       sysname        collate database_default Null
   ,DefDBName       sysname        collate database_default Null
   ,DefScName		 sysname        collate database_default Null
   ,UID             int		Null
   ,SID             varbinary(85)  Null
   )
	INSERT INTO #tmpUsers EXEC dbo.sp_helpuser;
	DECLARE @cnt INT;
	SELECT @cnt = COUNT(*) FROM #tmpUsers WHERE LoginName = @Login;
	IF @cnt = 0
	BEGIN
		PRINT ''FALSE'';
		RETURN 0;
	END
	PRINT ''TRUE'';
	RETURN 1;
END';

EXEC dbo.CreateProc @currDB, '[dbo].[IsDatabaseLoginDBO]', 'ALTER PROCEDURE [dbo].[IsDatabaseLoginDBO](@Login varchar(128))
AS
BEGIN
	PRINT ''Checking if user ''''''+@Login+'''''' has dbo role in active database...'';
	CREATE TABLE #tmpUsers
   (
    UserName        sysname        collate database_default Null
   ,RoleName        sysname        collate database_default Null
   ,LoginName       sysname        collate database_default Null
   ,DefDBName       sysname        collate database_default Null
   ,DefScName		 sysname        collate database_default Null
   ,UID             int		Null
   ,SID             varbinary(85)  Null
   )
	INSERT INTO #tmpUsers EXEC dbo.sp_helpuser;
	DECLARE @cnt INT;
	SELECT @cnt = COUNT(*) FROM #tmpUsers WHERE LoginName = @Login AND RoleName = ''db_owner'';
	IF @cnt = 0
	BEGIN
		PRINT ''FALSE'';
		RETURN 0
	END
	PRINT ''TRUE'';
	RETURN 1;
END';

EXEC dbo.CreateProc @currDB, '[dbo].[GrantDatabaseLogin]', 'ALTER PROCEDURE [dbo].[GrantDatabaseLogin](@Login varchar(128))
AS
BEGIN
	PRINT ''Granting active database login to user ''''''+@Login+''''''...'';
	EXEC sp_grantdbaccess @Login;
	RETURN
END';

EXEC dbo.CreateProc @currDB, '[dbo].[SetUserDefaultSchemaToDBO]', 'ALTER PROCEDURE [dbo].[SetUserDefaultSchemaToDBO](@Login varchar(128))
AS
BEGIN
	PRINT ''Setting database schema to DBO for user ''''''+@Login+''''''...'';
	DECLARE @sql NVARCHAR(1000);
	SET @sql = N''ALTER USER [''+@Login+N''] WITH DEFAULT_SCHEMA=dbo''
	EXEC sp_executesql @sql;
END';

EXEC dbo.CreateProc @currDB, '[dbo].[SetUserRolesForAosAccess]', 'ALTER PROCEDURE [dbo].[SetUserRolesForAosAccess](@Login varchar(128))
AS
BEGIN
	PRINT ''Setting database roles for user ''''''+@Login+''''''...'';
	EXEC sp_addrolemember ''db_ddladmin'', @Login;
	EXEC sp_addrolemember ''db_datareader'', @Login;
	EXEC sp_addrolemember ''db_datawriter'', @Login;
	DECLARE @sql NVARCHAR(1000);
	SET @sql=N''GRANT EXECUTE TO [''+@Login+N'']'';
	EXEC sp_executesql @sql;
END';

EXEC dbo.CreateProc @currDB, '[dbo].[GrantShowplan]', 'ALTER PROCEDURE [dbo].[GrantShowplan](@Login varchar(128))
AS
BEGIN
	PRINT ''Granting showplan to user ''''''+@Login+''''''...'';
	DECLARE @sql NVARCHAR(1000);
	SET @sql=N''GRANT showplan TO [''+@Login+N'']'';
	EXEC sp_executesql @sql;
END';

-- SCRIPT BODY
PRINT '';
PRINT 'EXECUTING SCRIPT BODY';
PRINT 'Script Parameters:';
PRINT '@createStoredProcedures:';
PRINT @createStoredProcedures;
PRINT '@loginName:';
PRINT @loginName;
PRINT '@aosServerName';
PRINT @aosServerName;
PRINT '@aosInstance:';
PRINT @aosInstance;
PRINT '@tempDBName';
PRINT @tempDBName;
PRINT '';

-- GRANT ACCESS TO DB SERVER
--		CHECK FOR LOGIN PRESENCE
DECLARE @isServerLogin BIT;
EXEC @isServerLogin = dbo.IsServerLogin @loginName;
IF @isServerLogin = 0
BEGIN
--		GRANT ACCESS IF NOT PRESENT
	EXEC dbo.GrantServerLogin @loginName;
END
-- GRANT ACCESS TO THE DATABASE
--		CHECK IF LOGIN IS DATABASE LOGIN
DECLARE @isDatabaseLogin BIT;
EXEC @isDatabaseLogin = dbo.IsDatabaseLogin @loginName;
--		CHECK IF LOGIN IS DATABASE LOGIN 'dbo'
DECLARE @isDatabaseLoginDBO BIT;
EXEC @isDatabaseLoginDBO = dbo.IsDatabaseLoginDBO @loginName;
--		GRANT ACCESS IF NOT PRESENT, SET DEFAULT SCHEMA 'dbo'
IF @isDatabaseLogin = 0
BEGIN
	EXEC dbo.GrantDatabaseLogin @loginName;
	EXEC dbo.SetUserDefaultSchemaToDBO @loginName;
END
--		SETUP DB ROLES IF NOT DBO
IF @isDatabaseLoginDBO = 0
BEGIN
	EXEC dbo.SetUserRolesForAosAccess @loginName;
END
-- IF NEEDED, CREATE STORED PROCEDURES
--		CHECK INPUT PARAMETER 'createStoredProcedures' FOR 1 AND PROCEED
		IF @createStoredProcedures = 1
		BEGIN
			PRINT 'CREATING STORED PROCEDURES...';
			-- DROP USED TABLES
			--PRINT 'Dropping old used tables...';
			--IF EXISTS(SELECT * from dbo.sysobjects where id = object_id('SYSCLIENTSESSIONS') and OBJECTPROPERTY(id, N'IsTable') = 1)
			--BEGIN
			--	EXEC sp_executesql N'drop table SYSCLIENTSESSIONS';
			--END
			--IF EXISTS(SELECT * from dbo.sysobjects where id = object_id('SYSSERVERSESSIONS') and OBJECTPROPERTY(id, N'IsTable') = 1)
			--BEGIN
			--	EXEC sp_executesql N'drop table SYSSERVERSESSIONS';
			--END
			
			-- TEMP
			DECLARE @tempProcName NVARCHAR(128);
			SET @tempProcName = N'[dbo].[CREATETEMPDBPERMISSIONS_'+@aosServerName+'_'+@aosInstance+']';
			PRINT 'Generated temp procedure name: ' + @tempProcName;
			DECLARE @tempProcSQL NVARCHAR(MAX);
			SET @tempProcSQL = 'ALTER PROCEDURE ' + @tempProcName + ' AS BEGIN ' +
				' exec(''USE ' + @tempDBName + ';
				DECLARE @dbaccesscount INT;
				EXEC sp_grantlogin ''''' + @loginName + ''''';' +
				' SELECT @dbaccesscount = COUNT(*) FROM master..syslogins WHERE name = ''''' + @loginName + ''''';' +
				' IF (@dbaccesscount <> 0)' +
				' EXEC sp_grantdbaccess ''''' + @loginName + ''''';' +
				' ALTER USER [' + @loginName + '] WITH DEFAULT_SCHEMA=dbo;';
			SET @tempProcSQL = @tempProcSQL + 'EXEC sp_addrolemember ''''db_ddladmin'''', ''''' + @loginName + ''''';'
					+ 'EXEC sp_addrolemember ''''db_datareader'''', ''''' + @loginName + ''''';'
					+ 'EXEC sp_addrolemember ''''db_datawriter'''', ''''' + @loginName + ''''';';
			SET @tempProcSQL = @tempProcSQL + '''); END';
			
			EXEC dbo.CreateProc 'master', @tempProcName, @tempProcSQL, @loginName;
			-- Set autorun for TEMP
			PRINT 'Setting autorun for ' + @tempProcName + '...';
			DECLARE @tempProcAutorun NVARCHAR(MAX);
			SET @tempProcAutorun = 'USE [master]; EXEC sp_procoption @ProcName='''+@tempProcName+''', @OptionName=startup, @OptionValue=true';
			EXEC sp_executesql @tempProcAutorun;
			-- CREATESERVERSESSIONS
			EXEC dbo.CreateProc @currDB, '[dbo].[CREATESERVERSESSIONS]', 'alter procedure [dbo].[CREATESERVERSESSIONS] @aosId nvarchar(50),
				 @version int,
				 @instanceName nvarchar(50),
				 @recid bigint,
				 @maxservers int,
				 @status int,
				 @loadbalance int,
				 @workload int,
				 @serverid int OUTPUT
				 as
				 declare @first as nvarchar(50)
				 declare @max_val as int
				 begin
				 select top 1 @first = SERVERID from SYSSERVERSESSIONS WITH (UPDLOCK, READPAST)
				   where STATUS = 0 and AOSID = @aosId and INSTANCE_NAME = @instanceName
				 if (select count(SERVERID) from SYSSERVERSESSIONS where SERVERID IN (@first)) > 0
				 begin
				 update SYSSERVERSESSIONS set AOSID = @aosId, VERSION = @version, INSTANCE_NAME = @instanceName,
				 LOGINDATETIME = dateadd(ms, -datepart(ms,getutcdate()), getutcdate()), LASTUPDATEDATETIME = dateadd(ms, -datepart(ms,getutcdate()), getutcdate()), STATUS = @status,
                 WORKLOAD = @workload, AOSACCOUNT = SUSER_SNAME()
				 where SERVERID IN (@first)
				 and (
                         ((select count(SERVERID) from SYSSERVERSESSIONS
						    where STATUS = 1 and LOADBALANCE = 0) < @maxservers)
                      OR 
                		    LOADBALANCE != 0
                 )
				 if @@ROWCOUNT = 0
				 select @serverid = 0
				 else
				 select @serverid = @first
				 end
				 else
				 begin
				 if (select count(SERVERID) from SYSSERVERSESSIONS WITH (UPDLOCK)
					   where STATUS = 1 and LOADBALANCE = 0) >= @maxservers
				 select @serverid = 0
				 else
				 begin
				 if (select count(SERVERID) from SYSSERVERSESSIONS) = 0
				 select @max_val = 1
				 else
				 select @max_val = max(SERVERID)+1 from SYSSERVERSESSIONS
                 insert into SYSSERVERSESSIONS(SERVERID, AOSID, INSTANCE_NAME, VERSION,  LOGINDATETIME, LASTUPDATEDATETIME, STATUS, RECID, LOADBALANCE, WORKLOAD, AOSACCOUNT)
                 values(@max_val, @aosId, @instanceName, @version, dateadd(ms, -datepart(ms,getutcdate()), getutcdate()), dateadd(ms, -datepart(ms,getutcdate()), getutcdate()), @status, @recid, @loadbalance, @workload, SUSER_SNAME())
				 select @serverid = @max_val
				 end
				 end
				 end', @loginName;
			-- CREATEUSERSESSIONS
			EXEC dbo.CreateProc @currDB, '[dbo].[CREATEUSERSESSIONS]', 'alter procedure [dbo].[CREATEUSERSESSIONS] @clientType int,
				 @sessionType int,
				 @serverid int,
				 @versionid int,
				 @userid nvarchar(8),
				 @lanExt nvarchar(10),
				 @manExt nvarchar(10),
                 @computerName nvarchar(80),
				 @sid  nvarchar(124),
				 @recid bigint,
				 @startId int,
				 @maxusers int,
				 @licenseType int,
				 @masterId int,
				 @maxClientId int,
				 @sessionid int OUTPUT,
				 @loginDateTime datetime OUTPUT
				 as
				 declare @return_val as int
				 declare @first as int
				 declare @max_val as int
				 declare @counter as int
				 begin
				 select @sessionid = -1
				 select @max_val = -1
				 select @counter = 0
				 select @loginDateTime = dateadd(ms, -datepart(ms,getutcdate()), getutcdate())
					   if(not exists(select * from SYSSERVERSESSIONS WITH (NOLOCK) where SERVERID = @serverid AND Status = 1))
					   begin
					   select @sessionid = -2
					   return
					   end
				 select @first = min(SESSIONID) from SYSCLIENTSESSIONS WITH (UPDLOCK,READPAST) where STATUS = 0 and SESSIONID > @maxClientId and SESSIONID <> @masterId
				 if (select count(*) from SYSCLIENTSESSIONS where SESSIONID IN (@first)) > 0
				 begin
				 if (@licenseType = 0)
				 begin
				 update SYSCLIENTSESSIONS set STATUS = 1, VERSION = @versionid, SERVERID = @serverid, USERID = @userid, LOGINDATETIME = @loginDateTime,
                 SID = @sid, USERLANGUAGE = @lanExt, HELPLANGUAGE = @manExt, CLIENTTYPE = @clientType, SESSIONTYPE = @sessionType, CLIENTCOMPUTER = @computerName
				 where SESSIONID IN (@first)
				 end
				 else if (@licenseType = 1)
				 begin
				 update SYSCLIENTSESSIONS set STATUS = 1, VERSION = @versionid, SERVERID = @serverid, USERID = @userid, LOGINDATETIME = @loginDateTime,
                 SID = @sid, USERLANGUAGE = @lanExt, HELPLANGUAGE = @manExt, CLIENTTYPE = @clientType, SESSIONTYPE = @sessionType, CLIENTCOMPUTER = @computerName
				 where SESSIONID IN (@first)
				 and ((select count(SESSIONID) from SYSCLIENTSESSIONS where CLIENTTYPE = @clientType and ((STATUS = 1) or (STATUS = 2))) < @maxusers)
				 end
				 else if (@licenseType = 2)
				 begin
				 update SYSCLIENTSESSIONS set STATUS = 1, VERSION = @versionid, SERVERID = @serverid, USERID = @userid, LOGINDATETIME = @loginDateTime,
                 SID = @sid, USERLANGUAGE = @lanExt, HELPLANGUAGE = @manExt, CLIENTTYPE = @clientType, SESSIONTYPE = @sessionType, CLIENTCOMPUTER = @computerName
				 where SESSIONID IN (@first)
				 and ( (select count(SESSIONID) from SYSCLIENTSESSIONS where CLIENTTYPE = @clientType and (USERID = @userid) and ((STATUS = 1) or (STATUS = 2))) > 0
				 or
				 (select count(distinct USERID) from SYSCLIENTSESSIONS where CLIENTTYPE = @clientType and ((STATUS = 1) or (STATUS = 2))) < @maxusers
				 )
				 end
				 if @@ROWCOUNT = 0
				 select @sessionid = 0
				 else
				 select @sessionid = @first
				 end
				 else
				 begin
				 if (@licenseType = 1)
				 begin
				 if (select count(SESSIONID) from SYSCLIENTSESSIONS where CLIENTTYPE = @clientType and ((STATUS = 1) or (STATUS = 2))) >= @maxusers
				 select @sessionid = 0
				 end
				 else if (@licenseType = 2)
				 begin
				 if (
				 ((select count(distinct USERID) from SYSCLIENTSESSIONS where CLIENTTYPE = @clientType and ((STATUS = 1) or (STATUS = 2))) >= @maxusers)
				 and
				 ((select count(SESSIONID) from SYSCLIENTSESSIONS where CLIENTTYPE = @clientType and (USERID = @userid) and ((STATUS = 1) or (STATUS = 2))) = 0)
				 )
				 select @sessionid = 0
				 end
				 if (@sessionid = -1) or (@licenseType = 0)
				 begin
				 while (@sessionid = -1 and @counter < 5)
				 begin
				 set @counter = @counter + 1
				 if (select count(SESSIONID) from SYSCLIENTSESSIONS WITH (UPDLOCK) where STATUS = 0 or STATUS = 1 or STATUS = 2 or STATUS = 3) = 0
				 select @max_val = @startId
				 else
				 select @max_val = max(SESSIONID)+1 from SYSCLIENTSESSIONS WITH (UPDLOCK)
				 if (@max_val > 65535)
				 select @sessionid = -3
				 else
				 begin
                 insert into SYSCLIENTSESSIONS(SESSIONID, SERVERID, VERSION, LOGINDATETIME, USERID, SID, USERLANGUAGE, HELPLANGUAGE, CLIENTTYPE, SESSIONTYPE, RECID, CLIENTCOMPUTER, STATUS)
                 values(@max_val, @serverid, @versionid, @loginDateTime, @userid, @sid, @lanExt, @manExt, @clientType, @sessionType, @recid, @computerName, 1)
				 if @@ROWCOUNT = 0
				 begin
				 select @sessionid = -1
				 end
				 else
				 select @sessionid = @max_val
				 end
				 end
				 end
				 end
				 end', @loginName;
			-- getNumInternal
			EXEC dbo.CreateProc @currDB, '[dbo].[getNumInternal]', 'alter procedure [dbo].[getNumInternal] @numberid bigint,
                 @globalTransId bigint,
                 @RowIDNumber bigint,
                 @UserId nvarchar(5),
                 @sessionid int, @sessionLoginDateTime datetime, @nextValue int output as 
                 BEGIN
                 DECLARE @continuous int
                 DECLARE @nextListValue int
                 DECLARE @rowNumber bigint
                 DECLARE @inuse int
                 DECLARE @highest int
                    SET NOCOUNT ON
                    SELECT @nextValue = 0  /* initialize to not found. */
                    SELECT @nextListValue = 0 /* not found */
                    SELECT @inuse = 1 /* inuse true by default */
                    SELECT @highest = 0
                    /* Check for continuous number, if continuous process list */
                        SELECT TOP 1 @highest = [HIGHEST], @nextValue = [NEXTREC], @continuous = [CONTINUOUS], @rowNumber = [RECID], @inuse = [INUSE]  
                        FROM [dbo].[NUMBERSEQUENCETABLE] WITH (ROWLOCK,UPDLOCK) 
                        WHERE [NUMBERSEQUENCETABLE].[RECID] = @numberid  
                 IF @rowNumber > 0
                 BEGIN
                     IF @continuous > 0 /* continuous number, goto list first */
                     BEGIN
                      SELECT TOP 1 @nextListValue = [NEXTREC], @rowNumber = [RECID] 
                          FROM [dbo].[NUMBERSEQUENCELIST] WITH (ROWLOCK,UPDLOCK)
                          WHERE [NUMBERSEQUENCELIST].[NUMBERSEQUENCEID] = @numberid and [NUMBERSEQUENCELIST].[STATUS] = 0  /* Free = 0; */
                      IF @nextListValue > 0
                      BEGIN
                        UPDATE [dbo].[NUMBERSEQUENCELIST] SET
                                    [STATUS] = 1,
                                    [TRANSID] = @globalTransId,
                                    [MODIFIEDTRANSACTIONID] = @globalTransId,
                                    [USERID] = @UserId,
                                    [MODIFIEDBY] = @UserId,
                                    [SESSIONID] = @sessionid,
                                    [SESSIONLOGINDATETIME] = @sessionLoginDateTime
                                    FROM [dbo].[NUMBERSEQUENCELIST] WHERE [RECID] = @rowNumber
                        Select @nextValue = @nextListValue
                      END
                      ELSE
                          IF @nextValue <= @highest
                          BEGIN
                                SELECT @nextListValue = 0
                          END
                          ELSE
                          BEGIN /* Exceeded high limit, return not found */
                                SELECT @nextValue = 0
                                SELECT @nextListValue = -1
                          END
                      END
                      IF @nextListValue = 0
                      BEGIN
                            INSERT [dbo].[NUMBERSEQUENCELIST] ([RECID], [RECVERSION],[STATUS], [TRANSID], [MODIFIEDBY], [USERID], [SESSIONID], [SESSIONLOGINDATETIME], [NUMBERSEQUENCEID], [NEXTREC]) Values (
                                @RowIDNumber,
                                1,
                                1,
                                @globalTransId,
                                @UserId,
                                @UserId,
                                @sessionid,
                                @sessionLoginDateTime,
                                @numberid,
                                @nextValue)
                           UPDATE [dbo].[NUMBERSEQUENCETABLE] SET
                                [MODIFIEDTRANSACTIONID] = @globalTransId,
                                [NEXTREC] = [NEXTREC]+1, [INUSE] = 1
                                FROM [dbo].[NUMBERSEQUENCETABLE] WHERE [RECID] = @numberid
                      END
                     END
                    ELSE
                       SELECT @nextValue = 0 /* error not supported so return null value. */
                end', @loginName;
		END
-- GRANT ACCESS TO SHOWPLAN
EXEC dbo.GrantShowplan @loginName;
PRINT '--FINISHED--';
