USE [MSDynamicsAX2012_Test]
GO

--List of AOS'  I would recommend we delete this table as when you start the aos in dev it will write a record to this table.  This way we get rid of references to production.
--select * from sysserversessions
DELETE SYSSERVERSESSIONS

--If you have a different admin account to be used in this environment we need to change the userinfo table
UPDATE USERINFO
SET sid = 'S-1-5-21-1551005637-2038879248-5624465-9356'
	, NETWORKALIAS = 'a.korey.miller'
WHERE ID = 'admin'

--We will want to automate creation of dev users probably by using existing user and changing id to developer
--select * from USERINFO
--Update the bc proxy user
--select * from SysBCProxyUserAccount
UPDATE SysBCProxyUserAccount
SET SID = 'S-1-5-21-1551005637-2038879248-5624465-18949'
	, NETWORKALIAS = 's.axtestproxybc'

--update workflow system account
UPDATE USERINFO
SET SID = 'S-1-5-21-1551005637-2038879248-5624465-18071'
	, NETWORKALIAS = 's.AXTestWorkflow'
WHERE ID = 'wfexc'

--update server configuration information - I would recommend that we delete this table and letting the record get created when you start the aos
--select * from SysServerConfig
DELETE SYSSERVERCONFIG

--update batch server information - I would recommend that we delete this table as the aos will get added when it connects for the first time
--select * from BatchServerConfig
DELETE BATCHSERVERCONFIG

--I would update this table so that only the default 'non load balanced aos instances' entry is left
--select * from SysClusterConfig
DELETE SYSCLUSTERCONFIG
WHERE CLUSTERNAME <> 'Non Load Balanced AOS Instances'

--For this one I think we should delete everything but the dataUpdate group and then update that to be the correct serverid.  
--select * from BATCHSERVERGROUP
DELETE BATCHSERVERGROUP
WHERE GROUPID <> 'DataUpdate'

UPDATE BATCHSERVERGROUP
SET SERVERID = '01@MB-ND01-VMT-015'

--I assume we can delete all of this only questions I have are automatic role assignment, user license report, and batch transfer for subledger journals.  If we want those we just need to change the script to update them to have the correct AOS.  Also if we want workflow working we need to update the workflow batch jobs
--select * from BATCH
DELETE BATCH

--delete BATCH where CAPTION <> 'Automatic role assignment'
--update BATCH set SERVERID = '01@MB-ND01-VMD-004' where CAPTION like 'workflow%'
--If your smtp server is different between environments we need to update this otherwise we can remove this script
--select * from SYSEMAILPARAMETERS
--select * from SYSEMAILSMTPPASSWORD
--Once document management is setup we will need to update this.  Until then we will make sure the path is blank.
--select * from SysFileStoreParameters
UPDATE SYSFILESTOREPARAMETERS
SET FILEPATH = ''

--updating the OLAP info
--select * from BIANALYSISSERVER
UPDATE BIANALYSISSERVER
SET SERVERNAME = 'MB-ND01-VMT-033\AX2012_Test'
	, DEFAULTDATABASENAME = 'AX2012_Test_OLAP'
WHERE ISDEFAULT = 1

DELETE BIANALYSISSERVER
WHERE SERVERNAME != 'MB-ND01-VMT-033'

--update the connection string for olap
--select * from BICONFIGURATION
UPDATE BICONFIGURATION
SET CONNECTIONSTRING = 'Provider=SQLNCLI10.1;Data Source=MB-ND01-SCT-001;Integrated Security=SSPI;Initial Catalog=MSDynamicsAX2012_Test'

--update ssrs information
--select * from SRSSERVERS
UPDATE SRSSERVERS
SET SERVERID = 'MB-ND01-VMT-033'
	, SERVERURL = 'http://mb-nd01-vmt-033/ReportServer_AX2012_Test'
	, REPORTMANAGERURL = 'http://mb-nd01-vmt-033/Reports_AX2012_TEST'
	, AOSID = '01@MB-ND01-VMT-015'
	, CONFIGURATIONID = 'DAX Test'
	, SERVERINSTANCE = 'AX2012_TEST'

--update help server info
--select VALUE from SYSGLOBALCONFIGURATION where NAME = 'HelpServerLocation'
UPDATE SYSGLOBALCONFIGURATION
SET VALUE = 'http://dynamicsaxtesthelp.mbnd.local/DynamicsAX6HelpServer/HelpService.svc'
WHERE NAME = 'HelpServerLocation'

--update EP info
--select * from EPGLOBALPARAMETERS
--select * from EPWEBSITEPARAMETERS
--select * from COLLABSITEPARAMETERS
UPDATE EPGLOBALPARAMETERS
SET HOMEPAGESITEID = '00000000-0000-0000-0000-000000000000'
	, DEVELOPMENTSITEID = '00000000-0000-0000-0000-000000000000'
	, SEARCHSERVERURL = ''

UPDATE EPWEBSITEPARAMETERS
SET INTERNALURL = 'http://erptestportal.mbnd.local'
	, SITEID = 'B6A6C8C4-434C-416B-981E-DFE3E7C91026'
	, EXTERNALURL = 'http://erptestportal.mbnd.local'

-- update environment color to blue
UPDATE dbo.COMPANYCOLOR
SET COMPANYFORMCOLOR = 16619887

USE [master]
GO

/****** Object:  StoredProcedure [dbo].[CREATETEMPDBPERMISSIONS_mb-nd01-vmd-004_01]    Script Date: 9/5/2013 1:55:33 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[CREATETEMPDBPERMISSIONS_mb-nd01-sct-001_Test]
AS
BEGIN
	EXEC (
			'USE tempdb;
                           DECLARE @dbaccesscount INT;
                           EXEC sp_grantlogin ''mbnd\s.AXTestAOS''; SELECT @dbaccesscount = COUNT(*) FROM master..syslogins WHERE name = ''mbnd\s.AXTestAOS''; IF (@dbaccesscount <> 0) EXEC sp_grantdbaccess ''mbnd\s.AXTestAOS''; ALTER USER [mbnd\s.AXTestAOS] WITH DEFAULT_SCHEMA=dbo;EXEC sp_addrolemember ''db_ddladmin'', ''mbnd\s.AXTestAOS'';EXEC sp_addrolemember ''db_datareader'', ''mbnd\s.AXTestAOS'';EXEC sp_addrolemember ''db_datawriter'', ''mbnd\s.AXTestAOS'';'
			);
END
GO

EXEC sp_procoption N'[dbo].[CREATETEMPDBPERMISSIONS_mb-nd01-sct-001_Test]'
	, 'startup'
	, '1'
GO



USE [MSDynamicsAX2012_Test]
GO
CREATE USER [MBND\s.AXTestProxyBC] FOR LOGIN [MBND\s.AXTestProxyBC]
GO
USE [MSDynamicsAX2012_Test]
GO
ALTER USER [MBND\s.AXTestProxyBC] WITH DEFAULT_SCHEMA=[dbo]
GO
USE [MSDynamicsAX2012_Test]
GO
EXEC sp_addrolemember N'db_datareader', N'MBND\s.AXTestProxyBC'
GO
USE [MSDynamicsAX2012_Test_model]
GO
CREATE USER [MBND\s.AXTestProxyBC] FOR LOGIN [MBND\s.AXTestProxyBC]
GO
USE [MSDynamicsAX2012_Test_model]
GO
ALTER USER [MBND\s.AXTestProxyBC] WITH DEFAULT_SCHEMA=[dbo]
GO
USE [MSDynamicsAX2012_Test_model]
GO
EXEC sp_addrolemember N'db_datareader', N'MBND\s.AXTestProxyBC'
GO


USE [MSDynamicsAX2012_Test]
GO
CREATE USER [MBND\s.AXTestAOS] FOR LOGIN [MBND\s.AXTestAOS]
GO
USE [MSDynamicsAX2012_Test]
GO
ALTER USER [MBND\s.AXTestAOS] WITH DEFAULT_SCHEMA=[dbo]
GO
USE [MSDynamicsAX2012_Test]
GO
EXEC sp_addrolemember N'db_owner', N'MBND\s.AXTestAOS'
GO
USE [MSDynamicsAX2012_Test_model]
GO
CREATE USER [MBND\s.AXTestAOS] FOR LOGIN [MBND\s.AXTestAOS]
GO
USE [MSDynamicsAX2012_Test_model]
GO
ALTER USER [MBND\s.AXTestAOS] WITH DEFAULT_SCHEMA=[dbo]
GO
USE [MSDynamicsAX2012_Test_model]
GO
EXEC sp_addrolemember N'db_owner', N'MBND\s.AXTestAOS'
GO
