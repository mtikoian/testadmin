USE [DynamicsAX_2012_dev]
GO
--List of AOS'  I would recommend we delete this table as when you start the aos in dev it will write a record to this table.  This way we get rid of references to production.
--select * from sysserversessions
DELETE SYSSERVERSESSIONS

--If you have a different admin account to be used in this environment we need to change the userinfo table
UPDATE USERINFO
SET sid = 'S-1-5-21-1551005637-2038879248-5624465-9355'
	, NETWORKALIAS = 'a.korey.miller'
WHERE ID = 'admin'

--We will want to automate creation of dev users probably by using existing user and changing id to developer
--select * from USERINFO
--Update the bc proxy user
--select * from SysBCProxyUserAccount
UPDATE SysBCProxyUserAccount
SET SID = 'S-1-5-21-1551005637-2038879248-5624465-17513'
	, NETWORKALIAS = 's.AXDevProxyBC'

--update workflow system account
UPDATE USERINFO
SET SID = 'S-1-5-21-1551005637-2038879248-5624465-17082'
	, NETWORKALIAS = 's.AXDevWorkflow'
WHERE ID = 'wfexc'

--update server configuration information - I would recommend that we delete this table and letting the record get created when you start the aos
--select * from SysServerConfig
DELETE SYSSERVERCONFIG

--update batch server information - I would recommend that we delete this table as the aos will get added when it connects for the first time
--select * from BatchServerConfig
DELETE BATCHSERVERCONFIG

--I would update this table so that only the default 'non load balanced aos instances' entry is left
--select * from SysClusterConfig
DELETE SYSCLUSTERCONFIG
WHERE CLUSTERNAME <> 'Non Load Balanced AOS Instances'

--For this one I think we should delete everything but the dataUpdate group and then update that to be the correct serverid.  
--select * from BATCHSERVERGROUP
DELETE BATCHSERVERGROUP
WHERE GROUPID <> 'DataUpdate'

UPDATE BATCHSERVERGROUP
SET SERVERID = '01@MB-ND01-VMD-004'

--I assume we can delete all of this only questions I have are automatic role assignment, user license report, and batch transfer for subledger journals.  If we want those we just need to change the script to update them to have the correct AOS.  Also if we want workflow working we need to update the workflow batch jobs
--select * from BATCH
DELETE BATCH

--delete BATCH where CAPTION <> 'Automatic role assignment'
--update BATCH set SERVERID = '01@MB-ND01-VMD-004' where CAPTION like 'workflow%'
--If your smtp server is different between environments we need to update this otherwise we can remove this script
--select * from SYSEMAILPARAMETERS
--select * from SYSEMAILSMTPPASSWORD
--Once document management is setup we will need to update this.  Until then we will make sure the path is blank.
--select * from SysFileStoreParameters
UPDATE SYSFILESTOREPARAMETERS
SET FILEPATH = ''

--updating the OLAP info
--select * from BIANALYSISSERVER
UPDATE BIANALYSISSERVER
SET SERVERNAME = 'MB-ND01-VMD-001'
	, DEFAULTDATABASENAME = 'AX2012_Dev'
WHERE ISDEFAULT = 1

DELETE BIANALYSISSERVER
WHERE SERVERNAME != 'MB-ND01-VMD-001'

--update the connection string for olap
--select * from BICONFIGURATION
UPDATE BICONFIGURATION
SET CONNECTIONSTRING = 'Provider=SQLNCLI10.1;Data Source=MB-ND01-VMD-004\AX2012_Dev;Integrated Security=SSPI;Initial Catalog=DynamicsAX_2012_dev'

--update ssrs information
--select * from SRSSERVERS
UPDATE SRSSERVERS
SET SERVERID = 'MB-ND01-VMD-001'
	, SERVERINSTANCE = 'DynamicsAX'
	, SERVERURL = 'http://axdevssrs.mbnd.local/ReportServer_AX2012'
	, REPORTMANAGERURL = 'http://axdevssrs.mbnd.local/Reports_AX2012'
	, AOSID = '01@MB-ND01-VMD-004'
	, CONFIGURATIONID = 'DAX Dev'

--update help server info
--select VALUE from SYSGLOBALCONFIGURATION where NAME = 'HelpServerLocation'
UPDATE SYSGLOBALCONFIGURATION
SET VALUE = 'http://dynamicsaxhelp.mbnd.local/DynamicsAX6HelpServer/HelpService.svc'
WHERE NAME = 'HelpServerLocation'

--update EP info
--select * from EPGLOBALPARAMETERS
--select * from EPWEBSITEPARAMETERS
--select * from COLLABSITEPARAMETERS
UPDATE EPGLOBALPARAMETERS
SET HOMEPAGESITEID = 'FFC4843C-E97A-4A78-A184-5563DE3810B6'
	, DEVELOPMENTSITEID = 'FFC4843C-E97A-4A78-A184-5563DE3810B6'
	, SEARCHSERVERURL = ''

UPDATE EPWEBSITEPARAMETERS
SET INTERNALURL = 'http://erpdevportal.mbnd.local'
	, SITEID = 'FFC4843C-E97A-4A78-A184-5563DE3810B6'
	, EXTERNALURL = 'http://erpdevportal.mbnd.local'
GO

USE [master]
GO

/****** Object:  StoredProcedure [dbo].[CREATETEMPDBPERMISSIONS_mb-nd01-vmd-004_01]    Script Date: 9/5/2013 1:55:33 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[CREATETEMPDBPERMISSIONS_mb-nd01-vmd-004_Dev]
AS
BEGIN
	EXEC (
			'USE tempdb;
                           DECLARE @dbaccesscount INT;
                           EXEC sp_grantlogin ''mbnd\s.dynamicsax2012dev''; SELECT @dbaccesscount = COUNT(*) FROM master..syslogins WHERE name = ''mbnd\s.dynamicsax2012dev''; IF (@dbaccesscount <> 0) EXEC sp_grantdbaccess ''mbnd\s.dynamicsax2012dev''; ALTER USER [mbnd\s.dynamicsax2012dev] WITH DEFAULT_SCHEMA=dbo;EXEC sp_addrolemember ''db_ddladmin'', ''mbnd\s.dynamicsax2012dev'';EXEC sp_addrolemember ''db_datareader'', ''mbnd\s.dynamicsax2012dev'';EXEC sp_addrolemember ''db_datawriter'', ''mbnd\s.dynamicsax2012dev'';'
			);
END
GO

EXEC sp_procoption N'[dbo].[CREATETEMPDBPERMISSIONS_mb-nd01-vmd-004_Dev]'
	, 'startup'
	, '1'
GO



USE [DynamicsAX_2012_dev]
GO
CREATE USER [MBND\s.axdevproxybc] FOR LOGIN [MBND\s.axdevproxybc]
GO
USE [DynamicsAX_2012_dev]
GO
ALTER USER [MBND\s.axdevproxybc] WITH DEFAULT_SCHEMA=[dbo]
GO
USE [DynamicsAX_2012_dev]
GO
EXEC sp_addrolemember N'db_datareader', N'MBND\s.axdevproxybc'
GO
USE [DynamicsAX_2012_dev_model]
GO
CREATE USER [MBND\s.axdevproxybc] FOR LOGIN [MBND\s.axdevproxybc]
GO
USE [DynamicsAX_2012_dev_model]
GO
ALTER USER [MBND\s.axdevproxybc] WITH DEFAULT_SCHEMA=[dbo]
GO
USE [DynamicsAX_2012_dev_model]
GO
EXEC sp_addrolemember N'db_datareader', N'MBND\s.axdevproxybc'
GO


USE [DynamicsAX_2012_dev]
GO
CREATE USER [MBND\s.DynamicsAX2012Dev] FOR LOGIN [MBND\s.DynamicsAX2012Dev]
GO
USE [DynamicsAX_2012_dev]
GO
ALTER USER [MBND\s.DynamicsAX2012Dev] WITH DEFAULT_SCHEMA=[dbo]
GO
USE [DynamicsAX_2012_dev]
GO
EXEC sp_addrolemember N'db_owner', N'MBND\s.DynamicsAX2012Dev'
GO
USE [DynamicsAX_2012_dev_model]
GO
CREATE USER [MBND\s.DynamicsAX2012Dev] FOR LOGIN [MBND\s.DynamicsAX2012Dev]
GO
USE [DynamicsAX_2012_dev_model]
GO
ALTER USER [MBND\s.DynamicsAX2012Dev] WITH DEFAULT_SCHEMA=[dbo]
GO
USE [DynamicsAX_2012_dev_model]
GO
EXEC sp_addrolemember N'db_owner', N'MBND\s.DynamicsAX2012Dev'
GO



USE [DynamicsAX_2012_dev]
GO
CREATE USER [MBND\s.TFS2012Service] FOR LOGIN [MBND\s.TFS2012Service]
GO
USE [DynamicsAX_2012_dev]
GO
ALTER USER [MBND\s.TFS2012Service] WITH DEFAULT_SCHEMA=[dbo]
GO
USE [DynamicsAX_2012_dev]
GO
EXEC sp_addrolemember N'db_owner', N'MBND\s.TFS2012Service'
GO
USE [DynamicsAX_2012_dev_model]
GO
CREATE USER [MBND\s.TFS2012Service] FOR LOGIN [MBND\s.TFS2012Service]
GO
USE [DynamicsAX_2012_dev_model]
GO
ALTER USER [MBND\s.TFS2012Service] WITH DEFAULT_SCHEMA=[dbo]
GO
USE [DynamicsAX_2012_dev_model]
GO
EXEC sp_addrolemember N'db_owner', N'MBND\s.TFS2012Service'
GO