USE [AX2012_Training]
GO
CREATE USER [MBND\s.AX2012TrainingPrxy] FOR LOGIN [MBND\s.AX2012TrainingPrxy]
GO
USE [AX2012_Training]
GO
ALTER USER [MBND\s.AX2012TrainingPrxy] WITH DEFAULT_SCHEMA=[dbo]
GO
USE [AX2012_Training]
GO
EXEC sp_addrolemember N'db_datareader', N'MBND\s.AX2012TrainingPrxy'
GO
USE [AX2012_Training_model]
GO
CREATE USER [MBND\s.AX2012TrainingPrxy] FOR LOGIN [MBND\s.AX2012TrainingPrxy]
GO
USE [AX2012_Training_model]
GO
ALTER USER [MBND\s.AX2012TrainingPrxy] WITH DEFAULT_SCHEMA=[dbo]
GO
USE [AX2012_Training_model]
GO
EXEC sp_addrolemember N'db_datareader', N'MBND\s.AX2012TrainingPrxy'
GO


USE [AX2012_Training]
GO
CREATE USER [MBND\s.AX2012TrainingAOS] FOR LOGIN [MBND\s.AX2012TrainingAOS]
GO
USE [AX2012_Training]
GO
ALTER USER [MBND\s.AX2012TrainingAOS] WITH DEFAULT_SCHEMA=[dbo]
GO
USE [AX2012_Training]
GO
EXEC sp_addrolemember N'db_owner', N'MBND\s.AX2012TrainingAOS'
GO
USE [AX2012_Training_model]
GO
CREATE USER [MBND\s.AX2012TrainingAOS] FOR LOGIN [MBND\s.AX2012TrainingAOS]
GO
USE [AX2012_Training_model]
GO
ALTER USER [MBND\s.AX2012TrainingAOS] WITH DEFAULT_SCHEMA=[dbo]
GO
USE [AX2012_Training_model]
GO
EXEC sp_addrolemember N'db_owner', N'MBND\s.AX2012TrainingAOS'
GO
