USE [DynAX2012_PreProd]
GO
CREATE USER [MBND\s.AX2012PreProdAOS] FOR LOGIN [MBND\s.AX2012PreProdAOS]
GO
USE [DynAX2012_PreProd]
GO
ALTER USER [MBND\s.AX2012PreProdAOS] WITH DEFAULT_SCHEMA=[dbo]
GO
USE [DynAX2012_PreProd]
GO
EXEC sp_addrolemember N'db_owner', N'MBND\s.AX2012PreProdAOS'
GO
USE [DynAX2012_PreProd_model]
GO
CREATE USER [MBND\s.AX2012PreProdAOS] FOR LOGIN [MBND\s.AX2012PreProdAOS]
GO
USE [DynAX2012_PreProd_model]
GO
ALTER USER [MBND\s.AX2012PreProdAOS] WITH DEFAULT_SCHEMA=[dbo]
GO
USE [DynAX2012_PreProd_model]
GO
EXEC sp_addrolemember N'db_owner', N'MBND\s.AX2012PreProdAOS'
GO


USE [DynAX2012_PreProd]
GO
CREATE USER [MBND\s.AX2012PreProdPrxy] FOR LOGIN [MBND\s.AX2012PreProdPrxy]
GO
USE [DynAX2012_PreProd]
GO
ALTER USER [MBND\s.AX2012PreProdPrxy] WITH DEFAULT_SCHEMA=[dbo]
GO
USE [DynAX2012_PreProd]
GO
EXEC sp_addrolemember N'db_datareader', N'MBND\s.AX2012PreProdPrxy'
GO
USE [DynAX2012_PreProd_model]
GO
CREATE USER [MBND\s.AX2012PreProdPrxy] FOR LOGIN [MBND\s.AX2012PreProdPrxy]
GO
USE [DynAX2012_PreProd_model]
GO
ALTER USER [MBND\s.AX2012PreProdPrxy] WITH DEFAULT_SCHEMA=[dbo]
GO
USE [DynAX2012_PreProd_model]
GO
EXEC sp_addrolemember N'db_datareader', N'MBND\s.AX2012PreProdPrxy'
GO