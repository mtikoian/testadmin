USE [DynamicsAX_2012_dev]
GO
CREATE USER [MBND\s.axdevproxybc] FOR LOGIN [MBND\s.axdevproxybc]
GO
USE [DynamicsAX_2012_dev]
GO
ALTER USER [MBND\s.axdevproxybc] WITH DEFAULT_SCHEMA=[dbo]
GO
USE [DynamicsAX_2012_dev]
GO
EXEC sp_addrolemember N'db_datareader', N'MBND\s.axdevproxybc'
GO
USE [DynamicsAX_2012_dev_model]
GO
CREATE USER [MBND\s.axdevproxybc] FOR LOGIN [MBND\s.axdevproxybc]
GO
USE [DynamicsAX_2012_dev_model]
GO
ALTER USER [MBND\s.axdevproxybc] WITH DEFAULT_SCHEMA=[dbo]
GO
USE [DynamicsAX_2012_dev_model]
GO
EXEC sp_addrolemember N'db_datareader', N'MBND\s.axdevproxybc'
GO


USE [DynamicsAX_2012_dev]
GO
CREATE USER [MBND\s.DynamicsAX2012Dev] FOR LOGIN [MBND\s.DynamicsAX2012Dev]
GO
USE [DynamicsAX_2012_dev]
GO
ALTER USER [MBND\s.DynamicsAX2012Dev] WITH DEFAULT_SCHEMA=[dbo]
GO
USE [DynamicsAX_2012_dev]
GO
EXEC sp_addrolemember N'db_owner', N'MBND\s.DynamicsAX2012Dev'
GO
USE [DynamicsAX_2012_dev_model]
GO
CREATE USER [MBND\s.DynamicsAX2012Dev] FOR LOGIN [MBND\s.DynamicsAX2012Dev]
GO
USE [DynamicsAX_2012_dev_model]
GO
ALTER USER [MBND\s.DynamicsAX2012Dev] WITH DEFAULT_SCHEMA=[dbo]
GO
USE [DynamicsAX_2012_dev_model]
GO
EXEC sp_addrolemember N'db_owner', N'MBND\s.DynamicsAX2012Dev'
GO
