USE MR_UAT
GO
-- =========================================================================
-- Title: <Title,,>
-- Author: Nem W Schlecht
-- Create Date: <Create Date,,>
-- Copyright: Goodman Networks/Multiband, Copyright (C) 2015
-- Description: <Description,,>
-- =========================================================================
SET XACT_ABORT ON;
SET NOCOUNT ON;
-- Make sure we're not in a transaction
IF (@@TRANCOUNT > 0)
BEGIN
    ROLLBACK;
END;

BEGIN TRAN;
SAVE TRAN nws_ssms;


DECLARE @TimeInterval INT = 60; -- This is in *MINUTES*

UPDATE Scheduling.[Trigger]
SET Interval = @TimeInterval
WHERE UnitOfMeasure = 2
    AND Interval = 5
;

UPDATE Scheduling.[Trigger]
SET Interval = @TimeInterval
WHERE UnitOfMeasure = 2
    AND Interval = 5
;
  
UPDATE Scheduling.[Trigger]
SET Interval = (@TimeInterval/2)
WHERE UnitOfMeasure = 2
    AND Interval = 15
;

SELECT t.NAME
    , CASE ts.StateType
        WHEN 3
            THEN 'Processing'
        WHEN 5
            THEN 'Complete'
        WHEN 7
            THEN 'Error'
        END AS StateType
    , ts.Progress
    , tr.Id AS TrigerID
    , CASE tr.IsEnabled
        WHEN 1
            THEN 'Enabled'
        ELSE 'Disabled'
        END AS NameStatus
    , tr.Interval
    , CASE tr.UnitOfMeasure
        WHEN 2
            THEN 'Minutes'
        ELSE 'Seconds'
        END AS IntervalTiming
    , tr.UnitOfMeasure
FROM scheduling.task t
    INNER JOIN scheduling.taskstate ts
        ON t.id = ts.taskid
    INNER JOIN scheduling.[Trigger] tr
        ON tr.Id = t.TriggerId
WHERE isenabled <> 0
    AND T.TypeId = '55D3F71A-2618-4EAE-9AA6-D48767B974D8'
;

--ROLLBACK TRAN nws_ssms;
COMMIT;

GO
