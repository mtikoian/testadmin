USE <DBName,,>_model;
GO

--
-- Dynamics AX check fields for conflicts
-- Authhor: Nem W Schlecht
-- Multiband Corp., Copyright (C) 2014
--
SET XACT_ABORT ON;
SET NOCOUNT ON;
-- Make sure we're not in a transaction
IF (@@TRANCOUNT > 0)
BEGIN
    ROLLBACK;
END;

BEGIN TRAN;
SAVE TRAN nws_ssms;

SELECT me.NAME AS Model_name
	, me.axid AS Model_AXID
	, me.ParentID
	, sd.NAME AS SQLDictionary_name
	, sd.tableid AS TableID
	, sd.FIELDID
	--, sd.*
FROM ModelElement AS me
	JOIN <DBName,,>.dbo.SQLDICTIONARY AS sd
		ON me.ParentId = sd.TABLEID
			AND me.name = sd.name
WHERE 1 = 1
	AND me.ElementType = 42
	AND me.AxId <> sd.FIELDID
	AND sd.SQLNAME <> '<source table>'
	-- I (Nem) think we can check the FLAGS instead of SQLNAME, but StoneRidge
	-- isn't 100% positive that would work
	--AND sd.FLAGS = 0
	AND sd.FIELDID <> 0
ORDER BY sd.NAME;

ROLLBACK TRAN nws_ssms;
COMMIT;

GO
