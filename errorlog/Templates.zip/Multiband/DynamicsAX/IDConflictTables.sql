USE <DBName,,>_model;
GO

--
-- Dynamics AX Check Table IDs for Conflicts
-- Authhor: Nem W Schlecht
-- Multiband Corp., Copyright (C) 2014
--
SET XACT_ABORT ON;
SET NOCOUNT ON;
-- Make sure we're not in a transaction
IF (@@TRANCOUNT > 0)
BEGIN
    ROLLBACK;
END;

BEGIN TRAN;
SAVE TRAN nws_ssms;

SELECT me.NAME AS Model_name
      , me.axid AS Model_AXID
      , sd.NAME AS SQLDictionary_name
      , sd.tableid AS TableID
FROM ModelElement AS me
      JOIN <DBName,,>.dbo.SQLDICTIONARY AS sd
            ON me.NAME = sd.NAME
WHERE 1 = 1
      AND me.parentid = 0
      AND me.axid <> 0
      AND me.ElementType = 44
      AND sd.FIELDID = 0
      AND me.axid <> sd.tableid
ORDER BY me.NAME;

ROLLBACK TRAN nws_ssms;
COMMIT;

GO
