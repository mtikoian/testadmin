--List of AOS'  I would recommend we delete this table as when you start the aos in dev it will write a record to this table.  This way we get rid of references to production.
--select * from sysserversessions
DELETE SYSSERVERSESSIONS

--select * from userinfo
--If you have a different admin account to be used in this environment we need to change the userinfo table
UPDATE USERINFO
SET sid = 'S-1-5-21-1551005637-2038879248-5624465-21277'
	, NETWORKALIAS = 'c.catherine.mcdade'
WHERE ID = 'admin'

--catherine sid = S-1-5-21-1551005637-2038879248-5624465-21277
--ryan keven sid = S-1-5-21-1551005637-2038879248-5624465-21087
--tom branca sid = S-1-5-21-1551005637-2038879248-5624465-21276
--We will want to automate creation of dev users probably by using existing user and changing id to developer
--select * from USERINFO
--catherine sid = S-1-5-21-1551005637-2038879248-5624465-21277
--ryan keven sid = S-1-5-21-1551005637-2038879248-5624465-21087
--tom branca sid = S-1-5-21-1551005637-2038879248-5624465-21276
--Update the bc proxy user
--select * from SysBCProxyUserAccount
UPDATE SysBCProxyUserAccount
SET SID = 'S-1-5-21-1551005637-2038879248-5624465-20845'
	, NETWORKALIAS = 's.AX2012DevSharedSvc'

--update workflow system account
--select * from userinfo where ID='wfexc'
update USERINFO set SID='S-1-5-21-1551005637-2038879248-5624465-17082', NETWORKALIAS='s.AXDevWorkflow'  where ID='wfexc'
--update server configuration information - I would recommend that we delete this table and letting the record get created when you start the aos
--select * from SysServerConfig
DELETE SYSSERVERCONFIG

--update batch server information - I would recommend that we delete this table as the aos will get added when it connects for the first time
--select * from BatchServerConfig
DELETE BATCHSERVERCONFIG
WHERE SERVERID <> '01@MB-ND01-VMD-015'

--I would update this table so that only the default 'non load balanced aos instances' entry is left
--select * from SysClusterConfig
DELETE SYSCLUSTERCONFIG
WHERE CLUSTERNAME <> 'Non Load Balanced AOS Instances'

--For this one I think we should delete everything but the dataUpdate group and then update that to be the correct serverid.  
--select * from BATCHSERVERGROUP
DELETE BATCHSERVERGROUP
WHERE GROUPID <> 'DataUpdate'

UPDATE BATCHSERVERGROUP
SET SERVERID = '01@MB-ND01-VMD-015'

--I assume we can delete all of this only questions I have are automatic role assignment, user license report, and batch transfer for subledger journals.  If we want those we just need to change the script to update them to have the correct AOS.  Also if we want workflow working we need to update the workflow batch jobs
--select * from BATCH
--delete BATCH 
DELETE BATCH
WHERE CAPTION <> 'Named user license count reports processing'

UPDATE BATCH
SET SERVERID = '01@MB-ND01-VMD-015'

--If your smtp server is different between environments we need to update this otherwise we can remove this script
--select * from SYSEMAILPARAMETERS
--select * from SYSEMAILSMTPPASSWORD
--Once document management is setup we will need to update this.  Until then we will make sure the path is blank.
--select * from SysFileStoreParameters
UPDATE SYSFILESTOREPARAMETERS
SET FILEPATH = ''

--updating the OLAP info
--select * from BIANALYSISSERVER
--update BIANALYSISSERVER set SERVERNAME = 'MB-ND01-VMD-001', DEFAULTDATABASENAME = 'AX2012_Dev' where ISDEFAULT = 1
DELETE BIANALYSISSERVER
WHERE SERVERNAME != 'MB-ND01-VMD-015'

--update the connection string for olap
--select * from BICONFIGURATION
--update BICONFIGURATION set CONNECTIONSTRING = 'Provider=SQLNCLI10.1;Data Source=MB-ND01-VMD-001;Integrated Security=SSPI;Initial Catalog=DynamicsAX_2012_dev'
--update ssrs information
--select * from SRSSERVERS
UPDATE SRSSERVERS
SET SERVERID = 'MyDevReportServer'
	, SERVERURL = 'http://MyDevReportServer:8080/ReportServer'
	, REPORTMANAGERURL = 'http://MyDevReportServer:8080/Reports'
	, AOSID = '01@MB-ND01-VMD-015'
	, CONFIGURATIONID = 'DAX Dev'

--update help server info
--select VALUE from SYSGLOBALCONFIGURATION where NAME = 'HelpServerLocation'
UPDATE SYSGLOBALCONFIGURATION
SET VALUE = 'http://mydevaxhelpserver/DynamicsAX6HelpServer/HelpService.svc'
WHERE NAME = 'HelpServerLocation'

--update EP info
--select * from EPGLOBALPARAMETERS
--select * from EPWEBSITEPARAMETERS
--select * from COLLABSITEPARAMETERS
UPDATE EPGLOBALPARAMETERS
SET HOMEPAGESITEID = '39BE9290-B001-43EE-86E1-F52751B710CB'
	, DEVELOPMENTSITEID = '39BE9290-B001-43EE-86E1-F52751B710CB'
	, SEARCHSERVERURL = ''

UPDATE EPWEBSITEPARAMETERS
SET INTERNALURL = 'http://mydeverpportal'
	, SITEID = '39BE9290-B001-43EE-86E1-F52751B710CB'
	, EXTERNALURL = 'http://mydeverpportal'
