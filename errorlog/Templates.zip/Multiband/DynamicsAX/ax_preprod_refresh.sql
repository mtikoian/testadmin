USE [DynAX2012_PreProd]
GO

--List of AOS'  I would recommend we delete this table as when you start the aos in dev it will write a record to this table.  This way we get rid of references to production.
--select * from sysserversessions
DELETE SYSSERVERSESSIONS

--If you have a different admin account to be used in this environment we need to change the userinfo table
UPDATE USERINFO
SET sid = 'S-1-5-21-1551005637-2038879248-5624465-9356'
	, NETWORKALIAS = 'a.korey.miller'
WHERE ID = 'admin'

--We will want to automate creation of dev users probably by using existing user and changing id to developer
--select * from USERINFO
--Update the bc proxy user
--select * from SysBCProxyUserAccount
UPDATE SysBCProxyUserAccount
SET SID = 'S-1-5-21-1551005637-2038879248-5624465-18901'
	, NETWORKALIAS = 's.AX2012PreProdPrxy'

--update workflow system account
UPDATE USERINFO
SET SID = 'S-1-5-21-1551005637-2038879248-5624465-18902'
	, NETWORKALIAS = 's.AX2012PreProdWkfl'
WHERE ID = 'wfexc'

--update server configuration information - I would recommend that we delete this table and letting the record get created when you start the aos
--select * from SysServerConfig
DELETE SYSSERVERCONFIG

--update batch server information - I would recommend that we delete this table as the aos will get added when it connects for the first time
--select * from BatchServerConfig
DELETE BATCHSERVERCONFIG

--I would update this table so that only the default 'non load balanced aos instances' entry is left
--select * from SysClusterConfig
DELETE SYSCLUSTERCONFIG
WHERE CLUSTERNAME <> 'Non Load Balanced AOS Instances'

--For this one I think we should delete everything but the dataUpdate group and then update that to be the correct serverid.  
--select * from BATCHSERVERGROUP
DELETE BATCHSERVERGROUP
WHERE GROUPID <> 'DataUpdate'

UPDATE BATCHSERVERGROUP
SET SERVERID = '01@MB-ND01-VMT-027'

--I assume we can delete all of this only questions I have are automatic role assignment, user license report, and batch transfer for subledger journals.  If we want those we just need to change the script to update them to have the correct AOS.  Also if we want workflow working we need to update the workflow batch jobs
--select * from BATCH
DELETE BATCH

--delete BATCH where CAPTION <> 'Automatic role assignment'
UPDATE BATCH
SET SERVERID = '01@MB-ND01-VMT-027'
WHERE CAPTION LIKE 'workflow%'

--If your smtp server is different between environments we need to update this otherwise we can remove this script
--select * from SYSEMAILPARAMETERS
--select * from SYSEMAILSMTPPASSWORD
--Once document management is setup we will need to update this.  Until then we will make sure the path is blank.
--select * from SysFileStoreParameters
UPDATE SYSFILESTOREPARAMETERS
SET FILEPATH = ''

--updating the OLAP info
--select * from BIANALYSISSERVER
--update BIANALYSISSERVER set SERVERNAME = 'MB-ND01-VMT-038\Dyn2012_UATCable', DEFAULTDATABASENAME = 'Dynamics AX' where ISDEFAULT = 1
--delete BIANALYSISSERVER where SERVERNAME !='MB-ND01-VMT-038'
--update the connection string for olap
--select * from BICONFIGURATION
--UPDATE BICONFIGURATION
--SET CONNECTIONSTRING = 'Provider=SQLNCLI10.1;Data Source=MB-ND01-SCT-001;Integrated Security=SSPI;Initial Catalog=DynAX2012_PreProd'

--update ssrs information
--select * from SRSSERVERS
--update SRSSERVERS set SERVERID ='MB-ND01-VMT-038', SERVERURL = 'http://mb-nd01-vmt-033/ReportServer_DYN2012_Test', REPORTMANAGERURL='http://mb-nd01-vmt-033/Reports_DYN2012_TEST', AOSID = '01@MB-ND01-VMT-015', CONFIGURATIONID= 'DAX Test'
--update help server info
--select VALUE from SYSGLOBALCONFIGURATION where NAME = 'HelpServerLocation'
UPDATE SYSGLOBALCONFIGURATION
SET VALUE = 'http://dynamicsaxtesthelp.mbnd.local/DynamicsAX6HelpServer/HelpService.svc'
WHERE NAME = 'HelpServerLocation'
	--update EP info
	--select * from EPGLOBALPARAMETERS
	--select * from EPWEBSITEPARAMETERS
	--select * from COLLABSITEPARAMETERS
	--update EPGLOBALPARAMETERS set HOMEPAGESITEID = '00000000-0000-0000-0000-000000000000', DEVELOPMENTSITEID = '00000000-0000-0000-0000-000000000000' ,SEARCHSERVERURL = ''
	--update EPWEBSITEPARAMETERS set INTERNALURL='http://erptestportal.mbnd.local', SITEID= 'B6A6C8C4-434C-416B-981E-DFE3E7C91026', EXTERNALURL = 'http://erptestportal.mbnd.local'



USE [master]
GO

/****** Object:  StoredProcedure [dbo].[CREATETEMPDBPERMISSIONS_mb-nd01-vmd-004_01]    Script Date: 9/5/2013 1:55:33 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[CREATETEMPDBPERMISSIONS_mb-nd01-sct-001_PreProd]
AS
BEGIN
	EXEC (
			'USE tempdb;
                           DECLARE @dbaccesscount INT;
                           EXEC sp_grantlogin ''mbnd\s.AX2012PreProdAOS''; 
                           SELECT @dbaccesscount = COUNT(*) FROM master..syslogins WHERE name = ''mbnd\s.AX2012PreProdAOS''; 
                           IF (@dbaccesscount <> 0) EXEC sp_grantdbaccess ''mbnd\s.AX2012PreProdAOS''; 
                           ALTER USER [mbnd\s.AX2012PreProdAOS] WITH DEFAULT_SCHEMA=dbo;
                           EXEC sp_addrolemember ''db_ddladmin'', ''mbnd\s.AX2012PreProdAOS'';
                           EXEC sp_addrolemember ''db_datareader'', ''mbnd\s.AX2012PreProdAOS'';
                           EXEC sp_addrolemember ''db_datawriter'', ''mbnd\s.AX2012PreProdAOS'';'
			);
END
GO

EXEC sp_procoption N'[dbo].[CREATETEMPDBPERMISSIONS_mb-nd01-sct-001_PreProd]'
	, 'startup'
	, '1'
GO


USE [DynAX2012_PreProd]
GO
CREATE USER [MBND\s.AX2012PreProdAOS] FOR LOGIN [MBND\s.AX2012PreProdAOS]
GO
USE [DynAX2012_PreProd]
GO
ALTER USER [MBND\s.AX2012PreProdAOS] WITH DEFAULT_SCHEMA=[dbo]
GO
USE [DynAX2012_PreProd]
GO
EXEC sp_addrolemember N'db_owner', N'MBND\s.AX2012PreProdAOS'
GO
USE [DynAX2012_PreProd_model]
GO
CREATE USER [MBND\s.AX2012PreProdAOS] FOR LOGIN [MBND\s.AX2012PreProdAOS]
GO
USE [DynAX2012_PreProd_model]
GO
ALTER USER [MBND\s.AX2012PreProdAOS] WITH DEFAULT_SCHEMA=[dbo]
GO
USE [DynAX2012_PreProd_model]
GO
EXEC sp_addrolemember N'db_owner', N'MBND\s.AX2012PreProdAOS'
GO


USE [DynAX2012_PreProd]
GO
CREATE USER [MBND\s.AX2012PreProdPrxy] FOR LOGIN [MBND\s.AX2012PreProdPrxy]
GO
USE [DynAX2012_PreProd]
GO
ALTER USER [MBND\s.AX2012PreProdPrxy] WITH DEFAULT_SCHEMA=[dbo]
GO
USE [DynAX2012_PreProd]
GO
EXEC sp_addrolemember N'db_datareader', N'MBND\s.AX2012PreProdPrxy'
GO
USE [DynAX2012_PreProd_model]
GO
CREATE USER [MBND\s.AX2012PreProdPrxy] FOR LOGIN [MBND\s.AX2012PreProdPrxy]
GO
USE [DynAX2012_PreProd_model]
GO
ALTER USER [MBND\s.AX2012PreProdPrxy] WITH DEFAULT_SCHEMA=[dbo]
GO
USE [DynAX2012_PreProd_model]
GO
EXEC sp_addrolemember N'db_datareader', N'MBND\s.AX2012PreProdPrxy'
GO