--
-- SSMS Template
-- Run with: Ctrl-Shift-M
-- Paste in Bad Order IDs into the prompted Value field
--

BEGIN TRAN find_bad_commission_work
USE SPIdb;

--
-- Find Bad DirectTV Commission entries
-- 
IF  EXISTS (SELECT * FROM tempdb.dbo.sysobjects
			WHERE ID = OBJECT_ID(N'tempdb..[#badCommissionDirectTV]')
				AND type in (N'U'))
	DROP TABLE tempdb..[#badCommissionDirectTV]
;

SELECT
	intRVOrderID
	, intCustNo
	, txtCustFirstName
	, txtCustLastName
	, intPayDateID
	, intOrderID
	, intTechPayJobID
INTO #badCommissionDirectTV
FROM tblRVOrderSales
WHERE intRVOrderID IN (<bad_order_ids, list, 62991,62946,54269,55026,62807>)
	AND intPayDateID IS NULL
;
SELECT *
FROM #badCommissionDirectTV
;
DROP TABLE #badCommissionDirectTV;


--
-- Find Custom Work Commissions
-- 
IF  EXISTS (SELECT * FROM tempdb.dbo.sysobjects
			WHERE ID = OBJECT_ID(N'tempdb..[#badCommissionCustom]')
				AND type in (N'U'))
	DROP TABLE tempdb..[#badCommissionCustom]
;

SELECT ehpod.mnyCommission
	, ehpod.mnyTechPay
	, ehpod.intOrderDetailID
	, ehpod.intintOrderID
	, ehpo.txtBillingFirstName
	, ehpo.txtBillingLastName
	, ehpo.dteOrderDate
INTO #badCommissionCustom
FROM tblEHPOrderDetails ehpod
	JOIN tblEHPOrders ehpo ON (ehpo.intOrderId = ehpod.intintOrderId)
WHERE intOrderDetailID IN (<bad_order_ids, list, 62991,62946,54269,55026,62807>)
;
SELECT *
FROM #badCommissionCustom
;
DROP TABLE #badCommissionCustom
;

ROLLBACK TRAN find_bad_commission_work