-- File Name    :       Uninstall Ola Hallengren Maintenance System.sql
-- Author       :       Graham Okely B App Sc
-- Email        :       Graham.DBA@gmail.com
-- Blog         :       http://sqlgokely.blogspot.com.au/
-- Disclaimer   :       Use at your own risk of course! It may help someone.
-- Reference    :       http://ola.hallengren.com/
/*
==[ Modifications ]=========================================================
DD/MM/YYYY <WHO>        : [Description of changes]
9/7/2012 GJO            : Initial version
10/7/2012 GJO           : Altered function drop process

8/10/2012 GJO           : NOTE: This is for a clean uninstall for th3e purpose of
: reinstallation! THe system is a good product.

============================================================================
*/
--------------------------------------
-- Select Database
USE master
GO

DECLARE @Select_Server VARCHAR(1024)
DECLARE @Current_Server VARCHAR(1024)
DECLARE @Choice INT

----------------------------------------
-- Ensure you have the correct server
----------------------------------------
-- Specify servername
SET @Select_Server = 'MB-ND01-VMG-049\AXDB_Test'

SELECT @Current_Server = @@servername

PRINT @Select_Server
PRINT @Current_Server
----------------------------------------
-- Select level of clean up
SET @Choice = 0

-- 0 all
-- 1 tables
-- 2 Drop stored procedures
-- 3 Drop function
-- 4 Drop jobs
-- 5 Drop purge jobs
IF (@Select_Server = @Current_Server)
BEGIN
	PRINT 'Uninstall Ola Maintenance System from ' + @Select_Server
	PRINT 'At level ' + cast(@Choice AS VARCHAR(1))
	PRINT getdate()

	----------------------------------------
	-- Drop tables
	IF (
			@Choice = 1
			OR @Choice = 0
			)
	BEGIN
		IF OBJECT_ID(N'dbo.CommandLog', 'U') IS NOT NULL
			AND OBJECT_ID(N'dbo.CommandLog_Bak', 'U') IS NULL
		BEGIN
			-- Backup log
			SELECT *
			INTO [dbo].[CommandLog_Bak]
			FROM [dbo].[CommandLog]

			-- log action
			INSERT INTO [dbo].[CommandLog_Bak] (
				Command
				, CommandType
				, StartTime
				)
			VALUES (
				'Uninstall all objects'
				, 'CLEAN'
				, getdate()
				)

			DROP TABLE [dbo].[CommandLog]
		END
	END

	----------------------------------------
	-- Drop stored procedures
	IF (
			@Choice = 2
			OR @Choice = 0
			)
	BEGIN
		IF EXISTS (
				SELECT *
				FROM sys.objects
				WHERE type = 'P'
					AND NAME = 'CommandExecute'
				)
			DROP PROCEDURE [dbo].[CommandExecute]

		IF EXISTS (
				SELECT *
				FROM sys.objects
				WHERE type = 'P'
					AND NAME = 'DatabaseBackup'
				)
			DROP PROCEDURE [dbo].[DatabaseBackup]

		IF EXISTS (
				SELECT *
				FROM sys.objects
				WHERE type = 'P'
					AND NAME = 'DatabaseIntegrityCheck'
				)
			DROP PROCEDURE [dbo].[DatabaseIntegrityCheck]

		IF EXISTS (
				SELECT *
				FROM sys.objects
				WHERE type = 'P'
					AND NAME = 'IndexOptimize'
				)
			DROP PROCEDURE [dbo].[IndexOptimize]
	END

	----------------------------------------
	-- Drop functions
	IF (
			@Choice = 3
			OR @Choice = 0
			)
	BEGIN
		IF OBJECT_ID('[dbo].[DatabaseSelect]') IS NOT NULL
			DROP FUNCTION [dbo].[DatabaseSelect]
	END

	----------------------------------------
	-- Drop jobs
	IF (
			@Choice = 4
			OR @Choice = 0
			)
	BEGIN
		IF EXISTS (
				SELECT job_id
				FROM msdb.dbo.sysjobs_view
				WHERE NAME = N'CommandLog Cleanup'
				)
		BEGIN
			EXEC msdb.dbo.sp_delete_job @job_name = N'CommandLog Cleanup'
				, @delete_unused_schedule = 1
		END

		IF EXISTS (
				SELECT job_id
				FROM msdb.dbo.sysjobs_view
				WHERE NAME = N'DatabaseBackup - SYSTEM_DATABASES - FULL'
				)
		BEGIN
			EXEC msdb.dbo.sp_delete_job @job_name = N'DatabaseBackup - SYSTEM_DATABASES - FULL'
				, @delete_unused_schedule = 1
		END

		IF EXISTS (
				SELECT job_id
				FROM msdb.dbo.sysjobs_view
				WHERE NAME = N'DatabaseIntegrityCheck - USER_DATABASES Lite'
				)
		BEGIN
			EXEC msdb.dbo.sp_delete_job @job_name = N'DatabaseIntegrityCheck - USER_DATABASES Lite'
				, @delete_unused_schedule = 1
		END

		IF EXISTS (
				SELECT job_id
				FROM msdb.dbo.sysjobs_view
				WHERE NAME = N'DatabaseBackup - USER_DATABASES - DIFF'
				)
		BEGIN
			EXEC msdb.dbo.sp_delete_job @job_name = N'DatabaseBackup - USER_DATABASES - DIFF'
				, @delete_unused_schedule = 1
		END

		IF EXISTS (
				SELECT job_id
				FROM msdb.dbo.sysjobs_view
				WHERE NAME = N'DatabaseBackup - USER_DATABASES - FULL'
				)
		BEGIN
			EXEC msdb.dbo.sp_delete_job @job_name = N'DatabaseBackup - USER_DATABASES - FULL'
				, @delete_unused_schedule = 1
		END

		IF EXISTS (
				SELECT job_id
				FROM msdb.dbo.sysjobs_view
				WHERE NAME = N'DatabaseBackup - USER_DATABASES - LOG'
				)
		BEGIN
			EXEC msdb.dbo.sp_delete_job @job_name = N'DatabaseBackup - USER_DATABASES - LOG'
				, @delete_unused_schedule = 1
		END

		IF EXISTS (
				SELECT job_id
				FROM msdb.dbo.sysjobs_view
				WHERE NAME = N'DatabaseIntegrityCheck - SYSTEM_DATABASES'
				)
		BEGIN
			EXEC msdb.dbo.sp_delete_job @job_name = N'DatabaseIntegrityCheck - SYSTEM_DATABASES'
				, @delete_unused_schedule = 1
		END

		IF EXISTS (
				SELECT job_id
				FROM msdb.dbo.sysjobs_view
				WHERE NAME = N'DatabaseIntegrityCheck - USER_DATABASES'
				)
		BEGIN
			EXEC msdb.dbo.sp_delete_job @job_name = N'DatabaseIntegrityCheck - USER_DATABASES'
				, @delete_unused_schedule = 1
		END

		IF EXISTS (
				SELECT job_id
				FROM msdb.dbo.sysjobs_view
				WHERE NAME = N'IndexOptimise'
				)
		BEGIN
			EXEC msdb.dbo.sp_delete_job @job_name = N'IndexOptimise'
				, @delete_unused_schedule = 1
		END

		IF EXISTS (
				SELECT job_id
				FROM msdb.dbo.sysjobs_view
				WHERE NAME = N'IndexOptimize - USER_DATABASES'
				)
		BEGIN
			EXEC msdb.dbo.sp_delete_job @job_name = N'IndexOptimize - USER_DATABASES'
				, @delete_unused_schedule = 1
		END

		IF EXISTS (
				SELECT job_id
				FROM msdb.dbo.sysjobs_view
				WHERE NAME = N'Output File Cleanup'
				)
		BEGIN
			EXEC msdb.dbo.sp_delete_job @job_name = N'Output File Cleanup'
				, @delete_unused_schedule = 1
		END
	END

	----------------------------------------
	-- Drop purge jobs
	IF (
			@Choice = 5
			OR @Choice = 0
			)
	BEGIN
		IF EXISTS (
				SELECT job_id
				FROM msdb.dbo.sysjobs_view
				WHERE NAME = N'sp_delete_backuphistory'
				)
			EXEC msdb.dbo.sp_delete_job @job_name = N'sp_delete_backuphistory'
				, @delete_unused_schedule = 1

		IF EXISTS (
				SELECT job_id
				FROM msdb.dbo.sysjobs_view
				WHERE NAME = N'sp_purge_jobhistory'
				)
			EXEC msdb.dbo.sp_delete_job @job_name = N'sp_purge_jobhistory'
				, @delete_unused_schedule = 1
	END
END
