USE master;
GO

SET NOCOUNT ON;

SELECT rol.NAME
	, mem.NAME
	, mem.type_desc
FROM sys.server_role_members AS srm
	INNER JOIN sys.server_principals AS rol
		ON rol.principal_id = srm.role_principal_id
	INNER JOIN sys.server_principals AS mem
		ON mem.principal_id = srm.member_principal_id
WHERE rol.NAME = 'sysadmin'
;

GO
