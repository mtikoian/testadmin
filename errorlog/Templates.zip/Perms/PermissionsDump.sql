USE master;
GO

SET NOCOUNT ON;

PRINT 'USE [' + DB_NAME() + ']';
PRINT 'GO';
SELECT 'EXEC sp_addrolemember N''' + p.NAME + ''', N''' + m.NAME + ''''
FROM sys.database_role_members rm
	JOIN sys.database_principals p
		ON rm.role_principal_id = p.principal_id
	JOIN sys.database_principals m
		ON rm.member_principal_id = m.principal_id
WHERE m.NAME NOT IN ('dbo', 'MBND\srv_SQLReplication')
	AND m.NAME NOT LIKE 'MSRepl%'
ORDER BY m.NAME
	, p.NAME
;

PRINT 'GO';

SELECT 'ALTER USER [' + m.name + ']' + ' WITH DEFAULT_SCHEMA=[MB]'
FROM sys.database_role_members rm
	JOIN sys.database_principals p
		ON rm.role_principal_id = p.principal_id
	JOIN sys.database_principals m
		ON rm.member_principal_id = m.principal_id
WHERE m.NAME <> 'dbo'
	AND m.NAME NOT LIKE 'MSRepl%'
	AND m.NAME NOT LIKE 'MBND\%'		-- domain groups cannot have default schemas
	AND m.NAME NOT LIKE 'MULTIBAND\%'	-- domain groups cannot have default schemas
GROUP BY m.name
ORDER BY m.NAME
;
PRINT 'GO';

GO
