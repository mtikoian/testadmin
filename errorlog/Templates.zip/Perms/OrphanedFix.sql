USE SPIdb;
GO

SET NOCOUNT ON;

EXEC sp_change_users_login @Action = 'Report';

EXEC sp_change_users_login
	@Action = 'Auto_Fix'
	, @UserNamePattern = 'sql.AudiSteam';

EXEC sp_change_users_login
	@Action = 'Auto_Fix'
	, @UserNamePattern = 'sql.SPI';

EXEC sp_change_users_login
	@Action = 'Auto_Fix'
	, @UserNamePattern = 'sql.TechPayUser';
GO


USE TechPayAppData;
GO

SET NOCOUNT ON;

EXEC sp_change_users_login @Action = 'Report';

EXEC sp_change_users_login
	@Action = 'Auto_Fix'
	, @UserNamePattern = 'sql.AudiSteam';

EXEC sp_change_users_login
	@Action = 'Auto_Fix'
	, @UserNamePattern = 'sql.SPI';

EXEC sp_change_users_login
	@Action = 'Auto_Fix'
	, @UserNamePattern = 'sql.TechPayUser';
GO


