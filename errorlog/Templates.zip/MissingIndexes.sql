-- =========================================================================
-- Title: <Title,,>
-- Author: Nem W Schlecht
-- Create Date: <Create Date,,>
-- Copyright: Goodman Networks/Multiband, Copyright (C) 2014
-- Description: <Description,,>
-- =========================================================================
SET XACT_ABORT ON;
SET NOCOUNT ON;

-- Make sure we're not in a transaction
IF (@@TRANCOUNT > 0)
BEGIN
	ROLLBACK;
END;

BEGIN TRANSACTION;

SAVE TRAN nws_ssms;

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

DECLARE @indent VARCHAR(10) = CHAR(10) + CHAR(9) + ', ';

SELECT TOP(100)
	ROUND(s.avg_total_user_cost * s.avg_user_impact * (s.user_seeks + s.user_scans), 0) AS [Total Cost]
	, d.[statement] AS [Table Name]
	, equality_columns
	, inequality_columns
	, included_columns
	, CASE
		WHEN (equality_columns IS NOT NULL AND d.inequality_columns IS NULL)
			THEN CHAR(10)
				+ 'CREATE INDEX idx_'
				+ REPLACE(REPLACE(REPLACE(REPLACE(d.[statement], '.', '_'), '[', ''), ']', ''), ' ', '')
				+ '_'
				+ REPLACE(REPLACE(REPLACE(REPLACE(equality_columns, ',', '_'), '[', ''), ']', ''), ' ', '')
				+ ' ON '
				+ d.statement
				+ ' ('
				+ CHAR(10)
				+ CHAR(9)
				+ REPLACE(d.equality_columns, ', ', @indent)
				+ CHAR(10)
				+ ')'
				+ ';'
				+ CHAR(10)
		WHEN (equality_columns IS NULL AND d.inequality_columns IS NOT NULL)
			THEN CHAR(10)
				+ 'CREATE INDEX idx_'
				+ REPLACE(REPLACE(REPLACE(REPLACE(d.[statement], '.', '_'), '[', ''), ']', ''), ' ', '')
				+ '_'
				+ REPLACE(REPLACE(REPLACE(REPLACE(inequality_columns, ',', '_'), '[', ''), ']', ''), ' ', '')
				+ ' ON '
				+ d.statement
				+ ' ('
				+ CHAR(10)
				+ CHAR(9)
				+ REPLACE(d.inequality_columns, ', ', @indent)
				+ CHAR(10)
				+ ')'
				+ ';'
				+ CHAR(10)
		WHEN (equality_columns IS NOT NULL AND d.inequality_columns IS NOT NULL)
			THEN CHAR(10)
				+ 'CREATE INDEX idx_'
				+ REPLACE(REPLACE(REPLACE(REPLACE(d.[statement], '.', '_'), '[', ''), ']', ''), ' ', '')
				+ '_'
				+ REPLACE(REPLACE(REPLACE(REPLACE(equality_columns, ',', '_'), '[', ''), ']', ''), ' ', '')
				+ '_'
				+ REPLACE(REPLACE(REPLACE(REPLACE(inequality_columns, ',', '_'), '[', ''), ']', ''), ' ', '')
				+ ' ON '
				+ d.statement
				+ ' ('
				+ CHAR(10)
				+ CHAR(9)
				+ REPLACE(d.equality_columns, ', ', @indent)
				+ CHAR(10)
				+ CHAR(9)
				+ ', '
				+ REPLACE(d.inequality_columns, ', ', @indent)
				+ CHAR(10)
				+ ')'
				+ ';'
				+ CHAR(10)
		END AS 'Index_SQL'
FROM sys.dm_db_missing_index_groups g
	INNER JOIN sys.dm_db_missing_index_group_stats s
		ON s.group_handle = g.index_group_handle
	INNER JOIN sys.dm_db_missing_index_details d
		ON d.index_handle = g.index_handle
WHERE d.[statement] like '%SPIdb%'
ORDER BY [Total Cost] DESC

ROLLBACK TRANSACTION nws_ssms;

COMMIT;
GO


