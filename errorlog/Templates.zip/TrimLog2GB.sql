USE master;
GO

SET NOCOUNT ON;

DECLARE @cur_dbname VARCHAR(100)
	, @cur_db_logfile VARCHAR(100)
	, @SQL NVARCHAR(MAX)
	, @param NVARCHAR(1000)
;

DECLARE @Search VARCHAR(200) = '';		-- limit to these databases (search)
--DECLARE @SimpleMode BIT = 1;			-- Force SIMPLE mode reduction

DECLARE dbcur CURSOR LOCAL READ_ONLY FORWARD_ONLY
FOR
SELECT NAME
FROM sys.databases
WHERE NAME NOT IN (
		'master'
		, 'tempdb'
		, 'model'
		, 'msdb'
		)
	AND NAME LIKE '%' + @Search + '%'
	AND state_desc = 'ONLINE'
ORDER BY NAME
;

OPEN dbcur;

FETCH NEXT
FROM dbcur
INTO @cur_dbname
;


WHILE (@@FETCH_STATUS = 0)
BEGIN
	PRINT 'PRINT ''Shrinking: ' + @cur_dbname + '''';
	PRINT 'USE [' + @cur_dbname + ']';
	PRINT 'GO';
	PRINT 'ALTER DATABASE [' + @cur_dbname + '] SET RECOVERY SIMPLE WITH NO_WAIT';
	PRINT 'GO';
	
	SET @param = '@logfile VARCHAR(100) OUTPUT';
	SET @SQL = 'SELECT @logfile = name FROM [' + @cur_dbname + '].sys.database_files WHERE type = 1';
	EXECUTE sp_executesql
		@SQL
		, @param
		, @logfile = @cur_db_logfile OUTPUT
	;
	
	PRINT '--DBCC SHRINKFILE (N''' + @cur_db_logfile + ''' , 0, TRUNCATEONLY)';
	PRINT '--GO';
	PRINT 'DBCC SHRINKFILE (N''' + @cur_db_logfile + ''' , 2000)';
	PRINT 'GO';
	PRINT 'ALTER DATABASE [' + @cur_dbname + '] SET RECOVERY FULL WITH NO_WAIT';
	PRINT 'GO';
	
	PRINT '';
	
	FETCH NEXT
	FROM dbcur
	INTO @cur_dbname
	;

END;

CLOSE dbcur;
DEALLOCATE dbcur;

GO
