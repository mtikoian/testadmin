USE distribution;
GO

SET NOCOUNT ON;

SELECT s.agent_id
	, a.id
	, s.article_id
	, a.subscriber_id
	, ar.Source_owner
	, ar.Source_object
	, ar.destination_owner
	, ar.destination_object
	, s.undelivcmdsindistdb
	, a.publisher_db
	, a.subscriber_db
	, a.publication
FROM distribution.dbo.msdistribution_status s WITH (NOLOCK)
	INNER JOIN (
		SELECT *
		FROM msdistribution_agents WITH (NOLOCK)
		) AS a
		ON a.id = s.agent_id
	INNER JOIN (
		SELECT *
		FROM msarticles WITH (NOLOCK)
		) AS ar
		ON ar.article_id = s.article_id
			AND a.publisher_Db = ar.publisher_db
WHERE a.subscriber_db <> 'virtual'
	AND s.undelivcmdsindistdb > 0
ORDER BY s.undelivcmdsindistdb DESC
;
GO

