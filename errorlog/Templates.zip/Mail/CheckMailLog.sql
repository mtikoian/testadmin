USE msdb;
GO

SET NOCOUNT ON;

SELECT *
FROM sysmail_allitems;
--sysmail_help_status_sp;
--sysmail_delete_mailitems_sp;
--sysmail_allitems;
--sysmail_event_log;
--sysmail_faileditems;
--sysmail_mailattachments;
--sysmail_sentitems;
--sysmail_unsentitems;
GO


