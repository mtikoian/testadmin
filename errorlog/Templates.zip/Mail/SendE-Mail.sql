USE msdb;
GO

SET NOCOUNT ON;

EXEC msdb.dbo.sp_send_dbmail
	@recipients = 'dba@emptec.com'
	, @from_address = 'nem@emptec.com'
	, @subject = 'Some subject'
	, @body = 'whatever'
	, @profile_name = 'MB_DBA_Profile';
GO


