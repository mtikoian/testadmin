-- Verify Agent
USE master;
GO

SET NOCOUNT ON;

EXEC xp_servicecontrol
	N'QueryState'
	, N'SQLServerAGENT'
;
GO

-- Verify Broker
SELECT is_broker_enabled
FROM sys.databases
WHERE database_id = DB_ID(N'msdb')
;
GO

-- Enable Broker (if needed)
--USE master
--Go

--ALTER DATABASE msdb SET ENABLE_BROKER WITH ROLLBACK IMMEDIATE;
--Go

EXEC sp_configure
	@configname = 'show advanced options'
	, @configvalue = 1
;
GO

RECONFIGURE;
GO

EXEC sp_configure
	@configname = 'Database Mail XPs'
	, @configvalue = 1
;
GO

RECONFIGURE;
GO

EXEC sp_configure
	@configname = 'show advanced options'
	, @configvalue = 0
;
GO

RECONFIGURE;
GO

-- Create a Database Mail account
EXEC msdb.dbo.sysmail_add_account_sp
	@account_name = 'MB_DBA_Account'
	, @description = 'Multiband DBA E-mail Notifications'
	, @email_address = 'dba@multibandusa.com'
	, @display_name = 'Multiband DBA'
	, @replyto_address = 'dba@multibandusa.com'
	, @mailserver_type = 'SMTP'
	, @mailserver_name = 'email.multibandusa.com'
	, @port = 25
	, @use_default_credentials = 0
;
GO

-- Create a Database Mail profile
EXEC msdb.dbo.sysmail_add_profile_sp
	@profile_name = 'MB_DBA_Profile'
	, @description = 'Profile for Multiband DBAs'
;
GO

-- Add the account to the profile
EXEC msdb.dbo.sysmail_add_profileaccount_sp
	@profile_name = 'MB_DBA_Profile'
	, @account_name = 'MB_DBA_Account'
	, @sequence_number = 1
;
GO

EXEC msdb.dbo.sp_add_operator
	@name=N'MB DBA'
	, @enabled=1
	, @pager_days=0
	, @email_address=N'dba@multibandusa.com'
;
GO
