USE master;
GO

SET NOCOUNT ON;

SELECT dbs.name
	, mf.NAME
	, physical_name
	, type_desc
	--, ISNULL(osperf_data.cntr_value, osperf_logs.cntr_value) AS dbsize_kb
	, CAST(ISNULL(osperf_data.cntr_value, osperf_logs.cntr_value)/1024 AS NUMERIC(12,2)) AS dbsize_mb
	--, CAST(CAST(ISNULL(osperf_data.cntr_value, osperf_logs.cntr_value)/1024 AS NUMERIC(12,2))/1024 AS NUMERIC(12,2)) AS dbsize_gb
	--, size
	--, CAST((size/102.4)/1024 AS NUMERIC(12,2)) as DBSize_GB
	, mf.STATE
	, mf.state_desc
--	, *
FROM sys.master_files AS mf
	JOIN sys.databases AS dbs
		ON mf.database_id = dbs.database_id
	LEFT JOIN sys.dm_os_performance_counters AS osperf_data
		 ON dbs.name = osperf_data.instance_name
			AND RTRIM(osperf_data.counter_name) = 'Data File(s) Size (KB)'
			AND type_desc = 'ROWS'
	LEFT JOIN sys.dm_os_performance_counters AS osperf_logs
		 ON dbs.name = osperf_logs.instance_name
			AND RTRIM(osperf_logs.counter_name) = 'Log File(s) Size (KB)'
			AND type_desc = 'LOG'
ORDER BY dbs.name
	, physical_name
;

GO
