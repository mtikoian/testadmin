-- cpu usage history
USE master;
GO

SET NOCOUNT ON;

DECLARE @ts_now BIGINT;

--SELECT @ts_now = cpu_ticks / CONVERT(FLOAT, cpu_ticks) FROM sys.dm_os_sys_info
SELECT @ts_now = ms_ticks
FROM sys.dm_os_sys_info;

SELECT
	--record_id
	--	,
	CONVERT(VARCHAR(19), DATEADD(ms, - 1 * (@ts_now - [timestamp]), GETDATE()), 120) AS EventTime
	, SQLProcessUtilization
	, SystemIdle
	, 100 - SystemIdle - SQLProcessUtilization AS OtherProcessUtilization
FROM (
	SELECT record.value('(./Record/@id)[1]', 'int') AS record_id
		, record.value('(./Record/SchedulerMonitorEvent/SystemHealth/SystemIdle)[1]', 'int') AS SystemIdle
		, record.value('(./Record/SchedulerMonitorEvent/SystemHealth/ProcessUtilization)[1]', 'int') AS SQLProcessUtilization
		, TIMESTAMP
	FROM (
		SELECT TIMESTAMP
			, CONVERT(XML, record) AS record
		FROM sys.dm_os_ring_buffers
		WHERE ring_buffer_type = N'RING_BUFFER_SCHEDULER_MONITOR'
			AND record LIKE '% %'
		) AS x
	) AS y
ORDER BY EVentTime
;

GO
