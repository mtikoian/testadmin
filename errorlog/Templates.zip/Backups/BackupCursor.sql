USE master;
GO
-- Back up all databases to a directory given a database name pattern (LIKE)
--
SET NOEXEC OFF;
SET NOCOUNT ON;

-- User setable vars
DECLARE @debug INT = 1;-- 0: actually backup   1: just print the backup commands
DECLARE @verify_backup INT = 1;-- 0: do NOT verify backup   1: verify backup
	--DECLARE @bkpath VARCHAR(1000) = 'I:\TugPreRefresh\MB-ND01-VMD-002'
	--DECLARE @prepend_host_db INT = 0;-- 0: Do NOT prepend 	1: prepend
DECLARE @bkpath VARCHAR(1000) = 'I:\TugPreRefresh';
DECLARE @do_copy_only INT = 1;-- 0: in-flow copy, 1: copy-only copy
DECLARE @prepend_host_db INT = 0;-- 0: Do NOT prepend host 	1: prepend
DECLARE @dbpattern VARCHAR(1000) = '%';-- Set this line!
DECLARE @dbpattern_skip VARCHAR(1000) = '%snapshot%';--optional
DECLARE @stats VARCHAR(5) = '5';-- statistics frequency update
DECLARE @DBA_inits VARCHAR(3) = 'NWS';-- DBA's initials
-- DECLARE @ServerName = @@SERVERNAME;
DECLARE @SQL NVARCHAR(MAX) = '';
DECLARE @filename VARCHAR(1000);
DECLARE @cur_database VARCHAR(100);
DECLARE @cur_bk_name VARCHAR(1000);
DECLARE @copy_only VARCHAR(100) = '';
DECLARE @cur_time_str VARCHAR(100) = CONVERT(VARCHAR(40), GETDATE(), 112);

SET @cur_time_str = @cur_time_str + '_' + REPLACE(CONVERT(VARCHAR(40), GETDATE(), 108), ':', '');

DECLARE bkfilelistcur CURSOR LOCAL FORWARD_ONLY READ_ONLY
FOR
SELECT NAME
FROM sys.databases
WHERE NAME /* COLLATE Latin1_General_CS_AS */ LIKE @dbpattern
	AND STATE = 0
	AND NAME NOT IN (
		'master'
		, 'msdb'
		, 'model'
		, 'tempdb'
		)
	AND NAME NOT LIKE @dbpattern_skip
ORDER BY NAME
;

OPEN bkfilelistcur;

FETCH NEXT
FROM bkfilelistcur
INTO @cur_database
;

WHILE (@@FETCH_STATUS = 0)
BEGIN
	SET @cur_bk_name = @cur_database + '-Full Database Backup';
	SET @filename = @bkpath + '\';

	IF (@do_copy_only = 1)
	BEGIN
		SET @copy_only = '	, COPY_ONLY' + CHAR(10);
	END;

	IF (@prepend_host_db = 1)
	BEGIN
		SET @filename = @filename
			+ REPLACE(@@SERVERNAME, '\', '_')
			+ '\'
			+ @cur_database
			+ '\'
			+ 'FULL'
			+ '\'
		;
	END;

	SET @filename = @filename
		+ REPLACE(@@SERVERNAME, '\', '_')
		+ '_'
		+ @cur_database
		+ '_FULL_'
		+ @cur_time_str
		+ '-'
		+ @DBA_inits
		+ '.bak'
	;
	SET @filename = REPLACE(@filename, ' ', '_');
	SET @SQL = '
PRINT ''*** Backup for '
	+ @cur_database
	+ ' started: '' + (CONVERT(VARCHAR(24), GETDATE(), 120))
BACKUP DATABASE ['
	+ @cur_database
	+ ']' + CHAR(10)
	+ '	TO DISK = N'''
	+ @filename + '''' + CHAR(10)
	+ '	WITH NOFORMAT' + CHAR(10)
	+ @copy_only
	+ '	, NOINIT' + CHAR(10)
	+ '	, NAME = N'''
	+ @cur_bk_name
	+ '''' + CHAR(10)
	+ '	, SKIP' + CHAR(10)
	+ '	, COMPRESSION' + CHAR(10)
	+ '	, NOREWIND' + CHAR(10)
	+ '	, NOUNLOAD' + CHAR(10)
	+ '	, STATS = ' + @stats + CHAR(10)
	+ ';'
	+ CHAR(10)
	;

	IF (@verify_backup = 1)
	BEGIN
		SET @SQL = @SQL + '
DECLARE @backupSetId AS INT
SELECT @backupSetId = position
FROM msdb..backupset
WHERE database_name=N'''
	+ @cur_database + '''' + CHAR(10)
	+ '	AND backup_set_id=(' + CHAR(10)
	+ '		SELECT MAX(backup_set_id)' + CHAR(10)
	+ '		FROM msdb..backupset' + CHAR(10)
	+ '		WHERE database_name=N''' + @cur_database + '''' + CHAR(10)
	+ '		)
IF (@backupSetId IS NULL)
BEGIN
	RAISERROR(N''Verify failed. Backup information for database '''''
	+ @cur_database
	+ ''''' not found.''
		, 16
		, 1
		);
END
RESTORE VERIFYONLY
	FROM DISK = N''' + @filename + '''
	WITH FILE = @backupSetId
	, NOUNLOAD
	, NOREWIND
GO
PRINT ''*** Backup for '
	+ @cur_database
	+ ' completed: '' + (CONVERT( VARCHAR(24), GETDATE(), 120))
'
;
	END;

	PRINT @SQL + CHAR(10);

	IF (@debug = 0)
	BEGIN
		EXEC (@SQL);
		PRINT '';
	END;

	FETCH NEXT
	FROM bkfilelistcur
	INTO @cur_database
	;
END;

CLOSE bkfilelistcur;

DEALLOCATE bkfilelistcur;

GO
