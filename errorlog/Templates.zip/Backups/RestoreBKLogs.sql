--
-- Restore all ".bak" files in a directory to the current database
--

SET NOCOUNT ON

-- User setable vars
DECLARE @debug INT = 1;			-- 0: actually restore   1: just print the restore commands
DECLARE @bkpath VARCHAR(1000) = 'F:\MSSQL\Backup';
DECLARE @bkservname VARCHAR(100) = REPLACE(@@servername, '\', '$');
DECLARE @force_disconnect INT = 0;				-- 0: do *not* force disconnect (error)		1: Force disconnect
DECLARE @target_db VARCHAR(100) = 'ssmslog';		-- Search target include filename

DECLARE @newdbfilename VARCHAR(100);
DECLARE @newlogname VARCHAR(100);

DECLARE @SQL NVARCHAR(MAX) = '';
DECLARE @filename VARCHAR(1000);
DECLARE @dbname VARCHAR(100);
DECLARE @dbfilename VARCHAR(100);
DECLARE @logname VARCHAR(100);
DECLARE @datafileinfo TABLE (
	name VARCHAR(200)
	, DEPTH INT
	, isfile BIT
);

DECLARE @logfileinfo TABLE (
	name VARCHAR(200)
	, DEPTH INT
	, isfile BIT
);

DECLARE @bkfileinfo TABLE (
	LogicalName VARCHAR(100),
	PhysicalName VARCHAR(1000),
	TYPE VARCHAR(5),
	FileGroupName VARCHAR(100),
	SIZE BIGINT,
	MaxSize BIGINT,
	FileID BIGINT,
	CreateLSN BIT,
	DropLSN BIT,
	UniqueId UNIQUEIDENTIFIER,
	ReadOnlyLSN BIT,
	ReadWriteLSN BIT,
	BackupSizeInBytes BIGINT,
	SourceBlockSize BIGINT,
	FileGroupId INT,
	LogGroupGUID UNIQUEIDENTIFIER,
	DifferentialBaseLSN BIT,
	DifferentialBaseGUID UNIQUEIDENTIFIER,
	IsReadOnly BIT,
	IsPresent BIT,
	TDEThumbprint VARCHAR(1000)
);

DECLARE @param NVARCHAR(500);
DECLARE @sysdatafile NVARCHAR(1000);
DECLARE @syslogfile NVARCHAR(1000);
DECLARE @sysdataname NVARCHAR(1000);
DECLARE @syslogname NVARCHAR(1000);
DECLARE @defaultdatafiledir NVARCHAR(1000);
DECLARE @defaultsyslogfiledir NVARCHAR(1000);

DECLARE @rc INT
EXEC @rc = master.dbo.xp_instance_regread N'HKEY_LOCAL_MACHINE',N'Software\Microsoft\MSSQLServer\MSSQLServer',N'DefaultData', @defaultdatafiledir OUTPUT, 'no_output'
EXEC @rc = master.dbo.xp_instance_regread N'HKEY_LOCAL_MACHINE',N'Software\Microsoft\MSSQLServer\MSSQLServer',N'DefaultLog', @defaultsyslogfiledir OUTPUT, 'no_output'

IF (@defaultdatafiledir IS NULL)
	BEGIN
		PRINT '-- Warning! @defaultdatafiledir IS NULL!';
		SET @defaultdatafiledir = '\';
	END
	

IF (@defaultsyslogfiledir IS NULL)
	BEGIN
		PRINT '-- Warning! @defaultdatafiledir IS NULL!';
		SET @defaultsyslogfiledir = '\';
	END

SET @defaultdatafiledir = @defaultdatafiledir + '\'
SET @defaultsyslogfiledir = @defaultsyslogfiledir + '\'

DECLARE @bkpath_data VARCHAR(300),
	@bkpath_logs VARCHAR(300)
	;
SET @bkpath_data = @bkpath + '\' + @bkservname + '\' + @target_db + '\FULL'
SET @bkpath_logs = @bkpath + '\' + @bkservname + '\' + @target_db + '\LOG'

SELECT @bkpath_data, @bkpath_logs

--
-- Fetch filenames
INSERT INTO @datafileinfo
EXEC xp_dirtree @bkpath_data, 1, 1

INSERT INTO @logfileinfo
EXEC xp_dirtree @bkpath_logs, 1, 1


select *
from @datafileinfo
;
select *
from @logfileinfo
;
