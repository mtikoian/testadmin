USE msdb;
GO

SET NOCOUNT ON;

SELECT DISTINCT destination_database_name AS DBRestored
	, restore_date AS RestoreDate
	, b.database_name AS SourceDB
	, backup_start_date AS BackupDate
FROM dbo.restorehistory AS h
	INNER JOIN master.dbo.sysdatabases AS sd
		ON sd.NAME = h.destination_database_name
	INNER JOIN dbo.BackupSet AS b
		ON h.backup_set_id = b.backup_set_id
	INNER JOIN dbo.BackupFile AS f
		ON f.backup_set_id = b.backup_set_id
GROUP BY destination_database_name
	, restore_date
	, b.database_name
	, backup_start_date
ORDER BY RestoreDate DESC
;

GO
