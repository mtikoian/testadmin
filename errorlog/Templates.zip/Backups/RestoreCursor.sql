USE master;
GO
--
-- Restore all ".bak" files in a directory to the current database
--
SET NOCOUNT ON;

-- User setable vars
DECLARE @debug INT = 1;-- 0: actually restore   1: just print the restore commands
DECLARE @bkpath VARCHAR(1000) = 'F:\MSSQL14\Restore\MBeM';
--DECLARE @bkpath VARCHAR(1000) = 'R:\Restore';
DECLARE @bkservname VARCHAR(100) = 'MB-ND01-SC-003';
--DECLARE @bkservname VARCHAR(100) = 'MB-ND01-SC-002';
DECLARE @force_disconnect INT = 0;-- 0: do *not* force disconnect (error)		1: Force disconnect
DECLARE @target_match VARCHAR(100) = '';-- Search target include filename
DECLARE @target_skip VARCHAR(100) = '_SK*P_';-- Search target skip
DECLARE @newdbfilename VARCHAR(100);
DECLARE @newlogname VARCHAR(100);
DECLARE @SQL NVARCHAR(MAX) = '';
DECLARE @filename VARCHAR(1000);
DECLARE @dbname VARCHAR(100);
DECLARE @dbfilename VARCHAR(100);
DECLARE @logname VARCHAR(100);

DECLARE @fileinfo TABLE (
	NAME VARCHAR(200) NULL
	, DEPTH INT NULL
	, isfile BIT NULL
	);

DECLARE @bkfileinfo TABLE (
	LogicalName VARCHAR(100) NULL
	, PhysicalName VARCHAR(1000) NULL
	, TYPE VARCHAR(5) NULL
	, FileGroupName VARCHAR(100) NULL
	, SIZE BIGINT NULL
	, MaxSize BIGINT NULL
	, FileID BIGINT NULL
	, CreateLSN BIT NULL
	, DropLSN BIT NULL
	, UniqueId UNIQUEIDENTIFIER NULL
	, ReadOnlyLSN BIT NULL
	, ReadWriteLSN BIT NULL
	, BackupSizeInBytes BIGINT NULL
	, SourceBlockSize BIGINT NULL
	, FileGroupId INT NULL
	, LogGroupGUID UNIQUEIDENTIFIER NULL
	, DifferentialBaseLSN BIT NULL
	, DifferentialBaseGUID UNIQUEIDENTIFIER NULL
	, IsReadOnly BIT NULL
	, IsPresent BIT NULL
	, TDEThumbprint VARCHAR(1000) NULL
	);

DECLARE @param NVARCHAR(500);
DECLARE @sysdatafile NVARCHAR(1000);
DECLARE @syslogfile NVARCHAR(1000);
DECLARE @sysdataname NVARCHAR(1000);
DECLARE @syslogname NVARCHAR(1000);
DECLARE @defaultdatafiledir NVARCHAR(1000);
DECLARE @defaultsyslogfiledir NVARCHAR(1000);
-- Default data/log dirs
--SET @param = '@datafile NVARCHAR(1000) OUTPUT, @logfile NVARCHAR(1000) OUTPUT';
--SET @SQL = '(
--	SELECT @datafile = REPLACE(mf.physical_name, ''master.mdf'', '''')
--		, @logfile = REPLACE(mf2.physical_name, ''mastlog.ldf'', '''')
--	FROM sys.master_files mf
--		JOIN sys.databases dbs
--			ON mf.database_id = dbs.database_id
--		JOIN sys.master_files mf2
--			ON (mf.database_id = mf2.database_id AND mf.type <> mf2.type)
--	WHERE dbs.name = ''master''
--		AND mf.type = 0
--		AND mf2.type = 1)';
--EXECUTE sp_executesql @SQL
--	, @param
--	, @datafile = @defaultdatafiledir OUTPUT
--	, @logfile = @defaultsyslogfiledir OUTPUT;

DECLARE @rc INT;

PRINT '/*';

EXEC @rc = master.dbo.xp_instance_regread
	@rootkey = N'HKEY_LOCAL_MACHINE'
	, @key = N'Software\Microsoft\MSSQLServer\MSSQLServer'
	, @value_name = N'DefaultData'
	, @value = @defaultdatafiledir OUTPUT
;

IF (@defaultdatafiledir IS NULL)
BEGIN
	-- PRINT '-- Fetch Default DATA directory - secondary try'
	EXEC master.dbo.xp_instance_regread
		@rootkey = 'HKEY_LOCAL_MACHINE'
		, @key = 'Software\Microsoft\MSSQLServer\Setup'
		, @value_name = 'SQLDataRoot'
		, @value = @defaultdatafiledir OUTPUT
		;
	SET @defaultdatafiledir = @defaultdatafiledir + '\Data';
END;

EXEC @rc = master.dbo.xp_instance_regread
	@rootkey = N'HKEY_LOCAL_MACHINE'
	, @key = N'Software\Microsoft\MSSQLServer\MSSQLServer'
	, @value_name = N'DefaultLog'
	, @value = @defaultsyslogfiledir OUTPUT
;

IF (@defaultsyslogfiledir IS NULL)
BEGIN
	-- PRINT '-- Fetch Default LOG directory - secondary try'
	EXEC master.dbo.xp_instance_regread
		@rootkey = 'HKEY_LOCAL_MACHINE'
		, @key = 'Software\Microsoft\MSSQLServer\Setup'
		, @value_name = 'SQLDataRoot'
		, @value = @defaultsyslogfiledir OUTPUT
		;
	SET @defaultsyslogfiledir = @defaultsyslogfiledir + '\Log';
END;

print '*/';


--SET @defaultdatafiledir = 'd:\Program Files\Microsoft SQL Server\MSSQL10_50.MSSQLSERVER\MSSQL\DATA';
--SET @defaultlogfiledir = 'd:\Program Files\Microsoft SQL Server\MSSQL10_50.MSSQLSERVER\MSSQL\LOG';
IF (@defaultdatafiledir IS NULL)
BEGIN
	PRINT '-- Warning! @defaultdatafiledir IS NULL!';
	SET @defaultdatafiledir = '\';
END;

IF (@defaultsyslogfiledir IS NULL)
BEGIN
	PRINT '-- Warning! @defaultdatafiledir IS NULL!';
	SET @defaultsyslogfiledir = '\';
END;

SET @defaultdatafiledir = @defaultdatafiledir + '\';
SET @defaultsyslogfiledir = @defaultsyslogfiledir + '\';

--
-- Fetch filenames
INSERT INTO @fileinfo
EXEC xp_dirtree
	@directory = @bkpath
	, @depth = 1
	, @file = 1
;

DECLARE bkfilelistcur CURSOR LOCAL FORWARD_ONLY READ_ONLY
FOR
SELECT NAME AS Filename
	, SUBSTRING(REPLACE(NAME, @bkservname + '_', ''), 0, CHARINDEX('_FULL', REPLACE(NAME, @bkservname + '_', ''))) AS dbname
FROM @fileinfo
WHERE NAME LIKE '%.bak'
	AND NAME LIKE '%' + @target_match + '%'
	AND NAME NOT LIKE '%' + @target_skip + '%'
	AND NAME LIKE @bkservname + '%'
;

OPEN bkfilelistcur;

FETCH NEXT
FROM bkfilelistcur
INTO @filename
	, @dbname;

WHILE (@@FETCH_STATUS = 0)
BEGIN
	SET @sysdatafile = NULL;
	SET @syslogfile = NULL;
	--print @dbname
	--
	-- See if we have this DB already - if so, use its existing names/locations
	SET @param = 
		'
		@dataname NVARCHAR(1000) OUTPUT
		, @logname NVARCHAR(1000) OUTPUT
		, @datafile NVARCHAR(1000) OUTPUT
		, @logfile NVARCHAR(1000) OUTPUT
		'
		;
	SET @SQL = 
		'(
				SELECT
					@dataname = mf.name
					, @datafile = mf.physical_name
					, @logname = mf2.name
					, @logfile = mf2.physical_name
				FROM sys.master_files mf
					JOIN sys.databases dbs
						ON mf.database_id = dbs.database_id
					JOIN sys.master_files mf2
						ON mf.database_id = mf2.database_id
							AND mf.type <> mf2.type
				WHERE dbs.name = ''' 
		+ @dbname + '''
						AND mf.type = 0
						AND mf2.type = 1)';

	EXECUTE sp_executesql
		@sql = @SQL
		, @parameters = @param
		, @datafile = @sysdatafile OUTPUT
		, @dataname = @sysdataname OUTPUT
		, @logname = @syslogname OUTPUT
		, @logfile = @syslogfile OUTPUT
	;
	
	PRINT '-- ======================================================================';

	IF (LEN(@sysdatafile) > 0)
	BEGIN
		-- We have this database already
		SET @SQL = '-- database already exists' + CHAR(10);

		IF (@force_disconnect = 1)
		BEGIN
			SET @SQL = @SQL + 'ALTER DATABASE [' + @dbname + '] SET single_user WITH ROLLBACK IMMEDIATE' + CHAR(10)
				+ 'GO' + CHAR(10)
				+ 'ALTER DATABASE [' + @dbname + '] SET multi_user WITH ROLLBACK IMMEDIATE' + CHAR(10)
				+ 'GO' + CHAR(10)
			;
		END;

		SET @SQL = @SQL + '
PRINT ''*** Restore for ' + @dbname + ' started: '' + (CONVERT( VARCHAR(24), GETDATE(), 120));

RESTORE DATABASE [' + @dbname + ']
FROM DISK = N''' + @bkpath + '\' + @filename + 
			'''
WITH FILE = 1
	, MOVE N''' + @sysdataname + ''' TO N''' + @sysdatafile + '''
	, MOVE N''' + @syslogname + ''' TO N''' + @syslogfile + 
			'''
	, NOUNLOAD
	, REPLACE
	, STATS = 5;
GO

PRINT ''*** Restore for ' + @dbname + 
			' completed: '' + (CONVERT( VARCHAR(24), GETDATE(), 120));
-- ======================================================================
';
	END;
	ELSE
	BEGIN
		-- this is a new database
		-- get db and log name from the backup file
		DELETE
		FROM @bkfileinfo;

		SET @SQL = 'RESTORE filelistonly FROM DISK = N''' + @bkpath + '\' + @filename + ''' WITH FILE = 1';

		INSERT INTO @bkfileinfo
		EXEC (@SQL);

		SELECT @dbfilename = LogicalName
		FROM @bkfileinfo
		WHERE TYPE = 'D';

		SELECT @logname = LogicalName
		FROM @bkfileinfo
		WHERE TYPE = 'L';

		IF (
				@dbname IS NULL
				OR @dbname = ''
				)
		BEGIN
			SET @dbname = @dbfilename;
			SET @newdbfilename = @dbfilename;
			SET @newlogname = @logname;
		END;
		ELSE
		BEGIN
			SET @newdbfilename = @dbname + '_Data';
			SET @newlogname = @dbname + '_Log';
		END;

		SET @SQL = '-- new database
PRINT ''*** Restore for ' + @dbname + ' started: '' + (CONVERT( VARCHAR(24), GETDATE(), 120));
GO
RESTORE DATABASE [' + @dbname + ']
FROM DISK = N''' + @bkpath + '\' + 
			@filename + '''
WITH FILE = 1
	, MOVE N''' + @dbfilename + ''' TO N''' + @defaultdatafiledir + @newdbfilename + '' + '.mdf''
	, MOVE N''' + @logname + ''' TO N''' + @defaultsyslogfiledir + @newlogname + '' + 
			'.ldf''
	, NOUNLOAD
	, STATS = 5
;
GO
PRINT ''*** Restore for ' + @dbname + ' completed: '' + (CONVERT( VARCHAR(24), GETDATE(), 120));
';
	END;

	PRINT @SQL + 'GO' + CHAR(10);

	IF (@debug = 0)
	BEGIN
		EXEC (@SQL);
	END;

	FETCH NEXT
	FROM bkfilelistcur
	INTO @filename
		, @dbname;
END;

CLOSE bkfilelistcur;

DEALLOCATE bkfilelistcur;

GO
