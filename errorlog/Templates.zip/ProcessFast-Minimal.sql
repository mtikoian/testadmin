USE master;
GO

SET NOCOUNT ON;

SELECT 'KILL ' + CAST(sp.spid AS VARCHAR(10)) AS killcmd
	, sd.NAME AS dbname
	, sp.loginame
	, sp.hostname
	, sp.program_name
	, sp.hostprocess
	, CONVERT(VARCHAR(19), sp.login_time, 120) AS login_time
	, CONVERT(VARCHAR(19), sp.last_batch, 120) AS last_batch
	, CAST(sp.cpu / 1000 AS BIGINT) AS cpu
	, CAST(sp.physical_io AS BIGINT) AS physical_io
	, sp.memusage
	, sp.STATUS
	, sp.cmd
FROM dbo.sysprocesses AS sp
	INNER JOIN sys.databases AS sd
		ON sd.database_id = sp.dbid
WHERE sp.hostprocess <> ''
	AND sp.program_name <> 'sqlcheck'
ORDER BY sp.spid
--ORDER BY sd.NAME
--ORDER BY sp.cpu DESC
;
GO


