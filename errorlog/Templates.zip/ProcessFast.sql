USE master;
GO

SET NOCOUNT ON;

SELECT spid
	, kpid
	, blocked
	, CAST(waittime AS BIGINT) AS waittime
	, lastwaittype
	, waitresource
	, dbid
	, name
	, uid
	, CAST(cpu / 1000 AS BIGINT) AS cpu
	, CAST(physical_io AS BIGINT) AS physical_io
	, memusage
	, login_time
	, last_batch
	, ecid
	, CAST(open_tran AS BIGINT) AS open_tran
	, STATUS
	, hostname
	, program_name
	, hostprocess
	, cmd
	, nt_domain
	, nt_username
	, net_address
	, net_library
	, loginame
	, stmt_start
	, stmt_end
FROM master.dbo.sysprocesses
	JOIN sys.databases
		ON database_id = sysprocesses.dbid
WHERE hostprocess <> ''
	AND program_name <> 'sqlcheck'
;
GO
