:out stdout
USE master;
GO

-- run in text mode
SET XACT_ABORT ON;
GO

SET NOCOUNT ON;

BEGIN TRANSACTION;

SAVE TRAN DEV_ssms;

PRINT 'USE master';
PRINT 'GO';

SELECT 'ALTER DATABASE [' + d.NAME + '] SET PARTNER PAUSE;
GO
'
FROM sys.database_mirroring AS dm
	INNER JOIN sys.databases AS d
		ON d.database_id = dm.database_id
WHERE dm.mirroring_guid IS NOT NULL;

ROLLBACK TRANSACTION DEV_ssms;

COMMIT;
GO
