USE master;
GO

SET NOCOUNT ON;
SET XACT_ABORT ON;

BEGIN TRANSACTION;

SAVE TRAN DEV_ssms;

PRINT 'USE master';
PRINT 'GO';

SELECT 'ALTER DATABASE [' 
        + d.NAME 
        + ']'
        + CHAR(10) 
        + 'SET PARTNER RESUME;' 
        + CHAR(10) 
        + 'GO'
        + CHAR(10)
FROM sys.database_mirroring AS dm
    JOIN sys.databases AS d
        ON d.database_id = dm.database_id
WHERE dm.mirroring_guid IS NOT NULL;

ROLLBACK TRANSACTION DEV_ssms;

COMMIT;
GO
