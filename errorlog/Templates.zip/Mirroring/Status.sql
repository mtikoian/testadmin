:connect mb-mn01-vmg-003.mbnd.local

USE msdb;
GO

SET NOCOUNT ON;

DECLARE @dbname VARCHAR(100) = 'ALL';
DECLARE @report_mode INT = 0;
	-- 0 = last row, 1 last two hours, 2 last four, 3 last eight, 4 last day
	-- 5 last two days, 6 last 100, 7 last 500, 8 last 1000, 9 all

DECLARE @dbstate TABLE (
	database_name NVARCHAR(100) NULL
	, role INT NULL
	, mirroring_state INT NULL
	, witness_status INT NULL
	, log_generation_rate INT NULL
	, unsent_log INT NULL
	, send_rate INT NULL
	, unrestored_log INT NULL
	, recovery_rate INT NULL
	, transaction_delay INT NULL
	, transactions_per_sec INT NULL
	, average_delay INT NULL
	, time_recorded DATETIME NULL
	, time_behind DATETIME NULL
	, local_time DATETIME NULL
);

IF (@dbname = 'ALL')
BEGIN
	DECLARE @cur_db VARCHAR(100);

	DECLARE dblistcur CURSOR LOCAL FORWARD_ONLY READ_ONLY
	FOR
		SELECT name
		FROM sys.databases
		ORDER BY name
		;
	
	OPEN dblistcur;
	
	FETCH NEXT
	FROM dblistcur
	INTO @cur_db
	;
	
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		INSERT INTO @dbstate
		EXEC sys.sp_dbmmonitorresults
			@database_name = @cur_db
			, @mode = @report_mode
			, @update_table = 0
			-- if 1, then generate a row in the base table and then return.  
			;

		FETCH NEXT
		FROM dblistcur
		INTO @cur_db
		;
	END;
	
	CLOSE dblistcur;
	DEALLOCATE dblistcur;
END;
ELSE
BEGIN
	INSERT INTO @dbstate
	EXEC sys.sp_dbmmonitorresults
		@database_name = @dbname
		, @mode = @report_mode
		, @update_table = 0
		-- if 1, then generate a row in the base table and then return.  
	;
END;

SELECT database_name
	, mirroring_state
	, CASE WHEN mirroring_state = 0
			THEN 'Suspended'
		WHEN mirroring_state = 1
			THEN 'Disconnected'
		WHEN mirroring_state = 2
			THEN 'Synchronizing'
		WHEN mirroring_state = 3
			THEN 'Pending Failover'
		WHEN mirroring_state = 4
			THEN 'Synchronized'
		ELSE 'UNKNOWN STATE'
		END AS state_desc
	, unsent_log AS unsent_log_kb
	, recovery_rate AS recovery_rate_kbs
	, local_time
	, CASE WHEN mirroring_state = 2
		THEN CAST(CAST((unsent_log/(recovery_rate+.000001))/60 AS DECIMAL(20,3)) AS VARCHAR(100))
		ELSE '--'
		END AS est_remaining_mins
	-- , *
FROM @dbstate
--WHERE unsent_log > 0
--	OR mirroring_state <> 4
ORDER BY unsent_log DESC
	, database_name
;

--SELECT SUM(unsent_log) AS Unsent_Total
--FROM @dbstate
--;

--USE master
--GO

--SELECT dbs.name, mir.*
--FROM sys.database_mirroring AS mir
--	JOIN sys.databases AS dbs
--		ON mir.database_id = dbs.database_id
--WHERE mir.mirroring_guid IS NOT NULL
--ORDER BY dbs.name

GO
