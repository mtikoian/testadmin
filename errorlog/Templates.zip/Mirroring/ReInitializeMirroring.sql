:out stdout

USE master;
GO

--
-- Generate Mirroring Connections
-- Nem W Schlecht
-- Multiband Corp., Copyright (C) 2014
--
--
-- This assumes a FULL and LOG backup have been made and restored to the mirroring server
-- need to turn on High Performance manually afterwards.
--
-- Run this on the *source* database instance
--
SET NOCOUNT ON;

DECLARE @Search VARCHAR(100);

SET @Search = '';-- limit to matching databases

SELECT '--'
		+ CHAR(10)
		+ '-- Reinitialize '
		+ NAME
		+ CHAR(10)
		+ '-- '
		+ CHAR(10)
		+ ':connect mb-mn01-vmg-003'
		+ CHAR(10)
		+ 'PRINT ''Setting up '
		+ NAME
		+ 'ON mirroring SERVER'';'
		+ CHAR(10)
		+ 'ALTER DATABASE ['
		+ NAME
		+ '] '
		+ CHAR(10)
		+ 'SET PARTNER = ''tcp://'
		+ LOWER(@@SERVERNAME)
		+ '.mbnd.local:5022'';'
		+ CHAR(10)
		+ 'GO'
		+ CHAR(10)
		+ CHAR(10)
		+ ':connect '
		+ LOWER(@@SERVERNAME)
		+ CHAR(10)
		+ 'PRINT ''Setting up '
		+ NAME
		+ ' on local server'';'
		+ CHAR(10)
		+ 'ALTER DATABASE ['
		+ NAME
		+ ']'
		+ CHAR(10)
		+ 'SET PARTNER = ''tcp://mb-mn01-vmg-003.mbnd.local:5022'';'
		+ CHAR(10)
		+ 'GO'
		+ CHAR(10)
		+ 'ALTER DATABASE ['
		+ NAME
		+ ']'
		+ CHAR(10)
		+ 'SET PARTNER SAFETY OFF;'
		+ CHAR(10)
		+ 'GO'
		+ CHAR(10) AS '-- Run output in SQLCMD mode!'
FROM sys.databases
WHERE NAME NOT IN (
		'master'
		, 'msdb'
		, 'model'
		, 'tempdb'
		)
	AND NAME LIKE '%'
		+ @Search
		+ '%'
ORDER BY NAME;
GO
