USE master;
GO

SELECT *
FROM sys.tcp_endpoints;
GO

-- not sure if you have to run this on the host or on the mirroring server
-- maybe both
-- the net says *just* the mirroring server

-- for sc-001, I run this *ON* sc-001 to restart mirroring

ALTER endpoint [Mirroring] STATE = stopped;
GO

ALTER endpoint [Mirroring] STATE = started;
GO


