USE master;
GO

SET NOCOUNT ON;

SELECT @@SERVERNAME AS ServerName
	, der.session_id
	, der.start_time
	, der.[status]
	, der.percent_complete AS '%'
	, DB_NAME(der.database_id) AS dbname
	-- , der.command
	, CASE percent_complete
		WHEN 0
			THEN 0
		ELSE (((DATEDIFF(MINUTE, start_time, GETDATE()) * 100) / percent_complete) - (DATEDIFF(MINUTE, start_time, GETDATE())))
		END AS 'est_mins'
	, der.last_wait_type
	, der.blocking_session_id AS 'blk_sid'
	, DATEDIFF(MINUTE, der.start_time, GETDATE()) AS runtime
	, SUBSTRING(st.TEXT, der.statement_start_offset / 2, (
			CASE 
				WHEN der.statement_end_offset = - 1
					THEN LEN(CONVERT(NVARCHAR(MAX), st.TEXT)) * 2
				ELSE der.statement_end_offset
				END - der.statement_start_offset
			) / 2) AS cur_sql
	, st.[text] AS full_sql
FROM sys.dm_exec_requests der
	CROSS APPLY sys.dm_exec_sql_text(der.sql_handle) st
WHERE session_id > 50
	AND session_id <> @@SPID
;

SELECT
	CONVERT(VARCHAR(50), (estimated_completion_time / 3600000))
		+ 'hrs'
		+ CONVERT(VARCHAR(50),
				  ((estimated_completion_time % 3600000) / 60000))
		+ 'min'
		+ CONVERT(VARCHAR(50),
				  (((estimated_completion_time % 3600000) % 60000) / 1000))
		+ 'sec'
		AS Estimated_Completion_Time
	, STATUS
	, command
	, DB_NAME(database_id) AS dbname
	, percent_complete
FROM sys.dm_exec_requests
WHERE DB_NAME(database_id) <> 'master'
;

GO
