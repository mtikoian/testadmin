USE master;
GO

-- Back up all databases to a directory given a database name pattern (LIKE)
--
SET NOEXEC OFF;
SET NOCOUNT ON;

-- User setable vars
DECLARE @debug INT;
DECLARE @verify_backup INT;
DECLARE @bkpath VARCHAR(1000);
DECLARE @do_copy_only INT;
DECLARE @prepend_host_db INT;
DECLARE @dbpattern VARCHAR(1000);
DECLARE @dbpattern_skip VARCHAR(1000);
DECLARE @stats VARCHAR(5);
DECLARE @DBA_inits VARCHAR(3);

SET @debug = 1;-- 0: actually backup   1: just print the backup commands
SET @verify_backup = 1;-- 0: do NOT verify backup   1: verify backup
SET @bkpath = 'R:\Backup';
SET @do_copy_only = 1;-- 0: in-flow copy, 1: copy-only copy
SET @prepend_host_db = 0;-- 0: Do NOT prepend host 	1: prepend
SET @dbpattern = '%';-- Set this line!
SET @dbpattern_skip = '%transfer%';--optional
SET @stats = '5';-- statistics frequency update
SET @DBA_inits = 'NWS';-- DBA's initials

-- DECLARE @ServerName = @@SERVERNAME;
DECLARE @SQL NVARCHAR(MAX);

SET @SQL = '';

DECLARE @filename VARCHAR(1000);
DECLARE @cur_database VARCHAR(100);
DECLARE @cur_bk_name VARCHAR(1000);
DECLARE @copy_only VARCHAR(100);

SET @copy_only = '';

DECLARE @cur_time_str VARCHAR(100);

SET @cur_time_str = CONVERT(VARCHAR(40), GETDATE(), 112);
SET @cur_time_str = @cur_time_str
		+ '_'
		+ REPLACE(CONVERT(VARCHAR(40), GETDATE(), 108), ':', '');

DECLARE bkfilelistcur CURSOR LOCAL FORWARD_ONLY READ_ONLY
FOR
SELECT NAME
FROM master.sys.databases
WHERE NAME /* COLLATE Latin1_General_CS_AS */ LIKE @dbpattern
	AND STATE = 0
	AND NAME NOT IN (
		'master'
		, 'msdb'
		, 'model'
		, 'tempdb'
		)
	AND NAME NOT LIKE @dbpattern_skip
ORDER BY NAME;

OPEN bkfilelistcur;

FETCH NEXT
FROM bkfilelistcur
INTO @cur_database;

WHILE (@@FETCH_STATUS = 0)
BEGIN
	SET @cur_bk_name = @cur_database + '-Full Database Backup';
	SET @filename = @bkpath + '\';

	IF (@do_copy_only = 1)
	BEGIN
		SET @copy_only = CHAR(9)
		+ ', COPY_ONLY'
		+ CHAR(10);
	END;

	IF (@prepend_host_db = 1)
	BEGIN
		SET @filename = @filename
		+ @@SERVERNAME
		+ '\'
		+ @cur_database
		+ '\'
		+ 'FULL'
		+ '\';
	END;

	SET @filename = @filename
		+ @@SERVERNAME
		+ '_'
		+ @cur_database
		+ '_FULL_'
		+ @cur_time_str
		+ '-'
		+ @DBA_inits
		+ '.bak';
	SET @filename = REPLACE(@filename, ' ', '_');
	SET @SQL = 'PRINT ''*** Backup for '
		+ @cur_database
		+ ' started: '' + (CONVERT( VARCHAR(24), GETDATE(), 120));' + CHAR(10) + 'BACKUP DATABASE ['
		+ @cur_database
		+ ']'
		+ CHAR(10)
		+ CHAR(9)
		+ 'TO DISK = N'''
		+ @filename
		+ ''''
		+ CHAR(10)
		+ CHAR(9)
		+ 'WITH NOFORMAT'
		+ CHAR(10)
		+ @copy_only
		+ CHAR(9)
		+ ', NOINIT'
		+ CHAR(10)
		+ CHAR(9)
		+ ', NAME = N'''
		+ @cur_bk_name
		+ ''''
		+ CHAR(10)
		+ CHAR(9)
		+ ', SKIP'
		+ CHAR(10)
		+ CHAR(9)
		+ ', NOREWIND'
		+ CHAR(10)
		+ CHAR(9)
		+ ', NOUNLOAD'
		+ CHAR(10)
		+ CHAR(9)
		+ ', STATS = '
		+ @stats
		+ ';';

	IF (@verify_backup = 1)
	BEGIN
		SET @SQL = @SQL
		+ CHAR(10)
		+ 'DECLARE @backupSetId AS INT;'
		+ CHAR(10)
		+ 'SELECT @backupSetId = position'
		+ CHAR(10)
		+ 'FROM msdb..backupset'
		+ CHAR(10)
		+ 'WHERE database_name=N'''
		+ @cur_database
		+ ''''
		+ CHAR(10)
		+ '	AND backup_set_id=('
		+ CHAR(10)
		+ '		SELECT MAX(backup_set_id)'
		+ CHAR(10)
		+ '		FROM msdb..backupset'
		+ CHAR(10)
		+ '		WHERE database_name=N'''
		+ @cur_database
		+ ''''
		+ CHAR(10)
		+ '		);'
		+ CHAR(10)
		+ 'IF (@backupSetId IS NULL)'
		+ CHAR(10)
		+ 'BEGIN'
		+ CHAR(10)
		+ CHAR(9)
		+ 'RAISERROR(N''Verify failed. Backup information for database '''''
		+ @cur_database
		+ ''''' not found.'''
		+ CHAR(10)
		+ CHAR(9)
		+ CHAR(9)
		+ ', 16'
		+ CHAR(10)
		+ CHAR(9)
		+ CHAR(9)
		+ ', 1'
		+ CHAR(10)
		+ CHAR(9)
		+ CHAR(9)
		+ ');'
		+ CHAR(10)
		+ 'END;'
		+ CHAR(10)
		+ 'RESTORE VERIFYONLY'
		+ CHAR(10)
		+ CHAR(9)
		+ 'FROM DISK = N'''
		+ @filename
		+ ''''
		+ CHAR(10)
		+ CHAR(9)
		+ 'WITH FILE = @backupSetId'
		+ CHAR(10)
		+ CHAR(9)
		+ ', NOUNLOAD'
		+ CHAR(10)
		+ CHAR(9)
		+ ', NOREWIND;'
		+ CHAR(10)
		+ 'GO'
		+ CHAR(10)
		+ 'PRINT ''*** Backup for '
		+ @cur_database
		+ ' completed: '' + (CONVERT( VARCHAR(24), GETDATE(), 120));'
		+ CHAR(10)
		+ CHAR(10);
	END;

	PRINT @SQL;

	IF (@debug = 0)
	BEGIN
		EXEC (@SQL);

		PRINT '';
	END;

	FETCH NEXT
	FROM bkfilelistcur
	INTO @cur_database;
END;

PRINT 'GO';

CLOSE bkfilelistcur;

DEALLOCATE bkfilelistcur;
GO
