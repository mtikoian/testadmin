USE master;
GO

SET NOCOUNT ON;

-- find all of the orphaned (SQL) users (DB SQL User without a login with the same SID)
WITH cte
AS (
	SELECT dp.NAME AS DBUser
		, dp.sid AS DBSid
	FROM sys.database_principals dp
		LEFT OUTER JOIN sys.server_principals sp
			ON dp.sid = sp.sid
	WHERE sp.sid IS NULL
		AND dp.type = 'S' -- SQL_USER
		AND dp.principal_id > 4
	)
-- join to logins with the same name to get the sql statement to un-orphan the user
SELECT cte.*
	, sp.NAME
	-- generate the SQL script to un-orphan the users that can be.
	, N'ALTER USER [' + cte.DBUser + N'] WITH LOGIN=' + sp.NAME + N';' AS LinkOrphanUserToLoginSQL
FROM cte
	-- LEFT JOIN allows seeing all orphaned users
	LEFT JOIN sys.server_principals sp
		ON cte.DBUser = sp.NAME
			AND sp.type = 'S'
ORDER BY DBUser;
GO


