USE msdb;
GO

SET NOCOUNT ON;

SELECT j.NAME AS 'JobName'
        , msdb.dbo.agent_datetime(h.run_date, h.run_time) AS 'RunDateTime'
        , ((h.run_duration / 10000 * 3600 
                + (h.run_duration / 100) % 100 * 60 
                + h.run_duration % 100 
                + 31) / 60) AS 'RunDurationMinutes'
FROM msdb.dbo.sysjobs AS j
	INNER JOIN msdb.dbo.sysjobhistory AS h
		ON j.job_id = h.job_id
WHERE j.enabled = 1 --Only Enabled Jobs
	--AND j.name = 'TestJob' --Uncomment to search for a single job
	--AND msdb.dbo.agent_datetime(run_date, run_time) --Uncomment for date range queries
	--	BETWEEN '12/08/2012' and '12/10/2012'
ORDER BY JobName
	, RunDateTime DESC;
GO
