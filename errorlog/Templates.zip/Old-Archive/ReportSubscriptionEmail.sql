USE [ReportServer2008];
GO

SET NOCOUNT ON;

DECLARE @Subscriptions TABLE (
	Report_OID UNIQUEIDENTIFIER NULL
	, ToList VARCHAR(8000) NULL
	, CCList VARCHAR(8000) NULL
	, BCCList VARCHAR(8000) NULL
	, SubjectLine VARCHAR(8000) NULL
	);
DECLARE @ExtensionSettings XML;
DECLARE @Report_OID UNIQUEIDENTIFIER;
--DECLARE @idoc;	

DECLARE SubscriptionList CURSOR LOCAL READ_ONLY FORWARD_ONLY
FOR
SELECT Report_OID
	, ExtensionSettings
FROM subscriptions
;

OPEN SubscriptionList;

FETCH NEXT
FROM SubscriptionList
INTO @Report_OID
	, @ExtensionSettings
;

WHILE (@@FETCH_STATUS = 0)
BEGIN
	EXEC sp_xml_preparedocument
		@idoc OUTPUT
		, @ExtensionSettings
	;

	INSERT INTO @Subscriptions
	SELECT @Report_OID
		, [TO]
		, [CC]
		, [BCC]
		, [Subject]
	FROM (
		SELECT *
		FROM OPENXML(@idoc, '/ParameterValues/ParameterValue') WITH (
				NAME NVARCHAR(100) 'Name'
				, Value NVARCHAR(100) 'Value'
				)
		) AS SourceTable
	pivot(MAX(value) FOR [Name] IN (
				[TO]
				, [BCC]
				, [CC]
				, [Subject]
				)) AS pivottable
	;

	EXEC sp_xml_removedocument @idoc;

	FETCH NEXT
	FROM SubscriptionList
	INTO @Report_OID
		, @ExtensionSettings;
END;

CLOSE SubscriptionList;

DEALLOCATE SubscriptionList;

SELECT c.path
	, c.NAME
	, s.Tolist
	, s.cclist
	, s.bcclist
	, s.subjectline
FROM CATALOG c
	INNER JOIN @Subscriptions s
		ON c.ItemID = s.Report_OID
ORDER BY [path]
	, NAME;
GO
