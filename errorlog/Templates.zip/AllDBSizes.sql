USE master;
GO

SET NOCOUNT ON;

SELECT DB_NAME(database_id) AS DatabaseName
	, SUM(size * 8) / 1024.0 AS SizeMB
FROM sys.master_files
WHERE DB_NAME(database_id) NOT IN (
		'master'
		, 'model'
		, 'msdb'
		, 'tempdb'
		)
GROUP BY database_id
--ORDER BY DB_NAME(database_id)
ORDER BY SizeMB DESC
;
GO
