:connect 2ua1370nj7\nemdev14
USE ssmslog;
GO

SET NOCOUNT ON;

DECLARE @Search VARCHAR(200) = '';

SELECT
	'----------------------------------------------------------------------------------'
	, CHAR(10)
		+ '-- '
		+ CAST(ExecutedOn AS VARCHAR(20))
	, CHAR(10)
		+ '-- '
		+ CHAR(10)
		+ '-- '
		+ DocumentCaption
		+ CHAR(10)
		+ '--'
		+ CHAR(10)
		+ CAST(QueryText AS VARCHAR(max))
		+ CHAR(10)
FROM ActionLoggerHistory
WHERE QueryText NOT LIKE '%FROM ActionLoggerHistory%'
	AND (
		QueryText LIKE '%' + @Search + '%'
		OR DocumentCaption like '%' + @Search + '%'
		)
ORDER BY ExecutedOn DESC
;

GO
