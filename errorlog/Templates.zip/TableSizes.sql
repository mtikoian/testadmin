--USE master;
--GO
SET NOCOUNT ON;

DECLARE @RowCount INT
	, @tablename VARCHAR(100);
DECLARE @Tables TABLE (
	PK INT IDENTITY(1, 1)
	, tablename VARCHAR(100) NULL
	, processed BIT NULL
	);

INSERT INTO @Tables (tablename)
SELECT TABLE_SCHEMA + '.' + TABLE_NAME
FROM INFORMATION_SCHEMA.TABLES
WHERE TABLE_TYPE = 'BASE TABLE'
	AND TABLE_NAME NOT LIKE 'dt%'
	AND TABLE_SCHEMA NOT LIKE 'mssqlrbs%'
ORDER BY TABLE_NAME ASC;

DECLARE @Space TABLE (
	NAME VARCHAR(100) NULL
	, ROWS NVARCHAR(100) NULL
	, reserved VARCHAR(100) NULL
	, DATA VARCHAR(100) NULL
	, index_size VARCHAR(100) NULL
	, unused VARCHAR(100) NULL
	)

SELECT TOP (1) @tablename = tablename
FROM @Tables
WHERE processed IS NULL
ORDER BY tablename;

SET @RowCount = 1;

WHILE (@RowCount <> 0)
BEGIN
	INSERT INTO @Space
	EXEC sp_spaceused @tablename;

	UPDATE @Tables
	SET processed = 1
	WHERE tablename = @tablename;

	SELECT TOP (1) @tablename = tablename
	FROM @Tables
	WHERE processed IS NULL
	ORDER BY tablename;

	SET @RowCount = @@ROWCOUNT;
END;

UPDATE @Space
SET DATA = REPLACE(DATA, 'KB', '');

UPDATE @Space
SET DATA = CONVERT(DECIMAL(18, 2), DATA) / 1000;

UPDATE @Space
SET DATA = DATA + 'MB';

UPDATE @Space
SET reserved = REPLACE(reserved, 'KB', '');

UPDATE @Space
SET reserved = CONVERT(DECIMAL(18, 2), reserved) / 1000;

UPDATE @Space
SET reserved = reserved + 'MB';

SELECT *
FROM @Space
ORDER BY CONVERT(DECIMAL(18, 2), REPLACE(DATA, 'MB', '')) DESC;

GO