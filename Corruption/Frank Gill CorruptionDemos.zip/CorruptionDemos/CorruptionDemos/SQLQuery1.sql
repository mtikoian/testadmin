USE [master]

RESTORE DATABASE [CorruptDemoDBRepairRebuildRepairRebuild] 
FROM  DISK = N'C:\Program Files\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\Backup\CorruptDemoDBRepairRebuild.bak' WITH  FILE = 1,  
MOVE N'CorruptDemoDBRepairRebuild' TO N'C:\Program Files\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\CorruptDemoDBRepairRebuildRepairRebuild.mdf',  
MOVE N'CorruptDemoDBRepairRebuild_log' TO N'C:\Program Files\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\CorruptDemoDBRepairRebuildRepairRebuild_log.ldf',  NOUNLOAD,  STATS = 5

GO


