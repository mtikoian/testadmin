USE [master]
RESTORE DATABASE [DemoNCIndex] 
FROM  DISK = N'C:\Program Files\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\Backup\CorruptDemoNCIndex.bak' WITH  FILE = 1,  
MOVE N'SalesDBData' TO N'C:\Program Files\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\DemoNCIndex.mdf',  
MOVE N'SalesDBLog' TO N'C:\Program Files\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\DemoNCIndex_LOG.ldf',  NOUNLOAD,  STATS = 5

GO


