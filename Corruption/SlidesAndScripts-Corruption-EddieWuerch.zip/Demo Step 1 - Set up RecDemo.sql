-- Run this script first to create the database.
-- !! IMPORTANT !!
-- Check the file locations for the FG1 and FG2 database files in the CREATE DATABASE command, below

-- THIS SCRIPT IS PROVIDED AS-IS, WITH NO WARANTY OR GUARANTEE
-- IT CONTAINS COMMANDS THAT *WILL* DESTROY DATA AND POSSIBLY DAMAGE
-- A DATABASE SUCH THAT ALL DATA WILL BE LOST
--
-- USE AT YOUR OWN RISK --
--
USE master;
GO
DROP DATABASE RecoveryDemo;
CREATE DATABASE RecoveryDemo;
GO
USE RecoveryDemo;
ALTER DATABASE RecoveryDemo ADD FILEGROUP FG1;
ALTER DATABASE RecoveryDemo ADD FILEGROUP FG2;
GO
ALTER DATABASE RecoveryDemo 
  ADD FILE(NAME = RecDemoFG1Data1, FILENAME = 'C:\sql\RecDemoFG1Data1.ndf', SIZE = 256MB, FILEGROWTH = 256MB) 
  TO FILEGROUP [FG1];
GO
ALTER DATABASE RecoveryDemo MODIFY FILEGROUP FG1 DEFAULT;
GO
ALTER DATABASE RecoveryDemo 
  ADD FILE(NAME = RecDemoFG2Data1, FILENAME = 'D:\RecDemoFG2Data1.ndf', SIZE = 32MB, FILEGROWTH = 256MB) 
  TO FILEGROUP [FG2];
GO


-- don't forget dbo.WreckPage
USE RecoveryDemo;
GO
CREATE TABLE dbo.Testr(id int not null primary key, val2 int NOT NULL);
GO
INSERT dbo.Testr(id, val2)
SELECT object_id, object_id  FROM sys.objects;
GO

CREATE NONCLUSTERED INDEX ixTestr ON dbo.Testr(val2)
GO

USE RecoveryDemo;
GO

SET ANSI_NULLS, QUOTED_IDENTIFIER ON;
GO
IF NOT OBJECT_ID('dbo.WreckPage') IS NULL
  DROP PROC dbo.WreckPage;
GO

CREATE PROC dbo.WreckPage(
@FileID  smallint,
@PageID  int
)
AS
SET NOCOUNT ON;
DECLARE @dbid smallint = DB_ID('RecoveryDemo');
-- This proc uses the undocumented DBCC WRITEPAGE command.
-- It was created for what this demo uses it for: to cause damage to a database
-- and test recovery. It not only makes a data page unusable, 
-- it will additionally tag the database as having had the command run it.
--
-- MICROSOFT WILL NOT SUPPORT A DATABASE THAT HAS BEEN CONTAMINATED BY THIS COMMAND.
-- THIS COMMAND WILL VOID YOUR WARRANTY.

PRINT 'THIS COMMAND HAS ONLY ONE PURPOSE: TO DESTROY DATA. THERE IS NO RISK. IT *WILL* DESTROY DATA.'
DBCC WRITEPAGE(@dbid, @FileID, @PageID, 197, 4, 0xFFEEDDCC, 1);

RETURN;
GO

use master;
GO

USE master;
go


