--Restore demos
-------------------------------------------------------------------------------------
-- THIS SCRIPT IS PROVIDED AS-IS, WITH NO WARANTY OR GUARANTEE
-- IT CONTAINS COMMANDS THAT *WILL* DESTROY DATA AND POSSIBLY DAMAGE
-- A DATABASE SUCH THAT ALL DATA WILL BE LOST
--
-- USE AT YOUR OWN RISK --
-------------------------------------------------------------------------------------

-- This command uses SQL-CMD mode
!!del /Q c:\sql\baks\wreckdemo\*.* 
-- do all demos with same full backup

-- Need full backup and initial log chain backup before we start trashing things
BACKUP DATABASE RecoveryDemo TO DISK = 'c:\sql\baks\wreckdemo\RecDemoBak1.bak' WITH COMPRESSION ;
BACKUP LOG RecoveryDemo TO DISK = 'c:\sql\baks\wreckdemo\RecDemoLog1.trn' WITH COMPRESSION ;
GO

/********************************************************************
 Start trashing things: simulate on-disk corruption - demo #1 (NCI)
*********************************************************************/
-- Find an index page to trash
DBCC IND('RecoveryDemo', 'dbo.Testr', 2)
-- This should be file 3, page 10

USE RecoveryDemo
GO
ALTER DATABASE RecoveryDemo SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
GO
EXEC dbo.WreckPage 3,10;
GO
ALTER DATABASE RecoveryDemo SET MULTI_USER WITH ROLLBACK IMMEDIATE;
GO

SET TRANSACTION ISOLATION LEVEL READ COMMITTED
-- And view the results
SELECT * FROM dbo.Testr ORDER BY val2;

SELECT * FROM msdb.dbo.suspect_pages;

USE MASTER;
GO
ALTER DATABASE RecoveryDemo SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
GO
ALTER DATABASE RecoveryDemo SET MULTI_USER WITH ROLLBACK IMMEDIATE;
GO

DBCC CHECKDB('RecoveryDemo') WITH NO_INFOMSGS;

USE RecoveryDemo;
GO
SELECT * FROM sys.indexes WHERE OBJECT_ID = 245575913
GO


-- It's just a non-clustered index. No data loss! 

-- Just rebuild!
ALTER INDEX ixTestr ON dbo.Testr REBUILD;
GO











-- Nope! Drop it, then create it -OR- DISABLE it, then REBUILD it
ALTER INDEX ixTestr ON dbo.Testr DISABLE;
GO
ALTER INDEX ixTestr ON dbo.Testr REBUILD;
GO
---- or
--DROP INDEX ixTestr ON dbo.Testr;
--GO
--CREATE NONCLUSTERED INDEX ixTestr ON dbo.Testr(val2)
--GO



-- ...and?
SELECT * FROM dbo.Testr ORDER BY val2;

SELECT * FROM msdb.dbo.suspect_pages;

DBCC CHECKDB('RecoveryDemo') WITH NO_INFOMSGS;



DELETE msdb.dbo.suspect_pages
WHERE database_id =DB_ID('RecoveryDemo')


/********************************************************************
 Trashing things: simulate on-disk corruption - demo #2 (CI)
*********************************************************************/
USE RecoveryDemo
GO

DBCC IND('RecoveryDemo', 'dbo.Testr', 1)


ALTER DATABASE RecoveryDemo SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
GO
EXEC dbo.WreckPage 3,8;
GO
ALTER DATABASE RecoveryDemo SET MULTI_USER WITH ROLLBACK IMMEDIATE;
GO

SET TRANSACTION ISOLATION LEVEL READ COMMITTED
SELECT * FROM dbo.Testr ORDER BY id;

SELECT DB_NAME(database_id), * FROM msdb.dbo.suspect_pages;

DBCC CHECKDB('RecoveryDemo') WITH NO_INFOMSGS;

-- this is what you do without backups... :(
ALTER DATABASE RecoveryDemo SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
DBCC CHECKDB('RecoveryDemo',REPAIR_ALLOW_DATA_LOSS) WITH NO_INFOMSGS;


-- Note: before you can begin a filegroup/file/page restore, you must start with a current 
-- log backup
BACKUP LOG RecoveryDemo TO DISK = 'c:\sql\baks\wreckdemo\RecDemoLog2.trn' WITH COMPRESSION;

-- Damage is in File #3:
SELECT IsNull(fg.name, '(log)') as [FileGroup], f.file_id,  f.type_desc, f.name AS logical_name, f.physical_name, f.state_desc
  FROM sys.database_files f LEFT JOIN
       sys.filegroups fg ON f.data_space_id = fg.data_space_id
ORDER BY f.file_id

-- One page? We can fix it!
USE master;
GO
RESTORE DATABASE RecoveryDemo
  PAGE = '3:8'
  FROM DISK = 'c:\sql\baks\wreckdemo\RecDemoBak1.bak'
  WITH NORECOVERY;
GO
RESTORE LOG RecoveryDemo
  FROM DISK = 'c:\sql\baks\wreckdemo\RecDemoLog1.trn' 
  WITH NORECOVERY;
GO
RESTORE LOG RecoveryDemo
  FROM DISK = 'c:\sql\baks\wreckdemo\RecDemoLog2.trn' 
  WITH NORECOVERY;
GO
-- now grab and re-apply transactions that have occurred since restore began
BACKUP LOG RecoveryDemo TO DISK = 'c:\sql\baks\wreckdemo\RecDemoLog3.trn' WITH COMPRESSION;
GO
RESTORE LOG RecoveryDemo
  FROM DISK = 'c:\sql\baks\wreckdemo\RecDemoLog3.trn' 
  WITH NORECOVERY;
GO
RESTORE DATABASE RecoveryDemo
  WITH RECOVERY;
GO

USE RecoveryDemo;
GO
SELECT * FROM dbo.Testr ORDER BY id;

DBCC CHECKDB('RecoveryDemo') WITH NO_INFOMSGS;

SELECT * FROM msdb.dbo.suspect_pages;

-- you can always clean up suspect_pages yourself (if you're a sysadmin)
DELETE msdb.dbo.suspect_pages;


/********************************************************************
 Trashing things: demo #3 (lost file)
*********************************************************************/
USE RecoveryDemo
GO
CREATE TABLE dbo.t2(id int NOT NULL, name varchar(256) NOT NULL, 
       CONSTRAINT pkt2 PRIMARY KEY CLUSTERED(id) ON [FG2])
ON [FG2];
GO

INSERT dbo.t2(id, name) SELECT object_id, name FROM sys.objects;
GO

SELECT * FROM dbo.t2

-- yank

CHECKPOINT;
DBCC DROPCLEANBUFFERS;
DBCC CHECKDB('RecoveryDemo') WITH NO_INFOMSGS;

-- Restore a missing file
-- Grab the lastest transactions
BACKUP LOG RecoveryDemo TO DISK = 'c:\sql\baks\wreckdemo\RecDemoLog4.trn' WITH COMPRESSION;
-- to perform an offline file recovery (available in all editions), 
-- put database in RECOVERY mode:
--BACKUP LOG RecoveryDemo TO DISK = 'c:\sql\baks\wreckdemo\RecDemoLog4.trn' WITH COMPRESSION, NORECOVERY;

GO

SELECT * FROM sys.database_files


-- Start the restore
USE master;
GO
-- this throws an error, but that's OK 
ALTER DATABASE RecoveryDemo MODIFY FILE (NAME = RecDemoFG2Data1, OFFLINE);
GO

RESTORE DATABASE RecoveryDemo
  FILE = 'RecDemoFG2Data1'
  FROM DISK = 'c:\sql\baks\wreckdemo\RecDemoBak1.bak'
  WITH NORECOVERY, MOVE 'RecDemoFG2Data1' TO 'C:\sql\RecDemoFG2Data1.ndf';
GO

RESTORE LOG RecoveryDemo
  FROM DISK = 'c:\sql\baks\wreckdemo\RecDemoLog1.trn' 
  WITH NORECOVERY;
GO
RESTORE LOG RecoveryDemo
  FROM DISK = 'c:\sql\baks\wreckdemo\RecDemoLog2.trn' 
  WITH NORECOVERY;
GO
RESTORE LOG RecoveryDemo
  FROM DISK = 'c:\sql\baks\wreckdemo\RecDemoLog3.trn' 
  WITH NORECOVERY;
GO
RESTORE LOG RecoveryDemo
  FROM DISK = 'c:\sql\baks\wreckdemo\RecDemoLog4.trn' 
  WITH NORECOVERY;
GO
-- now grab and re-apply transactions that have occurred since restore began
BACKUP LOG RecoveryDemo TO DISK = 'c:\sql\baks\wreckdemo\RecDemoLog5.trn' WITH COMPRESSION;
GO
RESTORE LOG RecoveryDemo
  FROM DISK = 'c:\sql\baks\wreckdemo\RecDemoLog5.trn' 
  WITH NORECOVERY;
GO
RESTORE DATABASE RecoveryDemo
  WITH RECOVERY;
GO


