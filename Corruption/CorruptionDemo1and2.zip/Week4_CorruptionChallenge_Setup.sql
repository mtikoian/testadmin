---  http://stevestedman.com/2015/05/corruption-challenge-4-alternate-solution/
-- Example 2 - Database Corruption
-- Presented by Steve Stedman  http://SteveStedman.com
-- Original Solution from Patrick Flynn.
------------------------------------------------------------

-- WEEK 4 SETUP


RAISERROR ('Dont run the whole script, just run sections at a time', 20, 1)  WITH LOG;
-- Step 1 Restore Backup

USE [master]

ALTER DATABASE CorruptionChallenge4 SET SINGLE_USER WITH ROLLBACK IMMEDIATE

RESTORE DATABASE [CorruptionChallenge4] 
FROM  DISK = N'C:\presentations\DataBase Coruption Challenge\Presentation\DBBackups - 2016\CorruptionChallenge4_Corrupt.bak' 
WITH  FILE = 1,  
	MOVE N'CorruptionChallenge4' TO N'C:\SQL_DATA\CorruptionChallenge4.mdf',  
	MOVE N'UserObjects' TO N'C:\SQL_DATA\CorruptionChallenge4_UserObjects.ndf',  
	MOVE N'CorruptionChallenge4_log' TO N'C:\SQL_DATA\CorruptionChallenge4_log.ldf',  
	REPLACE,  STATS = 10
GO

-- Step 2 Check Database  -- cancel after about 10 seconds...
DBCC CHECKDB('CorruptionChallenge4') WITH ALL_ERRORMSGS, NO_INFOMSGS

USE [CorruptionChallenge4]
GO
-- Step 3 Check Current User Objects - Before == 5
SELECT Count(*)
FROM sys.objects
WHERE is_ms_shipped = 0;

SELECT *
FROM sys.objects
WHERE is_ms_shipped = 0;

SELECT * FROM [dbo].[Orders];

DBCC CheckTable(Orders) WITH NO_INFOMSGS;

SELECT * FROM [dbo].[Customers] ;

DBCC CheckTable(Customers) WITH NO_INFOMSGS;

-- Step 4 Errors are related to Clustered Index 
-- Can use the Non clustered indexes to recover all data except MiddleName
-- Require to disable Database Triggers

USE [CorruptionChallenge4]
GO

DISABLE TRIGGER [noDropTables] ON DATABASE;
GO
DISABLE TRIGGER [noNewTables] ON DATABASE;
GO



CREATE TABLE [dbo].[Customers_Copy](
	[id] [int] NOT NULL,
	[FirstName] [varchar](30) NULL,
	[MiddleName] [varchar](30) NULL,
	[LastName] [varchar](30) NULL,
 CONSTRAINT [PK_Customers_1] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [UserObjects]
) ON [UserObjects]

GO


INSERT INTO [dbo].[Customers_Copy] (id, FirstName, MiddleName, LastName)
Select a.id, a.FirstName, '' as MiddleName, b.LastName
FROM 
(
	SELECT [id]
      ,[FirstName]
	FROM [CorruptionChallenge4].[dbo].[Customers]  
	WITH (INDEX(ncCustomerFirstname))
) a
inner join 
(
	SELECT [id]
      ,[LastName]
	FROM [CorruptionChallenge4].[dbo].[Customers] WITH (INDEX(ncCustomerLastname))
) b
ON a.id = b.id


SELECT * 
  FROM [dbo].[Customers_Copy];

-- 511740 rows recovered

-- Using DBCC Page data is intact in page but Allocation Data is incorrect
-- Can extract data via DBCC Page and Parse Data to obtain MiddleName