Use CorruptionChallenge4
GO

-- WEEK 4 Page Extract

-- Create Table to store data from DBCC Page


CREATE TABLE [dbo].[Customers_Copy1](
	[id] [int] NOT NULL,
	[FirstName] [varchar](30) NULL,
	[MiddleName] [varchar](30) NULL,
	[LastName] [varchar](30) NULL,
 CONSTRAINT [PK_Customers_2] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [UserObjects]
) ON [UserObjects]

GO



DECLARE 
	@DBName VARCHAR(256) = 'CorruptionChallenge4', 
	@FileId INT = 3, 
	@PageId INT, 
	@DumpStyle int = 1;

CREATE TABLE #DBCCIND
(
  PageFID INT,
  PagePID INT,
  IAMFID INT,
  IAMPID INT,
  ObjectID INT,
  IndexID INT,
  PartitionNumber INT,
  PartitionID BIGINT,
  iam_chain_type VARCHAR(100),
  PageType INT,
  IndexLevel INT,
  NextPageFID INT,
  NextPagePID INT,
  PrevPageFID INT,
  PrevPagePID INT
);

/* create a temp table to hold dbcc page results */ 
create table #DBCC_Page 
( 
    parentObject varchar(200), 
    object varchar(200), 
    field varchar(200), 
    value varchar(200) 
) 

CREATE TABLE #DBCC_Data
(
	PageId int,
	parentObject varchar(200),
	value varchar(100), 
	I1 int,
	I2 int, 
	I3 int   
)

INSERT INTO #DBCCIND
  EXEC ('DBCC IND(''CorruptionChallenge4'', ''dbo.Customers'', 1)');


DECLARE @STR VARCHAR (2000) 

DECLARE db_cursor CURSOR FOR  
SELECT PagePID 
FROM #DBCCIND 
WHERE PageType = 1 

OPEN db_cursor   
FETCH NEXT FROM db_cursor INTO @PageId   

WHILE @@FETCH_STATUS = 0   
BEGIN   
	SET @STR='DBCC PAGE (' + @DBName + ',' + Cast(@FileId as varchar(3)) + ','+ 
		Cast(@PageId as varchar(100)) + ','+ 
		Cast(@DumpStyle as varchar(100)) + ') with tableresults'

    PRINT @STR;

	/* store the output of dbcc page into the temp table */ 
	insert into #DBCC_Page exec(@STR) 

	INSERT INTO #DBCC_Data(PageId, parentObject, value, I1, I2, I3)
	Select 
		@PageId as PageId,
		parentObject, 
		value, 
		CHARINDEX('Offset', parentObject, 1) as I1,
		CHARINDEX('Length', parentObject, 1) as I2, 
		CHARINDEX('DumpStyle', parentObject, 1) as I3   
	from #DBCC_Page
	WHERE object like 'Memory Dump %'

	DELETE FROM #DBCC_Page;

    FETCH NEXT FROM db_cursor INTO @PageId   
END   

CLOSE db_cursor   
DEALLOCATE db_cursor; 



-------- Check results.
SELECT * 
  FROM #DBCC_Data;

With Translate as
(
Select 
	PageId,
	SUBSTRING(parentObject, 5, I1-7) as Slot,
	SUBSTRING(parentObject, I2+7, I3-I2-9) as Length,
	SUBSTRING(value,1,16) as LengthHex,
	SUBSTRING(value,20,45) as RawValues,
	SUBSTRING(value,67,20) as StringValues
FROM #DBCC_Data
), OrderedData as
(
	Select
		PageId,
		Slot,
		Length,
		LengthHex,
		RawValues,
		StringValues, 
		ROW_NUMBER() Over (Partition By PageId, Slot Order By LengthHex) as RowNum
	FROM Translate
) 
--SELECT * FROM OrderedData
Select 
	a.PageId, 
	a.Slot, 
	a.Length, 
	a.RawValues + ' ' + b.RawValues as HexValues, 
	a.StringValues + b.StringValues as StringValues
into tmpCustomerData
FROM 
(
	Select PageId, Slot, Length, RawValues, StringValues, RowNum
	from OrderedData
	WHERE RowNum =1
) a
INNER JOIN
(
	Select PageId, Slot, Length, RawValues, StringValues, RowNum
	from OrderedData
	WHERE RowNum = 2
) b  -- May need more INNER Joins if rows were larger.
ON a.Slot = b.Slot
AND a.PageId  = b.PageId
ORDER BY a.PageId, a.Slot;
GO
SELECT * FROM tmpCustomerData
GO
-- Needs following function
CREATE FUNCTION dbo.HexStrToVarBinary(@hexstr varchar(8000))
RETURNS varbinary(8000)
AS
BEGIN 
    DECLARE @hex char(1), @i int, @place bigint, @a bigint
    SET @i = LEN(@hexstr) 

    set @place = convert(bigint,1)
    SET @a = convert(bigint, 0)

    WHILE (@i > 0 AND (substring(@hexstr, @i, 1) like '[0-9A-Fa-f]')) 
     BEGIN 
        SET @hex = SUBSTRING(@hexstr, @i, 1) 
        SET @a = @a + 
    convert(bigint, CASE WHEN @hex LIKE '[0-9]' 
         THEN CAST(@hex as int) 
         ELSE CAST(ASCII(UPPER(@hex))-55 as int) end * @place)
    set @place = @place * convert(bigint,16)
        SET @i = @i - 1
    
     END 

    RETURN convert(varbinary(8000),@a)
END;
GO 

With Data as
(
	SELECT 
	PageId, Slot, Length, HexValues, StringValues,                     
	CAST(dbo.HexStrToVarBinary('0x' + Substring(HexValues, 17,2) + Substring(HexValues, 15,2) + Substring(HexValues, 13,2) + Substring(HexValues, 11,2)) AS INT) as id,
	CAST(dbo.HexStrToVarBinary('0x' + Substring(HexValues, 33,2) + Substring(HexValues, 31,2)) AS INT) as V1,
	CAST(dbo.HexStrToVarBinary('0x' + Substring(HexValues, 38,2) + Substring(HexValues, 35,2)) AS INT) as V2
	FROM   tmpCustomerData
)
INSERT INTO [dbo].[Customers_Copy1](id, FirstName, MiddleName, LastName)
Select 
	Data.id,
	Substring(StringValues,20, V1-19),
	Substring(StringValues,V1+1, V2-V1),
	Substring(StringValues,V2+1, 50)
from Data;
-- 511740 rows inserted
-- Compare to data extracted from Non-Clustered

Select Count(*)
FROM Customers_Copy1 c1
INNER JOIN Customers_Copy c2
	ON c1.id = c2.id;
-- 511740 rows matching

-- All Names match
SELECT Count(*)
  FROM Customers_Copy1 c1
 INNER JOIN Customers_Copy c2 ON c1.id = c2.id
 WHERE c1.FirstName <> c2.FirstName
    OR c2.LastName <> c2.LastName;

SELECT *
  FROM Customers_Copy1;







