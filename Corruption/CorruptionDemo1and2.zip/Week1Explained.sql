-- Example 1 - Database Corruption
-- Created by Steve Stedman  http://SteveStedman.com
-- Twitter @sqlEmt
-- LinkedIn http://linkedin.com/in/stevestedman
------------------------------------------------------------

RAISERROR ('Dont run the whole script, just run sections at a time', 20, 1)  WITH LOG;

SELECT @@VERSION;

USE [master]
GO
-- lets start by looking at what files the backup contains.
RESTORE FILELISTONLY
   FROM DISK = N'C:\presentations\DataBase Coruption Challenge\Presentation\DBBackups - 2016\CorruptionChallenge1.bak' ;
GO


RESTORE DATABASE [CorruptionChallenge1] 
   FROM DISK = N'C:\presentations\DataBase Coruption Challenge\Presentation\DBBackups - 2016\CorruptionChallenge1.bak' 
   WITH FILE = 1,  
        MOVE N'CorruptionChallenge1' TO N'C:\SQL_DATA\CorruptionChallenge1.mdf',  
        MOVE N'CorruptionChallenge1_log' TO N'C:\SQL_DATA\CorruptionChallenge1_log.ldf',  
        RECOVERY, REPLACE;

GO
USE CorruptionChallenge1;
GO 
DBCC CheckDB(CorruptionChallenge1) WITH NO_INFOMSGS;
 

-- double check the object id..
SELECT * 
  FROM sys.objects
 WHERE object_id = 245575913;

DBCC CheckTable(Revenue) WITH NO_INFOMSGS;


-- go into single user mode, so that nobody else is in the way...
ALTER DATABASE [CorruptionChallenge1] SET SINGLE_USER WITH ROLLBACK IMMEDIATE;


-- lets see what we have in the corrupt table
SELECT * 
  FROM Revenue;
-- 54 rows

-- whats in page 280?
DBCC TRACEON(3604) with no_infomsgs;
DBCC Page(CorruptionChallenge1, 1, 280, 2) WITH NO_INFOMSGS;


-- now what indexes and columns do we have available?
SELECT ind.name as IndexName,
       col.name as ColumnName,
       ic.is_included_column
  FROM sys.indexes ind 
 INNER JOIN sys.index_columns ic ON  ind.object_id = ic.object_id and ind.index_id = ic.index_id 
 INNER JOIN sys.columns col ON ic.object_id = col.object_id and ic.column_id = col.column_id 
 WHERE ind.object_id = OBJECT_ID('Revenue') 
   AND ind.is_unique = 0 
   AND ind.is_unique_constraint = 0 
 ORDER BY ind.name, ind.index_id, ic.index_column_id;
-- Non-clustered indexes implicitly include the clustered index keys automatically.
GO
 
-- pull from the non-clustered index without touching the clustered index
-- note that [id] is not called out in the nc-index, but it is included
SELECT [id], [Year], [Notes]
  FROM Revenue
  WITH (INDEX (ncBadNameForAnIndex) );
 
-- pull from the other non-clustered index without touching the clustered index
SELECT [id], [DepartmentID], [Revenue]
  FROM Revenue
  WITH (INDEX (ncDeptIdYear) );

GO



-- These next 4 lines where part of the winning solution by Brent Ozar.
--  Disclaimer:  I know, I'm really cheating here - there could be differences 
--    between rows or null value
SELECT SUM(DepartmentID), SUM(Revenue) FROM dbo.Revenue WITH (INDEX=clustId);
SELECT SUM(DepartmentID), SUM(Revenue) FROM dbo.Revenue WITH (INDEX=[ncDeptIdYear]);

SELECT SUM(Year), SUM(LEN(Notes)) FROM dbo.Revenue WITH (INDEX=clustId);
SELECT SUM(Year), SUM(LEN(Notes)) FROM dbo.Revenue WITH (INDEX=[ncBadNameForAnIndex]);

-- at this point, we know that NOTES is likely the only thing different


-- full outer join and compare the NOTES column from the clustered index to the nonclustered.
SELECT r1.[id], r1.[Notes] as 'FromNcIndex', r2.[Notes] as 'FromClustered'
  FROM Revenue AS r1 WITH (INDEX (ncBadNameForAnIndex) )
  FULL OUTER JOIN Revenue AS r2 WITH (INDEX=clustId) on r1.id = r2.id
  WHERE ISNULL(r1.[Notes], '') <> ISNULL(r2.[Notes], '');

-- now we know there is something different at id 31 in the notes column

-- Can we update the bad row?
BEGIN TRANSACTION;
	UPDATE [Revenue] 
	   SET Notes = 'test' 
	 WHERE id = 31;
ROLLBACK TRANSACTION;


-- Can we delete the bad row?
BEGIN TRANSACTION;
	DELETE [Revenue] 
	 WHERE id = 31;
ROLLBACK TRANSACTION;


-- create a query to bring back the all the data in the clustered index from the nonclustered indexes 
SELECT r1.[id], r2.[DepartmentID], r2.[Revenue], r1.[Year], r1.[Notes]
  FROM Revenue r1 WITH (INDEX (ncBadNameForAnIndex) )
 INNER JOIN Revenue as r2 WITH (INDEX (ncDeptIdYear) ) ON r1.[id] = r2.[id]
 ORDER BY r1.[id];



-- compare the entire results set double check the differences
SELECT r1.[id], r2.[DepartmentID], r2.[Revenue], r1.[Year], r1.[Notes]
  FROM Revenue r1 WITH (INDEX (ncBadNameForAnIndex) )
 INNER JOIN Revenue as r2 WITH (INDEX (ncDeptIdYear) ) ON r1.[id] = r2.[id]
EXCEPT
SELECT * 
  FROM Revenue;

SELECT * 
  FROM Revenue
EXCEPT
SELECT r1.[id], r2.[DepartmentID], r2.[Revenue], r1.[Year], r1.[Notes]
  FROM Revenue r1 WITH (INDEX (ncBadNameForAnIndex) )
 INNER JOIN Revenue as r2 WITH (INDEX (ncDeptIdYear) ) ON r1.[id] = r2.[id];
 


-- now save the data off to use later
CREATE TABLE [dbo].[RevenueSave](
		[id] [int] NOT NULL,
		[DepartmentID] [int] NULL,
		[Revenue] [int] NULL,
		[Year] [int] NULL,
		[Notes] [varchar](300) NULL
);

-- saving it all since we don't now what cleaning up the corruption will remove
INSERT INTO [dbo].[RevenueSave]
SELECT r1.[id], r2.[DepartmentID], r2.[Revenue], r1.[Year], r1.[Notes]
  FROM Revenue r1 WITH (INDEX (ncBadNameForAnIndex) )
 INNER JOIN Revenue as r2 WITH (INDEX (ncDeptIdYear) ) ON r1.[id] = r2.[id]
 ORDER BY r1.[id];
 
SELECT * FROM [dbo].[RevenueSave];
-- 54 rows


-- compare every row in RevenueSave to Revenue
SELECT r.*, rs.*
  FROM [dbo].[RevenueSave] AS rs
  FULL OUTER JOIN [dbo].[Revenue] AS r on r.id = rs.id
 WHERE ISNULL(r.[DepartmentID], 0) <> ISNULL(rs.[DepartmentID], 0)
    OR ISNULL(r.[Revenue], 0) <> ISNULL(rs.[Revenue], 0)
    OR ISNULL(r.[Year], 0) <> ISNULL(rs.[Year], 0)
    OR ISNULL(r.[Notes], '') <> ISNULL(rs.[Notes], '')
 ORDER BY r.ID, rs.ID;



-- first try to rebuild
BEGIN TRANSACTION; -- so we can undo if we need to

	DBCC CheckTable(Revenue, REPAIR_REBUILD);

	-- no good, nothing changed
	SELECT * FROM Revenue;

ROLLBACK TRANSACTION;




BEGIN TRANSACTION; -- so we can undo if we need to

	-- the following causes parts of the table to be lost.
	DBCC CheckTable(Revenue, REPAIR_ALLOW_DATA_LOSS);
	-- another option would be just TRUNCATE TABLE Revenue;

	SELECT * 
	  FROM Revenue;
	-- how many rows??

	-- whats missing...
	SELECT * 
	  FROM RevenueSave
    EXCEPT 
	SELECT * 
	  FROM Revenue;
	
ROLLBACK TRANSACTION;
--COMMIT TRANSACTION;


DBCC CheckTable(Revenue) WITH NO_INFOMSGS;
DBCC CheckDB(CorruptionChallenge1) WITH NO_INFOMSGS;

SELECT * 
  FROM Revenue;
-- how many rows.... its not 54 any more




-- lets see whats different between the tables
SELECT r.*, rs.*
  FROM [dbo].[RevenueSave] AS rs
  FULL OUTER JOIN [dbo].[Revenue] AS r on r.id = rs.id
 WHERE ISNULL(r.[DepartmentID], 0) <> ISNULL(rs.[DepartmentID], 0)
    OR ISNULL(r.[Revenue], 0) <> ISNULL(rs.[Revenue], 0)
    OR ISNULL(r.[Year], 0) <> ISNULL(rs.[Year], 0)
    OR ISNULL(r.[Notes], '') <> ISNULL(rs.[Notes], '')
 ORDER BY r.ID, rs.ID;


-- so now lets move the missing rows from RevenueSave 
SET IDENTITY_INSERT Revenue ON;

INSERT INTO Revenue ([id], [DepartmentID], [Revenue], [Year], [Notes])
SELECT * FROM RevenueSave rs
 WHERE rs.[id] NOT IN (SELECT [id] FROM Revenue);

SET IDENTITY_INSERT Revenue OFF;

SELECT * FROM Revenue;
-- how many rows now?


-- check the differences again..
SELECT r.*, rs.*
  FROM [dbo].[RevenueSave] AS rs
  FULL OUTER JOIN [dbo].[Revenue] AS r on r.id = rs.id
 WHERE ISNULL(r.[DepartmentID], 0) <> ISNULL(rs.[DepartmentID], 0)
    OR ISNULL(r.[Revenue], 0) <> ISNULL(rs.[Revenue], 0)
    OR ISNULL(r.[Year], 0) <> ISNULL(rs.[Year], 0)
    OR ISNULL(r.[Notes], '') <> ISNULL(rs.[Notes], '')
 ORDER BY r.ID, rs.ID;


 
-- confirm that the corruption is gone.
DBCC CheckDB(CorruptionChallenge1) WITH NO_INFOMSGS;

-- Normally I might leave this around for a while to just be sure we don't need it again.
DROP TABLE RevenueSave;

ALTER DATABASE [CorruptionChallenge1] SET MULTI_USER WITH ROLLBACK IMMEDIATE;




-- its done, now lets back up the database to be sure we have a good 
--   restore state to get back to if there are more probems.
BACKUP DATABASE CorruptionChallenge1
TO DISK = N'C:\DBBackups\CorruptionChallenge1_Fixed.bak' 
   WITH FORMAT,
   NAME = 'Full Backup of CorruptionChalenge1';



DBCC CheckDB(CorruptionChallenge1) WITH NO_INFOMSGS;


-- VICTORY!!!!