RAISERROR ('Dont run the whole script, just run sections at a time', 20, 1)  WITH LOG;


-- WEEK 4 - Cleanup

-- Step1 Restore Data to original Table (need to disableFK)
USE [CorruptionChallenge4]
GO

ALTER TABLE [dbo].[Orders] DROP CONSTRAINT [FK_Orders_People]
GO


TRUNCATE TABLE [dbo].[Customers];
DBCC CheckTable(Customers) WITH NO_INFOMSGS;

DBCC CHECKDB('CorruptionChallenge4') WITH ALL_ERRORMSGS, NO_INFOMSGS


SET IDENTITY_INSERT Customers ON

INSERT INTO [dbo].[Customers](id, FirstName, MiddleName, LastName)
SELECT 
	id, FirstName, MiddleName, LastName
FROM [dbo].[Customers_Copy1];

SET IDENTITY_INSERT Customers OFF

-- Check Corruption fixed
DBCC CHECKDB('CorruptionChallenge4') WITH ALL_ERRORMSGS, NO_INFOMSGS


-- Clean UP 
-- (a) Restore FK
ALTER TABLE [dbo].[Orders]  WITH CHECK ADD  CONSTRAINT [FK_Orders_People] FOREIGN KEY([customerId])
REFERENCES [dbo].[Customers] ([id])
GO

ALTER TABLE [dbo].[Orders] CHECK CONSTRAINT [FK_Orders_People]
GO

-- (b) Drop Temporary objects
USE [CorruptionChallenge4]
GO

DROP TABLE [dbo].[Customers_Copy]
DROP TABLE [dbo].[Customers_Copy1]
DROP TABLE [dbo].[tmpCustomerData]
DROP FUNCTION [dbo].[HexStrToVarBinary]

--(c) Restore Triggers
ENABLE TRIGGER [noDropTables] ON DATABASE;
ENABLE TRIGGER [noNewTables] ON DATABASE;

-- (d) Check Object Count restored to 5
SELECT Count(*)
FROM sys.objects
WHERE is_ms_shipped = 0;

-- (e) Check Data
SELECT * FROM dbo.Customers


-- Create a full backup at this point....



-- VICTORY
