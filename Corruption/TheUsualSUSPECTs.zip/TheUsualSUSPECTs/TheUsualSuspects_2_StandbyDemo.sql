/************************************************************************
				SETUP, IF NEEDED - BEGIN 
************************************************************************/
/* Prerequisite: need a log backup job running on this machine, 
   scheduled for a log backup once per minute. */

use master;

/* Create a database - full recovery mode. */
create database DemoStand;

alter database DemoStand 
set recovery full;

/* Take a full backup to start the log chain. */
backup database DemoStand
to disk = 'C:\SQL\Backup\DemoStand_Full.bak'
with checksum, compression, init;

/* Create a table that holds timestamped data. */
use DemoStand;

create table DateList (
	ID int identity(1,1) not null,
	DateStamp datetime not null
	)
;

/* Start a loop to insert data every couple of seconds, for 5 minutes total. */
declare @starttime datetime = current_timestamp

while (select datediff(mi,@starttime,current_timestamp)) < 5
begin
	insert into DateList(DateStamp)
	select current_timestamp;

	waitfor delay '00:00:03'
end

/* Tail log backup to finish things up. */
backup log DemoStand
to disk = 'C:\SQL\Backup\DemoStand_Tail.trn'
with norecovery;

/************************************************************************
				SETUP - END
************************************************************************/

/* Hey you guys! Check out these backups I took! */
select 
  bs.database_name as dbname
 ,case bs.type 
    when 'd' then 'full'
    when 'i' then 'diff'
    when 'l' then 'tlog'
    else 'unknown'
  end as backuptype
 ,bs.backup_finish_date as datecompleted
 ,bmf.physical_device_name as backupfile
from msdb.dbo.backupset as bs
inner join msdb.dbo.backupmediafamily as bmf
  on bs.media_set_id = bmf.media_set_id
where bs.database_name = 'DemoStand'
order by 
  bs.backup_finish_date desc;
go

/* backup query results: 

C:\SQL\Backup\BIO4_DemoStand_LOG_20150204_204718.trn
C:\SQL\Backup\BIO4_DemoStand_LOG_20150204_204700.trn
C:\SQL\Backup\BIO4_DemoStand_LOG_20150204_204600.trn
C:\SQL\Backup\BIO4_DemoStand_LOG_20150204_204500.trn
C:\SQL\Backup\BIO4_DemoStand_LOG_20150204_204400.trn
C:\SQL\Backup\BIO4_DemoStand_LOG_20150204_204300.trn
C:\SQL\Backup\DemoStand_Full.bak

*/

/* Now stop, collaborate and listen. Also, restore the database from the full backup, 
   but leave it in NORECOVERY. Tail-log backup, first. */
use master;

restore database DemoStand
from disk = 'C:\SQL\Backup\DemoStand_Full.bak'
with norecovery;

/* Now restore a tranlog, but keep the DB in standby. */
restore log DemoStand
from disk = 'C:\SQL\Backup\BIO4_DemoStand_LOG_20150204_204300.trn'
with standby = 'C:\SQL\Backup\DemoStand_Undo.txt';

/* Read-only? Let's query it! */
select * from DemoStand.dbo.DateList
order by ID

/* What if we want to roll forward a bit?  Try restoring the next log backup. */
restore log DemoStand
from disk = 'C:\SQL\Backup\BIO4_DemoStand_LOG_20150204_204400.trn'
with standby = 'C:\SQL\Backup\DemoStand_Undo.txt';

select * from DemoStand.dbo.DateList order by ID

/* Let's try rolling forward a few seconds, but not the whole next backup. */
restore log DemoStand
from disk = 'C:\SQL\Backup\BIO4_DemoStand_LOG_20150204_204500.trn'
with standby = 'C:\SQL\Backup\DemoStand_Undo.txt',
	 stopat = '2015-02-04 20:44:10.000'

select * from DemoStand.dbo.DateList order by ID

/* Just a *little* more forward? */
/* Let's try rolling forward a few seconds, but not the whole next backup. */
restore log DemoStand
from disk = 'C:\SQL\Backup\BIO4_DemoStand_LOG_20150204_204500.trn'
with standby = 'C:\SQL\Backup\DemoStand_Undo.txt',
	 stopat = '2015-02-04 20:44:30.000'

select * from DemoStand.dbo.DateList order by ID

/* Can we go backward? */
restore log DemoStand
from disk = 'C:\SQL\Backup\BIO4_DemoStand_LOG_20150204_204500.trn'
with standby = 'C:\SQL\Backup\DemoStand_Undo.txt', 
	 stopat = '2015-02-04 20:44:20.000';

select * from DemoStand.dbo.DateList order by ID

/* What's this look like in the error log? */
exec xp_readerrorlog; 

/* Since we got an error, we repeat the last restore. */
restore log DemoStand
from disk = 'C:\SQL\Backup\BIO4_DemoStand_LOG_20150204_204500.trn'
with standby = 'C:\SQL\Backup\DemoStand_Undo.txt',
	 stopat = '2015-02-04 20:44:30.000'

select * from DemoStand.dbo.DateList order by ID

/* Now, let's bring the database fully online. */
restore database DemoStand
with recovery; 

/* Check the error log contents. */
exec xp_readerrorlog; 
