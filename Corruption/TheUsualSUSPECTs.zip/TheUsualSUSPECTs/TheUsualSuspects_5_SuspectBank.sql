/* 
	Create the database and put an account in there. 
	Start a transaction, write it to disk.
	Show "half" transaction.
	Kill SQL and restart - show how transaction has rolled back.
	Show startup message noting rollback.
	Start transaction again. 
	Kill SQL but damage log file.
	Restart SQL, Database will enter SUSPECT mode.
	Detach / Attach? (Nope...)
	Hack Attach
	Emergency Mode
	Select data. 
	(Continue after error?)

	drop database SuspectBank	
*/

use master; 

create database SuspectBank;
go

use SuspectBank;

alter database SuspectBank
set recovery full;

backup database SuspectBank
to disk = 'C:\SQL\Backup\SuspectBank.bak'
with init, format, checksum, compression;
go

backup log SuspectBank
to disk = 'C:\SQL\Backup\SuspectBank.trn'
with init, format, checksum, compression;
go


create table Accounts (
	AccountName varchar(200),
	CheckingBalance int, 
	SavingsBalance int
	);

insert into Accounts
values('David Maxwell', 0, 1000);

select * from Accounts;
go

/* Start a transaction to move some money from savings to checking. */
begin tran; 

update Accounts
set CheckingBalance = 1000
where AccountName = 'David Maxwell'
go

/* Make sure that's written to disk... */
checkpoint;
go

/* What does the table look like currently? */
select * from Accounts;

/* SQL Server Crashes! (Run 'SHUTDOWN WITH NOWAIT' in another window.) */

use SuspectBank

select * from Accounts;
go

/* Why? Because that transaction never committed. */
exec xp_readerrorlog 0,1,N'rolled';

/* Let's try that again... */
begin tran; 

update Accounts
set CheckingBalance = 1000
where AccountName = 'David Maxwell'
go

/* Make sure that's written to disk... */
checkpoint;
go

/* SQL Server Crashes! (Run 'SHUTDOWN WITH NOWAIT' in another window.) 
   But this time, something happens to the log file...
   (Search for H@@@ ... User Transaction)
*/

/* databases view says... */
select name, state_desc
from sys.databases 
where name = 'SuspectBank'

/* sp_helpdb says... */
exec sp_helpdb SuspectBank;

/* Try something crazy. Detach / Attach? */
use master; 

exec sp_detach_db @dbname = 'SuspectBank';

/* SQL won't let you do this any more, so we'll have to trick it. */

alter database SuspectBank
set offline;

exec sp_detach_db @dbname = 'SuspectBank';

/* Now re-attach */
exec sp_attach_db @dbname = 'SuspectBank', 
	@filename1 = 'C:\SQL\Data\SuspectBank.mdf', 
	@filename2 = 'C:\SQL\Logs\SuspectBank_log.ldf';

/* Out of the frying pan... into the fire.
   Looks like SQL Server was trying to save us from ourselves.
   Further trickery will be required.  A "Hack Attach" is called for. 
   Save the current database files to a safe location. 
*/

/* Create a 'dummy' database. */
create database SuspectBank;

/* Now offline that database and replace the new 
   database files with the old ones. 
*/

alter database SuspectBank
set offline;

alter database SuspectBank
set online;

/* Out of the fire, but back in the frying pan. Let's take a closer look.
*/
alter database SuspectBank
set emergency;

use SuspectBank;

select * from Accounts;
go

/* Not where we want to be. At this point, our data is inconsistent. */
dbcc checkdb (SuspectBank)
with no_infomsgs;

/* Even CHECKDB thinks everything is OK. Can we attempt a tail-log backup? */

backup log SuspectBank
to disk = 'C:\sql\backup\suspectbak.trn'
with no_truncate, continue_after_error;


