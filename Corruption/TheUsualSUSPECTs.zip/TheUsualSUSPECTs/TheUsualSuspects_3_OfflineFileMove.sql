/* Offline demo. */

/* Create database to move files around. */
create database OfflineMove on 
	(
		name = 'OfflineMove_Data', 
		filename = 'C:\SQL\Data\OfflineMove.mdf'
	)
	log on
	(
		name = 'OfflineMove_Log',
		filename = 'C:\SQL\Logs\OfflineMove.ldf'
	)
;

select db_name(database_id), name, physical_name 
from master.sys.master_files
where database_id = db_id('OfflineMove');

/* Alter file locations */
alter database OfflineMove
modify file (
	name = 'OfflineMove_Log',
	filename = 'C:\SQL\OtherLogs\OfflineMove.ldf'
	)

select db_name(database_id), name, physical_name 
from master.sys.master_files
where database_id = db_id('OfflineMove');

/* Take DB offline. */
alter database OfflineMove
set offline;

/* Move files */
!!move C:\SQL\Logs\OfflineMove.ldf C:\SQL\OtherLogs\OfflineMove.ldf

/* Bring DB back online. */
alter database OfflineMove
set online; 

select db_name(database_id), name, physical_name 
from master.sys.master_files
where database_id = db_id('OfflineMove');

/* clean up? */
alter database OfflineMove
set offline;

drop database OfflineMove;

/* Really clean up. */
create database OfflineMove on 
	(
		name = 'OfflineMove_Data', 
		filename = 'C:\SQL\Data\OfflineMove.mdf'
	)
	log on
	(
		name = 'OfflineMove_Log',
		filename = 'C:\SQL\OtherLogs\OfflineMove.ldf'
	)
for attach;

drop database OfflineMove;
