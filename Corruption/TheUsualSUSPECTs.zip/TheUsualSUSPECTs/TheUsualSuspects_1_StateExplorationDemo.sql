/***************************************************************
  Name: TheUsualSUSPECTs_ExploringDatabaseState.sql
  Project/Ticket#: SQLSaturday357 - Cleveland
  Date: Jan 2015
  Requester: --
  DBA: David M Maxwell
  Step: 1 of 3
  Server: (local)
  Instructions: This script examines database state, showing the 
  undo and redo phases of startup as well as the CHECKDB LNG 
  output. Also shows how a database displays when it is online 
  or offline.

  ****************************************************
  NOTE: Restart SQL Server before running this script.
  ****************************************************

***************************************************************/
use master;

/* Show redo and undo phases of database startup. There will be
   messages in the error log for transactions rolled forward and
   rolled back on database startup.  */
exec xp_readerrorlog 0, 1, N'rolled';

/*  Show two different ways to see database state in T-SQL. 
	Don't forget to show from SSMS as well, for the point 
	and click fans. ;-)
*/
/* First, create a database to play with. */
create database SteadyState;

/*	sys.databases view: */
select name, state_desc from sys.databases;

/*	sp_helpdb system stored proc */
exec sp_helpdb;

exec sp_helpdb SteadyState;

/*	Take a DB offline. Do those still work? */
use master;

alter database SteadyState 
set offline with rollback immediate; 
/* Why rollback immediate? What's that mean? Why would we use it? */

/*	sys.databases view: */
select name, state_desc from sys.databases;

/*	Now try sp_helpdb... */
exec sp_helpdb;

exec sp_helpdb SteadyState;

/*	Since we can't check our permissions within the database, 
	sp_helpdb won't show the database to us. 
*/

/*	Bring SteadyState back online. */
alter database SteadyState 
set online; 

/* Clean up: */
drop database SteadyState;


