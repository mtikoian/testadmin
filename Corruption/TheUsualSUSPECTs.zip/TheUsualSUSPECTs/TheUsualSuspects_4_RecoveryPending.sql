use master; 

/* Create database with log on "unstable" drive. */
if exists (select name from sys.databases where name = 'rpdemo')
begin
	drop database rpdemo
end


create database RPDemo on (
	name = 'rpdemo', 
	filename = 'C:\sql\data\rpdemo.mdf'
	)
	log on (
	name = 'rpdemo_log', 
	filename = 'F:\rpdemolog.ldf' /* <-- huh? */
	)
;

/* Add a table to that database. */
use RPDemo;
create table datatable (
	ID int identity(1,1) not null, 
	bignumber bigint not null
	)
go

/* Start a data insert... */
insert into datatable (bignumber)
select cast(rand() * 1000 as int)
go 50000

/* SAN Failure / Hard Disk Crash - What's the state? */
select name, state_desc
from sys.databases
where name = 'RPDemo';


/* If file can be brough back / recovered... */
alter database rpdemo
set offline;

alter database rpdemo
set online;

/* Check error log for recovery messages: */
exec xp_readerrorlog;

/* How far did we get? */
select count(*) from RPDemo.dbo.datatable;

