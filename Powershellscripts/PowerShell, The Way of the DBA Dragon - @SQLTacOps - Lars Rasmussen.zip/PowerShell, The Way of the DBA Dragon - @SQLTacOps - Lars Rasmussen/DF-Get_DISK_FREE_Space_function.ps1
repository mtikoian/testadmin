function df { Param([string[]]$ComputerName) Get-WMIObject Win32_Volume -filter "DriveType=3" -computer $ComputerName | Select SystemName,Caption,Label,@{Name="DiskSize(GB)";
Expression={[decimal]("{0:N1}" -f($_.capacity/1gb))}},@{Name="freespace(GB)";Expression={[decimal]("{0:N1}" -f($_.freespace/1gb))}},@{Name="PercentFree(%)";
Expression={"{0:P2}" -f(($_.freespace/1gb)/($_.capacity/1gb))}}}