function LastReboot {
$date = Get-WmiObject Win32_OperatingSystem -ComputerName $args[0] | foreach{$_.LastBootUpTime}
$RebootTime = [System.DateTime]::ParseExact($date.split('.')[0],'yyyyMMddHHmmss',$null)
$RebootTime
}