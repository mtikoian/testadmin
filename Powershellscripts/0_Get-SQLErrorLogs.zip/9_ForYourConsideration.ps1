﻿1..6 | %{
$VoteSql = "http://sqlps.io/$_"
Start-Process $VoteSql
}
<# Make sure you're signed in when you vote #>