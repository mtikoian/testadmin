﻿#Import-Module SqlServer;

cd SQLSERVER:\sql\localhost\Default\DATABASES\

Dir |
Out-GridView -PassThru |
%{Backup-SqlDatabase -Database $_.Name
}


Get-SqlDatabase -ServerInstance localhost |
Where { $_.Name -ne 'tempdb' } |
Backup-SqlDatabase -CompressionOption On


<# Using a Snippet to scale your code #>
<#
    .DESCRIPTION            

#>
foreach ($RegisteredSQLs IN dir -recurse SQLSERVER:\SQLRegistration\'Database Engine Server Group'\ |
                                where {$_.Mode -ne 'd'} | OGV -PassThru)
{
Get-SqlDatabase -ServerInstance $RegisteredSQLs.Name |
Where { $_.Name -ne 'tempdb' } |
Backup-SqlDatabase -CompressionOption On
}


