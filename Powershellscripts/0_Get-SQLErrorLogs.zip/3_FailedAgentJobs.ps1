﻿Get-SqlAgent -ServerInstance 'localhost' | 
Get-SqlAgentJob | 
OGV
<# Compare this to OED of SQL Agent #>

$sqlserver = 'localhost'
Get-SqlAgent -ServerInstance localhost | 
Get-SqlAgentJob | 
Where { $_.IsEnabled -eq $true -and $_.LastRunOutcome -eq 'Failed' }


<# Looking at your output, if you're new to PowerShell you'll want to know... #>
#Format-Table
Get-SqlAgentJobHistory -ServerInstance $sqlserver -Since LastMonth |
FT -AutoSize

#Select-Object
Get-SqlAgentJobHistory -ServerInstance $sqlserver -Since LastMonth |
SELECT *


<# Check the history of all my Registered SQL Servers #>
<#
    .DESCRIPTION            
#>
foreach ($RegisteredSQLs IN dir -recurse SQLSERVER:\SQLRegistration\'Database Engine Server Group'\ |
                                where {$_.Mode -ne 'd'} | OGV -PassThru)
{
Get-SqlAgent -ServerInstance $RegisteredSQLs.Name | 
Get-SqlAgentJob | 
Where-Object { $_.IsEnabled -eq $true -and $_.LastRunOutcome -eq 'Failed' }
}


<# In the future, I should have a Start-SqlAgentJob cmdlet that I 
    can pipe these results to. #>