﻿#0
Import-Module -Name SqlServer

#1
Get-SqlErrorLog -ServerInstance localhost\sql2016

#How many messages
Get-SqlErrorLog -ServerInstance localhost\sql2016 | measure

Get-SqlErrorLog -ServerInstance localhost\sql2016|
OGV
# memory, paged out

Get-SqlErrorLog -ServerInstance localhost\sql2016|
OGV -PassThru |
measure

<#
    .DESCRIPTION            

#>
foreach ($RegisteredSQLs IN dir -recurse SQLSERVER:\SQLRegistration\'Database Engine Server Group'\ | where {$_.Mode -ne 'd'} )
{
$RegisteredSQLs.Name
}


foreach ($RegisteredSQLs IN dir -recurse SQLSERVER:\SQLRegistration\'Database Engine Server Group'\ | where {$_.Mode -ne 'd'} | OGV -PassThru)
{
$SqlErrLogs += Get-SqlErrorLog -ServerInstance $RegisteredSQLs.Name;
}
$SqlErrLogs|
OGV -PassThru |
measure
<# Scroll Right #>