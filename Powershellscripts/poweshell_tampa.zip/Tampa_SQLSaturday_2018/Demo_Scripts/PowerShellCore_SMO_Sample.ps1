<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2017 v5.4.141
	 Created on:   	10/02/2017 5:57 PM
	 Created by:   	Maximo Trinidad
	 Organization: 	PutItTogether
	 Filename:    PowerShellCore_SMO_Sample.ps1 	
	===========================================================================
	.DESCRIPTION
		This script code will work in PowerShell Core 6.0 with SMO assemblies 
		only when it gets corrected.
#>

## - Next line will error the script to run in Windows PowerShell 5.x:
#Requires -Version 6

## - =============================  sample to use smo to extract data ===========================
## - For Linux and Windows -- All Good!!
# - Windows Hack:
cd 'C:\Program Files\PowerShell\6.0.0-beta.8';

# - Linux Hack:
cd SqlToolsService

## - Loading SMO Assemblies:
$Assem = ("Microsoft.SqlServer.Management.Sdk.Sfc", `
"Microsoft.SqlServer.Smo", `
"Microsoft.SqlServer.ConnectionInfo", `
"Microsoft.SqlServer.SqlEnum");
Add-Type -AssemblyName $Assem;

## - Prepare connection strings and connect to SQL Serv
$SQLServerInstanceName = 'mars,1488';
$SQLUserName = 'sa'; $sqlPwd = '$SqlPwd01!';

$SQLServerInstanceName = 'venus';
$SQLUserName = 'sa'; $sqlPwd = '$SqlPwd01!';

## - Prepare connection to SQL Server:
$SQLSrvConn = new-object Microsoft.SqlServer.Management.Common.SqlConnectionInfo($SQLServerInstanceName, $SQLUserName, $SqlPwd);
$SQLSrvObj = new-object Microsoft.SqlServer.Management.Smo.Server($SQLSrvConn);

## - SMO Get SQL Server Info:
$SQLSrvObj.Information `
| Select-Object parent, platform, product, productlevel, `
				OSVersion, Edition, version, HostPlatform, HostDistribution `
| Format-List;

## - Sample T-SQL Queries:
$SqlQuery = @"
SELECT TOP (1000) [Name]
      ,[Location]
      ,[Hire]
      ,[HireDate]
  FROM [sampledb1].[dbo].[HolidayEmployees]
"@;

$SqlQuery = "SP_WHO2"

## - Execute T-SQL Query:
[array]$result = $SQLSrvObj.Databases['master'].ExecuteWithResults($SqlQuery);
$result.tables.Rows | Select-object -first 5 $_ | Format-Table -AutoSize;


## - Export to a true CSV format file:
#-Windows
$result.tables.Rows | Select-object -first 5 $_ `
| Export-Csv -Path c:/Temp/SMO_Data2.csv -NoTypeInformation -Encoding UTF8;

#-Linux
$result.tables.Rows | Select-object -first 5 $_ `
| Export-Csv -Path /home/maxt/Temp/SMO_Data2.csv -NoTypeInformation -Encoding UTF8;

