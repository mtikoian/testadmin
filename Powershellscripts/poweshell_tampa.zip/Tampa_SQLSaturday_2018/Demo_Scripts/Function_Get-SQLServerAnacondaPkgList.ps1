﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2018 v5.5.149
	 Created on:   	2/23/2018 4:59 PM
	 Created by:   	Maximo Trinidad
	 Organization: 	SAPIEN Technologies, Inc.
	 Filename:     	Function_Get-SQLServerAnacondaPkgList.ps1
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>

function Get-SQLServerAnacondaPkgList
{
	[CmdletBinding()]
	Param (
		[string]
		$SQLServerInstallationDrive = 'C:',
		[string]
		$SQLServerInstanceName
	)
	
	$SQLServerInstallationLocation = "$($SQLServerInstallationDrive)\Program Files\Microsoft SQL Server\MSSQL14.$($SQLServerInstanceName)\PYTHON_SERVICES\conda-meta"
	$SqlAnaconda = Get-ChildItem $SQLServerInstallationLocation -File *.json;
	
	[array]$global:SqlCondaPkgList = $null;
	[array]$global:SqlCondaPkgList = foreach ($Pkg in $SqlAnaconda.name)
	{
		## - Build PSCustomObject:
		[PSCustomObject]$PkgList = New-Object PSObject -Property @{
			PackageName	    = $Pkg.Split('-')[0];
			PackageVersion  = $Pkg.Split('-')[1];
			PackageLocation  = $SQLServerInstallationLocation;
		}; $PkgList;
	};
	$global:SqlCondaPkgList;	
}

## To execute function:
$SQLServerInstallationDrive = 'C:'
$SQLServerInstanceName = "MSQL2K17A"

Get-SQLServerAnacondaPkgList -SQLServerInstallationDrive $SQLServerInstallationDrive `
							 -SQLServerInstancename $SQLServerInstanceName;

$global:SqlCondaPkgList | Select-Object PackageName, PackageVersion
