﻿
[Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo")
[int]$numOfPerfmonCollections = 3
[int]$intervalOfCollections = 2

## Counters to collect ##
$physicalcounters =  ("\Memory\Available MBytes") `
,("\PhysicalDisk(*)\Avg. Disk sec/Read")`
,("\PhysicalDisk(*)\Avg. Disk sec/Write")  `
,("\Processor(_Total)\% Processor Time") 

## SQL Counter template ([instancekey] is replaced with instance name in Get-SQLCounters Function)
$sqlCounterTemplate =  ("\[instancekey]:SQL Statistics\Batch Requests/sec") `
,("\[instancekey]:Buffer Manager\Page life expectancy")

### ********** ###
### Begin Code ###
$server = Read-Host -Prompt "Specify a server"

[string]$sysprocessQuery = @"
SELECT spid,blocked,open_tran,waittime,lastwaittype,waitresource,dbid
,cpu,physical_io,memusage,hostname
FROM master..sysprocesses p
  WHERE (spid > 50)
  	AND (blocked != 0
  	OR EXISTS(SELECT 1 from master..sysprocesses bp WHERE bp.blocked = p.spid)
	OR cpu > 250
	OR waittime > 0
	OR physical_io > 100
	)
order by spid;
"@

[string]$waitsQuery = @"
WITH Waits AS (
 SELECT wait_type,
   wait_time_ms / 1000. AS wait_time_s,
   100. * wait_time_ms / SUM(wait_time_ms) OVER() AS pct,
   ROW_NUMBER() OVER(ORDER BY wait_time_ms DESC) AS rn
 FROM sys.dm_os_wait_stats
 WHERE wait_type
   NOT IN ('CLR_SEMAPHORE', 'LAZYWRITER_SLEEP', 'RESOURCE_QUEUE',  'SLEEP_TASK', 'SLEEP_SYSTEMTASK', 'SQLTRACE_BUFFER_FLUSH', 'WAITFOR',
   'CLR_AUTO_EVENT', 'CLR_MANUAL_EVENT')   ) -- filter out additional irrelevant waits
SELECT ServerName=@@ServerName,W1.wait_type, CAST(W1.wait_time_s AS DECIMAL(12, 2)) AS wait_time_s,
 CAST(W1.pct AS DECIMAL(12, 2)) AS pct, CAST(SUM(W2.pct) AS DECIMAL(12, 2)) AS running_pct
FROM Waits AS W1
 INNER JOIN Waits AS W2 ON W2.rn <= W1.rn
GROUP BY W1.rn, W1.wait_type, W1.wait_time_s, W1.pct
HAVING SUM(W2.pct) - W1.pct < 95; -- percentage threshold;
"@

# Check for the server online
if(Test-Connection -ComputerName $server -Count 2){
	Write-Host "$server pinged successfully"
} else {
	Write-Host "$server could not be pinged!"
	break;
}

#Grab SQL Services
$SQLServices = Get-WmiObject -ComputerName $server win32_service |
				Where-Object {$_.name -like "*SQL*" } |
				Select-Object Name,StartMode,State,Status
 
 if($SQLServices.Count -gt 0) {
		$SQLServices | Out-GridView -Title "$server SQL Services Information"
	}

[array]$sqlCounters = $null
[array]$sqlWaits = $null

# Grab OS counters and add to SQL Counter array for single grid output.
Write-Host "Reading OS Perf Counters...."
try{
	Get-Counter -Counter $physicalcounters `
	-MaxSamples $numOfPerfmonCollections -SampleInterval $intervalOfCollections |
	ForEach-Object {$_.CounterSamples | Select-Object @{Label="Server";Expression={$_.Path.Substring(2,($_.Path.IndexOf("\",2)-2))} },
	@{Label="PerfCategory";Expression={$_.Path.Substring(($_.Path.IndexOf("\",2)+1),($_.Path.LastIndexOf("\")+1)-(($_.Path.IndexOf("\\",2))+3) )}},
	@{Label="PerfCounter";Expression={$_.Path.Substring(($_.Path.LastIndexOf("\")+1),($_.Path.Length - ($_.Path.LastIndexOf("\")+1)))}},
	CookedValue,Timestamp
	} | Out-GridView -Title "$server Counters"
} catch {
	Write-Host "Problem Reading Perf Counters" + $Error
}

# Check each SQL Service (not Agent, etc) gather information
Foreach($sqlService in $SQLServices |
		Where-Object{$_.name -like "MSSQL$*" -or $_.name -eq "MSSQLSERVER"} |
		Where-Object{$_.State -eq "Running"  } )
{
	[string]$sqlServerName = $sqlService.Name
	$sqlServerName = $sqlServerName.Replace("MSSQL$","$server\")
	$sqlServerName = $sqlServerName.Replace("MSSQLSERVER","$server")

	Write-host "Checking $sqlServerName"
	#$sqlServer = New-Object("Microsoft.SqlServer.Management.Smo.Server") $sqlServerName

# Grab any blocking processes
	try{
	    $tmpBlocks= Invoke-Sqlcmd3 -Query $sysprocessQuery -SQLServerName $sqlServerName 
		if($tmpBlocks.Count -ge 1) {$blocks += $tmpBlocks}
	}
	catch{
		Write-Host "Problem Reading SysProcesses" + $Error
	}

# Grab waits
	try{
		$sqlversion = Invoke-Sqlcmd3 -Query "SELECT serverproperty('ProductVersion')" -SQLServerName $sqlServerName
		$version = $sqlversion.Column1.ToString();
		[int]$versionNumber = [int]$version.Substring(0,$version.IndexOf("."));
		
		if($versionNumber -ge 10)	{
			$sqlWaits += Invoke-Sqlcmd3 -Query $waitsQuery -SQLServerName $sqlServerName
		}
		}
	catch{
		Write-Host "Problem Reading Waits" + $Error
		}

# Get SQL Instance specific counter array and build up array $sqlCounters to store for all instances
	try{
		$sqlInstanceCounters = Get-SQLCounters -SQLServerToMonitor $sqlServerName -counters $sqlCounterTemplate
	} catch {
		Write-Host "Error Building SQL Counter Template $_"
	}

	try{
		$sqlCounters += Get-Counter -Counter $sqlInstanceCounters `
		-MaxSamples $numOfPerfmonCollections -SampleInterval $intervalOfCollections
	} catch {
		Write-Host "Error getting SQL Counters $_"
	}
} # end of SQL instances loop

#Blocking
$blocks | Out-GridView -Title "$sqlServerName Blocked Processes"

# Push Waits
$sqlWaits | Out-GridView -Title "SQL Server Waits"

# Push counters to grid
$sqlCounters | ForEach-Object{ $_.CounterSamples | 
	Select-Object  @{Label="Server";Expression={$_.Path.Substring(2,($_.Path.IndexOf("\",2)-2))} },
	@{Label="PerfCategory";Expression={$_.Path.Substring(($_.Path.IndexOf("\",2)+1),($_.Path.LastIndexOf("\"))-(($_.Path.IndexOf("\",2))+1) )}},
	@{Label="PerfCounter";Expression={$_.Path.Substring(($_.Path.LastIndexOf("\")+1),($_.Path.Length - ($_.Path.LastIndexOf("\")+1)))}},
	CookedValue,Timestamp } |
	Out-GridView -Title "$server SQL Counters"