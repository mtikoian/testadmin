﻿
$voice = New-Object -ComObject SAPI.SPVoice
  $voice.Rate = -4
  function invoke-speech
  {
      param([Parameter(ValueFromPipeline=$true)][string] $say )
      process
      {
         $voice.Speak($say) | out-null;   
     }
 }
 
 if(!(Test-Path alias:\out-voice)){
     new-alias -name out-voice -value invoke-speech;
}   

[array]$quotes = @("I find your lack of faith disturbing"
    ,"Use the Force, Luke"
    ,"You don’t need to see his identification … These aren’t the droids you’re looking for … He can go about his business … Move along."
    ,"Help me Obi-Wan Kenobi. You’re my only hope"
    ,"May the Force be with you"
    ,"When I left you, I was but the learner, now I am the master"
    ,"Only a master of evil, Darth"
	,"Aren't you a little short for a stormtrooper"
	)

$random = New-Object  System.Random

$quotes[$random.next(0,$quotes.Length)] | out-voice