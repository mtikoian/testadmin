﻿[DSCLocalConfigurationManager()]
Configuration LCMUpdate
{
   Node localhost
   {
      Settings
      {
         AllowModuleOverwrite = $True
         ConfigurationMode = 'ApplyAndMonitor'
         ConfigurationModeFrequencyMins = '15'
         RefreshMode = 'Push'
         RebootNodeIfNeeded = $True
         ActionAfterReboot = 'ContinueConfiguration'     
      }
   }
}

LCMUpdate -OutputPath 'C:\users\tim.COMPANY\Desktop\SQLServer'

Set-DscLocalConfigurationManager -ComputerName localhost -Path 'C:\users\tim.COMPANY\Desktop\SQLServer'