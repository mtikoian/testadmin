﻿# What are the DSC commands?
Get-Command -Module PSDesiredStateConfiguration

# What are the local LCM settings?
Get-DscLocalConfigurationManager

# Does the system config match its desired state configuration?
Test-DscConfiguration 

# Does the system have a DSC configuration?
Get-DscConfigurationStatus

# What is the system's desired state configuration?
Get-DscConfiguration

# Remove a configuration document
Remove-DscConfigurationDocument -Stage Current -Force



