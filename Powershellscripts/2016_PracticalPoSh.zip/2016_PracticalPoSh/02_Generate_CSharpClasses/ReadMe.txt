Based on my answer to this StackOverflow post
http://stackoverflow.com/questions/5873170/generate-class-from-database-table