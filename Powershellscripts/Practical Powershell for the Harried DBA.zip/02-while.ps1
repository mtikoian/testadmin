﻿$i = 10;

while( $i -gt 0 ) {
   $i;
   $i--;
   start-sleep -milliseconds 250;
}
'Boom!';
