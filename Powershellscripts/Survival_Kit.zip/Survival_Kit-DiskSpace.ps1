﻿<#
.SYNOPSIS
   Checks Disk Freespace on a list of servers to verify if they're above 5%
.DESCRIPTION
   This script will accept a text file list of physical servers and 
   then check freespace on all volumes.  If any volumes are less than
   5%, those volumes will be listed in a report and sent via email.

.PARAMETER <paramName>
   srvlist - file containing server names

.EXAMPLE
   .\Survival_Kit-DiskSpace -servers ServerList.txt
#>
param([parameter(Mandatory=$true)][string] $servers)

$srvlist = Get-Content $servers
$srvlist=("localhost")
$report=@()


foreach ($server in $srvlist)
{
	$output=gwmi win32_volume -computername $server  | where {$_.drivetype -eq 3 -and $_.name -notlike "\\*"} | Sort-Object name `
            | select name,@{l="Size_GB";e={($_.capacity/1gb).ToString("F2")}},@{l="FreeSpace_GB";e={($_.freespace/1gb).ToString("F2")}},@{l="PercentFree";e={(($_.Freespace/$_.Capacity)*100).ToString("F2")}}

    $output | Add-Member -type NoteProperty -name HostName $server
    $report+=$output
}
#Set these for your environment
$smtp="yourmail.server.com"
$from="SvcAlert@yourserver.com"
$to="You@yourcompany.com"

if(($report | where {$_.PercentFree -lt 5}).Length -gt 0)
{
	[string]$body=$report|where{$_.PercentFree -lt 5}| ConvertTo-HTML
	Send-MailMessage -To $to -from $from -subject "Low Freespace Alert!" -smtpserver $smtp -body $body -BodyAsHtml
}