﻿
Add-Type -AssemblyName "Microsoft.SqlServer.Smo, Version=11.0.0.0, Culture=neutral, PublicKeyToken=89845dcd8080cc91"
Add-Type -AssemblyName "Microsoft.SqlServer.SMOExtended, Version=11.0.0.0, Culture=neutral, PublicKeyToken=89845dcd8080cc91"

$server = New-Object -TypeName Microsoft.SqlServer.Management.Smo.Server -ArgumentList "Localhost\i12"

$initfields = $server.GetDefaultInitFields([Microsoft.Sqlserver.Management.Smo.Column])
#$initfields

[void]$initfields.Add("DataType")
[void]$server.SetDefaultInitFields([Microsoft.SqlServer.Management.Smo.Column], $initfields)

$db = $server.Databases["SMO_DB1"]
$table = $db.Tables["Table1"]
$column = $table.Columns["id"]
$column.DataType

#$columns = $table.Columns
#$columns[0].DataType



<#
# These are for you to fish.
$server.Databases["DemoDB"].Tables["Customer"].HasCompressedPartitions
$server.Databases["DemoDB"].Tables["Customer"].CreateDate
$server.Databases["DemoDB"].Tables["Customer"].ChangeTrackingEnabled
$server.Databases["DemoDB"].Tables["Customer"].AnsiNullsStatus
$server.Databases["DemoDB"].Tables["Customer"].Checks # not included when CreateDate used
$server.Databases["DemoDB"].Tables["Customer"].DataSpaceUsed # retrieved
$server.Databases["DemoDB"].Tables["Customer"].DateLastModified
$server.Databases["DemoDB"].Tables["Customer"].DistributionName
$server.Databases["DemoDB"].Tables["Customer"].FileGroup
$server.Databases["DemoDB"].Tables["Customer"].ForeignKeys #retrieved
$server.Databases["DemoDB"].Tables["Customer"].HasAfterTrigger
$server.Databases["DemoDB"].Tables["Customer"].HasClusteredIndex
$server.Databases["DemoDB"].Tables["Customer"].HasDeleteTrigger
$server.Databases["DemoDB"].Tables["Customer"].HasIndex
$server.Databases["DemoDB"].Tables["Customer"].HasUpdateTrigger
$server.Databases["DemoDB"].Tables["Customer"].ID
$server.Databases["DemoDB"].Tables["Customer"].IsSystemObject
$server.Databases["DemoDB"].Tables["Customer"].IndexSpaceUsed #retrieved
$server.Databases["DemoDB"].Tables["Customer"].IsFileTable
$server.Databases["DemoDB"].Tables["Customer"].IsVarDecimalStorageFormatEnabled #retrieved
$server.Databases["DemoDB"].Tables["Customer"].MaximumDegreeOfParallelism
$server.Databases["DemoDB"].Tables["Customer"].TrackColumnsUpdatedEnabled
$server.Databases["DemoDB"].Tables["Customer"].Triggers #retrieved


#>