﻿Add-Type -AssemblyName "Microsoft.SqlServer.Smo, Version=11.0.0.0, Culture=neutral, PublicKeyToken=89845dcd8080cc91"
Add-Type -AssemblyName "Microsoft.SqlServer.SMOExtended, Version=11.0.0.0, Culture=neutral, PublicKeyToken=89845dcd8080cc91"

$server = New-Object -TypeName Microsoft.SqlServer.Management.Smo.Server -ArgumentList "Localhost\i12"

$db = $server.Databases["SMO_DB1"]

# Get this one by virtue
$db.Name
# Not retrieved so it will pull it
$db.ID

# Will not retrieve it again
$db.ID

# Did not retrieve this yet
$db.Size

# Will not retrieve it again
$db.Size

# Will not retrive this because it was retrieved with ID
$db.RecoveryModel

# Change the RecoveryModel and still see this
$db.RecoveryModel

$db.Refresh()

# Now let's see
$db.RecoveryModel

