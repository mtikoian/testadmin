
Add-Type -AssemblyName "Microsoft.SqlServer.Smo, Version=11.0.0.0, Culture=neutral, PublicKeyToken=89845dcd8080cc91"
Add-Type -AssemblyName "Microsoft.SqlServer.SMOExtended, Version=11.0.0.0, Culture=neutral, PublicKeyToken=89845dcd8080cc91"

$server = New-Object -TypeName Microsoft.SqlServer.Management.Smo.Server -ArgumentList "Localhost\i12"

$server.Name

$db = $server.Databases["SMO_DB1"]
$db.Name
$db.Size

# Watch what happens when you go after the ID
$db.ID
$db.Owner
$db.PageVerify
$db.CompatibilityLevel
