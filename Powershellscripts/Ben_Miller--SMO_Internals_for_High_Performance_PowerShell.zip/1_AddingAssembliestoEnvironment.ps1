﻿# Old way, you should not use this any longer
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo")

# New way - Kind of
Add-Type -AssemblyName "Microsoft.SqlServer.Smo"

# New way - Right way - Specific
Add-Type -AssemblyName "Microsoft.SqlServer.Smo, Version=11.0.0.0, Culture=neutral, PublicKeyToken=89845dcd8080cc91"
Add-Type -AssemblyName "Microsoft.SqlServer.SMOExtended, Version=11.0.0.0, Culture=neutral, PublicKeyToken=89845dcd8080cc91"
