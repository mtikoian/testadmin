﻿$server = Get-Item SQLSERVER:\sql\localhost\i12
$initfields = $server.GetDefaultInitFields([Microsoft.Sqlserver.Management.Smo.Column])
$initfields.Add("DataType")
$server.SetDefaultInitFields([Microsoft.SqlServer.Management.Smo.Column], $initfields)

$db = $server.Databases["Demo"]
$table = $db.Tables["PartitionedTable"]
$column = $table.Columns["id"]
$columns = $table.Columns
$columns[0].DataType

$column.DataType
$server.Databases["DemoDB"].Tables["Customer"].HasCompressedPartitions
$server.Databases["DemoDB"].Tables["Customer"].CreateDate
$server.Databases["DemoDB"].Tables["Customer"].ChangeTrackingEnabled
$server.Databases["DemoDB"].Tables["Customer"].AnsiNullsStatus
$server.Databases["DemoDB"].Tables["Customer"].Checks # not included when CreateDate used
$server.Databases["DemoDB"].Tables["Customer"].DataSpaceUsed # retrieved
$server.Databases["DemoDB"].Tables["Customer"].DateLastModified
$server.Databases["DemoDB"].Tables["Customer"].DistributionName
$server.Databases["DemoDB"].Tables["Customer"].FileGroup
$server.Databases["DemoDB"].Tables["Customer"].ForeignKeys #retrieved
$server.Databases["DemoDB"].Tables["Customer"].HasAfterTrigger
$server.Databases["DemoDB"].Tables["Customer"].HasClusteredIndex
$server.Databases["DemoDB"].Tables["Customer"].HasDeleteTrigger
$server.Databases["DemoDB"].Tables["Customer"].HasIndex
$server.Databases["DemoDB"].Tables["Customer"].HasUpdateTrigger
$server.Databases["DemoDB"].Tables["Customer"].ID
$server.Databases["DemoDB"].Tables["Customer"].IsSystemObject
$server.Databases["DemoDB"].Tables["Customer"].IndexSpaceUsed #retrieved
$server.Databases["DemoDB"].Tables["Customer"].IsFileTable
$server.Databases["DemoDB"].Tables["Customer"].IsVarDecimalStorageFormatEnabled #retrieved
$server.Databases["DemoDB"].Tables["Customer"].MaximumDegreeOfParallelism
$server.Databases["DemoDB"].Tables["Customer"].TrackColumnsUpdatedEnabled
$server.Databases["DemoDB"].Tables["Customer"].Triggers #retrieved

















