<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2016 v5.2.117
	 Created on:   	7/29/2016 4:02 PM
	 Created by:   	Ben
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>
Function Get-SqlLogVlfCount
{
	param ($ServerInstance,
		$Database)
	
	$results = "" | Select ServerInstance, Database, Count
	
	$results.ServerInstance = $ServerInstance
	$results.Database = $Database
	
	$smo = "Microsoft.SqlServer.Management.Smo"
	$server = New-Object -TypeName "$smo.Server" -ArgumentList $ServerInstance
	$db = $server.Databases[$Database]
	if ($db -ne $null)
	{
		try
		{
			$ds = $db.ExecuteWithResults("DBCC LOGINFO")
			if ($ds.Tables.Count -gt 0)
			{
				$results.Count = $ds.Tables[0].Rows.Count
			}
			else 
			{
				$results.Count = -1
			}
		}
		catch
		{
			$results.Count = -1
		}
	}
	
	return $results
}

function Get-SqlLogInfo
{
	param (
		$ServerInstance,
		$Database,
		$UserId,
		$Password
	)
	
	$loginfo = "" | select ServerName, Database, FileId, Filename, Size, PhysicalName, VLFCount
	
	$results = @()
	
	$smo = "Microsoft.SqlServer.Management.Smo"
	$server = New-Object -TypeName "$smo.Server" -Args $ServerInstance
	if ($UserId -ne $null)
	{
		$server.ConnectionContext.LoginSecure = $false
		$server.ConnectionContext.Login = $UserId
		$server.ConnectionContext.Password = $Password
	}
	
	$db = $server.Databases[$Database]
	foreach ($log in $db.LogFiles)
	{
		$loginfo = "" | select ServerName, Database, FileId, Filename, Size, PhysicalName, VLFCount
		
		$loginfo.ServerName = $server.Name
		$loginfo.Database = $db.Name
		$loginfo.FileId = $log.ID
		$loginfo.FileName = $log.Name
		$loginfo.Size = $log.Size/1KB
		$loginfo.PhysicalName = $log.FileName
		$vlf = Get-SqlLogVlfCount -ServerInstance $ServerInstance -Database $Database 
		$loginfo.VLFCount = $vlf.Count
		
		$results += $loginfo
	}
	
	return $results
}
