##Stolen/Adapted from http://www.erichumphrey.com/wp-content/uploads/2011/03/Add-SqlServerStartupParameter.ps1
#Using Remoting for remote runs example:
#
#
#$sql_boxen = Get-Content \\scfs1\it\dba\txt\2013-02-07_HEQ_SQL-Servers.txt
#
#Create PowerShell Remoting Sessions
#$sql_sessions = [ordered]@{} ; foreach ($server in $sql_boxen) {$server; $sql_sessions += @{$server = (New-PSSession $server) } } ; $sql_sessions.values
#
#Run script against each ID in hash table to Get Current Startup Parameters
#foreach ($server in $sql_boxen) {$server; Invoke-Command -Session (Get-PSSession $sql_sessions.$server.Id) -FilePath \\scfs1\IT\DBA\PowerShell\Get-SqlServerStartupParameters.ps1 }
#
#
#
#
$hklmRootNode = "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server"

$props = Get-ItemProperty "$hklmRootNode\Instance Names\SQL"
$instances = $props.psobject.properties | ?{$_.Value -like 'MSSQL*'} | select Value

$instances | foreach {
    $inst = $_.Value;
    $regKey = "$hklmRootNode\$inst\MSSQLServer\Parameters"
    $props = Get-ItemProperty $regKey
    $params = $props.psobject.properties | ?{$_.Name -like 'SQLArg*'} | select Name, Value
    $params | ft -AutoSize
    $hasFlag = $false
}