﻿Start-Transcript -Path

Import-Module SqlServer

# Lets see which one loaded
Get-Module

# Lets see which modules are available
Get-Module -ListAvailable SqlServer

# Notice that there are multiple modules and they
# are listed in the order that they would load.
# You MUST make sure that your environments are
# set up like you want them. The install order
# and where they place the modules could
# be conflicting
# You could use the -MinimumVersion to get past the 1.0
Remove-Module SqlServer
Import-Module -Name SqlServer -MinimumVersion 2.0
Get-Module

# You could use the full path of the module
Import-Module -Name "C:\Program Files\WindowsPowerShell\Modules\SqlServer"

# Lastly you can get the module you want in a variable
# and load it specifically
$modules = Get-Module -ListAvailable SqlServer | Select -Last 1
Import-Module $modules

# Notice that you can see a SqlServer Script 0.0 version
# Using a required version you would miss that one


# Show the HKLM provider
cd HKLM:
dir

CD Software\Microsoft
dir

