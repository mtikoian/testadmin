﻿# Now let's see how you can use it

# First look at how you can interact without
# typing the paths in.
$SqlServer = "DEMOVM"
$Instance = "S16" # if it is a default instance use DEFAULT
$Database = "imoltp"

test-path "SQLSERVER:\SQL\$SqlServer\$Instance\Databases\$Database"

dir "$SqlServer\$Instance\Databases\$Database\Tables" | foreach { $_.Script(); }

dir "SQLSERVER:\SQL\$SqlServer\$Instance\Databases\$Database\Tables" | foreach { $_.Script() | Add-Content "c:\Demos\TSQL\$($_.Schema)_$($_.Name).sql" }

# Let me explain
# Setting variables up to hold information needed
# Then using string substitution for getting
# the path set up.
# Using dir and the pipeline to script out the 
# tables using Script() out to files with schema name
# and table name to get the data.
#
# All the variables are used to build a string
# used by PowerShell to form a Path
# This path is used to navigate the Provider

# One thing to remember about the Provider
CD SQLSERVER:\SQL\DEMOVM\S16\Databases\imoltp\Tables\dbo.DiskbasedTable

# you must specify the Schema.TableName to be in the Path
# Schema is not a first class citizen as a container like
# Databases.

dir
