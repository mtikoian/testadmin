<#
.SYNOPSIS
   This script will return a statistics object for the TableName on the SqlServer specified.
.DESCRIPTION
   The output of this script allows you to find out about the stats.
.PARAMETER SqlServer
.PARAMETER DBName
.PARAMETER TableName
.PARAMETER OutputCommands
.PARAMETER NoRecompute
	
.EXAMPLE
   You call it like this:
   Get-SqlStatisticsByTable -SqlServer server\s01 -TableName MyTable
   
#>
Function Get-SqlStatisticsByTable {
param (
	[string]$sqlserver,
	[string]$DBName,
	[string]$TableName,
    [string]$Schema ='dbo',
	[switch]$OutputCommands,
	[switch]$NoRecompute
)

$sb = New-Object -TypeName System.Text.StringBuilder
$db = Get-SqlDatabase $sqlserver $DBName
$table = $db.Tables.get_Item($TableName, $Schema)

$outputs = @()
$hash = @{}
$results = $null

foreach($index in $table.Indexes) {
	#if(!$OutputCommands) {
		$stats = $index.EnumStatistics()
	#}
	$hash.Add($index.Name, $true)
	foreach($stat in $stats) {
		$tbl = $stat.Tables[0]
		if($results) {
			$results.ImportRow($tbl.Rows[0])
		}
		else {
			$results = $tbl.Copy()				
		}
		if($OutputCommands) {
			[void]$sb.Append("UPDATE STATISTICS [$TableName] [$($index.Name)] WITH FULLSCAN")
			
			if($NoRecompute) {
				[void]$sb.Append(", NORECOMPUTE")
			}
			[void]$sb.Append("`r`nGO`r`n")
		}

		#if($tbl.Rows[0]["Rows"] -ne $tbl.Rows[0]["Rows Sampled"]) {
		#	Write-Output "Not-Equal: $($index.Name) - Update: $($tbl.Rows[0]['Updated']) - Rows: $($tbl.Rows[0]['Rows']) - Sampled: $($tbl.Rows[0]['Rows Sampled'])"
		#}
		#else {
		#	Write-Output "Equal-$($index.Name) - Update: $($tbl.Rows[0]['Updated']) - Rows: $($tbl.Rows[0]['Rows']) - Sampled: $($tbl.Rows[0]['Rows Sampled'])"
		#}
	}
}
$statistic = $table.EnumLastStatisticsUpdates()
if($statistic) {
	foreach($row in $statistic) {
		if(!$hash.ContainsKey($row.Name)) {
			$exec = $db.ExecuteWithResults("DBCC SHOW_STATISTICS('$($table.Name)', '$($row.Name)') WITH STAT_HEADER")
			if($results) {
				$results.ImportRow($exec.Tables[0].Rows[0])
			}
			else {
				$results = $exec.Tables[0].Copy()				
			}
			if($OutputCommands) {
				[void]$sb.Append("UPDATE STATISTICS [$tableName] [$($row.Name)] WITH FULLSCAN")

				if($NoRecompute) {
					[void]$sb.Append(", NORECOMPUTE")
				}
				[void]$sb.Append("`r`nGO`r`n")
			}

		}
	}
}
	#$results.AcceptChanges()
	
	if($OutputCommands) {
		$sb.ToString()
	}
	else {
		$results | Select *, @{Label="UpdateDate";Expression={[DateTime]$_.Updated}}
	}	
}

