<#	

#>
#Add-Type -AssemblyName "Microsoft.SqlServer.Smo, Version=11.0.0.0, Culture=neutral, PublicKeyToken=89845dcd8080cc91"
#Add-Type -AssemblyName "Microsoft.SqlServer.SmoExtended, Version=11.0.0.0, Culture=neutral, PublicKeyToken=89845dcd8080cc91"

function Get-SqlExposeIndexColumns
{
	param ($SqlIndex, $SqlClKeys, $ClFound)
	
	$nclKeys = @()
	$nclInclude = @()
	$colsintree = @()
	$colsinleaf = @()
	
	$description = $index_keys = $included_columns = $columns_in_tree = $columns_in_leaf = ""
	
	# Get Keys and Includes
	foreach ($column in $SqlIndex.IndexedColumns)
	{
		if ($column.IsIncluded)
		{
			$nclInclude += $column.Name
		}
		else
		{
			$nclKeys += $column.Name
		}
	}
	# Get ColsInTree
	if ($SqlIndex.IsUnique -and $ClFound)
	{
		foreach ($key in $nclKeys)
		{
			$colsintree += $key
		}
	}
	else
	{
		foreach ($key in $nclKeys)
		{
			$colsintree += $key
		}
		foreach ($key in $SqlClKeys)
		{
			if (!$colsintree.Contains($key))
			{
				$colsintree += $key
			}
		}
	}
	# Get ColsInLeaf
	$colsinleaf = $colsintree.Clone()
	
	foreach ($key in $nclInclude)
	{
		if (!$colsinleaf.Contains($key))
		{
			$colsinleaf += $key
		}
	}
	foreach ($key in $SqlClKeys)
	{
		if (!$colsinleaf.Contains($key))
		{
			$colsinleaf += $key
		}
	}
	
	$obj = "" | select index_id, is_disabled, index_name, index_description, index_keys, included_columns, filter_definition, columns_in_tree, columns_in_leaf, size_in_kb, has_compression
	$obj.index_id = $SqlIndex.ID
	$obj.is_disabled = $SqlIndex.IsDisabled
	$obj.index_name = $SqlIndex.Name
	$obj.filter_definition = $SqlIndex.FilterDefinition
	$obj.included_columns = ""
	$obj.index_keys = ""
	$obj.size_in_kb = "$($SqlIndex.SpaceUsed.ToString('N0')) KB, $(($SqlIndex.SpaceUsed/1KB).ToString('N2')) MB"
	$obj.has_compression = $SqlIndex.HasCompressedPartitions
	
	foreach ($key in $colsintree)
	{
		$obj.columns_in_tree = "$($obj.columns_in_tree), [$key]"
	}
	foreach ($key in $colsinleaf)
	{
		$obj.columns_in_leaf = "$($obj.columns_in_leaf), [$key]"
	}
	foreach ($key in $nclInclude)
	{
		$obj.included_columns = "$($obj.included_columns), [$key]"
	}
	foreach ($key in $nclKeys)
	{
		$obj.index_keys = "$($obj.index_keys), [$key]"
	}
	
	# Get the description
	if ($SqlIndex.IsClustered)
	{
		$obj.index_description = "clustered"
	}
	else
	{
		$obj.index_description = "nonclustered"
	}
	if ($SqlIndex.IndexType -eq "NonClusteredColumnStoreIndex")
	{
		$obj.index_keys = "n/a, see columns_in_leaf for details"
		$obj.included_columns = "n/a, columnstore index"
		$obj.filter_definition = "n/a, columnstore index"
		$obj.columns_in_tree = "n/a, columnstore index"
		if ($ClFound)
		{
			$obj.columns_in_leaf = "Columns with column-based index: $($obj.columns_in_leaf.SubString(2))"
		}
		else
		{
			$obj.columns_in_leaf = ""
		}
		$obj.index_description += " columnstore"
	}
	if ($SqlIndex.IgnoreDuplicateKeys)
	{
		$obj.index_description += ", ignore duplicate keys"
	}
	if ($SqlIndex.IsUnique)
	{
		$obj.index_description += ", unique"
	}
	if ($SqlIndex.IndexKeyType -eq "DriPrimaryKey")
	{
		$obj.index_description += ", primary key"
	}
	if ($SqlIndex.IndexKeyType -eq "DriUniqueKey")
	{
		$obj.index_description += ", unique key"
	}
	$obj.index_description += " located on $($SqlIndex.FileGroup)"
	
	if ($obj.index_keys.StartsWith(","))
	{
		$obj.index_keys = $obj.index_keys.SubString(2)
	}
	if ($obj.included_columns.StartsWith(","))
	{
		$obj.included_columns = $obj.included_columns.SubString(2)
	}
	if ($obj.columns_in_tree.StartsWith(","))
	{
		$obj.columns_in_tree = $obj.columns_in_tree.SubString(2)
	}
	if ($obj.columns_in_leaf.StartsWith(","))
	{
		$obj.columns_in_leaf = $obj.columns_in_leaf.Substring(2)
	}
	
	Write-Output $obj
}

function Get-SqlHelpIndex
{
	param ($ServerInstance, $DatabaseName, $TableName, $SchemaName = 'dbo', $Username, $Password)
	
	$found = $false
	$CLKeys = @()
	$description = $index_keys = $included_columns = $columns_in_tree = $columns_in_leaf = ""
	
	try
	{
		if($ServerInstance.GetType().Name -eq "Server") {
			$server = $ServerInstance
		}
		else {
			$server = New-Object -TypeName Microsoft.SqlServer.Management.Smo.Server -Args $ServerInstance
		}
		if($Username -ne $null) {
			$server.ConnectionContext.LoginSecure = $false
			$server.ConnectionContext.set_Login($Username)
			$server.ConnectionContext.set_Password($Password)
		}

		$fields = $server.GetDefaultInitFields([Microsoft.SqlServer.Management.Smo.Index])
		[void]$fields.Add("IsUnique")
		[void]$fields.Add("ID")
		[void]$fields.Add("IsDisabled")
		[void]$fields.Add("Name")
		[void]$fields.Add("FilterDefinition")
		[void]$fields.Add("IsClustered")
		[void]$fields.Add("IndexType")
		[void]$fields.Add("IndexKeyType")
		[void]$fields.Add("IgnoreDuplicateKeys")
		[void]$fields.Add("FileGroup")
		[void]$fields.Add("HasCompressedPartitions")
		
		$server.SetDefaultInitFields([Microsoft.SqlServer.Management.Smo.Index], $fields)
		
		$fields.Clear()
		[void]$fields.Add("IsIncluded")
		[void]$fields.Add("ID")
		
		$server.SetDefaultInitFields([Microsoft.SqlServer.Management.Smo.IndexedColumn], $fields)
		
		$db = $server.Databases["$DatabaseName"]
		$table = $db.Tables.Get_Item($TableName, $SchemaName)
	}
	catch
	{
		Write-Output "Error connecting to $ServerInstance"
		Write-Output $_.Exception.Message
	}

	if (!$table.ID)
	{
		Write-Output "Table [$SchemaName].[$TableName] does not exist in Database: $DatabaseName on Server: $ServerInstance"
		break
	}

	foreach ($index in ($table.Indexes | Sort ID))
	{
		if ($index.IsClustered)
		{
			$SqlClIndex = $index
			$found = $true
			break
		}
	}
	if (!$found)
	{
		$CLKeys += "RID"
	}
	
	$obj = "" | select index_id, is_disabled, index_name, index_description, index_keys, included_columns, filter_definition, columns_in_tree, columns_in_leaf, size_in_kb, has_compression
	
	if ($found)
	{
		
		foreach ($column in $SqlClIndex.IndexedColumns)
		{
			$index_keys += ", [$($column.Name)]"
			$ClKeys += $column.Name
		}
		if (!$SqlClIndex.IsUnique)
		{
			$CLKeys += "UNIQUIFIER"
		}
		
		if ($SqlClIndex.IsClustered)
		{
			$description = "clustered"
		}
		else
		{
			$description = "nonclustered"
		}
		if ($SqlClIndex.IndexType -eq "NonClusteredColumnStoreIndex")
		{
			$description += " columnstore"
		}
		$columns_in_tree = $index_keys
		
		if ($SqlClIndex.IgnoreDuplicateKeys)
		{
			$description += ", ignore duplicate keys"
		}

		if ($SqlClIndex.IsUnique)
		{
			$columns_in_leaf = 'All columns "included" - the leaf level IS the data row'
			$description += ", unique"
		}
		else
		{
			$columns_in_tree += ", UNIQUIFIER"
			$columns_in_leaf = 'All columns "included" - the leaf level IS the data row, plus the UNIQUIFIER'
		}
		if ($SqlClIndex.IndexKeyType -eq "DriPrimaryKey")
		{
			$description += ", primary key"
		}
		if ($SqlClIndex.IndexKeyType -eq "DriUniqueKey")
		{
			$description += ", unique key"
		}
		$description += " located on $($SqlClIndex.FileGroup)"
		
		$obj.index_id = $SqlClIndex.ID
		$obj.is_disabled = $SqlClIndex.IsDisabled
		
		$obj.index_name = $SqlClIndex.Name
		$obj.index_description = $description
		if ($index_keys.StartsWith(","))
		{
			$obj.index_keys = $index_keys.SubString(2)
		}
		else
		{
			$obj.index_keys = $index_keys
		}
		
		$obj.included_columns = ""
		$obj.filter_definition = $SqlClIndex.FilterDefinition
		if ($columns_in_tree.StartsWith(","))
		{
			$obj.columns_in_tree = $columns_in_tree.SubString(2)
		}
		else
		{
			$obj.columns_in_tree = $columns_in_tree
		}
		if ($columns_in_leaf.StartsWith(","))
		{
			$obj.columns_in_leaf = $columns_in_leaf.Substring(2)
		}
		else
		{
			$obj.columns_in_leaf = $columns_in_leaf
		}
		$obj.size_in_kb = "$($SqlClIndex.SpaceUsed.ToString('N0')) KB, $(($SqlClIndex.SpaceUsed/1KB).ToString('N2')) MB"
		$obj.has_compression = $SqlClIndex.HasCompressedPartitions

		$obj
	}
	
	
	foreach ($index in ($table.Indexes | where { $_.ID -eq 0 -or $_.ID -gt 1 } | sort ID))
	{
		$obj = Get-SqlExposeIndexColumns $index $ClKeys $found
		
		Write-Output $obj
	}
	# Check for the existence of the Table, if not then send a friendly error and exit.
	
	<#
	i.index_id, i.[type], i.data_space_id, QUOTENAME(i.name, N']') AS name,
			i.ignore_dup_key, i.is_unique, i.is_hypothetical, i.is_primary_key, i.is_unique_constraint,
			s.auto_created, s.no_recompute, i.filter_definition, i.is_disabled
	
		-- create temp tables
	CREATE TABLE #spindtab
	(
		index_name			sysname	collate database_default NOT NULL,
		index_id			int,
		[type]				tinyint,
		ignore_dup_key		bit,
		is_unique			bit,
		is_hypothetical		bit,
		is_primary_key		bit,
		is_unique_key		bit,
		is_disabled         bit,
		auto_created		bit,
		no_recompute		bit,
		groupname			sysname collate database_default NULL,
		index_keys			nvarchar(2126)	collate database_default NULL, -- see @keys above for length descr
		filter_definition	nvarchar(max),
		inc_Count			smallint,
		inc_columns			nvarchar(max),
		cols_in_tree		nvarchar(2126),
		cols_in_leaf		nvarchar(max)
	)

	CREATE TABLE #IncludedColumns
	(	RowNumber	smallint,
		[Name]	nvarchar(128)
	)
	
	#>
	
	# foreach index.
	# Get the Keys of the index with their descending flag (-)
	# Get all Included columns
	
	# If index is Clustered and non-unique
	#    @ColsInTree = @keys + N', UNIQUIFIER', @ColsInLeaf = N'All columns "included" - the leaf level IS the data row, plus the UNIQUIFIER'
	# If index is Clustered and unique
	#    @ColsInTree = @keys, @ColsInLeaf = N'All columns "included" - the leaf level IS the data row.'
	# If index is non-clustered and there IS a clustered index
	#    Call ExposeColsInIndex
	# If index is non-clustered and non-unique and the clustered index is NON unique
	# 	 @ColsInTree = @ColsInTree + N', UNIQUIFIER', @ColsInLeaf = @ColsInLeaf + N', UNIQUIFIER'
	# If index is non-clustered and unique and the clustered index is NON unique
	# 	 @ColsInLeaf = @ColsInLeaf + N', UNIQUIFIER'
	# If index is non-clustered and we are in a HEAP
	#    If non-unique key
	# 		SELECT @ColsInTree = @keys + N', RID'
	#			, @ColsInLeaf = @keys + N', RID' + CASE WHEN @inc_columns IS NOT NULL THEN N', ' + @inc_columns ELSE N'' END
	#    Else
	# 		SELECT @ColsInTree = @keys
	#			, @ColsInLeaf = @keys + N', RID' + CASE WHEN @inc_columns IS NOT NULL THEN N', ' + @inc_columns ELSE N'' END
	
	# Finally this is the return
	<#
		select
		'index_id' = index_id,
							  'is_disabled' = is_disabled,
							  'index_name' = index_name,
							  'index_description' = convert(varchar(210), --bits 16 off, 1, 2, 16777216 on, located on group
		case when index_id = 1 and type = 1 then 'clustered'
		when index_id > 1 and type = 6 then 'nonclustered columnstore'
		when index_id > 1 and type = 2 then 'nonclustered'
		else 'new index type' end
		+ case when ignore_dup_key <>0 then ', ignore duplicate keys' else '' end
		+ case when is_unique=1 then ', unique' else '' end
		+ case when is_hypothetical <>0 then ', hypothetical' else '' end
		+ case when is_primary_key <>0 then ', primary key' else '' end
		+ case when is_unique_key <>0 then ', unique key' else '' end
		+ case when auto_created <>0 then ', auto create' else '' end
		+ case when no_recompute <>0 then ', stats no recompute' else '' end
		+ ' located on ' + groupname),
							  'index_keys' =
		case when type = 6 then 'n/a, see columns_in_leaf for details'
		else index_keys end,
						'included_columns' =
		case when type = 6 then 'n/a, columnstore index'
		else inc_columns end,
						 'filter_definition' =
		case when type = 6 then 'n/a, columnstore index'
		else filter_definition end,
							   'columns_in_tree' =
		case when type = 6 then 'n/a, columnstore index'
		else cols_in_tree end,
						  'columns_in_leaf' =
		case when type = 6 then 'Columns with column-based index: ' + cols_in_leaf
		else cols_in_leaf end
		
		from #spindtab
		order by index_id
	#>
	
	
}
