﻿$server = New-Object -TypeName Microsoft.SqlServer.Management.Smo.Server -ArgumentList localhost\s1
$fields = $server.GetDefaultInitFields([Microsoft.SqlServer.Management.Smo.Database])
$fields.Add("IsSystemObject")
$server.SetDefaultInitFields([Microsoft.SqlServer.Management.Smo.Database], $fields)

$results = @()

foreach($db in ($server.Databases | Where { $_.IsSystemObject -eq $false })) {
    $vlfs = Get-SqlLogVlfCount -ServerInstance $server.name -Database $db.Name
     
    $results += $vlfs
}

. .\Out-DataTable.ps1

$table = $results | Out-DataTable

$table
$results.GetType()
$table.GetType()
 
. .\Write-DataTable.ps1

Write-DataTable -ServerInstance $server.name -Database DBA -TableName "dbo.VLFCounts" -Data $table
