<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2016 v5.2.117
	 Created on:   	7/29/2016 4:02 PM
	 Created by:   	Ben
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>
Function Get-SqlLogVlfCount
{
	param ($ServerInstance,
		$Database)
	
	$results = "" | Select ServerInstance, Database, Count
	
	$results.ServerInstance = $ServerInstance
	$results.Database = $Database
	
	$smo = "Microsoft.SqlServer.Management.Smo"
	$server = New-Object -TypeName "$smo.Server" -ArgumentList $ServerInstance
	$db = $server.Databases[$Database]
	if ($db -ne $null)
	{
		try
		{
			$ds = $db.ExecuteWithResults("DBCC LOGINFO")
			if ($ds.Tables.Count -gt 0)
			{
				$results.Count = $ds.Tables[0].Rows.Count
			}
			else 
			{
				$results.Count = -1
			}
		}
		catch
		{
			$results.Count = -1
		}
	}
	
	return $results
}

function Get-SqlLogInfo
{
	param (
		$ServerInstance,
		$Database,
		$UserId,
		$Password
	)
	
	$results = @()
	
	$smo = "Microsoft.SqlServer.Management.Smo"
	$server = New-Object -TypeName "$smo.Server" -Args $ServerInstance
	if ($UserId -ne $null)
	{
		$server.ConnectionContext.LoginSecure = $false
		$server.ConnectionContext.Login = $UserId
		$server.ConnectionContext.Password = $Password
	}
	
	$db = $server.Databases[$Database]
	foreach ($log in $db.LogFiles)
	{
		$loginfo = "" | select ServerName, Database, FileGroup, FileId, Filename, SizeMB, PhysicalName, Growth, GrowthType, UsedSpaceMB, SpaceFreeMB, VLFCount
		
		$loginfo.ServerName = $server.Name
		$loginfo.Database = $db.Name
		$loginfo.FileGroup = "NONE"
		$loginfo.FileId = $log.ID
		$loginfo.FileName = $log.Name
		$loginfo.SizeMB = $log.Size / 1KB
		$loginfo.PhysicalName = $log.FileName
		if($file.GrowthType -eq "KB") 
		{
			$loginfo.GrowthType = "MB"
			$loginfo.Growth = $log.Growth / 1KB
		}
		else 
		{
			$loginfo.GrowthType = $log.GrowthType
			$loginfo.Growth = $log.Growth
		}
		$loginfo.UsedSpaceMB = $log.UsedSpace / 1KB
		$loginfo.SpaceFreeMB = ($log.Size - $log.UsedSpace) / 1KB
		$vlf = Get-SqlLogVlfCount -ServerInstance $ServerInstance -Database $Database 
		$loginfo.VLFCount = $vlf.Count
		
		$results += $loginfo
	}
	
	return $results
}

function Get-SqlFileInfo
{
	param (
		$ServerInstance,
		$Database,
		$UserId,
		$Password
	)
	
	$results = @()
	
	$smo = "Microsoft.SqlServer.Management.Smo"
	$server = New-Object -TypeName "$smo.Server" -Args $ServerInstance
	if ($UserId -ne $null)
	{
		$server.ConnectionContext.LoginSecure = $false
		$server.ConnectionContext.Login = $UserId
		$server.ConnectionContext.Password = $Password
	}
	
	$db = $server.Databases[$Database]
	foreach ($fg in $db.FileGroups)
	{
		foreach ($file in $fg.Files)
		{
			$fileinfo = "" | select ServerName, Database, FileGroup, FileId, Filename, SizeMB, PhysicalName, Growth, GrowthType, UsedSpaceMB, SpaceFreeMB, VLFCount
			$fileinfo.ServerName = $ServerInstance
			$fileinfo.Database = $db.Name
			$fileinfo.FileGroup = $fg.Name
			$fileinfo.FileId = $file.ID
			$fileinfo.FileName = $file.Name
			$fileinfo.SizeMB = $file.Size / 1KB
			$fileinfo.PhysicalName = $file.FileName
			$fileinfo.Growth = $file.Growth
			
			if($file.GrowthType -eq "KB") 
			{
				$fileinfo.GrowthType = "MB"
				$fileinfo.Growth = $file.Growth / 1KB
			}
			else 
			{
				$fileinfo.GrowthType = $file.GrowthType
				$fileinfo.Growth = $file.Growth
			}
			$fileinfo.UsedSpaceMB = $file.UsedSpace / 1KB
			$fileinfo.SpaceFreeMB = ($file.Size - $file.UsedSpace) / 1KB
			$fileinfo.VLFCount = 0
			
			$results += $fileinfo
		}
	}
	
	$results += Get-SqlLogInfo -ServerInstance $ServerInstance -Database $Database
	
	
	return $results
}