<#
.SYNOPSIS
   <A brief description of the script>
.DESCRIPTION
   <A detailed description of the script>
.PARAMETER <paramName>
   <Description of script parameter>
.EXAMPLE
   <An example of using the script>
#>
function Get-SqlStatisticsByIndexId {
param (
	[string]$sqlserver,
	[string]$DBName,
	[string]$TableName,
    [string]$Schema,
	[int]$IndexId = 1,
	[switch]$FullTable
)

$db = Get-SqlDatabase $sqlserver $DBName
$table = $db.Tables.get_Item($TableName, $Schema)

$index = $table.Indexes | Where { $_.ID -eq $indexid }
if($index) {
	$stats = $index.EnumStatistics().Tables[0]
	if($FullTable) {
		$stats		
	}
	else {
		$stats | Select Name, Updated, Rows, "Rows Sampled", Steps | ft -AutoSize
	}
}


}
