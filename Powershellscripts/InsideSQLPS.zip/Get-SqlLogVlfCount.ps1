<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2016 v5.2.124
	 Created on:   	7/29/2016 11:03 AM
	 Created by:   	bmiller
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>
Function Get-SqlLogVlfCount
{
	param ($ServerInstance,
		$Database)
	
	$results = "" | Select ServerInstance, Database, Count, CollectionTime
	
	$results.ServerInstance = $ServerInstance
	$results.Database = $Database
    $results.CollectionTime = get-date
	
	$smo = "Microsoft.SqlServer.Management.Smo"
	$server = New-Object -TypeName "$smo.Server" -ArgumentList $ServerInstance
	$db = $server.Databases[$Database]
	if ($db -ne $null)
	{
		try
		{
			$ds = $db.ExecuteWithResults("DBCC LOGINFO")
			if ($ds.Tables.Count -gt 0)
			{
				$results.Count = $ds.Tables[0].Rows.Count
			}
			else 
			{
				$results.Count = -1
			}
		}
		catch
		{
			$results.Count = -1
		}
	}
	
	return $results
}
