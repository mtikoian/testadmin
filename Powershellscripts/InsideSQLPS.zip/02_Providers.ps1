﻿# Show the HKLM provider
# This is the view inside of the Registry
cd HKLM:
dir

CD "\software\microsoft\Windows NT\CurrentVersion"
dir

# Notice that some providers do not have
# facilities to be like drives
HKLM:

# But SQLServer module fixed that with a function
SQLSERVER:

Import-Module (Get-Module -ListAvailable sqlserver | select -last 1)

$base = (get-module sqlserver) | Select -first 1 ModuleBase
cd $base.ModuleBase

# Let's look at the formats for the particular
# objects in SMO, starting with Database
notepad .\SQLProvider.Format.ps1xml

dir sqlserver:\sql\localhost\s16\Databases
cd sqlserver:\
get-service mssql*

# Now let's look at the structure inside the provider
SQLSERVER:

dir  # or Get-ChildItem or gci

CD SQL

dir

# Notice the machine names
# If you have navigated into localhost then
# it will show up, otherwise, it will show
# your system name
CD DEMOVM

dir

# Now you will see the Instances whether they 
# are started or not
# To see the status you could do
Get-Service mssql*

cd S16

dir

<#  Notice the list of objects in the list
    Audits
    AvailabilityGroups
    BackupDevices
    Credentials
    CryptographicProviders
 -->Databases
    Endpoints
 -->JobServer
    Languages
    LinkedServers
 -->Logins
    Mail
    ResourceGovernor
 -->Roles
    ServerAuditSpecifications
    SystemDataTypes
    SystemMessages
    Triggers
    UserDefinedMessages
#>
cd Databases
dir

# Notice the format of the data. You can get
# properties you want by using Select 
dir | Select Name, ID, CompatibilityLevel | Format-Table * -AutoSize # or ft *

# Now let's look at the roles
cd ..\Roles
dir

Get-Item sysadmin
Get-Item sysadmin | Get-Member # or gm

# OK, now let's find out what cmdlets we have in 
# this module before we go to what we can do with
# it.
Get-Command -Module Sqlserver -Verb New
Get-Command -Module Sqlserver -Verb Add
Get-Command -Module Sqlserver -Verb Remove
Get-Command -Module Sqlserver -Verb Test

# OK now we want to connect with SQL Authentication
# Yes, you can do it, it is just different.
New-PSDrive -Name SQLAUTH -PSProvider SqlServer `
     -Root SQLSERVER:\SQL\DEMOVM\S16 `
     -Credential (get-credential)

CD SQLAUTH:

Function SQLAUTH: { CD SQLAUTH: }

SQLAUTH:

