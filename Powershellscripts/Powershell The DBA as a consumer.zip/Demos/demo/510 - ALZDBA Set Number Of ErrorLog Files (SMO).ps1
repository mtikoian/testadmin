﻿<# 
ALZDBA 20130102
Set number of Errolog files for a given SQLServer instance

Modifies the registry key NumErrorLogs for the instance 
[HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Microsoft SQL Server\<SQLInstanceNumber>\MSSQLServer]
"NumErrorLogs"=dword:0000001f

#>
clear-host 
# Target instances ( 
$sqlServers = Import-Csv -Path 'c:\temp\allInstances.csv' -Delimiter ';' 

# show overview of sqlserver data
#$sqlServers | Out-GridView 

# Load the SMO assembly and create the server object, connecting to the server.
[System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.SMO') | Out-Null

# Never trust a freaking default [10] ( [-1] for SQL2005 ) and set your own according to your desire
# Keep in mind these files may be big, so can consume quite some disk space.
#   We roll over on a weekly basis, so setting this to 20 will keep history for 20 weeks ( in normal operation )
#   or 20 restarts  ( an upgrade may need more than 2 restarts )
[int]$TargetNumberOfLogFiles = 20
$n = 0
foreach ( $Instance in $sqlServers ) {
	$SQLInstance = $Instance.FQServernaam.tostring()
	$n ++ ;
	$pct = $n * 100 / $sqlServers.count ;
	Write-Progress -Activity $('Processing SQLServer instances [{0}]' -f $sqlServers.count ) -Status "current: $SQLInstance" -PercentComplete $pct ;

	try {
		$server = New-Object 'Microsoft.SqlServer.Management.SMO.Server' ($SQLInstance)
		#Take controle over the actual connect
		$server.ConnectionContext.Connect()
		#Modify number of errorlog files for the instance
		if ( $server.NumberOfLogFiles -ne $TargetNumberOfLogFiles ) {

			write-host $('*[{0}] - Original number of errorlog files [{1}].' -f $server.Name, $server.NumberOfLogFiles )
			$server.NumberOfLogFiles = $TargetNumberOfLogFiles 
			$server.Alter()

			$server.Refresh()
			}
			
		write-host $('[{0}] - number of errorlog files [{1}].' -f $server.Name, $server.NumberOfLogFiles )
		}
	catch {
		Write-Host $('Execption encountered for [{0}] (ProductVersion {1}) : {2}' -f $SQLInstance, $Instance.ProductVersion.tostring(), $_.exception.message ) -ForegroundColor Black -BackgroundColor Red 
		}
	}
Write-Progress -Activity "Processing SQLServer instances [$sqlServer.count]" -Status "current: $SQLInstance" -Completed ;

Write-Host 'Processing finished' -ForegroundColor Black -BackgroundColor Yellow 

