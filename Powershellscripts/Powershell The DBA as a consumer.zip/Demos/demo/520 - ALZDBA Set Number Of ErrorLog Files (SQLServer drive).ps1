﻿<#
ALZDBA Set Number Of ErrorLog Files (SQLServer drive).ps1

#>
# all systems requirements
#requires -version 2.0
# 
# uabe0dv10\gnkd006
Clear-Host 

$TargetNumberOfErrorLogFiles = 20

<# ask user response SQLInstance #>
$SQLInstance=$null
$SQLInstance = read-host "SQLServer Instance Name?"
if (!$SQLInstance) { 
	$SQLInstance = "(localhost)"
	}
else {
If ( $SQLInstance -notlike '*\*')  {
    $SQLInstance += "\Default"
    }
 }

$Computer = $SQLInstance.Substring(0,$SQLInstance.LastIndexOf('\'))
$Instance = $SQLInstance.Substring($SQLInstance.LastIndexOf('\') + 1)
try {
	Set-Location SQLSERVER:\SQL\$Computer
	$TheInstance = dir | where-object { $_.DisplayName -eq $Instance } 
	if ( $TheInstance.NumberOfLogFiles -ne $TargetNumberOfErrorLogFiles ) {
		write-host $('*[{0}] - Original number of errorlog files [{1}].' -f $SQLInstance, $TheInstance.NumberOfLogFiles )
		#Modify Number of ErrorLog files to keep
		$TheInstance.NumberOfLogFiles = $TargetNumberOfErrorLogFiles
		}
	write-host $('[{0}] - number of errorlog files [{1}].' -f $SQLInstance, $TheInstance.NumberOfLogFiles )
		
	}
catch {
    write-host $('Cannot get the requested info for [{0}]' -f $SQLInstance )
	}



