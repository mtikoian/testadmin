﻿Clear-Host 

Set-Location $env:SQLSat
cd demo
#gci |  select IsOK, name | sort name | Export-Csv 'c:\temp\PoSh_Overview.csv' -Delimiter ';' -NoTypeInformation 
gci |  select @{n='IsOK';e={0}}, name | sort name | Export-Csv -path $( join-path -Path $env:SQLSat -childpath "Demo_Overview.csv") -Delimiter ';' -NoTypeInformation 

& "$( join-path -Path $env:SQLSat -childpath "Demo_Overview.csv")"
