#Show Version
$host.Version