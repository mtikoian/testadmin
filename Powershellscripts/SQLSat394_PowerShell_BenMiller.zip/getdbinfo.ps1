.\Get-SqlDatabaseInfo -ServerInstance localhost\s1 -databasename AdventureWorks2012
