# Load SQLPS environment

c:\Demos\Initialize-SqlpsEnvironment.ps1

#
