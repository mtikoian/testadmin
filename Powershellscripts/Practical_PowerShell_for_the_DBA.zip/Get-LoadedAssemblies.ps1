﻿[appdomain]::currentdomain.getassemblies() | sort -property fullname | format-table fullname 
