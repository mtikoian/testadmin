﻿Start-Transcript -Path "C:\Demos\Practical PowerShell\TranscriptDemo_1.txt"
Stop-Transcript
