#Powershell Database Backup Script
#Ref: http://www.sqlservercentral.com/articles/Backup+%2f+Restore/71682/

cls
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.SMO") | Out-Null
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.SmoExtended") | Out-Null
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.ConnectionInfo") | Out-Null
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.SmoEnum") | Out-Null

# Check disk space on local disks (drivetype=3) on local server
$cdrive = Get-WmiObject -Class Win32_LogicalDisk -Filter "DriveType=3"
$cdrive.FreeSpace

$a = Get-Date
$bzipfile = "AdventureWorksLT2008R2" + $a.Day + "-" + $a.Month + "-" + $a.Year + ".bak.zip"

$bkup = "C:\backup\AdventureWorksLT2008R2.bak"

if(Test-Path $bkup){
Write-Host " Deleting previous backup" $bkup
Remove-Item $bkup
}

$server = New-Object ("Microsoft.SqlServer.Management.Smo.Server") ("tosh-lpt")

$dbBackup = new-Object ("Microsoft.SqlServer.Management.Smo.Backup")
$dbRestore = new-object ("Microsoft.SqlServer.Management.Smo.Restore")

$dbBackup.Database = "AdventureWorksLT2008R2"

$dbBackup.Devices.AddDevice("C:\backup\AdventureWorksLT2008R2.bak", "File")

$dbBackup.Action="Database"

$dbBackup.Initialize = $TRUE

$dbBackup.SqlBackup($server)

if(!(Test-Path C:\backup\AdventureWorksLT2008R2.bak)){
#  $smtp = new-object Net.Mail.SmtpClient("emailserver")
#  $smtp.Send("from", "to", "Backups not working", "Action required immediately for Full Backup")
  Write-Host "*** ERROR *** Backups not working - Action required immediately for Full Backup"
  Exit
}

$dbRestore.Devices.AddDevice("C:\backup\AdventureWorksLT2008R2.bak", "File")
if (!($dbRestore.SqlVerify($server))){
#$smtp = new-object Net.Mail.SmtpClient("emailserver")
#$smtp.Send("from", "to", "Backups not valid", "Action required immediately for Full Backup")
  Write-Host "ERROR *** Backups not valid - Action required immediately for Full Backup"
Exit
}

Copy-Item C:\backup\AdventureWorksLT2008R2.bak C:\data\AdventureWorksLT2008R2.bak

#Write-Zip C:\Data\AdventureWorksLT2008R2.bak -OutputPath C:\Archives\$bzipfile

$cfin = Get-Date -format t
#$smtp = new-object Net.Mail.SmtpClient("emailserver")
#$smtp.Send("from", "to", "Database Backup Finish Time", $cfin)
Write-Host " Database Backup Finish Time" $cfin

# FTP file over to another destination
#$webclient = New-Object System.Net.WebClient
#$uri = New-Object System.Uri("FTP-server-site")
#$webclient.UploadFile($uri, $location)

