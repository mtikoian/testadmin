﻿cls

## ----------------------
#$a = "Hello SQL203"
#Write-Host $a –foregroundcolor “red”

# ----------------------
#$a = Read-Host “Enter your name”
#Write-Host "Hello" $a

# ----------------------
#function sum ([int]$a,[int]$b)
#{
#return $a + $b
#}
#sum 4 5

# ----------------------
#$a = "green"
#if ($a -eq "red")
#{$a = "The colour is red"}
#elseif ($a -eq "white")
#{$a = "The colour is white"}
#else
#{$a = "Another colour"}
#$a

# ----------------------
#For ($a=1; $a –le 5; $a++)
#{$a}
#
# ----------------------
#$a=1
#Do {$a; $a++}
#Until ($a –gt 5)
# ----------------------
#$a=1
#Do {$a; $a++}
#While ($a –lt 5)
#$a
#
# ----------------------
#$a = "black"
#switch ($a)
#{
#"red" {"The colour is red"}
#"white"{"The colour is white"}
#default{"Another colour"}
#}

# ----------------------
#$a = "red"
#switch ($a)
#{
#"red" {"The colour is red"}
#"white"{"The colour is white"}
#default{"Another colour"}
#}
# --------Pipeline-----------
#$a = Foreach ($i in Get-Childitem c:\windows)
#{$i.name; $i.creationtime}
#$a | out-file "C:\test.txt"

## ----------------------
$a = Get-Content "c:\test.txt"
foreach ($i in $a)
{$i}
##
## --------Pipeline-----------
#$a = Get-Process
#$a| Select-Object Name,Path,Company | Export-Csv -path "C:\test.csv"
#