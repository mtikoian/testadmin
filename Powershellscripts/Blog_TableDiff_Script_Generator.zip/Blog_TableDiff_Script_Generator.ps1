﻿# ---------------------------------------------------------------------------------------------
# This following functions will generate tablediff scripts that assume the tablediff executable
# has been added to the PATH variable on the machine.  
# 
# To use this PowerShell script, follow these steps:
# 
#   1) Edit the variables at the top
#   2) Call the desired function at the bottom of the script
#   3) Execute this PowerShell script within a PowerShell console
#   4) Execute the resulting batch file to perform the TableDiff
# ---------------------------------------------------------------------------------------------

Import-Module SQLPS -DisableNameChecking


# Set variables
$source              = "source_sql_instance_name"
$destination         = "destination_sql_instance_name"
$database            = "my_database"
$batchFile           = "<drive:><location>\Table_Diff_Script.bat"


# Delete any existing batch file
if (Test-Path $batchfile)
{
    Remove-Item -Path $batchFile 
}


# --------------------------------------------------------------
# Function to generate a TableDiff script for replicated tables.
# --------------------------------------------------------------
function New-TableDiffCommands()
{
	Param 
	(
	    [bool] $fastComparison
	)
	
	$tables = Invoke-Sqlcmd -Query "SELECT name FROM sys.tables WHERE is_replicated = 1" -ServerInstance $source -Database $database 
	    
	if ($fastComparison -eq $true)
	{
	    # Generate commands for a fast comparison only
	    foreach ($table in $tables)
	    {
	        $tableName = $table.name
		    "tablediff -q -sourceserver $source -sourcedatabase $database -sourcetable $tableName -destinationserver $destination -destinationdatabase $database -destinationtable $tableName" | Out-File $batchFile -Append -Encoding ascii
        }
	}
	else
	{
	    foreach ($table in $tables)
	    {
	        $tableName = $table.name
		    "tablediff -sourceserver $source -sourcedatabase $database -sourcetable $tableName -destinationserver $destination -destinationdatabase $database -destinationtable $tableName" | Out-File $batchFile -Append -Encoding ascii
        }
	}
}


# ----------------------------------------------------------------------------------------
# Function to generate a TableDiff script with a convergence script for replicated tables.
# ----------------------------------------------------------------------------------------
function New-TableDiffCommandsWithConvergenceScript()
{
	Param 
	(
	    [string] $directory
	)
	
    # Delete any old convergence scripts
    Get-ChildItem $directory -include *.sql -recurse | Remove-Item

	$tables = Invoke-Sqlcmd -Query "SELECT name FROM sys.tables WHERE is_replicated = 1" -ServerInstance $source -Database $database 
	
	# Generate TableDiff commands with the -f option to generate convergence scripts
	foreach ($table in $tables)
	{
	    $tableName = $table.name
        $filename = $directory + $tableName + "_converge_script.sql" 
		"tablediff -f $filename -sourceserver $source -sourcedatabase $database -sourcetable $tableName -destinationserver $destination -destinationdatabase $database -destinationtable $tableName" | Out-File $batchFile -Append -Encoding ascii
	}
}


# Main: Here we call the function we want to use
New-TableDiffCommands -fastComparison $true
New-TableDiffCommandsWithConvergenceScript -directory "C:\temp\"