﻿# Connect to SQL Server instance and run a command using SQL Native Client, Returns a recordset
# Script Variables are: $sqlInst, $sqlList, $sqlConnection, $sqlCommand, $sqlReader

# Read list of SQL Instances from pre-generated file
$sqlList = get-content c:\temp\SQL_List.txt

# Process through each instance in the file
foreach ($sqlInst in $sqlList) { 

# Create and open a database connection
$sqlConnection = new-object System.Data.SqlClient.SqlConnection "server=$sqlInst;database=msdb;Integrated Security=sspi"
$sqlConnection.Open()

#Create a command object
$sqlCommand = $sqlConnection.CreateCommand()
$sqlCommand.CommandText = "select server_name, database_name, backup_finish_date
from msdb.dbo.backupset b 
where datediff(hh,backup_finish_date, getdate()) < 24 and type = 'D'"

#Execute the Command
$sqlReader = $sqlCommand.ExecuteReader()

#Parse the records
while ($sqlReader.Read()) {$sqlReader["server_name"] + ", " + $sqlReader["database_name"] + ", " + $sqlReader["backup_finish_date"] | out-file c:\temp\sql_bkup.txt -append } 

# Close the database connection
$sqlConnection.Close()

} # End processing of instances from list


