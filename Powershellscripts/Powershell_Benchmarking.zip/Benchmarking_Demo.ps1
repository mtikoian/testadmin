﻿#Let's look at Get-Counter
Get-Help Get-Counter -ShowWindow 
Get-Help Get-Counter -Online

#And we can use it to get a simple counter
$counter = Get-Counter -Counter @('\Processor(_Total)\% Processor Time')
$counter

#Everything is an object, so what's the output
$counter | Get-Member

#The key is CounterSamples, where all our info is stored
$counter.CounterSamples | Get-Member

$counter.CounterSamples | Format-Table Path, Timestamp, CookedValue, RawValue -AutoSize

#We can get multiple samples, but it's a little different
#Specify the number of samples and how often to sample
$samples = Get-Counter -Counter @('\Processor(_Total)\% Processor Time') -SampleInterval 2 -MaxSamples 5

$samples.CounterSamples | Format-Table Path, Timestamp, CookedValue, RawValue -AutoSize

#And if we want multiple counters....
$multicounter = Get-Counter -Counter @("\SQLServer:Buffer Manager\Page Life Expectancy","\SQLServer:Buffer Manager\Buffer cache hit ratio") `
                    -SampleInterval 2 -MaxSamples 5 

$multicounter.CounterSamples | Format-Table Path, Timestamp, CookedValue -AutoSize

#SMO
$smosrv = new-object ('Microsoft.SqlServer.Management.Smo.Server')

#Lets us test to see if it's actually there
$smosrv.ConnectionContext.Connect()
$smosrv.ConnectionContext.ServerInstance

#The SMO has lost of information
$smosrv | Get-Member

$smosrv.ComputerNamePhysicalNetBIOS
$smosrv.VersionString
$smosrv.Databases

#we can use this for a lot of stuff. In our benchmarking we will only use it for a couple of things.

#Let's run our simple benchmark.
#(Fire up hammerDB)
Import-Module SQLBenchmarker
New-SQLBenchmarkReport -InstanceName localhost -DurationSec 60 -AutoOpen
