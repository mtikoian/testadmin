#servers.ps1
#Get list of Servers from XML and use

$ds = new-object "System.Data.DataSet" "dsServers"
$ds.ReadXml("C:\Demos\servers.xml")
$dtServer = new-object "System.Data.DataTable" "dtServers"
$dtServer = $ds.Tables[0]
$dtServer
