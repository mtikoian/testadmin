#employeeextract.ps1
#This script pulls info from the Person.Contact table in AdventureWorks and presents it to the user

$cn = new-object system.data.SqlClient.SqlConnection("Data Source=SQLTBWS\INST01;Integrated Security=SSPI;Initial Catalog=AdventureWorks");
$ds = new-object "System.Data.DataSet" "dsPersonData"
$q = "SELECT TOP 25 [ContactID]"
$q = $q + "      ,[FirstName]"
$q = $q + "      ,[LastName]"
$q = $q + "      ,[EmailAddress]"
$q = $q + "      ,[Phone]"
$q = $q + "  FROM [AdventureWorks].[Person].[Contact]"
$da = new-object "System.Data.SqlClient.SqlDataAdapter" ($q, $cn)
$da.Fill($ds)

$dtPerson = new-object "System.Data.DataTable" "dtPersonData"
$dtPerson = $ds.Tables[0]
$dtPerson | FOREACH-OBJECT { [string]$_.ContactID + ": " + $_.FirstName + ", " + $_.LastName + ", " + $_.EmailAddress + ", " + $_.Phone }
