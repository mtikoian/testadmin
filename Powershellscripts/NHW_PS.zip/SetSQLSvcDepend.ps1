###############################################################################
# Purpose: If MSiSCSI Service exists, Make SQL Server Service dependent on it.
###############################################################################
# Created by Nancy Hidy Wilson
# Ver. 1.0 - 03/24/2009 - Original version
# Ver. 1.1 - 03/26/2009 - Added dynamic creation of output status filename
###############################################################################

# Set error mode to Silently continue
$erroractionpreference = "SilentlyContinue"

# Get the full path and name of this script
$ScriptFullName = $MyInvocation.MyCommand.Definition 

# Create Output Status Filename from filename.type of this script in C:\Temp and append .out 
$outfile = split-path $ScriptFullName -leaf
$outfile = "C:\Temp\" + $outfile + ".out"

# Add initial separator line into Output Status File, append if file already exists 
"**********************************************" | Out-File $outfile -append

# Get current Date/Time and filename of script to Output Status File
$now=get-date
Write-Output $now " ...Starting " $ScriptFullName | Out-File $outfile -append

# Find MSiSCSI service
$iSCSISvc = get-service | Select-Object Name | where {$_.Name -eq "MSiSCSI" }

If ($iSCSISvc -match "MSiSCSI") {
  # Find SQL Services Registry key entries
  Write-Output "Found" $iSCSISvc ". Checking SQL Service Dependencies." | Out-File $outfile -append
  set-location HKLM:\SYSTEM\CurrentControlSet\Services
  $SQLSvcReg = dir | Select-Object Name | where {($_.Name -imatch "MSSQL") -and ($_.Name -inotmatch "MSSQLFD*") -and ($_.Name -inotmatch "MSSQLServerAD*") } 

# Go through each SQL Service and set dependency, if needed
  Foreach ($svc in $SQLSvcReg) {
    $svc.Name -replace "HKEY_LOCAL_MACHINE", "HKLM:" | set-location 
    Write-Output "Processing: " $svc.Name | Out-File $outfile -append
    $svckey = get-ItemProperty -path . 
    If ($svckey.DependOnService) {
	If ($svckey.DependOnService -match "MSiSCSI") {
	  Write-Output "..Found MSiSCSI in DependOnService. Nothing else to do." | Out-File $outfile -append
	}
	Else { 
	  Write-Output "..Adding MSiSCSI to existing DependOnService value" | Out-File $outfile -append
	  $newval = $svckey.DependOnService + "MSiSCSI"
	  Set-ItemProperty -path . -name DependOnService -value $newval
	}
    } 
    Else {
	Write-Output "..Adding DependOnService new key and value." | Out-File $outfile -append
	new-ItemProperty -path . -PropertyType MultiString -name DependOnService -value MSiSCSI
    }
  }
} 
Else { 
  Write-Output "NO MSiSCSI Service. Nothing to do." | Out-File $outfile -append
} 

# Closing 
# Add Ending Date/Time, Filename info into Output Status File
$now=get-date
Write-Output $now "Ending $ScriptFullName " | Out-File $outfile -append
"**********************************************" | Out-File $outfile -append

# END OF SCRIPT
