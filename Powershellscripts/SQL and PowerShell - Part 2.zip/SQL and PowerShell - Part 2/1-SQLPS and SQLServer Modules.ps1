﻿#I'm using ISE Steroids
http://www.powertheshell.com/isesteroids2-2/download/
#I'm extending PowerShell ISE with VariableExplorer
Import-Module VariableExplorer.psm1

#Check PowerShell Version, using 5.1
$PSVersionTable
#Import SQLPS Module, 2016 version
Import-Module -Name SQLPS -Verbose
#Notice the new version does NOT set location to PS SQLSERVER:> after importing!
#Ensure latest version, the C:\Program Files (x86)\Microsoft SQL Server\130\ folder is SQL 2016
Get-Module -Name SQLPS | Select-Object -ExpandProperty ModuleBase -First 1

$SQLPSCommands = Get-Command -Module SQLPS
$SQLPSCommands
$SQLPSCommands | Measure-Object

#Remove SQLPS before using SQLServer module, they conflict!
Remove-Module -Name SQLPS
Import-Module -Name SQLServer
#SQLServer Module is installed outside SQL Program Folders, separate releases
Get-Module -Name SQLServer | Select-Object -ExpandProperty ModuleBase -First 1

$SQLServerCommands = Get-Command -Module SQLServer
$SQLServerCommands
$SQLServerCommands | Measure-Object

Compare-Object -ReferenceObject ($SQLPSCommands) -DifferenceObject ($SQLServerCommands) -IncludeEqual

#More functionality is coming to SQLServer module in SQL vnext, check the Trello board!
#https://trello.com/b/NEerYXUU/powershell-sql-client-tools-sqlps-ssms

#Cleanup
Remove-Module -Name SQLPS
Remove-Module -Name SQLServer


