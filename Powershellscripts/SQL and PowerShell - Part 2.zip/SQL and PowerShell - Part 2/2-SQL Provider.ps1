﻿Set-Location c:\scripts
Import-Module SQLServer
Get-PSProvider

#Navigate our SQL Server using the SQL Provider
Set-Location -Path SQLSERVER:
#See what aspects of SQL Server are available
Get-ChildItem

#Use absolute path
Set-Location -Path SQLSERVER:\SQL\DGEM
Get-ChildItem

#Use relative path
Set-Location -Path .\DEFAULT
#See what aspects of this instance are available
Get-ChildItem

#Database object types
Get-ChildItem .\Databases\AdventureWorks2014
#Tables
Get-ChildItem .\Databases\AdventureWorks2014\Tables
#Let's inspect one table
Get-ChildItem .\Databases\AdventureWorks2014\Tables\HumanResources.Employee 
Get-ChildItem .\Databases\AdventureWorks2014\Tables\HumanResources.Employee\columns

#Let's get that item as an object
$tableObject = Get-Item .\Databases\AdventureWorks2014\Tables\HumanResources.Employee 
$tableObject | Get-Member
#It is a Microsoft.SqlServer.Management.Smo.Table object
#https://msdn.microsoft.com/en-us/library/microsoft.sqlserver.management.smo.table.aspx
#try one of the methods
$tableObject.Rebuild()


#SQL Agent
Get-ChildItem .\JobServer
Get-ChildItem .\JobServer\Jobs

#Get a job object
$job = Get-ChildItem .\JobServer\Jobs | Where-Object -Property Name -EQ 'Test Job'
$job | Get-Member

#work with job object
$job.Script()

#Cleanup
Remove-Module SQLServer