1. Setup managed service accounts for each SQL Server instance.
2. Service account names will need to be placed within the MyServerData.psd1 file.
3. SQL2017Config.ini provided as an example.