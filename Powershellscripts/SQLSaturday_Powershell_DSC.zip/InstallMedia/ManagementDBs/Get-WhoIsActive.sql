select name from master.sys.procedures where name = 'sp_whoisactive'

