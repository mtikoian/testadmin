select name from sys.databases where name = 'DBA'

