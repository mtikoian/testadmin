declare @Results table (Value varchar(300), Data int)
declare @data int
insert into @Results
EXEC xp_instance_regread N'HKEY_LOCAL_MACHINE', N'Software\Microsoft\MSSQLServer\MSSQLServer', N'NumErrorLogs'

select @data = data from @Results
set @data = ISNULL(@data,0)

if @data <> 30
BEGIN
	RAISERROR('Number of error logs does not match the desired configuration.  Updating....',16,1)
END
ELSE
 BEGIN
	PRINT 'Number of error logs matches the desired state.  Skipping.......'
END




if (select count(name) from sys.databases where name = 'DBA') = 0
BEGIN
	--RAISERROR ('Did not find database [DBA]', 16, 1)
	PRINT 'Did not find database [DBA].  Skipping...............'
END
ELSE
BEGIN
if (select count(*) from DBA.sys.objects where is_ms_shipped = 0) > 0
	BEGIN
	 PRINT 'Found database [DBA].  However, it contains user objects.  Skipping..'
	END
	ELSE
	BEGIN
	  RAISERROR('Found database [DBA].  Deploying objects........',16,1)
	END

END