declare @Results table (Value varchar(300), Data int)
declare @data int
insert into @Results
EXEC xp_instance_regread N'HKEY_LOCAL_MACHINE', N'Software\Microsoft\MSSQLServer\MSSQLServer', N'LoginMode'

select @data = data from @Results

if @data <> 1 --windows auth
BEGIN
	RAISERROR('Login mode is not Windows Authentication.  Updating....',16,1)
END
ELSE
 BEGIN
	PRINT 'Login mode is Windows Authentication.  Skipping.......'
END

