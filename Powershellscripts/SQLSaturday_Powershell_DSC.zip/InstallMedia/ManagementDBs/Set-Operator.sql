USE [msdb]
GO

/****** Object:  Operator [GHSDBA]    Script Date: 8/16/2017 1:19:48 PM ******/
EXEC msdb.dbo.sp_add_operator @name=N'DBATeam', 
		@enabled=1, 
		@weekday_pager_start_time=90000, 
		@weekday_pager_end_time=180000, 
		@saturday_pager_start_time=90000, 
		@saturday_pager_end_time=180000, 
		@sunday_pager_start_time=90000, 
		@sunday_pager_end_time=180000, 
		@pager_days=0, 
		@email_address=N'DBATeam@bogus.com', 
		@category_name=N'[Uncategorized]'
GO
