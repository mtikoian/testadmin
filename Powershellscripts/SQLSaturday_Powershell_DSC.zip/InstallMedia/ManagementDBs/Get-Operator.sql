USE msdb
go
select name from dbo.sysoperators where name = 'DBATeam'


