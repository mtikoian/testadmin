if (select name from sys.server_principals where sid = 1) = 'sa'
BEGIN
	RAISERROR('SA account has not been renamed.  Renaming now......',16,1)
END
ELSE
 BEGIN
	PRINT 'SA not found.......'
END

