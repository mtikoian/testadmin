if (select count(name) from sys.server_audit_specifications where name = 'AUDIT_APP_SPEC') = 0
BEGIN
	RAISERROR ('Did not find the AUDIT_APP_SPEC. Deploying the audit specification...............', 16, 1)
END
ELSE
BEGIN
 PRINT 'Found the AUDIT_APP_SPEC audit specification.  Skipping..'
 END
