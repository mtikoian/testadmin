select name from sys.server_principals where sid = 1


