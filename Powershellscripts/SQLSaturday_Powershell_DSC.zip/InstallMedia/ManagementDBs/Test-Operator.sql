USE msdb
GO
if (select count(name) from dbo.sysoperators where name = 'DBATeam') = 1
BEGIN
	--RAISERROR ('Did not find database [DBA]', 16, 1)
	PRINT 'DBATeam operator already exists.  Skipping...............'
END
ELSE
 BEGIN
	  RAISERROR('Creating the DBATeam operator.',16,1)
END

