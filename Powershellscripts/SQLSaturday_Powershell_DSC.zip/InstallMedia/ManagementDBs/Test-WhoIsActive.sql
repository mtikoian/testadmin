if (select count(name) from master.sys.procedures where name = 'sp_whoisactive') = 1
BEGIN
	PRINT 'Fonnd the sp_whoisactive stored procedure in the [Master] database.  Skipping...............'
END
ELSE
	RAISERROR('Did not find the sp_whoisactive stored procedure in the [Master] database.  Deploying...',16,1)

