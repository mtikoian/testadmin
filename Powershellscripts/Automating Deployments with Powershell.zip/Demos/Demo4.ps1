﻿# Import my modules
CD C:\Windows\System32 ;
Import-Module .\WindowsPowerShell\v1.0\Modules\Demos\SQLInstaller ;
Import-Module sqlps ;

CD C:\ ;

# Check firewall access for SQL Server
Invoke-Command {netsh advfirewall firewall add rule name="Open SQL Server Port 1433" dir=in action=allow protocol=TCP localport=1433} -Computer DEMO1
Invoke-Command {netsh advfirewall firewall add rule name="Open SQL Server Port 1433" dir=in action=allow protocol=TCP localport=1433} -Computer DEMO2


# Check the startup parameters
Set-Location SQLSERVER:\SQL\DEMO1$wmi = (Get-Item .).ManagedComputer#DEMO1# Show the state of the service$sqlSvc = $wmi.Services['MSSQLSERVER']$sqlSvc#Stop the instance$sqlSvc.Stop()$sqlSvc.Refresh()$SqlSvc.ServiceState#Restart$sqlSvc.Start()$sqlSvc.Refresh()$SqlSvc.ServiceState$sqlSvc.StartMode$sqlSvc.StartupParameters$addTrace1222 = $sqlSvc.StartupParameters$addTrace1222 += ';-T 1222'$sqlSvc.StartupParameters = $addTrace1222$sqlSvc.Alter()$sqlSvc.StartupParameters# Check Always On
$sqlSvc.IsHadrEnabled
Enable-SqlAlwaysOn -Path SQLSERVER:\SQL\DEMO1\DEFAULT
$sqlSvc.IsHadrEnabled

#Protocols
$sqlProt = $wmi.ClientProtocols
$sqlTCP = $sqlProt.Item('tcp')
$sqlTCP.ProtocolProperties['Default Port'].Value
$sqlTCP.IsEnabled = $true
$sqlTCP.Alter()


