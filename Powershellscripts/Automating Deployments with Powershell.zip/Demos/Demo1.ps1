﻿# Import my modules
CD C:\Windows\System32
Import-Module .\WindowsPowerShell\v1.0\Modules\Demos\SQLInstaller

# Show the version of PowerShell that I'm running on my client
$psversiontable

# Ensure WinRM is running
Test-PSRemoting Win8
Test-PSRemoting DEMO1
Test-PSRemoting DEMO2

# Check firewall access for WMI as we're going to need it
Invoke-Command {netsh advfirewall firewall set rule group="Windows Management Instrumentation (WMI)" new enable=yes} -Computer DEMO1
Invoke-Command {netsh advfirewall firewall set rule group="Windows Management Instrumentation (WMI)" new enable=yes} -Computer DEMO2
 
# Configure where needed
Set-WINRMListener DEMO1
Set-WINRMListener DEMO2

# Check PowerShell version on all servers.  Note minor differences in patch levels between client & servers
$psversiontable
Invoke-Command {$psversiontable} -Computer DEMO1
Invoke-Command {$psversiontable} -Computer DEMO2

# For the servers, check memory, processors, OS version and disks
$minCPU = 4$minMemoryGB = 64
$servers = ("DEMO1","DEMO2")
$servers | foreach(
                    {
                        # Get the server type information
                        "$_" ;
                        $verID = (gwmi win32_OperatingSystem -computer $_).Version;
                        $arch = (gwmi win32_OperatingSystem -computer $_).OSArchitecture ;
                        'Windows version {0}.{1} ({2})' -f $verID.Split(".")[0],$verID.Split(".")[1], $arch ;

                        # Check CPU
                        if ((gwmi win32_ComputerSystem -computer $_).NumberOfLogicalProcessors -lt $minCPU)	                    {# Example of error handling if built into a checking utility#		                    $Error.Clear()#    		                $errMsg = "Server $_ does not have sufficient vCPUs.  Min is $minCPU."#    		                $Error.add($errMsg)#   		                Throw                            "Server $_ does not have sufficient vCPUs.  Min is $minCPU, actual is $((gwmi win32_ComputerSystem -computer $_).NumberOfLogicalProcessors)"	                    }
                        if ([Math]::Ceiling((gwmi win32_ComputerSystem -computer $_).TotalPhysicalMemory / 1073741824) -lt $minMemoryGB)	                    {    		                "Server $_ does not have sufficient memory.  Min is $minMemoryGB GB, actual is $([Math]::Ceiling((gwmi win32_ComputerSystem -computer $_).TotalPhysicalMemory / 1073741824)) GB"	                    }                        # Check disks                            ## Assume that the minimum set of disks is                             ##  C (Operating System)          30 GB                            ##  D (Page file / shared files)  20 GB	                        ##	L (Database Tran Log Files)	  50 GB	                        ##	M (Database Data Files)		 200 GB	                        ##	S (System DB Files)		      20 GB	                        ##	T (TempDB Data Files)		  50 GB	                        ##	V (TempDB Tran Log Files)	  20 GB                        # Build a hash table for the disks                        $disks = @{"C:" = 30; "D:" = 20; "L:" = 50; "M:" = 200; "S:" = 20; "T:" = 50; "V:" = 20} ;                        $this = $_ ;                        $disks.GetEnumerator() | %{                                                    if ([Math]::Ceiling((gwmi win32_LogicalDisk -computer $this -filter "DeviceID='$($_.Key)'").Size / 1073741824) -lt $($_.Value)) 					                                {							                            "Server $this, disk $($_.Key) does not have sufficient capacity.  Min is $($_.Value) GB, actual is $([Math]::Ceiling((gwmi win32_LogicalDisk -computer $this -filter "DeviceID='$($_.Key)'").Size / 1073741824)) GB"    				                                }				                                  }	                    # Check the Paging File                        ## Make sure automatic management is not set for Windows 	                    if ((gwmi win32_ComputerSystem -computer $_).AutomaticManagedPagefile -eq "True")	                    {		                    "Server $_ has an automatically managed Page File."	                    }                        else                        {	                        if ((gwmi win32_PageFileUsage -computer $_).Count -gt 1)	                        {		                        "Server $svrName has more than 1 Page File."	                        }                            else                            {	                            if (    (gwmi win32_PageFileSetting -computer $_).MaximumSize -ne 8192 `                                         -or (     (gwmi win32_PageFileSetting -computer $_).MaximumSize -eq 8192 `                                              -and (gwmi win32_PageFileSetting -computer $_).InitialSize -ne 8192                                             )                                   )	                            {                                    "Server $_ Page File is not set to a custom size of 8GB, actual is $((gwmi win32_PageFileSetting -computer $this).InitialSize) GB to $((gwmi win32_PageFileSetting -computer $this).MaximumSize) GB"	                            }	                            if (!((gwmi win32_PageFileUsage -computer $_).Caption.startsWith("D:\","CurrentCultureIgnoreCase")))	                            {                                    "Server $_ Page File is not set to D:\ drive."	                            }                            }                        }	                    # Check the Roles and Features	                    ## Must have .NET 3.5.1 for SQL Server 2012.  Can also check whether there is more than a baseline set	                    $featureCheck = Invoke-Command -computerName $_ {                                                                            Import-Module ServerManager;                                                                             Get-WindowsFeature | where {$_.Name -eq "NET-Framework-Core"} | select Installed;                                                                             Remove-Module ServerManager                                                                        }	                    if ($featureCheck.Installed -ne $true)	                    {                            "Server $_ is missing .Net Framework 3.5.1 Feature."	                    }	                    # Check the Windows Firewall State	                    $fw = Invoke-Command -computerName $_ {netsh advfirewall show allprofiles state}	                    foreach ($fwSetting in $fw)	                    {		                    if ($fwSetting.contains("  ON  "))		                    {                                "Server $_ has WIndows Firewall features enabled."		                    }	                    }                    Write-Host ;
                    }
                  )

# For interest, show the features installed
Invoke-Command {Get-WindowsFeature | where { $_.Installed -eq $true}} -Computer DEMO1 | SELECT Name, DisplayName, FeatureType
Invoke-Command {Get-WindowsFeature | where { $_.Installed -eq $true}} -Computer DEMO2 | SELECT Name, DisplayName, FeatureType

