﻿# Import my modules
CD C:\Windows\System32 ;
Import-Module .\WindowsPowerShell\v1.0\Modules\Demos\SQLInstaller ;
Import-Module sqlps ;

CD C:\ ;

# Set max and min server memory with PowerShell
$s = New-Object (‘Microsoft.SqlServer.Management.Smo.Server’) “DEMO1”$s.Configuration.MinServerMemory.ConfigValue = 128$s.Configuration.MaxServerMemory.ConfigValue = 512$s.Configuration.Alter()Set-Location SQLSERVER:\SQL\DEMO1\DEFAULTInvoke-SqlCmd -InputFile 'C:\Demos\sp_config.sql'