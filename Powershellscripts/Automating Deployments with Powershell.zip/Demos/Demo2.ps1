﻿# Import my modules
CD C:\Windows\System32
Import-Module .\WindowsPowerShell\v1.0\Modules\Demos\SQLInstaller

# Command Line Options
## Show the main configuration file
notepad "C:\Demos\ConfigurationFile.ini"

# Build the command line
## Assume SQL Install media is in the D: drive
cd d:\
setup.exe /IACCEPTSQLSERVERLICENSETERMS /CONFIGURATIONFILE="C:\Demos\ConfigurationFile.ini" /AGTSVCACCOUNT="LAB\SQLAgent" /AGTSVCPASSWORD="Some very complex password" `
/SAPWD="I hope never to need this account" /SQLSVCACCOUNT="LAB\SQLService" /SQLSVCPASSWORD="Another very very complex password"
