## This module contains general functions that are specific to the SQL 
## Installer, but are not dependent upon objects defined on the GUI form.

###########################################################################

Function Set-WINRMListener
{
<#
.SYNOPSIS
Set-WinRMListener will configure a remote computer's WinRM service to listen for WinRM requests

.DESCRIPTION
Set-WinRMListener uses the system.management.managementclass object to create 3 registry keys.  These registry entries will configure the WinRM service when it restarts next.  Use Restart-WinRM to restart the WinRM service after it has been successfully configured.

.EXAMPLE 
Get-Content .\servers.txt | Set-WinRMListener 

Sets the WinRM service on the computers in the servers.txt file

.EXAMPLE 
Set-WinRMListener -ComputerName (get-content .\servers.txt) -IPv4Range "10.10.1.0 255.255.255.0"

Sets the WinRM service on the computers in the servers.txt file and restricts the IPv4 address to 10.10.1.0 /24

#>
[cmdletBinding()]
Param
    (
        # Enter a ComputerName or IP Address, accepts multiple ComputerNames
        [Parameter( 
        ValueFromPipeline=$True, 
        ValueFromPipelineByPropertyName=$True,
        Mandatory=$True,
        HelpMessage="Enter a ComputerName or IP Address, accepts multiple ComputerNames")] 
        [String[]]$ComputerName,
        [Parameter(
        HelpMessage="Enter the IPv4 address range for the WinRM listener")]
        [String]$IPv4Range = '*',
        [Parameter(
        HelpMessage="Enter the IPv4 address range for the WinRM listener")]
        [String]$IPv6Range = '*'
    )
Begin
    {
        $HKLM = 2147483650
        $Key = "SOFTWARE\Policies\Microsoft\Windows\WinRM\Service"
        $DWORDName = "AllowAutoConfig" 
        $DWORDvalue = "0x1"
        $String1Name = "IPv4Filter"
        $String2Name = "IPv6Filter"
    }
Process
    {
        Foreach ($computer in $ComputerName)
            {
                Write-Verbose "Beginning function on $computer"
                Try
                    {
                        Write-Verbose "Attempting to create remote registry handle"
                        $Reg = New-Object -TypeName System.Management.ManagementClass -ArgumentList \\$computer\Root\default:StdRegProv
                    }
                Catch 
                    {
                        Write-Warning $_.exception.message
                        Write-Warning "The function will abort operations on $Computer"
                        $problem =$true
                    }
                if (-not($problem))
                    {
                        Try 
                            {
                                Write-Verbose "Attempting to create Remote Key"
                                if (($reg.CreateKey($HKLM, $key)).returnvalue -ne 0) {Throw "Failed to create key"}
                            }
                        Catch 
                            {
                                Write-Warning $_.exception.message
                                Write-Warning "The function will abort operations on $Computer"
                                $problem =$true
                            }
                    }
                if (-not($problem))
                    {
                        Try 
                            {
                                Write-Verbose "Attemping to set DWORD value"
                                if (($reg.SetDWORDValue($HKLM, $Key, $DWORDName, $DWORDvalue)).ReturnValue -ne 0) {Throw "Failed to set DWORD"}
                            }
                        Catch 
                            {
                                Write-Warning $_.exception.message
                                Write-Warning "The function will abort operations on $Computer"
                                $problem =$true
                            }
                    }
                if (-not($problem))
                    {
                        Try 
                            {
                                Write-Verbose "Attempting to set first REG_SZ Value"
                                if (($reg.SetStringValue($HKLM, $Key, $String1Name, $IPv4Range)).ReturnValue -ne 0) {Throw "Failed to set REG_SZ"}
                            }
                        Catch 
                            {
                                Write-Warning $_.exception.message
                                Write-Warning "The function will abort operations on $Computer"
                                $problem =$true
                            }
                    }
                if (-not($problem))
                    {
                        Try 
                            {
                                Write-Verbose "Attempting to set second REG_SZ Value"
                                if (($reg.SetStringValue($HKLM, $Key, $String2Name, $IPv6Range)).ReturnValue -ne 0) {Throw "Failed to set REG_SZ"}
                            }
                        Catch 
                            {
                                Write-Warning $_.exception.message
                                Write-Warning "The function will abort operations on $Computer"
                                $problem =$true
                            }
                    }
                if ($problem) {$problem = $false} 
                Else {Write-Verbose "Successfully completed operation on $computer"}
            }
    }
End {}
}

###########################################################################

Function Restart-WinRM
{
<#
.SYNOPSIS
Restarts the WinRM service

.DESCRIPTION
Uses the win32_service class to get and restart the WinRM service.  This function was designed to be used after Set-WinRMListener to allow the new registry configuration to take hold.

.EXAMPLE
Restart-WinRM -computername TestVM

Restarts the WinRM service on TestVM

.EXAMPLE
Get-Content .\servers.txt | Restart-WinRM 

Restarts the WinRM service on all the computers in the servers.txt file

#>
[CmdletBinding()]
Param 
    (
        # Enter a ComputerName or IP Address, accepts multiple ComputerNames
        [Parameter( 
        ValueFromPipeline=$True, 
        ValueFromPipelineByPropertyName=$True,
        Mandatory=$True,
        HelpMessage="Enter a ComputerName or IP Address, accepts multiple ComputerNames")] 
        [String[]]$ComputerName
    )
Begin {}
Process 
    {
         Foreach ($computer in $ComputerName)
            {
                Write-Verbose "Beginning function on $computer"
                Try
                    {
                        Write-Verbose "Attempting to stop WinRM"
                        (Get-WmiObject win32_service -Filter "Name='WinRM'" -ComputerName $computer).StopService() | Out-Null
                        Start-Sleep -Seconds 10
                        if ((Get-WmiObject win32_service -Filter "Name='WinRM'" -ComputerName $computer).state -notlike "Stopped") {Throw "Failed to Stop WinRM"}
                    }
                Catch 
                    {
                        Write-Warning $_.exception.message
                        Write-Warning "The function will abort operations on $Computer"
                        $problem = $true
                    }
                if (-not($problem))
                    {
                        Try 
                            {
                                Write-Verbose "Attempting to start WinRM"
                                (Get-WmiObject win32_service -Filter "Name='WinRM'" -ComputerName $computer).StartService() | Out-Null
                                Start-Sleep -Seconds 10
                                if ((Get-WmiObject win32_service -Filter "Name='WinRM'" -ComputerName $computer).state -notlike "Running") {Throw "Failed to Start WinRM"}
                            }
                        Catch
                            {
                                Write-Warning $_.exception.message
                                Write-Warning "The function will abort operations on $Computer"
                                $problem = $true
                            }
                    }
                if ($problem) {$problem = $false} 
                Else {Write-Verbose "Successfully completed operation on $computer"}
            }    
    }
End {}
}

###########################################################################

Function Set-WinRMStartup
{
<#
.SYNOPSIS
Changes the startup type of the WinRM service to automatic

.DESCRIPTION
Uses the Win32_service class to change the startup type on the WinRM service to Automatic

.EXAMPLE
Set-WinRMStartup -Computername TestVM

Sets the WinRM service startup type to Automatic on test VM

#>
[CmdletBinding()]
Param 
    (
        # Enter a ComputerName or IP Address, accepts multiple ComputerNames
        [Parameter( 
        ValueFromPipeline=$True, 
        ValueFromPipelineByPropertyName=$True,
        Mandatory=$True,
        HelpMessage="Enter a ComputerName or IP Address, accepts multiple ComputerNames")] 
        [String[]]$ComputerName
    )
Begin {}
Process 
    {
         Foreach ($computer in $ComputerName)
            {
                Write-Verbose "Beginning function on $computer"
                Try
                    {
                        if (((Get-WmiObject win32_service -Filter "name='WinRM'" -ComputerName $computer).ChangeStartMode('Automatic')).ReturnValue -ne 0) {Throw "Failed to change WinRM Startup type on $Computer"}
                    }
                Catch
                    {
                        Write-Warning $_.exception.message
                        Write-Warning "Failed to change startmode on the WinRM service for $computer"
                    }
            }
    }
}


###########################################################################


function Test-PsRemoting
{
<# 
.SYNOPSIS 
    Checks whether PS Remoting is enabled on the remote computer.
.DESCRIPTION 
    This function checks whether a command can be executed on a remote
    Powershell session.   This is the best way to verify that PS Remoting
    is properly configured and enabled on the computer.

.NOTES 
    Author     : Martin Cairney  
    Company    : LobsterPot Solutions Pty Ltd 
    Version    : 1.0
    Date       : 2nd October 2013
    Requires   : PowerShell V2
.RETURNVALUE
    Returns [System.Boolean]
.LINK 
    http://www.lobsterpot.com.au
.EXAMPLE 
    $isEnabled = Test-PsRemoting MyRemoteServer
.PARAMETER computerName 
    The name of the remote computer to check. 

#> 

param
(
	[Parameter(Position=0, Mandatory=$TRUE, ValueFromPipeline=$TRUE)]   
	[string] $serverName 
)
   
	# Start of function 

    	try
    	{
        	$result = Invoke-Command -ComputerName $serverName -Credential $global:cred { 1 } -ErrorAction Stop
    	}
    	catch 
    	{
        	return $false
    	}
   
    	## I�ve never seen this happen, but if you want to be
    	## thorough�.
    	if($result -ne 1)
    	{
        	return $false
    	}
   
    	$true   
} 

###########################################################################

function Get-XMLDateTime
{
<# 
.SYNOPSIS 
    Converts a DateTime to an XML formatted DateTime string.
.DESCRIPTION 
    This function takes a standard DateTime object and converts it to
    XML format of YYYY-MM-DDThh:mm:ss.

.NOTES 
    Author     : Martin Cairney  
    Company    : LobsterPot Solutions Pty Ltd 
    Version    : 1.0
    Date       : 2nd October 2013
    Requires   : PowerShell V2
.RETURNVALUE
    Returns [System.String]
.LINK 
    http://www.lobsterpot.com.au
.EXAMPLE 
    $xmlDateTime = Get-XMLDateTime (Get-Date)
.PARAMETER stdDateTime 
    The DateTime value to convert to XML DateTime format. 

#> 

param
(
	[Parameter(Position=0, Mandatory=$TRUE, ValueFromPipeline=$FALSE)]   
	[System.Datetime] $stdDateTime 
)
   
	# Start of function 

	[string]$cSecond = "0" + $stdDateTime.Second.ToString()
    	[string]$cMinute = "0" + $stdDateTime.Minute.ToString()
    	[string]$cHour = "0" + $stdDateTime.Hour.ToString()
    	[string]$cDay = "0" + $stdDateTime.Day.ToString()
    	[string]$cMonth = "0" + $stdDateTime.Month.ToString()
    	[string]$cYear =  $stdDateTime.Year.ToString()

    	[string]$tTime = $cHour.substring($cHour.length - 2, 2) + ":"
	[string]$tTime += $cMinute.substring($cMinute.length - 2, 2) + ":"
	[string]$tTime += $cSecond.substring($cSecond.length - 2, 2)

    	[string]$tDate = $cYear + "-" + $cMonth.substring($cMonth.length - 2, 2) + "-" + $cDay.substring($cDay.length - 2, 2)
    
	[string]$XmlTime = $tDate + "T" + $tTime 

	$xmlTime
}
