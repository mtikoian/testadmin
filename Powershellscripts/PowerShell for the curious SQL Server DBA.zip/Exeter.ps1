﻿<#
Basic Examples of PowerShell usage for SQL Server DBAs
To accompany the session present at SQL Saturday Exter March 2014

All examples are safe to run in a controlled environment. 
Running them directly on a prod server may cause issues, do so at your own risk

If you've any questions please get in touch, 

Stuart Moore - 
Email: stuart@stuart-moore.com
Twitter: @napalmgram
Blog: http://stuart-moore.com
#>


#To change your location on the drive:
Set-Location C:\exter-ps
#aliased to:
sl c:\
cd c:\

#Get the contents of a folder:
Get-ChildItem C:\exter-ps
#aliased to
gci C:\exter-ps
#This one probably looks familiar
dir C:\exter-ps

#as will this alias to any *nix users in the audience
ls C:\exter-ps

#You can add parameters 
#Recurse down a folder tree:
Get-ChildItem c:\ -Recurse

#Include Hidden items
Get-ChildItem c:\ -Recurse -Force

#Is designed to be cross purpose, not just limited to disks
#How about the registry:
Get-ChildItem -Path HKLM:\Software -Recurse


#Potentially the MOST useful cmdlet in the whole of PowerShell

#Find all cmdlets containing the word log:
Get-Help *log*

#Get general help on a cmdlet
Get-Help Get-ChildItem

#Helpfully lots of cmdlets come with examples!
Get-Help Get-ChildItem -Examples
Get-Help Get-Service -Examples

#And if reading them on the console isn't the best method:
Get-Help Get-Service -Online
Get-Help Get-Process -Online


#Many cmdlets have options:
Get-ChildItem c:\ -Filter *exter*

<#
But many of them can be implemented in a more PowerShell way
by using the pipeline to send the cmdlet output to another
cmdlet to filter or sort
#>
Get-ChildItem c:\ | Where-Object {$_.Name -like "*ps*"}
Get-ChildItem c:\ | Where-Object {$_.Name -like "*ps*"} | Measure-Object
Get-ChildItem c:\ | Where-Object {$_.Name -like "*ps*"} | Sort-Object -Descending
Get-ChildItem c:\ | Where-Object {$_.Name -like "*ps*"} | Sort-Object LastWriteTime

#Can be built up step by step into complex useful command lines
#This example can be used to mirror Windows Roles and Features
#across windows servers, great for building app/web farms, W2012+
Get-WindowsFeature
Get-WindowsFeature | ?{$_.installed -eq $True}
Get-WindowsFeature | ?{$_.installed -eq $True} | Add-WindowsFeature -ComputerName Server2

<#
A classic task implement in one line of PowerShell.
Recurse down a folder structure deleting any file over 7 days
old, but ignoring any folders

(Syntax will be explained shortly!)
#>
Get-ChildItem -recurse |
     Where-Object {$_.LastWriteTime -lt (Get-Date).AddDays(-7) -and $_.IsPSContainer -eq $False} |
      Remove-Item

#Add a file extension filter and you've a SQL backup cleandown script ready to go:
Get-ChildItem -recurse |
     Where-Object {$_.LastWriteTime -lt (Get-Date).AddDays(-7) -and $_.Extension -eq "bak"} |
      Remove-Item

<#
So how do you find out about all these methods and properties that these
objects have>?

Meet Get-Member
#>
Get-Date | Get-Member

$today = get-date
$tomorrow = $today.AddDays(1)
$yesterday = $today.AddDays(-1)
$ThisDayAYearAgoWas = $today.AddYears(-1).DayOfWeek.ToString()

$today
$tomorrow
$yesterday
$ThisDayAYearAgoWas

#Generating timestamps
get-date -f yyyyMMddHHmm

#But this won't work
(get-date).AddDays(-3) -f yyyyMMddHHmm

#But, we can use the .Net object versions
(get-date).AddDays(-3).ToString("yyyyMMddHHmm")

<#
Note the use of brackets in the above examples
In Powershell this tells the engine to process the enclosed
command first and use the returned object. It saves using a 
variable to hold something temporarily

So the following sequence of commands will both start and stop a service
#>

$service = Get-Service -Name 'MSSQL$SQL2012'
$service.Stop()
Start-Sleep -Seconds 5
$service.Start()

#Can be rewritten as
(Get-Service -Name 'MSSQL$SQL2012').stop()
Start-Sleep -Seconds 5
(Get-Service -Name 'MSSQL$SQL2012').start()



<#
Can do conditional processing.

First of all If.
If this do that:

#>

if ($env:USERNAME -eq "Stuart"){
    write-output "hello stuart"
}

if ($env:USERNAME -ne "Stuart"){
    write-output "hello not stuart"
}

#Can also offer other options:

if ($env:USERName -eq "Stuart"){
    Write-Output "Hiya Stuart"
}elseif ($env:USERNAME -eq "Mark"){
    Write-Output "Hi Mark"
}else{
    Write-Output "You're not Stuart or Mark"
}

<#
Switch (Case) can be a better construct to use if you've a lot of options
Can be easier to read and spot the logic
#>
$value  = Read-Host "Enter a number 1-10"
switch ($value)
{
1 {"One"}
2 {"Two"}
3 {"Three"}
4 {"Four"}
5 {"Five"}
6 {"Six"}
7 {"Seven"}
8 {"Eight"}
9 {"Nine"}
10 {"Ten"}
default {"I said between 1 and 10!!!!"}
}


<#
Scripting is perfect for repeating dull repetitive tasks
So naturally there are a number of way of repeating the
same task

For loops are good when you know how many times you want to 
loop
#>
for($i=0;$i-le 10;$i=$i+1){
    echo $i
}

#Shorthand for an incrementing by 1 counter:
for($i=0;$i-le 10;$i++){
    echo $i
}

#Can also increment by values other than 1
for($i=0;$i-le 27;$i=$i+3){
    echo $i
}

<#
While loops are good for continous looping while you wait for
something to happen

This will one will keep looping as long as the user enters a 
number between 1 and 10
#>
[int]$i=5
do
{
    $i = Read-Host "Number between 1 and 10 please"
}while ($i -gt 0 -and $i -lt 10)

#Wait for a file to appear in the c:\waiting folder
do{
    Write-Output "No file yet $(get-date)"
    Start-Sleep -Seconds 5
}while ((gci c:\waiting\) -eq $NULL)
Write-Output "File appeared $(get-date)"


<#
PowerShell really comes into it's own when
you start accessing remote systems

Starting simple using a cmdlet's own remoting ability
#>

Get-Service -ComputerName localhost

<#
Now if we want to run something across a large number of machines
we can use Invoke-Command.

Here we get our list of servers from a simple text file. For this
example the file should just contain the server names

Invoke-Command will run our command/scriptblock against 32
machines in parallel and then queue them
#>
Invoke-Command -computer `
(Get-Content C:\SQLServers.txt) `
    -command {Get-Service |
    Where-Object {$_.Name -like "*SQL*"}}

<#Note in the above we filter on the remote machine to 
save on network traffic or too much overhead on our local
box
#>



#Start fully interactive PowerShell session on a 'remote' machine
Enter-PSSession localhost


<#
Just to show not everything's perfect, for some things we need to drop 
to WMI

Working with Services at a low level is a case in point
#>

#Note the lack of method to get or set the startup account
Get-Service | Get-Member

#We can get this information via WMI
Get-WmiObject win32_service -filter 'name like "%SQL%"' |
    Format-Table Name, State, StartName


$CSrv = Get-WmiObject win32_service -filter `
    'name="MSSQL$SQL2012"'
$CSrv.change($null,$null,$null,$null,$null,$false,
    ".\SQLacct","P@$sw0rd")

(Get-service -name 'MSSQL$SQL2012').stop()
Start-Sleep -Seconds 5
(Get-service -name 'MSSQL$SQL2012').start()

#OOPS!!!!!!!!!
#Reset

$CSrv = Get-WmiObject win32_service -filter `
    'name="MSSQL$SQL2012"'
$CSrv.change($null,$null,$null,$null,$null,$false,
    "LocalSystem","")


(Get-service -name 'MSSQL$SQL2012').start()

<#
As if all that wasn't enough to like about PowerShell
we can extend it via modules, snapins and other .Net DLLs
#>

Import-Module ActiveDirectory
Get-Command -Module ActiveDirectory | Measure-Object
Get-Command -module ActiveDirectory | Out-GridView


Import-Module sqlps -DisableNameChecking
Get-Command -Module SQLPS | Measure-Object
Get-Command -Module SQLPS | Out-GridView

#We can use the SQL PSDrive like a normal disk

Set-Location SQLSERVER:\sql\
cd WIN-4B40IEFH4CR\SQL2012\
Get-ChildItem

#Notice how much it looks like SQL Server Management Studios groupings.....

cd Databases
Get-ChildItem
cd psdb1
Get-ChildItem

Get-ChildItem tables

Get-ChildItem StoredProcedures


#But aren't there loads of system ones we should see?
#SMO treats those like 'hidden' files:
Get-ChildItem StoredProcedures -force

Get-ChildItem -recurse
#Oops, not everything works then! This is because each 'folder' contains
#a different type of object so recursion causes too many issues with handling
#the data coming back 

#Rememeber, this is SQL Server, so 2 parts to identify an object
Get-Item t1 #:(

Get-Item dbo.test_1 #:)

#Lots of propertys and Methods available:
Get-Item dbo.t1 | Get-Member

#We can search for things:
Get-ChildItem | foreach{
    $_.columns | where-object {$_.name -like '*find*'}

}

Get-ChildItem | foreach{
    $_.columns | where-object {$_.Datatype -like '*char*'} | ft name, DataType
}

#Very easy to clean up items. If you have good naming conventions!!
set-location SQLSERVER:\sql\WIN-4B40IEFH4CR\SQL2012\Databases\staging\tables

#What are those testing tables doing in Prod?
Get-ChildItem | Where-Object {$_.Name -like "Test*"} | remove-item

#That staging schema should be emptied as well
Get-ChildItem | Where-Object {$_.Schema -eq "Staging" -and $_.IsSystemObject -eq $false} | Remove-Item



<#
Can build our own objects/arrays to hold the results for more useful
searching and reporting

First we build an array called $cols to hold the results. And we use a temporary
hash array $tmpo to hold the results as we get them so we can pass the properties
into $cols
#>

$cols = @()
$tmpo = @{}

set-location SQLSERVER:\sql\WIN-4B40IEFH4CR\SQL2012\Databases\psdb1\tables
foreach ($table in (gci)){
    foreach ($col in $table.Columns){
      
        $tmpo.schema = $table.Schema
        $tmpo.tablename = $table.Name
        $tmpo.columname = $col.Name
        $tmpo.ColDataType = $col.DataType.SqlDataType
        $tmpo.ColDataLength = $col.DataType.MaximumLength
        $tmpo.IsIdentity = $col.Identity
        $cols += new-object psobject -Property $tmpo       
    }
}

# And then we can export them to a csv file:
$cols | Export-CSV C:\exter-ps\colsoutput.csv -NoTypeInformation



<#
The SMO interface opens up huge amount of SQL Server Functionality,
but needs a more 'programming like approach

But it does make it easier to target multiple instances. Take our 
column 'report' above. Using the PSDrive it would be tricky to run
it automatically against a whole set of SQL databases
#>

import-module sqlps -DisableNameChecking

$sqlsvr = New-Object -TypeName  Microsoft.SQLServer.Management.Smo.Server("WIN-4B40IEFH4CR\SQL2012")

foreach ($db in $sqlsvr.Databases | Where-Object {$_.IsSystemObject -eq $FALSE}){
$cols = @()
$tmpo = @{}

    foreach ($table in ($db.tables)){
        foreach ($col in $table.Columns){
      
            $tmpo.schema = $table.Schema
            $tmpo.tablename = $table.Name
            $tmpo.columname = $col.Name
            $tmpo.ColDataType = $col.DataType.SqlDataType
            $tmpo.ColDataLength = $col.DataType.MaximumLength
            $tmpo.IsIdentity = $col.Identity
            $cols += new-object psobject -Property $tmpo       
        }
    }

    $path = "C:\exter-ps\"+$db.name+"_colsoutput.csv"
    $cols | Export-CSV  $path -NoTypeInformation

}


<#
For example, adding a scheduled job to multiple servers

For this example, the text file SQLServers-jobs.txt should
have proper instance names (ie; Server\Instance)

#>

Import-Module SQLPS -DisableNameChecking

#Get our list of instances
$Servers  = get-content C:\exter-ps\SQLServers-jobs.txt
#Loop through the instances
foreach ($sv in $servers){
    #Create an empty job object
    $sqlsvr = New-Object -TypeName  Microsoft.SQLServer.Management.Smo.Server($sv)
    $SQLJob = New-Object -TypeName Microsoft.SqlServer.Management.SMO.Agent.Job -argumentlist $sqlsvr.JobServer, "Exeter_Job"
    $SQLJob.Create()

    #Now we add a step to our Job
    $SQLJobStep = New-Object -TypeName Microsoft.SqlServer.Management.SMO.Agent.JobStep -argumentlist $SQLJob, "Exeter_Job_Step" 
    $SQLJobStep.Command = "select * from sys.databases"
    $SQLJobStep.DatabaseName = "master"
    $SQLJobStep.Create()

    #Now add a schedule to our job to finish it off
    $SQLJobSchedule =  New-Object -TypeName Microsoft.SqlServer.Management.SMO.Agent.JobSchedule -argumentlist $SQLJob, "Exeter_Job_Schedule" 

    #Need to use the built in types for Frequency 
    $SQLJobSchedule.FrequencyTypes =  [Microsoft.SqlServer.Management.SMO.Agent.FrequencyTypes]::Daily
    $TimeSpan1 = New-Object -TypeName TimeSpan -argumentlist 13, 0, 0
    $SQLJobSchedule.ActiveStartTimeofDay = $TimeSpan1
    #Set the job to be active from now
    $SQLJobSchedule.ActiveStartDate = get-date
    #As we've picked daily, this will repeat every day
    $SQLJobSchedule.FrequencyInterval = 1
    $SQLJobSchedule.create()
}

<#
But what if we've got the command wrong?
Or we want to add another step?

Not a Problem
#>

$Servers  = get-content C:\exter-ps\SQLServers-jobs.txt
#Loop through the instances
foreach ($sv in $servers){
    #Create an empty job object
    $sqlsvr = New-Object -TypeName  Microsoft.SQLServer.Management.Smo.Server($sv)
    $SQLJob = $sqlsvr.JobServer.jobs["Exeter_Job"]
   

    #Now we modify our step to our Job
    $SQLJobStep = $sqljob.JobSteps["Exeter_Job_Step"]
    $SQLJobStep.Command = "select * from sys.master_files"
    $SQLJobStep.DatabaseName = "master"
    $SQLJobStep.alter()

    $SQLJobStep2 = New-Object -TypeName Microsoft.SqlServer.Management.SMO.Agent.JobStep -argumentlist $SQLJob, "Exeter_Job_Step2" 
    $SQLJobStep2.Command = "select * from sys.databases"
    $SQLJobStep2.DatabaseName = "master"
    $SQLJobStep2.Create()

    $SQLJobStep.OnSuccessAction = "GoToStep"
    $SQLJobStep.OnSuccessStep=2
    $SQLJobStep.Alter()
}

<#
Backups are a fine example of using powershell
#>

import-module "SQLPS" -DisableNameChecking

$sqlsvr = New-Object -TypeName  Microsoft.SQLServer.Management.Smo.Server("WIN-4B40IEFH4CR\SQL2012")

$backup = New-Object -TypeName Microsoft.SqlServer.Management.Smo.Backup
$backup.Action = [Microsoft.SQLServer.Management.SMO.BackupActionType]::Database
$devicetype = [Microsoft.SqlServer.Management.Smo.DeviceType]::File


foreach ($db in $sqlsvr.databases | where-object {$_.name -ne "tempdb"}){

	$backup.BackupSetDescription = "Full Back of "+$db.Name

	$backup.Database = $db.Name
	$backupname = "c:\sqlbackups\"+$db.Name+"_"+[DateTime]::Now.ToString("yyyyMMdd_HHmmss")+".bak"

	$backupdevice = New-Object -TypeName Microsoft.SQLServer.Management.Smo.BackupDeviceItem($backupname,$devicetype)
	
    $backup.Devices.Add($backupdevice)

    $backup.SqlBackup($sqlsvr)

	$backup.Devices.Remove($backupdevice)
    Remove-Variable backupdevice
}

#Can easily be modified to run against mulitple servers:

$Servers  = get-content C:\exter-ps\SQLServers-jobs.txt
#Loop through the instances
foreach ($sv in $servers){
    $sqlsvr = New-Object -TypeName  Microsoft.SQLServer.Management.Smo.Server($sv)

    $backup = New-Object -TypeName Microsoft.SqlServer.Management.Smo.Backup
    $backup.Action = [Microsoft.SQLServer.Management.SMO.BackupActionType]::Database
    $devicetype = [Microsoft.SqlServer.Management.Smo.DeviceType]::File


    foreach ($db in $sqlsvr.databases | where-object {$_.name -ne "tempdb"}){

	    $backup.BackupSetDescription = "Full Back of "+$db.Name

	    $backup.Database = $db.Name
	    $backupname = "c:\sqlbackups\"+$db.Name+"_"+[DateTime]::Now.ToString("yyyyMMdd_HHmmss")+".bak"

	    $backupdevice = New-Object -TypeName Microsoft.SQLServer.Management.Smo.BackupDeviceItem($backupname,$devicetype)
	
        $backup.Devices.Add($backupdevice)

        $backup.SqlBackup($sqlsvr)

	    $backup.Devices.Remove($backupdevice)
        Remove-Variable backupdevice
    }
}

<#
PowerShell jobs can be scheduled via Windows Scheduled tasks
So this is a very easy way to cope with SQL Express Install

Even more useful is that PowerShell lets you script restores
We are all testing our backups regularly aren't we?

This one scans your backup filess, and then restores to a random point
in time covered by them. This includes restoring any required transaction
logs. It will also relocate the database files to a folder of your choosing,
so you don't have to worry about matching folder structures or clobbering other
databases on the same box.
#>

Import-Module SQLPS -DisableNameChecking

$sqlsvr = New-Object -TypeName  Microsoft.SQLServer.Management.Smo.Server -ArgumentList ("WIN-4B40IEFH4CR\SQL2012")
$restore = New-Object -TypeName Microsoft.SQLServer.Management.Smo.Restore
$devicetype = [Microsoft.SqlServer.Management.Smo.DeviceType]::File

$restore.ReplaceDatabase = $FALSE
$restore.Database = 'restoredt'
$restore.NoRecovery = $TRUE
$files = gci C:\sqlbackups\restoretime


$i=1

$backuptmp = @{}
$objbackups = @()

foreach ($file in $files){

    $backupdevice = new-object Microsoft.SqlServer.Management.Smo.BackupDeviceItem -ArgumentList $file.FullName,$devicetype
    $restore.devices.add($backupdevice)
    $dt = $restore.readbackupheader($sqlsvr)
    $backuptmp.filename = $file.fullname
    $backuptmp.LastLSN = $dt.LastLSN
    $backuptmp.BackupType = $dt.BackupTypeDescription
    $backuptmp.StartDate = $dt.BackupStartDate
    $backuptmp.FinishDate = $dt.BackupFinishDate

    $objbackups += new-object psobject -Property $backuptmp
    $restore.devices.remove($backupdevice)
    remove-variable backupdevice
}

$StartDate = $objbackups.StartDate | Measure-Object -Min
$EndDate = $objbackups.FinishDate | Measure-Object -Max
$seconds = Get-Random ($EndDate.Maximum -$StartDate.Minimum).TotalSeconds
$target = $startdate.Minimum.AddSeconds($seconds)

$restore.ReplaceDatabase = $TRUE
$restore.ToPointInTime = get-date($target) -format "MMM dd, yyyy hh:mm tt"

$rf = New-Object -TypeName Microsoft.SqlServer.Management.SMO.RelocateFile
$rf.LogicalFileName = 'Restoretime'
$rf.PhysicalFileName = 'c:\sqlrestores\restoredt_data.mdf'
$restore.RelocateFiles.Add($rf)
remove-variable rf
$rf = New-Object -TypeName Microsoft.SqlServer.Management.SMO.RelocateFile
$rf.LogicalFileName = 'Restoretime_log'
$rf.PhysicalFileName = 'c:\sqlrestores\restoredt_log.ldf'
$restore.RelocateFiles.Add($rf)

foreach($backup in $objbackups | sort-object -Property LastLSN){
#    if((get-date($target)) -ge $backup.StartDate){
        if ((get-date($target)) -le $backup.finishdate) {
            $restore.NoRecovery = $FALSE
        }

    $backupdevice = new-object Microsoft.SqlServer.Management.Smo.BackupDeviceItem -ArgumentList $backup.filename, $devicetype
    $restore.devices.add($backupdevice)
    $restore.SQLrestore($sqlsvr)

    $restore.devices.remove($backupdevice)
    remove-variable backupdevice
        if ((get-date($target)) -le $backup.finishdate) {
            $restore.NoRecovery = $true
            break
        }
#   } 
}

write-host $target
invoke-sqlcmd -ServerInstance $sqlsvr -Query "select max(dt) from restoredt.dbo.steps"

<#
And for anything else there's Invoke-SQLCMD
#>
Invoke-Sqlcmd -query "select * from master.sys.databases" -ServerInstance "WIN-4B40IEFH4CR\SQL2012"

#Return the data into a Powershell Object
$data = Invoke-Sqlcmd -query "select * from master.sys.databases" -ServerInstance "WIN-4B40IEFH4CR\SQL2012"


#And then we can work with the data using the normal PowerShell tools
$data | Format-table name, log_reuse_wait_Desc, recovery_model_desc

