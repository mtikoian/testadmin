#sysbackup.ps1
# Backs up system databases
#
# Change log:
# January 10, 2010: Allen White
#   Initial Version

# Get the SQL Server instance name from the command line
param(
  [string]$inst=$null
  )

# Load SMO assembly, and if we're running SQL 2008 DLLs load the SMOExtended and SQLWMIManagement libraries
$v = [System.Reflection.Assembly]::LoadWithPartialName( 'Microsoft.SqlServer.SMO')
if ((($v.FullName.Split(','))[1].Split('='))[1].Split('.')[0] -ne '9') {
  [System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.SMOExtended') | out-null
  [System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.SQLWMIManagement') | out-null
  }

# Handle any errors that occur
Trap {
  # Handle the error
  $err = $_.Exception
  write-output $err.Message
  while( $err.InnerException ) {
  	$err = $err.InnerException
  	write-host $err.Message
  	};
  # End the script.
  break
  }

# Connect to the specified instance
$s = new-object ('Microsoft.SqlServer.Management.Smo.Server') $inst

# Get the directory where backups are stored
$bkdir = $s.Settings.BackupDirectory

# Get the databases for the instance, and iterate through them
$dbs = $s.Databases
foreach ($db in $dbs) {
  # Check to make sure the database is a system database, but not tempdb
  if ($db.IsSystemObject -eq $True -and $db.Name -ne 'tempdb') {
    # Store the database name and the current date and time
    $dbname = $db.Name
    $dt = get-date -format yyyyMMddHHmmss
    
    # Create the new Backup object
    $dbbk = new-object ('Microsoft.SqlServer.Management.Smo.Backup')
    
    # Set the Backup object properties
    $dbbk.Action = 'Database'
    $dbbk.Database = $dbname
    $dbbk.BackupSetDescription = "Full backup of " + $dbname
    $dbbk.BackupSetName = $dbname + " Backup"
    $dbbk.Initialize = $True
    $dbbk.MediaDescription = "Disk"
    $dbbk.CompressionOption = "On"        # Set this to Off if not using Enterprise Edition
    
    # Use the database name and date/time with the backup directory to create the backup file
    $dbbk.Devices.AddDevice($bkdir + "\" + $dbname + "_db_" + $dt + ".bak", 'File')
    
    # Back up the database
    $dbbk.SqlBackup($s)
    }
  }
