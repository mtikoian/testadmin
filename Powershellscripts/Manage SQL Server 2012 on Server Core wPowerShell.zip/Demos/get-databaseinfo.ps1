#get-databaseinfo.ps1
# Returns info on user databases
#
# Change log:
# December 13, 2012: Allen White
#   Initial Version

# Get the SQL Server instance name from the command line
param(
  [string]$inst=$null
  )

# Load SMO assembly, and if we're running SQL 2008 DLLs load the SMOExtended and SQLWMIManagement libraries
$v = [System.Reflection.Assembly]::LoadWithPartialName( 'Microsoft.SqlServer.SMO')
if ((($v.FullName.Split(','))[1].Split('='))[1].Split('.')[0] -ne '9') {
  [System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.SMOExtended') | out-null
  [System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.SQLWMIManagement') | out-null
  }

# Handle any errors that occur
Trap {
  # Handle the error
  $err = $_.Exception
  write-host $err.Message
  while( $err.InnerException ) {
  	$err = $err.InnerException
  	write-host $err.Message
  	};
  # End the script.
  break
  }

# Connect to the specified instance
$s = new-object ('Microsoft.SqlServer.Management.Smo.Server') $inst

$dbs = $s.Databases

$dbs | select Name, Collation, CompatibilityLevel, AutoShrink, RecoveryModel, Size, SpaceAvailable
