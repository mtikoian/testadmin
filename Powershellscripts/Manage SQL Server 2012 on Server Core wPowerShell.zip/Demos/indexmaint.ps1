#indexmaint.ps1
# Perform index reorgs and rebuilds depending on fragmentation percent
#
# Change log:
# January 10, 2010: Allen White
#   Initial Version
# November 13, 2010: Allen White
#   Use sys.dm_db_index_physical_stats to get the fragmentation and page count of each index
#   Test the page count to be greater than 1000 before doing index maintenance

# Get the SQL Server instance name from the command line
param(
  [string]$inst=$null
  )

# Load SMO assembly, and if we're running SQL 2008 DLLs load the SMOExtended and SQLWMIManagement libraries
$v = [System.Reflection.Assembly]::LoadWithPartialName( 'Microsoft.SqlServer.SMO')
if ((($v.FullName.Split(','))[1].Split('='))[1].Split('.')[0] -ne '9') {
  [System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.SMOExtended') | out-null
  [System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.SQLWMIManagement') | out-null
  }

# Handle any errors that occur
Trap {
  # Handle the error
  $err = $_.Exception
  write-host $err.Message
  while( $err.InnerException ) {
  	$err = $err.InnerException
  	write-host $err.Message
  	};
  # End the script.
  break
  }

# Connect to the specified instance
$s = new-object ('Microsoft.SqlServer.Management.Smo.Server') $inst

# Get the databases for the instance, and iterate through them
$dbs = $s.Databases
foreach ($db in $dbs) {
  # Check to make sure the database is not a system database, and is accessible
  if ($db.IsSystemObject -ne $True -and $db.IsAccessible -eq $True) {
    # Store the database name for reporting
    $dbname = $db.Name
    $dbid = [string]$db.ID
    
    $tbs = $db.Tables
    foreach ($tb in $tbs) {
      # Store the table name for reporting
      $tbname = $tb.Name
      $tbid = [string]$tb.ID
      
      $ixs = $tb.Indexes
      foreach ($ix in $ixs) {
        # We don't want to process XML indexes
      	if ($ix.IsXmlIndex -eq $False) {
          # Store the index name for reporting
          $ixname = $ix.Name
          $ixid = [string]$ix.ID
          
          # Get the Fragmentation and page count information 
          $frag = $ix.EnumFragmentation()
          foreach ($ixrow in $frag) {
            $frval = $ixrow.AverageFragmentation
            $pgcnt = $ixrow.Pages 
          
            # Check the fragmentation percent
            if ($frval -gt 30 -and $pgcnt -gt 1000) {
              # Rebuild the index if fragmentation over 30 percent
              Write-Host "Rebuilding " $dbname $tbname $ixname
              $ix.Rebuild()
              }
            elseif ($frval -gt 10 -and $pgcnt -gt 1000) {
              # Reorg the index if fragmentation over 10 percent
              Write-Host "Reorging " $dbname $tbname $ixname
              $ix.Reorganize()
            
              # A reorg doesn't update statistics, so do it manually
              $ix.UpdateStatistics()
              }
            }
          }
        }
      }
    }
  }
