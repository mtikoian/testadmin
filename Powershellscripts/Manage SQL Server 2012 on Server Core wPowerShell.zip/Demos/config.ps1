#config.ps1
#Changes Server Configuration parameters from installation defaults
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.SMO")  | out-null
$s = new-object ('Microsoft.SqlServer.Management.Smo.Server') 'SQLTBWS\INST01'

# Show Advanced Options
$s.Configuration.ShowAdvancedOptions.ConfigValue = 1

# Enable Database Mail
$s.Configuration.DatabaseMailEnabled.ConfigValue = 1

# Enable CLR Procedures
$s.Configuration.IsSqlClrEnabled.ConfigValue = 1

# Set Max DOP to Single Processor Mode
$s.Configuration.MaxDegreeOfParallelism.ConfigValue = 1

# Set Backup Compression On
if ($s.Information.EngineEdition -eq 'EnterpriseOrDeveloper') {
	$s.Configuration.DefaultBackupCompression.ConfigValue = 1
	}

# Make the changes
$s.Configuration.Alter()

