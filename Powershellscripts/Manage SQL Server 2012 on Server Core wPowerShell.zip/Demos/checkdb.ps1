#checkdb.ps1
# Perform DBCC CheckDB against each database
#
# Change log:
# January 10, 2010: Allen White
#   Initial Version

# Get the SQL Server instance name from the command line
param(
  [string]$inst=$null
  )

# Load SMO assembly, and if we're running SQL 2008 DLLs load the SMOExtended and SQLWMIManagement libraries
$v = [System.Reflection.Assembly]::LoadWithPartialName( 'Microsoft.SqlServer.SMO')
if ((($v.FullName.Split(','))[1].Split('='))[1].Split('.')[0] -ne '9') {
  [System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.SMOExtended') | out-null
  [System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.SQLWMIManagement') | out-null
  }

# Handle any errors that occur
Trap {
  # Handle the error
  $err = $_.Exception
  $errmsg = $err.Message
  while( $err.InnerException ) {
  	$err = $err.InnerException
  	$errmsg = $errmsg + "|" + $err.Message
  	};
  [Diagnostics.EventLog]::WriteEntry($s.Name ,"Job Error: $errmsg","Error")
  # End the script.
  break
  }

# Connect to the specified instance
$s = new-object ('Microsoft.SqlServer.Management.Smo.Server') $inst

# Get the databases for the instance, and iterate through them
$dbs = $s.Databases
foreach ($db in $dbs) {
  # Check to make sure the database is not a system database, and is accessible
  if ($db.IsSystemObject -ne $True -and $db.IsAccessible -eq $True) {
    # Store the database name for reporting
    $dbname = $db.Name
    
    # Peform the database check
    $db.CheckTables('None')
    
    }
  }
