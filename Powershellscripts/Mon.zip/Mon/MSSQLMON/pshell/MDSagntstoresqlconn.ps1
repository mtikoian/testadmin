Get-PSSnapin -registered

Add-PSSnapin SqlServerProviderSnapin110

Add-PSSnapin SqlServercmdletSnapin110

cd D:\MSSQLMON\pshell

. ./Invoke-sqlcmd2.ps1

. ./Write-DataTable.ps1

. ./Out-DataTable.ps1

. ./sqlmonfunctions.ps1

Invoke-sqlcmd2 -ServerInstance "MSF1VSQL32P" -Database TJXSQLDBMON -Query "SELECT [SQLSrvrName],[InstName] ,[ServiceType], [SQLVersion],[PortNum],[Criticality],[MonStatus],[AlertStatus],cast (getdate() as smalldatetime) rundatetime FROM [dbo].[v_SQLSrvrByServiceType] where sqlsrvrstatus = 'Z' and MonStatus=1 and ServiceType='SSDE' and SQLMonAccnt ='STORE'" | foreach-object {checksqlconn $_.SQLSrvrName $_.InstName $_.PortNum $_.SQLVersion $_.rundatetime}


Invoke-sqlcmd2 -ServerInstance "MSF1VSQL32P" -Database TJXSQLDBMON -Query "SELECT VSQL.[SQLSrvrName],VSQL.[InstName] ,[ServiceType], [SQLVersion],[PortNum],[Criticality],[MonStatus],[AlertStatus],cast (getdate() as smalldatetime) rundatetime FROM [dbo].[v_SQLSrvrByServiceType] VSQL inner join [dbo].tblMonSQLConnect MSQL on VSQL.SQLSrvrName = MSQL.SQLSrvrName and VSQL.InstName = MSQL.InstName where and sqlsrvrstatus = 'Z' and MonStatus=1 and ServiceType='SSDE' and SQLMonAccnt ='STORE' and MSQL.Status=0" | foreach-object {rechecksqlconn $_.SQLSrvrName $_.InstName $_.PortNum $_.SQLVersion $_.rundatetime}
