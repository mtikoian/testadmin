#Get-PSSnapin -registered

#Add-PSSnapin SqlServerProviderSnapin110

#Add-PSSnapin SqlServercmdletSnapin110

Import-Module SQLPS -DisableNameChecking

cd D:\MSSQLMON\pshell

. ./Invoke-sqlcmd2.ps1

. ./Write-DataTable.ps1

. ./Out-DataTable.ps1

. ./sqlmonfunctions.ps1

$MonServer="MSF1VSQL32P"

$MonDBName="TJXSQLDBMON"

#Invoke-sqlcmd2 -ServerInstance $MonServer -Database $MonDBName -Query "SELECT distinct [SQLSrvrName], RPCPortBlocked, cast (getdate() as smalldatetime) rundatetime FROM [dbo].[v_SQLSrvrByServiceType] where SQLSrvrStatus = 'A' and MonStatus=1 and SQLMonAccnt = 'STORE' and isnull(RPCPortBlocked,0)=0" | foreach-object {checkdrivespace $_.SQLSrvrName $_.rundatetime}

#FOR SERVERS NO SQL ENGINE
Invoke-sqlcmd2 -ServerInstance $MonServer -Database $MonDBName -Query "select sqlsrvrname , cast (getdate() as smalldatetime) rundatetime from [tblSQLSrvr] where ssde = 0 and sqlsrvrstatus = 'a' and SQLMonAccnt = 'STORE'" | foreach-object {checkdrivespace $_.SQLSrvrName $_.rundatetime}


#FOR SERVERS WITH SQL ENGIN
Invoke-sqlcmd2 -ServerInstance $MonServer -Database $MonDBName -Query "SELECT [SQLSrvrName],[InstName] ,[ServiceType], [SQLVersion],[PortNum],[Criticality],[MonStatus],[AlertStatus],cast (getdate() as smalldatetime) rundatetime FROM [dbo].[v_SQLSrvrByServiceType] where SQLSrvrStatus = 'A' and MonStatus=1 and SQLMonAccnt ='STORE' and ServiceType='SSDE'" | foreach-object {Checkdrivespace_TSQL $_.SQLSrvrName $_.InstName $_.PortNum $_.SQLVersion $_.rundatetime}


