function getlastsqlrestart([string] $Hostname,[string] $Instname,[int] $PortNum,[int] $Version, [string] $rundatetime)

{
$MonServer="MSF1VSQL16D"
$MonDBName="TJXSQLDBMON"
try
{
$SqlCatalog="master"
$SqlConnection = New-Object System.Data.SqlClient.SqlConnection
$SqlCmd = New-Object System.Data.SqlClient.SqlCommand
$SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
$DataSet = New-Object System.Data.DataSet
$DataSet2 = New-Object System.Data.DataSet
$DataSet3 = New-Object System.Data.DataSet
$DataSet4 = New-Object System.Data.DataSet
$SqlConnection.ConnectionString = �Server = $Hostname"+","+"$PortNum; Database =$SqlCatalog; Integrated Security = True;Connect Timeout=45;�

$SqlCmd.CommandText = "select crdate from sysdatabases where name = 'tempdb'"
$SqlCmd.Connection = $SqlConnection
$SqlAdapter.SelectCommand = $SqlCmd
$SqlAdapter.Fill($DataSet)|out-null
$recorditems =$DataSet.Tables[0]
}

catch
{
$RunDateTime+"Function-getlastsqlrestart: "+$Hostname+" is not reachable."+"--Error Details:"+$ErrDetails >>  "D:\MSSQLMON\pshell_log\getlastsqlrestart.log"
return
}


foreach ($recorditem in $recorditems)
{


$insertqry="INSERT INTO [dbo].[tblMonLastSQLRestart]([SQLSrvrName],[InstName],[LastRestart],[rundatetime]) VALUES ('"+$Hostname+"','"+$InstName+"','"+$recorditem.crdate+"','"+$rundatetime+"')"

Invoke-SqlCmd -ServerInstance $MonServer -Database $MonDBName -Query $insertqry
$SqlConnection.Close()

}

}



function getblockinginfo([string] $Hostname,[string] $Instname,[int] $PortNum,[int] $Version, [string] $rundatetime)

{
$MonServer="MSF1VSQL16D"
$MonDBName="TJXSQLDBMON"
try
{
$SqlCatalog="master"
$SqlConnection = New-Object System.Data.SqlClient.SqlConnection
$SqlCmd = New-Object System.Data.SqlClient.SqlCommand
$SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
$DataSet = New-Object System.Data.DataSet
$DataSet2 = New-Object System.Data.DataSet
$DataSet3 = New-Object System.Data.DataSet
$DataSet4 = New-Object System.Data.DataSet
$SqlConnection.ConnectionString = �Server = $Hostname"+","+"$PortNum; Database =$SqlCatalog; Integrated Security = True;Connect Timeout=5;�

$SqlCmd.CommandText = "select distinct spid,hostname,db_name(dbid) As 'DBName' ,loginame,blocked,program_name,status,SQL=convert (char (150),cmd), login_time, last_batch from master.dbo.sysprocesses Where status <> 'background'and cmd not in ('signal handler','lock monitor','log writer','lazy writer','checkpoint sleep','awaiting command') and blocked <>0 and waittime> 300000
UNION
select distinct spid,hostname,db_name(dbid) As 'DBName' ,loginame,blocked,program_name,status,SQL=convert (char (150),cmd), login_time, last_batch  from master.dbo.sysprocesses where spid in (select distinct blocked from master.dbo.sysprocesses Where status <> 'background'and cmd not in ('signal handler','lock monitor','log writer','lazy writer','checkpoint sleep','awaiting command') and blocked <>0 and waittime> 300000)
"
$SqlCmd.Connection = $SqlConnection
$SqlAdapter.SelectCommand = $SqlCmd
$SqlAdapter.Fill($DataSet)|out-null
$blockedspids =$DataSet.Tables[0]
}

catch
{
$ErrDetails=$error[0]
$RunDateTime+":Function - getblockinginfo: "+$Hostname+" is not reachable."+"--Error Details:"+$ErrDetails >>  "D:\MSSQLMON\pshell_log\getblockinginfo.log"
return}


foreach ($blockedspid in $blockedspids)
{

$insertqry="INSERT INTO [dbo].[tblMonBlockedspids]([SQLSrvrName],[InstName],[spid],[hostname],[DBName],[loginname],[blocked],[programname],[SPIDStatus],[SQLStmnt],[login_time],[last_batch],[rundatetime]) VALUES ('"+$Hostname+"','"+$InstName+"','"+$blockedspid.spid+"','"+$blockedspid.hostname+"','"+$blockedspid.DBName+"','"+$blockedspid.loginame+"','"+$blockedspid.blocked+"','"+$blockedspid.program_name+"','"+$blockedspid.Status+"','"+$blockedspid.SQL+"','"+$blockedspid.login_time+"','"+$blockedspid.last_batch+"','"+$rundatetime+"')"

Invoke-SqlCmd -ServerInstance $MonServer -Database $MonDBName -Query $insertqry
$SqlConnection.Close()

}

}










### Other Functions used

function is-null($value){  
return  [System.DBNull]::Value.Equals($value)  
} 

#####


