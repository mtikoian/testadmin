#Get-PSSnapin -registered

#Add-PSSnapin SqlServerProviderSnapin110

#Add-PSSnapin SqlServercmdletSnapin110

Import-Module SQLPS -DisableNameChecking

cd D:\MSSQLMON\pshell

. ./Invoke-sqlcmd2.ps1

. ./Write-DataTable.ps1

. ./Out-DataTable.ps1

. ./sqlmonfunctions.ps1

$MonServer="MSF1vSQL32P"

$MonDBName="TJXSQLDBMON"

# Server Info

Get-date >  "D:\MSSQLMON\pshell_log\getsrvrinfo.log"

#Invoke-sqlcmd2 -ServerInstance $MonServer -Database $MonDBName -Query "SELECT distinct [SQLSrvrName], cast (getdate() as smalldatetime) rundatetime FROM [dbo].[v_SQLSrvrByServiceType] where SQLSrvrStatus = 'A' and MonStatus=1 and SQLMonAccnt = 'CORP' and isnull(RPCPortBlocked,1)=0" | foreach-object {getsrvrinfo $_.SQLSrvrName $_.rundatetime}

 Invoke-sqlcmd2 -ServerInstance $MonServer -Database $MonDBName -Query "SELECT distinct [SQLSrvrName], cast (getdate() as smalldatetime) rundatetime FROM [dbo].[v_SQLSrvrByServiceType] where SQLSrvrStatus = 'A' and MonStatus=1 and SQLMonAccnt = 'CORP'" | foreach-object {getsrvrinfo $_.SQLSrvrName $_.rundatetime}

# Server Info Behind the Firewall


# SQL Instance Info

Get-date >  "D:\MSSQLMON\pshell_log\GetSQLInstInfo.log"

Invoke-sqlcmd2 -ServerInstance $MonServer -Database $MonDBName -Query "SELECT [SQLSrvrName],[InstName] ,[ServiceType], [SQLVersion],[PortNum],[Criticality],[MonStatus],[AlertStatus],cast (getdate() as smalldatetime) rundatetime FROM [dbo].[v_SQLSrvrByServiceType] where SQLSrvrStatus = 'A' and MonStatus=1 and SQLMonAccnt = 'CORP' and ServiceType='SSDE'" | foreach-object {GetSQLInstInfo $_.SQLSrvrName $_.InstName $_.PortNum $_.SQLVersion $_.rundatetime}

# DB Info
Get-date >  "D:\MSSQLMON\pshell_log\getdbinfo.log"

Invoke-sqlcmd2 -ServerInstance $MonServer -Database $MonDBName -Query "SELECT [SQLSrvrName],[InstName] ,[ServiceType], [SQLVersion],[PortNum],[Criticality],[MonStatus],[AlertStatus],cast (getdate() as smalldatetime) rundatetime FROM [dbo].[v_SQLSrvrByServiceType] where SQLSrvrStatus = 'A' and MonStatus=1 and SQLMonAccnt = 'CORP' and ServiceType='SSDE'" | foreach-object {getdbinfo $_.SQLSrvrName $_.InstName $_.PortNum $_.SQLVersion $_.rundatetime}


# Drive Info

#Invoke-sqlcmd2 -ServerInstance $MonServer -Database $MonDBName -Query "SELECT distinct [SQLSrvrName], cast (getdate() as smalldatetime) rundatetime FROM [dbo].[v_SQLSrvrByServiceType] where SQLSrvrStatus = 'A' and MonStatus=1 and SQLMonAccnt = 'CORP' and isnull(RPCPortBlocked,1)=0" | foreach-object {getdriveinfo $_.SQLSrvrName $_.rundatetime}

Get-date >  "D:\MSSQLMON\pshell_log\getdriveinfo.log"

Invoke-sqlcmd2 -ServerInstance $MonServer -Database $MonDBName -Query "SELECT distinct [SQLSrvrName], cast (getdate() as smalldatetime) rundatetime FROM [dbo].[v_SQLSrvrByServiceType] where SQLSrvrStatus = 'A' and MonStatus=1 and SQLMonAccnt = 'CORP' and isnull(BHFirewall,1)=0" | foreach-object {getdriveinfo $_.SQLSrvrName $_.rundatetime}

# Drive Infor for Servers behind firewall

Get-date >  "D:\MSSQLMON\pshell_log\getdriveinfobhfirewall.log"
#Invoke-sqlcmd2 -ServerInstance $MonServer -Database $MonDBName -Query "SELECT [SQLSrvrName],[InstName] ,[ServiceType], [SQLVersion],[PortNum],[Criticality],[MonStatus],[AlertStatus],cast (getdate() as smalldatetime) rundatetime FROM [dbo].[v_SQLSrvrByServiceType] where SQLSrvrStatus = 'A' and MonStatus=1 and SQLMonAccnt ='CORP' and ServiceType='SSDE' and RPCPortBlocked = 1 and SQLSrvrName not in (select SQLSrvrName from tblDrives)" | foreach-object {getdriveinfobhfirewall $_.SQLSrvrName $_.InstName $_.PortNum $_.SQLVersion $_.rundatetime}

Invoke-sqlcmd2 -ServerInstance $MonServer -Database $MonDBName -Query "SELECT [SQLSrvrName],[InstName] ,[ServiceType], [SQLVersion],[PortNum],[Criticality],[MonStatus],[AlertStatus],cast (getdate() as smalldatetime) rundatetime FROM [dbo].[v_SQLSrvrByServiceType] where SQLSrvrStatus = 'A' and MonStatus=1 and SQLMonAccnt ='CORP' and BHFirewall = 1 and SQLSrvrName not in (select SQLSrvrName from tblDrives)" | foreach-object {getdriveinfobhfirewall $_.SQLSrvrName $_.InstName $_.PortNum $_.SQLVersion $_.rundatetime}



