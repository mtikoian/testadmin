Import-Module SQLPS -DisableNameChecking


cd D:\MSSQLMON\pshell

. ./Invoke-sqlcmd2.ps1

. ./Write-DataTable.ps1

. ./Out-DataTable.ps1

. ./newfunctions.ps1

$MonServer="MSF1vSQL32P"

$MonDBName="TJXSQLDBMON"

# Check for Reporting service

Invoke-sqlcmd2 -ServerInstance $MonServer -Database $MonDBName -Query "SELECT  distinct [SQLSrvrName], [instname], 'SQL Server Reporting Service*' displayname, cast (getdate() as smalldatetime) rundatetime FROM [dbo].[tblSQLsrvr_temp] where SQLSrvrStatus = 'A' and SQLMonAccnt = 'Store'" | foreach-object {GetServiceInstalled $_.SQLSrvrName $_.instname $_.displayname $_.rundatetime}

# Check for Analysis service

Invoke-sqlcmd2 -ServerInstance $MonServer -Database $MonDBName -Query "SELECT  distinct [SQLSrvrName], [instname], 'SQL Server Analysis Service*' displayname, cast (getdate() as smalldatetime) rundatetime FROM [dbo].[tblSQLsrvr_temp] where SQLSrvrStatus = 'A' and SQLMonAccnt = 'Store'" | foreach-object {GetServiceInstalled $_.SQLSrvrName $_.instname $_.displayname $_.rundatetime}

# Check for Integration service

Invoke-sqlcmd2 -ServerInstance $MonServer -Database $MonDBName -Query "SELECT  distinct [SQLSrvrName], [instname], 'SQL Server Integration Service*' displayname, cast (getdate() as smalldatetime) rundatetime FROM [dbo].[tblSQLsrvr_temp] where SQLSrvrStatus = 'A' and  SQLMonAccnt = 'Store'" | foreach-object {GetServiceInstalled $_.SQLSrvrName $_.instname $_.displayname $_.rundatetime}

# Check for SQL Server service

Invoke-sqlcmd2 -ServerInstance $MonServer -Database $MonDBName -Query "SELECT  distinct [SQLSrvrName], [instname], 'MSSQL' displayname, cast (getdate() as smalldatetime) rundatetime FROM [dbo].[tblSQLsrvr_temp] where SQLSrvrStatus = 'A' and  SQLMonAccnt = 'Store'" | foreach-object {GetServiceInstalled $_.SQLSrvrName $_.instname $_.displayname $_.rundatetime}







