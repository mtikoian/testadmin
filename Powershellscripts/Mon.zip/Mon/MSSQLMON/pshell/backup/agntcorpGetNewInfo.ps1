Get-PSSnapin -registered

Add-PSSnapin SqlServerProviderSnapin110

Add-PSSnapin SqlServercmdletSnapin110

