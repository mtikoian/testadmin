function getlastsqlrestart([string] $Hostname,[string] $Instname,[int] $PortNum,[int] $Version, [string] $rundatetime)

{
$MonServer="MSF1VSQL32P"
$MonDBName="TJXSQLDBMON"
try
{
$SqlCatalog="master"
$SqlConnection = New-Object System.Data.SqlClient.SqlConnection
$SqlCmd = New-Object System.Data.SqlClient.SqlCommand
$SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
$DataSet = New-Object System.Data.DataSet
$DataSet2 = New-Object System.Data.DataSet
$DataSet3 = New-Object System.Data.DataSet
$DataSet4 = New-Object System.Data.DataSet
$SqlConnection.ConnectionString = �Server = $Hostname"+","+"$PortNum; Database =$SqlCatalog; Integrated Security = True;Connect Timeout=45;�

$SqlCmd.CommandText = "select crdate from sysdatabases where name = 'tempdb'"
$SqlCmd.Connection = $SqlConnection
$SqlAdapter.SelectCommand = $SqlCmd
$SqlAdapter.Fill($DataSet)|out-null
$recorditems =$DataSet.Tables[0]
}

catch
{return}


foreach ($recorditem in $recorditems)
{


$insertqry="INSERT INTO [dbo].[tblMonLastSQLRestart]([SQLSrvrName],[InstName],[LastRestart],[rundatetime]) VALUES ('"+$Hostname+"','"+$InstName+"','"+$recorditem.crdate+"','"+$rundatetime+"')"

Invoke-SqlCmd -ServerInstance $MonServer -Database $MonDBName -Query $insertqry
$SqlConnection.Close()

}

}









function getbackupstatus([string] $Hostname,[string] $Instname,[int] $PortNum,[int] $Version, [string] $rundatetime)

{
$MonServer="MSF1VSQL32P"
$MonDBName="TJXSQLDBMON"
try
{
$SqlCatalog="master"
$SqlConnection = New-Object System.Data.SqlClient.SqlConnection
$SqlCmd = New-Object System.Data.SqlClient.SqlCommand
$SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
$DataSet = New-Object System.Data.DataSet
$DataSet2 = New-Object System.Data.DataSet
$DataSet3 = New-Object System.Data.DataSet
$DataSet4 = New-Object System.Data.DataSet
$SqlConnection.ConnectionString = �Server = $Hostname"+","+"$PortNum; Database =$SqlCatalog; Integrated Security = True;Connect Timeout=45;�

$SqlCmd.CommandText = "SELECT     name as DBName, DBRecoveryModel, MostRecentBackup, type as BackupType FROM  (SELECT     name, CASE WHEN status & 8 = 8 THEN 'Simple' ELSE 'NotSimple' END DBRecoveryModel FROM master..sysdatabases WHERE (name NOT IN ('tempdb', 'pubs', 'Northwind', 'ReportServerTempDB')) AND ((status & 512) <= 0) AND ((status & 32) <= 0) AND ((status & 1024) <= 0) AND ((status & 128) <= 0) AND ((status & 32768) <= 0)) MasterDB LEFT OUTER JOIN (SELECT     database_name, MAX(backup_finish_date) AS MostRecentBackup, type FROM msdb..backupset GROUP BY database_name, type) DRVBackup ON MasterDB.name = DRVBackup.database_name
UNION
SELECT     name as DBName, DBRecoveryModel, MostRecentBackup, type as BackupType FROM  (SELECT     name, CASE WHEN status & 8 = 8 THEN 'Simple' ELSE 'NotSimple' END DBRecoveryModel FROM master..sysdatabases WHERE (name NOT IN ('tempdb', 'pubs', 'Northwind', 'ReportServerTempDB')) AND ((status & 512) <= 0) AND ((status & 32) <= 0) AND ((status & 1024) <= 0) AND ((status & 128) <= 0) AND ((status & 32768) <= 0)) MasterDB LEFT OUTER JOIN (SELECT     database_name, MAX(backup_finish_date) AS MostRecentBackup, type FROM msdb..backupset GROUP BY database_name, type having type = 'D') DRVBackup ON MasterDB.name = DRVBackup.database_name order by name"
$SqlCmd.Connection = $SqlConnection
$SqlAdapter.SelectCommand = $SqlCmd
$SqlAdapter.Fill($DataSet)|out-null
$backups =$DataSet.Tables[0]
}

catch
{return}


foreach ($backup in $backups)
{

if (is-null $backup.MostRecentBackup)
{
$insertqry="INSERT INTO [dbo].[tblMonBackupStatus]([SQLSrvrName],[InstName],[DBName],[DBRecoveryModel],[MostRecentBackup],[BackupType]) VALUES ('"+$Hostname+"','"+$InstName+"','"+$backup.DBName+"','"+$backup.DBRecoveryModel+"',NULL,'"+$backup.backuptype+"')"
}
else
{
$insertqry="INSERT INTO [dbo].[tblMonBackupStatus]([SQLSrvrName],[InstName],[DBName],[DBRecoveryModel],[MostRecentBackup],[BackupType]) VALUES ('"+$Hostname+"','"+$InstName+"','"+$backup.DBName+"','"+$backup.DBRecoveryModel+"','"+$backup.MostRecentBackup+"','"+$backup.backuptype+"')"
}
Invoke-SqlCmd -ServerInstance $MonServer -Database $MonDBName -Query $insertqry
$SqlConnection.Close()

}

}




Function getdriveinfo  ([string] $Hostname, [string] $rundatetime)
{
$MonServer="MSF1VSQL32P"
$MonDBName="TJXSQLDBMON"


$drives=Get-WmiObject -computername $hostname -class Win32_LogicalDisk -filter "DriveType=3"|Select-Object -property DeviceID,@{label='DriveSpaceMB';expression={$_.size / 1MB -as [int]}},@{label='FreeSpaceMB';expression={$_.FreeSpace / 1MB -as [int]}}


 if ($?)
{

foreach ($drive in $drives)
{
$insertqry="exec uspUpdateDriveInfo '"+$Hostname+"','"+$drive.DeviceID+"','"+$drive.DriveSpaceMB+"','"+$rundatetime+"'"
Invoke-SqlCmd -ServerInstance $MonServer -Database $MonDBName -Query $insertqry
}
GetMountPointInfo $Hostname $rundatetime

}
}





function GetMountPointInfo([string] $Hostname, [string] $rundatetime) 
{

$MonServer="MSF1VSQL32P"
$MonDBName="TJXSQLDBMON"

       
        $objFSO = New-Object -com Scripting.FileSystemObject
        $MountPoints = gwmi -class "win32_mountpoint" -namespace "root\cimv2" -computername $Hostname

 if ($?)
{
        $Volumes = gwmi -class "win32_volume" -namespace "root/cimv2" -ComputerName $Hostname| select name, freespace



        foreach ($MP in $Mountpoints) {
                $MP.directory = $MP.directory.replace("\\","\")        
                foreach ($v in $Volumes) {
                        $vshort = $v.name.Substring(0,$v.name.length-1 )
                        $vshort = """$vshort""" #Make it look like format in $MP (line 11).
                        if ($mp.directory.contains($vshort)) { #only queries mountpoints that exist as drive volumes no system
                                $DestFolder = "\\"+$Hostname + "\"+ $v.name.Substring(0,$v.name.length-1 ).Replace(":","$")
                                #$destFolder #troubleshooting string to verify building dest folder correctly.
                                $colItems = (Get-ChildItem $destfolder |  where{$_.length -ne $null} |Measure-Object -property length -sum)
                                #to clean up errors when folder contains no files.
                                #does not take into account subfolders.
                               
                                if($colItems.sum -eq $null) {
                                        $fsize = 0
                                } else {
                                        $fsize = $colItems.sum
                                }
                               
                                $TotFolderSize = $fsize + $v.freespace
                                $insertqry="exec uspUpdateDriveInfo '"+$Hostname+"','"+$V.name+"','"+[int]($TotFolderSize/1MB)+"','"+$rundatetime+"'"

Invoke-SqlCmd -ServerInstance $MonServer -Database $MonDBName -Query $insertqry
                        }
                }
        }
}
}




function getdriveinfobhfirewall ([string] $Hostname,[string] $Instname,[int] $PortNum,[int] $Version, [string] $rundatetime)

{
$MonServer="MSF1VSQL32P"
$MonDBName="TJXSQLDBMON"
try
{
$SqlCatalog="master"
$SqlConnection = New-Object System.Data.SqlClient.SqlConnection
$SqlCmd = New-Object System.Data.SqlClient.SqlCommand
$SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
$DataSet = New-Object System.Data.DataSet
$DataSet2 = New-Object System.Data.DataSet
$DataSet3 = New-Object System.Data.DataSet
$DataSet4 = New-Object System.Data.DataSet
$SqlConnection.ConnectionString = �Server = $Hostname"+","+"$PortNum; Database =$SqlCatalog; Integrated Security = True;Connect Timeout=5;�

$SqlCmd.CommandText = "
SET NOCOUNT ON

DECLARE @OLEAUTOPROC int
DECLARE @SHOWADVOPT int

DECLARE @OLEAUTOPROCCHANGED int
DECLARE @SHOWADVOPTCHANGED int
SET @OLEAUTOPROCCHANGED = 0
SET @SHOWADVOPTCHANGED = 0


select @OLEAUTOPROC = value from sysconfigures where comment like 'Enable or disable Ole Automation Procedures'

IF @OLEAUTOPROC = 0
BEGIN
select @SHOWADVOPT = value from sysconfigures where comment = 'show advanced options'

IF @SHOWADVOPT = 0
BEGIN
exec sp_configure 'show advanced options',1
reconfigure with override
SET @SHOWADVOPTCHANGED = 1
END

exec sp_configure 'Ole Automation Procedures',1
reconfigure with override
SET @OLEAUTOPROCCHANGED = 1

END

DECLARE @hr int

DECLARE @fso int

DECLARE @drive char(1)

DECLARE @odrive int

DECLARE @TotalSize varchar(20)

DECLARE @MB bigint ; SET @MB = 1048576

CREATE TABLE #drives (drive char(1) PRIMARY KEY,

FreeSpace int NULL,

TotalSize int NULL)

INSERT #drives(drive,FreeSpace)

EXEC master.dbo.xp_fixeddrives

EXEC @hr=sp_OACreate 'Scripting.FileSystemObject',@fso OUT

IF @hr <> 0 EXEC sp_OAGetErrorInfo @fso

DECLARE dcur CURSOR LOCAL FAST_FORWARD

FOR SELECT drive from #drives

ORDER by drive

OPEN dcur

FETCH NEXT FROM dcur INTO @drive

WHILE @@FETCH_STATUS=0

BEGIN

EXEC @hr = sp_OAMethod @fso,'GetDrive', @odrive OUT, @drive

IF @hr <> 0 EXEC sp_OAGetErrorInfo @fso

EXEC @hr = sp_OAGetProperty @odrive,'TotalSize', @TotalSize OUT

IF @hr <> 0 EXEC sp_OAGetErrorInfo @odrive

UPDATE #drives

SET TotalSize=@TotalSize/@MB

WHERE drive=@drive

FETCH NEXT FROM dcur INTO @drive

END

CLOSE dcur

DEALLOCATE dcur

EXEC @hr=sp_OADestroy @fso

IF @hr <> 0 EXEC sp_OAGetErrorInfo @fso

SELECT drive as DeviceID,

TotalSize as DriveSpaceMB

FROM #drives

ORDER BY drive

DROP TABLE #drives

IF @OLEAUTOPROCCHANGED = 1
BEGIN
exec sp_configure 'Ole Automation Procedures',0
reconfigure with override
END

IF @SHOWADVOPTCHANGED =1
BEGIN
exec sp_configure 'show advanced options',0
reconfigure with override 
END
"
$SqlCmd.Connection = $SqlConnection
$SqlAdapter.SelectCommand = $SqlCmd
$SqlAdapter.Fill($DataSet)|out-null
$drives =$DataSet.Tables[0]
}

catch
{return}


foreach ($drive in $drives)
{
$insertqry="exec uspUpdateDriveInfo '"+$Hostname+"','"+$drive.DeviceID+":','"+$drive.DriveSpaceMB+"','"+$rundatetime+"'"
Invoke-SqlCmd -ServerInstance $MonServer -Database $MonDBName -Query $insertqry

$SqlConnection.Close()

}

}




function getblockinginfo([string] $Hostname,[string] $Instname,[int] $PortNum,[int] $Version, [string] $rundatetime)

{
$MonServer="MSF1VSQL32P"
$MonDBName="TJXSQLDBMON"
try
{
$SqlCatalog="master"
$SqlConnection = New-Object System.Data.SqlClient.SqlConnection
$SqlCmd = New-Object System.Data.SqlClient.SqlCommand
$SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
$DataSet = New-Object System.Data.DataSet
$DataSet2 = New-Object System.Data.DataSet
$DataSet3 = New-Object System.Data.DataSet
$DataSet4 = New-Object System.Data.DataSet
$SqlConnection.ConnectionString = �Server = $Hostname"+","+"$PortNum; Database =$SqlCatalog; Integrated Security = True;Connect Timeout=5;�

$SqlCmd.CommandText = "select distinct spid,hostname,db_name(dbid) As 'DBName' ,loginame,blocked,program_name,status,SQL=convert (char (150),cmd), login_time, last_batch from master.dbo.sysprocesses Where status <> 'background'and cmd not in ('signal handler','lock monitor','log writer','lazy writer','checkpoint sleep','awaiting command') and blocked <>0 and waittime> 300000
UNION
select distinct spid,hostname,db_name(dbid) As 'DBName' ,loginame,blocked,program_name,status,SQL=convert (char (150),cmd), login_time, last_batch  from master.dbo.sysprocesses where spid in (select distinct blocked from master.dbo.sysprocesses Where status <> 'background'and cmd not in ('signal handler','lock monitor','log writer','lazy writer','checkpoint sleep','awaiting command') and blocked <>0 and waittime> 300000)
"
$SqlCmd.Connection = $SqlConnection
$SqlAdapter.SelectCommand = $SqlCmd
$SqlAdapter.Fill($DataSet)|out-null
$blockedspids =$DataSet.Tables[0]
}

catch
{return}


foreach ($blockedspid in $blockedspids)
{

$insertqry="INSERT INTO [dbo].[tblMonBlockedspids]([SQLSrvrName],[InstName],[spid],[hostname],[DBName],[loginname],[blocked],[programname],[SPIDStatus],[SQLStmnt],[login_time],[last_batch],[rundatetime]) VALUES ('"+$Hostname+"','"+$InstName+"','"+$blockedspid.spid+"','"+$blockedspid.hostname+"','"+$blockedspid.DBName+"','"+$blockedspid.loginame+"','"+$blockedspid.blocked+"','"+$blockedspid.program_name+"','"+$blockedspid.Status+"','"+$blockedspid.SQL+"','"+$blockedspid.login_time+"','"+$blockedspid.last_batch+"','"+$rundatetime+"')"

Invoke-SqlCmd -ServerInstance $MonServer -Database $MonDBName -Query $insertqry
$SqlConnection.Close()

}

}



function getdbinfo([string] $Hostname,[string] $Instname,[int] $PortNum,[int] $Version, [string] $rundatetime)

{
$MonServer="MSF1VSQL32P"
$MonDBName="TJXSQLDBMON"

$SqlCatalog="master"
$SqlConnection = New-Object System.Data.SqlClient.SqlConnection
$SqlCmd = New-Object System.Data.SqlClient.SqlCommand
$SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
$DataSet = New-Object System.Data.DataSet
$DataSet2 = New-Object System.Data.DataSet
$DataSet3 = New-Object System.Data.DataSet
$DataSet4 = New-Object System.Data.DataSet
$SqlConnection.ConnectionString = �Server = $Hostname"+","+"$PortNum; Database =$SqlCatalog; Integrated Security = True;Connect Timeout=45;�

$SqlCmd.CommandText = "select name,DATABASEPROPERTYEX(name, 'Status') DBStatus, DATABASEPROPERTYEX(name, 'Collation') DBCollation, DATABASEPROPERTYEX(name, 'Recovery') RecoveryModel,DATABASEPROPERTYEX(name, 'IsAutoClose') AutoClose,DATABASEPROPERTYEX(name, 'IsAutoCreateStatistics') AutoCreateStats,DATABASEPROPERTYEX(name, 'IsAutoShrink') AutoShrink,DATABASEPROPERTYEX(name, 'IsAutoUpdateStatistics') AutoUpdateStats,DATABASEPROPERTYEX(name, 'IsPublished') IsPublished,DATABASEPROPERTYEX(name, 'IsSubscribed') IsSubscribed, cmptlevel from sysdatabases"
$SqlCmd.Connection = $SqlConnection
$SqlAdapter.SelectCommand = $SqlCmd
$SqlAdapter.Fill($DataSet)|out-null
$dbs =$DataSet.Tables[0]


foreach ($db in $dbs)
{

#$insertqry="INSERT INTO [dbo].[tblGetDBInfo]([SQLSrvrName],[InstName],[DBName],[RecoveryModel],[DBStatus],[AutoClose],[AutoCreateStats],[AutoShrink],[AutoUpdateStats],[IsPublished],[IsSubscribed],[DBCollation],rundatetime) VALUES ('"+$Hostname+"','"+$InstName+"','"+$db.name+"','"+$db.RecoveryModel+"','"+$db.DBStatus+"','"+$db.AutoClose+"','"+$db.AutoCreateStats+"','"+$db.AutoShrink+"','"+$db.AutoUpdateStats+"','"+$db.IsPublished+"','"+$db.IsSubscribed+"','"+$db.DBCollation+"','"+$rundatetime+"')"

$insertqry="Exec uspUpdateDBInfo '"+$Hostname+"','"+$InstName+"','"+$db.name+"','"+$db.RecoveryModel+"','"+$db.DBStatus+"','"+$db.AutoClose+"','"+$db.AutoCreateStats+"','"+$db.AutoShrink+"','"+$db.AutoUpdateStats+"','"+$db.IsPublished+"','"+$db.IsSubscribed+"','"+$db.DBCollation+"','"+$db.cmptlevel+"','"+$rundatetime+"'"

Invoke-SqlCmd -ServerInstance $MonServer -Database $MonDBName -Query $insertqry
$SqlConnection.Close()

}

}



Function checksqlconn  ([string] $Hostname,[string] $Instname,[int] $PortNum,[decimal] $Version, [string] $rundatetime)
{
$MonServer="MSF1VSQL32P"
$MonDBName="TJXSQLDBMON"

$SqlCatalog="master"
$SqlConnection = New-Object System.Data.SqlClient.SqlConnection
$SqlConnection.ConnectionString = �Server = $Hostname"+","+"$PortNum; Database =$SqlCatalog; Integrated Security = True;Connect Timeout=45;�
$SqlConnection.Open()
if($SqlConnection.state -eq �Open�)
{

$insertqry="INSERT INTO [dbo].[tblMonSQLConnect] ([SQLSrvrName],[InstName],[SSDEPortNum],[Status],[RunDateTime]) VALUES ('"+$Hostname+"','"+$InstName+"','"+$PortNum+"',1,'"+$rundatetime+"')"
Invoke-SqlCmd -ServerInstance $MonServer -Database $MonDBName -Query $insertqry
$SqlConnection.Close()
}

else
{
$ErrDetails=$error[0]
$insertqry="INSERT INTO [dbo].[tblMonSQLConnect] ([SQLSrvrName],[InstName],[SSDEPortNum],[Status],[ErrMsage],[RunDateTime]) VALUES ('"+$Hostname+"','"+$InstName+"','"+$PortNum+"',0,'"+$ErrDetails+"','"+$rundatetime+"')"
Invoke-SqlCmd -ServerInstance $MonServer -Database $MonDBName -Query $insertqry
$SqlConnection.Close()
}

}



Function rechecksqlconn  ([string] $Hostname,[string] $Instname,[int] $PortNum,[decimal] $Version, [string] $rundatetime)
{
$MonServer="MSF1VSQL32P"
$MonDBName="TJXSQLDBMON"

$SqlCatalog="master"
$SqlConnection = New-Object System.Data.SqlClient.SqlConnection
$SqlConnection.ConnectionString = �Server = $Hostname"+","+"$PortNum; Database =$SqlCatalog; Integrated Security = True;Connect Timeout=45;�
$SqlConnection.Open()
if($SqlConnection.state -eq �Open�)
{

$insertqry="Update [dbo].[tblMonSQLConnect] Set [Status] = 1,[ErrMsage] = NULL Where [SQLSrvrName] = '"+$Hostname+"' and [InstName] = '"+$InstName+"'"
Invoke-SqlCmd -ServerInstance $MonServer -Database $MonDBName -Query $insertqry
$SqlConnection.Close()
}

else
{

$SqlConnection.Close()
}

}





Function checkservices  ([string] $Hostname,[string] $Instname,[string] $ServiceType,[decimal] $Version, [datetime] $rundatetime)
{
$MonServer="MSF1VSQL32P"
$MonDBName="TJXSQLDBMON"

if($ServiceType -eq "SSDE" -and $Instname -eq "DEFAULT")
{$ChkServicename="MSSQLSERVER"}
elseif($ServiceType -eq "SSDE" -and $Instname -ne "DEFAULT")
{$ChkServicename="MSSQL$"+$Instname}
elseif($ServiceType -eq "AGNT" -and $Instname -eq "DEFAULT")
{$ChkServicename="SQLServerAgent"}
elseif($ServiceType -eq "AGNT" -and $Instname -ne "DEFAULT")
{$ChkServicename="SQLAgent$"+$Instname}
elseif($ServiceType -eq "SSRS" -and $Instname -eq "DEFAULT")
{$ChkServicename="ReportServer"}
elseif($ServiceType -eq "SSRS" -and $Instname -ne "DEFAULT")
{$ChkServicename="ReportServer$"+$Instname}
elseif($ServiceType -eq "SSAS" -and $Instname -eq "DEFAULT")
{$ChkServicename="MSSQLServerOLAPService"}
elseif($ServiceType -eq "SSAS" -and $Instname -ne "DEFAULT")
{$ChkServicename="MSOLAP$"+$Instname}
elseif($ServiceType -eq "SSIS" -and $Version -le "9.99")
{$ChkServicename="MsDtsServer"}
elseif($ServiceType -eq "SSIS" -and $Version -ge "10.00")
{$ChkServicename="MsDtsServer100"}
elseif($ServiceType -eq "SYBASE")
{$ChkServicename="SYBSQL_"+$Hostname}
elseif($ServiceType -eq "SYBCKP")
{$ChkServicename="SYBBCK_"+$Hostname+"_BS"}
else
{return}

$Services=get-wmiobject -class win32_service -computername $hostname| where {$_.name -eq $ChkServicename}| select-object Name,state,status,Started,Startname,Description
 if (!$?)
{
$ErrDetails=$error[0]
$SpecialChars = "'"
$SpecialChars |% {$ErrDetails = $ErrDetails -replace $_,""}
$insertqry="INSERT INTO [dbo].[tblMonServiceStatus] ([SQLSrvrName],[InstName],[ServiceType],[Status],[ErrMsage],[RunDateTime]) VALUES ('"+$Hostname+"','"+$InstName+"','"+$ServiceType+"',0,'"+$ErrDetails+"','"+$rundatetime+"')"
Invoke-SqlCmd -ServerInstance $MonServer -Database $MonDBName -Query $insertqry
return
}
else
{

foreach ( $service in $Services)
{
if($service.state -ne "Running" -or  $service.status -ne "OK" -or $service.started -ne "True" )
{
$ErrDetails="State: "+$service.state+" Status: "+$service.status+" Started: "+$service.started
$insertqry="INSERT INTO [dbo].[tblMonServiceStatus] ([SQLSrvrName],[InstName],[ServiceType],[Status],[ErrMsage],[RunDateTime]) VALUES ('"+$Hostname+"','"+$InstName+"','"+$ServiceType+"',0,'"+$ErrDetails+"','"+$rundatetime+"')"
Invoke-SqlCmd -ServerInstance $MonServer -Database $MonDBName -Query $insertqry
}
else
{
$insertqry="INSERT INTO [dbo].[tblMonServiceStatus] ([SQLSrvrName],[InstName],[ServiceType],[Status],[RunDateTime]) VALUES ('"+$Hostname+"','"+$InstName+"','"+$ServiceType+"',1,'"+$rundatetime+"')"
Invoke-SqlCmd -ServerInstance $MonServer -Database $MonDBName -Query $insertqry
}
}

}
}





Function checkdrivespace  ([string] $Hostname, [string] $rundatetime)
{
$MonServer="MSF1VSQL32P"
$MonDBName="TJXSQLDBMON"


$drives=Get-WmiObject -computername $hostname -class Win32_LogicalDisk -filter "DriveType=3"|Select-Object -property DeviceID,@{label='DriveSpaceMB';expression={$_.size / 1MB -as [int]}},@{label='FreeSpaceMB';expression={$_.FreeSpace / 1MB -as [int]}}


 if (!$?)
{
$ErrDetails=$error[0]
$insertqry="INSERT INTO [dbo].[tblMonDriveSpace] ([SQLSrvrName],[ErrMsage],[RunDateTime]) VALUES ('"+$Hostname+"','"+$ErrDetails+"','"+$rundatetime+"')"
Invoke-SqlCmd -ServerInstance $MonServer -Database $MonDBName -Query $insertqry
return
}
else
{

foreach ($drive in $drives)
{
$insertqry="INSERT INTO [dbo].[tblMonDriveSpace] ([SQLSrvrName],[DriveLetter],[DriveSpaceMB],[FreeSpaceMB],[RunDateTime]) VALUES ('"+$Hostname+"','"+$drive.DeviceID+"','"+$drive.DriveSpaceMB+"','"+$drive.FreeSpaceMB+"','"+$rundatetime+"')"
Invoke-SqlCmd -ServerInstance $MonServer -Database $MonDBName -Query $insertqry
}
CheckMountPointSpace $Hostname $rundatetime

}
}



function CheckMountPointSpace([string] $Hostname, [string] $rundatetime) 
{

$MonServer="MSF1VSQL32P"
$MonDBName="TJXSQLDBMON"

    
        $objFSO = New-Object -com Scripting.FileSystemObject
        $MountPoints = gwmi -class "win32_mountpoint" -namespace "root\cimv2" -computername $Hostname


 if (!$?)
{
return
}

else
{
        $Volumes = gwmi -class "win32_volume" -namespace "root/cimv2" -ComputerName $Hostname| select name, freespace



        foreach ($MP in $Mountpoints) {
                $MP.directory = $MP.directory.replace("\\","\")        
                foreach ($v in $Volumes) {
                        $vshort = $v.name.Substring(0,$v.name.length-1 )
                        $vshort = """$vshort""" #Make it look like format in $MP (line 11).
                        if ($mp.directory.contains($vshort)) { #only queries mountpoints that exist as drive volumes no system
                                $DestFolder = "\\"+$Hostname + "\"+ $v.name.Substring(0,$v.name.length-1 ).Replace(":","$")
                                #$destFolder #troubleshooting string to verify building dest folder correctly.
                                $colItems = (Get-ChildItem $destfolder |  where{$_.length -ne $null} |Measure-Object -property length -sum)
                                #to clean up errors when folder contains no files.
                                #does not take into account subfolders.
                               
                                if($colItems.sum -eq $null) {
                                        $fsize = 0
                                } else {
                                        $fsize = $colItems.sum
                                }
                               
                                $TotFolderSize = $fsize + $v.freespace
                                $insertqry="INSERT INTO [dbo].[tblMonDriveSpace] ([SQLSrvrName],[DriveLetter],[DriveSpaceMB],[FreeSpaceMB],[RunDateTime]) VALUES ('"+$Hostname+"','"+$V.name+"','"+[int]($TotFolderSize/1MB)+"','"+[int]($v.freespace/1MB)+"','"+$rundatetime+"')"

Invoke-SqlCmd -ServerInstance $MonServer -Database $MonDBName -Query $insertqry
                        }
                }
        }

}

}






function checkxp_fixeddrivespace ([string] $Hostname,[string] $Instname,[int] $PortNum,[int] $Version, [string] $rundatetime)

{
$MonServer="MSF1VSQL32P"
$MonDBName="TJXSQLDBMON"
try
{
$SqlCatalog="master"
$SqlConnection = New-Object System.Data.SqlClient.SqlConnection
$SqlCmd = New-Object System.Data.SqlClient.SqlCommand
$SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
$DataSet = New-Object System.Data.DataSet
$DataSet2 = New-Object System.Data.DataSet
$DataSet3 = New-Object System.Data.DataSet
$DataSet4 = New-Object System.Data.DataSet
$SqlConnection.ConnectionString = �Server = $Hostname"+","+"$PortNum; Database =$SqlCatalog; Integrated Security = True;Connect Timeout=5;�

$SqlCmd.CommandText = "exec xp_fixeddrives"
$SqlCmd.Connection = $SqlConnection
$SqlAdapter.SelectCommand = $SqlCmd
$SqlAdapter.Fill($DataSet)|out-null
$drives =$DataSet.Tables[0]
}

catch
{
$ErrDetails=$error[0]
$insertqry="INSERT INTO [dbo].[tblMonDriveSpace] ([SQLSrvrName],[ErrMsage],[RunDateTime]) VALUES ('"+$Hostname+"','"+$ErrDetails+"','"+$rundatetime+"')"
Invoke-SqlCmd -ServerInstance $MonServer -Database $MonDBName -Query $insertqry
return
}


foreach ($drive in $drives)
{
$insertqry="INSERT INTO [dbo].[tblMonDriveSpace] ([SQLSrvrName],[DriveLetter],[DriveSpaceMB],[FreeSpaceMB],[RunDateTime]) VALUES ('"+$Hostname+"','"+$drive.drive+":',NULL,'"+$drive.{MB free}+"','"+$rundatetime+"')"
Invoke-SqlCmd -ServerInstance $MonServer -Database $MonDBName -Query $insertqry
$SqlConnection.Close()
}


}





function checkdbstatus([string] $Hostname,[string] $Instname,[int] $PortNum,[int] $Version, [string] $rundatetime)

{
$MonServer="MSF1VSQL32P"
$MonDBName="TJXSQLDBMON"

try
{
$SqlCatalog="master"
$SqlConnection = New-Object System.Data.SqlClient.SqlConnection
$SqlCmd = New-Object System.Data.SqlClient.SqlCommand
$SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
$DataSet = New-Object System.Data.DataSet
$DataSet2 = New-Object System.Data.DataSet
$DataSet3 = New-Object System.Data.DataSet
$DataSet4 = New-Object System.Data.DataSet
$SqlConnection.ConnectionString = �Server = $Hostname"+","+"$PortNum; Database =$SqlCatalog; Integrated Security = True;Connect Timeout=15;�

$SqlCmd.CommandText = "SELECT name, DATABASEPROPERTYEX(name,'Status') dbstatus FROM sysdatabases"
$SqlCmd.Connection = $SqlConnection
$SqlAdapter.SelectCommand = $SqlCmd
$SqlAdapter.Fill($DataSet)|out-null
$dbs =$DataSet.Tables[0]
}

catch
{

$ErrDetails=$error[0]

$insertqry="INSERT INTO [dbo].[tblMonDBStatus]([SQLSrvrName],[InstName],[ErrMsage],[RunDateTime]) VALUES ('"+$Hostname+"','"+$InstName+"','"+$ErrDetails+"','"+$rundatetime+"')"
Invoke-SqlCmd -ServerInstance $MonServer -Database $MonDBName -Query $insertqry
$SqlConnection.Close()

return}


foreach ($db in $dbs)
{

$insertqry="INSERT INTO [dbo].[tblMonDBStatus]([SQLSrvrName],[InstName],[DBName],[ActualDBStatus],[RunDateTime]) VALUES ('"+$Hostname+"','"+$InstName+"','"+$db.name+"','"+$db.dbstatus+"','"+$rundatetime+"')"
Invoke-SqlCmd -ServerInstance $MonServer -Database $MonDBName -Query $insertqry
$SqlConnection.Close()

}

}





Function checkdbfileusage  ([string] $Hostname,[string] $Instname,[int] $PortNum,[int] $Version, [string] $rundatetime)
{
$MonServer="MSF1VSQL32P"
$MonDBName="TJXSQLDBMON"



$SqlConnection = New-Object System.Data.SqlClient.SqlConnection
$SqlCmd = New-Object System.Data.SqlClient.SqlCommand
$SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
$DataSet = New-Object System.Data.DataSet
$SqlConnection.ConnectionString = �Server = $Hostname"+","+"$PortNum; Database =$SqlCatalog; Integrated Security = True;Connect Timeout=45;�
$SqlCmd.CommandText = "select name from master.dbo.sysdatabases"
$SqlCmd.Connection = $SqlConnection
$SqlAdapter.SelectCommand = $SqlCmd
$SqlAdapter.Fill($DataSet)|out-null
$dbs =$DataSet.Tables[0]


$dbs | foreach-object {
$insertqry = "SELECT '"+$Hostname+"' as SQLSrvrName,'"+$InstName+"' as InstName,'"+$_.name+"' as DBName, name as LogicalFileName, groupid, CASE WHEN status & 0x40 = 64 Then 'LOG' ELSE 'DATA'END AS FileType, maxsize, CEILING(size * 8 / 1024.) AS CurrSizeMB, floor(size/128.0 - CAST(FILEPROPERTY(name, 'SpaceUsed') AS int)/128.0) AS FreeSpaceMB, CASE WHEN status & 0x100000 > 0 THEN growth ELSE NULL END AS GrowthPRCNT, CASE WHEN status & 0x100000 = 0 THEN CEILING(growth * 8 / 1024.) END AS GrowthMB ,'"+$rundatetime+"' as rundatetime FROM sysfiles"

$SQLINST=$Hostname+","+$PortNum

$dt = Invoke-SqlCmd -ServerInstance $SQLINST -Database $_.name -Query $insertqry | % { $_.PSADAPTED } | out-datatable

#Add-SqlTable -ServerInstance $MonServer -Database $MonDBName -TableName "tblMonDBFileSize1" -DataTable $dt

Write-DataTable -ServerInstance $MonServer -Database $MonDBName -TableName "tblMonDBFileSize" -Data $dt


}

}



Function checklastreboot  ([string] $Hostname, [string] $rundatetime)
{

$MonServer="MSF1VSQL32P"
$MonDBName="TJXSQLDBMON"

$date = Get-WmiObject Win32_OperatingSystem -computername $Hostname | foreach{$_.LastBootUpTime}
$RebootTime = [System.DateTime]::ParseExact($date.split('.')[0],'yyyyMMddHHmmss',$null)

$insertqry="INSERT INTO [dbo].[tblMonSrvrLastReboot] ([SQLSrvrName],[LastRebootDT],[RunDateTime]) VALUES ('"+$Hostname+"','"+$RebootTime+"','"+$rundatetime+"')"
Invoke-SqlCmd -ServerInstance $MonServer -Database $MonDBName -Query $insertqry

}



Function getsrvrinfo ([string] $Hostname, [string] $rundatetime)
{

$MonServer="MSF1VSQL32P"
$MonDBName="TJXSQLDBMON"

$computer=get-wmiobject -class win32_computersystem -computername $hostname
$os=get-wmiobject -class win32_operatingsystem -computername $hostname
$cpuinfo=Get-WmiObject -Class Win32_Processor -computername $hostname 

if (!$?)
{
$ErrDetails=$error[0]

$SpecialChars = "'"

$SpecialChars |% {$ErrDetails = $ErrDetails -replace $_,""}

#$insertqry="INSERT INTO [dbo].[tblGetSrvrInfo] ([Srvrname],[ErrMsage],[RunDateTime]) VALUES ('"+$Hostname+"','"+$ErrDetails+"','"+$rundatetime+"')"

#$insertqry="exec uspUpdateSrvrInfo @SQLSrvrName = '"+$Hostname+"', @ErrMsage = '"+$ErrDetails+"',@rundatetime = '"+$rundatetime+"'"

Invoke-SqlCmd -ServerInstance $MonServer -Database $MonDBName -Query $insertqry
return
}
else
{

if (@($cpuinfo)[0].NumberOfCores)
    {
        $cores = @($cpuinfo).count * @($cpuinfo)[0].NumberOfCores
    }
    else
    {
        $cores = @($cpuinfo).count
    }
    $sockets = @(@($cpuinfo) |
    % {$_.SocketDesignation} |
    select-object -unique).count;


foreach($cpu in $cpuinfo) {
$cpuname=$cpu.Name
$cpuspeed=$cpu.CurrentClockSpeed
$cpuarch=$cpu.Architecture
$cpuaddrwidth=$cpu.AddressWidth

}



#$insertqry="INSERT INTO [dbo].[tblGetSrvrInfo] ([Srvrname],[DomainName],[Sockets],[Cores],[CPUType],[CPUCurrSpeedMhz],[CPUArch],[SystemType],[PhysicalMemoryMB],[Model],[Manufacturer],[TimeZoneVal],[DaylightInEffect],OSBuildNumber,OSCaption,OSVersion,TotalVirtualMemMB,PAEEnabled,[ErrMsage],[RunDateTime]) VALUES ('"+$Hostname+"','"+$computer.Domain+"','"+$sockets+"','"+$cores+"','"+$cpuname+"','"+$cpuspeed+"','"+$cpuarch+"','"+$cpuaddrwidth+"','"+[int]($computer.TotalPhysicalMemory/1mb)+"','"+$computer.Model+"','"+$computer.Manufacturer+"','"+$computer.CurrentTimeZone+"','"+$computer.DaylightInEffect+"','"+$os.BuildNumber+"','"+$os.Caption+"','"+$os.Version+"','"+[int]($os.TotalVirtualMemorySize/1kb)+"','"+$os.PAEEnabled+"','0','"+$rundatetime+"')"

$insertqry="exec uspUpdateSrvrInfo '"+$Hostname+"','"+$computer.Domain+"','"+$sockets+"','"+$cores+"','"+$cpuname+"','"+$cpuspeed+"','"+$cpuarch+"','"+$cpuaddrwidth+"','"+[int]($computer.TotalPhysicalMemory/1mb)+"','"+$computer.Model+"','"+$computer.Manufacturer+"','"+$computer.CurrentTimeZone+"','"+$computer.DaylightInEffect+"','"+$os.BuildNumber+"','"+$os.Caption+"','"+$os.Version+"','"+[int]($os.TotalVirtualMemorySize/1kb)+"','"+$os.PAEEnabled+"','0','"+$rundatetime+"'"

Invoke-SqlCmd -ServerInstance $MonServer -Database $MonDBName -Query $insertqry


}
}



function GetSQLInstInfo ([string] $Hostname,[string] $Instname,[int] $PortNum,[int] $Version, [string] $rundatetime)

{
$MonServer="MSF1VSQL32P"
$MonDBName="TJXSQLDBMON"

try
{
$SqlCatalog="master"
$SqlConnection = New-Object System.Data.SqlClient.SqlConnection
$SqlCmd = New-Object System.Data.SqlClient.SqlCommand
$SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
$DataSet = New-Object System.Data.DataSet
$DataSet2 = New-Object System.Data.DataSet
$DataSet3 = New-Object System.Data.DataSet
$DataSet4 = New-Object System.Data.DataSet
$SqlConnection.ConnectionString = �Server = $Hostname"+","+"$PortNum; Database =$SqlCatalog; Integrated Security = True;Connect Timeout=45;�

$SqlCmd.CommandText = "SELECT CONVERT(varchar(100), SERVERPROPERTY('ProductVersion')) as ProductVersion, CONVERT(varchar(100), SERVERPROPERTY('Collation')) as InstCollation,CONVERT(varchar(100), SERVERPROPERTY('Edition')) as ProductEdition, CONVERT(char(20), SERVERPROPERTY('ProductLevel')) as ProductLevel,CONVERT(char(20), SERVERPROPERTY('LCID')) as LCID,CONVERT(char(20), SERVERPROPERTY('IsIntegratedSecurityOnly')) AS IsIntegratedSecurityOnly, CONVERT(char(20), SERVERPROPERTY('IsFullTextInstalled')) AS IsFullTextInstalled, CONVERT(char(20), SERVERPROPERTY('IsClustered')) AS IsClustered, CONVERT(char(20), SERVERPROPERTY('BuildClrVersion'))  AS BuildClrVersion"
$SqlCmd.Connection = $SqlConnection
$SqlAdapter.SelectCommand = $SqlCmd
$SqlAdapter.Fill($DataSet)|out-null
$dbs =$DataSet.Tables[0]
}

	catch
	{

$ErrDetails=$error[0]

$SpecialChars = "'"

$SpecialChars |% {$ErrDetails = $ErrDetails -replace $_,""}


#$insertqry="INSERT INTO [dbo].[tblGetSQLInstInfo]([SQLSrvrName],[InstName],[ErrMsage],[RunDateTime]) VALUES ('"+$Hostname+"','"+$InstName+"','"+$ErrDetails+"','"+$rundatetime+"')"

$insertqry="exec uspUpdateSQLSrvrInfo @SQLSrvrName = '"+$Hostname+"',@InstName = '"+$InstName+"',@ErrMsage = '"+$ErrDetails+"',@rundatetime = '"+$rundatetime+"'"
write-host $insertqry
Invoke-SqlCmd -ServerInstance $MonServer -Database $MonDBName -Query $insertqry

$SqlConnection.Close()
return

	}

$dbs | foreach-object {
#$insertqry="INSERT INTO [dbo].[tblGetSQLInstInfo]([SQLSrvrName],[InstName],[ProductVersion],[ProductEdition], [InstCollation],[RunDateTime]) VALUES ('"+$Hostname+"','"+$InstName+"','"+$_.ProductVersion+"','"+$_.ProductEdition+"','"+$_.InstCollation+"','"+$rundatetime+"')"
$insertqry="exec uspUpdateSQLSrvrInfo '"+$Hostname+"','"+$InstName+"','"+$_.ProductVersion+"','"+$_.ProductLevel+"','"+$_.ProductEdition+"','"+$_.InstCollation+"','"+$_.LCID+"','"+$_.IsIntegratedSecurityOnly+"','"+$_.IsFullTextInstalled+"','"+$_.IsClustered+"','"+$_.BuildClrVersion+"','0','"+$rundatetime+"'"
Invoke-SqlCmd -ServerInstance $MonServer -Database $MonDBName -Query $insertqry
$SqlConnection.Close()
}

}





function getjobowner([string] $Hostname,[string] $Instname,[int] $PortNum,[int] $Version, [string] $rundatetime)

{
$MonServer="MSF1VSQL32P"
$MonDBName="TJXSQLDBMON"
try
{
$SqlCatalog="msdb"
$SqlConnection = New-Object System.Data.SqlClient.SqlConnection
$SqlCmd = New-Object System.Data.SqlClient.SqlCommand
$SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
$DataSet = New-Object System.Data.DataSet
$DataSet2 = New-Object System.Data.DataSet
$DataSet3 = New-Object System.Data.DataSet
$DataSet4 = New-Object System.Data.DataSet
$SqlConnection.ConnectionString = �Server = $Hostname"+","+"$PortNum; Database =$SqlCatalog; Integrated Security = True;Connect Timeout=45;�

$SqlCmd.CommandText = "select  name, SUSER_SNAME(owner_sid) as JobOwner, enabled from sysjobs order by name"
$SqlCmd.Connection = $SqlConnection
$SqlAdapter.SelectCommand = $SqlCmd
$SqlAdapter.Fill($DataSet)|out-null
$jobs =$DataSet.Tables[0]
}

catch
{return}


foreach ($job in $jobs)
{

$SpecialChars = "'"
$SpecialChars |% {$job.name = $job.name -replace $_,"''"}
$insertqry="INSERT INTO [dbo].[z_GetJobOwners]([SQLSrvrName],[InstName],[JobName],[JobOwner],[JobEnabled]) VALUES ('"+$Hostname+"','"+$InstName+"','"+$job.name+"','"+$job.JobOwner+"','"+$job.enabled+"')"
write-host $insertqry
Invoke-SqlCmd -ServerInstance $MonServer -Database $MonDBName -Query $insertqry
}
$SqlConnection.Close()

}



function getdborolemembers([string] $Hostname,[string] $Instname,[int] $PortNum,[string] $DBName,[int] $Version, [string] $rundatetime)

{
$MonServer="MSF1VSQL32P"
$MonDBName="TJXSQLDBMON"
try
{
$SqlCatalog=$DBName
$SqlConnection = New-Object System.Data.SqlClient.SqlConnection
$SqlCmd = New-Object System.Data.SqlClient.SqlCommand
$SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
$DataSet = New-Object System.Data.DataSet
$DataSet2 = New-Object System.Data.DataSet
$DataSet3 = New-Object System.Data.DataSet
$DataSet4 = New-Object System.Data.DataSet
$SqlConnection.ConnectionString = �Server = $Hostname"+","+"$PortNum; Database =$SqlCatalog; Integrated Security = True;Connect Timeout=45;�

$SqlCmd.CommandText = "sp_helprolemember 'db_owner'"
$SqlCmd.Connection = $SqlConnection
$SqlAdapter.SelectCommand = $SqlCmd
$SqlAdapter.Fill($DataSet)|out-null
$jobs =$DataSet.Tables[0]
}

catch
{return}


foreach ($job in $jobs)
{


$insertqry="INSERT INTO [dbo].[ccs_tjxsql063]([SQLSrvrName],[InstName],[DBName],[RoleName],[Username]) VALUES ('"+$Hostname+"','"+$InstName+"','"+$DBName+"','db_owner','"+$job.MemberName+"')"
write-host $insertqry
Invoke-SqlCmd -ServerInstance $MonServer -Database $MonDBName -Query $insertqry
}
$SqlConnection.Close()

}




function getjobstatus([string] $Hostname,[string] $Instname,[int] $PortNum,[int] $Version, [string] $rundatetime)

{
$MonServer="MSF1VSQL32P"
$MonDBName="TJXSQLDBMON"
try
{
$SqlCatalog="master"
$SqlConnection = New-Object System.Data.SqlClient.SqlConnection
$SqlCmd = New-Object System.Data.SqlClient.SqlCommand
$SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
$DataSet = New-Object System.Data.DataSet
$DataSet2 = New-Object System.Data.DataSet
$DataSet3 = New-Object System.Data.DataSet
$DataSet4 = New-Object System.Data.DataSet
$SqlConnection.ConnectionString = �Server = $Hostname"+","+"$PortNum; Database =$SqlCatalog; Integrated Security = True;Connect Timeout=45;�

$SqlCmd.CommandText = "SELECT     name as DBName, DBRecoveryModel, MostRecentBackup, type as BackupType FROM  (SELECT     name, CASE WHEN status & 8 = 8 THEN 'Simple' ELSE 'NotSimple' END DBRecoveryModel FROM master..sysdatabases WHERE (name NOT IN ('tempdb', 'pubs', 'Northwind', 'ReportServerTempDB')) AND ((status & 512) <= 0) AND ((status & 32) <= 0) AND ((status & 1024) <= 0) AND ((status & 128) <= 0) AND ((status & 32768) <= 0)) MasterDB LEFT OUTER JOIN (SELECT     database_name, MAX(backup_finish_date) AS MostRecentBackup, type FROM msdb..backupset GROUP BY database_name, type) DRVBackup ON MasterDB.name = DRVBackup.database_name
UNION
SELECT     name as DBName, DBRecoveryModel, MostRecentBackup, type as BackupType FROM  (SELECT     name, CASE WHEN status & 8 = 8 THEN 'Simple' ELSE 'NotSimple' END DBRecoveryModel FROM master..sysdatabases WHERE (name NOT IN ('tempdb', 'pubs', 'Northwind', 'ReportServerTempDB')) AND ((status & 512) <= 0) AND ((status & 32) <= 0) AND ((status & 1024) <= 0) AND ((status & 128) <= 0) AND ((status & 32768) <= 0)) MasterDB LEFT OUTER JOIN (SELECT     database_name, MAX(backup_finish_date) AS MostRecentBackup, type FROM msdb..backupset GROUP BY database_name, type having type = 'D') DRVBackup ON MasterDB.name = DRVBackup.database_name order by name"
$SqlCmd.Connection = $SqlConnection
$SqlAdapter.SelectCommand = $SqlCmd
$SqlAdapter.Fill($DataSet)|out-null
$backups =$DataSet.Tables[0]
}

catch
{return}


foreach ($backup in $backups)
{

if (is-null $backup.MostRecentBackup)
{
$insertqry="INSERT INTO [dbo].[tblMonBackupStatus]([SQLSrvrName],[InstName],[DBName],[DBRecoveryModel],[MostRecentBackup],[BackupType]) VALUES ('"+$Hostname+"','"+$InstName+"','"+$backup.DBName+"','"+$backup.DBRecoveryModel+"',NULL,'"+$backup.backuptype+"')"
}
else
{
$insertqry="INSERT INTO [dbo].[tblMonBackupStatus]([SQLSrvrName],[InstName],[DBName],[DBRecoveryModel],[MostRecentBackup],[BackupType]) VALUES ('"+$Hostname+"','"+$InstName+"','"+$backup.DBName+"','"+$backup.DBRecoveryModel+"','"+$backup.MostRecentBackup+"','"+$backup.backuptype+"')"
}
Invoke-SqlCmd -ServerInstance $MonServer -Database $MonDBName -Query $insertqry
$SqlConnection.Close()

}

}







### Other Functions used

function is-null($value){  
return  [System.DBNull]::Value.Equals($value)  
} 

#####


