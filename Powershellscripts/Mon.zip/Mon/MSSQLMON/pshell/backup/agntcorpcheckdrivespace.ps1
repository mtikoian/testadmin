Get-PSSnapin -registered

Add-PSSnapin SqlServerProviderSnapin110

Add-PSSnapin SqlServercmdletSnapin110

cd D:\MSSQLMON\pshell

. ./Invoke-sqlcmd2.ps1

. ./Write-DataTable.ps1

. ./Out-DataTable.ps1

. ./sqlmonfunctions.ps1

$MonServer="MSF1VSQL32P"

$MonDBName="TJXSQLDBMON"

Invoke-sqlcmd2 -ServerInstance $MonServer -Database $MonDBName -Query "SELECT distinct [SQLSrvrName], RPCPortBlocked, cast (getdate() as smalldatetime) rundatetime FROM [dbo].[v_SQLSrvrByServiceType] where SQLSrvrStatus = 'A' and MonStatus=1 and SQLMonAccnt = 'CORP' and isnull(RPCPortBlocked,0)=0" | foreach-object {checkdrivespace $_.SQLSrvrName $_.rundatetime}


Invoke-sqlcmd2 -ServerInstance $MonServer -Database $MonDBName -Query "SELECT [SQLSrvrName],[InstName] ,[ServiceType], [SQLVersion],[PortNum],[Criticality],[MonStatus],[AlertStatus],cast (getdate() as smalldatetime) rundatetime FROM [dbo].[v_SQLSrvrByServiceType] where SQLSrvrStatus = 'A' and MonStatus=1 and SQLMonAccnt ='CORP' and ServiceType='SSDE' and RPCPortBlocked = 1" | foreach-object {checkxp_fixeddrivespace $_.SQLSrvrName $_.InstName $_.PortNum $_.SQLVersion $_.rundatetime}

