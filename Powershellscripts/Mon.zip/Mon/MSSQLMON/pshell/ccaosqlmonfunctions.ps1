Function getsrvrinfo ([string] $Hostname, [string] $rundatetime)
{

$MonServer="MSF1VSQL32P"
$MonDBName="TJXSQLDBMON_test"

$computer=get-wmiobject -class win32_computersystem -computername $hostname
$os=get-wmiobject -class win32_operatingsystem -computername $hostname
$cpuinfo=Get-WmiObject -Class Win32_Processor -computername $hostname 

if (!$?)
{
$ErrDetails=$error[0]

$SpecialChars = "'"

$SpecialChars |% {$ErrDetails = $ErrDetails -replace $_,""}

#$insertqry="INSERT INTO [dbo].[tblGetSrvrInfo] ([Srvrname],[ErrMsage],[RunDateTime]) VALUES ('"+$Hostname+"','"+$ErrDetails+"','"+$rundatetime+"')"

#$insertqry="exec uspUpdateSrvrInfo @SQLSrvrName = '"+$Hostname+"', @ErrMsage = '"+$ErrDetails+"',@rundatetime = '"+$rundatetime+"'"

Invoke-SqlCmd -ServerInstance $MonServer -Database $MonDBName -Query $insertqry
return
}
else
{

if (@($cpuinfo)[0].NumberOfCores)
    {
        $cores = @($cpuinfo).count * @($cpuinfo)[0].NumberOfCores
    }
    else
    {
        $cores = @($cpuinfo).count
    }
    $sockets = @(@($cpuinfo) |
    % {$_.SocketDesignation} |
    select-object -unique).count;


foreach($cpu in $cpuinfo) {
$cpuname=$cpu.Name
$cpuspeed=$cpu.CurrentClockSpeed
$cpuarch=$cpu.Architecture
$cpuaddrwidth=$cpu.AddressWidth

}



#$insertqry="INSERT INTO [dbo].[tblGetSrvrInfo] ([Srvrname],[DomainName],[Sockets],[Cores],[CPUType],[CPUCurrSpeedMhz],[CPUArch],[SystemType],[PhysicalMemoryMB],[Model],[Manufacturer],[TimeZoneVal],[DaylightInEffect],OSBuildNumber,OSCaption,OSVersion,TotalVirtualMemMB,PAEEnabled,[ErrMsage],[RunDateTime]) VALUES ('"+$Hostname+"','"+$computer.Domain+"','"+$sockets+"','"+$cores+"','"+$cpuname+"','"+$cpuspeed+"','"+$cpuarch+"','"+$cpuaddrwidth+"','"+[int]($computer.TotalPhysicalMemory/1mb)+"','"+$computer.Model+"','"+$computer.Manufacturer+"','"+$computer.CurrentTimeZone+"','"+$computer.DaylightInEffect+"','"+$os.BuildNumber+"','"+$os.Caption+"','"+$os.Version+"','"+[int]($os.TotalVirtualMemorySize/1kb)+"','"+$os.PAEEnabled+"','0','"+$rundatetime+"')"

$insertqry="exec uspUpdateSrvrInfo '"+$Hostname+"','"+$computer.Domain+"','"+$sockets+"','"+$cores+"','"+$cpuname+"','"+$cpuspeed+"','"+$cpuarch+"','"+$cpuaddrwidth+"','"+[int]($computer.TotalPhysicalMemory/1mb)+"','"+$computer.Model+"','"+$computer.Manufacturer+"','"+$computer.CurrentTimeZone+"','"+$computer.DaylightInEffect+"','"+$os.BuildNumber+"','"+$os.Caption+"','"+$os.Version+"','"+[int]($os.TotalVirtualMemorySize/1kb)+"','"+$os.PAEEnabled+"','0','"+$rundatetime+"'"
Invoke-SqlCmd -ServerInstance $MonServer -Database $MonDBName -Query $insertqry


}
}

Function getServiceInfo ([string] $Hostname, [string] $rundatetime)
{

$MonServer="MSF1VSQL32P"
$MonDBName="TJXSQLDBMON"


# Purpose: To check whether a service is installed
 Clear-Hos
$sName = "ESP System Agent for Microsoft Windows"
$service = Get-Service -display $sName -ErrorAction SilentlyContinue -ComputerName $Hostname
If ( -not $service ) 
{
$insertqry="INSERT INTO [dbo].[tblGetService] (SQLSrvrName,ServiceName,Status,RunDateTime) VALUES ('"+$Hostname+"','"+$sname +"','"+"'not installed'"+"','"+$rundatetime+"')"
}
else { 
$insertqry="INSERT INTO [dbo].[tblGetService] (SQLSrvrName,ServiceName,Status,RunDateTime) VALUES ('"+$Hostname+"','"+$sname +"','"+"'installed'"+"','"+$rundatetime+"')"
}

Invoke-SqlCmd -ServerInstance $MonServer -Database $MonDBName -Query $insertqry
}
