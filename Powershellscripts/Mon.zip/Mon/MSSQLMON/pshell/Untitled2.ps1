﻿
$Hostname="STO1VSET01P"
$rundatetime="2015-10-22 22:00:00"
$MonServer="MSF1VSQL32P"
$MonDBName="TJXSQLDBMON"

$computer=get-wmiobject -class win32_computersystem -computername $hostname
$os=get-wmiobject -class win32_operatingsystem -computername $hostname
$cpuinfo=Get-WmiObject -Class Win32_Processor -computername $hostname 

if (!$?)
{
$ErrDetails=$error[0]

$SpecialChars = "'"

$SpecialChars |% {$ErrDetails = $ErrDetails -replace $_,""}

#$insertqry="INSERT INTO [dbo].[tblGetSrvrInfo] ([Srvrname],[ErrMsage],[RunDateTime]) VALUES ('"+$Hostname+"','"+$ErrDetails+"','"+$rundatetime+"')"

$insertqry="exec uspUpdateNoSrvrInfo @SQLSrvrName = '"+$Hostname+"', @ErrMsage = '"+$ErrDetails+"',@rundatetime = '"+$rundatetime+"'"

Invoke-SqlCmd -ServerInstance $MonServer -Database $MonDBName -Query $insertqry

$RunDateTime+":Function-getsrvrinfo: "+$Hostname+" is not reachable."+"--Error Details:"+$ErrDetails >>  "D:\MSSQLMON\pshell_log\getsrvrinfo.log"

return
}
else
{

if (@($cpuinfo)[0].NumberOfCores)
    {
        $cores = @($cpuinfo).count * @($cpuinfo)[0].NumberOfCores
    }
    else
    {
        $cores = @($cpuinfo).count
    }
    $sockets = @(@($cpuinfo) |
    % {$_.SocketDesignation} |
    select-object -unique).count;


foreach($cpu in $cpuinfo) {
$cpuname=$cpu.Name
$cpuspeed=$cpu.CurrentClockSpeed
$cpuarch=$cpu.Architecture
$cpuaddrwidth=$cpu.AddressWidth

}

#$insertqry="INSERT INTO [dbo].[tblGetSrvrInfo] ([Srvrname],[DomainName],[Sockets],[Cores],[CPUType],[CPUCurrSpeedMhz],[CPUArch],[SystemType],[PhysicalMemoryMB],[Model],[Manufacturer],[TimeZoneVal],[DaylightInEffect],OSBuildNumber,OSCaption,OSVersion,TotalVirtualMemMB,PAEEnabled,[ErrMsage],[RunDateTime]) VALUES ('"+$Hostname+"','"+$computer.Domain+"','"+$sockets+"','"+$cores+"','"+$cpuname+"','"+$cpuspeed+"','"+$cpuarch+"','"+$cpuaddrwidth+"','"+[int]($computer.TotalPhysicalMemory/1mb)+"','"+$computer.Model+"','"+$computer.Manufacturer+"','"+$computer.CurrentTimeZone+"','"+$computer.DaylightInEffect+"','"+$os.BuildNumber+"','"+$os.Caption+"','"+$os.Version+"','"+[int]($os.TotalVirtualMemorySize/1kb)+"','"+$os.PAEEnabled+"','0','"+$rundatetime+"')"

$insertqry="exec uspUpdateSrvrInfo '"+$Hostname+"','"+$computer.Domain+"','"+$sockets+"','"+$cores+"','"+$cpuname+"','"+$cpuspeed+"','"+$cpuarch+"','"+$cpuaddrwidth+"','"+[int]($computer.TotalPhysicalMemory/1mb)+"','"+$computer.Model+"','"+$computer.Manufacturer+"','"+$computer.CurrentTimeZone+"','"+$computer.DaylightInEffect+"','"+$os.BuildNumber+"','"+$os.Caption+"','"+$os.Version+"','"+[int]($os.TotalVirtualMemorySize/1kb)+"','"+$os.PAEEnabled+"','0','"+$rundatetime+"'"

write-host $insertqry

#Invoke-SqlCmd -ServerInstance $MonServer -Database $MonDBName -Query $insertqry


}

