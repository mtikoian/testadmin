﻿$MonServer="MSF1VSQL32P"
$MonDBName="TJXSQLDBMON"
$hostname="WAT1VSET01P"
$PortNum=1433
$rundatetime="2015-02-05 13:44:00"
$InstName = "DEFAULT"


try
{
$SqlCatalog="master"
$SqlConnection = New-Object System.Data.SqlClient.SqlConnection
$SqlCmd = New-Object System.Data.SqlClient.SqlCommand
$SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
$DataSet = New-Object System.Data.DataSet
$DataSet2 = New-Object System.Data.DataSet
$DataSet3 = New-Object System.Data.DataSet
$DataSet4 = New-Object System.Data.DataSet
$SqlConnection.ConnectionString = “Server = $Hostname"+","+"$PortNum; Database =$SqlCatalog; Integrated Security = True;Connect Timeout=45;”

$SqlCmd.CommandText = "SELECT CONVERT(varchar(100), SERVERPROPERTY('ProductVersion')) as ProductVersion, CONVERT(varchar(100), SERVERPROPERTY('Collation')) as InstCollation,CONVERT(varchar(100), SERVERPROPERTY('Edition')) as ProductEdition, CONVERT(char(20), SERVERPROPERTY('ProductLevel')) as ProductLevel,CONVERT(char(20), SERVERPROPERTY('LCID')) as LCID,CONVERT(char(20), SERVERPROPERTY('IsIntegratedSecurityOnly')) AS IsIntegratedSecurityOnly, CONVERT(char(20), SERVERPROPERTY('IsFullTextInstalled')) AS IsFullTextInstalled, CONVERT(char(20), SERVERPROPERTY('IsClustered')) AS IsClustered, CONVERT(char(20), SERVERPROPERTY('BuildClrVersion'))  AS BuildClrVersion"
$SqlCmd.Connection = $SqlConnection
$SqlAdapter.SelectCommand = $SqlCmd
$SqlAdapter.Fill($DataSet)|out-null
$dbs =$DataSet.Tables[0]


}


catch
{

$ErrDetails=$error[0]

$SpecialChars = "'"

$SpecialChars |% {$ErrDetails = $ErrDetails -replace $_,""}


write-output $ErrDetails

#$insertqry="INSERT INTO [dbo].[tblGetSQLInstInfo]([SQLSrvrName],[InstName],[ErrMsage],[RunDateTime]) VALUES ('"+$Hostname+"','"+$InstName+"','"+$ErrDetails+"','"+$rundatetime+"')"

$insertqry="exec uspUpdateSQLSrvrInfo @SQLSrvrName = '"+$Hostname+"',@InstName = '"+$InstName+"',@ErrMsage = '"+$ErrDetails+"',@rundatetime = '"+$rundatetime+"'"
write-host $insertqry
Invoke-SqlCmd -ServerInstance $MonServer -Database $MonDBName -Query $insertqry

$RunDateTime+":Function-GetSQLInstInfo: "+$Hostname+" is not reachable."+"--Error Details:"+$ErrDetails >>  "D:\MSSQLMON\pshell_log\GetSQLInstInfo.log"

$SqlConnection.Close()


return 
}


$dbs | foreach-object {
#$insertqry="INSERT INTO [dbo].[tblGetSQLInstInfo]([SQLSrvrName],[InstName],[ProductVersion],[ProductEdition], [InstCollation],[RunDateTime]) VALUES ('"+$Hostname+"','"+$InstName+"','"+$_.ProductVersion+"','"+$_.ProductEdition+"','"+$_.InstCollation+"','"+$rundatetime+"')"
$insertqry="exec uspUpdateSQLSrvrInfo '"+$Hostname+"','"+$InstName+"','"+$_.ProductVersion+"','"+$_.ProductLevel+"','"+$_.ProductEdition+"','"+$_.InstCollation+"','"+$_.LCID+"','"+$_.IsIntegratedSecurityOnly+"','"+$_.IsFullTextInstalled+"','"+$_.IsClustered+"','"+$_.BuildClrVersion+"','0','"+$rundatetime+"'"
Invoke-SqlCmd -ServerInstance $MonServer -Database $MonDBName -Query $insertqry
$SqlConnection.Close()

write-output $rundatetime
write-output $_.ProductVersion
}

