function getdefaultbackuplocation ([string] $Hostname,[string] $Instname,[int] $PortNum,[int] $Version, [string] $rundatetime)

{
$MonServer="MSF1VSQL32P"
$MonDBName="TJXSQLDBMON"


try
{
$SqlCatalog="master"
$SqlConnection = New-Object System.Data.SqlClient.SqlConnection
$SqlCmd = New-Object System.Data.SqlClient.SqlCommand
$SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
$DataSet = New-Object System.Data.DataSet
$DataSet2 = New-Object System.Data.DataSet
$DataSet3 = New-Object System.Data.DataSet
$DataSet4 = New-Object System.Data.DataSet

$SqlConnection.ConnectionString = �Server = $Hostname"+","+"$PortNum; Database =$SqlCatalog; Integrated Security = True;Connect Timeout=45;�

$SqlCmd.CommandText = "exec master.dbo.xp_instance_regread N'HKEY_LOCAL_MACHINE',N'Software\Microsoft\MSSQLServer\MSSQLServer', N'BackupDirectory'"
$SqlCmd.Connection = $SqlConnection
$SqlAdapter.SelectCommand = $SqlCmd
$SqlAdapter.Fill($DataSet)|out-null
$backuplocations =$DataSet.Tables[0]
}

catch
{
$ErrDetails=$error[0]
$PagerAlert=1
#$smtp.Send($emailFrom, $emailTo, $subject, $PagerMessage)
#$smtp.Send($emailFrom, $PagerTo, $subject, $PagerMessage)
$RunDateTime+"Function:getdefaultbackuplocation --"+$displayName+" is not reachable."+"Error reaching the host: "+$Hostname+"; Error Details:"+$ErrDetails >>  "D:\MSSQLMON\pshell_log\getdefaultbackuplocation.log"
return
}


foreach ($backuplocation in $backuplocations)
{
$insertqry="INSERT INTO [dbo].[tblGetDefaultBackupLocation] (SQLSrvrName,BacupDirectory,RunDateTime) VALUES ('"+$Hostname+"','"+$backuplocation.Data +"','"+$rundatetime+"')"
Invoke-SqlCmd -ServerInstance $MonServer -Database $MonDBName -Query $insertqry
$SqlConnection.Close()
}
}


function getbackuplocation ([string] $Hostname,[string] $Instname,[int] $PortNum,[int] $Version, [string] $rundatetime)
{
$MonServer="MSF1VSQL32P"
$MonDBName="TJXSQLDBMON"
try
{
$SqlCatalog="master"
$SqlConnection = New-Object System.Data.SqlClient.SqlConnection
$SqlCmd = New-Object System.Data.SqlClient.SqlCommand
$SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
$DataSet = New-Object System.Data.DataSet
$DataSet2 = New-Object System.Data.DataSet
$DataSet3 = New-Object System.Data.DataSet
$DataSet4 = New-Object System.Data.DataSet

$SqlConnection.ConnectionString = �Server = $Hostname"+","+"$PortNum; Database =$SqlCatalog; Integrated Security = True;Connect Timeout=45;�


$SqlCmd.CommandText = "SELECT msdb.dbo.backupset.database_name,max(msdb.dbo.backupmediafamily.physical_device_name) as physical_device_name,max(msdb.dbo.backupset.backup_start_date) AS backup_start_date FROM msdb.dbo.backupmediafamily INNER JOIN msdb.dbo.backupset ON msdb.dbo.backupmediafamily.media_set_id = msdb.dbo.backupset.media_set_id and msdb.dbo.backupset.database_name in (select name from master..sysdatabases where DATABASEPROPERTYEX(name, 'Status') = 'ONLINE') WHERE msdb..backupset.type = 'D' GROUP BY msdb.dbo.backupset.database_name"

# $SqlCmd.CommandText = "SELECT  database_name, x.physical_device_name, x.backup_start_date FROM (  SELECT  bs.database_name,bs.backup_start_date,bmf.physical_device_name,Ordinal = ROW_NUMBER() OVER( PARTITION BY bs.database_name ORDER BY bs.backup_start_date DESC ) FROM  msdb.dbo.backupmediafamily bmf JOIN msdb.dbo.backupmediaset bms ON bmf.media_set_id = bms.media_set_id JOIN msdb.dbo.backupset bs ON bms.media_set_id = bs.media_set_id WHERE   bs.[type] = 'D' AND bs.is_copy_only = 0 ) x WHERE x.Ordinal = 1"

$SqlCmd.Connection = $SqlConnection
$SqlAdapter.SelectCommand = $SqlCmd
$SqlAdapter.Fill($DataSet)|out-null
$backuplocations =$DataSet.Tables[0]
}

catch
{
$ErrDetails=$error[0]
$PagerAlert=1
#$smtp.Send($emailFrom, $emailTo, $subject, $PagerMessage)
#$smtp.Send($emailFrom, $PagerTo, $subject, $PagerMessage)
$RunDateTime+"Function:getbackuplocation --"+$displayName+" is not reachable."+"Error reaching the host: "+$Hostname+"; Error Details:"+$ErrDetails >>  "D:\MSSQLMON\pshell_log\getbackuplocation.log"
return
}


foreach ($backuplocation in $backuplocations)
{
$insertqry="INSERT INTO [dbo].[tblMonBackupLocation] (SQLSrvrName,InstName, DBName, LastBackupFileName, LastBackupDatatime,RunDateTime) VALUES ('"+$Hostname+"','"+$Instname+"','"+$backuplocation.database_name+"','"+$backuplocation.physical_device_name+"','"+$backuplocation.backup_start_date+"','"+$rundatetime+"')" 
Invoke-SqlCmd -ServerInstance $MonServer -Database $MonDBName -Query $insertqry
$SqlConnection.Close()
}
}

Function getServiceInfo ([string] $Hostname, [string] $rundatetime)
{

$MonServer="MSF1VSQL32P"
$MonDBName="TJXSQLDBMON"
# $Hostname="sho1vssn01p"
# $rundatetime="2014-07-30 21:08:00.000"

# Purpose: To check whether a service is installed

$sName = "ESP System Agent for Microsoft Windows"
$Service = Get-Service -display $sName -ErrorAction SilentlyContinue -ComputerName $Hostname | Select Name, MachineName, Status
 
If ( -not $service )
{
$insertqry="INSERT INTO [dbo].[tblGetService] (SQLSrvrName,ServiceName,Status,RunDateTime) VALUES ('"+$Hostname+"','"+$sname +"','"+"not installed"+"','"+$rundatetime+"')"
}
else { 
$insertqry="INSERT INTO [dbo].[tblGetService] (SQLSrvrName,ServiceName,Status,RunDateTime) VALUES ('"+$Hostname+"','"+$sname +"','"+"installed"+"','"+$rundatetime+"')"
}
Invoke-SqlCmd -ServerInstance $MonServer -Database $MonDBName -Query $insertqry
$SqlConnection.Close()
}

#Import-Module SQLPS -DisableNameChecking


function getjobname ([string] $Hostname,[string] $Instname,[int] $PortNum,[int] $Version, [string] $rundatetime)
{
$MonServer="MSF1VSQL32P"
$MonDBName="TJXSQLDBMON"

 #$Hostname="TKMWDBAC"
 #$rundatetime="2014-08-04 21:08:00.000"
 #$Instname="default"
 #$PortNum=1433
 #$Version=8.0

# Purpose: To get all jobs in SQL agent

try
{
$SqlCatalog="master"
$SqlConnection = New-Object System.Data.SqlClient.SqlConnection
$SqlCmd = New-Object System.Data.SqlClient.SqlCommand
$SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
$DataSet = New-Object System.Data.DataSet
$DataSet2 = New-Object System.Data.DataSet
$DataSet3 = New-Object System.Data.DataSet
$DataSet4 = New-Object System.Data.DataSet

$SqlConnection.ConnectionString = �Server = $Hostname"+","+"$PortNum; Database =$SqlCatalog; Integrated Security = True;Connect Timeout=45;�
$SqlCmd.CommandText = "SELECT j.name[JobName], j.enabled, SUSER_SNAME(j.owner_sid) [JobOwner], c.name [CategoryName] FROM [msdb].[dbo].[sysjobs] j JOIN [msdb].[dbo].[syscategories] c on j.category_id = c.category_id"
$SqlCmd.Connection = $SqlConnection
$SqlAdapter.SelectCommand = $SqlCmd
$SqlAdapter.Fill($DataSet)|out-null
$jobnames =$DataSet.Tables[0]
}

catch
{return}


foreach ($jobname in $jobnames)
{
$insertqry="INSERT INTO [dbo].[tblJobInfo] (SQLSrvrName,InstName,JobName,enabled, JobOwner,CategoryName,rundatetime) VALUES ('"+$Hostname+"','"+$Instname+"','"+$Jobname.JobName+"',"+$jobname.enabled+",'"+$Jobname.JobOwner+"','"+$Jobname.CategoryName+"','"+$rundatetime+"')"
Invoke-SqlCmd -ServerInstance $MonServer -Database $MonDBName -Query $insertqry
$SqlConnection.Close()
}
}


Function GetServiceInstalled ([string] $Hostname, [string] $instname, [string] $displayname, [string] $rundatetime)
{

$MonServer="MSF1VSQL32P"
$MonDBName="TJXSQLDBMON"

if ($displayName -eq "MSSQL")
{
    if ($Instname -eq "Default")
    {
        $Name = "MSSQLSERVER"
    }
    else
    {
        $name = "MSSQL$"+$Instname
    }    
  
        $Services = Get-Service -ComputerName $Hostname | where {$_.Name -eq $name}
}
else
{
    $Services = Get-Service -ComputerName $Hostname | where {$_.displayName -like $displayname}
}

if (!$?)
{
$ErrDetails=$error[0]
$PagerAlert=1
$PagerMessage="Get Service: "+$displayName+" is not reachable."
#$smtp.Send($emailFrom, $emailTo, $subject, $PagerMessage)
#$smtp.Send($emailFrom, $PagerTo, $subject, $PagerMessage)
$RunDateTime+" -- Get Service: "+$displayName+" is not reachable."+"Error reaching the host: "+$Hostname+"; Error Details:"+$ErrDetails >>  "D:\MSSQLMON\pshell_log\GetSericeInstalled.log"
return
}
else 
{
    foreach ($Service in $Services)
    {

        if ($Service.Status -eq "Running")
        {
            #write-output $Service.name
            $Updateqry="exec uspUpdateServiceInfo '"+$Hostname+"','"+$Instname+"','"+$Service.Name+"', '"+$Service.status+"'"
       
            Invoke-SqlCmd -ServerInstance $MonServer -Database $MonDBName -Query $Updateqry
        }
    }
}
}

Get-Service -ComputerName msf1bsql04p | where {$_.Name -like "mssql"} | select name, displayname, status