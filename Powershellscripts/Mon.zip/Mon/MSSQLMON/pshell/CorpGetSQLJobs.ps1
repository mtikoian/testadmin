Import-Module SQLPS -DisableNameChecking

cd D:\MSSQLMON\pshell

. ./Invoke-sqlcmd2.ps1

. ./Write-DataTable.ps1

. ./Out-DataTable.ps1

. ./newfunctions.ps1

$MonServer="MSF1vSQL32P"

$MonDBName="TJXSQLDBMON"

# Get All SQL Jobs

Invoke-sqlcmd2 -ServerInstance $MonServer -Database $MonDBName -Query "SELECT distinct [SQLSrvrName],[instname], [SQLVersion], [PortNum],cast (getdate() as smalldatetime) rundatetime FROM [dbo].[v_SQLSrvrByServiceType] where SQLSrvrStatus = 'A' and SQLMonAccnt = 'CORP' and ServiceType='SSDE'" | foreach-object {getjobname $_.SQLSrvrName $_.InstName $_.PortNum $_.SQLVersion $_.rundatetime}


