Import-Module SQLPS -DisableNameChecking


cd D:\MSSQLMON\pshell

. ./Invoke-sqlcmd2.ps1

. ./Write-DataTable.ps1

. ./Out-DataTable.ps1

. ./newfunctions.ps1

$MonServer="MSF1vSQL32P"

$MonDBName="TJXSQLDBMON"

# Service Info

Invoke-sqlcmd2 -ServerInstance $MonServer -Database $MonDBName -Query "SELECT distinct [SQLSrvrName], cast (getdate() as smalldatetime) rundatetime FROM [dbo].[v_SQLSrvrByServiceType] where SQLSrvrStatus = 'A' and MonStatus=1 and SQLMonAccnt = 'STORE'" | foreach-object {getserviceinfo $_.SQLSrvrName $_.rundatetime}




