

Function checksqlconn  ([string] $Hostname,[string] $Instname,[int] $PortNum,[decimal] $Version, [string] $rundatetime)
{
$MonServer="TJXW002401\SQLMON"
$MonDBName="TJXSQLDBMON"

$SqlCatalog="master"
$SqlConnection = New-Object System.Data.SqlClient.SqlConnection
$SqlConnection.ConnectionString = �Server = $Hostname"+","+"$PortNum; Database =$SqlCatalog; Integrated Security = True;Connect Timeout=45;�
$SqlConnection.Open()
if($SqlConnection.state -eq �Open�)
{

$insertqry="INSERT INTO [dbo].[zz_tblMonSQLConnect] ([SQLSrvrName],[InstName],[SSDEPortNum],[Status],[RunDateTime]) VALUES ('"+$Hostname+"','"+$InstName+"','"+$PortNum+"',1,'"+$rundatetime+"')"
Invoke-SqlCmd -ServerInstance $MonServer -Database $MonDBName -Query $insertqry
$SqlConnection.Close()
}

else
{
$ErrDetails=$error[0]
$insertqry="INSERT INTO [dbo].[zz_tblMonSQLConnect] ([SQLSrvrName],[InstName],[SSDEPortNum],[Status],[ErrMsage],[RunDateTime]) VALUES ('"+$Hostname+"','"+$InstName+"','"+$PortNum+"',0,'"+$ErrDetails+"','"+$rundatetime+"')"
Invoke-SqlCmd -ServerInstance $MonServer -Database $MonDBName -Query $insertqry
$SqlConnection.Close()
}

}



Function checkservices  ([string] $Hostname,[string] $Instname,[string] $ServiceType,[decimal] $Version, [datetime] $rundatetime)
{
$MonServer="TJXW002401\SQLMON"
$MonDBName="TJXSQLDBMON"

if($ServiceType -eq "SSDE" -and $Instname -eq "DEFAULT")
{$ChkServicename="MSSQLSERVER"}
elseif($ServiceType -eq "SSDE" -and $Instname -ne "DEFAULT")
{$ChkServicename="MSSQL$"+$Instname}
elseif($ServiceType -eq "AGNT" -and $Instname -eq "DEFAULT")
{$ChkServicename="SQLServerAgent"}
elseif($ServiceType -eq "AGNT" -and $Instname -ne "DEFAULT")
{$ChkServicename="SQLAgent$"+$Instname}
elseif($ServiceType -eq "SSRS" -and $Instname -eq "DEFAULT")
{$ChkServicename="ReportServer"}
elseif($ServiceType -eq "SSRS" -and $Instname -ne "DEFAULT")
{$ChkServicename="ReportServer$"+$Instname}
elseif($ServiceType -eq "SSAS" -and $Instname -eq "DEFAULT")
{$ChkServicename="MSSQLServerOLAPService"}
elseif($ServiceType -eq "SSAS" -and $Instname -ne "DEFAULT")
{$ChkServicename="MSOLAP$"+$Instname}
elseif($ServiceType -eq "SSIS" -and $Version -le "9.99")
{$ChkServicename="MsDtsServer"}
elseif($ServiceType -eq "SSIS" -and $Version -ge "10.00")
{$ChkServicename="MsDtsServer100"}
elseif($ServiceType -eq "SYBASE")
{$ChkServicename="SYBSQL_"+$Hostname}
elseif($ServiceType -eq "SYBCKP")
{$ChkServicename="SYBBCK_"+$Hostname+"_BS"}
else
{return}

$Services=get-wmiobject -class win32_service -computername $hostname| where {$_.name -eq $ChkServicename}| select-object Name,state,status,Started,Startname,Description
 if (!$?)
{
$ErrDetails=$error[0]
$SpecialChars = "'"
$SpecialChars |% {$ErrDetails = $ErrDetails -replace $_,""}
$insertqry="INSERT INTO [dbo].[tblMonServiceStatus] ([SQLSrvrName],[InstName],[ServiceType],[Status],[ErrMsage],[RunDateTime]) VALUES ('"+$Hostname+"','"+$InstName+"','"+$ServiceType+"',0,'"+$ErrDetails+"','"+$rundatetime+"')"
Invoke-SqlCmd -ServerInstance $MonServer -Database $MonDBName -Query $insertqry
return
}
else
{

foreach ( $service in $Services)
{
if($service.state -ne "Running" -or  $service.status -ne "OK" -or $service.started -ne "True" )
{
$ErrDetails="State: "+$service.state+" Status: "+$service.status+" Started: "+$service.started
$insertqry="INSERT INTO [dbo].[tblMonServiceStatus] ([SQLSrvrName],[InstName],[ServiceType],[Status],[ErrMsage],[RunDateTime]) VALUES ('"+$Hostname+"','"+$InstName+"','"+$ServiceType+"',0,'"+$ErrDetails+"','"+$rundatetime+"')"
Invoke-SqlCmd -ServerInstance $MonServer -Database $MonDBName -Query $insertqry
}
else
{
$insertqry="INSERT INTO [dbo].[tblMonServiceStatus] ([SQLSrvrName],[InstName],[ServiceType],[Status],[RunDateTime]) VALUES ('"+$Hostname+"','"+$InstName+"','"+$ServiceType+"',1,'"+$rundatetime+"')"
Invoke-SqlCmd -ServerInstance $MonServer -Database $MonDBName -Query $insertqry
}
}

}
}





Function checkdrivespace  ([string] $Hostname, [string] $rundatetime)
{
$MonServer="TJXW002401\SQLMON"
$MonDBName="TJXSQLDBMON"


$drives=Get-WmiObject -computername $hostname -class Win32_LogicalDisk -filter "DriveType=3"|Select-Object -property DeviceID,@{label='DriveSpaceMB';expression={$_.size / 1MB -as [int]}},@{label='FreeSpaceMB';expression={$_.FreeSpace / 1MB -as [int]}}


 if (!$?)
{
$ErrDetails=$error[0]
$insertqry="INSERT INTO [dbo].[tblMonDriveSpace] ([SQLSrvrName],[ErrMsage],[RunDateTime]) VALUES ('"+$Hostname+"','"+$ErrDetails+"','"+$rundatetime+"')"
Invoke-SqlCmd -ServerInstance $MonServer -Database $MonDBName -Query $insertqry
return
}
else
{

foreach ($drive in $drives)
{
$insertqry="INSERT INTO [dbo].[tblMonDriveSpace] ([SQLSrvrName],[DriveLetter],[DriveSpaceMB],[FreeSpaceMB],[RunDateTime]) VALUES ('"+$Hostname+"','"+$drive.DeviceID+"','"+$drive.DriveSpaceMB+"','"+$drive.FreeSpaceMB+"','"+$rundatetime+"')"
Invoke-SqlCmd -ServerInstance $MonServer -Database $MonDBName -Query $insertqry
}
CheckMountPointSpace $Hostname $rundatetime

}
}



function CheckMountPointSpace([string] $Hostname, [string] $rundatetime) 
{

$MonServer="TJXW002401\SQLMON"
$MonDBName="TJXSQLDBMON"

    
        $objFSO = New-Object -com Scripting.FileSystemObject
        $MountPoints = gwmi -class "win32_mountpoint" -namespace "root\cimv2" -computername $Hostname


 if (!$?)
{
return
}

else
{
        $Volumes = gwmi -class "win32_volume" -namespace "root/cimv2" -ComputerName $Hostname| select name, freespace



        foreach ($MP in $Mountpoints) {
                $MP.directory = $MP.directory.replace("\\","\")        
                foreach ($v in $Volumes) {
                        $vshort = $v.name.Substring(0,$v.name.length-1 )
                        $vshort = """$vshort""" #Make it look like format in $MP (line 11).
                        if ($mp.directory.contains($vshort)) { #only queries mountpoints that exist as drive volumes no system
                                $DestFolder = "\\"+$Hostname + "\"+ $v.name.Substring(0,$v.name.length-1 ).Replace(":","$")
                                #$destFolder #troubleshooting string to verify building dest folder correctly.
                                $colItems = (Get-ChildItem $destfolder |  where{$_.length -ne $null} |Measure-Object -property length -sum)
                                #to clean up errors when folder contains no files.
                                #does not take into account subfolders.
                               
                                if($colItems.sum -eq $null) {
                                        $fsize = 0
                                } else {
                                        $fsize = $colItems.sum
                                }
                               
                                $TotFolderSize = $fsize + $v.freespace
                                $insertqry="INSERT INTO [dbo].[tblMonDriveSpace] ([SQLSrvrName],[DriveLetter],[DriveSpaceMB],[FreeSpaceMB],[RunDateTime]) VALUES ('"+$Hostname+"','"+$V.name+"','"+[int]($TotFolderSize/1MB)+"','"+[int]($v.freespace/1MB)+"','"+$rundatetime+"')"

Invoke-SqlCmd -ServerInstance $MonServer -Database $MonDBName -Query $insertqry
                        }
                }
        }

}

}



function checkdbstatus([string] $Hostname,[string] $Instname,[int] $PortNum,[int] $Version, [string] $rundatetime)

{
$MonServer="TJXW002401\SQLMON"
$MonDBName="TJXSQLDBMON"

try
{
$SqlCatalog="master"
$SqlConnection = New-Object System.Data.SqlClient.SqlConnection
$SqlCmd = New-Object System.Data.SqlClient.SqlCommand
$SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
$DataSet = New-Object System.Data.DataSet
$DataSet2 = New-Object System.Data.DataSet
$DataSet3 = New-Object System.Data.DataSet
$DataSet4 = New-Object System.Data.DataSet
$SqlConnection.ConnectionString = �Server = $Hostname"+","+"$PortNum; Database =$SqlCatalog; Integrated Security = True;Connect Timeout=45;�

$SqlCmd.CommandText = "SELECT name, DATABASEPROPERTYEX(name,'Status') dbstatus FROM sysdatabases"
$SqlCmd.Connection = $SqlConnection
$SqlAdapter.SelectCommand = $SqlCmd
$SqlAdapter.Fill($DataSet)|out-null
$dbs =$DataSet.Tables[0]
}

catch
{return}


foreach ($db in $dbs)
{

$insertqry="INSERT INTO [dbo].[tblMonDBStatus]([SQLSrvrName],[InstName],[DBName],[DBStatus],[RunDateTime]) VALUES ('"+$Hostname+"','"+$InstName+"','"+$db.name+"','"+$db.dbstatus+"','"+$rundatetime+"')"
Invoke-SqlCmd -ServerInstance $MonServer -Database $MonDBName -Query $insertqry
$SqlConnection.Close()

}

}





Function checkdbfileusage  ([string] $Hostname,[string] $Instname,[int] $PortNum,[int] $Version, [string] $rundatetime)
{
$MonServer="TJXW002401\SQLMON"
$MonDBName="TJXSQLDBMON"



$SqlConnection = New-Object System.Data.SqlClient.SqlConnection
$SqlCmd = New-Object System.Data.SqlClient.SqlCommand
$SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
$DataSet = New-Object System.Data.DataSet
$SqlConnection.ConnectionString = �Server = $Hostname"+","+"$PortNum; Database =$SqlCatalog; Integrated Security = True;Connect Timeout=45;�
$SqlCmd.CommandText = "select name from master.dbo.sysdatabases"
$SqlCmd.Connection = $SqlConnection
$SqlAdapter.SelectCommand = $SqlCmd
$SqlAdapter.Fill($DataSet)|out-null
$dbs =$DataSet.Tables[0]


$dbs | foreach-object {
$insertqry = "SELECT '"+$Hostname+"' as SQLSrvrName,'"+$InstName+"' as InstName,'"+$_.name+"' as DBName, name as LogicalFileName, groupid, CASE WHEN status & 0x40 = 64 Then 'LOG' ELSE 'DATA'END AS FileType, maxsize, CEILING(size * 8 / 1024.) AS CurrSizeMB, floor(size/128.0 - CAST(FILEPROPERTY(name, 'SpaceUsed') AS int)/128.0) AS FreeSpaceMB, CASE WHEN status & 0x100000 > 0 THEN growth ELSE NULL END AS GrowthPRCNT, CASE WHEN status & 0x100000 = 0 THEN CEILING(growth * 8 / 1024.) END AS GrowthMB ,'"+$rundatetime+"' as rundatetime FROM sysfiles"

$SQLINST=$Hostname+","+$PortNum

$dt = Invoke-SqlCmd -ServerInstance $SQLINST -Database $_.name -Query $insertqry | % { $_.PSADAPTED } | out-datatable

#Add-SqlTable -ServerInstance $MonServer -Database $MonDBName -TableName "tblMonDBFileSize1" -DataTable $dt

Write-DataTable -ServerInstance $MonServer -Database $MonDBName -TableName "tblMonDBFileSize" -Data $dt


}

}



Function checklastreboot  ([string] $Hostname, [string] $rundatetime)
{

$MonServer="TJXW002401\SQLMON"
$MonDBName="TJXSQLDBMON"

$date = Get-WmiObject Win32_OperatingSystem -computername $Hostname | foreach{$_.LastBootUpTime}
$RebootTime = [System.DateTime]::ParseExact($date.split('.')[0],'yyyyMMddHHmmss',$null)

$insertqry="INSERT INTO [dbo].[tblMonSrvrLastReboot] ([SQLSrvrName],[LastRebootDT],[RunDateTime]) VALUES ('"+$Hostname+"','"+$RebootTime+"','"+$rundatetime+"')"
Invoke-SqlCmd -ServerInstance $MonServer -Database $MonDBName -Query $insertqry

}



Function getsrvrinfo ([string] $Hostname, [string] $rundatetime)
{

$MonServer="TJXW002401\SQLMON"
$MonDBName="TJXSQLDBMON"

$computer=get-wmiobject -class win32_computersystem -computername $hostname
$os=get-wmiobject -class win32_operatingsystem -computername $hostname
$cpuinfo=Get-WmiObject -Class Win32_Processor -computername $hostname 

if (!$?)
{
$ErrDetails=$error[0]

$SpecialChars = "'"

$SpecialChars |% {$ErrDetails = $ErrDetails -replace $_,""}

#$insertqry="INSERT INTO [dbo].[tblGetSrvrInfo] ([Srvrname],[ErrMsage],[RunDateTime]) VALUES ('"+$Hostname+"','"+$ErrDetails+"','"+$rundatetime+"')"

$insertqry="exec uspUpdateSrvrInfo @SQLSrvrName = '"+$Hostname+"', @ErrMsage = '"+$ErrDetails+"',@rundatetime = '"+$rundatetime+"')"

Invoke-SqlCmd -ServerInstance $MonServer -Database $MonDBName -Query $insertqry
return
}
else
{

if (@($cpuinfo)[0].NumberOfCores)
    {
        $cores = @($cpuinfo).count * @($cpuinfo)[0].NumberOfCores
    }
    else
    {
        $cores = @($cpuinfo).count
    }
    $sockets = @(@($cpuinfo) |
    % {$_.SocketDesignation} |
    select-object -unique).count;


foreach($cpu in $cpuinfo) {
$cpuname=$cpu.Name
$cpuspeed=$cpu.CurrentClockSpeed
$cpuarch=$cpu.Architecture
$cpuaddrwidth=$cpu.AddressWidth

}



#$insertqry="INSERT INTO [dbo].[tblGetSrvrInfo] ([Srvrname],[DomainName],[Sockets],[Cores],[CPUType],[CPUCurrSpeedMhz],[CPUArch],[SystemType],[PhysicalMemoryMB],[Model],[Manufacturer],[TimeZoneVal],[DaylightInEffect],OSBuildNumber,OSCaption,OSVersion,TotalVirtualMemMB,PAEEnabled,[ErrMsage],[RunDateTime]) VALUES ('"+$Hostname+"','"+$computer.Domain+"','"+$sockets+"','"+$cores+"','"+$cpuname+"','"+$cpuspeed+"','"+$cpuarch+"','"+$cpuaddrwidth+"','"+[int]($computer.TotalPhysicalMemory/1mb)+"','"+$computer.Model+"','"+$computer.Manufacturer+"','"+$computer.CurrentTimeZone+"','"+$computer.DaylightInEffect+"','"+$os.BuildNumber+"','"+$os.Caption+"','"+$os.Version+"','"+[int]($os.TotalVirtualMemorySize/1kb)+"','"+$os.PAEEnabled+"','0','"+$rundatetime+"')"

$insertqry="exec uspUpdateSrvrInfo '"+$Hostname+"','"+$computer.Domain+"','"+$sockets+"','"+$cores+"','"+$cpuname+"','"+$cpuspeed+"','"+$cpuarch+"','"+$cpuaddrwidth+"','"+[int]($computer.TotalPhysicalMemory/1mb)+"','"+$computer.Model+"','"+$computer.Manufacturer+"','"+$computer.CurrentTimeZone+"','"+$computer.DaylightInEffect+"','"+$os.BuildNumber+"','"+$os.Caption+"','"+$os.Version+"','"+[int]($os.TotalVirtualMemorySize/1kb)+"','"+$os.PAEEnabled+"','0','"+$rundatetime+"'"

Invoke-SqlCmd -ServerInstance $MonServer -Database $MonDBName -Query $insertqry


}
}



function GetSQLInstInfo ([string] $Hostname,[string] $Instname,[int] $PortNum,[int] $Version, [string] $rundatetime)

{
$MonServer="TJXW002401\SQLMON"
$MonDBName="TJXSQLDBMON"

try
{
$SqlCatalog="master"
$SqlConnection = New-Object System.Data.SqlClient.SqlConnection
$SqlCmd = New-Object System.Data.SqlClient.SqlCommand
$SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
$DataSet = New-Object System.Data.DataSet
$DataSet2 = New-Object System.Data.DataSet
$DataSet3 = New-Object System.Data.DataSet
$DataSet4 = New-Object System.Data.DataSet
$SqlConnection.ConnectionString = �Server = $Hostname"+","+"$PortNum; Database =$SqlCatalog; Integrated Security = True;Connect Timeout=45;�

$SqlCmd.CommandText = "SELECT CONVERT(varchar(100), SERVERPROPERTY('ProductVersion')) as ProductVersion, CONVERT(varchar(100), SERVERPROPERTY('Collation')) as InstCollation,CONVERT(varchar(100), SERVERPROPERTY('Edition')) as ProductEdition, CONVERT(char(20), SERVERPROPERTY('ProductLevel')) as ProductLevel,CONVERT(char(20), SERVERPROPERTY('LCID')) as LCID,CONVERT(char(20), SERVERPROPERTY('IsIntegratedSecurityOnly')) AS IsIntegratedSecurityOnly, CONVERT(char(20), SERVERPROPERTY('IsFullTextInstalled')) AS IsFullTextInstalled, CONVERT(char(20), SERVERPROPERTY('IsClustered')) AS IsClustered, CONVERT(char(20), SERVERPROPERTY('BuildClrVersion'))  AS BuildClrVersion"
$SqlCmd.Connection = $SqlConnection
$SqlAdapter.SelectCommand = $SqlCmd
$SqlAdapter.Fill($DataSet)|out-null
$dbs =$DataSet.Tables[0]
}

	catch
	{

$ErrDetails=$error[0]

$SpecialChars = "'"

$SpecialChars |% {$ErrDetails = $ErrDetails -replace $_,""}


#$insertqry="INSERT INTO [dbo].[tblGetSQLInstInfo]([SQLSrvrName],[InstName],[ErrMsage],[RunDateTime]) VALUES ('"+$Hostname+"','"+$InstName+"','"+$ErrDetails+"','"+$rundatetime+"')"

$insertqry="exec uspUpdateSQLSrvrInfo @SQLSrvrName = '"+$Hostname+"',@InstName = '"+$InstName+"',@ErrMsage = '"+$ErrDetails+"',@rundatetime = '"+$rundatetime+"'"
write-host $insertqry
Invoke-SqlCmd -ServerInstance $MonServer -Database $MonDBName -Query $insertqry

$SqlConnection.Close()
return

	}

$dbs | foreach-object {
#$insertqry="INSERT INTO [dbo].[tblGetSQLInstInfo]([SQLSrvrName],[InstName],[ProductVersion],[ProductEdition], [InstCollation],[RunDateTime]) VALUES ('"+$Hostname+"','"+$InstName+"','"+$_.ProductVersion+"','"+$_.ProductEdition+"','"+$_.InstCollation+"','"+$rundatetime+"')"
$insertqry="exec uspUpdateSQLSrvrInfo '"+$Hostname+"','"+$InstName+"','"+$_.ProductVersion+"','"+$_.ProductLevel+"','"+$_.ProductEdition+"','"+$_.InstCollation+"','"+$_.LCID+"','"+$_.IsIntegratedSecurityOnly+"','"+$_.IsFullTextInstalled+"','"+$_.IsClustered+"','"+$_.BuildClrVersion+"','0','"+$rundatetime+"'"
Invoke-SqlCmd -ServerInstance $MonServer -Database $MonDBName -Query $insertqry
$SqlConnection.Close()
}

}





function getjobowner([string] $Hostname,[string] $Instname,[int] $PortNum,[int] $Version, [string] $rundatetime)

{
$MonServer="TJXW002401\SQLMON"
$MonDBName="TJXSQLDBMON"
try
{
$SqlCatalog="msdb"
$SqlConnection = New-Object System.Data.SqlClient.SqlConnection
$SqlCmd = New-Object System.Data.SqlClient.SqlCommand
$SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
$DataSet = New-Object System.Data.DataSet
$DataSet2 = New-Object System.Data.DataSet
$DataSet3 = New-Object System.Data.DataSet
$DataSet4 = New-Object System.Data.DataSet
$SqlConnection.ConnectionString = �Server = $Hostname"+","+"$PortNum; Database =$SqlCatalog; Integrated Security = True;Connect Timeout=45;�

$SqlCmd.CommandText = "select  name, SUSER_SNAME(owner_sid) as JobOwner, enabled from sysjobs order by name"
$SqlCmd.Connection = $SqlConnection
$SqlAdapter.SelectCommand = $SqlCmd
$SqlAdapter.Fill($DataSet)|out-null
$jobs =$DataSet.Tables[0]
}

catch
{return}


foreach ($job in $jobs)
{

$SpecialChars = "'"
$SpecialChars |% {$job.name = $job.name -replace $_,"''"}
$insertqry="INSERT INTO [dbo].[z_GetJobOwners]([SQLSrvrName],[InstName],[JobName],[JobOwner],[JobEnabled]) VALUES ('"+$Hostname+"','"+$InstName+"','"+$job.name+"','"+$job.JobOwner+"','"+$job.enabled+"')"
write-host $insertqry
Invoke-SqlCmd -ServerInstance $MonServer -Database $MonDBName -Query $insertqry
}
$SqlConnection.Close()

}


function ccsgetlinkedservers([string] $Hostname,[string] $Instname,[int] $PortNum,[int] $Version, [string] $rundatetime)

{
$MonServer="TJXW002401\SQLMON"
$MonDBName="TJXSQLDBMON"
try
{
$SqlCatalog="master"
$SqlConnection = New-Object System.Data.SqlClient.SqlConnection
$SqlCmd = New-Object System.Data.SqlClient.SqlCommand
$SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
$DataSet = New-Object System.Data.DataSet
$DataSet2 = New-Object System.Data.DataSet
$DataSet3 = New-Object System.Data.DataSet
$DataSet4 = New-Object System.Data.DataSet
$SqlConnection.ConnectionString = �Server = $Hostname"+","+"$PortNum; Database =$SqlCatalog; Integrated Security = True;Connect Timeout=45;�

$SqlCmd.CommandText = "select srvname from sysservers where srvid !=0"
$SqlCmd.Connection = $SqlConnection
$SqlAdapter.SelectCommand = $SqlCmd
$SqlAdapter.Fill($DataSet)|out-null
$jobs =$DataSet.Tables[0]
}

catch
{return}


foreach ($job in $jobs)
{

$SpecialChars = "'"
$SpecialChars |% {$job.srvname = $job.srvname -replace $_,"''"}
$insertqry="INSERT INTO [dbo].[ccs_tjxsql013]([SQLSrvrName],[InstName],[LinkedServer]) VALUES ('"+$Hostname+"','"+$InstName+"','"+$job.srvname+"')"
write-host $insertqry
Invoke-SqlCmd -ServerInstance $MonServer -Database $MonDBName -Query $insertqry
}
$SqlConnection.Close()

}



function ccsgetsoapendpoints([string] $Hostname,[string] $Instname,[int] $PortNum,[int] $Version, [string] $rundatetime)

{
$MonServer="TJXW002401\SQLMON"
$MonDBName="TJXSQLDBMON"
try
{
$SqlCatalog="master"
$SqlConnection = New-Object System.Data.SqlClient.SqlConnection
$SqlCmd = New-Object System.Data.SqlClient.SqlCommand
$SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
$DataSet = New-Object System.Data.DataSet
$DataSet2 = New-Object System.Data.DataSet
$DataSet3 = New-Object System.Data.DataSet
$DataSet4 = New-Object System.Data.DataSet
$SqlConnection.ConnectionString = �Server = $Hostname"+","+"$PortNum; Database =$SqlCatalog; Integrated Security = True;Connect Timeout=45;�

$SqlCmd.CommandText = "select name from sys.endpoints where type = 1"
$SqlCmd.Connection = $SqlConnection
$SqlAdapter.SelectCommand = $SqlCmd
$SqlAdapter.Fill($DataSet)|out-null
$jobs =$DataSet.Tables[0]
}

catch
{return}


foreach ($job in $jobs)
{

$SpecialChars = "'"
$SpecialChars |% {$job.name = $job.name -replace $_,"''"}
$insertqry="INSERT INTO [dbo].[ccs_tjxsql070]([SQLSrvrName],[InstName],[LinkedServer]) VALUES ('"+$Hostname+"','"+$InstName+"','"+$job.name+"')"
write-host $insertqry
Invoke-SqlCmd -ServerInstance $MonServer -Database $MonDBName -Query $insertqry
}
$SqlConnection.Close()

}



function ccsgetservicebrokerpoints([string] $Hostname,[string] $Instname,[int] $PortNum,[int] $Version, [string] $rundatetime)

{
$MonServer="TJXW002401\SQLMON"
$MonDBName="TJXSQLDBMON"
try
{
$SqlCatalog="master"
$SqlConnection = New-Object System.Data.SqlClient.SqlConnection
$SqlCmd = New-Object System.Data.SqlClient.SqlCommand
$SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
$DataSet = New-Object System.Data.DataSet
$DataSet2 = New-Object System.Data.DataSet
$DataSet3 = New-Object System.Data.DataSet
$DataSet4 = New-Object System.Data.DataSet
$SqlConnection.ConnectionString = �Server = $Hostname"+","+"$PortNum; Database =$SqlCatalog; Integrated Security = True;Connect Timeout=45;�

$SqlCmd.CommandText = "select name from sys.endpoints where type = 3"
$SqlCmd.Connection = $SqlConnection
$SqlAdapter.SelectCommand = $SqlCmd
$SqlAdapter.Fill($DataSet)|out-null
$jobs =$DataSet.Tables[0]
}

catch
{return}


foreach ($job in $jobs)
{

$SpecialChars = "'"
$SpecialChars |% {$job.name = $job.name -replace $_,"''"}
$insertqry="INSERT INTO [dbo].[ccs_tjxsql082]([SQLSrvrName],[InstName],[LinkedServer]) VALUES ('"+$Hostname+"','"+$InstName+"','"+$job.name+"')"
write-host $insertqry
Invoke-SqlCmd -ServerInstance $MonServer -Database $MonDBName -Query $insertqry
}
$SqlConnection.Close()

}


function ccsgetproxysubsystem([string] $Hostname,[string] $Instname,[int] $PortNum,[int] $Version, [string] $rundatetime)

{
$MonServer="TJXW002401\SQLMON"
$MonDBName="TJXSQLDBMON"
try
{
$SqlCatalog="msdb"
$SqlConnection = New-Object System.Data.SqlClient.SqlConnection
$SqlCmd = New-Object System.Data.SqlClient.SqlCommand
$SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
$DataSet = New-Object System.Data.DataSet
$DataSet2 = New-Object System.Data.DataSet
$DataSet3 = New-Object System.Data.DataSet
$DataSet4 = New-Object System.Data.DataSet
$SqlConnection.ConnectionString = �Server = $Hostname"+","+"$PortNum; Database =$SqlCatalog; Integrated Security = True;Connect Timeout=45;�

$SqlCmd.CommandText = "exec sp_enum_proxy_for_subsystem"
$SqlCmd.Connection = $SqlConnection
$SqlAdapter.SelectCommand = $SqlCmd
$SqlAdapter.Fill($DataSet)|out-null
$jobs =$DataSet.Tables[0]
}

catch
{
write-host "Error"
return}


foreach ($job in $jobs)
{

$SpecialChars = "'"
$SpecialChars |% {$job.subsystem_name = $job.subsystem_name  -replace $_,"''"}
$SpecialChars |% {$job.proxy_name = $job.proxy_name -replace $_,"''"}

$insertqry="INSERT INTO [dbo].[ccs_tjxsql083]([SQLSrvrName],[InstName],[SubSystem],[ProxyName]) VALUES ('"+$Hostname+"','"+$InstName+"','"+$job.subsystem_name+"','"+$job.proxy_name+"')"
write-host $insertqry
Invoke-SqlCmd -ServerInstance $MonServer -Database $MonDBName -Query $insertqry
}
$SqlConnection.Close()

}



function ccsgetclrvalues([string] $Hostname,[string] $Instname,[int] $PortNum,[int] $Version, [string] $rundatetime)

{
$MonServer="TJXW002401\SQLMON"
$MonDBName="TJXSQLDBMON"
try
{
$SqlCatalog="master"
$SqlConnection = New-Object System.Data.SqlClient.SqlConnection
$SqlCmd = New-Object System.Data.SqlClient.SqlCommand
$SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
$DataSet = New-Object System.Data.DataSet
$DataSet2 = New-Object System.Data.DataSet
$DataSet3 = New-Object System.Data.DataSet
$DataSet4 = New-Object System.Data.DataSet
$SqlConnection.ConnectionString = �Server = $Hostname"+","+"$PortNum; Database =$SqlCatalog; Integrated Security = True;Connect Timeout=45;�

$SqlCmd.CommandText = "select value_in_use from sys.configurations where name ='clr enabled' and value_in_use = 1"
$SqlCmd.Connection = $SqlConnection
$SqlAdapter.SelectCommand = $SqlCmd
$SqlAdapter.Fill($DataSet)|out-null
$jobs =$DataSet.Tables[0]
}

catch
{return}


foreach ($job in $jobs)
{


$insertqry="INSERT INTO [dbo].[ccs_tjxsql098]([SQLSrvrName],[InstName],[CLREnabled]) VALUES ('"+$Hostname+"','"+$InstName+"','"+$job.value_in_use+"')"
write-host $insertqry
Invoke-SqlCmd -ServerInstance $MonServer -Database $MonDBName -Query $insertqry
}
$SqlConnection.Close()

}





### Other Functions used

function is-null($value){  
return  [System.DBNull]::Value.Equals($value)  
} 

#####


