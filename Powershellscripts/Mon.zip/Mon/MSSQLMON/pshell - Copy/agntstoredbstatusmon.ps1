Get-PSSnapin -registered

Add-PSSnapin SqlServerProviderSnapin100

Add-PSSnapin SqlServercmdletSnapin100

cd D:\MSSQLMON\pshell

. ./Invoke-sqlcmd2.ps1

. ./Write-DataTable.ps1

. ./Out-DataTable.ps1

. ./sqlmonfunctions.ps1

Invoke-sqlcmd2 -ServerInstance "FRA1VSQM01P" -Database TJXSQLDBMON -Query "SELECT [SQLSrvrName],[InstName] ,[ServiceType], [SQLVersion],[PortNum],[Criticality],[MonStatus],[AlertStatus],cast (getdate() as smalldatetime) rundatetime FROM [dbo].[v_SQLSrvrByServiceType] where SQLSrvrStatus = 'A' and MonStatus=1 and ServiceType='SSDE' and SQLMonAccnt ='STORE'" | foreach-object {checkdbstatus $_.SQLSrvrName $_.InstName $_.PortNum $_.SQLVersion $_.rundatetime}
