Function checkcrystalservices ([string] $hostname,[string] $EnvType )
{
If ($hostname -eq "FRA1BCRY01P")
{
$MonServices=@("BOBJCentralMS","BOBJCrystalReportApplicationServer","BOBJCrystalReportsCacheServer(2)","BOBJCrystalReportspageserver(2)","BOBJDestinationServer","BOBJEventServer","BOBJInputFileServer","BOBJJobServer_Report","BOBJOutputFileServer","BOBJProcessServer","BOBJProgramServer","BOBJWebiServer","BOBJWICDZ")
}
Elseif ($hostname -eq "FRA1BCRY02P")
{
$MonServices=@("BOBJCrystalReportApplicationServer","BOBJCrystalReportsCacheServer(2)","BOBJCrystalReportspageserver(2)","BOBJDestinationServer","BOBJEventServer","BOBJInputFileServer","BOBJJobServer_Report","BOBJOutputFileServer","BOBJProcessServer","BOBJProgramServer","BOBJWebiServer","BOBJWICDZ")
}
Elseif ($hostname -eq "ATL1BCRY01P")
{
$MonServices=@("BOE120SIAATL1BCRY01P","BOE120Tomcat")
}
Elseif ($hostname -eq "ATL1BCRY02P")
{
$MonServices=@("BOE120SIAATL1BCRY02P","BOE120Tomcat")
}
Else
{
$MonServices=@("BOBJCentralMS","BOBJCrystalReportApplicationServer","BOBJCrystalReportsCacheServer(2)","BOBJCrystalReportspageserver(2)","BOBJDestinationServer","BOBJEventServer","BOBJInputFileServer","BOBJJobServer_Report","BOBJOutputFileServer","BOBJProcessServer","BOBJProgramServer","BOBJWebiServer","BOBJWICDZ")
}


$RunDateTime = Get-Date
$RunDateTime = $RunDateTime.ToShortDateString() +" "+ $RunDateTime.ToShortTimeString()

$emailFrom = "DoNotReply@tjx.com"
$subject = "CrystalReport Services on "+$hostname
$smtpServer = "tjxsmtp2.tjx.com"
$smtp = new-object Net.Mail.SmtpClient($smtpServer)

If ($EnvType -eq "P")
{
$emailTo = "DBSG_DB2_Distributed@tjx.com"
$PagerTo = "db2aix_beeper@tjx.com, DBSG_DB2_Distributed@tjx.com"
}
Else
{
$emailTo = "suneel_mundlapudi@tjx.com"
$PagerTo = "suneel_mundlapudi@tjx.com"
}

$EmailMessage=""
$PagerMessage="Services Could not be started: "
$EmailAlert=0
$PagerAlert=0


$ServiceErrCount = 0

foreach ($ServiceName in $MonServices)
{


$Services=get-wmiobject -class win32_service -computername $hostname| where {$_.name -eq $ServiceName}| select-object Name,state,status,Started,Startname,Description
 if (!$?)
{

$ErrDetails=$error[0]
$PagerAlert=1
$PagerMessage="Crystal Report Server "+$Hostname+" is not reachable."
#$smtp.Send($emailFrom, $emailTo, $subject, $PagerMessage)
$smtp.Send($emailFrom, $PagerTo, $subject, $PagerMessage)
$RunDateTime+" - Error reaching the host: "+$Hostname+"; Error Details:"+$ErrDetails >>  "D:\MSSQLMON\pshell_log\CrystalMon.log"
return
}
else
{


foreach ( $service in $Services)
{

if ($service.name)
{

if($service.state -ne "Running")
{



$ServiceErrCount = 1
$ErrDetails= $RunDateTime+" - "+$hostname+" - Error : Service Name: "+$service.name + " State: "+$service.state+". It will be attempted to start."

$ErrDetails >>  "D:\MSSQLMON\pshell_log\CrystalMon.log"


$i = 1


while ($i -le 5) {



$SrvStatus = startservice $hostname $service.name
Start-Sleep -s 10

if ($SrvStatus -ne "Running")
{
$RunDateTime+" - "+$hostname+" - Error : Service Name: "+$service.name + " State: "+$SrvStatus+". Service is still not running" >>  "D:\MSSQLMON\pshell_log\CrystalMon.log"
$i++

if ($i -eq 5)
{
$PagerAlert=1
$PagerMessage=$PagerMessage+$service.name +";"
}

}
else
{
$i=6
$EmailAlert=1
$EmailMessage=$EmailMessage+"Service Name: "+$service.name +" was successfully started on "+$hostname+".`n"
$RunDateTime+" - "+$hostname+" - Success: Service Name: "+$service.name + " State: "+$SrvStatus+". Service is now running" >>  "D:\MSSQLMON\pshell_log\CrystalMon.log"

}




}



}

}


else
{

$EmailAlert=1
$EmailMessage=$EmailMessage+"Service Name: "+$ServiceName+" does not exist on "+$hostname+".`n"


$ServiceErrCount = 1
$RunDateTime+" - "+$hostname+" - Error: "+$ServiceName+" Service doesn't exist" >>  "D:\MSSQLMON\pshell_log\CrystalMon.log"

}


}

}






}

if($ServiceErrCount -eq 0)
{

$RunDateTime+" - "+$hostname+" - Success: All the services are running as required" >>  "D:\MSSQLMON\pshell_log\CrystalMon.log"

}


if ($EmailAlert -eq 1)
{
$smtp.Send($emailFrom, $emailTo, $subject, $EmailMessage)
}
if ($PagerAlert -eq 1)
{
$smtp.Send($emailFrom, $PagerTo, $subject, $PagerMessage)
#$smtp.Send($emailFrom, $emailTo, $subject, $PagerMessage)
}

}




function startservice([string] $Hostname,[string] $ServiceName)

{
$serviceInstance = (Get-WmiObject -computername $hostname -class Win32_Service -Filter "Name='$ServiceName'")
$serviceInstance.StartService() | Out-Null

$serviceInstance = (Get-WmiObject -computername $hostname -class Win32_Service -Filter "Name='$ServiceName'")
$serviceInstance.State
}



