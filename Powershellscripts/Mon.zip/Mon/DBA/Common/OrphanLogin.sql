if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[OrphanLogin]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[OrphanLogin]
GO

CREATE TABLE [dbo].[OrphanLogin] (
	[ServerName] [varchar] (60) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[OrphanLogin] [varchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[SID] [varbinary] (85) NULL 
) ON [PRIMARY]
GO

