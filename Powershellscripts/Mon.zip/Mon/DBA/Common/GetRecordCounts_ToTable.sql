SET NOCOUNT ON
	
DECLARE DB_CURS CURSOR FOR
	SELECT name from master.dbo.sysdatabases
	WHERE name not in( 'master', 'model', 'msdb', 'Northwind', 'pubs', 'tempdb' )

DECLARE @DB varchar(120)
DECLARE
	@Table		varchar( 120 ),
	@Owner		varchar( 50 ),
	@Cmd		varchar( 1000 )

CREATE TABLE #TABLES
(
	[DBName] [varchar] (120) NOT NULL ,
	[TableName] [varchar] (120) NOT NULL ,
	[RecordCount] [bigint] NULL ,
	[Owner] [sysname] NOT NULL ,
	[SampleDate] [datetime] NOT NULL 
)

OPEN DB_CURS
FETCH NEXT FROM DB_CURS INTO @DB
WHILE @@FETCH_STATUS = 0
BEGIN
	TRUNCATE TABLE #TABLES
	SET @CMD = 'SELECT ''' + @DB + ''', TABLE_SCHEMA, TABLE_NAME, getdate()
		FROM ' + @DB + '.INFORMATION_SCHEMA.TABLES
		WHERE 
			TABLE_TYPE = ''BASE TABLE'' 	and
			TABLE_NAME not like ''sys%'' 	and 
			TABLE_NAME <> ''dtproperties'''
	PRINT @CMD
	INSERT INTO #TABLES( DBName, Owner, TableName, SampleDate) EXEC(@CMD)
		
    	SET @CMD = 'UPDATE #TABLES SET RecordCount = 
		( SELECT count(*) FROM @DB.@Owner.@Table )'
	
	
	FETCH NEXT FROM DB_CURS INTO @DB
END
CLOSE DB_CURS
DEALLOCATE DB_CURS
select * from #tables
drop table #tables


select * from Northwind.dbo.sysobjects where xtype = 'U'


