USE dba
go
IF OBJECT_ID( 'dbo.usp_DifferentialBackup' ) IS NOT NULL
	DROP PROCEDURE dbo.usp_DifferentialBackup
GO
CREATE PROCEDURE dbo.usp_DifferentialBackup
	@DBName		varchar( 50 ),
	@Path		varchar( 120 ),
	@RetainDays int = 7
AS
/*********************************************************************

     Creates a differential backup file whose name format is 
		'<dbname>_Diff_YYYYMMDDHHMM.BAK'.

	 Parameters:
		DBName		name of database
		Path		Path of folder to store backup in
		RetainDays  How many days to store the info 
					in msdb ( default = 7 )

	Example:
usp_DifferentailBackup 'tkcsd', '\\172.24.60.76\Ddrive\backup', 4

************************************************************************/

DECLARE 
@WhichBKP 	varchar( 300 ), 
@curdate 	datetime,
@CMD		varchar( 3000 )

SET @curdate = GETDATE()

SET @WhichBKP = 
	@Path + '\' + @DBName + '_Diff_' + 
	REPLACE( REPLACE( REPLACE( CONVERT( varchar(16), @curdate, 120 ), '-', '' ), ':', '' ), ' ', '' ) +
	'.BAK'
--print @WhichBKP

SET @CMD = 'BACKUP DATABASE ' + @DBName + ' TO DISK = ''' +
	@WhichBKP + ''' WITH INIT, DIFFERENTIAL, ' +
	' NAME = N''' + @DBName + ' Differential Backup'', DESCRIPTION = ''Differential'', 
	RETAINDAYS=' + CAST( @RetainDays as varchar )
--print @CMD
EXEC( @CMD )


DECLARE @i INT

SELECT @i = position FROM msdb..backupset 
WHERE database_name= @DBName AND type!='F' AND backup_set_id=
( SELECT MAX(backup_set_id) FROM msdb..backupset WHERE database_name= @DBName )

RESTORE VERIFYONLY FROM DISK = @WhichBKP WITH FILE = @i

GO
