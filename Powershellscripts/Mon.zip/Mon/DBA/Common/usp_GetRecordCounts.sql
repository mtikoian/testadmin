USE DBA
GO
IF OBJECT_ID( 'dbo.usp_GetRecordCounts' ) IS NOT NULL
	DROP PROCEDURE dbo.usp_GetRecordCounts 
GO
CREATE PROCEDURE dbo.usp_GetRecordCounts
		@DBName		varchar(50) 
AS
SET NOCOUNT ON
--DROP TABLE #TEMP
CREATE TABLE #TEMP( RECCOUNT INT )

DECLARE
	@Table		varchar( 60 ),
	@Owner		varchar( 50 ),
	@Cmd		varchar(2000),
	@Count 		int,
	@SampleDate	datetime

SET @SampleDate	= GETDATE()
SET @Cmd =
'INSERT INTO DBA.dbo.Table_Counts( DBName, TableName, Owner, SampleDate )
SELECT ''' + @DBName + ''', TABLE_NAME, TABLE_SCHEMA, ''' 
+ CONVERT( varchar(25), @SampleDate, 121 ) +
''' FROM [' + @DBName + '].INFORMATION_SCHEMA.TABLES 
WHERE 
		TABLE_TYPE = ''BASE TABLE'' and
		TABLE_NAME not like ''sys%'' and 
		TABLE_NAME <> ''dtproperties'''
--PRINT @Cmd
EXEC( @Cmd )

DECLARE
	Table_curs CURSOR FOR
	SELECT DISTINCT TableName, Owner FROM DBA.dbo.Table_Counts
	WHERE DBName = @DBName AND SampleDate = @SampleDate

OPEN Table_curs
FETCH NEXT FROM Table_curs INTO @Table, @Owner
WHILE @@FETCH_STATUS = 0
	begin
	TRUNCATE TABLE #TEMP
	SET @Cmd = 'SELECT COUNT(*) FROM [' + @DBName + '].' + @Owner + '.[' + @Table + ']'
	--PRINT @cmd
	INSERT INTO #TEMP( RECCOUNT )
		exec( @cmd )
	SELECT @Count = MAX( RECCOUNT ) FROM #TEMP
	--PRINT @Count

	UPDATE dbo.Table_Counts
	SET RecordCount = @Count
	WHERE 
		DBName    = @DBName and
	  	TableName = @Table  and
		Owner	  = @Owner  and
	  	RecordCount IS NULL
	FETCH NEXT FROM Table_curs INTO @Table, @Owner
	end
CLOSE Table_curs
DEALLOCATE Table_curs
DROP TABLE #TEMP
SELECT TableName, RecordCount, Owner, SampleDate
FROM dbo.Table_Counts
WHERE DBName = @DBName and SampleDate = @SampleDate
ORDER BY TableName, Owner
go






