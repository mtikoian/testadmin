USE DBA
GO
IF OBJECT_ID( 'dbo.usp_RebuildShowcontigIndexes' ) IS NOT NULL
	DROP PROCEDURE dbo.usp_RebuildShowcontigIndexes
GO
CREATE PROCEDURE dbo.usp_RebuildShowcontigIndexes
			@Database	varchar(50) = NULL

/**********************************************

	Rebuilds all the indexes for tables in the 
	dba.dbo.SHOWCONTIG table.  The data was 
	put in the table by running usp_Showcontig.

	If a database name is passed, only indexes
	for that database are rebuilt.

	Any table having at least one index in 
	the showcontig table will have ALL of 
	its indexes rebuilt.

************************************************/
AS
SET NOCOUNT ON
DECLARE
	@TableName		varchar( 50 ),
	@DBName			varchar( 50 ),
	@Owner			sysname,
	@TableCount		int,
	@JobStart		datetime,
	@JobEnd			datetime,
	@command1		varchar(2000)

IF @Database IS NULL
	PRINT 'DBREINDEX FOR ALL DATABASES'
ELSE
	PRINT 'DBREINDEX FOR ' + @Database 

SET @JobStart 		= GETDATE()
PRINT 'JOB START TIME:  ' + CAST( @JobStart as varchar )

IF @Database IS NULL
	DECLARE
		Indexes CURSOR FORWARD_ONLY READ_ONLY FOR
		SELECT DISTINCT RTRIM( DBName ), RTRIM( TableName ), RTRIM( Owner )
		FROM DBA.dbo.ShowContig
		ORDER BY RTRIM( DBName ), RTRIM( TableName )
ELSE
	DECLARE
		Indexes CURSOR FORWARD_ONLY READ_ONLY FOR
		SELECT DISTINCT RTRIM( DBName ), RTRIM( TableName ), RTRIM( Owner )
		FROM DBA.dbo.ShowContig
		WHERE DBName = @Database
		ORDER BY RTRIM( TableName )

SET @TableCount = 0
OPEN Indexes
FETCH NEXT FROM Indexes INTO @DBName, @TableName, @Owner
WHILE @@FETCH_STATUS = 0
	begin
	SET @TableCount = @TableCount + 1
	SET @command1 = 
		'DBCC DBREINDEX ( ''[' + @DBName + '].' + @owner + '.' + 
		@TableName + ''' ) WITH NO_INFOMSGS '
	PRINT @command1
	EXEC( @command1 )
	SET @command1 = 'use ' + @DBName + ' exec sp_recompile ' + @TableName
	PRINT @command1
	EXEC( @command1 )
	FETCH NEXT FROM Indexes INTO @DBName, @TableName, @Owner
	end
CLOSE Indexes
DEALLOCATE Indexes
PRINT CAST( @TableCount as varchar ) + ' TABLES REINDEXED'
PRINT ' '
PRINT '***********************************************************************'
PRINT ' '
SET @JobEnd = GETDATE()
PRINT 'JOB END TIME:  ' + CAST( @JobEnd as varchar )
IF DATEDIFF( mi, @JobStart, @JobEnd ) < 60
	PRINT 'JOB DURATION:  ' + 
		CAST( DATEDIFF( mi, @JobStart, @JobEnd ) as varchar ) + ' minutes'
ELSE
	PRINT 'JOB DURATION:  ' + 
	CAST( ( DATEDIFF( mi, @JobStart, @JobEnd )/60 ) as varchar ) + ' hrs ' +
	CAST( ( DATEDIFF( mi, @JobStart, @JobEnd )%60 ) as varchar ) + ' minutes'
go
