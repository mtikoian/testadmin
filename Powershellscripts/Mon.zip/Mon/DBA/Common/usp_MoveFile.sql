USE DBA
go
IF OBJECT_ID( 'dbo.usp_MoveFile' ) IS NOT NULL
	DROP PROCEDURE dbo.usp_MoveFile
GO
CREATE PROCEDURE dbo.usp_MoveFile 	
		@FileName		varchar( 120 ),
		@Destination 	varchar( 120 )
AS
SET NOCOUNT ON
DECLARE 
	@Wincmd varchar( 500 ),
	@rtn int,
	@jobID uniqueidentifier,
	@seq	int,
	@jobname varchar(300),
	@count int

CREATE TABLE #TEMP
(
	job_id uniqueidentifier ,
	job_name sysname ,
	run_status int ,
	run_date int ,
	run_time int ,
	run_duration int ,
	operator_emailed nvarchar(20) ,
	operator_netsent nvarchar(20), 
	operator_paged nvarchar(20) ,
	retries_attempted int ,
	server nvarchar(30) 
)

SET @rtn = 0

IF charindex( '*', @FileName ) = 0
	begin
	DECLARE  @FileExists	char(1)
	exec usp_DoesFileExist @FileName, @FileExists out
	IF @FileExists = 'N'
		begin
		PRINT 'File ' + @FileName + ' does not exist'
		RETURN -1
		end
	end

IF LEFT( @Destination, 1 ) <> '\' 
	SET @Wincmd = 'move "' + @FileName + '" "' + RTRIM(@Destination) + '\"'
ELSE
	SET @Wincmd = 'move "' + @FileName + '" "' + RTRIM(@Destination) + '"'

SET @SEQ = 0
SET @jobname = '_Temp_Move_File'

WHILE @seq < 50
	begin
	set @jobname = @jobname + cast(@seq as varchar)
	SELECT @count = count(*) from msdb.dbo.sysjobs where name = @jobname
	print cast(@count as varchar)
	print @jobname
	if @count = 0
		begin
		EXEC msdb.dbo.sp_add_job @job_name = @jobname, @job_id = @jobID OUTPUT 
		if @jobID is not null set @seq = 99
		end
	set @seq = @seq + 1
	end

IF @jobID is null
	begin
	SET @rtn = -1
	RETURN @rtn
	end

EXEC msdb.dbo.sp_add_jobstep @job_id = @jobID, @step_name = 'Move File', @step_id = 1, @subsystem = 'CMDEXEC', @command = @WinCmd
EXEC msdb.dbo.sp_add_jobserver @job_id = @jobID
EXEC @rtn = msdb.dbo.sp_start_job @job_id = @jobID, @output_flag = 0 
IF @rtn <> 0 RETURN @rtn

WAITFOR DELAY '000:00:05' -- Give the job a chance to complete
INSERT INTO #TEMP EXEC msdb.dbo.sp_help_jobhistory @job_id = @jobID

WHILE @@ROWCOUNT = 0
  BEGIN
  WAITFOR DELAY '000:00:05' -- Give the job a chance to complete
  INSERT INTO #TEMP EXEC msdb.dbo.sp_help_jobhistory @job_id = @jobID
  END

SELECT @rtn = max(run_status) FROM #TEMP
IF @rtn <> 1 
	SET @rtn = -1
ELSE
	EXEC msdb.dbo.sp_delete_job @job_id = @jobID

DROP TABLE #TEMP

PRINT 'File ' + @FileName + ' moved'
RETURN @rtn
go
