USE DBA
go
IF OBJECT_ID( 'dbo.usp_CollectFreeSpaceStats' ) is not null
	DROP PROCEDURE dbo.usp_CollectFreeSpaceStats
GO
CREATE PROCEDURE dbo.usp_CollectFreeSpaceStats
		@Save_Flag	char(1) = 'N'
AS
/************************************************************************************

   Determines the amount of free space on each drive that is 
   used by SQL Server data, log and backup files.  Also checks space
   on drive shares used by jobs with 'copy' or 'move' command.  This  
   includes drive shares from other servers.

   If Save_Flag = 'Y', the results are collected into table 
   DB_FREESPACE_STATS for later analysis, else a result set is returned.

*************************************************************************************/

SET NOCOUNT ON
CREATE TABLE #Drives ( [drive] varchar( 40 ), [MB free] int ) 

--	Get the local or mapped drives 
INSERT INTO #Drives EXEC master..xp_fixeddrives
--SELECT * FROM #Drives

--	Include drive shares on other servers from backup jobs
INSERT INTO #Drives( [drive] )
	SELECT DISTINCT  
	LEFT( physical_device_name, 
		CHARINDEX( '\', physical_device_name, 
		CHARINDEX( '\', physical_device_name, 3 ) + 1 ) - 1  )
	FROM msdb..backupmediafamily 
	WHERE LEFT( physical_device_name, 2 ) = '\\'

/******************************************************************

		Get drive shares that are being used in 'move' or 'copy' 
		DOS jobs.  These are frequently used to move local backups
		to other servers on the network.

*******************************************************************/

DECLARE
	@DrivePath	varchar(120),
	@PathStart  int,
	@PathEnd	int,
	@DOSCommand varchar(1600)

DECLARE
	JobCurs CURSOR FOR
	SELECT [command] FROM msdb..sysjobsteps
	WHERE subsystem = 'CmdExec' and 
		 ( command LIKE 'move %' OR command LIKE 'copy %' )

OPEN JobCurs
FETCH NEXT FROM JobCurs INTO @DOSCommand
WHILE @@FETCH_STATUS = 0
	begin
	SET @PathStart = 0
	SET @PathEnd = 0
	SET @DrivePath = NULL
	SET @PathStart = CHARINDEX( '\\', @DOSCommand )
	
	IF @PathStart > 0 
		SET @PathEnd = 	CHARINDEX( '\', @DOSCommand, 
						CHARINDEX( '\', @DOSCommand, @PathStart + 2 ) + 1 )
	
	IF @PathStart <> 0
		IF @PathEnd <> 0
			SET @DrivePath = SUBSTRING( @DOSCommand, @PathStart, @PathEnd - @PathStart )
		ELSE
			SET @DrivePath = SUBSTRING( @DOSCommand, @PathStart, LEN( @DOSCommand ) - @PathStart )
	
	IF RIGHT( @DrivePath, 1 ) = '"'
		SET @DrivePath = RIGHT( @DrivePath, LEN( @DrivePath ) - 1 )

	INSERT INTO #Drives( [drive] ) 
		SELECT @DrivePath
		WHERE @DrivePath NOT IN ( SELECT [drive] FROM #Drives )
	FETCH NEXT FROM JobCurs INTO @DOSCommand
	end
CLOSE JobCurs
DEALLOCATE JobCurs
--SELECT * FROM #Drives

--Get amount of freespace for each drive share
DECLARE 
	DBServerDrives_Cursor CURSOR FOR 
	SELECT [drive] FROM  #Drives  
	WHERE [MB free] IS NULL

DECLARE 
	@FreeSpace 		varchar( 50 ), 	--Used to hold space value parsed from executing DIR command
	@OK 			int,  			-- >0 if the 'dir' works.
	@Idx			int,
	@DriveShare 	varchar( 40 ),	
	@Command 		varchar( 3000 )	

OPEN DBServerDrives_Cursor
FETCH NEXT FROM DBServerDrives_Cursor INTO @DriveShare
WHILE ( @@fetch_status <> -1 )
BEGIN
	IF ( @@fetch_status <> -2 )
	BEGIN
		--Table #cmd_result to be used to hold the text for executing the 'dir' command
		CREATE TABLE #cmd_result ( output varchar( 8000 ) )
		
		--Construct the command using xp_cmdshell to get free space value and execute it
		SET @Command = 
			'INSERT #cmd_result exec master..xp_cmdshell ''dir "' 
				+ @DriveShare	+ '"'''	 -- a UNC string			
		--PRINT @Command
		EXECUTE ( @Command )
		SELECT @OK = COUNT(*) FROM #cmd_result WHERE OUTPUT like '% bytes free'
		 
		IF @OK > 0	
		BEGIN	--get the line with the 'byte free' text and parse it for the value
			SELECT @FreeSpace = LTRIM( REVERSE( LEFT( output, 40 ) ) )
			FROM #cmd_result WHERE OUTPUT like '% bytes free'
			
			SET @FreeSpace = REVERSE( LEFT( @FreeSpace, ( CHARINDEX( ' ', @FreeSpace ) - 1 )  ) )
			SET @FreeSpace = REPLACE( ISNULL( @FreeSpace, 0 ), ',', '' )
			
			UPDATE #Drives
			SET [MB free] = ROUND( CONVERT( real, @FreeSpace ) / 1048576, 2 ) -- Convert into MB
			WHERE [drive] = @DriveShare
		END
	DROP TABLE #cmd_result
	END
	FETCH NEXT FROM DBServerDrives_Cursor INTO @DriveShare
END
CLOSE DBServerDrives_Cursor
DEALLOCATE DBServerDrives_Cursor

IF @Save_Flag = 'Y'
	begin
	INSERT INTO dbo.DB_FREESPACE_STATS ( Drive, FreeSpace )
		SELECT [drive], [MB free] FROM #Drives
		WHERE [MB free] IS NOT NULL
	-- Purge data older than 3 months
	DELETE FROM dbo.DB_FREESPACE_STATS 
		WHERE DATEDIFF( w, State_Date,GETDATE() ) > 3
	UPDATE dbo.DB_FREESPACE_STATS SET DB = 1 WHERE [drive] in
		( SELECT DISTINCT LEFT( filename, 1 )  FROM master.dbo.sysaltfiles )
	end
ELSE
	SELECT * FROM #DRIVES WHERE [MB free] IS NOT NULL


DROP TABLE #Drives 
GO

