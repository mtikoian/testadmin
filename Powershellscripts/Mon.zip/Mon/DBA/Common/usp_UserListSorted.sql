use DBA
go

IF OBJECT_ID( 'dbo.usp_UserListSorted' ) IS NOT NULL
	DROP PROCEDURE dbo.usp_UserListSorted 
go

CREATE PROCEDURE dbo.usp_UserListSorted( @SortOrder	varchar( 30 ) )
AS
SET NOCOUNT ON
CREATE TABLE #DB_Users
(	
	ServerName		varchar( 30 ),
	UserName		varchar( 30 ),
	Pwd				char( 2 ), 
	DBName			varchar( 30 ),
	RoleName		varchar( 30 ),
	IsNTGroup		char( 2 ),
	IsAliased		char( 2 ),
	SysAdmin		char( 2 ),
	ServerAdmin 	char( 2 ),
	SetupAdmin		char( 2 ),
	ProcessAdmin	char( 2 ),
	SecurityAdmin	char( 2 ),
	DiskAdmin		char( 2 ),
	DBCreator		char( 2 )    
)
DECLARE 
		@DBName		varchar( 30 ),
		@SQLString1 varchar( 200 ),
		@SQLString 	varchar( 1000 )
DECLARE DBcurs CURSOR FOR
	SELECT name 
	FROM master.dbo.sysdatabases
	WHERE name not in ( 'pubs', 'Northwind', 'Tempdb', 'Model' )
SET @SQLString1 = 'INSERT INTO #DB_Users( ServerName, RoleName, DBName, UserName, IsAliased, IsNTGroup ) '
OPEN DBcurs
FETCH NEXT FROM DBcurs INTO @DBName
WHILE @@FETCH_STATUS = 0
	begin
	-- Note:  The 2KPERDAT server has a case-sensitive database ( SC_Prod ), so the table
	--        and column names in the following query must be all lowercase!!!
	SET @SQLString = 'SELECT @@SERVERNAME, ISNULL( r.name, '' '' ),  ''' + @DBName + ''', '
	SET @SQLString = @SQLString + 'CASE WHEN u.isntname = 1 THEN l.name ELSE u.name END, '
	SET @SQLString = @SQLString + 'CASE WHEN u.isaliased = 1 THEN '' Y'' ELSE '' '' END, '
	SET @SQLString = @SQLString + 'CASE WHEN u.isntgroup = 1 THEN '' Y'' ELSE '' '' END '
	SET @SQLString = @SQLString + 'FROM master.dbo.syslogins l JOIN '
	SET @SQLString = @SQLString +  @DBName + '.dbo.sysusers u ON u.sid = l.sid LEFT JOIN '
	SET @SQLString = @SQLString +  @DBName + '.dbo.sysmembers m ON u.uid = m.memberuid LEFT JOIN '
	SET @SQLString = @SQLString +  @DBName + '.dbo.sysusers r ON  r.uid = m.groupuid '
	SET @SQLString = @SQLString + 'WHERE u.isapprole = 0 and u.issqlrole = 0 and u.name NOT IN '
	SET @SQLString = @SQLString + '( ''dbo'', ''guest'', ''INFORMATION_SCHEMA'', ''SYSTEM_FUNCTION_SCHEMA'' ) '
	SET @SQLString = @SQLString + 'ORDER BY   u.name, r.name'
	
	--print @SQLString
	INSERT INTO #DB_Users
		exec( @SQLString1 + @SQLString )
	
	FETCH NEXT FROM DBcurs INTO @DBName
	end
CLOSE DBcurs
DEALLOCATE DBcurs
INSERT INTO #DB_Users( ServerName, RoleName, DBName, UserName, IsAliased, IsNTGroup )
SELECT  @@SERVERNAME, ' ', ' ', name, ' ', CASE WHEN IsNtGroup = 1 THEN ' Y' ELSE ' ' END
FROM master.dbo.syslogins
WHERE name not in ( SELECT UserName FROM #DB_Users )
UPDATE #DB_Users
SET	Pwd 			= 	CASE WHEN password is NULL and ( s.IsNtUser = 0 and s.IsNtGroup = 0 )  THEN ' N' ELSE ' ' END,
	SysAdmin 		= 	CASE WHEN s.Sysadmin = 1 		THEN ' Y' ELSE ' ' END,
	ServerAdmin 	= 	CASE WHEN s.ServerAdmin = 1 	THEN ' Y' ELSE ' ' END,
	SetupAdmin 		= 	CASE WHEN s.Setupadmin = 1		THEN ' Y' ELSE ' ' END,
	ProcessAdmin 	= 	CASE WHEN s.Processadmin = 1	THEN ' Y' ELSE ' ' END,
	SecurityAdmin 	= 	CASE WHEN s.Securityadmin = 1 	THEN ' Y' ELSE ' ' END,
	DiskAdmin 		= 	CASE WHEN s.Diskadmin = 1 		THEN ' Y' ELSE ' ' END,
	DBCreator 		= 	CASE WHEN s.DBCreator = 1		THEN ' Y' ELSE ' ' END
FROM master.dbo.syslogins s
WHERE name = UserName


if @SortOrder = 'Database'
	SELECT 	ServerName,     DBname, 		RoleName,      	UserName,  
			Pwd, 			SysAdmin,		DBCreator		IsNTGroup,  	IsAliased,	
			ServerAdmin, 	SetupAdmin, 	ProcessAdmin, 	SecurityAdmin, 	DiskAdmin 	
	FROM  #DB_Users
	ORDER BY ServerName, DBName, RoleName, UserName

else if @SortOrder = 'Role'
	SELECT 	ServerName,		RoleName,   UserName,      	DBName,    
			Pwd, 			DBCreator,	SysAdmin,	   	IsNTGroup,  		IsAliased,       
			ServerAdmin, 	SetupAdmin, ProcessAdmin, 	SecurityAdmin, 		DiskAdmin
	FROM #DB_Users
	ORDER BY ServerName, RoleName, UserName, DBName

else 
	SELECT 	ServerName,	UserName,   	DBName,        	RoleName,  
			Pwd, 		SysAdmin,	   	DBCreator, 		IsNTGroup,		IsAliased,	
			ServerAdmin,SetupAdmin, 	ProcessAdmin,  	SecurityAdmin,	DiskAdmin	
	FROM #DB_Users
	ORDER BY ServerName,UserName, DBName, RoleName

DROP TABLE #DB_Users
GO
