USE DBA
GO
IF OBJECT_ID( 'dbo.usp_GetDBAttributes' ) IS NOT NULL
	DROP PROCEDURE dbo.usp_GetDBAttributes
go
CREATE PROCEDURE dbo.usp_GetDBAttributes
AS
BEGIN
SET NOCOUNT ON
TRUNCATE TABLE dbo.DBAttributes

INSERT INTO dbo.DBAttributes( DBName, Model, Status )
	SELECT 
		name, 
		CAST( DATABASEPROPERTYEX( name, 'RECOVERY' ) as varchar ), 
		CAST( DATABASEPROPERTYEX(name, 'Status') as varchar )
	FROM master.dbo.sysdatabases
END
go