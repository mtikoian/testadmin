USE DBA
GO
IF OBJECT_ID('dbo.usp_RenameLogDayOfWeekHour') IS NOT NULL
	DROP PROCEDURE dbo.usp_RenameLogDayOfWeekHour
GO

CREATE PROCEDURE dbo.usp_RenameLogDayOfWeekHour
	@FilePath	varchar( 120 )

	/******************************************************

		Renames a file to include the day of the week 
		and the hour of the day as part of the name.

		If the new file name already exists, it gets
		overwritten.

		Example :  
			If the current day is Sunday and the 
			current hour is 11AM, then
			sp_ihRenameLogDayOfWeek 'c:\temp\test.log'
			renames the file to �test_Sunday_11AM.log�

	*******************************************************/
AS
SET NOCOUNT ON
DECLARE 
	@WinCmd varchar(300),
	@rtn	int,
	@jobID uniqueidentifier,
	@seq	int,
	@jobname varchar(300),
	@count int

CREATE TABLE #TEMP
(
	job_id uniqueidentifier ,
	job_name sysname ,
	run_status int ,
	run_date int ,
	run_time int ,
	run_duration int ,
	operator_emailed nvarchar(20) ,
	operator_netsent nvarchar(20), 
	operator_paged nvarchar(20) ,
	retries_attempted int ,
	server nvarchar(30) 
)

SET @rtn = 0

DECLARE
	@DayOfWeek		varchar( 9 ),
	@Datetime		datetime,
	@Hour			int,
	@Path			varchar( 120 ),
	@NewFilePath	varchar( 120 ),
	@FileName		varchar( 120 ),
	@NewName		varchar( 120 )

SET @Path = LEFT( @FilePath, LEN( @FilePath ) - CHARINDEX( '\', REVERSE( @FilePath ) ) + 1 )
SET @FileName = RIGHT( @FilePath, CHARINDEX( '\', REVERSE( @FilePath ) ) - 1 )

SET @Datetime 	= GETDATE()
SET @Hour	  	= DATEPART( hh, @Datetime )
SET @DayOfWeek  = CASE DATEPART( dw, @Datetime )
						WHEN 1 THEN 'Sunday'
						WHEN 2 THEN 'Monday'
						WHEN 3 THEN 'Tuesday'
						WHEN 4 THEN 'Wednesday'
						WHEN 5 THEN 'Thursday'
						WHEN 6 THEN 'Friday'
						ELSE		'Saturday'
				  END
SET @NewName	= LEFT( @FileName, CHARINDEX( '.', @FileName ) - 1 ) +
				  '_' + @DayOfWeek + '_' + 
				  CAST( CASE 
							WHEN @Hour > 12 THEN @Hour - 12
							ELSE @Hour
				  		END AS varchar(2) ) +
				  CASE 
						WHEN @Hour > 12 THEN 'PM'
					    ELSE 'AM'
				  END +
				  RIGHT( @FileName, 4 )

SET @NewFilePath = 	@Path + @NewName
exec dbo.usp_DeleteFile @NewFilePath

SET @WinCmd  = 	'ren "' + @FilePath + '" ' + @NewName + ''

SET @SEQ = 0
SET @jobname = '_Temp_RenameLogDayOfWeekHour'

WHILE @seq < 50
	begin
	set @jobname = @jobname + cast(@seq as varchar)
	SELECT @count = count(*) from msdb.dbo.sysjobs where name = @jobname
	print cast(@count as varchar)
	print @jobname
	if @count = 0
		begin
		EXEC msdb.dbo.sp_add_job @job_name = @jobname, @job_id = @jobID OUTPUT 
		if @jobID is not null set @seq = 99
		end
	set @seq = @seq + 1
	end

IF @jobID is null
	begin
	SET @rtn = -1
	RETURN @rtn
	end


EXEC msdb.dbo.sp_add_jobstep @job_id = @jobID, @step_name = 'Rename Log Day Of Week Hour', @step_id = 1, @subsystem = 'CMDEXEC', @command = @WinCmd
EXEC msdb.dbo.sp_add_jobserver @job_id = @jobID
EXEC @rtn = msdb.dbo.sp_start_job @job_id = @jobID, @output_flag = 0 
IF @rtn <> 0 RETURN @rtn

WAITFOR DELAY '000:00:05' -- Give the job a chance to complete
INSERT INTO #TEMP EXEC msdb.dbo.sp_help_jobhistory @job_id = @jobID

WHILE @@ROWCOUNT = 0
  BEGIN
  WAITFOR DELAY '000:00:05' -- Give the job a chance to complete
  INSERT INTO #TEMP EXEC msdb.dbo.sp_help_jobhistory @job_id = @jobID
  END

SELECT @rtn = max(run_status) FROM #TEMP
IF @rtn <> 1 
	SET @rtn = -1
ELSE
	EXEC msdb.dbo.sp_delete_job @job_id = @jobID


DROP TABLE #TEMP
RETURN @rtn
GO