use DBA
go
		
IF OBJECT_ID( 'dbo.User_Activity_Loc' ) IS NULL
	Create TABLE dbo.User_Activity_Loc
	(	
		SPID		smallint	NOT NULL,
		Status		char(15),
		Login		varchar(64),	
		Host		varchar(64),
		Block		varchar(20),	
		BlkBy		char(4),	
		DB			varchar(64),
		Command		varchar(256),
		CPUTime		char(10),
		DiskIO		char(10),	
		LastBatch	char(15),
		Program		varchar(256),
		Buffer		varchar(255),
		FetchDate	datetime NOT NULL DEFAULT GETDATE()
	)
GO
IF OBJECT_ID( 'dbo.User_Locks_Loc' ) IS NULL
	begin
	Create TABLE dbo.User_Locks_Loc
	(	
		SPID		smallint	NOT NULL,
		ObjName		varchar(60),
		IndexName	varchar(60),
		Type		char(4),
		Resource	char(16),
		Mode		varchar(8),
		Status		varchar(10)
	)
	end
go

IF OBJECT_ID( 'usp_DumpSPIDToTable' ) is not NULL
	DROP PROCEDURE dbo.usp_DumpSPIDToTable
go
CREATE PROCEDURE dbo.usp_DumpSPIDToTable
	
	/*************************************************

			Saves current activity for all
			databases on a server, the contents of 
			the the input buffers on the clients and
			the current locks.

	***************************************************/

AS
BEGIN
SET NOCOUNT ON
CREATE TABLE #Locks_TEMP
(	
	SPID		smallint,
	DBId		smallint,
	ObjId		int,
	IndId		smallint,
	Type		nchar(4),
	Resource	nchar(16),
	Mode		nvarchar(8),
	Status		varchar(10)
)
CREATE TABLE #Input_TEMP
( 	
	EventType nvarchar(30),
	Parameters int,
	EventInfo nvarchar(max)
)
CREATE TABLE #Activity_TEMP
(	
	SPID		smallint,
	Status		char(15),
	Login		varchar(64),	
	HostName	varchar(64),
	BlkBy		char(7),		
	DBName		varchar(64),
	Command		varchar(256),
	CPUTime		char(10),
	DiskIO		char(10),	
	LastBatch	char(15),
	ProgramName	varchar(256),
	SPID2		smallint,
	Requestid 	int
)
TRUNCATE TABLE dbo.User_Locks_Loc
TRUNCATE TABLE dbo.User_Activity_Loc

INSERT INTO #Activity_TEMP EXEC( 'master.dbo.sp_who2' )

INSERT INTO dbo.User_Activity_Loc
( SPID, Status, Login, Host, Program, Block, BlkBy, DB, Command, CPUTime, DiskIO, LastBatch)
	SELECT 	
			SPID, 
			Status, 
			Login, 
			HostName, 
			ProgramName,
		   	CASE WHEN CHARINDEX( '.', BlkBy ) = 0 and cast( BlkBy as smallint ) <> 0 THEN 'Blocked'
				 WHEN CHARINDEX( '.', BlkBy ) = 0 and cast( BlkBy as smallint ) = 0 THEN 'Blocker'
				 ELSE ''
		   	END, 
			CASE WHEN CHARINDEX( '.', BlkBy ) = 0 and cast( BlkBy as smallint ) <> 0 THEN BlkBy
				 ELSE ''
		   	END, 
		   	DBName, 
			Command,
		   	CPUTime,
			DiskIO, 
			LastBatch
		FROM #Activity_TEMP 

DECLARE 
	@Spid  smallint
DECLARE
	SPID_CURSOR CURSOR FOR
	SELECT SPID FROM dbo.User_Activity_Loc WHERE SPID > 50

OPEN SPID_CURSOR
FETCH NEXT FROM SPID_CURSOR INTO @Spid
WHILE @@FETCH_STATUS = 0
	begin
	--EXEC( 'DBCC INPUTBUFFER ( ' + @Spid + ')' )
	INSERT INTO #INPUT_TEMP EXEC( 'DBCC INPUTBUFFER ( ' + @Spid + ')' )

	UPDATE dbo.User_Activity_Loc
	SET Buffer = left(EventInfo, 255)
	FROM #INPUT_TEMP WHERE SPID = @Spid

	TRUNCATE TABLE #INPUT_TEMP
	FETCH NEXT FROM SPID_CURSOR INTO @Spid
	end
CLOSE SPID_CURSOR
DEALLOCATE SPID_CURSOR

INSERT INTO #Locks_TEMP( SPID, DBId, ObjId, IndId, Type, Resource, Mode, Status	)
	EXEC( 'master.dbo.sp_lock' )

DECLARE
	@Cmd		varchar(3000),
	@DB			varchar(60),
	@ObjId		int,
	@IndId		smallint,
	@DBId		smallint,
	@Type		nchar(4),
	@Resource	nchar(16),
	@Mode		nvarchar(8),
	@Status		varchar(10)

DECLARE
	DB_CURS CURSOR FOR
	SELECT SPID, ObjId, IndId, Type, Resource, Mode, Status, DBId
	FROM #Locks_TEMP
	WHERE Type <> 'DB'

OPEN DB_CURS
FETCH NEXT FROM DB_CURS INTO @Spid, @ObjId, @IndId, @Type, @Resource, @Mode, @Status, @DBId
WHILE @@FETCH_STATUS = 0
	begin
	SELECT @DB = name FROM master.dbo.sysdatabases where dbid = @DBId
	--PRINT @DB
	IF @IndId > 0
		SET @Cmd =
		'INSERT INTO dbo.User_Locks_Loc( SPID, ObjName, IndexName, Type, Resource, Mode, Status)
		SELECT cast( ''' + cast( @Spid as varchar ) + ''' as smallint ), LEFT( o.name, 60 ) , LEFT( i.name, 60 ), ''' + @Type +
		''', ''' + @Resource + ''', ''' + @Mode + ''', ''' + @Status  +
		''' FROM ' + @DB + '.dbo.sysobjects o ' +
		' JOIN ' + @DB + '.dbo.sysindexes i on i.id = o.id' +
		' WHERE o.id = ' + cast( @ObjId as varchar ) + ' and i.indid = ' + cast( @IndId as varchar )
	ELSE
		SET @Cmd =
		'INSERT INTO dbo.User_Locks_Loc( SPID, ObjName, IndexName, Type, Resource, Mode, Status)
		SELECT cast( ''' + cast( @Spid as varchar ) + ''' as smallint ), LEFT( o.name, 60 ) , '''', ''' + @Type +
		''', ''' + @Resource + ''', ''' + @Mode + ''', ''' + @Status  +
		''' FROM ' + @DB + '.dbo.sysobjects o WHERE o.id = ' + cast( @ObjId as varchar )

	--PRINT @Cmd
	EXEC( @Cmd )
	FETCH NEXT FROM DB_CURS INTO @Spid, @ObjId, @IndId, @Type, @Resource, @Mode, @Status, @DBId
	end
CLOSE DB_CURS
DEALLOCATE DB_CURS

END
go

--SELECT * FROM dbo.User_Activity_Loc
--SELECT * FROM dbo.User_Locks_Loc

