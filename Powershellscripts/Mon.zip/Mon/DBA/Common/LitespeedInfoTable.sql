use dba
go
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[LitespeedInfo]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[LitespeedInfo]
GO

CREATE TABLE [dbo].[LitespeedInfo] (
	[Name] [varchar] (50)  NULL ,
	[Value] [varchar] (50) NULL 
) ON [PRIMARY]
GO

