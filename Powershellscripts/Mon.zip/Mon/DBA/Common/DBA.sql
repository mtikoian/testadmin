use DBA
go
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[LitespeedInfo]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[LitespeedInfo]
GO

IF OBJECT_ID( 'dbo.usp_RenameFileWithDateTimeNoSS' ) IS NOT NULL
	DROP PROCEDURE dbo.usp_RenameFileWithDateTimeNoSS
GO
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[udf_InsertCommas]') and xtype in (N'FN', N'IF', N'TF'))
drop function [dbo].[udf_InsertCommas]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[udf_RecoveryModel]') and xtype in (N'FN', N'IF', N'TF'))
drop function [dbo].[udf_RecoveryModel]
GO
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_RenameFile_MMDDYY]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
DROP PROCEDURE [dbo].[usp_RenameFile_MMDDYY]
go

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_IndexDefrag2005]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
DROP PROCEDURE [dbo].[usp_IndexDefrag2005]
go

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_BinaryToHexadecimal]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_BinaryToHexadecimal]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_CollectFreeSpaceStats]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_CollectFreeSpaceStats]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_CopyFile]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_CopyFile]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_DeleteBakHistory]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_DeleteBakHistory]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_DeleteDatedFiles]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_DeleteDatedFiles]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_DeleteDiffHistory]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_DeleteDiffHistory]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_DeleteFile]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_DeleteFile]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_DeleteLogHistory]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_DeleteLogHistory]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_DifferentialBackup]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_DifferentialBackup]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_DoesFileExist]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_DoesFileExist]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_DumpSPIDToTable]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_DumpSPIDToTable]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_GetAgentJobs]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_GetAgentJobs]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_GetDBAttributes]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_GetDBAttributes]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_GetFileDate]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_GetFileDate]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_GetRecordCounts]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_GetRecordCounts]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_Get_DbStats3]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_Get_DbStats3]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_Get_WaitStats]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_Get_WaitStats]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_KillUsers]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_KillUsers]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_MoveFile]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_MoveFile]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_RebuildShowcontigIndexes]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_RebuildShowcontigIndexes]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_RecoveryModel]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_RecoveryModel]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_RenameFileDayOfWeek]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_RenameFileDayOfWeek]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_RenameFileDayOfWeekHour]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_RenameFileDayOfWeekHour]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_RenameFileWithDateTime]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_RenameFileWithDateTime]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_RenameFile_YYYYMMDD]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_RenameFile_YYYYMMDD]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_RenameFile_YYYYxMMxDD]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_RenameFile_YYYYxMMxDD]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_RenameLogDayOfWeek]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_RenameLogDayOfWeek]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_RenameLogDayOfWeekHour]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_RenameLogDayOfWeekHour]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_RenameLogWithDateTime]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_RenameLogWithDateTime]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_RoleMembers]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_RoleMembers]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_Showcontig]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_Showcontig]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_Track_WaitStats]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_Track_WaitStats]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_UserList2]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_UserList2]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Agent_Jobs]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[Agent_Jobs]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DBAttributes]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[DBAttributes]
GO

if object_id( 'dbo.ServerInfo' ) is not null
	drop table [dbo].[ServerInfo]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DBSTATS]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[DBSTATS]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DB_FREESPACE_STATS]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[DB_FREESPACE_STATS]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Showcontig]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[Showcontig]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Table_Counts]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[Table_Counts]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[User_Activity_Loc]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[User_Activity_Loc]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[User_Locks_Loc]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[User_Locks_Loc]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[WaitStats]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[WaitStats]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[tmp_sfs]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[tmp_sfs]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[tmp_stats]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[tmp_stats]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[tmplg]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[tmplg]
GO

if object_id(N'[dbo].[OrphanLogin]') is not null
drop table [dbo].[OrphanLogin]
GO


CREATE FUNCTION dbo.udf_InsertCommas( @VarNumber	varchar( 15 ) )
	RETURNS varchar

/********************************************************

	User-Defined function to insert
	commas into a string representing 
	a number.

********************************************************/
	
AS BEGIN
	
	DECLARE 
		@DecimalPoint	int,
		@FirstComma		int,
		@WithCommas	    varchar( 15 )


	SET @WithCommas = @VarNumber
	if @WithCommas is null RETURN @WithCommas

	SET @DecimalPoint = CHARINDEX( '.', @WithCommas )

	if @DecimalPoint = 0
		SET @FirstComma = LEN( @WithCommas ) + 1
	else
		SET @FirstComma	= @DecimalPoint
	

	WHILE ( @FirstComma > 4 )
	begin
		SET @WithCommas = LEFT( @WithCommas, @FirstComma - 4 ) + ',' + 
						 RIGHT( @WithCommas, Len( @WithCommas ) - @FirstComma + 4  )
		SET @FirstComma = CHARINDEX( ',', @WithCommas )
	end
	
	RETURN @WithCommas
END

GO



CREATE FUNCTION dbo.udf_RecoveryModel( @DB	varchar(60) )
RETURNS varchar(60)
AS
BEGIN

DECLARE @Model	varchar(60)
SELECT @Model = cast( DATABASEPROPERTYEX( name, 'recovery') as varchar )
FROM master.dbo.sysdatabases WHERE name = @DB

RETURN @Model
END

GO


CREATE TABLE [dbo].[Agent_Jobs] (
	[job_id] [uniqueidentifier] NOT NULL ,
	[last_run_date] [int] NOT NULL ,
	[last_run_time] [int] NOT NULL ,
	[next_run_date] [int] NOT NULL ,
	[next_run_time] [int] NOT NULL ,
	[next_run_schedule_id] [int] NOT NULL ,
	[requested_to_run] [int] NOT NULL ,
	[request_source] [int] NOT NULL ,
	[request_source_id] [sysname] NULL ,
	[running] [int] NOT NULL ,
	[current_step] [int] NOT NULL ,
	[current_retry_attempt] [int] NOT NULL ,
	[job_state] [int] NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[DBAttributes] (
	[DBName] [varchar] (60) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Model] [varchar] (60) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Status] [varchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[DBSTATS] (
	[Id] [int] IDENTITY (1, 1) NOT NULL ,
	[ServerName] [char] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[DBName] [char] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Data_Size] [decimal](38, 2) NULL ,
	[Data_Used] [decimal](38, 2) NULL ,
	[Log_Size] [decimal](38, 2) NULL ,
	[Log_Used] [decimal](38`, 2) NULL ,
	[State_Date] [datetime] NOT NULL ,
	[PercentLog] [decimal](9, 2) NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[DB_FREESPACE_STATS] (
	[Id] [int] IDENTITY (1, 1) NOT NULL ,
	[ServerName] [char] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Drive] [varchar] (40) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[FreeSpace] [real] NULL ,
	[State_Date] [datetime] NOT NULL ,
	[DB] [bit] NOT NULL 
) ON [PRIMARY]
GO


CREATE TABLE [dbo].[LitespeedInfo] (
	[Name] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Value] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL 
) ON [PRIMARY]
GO


CREATE TABLE [dbo].[Showcontig] (
	[Add_Date] [datetime] NOT NULL ,
	[DBName] [sysname] NOT NULL ,
	[TableName] [varchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[TableId] [int] NOT NULL ,
	[IndexName] [varchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[IndexId] [int] NOT NULL ,
	[Lvl] [int] NULL ,
	[CountPages] [int] NULL ,
	[CountRows] [int] NULL ,
	[MinRecSize] [int] NULL ,
	[MaxRecSize] [int] NULL ,
	[AvgRecSize] [int] NULL ,
	[ForRecCount] [int] NULL ,
	[Extents] [int] NULL ,
	[ExtentSwitches] [int] NULL ,
	[AvgFreeBytes] [int] NULL ,
	[AvgPageDensity] [decimal](18, 0) NULL ,
	[ScanDensity] [decimal](18, 0) NULL ,
	[BestCount] [int] NULL ,
	[ActualCount] [int] NULL ,
	[LogicalFrag] [decimal](18, 0) NULL ,
	[ExtentFrag] [decimal](18, 0) NULL ,
	[Owner] [sysname] NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[Table_Counts] (
	[DBName] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[TableName] [varchar] (80) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[RecordCount] [int] NULL ,
	[Owner] [sysname] NOT NULL ,
	[SampleDate] [datetime] NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[User_Activity_Loc] (
	[SPID] [smallint] NOT NULL ,
	[Status] [char] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Login] [varchar] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Host] [varchar] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Block] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[BlkBy] [char] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[DB] [varchar] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Command] [varchar] (256) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[CPUTime] [char] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[DiskIO] [char] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[LastBatch] [char] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Program] [varchar] (256) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Buffer] [varchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[FetchDate] [datetime] NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[User_Locks_Loc] (
	[SPID] [smallint] NOT NULL ,
	[ObjName] [varchar] (60) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[IndexName] [varchar] (60) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Type] [char] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Resource] [char] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Mode] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Status] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[WaitStats] (
	[Wait Type] [varchar] (80) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Requests] [numeric](20, 1) NULL ,
	[Wait Time] [numeric](20, 1) NULL ,
	[Signal Wait Time] [numeric](20, 1) NULL ,
	[Now] [datetime] NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[tmp_sfs] (
	[DBName] [nvarchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[FileId] [int] NULL ,
	[FileGroup] [int] NULL ,
	[TotalExtents] [int] NULL ,
	[UsedExtents] [int] NULL ,
	[Name] [varchar] (1024) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[FileName] [varchar] (1024) COLLATE SQL_Latin1_General_CP1_CI_AS NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[tmp_stats] (
	[TotalExtents] [int] NULL ,
	[UsedExtents] [int] NULL ,
	[DBName] [varchar] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[LogSize] [real] NULL ,
	[LogSpaceUsed] [real] NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[tmplg] (
	[DBName] [varchar] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[LogSize] [real] NULL ,
	[LogSpaceUsed] [real] NULL ,
	[Status] [int] NULL 
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[DB_FREESPACE_STATS] WITH NOCHECK ADD 
	CONSTRAINT [PK_DB_FREESPACE_STATS] PRIMARY KEY  CLUSTERED 
	(
		[Id]
	) WITH  FILLFACTOR = 90  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[Showcontig] WITH NOCHECK ADD 
	CONSTRAINT [PK_Showcontig] PRIMARY KEY  CLUSTERED 
	(
		[DBName],
		[TableId],
		[IndexId]
	) WITH  FILLFACTOR = 90  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[Table_Counts] WITH NOCHECK ADD 
	CONSTRAINT [PK_Table_Counts] PRIMARY KEY  CLUSTERED 
	(
		[DBName],
		[Owner],
		[TableName],
		[SampleDate]
	) WITH  FILLFACTOR = 90  ON [PRIMARY] 
GO

CREATE TABLE [dbo].[ServerInfo](
	[ProductVersion] [varchar](50) NULL,
	[ProductLevel] [varchar](50) NULL,
	[Edition] [varchar](50) NULL
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[DBSTATS] ADD 
	CONSTRAINT [DF_DBSTATS_ServerName] DEFAULT (@@servername) FOR [ServerName],
	CONSTRAINT [DF_DBSTATS_Stat_Date] DEFAULT (getdate()) FOR [State_Date]
GO

 CREATE  INDEX [IX_DBSTATS_2] ON [dbo].[DBSTATS]([DBName]) WITH  FILLFACTOR = 90 ON [PRIMARY]
GO

 CREATE  INDEX [IX_DBSTATS_1] ON [dbo].[DBSTATS]([ServerName], [DBName]) WITH  FILLFACTOR = 90 ON [PRIMARY]
GO

ALTER TABLE [dbo].[DB_FREESPACE_STATS] ADD 
	CONSTRAINT [DF_FREESPACE_ServerName] DEFAULT (@@servername) FOR [ServerName],
	CONSTRAINT [DF_FREESPACE_Stat_Date] DEFAULT (getdate()) FOR [State_Date],
	CONSTRAINT [DF__DB_FREESPACE__DB__13F1F5EB] DEFAULT (0) FOR [DB]
GO

 CREATE  UNIQUE  INDEX [IX_Showcontig] ON [dbo].[Showcontig]([DBName], [TableName], [IndexName]) WITH  FILLFACTOR = 90 ON [PRIMARY]
GO

ALTER TABLE [dbo].[User_Activity_Loc] ADD 
	CONSTRAINT [DF__User_Acti__Fetch__73852659] DEFAULT (getdate()) FOR [FetchDate]
GO

ALTER TABLE [dbo].[WaitStats] ADD 
	CONSTRAINT [DF__WaitStats__Now__412EB0B6] DEFAULT (getdate()) FOR [Now]
GO



CREATE PROCEDURE dbo.usp_BinaryToHexadecimal
    @BinValue varbinary(256),
    @HexValue varchar(256) OUTPUT
/*************************************************

	Converts a binary value to a hexadecimal.

**************************************************/
AS
DECLARE 
	@CharValue 	varchar(256),
	@i 			int,
	@Length 	int,
	@HexString 	char(16)

SET @CharValue = '0x'
SET @i = 1
SET @Length = DATALENGTH (@BinValue)
SET @HexString = '0123456789ABCDEF' 

WHILE (@i <= @Length) 
BEGIN
  DECLARE 
		@TempInt 	int,
  		@FirstInt 	int,
  		@SecondInt 	int

  SET @TempInt = CONVERT(int, SUBSTRING(@binvalue,@i,1))
  SET @FirstInt = FLOOR(@TempInt/16)
  SET @SecondInt = @TempInt - (@FirstInt*16)
  SET @CharValue = @CharValue + SUBSTRING(@HexString, @FirstInt+1, 1) +
    							SUBSTRING(@HexString, @SecondInt+1, 1)
  SET @i = @i + 1
END
SET @hexvalue = @CharValue
GO


CREATE PROCEDURE dbo.usp_CollectFreeSpaceStats
		@Save_Flag	char(1) = 'N'
AS
/************************************************************************************

   Determines the amount of free space on each drive that is 
   used by SQL Server data, log and backup files.  Also checks space
   on drive shares used by jobs with 'copy' or 'move' command.  This  
   includes drive shares from other servers.

   If Save_Flag = 'Y', the results are collected into table 
   DB_FREESPACE_STATS for later analysis, else a result set is returned.

*************************************************************************************/

SET NOCOUNT ON
CREATE TABLE #Drives ( [drive] varchar( 40 ), [MB free] int ) 

--	Get the local or mapped drives 
INSERT INTO #Drives EXEC master..xp_fixeddrives
--SELECT * FROM #Drives

--	Include drive shares on other servers from backup jobs
INSERT INTO #Drives( [drive] )
	SELECT DISTINCT  
	LEFT( physical_device_name, 
		CHARINDEX( '\', physical_device_name, 
		CHARINDEX( '\', physical_device_name, 3 ) + 1 ) - 1  )
	FROM msdb..backupmediafamily 
	WHERE LEFT( physical_device_name, 2 ) = '\\'

/******************************************************************

		Get drive shares that are being used in 'move' or 'copy' 
		DOS jobs.  These are frequently used to move local backups
		to other servers on the network.

*******************************************************************/

DECLARE
	@DrivePath	varchar(120),
	@PathStart  int,
	@PathEnd	int,
	@DOSCommand varchar(1600)

DECLARE
	JobCurs CURSOR FOR
	SELECT [command] FROM msdb..sysjobsteps
	WHERE subsystem = 'CmdExec' and 
		 ( command LIKE 'move %' OR command LIKE 'copy %' )

OPEN JobCurs
FETCH NEXT FROM JobCurs INTO @DOSCommand
WHILE @@FETCH_STATUS = 0
	begin
	SET @PathStart = 0
	SET @PathEnd = 0
	SET @DrivePath = NULL
	SET @PathStart = CHARINDEX( '\\', @DOSCommand )
	
	IF @PathStart > 0 
		SET @PathEnd = 	CHARINDEX( '\', @DOSCommand, 
						CHARINDEX( '\', @DOSCommand, @PathStart + 2 ) + 1 )
	
	IF @PathStart <> 0
		IF @PathEnd <> 0
			SET @DrivePath = SUBSTRING( @DOSCommand, @PathStart, @PathEnd - @PathStart )
		ELSE
			SET @DrivePath = SUBSTRING( @DOSCommand, @PathStart, LEN( @DOSCommand ) - @PathStart )
	
	IF RIGHT( @DrivePath, 1 ) = '"'
		SET @DrivePath = RIGHT( @DrivePath, LEN( @DrivePath ) - 1 )

	INSERT INTO #Drives( [drive] ) 
		SELECT @DrivePath
		WHERE @DrivePath NOT IN ( SELECT [drive] FROM #Drives )
	FETCH NEXT FROM JobCurs INTO @DOSCommand
	end
CLOSE JobCurs
DEALLOCATE JobCurs
--SELECT * FROM #Drives

/*
--Get amount of freespace for each drive share
DECLARE 
	DBServerDrives_Cursor CURSOR FOR 
	SELECT [drive] FROM  #Drives  
	WHERE [MB free] IS NULL

DECLARE 
	@FreeSpace 		varchar( 50 ), 	--Used to hold space value parsed from executing DIR command
	@OK 			int,  			-- >0 if the 'dir' works.
	@Idx			int,
	@DriveShare 	varchar( 40 ),	
	@Command 		varchar( 3000 )	

OPEN DBServerDrives_Cursor
FETCH NEXT FROM DBServerDrives_Cursor INTO @DriveShare
WHILE ( @@fetch_status <> -1 )
BEGIN
	IF ( @@fetch_status <> -2 )
	BEGIN
		--Table #cmd_result to be used to hold the text for executing the 'dir' command
		CREATE TABLE #cmd_result ( output varchar( 8000 ) )
		
		--Construct the command using xp_cmdshell to get free space value and execute it
		SET @Command = 
			'INSERT #cmd_result exec master..xp_cmdshell ''dir "' 
				+ @DriveShare	+ '"'''	 -- a UNC string			
		--PRINT @Command
		EXECUTE ( @Command )
		SELECT @OK = COUNT(*) FROM #cmd_result WHERE OUTPUT like '% bytes free'
		 
		IF @OK > 0	
		BEGIN	--get the line with the 'byte free' text and parse it for the value
			SELECT @FreeSpace = LTRIM( REVERSE( LEFT( output, 40 ) ) )
			FROM #cmd_result WHERE OUTPUT like '% bytes free'
			
			SET @FreeSpace = REVERSE( LEFT( @FreeSpace, ( CHARINDEX( ' ', @FreeSpace ) - 1 )  ) )
			SET @FreeSpace = REPLACE( ISNULL( @FreeSpace, 0 ), ',', '' )
			
			UPDATE #Drives
			SET [MB free] = ROUND( CONVERT( real, @FreeSpace ) / 1048576, 2 ) -- Convert into MB
			WHERE [drive] = @DriveShare
		END
	DROP TABLE #cmd_result
	END
	FETCH NEXT FROM DBServerDrives_Cursor INTO @DriveShare
END
CLOSE DBServerDrives_Cursor
DEALLOCATE DBServerDrives_Cursor
*/

IF @Save_Flag = 'Y'
	begin
	INSERT INTO dbo.DB_FREESPACE_STATS ( Drive, FreeSpace )
		SELECT [drive], [MB free] FROM #Drives
		WHERE [MB free] IS NOT NULL
	-- Purge data older than 3 months
	DELETE FROM dbo.DB_FREESPACE_STATS 
		WHERE DATEDIFF( w, State_Date,GETDATE() ) > 3
	UPDATE dbo.DB_FREESPACE_STATS SET DB = 1 WHERE [drive] in
		( SELECT DISTINCT LEFT( filename, 1 )  FROM master.dbo.sysaltfiles )
	end
ELSE
	SELECT * FROM #DRIVES WHERE [MB free] IS NOT NULL


DROP TABLE #Drives 
GO



CREATE PROCEDURE dbo.usp_CopyFile ( @SourceFile 	varchar(120),
    				    @Destination   	varchar(120))
AS
BEGIN
SET NOCOUNT ON
DECLARE 
	@WinCmd varchar(300),
	@rtn	int,
	@jobID uniqueidentifier,
	@seq	int,
	@jobname varchar(300),
	@count int

CREATE TABLE #TEMP
(
	job_id uniqueidentifier ,
	job_name sysname ,
	run_status int ,
	run_date int ,
	run_time int ,
	run_duration int ,
	operator_emailed nvarchar(20) ,
	operator_netsent nvarchar(20), 
	operator_paged nvarchar(20) ,
	retries_attempted int ,
	server nvarchar(30) 
)

SET @rtn = 0

IF CHARINDEX( '*', @SourceFile ) = 0
	begin
	DECLARE  @FileExists	char(1)
	exec usp_DoesFileExist @SourceFile, @FileExists out
	IF @FileExists = 'N'
		begin
		PRINT 'File ' + @SourceFile + ' does not exist'
		RETURN -1
		end
	end


SET @WinCmd = 'Copy "' + @SourceFile + '" "' + @Destination + '"'
SET @rtn = 0
SET @SEQ = 0
SET @jobname = '_Temp_Copy_File'

WHILE @seq < 50
	begin
	set @jobname = @jobname + cast(@seq as varchar)
	SELECT @count = count(*) from msdb.dbo.sysjobs where name = @jobname
	print cast(@count as varchar)
	print @jobname
	if @count = 0
		begin
		EXEC msdb.dbo.sp_add_job @job_name = @jobname, @job_id = @jobID OUTPUT 
		if @jobID is not null set @seq = 99
		end
	set @seq = @seq + 1
	end

IF @jobID is null
	begin
	SET @rtn = -1
	RETURN @rtn
	end

EXEC msdb.dbo.sp_add_jobstep @job_id = @jobID, @step_name = 'Copy File', @step_id = 1, @subsystem = 'CMDEXEC', @command = @WinCmd
EXEC msdb.dbo.sp_add_jobserver @job_id = @jobID
EXEC @rtn = msdb.dbo.sp_start_job @job_id = @jobID, @output_flag = 0 
IF @rtn <> 0 RETURN @rtn

WAITFOR DELAY '000:00:05' -- Give the job a chance to complete
INSERT INTO #TEMP EXEC msdb.dbo.sp_help_jobhistory @job_id = @jobID

WHILE @@ROWCOUNT = 0
  BEGIN
  WAITFOR DELAY '000:00:05' -- Give the job a chance to complete
  INSERT INTO #TEMP EXEC msdb.dbo.sp_help_jobhistory @job_id = @jobID
  END

SELECT @rtn = max(run_status) FROM #TEMP
IF @rtn <> 1 
	SET @rtn = -1
ELSE
	EXEC msdb.dbo.sp_delete_job @job_id = @jobID

DROP TABLE #TEMP
RETURN @rtn
END
go





CREATE PROCEDURE dbo.usp_DeleteBakHistory 
		@Path			varchar( 120 ),
		@DBName			varchar( 80 ) = 'pubs',
		@HistoryValue	int = 7,
		@HistoryMetric	varchar( 5 ) = 'DAYS'

/************************************************************************************

	Deletes backup files that are older than the amount of history requested.

	Backups are assumed to be named according using the same format as
	is assumed to be of the same format as the names of full backups 
	generated from the sqlmaint utility.  For example, the backup name for
	the Northwind database would be Northwind_Full_200312300600.BAK. 

	Parameters:
		Path			Path of database backups 
		DBName			Name of database  ( default = 'pubs' )
		HistoryValue	Number of days or weeks  ( default = 7 )
		HistoryMetric	Days or Weeks ( default = 'DAYS' )

	Examples:
		usp_DeleteBakHistory '\\172.24.60.76\Ddrive\2ksqlprod2\Northwind', 'Northwind', 1, 'WEEKS'    
			( deletes backup files from \\172.24.60.76\Ddrive\2ksqlprod2\Northwind
			  that are older than 1 week.  )

		usp_DeleteBakHistory 'M:\Backups\Northwind', 'Northwind'	( keep history for 7 days )

*************************************************************************************/
AS
SET NOCOUNT ON

CREATE TABLE #cmd_result 
( 
     output varchar( 8000 ) NULL
)

DECLARE 
	@jobID        	uniqueidentifier,
    @jobname        varchar(30),
	@Cmd        	varchar( 1000 ),
	@DateString		varchar( 10 ),
	@BakName 		varchar( 80 ),
	@BakDate		datetime,
	@Count			int,
	@Rtn			int

SET @HistoryMetric = UPPER( @HistoryMetric )
SET @Rtn           = 0

IF @Path IS NULL
	begin
	RAISERROR( 'NO PATH SPECIFIED',  18, 1 ) 
	RETURN(-1)
	end

SET @Path = RTRIM( @Path )
IF RIGHT( @Path, 1 ) = '\'  SET @Path = LEFT( @Path, LEN( @Path ) - 1 )
	
SELECT @Count = COUNT(*) FROM master..sysdatabases WHERE name = @DBName
IF @Count = 0 
	begin
	RAISERROR( 'INVALID DATABASE NAME',  18, 1 )
	RETURN(-1)
	end

IF UPPER( @HistoryMetric ) NOT IN ( 'DAYS', 'WEEKS' )
	begin
	RAISERROR( 'INVALID HISTORY METRIC', 18, 1 )
	RETURN(-1)
	end

SET @Cmd = 'INSERT #cmd_result exec master..xp_procedure ''dir '

SET @Cmd = @Cmd + '"' + @Path + '\' + @DBName + '_Full_*.BAK"'''

EXECUTE ( @Cmd )

DELETE FROM #cmd_result WHERE CHARINDEX( '.BAK', output ) = 0
DELETE FROM #cmd_result WHERE output is null

DECLARE 
	BAK_CURS CURSOR FOR
	SELECT 
		LEFT( output, 10 ), 
		RIGHT( output, CHARINDEX( ' ', REVERSE( output ) ) - 1 ) 
	FROM #cmd_result

SELECT @Count = COUNT(*) FROM #cmd_result

IF @Count = 0 
	PRINT 'NO BACKUPS FOUND'
--ELSE IF @Count <= @HistoryValue
--	PRINT 'NUMBER OF BACKUPS NOT EXCEEDED'
ELSE
  BEGIN
	SET @Count = 0
	PRINT 'SEARCHING FOR BACKUP TO DELETE'
	OPEN BAK_CURS
	FETCH FROM BAK_CURS INTO @DateString, @BakName
	WHILE @@FETCH_STATUS = 0
	  BEGIN
		SET @BakDate = @DateString
		PRINT @BakDate
		SET @Cmd = 'del "' + @Path + '\' + @BakName + '"'
					
		IF @HistoryMetric = 'DAYS' AND DATEDIFF( DAY, @BakDate, GETDATE() ) >= @HistoryValue
		  BEGIN
			PRINT 'DELETING ' + @BakName
            set @jobname = '_tmp_Delete' + convert(varchar(10), @count) 
            EXEC msdb.dbo.sp_add_job @job_name = @jobname, @enabled  = 1, 
                 @start_step_id = 1, @owner_login_name='sa'
            EXEC msdb.dbo.sp_add_jobstep @job_name = @jobname, @step_name = 'Delete Old Backups', 
                 @step_id = 1, @subsystem = 'CMDEXEC', @command = @cmd
            EXEC msdb.dbo.sp_add_jobserver @job_name = @jobname
            EXEC @Rtn = msdb.dbo.sp_start_job @job_name = @jobname, @output_flag = 0
            If @Rtn <> 0 
                 RETURN @Rtn
            WAITFOR DELAY '000:00:05' -- Give the job a chance to complete
            EXEC @Rtn = msdb.dbo.sp_delete_job @job_name = @jobname
            If @Rtn <> 0 
                 RETURN @Rtn
			SET @Count = @Count + 1
		  END

		ELSE IF DATEDIFF( WEEK, @BakDate, GETDATE() ) >= @HistoryValue
		  BEGIN
			PRINT 'DELETING ' + @BakName
            set @jobname = '_tmp_Delete' + convert(varchar(10), @count) 
            EXEC msdb.dbo.sp_add_job @job_name = @jobname, @enabled  = 1, 
                 @start_step_id = 1, @owner_login_name='sa'
            EXEC msdb.dbo.sp_add_jobstep @job_name = @jobname, @step_name = 'Delete Old Backups', 
                 @step_id = 1, @subsystem = 'CMDEXEC', @command = @cmd
            EXEC msdb.dbo.sp_add_jobserver @job_name = @jobname
            EXEC @Rtn = msdb.dbo.sp_start_job @job_name = @jobname, @output_flag = 0
            If @Rtn <> 0 
                 RETURN @Rtn
            WAITFOR DELAY '000:00:05' -- Give the job a chance to complete
            EXEC @Rtn = msdb.dbo.sp_delete_job @job_name = @jobname
            If @Rtn <> 0 
                 RETURN @Rtn
			SET @Count = @Count + 1
		  END

		FETCH FROM BAK_CURS INTO @DateString, @BakName
	  END	
	CLOSE BAK_CURS
	PRINT CAST( @Count as varchar ) + ' FILES DELETED'
  END

DEALLOCATE BAK_CURS
DROP TABLE #cmd_result

RETURN @Rtn

go




CREATE PROCEDURE dbo.usp_DeleteDatedFiles 
		@Path			varchar( 120 ),
		@Prefix			varchar( 120 ),
		@Suffix			varchar( 120 ),
		@HistoryValue	int = 7,
		@HistoryMetric	varchar( 20 ) = 'DAYS'

/************************************************************************************

	Deletes import files having the format PrefixYYYYMMDDSuffix whose date 
	is more than the age specified.
	
	Parameters:
		Path			Path 
		Prefix			Name of file preceding the date
		Suffix			Name of file following the date
		HistoryValue	Number of days or weeks  ( default = 7 )
		HistoryMetric	Days or Weeks ( default = 'DAYS' )

	Examples:
	sp_ihDeleteDatedFiles 'M:\Temp', 'vss_', '.csv'	
			( keep history for 7 days for files named vss_YYYYMMDD.csv )

	sp_ihDeleteDatedFiles 'M:\Temp', 'vssVendors', '.csv', 30 
			( keep history for 30 days for files named vssVendorsYYYYMMDD.csv )

	sp_ihDeleteDatedFiles 'M:\Temp', 'vss_', abc.csv', 5, 'WEEKS'	
			( keep history for 5 weeks for files named vss_YYYYMMDDabc.csv )

*************************************************************************************/
AS

SET NOCOUNT ON

CREATE TABLE #cmd_result ( output varchar( 1000 ) NULL )

DECLARE 
	@Command 		varchar( 1000 ),
	@DateString		varchar( 10 ),
	@FileName 		varchar( 120 ),
	@Date			datetime,
	@Count			int

SET @HistoryMetric = UPPER( @HistoryMetric )
	
IF UPPER( @HistoryMetric ) NOT IN ( 'DAYS', 'WEEKS' )
	begin
	RAISERROR( 'INVALID HISTORY METRIC', 18, 1 ) WITH LOG
	RETURN
	end

SET @Path = RTRIM( @Path )
IF LEFT( @Path, 1 ) <> '\'  SET @Path = @Path + '\'

SET @Command = 'INSERT #cmd_result exec master..xp_procedure ''dir '
SET @Command = @Command + '"' + @Path + '"'''
PRINT @Command
EXECUTE ( @Command )

DELETE FROM #cmd_result WHERE output IS NULL

DELETE FROM #cmd_result 
WHERE RIGHT( RTRIM( output ), LEN( @Suffix ) ) <> @Suffix  

IF @Count = 0
	PRINT 'No FILES FOUND'
ELSE
	begin
	DECLARE 
		DIR_CURS CURSOR FOR
		SELECT RIGHT( output, CHARINDEX( ' ', REVERSE( RTRIM( output ) ) ) - 1 ) -- file name
		FROM #cmd_result

	SET @Count = 0
	PRINT 'SEARCHING FOR FILE TO DELETE'
	OPEN DIR_CURS
	FETCH FROM DIR_CURS INTO @FileName
	WHILE @@FETCH_STATUS = 0
		begin
		IF  LEN( @FileName ) = LEN( @Prefix ) + LEN( @Suffix ) + 8 AND
			LEFT( @FileName, LEN( @Prefix ) ) = @Prefix AND
			RIGHT( @FileName, LEN( @FileName ) - ( LEN( @Prefix ) + 8 ) ) = @Suffix AND
			ISNUMERIC( SUBSTRING( @FileName, LEN( @Prefix ) + 1, 8 ) ) = 1
			begin
			SET @DateString = SUBSTRING( @FileName, LEN( @Prefix ) + 5, 2 ) + '/' +
							  SUBSTRING( @FileName, LEN( @Prefix ) + 7, 2 ) + '/' +
							  SUBSTRING( @FileName, LEN( @Prefix ) + 1, 4 )
			SET @Date = CAST( @DateString  as datetime )

			IF @HistoryMetric = 'DAYS' AND DATEDIFF( DAY, @Date, GETDATE() ) >= @HistoryValue
				begin
				PRINT 'DELETING ' + @FileName
				SET @Command = 'master.dbo.xp_procedure ''del "' + @Path + @FileName + '"'''
                PRINT @Command
            	EXEC( @Command )
				SET @Count = @Count + 1
				end

			ELSE IF DATEDIFF( WEEK, @Date, GETDATE() ) >= @HistoryValue
				begin
				PRINT 'DELETING ' + @FileName
				SET @Command = 'master.dbo.xp_procedure ''del "' + @Path + @FileName + '"'''
                PRINT @Command
            	EXEC( @Command )
				SET @Count = @Count + 1
				end
			end
		FETCH FROM DIR_CURS INTO @FileName
		end	
	CLOSE DIR_CURS
	PRINT CAST( @Count as varchar ) + ' FILES DELETED'
	DEALLOCATE DIR_CURS
	DROP TABLE #cmd_result
	end
go



CREATE PROCEDURE dbo.usp_DeleteDiffHistory 
		@Path			varchar( 120 ),
		@DBName			varchar( 80 ) = 'pubs',
		@HistoryValue	int = 7,
		@HistoryMetric	varchar( 5 ) = 'DAYS'

/************************************************************************************

	Deletes differential backup files that are older than the amount 
	of history requested.

	Files are assumed to have the format <dbname>_diff_YYYYMMDDhhmm.
	For example, the backup name for the Northwind database would be 
	Northwind_diff_200312300600.BAK. 

	Parameters:
		Path			Path of database backups 
		DBName			Name of database  ( default = 'pubs' )
		HistoryValue	Number of days or weeks  ( default = 7 )
		HistoryMetric	Days or Weeks ( default = 'DAYS' )

	Examples:
		usp_DeleteDiffHistory '\\172.24.60.76\Ddrive\2ksqlprod2\Northwind', 'Northwind', 1, 'WEEKS'    
			( deletes backup files from \\172.24.60.76\Ddrive\2ksqlprod2\Northwind
			  that are older than 1 week.  )

		usp_DeleteDiffHistory 'M:\Backups\Northwind', 'Northwind'	( keep history for 7 days )

*************************************************************************************/
AS

SET NOCOUNT ON

CREATE TABLE #cmd_result ( output varchar( 8000 ) NULL )

DECLARE 
	@Command 		varchar( 1000 ),
	@DateString		varchar( 10 ),
	@BakName 		varchar( 80 ),
	@BakDate		datetime,
	@Count			int

IF @Path IS NULL
	begin
	RAISERROR( 'NO PATH SPECIFIED',  18, 1 ) 
	RETURN(-1)
	end

SET @Path = RTRIM( @Path )
IF RIGHT( @Path, 1 ) = '\'  SET @Path = LEFT( @Path, LEN( @Path ) - 1 )
	
SELECT @Count = COUNT(*) FROM master..sysdatabases WHERE name = @DBName
IF @Count = 0 
	begin
	RAISERROR( 'INVALID DATABASE NAME',  18, 1 )
	RETURN(-1)
	end

SET @HistoryMetric = UPPER( @HistoryMetric )

IF @HistoryMetric NOT IN ( 'DAYS', 'WEEKS', 'DAY', 'WEEK' )
	begin
	RAISERROR( 'INVALID HISTORY METRIC', 18, 1 )
	RETURN(-1)
	end

SET @Command = 'INSERT #cmd_result exec master..xp_procedure ''dir '
SET @Command = @Command + '"' + @Path + '\' + @DBName + '_Diff_*.BAK"'''

PRINT @Command
EXECUTE ( @Command )

DELETE FROM #cmd_result WHERE CHARINDEX( '.BAK', output ) = 0
DELETE FROM #cmd_result WHERE output is null

DECLARE 
	BAK_CURS CURSOR FOR
	SELECT 
		LEFT( output, 10 ), 
		RIGHT( output, CHARINDEX( ' ', REVERSE( output ) ) - 1 ) 
	FROM #cmd_result

--SELECT * FROM #cmd_result
SELECT @Count = COUNT(*) FROM #cmd_result

IF @Count = 0 
	PRINT 'NO BACKUPS FOUND'
-- ELSE IF @Count <= @HistoryValue
--  PRINT 'NUMBER OF BACKUPS NOT EXCEEDED'
ELSE
	begin
	SET @Count = 0
	PRINT 'SEARCHING FOR BACKUP TO DELETE'
	OPEN BAK_CURS
	FETCH FROM BAK_CURS INTO @DateString, @BakName
	WHILE @@FETCH_STATUS = 0
		begin
		--PRINT @DateString
		SET @BakDate = @DateString
		PRINT @BakDate
		--PRINT @BakName
		SET @Command = 'master..xp_procedure ''del "' + @Path + '\' + @BakName + '"'''
					
		IF @HistoryMetric IN( 'DAYS', 'DAY' ) AND 
				DATEDIFF( DAY, @BakDate, GETDATE() ) >= @HistoryValue
			begin
			--PRINT @Command
			PRINT 'DELETING ' + @BakName
            PRINT @Command
        	EXEC( @Command )
			SET @Count = @Count + 1
			end

		ELSE IF DATEDIFF( WEEK, @BakDate, GETDATE() ) >= @HistoryValue
			begin
			--PRINT @Command
			PRINT 'DELETING ' + @BakName
            PRINT @Command
            EXEC( @Command )
			SET @Count = @Count + 1
			end

		FETCH FROM BAK_CURS INTO @DateString, @BakName
		end	
	CLOSE BAK_CURS
	PRINT CAST( @Count as varchar ) + ' FILES DELETED'
	end
DEALLOCATE BAK_CURS
DROP TABLE #cmd_result
go



CREATE PROCEDURE dbo.usp_DeleteFile 	
		@FileName	varchar( 120 )
AS
SET NOCOUNT ON
DECLARE 
	@WinCmd varchar(300),
	@rtn	int,
	@jobID uniqueidentifier,
	@seq	int,
	@jobname varchar(300),
	@count int

CREATE TABLE #TEMP
(
	job_id uniqueidentifier ,
	job_name sysname ,
	run_status int ,
	run_date int ,
	run_time int ,
	run_duration int ,
	operator_emailed nvarchar(20) ,
	operator_netsent nvarchar(20), 
	operator_paged nvarchar(20) ,
	retries_attempted int ,
	server nvarchar(30) 
)

SET @rtn = 0

IF CHARINDEX( '*', @FileName ) = 0
	begin
	DECLARE  @FileExists	char(1)
	exec usp_DoesFileExist @FileName, @FileExists out
	IF @FileExists = 'N'
		begin
		PRINT 'File ' + @FileName + ' does not exist'
		RETURN -1
		end
	end


SET @Wincmd = 'del "' + @FileName + '"'
SET @rtn = 0
SET @SEQ = 0
SET @jobname = '_Temp_Delete_File'

WHILE @seq < 50
	begin
	set @jobname = @jobname + cast(@seq as varchar)
	SELECT @count = count(*) from msdb.dbo.sysjobs where name = @jobname
	print cast(@count as varchar)
	print @jobname
	if @count = 0
		begin
		EXEC msdb.dbo.sp_add_job @job_name = @jobname, @job_id = @jobID OUTPUT 
		if @jobID is not null set @seq = 99
		end
	set @seq = @seq + 1
	end

IF @jobID is null
	begin
	SET @rtn = -1
	RETURN @rtn
	end

EXEC msdb.dbo.sp_add_jobstep @job_id = @jobID, @step_name = 'Delete File', @step_id = 1, @subsystem = 'CMDEXEC', @command = @WinCmd
EXEC msdb.dbo.sp_add_jobserver @job_id = @jobID
EXEC @rtn = msdb.dbo.sp_start_job @job_id = @jobID, @output_flag = 0 
IF @rtn <> 0 RETURN @rtn

WAITFOR DELAY '000:00:05' -- Give the job a chance to complete
INSERT INTO #TEMP EXEC msdb.dbo.sp_help_jobhistory @job_id = @jobID

WHILE @@ROWCOUNT = 0
  BEGIN
  WAITFOR DELAY '000:00:05' -- Give the job a chance to complete
  INSERT INTO #TEMP EXEC msdb.dbo.sp_help_jobhistory @job_id = @jobID
  END

SELECT @rtn = max(run_status) FROM #TEMP
IF @rtn <> 1 
	SET @rtn = -1
ELSE
	EXEC msdb.dbo.sp_delete_job @job_id = @jobID

DROP TABLE #TEMP

PRINT 'File ' + @FileName + ' deleted'
RETURN @rtn
go




CREATE PROCEDURE dbo.usp_DeleteLogHistory 
		@Path			varchar( 120 ),
		@DBName			varchar( 80 ) = 'pubs',
		@HistoryValue	int = 1,
		@HistoryMetric	varchar( 5 ) = 'DAYS'

/************************************************************************************

	Deletes backup log file backups that are older than the amount 
	of history requested.  Backups are assumed to be named with the 
	same format as the names of transaction log backups generated 
	from the sqlmaint utility.  For example, the backup name for the 
	Northwind database would be Northwind_tlog_200312300600.TRN. 

	Parameters:
		Path			Path of database backups 
		DBName			Name of database  ( default = 'pubs' )
		HistoryValue	Number of hours, days or weeks  ( default = 1 )
		HistoryMetric	Hours, Days or Weeks ( default = 'DAYS' )

	Examples:
		usp_DeleteLogHistory '\\172.24.60.76\Ddrive\2ksqlprod2\Northwind', 'Northwind', 1, 'WEEKS'    
			( deletes backup files from \\172.24.60.76\Ddrive\2ksqlprod2\Northwind
			  that are older than 1 week.  )

		usp_DeleteLogHistory 'M:\Backups\Northwind', 'Northwind'	( keep history for 7 days )

*************************************************************************************/
AS
SET NOCOUNT ON
CREATE TABLE #cmd_result ( output varchar( 8000 ) )
DECLARE 
	@Command 		varchar( 1000 ),
	@DateString		varchar( 10 ),
	@BakName 		varchar( 80 ),
	@BakDate		datetime,
	@Count			int

SET @HistoryMetric = UPPER( @HistoryMetric )

IF @Path IS NULL
	begin
	RAISERROR( 'NO PATH SPECIFIED',  18, 1 ) 
	RETURN(-1)
	end

SET @Path = RTRIM( @Path )
IF RIGHT( @Path, 1 ) = '\'  SET @Path = LEFT( @Path, LEN( @Path ) - 1 )
	
SELECT @Count = COUNT(*) FROM master..sysdatabases WHERE name = @DBName
IF @Count = 0 
	begin
	RAISERROR( 'INVALID DATABASE NAME',  18, 1 )
	RETURN(-1)
	end

IF UPPER( @HistoryMetric ) NOT IN ( 'HOURS', 'DAYS', 'WEEKS' )
	begin
	RAISERROR( 'INVALID HISTORY METRIC', 18, 1 )
	RETURN(-1)
	end

SET @Command = 'INSERT #cmd_result exec master..xp_cmdshell ''dir '
SET @Command = @Command + '"' + @Path + '\' + @DBName + '_tlog_*.TRN"'''
PRINT @Command
EXECUTE ( @Command )

DELETE FROM #cmd_result WHERE CHARINDEX( '.TRN', output ) = 0
DELETE FROM #cmd_result WHERE output is null

DECLARE 
	BAK_CURS CURSOR FOR
	SELECT 
		LEFT( output, 10 ), 
		RIGHT( output, CHARINDEX( ' ', REVERSE( output ) ) - 1 ) 
	FROM #cmd_result

--SELECT * FROM #cmd_result
SELECT @Count = COUNT(*) FROM #cmd_result

IF @Count = 0 
	PRINT 'NO BACKUPS FOUND'
ELSE IF @Count <= @HistoryValue
	PRINT 'NUMBER OF BACKUPS NOT EXCEEDED'
ELSE
	begin
	SET @Count = 0
	PRINT 'SEARCHING FOR BACKUP TO DELETE'
	OPEN BAK_CURS
	FETCH FROM BAK_CURS INTO @DateString, @BakName
	WHILE @@FETCH_STATUS = 0
		begin
		--PRINT @DateString
		SET @BakDate = @DateString
		PRINT @BakDate
		--PRINT @BakName
		SET @Command = 'master..xp_cmdshell ''del "' + @Path + '\' + @BakName + '"'''
					
		IF @HistoryMetric = 'DAYS'  AND DATEDIFF( DAY,  @BakDate, GETDATE() ) >= @HistoryValue OR
		   @HistoryMetric = 'HOURS' AND DATEDIFF( HOUR, @BakDate, GETDATE() ) >= @HistoryValue OR
		   @HistoryMetric = 'WEEKS' AND DATEDIFF( WEEK, @BakDate, GETDATE() ) >= @HistoryValue
			begin
			--PRINT @Command
			PRINT 'DELETING ' + @BakName
			EXEC( @Command )
			SET @Count = @Count + 1
			end
		FETCH FROM BAK_CURS INTO @DateString, @BakName
		end	
	CLOSE BAK_CURS
	PRINT CAST( @Count as varchar ) + ' FILES DELETED'
	end
DEALLOCATE BAK_CURS
DROP TABLE #cmd_result
RETURN

GO


CREATE PROCEDURE dbo.usp_DifferentialBackup
	@DBName		varchar( 50 ),
	@Path		varchar( 120 ),
	@RetainDays int = 7
AS
/*********************************************************************

     Creates a differential backup file whose name format is 
		'<dbname>_Diff_YYYYMMDDHHMM.BAK'.

	 Parameters:
		DBName		name of database
		Path		Path of folder to store backup in
		RetainDays  How many days to store the info 
					in msdb ( default = 7 )

	Example:
usp_DifferentailBackup 'tkcsd', '\\172.24.60.76\Ddrive\backup', 4

************************************************************************/

DECLARE 
@WhichBKP 	varchar( 300 ), 
@curdate 	datetime,
@CMD		varchar( 3000 )

SET @curdate = GETDATE()

SET @WhichBKP = 
	@Path + '\' + @DBName + '_Diff_' + 
	REPLACE( REPLACE( REPLACE( CONVERT( varchar(16), @curdate, 120 ), '-', '' ), ':', '' ), ' ', '' ) +
	'.BAK'
--print @WhichBKP

SET @CMD = 'BACKUP DATABASE ' + @DBName + ' TO DISK = ''' +
	@WhichBKP + ''' WITH INIT, DIFFERENTIAL, ' +
	' NAME = N''' + @DBName + ' Differential Backup'', DESCRIPTION = ''Differential'', 
	RETAINDAYS=' + CAST( @RetainDays as varchar )
--print @CMD
EXEC( @CMD )


DECLARE @i INT

SELECT @i = position FROM msdb..backupset 
WHERE database_name= @DBName AND type!='F' AND backup_set_id=
( SELECT MAX(backup_set_id) FROM msdb..backupset WHERE database_name= @DBName )

RESTORE VERIFYONLY FROM DISK = @WhichBKP WITH FILE = @i
GO



CREATE PROCEDURE dbo.usp_DoesFileExist
		@FileName	varchar( 120 ),
		@FileExists char(1) output
AS
SET NOCOUNT ON
CREATE TABLE #results
(
	FileExists		int,
	FileIsDir		int,
	ParentDirExists int 
)
DECLARE  
	@cmd		varchar( 500 ),
	@Exists		int

SET @cmd = 'master..xp_fileexist ''' + @FileName + ''''
INSERT INTO #results  EXEC( @cmd )

SELECT @Exists = FileExists FROM #results

IF @Exists = 1 
	SET @FileExists = 'Y'
ELSE
	SET @FileExists = 'N'

DROP TABLE #results

GO


CREATE PROCEDURE dbo.usp_DumpSPIDToTable
	
	/*************************************************

			Saves current activity for all
			databases on a server, the contents of 
			the the input buffers on the clients and
			the current locks.

	***************************************************/

AS
BEGIN
SET NOCOUNT ON
CREATE TABLE #Locks_TEMP
(	
	SPID		smallint,
	DBId		smallint,
	ObjId		int,
	IndId		smallint,
	Type		nchar(4),
	Resource	nchar(16),
	Mode		nvarchar(8),
	Status		varchar(10)
)
CREATE TABLE #Input_TEMP
( 	
	EventType nvarchar(30),
	Parameters int,
	EventInfo nvarchar(255)
)
CREATE TABLE #Activity_TEMP
(	
	SPID		smallint,
	Status		char(15),
	Login		varchar(64),	
	HostName	varchar(64),
	BlkBy		char(7),		
	DBName		varchar(64),
	Command		varchar(256),
	CPUTime		char(10),
	DiskIO		char(10),	
	LastBatch	char(15),
	ProgramName	varchar(256),
	SPID2		smallint
)
TRUNCATE TABLE dbo.User_Locks_Loc
TRUNCATE TABLE dbo.User_Activity_Loc

INSERT INTO #Activity_TEMP EXEC( 'master.dbo.sp_who2' )

INSERT INTO dbo.User_Activity_Loc
( SPID, Status, Login, Host, Program, Block, BlkBy, DB, Command, CPUTime, DiskIO, LastBatch)
	SELECT 	
			SPID, 
			Status, 
			Login, 
			HostName, 
			ProgramName,
		   	CASE WHEN CHARINDEX( '.', BlkBy ) = 0 and cast( BlkBy as smallint ) <> 0 THEN 'Blocked'
				 WHEN CHARINDEX( '.', BlkBy ) = 0 and cast( BlkBy as smallint ) = 0 THEN 'Blocker'
				 ELSE ''
		   	END, 
			CASE WHEN CHARINDEX( '.', BlkBy ) = 0 and cast( BlkBy as smallint ) <> 0 THEN BlkBy
				 ELSE ''
		   	END, 
		   	DBName, 
			Command,
		   	CPUTime,
			DiskIO, 
			LastBatch
		FROM #Activity_TEMP 

DECLARE 
	@Spid  smallint
DECLARE
	SPID_CURSOR CURSOR FOR
	SELECT SPID FROM dbo.User_Activity_Loc WHERE SPID > 50

OPEN SPID_CURSOR
FETCH NEXT FROM SPID_CURSOR INTO @Spid
WHILE @@FETCH_STATUS = 0
	begin
	INSERT INTO #INPUT_TEMP EXEC( 'DBCC INPUTBUFFER ( ' + @Spid + ')' )

	UPDATE dbo.User_Activity_Loc
	SET Buffer = EventInfo
	FROM #INPUT_TEMP WHERE SPID = @Spid

	TRUNCATE TABLE #INPUT_TEMP
	FETCH NEXT FROM SPID_CURSOR INTO @Spid
	end
CLOSE SPID_CURSOR
DEALLOCATE SPID_CURSOR

INSERT INTO #Locks_TEMP( SPID, DBId, ObjId, IndId, Type, Resource, Mode, Status	)
	EXEC( 'master.dbo.sp_lock' )

DECLARE
	@Cmd		varchar(3000),
	@DB			varchar(60),
	@ObjId		int,
	@IndId		smallint,
	@DBId		smallint,
	@Type		nchar(4),
	@Resource	nchar(16),
	@Mode		nvarchar(8),
	@Status		varchar(10)

DECLARE
	DB_CURS CURSOR FOR
	SELECT SPID, ObjId, IndId, Type, Resource, Mode, Status, DBId
	FROM #Locks_TEMP
	WHERE Type <> 'DB'

OPEN DB_CURS
FETCH NEXT FROM DB_CURS INTO @Spid, @ObjId, @IndId, @Type, @Resource, @Mode, @Status, @DBId
WHILE @@FETCH_STATUS = 0
	begin
	SELECT @DB = name FROM master.dbo.sysdatabases where dbid = @DBId
	--PRINT @DB
	IF @IndId > 0
		SET @Cmd =
		'INSERT INTO dbo.User_Locks_Loc( SPID, ObjName, IndexName, Type, Resource, Mode, Status)
		SELECT cast( ''' + cast( @Spid as varchar ) + ''' as smallint ), LEFT( o.name, 60 ) , LEFT( i.name, 60 ), ''' + @Type +
		''', ''' + @Resource + ''', ''' + @Mode + ''', ''' + @Status  +
		''' FROM ' + @DB + '.dbo.sysobjects o ' +
		' JOIN ' + @DB + '.dbo.sysindexes i on i.id = o.id' +
		' WHERE o.id = ' + cast( @ObjId as varchar ) + ' and i.indid = ' + cast( @IndId as varchar )
	ELSE
		SET @Cmd =
		'INSERT INTO dbo.User_Locks_Loc( SPID, ObjName, IndexName, Type, Resource, Mode, Status)
		SELECT cast( ''' + cast( @Spid as varchar ) + ''' as smallint ), LEFT( o.name, 60 ) , '''', ''' + @Type +
		''', ''' + @Resource + ''', ''' + @Mode + ''', ''' + @Status  +
		''' FROM ' + @DB + '.dbo.sysobjects o WHERE o.id = ' + cast( @ObjId as varchar )

	--PRINT @Cmd
	EXEC( @Cmd )
	FETCH NEXT FROM DB_CURS INTO @Spid, @ObjId, @IndId, @Type, @Resource, @Mode, @Status, @DBId
	end
CLOSE DB_CURS
DEALLOCATE DB_CURS
END

GO



CREATE PROCEDURE dbo.usp_GetAgentJobs
AS
BEGIN
SET NOCOUNT ON

IF OBJECT_ID( 'dbo.Agent_Jobs' ) IS NULL
	CREATE TABLE dbo.Agent_Jobs
(	job_id                UNIQUEIDENTIFIER NOT NULL,
    last_run_date         INT              NOT NULL,
    last_run_time         INT              NOT NULL,
    next_run_date         INT              NOT NULL,
    next_run_time         INT              NOT NULL,
  	next_run_schedule_id  INT              NOT NULL,
	requested_to_run      INT              NOT NULL, -- BOOL
	request_source        INT              NOT NULL,
	request_source_id     sysname          NULL,
	running               INT              NOT NULL, -- BOOL
	current_step          INT              NOT NULL,
	current_retry_attempt INT              NOT NULL,
    job_state             INT              NOT NULL
)
ELSE
	TRUNCATE TABLE dbo.Agent_Jobs

INSERT INTO dbo.Agent_Jobs EXEC master.dbo.xp_sqlagent_enum_jobs 1,'sa'
/*
SELECT name as JobName
FROM dbo.Agent_Jobs r JOIN msdb.dbo.sysjobs j ON r.job_id = j.job_id
WHERE running = 1
*/
END

GO



CREATE PROCEDURE dbo.usp_GetDBAttributes
AS
BEGIN
SET NOCOUNT ON
TRUNCATE TABLE dbo.DBAttributes

INSERT INTO dbo.DBAttributes( DBName, Model, Status )
	SELECT 
		name, 
		CAST( DATABASEPROPERTYEX( name, 'RECOVERY' ) as varchar ), 
		CAST( DATABASEPROPERTYEX(name, 'Status') as varchar )
	FROM master.dbo.sysdatabases

END
GO



CREATE PROCEDURE dbo.usp_GetFileDate
	@FileName		varchar(120),
	@LastWriteDate	char(8)  OUT,
	@LastWriteTime	char(8)  OUT
/*******************************************************************************
	
	Input:	
		@FileName		Full path file name
	Output: 
		@LastWriteDate		Date in YYYYMMDD format.
		@LastWriteTime  	Time in hh:mm:ss (24 hr) format.

	If error or file not found, -1 return code.

***********************************************************************************/

AS
SET NOCOUNT ON
DECLARE @cmd	varchar(1000)

CREATE TABLE #TMP
( 	AltName		varchar(120),
  	Size			int,
  	CreateDate		char(8),
	CreateTime		varchar(6),
	LastWrittenDate		char(8),
	LastWrittenTime 	varchar(6),
	LastAccessedDate	char(8),
	LastAccessedTime	varchar(6),
	Attributes		int
)
SET @cmd = 'master..xp_getfiledetails ''' + @FileName + ''''

INSERT INTO #tmp EXEC(@cmd)
IF @@ROWCOUNT = 0 RETURN(-1)

SELECT 
	@LastWriteDate = LastWrittenDate,
	@LastWriteTime = 
		CASE 	WHEN LEN(LastWrittenTime ) = 6 
			THEN LEFT( LastWrittenTime, 2 ) + ':' + 
				SUBSTRING( LastWrittenTime, 3, 2 ) + ':' +
				RIGHT( LastWrittenTime, 2 )
			ELSE '0' + LEFT( LastWrittenTime, 1 ) + ':' + 
				SUBSTRING( LastWrittenTime, 2, 2 ) + ':' +
				RIGHT( LastWrittenTime, 2 )
		END				  
FROM #TMP
PRINT 'Last Written Date = ' + 
		SUBSTRING( @LastWriteDate, 5,2 ) + '/' +
		RIGHT(  @LastWriteDate, 2 ) + '/' +
		LEFT(  @LastWriteDate, 4 ) 
PRINT 'Last Written Time = ' + @LastWriteTime
RETURN(0)

GO



CREATE PROCEDURE dbo.usp_GetRecordCounts
		@DBName		varchar(50) 
AS
SET NOCOUNT ON
--DROP TABLE #TEMP
CREATE TABLE #TEMP( RECCOUNT INT )

DECLARE
	@Table		varchar( 60 ),
	@Owner		varchar( 50 ),
	@Cmd		varchar(2000),
	@Count 		int,
	@SampleDate	datetime

SET @SampleDate	= GETDATE()
SET @Cmd =
'INSERT INTO DBA.dbo.Table_Counts( DBName, TableName, Owner, SampleDate )
SELECT ''' + @DBName + ''', TABLE_NAME, TABLE_SCHEMA, ''' 
+ CONVERT( varchar(25), @SampleDate, 121 ) +
''' FROM [' + @DBName + '].INFORMATION_SCHEMA.TABLES 
WHERE 
		TABLE_TYPE = ''BASE TABLE'' and
		TABLE_NAME not like ''sys%'' and 
		TABLE_NAME <> ''dtproperties'''
--PRINT @Cmd
EXEC( @Cmd )

DECLARE
	Table_curs CURSOR FOR
	SELECT DISTINCT TableName, Owner FROM DBA.dbo.Table_Counts
	WHERE DBName = @DBName AND SampleDate = @SampleDate

OPEN Table_curs
FETCH NEXT FROM Table_curs INTO @Table, @Owner
WHILE @@FETCH_STATUS = 0
	begin
	TRUNCATE TABLE #TEMP
	SET @Cmd = 'SELECT COUNT(*) FROM [' + @DBName + '].' + @Owner + '.[' + @Table + ']'
	--PRINT @cmd
	INSERT INTO #TEMP( RECCOUNT )
		exec( @cmd )
	SELECT @Count = MAX( RECCOUNT ) FROM #TEMP
	--PRINT @Count

	UPDATE dbo.Table_Counts
	SET RecordCount = @Count
	WHERE 
		DBName    = @DBName and
	  	TableName = @Table  and
		Owner	  = @Owner  and
	  	RecordCount IS NULL
	FETCH NEXT FROM Table_curs INTO @Table, @Owner
	end
CLOSE Table_curs
DEALLOCATE Table_curs
DROP TABLE #TEMP
SELECT TableName, RecordCount, Owner, SampleDate
FROM dbo.Table_Counts
WHERE DBName = @DBName and SampleDate = @SampleDate
ORDER BY TableName, Owner

GO



CREATE PROCEDURE dbo.usp_Get_DbStats3
/***************************************************************

		This procedure records the disk space used by
		databases.

*****************************************************************/
AS
BEGIN
SET NOCOUNT ON

DROP TABLE dbo.tmplg
DROP TABLE dbo.tmp_sfs

--IF OBJECT_ID( 'dbo.tmplg' ) IS NULL
	CREATE TABLE dbo.tmplg
	( 
		DBName       	varchar( 64 ),
		LogSize		real,
		LogSpaceUsed	real,
		Status		int
	)

--IF OBJECT_ID( 'dbo.tmp_sfs' ) IS NULL
	CREATE TABLE dbo.tmp_sfs
	(   
		DBName			nvarchar( 128 ),
		FileId	    		int,
		FileGroup		int, 
		TotalExtents		bigint, 
		UsedExtents		bigint, 
		Name			varchar( 1024 ), 
		FileName		varchar( 1024 )
	)

--TRUNCATE TABLE DBA.dbo.tmplg
--TRUNCATE TABLE DBA.dbo.tmp_sfs

INSERT INTO DBA.dbo.tmplg EXECUTE ( 'DBCC SQLPERF( logspace )' )

DECLARE	@CMD varchar( 2000 )
SET @CMD = 'USE [?] ' 
SET @CMD = @CMD + 
	'INSERT INTO DBA.dbo.tmp_sfs( FileId,FileGroup,TotalExtents,UsedExtents,Name,FileName	 ) '
SET @CMD = @CMD + ' EXEC( ''DBCC SHOWFILESTATS'' ) ' 
SET @CMD = @CMD + ' UPDATE DBA.dbo.tmp_sfs SET DBName = ''?'' WHERE DBName IS NULL '
EXEC sp_MSForEachDB @Command1=@CMD

INSERT INTO DBA.dbo.DBSTATS 
( 	DBName, Data_Size, Data_Used, 	Log_Size, Log_Used, State_Date, PercentLog )
	SELECT 	
			s.DBName,
			SUM( TotalExtents ) * 64 / 1024, 
			SUM( UsedExtents ) * 64 / 1024, 
			CAST( MAX( l.LogSize ) AS varchar ) ,
			CAST( ( MAX(l.LogSize) * MAX(l.LogSpaceUsed) ) / 100.0 AS varchar ),
			GETDATE(),
			MAX(LogSpaceUsed)
	FROM DBA.dbo.tmp_sfs s 
		JOIN DBA.dbo.tmplg l ON s.DBName = l.DBName
	WHERE s.DBName NOT IN( 'model', 'pubs', 'Northwind' )
	GROUP BY s.DBName
END
GO





CREATE PROCEDURE dbo.usp_Get_WaitStats
AS
/*******************************************************

		This stored procedure creates a WaitStats 
		report that lists wait types by percentage.
		You can run the procedure while 
		usp_Track_WaitStats is executing.

*********************************************************/

SET NOCOUNT ON
DECLARE
	@Now		datetime,
	@TotalWait	numeric(20,1),
	@EndTime	datetime,
	@BeginTime	datetime,
	@Hr			int,
	@Min		int,
	@Sec		int

SELECT 	
	@Now 		= MAX( Now ), 
	@BeginTime 	= MIN( Now ), 
	@EndTime 	= MAX( Now )
FROM WaitStats
WHERE [Wait Type] = 'Total'

-- Subtract WaitFor, Sleep, and Resource_Queue from Total.
SELECT @TotalWait = SUM([Wait Time]) + 1 FROM WaitStats
WHERE [Wait Type] NOT IN 
	( 'WAITFOR', 'SLEEP', 'RESOURCE_QUEUE', 'Total', '***total***' ) AND
	Now = @Now

-- Insert adjusted totals and rank by percentage in descending order.
DELETE FROM WaitStats WHERE [Wait Type] = '***total***' AND Now = @Now
INSERT INTO WaitStats
	SELECT '***total***', 0, @TotalWait, @TotalWait, @Now

SELECT
	[Wait Type], 
	[Wait Time], 
	Percentage = CAST( 100 * [Wait Time] / @TotalWait as numeric(20,1) )
FROM WaitStats
WHERE [Wait Type] NOT IN( 'WAITFOR', 'SLEEP', 'RESOURCE_QUEUE', 'Total' )
	AND Now = @Now
ORDER BY Percentage desc

GO


CREATE PROCEDURE dbo.usp_KillUsers 
				@DBName		varchar(50),
				@SingleUser char(1) = NULL

/*************************************************

	Kills all the current connections.  
	
	If the SingleUser parameter is set to 'Y', 
	the database will be left in single-user mode.

***************************************************/
AS
SET NOCOUNT ON
DECLARE
	@Cmd		varchar(300)
	
IF @DBName = ''
	begin
	RAISERROR( 'Database name required', 0, 1  )
	RETURN -1
	end
ELSE IF @DBName NOT IN ( SELECT name FROM master..sysdatabases )
	begin
	RAISERROR( 'Invalid database name', 0, 1  )
	RETURN -1
	end

PRINT 'SETTING DATABASE TO SINGLE_USER'
SET @Cmd = 'ALTER DATABASE ' + @DBName 
			+ ' SET SINGLE_USER WITH ROLLBACK AFTER 60 SECONDS'
EXEC(@Cmd)

IF ISNULL( @SingleUser, '' ) = 'Y'
	PRINT 'DATABASE ' + @DBName + ' SET TO SINGLE_USER MODE'
ELSE
	begin
	PRINT 'SETTING DATABASE TO MULTI_USER'
	SET @Cmd = 'ALTER DATABSE ' + @DBName + ' SET MULTI_USER'
	EXEC(@Cmd )
	end

RETURN
GO



CREATE PROCEDURE dbo.usp_MoveFile 	
		@FileName		varchar( 120 ),
		@Destination 	varchar( 120 )
AS
SET NOCOUNT ON
DECLARE 
	@Wincmd varchar( 500 ),
	@rtn int,
	@jobID uniqueidentifier,
	@seq	int,
	@jobname varchar(300),
	@count int

CREATE TABLE #TEMP
(
	job_id uniqueidentifier ,
	job_name sysname ,
	run_status int ,
	run_date int ,
	run_time int ,
	run_duration int ,
	operator_emailed nvarchar(20) ,
	operator_netsent nvarchar(20), 
	operator_paged nvarchar(20) ,
	retries_attempted int ,
	server nvarchar(30) 
)

SET @rtn = 0

IF charindex( '*', @FileName ) = 0
	begin
	DECLARE  @FileExists	char(1)
	exec usp_DoesFileExist @FileName, @FileExists out
	IF @FileExists = 'N'
		begin
		PRINT 'File ' + @FileName + ' does not exist'
		RETURN -1
		end
	end

IF LEFT( @Destination, 1 ) <> '\' 
	SET @Wincmd = 'move "' + @FileName + '" "' + RTRIM(@Destination) + '\"'
ELSE
	SET @Wincmd = 'move "' + @FileName + '" "' + RTRIM(@Destination) + '"'

SET @SEQ = 0
SET @jobname = '_Temp_Move_File'

WHILE @seq < 50
	begin
	set @jobname = @jobname + cast(@seq as varchar)
	SELECT @count = count(*) from msdb.dbo.sysjobs where name = @jobname
	print cast(@count as varchar)
	print @jobname
	if @count = 0
		begin
		EXEC msdb.dbo.sp_add_job @job_name = @jobname, @job_id = @jobID OUTPUT 
		if @jobID is not null set @seq = 99
		end
	set @seq = @seq + 1
	end

IF @jobID is null
	begin
	SET @rtn = -1
	RETURN @rtn
	end

EXEC msdb.dbo.sp_add_jobstep @job_id = @jobID, @step_name = 'Move File', @step_id = 1, @subsystem = 'CMDEXEC', @command = @WinCmd
EXEC msdb.dbo.sp_add_jobserver @job_id = @jobID
EXEC @rtn = msdb.dbo.sp_start_job @job_id = @jobID, @output_flag = 0 
IF @rtn <> 0 RETURN @rtn

WAITFOR DELAY '000:00:05' -- Give the job a chance to complete
INSERT INTO #TEMP EXEC msdb.dbo.sp_help_jobhistory @job_id = @jobID

WHILE @@ROWCOUNT = 0
  BEGIN
  WAITFOR DELAY '000:00:05' -- Give the job a chance to complete
  INSERT INTO #TEMP EXEC msdb.dbo.sp_help_jobhistory @job_id = @jobID
  END

SELECT @rtn = max(run_status) FROM #TEMP
IF @rtn <> 1 
	SET @rtn = -1
ELSE
	EXEC msdb.dbo.sp_delete_job @job_id = @jobID

DROP TABLE #TEMP

PRINT 'File ' + @FileName + ' moved'
RETURN @rtn
go


CREATE PROCEDURE dbo.usp_RebuildShowcontigIndexes
			@Database	varchar(50) = NULL

/**********************************************

	Rebuilds all the indexes for tables in the 
	dba.dbo.SHOWCONTIG table.  The data was 
	put in the table by running usp_Showcontig.

	If a database name is passed, only indexes
	for that database are rebuilt.

	Any table having at least one index in 
	the showcontig table will have ALL of 
	its indexes rebuilt.

************************************************/
AS
SET NOCOUNT ON
DECLARE
	@TableName		varchar( 50 ),
	@DBName			varchar( 50 ),
	@Owner			sysname,
	@TableCount		int,
	@JobStart		datetime,
	@JobEnd			datetime,
	@command1		varchar(2000)

IF @Database IS NULL
	PRINT 'DBREINDEX FOR ALL DATABASES'
ELSE
	PRINT 'DBREINDEX FOR ' + @Database 

SET @JobStart 		= GETDATE()
PRINT 'JOB START TIME:  ' + CAST( @JobStart as varchar )

IF @Database IS NULL
	DECLARE
		Indexes CURSOR FORWARD_ONLY READ_ONLY FOR
		SELECT DISTINCT RTRIM( DBName ), RTRIM( TableName ), RTRIM( Owner )
		FROM DBA.dbo.ShowContig
		ORDER BY RTRIM( DBName ), RTRIM( TableName )
ELSE
	DECLARE
		Indexes CURSOR FORWARD_ONLY READ_ONLY FOR
		SELECT DISTINCT RTRIM( DBName ), RTRIM( TableName ), RTRIM( Owner )
		FROM DBA.dbo.ShowContig
		WHERE DBName = @Database
		ORDER BY RTRIM( TableName )

SET @TableCount = 0
OPEN Indexes
FETCH NEXT FROM Indexes INTO @DBName, @TableName, @Owner
WHILE @@FETCH_STATUS = 0
	begin
	SET @TableCount = @TableCount + 1
	SET @command1 = 
		'DBCC DBREINDEX ( ''[' + @DBName + '].' + @owner + '.' + 
		@TableName + ''' ) WITH NO_INFOMSGS '
	PRINT @command1
	EXEC( @command1 )
	SET @command1 = 'use ' + @DBName + ' exec sp_recompile ' + @TableName
	PRINT @command1
	EXEC( @command1 )
	FETCH NEXT FROM Indexes INTO @DBName, @TableName, @Owner
	end
CLOSE Indexes
DEALLOCATE Indexes
PRINT CAST( @TableCount as varchar ) + ' TABLES REINDEXED'
PRINT ' '
PRINT '***********************************************************************'
PRINT ' '
SET @JobEnd = GETDATE()
PRINT 'JOB END TIME:  ' + CAST( @JobEnd as varchar )
IF DATEDIFF( mi, @JobStart, @JobEnd ) < 60
	PRINT 'JOB DURATION:  ' + 
		CAST( DATEDIFF( mi, @JobStart, @JobEnd ) as varchar ) + ' minutes'
ELSE
	PRINT 'JOB DURATION:  ' + 
	CAST( ( DATEDIFF( mi, @JobStart, @JobEnd )/60 ) as varchar ) + ' hrs ' +
	CAST( ( DATEDIFF( mi, @JobStart, @JobEnd )%60 ) as varchar ) + ' minutes'

GO



CREATE PROCEDURE dbo.usp_RecoveryModel
		 @DB	varchar(60)
		
AS
BEGIN

SELECT cast( DATABASEPROPERTYEX( name, 'recovery') as varchar )
FROM master.dbo.sysdatabases WHERE name = @DB

END

GO




CREATE PROCEDURE dbo.usp_RenameFileDayOfWeek
	@FilePath	varchar( 120 )
/******************************************************

	Renames a file to include the day of the 
	week as part of the name.  

	If a file with the new name already exists, 
	it gets overwritten.

	Example:  When 'c:\temp\test.log' is passed in
	and the current day is Sunday,
	it's name is changed to test_Sunday.log.

*******************************************************/
AS
SET NOCOUNT ON
DECLARE 
	@WinCmd varchar(300),
	@rtn	int,
	@jobID uniqueidentifier,
	@seq	int,
	@jobname varchar(300),
	@count int

CREATE TABLE #TEMP
(
	job_id uniqueidentifier ,
	job_name sysname ,
	run_status int ,
	run_date int ,
	run_time int ,
	run_duration int ,
	operator_emailed nvarchar(20) ,
	operator_netsent nvarchar(20), 
	operator_paged nvarchar(20) ,
	retries_attempted int ,
	server nvarchar(30) 
)

SET @rtn = 0

DECLARE
	@DayOfWeek		varchar( 9 ),
	@FileName		varchar( 120 ),
	@Path			varchar( 120 ),
	@NewFileName	varchar( 120 ),
	@NewFilePath	varchar( 120 )

SET @Path = 
	LEFT( @FilePath, LEN( @FilePath ) - CHARINDEX( '\', REVERSE( @FilePath ) ) + 1 )
SET @FileName   = 
	RIGHT( @FilePath, CHARINDEX( '\', REVERSE( @FilePath ) ) - 1 )
SET @DayOfWeek  = 
	CASE DATEPART( dw, GETDATE() )
		WHEN 1 THEN 'Sunday'
		WHEN 2 THEN 'Monday'
		WHEN 3 THEN 'Tuesday'
		WHEN 4 THEN 'Wednesday'
		WHEN 5 THEN 'Thursday'
		WHEN 6 THEN 'Friday'
		ELSE	'Saturday'
	END
SET @NewFileName = 	
	LEFT( @FileName, CHARINDEX( '.', @FileName ) - 1 ) +
	'_' + @DayOfWeek + RIGHT( @FileName, 4 )
SET @NewFilePath = @Path + @NewFileName
SET @WinCmd   = 'ren "' + @FilePath + '" ' + @NewFileName + ''
EXEC dba.dbo.usp_DeleteFile @NewFilePath

SET @SEQ = 0
SET @jobname = '_Temp_RenameFileDayOfWeek'

WHILE @seq < 50
	begin
	set @jobname = @jobname + cast(@seq as varchar)
	SELECT @count = count(*) from msdb.dbo.sysjobs where name = @jobname
	print cast(@count as varchar)
	print @jobname
	if @count = 0
		begin
		EXEC msdb.dbo.sp_add_job @job_name = @jobname, @job_id = @jobID OUTPUT 
		if @jobID is not null set @seq = 99
		end
	set @seq = @seq + 1
	end

IF @jobID is null
	begin
	SET @rtn = -1
	RETURN @rtn
	end


EXEC msdb.dbo.sp_add_jobstep @job_id = @jobID, @step_name = 'Rename File Day Of Week', @step_id = 1, @subsystem = 'CMDEXEC', @command = @WinCmd
EXEC msdb.dbo.sp_add_jobserver @job_id = @jobID
EXEC @rtn = msdb.dbo.sp_start_job @job_id = @jobID, @output_flag = 0 
IF @rtn <> 0 RETURN @rtn

WAITFOR DELAY '000:00:05' -- Give the job a chance to complete
INSERT INTO #TEMP EXEC msdb.dbo.sp_help_jobhistory @job_id = @jobID

WHILE @@ROWCOUNT = 0
  BEGIN
  WAITFOR DELAY '000:00:05' -- Give the job a chance to complete
  INSERT INTO #TEMP EXEC msdb.dbo.sp_help_jobhistory @job_id = @jobID
  END

SELECT @rtn = max(run_status) FROM #TEMP
IF @rtn <> 1 
	SET @rtn = -1
ELSE
	EXEC msdb.dbo.sp_delete_job @job_id = @jobID

DROP TABLE #TEMP
RETURN @rtn
go



CREATE PROCEDURE dbo.usp_RenameFileDayOfWeekHour
	@FilePath	varchar( 120 )

/******************************************************

	Renames a file to include the day of the week 
	and the hour of the day as part of the name.

	If the new file name already exists, it gets
	overwritten.

	Example :  
		If the current day is Sunday and the 
		current hour is 11AM, then
		usp_RenameFileDayOfWeek 'c:\temp\test.log'
		renames the file to �test_Sunday_11AM.log�

*******************************************************/
AS
SET NOCOUNT ON
DECLARE 
	@WinCmd varchar(300),
	@rtn	int,
	@jobID uniqueidentifier,
	@seq	int,
	@jobname varchar(300),
	@count int

CREATE TABLE #TEMP
(
	job_id uniqueidentifier ,
	job_name sysname ,
	run_status int ,
	run_date int ,
	run_time int ,
	run_duration int ,
	operator_emailed nvarchar(20) ,
	operator_netsent nvarchar(20), 
	operator_paged nvarchar(20) ,
	retries_attempted int ,
	server nvarchar(30) 
)

SET @rtn = 0

DECLARE
	@DayOfWeek		varchar( 9 ),
	@Datetime		datetime,
	@Hour			int,
	@Path			varchar( 120 ),
	@NewFilePath	varchar( 120 ),
	@FileName		varchar( 120 ),
	@NewName		varchar( 120 )

SET @Path = 
	LEFT( @FilePath, LEN( @FilePath ) - CHARINDEX( '\', REVERSE( @FilePath ) ) + 1 )
SET @FileName = 
	RIGHT( @FilePath, CHARINDEX( '\', REVERSE( @FilePath ) ) - 1 )
SET @Datetime 	= GETDATE()
SET @Hour	  	= DATEPART( hh, @Datetime )
SET @DayOfWeek  = 
	CASE DATEPART( dw, @Datetime )
		WHEN 1 THEN 'Sunday'
		WHEN 2 THEN 'Monday'
		WHEN 3 THEN 'Tuesday'
		WHEN 4 THEN 'Wednesday'
		WHEN 5 THEN 'Thursday'
		WHEN 6 THEN 'Friday'
		ELSE		'Saturday'
		END
SET @NewName = 
	LEFT( @FileName, CHARINDEX( '.', @FileName ) - 1 ) +
	'_' + @DayOfWeek + '_' + 
	CAST( CASE 
			WHEN @Hour > 12 THEN @Hour - 12
			ELSE @Hour
		  END AS varchar(2) ) +
		  CASE 
			WHEN @Hour > 12 THEN 'PM'
			ELSE 'AM'
		  END +
		  RIGHT( @FileName, 4 )

SET @NewFilePath = 	@Path + @NewName
exec dbo.usp_DeleteFile @NewFilePath

SET @WinCmd  = 	'ren "' + @FilePath + '" ' + @NewName + ''
SET @SEQ = 0
SET @jobname = '_Temp_RenameFileDayOfWeekHour'

WHILE @seq < 50
	begin
	set @jobname = @jobname + cast(@seq as varchar)
	SELECT @count = count(*) from msdb.dbo.sysjobs where name = @jobname
	print cast(@count as varchar)
	print @jobname
	if @count = 0
		begin
		EXEC msdb.dbo.sp_add_job @job_name = @jobname, @job_id = @jobID OUTPUT 
		if @jobID is not null set @seq = 99
		end
	set @seq = @seq + 1
	end

IF @jobID is null
	begin
	SET @rtn = -1
	RETURN @rtn
	end


EXEC msdb.dbo.sp_add_jobstep @job_id = @jobID, @step_name = 'Rename File Day Of Week Hour', @step_id = 1, @subsystem = 'CMDEXEC', @command = @WinCmd
EXEC msdb.dbo.sp_add_jobserver @job_id = @jobID
EXEC @rtn = msdb.dbo.sp_start_job @job_id = @jobID, @output_flag = 0 
IF @rtn <> 0 RETURN @rtn

WAITFOR DELAY '000:00:05' -- Give the job a chance to complete
INSERT INTO #TEMP EXEC msdb.dbo.sp_help_jobhistory @job_id = @jobID

WHILE @@ROWCOUNT = 0
  BEGIN
  WAITFOR DELAY '000:00:05' -- Give the job a chance to complete
  INSERT INTO #TEMP EXEC msdb.dbo.sp_help_jobhistory @job_id = @jobID
  END

SELECT @rtn = max(run_status) FROM #TEMP
IF @rtn <> 1 
	SET @rtn = -1
ELSE
	EXEC msdb.dbo.sp_delete_job @job_id = @jobID

DROP TABLE #TEMP
RETURN @rtn
GO

GO


CREATE PROCEDURE dbo.usp_RenameFileWithDateTime
	@FilePath 	varchar( 120 )
/******************************************************

	Renames a file to include the date and time as
	part of the name.

	Example:  
		DBA..usp_RenameFileWithDateTime �c:\temp\test.log�
		renames the file to the following format:  
			 �test_yyyy-mm-dd hh:mi:ss.log�  (24h)

*******************************************************/
AS
SET NOCOUNT ON
DECLARE 
	@WinCmd varchar(300),
	@rtn	int,
	@jobID uniqueidentifier,
	@seq	int,
	@jobname varchar(300),
	@count int

CREATE TABLE #TEMP
(
	job_id uniqueidentifier ,
	job_name sysname ,
	run_status int ,
	run_date int ,
	run_time int ,
	run_duration int ,
	operator_emailed nvarchar(20) ,
	operator_netsent nvarchar(20), 
	operator_paged nvarchar(20) ,
	retries_attempted int ,
	server nvarchar(30) 
)

SET @rtn = 0

DECLARE
	@DateString		varchar( 50 ),
	@FileName		varchar( 120 )

SET @DateString = 
	REPLACE( REPLACE( CONVERT( varchar, GETDATE(), 120 ), ' ', '_' ), ':', '.' ) 			  
SET @FileName	= 
	RIGHT( @FilePath, CHARINDEX( '\', REVERSE( @FilePath ) ) - 1 )
SET @WinCmd  = 
	'ren "' + @FilePath + '" ' +
	LEFT( @FileName, CHARINDEX( '.', @FileName ) - 1 ) +
	'_' + @DateString + RIGHT( @FileName, 4 ) + ''

SET @SEQ = 0
SET @jobname = '_Temp_RenameFileWithDateTime'

WHILE @seq < 50
	begin
	set @jobname = @jobname + cast(@seq as varchar)
	SELECT @count = count(*) from msdb.dbo.sysjobs where name = @jobname
	print cast(@count as varchar)
	print @jobname
	if @count = 0
		begin
		EXEC msdb.dbo.sp_add_job @job_name = @jobname, @job_id = @jobID OUTPUT 
		if @jobID is not null set @seq = 99
		end
	set @seq = @seq + 1
	end

IF @jobID is null
	begin
	SET @rtn = -1
	RETURN @rtn
	end


EXEC msdb.dbo.sp_add_jobstep @job_id = @jobID, @step_name = 'Rename File With Date Time', @step_id = 1, @subsystem = 'CMDEXEC', @command = @WinCmd
EXEC msdb.dbo.sp_add_jobserver @job_id = @jobID
EXEC @rtn = msdb.dbo.sp_start_job @job_id = @jobID, @output_flag = 0 
IF @rtn <> 0 RETURN @rtn

WAITFOR DELAY '000:00:05' -- Give the job a chance to complete
INSERT INTO #TEMP EXEC msdb.dbo.sp_help_jobhistory @job_id = @jobID

WHILE @@ROWCOUNT = 0
  BEGIN
  WAITFOR DELAY '000:00:05' -- Give the job a chance to complete
  INSERT INTO #TEMP EXEC msdb.dbo.sp_help_jobhistory @job_id = @jobID
  END

SELECT @rtn = max(run_status) FROM #TEMP
IF @rtn <> 1 
	SET @rtn = -1
ELSE
	EXEC msdb.dbo.sp_delete_job @job_id = @jobID

DROP TABLE #TEMP
RETURN @rtn
go



CREATE PROCEDURE dbo.usp_RenameFile_MMDDYY
	@FilePath 	varchar( 120 )
AS
SET NOCOUNT ON

DECLARE 
	@rtn	int,
	@jobID uniqueidentifier,
	@seq	int,
	@jobname varchar(300),
	@count int

CREATE TABLE #TEMP
(
	job_id uniqueidentifier ,
	job_name sysname ,
	run_status int ,
	run_date int ,
	run_time int ,
	run_duration int ,
	operator_emailed nvarchar(20) ,
	operator_netsent nvarchar(20), 
	operator_paged nvarchar(20) ,
	retries_attempted int ,
	server nvarchar(30) 
)

SET @rtn = 0

DECLARE
	@WinCmd			varchar( 300 ),
	@DateString		varchar( 50 ),
	@FileName		varchar( 120 ),
	@Extension		int

SET @DateString = 
	REPLACE( CONVERT( varchar, GETDATE(), 1 ), '/', '' )
				  
SET @FileName	= 
	RIGHT( @FilePath, CHARINDEX( '\', REVERSE( @FilePath ) ) - 1 )

SET @Extension = LEN(@FileName) - CHARINDEX( '.', @FileName ) + 1

SET @WinCmd  = 'ren "' + @FilePath + '" "' +
	LEFT( @FileName, CHARINDEX( '.', @FileName ) - 1 ) +
	'_' + @DateString + RIGHT( @FileName, @Extension ) + '"'

SET @SEQ = 0
SET @jobname = '_Temp_RenameFile_MMDDYY'

WHILE @seq < 50
	begin
	set @jobname = @jobname + cast(@seq as varchar)
	SELECT @count = count(*) from msdb.dbo.sysjobs where name = @jobname
	print cast(@count as varchar)
	print @jobname
	if @count = 0
		begin
		EXEC msdb.dbo.sp_add_job @job_name = @jobname, @job_id = @jobID OUTPUT 
		if @jobID is not null set @seq = 99
		end
	set @seq = @seq + 1
	end

IF @jobID is null
	begin
	SET @rtn = -1
	RETURN @rtn
	end	


EXEC msdb.dbo.sp_add_jobstep @job_id = @jobID, @step_name = 'Rename File MMDDYY', @step_id = 1, @subsystem = 'CMDEXEC', @command = @WinCmd
EXEC msdb.dbo.sp_add_jobserver @job_id = @jobID
EXEC @rtn = msdb.dbo.sp_start_job @job_id = @jobID, @output_flag = 0 
IF @rtn <> 0 RETURN @rtn

WAITFOR DELAY '000:00:05' -- Give the job a chance to complete
INSERT INTO #TEMP EXEC msdb.dbo.sp_help_jobhistory @job_id = @jobID

WHILE @@ROWCOUNT = 0
  BEGIN
  WAITFOR DELAY '000:00:05' -- Give the job a chance to complete
  INSERT INTO #TEMP EXEC msdb.dbo.sp_help_jobhistory @job_id = @jobID
  END

SELECT @rtn = max(run_status) FROM #TEMP
IF @rtn <> 1 
	SET @rtn = -1
ELSE
	EXEC msdb.dbo.sp_delete_job @job_id = @jobID

DROP TABLE #TEMP
RETURN @rtn
go



CREATE PROCEDURE dbo.usp_RenameFile_YYYYMMDD
	@FilePath 	varchar( 120 )

/******************************************************
	Renames a file to include the date and time as
	part of the name.
	Example:  
		DBA..usp_RenameFile_YYYYMMDD `c:\temp\test.log'
		renames the file to the following format:  
		`test_yyyymmdd.log'  
*******************************************************/

AS
SET NOCOUNT ON

DECLARE 
	@WinCmd varchar(300),
	@rtn	int,
	@jobID uniqueidentifier,
	@seq	int,
	@jobname varchar(300),
	@count int

CREATE TABLE #TEMP
(
	job_id uniqueidentifier ,
	job_name sysname ,
	run_status int ,
	run_date int ,
	run_time int ,
	run_duration int ,
	operator_emailed nvarchar(20) ,
	operator_netsent nvarchar(20), 
	operator_paged nvarchar(20) ,
	retries_attempted int ,
	server nvarchar(30) 
)

SET @rtn = 0


DECLARE
	@DateString		varchar( 8 ),
	@FileName		varchar( 120 )

SET @DateString = CONVERT( varchar, GETDATE(), 112 )
				  
SET @FileName	= RIGHT( @FilePath, CHARINDEX( '\', REVERSE( @FilePath ) ) - 1 )
SET @WinCmd  = 'ren "' + @FilePath + '" ' +
		LEFT( @FileName, CHARINDEX( '.', @FileName ) - 1 ) +
		'_' + @DateString + RIGHT( @FileName, 4 ) + ''

SET @SEQ = 0
SET @jobname = '_Temp_RenameFile_YYYYMMDD'

WHILE @seq < 50
	begin
	set @jobname = @jobname + cast(@seq as varchar)
	SELECT @count = count(*) from msdb.dbo.sysjobs where name = @jobname
	print cast(@count as varchar)
	print @jobname
	if @count = 0
		begin
		EXEC msdb.dbo.sp_add_job @job_name = @jobname, @job_id = @jobID OUTPUT 
		if @jobID is not null set @seq = 99
		end
	set @seq = @seq + 1
	end

IF @jobID is null
	begin
	SET @rtn = -1
	RETURN @rtn
	end


EXEC msdb.dbo.sp_add_jobstep @job_id = @jobID, @step_name = 'Rename File_YYYYMMDD', @step_id = 1, @subsystem = 'CMDEXEC', @command = @WinCmd
EXEC msdb.dbo.sp_add_jobserver @job_id = @jobID
EXEC @rtn = msdb.dbo.sp_start_job @job_id = @jobID, @output_flag = 0 
IF @rtn <> 0 RETURN @rtn

WAITFOR DELAY '000:00:05' -- Give the job a chance to complete
INSERT INTO #TEMP EXEC msdb.dbo.sp_help_jobhistory @job_id = @jobID

WHILE @@ROWCOUNT = 0
  BEGIN
  WAITFOR DELAY '000:00:05' -- Give the job a chance to complete
  INSERT INTO #TEMP EXEC msdb.dbo.sp_help_jobhistory @job_id = @jobID
  END

SELECT @rtn = max(run_status) FROM #TEMP
IF @rtn <> 1 
	SET @rtn = -1
ELSE
	EXEC msdb.dbo.sp_delete_job @job_id = @jobID

DROP TABLE #TEMP
RETURN @rtn
GO



CREATE PROCEDURE dbo.usp_RenameFile_YYYYxMMxDD
	@FilePath 	varchar( 120 ),
	@Separator	char(1)= ''
/******************************************************

	Renames a file to include the current date 
	( with or without separators ) as part of the name.
	Default is without separators.

	Example:  
		DBA..usp_RenameFile_YYYYxMMxDD �c:\temp\test.log�, '-'
		renames the file to the following format:  
				'test_yyyy-mm-dd.log�  
*******************************************************/
AS
SET NOCOUNT ON
DECLARE 
	@rtn	int,
	@jobID uniqueidentifier,
	@seq	int,
	@jobname varchar(300),
	@count int

CREATE TABLE #TEMP
(
	job_id uniqueidentifier ,
	job_name sysname ,
	run_status int ,
	run_date int ,
	run_time int ,
	run_duration int ,
	operator_emailed nvarchar(20) ,
	operator_netsent nvarchar(20), 
	operator_paged nvarchar(20) ,
	retries_attempted int ,
	server nvarchar(30) 
)

SET @rtn = 0

DECLARE
	@WinCmd			varchar( 300 ),
	@DateString		varchar( 50 ),
	@FileName		varchar( 120 ),
	@Extension		int

SET @DateString = 
	REPLACE( CONVERT( varchar, GETDATE(), 102 ), '.', @Separator )
				  
SET @FileName	= 
	RIGHT( @FilePath, CHARINDEX( '\', REVERSE( @FilePath ) ) - 1 )

SET @Extension = LEN(@FileName) - CHARINDEX( '.', @FileName ) + 1

SET @WinCmd  = 
	'ren "' + @FilePath + '" "' +
	LEFT( @FileName, CHARINDEX( '.', @FileName ) - 1 ) +
	'_' + @DateString + RIGHT( @FileName, @Extension ) + '"'

SET @SEQ = 0
SET @jobname = '_Temp_RenameFile_YYYYxMMxDD'

WHILE @seq < 50
	begin
	set @jobname = @jobname + cast(@seq as varchar)
	SELECT @count = count(*) from msdb.dbo.sysjobs where name = @jobname
	print cast(@count as varchar)
	print @jobname
	if @count = 0
		begin
		EXEC msdb.dbo.sp_add_job @job_name = @jobname, @job_id = @jobID OUTPUT 
		if @jobID is not null set @seq = 99
		end
	set @seq = @seq + 1
	end

IF @jobID is null
	begin
	SET @rtn = -1
	RETURN @rtn
	end



EXEC msdb.dbo.sp_add_jobstep @job_id = @jobID, @step_name = 'Rename File YYYYxMMxDD', @step_id = 1, @subsystem = 'CMDEXEC', @command = @WinCmd
EXEC msdb.dbo.sp_add_jobserver @job_id = @jobID
EXEC @rtn = msdb.dbo.sp_start_job @job_id = @jobID, @output_flag = 0 
IF @rtn <> 0 RETURN @rtn

WAITFOR DELAY '000:00:05' -- Give the job a chance to complete
INSERT INTO #TEMP EXEC msdb.dbo.sp_help_jobhistory @job_id = @jobID

WHILE @@ROWCOUNT = 0
  BEGIN
  WAITFOR DELAY '000:00:05' -- Give the job a chance to complete
  INSERT INTO #TEMP EXEC msdb.dbo.sp_help_jobhistory @job_id = @jobID
  END

SELECT @rtn = max(run_status) FROM #TEMP
IF @rtn <> 1 
	SET @rtn = -1
ELSE
	EXEC msdb.dbo.sp_delete_job @job_id = @jobID


DROP TABLE #TEMP
RETURN @rtn
go



CREATE PROCEDURE dbo.usp_RenameLogDayOfWeek
	@FilePath	varchar( 120 )

	/******************************************************

		Renames a file to include the day of the 
		week as part of the name.  

		If a file with the new name already exists, 
		it gets overwritten.

		Example:  When 'c:\temp\test.log' is passed in
		and the current day is Sunday,
		it's name is changed to test_Sunday.log.

	*******************************************************/
AS
SET NOCOUNT ON
DECLARE 
	@WinCmd varchar(300),
	@rtn	int,
	@jobID uniqueidentifier,
	@seq	int,
	@jobname varchar(300),
	@count int

CREATE TABLE #TEMP
(
	job_id uniqueidentifier ,
	job_name sysname ,
	run_status int ,
	run_date int ,
	run_time int ,
	run_duration int ,
	operator_emailed nvarchar(20) ,
	operator_netsent nvarchar(20), 
	operator_paged nvarchar(20) ,
	retries_attempted int ,
	server nvarchar(30) 
)

SET @rtn = 0

DECLARE
	@DayOfWeek		varchar( 9 ),
	@FileName		varchar( 120 ),
	@Path			varchar( 120 ),
	@NewFileName	varchar( 120 ),
	@NewFilePath	varchar( 120 )

SET @Path = LEFT( @FilePath, LEN( @FilePath ) - CHARINDEX( '\', REVERSE( @FilePath ) ) + 1 )
SET @FileName   = RIGHT( @FilePath, CHARINDEX( '\', REVERSE( @FilePath ) ) - 1 )
SET @DayOfWeek  = CASE DATEPART( dw, GETDATE() )
						WHEN 1 THEN 'Sunday'
						WHEN 2 THEN 'Monday'
						WHEN 3 THEN 'Tuesday'
						WHEN 4 THEN 'Wednesday'
						WHEN 5 THEN 'Thursday'
						WHEN 6 THEN 'Friday'
						ELSE		'Saturday'
				  END
SET @NewFileName = 	LEFT( @FileName, CHARINDEX( '.', @FileName ) - 1 ) +
					'_' + @DayOfWeek + RIGHT( @FileName, 4 )
SET @NewFilePath = @Path + @NewFileName
SET @WinCmd   = 'ren "' + @FilePath + '" ' + @NewFileName + ''

EXEC dba.dbo.usp_DeleteFile @NewFilePath

SET @SEQ = 0
SET @jobname = '_Temp_RenameLogDayOfWeek'

WHILE @seq < 50
	begin
	set @jobname = @jobname + cast(@seq as varchar)
	SELECT @count = count(*) from msdb.dbo.sysjobs where name = @jobname
	print cast(@count as varchar)
	print @jobname
	if @count = 0
		begin
		EXEC msdb.dbo.sp_add_job @job_name = @jobname, @job_id = @jobID OUTPUT 
		if @jobID is not null set @seq = 99
		end
	set @seq = @seq + 1
	end

IF @jobID is null
	begin
	SET @rtn = -1
	RETURN @rtn
	end


EXEC msdb.dbo.sp_add_jobstep @job_id = @jobID, @step_name = 'Rename Log Day Of Week', @step_id = 1, @subsystem = 'CMDEXEC', @command = @WinCmd
EXEC msdb.dbo.sp_add_jobserver @job_id = @jobID
EXEC @rtn = msdb.dbo.sp_start_job @job_id = @jobID, @output_flag = 0 
IF @rtn <> 0 RETURN @rtn

WAITFOR DELAY '000:00:05' -- Give the job a chance to complete
INSERT INTO #TEMP EXEC msdb.dbo.sp_help_jobhistory @job_id = @jobID

WHILE @@ROWCOUNT = 0
  BEGIN
  WAITFOR DELAY '000:00:05' -- Give the job a chance to complete
  INSERT INTO #TEMP EXEC msdb.dbo.sp_help_jobhistory @job_id = @jobID
  END

SELECT @rtn = max(run_status) FROM #TEMP
IF @rtn <> 1 
	SET @rtn = -1
ELSE
	EXEC msdb.dbo.sp_delete_job @job_id = @jobID

DROP TABLE #TEMP
RETURN @rtn
go


CREATE PROCEDURE dbo.usp_RenameLogDayOfWeekHour
	@FilePath	varchar( 120 )

	/******************************************************

		Renames a file to include the day of the week 
		and the hour of the day as part of the name.

		If the new file name already exists, it gets
		overwritten.

		Example :  
			If the current day is Sunday and the 
			current hour is 11AM, then
			sp_ihRenameLogDayOfWeek 'c:\temp\test.log'
			renames the file to �test_Sunday_11AM.log�

	*******************************************************/
AS
SET NOCOUNT ON
DECLARE 
	@WinCmd varchar(300),
	@rtn	int,
	@jobID uniqueidentifier,
	@seq	int,
	@jobname varchar(300),
	@count int

CREATE TABLE #TEMP
(
	job_id uniqueidentifier ,
	job_name sysname ,
	run_status int ,
	run_date int ,
	run_time int ,
	run_duration int ,
	operator_emailed nvarchar(20) ,
	operator_netsent nvarchar(20), 
	operator_paged nvarchar(20) ,
	retries_attempted int ,
	server nvarchar(30) 
)

SET @rtn = 0

DECLARE
	@DayOfWeek		varchar( 9 ),
	@Datetime		datetime,
	@Hour			int,
	@Path			varchar( 120 ),
	@NewFilePath	varchar( 120 ),
	@FileName		varchar( 120 ),
	@NewName		varchar( 120 )

SET @Path = LEFT( @FilePath, LEN( @FilePath ) - CHARINDEX( '\', REVERSE( @FilePath ) ) + 1 )
SET @FileName = RIGHT( @FilePath, CHARINDEX( '\', REVERSE( @FilePath ) ) - 1 )

SET @Datetime 	= GETDATE()
SET @Hour	  	= DATEPART( hh, @Datetime )
SET @DayOfWeek  = CASE DATEPART( dw, @Datetime )
						WHEN 1 THEN 'Sunday'
						WHEN 2 THEN 'Monday'
						WHEN 3 THEN 'Tuesday'
						WHEN 4 THEN 'Wednesday'
						WHEN 5 THEN 'Thursday'
						WHEN 6 THEN 'Friday'
						ELSE		'Saturday'
				  END
SET @NewName	= LEFT( @FileName, CHARINDEX( '.', @FileName ) - 1 ) +
				  '_' + @DayOfWeek + '_' + 
				  CAST( CASE 
							WHEN @Hour > 12 THEN @Hour - 12
							ELSE @Hour
				  		END AS varchar(2) ) +
				  CASE 
						WHEN @Hour > 12 THEN 'PM'
					    ELSE 'AM'
				  END +
				  RIGHT( @FileName, 4 )

SET @NewFilePath = 	@Path + @NewName
exec dbo.usp_DeleteFile @NewFilePath

SET @WinCmd  = 	'ren "' + @FilePath + '" ' + @NewName + ''

SET @SEQ = 0
SET @jobname = '_Temp_RenameLogDayOfWeekHour'

WHILE @seq < 50
	begin
	set @jobname = @jobname + cast(@seq as varchar)
	SELECT @count = count(*) from msdb.dbo.sysjobs where name = @jobname
	print cast(@count as varchar)
	print @jobname
	if @count = 0
		begin
		EXEC msdb.dbo.sp_add_job @job_name = @jobname, @job_id = @jobID OUTPUT 
		if @jobID is not null set @seq = 99
		end
	set @seq = @seq + 1
	end

IF @jobID is null
	begin
	SET @rtn = -1
	RETURN @rtn
	end


EXEC msdb.dbo.sp_add_jobstep @job_id = @jobID, @step_name = 'Rename Log Day Of Week Hour', @step_id = 1, @subsystem = 'CMDEXEC', @command = @WinCmd
EXEC msdb.dbo.sp_add_jobserver @job_id = @jobID
EXEC @rtn = msdb.dbo.sp_start_job @job_id = @jobID, @output_flag = 0 
IF @rtn <> 0 RETURN @rtn

WAITFOR DELAY '000:00:05' -- Give the job a chance to complete
INSERT INTO #TEMP EXEC msdb.dbo.sp_help_jobhistory @job_id = @jobID

WHILE @@ROWCOUNT = 0
  BEGIN
  WAITFOR DELAY '000:00:05' -- Give the job a chance to complete
  INSERT INTO #TEMP EXEC msdb.dbo.sp_help_jobhistory @job_id = @jobID
  END

SELECT @rtn = max(run_status) FROM #TEMP
IF @rtn <> 1 
	SET @rtn = -1
ELSE
	EXEC msdb.dbo.sp_delete_job @job_id = @jobID


DROP TABLE #TEMP
RETURN @rtn
GO


CREATE PROCEDURE dbo.usp_RenameLogWithDateTime
	@FilePath 	varchar( 120 )

	/******************************************************

		Renames a file to include the date and time as
		part of the name.

		Example:  
			DBA..usp_RenameLogWithDateTime �c:\temp\test.log�
		     renames the file to the following format:  
			 �test_yyyy-mm-dd hh:mi:ss.log�  (24h)


	*******************************************************/
AS
SET NOCOUNT ON
DECLARE 
	@WinCmd varchar(1000),
	@rtn	int,
	@jobID uniqueidentifier,
	@seq	int,
	@jobname varchar(300),
	@count int

CREATE TABLE #TEMP
(
	job_id uniqueidentifier ,
	job_name sysname ,
	run_status int ,
	run_date int ,
	run_time int ,
	run_duration int ,
	operator_emailed nvarchar(20) ,
	operator_netsent nvarchar(20), 
	operator_paged nvarchar(20) ,
	retries_attempted int ,
	server nvarchar(30) 
)

SET @rtn = 0

DECLARE
	@DateString		varchar( 50 ),
	@FileName		varchar( 120 )

SET @DateString = 
	REPLACE( REPLACE( CONVERT( varchar, GETDATE(), 120 ), ' ', '_' ), ':', '.' ) 
				  
SET @FileName	= RIGHT( @FilePath, CHARINDEX( '\', REVERSE( @FilePath ) ) - 1 )
SET @WinCmd  = 'ren "' + @FilePath + '" ' +
		LEFT( @FileName, CHARINDEX( '.', @FileName ) - 1 ) +
		 '_' + @DateString + RIGHT( @FileName, 4 ) + ''


SET @SEQ = 0
SET @jobname = '_Temp_RenameLogWithDateTime'

WHILE @seq < 50
	begin
	set @jobname = @jobname + cast(@seq as varchar)
	SELECT @count = count(*) from msdb.dbo.sysjobs where name = @jobname
	print cast(@count as varchar)
	print @jobname
	if @count = 0
		begin
		EXEC msdb.dbo.sp_add_job @job_name = @jobname, @job_id = @jobID OUTPUT 
		if @jobID is not null set @seq = 99
		end
	set @seq = @seq + 1
	end

IF @jobID is null
	begin
	SET @rtn = -1
	RETURN @rtn
	end

EXEC msdb.dbo.sp_add_jobstep @job_id = @jobID, @step_name = 'Rename Log With Date Time', @step_id = 1, @subsystem = 'CMDEXEC', @command = @WinCmd
EXEC msdb.dbo.sp_add_jobserver @job_id = @jobID
EXEC @rtn = msdb.dbo.sp_start_job @job_id = @jobID, @output_flag = 0 
IF @rtn <> 0 RETURN @rtn

WAITFOR DELAY '000:00:05' -- Give the job a chance to complete
INSERT INTO #TEMP EXEC msdb.dbo.sp_help_jobhistory @job_id = @jobID

WHILE @@ROWCOUNT = 0
  BEGIN
  WAITFOR DELAY '000:00:05' -- Give the job a chance to complete
  INSERT INTO #TEMP EXEC msdb.dbo.sp_help_jobhistory @job_id = @jobID
  END

SELECT @rtn = max(run_status) FROM #TEMP
IF @rtn <> 1 
	SET @rtn = -1
ELSE
	EXEC msdb.dbo.sp_delete_job @job_id = @jobID


DROP TABLE #TEMP
RETURN @rtn
go




CREATE PROCEDURE dbo.usp_RoleMembers 
			@DBName		varchar(50),
			@ReportPath	varchar( 100 ) = NULL
AS
SET NOCOUNT ON
IF @DBName IS NULL
	BEGIN
	PRINT 'Database name not provided'
	RETURN( -1 )
	END

DECLARE @SQLSTMT	varchar(500 )

SET @SQLSTMT = 
   'SELECT u.name as Role, x.name as Member 
	FROM [' + @DBName + '].dbo.sysusers u 
		JOIN [' + @DBName + '].dbo.sysmembers m ON u.uid = m.groupuid 
		JOIN [' + @DBName + '].dbo.sysusers x   ON x.uid = m.memberuid
	WHERE u.issqlrole = 1 and u.name <> ''public''
	ORDER BY u.name, x.name'

EXEC( @SQLSTMT )
IF @ReportPath IS NOT NULL
	BEGIN
	SET @SQLSTMT = 
	'sp_MakeWebTask 
		@DBName = ''' + @DBName + ''', 
		@OutputFile = ''' + @ReportPath + '\Roles.htm'' ,
		@WebpageTitle = ''Role members for ' + @DBName + ''',
		@ResultsTitle = ''Role members for ' + @DBName + ''',
		@LastUpdated = 1,
		@TabBorder = 1,
		@ColHeaders = 1,
		@Query = ''SELECT u.name as Role, x.name as Member 
		FROM [' + @DBName + '].dbo.sysusers u 
			JOIN [' + @DBName + '].dbo.sysmembers m ON u.uid = m.groupuid 
			JOIN [' + @DBName + '].dbo.sysusers x   ON x.uid = m.memberuid
		WHERE u.issqlrole = 1 and u.uid <> 0 
		ORDER BY u.name, x.name'''
	--print @sqlstmt
	EXEC( @SQLSTMT )
	END

GO


CREATE PROCEDURE dbo.usp_Showcontig
			@MaxFrag	decimal = 10.0

/***************************************************************************

		Runs DBCC SHOWCONTIG on all the tables on the server and 
		inserts a record in the DBA.dbo.Showcontig table for indexes 
		that should be rebuilt.  The indexes can be rebuilt by executing
		DBA.dbo.usp_RebuildShowcontigIndexes.  A report of those indexes
 		is also returned.  Every time this procedure is run, the
		Showcontig table is first truncated.
				
		This procedure will fail on a SQL Server 7.0 server 
		because the ALL_INDEXES is not an option for SHOWCONTIG on 
		that version of SQL Server.

		Parameters:
			@MaxFrag  		
				The maximum percent fragmentation that
				must exist in order to be considered for 
				defragmentation.  The default value for @MaxFrag
				is 10.0%, but it can be modified to any value.

*************************************************************************/
AS
SET NOCOUNT ON

CREATE TABLE #FragList
(	
	DBNAME			varchar(50),
	TableName		char( 255 ),
	TableId			int,
	IndexName		char( 255 ),
	IndexId			int,
	Lvl				int,
	CountPages		int,
	CountRows		int,
	MinRecSize		int,
	MaxRecSize		int,
	AvgRecSize		int,
	ForRecCount		int,
	Extents			int,
	ExtentSwitches	int,
	AvgFreeBytes	int,
	AvgPageDensity	decimal,
	ScanDensity		decimal,
	BestCount		int,
	ActualCount		int,
	LogicalFrag		decimal,
	ExtentFrag		decimal,
	Owner			sysname NULL,
	CollectionDate	datetime
)

TRUNCATE TABLE DBA.dbo.SHOWCONTIG

DECLARE	
	@TableName		varchar( 50 ),
	@IndexName		varchar( 50 ),
	@DBName			varchar( 50 ),
	@IndexId		int,
	@Owner			sysname,
	@LogicalFrag	decimal,
	@ExtentFrag		decimal,
	@ScanDensity	decimal,
	@AvgPageDensity decimal,
	@TableCount		int,
	@JobStart		datetime,
	@JobEnd			datetime

SET @JobStart 		= GETDATE()

PRINT 'SHOWCONTIG JOB START TIME:  ' + CAST( @JobStart as varchar )

DECLARE 
	@RC 			int,
	@command1 		nvarchar(2000),
	@replacechar 	nchar(1),
	@command2 		nvarchar(2000),
	@command3 		nvarchar(2000),
	@whereand 		nvarchar(2000),
	@precommand 	nvarchar(2000),
	@postcommand 	nvarchar(2000)

-- Set parameter values
SET @replacechar = '?'
SET @command1 = 
	'PRINT '' '' PRINT ''?'' USE ? INSERT INTO #FragList
	( TableName, TableId, IndexName, IndexId, Lvl, CountPages,
  		CountRows, MinRecSize, MaxRecSize, AvgRecSize, ForRecCount,
  		Extents, ExtentSwitches, AvgFreeBytes, AvgPageDensity,
 	 	ScanDensity, BestCount, ActualCount, LogicalFrag, ExtentFrag	
	) EXEC( ''DBCC SHOWCONTIG WITH TABLERESULTS, ALL_INDEXES'' )' 
SET @command2 = 
	' USE ? UPDATE #FragList SET DBNAME = ''?'' WHERE DBNAME IS NULL ' +
	' DELETE FROM #FragList FROM #Fraglist f JOIN sysobjects s ON f.TableId = s.id ' +
	' WHERE xtype = ''S'' and DBName = ''?''' +
	' UPDATE #FragList SET Owner = USER_NAME( s.uid ) ' + 
	' FROM #FragList f JOIN sysobjects s ON f.TableId = s.id ' +
	' WHERE xtype = ''U'' and DBName = ''?''' 		
EXEC @RC = master.dbo.[sp_MSforeachdb] @command1, @replacechar, @command2, @command3, @precommand, @postcommand

-- I don't care about these databases
DELETE FROM #FragList WHERE DBNAME IN 
( 'master', 'msdb', 'tempdb','model', 'distribution', 'pubs', 'Northwind' )

-- IndexId: 1 	= Clustered index,
--			>1 	= Heap,
--			255 = Entry for tables that have text or image data
DELETE FROM #FragList WHERE IndexId < 1 OR IndexId = 255
DELETE FROM #FragList WHERE IndexName LIKE '_WA%'
DELETE FROM #FragList WHERE TableName = 'dtproperties'
UPDATE #Fraglist SET CollectionDate = GETDATE()

INSERT INTO DBA.dbo.SHOWCONTIG
(	
	Add_Date, DBName,TableName,TableId,IndexName,IndexId,Lvl,CountPages,
	CountRows,MinRecSize,MaxRecSize,AvgRecSize,ForRecCount,Extents,
	ExtentSwitches,AvgFreeBytes,AvgPageDensity,ScanDensity,BestCount,
	ActualCount,LogicalFrag,ExtentFrag,Owner	
)
	SELECT 
		CollectionDate, DBName,TableName,TableId,IndexName,IndexId,Lvl,CountPages,
		CountRows,MinRecSize,MaxRecSize,AvgRecSize,ForRecCount,Extents,
		ExtentSwitches,AvgFreeBytes,AvgPageDensity,ScanDensity,BestCount,
		ActualCount,LogicalFrag,ExtentFrag,Owner
	FROM #FragList
	WHERE
		-- who cares if there is only 1 page of index
		CountPages > 1 and
			-- Extent frag always matters
		( 	ExtentFrag > @MaxFrag OR
			-- Could the fill factor be wrong?
			ISNULL( ScanDensity, 0 ) < 90 OR
			-- Logical frag only pertains to clustered indexes
		 	( IndexId = 1 and LogicalFrag > @MaxFrag ) )
			
DROP TABLE #FragList

PRINT ' '
PRINT 'FRAGMENTED INDEXES'

DECLARE
	Indexes CURSOR FORWARD_ONLY READ_ONLY FOR
	SELECT 
		RTRIM( DBName ), RTRIM( TableName ), Owner, 
		RTRIM( IndexName ), IndexId, LogicalFrag, ExtentFrag, 
		ScanDensity, AvgPageDensity
	FROM DBA.dbo.ShowContig
	ORDER BY RTRIM( DBName ), RTRIM( TableName ), IndexName, Owner


OPEN Indexes
FETCH NEXT FROM Indexes 
	INTO @DBName, @TableName, @Owner, @IndexName, @IndexId,
		 @LogicalFrag, @ExtentFrag, @ScanDensity, @AvgPageDensity
WHILE @@FETCH_STATUS = 0
	begin
	PRINT ' '
	-- Logical fragmentation is only relevant to the clustered index 
	IF @IndexId = 1 
		begin
		PRINT @DBName + ', ' + @TableName + ', ' + @IndexName + ', ' +
		  	CAST( @IndexId as varchar ) + ' - Logical fragmentation ' + 
		  	RTRIM( CONVERT( varchar( 15 ), @LogicalFrag )) + '%'
		end

	PRINT @DBName + ', ' + @TableName + ', ' + @IndexName + ', ' +
		  CAST( @IndexId as varchar ) + ' - Extent fragmentation ' + 
		  RTRIM( CONVERT( varchar( 15 ), @ExtentFrag )) + '%'

	PRINT @DBName + ', ' + @TableName + ', ' + @IndexName + ', ' +
		  CAST( @IndexId as varchar ) + ' - Scan density ' + 
		  RTRIM( CONVERT( varchar( 15 ), @ScanDensity )) + '%'

	PRINT @DBName + ', ' + @TableName + ', ' + @IndexName + ', ' +
		  CAST( @IndexId as varchar ) + ' - Avg Page density ' + 
		  RTRIM( CONVERT( varchar( 15 ), @AvgPageDensity )) + '%'

	FETCH NEXT FROM Indexes 
		INTO @DBName, @TableName, @Owner, @IndexName, @IndexId,
			 @LogicalFrag, @ExtentFrag, @ScanDensity, @AvgPageDensity
	end
CLOSE Indexes
DEALLOCATE Indexes
PRINT ' '
PRINT '***********************************************************************'
PRINT ' '
SET @JobEnd = GETDATE()
PRINT 'JOB END TIME:  ' + CAST( @JobEnd as varchar )
IF DATEDIFF( mi, @JobStart, @JobEnd ) < 60
	PRINT 'JOB DURATION:  ' + 
		CAST( DATEDIFF( mi, @JobStart, @JobEnd ) as varchar ) + ' minutes'
ELSE
	PRINT 'JOB DURATION:  ' + 
	CAST( ( DATEDIFF( mi, @JobStart, @JobEnd )/60 ) as varchar ) + ' hrs ' +
	CAST( ( DATEDIFF( mi, @JobStart, @JobEnd )%60 ) as varchar ) + ' minutes'

GO


CREATE PROCEDURE dbo.usp_Track_WaitStats
	( @Num_Samples 	int = 10,
	  @DelayNum	 	int = 1,
	  @DelayType	nvarchar(10) = 'minutes'
	)
AS
/*********************************************************

	@Num_Samples:   The number of times to capture
					waitstats; default 10 times.
	@DelayNum:		The delay interval; can be in
					minutes or seconds; default is 
					1 minute.
	@DelayType:		The time specified. Values are 
					"minutes" or "seconds."

************************************************************/

SET NOCOUNT ON
IF OBJECT_ID( 'dbo.WaitStats' ) IS NULL
	CREATE TABLE dbo.WaitStats
	(	[Wait Type]			varchar(80),
		Requests			numeric(20,1),
		[Wait Time]			numeric(20,1),
		[Signal Wait Time]	numeric(20,1),
		Now					datetime default GETDATE()
	)
ELSE
	TRUNCATE TABLE dbo.WaitStats

DBCC SQLPERF( WAITSTATS, CLEAR )  -- clear out waitstats

DECLARE
	@i			int,
	@Delay		varchar(8),
	@Dt			varchar(3),
	@Now		datetime,	
	@TotalWait	numeric(20,1),
	@EndTime	datetime,
	@BeginTime	datetime,
	@Hr			int,
	@Min		int,
	@Sec		int

SET @i = 1
SET	@Dt	=	
	CASE LOWER( @DelayType )
		WHEN 'minutes' 	THEN 'm'
		WHEN 'minute'	THEN 'm'
		WHEN 'min'		THEN 'm'
		WHEN 'mm'		THEN 'm'
		WHEN 'mi'		THEN 'm'
		WHEN 'm'		THEN 'm'
		WHEN 'seconds'	THEN 's'
		WHEN 'second'	THEN 's'
		WHEN 'sec'		THEN 's'
		WHEN 'ss'		THEN 's'
		WHEN 's'		THEN 's'
		ELSE @DelayType
	END
IF @Dt NOT IN ( 's', 'm' )
	begin
	PRINT 'Please supply delay type, e.g. seconds or minutes'
	RETURN
	end

IF @Dt = 's'
	begin
	SET @Sec	= @DelayNum % 60
	SET @Min	= CAST(( @DelayNum / 60 ) as int )
	SET @Hr		= CAST(( @Min / 60 ) as int )
	SET @Min	= @Min % 60
	end

IF @Dt = 'm'
	begin
	SET @Sec	= 0
	SET @Min	= @DelayNum % 60
	SET @Hr		= CAST(( @DelayNum / 60 ) as int )
	end

SET @Delay =	RIGHT( '0' + CONVERT( varchar(2), @Hr ), 2 ) +
			 	':' +
				RIGHT( '0' + CONVERT( varchar(2), @Min ), 2 ) +
				':' +
			 	RIGHT( '0' + CONVERT( varchar(2), @Sec ), 2 )

IF @Hr > 23 OR @Min > 59 OR @Sec > 59
	begin
	SELECT 'hh:mm:ss delay time cannot > 23:59:59'
	SELECT 'Delay interval and type:  ' + 
			CONVERT( varchar(10), @DelayNum ) +
			',' + @DelayType + ' converts to ' + @Delay
	RETURN
	end

WHILE ( @i <= @Num_Samples )
	begin
	INSERT INTO WaitStats
		( [Wait Type], Requests, [Wait Time], [Signal Wait Time] )
	EXEC ( 'DBCC SQLPERF( WAITSTATS )' )
	SET @i = @i + 1
	WAITFOR DELAY @Delay
	end
--  Create report
EXEC dbo.usp_Get_WaitStats

GO



CREATE PROCEDURE dbo.usp_UserList2 
AS

SET NOCOUNT ON


CREATE TABLE #DB_Users
(	
	ServerName		varchar( 30 ),
	UserName		varchar( 30 ),
	Pwd				char( 2 ), 
	DBName			varchar( 30 ),
	RoleName		varchar( 30 ),
	IsNTGroup		char( 2 ),
	IsAliased		char( 2 ),
	SysAdmin		char( 2 ),
	ServerAdmin 	char( 2 ),
	SetupAdmin		char( 2 ),
	ProcessAdmin	char( 2 ),
	SecurityAdmin	char( 2 ),
	DiskAdmin		char( 2 ),
	DBCreator		char( 2 )    
)

DECLARE 
		@DBName		varchar( 30 ),
		@SQLString1 varchar( 200 ),
		@SQLString 	varchar( 1000 )

DECLARE DBcurs CURSOR FOR
	SELECT name 
	FROM master.dbo.sysdatabases
	WHERE name not in ( 'pubs', 'Northwind', 'Tempdb', 'Model' )

SET @SQLString1 = 'INSERT INTO #DB_Users( ServerName, RoleName, DBName, UserName, IsAliased, IsNTGroup ) '

OPEN DBcurs
FETCH NEXT FROM DBcurs INTO @DBName
WHILE @@FETCH_STATUS = 0
	begin
	-- Note:  The 2KPERDAT server has a case-sensitive database ( SC_Prod ), so the table
	--        and column names in the following query must be all lowercase!!!
	SET @SQLString = 'SELECT @@SERVERNAME, ISNULL( r.name, '' '' ),  ''' + @DBName + ''', '
	SET @SQLString = @SQLString + 'CASE WHEN u.isntname = 1 THEN l.name ELSE u.name END, '
	SET @SQLString = @SQLString + 'CASE WHEN u.isaliased = 1 THEN '' Y'' ELSE '' '' END, '
	SET @SQLString = @SQLString + 'CASE WHEN u.isntgroup = 1 THEN '' Y'' ELSE '' '' END '
	SET @SQLString = @SQLString + 'FROM master.dbo.syslogins l JOIN '
	SET @SQLString = @SQLString +  @DBName + '.dbo.sysusers u ON u.sid = l.sid LEFT JOIN '
	SET @SQLString = @SQLString +  @DBName + '.dbo.sysmembers m ON u.uid = m.memberuid LEFT JOIN '
	SET @SQLString = @SQLString +  @DBName + '.dbo.sysusers r ON  r.uid = m.groupuid '
	SET @SQLString = @SQLString + 'WHERE u.isapprole = 0 and u.issqlrole = 0 and u.name NOT IN '
	SET @SQLString = @SQLString + '( ''dbo'', ''guest'', ''INFORMATION_SCHEMA'', ''SYSTEM_FUNCTION_SCHEMA'' ) '
	SET @SQLString = @SQLString + 'ORDER BY   u.name, r.name'
	
	--print @SQLString
	INSERT INTO #DB_Users
		exec( @SQLString1 + @SQLString )
	
	FETCH NEXT FROM DBcurs INTO @DBName
	end
CLOSE DBcurs
DEALLOCATE DBcurs


INSERT INTO #DB_Users( ServerName, RoleName, DBName, UserName, IsAliased, IsNTGroup )
SELECT  @@SERVERNAME, ' ', ' ', name, ' ', CASE WHEN IsNtGroup = 1 THEN ' Y' ELSE ' ' END
FROM master.dbo.syslogins
WHERE name not in ( SELECT UserName FROM #DB_Users )

UPDATE #DB_Users
SET	Pwd 			= 	CASE WHEN password is NULL and ( s.IsNtUser = 0 and s.IsNtGroup = 0 )  THEN ' N' ELSE ' ' END,
	SysAdmin 		= 	CASE WHEN s.Sysadmin = 1 		THEN ' Y' ELSE ' ' END,
	ServerAdmin 	= 	CASE WHEN s.ServerAdmin = 1 	THEN ' Y' ELSE ' ' END,
	SetupAdmin 		= 	CASE WHEN s.Setupadmin = 1		THEN ' Y' ELSE ' ' END,
	ProcessAdmin 	= 	CASE WHEN s.Processadmin = 1	THEN ' Y' ELSE ' ' END,
	SecurityAdmin 	= 	CASE WHEN s.Securityadmin = 1 	THEN ' Y' ELSE ' ' END,
	DiskAdmin 		= 	CASE WHEN s.Diskadmin = 1 		THEN ' Y' ELSE ' ' END,
	DBCreator 		= 	CASE WHEN s.DBCreator = 1		THEN ' Y' ELSE ' ' END
FROM master.dbo.syslogins s
WHERE name = UserName

SELECT * FROM #DB_Users
DROP TABLE #DB_Users


GO



CREATE PROCEDURE [dbo].[usp_IndexDefrag2005]
	@DBName		sysname
AS
BEGIN
SET NOCOUNT ON
DECLARE 
	@Exec			char(1),
	@ShowData		char(1),
	@DBID			int,
	@cmd			varchar(3000),
	@ErrorMessage   NVARCHAR(4000),
    @ErrorSeverity  INT,
    @ErrorState     INT

SET @Exec = 'Y'
SET @Showdata = 'N'

SET @DBID = DB_ID(@DBName)

CREATE TABLE #TEMP
(	
	SchemaName		sysname,
	TblName			sysname,
	IndexName		sysname,
	IType			int, 
	TypeDesc		nvarchar(60),
	data_space_id	int,
	TblId			int,
	index_id		int,
	partition_number int,
	alloc_unit_type_desc nvarchar(60),
	index_depth		tinyint,
	index_level		tinyint,
	avg_fragmentation_in_percent float,
	avg_page_space_used_in_percent float
)

SET @cmd = 
'SELECT
	s.name as SchemaName,
	o.name as TblName,
	i.name as IndexName,
	i.type,
	i.type_desc,
	i.data_space_id,
	p.object_id as TblId,
	p.index_id,
	p.partition_number,
	p.alloc_unit_type_desc,
	p.index_depth,
	p.index_level,
	p.avg_fragmentation_in_percent,
	p.avg_page_space_used_in_percent
FROM 
	sys.dm_db_index_physical_stats (' + cast(@DBID as varchar) + ' , null, null, null, null) p
	join ' + @DBName + '.sys.objects o on o.object_id = p.object_id
	join ' + @DBName + '.sys.indexes i on i.object_id = p.object_id and i.index_id = p.index_id
	join ' + @DBNAme + '.sys.schemas s on s.schema_id = o.schema_id
WHERE 
	p.index_id > 0 and p.index_id < 255 and i.Is_Disabled = 0'

INSERT INTO #TEMP exec(@cmd)

IF @ShowData = 'Y' SELECT * FROM #TEMP ORDER BY TblName, index_id, index_level


DECLARE
	@Schema	sysname,
	@TbName sysname,
	@IdxName sysname,
	@MaxFrag int,
	@TblId	int,
	@IndexId int

-- Do the clustered indexes first.  
-- If they are fragmented, all the indexes for the table will be rebuilt.

DECLARE 
	CURS CURSOR FAST_FORWARD FOR
	SELECT
		SchemaName,
		TblName,
		TblId,
		max(avg_fragmentation_in_percent) as MaxFrag
	FROM #TEMP
	WHERE 
		Index_Id = 1 and avg_fragmentation_in_percent > 10
	GROUP BY SchemaName, TblName, TblId
	ORDER BY SchemaName, TblName


OPEN CURS
FETCH NEXT FROM CURS INTO @Schema, @TbName, @TblId, @MaxFrag
WHILE @@FETCH_STATUS = 0
	BEGIN
	SET @cmd = 'ALTER INDEX ALL ON ' + @DBName + '.' + @Schema + '.' + @TbName + 
				' REBUILD WITH (SORT_IN_TEMPDB = ON, ONLINE = OFF);'
	PRINT @cmd + ' -- ' + cast(@MaxFrag as varchar)

	IF @Exec = 'Y'
		begin
		BEGIN TRY
			EXEC( @cmd )
		END TRY
		BEGIN CATCH
			SELECT
				@ErrorMessage = ERROR_MESSAGE(),
				@ErrorSeverity = ERROR_SEVERITY(),
				@ErrorState = ERROR_STATE()
			RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState)
		END CATCH

		SET @cmd = 'use ' + @DBName + '; exec sp_recompile ''' + @Schema + '.' + @TbName + ''';'
		PRINT @cmd
		exec(@cmd)
		print ' '
		end
	FETCH NEXT FROM CURS INTO @Schema, @TbName, @TblId, @MaxFrag
	END
CLOSE CURS
DEALLOCATE CURS


-- Now check indexes for table without clustered index or whose clustered index wasn't fragmented

DECLARE
	CURS CURSOR FAST_FORWARD FOR
	SELECT
		SchemaName,
		TblName, 
		IndexName,
		TblId,
		index_id,
		max(avg_fragmentation_in_percent) as MaxFrag
	FROM 
		#TEMP
	WHERE 
		avg_fragmentation_in_percent > 10 and TblId NOT IN
		( SELECT TblId FROM #TEMP WHERE Index_id = 1 and avg_fragmentation_in_percent > 10 )
	GROUP BY SchemaName, TblName, IndexName, TblId, index_id
	ORDER BY SchemaName, TblName, index_id


OPEN CURS
FETCH NEXT FROM CURS INTO @Schema, @TbName, @IdxName, @TblId, @IndexId, @MaxFrag
WHILE @@FETCH_STATUS = 0
	BEGIN
	SET @cmd = 'ALTER INDEX ' + @IdxName + ' ON ' + @DBName + '.' + @Schema + '.' + @TbName + 
				' REBUILD WITH (SORT_IN_TEMPDB = ON, ONLINE = OFF);'
	
	PRINT @cmd + ' -- ' + cast(@MaxFrag as varchar)

	IF @Exec = 'Y' 
		begin
		BEGIN TRY
			EXEC (@cmd)
		END TRY
		BEGIN CATCH
			SELECT
				@ErrorMessage = ERROR_MESSAGE(),
				@ErrorSeverity = ERROR_SEVERITY(),
				@ErrorState = ERROR_STATE()
			RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState)
		END CATCH

		SET @cmd = 'USE ' + @DBName + '; exec sp_recompile ''' + @Schema + '.' + @TbName + ''';'
		print @cmd
		exec(@cmd)
		print ' '
		end
	FETCH NEXT FROM CURS INTO @Schema, @TbName, @IdxName, @TblId, @IndexId, @MaxFrag
	END
CLOSE CURS
DEALLOCATE CURS
END
GO



CREATE PROCEDURE dbo.usp_RenameFileWithDateTimeNoSS
	@FilePath 	varchar( 120 )

/******************************************************

	Renames a file to include the date and time as
	part of the name.

	Example:  
		DBA..usp_RenameFileWithDateTime �c:\temp\test.log�
		renames the file to the following format:  
			 �test_yyyymmddhhmi.log�  (24h)

*******************************************************/
AS
SET NOCOUNT ON
DECLARE
	@DateString		varchar( 50 ),
	@FileName		varchar(120)

DECLARE 
	@WinCmd varchar(300),
	@rtn	int,
	@jobID uniqueidentifier,
	@seq	int,
	@jobname varchar(300),
	@count int

CREATE TABLE #TEMP
(
	job_id uniqueidentifier ,
	job_name sysname ,
	run_status int ,
	run_date int ,
	run_time int ,
	run_duration int ,
	operator_emailed nvarchar(20) ,
	operator_netsent nvarchar(20), 
	operator_paged nvarchar(20) ,
	retries_attempted int ,
	server nvarchar(30) 
)

SET @rtn = 0
SET @DateString = 
	LEFT( REPLACE( REPLACE( REPLACE( CONVERT( varchar, GETDATE(), 120 ), '-', '' ), ':', '' ), ' ', '' ), 12 )
PRINT @DateString
			  
SET @FileName	= RIGHT( @FilePath, CHARINDEX( '\', REVERSE( @FilePath ) ) - 1 )
SET @WinCmd  = 
	'ren "' + @FilePath + '" ' +
	LEFT( @FileName, CHARINDEX( '.', @FileName ) - 1 ) +
	'_' + @DateString + RIGHT( @FileName, 4 ) + ''

SET @rtn = 0
SET @SEQ = 0
SET @jobname = '_Temp_RenameFileWithDateTimeNoSS'

WHILE @seq < 50
	begin
	set @jobname = @jobname + cast(@seq as varchar)
	SELECT @count = count(*) from msdb.dbo.sysjobs where name = @jobname
	print cast(@count as varchar)
	print @jobname
	if @count = 0
		begin
		EXEC msdb.dbo.sp_add_job @job_name = @jobname, @job_id = @jobID OUTPUT 
		if @jobID is not null set @seq = 99
		end
	set @seq = @seq + 1
	end

IF @jobID is null
	begin
	SET @rtn = -1
	RETURN @rtn
	end

EXEC msdb.dbo.sp_add_jobstep @job_id = @jobID, @step_name = 'Rename File With Datetime NoSS', @step_id = 1, @subsystem = 'CMDEXEC', @command = @WinCmd
EXEC msdb.dbo.sp_add_jobserver @job_id = @jobID
EXEC @rtn = msdb.dbo.sp_start_job @job_id = @jobID, @output_flag = 0 
IF @rtn <> 0 RETURN @rtn

WAITFOR DELAY '000:00:05' -- Give the job a chance to complete
INSERT INTO #TEMP EXEC msdb.dbo.sp_help_jobhistory @job_id = @jobID

WHILE @@ROWCOUNT = 0
  BEGIN
  WAITFOR DELAY '000:00:05' -- Give the job a chance to complete
  INSERT INTO #TEMP EXEC msdb.dbo.sp_help_jobhistory @job_id = @jobID
  END

SELECT @rtn = max(run_status) FROM #TEMP
IF @rtn <> 1 
	SET @rtn = -1
ELSE
	EXEC msdb.dbo.sp_delete_job @job_id = @jobID

DROP TABLE #TEMP
RETURN @rtn
go

CREATE TABLE [dbo].[OrphanLogin] (
	[ServerName] [varchar] (60) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[OrphanLogin] [varchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[SID] [varbinary] (85) NULL 
) ON [PRIMARY]
GO