USE DBA
go
IF  OBJECT_ID( 'dbo.usp_Get_DbStats3' ) IS NOT NULL
	DROP PROCEDURE dbo.usp_Get_DbStats3
go
CREATE PROCEDURE dbo.usp_Get_DbStats3
/***************************************************************

		This procedure records the disk space used by
		databases.

*****************************************************************/
AS
BEGIN
SET NOCOUNT ON

DROP TABLE dbo.tmplg
DROP TABLE dbo.tmp_sfs

--IF OBJECT_ID( 'dbo.tmplg' ) IS NULL
	CREATE TABLE dbo.tmplg
	( 
		DBName       	varchar( 64 ),
		LogSize		real,
		LogSpaceUsed	real,
		Status		int
	)

--IF OBJECT_ID( 'dbo.tmp_sfs' ) IS NULL
	CREATE TABLE dbo.tmp_sfs
	(   
		DBName			nvarchar( 128 ),
		FileId	    		int,
		FileGroup		int, 
		TotalExtents		bigint, 
		UsedExtents		bigint, 
		Name			varchar( 1024 ), 
		FileName		varchar( 1024 )
	)

--TRUNCATE TABLE DBA.dbo.tmplg
--TRUNCATE TABLE DBA.dbo.tmp_sfs

INSERT INTO DBA.dbo.tmplg EXECUTE ( 'DBCC SQLPERF( logspace )' )

DECLARE	@CMD varchar( 2000 )
SET @CMD = 'USE [?] ' 
SET @CMD = @CMD + 
	'INSERT INTO DBA.dbo.tmp_sfs( FileId,FileGroup,TotalExtents,UsedExtents,Name,FileName	 ) '
SET @CMD = @CMD + ' EXEC( ''DBCC SHOWFILESTATS'' ) ' 
SET @CMD = @CMD + ' UPDATE DBA.dbo.tmp_sfs SET DBName = ''?'' WHERE DBName IS NULL '
EXEC sp_MSForEachDB @Command1=@CMD

INSERT INTO DBA.dbo.DBSTATS 
( 	DBName, Data_Size, Data_Used, 	Log_Size, Log_Used, State_Date, PercentLog )
	SELECT 	
			s.DBName,
			SUM( TotalExtents ) * 64 / 1024, 
			SUM( UsedExtents ) * 64 / 1024, 
			CAST( MAX( l.LogSize ) AS varchar ) ,
			CAST( ( MAX(l.LogSize) * MAX(l.LogSpaceUsed) ) / 100.0 AS varchar ),
			GETDATE(),
			MAX(LogSpaceUsed)
	FROM DBA.dbo.tmp_sfs s 
		JOIN DBA.dbo.tmplg l ON s.DBName = l.DBName
	WHERE s.DBName NOT IN( 'model', 'pubs', 'Northwind' )
	GROUP BY s.DBName
END
GO
-- SELECT * FROM DBA.dbo.DBSTATS ORDER BY STATE_DATE DESC, DBNAME

