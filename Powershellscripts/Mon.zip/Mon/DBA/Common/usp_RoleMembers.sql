use dba
go
IF OBJECT_ID( 'dbo.usp_RoleMembers' ) IS NOT NULL
	DROP PROCEDURE dbo.usp_RoleMembers
GO
CREATE PROCEDURE dbo.usp_RoleMembers 
			@DBName		varchar(50),
			@ReportPath	varchar( 100 ) = NULL
AS
SET NOCOUNT ON
IF @DBName IS NULL
	BEGIN
	PRINT 'Database name not provided'
	RETURN( -1 )
	END

DECLARE @SQLSTMT	varchar(500 )

SET @SQLSTMT = 
   'SELECT u.name as Role, x.name as Member 
	FROM [' + @DBName + '].dbo.sysusers u 
		JOIN [' + @DBName + '].dbo.sysmembers m ON u.uid = m.groupuid 
		JOIN [' + @DBName + '].dbo.sysusers x   ON x.uid = m.memberuid
	WHERE u.issqlrole = 1 and u.name <> ''public''
	ORDER BY u.name, x.name'

EXEC( @SQLSTMT )
IF @ReportPath IS NOT NULL
	BEGIN
	SET @SQLSTMT = 
	'sp_MakeWebTask 
		@DBName = ''' + @DBName + ''', 
		@OutputFile = ''' + @ReportPath + '\Roles.htm'' ,
		@WebpageTitle = ''Role members for ' + @DBName + ''',
		@ResultsTitle = ''Role members for ' + @DBName + ''',
		@LastUpdated = 1,
		@TabBorder = 1,
		@ColHeaders = 1,
		@Query = ''SELECT u.name as Role, x.name as Member 
		FROM [' + @DBName + '].dbo.sysusers u 
			JOIN [' + @DBName + '].dbo.sysmembers m ON u.uid = m.groupuid 
			JOIN [' + @DBName + '].dbo.sysusers x   ON x.uid = m.memberuid
		WHERE u.issqlrole = 1 and u.uid <> 0 
		ORDER BY u.name, x.name'''
	--print @sqlstmt
	EXEC( @SQLSTMT )
	END
GO

