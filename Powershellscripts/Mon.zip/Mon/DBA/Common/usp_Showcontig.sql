USE DBA
GO
IF OBJECT_ID( 'dbo.usp_Showcontig' ) IS NOT NULL
	DROP PROCEDURE dbo.usp_Showcontig
GO
CREATE PROCEDURE dbo.usp_Showcontig
			@MaxFrag	decimal = 10.0

/***************************************************************************

		Runs DBCC SHOWCONTIG on all the tables on the server and 
		inserts a record in the DBA.dbo.Showcontig table for indexes 
		that should be rebuilt.  The indexes can be rebuilt by executing
		DBA.dbo.usp_RebuildShowcontigIndexes.  A report of those indexes
 		is also returned.  Every time this procedure is run, the
		Showcontig table is first truncated.
				
		This procedure will fail on a SQL Server 7.0 server 
		because the ALL_INDEXES is not an option for SHOWCONTIG on 
		that version of SQL Server.

		Parameters:
			@MaxFrag  		
				The maximum percent fragmentation that
				must exist in order to be considered for 
				defragmentation.  The default value for @MaxFrag
				is 10.0%, but it can be modified to any value.

*************************************************************************/
AS
SET NOCOUNT ON

CREATE TABLE #FragList
(	
	DBNAME			varchar(50),
	TableName		char( 255 ),
	TableId			int,
	IndexName		char( 255 ),
	IndexId			int,
	Lvl				int,
	CountPages		int,
	CountRows		int,
	MinRecSize		int,
	MaxRecSize		int,
	AvgRecSize		int,
	ForRecCount		int,
	Extents			int,
	ExtentSwitches	int,
	AvgFreeBytes	int,
	AvgPageDensity	decimal,
	ScanDensity		decimal,
	BestCount		int,
	ActualCount		int,
	LogicalFrag		decimal,
	ExtentFrag		decimal,
	Owner			sysname NULL,
	CollectionDate	datetime
)

TRUNCATE TABLE DBA.dbo.SHOWCONTIG

DECLARE	
	@TableName		varchar( 50 ),
	@IndexName		varchar( 50 ),
	@DBName			varchar( 50 ),
	@IndexId		int,
	@Owner			sysname,
	@LogicalFrag	decimal,
	@ExtentFrag		decimal,
	@ScanDensity	decimal,
	@AvgPageDensity decimal,
	@TableCount		int,
	@JobStart		datetime,
	@JobEnd			datetime

SET @JobStart 		= GETDATE()

PRINT 'SHOWCONTIG JOB START TIME:  ' + CAST( @JobStart as varchar )

DECLARE 
	@RC 			int,
	@command1 		nvarchar(2000),
	@replacechar 	nchar(1),
	@command2 		nvarchar(2000),
	@command3 		nvarchar(2000),
	@whereand 		nvarchar(2000),
	@precommand 	nvarchar(2000),
	@postcommand 	nvarchar(2000)

-- Set parameter values
SET @replacechar = '?'
SET @command1 = 
	'PRINT '' '' PRINT ''?'' USE ? INSERT INTO #FragList
	( TableName, TableId, IndexName, IndexId, Lvl, CountPages,
  		CountRows, MinRecSize, MaxRecSize, AvgRecSize, ForRecCount,
  		Extents, ExtentSwitches, AvgFreeBytes, AvgPageDensity,
 	 	ScanDensity, BestCount, ActualCount, LogicalFrag, ExtentFrag	
	) EXEC( ''DBCC SHOWCONTIG WITH TABLERESULTS, ALL_INDEXES'' )' 
SET @command2 = 
	' USE ? UPDATE #FragList SET DBNAME = ''?'' WHERE DBNAME IS NULL ' +
	' DELETE FROM #FragList FROM #Fraglist f JOIN sysobjects s ON f.TableId = s.id ' +
	' WHERE xtype = ''S'' and DBName = ''?''' +
	' UPDATE #FragList SET Owner = USER_NAME( s.uid ) ' + 
	' FROM #FragList f JOIN sysobjects s ON f.TableId = s.id ' +
	' WHERE xtype = ''U'' and DBName = ''?''' 		
EXEC @RC = master.dbo.[sp_MSforeachdb] @command1, @replacechar, @command2, @command3, @precommand, @postcommand

-- I don't care about these databases
DELETE FROM #FragList WHERE DBNAME IN 
( 'master', 'msdb', 'tempdb','model', 'distribution', 'pubs', 'Northwind' )

-- IndexId: 1 	= Clustered index,
--			>1 	= Heap,
--			255 = Entry for tables that have text or image data
DELETE FROM #FragList WHERE IndexId < 1 OR IndexId = 255
DELETE FROM #FragList WHERE IndexName LIKE '_WA%'
DELETE FROM #FragList WHERE TableName = 'dtproperties'
UPDATE #Fraglist SET CollectionDate = GETDATE()

INSERT INTO DBA.dbo.SHOWCONTIG
(	
	Add_Date, DBName,TableName,TableId,IndexName,IndexId,Lvl,CountPages,
	CountRows,MinRecSize,MaxRecSize,AvgRecSize,ForRecCount,Extents,
	ExtentSwitches,AvgFreeBytes,AvgPageDensity,ScanDensity,BestCount,
	ActualCount,LogicalFrag,ExtentFrag,Owner	
)
	SELECT 
		CollectionDate, DBName,TableName,TableId,IndexName,IndexId,Lvl,CountPages,
		CountRows,MinRecSize,MaxRecSize,AvgRecSize,ForRecCount,Extents,
		ExtentSwitches,AvgFreeBytes,AvgPageDensity,ScanDensity,BestCount,
		ActualCount,LogicalFrag,ExtentFrag,Owner
	FROM #FragList
	WHERE
		-- who cares if there is only 1 page of index
		CountPages > 1 and
			-- Extent frag always matters
		( 	ExtentFrag > @MaxFrag OR
			-- Could the fill factor be wrong?
			ISNULL( ScanDensity, 0 ) < 90 OR
			-- Logical frag only pertains to clustered indexes
		 	( IndexId = 1 and LogicalFrag > @MaxFrag ) )
			
DROP TABLE #FragList

PRINT ' '
PRINT 'FRAGMENTED INDEXES'

DECLARE
	Indexes CURSOR FORWARD_ONLY READ_ONLY FOR
	SELECT 
		RTRIM( DBName ), RTRIM( TableName ), Owner, 
		RTRIM( IndexName ), IndexId, LogicalFrag, ExtentFrag, 
		ScanDensity, AvgPageDensity
	FROM DBA.dbo.ShowContig
	ORDER BY RTRIM( DBName ), RTRIM( TableName ), IndexName, Owner


OPEN Indexes
FETCH NEXT FROM Indexes 
	INTO @DBName, @TableName, @Owner, @IndexName, @IndexId,
		 @LogicalFrag, @ExtentFrag, @ScanDensity, @AvgPageDensity
WHILE @@FETCH_STATUS = 0
	begin
	PRINT ' '
	-- Logical fragmentation is only relevant to the clustered index 
	IF @IndexId = 1 
		begin
		PRINT @DBName + ', ' + @TableName + ', ' + @IndexName + ', ' +
		  	CAST( @IndexId as varchar ) + ' - Logical fragmentation ' + 
		  	RTRIM( CONVERT( varchar( 15 ), @LogicalFrag )) + '%'
		end

	PRINT @DBName + ', ' + @TableName + ', ' + @IndexName + ', ' +
		  CAST( @IndexId as varchar ) + ' - Extent fragmentation ' + 
		  RTRIM( CONVERT( varchar( 15 ), @ExtentFrag )) + '%'

	PRINT @DBName + ', ' + @TableName + ', ' + @IndexName + ', ' +
		  CAST( @IndexId as varchar ) + ' - Scan density ' + 
		  RTRIM( CONVERT( varchar( 15 ), @ScanDensity )) + '%'

	PRINT @DBName + ', ' + @TableName + ', ' + @IndexName + ', ' +
		  CAST( @IndexId as varchar ) + ' - Avg Page density ' + 
		  RTRIM( CONVERT( varchar( 15 ), @AvgPageDensity )) + '%'

	FETCH NEXT FROM Indexes 
		INTO @DBName, @TableName, @Owner, @IndexName, @IndexId,
			 @LogicalFrag, @ExtentFrag, @ScanDensity, @AvgPageDensity
	end
CLOSE Indexes
DEALLOCATE Indexes
PRINT ' '
PRINT '***********************************************************************'
PRINT ' '
SET @JobEnd = GETDATE()
PRINT 'JOB END TIME:  ' + CAST( @JobEnd as varchar )
IF DATEDIFF( mi, @JobStart, @JobEnd ) < 60
	PRINT 'JOB DURATION:  ' + 
		CAST( DATEDIFF( mi, @JobStart, @JobEnd ) as varchar ) + ' minutes'
ELSE
	PRINT 'JOB DURATION:  ' + 
	CAST( ( DATEDIFF( mi, @JobStart, @JobEnd )/60 ) as varchar ) + ' hrs ' +
	CAST( ( DATEDIFF( mi, @JobStart, @JobEnd )%60 ) as varchar ) + ' minutes'
go

