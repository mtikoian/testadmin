use DBA
go
IF OBJECT_ID( 'dbo.usp_DeleteDatedFiles' ) IS NOT NULL
	DROP PROCEDURE dbo.usp_DeleteDatedFiles
go
CREATE PROCEDURE dbo.usp_DeleteDatedFiles 
		@Path			varchar( 120 ),
		@Prefix			varchar( 120 ),
		@Suffix			varchar( 120 ),
		@HistoryValue	int = 7,
		@HistoryMetric	varchar( 20 ) = 'DAYS'

/************************************************************************************

	Deletes import files having the format PrefixYYYYMMDDSuffix whose date 
	is more than the age specified.
	
	Parameters:
		Path			Path 
		Prefix			Name of file preceding the date
		Suffix			Name of file following the date
		HistoryValue	Number of days or weeks  ( default = 7 )
		HistoryMetric	Days or Weeks ( default = 'DAYS' )

	Examples:
	sp_ihDeleteDatedFiles 'M:\Temp', 'vss_', '.csv'	
			( keep history for 7 days for files named vss_YYYYMMDD.csv )

	sp_ihDeleteDatedFiles 'M:\Temp', 'vssVendors', '.csv', 30 
			( keep history for 30 days for files named vssVendorsYYYYMMDD.csv )

	sp_ihDeleteDatedFiles 'M:\Temp', 'vss_', abc.csv', 5, 'WEEKS'	
			( keep history for 5 weeks for files named vss_YYYYMMDDabc.csv )

*************************************************************************************/
AS

SET NOCOUNT ON

CREATE TABLE #cmd_result ( output varchar( 1000 ) )

DECLARE 
	@Command 		varchar( 1000 ),
	@DateString		varchar( 10 ),
	@FileName 		varchar( 120 ),
	@Date			datetime,
	@Count			int

SET @HistoryMetric = UPPER( @HistoryMetric )
	
IF UPPER( @HistoryMetric ) NOT IN ( 'DAYS', 'WEEKS' )
	begin
	RAISERROR( 'INVALID HISTORY METRIC', 18, 1 ) WITH LOG
	RETURN
	end

SET @Path = RTRIM( @Path )
IF LEFT( @Path, 1 ) <> '\'  SET @Path = @Path + '\'

SET @Command = 'INSERT #cmd_result exec master..xp_cmdshell ''dir '
SET @Command = @Command + '"' + @Path + '"'''
PRINT @Command
EXECUTE ( @Command )

DELETE FROM #cmd_result WHERE output IS NULL

DELETE FROM #cmd_result 
WHERE RIGHT( RTRIM( output ), LEN( @Suffix ) ) <> @Suffix  

IF @Count = 0
	PRINT 'No FILES FOUND'
ELSE
	begin
	DECLARE 
		DIR_CURS CURSOR FOR
		SELECT RIGHT( output, CHARINDEX( ' ', REVERSE( RTRIM( output ) ) ) - 1 ) -- file name
		FROM #cmd_result

	SET @Count = 0
	PRINT 'SEARCHING FOR FILE TO DELETE'
	OPEN DIR_CURS
	FETCH FROM DIR_CURS INTO @FileName
	WHILE @@FETCH_STATUS = 0
		begin
		IF  LEN( @FileName ) = LEN( @Prefix ) + LEN( @Suffix ) + 8 AND
			LEFT( @FileName, LEN( @Prefix ) ) = @Prefix AND
			RIGHT( @FileName, LEN( @FileName ) - ( LEN( @Prefix ) + 8 ) ) = @Suffix AND
			ISNUMERIC( SUBSTRING( @FileName, LEN( @Prefix ) + 1, 8 ) ) = 1
			begin
			SET @DateString = SUBSTRING( @FileName, LEN( @Prefix ) + 5, 2 ) + '/' +
							  SUBSTRING( @FileName, LEN( @Prefix ) + 7, 2 ) + '/' +
							  SUBSTRING( @FileName, LEN( @Prefix ) + 1, 4 )
			SET @Date = CAST( @DateString  as datetime )

			IF @HistoryMetric = 'DAYS' AND DATEDIFF( DAY, @Date, GETDATE() ) >= @HistoryValue
				begin
				PRINT 'DELETING ' + @FileName
				SET @Command = 'master.dbo.xp_cmdshell ''del "' + @Path + @FileName + '"'''
				EXEC( @Command )
				SET @Count = @Count + 1
				end

			ELSE IF DATEDIFF( WEEK, @Date, GETDATE() ) >= @HistoryValue
				begin
				PRINT 'DELETING ' + @FileName
				SET @Command = 'master.dbo.xp_cmdshell ''del "' + @Path + @FileName + '"'''
				EXEC( @Command )
				SET @Count = @Count + 1
				end
			end
		FETCH FROM DIR_CURS INTO @FileName
		end	
	CLOSE DIR_CURS
	PRINT CAST( @Count as varchar ) + ' FILES DELETED'
	DEALLOCATE DIR_CURS
	DROP TABLE #cmd_result
	end
go

