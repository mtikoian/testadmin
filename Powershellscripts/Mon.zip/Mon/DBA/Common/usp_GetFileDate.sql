USE DBA
GO
IF OBJECT_ID( 'dbo.usp_GetFileDate' ) IS NOT NULL
	DROP PROCEDURE dbo.usp_GetFileDate
GO
CREATE PROCEDURE dbo.usp_GetFileDate
	@FileName		varchar(120),
	@LastWriteDate	char(8)  OUT,
	@LastWriteTime	char(8)  OUT
/*******************************************************
	
	Input:	
		@FileName		Full path file name
	Output: 
		@LastWriteDate	Date in YYYYMMDD format.
		@LastWriteTime  Time in hh:mm:ss (24 hr) format.

	If error or file not found, -1 return code.

********************************************************/

AS
SET NOCOUNT ON
DECLARE @cmd	varchar(1000)

CREATE TABLE #TMP
( 	AltName				varchar(120),
  	Size				int,
  	CreateDate			char(8),
	CreateTime			varchar(6),
	LastWrittenDate		char(8),
	LastWrittenTime 	varchar(6),
	LastAccessedDate	char(8),
	LastAccessedTime	varchar(6),
	Attributes			int
)
SET @cmd = 'master..xp_getfiledetails ''' + @FileName + ''''

INSERT INTO #tmp EXEC(@cmd)

IF @@ROWCOUNT = 0 RETURN(-1)

SELECT 
	@LastWriteDate = LastWrittenDate,
	@LastWriteTime = 
		CASE 	WHEN LEN(LastWrittenTime ) = 6 
				THEN LEFT( LastWrittenTime, 2 ) + ':' + 
					 SUBSTRING( LastWrittenTime, 3, 2 ) + ':' +
					 RIGHT( LastWrittenTime, 2 )
				ELSE '0' + LEFT( LastWrittenTime, 1 ) + ':' + 
					 SUBSTRING( LastWrittenTime, 2, 2 ) + ':' +
					 RIGHT( LastWrittenTime, 2 )
		END				  
FROM #TMP
PRINT 'Last Written Date = ' + 
		SUBSTRING( @LastWriteDate, 5,2 ) + '/' +
		RIGHT(  @LastWriteDate, 2 ) + '/' +
		LEFT(  @LastWriteDate, 4 ) 
PRINT 'Last Written Time = ' + @LastWriteTime
RETURN(0)
go






