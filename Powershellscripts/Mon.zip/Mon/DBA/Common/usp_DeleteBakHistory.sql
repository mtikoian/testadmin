use DBA
go
IF OBJECT_ID('dbo.usp_DeleteBakHistory') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.usp_DeleteBakHistory
    IF OBJECT_ID('dbo.usp_DeleteBakHistory') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.usp_DeleteBakHistory >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.usp_DeleteBakHistory >>>'
END
go
CREATE PROCEDURE dbo.usp_DeleteBakHistory 
		@Path			varchar( 120 ),
		@DBName			varchar( 80 ) = 'pubs',
		@HistoryValue	int = 7,
		@HistoryMetric	varchar( 5 ) = 'DAYS'

/************************************************************************************

	Deletes backup files that are older than the amount of history requested.

	Backups are assumed to be named according using the same format as
	is assumed to be of the same format as the names of full backups 
	generated from the sqlmaint utility.  For example, the backup name for
	the Northwind database would be Northwind_Full_200312300600.BAK. 

	Parameters:
		Path			Path of database backups 
		DBName			Name of database  ( default = 'pubs' )
		HistoryValue	Number of days or weeks  ( default = 7 )
		HistoryMetric	Days or Weeks ( default = 'DAYS' )

	Examples:
		usp_DeleteBakHistory '\\172.24.60.76\Ddrive\2ksqlprod2\Northwind', 'Northwind', 1, 'WEEKS'    
			( deletes backup files from \\172.24.60.76\Ddrive\2ksqlprod2\Northwind
			  that are older than 1 week.  )

		usp_DeleteBakHistory 'M:\Backups\Northwind', 'Northwind'	( keep history for 7 days )

*************************************************************************************/
AS
SET NOCOUNT ON

CREATE TABLE #cmd_result 
( 
     output varchar( 8000 ) NULL
)

DECLARE 
	@jobID        	uniqueidentifier,
    @jobname        varchar(30),
	@Cmd        	varchar( 1000 ),
	@DateString		varchar( 10 ),
	@BakName 		varchar( 80 ),
	@BakDate		datetime,
	@Count			int,
	@Rtn			int

SET @HistoryMetric = UPPER( @HistoryMetric )
SET @Rtn           = 0

IF @Path IS NULL
	begin
	RAISERROR( 'NO PATH SPECIFIED',  18, 1 ) 
	RETURN(-1)
	end

SET @Path = RTRIM( @Path )
IF RIGHT( @Path, 1 ) = '\'  SET @Path = LEFT( @Path, LEN( @Path ) - 1 )
	
SELECT @Count = COUNT(*) FROM master..sysdatabases WHERE name = @DBName
IF @Count = 0 
	begin
	RAISERROR( 'INVALID DATABASE NAME',  18, 1 )
	RETURN(-1)
	end

IF UPPER( @HistoryMetric ) NOT IN ( 'DAYS', 'WEEKS' )
	begin
	RAISERROR( 'INVALID HISTORY METRIC', 18, 1 )
	RETURN(-1)
	end

SET @Cmd = 'INSERT #cmd_result exec master..xp_procedure ''dir '

SET @Cmd = @Cmd + '"' + @Path + '\' + @DBName + '_Full_*.BAK"'''

EXECUTE ( @Cmd )

DELETE FROM #cmd_result WHERE CHARINDEX( '.BAK', output ) = 0
DELETE FROM #cmd_result WHERE output is null

DECLARE 
	BAK_CURS CURSOR FOR
	SELECT 
		LEFT( output, 10 ), 
		RIGHT( output, CHARINDEX( ' ', REVERSE( output ) ) - 1 ) 
	FROM #cmd_result

SELECT @Count = COUNT(*) FROM #cmd_result

IF @Count = 0 
	PRINT 'NO BACKUPS FOUND'
--ELSE IF @Count <= @HistoryValue
--	PRINT 'NUMBER OF BACKUPS NOT EXCEEDED'
ELSE
  BEGIN
	SET @Count = 0
	PRINT 'SEARCHING FOR BACKUP TO DELETE'
	OPEN BAK_CURS
	FETCH FROM BAK_CURS INTO @DateString, @BakName
	WHILE @@FETCH_STATUS = 0
	  BEGIN
		SET @BakDate = @DateString
		PRINT @BakDate
		SET @Cmd = 'del "' + @Path + '\' + @BakName + '"'
					
		IF @HistoryMetric = 'DAYS' AND DATEDIFF( DAY, @BakDate, GETDATE() ) >= @HistoryValue
		  BEGIN
			PRINT 'DELETING ' + @BakName
            set @jobname = '_tmp_Delete' + convert(varchar(10), @count) 
            EXEC msdb.dbo.sp_add_job @job_name = @jobname, @enabled  = 1, 
                 @start_step_id = 1, @owner_login_name='sa'
            EXEC msdb.dbo.sp_add_jobstep @job_name = @jobname, @step_name = 'Delete Old Backups', 
                 @step_id = 1, @subsystem = 'CMDEXEC', @command = @cmd
            EXEC msdb.dbo.sp_add_jobserver @job_name = @jobname
            EXEC @Rtn = msdb.dbo.sp_start_job @job_name = @jobname, @output_flag = 0
            If @Rtn <> 0 
                 RETURN @Rtn
            WAITFOR DELAY '000:00:05' -- Give the job a chance to complete
            EXEC @Rtn = msdb.dbo.sp_delete_job @job_name = @jobname
            If @Rtn <> 0 
                 RETURN @Rtn
			SET @Count = @Count + 1
		  END

		ELSE IF DATEDIFF( WEEK, @BakDate, GETDATE() ) >= @HistoryValue
		  BEGIN
			PRINT 'DELETING ' + @BakName
            set @jobname = '_tmp_Delete' + convert(varchar(10), @count) 
            EXEC msdb.dbo.sp_add_job @job_name = @jobname, @enabled  = 1, 
                 @start_step_id = 1, @owner_login_name='sa'
            EXEC msdb.dbo.sp_add_jobstep @job_name = @jobname, @step_name = 'Delete Old Backups', 
                 @step_id = 1, @subsystem = 'CMDEXEC', @command = @cmd
            EXEC msdb.dbo.sp_add_jobserver @job_name = @jobname
            EXEC @Rtn = msdb.dbo.sp_start_job @job_name = @jobname, @output_flag = 0
            If @Rtn <> 0 
                 RETURN @Rtn
            WAITFOR DELAY '000:00:05' -- Give the job a chance to complete
            EXEC @Rtn = msdb.dbo.sp_delete_job @job_name = @jobname
            If @Rtn <> 0 
                 RETURN @Rtn
			SET @Count = @Count + 1
		  END

		FETCH FROM BAK_CURS INTO @DateString, @BakName
	  END	
	CLOSE BAK_CURS
	PRINT CAST( @Count as varchar ) + ' FILES DELETED'
  END

DEALLOCATE BAK_CURS
DROP TABLE #cmd_result

RETURN @Rtn

go
IF OBJECT_ID('dbo.usp_DeleteBakHistory') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.usp_DeleteBakHistory >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.usp_DeleteBakHistory >>>'
go

