USE DBA
go

if OBJECT_ID( 'udf_InsertCommas' ) is not null
	DROP FUNCTION dbo.udf_InsertCommas
go

CREATE FUNCTION dbo.udf_InsertCommas( @VarNumber	varchar( 15 ) )
	RETURNS varchar( 20 )

/********************************************************

			User-Defined function to insert
			commas into a string representing 
			a number.

********************************************************/
	
AS BEGIN
	
	DECLARE 
		@DecimalPoint	int,
		@FirstComma		int,
		@WithCommas	    varchar( 20 )


	SET @WithCommas = @VarNumber
	if @WithCommas is null RETURN @WithCommas

	SET @DecimalPoint = CHARINDEX( '.', @WithCommas )

	if @DecimalPoint = 0
		SET @FirstComma = LEN( @WithCommas ) + 1
	else
		SET @FirstComma	= @DecimalPoint
	

	WHILE ( @FirstComma > 4 )
	begin
		SET @WithCommas = LEFT( @WithCommas, @FirstComma - 4 ) + ',' + 
						 RIGHT( @WithCommas, Len( @WithCommas ) - @FirstComma + 4  )
		SET @FirstComma = CHARINDEX( ',', @WithCommas )
	end
	
	RETURN @WithCommas
END
GO 