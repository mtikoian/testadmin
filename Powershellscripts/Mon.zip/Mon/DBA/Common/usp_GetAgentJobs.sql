USE DBA
GO
IF OBJECT_ID( 'dbo.usp_GetAgentJobs' ) IS NOT NULL
	DROP PROCEDURE dbo.usp_GetAgentJobs
GO
CREATE PROCEDURE dbo.usp_GetAgentJobs
AS
BEGIN
SET NOCOUNT ON

IF OBJECT_ID( 'dbo.Agent_Jobs' ) IS NULL
	CREATE TABLE dbo.Agent_Jobs
(	job_id                UNIQUEIDENTIFIER NOT NULL,
    last_run_date         INT              NOT NULL,
    last_run_time         INT              NOT NULL,
    next_run_date         INT              NOT NULL,
    next_run_time         INT              NOT NULL,
  	next_run_schedule_id  INT              NOT NULL,
	requested_to_run      INT              NOT NULL, -- BOOL
	request_source        INT              NOT NULL,
	request_source_id     sysname          NULL,
	running               INT              NOT NULL, -- BOOL
	current_step          INT              NOT NULL,
	current_retry_attempt INT              NOT NULL,
    job_state             INT              NOT NULL
)
ELSE
	TRUNCATE TABLE dbo.Agent_Jobs

INSERT INTO dbo.Agent_Jobs EXEC master.dbo.xp_sqlagent_enum_jobs 1,'sa'
/*
SELECT name as JobName
FROM dbo.Agent_Jobs r JOIN msdb.dbo.sysjobs j ON r.job_id = j.job_id
WHERE running = 1
*/
END
GO


