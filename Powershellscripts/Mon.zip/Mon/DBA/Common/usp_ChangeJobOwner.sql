USE [DBA]
GO

IF OBJECT_ID('dbo.usp_ChangeJobOwner') IS NOT NULL
	DROP PROCEDURE [dbo].[usp_ChangeJobOwner] 
GO

USE [DBA]
GO

/****** Object:  StoredProcedure [dba].[dbo].[usp_ChangeJobOwner]    Script Date: 11/03/2009 09:47:11 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].usp_ChangeJobOwner
AS
BEGIN
SET NOCOUNT ON

DECLARE 
	@SQLStmt	varchar( 6000 ),
	@JobId		varchar(55)
	

CREATE TABLE #TMP
( 	
	job_id	varchar(55) NULL,
	job_owner [sysname] NULL
)

SET @SQLStmt = 'INSERT INTO #TMP select job_id, SUSER_SName (owner_sid) as Job_Owner FROM msdb.dbo.sysjobs WHERE SUSER_SName(owner_sid) <> ''sa'''	

	--PRINT @SQLStmt

	EXEC ( @SQLStmt )

DECLARE 	
	@job_id 	varchar(55),	
	@job_onwer	sysname


DECLARE	JOB_CUR CURSOR FOR
SELECT job_id, job_owner
FROM #TMP 

OPEN JOB_CUR
FETCH NEXT FROM JOB_CUR INTO  @job_id,	@job_onwer


WHILE @@FETCH_STATUS = 0
	begin

	SET @SqlStmt = ' EXEC msdb.[dbo].[sp_update_job] @job_id=N''' + @job_id + ''',@owner_login_name=N''sa'';'
	--PRINT @SqlStmt
	EXEC (@SqlStmt)


	FETCH NEXT FROM JOB_CUR INTO @job_id,	@job_onwer
	end

CLOSE JOB_CUR
DEALLOCATE JOB_CUR
DROP TABLE #TMP

END 
	