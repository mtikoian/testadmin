USE [DBA]
GO

/****** Object:  StoredProcedure [dbo].[usp_GetOrphanLogins]    Script Date: 10/27/2009 16:10:03 ******/
IF  (OBJECT_ID(N'[dbo].[usp_GetOrphanLogins]')) IS NOT NULL
DROP PROCEDURE [dbo].[usp_GetOrphanLogins]
GO

USE [DBA]
GO

/****** Object:  StoredProcedure [dbo].[usp_GetOrphanLogins]    Script Date: 10/27/2009 16:10:03 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[usp_GetOrphanLogins] 
	@Server 	varchar(60) = @@ServerName,
	@Version	int = 2
AS
BEGIN
SET NOCOUNT ON
PRINT '    usp_GetOrphanLogins - ' + @Server

DECLARE @SqlStmt	varchar( 2000 )

TRUNCATE table [DBA].dbo.OrphanLogin

SET @SqlStmt = 'INSERT into [DBA].dbo.OrphanLogin (SID,OrphanLogin) '
IF @Version in (5,8)
	begin
	SET @SqlStmt = @SqlStmt + ' exec [' + @Server + '].MASTER.SYS.sp_validatelogins'
	--PRINT @SqlStmt
	EXEC( @SqlStmt )
	end

ELSE
	begin
	SET @SqlStmt = @SqlStmt + ' exec [' + @Server + '].MASTER.dbo.sp_validatelogins'
	--PRINT @SQLSTMT
	EXEC( @SqlStmt )
	end

UPDATE dbo.OrphanLogin
SET ServerName = @Server where ServerName is null

END


GO


