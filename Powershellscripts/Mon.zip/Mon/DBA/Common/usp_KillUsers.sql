USE dba
GO
IF OBJECT_ID( 'dbo.usp_KillUsers' ) IS NOT NULL
	DROP PROCEDURE dbo.usp_KillUsers
GO
CREATE PROCEDURE dbo.usp_KillUsers 
				@DBName		varchar(50),
				@SingleUser char(1) = NULL

/*************************************************

	Kills all the current connections.  
	
	If the SingleUser parameter is set to 'Y', 
	the database will be left in single-user mode.

***************************************************/
AS
SET NOCOUNT ON
DECLARE
	@Cmd		varchar(300)
	
IF @DBName = ''
	begin
	RAISERROR( 'Database name required', 0, 1  )
	RETURN -1
	end
ELSE IF @DBName NOT IN ( SELECT name FROM master..sysdatabases )
	begin
	RAISERROR( 'Invalid database name', 0, 1  )
	RETURN -1
	end

PRINT 'SETTING DATABASE TO SINGLE_USER'
SET @Cmd = 'ALTER DATABASE ' + @DBName 
			+ ' SET SINGLE_USER WITH ROLLBACK AFTER 60 SECONDS'
EXEC(@Cmd)

IF ISNULL( @SingleUser, '' ) = 'Y'
	PRINT 'DATABASE ' + @DBName + ' SET TO SINGLE_USER MODE'
ELSE
	begin
	PRINT 'SETTING DATABASE TO MULTI_USER'
	SET @Cmd = 'ALTER DATABSE ' + @DBName + ' SET MULTI_USER'
	EXEC(@Cmd )
	end

RETURN
GO