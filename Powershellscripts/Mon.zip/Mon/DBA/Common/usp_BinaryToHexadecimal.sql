USE dba
go

IF OBJECT_ID ('dbo.usp_BinaryToHexadecimal') IS NOT NULL
  DROP PROCEDURE dbo.usp_BinaryToHexadecimal
GO
CREATE PROCEDURE dbo.usp_BinaryToHexadecimal
    @BinValue varbinary(256),
    @HexValue varchar(256) OUTPUT
/*************************************************

	Converts a binary value to a hexadecimal.

**************************************************/
AS
DECLARE 
	@CharValue 	varchar(256),
	@i 			int,
	@Length 	int,
	@HexString 	char(16)

SET @CharValue = '0x'
SET @i = 1
SET @Length = DATALENGTH (@BinValue)
SET @HexString = '0123456789ABCDEF' 

WHILE (@i <= @Length) 
BEGIN
  DECLARE 
		@TempInt 	int,
  		@FirstInt 	int,
  		@SecondInt 	int

  SET @TempInt = CONVERT(int, SUBSTRING(@binvalue,@i,1))
  SET @FirstInt = FLOOR(@TempInt/16)
  SET @SecondInt = @TempInt - (@FirstInt*16)
  SET @CharValue = @CharValue + SUBSTRING(@HexString, @FirstInt+1, 1) +
    							SUBSTRING(@HexString, @SecondInt+1, 1)
  SET @i = @i + 1
END
SET @hexvalue = @CharValue
GO
