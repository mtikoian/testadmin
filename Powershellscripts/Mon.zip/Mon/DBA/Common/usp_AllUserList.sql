USE DBA
go
IF OBJECT_ID( 'usp_AllUserList' ) IS NOT NULL
	DROP PROCEDURE dbo.usp_AllUserList
go

CREATE PROCEDURE dbo.usp_AllUserList 
		@SortOrder	  varchar( 10 ) = 'User',
		@ServerName	  varchar( 30 ) = NULL,
		@DatabaseName varchar( 30 ) = NULL
AS


SET NOCOUNT ON

if OBJECT_ID( '#TempUsers' ) is not null
	DROP TABLE #TempUsers

CREATE TABLE #TempUsers
(	
	ServerName		varchar( 30 ),
	UserName		varchar( 30 ),
	Pwd				char( 2 ), 
	DBName			varchar( 30 ),
	RoleName		varchar( 30 ),
	IsNTGroup		char( 2 ),
	IsAliased		char( 2 ),
	SysAdmin		char( 2 ),
	ServerAdmin 	char( 2 ),
	SetupAdmin		char( 2 ),
	ProcessAdmin	char( 2 ),
	SecurityAdmin	char( 2 ),
	DiskAdmin		char( 2 ),
	DBCreator		char( 2 )    
)

INSERT INTO #TempUsers
	exec dbo.usp_UserList2 

if @SortOrder = 'Database'
	SELECT 	ServerName, 	DBname, 		RoleName,      	UserName,  
			Pwd, 			SysAdmin,		DBCreator		IsNTGroup,  	IsAliased,	
			ServerAdmin, 	SetupAdmin, 	ProcessAdmin, 	SecurityAdmin, 	DiskAdmin 	
	FROM #TempUsers 
	ORDER BY DBName, RoleName, UserName

else if @SortOrder = 'Role'
	SELECT 	ServerName, RoleName,   	UserName,      	DBName,    
			Pwd, 		DBCreator,		SysAdmin,	   	IsNTGroup,  		IsAliased,       
			ServerAdmin, SetupAdmin, 	ProcessAdmin, 	SecurityAdmin, 		DiskAdmin
	FROM #TempUsers 
	ORDER BY RoleName, UserName, DBName

else 
	SELECT 	ServerName,	UserName,   	DBName,        	RoleName,  
			Pwd, 		SysAdmin,	   	DBCreator, 		IsNTGroup,		IsAliased,	
			ServerAdmin,SetupAdmin, 	ProcessAdmin,  	SecurityAdmin,	DiskAdmin	
	FROM #TempUsers 
	ORDER BY UserName, DBName, RoleName

DROP TABLE #TempUsers
GO
