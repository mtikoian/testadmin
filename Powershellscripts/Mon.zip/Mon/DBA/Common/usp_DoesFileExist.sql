USE DBA
GO
IF OBJECT_ID( 'dbo.usp_DoesFileExist' ) IS NOT NULL
	DROP PROCEDURE dbo.usp_DoesFileExist
GO
CREATE PROCEDURE dbo.usp_DoesFileExist
		@FileName	varchar( 120 ),
		@FileExists char(1) output
AS
SET NOCOUNT ON
CREATE TABLE #results
(
	FileExists		int,
	FileIsDir		int,
	ParentDirExists int 
)
DECLARE  
	@cmd		varchar( 500 ),
	@Exists		int

SET @cmd = 'master..xp_fileexist ''' + @FileName + ''''
INSERT INTO #results  EXEC( @cmd )

SELECT @Exists = FileExists FROM #results

IF @Exists = 1 
	SET @FileExists = 'Y'
ELSE
	SET @FileExists = 'N'

DROP TABLE #results
GO
