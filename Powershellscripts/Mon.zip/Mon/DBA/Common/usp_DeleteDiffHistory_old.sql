use DBA
go
IF OBJECT_ID( 'dbo.usp_DeleteDiffHistory' ) IS NOT NULL
	DROP PROCEDURE dbo.usp_DeleteDiffHistory
go
CREATE PROCEDURE dbo.usp_DeleteDiffHistory 
		@Path			varchar( 120 ),
		@DBName			varchar( 80 ) = 'pubs',
		@HistoryValue	int = 7,
		@HistoryMetric	varchar( 5 ) = 'DAYS'

/************************************************************************************

	Deletes differential backup files that are older than the amount 
	of history requested.

	Files are assumed to have the format <dbname>_diff_YYYYMMDDhhmm.
	For example, the backup name for the Northwind database would be 
	Northwind_diff_200312300600.BAK. 

	Parameters:
		Path			Path of database backups 
		DBName			Name of database  ( default = 'pubs' )
		HistoryValue	Number of days or weeks  ( default = 7 )
		HistoryMetric	Days or Weeks ( default = 'DAYS' )

	Examples:
		usp_DeleteDiffHistory '\\172.24.60.76\Ddrive\2ksqlprod2\Northwind', 'Northwind', 1, 'WEEKS'    
			( deletes backup files from \\172.24.60.76\Ddrive\2ksqlprod2\Northwind
			  that are older than 1 week.  )

		usp_DeleteDiffHistory 'M:\Backups\Northwind', 'Northwind'	( keep history for 7 days )

*************************************************************************************/
AS

SET NOCOUNT ON

CREATE TABLE #cmd_result ( output varchar( 8000 ) )

DECLARE 
	@Command 		varchar( 1000 ),
	@DateString		varchar( 10 ),
	@BakName 		varchar( 80 ),
	@BakDate		datetime,
	@Count			int

IF @Path IS NULL
	begin
	RAISERROR( 'NO PATH SPECIFIED',  18, 1 ) 
	RETURN(-1)
	end

SET @Path = RTRIM( @Path )
IF RIGHT( @Path, 1 ) = '\'  SET @Path = LEFT( @Path, LEN( @Path ) - 1 )
	
SELECT @Count = COUNT(*) FROM master..sysdatabases WHERE name = @DBName
IF @Count = 0 
	begin
	RAISERROR( 'INVALID DATABASE NAME',  18, 1 )
	RETURN(-1)
	end

SET @HistoryMetric = UPPER( @HistoryMetric )

IF @HistoryMetric NOT IN ( 'DAYS', 'WEEKS', 'DAY', 'WEEK' )
	begin
	RAISERROR( 'INVALID HISTORY METRIC', 18, 1 )
	RETURN(-1)
	end

SET @Command = 'INSERT #cmd_result exec master..xp_cmdshell ''dir '
SET @Command = @Command + '"' + @Path + '\' + @DBName + '_Diff_*.BAK"'''

PRINT @Command
EXECUTE ( @Command )

DELETE FROM #cmd_result WHERE CHARINDEX( '.BAK', output ) = 0
DELETE FROM #cmd_result WHERE output is null

DECLARE 
	BAK_CURS CURSOR FOR
	SELECT 
		LEFT( output, 10 ), 
		RIGHT( output, CHARINDEX( ' ', REVERSE( output ) ) - 1 ) 
	FROM #cmd_result

--SELECT * FROM #cmd_result
SELECT @Count = COUNT(*) FROM #cmd_result

IF @Count = 0 
	PRINT 'NO BACKUPS FOUND'
ELSE IF @Count <= @HistoryValue
	PRINT 'NUMBER OF BACKUPS NOT EXCEEDED'
ELSE
	begin
	SET @Count = 0
	PRINT 'SEARCHING FOR BACKUP TO DELETE'
	OPEN BAK_CURS
	FETCH FROM BAK_CURS INTO @DateString, @BakName
	WHILE @@FETCH_STATUS = 0
		begin
		--PRINT @DateString
		SET @BakDate = @DateString
		PRINT @BakDate
		--PRINT @BakName
		SET @Command = 'master..xp_cmdshell ''del "' + @Path + '\' + @BakName + '"'''
					
		IF @HistoryMetric IN( 'DAYS', 'DAY' ) AND 
				DATEDIFF( DAY, @BakDate, GETDATE() ) >= @HistoryValue
			begin
			--PRINT @Command
			PRINT 'DELETING ' + @BakName
			EXEC( @Command )
			SET @Count = @Count + 1
			end

		ELSE IF DATEDIFF( WEEK, @BakDate, GETDATE() ) >= @HistoryValue
			begin
			--PRINT @Command
			PRINT 'DELETING ' + @BakName
			EXEC( @Command )
			SET @Count = @Count + 1
			end

		FETCH FROM BAK_CURS INTO @DateString, @BakName
		end	
	CLOSE BAK_CURS
	PRINT CAST( @Count as varchar ) + ' FILES DELETED'
	end
DEALLOCATE BAK_CURS
DROP TABLE #cmd_result
go

