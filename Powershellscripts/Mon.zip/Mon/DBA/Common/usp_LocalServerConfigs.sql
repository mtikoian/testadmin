USE DBA
GO

IF OBJECT_ID('dbo.usp_LocalServerConfigs') IS NOT NULL
	DROP PROCEDURE dbo.usp_LocalServerConfigs
go
CREATE PROCEDURE dbo.usp_LocalServerConfigs
AS
TRUNCATE TABLE dbo.ServerConfigs

EXEC sp_configure 'show advanced option', '1'

RECONFIGURE
INSERT INTO dbo.ServerConfigs EXEC sp_configure

GO




