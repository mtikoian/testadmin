IF OBJECT_ID( '[dbo].[Usp_Clear_Trans_Log_2005]' ) IS NOT NULL
	DROP PROCEDURE [dbo].[Usp_Clear_Trans_Log_2005]
GO

CREATE PROCEDURE [dbo].[Usp_Clear_Trans_Log_2005] 
	@p_database_name varchar(100)
as
--XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
--XX
--XX invocation: execute Usp_Clear_Trans_Log_2005
--XX
--XX description: This will perform a backup log with truncate only on each log 
--XX                file then it will truncate the transaction log
--XX
--XX HISTORY:
--XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
DECLARE
	@vs_error_message   	VARCHAR(200),
	@vn_error_number      	NUMERIC(5),
	@vs_message         	varchar(200),
	@vs_name  		varchar(100),
	@vs_cmd 		varchar(1000)

BEGIN
SET NOCOUNT ON

SET @vs_cmd = 'USE ' + @p_database_name + ' SELECT name FROM sysfiles WHERE filename like ''%.ldf%'''  
print @vs_cmd

CREATE TABLE #temp ( name sysname )
INSERT INTO #temp(name) EXEC(@vs_cmd)

-- set the string to backup the log first  
SELECT @vs_cmd = 'BACKUP LOG ' +  @p_database_name + ' WITH  truncate_only'
print @vs_cmd

begin try
    EXEC(@vs_cmd)
end try
begin catch
  select Error_Number(), Error_Message()
  print ('Error backing up log for ' + @p_database_name)
  return
end catch

DECLARE
	c_files cursor for
 	SELECT name FROM #temp

open c_files
fetch c_files into @vs_name
while @@fetch_status = 0 
   begin
   begin try
      SET @vs_cmd = 'USE ' + @p_database_name + ' DBCC SHRINKFILE  (' + ltrim(rtrim(@vs_name)) + ',1) ' 
      print @vs_cmd
      EXEC (@vs_cmd)
   end try
   begin catch
      select Error_Number(), Error_Message()
      print ('Error backing up log for ' + @p_database_name)
      close c_files
      deallocate c_files
      return
   end catch
   fetch c_files into @vs_name
   end
   close c_files
   deallocate c_files     
END
GO
 
  
   
