use DBA
go
IF OBJECT_ID( 'dbo.usp_ExportApps' ) IS NOT NULL
	DROP PROCEDURE dbo.usp_ExportApps
go
CREATE PROCEDURE dbo.usp_ExportApps 
	@TYPE char(1) = NULL,
	@Audited char(1) = NULL
	
AS
BEGIN
SET NOCOUNT ON
DECLARE @rtn	int,
	@cmd 	varchar(3000)

CREATE TABLE #TEMP
(
	job_id uniqueidentifier ,
	job_name sysname ,
	run_status int ,
	run_date int ,
	run_time int ,
	run_duration int ,
	operator_emailed nvarchar(20) ,
	operator_netsent nvarchar(20), 
	operator_paged nvarchar(20) ,
	retries_attempted int ,
	server nvarchar(30) 
)

SET @rtn = 0

IF OBJECT_ID( 'dbo.ExportApps' ) IS NOT NULL
	DROP TABLE dbo.ExportApps

SET @cmd = 'SELECT Server, ServerType, DB, 
		Application, Department, Code, 
		DBA, Manager_Contact, 
		CASE Audited WHEN 1 THEN ''Y'' ELSE '''' END as Audited, 
		CASE PCI WHEN 1 THEN ''Y'' ELSE '''' END as PCI,
		CASE PII WHEN 1 THEN ''Y'' ELSE '''' END AS PII,
		CASE NonSQL WHEN 1 THEN ''Y'' ELSE '''' END AS NonSQL, 
		NumUsers, AdjUserCount,
		DBDrives, 
		Bkp_Plan, Tape_DRM_Plan, Bkp_PlanName, 
		OrigDBSize, OrigDBDate,
		CurrentDBSize, GrowthRate,  
		Comment
	    INTO dbo.ExportApps
	    FROM DBA.dbo.Applications_Supported'

IF @TYPE = 'P'
	BEGIN
	IF @Audited 	= 'A'  SET @cmd = @cmd + ' WHERE ServerType = ''P'' and Audited = 1' 
	ELSE IF @Audited = 'I' SET @cmd = @cmd + ' WHERE ServerType = ''P'' and PII = 1' 
	ELSE IF @Audited = 'C' SET @cmd = @cmd + ' WHERE ServerType = ''P'' and PCI = 1' 
	ELSE 		       SET @cmd = @cmd + ' WHERE ServerType = ''P'''
	END
   
IF @TYPE = 'D'
	BEGIN
	IF @Audited 	= 'A'  SET @cmd = @cmd + ' WHERE ServerType = ''D'' and Audited = 1' 
	ELSE IF @Audited = 'I' SET @cmd = @cmd + ' WHERE ServerType = ''D'' and PII = 1' 
	ELSE IF @Audited = 'C' SET @cmd = @cmd + ' WHERE ServerType = ''D'' and PCI = 1' 
	ELSE 		       SET @cmd = @cmd + ' WHERE ServerType = ''D'''
	END

SET @cmd = @cmd + ' ORDER BY Server, DB'

--PRINT @cmd
EXEC(@cmd)


exec msdb.dbo.sp_start_job 'DailyCheck - Export Apps' 
WAITFOR DELAY '000:00:05' -- Give the job a chance to complete
INSERT INTO #TEMP EXEC msdb.dbo.sp_help_jobhistory @job_name = 'DailyCheck - Export Apps'

WHILE @@ROWCOUNT = 0
  BEGIN
  WAITFOR DELAY '000:00:05' -- Give the job a chance to complete
  INSERT INTO #TEMP EXEC msdb.dbo.sp_help_jobhistory @job_name = 'DailyCheck - Export Apps'
  END

SELECT @rtn = max(run_status) FROM #TEMP
IF @rtn <> 1 SET @rtn = -1
RETURN @rtn
END
GO