USE DBA
GO
IF OBJECT_ID( 'dbo.usp_GetUserDatabaseList' ) IS NOT NULL
	DROP PROCEDURE dbo.usp_GetUserDatabaseList
GO
CREATE PROCEDURE dbo.usp_GetUserDatabaseList
AS
BEGIN
	SET NOCOUNT ON

	SELECT DISTINCT Databases.ServerName, Databases.DBName
	FROM  Users INNER JOIN Databases ON Users.DBId = Databases.DBId
UNION
	SELECT DISTINCT Databases.ServerName, '*'
	FROM  Users INNER JOIN Databases ON Users.DBId = Databases.DBId
END
GO
