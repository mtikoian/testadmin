USE DBA
GO
IF OBJECT_ID( 'dbo.usp_GetDatabaseSizes' ) IS NOT NULL
	DROP PROCEDURE dbo.usp_GetDatabaseSizes
GO
CREATE PROCEDURE dbo.usp_GetDatabaseSizes 
		@ServerName	varchar( 60 ) = @@ServerName
AS
BEGIN
SET NOCOUNT ON
PRINT '    usp_GetDatabaseSizes - ' + @ServerName
DECLARE 
	@SqlStmt	varchar( 2000 )

-- A server's DBSTATS table may also have history from another server
-- if a database was moved over from another server
SET @SqlStmt = 
	'INSERT INTO All_DBStats( DBId, Data_Size, Data_Used, Log_Size, Log_Used, Sample_Date, Percent_Log )'
SET @SqlStmt = @SqlStmt + 
	'SELECT DBId, Data_Size, Data_Used, Log_Size,Log_Used, State_Date, PercentLog '
SET @SqlStmt = @SqlStmt +
	'FROM [' + @ServerName + '].dba.dbo.DBStats s JOIN dbo.Databases d ON '
SET @SqlStmt = @SqlStmt + 
	'd.ServerName = ''' + @ServerName + '''  AND RTRIM( s.DBName ) = d.DBName ' 

--PRINT @SqlStmt
EXEC( @SqlStmt )
END
go

