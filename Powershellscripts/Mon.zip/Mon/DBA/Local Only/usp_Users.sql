USE DBA
GO
IF OBJECT_ID( 'dbo.usp_Users' ) IS NOT NULL
	DROP PROCEDURE dbo.usp_Users
GO
CREATE PROCEDURE dbo.usp_Users
	@Server varchar(60) = @@ServerName
AS
BEGIN
SET NOCOUNT ON
PRINT '    usp_Users - ' + @Server

DECLARE 
		@DBName		varchar( 120 ),
		@DBType		char(1),
		@DBId		int,
		@SQLString1 varchar( 3000 ),
		@SQLString2 varchar( 3000 ),
		@Once		bit

DECLARE DBcurs CURSOR FOR
	SELECT DBName, DBId, DBType
	FROM dbo.Databases
	WHERE ServerName = @Server and ActiveFlag = 1 and
		DBName not in 
	( 'tempdb', 'Northwind', 'pubs', 'LitespeedLocal', 'SRP.NA.BLACKBERRY.NET' ) and  
		( Status is NULL or Status = 'ONLINE' )
	ORDER BY DBName

SET @Once = 0

OPEN DBcurs
FETCH NEXT FROM DBcurs INTO @DBName, @DBId, @DBType
WHILE @@FETCH_STATUS = 0
	begin
	--PRINT @DBName
	UPDATE dbo.Databases SET ActiveFlag = 0 WHERE DBId = @DBId
	SET @SQLString1 = 
	'INSERT INTO dbo.Users( ServerName, RoleName, Login, Alias, NTGroup, DefaultDB, UserName, DBId, CreateDate ) '

	-- Note:  The 2KPERDAT server has a case-sensitive database ( SC_Prod ), so the table
	--        and column names in the following query must be all lowercase!!!
	SET @SQLString2 = 
	'SELECT distinct ''' + @Server + ''', 
	 left( ISNULL( r.name, '''' ), 50 ), 
	 ISNULL( l.name, '''' ), 
	 CASE WHEN u.isaliased = 1 THEN ''Y'' ELSE ''N'' END, 
	 CASE WHEN u.isntgroup = 1 THEN ''Y'' ELSE ''N'' END,
	  l.dbname, 
	 left( u.name, 50 ), ' + 
	cast( @DBId as varchar ) + 
	 ', u.CreateDate
	  FROM [' + @Server + '].master.dbo.syslogins l 
	 RIGHT JOIN [' + @Server + '].[' + @DBName + '].dbo.sysusers u ON u.sid = l.sid 
	 LEFT JOIN [' + @Server + '].[' + @DBName + '].dbo.sysmembers m ON u.uid = m.memberuid 
	 LEFT JOIN [' + @Server + '].[' + @DBName + '].dbo.sysusers r ON  r.uid = m.groupuid 
	 WHERE 
		ISNULL( l.name, '''' ) NOT IN( ''sa'') and
	 	ISNULL( u.name, '''') NOT IN ( ''INFORMATION_SCHEMA'', ''SYSTEM_FUNCTION_SCHEMA'', ''public'' ) AND
		( ISNULL( l.name, '''' ) <> ''''  or ISNULL( r.name, '''' ) <> '''' )'
	
	--PRINT @SQLString1 + @SQLString2
	EXEC( @SQLString1 + @SQLString2 )

	IF EXISTS( SELECT * FROM dbo.AdjustedUsers WHERE ServerName = @Server and DBName = @DBName )
		begin
		DECLARE 
			@Table		varchar(60), 
			@Filter 	varchar(300),
			@Owner		varchar(60),
			@CreateDate	varchar(60),
			@LastLogin	varchar(60),
			@Login		varchar(60),
			@User		varchar(150), 
			@DefaultDB  varchar(120)

		SELECT 
			@Table = a.TableName, 
			@Filter = a.Filter, 
			@Owner = a.Owner,
			@CreateDate = a.CreateDateColumn,
			@LastLogin = a.LastLoginColumn,
			@Login = a.Login,
			@User = a.UserColumn,
			@DefaultDB = u.DefaultDB
		FROM DBA.dbo.AdjustedUsers a JOIN dbo.Users u ON a.Login = u.Login
		WHERE a.DBName = @DBName
			
		SET @SQLString1 = 'INSERT INTO dbo.Users( AdjUser, ServerName, Login, UserName, DBId, DefaultDB, CreateDate, LastLogin ) '

		IF  @DBName = 'PerformanceAppraisal' AND @Server = '2KSQLDEV1'
			SET @SQLString1 = @SQLString1 + 'SELECT 1, ''' + @Server + ''', ''PAS2KSQLDEV1ID'',' + 
				@User + ',''' + cast( @DBId as varchar ) + ''', ''' + @DefaultDB + ''''
		ELSE
			SET @SQLString1 = @SQLString1 + 'SELECT 1, ''' + @Server + ''', ''' + @Login + ''', ' + 
				@User + ',''' + cast( @DBId as varchar ) + ''', ''' + @DefaultDB + ''''
		
		IF ISNULL( @CreateDate, '' ) = ''
			SET @SQLString1 = @SQLString1 + ', NULL'
		ELSE
			SET @SQLString1 = @SQLString1 + ', ' + @CreateDate 

		IF ISNULL( @LastLogin, '' ) = ''
			SET @SQLString1 = @SQLString1 + ', NULL '
		ELSE
			SET @SQLString1 = @SQLString1 + ', ' + @LastLogin 

		
		SET @SQLString1 = @SQLString1 +
			' FROM [' + @Server + '].' + @DBName + '.' + @Owner + '.' + @Table

		IF @Filter IS NOT NULL
			SET @SQLString1 = @SQLString1 +  ' WHERE ' + @Filter

		--PRINT @SQLString1
       	EXEC( @SQLString1 )
		end

	UPDATE dbo.Databases SET ActiveFlag = 1 WHERE DBId = @DBId
	FETCH NEXT FROM DBcurs INTO @DBName, @DBId, @DBType
	end
CLOSE DBcurs
DEALLOCATE DBcurs

SET @SQLString1 =
'INSERT INTO dbo.Users( ServerName, Login, NTGroup, DefaultDB )
SELECT ''' + @Server + ''', l.name, 
CASE WHEN l.IsNtGroup = 1 THEN ''Y'' ELSE ''N'' END,
dbname
FROM [' + @Server + '].master.dbo.syslogins l
WHERE l.name IS NOT NULL and l.name NOT IN 
( SELECT Login FROM dbo.Users WHERE ServerName = ''' + @Server + ''' )'

--PRINT @SQLString1
EXEC( @SQLString1 )

--UPDATE dbo.Users SET SvrRights = 'Y'
--FROM dbo.ServerPermissions P JOIN dbo.Users u ON p.UserId = u.Id 
END

GO

