use dba
go
IF OBJECT_ID( 'dbo.usp_SetDaysForSchedule' ) IS NOT NULL
	DROP PROCEDURE dbo.usp_SetDaysForSchedule
GO
CREATE PROCEDURE dbo.usp_SetDaysForSchedule
AS
BEGIN
SET NOCOUNT ON
PRINT '    usp_SetDaysForSchedule'

DECLARE	
	@Id			int,
	@Day		varchar(150),
	@Freq		int

DECLARE CURS CURSOR FOR
	SELECT Id, [When] 
	FROM dbo.Schedules
	WHERE Freq = 'Weekly' and ISNUMERIC( [When] ) = 1

OPEN CURS
FETCH NEXT FROM CURS INTO @Id, @Day
WHILE @@FETCH_STATUS = 0
	begin
	SET @Freq = cast( @Day as int )
	SET @Day = ''

	IF ( @Freq & 1 = 1 )	SET @Day = @Day + 'Sun '
	IF ( @Freq & 2 = 2 )   	SET @Day = @Day + 'Mon '
	IF ( @Freq & 4 = 4 )   	SET @Day = @Day + 'Tue '
	IF ( @Freq & 8 = 8 )   	SET @Day = @Day + 'Wed '
	IF ( @Freq & 16 = 16 ) 	SET @Day = @Day + 'Thu '
	IF ( @Freq & 32 = 32 ) 	SET @Day = @Day + 'Fri '
	IF ( @Freq & 64 = 64 ) 	SET @Day = @Day + 'Sat'

	UPDATE dbo.Schedules SET [When] = @Day WHERE Id = @Id
	FETCH NEXT FROM CURS INTO @Id, @Day
	end
CLOSE CURS
DEALLOCATE CURS
END
go