
/*******************************************************************************************

		Runs DBCC SHOWCONTIG on all the tables.
		Also runs sp_updatestats and DBCC UPDATEUSAGE.
		
		This script will fail on a SQL Server 7.0 server because
		the ALL_INDEXES is not an option for SHOWCONTIG on
		that version.

		Author:  Irene Hill
		Revision Date:  12/20/04

		Input values than can be modified:  
		@MaxFrag:  		The maximum percent fragmentation that
						must exist in order to be considered for 
						defragmentation.  The default value for @MaxFrag
						is 10%, but it can be modified to any value.

		@PrintTable: 	A flag to indicate whether or not the contents
					 	of the #Fraglist table should be displayed.  This
					 	table holds the results of issuing a DBCC SHOWCONTIG
					 	for each of the tables in the database.  

	
************************************************************************************************/
SET NOCOUNT ON

-- DROP TABLE #FragList
CREATE TABLE #FragList
(	TableName		char( 255 ),
	TableId			int,
	IndexName		char( 255 ),
	IndexId			int,
	Lvl				int,
	CountPages		int,
	CountRows		int,
	MinRecSize		int,
	MaxRecSize		int,
	AvgRecSize		int,
	ForRecCount		int,
	Extents			int,
	ExtentSwitches	int,
	AvgFreeBytes	int,
	AvgPageDensity	decimal,
	ScanDensity		decimal,
	BestCount		int,
	ActualCount		int,
	LogicalFrag		decimal,
	ExtentFrag		decimal,
	Owner			sysname NULL
)

DELETE FROM DBA.dbo.SHOWCONTIG WHERE DBName = DB_NAME() 

DECLARE	
	@TableName		varchar( 50 ),
	@IndexName		varchar( 50 ),
	@IndexId		int,
	@Owner			sysname,
	@MaxFrag		decimal,
	@LogicalFrag	decimal,
	@ExtentFrag		decimal,
	@ScanDensity	decimal,
	@AvgPageDensity decimal,
	@PrintTable		char( 1 ),
	@Count			int,
	@IndexCount		int,
	@JobStart		datetime,
	@JobEnd			datetime

SET @MaxFrag	  = 10.0
SET @PrintTable	  = 'N'

DECLARE
	Tables CURSOR FOR
	SELECT 	TABLE_NAME, TABLE_SCHEMA
	FROM	INFORMATION_SCHEMA.TABLES
	WHERE	TABLE_TYPE = 'BASE TABLE' AND 
			TABLE_NAME <> 'dtproperties'
	ORDER BY TABLE_NAME	

SET @JobStart	  = GETDATE()
PRINT 'SHOWCONTIG JOB '
PRINT ' '
PRINT 'JOB START TIME:  ' + CAST( @JobStart as varchar )
PRINT 'DATABASE:  ' + DB_NAME()
PRINT ' '

-- Make sure that space info in sysindexes is correct
PRINT 'Executing:  DBCC UPDATEUSAGE (0) for all tables'
DBCC UPDATEUSAGE (0)
PRINT ' '

OPEN Tables
FETCH NEXT FROM Tables INTO @TableName, @Owner
SET @Count = 0

WHILE @@FETCH_STATUS = 0
	begin
	--  Run the DBCC SHOWCONTIG command to view
	--  fragmentation information about all the table's indexes.
	SET @Count = @Count + 1
	--PRINT 'DBCC SHOWCONTIG ( ''' + @Owner + '.[' + @TableName + 
	--			']'' ) WITH TABLERESULTS, ALL_INDEXES, NO_INFOMSGS' 
	INSERT INTO #FragList
		( TableName, TableId, IndexName, IndexId, Lvl, CountPages,
		  CountRows, MinRecSize, MaxRecSize, AvgRecSize, ForRecCount,
		  Extents, ExtentSwitches, AvgFreeBytes, AvgPageDensity,
		  ScanDensity, BestCount, ActualCount, LogicalFrag, ExtentFrag	
		)
		EXEC ( 'DBCC SHOWCONTIG ( ''' + @Owner + '.[' + @TableName + 
				']'' ) WITH TABLERESULTS, ALL_INDEXES, NO_INFOMSGS' )
	
	UPDATE #FragList SET Owner = @Owner WHERE Owner is NULL
	FETCH NEXT FROM Tables INTO @TableName, @Owner
	end
CLOSE Tables
DEALLOCATE Tables

PRINT ' '
PRINT 'TOTAL TABLES PROCESSED:  ' + CAST( @Count as varchar )

-- IndexId: 1 	= Clustered index,
--			>1 	= Heap,
--			255 = Entry for tables that have text or image data

DELETE FROM #FragList WHERE IndexId < 1 OR IndexId = 255
DELETE FROM #FragList WHERE IndexName LIKE '_WA%'

INSERT INTO DBA.dbo.SHOWCONTIG
(	
	Add_Date, DBName,TableName,TableId,IndexName,IndexId,Lvl,CountPages,
	CountRows,MinRecSize,MaxRecSize,AvgRecSize,ForRecCount,Extents,
	ExtentSwitches,AvgFreeBytes,AvgPageDensity,ScanDensity,BestCount,
	ActualCount,LogicalFrag,ExtentFrag,Owner	
)
	SELECT 
		GETDATE(),DB_NAME(),TableName,TableId,IndexName,IndexId,Lvl,CountPages,
		CountRows,MinRecSize,MaxRecSize,AvgRecSize,ForRecCount,Extents,
		ExtentSwitches,AvgFreeBytes,AvgPageDensity,ScanDensity,BestCount,
		ActualCount,LogicalFrag,ExtentFrag,Owner
	FROM #FragList

-- SELECT * FROM DBA.DBO.SHOWCONTIG
-- Just print the index info for those indexes that exceed the threshold

DECLARE
	Indexes CURSOR FOR
	SELECT RTRIM( TableName ), Owner, 
		   RTRIM( IndexName ), IndexId, 
		   LogicalFrag, ExtentFrag, 
		   ScanDensity, AvgPageDensity
	FROM #FragList
	WHERE 
		-- Logical fragmentation is only relevant to the clustered index 
		( IndexId = 1 and ISNULL( LogicalFrag, 0 ) > @MaxFrag ) 
		OR
		   ISNULL( ExtentFrag, 0 ) > @MaxFrag 
		OR
		(  ISNULL( ScanDensity, 0 ) <> 100 AND
		   ISNULL( ScanDensity, 0 ) < 100 - @MaxFrag ) 
		--OR
		--(  ISNULL( AvgPageDensity, 0 ) <> 100 AND
		--   ISNULL( AvgPageDensity, 0 ) < 100 - @MaxFrag )
	ORDER BY RTRIM( TableName ), IndexName, Owner

SET @IndexCount = 0
OPEN Indexes
FETCH NEXT FROM Indexes 
	INTO @TableName, @Owner, @IndexName, @IndexId,
		 @LogicalFrag, @ExtentFrag, @ScanDensity, @AvgPageDensity
WHILE @@FETCH_STATUS = 0
	begin
	PRINT ' '
	SET @IndexCount = @IndexCount + 1
	IF @IndexId = 1 
		begin
		PRINT @TableName + ', ' + @IndexName + ', ' +
		  	CAST( @IndexId as varchar ) + ' - Logical fragmentation ' + 
		  	RTRIM( CONVERT( varchar( 15 ), @LogicalFrag )) + '%'
		end

	PRINT @TableName + ', ' + @IndexName + ', ' +
		  CAST( @IndexId as varchar ) + ' - Extent fragmentation ' + 
		  RTRIM( CONVERT( varchar( 15 ), @ExtentFrag )) + '%'

	PRINT @TableName + ', ' + @IndexName + ', ' +
		  CAST( @IndexId as varchar ) + ' - Scan density ' + 
		  RTRIM( CONVERT( varchar( 15 ), @ScanDensity )) + '%'

	PRINT @TableName + ', ' + @IndexName + ', ' +
		  CAST( @IndexId as varchar ) + ' - Avg Page density ' + 
		  RTRIM( CONVERT( varchar( 15 ), @AvgPageDensity )) + '%'

	FETCH NEXT FROM Indexes 
		INTO @TableName, @Owner, @IndexName, @IndexId,
			 @LogicalFrag, @ExtentFrag, @ScanDensity, @AvgPageDensity
	end
CLOSE Indexes
DEALLOCATE Indexes
PRINT ' '
PRINT '***********************************************************************'
PRINT ' '

PRINT 'Run sp_updatestats'
exec sp_updatestats 

IF @PrintTable = 'Y'
	SELECT * FROM #FragList
	ORDER BY TableName, IndexId

DROP TABLE #FragList

SET @JobEnd = GETDATE()
PRINT 'JOB END TIME:  ' + CAST( @JobEnd as varchar )
IF DATEDIFF( mi, @JobStart, @JobEnd ) < 60
	PRINT 'JOB DURATION:  ' + 
		CAST( DATEDIFF( mi, @JobStart, @JobEnd ) as varchar ) + ' minutes'
ELSE
	PRINT 'JOB DURATION:  ' + 
	CAST( ( DATEDIFF( mi, @JobStart, @JobEnd )/60 ) as varchar ) + ' hrs ' +
	CAST( ( DATEDIFF( mi, @JobStart, @JobEnd )%60 ) as varchar ) + ' minutes'
go

