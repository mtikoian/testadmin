USE DBA
GO
IF OBJECT_ID( 'dbo.usp_ServerPermissions' ) IS NOT NULL
	DROP PROCEDURE dbo.usp_ServerPermissions
GO
CREATE PROCEDURE dbo.usp_ServerPermissions
	@Server varchar(60) = @@ServerName
AS
BEGIN
SET NOCOUNT ON
PRINT '    usp_ServerPermissions ' + @Server

DECLARE @SqlCmd varchar( 3000 )

SET @SqlCmd = '
INSERT INTO dbo.ServerPermissions
( ServerName,Login,Sys,Security,Server,Setup,Process,[Disk],DBCreator )
SELECT ''' + @Server + ''' , name, 
	CASE sysadmin 		WHEN 1 THEN ''Y'' ELSE ''N'' END,
	CASE securityadmin 	WHEN 1 THEN ''Y'' ELSE ''N'' END,
	CASE serveradmin 	WHEN 1 THEN ''Y'' ELSE ''N'' END,
	CASE setupadmin 	WHEN 1 THEN ''Y'' ELSE ''N'' END,
	CASE processadmin 	WHEN 1 THEN ''Y'' ELSE ''N'' END,
	CASE diskadmin 		WHEN 1 THEN ''Y'' ELSE ''N'' END,
	CASE dbcreator 		WHEN 1 THEN ''Y'' ELSE ''N'' END
FROM [' + @Server + '].master.dbo.syslogins
WHERE 
	name IS NOT NULL AND 
	name NOT IN( ''BUILTIN\Administrators'', ''sa'' ) AND
      ( sysadmin 	<> 0 OR
	securityadmin 	<> 0 OR
	serveradmin 	<> 0 OR
	setupadmin 	<> 0 OR
	processadmin 	<> 0 OR
	diskadmin 	<> 0 OR
	dbcreator 	<> 0 )'

--PRINT @SqlCmd
EXEC( @SqlCmd )
END
GO

