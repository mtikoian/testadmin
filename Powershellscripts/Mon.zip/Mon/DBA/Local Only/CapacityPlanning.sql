/*************************************************

				Capacity Planning

**************************************************/
USE DBA
GO 
CREATE TABLE dbo.All_Free_Space 
(
	ServerName 		varchar (60) NOT NULL ,
	Drive 			varchar (40) NOT NULL ,
	Date_Collected 	datetime NOT NULL ,
	Freespace 		decimal(9, 2) NULL ,
	Space In MB 	varchar (15) NULL ,
	DB				bit	NULL DEFAULT 0
	CONSTRAINT PK_All_Free_Space PRIMARY KEY  CLUSTERED 
	(
		ServerName,
		Drive,
		Date_Collected
	),
	CONSTRAINT FK_All_Free_Space_Servers FOREIGN KEY 
	(
		ServerName
	) REFERENCES dbo.Servers (
		ServerName
	) ON DELETE CASCADE  ON UPDATE CASCADE 
)
GO


/*************************************************

			Create Stats Tables

**************************************************/

IF OBJECT_ID( 'dbo.All_DBSTATS' ) IS NOT NULL
	DROP TABLE dbo.All_DBSTATS
GO
CREATE TABLE dbo.All_DBSTATS
(	StatsId			int 			NOT NULL IDENTITY( 1, 1 ),
	DBId			int				NOT NULL,
	Sample_Date		datetime		NOT NULL,
	Data_Size		decimal( 9, 2 ) NULL,	
	Data_Used		decimal( 9, 2 )	NULL,
	Percent_Data	INT				NULL,
	Log_Size		decimal( 9, 2 ) NULL,
	Log_Used		decimal( 9, 2 )	NULL,
	Percent_Log		INT 			NULL,
	TotalSize		decimal( 10, 2 ) NULL,
	TotalUsed		decimal( 10, 2 ) NULL
)
CREATE UNIQUE CLUSTERED INDEX IX_All_DBSTATS_DB_Sample ON
dbo.All_DBSTATS( DBId, Sample_Date )
GO
ALTER TABLE All_DBSTATS ADD CONSTRAINT PK_All_DBSTATS PRIMARY KEY( StatsId )
GO
IF OBJECT_ID( 'dbo.MONTHS' ) IS NOT NULL
	DROP TABLE dbo.MONTHS
GO
CREATE TABLE dbo.MONTHS
(	MonthId			int identity( 1, 1 ) not null,
	DBId			int,
	Sample_Year		int,
	Sample_Month	int,
	DataUsed		int,
	Diff			int,
	PctIncr			decimal( 12, 2 )
)
GO
IF OBJECT_ID( 'Stats_Summary' ) IS NOT NULL
	DROP TABLE dbo.Stats_Summary
GO
CREATE TABLE dbo.Stats_Summary
(
	DBId				int,
	StartDate			datetime,
	EndDate			    datetime,
	Months				integer,
	MinUsed				integer,
	MaxUsed				integer,
	SizeDiff			integer,
	PctIncr				decimal( 12, 2 ),
	PctPerMo			decimal( 12, 2 ),
	SizeIn1				numeric,
	SizeIn2				numeric,
	SizeIn3				numeric,
	SizeIn4				numeric,
	SizeIn5				numeric,
	SizeIn6				numeric,
	SizeIn7				numeric,
	SizeIn8				numeric,
	SizeIn9				numeric,
	SizeIn10			numeric,
	SizeIn11			numeric,
	SizeIn12			numeric,
	AvgLogSize			integer
)
GO

-- SELECT * FROM ALL_DATABASES ORDER BY SERVERNAME, DBNAME

/*************************************************

			Collect database sizes

**************************************************/

DECLARE
	SERVERS_CUR CURSOR FOR 
	SELECT ServerName FROM dbo.SERVERS

DECLARE 
	@SQLSTMT	varchar( 2000 ),
	@ServerName	varchar( 80 )

OPEN SERVERS_CUR
FETCH NEXT FROM SERVERS_CUR INTO @ServerName
WHILE ( @@FETCH_STATUS = 0 )
	begin
	-- A server's DBSTATS table may also have history from another server
    -- if a database was moved over from another server
	SET @SQLSTMT = 
	'INSERT INTO All_DBSTATS( DBId, Data_Size, Data_Used, Log_Size, Log_Used, Sample_Date )'
	SET @SQLSTMT = @SQLSTMT + 
	'SELECT DBId, Data_Size, Data_Used, Log_Size,Log_Used, State_Date '
	SET @SQLSTMT = @SQLSTMT +
	'FROM [' + @ServerName + '].dba.dbo.DBStats s JOIN dbo.ALL_DATABASES d ON '
	SET @SQLSTMT = @SQLSTMT + 
	'd.ServerName = ''' + @ServerName + ''' AND RTRIM( s.DBName ) = d.DBName ' 
	PRINT @SQLSTMT
	EXEC( @SQLSTMT )
	FETCH NEXT FROM SERVERS_CUR INTO @ServerName
	end
CLOSE SERVERS_CUR
DEALLOCATE SERVERS_CUR

/**********************************************************

		Calculate totals and percentages

***********************************************************/
DELETE FROM dbo.ALL_DBSTATS 
WHERE ISNULL( Data_Used, 0 ) <= 1.00 and DBId in
	( SELECT distinct DBId FROM dbo.All_DBstats 
                WHERE ISNULL( Data_Used, 0 ) > 1.00 )
go
UPDATE ALL_DBSTATS SET Log_Size  = 1 WHERE ISNULL( Log_Size, 0 )  = 0 
UPDATE ALL_DBSTATS SET Log_Used  = 0 WHERE Log_Used  IS NULL
go

UPDATE All_DBSTATS 
SET TotalSize  		= Data_Size + Log_Size,
	TotalUsed  		= Data_Used + Log_Used,
	Percent_Data 	= ( CEILING( Data_Used ) / CEILING( Data_Size ) ) * 100,
	Percent_Log  	= 
		CASE
			WHEN Log_Used = 0 THEN 0
			WHEN Log_Size = 0 THEN 0
			ELSE ( CEILING( Log_Used ) / CEILING( Log_Size )) * 100
		END
GO
-- Check size details of databases
SELECT 
	ServerName,
	DBName,
	DBType, 
	Sample_Date,
	Data_Size, 
	Data_Used, 
	Percent_Data, 
	Log_Size, 
	Log_Used, 
	Percent_Log,
	TotalSize, 
	TotalUsed
FROM All_DBSTATS s JOIN ALL_DATABASES d ON s.DBId = d.DBId
WHERE DBType = 'P' and DBName = 'mktweb_internal'
ORDER BY DBType, Servername, DBName, Sample_Date
go
-- Get maximum size of each database
SELECT 
	ServerName, 
	DBName, 
	Type_Flag,
	max( TotalSize ) as MaxSize
FROM All_DBSTATS s JOIN ALL_DATABASES d ON s.DBId = d.DBId
GROUP BY Servername, DBNAme, DBType
ORDER BY DBType, Servername, DBName
go
-- Check that production and dev/test databases are correctly marked
SELECT 
	ServerName, 
	DBName, 
	DBType,
	max( TotalSize ) as MaxSize
FROM All_DBSTATS s JOIN ALL_DATABASES d ON s.DBId = d.DBId
WHERE DBType <> 'S'
GROUP BY Servername, DBNAme, DBType
ORDER BY DBName, DBType
go

/**********************************************************

 		Do size projections for Production databases.

**********************************************************/

SELECT 
	ServerName,
	DBName,
	CONVERT( varchar, Sample_Date, 101 ) as SampleDate, 
	CEILING( Data_Size )	as DataSize,
	CEILING( Data_Used ) 	as DataUsed,
	Percent_Data 			as PctData,
	CEILING( Log_Size ) 	as LogSize,
	CEILING( Log_Used ) 	as LogUsed,
	Percent_Log 			as PctLog,
	CEILING( TotalSize ) 	as TotalSize,
	CEILING( TotalUsed ) 	as TotalUsed
FROM All_DBSTATS s JOIN ALL_DATABASES d ON s.DBId = d.DBId
WHERE DBNAME = 'KRONOSDATA'
ORDER BY ServerName, DBName, Sample_Date

-- Sample for removing entries for a database that hadn't been loaded yet
DELETE FROM [2ksqlprod2].DBA.dbo.DBSTATS 
WHERE DBNAME = 'TJXVENDORS' AND
	  State_Date < '05/08/2004'


-- Get summary info for production databases
INSERT INTO dbo.Stats_Summary
( 	DBId,
	StartDate, 
	EndDate, 
	Months, 
	AvgLogSize, 
	MaxUsed, 
	MinUsed, 
  	SizeDiff, 
	PctIncr
)
SELECT 
	s.DBId,
	CONVERT( varchar, MIN( Sample_Date ), 101 ) 		AS StartDate,
	CONVERT( varchar, MAX( Sample_Date ), 101 ) 		AS EndDate,
	DATEDIFF( m, MIN( Sample_Date ), MAX( Sample_Date ) ) AS Months,
	CEILING( AVG( Log_Used ) ) 							AS AvgLogSize,
	MAX( Data_Used ) 									AS MaxDataUsed,
	MIN( Data_Used ) 									AS MinDataUsed, 
	MAX( Data_Used ) - MIN( Data_Used ) 				AS DiffDataUsed, 
	ROUND( ( ( CAST( ROUND( ( ( MAX( Data_Used ) - MIN( Data_Used ) ) / 
		MIN( Data_Used ) ), 2 ) AS decimal( 8, 2 ) ) ) * 100 ), 2 ) AS IncrAmt
FROM 
	All_DBSTATS s JOIN ALL_DATABASES d ON s.DBId = d.DBId
WHERE 
	DBType = 'P' AND Data_Used <> 0 
	-- throw out the first week's data to allow for ramp-up
	AND Sample_Date NOT IN 
		( SELECT MIN( Sample_Date ) FROM ALL_DBSTATS WHERE DBId = s.DBId )
GROUP BY s.DBId
GO

UPDATE dbo.Stats_Summary
SET PctIncr = 0, PctPerMo = 0
WHERE Months = 0

select * from all_databases order by dbid

UPDATE dbo.Stats_Summary
SET SizeIn1 = MaxUsed,
	SizeIn2 = MaxUsed,
	SizeIn3 = MaxUsed,
	SizeIn4 = MaxUsed,
	SizeIn5 = MaxUsed,
	SizeIn6 = MaxUsed,
	SizeIn7 = MaxUsed,
	SizeIn8 = MaxUsed,
	SizeIn9 = MaxUsed,
	SizeIn10 = MaxUsed,
	SizeIn11 = MaxUsed,
	SizeIn12 = MaxUsed
WHERE PctPerMo = 0
GO
SELECT d.dbname,s.* 
FROM dbo.Stats_Summary s 
	join ALL_DATABASES d ON  d.dbid = s.dbid
ORDER BY DBNAME

/******************************************************

		Calculate sizes per month.
		The data in Stats_Summary is by week.

*******************************************************/


INSERT INTO dbo.MONTHS( DBId, Sample_Year, Sample_Month, DataUsed )
SELECT 
	s.DBId,
	DATEPART( year, Sample_Date ), 
	DATEPART( month, Sample_Date ), 
	MAX( CEILING( Data_Used ) ) 
FROM dbo.ALL_DBSTATS a 
	JOIN dbo.Stats_Summary s ON a.DBId = s.DBId 
	JOIN dbo.ALL_DATABASES d On a.DBId = d.DBId
GROUP BY 
	s.DBId,
	DATEPART( year, Sample_Date ), DATEPART( month, Sample_Date )
ORDER BY 
	s.DBId,
	DATEPART( year, Sample_Date ), DATEPART( month, Sample_Date )
GO

-- Calculate difference between given month and previous month
UPDATE dbo.MONTHS
SET Diff = DataUsed - 
	( SELECT DataUsed FROM MONTHS WHERE MonthId = m.MonthId - 1 AND DBId = m.DBId )
FROM MONTHS m JOIN ALL_DATABASES d ON m.DBId = d.DBId
WHERE MonthId <> ( SELECT MIN( MonthId ) FROM MONTHS WHERE DBId = m.DBId )

-- Calculate percent increase per month
UPDATE dbo.MONTHS
SET PctIncr = ROUND( ( CAST( ISNULL( Diff, 0 ) AS numeric ) / 
						( SELECT CAST( DataUsed as numeric ) 
			  			  FROM MONTHS 
			  			  WHERE MonthId = m.MonthId - 1 ) ), 2 ) * 100
FROM dbo.MONTHS m
WHERE  ( SELECT DataUsed FROM MONTHS WHERE MonthId = m.MonthId - 1 ) > 0
GO

UPDATE dbo.MONTHS SET PctIncr = 0 WHERE MonthId = 1
GO

/*****************************************

SELECT d.Servername, d.dbname, m.* 
FROM dbo.MONTHS m 
	JOIN All_Databases d ON m.dbid = d.dbid
ORDER BY m.DBId, m.MonthId

SELECT d.dbname, s.*
FROM DBO.STATS_SUMMARY s join all_databases d
	on s.dbid = d.dbid
order by d.dbname

******************************************/


/******************************************
	
	Get average pct increase per month

*******************************************/

UPDATE dbo.Stats_Summary
SET PctPerMo = 
	CASE WHEN ISNULL( PctIncr, 0 ) < 1 THEN 0 
		 ELSE ( SELECT ROUND( AVG( ISNULL( PctIncr, 0 ) ), 2 ) FROM MONTHS
				WHERE DBId = s.DBId   )
	END
FROM dbo.Stats_Summary s
go

-- SELECT * FROM dbo.Stats_Summary

-- Calculate the projected sizes for each month using average pct increase per month
UPDATE dbo.Stats_Summary 
SET SizeIn1  = CASE WHEN PctIncr < 1 THEN MaxUsed
				    ELSE MaxUsed  + ( MaxUsed * ( PctPerMo/100 ) ) 
			   END 

UPDATE dbo.Stats_Summary 
SET SizeIn2  = CASE WHEN PctIncr < 1 THEN MaxUsed
					ELSE SizeIn1  + ( SizeIn1 * ( PctPerMo/100 ) )  
			   END

UPDATE dbo.Stats_Summary 
SET SizeIn3  = CASE WHEN PctIncr < 1 THEN MaxUsed
					ELSE SizeIn2  + ( SizeIn2 * ( PctPerMo/100 ) )  
			   END

UPDATE dbo.Stats_Summary 
SET SizeIn4  = CASE WHEN PctIncr < 1 THEN MaxUsed
					ELSE SizeIn3  + ( SizeIn3 * ( PctPerMo/100 ) )  
			   END

UPDATE dbo.Stats_Summary 
SET SizeIn5  = CASE WHEN PctIncr < 1 THEN MaxUsed
					ELSE SizeIn4  + ( SizeIn4 * ( PctPerMo/100 ) )  
			   END

UPDATE dbo.Stats_Summary 
SET SizeIn6  = CASE WHEN PctIncr < 1 THEN MaxUsed
					ELSE SizeIn5  + ( SizeIn5 * ( PctPerMo/100 ) )  
			   END

UPDATE dbo.Stats_Summary 
SET SizeIn7  = 	CASE WHEN PctIncr < 1 THEN MaxUsed
					 ELSE SizeIn6  + ( SizeIn6 * ( PctPerMo/100 ) )  
				END

UPDATE dbo.Stats_Summary 
SET SizeIn8  = 	CASE WHEN PctIncr < 1 THEN MaxUsed
					 ELSE SizeIn7  + ( SizeIn7 * ( PctPerMo/100 ) )  
				END

UPDATE dbo.Stats_Summary 
SET SizeIn9  = 	CASE WHEN PctIncr < 1 THEN MaxUsed
					 ELSE SizeIn8  + ( SizeIn8 * ( PctPerMo/100 ) )  
				END

UPDATE dbo.Stats_Summary 
SET SizeIn10 = 	CASE WHEN PctIncr < 1 THEN MaxUsed
					 ELSE SizeIn9  + ( SizeIn9 * ( PctPerMo/100 ) )  
				END

UPDATE dbo.Stats_Summary 
SET SizeIn11 = 	CASE WHEN PctIncr < 1 THEN MaxUsed
					 ELSE SizeIn10 + ( SizeIn10 * ( PctPerMo/100 ) )  
				END

UPDATE dbo.Stats_Summary 
SET SizeIn12 = 	CASE WHEN PctIncr < 1 THEN MaxUsed
					 ELSE SizeIn11 + ( SizeIn11 * ( PctPerMo/100 ) )  
				END
GO


-- See if there is any skewing of percentages because there was a data load
SELECT
	ServerName, 
	DBName, 
	CONVERT( varchar, StartDate, 101 ) as StartDate,
	CONVERT( varchar, EndDate, 101 ) as EndDate,
	Months,
	AvgLogSize 	as Log,
	MinUsed 	as MinData,
	MaxUsed 	as MaxData,
	SizeDiff	as Diff,
	PctIncr		as PctIncr,
	PctPerMo	as [PctIncr/Mo],
	SizeIn1		as [Month 1],
	SizeIn2		as [Month 2],
	SizeIn3		as [Month 3],
	SizeIn4		as [Month 4],
	SizeIn5		as [Month 5],
	SizeIn6		as [Month 6],
	SizeIn7		as [Month 7],
	SizeIn8		as [Month 8],
	SizeIn9		as [Month 9],
	SizeIn10	as [Month 10],
	SizeIn11	as [Month 11],
	SizeIn12	as [Month 12]
FROM dbo.Stats_Summary s JOIN dbo.ALL_DATABASES d ON s.DBId = d.DBId
WHERE PctPerMo > 25
ORDER BY ServerName, DBName


SELECT 
	ServerName, 
	DBName, 
	DBType, 
	CONVERT( varchar, Sample_Date, 101 ) as Dated,
	Data_Size, 
	Data_Used, 
	Percent_Data, 
	Log_Size, 
	Log_Used, 
	Percent_Log,
	TotalSize, 
	TotalUsed
FROM All_DBSTATS s JOIN ALL_DATABASES d ON s.DBId = d.DBId
WHERE 
	DBType = 'P' and 
	DBName IN( 'TJX_ARTEMIS', 'TJXVendors' )
ORDER BY DBType, Servername, DBName, Dated

/*****************************************************

			Show Results

******************************************************/


SELECT ServerName, DBName, Sample_Year as Year,
	Sample_Month as Month, DataUsed, Diff, PctIncr
FROM dbo.Months m JOIN dbo.ALL_DATABASES d
	ON m.DBId = d.DBId
where dbname = 'tjxvendors'
ORDER BY ServerName, DBName, Sample_Year, cast( Sample_Month as int )


SELECT
	ServerName, 
	DBName, 
	CONVERT( varchar, StartDate, 101 ) as StartDate,
	Months,
	AvgLogSize 	as AvgLog,
	MinUsed 	as MinData,
	MaxUsed 	as MaxData,
	SizeDiff	as Diff,
	PctIncr		as PctIncr,
	PctPerMo	as [PctIncr/Mo],
	SizeIn1		as [Month 1],
	SizeIn2		as [Month 2],
	SizeIn3		as [Month 3],
	SizeIn4		as [Month 4],
	SizeIn5		as [Month 5],
	SizeIn6		as [Month 6],
	SizeIn7		as [Month 7],
	SizeIn8		as [Month 8],
	SizeIn9		as [Month 9],
	SizeIn10	as [Month 10],
	SizeIn11	as [Month 11],
	SizeIn12	as [Month 12]
FROM dbo.Stats_Summary s JOIN dbo.ALL_DATABASES d ON s.DBId = d.DBId
ORDER BY ServerName, DBName
