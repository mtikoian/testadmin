use DBA
go

IF OBJECT_ID( 'dbo.usp_ExportGrants' ) IS NOT NULL
	DROP PROCEDURE dbo.usp_ExportGrants
go
CREATE PROCEDURE dbo.usp_ExportGrants
	@Server		varchar(60) = @@Servername,
	@DB		varchar(60) = NULL
AS
BEGIN
SET NOCOUNT ON

DECLARE @rtn	int

CREATE TABLE #TEMP
(
	job_id uniqueidentifier ,
	job_name sysname ,
	run_status int ,
	run_date int ,
	run_time int ,
	run_duration int ,
	operator_emailed nvarchar(20) ,
	operator_netsent nvarchar(20), 
	operator_paged nvarchar(20) ,
	retries_attempted int ,
	server nvarchar(30) 
)

SET @rtn = 0

IF OBJECT_ID( 'dbo.ExportGrants' ) IS NOT NULL
	DROP TABLE dbo.ExportGrants

IF @Server = '*ALL' 
	SELECT d.ServerName, d.DBName, 
		ObjectName, ObjectType, Owner, GranteeName, GrantType, Permission
	INTO dbo.ExportGrants
	FROM dbo.Grants u JOIN dbo.Databases d on d.DBId = u.DBId

ELSE IF ISNULL( @DB, '' ) <> '' AND isnull(@DB, '') <> '*'
	SELECT d.ServerName, d.DBName, 
		ObjectName, ObjectType, Owner, GranteeName, GrantType, Permission
	INTO dbo.ExportGrants
	FROM dbo.Grants u JOIN dbo.Databases d on d.DBId = u.DBId
	WHERE d.ServerName = @Server and d.DBName = @DB
ELSE
	SELECT d.ServerName, d.DBName, 
		ObjectName, ObjectType, Owner, GranteeName, GrantType, Permission
	INTO dbo.ExportGrants
	FROM dbo.Grants u JOIN dbo.Databases d on d.DBId = u.DBId
	WHERE d.ServerName = @Server

exec msdb.dbo.sp_start_job 'DailyCheck - Export Grants'
WAITFOR DELAY '000:00:05' -- Give the job a chance to complete
INSERT INTO #TEMP EXEC msdb.dbo.sp_help_jobhistory @job_name = 'DailyCheck - Export Grants'

WHILE @@ROWCOUNT = 0
  BEGIN
  WAITFOR DELAY '000:00:05' -- Give the job a chance to complete
  INSERT INTO #TEMP EXEC msdb.dbo.sp_help_jobhistory @job_name = 'DailyCheck - Export Grants'
  END

SELECT @rtn = max(run_status) FROM #TEMP
IF @rtn <> 1 SET @rtn = -1
RETURN @rtn
END
GO