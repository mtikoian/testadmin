USE DBA
GO
IF OBJECT_ID( 'dbo.usp_AllDBAttributes' ) IS NOT NULL
	DROP PROCEDURE dbo.usp_AllDBAttributes
go
CREATE PROCEDURE dbo.usp_AllDBAttributes
		@Server		varchar(60)
as
BEGIN
SET NOCOUNT ON
DECLARE @SQL 	varchar( 1000 )

PRINT 'usp_AllDBAtributes - ' + @Server

SET @SQL = 'UPDATE dbo.Databases SET RecoveryModel = x.RecoveryModel 
	FROM dbo.Databases d JOIN [' + @Server + '].DBA.dbo.DBAttributes x
    ON d.Servername = ''' + @Server + ''' and d.DBName = x.DBName'
--PRINT @SQL
EXEC( @SQL )
END
GO