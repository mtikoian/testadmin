use DBA
go
IF OBJECT_ID('dbo.udf_GetWeeklyDays') IS NOT NULL
	DROP FUNCTION dbo.udf_GetWeeklyDays
GO

CREATE FUNCTION dbo.udf_GetWeeklyDays( @Freq int )
RETURNS varchar(150)
AS
BEGIN

DECLARE @Days varchar(150)
SET @Days = ''

IF ( @Freq & 1 = 1 )	SET @Days = @Days + 'Sun '
IF ( @Freq & 2 = 2 )   	SET @Days = @Days + 'Mon '
IF ( @Freq & 4 = 4 )   	SET @Days = @Days + 'Tue '
IF ( @Freq & 8 = 8 )   	SET @Days = @Days + 'Wed '
IF ( @Freq & 16 = 16 ) 	SET @Days = @Days + 'Thu '
IF ( @Freq & 32 = 32 ) 	SET @Days = @Days + 'Fri '
IF ( @Freq & 64 = 64 ) 	SET @Days = @Days + 'Sat'
RETURN @Days
END
GO

