use DBA
go

IF OBJECT_ID( '[dbo].[usp_SaveServerFreespace]') IS NOT NULL
	drop procedure [dbo].[usp_SaveServerFreespace]
GO
CREATE PROCEDURE dbo.usp_SaveServerFreespace
		@Server		varchar( 50 ) = @@Servername

/*************************************************************

		Writes disk space data from the server whose name
		is passed in to the DB_FreeSpace_Stats
	    table in the DBA database on the local server.

		Sample:  exec usp_SaveServerFreespace '2KSQLPROD2'

**************************************************************/
AS
BEGIN
SET NOCOUNT ON
PRINT '    usp_SaveServerFreespace - ' + @Server

DECLARE
	@SQLStmt		varchar ( 500 )

SET @SQLStmt = 
	'INSERT INTO dbo.All_Free_Space( ServerName, Drive, Freespace, Date_Collected, DB, [Space in MB] )
	 SELECT a.ServerName, a.Drive, CAST( a.FreeSpace as decimal( 9, 2 ) ), a.State_Date, DB, dbo.udf_InsertCommas(cast( a.Freespace as int )) 
	 FROM [' + @Server + '].DBA.dbo.DB_Freespace_Stats a
	 WHERE State_Date NOT IN 
	( SELECT Date_Collected FROM dbo.All_Free_Space WHERE ServerName = a.ServerName )'

--PRINT @SQLStmt
EXEC( @SQLStmt )
END
GO


