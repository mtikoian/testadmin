IF OBJECT_ID( 'dbo.usp_GetTodaysZipFileName' ) IS NOT NULL
	DROP PROCEDURE dbo.usp_GetTodaysZipFileName
go

CREATE PROCEDURE dbo.usp_GetTodaysZipFileName
	@FileName	varchar(50)
as
BEGIN
SET NOCOUNT ON
DECLARE 
	@DateStr varchar(10),
	@Today	 varchar(10),
	@ZipName varchar(121)

SET @Today = CONVERT( varchar(10), getdate(), 101 )
SET @DateStr = 	RIGHT( @Today, 4 ) + '-' + 
				LEFT( @Today, 2 )  + '-' + 
				SUBSTRING( @Today, 4, 2 )
SET @ZipName = @FileName + '_' + @DateStr + '.zip'
SELECT @ZipName
END
GO


