if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_All_DBStats_Databases]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[All_DBStats] DROP CONSTRAINT FK_All_DBStats_Databases
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_Database_Files_Databases]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[Database_Files] DROP CONSTRAINT FK_Database_Files_Databases
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_Grants_Databases]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[Grants] DROP CONSTRAINT FK_Grants_Databases
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_MaintenancePlans_Databases]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[MaintenancePlans] DROP CONSTRAINT FK_MaintenancePlans_Databases
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_Months_Databases]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[Months] DROP CONSTRAINT FK_Months_Databases
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_Stats_Summary_Databases]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[Stats_Summary] DROP CONSTRAINT FK_Stats_Summary_Databases
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_Users_Databases]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[Users] DROP CONSTRAINT FK_Users_Databases
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_PackageSteps_Packages]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[PackageSteps] DROP CONSTRAINT FK_PackageSteps_Packages
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_All_Free_Space_Servers]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[All_Free_Space] DROP CONSTRAINT FK_All_Free_Space_Servers
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_BlankLogins_Servers]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[BlankLogins] DROP CONSTRAINT FK_BlankLogins_Servers
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_Jobs_Servers]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[Jobs] DROP CONSTRAINT FK_Jobs_Servers
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_Packages_Servers]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[Packages] DROP CONSTRAINT FK_Packages_Servers
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_ServerConfigurations_Servers]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[ServerConfigurations] DROP CONSTRAINT FK_ServerConfigurations_Servers
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_User_Activity_Servers]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[User_Activity] DROP CONSTRAINT FK_User_Activity_Servers
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_Users_Servers]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[Users] DROP CONSTRAINT FK_Users_Servers
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_User_Locks_User_Activity]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[User_Locks] DROP CONSTRAINT FK_User_Locks_User_Activity
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_ServerPermissions_Users]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[ServerPermissions] DROP CONSTRAINT FK_ServerPermissions_Users
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AdjustedUsers]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[AdjustedUsers]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Agent_Jobs]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[Agent_Jobs]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[All_DBStats]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[All_DBStats]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[All_Free_Space]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[All_Free_Space]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Applications_Supported]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[Applications_Supported]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Applications_Supported_Save]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[Applications_Supported_Save]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[BlankLogins]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[BlankLogins]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DBA_Log]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[DBA_Log]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DBAttributes]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[DBAttributes]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DBSTATS]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[DBSTATS]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DB_FREESPACE_STATS]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[DB_FREESPACE_STATS]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Database_Files]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[Database_Files]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Databases]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[Databases]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ExportApps]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[ExportApps]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ExportAuditPermissions]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[ExportAuditPermissions]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ExportBlankLogins]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[ExportBlankLogins]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ExportGrants]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[ExportGrants]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ExportJobs]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[ExportJobs]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ExportPermissions]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[ExportPermissions]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ExportSchedules]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[ExportSchedules]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ExportUsers]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[ExportUsers]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Grants]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[Grants]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Jobs]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[Jobs]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[LitespeedInfo]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[LitespeedInfo]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[MaintenancePlans]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[MaintenancePlans]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Months]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[Months]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[PackageSteps]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[PackageSteps]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Packages]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[Packages]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RunningJobs]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[RunningJobs]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Schedules]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[Schedules]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ServerConfigs]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[ServerConfigs]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ServerConfigurations]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[ServerConfigurations]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ServerInfo]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[ServerInfo]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ServerPermissions]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[ServerPermissions]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Servers]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[Servers]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Servers_Save]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[Servers_Save]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Showcontig]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[Showcontig]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Showcontig_All]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[Showcontig_All]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Stats_Summary]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[Stats_Summary]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[TEMP_MONTHS]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[TEMP_MONTHS]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Table_Counts]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[Table_Counts]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[TempUsers]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[TempUsers]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[User_Activity]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[User_Activity]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[User_Activity_Loc]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[User_Activity_Loc]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[User_Locks]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[User_Locks]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[User_Locks_Loc]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[User_Locks_Loc]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Users]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[Users]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[tmp_sfs]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[tmp_sfs]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[tmp_stats]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[tmp_stats]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[tmplg]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[tmplg]
GO

CREATE TABLE [dbo].[AdjustedUsers] (
	[Id] [int] IDENTITY (1, 1) NOT NULL ,
	[ServerName] [varchar] (60) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[DBName] [varchar] (120) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Owner] [varchar] (60) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[TableName] [varchar] (60) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Filter] [varchar] (300) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Processed] [bit] NULL ,
	[UserColumn] [varchar] (150) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[CreateDateColumn] [varchar] (60) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[LastLoginColumn] [varchar] (60) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Login] [varchar] (60) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[Agent_Jobs] (
	[job_id] [uniqueidentifier] NOT NULL ,
	[last_run_date] [int] NOT NULL ,
	[last_run_time] [int] NOT NULL ,
	[next_run_date] [int] NOT NULL ,
	[next_run_time] [int] NOT NULL ,
	[next_run_schedule_id] [int] NOT NULL ,
	[requested_to_run] [int] NOT NULL ,
	[request_source] [int] NOT NULL ,
	[request_source_id] [sysname] NULL ,
	[running] [int] NOT NULL ,
	[current_step] [int] NOT NULL ,
	[current_retry_attempt] [int] NOT NULL ,
	[job_state] [int] NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[All_DBStats] (
	[StatsId] [int] IDENTITY (1, 1) NOT NULL ,
	[DBId] [int] NOT NULL ,
	[Sample_Date] [datetime] NOT NULL ,
	[Data_Size] [decimal](9, 2) NULL ,
	[Data_Used] [decimal](9, 2) NULL ,
	[Percent_Data] [int] NULL ,
	[Log_Size] [decimal](9, 2) NULL ,
	[Log_Used] [decimal](9, 2) NULL ,
	[Percent_Log] [int] NULL ,
	[TotalSize] [decimal](10, 2) NULL ,
	[TotalUsed] [decimal](10, 2) NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[All_Free_Space] (
	[ServerName] [varchar] (60) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Drive] [varchar] (40) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Date_Collected] [datetime] NOT NULL ,
	[Freespace] [decimal](9, 2) NULL ,
	[Space In MB] [varchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[DB] [bit] NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[Applications_Supported] (
	[Server] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[DB] [varchar] (120) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Application] [varchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Department] [varchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[DBA] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Manager_Contact] [varchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Bkp_Plan] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Tape_DRM_Plan] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Comment] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Id] [int] IDENTITY (1, 1) NOT NULL ,
	[Bkp_PlanName] [varchar] (80) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Audited] [bit] NULL ,
	[OrigDBSize] [decimal](9, 2) NULL ,
	[CurrentDBSize] [decimal](9, 2) NULL ,
	[NumUsers] [int] NULL ,
	[OrigDBDate] [datetime] NULL ,
	[AdjUserCount] [int] NULL ,
	[GrowthRate] [decimal](12, 2) NULL ,
	[ActiveFlag] [bit] NULL ,
	[DBDrives] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Code] [varchar] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[PCI] [bit] NULL ,
	[PII] [bit] NULL ,
	[ServerType] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[NonSQL] [bit] NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[Applications_Supported_Save] (
	[Server] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[DB] [varchar] (120) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Application] [varchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Department] [varchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[DBA] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Manager_Contact] [varchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Bkp_Plan] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Tape_DRM_Plan] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Comment] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Id] [int] IDENTITY (1, 1) NOT NULL ,
	[Bkp_PlanName] [varchar] (80) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Audited] [bit] NULL ,
	[OrigDBSize] [decimal](9, 2) NULL ,
	[CurrentDBSize] [decimal](9, 2) NULL ,
	[NumUsers] [int] NULL ,
	[OrigDBDate] [datetime] NULL ,
	[AdjUserCount] [int] NULL ,
	[GrowthRate] [decimal](12, 2) NULL ,
	[ActiveFlag] [bit] NULL ,
	[DBDrives] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Code] [varchar] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[PCI] [bit] NULL ,
	[PII] [bit] NULL ,
	[ServerType] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[NonSQL] [bit] NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[BlankLogins] (
	[Id] [int] IDENTITY (1, 1) NOT NULL ,
	[ServerName] [varchar] (60) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Login] [varchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[DBA_Log] (
	[DBA] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Requestor] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[DateTimeReceived] [smalldatetime] NULL ,
	[DateTimeFinished] [smalldatetime] NULL ,
	[TimeSpent] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Project] [varchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Email] [varchar] (3000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Comments] [varchar] (1000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[DBAttributes] (
	[DBName] [varchar] (60) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Model] [varchar] (60) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Status] [varchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[DBSTATS] (
	[Id] [int] IDENTITY (1, 1) NOT NULL ,
	[ServerName] [char] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[DBName] [char] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Data_Size] [decimal](9, 2) NULL ,
	[Data_Used] [decimal](9, 2) NULL ,
	[Log_Size] [decimal](9, 2) NULL ,
	[Log_Used] [decimal](9, 2) NULL ,
	[State_Date] [datetime] NOT NULL ,
	[PercentLog] [decimal](9, 2) NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[DB_FREESPACE_STATS] (
	[Id] [int] IDENTITY (1, 1) NOT NULL ,
	[ServerName] [char] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Drive] [varchar] (40) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[FreeSpace] [real] NULL ,
	[State_Date] [datetime] NOT NULL ,
	[DB] [bit] NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[Database_Files] (
	[Id] [int] IDENTITY (1, 1) NOT NULL ,
	[DBId] [int] NOT NULL ,
	[LogicalName] [varchar] (120) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[PhysicalName] [varchar] (500) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[SizeInMB] [int] NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[Databases] (
	[DBId] [int] IDENTITY (1, 1) NOT NULL ,
	[ServerName] [varchar] (60) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[DBName] [varchar] (120) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[DBType] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[ServDBId] [int] NULL ,
	[ActiveFlag] [bit] NOT NULL ,
	[RecoveryModel] [varchar] (60) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Status] [varchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[NumTables] [int] NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[ExportApps] (
	[Server] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[ServerType] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[DB] [varchar] (120) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Application] [varchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Department] [varchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Code] [varchar] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[DBA] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Manager_Contact] [varchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Audited] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[PCI] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[PII] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[NonSQL] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[NumUsers] [int] NULL ,
	[AdjUserCount] [int] NULL ,
	[DBDrives] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Bkp_Plan] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Tape_DRM_Plan] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Bkp_PlanName] [varchar] (80) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[OrigDBSize] [decimal](9, 2) NULL ,
	[OrigDBDate] [datetime] NULL ,
	[CurrentDBSize] [decimal](9, 2) NULL ,
	[GrowthRate] [decimal](12, 2) NULL ,
	[Comment] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[ExportAuditPermissions] (
	[Application] [varchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[ServerName] [varchar] (60) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Login] [sysname] NULL ,
	[SysAdmin] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Security] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Server] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Setup] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Process] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Disk] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[DBCreator] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[ExportBlankLogins] (
	[ServerName] [varchar] (60) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Login] [varchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[ExportGrants] (
	[ServerName] [varchar] (60) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[DBName] [varchar] (120) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[ObjectName] [varchar] (120) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[ObjectType] [varchar] (120) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Owner] [varchar] (120) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[GranteeName] [varchar] (120) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[GrantType] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Permission] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[ExportJobs] (
	[ServerName] [varchar] (60) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[From Srv] [varchar] (25) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[JobName] [sysname] NOT NULL ,
	[MaintPlan] [bit] NOT NULL ,
	[DTS] [bit] NOT NULL ,
	[Scheduled] [bit] NOT NULL ,
	[Status] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Date] [datetime] NULL ,
	[Time] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Duration] [char] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[DateModified] [datetime] NULL ,
	[Log] [varchar] (200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Description] [varchar] (512) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Message] [varchar] (1024) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[RunDatetime] [datetime] NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[ExportPermissions] (
	[ServerName] [varchar] (60) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Login] [sysname] NULL ,
	[SysAdmin] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Security] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Server] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Setup] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Process] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Disk] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[DBCreator] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[ExportSchedules] (
	[ServerName] [varchar] (60) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[JobName] [sysname] NOT NULL ,
	[DTS] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[MaintPlan] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Desc] [varchar] (512) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Freq] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[When] [varchar] (150) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Time] [varchar] (25) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[History] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[StepId] [int] NULL ,
	[StepName] [varchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[NextRunDate] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[NextRunTime] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[OrigSrv] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Owner] [sysname] NULL ,
	[Netsend] [varchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[JobType] [varchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[ExportUsers] (
	[ServerName] [varchar] (60) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Login] [varchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[UserName] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[DBName] [varchar] (120) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[RoleName] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[NTGroup] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Alias] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[DefaultDB] [varchar] (120) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[CreateDate] [datetime] NULL ,
	[LastLogin] [datetime] NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[Grants] (
	[DBid] [int] NOT NULL ,
	[ObjectName] [varchar] (120) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[ObjectType] [varchar] (120) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Owner] [varchar] (120) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[GranteeName] [varchar] (120) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[GrantType] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Permission] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Grantid] [int] IDENTITY (1, 1) NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[Jobs] (
	[LngId] [int] IDENTITY (1, 1) NOT NULL ,
	[ServerName] [varchar] (60) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Originating_Server] [varchar] (25) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[JobName] [sysname] NOT NULL ,
	[Status] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[RunDate] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[RunTime] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[RunDuration] [char] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[RunDatetime] [datetime] NULL ,
	[DateModified] [datetime] NULL ,
	[LogFileName] [varchar] (200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Description] [varchar] (512) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Message] [varchar] (1024) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[MaintPlan] [bit] NOT NULL ,
	[DTS] [bit] NOT NULL ,
	[Scheduled] [bit] NOT NULL ,
	[OldJobName] [sysname] NOT NULL ,
	[Owner] [sysname] NULL ,
	[NetSend] [varchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[LitespeedInfo] (
	[Name] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Value] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[MaintenancePlans] (
	[Id] [int] IDENTITY (1, 1) NOT NULL ,
	[PlanName] [varchar] (80) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Activity] [varchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Date] [datetime] NULL ,
	[DBId] [int] NULL ,
	[EndDate] [datetime] NULL ,
	[ActivityId] [int] NULL ,
	[Status] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[ServerName] [varchar] (60) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Duration] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[Months] (
	[MonthId] [int] IDENTITY (1, 1) NOT NULL ,
	[DBId] [int] NULL ,
	[Sample_Year] [int] NULL ,
	[Sample_Month] [int] NULL ,
	[DataUsed] [int] NULL ,
	[Diff] [int] NULL ,
	[PctIncr] [decimal](12, 2) NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[PackageSteps] (
	[Id] [int] IDENTITY (1, 1) NOT NULL ,
	[Stepname] [varchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Errorcode] [int] NULL ,
	[ProgressCount] [bigint] NULL ,
	[Starttime] [datetime] NULL ,
	[Endtime] [datetime] NULL ,
	[Elapsedtime] [float] NULL ,
	[ErrorDescription] [varchar] (2000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[PkgId] [int] NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[Packages] (
	[Id] [int] IDENTITY (1, 1) NOT NULL ,
	[ServerName] [varchar] (60) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[PkgName] [varchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Description] [varchar] (1024) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Created] [datetime] NULL ,
	[LastModified] [datetime] NULL ,
	[Owner] [varchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Job] [bit] NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[RunningJobs] (
	[Server] [varchar] (60) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[JobName] [varchar] (250) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Date] [smalldatetime] NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[Schedules] (
	[Id] [int] IDENTITY (1, 1) NOT NULL ,
	[ServerName] [varchar] (60) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[JobName] [sysname] NOT NULL ,
	[OrigSrv] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[JobType] [varchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Desc] [varchar] (512) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Owner] [sysname] NULL ,
	[Netsend] [varchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Created] [datetime] NULL ,
	[Modified] [datetime] NULL ,
	[SchedName] [sysname] NULL ,
	[Freq] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[When] [varchar] (150) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Time] [varchar] (25) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[NextRunDate] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[NextRunTime] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[MaintPlan] [bit] NOT NULL ,
	[DTS] [bit] NOT NULL ,
	[History] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[StepId] [int] NULL ,
	[StepName] [varchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[ServerConfigs] (
	[Id] [int] IDENTITY (1, 1) NOT NULL ,
	[Name] [nvarchar] (70) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Minimum] [int] NULL ,
	[Maximum] [int] NULL ,
	[Config_Value] [int] NULL ,
	[Run_Value] [int] NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[ServerConfigurations] (
	[Name] [nvarchar] (70) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Minimum] [int] NULL ,
	[Maximum] [int] NULL ,
	[Config_Value] [int] NULL ,
	[Run_Value] [int] NULL ,
	[ServerName] [varchar] (60) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Id] [int] IDENTITY (1, 1) NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[ServerInfo] (
	[ProductVersion] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[ProductLevel] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Edition] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[ServerPermissions] (
	[Id] [int] IDENTITY (1, 1) NOT NULL ,
	[ServerName] [varchar] (60) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Login] [sysname] NULL ,
	[Sys] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Security] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Server] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Setup] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Process] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Disk] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[DBCreator] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[UserId] [int] NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[Servers] (
	[ServerName] [varchar] (60) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[SQLVersion] [int] NOT NULL ,
	[ServerType] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[ActiveFlag] [bit] NOT NULL ,
	[Started] [bit] NOT NULL ,
	[Finished] [bit] NOT NULL ,
	[Step] [varchar] (80) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[DB2Driver] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[ServicePack] [varchar] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[LiteSpeed] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Server_IP] [varchar] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[OS_Name] [varchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[OS_Description] [varchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Product_Name] [varchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[MemoryMB] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[CPU] [varchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[MHZ] [smallint] NULL ,
	[pmp_device_key] [int] NULL ,
	[NumCPU] [smallint] NULL ,
	[Dependencies] [varchar] (500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[ClusterMember] [bit] NOT NULL ,
	[ClusterName] [varchar] (60) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Litespeed Version] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[BuildNumber] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Edition] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[64-bit] [bit] NOT NULL ,
	[Itanium] [bit] NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[Servers_Save] (
	[ServerName] [varchar] (60) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[SQLVersion] [int] NOT NULL ,
	[ServerType] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[ActiveFlag] [bit] NOT NULL ,
	[Started] [bit] NOT NULL ,
	[Finished] [bit] NOT NULL ,
	[Step] [varchar] (80) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[DB2Driver] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[ServicePack] [varchar] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[LiteSpeed] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Server_IP] [varchar] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[OS_Name] [varchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[OS_Description] [varchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Product_Name] [varchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[MemoryMB] [smallint] NULL ,
	[CPU] [varchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[MHZ] [smallint] NULL ,
	[pmp_device_key] [int] NULL ,
	[NumCPU] [smallint] NULL ,
	[Dependencies] [varchar] (500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[ClusterMember] [bit] NOT NULL ,
	[ClusterName] [varchar] (60) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Litespeed Version] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[BuildNumber] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Edition] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[64-bit] [bit] NOT NULL ,
	[Itanium] [bit] NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[Showcontig] (
	[Add_Date] [datetime] NOT NULL ,
	[DBName] [sysname] NOT NULL ,
	[TableName] [varchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[TableId] [int] NOT NULL ,
	[IndexName] [varchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[IndexId] [int] NOT NULL ,
	[Lvl] [int] NULL ,
	[CountPages] [int] NULL ,
	[CountRows] [int] NULL ,
	[MinRecSize] [int] NULL ,
	[MaxRecSize] [int] NULL ,
	[AvgRecSize] [int] NULL ,
	[ForRecCount] [int] NULL ,
	[Extents] [int] NULL ,
	[ExtentSwitches] [int] NULL ,
	[AvgFreeBytes] [int] NULL ,
	[AvgPageDensity] [decimal](18, 0) NULL ,
	[ScanDensity] [decimal](18, 0) NULL ,
	[BestCount] [int] NULL ,
	[ActualCount] [int] NULL ,
	[LogicalFrag] [decimal](18, 0) NULL ,
	[ExtentFrag] [decimal](18, 0) NULL ,
	[Owner] [sysname] NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[Showcontig_All] (
	[Add_Datetime] [datetime] NOT NULL ,
	[ServerName] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[DBName] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[TableName] [char] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[TableId] [int] NOT NULL ,
	[IndexName] [char] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[IndexId] [int] NOT NULL ,
	[Lvl] [int] NULL ,
	[Pages] [int] NULL ,
	[Rows] [int] NULL ,
	[MinRecSize] [int] NULL ,
	[MaxRecSize] [int] NULL ,
	[AvgRecSize] [int] NULL ,
	[ForRecCount] [int] NULL ,
	[Extents] [int] NULL ,
	[ExtentSwitches] [int] NULL ,
	[AvgFreeBytes] [int] NULL ,
	[AvgPageDensity] [decimal](18, 0) NULL ,
	[ScanDensity] [decimal](18, 0) NULL ,
	[BestCount] [int] NULL ,
	[ActualCount] [int] NULL ,
	[LogicalFrag] [decimal](18, 0) NULL ,
	[ExtentFrag] [decimal](18, 0) NULL ,
	[Owner] [sysname] NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[Stats_Summary] (
	[DBId] [int] NOT NULL ,
	[StartDate] [datetime] NOT NULL ,
	[EndDate] [datetime] NOT NULL ,
	[Months] [int] NULL ,
	[MinUsed] [int] NULL ,
	[MaxUsed] [int] NULL ,
	[SizeDiff] [int] NULL ,
	[PctIncr] [decimal](12, 2) NULL ,
	[PctPerMo] [decimal](12, 2) NULL ,
	[SizeIn1] [numeric](18, 0) NULL ,
	[SizeIn2] [numeric](18, 0) NULL ,
	[SizeIn3] [numeric](18, 0) NULL ,
	[SizeIn4] [numeric](18, 0) NULL ,
	[SizeIn5] [numeric](18, 0) NULL ,
	[SizeIn6] [numeric](18, 0) NULL ,
	[SizeIn7] [numeric](18, 0) NULL ,
	[SizeIn8] [numeric](18, 0) NULL ,
	[SizeIn9] [numeric](18, 0) NULL ,
	[SizeIn10] [numeric](18, 0) NULL ,
	[SizeIn11] [numeric](18, 0) NULL ,
	[SizeIn12] [numeric](18, 0) NULL ,
	[AvgLogSize] [int] NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[TEMP_MONTHS] (
	[YEAR] [int] NULL ,
	[MONTH] [int] NULL ,
	[DataUsed] [decimal](9, 0) NULL ,
	[%Incr] [decimal](3, 2) NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[Table_Counts] (
	[DBName] [varchar] (120) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[TableName] [varchar] (120) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[RecordCount] [bigint] NULL ,
	[Owner] [sysname] NOT NULL ,
	[SampleDate] [datetime] NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[TempUsers] (
	[ServerName] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[UserName] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Pwd] [char] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[DBName] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[RoleName] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[IsNTGroup] [char] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[IsAliased] [char] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[SysAdmin] [char] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[ServerAdmin] [char] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[SetupAdmin] [char] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[ProcessAdmin] [char] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[SecurityAdmin] [char] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[DiskAdmin] [char] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[DBCreator] [char] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[User_Activity] (
	[Id] [int] IDENTITY (1, 1) NOT NULL ,
	[ServerName] [varchar] (60) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[SPID] [smallint] NOT NULL ,
	[Status] [char] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Login] [varchar] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Host] [varchar] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Block] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[BlkBy] [char] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[DB] [varchar] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Command] [varchar] (256) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[CPUTime] [char] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[DiskIO] [char] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[LastBatch] [char] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Program] [varchar] (256) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Buffer] [varchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[FetchDate] [datetime] NULL ,
	[Lock] [bit] NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[User_Activity_Loc] (
	[SPID] [smallint] NOT NULL ,
	[Status] [char] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Login] [varchar] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Host] [varchar] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Block] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[BlkBy] [char] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[DB] [varchar] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Command] [varchar] (256) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[CPUTime] [char] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[DiskIO] [char] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[LastBatch] [char] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Program] [varchar] (256) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Buffer] [varchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[FetchDate] [datetime] NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[User_Locks] (
	[ActivityId] [int] NOT NULL ,
	[ObjName] [varchar] (60) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[IndexName] [varchar] (60) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Type] [char] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Resource] [char] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Mode] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Status] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[User_Locks_Loc] (
	[SPID] [smallint] NOT NULL ,
	[ObjName] [varchar] (60) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[IndexName] [varchar] (60) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Type] [char] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Resource] [char] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Mode] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Status] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[Users] (
	[Id] [int] IDENTITY (1, 1) NOT NULL ,
	[ServerName] [varchar] (60) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Login] [varchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[UserName] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[RoleName] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[NTGroup] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Alias] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[DefaultDB] [varchar] (120) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[SvrRights] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[DBId] [int] NULL ,
	[CreateDate] [datetime] NULL ,
	[LastLogin] [datetime] NULL ,
	[AdjUser] [bit] NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[tmp_sfs] (
	[DBName] [nvarchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[FileId] [int] NULL ,
	[FileGroup] [int] NULL ,
	[TotalExtents] [int] NULL ,
	[UsedExtents] [int] NULL ,
	[Name] [varchar] (1024) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[FileName] [varchar] (1024) COLLATE SQL_Latin1_General_CP1_CI_AS NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[tmp_stats] (
	[TotalExtents] [int] NULL ,
	[UsedExtents] [int] NULL ,
	[DBName] [varchar] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[LogSize] [real] NULL ,
	[LogSpaceUsed] [real] NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[tmplg] (
	[DBName] [varchar] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[LogSize] [real] NULL ,
	[LogSpaceUsed] [real] NULL ,
	[Status] [int] NULL 
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[AdjustedUsers] WITH NOCHECK ADD 
	CONSTRAINT [PK_AdjustedUsers] PRIMARY KEY  CLUSTERED 
	(
		[Id]
	) WITH  FILLFACTOR = 90  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[All_DBStats] WITH NOCHECK ADD 
	CONSTRAINT [PK_All_DBStats] PRIMARY KEY  CLUSTERED 
	(
		[StatsId]
	) WITH  FILLFACTOR = 90  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[Applications_Supported] WITH NOCHECK ADD 
	CONSTRAINT [PK_Applications_Supported] PRIMARY KEY  CLUSTERED 
	(
		[Id]
	) WITH  FILLFACTOR = 90  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[BlankLogins] WITH NOCHECK ADD 
	CONSTRAINT [PK_BlankLogins] PRIMARY KEY  CLUSTERED 
	(
		[Id]
	) WITH  FILLFACTOR = 90  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[DB_FREESPACE_STATS] WITH NOCHECK ADD 
	CONSTRAINT [IX_DB_FREESPACE_STATS] UNIQUE  CLUSTERED 
	(
		[ServerName],
		[Drive],
		[State_Date]
	) WITH  FILLFACTOR = 90  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[Database_Files] WITH NOCHECK ADD 
	CONSTRAINT [PK_Database_Files] PRIMARY KEY  CLUSTERED 
	(
		[Id]
	) WITH  FILLFACTOR = 90  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[Databases] WITH NOCHECK ADD 
	CONSTRAINT [PK_Databases] PRIMARY KEY  CLUSTERED 
	(
		[DBId]
	) WITH  FILLFACTOR = 90  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[Grants] WITH NOCHECK ADD 
	CONSTRAINT [PK_Grants] PRIMARY KEY  CLUSTERED 
	(
		[Grantid]
	) WITH  FILLFACTOR = 90  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[Jobs] WITH NOCHECK ADD 
	CONSTRAINT [PK_Jobs] PRIMARY KEY  CLUSTERED 
	(
		[LngId]
	) WITH  FILLFACTOR = 90  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[MaintenancePlans] WITH NOCHECK ADD 
	CONSTRAINT [PK_MaintenancePlan] PRIMARY KEY  CLUSTERED 
	(
		[Id]
	) WITH  FILLFACTOR = 90  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[Months] WITH NOCHECK ADD 
	CONSTRAINT [PK_Months] PRIMARY KEY  CLUSTERED 
	(
		[MonthId]
	) WITH  FILLFACTOR = 90  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[PackageSteps] WITH NOCHECK ADD 
	CONSTRAINT [PK_PackageSteps] PRIMARY KEY  CLUSTERED 
	(
		[Id]
	) WITH  FILLFACTOR = 90  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[Schedules] WITH NOCHECK ADD 
	CONSTRAINT [PK_Schedules] PRIMARY KEY  CLUSTERED 
	(
		[Id]
	) WITH  FILLFACTOR = 90  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[ServerConfigs] WITH NOCHECK ADD 
	CONSTRAINT [PK_ServerConfigs] PRIMARY KEY  CLUSTERED 
	(
		[Id]
	) WITH  FILLFACTOR = 90  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[ServerConfigurations] WITH NOCHECK ADD 
	CONSTRAINT [PK_ServerConfigurations] PRIMARY KEY  CLUSTERED 
	(
		[Id]
	) WITH  FILLFACTOR = 90  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[ServerPermissions] WITH NOCHECK ADD 
	CONSTRAINT [PK_ServerPermissions] PRIMARY KEY  CLUSTERED 
	(
		[Id]
	) WITH  FILLFACTOR = 90  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[Servers] WITH NOCHECK ADD 
	CONSTRAINT [PK_SERVERS] PRIMARY KEY  CLUSTERED 
	(
		[ServerName]
	) WITH  FILLFACTOR = 90  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[Showcontig] WITH NOCHECK ADD 
	CONSTRAINT [PK_Showcontig] PRIMARY KEY  CLUSTERED 
	(
		[DBName],
		[TableId],
		[IndexId]
	) WITH  FILLFACTOR = 90  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[Showcontig_All] WITH NOCHECK ADD 
	CONSTRAINT [PK_Showcontig_All] PRIMARY KEY  CLUSTERED 
	(
		[Add_Datetime],
		[ServerName],
		[DBName],
		[TableId],
		[IndexId]
	) WITH  FILLFACTOR = 90  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[Stats_Summary] WITH NOCHECK ADD 
	CONSTRAINT [PK_Stats_Summary] PRIMARY KEY  CLUSTERED 
	(
		[DBId]
	) WITH  FILLFACTOR = 90  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[Table_Counts] WITH NOCHECK ADD 
	CONSTRAINT [PK_Table_Counts] PRIMARY KEY  CLUSTERED 
	(
		[DBName],
		[Owner],
		[TableName],
		[SampleDate]
	) WITH  FILLFACTOR = 90  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[User_Activity] WITH NOCHECK ADD 
	CONSTRAINT [PK_User_Activity] PRIMARY KEY  CLUSTERED 
	(
		[Id]
	) WITH  FILLFACTOR = 90  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[Users] WITH NOCHECK ADD 
	CONSTRAINT [PK_Users] PRIMARY KEY  CLUSTERED 
	(
		[Id]
	) WITH  FILLFACTOR = 90  ON [PRIMARY] 
GO

 CREATE  UNIQUE  CLUSTERED  INDEX [IDX_Packages] ON [dbo].[Packages]([ServerName], [PkgName]) WITH  FILLFACTOR = 90 ON [PRIMARY]
GO

ALTER TABLE [dbo].[AdjustedUsers] ADD 
	CONSTRAINT [DF__AdjustedU__Owner__4D81DB07] DEFAULT ('dbo') FOR [Owner]
GO

 CREATE  UNIQUE  INDEX [IDX_AdjustedUsers] ON [dbo].[AdjustedUsers]([ServerName], [DBName]) WITH  FILLFACTOR = 90 ON [PRIMARY]
GO

 CREATE  UNIQUE  INDEX [IX_All_DBStats_DB_Sample] ON [dbo].[All_DBStats]([DBId], [Sample_Date]) WITH  FILLFACTOR = 90 ON [PRIMARY]
GO

ALTER TABLE [dbo].[All_Free_Space] ADD 
	CONSTRAINT [DF_All_Free_Space_DB] DEFAULT (0) FOR [DB]
GO

 CREATE  INDEX [IX_All_Free_Space] ON [dbo].[All_Free_Space]([ServerName], [Drive], [Date_Collected]) WITH  FILLFACTOR = 90 ON [PRIMARY]
GO

ALTER TABLE [dbo].[Applications_Supported] ADD 
	CONSTRAINT [DF_Applications_Supported_Audited] DEFAULT (0) FOR [Audited],
	CONSTRAINT [DF_Applications_Supported_ActiveFlag] DEFAULT (1) FOR [ActiveFlag],
	CONSTRAINT [DF_Applications_Supported_PCI] DEFAULT (0) FOR [PCI],
	CONSTRAINT [DF_Applications_Supported_PII] DEFAULT (0) FOR [PII],
	CONSTRAINT [DF_Applications_Supported_NonSQL] DEFAULT (0) FOR [NonSQL],
	CONSTRAINT [IX_Applications_Supported] UNIQUE  NONCLUSTERED 
	(
		[Server],
		[DB]
	) WITH  FILLFACTOR = 90  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[DBSTATS] ADD 
	CONSTRAINT [DF_DBSTATS_ServerName] DEFAULT (@@servername) FOR [ServerName],
	CONSTRAINT [DF_DBSTATS_Stat_Date] DEFAULT (getdate()) FOR [State_Date],
	CONSTRAINT [PK_DBSTATS] PRIMARY KEY  NONCLUSTERED 
	(
		[Id]
	) WITH  FILLFACTOR = 90  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[DB_FREESPACE_STATS] ADD 
	CONSTRAINT [DF_FREESPACE_ServerName] DEFAULT (@@servername) FOR [ServerName],
	CONSTRAINT [DF_FREESPACE_Stat_Date] DEFAULT (getdate()) FOR [State_Date],
	CONSTRAINT [DF__DB_FREESPACE__DB__48F23014] DEFAULT (0) FOR [DB],
	CONSTRAINT [PK_DB_FREESPACE_STATS] PRIMARY KEY  NONCLUSTERED 
	(
		[Id]
	) WITH  FILLFACTOR = 90  ON [PRIMARY] 
GO

 CREATE  UNIQUE  INDEX [IDX_Database_Files] ON [dbo].[Database_Files]([DBId], [LogicalName], [PhysicalName]) WITH  FILLFACTOR = 90 ON [PRIMARY]
GO

 CREATE  INDEX [IDX_Database_Files2] ON [dbo].[Database_Files]([DBId]) WITH  FILLFACTOR = 90 ON [PRIMARY]
GO

ALTER TABLE [dbo].[Databases] ADD 
	CONSTRAINT [DF__Databases__DBTyp__1C349836] DEFAULT ('D') FOR [DBType],
	CONSTRAINT [DF_Databases_ActiveFlag] DEFAULT (1) FOR [ActiveFlag],
	CONSTRAINT [DF_Databases_NumTables] DEFAULT (0) FOR [NumTables]
GO

 CREATE  UNIQUE  INDEX [IX_Databases] ON [dbo].[Databases]([ServerName], [DBName]) WITH  FILLFACTOR = 90 ON [PRIMARY]
GO

 CREATE  INDEX [IX_Grants] ON [dbo].[Grants]([DBid]) WITH  FILLFACTOR = 90 ON [PRIMARY]
GO

ALTER TABLE [dbo].[Jobs] ADD 
	CONSTRAINT [DF__Jobs__MaintPlan__4536ADC9] DEFAULT (0) FOR [MaintPlan],
	CONSTRAINT [DF__Jobs__DTS__462AD202] DEFAULT (0) FOR [DTS],
	CONSTRAINT [DF__Jobs__Scheduled__471EF63B] DEFAULT (0) FOR [Scheduled]
GO

 CREATE  INDEX [IDX_Jobs2] ON [dbo].[Jobs]([ServerName], [RunDatetime] DESC ) WITH  FILLFACTOR = 90 ON [PRIMARY]
GO

 CREATE  INDEX [IX_MaintenancePlans] ON [dbo].[MaintenancePlans]([DBId]) WITH  FILLFACTOR = 90 ON [PRIMARY]
GO

 CREATE  UNIQUE  INDEX [IX_Months] ON [dbo].[Months]([DBId], [Sample_Year], [Sample_Month]) WITH  FILLFACTOR = 90 ON [PRIMARY]
GO

 CREATE  INDEX [IDX_PackageSteps] ON [dbo].[PackageSteps]([PkgId]) WITH  FILLFACTOR = 90 ON [PRIMARY]
GO

ALTER TABLE [dbo].[Packages] ADD 
	CONSTRAINT [DF__Packages__Job__6603700E] DEFAULT (0) FOR [Job],
	CONSTRAINT [PK_Packages] PRIMARY KEY  NONCLUSTERED 
	(
		[Id]
	) WITH  FILLFACTOR = 90  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[Schedules] ADD 
	CONSTRAINT [DF__Schedules__Maint__2F476CAA] DEFAULT (0) FOR [MaintPlan],
	CONSTRAINT [DF__Schedules__DTS__303B90E3] DEFAULT (0) FOR [DTS]
GO

 CREATE  INDEX [IDX_Schedules] ON [dbo].[Schedules]([ServerName]) WITH  FILLFACTOR = 90 ON [PRIMARY]
GO

ALTER TABLE [dbo].[ServerPermissions] ADD 
	CONSTRAINT [DF__ServerPermi__Sys__3AB91F56] DEFAULT ('N') FOR [Sys],
	CONSTRAINT [DF__ServerPer__Secur__3BAD438F] DEFAULT ('N') FOR [Security],
	CONSTRAINT [DF__ServerPer__Serve__3CA167C8] DEFAULT ('N') FOR [Server],
	CONSTRAINT [DF__ServerPer__Setup__3D958C01] DEFAULT ('N') FOR [Setup],
	CONSTRAINT [DF__ServerPer__Proce__3E89B03A] DEFAULT ('N') FOR [Process],
	CONSTRAINT [DF__ServerPerm__Disk__3F7DD473] DEFAULT ('N') FOR [Disk],
	CONSTRAINT [DF__ServerPer__DBCre__4071F8AC] DEFAULT ('N') FOR [DBCreator]
GO

 CREATE  INDEX [IDX_ServerPermissions] ON [dbo].[ServerPermissions]([ServerName], [Login]) WITH  FILLFACTOR = 90 ON [PRIMARY]
GO

 CREATE  INDEX [IDX_ServerPermissions1] ON [dbo].[ServerPermissions]([UserId]) WITH  FILLFACTOR = 90 ON [PRIMARY]
GO

ALTER TABLE [dbo].[Servers] ADD 
	CONSTRAINT [DF__SERVERS__SQLVers__61E66462] DEFAULT (2) FOR [SQLVersion],
	CONSTRAINT [DF__SERVERS__ServerT__62DA889B] DEFAULT ('D') FOR [ServerType],
	CONSTRAINT [DF_Servers_ActiveFlag] DEFAULT (1) FOR [ActiveFlag],
	CONSTRAINT [DF_Servers_Started] DEFAULT (0) FOR [Started],
	CONSTRAINT [DF_Servers_Finished] DEFAULT (0) FOR [Finished],
	CONSTRAINT [DF_Servers_ClusterMember] DEFAULT (0) FOR [ClusterMember],
	CONSTRAINT [DF_Servers_64-bit] DEFAULT (0) FOR [64-bit],
	CONSTRAINT [DF_Servers_Itanium] DEFAULT (0) FOR [Itanium],
	CONSTRAINT [IX_SERVERS] UNIQUE  NONCLUSTERED 
	(
		[ServerName]
	) WITH  FILLFACTOR = 90  ON [PRIMARY] 
GO

 CREATE  UNIQUE  INDEX [IX_Showcontig] ON [dbo].[Showcontig]([DBName], [TableName], [IndexName]) WITH  FILLFACTOR = 90 ON [PRIMARY]
GO

 CREATE  UNIQUE  INDEX [IX_Showcontig_All] ON [dbo].[Showcontig_All]([Add_Datetime] DESC , [ServerName], [DBName], [TableName], [IndexName]) WITH  FILLFACTOR = 90 ON [PRIMARY]
GO

ALTER TABLE [dbo].[User_Activity] ADD 
	CONSTRAINT [DF__User_Activ__Lock__50A86075] DEFAULT (0) FOR [Lock]
GO

 CREATE  INDEX [IDX_User_Activity] ON [dbo].[User_Activity]([ServerName], [SPID], [DB]) WITH  FILLFACTOR = 90 ON [PRIMARY]
GO

ALTER TABLE [dbo].[User_Activity_Loc] ADD 
	CONSTRAINT [DF__User_Acti__Fetch__3DF4B35D] DEFAULT (getdate()) FOR [FetchDate]
GO

 CREATE  INDEX [IDX_User_Locks] ON [dbo].[User_Locks]([ActivityId]) WITH  FILLFACTOR = 90 ON [PRIMARY]
GO

ALTER TABLE [dbo].[Users] ADD 
	CONSTRAINT [DF__Users__NTGroup__340C21C7] DEFAULT ('N') FOR [NTGroup],
	CONSTRAINT [DF__Users__Alias__35004600] DEFAULT ('N') FOR [Alias],
	CONSTRAINT [DF__Users__SvrRights__35F46A39] DEFAULT ('N') FOR [SvrRights],
	CONSTRAINT [DF_Users_AdjUser] DEFAULT (0) FOR [AdjUser]
GO

 CREATE  INDEX [IX_Users] ON [dbo].[Users]([DBId]) WITH  FILLFACTOR = 90 ON [PRIMARY]
GO

 CREATE  INDEX [IX_Users3] ON [dbo].[Users]([SvrRights]) WITH  FILLFACTOR = 90 ON [PRIMARY]
GO

 CREATE  INDEX [IX_Users1] ON [dbo].[Users]([ServerName], [Login]) WITH  FILLFACTOR = 90 ON [PRIMARY]
GO

ALTER TABLE [dbo].[All_DBStats] ADD 
	CONSTRAINT [FK_All_DBStats_Databases] FOREIGN KEY 
	(
		[DBId]
	) REFERENCES [dbo].[Databases] (
		[DBId]
	) ON DELETE CASCADE  ON UPDATE CASCADE 
GO

ALTER TABLE [dbo].[All_Free_Space] ADD 
	CONSTRAINT [FK_All_Free_Space_Servers] FOREIGN KEY 
	(
		[ServerName]
	) REFERENCES [dbo].[Servers] (
		[ServerName]
	) ON DELETE CASCADE  ON UPDATE CASCADE 
GO

ALTER TABLE [dbo].[BlankLogins] ADD 
	CONSTRAINT [FK_BlankLogins_Servers] FOREIGN KEY 
	(
		[ServerName]
	) REFERENCES [dbo].[Servers] (
		[ServerName]
	) ON DELETE CASCADE  ON UPDATE CASCADE 
GO

ALTER TABLE [dbo].[Database_Files] ADD 
	CONSTRAINT [FK_Database_Files_Databases] FOREIGN KEY 
	(
		[DBId]
	) REFERENCES [dbo].[Databases] (
		[DBId]
	) ON DELETE CASCADE  ON UPDATE CASCADE 
GO

ALTER TABLE [dbo].[Grants] ADD 
	CONSTRAINT [FK_Grants_Databases] FOREIGN KEY 
	(
		[DBid]
	) REFERENCES [dbo].[Databases] (
		[DBId]
	) ON DELETE CASCADE  ON UPDATE CASCADE 
GO

ALTER TABLE [dbo].[Jobs] ADD 
	CONSTRAINT [FK_Jobs_Servers] FOREIGN KEY 
	(
		[ServerName]
	) REFERENCES [dbo].[Servers] (
		[ServerName]
	) ON DELETE CASCADE  ON UPDATE CASCADE 
GO

ALTER TABLE [dbo].[MaintenancePlans] ADD 
	CONSTRAINT [FK_MaintenancePlans_Databases] FOREIGN KEY 
	(
		[DBId]
	) REFERENCES [dbo].[Databases] (
		[DBId]
	) ON DELETE CASCADE  ON UPDATE CASCADE 
GO

ALTER TABLE [dbo].[Months] ADD 
	CONSTRAINT [FK_Months_Databases] FOREIGN KEY 
	(
		[DBId]
	) REFERENCES [dbo].[Databases] (
		[DBId]
	) ON DELETE CASCADE  ON UPDATE CASCADE 
GO

ALTER TABLE [dbo].[PackageSteps] ADD 
	CONSTRAINT [FK_PackageSteps_Packages] FOREIGN KEY 
	(
		[PkgId]
	) REFERENCES [dbo].[Packages] (
		[Id]
	) ON DELETE CASCADE  ON UPDATE CASCADE 
GO

ALTER TABLE [dbo].[Packages] ADD 
	CONSTRAINT [FK_Packages_Servers] FOREIGN KEY 
	(
		[ServerName]
	) REFERENCES [dbo].[Servers] (
		[ServerName]
	) ON DELETE CASCADE  ON UPDATE CASCADE 
GO

ALTER TABLE [dbo].[ServerConfigurations] ADD 
	CONSTRAINT [FK_ServerConfigurations_Servers] FOREIGN KEY 
	(
		[ServerName]
	) REFERENCES [dbo].[Servers] (
		[ServerName]
	) ON DELETE CASCADE  ON UPDATE CASCADE 
GO

ALTER TABLE [dbo].[ServerPermissions] ADD 
	CONSTRAINT [FK_ServerPermissions_Users] FOREIGN KEY 
	(
		[UserId]
	) REFERENCES [dbo].[Users] (
		[Id]
	) ON DELETE CASCADE  ON UPDATE CASCADE 
GO

ALTER TABLE [dbo].[Stats_Summary] ADD 
	CONSTRAINT [FK_Stats_Summary_Databases] FOREIGN KEY 
	(
		[DBId]
	) REFERENCES [dbo].[Databases] (
		[DBId]
	) ON DELETE CASCADE  ON UPDATE CASCADE 
GO

ALTER TABLE [dbo].[User_Activity] ADD 
	CONSTRAINT [FK_User_Activity_Servers] FOREIGN KEY 
	(
		[ServerName]
	) REFERENCES [dbo].[Servers] (
		[ServerName]
	) ON DELETE CASCADE  ON UPDATE CASCADE 
GO

ALTER TABLE [dbo].[User_Locks] ADD 
	CONSTRAINT [FK_User_Locks_User_Activity] FOREIGN KEY 
	(
		[ActivityId]
	) REFERENCES [dbo].[User_Activity] (
		[Id]
	) ON DELETE CASCADE  ON UPDATE CASCADE 
GO

ALTER TABLE [dbo].[Users] ADD 
	CONSTRAINT [FK_Users_Databases] FOREIGN KEY 
	(
		[DBId]
	) REFERENCES [dbo].[Databases] (
		[DBId]
	) ON DELETE CASCADE  ON UPDATE CASCADE ,
	CONSTRAINT [FK_Users_Servers] FOREIGN KEY 
	(
		[ServerName]
	) REFERENCES [dbo].[Servers] (
		[ServerName]
	) ON DELETE CASCADE  ON UPDATE CASCADE 
GO

