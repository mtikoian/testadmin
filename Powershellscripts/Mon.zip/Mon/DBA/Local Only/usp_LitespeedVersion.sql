USE DBA
GO

IF OBJECT_ID('dbo.usp_LitespeedVersion') IS NOT NULL
	DROP PROCEDURE dbo.usp_LitespeedVersion
go
CREATE PROCEDURE dbo.usp_LitespeedVersion
@ServerName	varchar(60)
AS

DECLARE @cmd varchar(3000)

CREATE TABLE #tmp
( 
Name varchar(100),
Value varchar(100)
)
SET @cmd = 'INSERT INTO #tmp EXEC [' + @ServerName + '].[master].[dbo].[xp_sqllitespeed_version]'

select Value  from #tmp where Name = 'Product Version'

EXEC(@cmd)
GO




