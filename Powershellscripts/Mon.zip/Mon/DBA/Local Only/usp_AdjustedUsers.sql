USE DBA
GO
IF OBJECT_ID( 'dbo.usp_AdjustedUsers' ) IS NOT NULL
	DROP PROCEDURE dbo.usp_AdjustedUsers
go
CREATE PROCEDURE dbo.usp_AdjustedUsers
as
BEGIN
SET NOCOUNT ON
PRINT 'usp_AdjustedUsers'

DECLARE
	@Server	varchar(60),
	@DB	varchar(120),
	@Owner	varchar(60),
	@Table	varchar(60),
	@Filter	varchar(1000),
	@SQL	varchar(3000)

UPDATE dbo.AdjustedUsers SET Processed = 0

DECLARE
	ADJ_CUR CURSOR FOR
	SELECT u.ServerName, u.DBName, u.Owner, u.TableName, u.Filter
	FROM dbo.AdjustedUsers u 
		JOIN dbo.Servers s ON s.ServerName = u.ServerName
	WHERE s.ActiveFlag = 1
	ORDER BY u.ServerName, u.DBName

OPEN ADJ_CUR
FETCH NEXT FROM ADJ_CUR INTO @Server, @DB, @Owner, @Table, @Filter
WHILE @@FETCH_STATUS = 0
	begin
	PRINT @Server + ' - ' + @DB
	SET @SQL = 
		'UPDATE dbo.Applications_Supported 
		 SET AdjUserCount = UserCount
		 FROM dbo.Applications_Supported a JOIN
		 ( SELECT COUNT(*) as UserCount
		   FROM [' + @Server + '].' + @DB + '.' + @Owner + '.' + @Table 

	IF @Filter IS NOT NULL SET @SQL = @SQL + ' WHERE ' + @Filter

	SET @SQL = @SQL + ' ) as uu ON a.Server = ''' + @Server + ''' and
		a.DB = ''' + @DB + ''''
	
	PRINT @SQL
	EXEC( @SQL )

	UPDATE dbo.AdjustedUsers SET Processed = 1 
	WHERE ServerName = @Server and DBName = @DB

	FETCH NEXT FROM ADJ_CUR INTO @Server, @DB, @Owner, @Table, @Filter
	end
CLOSE ADJ_CUR
DEALLOCATE ADJ_CUR
END
GO