use DBA
go
IF OBJECT_ID( 'usp_ObjectGrantsNotNull' ) IS NOT NULL
	DROP PROCEDURE dbo.usp_ObjectGrantsNotNull
go
 
CREATE PROCEDURE dbo.usp_ObjectGrantsNotNull
	@Server varchar( 60 ),
	@Database varchar( 120 ),
	@DBid	int
AS
BEGIN
PRINT 'usp_ObjectGrantsNotNull - ' + @Server + ' - ' + @Database

DECLARE
 @cmd	varchar(4000)

SET @cmd = 
'INSERT INTO dbo.Grants
	(DBid, ObjectName, ObjectType, Owner, GranteeName, GrantType, Permission) 
	SELECT 	' + cast(@DBid as varchar) + ', 
		o.name 	AS ObjectName,
		CASE o.xtype
			WHEN ''C''  THEN ''Check constraint''
		 	WHEN ''D''  THEN ''Default constraint''
		 	WHEN ''F''  THEN ''Foreign key''
		 	WHEN ''L''  THEN ''Log''
		 	WHEN ''FN'' THEN ''Scalar function''
		 	WHEN ''IN'' THEN ''Inline table function''
		 	WHEN ''P''  THEN ''Stored procedure''
		 	WHEN ''PK'' THEN ''Primary key''
		 	WHEN ''RF'' THEN ''Replication filter stored procedure'' 
		 	WHEN ''S''  THEN ''System table''
		 	WHEN ''TF'' THEN ''Table function''
		 	WHEN ''TR'' THEN ''Trigger''
		 	WHEN ''U''  THEN ''Table''
		 	WHEN ''UQ'' THEN ''Unique constraint''
		 	WHEN ''V''  THEN ''View''
		 	WHEN ''X''  THEN ''Extended stored procedure''
		 	ELSE o.xtype  
		END AS ObjectType, 
		x.name	AS Owner,
		u.name	AS GranteeName,
		CASE s.protecttype
			WHEN 204 THEN ''Grant with grant''
		 	WHEN 205 THEN ''Grant''
		 	WHEN 206 THEN ''Deny''
		 	ELSE cast(s.protecttype as varchar)
		END AS GrantType, 
		CASE s.action
			 WHEN 26  THEN ''REFERENCES''
		 	 WHEN 178 THEN ''CREATE FUNCTION''
 		 	 WHEN 193 THEN ''SELECT''
		 	 WHEN 195 THEN ''INSERT''
		 	 WHEN 196 THEN ''DELETE''
		 	 WHEN 197 THEN ''UPDATE''
		 	 WHEN 198 THEN ''CREATE TABLE''
		 	 WHEN 203 THEN ''CREATE DATABASE''
		 	 WHEN 207 THEN ''CREATE VIEW''
		 	 WHEN 222 THEN ''CREATE PROCEDURE''
		 	 WHEN 224 THEN ''EXECUTE''
		 	 WHEN 228 THEN ''BACKUP DATABASE''
		 	 WHEN 233 THEN ''CREATE DEFAULT''
		 	 WHEN 235 THEN ''BACKUP LOG''
		 	 WHEN 236 THEN ''CREATE RULE''
		 	 ELSE cast(s.action as varchar)
		END AS Permission
FROM
		[' + @Server + '].[' + @Database + '].dbo.sysobjects o 
		LEFT JOIN [' + @Server + '].[' + @Database + '].dbo.syspermissions p on p.id   = o.id
		LEFT JOIN [' + @Server + '].[' + @Database + '].dbo.sysusers u on u.uid  = p.grantee
		LEFT JOIN [' + @Server + '].[' + @Database + '].dbo.sysusers x on x.uid  = o.uid
		LEFT JOIN [' + @Server + '].[' + @Database + '].dbo.sysprotects s on s.id = o.id and s.uid = u.uid 
WHERE 
	isnull(o.name,'''') = ''xp_cmdshell'' OR
	( u.name IS NOT NULL AND 
	  s.action IS NOT NULL AND
	  u.name not in 
	( ''public'', ''guest'', ''RepositoryUser'', ''TargetServersRole'', ''DatabaseMailUserRole'', 
	''db_dtsadmin'', ''db_dtsltduser'', ''db_dtsoperator'', ''RSExecRole'',
	''SQLAgentOperatorRole'', ''SQLAgentUserRole'', ''dc_admin'', ''dc_operator'', ''dc_proxy'', 
	''db_ssisadmin'', ''db_ssisoperator'', ''db_ssisltduser'', ''PolicyAdministratorRole'', 
	''ServerGroupAdministratorRole'', ''ServerGroupReaderRole'' ))'

PRINT @CMD
EXEC(@CMD)
END
GO



