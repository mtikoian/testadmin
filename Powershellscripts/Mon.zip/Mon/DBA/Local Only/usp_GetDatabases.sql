USE DBA
GO
IF OBJECT_ID( 'dbo.usp_GetDatabases' ) IS NOT NULL
	DROP PROCEDURE dbo.usp_GetDatabases 
GO
CREATE PROCEDURE dbo.usp_GetDatabases 
	@Server 	varchar(60) = @@ServerName,
	@Version	int = 2
AS
BEGIN
SET NOCOUNT ON
PRINT '    usp_GetDatabases - ' + @Server

DECLARE @SqlStmt	varchar( 2000 )

IF @Version <> 7
	begin
	SET @SqlStmt = 'exec [' + @Server + '].DBA.dbo.usp_GetDBAttributes'
	--PRINT @SqlStmt
	EXEC( @SqlStmt )
	end

IF @Version = 7
	begin
	SET @SqlStmt = 'INSERT INTO dbo.Databases( ServerName, DBName, ServDBId ) '
	SET @SqlStmt = @SqlStmt + 
	'SELECT ''' + @Server + ''', name, m.dbid
	FROM [' + @Server + '].master.dbo.sysdatabases m 
	WHERE name not in( ''Northwind'', ''pubs'' ) and 
		name not like ''AdventureWorks%'''
	--PRINT @SQLSTMT
	EXEC( @SqlStmt )
	end
ELSE
	begin
	SET @SqlStmt = 
	'INSERT INTO dbo.Databases( ServerName, DBName, ServDBId, RecoveryModel, Status) '
	SET @SqlStmt = @SqlStmt + 
	'SELECT ''' + @Server + ''', name, m.dbid, a.Model, a.Status 
	FROM [' + @Server + '].master.dbo.sysdatabases m 
	JOIN [' + @Server + '].DBA.dbo.DBAttributes a ON m.name = a.DBName
	WHERE name not in( ''Northwind'', ''pubs'' ) and 
		name not like ''AdventureWorks%'''
	--PRINT @SQLSTMT
	EXEC( @SqlStmt )
	end

UPDATE dbo.Databases
SET DBType = 
	CASE 
		WHEN DBName IN 
		( 'tempdb', 'master', 'msdb', 'model', 'distribution' ) THEN 'S'
		--WHEN DBName IN 
		--( 'DUMMY', 'TEST', 'Capacity_Repository', 'xarrival' ) THEN 'D'
		--WHEN DBName LIKE '%_Test%'	 THEN 'D'
		--WHEN DBName LIKE '%TempDB'	 THEN 'D'
		--WHEN DBName LIKE '%_Dev%'	 THEN 'D'
		--WHEN DBName LIKE '%_Staging%'	 THEN 'D'
		--WHEN DBName LIKE '%_backup%'     THEN 'D'
		--WHEN DBName LIKE '%LiteSpeed%'   THEN 'D'
		WHEN s.ServerType = 'S' THEN 'D'
		ELSE s.ServerType
	END
FROM dbo.Databases d JOIN dbo.Servers s ON d.ServerName = s.ServerName 
WHERE s.ServerName = @Server

exec DBA.dbo.usp_GetDatabaseTableCounts @Server, @Version

END
GO
