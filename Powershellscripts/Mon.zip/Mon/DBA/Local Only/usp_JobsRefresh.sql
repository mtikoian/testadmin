USE DBA
GO

IF OBJECT_ID( 'dbo.usp_JobsRefresh' ) IS NOT NULL
	DROP PROCEDURE dbo.usp_JobsRefresh
go

CREATE PROCEDURE dbo.usp_JobsRefresh
as
BEGIN
SET NOCOUNT ON
DECLARE SERVER_CUR CURSOR FOR
	SELECT ServerName, SQLVersion
	FROM DBA.dbo.Servers 
	WHERE ServerName NOT LIKE '*%' and ActiveFlag = 1
	
DECLARE
	@SQLSTMT	varchar( 1000 ),
	@ServerName	varchar( 50 ),
	@SQLVersion	int

OPEN SERVER_CUR
FETCH NEXT FROM SERVER_CUR INTO @ServerName, @SQLVersion
WHILE @@FETCH_STATUS = 0
	BEGIN
	SET @SQLSTMT = 'EXEC DBA.dbo.usp_GetJobs ''' + @ServerName + ''',' + cast(@SQLVersion as varchar) + ''''
	PRINT @SQLSTMT
	EXEC( @SQLSTMT )
	FETCH NEXT FROM SERVER_CUR INTO @ServerName, @SQLVersion
	END
CLOSE SERVER_CUR
DEALLOCATE SERVER_CUR

SELECT * FROM dbo.Jobs
ORDER BY CAST( RunDate as datetime ) desc, ServerName, RunTime
END
GO

