/***********************************************

		usp_Track_WaitStats and
		usp_Get_WaitStats

************************************************/

USE DBA
GO
IF OBJECT_ID( 'dbo.usp_Get_WaitStats' ) IS NOT NULL
	DROP PROCEDURE dbo.usp_Get_WaitStats
GO
CREATE PROCEDURE dbo.usp_Get_WaitStats
AS
/*******************************************************

		This stored procedure creates a WaitStats 
		report that lists wait types by percentage.
		You can run the procedure while 
		usp_Track_WaitStats ( see below ) is executing.

*********************************************************/

SET NOCOUNT ON
DECLARE
	@Now		datetime,
	@TotalWait	numeric(20,1),
	@EndTime	datetime,
	@BeginTime	datetime,
	@Hr			int,
	@Min		int,
	@Sec		int

SELECT 	
	@Now 		= MAX( Now ), 
	@BeginTime 	= MIN( Now ), 
	@EndTime 	= MAX( Now )
FROM WaitStats
WHERE [Wait Type] = 'Total'

-- Subtract WaitFor, Sleep, and Resource_Queue from Total.
SELECT @TotalWait = SUM([Wait Time]) + 1 FROM WaitStats
WHERE [Wait Type] NOT IN 
	( 'WAITFOR', 'SLEEP', 'RESOURCE_QUEUE', 'Total', '***total***' ) AND
	Now = @Now

-- Insert adjusted totals and rank by percentage in descending order.
DELETE FROM WaitStats WHERE [Wait Type] = '***total***' AND Now = @Now
INSERT INTO WaitStats
	SELECT '***total***', 0, @TotalWait, @TotalWait, @Now

SELECT
	[Wait Type], 
	[Wait Time], 
	Percentage = CAST( 100 * [Wait Time] / @TotalWait as numeric(20,1) )
FROM WaitStats
WHERE [Wait Type] NOT IN( 'WAITFOR', 'SLEEP', 'RESOURCE_QUEUE', 'Total' )
	AND Now = @Now
ORDER BY Percentage desc
GO

		

USE DBA
GO
IF OBJECT_ID( 'dbo.usp_Track_WaitStats' ) IS NOT NULL
	DROP PROCEDURE dbo.usp_Track_WaitStats
GO
CREATE PROCEDURE dbo.usp_Track_WaitStats
	( @Num_Samples 	int = 10,
	  @DelayNum	 	int = 1,
	  @DelayType	nvarchar(10) = 'minutes'
	)
AS
/*********************************************************

	@Num_Samples:   The number of times to capture
					waitstats; default 10 times.
	@DelayNum:		The delay interval; can be in
					minutes or seconds; default is 
					1 minute.
	@DelayType:		The time specified. Values are 
					"minutes" or "seconds."

************************************************************/

SET NOCOUNT ON
IF OBJECT_ID( 'dbo.WaitStats' ) IS NULL
	CREATE TABLE dbo.WaitStats
	(	[Wait Type]			varchar(80),
		Requests			numeric(20,1),
		[Wait Time]			numeric(20,1),
		[Signal Wait Time]	numeric(20,1),
		Now					datetime default GETDATE()
	)
ELSE
	TRUNCATE TABLE dbo.WaitStats

DBCC SQLPERF( WAITSTATS, CLEAR )  -- clear out waitstats

DECLARE
	@i			int,
	@Delay		varchar(8),
	@Dt			varchar(3),
	@Now		datetime,	
	@TotalWait	numeric(20,1),
	@EndTime	datetime,
	@BeginTime	datetime,
	@Hr			int,
	@Min		int,
	@Sec		int

SET @i = 1
SET	@Dt	=	
	CASE LOWER( @DelayType )
		WHEN 'minutes' 	THEN 'm'
		WHEN 'minute'	THEN 'm'
		WHEN 'min'		THEN 'm'
		WHEN 'mm'		THEN 'm'
		WHEN 'mi'		THEN 'm'
		WHEN 'm'		THEN 'm'
		WHEN 'seconds'	THEN 's'
		WHEN 'second'	THEN 's'
		WHEN 'sec'		THEN 's'
		WHEN 'ss'		THEN 's'
		WHEN 's'		THEN 's'
		ELSE @DelayType
	END
IF @Dt NOT IN ( 's', 'm' )
	begin
	PRINT 'Please supply delay type, e.g. seconds or minutes'
	RETURN
	end

IF @Dt = 's'
	begin
	SET @Sec	= @DelayNum % 60
	SET @Min	= CAST(( @DelayNum / 60 ) as int )
	SET @Hr		= CAST(( @Min / 60 ) as int )
	SET @Min	= @Min % 60
	end

IF @Dt = 'm'
	begin
	SET @Sec	= 0
	SET @Min	= @DelayNum % 60
	SET @Hr		= CAST(( @DelayNum / 60 ) as int )
	end

SET @Delay =	RIGHT( '0' + CONVERT( varchar(2), @Hr ), 2 ) +
			 	':' +
				RIGHT( '0' + CONVERT( varchar(2), @Min ), 2 ) +
				':' +
			 	RIGHT( '0' + CONVERT( varchar(2), @Sec ), 2 )

IF @Hr > 23 OR @Min > 59 OR @Sec > 59
	begin
	SELECT 'hh:mm:ss delay time cannot > 23:59:59'
	SELECT 'Delay interval and type:  ' + 
			CONVERT( varchar(10), @DelayNum ) +
			',' + @DelayType + ' converts to ' + @Delay
	RETURN
	end

WHILE ( @i <= @Num_Samples )
	begin
	INSERT INTO WaitStats
		( [Wait Type], Requests, [Wait Time], [Signal Wait Time] )
	EXEC ( 'DBCC SQLPERF( WAITSTATS )' )
	SET @i = @i + 1
	WAITFOR DELAY @Delay
	end
--  Create report
EXEC dbo.usp_Get_WaitStats
GO

			
