USE DBA
go
IF OBJECT_ID( 'dbo.usp_EraseServerData' ) IS NOT NULL
	DROP PROCEDURE dbo.usp_EraseServerData
go
CREATE PROCEDURE dbo.usp_EraseServerData  	@Server varchar(60) 
AS
BEGIN
SET NOCOUNT ON
-- This will take care of several tables because of 
-- delete cascades
DELETE FROM dbo.Databases 		WHERE ServerName = @Server
DELETE FROM dbo.Jobs 			WHERE ServerName = @Server
DELETE FROM dbo.Packages 		WHERE ServerName = @Server
DELETE FROM dbo.BlankLogins 		WHERE ServerName = @Server
DELETE FROM dbo.All_Free_Space 		WHERE ServerName = @Server
DELETE FROM dbo.User_Activity 		WHERE ServerName = @Server
DELETE FROM dbo.Schedules 		WHERE ServerName = @Server
DELETE FROM dbo.Users			WHERE ServerName = @Server

UPDATE dbo.Servers SET Started = 0, Finished = 0, Step = NULL
WHERE Servername = @Server
END 
GO

