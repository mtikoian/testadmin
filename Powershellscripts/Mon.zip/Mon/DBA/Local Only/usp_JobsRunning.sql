USE DBA
GO
IF OBJECT_ID( 'dbo.usp_JobsRunning' ) IS NOT NULL
	DROP PROCEDURE dbo.usp_JobsRunning
go
CREATE PROCEDURE dbo.usp_JobsRunning
AS
BEGIN
SET NOCOUNT ON
TRUNCATE TABLE DBA.dbo.RunningJobs

DECLARE SERVER_CUR CURSOR FOR 
	SELECT ServerName FROM DBA.dbo.Servers
	WHERE ServerName <> '*ALL' and ActiveFlag = 1 

DECLARE 
	@Server varchar(60),
	@cmd	varchar(1000)

OPEN SERVER_CUR
FETCH NEXT FROM SERVER_CUR INTO @Server
WHILE @@FETCH_STATUS = 0
	begin
	PRINT @Server
	SET @cmd = 'exec DBA.dbo.usp_GetRunningJobs ''' + @Server + ''''
	--PRINT @cmd
	EXEC( @cmd )
	FETCH NEXT FROM SERVER_CUR INTO @Server
	end
CLOSE SERVER_CUR
DEALLOCATE SERVER_CUR

SELECT * FROM dbo.RunningJobs ORDER BY Server
END
GO


