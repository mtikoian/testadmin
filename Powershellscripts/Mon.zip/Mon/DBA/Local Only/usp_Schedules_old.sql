USE DBA
GO

IF OBJECT_ID( 'dbo.usp_Schedules' ) IS NOT NULL
	DROP PROCEDURE dbo.usp_Schedules
go
CREATE PROCEDURE dbo.usp_Schedules 
	@Server	varchar(80) = @@ServerName,
	@Version int = 2
AS
BEGIN
SET NOCOUNT ON
PRINT '    usp_Schedules'

DECLARE @Cmd	varchar(6000)

IF @Version not in ( 7, 2 )
	SET @Cmd =
	'INSERT INTO DBA.dbo.Schedules
	(	ServerName, JobName, [Desc], Owner, Created, Modified,
		SchedName, Freq, [When], [Time], 
		NextRunDate, NextRunTime, MaintPlan, DTS, History, StepId, StepName ) 
	SELECT 
		''' + @Server + ''',
		REPLACE( REPLACE( REPLACE( j.name, ''for DB Maintenance Plan '', '''' ), 
				'' Job '', '''' ), ''Log Shipping'', ''LShip'') as JobName, 
		LEFT( ISNULL( j.description, '''' ), 512 ) as [Desc],  
		CASE WHEN l.name IS NOT NULL THEN l.name ELSE SUSER_SNAME(j.owner_sid) END as Owner, 
		j.date_created as Created,
		j.date_modified as Modified,
		ISNULL( s.name, '''' ) as SchedName,
		CASE s.freq_type
			WHEN 1 	THEN ''Once''
			WHEN 4 	THEN ''Daily''
			WHEN 8 	THEN ''Weekly''
			WHEN 16 THEN ''Monthly''
			WHEN 32 THEN ''Monthly''
			WHEN 64 THEN ''When SQL Server Agent starts''
			WHEN 128 THEN ''When computer is idle''
			ELSE cast(s.freq_type as varchar)
		END as Freq,
		CASE 
			WHEN s.freq_type = 4  THEN ''Every '' + cast( s.freq_interval as varchar ) + '' days''
			WHEN s.freq_type = 8  THEN cast( s.freq_interval as varchar )
			WHEN s.freq_type = 16 THEN ''On day '' +  cast( s.freq_interval as varchar )
			WHEN s.freq_type = 32 THEN 
				CASE s.freq_relative_interval
					WHEN 1	THEN ''Every first ''
					WHEN 2	THEN ''Every second ''
					WHEN 4	THEN ''Every third ''
					WHEN 8	THEN ''Every fourth ''
					WHEN 16 THEN ''Every last ''
					ELSE cast( s.freq_interval as varchar )
				END + 
				CASE s.freq_interval
					WHEN 1 	THEN ''Sunday''
					WHEN 2	THEN ''Monday''
					WHEN 3 	THEN ''Tuesday''
					WHEN 4  THEN ''Wednesday''
					WHEN 5 	THEN ''Thursday''
					WHEN 6 	THEN ''Friday''
					WHEN 7 	THEN ''Saturday''
					WHEN 8	THEN ''Day''
					WHEN 9	THEN ''Weekday''
					WHEN 10 THEN ''Weekend day''
					ELSE cast( s.freq_interval as varchar )
				END
			ELSE CAST( s.freq_type as varchar )
		END as [When],
		CASE s.freq_subday_type
			WHEN 1	THEN 
				CASE 
					WHEN js.next_run_time IS NULL THEN NULL
					ELSE
					LEFT( REPLICATE(''0'', 6 - LEN( cast( js.next_run_time as varchar ) ) )
					+ cast( js.next_run_time as varchar ), 2 ) + '':'' +
					SUBSTRING( REPLICATE(''0'', 6 - LEN( cast( js.next_run_time as varchar ) ) )
					+ cast( js.next_run_time as varchar ), 3, 2 ) + '':'' +
					RIGHT( REPLICATE(''0'', 6 - LEN( cast( js.next_run_time as varchar ) ) )
					+ cast( js.next_run_time as varchar ), 2 )
				END
			WHEN 2	THEN ''Every '' + cast( s.freq_subday_interval as varchar ) + '' Sec''
			WHEN 4	THEN ''Every '' + cast( s.freq_subday_interval as varchar ) + '' Min''
			WHEN 8	THEN ''Every '' + cast( s.freq_subday_interval as varchar ) + '' Hr''
			ELSE cast(s.freq_subday_type as varchar)
		END as [Time],
		CASE
			WHEN LEN( ISNULL( cast( js.next_run_date as varchar ), '''' ) ) = 8
			THEN
				SUBSTRING( cast( js.next_run_date as varchar ), 5, 2 ) + ''/'' + 
				RIGHT( cast( js.next_run_date as varchar ), 2 ) + ''/'' + 
				LEFT( cast( js.next_run_date as varchar ), 4 )
		END as NextRunDate,
		CASE
			WHEN js.next_run_time IS NULL THEN NULL
			ELSE
			LEFT( REPLICATE(''0'', 6 - LEN( cast( js.next_run_time as varchar ) ) )
				+ cast( js.next_run_time as varchar ), 2 ) + '':'' +
			SUBSTRING( REPLICATE(''0'', 6 - LEN( cast( js.next_run_time as varchar ) ) )
				+ cast( js.next_run_time as varchar ), 3, 2 ) + '':'' +
			RIGHT( REPLICATE(''0'', 6 - LEN( cast( js.next_run_time as varchar ) ) )
				+ cast( js.next_run_time as varchar ), 2 )
		END as NextRunTime,
		CASE WHEN m.job_id IS NOT NULL THEN 1 ELSE 0 END as MaintPlan,
		CASE WHEN dts.step_id IS NOT NULL THEN 1 ELSE 0 END as DTS,
		left(REPLACE( REPLACE( REPLACE( hist.History, '' '', '''' ), '''''''', '''' ), '','', '''' ), 10 ) as history,
		hist.step_id as StepId,
		LEFT( hist.step_name, 128 ) as StepName
	FROM [' + @Server + '].msdb.dbo.sysjobs j 
		LEFT JOIN [' + @Server + '].master.dbo.syslogins l on j.owner_sid = l.sid
		LEFT JOIN [' + @Server + '].msdb.dbo.syscategories c ON j.category_id = c.category_id 
		LEFT JOIN [' + @Server + '].msdb.dbo.sysjobschedules js ON j.job_id = js.job_id
		LEFT JOIN [' + @Server + '].msdb.dbo.sysschedules s ON js.schedule_id = s.schedule_id and s.enabled = 1
		LEFT JOIN 
		( SELECT job_id, max( step_id ) as step_id FROM [' + @Server + '].msdb.dbo.sysjobsteps 
	  	  WHERE command like ''DTSRun%'' GROUP BY job_id ) as dts ON dts.job_id = j.job_id
		LEFT JOIN 
		( SELECT job_id, step_id, step_name, '''' as history
		  FROM [' + @Server + '].msdb.dbo.sysjobsteps 
		) as hist ON hist.job_id = j.job_id
		LEFT JOIN [' + @Server + '].msdb.dbo.sysdbmaintplan_jobs m ON m.job_id = j.job_id
	WHERE j.enabled = 1 and c.category_class = 1'

ELSE
	SET @Cmd =
	'INSERT INTO DBA.dbo.Schedules
	(	ServerName, JobName, [Desc], Owner, Created, Modified,
		SchedName, Freq, [When], [Time], 
		NextRunDate, NextRunTime, MaintPlan, DTS, History, StepId, StepName ) 
	SELECT 
		''' + @Server + ''',
		REPLACE( REPLACE( REPLACE( j.name, ''for DB Maintenance Plan '', '''' ), 
				'' Job '', '''' ), ''Log Shipping'', ''LShip'') as JobName, 
		LEFT( ISNULL( j.description, '''' ), 512 ) as [Desc],  
		CASE WHEN l.name IS NOT NULL THEN l.name ELSE SUSER_SNAME(j.owner_sid) END as Owner, 
		j.date_created as Created,
		j.date_modified as Modified,
		ISNULL( s.name, '''' ) as SchedName,
		CASE s.freq_type
			WHEN 1 	THEN ''Once''
			WHEN 4 	THEN ''Daily''
			WHEN 8 	THEN ''Weekly''
			WHEN 16 THEN ''Monthly''
			WHEN 32 THEN ''Monthly''
			WHEN 64 THEN ''When SQL Server Agent starts''
			WHEN 128 THEN ''When computer is idle''
			ELSE cast(s.freq_type as varchar)
		END as Freq,
		CASE 
			WHEN s.freq_type = 4  THEN ''Every '' + cast( s.freq_interval as varchar ) + '' days''
			WHEN s.freq_type = 8  THEN cast( s.freq_interval as varchar )
			WHEN s.freq_type = 16 THEN ''On day '' +  cast( s.freq_interval as varchar )
			WHEN s.freq_type = 32 THEN 
				CASE s.freq_relative_interval
					WHEN 1	THEN ''Every first ''
					WHEN 2	THEN ''Every second ''
					WHEN 4	THEN ''Every third ''
					WHEN 8	THEN ''Every fourth ''
					WHEN 16 THEN ''Every last ''
					ELSE cast( s.freq_relative_interval as varchar )
				END + 
				CASE s.freq_interval
					WHEN 1 	THEN ''Sunday''
					WHEN 2	THEN ''Monday''
					WHEN 3 	THEN ''Tuesday''
					WHEN 4  THEN ''Wednesday''
					WHEN 5 	THEN ''Thursday''
					WHEN 6 	THEN ''Friday''
					WHEN 7 	THEN ''Saturday''
					WHEN 8	THEN ''Day''
					WHEN 9	THEN ''Weekday''
					WHEN 10 THEN ''Weekend day''
					ELSE cast( s.freq_interval as varchar )
				END
			ELSE cast(s.freq_type as varchar)
		END as [When],
		CASE s.freq_subday_type
			WHEN 1	THEN 
				CASE 
					WHEN s.next_run_time IS NULL THEN NULL
					ELSE
					LEFT( REPLICATE(''0'', 6 - LEN( cast( s.next_run_time as varchar ) ) )
					+ cast( s.next_run_time as varchar ), 2 ) + '':'' +
					SUBSTRING( REPLICATE(''0'', 6 - LEN( cast( s.next_run_time as varchar ) ) )
					+ cast( s.next_run_time as varchar ), 3, 2 ) + '':'' +
					RIGHT( REPLICATE(''0'', 6 - LEN( cast( s.next_run_time as varchar ) ) )
					+ cast( s.next_run_time as varchar ), 2 )
				END
			WHEN 2	THEN ''Every '' + cast( s.freq_subday_interval as varchar ) + '' Sec''
			WHEN 4	THEN ''Every '' + cast( s.freq_subday_interval as varchar ) + '' Min''
			WHEN 8	THEN ''Every '' + cast( s.freq_subday_interval as varchar ) + '' Hr''
			ELSE cast(s.freq_subday_type as varchar)
		END as [Time],
		CASE
			WHEN LEN( ISNULL( cast( s.next_run_date as varchar ), '''' ) ) = 8
			THEN
				SUBSTRING( cast( s.next_run_date as varchar ), 5, 2 ) + ''/'' + 
				RIGHT( cast( s.next_run_date as varchar ), 2 ) + ''/'' + 
				LEFT( cast( s.next_run_date as varchar ), 4 )
		END as NextRunDate,
		CASE
			WHEN s.next_run_time IS NULL THEN NULL
			ELSE
			LEFT( REPLICATE(''0'', 6 - LEN( cast( s.next_run_time as varchar ) ) )
				+ cast( s.next_run_time as varchar ), 2 ) + '':'' +
			SUBSTRING( REPLICATE(''0'', 6 - LEN( cast( s.next_run_time as varchar ) ) )
				+ cast( s.next_run_time as varchar ), 3, 2 ) + '':'' +
			RIGHT( REPLICATE(''0'', 6 - LEN( cast( s.next_run_time as varchar ) ) )
				+ cast( s.next_run_time as varchar ), 2 )
		END as NextRunTime,
		CASE WHEN m.job_id IS NOT NULL THEN 1 ELSE 0 END as MaintPlan,
		CASE WHEN dts.step_id IS NOT NULL THEN 1 ELSE 0 END as DTS,
		left(REPLACE( REPLACE( REPLACE( hist.History, '' '', '''' ), '''''''', '''' ), '','', '''' ), 10 ) as history,
		hist.step_id as StepId,
		LEFT( hist.step_name, 128 ) as StepName
	FROM [' + @Server + '].msdb.dbo.sysjobs j 
		JOIN [' + @Server + '].master.dbo.syslogins l on j.owner_sid = l.sid
		JOIN [' + @Server + '].msdb.dbo.syscategories c ON j.category_id = c.category_id 
		LEFT JOIN [' + @Server + '].msdb.dbo.sysoperators o ON j.notify_netsend_operator_id = o.id
		LEFT JOIN [' + @Server + '].msdb.dbo.sysjobschedules s ON s.job_id = j.job_id and s.enabled = 1
		LEFT JOIN 
		( SELECT job_id, max( step_id ) as step_id FROM [' + @Server + '].msdb.dbo.sysjobsteps 
	  	  WHERE command like ''DTSRun%'' GROUP BY job_id ) as dts ON dts.job_id = j.job_id
		LEFT JOIN 
		( SELECT job_id, step_id, step_name,
			CASE
				WHEN command like ''%-DelBkUps %''  THEN
					SUBSTRING( command, charindex( ''-DelBkUps '', command ) + 10, 
		    		charindex( ''-'', command, ( charindex( ''-DelBkUps '', command ) + 10 )) -
		 			( charindex( ''-DelBkUps '', command ) + 10 ) ) 
				WHEN command like ''%usp_DeleteDiffHistory %'' THEN
					LTRIM( right( command, charindex( '','', reverse(command), charindex( '','', reverse(command) ) + 1 ) -1 ))
				WHEN command like ''%usp_DeleteBakHistory %'' THEN
					LTRIM( right( command, charindex( '','', reverse(command), charindex( '','', reverse(command) ) + 1 ) -1 ))
				ELSE ''''
			END as history
		  FROM [' + @Server + '].msdb.dbo.sysjobsteps 
		) as hist ON hist.job_id = j.job_id
		LEFT JOIN [' + @Server + '].msdb.dbo.sysdbmaintplan_jobs m ON m.job_id = j.job_id
	WHERE j.enabled = 1 and c.category_class = 1'

--PRINT @Cmd
EXEC(@Cmd)
END
go

