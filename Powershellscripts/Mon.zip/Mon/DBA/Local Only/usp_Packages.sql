USE DBA
GO
IF OBJECT_ID( 'dbo.usp_Packages' ) IS NOT NULL
	DROP PROCEDURE dbo.usp_Packages 
go
CREATE PROCEDURE dbo.usp_Packages	
		@Server		sysname = @@Servername,
		@Version	int = 2
AS
BEGIN
SET NOCOUNT ON
PRINT '    usp_Packages - ' + @Server

DECLARE @Cmd	varchar(1000)
SET @Cmd =
'INSERT INTO dbo.Packages( ServerName, PkgName, Description, Created, LastModified, Owner )
	SELECT ''' + @Server + ''', p.name, 
	CASE WHEN d.description like ''DTS package description%'' THEN ''''
         ELSE d.description END, 
	p.Created, p.LastModified, d.owner
	FROM [' + @Server + '].msdb.dbo.sysdtspackages d
		join
		( 	select name, min(createdate) as Created, max(createdate) as LastModified
			from [' + @Server + '].msdb.dbo.sysdtspackages
			group by name
		) as p on 	d.name = p.name and 
			  	d.createdate = p.LastModified 
	WHERE ''' + @Server + ''' + p.name NOT IN (SELECT ServerName + PkgName FROM dbo.Packages)'
--PRINT @Cmd
EXEC( @Cmd )

IF @Version not in ( 7, 2 )
SET @Cmd =
'INSERT INTO dbo.Packages( ServerName, PkgName, Description, Created, LastModified, Owner )
	SELECT ''' + @Server + ''', p.name, 
	CASE WHEN d.description like ''DTS package description%'' THEN ''''
         ELSE d.description END, 
	p.Created, p.LastModified, d.owner
	FROM [' + @Server + '].msdb.dbo.sysmaintplan_plans d
		join
		( 	select name, min(create_date) as Created, max(create_date) as LastModified
			from [' + @Server + '].msdb.dbo.sysmaintplan_plans
			group by name
		) as p on 	d.name = p.name and 
			  	d.create_date = p.LastModified
	WHERE ''' + @Server + ''' + p.name NOT IN (SELECT ServerName + PkgName FROM dbo.Packages)'
--PRINT @Cmd
EXEC( @Cmd )

-- This will pick up the jobs or job steps whose names match a package name
-- The DTSRun command itself may be encrypted
SET @Cmd =
'UPDATE dbo.Packages SET Job = 1 
WHERE ServerName = ''' + @Server + ''' and 
PKGName IN ( SELECT name FROM [' + @Server + '].msdb.dbo.sysjobs UNION 
SELECT step_name FROM [' + @Server + '].msdb.dbo.sysjobsteps )'
--PRINT @Cmd
EXEC( @Cmd )

-- This will pick up the job steps where the package name is not encrypted
SET @Cmd =
'UPDATE dbo.Packages SET Job = 1
WHERE ServerName = ''' + @Server + ''' and 
EXISTS ( SELECT * FROM [' + @Server + '].msdb.dbo.sysjobsteps 
WHERE  command LIKE ''DTSRUN%'' and command like ''%'' + PKGName + ''%'' )'
--PRINT @Cmd
EXEC( @Cmd )

IF @Version <> 7
	begin
	SET @Cmd = 
	'INSERT INTO DBA.dbo.PackageSteps
	(	Stepname, Errorcode, ProgressCount, 
		Starttime, Endtime, Elapsedtime, ErrorDescription, PkgId )
	SELECT
		s.stepname, s.errorcode, s.progresscount, 
		s.starttime, s.endtime, s.elapsedtime, s.errordescription, p.Id
	FROM
		[' + @Server + '].msdb.dbo.sysdtspackagelog L
		JOIN ( 	SELECT id, max( starttime) as maxstart 
				FROM [' + @Server + '].msdb.dbo.sysdtspackagelog
		  		GROUP BY id ) as LL on LL.id = L.id
		JOIN DBA.dbo.Packages p on p.ServerName = ''' + @Server + ''' and p.PkgName = L.name
		LEFT JOIN [' + @Server + '].msdb.dbo.sysdtssteplog s on L.lineagefull = s.lineagefull 
	WHERE L.starttime = LL.maxstart
	ORDER BY name, s.starttime'
	--PRINT @Cmd
	EXEC( @Cmd )
	end
END
go

