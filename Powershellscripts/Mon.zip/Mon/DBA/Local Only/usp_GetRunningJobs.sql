USE DBA
GO
IF OBJECT_ID( 'dbo.usp_GetRunningJobs' ) IS NOT NULL
	DROP PROCEDURE dbo.usp_GetRunningJobs
GO
CREATE PROCEDURE dbo.usp_GetRunningJobs  
		@Server varchar(60)
AS
BEGIN
SET NOCOUNT ON
PRINT 'usp_GetRunningJobs - ' + @Server

DECLARE @SQL  varchar(1000)

SET @SQL ='[' + @Server + '].DBA.dbo.usp_GetAgentJobs'
--PRINT @SQL
EXEC(@SQL)

SET @SQL = 'INSERT INTO dbo.RunningJobs( Server, JobName, Date ) 
	SELECT ''' + @Server + ''', name, getdate() FROM [' + @Server + '].DBA.dbo.Agent_Jobs a 
	JOIN [' + @Server + '].msdb.dbo.sysjobs j ON a.job_id = j.job_id 
	WHERE running = 1'
--PRINT @SQL
EXEC(@SQL)
END
go


