USE DBA
go
IF OBJECT_ID( 'usp_GetJobs' ) IS NOT NULL
	DROP PROCEDURE usp_GetJobs
go

CREATE PROCEDURE usp_GetJobs 
		@Server varchar( 50 ) = @@ServerName,
		@Version int = 2
AS
BEGIN
SET NOCOUNT ON
PRINT '    usp_GetJobs'

DECLARE 
	@varcharDateToday char( 10 ),
	@SQLStmt	varchar( 6000 )
	
SET @varcharDateToday = CONVERT( char( 10 ), GETDATE(), 101 )
PRINT 'Server:  ' + @Server


SET @SQLStmt = 
	'INSERT INTO DBA.dbo.Jobs
	( 	ServerName, Originating_Server, JobName, Status, 
	  	RunDate, RunTime, RunDuration, RunDatetime, DateModified, 
        	LogFileName, Message, Description, MaintPlan, DTS, Scheduled, 
	OldJobName )
 		SELECT ''' + @Server + ''', ' +
		CASE @Version WHEN 5 THEN '''2005'', '
			      WHEN 8 THEN '''2008'', '
			      WHEN 2 THEN '''2000'', '
			      --ELSE ''''', '
			      ELSE '''' + CAST(@version as varchar) + ''', '
		END +
		'REPLACE( REPLACE( REPLACE( sj.name, ''for DB Maintenance Plan '', '''' ), '' Job '', '''' ), ''Log Shipping'', ''LShip''),
		CASE sjh.run_status
			WHEN 0 THEN ''Failed''
			WHEN 1 THEN ''Succeeded''
			WHEN 2 THEN ''Retry''
			WHEN 3 THEN ''Canceled''
			WHEN 4 THEN ''In Progress''
			ELSE ''Unknown''
		END,
		sjh.RunDate,
		sjh.RunTime,
		sjh.Duration,
		sjh.RunDateTime,
		sj.date_modified,
		sjs.output_file_name,
		sjh.Message,
		sj.description,
		CASE WHEN m.job_id IS NOT NULL THEN 1 
		     WHEN sj.category_id = 3 THEN 1
		     WHEN sjs.command like ''%Maintenance Plans%'' THEN 1
		     ELSE 0 
		END as MaintPlan,
		CASE WHEN dts.step_id IS NOT NULL THEN 1 ELSE 0 END as DTS,
		CASE WHEN s.schedule_id IS NOT NULL THEN 1 ELSE 0 END as Scheduled,
		sj.name as OldJobName
 	FROM [' + @Server + '].msdb.dbo.sysjobs sj 
		JOIN 
		( SELECT job_id, step_id, run_status,
			SUBSTRING( CAST( run_date AS char(8)), 5, 2 ) + ''/'' + 
				RIGHT( CAST( run_date AS char(8)),2 ) + ''/'' +
				LEFT( CAST( run_date AS char(8)), 4 ) 
			as RunDate,
			LEFT( RIGHT( ''000000'' + CAST( run_time AS varchar(10)), 6 ), 2 ) + '':'' +
				SUBSTRING( RIGHT( ''000000'' + CAST( run_time AS varchar(10)), 6 ), 3, 2 ) + '':'' +
				RIGHT( RIGHT( ''000000'' + CAST( run_time AS varchar(10)), 6 ), 2 )
			as RunTime,
			LEFT( RIGHT( ''000000'' + CAST( run_duration AS varchar(10)), 6 ), 2 ) + '':'' +
				SUBSTRING( RIGHT( ''000000'' + CAST( run_duration AS varchar(10)), 6 ),3, 2 ) + '':'' +
				RIGHT( RIGHT( ''000000'' + CAST( run_duration AS varchar(10)), 6 ), 2 )
			as Duration,
			dbo.udf_HistoryDateTime (run_date, run_time) as RunDateTime,
			RIGHT( message, len( message ) - charindex( ''.'', message ) - 2 ) as Message
		   FROM [' + @Server + '].msdb.dbo.sysjobhistory 
		) as sjh ON sj.job_id = sjh.job_id and sjh.step_id = 0 
		JOIN [' + @Server + '].msdb.dbo.sysjobsteps sjs  ON sj.job_id = sjs.job_id and 
				sjs.step_id = 1  -- get log file name only
		LEFT JOIN ( SELECT job_id, max( step_id ) as step_id FROM [' + @Server + '].msdb.dbo.sysjobsteps 
		    WHERE command like ''DTSRun%'' or subsystem = ''SSIS'' GROUP BY job_id ) 
			as dts ON dts.job_id = sj.job_id
		LEFT JOIN [' + @Server + '].msdb.dbo.sysdbmaintplan_jobs m ON m.job_id = sj.job_id
		LEFT JOIN ( SELECT job_id, MAX( schedule_id ) as schedule_id FROM [' + @Server + '].msdb.dbo.sysjobschedules
			 GROUP BY job_id ) AS s ON s.job_id = sj.job_id
 	WHERE
	-- No jobs older than 1 month
		sjh.RunDateTime > DATEADD( M, -1, GETDATE() ) AND 
		sjh.RunDateTime > ( SELECT ISNULL( max( RunDatetime ), CAST( ''01/01/95'' AS datetime ) )
			FROM DBA.dbo.Jobs WHERE ServerName = ''' + @Server + ''')' 

--PRINT @SQLStmt
EXEC ( @SQLStmt )

-- Get the disabled jobs

SET @SQLStmt = 
	'INSERT INTO dbo.Jobs
		( ServerName, Originating_Server, JobName, Status, RunDate, RunTime, 
	  	  RunDuration, RunDatetime, DateModified, Description, OldJobName )
	SELECT
		''' + @Server + ''', ' +
		CASE @Version WHEN 5 THEN '''2005'', '
			      WHEN 8 THEN '''2008'', '
			      WHEN 2 THEN '''2000'', '
			      --ELSE ''''', '
			      ELSE '''' + CAST(@version as varchar) + ''', '
		END +
		'REPLACE( REPLACE( REPLACE( sj.name, ''for DB Maintenance Plan '', '''' ), '' Job '', '''' ), ''Log Shipping'', ''LShip''),
		''Disabled'',
		''' + @varcharDateToday + ''',
		NULL,
		NULL,
		''' + @varcharDateToday + ''',
		sj.date_modified,
		sj.description,
		sj.name
	FROM 
		[' + @Server + '].msdb.dbo.sysjobs sj 
	WHERE
		-- Only disabled jobs
		sj.enabled = 0 AND NOT EXISTS
		( SELECT * FROM DBA.dbo.Jobs t 
		  WHERE ServerName = ''' + @Server + ''' and 
		  RunDatetime = ''' + @varcharDateToday + ''' and OldJobName = sj.name )'

--PRINT @SQLStmt
EXEC ( @SQLStmt )
END
GO

