use DBA

go
IF OBJECT_ID('dbo.usp_ChangeJobOwnerAll') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.usp_ChangeJobOwnerAll

END
go

CREATE PROCEDURE dbo.usp_ChangeJobOwnerAll
as
BEGIN

DECLARE @SqlStmt	varchar( 2000 )
DECLARE @Server		varchar(60)

DECLARE	SERVER_CUR CURSOR FOR
	SELECT ServerName
	FROM DBA.dbo.Servers 
	WHERE ServerName NOT LIKE '*%' and ActiveFlag = 1 and SQLVersion <> 7
	ORDER BY ServerName

OPEN SERVER_CUR
FETCH NEXT FROM SERVER_CUR INTO @Server

WHILE @@FETCH_STATUS = 0
	begin
	print ' Server - ' + @Server

	-- Get orphan logins from each server

	SET @SqlStmt = ' exec [' + @Server + '].[DBA].[dbo].[usp_usp_ChangeJobOwner] '
	PRINT @SqlStmt
	EXEC (@SqlStmt)

	FETCH NEXT FROM ORPH_CUR INTO @Server
	end

CLOSE SERVER_CUR
DEALLOCATE SERVER_CUR


end




GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

