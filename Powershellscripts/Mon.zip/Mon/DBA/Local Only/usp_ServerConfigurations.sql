USE DBA
GO

IF OBJECT_ID('dbo.usp_ServerConfigurations') IS NOT NULL
	DROP PROCEDURE dbo.usp_ServerConfigurations
go
CREATE PROCEDURE dbo.usp_ServerConfigurations
@ServerName	varchar(60)
AS

DECLARE @cmd varchar(3000)

SET @cmd = 
'INSERT INTO dbo.ServerConfigurations( ServerName, Name, Mininum, Maximum, Config_Value, Run_Value )
	SELECT @ServerName, Name, Minimum, Maximum, Config_Value, Run_Value
	FROM [' + @ServerName + '].DBA.dbo.ServerConfigs'
EXEC(@cmd)
GO




