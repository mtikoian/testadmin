use dba
go

if object_id(N'[dbo].[CollectOrphanLogin]') is not null
drop table [dbo].[CollectOrphanLogin]
GO

CREATE TABLE [dbo].[CollectOrphanLogin] (
	[ServerName] [varchar] (60) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[OrphanLogin] [varchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[SID] [varbinary] (85) NULL 
) ON [PRIMARY]
GO