USE DBA
GO
IF OBJECT_ID( 'dbo.usp_GetDatabaseTableCounts' ) IS NOT NULL
	DROP PROCEDURE dbo.usp_GetDatabaseTableCounts
go
CREATE PROCEDURE dbo.usp_GetDatabaseTableCounts  
	@Server 	varchar(60) = @@ServerName,
	@Version	int = 2
AS
BEGIN
SET NOCOUNT ON
PRINT '    usp_GetDatabaseTableCounts - ' + @Server

DECLARE TABLE_CURS CURSOR FOR
	SELECT DBname, DBId
	FROM DBA.dbo.Databases
	WHERE ServerName = @Server and DBType <> 'S' 
		and DBName <> 'SRP.NA.BLACKBERRY.NET'

DECLARE @DB	varchar(120),
	@DBId	int,
	@cmd	varchar(2000)

OPEN TABLE_CURS
FETCH NEXT FROM TABLE_CURS INTO @DB, @DBId
WHILE @@FETCH_STATUS = 0
	BEGIN
	if @Version in ( 7, 2 )
	    SET @cmd = 
		'UPDATE DBA.dbo.Databases SET NumTables =
		( SELECT count(*) FROM [' + @Server + '].[' + @DB + '].dbo.sysobjects
	  	  WHERE xtype in ( ''U'', ''V'') )
		  WHERE DBId = ' + cast( @DBId as varchar )
	else
	    SET @cmd = 
		'UPDATE DBA.dbo.Databases SET NumTables =
		( SELECT count(*) FROM [' + @Server + '].[' + @DB + '].sys.sysobjects
	  	  WHERE xtype in( ''U'', ''V'' ) )
		  WHERE DBId = ' + cast( @DBId as varchar )
	--PRINT @cmd
	EXEC( @cmd )
	FETCH NEXT FROM TABLE_CURS INTO @DB, @DBId
	END
CLOSE TABLE_CURS
DEALLOCATE TABLE_CURS
END
GO
