USE DBA
GO
IF OBJECT_ID( 'dbo.udf_HistoryDateTime' ) IS NOT NULL
	DROP FUNCTION dbo.udf_HistoryDateTime 
GO

CREATE FUNCTION dbo.udf_HistoryDateTime 
	(@hdate int, @htime int)

	-- Takes the integer values for date and time 
    	-- and returns a combined datetime value

RETURNS datetime
AS
BEGIN
DECLARE @xtime	char(06)

SET @xtime = Replicate('0', 6 - len(cast( @htime as varchar ))) 
	+ cast( @htime as varchar )

RETURN
cast
((
	SUBSTRING(cast(@hdate as char(8)), 5, 2 ) 
	+ '/' 
	+ RIGHT(cast(@hdate as char(8)), 2) 
	+ '/' 
	+ LEFT(cast(@hdate as char(8)), 4) 
	+ ' ' 
	+ LEFT( @xtime, 2 )
	+ ':' 
	+ SUBSTRING( @xtime, 3, 2 )
	+ ':' 
	+ RIGHT( @xtime, 2 )
) as datetime )
END
GO



