use DBA
go
IF OBJECT_ID( 'dbo.usp_ExportPermissions' ) IS NOT NULL
	DROP PROCEDURE dbo.usp_ExportPermissions
go
CREATE PROCEDURE dbo.usp_ExportPermissions 
	@ServerType char(1) = '*'
AS
BEGIN
SET NOCOUNT ON

DECLARE @rtn	int

CREATE TABLE #TEMP
(
	job_id uniqueidentifier ,
	job_name sysname ,
	run_status int ,
	run_date int ,
	run_time int ,
	run_duration int ,
	operator_emailed nvarchar(20) ,
	operator_netsent nvarchar(20), 
	operator_paged nvarchar(20) ,
	retries_attempted int ,
	server nvarchar(30) 
)

SET @rtn = 0

IF @ServerType = 'A' and OBJECT_ID( 'dbo.ExportAuditPermissions' ) IS NOT NULL 	
	DROP TABLE dbo.ExportAuditPermissions
ELSE IF OBJECT_ID( 'dbo.ExportPermissions' ) IS NOT NULL 
	DROP TABLE dbo.ExportPermissions
	

DECLARE 
	@DTSCommand varchar(300),
	@SQLCmd		varchar(1000)


IF @ServerType <> 'A'
	begin
	SET @SQLCmd = 
	'SELECT DISTINCT
	p.ServerName, Login, 
	CASE Sys WHEN ''N'' THEN '''' ELSE Sys END as SysAdmin, 
	CASE Security WHEN ''N'' THEN '''' ELSE Security END as Security, 
	CASE p.Server WHEN ''N'' THEN '''' ELSE p.Server END as Server, 
	CASE Setup WHEN ''N'' THEN '''' ELSE Setup END as Setup,  
	CASE Process WHEN ''N'' THEN '''' ELSE Process END as Process, 
	CASE [Disk] WHEN ''N'' THEN '''' ELSE [Disk] END as [Disk], 
	CASE DBCreator WHEN ''N'' THEN '''' ELSE DBCreator END as DBCreator
	INTO dbo.ExportPermissions
	FROM dbo.ServerPermissions p join Servers s on p.ServerName = s.ServerName 
	left join 
	( SELECT DISTINCT Server, Audited FROM dbo.Applications_Supported 
	  WHERE Audited = 1 ) as a on s.ServerName = a.Server 
	WHERE ServerType = ''' + @ServerType + ''''
	print @sqlcmd
	EXEC( @SQLCmd )
	--EXEC master..xp_cmdshell 'DTSRun /S "(local)" /N "Daily Check - Export Server Permissions" /E '
	exec msdb.dbo.sp_start_job 'DailyCheck - Export Server Permissions'
	end
ELSE 
	begin	
	SET @SQLCmd = 
	'SELECT DISTINCT Application,
	p.ServerName, Login, 
	CASE Sys WHEN ''N'' THEN '''' ELSE Sys END as SysAdmin, 
	CASE Security WHEN ''N'' THEN '''' ELSE Security END as Security, 
	CASE p.Server WHEN ''N'' THEN '''' ELSE p.Server END as Server, 
	CASE Setup WHEN ''N'' THEN '''' ELSE Setup END as Setup,  
	CASE Process WHEN ''N'' THEN '''' ELSE Process END as Process, 
	CASE [Disk] WHEN ''N'' THEN '''' ELSE [Disk] END as [Disk], 
	CASE DBCreator WHEN ''N'' THEN '''' ELSE DBCreator END as DBCreator
	INTO dbo.ExportAuditPermissions
	FROM dbo.ServerPermissions p join Servers s on p.ServerName = s.ServerName 
	left join 
	( SELECT DISTINCT Server, Audited, Application FROM dbo.Applications_Supported 
	  WHERE Audited = 1 ) as a on s.ServerName = a.Server 
	WHERE Audited = 1'
	print @sqlcmd
	EXEC( @SQLCmd )
	--EXEC master..xp_cmdshell 'DTSRun /S "(local)" /N "Daily Check - Export Audited Server Permissions" /E '
	exec msdb.dbo.sp_start_job 'DailyCheck - Export Server Permissions'
	end
WAITFOR DELAY '000:00:05' -- Give the job a chance to complete
INSERT INTO #TEMP EXEC msdb.dbo.sp_help_jobhistory @job_name = 'DailyCheck - Export Server Permissions'

WHILE @@ROWCOUNT = 0
  BEGIN
  WAITFOR DELAY '000:00:05' -- Give the job a chance to complete
  INSERT INTO #TEMP EXEC msdb.dbo.sp_help_jobhistory @job_name = 'DailyCheck - Export Server Permissions'
  END

SELECT @rtn = max(run_status) FROM #TEMP
IF @rtn <> 1 SET @rtn = -1
RETURN @rtn
END
GO