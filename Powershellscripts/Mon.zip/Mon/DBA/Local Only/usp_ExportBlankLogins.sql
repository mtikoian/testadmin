use DBA
go
IF OBJECT_ID( 'dbo.usp_ExportBlankLogins' ) IS NOT NULL
	DROP PROCEDURE dbo.usp_ExportBlankLogins
go
CREATE PROCEDURE dbo.usp_ExportBlankLogins
	@ServerType		char(1) = '*'
AS
BEGIN
SET NOCOUNT ON
DECLARE @rtn	int

CREATE TABLE #TEMP
(
	job_id uniqueidentifier ,
	job_name sysname ,
	run_status int ,
	run_date int ,
	run_time int ,
	run_duration int ,
	operator_emailed nvarchar(20) ,
	operator_netsent nvarchar(20), 
	operator_paged nvarchar(20) ,
	retries_attempted int ,
	server nvarchar(30) 
)

SET @rtn = 0

IF OBJECT_ID( 'dbo.ExportBlankLogins' ) IS NOT NULL
	DROP TABLE dbo.ExportBlankLogins

DECLARE 
	@DTSCommand varchar(300),
	@SQLCmd		varchar(1000)

SET @SQLCmd = 
'SELECT l.ServerName, Login 
INTO dbo.ExportBlankLogins
FROM dbo.BlankLogins l JOIN dbo.SERVERS s
ON l.ServerName = s.ServerName 
LEFT JOIN ( SELECT DISTINCT Server, Audited FROM dbo.Applications_Supported 
WHERE Audited = 1 ) as a on s.ServerName = a.Server
'
IF @ServerType IN ( 'P', 'D' ) 
	SET @SQLCmd = @SQLCmd + ' WHERE s.ServerType = ''' + @ServerType + ''''
ELSE IF @ServerType = 'A'
	SET @SQLCmd = @SQLCmd + ' WHERE a.Audited = 1'

print @sqlcmd
EXEC( @SQLCmd )

--EXEC master..xp_cmdshell 'DTSRun /S "(local)" /N "Daily Check - Export No Passwords" /E '
exec msdb.dbo.sp_start_job 'DailyCheck - Export Blank Logins'
WAITFOR DELAY '000:00:05' -- Give the job a chance to complete
INSERT INTO #TEMP EXEC msdb.dbo.sp_help_jobhistory @job_name = 'DailyCheck - Export Blank Logins'

WHILE @@ROWCOUNT = 0
  BEGIN
  WAITFOR DELAY '000:00:05' -- Give the job a chance to complete
  INSERT INTO #TEMP EXEC msdb.dbo.sp_help_jobhistory @job_name = 'DailyCheck - Export Blank Logins'
  END

SELECT @rtn = max(run_status) FROM #TEMP
IF @rtn <> 1 SET @rtn = -1
RETURN @rtn
END
GO