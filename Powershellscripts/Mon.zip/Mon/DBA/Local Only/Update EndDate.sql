UPDATE DBA.dbo.MaintenancePlans
SET EndDate =
	CASE len(Duration)
		WHEN 1 THEN dateadd(ss, cast(Duration as int), [Date] )	
		WHEN 2 THEN dateadd(ss, cast(run_duration as int), [Date] )
		WHEN 3 THEN dateadd(ss, 
				(cast(left( run_duration, 1) as int) * 60) 
				+ cast(right(run_duration, 2 ) as int), [Date] ) 
		WHEN 4 THEN dateadd(ss, 
				(cast(left(run_duration, 2) as int) * 60 )
				+ cast(right(run_duration, 2 ) as int), [Date] )	
		WHEN 5 THEN dateadd(ss, 
				(cast(left(run_duration, 1) as int) * 3600)
				+ (cast(left(run_duration, 2) as int) * 60 )
				+ cast(right(run_duration, 2 ) as int), [Date] )
	        WHEN 6 THEN dateadd(ss, (cast(left(run_duration, 2) as int) * 3600)
				+ (cast(left(run_duration, 2) as int) * 60 )
				+ cast(right(run_duration, 2 ) as int), [Date] )
		END as EndTime
WHERE 	
	EndDate IS NULL and Duration IS NOT NULL