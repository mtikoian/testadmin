if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_CollectOrphanLogins]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_CollectOrphanLogins]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO



CREATE   PROCEDURE [dbo].[usp_CollectOrphanLogins] 
AS
BEGIN
SET NOCOUNT ON	
	


DECLARE @SqlStmt	varchar( 2000 )
DECLARE @Server		varchar(60)
DECLARE	@Version	int 

DECLARE	ORPH_CUR CURSOR FOR
	SELECT ServerName, SQLVersion
	FROM DBA.dbo.Servers 
	WHERE ServerName not LIKE '*%' and ActiveFlag = 1 and SQLVersion <> 7
	ORDER BY ServerName


truncate table [DBA].dbo.CollectOrphanLogin

OPEN ORPH_CUR
FETCH NEXT FROM ORPH_CUR INTO @Server, @Version

PRINT 'usp_CollectOrphanLogins - ' + @Server

WHILE @@FETCH_STATUS = 0
	begin
	print ' Server - ' + @Server

	
	-- Get orphan logins from each server

	SET @SqlStmt = 'INSERT into [DBA].dbo.CollectOrphanLogin (ServerName,  SID, OrphanLogin) SELECT '
	SET @SqlStmt = @SqlStmt + '''' + @Server + ''''
	SET @SqlStmt = @SqlStmt + ', SID, [NT Login] FROM OPENROWSET(''SQLoledb'',''Server=' + @Server + ';Trusted_Connection=yes;'', '
	SET @SqlStmt = @SqlStmt + '''set fmtonly off exec sp_validatelogins'')'
	PRINT @SQLStmt
	
	EXEC( @SqlStmt )

	FETCH NEXT FROM ORPH_CUR INTO @Server, @Version
	end

CLOSE ORPH_CUR
DEALLOCATE ORPH_CUR


end






GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

