IF OBJECT_ID( 'dbo.usp_CreateFTPParamFile' ) IS NOT NULL
	DROP PROCEDURE dbo.usp_CreateFTPParamFile
GO
CREATE PROCEDURE dbo.usp_CreateFTPParamFile
	@FTPServer  varchar(200),
	@Login		varchar(100),
	@Pwd		varchar(100),
	@ChgPath	varchar(200) = NULL,  -- folder to change to at FTP site
	@FileToFTP	varchar(200),  -- provide full path of file
	@ParamFile	varchar(200)   -- provide full path of file
AS
BEGIN
SET NOCOUNT ON
DECLARE @text1	varchar(500)

SET @text1 = 'echo ' + @FTPServer + '>' + @ParamFile
EXEC master.dbo.xp_cmdshell @text1
SET @text1 = 'echo ' + @Login + '>>' + @ParamFile
EXEC master.dbo.xp_cmdshell @text1
SET @text1 = 'echo ' + @Pwd + '>>' + @ParamFile
EXEC master.dbo.xp_cmdshell @text1
if @ChgPath is not null
	begin
	SET @text1 = 'echo cd ' + @ChgPath + '>>' + @ParamFile
	EXEC master.dbo.xp_cmdshell @text1
	end
SET @text1 = 'echo mput ' + @FileToFTP + '>>' + @ParamFile
EXEC master.dbo.xp_cmdshell @text1
SET @text1 = 'echo quit >>' + @ParamFile
EXEC master.dbo.xp_cmdshell @text1
END
GO

