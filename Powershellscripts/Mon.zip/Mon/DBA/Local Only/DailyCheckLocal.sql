if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[VerifyRequest]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[VerifyRequest]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_AdjustedUsers]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_AdjustedUsers]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_AllDBAttributes]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_AllDBAttributes]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_AllUserList]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_AllUserList]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_BlankLogins]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_BlankLogins]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_BlankPwd]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_BlankPwd]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_CreateFTPParamFile]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_CreateFTPParamFile]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_EraseServerData]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_EraseServerData]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_ExportApps]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_ExportApps]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_ExportBlankLogins]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_ExportBlankLogins]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_ExportJobs]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_ExportJobs]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_ExportMonthlyAudit]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_ExportMonthlyAudit]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_ExportPermissions]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_ExportPermissions]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_ExportSchedules]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_ExportSchedules]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_ExportServers]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_ExportServers]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_ExportUsers]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_ExportUsers]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_GetDatabaseAttributes]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_GetDatabaseAttributes]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_GetDatabaseFiles]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_GetDatabaseFiles]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_GetDatabaseSizes]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_GetDatabaseSizes]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_GetDatabases]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_GetDatabases]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_GetJobs]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_GetJobs]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_GetLastBackups]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_GetLastBackups]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_GetRunningJobs]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_GetRunningJobs]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_GetTodaysZipFileName]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_GetTodaysZipFileName]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_GetUserDatabaseList]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_GetUserDatabaseList]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_Get_DbStats3]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_Get_DbStats3]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_Get_WaitStats]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_Get_WaitStats]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_HelpIndexes]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_HelpIndexes]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_JobsRefresh]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_JobsRefresh]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_JobsRunning]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_JobsRunning]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_MaintenancePlans]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_MaintenancePlans]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_Packages]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_Packages]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_PhysicalDefrag]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_PhysicalDefrag]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_RecoveryModel]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_RecoveryModel]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_RefreshActivity]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_RefreshActivity]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_RefreshFreeSpace]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_RefreshFreeSpace]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_RefreshRunningJobs]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_RefreshRunningJobs]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_RunningJobs]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_RunningJobs]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_SaveServerFreespace]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_SaveServerFreespace]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_Schedules]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_Schedules]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_ServerPermissions]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_ServerPermissions]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_SetDaysForSchedule]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_SetDaysForSchedule]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_Showcontig_All]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_Showcontig_All]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_SynchronizeUsers]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_SynchronizeUsers]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_Track_WaitStats]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_Track_WaitStats]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_Users]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_Users]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_get_dbstats2ForEachDB]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_get_dbstats2ForEachDB]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_UserList3]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_UserList3]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

/*
 * VerifyRequestTransfer - run a command that looks for @filename in the output
 *
 *  Author: Bill Twomey, Database Solutions
 * 
 *  This proc looks for a file matching 'Orders.%' in the output of an ftp command.
 *  The output message reports success/failure of transfer. 
 *  A return code of 1 indicates success
 *  Return code = 0 indicates failure.
 * 
 *  How it Works:
 *  ftp is executed using @ftpcommandfile as input to the -s parameter.  
 *  The output of ftp is written to a table
 *  The table is cleared of garbage records
 *  The count of records matching @filename is checked
 *  if the count = 1 then there success!
 */
CREATE  proc VerifyRequest 
	@filename varchar(200), 
	@ftpcommandfile varchar(1000)
as

	declare @rc int
	declare  @rows int, @errcode int, @rows2 int
	set @rc = 0
	set @rows = -9998

	set nocount on
	-- build a table containing list of files in Request directory
	if exists (select * from tempdb.dbo.sysobjects where name='RequestFiles' and type = 'U')
		drop table tempdb.dbo.RequestFiles
	create table tempdb.dbo.RequestFiles (
		line_no int identity(1,1) Primary key clustered,
		Filename varchar(200) NULL
	)
	declare @cmd varchar(2000)

	--Get list of remote files
	set @cmd = 'ftp -i -s:' + @ftpcommandfile
	Insert into tempdb.dbo.RequestFiles (Filename)
		Exec master.dbo.xp_cmdshell @cmd
	select @rows = @@rowcount, @errcode = @@error
	if @rows = 0 OR @errcode != 0
	begin
		set @rc = -1
		goto done
	end

	-- remove non-files and already processed files	( there might have been old files on remotesystem )
	Delete 
		From tempdb.dbo.RequestFiles
		Where coalesce(Filename, '') not like '%Orders.%'
	-- check count
	select @rows = (select count(*) from tempdb.dbo.RequestFiles	
		Where tempdb.dbo.RequestFiles.Filename like '%'+@filename+'%' )

	if @rows = 1
		set @rc = 1
done:
	return @rc

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE dbo.usp_AdjustedUsers
as
BEGIN
SET NOCOUNT ON

DECLARE
	@Server	varchar(60),
	@DB		varchar(60),
	@Owner	varchar(60),
	@Table	varchar(60),
	@Filter	varchar(1000),
	@SQL	varchar(3000)

UPDATE dbo.AdjustedUsers SET Processed = 0

DECLARE
	ADJ_CUR CURSOR FOR
	SELECT ServerName, DBName, Owner, TableName, Filter
	FROM dbo.AdjustedUsers
	ORDER BY ServerName, DBName

OPEN ADJ_CUR
FETCH NEXT FROM ADJ_CUR INTO @Server, @DB, @Owner, @Table, @Filter
WHILE @@FETCH_STATUS = 0
	begin
	PRINT @Server + ' - ' + @DB
	SET @SQL = 
		'UPDATE dbo.Applications_Supported 
		 SET AdjUserCount = UserCount
		 FROM dbo.Applications_Supported a JOIN
		 ( SELECT COUNT(*) as UserCount
		   FROM [' + @Server + '].' + @DB + '.' + @Owner + '.' + @Table 

	IF @Filter IS NOT NULL SET @SQL = @SQL + ' WHERE ' + @Filter

	SET @SQL = @SQL + ' ) as uu ON a.Server = ''' + @Server + ''' and
		a.DB = ''' + @DB + ''''
	
	

	PRINT @SQL
	EXEC( @SQL )

	UPDATE dbo.AdjustedUsers SET Processed = 1 
	WHERE ServerName = @Server and DBName = @DB

	FETCH NEXT FROM ADJ_CUR INTO @Server, @DB, @Owner, @Table, @Filter
	end
CLOSE ADJ_CUR
DEALLOCATE ADJ_CUR
END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE dbo.usp_AllDBAttributes
		@Server		varchar(60)
as
BEGIN
SET NOCOUNT ON
DECLARE @SQL 	varchar( 1000 )

SET @SQL = 'UPDATE dbo.Databases SET RecoveryModel = x.RecoveryModel 
	FROM dbo.Databases d JOIN [' + @Server + '].DBA.dbo.DBAttributes x
    ON d.Servername = ''' + @Server + ''' and d.DBName = x.DBName'
--PRINT @SQL
EXEC( @SQL )
END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


CREATE PROCEDURE dbo.usp_AllUserList 
		@SortOrder	  varchar( 10 ) = 'User',
		@ServerName	  varchar( 30 ) = NULL,
		@DatabaseName varchar( 30 ) = NULL
AS


SET NOCOUNT ON

if OBJECT_ID( '#TempUsers' ) is not null
	DROP TABLE #TempUsers

CREATE TABLE #TempUsers
(	
	ServerName		varchar( 30 ),
	UserName		varchar( 30 ),
	Pwd				char( 2 ), 
	DBName			varchar( 30 ),
	RoleName		varchar( 30 ),
	IsNTGroup		char( 2 ),
	IsAliased		char( 2 ),
	SysAdmin		char( 2 ),
	ServerAdmin 	char( 2 ),
	SetupAdmin		char( 2 ),
	ProcessAdmin	char( 2 ),
	SecurityAdmin	char( 2 ),
	DiskAdmin		char( 2 ),
	DBCreator		char( 2 )    
)

INSERT INTO #TempUsers
exec dbo.usp_UserList2 


	
if @SortOrder = 'Database'
	SELECT 	ServerName, 	DBname, 		RoleName,      	UserName,  
			Pwd, 			SysAdmin,		DBCreator		IsNTGroup,  	IsAliased,	
			ServerAdmin, 	SetupAdmin, 	ProcessAdmin, 	SecurityAdmin, 	DiskAdmin 	
	FROM #TempUsers 
	ORDER BY DBName, RoleName, UserName

else if @SortOrder = 'Role'
	SELECT 	ServerName, RoleName,   	UserName,      	DBName,    
			Pwd, 		DBCreator,		SysAdmin,	   	IsNTGroup,  		IsAliased,       
			ServerAdmin, SetupAdmin, 	ProcessAdmin, 	SecurityAdmin, 		DiskAdmin
	FROM #TempUsers 
	ORDER BY RoleName, UserName, DBName

else 
	SELECT 	ServerName,	UserName,   	DBName,        	RoleName,  
			Pwd, 		SysAdmin,	   	DBCreator, 		IsNTGroup,		IsAliased,	
			ServerAdmin,SetupAdmin, 	ProcessAdmin,  	SecurityAdmin,	DiskAdmin	
	FROM #TempUsers 
	ORDER BY UserName, DBName, RoleName

DROP TABLE #TempUsers

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO



CREATE PROCEDURE dbo.usp_BlankLogins 
		@Server		varchar( 50 ) = NULL
AS
BEGIN
SET NOCOUNT ON
PRINT '    usp_BlankLogins'

IF @Server IS NULL SET @Server = @@Servername

DECLARE
	@SQLStmt		varchar ( 500 )

SET @SQLStmt = 
'INSERT INTO dbo.BlankLogins( ServerName, Login )
SELECT  ''' + @Server + ''', m.name
FROM [' + @Server + '].master.dbo.syslogins m 
WHERE m.password IS NULL AND m.IsNtUser = 0 and m.IsNtGroup = 0'

--PRINT @SQLStmt
EXEC( @SQLStmt )
END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


CREATE PROCEDURE dbo.usp_BlankPwd 	
AS

SET NOCOUNT ON
IF OBJECT_ID( 'dbo.BlankLogins' ) IS NOT NULL
	TRUNCATE TABLE dbo.BlankLogins
ELSE
	CREATE TABLE BlankLogins
(	
	ServerName		varchar( 30 ),
	Login    		varchar( 30 )
)

INSERT INTO BlankLogins( ServerName, Login )
SELECT  '2KARRIVAL', name FROM [2KARRIVAL].master.dbo.syslogins
WHERE password IS NULL AND ( IsNtUser = 0 and IsNtGroup = 0 )

IF NOT EXISTS( SELECT * FROM BlankLogins WHERE ServerName = '2KARRIVAL' )
	INSERT INTO BlankLogins( ServerName, Login ) VALUES( '2KARRIVAL', 'none' ) 

SELECT * FROM BlankLogins ORDER BY ServerName, Login

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE dbo.usp_CreateFTPParamFile
	@FTPServer  varchar(200),
	@Login		varchar(100),
	@Pwd		varchar(100),
	@ChgPath	varchar(200) = NULL,  -- folder to change to at FTP site
	@FileToFTP	varchar(200),  -- provide full path of file
	@ParamFile	varchar(200)   -- provide full path of file
AS
BEGIN
SET NOCOUNT ON
DECLARE @text1	varchar(500)

SET @text1 = 'echo ' + @FTPServer + '>' + @ParamFile
EXEC master.dbo.xp_cmdshell @text1
SET @text1 = 'echo ' + @Login + '>>' + @ParamFile
EXEC master.dbo.xp_cmdshell @text1
SET @text1 = 'echo ' + @Pwd + '>>' + @ParamFile
EXEC master.dbo.xp_cmdshell @text1
if @ChgPath is not null
	begin
	SET @text1 = 'echo cd ' + @ChgPath + '>>' + @ParamFile
	EXEC master.dbo.xp_cmdshell @text1
	end
SET @text1 = 'echo mput ' + @FileToFTP + '>>' + @ParamFile
EXEC master.dbo.xp_cmdshell @text1
SET @text1 = 'echo quit >>' + @ParamFile
EXEC master.dbo.xp_cmdshell @text1
END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE dbo.usp_EraseServerData  	@Server varchar(60) 
AS
BEGIN
SET NOCOUNT ON
-- This will take care of several tables because of 
-- delete cascades
DELETE FROM dbo.Databases WHERE ServerName = @Server

DELETE FROM dbo.Jobs 			WHERE ServerName = @Server
DELETE FROM dbo.Packages 		WHERE ServerName = @Server
DELETE FROM dbo.BlankLogins 	WHERE ServerName = @Server
DELETE FROM dbo.All_Free_Space 	WHERE ServerName = @Server
DELETE FROM dbo.User_Activity 	WHERE ServerName = @Server
DELETE FROM dbo.Schedules 		WHERE ServerName = @Server
DELETE FROM dbo.Users			WHERE ServerName = @Server

UPDATE dbo.Servers SET Started = 0, Finished = 0, Step = NULL
WHERE Servername = @Server
END 

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE dbo.usp_ExportApps 
	@Audited char(1) = NULL
AS
BEGIN
SET NOCOUNT ON
DECLARE @rtn	int

CREATE TABLE #TEMP
(
	job_id uniqueidentifier ,
	job_name sysname ,
	run_status int ,
	run_date int ,
	run_time int ,
	run_duration int ,
	operator_emailed nvarchar(20) ,
	operator_netsent nvarchar(20), 
	operator_paged nvarchar(20) ,
	retries_attempted int ,
	server nvarchar(30) 
)

SET @rtn = 0

IF OBJECT_ID( 'dbo.ExportApps' ) IS NOT NULL
	DROP TABLE dbo.ExportApps

IF @Audited = 'Y'
	SELECT Server, DB, 'Y' as Audited, 
		Application, Code, Department, DBA, Manager_Contact, 
		Bkp_Plan, Tape_DRM_Plan, Bkp_PlanName, DBDrives, 
		OrigDBSize as OrigDB, OrigDBDate,
		CurrentDBSize as CurrentDB, GrowthRate, NumUsers as Logins,
		AdjUserCount as Users,  Comment
	INTO dbo.ExportApps
	FROM DBA.dbo.Applications_Supported
	WHERE Audited = 1 and ActiveFlag = 1
	ORDER BY Server, DB
ELSE
	SELECT Server, DB, CASE Audited WHEN 1 THEN 'Y' ELSE '' END as Audited, 
		Application, Code, Department, DBA, Manager_Contact, 
		Bkp_Plan, Tape_DRM_Plan, Bkp_PlanName, DBDrives, 
		OrigDBSize as OrigDB, OrigDBDate,
		CurrentDBSize as CurrentDB, GrowthRate, NumUsers as Logins, 
		AdjUserCount as Users,  Comment
	INTO dbo.ExportApps
	FROM DBA.dbo.Applications_Supported
	WHERE ActiveFlag = 1
	ORDER BY Server, DB

--EXEC master..xp_cmdshell 'DTSRun /S "(local)" /N "Daily Check - Export Applications" /E '

exec msdb.dbo.sp_start_job 'DailyCheck - Export Apps' 
WAITFOR DELAY '000:00:05' -- Give the job a chance to complete
INSERT INTO #TEMP EXEC msdb.dbo.sp_help_jobhistory @job_name = 'DailyCheck - Export Apps'

WHILE @@ROWCOUNT = 0
  BEGIN
  WAITFOR DELAY '000:00:05' -- Give the job a chance to complete
  INSERT INTO #TEMP EXEC msdb.dbo.sp_help_jobhistory @job_name = 'DailyCheck - Export Apps'
  END

SELECT @rtn = max(run_status) FROM #TEMP
IF @rtn <> 1 SET @rtn = -1
RETURN @rtn
END



GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE dbo.usp_ExportBlankLogins
	@ServerType		char(1) = '*'
AS
BEGIN
SET NOCOUNT ON
DECLARE @rtn	int

CREATE TABLE #TEMP
(
	job_id uniqueidentifier ,
	job_name sysname ,
	run_status int ,
	run_date int ,
	run_time int ,
	run_duration int ,
	operator_emailed nvarchar(20) ,
	operator_netsent nvarchar(20), 
	operator_paged nvarchar(20) ,
	retries_attempted int ,
	server nvarchar(30) 
)

SET @rtn = 0

IF OBJECT_ID( 'dbo.ExportBlankLogins' ) IS NOT NULL
	DROP TABLE dbo.ExportBlankLogins

DECLARE 
	@DTSCommand varchar(300),
	@SQLCmd		varchar(1000)

SET @SQLCmd = 
'SELECT l.ServerName, Login 
INTO dbo.ExportBlankLogins
FROM dbo.BlankLogins l JOIN dbo.SERVERS s
ON l.ServerName = s.ServerName 
LEFT JOIN ( SELECT DISTINCT Server, Audited FROM dbo.Applications_Supported 
WHERE Audited = 1 ) as a on s.ServerName = a.Server
'
IF @ServerType IN ( 'P', 'D' ) 
	SET @SQLCmd = @SQLCmd + ' WHERE s.ServerType = ''' + @ServerType + ''''
ELSE IF @ServerType = 'A'
	SET @SQLCmd = @SQLCmd + ' WHERE a.Audited = 1'

print @sqlcmd
EXEC( @SQLCmd )

--EXEC master..xp_cmdshell 'DTSRun /S "(local)" /N "Daily Check - Export No Passwords" /E '
exec msdb.dbo.sp_start_job 'DailyCheck - Export Blank Logins'
WAITFOR DELAY '000:00:05' -- Give the job a chance to complete
INSERT INTO #TEMP EXEC msdb.dbo.sp_help_jobhistory @job_name = 'DailyCheck - Export Blank Logins'

WHILE @@ROWCOUNT = 0
  BEGIN
  WAITFOR DELAY '000:00:05' -- Give the job a chance to complete
  INSERT INTO #TEMP EXEC msdb.dbo.sp_help_jobhistory @job_name = 'DailyCheck - Export Blank Logins'
  END

SELECT @rtn = max(run_status) FROM #TEMP
IF @rtn <> 1 SET @rtn = -1
RETURN @rtn
END



GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE dbo.usp_ExportJobs 
	@Status		varchar(15) = 'ALL', 
	@Shipping 	char(1) 	= 'N', 
	@Server		varchar(50) = 'ALL',
	@ServerType	char(1) 	= 'A'
AS
BEGIN
SET NOCOUNT ON

DECLARE @rtn	int

CREATE TABLE #TEMP
(
	job_id uniqueidentifier ,
	job_name sysname ,
	run_status int ,
	run_date int ,
	run_time int ,
	run_duration int ,
	operator_emailed nvarchar(20) ,
	operator_netsent nvarchar(20), 
	operator_paged nvarchar(20) ,
	retries_attempted int ,
	server nvarchar(30) 
)

SET @rtn = 0

IF OBJECT_ID( 'dbo.ExportJobs' ) IS NOT NULL
	DROP TABLE dbo.ExportJobs

DECLARE 
	@DTSCommand varchar(300),
	@SQLCmd		varchar(2000)

SET @SQLCmd = 
'SELECT    
	r.ServerName, 
	Originating_Server AS [From Srv], 
	JobName, 
	MaintPlan,
	DTS,
	Scheduled,
	Status, 
	CAST(RunDate AS datetime) AS Date, 
	RunTime AS Time, 
	RunDuration AS Duration, 
    DateModified, 
	LogFileName AS [Log], 
	CASE WHEN Description = ''No description available.'' 
	     THEN '''' ELSE Description END AS Description, 
    RIGHT(Message, LEN(Message) - CHARINDEX(''.'', Message) - 2) AS Message, 
	RunDatetime
INTO dbo.ExportJobs
FROM dbo.Jobs r join dbo.SERVERS s ON r.ServerName = s.ServerName'

IF @Status = 'Failed'
	begin
	SET @SQLCmd = @SQLCmd + ' WHERE Status = ''Failed''' 
	IF @Server NOT IN (  'ALL', '*ALL' )
		SET @SQLCmd = @SQLCmd + ' and r.ServerName = ''' + @Server + ''''
	ELSE IF @ServerType <> 'A'
		SET @SQLCmd = @SQLCmd + ' and ServerType = ''' + @ServerType + ''''
	end

ELSE IF @Shipping = 'N'
	begin
	SET @SQLCmd = @SQLCmd + 
		' WHERE JobName not like ''%LogShip%'' and JobName not like ''%Log Ship%'''
	IF @Server IN ( 'ALL', '*ALL' )
		SET @SQLCmd = @SQLCmd + ' and r.ServerName = ''' + @Server + ''''
	ELSE IF @ServerType <> 'A'
		SET @SQLCmd = @SQLCmd + ' and ServerType = ''' + @ServerType + ''''
	end

ELSE IF @Server IN ( 'ALL', '*ALL' )
	SET @SQLCmd = @SQLCmd + ' WHERE r.ServerName = ''' + @Server + ''''

ELSE IF @ServerType <> 'A'
	SET @SQLCmd = @SQLCmd + ' WHERE ServerType = ''' + @ServerType + ''''

PRINT @SQLCmd
EXEC( @SQLCmd )
--EXEC master..xp_cmdshell 'DTSRun /S "(local)" /N "Daily Check - Export Jobs" /E '

exec msdb.dbo.sp_start_job 'DailyCheck - Export Jobs'
WAITFOR DELAY '000:00:05' -- Give the job a chance to complete
INSERT INTO #TEMP EXEC msdb.dbo.sp_help_jobhistory @job_name = 'DailyCheck - Export Jobs'

WHILE @@ROWCOUNT = 0
  BEGIN
  WAITFOR DELAY '000:00:05' -- Give the job a chance to complete
  INSERT INTO #TEMP EXEC msdb.dbo.sp_help_jobhistory @job_name = 'DailyCheck - Export Jobs'
  END

SELECT @rtn = max(run_status) FROM #TEMP
IF @rtn <> 1 SET @rtn = -1
RETURN @rtn
END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE usp_ExportMonthlyAudit
AS
BEGIN
SET NOCOUNT ON
TRUNCATE TABLE dbo.ExportPermissions

--INSERT INTO dbo.ExportPermissions( ServerName, Login, SysAdmin )
	SELECT Application, Server, DB
	FROM dbo.Applications_Supported
	WHERE Audited = 1
	ORDER BY Server, Application

INSERT INTO dbo.ExportPermissions
( ServerName, Login, SysAdmin, Security, Server, Setup, Process, [Disk], DBCreator )
SELECT DISTINCT
	p.ServerName, 
	p.Login, 
	p.Sys, 
	p.Security, 
	p.Server, 
	p.Setup, 
	p.Process, 
	p.[Disk], 
	p.DBCreator
FROM DBA.dbo.ServerPermissions p join dbo.Applications_Supported a
	on p.ServerName = a.Server
WHERE a.Audited = 1
ORDER BY p.ServerName, p.Login
END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE dbo.usp_ExportPermissions 
	@ServerType char(1) = '*'
AS
BEGIN
SET NOCOUNT ON

DECLARE @rtn	int

CREATE TABLE #TEMP
(
	job_id uniqueidentifier ,
	job_name sysname ,
	run_status int ,
	run_date int ,
	run_time int ,
	run_duration int ,
	operator_emailed nvarchar(20) ,
	operator_netsent nvarchar(20), 
	operator_paged nvarchar(20) ,
	retries_attempted int ,
	server nvarchar(30) 
)

SET @rtn = 0

IF @ServerType = 'A' and OBJECT_ID( 'dbo.ExportAuditPermissions' ) IS NOT NULL 	
	DROP TABLE dbo.ExportAuditPermissions
ELSE IF OBJECT_ID( 'dbo.ExportPermissions' ) IS NOT NULL 
	DROP TABLE dbo.ExportPermissions
	

DECLARE 
	@DTSCommand varchar(300),
	@SQLCmd		varchar(1000)


IF @ServerType <> 'A'
	begin
	SET @SQLCmd = 
	'SELECT DISTINCT
	p.ServerName, Login, 
	CASE Sys WHEN ''N'' THEN '''' ELSE Sys END as SysAdmin, 
	CASE Security WHEN ''N'' THEN '''' ELSE Security END as Security, 
	CASE p.Server WHEN ''N'' THEN '''' ELSE p.Server END as Server, 
	CASE Setup WHEN ''N'' THEN '''' ELSE Setup END as Setup,  
	CASE Process WHEN ''N'' THEN '''' ELSE Process END as Process, 
	CASE [Disk] WHEN ''N'' THEN '''' ELSE [Disk] END as [Disk], 
	CASE DBCreator WHEN ''N'' THEN '''' ELSE DBCreator END as DBCreator
	INTO dbo.ExportPermissions
	FROM dbo.ServerPermissions p join Servers s on p.ServerName = s.ServerName 
	left join 
	( SELECT DISTINCT Server, Audited FROM dbo.Applications_Supported 
	  WHERE Audited = 1 ) as a on s.ServerName = a.Server 
	WHERE ServerType = ''' + @ServerType + ''''
	print @sqlcmd
	EXEC( @SQLCmd )
	--EXEC master..xp_cmdshell 'DTSRun /S "(local)" /N "Daily Check - Export Server Permissions" /E '
	exec msdb.dbo.sp_start_job 'DailyCheck - Export Server Permissions'
	end
ELSE 
	begin	
	SET @SQLCmd = 
	'SELECT DISTINCT Application,
	p.ServerName, Login, 
	CASE Sys WHEN ''N'' THEN '''' ELSE Sys END as SysAdmin, 
	CASE Security WHEN ''N'' THEN '''' ELSE Security END as Security, 
	CASE p.Server WHEN ''N'' THEN '''' ELSE p.Server END as Server, 
	CASE Setup WHEN ''N'' THEN '''' ELSE Setup END as Setup,  
	CASE Process WHEN ''N'' THEN '''' ELSE Process END as Process, 
	CASE [Disk] WHEN ''N'' THEN '''' ELSE [Disk] END as [Disk], 
	CASE DBCreator WHEN ''N'' THEN '''' ELSE DBCreator END as DBCreator
	INTO dbo.ExportAuditPermissions
	FROM dbo.ServerPermissions p join Servers s on p.ServerName = s.ServerName 
	left join 
	( SELECT DISTINCT Server, Audited, Application FROM dbo.Applications_Supported 
	  WHERE Audited = 1 ) as a on s.ServerName = a.Server 
	WHERE Audited = 1'
	print @sqlcmd
	EXEC( @SQLCmd )
	--EXEC master..xp_cmdshell 'DTSRun /S "(local)" /N "Daily Check - Export Audited Server Permissions" /E '
	exec msdb.dbo.sp_start_job 'DailyCheck - Export Server Permissions'
	end
WAITFOR DELAY '000:00:05' -- Give the job a chance to complete
INSERT INTO #TEMP EXEC msdb.dbo.sp_help_jobhistory @job_name = 'DailyCheck - Export Server Permissions'

WHILE @@ROWCOUNT = 0
  BEGIN
  WAITFOR DELAY '000:00:05' -- Give the job a chance to complete
  INSERT INTO #TEMP EXEC msdb.dbo.sp_help_jobhistory @job_name = 'DailyCheck - Export Server Permissions'
  END

SELECT @rtn = max(run_status) FROM #TEMP
IF @rtn <> 1 SET @rtn = -1
RETURN @rtn
END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE dbo.usp_ExportSchedules
	@Server		varchar(50) = 'ALL',
	@ServerType char(1) = 'A'
AS
BEGIN
SET NOCOUNT ON

DECLARE @rtn	int

CREATE TABLE #TEMP
(
	job_id uniqueidentifier ,
	job_name sysname ,
	run_status int ,
	run_date int ,
	run_time int ,
	run_duration int ,
	operator_emailed nvarchar(20) ,
	operator_netsent nvarchar(20), 
	operator_paged nvarchar(20) ,
	retries_attempted int ,
	server nvarchar(30) 
)

SET @rtn = 0

IF OBJECT_ID( 'dbo.ExportSchedules' ) IS NOT NULL
	DROP TABLE dbo.ExportSchedules

DECLARE 
	@DTSCommand varchar(300),
	@SQLCmd		varchar(1000)

SET @SQLCmd = 
'SELECT     
	h.ServerName, 
	JobName, 
	case DTS when 0 then '''' else ''Y'' end as DTS,
	case MaintPlan when 0 then '''' else ''Y'' end as MaintPlan,
	case when [Desc] = ''No description available.'' then '''' else [Desc] end as [Desc], 
	Freq, 
	[When], 
	[Time], 
	History,
	StepId,
	StepName,
	NextRunDate, 
	NextRunTime, 
	OrigSrv, 
	Owner, 
	Netsend, 
	JobType
INTO dbo.ExportSchedules
FROM dbo.Schedules h join dbo.SERVERS s on h.ServerName = s.ServerName'

IF @Server <> 'ALL'
	SET @SQLCmd = @SQLCmd + ' WHERE h.ServerName = ''' + @Server + ''''
ELSE IF @ServerType <> 'A' 
	SET @SQLCmd = @SQLCmd + ' WHERE ServerType = ''' + @ServerType + ''''

print @sqlcmd
EXEC( @SQLCmd )
--EXEC master..xp_cmdshell 'DTSRun /S "(local)" /N "Daily Check - Export Schedules" /E '

exec msdb.dbo.sp_start_job 'DailyCheck - Export Schedules'
WAITFOR DELAY '000:00:05' -- Give the job a chance to complete
INSERT INTO #TEMP EXEC msdb.dbo.sp_help_jobhistory @job_name = 'DailyCheck - Export Schedules'

WHILE @@ROWCOUNT = 0
  BEGIN
  WAITFOR DELAY '000:00:05' -- Give the job a chance to complete
  INSERT INTO #TEMP EXEC msdb.dbo.sp_help_jobhistory @job_name = 'DailyCheck - Export Schedules'
  END

SELECT @rtn = max(run_status) FROM #TEMP
IF @rtn <> 1 SET @rtn = -1
RETURN @rtn
END



GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE dbo.usp_ExportServers
AS
BEGIN
SET NOCOUNT ON
DECLARE @rtn	int

CREATE TABLE #TEMP
(
	job_id uniqueidentifier ,
	job_name sysname ,
	run_status int ,
	run_date int ,
	run_time int ,
	run_duration int ,
	operator_emailed nvarchar(20) ,
	operator_netsent nvarchar(20), 
	operator_paged nvarchar(20) ,
	retries_attempted int ,
	server nvarchar(30) 
)

SET @rtn = 0

--EXEC master..xp_cmdshell 'DTSRun /S "(local)" /N "Daily Check - Export Servers" /E '
exec msdb.dbo.sp_start_job 'DailyCheck - Export Servers'
WAITFOR DELAY '000:00:05' -- Give the job a chance to complete
INSERT INTO #TEMP EXEC msdb.dbo.sp_help_jobhistory @job_name = 'DailyCheck - Export Servers'

WHILE @@ROWCOUNT = 0
  BEGIN
  WAITFOR DELAY '000:00:05' -- Give the job a chance to complete
  INSERT INTO #TEMP EXEC msdb.dbo.sp_help_jobhistory @job_name = 'DailyCheck - Export Servers'
  END

SELECT @rtn = max(run_status) FROM #TEMP
IF @rtn <> 1 SET @rtn = -1
RETURN @rtn
END



GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE dbo.usp_ExportUsers
	@Server		varchar(60) = @@Servername,
	@DB			varchar(60) = NULL
AS
BEGIN
SET NOCOUNT ON

DECLARE @rtn	int

CREATE TABLE #TEMP
(
	job_id uniqueidentifier ,
	job_name sysname ,
	run_status int ,
	run_date int ,
	run_time int ,
	run_duration int ,
	operator_emailed nvarchar(20) ,
	operator_netsent nvarchar(20), 
	operator_paged nvarchar(20) ,
	retries_attempted int ,
	server nvarchar(30) 
)

SET @rtn = 0

IF OBJECT_ID( 'dbo.ExportUsers' ) IS NOT NULL
	DROP TABLE dbo.ExportUsers

IF @Server = '*ALL' 
	SELECT u.ServerName, Login, UserName, DBName, RoleName, NTGroup, Alias, DefaultDB, CreateDate, LastLogin
	INTO dbo.ExportUsers
	FROM dbo.Users u JOIN dbo.Databases d on d.DBId = u.DBId

ELSE IF ISNULL( @DB, '' ) <> '' AND @DB <> '*'
	SELECT u.ServerName, Login, UserName, DBName, RoleName, NTGroup, Alias, DefaultDB, CreateDate, LastLogin
	INTO dbo.ExportUsers
	FROM dbo.Users u JOIN dbo.Databases d on d.DBId = u.DBId
	WHERE u.ServerName = @Server and d.DBName = @DB
ELSE
	SELECT u.ServerName, Login, UserName, DBName, RoleName, NTGroup, Alias, DefaultDB, CreateDate, LastLogin
	INTO dbo.ExportUsers
	FROM dbo.Users u JOIN dbo.Databases d on d.DBId = u.DBId
	WHERE u.ServerName = @Server

--EXEC master..xp_cmdshell 'DTSRun /S "(local)" /N "Daily Check - Export Users" /E '

exec msdb.dbo.sp_start_job 'DailyCheck - Export Users'
WAITFOR DELAY '000:00:05' -- Give the job a chance to complete
INSERT INTO #TEMP EXEC msdb.dbo.sp_help_jobhistory @job_name = 'DailyCheck - Export Users'

WHILE @@ROWCOUNT = 0
  BEGIN
  WAITFOR DELAY '000:00:05' -- Give the job a chance to complete
  INSERT INTO #TEMP EXEC msdb.dbo.sp_help_jobhistory @job_name = 'DailyCheck - Export Users'
  END

SELECT @rtn = max(run_status) FROM #TEMP
IF @rtn <> 1 SET @rtn = -1
RETURN @rtn
END



GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE dbo.usp_GetDatabaseAttributes
AS
/*************************************************

  Gets the recovery model of each database.

*************************************************/

SET NOCOUNT ON
TRUNCATE TABLE dbo.DBAttributes

DECLARE 
	DB_CUR CURSOR FOR 
	SELECT name FROM master.dbo.sysdatabases
	ORDER BY name

DECLARE 
	@DB		varchar(60),
	@SQL	varchar(1000)


OPEN DB_CUR
FETCH NEXT FROM DB_CUR INTO @DB
WHILE @@FETCH_STATUS = 0
	begin
	print @DB
	--SET @SQL = '	INSERT INTO dbo.DBAttributes( DBName, RecoveryModel ) ' 
	SET @SQL = 'SELECT name,CAST( DATABASEPROPERTYEX(name, ''RECOVERY'') AS VARCHAR ) from [2ksqldev1].master.dbo.sysdatabases
		where name = ''' + @DB + ''''
	PRINT @SQL
	EXEC(@SQL)
	FETCH NEXT FROM DB_CUR INTO @DB
	end
CLOSE DB_CUR
DEALLOCATE DB_CUR

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE dbo.usp_GetDatabaseFiles  @Server	varchar(60)
AS
BEGIN
SET NOCOUNT ON
PRINT '    usp_GetDatabaseFiles'

DECLARE	@cmd	varchar(2000)
SET @cmd = 
	'INSERT INTO DBA.dbo.Database_Files( DBId, LogicalName, PhysicalName )
	SELECT a.DBId, f.name, f.filename
	FROM [' + @Server + '].master.dbo.sysaltfiles f 
		JOIN [' + @Server + '].master.dbo.sysdatabases d ON f.dbid = d.dbid 
		JOIN DBA.dbo.Databases a ON a.ServerName = ''' + @Server + ''' and a.DBname = d.name'
--PRINT @cmd
EXEC( @cmd )
END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE dbo.usp_GetDatabaseSizes 
		@ServerName	varchar( 60 ) = @@ServerName
AS
BEGIN
SET NOCOUNT ON
PRINT '    usp_GetDatabaseSizes'
DECLARE 
	@SqlStmt	varchar( 2000 )

-- A server's DBSTATS table may also have history from another server
-- if a database was moved over from another server
SET @SqlStmt = 
	'INSERT INTO All_DBStats( DBId, Data_Size, Data_Used, Log_Size, Log_Used, Sample_Date, Percent_Log )'
SET @SqlStmt = @SqlStmt + 
	'SELECT DBId, Data_Size, Data_Used, Log_Size,Log_Used, State_Date, PercentLog '
SET @SqlStmt = @SqlStmt +
	'FROM [' + @ServerName + '].dba.dbo.DBStats s JOIN dbo.Databases d ON '
SET @SqlStmt = @SqlStmt + 
	'd.ServerName = ''' + @ServerName + '''  AND RTRIM( s.DBName ) = d.DBName ' 

--PRINT @SqlStmt
EXEC( @SqlStmt )
END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE dbo.usp_GetDatabases 
	@Server 	varchar(60) = @@ServerName,
	@Version	int = 2
AS
BEGIN
SET NOCOUNT ON
PRINT '    usp_GetDatabases'
PRINT 'SERVER:  ' + @Server

DECLARE @SqlStmt	varchar( 2000 )

IF @Version <> 7
	begin
	SET @SqlStmt = 'exec [' + @Server + '].DBA.dbo.usp_GetDBAttributes'
	--PRINT @SqlStmt
	EXEC( @SqlStmt )
	end

IF @Version = 7
	begin
	SET @SqlStmt = 'INSERT INTO dbo.Databases( ServerName, DBName, ServDBId ) '
	SET @SqlStmt = @SqlStmt + 
	'SELECT ''' + @Server + ''', name, m.dbid
	FROM [' + @Server + '].master.dbo.sysdatabases m 
	WHERE name not in( ''Northwind'', ''pubs'' ) and 
		name not like ''AdventureWorks%'''
	--PRINT @SQLSTMT
	EXEC( @SqlStmt )
	end
ELSE
	begin
	SET @SqlStmt = 
	'INSERT INTO dbo.Databases( ServerName, DBName, ServDBId, RecoveryModel, Status) '
	SET @SqlStmt = @SqlStmt + 
	'SELECT ''' + @Server + ''', name, m.dbid, a.Model, a.Status 
	FROM [' + @Server + '].master.dbo.sysdatabases m 
	JOIN [' + @Server + '].DBA.dbo.DBAttributes a ON m.name = a.DBName
	WHERE name not in( ''Northwind'', ''pubs'' ) and 
		name not like ''AdventureWorks%'''
	--PRINT @SQLSTMT
	EXEC( @SqlStmt )
	end

UPDATE dbo.Databases
SET DBType = 
	CASE 
		WHEN DBName IN 
		( 'TEMPDB', 'MASTER', 'MSDB', 'MODEL', 'DISTRIBUTION', 'DBA' ) THEN 'S'
		WHEN DBName IN 
		( 'DUMMY', 'TEST', 'Capacity_Repository', 'xarrival' ) THEN 'D'
		WHEN DBName LIKE '%_Test%'		 THEN 'D'
		WHEN DBName LIKE '%TempDB'		 THEN 'D'
		WHEN DBName LIKE '%_Dev%'		 THEN 'D'
		WHEN DBName LIKE '%_Staging%'	 THEN 'D'
		WHEN DBName LIKE '%_backup%'     THEN 'D'
		WHEN DBName LIKE '%LiteSpeed%'   THEN 'D'
		WHEN s.ServerName = 'NTWEBSTAGE' THEN
			CASE WHEN DBName IN( 'FundRaising', 'Fund_Kaplan', 'HelpDesk' ) THEN 'P' 
				 ELSE 'D' END
		ELSE s.ServerType
	END
FROM dbo.Databases d JOIN dbo.Servers s ON d.ServerName = s.ServerName 
WHERE s.ServerName = @Server
END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


CREATE PROCEDURE usp_GetJobs 
		@Server varchar( 50 ) = @@ServerName,
		@Version int = 2
AS
BEGIN
SET NOCOUNT ON
PRINT '    usp_GetJobs'

DECLARE 
	@varcharDateToday char( 10 ),
	@SQLStmt	varchar( 6000 )
	
SET @varcharDateToday = CONVERT( char( 10 ), GETDATE(), 101 )
PRINT 'Server:  ' + @Server

IF @Version = 5
	SET @SQLStmt = 
	'INSERT INTO DBA.dbo.Jobs
	( 	ServerName, Originating_Server, JobName, Status, 
	  	RunDate, RunTime, RunDuration, RunDatetime, DateModified, 
        LogFileName, Message, Description, MaintPlan, DTS, Scheduled, OldJobName,
		Owner, NetSend )
 	SELECT ''' + 
		@Server + ''', ''2005'', '
ELSE IF @Version = 2 
	SET @SQLStmt = 
	'INSERT INTO DBA.dbo.Jobs
	( 	ServerName, Originating_Server, JobName, Status, 
	  	RunDate, RunTime, RunDuration, RunDatetime, DateModified, 
        LogFileName, Message, Description, MaintPlan, DTS, Scheduled, OldJobName,
		Owner, NetSend )
 	SELECT ''' + 
		@Server + ''', ''2000'','

ELSE IF @Version = 7 
	SET @SQLStmt = 
	'INSERT INTO DBA.dbo.Jobs
	( 	ServerName, Originating_Server, JobName, Status, 
	  	RunDate, RunTime, RunDuration, RunDatetime, DateModified, 
        LogFileName, Message, Description, MaintPlan, DTS, Scheduled, OldJobName,
		Owner, NetSend )
 	SELECT ''' + 
		@Server + ''', ''7'','
ELSE
	SET @SQLStmt = 
	'INSERT INTO DBA.dbo.Jobs
	( 	ServerName, JobName, Status, 
	  	RunDate, RunTime, RunDuration, RunDatetime, DateModified, 
        LogFileName, Message, Description, MaintPlan, DTS, Scheduled, OldJobName,
		Owner, NetSend )
 	SELECT ''' + 
		@Server + ''', '


SET @SQLStmt = @SQLStmt + 
		'REPLACE( REPLACE( REPLACE( sj.name, ''for DB Maintenance Plan '', '''' ), '' Job '', '''' ), ''Log Shipping'', ''LShip''),
		CASE sjh.run_status
			WHEN 0 THEN ''Failed''
			WHEN 1 THEN ''Succeeded''
			WHEN 2 THEN ''Retry''
			WHEN 3 THEN ''Canceled''
			WHEN 4 THEN ''In Progress''
			ELSE ''Unknown''
		END,
		sjh.RunDate,
		sjh.RunTime,
		sjh.Duration,
		sjh.RunDateTime,
		sj.date_modified,
		sjs.output_file_name,
		sjh.Message,
		sj.description,
		CASE WHEN m.job_id IS NOT NULL THEN 1 ELSE 0 END as MaintPlan,
		CASE WHEN dts.step_id IS NOT NULL THEN 1 ELSE 0 END as DTS,
		CASE WHEN s.schedule_id IS NOT NULL THEN 1 ELSE 0 END as Scheduled,
		sj.name as OldJobName,
		l.name,
		ISNULL( o.name, '''' )
 	FROM [' + @Server + '].msdb.dbo.sysjobs sj 
		JOIN [' + @Server + '].master.dbo.syslogins l on sj.owner_sid = l.sid
		JOIN 
		( SELECT job_id, step_id, run_status,
			SUBSTRING( CAST( run_date AS char(8)), 5, 2 ) + ''/'' + 
				RIGHT( CAST( run_date AS char(8)),2 ) + ''/'' +
				LEFT( CAST( run_date AS char(8)), 4 ) 
			as RunDate,
			LEFT( RIGHT( ''000000'' + CAST( run_time AS varchar(10)), 6 ), 2 ) + '':'' +
				SUBSTRING( RIGHT( ''000000'' + CAST( run_time AS varchar(10)), 6 ), 3, 2 ) + '':'' +
				RIGHT( RIGHT( ''000000'' + CAST( run_time AS varchar(10)), 6 ), 2 )
			as RunTime,
			LEFT( RIGHT( ''000000'' + CAST( run_duration AS varchar(10)), 6 ), 2 ) + '':'' +
				SUBSTRING( RIGHT( ''000000'' + CAST( run_duration AS varchar(10)), 6 ),3, 2 ) + '':'' +
				RIGHT( RIGHT( ''000000'' + CAST( run_duration AS varchar(10)), 6 ), 2 )
			as Duration,
			CONVERT( datetime, ( LEFT( CAST( run_date AS char(8) ), 4 ) + ''-'' +
				SUBSTRING( CAST( run_date AS char(8)), 5, 2 ) + ''-'' +
				RIGHT( CAST( run_date AS char(8)),2 ) + '' '' +
				LEFT( RIGHT( ''000000'' + CAST( run_time AS varchar(10)), 6 ), 2 ) + '':'' +
				SUBSTRING( RIGHT( ''000000'' + CAST( run_time AS varchar(10)), 6 ), 3, 2 ) + '':'' +
				RIGHT( RIGHT( ''000000'' + CAST( run_time AS varchar(10)), 6 ), 2 ) ), 120 )
			as RunDateTime,
			RIGHT( message, len( message ) - charindex( ''.'', message ) - 2 ) as Message
		   	FROM [' + @Server + '].msdb.dbo.sysjobhistory 
		) as sjh ON sj.job_id = sjh.job_id and sjh.step_id = 0 
		JOIN [' + @Server + '].msdb.dbo.sysjobsteps sjs  ON sj.job_id = sjs.job_id and 
				sjs.step_id = 1  -- get log file name only
		LEFT JOIN ( SELECT job_id, max( step_id ) as step_id FROM [' + @Server + '].msdb.dbo.sysjobsteps 
				WHERE command like ''DTSRun%'' GROUP BY job_id ) as dts ON dts.job_id = sj.job_id
		LEFT JOIN [' + @Server + '].msdb.dbo.sysdbmaintplan_jobs m ON m.job_id = sj.job_id
		LEFT JOIN ( SELECT job_id, MAX( schedule_id ) as schedule_id FROM [' + @Server + '].msdb.dbo.sysjobschedules
			 GROUP BY job_id ) AS s ON s.job_id = sj.job_id
		LEFT JOIN [' + @Server + '].msdb.dbo.sysoperators o ON sj.notify_netsend_operator_id = o.id
 	WHERE
	-- No jobs older than 1 month
		sjh.RunDateTime > DATEADD( M, -1, GETDATE() ) AND 
		sjh.RunDateTime > ( SELECT ISNULL( max( RunDatetime ), CAST( ''01/01/95'' AS datetime ) )
			FROM DBA.dbo.Jobs WHERE ServerName = ''' + @Server + ''')' 

--PRINT @SQLStmt
EXEC ( @SQLStmt )

-- Get the disabled jobs

IF @Version = 5
	SET @SQLStmt = 
	'INSERT INTO dbo.Jobs
		( ServerName, Originating_Server, JobName, Status, RunDate, RunTime, 
	  	RunDuration, RunDatetime, DateModified, Description, OldJobName, Owner, NetSend )
	SELECT ''' + @Server + ''', ''2005'','

ELSE IF @Version = 2
	SET @SQLStmt = 
	'INSERT INTO dbo.Jobs
		( ServerName, Originating_Server, JobName, Status, RunDate, RunTime, 
	  	  RunDuration, RunDatetime, DateModified, Description, OldJobName, Owner, NetSend )
	SELECT
		''' + @Server + ''', ''2000'','

ELSE IF @Version = 7
	SET @SQLStmt = 
	'INSERT INTO dbo.Jobs
		( ServerName, Originating_Server, JobName, Status, RunDate, RunTime, 
	  	  RunDuration, RunDatetime, DateModified, Description, OldJobName, Owner, NetSend )
	SELECT
		''' + @Server + ''', ''7'','
ELSE
	SET @SQLStmt = 
	'INSERT INTO dbo.Jobs
		( ServerName, JobName, Status, RunDate, RunTime, 
	  	  RunDuration, RunDatetime, DateModified, Description, OldJobName, Owner, NetSend )
	SELECT
		''' + @Server + ''', '


SET @SQLStmt = @SQLStmt + 
		'REPLACE( REPLACE( REPLACE( sj.name, ''for DB Maintenance Plan '', '''' ), '' Job '', '''' ), ''Log Shipping'', ''LShip''),
		''Disabled'',
		''' + @varcharDateToday + ''',
		NULL,
		NULL,
		''' + @varcharDateToday + ''',
		sj.date_modified,
		sj.description,
		sj.name,
		l.name,
		isnull(o.name, '''')
	FROM 
		[' + @Server + '].msdb.dbo.sysjobs sj 
		JOIN [' + @Server + '].master.dbo.syslogins l  on sj.owner_sid = l.sid
		LEFT JOIN [' + @Server + '].msdb.dbo.sysoperators o  ON sj.notify_netsend_operator_id = o.id
	WHERE
		-- Only disabled jobs
		sj.enabled = 0 AND NOT EXISTS
		( SELECT * FROM DBA.dbo.Jobs t 
		  WHERE ServerName = ''' + @Server + ''' and 
		  RunDatetime = ''' + @varcharDateToday + ''' and OldJobName = sj.name )'

--PRINT @SQLStmt
EXEC ( @SQLStmt )
END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE dbo.usp_GetLastBackups 
	@Server varchar(50) = @@servername
AS
BEGIN
SET NOCOUNT ON
DECLARE	@Cmd varchar(1000)
SET @Cmd =
'INSERT INTO dbo.LastBackups( Server, DB, PlanName, Activity, Date )
SELECT ''' + @Server + ''', d.name, h.plan_name, h.activity, h.end_time
FROM [' + @Server + '].master.dbo.sysdatabases d LEFT JOIN
( 	SELECT plan_name, database_name, server_name, activity, max(end_time) as end_time
	FROM [' + @Server + '].msdb.dbo.sysdbmaintplan_history 
	WHERE succeeded = 1
	GROUP BY plan_name, database_name, server_name, activity
) AS h ON d.name = h.database_name
WHERE name NOT IN ( ''Northwind'', ''pubs'', ''tempdb'' )'
--PRINT @Cmd
EXEC( @Cmd )
END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE dbo.usp_GetRunningJobs  
		@Server varchar(60)
AS
BEGIN
SET NOCOUNT ON

DECLARE @SQL  varchar(1000)

SET @SQL ='[' + @Server + '].DBA.dbo.usp_GetAgentJobs'
--PRINT @SQL
EXEC(@SQL)

SET @SQL = 'INSERT INTO dbo.RunningJobs( Server, JobName, Date ) 
	SELECT ''' + @Server + ''', name, getdate() FROM [' + @Server + '].DBA.dbo.Agent_Jobs a 
	JOIN [' + @Server + '].msdb.dbo.sysjobs j ON a.job_id = j.job_id 
	WHERE running = 1'
--PRINT @SQL
EXEC(@SQL)
END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


CREATE PROCEDURE dbo.usp_GetTodaysZipFileName
	@FileName	varchar(50)
as
BEGIN
SET NOCOUNT ON
DECLARE 
	@DateStr varchar(10),
	@Today	 varchar(10),
	@ZipName varchar(121)

SET @Today = CONVERT( varchar(10), getdate(), 101 )
SET @DateStr = 	RIGHT( @Today, 4 ) + '-' + 
				LEFT( @Today, 2 )  + '-' + 
				SUBSTRING( @Today, 4, 2 )
SET @ZipName = @FileName + '_' + @DateStr + '.zip'
SELECT @ZipName
END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE dbo.usp_GetUserDatabaseList
AS
BEGIN
	SET NOCOUNT ON

	SELECT DISTINCT Databases.ServerName, Databases.DBName
	FROM  Users INNER JOIN Databases ON Users.DBId = Databases.DBId
UNION
	SELECT DISTINCT Databases.ServerName, '*'
	FROM  Users INNER JOIN Databases ON Users.DBId = Databases.DBId
END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE dbo.usp_Get_DbStats3
/***************************************************************

		This procedure records the disk space used by
		databases.

*****************************************************************/
AS
BEGIN
SET NOCOUNT ON

IF OBJECT_ID( 'dbo.tmplg' ) IS NULL
	CREATE TABLE dbo.tmplg
	( 
		DBName       	varchar( 64 ),
		LogSize			real,
		LogSpaceUsed	real,
		Status			int
	)

IF OBJECT_ID( 'dbo.tmp_sfs' ) IS NULL
	CREATE TABLE dbo.tmp_sfs
	(   
		DBName			nvarchar( 128 ),
		FileId	    	int,
		FileGroup		int, 
		TotalExtents	int, 
		UsedExtents		int, 
		Name			varchar( 1024 ), 
		FileName		varchar( 1024 )
	)

TRUNCATE TABLE DBA.dbo.tmplg
TRUNCATE TABLE DBA.dbo.tmp_sfs

INSERT INTO DBA.dbo.tmplg EXECUTE ( 'DBCC SQLPERF( logspace )' )

DECLARE	@CMD varchar( 2000 )
SET @CMD = 'USE [?] ' 
SET @CMD = @CMD + 'INSERT INTO DBA.dbo.tmp_sfs( FileId,FileGroup,TotalExtents,UsedExtents,Name,FileName	 ) '
SET @CMD = @CMD + ' EXEC( ''DBCC SHOWFILESTATS'' ) ' 
SET @CMD = @CMD + ' UPDATE DBA.dbo.tmp_sfs SET DBName = ''?'' WHERE DBName IS NULL '
EXEC sp_MSForEachDB @Command1=@CMD

INSERT INTO DBA.dbo.DBSTATS 
( 	DBName, Data_Size, Data_Used, 	Log_Size, Log_Used, State_Date, PercentLog )
	SELECT 	
			s.DBName,
			SUM( TotalExtents ) * 64 / 1024, 
			SUM( UsedExtents ) * 64 / 1024, 
			CAST( MAX( l.LogSize ) AS varchar ) ,
			CAST( ( MAX(l.LogSize) * MAX(l.LogSpaceUsed) ) / 100.0 AS varchar ),
			GETDATE(),
			MAX(LogSpaceUsed)
	FROM DBA.dbo.tmp_sfs s 
		JOIN DBA.dbo.tmplg l ON s.DBName = l.DBName
	WHERE s.DBName NOT IN( 'model', 'pubs', 'Northwind' )
	GROUP BY s.DBName
END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE dbo.usp_Get_WaitStats
AS
/*******************************************************

		This stored procedure creates a WaitStats 
		report that lists wait types by percentage.
		You can run the procedure while 
		usp_Track_WaitStats is executing.

*********************************************************/

SET NOCOUNT ON
DECLARE
	@Now		datetime,
	@TotalWait	numeric(20,1),
	@EndTime	datetime,
	@BeginTime	datetime,
	@Hr			int,
	@Min		int,
	@Sec		int

SELECT 	
	@Now 		= MAX( Now ), 
	@BeginTime 	= MIN( Now ), 
	@EndTime 	= MAX( Now )
FROM WaitStats
WHERE [Wait Type] = 'Total'

-- Subtract WaitFor, Sleep, and Resource_Queue from Total.
SELECT @TotalWait = SUM([Wait Time]) + 1 FROM WaitStats
WHERE [Wait Type] NOT IN 
	( 'WAITFOR', 'SLEEP', 'RESOURCE_QUEUE', 'Total', '***total***' ) AND
	Now = @Now

-- Insert adjusted totals and rank by percentage in descending order.
DELETE FROM WaitStats WHERE [Wait Type] = '***total***' AND Now = @Now
INSERT INTO WaitStats
	SELECT '***total***', 0, @TotalWait, @TotalWait, @Now

SELECT
	[Wait Type], 
	[Wait Time], 
	Percentage = CAST( 100 * [Wait Time] / @TotalWait as numeric(20,1) )
FROM WaitStats
WHERE [Wait Type] NOT IN( 'WAITFOR', 'SLEEP', 'RESOURCE_QUEUE', 'Total' )
	AND Now = @Now
ORDER BY Percentage desc

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


CREATE PROCEDURE dbo.usp_HelpIndexes

/***************************************************************

			Issues sp_helpindex for all of the user tables.

*****************************************************************/
AS
BEGIN

SET NOCOUNT ON

CREATE TABLE #Indexes
(
	TableName			varchar( 30 ),
	TableId				int,
	IndexId				int,
	IndexName			sysname,
	index_description 	varchar(210), 
	index_keys 			varchar(2078) 
)

DECLARE
	@Tablename	varchar( 30 ),
	@TableId	int,
	@SQl		varchar( 1000 )

DECLARE Tab_Curs CURSOR FOR
	SELECT DISTINCT o.name, o.id
	FROM sysobjects o join sysindexes i on i.id = o.id
	WHERE 	o.xtype = 'U' and 
			i.name not like '_WA_sys%' and 
			i.indid between 1 and 254

OPEN Tab_Curs
FETCH NEXT FROM Tab_Curs INTO @TableName, @TableId
WHILE @@FETCH_STATUS = 0
	BEGIN
	SET @SQL = 'sp_helpindex ' + @TableName
	INSERT INTO #Indexes( IndexName, Index_Description, Index_Keys )
	exec ( @SQL )
	
	UPDATE #Indexes
	SET TableName = @TableName,
		TableId   = @TableId
	WHERE TableName is null
	FETCH NEXT FROM Tab_Curs INTO @TableName, @TableId
	END
CLOSE Tab_Curs
DEALLOCATE Tab_Curs


UPDATE #Indexes
	SET IndexId = i.indid
FROM #Indexes t join sysindexes i on t.TableId   = i.id and  t.IndexName = i.name
		

UPDATE #Indexes
	SET Index_Description = 
		CASE WHEN CHARINDEX( 'located', Index_Description, 1  ) > 0 
			 THEN LEFT( Index_Description, CHARINDEX( 'located', Index_Description, 1  ) - 1 )
		END

DECLARE 
	@KeyString	varchar( 2078 ),
	@NewString  varchar( 2087 ),
	@ColCnt		int,
	@IndexId	int

DECLARE 
	Idx_Curs CURSOR FOR 
	SELECT TableId, IndexId, Index_Keys
	FROM #Indexes
	

OPEN Idx_Curs
FETCH NEXT FROM Idx_Curs INTO @TableId, @IndexId, @KeyString
WHILE @@FETCH_STATUS = 0
	begin
	SET @NewString = ''
	SET @ColCnt = 1
	WHILE CHARINDEX( ',', @KeyString, 1 ) > 0
		begin
		SET @NewString = @NewString +
						 LEFT( @KeyString, CHARINDEX( ',', @KeyString, 1 ) - 1 ) + 
						 CASE WHEN indexkey_property( @TableId, @IndexId, @ColCnt, 'isdescending') = 1
							  THEN ' DESC,'
						  	  ELSE ' ASC,'
					 	 END
		SET @KeyString = RIGHT( @KeyString, LEN( @KeyString ) - CHARINDEX( ',', @KeyString, 1 ) )
		SET @ColCnt = @ColCnt + 1
		end
	SET @NewString = @NewString + @KeyString + 
					 CASE WHEN indexkey_property( @TableId, @IndexId, @ColCnt, 'isdescending') = 1
						  THEN ' DESC'
						  ELSE ' ASC'
					 END
    UPDATE #Indexes
	SET Index_Keys = @NewString
	WHERE CURRENT OF Idx_Curs
		 
	FETCH NEXT FROM Idx_Curs INTO @TableId, @IndexId, @KeyString
	END
CLOSE Idx_Curs
DEALLOCATE Idx_Curs

SELECT * FROM #Indexes
ORDER BY TableName, IndexId
END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


CREATE PROCEDURE dbo.usp_JobsRefresh
as
BEGIN
SET NOCOUNT ON
DECLARE SERVER_CUR CURSOR FOR
	SELECT ServerName, SQLVersion
	FROM DBA.dbo.Servers 
	WHERE ServerName NOT LIKE '*%' and ActiveFlag = 1
	
DECLARE
	@SQLSTMT	varchar( 1000 ),
	@ServerName	varchar( 50 ),
	@SQLVersion	int

OPEN SERVER_CUR
FETCH NEXT FROM SERVER_CUR INTO @ServerName, @SQLVersion
WHILE @@FETCH_STATUS = 0
	BEGIN
	SET @SQLSTMT = 'EXEC DBA.dbo.usp_GetJobs ''' + @ServerName + ''',' + cast(@SQLVersion as varchar) + ''''
	PRINT @SQLSTMT
	EXEC( @SQLSTMT )
	FETCH NEXT FROM SERVER_CUR INTO @ServerName, @SQLVersion
	END
CLOSE SERVER_CUR
DEALLOCATE SERVER_CUR

SELECT * FROM dbo.Jobs
ORDER BY CAST( RunDate as datetime ) desc, ServerName, RunTime
END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE dbo.usp_JobsRunning
AS
BEGIN
SET NOCOUNT ON
TRUNCATE TABLE DBA.dbo.RunningJobs

DECLARE SERVER_CUR CURSOR FOR 
	SELECT ServerName FROM DBA.dbo.Servers
	WHERE ServerName <> '*ALL' and ActiveFlag = 1 

DECLARE 
	@Server varchar(60),
	@cmd	varchar(1000)

OPEN SERVER_CUR
FETCH NEXT FROM SERVER_CUR INTO @Server
WHILE @@FETCH_STATUS = 0
	begin
	PRINT @Server
	SET @cmd = 'exec DBA.dbo.usp_GetRunningJobs ''' + @Server + ''''
	--PRINT @cmd
	EXEC( @cmd )
	FETCH NEXT FROM SERVER_CUR INTO @Server
	end
CLOSE SERVER_CUR
DEALLOCATE SERVER_CUR

SELECT * FROM dbo.RunningJobs ORDER BY Server
END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE dbo.usp_MaintenancePlans 
	@Server varchar(60) = @@servername
AS
BEGIN
SET NOCOUNT ON
PRINT '    usp_MaintenancePlans'

DECLARE	@Cmd varchar(1000)
SET @Cmd =
'INSERT INTO dbo.MaintenancePlans( PlanName, Activity, Date, DBId )
SELECT h.plan_name, h.activity, h.end_time, v.DBId
FROM [' + @Server + '].master.dbo.sysdatabases d 
	JOIN dbo.Databases v ON v.DBName = d.name and v.ServerName = ''' + @Server +
	''' LEFT JOIN
( 	SELECT plan_name, database_name, server_name, activity, max(end_time) as end_time
	FROM [' + @Server + '].msdb.dbo.sysdbmaintplan_history 
	WHERE succeeded = 1 and DATEADD( m, 1, end_time ) >= GETDATE()
	GROUP BY plan_name, database_name, server_name, activity
) AS h ON d.name = h.database_name
WHERE name NOT IN ( ''Northwind'', ''pubs'', ''tempdb'' )'

--PRINT @Cmd
EXEC( @Cmd )

SET @Cmd =
'INSERT INTO dbo.MaintenancePlans( PlanName, Activity, Date, DBId )
SELECT j.name, ''Differential'', RunDate, d.DBId
FROM [' + @Server + '].msdb.dbo.sysjobs j 
	join [' + @Server + '].msdb.dbo.sysjobsteps st on j.job_id = st.job_id
	join ( select job_id, max( cast( cast( run_date as varchar ) as datetime ) ) as RunDate
		   from [' + @Server + '].msdb.dbo.sysjobhistory
			group by job_id
		) as hist on hist.job_id = j.job_id
	join DBA.dbo.Databases d 
		on d.ServerName = ''' + @Server + ''' and
		d.DBName =  substring( st.command, charindex('''''''', st.command ) + 1,  charindex( '','', st.command ) -1 - charindex('''''''', st.command ) - 1 )
WHERE
	st.command like ''%usp_DifferentialBackup%'''
--PRINT @Cmd
EXEC( @Cmd )
END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE dbo.usp_Packages	
		@Server		sysname = @@Servername,
		@Version	int = 2
AS
BEGIN
SET NOCOUNT ON
PRINT '    usp_Packages'

DECLARE @Cmd	varchar(1000)
SET @Cmd =
'INSERT INTO dbo.Packages( ServerName, PkgName, Description, Created, LastModified, Owner )
	SELECT ''' + @Server + ''', p.name, 
	CASE WHEN d.description like ''DTS package description%'' THEN ''''
         ELSE d.description END, 
	p.Created, p.LastModified, d.owner
	FROM [' + @Server + '].msdb.dbo.sysdtspackages d
		join
		( 	select name, min(createdate) as Created, max(createdate) as LastModified
			from [' + @Server + '].msdb.dbo.sysdtspackages
			group by name
		) as p on 	d.name = p.name and 
			  	d.createdate = p.LastModified'
--PRINT @Cmd
EXEC( @Cmd )

-- This will pick up the jobs or job steps whose names match a package name
-- The DTSRun command itself may be encrypted
SET @Cmd =
'UPDATE dbo.Packages SET Job = 1 
WHERE ServerName = ''' + @Server + ''' and 
PKGName IN ( SELECT name FROM [' + @Server + '].msdb.dbo.sysjobs UNION 
SELECT step_name FROM [' + @Server + '].msdb.dbo.sysjobsteps )'
--PRINT @Cmd
EXEC( @Cmd )

-- This will pick up the job steps where the package name is not encrypted
SET @Cmd =
'UPDATE dbo.Packages SET Job = 1
WHERE ServerName = ''' + @Server + ''' and 
EXISTS ( SELECT * FROM [' + @Server + '].msdb.dbo.sysjobsteps 
WHERE  command LIKE ''DTSRUN%'' and command like ''%'' + PKGName + ''%'' )'
--PRINT @Cmd
EXEC( @Cmd )

IF @Version <> 7
	begin
	SET @Cmd = 
	'INSERT INTO DBA.dbo.PackageSteps
	(	Stepname, Errorcode, ProgressCount, 
		Starttime, Endtime, Elapsedtime, ErrorDescription, PkgId )
	SELECT
		s.stepname, s.errorcode, s.progresscount, 
		s.starttime, s.endtime, s.elapsedtime, s.errordescription, p.Id
	FROM
		[' + @Server + '].msdb.dbo.sysdtspackagelog L
		JOIN ( 	SELECT id, max( starttime) as maxstart 
				FROM [' + @Server + '].msdb.dbo.sysdtspackagelog
		  		GROUP BY id ) as LL on LL.id = L.id
		JOIN DBA.dbo.Packages p on p.ServerName = ''' + @Server + ''' and p.PkgName = L.name
		LEFT JOIN [' + @Server + '].msdb.dbo.sysdtssteplog s on L.lineagefull = s.lineagefull 
	WHERE L.starttime = LL.maxstart
	ORDER BY name, s.starttime'
	--PRINT @Cmd
	EXEC( @Cmd )
	end
END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE dbo.usp_PhysicalDefrag
	( @ExecDefrag	char( 1 ) = 'N', 
	  @MaxFrag		decimal = 10.0,  
	  @PrintTable	char( 1 ) = 'N' )
AS
/*******************************************************************************************

		Does a physical defragmentation of the indexes in the current database 
		whose extent fragmentation is greater than @MaxFrag using DBCC DBREINDEX.

		Author:  Irene Hill
		Revision Date:  06/12/03/

		Input values than can be modified:  
		@MaxFrag:  		The maximum percent fragmentation that
						must exist in order to be considered for 
						defragmentation.  The default value for @MaxFrag
						is 10.0%, but it can be modified to any value.

		@PrintTable: 	A flag to indicate whether or not the contents
					 	of the #Fraglist table should be displayed.  This
					 	table holds the results of issueing a DBCC SHOWCONTIG
					 	for each of the tables in the database before any
					 	defragmention is done.  The default is 'Y'.

		@ExecDefrag: 	A flag to indicate whether the DBCC INDEXDEFRAG command
					 	should be executed.  The default is 'Y'.

************************************************************************************************/
BEGIN

SET NOCOUNT ON
-- DROP TABLE #FragList

DECLARE	
	@TableName		varchar( 50 ),
	@IndexName  	varchar( 50 ),
 	@ExecStr		varchar( 255 ),
	@Owner			sysname,
 	@TableId		int,
	@IndexId		int,
	@LogicalFrag	decimal,
	@ExtentFrag		decimal,
	@PrevTable		varchar( 50 ),
	@Count			int


PRINT 'Start time:  ' + cast( getdate() as varchar )
PRINT 'DATABASE:  ' + DB_NAME()
PRINT ' '

DECLARE
	Tables CURSOR FOR
	SELECT 	TABLE_NAME, TABLE_SCHEMA
	FROM	INFORMATION_SCHEMA.TABLES
	WHERE	TABLE_TYPE = 'BASE TABLE' 
	ORDER BY TABLE_NAME	

CREATE TABLE #FragList
(	ObjectName		char( 255 ),
	ObjectId		int,
	IndexName		char( 255 ),
	IndexId			int,
	Lvl				int,
	CountPages		int,
	CountRows		int,
	MinRecSize		int,
	MaxRecSize		int,
	AvgRecSize		int,
	ForRecCount		int,
	Extents			int,
	ExtentSwitches	int,
	AvgFreeBytes	int,
	AvgPageDensity	decimal,
	ScanDensity		decimal,
	BestCount		int,
	ActualCount		int,
	LogicalFrag		decimal,
	ExtentFrag		decimal,
	Owner			sysname NULL
)

SET @Count = 0
OPEN Tables
FETCH NEXT FROM Tables INTO @TableName, @Owner

WHILE @@FETCH_STATUS = 0
BEGIN
	SET @Count = @Count + 1
-- Run the DBCC SHOWCONTIG command to view
-- fragmentation information about all the table's indexes.
	PRINT @Owner + '.' + @TableName
	INSERT INTO #FragList( ObjectName, ObjectId, IndexName, IndexId, Lvl, CountPages,
						   CountRows, MinRecSize, MaxRecSize, AvgRecSize, ForRecCount,
						   Extents, ExtentSwitches, AvgFreeBytes, AvgPageDensity,
						   ScanDensity, BestCount, ActualCount, LogicalFrag, ExtentFrag	
						 )
	EXEC ( 'DBCC SHOWCONTIG ( ''' + @Owner + '.' + @TableName + ''' ) WITH FAST, TABLERESULTS, ALL_INDEXES, NO_INFOMSGS' )
	
	UPDATE #FragList
	SET Owner = @Owner
	WHERE Owner is NULL

	FETCH NEXT FROM Tables INTO @TableName, @Owner
END

CLOSE Tables
DEALLOCATE Tables
PRINT 'TOTAL TABLES:  ' + cast( @Count as varchar )
SELECT @Count = count(*) FROM #Fraglist WHERE IndexId > 0
PRINT 'TOTAL INDEXES:  ' + cast( @Count as varchar )
PRINT ' '

-- SELECT * FROM #FragList

-- Declare cursor for list of indexes to be defragmented.
-- Sort the cursor by tablename and indexid so that all
-- of the for a given table will be grouped together and
-- so the IndexId 1 ( the clustered index ) with be first.

DECLARE
	Indexes CURSOR FOR
	SELECT 	RTRIM( ObjectName ), ObjectId, IndexId, 
			ISNULL( ExtentFrag, 0 ), ISNULL( LogicalFrag, 0 ), RTRIM( s.name ),
			f.Owner 
	FROM 	
		#FragList f JOIN
		sysindexes s ON f.ObjectId = s.id 	AND 
						f.IndexID  = s.indid
	WHERE	
		IndexId > 0
			
	ORDER BY 
		ObjectName,IndexId

OPEN Indexes
SET @PrevTable = ''

FETCH NEXT FROM Indexes INTO @TableName, @TableId, @IndexId, @ExtentFrag, 
							 @LogicalFrag, @IndexName, @Owner
if @@FETCH_STATUS <> 0
	PRINT 'No indexes to be defragmented.'

WHILE @@FETCH_STATUS = 0
BEGIN
		
	PRINT @TableName + ', ' + @IndexName + ' - Extent fragmentation currently ' + 
			RTRIM( CONVERT( varchar( 15 ), @ExtentFrag )) + '%'
		
	PRINT @TableName + ', ' + @IndexName + ' - Logical fragmentation currently ' + 
			RTRIM( CONVERT( varchar( 15 ), @LogicalFrag )) + '%'

	IF @IndexId = 1
		PRINT 'CLUSTERED INDEX'
	ELSE
		PRINT 'NON-CLUSTERED INDEX'


	IF @ExecDefrag = 'Y' and 
			( ISNULL( @ExtentFrag, 0 ) > @MaxFrag or ISNULL( @LogicalFrag, 0 ) > @MaxFrag )  
		begin
		SET @ExecStr = 'DBCC DBREINDEX( ''' + @Owner + '.' + @TableName + ''', ' + @IndexName + ' )'
		PRINT @ExecStr
		PRINT ' '
		EXEC ( @ExecStr )
			
		-- If the index is clustered, then rebuilding it automatically 
		-- rebuilds all indexes on the table

		IF @IndexId = 1
			begin
			PRINT ' '
			PRINT 'Defrag results for ' + @TableName  + ':  '
			EXEC ( 'DBCC SHOWCONTIG ( ''' + @Owner + '.' + @TableName + ''' ) WITH FAST' )
			PRINT ' '
			SET @ExecStr = 'sp_recompile ''' + @Owner + '.[' + @TableName + ']'''
			PRINT @ExecStr
			EXEC ( @ExecStr )
			SET @PrevTable = @TableName
			WHILE @@FETCH_STATUS = 0 and @TableName = @PrevTable
				FETCH NEXT FROM Indexes INTO @TableName, @TableId, @IndexId, @ExtentFrag, 
											 @LogicalFrag, @IndexName, @Owner
			end
		ELSE
			begin
			PRINT ' '
			PRINT 'Defrag results for ' + @TableName + ', ' + @IndexName + ':  '
			EXEC ( 'DBCC SHOWCONTIG ( ''' + @Owner + '.' + @TableName + ''', ' + @IndexId + ' ) WITH FAST' )
			IF @TableName <> @PrevTable
				begin
				PRINT ' '
				SET @ExecStr = 'sp_recompile ''' + @Owner + '.[' + @TableName + ']'''
				PRINT @ExecStr
				EXEC ( @ExecStr )
				SET @PrevTable = @TableName
				end
			FETCH NEXT FROM Indexes INTO @TableName, @TableId, @IndexId, @ExtentFrag, 
										 @LogicalFrag, @IndexName, @Owner
			end
		end
	ELSE
		FETCH NEXT FROM Indexes INTO @TableName, @TableId, @IndexId, @ExtentFrag, 
									 @LogicalFrag, @IndexName, @Owner

	PRINT ' '
	PRINT '***********************************************************************'
	PRINT ' '
END

CLOSE Indexes
DEALLOCATE Indexes

IF @PrintTable = 'Y'
	SELECT * FROM #FragList
	ORDER BY ObjectName, IndexId

PRINT 'End time:  ' + cast( getdate() as varchar )
DROP TABLE #FragList
END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


CREATE PROCEDURE dbo.usp_RecoveryModel
		 @DB	varchar(60)
		
AS
BEGIN
DECLARE @Model varchar(60)

SELECT @Model = cast( DATABASEPROPERTYEX( name, 'recovery') as varchar )
FROM master.dbo.sysdatabases WHERE name = @DB
RETURN @Model
END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE dbo.usp_RefreshActivity
	@Server		varchar(60) = @@Servername

/*********************************************

		Gets Activity and Lock info
		from another server's tables.

*********************************************/

AS
BEGIN
SET NOCOUNT ON

BEGIN TRAN
DELETE FROM dbo.User_Locks    
FROM dbo.User_Activity a JOIN dbo.User_Locks l on a.Id = l.ActivityId
WHERE a.ServerName = @Server

DELETE FROM dbo.User_Activity WHERE ServerName = @Server
COMMIT

DECLARE @Cmd varchar(3000)
EXEC( @Cmd )

SET @Cmd = 
	'INSERT INTO dbo.User_Activity
	( ServerName, SPID, Status, Login,	Host, Block, BlkBy,	DB, Command, CPUTime, DiskIO, 
	LastBatch, Program, Buffer, FetchDate	)
	SELECT ''' + @Server + ''', SPID, Status, Login, Host, Block, BlkBy, DB, Command, 
	CPUTime, DiskIO, LastBatch, Program, Buffer, FetchDate
	FROM [' + @Server + '].DBA.dbo.User_Activity_Loc'
--PRINT @Cmd
EXEC( @Cmd )

SET @Cmd = 
	'INSERT INTO dbo.User_Locks
	( ActivityId, ObjName, IndexName, Type, Resource, Mode, Status)
	SELECT a.Id, ObjName, IndexName, Type, Resource, Mode, l.Status
	FROM [' + @Server + '].DBA.dbo.User_Locks_Loc l 
	JOIN dbo.User_Activity a on a.SPID = l.SPID and ServerName = ''' + @Server + ''''
--PRINT @Cmd
EXEC( @Cmd )

UPDATE dbo.User_Activity
SET Lock = 1
WHERE Id in ( Select distinct ActivityId from dbo.User_Locks )
END
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE dbo.usp_RefreshFreeSpace
AS
BEGIN
SET NOCOUNT ON
DECLARE SERVER_CUR CURSOR FOR 
	SELECT ServerName FROM DBA.dbo.Servers
	WHERE ServerName <> '*ALL' and ActiveFlag = 1

DECLARE 
	@Server varchar(60),
	@cmd	varchar(1000)

OPEN SERVER_CUR
FETCH NEXT FROM SERVER_CUR INTO @Server
WHILE @@FETCH_STATUS = 0
	begin
	SET @cmd = 'exec [' + @Server + '].DBA.dbo.usp_CollectFreeSpaceStats ''Y'''
	--PRINT @cmd
	EXEC( @cmd )
	EXEC DBA.dbo.usp_SaveServerFreespace @Server		
	FETCH NEXT FROM SERVER_CUR INTO @Server
	end
CLOSE SERVER_CUR
DEALLOCATE SERVER_CUR
END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE dbo.usp_RefreshRunningJobs
AS
BEGIN
SET NOCOUNT ON
TRUNCATE TABLE DBA.dbo.RunningJobs

DECLARE SERVER_CUR CURSOR FOR 
	SELECT ServerName FROM DBA.dbo.Servers
	WHERE ServerName <> '*ALL' and ActiveFlag = 1 

DECLARE 
	@Server varchar(60),
	@cmd	varchar(1000)

OPEN SERVER_CUR
FETCH NEXT FROM SERVER_CUR INTO @Server
WHILE @@FETCH_STATUS = 0
	begin
	PRINT @Server
	SET @cmd = 'exec DBA.dbo.usp_GetRunningJobs ''' + @Server + ''''
	--PRINT @cmd
	EXEC( @cmd )
	FETCH NEXT FROM SERVER_CUR INTO @Server
	end
CLOSE SERVER_CUR
DEALLOCATE SERVER_CUR

SELECT * FROM dbo.RunningJobs ORDER BY Server
END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE dbo.usp_RunningJobs
AS
BEGIN
SET NOCOUNT ON
TRUNCATE TABLE DBA.dbo.RunningJobs

DECLARE SERVER_CUR CURSOR FOR 
	SELECT ServerName FROM DBA.dbo.Servers
	WHERE ServerName <> '*ALL' and ActiveFlag = 1 

DECLARE 
	@Server varchar(60),
	@cmd	varchar(1000)

OPEN SERVER_CUR
FETCH NEXT FROM SERVER_CUR INTO @Server
WHILE @@FETCH_STATUS = 0
	begin
	PRINT @Server
	SET @cmd = 'exec DBA.dbo.usp_GetRunningJobs ''' + @Server + ''''
	--PRINT @cmd
	EXEC( @cmd )
	FETCH NEXT FROM SERVER_CUR INTO @Server
	end
CLOSE SERVER_CUR
DEALLOCATE SERVER_CUR

SELECT * FROM dbo.RunningJobs ORDER BY Server
END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE dbo.usp_SaveServerFreespace
		@Server		varchar( 50 ) = @@Servername

/*************************************************************

		Writes disk space data from the server whose name
		is passed in to the DB_FreeSpace_Stats
	    table in the DBA database on the local server.

		Sample:  exec usp_SaveServerFreespace '2KSQLPROD2'

**************************************************************/
AS
BEGIN
SET NOCOUNT ON
PRINT '    usp_SaveServerFreespace'

DECLARE
	@SQLStmt		varchar ( 500 )

SET @SQLStmt = 
	'INSERT INTO dbo.All_Free_Space( ServerName, Drive, Freespace, Date_Collected, DB )
	 SELECT a.ServerName, a.Drive, CAST( a.FreeSpace as decimal( 9, 2 ) ), a.State_Date, DB 
	 FROM [' + @Server + '].DBA.dbo.DB_Freespace_Stats a
	 WHERE State_Date NOT IN 
	( SELECT Date_Collected FROM dbo.All_Free_Space WHERE ServerName = a.ServerName )'

--PRINT @SQLStmt
EXEC( @SQLStmt )
END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE dbo.usp_Schedules 
	@Server	varchar(80) = @@ServerName,
	@Version int = 2
AS
BEGIN
SET NOCOUNT ON
PRINT '    usp_Schedules'

DECLARE @Cmd	varchar(6000)

IF @Version = 5
	SET @Cmd =
	'INSERT INTO DBA.dbo.Schedules
	(	ServerName, JobName, OrigSrv, JobType, [Desc], Owner, NetSend, Created, Modified,
		SchedName, Freq, [When], [Time], 
		NextRunDate, NextRunTime, MaintPlan, DTS, History, StepId, StepName ) 
	SELECT 
		''' + @Server + ''',
		REPLACE( REPLACE( REPLACE( j.name, ''for DB Maintenance Plan '', '''' ), 
				'' Job '', '''' ), ''Log Shipping'', ''LShip''), 
		''' + @Server + ''',
		CASE c.category_type
			WHEN 1 THEN ''Local''
			WHEN 2 THEN ''Multiserver''
			ELSE ''''
		END,
		LEFT( ISNULL( j.description, '''' ), 512 ),  
		l.name, 
		ISNULL( o.name, '''' ),
		j.date_created,
		j.date_modified,
		ISNULL( ss.name, '''' ),
		CASE ss.freq_type
			WHEN 1 	THEN ''Once''
			WHEN 4 	THEN ''Daily''
			WHEN 8 	THEN ''Weekly''
			WHEN 16 THEN ''Monthly''
			WHEN 32 THEN ''Monthly''
			WHEN 64 THEN ''When SQL Server Agent starts''
			WHEN 128 THEN ''Idle''
			ELSE ''''
		END,
		CASE 
			WHEN ss.freq_type = 4  THEN ''Every '' + cast( ss.freq_interval as varchar ) + '' days''
			WHEN ss.freq_type = 8  THEN cast( ss.freq_interval as varchar )
			WHEN ss.freq_type = 16 THEN ''On day '' +  cast( ss.freq_interval as varchar )
			WHEN ss.freq_type = 32 THEN 
				CASE ss.freq_relative_interval
					WHEN 1	THEN ''Every first ''
					WHEN 2	THEN ''Every second ''
					WHEN 4	THEN ''Every third ''
					WHEN 8	THEN ''Every fourth ''
					WHEN 16 THEN ''Every last ''
					ELSE ''''
				END + 
				CASE ss.freq_interval
					WHEN 1 	THEN ''Sunday''
					WHEN 2	THEN ''Monday''
					WHEN 3 	THEN ''Tuesday''
					WHEN 4  THEN ''Wednesday''
					WHEN 5 	THEN ''Thursday''
					WHEN 6 	THEN ''Friday''
					WHEN 7 	THEN ''Saturday''
					WHEN 8	THEN ''Day''
					WHEN 9	THEN ''Weekday''
					WHEN 10 THEN ''Weekend day''
					ELSE ''''
				END
			ELSE ''''
		END,
		CASE ss.freq_subday_type
			WHEN 1	THEN 
				CASE 
					WHEN s.next_run_time IS NULL THEN NULL
				ELSE
					LEFT( REPLICATE(''0'', 6 - LEN( cast( s.next_run_time as varchar ) ) )
					+ cast( s.next_run_time as varchar ), 2 ) + '':'' +
					SUBSTRING( REPLICATE(''0'', 6 - LEN( cast( s.next_run_time as varchar ) ) )
					+ cast( s.next_run_time as varchar ), 3, 2 ) + '':'' +
					RIGHT( REPLICATE(''0'', 6 - LEN( cast( s.next_run_time as varchar ) ) )
					+ cast( s.next_run_time as varchar ), 2 )
				END
			WHEN 2	THEN ''Every '' + cast( ss.freq_subday_interval as varchar ) + '' Sec''
			WHEN 4	THEN ''Every '' + cast( ss.freq_subday_interval as varchar ) + '' Min''
			WHEN 8	THEN ''Every '' + cast( ss.freq_subday_interval as varchar ) + '' Hr''
			ELSE ''''
		END,
		CASE
			WHEN LEN( ISNULL( cast( s.next_run_date as varchar ), '''' ) ) = 8
			THEN
				SUBSTRING( cast( s.next_run_date as varchar ), 5, 2 ) + ''/'' + 
				RIGHT( cast( s.next_run_date as varchar ), 2 ) + ''/'' + 
				LEFT( cast( s.next_run_date as varchar ), 4 )
		END,
		CASE
			WHEN s.next_run_time IS NULL THEN NULL
			ELSE
			LEFT( REPLICATE(''0'', 6 - LEN( cast( s.next_run_time as varchar ) ) )
				+ cast( s.next_run_time as varchar ), 2 ) + '':'' +
			SUBSTRING( REPLICATE(''0'', 6 - LEN( cast( s.next_run_time as varchar ) ) )
				+ cast( s.next_run_time as varchar ), 3, 2 ) + '':'' +
			RIGHT( REPLICATE(''0'', 6 - LEN( cast( s.next_run_time as varchar ) ) )
				+ cast( s.next_run_time as varchar ), 2 )
		END,
		CASE WHEN m.job_id IS NOT NULL THEN 1 ELSE 0 END,
		CASE WHEN dts.step_id IS NOT NULL THEN 1 ELSE 0 END,
		left(REPLACE( REPLACE( REPLACE( hist.History, '' '', '''' ), '''''''', '''' ), '','', '''' ), 10 ) as history,
		hist.step_id,
		LEFT( hist.step_name, 128 )
	FROM [' + @Server + '].msdb.dbo.sysjobs j 
		JOIN [' + @Server + '].master.dbo.syslogins l on j.owner_sid = l.sid
		JOIN [' + @Server + '].msdb.dbo.syscategories c ON j.category_id = c.category_id 
		LEFT JOIN [' + @Server + '].msdb.dbo.sysoperators o ON j.notify_netsend_operator_id = o.id
		LEFT JOIN [' + @Server + '].msdb.dbo.sysjobschedules s ON s.job_id = j.job_id 
		LEFT JOIN [' + @Server + '].msdb.dbo.sysschedules ss ON ss.schedule_id = s.schedule_id and ss.enabled = 1
		LEFT JOIN 
			( SELECT job_id, max( step_id ) as step_id FROM [' + @Server + '].msdb.dbo.sysjobsteps 
	  	  	WHERE command like ''DTSRun%'' GROUP BY job_id ) as dts ON dts.job_id = j.job_id
		LEFT JOIN 
			( SELECT job_id, step_id, step_name,
			CASE
				WHEN command like ''%-DelBkUps %''  THEN
					SUBSTRING( command, charindex( ''-DelBkUps '', command ) + 10, 
		    		charindex( ''-'', command, ( charindex( ''-DelBkUps '', command ) + 10 )) -
		 			( charindex( ''-DelBkUps '', command ) + 10 ) ) 
				WHEN command like ''%usp_DeleteDiffHistory %'' THEN
					LTRIM( right(cast(command as varchar), charindex( '','', 
					reverse(cast(command as varchar)), charindex( '','', reverse(cast(command as varchar) ) + 1 ) -1 )))
				WHEN command like ''%usp_DeleteBakHistory %'' THEN
					LTRIM( right(cast(command as varchar), charindex( '','', 
					reverse(cast(command as varchar)), charindex( '','', reverse(cast(command as varchar) ) + 1 ) -1 )))
				ELSE ''''
			END as history
		  FROM [' + @Server + '].msdb.dbo.sysjobsteps 
		) as hist ON hist.job_id = j.job_id
		LEFT JOIN [' + @Server + '].msdb.dbo.sysdbmaintplan_jobs m ON m.job_id = j.job_id
	WHERE j.enabled = 1 and c.category_class = 1'

ELSE
	SET @Cmd =
	'INSERT INTO DBA.dbo.Schedules
	(	ServerName, JobName, OrigSrv, JobType, [Desc], Owner, NetSend, Created, Modified,
		SchedName, Freq, [When], [Time], 
		NextRunDate, NextRunTime, MaintPlan, DTS, History, StepId, StepName ) 
	SELECT 
		''' + @Server + ''',
		REPLACE( REPLACE( REPLACE( j.name, ''for DB Maintenance Plan '', '''' ), 
				'' Job '', '''' ), ''Log Shipping'', ''LShip''), 
		ISNULL(j.originating_server, '''' ),
		CASE c.category_type
			WHEN 1 THEN ''Local''
			WHEN 2 THEN ''Multiserver''
			ELSE ''''
		END,
		LEFT( ISNULL( j.description, '''' ), 512 ),  
		l.name, 
		ISNULL( o.name, '''' ),
		j.date_created,
		j.date_modified,
		ISNULL( s.name, '''' ),
		CASE s.freq_type
			WHEN 1 	THEN ''Once''
			WHEN 4 	THEN ''Daily''
			WHEN 8 	THEN ''Weekly''
			WHEN 16 THEN ''Monthly''
			WHEN 32 THEN ''Monthly''
			WHEN 64 THEN ''When SQL Server Agent starts''
			ELSE ''''
		END,
		CASE 
			WHEN s.freq_type = 4  THEN ''Every '' + cast( s.freq_interval as varchar ) + '' days''
			WHEN s.freq_type = 8  THEN cast( s.freq_interval as varchar )
			WHEN s.freq_type = 16 THEN ''On day '' +  cast( s.freq_interval as varchar )
			WHEN s.freq_type = 32 THEN 
				CASE s.freq_relative_interval
					WHEN 1	THEN ''Every first ''
					WHEN 2	THEN ''Every second ''
					WHEN 4	THEN ''Every third ''
					WHEN 8	THEN ''Every fourth ''
					WHEN 16 THEN ''Every last ''
					ELSE ''''
				END + 
				CASE s.freq_interval
					WHEN 1 	THEN ''Sunday''
					WHEN 2	THEN ''Monday''
					WHEN 3 	THEN ''Tuesday''
					WHEN 4  THEN ''Wednesday''
					WHEN 5 	THEN ''Thursday''
					WHEN 6 	THEN ''Friday''
					WHEN 7 	THEN ''Saturday''
					WHEN 8	THEN ''Day''
					WHEN 9	THEN ''Weekday''
					WHEN 10 THEN ''Weekend day''
					ELSE ''''
				END
			ELSE ''''
		END,
		CASE s.freq_subday_type
			WHEN 1	THEN 
				CASE 
					WHEN s.next_run_time IS NULL THEN NULL
					ELSE
					LEFT( REPLICATE(''0'', 6 - LEN( cast( s.next_run_time as varchar ) ) )
					+ cast( s.next_run_time as varchar ), 2 ) + '':'' +
					SUBSTRING( REPLICATE(''0'', 6 - LEN( cast( s.next_run_time as varchar ) ) )
					+ cast( s.next_run_time as varchar ), 3, 2 ) + '':'' +
					RIGHT( REPLICATE(''0'', 6 - LEN( cast( s.next_run_time as varchar ) ) )
					+ cast( s.next_run_time as varchar ), 2 )
				END
			WHEN 2	THEN ''Every '' + cast( s.freq_subday_interval as varchar ) + '' Sec''
			WHEN 4	THEN ''Every '' + cast( s.freq_subday_interval as varchar ) + '' Min''
			WHEN 8	THEN ''Every '' + cast( s.freq_subday_interval as varchar ) + '' Hr''
			ELSE ''''
		END,
		CASE
			WHEN LEN( ISNULL( cast( s.next_run_date as varchar ), '''' ) ) = 8
			THEN
				SUBSTRING( cast( s.next_run_date as varchar ), 5, 2 ) + ''/'' + 
				RIGHT( cast( s.next_run_date as varchar ), 2 ) + ''/'' + 
				LEFT( cast( s.next_run_date as varchar ), 4 )
		END,
		CASE
			WHEN s.next_run_time IS NULL THEN NULL
			ELSE
			LEFT( REPLICATE(''0'', 6 - LEN( cast( s.next_run_time as varchar ) ) )
				+ cast( s.next_run_time as varchar ), 2 ) + '':'' +
			SUBSTRING( REPLICATE(''0'', 6 - LEN( cast( s.next_run_time as varchar ) ) )
				+ cast( s.next_run_time as varchar ), 3, 2 ) + '':'' +
			RIGHT( REPLICATE(''0'', 6 - LEN( cast( s.next_run_time as varchar ) ) )
				+ cast( s.next_run_time as varchar ), 2 )
		END,
		CASE WHEN m.job_id IS NOT NULL THEN 1 ELSE 0 END,
		CASE WHEN dts.step_id IS NOT NULL THEN 1 ELSE 0 END,
		left(REPLACE( REPLACE( REPLACE( hist.History, '' '', '''' ), '''''''', '''' ), '','', '''' ), 10 ) as history,
		hist.step_id,
		LEFT( hist.step_name, 128 )
	FROM [' + @Server + '].msdb.dbo.sysjobs j 
		JOIN [' + @Server + '].master.dbo.syslogins l on j.owner_sid = l.sid
		JOIN [' + @Server + '].msdb.dbo.syscategories c ON j.category_id = c.category_id 
		LEFT JOIN [' + @Server + '].msdb.dbo.sysoperators o ON j.notify_netsend_operator_id = o.id
		LEFT JOIN [' + @Server + '].msdb.dbo.sysjobschedules s ON s.job_id = j.job_id and s.enabled = 1
		LEFT JOIN 
		( SELECT job_id, max( step_id ) as step_id FROM [' + @Server + '].msdb.dbo.sysjobsteps 
	  	  WHERE command like ''DTSRun%'' GROUP BY job_id ) as dts ON dts.job_id = j.job_id
		LEFT JOIN 
		( SELECT job_id, step_id, step_name,
			CASE
				WHEN command like ''%-DelBkUps %''  THEN
					SUBSTRING( command, charindex( ''-DelBkUps '', command ) + 10, 
		    		charindex( ''-'', command, ( charindex( ''-DelBkUps '', command ) + 10 )) -
		 			( charindex( ''-DelBkUps '', command ) + 10 ) ) 
				WHEN command like ''%usp_DeleteDiffHistory %'' THEN
					LTRIM( right( command, charindex( '','', reverse(command), charindex( '','', reverse(command) ) + 1 ) -1 ))
				WHEN command like ''%usp_DeleteBakHistory %'' THEN
					LTRIM( right( command, charindex( '','', reverse(command), charindex( '','', reverse(command) ) + 1 ) -1 ))
				ELSE ''''
			END as history
		  FROM [' + @Server + '].msdb.dbo.sysjobsteps 
		) as hist ON hist.job_id = j.job_id
		LEFT JOIN [' + @Server + '].msdb.dbo.sysdbmaintplan_jobs m ON m.job_id = j.job_id
	WHERE j.enabled = 1 and c.category_class = 1'

--PRINT @Cmd
EXEC(@Cmd)
END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE dbo.usp_ServerPermissions
	@Server varchar(60) = @@ServerName
AS
BEGIN
SET NOCOUNT ON
PRINT '    usp_ServerPermissions ' + @Server

DECLARE @SqlCmd varchar( 3000 )

SET @SqlCmd = '
INSERT INTO dbo.ServerPermissions
( ServerName,Login,Sys,Security,Server,Setup,Process,[Disk],DBCreator )
SELECT ''' + @Server + ''' , name, 
	CASE sysadmin 		WHEN 1 THEN ''Y'' ELSE ''N'' END,
	CASE securityadmin 	WHEN 1 THEN ''Y'' ELSE ''N'' END,
	CASE serveradmin 	WHEN 1 THEN ''Y'' ELSE ''N'' END,
	CASE setupadmin 	WHEN 1 THEN ''Y'' ELSE ''N'' END,
	CASE processadmin 	WHEN 1 THEN ''Y'' ELSE ''N'' END,
	CASE diskadmin 		WHEN 1 THEN ''Y'' ELSE ''N'' END,
	CASE dbcreator 		WHEN 1 THEN ''Y'' ELSE ''N'' END
FROM [' + @Server + '].master.dbo.syslogins
WHERE 
	name IS NOT NULL AND 
	name NOT IN( ''BUILTIN\Administrators'', ''sa'' ) AND
  ( sysadmin 		<> 0 OR
	securityadmin 	<> 0 OR
	serveradmin 	<> 0 OR
	setupadmin 		<> 0 OR
	processadmin 	<> 0 OR
	diskadmin 		<> 0 OR
	dbcreator 		<> 0 )'

--PRINT @SqlCmd
EXEC( @SqlCmd )
END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE dbo.usp_SetDaysForSchedule
AS
BEGIN
SET NOCOUNT ON
PRINT '    usp_SetDaysForSchedule'

DECLARE	
	@Id			int,
	@Day		varchar(150),
	@Freq		int

DECLARE CURS CURSOR FOR
	SELECT Id, [When] 
	FROM dbo.Schedules
	WHERE Freq = 'Weekly' and ISNUMERIC( [When] ) = 1

OPEN CURS
FETCH NEXT FROM CURS INTO @Id, @Day
WHILE @@FETCH_STATUS = 0
	begin
	SET @Freq = cast( @Day as int )
	SET @Day = ''

	IF ( @Freq & 1 = 1 )	SET @Day = @Day + 'Sun '
	IF ( @Freq & 2 = 2 )   	SET @Day = @Day + 'Mon '
	IF ( @Freq & 4 = 4 )   	SET @Day = @Day + 'Tue '
	IF ( @Freq & 8 = 8 )   	SET @Day = @Day + 'Wed '
	IF ( @Freq & 16 = 16 ) 	SET	@Day = @Day + 'Thu '
	IF ( @Freq & 32 = 32 ) 	SET	@Day = @Day + 'Fri '
	IF ( @Freq & 64 = 64 ) 	SET @Day = @Day + 'Sat'

	UPDATE dbo.Schedules SET [When] = @Day WHERE Id = @Id
	FETCH NEXT FROM CURS INTO @Id, @Day
	end
CLOSE CURS
DEALLOCATE CURS
END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE dbo.usp_Showcontig_All
		@ServerName	varchar(50 ), 
		@Threshold int = 10
AS
SET NOCOUNT ON

DECLARE
	@SqlStmt	varchar( 3000 )

IF @ServerName IS NULL RETURN(-1)

SET @SqlStmt = '
	INSERT INTO dbo.Showcontig_All' + 
	'( ServerName,DBName,TableName,TableId,IndexName,
		IndexId,Lvl,Pages,Rows,MinRecSize,MaxRecSize,
		AvgRecSize,ForRecCount,Extents,ExtentSwitches,AvgFreeBytes,
		AvgPageDensity,ScanDensity,BestCount,ActualCount,LogicalFrag,
		ExtentFrag,	Owner, Add_Datetime	) ' + 
	'SELECT ''' + @ServerName + ''',' +
		'DBName,TableName,TableId,IndexName,
		IndexId,Lvl,CountPages,CountRows,MinRecSize,MaxRecSize,
		AvgRecSize,ForRecCount,Extents,ExtentSwitches,AvgFreeBytes,
		AvgPageDensity,ScanDensity,BestCount,ActualCount,LogicalFrag,
	ExtentFrag,	Owner, Add_Date ' +
	'FROM [' + @ServerName + '].DBA.dbo.Showcontig ' +
	'WHERE DBName + TableName + IndexName + CAST( Add_Date as varchar ) NOT in
	( SELECT DBName + TableName + IndexName + CAST( Add_Datetime as varchar )
      FROM DBA.dbo.Showcontig_All 
	  WHERE ServerName = ''' + @ServerName + ''' )'
--PRINT @SqlStmt
EXEC( @SqlStmt )

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE dbo.usp_SynchronizeUsers
AS
BEGIN
SET NOCOUNT ON

DECLARE name_curs CURSOR FOR
	SELECT name FROM dbo.sysusers 
	WHERE 
		name not like 'db_%' and 
		name not in ( 'guest', 'public' ) and
		name not like 'marmaxx%'

DECLARE
	@name varchar(60),
	@SQL  varchar(1000)

OPEN name_curs
FETCH NEXT FROM name_curs INTO @name
WHILE @@FETCH_STATUS = 0
	begin
	PRINT @name
	SET @SQL = 'sp_change_users_login ''Update_One'', ''' + @name + ''', ''' + @name + ''''
	--print @SQL
	EXEC( @SQL )
	PRINT ' '
	FETCH NEXT FROM name_curs INTO @name
	end
CLOSE name_curs
DEALLOCATE name_curs
END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE dbo.usp_Track_WaitStats
	( @Num_Samples 	int = 10,
	  @DelayNum	 	int = 1,
	  @DelayType	nvarchar(10) = 'minutes'
	)
AS
/*********************************************************

	@Num_Samples:   The number of times to capture
					waitstats; default 10 times.
	@DelayNum:		The delay interval; can be in
					minutes or seconds; default is 
					1 minute.
	@DelayType:		The time specified. Values are 
					"minutes" or "seconds."

************************************************************/

SET NOCOUNT ON
IF OBJECT_ID( 'dbo.WaitStats' ) IS NULL
	CREATE TABLE dbo.WaitStats
	(	[Wait Type]			varchar(80),
		Requests			numeric(20,1),
		[Wait Time]			numeric(20,1),
		[Signal Wait Time]	numeric(20,1),
		Now					datetime default GETDATE()
	)
ELSE
	TRUNCATE TABLE dbo.WaitStats

DBCC SQLPERF( WAITSTATS, CLEAR )  -- clear out waitstats

DECLARE
	@i			int,
	@Delay		varchar(8),
	@Dt			varchar(3),
	@Now		datetime,	
	@TotalWait	numeric(20,1),
	@EndTime	datetime,
	@BeginTime	datetime,
	@Hr			int,
	@Min		int,
	@Sec		int

SET @i = 1
SET	@Dt	=	
	CASE LOWER( @DelayType )
		WHEN 'minutes' 	THEN 'm'
		WHEN 'minute'	THEN 'm'
		WHEN 'min'		THEN 'm'
		WHEN 'mm'		THEN 'm'
		WHEN 'mi'		THEN 'm'
		WHEN 'm'		THEN 'm'
		WHEN 'seconds'	THEN 's'
		WHEN 'second'	THEN 's'
		WHEN 'sec'		THEN 's'
		WHEN 'ss'		THEN 's'
		WHEN 's'		THEN 's'
		ELSE @DelayType
	END
IF @Dt NOT IN ( 's', 'm' )
	begin
	PRINT 'Please supply delay type, e.g. seconds or minutes'
	RETURN
	end

IF @Dt = 's'
	begin
	SET @Sec	= @DelayNum % 60
	SET @Min	= CAST(( @DelayNum / 60 ) as int )
	SET @Hr		= CAST(( @Min / 60 ) as int )
	SET @Min	= @Min % 60
	end

IF @Dt = 'm'
	begin
	SET @Sec	= 0
	SET @Min	= @DelayNum % 60
	SET @Hr		= CAST(( @DelayNum / 60 ) as int )
	end

SET @Delay =	RIGHT( '0' + CONVERT( varchar(2), @Hr ), 2 ) +
			 	':' +
				RIGHT( '0' + CONVERT( varchar(2), @Min ), 2 ) +
				':' +
			 	RIGHT( '0' + CONVERT( varchar(2), @Sec ), 2 )

IF @Hr > 23 OR @Min > 59 OR @Sec > 59
	begin
	SELECT 'hh:mm:ss delay time cannot > 23:59:59'
	SELECT 'Delay interval and type:  ' + 
			CONVERT( varchar(10), @DelayNum ) +
			',' + @DelayType + ' converts to ' + @Delay
	RETURN
	end

WHILE ( @i <= @Num_Samples )
	begin
	INSERT INTO WaitStats
		( [Wait Type], Requests, [Wait Time], [Signal Wait Time] )
	EXEC ( 'DBCC SQLPERF( WAITSTATS )' )
	SET @i = @i + 1
	WAITFOR DELAY @Delay
	end
--  Create report
EXEC dbo.usp_Get_WaitStats

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE dbo.usp_Users
	@Server varchar(60) = @@ServerName
AS
BEGIN
SET NOCOUNT ON
PRINT '    usp_Users'
PRINT '    ' + @Server

DECLARE 
		@DBName		varchar( 50 ),
		@DBType		char(1),
		@DBId		int,
		@SQLString1 varchar( 3000 ),
		@SQLString2 varchar( 3000 ),
		@Once		bit

DECLARE DBcurs CURSOR FOR
	SELECT DBName, DBId, DBType
	FROM dbo.Databases
	WHERE ServerName = @Server and ActiveFlag = 1 and
		DBName not in ( 'tempdb', 'Northwind', 'pubs' ) and
		( Status is NULL or Status = 'ONLINE' )
	ORDER BY DBName

SET @Once = 0

OPEN DBcurs
FETCH NEXT FROM DBcurs INTO @DBName, @DBId, @DBType
WHILE @@FETCH_STATUS = 0
	begin
	PRINT @DBName
	UPDATE dbo.Databases SET ActiveFlag = 0 WHERE DBId = @DBId
	SET @SQLString1 = 'INSERT INTO dbo.Users( ServerName, RoleName, Login, Alias, NTGroup, DefaultDB, UserName, DBId, CreateDate ) '

	-- Note:  The 2KPERDAT server has a case-sensitive database ( SC_Prod ), so the table
	--        and column names in the following query must be all lowercase!!!
	SET @SQLString2 = 
	'SELECT ''' + @Server + ''', 
	 left( ISNULL( r.name, '''' ), 50 ), 
	 ISNULL( l.name, '''' ), 
	 CASE WHEN u.isaliased = 1 THEN ''Y'' ELSE ''N'' END, 
	 CASE WHEN u.isntgroup = 1 THEN ''Y'' ELSE ''N'' END,
	  l.dbname, 
	 left( u.name, 50 ), ' + 
	cast( @DBId as varchar ) + 
	 ', u.CreateDate
	  FROM [' + @Server + '].master.dbo.syslogins l 
	 RIGHT JOIN [' + @Server + '].[' + @DBName + '].dbo.sysusers u ON u.sid = l.sid 
	 LEFT JOIN [' + @Server + '].[' + @DBName + '].dbo.sysmembers m ON u.uid = m.memberuid 
	 LEFT JOIN [' + @Server + '].[' + @DBName + '].dbo.sysusers r ON  r.uid = m.groupuid 
	 WHERE 
		ISNULL( l.name, '''' ) NOT IN( ''sa'', ''BUILTIN\Administrators'') and
	 	ISNULL( u.name, '''') NOT IN ( ''guest'', ''INFORMATION_SCHEMA'', ''SYSTEM_FUNCTION_SCHEMA'', ''public'' ) AND
		( ISNULL( l.name, '''' ) <> ''''  or ISNULL( r.name, '''' ) <> '''' )'
	
	--PRINT @SQLString1 + @SQLString2
	EXEC( @SQLString1 + @SQLString2 )

	IF EXISTS( SELECT * FROM dbo.AdjustedUsers WHERE ServerName = @Server and DBName = @DBName )
		begin
		DECLARE 
			@Table		varchar(60), 
			@Filter 	varchar(300),
			@Owner		varchar(60),
			@CreateDate	varchar(60),
			@LastLogin	varchar(60),
			@Login		varchar(60),
			@User		varchar(150), 
			@DefaultDB  varchar(60)

		SELECT 
			@Table = a.TableName, 
			@Filter = a.Filter, 
			@Owner = a.Owner,
			@CreateDate = a.CreateDateColumn,
			@LastLogin = a.LastLoginColumn,
			@Login = a.Login,
			@User = a.UserColumn,
			@DefaultDB = u.DefaultDB
		FROM DBA.dbo.AdjustedUsers a JOIN dbo.Users u ON a.Login = u.Login
		WHERE a.DBName = @DBName
			
		SET @SQLString1 = 'INSERT INTO dbo.Users( ServerName, Login, UserName, DBId, DefaultDB, CreateDate, LastLogin ) '

		IF  @DBName = 'PerformanceAppraisal' AND @Server = '2KSQLDEV1'
			SET @SQLString1 = @SQLString1 + 'SELECT ''' + @Server + ''', ''PAS2KSQLDEV1ID'',' + 
				@User + ',''' + cast( @DBId as varchar ) + ''', ''' + @DefaultDB + ''''
		ELSE
			SET @SQLString1 = @SQLString1 + 'SELECT ''' + @Server + ''', ''' + @Login + ''', ' + 
				@User + ',''' + cast( @DBId as varchar ) + ''', ''' + @DefaultDB + ''''
		
		IF ISNULL( @CreateDate, '' ) = ''
			SET @SQLString1 = @SQLString1 + ', NULL'
		ELSE
			SET @SQLString1 = @SQLString1 + ', ' + @CreateDate 

		IF ISNULL( @LastLogin, '' ) = ''
			SET @SQLString1 = @SQLString1 + ', NULL '
		ELSE
			SET @SQLString1 = @SQLString1 + ', ' + @LastLogin 

		
		SET @SQLString1 = @SQLString1 +
			' FROM [' + @Server + '].' + @DBName + '.' + @Owner + '.' + @Table

		IF @Filter IS NOT NULL
			SET @SQLString1 = @SQLString1 +  ' WHERE ' + @Filter

		--PRINT @SQLString1
       	EXEC( @SQLString1 )
		end

	UPDATE dbo.Databases SET ActiveFlag = 1 WHERE DBId = @DBId
	FETCH NEXT FROM DBcurs INTO @DBName, @DBId, @DBType
	end
CLOSE DBcurs
DEALLOCATE DBcurs

SET @SQLString1 =
'INSERT INTO dbo.Users( ServerName, Login, NTGroup, DefaultDB )
SELECT ''' + @Server + ''', l.name, 
CASE WHEN l.IsNtGroup = 1 THEN ''Y'' ELSE ''N'' END,
dbname
FROM [' + @Server + '].master.dbo.syslogins l
WHERE l.name IS NOT NULL and 
	--l.name not in ( ''sa'', ''BUILTIN\Administrators'' ) and 
	l.name NOT IN 
( SELECT Login FROM dbo.Users WHERE ServerName = ''' + @Server + ''' )'

--PRINT @SQLString1
EXEC( @SQLString1 )

SET @SQLString1 = '
INSERT INTO dbo.ServerPermissions
( ServerName,Login,Sys,Security,Server,Setup,Process,[Disk],DBCreator, UserId )
SELECT ''' + @Server + ''' , name, 
	CASE sysadmin 		WHEN 1 THEN ''Y'' ELSE ''N'' END,
	CASE securityadmin 	WHEN 1 THEN ''Y'' ELSE ''N'' END,
	CASE serveradmin 	WHEN 1 THEN ''Y'' ELSE ''N'' END,
	CASE setupadmin 	WHEN 1 THEN ''Y'' ELSE ''N'' END,
	CASE processadmin 	WHEN 1 THEN ''Y'' ELSE ''N'' END,
	CASE diskadmin 		WHEN 1 THEN ''Y'' ELSE ''N'' END,
	CASE dbcreator 		WHEN 1 THEN ''Y'' ELSE ''N'' END,
	u.Id
FROM [' + @Server + '].master.dbo.syslogins l JOIN dbo.Users u 
	ON u.ServerName = ''' + @Server + ''' and isnull( l.name,'''' ) = u.Login
WHERE 
	--name NOT IN( ''BUILTIN\Administrators'', ''sa'' ) AND
  ( sysadmin 		<> 0 OR
	securityadmin 	<> 0 OR
	serveradmin 	<> 0 OR
	setupadmin 		<> 0 OR
	processadmin 	<> 0 OR
	diskadmin 		<> 0 OR
	dbcreator 		<> 0 )'

--PRINT @SQLString1
EXEC( @SQLString1 )

UPDATE dbo.Users SET SvrRights = 'Y'
FROM dbo.ServerPermissions P JOIN dbo.Users u ON p.UserId = u.Id 
END


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE dbo.usp_get_dbstats2ForEachDB 
/***************************************************************

		This procedure records the disk space used by
		databases.

*****************************************************************/
AS
IF OBJECT_ID( 'dbo.tmp_stats' ) IS NULL
	CREATE TABLE dbo.tmp_stats
	(
		TotalExtents	int,
		UsedExtents		int,
		DBName			varchar( 40 ),
		LogSize			real,
		LogSpaceUsed	real
	)
IF OBJECT_ID( 'dbo.tmplg' ) IS NULL
	CREATE TABLE dbo.tmplg
	( 
		DBName       	varchar( 32 ),
		LogSize			real,
		LogSpaceUsed	real,
		Status			int
	)

IF OBJECT_ID( 'dbo.tmp_sfs' ) IS NULL
	CREATE TABLE dbo.tmp_sfs
	(   
		DBName			nvarchar( 128 ),
		FileId	    	int,
		FileGroup		int, 
		TotalExtents	int, 
		UsedExtents		int, 
		Name			varchar( 1024 ), 
		FileName		varchar( 1024 )
	)

TRUNCATE TABLE DBA.dbo.tmplg
TRUNCATE TABLE DBA.dbo.tmp_stats
TRUNCATE TABLE DBA.dbo.tmp_sfs

INSERT INTO DBA.dbo.tmplg EXECUTE ( 'DBCC SQLPERF( logspace )' )

DECLARE	@CMD varchar( 2000 )
SET @CMD = 'USE [?] ' 
SET @CMD = @CMD + 'INSERT INTO DBA.dbo.tmp_sfs( FileId,FileGroup,TotalExtents,UsedExtents,Name,FileName	 ) '
SET @CMD = @CMD + ' EXEC( ''DBCC SHOWFILESTATS'' ) ' 
SET @CMD = @CMD + ' UPDATE DBA.dbo.tmp_sfs SET DBNAME = ''?'' WHERE DBNAME IS NULL '
EXEC sp_MSForEachDB @Command1=@CMD

INSERT INTO DBA.dbo.DBSTATS 
( 	Record_Type, DBName, Data_Size, Data_Used, 	Log_Size, Log_Used, State_Date )
	SELECT 	'1',
			s.DBName,
			SUM( TotalExtents ) * 64 / 1024, 
			SUM( UsedExtents ) * 64 / 1024, 
			CAST( MAX( l.LogSize ) AS varchar ) ,
			CAST( ( MAX(l.LogSize) * MAX(l.LogSpaceUsed) ) / 100.0 AS varchar ),
			GETDATE()
	FROM DBA.dbo.tmp_sfs s 
		JOIN DBA.dbo.tmplg l ON s.DBName = l.DBName
	WHERE s.DBName NOT IN( 'model', 'pubs', 'Northwind', 'tempdb' )
	GROUP BY s.DBName
	
-- SELECT * FROM DBA.dbo.DBSTATS ORDER BY STATE_DATE DESC, DBNAME

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


CREATE PROCEDURE dbo.usp_UserList3 
	@Server varchar(50) = @@ServerName
AS

SET NOCOUNT ON

DECLARE 
		@DBName		varchar( 50 ),
		@SQLString1 varchar( 1000 ),
		@SQLString2 varchar( 3000 )

DECLARE DBcurs CURSOR FOR
	SELECT DBName
	FROM dbo.ALL_DATABASES
	WHERE ServerName = @Server

SET @SQLString1 = 
'INSERT INTO dbo.Users( ServerName, RoleName, DBName, Login, Alias, NTGroup, DefaultDB, UserName ) '

OPEN DBcurs
FETCH NEXT FROM DBcurs INTO @DBName
WHILE @@FETCH_STATUS = 0
	begin
	-- Note:  The 2KPERDAT server has a case-sensitive database ( SC_Prod ), so the table
	--        and column names in the following query must be all lowercase!!!
	SET @SQLString2 = 
	'SELECT ''' + @Server + ''', ISNULL( r.name, '''' ), ''' + @DBName + ''', 
	 l.name, 
	 CASE WHEN u.isaliased = 1 THEN ''Y'' ELSE ''N'' END, 
	 CASE WHEN u.isntgroup = 1 THEN ''Y'' ELSE ''N'' END,
	 l.dbname, u.name
	 FROM [' + @Server + '].master.dbo.syslogins l 
	 JOIN [' + @Server + '].' + @DBName + '.dbo.sysusers u ON u.sid = l.sid 
	 LEFT JOIN [' + @Server + '].' + @DBName + '.dbo.sysmembers m ON u.uid = m.memberuid 
	 LEFT JOIN [' + @Server + '].' + @DBName + '.dbo.sysusers r ON  r.uid = m.groupuid 
	 WHERE u.isapprole = 0 and u.issqlrole = 0 and u.name NOT IN 
	( ''dbo'', ''guest'', ''INFORMATION_SCHEMA'', ''SYSTEM_FUNCTION_SCHEMA'' )'
	
	--PRINT @SQLString1 + @SQLString2
	EXEC( @SQLString1 + @SQLString2 )
	
	FETCH NEXT FROM DBcurs INTO @DBName
	end
CLOSE DBcurs
DEALLOCATE DBcurs

SET @SQLString1 =
'INSERT INTO dbo.Users( ServerName, Login, NTGroup )
SELECT ''' + @Server + ''', name, CASE WHEN IsNtGroup = 1 THEN ''Y'' ELSE ''N'' END
FROM master.dbo.syslogins WHERE name NOT IN 
( SELECT Login FROM dbo.Users WHERE ServerName = ''' + @Server + ''' )'

PRINT @SQLString1
EXEC( @SQLString1 )

SET @SQLString1 = '
INSERT INTO dbo.ServerPermissions
( ServerName,Login,Sys,Security,Server,Setup,Process,[Disk],DBCreator, UserId )
SELECT ''' + @Server + ''' , name, 
	CASE sysadmin 		WHEN 1 THEN ''Y'' ELSE ''N'' END,
	CASE securityadmin 	WHEN 1 THEN ''Y'' ELSE ''N'' END,
	CASE serveradmin 	WHEN 1 THEN ''Y'' ELSE ''N'' END,
	CASE setupadmin 	WHEN 1 THEN ''Y'' ELSE ''N'' END,
	CASE processadmin 	WHEN 1 THEN ''Y'' ELSE ''N'' END,
	CASE diskadmin 		WHEN 1 THEN ''Y'' ELSE ''N'' END,
	CASE dbcreator 		WHEN 1 THEN ''Y'' ELSE ''N'' END,
	u.Id 
FROM [' + @Server + '].master.dbo.syslogins l
JOIN dbo.Users u ON u.ServerName = ''' + @Server + ''' and l.name = u.Login
WHERE 
	name NOT IN( ''BUILTIN\Administrators'', ''sa'' ) AND
  ( sysadmin 		<> 0 OR
	securityadmin 	<> 0 OR
	serveradmin 	<> 0 OR
	setupadmin 		<> 0 OR
	processadmin 	<> 0 OR
	diskadmin 		<> 0 OR
	dbcreator 		<> 0 )'

PRINT @SQLString1
EXEC( @SQLString1 )

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

