USE DBA
GO

/******************************************

		CLEAR TABLES

*******************************************/


IF OBJECT_ID( 'FK_Grants_Databases' ) IS NOT NULL
	ALTER TABLE dbo.Grants
	DROP CONSTRAINT FK_Grants_Databases
GO
IF OBJECT_ID( 'FK_ServerPermissions_Users' ) IS NOT NULL
	ALTER TABLE dbo.ServerPermissions 
	DROP CONSTRAINT FK_ServerPermissions_Users
GO
IF OBJECT_ID( 'FK_Database_Files_Databases' ) IS NOT NULL
	ALTER TABLE dbo.Database_Files 
	DROP CONSTRAINT FK_Database_Files_Databases
GO
IF OBJECT_ID( 'FK_Users_Databases' ) IS NOT NULL
	ALTER TABLE dbo.Users 
	DROP CONSTRAINT FK_Users_Databases
GO
IF OBJECT_ID( 'FK_MaintenancePlans_Databases' ) IS NOT NULL
	ALTER TABLE dbo.MaintenancePlans 
	DROP CONSTRAINT FK_MaintenancePlans_Databases
GO
IF OBJECT_ID( 'FK_All_DBStats_Databases' ) IS NOT NULL
	ALTER TABLE dbo.All_DBStats 
	DROP CONSTRAINT FK_All_DBStats_Databases
GO
IF OBJECT_ID( 'FK_Months_Databases' ) IS NOT NULL
	ALTER TABLE dbo.Months 
	DROP CONSTRAINT FK_Months_Databases
GO
IF OBJECT_ID( 'FK_Stats_Summary_Databases' ) IS NOT NULL
	ALTER TABLE dbo.Stats_Summary 
	DROP CONSTRAINT FK_Stats_Summary_Databases
GO
IF OBJECT_ID( 'FK_User_Locks_User_Activity' ) IS NOT NULL
	ALTER TABLE dbo.User_Locks
	DROP CONSTRAINT FK_User_Locks_User_Activity
GO
IF OBJECT_ID( 'FK_PackageSteps_Packages' ) IS NOT NULL
	ALTER TABLE dbo.PackageSteps
	DROP CONSTRAINT FK_PackageSteps_Packages
GO
TRUNCATE TABLE dbo.Jobs
TRUNCATE TABLE dbo.Showcontig_All
TRUNCATE TABLE dbo.ServerPermissions
TRUNCATE TABLE dbo.Users
TRUNCATE TABLE dbo.BlankLogins
TRUNCATE TABLE dbo.MaintenancePlans
TRUNCATE TABLE dbo.Schedules
TRUNCATE TABLE dbo.PackageSteps
TRUNCATE TABLE dbo.Packages
TRUNCATE TABLE dbo.Database_Files
TRUNCATE TABLE dbo.Databases
TRUNCATE TABLE dbo.All_DBStats
TRUNCATE TABLE dbo.Stats_Summary
TRUNCATE TABLE dbo.Months
TRUNCATE TABLE dbo.RunningJobs
TRUNCATE TABLE dbo.Grants
GO
ALTER TABLE dbo.ServerPermissions 
	ADD CONSTRAINT FK_ServerPermissions_Users
	FOREIGN KEY( UserId ) REFERENCES dbo.Users
	ON UPDATE CASCADE ON DELETE CASCADE

ALTER TABLE dbo.Database_Files 
	ADD CONSTRAINT FK_Database_Files_Databases
	FOREIGN KEY( DBId ) REFERENCES dbo.Databases
	ON UPDATE CASCADE ON DELETE CASCADE

ALTER TABLE dbo.Users 
	ADD CONSTRAINT FK_Users_Databases
	FOREIGN KEY( DBId ) REFERENCES dbo.Databases
	ON UPDATE CASCADE ON DELETE CASCADE

ALTER TABLE dbo.MaintenancePlans
	ADD CONSTRAINT FK_MaintenancePlans_Databases
	FOREIGN KEY( DBId ) REFERENCES dbo.Databases
	ON UPDATE CASCADE ON DELETE CASCADE

ALTER TABLE dbo.All_DBStats
	ADD CONSTRAINT FK_All_DBStats_Databases
	FOREIGN KEY( DBId ) REFERENCES dbo.Databases
	ON UPDATE CASCADE ON DELETE CASCADE

ALTER TABLE dbo.Months
	ADD CONSTRAINT FK_Months_Databases
	FOREIGN KEY( DBId ) REFERENCES dbo.Databases
	ON UPDATE CASCADE ON DELETE CASCADE

ALTER TABLE dbo.Stats_Summary
	ADD CONSTRAINT FK_Stats_Summary_Databases
	FOREIGN KEY( DBId ) REFERENCES dbo.Databases
	ON UPDATE CASCADE ON DELETE CASCADE

ALTER TABLE dbo.User_Locks
	ADD CONSTRAINT FK_User_Locks_User_Activity
	FOREIGN KEY( ActivityId ) REFERENCES dbo.User_Activity
	ON UPDATE CASCADE ON DELETE CASCADE

ALTER TABLE dbo.PackageSteps
	ADD CONSTRAINT FK_PackageSteps_Packages
	FOREIGN KEY( PkgId) REFERENCES dbo.Packages
	ON UPDATE CASCADE ON DELETE CASCADE

ALTER TABLE dbo.Grants
	ADD CONSTRAINT FK_Grants_Databases
	FOREIGN KEY(DBid) REFERENCES dbo.Databases
	ON UPDATE CASCADE ON DELETE CASCADE

GO


UPDATE dbo.Servers SET Started = 0, Finished = 0, Step = NULL


/*******************************************************

			COLLECT DATA FROM SERVERS

********************************************************/
SELECT ServerName, SQLVersion, ServerType 
	FROM DBA.dbo.Servers 
	WHERE ServerName NOT LIKE '*%' and ActiveFlag = 1
		and ServerName not in
	(  SELECT DISTINCT Servername FROM dbo.Databases )
	ORDER BY ServerType desc, ServerName asc
go

DECLARE
	SERVER_CUR CURSOR FOR
	SELECT ServerName, SQLVersion, ServerType 
	FROM DBA.dbo.Servers 
	WHERE ServerName NOT LIKE '*%' and ActiveFlag = 1
		and ServerName not in
	(  SELECT DISTINCT Servername FROM dbo.Databases )
	ORDER BY ServerType desc, ServerName asc

DECLARE
	@SqlStmt	varchar( 1000 ),
	@Server		varchar( 60 ),
	@Version 	int,
	@Type    	char(1)


OPEN SERVER_CUR
FETCH NEXT FROM SERVER_CUR INTO @Server, @Version, @Type
WHILE @@FETCH_STATUS = 0
	BEGIN
	PRINT @Server
	UPDATE dbo.Servers SET Started = 1 WHERE ServerName = @Server

	UPDATE dbo.Servers SET Step = 'usp_GetDatabases' WHERE ServerName = @Server
	SET @SqlStmt = 'EXEC dba.dbo.usp_GetDatabases ''' + @Server + ''', ' + cast( @Version as varchar )
	EXEC( @SqlStmt )

	UPDATE dbo.Servers SET Step = 'usp_BlankLogins' WHERE ServerName = @Server
	SET @SqlStmt = 'EXEC dba.dbo.usp_BlankLogins ''' + @Server + ''''
	EXEC( @SqlStmt )

	UPDATE dbo.Servers SET Step = 'usp_ServerPermissions' WHERE ServerName = @Server
	SET @SqlStmt = 'EXEC dba.dbo.usp_ServerPermissions ''' + @Server + ''''
	EXEC( @SqlStmt )

	UPDATE dbo.Servers SET Step = 'usp_SaveServerFreespace' WHERE ServerName = @Server
	SET @SqlStmt = 'EXEC dba.dbo.usp_SaveServerFreespace ''' + @Server + ''''
	EXEC( @SqlStmt )

	UPDATE dbo.Servers SET Step = 'usp_GetJobs' WHERE ServerName = @Server
	SET @SqlStmt = 'EXEC dba.dbo.usp_GetJobs ''' + @Server + ''', ' + cast( @Version as varchar ) + '  '
	EXEC( @SqlStmt )

	UPDATE dbo.Servers SET Step = 'usp_MaintenancePlans' WHERE ServerName = @Server
	SET @SqlStmt = 'EXEC dba.dbo.usp_MaintenancePlans ''' + @Server + ''''
	EXEC( @SqlStmt )

	UPDATE dbo.Servers SET Step = 'usp_Schedules' WHERE ServerName = @Server
	SET @SqlStmt = 'EXEC dba.dbo.usp_Schedules ''' + @Server + ''', ' + cast( @Version as varchar ) + '  '
	EXEC( @SqlStmt )

	UPDATE dbo.Servers SET Step = 'usp_GetRunningJobs' WHERE ServerName = @Server
	SET @SqlStmt = 'EXEC dba.dbo.usp_GetRunningJobs ''' + @Server + ''''
	EXEC( @SqlStmt )

	UPDATE dbo.Servers SET Step = 'usp_GetDatabaseFiles' WHERE ServerName = @Server
	SET @SqlStmt = 'EXEC dba.dbo.usp_GetDatabaseFiles ''' + @Server + ''''
	EXEC( @SqlStmt )

	UPDATE dbo.Servers SET Step = 'usp_GetDatabaseSizes' WHERE ServerName = @Server
	SET @SqlStmt = 'EXEC dba.dbo.usp_GetDatabaseSizes ''' + @Server + ''''
	EXEC( @SqlStmt )


	UPDATE dbo.Servers SET Step = 'usp_Packages' WHERE ServerName = @Server
	SET @SqlStmt = 'EXEC dba.dbo.usp_Packages ''' + @Server + ''', ' + cast( @Version as varchar ) + '  '
	EXEC( @SqlStmt )

	FETCH NEXT FROM SERVER_CUR INTO @Server, @Version, @Type
	END
CLOSE SERVER_CUR
DEALLOCATE SERVER_CUR
GO

UPDATE DBA.dbo.MaintenancePlans
SET EndDate =
CASE len(Duration)
	WHEN 1 THEN dateadd(ss, cast(Duration as int), [Date] )	
	WHEN 2 THEN dateadd(ss, cast(Duration as int), [Date] )
	WHEN 3 THEN dateadd(ss, 
		(cast(left( Duration, 1) as int) * 60) 
		+ cast(right(Duration, 2 ) as int), [Date] ) 
	WHEN 4 THEN dateadd(ss, 
		(cast(left(Duration, 2) as int) * 60 )
		+ cast(right(Duration, 2 ) as int), [Date] )	
	WHEN 5 THEN dateadd(ss, 
		(cast(left(Duration, 1) as int) * 3600)
		+ (cast(left(Duration, 2) as int) * 60 )
		+ cast(right(Duration, 2 ) as int), [Date] )
	 WHEN 6 THEN dateadd(ss, (cast(left(Duration, 2) as int) * 3600)
		+ (cast(left(Duration, 2) as int) * 60 )
		+ cast(right(Duration, 2 ) as int), [Date] )
END
WHERE 	
	EndDate IS NULL and isnumeric( isnull( Duration, '' ) ) = 1
GO

/**********************************************

			EDIT FREESPACE

***********************************************/
PRINT 'EDIT FREESPACE'
GO
-- Add commas
UPDATE DBA.dbo.All_Free_Space
SET [Space in MB] = dbo.udf_InsertCommas( Freespace )
WHERE CHARINDEX( ',', [Space in MB] ) = 0
go
-- Right justify
UPDATE DBA.dbo.All_Free_Space
SET [Space in MB] = SPACE( 15 - LEN( [Space in MB] ) ) + [Space in MB]
go
/**********************************************

			PURGE FREESPACE

***********************************************/
PRINT 'PURGE FREESPACE'
GO
DELETE FROM dbo.All_Free_Space
WHERE DATEDIFF( d, Date_Collected, getdate()  ) > 3
go

/****************************************************

		APPLICATIONS SUPPORTED

*****************************************************/

PRINT 'APPLICATIONS SUPPORTED'
GO

-- Add any new production databases
INSERT INTO dbo.Applications_Supported( Server, DB )
    SELECT DISTINCT d.Servername, d.DBName
    FROM dbo.Databases d 
	JOIN dbo.Servers s on d.Servername = s.Servername
	JOIN dbo.Applications_Supported a on a.Server = d.Servername
    WHERE 	
	s.ActiveFlag = 1 and
	 --d.DBType = 'P' and 
	d.DBName not in 
	( 'master', 'model', 'msdb', 'tempdb', 'pubs', 
		'Northwind', 'DBA', 'LitespeedLocal' ) and
	d.Servername + d.DBName not in
	( SELECT Server + DB FROM dbo.Applications_Supported )
go


UPDATE dbo.Applications_Supported
SET Application = b.Application
FROM dbo.Applications_Supported a 
	join ( SELECT DB, Application
			FROM dbo.Applications_Supported 
			WHERE isnull( Application, '' ) <> '' )
		 as b on b.DB = a.DB 
WHERE isnull( a.Application, '' ) = '' 
GO

UPDATE dbo.Applications_Supported
SET Code = b.Code
FROM dbo.Applications_Supported a 
	join ( SELECT DB, Code
			FROM dbo.Applications_Supported  
			WHERE isnull( Code, '' ) <> '' )
		 as b on b.DB = a.DB 
WHERE isnull( a.Code, '' ) = '' 
GO

UPDATE dbo.Applications_Supported
SET Manager_Contact = b.Manager_Contact
FROM dbo.Applications_Supported a 
	join ( SELECT DB, Server, Manager_Contact
			FROM dbo.Applications_Supported  
			WHERE isnull( Manager_Contact, '' ) <> '' )
		 as b on b.DB = a.DB 
WHERE isnull( a.Manager_Contact, '' ) = '' 
GO

UPDATE dbo.Applications_Supported
SET Department = b.Department
FROM dbo.Applications_Supported a 
	join ( SELECT DB, Server, Department
			FROM dbo.Applications_Supported  
			WHERE isnull( Department, '' ) <> '' )
		 as b on b.DB = a.DB 
WHERE isnull( a.Department, '' ) = '' 
GO


-- Delete any databases not longer on a production server
DELETE FROM dbo.Applications_Supported
FROM dbo.Databases d JOIN dbo.Applications_Supported a 
	ON d.ServerName = a.Server
WHERE DB NOT IN ( SELECT DBName FROM dbo.Databases )
go

-- Update the backup plan names
UPDATE dbo.Applications_Supported
SET Bkp_PlanName = PlanName,
	Bkp_Plan = CASE WHEN ISNULL( Bkp_Plan, '' ) = '' THEN 'Y' ELSE Bkp_Plan END
FROM dbo.Applications_Supported a 
	JOIN dbo.Databases d ON d.ServerName = a.server and DB = d.DBName
	JOIN dbo.MaintenancePlans m ON m.DBId = d.DBId
WHERE m.activity like '%backup database%' --and isnull( Bkp_PlanName, '' ) = ''
go

-- Update the original DB sizes
UPDATE dbo.Applications_Supported
SET OrigDBSize = Data_Used,
	OrigDBDate = Sample_Date
FROM All_DBStats a 
	join Databases d on a.DBId = d.DBId
	join Applications_Supported s 
		on d.ServerName = s.Server and d.DBName = s.DB
WHERE ISNULL(OrigDBSize, 0 ) = 0 and Sample_Date in 
	( SELECT min( Sample_Date ) FROM All_DBStats WHERE DBId = d.DBId )
go

-- Update the current DB Sizes
UPDATE dbo.Applications_Supported
SET CurrentDBSize = Data_Used
FROM All_DBStats a 
	join Databases d on a.DBId = d.DBId
	join Applications_Supported s 
		on d.ServerName = s.Server and d.DBName = s.DB
WHERE Sample_Date in 
	( SELECT MAX( Sample_Date ) FROM All_DBStats WHERE DBId = d.DBId )
go

-- Update the growth rates
UPDATE dbo.Applications_Supported
SET GrowthRate = PctPerMo
FROM Stats_Summary a 
	join Databases d on a.DBId = d.DBId
	join Applications_Supported s 
		on d.ServerName = s.Server and d.DBName = s.DB
go

-- Update the number of logins
UPDATE dbo.Applications_Supported
SET NumUsers = UserCount
FROM dbo.Applications_Supported a
	join
(	SELECT d.ServerName, d.DBName, count(*) as UserCount
	FROM dbo.Databases d 
		join (	SELECT distinct DBId, Login
           		FROM dbo.Users u ) as uu on d.DBId = uu.DBId
	GROUP BY d.ServerName, d.DBName 
) as uu on uu.ServerName = a.Server and uu.DBName = a.DB
go

-- Update the appp user counts
exec dbo.usp_AdjustedUsers
go

UPDATE dbo.Applications_Supported SET DBDrives = NULL
GO
DECLARE DB_CUR CURSOR FOR 
	SELECT DISTINCT ServerName, DBName, LEFT( PhysicalName, 1 )
	FROM dbo.Database_Files f 
		JOIN dbo.Databases d on f.DBId = d.DBId
		JOIN dbo.Applications_Supported a 
			ON a.Server = d.ServerName and a.DB = d.DBName
	ORDER BY ServerName, DBName

DECLARE
	@Server		varchar(60),
	@DB			varchar(60),
	@Drive      varchar(20)

OPEN DB_CUR
FETCH NEXT FROM DB_CUR INTO @Server, @DB, @Drive
WHILE @@FETCH_STATUS = 0
	begin	
	PRINT 'SERVER:  ' + @Server + '   DB:  ' + @DB + '   Drive:  ' + @Drive
	UPDATE dbo.Applications_Supported
	SET DBDrives = CASE WHEN ISNULL( DBDrives, '' ) = '' 
						THEN @Drive
						ELSE DBDrives + ',' + @Drive
				   END
	WHERE Server = @Server and DB = @DB
	FETCH NEXT FROM DB_CUR INTO @Server, @DB, @Drive
	end
CLOSE DB_CUR
DEALLOCATE DB_CUR
go




/******************************************************

			Capacity Planning

*******************************************************/
PRINT 'CAPACITY PLANNING'
GO

IF OBJECT_ID( 'FK_Months_Databases' ) IS NOT NULL
	ALTER TABLE dbo.Months 
	DROP CONSTRAINT FK_Months_Databases
GO
IF OBJECT_ID( 'FK_Stats_Summary_Databases' ) IS NOT NULL
	ALTER TABLE dbo.Stats_Summary 
	DROP CONSTRAINT FK_Stats_Summary_Databases
GO
TRUNCATE TABLE dbo.Stats_Summary
GO
TRUNCATE TABLE dbo.Months
GO
ALTER TABLE dbo.Months
	ADD CONSTRAINT FK_Months_Databases
	FOREIGN KEY( DBId ) REFERENCES dbo.Databases
	ON UPDATE CASCADE ON DELETE CASCADE
GO
ALTER TABLE dbo.Stats_Summary
	ADD CONSTRAINT FK_Stats_Summary_Databases
	FOREIGN KEY( DBId ) REFERENCES dbo.Databases
	ON UPDATE CASCADE ON DELETE CASCADE
GO


DELETE FROM dbo.ALL_DBSTATS 
WHERE ISNULL( Data_Used, 0 ) <= 1.00 and DBId in
	( SELECT distinct DBId FROM dbo.All_DBstats 
                WHERE ISNULL( Data_Used, 0 ) > 1.00 )
GO
UPDATE dbo.ALL_DBSTATS 
	SET Log_Size  = ISNULL( Log_Size, 1 )  
GO
UPDATE dbo.ALL_DBSTATS 
	SET Log_Used  = ISNULL( Log_Used, 0 )
GO
UPDATE dbo.All_DBSTATS 
SET 
	TotalSize  	= Data_Size + Log_Size,
    	TotalUsed  	= Data_Used + Log_Used,
	Percent_Data 	=  
		CASE WHEN Data_Size = 0 THEN 0
		ELSE ( CEILING( Data_Used ) / CEILING( Data_Size ) ) * 100 END
GO
UPDATE dbo.All_DBSTATS
SET Percent_Log  	= 
	CASE 
	WHEN Log_Used = 0 THEN 0
	WHEN Log_Size = 0 THEN 0
	ELSE ( CEILING( Log_Used ) / CEILING( Log_Size )) * 100
	END
WHERE Percent_Log IS NULL

GO

INSERT INTO dbo.Stats_Summary
( 	DBId,
	StartDate, 
	EndDate, 
	Months, 
	AvgLogSize, 
	MaxUsed, 
	MinUsed, 
  	SizeDiff, 
	PctIncr
)
SELECT 
	s.DBId,
	CONVERT( varchar, MIN( Sample_Date ), 101 ) AS StartDate,
	CONVERT( varchar, MAX( Sample_Date ), 101 ) AS EndDate,
	DATEDIFF( m, MIN( Sample_Date ), MAX( Sample_Date ) ) AS Months,
	CEILING( AVG( Log_Used ) )  AS AvgLogSize,
	MAX( Data_Used ) 	AS MaxDataUsed,
	MIN( Data_Used ) 	AS MinDataUsed, 
	MAX( Data_Used ) - MIN( Data_Used ) AS DiffDataUsed, 
	ROUND( ( ( ROUND( ( ( MAX( Data_Used ) - MIN( Data_Used ) ) / 
		MIN( Data_Used ) ), 2 )  ) * 100 ), 2 ) AS IncrAmt
FROM 
	dbo.All_DBStats s JOIN 
	dbo.Databases d ON s.DBId = d.DBId
WHERE 
	DBType = 'P' 
	AND Data_Used <> 0 
	AND d.ActiveFlag = 1 
	AND d.DBId not in
	    ( SELECT distinct DBId 
			FROM dbo.Stats_Summary )
	-- throw out the first week's data to allow for ramp-up
	AND Sample_Date not in
	( SELECT MIN( Sample_Date ) FROM dbo.All_DBStats 
		WHERE DBId = s.DBId )
GROUP BY s.DBId
GO
UPDATE dbo.Stats_Summary
SET SizeIn1 = MaxUsed,
	SizeIn2 = MaxUsed,
	SizeIn3 = MaxUsed,
	SizeIn4 = MaxUsed,
	SizeIn5 = MaxUsed,
	SizeIn6 = MaxUsed,
	SizeIn7 = MaxUsed,
	SizeIn8 = MaxUsed,
	SizeIn9 = MaxUsed,
	SizeIn10 = MaxUsed,
	SizeIn11 = MaxUsed,
	SizeIn12 = MaxUsed
WHERE PctPerMo = 0
go

INSERT INTO dbo.Months
( DBId, Sample_Year, Sample_Month, DataUsed )
SELECT 
	s.DBId,
	DATEPART( year, Sample_Date ), 
	DATEPART( month, Sample_Date ), 
	MAX( CEILING( Data_Used ) ) 
FROM dbo.All_DBStats a 
	JOIN dbo.Stats_Summary s ON a.DBId = s.DBId 
	JOIN dbo.Databases d On a.DBId = d.DBId
WHERE d.DBId not in ( SELECT distinct DBId FROM dbo.Months )
GROUP BY 
	s.DBId,
	DATEPART( year, Sample_Date ), 
	DATEPART( month, Sample_Date )
ORDER BY 
	s.DBId,
	DATEPART( year, Sample_Date ), 
	DATEPART( month, Sample_Date )

-- Calculate difference between given month and previous month
UPDATE dbo.Months
SET Diff = DataUsed - 
	( SELECT DataUsed FROM dbo.Months 
	  WHERE MonthId = m.MonthId - 1 AND DBId = m.DBId )
FROM dbo.Months m JOIN dbo.Databases d ON m.DBId = d.DBId
WHERE MonthId <> 
	( SELECT MIN( MonthId ) FROM dbo.Months
	   WHERE DBId = m.DBId )

-- Calculate percent increase per month
UPDATE dbo.Months
SET PctIncr = 
	ROUND( ( ISNULL( Diff, 0 ) / 
		( SELECT DataUsed  
	  	  FROM dbo.Months
		  WHERE MonthId = m.MonthId - 1 ) ), 2 ) * 100
FROM dbo.Months m
WHERE  ( SELECT DataUsed FROM dbo.Months
	    WHERE MonthId = m.MonthId - 1 ) > 0

UPDATE dbo.Months SET PctIncr = 0 WHERE MonthId = 1

UPDATE dbo.Stats_Summary
SET PctPerMo = 
	CASE 
	WHEN ISNULL( PctIncr, 0 ) < 1 THEN 0 
	ELSE ( SELECT ROUND( AVG( ISNULL( PctIncr, 0 ) ), 2 ) 
	       FROM dbo.Months
	       WHERE DBId = s.DBId   )
	END
FROM dbo.Stats_Summary s
go


/*************************************************************

 Calculate the projected sizes for each month using
 average pct increase per month

*************************************************************/
-- Calculate the projected sizes for each month using
-- average pct increase per month

UPDATE dbo.Stats_Summary 
SET SizeIn1  = 
	CASE WHEN PctIncr < 1 THEN MaxUsed
	WHEN LEN(MaxUsed) >= 30 THEN 0
	ELSE MaxUsed  + ( MaxUsed * ( PctPerMo/100 ) ) 
	END 

UPDATE dbo.Stats_Summary 
SET SizeIn2  = 
	CASE WHEN PctIncr < 1 THEN MaxUsed
	WHEN LEN(SizeIn1) >= 30 THEN 0
	ELSE SizeIn1  + ( SizeIn1 * ( PctPerMo/100 ) )  
	END

UPDATE dbo.Stats_Summary 
SET SizeIn3  = 
	CASE WHEN PctIncr < 1 THEN MaxUsed
	WHEN LEN(SizeIn2) >= 30 THEN 0
	ELSE SizeIn2  + ( SizeIn2 * ( PctPerMo/100 ) )  
	END

UPDATE dbo.Stats_Summary 
SET SizeIn4  = 
	CASE WHEN PctIncr < 1 THEN MaxUsed
	WHEN LEN(SizeIn3) >= 30 THEN 0
	ELSE SizeIn3  + ( SizeIn3 * ( PctPerMo/100 ) )  
	END

UPDATE dbo.Stats_Summary 
SET SizeIn5  = 
	CASE WHEN PctIncr < 1 THEN MaxUsed
	WHEN LEN(SizeIn4) >= 30 THEN 0
	ELSE SizeIn4  + ( SizeIn4 * ( PctPerMo/100 ) )  
	END

UPDATE dbo.Stats_Summary 
SET SizeIn6  = 
	CASE WHEN PctIncr < 1 THEN MaxUsed
	WHEN LEN(SizeIn6) >= 30 THEN 0
	ELSE SizeIn5  + ( SizeIn5 * ( PctPerMo/100 ) )  
	END

UPDATE dbo.Stats_Summary 
SET SizeIn7  = 	
	CASE WHEN PctIncr < 1 THEN MaxUsed
	WHEN LEN(SizeIn6) >= 30 THEN 0
	ELSE SizeIn6  + ( SizeIn6 * ( PctPerMo/100 ) )  
	END

UPDATE dbo.Stats_Summary 
SET SizeIn8  = 	
	CASE WHEN PctIncr < 1 THEN MaxUsed
	WHEN LEN(SizeIn7) >= 30 THEN 0
	ELSE SizeIn7  + ( SizeIn7 * ( PctPerMo/100 ) )  
	END

UPDATE dbo.Stats_Summary 
SET SizeIn9  = 	
	CASE WHEN PctIncr < 1 THEN MaxUsed
	WHEN LEN(SizeIn8) >= 30 THEN 0
	ELSE SizeIn8  + ( SizeIn8 * ( PctPerMo/100 ) )  
	END

UPDATE dbo.Stats_Summary 
SET SizeIn10 = 	
	CASE WHEN PctIncr < 1 THEN MaxUsed
	WHEN LEN(SizeIn9) >= 30 THEN 0
	ELSE SizeIn9  + ( SizeIn9 * ( PctPerMo/100 ) )  
	END

UPDATE dbo.Stats_Summary 
SET SizeIn11 = 	
	CASE WHEN PctIncr < 1 THEN MaxUsed
	WHEN LEN(SizeIn10) >= 30 THEN 0
	ELSE SizeIn10 + ( SizeIn10 * ( PctPerMo/100 ) )  
	END

UPDATE dbo.Stats_Summary 
SET SizeIn12 = 	
	CASE WHEN PctIncr < 1 THEN MaxUsed
	WHEN LEN(SizeIn11) >= 30 THEN 0
	ELSE SizeIn11 + ( SizeIn11 * ( PctPerMo/100 ) )  
	END
GO

/**********************************************

		Get Users
	
	( This includes database logins )

**********************************************/
PRINT 'PROCESS USERS'
GO

DECLARE 
	@Server	varchar(60),
	@SqlStmt 	varchar( 1000 )

DECLARE Users_curs CURSOR FOR
	SELECT ServerName
	FROM dbo.Servers
	WHERE ServerName NOT LIKE '*%' and ActiveFlag = 1
	--and ServerName not in ( SELECT DISTINCT Servername FROM dbo.Users )
	and ( isnull(Step, '') <> 'usp_users' or ( isnull(Step,'') = 'usp_users' and Finished = 0 ) )
	ORDER BY ServerType desc, ServerName asc
	
OPEN Users_curs
FETCH NEXT FROM Users_curs INTO @Server
WHILE @@FETCH_STATUS = 0
    begin
    PRINT @Server
    UPDATE dbo.Servers SET Step = 'usp_Users' WHERE ServerName = @Server

    SET @SqlStmt = 'EXEC dba.dbo.usp_Users ''' + @Server + ''''
    EXEC( @SqlStmt )

    UPDATE dbo.Servers SET Finished = 1 WHERE Servername = @Server
    
    FETCH NEXT FROM Users_curs INTO @Server
    end
CLOSE Users_curs
DEALLOCATE Users_curs
GO

/*****************************************************

	Get Grants


******************************************************/

DECLARE
    @Server	varchar(60),
    @Database	varchar(60),
    @DBid	int

DECLARE
	CURS CURSOR FOR
	SELECT ServerName, DBName, DBid
	FROM dbo.Databases
	WHERE --DBType <> 'S' and
	DBName not in 
	 ( 'SRP.NA.BLACKBERRY.NET', 'LitespeedLocal', 
	   'TempDB' , 'pubs', 'Northwind' ) 
	and DBid not in ( SELECT distinct DBid FROM dbo.Grants )  
	ORDER BY ServerName, DBName

OPEN CURS
FETCH NEXT FROM CURS INTO @Server, @Database, @DBid
WHILE @@FETCH_STATUS = 0
    BEGIN
	EXEC dbo.usp_Grants @Server, @Database, @DBid
	FETCH NEXT FROM CURS INTO @Server, @Database, @DBid
    END
CLOSE CURS
DEALLOCATE CURS
go


