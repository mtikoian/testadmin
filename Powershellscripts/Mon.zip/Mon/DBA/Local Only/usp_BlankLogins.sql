USE DBA
GO

IF OBJECT_ID( 'dbo.usp_BlankLogins' ) IS NOT NULL
	DROP PROCEDURE dbo.usp_BlankLogins
go


CREATE PROCEDURE dbo.usp_BlankLogins 
		@Server		varchar( 50 ) = NULL
AS
BEGIN
SET NOCOUNT ON
PRINT '    usp_BlankLogins - ' + @Server

IF @Server IS NULL SET @Server = @@Servername

DECLARE
	@SQLStmt		varchar ( 500 )

SET @SQLStmt = 
'INSERT INTO dbo.BlankLogins( ServerName, Login )
SELECT  ''' + @Server + ''', m.name
FROM [' + @Server + '].master.dbo.syslogins m 
WHERE m.password IS NULL AND m.IsNtUser = 0 and m.IsNtGroup = 0'

--PRINT @SQLStmt
EXEC( @SQLStmt )
END
GO

