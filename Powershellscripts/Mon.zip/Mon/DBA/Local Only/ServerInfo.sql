USE DBA
GO

SELECT c.*
FROM [fra1sdbs01p].pmp_v3_0.dbo.PMP_discovered_servers c 
	JOIN DBA.dbo.Servers s ON c.Server_Name = s.ServerName
order by Server_Name
go

SELECT s.ServerName, c.Server_IP, c.OS_Name, c.OS_Description, c.Product_Name, c.pmp_device_key
FROM [fra1sdbs01p].pmp_v3_0.dbo.server_cfg c
	JOIN DBA.dbo.Servers s ON c.Server_Name = s.ServerName
WHERE c.cfg_time = ( SELECT max(cfg_time) FROM [fra1sdbs01p].pmp_v3_0.dbo.server_cfg WHERE server_name = s.ServerName )
go

SELECT c.Name, c.ProductName
FROM [fra1sdbs01p].Insight_v42_0_82913296.dbo.devices c 
	JOIN DBA.dbo.Servers s ON c.Name = s.ServerName
WHERE c.ProductType = 1 and isnull(s.Product_Name, '' ) = '' and isnull(c.ProductName, '') <> ''
order by Name
go

UPDATE DBA.dbo.Servers
SET 	Server_IP 		= c.Server_IP, 
		OS_Name			= c.OS_Name, 
		OS_Description 	= c.OS_Description, 
		Product_Name 	= c.Product_Name, 
		pmp_device_key 	= c.pmp_device_key
FROM 
	[fra1sdbs01p].pmp_v3_0.dbo.server_cfg c 
	JOIN DBA.dbo.Servers s ON c.Server_Name = s.ServerName
WHERE c.cfg_time = ( SELECT max(cfg_time) FROM [fra1sdbs01p].pmp_v3_0.dbo.server_cfg WHERE server_name = s.ServerName )
go

UPDATE DBA.dbo.Servers
SET Product_Name = ProductName
FROM [fra1sdbs01p].Insight_v42_0_82913296.dbo.devices c 
	JOIN DBA.dbo.Servers s ON c.Name = s.ServerName
WHERE c.ProductType = 1 and isnull(s.Product_Name, '' ) = '' and isnull(c.ProductName, '') <> ''
go

UPDATE DBA.dbo.Servers
SET NumCPU =	G.NumCPU,
	CPU	   =	g.CPU,
	MHZ	   = 	g.MHZ
FROM 
	DBA.dbo.Servers ss
	join 
		( SELECT max( pmp_device_key) as dkey, count(*) as NumCPU, max(name) as CPU, max(mhz) as MHZ
		  FROM [fra1sdbs01p].pmp_v3_0.dbo.processor_cfg x
		  WHERE cfg_time = ( SELECT max(cfg_time) FROM [fra1sdbs01p].pmp_v3_0.dbo.server_cfg WHERE pmp_device_key = x.pmp_device_key ) 
		  GROUP BY pmp_device_key
		) AS G on ss.pmp_device_key = g.dkey
go

UPDATE DBA.dbo.Servers
SET MemoryMB = Memory 
FROM 
	DBA.dbo.Servers ss
	join 
	( SELECT max( pmp_device_key ) as dkey, sum( mbytes) as Memory 
	  FROM [fra1sdbs01p].pmp_v3_0.dbo.memory_module_cfg x
	  WHERE cfg_time = ( SELECT max(cfg_time) FROM [fra1sdbs01p].pmp_v3_0.dbo.memory_module_cfg WHERE pmp_device_key = x.pmp_device_key )
	  GROUP BY pmp_device_key 
	) as g on ss.pmp_device_key = g.dkey
go




