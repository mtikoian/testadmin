USE DBA
GO
IF OBJECT_ID( 'dbo.usp_RefreshFreeSpace' ) IS NOT NULL
	DROP PROCEDURE dbo.usp_RefreshFreeSpace
go
CREATE PROCEDURE dbo.usp_RefreshFreeSpace
AS
BEGIN
SET NOCOUNT ON
DECLARE SERVER_CUR CURSOR FOR 
	SELECT ServerName FROM DBA.dbo.Servers
	WHERE ServerName <> '*ALL' and ActiveFlag = 1

DECLARE 
	@Server varchar(60),
	@cmd	varchar(1000)

OPEN SERVER_CUR
FETCH NEXT FROM SERVER_CUR INTO @Server
WHILE @@FETCH_STATUS = 0
	begin
	SET @cmd = 'exec [' + @Server + '].DBA.dbo.usp_CollectFreeSpaceStats ''Y'''
	--PRINT @cmd
	EXEC( @cmd )
	EXEC DBA.dbo.usp_SaveServerFreespace @Server		
	FETCH NEXT FROM SERVER_CUR INTO @Server
	end
CLOSE SERVER_CUR
DEALLOCATE SERVER_CUR
END
GO