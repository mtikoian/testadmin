use DBA
go
IF OBJECT_ID( 'dbo.usp_DeleteBakHistoryDEV3' ) IS NOT NULL
	DROP PROCEDURE dbo.usp_DeleteBakHistoryDEV3
go
CREATE PROCEDURE dbo.usp_DeleteBakHistoryDEV3 
		@Delete			char(1) = 'N',
		@HistoryValue	int = 3
		
AS
BEGIN
SET NOCOUNT ON

CREATE TABLE #cmd_result ( output varchar( 8000 ) )
CREATE TABLE #temp_folder( FileExists int, DirectoryExists int, ParentDirExists int )

IF UPPER(@Delete) NOT IN ( 'Y', 'N' ) 
	begin
	PRINT 'INVALID @Delete value'
	RETURN -1
	end

PRINT 'DATE:  ' + CAST( GETDATE() AS VARCHAR )

DECLARE 
	@Command 		varchar( 1000 ),
	@BakName 		varchar( 80 ),
	@DateString		varchar(30),
	@Count			int,
	@Tally 			int,
	@DirExists		int,
	@Path			varchar(120),
	@DBPath			varchar(120),
	@Server			varchar(60),
	@DB				varchar(80),
	@SaveHistory    int


--  These are the servers that do LiteSpeed backups ( instances included )
DECLARE SERVER_CURS CURSOR FOR
	SELECT ServerName
	FROM DBA.dbo.Servers
	WHERE ServerName in
	( '2KSQLPROD1', '2KSQLPROD2', '2KSQLPROD4', '2KSQLPROD5' , '2KSQLPROD6', '2KSQLPROD7', 'FRA1VSSQL02',
	  '2KSQLDEV1', '2KSQLDEV1\STELLENT', '2KSQLDEV1\IC', '2KSQLDEV1\POWR', '2KSQLDEV3', '2KSQLDEV3\OUTLOOKSOFT')
	ORDER BY ServerName

DECLARE BAK_CURS CURSOR FOR
	SELECT 	LEFT( output, 10 ), RIGHT( output, CHARINDEX( ' ', REVERSE( output ) ) - 1 ) 
	FROM #cmd_result
	ORDER BY RIGHT( output, CHARINDEX( ' ', REVERSE( output ) ) - 1 ) 


SET @Path = '\\2ksqldev3\Edrive' 
WHILE @Path <> 'ZZ'
    begin
    OPEN SERVER_CURS
	FETCH NEXT FROM SERVER_CURS INTO @Server
	WHILE @@FETCH_STATUS = 0 
		begin
		SET @Path = @Path + '\' + CASE WHEN CHARINDEX('\', @Server) = 0 THEN @Server
			ELSE RIGHT(@Server, LEN(@Server) - CHARINDEX('\', @Server)) END
		PRINT @PATH
		SET @Command = 'INSERT INTO #temp_folder exec master..xp_fileexist ''' + @Path + ''''
		--PRINT @Command

		EXEC (@Command)
	    SELECT @DirExists = DirectoryExists FROM #temp_folder
		
		IF @DirExists = 1
			begin 
			DECLARE DB_CURS CURSOR FOR 
				SELECT DBName FROM DBA.dbo.Databases 
				WHERE ServerName = @Server and DBName <> 'WebPDM'
				ORDER BY DBName

			OPEN DB_CURS
			FETCH NEXT FROM DB_CURS INTO @DB
			WHILE @@FETCH_STATUS = 0
				begin
				SET @DBPath = @Path +  '\' + @DB +  '\' + @DB + '_db_*.BAK'
				SET @Command = 'INSERT #cmd_result exec master..xp_cmdshell ''dir '+ @DBPath + ''''
				--PRINT @Command
				EXECUTE ( @Command )
				DELETE FROM #cmd_result WHERE CHARINDEX( '.BAK', output ) = 0
				DELETE FROM #cmd_result WHERE output is null
			
				SELECT @Count = COUNT(*) FROM #cmd_result
				--PRINT CAST(@Count AS VARCHAR )

				IF @Count <= 0
					DELETE FROM #cmd_result

				IF @Server = '2KSQLPROD1' and @Count <= 6 
					and @DB in ( 'POWR_Client_Repository_Master', 'POWR_SERV', 'csdb' ) 
					begin
					--PRINT 'ONLY ' + CAST(@Count AS varchar) + ' BACKUPS FOR ' + @Server + ' ' + @DB
					DELETE FROM #cmd_result
					end

				ELSE IF @Count <= @HistoryValue
					begin
					--PRINT 'ONLY ' + CAST(@Count AS varchar) + ' BACKUPS FOR ' + @Server + ' ' + @DB
					DELETE FROM #cmd_result
					end
				ELSE IF @Count > 0
					begin
					SET @Tally = 0 
					IF @Server = '2KSQLPROD1' AND @DB IN ( 'POWR_Client_Repository_Master', 'POWR_SERV', 'csdb'  ) 
						begin
						SET @SaveHistory = @HistoryValue
						SET @HistoryValue = 6
						end
					PRINT ' '
					PRINT '*****   SEARCHING FOR BACKUP TO DELETE FOR ' + @Server + ' ' + @DB + ' *****'
					OPEN BAK_CURS
					FETCH FROM BAK_CURS INTO @DateString, @BakName
					WHILE @@FETCH_STATUS = 0 and @Count - @Tally > @HistoryValue
						begin
						SET @Command = 'master..xp_cmdshell ''del "' + @Path + '\' + @DB + '\' + @BakName + '"'''
						--PRINT @Command
						
						PRINT @BakName
						IF @Delete = 'Y' EXEC( @Command )
						SET @Tally = @Tally + 1

						FETCH FROM BAK_CURS INTO @DateString, @BakName
						end	-- WHILE BAK_CURS

					CLOSE BAK_CURS
					DELETE FROM #cmd_result

					IF @Server = '2KSQLPROD1' AND @DB IN ( 'POWR_Client_Repository_Master', 'POWR_SERV', 'csdb'  ) 
						SET @HistoryValue = @SaveHistory
					
					IF @Delete = 'Y' PRINT '***** ' + CAST( @Tally as varchar ) + ' FILES DELETED *****'
					ELSE PRINT '***** ' + CAST( @Tally as varchar ) + ' FILES ELIGIBLE FOR DELETION *****'
					PRINT ' '
					end  -- else
				FETCH NEXT FROM DB_CURS INTO @DB
				end -- WHILE DB_CURS
					
			CLOSE DB_CURS
			DEALLOCATE DB_CURS
			end -- DirExits

		SET @Path = LEFT(@Path,18)
		DELETE FROM #temp_folder
		FETCH NEXT FROM SERVER_CURS INTO @Server
		end -- while SERVER_CURS
				
	CLOSE SERVER_CURS

	
	IF      substring(@Path, 13, 1) = 'E' SET @Path = '\\2ksqldev3\Fdrive'
	ELSE IF substring(@Path, 13, 1) = 'F' SET @Path = '\\2ksqldev3\Gdrive'
	ELSE IF substring(@Path, 13, 1) = 'G' SET @Path = '\\2ksqldev3\Hdrive'
	ELSE IF substring(@Path, 13, 1) = 'H' SET @Path = '\\2ksqldev3\Idrive'
	ELSE IF substring(@Path, 13, 1) = 'I' SET @Path = '\\2ksqldev3\Jdrive'
	ELSE IF substring(@Path, 13, 1) = 'J' SET @Path = '\\2ksqldev3\Kdrive'
	ELSE IF substring(@Path, 13, 1) = 'K' SET @Path = '\\2ksqldev3\Ldrive'
	ELSE IF substring(@Path, 13, 1) = 'L' SET @Path = '\\2ksqldev3\Mdrive'
	ELSE SET @Path = 'ZZ'

	end -- while @PATH
	
DEALLOCATE BAK_CURS
DEALLOCATE SERVER_CURS
DROP TABLE #cmd_result
RETURN 0
END
go

