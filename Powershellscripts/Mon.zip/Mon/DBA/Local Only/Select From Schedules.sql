select ServerName, JobName, [When], Time from schedules 
where Time between '01:00:00' and '02:00:00' and ( [when] like '%Sun%' or [when] like '%every%')
order by servername, time, jobname