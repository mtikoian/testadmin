USE DBA
GO
IF OBJECT_ID( 'dbo.usp_RefreshActivity' ) IS NOT NULL
	DROP PROCEDURE dbo.usp_RefreshActivity
go
CREATE PROCEDURE dbo.usp_RefreshActivity
	@Server		varchar(60) = @@Servername

/*********************************************

		Gets Activity and Lock info
		from another server's tables.

*********************************************/

AS
BEGIN
SET NOCOUNT ON
PRINT 'usp_RefreshActivity - ' + @Server

BEGIN TRAN
DELETE FROM dbo.User_Locks    
FROM dbo.User_Activity a JOIN dbo.User_Locks l on a.Id = l.ActivityId
WHERE a.ServerName = @Server

DELETE FROM dbo.User_Activity WHERE ServerName = @Server
COMMIT

DECLARE @Cmd varchar(3000)
EXEC( @Cmd )

SET @Cmd = 
	'INSERT INTO dbo.User_Activity
	( ServerName, SPID, Status, Login,	Host, Block, BlkBy,	DB, Command, CPUTime, DiskIO, 
	LastBatch, Program, Buffer, FetchDate	)
	SELECT ''' + @Server + ''', SPID, Status, Login, Host, Block, BlkBy, DB, Command, 
	CPUTime, DiskIO, LastBatch, Program, Buffer, FetchDate
	FROM [' + @Server + '].DBA.dbo.User_Activity_Loc'
--PRINT @Cmd
EXEC( @Cmd )

SET @Cmd = 
	'INSERT INTO dbo.User_Locks
	( ActivityId, ObjName, IndexName, Type, Resource, Mode, Status)
	SELECT a.Id, ObjName, IndexName, Type, Resource, Mode, l.Status
	FROM [' + @Server + '].DBA.dbo.User_Locks_Loc l 
	JOIN dbo.User_Activity a on a.SPID = l.SPID and ServerName = ''' + @Server + ''''
--PRINT @Cmd
EXEC( @Cmd )

UPDATE dbo.User_Activity
SET Lock = 1
WHERE Id in ( Select distinct ActivityId from dbo.User_Locks )
END
go