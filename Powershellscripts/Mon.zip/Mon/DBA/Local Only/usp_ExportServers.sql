use DBA
go

IF OBJECT_ID( 'dbo.usp_ExportServers' ) IS NOT NULL
	DROP PROCEDURE dbo.usp_ExportUsers
go
CREATE PROCEDURE dbo.usp_ExportServers
AS
BEGIN
SET NOCOUNT ON
DECLARE @rtn	int

CREATE TABLE #TEMP
(
	job_id uniqueidentifier ,
	job_name sysname ,
	run_status int ,
	run_date int ,
	run_time int ,
	run_duration int ,
	operator_emailed nvarchar(20) ,
	operator_netsent nvarchar(20), 
	operator_paged nvarchar(20) ,
	retries_attempted int ,
	server nvarchar(30) 
)

SET @rtn = 0

--EXEC master..xp_cmdshell 'DTSRun /S "(local)" /N "Daily Check - Export Servers" /E '
exec msdb.dbo.sp_start_job 'DailyCheck - Export Servers'
WAITFOR DELAY '000:00:05' -- Give the job a chance to complete
INSERT INTO #TEMP EXEC msdb.dbo.sp_help_jobhistory @job_name = 'DailyCheck - Export Servers'

WHILE @@ROWCOUNT = 0
  BEGIN
  WAITFOR DELAY '000:00:05' -- Give the job a chance to complete
  INSERT INTO #TEMP EXEC msdb.dbo.sp_help_jobhistory @job_name = 'DailyCheck - Export Servers'
  END

SELECT @rtn = max(run_status) FROM #TEMP
IF @rtn <> 1 SET @rtn = -1
RETURN @rtn
END
GO