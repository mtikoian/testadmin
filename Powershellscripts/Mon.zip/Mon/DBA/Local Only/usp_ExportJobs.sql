use DBA
go
IF OBJECT_ID( 'dbo.usp_ExportJobs' ) IS NOT NULL
	DROP PROCEDURE dbo.usp_ExportJobs
go
CREATE PROCEDURE dbo.usp_ExportJobs 
	@Status		varchar(15) = 'ALL', 
	@Shipping 	char(1)     = 'N', 
	@Server		varchar(50) = 'ALL',
	@ServerType	char(1)     = 'A'
AS
BEGIN
SET NOCOUNT ON

DECLARE @rtn	int

CREATE TABLE #TEMP
(
	job_id uniqueidentifier ,
	job_name sysname ,
	run_status int ,
	run_date int ,
	run_time int ,
	run_duration int ,
	operator_emailed nvarchar(20) ,
	operator_netsent nvarchar(20), 
	operator_paged nvarchar(20) ,
	retries_attempted int ,
	server nvarchar(30) 
)

SET @rtn = 0

IF OBJECT_ID( 'dbo.ExportJobs' ) IS NOT NULL
	DROP TABLE dbo.ExportJobs

DECLARE 
	@DTSCommand varchar(300),
	@SQLCmd		varchar(2000)

SET @SQLCmd = 
'SELECT    
	r.ServerName, 
	Originating_Server AS [From Srv], 
	JobName, 
	MaintPlan,
	DTS,
	Scheduled,
	Status, 
	CAST(RunDate AS datetime) AS Date, 
	RunTime AS Time, 
	RunDuration AS Duration, 
    DateModified, 
	LogFileName AS [Log], 
	CASE WHEN Description = ''No description available.'' 
	     THEN '''' ELSE Description END AS Description, 
    RIGHT(Message, LEN(Message) - CHARINDEX(''.'', Message) - 2) AS Message, 
	RunDatetime
INTO dbo.ExportJobs
FROM dbo.Jobs r join dbo.SERVERS s ON r.ServerName = s.ServerName'

IF @Status = 'Failed'
	begin
	SET @SQLCmd = @SQLCmd + ' WHERE Status = ''Failed''' 
	IF @Server NOT IN (  'ALL', '*ALL' )
		SET @SQLCmd = @SQLCmd + ' and r.ServerName = ''' + @Server + ''''
	ELSE IF @ServerType <> 'A'
		SET @SQLCmd = @SQLCmd + ' and ServerType = ''' + @ServerType + ''''
	end

ELSE IF @Shipping = 'N'
	begin
	SET @SQLCmd = @SQLCmd + 
		' WHERE JobName not like ''%LogShip%'' and JobName not like ''%Log Ship%'''
	IF @Server IN ( 'ALL', '*ALL' )
		SET @SQLCmd = @SQLCmd + ' and r.ServerName = ''' + @Server + ''''
	ELSE IF @ServerType <> 'A'
		SET @SQLCmd = @SQLCmd + ' and ServerType = ''' + @ServerType + ''''
	end

ELSE IF @Server IN ( 'ALL', '*ALL' )
	SET @SQLCmd = @SQLCmd + ' WHERE r.ServerName = ''' + @Server + ''''

ELSE IF @ServerType <> 'A'
	SET @SQLCmd = @SQLCmd + ' WHERE ServerType = ''' + @ServerType + ''''

PRINT @SQLCmd
EXEC( @SQLCmd )
--EXEC master..xp_cmdshell 'DTSRun /S "(local)" /N "Daily Check - Export Jobs" /E '

exec msdb.dbo.sp_start_job 'DailyCheck - Export Jobs'
WAITFOR DELAY '000:00:05' -- Give the job a chance to complete
INSERT INTO #TEMP EXEC msdb.dbo.sp_help_jobhistory @job_name = 'DailyCheck - Export Jobs'

WHILE @@ROWCOUNT = 0
  BEGIN
  WAITFOR DELAY '000:00:05' -- Give the job a chance to complete
  INSERT INTO #TEMP EXEC msdb.dbo.sp_help_jobhistory @job_name = 'DailyCheck - Export Jobs'
  END

SELECT @rtn = max(run_status) FROM #TEMP
IF @rtn <> 1 SET @rtn = -1
RETURN @rtn
END

GO