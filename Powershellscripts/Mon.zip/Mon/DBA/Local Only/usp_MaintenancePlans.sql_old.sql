USE DBA
GO
IF OBJECT_ID( 'dbo.usp_MaintenancePlans' ) IS NOT NULL
	DROP PROCEDURE dbo.usp_MaintenancePlans 
GO
CREATE PROCEDURE dbo.usp_MaintenancePlans 
	@Server varchar(60) = @@servername,
	@Litespeed varchar(10) = ''
AS
BEGIN
SET NOCOUNT ON
PRINT '    usp_MaintenancePlans'

DECLARE	@Cmd varchar(3000)

IF ISNULL( @Litespeed, '' ) <> ''
	begin
	SET @Cmd = 
	'INSERT INTO dbo.MaintenancePlans( DBId, [Date], EndDate, ActivityId, Activity, Status )
	SELECT db.DBId, s.StartTime, s.FinishTime, s.ActivityTypeId, s.ActivityTypeDesc, s.StatusName
	FROM 
	dbo.Databases db
	join 
	(	SELECT 
			a.ServerName, d.DatabaseName, a.StartTime, a.FinishTime, a.ActivityTypeID,
			t.ActivityTypeDesc, y.StatusName
		FROM 
			[' + @Server + '].LitespeedLocal.dbo.LitespeedActivity a
			join [' + @Server + '].LitespeedLocal.dbo.LitespeedActivityType t 
				on a.ActivityTypeID = t.ActivityTypeId
			join [' + @Server + '].LitespeedLocal.dbo.LitespeedDatabase d 
				on a.DatabaseId = d.DatabaseId
			join [' + @Server + '].LitespeedLocal.dbo.LitespeedStatusType y 
				on a.StatusTypeID = y.StatusTypeId 
			join
			(	SELECT DatabaseId, ActivityTypeId, max(StartTime) as StartTime
				FROM [' + @Server + '].LitespeedLocal.dbo.LitespeedActivity 
				GROUP BY ServerName, DatabaseId, ActivityTypeID
			) as ls on	a.DatabaseId = ls.DatabaseId and
					a.ActivityTypeId = ls.ActivityTypeId
		WHERE a.StartTime = ls.StartTime
	) AS s on	db.ServerName = s.ServerName and 
			db.DBName = s.DatabaseName
	WHERE db.DBName NOT IN ( ''Northwind'', ''pubs'', ''tempdb'' )'
	end
ELSE
	begin
	SET @Cmd =
	'INSERT INTO dbo.MaintenancePlans( PlanName, Activity, EndDate, DBId, Status )
	SELECT h.plan_name, h.activity, h.end_time, v.DBId, 
	CASE h.succeeded WHEN 1 THEN ''Succeeded'' ELSE ''Failed'' END
	FROM 
	dbo.Databases v 
	JOIN
	( SELECT plan_name, database_name, server_name, activity, max(end_time) as end_time
	FROM [' + @Server + '].msdb.dbo.sysdbmaintplan_history 
	GROUP BY plan_name, database_name, server_name, activity
	) AS m ON v.DBName = m.database_name and v.ServerName = m.server_name
	JOIN [' + @Server + '].msdb.dbo.sysdbmaintplan_history h
	on 	m.plan_name = h.plan_name and 
		m.database_name = h.database_name and 
		m.server_name = h.server_name and
		m.activity = h.activity
	WHERE m.end_time = h.end_time and m.database_name NOT IN ( ''Northwind'', ''pubs'', ''tempdb'' )'
	end

--PRINT @Cmd
EXEC( @Cmd )


END
GO


