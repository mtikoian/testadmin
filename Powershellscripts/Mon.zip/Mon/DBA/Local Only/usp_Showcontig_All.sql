USE DBA
GO
IF OBJECT_ID( 'dbo.usp_Showcontig_All') IS NOT NULL
	DROP PROCEDURE dbo.usp_Showcontig_All 
GO
CREATE PROCEDURE dbo.usp_Showcontig_All
		@ServerName	varchar(50 ), 
		@Threshold int = 10
AS
SET NOCOUNT ON

DECLARE
	@SqlStmt	varchar( 3000 )

IF @ServerName IS NULL RETURN(-1)

SET @SqlStmt = '
	INSERT INTO dbo.Showcontig_All' + 
	'( ServerName,DBName,TableName,TableId,IndexName,
		IndexId,Lvl,Pages,Rows,MinRecSize,MaxRecSize,
		AvgRecSize,ForRecCount,Extents,ExtentSwitches,AvgFreeBytes,
		AvgPageDensity,ScanDensity,BestCount,ActualCount,LogicalFrag,
		ExtentFrag,	Owner, Add_Datetime	) ' + 
	'SELECT ''' + @ServerName + ''',' +
		'DBName,TableName,TableId,IndexName,
		IndexId,Lvl,CountPages,CountRows,MinRecSize,MaxRecSize,
		AvgRecSize,ForRecCount,Extents,ExtentSwitches,AvgFreeBytes,
		AvgPageDensity,ScanDensity,BestCount,ActualCount,LogicalFrag,
	ExtentFrag,	Owner, Add_Date ' +
	'FROM [' + @ServerName + '].DBA.dbo.Showcontig ' +
	'WHERE DBName + TableName + IndexName + CAST( Add_Date as varchar ) NOT in
	( SELECT DBName + TableName + IndexName + CAST( Add_Datetime as varchar )
      FROM DBA.dbo.Showcontig_All 
	  WHERE ServerName = ''' + @ServerName + ''' )'
--PRINT @SqlStmt
EXEC( @SqlStmt )
GO

