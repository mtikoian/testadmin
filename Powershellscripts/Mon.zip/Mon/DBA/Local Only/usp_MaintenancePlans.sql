USE DBA
GO
IF OBJECT_ID( 'dbo.usp_MaintenancePlans' ) IS NOT NULL
	DROP PROCEDURE dbo.usp_MaintenancePlans 
GO
CREATE PROCEDURE dbo.usp_MaintenancePlans 
	@Server varchar(60) = @@servername,
	@Litespeed varchar(10) = '',
	@Version int = 2
AS
BEGIN
SET NOCOUNT ON
PRINT '    usp_MaintenancePlans - ' + @Server

DECLARE	@Cmd varchar(8000)

IF ISNULL( @Litespeed, '' ) <> ''
	begin
	-- This will get the backup jobs
	SET @Cmd = 
	'INSERT INTO DBA.dbo.MaintenancePlans
		( ServerName, DBId, [Date], EndDate, ActivityId, Activity, Status )
	SELECT ''' + @Server + ''', db.DBId, s.StartTime, s.FinishTime, s.ActivityTypeId, 
		s.ActivityTypeName, s.StatusName 
	FROM 
	DBA.dbo.Databases db
	join 
	(	SELECT 
			a.ServerName, d.DatabaseName, a.StartTime, a.FinishTime, a.ActivityTypeID,
			t.ActivityTypeName, y.StatusName
		FROM 
			[' + @Server + '].LitespeedLocal.dbo.LitespeedActivity a
			join [' + @Server + '].LitespeedLocal.dbo.LitespeedActivityType t 
				on a.ActivityTypeID = t.ActivityTypeId
			join [' + @Server + '].LitespeedLocal.dbo.LitespeedDatabase d 
				on a.DatabaseId = d.DatabaseId
			join [' + @Server + '].LitespeedLocal.dbo.LitespeedStatusType y 
				on a.StatusTypeID = y.StatusTypeId 
			join
			(	SELECT DatabaseId, ActivityTypeId, max(StartTime) as StartTime
				FROM [' + @Server + '].LitespeedLocal.dbo.LitespeedActivity 
				GROUP BY DatabaseId, ActivityTypeID
			) as ls on	a.DatabaseId = ls.DatabaseId and
					a.ActivityTypeId = ls.ActivityTypeId
		WHERE a.StartTime = ls.StartTime
	) AS s on db.DBName = s.DatabaseName
	WHERE db.ServerName = ''' + @Server + ''' and 
	db.DBName NOT IN ( ''Northwind'', ''pubs'', ''tempdb'', ''model'', ''msdb'')'
	--PRINT @Cmd
	EXEC( @Cmd )
	-- This will get the integrity and optimization jobs
	SET @Cmd = 
	'INSERT INTO DBA.dbo.MaintenancePlans
		( ServerName, DBId, PlanName, [Date], Status, Activity, Duration )
	SELECT DISTINCT 
		db.ServerName,
		db.DBId,
		j.name as PlanName,
		h.maxdate as StartTime, 
		CASE hh.run_status 
			WHEN 0 THEN ''Failed''
			WHEN 1 THEN ''Succeeded''
			WHEN 2 THEN ''Retry''
			WHEN 3 THEN ''Canceled''
			WHEN 4 THEN ''In progress''
			ELSE cast(hh.run_status as varchar) end as StatusName,
		RIGHT(j.name, len(j.name) -  charindex(''.'', j.name )) as Activity,
		hh.run_duration
	FROM 
		[' + @Server + '].msdb.dbo.sysjobs j 
		join [' + @Server + '].msdb.dbo.sysjobhistory hh
			 on hh.job_id = j.job_id and hh.step_id = 0
		join 
		( 
		  SELECT job_id,
			MAX( dbo.udf_HistoryDateTime (run_date, run_time) ) as maxdate
		  FROM [' + @Server + '].msdb.dbo.sysjobhistory 
		  WHERE step_id = 0
		  GROUP BY job_id
		 )as h on j.job_id = h.job_id
		join DBA.dbo.Databases db on db.ServerName = ''' + @Server + ''' and 
			db.DBName = CASE 
			WHEN charindex(''.'', j.name ) = 0 THEN j.name
			WHEN LEFT(j.name, charindex(''.'', j.name ) - 1 ) like ''System D%'' 
			THEN ''master''
			ELSE LEFT(j.name, charindex(''.'', j.name ) - 1 ) END
	WHERE j.category_id = 3 
		and LEFT(j.name, charindex(''.'', j.name ) ) <> ''All DBs.''
		and charindex(''Backup'', j.name ) = 0 
		and charindex(''.'', j.name ) <> 0
		and dbo.udf_HistoryDateTime (run_date, run_time) = maxdate'
	--PRINT @Cmd
	EXEC( @Cmd )
	end

ELSE IF @Version in ( 2, 7 )
	begin
	SET @Cmd =
	'INSERT INTO DBA.dbo.MaintenancePlans
		( ServerName, PlanName, Activity, [Date], EndDate, DBId, Status )
	SELECT ''' + @Server + ''', h.plan_name, h.activity, h.start_time, h.end_time, v.DBId, 
	CASE h.succeeded WHEN 1 THEN ''Succeeded'' ELSE ''Failed'' END 
	FROM 
	    DBA.dbo.Databases v 
	    JOIN
	    ( SELECT plan_name, database_name, activity, max(end_time) as end_time
	      FROM [' + @Server + '].msdb.dbo.sysdbmaintplan_history 
	      WHERE isnull( database_name, '''') <> ''''
	      GROUP BY plan_name, database_name, activity
	    ) AS m ON v.DBName = m.database_name 
	    JOIN [' + @Server + '].msdb.dbo.sysdbmaintplan_history h
	    on 	m.plan_name = h.plan_name and 
		m.database_name = h.database_name and 
		m.activity = h.activity
	WHERE v.ServerName = ''' + @Server + ''' 
		and m.end_time = h.end_time 
		and m.database_name NOT IN ( ''Northwind'', ''pubs'', ''tempdb'', ''model'', ''msdb'' )'
	--PRINT @Cmd
	EXEC( @Cmd )
	end

ELSE
	begin
	SET @Cmd =
	'INSERT INTO DBA.dbo.MaintenancePlans
		( ServerName, PlanName, [Date], Status, DBid, Activity, Duration )
	SELECT DISTINCT ''' + @Server + ''', 
		j.name as PlanName, 
		maxh.maxdate as StartDateTime, 
		CASE h.run_status	
			WHEN 0 THEN ''Failed''
			WHEN 1 THEN ''Succeeded''
			WHEN 2 THEN ''Retry''
			WHEN 3 THEN ''Cancelled''
			ELSE ''In Progress''
		END as Status,
		dd.DBID,
		right( j.name, len(j.name) - charindex(''.'', j.name)) as Activity,
		run_duration
	  FROM 
		( SELECT job_id, 
			MAX( dbo.udf_HistoryDateTime (run_date, run_time)) as maxdate
		  FROM [' + @Server + '].msdb.dbo.sysjobhistory
		  WHERE step_id = 0
		  GROUP BY job_id
		) as maxh
		JOIN [' + @Server + '].msdb.dbo.sysjobs j ON j.job_id = maxh.job_id
		JOIN [' + @Server + '].msdb.dbo.sysjobhistory h ON j.job_id = h.job_id and 
			dbo.udf_HistoryDateTime (h.run_date, h.run_time) = maxh.maxdate and
			h.step_id = 0
		LEFT JOIN [' + @Server + '].master.dbo.sysdatabases d on d.name = LEFT(j.name, charindex(''.'', j.name ) - 1 )
		LEFT JOIN DBA.dbo.Databases dd ON dd.ServerName = ''' + @Server + ''' and
		dd.DBName = CASE 
		    WHEN charindex(''.'', j.name ) = 0 THEN j.name
		    WHEN LEFT(j.name, charindex(''.'', j.name ) - 1 ) like ''System D%'' 
			THEN ''master'' 
		    ELSE LEFT(j.name, charindex(''.'', j.name ) - 1 ) END
	WHERE j.category_id = 3 and LEFT(j.name, charindex(''.'', j.name ) ) <> ''All DBs.'''
	--PRINT @Cmd
	EXEC( @Cmd )
	end

END
GO


