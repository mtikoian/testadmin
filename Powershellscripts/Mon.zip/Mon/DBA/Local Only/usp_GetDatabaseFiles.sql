USE DBA
GO
IF OBJECT_ID( 'dbo.usp_GetDatabaseFiles' ) IS NOT NULL
	DROP PROCEDURE dbo.usp_GetDatabaseFiles
go
CREATE PROCEDURE dbo.usp_GetDatabaseFiles  
	@Server	varchar(60)
AS
BEGIN
SET NOCOUNT ON
PRINT '    usp_GetDatabaseFiles - ' + @Server

DECLARE	@cmd	varchar(2000)
SET @cmd = 
	'INSERT INTO DBA.dbo.Database_Files( DBId, LogicalName, PhysicalName, SizeInMB )
	SELECT a.DBId, f.name, f.filename, f.Size
	FROM [' + @Server + '].master.dbo.sysaltfiles f 
		JOIN [' + @Server + '].master.dbo.sysdatabases d ON f.dbid = d.dbid 
		JOIN DBA.dbo.Databases a ON a.ServerName = ''' + @Server + ''' and a.DBname = d.name'
--PRINT @cmd
EXEC( @cmd )
END
GO
