﻿
Add-Type -AssemblyName "Microsoft.SqlServer.Smo, Version=11.0.0.0, Culture=neutral, PublicKeyToken=89845dcd8080cc91"
Add-Type -AssemblyName "Microsoft.SqlServer.SMOExtended, Version=11.0.0.0, Culture=neutral, PublicKeyToken=89845dcd8080cc91"

$server = New-Object -TypeName Microsoft.SqlServer.Management.Smo.Server -ArgumentList "Localhost\i12"

$initfields = $server.GetDefaultInitFields([Microsoft.SqlServer.Management.Smo.Database])
$initfields

$initfields.Add("ID") | Out-Null
$initfields.Add("RecoveryModel") | Out-Null
$server.SetDefaultInitFields([Microsoft.SqlServer.Management.Smo.Database], $initfields)

$btime = Get-Date
$server.Databases | Select Name, ID, RecoveryModel | Out-Null
$atime = Get-Date

$ts = New-TimeSpan -Start $btime -End $atime

Write-Host "Time taken: $($ts.Milliseconds) ms"
