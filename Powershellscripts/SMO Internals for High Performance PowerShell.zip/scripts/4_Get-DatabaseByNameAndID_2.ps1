
Add-Type -AssemblyName "Microsoft.SqlServer.Smo, Version=11.0.0.0, Culture=neutral, PublicKeyToken=89845dcd8080cc91"
Add-Type -AssemblyName "Microsoft.SqlServer.SMOExtended, Version=11.0.0.0, Culture=neutral, PublicKeyToken=89845dcd8080cc91"

$server = New-Object -TypeName Microsoft.SqlServer.Management.Smo.Server -ArgumentList "Localhost\i12"


$server.Name
$initfields = $server.GetDefaultInitFields([Microsoft.SqlServer.Management.Smo.Database])
$initfields.Add("ID")
$initfields.Add("Owner")
$initfields.Add("PageVerify")
$initfields.Add("Size")

$server.SetDefaultInitFields([Microsoft.SqlServer.Management.Smo.Database], $initfields)

$server.Databases | Select Name, Owner, PageVerify, size | Out-Null

$db = $server.Databases["SMO_DB1"]
$db.Name
$db.Owner
$db.PageVerify
$db.Size


<#
Be careful with the SetInitDefaultFields when using
Retrieved values that are not in sys.databases, 
when you access a property, it will retrieve the
value for all DBs even if you don't use it.
#>
#$alldbs = $server.Databases
#$alldbs[0].PageVerify

Write-Host "Memory after Name: $(($after - $before)/1MB)"

$before = [gc]::GetTotalMemory($true)
$db.Size
$after = [gc]::GetTotalMemory($true)

Write-Host "Memory after Size: $(($after - $before)/1MB)"

# Watch what happens when you go after the ID
$before = [gc]::GetTotalMemory($true)
$db.ID
$after = [gc]::GetTotalMemory($true)
$endmemory = [gc]::GetTotalMemory($true)

Write-Host "Memory after ID: $(($after - $before)/1MB)"
Write-Host "Total Memory Difference: $(($endmemory - $beginmemory)/1MB)"

