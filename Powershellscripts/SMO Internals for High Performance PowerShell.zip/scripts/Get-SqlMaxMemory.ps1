
Add-Type -AssemblyName "Microsoft.SqlServer.Smo, Version=10.0.0.0, Culture=neutral, PublicKeyToken=89845dcd8080cc91"

Function Get-SqlMaxMemory {
	Param ( [string]$sqlserver )
	
	$sqlconn = New-Object -TypeName Microsoft.SqlServer.Management.Smo.Server -ArgumentList $sqlserver
	
	$maxmem = $sqlconn.Configuration.MaxServerMemory.RunValue
	Write-Output $maxmem
}

