﻿
Add-Type -AssemblyName "Microsoft.SqlServer.Smo, Version=11.0.0.0, Culture=neutral, PublicKeyToken=89845dcd8080cc91"
Add-Type -AssemblyName "Microsoft.SqlServer.SMOExtended, Version=11.0.0.0, Culture=neutral, PublicKeyToken=89845dcd8080cc91"

$server = New-Object -TypeName Microsoft.SqlServer.Management.Smo.Server -ArgumentList "Localhost\i12"

$btime = Get-Date
$dbs = $server.Databases
$dbs | Select Name, ID | Out-Null

#$server.Databases | Select Name, ID | Out-Null
$atime = Get-Date
$ts = New-TimeSpan -Start $btime -End $atime

Write-Host "Time taken: $($ts.Milliseconds) ms"

