# Set everything enabled except INST2 services
Set-SQLServiceStartMode -OriginalStartMode 'Auto' -NewStartMode 'Manual'
Set-SQLServiceStartMode -OriginalStartMode 'Disabled' -NewStartMode 'Manual'
Set-SQLServiceStartMode -NewStartMode 'Disabled' -ServiceName 'ReportServer$INST1' -ComputerName bigred7
Set-SQLServiceStartMode -NewStartMode 'Disabled' -ServiceName 'MSSQL$INST2' -ComputerName bigred7
Set-SQLServiceStartMode -NewStartMode 'Disabled' -ServiceName 'SQLAgent$INST2' -ComputerName bigred7
Stop-Service 'MSSQL$INST2' -Force
Start-SQLServices

# Init OLA Demo
Get-ChildItem -Path 'C:\SQL\MSSQL11.INST1\MSSQL\Backup\' | Remove-Item -Recurse -Force 
Copy-Item -Path 'C:\SQL\MSSQL11.INST1\MSSQL\BackupSaved\BIGRED7$INST1\' -Destination 'C:\SQL\MSSQL11.INST1\MSSQL\Backup\' -Recurse
Get-ChildItem 'C:\SQL\MSSQL11.INST1\MSSQL\Backup\' -File -Recurse | ForEach-Object { $_.CreationTime = $_.LastWriteTime }


Get-SQLServices | Format-Table -AutoSize

# Start PowerPoint
Start-Process powerpnt.exe -ArgumentList "C:\Users\cjsommer\Documents\Git\sqlserver-automation-with-posh\SQLServerAutomationWithPowershell.pptx"

# Start SSMS
Start-Process ssms.exe

# Start Windows Explorer
Start-Process explorer.exe -ArgumentList "C:\Users\cjsommer\Documents\Git\sqlserver-automation-with-posh"

# Start IE
Start-Process iexplore.exe
