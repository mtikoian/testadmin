﻿[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo")
[System.Reflection.Assembly]::LoadFile("")
[System.Reflection.Assembly]::LoadFrom("")

Add-Type -AssemblyName Microsoft.SqlServer.Smo

Add-Type -AssemblyName "Microsoft.SqlServer.Smo, Version=12.0.0.0, Culture=neutral, PublicKeyToken=89845dcd8080cc91"


