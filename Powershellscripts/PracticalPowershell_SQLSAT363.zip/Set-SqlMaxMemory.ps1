param ($server, $value)

$sqlserver = New-Object -TypeName Microsoft.SqlServer.Management.Smo.Server -ArgumentList $server
$sqlserver.Configuration.MaxServerMemory.ConfigValue = $value
$sqlserver.Configuration.Alter() # could use Alter($true) for RECONFIGURE WITH OVERRIDE
