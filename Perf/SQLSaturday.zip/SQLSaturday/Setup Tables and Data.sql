-- Create a table with 3 pages of data
CREATE TABLE dbo.ULocks (
  ID  int           NOT NULL,
  NCI int           NOT NULL,
  VC  varchar(1024) NOT NULL,
  
  CONSTRAINT PK_ULocks
    PRIMARY KEY CLUSTERED (ID)
);

CREATE NONCLUSTERED INDEX NCI_ULocks
  ON dbo.ULocks(NCI);

DECLARE
  @ct int;

SET @ct = 1;

WHILE (@ct < 20)
BEGIN
  INSERT INTO dbo.ULocks (ID, NCI, VC)
  VALUES(@ct, @ct, REPLICATE(CAST(@ct AS char(1)), 1000));

  SET @ct = @ct + 1;
END
GO

-- Clean all (most) dirty pages
CHECKPOINT 1;


