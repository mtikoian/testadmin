EXEC sp_lock;

SELECT * FROM sys.dm_tran_locks;