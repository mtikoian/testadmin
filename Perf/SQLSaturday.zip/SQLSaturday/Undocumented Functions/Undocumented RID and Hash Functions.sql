-- View the hash using the primary key
SELECT
  %%lockres%%,
  *
FROM
  dbo.ULocks;

-- View the hashes for the non-clustered index
SELECT
  %%lockres%%,
  *
FROM
  dbo.ULocks WITH (INDEX = NCI_ULocks);

-- View the RID in a binary format
-- See SQL Server 2008 Internals for a decode function
SELECT
  %%physloc%%,
  *
FROM
  dbo.Ulocks;
