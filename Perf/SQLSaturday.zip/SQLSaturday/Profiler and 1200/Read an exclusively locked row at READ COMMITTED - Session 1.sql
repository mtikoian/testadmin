-- Read an exclusively locked row at READ COMMITTED - Session 1
-- Violate BOL "shared locks taken for read committed"

DBCC TRACEON(1200, -1);
DBCC TRACEON(3604);
GO

-- In thread 1

SET TRANSACTION ISOLATION LEVEL REPEATABLE READ;

BEGIN TRANSACTION;

SELECT * FROM dbo.ULocks WITH (XLOCK) WHERE ID = 4;

-- Verify the X lock
EXEC sp_lock @@SPID;

RETURN;

-- Go to thread 2


-- Dirty the page
ROLLBACK TRANSACTION;
BEGIN TRANSACTION;

UPDATE
  dbo.ULocks
SET
  VC = VC + ','
WHERE ID = 4;

EXEC sp_lock @@SPID; -- Same key X lock

RETURN;
-- Now try to read the row again on thread 2


-- Clean dirty pages
COMMIT TRANSACTION;
CHECKPOINT 1;
RETURN;

-- Now try thread 2 again

DBCC TRACEOFF(3604);
DBCC TRACEOFF(1200, -1);