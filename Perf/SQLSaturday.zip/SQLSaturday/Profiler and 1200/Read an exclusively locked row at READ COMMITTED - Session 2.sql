-- Read an exclusively locked row at READ COMMITTED - Session 2
DBCC TRACEON(1200, -1);
DBCC TRACEON(3604);
GO

SET TRANSACTION ISOLATION LEVEL READ COMMITTED;

SELECT * FROM dbo.ULocks WHERE ID = 4;

-- Try at repeatable read in an auto-commit transaction
SELECT * FROM dbo.ULocks WITH (REPEATABLEREAD) WHERE ID = 4;

RETURN;
-- Dirty the page using thread 1




-- Retry the read
SELECT * FROM dbo.ULocks WHERE ID = 4;

RETURN;




-- Commit the change in session 1 and checkpoint the DB
-- Retry the read against a clean page
SELECT * FROM dbo.ULocks WHERE ID = 4;


DBCC TRACEOFF(3604);
DBCC TRACEOFF(1200, -1);