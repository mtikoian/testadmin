-- When do U locks get used?

-- Update using a clustered index seek
-- Should see only key X locks
DBCC TRACEON(1200, -1);
DBCC TRACEON(3604);

BEGIN TRANSACTION;

UPDATE
  dbo.ULocks
SET
  VC = 'update via CLI seek'
WHERE
  ID = 2;

ROLLBACK TRANSACTION;

RETURN;



-- Update using a clustered index scan
-- Should IX table, IU page, U key
-- promoted to IX page, X key on matches
BEGIN TRANSACTION;

UPDATE
  dbo.ULocks
SET
  VC = 'update via CLI scan'
WHERE
  VC LIKE '3%'; -- third row

ROLLBACK TRANSACTION;
RETURN;


-- Update using a non-unique non-clustered index seek
-- Should see U lock on NCI and CLI, then X lock on CLI
BEGIN TRANSACTION;

UPDATE
  dbo.ULocks
SET
  VC = 'update via NCI'
WHERE
  NCI = 5; -- third row

/*
-- Replace the hobt_id below with the values in ObjectID2,
-- or KEY <file_id>:<hobt_id> from Messages window
select * from sys.partitions where hobt_id = 72057594038976512;
select * from sys.partitions where hobt_id = 72057594038910976;
*/

ROLLBACK TRANSACTION;

DBCC TRACEOFF(3604);
DBCC TRACEOFF(1200, -1);

