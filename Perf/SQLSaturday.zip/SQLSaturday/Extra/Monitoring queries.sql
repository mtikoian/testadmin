-- Monitoring session
DECLARE
  @spid1  smallint,
  @spid2  smallint;

SET @spid1 = X;
SET @spid2 = X;

EXEC sp_lock @spid1, @spid2;

-- Use DMV
SELECT * FROM sys.dm_tran_locks
WHERE request_session_id IN (@spid1, @spid2);

-- See internal lock info
SELECT * FROM sys.syslockinfo;


-- Oldest transaction holding up checkpoint
DBCC OPENTRAN;

-- Oldest running request per database
WITH CTE_RequestStartTimes AS
(
  SELECT
    database_id, session_id, start_time,
    ROW_NUMBER() OVER (PARTITION BY database_id ORDER BY start_time DESC) AS Rn
  FROM sys.dm_exec_requests
)
SELECT database_id, session_id, start_time
FROM CTE_RequestStartTimes
WHERE Rn = 1;

-- Idle sessions with open tran
SELECT *
FROM sys.sysprocesses AS sp
WHERE open_tran > 0 AND
  NOT EXISTS (SELECT 1 FROM sys.dm_exec_requests WHERE session_id = sp.spid);