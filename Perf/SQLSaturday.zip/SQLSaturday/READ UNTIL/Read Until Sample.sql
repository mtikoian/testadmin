CREATE TABLE dbo.WorkTable (
  WorkID        int   NOT NULL IDENTITY(1,1),
  WorkPayload   XML   NOT NULL,

  CONSTRAINT PK_WorkTable
    PRIMARY KEY CLUSTERED (WorkID)
);
GO

CREATE PROCEDURE dbo.ReadUntilExample
  @PreviousMaxWorkID  int,
  @BatchSize          int = 1000
AS
BEGIN

  SET NOCOUNT ON;
  SET TRANSACTION ISOLATION LEVEL REPEATABLE READ;
  SET LOCK_TIMEOUT 2000;

  DECLARE
    @Error_Number                 int,
    @MaxRequestID                 int,
    @SchemaLockDetectedIndicator  bit;

  BEGIN TRY

    -- Don't care about rolling these back
    DELETE FROM
      dbo.WorkTable WITH (ROWLOCK READPAST)
    WHERE
      WorkID <= @PreviousMaxWorkID;

    BEGIN TRANSACTION;

    -- Start: READ UNTIL pattern
    BEGIN TRY

      /*
        First pass to get max ID.
        Reads until an incompatible lock is found,
        or @BatchSize is reached,
        whichever occurs first.
        Note: Two passes required as @@ROWCOUNT = 0 if lock timeout error thrown.
      */
      SELECT TOP (@BatchSize)
        @MaxRequestID = WorkID
      FROM
        dbo.WorkTable WITH (REPEATABLEREAD ROWLOCK NOWAIT)
      WHERE
        WorkID > @PreviousMaxWorkID
      ORDER BY
        WorkID;

    END TRY
    BEGIN CATCH

      SET @Error_Number = ERROR_NUMBER();

      IF @Error_Number <> 1222 OR XACT_STATE() = -1
        BEGIN
          IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION;

          EXEC dbo.LogAndRethrowError ...;

        END
      ELSE IF @Error_Number = 1222 AND @MaxRequestID IS NULL
        BEGIN

          -- Set the signalling bit to be used by the outer catch block.
          SET @SchemaLockDetectedIndicator = 1;

          /*
            Do a dummy select to try to get a Sch-S lock. If this fails, we
            have a good idea why the lock timed out in the first pass.
            There is a micro-race between the first pass and here, but it is not material.
          */
          SELECT
            @MaxRequestID = WorkID
          FROM
            dbo.WorkTable WITH (NOLOCK) -- Still going get a Sch-S lock requested
          WHERE
            1 = 0;

          /*
            Reset the signalling bit. It was most likely not a schema S lock block,
            but rather the first available row was locked.
            The second pass SELECT below will return an empty result set.
          */
          SET @SchemaLockDetectedIndicator = 0;

        END

      -- ELSE @Error_Number = 1222 AND @MaxRequestTimestamp IS NOT NULL
      -- We have our READ UNTIL range ready for the second pass.

    END CATCH

    SELECT
      WorkID,
      WorkPayload
    FROM
      dbo.WorkTable WITH (NOLOCK) -- We have the Sch-S and row S locks from above. No need to reaquire.
    WHERE
      WorkID > @PreviousMaxWorkID AND
      WorkID <= @MaxRequestID
    ORDER BY
      WorkID;

    -- End: READ UNTIL pattern

    COMMIT TRANSACTION;

  END TRY
  BEGIN CATCH
    IF @@TRANCOUNT > 0
      ROLLBACK TRANSACTION;

    -- Optionally check @SchemaLockDetectedIndicator and attempt a retry

    EXEC dbo.LogAndRethrowError ...;

  END CATCH

  RETURN 0;

END
GO


