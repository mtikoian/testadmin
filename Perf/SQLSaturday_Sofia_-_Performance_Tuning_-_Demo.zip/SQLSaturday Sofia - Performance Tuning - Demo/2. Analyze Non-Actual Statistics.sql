USE AdventureWorks2012;
GO

UPDATE STATISTICS dbo.bigTransactionHistory3
GO

SET STATISTICS IO ON
GO

SELECT TOP(200000) p.* FROM dbo.bigTransactionHistory3 t
INNER JOIN dbo.bigProduct p
	ON t.ProductID = p.ProductID 
WHERE t.TransactionDate = '01-01-2013'
OPTION (RECOMPILE)
GO
