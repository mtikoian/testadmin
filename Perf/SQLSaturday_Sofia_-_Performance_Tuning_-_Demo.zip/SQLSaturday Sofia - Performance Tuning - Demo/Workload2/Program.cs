﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Workload2
{
    class Program
    {
        static void Main(string[] args)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["AdventureWorks"].ConnectionString;

            // Dynamic SQL
            SqlConnection connection = new SqlConnection(connectionString);
            using (connection)
            {
                int maxIdForExecution = 1000;
                int id = 1;
                connection.Open();
                while (id <= maxIdForExecution)
                {
                    SqlCommand command = new SqlCommand("dbo.GetTransactionHistoryById", connection);
                    command.Parameters.AddWithValue("@Id", id);
                    command.CommandType = CommandType.StoredProcedure;
                    var list = new List<object>();
                    var reader = command.ExecuteReader();
                    while (reader.Read())
                    {

                    }
                    reader.Close();

                    id++;
                }
            }
        }
    }
}
