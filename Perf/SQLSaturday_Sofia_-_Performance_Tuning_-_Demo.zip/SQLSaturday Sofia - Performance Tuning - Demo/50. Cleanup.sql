USE StackOverflow_Old
GO

IF EXISTS (SELECT OBJECT_ID('GetDate', 'FN'))
	DROP FUNCTION GetDate
GO

