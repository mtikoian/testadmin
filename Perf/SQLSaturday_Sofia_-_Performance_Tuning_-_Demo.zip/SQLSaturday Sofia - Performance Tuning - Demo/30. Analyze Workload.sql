USE Profiler
GO

SELECT TextData, Duration / 1000000 AS [Duration (sec)], CPU, Reads, RowCounts FROM XXX
ORDER BY Duration DESC

SELECT TextData, Duration / 1000000 AS [Duration (sec)], CPU, Reads, RowCounts FROM XXX
ORDER BY Reads DESC

SELECT SUBSTRING(TextData, 0, 40) AS Query, COUNT(*) AS ExecutionCount
	, SUM(Duration)  / 1000000 AS [Duration (sec)], SUM(CPU) AS CPU, SUM(Reads) AS Reads
	, MIN(RowNumber) AS FirstQueryRowNumber 
FROM XXX
GROUP BY SUBSTRING(TextData, 0, 40)
ORDER BY SUM(Duration) DESC


SELECT SUBSTRING(TextData, 0, 40) AS Query, COUNT(*) AS ExecutionCount
	, SUM(Duration)  / 1000000 AS [Duration (sec)], SUM(CPU) AS CPU, SUM(Reads) AS Reads
	, MIN(RowNumber) AS FirstQueryRowNumber 
FROM XXX
GROUP BY SUBSTRING(TextData, 0, 40)
ORDER BY SUM(Reads) DESC

SELECT * FROM test WHERE RowNumber = XX

