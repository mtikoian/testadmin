USE StackOverflow_Old
GO

ALTER TABLE Users 
	ADD LocationReversed AS REVERSE(Location) PERSISTED
GO

CREATE INDEX IX_USERS_LOCATIONREVERSED
	ON Users(LocationReversed)
	INCLUDE (Reputation, CreationDate)
GO

DROP INDEX IX_USERS_LOCATIONREVERSED ON Users(LocationReversed)
GO

-- Speaker Tip: Include Time Statistics

ALTER TABLE Users
	ADD LocationBinary AS Location COLLATE Latin1_General_BIN2 PERSISTED
GO

SELECT Id FROM Users WHERE Location LIKE '%Bulgaria%'
OPTION (MAXDOP 1)

SELECT Id FROM Users WHERE LocationBinary LIKE '%Bulgaria%'
OPTION (MAXDOP 1)

-- Cleanup
DROP INDEX IX_USERS_LOCATIONREVERSED ON Users
GO

ALTER TABLE Users 
	DROP COLUMN LocationReversed
GO

ALTER TABLE Users 
	DROP COLUMN LocationBinary
GO

