Use AdventureWorksDW2014;

-- Try the parallel plan
Select COUNT(*)
From dbo.FactProductInventory
Where MovementDate > '2011-1-1';

-- Try the parallel plan with MaxDOP 8
Select COUNT(*)
From dbo.FactProductInventory
Where MovementDate > '2011-1-1'
Option(MaxDOP 8);




-- Try the parallel plan with MaxDOP 1
Select COUNT(*)
From dbo.FactProductInventory
Where MovementDate > '2011-1-1'
Option(MaxDOP 1);