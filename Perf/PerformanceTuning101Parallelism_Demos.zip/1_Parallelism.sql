Use AdventureWorksDW2014;

-- How big is it?
Select rows
From sys.partitions
Where object_id = OBJECT_ID('dbo.FactProductInventory');

-- Let's look at a parallel plan
Select COUNT(*)
From dbo.FactProductInventory
Where MovementDate > '2011-1-1';
-- 104.647

-- Let's force a serial plan
Select COUNT(*)
From dbo.FactProductInventory
Where MovementDate > '2011-1-1'
Option (MaxDOP 1);
-- 145.187

-- To what is Cost threshold for parallelism set?
Exec sp_configure 'show advanced options', 1;
Reconfigure;
Exec sp_configure 'cost threshold for parallelism';
Exec sp_configure 'max degree of parallelism';

-- Pump up the jam to 150
Exec sp_configure 'Cost threshold for parallelism', 150;
Reconfigure;

-- Try the parallel plan again
Select COUNT(*)
From dbo.FactProductInventory
Where MovementDate > '2011-1-1';

-- Pump down the jam to 135
Exec sp_configure 'Cost threshold for parallelism', 135;
Reconfigure;

-- Try the parallel plan again
Select COUNT(*)
From dbo.FactProductInventory
Where MovementDate > '2011-1-1';

-- User complains that the query is slower for him than anyone else
Execute As User = 'SerialUser';

-- Try the parallel plan again
Select COUNT(*)
From dbo.FactProductInventory
Where MovementDate > '2011-1-1';

Revert;

-- So the user decides to show you

-- Maybe the user is being restricted by Resource Governor
Select sess.session_id,
	sess.login_name,
	grps.name,
	grps.max_dop,
	grps.effective_max_dop
From sys.dm_exec_sessions As sess 
Inner Join sys.dm_resource_governor_workload_groups As grps 
    On sess.group_id = grps.group_id
Where session_id = ;

-- Clean-up
-- Pump down the jam to default of 5
Exec sp_configure 'Cost threshold for parallelism', 5;
Reconfigure;

-- Set workgroup back to MaxDOP 1
Alter Workload Group SerialGroup With(max_dop = 1);
Alter Resource Governor Reconfigure;
