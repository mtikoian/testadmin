use Credit
GO
set Statistics IO On 
set statistics time on
-- how bad is select * 
select  * From charge  
where charge_dt between '1999-06-15 10:45:07.223'
and '1999-07-15 10:45:07.223'

select  member_no,
provider_no From charge  
where charge_dt between '1999-06-15 10:45:07.223'
and '1999-07-15 10:45:07.223'

/*
SQL Server parse and compile time: 
   CPU time = 1 ms, elapsed time = 1 ms.
SQL Server parse and compile time: 
   CPU time = 0 ms, elapsed time = 0 ms.

(388064 row(s) affected)
Table 'charge'. Scan count 9, logical reads 9453, physical reads 0, read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.

 SQL Server Execution Times:
   CPU time = 375 ms,  elapsed time = 3200 ms.
*/


select  member_no,
provider_no From charge  
where charge_dt between '1999-06-15 10:45:07.223'
and '1999-07-15 10:45:07.223'
/*
SQL Server parse and compile time: 
   CPU time = 0 ms, elapsed time = 1 ms.
SQL Server parse and compile time: 
   CPU time = 0 ms, elapsed time = 0 ms.

(388064 row(s) affected)
Table 'charge'. Scan count 9, logical reads 9433, physical reads 0, read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.

 SQL Server Execution Times:
   CPU time = 311 ms,  elapsed time = 2345 ms.
*/
/*
(388064 row(s) affected)
Table 'charge'. Scan count 9, logical reads 9453, physical reads 0, read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.
(388064 row(s) affected)
Table 'charge'. Scan count 9, logical reads 9433, physical reads 0, read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.
--same IO
*/

--look at execution plan
--point out green suggested index
select  member_no,
provider_no From charge  
where charge_dt between '1999-06-15 10:45:07.223'
and '1999-07-15 10:45:07.223'
/*
--eads 
9433,
1255 
CREATE NONCLUSTERED INDEX charge_1_a
ON [dbo].[charge] ([charge_dt])
INCLUDE ([member_no],[provider_no])
GO
*/
/*

(388064 row(s) affected)
Table 'charge'. Scan count 1, logical reads 1255, physical reads 0, read-ahead reads 10, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.

 SQL Server Execution Times:
   CPU time = 31 ms,  elapsed time = 2382 ms.

 now 2.8 seconds (down from 3741)
 1255 IOs down from 9454
  
*/

