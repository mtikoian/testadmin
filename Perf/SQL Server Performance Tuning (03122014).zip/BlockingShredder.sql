use master
GO
set QUOTED_IDENTIFIER ON
declare @holder table (pk int identity, alerttime datetime, xmlcol xml)
insert into @holder(alerttime, Xmlcol)
SELECT  top 1000  alerttime, BlockedReport Data FROM blockedevents
--where alerttime>dateadd(mi,-5,getdate())
order by alerttime desc
declare @Holding1 table (
	[alerttime] [datetime] NULL,
	[Blocked Process HostName] [sysname] NULL,
	[Blocked Process Login] [sysname] NULL,
	[Blocked Process Transaction Started] datetime  NULL,
	[Blocked] [varchar](max) NULL,
	[Blocking Process HostName] [sysname] NULL,
	[Blocking Process Login] [sysname] NULL,
	[Blocking] [varchar](max) NULL,
	[Blocking Process Transaction Started] datetime NULL
) 
--insert into @holding1
 SELECT t.alerttime,
t.xmlcol.value('(/TextData/blocked-process-report/blocked-process/process/@hostname)[1]','sysname')[Blocked Process HostName],
t.xmlcol.value('(/TextData/blocked-process-report/blocked-process/process/@loginname)[1]','sysname')[Blocked Process Login],
t.xmlcol.value('(/TextData/blocked-process-report/blocked-process/process/@lasttranstarted)[1]','datetime')[Blocked Process Transaction Started],
convert(varchar(max), t.xmlcol.query('data(/TextData/blocked-process-report/blocked-process/process/inputbuf)')) as Blocked,
t.xmlcol.value('(/TextData/blocked-process-report/blocking-process/process/@hostname)[1]','sysname')[Blocking Process HostName],
t.xmlcol.value('(/TextData/blocked-process-report/blocking-process/process/@loginname)[1]','sysname') [Blocking Process Login],
convert(varchar(max), t.xmlcol.query('data(/TextData/blocked-process-report/blocking-process/process/inputbuf)')) as Blocking,
t.xmlcol.value('(/TextData/blocked-process-report/blocking-process/process/@lastbatchstarted)[1]','datetime')[Blocking Process Transaction Started],
t.xmlcol.value('(/TextData/blocked-process-report/blocking-process/process/@currentdb)[1]','int')  
from @holder t
where t.xmlcol.value('(/TextData/blocked-process-report/blocking-process/process/@currentdb)[1]','int')  >4
order by 1 
 