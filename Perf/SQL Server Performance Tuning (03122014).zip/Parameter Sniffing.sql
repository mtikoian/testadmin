/*
from http://www.simple-talk.com/sql/t-sql-programming/parameter-sniffing/
*/
/*
create database ParameterSniffing

use ParameterSniffing
GO
SET NOCOUNT ON;
if exists(select * from sys.objects where name='BillingInfo' and type='u')
DROP TABLE BillingInfo;
CREATE TABLE BillingInfo(
ID INT IDENTITY,
BillingDate DATETIME,
BillingAmt MONEY,
BillingDesc varchar(500));
 

DECLARE @I INT;
DECLARE @BD INT;
SET @I = 0;
WHILE @I < 1000000
BEGIN
  SET @I = @I + 1;
  SET @BD=CAST(RAND()*10000 AS INT)%3650;
  INSERT BillingInfo (BillingDate, BillingAmt)
  VALUES (DATEADD(DD,@BD,
    CAST('1999/01/01' AS DATETIME)),
    RAND()*5000);
END

ALTER TABLE BillingInfo
ADD  CONSTRAINT [PK_BillingInfo_ID]
PRIMARY KEY CLUSTERED (ID);
GO
CREATE NONCLUSTERED INDEX IX_BillingDate
ON dbo.BillingInfo(BillingDate);

*/
/*
CREATE PROC [dbo].[DisplayBillingInfo]
  @BeginDate DATETIME,
  @EndDate DATETIME
AS
SELECT BillingDate, BillingAmt
  FROM BillingInfo
  WHERE BillingDate between @BeginDate AND @EndDate; 
GO
*/
SET STATISTICS IO ON;

DBCC FREEPROCCACHE;
--this will flush all execution plans
--year date range done first 
--3599,
EXEC dbo.DisplayBillingInfo @BeginDate = '1999-01-01', 
@EndDate  = '1999-12-31'; 
--Table 'BillingInfo'. Scan count 1, logical reads 3600, physical reads 0, read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.
set statistics io on 
--3599 year
--3599, 2 days
 
--Table 'BillingInfo'. Scan count 1, logical reads 3600, physical reads 0, read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.
EXEC dbo.DisplayBillingInfo @BeginDate = '2005-01-01', 
@EndDate  = '2005-01-03';

--same number of pages

DBCC FREEPROCCACHE;
--this will flush all execution plans
--2 day range done first 
EXEC dbo.DisplayBillingInfo @BeginDate = '2005-01-01', 
@EndDate  = '2005-01-03';
--Table 'BillingInfo'. Scan count 1, logical reads 2820, physical reads 0, read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.


EXEC dbo.DisplayBillingInfo @BeginDate = '1999-01-01', 
@EndDate  = '1999-12-31'; 
 
--Table 'BillingInfo'. Scan count 1, logical reads 335404,, physical reads 0, read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.
--note an astounding 335,815 pages are scanned

--solution  
sp_helptext DisplayBillingInfo 
GO

CREATE PROC [dbo].[DisplayBillingInfoNEW]
  @BeginDate DATETIME,
  @EndDate DATETIME
AS
declare @BeginDateTemp datetime
declare @EndDateTemp datetime
set  @BeginDateTemp = @BeginDate
set  @EndDateTemp = @EndDate
SELECT BillingDate, BillingAmt
FROM BillingInfo
WHERE BillingDate between @BeginDateTemp AND @EndDateTemp; 

GO

EXEC dbo.DisplayBillingInfoNEW @BeginDate = '2005-01-01', 
@EndDate  = '2005-01-03';
--Table 'BillingInfo'. Scan count 1, logical reads 3600, physical reads 0, read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.


EXEC dbo.DisplayBillingInfoNEW @BeginDate = '1999-01-01', 
@EndDate  = '1999-12-31'; 
 --Table 'BillingInfo'. Scan count 1, logical reads 3600, physical reads 0, read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.
DBCC FREEPROCCACHE
GO

EXEC dbo.DisplayBillingInfoNEW @BeginDate = '1999-01-01', 
@EndDate  = '1999-12-31'; 
 --Table 'BillingInfo'. Scan count 1, logical reads 3600, physical reads 0, read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.
EXEC dbo.DisplayBillingInfoNEW @BeginDate = '2005-01-01', 
@EndDate  = '2005-01-03';
--Table 'BillingInfo'. Scan count 1, logical reads 3600, physical reads 0, read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.

