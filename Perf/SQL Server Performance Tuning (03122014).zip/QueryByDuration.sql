use master
GO
select textdata, applicationName,duration From creditcard 
where applicationname not like 'DatabaseMail%' 
and applicationname not like 'SQLAgent%'  
and applicationname not like 'Microsoft SQL Server Management Studio%'
and applicationname not like 'Microsoft� Windows� Operating System%'
and applicationname not like 'SQL Server Log Shipping%'
order by duration desc