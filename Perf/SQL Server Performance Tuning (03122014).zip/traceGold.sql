declare @rc int
declare @count int
declare @on bit
set @on=1
declare @TraceID int
declare @iEventID int
declare @iColID int
declare @iColIDMax int
declare @maxfilesize bigint
set @maxfilesize = 250				--	An optimal size for tracing and handling the files
declare @stopat datetime
set @stopat=dateadd(mi,40,getdate())

exec sp_trace_create @TraceID output, 2 , N'c:\temp\Santanu', @maxfilesize, @stopat
declare @strVersion varchar(10)

declare @table table(pk int identity, iEventID int)
insert into @table(iEventID) values(10)
insert into @table(iEventID) values(11)
insert into @table(iEventID) values(12)
insert into @table(iEventID) values(13)
insert into @table(iEventID) values(14)
insert into @table(iEventID) values(15)
insert into @table(iEventID) values(16)
insert into @table(iEventID) values(17)
insert into @table(iEventID) values(19)
insert into @table(iEventID) values(22)
insert into @table(iEventID) values(25)
insert into @table(iEventID) values(27)
insert into @table(iEventID) values(28)
insert into @table(iEventID) values(33)
insert into @table(iEventID) values(34)
insert into @table(iEventID) values(37)
insert into @table(iEventID) values(39)
insert into @table(iEventID) values(40)
insert into @table(iEventID) values(41)
insert into @table(iEventID) values(44)
insert into @table(iEventID) values(45)
insert into @table(iEventID) values(50)
insert into @table(iEventID) values(53)
insert into @table(iEventID) values(55)
insert into @table(iEventID) values(58)
insert into @table(iEventID) values(60)
insert into @table(iEventID) values(67)
insert into @table(iEventID) values(69)
insert into @table(iEventID) values(70)
insert into @table(iEventID) values(71)
insert into @table(iEventID) values(73)
insert into @table(iEventID) values(74)
insert into @table(iEventID) values(76)
insert into @table(iEventID) values(77)
insert into @table(iEventID) values(78)
insert into @table(iEventID) values(79)
insert into @table(iEventID) values(80)
insert into @table(iEventID) values(81)
insert into @table(iEventID) values(92)
insert into @table(iEventID) values(93)
insert into @table(iEventID) values(98)
insert into @table(iEventID) values(100)
insert into @table(iEventID) values(116)
insert into @table(iEventID) values(125)
insert into @table(iEventID) values(126)
insert into @table(iEventID) values(127)
insert into @table(iEventID) values(137)
insert into @table(iEventID) values(150)
insert into @table(iEventID) values(166)
insert into @table(iEventID) values(181)
insert into @table(iEventID) values(182)
insert into @table(iEventID) values(183)
insert into @table(iEventID) values(184)
insert into @table(iEventID) values(185)
insert into @table(iEventID) values(186)
insert into @table(iEventID) values(187)
insert into @table(iEventID) values(188)
insert into @table(iEventID) values(191)
insert into @table(iEventID) values(192)
insert into @table(iEventID) values(196)
select @count=count(*) from @table
declare @counter int
set @counter=1
while @counter<@count
begin
	select @iEventID=iEventID from @table where pk=@counter

	set @iColID = 1
	set @iColIDMax = 64

	while(@iColID <= @iColIDMax)
	begin
		exec sp_trace_setevent @TraceID, @iEventID, @iColID, @on
		set @iColID = @iColID + 1
	end
	select @counter=@counter+1
end	

set @on=0

exec sp_trace_setevent @TraceID, 10, 1, @on		--		No Text for RPC, only Binary for performance
exec sp_trace_setevent @TraceID, 11, 1, @on		--		No Text for RPC, only Binary for performance

exec sp_trace_setfilter @TraceID, 10, 0, 7, N'SQL Server Profiler - 9e792bf2-2b1a-4489-9868-687a97e99007'
exec sp_trace_setfilter @TraceID, 35, 0, 6, N'test4'



-- Set the trace status to start
exec sp_trace_setstatus @TraceID, 1
 

/*
select * From sys.traces
exec sp_trace_setstatus 2, 0
exec sp_trace_setstatus 2, 2
*/
 