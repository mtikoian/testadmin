EXEC dbo.sp_WhoIsActive
@get_transaction_info=0,
@output_column_list ='[session_id][start_time]
                  [cpu][status][context_switches][wait_info][program_name]
                 [database_name][sql_text][host_name][open_tran_count]', 
@sort_column ='[CPU]'

GO
EXEC dbo.sp_WhoIsActive
@delta_interval=60, @output_column_list ='[session_id][start_time][context switches]
                  [CPU_delta][reads_delta][writes_delta][tempdb_writes_delta]
                  [tempdb_reads_delta][tempdb_current_delta]
                  [database_name][host_name][login_name]', 
@sort_column='[CPU_delta]'
--GO
--EXEC sp_WhoIsActive
--        @OUTPUT_COLUMN_LIST =
--            '[login_name],[dd hh:mm:ss.mss],[sql_text],[reads],[writes],
--            [context_switches],[physical_io],[wait_info],[blocking_session_id],
--            [tempdb_writes],[tran_log_writes],[query_plan],[session_id]';

--GO  