--:CONNECT SQLHAMMERLAPTOP\SQL2014

USE master

IF EXISTS (SELECT * FROM sys.databases WHERE name = 'AdventureWorks2014_clone')
BEGIN
	ALTER DATABASE AdventureWorks2014_clone SET SINGLE_USER WITH ROLLBACK IMMEDIATE
	DROP DATABASE AdventureWorks2014_clone
END

--1-x-OPTIMIZER_WHATIF.sql
DBCC OPTIMIZER_WHATIF(1, 0);
DBCC OPTIMIZER_WHATIF(2, 0);
DBCC OPTIMIZER_WHATIF(3, 0);

EXEC sp_configure 'show', 1
RECONFIGURE
EXEC sp_configure 'cost threshold', 5
RECONFIGURE

/***************************************************/

USE AdventureWorks2014_clone
GO

--2-Sorts.sql
IF EXISTS (	SELECT * 
			FROM sys.indexes 
			WHERE name = 'IX_Person_LastName_FirstName_MiddleName_test')
BEGIN
	DROP INDEX [IX_Person_LastName_FirstName_MiddleName_test] 
	ON [Person].[Person]
END
IF EXISTS (	SELECT * 
			FROM sys.indexes 
			WHERE name = 'IX_SalesOrderHeader_CustomerID')
BEGIN
	DROP INDEX [IX_SalesOrderHeader_CustomerID] 
	ON [Sales].[SalesOrderHeader]
END

--3-Residual-Predicates.sql
IF EXISTS (	SELECT * 
			FROM sys.indexes 
			WHERE name = 'IX_TransactionHistory_ReferenceOrderID_Quantity')
BEGIN
	DROP INDEX [IX_TransactionHistory_ReferenceOrderID_Quantity] 
	ON [Production].[TransactionHistory]
END

