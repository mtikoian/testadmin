
USE AdventureWorks2014_clone
GO

/*
Key columns out of order
*/

/*
Expected result:
Index seek with a residual predicate,
even though both predicate columns are in the index
IX_TransactionHistory_ReferenceOrderID_ReferenceOrderLineID_Quantity
*/

SELECT [ReferenceOrderID]
	,Quantity
FROM [Production].[TransactionHistory]
WHERE Quantity = 50
	AND [ReferenceOrderID] = 10000
OPTION (RECOMPILE)

/*
Solution:
Create a covering index.
*/

CREATE INDEX IX_TransactionHistory_ReferenceOrderID_Quantity
ON [Production].[TransactionHistory] ([ReferenceOrderID],[Quantity])

SELECT [ReferenceOrderID]
	,Quantity
FROM [Production].[TransactionHistory]
WHERE Quantity = 50
	AND [ReferenceOrderID] = 10000
OPTION (RECOMPILE)

/*
It gets worse...
MERGE JOIN residuals
*/

/*
Expected result:
MERGE JOIN with a residual predicate hidden in the properties.
*/

SELECT s.Name, COUNT(*) 
FROM Production.ProductSubcategory s 
INNER MERGE JOIN Production.Product p 
ON s.ProductSubcategoryID = p.ProductSubcategoryID 
WHERE RIGHT(p.Name, LEN(s.Name)) = 'blah' 
GROUP BY s.Name;

/*
[AdventureWorks2014_clone].[Production].[Product].[ProductSubcategoryID] as 
[p].[ProductSubcategoryID]=[AdventureWorks2014_clone].[Production].[ProductSubcategory].
	[ProductSubcategoryID] as [s].[ProductSubcategoryID] AND 
right([AdventureWorks2014_clone].[Production].[Product].[Name] as [p].[Name],[Expr1003])=N'blah'
*/

/*
Solution:
SARGability (Functions on col side of predicate), which is out of scope for this presentation.
*/

/*
HASH MATCH is only a little better
*/

/*
Expected result:
HASH MATCH with a probe residual
*/

SELECT p1.ProductID 
FROM Production.Product p1 
INNER JOIN Production.Product p2 
	ON p1.ProductSubcategoryID = p2.ProductSubcategoryID 
		AND p1.ListPrice - p2.ListPrice = 0

/*
Solution:
SARGability (aggregate on col side of predicate), which is out of scope for this presentation.
*/
