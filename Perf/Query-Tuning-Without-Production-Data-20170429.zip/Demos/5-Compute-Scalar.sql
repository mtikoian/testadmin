
/*
Compute Scalars
*/

USE [AdventureWorks2014_clone]
GO

/*
Example of a cheap compute scalar.
*/

/*
Expected result:
Stream aggregate and compute scalar due to convertion of BIGINT to INT.

[Expr1002] = Scalar Operator(CONVERT_IMPLICIT(int,[Expr1003],0))
*/

SELECT COUNT(*)
FROM Person.Person

/*
Expected result:
Stream aggregate without a compute scalar.
*/

SELECT COUNT_BIG(*)
FROM Person.Person

/*
Expensive compute scalars
*/

/*
Expected results:
Compute scalar cost = 0.0000013
Actual UDF cost = 26.92
That is over 20,000 times more expensive than advertised
and the difference between a parallel and serial plan (with defaults).
*/

SELECT dbo.ufnGetProductsSoldThisMonth()

/*
We didn't get a parallel plan because a query
cost of 0.0000013 is too low.

Or maybe it was for more than one reason...
*/

EXEC sp_configure 'show', 1
RECONFIGURE
EXEC sp_configure 'cost threshold'

SELECT dbo.ufnGetProductsSoldThisMonth()
FROM sys.columns c1, sys.columns c2 --Arbitrarily enhancing our query cost
OPTION (RECOMPILE)

/*
We didn't get a parallel plan even though our 
cost threshold for parallism is 5 and the query cost is 12.86.
*/

/*
Solution:
Do not use UDFs.
There are only a few types of functions which can 
take advantage of the better optimizer features,
such as predicate push down and plan simplification.
(Inline Table-Valued Functions).
*/
