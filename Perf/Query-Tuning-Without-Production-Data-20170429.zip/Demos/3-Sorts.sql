
/*
ORDER BY SORT
*/

USE AdventureWorks2014_clone
GO

/*
Expecting:
Clustered Index Scan on [AdventureWorks2014_clone].[Person].[Person].[PK_Person_BusinessEntityID]
Sort
*/

select LastName, FirstName, MiddleName
	,NameStyle
from [Person].[Person]
ORDER BY lastname DESC
OPTION (RECOMPILE)

/*
Solution:
Do not order by.
If you have to, try to make SQL Server read pre-sorted data.
Why is it not using the [IX_Person_LastName_FirstName_MiddleName] index?
*/

select LastName, FirstName, MiddleName
	,NameStyle
from [Person].[Person] WITH (INDEX (IX_Person_LastName_FirstName_MiddleName))
ORDER BY lastname DESC
OPTION (RECOMPILE)

/*
Let's stop bossing the optimizer around now.
Add the NameStyle column to your index.
*/
/*
IMPORTANT NOTE:
You would drop and create the index with the new columns when you go to 
production but you don't want to do that while testing because you will
loose your production statistics.
*/
/*
Expected result:
Index scan on [IX_Person_LastName_FirstName_MiddleName_test]
Scan direction: BACKWARDS
No sort
*/

CREATE NONCLUSTERED INDEX [IX_Person_LastName_FirstName_MiddleName_test] ON [Person].[Person]
(
	[LastName] ASC,
	[FirstName] ASC,
	[MiddleName] ASC
)
INCLUDE
(
	[NameStyle]
)
WITH (DROP_EXISTING = OFF, PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

select LastName, FirstName, MiddleName
	,NameStyle
from [Person].[Person] 
ORDER BY lastname DESC
OPTION (RECOMPILE)

/***************************************************/

/*
STREAM AGGREGATE SORT
*/

/*
Expected results:
MERGE JOIN with a SORT on one branch
JOIN hint for demonstration only, do not use in production.
*/

SELECT C.CustomerID, OH.SalesOrderID
FROM Sales.SalesOrderHeader AS OH
INNER MERGE JOIN Sales.Customer AS C ON OH.CustomerID = C.CustomerID
OPTION (RECOMPILE)

/*
Solution:
Pre-sort the data set with an index
*/

CREATE NONCLUSTERED INDEX [IX_SalesOrderHeader_CustomerID] 
ON [Sales].[SalesOrderHeader] ( [CustomerID] ASC )

/*
Expected results:
MERGE JOIN without any SORTS
*/

SELECT C.CustomerID, OH.SalesOrderID
FROM Sales.SalesOrderHeader AS OH
INNER MERGE JOIN Sales.Customer AS C ON OH.CustomerID = C.CustomerID
OPTION (RECOMPILE)
