--:CONNECT SQLHAMMERLAPTOP\SQL2014

/*
What is OPTIMIZER_WHATIF and how do we use it?
*/

/**************************************
 !!!   UNDOCUMENTED DBCC COMMAND    !!!
 !!!    UNSUPPORTED MY MICROSOFT    !!!
 !!! DO NOT USE IN PRODUCTION, EVER !!!
***************************************/

DBCC TRACEON (2588) WITH NO_INFOMSGS -- TF to enable help to undocumented commands
DBCC HELP ('OPTIMIZER_WHATIF') WITH NO_INFOMSGS -- DBCC help
 
DBCC TRACEON(3604) WITH NO_INFOMSGS -- TF to send output results to console
DBCC OPTIMIZER_WHATIF(0) WITH NO_INFOMSGS; -- Current and valid values

/*
Example: session scoped
*/

--Spoof 16 cores
DBCC OPTIMIZER_WHATIF(CPUs, 16);
-- Set ammount of memory in MB, in this case 512GB
DBCC OPTIMIZER_WHATIF(MemoryMBs, 524288);
-- Set to 64 bit system
DBCC OPTIMIZER_WHATIF(Bits, 64);

/*
Verify success:
Current_value should be updated from 0s to specified values.
*/

DBCC TRACEON(3604) WITH NO_INFOMSGS -- TF to send output results to console
DBCC OPTIMIZER_WHATIF(0) WITH NO_INFOMSGS; -- Current and valid values

/*
Revert: 0s for properties 1-3 indicate auto-detect.
*/

DBCC OPTIMIZER_WHATIF(1, 0);
DBCC OPTIMIZER_WHATIF(2, 0);
DBCC OPTIMIZER_WHATIF(3, 0);

/*
OR
*/

DBCC OPTIMIZER_WHATIF(RESET);

