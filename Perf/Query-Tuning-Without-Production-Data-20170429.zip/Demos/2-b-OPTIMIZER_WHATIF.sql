--:CONNECT SQLHAMMERLAPTOP\SQL2014

USE [AdventureWorks2014_clone]

/*
Expected result:
Parallel plan
With enough memory for table spool for rewinds
Nested loops with a no join predicate warning
*/

--Spoof 16 cores
DBCC OPTIMIZER_WHATIF(1, 16);
-- Set ammount of memory in MB, in this case 512GB
DBCC OPTIMIZER_WHATIF(2, 524288);
-- Set to 64 bit system
DBCC OPTIMIZER_WHATIF(3, 64);
GO


SELECT *
FROM [Person].[Person] p1
CROSS APPLY [Person].[Person] p2 
ORDER BY p1.FirstName, p2.FirstName
OPTION (RECOMPILE)


/*
Expected result:
Serial plan
No table spool
Nested loops because there is no join predicate.
*/

--Spoof 1 core
DBCC OPTIMIZER_WHATIF(1, 1);
-- Set ammount of memory in MB
DBCC OPTIMIZER_WHATIF(2, 512);
-- Set to 64 bit system
DBCC OPTIMIZER_WHATIF(3, 64);
GO


SELECT *
FROM [Person].[Person] p1
CROSS APPLY [Person].[Person] p2
ORDER BY p1.FirstName, p2.FirstName
OPTION (RECOMPILE) --Demostration purposes only.
GO

