--:CONNECT SQLHAMMERLAPTOP\SQL2014

/*
I'll buy you a beer if you know 
why this has a residual predicate and
we cannot do anything about it...

and that is OK.
*/

USE AdventureWorks2014_clone
GO


SELECT TransactionID
	,Quantity
FROM [Production].[TransactionHistory]
WHERE Quantity = 50
	AND TransactionID = 10000
OPTION (RECOMPILE)































/* PK on TransactionID so it will never scan more than 1 row */


