
/*
Nasty Inner Loop
*/

USE AdventureWorks2014_clone
GO

/*
Clean up from previous demo
*/

IF EXISTS (	SELECT * 
			FROM sys.indexes 
			WHERE name = 'IX_SalesOrderHeader_CustomerID')
BEGIN
	DROP INDEX [IX_SalesOrderHeader_CustomerID] 
	ON [Sales].[SalesOrderHeader]
END

/*
Expected Results:
Long SalesOrderHistory branch.
Nest loop with a cost of 365.
*/

SELECT BusinessEntityID, AVG(h.TotalDue) TotalDue
FROM Person.Person p
INNER LOOP JOIN 
(
	SELECT CustomerID, TotalDue
	FROM Sales.SalesOrderHeader h1
	INNER JOIN Sales.SalesOrderDetail d1 ON d1.SalesOrderID = h1.SalesOrderID
	INNER JOIN Sales.SalesOrderHeaderSalesReason r1 ON r1.SalesOrderID = h1.SalesOrderID
)  h ON h.CustomerID = p.BusinessEntityID
WHERE BusinessEntityID > 13347
GROUP BY BusinessEntityID
OPTION (RECOMPILE)

/*
Nested Loops due to Parameter Sniffing
*/

--DO NOT RUN THIS IN PRODUCTION, EVER!
DBCC FREEPROCCACHE()

/*
Expected results:
Three seeks.
Two nested loops.
A good plan for 3 shops!
*/

--You have to execute this before showing the plan to cache it.
EXEC dbo.GetShopsByInvestmentGroupId 57030015 --3 shops

--Take a look at the number of shops estimated 
--from the [dbo].[InvestmentGroupShop].IX_InvestmentGroupShop_investmentGroupId statistics.

/*
Expected results:
Same cached results.
Not a good plan for 1003 shops!
*/

EXEC dbo.GetShopsByInvestmentGroupId 57030010 --1003 shops

--Take a look at the number of shops estimated 
--from the [dbo].[InvestmentGroupShop].IX_InvestmentGroupShop_investmentGroupId statistics.

--I REPEAT; DO NOT RUN THIS IN PRODUCTION, EVER!
DBCC FREEPROCCACHE()

/*
Expected results:
Nested loop because we are pulling the investment group by a specific id.
Hash match to pull the shops and bridge table together.
*/

EXEC dbo.GetShopsByInvestmentGroupId 57030010 --1003 shops

