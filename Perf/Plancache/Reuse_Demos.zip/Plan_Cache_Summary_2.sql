/*--  
	 DBCC FREEPROCCACHE

*/

SELECT top 100 a.[text], b.[usecounts], b.size_in_bytes, b.[cacheobjtype], b.[objtype]
FROM sys.dm_exec_cached_plans as b
CROSS APPLY sys.dm_exec_sql_text(b.[plan_handle]) AS a
WHERE b.[cacheobjtype] LIKE ('Compiled Plan%')
AND a.[text] NOT LIKE '%oplsn_fseqno, oplsn_bOffset, oplsn_sloti%'
AND a.[text] NOT LIKE '(@_msparam%' AND a.[text] NOT LIKE '%trace%'
ORDER BY [text] 
OPTION (RECOMPILE) ;


