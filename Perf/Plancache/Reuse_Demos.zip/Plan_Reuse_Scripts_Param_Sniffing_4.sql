USE AdventureWorks ;
GO

SET NOCOUNT ON ;



IF OBJECT_ID('dbo.cp_GetOrdersBySalesPersonID') IS NOT NULL
  DROP PROC dbo.cp_GetOrdersBySalesPersonID;
GO

CREATE PROC dbo.cp_GetOrdersBySalesPersonID
  @SalesPersonID AS INT
AS

SELECT SalesOrderID, OrderDate, SalesOrderNumber
    FROM Sales.SalesOrderHeader
        WHERE SalesPersonID = @SalesPersonID ;
GO

DBCC FREEPROCCACHE ;

--  Turn on Show Execution Plans

--  How effecient are these three executions?  Parameter sniffing at work.
SET STATISTICS IO ON ;
GO
EXEC dbo.cp_GetOrdersBySalesPersonID 287 ;
GO
EXEC dbo.cp_GetOrdersBySalesPersonID 1703 ;
GO
EXEC sp_recompile N'dbo.cp_GetOrdersBySalesPersonID' ;
GO
EXEC dbo.cp_GetOrdersBySalesPersonID 1703 ;
GO
EXEC dbo.cp_GetOrdersBySalesPersonID 287 ;
GO
SET STATISTICS IO OFF ;


--   Drop the proc and recreate it with the RECOMPILE option
IF OBJECT_ID('dbo.cp_GetOrdersBySalesPersonID') IS NOT NULL
  DROP PROC dbo.cp_GetOrdersBySalesPersonID;
GO

CREATE PROC dbo.cp_GetOrdersBySalesPersonID
  @SalesPersonID AS INT
WITH RECOMPILE

AS

SELECT SalesOrderID, OrderDate, SalesOrderNumber
    FROM Sales.SalesOrderHeader
        WHERE SalesPersonID = @SalesPersonID ;
GO

--  See the difference in the reads now
SET STATISTICS IO ON ;
GO
EXEC dbo.cp_GetOrdersBySalesPersonID 287 ;
GO
EXEC dbo.cp_GetOrdersBySalesPersonID 1703 ;
GO
SET STATISTICS IO OFF ;


--  Another alternative is OPTION(RECOMPILE)

DECLARE @SalesPersonID INT
--SET @SalesPersonID = 99999 ;
SET @SalesPersonID = 1703 ;

SELECT SalesOrderID, OrderDate, SalesOrderNumber
    FROM Sales.SalesOrderHeader
        WHERE SalesPersonID = @SalesPersonID OPTION(RECOMPILE);


--   Drop the proc and recreate it with the OPTIMIZE FOR option
IF OBJECT_ID('dbo.cp_GetOrdersBySalesPersonID') IS NOT NULL
  DROP PROC dbo.cp_GetOrdersBySalesPersonID;
GO
CREATE PROC dbo.cp_GetOrdersBySalesPersonID
  @SalesPersonID AS INT

AS

SELECT SalesOrderID, OrderDate, SalesOrderNumber
    FROM Sales.SalesOrderHeader
        WHERE SalesPersonID = @SalesPersonID 

OPTION(OPTIMIZE FOR(@SalesPersonID = 287));
GO


--  See that they will aways use the same plan with the OPTIMIZE FOR 
SET STATISTICS IO ON ;
GO
EXEC dbo.cp_GetOrdersBySalesPersonID 287 ;
GO
EXEC dbo.cp_GetOrdersBySalesPersonID 99999 ;
GO
SET STATISTICS IO OFF ;



--   Drop the proc and recreate it with statement level hints
IF OBJECT_ID('dbo.cp_GetOrdersBySalesPersonID') IS NOT NULL
  DROP PROC dbo.cp_GetOrdersBySalesPersonID;
GO
CREATE PROC dbo.cp_GetOrdersBySalesPersonID
  @SalesPersonID AS INT

AS
SELECT SalesOrderID, OrderDate, SalesOrderNumber
    FROM Sales.SalesOrderHeader
        WHERE SalesPersonID = @SalesPersonID ;

SELECT SalesOrderID, OrderDate, SalesOrderNumber
    FROM Sales.SalesOrderHeader
        WHERE SalesPersonID = @SalesPersonID 
OPTION(OPTIMIZE FOR (@SalesPersonID = 287)) ;

SELECT SalesOrderID, OrderDate, SalesOrderNumber
    FROM Sales.SalesOrderHeader
        WHERE SalesPersonID = @SalesPersonID 
		OPTION (RECOMPILE) ;

GO


--  See that they will get potentially different plans for each statement 
SET STATISTICS IO ON ;
GO
EXEC dbo.cp_GetOrdersBySalesPersonID 287 ;
GO
EXEC dbo.cp_GetOrdersBySalesPersonID 1703 ;
GO
SET STATISTICS IO OFF ;




----------------  Plan Guides   -----------------------------------



--  control for code in Stored Procs  -----------
--  Drop and recreate the original sp
IF OBJECT_ID('dbo.cp_GetOrdersBySalesPersonID') IS NOT NULL
  DROP PROC dbo.cp_GetOrdersBySalesPersonID;
GO

CREATE PROC dbo.cp_GetOrdersBySalesPersonID
  @SalesPersonID AS INT
AS

SELECT SalesOrderID, OrderDate, SalesOrderNumber
    FROM Sales.SalesOrderHeader
        WHERE SalesPersonID = @SalesPersonID ;
GO

EXEC sp_create_plan_guide
@name = N'SalesPersonID_Guide',
@stmt = N'SELECT SalesOrderID, OrderDate, SalesOrderNumber
    FROM Sales.SalesOrderHeader
        WHERE SalesPersonID = @SalesPersonID ;',
@type = N'OBJECT',
@module_or_batch = N'dbo.cp_GetOrdersBySalesPersonID',
@params = NULL,
@hints = N'OPTION(OPTIMIZE FOR(@SalesPersonID = 287))'



SET STATISTICS IO ON ;
GO
EXEC dbo.cp_GetOrdersBySalesPersonID 287 ;
GO
EXEC dbo.cp_GetOrdersBySalesPersonID 1703 ;
GO
SET STATISTICS IO OFF ;

