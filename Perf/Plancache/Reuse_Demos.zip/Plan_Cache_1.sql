-- Plan caching in SQL Server 2012
--  http://msdn.microsoft.com/en-us/library/dn148262.aspx



--   DMV's
SELECT * FROM sys.dm_exec_cached_plans 
 
SELECT * FROM sys.dm_exec_plan_attributes(0x0500FF7F6841A90EC8406406000000000000000000000000)

SELECT * FROM sys.dm_exec_sql_text(0x0500FF7F6841A90EC8406406000000000000000000000000)




--  Let's look at the Plan Types
SELECT [cacheobjtype] AS [Cache Obj Type], [objtype] AS [Plan Type],
    COUNT(*) AS [# of Plans],
    (SUM(CAST([size_in_bytes] AS BIGINT))/1024)/1024 AS [Size MBs],
    AVG([usecounts]) AS [Use Counts]
FROM sys.dm_exec_cached_plans
    GROUP BY [cacheobjtype], [objtype]


    

--  clear all plans from the procedure cache
DBCC FREEPROCCACHE



--  All currently cached plans using the DMV's
SELECT b.[cacheobjtype], b.[objtype], b.[usecounts]
    , a.[dbid], a.[objectid], b.[size_in_bytes], a.[text]
FROM sys.dm_exec_cached_plans as b
    CROSS APPLY sys.dm_exec_sql_text(b.[plan_handle]) AS a
ORDER BY [usecounts] DESC


--  filter out the mundane stuff.
SELECT b.[cacheobjtype], b.[objtype],  b.[usecounts]
--    , a.[dbid], a.[objectid], b.[size_in_bytes]
    , a.[text]
FROM sys.dm_exec_cached_plans as b
    CROSS APPLY sys.dm_exec_sql_text(b.[plan_handle]) AS a
WHERE b.[cacheobjtype] IN ('Compiled Plan')  --('Compiled Plan','Extended Proc','CLR Compiled Func','CLR Compiled Proc')
    ORDER BY [usecounts] DESC




--  1000 Most used Plans
SELECT top 1000 b.[cacheobjtype], b.[objtype], b.[usecounts]
    , a.[dbid], a.[objectid], b.[size_in_bytes], a.[text]
FROM sys.dm_exec_cached_plans as b
    CROSS APPLY sys.dm_exec_sql_text(b.[plan_handle]) AS a
WHERE b.[cacheobjtype] IN ('Compiled Plan')
    ORDER BY [usecounts] DESC

--  1000 Least used Plans
SELECT top 1000 b.[cacheobjtype], b.[objtype], b.[usecounts]
    , a.[dbid], a.[objectid], b.[size_in_bytes], a.[text]
FROM sys.dm_exec_cached_plans as b
    CROSS APPLY sys.dm_exec_sql_text(b.[plan_handle]) AS a
WHERE b.[cacheobjtype] IN ('Compiled Plan')
    ORDER BY [usecounts] ASC

