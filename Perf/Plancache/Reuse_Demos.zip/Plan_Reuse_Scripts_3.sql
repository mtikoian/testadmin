
USE AdventureWorks ;
GO

--  Cleanup
-- Get rid of any existing plan guides
EXEC sp_control_plan_guide N'DROP ALL';
GO
EXEC sys.sp_configure N'optimize for ad hoc workloads', N'0'
GO
RECONFIGURE WITH OVERRIDE
GO

ALTER DATABASE [Adventureworks] SET PARAMETERIZATION SIMPLE
-----------------------------------------------

DBCC FREEPROCCACHE
GO

--  Adhoc queries with no autoparameterization
SELECT * FROM [Person].[Address] WHERE [city] = 'London' ;
GO
SELECT * FROM [Person].[Address] WHERE [city] = 'Berlin' ;
GO
SELECT * FROM [Person].[Address] WHERE [city] = 'Orange1' ;
GO


DBCC FREEPROCCACHE
GO

--  Adhoc queries with autoparameterization
GO
SELECT * FROM [Person].[Address] WHERE [Addressid] = 638 ;
GO
SELECT * FROM [Person].[Address] WHERE [Addressid] = 17057 ;
GO
SELECT * FROM [Person].[Address] WHERE [Addressid] = 22330 ;
GO



--  Beware of some assumptions autoparameterization makes such as data types.
--  Notice what datatype Sql Server gives this query compared to the previous ones.
SELECT * FROM [Person].[Address] WHERE [Addressid] = 93254521 ;
GO



DBCC FREEPROCCACHE
GO
--  Notice that it doesn't take much to defeat autoparameterization
GO
SELECT MAX(ModifiedDate) FROM [Person].[Address] WHERE [Addressid] = 17057 ;
GO
SELECT MAX(ModifiedDate) FROM [Person].[Address] WHERE [Addressid] = 22330 ;
GO
SELECT h.AccountNumber, d.ProductID
FROM [Sales].[SalesOrderHeader] AS h INNER JOIN [Sales].[SalesOrderDetail] AS d
    ON h.SalesOrderID = d.SalesOrderID
WHERE h.SalesOrderID = 44000
GO




--  Look at this DB setting and how it affects the plan reuse
ALTER DATABASE [Adventureworks] SET PARAMETERIZATION FORCED 
GO

ALTER DATABASE [Adventureworks] SET PARAMETERIZATION SIMPLE
GO

--  Now lets see how this Instance wide option affects the cache
EXEC sys.sp_configure N'optimize for ad hoc workloads', N'1'
GO
RECONFIGURE WITH OVERRIDE
GO

-- *** Note the size of the stubs vs. the actual full plans


EXEC sys.sp_configure N'optimize for ad hoc workloads', N'0'
GO
RECONFIGURE WITH OVERRIDE
GO



--  What about dynamic sql
DBCC FREEPROCCACHE
GO
DECLARE @SQL NVARCHAR(200) ;

SET @SQL = N'SELECT * FROM [Person].[Address] WHERE [Addressid] = 222' ;
EXEC(@SQL) ;
GO
DECLARE @SQL NVARCHAR(200) ;

SET @SQL = N'SELECT * FROM [Person].[Address] WHERE [Addressid] = 333' ;
EXEC(@SQL) ;
GO
DECLARE @SQL NVARCHAR(200) ;

SET @SQL = N'SELECT * FROM [Person].[Address] WHERE [Addressid] = 444' ;
EXEC(@SQL) ;
GO

---
DBCC FREEPROCCACHE

GO
DECLARE @SQL NVARCHAR(200) ;

SET @SQL = N'SELECT * FROM [Person].[Address] WHERE [city] = ''Orange''' ;
EXEC(@SQL) ;
GO
DECLARE @SQL NVARCHAR(200) ;

SET @SQL = N'SELECT * FROM [Person].[Address] WHERE [city] = ''London''' ;
EXEC(@SQL) ;
GO

-------
DBCC FREEPROCCACHE

GO
---  Does sp_executesql make a difference?
DECLARE @City VARCHAR(30) ;
DECLARE @SQL NVARCHAR(500);
DECLARE @ParmDefinition NVARCHAR(500);

SET @SQL = N'SELECT * FROM [Person].[Address] WHERE [city] = @City' ;
SET @ParmDefinition = N'@City VARCHAR(30)';
SET @City = 'London' ;

EXECUTE sp_executesql @SQL, @ParmDefinition, @City = @City;

SET @City = 'Orange' ;
EXECUTE sp_executesql @SQL, @ParmDefinition, @City = @City;
GO



--  Lets see actual dotnet calls



DBCC FREEPROCCACHE

--  Plan guides can help as well

-- Get rid of any existing plan guides
EXEC sp_control_plan_guide N'DROP ALL';
GO

---   Getting a template
DECLARE @stmt nvarchar(max)
DECLARE @params nvarchar(max)
EXEC sp_get_query_template N'SELECT * FROM [Person].[Address] WHERE [city] = ''Orange'' ;',
@stmt OUTPUT, 
@params OUTPUT

---  Use that template in a plan guide
EXEC sp_create_plan_guide N'City_Guide', 
@stmt, 
N'TEMPLATE', 
NULL, 
@params, 
N'OPTION(PARAMETERIZATION FORCED)'
GO

-- see how these queries now use parameterization
SELECT * FROM [Person].[Address] WHERE [city] = 'Orange' ;
GO
SELECT * FROM [Person].[Address] WHERE [city] = 'Berlin' ;





/*
    The difference in plan reuse behavior between an Adhoc query
    or plain dynamic sql and using the parameters with sp_executesql
    is comporable to how submitting adhoc sql statements vs. parameterized
    ones from your client app or middle tier. 
    Never rely on autoparameterization. 
    Always use parameters in the connection object or use sp_executesql
    with proper parameters or simply use stored procedures.
*/



--------
DBCC FREEPROCCACHE

GO
-----    stored procs  ---------
IF OBJECT_ID('dbo.cp_GetOrdersBySalesPersonID') IS NOT NULL
  DROP PROC dbo.cp_GetOrdersBySalesPersonID;
GO

CREATE PROC dbo.cp_GetOrdersBySalesPersonID
  @SalesPersonID AS INT
AS

SELECT SalesOrderID, OrderDate--, SalesOrderNumber
    FROM Sales.SalesOrderHeader
        WHERE SalesPersonID = @SalesPersonID ;
GO

--  Stored Procedure plan reuse
EXEC dbo.cp_GetOrdersBySalesPersonID 288 ;
GO
EXEC dbo.cp_GetOrdersBySalesPersonID 278 ;
GO
EXEC dbo.cp_GetOrdersBySalesPersonID 99999 ;
GO
