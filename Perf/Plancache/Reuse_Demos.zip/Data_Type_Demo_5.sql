

USE AdventureWorks ;
GO


IF OBJECT_ID('[dbo].[TestIndex]','U') IS NOT NULL
  DROP TABLE dbo.[TestIndex] ;
GO

SELECT [AddressID],[AddressLine1],[AddressLine2]
    ,CAST([City] AS VARCHAR(30)) AS [City]
    ,[StateProvinceID],[PostalCode],[rowguid],[ModifiedDate] 
INTO [dbo].[TestIndex] 
FROM [Person].[Address] ;

CREATE NONCLUSTERED INDEX [IX_TestIndex__City] ON [dbo].[TestIndex] 
([City] ASC) ;
GO


--  Turn on Query Plans
--  CTRL-M

SET STATISTICS IO ON

DECLARE @City VARCHAR(30) = 'Shawnee2' ;

SELECT * FROM [dbo].[TestIndex] WHERE [city] = @City ;
GO

DECLARE @City NVARCHAR(30) = 'Shawnee2' ;

SELECT * FROM [dbo].[TestIndex] WHERE [city] = @City ;
GO
