/*============================================================
--http://www.SQLBalls.com
--@SQLBalls: SQLBalls@gmail.com
--Performance Troubleshooting
--

This Sample Code is provided for the purpose of illustration only and is not intended
to be used in a production environment.  THIS SAMPLE CODE AND ANY RELATED INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.

==============================================================*/

Use Demo2
go
set nocount on;
go

while (1=1)
begin
	insert into dbo.mytable1 default values
end
go