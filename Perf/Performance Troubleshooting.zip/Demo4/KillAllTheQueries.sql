
if exists(select name from tempdb.sys.tables where name like '#mytable%')
begin
	drop table #mytable
end
go
create table #mytable( myid int identity(1,1), sqlcmd varchar(500))

insert into #mytable
select
	'kill ' + cast(session_id as varchar(4))
from
	sys.dm_exec_sessions
where
	program_name='SQLCMD'

declare @i int, @x int, @sqlcmd varchar(500)
set @i=0
set @x=(select count(*) from #mytable)

While (@i<@x)
	Begin
		set @i=@i+1
		set @sqlcmd=(select sqlcmd from #mytable where myid=@i)

		exec(@sqlcmd)
	end