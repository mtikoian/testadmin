USE AdventureWorks2012
GO

IF OBJECT_ID('tempdb..#waits_base') IS NOT NULL
	DROP TABLE #waits_base

SELECT * INTO #waits_base FROM sys.dm_os_wait_stats

SELECT w.wait_type
    ,wait_count_delta = w.waiting_tasks_count - b.waiting_tasks_count
    ,wait_time = w.wait_time_ms - b.wait_time_ms
	,signal_wait = w.signal_wait_time_ms-b.signal_wait_time_ms
	,resource_wait = (w.wait_time_ms - b.wait_time_ms)-(w.signal_wait_time_ms-b.signal_wait_time_ms)
FROM sys.dm_os_wait_stats w 
    INNER JOIN #waits_base b ON b.wait_type = w.wait_type

where w.wait_type not in ('CLR_SEMAPHORE',    'LAZYWRITER_SLEEP',
'RESOURCE_QUEUE',   'SQLTRACE_BUFFER_FLUSH',  'SLEEP_TASK',       'SLEEP_SYSTEMTASK',  'WAITFOR',   'HADR_FILESTREAM_IOMGR_IOCOMPLETION',  'CHECKPOINT_QUEUE', 'REQUEST_FOR_DEADLOCK_SEARCH', 'XE_TIMER_EVENT',   'XE_DISPATCHER_JOIN','LOGMGR_QUEUE','FT_IFTS_SCHEDULER_IDLE_WAIT', 'BROKER_TASK_STOP', 'CLR_MANUAL_EVENT', 'CLR_AUTO_EVENT',   'DISPATCHER_QUEUE_SEMAPHORE',  'TRACEWRITE',       'XE_DISPATCHER_WAIT', 'BROKER_TO_FLUSH',  'BROKER_EVENTHANDLER', 'FT_IFTSHC_MUTEX',  'SQLTRACE_INCREMENTAL_FLUSH_SLEEP', 'DIRTY_PAGE_POLL',  'SP_SERVER_DIAGNOSTICS_SLEEP'
)
ORDER BY wait_count_delta DESC


GO


-- Run Workload

SELECT w.wait_type
    ,wait_count_delta = w.waiting_tasks_count - b.waiting_tasks_count
    ,wait_time = w.wait_time_ms - b.wait_time_ms
	,signal_wait = w.signal_wait_time_ms-b.signal_wait_time_ms
	,resource_wait = (w.wait_time_ms - b.wait_time_ms)-(w.signal_wait_time_ms-b.signal_wait_time_ms)
FROM sys.dm_os_wait_stats w 
    INNER JOIN #waits_base b ON b.wait_type = w.wait_type

where w.wait_type not in ('CLR_SEMAPHORE',    'LAZYWRITER_SLEEP',
'RESOURCE_QUEUE',   'SQLTRACE_BUFFER_FLUSH',  'SLEEP_TASK',       'SLEEP_SYSTEMTASK',  'WAITFOR',   'HADR_FILESTREAM_IOMGR_IOCOMPLETION',  'CHECKPOINT_QUEUE', 'REQUEST_FOR_DEADLOCK_SEARCH', 'XE_TIMER_EVENT',   'XE_DISPATCHER_JOIN','LOGMGR_QUEUE','FT_IFTS_SCHEDULER_IDLE_WAIT', 'BROKER_TASK_STOP', 'CLR_MANUAL_EVENT', 'CLR_AUTO_EVENT',   'DISPATCHER_QUEUE_SEMAPHORE',  'TRACEWRITE',       'XE_DISPATCHER_WAIT', 'BROKER_TO_FLUSH',  'BROKER_EVENTHANDLER', 'FT_IFTSHC_MUTEX',  'SQLTRACE_INCREMENTAL_FLUSH_SLEEP', 'DIRTY_PAGE_POLL',  'SP_SERVER_DIAGNOSTICS_SLEEP'
)
ORDER BY wait_count_delta DESC


GO
