/*
How do you clear the server's wait
stats?
DBCC SQLPERF('sys.dm_os_wait_stats', CLEAR);

=================================================
BY: Glenn Berry & Paul Randal


CTE to get wait stats.

This CTE get's the wait stats as they are occuring on the 
system and give's you the total seconds of wait, the 
# of occurances, as well as the top percentage of where
your wait time is coming from.  

The Exclusions of certian wait types were recommendations
by Paul Randal in the MCM wait types video series
==================================================
*/
set transaction isolation level read uncommitted 
go
use demo2
go
if exists(select name from tempdb.sys.tables where name like '#tcount%')
begin	
	drop table #tcount 
end
go
declare @rowcount1 int, @starttime datetime

set @rowcount1=( select ps.row_count from sys.dm_db_partition_stats ps
left join sys.objects so
on ps.object_id=so.object_id
where so.name='mytable1')

set @starttime = getdate()


create table #tcount(rowCount1 int, starttime datetime)
insert into #tcount(rowcount1, starttime)
values(@rowcount1, @starttime)

go

WITH Waits AS
(SELECT 
	wait_type,
	wait_time_ms /1000.0 AS Waits,
	(wait_time_ms - signal_wait_time_ms)/1000.0 AS Resources,
	signal_wait_time_ms/1000.0 AS Signals,
	waiting_tasks_count AS WaitCount,
	100.0 * wait_time_ms /SUM(wait_time_ms) OVER()AS Percentage,
	ROW_NUMBER()OVER
	(ORDER BY wait_time_ms DESC)AS RowNum
FROM sys.dm_os_wait_stats
WHERE 
	wait_type NOT IN ('CLR_SEMAPHORE','LAZYWRITER_SLEEP','RESOURCE_QUEUE','SLEEP_SYSTEMTASK','SQLTRACE_BUFFER_FLUSH','WAITFOR','LOGMGR_QUEUE','CHECKPOINT_QUEUE'
,'REQUEST_FOR_DEADLOCK_SEARCH','XE_TIMER_EVENT','BROKER_TO_FLUSH','BROKER_TASK_STOP','CLR_MANUAL_EVENT'
,'CLR_AUTO_EVENT','DISPATCHER_QUEUE_SEMAPHORE','FT_IFTS_SCHEDULER_IDLE_WAIT'
,'XE_DISPATCHER_WAIT','XE_DISPATCHER_JOIN','SQLTRACE_INCREMENTAL_FLUSH_SLEEP', 'HADR_FILESTREAM_IOMGR_IOCOMPLETION','DIRTY_PAGE_POLL', 'SP_SERVER_DIAGNOSTICS_SLEEP', 'SLEEP_TASK', 'BROKER_EVENTHANDLER', 'SLEEP_BPOOL_FLUSH')
)


SELECT 
	W1.wait_type
	,CAST(W1.Waits AS DECIMAL(14,4))AS Wait_S
	,CAST(w1.Resources AS DECIMAL(14,4))AS  Resources_S
	,CAST(W1.Signals AS DECIMAL(14,4))AS Signal_S
	,W1.WaitCount
	,CAST(W1.Percentage AS DECIMAL(14,4))AS Percentage
	,CAST((w1.WaitS/W1.WaitCount) as decimal(14,4))as AvgWait_S
	,CAST((AVG(W1.Resources)/ W1.WaitCount) AS DECIMAL(14,4))AS AvgRes_S
	,CAST(AVG(W1.Signals)/ W1.WaitCount AS DECIMAL(14,4))AS AvgSig_S
FROM 
	Waits AS W1
	INNER JOIN Waits AS W2
ON 
	W2.RowNum <=W1.RowNum
where
	w1.waitcount >0
GROUP BY 
	W1.RowNum,W1.wait_type,W1.Waits,W1.Percentage, w1.Resources, w1.WaitCount,w1.Signals
HAVING 
	SUM(W2.Percentage) -W1.Percentage <99 --Percentage Threshold
/*
=================================================
BY: Joe Sack

This will give you the waits as they are happening
on a system, and give you the query text, as well
as the execution plans as they are occuring

I added the @@SPID to the query so we would not
see our own query plan come back while trouble
shooting
==================================================
*/


Select
	DB_NAME(est.dbid) AS DatabaseName,
	login_name,
	owt.session_id,
	er.percent_complete,
	owt.wait_duration_ms,
	owt.wait_type,
	owt.blocking_session_id,
	owt.resource_description,
	es.program_name,
	est.text,
	est.dbid,
	eqp.query_plan,
	es.cpu_time,
	es.memory_usage
from sys.dm_os_waiting_tasks owt
INNER JOIN sys.dm_exec_sessions es ON
	owt.session_id=es.session_id
INNER JOIN sys.dm_exec_requests er ON
	es.session_id=er.session_id
OUTER APPLY sys.dm_exec_sql_text(er.plan_handle) est
OUTER APPLY sys.dm_exec_query_plan(er.plan_handle) eqp
WHERE es.is_user_process=1
	AND es.session_id<> @@spid;

declare @rowcount1 int, @rowcount2 int, @starttime datetime, @endtime datetime
waitfor delay '00:00:01'
set @rowcount2=(select ps.row_count from sys.dm_db_partition_stats ps
left join sys.objects so
on ps.object_id=so.object_id
where so.name='mytable1')
set @endtime=getdate()

set @rowcount1=(select rowcount1 from #tcount)
set @starttime=(select starttime from #tcount)

select @rowcount2-@rowcount1 as records_Added, datediff(ms, @starttime, @endtime) as elapsedtimein_MS
go
use master
go