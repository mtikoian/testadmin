USE [Demo2];
DBCC SHRINKFILE (N'Demo2_log', 1, TRUNCATEONLY);
--
-- CHECK: if the tlog file has shrunk with the following query:
SELECT name, (size*8)/1024 AS log_MB FROM [Demo2].dbo.sysfiles WHERE (64 & status) = 64

--
-- METHOD: Alter recovery model -> Shrink:
-- NOTE: Because the database is in FULL recovery model, one alternative is to set it to SIMPLE to truncate the log, shrink it, and reset it to FULL.
-- NOTE2: This method of setting the recovery model to SIMPLE and back again WILL BREAK log chaining, and thus any log shipping or mirroring.
USE [master]; ALTER DATABASE [Demo2] SET RECOVERY SIMPLE;
USE [Demo2];
--
-- CHECK: if the tlog file has shrunk with the following query:
SELECT name, (size*8)/1024 AS log_MB FROM [Demo2].dbo.sysfiles WHERE (64 & status) = 64
-- Now for the log file growth:
ALTER DATABASE [Demo2] MODIFY FILE ( NAME = N'Demo2_log', SIZE = 512MB , FILEGROWTH = 64MB );
