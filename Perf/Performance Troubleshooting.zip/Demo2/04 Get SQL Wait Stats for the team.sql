/*
How do you clear the server's wait
stats?
DBCC SQLPERF('sys.dm_os_wait_stats', CLEAR);

=================================================
BY: Glenn Berry & Paul Randal


CTE to get wait stats.

This CTE get's the wait stats as they are occuring on the 
system and give's you the total seconds of wait, the 
# of occurances, as well as the top percentage of where
your wait time is coming from.  

The Exclusions of certian wait types were recommendations
by Paul Randal in the MCM wait types video series
==================================================
*/
set transaction isolation level read uncommitted 
go
if exists(select name from tempdb.sys.tables where name like '#perfT%')
begin
	drop table #perfT
end
go
create table #perfT(mydate datetime, myCount bigint)
go
insert into #perfT
select
	getdate()
	,count(*)
from 
	demo3.dbo.myTable1
go
select * from #perfT
go
WITH Waits AS
(SELECT 
	wait_type,
	wait_time_ms /1000.0 AS Waits,
	(wait_time_ms - signal_wait_time_ms)/1000.0 AS Resources,
	signal_wait_time_ms/1000.0 AS Signals,
	waiting_tasks_count AS WaitCount,
	100.0 * wait_time_ms /SUM(wait_time_ms) OVER()AS Percentage,
	ROW_NUMBER()OVER
	(ORDER BY wait_time_ms DESC)AS RowNum
FROM sys.dm_os_wait_stats
WHERE 
	wait_type NOT IN ('CLR_SEMAPHORE','LAZYWRITER_SLEEP','RESOURCE_QUEUE','SLEEP_SYSTEMTASK','SQLTRACE_BUFFER_FLUSH','WAITFOR','LOGMGR_QUEUE','CHECKPOINT_QUEUE'
,'REQUEST_FOR_DEADLOCK_SEARCH','XE_TIMER_EVENT','BROKER_TO_FLUSH','BROKER_TASK_STOP','CLR_MANUAL_EVENT'
,'CLR_AUTO_EVENT','DISPATCHER_QUEUE_SEMAPHORE','FT_IFTS_SCHEDULER_IDLE_WAIT'
,'XE_DISPATCHER_WAIT','XE_DISPATCHER_JOIN','SQLTRACE_INCREMENTAL_FLUSH_SLEEP', 'HADR_FILESTREAM_IOMGR_IOCOMPLETION','DIRTY_PAGE_POLL', 'SP_SERVER_DIAGNOSTICS_SLEEP','SLEEP_TASK',
'BROKER_EVENTHANDLER', 'FT_IFTSHC_MUTEX', 'SLEEP_DBSTARTUP')
)


SELECT 
	W1.wait_type
	,CAST(W1.Waits AS DECIMAL(14,4))AS Wait_S
	,CAST(w1.Resources AS DECIMAL(14,4))AS  Resources_S
	,CAST(W1.Signals AS DECIMAL(14,4))AS Signal_S
	,W1.WaitCount
	,CAST(W1.Percentage AS DECIMAL(14,4))AS Percentage
	--,cast(w2.Percentage as decimal(14,4)) as percent2
	--,sum(w2.percentage)-w1.Percentage as mathstuff
	,CAST((w1.WaitS/W1.WaitCount) as decimal(14,4))as AvgWait_S
	,CAST((AVG(W1.Resources)/ W1.WaitCount) AS DECIMAL(14,4))AS AvgRes_S
	,CAST(AVG(W1.Signals)/ W1.WaitCount AS DECIMAL(14,4))AS AvgSig_S
FROM 
	Waits AS W1
	INNER JOIN Waits AS W2
ON 
	W2.RowNum <=W1.RowNum
GROUP BY 
	W1.RowNum,W1.wait_type,W1.Waits,W1.Percentage, w1.Resources, w1.WaitCount,w1.Signals
HAVING 
	SUM(W2.Percentage) -W1.Percentage <99 --Percentage Threshold
/*
=================================================
BY: Joe Sack

This will give you the waits as they are happening
on a system, and give you the query text, as well
as the execution plans as they are occuring

I added the @@SPID to the query so we would not
see our own query plan come back while trouble
shooting
==================================================
*/


Select
	DB_NAME(est.dbid) AS DatabaseName,
	login_name,
	owt.session_id,
	er.percent_complete,
	owt.wait_duration_ms,
	owt.wait_type,
	owt.blocking_session_id,
	owt.resource_description,
	es.program_name,
	est.text,
	est.dbid,
	eqp.query_plan,
	es.cpu_time,
	es.memory_usage
from sys.dm_os_waiting_tasks owt
INNER JOIN sys.dm_exec_sessions es ON
	owt.session_id=es.session_id
INNER JOIN sys.dm_exec_requests er ON
	es.session_id=er.session_id
OUTER APPLY sys.dm_exec_sql_text(er.plan_handle) est
OUTER APPLY sys.dm_exec_query_plan(er.plan_handle) eqp
WHERE es.is_user_process=1
	AND es.session_id<> @@spid;
go
select 
	datediff(ms,mydate, getdate()) as Seconds
	,((select count(*) from demo3.dbo.myTable1)-mycount) as AddedRows	
from
	#perfT
	
go
use master
go

/*
DBCC FREEPROCCACHE

use demo3
go
SELECT TOP(250) p.name AS [SP Name], qs.execution_count,
ISNULL(qs.execution_count/DATEDIFF(Second, qs.cached_time, GETDATE()), 0) AS [Calls/Second],
qs.total_worker_time/qs.execution_count AS [AvgWorkerTime], qs.total_worker_time AS [TotalWorkerTime],  
qs.total_elapsed_time, qs.total_elapsed_time/qs.execution_count AS [avg_elapsed_time],
qs.cached_time
FROM sys.procedures AS p WITH (NOLOCK)
INNER JOIN sys.dm_exec_procedure_stats AS qs WITH (NOLOCK)
ON p.[object_id] = qs.[object_id]
WHERE qs.database_id = DB_ID()
ORDER BY qs.execution_count DESC OPTION (RECOMPILE);

*/