use AdventureWorks2012
go
while 1=1
begin
	exec p_sel_get_customer_by_SSN '570807133';
end
