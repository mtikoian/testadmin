SET NOCOUNT ON
/*
1. Run Script
2. Copy the following statement into SQL Load Generator with 20 conncurrent connections

exec p_sel_get_customer_by_SSN '100010977'
*/

use AdventureWorks2012
go 
/*
stored proc
*/
if exists(select * from sys.procedures where name='p_sel_get_customer_by_SSN')
begin
	drop procedure p_sel_get_customer_by_SSN
end
go
create procedure p_sel_get_customer_by_SSN(
	@ssn char(9)
)
as
begin
	select ssn from dbo.customers 
	where ssn=@ssn 
end
go
