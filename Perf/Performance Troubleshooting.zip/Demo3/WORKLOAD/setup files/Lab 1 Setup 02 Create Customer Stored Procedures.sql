SET NOCOUNT ON
/*
1. Run Script
2. Copy the following statement into SQL Load Generator with 20 conncurrent connections

exec p_sel_get_customer_by_SSN '570807133'
*/

select * from dbo.customers

use AdventureWorks2012
go 
/*
stored proc
*/
if exists(select * from sys.procedures where name='p_sel_get_customer_by_SSN')
begin
	drop procedure p_sel_get_customer_by_SSN
end
go
create procedure p_sel_get_customer_by_SSN(
	@ssn nchar(9)
)
as
begin
	select ssn from dbo.customers 
	where ssn=@ssn 
end
go
/*
Make sure SSN NCLX is in place
*/
use AdventureWorks2012
go
if exists(select name from sys.indexes where name='nxlx_customer_ssn')
begin
	drop index nxlx_customer_ssn on dbo.customers
end
go
CREATE NONCLUSTERED INDEX nxlx_customer_ssn
ON [dbo].[customers] ([ssn])
/*
Free procedure cache
*/
DBCC FREEPROCCACHE

select * from dbo.customers