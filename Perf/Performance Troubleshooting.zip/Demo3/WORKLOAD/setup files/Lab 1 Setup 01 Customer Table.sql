use AdventureWorks2012
go
SET NOCOUNT ON
GO
/*
create customer table
*/
if exists(select st.name, ss.name from sys.tables st left join sys.schemas ss on st.schema_id=ss.schema_id  where st.name='customers' and ss.name='dbo' )
begin
	drop table dbo.customers
end
go
create table dbo.customers( 
				customerID int identity(100000,1) 
				,ssn char(9)
				,FirstName varchar(50)
				,MiddileInitial char(1)
				,LastName varchar(100)
				,BirthDate datetime
				,Gender char(1)
				,constraint pk_customers_customerID primary key clustered (customerID)
				)

declare @i int, @x int, @y int, @z int, @firstname varchar(50), @ssn char(9), @mi char(1), @LastName varchar(100),@DOB datetime, @gender char(1),  @date_from DATETIME, @date_to DATETIME
 
SET @date_from = '1992-12-01';
SET @date_to = '1996-1-01';
set @i=0
begin transaction
while(@i<899999)
Begin

	set @x=(select CAST(RAND() * 10 AS INT))
	set @y=(select CAST(RAND() * 10 AS INT))
	set @z=(select CAST(RAND() * 10 AS INT))
	set @ssn=cast((select CAST(RAND() * 1000000000 AS INT)) as char(9))
	set @dob=(SELECT
(@date_from +(ABS(CAST(CAST( NewID() AS BINARY(8) )AS INT))%CAST((@date_to - @date_from)AS INT))))


	select
		@firstname=case @x
			when 1 then  'Michael'
			when 2 then 'Neil'
			when 3 then 'David'
			when 4 then 'Joss'
			when 5 then 'Jorge'
			when 6 then 'Chad'
			when 7 then 'Kathi'
			when 8 then 'Lisa'
			when 9 then 'Serenity'
			else 'Paul'
		end
		,@lastname=case @y
			when 1 then  'Jordan'
			when 2 then 'Patrick-Harris'
			when 3 then 'Ball'
			when 4 then 'Whedon'
			when 5 then 'Segarra'
			when 6 then 'Churchwell'
			when 7 then 'Kellenburger'
			when 8 then 'Simpson'
			when 9 then 'Elizabeth'
			else 'Randal'
		end
		,@mi=case @z
			when 1 then  'T'
			when 2 then 'W'
			when 3 then 'X'
			when 4 then 'C'
			when 5 then 'V'
			when 6 then 'H'
			when 7 then 'P'
			when 8 then 'L'
			when 9 then 'B'
			else 'Q'
		end
		,@gender=case 
			when (@x<7) then 'M'
			else 'F'
			end 

			insert into dbo.customers(ssn,FirstName,MiddileInitial,LastName,BirthDate,Gender)
			values( @ssn, @firstname, @mi, @LastName, @dob, @gender)

	set @i=@i+1

end
commit transaction
