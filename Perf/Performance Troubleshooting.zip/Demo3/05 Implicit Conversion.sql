USE AdventureWorks2012
GO
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED 
GO

DECLARE @dbname SYSNAME 
SET @dbname = QUOTENAME(DB_NAME()); 

WITH XMLNAMESPACES 
   (DEFAULT 'http://schemas.microsoft.com/sqlserver/2004/07/showplan') 
SELECT 
   t.value('(ScalarOperator/Identifier/ColumnReference/@Schema)[1]', 'sysname') +'.'+
   t.value('(ScalarOperator/Identifier/ColumnReference/@Table)[1]', 'sysname') AS ObjectName
   ,t.value('(ScalarOperator/Identifier/ColumnReference/@Column)[1]', 'sysname') AS ColumnName
   ,ic.DATA_TYPE AS ConvertFrom
   ,ic.CHARACTER_MAXIMUM_LENGTH AS ConvertFromLength
   ,t.value('(@DataType)[1]', 'sysname') AS ConvertTo
   ,t.value('(@Length)[1]', 'int') AS ConvertToLength
   ,stmt.value('(@StatementText)[1]', 'varchar(max)') AS TSQL
   ,query_plan 
   ,plan_handle
FROM sys.dm_exec_cached_plans AS cp 
    CROSS APPLY sys.dm_exec_query_plan(plan_handle) AS qp 
    CROSS APPLY query_plan.nodes('/ShowPlanXML/BatchSequence/Batch/Statements/StmtSimple') AS batch(stmt) 
    CROSS APPLY stmt.nodes('.//Convert[@Implicit="1"]') AS n(t) 
    INNER JOIN INFORMATION_SCHEMA.COLUMNS AS ic 
        ON QUOTENAME(ic.TABLE_SCHEMA) = t.value('(ScalarOperator/Identifier/ColumnReference/@Schema)[1]', 'sysname') 
        AND QUOTENAME(ic.TABLE_NAME) = t.value('(ScalarOperator/Identifier/ColumnReference/@Table)[1]', 'sysname') 
        AND ic.COLUMN_NAME = t.value('(ScalarOperator/Identifier/ColumnReference/@Column)[1]', 'sysname') 
WHERE t.exist('ScalarOperator/Identifier/ColumnReference[@Database=sql:variable("@dbname")][@Schema!="[sys]"]') = 1 