/*============================================================
--http://www.SQLBalls.com
--@SQLBalls: SQLBalls@gmail.com
--Trimming Indexes
--

This Sample Code is provided for the purpose of illustration only and is not intended
to be used in a production environment.  THIS SAMPLE CODE AND ANY RELATED INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.

==============================================================*/
/*
Create our database
*/
use master
go
if exists(select name from sys.databases where name='demoIndexes')
begin
	drop database demoIndexes
end
go
Create database demoIndexes
go
use demoIndexes
go

/*
Create our heap for our deeper
examples
*/
set statistics profile off
if exists(select name from sys.tables where name='heap')
begin
	drop table dbo.heap
end
go
create table dbo.heap(myid int primary key clustered , mychar char(3000) default 'a', mychar2 char(500) default 'b')
go
declare @i int
set @i=0
while(@i<15000)
begin
	begin transaction
		set @i=@i+1
		insert into dbo.heap(myid, mychar, mychar2)
		values(@i, ('a'+cast(@i as varchar(6))), ('b'+cast(@i as varchar(6))))
		
	commit transaction
end

set statistics io off

/*
That Failed Try this one
*/
create nonclustered index nclx_heap_mychar2 on heap(mychar2)

/*
Set execution plan 
*/
if exists(select name from sys.procedures where name='p_sel_key_lookup')
begin
	drop procedure p_sel_key_lookup
end
go
create procedure p_sel_key_lookup
as
begin
select
	*
from
	dbo.heap
where
	mychar2='b101'
end
go

exec p_sel_key_lookup