USE [AdventureWorks2014]
GO

IF OBJECT_ID('demo.AddDiscountToSalesOrderDetail') IS NOT NULL
DROP PROCEDURE [demo].[AddDiscountToSalesOrderDetail]
GO

/****** Object:  StoredProcedure [demo].[AddDiscountToSalesOrderDetail]    Script Date: 8/17/2014 4:12:39 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*

 DBCC DROPCLEANBUFFERS
 DBCC FREEPROCCACHE

 */
-- demo.AddDiscountToSalesOrderDetail '01/01/2011', '02/01/2011'

-- demo.AddDiscountToSalesOrderDetail '03/01/2012', '06/01/2014 23:59:59' WITH RECOMPILE
-- UPDATE STATISTICS [Sales].[SalesOrderDetailEnlarged] WITH FULLSCAN
CREATE PROCEDURE [demo].[AddDiscountToSalesOrderDetail] (
    @BeginDate datetime,
    @EndDate datetime

)

as

BEGIN TRANSACTION

    UPDATE sod
	SET   [UnitPriceDiscount] = 
	   CASE 
    		  WHEN [OrderQty] > 20 THEN [UnitPrice] * .20
		  WHEN [OrderQty] > 15 THEN [UnitPrice] * .15
		  WHEN [OrderQty] > 10 THEN [UnitPrice] * .10
		  WHEN [OrderQty] > 5 THEN [UnitPrice] * .05
		  ELSE 0 END

    FROM [Sales].[SalesOrderDetailEnlarged] sod
    JOIN [Sales].[SalesOrderHeaderEnlarged] soh
    ON soh.[SalesOrderID] = sod.[SalesOrderID]
    WHERE soh.[ShipDate] >= @BeginDate
    --AND CAST(sod.ModifiedDate as DATE) between @BeginDate and @EndDate
    AND sod.ModifiedDate between @BeginDate and @EndDate
    --OPTION (MAXDOP 1)

COMMIT TRAN

/*
SELECT CAST(ModifiedDate as date), count(*)
FROM [Sales].[SalesOrderDetailEnlarged]
group by CAST(ModifiedDate as date)
order by 2 desc
*/
GO

