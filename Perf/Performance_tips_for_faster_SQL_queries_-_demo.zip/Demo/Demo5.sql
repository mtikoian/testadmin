/*
	SQLSatSlovenia - 10.12.2016
	Performance tips forfaster SQL queries

	Emanuele Zanchettin
	ezanchettin@thinkit.it - www.thinkit.it
*/

USE SQLSatSlovenia;



-- UPDATING DATA
SET STATISTICS IO ON;
SET STATISTICS TIME ON;

UPDATE History SET Description = CASE Code
        WHEN 1111 THEN 'NEW VALUE'
        WHEN 2222 THEN 'NEW VALUE 2'
        WHEN 5333 THEN 'NEW VALUE 3'
    END
WHERE Code in (1111, 2222, 5333)

SET STATISTICS IO OFF;
SET STATISTICS TIME OFF;
/*

*/







-- UPDATING DATI IF NEEDED
SET STATISTICS IO ON;
SET STATISTICS TIME ON;

UPDATE History
SET Description = 'NEW VALUE'			-- NEW VALUE
WHERE Code = 1111						-- CONDITION
    AND Description <> 'NEW VALUE'		-- VALIDATION

UPDATE History
SET Description = 'NEW VALUE 2'			-- NEW VALUE
WHERE Code = 2222						-- CONDITION
    AND Description <> 'NEW VALUE 2'	-- VALIDATION

UPDATE History
SET Description = 'NEW VALUE 3'			-- NEW VALUE
WHERE Code = 5333						-- CONDITION
    AND Description <> 'NEW VALUE 3'	-- VALIDATION

SET STATISTICS IO OFF;
SET STATISTICS TIME OFF;
/*

 */



