/*
	SQLSatSlovenia - 10.12.2016
	Performance tips forfaster SQL queries

	Emanuele Zanchettin
	ezanchettin@thinkit.it - www.thinkit.it
*/

USE SQLSatSlovenia;



-- HISTORY TABLE
CREATE TABLE History(
             ID INT IDENTITY(1,1) NOT NULL,
			 Code INT, 
             Description varchar( 35 ));
GO

CREATE NONCLUSTERED INDEX IX_History ON dbo.History
	(
	Code
	) 
	INCLUDE (Description)
	WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]






-- INSERTING DATA >> Demo4a - ROW BY ROW APPROACH
TRUNCATE TABLE History;

SET STATISTICS IO ON;
SET STATISTICS TIME ON;
INSERT INTO History (Code, Description) VALUES (...., ...);
INSERT INTO History (Code, Description) VALUES (...., ...);
[...]
INSERT INTO History (Code, Description) VALUES (...., ...);
INSERT INTO History (Code, Description) VALUES (...., ...);
SET STATISTICS TIME OFF;
SET STATISTICS IO OFF;
GO


-- INSERTING DATA >> Demo4b - ROW SET APPROACH
TRUNCATE TABLE History;

SET STATISTICS IO ON;
SET STATISTICS TIME ON;
INSERT INTO History (Code, Description) VALUES (...., ...), (...., ...), (...., ...), (...., ...), (...., ...);
[...]
INSERT INTO History (Code, Description) VALUES (...., ...), (...., ...), (...., ...), (...., ...), (...., ...);
SET STATISTICS TIME OFF;
SET STATISTICS IO OFF;
GO

