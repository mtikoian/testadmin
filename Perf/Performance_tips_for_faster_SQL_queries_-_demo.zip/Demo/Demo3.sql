/*
	SQLSatSlovenia - 10.12.2016
	Performance tips forfaster SQL queries

	Emanuele Zanchettin
	ezanchettin@thinkit.it - www.thinkit.it
*/

USE SQLSatSlovenia;



-- FUNCTIONS TO MANAGE DATE
CREATE FUNCTION dbo.fn_DataNumericaAAAAMMGG(@Data smalldatetime)
RETURNS float
AS
     BEGIN
         RETURN CONVERT(float, YEAR(@Data)) * 10000 + CONVERT(float, MONTH(@Data)) * 100 + CONVERT(float, DAY(@Data));
     END;
GO

CREATE FUNCTION dbo.fn_DataStringaAAAAMMGG(@Data datetime)
RETURNS char(8)
AS
     BEGIN
         DECLARE @stringa char(8);

         DECLARE @mese nvarchar(2) = CONVERT(nvarchar(2) , DATEPART(mm, @Data ));
         IF LEN(@mese) = 1
         BEGIN
			SET @mese = '0' + @mese;
		 END;

         DECLARE @giorno nvarchar(2) = CONVERT(nvarchar(2), DATEPART(dd, @Data ));
         IF LEN(@giorno) = 1
         BEGIN
             SET @giorno = '0' + @giorno;
         END;

         SET @stringa = CONVERT(char(4), DATEPART(yyyy, @Data)) + @mese + @giorno;

         RETURN @stringa;
     END;
GO

-- ITEMS TABLE
CREATE TABLE Products(
             ID int , 
             Descrizione varchar( 35 ));
GO

-- INSERTING DATA 
INSERT INTO Products
VALUES
       (1, 'apple'),
       (2, 'orange'),
       (3, 'banana'),
       (4, 'kiwi'),
       (5, 'melon'),
       (6, 'watermelon');
GO

-- FUNCTION TO MANAGE THE ITEM DESCRIPTION
CREATE FUNCTION dbo.fn_ItemDescription(@Id int)
RETURNS varchar( 35 )
AS
     BEGIN
         RETURN( SELECT descrizione
                   FROM Products
                   WHERE ID = @Id );
     END;
GO

CREATE FUNCTION dbo.fn_GrossPrice(@Price int, @Vat int)
RETURNS int
AS
     BEGIN
         RETURN @Price + @Price * @Vat / 100;
     END;
GO

-- PRODUCTS CATALOG TABLE
CREATE TABLE [Catalog](
    ID INT IDENTITY(1,1) NOT NULL, 
    StartDate datetime , 
    EndDate datetime , 
    Price int, 
    Text varchar( 35 ) , 
    ProductID int , 
    Vat int );
GO



-- INSERTING DATA (16")
DECLARE @i int;
SET @i = 50000;
WHILE @i > 0
    BEGIN
        INSERT INTO Catalog (StartDate, EndDate, Price, Text, ProductID, Vat) 
        VALUES
               (GETDATE(), GETDATE(), 123, 'promotion ...', 2, 22);
        SET @i = @i - 1;
    END;
GO

SELECT *
  FROM Catalog;

SELECT COUNT(*)
  FROM Catalog; 



DBCC DROPCLEANBUFFERS;

-- EXTRACTING DATA WITH FUNCTIONS
SET STATISTICS IO ON;
SET STATISTICS TIME ON;
SELECT dbo.fn_DataStringaAAAAMMGG(StartDate) AS StartDate, 
       dbo.fn_DataNumericaAAAAMMGG(EndDate) AS EndDate, 
       Text, 
       dbo.fn_ItemDescription(ProductID) AS Prodotto, 
       dbo.fn_GrossPrice(Price, Vat) AS PriceLordo
  FROM Catalog;
SET STATISTICS TIME OFF;
SET STATISTICS IO OFF;
GO
/*

*/





-- EXTRACTING DATA WITH INLINE
SET STATISTICS IO ON;
SET STATISTICS TIME ON;
SELECT CONVERT(char(8), StartDate, 112) AS StartDate, 
       CONVERT(float, CONVERT(char(8), EndDate, 112)) AS EndDate, 
       Text, 
       Products.Descrizione AS Prodotto, 
       Price + Price * Vat / 100 AS PriceLordo
  FROM Catalog
       JOIN Products ON Products.ID = Catalog.ProductID;
SET STATISTICS TIME OFF;
SET STATISTICS IO OFF;
GO
/*

*/




