/*
	SQLSatSlovenia - 10.12.2016
	Performance tips forfaster SQL queries

	Emanuele Zanchettin
	ezanchettin@thinkit.it - www.thinkit.it
*/

USE SQLSatSlovenia;




-- INSERTING DATA 
TRUNCATE TABLE [Discount];
INSERT INTO [Discount] ([Code], Percentage, DateTime)
    SELECT TOP 500000
			Code  , 
		 CAST(Rand(CAST( NEWID() AS varbinary )) * 80 + 1 AS INT) 
		 , DATEADD(d, -CAST(Rand(CAST( NEWID() AS varbinary )) * 500 + 1 AS INT), GETDATE())
		 FROM [Stock]
		 ORDER BY CAST(CODE AS INT)

DBCC DROPCLEANBUFFERS;




-- EXTRACTING DATA PRODUCTS HAVING A DISCOUNT < 50% - SUBQUERY
SET STATISTICS IO ON;
SET STATISTICS TIME ON;
SELECT TOP 500001 [Stock].Code
		, [Stock].Quantity
		, (SELECT [Percentage] FROM Discount WHERE Code = [Stock].Code) AS [Percentage]
FROM [Stock]
WHERE ISNULL((SELECT [Percentage] FROM Discount WHERE Code = [Stock].Code), 0) < 50
SET STATISTICS TIME OFF;
SET STATISTICS IO OFF;
GO
/*

*/





SET STATISTICS IO ON;
SET STATISTICS TIME ON;
SELECT TOP 500001 [Stock].Code
		, [Stock].Quantity
		, [Discount].[Percentage]
FROM [Stock]
LEFT JOIN [Discount] ON Discount.Code = [Stock].Code AND [Percentage] < 50
SET STATISTICS TIME OFF;
SET STATISTICS IO OFF;
GO
/*

*/