/*
	SQLSatSlovenia - 10.12.2016
	Performance tips forfaster SQL queries

	Emanuele Zanchettin
	ezanchettin@thinkit.it - www.thinkit.it
*/

-- Create the database (12")
USE master;

GO
IF NOT EXISTS(SELECT * FROM sys.sysdatabases WHERE name = 'SQLSatSlovenia')
BEGIN
CREATE DATABASE SQLSatSlovenia
ON PRIMARY
  ( NAME = SQLSatSlovenia_dat,
      FILENAME = 'D:\temp\SQLSatSlovenia.mdf',
      SIZE = 500 MB,
      MAXSIZE = UNLIMITED,
      FILEGROWTH = 100 MB )
  LOG ON
  ( NAME = SQLSatSlovenia_log,
      FILENAME = 'D:\temp\SQLSatSlovenia.ldf',
      SIZE = 2 GB,
      MAXSIZE = UNLIMITED,
      FILEGROWTH = 100 MB ) ;
END
GO

SET STATISTICS TIME OFF;
SET STATISTICS IO OFF;


USE SQLSatSlovenia;


-- MANAGING WAREHOUSE MOVEMENTS
CREATE TABLE [dbo].[WarehouseMovements](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[ItemID] int NOT NULL,
	[Moviment] varchar(50) NOT NULL,
	[Quantity] int NOT NULL,
	[DateTime] datetime NOT NULL,
 CONSTRAINT [PK_WarehouseMovements] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)
) ON [PRIMARY]
GO




-- INSERTING DATA (1kk => 6", 10kk => 1')
--TRUNCATE TABLE [WarehouseMovements];

-- APPROACH ROW-BY-ROW (50k => 17")
DECLARE @i INT = 0;
WHILE (@i  < 50000)
BEGIN
  INSERT INTO [WarehouseMovements] (ItemID, Moviment, Quantity, DateTime)
    SELECT
            CAST(Rand(CAST( NEWID() AS varbinary )) * 100 + 1 AS INT) , 
			CASE CAST(Rand(CAST( NEWID() AS varbinary )) * 6 + 1 AS INT)
			WHEN 1 THEN 'DWN' -- DOWNLOAD NORMAL
			WHEN 2 THEN 'DWE' -- DOWNLOAD EMERGENCY
			WHEN 3 THEN 'DWC' -- DOWNLOAD CHECK
			WHEN 4 THEN 'DWA' -- DOWNLOAD APPARTMENT
			WHEN 5 THEN 'UPN' -- UPLOAD NORMAL
			WHEN 6 THEN 'UPE' -- UPLOAD EMERGENCY
			ELSE 'UPD'	      -- UPDATE
		END,
		 CAST(Rand(CAST( NEWID() AS varbinary )) * 100 + 1 AS INT) 
		 , DATEADD(d, -CAST(Rand(CAST( NEWID() AS varbinary )) * 500 + 1 AS INT), GETDATE());
	SET @i = @i + 1;
END

-- APPROACH ROW-SET (2kk => 19")
CREATE FUNCTION dbo.fn_numbers(@Start AS BIGINT,@End AS BIGINT) RETURNS TABLE
AS
RETURN
  WITH
  L0   AS(SELECT 1 AS c UNION ALL SELECT 1),
  L1   AS(SELECT 1 AS c FROM L0 AS A, L0 AS B),
  L2   AS(SELECT 1 AS c FROM L1 AS A, L1 AS B),
  L3   AS(SELECT 1 AS c FROM L2 AS A, L2 AS B),
  L4   AS(SELECT 1 AS c FROM L3 AS A, L3 AS B),
  L5   AS(SELECT 1 AS c FROM L4 AS A, L4 AS B),
  Nums AS(SELECT ROW_NUMBER() OVER(ORDER BY c) AS n FROM L5)
  SELECT n FROM Nums 
  WHERE n between  @Start and @End;  
GO  

INSERT INTO [WarehouseMovements] (ItemID, Moviment, Quantity, DateTime)
    SELECT
			CAST(Rand(CAST( NEWID() AS varbinary )) * 100 + 1 AS INT) , 
			CASE CAST(Rand(CAST( NEWID() AS varbinary )) * 6 + 1 AS INT)
			WHEN 1 THEN 'DWN' -- DOWNLOAD NORMAL
			WHEN 2 THEN 'DWE' -- DOWNLOAD EMERGENCY
			WHEN 3 THEN 'DWC' -- DOWNLOAD CHECK
			WHEN 4 THEN 'DWA' -- DOWNLOAD APPARTMENT
			WHEN 5 THEN 'UPN' -- UPLOAD NORMAL
			WHEN 6 THEN 'UPE' -- UPLOAD EMERGENCY
			ELSE 'UPD'	      -- UPDATE
		END,
		 CAST(Rand(CAST( NEWID() AS varbinary )) * 100 + 1 AS INT) 
		 , DATEADD(d, -CAST(Rand(CAST( NEWID() AS varbinary )) * 500 + 1 AS INT), GETDATE())
		 FROM dbo.fn_numbers(1, 2000000) Nums


-- CREATING INDEX NONCLUSTERED FOR SEARCHING
CREATE NONCLUSTERED INDEX IX_Movement ON dbo.[WarehouseMovements]
	(
	Moviment
	) 
	INCLUDE (ItemID, Quantity, DateTime)
	WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]


-- CHECKING INTERTED RECORDS
SELECT TOP 10 *
FROM [WarehouseMovements]

SELECT count(*)
FROM [WarehouseMovements]


-- REQUEST: EXTRACTING ALL EMERGENCY MOVEMENTS (UPLOAD-DOWNLOAD) OF LAST 90DAYS (execution plan)
DBCC DROPCLEANBUFFERS;

SET STATISTICS TIME ON;
SET STATISTICS IO ON;

SELECT [Moviment], COUNT(*)
FROM [WarehouseMovements]
WHERE [Moviment] LIKE '%E' AND DateTime >= DATEADD(d, -90, GETDATE())
GROUP BY [Moviment];

SET STATISTICS TIME OFF;
SET STATISTICS IO OFF;
/*

 */



 -- CREATING MISSING INDEX AS ADVISED
 CREATE NONCLUSTERED INDEX IX2_Movement ON dbo.[WarehouseMovements]
	(
	DateTime
	) 
	INCLUDE (Moviment)
	WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]


-- RETRY DATA EXTRACTION
/*

*/



-- CREATING A TABLE OF MOVEMENTS TYPE
CREATE TABLE [dbo].[MovementType](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[Moviment] varchar(3) NOT NULL,
 CONSTRAINT [PK_MovementType] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)
) ON [PRIMARY]

INSERT INTO [MovementType] ([Moviment]) VALUES ('DWN'), ('DWE'), ('DWC'), ('DWA'), ('UPN'), ('UPE'), ('UPD');

CREATE NONCLUSTERED INDEX IX_MovementType ON dbo.MovementType
	(
	Moviment
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]






-- Solution 1: ADD A COLUMN AT THE END OF TABLE (17")
ALTER TABLE dbo.WarehouseMovements ADD
	MovementTypeID int NULL;
GO
UPDATE dbo.WarehouseMovements
SET MovementTypeID = [MovementType].id
FROM dbo.WarehouseMovements
INNER JOIN [dbo].[MovementType] ON [MovementType].Moviment = WarehouseMovements.Moviment;
-- Solution 1: END




-- Solution 2: ADD A COLUMNS IN THE MIDDLE, RIGHT POSITION (47")
CREATE TABLE dbo.Tmp_WarehouseMovements
	(
	id int NOT NULL IDENTITY (1, 1),
	ItemID int NOT NULL,
	Moviment varchar(50) NOT NULL,
	MovementTypeID int NULL,
	Quantity int NOT NULL,
	DateTime datetime NOT NULL
	)  ON [PRIMARY]
GO
SET IDENTITY_INSERT dbo.Tmp_WarehouseMovements ON
GO
INSERT INTO dbo.Tmp_WarehouseMovements (id, ItemID, Moviment, MovementTypeID, Quantity, DateTime)
SELECT WarehouseMovements.id, ItemID, WarehouseMovements.Moviment, [MovementType].id, Quantity, DateTime 
FROM dbo.WarehouseMovements
INNER JOIN [dbo].[MovementType] ON [MovementType].Moviment = WarehouseMovements.Moviment;
		
SET IDENTITY_INSERT dbo.Tmp_WarehouseMovements OFF
GO
DROP TABLE dbo.WarehouseMovements
GO
EXECUTE sp_rename N'dbo.Tmp_WarehouseMovements', N'WarehouseMovements', 'OBJECT' 
GO
-- RECREATE PK and INDEXES
ALTER TABLE dbo.WarehouseMovements ADD CONSTRAINT
	PK_WarehouseMovements PRIMARY KEY CLUSTERED 
	(
	id
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

GO
CREATE NONCLUSTERED INDEX IX_Movement ON dbo.WarehouseMovements
	(
	Moviment
	) 
	INCLUDE (ItemID, Quantity, DateTime)
	WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
-- Solution 2: END





-- ADDING FK
ALTER TABLE dbo.WarehouseMovements ADD CONSTRAINT
	FK_WarehouseMovements_MovementType FOREIGN KEY
	(
	MovementTypeID
	) REFERENCES dbo.MovementType
	(
	id
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 
	
GO

-- RETRY DATA EXTRACTION (execution plan)
DBCC DROPCLEANBUFFERS;

SET STATISTICS TIME ON;
SET STATISTICS IO ON;

SELECT [MovementType].[Moviment], COUNT(*)
FROM [WarehouseMovements]
INNER JOIN [MovementType] ON [MovementType].id = [WarehouseMovements].MovementTypeID
WHERE [MovementType].[Moviment] LIKE '%E' AND DateTime >= DATEADD(d, -90, GETDATE())
GROUP BY [MovementType].[Moviment];

SET STATISTICS TIME OFF;
SET STATISTICS IO OFF;

/*

*/



-- INDEX ADVISED ... DON'T USE IT, USE YOUR HEAD TO DESIGN IT!!
CREATE NONCLUSTERED INDEX IX_MovementTypeID ON dbo.WarehouseMovements
	(
	DateTime
	)
	INCLUDE (MovementTypeID)
	 WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

-- RETRY DATA EXTRACTION WITH ADVISED INDEX
/*

*/



-- DESIGNED INDEX 
CREATE NONCLUSTERED INDEX IX2_MovementTypeID ON dbo.WarehouseMovements
	(
	MovementTypeID
	)
	INCLUDE (DateTime)
	 WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

-- RETRY DATA EXTRACTION WITH DESIGNED INDEX
/*

*/
