/*
	SQLSatSlovenia - 10.12.2016
	Performance tips forfaster SQL queries

	Emanuele Zanchettin
	ezanchettin@thinkit.it - www.thinkit.it
*/

USE SQLSatSlovenia;


-- ITEM TABLE (es. db third parties)
CREATE TABLE [dbo].[Stock](
	[Code] varchar(50) NOT NULL,
	[Quantity] int NOT NULL,
	[DateTime] datetime NOT NULL,
 CONSTRAINT [PK_Stock] PRIMARY KEY CLUSTERED 
(
	[Code] ASC
)
) ON [PRIMARY]
GO

-- INSERTING DATA (1kk => 6", 10kk => 1')
--TRUNCATE TABLE [Stock];

-- ROW-SET APPROACH (2kk => 19")
INSERT INTO [Stock] ([Code], Quantity, DateTime)
    SELECT
			n , 
		 CAST(Rand(CAST( NEWID() AS varbinary )) * 100 + 1 AS INT) 
		 , DATEADD(d, -CAST(Rand(CAST( NEWID() AS varbinary )) * 500 + 1 AS INT), GETDATE())
		 FROM dbo.fn_numbers(1, 2000000) Nums


-- CHECKING INSERTED RECORDS
SELECT TOP 10 *
FROM [Stock]

SELECT count(*)
FROM [Stock]





-- CUSTOMIZING PROMOTIONS
CREATE TABLE [dbo].[Discount](
	[Code] INT NOT NULL,
	[Percentage] int NOT NULL,
	[DateTime] datetime NOT NULL,
 CONSTRAINT [PK_Discount] PRIMARY KEY CLUSTERED 
(
	[Code] ASC
)
) ON [PRIMARY]
GO

-- INSETING DATA (1kk => 6", 10kk => 1')
--TRUNCATE TABLE [Discount];
INSERT INTO [Discount] ([Code], Percentage, DateTime)
    SELECT
			n  , 
		 CAST(Rand(CAST( NEWID() AS varbinary )) * 80 + 1 AS INT) 
		 , DATEADD(d, -CAST(Rand(CAST( NEWID() AS varbinary )) * 500 + 1 AS INT), GETDATE())
		 FROM dbo.fn_numbers(1, 2000) Nums

SELECT TOP 10 *
FROM [Discount]

SELECT count(*)
FROM [Discount]

-- EXTRACTING DATA (execution plan)
DBCC DROPCLEANBUFFERS;

SET STATISTICS IO ON;
SET STATISTICS TIME ON;

SELECT Discount.[Code], Discount.[Percentage], Stock.Quantity
FROM Stock
INNER JOIN Discount ON Discount.Code = Stock.Code

SET STATISTICS TIME OFF;
SET STATISTICS IO OFF;

/*

*/






-- CHANGING CODE COLUMN DATA TYPE (1")
CREATE TABLE dbo.Tmp_Discount
	(
	[Code] varchar(50) NOT NULL,
	[Percentage] int NOT NULL,
	[DateTime] datetime NOT NULL,
 CONSTRAINT [PK_Discount_ok] PRIMARY KEY CLUSTERED 
(
	[Code] ASC
)
) ON [PRIMARY]
GO
INSERT INTO dbo.Tmp_Discount ([Code], [Percentage], DateTime)
SELECT [Code], [Percentage], DateTime
FROM  dbo.Discount
GO
DROP TABLE dbo.Discount
GO
EXECUTE sp_rename N'dbo.Tmp_Discount', N'Discount', 'OBJECT' 
GO

-- ADDING FK
ALTER TABLE dbo.Discount ADD CONSTRAINT
	FK_Discount_Stock FOREIGN KEY
	(
	Code
	) REFERENCES dbo.Stock
	(
	Code
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 
	
GO



DBCC DROPCLEANBUFFERS;

SET STATISTICS IO ON;
SET STATISTICS TIME ON;

SELECT Discount.[Code], Discount.[Percentage], Stock.Quantity
FROM Stock
INNER JOIN Discount ON Discount.Code = Stock.Code

SET STATISTICS TIME OFF;
SET STATISTICS IO OFF;

/*

*/

