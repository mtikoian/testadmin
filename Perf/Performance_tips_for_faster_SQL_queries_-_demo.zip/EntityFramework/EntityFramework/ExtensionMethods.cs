﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntityFramework
{
    internal static class ExtensionMethods
    {
        public static bool Contains(this string source, string stringToSearch, StringComparison comparison)
        {
            return source.IndexOf(stringToSearch, comparison) >= 0;
        }
    }
}
