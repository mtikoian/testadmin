﻿using System;
using System.Data.Common;
using System.Data.Entity.Infrastructure.Interception;

namespace EntityFramework
{
    public class LoggerInterceptor : IDbCommandInterceptor
    {
        private readonly ILogger _logger;

        public LoggerInterceptor(ILogger logger)
        {
            if (logger == null)
            {
                throw new ArgumentNullException("logger");
            }
            _logger = logger;
        }

        public void NonQueryExecuted(DbCommand command, DbCommandInterceptionContext<int> interceptionContext)
        {
            LogIfExceptionOccurs(interceptionContext, string.Format("NonQuery command: {0}\n", command.CommandText));
        }

        public void NonQueryExecuting(DbCommand command, DbCommandInterceptionContext<int> interceptionContext)
        {
            _logger.WriteLog(string.Format("Executing NonQuery command: {0}\n", command.CommandText));
        }

        public void ReaderExecuted(DbCommand command, DbCommandInterceptionContext<DbDataReader> interceptionContext)
        {
            LogIfExceptionOccurs(interceptionContext, string.Format("Reader command: {0}\n", command.CommandText));
        }

        public void ReaderExecuting(DbCommand command, DbCommandInterceptionContext<DbDataReader> interceptionContext)
        {
            _logger.WriteLog(string.Format("Executing Reader command: {0}\n", command.CommandText));
        }

        public void ScalarExecuted(DbCommand command, DbCommandInterceptionContext<object> interceptionContext)
        {
            LogIfExceptionOccurs(interceptionContext, string.Format("Scalar command: {0}\n", command.CommandText));
        }

        public void ScalarExecuting(DbCommand command, DbCommandInterceptionContext<object> interceptionContext)
        {
            _logger.WriteLog(string.Format("Executing Scalar command: {0}\n", command.CommandText));
        }

        private void LogIfExceptionOccurs<T>(DbCommandInterceptionContext<T> interceptionContext, string message)
        {
            if (interceptionContext.Exception != null)
            {
                _logger.WriteLog(message);
                _logger.WriteLog(string.Format("Returned error during execution: {0}\n", interceptionContext.Exception.Message));
            }
        }
    }
}
