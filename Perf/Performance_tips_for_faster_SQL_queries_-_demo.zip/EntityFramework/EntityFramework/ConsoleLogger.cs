﻿using System;

namespace EntityFramework
{
    public class ConsoleLogger : ILogger
    {
        public void WriteLog(string message)
        {
            Console.Write(message);
        }
    }
}
