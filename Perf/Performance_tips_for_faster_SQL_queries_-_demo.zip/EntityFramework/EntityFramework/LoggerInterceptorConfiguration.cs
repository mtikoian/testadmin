﻿using System.Data.Entity;

namespace EntityFramework
{
    public class LoggerInterceptorConfiguration : DbConfiguration
    {

        protected internal LoggerInterceptorConfiguration()
            : base()
        {
        }

        public LoggerInterceptorConfiguration(ILogger logger)
        {
            AddInterceptor(new LoggerInterceptor(logger));
        }
    }
}
