DBCC FREEPROCCACHE

ALTER DATABASE SCOPED CONFIGURATION CLEAR PROCEDURE_CACHE;
GO

SELECT SalesOrderID, SalesOrderDetailID 
FROM [dbo].[SalesOrderDetailBIG] 
WHERE SalesOrderID = 71784 
GO 25

SELECT SalesOrderID, SalesOrderDetailID 
FROM [dbo].[SalesOrderDetailBIG] 
WHERE SalesOrderDetailID = 113283 
GO 50

SELECT usecounts, cacheobjtype, objtype, text 
FROM sys.dm_exec_cached_plans 
CROSS APPLY sys.dm_exec_sql_text(plan_handle) 
WHERE usecounts > 1 and objtype IN(N'Adhoc', N'Prepared')
ORDER BY usecounts DESC;
GO

--Enable show execution plan, show table scan and cost threshold value
SELECT SalesOrderID, SalesOrderDetailID 
FROM [dbo].[SalesOrderDetailBIG] 
WHERE SalesOrderDetailID = 113283 

--Create a covering index for the query, takes approx 30 seconds
CREATE NONCLUSTERED INDEX [IX_SalesOrderDetail_SaleOrderDetailID] ON [dbo].[SalesOrderDetailBIG]  ( SalesOrderDetailID ASC) INCLUDE ( SalesOrderID) 

--Enable show execution plan, show table scan and cost threshold value after the index creation
SELECT SalesOrderID, SalesOrderDetailID 
FROM [dbo].[SalesOrderDetailBIG]  
WHERE SalesOrderDetailID = 113283 

--Cleanup index
DROP INDEX [IX_SalesOrderDetail_SaleOrderDetailID] ON [dbo].[SalesOrderDetailBIG] WITH ( ONLINE = OFF )
