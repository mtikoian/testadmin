/*============================================================================
  File:     IOLatenciesAzure.sql
 
  Summary:  file stats
 
  Azure SQL Database
------------------------------------------------------------------------------
  Written by Paul S. Randal, SQLskills.com
  Modified for Azure SQL Database by Tim Radney, SQLskills.com
 
  (c) 2016, SQLskills.com. All rights reserved.
 
  For more scripts and sample code, check out http://www.SQLskills.com
 
  You may alter this code for your own *non-commercial* purposes (e.g. in a
  for-sale commercial tool). Use in your own environment is encouraged.
  You may republish altered code as long as you include this copyright and
  give due credit, but you must obtain prior permission before blogging
  this code.
 
  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF
  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED
  TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
  PARTICULAR PURPOSE.
============================================================================*/
SELECT  [ReadLatency] = CASE WHEN [num_of_reads] = 0 THEN 0
                             ELSE ( [io_stall_read_ms] / [num_of_reads] )
                        END ,
        [WriteLatency] = CASE WHEN [num_of_writes] = 0 THEN 0
                              ELSE ( [io_stall_write_ms] / [num_of_writes] )
                         END ,
        [Latency] = CASE WHEN ( [num_of_reads] = 0
                                AND [num_of_writes] = 0
                              ) THEN 0
                         ELSE ( [io_stall] / ( [num_of_reads]
                                               + [num_of_writes] ) )
                    END ,
        [AvgBPerRead] = CASE WHEN [num_of_reads] = 0 THEN 0
                             ELSE ( [num_of_bytes_read] / [num_of_reads] )
                        END ,
        [AvgBPerWrite] = CASE WHEN [num_of_writes] = 0 THEN 0
                              ELSE ( [num_of_bytes_written] / [num_of_writes] )
                         END ,
        [AvgBPerTransfer] = CASE WHEN ( [num_of_reads] = 0
                                        AND [num_of_writes] = 0
                                      ) THEN 0
                                 ELSE ( ( [num_of_bytes_read]
                                          + [num_of_bytes_written] )
                                        / ( [num_of_reads] + [num_of_writes] ) )
                            END ,
        DB_NAME([vfs].[database_id]) AS [DB],
		[vfs].[file_id] AS [File_id]
FROM    sys.dm_io_virtual_file_stats(NULL, NULL) AS [vfs]
        JOIN sys.databases AS [mf] ON [vfs].[database_id] = [mf].[database_id]
WHERE [mf].[database_id] != '1'
ORDER BY [WriteLatency] DESC;
GO
