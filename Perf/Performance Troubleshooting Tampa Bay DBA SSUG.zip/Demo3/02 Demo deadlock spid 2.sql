if exists(select name from sys.tables where name='t1')
begin
	drop table t1
end
go
create table t1(c1 int);
insert into t1 values(1);
go
begin tran
	update t1 set c1=2
go

select * from t2

--rollback tran