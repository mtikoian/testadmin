if exists(select name from sys.tables where name='t2')
begin
	drop table t2
end
go
create table t2(c1 int)
insert into t2 values(1)
go
begin tran
update t2 set c1=2
go



select * from t1
