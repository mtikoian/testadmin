/*============================================================
--http://www.SQLBalls.com
--@SQLBalls: SQLBalls@gmail.com
--Performance Troubleshooting
--

This Sample Code is provided for the purpose of illustration only and is not intended
to be used in a production environment.  THIS SAMPLE CODE AND ANY RELATED INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.

==============================================================*/

USE demoCOMPRESSION_Partition
GO

/*
Copy To Another Window
USE demoCOMPRESSION_Partition
GO
SELECT
	*
FROM
	dbo.mytable1
*/

BEGIN TRANSACTION

UPDATE dbo.myTable1
SET productName='Pragmatic Works Demo'
WHERE myid=18000

ROLLBACK TRANSACTION        


/*
DMV's
Copy To Another Windows
SELECT 
DB_NAME(der.database_id)
,der.session_id
,der.blocking_session_id
,der.command
,der.status
,der.wait_type
,der.wait_resource
FROM sys.dm_exec_requests der
left join sys.dm_exec_sessions es
on der.session_id=es.session_id
WHERE DB_NAME(der.database_id)='demoCOMPRESSION_Partition'
and es.is_user_process=1


SELECT 
	session_id,
	status
FROM 
	sys.dm_exec_sessions 
WHERE 
	session_id=52

select 
	*
from
	sys.dm_tran_locks

*/

/*
Copy To Another Window

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

USE demoCOMPRESSION_Partition
GO
SELECT
	*
FROM
	dbo.mytable1
WHERE
	myID=18000
*/

ALTER DATABASE MyDatabase
SET ALLOW_SNAPSHOT_ISOLATION ON

ALTER DATABASE MyDatabase
SET READ_COMMITTED_SNAPSHOT ON


