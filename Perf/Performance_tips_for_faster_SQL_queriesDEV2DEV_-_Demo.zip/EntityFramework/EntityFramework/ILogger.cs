﻿namespace EntityFramework
{
    public interface ILogger
    {
        void WriteLog(string message);
    }
}
