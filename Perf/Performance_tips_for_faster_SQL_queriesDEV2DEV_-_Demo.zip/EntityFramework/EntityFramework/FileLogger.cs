﻿using System;
using System.IO;

namespace EntityFramework
{
    public class FileLogger : ILogger
    {
        private readonly string _fileName;
        public FileLogger(string fileName)
        {
            if (fileName == null)
            {
                throw new ArgumentNullException(fileName);
            }
            _fileName = fileName;
        }
        public void WriteLog(string message)
        {
            using (var writer = File.AppendText(_fileName))
            {
                writer.WriteLine(message);
            }
        }
    }
}
