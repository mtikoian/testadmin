﻿/*
	SQLSatDublin - 17.06.2017
	Performance tips forfaster SQL queries

	Emanuele Zanchettin
	ezanchettin@thinkit.it - www.thinkit.it
*/
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntityFramework
{
    class Program
    {
        static void Main(string[] args)
        {
            // Welcome screen
            Console.WriteLine("*********************************************************");
            Console.WriteLine("***         Welcome to Entity Framework DEMO          ***");
            Console.WriteLine("***            #SQLSatDublin - 17.06.2017             ***");
            Console.WriteLine("*** open SSMS and Profiler, database in use Northwind ***");
            Console.WriteLine("*********************************************************");
            Console.WriteLine();

            // Connection succeeded. Begin interactive loop
            MenuLoop();
        }

        #region Program control flow

        /// <summary>
        /// Main program loop.
        /// </summary>
        private static void MenuLoop()
        {

            // Loop until the user chose "Exit".
            bool continueLoop;
            do
            {

                PrintMenu();
                Console.WriteLine();

                continueLoop = GetMenuChoiceAndExecute();
                Console.WriteLine();
            }
            while (continueLoop);
        }

        private const ConsoleColor EnabledColor = ConsoleColor.White; // color for items that are expected to succeed
        private const ConsoleColor DisabledColor = ConsoleColor.DarkGray; // color for items that are expected to fail
        private static bool[] usedMenuItem = { false, false, false, false, false, false, false, false, false, false, false, false, false };

        /// <summary>
        /// Writes the program menu.
        /// </summary>
        private static void PrintMenu()
        {
            ConsoleColor createSmmColor; // color for create shard map manger menu item
            ConsoleColor otherMenuItemColor; // color for other menu items

            createSmmColor = EnabledColor;
            otherMenuItemColor = DisabledColor;

            ConsoleUtils.WriteColor(usedMenuItem[1] ? otherMenuItemColor : createSmmColor, "1. Filtering data Client Side");
            ConsoleUtils.WriteColor(usedMenuItem[2] ? otherMenuItemColor : createSmmColor, "2. Filtering data Server Side");
            ConsoleUtils.WriteColor(usedMenuItem[3] ? otherMenuItemColor : createSmmColor, "3. Filtering data Server Side (optimized)");
            ConsoleUtils.WriteColor(usedMenuItem[4] ? otherMenuItemColor : createSmmColor, "4. Filtering data Server Side using Projection");
            ConsoleUtils.WriteColor(usedMenuItem[5] ? otherMenuItemColor : createSmmColor, "5. Extract data about Country Sales");
            ConsoleUtils.WriteColor(usedMenuItem[6] ? otherMenuItemColor : createSmmColor, "6. Extract data about Country Sales (optimized)");
            ConsoleUtils.WriteColor(usedMenuItem[7] ? otherMenuItemColor : createSmmColor, "7. Extract data about Country Sales using Projection");
            ConsoleUtils.WriteColor(usedMenuItem[8] ? otherMenuItemColor : createSmmColor, "8. Extract data about Country Sales without loop (!?!?)");
            ConsoleUtils.WriteColor(usedMenuItem[9] ? otherMenuItemColor : createSmmColor, "9. Try to debug using ToString()");
            ConsoleUtils.WriteColor(usedMenuItem[10] ? otherMenuItemColor : createSmmColor, "10. Try to debug using Custom Logger to console");
            ConsoleUtils.WriteColor(usedMenuItem[11] ? otherMenuItemColor : createSmmColor, "11. Try to debug using Custom Logger to file");
            ConsoleUtils.WriteColor(usedMenuItem[12] ? otherMenuItemColor : createSmmColor, "12. Try to debug using Interception to file (!?!?)");
            ConsoleUtils.WriteColor(EnabledColor, "13. Exit");
        }

        /// <summary>
        /// Gets the user's chosen menu item and executes it.
        /// </summary>
        /// <returns>true if the program should continue executing.</returns>
        private static bool GetMenuChoiceAndExecute()
        {
            ILogger consoleLogger = new ConsoleLogger();
            ILogger fileLogger = new FileLogger(@"C:\Temp\SQLSatDublin2017\EntityFrameworkLog.txt");

            while (true)
            {
                int menuValue = ConsoleUtils.ReadIntegerInput("Enter an option [1-13] and press ENTER: ");

                if (menuValue < usedMenuItem.Length)
                    usedMenuItem[menuValue] = true;

                switch (menuValue)
                {
                    case 1: // Try to filter data Client Side
                        Console.WriteLine();
                        FilteringClientSide();
                        return true;
                    case 2: // Try to filter data Server Side
                        Console.WriteLine();
                        FilteringServerSide();
                        return true;
                    case 3: // Try to filter data Server Side (Optimized)
                        Console.WriteLine();
                        FilteringServerSideOptimized();
                        return true;
                    case 4: // Try to filter data Server Side using Projection
                        Console.WriteLine();
                        FilteringServerSideProjection();
                        return true;
                    case 5: // Try to extract data about Country Sales (row by row)
                        Console.WriteLine();
                        ExtractDataCountrySales();
                        return true;
                    case 6: // Try to extract data about Country Sales (Optimized)
                        Console.WriteLine();
                        ExtractDataCountrySalesOptimized();
                        return true;
                    case 7: // Try to extract data about Country Sales using Projection
                        Console.WriteLine();
                        ExtractDataCountrySalesProjection();
                        return true;
                    case 8: // Try to extract data about Country Sales without loop (!?!?)
                        Console.WriteLine();
                        ExtractDataCountrySalesProjectionMad();
                        return true;
                    case 9: // Try to debug using ToString()
                        Console.WriteLine();
                        DebugUsingToString();
                        return true;
                    case 10: // Try to debug using Custom Logger to console
                        Console.WriteLine();
                        DebugUsingCustomLogger(consoleLogger);
                        return true;
                    case 11: // Try to debug using Custom Logger to file
                        Console.WriteLine();
                        DebugUsingCustomLogger(fileLogger);
                        return true;
                    case 12: // Try to debug using Interception to file
                        Console.WriteLine();
                        DebugUsingInterception(fileLogger);
                        return true;
                    case 13: // Exit
                        return false;
                }
            }
        }

        #endregion  

        private static void FilteringClientSide()
        {
            string value = ConsoleUtils.ReadStringInput("Enter a value for ProductName and press ENTER: ");

            using (northwindEntities myEntities = new northwindEntities())
            {
                IEnumerable<Products> productsQuery = from product in myEntities.Products
                                                        select product;

                bool found = false;
                foreach (Products product in productsQuery)
                {
                    if (product.ProductName.Contains(value, StringComparison.CurrentCultureIgnoreCase))
                    {
                        Console.WriteLine("Product: {0} {1} - Price: {2}",
                            product.ProductID,
                            product.ProductName,
                            product.UnitPrice);
                        found = true;
                    }
                }

                if (!found)
                    Console.WriteLine("No Products found");

            }
        }

        private static void FilteringServerSide()
        {
            string value = ConsoleUtils.ReadStringInput("Enter a value for ProductName and press ENTER: ");

            using (northwindEntities myEntities = new northwindEntities())
            {
                IEnumerable<Products> productsQuery = from product in myEntities.Products
                                                      where product.ProductName.Contains(value)
                                                        select product;

                foreach (Products product in productsQuery)
                {
                    Console.WriteLine("Product: {0} {1} - Price: {2}",
                        product.ProductID,
                        product.ProductName,
                        product.UnitPrice);
                }

                if (productsQuery.Count() == 0)
                    Console.WriteLine("No Products found");
            }
        }

        private static void FilteringServerSideOptimized()
        {
            string value = ConsoleUtils.ReadStringInput("Enter a value for ProductName and press ENTER: ");

            using (northwindEntities myEntities = new northwindEntities())
            {
                IEnumerable<Products> productsQuery = from product in myEntities.Products
                                                      where product.ProductName.Contains(value)
                                                        select product;

                List<Products> products = productsQuery.ToList();

                foreach (Products product in products)
                {
                    Console.WriteLine("Product: {0} {1} - Price: {2}",
                        product.ProductID,
                        product.ProductName,
                        product.UnitPrice);
                }

                if (products.Count() == 0)
                    Console.WriteLine("No Products found");
            }
        }

        private static void FilteringServerSideProjection()
        {
            string value = ConsoleUtils.ReadStringInput("Enter a value for ProductName and press ENTER: ");

            using (northwindEntities myEntities = new northwindEntities())
            {
                var productsQuery = from product in myEntities.Products
                                    where product.ProductName.Contains(value)
                                    select new
                                    {
                                        product.ProductID,
                                        product.ProductName,
                                        product.UnitPrice
                                    };

                bool found = false;
                foreach (var product in productsQuery)
                {
                    Console.WriteLine("Product: {0} {1} - Price: {2}",
                        product.ProductID,
                        product.ProductName,
                        product.UnitPrice);
                        found = true;
                }

                if (!found)
                    Console.WriteLine("No Products found");

            }
        }

        private static void ExtractDataCountrySales()
        {
            string value = ConsoleUtils.ReadStringInput("Enter a value for ShipCountry and press ENTER: ");

            using (northwindEntities myEntities = new northwindEntities())
            {
                IEnumerable<Orders> ordersQuery = from order in myEntities.Orders
                                                  where order.ShipCountry == value
                                                  select order;

                decimal salesTotal = 0;
                foreach (Orders order in ordersQuery)
                {
                    foreach (Order_Details detail in order.Order_Details)
                    {
                        salesTotal += detail.Quantity * detail.UnitPrice;
                    }
                }
                Console.WriteLine("Sales amount: {0:N}", salesTotal);
            }
        }

        private static void ExtractDataCountrySalesOptimized()
        {
            string value = ConsoleUtils.ReadStringInput("Enter a value for ShipCountry and press ENTER: ");

            using (northwindEntities myEntities = new northwindEntities())
            {
                IEnumerable<Orders> ordersQuery = from order in myEntities.Orders.Include(p => p.Order_Details) //.Orders.Include("Order_Details")
                                                  where order.ShipCountry == value
                                                  select order;

                decimal orderTotal = 0;
                foreach (Orders order in ordersQuery)
                {
                    foreach (Order_Details detail in order.Order_Details)
                    {
                        orderTotal += detail.Quantity * detail.UnitPrice;
                    }
                }
                Console.WriteLine("Sales amount: {0:N}", orderTotal);
            }
        }

        private static void ExtractDataCountrySalesProjection()
        {
            string value = ConsoleUtils.ReadStringInput("Enter a value for ShipCountry and press ENTER: ");

            using (northwindEntities myEntities = new northwindEntities())
            {

                var ordersQuery = myEntities.Orders
                                  .Where(order => order.ShipCountry == value)
                                  .SelectMany(order => order.Order_Details)
                                  .Select(od => new
                                  {
                                      Quantity = od.Quantity,
                                      UnitPrice = od.UnitPrice
                                  });

                decimal orderTotal = 0;
                foreach (var detail in ordersQuery)
                {
                    orderTotal += detail.Quantity * detail.UnitPrice;
                }
                Console.WriteLine("Sales amount: {0:N}", orderTotal);
           
            }
        }

        private static void ExtractDataCountrySalesProjectionMad()
        {
            string value = ConsoleUtils.ReadStringInput("Enter a value for ShipCountry and press ENTER: ");

            using (northwindEntities myEntities = new northwindEntities())
            {

                Console.WriteLine("Sales amount: {0:N}", myEntities.Orders
                                  .Where(order => order.ShipCountry == value)
                                  .SelectMany(order => order.Order_Details)
                                  .Sum(od => od.Quantity * od.UnitPrice));

            }
        }

        public static void DebugUsingToString()
        {

            string value = ConsoleUtils.ReadStringInput("Enter a value for City and press ENTER: ");

            using (northwindEntities myEntities = new northwindEntities())
            {
                var ordersQuery = myEntities.Orders
                    .Where(o => o.Customers.City == value)
                    .OrderBy(o => o.Customers.CompanyName);

                Console.WriteLine(ordersQuery.ToString());

                foreach (var order in ordersQuery.ToList())
                {
                    Console.WriteLine("Company Name: {0} - Order number: {1} - Order amount: {2:N2}",
                        order.Customers.CompanyName,
                        order.OrderID,
                        order.Order_Details.Sum(od => od.Quantity * od.UnitPrice));
                }

            }
        }

        public static void DebugUsingCustomLogger(ILogger logger)
        {
            string value = ConsoleUtils.ReadStringInput("Enter a value for City and press ENTER: ");

            using (northwindEntities myEntities = new northwindEntities())
            {
                myEntities.Database.Log = logger.WriteLog;

                var ordersQuery = myEntities.Orders
                    .Where(o => o.Customers.City == value)
                    .OrderBy(o => o.Customers.CompanyName);

                foreach (var order in ordersQuery.ToList())
                {
                    Console.WriteLine("Company Name: {0} - Order number: {1} - Order amount: {2:N2}",
                        order.Customers.CompanyName,
                        order.OrderID,
                        order.Order_Details.Sum(od => od.Quantity * od.UnitPrice));
                }

            }
        }

        public static void DebugUsingInterception(ILogger logger)
        {
            string value = ConsoleUtils.ReadStringInput("Enter a value for City and press ENTER: ");

            // Let Entity Framework use our interceptor.
            DbConfiguration.SetConfiguration(new LoggerInterceptorConfiguration(logger));

            using (northwindEntities myEntities = new northwindEntities())
            {
                var ordersQuery = myEntities.Order_Details
                    .Where(od => od.Orders.Customers.City == value)
                    .GroupBy(o => new
                    {
                        o.OrderID,
                        o.Orders.Customers.CompanyName
                    })
                    .OrderBy(k => k.Key.CompanyName)
                    .Select(o => new
                    {
                        OrderNumber = o.Key.OrderID,
                        o.Key.CompanyName,
                        OrderAmount = o.Sum(d => d.Quantity * d.UnitPrice)
                    });

                foreach (var o in ordersQuery.ToList())
                {
                    Console.WriteLine("Company Name: {0} - Order number: {1} - Order amount: {2:N2}",
                        o.CompanyName,
                        o.OrderNumber,
                        o.OrderAmount);
                }

            }
        }

    }
}
