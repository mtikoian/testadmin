/*
	SQLSatDublin 2017 - 17.06.2017
	Performance tips forfaster SQL queries

	Emanuele Zanchettin
	ezanchettin@thinkit.it - @_thinkIT_
*/

USE [northwind];

-- SCENARIO 7: A COMPANY THAT SELL ITS PRODUCTS AROUND THE WORLD

-- EXTRACTING SOLD PRODUCTS PER COUNTRY, TOTAL PER COUNTRY AND GRAN TOTAL (Execution plan CTRL+M)
DBCC DROPCLEANBUFFERS;

SET STATISTICS TIME ON;
SET STATISTICS IO ON;

SELECT ShipCountry, ProductName, Price
FROM (

-- EXTRACTING SOLD PRODUCTmS PER COUNTRY 
SELECT ShipCountry, ProductName, SUM([Order Details].UnitPrice * [Order Details].Quantity) AS Price
FROM [Order Details]
INNER JOIN [Products] ON Products.ProductID = [Order Details].ProductID
INNER JOIN [Orders] ON [Orders].OrderID = [Order Details].OrderID
GROUP BY ShipCountry, ProductName

UNION 

-- EXTRACTING TOTAL PER COUNTRY
SELECT ShipCountry, NULL AS ProductName, SUM([Order Details].UnitPrice * [Order Details].Quantity) AS Price
FROM [Order Details]
INNER JOIN [Products] ON Products.ProductID = [Order Details].ProductID
INNER JOIN [Orders] ON [Orders].OrderID = [Order Details].OrderID
GROUP BY ShipCountry

UNION 

-- EXTRACTING GRAN TOTAL
SELECT NULL AS ShipCountry, NULL AS ProductName, SUM([Order Details].UnitPrice * [Order Details].Quantity) AS Price
FROM [Order Details]
INNER JOIN [Products] ON Products.ProductID = [Order Details].ProductID
INNER JOIN [Orders] ON [Orders].OrderID = [Order Details].OrderID

) tmp

ORDER BY CASE WHEN ShipCountry IS NULL THEN 1 ELSE 0 END, ShipCountry, CASE WHEN ProductName IS NULL THEN 1 ELSE 0 END, ProductName

SET STATISTICS TIME OFF;
SET STATISTICS IO OFF;

/*

*/


-- RETRY TO EXTRACT DATA USING ROLLUP (Execution plan CTRL+M) (QUESTION: Is there a limit? If yes, what?)
DBCC DROPCLEANBUFFERS;

SET STATISTICS TIME ON;
SET STATISTICS IO ON;

SELECT [Orders].ShipCountry, [Products].ProductName, SUM([Order Details].UnitPrice * [Order Details].Quantity) as Price
FROM [Order Details]
INNER JOIN [Products] ON Products.ProductID = [Order Details].ProductID
INNER JOIN [Orders] ON [Orders].OrderID = [Order Details].OrderID
GROUP BY ROLLUP([Orders].ShipCountry, [Products].ProductName)


SET STATISTICS TIME OFF;
SET STATISTICS IO OFF;

/*

*/




