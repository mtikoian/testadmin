/*
	SQLSatDublin 2017 - 17.06.2017
	Performance tips forfaster SQL queries

	Emanuele Zanchettin
	ezanchettin@thinkit.it - @_thinkIT_
*/

USE SQLSatDublin2017;

-- SCENARIO 3: a fruit-shop database has a lot of functions for the "code reuse" principle and it works! but ... 


-- FUNCTION TO MANAGE DATE FROM SMALLDATETIME TO NUMERIC AAAAMMDD
CREATE FUNCTION dbo.fn_DataNumericaAAAAMMDD(@Data smalldatetime)
RETURNS float
AS
     BEGIN
         RETURN CONVERT(float, YEAR(@Data)) * 10000 + CONVERT(float, MONTH(@Data)) * 100 + CONVERT(float, DAY(@Data));
     END;
GO

-- FUNCTION TO MANAGE DATE FROM DATETIME TO STRING AAAAMMDD
CREATE FUNCTION dbo.fn_DataStringaAAAAMMDD(@Data datetime)
RETURNS char(8)
AS
     BEGIN
         DECLARE @stringa char(8);

         DECLARE @mese nvarchar(2) = CONVERT(nvarchar(2) , DATEPART(mm, @Data ));
         IF LEN(@mese) = 1
         BEGIN
			SET @mese = '0' + @mese;
		 END;

         DECLARE @giorno nvarchar(2) = CONVERT(nvarchar(2), DATEPART(dd, @Data ));
         IF LEN(@giorno) = 1
         BEGIN
             SET @giorno = '0' + @giorno;
         END;

         SET @stringa = CONVERT(char(4), DATEPART(yyyy, @Data)) + @mese + @giorno;

         RETURN @stringa;
     END;
GO


-- FUNCTION TO MANAGE THE ITEM DESCRIPTION
CREATE FUNCTION dbo.fn_ItemDescription(@Id int)
RETURNS varchar( 35 )
AS
     BEGIN
         RETURN( SELECT descrizione
                   FROM Products
                   WHERE ID = @Id );
     END;
GO

-- FUNCTION TO MANAGE THE GROSS PRICE ALGORITHM
CREATE FUNCTION dbo.fn_GrossPrice(@Price int, @Vat int)
RETURNS int
AS
     BEGIN
         RETURN @Price + @Price * @Vat / 100;
     END;
GO

-- CHECKING INSERTED RECORDS
SELECT *
  FROM [Products];

SELECT COUNT(*)
  FROM [Products]; 


SELECT *
  FROM [Catalog];

SELECT COUNT(*)
  FROM [Catalog]; 



-- REQUEST: EXTRACTING ALL DATA FROM CATALOG (execution plan CTRL+M)
DBCC DROPCLEANBUFFERS;

SET STATISTICS IO ON;
SET STATISTICS TIME ON;
SELECT dbo.fn_DataStringaAAAAMMDD(StartDate) AS StartDate, 
       dbo.fn_DataNumericaAAAAMMDD(EndDate) AS EndDate, 
       Text, 
       dbo.fn_ItemDescription(ProductID) AS Product, 
       dbo.fn_GrossPrice(Price, Vat) AS PublicPrice
  FROM Catalog;
SET STATISTICS TIME OFF;
SET STATISTICS IO OFF;
GO
/*

*/





-- EXTRACTING DATA WITH INLINE FUNCTIONS
DBCC DROPCLEANBUFFERS;

SET STATISTICS IO ON;
SET STATISTICS TIME ON;
SELECT CONVERT(char(8), StartDate, 112) AS StartDate, 
       CONVERT(float, CONVERT(char(8), EndDate, 112)) AS EndDate, 
       Text, 
       Products.Descrizione AS Product, 
       Price + Price * Vat / 100 AS PublicPrice
  FROM Catalog
       JOIN Products ON Products.ID = Catalog.ProductID;
SET STATISTICS TIME OFF;
SET STATISTICS IO OFF;
GO
/*

*/

-- ADD THE MISSING INDEX
CREATE NONCLUSTERED INDEX [IX_Catalog_Product]
ON [dbo].[Catalog] ([ProductID])
INCLUDE ([StartDate],[EndDate],[Price],[Text],[Vat])


-- EXTRACTING DATA WITH INLINE, WITH INDEX
DBCC DROPCLEANBUFFERS;

SET STATISTICS IO ON;
SET STATISTICS TIME ON;
SELECT CONVERT(char(8), StartDate, 112) AS StartDate, 
       CONVERT(float, CONVERT(char(8), EndDate, 112)) AS EndDate, 
       Text, 
       Products.Descrizione AS Product, 
       Price + Price * Vat / 100 AS PublicPrice
  FROM Catalog
       JOIN Products ON Products.ID = Catalog.ProductID;
SET STATISTICS TIME OFF;
SET STATISTICS IO OFF;
GO
/*

*/