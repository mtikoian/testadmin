/*
	SQLSatDublin 2017 - 17.06.2017
	Performance tips forfaster SQL queries

	Emanuele Zanchettin
	ezanchettin@thinkit.it - @_thinkIT_
*/

USE SQLSatDublin2017;

-- SCENARIO 2: a third parties solution is used to manage an online catalog (ecommerce), a customization doesn't work fine


-- CHECKING INSERTED RECORDS
SELECT TOP 10 *
FROM [Stock]

SELECT count(*)
FROM [Stock]


-- CUSTOMIZING PROMOTIONS 
CREATE TABLE [dbo].[Discount](
	[Code] INT NOT NULL,			-- item has a numeric code (like EAN)
	[Percentage] int NOT NULL,		-- percentage of discount
	[DateTime] datetime NOT NULL,	-- date start of validaty
 CONSTRAINT [PK_Discount] PRIMARY KEY CLUSTERED 
(
	[Code] ASC
)
) ON [PRIMARY]
GO

-- INSERTING DATA, SIMULATION OF ITEM DISCOUNT (random)
--TRUNCATE TABLE [Discount];
INSERT INTO [Discount] ([Code], Percentage, DateTime)
SELECT n, CAST(Rand(CAST( NEWID() AS varbinary )) * 80 + 1 AS INT), DATEADD(d, -CAST(Rand(CAST( NEWID() AS varbinary )) * 500 + 1 AS INT), GETDATE())
FROM dbo.fn_numbers(1, 2000) Nums

-- CHECKING INSERTED RECORDS
SELECT TOP 10 *
FROM [Discount]

SELECT count(*)
FROM [Discount]

-- REQUEST: THE DISCOUNT PAGE NEEDS ALL ITEMS WITH A DISCOUNT (execution plan CTRL+M)
DBCC DROPCLEANBUFFERS;

SET STATISTICS IO ON;
SET STATISTICS TIME ON;

SELECT Discount.[Code], Discount.[Percentage], Stock.Quantity
FROM Stock
INNER JOIN Discount ON Discount.Code = Stock.Code

SET STATISTICS TIME OFF;
SET STATISTICS IO OFF;

/*

*/
-- QUESTION: why a simple query has a complex Execution Plan?




-- CHANGING CODE COLUMN DATA TYPE (1")
CREATE TABLE dbo.Tmp_Discount
	(
	[Code] varchar(50) NOT NULL,
	[Percentage] int NOT NULL,
	[DateTime] datetime NOT NULL,
 CONSTRAINT [PK_Discount_ok] PRIMARY KEY CLUSTERED 
(
	[Code] ASC
)
) ON [PRIMARY]
GO
INSERT INTO dbo.Tmp_Discount ([Code], [Percentage], DateTime)
SELECT [Code], [Percentage], DateTime
FROM  dbo.Discount
GO
DROP TABLE dbo.Discount
GO
EXECUTE sp_rename N'dbo.Tmp_Discount', N'Discount', 'OBJECT' 
GO

-- ADDING FK
ALTER TABLE dbo.Discount ADD CONSTRAINT
	FK_Discount_Stock FOREIGN KEY
	(
	Code
	) REFERENCES dbo.Stock
	(
	Code
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 
	
GO



-- RETRY DATA EXTRACTION
DBCC DROPCLEANBUFFERS;

SET STATISTICS IO ON;
SET STATISTICS TIME ON;

SELECT Discount.[Code], Discount.[Percentage], Stock.Quantity
FROM Stock
INNER JOIN Discount ON Discount.Code = Stock.Code

SET STATISTICS TIME OFF;
SET STATISTICS IO OFF;

/*

*/

