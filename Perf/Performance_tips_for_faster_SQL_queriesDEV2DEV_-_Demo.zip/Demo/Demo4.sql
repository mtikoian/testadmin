/*
	SQLSatDublin 2017 - 17.06.2017
	Performance tips forfaster SQL queries

	Emanuele Zanchettin
	ezanchettin@thinkit.it - @_thinkIT_
*/

USE SQLSatDublin2017;


-- SCENARIO 4: A tipical company needs to move (a lot of) data into a history table, using a custom software





-- INSERTING DATA >> Demo4a - ROW BY ROW APPROACH
TRUNCATE TABLE History;

SET STATISTICS IO ON;
SET STATISTICS TIME ON;
INSERT INTO History (Code, Description) VALUES (...., ...);
INSERT INTO History (Code, Description) VALUES (...., ...);
[...]
INSERT INTO History (Code, Description) VALUES (...., ...);
INSERT INTO History (Code, Description) VALUES (...., ...);
SET STATISTICS TIME OFF;
SET STATISTICS IO OFF;
GO


-- INSERTING DATA >> Demo4b - ROW SET APPROACH (QUESTION: Is there a limit? If yes, what's that?)
TRUNCATE TABLE History;

SET STATISTICS IO ON;
SET STATISTICS TIME ON;
INSERT INTO History (Code, Description) VALUES (...., ...), (...., ...), (...., ...), (...., ...), (...., ...);
[...]
INSERT INTO History (Code, Description) VALUES (...., ...), (...., ...), (...., ...), (...., ...), (...., ...);
SET STATISTICS TIME OFF;
SET STATISTICS IO OFF;
GO

