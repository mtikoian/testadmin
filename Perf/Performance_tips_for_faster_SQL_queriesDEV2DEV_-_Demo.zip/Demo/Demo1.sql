/*
	SQLSatDublin 2017 - 17.06.2017
	Performance tips forfaster SQL queries

	Emanuele Zanchettin
	ezanchettin@thinkit.it - @_thinkIT_
*/

USE SQLSatDublin2017;

-- SCENARIO 1: a Warehouse Management System needs to improve performance when some data are extracted from table

-- CHECKING RECORDS
SELECT TOP 10 *
FROM [WarehouseMovements]

-- [Moviment] classification
SELECT Count(*) AS [Count], [Moviment], CASE [Moviment] WHEN 'DWN' THEN 'DOWNLOAD NORMAL'
			WHEN 'DWE' THEN 'DOWNLOAD EMERGENCY' -- EMERGENCY ENDS WITH "E"
			WHEN 'DWC' THEN 'DOWNLOAD CHECK'
			WHEN 'DWA' THEN 'DOWNLOAD APPARTMENT'
			WHEN 'UPN' THEN 'UPLOAD NORMAL'
			WHEN 'UPE' THEN 'UPLOAD EMERGENCY' -- EMERGENCY ENDS WITH "E"
			WHEN 'UPD' THEN 'UPDATE'
			END AS [Description]
FROM [WarehouseMovements]
GROUP BY [Moviment]


SELECT count(*)
FROM [WarehouseMovements]


-- REQUEST: EXTRACTING ALL EMERGENCY MOVEMENTS (UPLOAD-DOWNLOAD) OF LAST 90DAYS (execution plan CTRL+M)
DBCC DROPCLEANBUFFERS;

SET STATISTICS TIME ON;
SET STATISTICS IO ON;

SELECT [Moviment], COUNT(*)
FROM [WarehouseMovements]
WHERE [Moviment] LIKE '%E' AND DateTime >= DATEADD(d, -90, GETDATE())
GROUP BY [Moviment];

SET STATISTICS TIME OFF;
SET STATISTICS IO OFF;
/*

*/



 -- APPROACH 1: CREATING MISSING INDEX AS ADVISED
 CREATE NONCLUSTERED INDEX IX2_Movement ON dbo.[WarehouseMovements]
	(
	DateTime
	) 
	INCLUDE (Moviment)
	WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]


-- RETRY DATA EXTRACTION
DBCC DROPCLEANBUFFERS;

SET STATISTICS TIME ON;
SET STATISTICS IO ON;

SELECT [Moviment], COUNT(*)
FROM [WarehouseMovements]
WHERE [Moviment] LIKE '%E' AND DateTime >= DATEADD(d, -90, GETDATE())
GROUP BY [Moviment];

SET STATISTICS TIME OFF;
SET STATISTICS IO OFF;
/*

*/



-- APPROACH 2: CREATING A TABLE OF MOVEMENTS TYPE
CREATE TABLE [dbo].[MovementType](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[Moviment] varchar(3) NOT NULL,
 CONSTRAINT [PK_MovementType] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)
) ON [PRIMARY]

INSERT INTO [MovementType] ([Moviment]) VALUES ('DWN'), ('DWE'), ('DWC'), ('DWA'), ('UPN'), ('UPE'), ('UPD');

CREATE NONCLUSTERED INDEX IX_MovementType ON dbo.MovementType
	(
	Moviment
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]






-- Solution 1: ADD A COLUMN AT THE END OF TABLE (26")
ALTER TABLE dbo.WarehouseMovements ADD
	MovementTypeID int NULL;
GO
UPDATE dbo.WarehouseMovements
SET MovementTypeID = [MovementType].id
FROM dbo.WarehouseMovements
INNER JOIN [dbo].[MovementType] ON [MovementType].Moviment = WarehouseMovements.Moviment;
-- Solution 1: END




-- Solution 2: ADD A COLUMNS IN THE MIDDLE, RIGHT POSITION (47")
CREATE TABLE dbo.Tmp_WarehouseMovements
	(
	id int NOT NULL IDENTITY (1, 1),
	ItemID int NOT NULL,
	Moviment varchar(50) NOT NULL,
	MovementTypeID int NULL,
	Quantity int NOT NULL,
	DateTime datetime NOT NULL
	)  ON [PRIMARY]
GO
SET IDENTITY_INSERT dbo.Tmp_WarehouseMovements ON
GO
INSERT INTO dbo.Tmp_WarehouseMovements (id, ItemID, Moviment, MovementTypeID, Quantity, DateTime)
SELECT WarehouseMovements.id, ItemID, WarehouseMovements.Moviment, [MovementType].id, Quantity, DateTime 
FROM dbo.WarehouseMovements
INNER JOIN [dbo].[MovementType] ON [MovementType].Moviment = WarehouseMovements.Moviment;
		
SET IDENTITY_INSERT dbo.Tmp_WarehouseMovements OFF
GO
DROP TABLE dbo.WarehouseMovements
GO
EXECUTE sp_rename N'dbo.Tmp_WarehouseMovements', N'WarehouseMovements', 'OBJECT' 
GO
-- RECREATE PK and INDEXES
ALTER TABLE dbo.WarehouseMovements ADD CONSTRAINT
	PK_WarehouseMovements PRIMARY KEY CLUSTERED 
	(
	id
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

GO
CREATE NONCLUSTERED INDEX IX_Movement ON dbo.WarehouseMovements
	(
	Moviment
	) 
	INCLUDE (ItemID, Quantity, DateTime)
	WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
-- Solution 2: END





-- ADDING FK (QUESTION: why a FK can help to improve performance?)
ALTER TABLE dbo.WarehouseMovements ADD CONSTRAINT
	FK_WarehouseMovements_MovementType FOREIGN KEY
	(
	MovementTypeID
	) REFERENCES dbo.MovementType
	(
	id
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 
GO

-- RETRY DATA EXTRACTION (execution plan CTRL+M)
DBCC DROPCLEANBUFFERS;

SET STATISTICS TIME ON;
SET STATISTICS IO ON;

SELECT [MovementType].[Moviment], COUNT(*)
FROM [WarehouseMovements]
INNER JOIN [MovementType] ON [MovementType].id = [WarehouseMovements].MovementTypeID
WHERE [MovementType].[Moviment] LIKE '%E' AND DateTime >= DATEADD(d, -90, GETDATE())
GROUP BY [MovementType].[Moviment];

SET STATISTICS TIME OFF;
SET STATISTICS IO OFF;

/*

*/



-- INDEX ADVISED ... DON'T USE IT, USE YOUR HEAD TO DESIGN IT!!
CREATE NONCLUSTERED INDEX IX_MovementTypeID ON dbo.WarehouseMovements
	(
	DateTime
	)
	INCLUDE (MovementTypeID)
	 WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

-- RETRY DATA EXTRACTION WITH ADVISED INDEX
DBCC DROPCLEANBUFFERS;

SET STATISTICS TIME ON;
SET STATISTICS IO ON;

SELECT [MovementType].[Moviment], COUNT(*)
FROM [WarehouseMovements]
INNER JOIN [MovementType] ON [MovementType].id = [WarehouseMovements].MovementTypeID
WHERE [MovementType].[Moviment] LIKE '%E' AND DateTime >= DATEADD(d, -90, GETDATE())
GROUP BY [MovementType].[Moviment];

SET STATISTICS TIME OFF;
SET STATISTICS IO OFF;

/*

*/



-- DESIGNED INDEX 
CREATE NONCLUSTERED INDEX IX2_MovementTypeID ON dbo.WarehouseMovements
(
MovementTypeID
)
INCLUDE (DateTime)
	WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

-- RETRY DATA EXTRACTION WITH DESIGNED INDEX
DBCC DROPCLEANBUFFERS;

SET STATISTICS TIME ON;
SET STATISTICS IO ON;

SELECT [MovementType].[Moviment], COUNT(*)
FROM [WarehouseMovements]
INNER JOIN [MovementType] ON [MovementType].id = [WarehouseMovements].MovementTypeID
WHERE [MovementType].[Moviment] LIKE '%E' AND DateTime >= DATEADD(d, -90, GETDATE())
GROUP BY [MovementType].[Moviment];

SET STATISTICS TIME OFF;
SET STATISTICS IO OFF;
/*

*/
