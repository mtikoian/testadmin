/*
	SQLSatDublin 2017 - 17.06.2017
	Performance tips forfaster SQL queries

	Emanuele Zanchettin
	ezanchettin@thinkit.it - @_thinkIT_
*/

-- Create the database (12")
USE master;

GO
IF NOT EXISTS(SELECT * FROM sys.sysdatabases WHERE name = 'SQLSatDublin2017')
BEGIN
CREATE DATABASE SQLSatDublin2017
ON PRIMARY
  ( NAME = SQLSatDublin2017_dat,
      FILENAME = 'C:\temp\SQLSatDublin2017.mdf',
      SIZE = 1GB,
      MAXSIZE = UNLIMITED,
      FILEGROWTH = 100 MB )
  LOG ON
  ( NAME = SQLSatDublin2017_log,
      FILENAME = 'C:\temp\SQLSatDublin2017.ldf',
      SIZE = 2 GB,
      MAXSIZE = UNLIMITED,
      FILEGROWTH = 100 MB ) ;
END
GO

SET STATISTICS TIME OFF;
SET STATISTICS IO OFF;


USE SQLSatDublin2017;

/* 
	SCENARIO 1 
*/
-- MANAGING WAREHOUSE MOVEMENTS
CREATE TABLE [dbo].[WarehouseMovements](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[ItemID] int NOT NULL,
	[Moviment] varchar(50) NOT NULL,
	[Quantity] int NOT NULL,
	[DateTime] datetime NOT NULL,
 CONSTRAINT [PK_WarehouseMovements] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)
) ON [PRIMARY]
GO




-- INSERTING DATA (1kk => 6", 10kk => 1')
--TRUNCATE TABLE [WarehouseMovements];

-- APPROACH ROW-BY-ROW (50k => 17")
DECLARE @i INT = 0;
WHILE (@i  < 50000)
BEGIN
  INSERT INTO [WarehouseMovements] (ItemID, Moviment, Quantity, DateTime)
    SELECT
            CAST(Rand(CAST( NEWID() AS varbinary )) * 100 + 1 AS INT) , 
			CASE CAST(Rand(CAST( NEWID() AS varbinary )) * 6 + 1 AS INT)
			WHEN 1 THEN 'DWN' -- DOWNLOAD NORMAL
			WHEN 2 THEN 'DWE' -- DOWNLOAD EMERGENCY
			WHEN 3 THEN 'DWC' -- DOWNLOAD CHECK
			WHEN 4 THEN 'DWA' -- DOWNLOAD APPARTMENT
			WHEN 5 THEN 'UPN' -- UPLOAD NORMAL
			WHEN 6 THEN 'UPE' -- UPLOAD EMERGENCY
			ELSE 'UPD'	      -- UPDATE
		END,
		 CAST(Rand(CAST( NEWID() AS varbinary )) * 100 + 1 AS INT) 
		 , DATEADD(d, -CAST(Rand(CAST( NEWID() AS varbinary )) * 500 + 1 AS INT), GETDATE());
	SET @i = @i + 1;
END
GO

-- APPROACH ROW-SET (2kk => 19")
CREATE FUNCTION dbo.fn_numbers(@Start AS BIGINT,@End AS BIGINT) RETURNS TABLE
AS
RETURN
  WITH
  L0   AS(SELECT 1 AS c UNION ALL SELECT 1),
  L1   AS(SELECT 1 AS c FROM L0 AS A, L0 AS B),
  L2   AS(SELECT 1 AS c FROM L1 AS A, L1 AS B),
  L3   AS(SELECT 1 AS c FROM L2 AS A, L2 AS B),
  L4   AS(SELECT 1 AS c FROM L3 AS A, L3 AS B),
  L5   AS(SELECT 1 AS c FROM L4 AS A, L4 AS B),
  Nums AS(SELECT ROW_NUMBER() OVER(ORDER BY c) AS n FROM L5)
  SELECT n FROM Nums 
  WHERE n between  @Start and @End;  
GO  

INSERT INTO [WarehouseMovements] (ItemID, Moviment, Quantity, DateTime)
    SELECT
			CAST(Rand(CAST( NEWID() AS varbinary )) * 100 + 1 AS INT) , 
			CASE CAST(Rand(CAST( NEWID() AS varbinary )) * 6 + 1 AS INT)
			WHEN 1 THEN 'DWN' -- DOWNLOAD NORMAL
			WHEN 2 THEN 'DWE' -- DOWNLOAD EMERGENCY
			WHEN 3 THEN 'DWC' -- DOWNLOAD CHECK
			WHEN 4 THEN 'DWA' -- DOWNLOAD APPARTMENT
			WHEN 5 THEN 'UPN' -- UPLOAD NORMAL
			WHEN 6 THEN 'UPE' -- UPLOAD EMERGENCY
			ELSE 'UPD'	      -- UPDATE
		END,
		 CAST(Rand(CAST( NEWID() AS varbinary )) * 100 + 1 AS INT) 
		 , DATEADD(d, -CAST(Rand(CAST( NEWID() AS varbinary )) * 500 + 1 AS INT), GETDATE())
		 FROM dbo.fn_numbers(1, 2000000) Nums


-- CREATING INDEX NONCLUSTERED FOR SEARCHING
CREATE NONCLUSTERED INDEX IX_Movement ON dbo.[WarehouseMovements]
	(
	Moviment
	) 
	INCLUDE (ItemID, Quantity, DateTime)
	WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]


/* 
	SCENARIO 2
*/

-- ITEM TABLE (es. db third parties)
CREATE TABLE [dbo].[Stock](
	[Code] varchar(50) NOT NULL,
	[Quantity] int NOT NULL,
	[DateTime] datetime NOT NULL,
 CONSTRAINT [PK_Stock] PRIMARY KEY CLUSTERED 
(
	[Code] ASC
)
) ON [PRIMARY]
GO

-- INSERTING DATA (1kk => 6", 10kk => 1')
--TRUNCATE TABLE [Stock];

-- ROW-SET APPROACH (2kk => 19")
INSERT INTO [Stock] ([Code], Quantity, DateTime)
    SELECT
			n , 
		 CAST(Rand(CAST( NEWID() AS varbinary )) * 100 + 1 AS INT) 
		 , DATEADD(d, -CAST(Rand(CAST( NEWID() AS varbinary )) * 500 + 1 AS INT), GETDATE())
		 FROM dbo.fn_numbers(1, 2000000) Nums


/*
	SCENARIO 3
*/
-- ITEMS TABLE
CREATE TABLE Products(
             ID int , 
             Descrizione varchar( 35 ));
GO

-- INSERTING DATA 
INSERT INTO Products
VALUES
       (1, 'apple'),
       (2, 'orange'),
       (3, 'banana'),
       (4, 'kiwi'),
       (5, 'melon'),
       (6, 'watermelon');
GO

-- PRODUCTS CATALOG TABLE
CREATE TABLE [Catalog](
    ID INT IDENTITY(1,1) NOT NULL, 
    StartDate datetime , 
    EndDate datetime , 
    Price int, 
    Text varchar( 35 ) , 
    ProductID int , 
    Vat int );
GO

-- INSERTING DATA (16")
DECLARE @i int;
SET @i = 50000;
WHILE @i > 0
    BEGIN
        INSERT INTO Catalog (StartDate, EndDate, Price, Text, ProductID, Vat) 
        VALUES
               (GETDATE(), GETDATE(), 123, 'this is a description ...', 2, 22);
        SET @i = @i - 1;
    END;
GO


/*
	SCENARIO 4
*/

-- HISTORY TABLE
CREATE TABLE History(
    ID INT IDENTITY(1,1) NOT NULL,
	Code INT, 
    Description varchar( 35 ));
GO

CREATE NONCLUSTERED INDEX IX_History ON dbo.History
(
	Code
) 
INCLUDE (Description)
WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]


/*
	SCENARIO 8
*/

CREATE TABLE [Scores](
    ID INT IDENTITY(1,1) NOT NULL, 
    GameID int , 
    PlayerID int , 
    Score int);
GO

INSERT INTO [Scores] (GameID, PlayerID, Score)
SELECT 
CAST(Rand(CAST( NEWID() AS varbinary )) * 10 + 1 AS INT) , 
CAST(Rand(CAST( NEWID() AS varbinary )) * 3000 + 1 AS INT) , 
CAST(Rand(CAST( NEWID() AS varbinary )) * 100000 + 1 AS INT)
FROM dbo.fn_numbers(1, 2000000) Nums
