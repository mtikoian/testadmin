/*
	SQLSatDublin 2017 - 17.06.2017
	Performance tips forfaster SQL queries

	Emanuele Zanchettin
	ezanchettin@thinkit.it - @_thinkIT_

	******************
	*** BONUS DEMO ***
	******************

*/

USE [SQLSatDublin2017];

-- SCENARIO 8: A game community organized an online challenge and needs to extract a score table


-- CHECKING RECORDS
SELECT TOP 10 *
FROM [Scores]

-- EXTRACTING THE BEST SCORE'S PLAYER FOR EACH GAME
DBCC DROPCLEANBUFFERS;

SET STATISTICS TIME ON;
SET STATISTICS IO ON;

SELECT GameID, PlayerID, Score
FROM (
	SELECT GameID, PlayerID, Score, ROW_NUMBER() OVER (PARTITION BY GameID, PlayerID ORDER BY GameID, PlayerID, Score DESC) AS rownum
	FROM [Scores]
) temp
WHERE rownum = 1

SET STATISTICS TIME OFF;
SET STATISTICS IO OFF;
/*

*/


-- RETRY TO EXTRACT DATA
DBCC DROPCLEANBUFFERS;

SET STATISTICS TIME ON;
SET STATISTICS IO ON;

SELECT GameID, PlayerID, extern2.maxScore
FROM [Scores] extern
CROSS APPLY (SELECT MAX(Score) AS maxScore
			FROM [Scores] intern
			WHERE intern.GameID = extern.GameID AND intern.PlayerID = extern.PlayerID) extern2
GROUP BY extern.GameID, extern.PlayerID, extern2.maxScore

SET STATISTICS TIME OFF;
SET STATISTICS IO OFF;
/*

*/

-- RETRY TO EXTRACT DATA
DBCC DROPCLEANBUFFERS;

SET STATISTICS TIME ON;
SET STATISTICS IO ON;

SELECT GameID, PlayerID, MAX(Score) AS maxScore
FROM [Scores]
GROUP BY GameID, PlayerID


SET STATISTICS TIME OFF;
SET STATISTICS IO OFF;
/*

*/