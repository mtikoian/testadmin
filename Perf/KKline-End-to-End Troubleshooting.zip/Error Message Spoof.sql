-- Fake error messages
RAISERROR(N'Kevin - you suck!', 19, 1) WITH LOG;