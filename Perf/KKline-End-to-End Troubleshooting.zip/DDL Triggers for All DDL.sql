/* 
Based on code by the awesome Aaron Bertrand (@AaronBertrand, http://blogs.sqlsentry.com/AaronBertrand/). 
Read more at:

   - https://www.mssqltips.com/sqlservertip/2085/sql-server-ddl-triggers-to-track-all-database-changes/
   - https://www.mssqltips.com/sqlservertip/2951/extending-sql-server-ddl-triggers-for-more-functionality-part-1/
   - https://www.mssqltips.com/sqlservertip/2952/extend-sql-server-ddl-triggers-for-more-functionality-part-2/

KKline, Email at KEKline@sqlsentry.com, Social media at @kekline
Blog at http://blogs.sqlsentry.com/KevinKline 
*/

-- Create the admin tables to store the data. Personally, I like to use MSDB for this. 
USE msdb;
GO

CREATE TABLE dbo.DDLEvents
(
    EventDate    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    EventType    NVARCHAR(64),
    EventDDL     NVARCHAR(MAX),
    EventXML     XML,
    DatabaseName NVARCHAR(255),
    SchemaName   NVARCHAR(255),
    ObjectName   NVARCHAR(255),
    HostName     VARCHAR(64),
    IPAddress    VARCHAR(32),
    ProgramName  NVARCHAR(255),
    LoginName    NVARCHAR(255)
);

-- User who might make changes must have INSERT privileges on the DDLEvents table.
GRANT SELECT, INSERT ON OBJECT::msdb.dbo.DDLEvents TO [public];
GO

-- Create the DDL triggers
USE YourDatabase;
GO

CREATE TRIGGER DDLTrigger_Sample
    ON DATABASE 
	-- Feeling lazy? Experiment with scope of ON ALL SERVER, instead of ON DATABASE.
    FOR DDL_DATABASE_LEVEL_EVENTS 
	-- To filter out noise events, refer to the topic on DDL Event Groups
	-- at https://msdn.microsoft.com/en-us/library/bb510452.aspx.
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE
        @EventData XML = EVENTDATA();
 
    DECLARE 
        @ip VARCHAR(32) =
        (
            SELECT client_net_address
                FROM sys.dm_exec_connections
                WHERE session_id = @@SPID
        );
 
    INSERT msdb.dbo.DDLEvents
    (
        EventType,
        EventDDL,
        EventXML,
        DatabaseName,
        SchemaName,
        ObjectName,
        HostName,
        IPAddress,
        ProgramName,
        LoginName
    )
    SELECT
        @EventData.value('(/EVENT_INSTANCE/EventType)[1]',   'NVARCHAR(100)'), 
        @EventData.value('(/EVENT_INSTANCE/TSQLCommand)[1]', 'NVARCHAR(MAX)'),
        @EventData,
        DB_NAME(),
        @EventData.value('(/EVENT_INSTANCE/SchemaName)[1]',  'NVARCHAR(255)'), 
        @EventData.value('(/EVENT_INSTANCE/ObjectName)[1]',  'NVARCHAR(255)'),
        HOST_NAME(),
        @ip,
        PROGRAM_NAME(),
        SUSER_SNAME();
END
GO

/* Enable and disable the trigger as needed.
USE YourDatabase;
GO

ENABLE TRIGGER [DDLTrigger_Sample] ON DATABASE;

DISABLE TRIGGER [DDLTrigger_Sample] ON DATABASE;
*/


-- Let's do a quick test.
CREATE TABLE dbo.B_TABLE
	( Col1	INT	IDENTITY(1,1) ,
	  Col2	NVARCHAR(50) CONSTRAINT B_DEFAULT_ON_A_TABLE DEFAULT ('Test') );
GO
ALTER TABLE dbo.B_TABLE ADD CONSTRAINT B_CHECK_ON_A_TABLE CHECK ( Col2 <> '' );
GO
DROP TABLE dbo.B_TABLE;
GO


-- Let's see some data!
SELECT *
FROM msdb.dbo.DDLEvents
-- WHERE EventType = 'ALTER_PROCEDURE'
ORDER BY EventDate;

