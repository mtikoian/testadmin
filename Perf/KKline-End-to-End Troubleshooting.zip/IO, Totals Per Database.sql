--Calculating the Total I/O for Each Database

SELECT
  DB_NAME(database_id) AS database_name,
  CAST(SUM(num_of_bytes_read + num_of_bytes_written) / 1048576. AS DECIMAL(12, 2)) AS io_in_mb,
  CAST(SUM(num_of_bytes_read) / 1048576. AS DECIMAL(12, 2)) AS reads_in_mb,
  CAST(SUM(num_of_bytes_written) / 1048576. AS DECIMAL(12, 2)) AS writes_in_mb
FROM sys.dm_io_virtual_file_stats(NULL, NULL) AS DM_IO_Stats
GROUP BY database_id
ORDER BY io_in_mb DESC;