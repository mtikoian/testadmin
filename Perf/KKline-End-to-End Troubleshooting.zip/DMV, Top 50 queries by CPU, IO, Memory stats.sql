/*
Execution Related DMV
Server Scope
Returns aggregate performance statistics for cached query plans. The view contains one row per query statement within the cached plan,
and the lifetime of the rows are tied to the plan itself. When a plan is removed from the cache, the corresponding rows are eliminated
from this view. 
*/

--Top 50 CPU items
SELECT TOP 50 ( total_worker_time / qs.execution_count ) AS averageCPU
   ,total_worker_time AS totalCPU
   ,qs.execution_count AS executionCount
   ,OBJECT_NAME(qt.objectid) AS objectName
   ,SUBSTRING(qt.text,qs.statement_start_offset / 2,( CASE WHEN qs.statement_end_offset = -1 THEN LEN(CONVERT(NVARCHAR(MAX),qt.text)) * 2
                                                           ELSE qs.statement_end_offset
                                                      END - qs.statement_start_offset ) / 2) AS individualQuery
   ,qt.[text] AS parentQuery
   ,qs.creation_time
   ,qs.last_execution_time
FROM sys.dm_exec_query_stats qs
    CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle) as qt
--WHERE qt.dbid = DB_ID()
ORDER BY averageCPU DESC ;

--Top 50 IO Items
SELECT TOP 50 ( total_logical_reads + total_logical_writes ) / qs.execution_count AS averageIO
   ,( total_logical_reads + total_logical_writes ) AS totalIO
   ,qs.execution_count AS executionCount
   ,OBJECT_NAME(qt.objectid) AS objectName
   ,SUBSTRING(qt.text,qs.statement_start_offset / 2,( CASE WHEN qs.statement_end_offset = -1 THEN LEN(CONVERT(NVARCHAR(MAX),qt.text)) * 2
                                                           ELSE qs.statement_end_offset
                                                      END - qs.statement_start_offset ) / 2) AS individualQuery
   ,qt.[text] AS parentQuery
   ,qs.creation_time
   ,qs.last_execution_time
FROM sys.dm_exec_query_stats qs
    CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle) as qt
--WHERE qt.dbid = DB_ID()
ORDER BY averageIO DESC ;