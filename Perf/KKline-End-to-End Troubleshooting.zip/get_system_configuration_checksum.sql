SELECT
    HASHBYTES
    (
        'SHA1'
        ,(
            SELECT
                CONVERT(VARCHAR(18),CONVERT(VARBINARY(8),SCFG.value_in_use,0),1)
            FROM    sys.configurations  SCFG
            ORDER BY SCFG.configuration_id ASC
            FOR XML PATH(''),TYPE
        ).value('(./text())[1]','VARCHAR(MAX)')
    )   AS SCFG_SHA1