USE AdventureWorks ;
GO
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[Person].[Address]') AND name = N'IX_PA_1')
    DROP INDEX [IX_PA_1] ON [Person].[Address] WITH ( ONLINE = OFF )
GO
CREATE NONCLUSTERED INDEX [IX_PA_1] ON [Person].[Address] 
([AddressLine1]) ;
GO

USE master;
GO
ALTER DATABASE [PerfTest] SET SINGLE_USER WITH ROLLBACK IMMEDIATE; 
GO
ALTER DATABASE [PerfTest] SET OFFLINE;
GO
ALTER DATABASE [PerfTest] SET ONLINE;
GO
ALTER DATABASE [PerfTest] SET MULTI_USER; 
GO

USE [AdventureWorks]
GO

SELECT b.[name], a.*
FROM sys.dm_db_index_operational_stats(NULL, NULL, NULL, NULL) AS a
    INNER JOIN sys.indexes AS b ON a.[object_id] = b.[object_id] AND 
    a.[index_id] = b.[index_id]
WHERE a.[database_id] = DB_ID()
    AND b.[object_id] = OBJECT_ID('Person.Address') ;


--  Rebuild the index and see what that does for the stats
ALTER INDEX ALL ON [Person].[Address] REBUILD ;


SELECT b.[name], a.*
FROM sys.dm_db_index_operational_stats(NULL, NULL, NULL, NULL) AS a
    INNER JOIN sys.indexes AS b ON a.[object_id] = b.[object_id] AND 
    a.[index_id] = b.[index_id]
WHERE a.[database_id] = DB_ID()
    AND b.[object_id] = OBJECT_ID('Person.Address') ;


SELECT * FROM Person.Address WITH (INDEX = IX_Address_City) WHERE City = N'Paderborn' 
GO
SELECT * FROM Person.Address WHERE AddressLine1 LIKE 'Bund%' ;
GO
SELECT * FROM Person.Address WHERE AddressID IN (20111, 21743, 19872) ;
GO
SELECT * FROM Person.Address ;
GO

--  Look what happens with an INSERT
BEGIN TRAN

INSERT INTO [PerfTest].[Person].[Address]
    ([AddressLine1],[AddressLine2],[City],[StateProvinceID],[PostalCode],[rowguid],[ModifiedDate])
VALUES ('201 Hello Drive',NULL, 'Boston', 30, N'02113','0175A174-6C34-4D41-B3C1-4419CD6A0446','20110101')




--  How about when we roll it back?
ROLLBACK



SELECT b.[name], a.*
FROM sys.dm_db_index_operational_stats(NULL, NULL, NULL, NULL) AS a
    INNER JOIN sys.indexes AS b ON a.[object_id] = b.[object_id] AND 
    a.[index_id] = b.[index_id]
WHERE a.[database_id] = DB_ID()
    AND b.[object_id] = OBJECT_ID('Person.Address') ;

-- Clean up
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[Person].[Address]') AND name = N'IX_PA_1')
    DROP INDEX [IX_PA_1] ON [Person].[Address] WITH ( ONLINE = OFF )
GO
