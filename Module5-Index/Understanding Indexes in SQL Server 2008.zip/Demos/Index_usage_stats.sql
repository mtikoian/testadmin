IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[Person].[Address]') AND name = N'IX_PA_1')
    DROP INDEX [IX_PA_1] ON [Person].[Address] WITH ( ONLINE = OFF )
GO
CREATE NONCLUSTERED INDEX [IX_PA_1] ON [Person].[Address] 
([AddressLine1]) ;
GO

UPDATE STATISTICS Person.Address ;


USE master;
GO
ALTER DATABASE PerfTest SET SINGLE_USER WITH ROLLBACK IMMEDIATE; 
GO
ALTER DATABASE PerfTest SET OFFLINE;
GO
ALTER DATABASE PerfTest SET ONLINE;
GO
ALTER DATABASE PerfTest SET MULTI_USER; 
GO
USE AdventureWorks


SELECT b.[name], a.*
FROM sys.dm_db_index_usage_stats AS a
    INNER JOIN sys.indexes AS b ON a.[object_id] = b.[object_id] AND 
    a.[index_id] = b.[index_id]
WHERE a.[database_id] = DB_ID()
 AND a.[object_id] > 1000 AND b.[name] IS NOT NULL;

SELECT * FROM Person.Address WITH (INDEX = IX_Address_City) WHERE City = N'Paderborn' 
GO
SELECT * FROM Person.Address WHERE AddressLine1 LIKE 'Bund%' ;
GO
SELECT * FROM Person.Address WHERE AddressID IN (20111, 21743, 19872) ;
GO
SELECT * FROM Person.Address ;
GO


SELECT b.[name], a.*
FROM sys.dm_db_index_usage_stats AS a
    INNER JOIN sys.indexes AS b ON a.[object_id] = b.[object_id] AND 
    a.[index_id] = b.[index_id]
WHERE a.[database_id] = DB_ID()
 AND a.[object_id] > 1000 AND b.[name] IS NOT NULL;

--  Rebuild the index and see what that does for the stats
ALTER INDEX ALL ON [Person].[Address] REBUILD ;

SELECT b.[name], a.*
FROM sys.dm_db_index_usage_stats AS a
    INNER JOIN sys.indexes AS b ON a.[object_id] = b.[object_id] AND 
    a.[index_id] = b.[index_id]
WHERE a.[database_id] = DB_ID()
 AND a.[object_id] > 1000 AND b.[name] IS NOT NULL;


-- Cleanup
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[Person].[Address]') AND name = N'IX_PA_1')
    DROP INDEX [IX_PA_1] ON [Person].[Address] WITH ( ONLINE = OFF )
GO