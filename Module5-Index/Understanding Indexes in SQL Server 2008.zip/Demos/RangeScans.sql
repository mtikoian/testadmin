USE AdventureWorks
GO

--  Range scans

IF EXISTS(SELECT * FROM sys.indexes WHERE name = 'IX_NC_SalesOrderDetail_SalesOrderID')
    DROP INDEX [Sales].[SalesOrderDetail].[IX_NC_SalesOrderDetail_SalesOrderID]
GO
CREATE NONCLUSTERED INDEX [IX_NC_SalesOrderDetail_SalesOrderID] ON [Sales].[SalesOrderDetail] 
([SalesOrderID] ) 
GO


SET STATISTICS IO ON ;

SELECT *
FROM Sales.SalesOrderDetail 
WHERE SalesOrderID = 44284;


SELECT *
FROM Sales.SalesOrderDetail WITH (INDEX = IX_NC_SalesOrderDetail_SalesOrderID )
WHERE SalesOrderID = 44284;

SET STATISTICS IO OFF ;




--  Even Non Clustred Indexes can benefit from Range Scans
SET STATISTICS IO ON ;

SELECT *
FROM Sales.SalesOrderDetail 
WHERE ProductID = 778;

SELECT ProductID, SalesOrderID, SalesOrderDetailID
FROM Sales.SalesOrderDetail 
WHERE ProductID = 778;

SET STATISTICS IO OFF ;


-- Cleanup
IF EXISTS(SELECT * FROM sys.indexes WHERE name = 'IX_NC_SalesOrderDetail_SalesOrderID')
    DROP INDEX [Sales].[SalesOrderDetail].[IX_NC_SalesOrderDetail_SalesOrderID]
GO





