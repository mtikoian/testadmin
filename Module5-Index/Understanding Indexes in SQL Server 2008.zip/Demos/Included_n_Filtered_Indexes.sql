
--  Included Columns

DROP INDEX [IX_SOD_1] ON [Sales].[SalesOrderDetail] ;
DROP INDEX [IX_SOD_2] ON [Sales].[SalesOrderDetail] ;
DROP INDEX [IX_SOD_3] ON [Sales].[SalesOrderDetail] ;
DROP INDEX [IX_SOD_4] ON [Sales].[SalesOrderDetail] ;
DROP INDEX [IX_PA_1] ON [Person].[Address]  ;
DROP INDEX [IX_PA_2] ON [Person].[Address]  ;

CREATE NONCLUSTERED INDEX [IX_SOD_1] ON [Sales].[SalesOrderDetail] 
([ProductID], [OrderQty] ) ;

CREATE NONCLUSTERED INDEX [IX_SOD_2] ON [Sales].[SalesOrderDetail] 
([ProductID] ) INCLUDE ([OrderQty] ) ;

CREATE NONCLUSTERED INDEX [IX_SOD_3] ON [Sales].[SalesOrderDetail] 
([ProductID], [OrderQty], [CarrierTrackingNumber], [ModifiedDate], [UnitPriceDiscount] ) ;

CREATE NONCLUSTERED INDEX [IX_SOD_4] ON [Sales].[SalesOrderDetail] 
([ProductID] ) INCLUDE ([OrderQty], [CarrierTrackingNumber], [ModifiedDate], [UnitPriceDiscount] ) ;


CREATE NONCLUSTERED INDEX [IX_PA_1] ON [Person].[Address] 
([AddressLine1], [AddressLine2], [City],[StateProvinceID], [PostalCode])

CREATE NONCLUSTERED INDEX [IX_PA_2] ON [Person].[Address] 
([AddressLine1]) INCLUDE ([AddressLine2], [City],[StateProvinceID], [PostalCode])


--  Look at the differences between an included column and a compound index
SET STATISTICS IO ON

SELECT * FROM Sales.SalesOrderDetail WITH (INDEX = [IX_SOD_1])
WHERE ProductID = 738 AND OrderQty = 9 
 OPTION (RECOMPILE) ;

SELECT * FROM Sales.SalesOrderDetail WITH (INDEX = [IX_SOD_2])
WHERE ProductID = 738 AND OrderQty = 9 
 OPTION (RECOMPILE) ;

SELECT SalesOrderID, CarrierTrackingNumber, ProductID, ModifiedDate,UnitPriceDiscount
    FROM Sales.SalesOrderDetail  WITH (INDEX = [IX_SOD_3])
        WHERE ProductID = 738 AND OrderQty = 9 ;

SELECT SalesOrderID, CarrierTrackingNumber, ProductID, ModifiedDate,UnitPriceDiscount
    FROM Sales.SalesOrderDetail WITH (INDEX = [IX_SOD_4])
        WHERE ProductID = 738 AND OrderQty = 9 ;

SELECT * FROM Person.Address  WITH (INDEX = [IX_PA_1])
    WHERE AddressLine1 LIKE '975%'

SELECT * FROM Person.Address WITH (INDEX = [IX_PA_2])
    WHERE AddressLine1 LIKE '975%'


SELECT [AddressLine2], [City],[StateProvinceID], [PostalCode] 
    FROM Person.Address  WITH (INDEX = [IX_PA_1])
        WHERE AddressLine1 LIKE '975%'

SELECT [AddressLine2], [City],[StateProvinceID], [PostalCode] 
    FROM Person.Address WITH (INDEX = [IX_PA_2])
        WHERE AddressLine1 LIKE '975%'


SET STATISTICS IO OFF

   
--  Although in this example the diff is slight it shows this can make a difference
SELECT page_count,record_count, * 
FROM sys.dm_db_index_physical_stats(DB_ID(),OBJECT_ID('Sales.SalesOrderDetail'),INDEXPROPERTY(OBJECT_ID('Sales.SalesOrderDetail'),'IX_SOD_1','IndexID'),NULL,'DETAILED')
SELECT page_count,record_count, * 
FROM sys.dm_db_index_physical_stats(DB_ID(),OBJECT_ID('Sales.SalesOrderDetail'),INDEXPROPERTY(OBJECT_ID('Sales.SalesOrderDetail'),'IX_SOD_2','IndexID'),NULL,'DETAILED')
SELECT page_count,record_count, * 
FROM sys.dm_db_index_physical_stats(DB_ID(),OBJECT_ID('Sales.SalesOrderDetail'),INDEXPROPERTY(OBJECT_ID('Sales.SalesOrderDetail'),'IX_SOD_3','IndexID'),NULL,'DETAILED')
SELECT page_count,record_count, * 
FROM sys.dm_db_index_physical_stats(DB_ID(),OBJECT_ID('Sales.SalesOrderDetail'),INDEXPROPERTY(OBJECT_ID('Sales.SalesOrderDetail'),'IX_SOD_4','IndexID'),NULL,'DETAILED')

SELECT page_count,record_count, * 
FROM sys.dm_db_index_physical_stats(DB_ID(),OBJECT_ID('Person.Address'),INDEXPROPERTY(OBJECT_ID('Person.Address'),'IX_PA_1','IndexID'),NULL,'DETAILED')
SELECT page_count,record_count, * 
FROM sys.dm_db_index_physical_stats(DB_ID(),OBJECT_ID('Person.Address'),INDEXPROPERTY(OBJECT_ID('Person.Address'),'IX_PA_2','IndexID'),NULL,'DETAILED')


----------------------------------------------

--   Filtered Indexes


--  What index does this query use?
SELECT OrderDate, Status,SalesOrderID, SalesOrderNumber
FROM Sales.SalesOrderHeader --WITH (INDEX = [IX_SalesOrderHeader_ProductID_F_ShipMethodID_OnlineOrderFlag])
WHERE OrderDate = '20010701 00:00:00.000' AND ShipMethodID = 5 AND OnlineOrderFlag = 1 OPTION (RECOMPILE) ;


--  Create a Filtered index index
DROP INDEX [IX_SalesOrderHeader_OrderDate_F_ShipMethodID_OnlineOrderFlag_I_Status] ON [Sales].[SalesOrderHeader] 

CREATE NONCLUSTERED INDEX [IX_SalesOrderHeader_OrderDate_F_ShipMethodID_OnlineOrderFlag_I_Status] ON [Sales].[SalesOrderHeader] 
([OrderDate] ) INCLUDE ([Status] )  WHERE [ShipMethodID] = 5 AND [OnlineOrderFlag] = 1 ;

--  Now take a look at the plan
SELECT OrderDate, Status,SalesOrderID, SalesOrderNumber
FROM Sales.SalesOrderHeader --WITH (INDEX = [IX_SalesOrderHeader_ProductID_F_ShipMethodID_OnlineOrderFlag])
WHERE OrderDate = '20010701 00:00:00.000' AND ShipMethodID = 5 AND OnlineOrderFlag = 1 OPTION (RECOMPILE) ;



DROP INDEX [IX_SalesOrderHeader_OrderDate_ShipMethodID_OnlineOrderFlag_I_Status] ON [Sales].[SalesOrderHeader] 

CREATE NONCLUSTERED INDEX [IX_SalesOrderHeader_OrderDate_ShipMethodID_OnlineOrderFlag_I_Status] ON [Sales].[SalesOrderHeader] 
([OrderDate], [ShipMethodID], [OnlineOrderFlag] ) INCLUDE ([Status] ) ;

--  Compare the stats for each of the indexes
DBCC SHOW_STATISTICS('Sales.SalesOrderHeader','IX_SalesOrderHeader_OrderDate_F_ShipMethodID_OnlineOrderFlag_I_Status') ;

DBCC SHOW_STATISTICS('Sales.SalesOrderHeader','IX_SalesOrderHeader_OrderDate_ShipMethodID_OnlineOrderFlag_I_Status') ;


--  What do they look like in sys.indexes?  Get the ID's for both indexes
SELECT * FROM sys.indexes WHERE [object_id] = OBJECT_ID('Sales.SalesOrderHeader') ;


SELECT page_count,record_count, * 
    FROM sys.dm_db_index_physical_stats(DB_ID(),OBJECT_ID('Sales.SalesOrderHeader'),13,NULL,'DETAILED')
SELECT page_count,record_count, * 
    FROM sys.dm_db_index_physical_stats(DB_ID(),OBJECT_ID('Sales.SalesOrderHeader'),14,NULL,'DETAILED')




/*
UPDATE STATISTICS Sales.SalesOrderDetail WITH FULLSCAN ;

UPDATE STATISTICS Sales.SalesOrderHeader WITH FULLSCAN ;
*/


-- Cleanup

DROP INDEX [IX_SOD_1] ON [Sales].[SalesOrderDetail] ;
DROP INDEX [IX_SOD_2] ON [Sales].[SalesOrderDetail] ;
DROP INDEX [IX_SOD_3] ON [Sales].[SalesOrderDetail] ;
DROP INDEX [IX_SOD_4] ON [Sales].[SalesOrderDetail] ;
DROP INDEX [IX_PA_1] ON [Person].[Address]  ;
DROP INDEX [IX_PA_2] ON [Person].[Address]  ;

DROP INDEX [IX_SalesOrderHeader_OrderDate_ShipMethodID_OnlineOrderFlag_I_Status] ON [Sales].[SalesOrderHeader] 
DROP INDEX [IX_SalesOrderHeader_OrderDate_F_ShipMethodID_OnlineOrderFlag_I_Status] ON [Sales].[SalesOrderHeader] 
