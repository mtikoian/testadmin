USE IndexDemo;
go

-- All existing indexes have LastName as the first indexed column.
-- The filtered index will only have FirstName as indexed column,
-- and it will only be made for LastNames starting with R-V.
CREATE   NONCLUSTERED INDEX ix_FirstName_Filter
ON       dbo.Persons (FirstName)
WHERE    LastName >= 'R'
AND      LastName <  'W';
go

-- This query uses the exact same filter on LastName,
-- so you would expect the filtered index will be used.
-- Q: Why isn't it?
-- A: This is (currently) a "fuctionality gap" in the Query Optimizer

SET STATISTICS IO ON;

SELECT COUNT(*)
FROM   dbo.Persons --WITH (INDEX(ix_FirstName_Filter)) --NO SEEK?!?
WHERE  LastName >= 'R'
AND    LastName <  'W';



-- After adding a filter on FirstName, the indexed column may get used.

SELECT COUNT(*)
FROM   dbo.Persons -- WITH (INDEX(ix_PersonName))
WHERE  LastName >= 'R'
AND    LastName <  'W'
AND    FirstName = 'Audrey';

SELECT COUNT(*)
FROM   dbo.Persons  --WITH (INDEX(ix_FirstName_Filter))
WHERE  LastName >= 'R'
AND    LastName <  'W'
AND    FirstName LIKE 'A%';



-- The filtered index can't be used for the query below,
-- because there might (in theory) be a row with LastName equal to 'W'.

SELECT COUNT(*)
FROM   dbo.Persons -- WITH (INDEX(ix_FirstName_Filter))
WHERE  LastName BETWEEN 'R' AND 'W'
AND    FirstName = 'Audrey';


-- The filtered index can be used if the filter in the query is stricter.
--nope, still won't use it
SELECT COUNT(*)
FROM   dbo.Persons -- WITH (INDEX(ix_FirstName_Filter))
--WHERE  LastName BETWEEN 'S' AND 'T'
WHERE  LastName >= 'S' AND LastName <  'T'
AND    FirstName = 'Audrey';

SET STATISTICS IO OFF;


-- Including the filtered column may make the filtered index more
-- useful for queries (especially if WHERE is more strict than index)
CREATE   NONCLUSTERED INDEX ix_FirstName_Filter_Incl_LastName
ON       dbo.Persons (FirstName)
INCLUDE (LastName)
WHERE    LastName >= 'R'
AND      LastName <  'W';
go

--better example
USE AdventureWorks2012
go
SELECT SpecialOfferID, COUNT(*)
FROM Sales.SalesOrderDetail
GROUP BY SpecialOfferID
ORDER BY COUNT(*) DESC

SpecialOfferID 
-------------- -----------
1              115884
2              3428
3              606
13             524
14             244
16             169
7              137
8              98
11             84
4              80
9              61
5              2

HUGE VALUE distribution disparity.  
If ID 1 is used in a where clause, want table scan, otherwise want index seek and bookmark lookup

CREATE NONCLUSTERED INDEX ix_SalesOrderDetail_ID_Not_1
ON Sales.SalesOrderDetail (SpecialOfferID)
WHERE SpecialOfferID <> 1

the above index will get you seeks when should get them, scans when should get them
yet takes up only ~5% of total space of a normal unfiltered index!!

--Show stats IO and actual plan
SET STATISTICS IO ON
GO
SELECT * FROM Sales.SalesOrderDetail WHERE SpecialOfferID = 1
go
SELECT * FROM Sales.SalesOrderDetail WHERE SpecialOfferID = 14
go
