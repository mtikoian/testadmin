USE IndexDemo;
go

-- There is no good index to support the query below.
-- The optimizer has to settle for a clustered index scan.

SET STATISTICS IO ON;

SELECT   LastName, AVG(EmailLen) AS AvgEmailLen
FROM     dbo.Persons
GROUP BY LastName;

-- Creating a "normal" view costs almost nothing,
-- but it also doesn't help performance.

-- Note that a CREATE VIEW always needs its own batch
go
CREATE VIEW dbo.LastName_AvgMailLen
AS SELECT   LastName, AVG(EmailLen) AS AvgEmailLen
   FROM     dbo.Persons
   GROUP BY LastName;
go

SELECT LastName, AvgEmailLen
FROM   dbo.LastName_AvgMailLen;

-- Creating an indexed view does incur a cost at creation time,
-- but can save a lot of time when queried
-- There are a lot of restrictions, though.

go
CREATE VIEW dbo.LastName_Plus_Stats
       WITH SCHEMABINDING
AS SELECT   LastName, SUM(EmailLen) AS SumEmailLen, COUNT_BIG(*) AS CountPersons
   FROM     dbo.Persons
   GROUP BY LastName;
go

CREATE UNIQUE CLUSTERED INDEX ix_LastName_Plus_Stats
    ON dbo.LastName_Plus_Stats(LastName)
go

-- The WITH (NOEXPAND) hint is required on all editions except Enterprise
-- (or Developer, which is functionally equivalent to Enterprise)

SELECT LastName, SumEmailLen / CountPersons AS AvgEmailLen
FROM   dbo.LastName_Plus_Stats WITH (NOEXPAND);

-- On Enterprise (and Developer) edition, the hint is not required.
-- In fact, it is not even required to reference the view directly,
-- and SQL Server is also smart enough to figure out the average calculation.

SELECT   LastName, AVG(EmailLen) AS AvgEmailLen
FROM     dbo.Persons
GROUP BY LastName;

-- Indexed views can also be used when a subset of their rows are needed.

SELECT   AVG(EmailLen)
FROM     dbo.Persons
WHERE    LastName = 'Kelly';

-- Though I never encountered a situation where it is actually useful,
-- it is possible to defined additional nonclustered indexes.
CREATE NONCLUSTERED INDEX ix_SumEmailLen
    ON dbo.LastName_Plus_Stats(SumEmailLen);

-- Completely nonsensical query to show the index being used
SELECT   LastName, SUM(EmailLen)
FROM     dbo.Persons
GROUP BY LastName
HAVING   SUM(EmailLen) > 100000;

-- On non Enterprise Edition, use the query below.
SELECT   LastName, SumEmailLen
FROM     dbo.LastName_Plus_Stats WITH (NOEXPAND)
WHERE    SumEmailLen > 100000;

SET STATISTICS IO OFF;
