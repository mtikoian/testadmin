USE IndexDemo;
go
SET STATISTICS TIME ON;

-- Delete 10,000 rows (update and insert have similar effects)
-- Check the execution plan for impact of all these indexes
BEGIN TRANSACTION;

DELETE dbo.Persons 
WHERE  PersonID BETWEEN 100000 AND 110000;

ROLLBACK TRANSACTION;
go


-- Delete all indexes and indexed views,
-- then do the same DELETE statement again.
BEGIN TRANSACTION;

DROP INDEX dbo.Persons.ix_FirstName_Filter;
DROP INDEX dbo.Persons.ix_FirstName_Filter_Incl_LastName;
DROP INDEX dbo.Persons.ix_PersonName;
DROP INDEX dbo.Persons.ix_PersonName_Include;
DROP INDEX dbo.Persons.ix_EmailLen;
DROP INDEX dbo.Persons.ix_FirstName_EmailLen;
DROP INDEX dbo.Persons.ix_FirstName_LastName;
DROP VIEW  dbo.LastName_Plus_Stats;

DELETE dbo.Persons 
WHERE  PersonID BETWEEN 100000 AND 110000;

ROLLBACK TRANSACTION;
go

SET STATISTICS TIME OFF;
go
