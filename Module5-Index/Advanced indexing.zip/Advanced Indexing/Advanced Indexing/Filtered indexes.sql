USE IndexDemo;
go

-- All existing indexes have LastName as the first indexed column.
-- The filtered index will only have FirstName as indexed column,
-- and it will only be made for LastNames starting with R-V.
CREATE   NONCLUSTERED INDEX ix_FirstName_Filter
ON       dbo.Persons (FirstName)
WHERE    LastName >= 'R'
AND      LastName <  'W';
go

-- This query uses the exact same filter on LastName,
-- so you would expect the filtered index will be used.
-- Q: Why isn't it?
-- A: This is (currently) a "fuctionality gap" in the Query Optimizer

SET STATISTICS IO ON;

SELECT COUNT(*)
FROM   dbo.Persons -- WITH (INDEX(ix_FirstName_Filter))
WHERE  LastName >= 'R'
AND    LastName <  'W';



-- After adding a filter on FirstName, the indexed column may get used.

SELECT COUNT(*)
FROM   dbo.Persons -- WITH (INDEX(ix_FirstName_Filter))
WHERE  LastName >= 'R'
AND    LastName <  'W'
AND    FirstName = 'Audrey';

SELECT COUNT(*)
FROM   dbo.Persons -- WITH (INDEX(ix_FirstName_Filter))
WHERE  LastName >= 'R'
AND    LastName <  'W'
AND    FirstName LIKE 'A%';



-- The filtered index can't be used for the query below,
-- because there might (in theory) be a row with LastName equal to 'W'.

SELECT COUNT(*)
FROM   dbo.Persons -- WITH (INDEX(ix_FirstName_Filter))
WHERE  LastName BETWEEN 'R' AND 'W'
AND    FirstName = 'Audrey';


-- The filtered index can be used if the filter in the query is stricter.

SELECT COUNT(*)
FROM   dbo.Persons -- WITH (INDEX(ix_FirstName_Filter))
WHERE  LastName BETWEEN 'R' AND 'V'
AND    FirstName = 'Audrey';

SET STATISTICS IO OFF;


-- Including the filtered column may make the filtered index more
-- useful for queries (especially if WHERE is more strict than index)
CREATE   NONCLUSTERED INDEX ix_FirstName_Filter_Incl_LastName
ON       dbo.Persons (FirstName)
INCLUDE (LastName)
WHERE    LastName >= 'R'
AND      LastName <  'W';
go
