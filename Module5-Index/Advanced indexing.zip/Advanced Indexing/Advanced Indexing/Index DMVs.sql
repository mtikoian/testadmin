USE IndexDemo;
go

-- Execute some queries for which there is no index
SELECT FirstName
FROM   dbo.Persons
WHERE  EmailLen = 50;

SELECT PersonID, FirstName
FROM   dbo.Persons
WHERE  EmailLen < 10
AND    FirstName LIKE 'B%';


-- Queries below originally written by Glenn Berry
-- I only reformatted them

-- Possible bad indexes (writes > reads) for current database
-- Note that writes > reads is not always a bad index
-- Also note that writes < reads is not always a good index,
--  especially if the difference is relatively small
SELECT     OBJECT_NAME(s.[object_id])  AS [Table Name],
           i.name                      AS [Index Name],
           i.index_id,
           user_updates                AS [Total Writes],
           user_seeks + user_scans + user_lookups
                                       AS [Total Reads],
           user_updates - (user_seeks + user_scans + user_lookups)
                                       AS [Difference]
FROM       sys.dm_db_index_usage_stats AS  s WITH (NOLOCK)
INNER JOIN sys.indexes                 AS  i WITH (NOLOCK)
      ON   s.[object_id]                =  i.[object_id]
      AND  i.index_id                   =  s.index_id
WHERE      OBJECTPROPERTY(s.[object_id],'IsUserTable')
                                        =  1
AND        s.database_id                =  DB_ID()
AND        user_updates                 > (user_seeks + user_scans + user_lookups)
AND        i.index_id                   >  1
ORDER BY  [Difference]   DESC,
          [Total Writes] DESC,
          [Total Reads]  ASC;


-- Missing Indexes for entire instance by Index Advantage
-- Look at last user seek time, number of user seeks to help determine source and importance
-- SQL Server is overly eager to add included columns, so beware
SELECT     user_seeks * avg_total_user_cost * (avg_user_impact * 0.01)
                                                AS [index_advantage], 
           migs.last_user_seek, mid.[statement] AS [Database.Schema.Table],
           mid.equality_columns,
           mid.inequality_columns,
           mid.included_columns,
           migs.unique_compiles,
           migs.user_seeks,
           migs.avg_total_user_cost,
           migs.avg_user_impact
FROM       sys.dm_db_missing_index_group_stats  AS  migs WITH (NOLOCK)
INNER JOIN sys.dm_db_missing_index_groups       AS  mig  WITH (NOLOCK)
      ON   migs.group_handle                     =  mig.index_group_handle
INNER JOIN sys.dm_db_missing_index_details      AS  mid  WITH (NOLOCK)
      ON   mig.index_handle                      =  mid.index_handle
ORDER BY   index_advantage    DESC;
go

-- Add all recommended missing indexes (not recommended!!!!!)
CREATE   NONCLUSTERED INDEX ix_EmailLen
ON       dbo.Persons(EmailLen)
INCLUDE (FirstName);

CREATE   NONCLUSTERED INDEX ix_FirstName_EmailLen
ON       dbo.Persons(FirstName, EmailLen)
INCLUDE (PersonID);

CREATE   NONCLUSTERED INDEX ix_FirstName_LastName
ON       dbo.Persons(FirstName, LastName);
