USE AdventureWorksDW2008XL;
GO

SET STATISTICS TIME ON;

--DBCC DROPCLEANBUFFERS;

-- Notice how the Filter operator severely reduces the amount of rows,
-- but does not change the amount of batches.
SELECT     rs.ProductKey
		 , COUNT(rs.SalesOrderNumber)   AS  NumberOfSales
         , SUM(rs.SalesAmount)          AS  TotalSalesAmount
FROM       dbo.FactResellerSalesXL      AS  rs
WHERE      rs.UnitPrice                 >=  rs.ExtendedAmount
GROUP BY   rs.ProductKey
ORDER BY   rs.ProductKey;
go
