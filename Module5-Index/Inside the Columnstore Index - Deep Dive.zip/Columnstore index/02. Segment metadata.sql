USE AdventureWorksDW2008XL;
go

SELECT     c.name                    AS "Column name",
           p.partition_number,
		   s.segment_id,
		   s.min_data_id,
		   s.max_data_id,
		   s.on_disk_size
FROM       sys.column_store_segments AS  s
INNER JOIN sys.partitions            AS  p
      ON   s.hobt_id                  =  p.hobt_id
INNER JOIN sys.indexes               AS  i 
      ON   i.object_id                =  p.object_id
      AND  i.type                     =  6                          -- Nonclustered columnstore index
--    AND  i.name                     = 'CSI_FactResellerSalesXL'   -- Optional filter on index name
LEFT  JOIN sys.columns               AS  c                          -- Use outer join to expose column for RID or uniqifier
      ON   c.object_id                =  p.object_id
	  AND  c.column_id                =  s.column_id
--WHERE    c.name                     = 'SalesOrderNumber'          -- Optional filter on column name
ORDER BY   s.column_id,
           s.partition_id,
		   s.segment_id;
go
