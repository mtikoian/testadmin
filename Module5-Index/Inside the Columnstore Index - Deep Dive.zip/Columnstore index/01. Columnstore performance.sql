USE AdventureWorksDW2008XL;
GO

SET STATISTICS TIME ON;

--DBCC DROPCLEANBUFFERS;

-- Here's a fairly standard query on the (enlarged) FactResellerSales table.
-- We want a report of the total sales, aggregated by product,
-- for sales made outside of North America.
-- Dropping and ruilding the columnstore index takes too much time, so I use the
-- IGNORE_NONCLUSTERED_COLUMNSTORE_INDEX hint to mimic behaviour without CS index.
SELECT     p.EnglishProductName
		 , COUNT(rs.SalesOrderNumber)   AS  NumberOfSales
         , SUM(rs.SalesAmount)          AS  TotalSalesAmount
FROM       dbo.FactResellerSalesXL      AS  rs
INNER JOIN dbo.DimSalesTerritory        AS  st
      ON   st.SalesTerritoryKey          =  rs.SalesTerritoryKey
      AND  st.SalesTerritoryCountry NOT IN('United States', 'Canada')
INNER JOIN dbo.DimProduct               AS  p
      ON   p.ProductKey                  =  rs.ProductKey
GROUP BY   p.EnglishProductName
ORDER BY   p.EnglishProductName
OPTION (IGNORE_NONCLUSTERED_COLUMNSTORE_INDEX);

-- Elapsed times for above query (without columnstore index)
-- Measured as average of three consecutive tests, with no other programs active

-- Execution time with "cold" cache: 132427 ms
-- Execution time with "hot" cache:   11004 ms
go

--DBCC DROPCLEANBUFFERS;

-- But we may want to include all the products, even those without sales.
-- So we have to change one join type to be an OUTER join
SELECT     p.EnglishProductName
		 , COUNT(rs.SalesOrderNumber)   AS  NumberOfSales
         , SUM(rs.SalesAmount)          AS  TotalSalesAmount
FROM       dbo.FactResellerSalesXL      AS  rs
INNER JOIN dbo.DimSalesTerritory        AS  st
      ON   st.SalesTerritoryKey          =  rs.SalesTerritoryKey
      AND  st.SalesTerritoryCountry NOT IN('United States', 'Canada')
RIGHT OUTER JOIN dbo.DimProduct         AS  p
      ON   p.ProductKey                  =  rs.ProductKey
GROUP BY   p.EnglishProductName
ORDER BY   p.EnglishProductName
OPTION (IGNORE_NONCLUSTERED_COLUMNSTORE_INDEX);

-- Elapsed times for above query (without columnstore index)
-- Measured as average of three consecutive tests, with no other programs active

-- Execution times with "cold" cache: 132969 ms
-- Execution times with "hot" cache:   16788 ms
go



--DBCC DROPCLEANBUFFERS;

-- Here is the first query again, but now without a hint;
-- the optimizer will pick the columnstore index,
-- and use batch mode for a large part of the plan.
SELECT     p.EnglishProductName
		 , COUNT(rs.SalesOrderNumber)   AS  NumberOfSales
         , SUM(rs.SalesAmount)          AS  TotalSalesAmount
FROM       dbo.FactResellerSalesXL      AS  rs
INNER JOIN dbo.DimSalesTerritory        AS  st
      ON   st.SalesTerritoryKey          =  rs.SalesTerritoryKey
      AND  st.SalesTerritoryCountry NOT IN('United States', 'Canada')
INNER JOIN dbo.DimProduct               AS  p
      ON   p.ProductKey                  =  rs.ProductKey
GROUP BY   p.EnglishProductName
ORDER BY   p.EnglishProductName;

-- Execution time with "cold" cache: 1873 ms = 70,7 x faster
-- Execution time with "hot" cache:   304 ms = 36.2 x faster
go

--DBCC DROPCLEANBUFFERS;

-- Here is the second query again, but now without a hint;
-- the optimizer will pick the columnstore index,
-- but batch mode cannot be used because of the outer join.
SELECT     p.EnglishProductName
		 , COUNT(rs.SalesOrderNumber)   AS  NumberOfSales
         , SUM(rs.SalesAmount)          AS  TotalSalesAmount
FROM       dbo.FactResellerSalesXL      AS  rs
INNER JOIN dbo.DimSalesTerritory        AS  st
      ON   st.SalesTerritoryKey          =  rs.SalesTerritoryKey
      AND  st.SalesTerritoryCountry NOT IN('United States', 'Canada')
RIGHT OUTER JOIN dbo.DimProduct         AS  p
      ON   p.ProductKey                  =  rs.ProductKey
GROUP BY   p.EnglishProductName
ORDER BY   p.EnglishProductName;

-- Execution times with "cold" cache: 15903 ms = 8.4 x faster
-- Execution times with "hot" cache:   8659 ms = 1.9 x faster
go
