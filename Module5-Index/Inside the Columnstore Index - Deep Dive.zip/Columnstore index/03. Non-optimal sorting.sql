USE tempdb;
go

-- Create (after dropping if it exists) a sufficiently large test database
-- (Change the path names in the CREATE DATABASE statement for your system)

IF EXISTS (SELECT * FROM sys.databases WHERE name = 'TestCSindex')
BEGIN;
  ALTER DATABASE TestCSindex SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
  DROP DATABASE TestCSindex;
END;
go

CREATE DATABASE TestCSindex
    ON (NAME = N'TestCSindex',     FILENAME = N'D:\SQL 2012\Data\TestCSindex.mdf',     SIZE = 200MB, FILEGROWTH = 20MB)
LOG ON (NAME = N'TestCSindex_log', FILENAME = N'C:\SQL 2012\Log\TestCSindex_log.ldf' , SIZE = 400MB, FILEGROWTH = 20MB);
go

USE TestCSindex;
GO

-- Create a table with test data.
-- Note that the following will be true about correlations:
-- 1. PK is the primary key, an ever increasing number
-- 2. Col1 is generated with random numbers, 0 through 500, so no correlation to PK
-- 3. Col2 is equal to Col1 + 1, so 100% correlated to Col1
-- 4. Col3 is highly correlated to Col1 and Col2 (mostly Col2 + 1, but 1% is Col2 + 1000)
-- 5. Col4 is equal to Col1 in the "first" (by PK) 100,000 rows; totally uncorrelated after that

CREATE TABLE TestData
       (PK int PRIMARY KEY CLUSTERED,
        Col1 int NOT NULL,
        Col2 int NOT NULL,
        Col3 int NOT NULL,
        Col4 int NOT NULL);
go

DECLARE @i int, @c1 int, @c2 int, @c3 int, @c4 int;

SET @i = RAND(1234);         -- Reseed randomizer for repeatability
SET @i = 1;

WHILE @i <= 500000
BEGIN;
  SET @c1 = RAND() * 500;
  SET @c2 = @c1 + 1;
  IF RAND() < 0.01                      -- Col3 has 1% outliers
    SET @c3 = @c2 + 100;
  ELSE
    SET @c3 = @c2 + 1;
  IF @i < 100000                        -- Col4 correlates only for first 100,000 rows
    SET @c4 = @c1;
  ELSE
    SET @c4 = RAND() * 500;

  INSERT INTO TestData (PK, Col1, Col2, Col3, Col4)
  VALUES (@i, @c1, @c2, @c3, @c4);
  SET @i += 1;
  IF @i % 1000 = 0 PRINT @i;
END;
go

-- Create five copies of the data, "ordered" (clustered index) by each of the columns
SELECT PK, Col1, Col2, Col3, Col4, ROW_NUMBER() OVER(ORDER BY PK) AS RN
INTO   ClusterPK
FROM   TestData;
CREATE UNIQUE CLUSTERED INDEX ix_RN ON ClusterPK(RN);

SELECT PK, Col1, Col2, Col3, Col4, ROW_NUMBER() OVER(ORDER BY Col1) AS RN
INTO   Cluster1
FROM   TestData;
CREATE UNIQUE CLUSTERED INDEX ix_RN ON Cluster1(RN);

SELECT PK, Col1, Col2, Col3, Col4, ROW_NUMBER() OVER(ORDER BY Col2) AS RN
INTO   Cluster2
FROM   TestData;
CREATE UNIQUE CLUSTERED INDEX ix_RN ON Cluster2(RN);

SELECT PK, Col1, Col2, Col3, Col4, ROW_NUMBER() OVER(ORDER BY Col3) AS RN
INTO   Cluster3
FROM   TestData;
CREATE UNIQUE CLUSTERED INDEX ix_RN ON Cluster3(RN);

SELECT PK, Col1, Col2, Col3, Col4, ROW_NUMBER() OVER(ORDER BY Col4) AS RN
INTO   Cluster4
FROM   TestData;
CREATE UNIQUE CLUSTERED INDEX ix_RN ON Cluster4(RN);
go

-- Create columnstore indexes on each of those tables.
CREATE NONCLUSTERED COLUMNSTORE INDEX csiPK ON ClusterPK (PK, Col1, Col2, Col3, Col4);
CREATE NONCLUSTERED COLUMNSTORE INDEX csiCol1 ON Cluster1 (PK, Col1, Col2, Col3, Col4);
CREATE NONCLUSTERED COLUMNSTORE INDEX csiCol2 ON Cluster2 (PK, Col1, Col2, Col3, Col4);
CREATE NONCLUSTERED COLUMNSTORE INDEX csiCol3 ON Cluster3 (PK, Col1, Col2, Col3, Col4);
CREATE NONCLUSTERED COLUMNSTORE INDEX csiCol4 ON Cluster4 (PK, Col1, Col2, Col3, Col4);
go

-- Inspect metadata - focus on "on_disk_size" column
SELECT     i.name                    AS "Index name",
           s.column_id,
           c.name                    AS "Column name",
           s.partition_id,
           s.segment_id,
           s.min_data_id,
           s.max_data_id,
           s.on_disk_size
FROM       sys.column_store_segments AS  s
INNER JOIN sys.partitions            AS  p
      ON   s.hobt_id                  =  p.hobt_id
INNER JOIN sys.indexes               AS  i 
      ON   i.object_id                =  p.object_id
      AND  i.type                     =  6             -- Columnstore index
LEFT  JOIN sys.columns               AS  c             -- Left join to not exclude "internal" columns
      ON   c.object_id                =  p.object_id
      AND  c.column_id                =  s.column_id
ORDER BY   i.name,
           s.column_id,
           s.partition_id,
           s.segment_id;

-- Or just check the total on_disk_size per table
SELECT       IndexName,
             SUM(on_disk_size)
FROM
 (SELECT     i.name                    AS  IndexName,
             s.on_disk_size
  FROM       sys.column_store_segments AS  s
  INNER JOIN sys.partitions            AS  p
        ON   s.hobt_id                  =  p.hobt_id
  INNER JOIN sys.indexes               AS  i 
        ON   i.object_id                =  p.object_id
        AND  i.type                     =  6) AS x
GROUP BY     IndexName
ORDER BY     IndexName;
go

-- Clean up
DROP INDEX csiPK ON ClusterPK;
DROP INDEX csiCol1 ON Cluster1;
DROP INDEX csiCol2 ON Cluster2;
DROP INDEX csiCol3 ON Cluster3;
DROP INDEX csiCol4 ON Cluster4;
go

DROP TABLE ClusterPK;
DROP TABLE Cluster1;
DROP TABLE Cluster2;
DROP TABLE Cluster3;
DROP TABLE Cluster4;
go
