-- These demos use a modified copy of the demo database AdventureWorksDW2008.
-- The only modification is the addition of a new table: FactResellerSalesXL.
-- The schema of this table is exactly identical to FactResellerSales,
-- but a huge amount of extra data has been added to get more than a million rows.

-- I did not make this database myself, and I have no permission to redistribute it;
-- unfortunately, this means other people cannot run the demos.
-- They should all work on the standard FactResellerSales table,
-- but due to its smaller size, the columnstore index will not give much performance benefit here,
-- and batch mode will probably never be used.

USE AdventureWorksDW2008XL
go

SELECT COUNT(*) FROM dbo.FactResellerSales;
--      60,855 rows

SELECT COUNT(*) FROM dbo.FactResellerSalesXL;
-- 101,203,430 rows

-- Note that, apart from the extra rows, there is NO difference between the two tables.
-- FactResellerSalesXL has all the same keys, constraints, indexes, etc.
-- With, obviously, the added columnstore index as the only difference.
go
