USE AdventureWorksDW2008XL;
go

SELECT     c.name                    AS "Column name",
           s.partition_id,
		   s.segment_id,
		   s.min_data_id,
		   s.max_data_id,
		   s.on_disk_size,
           s.version,
           s.encoding_type,
           s.base_id,
           s.magnitude,
           s.primary_dictionary_id,
           s.secondary_dictionary_id,
           s.has_nulls,
           s.null_value
FROM       sys.column_store_segments AS  s
INNER JOIN sys.partitions            AS  p
      ON   s.hobt_id                  =  p.hobt_id
INNER JOIN sys.indexes               AS  i 
      ON   i.object_id                =  p.object_id
      AND  i.type                     =  6                          -- Nonclustered columnstore index
--    AND  i.name                     = 'CSI_FactResellerSalesXL'   -- Optional filter on index name
LEFT  JOIN sys.columns               AS  c                          -- Use outer join to expose column for RID or uniqifier
      ON   c.object_id                =  p.object_id
	  AND  c.column_id                =  s.column_id
--WHERE    c.name                     = 'SalesOrderNumber'          -- Optional filter on column name
ORDER BY   s.column_id,
           s.partition_id,
		   s.segment_id;

SELECT     c.name                    AS "Column name",
           d.partition_id,
           d.dictionary_id,
           d.version,
		   d.type,
           d.flags,
           d.last_id,
           d.entry_count,
           d.on_disk_size
FROM       sys.column_store_dictionaries AS d
INNER JOIN sys.partitions                AS  p
      ON   d.hobt_id                      =  p.hobt_id
INNER JOIN sys.indexes                   AS  i 
      ON   i.object_id                    =  p.object_id
      AND  i.type                         =  6                          -- Nonclustered columnstore index
--    AND  i.name                         = 'CSI_FactResellerSalesXL'   -- Optional filter on index name
LEFT  JOIN sys.columns                   AS  c                          -- Use outer join to expose column for RID or uniqifier
      ON   c.object_id                    =  p.object_id
	  AND  c.column_id                    =  d.column_id
--WHERE    c.name                         = 'SalesOrderNumber'          -- Optional filter on column name
ORDER BY   d.column_id,
           d.partition_id,
           d.dictionary_id;
go




IF OBJECT_ID('dbo.TestTable') IS NOT NULL
BEGIN;
  DROP TABLE dbo.TestTable;
END;
go

CREATE TABLE dbo.TestTable
    (KeyCol     int          NOT NULL PRIMARY KEY,
     MultOf1000 int          NULL,
     VeryBig    int          NULL,
     Num0To9    tinyint      NULL,
     TextData   varchar(100) NULL,
     HasNulls   int          NULL);
go

DECLARE @i int = 0;
WHILE @i <= 999
BEGIN;
  INSERT INTO dbo.TestTable (KeyCol, MultOf1000, VeryBig, Num0To9, TextData, HasNulls)
  VALUES (@i, @i * 1000, @i + 12345678, @i % 10,
          CASE WHEN @i % 2 = 0 THEN 'This is an even number' ELSE 'This is an odd number' END,
          CASE WHEN @i = 800 THEN NULL ELSE @i END);
  SET @i += 1;
END;

CREATE NONCLUSTERED COLUMNSTORE INDEX CSI_TestTable
    ON dbo.TestTable (KeyCol, MultOf1000, VeryBig, Num0To9, TextData, HasNulls);
go

SELECT     c.name                    AS "Column name",
           s.partition_id,
		   s.segment_id,
		   s.min_data_id,
		   s.max_data_id,
		   s.on_disk_size,
           s.version,
           s.encoding_type,
           s.base_id,
           s.magnitude,
           s.primary_dictionary_id,
           s.secondary_dictionary_id,
           s.has_nulls,
           s.null_value
FROM       sys.column_store_segments AS  s
INNER JOIN sys.partitions            AS  p
      ON   s.hobt_id                  =  p.hobt_id
INNER JOIN sys.indexes               AS  i 
      ON   i.object_id                =  p.object_id
      AND  i.type                     =  6                          -- Nonclustered columnstore index
      AND  i.name                     = 'CSI_TestTable'             -- Optional filter on index name
LEFT  JOIN sys.columns               AS  c                          -- Use outer join to expose column for RID or uniqifier
      ON   c.object_id                =  p.object_id
	  AND  c.column_id                =  s.column_id
--WHERE    c.name                     = 'SalesOrderNumber'          -- Optional filter on column name
ORDER BY   s.column_id,
           s.partition_id,
		   s.segment_id;

SELECT     c.name                    AS "Column name",
           d.partition_id,
           d.dictionary_id,
           d.version,
		   d.type,
           d.flags,
           d.last_id,
           d.entry_count,
           d.on_disk_size
FROM       sys.column_store_dictionaries AS d
INNER JOIN sys.partitions                AS  p
      ON   d.hobt_id                      =  p.hobt_id
INNER JOIN sys.indexes                   AS  i 
      ON   i.object_id                    =  p.object_id
      AND  i.type                         =  6                          -- Nonclustered columnstore index
      AND  i.name                         = 'CSI_TestTable'             -- Optional filter on index name
LEFT  JOIN sys.columns                   AS  c                          -- Use outer join to expose column for RID or uniqifier
      ON   c.object_id                    =  p.object_id
	  AND  c.column_id                    =  d.column_id
--WHERE    c.name                         = 'SalesOrderNumber'          -- Optional filter on column name
ORDER BY   d.column_id,
           d.partition_id,
           d.dictionary_id;
go

DROP TABLE dbo.TestTable;
go
