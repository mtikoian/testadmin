USE AdventureWorksDW2008XL;
GO

SET STATISTICS IO ON;

--DBCC DROPCLEANBUFFERS;

-- Here's a fairly standard query on the (enlarged) FactResellerSales table.
-- We want a report of the total sales, aggregated by product,
-- for sales made outside of North America.
-- Dropping and ruilding the columnstore index takes too much time, so I use the
-- IGNORE_NONCLUSTERED_COLUMNSTORE_INDEX hint to mimic behaviour without CS index.
SELECT     p.EnglishProductName
		 , COUNT(rs.SalesOrderNumber)   AS  NumberOfSales
         , SUM(rs.SalesAmount)          AS  TotalSalesAmount
FROM       dbo.FactResellerSalesXL      AS  rs
INNER JOIN dbo.DimSalesTerritory        AS  st
      ON   st.SalesTerritoryKey          =  rs.SalesTerritoryKey
      AND  st.SalesTerritoryCountry      =  'United Kingdom'
INNER JOIN dbo.DimProduct               AS  p
      ON   p.ProductKey                  =  rs.ProductKey
GROUP BY   p.EnglishProductName
ORDER BY   p.EnglishProductName;

SELECT     p.EnglishProductName
		 , COUNT(rs.SalesOrderNumber)   AS  NumberOfSales
         , SUM(rs.SalesAmount)          AS  TotalSalesAmount
FROM       dbo.FactResellerSalesXL      AS  rs
INNER JOIN dbo.DimSalesTerritory        AS  st
      ON   st.SalesTerritoryKey          =  rs.SalesTerritoryKey
      AND  st.SalesTerritoryCountry     <>  'United Kingdom'
INNER JOIN dbo.DimProduct               AS  p
      ON   p.ProductKey                  =  rs.ProductKey
GROUP BY   p.EnglishProductName
ORDER BY   p.EnglishProductName;
