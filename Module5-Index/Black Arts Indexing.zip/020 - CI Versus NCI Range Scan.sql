-------------------------------------------------------------------------------
--Demonstrate different approaches of running a query for the number of rows in
--a specific range using the clustering key as the search criteria.
-------------------------------------------------------------------------------

USE Indexing;
go

--Make sure the indexes don't already exist
IF (SELECT COUNT(*) FROM sys.indexes WHERE name = 'Scores_IDX01') > 0
  BEGIN
    DROP INDEX Scores_IDX01 ON dbo.Scores;
  END;

IF (SELECT COUNT(*) FROM sys.indexes WHERE name = 'Scores_IDX02') > 0
  BEGIN
    DROP INDEX Scores_IDX02 ON dbo.Scores;
  END;

--Set the statistics on so we can see the number of reads for each query
SET STATISTICS IO ON;

-------------------------------------------------------------------------------
--Query for the number of rows in a specific range using the clustering key 
--as the criteria.
-------------------------------------------------------------------------------
--Run the query.
--An index seek against the CI was used and took 30,052 reads.
--The reads are so high because the very wide rows had to be read.
SELECT COUNT(*) 
  FROM dbo.Scores
  WHERE ID >= 10000
    AND ID <  40000;

--Create the same nonclustered index used to cover the previous query.
--This isn't ideal, but will help.
CREATE NONCLUSTERED INDEX Scores_IDX01 ON dbo.Scores(Score);

--Run the query.
--An index scan was used against the NCI and took 176 reads.
--A scan was used instead of a seek because the Score column is the leading 
--edge in the NCI, not the ID column. Because the index isn't sorted by ID,
--the optimizer knew it couldn't do a seek.
SELECT COUNT(*) 
  FROM dbo.Scores
  WHERE ID >= 10000
    AND ID <  40000;

--That didn't have the desired affect, so drop that index.
DROP INDEX Scores_IDX01 ON dbo.Scores;

--Create an NCI to cover the query.
--Note that the NCI key is the same exact column as the clustering key.
--> This will be viewed by most as a "duplicate index" because the NCI key <--
--> column is the same as the clustering key.                              <--
CREATE NONCLUSTERED INDEX Scores_IDX02 ON dbo.Scores(ID);

--Run the same query a third time and see the same results.
--This time, an index seek was used against the new NCI and took 40 reads.
SELECT COUNT(*) 
  FROM dbo.Scores
  WHERE ID >= 10000
    AND ID <  40000;

--The very narrow NCI on ID, which is the same key as the clustering key, but
--much narrower than the CI, resulted in reads being reduced by 99.86%.

-------------------------------------------------------------------------------
--Clean up
-------------------------------------------------------------------------------
IF (SELECT COUNT(*) FROM sys.indexes WHERE name = 'Scores_IDX01') > 0
  BEGIN
    DROP INDEX Scores_IDX01 ON dbo.Scores;
  END;

IF (SELECT COUNT(*) FROM sys.indexes WHERE name = 'Scores_IDX02') > 0
  BEGIN
    DROP INDEX Scores_IDX02 ON dbo.Scores;
  END;
