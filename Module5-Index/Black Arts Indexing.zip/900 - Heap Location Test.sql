-------------------------------------------------------------------------------
--Demonstrate the case where deleting from a heap and then inserting new rows
--can use the empty space instead of always adding it onto the end. In this
--demo, some of the new rows are added as new space and some in free space.

--The absolute number of rows that will be inserted on a new page depends on
--many different things. The point is that some will likely move.

--This script is meant to be run all at once.
-------------------------------------------------------------------------------

USE Indexing;
go

--Create a heap table
IF OBJECT_ID('dbo.HeapTest', 'u') IS NOT NULL DROP TABLE dbo.HeapTest;
CREATE TABLE dbo.HeapTest (
  ID Integer not null IDENTITY (1, 1),
  Name Varchar(32) not null,
  Score Integer not null,
  EntryDate datetime not null);

--Populate 1K rows
DECLARE @StartValue Datetime,
        @EndValue   Datetime,
        @Range      Integer;

SELECT @StartValue = '1990',
       @EndValue   = '2015',
       @Range      = DATEDIFF(day, @StartValue, @EndValue);

INSERT INTO dbo.HeapTest WITH (TABLOCK) (Name, Score, EntryDate)
  SELECT Name = SUBSTRING(CAST(NEWID() AS Varchar(36)), ABS(CHECKSUM(NEWID())) % 10, ABS(CHECKSUM(NEWID())) % 32 + 1),
    Score = ABS(CHECKSUM(NEWID())) % 10 + 1,
    EntryDate = RAND(CHECKSUM(NEWID())) * @Range + @StartValue
  FROM dbo.TallyN(1000) t
  OPTION (RECOMPILE);

--Create a table to hold the ID and location data for each row
IF OBJECT_ID('tempdb.dbo.#test_locations', 'u') IS NOT NULL DROP TABLE #test_locations;
CREATE TABLE #test_locations (
  source_set_id Integer,
  id Integer,
  file_id Integer,
  page_id Integer,
  slot_id Integer);

--Populate the IDs and locations into the temp table
INSERT INTO #test_locations(source_set_id, id, file_id, page_id, slot_id)
  SELECT 1, ht.ID, plc.file_id, page_id, slot_id 
    FROM dbo.HeapTest ht
      CROSS APPLY sys.fn_PhysLocCracker(%%physloc%%) plc
    ORDER BY ht.ID;

--Delete 100 rows from the heap (10% of the rows)
DELETE FROM dbo.HeapTest
  WHERE ID < 101;

--Add the same number of rows to the heap
INSERT INTO dbo.HeapTest WITH (TABLOCK) (Name, Score, EntryDate)
  SELECT Name = SUBSTRING(CAST(NEWID() AS Varchar(36)), ABS(CHECKSUM(NEWID())) % 10, ABS(CHECKSUM(NEWID())) % 32 + 1),
    Score = ABS(CHECKSUM(NEWID())) % 10 + 1,
    EntryDate = RAND(CHECKSUM(NEWID())) * @Range + @StartValue
  FROM dbo.TallyN(100) t
  OPTION (RECOMPILE);

--Populate the IDs and locations into the temp table
INSERT INTO #test_locations(source_set_id, id, file_id, page_id, slot_id)
  SELECT 2, ht.ID, plc.file_id, page_id, slot_id 
    FROM dbo.HeapTest ht
      CROSS APPLY sys.fn_PhysLocCracker(%%physloc%%) plc
    ORDER BY ht.ID;

--Compare the rows that are different in the 2 sets.
WITH cteNewRows AS (
  SELECT id, file_id, page_id, slot_id
    FROM #test_locations 
    WHERE source_set_id = 2
  EXCEPT
  SELECT id, file_id, page_id, slot_id 
    FROM #test_locations 
    WHERE source_set_id = 1
),
cteReplacedRows AS (
  SELECT id, file_id, page_id, slot_id 
    FROM #test_locations 
    WHERE source_set_id = 1
  EXCEPT 
  SELECT id, file_id, page_id, slot_id 
    FROM #test_locations 
    WHERE source_set_id = 2
)
SELECT OldID = rr.id, NewID = nr.id, OldPage = rr.page_id, NewPage = nr.page_id,
    RowMoved = CASE WHEN rr.page_id = nr.page_id THEN 'Same Location' 
                                                 ELSE 'Row Moved'
               END
  FROM cteNewRows nr
    INNER JOIN cteReplacedRows rr on rr.id + 1000 = nr.ID 
  ORDER BY rr.id;
