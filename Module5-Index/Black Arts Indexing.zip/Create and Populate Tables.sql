USE Indexing;
go

--Take note of the size of the log file in MB before we start
SELECT LogSize = size / 128.0 
  FROM sys.sysfiles
  WHERE fileid = 2;

-------------------------------------------------------------------------------
--Create a wide table to hold a score and comments.
-------------------------------------------------------------------------------
IF OBJECT_ID('dbo.Scores', 'u') IS NOT NULL DROP TABLE dbo.Scores;
go

CREATE TABLE dbo.Scores (
  ID Integer not null identity (1, 1),
  constraint Scores_PK PRIMARY KEY (ID),
  Score Integer,
  Comments Varchar(7000),
  EntryDate Datetime not null default GETDATE());

--Populate the table with 100K rows of test data. The Comments column in the CTE 
--is 100 characters long and is then replicated 70 times to fill up the 
--Comments column in the table. The intent is to populate the wide rows.
WITH cteData AS (
  SELECT Score = ABS(CHECKSUM(NEWID())) % 10 + 1,
      Comments = CAST(NEWID() AS VARCHAR(36)) + 
                 CAST(NEWID() AS VARCHAR(36)) + 
                 SUBSTRING(CAST(NEWID() AS Varchar(36)), 1, 28),
      N = t.N
    FROM dbo.TallyN(100000) t
)
INSERT INTO dbo.Scores WITH (TABLOCK) (Score, Comments, EntryDate)
  SELECT Score = d.Score,
      Comments = REPLICATE(d.Comments, 70),
      DATEADD(day, d.N, '01/01/1900')
    FROM cteData d
    OPTION (RECOMPILE);

-------------------------------------------------------------------------------
--Create tables to demonstrate the impact of implicit casts on indexes
-------------------------------------------------------------------------------
--Create an employees table with ANSI names
IF OBJECT_ID('dbo.EmployeesVC', 'u') IS NOT NULL DROP TABLE dbo.EmployeesVC;
CREATE TABLE dbo.EmployeesVC (
  ID Integer not null identity (1, 1),
  constraint EmployeesVC_PK PRIMARY KEY (ID),
  FirstName Varchar(32) not null,
  LastName Varchar(32) not null,
  HireDate Datetime not null);

--Populate using Jeff's approach to test data
DECLARE @NumberOfRows Integer,
        @StartValue   Datetime,
        @EndValue     Datetime,
        @Range        Integer;

--Define our parameters to generate 1m rows with dates between 1990 and 2015
 SELECT @NumberOfRows = 1000000,
        @StartValue   = '1990',
        @EndValue     = '2015',
        @Range        = DATEDIFF(day, @StartValue, @EndValue);

INSERT INTO dbo.EmployeesVC WITH (TABLOCK) (FirstName, LastName, HireDate) 
  SELECT TOP (@NumberOfRows)
        SomeRandomName = SUBSTRING(CAST(NEWID() AS Varchar(36)), ABS(CHECKSUM(NEWID())) % 10, ABS(CHECKSUM(NEWID())) % 19 + 2),
        SomeRandomName = SUBSTRING(CAST(NEWID() AS Varchar(36)), ABS(CHECKSUM(NEWID())) % 10, ABS(CHECKSUM(NEWID())) % 19 + 2),
        SomeRandomDateTime = RAND(CHECKSUM(NEWID())) * @Range + @StartValue
    FROM dbo.TallyN(@NumberOfRows)
    OPTION (RECOMPILE);

--Update a few last names to be the same, but make sure they're in separate parts of the table
UPDATE dbo.EmployeesVC WITH (TABLOCK)
  SET LastName = x.LastName 
  FROM (VALUES(100, 'Smith'),
              (101, 'Jones'),
              (102, 'Johnson'),
              (103, 'Moden'),
              (104, 'Wagner'),
              (105, 'Bain'),
              (106, 'Martinez'),
              (107, 'White'),
              (108, 'Anderson'),
              (109, 'Thomas'),
              (110, 'Washington'),
              (111, 'Brown'),
              (112, 'Malven'),
              (113, 'Roy'),
              (114, 'Cross'),
              (115, 'Van Dyke'),
              (116, 'Irvine'),
              (117, 'Batali'),
              (118, 'Gates'),
              (119, 'Ellison')
       ) x (ModValue, LastName)
  WHERE ID % 1000 = x.ModValue
  OPTION (RECOMPILE);

UPDATE dbo.EmployeesVC WITH (TABLOCK)
  SET FirstName = x.FirstName
  FROM (VALUES(120, 'Jeff'),
              (121, 'Ed'),
              (122, 'Kathy'),
              (123, 'Victoria'),
              (124, 'Tim'),
              (125, 'Bill'),
              (126, 'Bob'),
              (127, 'Sue'),
              (128, 'Mary'),
              (129, 'Thomas'),
              (130, 'Margaret'),
              (131, 'Diane'),
              (132, 'Mark'),
              (133, 'Marcia'),
              (134, 'Alton'),
              (135, 'Lori'),
              (136, 'Emily'),
              (137, 'Ruth'),
              (138, 'Rachel'),
              (139, 'Alma')
       ) x (ModValue, FirstName)
  WHERE ID % 1000 = x.ModValue
  OPTION (RECOMPILE);

--Make sure we have a bunch of duplicate names
SELECT LastName, COUNT(*)
  FROM dbo.Employeesvc 
  GROUP BY LastName
  HAVING COUNT(LastName) > 10
  ORDER BY COUNT(*) DESC, LastName;

--Create an employees table with Unicode names
IF OBJECT_ID('dbo.EmployeesNVC', 'u') IS NOT NULL DROP TABLE dbo.EmployeesNVC;
CREATE TABLE dbo.EmployeesNVC (
  ID Integer not null identity (1, 1),
  constraint EmployeesNVC_PK PRIMARY KEY (ID),
  FirstName Nvarchar(32) not null,
  LastName Nvarchar(32) not null,
  HireDate Datetime not null);

--Copy the rows from dbo.EmployeesVC to dbo.EmployeesNVC
INSERT INTO dbo.EmployeesNVC WITH (TABLOCK) (FirstName, LastName, HireDate) 
  SELECT CONVERT(Nvarchar(32), FirstName), 
      CONVERT(Nvarchar(32), LastName),
      HireDate
    FROM dbo.EmployeesVC
    ORDER BY ID
    OPTION (RECOMPILE);
 
--Create another employees table with ANSI names
IF OBJECT_ID('dbo.EmployeesVC2', 'u') IS NOT NULL DROP TABLE dbo.EmployeesVC2;
CREATE TABLE dbo.EmployeesVC2 (
  ID Integer not null identity (1, 1),
  constraint EmployeesVC2_PK PRIMARY KEY (ID),
  FirstName Varchar(32) not null,
  LastName Varchar(32) not null,
  HireDate Datetime not null);

INSERT INTO dbo.EmployeesVC2 WITH (TABLOCK) (FirstName, LastName, HireDate)
  SELECT FirstName, LastName, HireDate
    FROM dbo.EmployeesVC
    ORDER BY ID
    OPTION (RECOMPILE);

--We've created 3 tables with 1M rows and 1 with 100K rows. Check the log size
SELECT LogSize = size / 128.0 
  FROM sys.sysfiles
  WHERE fileid = 2;
