-------------------------------------------------------------------------------
--Demonstrate the impact of implicit casts on strings in join predicates.
-------------------------------------------------------------------------------

USE Indexing;
go

--Make sure the indexes don't already exist.
IF (SELECT COUNT(*) FROM sys.indexes WHERE name = 'EmployeesVC_IDX01') > 0
  BEGIN
    DROP INDEX EmployeesVC_IDX01 ON dbo.EmployeesVC;
  END;

IF (SELECT COUNT(*) FROM sys.indexes WHERE name = 'EmployeesVC2_IDX01') > 0
  BEGIN
    DROP INDEX EmployeesVC2_IDX01 ON dbo.EmployeesVC2;
  END;

IF (SELECT COUNT(*) FROM sys.indexes WHERE name = 'EmployeesNVC_IDX01') > 0
  BEGIN
    DROP INDEX EmployeesNVC_IDX01 ON dbo.EmployeesNVC;
  END;

--Set the statistics on so we can see the number of reads for each query.
SET STATISTICS IO ON;

-------------------------------------------------------------------------------
--Query the joined tables to return rows from both tables based on last name.
--Only a count is being returned because the data isn't the point of interest.
--The point is the data types of the columns used in the join predicate.
-------------------------------------------------------------------------------

--Query a count with matching data types in the joined columns.
--The reads are 6,140 and 6,070.
--Both tables where scanned because there's no index the query can use.
SELECT COUNT(*)
  FROM dbo.EmployeesVC e1
    INNER JOIN dbo.EmployeesVC2 e2 ON e2.LastName = e1.LastName;

--Query a count with mismatched data types in the joined columns.
--The reads are 6,140 and 8,777, but the worktable has 29,472 reads.
--Both tables where scanned because there's no index the query can use.
--The query spilled to TempDB - note the little warning symbol on the hash 
--match operator. Also see the warning on the SELECT operator - the implicit
--cast is shown in the tooltip.
SELECT COUNT(*)
  FROM dbo.EmployeesVC e1
    INNER JOIN dbo.EmployeesNVC e2 ON e2.LastName = e1.LastName;

-------------------------------------------------------------------------------
--Create an NCI on the last name column on the base table.
-------------------------------------------------------------------------------
CREATE NONCLUSTERED INDEX EmployeesVC_IDX01 ON dbo.EmployeesVC(LastName ASC);

-------------------------------------------------------------------------------
--Query the joined tables to return rows from both tables based on last name.
--The queries are identical the previous ones, but there's an NCI in place now.
-------------------------------------------------------------------------------

--Query a count with matching data types in the joined columns.
--The reads are 3,126 and 6,070.
--The reads are lower on dbo.EmployeesVC because the query scanned the NCI
--instead of the CI, which is the whole table.
SELECT COUNT(*)
  FROM dbo.EmployeesVC e1
    INNER JOIN dbo.EmployeesVC2 e2 ON e2.LastName = e1.LastName;

--Query a count with mismatched data types in the joined columns.
--The reads are 3,130 and 8,777, but a worktable has 29,312 reads.
--The query spilled to TempDB - note the little warning symol on the hash 
--match operator. Also see the warning on the SELECT operator - the implicit
--cast is shown in the tooltip.
SELECT COUNT(*)
  FROM dbo.EmployeesVC e1
    INNER JOIN dbo.EmployeesNVC e2 ON e2.LastName = e1.LastName;

-------------------------------------------------------------------------------
--Create NCIs on the last name columns to cover both queries.
-------------------------------------------------------------------------------
CREATE NONCLUSTERED INDEX EmployeesVC2_IDX01 ON dbo.EmployeesVC2(LastName ASC);
CREATE NONCLUSTERED INDEX EmployeesNVC_IDX01 ON dbo.EmployeesNVC(LastName ASC);

-------------------------------------------------------------------------------
--Query the joined tables to return rows from both tables based on last name.
--The queries are identical the previous ones, but there are 2 NCIs in place 
--now, one on each of the joined tables.
-------------------------------------------------------------------------------

--Query a count with matching data types in the joined columns.
--The reads are 3,126 and 3,130.
--The optimizer scanned both NCIs - one on each table.
SELECT COUNT(*)
  FROM dbo.EmployeesVC e1
    INNER JOIN dbo.EmployeesVC2 e2 ON e2.LastName = e1.LastName;

--Query the joined tables with mismatched data types in the joined columns.
--The reads are 3,130 and 2,748,664 and the workfile has 13,840 reads.
--The query scanned the NCI on dbo.Employees and an index seek on 
--dbo.EmployeesNVC. The seek was picked by the optimizer because it tried to
--make execution better by using a seek, but it had to do lots of them.

--> One scan is better than 859,628 seeks. <--

--The query spilled to TempDB - note the little warning symol on the hash 
--match operator. Also see the warning on the SELECT operator - the implicit
--cast is shown in the tooltip.
SELECT COUNT(*)
  FROM dbo.EmployeesVC e1
    INNER JOIN dbo.EmployeesNVC e2 ON e2.LastName = e1.LastName;
      
-------------------------------------------------------------------------------
--Clean up
-------------------------------------------------------------------------------
SET STATISTICS IO OFF;

IF (SELECT COUNT(*) FROM sys.indexes WHERE name = 'EmployeesVC_IDX01') > 0
  BEGIN
    DROP INDEX EmployeesVC_IDX01 ON dbo.EmployeesVC;
  END;

IF (SELECT COUNT(*) FROM sys.indexes WHERE name = 'EmployeesVC2_IDX01') > 0
  BEGIN
    DROP INDEX EmployeesVC2_IDX01 ON dbo.EmployeesVC2;
  END;

IF (SELECT COUNT(*) FROM sys.indexes WHERE name = 'EmployeesNVC_IDX01') > 0
  BEGIN
    DROP INDEX EmployeesNVC_IDX01 ON dbo.EmployeesNVC;
  END;
 