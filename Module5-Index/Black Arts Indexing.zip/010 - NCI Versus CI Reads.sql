-------------------------------------------------------------------------------
--Demonstrate the reduction in reads when using a narrow NCI instead of a 
--a wide table.
-------------------------------------------------------------------------------

USE Indexing;
go

--Make sure the index doesn't already exist
IF (SELECT COUNT(*) FROM sys.indexes WHERE name = 'Scores_IDX01') > 0
  BEGIN
    DROP INDEX Scores_IDX01 ON dbo.Scores;
  END;

--See that the table can store one row per page.
EXECUTE dbo.CalculatePageSpace 'dbo.Scores';

--Set the statistics on so we can see the number of reads for each query
SET STATISTICS IO ON;

-------------------------------------------------------------------------------
--Query the the number of rows and average score.
-------------------------------------------------------------------------------

--Query the number of rows in the table
--The CI was scanned and it consumed 112,824 reads.
SELECT COUNT(*)
  FROM dbo.Scores;

--Calculate the average score over all 100k rows.
--The CI was scanned and it consumed 112,824 reads.
SELECT AVG(CONVERT(Numeric(6, 4), Score))
  FROM dbo.Scores;

--Create a nonclustered index to cover the queries
CREATE NONCLUSTERED INDEX Scores_IDX01 ON dbo.Scores(Score);

-------------------------------------------------------------------------------
--Query the the number of rows and average score.
--The only difference is that the NCI is now in place.
-------------------------------------------------------------------------------

--Query the number of rows in the table and see the same result.
--The NCI was scanned and it consumed 176 reads.
SELECT COUNT(*)
  FROM dbo.Scores;

--Calculate the average score over all 100k rows and see the same query result.
--The NCI was scanned and it consumed 176 reads.
SELECT AVG(CONVERT(Numeric(6, 4), Score))
  FROM dbo.Scores;

--The NCI was scanned because all rows had to be read for both the count and
--average. The optimizer picked the NCI because it knew it would results in
--fewer reads - a 99.8% reduction.

-------------------------------------------------------------------------------
--Clean up
-------------------------------------------------------------------------------
IF (SELECT COUNT(*) FROM sys.indexes WHERE name = 'Scores_IDX01') > 0
  BEGIN
    DROP INDEX Scores_IDX01 ON dbo.Scores;
  END;
