-------------------------------------------------------------------------------
--Demonstrate the physical location of rows.
-------------------------------------------------------------------------------

USE Indexing;
go

--Query the physical locations of the first 1,000 rows in the products table
SELECT TOP 1000 ID, NativeLoc = %%physloc%%, 
    FormattedLoc = sys.fn_PhysLocFormatter(%%physloc%%),
    plc.file_id, plc.page_id, plc.slot_id
  FROM dbo.Scores
    CROSS APPLY sys.fn_PhysLocCracker(%%physloc%%) plc
  ORDER BY ID;

-------------------------------------------------------------------------------
--BONUS CONTENT
-------------------------------------------------------------------------------
/*
The sys.fn_PhysLocCracker is an MTVF, which performs well over 10 rows, but
any piece of junk can run decently over 10 rows. I think we can do better than
Microsoft's MTVF and return the same results.

First, here's the function that's a part of SQL Server:

ALTER function sys.fn_PhysLocCracker(@physical_locator binary (8))
returns @dumploc_table table
(
	[file_id]	int not null,
	[page_id]	int not null,
	[slot_id]	int not null
)
as
begin

	declare @page_id	binary (4)
	declare @file_id	binary (2)
	declare @slot_id	binary (2)

	-- Page ID is the first four bytes, then 2 bytes of page ID, then 2 bytes of slot
	--
	select @page_id = convert (binary (4), reverse (substring (@physical_locator, 1, 4)))
	select @file_id = convert (binary (2), reverse (substring (@physical_locator, 5, 2)))
	select @slot_id = convert (binary (2), reverse (substring (@physical_locator, 7, 2)))
	
	insert into @dumploc_table values (@file_id, @page_id, @slot_id)
	return
end
*/

/*
Observations:
1. The function is an MTVF, which is usually slow. Granted, this function isn't
   a normal, everyday function used in production, but if something is going 
   to be queried, it should be done efficiently.
2. The INSERT statements relies on an implicit case from a binary to an integer
   when creating the rows in the return table.
3. The function is not schema-bound. Using WITH SCHEMABINDING on functions is
   encouraged because SQL Server knows that it doesn't have to check any 
   underlying tables. There aren't any in the function, so it's a free way to
   have SQL Server skip a check. The less overhead work SQL Server has to do,
   the faster the functions are allowed to run. It isn't much, but every little
   bit helps. It's been observed that this also helps to avoid unnecessary
   spool operators in the query plan.
*/

--Create an ITVF version of the function to return the physical location.
--Keep both the parameter and output columns identical.
IF OBJECT_ID('dbo.PhysLocCrackerITVF', 'if') IS NOT NULL DROP FUNCTION dbo.PhysLocCrackerITVF;
go

CREATE FUNCTION dbo.PhysLocCrackerITVF(@physical_locator Binary(8)) 
  RETURNS TABLE WITH SCHEMABINDING
AS

  RETURN (
    SELECT page_id = CONVERT(Integer, CONVERT(Binary(4), REVERSE(SUBSTRING(@physical_locator, 1, 4)))),
           file_id = CONVERT(Integer, CONVERT(Binary(2), REVERSE(SUBSTRING(@physical_locator, 5, 2)))),
           slot_id = CONVERT(Integer, CONVERT(Binary(2), REVERSE(SUBSTRING(@physical_locator, 7, 2))))
  );
go

-------------------------------------------------------------------------------
--Race the MTVF and ITVF against one another.
-------------------------------------------------------------------------------
DECLARE @times TABLE (
  Name Varchar(32) not null,
  d Datetime not null);

--Contestant A: The built-in Microsoft MTVF
INSERT INTO @times(name, d) VALUES('MTVF', GETDATE());

SELECT TOP 10000 ID, NativeLoc = %%physloc%%, 
    plc.file_id, plc.page_id, plc.slot_id
  FROM dbo.Scores
    CROSS APPLY sys.fn_PhysLocCracker(%%physloc%%) plc
  ORDER BY ID
  OPTION (RECOMPILE);

INSERT INTO @times(name, d) VALUES('MTVF', GETDATE());

--Contestant B: The ITVF to do the same work
INSERT INTO @times(name, d) VALUES('ITVF', GETDATE());

SELECT TOP 10000 ID, NativeLoc = %%physloc%%, 
    plc.file_id, plc.page_id, plc.slot_id 
  FROM dbo.Scores
    CROSS APPLY dbo.PhysLocCrackerITVF(%%physloc%%) plc
  ORDER BY ID
  OPTION (RECOMPILE);

INSERT INTO @times(name, d) VALUES('ITVF', GETDATE());

--Query the performance of each approach.
SELECT Name, Diff = DATEDIFF(ms, MIN(d), MAX(d))
  FROM @times
  GROUP BY name;

/* Timing (on my machine) shows the performance difference of the MTVF being
executed in a loop versus the ITVF being inlined and executes once. This can
be seen by looking at the Table Valued Function operator in the query plan
and looking at the Number of Executions.

Rows        MTVF  ITVF  ITVF % of MTVF
1,000        226  116   51.3%
10,000       686  166   24.2%
100,000     5676  690   12.1%
1,000,000  55010  5810  10.5%
*/
