-------------------------------------------------------------------------------
--Demonstrate the impact of having covering indexes.
-------------------------------------------------------------------------------

USE Indexing;
go

--Make sure the indexes don't already exist
IF (SELECT COUNT(*) FROM sys.indexes WHERE name = 'Scores_IDX01') > 0
  BEGIN
    DROP INDEX Scores_IDX01 ON dbo.Scores;
  END;

IF (SELECT COUNT(*) FROM sys.indexes WHERE name = 'Scores_IDX02') > 0
  BEGIN
    DROP INDEX Scores_IDX02 ON dbo.Scores;
  END;

--Set the statistics on so we can see the number of reads for each query
SET STATISTICS IO ON;

-------------------------------------------------------------------------------
--Query the comments entered between 1/1/1990 and 12/31/2000.
-------------------------------------------------------------------------------
--Run the query.
--An index scan against the CI was used and took 100,163 reads.
--The reads are so high because all the rows had to be read.
SELECT Comments 
  FROM dbo.Scores
  WHERE EntryDate >= '01/01/1990'
    AND EntryDate <  '01/01/2000';

--Create an NCI to to handle the filter.
CREATE NONCLUSTERED INDEX Scores_IDX01 ON dbo.Scores(EntryDate);

--Run the query again.
--An index seek was used against the new NCI, but a key lookup was used against
--the CI because the NCI didn't contain the Comments column.
--For every row in the NCI, a row had to be retrieved from the CI, which drove 
--the reads up to 11,204.

--The optimizer determined that, given the number of rows to be read, it was 
--cheaper to do a key lookup than it would be to read the entire CI.
SELECT Comments 
  FROM dbo.Scores
  WHERE EntryDate >= '01/01/1990'
    AND EntryDate <  '01/01/2000';

--SQL Server knows it can execute this query using the plan it decided on with
--the key lookup, but I think we can do better. I'm going to leave the existing
--index in place, but create another one to cover the query.
CREATE NONCLUSTERED INDEX Scores_IDX02 ON dbo.Scores(EntryDate) INCLUDE(Comments);

--Run the same query a third time and see the same results.
--This time, an index seek was used against the new NCI and took 3,680 reads.
SELECT Comments 
  FROM dbo.Scores
  WHERE EntryDate >= '01/01/1990'
    AND EntryDate <  '01/01/2000';

--SQL Server created a new index, so it invalidated the previous plan.
--When it determined how to best fulfill the query, it picked the best one,
--which is the one created to cover the query.

-------------------------------------------------------------------------------
--Clean up
-------------------------------------------------------------------------------
IF (SELECT COUNT(*) FROM sys.indexes WHERE name = 'Scores_IDX01') > 0
  BEGIN
    DROP INDEX Scores_IDX01 ON dbo.Scores;
  END;

IF (SELECT COUNT(*) FROM sys.indexes WHERE name = 'Scores_IDX02') > 0
  BEGIN
    DROP INDEX Scores_IDX02 ON dbo.Scores;
  END;
