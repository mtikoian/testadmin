USE AdventureWorks2014
GO

IF EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_SalesOrderHeader_CustomerID2')
    DROP INDEX [IX_SalesOrderHeader_CustomerID2] ON Sales.SalesOrderHeader
GO

DBCC FREEPROCCACHE
DBCC DROPCLEANBUFFERS
GO

--Show key lookup
EXEC sp_executeSQL N'SELECT SalesOrderID, SalesOrderNumber, OrderDate, DueDate, ShipDate
INTO #a
FROM Sales.SalesOrderHeader
WHERE CustomerID = 11238'
GO 50

--Leverage sys.dm_db_index_usage_stats to find imbalances
SELECT  ius.database_id
    ,ius.object_id
    ,ius.index_id
    ,i.name
    ,ius.user_seeks
    ,ius.user_scans
    ,ius.user_lookups
    ,ius.user_updates
FROM sys.dm_db_index_usage_stats ius
    INNER JOIN sys.indexes i ON ius.object_id = i.object_id AND ius.index_id = i.index_id
WHERE ius.database_id = DB_ID()
AND ius.object_id = OBJECT_ID('Sales.SalesOrderHeader')
GO

--Query plan cache to find index usage
WITH XMLNAMESPACES(DEFAULT N'http://schemas.microsoft.com/sqlserver/2004/07/showplan')
SELECT 
    o.value('(IndexScan/Object/@Schema)[1]', 'sysname') AS SchemaName
    ,o.value('(IndexScan/Object/@Table)[1]', 'sysname') AS TableName
    ,o.value('(IndexScan/Object/@Index)[1]', 'sysname') AS IndexName
    ,REPLACE(o.query(' 
	    for $column in IndexScan/DefinedValues/DefinedValue/ColumnReference 
	    return string($column/@Column) 
	    ').value('.', 'varchar(max)'), ' ', ', ') AS KeyLookupColumns
    ,o.value(N'@PhysicalOp', N'varchar(50)') AS physical_operator
    ,o.value(N'@LogicalOp', N'varchar(50)') AS Logical_operator
    ,plan_handle
    ,qp.query_plan
FROM sys.dm_exec_cached_plans cp
    CROSS APPLY sys.dm_exec_query_plan(cp.plan_handle) qp
    CROSS APPLY sys.dm_exec_plan_attributes(cp.plan_handle) pa
    CROSS APPLY qp.query_plan.nodes('//StmtSimple') s(stmt)
    CROSS APPLY qp.query_plan.nodes(N'//RelOp') r(o)
WHERE query_plan.exist('.//RelOp/IndexScan[@Lookup="1"]')=1
AND o.exist('./IndexScan[@Lookup="1"]')=1
AND pa.attribute = 'dbid'
AND pa.value = DB_ID()

EXEC sp_indexanalysis @tablename = 'Sales.SalesOrderHeader' 
GO
