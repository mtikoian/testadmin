USE AdventureWorks2014
GO

SELECT OBJECT_SCHEMA_NAME(i.object_id) + '.' + OBJECT_NAME(i.object_id)
    --, database_id
    --, object_id
    , dius.index_id
    , i.name
    , dius.user_seeks
    , dius.user_scans
    , dius.user_lookups
    , dius.user_updates
    , dius.last_user_seek
    , dius.last_user_scan
    , dius.last_user_lookup
    , dius.last_user_update
    , dius.system_seeks
    , dius.system_scans
    , dius.system_lookups
    , dius.system_updates
    , dius.last_system_seek
    , dius.last_system_scan
    , dius.last_system_lookup
    , dius.last_system_update
FROM sys.dm_db_index_usage_stats dius
    INNER JOIN sys.indexes i ON dius.object_id = i.object_id AND dius.index_id = i.index_id
WHERE database_id = DB_ID()
AND i.object_id = OBJECT_ID('Person.Person')

UPDATE Person.Person
SET ModifiedDate = GETDATE()
GO 6 -- Remember the row count 19972

--Indexes that haven't been used?
SELECT OBJECT_SCHEMA_NAME(i.object_id) + '.' + OBJECT_NAME(i.object_id)
    , i.index_id
    , i.name
    , dius.user_seeks
    , dius.user_scans
    , dius.user_lookups
    , dius.user_updates
FROM sys.indexes i 
    LEFT OUTER JOIN sys.dm_db_index_usage_stats dius ON dius.object_id = i.object_id AND dius.index_id = i.index_id AND dius.database_id = DB_ID()
WHERE i.object_id = OBJECT_ID('Person.Person')

--WARNING!!! sys.dm_db_index_usage_stats is affected by service restarts and index dropped.

--Indexes that haven't been used?
--The wrong way -->
SELECT OBJECT_SCHEMA_NAME(i.object_id) + '.' + OBJECT_NAME(i.object_id) AS table_name
    , i.index_id
    , i.name
    , dius.user_seeks
    , dius.user_scans
    , dius.user_lookups
    , dius.user_updates
FROM sys.indexes i 
    INNER JOIN sys.dm_db_index_usage_stats dius ON dius.object_id = i.object_id AND dius.index_id = i.index_id AND dius.database_id = DB_ID()
WHERE i.object_id = OBJECT_ID('Person.Person')
AND COALESCE(dius.user_seeks,0) + COALESCE(dius.user_scans,0) + COALESCE(dius.user_lookups,0) = 0


--The right way -->
SELECT OBJECT_SCHEMA_NAME(i.object_id) + '.' + OBJECT_NAME(i.object_id) AS table_name
    , i.index_id
    , i.name
    , dius.user_seeks
    , dius.user_scans
    , dius.user_lookups
    , dius.user_updates
FROM sys.indexes i 
    LEFT OUTER JOIN sys.dm_db_index_usage_stats dius ON dius.object_id = i.object_id AND dius.index_id = i.index_id AND dius.database_id = DB_ID()
WHERE i.object_id = OBJECT_ID('Person.Person')
AND (dius.object_id IS NULL
OR COALESCE(dius.user_seeks,0) + COALESCE(dius.user_scans,0) + COALESCE(dius.user_lookups,0) = 0)


--How have indexes been used?
;WITH UseageCTE
AS (
    SELECT OBJECT_SCHEMA_NAME(i.object_id) + '.' + OBJECT_NAME(i.object_id) as table_name
        , i.index_id
        , i.name as index_name
        , i.type_desc
        , COALESCE(dius.user_seeks,0) AS user_seeks
        , COALESCE(dius.user_scans,0) AS user_scans
        , COALESCE(dius.user_lookups,0) AS user_lookups
        , COALESCE(dius.user_seeks,0) + COALESCE(dius.user_scans,0) + COALESCE(dius.user_lookups,0) AS user_total
        , COALESCE(dius.user_updates,0) AS user_updates
    FROM sys.indexes i 
        LEFT OUTER JOIN sys.dm_db_index_usage_stats dius ON dius.object_id = i.object_id AND dius.index_id = i.index_id AND dius.database_id = DB_ID()
    WHERE i.object_id = OBJECT_ID('Person.Person')
    )
SELECT table_name
    , index_name
    , type_desc
    , user_seeks
    , user_scans
    , user_lookups
    , user_total 
    , CAST(100.*user_total/SUM(user_total) OVER() as decimal(12,2)) as user_percent
    , user_updates
    , CAST((100.*user_updates/NULLIF(user_total,0)) as decimal(12,2)) AS update_ratio
FROM UseageCTE
ORDER BY 8 DESC
