SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
GO

IF OBJECT_ID('tempdb..#plans') IS NOT NULL
	DROP TABLE #plans
GO

CREATE TABLE #plans
	(
	[plan_handle] [varbinary](64) NULL
	,[parent_operation_id] [int] NULL
	,[operation_id] [int] NULL
	,[physical_operator] [varchar](50) NULL 
	,[Logical_operator] [varchar](50) NULL
	,[key_lookup] bit
	,[index] [sysname] NULL
	,[columns] [varchar](max) NULL
	,[query_plan] [xml] NULL
	)
GO

WITH XMLNAMESPACES(DEFAULT N'http://schemas.microsoft.com/sqlserver/2004/07/showplan')
INSERT INTO #plans
SELECT 
	cp.plan_handle
	,o.value(N'../../@NodeId', N'int') AS parent_operation_id
	,o.value(N'@NodeId', N'int') AS operation_id
	,o.value(N'@PhysicalOp', N'varchar(50)') AS physical_operator
	,o.value(N'@LogicalOp', N'varchar(50)') AS Logical_operator
	,o.value('(IndexScan/@Lookup)[1]', 'bit') AS [index]
	,o.value('(IndexScan/Object/@Index)[1]', 'sysname') AS [index]
	,REPLACE(o.query(' 
		for $column in IndexScan/DefinedValues/DefinedValue/ColumnReference 
		return string($column/@Column) 
		').value('.', 'varchar(max)'), ' ', ', ') AS [columns]
	,qp.query_plan
FROM sys.dm_exec_cached_plans cp
	CROSS APPLY sys.dm_exec_query_plan(cp.plan_handle) qp
	CROSS APPLY qp.query_plan.nodes(N'//RelOp') r(o)
WHERE cp.cacheobjtype = N'Compiled Plan'
AND query_plan.exist('//RelOp/IndexScan[@Lookup="1"]')=1
AND cp.plan_handle = 0x0600080083C1542D7048B9F80300000001000000000000000000000000000000000000000000000000000000
ORDER BY cp.plan_handle, o.value(N'@NodeId', N'int')

;WITH UpPlan
AS (
	SELECT plan_handle, parent_operation_id, operation_id
	FROM #plans
	WHERE key_lookup = 1
	UNION ALL
	SELECT p.plan_handle, p.parent_operation_id, p.operation_id
	FROM #plans p
		INNER JOIN UpPlan u ON p.plan_handle = u.plan_handle AND p.operation_id=u.parent_operation_id
	WHERE p.physical_operator <> 'Nested Loops'
	)
,DownPlan 
AS (
	SELECT p.plan_handle, p.parent_operation_id, p.operation_id, p.[index]
	FROM UpPlan u
		INNER JOIN #plans p ON u.parent_operation_id = p.parent_operation_id
	WHERE u.operation_id <>  p.operation_id
	UNION ALL
	SELECT p.plan_handle, p.parent_operation_id, p.operation_id, p.[index]
	FROM #plans p
		INNER JOIN DownPlan d ON p.plan_handle = d.plan_handle AND p.parent_operation_id=d.operation_id
	WHERE p.[index] IS NOT NULL
)
SELECT p.plan_handle, d.[index] AS ReferenceIndex, p.[index] as LookUpIndex, p.columns AS LookUpColumns, p.query_plan
FROM DownPlan d
	INNER JOIN UpPlan u ON d.plan_handle = u.plan_handle
	INNER JOIN #plans p ON u.plan_handle = p.plan_handle AND u.operation_id = p.operation_id
WHERE d.[index] IS NOT NULL


