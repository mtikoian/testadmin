USE AdventureWorks2014
GO

IF EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_SalesSalesOrderHeader_DueDate')
    DROP INDEX IX_SalesSalesOrderHeader_DueDate ON Sales.SalesOrderHeader
GO

SELECT DueDate FROM Sales.SalesOrderHeader
WHERE DueDate = '2005-07-13 00:00:00.000'
GO

SELECT DueDate FROM Sales.SalesOrderHeader
WHERE DueDate Between '20050701' AND '20050731'
GO

SELECT DueDate, OrderDate FROM Sales.SalesOrderHeader
WHERE DueDate Between '20050701' AND '20050731'
GO

SELECT OrderDate FROM Sales.SalesOrderHeader
WHERE DueDate Between '20050701' AND '20050731'
GO

SELECT
  DB_NAME(database_id) AS database_name
  ,OBJECT_NAME(object_id, database_id) AS table_name
  ,mid.equality_columns
  ,mid.inequality_columns
  ,mid.included_columns
  ,(migs.user_seeks + migs.user_scans) * migs.avg_user_impact AS Impact
  ,migs.avg_total_user_cost * (migs.avg_user_impact / 100.0) * (migs.user_seeks + migs.user_scans) AS Score
  ,migs.user_seeks
  ,migs.user_scans
FROM sys.dm_db_missing_index_details mid
    INNER JOIN sys.dm_db_missing_index_groups mig ON mid.index_handle = mig.index_handle
    INNER JOIN sys.dm_db_missing_index_group_stats migs ON mig.index_group_handle = migs.group_handle
ORDER BY migs.avg_total_user_cost * (migs.avg_user_impact / 100.0) * (migs.user_seeks + migs.user_scans) DESC
GO

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
GO

--http://sqlblog.com/blogs/jonathan_kehayias/archive/2009/07/27/digging-into-the-sql-plan-cache-finding-missing-indexes.aspx
WITH XMLNAMESPACES (DEFAULT 'http://schemas.microsoft.com/sqlserver/2004/07/showplan') 
,PlanMissingIndexes
AS (
    SELECT query_plan, cp.usecounts
    FROM sys.dm_exec_cached_plans cp
        OUTER APPLY sys.dm_exec_query_plan(cp.plan_handle) tp     
    WHERE tp.query_plan.exist('//MissingIndex')=1
)
SELECT 
    stmt.value('(//MissingIndex/@Database)[1]', 'sysname') AS database_name
    ,stmt.value('(//MissingIndex/@Schema)[1]', 'sysname') AS [schema_name]
    ,stmt.value('(//MissingIndex/@Table)[1]', 'sysname') AS [table_name]
    ,stmt.value('(@StatementText)[1]', 'VARCHAR(4000)') AS sql_text
    ,pmi.usecounts
    ,stmt.value('(//MissingIndexGroup/@Impact)[1]', 'FLOAT') AS impact
    ,stmt.query('for $group in //ColumnGroup
        for $column in $group/Column
        where $group/@Usage="EQUALITY"
        return string($column/@Name) 
        ').value('.', 'varchar(max)') AS equality_columns
    ,stmt.query('for $group in //ColumnGroup
        for $column in $group/Column
        where $group/@Usage="INEQUALITY"
        return string($column/@Name) 
        ').value('.', 'varchar(max)') AS inequality_columns
    ,stmt.query('for $group in //ColumnGroup
        for $column in $group/Column
        where $group/@Usage="INCLUDE"
        return string($column/@Name) 
        ').value('.', 'varchar(max)') AS include_columns
    ,pmi.query_plan
FROM PlanMissingIndexes pmi
    CROSS APPLY pmi.query_plan.nodes('//StmtSimple') AS p(stmt);
GO

EXEC dbo.sp_IndexAnalysis @TableName = 'Sales.SalesOrderHeader'

CREATE INDEX IX_SalesSalesOrderHeader_DueDate ON Sales.SalesOrderHeader(DueDate) INCLUDE (OrderDate)
GO

SELECT DueDate FROM Sales.SalesOrderHeader
WHERE DueDate = '2005-07-13 00:00:00.000'
GO

SELECT DueDate FROM Sales.SalesOrderHeader
WHERE DueDate Between '20050701' AND '20050731'
GO

SELECT DueDate, OrderDate FROM Sales.SalesOrderHeader
WHERE DueDate Between '20050701' AND '20050731'
GO

SELECT OrderDate FROM Sales.SalesOrderHeader
WHERE DueDate Between '20050701' AND '20050731'
GO