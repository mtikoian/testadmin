USE AdventureWorks2014
GO

-- Who's heard of table partitioning
-- Indexes can span partitions
SELECT  partition_id
    , object_id
    , index_id
    , partition_number
    , in_row_data_page_count
    , in_row_used_page_count
    , in_row_reserved_page_count
    , lob_used_page_count
    , lob_reserved_page_count
    , row_overflow_used_page_count
    , row_overflow_reserved_page_count
    , used_page_count
    , reserved_page_count
    , row_count
FROM sys.dm_db_partition_stats

--Answer the question - where is all of the space in my database going?  Which indexes?
--All rows - all tables
SELECT OBJECT_SCHEMA_NAME(ps.object_id) + '.' + OBJECT_NAME(ps.object_id) as table_name
    , SUM(row_count) AS [RowCount]
    , CAST(((SUM(ps.in_row_data_page_count)) * CAST(8 as float))/1024. as decimal(12,2)) as data_size_in_mb
    , CAST(((SUM(ps.in_row_used_page_count + ps.lob_used_page_count + ps.row_overflow_used_page_count)) * CAST(8 as float))/1024. as decimal(12,2)) as used_size_in_mb
    , CAST((SUM(ps.reserved_page_count) * CAST(8 as float))/1024. as decimal(12,2)) as total_size_in_mb
FROM sys.dm_db_partition_stats ps
WHERE index_id IN (0,1)
GROUP BY OBJECT_SCHEMA_NAME(ps.object_id) + '.' + OBJECT_NAME(ps.object_id)
ORDER BY 2 DESC

