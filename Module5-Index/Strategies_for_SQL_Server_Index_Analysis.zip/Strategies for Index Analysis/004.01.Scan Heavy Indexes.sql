USE AdventureWorks2014
GO

--Takes about 10 seconds
DBCC FREEPROCCACHE
GO

EXEC sp_executeSQL N'SELECT SalesOrderID, SalesPersonID, AccountNumber
INTO #a
FROM Sales.SalesOrderHeader
WHERE AccountNumber = ''10-4030-023766''';
GO 75

EXEC sp_executeSQL N'SELECT SalesOrderID, SalesPersonID
INTO #a
FROM Sales.SalesOrderHeader';
GO 25

EXEC sp_executeSQL N'SELECT SalesOrderID, CustomerID
INTO #a
FROM Sales.SalesOrderHeader';
GO 50

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
GO

SELECT TOP 5
	OBJECT_NAME(i.object_id)
	,i.name
	,ius.database_id
	,ius.object_id
	,ius.index_id
	,ius.user_seeks
	,ius.user_scans
	,ius.user_lookups
FROM sys.dm_db_index_usage_stats ius
	INNER JOIN sys.indexes i ON ius.object_id = i.object_id AND ius.index_id = i.index_id
WHERE ius.database_id = DB_ID()
AND ius.object_id = OBJECT_ID('Sales.SalesOrderHeader')
ORDER BY user_scans DESC
GO

--DECLARE @IndexName sysname = 'IX_SalesOrderHeader_SalesPersonID';
--DECLARE @IndexName sysname = 'IX_SalesOrderHeader_CustomerID';
--DECLARE @op sysname = 'Index Scan';

DECLARE @IndexName sysname = 'PK_SalesOrderHeader_SalesOrderID';
DECLARE @op sysname = 'Clustered Index Scan';

WITH XMLNAMESPACES(DEFAULT N'http://schemas.microsoft.com/sqlserver/2004/07/showplan')
SELECT 
	cp.plan_handle
	,DB_NAME(dbid) + '.' + OBJECT_SCHEMA_NAME(objectid, dbid) + '.' + OBJECT_NAME(objectid, dbid) AS database_object
    ,qp.query_plan
    ,c1.value('@PhysicalOp','nvarchar(50)') 
    ,c2.value('@Index','nvarchar(max)')    
FROM sys.dm_exec_cached_plans cp 
    CROSS APPLY sys.dm_exec_query_plan(cp.plan_handle) qp
    CROSS APPLY query_plan.nodes('//RelOp') r(c1)
    OUTER APPLY c1.nodes('IndexScan/Object') as o(c2)
WHERE c2.value('@Index','nvarchar(max)') = QUOTENAME(@IndexName,'[')
AND c1.exist('@PhysicalOp[. = sql:variable("@op")]') = 1

