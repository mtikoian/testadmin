USE AdventureWorks2014
GO

IF OBJECT_ID('Person_ChangeIndex') IS NOT NULL
    DROP TABLE Person_ChangeIndex

CREATE TABLE [dbo].[Person_ChangeIndex](
	[BusinessEntityID] [int] NOT NULL,
	[PersonType] [nchar](2) NOT NULL,
	[NameStyle] [dbo].[NameStyle] NOT NULL,
	[Title] [nvarchar](8) NULL,
	[FirstName] [dbo].[Name] NOT NULL,
	[LastName] [dbo].[Name] NOT NULL,
	[Suffix] [nvarchar](10) NULL,
	[EmailPromotion] [int] NOT NULL,
    )

INSERT INTO Person_ChangeIndex
SELECT BusinessEntityID, PersonType, NameStyle, Title, FirstName, LastName, Suffix, EmailPromotion
FROM [Person].[Person]

CREATE NONCLUSTERED INDEX [IX_Person_ChangeIndex_LastName_FirstName]
    ON Person_ChangeIndex ([LastName] ASC, [FirstName] ASC)
    
ALTER TABLE Person_ChangeIndex ADD  CONSTRAINT [PK_Person_ChangeIndex_BusinessEntityID] 
    PRIMARY KEY CLUSTERED ([BusinessEntityID] ASC)

IF OBJECT_ID('Person_MoveCluster') IS NOT NULL
    DROP TABLE Person_MoveCluster

CREATE TABLE [dbo].[Person_MoveCluster](
	[BusinessEntityID] [int] NOT NULL,
	[PersonType] [nchar](2) NOT NULL,
	[NameStyle] [dbo].[NameStyle] NOT NULL,
	[Title] [nvarchar](8) NULL,
	[FirstName] [dbo].[Name] NOT NULL,
	[LastName] [dbo].[Name] NOT NULL,
	[Suffix] [nvarchar](10) NULL,
	[EmailPromotion] [int] NOT NULL,
    )
    
INSERT INTO Person_MoveCluster
SELECT BusinessEntityID, PersonType, NameStyle, Title, FirstName, LastName, Suffix, EmailPromotion
FROM [Person].[Person]

CREATE NONCLUSTERED INDEX [IX_Person_MoveCluster_LastName_FirstName]
    ON Person_MoveCluster ([LastName] ASC, [FirstName] ASC)
    
ALTER TABLE Person_MoveCluster ADD  CONSTRAINT [PK_Person_MoveCluster_BusinessEntityID] 
    PRIMARY KEY CLUSTERED ([BusinessEntityID] ASC)

/*
Can you use the DMVs to identify 
when clustered indexes may be 
misaligned or when they 
may need included columns?
*/
DECLARE @i int = 0
WHILE @i < 500
BEGIN
    SET NOCOUNT ON

    SELECT FirstName, LastName, PersonType
    INTO #A
    FROM Person_ChangeIndex
    WHERE [LastName] = 'Duffy'
    AND [FirstName] = 'Terri'
    
    SELECT FirstName, LastName, PersonType
    INTO #B
    FROM Person_MoveCluster
    WHERE [LastName] = 'Duffy'
    AND [FirstName] = 'Terri'
    
    DROP TABLE #A
    DROP TABLE #B
    SET @i += 1
    
    PRINT @i
END

--Indexes that haven't been used?
SELECT OBJECT_SCHEMA_NAME(i.object_id) + '.' + OBJECT_NAME(i.object_id)
    , i.index_id
    , i.name
    , i.type_desc
    , dius.user_seeks
    , dius.user_scans
    , dius.user_lookups
    , dius.user_updates
FROM sys.indexes i 
    LEFT OUTER JOIN sys.dm_db_index_usage_stats dius ON dius.object_id = i.object_id AND dius.index_id = i.index_id AND dius.database_id = DB_ID()
WHERE i.object_id = OBJECT_ID('Person_ChangeIndex')
OR i.object_id = OBJECT_ID('Person_MoveCluster')

/* -- Get execution plan
    SELECT FirstName, LastName, PersonType
    FROM Person_MoveCluster
    WHERE [LastName] = 'Duffy'
    AND [FirstName] = 'Terri'
*/

--Modify Person_ChangeIndex
ALTER TABLE Person_ChangeIndex DROP CONSTRAINT [PK_Person_ChangeIndex_BusinessEntityID] 

ALTER TABLE Person_ChangeIndex ADD  CONSTRAINT [PK_Person_ChangeIndex_BusinessEntityID] 
    PRIMARY KEY CLUSTERED ([BusinessEntityID] ASC)

DROP INDEX [IX_Person_ChangeIndex_LastName_FirstName] ON Person_ChangeIndex 

CREATE NONCLUSTERED INDEX [IX_Person_ChangeIndex_LastName_FirstName] ON Person_ChangeIndex 
    ([LastName] ASC, [FirstName] ASC) INCLUDE (PersonType)
    
-- Modify Person_MoveCluster
ALTER TABLE Person_MoveCluster DROP CONSTRAINT [PK_Person_MoveCluster_BusinessEntityID] 

DROP INDEX [IX_Person_MoveCluster_LastName_FirstName] ON Person_MoveCluster

CREATE CLUSTERED INDEX [IX_Person_MoveCluster_LastName_FirstName]
    ON Person_MoveCluster ([LastName] ASC, [FirstName] ASC)
    
ALTER TABLE Person_MoveCluster ADD  CONSTRAINT [PK_Person_MoveCluster_BusinessEntityID] 
    PRIMARY KEY NONCLUSTERED ([BusinessEntityID] ASC)
    
    
DECLARE @l int = 0
WHILE @l < 500
BEGIN
    SET NOCOUNT ON

    SELECT FirstName, LastName, PersonType
    INTO #C
    FROM Person_ChangeIndex
    WHERE [LastName] = 'Duffy'
    AND [FirstName] = 'Terri'
    
    SELECT FirstName, LastName, PersonType
    INTO #D
    FROM Person_MoveCluster
    WHERE [LastName] = 'Duffy'
    AND [FirstName] = 'Terri'
    
    DROP TABLE #C
    DROP TABLE #D
    SET @l += 1
    
    PRINT @l
END

SELECT OBJECT_SCHEMA_NAME(i.object_id) + '.' + OBJECT_NAME(i.object_id)
    , i.index_id
    , i.name
    , i.type_desc
    , dius.user_seeks
    , dius.user_scans
    , dius.user_lookups
    , dius.user_updates
FROM sys.indexes i 
    LEFT OUTER JOIN sys.dm_db_index_usage_stats dius ON dius.object_id = i.object_id AND dius.index_id = i.index_id AND dius.database_id = DB_ID()
WHERE i.object_id = OBJECT_ID('Person_ChangeIndex')
OR i.object_id = OBJECT_ID('Person_MoveCluster')
