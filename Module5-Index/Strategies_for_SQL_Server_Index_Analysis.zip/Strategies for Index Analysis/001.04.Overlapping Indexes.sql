USE AdventureWorks2014
GO

IF EXISTS(SELECT * FROM sys.indexes WHERE name = '_dta_index_Person_10_1509580416__K6_K7_K5_2')
    DROP INDEX [_dta_index_Person_10_1509580416__K6_K7_K5_2] ON [Person].[Person]

SET STATISTICS IO ON

--Improve performance.  Check out execution plan
SELECT FirstName, MiddleName, LastName, PersonType
FROM [Person].[Person]
WHERE [LastName] = 'Duffy'
AND [FirstName] = 'Terri'
AND [MiddleName] = 'Lee'

-- http://blog.sqlauthority.com/2009/10/07/sql-server-query-optimization-remove-bookmark-lookup-remove-rid-lookup-remove-key-lookup/
-- Run DTA, add a new index
CREATE NONCLUSTERED INDEX [_dta_index_Person_10_1509580416__K6_K7_K5_2] ON [Person].[Person] 
    ([LastName] ASC,  [FirstName] ASC, [MiddleName] ASC) INCLUDE (PersonType)

--Fixed!  
SELECT FirstName, MiddleName, LastName, PersonType
FROM [Person].[Person]
WHERE [LastName] = 'Duffy'
AND [FirstName] = 'Terri'
AND [MiddleName] = 'Lee'
GO

--Maybe?
;WITH indexcols 
AS
(
SELECT object_id
	,index_id
	,name
	,(SELECT CASE key_ordinal WHEN 0 THEN NULL ELSE column_id END AS [data()]
		FROM sys.index_columns k
		WHERE k.object_id = i.object_id
		AND k.index_id = i.index_id
		ORDER BY key_ordinal, column_id
		FOR XML PATH('')) cols
	,(SELECT CASE key_ordinal WHEN 0 THEN column_id ELSE NULL END AS [data()]
		FROM sys.index_columns k
		WHERE k.object_id = i.object_id
		AND k.index_id = i.index_id
		ORDER BY column_id
		FOR XML PATH('')) AS inc
FROM sys.indexes i
WHERE type < 3
)
SELECT
	OBJECT_SCHEMA_NAME(c1.object_id) + '.' + OBJECT_NAME(c1.object_id) as [Table]
	,c1.name as [Index]
	,c2.name as [Partial Duplicate]
	,STUFF((SELECT ', ' + CASE WHEN k.is_included_column = 0 THEN QUOTENAME(c.name, '[') ELSE QUOTENAME(c.name, '(') END AS [data()]
		FROM sys.index_columns k
			INNER JOIN sys.columns c ON k.object_id = c.object_id AND k.column_id = c.column_id
		WHERE k.object_id = c1.object_id
		AND k.index_id = c1.index_id
		ORDER BY CASE WHEN k.is_included_column = 0 THEN k.key_ordinal ELSE 99999 END, k.index_column_id
		FOR XML PATH('')),1,2,'') AS [Columns]
FROM indexcols c1
	INNER JOIN indexcols c2
ON c1.object_id = c2.object_id
AND c1.index_id > c2.index_id
AND (c1.cols LIKE c2.cols + '%' 
OR c2.cols LIKE c1.cols + '%') 
AND OBJECT_SCHEMA_NAME(c1.object_id) + '.' + OBJECT_NAME(c1.object_id) = 'Person.Person'
