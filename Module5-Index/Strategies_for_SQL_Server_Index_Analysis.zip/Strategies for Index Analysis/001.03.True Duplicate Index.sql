
--Listing 1. Obvious duplicate indexes

USE tempdb
GO
DROP TABLE dbo.Person

CREATE TABLE dbo.Person (
PersonID INT IDENTITY(1,1)
,FirstName VARCHAR(50)
,LastName VARCHAR(50)
,CONSTRAINT PK_Person PRIMARY KEY CLUSTERED (PersonID)
)

INSERT INTO dbo.Person
SELECT FirstName, LastName
FROM AdventureWorks2014.Person.Person

CREATE INDEX IX_Person_FirstName ON dbo.Person(FirstName)
CREATE INDEX IX_Person_FName ON dbo.Person(FirstName)


--Listing 2. Metadata Duplicate Index Script

;WITH IndexSchema AS (
SELECT i.object_id
,i.index_id
,i.name
,ISNULL(i.filter_definition,'') AS filter_definition
,i.is_unique
,(SELECT CASE key_ordinal WHEN 0 THEN NULL ELSE QUOTENAME(CAST(column_id AS VARCHAR)
+ CASE WHEN ic.is_descending_key = 1 THEN '-' ELSE '+' END,'(') END
FROM sys.index_columns ic
WHERE ic.object_id = i.object_id
AND ic.index_id = i.index_id
ORDER BY key_ordinal, column_id
FOR XML PATH('')) AS index_columns_keys_ids
,(SELECT CASE key_ordinal WHEN 0 THEN QUOTENAME(column_id,'(') ELSE NULL END
FROM sys.index_columns ic
WHERE ic.object_id = i.object_id
AND ic.index_id = i.index_id
ORDER BY column_id
FOR XML PATH('')) AS included_columns_ids
FROM sys.tables t
INNER JOIN sys.indexes i ON t.object_id = i.object_id
WHERE i.type_desc IN ('NONCLUSTERED'))
SELECT QUOTENAME(DB_NAME()) AS database_name
,QUOTENAME(OBJECT_SCHEMA_NAME(is1.object_id)) + '.'
+ QUOTENAME(OBJECT_NAME(is1.object_id)) AS object_name
,is1.name as index_name
,is2.name as duplicate_index_name
FROM IndexSchema is1
INNER JOIN IndexSchema is2 ON is1.object_id = is2.object_id
AND is1.index_id <> is2.index_id
AND is1.index_columns_keys_ids = is2.index_columns_keys_ids
AND is1.included_columns_ids = is2.included_columns_ids
AND is1.filter_definition = is2.filter_definition
AND is1.is_unique = is2.is_unique


--Listing 3. DBCC IND for First Two Indexes

USE tempdb
GO

DBCC IND (0,'dbo.Person',2)
DBCC IND (0,'dbo.Person',3)


--Listing 4. DBCC PAGE for First Two Indexes

USE tempdb
GO

DBCC TRACEON(3604)
DBCC PAGE(0,1,8120,3) -- Index page for first index
DBCC PAGE(0,1,8216,3) -- Index page for second index


--Listing 5. Create Script for Second Set of Indexes

USE tempdb
GO

CREATE INDEX IX_Person_FirstNameINC ON dbo.Person(FirstName) INCLUDE (PersonID)
CREATE INDEX IX_Person_FirstNamePersonID ON dbo.Person(FirstName, PersonID)


--Listing 6. DBCC PAGE for First Two Indexes

USE tempdb
GO

DBCC IND (0,'dbo.Person',4)
DBCC IND (0,'dbo.Person',5)

--Listing 7. DBCC PAGE for First Two Indexes

USE tempdb
GO

DBCC TRACEON(3604)
DBCC PAGE(0,1,8120,3) -- Index page for first index
DBCC PAGE(0,1,8216,3) -- Index page for second index
DBCC PAGE(0,1,8336,3) -- Index page for third index
DBCC PAGE(0,1,8440,3) -- Index page for four index


--Listing 8.&nbsp;Physically Duplicate Index Script

;WITH IndexSchema AS (
SELECT i.object_id
,i.index_id
,i.name
,ISNULL(i.filter_definition,'') AS filter_definition
,i.is_unique
,(SELECT QUOTENAME(CAST(ic.column_id AS VARCHAR(10))
+ CASE WHEN ic.is_descending_key = 1 THEN '-' ELSE '+' END, '(')
FROM sys.index_columns ic
INNER JOIN sys.columns c ON ic.object_id = c.object_id AND ic.column_id = c.column_id
WHERE i.object_id = ic.object_id
AND i.index_id = ic.index_id
AND is_included_column = 0
ORDER BY key_ordinal ASC
FOR XML PATH(''))
+ COALESCE((SELECT QUOTENAME(CAST(ic.column_id AS VARCHAR(10))
+ CASE WHEN ic.is_descending_key = 1 THEN '-' ELSE '+' END, '(')
FROM sys.index_columns ic
INNER JOIN sys.columns c ON ic.object_id = c.object_id AND ic.column_id = c.column_id
LEFT OUTER JOIN sys.index_columns ic_key ON c.object_id = ic_key.object_id
AND c.column_id = ic_key.column_id
AND i.index_id = ic_key.index_id
AND ic_key.is_included_column = 0
WHERE i.object_id = ic.object_id
AND ic.index_id = 1
AND ic.is_included_column = 0
AND ic_key.index_id IS NULL
ORDER BY ic.key_ordinal ASC
FOR XML PATH('')),'')
+ CASE WHEN i.is_unique = 1 THEN 'U' ELSE '' END AS index_columns_keys_ids

,CASE WHEN i.index_id IN (0,1) THEN 'ALL-COLUMNS' ELSE
COALESCE((SELECT QUOTENAME(ic.column_id,'(')
FROM sys.index_columns ic
INNER JOIN sys.columns c ON ic.object_id = c.object_id AND ic.column_id = c.column_id
LEFT OUTER JOIN sys.index_columns ic_key ON c.object_id = ic_key.object_id AND c.column_id = ic_key.column_id AND ic_key.index_id = 1
WHERE i.object_id = ic.object_id
AND i.index_id = ic.index_id
AND ic.is_included_column = 1
AND ic_key.index_id IS NULL
ORDER BY ic.key_ordinal ASC
FOR XML PATH('')), SPACE(0)) END AS included_columns_ids
FROM sys.tables t
INNER JOIN sys.indexes i ON t.object_id = i.object_id
INNER JOIN sys.data_spaces ds ON i.data_space_id = ds.data_space_id
INNER JOIN sys.dm_db_partition_stats ps ON i.object_id = ps.object_id AND i.index_id = ps.index_id)
SELECT QUOTENAME(DB_NAME()) AS database_name
,QUOTENAME(OBJECT_SCHEMA_NAME(is1.object_id)) + '.'
+ QUOTENAME(OBJECT_NAME(is1.object_id)) AS object_name
,is1.name as index_name
,is2.name as duplicate_index_name
FROM IndexSchema is1
INNER JOIN IndexSchema is2 ON is1.object_id = is2.object_id
AND is1.index_id <> is2.index_id
AND is1.index_columns_keys_ids = is2.index_columns_keys_ids
AND is1.included_columns_ids = is2.included_columns_ids
AND is1.filter_definition = is2.filter_definition
AND is1.is_unique = is2.is_unique

EXEC dbo.sp_IndexAnalysis @TableName = 'dbo.Person'