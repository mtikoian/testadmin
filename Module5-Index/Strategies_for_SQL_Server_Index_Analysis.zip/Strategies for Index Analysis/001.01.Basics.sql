USE AdventureWorks2014
GO

-- Basic details about your indexes
SELECT ds.name as filegroup
    , OBJECT_NAME(i.object_id) 
    , i.object_id
    , i.name
    , i.index_id -- 0: heap, 1:clustered, 2+: non-c
    , i.type
    , i.type_desc
    , i.is_unique
    , i.data_space_id -- filegroup
    , i.ignore_dup_key
    , i.is_primary_key
    , i.is_unique_constraint
    , i.fill_factor  -- leaf level of each index page during index creation or rebuild
    , i.is_padded -- fillfactor is applied to the intermediate-level pages of the index
    , i.is_disabled
    , i.is_hypothetical -- column level statistics
    , i.allow_row_locks
    , i.allow_page_locks
    , i.has_filter
    , i.filter_definition
FROM sys.indexes i
    INNER JOIN sys.data_spaces ds ON i.data_space_id = ds.data_space_id
WHERE OBJECTPROPERTY(i.object_id, 'IsUserTable') = 1

--Do you have heaps?
SELECT OBJECT_NAME(object_id), *
FROM sys.indexes
WHERE type = 0

--You are about to implement a CRUD solution... Do all tables have a primary keys?
SELECT * FROM sys.tables
WHERE object_id NOT IN (SELECT object_id FROM sys.indexes WHERE is_primary_key = 1)

-- Basic details about what is in your index
SELECT OBJECT_NAME(ic.object_id) as table_name
    , ic.object_id -- table reference
    , i.name as index_name
    , ic.index_id -- index identifier
    , c.name as column_name
    , ic.index_column_id -- not the actual index column order!
    , ic.column_id -- column reference in table
    , ic.key_ordinal -- actual index column order!!
    , ic.partition_ordinal
    , ic.is_descending_key
    , ic.is_included_column
FROM sys.index_columns ic
    INNER JOIN sys.indexes i ON ic.object_id = i.object_id AND ic.index_id = i.index_id
    INNER JOIN sys.columns c ON ic.object_id = c.object_id AND ic.index_column_id = c.column_id
WHERE OBJECTPROPERTY(ic.object_id, 'IsUserTable') = 1
--AND ic.object_id = 354100302
--AND ic.index_id = 2
ORDER BY 1, 2, 3

