USE AdventureWorks2014
GO

SELECT database_id
    , object_id
    , index_id
    , partition_number
    , index_type_desc
    , alloc_unit_type_desc
    , index_depth
    , index_level
    , avg_fragmentation_in_percent
    , fragment_count
    , avg_fragment_size_in_pages 
    , page_count
    , avg_page_space_used_in_percent
    , record_count
    , ghost_record_count
    , version_ghost_record_count
    , min_record_size_in_bytes
    , max_record_size_in_bytes
    , avg_record_size_in_bytes
    , forwarded_record_count
    , compressed_page_count
FROM sys.dm_db_index_physical_stats(DB_ID(),NULL,NULL,NULL,NULL)

/*
avg_fragmentation_in_percent 
> 5% and < = 30%    ALTER INDEX REORGANIZE
> 30%               ALTER INDEX REBUILD WITH (ONLINE = ON)
*/
SELECT DB_NAME(database_id) as database_name
    ,OBJECT_NAME(object_id) as object_name
    ,index_id
    ,partition_number
    ,avg_fragmentation_in_percent
    ,fragment_count
    ,avg_fragment_size_in_pages
FROM sys.dm_db_index_physical_stats(DB_ID(),NULL,NULL,NULL,NULL)
WHERE avg_fragmentation_in_percent > 5
ORDER BY avg_fragmentation_in_percent ASC
