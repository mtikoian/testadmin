USE AdventureWorks2014
GO

IF OBJECT_ID('dbo.SalesOrderHeader') IS NOT NULL
DROP TABLE dbo.SalesOrderHeader

IF OBJECT_ID('dbo.Customer') IS NOT NULL
DROP TABLE dbo.Customer

CREATE TABLE dbo.Customer(
	CustomerID int
	,FillterData char(1000)
	,CONSTRAINT PK_Customer_CustomerID PRIMARY KEY CLUSTERED (CustomerID)
	);

CREATE TABLE dbo.SalesOrderHeader(
	SalesOrderID int
	,OrderDate datetime 
	,DueDate datetime 
	,CustomerID int 
	,FillterData char(1000)
	,CONSTRAINT PK_SalesOrderHeader_SalesOrderID PRIMARY KEY CLUSTERED (SalesOrderID)
	,CONSTRAINT GK_SalesOrderHeader_CustomerID_FROM_Customer FOREIGN KEY (CustomerID) REFERENCES dbo.Customer(CustomerID)
	);

INSERT INTO dbo.Customer (CustomerID)
SELECT CustomerID
FROM Sales.Customer;

INSERT INTO dbo.SalesOrderHeader (SalesOrderID, OrderDate, DueDate, CustomerID)
SELECT SalesOrderID, OrderDate, DueDate, CustomerID
FROM Sales.SalesOrderHeader;
