--http://sqlblog.com/blogs/louis_davidson/archive/2007/08/26/sys-dm-db-index-operational-stats.aspx

USE AdventureWorks2014
GO
--low-level I/O, locking, latching, and access method activity 
--sys.dm_db_index_operational_stats

SELECT object_id
    , index_id
    , partition_number
    , leaf_insert_count
    , leaf_delete_count
    , leaf_update_count
    , leaf_ghost_count
    , nonleaf_insert_count
    , nonleaf_delete_count
    , nonleaf_update_count
    , leaf_allocation_count
    , nonleaf_allocation_count
    , leaf_page_merge_count
    , nonleaf_page_merge_count
    , range_scan_count
    , singleton_lookup_count
    , forwarded_fetch_count
    , lob_fetch_in_pages
    , lob_fetch_in_bytes
    , lob_orphan_create_count
    , lob_orphan_insert_count
    , row_overflow_fetch_in_pages
    , row_overflow_fetch_in_bytes
    , column_value_push_off_row_count
    , column_value_pull_in_row_count
    , row_lock_count
    , row_lock_wait_count
    , row_lock_wait_in_ms
    , page_lock_count
    , page_lock_wait_count
    , page_lock_wait_in_ms
    , index_lock_promotion_attempt_count
    , index_lock_promotion_count
    , page_latch_wait_count
    , page_latch_wait_in_ms
    , page_io_latch_wait_count
    , page_io_latch_wait_in_ms
    , tree_page_latch_wait_count
    , tree_page_latch_wait_in_ms
    , tree_page_io_latch_wait_count
    , tree_page_io_latch_wait_in_ms
    , page_compression_attempt_count
    , page_compression_success_count
FROM sys.dm_db_index_operational_stats(db_id(),null,null,null) 


--Tables with latch contention
--High pagelatch or pageiolatch waits?  Here's where to look...
SELECT OBJECT_SCHEMA_NAME(ios.object_id) + '.' + OBJECT_NAME(ios.object_id) as table_name
    ,i.name as index_name
    ,page_latch_wait_count
    ,CAST(100. * page_latch_wait_in_ms / NULLIF(page_io_latch_wait_count,0) AS decimal(12,2)) AS avg_page_latch_wait_ms
    ,page_io_latch_wait_count
    ,CAST(100. * page_io_latch_wait_in_ms / NULLIF(page_io_latch_wait_count,0) AS decimal(12,2)) AS avg_page_io_latch_wait_ms
FROM sys.dm_db_index_operational_stats(DB_ID(),NULL,NULL,NULL) ios
    INNER JOIN sys.indexes i ON i.object_id = ios.object_id AND i.index_id = ios.index_id
WHERE OBJECTPROPERTY(ios.object_id,'IsUserTable') = 1
ORDER BY page_latch_wait_count + page_io_latch_wait_count DESC


--List out indexes with the most contention e.g. blocking
SELECT OBJECT_SCHEMA_NAME(ios.object_id) + '.' + OBJECT_NAME(ios.object_id) as table_name
    ,i.name as index_name
    ,page_lock_count
    ,page_lock_wait_count
    ,CAST(100. * page_lock_wait_count / NULLIF(page_lock_count,0) AS decimal(6,2)) AS block_pct
    ,page_lock_wait_in_ms
    ,CAST(100. * page_lock_wait_in_ms / NULLIF(page_lock_wait_count,0) AS decimal(12,2)) AS avg_lock_wait_ms
    ,row_lock_count
    ,row_lock_wait_count
    ,CAST(100. * row_lock_wait_count / NULLIF(row_lock_count,0) AS decimal(6,2)) AS block_pct
    ,row_lock_wait_in_ms
    ,CAST(100. * row_lock_wait_in_ms / NULLIF(row_lock_wait_count,0) AS decimal(12,2)) AS avg_lock_wait_ms
FROM sys.dm_db_index_operational_stats (DB_ID(), NULL, NULL, NULL) ios
    INNER JOIN sys.indexes i ON i.object_id = ios.object_id AND i.index_id = ios.index_id
WHERE OBJECTPROPERTY(ios.object_id,'IsUserTable') = 1
ORDER BY row_lock_wait_count + page_lock_wait_count DESC, row_lock_count + page_lock_count DESC


--Back to first captain obvious... mentioned Index Usage...
--How have indexes been used?
;WITH UseageCTE
AS (
    SELECT OBJECT_SCHEMA_NAME(i.object_id) + '.' + OBJECT_NAME(i.object_id) as table_name
        , i.index_id
        , i.name as index_name
        , COALESCE(dius.user_seeks,0) AS user_seeks
        , COALESCE(dius.user_scans,0) AS user_scans
        , COALESCE(dius.user_lookups,0) AS user_lookups
        , COALESCE(dius.user_seeks,0) + COALESCE(dius.user_scans,0) + COALESCE(dius.user_lookups,0) AS user_total
        , COALESCE(dius.user_updates,0) AS user_updates
    FROM sys.indexes i 
        LEFT OUTER JOIN sys.dm_db_index_usage_stats dius ON dius.object_id = i.object_id AND dius.index_id = i.index_id AND dius.database_id = DB_ID()
    WHERE i.object_id = OBJECT_ID('Person.Person')
    )
SELECT table_name
    , index_name
    , user_seeks
    , user_scans
    , user_lookups
    , user_total 
    , CAST(100.*user_total/SUM(user_total) OVER() as decimal(12,2)) as user_percent
    , user_updates
    , CAST((100.*user_updates/NULLIF(user_total,0)) as decimal(12,2)) AS update_ratio
FROM UseageCTE
ORDER BY 8 DESC

--How did the index get used operationally?
SELECT OBJECT_SCHEMA_NAME(ios.object_id) + '.' + OBJECT_NAME(ios.object_id) as table_name
    , i.name as index_name
    , ios.range_scan_count
    , ios.singleton_lookup_count
    , ios.leaf_insert_count
    , ios.leaf_delete_count
    , ios.leaf_update_count
    --, ios.leaf_update_count/6
    
FROM sys.dm_db_index_operational_stats (DB_ID(), NULL, NULL, NULL) ios
    INNER JOIN sys.indexes i ON i.object_id = ios.object_id AND i.index_id = ios.index_id
WHERE OBJECTPROPERTY(ios.object_id,'IsUserTable') = 1 
AND ios.object_id = OBJECT_ID('Person.Person')
