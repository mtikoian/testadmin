--Who uses fks to analyze their indexes?
-- You guys should make sure I'm reading all of 
-- my inline notes.
USE AdventureWorks2014
GO

SELECT name
    , object_id
    , principal_id
    , schema_id
    , parent_object_id
    , type
    , type_desc
    , create_date --<-- Indexes should have THIS!!!
    , modify_date --<-- Indexes should have this
    , is_ms_shipped
    , is_published
    , is_schema_published
    , referenced_object_id
    , key_index_id
    , is_disabled
    , is_not_for_replication
    , is_not_trusted
    , delete_referential_action
    , delete_referential_action_desc
    , update_referential_action
    , update_referential_action_desc
    , is_system_named
FROM sys.foreign_keys

SELECT constraint_object_id
    , constraint_column_id
    , parent_object_id, OBJECT_NAME(parent_object_id)
    , parent_column_id
    , referenced_object_id, OBJECT_NAME(referenced_object_id)
    , referenced_column_id
FROM sys.foreign_key_columns
