
--pick a random number 
DECLARE @maxNumber INT = 1000000

DECLARE @myNumber INT = CAST(RAND() * @maxNumber + 1 AS INT) ;
PRINT 'My number is ' + CAST(@myNumber AS VARCHAR)

DECLARE @guess INT = @maxNumber/2
DECLARE @highGuess INT = @maxNumber
DECLARE @lowGuess INT = 1 
DECLARE @guessCount INT = 1

WHILE @guess <> @myNumber BEGIN 
	
	IF @myNumber > @guess BEGIN
		set @lowGuess = @guess; 
		SET @guess = (@highGuess + @guess)/2
	END
	ELSE BEGIN 
		SET @highGuess = @guess
		SET @guess = (@lowGuess + @guess)/2;
	END
	SET @guessCount += 1;
	Print @guess;
END  

print 'I found the number in ' + CAST(@guessCount AS VARCHAR) + ' guesses!'

