create table Heap(ID INT not null, Number int not null identity) 

declare @count INT = 0 

declare @random int 

while @count < 1000 begin 
	set @random = cast(rand() * 1000 +1 AS Int)
	if not exists(select * from heap where ID = @random) begin
		insert into heap(ID) select @random 
		set @count +=1
	end

end


Create table Numbers(Numbers INT NOT NULL) 

;with Numberz AS(Select ROW_NUMBER() OVER(Order by (SELECT NULL)) Number
	from sys.objects a cross join sys.objects b cross join sys.objects c)
INSERT INTO Numbers
select Number 
from Numberz
WHERE Number <= 10000 

select * from Numbers
select * from Heap
