set statistics io off
USE Index_Demos
GO
SET NOCOUNT ON;

--The best Clustered Indexes
-- Are ever-increasing
IF OBJECT_ID('RandomInserts') IS NOT NULL 
	DROP TABLE RandomInserts; 
GO
CREATE TABLE RandomInserts (ID INT NOT NULL, 
		CharValue CHAR(896) DEFAULT 'AAA');
GO
CREATE UNIQUE CLUSTERED INDEX CI_RandomInserts ON RandomInserts (ID);
GO
DECLARE @count INT = 0 ;
DECLARE @random INT; 
WHILE @count < 10000 BEGIN
	SET @random = cast(rand() * 10000 +1 AS INT);
	BEGIN TRY 
		INSERT INTO RandomInserts(ID) VALUES(@random);
		SET @count +=1;
	END TRY 
	BEGIN CATCH
		--do nothing
	END CATCH;
END;

--start
IF OBJECT_ID('OrderedInserts') IS NOT NULL 
	DROP TABLE OrderedInserts; 
GO
CREATE TABLE OrderedInserts(ID INT NOT NULL PRIMARY KEY, 
	CharValue CHAR(896) DEFAULT 'AAA');
GO
INSERT INTO OrderedInserts(ID) 
SELECT Number 
FROM 
Numbers; 


--Identical structure and values,
--just inserted in different orders
SELECT * FROM RandomInserts;
SELECT * FROM OrderedInserts;


SELECT index_type_desc, index_depth, index_level, 
	avg_fragmentation_in_percent,page_count, record_count  
FROM sys.dm_db_index_physical_stats(DB_ID(), 
	OBJECT_ID('dbo.RandomInserts'),NULL, NULL, 'Detailed');

SELECT index_type_desc, index_depth, index_level, 
	avg_fragmentation_in_percent,page_count, record_count  
FROM sys.dm_db_index_physical_stats(DB_ID(), 
	OBJECT_ID('dbo.OrderedInserts'),NULL, NULL, 'Detailed');


--The best cluster key is narrow
IF OBJECT_ID('WIDE') IS NOT NULL
	DROP TABLE WIDE;
GO

CREATE TABLE WIDE(ID INT, CharValue CHAR(896) DEFAULT 'AAA');
CREATE CLUSTERED INDEX CI_WIDE ON WIDE(ID,CharValue); 

INSERT INTO WIDE(ID)
SELECT number 
FROM Numbers; 


SELECT index_type_desc, index_depth, index_level, 
	avg_fragmentation_in_percent,page_count, record_count  
FROM sys.dm_db_index_physical_stats(DB_ID(), 
	OBJECT_ID('dbo.WIDE'),NULL, NULL, 'Detailed');

SELECT index_type_desc, index_depth, index_level, 
	avg_fragmentation_in_percent,page_count, record_count  
FROM sys.dm_db_index_physical_stats(DB_ID(), 
	OBJECT_ID('dbo.OrderedInserts'),NULL, NULL, 'Detailed');

--The best cluster key is unique
IF OBJECT_ID('NonUnique') IS NOT NULL
	DROP TABLE NonUnique;

CREATE TABLE NonUnique(ID INT, CharValue CHAR(896))
GO
CREATE CLUSTERED INDEX CI_NonUnique ON NonUnique(CharValue);


INSERT INTO NonUnique(ID, CharValue)
SELECT Number, 
		CASE WHEN Number < 1000 THEN 'AAA' 
			WHEN Number BETWEEN 1001 AND 2000 THEN 'BBB'
			WHEN Number BETWEEN 2001 AND 3000 THEN 'CCC'
			WHEN Number BETWEEN 3001 AND 4000 THEN 'DDD'
			WHEN Number BETWEEN 4001 AND 5000 THEN 'EEE'
			WHEN Number BETWEEN 5001 AND 6000 THEN 'BBB'
			WHEN Number BETWEEN 6001 AND 7000 THEN 'CCC'
			WHEN Number BETWEEN 7001 AND 8000 THEN 'DDD'
			WHEN Number BETWEEN 8001 AND 8960 THEN 'EEE'
			WHEN Number BETWEEN 8961 AND 10000 THEN 'FFF'
		END
FROM Numbers;

SELECT index_type_desc, index_depth, index_level, 
	avg_fragmentation_in_percent,page_count, record_count  
FROM sys.dm_db_index_physical_stats(DB_ID(), 
	OBJECT_ID('dbo.NonUnique'),NULL, NULL, 'Detailed');	

SET STATISTICS IO ON;
SELECT ID, CharValue
FROM NonUnique
WHERE CharValue = 'CCC' AND ID = 2550;

SELECT ID, CharValue
FROM NonUnique
WHERE ID = 2550;

SELECT ID, CharValue 
FROM OrderedInserts 
WHERE ID = 2550;


--The best cluster key doesn't change
set statistics io off
IF OBJECT_ID('Changes')  IS NOT NULL
	DROP TABLE Changes ;
GO
CREATE TABLE Changes(ID INT, CharValue CHAR(986));
GO
CREATE CLUSTERED INDEX CI_Changes ON Changes (ID);
INSERT INTO Changes(ID)
SELECT Number
FROM Numbers 
ORDER BY Number;

SELECT index_type_desc, index_depth, index_level, 
	avg_fragmentation_in_percent,page_count, record_count  
FROM sys.dm_db_index_physical_stats(DB_ID(), 
	OBJECT_ID('dbo.Changes'),NULL, NULL, 'Detailed');	

UPDATE Changes 
SET ID = ID * CAST(RAND() * 10 AS Integer) 
WHERE ID % 10 = 0;

SELECT index_type_desc, index_depth, index_level, 
	avg_fragmentation_in_percent,page_count, record_count  
FROM sys.dm_db_index_physical_stats(DB_ID(), 
	OBJECT_ID('dbo.Changes'),NULL, NULL, 'Detailed');
	
--END CLUSTERED




--Non-clustered index

USE AdventureWorks2014;
GO

--create a demo table
IF OBJECT_ID('dbo.DEMO_SalesDetail') IS NOT NULL 
	DROP TABLE dbo.DEMO_SalesDetail;

SELECT * INTO dbo.DEMO_SalesDetail FROM Sales.SalesOrderDetail ;
ALTER TABLE dbo.DEMO_SalesDetail ADD PRIMARY KEY CLUSTERED
	(SalesOrderID, SalesOrderDetailID)
   
 
SET STATISTICS IO ON;
--Turn on execution plan
SELECT SalesOrderID, ProductID
FROM dbo.DEMO_SalesDetail
WHERE ProductID = 919;


--Add the index
CREATE NONCLUSTERED INDEX NDX_DEMO_SalesDetail ON 
	dbo.DEMO_SalesDetail (ProductID);


SELECT SalesOrderID, ProductID
FROM dbo.DEMO_SalesDetail
WHERE ProductID = 919;

--Key lookup
SELECT SalesOrderID, ProductID, OrderQty  
FROM dbo.DEMO_SalesDetail 
WHERE ProductID = 919;

--Scan
SELECT SalesOrderID, ProductID, OrderQty  
FROM dbo.DEMO_SalesDetail 
WHERE ProductID = 707;

DROP INDEX NDX_DEMO_SalesDetail ON dbo.DEMO_SalesDetail;

CREATE NONCLUSTERED INDEX NDX_DEMO_SalesDetail
ON dbo.DEMO_SalesDetail (ProductID) INCLUDE(OrderQty);

SELECT SalesOrderID, SalesOrderDetailID,
	ProductID, OrderQty  
FROM dbo.DEMO_SalesDetail 
WHERE ProductID = 707;

--Intersecting columns
SELECT SalesOrderID,ModifiedDate, ProductID 
FROM dbo.DEMO_SalesDetail  
WHERE ProductID = 877 AND
	ModifiedDate = '2013-05-30';

CREATE INDEX NDX_DEMO_SalesDetails_ModifiedDate
	ON dbo.DEMO_SalesDetail(ModifiedDate);

SELECT SalesOrderID,ModifiedDate, ProductID 
FROM dbo.DEMO_SalesDetail  
WHERE ProductID = 877 AND
	ModifiedDate = '2013-05-30';

--Order is important!
DROP INDEX NDX_DEMO_SalesDetails_ModifiedDate ON dbo.DEMO_SalesDetail
DROP INDEX NDX_DEMO_SalesDetail ON dbo.DEMO_SalesDetail;

CREATE NONCLUSTERED INDEX NDX_DEMO_SalesDetail ON dbo.DEMO_SalesDetail 
	(ProductID, ModifiedDate);

SELECT SalesOrderID, ProductID, ModifiedDate 
FROM dbo.DEMO_SalesDetail 
WHERE ProductID = 707;

SELECT SalesOrderID, ProductID, ModifiedDate 
FROM dbo.DEMO_SalesDetail 
WHERE ModifiedDate = '2013-05-30';







--Fragmentation
SELECT * FROM RandomInserts;


SELECT index_type_desc, index_depth, index_level, 
	avg_fragmentation_in_percent,page_count, record_count  
FROM sys.dm_db_index_physical_stats(DB_ID(), 
	OBJECT_ID('dbo.RandomInserts'),NULL, NULL, 'Detailed');
	
--CREATE UNIQUE CLUSTERED INDEX CI_RandomInserts ON RandomInserts (ID) DROP_EXISTING = ON;

--ALTER INDEX CI_RandomInserts ON RandomInserts REORGANIZE;

ALTER INDEX CI_RandomInserts ON RandomInserts REBUILD;

SELECT index_type_desc, index_depth, index_level, 
	avg_fragmentation_in_percent,page_count, record_count  
FROM sys.dm_db_index_physical_stats(DB_ID(), 
	OBJECT_ID('dbo.RandomInserts'),NULL, NULL, 'Detailed');


--Fill Factor

exec sys.sp_configure 'show advanced options','1'
go
reconfigure
go
exec sys.sp_configure

GO

SELECT i.fill_factor,i.name, ddips.index_depth, ddips.index_level
    , ddips.page_count, ddips.record_count
FROM sys.indexes AS i
Join sys.dm_db_index_physical_stats(DB_ID(), 
    OBJECT_ID(N'dbo.RandomInserts'), Null, Null, N'Detailed') AS ddips
    ON i.OBJECT_ID = ddips.OBJECT_ID
    And i.index_id = ddips.index_id;


ALTER INDEX CI_RandomInserts ON RandomInserts REBUILD WITH (FILLFACTOR = 80);

--Fill Factor
SELECT i.fill_factor,i.name, ddips.index_depth, ddips.index_level
    , ddips.page_count, ddips.record_count
FROM sys.indexes AS i
Join sys.dm_db_index_physical_stats(DB_ID(), 
    OBJECT_ID(N'dbo.RandomInserts'), Null, Null, N'Detailed') AS ddips
    ON i.OBJECT_ID = ddips.OBJECT_ID
    And i.index_id = ddips.index_id;


ALTER INDEX CI_RandomInserts ON RandomInserts REBUILD;

--Fill Factor
SELECT i.fill_factor,i.name, ddips.index_depth, ddips.index_level
    , ddips.page_count, ddips.record_count
FROM sys.indexes AS i
Join sys.dm_db_index_physical_stats(DB_ID(), 
    OBJECT_ID(N'dbo.RandomInserts'), Null, Null, N'Detailed') AS ddips
    ON i.OBJECT_ID = ddips.OBJECT_ID
    And i.index_id = ddips.index_id;
    
    
--Tools for query tuning
--Execution plan
USE stratus_client;
GO
SELECT Address1, Address2, City, s.PostalCode
FROM system.Sites s
WHERE s.City = 'Collinsville';

--missing indexes, Glenn Berry query
SELECT DISTINCT CONVERT(decimal(18,2), user_seeks * avg_total_user_cost * (avg_user_impact * 0.01)) AS [index_advantage], 
migs.last_user_seek, mid.[statement] AS [Database.Schema.Table],
mid.equality_columns, mid.inequality_columns, mid.included_columns,
migs.unique_compiles, migs.user_seeks, migs.avg_total_user_cost, migs.avg_user_impact,
OBJECT_NAME(mid.[object_id]) AS [Table Name], p.rows AS [Table Rows]
FROM sys.dm_db_missing_index_group_stats AS migs WITH (NOLOCK)
INNER JOIN sys.dm_db_missing_index_groups AS mig WITH (NOLOCK)
ON migs.group_handle = mig.index_group_handle
INNER JOIN sys.dm_db_missing_index_details AS mid WITH (NOLOCK)
ON mig.index_handle = mid.index_handle
INNER JOIN sys.partitions AS p WITH (NOLOCK)
ON p.[object_id] = mid.[object_id]
WHERE mid.database_id = DB_ID() 
ORDER BY index_advantage DESC OPTION (RECOMPILE);

--Unneeded indexes, Glenn Berry
SELECT OBJECT_NAME(s.[object_id]) AS [Table Name], i.name AS [Index Name], 
o.[type_desc], o.create_date, i.index_id, i.is_disabled,
user_updates AS [Total Writes], user_seeks + user_scans + user_lookups AS [Total Reads],
user_updates - (user_seeks + user_scans + user_lookups) AS [Difference]
FROM sys.dm_db_index_usage_stats AS s WITH (NOLOCK)
INNER JOIN sys.indexes AS i WITH (NOLOCK)
ON s.[object_id] = i.[object_id]
AND i.index_id = s.index_id
INNER JOIN sys.objects AS o WITH (NOLOCK) 
ON i.[object_id] = o.[object_id]
WHERE OBJECTPROPERTY(s.[object_id],'IsUserTable') = 1
AND s.database_id = DB_ID()
AND user_updates > (user_seeks + user_scans + user_lookups)
AND i.index_id > 1
ORDER BY [Difference] DESC, [Total Writes] DESC, [Total Reads] ASC OPTION (RECOMPILE);

--Duplicate indexes, http://www.sql-server-performance.com/2013/find-duplicate-indexes-on-sql-server/
SET NOCOUNT ON;

DECLARE  @First				[smallint]
		,@Last				[smallint]
		,@DBName			[nvarchar] (128)
		,@SQLServer			[nvarchar] (128)
		,@StringToExecuteP1	[nvarchar] (max)
		,@StringToExecuteP2	[nvarchar] (max)
		,@StringToExecuteP3	[nvarchar] (max)

IF NOT EXISTS (SELECT *
			   FROM [tempdb].[sys].[objects]
			   WHERE [name] = 'DUPLICATE_INDEXES_INFO'
				AND [type] IN (N'U'))
BEGIN
	CREATE TABLE [tempdb].[dbo].[DUPLICATE_INDEXES_INFO]
		([Server]				[nvarchar](128)
		,[Database]				[nvarchar](128)
	    ,[TableName]			[varchar](256)
	    ,[IndexName]			[varchar](256)
	    ,[IndexType]			[varchar](13)
	    ,[KeyColumns]			[varchar](512)
	    ,[NonKeyColumns]		[varchar](512)
	    ,[KeyColumnsOrder]		[varchar](512)
	    ,[NonKeyColumnsOrder]	[varchar](512)
	    ,[IsUnique]				[char](1)
	    ,[HasNonKeyColumns]		[char](1)
		,[CheckDate]			[datetime])
END
ELSE
BEGIN
	TRUNCATE TABLE [tempdb].[dbo].[DUPLICATE_INDEXES_INFO]
END

IF OBJECT_ID('Tempdb.dbo.#Indexes') IS NOT NULL
	DROP TABLE #Indexes
CREATE TABLE #Indexes  
	([RowNo] [smallint] IDENTITY(1, 1)
	,[TableName] [varchar](256)
	,[IndexName] [varchar](256)
	,[IsUnique] [smallint]
	,[IndexType] [varchar](13))
					   
IF OBJECT_ID('Tempdb.dbo.#AllIndexesInfo') IS NOT NULL
	DROP TABLE #AllIndexesInfo
CREATE TABLE #AllIndexesInfo
	([ObjectID]			[int] NOT NULL
	,[TableName]		[nvarchar](128) NULL
	,[IndexID]			[int] NOT NULL
	,[IndexName]		[sysname] NULL
	,[IndexType]		[varchar](13) NOT NULL
	,[ColumnID]			[int] NOT NULL
	,[ColumnName]		[sysname] NULL
	,[IncludedColumns]	[bit] NULL
	,[IsUnique]			[bit] NULL)

IF OBJECT_ID('Tempdb.dbo.#AllIndexesDetailedInfo') IS NOT NULL
	DROP TABLE #AllIndexesDetailedInfo					
CREATE TABLE #AllIndexesDetailedInfo
	([TableName]			[varchar](256)
	,[IndexName]			[varchar](256)
	,[IndexType]			[varchar](13)
	,[KeyColumns]			[varchar](512)
	,[NonKeyColumns]		[varchar](512)
	,[KeyColumnsOrder]		[varchar](512)
	,[NonKeyColumnsOrder]	[varchar](512)
	,[IsUnique]				[char](1)
	,[HasNonKeyColumns]		[char](1))
								    
DECLARE @DatabaseList TABLE ([RowNo]  [smallint] identity (1, 1)
							,[DBName] [varchar](200))

SELECT @SQLServer = CAST(SERVERPROPERTY('ServerName') AS [nvarchar](128))

INSERT INTO @DatabaseList 
SELECT [name] FROM [master].[sys].[databases] WITH (NOLOCK) 
WHERE  [state_desc] = 'ONLINE' 
	AND [source_database_id] IS NULL
	AND [database_id] > 4

SELECT @First = MIN([RowNo]) FROM @DatabaseList
SELECT @Last = MAX([RowNo]) FROM @DatabaseList

WHILE @First <= @Last
BEGIN
	SELECT @DBName = [DBName] 
	FROM @DatabaseList WHERE [RowNo] = @First

	SET @StringToExecuteP1 = 'USE [' + @DBName + '];
		INSERT INTO #AllIndexesInfo
				   ([ObjectID]
				   ,[TableName]
				   ,[IndexID]
				   ,[IndexName]
				   ,[IndexType]
				   ,[ColumnID]
				   ,[ColumnName]
				   ,[IncludedColumns]
				   ,[IsUnique])
		SELECT o.[object_id] AS [ObjectID]
			  ,OBJECT_NAME(o.[object_id]) AS [TableName]
			  ,i.[index_id] AS [IndexID]
			  ,i.[name] AS [IndexName]
			  ,CASE i.[type]
				WHEN 0
					THEN ''Heap''
				WHEN 1
					THEN ''Clustered''
				WHEN 2
					THEN ''Non-Clustered''
				WHEN 3
					THEN ''XML''
				ELSE ''Unknown''
				END AS [IndexType]
			,ic.[column_id] AS [ColumnID]
			,c.[name] AS [ColumnName]
			,ic.[is_included_column] [IncludedColumns]
			,i.[is_unique] AS [IsUnique]
		FROM [' + @DBName + '].[sys].[indexes] i
		INNER JOIN [' + @DBName + '].[sys].[objects] o 
			ON i.[object_id] = o.[object_id]
				AND o.[type] = ''U''
				AND i.[index_id] > 0
		INNER JOIN [' + @DBName + '].[sys].[index_columns] ic 
			ON i.[index_id] = ic.[index_id]
				AND i.[object_id] = ic.[object_id]
		INNER JOIN [' + @DBName + '].[sys].[columns] c 
			ON c.[column_id] = ic.[column_id]
				AND c.[object_id] = ic.[object_id]
			
		INSERT INTO #Indexes
		SELECT DISTINCT [TableName]
			,[IndexName]
			,[IsUnique]
			,[IndexType]
		FROM #AllIndexesInfo'

	EXEC (@StringToExecuteP1)

	SET @StringToExecuteP2 = 'USE [' + @DBName + '];
		DECLARE @First				[smallint]
			   ,@Last				[smallint]
			   ,@IsUnique			[smallint]
			   ,@HasNonKeyCols		[char] (1)
			   ,@TableName			[varchar] (256)
			   ,@IndexName			[varchar] (256)
			   ,@IndexType			[varchar] (13)
			   ,@IndexColumns		[varchar] (1000)
			   ,@IncludedColumns	[varchar] (1000)
			   ,@IndexColsOrder		[varchar] (1000)
			   ,@IncludedColsOrder  [varchar] (1000)

		SELECT @First = MIN([RowNo])
		FROM #Indexes

		SELECT @Last = MAX([RowNo])
		FROM #Indexes

		WHILE @First <= @Last
		BEGIN
			SET @IndexColumns = NULL
			SET @IncludedColumns = NULL
			SET @IncludedColsOrder = NULL
			SET @IndexColsOrder = NULL

			SELECT @TableName = [TableName]
				  ,@IndexName = [IndexName]
				  ,@IsUnique  = [IsUnique]
				  ,@IndexType = [IndexType]
			FROM #Indexes
			WHERE [RowNo] = @First

			SELECT @IndexColumns = COALESCE(@IndexColumns + '', '', '''') 
										+ [ColumnName]
			FROM #AllIndexesInfo
			WHERE [TableName] = @TableName
				AND [IndexName] = @IndexName
				AND [IncludedColumns] = 0
			ORDER BY [IndexName]
					,[ColumnName]

			SELECT @IncludedColumns = COALESCE(@IncludedColumns + '', '', '''') 
										+ [ColumnName]
			FROM #AllIndexesInfo
			WHERE [TableName] = @TableName
				AND [IndexName] = @IndexName
				AND [IncludedColumns] = 1
			ORDER BY [IndexName]
					,[ColumnName]

			SELECT @IndexColsOrder = COALESCE(@IndexColsOrder + '', '', '''') 
										+ [ColumnName]
			FROM #AllIndexesInfo
			WHERE [TableName] = @TableName
				AND [IndexName] = @IndexName
				AND [IncludedColumns] = 0

			SELECT @IncludedColsOrder = COALESCE(@IncludedColsOrder + '', '', '''') 
										+ [ColumnName]
			FROM #AllIndexesInfo
			WHERE [TableName] = @TableName
				AND [IndexName] = @IndexName
				AND [IncludedColumns] = 1

			SET @HasNonKeyCols = ''N''

			IF @IncludedColumns IS NOT NULL
			BEGIN
				SET @HasNonKeyCols = ''Y''
			END

			INSERT INTO #AllIndexesDetailedInfo (
				[TableName]
				,[IndexName]
				,[IndexType]
				,[IsUnique]
				,[KeyColumns]
				,[KeyColumnsOrder]
				,[HasNonKeyColumns]
				,[NonKeyColumns]
				,[NonKeyColumnsOrder]
				)
			SELECT @TableName
				,@IndexName
				,@IndexType
				,CASE @IsUnique
					WHEN 1
						THEN ''Y''
					WHEN 0
						THEN ''N''
					END
				,@IndexColumns
				,@IndexColsOrder
				,@HasNonKeyCols
				,@IncludedColumns
				,@IncludedColsOrder

			SET @First = @First + 1
		END'

	EXEC (@StringToExecuteP2)

	SET @StringToExecuteP3 = 'USE [' + @DBName + '];
	  INSERT INTO [tempdb].[dbo].[DUPLICATE_INDEXES_INFO]
			   ([Server]
			   ,[Database]
			   ,[TableName]
			   ,[IndexName]
			   ,[IndexType]
	   		   ,[KeyColumns]
			   ,[HasNonKeyColumns]
			   ,[NonKeyColumns]
			   ,[KeyColumnsOrder]
			   ,[NonKeyColumnsOrder]
			   ,[IsUnique]
			   ,[CheckDate])
		SELECT  ''' + @SQLServer + '''
			   ,''' + @DBName + '''
			   ,[TableName]
			   ,[IndexName]
			   ,[IndexType]
	   		   ,[KeyColumns]
			   ,[HasNonKeyColumns]
			   ,[NonKeyColumns]
			   ,[KeyColumnsOrder]
			   ,[NonKeyColumnsOrder]
			   ,[IsUnique]
			   ,CURRENT_TIMESTAMP
		FROM
		(
		  SELECT DISTINCT 
			 a1.[TableName]
			,a1.[IndexName]
			,a1.[IndexType]
			,a1.[KeyColumns]
			,a1.[HasNonKeyColumns]
			,a1.[NonKeyColumns]
			,a1.[KeyColumnsOrder]
			,a1.[NonKeyColumnsOrder]
			,a1.[IsUnique]
		  FROM #AllIndexesDetailedInfo a1
		  INNER JOIN #AllIndexesDetailedInfo a2 
			ON a1.[TableName] = a2.TableName
			 AND a1.[IndexName] <> a2.[IndexName]
			 AND a1.[KeyColumns] = a2.[KeyColumns]
			 AND ISNULL(a1.[NonKeyColumns], '''') = ISNULL(a2.[NonKeyColumns], '''')
		  WHERE a1.[IndexType] <> ''XML''
		 ) a '

	EXEC (@StringToExecuteP3)
	
	TRUNCATE TABLE #Indexes
	TRUNCATE TABLE #AllIndexesInfo
	TRUNCATE TABLE #AllIndexesDetailedInfo
	
	SET @First = @First + 1 
END

SELECT [Server]
      ,[Database]
      ,[TableName]
      ,[IndexName]
      ,[IndexType]
      ,[KeyColumns]
      ,[NonKeyColumns]
      ,[KeyColumnsOrder]
      ,[NonKeyColumnsOrder]
      ,[IsUnique]
      ,[HasNonKeyColumns]
      ,[CheckDate]
FROM [tempdb].[dbo].[DUPLICATE_INDEXES_INFO]

SET NOCOUNT OFF;

