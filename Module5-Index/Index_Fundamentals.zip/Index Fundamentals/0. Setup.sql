/*
0. Setup
*/

--Run Thinking Big (Adventure) from Adam Machanic
--http://sqlblog.com/blogs/adam_machanic/archive/2011/10/17/thinking-big-adventure.aspx
USE AdventureWorks2014;
GO
SELECT * INTO bigTransactionHistory2 FROM bigTransactionHistory;
GO

SELECT * INTO bigProduct2 FROM bigProduct;

CREATE DATABASE [IndexDemo];
GO
ALTER DATABASE [IndexDemo] SET RECOVERY SIMPLE 
GO
USE [IndexDemo];
GO

CREATE table Heap(ID INT NOT NULL, Number INT NOT NULL IDENTITY);

DECLARE @count INT = 0;
DECLARE @random INT;

WHILE @count < 1000 BEGIN
	SET @random = CAST(RAND() * 1000 +1 AS Int)
	IF NOT EXISTS(SELECT * FROM Heap WHERE ID = @random) BEGIN
		INSERT INTO Heap(ID) 
		SELECT @random;
		SET @count +=1;
	END;
END;


