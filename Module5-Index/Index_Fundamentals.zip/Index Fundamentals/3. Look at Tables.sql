/*
3. Look at clustered index and heap
bigProduct from Adam Machanac 
http://sqlblog.com/blogs/adam_machanic/archive/2011/10/17/thinking-big-adventure.aspx
*/
USE AdventureWorks2014;
GO
--Execution Plan
--Heap
SELECT * 
FROM [dbo].[bigProduct2];
--Clustered index
SELECT * 
FROM [dbo].[bigProduct];