/*
9. SARGability
*/
USE AdventureWorks2014;
GO

SELECT LastName, FirstName 
FROM Person.Person
WHERE LastName = 'Smith';


SELECT LastName, FirstName 
FROM Person.Person
WHERE LEFT(LastName,1) = 'S';

--Better to do this:
SELECT LastName, FirstName 
FROM Person.Person
WHERE LastName LIKE 'S%';


--But this is not so good
SELECT FirstName, LastName
FROM Person.Person 
WHERE LastName LIKE '%mith';


SELECT FirstName, LastName 
FROM Person.Person 
WHERE LastName NOT LIKE 'Smit%';


SELECT FirstName, LastName 
FROM Person.Person 
WHERE LastName not like 'smith';


SELECT FirstName, LastName 
FROM Person.Person 
WHERE Firstname = 'Kevin';


CREATE TABLE #conversion(ID varchar(10));

insert into #conversion
select object_id 
from sys.objects;

select * from #conversion
create index ix_test on #conversion(id);
GO
DECLARE @ID INT;
SET @ID = 3;

SELECT ID 
FROM #conversion 
where ID = @id;
Go
DECLARE @ID VARCHAR(10);
SET @ID = 3;

SELECT ID 
FROM #conversion 
where ID = @id;