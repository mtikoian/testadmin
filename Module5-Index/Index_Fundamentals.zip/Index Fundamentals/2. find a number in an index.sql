/*
2. Find the number in an index
*/
USE IndexDemo;
GO
--pick a random number 
DECLARE @maxNumber INT = 1000000;
DECLARE @myNumber INT = CAST(RAND() * @maxNumber + 1 AS INT);
SELECT  'The number is ' + cast(@myNumber as varchar(10));

DECLARE @guess INT = @maxNumber/2;
DECLARE @highGuess INT = @maxNumber;
DECLARE @lowGuess INT = 1;
DECLARE @guessCount INT = 1;

WHILE @guess <> @myNumber BEGIN
	IF @myNumber > @guess BEGIN
		set @lowGuess = @guess; 
		SET @guess = (@highGuess + @guess)/2;
	END
	ELSE BEGIN 
		SET @highGuess = @guess;
		SET @guess = (@lowGuess + @guess)/2;
	END
	SET @guessCount += 1;
	Print @guess;
END;  
SELECT 'I found the number in ' + CAST(@guessCount AS VARCHAR) + ' guesses!';

