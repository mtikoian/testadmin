/*
7. Column order
*/

USE AdventureWorks2014;
GO
SET STATISTICS IO ON;
GO
EXEC sp_helpindex 'Person.Person';
GO

SELECT LastName, FirstName, MiddleName 
FROM Person.Person
WHERE LastName = 'Adams';

SELECT LastName, FirstName, MiddleName 
FROM Person.Person
WHERE FirstName = 'Amanda';

