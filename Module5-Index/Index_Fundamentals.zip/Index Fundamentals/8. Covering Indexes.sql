/*
8. Covering indexes
*/
USE AdventureWorks2014;
GO

SET STATISTICS IO ON;
GO

--create a demo table
IF OBJECT_ID('dbo.DEMO_SalesDetail') IS NOT NULL 
	DROP TABLE dbo.DEMO_SalesDetail;

SELECT * INTO dbo.DEMO_SalesDetail FROM Sales.SalesOrderDetail ;
--Since no clustered index, adding a primary key will create it
ALTER TABLE dbo.DEMO_SalesDetail ADD PRIMARY KEY 
	(SalesOrderID, SalesOrderDetailID)
   
 
SET STATISTICS IO ON;
--Turn on execution plan
SELECT SalesOrderID, ProductID
FROM dbo.DEMO_SalesDetail
WHERE ProductID = 919;


--Add the index
CREATE NONCLUSTERED INDEX NDX_DEMO_SalesDetail ON 
	dbo.DEMO_SalesDetail (ProductID);

SELECT SalesOrderID, ProductID
FROM dbo.DEMO_SalesDetail
WHERE ProductID = 919;

--Key lookup
SELECT SalesOrderID, ProductID, OrderQty  
FROM dbo.DEMO_SalesDetail 
WHERE ProductID = 919;

DROP INDEX NDX_DEMO_SalesDetail ON dbo.DEMO_SalesDetail;

--One index that works for all values
CREATE NONCLUSTERED INDEX NDX_DEMO_SalesDetail
ON dbo.DEMO_SalesDetail (ProductID) INCLUDE(OrderQty);

SELECT SalesOrderID, SalesOrderDetailID,
	ProductID, OrderQty  
FROM dbo.DEMO_SalesDetail 
WHERE ProductID = 919;

