/*
4. Search tables
*/
--Execution plan
SET STATISTICS IO ON;
SET STATISTICS TIME ON;
GO
USE AdventureWorks2014;
GO
--don't do this at home or at work
DBCC DROPCLEANBUFFERS;

SELECT * 
FROM bigTransactionHistory
WHERE TransactionID = 42;

SELECT * 
FROM bigTransactionHistory2
WHERE TransactionID = 42;

