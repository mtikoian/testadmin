/*
5. Look at some nonclustered indexes
*/

--Index dialog
--Script out

USE AdventureWorks2014;
GO

EXEC sp_helpindex 'Production.Product';


SELECT ProductID 
FROM dbo.bigTransactionHistory
WHERE ProductID = 1001;