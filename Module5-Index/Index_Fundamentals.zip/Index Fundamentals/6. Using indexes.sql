/*
6. Indexes in action
*/

--Tools: Execution plan and Statistics IO
USE AdventureWorks2014;
GO
SET STATISTICS IO ON;
GO
USE AdventureWorks2014;
GO

SELECT * 
FROM Production.Product;

SELECT * 
FROM Production.Product 
WHERE ProductID = 864;

SELECT Name 
FROM Production.Product 
WHERE Name = 'ML Road Frame - Red, 48';

SELECT Color
FROM Production.Product 
WHERE Color = 'Blue';