/*
1. Find a number in a heap
*/

USE IndexDemo;
GO
--find a value in a HEAP
DECLARE @myNumber INT = CAST(RAND() * 1000 + 1 AS INT) ;
DECLARE @guess INT; 
DECLARE @guessCount INT = 0

SELECT  'The number is ' + CAST(@myNumber AS VARCHAR);
DECLARE Numbers CURSOR FAST_FORWARD FOR
	SELECT ID FROM Heap;
OPEN Numbers;
FETCH NEXT FROM Numbers INTO @guess; 
WHILE @myNumber <> @guess BEGIN 
	SET @guessCount += 1; 
	FETCH NEXT FROM Numbers INTO @guess;
	PRINT @guess;
END 
SELECT 'I found the number in ' + CAST(@guessCount AS VARCHAR) + ' guesses!'
	
CLOSE Numbers;
DEALLOCATE Numbers;