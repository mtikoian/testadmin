SET STATISTICS IO ON
GO

DBCC freeproccache
go
--NOTE: this query is actually covered by a tight NC index on ProductKey!!
SELECT d.CalendarYear,
      d.CalendarQuarter,
      COUNT(*) AS NumberSold
--  FROM dbo.FactResellerSalesPartCCSI AS f
  FROM dbo.FactResellerSalesPart AS f
      JOIN dbo.DimDate AS d
      ON f.OrderDateKey = d.DateKey
--  WHERE ProductKey = 548 --some
--  WHERE ProductKey = 256 --very few
--  WHERE ProductKey = 471 --quite a bit
  GROUP BY d.CalendarYear, d.CalendarQuarter
  ORDER BY d.CalendarYear, d.CalendarQuarter
--OPTION (MAXDOP 1) --disables Batch Mode Processing
OPTION (MAXDOP 2) --shows just how awesome BMP is!!

NO WHERE clause, cold cache: COLUMN store = 2 SECONDS, NO COLUMN store = 57 seconds


DBCC freeproccache
go
--DBCC DROPCLEANBUFFERS
go
SELECT d.CalendarYear,
      d.CalendarQuarter,
      COUNT(*) AS NumberSold, 
      SUM(SalesAmount) AS TotalSales --forces a hit on fact table
--  FROM dbo.FactResellerSalesPartCCSI AS f
  FROM dbo.FactResellerSalesPart AS f
      JOIN dbo.DimDate AS d
      ON f.OrderDateKey = d.DateKey
--  WHERE ProductKey = 548 --some
--  WHERE ProductKey = 256 --very few
--  WHERE ProductKey = 471 --quite a bit
  GROUP BY d.CalendarYear, d.CalendarQuarter
  ORDER BY d.CalendarYear, d.CalendarQuarter
--OPTION (MAXDOP 1) --disables Batch Mode Processing, EVEN IN 2014 CCSI!
OPTION (MAXDOP 2) --shows just how awesome BMP is!!


