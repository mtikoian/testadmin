/****************************************************
Batch Execution Mode - not used on UNIONs
Workaround
****************************************************/

USE AdventureworksDW2008_4M
go
SET STATISTICS IO ON
GO

-- Show difference between BATCH processing and ROW processing
-- First ROW - BATCH processing not supported with OUTER JOINs
-- Show CPU usage and data skew issue here too
SELECT P.EnglishPromotionName, -- 14 sec
   COALESCE(SUM(F.ExtendedAmount), 0) AS TotalSales
   FROM dbo.DimPromotion AS P
   LEFT OUTER JOIN dbo.FactResellerSalesPartCCSI AS F --got ROW MODE here in 2012 on NCCSI!
      ON P.PromotionKey = F.PromotionKey
      AND F.OrderDateKey >= 20040101
   GROUP BY P.EnglishPromotionName;

--And had to do this workaround because of that limitation

-- BATCH processing - this is an INNER JOIN - different results than above, but a reasonable comparison
SELECT P.EnglishPromotionName,
   COALESCE(SUM(F.ExtendedAmount), 0) AS TotalSales
   FROM dbo.DimPromotion AS P
   JOIN dbo.FactResellerSalesPart AS F
      ON P.PromotionKey = F.PromotionKey
      AND F.OrderDateKey >= 20040101
   GROUP BY P.EnglishPromotionName;

-- Workaround to use INNER JOIN on large data set, then OUTER JOIN on much smaller
WITH GroupedSales AS (SELECT P.PromotionKey,
   COALESCE(SUM(F.ExtendedAmount), 0) AS TotalSales
   FROM dbo.DimPromotion AS P
   JOIN dbo.FactResellerSalesPart AS F
      ON P.PromotionKey = F.PromotionKey
      AND F.OrderDateKey >= 20040101
   GROUP BY P.PromotionKey
)SELECT P.EnglishPromotionName,
   COALESCE(G.TotalSales, 0)
   FROM dbo.DimPromotion AS P
   LEFT OUTER JOIN GroupedSales AS G
      ON P.PromotionKey = G.PromotionKey
   ORDER BY P.EnglishPromotionName;
