/*
	1. Index Fragmentation Report
*/
USE AdventureWorksLT2012
GO
-- sys.dm_db_index_physical_sts DMV
select * from sys.dm_db_index_physical_stats(db_id(),null,null,null,'LIMITED');

GO
-- Join the DMV to system views to obtain more information.
-- Why is Pagecount relevant?
	-- Low number of pages will never defragment.
	-- Very high pagecount (over 1 million) means consider doing Index Rebuilds only.
select sch.name as SchemaName,
	st.name as TableName,
	si.name as IndexName,
	ips.partition_number,
	ips.index_type_desc,
	ips.avg_fragmentation_in_percent,
	ips.page_count
from sys.dm_db_index_physical_stats(db_id(),null,null,null,'LIMITED') ips
join sys.tables st
	on ips.object_id = st.object_id
join sys.schemas sch
	on st.schema_id = sch.schema_id
join sys.indexes si
	on ips.object_id = si.object_id
	and ips.index_id = si.index_id
where st.is_ms_shipped = 0;

-- Quick Pagecount
select sch.name as SchemaName,st.name as TableName,si.name as IndexName,
ps.partition_number,ps.reserved_page_count,ps.row_count
from sys.dm_db_partition_stats ps
join sys.tables st
	on ps.object_id = st.object_id
join sys.schemas sch
	on st.schema_id = sch.schema_id
join sys.indexes si
	on ps.object_id = si.object_id
	and ps.index_id = si.index_id
where st.is_ms_shipped = 0;

/*
	2. Fill Factor
*/
USE IndexMaintenanceDemo
GO

-- Drop index if it exists.
if exists (
	select * from sys.indexes si
		join sys.tables st
			on si.object_id = st.object_id
	where si.name = 'IX_FillFactorTest_String1' and st.name = 'FillFactorTest')
begin
	DROP INDEX IX_FillFactorTest_String1 ON dbo.FillFactorTest
end

-- Truncate the table
truncate table dbo.FillFactorTest

-- Import data into the FillFactorTest table.
-- Review its fragmentation.
select object_name(object_id),avg_fragmentation_in_percent 
from sys.dm_db_index_physical_stats(db_id(),object_id('FillFactorTest'),null,null,'LIMITED');

-- Create Index
CREATE NONCLUSTERED INDEX IX_FillFactorTest_String1 ON dbo.FillFactorTest
(
	String1
)

-- Review its fragmentation.
select object_name(object_id),avg_fragmentation_in_percent 
from sys.dm_db_index_physical_stats(db_id(),object_id('FillFactorTest'),null,null,'LIMITED');


-- Insert 10,000 records.
insert dbo.FillFactorTest (
	String1,
	String2,
	Integer1,
	Integer2,
	Date1
)
select top 10000 String1,
	String2,
	Integer1,
	Integer2,
	Date1
from dbo.FillFactorTest

-- Review fragmentation again.
select object_name(ips.object_id) as TableName,si.name as IndexName,avg_fragmentation_in_percent 
from sys.dm_db_index_physical_stats(db_id(),object_id('FillFactorTest'),null,null,'LIMITED') ips
join sys.indexes si
on ips.object_id = si.object_id and ips.index_id = si.index_id;

-- Rebuild index.
ALTER INDEX IX_FillFactorTest_String1 ON dbo.FillFactorTest REBUILD WITH (FILLFACTOR=90);

-- Review fragmentation again.
select object_name(ips.object_id) as TableName,si.name as IndexName,avg_fragmentation_in_percent 
from sys.dm_db_index_physical_stats(db_id(),object_id('FillFactorTest'),null,null,'LIMITED') ips
join sys.indexes si
on ips.object_id = si.object_id and ips.index_id = si.index_id;

-- Insert 10,000 records.
insert dbo.FillFactorTest (
	String1,
	String2,
	Integer1,
	Integer2,
	Date1
)
select top 10000 String1,
	String2,
	Integer1,
	Integer2,
	Date1
from dbo.FillFactorTest

-- Review fragmentation again.
select object_name(ips.object_id) as TableName,si.name as IndexName,avg_fragmentation_in_percent 
from sys.dm_db_index_physical_stats(db_id(),object_id('FillFactorTest'),null,null,'LIMITED') ips
join sys.indexes si
on ips.object_id = si.object_id and ips.index_id = si.index_id;

/*
	3. Rebuild vs. Reorganize syntax.
*/
ALTER INDEX IX_FillFactorTest_String1 on dbo.FillFactorTest REBUILD;
ALTER INDEX IX_FillFactorTest_String1 on dbo.FillFactorTest REBUILD WITH (ONLINE=ON);

ALTER INDEX PK_LobTest on dbo.LobTest REBUILD WITH(ONLINE=ON);	-- Fails

ALTER INDEX IX_FillFactorTest_String1 on dbo.FillFactorTest REORGANIZE;

select * from sys.indexes where name = 'IX_FillFactorTest_String1';

/*
	4. Stats Update
*/
UPDATE STATISTICS dbo.FillFactorTest

exec sp_updatestats

/*
	5. Maintenance Plans.
			Pros:
				a. Easy to setup.
				b. 2012 has fixed Online rebuilds.
			Cons:
				a. Maintains everything.
				b. No good visibility on how it works.
				c. Fill Factor option is somewhat confusing.
				d. Stats maintenance Sample options are not good.
*/

-- No scripts needed for Maintenance Plans.

/*
	6. Microsoft's Script.
			Pros:
				a. Easy to setup.
				b. Only maintains indexes that are fragmented.
				c. Supports partition level index maintenance.
			Cons:
				a. No online indexing capability.
				b. Stats maintenance not included.
*/
USE AdventureWorksLT2012
GO
-- Ensure a USE <databasename> statement has been executed first.
SET NOCOUNT ON;
DECLARE @objectid int;
DECLARE @indexid int;
DECLARE @partitioncount bigint;
DECLARE @schemaname nvarchar(130); 
DECLARE @objectname nvarchar(130); 
DECLARE @indexname nvarchar(130); 
DECLARE @partitionnum bigint;
DECLARE @partitions bigint;
DECLARE @frag float;
DECLARE @command nvarchar(4000); 
-- Conditionally select tables and indexes from the sys.dm_db_index_physical_stats function 
-- and convert object and index IDs to names.
SELECT
    object_id AS objectid,
    index_id AS indexid,
    partition_number AS partitionnum,
    avg_fragmentation_in_percent AS frag
INTO #work_to_do
FROM sys.dm_db_index_physical_stats (DB_ID(), NULL, NULL , NULL, 'LIMITED')
WHERE avg_fragmentation_in_percent > 10.0 AND index_id > 0;

-- Declare the cursor for the list of partitions to be processed.
DECLARE partitions CURSOR FOR SELECT * FROM #work_to_do;

-- Open the cursor.
OPEN partitions;

-- Loop through the partitions.
WHILE (1=1)
    BEGIN;
        FETCH NEXT
           FROM partitions
           INTO @objectid, @indexid, @partitionnum, @frag;
        IF @@FETCH_STATUS < 0 BREAK;
        SELECT @objectname = QUOTENAME(o.name), @schemaname = QUOTENAME(s.name)
        FROM sys.objects AS o
        JOIN sys.schemas as s ON s.schema_id = o.schema_id
        WHERE o.object_id = @objectid;
        SELECT @indexname = QUOTENAME(name)
        FROM sys.indexes
        WHERE  object_id = @objectid AND index_id = @indexid;
        SELECT @partitioncount = count (*)
        FROM sys.partitions
        WHERE object_id = @objectid AND index_id = @indexid;

-- 30 is an arbitrary decision point at which to switch between reorganizing and rebuilding.
        IF @frag < 30.0
            SET @command = N'ALTER INDEX ' + @indexname + N' ON ' + @schemaname + N'.' + @objectname + N' REORGANIZE';
        IF @frag >= 30.0
            SET @command = N'ALTER INDEX ' + @indexname + N' ON ' + @schemaname + N'.' + @objectname + N' REBUILD';
        IF @partitioncount > 1
            SET @command = @command + N' PARTITION=' + CAST(@partitionnum AS nvarchar(10));
        EXEC (@command);
        PRINT N'Executed: ' + @command;
    END;

-- Close and deallocate the cursor.
CLOSE partitions;
DEALLOCATE partitions;

-- Drop the temporary table.
DROP TABLE #work_to_do;
GO

/*
	7. Ola Hallengren's Scripts
			Pros:
				a. Highly configurable with lots of options.
				b. Free!
				c. Online rebuilds are maintained how you specify.
				d. Supports partition level maintenance.
				e. Supports logging.
				f. Only maintains fragmented indexes.
				g. Configurable Stats Maintenance.
			Cons:
				a. Database objects need to be created somewhere (stored procedures and log table).

		CommandLog.sql - This creates a table that logs index maintenance data.
		CommandExecute.sql - This is a helper stored procedure that is used to write to the CommandLog table.
		IndexOptimize.sql - This is the main script for the Index Maintenance System.
*/

/*
	Paramters:
				Databases,
				FragmentationLow, FragmentationMedium, FragmentationHigh,
				FragmentationLevel1, FragmentationLevel2,
				PageCountLevel,
				SortInTempDB,
				MaxDOP,
				FillFactor,
				PadIndex,
				LOBCompaction,
				UpdateStatistics,OnlyModifiedStatistics,
				StatisticsSample,StatisticsResample,
				PartitionLevel,
				TimeLimit,
				Indexes,
				Delay,
				LogToTable,
				Execute
*/
USE IndexMaintenanceDemo
GO

exec dbo.IndexOptimize @Databases = 'USER_DATABASES',
	@FragmentationMedium='INDEX_REORGANIZE',
	@FragmentationHigh = 'INDEX_REBUILD_ONLINE,INDEX_REBUILD_OFFLINE',
	@FragmentationLevel1=5,
	@FragmentationLevel2=30,
	@UpdateStatistics='ALL',
	@OnlyModifiedStatistics='Y',
	@PartitionLevel='Y',
	@LogToTable='Y'

select * from dbo.CommandLog
