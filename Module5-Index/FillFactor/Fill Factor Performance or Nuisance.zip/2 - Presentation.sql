/************************
Fill Factor: Performance or Nuisance?
Created: 12/9/2013
Description: Presentation for Fill Factor. We will be demonstrating how a modified fill factor changes the outcome of 
the results. This is only to show how things change from default. Inserts and updates may still have a benefit.
************************/

--Let's see how this affects backups. --Time 00:03:05

BACKUP DATABASE [AdventureWorks2012FillFactor70] 
TO  DISK = 
N'C:\Backup\AdventureWorks2012FillFactor70.bak' 
WITH NOFORMAT, NOINIT,  
NAME = N'AdventureWorks2012FillFactor70-Full Database Backup', 
SKIP, NOREWIND, NOUNLOAD,  STATS = 10
GO

BACKUP DATABASE [AdventureWorks2012FillFactor100] 
TO  DISK = 
N'C:\Backup\AdventureWorks2012FillFactor100.bak' 
WITH NOFORMAT, NOINIT,  
NAME = N'AdventureWorks2012FillFactor100-Full Database Backup', 
SKIP, NOREWIND, NOUNLOAD,  STATS = 10
GO

BACKUP DATABASE  [ContosoRetailDWFillFactor70]
TO  DISK = 
N'C:\Backup\ContosoRetailDWFillFactor70.bak' 
WITH NOFORMAT, NOINIT,  
NAME = N'ContosoRetailDWFillFactor70-Full Database Backup', 
SKIP, NOREWIND, NOUNLOAD,  STATS = 10
GO

BACKUP DATABASE  [ContosoRetailDWFillFactor100]
TO  DISK = 
N'C:\Backup\ContosoRetailDWFillFactor100.bak' 
WITH NOFORMAT, NOINIT,  
NAME = N'ContosoRetailDWFillFactor100-Full Database Backup', 
SKIP, NOREWIND, NOUNLOAD,  STATS = 10
GO

--Now to see how much space is lost just to a fill factor change -Time 00:00:00
--The below script is a modification of a part of Glenn Berry's SQL Server Diagnostic Queries
--http://sqlserverperformance.wordpress.com/2013/11/15/sql-server-diagnostic-information-queries-for-november-2013/

SELECT TOP (4) bs.database_name AS [Database Name], 
CONVERT (BIGINT, bs.backup_size / 1048576 ) AS [Uncompressed Backup Size (MB)],
CONVERT (BIGINT, bs.compressed_backup_size / 1048576 ) AS [Compressed Backup Size (MB)],
CONVERT (NUMERIC (20,2), (CONVERT (FLOAT, bs.backup_size) /
CONVERT (FLOAT, bs.compressed_backup_size))) AS [Compression Ratio], 
DATEDIFF (SECOND, bs.backup_start_date, bs.backup_finish_date) AS [Backup Elapsed Time (sec)],
bs.backup_finish_date AS [Backup Finish Date]
FROM msdb.dbo.backupset AS bs WITH (NOLOCK)
WHERE DATEDIFF (SECOND, bs.backup_start_date, bs.backup_finish_date) > 0 
AND bs.backup_size > 0
AND bs.type = 'D' -- Change to L if you want Log backups
ORDER BY bs.backup_finish_date DESC OPTION (RECOMPILE);

--First sight shows that your normal backups alone are going to be larger. 
--With compression the size may be smaller, but the ratio is roughly the same.

--What does that do to our reads? Note: SSD's show less impact than spinning disk

set statistics IO ON
set statistics time on

DBCC DROPCLEANBUFFERS
DBCC FREEPROCCACHE
DBCC FREESESSIONCACHE
DBCC FREESYSTEMCACHE ('all')


select * from AdventureWorks2012FillFactor70.person.person
/*

(19972 row(s) affected)
Table 'Person'. Scan count 1, logical reads 3859, physical reads 3, read-ahead reads 3884, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.

 SQL Server Execution Times:
   CPU time = 62 ms,  elapsed time = 2156 ms.

*/

DBCC DROPCLEANBUFFERS
DBCC FREEPROCCACHE
DBCC FREESESSIONCACHE
DBCC FREESYSTEMCACHE ('all')

select * from AdventureWorks2012FillFactor100.person.person
/*

(19972 row(s) affected)
Table 'Person'. Scan count 1, logical reads 3820, physical reads 2, read-ahead reads 3826, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.

 SQL Server Execution Times:
   CPU time = 78 ms,  elapsed time = 1669 ms.

   */

DBCC DROPCLEANBUFFERS
DBCC FREEPROCCACHE
DBCC FREESESSIONCACHE
DBCC FREESYSTEMCACHE ('all')

select * from ContosoRetailDWFillFactor100.dbo.FactOnlineSales --Time 00:02:36
--good time for any questions

/*

(12627608 row(s) affected)
Table 'FactOnlineSales'. Scan count 1, logical reads 46535, physical reads 2, read-ahead reads 46524, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.

 SQL Server Execution Times:
   CPU time = 17238 ms,  elapsed time = 138565 ms.

*/

DBCC DROPCLEANBUFFERS
DBCC FREEPROCCACHE
DBCC FREESESSIONCACHE
DBCC FREESYSTEMCACHE ('all')

select * from ContosoRetailDWFillFactor70.dbo.FactOnlineSales  --Time 00:02:23
--good time for any questions

/*

(12627608 row(s) affected)
Table 'FactOnlineSales'. Scan count 1, logical reads 62518, physical reads 1, read-ahead reads 63406, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.

 SQL Server Execution Times:
   CPU time = 18704 ms,  elapsed time = 136003 ms.

*/