select sch.name as SchemaName, tbl.name as TableName, idx.name as IndexName,
ips.page_count as Pages, 1.0*record_count/page_count as Ratio , ips.record_count as RecordCount, 
ips.avg_record_size_in_bytes, ips.max_record_size_in_bytes
--,ips.index_type_desc, ips.alloc_unit_type_desc, idx.fill_factor, fg.name as FileGroup, ips.partition_number, compressed_page_count
from sys.dm_db_index_physical_stats (db_id(),null,null,null,'detailed') ips
inner join sys.indexes as idx on idx.object_id = ips.object_id
and idx.index_id = ips.index_id
inner join sys.tables as tbl on tbl.object_id = ips.object_id
inner join sys.schemas as sch on sch.schema_id = tbl.schema_id
inner join sys.filegroups as fg on fg.data_space_id = idx.data_space_id
where page_count > 0
and record_count > 1000
and index_level = 0