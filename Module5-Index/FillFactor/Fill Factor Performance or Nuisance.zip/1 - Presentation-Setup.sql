/************************
Fill Factor: Performance or Nuisance?
Created: 12/9/2013
Description: Here we will create the environment we need to recreate this presentation.
Adventureworks database is located at http://msftdbprodsamples.codeplex.com/downloads/get/417885
Contoso Retail is located at http://www.microsoft.com/en-us/download/details.aspx?id=18279

Note:

Please correct from and to locations during the restore to where you have these files loaded.

************************/

--First, Let's make sure nothing is left over from an earlier run.

--time 00:02:07 to 5400 USB Drive

set statistics IO OFF
set statistics time OFF

USE [master]
GO

DROP DATABASE [ContosoRetailDWFillFactor70]
GO

DROP DATABASE [ContosoRetailDWFillFactor100]
GO

DROP DATABASE [AdventureWorks2012FillFactor70]
GO

DROP DATABASE [AdventureWorks2012FillFactor100]
GO

DBCC DROPCLEANBUFFERS
DBCC FREEPROCCACHE
DBCC FREESESSIONCACHE
DBCC FREESYSTEMCACHE ('all')

--Let's restore these databases fresh.

USE [master]
RESTORE DATABASE [AdventureWorks2012FillFactor70] 
FROM  DISK = N'C:\Databases\AdventureWorks2012-Full Database Backup.bak'
WITH  FILE = 1,  MOVE N'AdventureWorks2012_Data' 
TO N'C:\databases\AdventureWorks2012FillFactor70_Data.mdf',  
MOVE N'AdventureWorks2012_Log' TO N'C:\databases\AdventureWorks2012FillFactor70_log.ldf',  
NOUNLOAD,  STATS = 5
GO
USE [master]
RESTORE DATABASE [AdventureWorks2012FillFactor100] 
FROM  DISK = N'C:\Databases\AdventureWorks2012-Full Database Backup.bak'
WITH  FILE = 1,  MOVE N'AdventureWorks2012_Data' 
TO N'C:\databases\AdventureWorks2012FillFactor100_Data.mdf',  
MOVE N'AdventureWorks2012_Log' TO N'C:\databases\AdventureWorks2012FillFactor100_log.ldf',  
NOUNLOAD,  STATS = 5
GO
USE [master]
RESTORE DATABASE [ContosoRetailDWFillFactor100] 
FROM  DISK = N'C:\Databases\ContosoRetailDW.bak' 
WITH  FILE = 1,  MOVE N'ContosoRetailDW2.0' 
TO N'C:\databases\ContosoRetailDWFillFactor100.mdf',  
MOVE N'ContosoRetailDW2.0_log' TO N'C:\databases\ContosoRetailDWFillFactor100.ldf',  
NOUNLOAD,  STATS = 5
GO
USE [master]
RESTORE DATABASE [ContosoRetailDWFillFactor70] 
FROM  DISK = N'C:\Databases\ContosoRetailDW.bak' 
WITH  FILE = 1,  MOVE N'ContosoRetailDW2.0' 
TO N'C:\databases\ContosoRetailDWFillFactor70.mdf',  
MOVE N'ContosoRetailDW2.0_log' TO N'C:\databases\ContosoRetailDWFillFactor70.ldf',  
NOUNLOAD,  STATS = 5
GO
--Now with this done, we can change the fillfactors of these databases to get some good data.

--this will create a script to change the fill factors to 70 for each of the databases labeled 70.

--use [AdventureWorks2012FillFactor70] --time 00:01:06 to 5400 USB Drive

select sch.name AS SchemaName,tbl.name AS TableName,idx.name AS IndexName,ds.name AS Filegroup,
data_compression_desc,total_pages,total_pages*8/1024 AS SizeInMB,max_column_id_used,fill_factor,
'ALTER INDEX [' + idx.name + '] ON [' + Schema_Name(sch.schema_id) +
'].[' + object_Name(idx.object_id) +
'] REBUILD PARTITION = ALL WITH ( FILLFACTOR = 70, ONLINE = ON, SORT_IN_TEMPDB = ON )' as Rebuild
from AdventureWorks2012FillFactor70.sys.partitions p
inner join AdventureWorks2012FillFactor70.sys.allocation_units au  on au.container_id = p.hobt_id
inner join AdventureWorks2012FillFactor70.sys.filegroups fg  on fg.data_space_id = au.data_space_id
inner join AdventureWorks2012FillFactor70.sys.tables tbl on tbl.object_id = p.object_id
inner join AdventureWorks2012FillFactor70.sys.indexes idx on idx.object_id = p.object_id
inner join AdventureWorks2012FillFactor70.sys.schemas sch on sch.schema_id = tbl.schema_id
inner join AdventureWorks2012FillFactor70.sys.data_spaces ds on ds.data_space_id = au.data_space_id
and idx.index_id = p.index_id
where idx.name is not null
order by ds.name, idx.name

--use [ContosoRetailDWFillFactor70] --time 00:04:07 to 5400 USB Drive

select sch.name AS SchemaName,tbl.name AS TableName,idx.name AS IndexName,ds.name AS Filegroup,
data_compression_desc,total_pages,total_pages*8/1024 AS SizeInMB,max_column_id_used,fill_factor,
'ALTER INDEX [' + idx.name + '] ON [' + Schema_Name(sch.schema_id) +
'].[' + object_Name(idx.object_id) +
'] REBUILD PARTITION = ALL WITH ( FILLFACTOR = 70, ONLINE = ON, SORT_IN_TEMPDB = ON )' as Rebuild
from ContosoRetailDWFillFactor70.sys.partitions p
inner join ContosoRetailDWFillFactor70.sys.allocation_units au  on au.container_id = p.hobt_id
inner join ContosoRetailDWFillFactor70.sys.filegroups fg  on fg.data_space_id = au.data_space_id
inner join ContosoRetailDWFillFactor70.sys.tables tbl on tbl.object_id = p.object_id
inner join ContosoRetailDWFillFactor70.sys.indexes idx on idx.object_id = p.object_id
inner join ContosoRetailDWFillFactor70.sys.schemas sch on sch.schema_id = tbl.schema_id
inner join ContosoRetailDWFillFactor70.sys.data_spaces ds on ds.data_space_id = au.data_space_id
and idx.index_id = p.index_id
where idx.name is not null
order by ds.name, idx.name