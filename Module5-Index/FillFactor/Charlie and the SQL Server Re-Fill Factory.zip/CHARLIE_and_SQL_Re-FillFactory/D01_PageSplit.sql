/*
Event: SQL Saturday #347, Washington, DC
Date:  2014-12-06
Topic: Re-FillFactoring
By:    Slava Murygin
Demo:  #1. Page Splits on update

http://slavasql.blogspot.com/
@SlavaSQL
*/
USE master;
GO
IF DB_ID('TestDB') IS NOT NULL 
BEGIN
	ALTER DATABASE [TestDB] SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
	DROP DATABASE [TestDB];
END
GO
CREATE DATABASE [TestDB];
GO
USE [TestDB];
GO
-- Drop Test Table if exists
IF EXISTS ( SELECT TOP 1 1 FROM sys.tables WHERE name = 'tbl_FF_Test')
	DROP TABLE tbl_FF_Test;
GO
-- Create Test Table
CREATE TABLE tbl_FF_Test(
	ID INT 
	CONSTRAINT PK_FF_Test PRIMARY KEY, 
	RNDNumber BIGINT NULL,
	TestText VARCHAR(100) NULL,
);
GO
-- Fill Test records
INSERT INTO tbl_FF_Test(ID) 
SELECT TOP 239470 (ROW_NUMBER() OVER (ORDER BY Message_ID) ) AS RowNumber 
FROM sys.messages, (SELECT 1 as D union SELECT 2) as Doubler;
GO
SELECT TOP 100 * FROM tbl_FF_Test
GO

--------------------------------------------------------------------------------------------------------------------------------
-- #1 - Page Split Demonstration

SELECT ps.index_level, 
	CASE WHEN i.fill_factor = 0 OR (ps.index_level > 0 and i.is_padded = 0) 
	THEN 100 ELSE i.fill_factor END AS fill_factor,
	ROUND(ps.avg_fragmentation_in_percent,3) as [AVG Frgmnt %], 
	ROUND(ps.avg_page_space_used_in_percent,3) as [AVG Space Use %], 
	ps.page_count, 
	ROUND(ps.page_count/128.,3) as Index_Size_Mb,
	ps.record_count, (ps.record_count / ps.page_count) as AVG_Records_per_Page
FROM sys.dm_db_index_physical_stats(DB_ID(), OBJECT_ID('tbl_FF_Test'), NULL, NULL, 'DETAILED') ps 
INNER JOIN sys.indexes i ON i.OBJECT_ID = ps.OBJECT_ID AND i.index_id = ps.index_id;
GO
;WITH PageList AS (
	SELECT a.page_type_desc, a.extent_page_id, a.allocated_page_page_id, a.page_level, a.next_page_page_id, a.previous_page_page_id
	FROM sys.dm_db_database_page_allocations(DB_ID(), OBJECT_ID('tbl_FF_Test'), 1, NULL, 'DETAILED') as a
	--WHERE IsNull(a.page_type_desc,'IAM_PAGE') != 'IAM_PAGE'
), SortedPageList AS (
	SELECT page_type_desc, extent_page_id, allocated_page_page_id, page_level, next_page_page_id, previous_page_page_id, 0 as OrderLevel
	FROM PageList WHERE previous_page_page_id is Null
	UNION ALL
	SELECT ps.page_type_desc, ps.extent_page_id, ps.allocated_page_page_id, ps.page_level, ps.next_page_page_id, ps.previous_page_page_id, sps.OrderLevel + 1
	FROM PageList as ps
	INNER JOIN SortedPageList as sps ON sps.allocated_page_page_id = ps.previous_page_page_id
)
SELECT page_type_desc, OrderLevel,
	 CASE 
		WHEN page_level = 1 THEN 'Root Page'
		WHEN page_type_desc = 'IAM_PAGE' THEN 'IAM Page'
		WHEN page_level = 0 and OrderLevel = 0 THEN 'Page A'
		WHEN page_level = 0 and OrderLevel = 1 THEN 'Page B'
		WHEN page_level = 0 and OrderLevel = 2 THEN 'Page C'
	END as PageCode,
	extent_page_id, allocated_page_page_id, page_level, next_page_page_id, previous_page_page_id
FROM SortedPageList
ORDER BY page_level DESC, OrderLevel
OPTION (MAXRECURSION 32767);
GO
SET STATISTICS IO ON
GO
UPDATE tbl_FF_Test 
SET TestText = 'SQLSaturday'
WHERE ID = 1;
GO
SET STATISTICS IO OFF
-- 11 IOs!!!
GO
SELECT ps.index_level, 
	CASE WHEN i.fill_factor = 0 OR (ps.index_level > 0 and i.is_padded = 0) 
	THEN 100 ELSE i.fill_factor END AS fill_factor,
	ROUND(ps.avg_fragmentation_in_percent,3) as [AVG Frgmnt %], 
	ROUND(ps.avg_page_space_used_in_percent,3) as [AVG Space Use %], 
	ps.page_count, 
	ROUND(ps.page_count/128.,3) as Index_Size_Mb,
	ps.record_count, (ps.record_count / ps.page_count) as AVG_Records_per_Page
FROM sys.dm_db_index_physical_stats(DB_ID(), OBJECT_ID('tbl_FF_Test'), NULL, NULL, 'DETAILED') ps 
INNER JOIN sys.indexes i ON i.OBJECT_ID = ps.OBJECT_ID AND i.index_id = ps.index_id;
GO
;WITH PageList AS (
	SELECT a.page_type_desc, a.extent_page_id, a.allocated_page_page_id, a.page_level, a.next_page_page_id, a.previous_page_page_id
	FROM sys.dm_db_database_page_allocations(DB_ID(), OBJECT_ID('tbl_FF_Test'), 1, NULL, 'DETAILED') as a
	--WHERE IsNull(a.page_type_desc,'IAM_PAGE') != 'IAM_PAGE'
), SortedPageList AS (
	SELECT page_type_desc, extent_page_id, allocated_page_page_id, page_level, next_page_page_id, previous_page_page_id, 0 as OrderLevel
	FROM PageList WHERE previous_page_page_id is Null
	UNION ALL
	SELECT ps.page_type_desc, ps.extent_page_id, ps.allocated_page_page_id, ps.page_level, ps.next_page_page_id, ps.previous_page_page_id, sps.OrderLevel + 1
	FROM PageList as ps
	INNER JOIN SortedPageList as sps ON sps.allocated_page_page_id = ps.previous_page_page_id
)
SELECT TOP 8 page_type_desc, OrderLevel,
	 CASE 
		WHEN page_type_desc = 'IAM_PAGE' THEN 'IAM Page'
		WHEN page_level = 2 THEN 'Root Page'
		WHEN page_level = 1 and OrderLevel = 0 THEN 'Intermediate Index Page 1'
		WHEN page_level = 1 and OrderLevel = 1 THEN 'Intermediate Index Page 2'
		WHEN page_level = 0 and OrderLevel = 0 THEN 'Page A'
		WHEN page_level = 0 and OrderLevel = 1 THEN 'Page AA'
		WHEN page_level = 0 and OrderLevel = 2 THEN 'Page B'
		WHEN page_level = 0 and OrderLevel = 3 THEN 'Page C'
	END as PageCode,
	extent_page_id, allocated_page_page_id, page_level, next_page_page_id, previous_page_page_id
FROM SortedPageList
ORDER BY page_level DESC, OrderLevel
OPTION (MAXRECURSION 32767);
GO
--------------------------------------------------------------------------------------------------------------------------------
-- ? What is FF ?

SET STATISTICS IO ON
GO
-- 12 IOs!!!
UPDATE tbl_FF_Test 
SET TestText = 'SQLSaturday'
WHERE ID = 501;
GO
-- 3 IOs!!!
UPDATE tbl_FF_Test 
SET TestText = 'SQLSaturday'
WHERE ID = 2;
GO
SET STATISTICS IO OFF
--------------------------------------------------------------------------------------------------------------------------------
