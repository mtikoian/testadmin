/*
Event: SQL Saturday #347, Washington, DC
Date:  2014-12-06
Topic: Re-FillFactoring
By:    Slava Murygin
Demo:  #6. Finding the Golden Ticket 

http://slavasql.blogspot.com/
@SlavaSQL
*/
Use TestFF
GO
/*
Script to make a determination if Fill Factor has to be lovered.
Very important to follow steps below:

1. Determine maintenance period - that can be a daily, weekly or bi-weekly;

2. Rebuild ALL Indexes - 
   - For SQL Server Standard Edition you cannot rebuild indexes online;
   - For Small tables you can use Index Reorganize - it is always Online, but slower;
   - For SQL Server 2014 you can use options: WAIT_AT_LOW_PRIORITY, MAX_DURATION, AND ABORT_AFTER_WAIT;

3. Schedule the Re-Fillfactoring script;
   - Determine the time when Server/Database is less busy;
   - Determine Fillfactor rebuilding options, such as threshold of fragmentation, proposed FillFactor percentage lovering.
	 Also: PAD_INDEX, ONLINE or Index REBUILD/REORGANIZE;

4. Monitor results:
   - You can specify to store results of FillFactor determination script into a table;
   - Keep an eye on tables with biggest fragmentation and lowest FillFactor;
   - You can turn off FillFactor lovering after you be sure your indexes in a good shape.

5. Do not forget to enable "ALTER INDEX" script execution at the bottom of the script.
*/
DECLARE @Lover_FF_Min_Decision DECIMAL = 1;			-- Minimum Gain Decision. 
													-- All indexes above that number will have their FF decreased
													-- All indexes below that number will be just rebuilt (if necesary)
DECLARE @Lover_FF_Percent TINYINT = 1;				-- Fill Factor decrease percentage.
DECLARE @Minimum_Fragmentation_Percent TINYINT = 5;	-- Indexes will be concidered for fragmentation or index rebuilt only if they have fragmentation above that level
DECLARE @PAD_INDEX NVARCHAR(3) = 'ON';				-- Specifies if PAD_INDEX is ON/OFF for FF change
DECLARE @ONLINE_REBUILD NVARCHAR(3) = 'ON';			-- Specifies if Index has to be accessible during the rebuild. "ON" - accessible / "OFF" is not
DECLARE @SQLCMD VARCHAR(8000);						-- Dynamic SQL variable

;WITH DB_STATS AS (
	SELECT TOP 5000
		OBJECT_SCHEMA_NAME(ps.object_id) as SchemaName,
		OBJECT_NAME(ps.object_id) as TableName, 
		i.name as IndexName, 
		i.index_id, 
		CASE i.fill_factor WHEN 0 THEN 100 ELSE i.fill_factor END as fill_factor,
		CASE i.fill_factor WHEN 0 THEN 100 ELSE i.fill_factor END - 
			CASE WHEN i.fill_factor > @Lover_FF_Percent THEN @Lover_FF_Percent ELSE 0 END as Proposed_fill_factor,

		CAST(ROUND(ps.avg_fragmentation_in_percent,3) as Decimal(9,3)) as avg_fragmentation_in_percent, 
		ps.fragment_count, 
		ps.record_count,
		ps.page_count, 

		CAST(ROUND(ps.avg_page_space_used_in_percent,3) as Decimal(9,3)) as avg_page_space_used_in_percent, 
		CAST(ROUND(ps.page_count / 128.,3) as Decimal(9,3)) AS Allocated_Space_Mb,
		CAST(ROUND(ps.page_count * ps.avg_page_space_used_in_percent / 12800.,3) as Decimal(9,3)) as Real_Space_Used_Mb,
		CAST(ROUND(ps.page_count * (100 - ps.avg_page_space_used_in_percent) / 12800.,3) as Decimal(9,3)) as Reserved_Space_Mb,

		CAST(ROUND((ps.page_count * ps.avg_page_space_used_in_percent) / 128
		/ (CASE i.fill_factor WHEN 0 THEN 100 ELSE i.fill_factor END - 
			CASE WHEN i.fill_factor > @Lover_FF_Percent THEN @Lover_FF_Percent ELSE 0 END),3) as Decimal(9,3)) as Proposed_Size_Mb,

		CAST(ROUND(100 - ps.avg_page_space_used_in_percent * 100
		/ (CASE i.fill_factor WHEN 0 THEN 100 ELSE i.fill_factor END),3) as Decimal(9,3)) as Current_Space_Overuse_Percent,

		CAST(ROUND(100 - ps.avg_page_space_used_in_percent * 100
		/ (CASE i.fill_factor WHEN 0 THEN 100 ELSE i.fill_factor END - 
			CASE WHEN i.fill_factor > @Lover_FF_Percent THEN @Lover_FF_Percent ELSE 0 END),3) as Decimal(9,3)) as Proposed_Space_Gain_Percent

		
	FROM sys.dm_db_index_physical_stats(DB_ID(), NULL, NULL, NULL, 'SAMPLED') ps 
	INNER JOIN sys.indexes i ON i.OBJECT_ID = ps.OBJECT_ID AND i.index_id = ps.index_id 
	WHERE ps.page_count > 1 and ps.avg_fragmentation_in_percent > 0
)
SELECT TableName, IndexName
	, index_id
	, fill_factor
	, CASE WHEN page_count * Proposed_Space_Gain_Percent * 10 / ( SELECT AVG(page_count) * AVG(avg_fragmentation_in_percent) FROM DB_STATS ) >= @Lover_FF_Min_Decision
		THEN Proposed_fill_factor ELSE fill_factor END AS Proposed_fill_factor
	, avg_fragmentation_in_percent
	, fragment_count
	, record_count
	, page_count
	, avg_page_space_used_in_percent
	, Allocated_Space_Mb
	, Real_Space_Used_Mb
	, Reserved_Space_Mb
	, Proposed_Size_Mb
	, Current_Space_Overuse_Percent
	, Proposed_Space_Gain_Percent
	, CAST(Real_Space_Used_Mb * 100 / Proposed_fill_factor as NUMERIC(18,3)) as Space_Prediction_Mb
	, CAST(Allocated_Space_Mb * Proposed_Space_Gain_Percent / 100 as NUMERIC(18,3)) AS Real_Space_Gain_Prediction_Mb
	, CAST(page_count * Proposed_Space_Gain_Percent * 10 / ( SELECT AVG(page_count) * AVG(avg_fragmentation_in_percent) FROM DB_STATS ) as NUMERIC(18,3)) as GainDecision
FROM DB_STATS
WHERE avg_fragmentation_in_percent > @Minimum_Fragmentation_Percent
ORDER BY Real_Space_Gain_Prediction_Mb DESC;

--==============================================================================================================================
-- Here is code to do the change:
--==============================================================================================================================
DECLARE ReFillFactor CURSOR FAST_FORWARD FOR
WITH DB_STATS AS (
	SELECT 
		OBJECT_SCHEMA_NAME(ps.object_id) as SchemaName,
		OBJECT_NAME(ps.object_id) as TableName, 
		i.name as IndexName, 
		i.index_id, 
		Proposed_fill_factor = CASE i.fill_factor WHEN 0 THEN 100 ELSE i.fill_factor END - 
			CASE WHEN i.fill_factor > @Lover_FF_Percent THEN @Lover_FF_Percent ELSE 0 END,

		ps.avg_fragmentation_in_percent, 
		ps.page_count, 

		Proposed_Space_Gain_Percent = 100 - ps.avg_page_space_used_in_percent * 100
		/ (CASE i.fill_factor WHEN 0 THEN 100 ELSE i.fill_factor END - 
			CASE WHEN i.fill_factor > @Lover_FF_Percent THEN @Lover_FF_Percent ELSE 0 END) 

	FROM sys.dm_db_index_physical_stats(DB_ID(), NULL, NULL, NULL, 'SAMPLED') ps 
	INNER JOIN sys.indexes i ON i.OBJECT_ID = ps.OBJECT_ID AND i.index_id = ps.index_id 
	WHERE ps.page_count > 1 and ps.avg_fragmentation_in_percent > 0
)
SELECT 'ALTER INDEX ' + IndexName + ' ON [' + SchemaName + '].[' + TableName + ']'
	+ ' REBUILD WITH (' + 
	CASE WHEN page_count * Proposed_Space_Gain_Percent * 10 / ( SELECT AVG(page_count) * AVG(avg_fragmentation_in_percent) FROM DB_STATS ) >= @Lover_FF_Min_Decision
	THEN  'PAD_INDEX = ' + @PAD_INDEX + ', FILLFACTOR = ' + CAST(Proposed_fill_factor as VARCHAR) + ', ' ELSE '' END + 'SORT_IN_TEMPDB = ON);'
FROM DB_STATS
WHERE avg_fragmentation_in_percent > @Minimum_Fragmentation_Percent
ORDER BY index_id, page_count * Proposed_Space_Gain_Percent DESC
FOR READ ONLY;

OPEN ReFillFactor;
FETCH NEXT FROM ReFillFactor INTO @SQLCMD;
WHILE (@@fetch_status <> -1)
BEGIN
	PRINT @SQLCMD;
	RAISERROR ('Processing...',10,1) WITH NOWAIT;
--	EXEC(@SQLCMD);
	FETCH NEXT FROM ReFillFactor INTO @SQLCMD;
END

CLOSE ReFillFactor;
DEALLOCATE ReFillFactor;

