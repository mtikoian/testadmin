/*
Event: SQL Saturday #347, Washington, DC
Date:  2014-12-06
Topic: Re-FillFactoring
By:    Slava Murygin
Demo:  #2. Fat tables size issue

http://slavasql.blogspot.com/
@SlavaSQL
*/
USE master
GO
IF DB_ID('TestDB') IS NOT NULL 
BEGIN
	ALTER DATABASE [TestDB] SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
	DROP DATABASE [TestDB];
END
GO
CREATE DATABASE [TestDB];
GO
use TestDB
GO
-- Drop Test Table if exists
IF EXISTS ( SELECT TOP 1 1 FROM sys.tables WHERE name = 'tbl_FF_Test')
	DROP TABLE tbl_FF_Test;
GO
-- Create Test Table
CREATE TABLE tbl_FF_Test(
	ID INT 
	CONSTRAINT PK_FF_Test PRIMARY KEY, 
	RNDNumber BIGINT NULL,
	TestText VARCHAR(100) NULL,
);
GO
-- Fill Test records
INSERT INTO tbl_FF_Test(ID) 
SELECT TOP 239470 (ROW_NUMBER() OVER (ORDER BY Message_ID) ) AS RowNumber 
FROM sys.messages, (SELECT 1 as D union SELECT 2) as Doubler;
GO


--------------------------------------------------------------------------------------------------------------------------------
-- #2A - Fragmentation Demonstration

SELECT ps.index_level, 
	CASE WHEN i.fill_factor = 0 OR (ps.index_level > 0 and i.is_padded = 0) 
	THEN 100 ELSE i.fill_factor END AS fill_factor,
	ROUND(ps.avg_fragmentation_in_percent,3) as [AVG Frgmnt %], 
	ROUND(ps.avg_page_space_used_in_percent,3) as [AVG Space Use %], 
	ps.page_count, 
	ROUND(ps.page_count/128.,3) as Index_Size_Mb,
	ps.record_count, (ps.record_count / ps.page_count) as AVG_Records_per_Page
FROM sys.dm_db_index_physical_stats(DB_ID(), OBJECT_ID('tbl_FF_Test'), NULL, NULL, 'DETAILED') ps 
INNER JOIN sys.indexes i ON i.OBJECT_ID = ps.OBJECT_ID AND i.index_id = ps.index_id;
GO
-- Updating 622 records out of 239470
-- Which is 0.25%
SET STATISTICS IO ON
GO
UPDATE tbl_FF_Test 
SET TestText = 'SQLSaturday'
WHERE ID % 385 = 0;
GO
SET STATISTICS IO OFF
/*
Size Increase from 4.867 Mb to 9.75 Mb - Exactly 2 Times!!!
Due to Page Splits: 6229 IOs!!!!
*/

GO
SELECT ps.index_level, 
	CASE WHEN i.fill_factor = 0 OR (ps.index_level > 0 and i.is_padded = 0) 
	THEN 100 ELSE i.fill_factor END AS fill_factor,
	ROUND(ps.avg_fragmentation_in_percent,3) as [AVG Frgmnt %], 
	ROUND(ps.avg_page_space_used_in_percent,3) as [AVG Space Use %], 
	ps.page_count, 
	ROUND(ps.page_count/128.,3) as Index_Size_Mb,
	ps.record_count, (ps.record_count / ps.page_count) as AVG_Records_per_Page
FROM sys.dm_db_index_physical_stats(DB_ID(), OBJECT_ID('tbl_FF_Test'), NULL, NULL, 'DETAILED') ps 
INNER JOIN sys.indexes i ON i.OBJECT_ID = ps.OBJECT_ID AND i.index_id = ps.index_id;
GO

--------------------------------------------------------------------------------------------------------------------------------
-- ? What is FF ?


