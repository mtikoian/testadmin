/*
Event: SQL Saturday #347, Washington, DC
Date:  2014-12-06
Topic: Re-FillFactoring
By:    Slava Murygin
Demo:  #5. Finding the right Fill Factor.

http://slavasql.blogspot.com/
@SlavaSQL
*/
USE master;
GO
IF DB_ID('TestDB') IS NOT NULL 
BEGIN
	ALTER DATABASE [TestDB] SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
	DROP DATABASE [TestDB];
END
GO
CREATE DATABASE [TestDB];
GO
USE [TestDB];
GO
-- Drop Test Table if exists
IF EXISTS ( SELECT TOP 1 1 FROM sys.tables WHERE name = 'tbl_FF_Test')
	DROP TABLE tbl_FF_Test;
GO
-- Create Test Table
CREATE TABLE tbl_FF_Test(
	ID INT IDENTITY(1,1)
		CONSTRAINT PK_FF_Test 
		PRIMARY KEY CLUSTERED,
	UI UNIQUEIDENTIFIER NULL
		INDEX NCIX_FF_Test NONCLUSTERED WITH (FILLFACTOR=100,PAD_INDEX=OFF),
	TestText VARCHAR(100) NULL,
);
GO
INSERT INTO tbl_FF_Test(UI) 
SELECT NEWID() FROM sys.messages;
GO
ALTER INDEX NCIX_FF_Test ON tbl_FF_Test REBUILD;
GO
SELECT ps.index_level, 
	CASE WHEN i.fill_factor = 0 OR (ps.index_level > 0 and i.is_padded = 0) 
	THEN 100 ELSE i.fill_factor END AS fill_factor,
	ROUND(ps.avg_fragmentation_in_percent,3) as [AVG Frgmnt %], 
	ROUND(ps.avg_page_space_used_in_percent,3) as [AVG Space Use %], 
	ps.page_count, 
	ROUND(ps.page_count/128.,3) as Index_Size_Mb,
	ps.record_count, (ps.record_count / ps.page_count) as AVG_Records_per_Page
FROM sys.dm_db_index_physical_stats(DB_ID(), OBJECT_ID('tbl_FF_Test'), 
	INDEXPROPERTY(OBJECT_ID('tbl_FF_Test'), 'NCIX_FF_Test', 'IndexId'), NULL, 'DETAILED') ps 
INNER JOIN sys.indexes i ON i.OBJECT_ID = ps.OBJECT_ID AND i.index_id = ps.index_id;
GO
-- Replicate data load. Daily increase by 1% within two weeks.
-- Insert 1% of records 14 times
CHECKPOINT 
GO
DECLARE @i INT = 14;
WHILE @i>0
BEGIN
	INSERT INTO tbl_FF_Test(UI) 
	SELECT TOP 1 PERCENT NEWID() FROM tbl_FF_Test;
	SET @i -= 1;
END
GO
SELECT
    [AllocUnitName] AS N'Index',
    (CASE [Context]
        WHEN N'LCX_INDEX_LEAF' THEN N'Nonclustered'
        WHEN N'LCX_CLUSTERED' THEN N'Clustered'
        ELSE N'Non-Leaf'
    END) AS [SplitType],
    COUNT (1) AS [SplitCount]
FROM
    fn_dblog (NULL, NULL)
WHERE
    [Operation] = N'LOP_DELETE_SPLIT'
GROUP BY [AllocUnitName], [Context];
GO
SELECT ps.index_level, 
	CASE WHEN i.fill_factor = 0 OR (ps.index_level > 0 and i.is_padded = 0) 
	THEN 100 ELSE i.fill_factor END AS fill_factor,
	ROUND(ps.avg_fragmentation_in_percent,3) as [AVG Frgmnt %], 
	ROUND(ps.avg_page_space_used_in_percent,3) as [AVG Space Use %], 
	ps.page_count, 
	ROUND(ps.page_count/128.,3) as Index_Size_Mb,
	ps.record_count, (ps.record_count / ps.page_count) as AVG_Records_per_Page
FROM sys.dm_db_index_physical_stats(DB_ID(), OBJECT_ID('tbl_FF_Test'), 
	INDEXPROPERTY(OBJECT_ID('tbl_FF_Test'), 'NCIX_FF_Test', 'IndexId'), NULL, 'DETAILED') ps 
INNER JOIN sys.indexes i ON i.OBJECT_ID = ps.OBJECT_ID AND i.index_id = ps.index_id;
-- Pretty bad situation in terms of fragmentation and page splits
GO
CHECKPOINT 
GO

-- ============================================================================================================================================
-- Use FF = 90% to 80%

-- Drop Test Table if exists
IF EXISTS ( SELECT TOP 1 1 FROM sys.tables WHERE name = 'tbl_FF_Test')
	DROP TABLE tbl_FF_Test;
GO
-- Create Test Table
CREATE TABLE tbl_FF_Test(
	ID INT IDENTITY(1,1)
		CONSTRAINT PK_FF_Test 
		PRIMARY KEY CLUSTERED,
	UI UNIQUEIDENTIFIER NULL
		INDEX NCIX_FF_Test NONCLUSTERED WITH (FILLFACTOR=90,PAD_INDEX=OFF),
	TestText VARCHAR(100) NULL,
);
GO
INSERT INTO tbl_FF_Test(UI) 
SELECT NEWID() FROM sys.messages;
GO
ALTER INDEX NCIX_FF_Test ON tbl_FF_Test REBUILD;
GO
SELECT ps.index_level, 
	CASE WHEN i.fill_factor = 0 OR (ps.index_level > 0 and i.is_padded = 0) 
	THEN 100 ELSE i.fill_factor END AS fill_factor,
	ROUND(ps.avg_fragmentation_in_percent,3) as [AVG Frgmnt %], 
	ROUND(ps.avg_page_space_used_in_percent,3) as [AVG Space Use %], 
	ps.page_count, 
	ROUND(ps.page_count/128.,3) as Index_Size_Mb,
	ps.record_count, (ps.record_count / ps.page_count) as AVG_Records_per_Page
FROM sys.dm_db_index_physical_stats(DB_ID(), OBJECT_ID('tbl_FF_Test'), 
	INDEXPROPERTY(OBJECT_ID('tbl_FF_Test'), 'NCIX_FF_Test', 'IndexId'), NULL, 'DETAILED') ps 
INNER JOIN sys.indexes i ON i.OBJECT_ID = ps.OBJECT_ID AND i.index_id = ps.index_id;
GO
-- Insert 1% of records 14 times
CHECKPOINT 
GO
DECLARE @i INT = 14;
WHILE @i>0
BEGIN
	INSERT INTO tbl_FF_Test(UI) 
	SELECT TOP 1 PERCENT NEWID() FROM tbl_FF_Test;
	SET @i -= 1;
END
GO
SELECT
    [AllocUnitName] AS N'Index',
    (CASE [Context]
        WHEN N'LCX_INDEX_LEAF' THEN N'Nonclustered'
        WHEN N'LCX_CLUSTERED' THEN N'Clustered'
        ELSE N'Non-Leaf'
    END) AS [SplitType],
    COUNT (1) AS [SplitCount]
FROM
    fn_dblog (NULL, NULL)
WHERE
    [Operation] = N'LOP_DELETE_SPLIT'
GROUP BY [AllocUnitName], [Context];
GO
SELECT ps.index_level, 
	CASE WHEN i.fill_factor = 0 OR (ps.index_level > 0 and i.is_padded = 0) 
	THEN 100 ELSE i.fill_factor END AS fill_factor,
	ROUND(ps.avg_fragmentation_in_percent,3) as [AVG Frgmnt %], 
	ROUND(ps.avg_page_space_used_in_percent,3) as [AVG Space Use %], 
	ps.page_count, 
	ROUND(ps.page_count/128.,3) as Index_Size_Mb,
	ps.record_count, (ps.record_count / ps.page_count) as AVG_Records_per_Page
FROM sys.dm_db_index_physical_stats(DB_ID(), OBJECT_ID('tbl_FF_Test'), 
	INDEXPROPERTY(OBJECT_ID('tbl_FF_Test'), 'NCIX_FF_Test', 'IndexId'), NULL, 'DETAILED') ps 
INNER JOIN sys.indexes i ON i.OBJECT_ID = ps.OBJECT_ID AND i.index_id = ps.index_id;
-- Pretty bad situation in terms of fragmentation and page splits
GO
CHECKPOINT 
GO
