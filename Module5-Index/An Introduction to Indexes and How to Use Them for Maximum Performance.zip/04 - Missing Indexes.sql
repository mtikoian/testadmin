USE AdventureWorks;
GO

-- Show plan

SELECT
	[SalesOrderID]
FROM
	[AdventureWorks].[Sales].[SalesOrderDetail]
WHERE
	ModifiedDate > '2008-01-01';

SELECT
	[SalesOrderID],
	[ProductID]
FROM
	[AdventureWorks].[Sales].[SalesOrderDetail]
WHERE
	ModifiedDate > '2008-01-01';

SELECT
	[SalesOrderID],
	[ProductID]
FROM
	[AdventureWorks].[Sales].[SalesOrderDetail]
WHERE
	ModifiedDate > '2008-01-01'
	AND ProductID = 922;


CREATE NONCLUSTERED INDEX [<Name of Missing Index, sysname,>]
ON [Sales].[SalesOrderDetail] ([ModifiedDate])
INCLUDE ([SalesOrderID]);

CREATE NONCLUSTERED INDEX [<Name of Missing Index, sysname,2>]
ON [Sales].[SalesOrderDetail] ([ModifiedDate])
INCLUDE ([SalesOrderID],[ProductID]);

CREATE NONCLUSTERED INDEX [<Name of Missing Index, sysname,>3]
ON [Sales].[SalesOrderDetail] ([ProductID],[ModifiedDate])
INCLUDE ([SalesOrderID]);


DROP INDEX [<Name of Missing Index, sysname,>]
ON [Sales].[SalesOrderDetail];

DROP INDEX [<Name of Missing Index, sysname,2>]
ON [Sales].[SalesOrderDetail];

DROP INDEX [<Name of Missing Index, sysname,>3]
ON [Sales].[SalesOrderDetail];


SELECT
	migs.*,
	mid.*
FROM
	sys.dm_db_missing_index_groups mig
INNER JOIN
	sys.dm_db_missing_index_group_stats migs
		ON migs.group_handle = mig.index_group_handle
INNER JOIN
	sys.dm_db_missing_index_details mid
		ON mig.index_handle = mid.index_handle;


CREATE NONCLUSTERED INDEX [IX_TEST]
ON [Sales].[SalesOrderDetail] ([ModifiedDate],[ProductID]);



CREATE NONCLUSTERED INDEX [IX_TEST2]
ON [Sales].[SalesOrderDetail] ([ProductID],[ModifiedDate]);

