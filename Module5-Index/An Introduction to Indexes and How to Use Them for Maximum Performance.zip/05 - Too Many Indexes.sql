USE AdventureWorks;
GO

CREATE TABLE [SQLSaturday].[FewIndexes] (ID INT, Col1 INT, Col2 INT, Col3 INT, Col4 INT, Col5 INT, Col6 INT, Col7 INT, Col8 INT);
CREATE TABLE [SQLSaturday].[ManyIndexes] (ID INT, Col1 INT, Col2 INT, Col3 INT, Col4 INT, Col5 INT, Col6 INT, Col7 INT, Col8 INT);

CREATE CLUSTERED INDEX CIX_Few ON [SQLSaturday].[FewIndexes] (ID);
CREATE CLUSTERED INDEX CIX_Many ON [SQLSaturday].[ManyIndexes] (ID);

CREATE NONCLUSTERED INDEX NIX_Many1 ON [SQLSaturday].[ManyIndexes] (Col1);
CREATE NONCLUSTERED INDEX NIX_Many2 ON [SQLSaturday].[ManyIndexes] (Col2);
CREATE NONCLUSTERED INDEX NIX_Many3 ON [SQLSaturday].[ManyIndexes] (Col3);
CREATE NONCLUSTERED INDEX NIX_Many4 ON [SQLSaturday].[ManyIndexes] (Col4);
CREATE NONCLUSTERED INDEX NIX_Many5 ON [SQLSaturday].[ManyIndexes] (Col5);
CREATE NONCLUSTERED INDEX NIX_Many6 ON [SQLSaturday].[ManyIndexes] (Col6);
CREATE NONCLUSTERED INDEX NIX_Many7 ON [SQLSaturday].[ManyIndexes] (Col7);
CREATE NONCLUSTERED INDEX NIX_Many8 ON [SQLSaturday].[ManyIndexes] (Col8);

SET STATISTICS IO ON;

INSERT INTO [SQLSaturday].[FewIndexes]
SELECT TOP 10000
	ROW_NUMBER() OVER (ORDER BY a.object_id),
	ROW_NUMBER() OVER (ORDER BY a.object_id),
	ROW_NUMBER() OVER (ORDER BY a.object_id),
	ROW_NUMBER() OVER (ORDER BY a.object_id),
	ROW_NUMBER() OVER (ORDER BY a.object_id),
	ROW_NUMBER() OVER (ORDER BY a.object_id),
	ROW_NUMBER() OVER (ORDER BY a.object_id),
	ROW_NUMBER() OVER (ORDER BY a.object_id),
	ROW_NUMBER() OVER (ORDER BY a.object_id)
FROM
	sys.all_columns a
CROSS JOIN
	sys.all_columns b;

INSERT INTO [SQLSaturday].[ManyIndexes]
SELECT TOP 10000
	ROW_NUMBER() OVER (ORDER BY a.object_id),
	ROW_NUMBER() OVER (ORDER BY a.object_id),
	ROW_NUMBER() OVER (ORDER BY a.object_id),
	ROW_NUMBER() OVER (ORDER BY a.object_id),
	ROW_NUMBER() OVER (ORDER BY a.object_id),
	ROW_NUMBER() OVER (ORDER BY a.object_id),
	ROW_NUMBER() OVER (ORDER BY a.object_id),
	ROW_NUMBER() OVER (ORDER BY a.object_id),
	ROW_NUMBER() OVER (ORDER BY a.object_id)
FROM
	sys.all_columns a
CROSS JOIN
	sys.all_columns b;

UPDATE
	[SQLSaturday].[FewIndexes]
SET
	ID = 10001
WHERE
	ID = 10000;

UPDATE
	[SQLSaturday].[ManyIndexes]
SET
	ID = 10001
WHERE
	ID = 10000;

DELETE FROM [SQLSaturday].[FewIndexes];
DELETE FROM [SQLSaturday].[ManyIndexes];

SELECT
	*
FROM
	sys.dm_db_index_usage_stats
WHERE
	database_id = DB_ID()
	AND (object_id = OBJECT_ID('[SQLSaturday].[FewIndexes]')
	OR object_id = OBJECT_ID('[SQLSaturday].[ManyIndexes]'));


EXEC sp_spaceused '[SQLSaturday].[ManyIndexes]'

ALTER INDEX NIX_Many5 ON [SQLSaturday].[ManyIndexes] DISABLE;
ALTER INDEX NIX_Many6 ON [SQLSaturday].[ManyIndexes] DISABLE;
ALTER INDEX NIX_Many7 ON [SQLSaturday].[ManyIndexes] DISABLE;
ALTER INDEX NIX_Many8 ON [SQLSaturday].[ManyIndexes] DISABLE;

ALTER INDEX NIX_Many5 ON [SQLSaturday].[ManyIndexes] REBUILD;
ALTER INDEX NIX_Many6 ON [SQLSaturday].[ManyIndexes] REBUILD;
ALTER INDEX NIX_Many7 ON [SQLSaturday].[ManyIndexes] REBUILD;
ALTER INDEX NIX_Many8 ON [SQLSaturday].[ManyIndexes] REBUILD;

