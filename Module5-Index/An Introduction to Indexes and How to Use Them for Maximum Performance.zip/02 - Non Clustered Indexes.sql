USE AdventureWorks;
GO

-- Show the plan

-- This is a non covering index.
CREATE NONCLUSTERED INDEX NIX_PhoneBook ON [SQLSaturday].[PersonHeap] (FirstName);
GO

SELECT
	FirstName,
	LastName
FROM
	[SQLSaturday].[PersonHeap] WITH (INDEX = NIX_Phonebook)
WHERE
	FirstName = 'John';

-- These are covering indexes
CREATE NONCLUSTERED INDEX NIX_PhoneBook ON [SQLSaturday].[PersonCIX] (FirstName);
CREATE NONCLUSTERED INDEX NIX_PhoneBook_Covering ON [SQLSaturday].[PersonHeap] (FirstName, LastName);

SELECT
	FirstName,
	LastName
FROM
	[SQLSaturday].[PersonHeap]
WHERE
	FirstName = 'John';

SELECT
	FirstName,
	LastName
FROM
	[SQLSaturday].[PersonCIX]
WHERE
	FirstName = 'John';

CREATE NONCLUSTERED INDEX NIX_PhoneBook_Filtered
ON [SQLSaturday].[PersonHeap] (FirstName)
WHERE LastName = 'Smith';

SELECT
	FirstName
FROM
	[SQLSaturday].[PersonHeap]
WHERE
	LastName = 'Smith';