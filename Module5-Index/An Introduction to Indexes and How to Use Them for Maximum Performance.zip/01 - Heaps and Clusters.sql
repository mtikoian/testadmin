USE AdventureWorks;
GO

-- Creating a HEAP
CREATE TABLE [SQLSaturday].[PersonHeap]
	(FirstName NVARCHAR(50) NOT NULL,
	LastName NVARCHAR(50) NOT NULL);
GO

-- Creating a Clustered Index
CREATE TABLE [SQLSaturday].[PersonCIX]
	(FirstName NVARCHAR(50) NOT NULL,
	LastName NVARCHAR(50) NOT NULL);
GO

CREATE CLUSTERED INDEX CIX_Person ON [SQLSaturday].[PersonCIX] (LastName, FirstName);
GO

SELECT
	*
FROM
	sys.indexes
WHERE
	object_id = OBJECT_ID('[SQLSaturday].[PersonHeap]')
	OR object_id = OBJECT_ID('[SQLSaturday].[PersonCIX]');

-- Some sample data.......
INSERT INTO
	[SQLSaturday].[PersonHeap]
SELECT
	FirstName,
	LastName
FROM
	Person.Person;

INSERT INTO [SQLSaturday].[PersonCIX]
SELECT
	FirstName,
	LastName
FROM
	Person.Person;
GO

-- Show the plan
SET STATISTICS IO ON;

-- The HEAP will always scan
SELECT
	*
FROM
	[SQLSaturday].[PersonHeap]
WHERE
	LastName = 'Smith';

-- The CIX will seek when it can
SELECT
	*
FROM
	[SQLSaturday].[PersonCIX]
WHERE
	LastName = 'Smith';

SELECT
	*
FROM
	[SQLSaturday].[PersonCIX]
WHERE
	FirstName = 'John';
