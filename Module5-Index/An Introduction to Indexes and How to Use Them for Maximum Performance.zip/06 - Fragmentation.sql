USE AdventureWorks;
GO

SELECT
	*
INTO
	[SQLSaturday].[LowFillFactor]
FROM
	[Sales].[SalesOrderDetail];
SELECT
	*
INTO
	[SQLSaturday].[HighFillFactor]
FROM
	[Sales].[SalesOrderDetail];

CREATE CLUSTERED INDEX IX_Low
ON [SQLSaturday].[LowFillFactor] (SalesOrderID)
WITH (FILLFACTOR = 10);
CREATE CLUSTERED INDEX IX_High
ON [SQLSaturday].[HighFillFactor] (SalesOrderID)
WITH (FILLFACTOR = 90);

SELECT
	*
FROM
	sys.dm_db_index_physical_stats(DB_ID(), OBJECT_ID('[SQLSaturday].[LowFillFactor]'), 1, NULL, 'DETAILED');
SELECT
	*
FROM
	sys.dm_db_index_physical_stats(DB_ID(), OBJECT_ID('[SQLSaturday].[HighFillFactor]'), 1, NULL, 'DETAILED');

SELECT NEWID();
SELECT NEWID();

CREATE TABLE [SQLSaturday].Fragmented (ID INT, MyGUID UNIQUEIDENTIFIER);
CREATE TABLE [SQLSaturday].NotFragmented (ID INT IDENTITY(1, 1), MyGUID UNIQUEIDENTIFIER);

CREATE CLUSTERED INDEX IX_Frag ON [SQLSaturday].Fragmented (MyGUID);
CREATE CLUSTERED INDEX IX_NotFrag ON [SQLSaturday].NotFragmented (ID);

INSERT INTO
	[SQLSaturday].Fragmented
SELECT TOP 100000
	ROW_NUMBER() OVER (ORDER BY a.object_id),
	NEWID()
FROM
	sys.all_columns a
CROSS JOIN
	sys.all_columns b;

INSERT INTO
	[SQLSaturday].NotFragmented (MyGUID)
SELECT TOP 100000
	NEWID()
FROM
	sys.all_columns a
CROSS JOIN
	sys.all_columns b;

SELECT
	*
FROM
	sys.dm_db_index_physical_stats(DB_ID(), OBJECT_ID('[SQLSaturday].[Fragmented]'), 1, NULL, 'DETAILED');
SELECT
	*
FROM
	sys.dm_db_index_physical_stats(DB_ID(), OBJECT_ID('[SQLSaturday].[NotFragmented]'), 1, NULL, 'DETAILED');

ALTER INDEX IX_Frag ON [SQLSaturday].Fragmented REBUILD;


ALTER INDEX IX_Low
ON [SQLSaturday].[LowFillFactor] REBUILD
WITH (FILLFACTOR = 100);

SELECT
	*
FROM
	sys.dm_db_index_physical_stats(DB_ID(), OBJECT_ID('[SQLSaturday].[LowFillFactor]'), 1, NULL, 'DETAILED');
