USE AdventureWorks;
GO

-- Show Plan

SELECT
	*
FROM
	[SQLSaturday].PersonCIX
WHERE
	LastName = 'Smith'
OPTION (RECOMPILE);

SELECT
	*
FROM
	[SQLSaturday].PersonCIX
WHERE
	LastName = 'Jones'
OPTION (RECOMPILE);



DBCC SHOW_STATISTICS ('SQLSaturday.PersonCIX', 'CIX_Person');