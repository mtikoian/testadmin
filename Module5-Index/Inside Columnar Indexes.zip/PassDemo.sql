Use AdventureworksDW2016CTP3
go
--Demo 1: Basic Columnstore

-- New syntax BTW
drop table if exists t_colstor
go

-- create the table
create table t_colstor (
	accountkey			int not null,
	accountdescription	nvarchar (50) not null,
	accounttype			nvarchar(50),
	AccountCodeAlternatekey int)


-- CREATE SIMPLE ROW STORE TABLE TO START WITH
insert into t_colstor 
SELECT accountkey, accountdescription, accounttype, accountcodeAlternateKey 
FROM AdventureWorksDW2016ctp3.dbo.DimAccount 


-- show query plan
-- create clustered columnstore index
CREATE CLUSTERED COLUMNSTORE index t_colstor_cci on t_colstor WITH (DATA_COMPRESSION= COLUMNSTORE);

--rebuild index to change compression setting
alter index t_colstor_cci on t_colstor rebuild with (DATA_COMPRESSION = COLUMNSTORE_ARCHIVE)

-- reorganize
alter index t_colstor_cci on t_colstor reorganize with (COMPRESS_ALL_ROW_GROUPS = ON)
--alter table alter index t_colstor_cci on t_colstor reorganize with (COMPRESS_ALL_ROW_GROUPS = ON)

-- creating columntore index as part of create table
create table t_colstore2 (c1 int, index t_colstor2_cci clustered columnstore )

-- querying and query plan
SELECT accounttype, COUNT(*) FROM t_colstor GROUP BY accounttype


-- SQL 2014 did not support foreign Key constraints.. 
-- Validate there are constraints on this table
SELECT * FROM sys.indexes WHERE object_id = object_id('FactResellerSalesXL_CCI')
SELECT * FROM sys.foreign_keys WHERE parent_object_id = object_id('FactResellerSalesXL_CCI')

-- Now make change to violate constraint and it should fail.
BEGIN TRAN
DECLARE @SalesOrderNumber NVARCHAR(25)

SET @SalesOrderNumber = (
		SELECT TOP 1 SalesOrderNumber
		FROM FactResellerSalesXL_CCI
		)

UPDATE FactResellerSalesXL_CCI
SET ProductKey = - 999
WHERE SalesOrderNumber = @SalesOrderNumber
ROLLBACK



--Demo 2: Performance
DBCC DROPCLEANBUFFERS
GO
-- Execute a typical query that joins the Fact Table with dimension tables
-- Note this query will run on the Page Compressed table, Note down the time
SET STATISTICS IO ON
SET STATISTICS TIME ON
GO

SELECT c.CalendarYear
	,b.SalesTerritoryRegion
	,FirstName + ' ' + LastName AS FullName
	,count(SalesOrderNumber) AS NumSales
	,sum(SalesAmount) AS TotalSalesAmt
	,Avg(SalesAmount) AS AvgSalesAmt
	,count(DISTINCT SalesOrderNumber) AS NumOrders
	,count(DISTINCT ResellerKey) AS NumResellers
FROM FactResellerSalesXL_PageCompressed a
INNER JOIN DimSalesTerritory b ON b.SalesTerritoryKey = a.SalesTerritoryKey
INNER JOIN DimEmployee d ON d.Employeekey = a.EmployeeKey
INNER JOIN DimDate c ON c.DateKey = a.OrderDateKey
WHERE b.SalesTerritoryKey = 3
	AND c.FullDateAlternateKey BETWEEN '1/1/2006' AND '1/1/2010'
GROUP BY b.SalesTerritoryRegion,d.EmployeeKey,d.FirstName,d.LastName,c.CalendarYear
GO

SET STATISTICS IO OFF
SET STATISTICS TIME OFF
GO

DBCC DROPCLEANBUFFERS
GO
-- This is the same Prior query on a table with a Clustered Columnstore index CCI 
-- The comparison numbers are even more dramatic the larger the table is, this is a 11 million row table only.
SET STATISTICS IO ON
SET STATISTICS TIME ON
GO

SELECT b.SalesTerritoryRegion
	,FirstName + ' ' + LastName AS FullName
	,count(SalesOrderNumber) AS NumSales
	,sum(SalesAmount) AS TotalSalesAmt
	,Avg(SalesAmount) AS AvgSalesAmt
	,count(DISTINCT SalesOrderNumber) AS NumOrders
	,count(DISTINCT ResellerKey) AS NumResellers
FROM FactResellerSalesXL_CCI a
INNER JOIN DimSalesTerritory b ON b.SalesTerritoryKey = a.SalesTerritoryKey
INNER JOIN DimEmployee d ON d.Employeekey = a.EmployeeKey
INNER JOIN DimDate c ON c.DateKey = a.OrderDateKey
WHERE b.SalesTerritoryKey = 3
	AND c.FullDateAlternateKey BETWEEN '1/1/2006' AND '1/1/2010'
GROUP BY b.SalesTerritoryRegion,d.EmployeeKey,d.FirstName,d.LastName,c.CalendarYear
GO

SET STATISTICS IO OFF
SET STATISTICS TIME OFF
GO

-- Number of Columns
select	min (CurrencyKey), min(OrderDateKey), min (EmployeeKey), 
		min (PromotionKey), min (DueDateKey),
		min (ProductKey), min (DueDateKey)
from FactResellerSalesXL_CCI
go
select	min (CurrencyKey)
from FactResellerSalesXL_CCI

-- Push Down
SELECT CurrencyKey, COUNT(*) FROM FactResellerSalesXL_CCI 
WHERE CurrencyKey <> 98 AND DueDate > getdate() - 1000
GROUP BY CurrencyKey

-- Look at the Query Plan, you will see the Predicate pushed to the SCAN
-- In SQL 2014, this would be a SCAN followed by a Filter
-- Look at the Properties of the SCAN, you will see a Predicate:  [AdventureworksDW2014].[dbo].[FactResellerSalesXL_CCI].[CustomerPONumber]=[@1]
SELECT CustomerPONumber
FROM FactResellerSalesXL_CCI
WHERE CustomerPONumber = N'PO1022545'

--Demo 3: Real Time Analytics - NCCI

SET STATISTICS IO ON
SET STATISTICS TIME ON
GO

select top 100 SalesOrderNumber from FactResellerSalesXL_CCI 
WITH (INDEX = [IndFactResellerSalesXL_CCI])
where SalesOrderNumber = 'SO892200'
go
CREATE INDEX NCCI on FactResellerSalesXL_CCI (SalesOrderNumber)
go
select top 100 SalesOrderNumber from FactResellerSalesXL_CCI
where SalesOrderNumber = 'SO892200'
go
--clean
DROP INDEX FactResellerSalesXL_CCI.NCCI