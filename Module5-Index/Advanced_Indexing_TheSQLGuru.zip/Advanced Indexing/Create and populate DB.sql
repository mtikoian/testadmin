USE master;
SET NOCOUNT ON;
go

PRINT CAST(SYSDATETIME() AS varchar(23)) + ': start creating demo database.'

-- Remove old version of demo database. Use brute force if necessary.
IF EXISTS (SELECT name FROM sys.databases WHERE name = N'IndexDemo')
  BEGIN;
  ALTER DATABASE IndexDemo SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
  DROP DATABASE IndexDemo;
  END;
go

-- Create the empty demo database, with sufficient size for the demo table.
-- To make the script run on all databases, I don't hardcode the directory,
-- but use the directory where the master database lives;
-- this gives me the guarantee that the directory exists
-- and is accessible by SQL Server.
--
-- Unfortunately, this requires the use of dynamic SQL,
-- which I normally avoid. In this case, though, the risk is acceptable.
-- The only way to exploit this dynamic SQL is to install an instance
-- with the master database in directory a very carefully crafted path;
-- whoever can do that must have admin rights
-- and doesn't need the SQL injection attack.

DECLARE @master_directory nvarchar(260);
SET @master_directory =
 (SELECT REPLACE(physical_name, 'master.mdf', '')
  FROM   sys.database_files
  WHERE  name='master'
  AND    type=0);
EXECUTE
 (N'CREATE DATABASE IndexDemo
    ON PRIMARY
      (NAME = IndexDemo,
       FILENAME = ''' + @master_directory + N'IndexDemo.mdf'',
       SIZE = 1000MB, FILEGROWTH = 102400KB )
    LOG ON
      (NAME = IndexDemoLog,
       FILENAME = ''' + @master_directory + N'IndexDemo.ldf'',
       SIZE = 500MB, FILEGROWTH = 51200KB )
    COLLATE Latin1_General_CI_AS;');
go

-- Switch to tempdb before switching to IndexDemo.
-- If IndexDemo was not created, the USE statement fails,
-- but the next batch will still execute.
-- Switching to tempdb first ensures spurious tables will be created there.

USE tempdb;
ALTER DATABASE indexdemo SET RECOVERY SIMPLE
go

USE IndexDemo;
go

-- Create the demo table.
-- Note that the PRIMARY KEY implicitly creates a clustered index.
CREATE TABLE dbo.Persons
  (PersonID  int           NOT NULL IDENTITY,
   FirstName varchar(20)   NOT NULL,
   LastName  varchar(30)   NOT NULL,
   Email     varchar(200)  NOT NULL,
   EmailLen  int           NOT NULL,
   Other     varchar(1000) NOT NULL)
   --,		 CONSTRAINT PK_Persons PRIMARY KEY(PersonID));
go

-- Add an index that won't be used in the demo.
-- (Required for demo of index usage stats)
--KGB: moved to bottom
--CREATE NONCLUSTERED INDEX ix_Persons_Email
--ON     dbo.Persons(Email)
--WHERE  EmailLen > 1;

-- Test data is based on (read: shamelessly copied from) AdventureWorks,
-- so you must have that demo database installed when running this script.
-- AdventureWorks can be downloaded from http://msftdbprodsamples.codeplex.com/.

-- Enable rowcount feedback (to see the exact row numbers)
SET NOCOUNT OFF;

-- Fill the table with all (approximately 20,000) persons from AdventureWorks
PRINT CAST(SYSDATETIME() AS varchar(23)) + ': start populating table.'
INSERT INTO dbo.Persons
           (FirstName,             LastName,
            Email,                 EmailLen,
            Other)
SELECT      LEFT(FirstName, 20),   LEFT(LastName, 30),
            EmailAddress,          LEN(EmailAddress),
            RTRIM(REPLICATE(EmailAddress + ' ', 10))
FROM        AdventureWorks2012.Person.Person p
INNER JOIN  AdventureWorks2012.Person.EmailAddress ea on p.BusinessEntityID = ea.BusinessEntityID;


-- Double up a few times, to bump the test data to over a million rows
-- 20,000 to 40,000
INSERT INTO dbo.Persons
           (FirstName,             LastName,
            Email,                 EmailLen,              Other)
SELECT      FirstName,             LastName,
            Email,                 EmailLen,              Other
FROM        dbo.Persons;
go
-- 40,000 to 80,000
INSERT INTO dbo.Persons
           (FirstName,             LastName,
            Email,                 EmailLen,              Other)
SELECT      FirstName,             LastName,
            Email,                 EmailLen,              Other
FROM        dbo.Persons;
go
CHECKPOINT
GO
-- 80,000 to 160,000
INSERT INTO dbo.Persons
           (FirstName,             LastName,
            Email,                 EmailLen,              Other)
SELECT      FirstName,             LastName,
            Email,                 EmailLen,              Other
FROM        dbo.Persons;
go
-- 160,000 to 320,000
INSERT INTO dbo.Persons
           (FirstName,             LastName,
            Email,                 EmailLen,              Other)
SELECT      FirstName,             LastName,
            Email,                 EmailLen,              Other
FROM        dbo.Persons;
go
CHECKPOINT
GO
-- 320,000 to 640,000
INSERT INTO dbo.Persons
           (FirstName,             LastName,
            Email,                 EmailLen,              Other)
SELECT      FirstName,             LastName,
            Email,                 EmailLen,              Other
FROM        dbo.Persons;
go
-- 640,000 to 1,280,000
INSERT INTO dbo.Persons
           (FirstName,             LastName,
            Email,                 EmailLen,              Other)
SELECT      FirstName,             LastName,
            Email,                 EmailLen,              Other
FROM        dbo.Persons;
go
CHECKPOINT
GO

--add PK
ALTER TABLE [dbo].[Persons] ADD  CONSTRAINT [PK_Persons] PRIMARY KEY CLUSTERED 
(
	[PersonID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = ON, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO
CHECKPOINT
GO


-- Add a nonclustered index
PRINT CAST(SYSDATETIME() AS varchar(23)) + ': start creating nonclustered index.'
CREATE NONCLUSTERED INDEX ix_PersonName
	ON dbo.Persons (LastName, FirstName);

-- Add an index that won't be used in the demo.
-- (Required for demo of index usage stats)
go
CHECKPOINT
go
CREATE NONCLUSTERED INDEX ix_Persons_Email
ON     dbo.Persons(Email)
WHERE  EmailLen > 1;

go
PRINT CAST(SYSDATETIME() AS varchar(23)) + ': tables and indexes succesfully created and populated.'
