USE IndexDemo;
go

-- No nonclustered index exists that includes the email column.
-- Optimizer has to choose between efficient seek + expensive lookup,
-- or expensive scan
-- When few rows are expected to match, use seek + lookup

SET STATISTICS IO ON;

SELECT FirstName, LastName, Email
FROM   dbo.Persons --WITH (INDEX=ix_PersonName) --are we smarter than optimizer?
WHERE  LastName LIKE 'S%';

SELECT FirstName, LastName, Email
FROM   dbo.Persons
WHERE  LastName LIKE 'V%';

SET STATISTICS IO OFF;


-- Add a nonclustered index that does cover the index
-- The "ideal" index for THIS query is on LastName,
-- and INCLUDEs both the columns FirstName and Email.

CREATE   NONCLUSTERED INDEX ix_PersonName_Include
ON       dbo.Persons (LastName)
INCLUDE (FirstName, Email);

-- Now, the obvious choice is to seek in the covering index, for both queries.

SET STATISTICS IO ON;

SELECT FirstName, LastName, Email
FROM   dbo.Persons
WHERE  LastName LIKE 'S%';

SELECT FirstName, LastName, Email
FROM   dbo.Persons
WHERE  LastName LIKE 'V%';

SET STATISTICS IO OFF;



-- To prevent wildgrowth of indexes, it's often better to have a
-- limited number of indexes that are "reasonably good" for several queries,
-- than to have a bucketload of indexes that are each "perfect" for one.
-- The index below is slightly worse for this specific query,
-- but can be used by other queries as well.
-- It could replace the existing index on LastName, FirstName.
DROP     INDEX dbo.Persons.ix_PersonName_Include;

CREATE   NONCLUSTERED INDEX ix_PersonName_Include
ON       dbo.Persons (LastName, FirstName)
INCLUDE (Email);

-- This version of the covering index is still very good, for both queries.

SET STATISTICS IO ON;

SELECT FirstName, LastName, Email
FROM   dbo.Persons
WHERE  LastName LIKE 'S%';

SELECT FirstName, LastName, Email
FROM   dbo.Persons
WHERE  LastName LIKE 'V%';

SET STATISTICS IO OFF;
