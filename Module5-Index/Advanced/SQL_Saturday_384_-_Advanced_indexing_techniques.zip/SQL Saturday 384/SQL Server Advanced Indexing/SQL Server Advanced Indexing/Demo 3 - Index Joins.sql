use AdventureWorks2008R2
go
set statistics io on
set statistics time on
--include actual execution plan


SELECT soh.SalesPersonID,
soh.OrderDate
FROM Sales.SalesOrderHeader AS soh
WHERE soh.SalesPersonID = 276
AND soh.OrderDate BETWEEN '4/1/2005' AND '7/1/2005' ;

CREATE NONCLUSTERED INDEX IX_Test
ON Sales.SalesOrderHeader (OrderDate ASC) ;


SELECT soh.SalesPersonID,
soh.OrderDate
FROM Sales.SalesOrderHeader AS soh
WHERE soh.SalesPersonID = 276
AND soh.OrderDate BETWEEN '4/1/2005' AND '7/1/2005' ;

--using hints sometimes can be really harmful
SELECT soh.SalesPersonID,soh.OrderDate 
FROM Sales.SalesOrderHeader AS soh 
WITH (INDEX (IX_Test,IX_SalesOrderHeader_SalesPersonID)) 
WHERE soh.OrderDate BETWEEN '4/1/2002' AND '7/1/2002';

DROP INDEX Sales.SalesOrderHeader.IX_Test