use AdventureWorks2008R2
go
set statistics io on
set statistics time on
--include actual execution plan


SELECT a.PostalCode
FROM Person.Address AS a
WHERE a.StateProvinceID = 42 ;
--there is a key lookup (cpu intensive)






--create the covering index
CREATE NONCLUSTERED INDEX [IX_Address_StateProvinceID]
ON [Person].[Address] ([StateProvinceID] ASC)
INCLUDE (PostalCode) --<-- INCLUDE
WITH (DROP_EXISTING = ON) ;

sp_helpindex 'Person.Address'

--test the query
SELECT a.PostalCode
FROM Person.Address AS a
WHERE a.StateProvinceID = 42 ;



--revert the index
CREATE NONCLUSTERED INDEX [IX_Address_StateProvinceID]
ON [Person].[Address] ([StateProvinceID] ASC)

WITH (DROP_EXISTING = ON) ;