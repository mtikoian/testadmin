use AdventureWorks2008R2
go
set statistics io on
set statistics time on

--create some indexes
CREATE NONCLUSTERED INDEX IX_Test
ON Person.Address(City ASC, PostalCode ASC) ;

CREATE NONCLUSTERED INDEX IX_Comp_Test
ON Person.Address (City,PostalCode)
WITH (DATA_COMPRESSION = ROW ) ;

CREATE NONCLUSTERED INDEX IX_Comp_Page_Test
ON Person.Address (City,PostalCode)
WITH (DATA_COMPRESSION = PAGE) ;

SELECT i.Name,
i.type_desc,
s.page_count,
s.record_count,
s.index_level,
compressed_page_count
FROM sys.indexes i
JOIN sys.dm_db_index_physical_stats(DB_ID(N'AdventureWorks2008R2'),
OBJECT_ID(N'Person.Address'), NULL,
NULL, 'DETAILED') AS s
ON i.index_id = s.index_id
WHERE i.OBJECT_ID = OBJECT_ID(N'Person.Address') ;



--compression in action
SELECT a.City,
a.PostalCode
FROM Person.Address AS a
WHERE a.City = 'Newton'
AND a.PostalCode = 'V2M1N7' ;
--logical reads 2

SELECT a.City,
a.PostalCode
FROM Person.Address AS a WITH (INDEX = IX_Test)
WHERE a.City = 'Newton'
AND a.PostalCode = 'V2M1N7' ;

--logical reads 3


--cleanup
DROP INDEX Person.Address.IX_Test;
DROP INDEX Person.Address.IX_Comp_Test;
DROP INDEX Person.Address.IX_Comp_Page_Test;