use AdventureWorks2008R2
go
set statistics io on
set statistics time on
--include actual execution plan


SELECT soh.*
FROM Sales.SalesOrderHeader AS soh
WHERE soh.SalesPersonID = 276
AND soh.OrderDate BETWEEN '4/1/2005' AND '7/1/2005' ;

--sp_helpindex 'Sales.SalesOrderHeader'

--create index
CREATE NONCLUSTERED INDEX IX_Test
ON Sales.SalesOrderHeader (OrderDate);

--check execution again
SELECT soh.*
FROM Sales.SalesOrderHeader AS soh
WHERE soh.SalesPersonID = 276
AND soh.OrderDate BETWEEN '4/1/2005' AND '7/1/2005' ;

DROP INDEX Sales.SalesOrderHeader.IX_Test;