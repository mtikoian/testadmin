use AdventureWorks2008R2
go
set statistics io on
set statistics time on
--include actual execution plan


SELECT soh.PurchaseOrderNumber,
soh.OrderDate,
soh.ShipDate,
soh.SalesPersonID
FROM Sales.SalesOrderHeaderEnlarged AS soh
WHERE PurchaseOrderNumber LIKE 'PO5%'
AND soh.SalesPersonID IS NOT NULL ;;

CREATE NONCLUSTERED INDEX IX_Test
ON Sales.SalesOrderHeaderEnlarged(PurchaseOrderNumber ,SalesPersonID)
--INCLUDE (OrderDate,ShipDate);--????????? why including them?


--what is the size?

SELECT i.[name] AS IndexName
    ,SUM(s.[used_page_count]) * 8 AS IndexSizeKB
FROM sys.dm_db_partition_stats AS s
INNER JOIN sys.indexes AS i ON s.[object_id] = i.[object_id]
    AND s.[index_id] = i.[index_id]
where i.name = 'IX_Test'
GROUP BY i.[name]
ORDER BY i.[name]
GO


SELECT soh.PurchaseOrderNumber,
soh.OrderDate,
soh.ShipDate,
soh.SalesPersonID
FROM Sales.SalesOrderHeaderEnlarged AS soh
WHERE PurchaseOrderNumber LIKE 'PO5%'
AND soh.SalesPersonID IS NOT NULL ;;













CREATE NONCLUSTERED INDEX IX_Test
ON Sales.SalesOrderHeaderEnlarged(PurchaseOrderNumber,SalesPersonID)
INCLUDE (OrderDate,ShipDate)
WHERE PurchaseOrderNumber IS NOT NULL AND SalesPersonID IS NOT NULL
WITH (DROP_EXISTING = ON);

SELECT i.[name] AS IndexName
    ,SUM(s.[used_page_count]) * 8 AS IndexSizeKB
FROM sys.dm_db_partition_stats AS s
INNER JOIN sys.indexes AS i ON s.[object_id] = i.[object_id]
    AND s.[index_id] = i.[index_id]
where i.name = 'IX_Test'
GROUP BY i.[name]
ORDER BY i.[name]
GO

SELECT soh.PurchaseOrderNumber,
soh.OrderDate,
soh.ShipDate,
soh.SalesPersonID
FROM Sales.SalesOrderHeaderEnlarged AS soh
WHERE PurchaseOrderNumber LIKE 'PO5%'
AND soh.SalesPersonID IS NOT NULL ;;



DROP INDEX Sales.SalesOrderHeaderenlarged.IX_Test
--FILTERED INDEXES END
