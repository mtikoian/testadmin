set statistics io on
go
SELECT sod.*
FROM Sales.SalesOrderDetail AS sod
WHERE sod.SalesOrderID IN (51825, 51826, 51827, 51828) ;
go
SELECT sod.*
FROM Sales.SalesOrderDetail AS sod
WHERE sod.SalesOrderID BETWEEN 51825 AND 51828 ;
go
SELECT sod.*
FROM Sales.SalesOrderDetail AS sod
WHERE sod.SalesOrderID >= 51825 AND sod.SalesOrderID <=51828 ;




--look at the LIKE condition

SELECT c.CurrencyCode
FROM Sales.Currency AS c
WHERE c.[Name] LIKE '%Ice%' ;

SELECT c.CurrencyCode
FROM Sales.Currency AS c
WHERE c.[Name] LIKE 'Ice%' ;

SELECT c.CurrencyCode
FROM Sales.Currency AS c
WHERE c.[Name] >= N'Ice'
AND c.[Name] < N'IcF' ;


--the !< vs. >=
SELECT *
FROM Purchasing.PurchaseOrderHeader AS poh
WHERE poh.PurchaseOrderID >= 2975 ;
SELECT *
FROM Purchasing.PurchaseOrderHeader AS poh
WHERE poh.PurchaseOrderID !< 2975 ;

--operator in the where clause
SELECT *
FROM Purchasing.PurchaseOrderHeader AS poh
WHERE poh.PurchaseOrderID * 2 = 3400 ;

--vs.

SELECT *
FROM Purchasing.PurchaseOrderHeader AS poh
WHERE poh.PurchaseOrderID = 3400 / 2 ;


--SUBSTRING vs. LIKE
SELECT d.Name
FROM HumanResources.Department AS d
WHERE SUBSTRING(d.[Name], 1, 1) = 'F' ;

SELECT d.Name
FROM HumanResources.Department AS d
WHERE d.[Name] LIKE 'F%' ;

--datepart comparison
IF EXISTS ( SELECT *
FROM sys.indexes
WHERE object_id = OBJECT_ID(N'[Sales].[SalesOrderHeader]')
AND name = N'IndexTest' ) DROP INDEX IndexTest ON [Sales].[SalesOrderHeader] ;
GO
CREATE INDEX IndexTest ON Sales.SalesOrderHeader(OrderDate) ;

SELECT soh.SalesOrderID,
soh.OrderDate
FROM Sales.SalesOrderHeader AS soh
JOIN Sales.SalesOrderDetail AS sod
ON soh.SalesOrderID = sod.SalesOrderID
WHERE DATEPART(yy, soh.OrderDate) = 2008
AND DATEPART(mm, soh.OrderDate) = 4;

--vs.
SELECT soh.SalesOrderID,
soh.OrderDate
FROM Sales.SalesOrderHeader AS soh
JOIN Sales.SalesOrderDetail AS sod
ON soh.SalesOrderID = sod.SalesOrderID
WHERE soh.OrderDate >= '2008-04-01'
AND soh.OrderDate < '2008-05-01' ;