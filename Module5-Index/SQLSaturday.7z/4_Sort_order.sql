SET STAtistics io on
use AdventureWorks2014
go

select Person.Person.BusinessEntityID,Person.Person.FirstName,Person.Person.LastName
from Person.Person
where FirstName='Kim'
and lastname='Ralls'

drop index [IX_Person_LastName_FirstName_MiddleName] ON [Person].[Person]

CREATE NONCLUSTERED INDEX [IX_Person_Order] ON [Person].[Person]
(
	[FirstName] ASC,
	[LastName] ASC
	
)

select Person.Person.BusinessEntityID,Person.Person.FirstName,Person.Person.LastName
from Person.Person
where FirstName='Kim'
and lastname='Ralls'

select Person.Person.BusinessEntityID
from Person.Person
where FirstName = 'Kim' 
select Person.Person.BusinessEntityID
from Person.Person
where lastname = 'Ralls'
/*

drop INDEX [IX_Person_Order] ON [Person].[Person]
go
CREATE NONCLUSTERED INDEX [IX_Person_LastName_FirstName_MiddleName] ON [Person].[Person]
(
	[LastName] ASC,
	[FirstName] ASC,
	[MiddleName] ASC
)

*/
