use [AdventureWorks2014]
go

select object_name(object_id) as TableName,name as IndexName,index_id,type,type_desc from sys.indexes where object_name(object_id) = 'Address' 

DBCC TRACEON(3604)
go
DBCC IND('AdventureWorks2014','Person.Address',1) -- dbname,indexname,indexid --Clustered index
DBCC IND('AdventureWorks2014','Person.Address',4) -- NonClustered index
--page type 1 is data page, type 2 is index page, 10 is IAM page - telling SQL about allocation
--leaf level being level 0, count down to up

DBCC PAGE('AdventureWorks2014',1,20212,3) --db name,fileid,page,output if you change it to 0 or leave it out, it only shows header, type 1 shows in raw binary 2 in hexadecimal-clustered

DBCC PAGE('AdventureWorks2014',1,8125,3)--non clustered 
--can be used to convert page id to object id e.g. in event of deadlock
--not same with compression but same with encryption

/*
in row data
Lob data
row overflow - stored like a lob

DBCC TRACEOFF(3604)
*/