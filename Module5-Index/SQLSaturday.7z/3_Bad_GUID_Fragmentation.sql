
set nocount on
go
alter database AdventureWorks2014 set recovery full
backup database AdventureWorks2014 to Adventureworks with init,compression
go
use AdventureWorks2014
go
create TABLE Manjot_Guid_Demo
(
OrderNumber uniqueidentifier default newid() rowguidcol,
OrderDate datetime default getdate(),
OrderStatus char(500) default 'NoStatus',
OrderComment varchar(max) default 'What a bad order and comment'
)
go
create clustered index CIX_GUID on Manjot_Guid_Demo(OrderNumber) 
go

create TABLE Manjot_SeqGuid_Demo
(
OrderNumber uniqueidentifier default newsequentialid() rowguidcol,
OrderDate datetime default getdate(),
OrderStatus char(500) default 'NoStatus',
OrderComment varchar(max) default 'What a bad order and comment'
)
go
create clustered index CIX_Seq_GUID on Manjot_SeqGuid_Demo(OrderNumber) 
go
 SELECT
    [AllocUnitName] AS N'Index',[Context],
    (CASE [Context]
        WHEN N'LCX_INDEX_LEAF' THEN N'Nonclustered'
        WHEN N'LCX_CLUSTERED' THEN N'Clustered'
        ELSE N'Non-Leaf'
    END) AS [SplitType],
    COUNT (1) AS [SplitCount]
FROM
    fn_dblog (NULL, NULL)
WHERE
    [Operation] = N'LOP_DELETE_SPLIT'
	
	and [Context] not like '%INTERIOR'
GROUP BY [AllocUnitName], [Context];
GO
 select
 object_schema_name(ps.object_id) as ObjectSchema,
 object_name (ps.object_id) as ObjectName,
 ps.object_id ObjectId,
 i.name as IndexName,
 ps.avg_fragmentation_in_percent,
 ps.page_count
from sys.dm_db_index_physical_stats(db_id(), null, null, null, null) ps
inner join sys.indexes i
 on i.object_id = ps.object_id and
  i.index_id = ps.index_id
where
 ps.index_id > 0
 and object_name(ps.object_id) in('Manjot_Guid_Demo','Manjot_SeqGuid_Demo')
order by avg_fragmentation_in_percent desc
--the insert takes ~30 sec to complete
 insert into Manjot_Guid_Demo default values
 go 100000
 insert into Manjot_SeqGuid_Demo default values
 go 100000


 SELECT
    [AllocUnitName] AS N'Index',[Context],
    (CASE [Context]
        WHEN N'LCX_INDEX_LEAF' THEN N'Nonclustered'
        WHEN N'LCX_CLUSTERED' THEN N'Clustered'
        ELSE N'Non-Leaf'
    END) AS [SplitType],
    COUNT (1) AS [SplitCount]
FROM
    fn_dblog (NULL, NULL)
WHERE
    [Operation] = N'LOP_DELETE_SPLIT'
	and [Context] not like '%INTERIOR'
GROUP BY [AllocUnitName], [Context];
GO
 select
 object_schema_name(ps.object_id) as ObjectSchema,
 object_name (ps.object_id) as ObjectName,
 ps.object_id ObjectId,
 i.name as IndexName,
 ps.avg_fragmentation_in_percent,
 ps.page_count
from sys.dm_db_index_physical_stats(db_id(), null, null, null, null) ps
inner join sys.indexes i
 on i.object_id = ps.object_id and
  i.index_id = ps.index_id
where
 ps.index_id > 0
 and object_name(ps.object_id) in('Manjot_Guid_Demo','Manjot_SeqGuid_Demo')
order by avg_fragmentation_in_percent desc

 /* 
 drop table Manjot_Guid_Demo
 drop table Manjot_SeqGuid_Demo
 
alter database AdventureWorks2014 set recovery simple
 */

