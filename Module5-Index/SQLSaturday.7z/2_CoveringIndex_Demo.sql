/*
Demo 1
Covering Index
*/
set statistics io on

use AdventureWorks2014
go
select * from [Person].[Person] 
where lastname ='Miller'
go
select firstname from Person.Person 
where lastname='Miller'
-- notice the cost

go
select FirstName,LastName,EmailPromotion
from 
[Person].[Person]
where LastName like 'S%' 
/*
SQL may do a index seek + lookup or a scan which ever is faster
*/

select FirstName,LastName,EmailPromotion
from 
[Person].[Person]
where LastName like 'V%' 
--Creating this index:

  CREATE NONCLUSTERED INDEX [IX_LastName_Demo]
  ON [Person].[Person] ([LastName])
  INCLUDE ([FirstName],[EmailPromotion])

go

select FirstName,LastName,EmailPromotion
from 
[Person].[Person]
where LastName like 'V%' 
go

drop index [IX_LastName_Demo] on Person.Person
-- what if I want to minimize overlapping?
-- see a matching, exiting index and alter it

DROP INDEX [IX_Person_LastName_FirstName_MiddleName] ON [Person].[Person]
GO

CREATE NONCLUSTERED INDEX [IX_Person_LastName_FirstName_MiddleName] ON [Person].[Person]
(
	[LastName] ASC,
	[FirstName] ASC,
	[MiddleName] ASC
)
INCLUDE ([EmailPromotion])
go
select FirstName,LastName,EmailPromotion
from 
[Person].[Person]
where LastName like 'V%' 


/*

DROP INDEX [IX_Person_LastName_FirstName_MiddleName] ON [Person].[Person]
GO

CREATE NONCLUSTERED INDEX [IX_Person_LastName_FirstName_MiddleName] ON [Person].[Person]
(
	[LastName] ASC,
	[FirstName] ASC,
	[MiddleName] ASC
)
*/