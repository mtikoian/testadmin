--###############################################
-- 3. NonClustered Index Demo
--###############################################
USE SQLSaturday208
GO
/* Create Sample Table */
--CREATE TABLE [dbo].[MyTable](
--[ID] [int] NOT NULL,
--[First] [nchar](10) NULL,
--[Second] [nchar](10) NULL
--) ON [PRIMARY]
--GO
/* Fill Table with Sample Data */
--INSERT INTO [dbo].[MyTable]
--([ID],[First],[Second])
--SELECT 1,'First1','Second1'
--UNION ALL
--SELECT 2,'First2','Second2'
--UNION ALL
--SELECT 3,'First3','Second3'
--UNION ALL
--SELECT 4,'First4','Second4'
--UNION ALL
--SELECT 5,'First5','Second5'
--GO


/* Create Clustered Index over Table */
--CREATE CLUSTERED INDEX [IX_MyTable_Clustered]
--ON [dbo].[MyTable]
--(
--[ID] ASC
--) ON [PRIMARY]
--GO




/* Run following two queries together and observe the
results by Enabling Actual Execution Plan (CTRL + M)
1st Query will use Clustered Index Scan
2nd Query will use Clustered Index Scan
*/
SELECT ID		-- Column that is a Clustered Index
FROM [MyTable]
WHERE First = 'First1' AND Second = 'Second1' -- Custered Index Scan
GO
SELECT Second
FROM [MyTable]
WHERE First = 'First1' AND Second = 'Second1' -- Custered Index Scan
GO 




/* Create Nonclustered Index over Table */
CREATE NONCLUSTERED INDEX [IX_MyTable_NonClustered]
ON [dbo].[MyTable]
(
[First] ASC,	-- Note: columns Order is very important.
[Second] ASC
) ON [PRIMARY]
GO






/* Re-Run following two queries together and observe the
results by Enabling Actual Execution Plan (CTRL + M)
1st Query will use Index Seek
2nd Query will use Index Seek
*/
SELECT ID		-- Column that is a Clustered Index
FROM [MyTable]
WHERE First = 'First1' AND Second = 'Second1' -- Index Seek (NonClustered)
GO
SELECT Second	-- Column that is part of a NonClustered Index
FROM [MyTable]
WHERE First = 'First1' AND Second = 'Second1' -- Index Seek (NonClustered)
GO 



--/* Clean up */
--DROP TABLE [dbo].[MyTable]
--GO 