 --###############################################
-- 4 Covering Index and Filtered Index Demo
--###############################################

 --###############################################
-- 4.1 Covering Index Demo
--###############################################

--------------------------
-- Clean Up
IF EXISTS (SELECT name FROM sysindexes WHERE name = 'IX_SalesOrderDetail_CarrierTrackingNumber')
BEGIN
	DROP INDEX [IX_SalesOrderDetail_CarrierTrackingNumber]
		ON [Sales].[SalesOrderDetail]
END
GO
--------------------------



USE AdventureWorks2008R2
GO

-- Before Covering Index
--TODO: Record logical read = ???? (1240)
SET STATISTICS IO ON
SELECT  SalesOrderID,
        CarrierTrackingNumber,
        OrderQty,
        ProductID,
        UnitPrice
FROM    Sales.SalesOrderDetail
WHERE   CarrierTrackingNumber LIKE '%98'
SET STATISTICS IO OFF
GO

-- Create Covering Index
CREATE NONCLUSTERED INDEX [IX_SalesOrderDetail_CarrierTrackingNumber]
ON [Sales].[SalesOrderDetail] ( [CarrierTrackingNumber] ASC )
    INCLUDE ( SalesOrderID, OrderQty, ProductID, UnitPrice )
--WITH (DROP_EXISTING = ON)	-- because the index doesn't exist yet
ON  [PRIMARY]
GO

-- After Covering Index
--TODO: Record logical read = ??? (640)
SET STATISTICS IO ON
SELECT  SalesOrderID,
        CarrierTrackingNumber,
        OrderQty,
        ProductID,
        UnitPrice
FROM    Sales.SalesOrderDetail
WHERE   CarrierTrackingNumber LIKE '%98'
SET STATISTICS IO OFF
GO



--###############################################
-- 4.2. Filtered Index Demo
--###############################################


-- Create a Filtered Index
CREATE NONCLUSTERED INDEX [IX_SalesOrderDetail_CarrierTrackingNumber]
ON [Sales].[SalesOrderDetail] ( [CarrierTrackingNumber] ASC )
    INCLUDE ( SalesOrderID, OrderQty, ProductID, UnitPrice )
WHERE [CarrierTrackingNumber] IS NOT NULL -- Place a filter
WITH (DROP_EXISTING = ON)	-- because this index is already exists.
ON  [PRIMARY]
GO

-- After Filtered Index
--TODO: Record logical read = ??? (429)
--TODO: Overall Logical Read Improvments = (~%33 after creating the filtered index and ~%65 before creating the NonClusterd Covering Index) 
SET STATISTICS IO ON
SELECT  SalesOrderID,
        CarrierTrackingNumber,
        OrderQty,
        ProductID,
        UnitPrice
FROM    Sales.SalesOrderDetail
WHERE   CarrierTrackingNumber LIKE '%98'
SET STATISTICS IO OFF
GO

