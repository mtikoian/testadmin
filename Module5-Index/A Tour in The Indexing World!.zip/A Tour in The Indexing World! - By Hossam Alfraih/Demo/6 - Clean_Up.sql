--###############################################
-- 6. Clean Up Objects Used in Demoes
--###############################################
USE SQLSaturday208
GO


/* Clean up */
DROP TABLE TBL_CUSTOMERS
DROP TABLE [dbo].[MyTable]
GO 

/*
-- or just
ALTER DATABASE [SQLSaturday208]
SET OFFLINE
WITH ROLLBACK IMMEDIATE
GO
DROP DATABASE [SQLSaturday208]
GO
*/
