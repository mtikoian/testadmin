--###############################################
-- 1. Heap Demo
--###############################################
 
 /** 1. Prepare Demo Database **/
 -- A) Creare New Database
CREATE DATABASE SQLSaturday208
GO

-- B) Use Demo Database
USE SQLSaturday208
GO




/** 2. Prepare a Heap **/

-- A) Create Heap
CREATE TABLE TBL_CUSTOMERS
(
ID INT IDENTITY(1,1), -- NO PK
FIRST_NAME NVARCHAR(50) ,
LAST_NAME NVARCHAR(50) ,
EMAIL  UNIQUEIDENTIFIER DEFAULT(NEWID()),
PHONE UNIQUEIDENTIFIER DEFAULT(NEWID()),
MOBILE UNIQUEIDENTIFIER DEFAULT (NEWSEQUENTIALID())
)
GO


-- B) Insert 10,000 records
SET NOCOUNT ON
INSERT INTo TBL_CUSTOMERS (FIRST_NAME, LAST_NAME) values ('Hossam','Alfraih')
GO 10000
SET NOCOUNT OFF




/** 3. Alway Table Scan **/
-- TODO: Include Actual Execution Plan (Ctl+M)

-- A) All Table
SELECT * FROM TBL_CUSTOMERS
GO 

-- B) Specific Record
SELECT * FROM TBL_CUSTOMERS WHERE ID = 1000
GO
--Q) Why we still have Table Scan not Index Seek?
--Q) Why we did not create index on ID?



/** 4. Space Re-Use **/
-- A) Check Logical Data Read
-- TODO: Logical Data Read = ??? (121)

SET STATISTICS IO ON
SELECT * FROM TBL_CUSTOMERS
SET STATISTICS IO OFF

-- B) Delete some data (~77%)
DELETE TBL_CUSTOMERS WHERE ID % 2 = 0
DELETE TBL_CUSTOMERS WHERE ID % 3 = 0
DELETE TBL_CUSTOMERS WHERE ID % 5 = 0
DELETE TBL_CUSTOMERS WHERE ID % 7 = 0
GO


-- C) Re-Check Logical Data Read
-- TODO: Logical Data Read = ??? (121) = same (no compacting = no performance deg.)

SET STATISTICS IO ON
SELECT * FROM TBL_CUSTOMERS
SET STATISTICS IO OFF


-- D) Compact Heap Strcture (2008+) 
-- ReBuilding The Heap
-- Tip: you can do it either in memory or in TempDB (SORT_IN_TEMPDB = ON).
ALTER TABLE TBL_CUSTOMERS REBUILD WITH (ONLINE = ON)
GO

-- E) Re-Check Logical Data Read
-- TODO: Logical Data Read = ??? (27)
SET STATISTICS IO ON
SELECT * FROM TBL_CUSTOMERS
SET STATISTICS IO OFF


/* Clean up */
--DROP TABLE TBL_CUSTOMERS
--GO 


