--###############################################
-- 2. Clustered Index Demo
--###############################################
USE SQLSaturday208
GO
/* Create Sample Table (Without Clustered Index)*/
CREATE TABLE [dbo].[MyTable](
[ID] [int] NOT NULL, 
[First] [nchar](10) NULL,
[Second] [nchar](10) NULL
) ON [PRIMARY]
GO


/* Fill Table with Sample Data */
INSERT INTO [dbo].[MyTable]
([ID],[First],[Second])
SELECT 1,'First1','Second1'
UNION ALL
SELECT 2,'First2','Second2'
UNION ALL
SELECT 3,'First3','Second3'
UNION ALL
SELECT 4,'First4','Second4'
UNION ALL
SELECT 5,'First5','Second5'
GO




/* Selecting a specific record */
-- A) Before Index
-- TODO: Include Actual Execution Plan (Ctl+M)
SELECT	First, Second
FROM	dbo.MyTable
WHERE	ID = 3 -- Table Scan





/* Create Clustered Index over Table */
CREATE CLUSTERED INDEX [IX_MyTable_Clustered]
ON [dbo].[MyTable]
(
[ID] ASC
) ON [PRIMARY]
GO





/* Selecting a specific record */
-- B) After Index
SELECT	First, Second
FROM	dbo.MyTable
WHERE	ID = 3 -- Clustered Index Seek




/* Clean up (don't clean up if you are going to do the NonClustered Index Demo) */
--DROP TABLE [dbo].[MyTable]
--GO 