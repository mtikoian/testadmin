--###############################################
-- 5. Index Usage Stats Demo
--###############################################
USE SQLSaturday208
GO

/* Index activity and Last Performaed Time : sys.dm_db_index_usage_stats */
select object_schema_name(indexes.object_id) + '.' + object_name(indexes.object_id) as objectName,
indexes.type_desc,ius.user_seeks, ius.user_scans,ius.user_lookups, ius.user_updates from sys.indexes
left outer join sys.dm_db_index_usage_stats ius
                        on indexes.object_id = ius.object_id
                             and indexes.index_id = ius.index_id
                             and ius.database_id = db_id('SQLSaturday208')

WHERE USER_SCANS IS NOT NULL OR USER_SEEKS IS NOT NULL -- to filter data

GO



/* Clean up */
--DROP TABLE [dbo].[MyTable]
--GO 
