--� 2018 | ByrdNest Consulting

--log into production database and run next three queries

USE ROICore
GO

--Index usage
--  FROM http://www.sqlservercentral.com/scripts/Tuning/61886/
SELECT object_name(a.[object_id]) AS 'table',
		c.name "index",
		(SELECT used/128 FROM sysindexes b WHERE b.name=c.name and c.index_id = b.indid) 'MB',
		(SELECT count(*) FROM sys.index_columns d WHERE a.object_id = d.object_id and a.index_id = d.index_id and d.is_included_column = 0) "cols",
		(SELECT count(*) FROM sys.index_columns d WHERE a.object_id = d.object_id and a.index_id = d.index_id and d.is_included_column = 1) "included",
		(a.user_seeks + a.user_scans + a.user_lookups) "hits",
		(a.user_updates) "updates",
		a.last_user_update "stats_date",
		CAST(a.user_seeks + a.user_scans + a.user_lookups AS REAL) / cast(case a.user_updates when 0 then 1 else a.user_updates end AS REAL) * 100 "ratio",
		'alter index [' + c.name + '] on [' + object_name(a.object_id) + '] disable;' "SQLCmd"
	FROM sys.dm_db_index_usage_stats a
	JOIN sysobjects AS o
	  ON (a.object_id = o.id)
	JOIN sys.indexes AS c
	  ON (a.object_id = c.object_id and a.index_id = c.index_id)
	WHERE o.type = 'U'					-- exclude system tables
	  and c.is_unique = 0				-- no unique indexes
	  and c.type = 2					-- nonclustered indexes only
	  and c.is_primary_key = 0			-- no primary keys
	  and c.is_unique_constraint = 0	-- no unique constraints
	  and c.is_disabled = 0				-- only active indexes
	  and a.database_id = DB_ID()		-- for current database only
GO


--Find Unused Indexes of CurrentDatabase
DECLARE @dbid INT
SELECT @dbid = DB_ID(DB_NAME())
SELECT OBJECTNAME = OBJECT_NAME(I.OBJECT_ID),
		INDEXNAME = I.NAME,
		I.INDEX_ID
	FROM SYS.INDEXES I
	JOIN SYS.OBJECTS O
	  ON I.OBJECT_ID = O.OBJECT_ID
	WHERE OBJECTPROPERTY(O.OBJECT_ID,'IsUserTable') = 1
	  AND I.is_primary_key = 0
	  AND I.INDEX_ID NOT IN (SELECT S.INDEX_ID
								FROM SYS.DM_DB_INDEX_USAGE_STATS S
								WHERE S.OBJECT_ID = I.OBJECT_ID
								  AND I.INDEX_ID = S.INDEX_ID
								  AND DATABASE_ID = @dbid)
	ORDER BY OBJECTNAME,I.INDEX_ID,INDEXNAME ASC
GO

--missing indexes
SELECT
  migs.avg_total_user_cost * (migs.avg_user_impact / 100.0) * (migs.user_seeks + migs.user_scans) AS improvement_measure,
  'CREATE INDEX [missing_index_' + CONVERT (varchar, mig.index_group_handle) + '_' + CONVERT (varchar, mid.index_handle)
  + '_' + LEFT (PARSENAME(mid.statement, 1), 32) + ']'
  + ' ON ' + mid.statement
  + ' (' + ISNULL (mid.equality_columns,'')
    + CASE WHEN mid.equality_columns IS NOT NULL AND mid.inequality_columns IS NOT NULL THEN ',' ELSE '' END
    + ISNULL (mid.inequality_columns, '')
  + ')'
  + ISNULL (' INCLUDE (' + mid.included_columns + ')', '') AS create_index_statement,
  migs.*, mid.database_id, mid.[object_id]
FROM sys.dm_db_missing_index_groups mig
INNER JOIN sys.dm_db_missing_index_group_stats migs ON migs.group_handle = mig.index_group_handle
INNER JOIN sys.dm_db_missing_index_details mid ON mig.index_handle = mid.index_handle
WHERE migs.avg_total_user_cost * (migs.avg_user_impact / 100.0) * (migs.user_seeks + migs.user_scans) > 10
ORDER BY migs.avg_total_user_cost * migs.avg_user_impact * (migs.user_seeks + migs.user_scans) DESC


--need to be careful of these queries, looks back to last time sql server was started; could be misleading


--in any case consider disabling rather than deleting an index.  Can go back later and delete as necessary
--to re-enable an index, you just need to rebuild it.

--script to remove hypothetical indexes (left over from tuning wizard
WHILE EXISTS (SELECT * FROM sys.indexes WHERE is_hypothetical = 1) 
BEGIN 
DECLARE @sql varchar(max) 
SELECT @sql = 'drop index ' + indexname + ' on [' + tablename + ']' 
FROM (
SELECT TOP 1 indexname = i.name, tablename = o.name 
FROM sys.indexes i 
INNER JOIN sys.objects o 
ON i.object_id = o.object_id 
WHERE i.is_hypothetical = 1 and o.type = 'u'
) x 
SELECT @sql 
EXEC (@sql) 
END 
GO 

--script to remove hypothetical statistics left over from tuning wizard
WHILE EXISTS (SELECT * FROM sys.stats i WHERE OBJECTPROPERTY(i.[object_id],'IsUserTable') = 1 AND i.[name] LIKE '_dta%' and user_created = 0) 
BEGIN 
DECLARE @sql varchar(max) 
SELECT @sql = 'drop statistics [' + object_name(i.[object_id]) + '].['+ i.[name] + ']' 
FROM sys.stats i 
WHERE 
OBJECTPROPERTY(i.[object_id],'IsUserTable') = 1 AND 
i.[name] LIKE '_dta%' and user_created = 0 
SELECT @sql 
EXEC (@sql) 
END
