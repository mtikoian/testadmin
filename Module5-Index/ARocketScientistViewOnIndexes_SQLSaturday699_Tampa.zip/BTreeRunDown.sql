--� 2018 | ByrdNest Consulting
--BTree Demo

--start with clean copy of AdventureWorkw2012
USE [master]
ALTER DATABASE [AdventureWorks2012] SET SINGLE_USER WITH ROLLBACK IMMEDIATE		--kick off all users except me
RESTORE DATABASE [AdventureWorks2012] 
	FROM  DISK = N'D:\Misc\AdventureWorks2012\AdventureWorks2012.bak' WITH  FILE = 1,
	NOUNLOAD,  REPLACE,  STATS = 20
ALTER DATABASE [AdventureWorks2012] SET MULTI_USER								--set back to multi-user
GO
ALTER AUTHORIZATION ON DATABASE::AdventureWorks2012 TO sa;						--give ownership to sa; not me
GO

USE AdventureWorks2012
GO

/*
CREATE NONCLUSTERED INDEX IDX_SalesOrderDetail_ModifiedDate on Sales.SalesOrderDetail(ModifiedDate)
	INCLUDE (SalesOrderID,SalesOrderDetailID,CarrierTrackingNumber,OrderQty, ProductID,
			 SpecialOfferID,UnitPrice,UnitPriceDiscount,LineTotal,rowguid)
--	WITH (DROP_EXISTING = ON, ONLINE = ON)
*/GO
CREATE NONCLUSTERED INDEX IDX_SalesOrderDetail_ModifiedDate2 on Sales.SalesOrderDetail(ModifiedDate)
	INCLUDE (CarrierTrackingNumber,OrderQty, ProductID,
			 SpecialOfferID,UnitPrice,UnitPriceDiscount,LineTotal,rowguid)
--	WITH (DROP_EXISTING = ON, ONLINE = ON)
GO

SELECT ID,Name,Dpages,reserved,used,rowcnt,indid
	FROM sys.sysindexes
	WHERE [Name] IN (/*'IDX_SalesOrderDetail_ModifiedDate',*/'IDX_SalesOrderDetail_ModifiedDate2');
GO
--indid = 5

SELECT allocated_page_page_id, page_type_desc,page_level
	FROM sys.dm_db_database_page_allocations (DB_ID(), OBJECT_ID('Sales.SalesOrderDetail'), 5,1,'Detailed')
	WHERE page_level IS NOT NULL
	ORDER BY page_type_desc, page_level DESC
GO

/*	Root (in this case) at page level 2, page 24280
	Intermediate level (1)  - 8 boundaries
	Leaf level (0) - 1456 nodes
*/

/*	--almost same results as above SELECT
DBCC IND('AdventureWorks2012','Sales.SalesOrderDetail',-1)
GO
*/

SELECT TOP 1 ModifiedDate,SalesOrderID,SalesOrderDetailID FROM Sales.SalesOrderDetail ORDER BY 1 ASC, 2 ASC, 3 ASC;
/*
ModifiedDate			SalesOrderID	SalesOrderDetailID
2005-07-01 00:00:00.000	43659			1
*/

--first page in index 5 (IAM Page)
DBCC TRACEON(3604)
DBCC PAGE('AdventureWorks2012',1,23816,3) WITH TABLERESULTS		--note row 59 Field 1:24280
GO
DBCC TRACEOFF(3604)
GO

--root node page for index 5
DBCC TRACEON(3604)
DBCC PAGE('AdventureWorks2012',1,24280,3) WITH TABLERESULTS		--check 2nd result set; note ChildPageID for ModifiedDate NULL (2005-07-01 < 2006-08-02
GO
DBCC TRACEOFF(3604)
GO
--	ignore first result set (metadata); looking at 2nd result set 
--	note index columns (ModifiedDate, SalesOrderID, SalesOrderDetailID); CI included even though not specified in index declaration
--	note childpage for {NULL,NULL,NULL} boundary


/*
Look at ModifiedDate breaks (note ChildPageID not in numeric order)
NULL
2006-08-02
2007-05-03
2007-09-02
2007-11-17
2008-01-23
2008-03-31
2008-06-01
*/
--Look at Columns in root level:  ModifiedDate, SalesOrderID, SalesOrderDetailID (last two PKs)





--intermediate page for index 5 (traveling down the N{ULL,NULL,NULL} left boundary) 
DBCC TRACEON(3604)
DBCC PAGE('AdventureWorks2012',1,24600,3) WITH TABLERESULTS		--check 2nd result set; Data for SalesOrderDetailID = 1
GO
DBCC TRACEOFF(3604)
GO
--206 rows (boundaries) in intermendiate level (still with ModifiedDate,SalesOrderID, and SalesOrderDetailID)

--again traversing {NULL,NULL,NULL} boundary (page 24512)
--leaf page for index 5
DBCC TRACEON(3604)
DBCC PAGE('AdventureWorks2012',1,24512,3) WITH TABLERESULTS		--check 2nd result set; Data for SalesOrderDetailID = 1
GO
DBCC TRACEOFF(3604)
GO
--73 rows of index data on this particular page.
--note all row data on this page; note also that Primary Key is there, but not repeated.

--real geeky article on b-tree traversal at https://logicalread.com/laymans-guide-climbing-sql-server-index-b-tree-part-1/ by Mike Byrd

--also will be presenting "Climbing the SQL Server Index B-Tree (from a user perspective)" at SQL Saturday 726 (Phoenix) and SQL Saturday 700 (Colorado Springs)

