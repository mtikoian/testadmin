--� 2018 | ByrdNest Consulting
--example of separate PK and clustered index

USE [AdventureWorks2012]
GO
IF OBJECT_ID(N'Sales.SalesOrderHeader2') IS NOT NULL DROP TABLE Sales.SalesOrderHeader2
GO


CREATE TABLE [Sales].[SalesOrderHeader2](
	[SalesOrderID] [int] IDENTITY(1,1) NOT FOR REPLICATION NOT NULL,
	[RevisionNumber] [tinyint] NOT NULL CONSTRAINT [DF_SalesOrderHeader2_RevisionNumber]  DEFAULT ((0)),
	[OrderDate] [datetime] NOT NULL CONSTRAINT [DF_SalesOrderHeader2_OrderDate]  DEFAULT (getdate()),
	[DueDate] [datetime] NOT NULL,
	[ShipDate] [datetime] NULL,
	[Status] [tinyint] NOT NULL CONSTRAINT [DF_SalesOrderHeader2_Status]  DEFAULT ((1)),
	[OnlineOrderFlag] [dbo].[Flag] NOT NULL CONSTRAINT [DF_SalesOrderHeader2_OnlineOrderFlag]  DEFAULT ((1)),
	[SalesOrderNumber]  AS (isnull(N'SO'+CONVERT([nvarchar](23),[SalesOrderID]),N'*** ERROR ***')),
	[PurchaseOrderNumber] [dbo].[OrderNumber] NULL,
	[AccountNumber] [dbo].[AccountNumber] NULL,
	[CustomerID] [int] NOT NULL,
	[SalesPersonID] [int] NULL,
	[TerritoryID] [int] NULL,
	[BillToAddressID] [int] NOT NULL,
	[ShipToAddressID] [int] NOT NULL,
	[ShipMethodID] [int] NOT NULL,
	[CreditCardID] [int] NULL,
	[CreditCardApprovalCode] [varchar](15) NULL,
	[CurrencyRateID] [int] NULL,
	[SubTotal] [money] NOT NULL CONSTRAINT [DF_SalesOrderHeader2_SubTotal]  DEFAULT ((0.00)),
	[TaxAmt] [money] NOT NULL CONSTRAINT [DF_SalesOrderHeader2_TaxAmt]  DEFAULT ((0.00)),
	[Freight] [money] NOT NULL CONSTRAINT [DF_SalesOrderHeader2_Freight]  DEFAULT ((0.00)),
	[TotalDue]  AS (isnull(([SubTotal]+[TaxAmt])+[Freight],(0))),
	[Comment] [nvarchar](128) NULL,
	[rowguid] [uniqueidentifier] ROWGUIDCOL  NOT NULL CONSTRAINT [DF_SalesOrderHeader2_rowguid]  DEFAULT (newid()),
	[ModifiedDate] [datetime] NOT NULL CONSTRAINT [DF_SalesOrderHeader2_ModifiedDate]  DEFAULT (getdate()),
	ModifiedDateKey AS CONVERT(INT,CONVERT(VARCHAR(25),ModifiedDate,112)) PERSISTED,
 CONSTRAINT [PK_SalesOrderHeader2_SalesOrderID] PRIMARY KEY NONCLUSTERED				--note NONCLUSTERED for PK
	([SalesOrderID] ASC))
GO
--see Object Explorer

--may not want to use ModifiedDateKey in production; 
--	changes may cause data movement (maybe in partition movement)
CREATE CLUSTERED INDEX CIDX_SaleOrderHeader22 
	ON Sales.SalesOrderHeader2(ModifiedDateKey,SalesOrderID)   --change in naming convention
GO
--see Object Explorer

--clean up
/*
IF OBJECT_ID(N'Sales.SalesOrderHeader2') IS NOT NULL DROP TABLE Sales.SalesOrderHeader2
GO
*/