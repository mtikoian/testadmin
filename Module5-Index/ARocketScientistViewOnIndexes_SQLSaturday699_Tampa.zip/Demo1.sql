--� 2018 | ByrdNest Consulting
--Index examples

--start with clean copy of AdventureWorkw2012
USE [master]
ALTER DATABASE [AdventureWorks2012] SET SINGLE_USER WITH ROLLBACK IMMEDIATE		--kick off all users except me
RESTORE DATABASE [AdventureWorks2012] 
	FROM  DISK = N'D:\Misc\AdventureWorks2012\AdventureWorks2012.bak' WITH  FILE = 1,
	NOUNLOAD,  REPLACE,  STATS = 10
ALTER DATABASE [AdventureWorks2012] SET MULTI_USER								--set back to multi-user
GO
ALTER AUTHORIZATION ON DATABASE::AdventureWorks2012 TO sa;						--give ownership to sa; not me
GO

USE AdventureWorks2012
GO


IF OBJECT_ID(N'dbo.HeapExample') IS NOT NULL DROP TABLE dbo.HeapExample
GO
CREATE TABLE dbo.HeapExample(				--same structure as Sales.Currency in AdventureWorks2012 except no PK
	CurrencyCode	NVARCHAR(3) NOT NULL,
	[Name]			NVARCHAR(50) NOT NULL,
	ModifiedDate	DATETIME NOT NULL CONSTRAINT DF_Currency_ModifiedDate  DEFAULT (getdate()) )
GO

INSERT dbo.HeapExample				--since no PK, SS uses a row identifier to uniquely address each row 
									--(consisting of the file number, data page number, and slot on the page). -- very efficient 
	(CurrencyCode, [Name])
	SELECT CurrencyCode, [Name]
		FROM Sales.Currency
GO
--see Object Explorer

sp_help 'dbo.HeapExample';
GO
sp_help 'Sales.Currency';
GO

IF OBJECT_ID(N'dbo.PKexample') IS NOT NULL DROP TABLE dbo.PKexample
GO

--PK in table definition
CREATE TABLE dbo.PKexample(
	CurrencyCode nchar(3) NOT NULL,
	[Name] NVARCHAR(50) NOT NULL,
	ModifiedDate datetime NOT NULL CONSTRAINT DF_Currency2_ModifiedDate  DEFAULT (getdate()),
 CONSTRAINT PK_Currency_CurrencyCode PRIMARY KEY CLUSTERED			--Clustered is default; don't have to specify
	(CurrencyCode ASC) )
GO
--see Object Explorer

--Option 2; defining PK at column definition
IF OBJECT_ID(N'dbo.PKexample') IS NOT NULL DROP TABLE dbo.PKexample
GO
--PK in table definition, but do not get to name it -- see SSMS
CREATE TABLE dbo.PKexample(
	CurrencyCode nchar(3) NOT NULL PRIMARY KEY CLUSTERED,			--note that CLUSTERED is optional (default)
	[Name] NVARCHAR(50) NOT NULL,
	ModifiedDate datetime NOT NULL CONSTRAINT DF_Currency2_ModifiedDate  DEFAULT (getdate()) )
GO
--see Object Explorer

--Option 2b; defining PK at column definition
IF OBJECT_ID(N'dbo.PKexample') IS NOT NULL DROP TABLE dbo.PKexample
GO
--PK in table definition, but can name it -- see SSMS
CREATE TABLE dbo.PKexample(
	CurrencyCode nchar(3) NOT NULL CONSTRAINT PK_Currency_Code PRIMARY KEY,
	[Name] NVARCHAR(50) NOT NULL,
	ModifiedDate datetime NOT NULL CONSTRAINT DF_Currency2_ModifiedDate  DEFAULT (getdate()) )
GO
--see Object Explorer

--Option 3; defining PK after the table definition
IF OBJECT_ID(N'dbo.PKexample') IS NOT NULL DROP TABLE dbo.PKexample
GO
--PK defined after table definition
CREATE TABLE dbo.PKexample(
	CurrencyCode nchar(3) NOT NULL,
	[Name] NVARCHAR(50) NOT NULL,
	ModifiedDate datetime NOT NULL CONSTRAINT DF_Currency2_ModifiedDate  DEFAULT (getdate()) )
GO
--see Object Explorer
ALTER TABLE dbo.PKexample		-- can also use this to add PK to existing table
	ADD CONSTRAINT PK_Currency_CurrencyCode PRIMARY KEY CLUSTERED (CurrencyCode)
--see Object Explorer
GO

INSERT dbo.PKexample
	(CurrencyCode, [Name])
	SELECT CurrencyCode, [Name]
		FROM Sales.Currency;
GO
sp_help PKexample
GO

--clean up new tables
IF OBJECT_ID(N'dbo.HeapExample') IS NOT NULL DROP TABLE dbo.HeapExample
GO
IF OBJECT_ID(N'dbo.PKexample') IS NOT NULL DROP TABLE dbo.PKexample
GO

/*****************show example of differing PK and Clustered Index*********/
--	see Demo1.5.sql

--now look at nonclustered indexes
--create nonclustered index

USE [AdventureWorks2012]
GO

IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_SalesOrderHeader_SalesPersonID')
	DROP INDEX IX_SalesOrderHeader_SalesPersonID ON Sales.SalesOrderHeader;
GO
CREATE NONCLUSTERED INDEX IX_SalesOrderHeader_SalesPersonID ON Sales.SalesOrderHeader
	([SalesPersonID] ASC)							--I rarely have single column indexes -- rarely used!
	WITH (ONLINE = ON, DATA_COMPRESSION = ROW);		--only available in Developer/Enterprise versions (or higher) and SS2016 SP1 (Standard Edition)
GO
--note index name (standardization):  IX_tablename_columname


--turn on include actual execution plan (Ctrl-M)
SET STATISTICS IO,TIME ON			--poor man's profiler; I use all the time for performance tuning
GO
SELECT SalesOrderID, AccountNumber, CustomerID			--note scan of clustered PK
	FROM Sales.SalesOrderHeader
	WHERE SalesPersonID = 277
	ORDER BY 1
GO
SET STATISTICS IO,TIME OFF
GO

--(473 row(s) affected)
--query cost = 0.545; 689 logical reads
--note clustered index scan; why didn't it use IX_SalesOrderHeader_SalesPersonID
GO



SET STATISTICS IO,TIME ON
GO
SELECT SalesOrderID, AccountNumber, CustomerID		--note seek of index (IX_SalesOrderHeader_SalesPersonID), but resulting Key Lookup
	FROM Sales.SalesOrderHeader
	WHERE SalesPersonID = 285
	ORDER BY 1
GO
SET STATISTICS IO,TIME OFF
GO
--(16 row(s) affected)
--query cost = 0.052; 50 logical reads

--why difference in query plans????

--Nonclustered index selection tends to be more effective if less than 5% of the data is to be accessed


--covering indexes (adds all columns needed in query (PK automatically included)
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_SalesOrderHeader_SalesPersonID')
	DROP INDEX IX_SalesOrderHeader_SalesPersonID ON Sales.SalesOrderHeader
GO
CREATE NONCLUSTERED INDEX IX_SalesOrderHeader_SalesPersonID ON Sales.SalesOrderHeader
	([SalesPersonID] ASC)
	INCLUDE (AccountNumber, CustomerID)				--why is this a covering index?  why isn't PK in definition???
	WITH (ONLINE = ON, DATA_COMPRESSION = ROW)		--can only use this line in Enterprise version (also Developer, 
													--	but now also Data_Compression but not ONLINE in Standard (SS2016, SP1))
GO

SET STATISTICS IO,TIME ON
GO
SELECT SalesOrderID, AccountNumber, CustomerID			--now index seek (because the index is "convering")
	FROM Sales.SalesOrderHeader
	WHERE SalesPersonID = 277
	ORDER BY 1
GO
SET STATISTICS IO,TIME OFF
GO
--(473 row(s) affected)
--query cost = 0.005; 5 logical reads


SET STATISTICS IO,TIME ON
GO
SELECT SalesOrderID, AccountNumber, CustomerID
	FROM Sales.SalesOrderHeader
	WHERE SalesPersonID = 285
	ORDER BY 1
GO
SET STATISTICS IO,TIME OFF
GO
--(16 row(s) affected)
--query cost = 0.005; 3 logical reads

--note now both queries use same query plan with the covered index
GO
-- be careful with covering indexes; don't want to recreate whole table (keep index narrow)



--turn on include actual execution plan (CTRL-M)
--example of suggested index
SET STATISTICS IO,TIME ON
GO
SELECT SalesOrderID, RevisionNumber,TerritoryID, ModifiedDate
	FROM Sales.SalesOrderHeader
	WHERE ModifiedDate BETWEEN '1/1/2007' AND '12/31/2007'
GO
SET STATISTICS IO,TIME OFF
GO
--query cost is 0.545; 689 logical reads

--show missing index
/*
CREATE NONCLUSTERED INDEX [<Name of Missing Index, sysname,>]
ON [Sales].[SalesOrderHeader] ([ModifiedDate])
INCLUDE ([SalesOrderID],[RevisionNumber],[TerritoryID])
GO
--need to be careful of Microsoft suggested indexes; usally include PK; also may nearly duplicate an existing index!!!
--check Object Explorer to see if index on ModifiedDate already exists -- if so, consider combining the two indexes
*/


IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IDX_SalesOrderHeader_ModifiedDate')
	DROP INDEX IDX_SalesOrderHeader_ModifiedDate ON Sales.SalesOrderHeader
GO
CREATE NONCLUSTERED INDEX IDX_SalesOrderHeader_ModifiedDate
	ON [Sales].[SalesOrderHeader] ([ModifiedDate])
	INCLUDE ([RevisionNumber],[TerritoryID])
	WITH (ONLINE = ON, DATA_COMPRESSION = ROW);			--can only use these with Developer,Enterprise, or Data Center or Standard Edition SS 2016, SP1
GO

--now rerun query
SET STATISTICS IO,TIME ON
GO
SELECT SalesOrderID, RevisionNumber,TerritoryID, ModifiedDate
	FROM Sales.SalesOrderHeader
	WHERE ModifiedDate BETWEEN '1/1/2007' AND '12/31/2007'
GO
SET STATISTICS IO,TIME OFF
GO
--now query cost only 0.038; logical reads = 33

--now compare queries and query plans
CHECKPOINT;						--ensures dirty buffer pages are written and then used by DROPCLEANBUFFERS
DBCC DROPCLEANBUFFERS			--don't use this in production database
GO
SET STATISTICS IO,TIME ON;
SELECT SalesOrderID, RevisionNumber,TerritoryID, ModifiedDate
	FROM Sales.SalesOrderHeader
	WHERE ModifiedDate BETWEEN '1/1/2007' AND '12/31/2007';
PRINT '***********'
CHECKPOINT;
DBCC DROPCLEANBUFFERS			--don't use this in production database
SELECT SalesOrderID, RevisionNumber,TerritoryID, ModifiedDate
	FROM Sales.SalesOrderHeader WITH (INDEX (PK_SalesOrderHeader_SalesOrderID))		--index hint
	WHERE ModifiedDate BETWEEN '1/1/2007' AND '12/31/2007';
SET STATISTICS IO,TIME OFF;
GO



--example where query has to do a table scan
SELECT p.LastName,soh.*
	From Sales.SalesOrderHeader soh
	JOIN Sales.Customer c
	  ON c.CustomerID = soh.CustomerID
	JOIN Person.Person p
	  ON p.BusinessEntityID = c.PersonID
	WHERE p.LastName LIKE '%B%'		--impossible to create index for leading wild card

--note query plan asking for index on Sales.Customer (ID_Customer_PersonID)

--example where index can be used
SELECT p.LastName,soh.*
	From Sales.SalesOrderHeader soh
	JOIN Sales.Customer c
	  ON c.CustomerID = soh.CustomerID
	JOIN Person.Person p
	  ON p.BusinessEntityID = c.PersonID
	WHERE p.LastName LIKE 'B%'


--discuss suggested missing index -- note CustomerID is not needed (may need to consider other queries for covering index)
IF EXISTS (SELECT 1 FROM sys.indexes where name = 'IX_Customer_PersonID') DROP INDEX IX_Customer_PersonID ON Sales.Customer
GO
CREATE NONCLUSTERED INDEX IX_Customer_PersonID on Sales.Customer (PersonID)
	WITH (ONLINE = ON, DATA_COMPRESSION = ROW);
GO


--now look at query plan from above query
SELECT p.LastName,soh.*
	From Sales.SalesOrderHeader soh
	JOIN Sales.Customer c
	  ON c.CustomerID = soh.CustomerID
	JOIN Person.Person p
	  ON p.BusinessEntityID = c.PersonID
	WHERE p.LastName LIKE 'B%'


--clean up
IF EXISTS (SELECT 1 FROM sys.indexes where name = 'IX_Customer_PersonID') DROP INDEX IX_Customer_PersonID ON Sales.Customer
GO



--now let's just look at a query and see if we can determine what indexes are needed

SELECT p.FirstName, p.LastName,h.SalesOrderID,prod.[Name] ProductName,d.LineTotal, h.ShipDate
	FROM Sales.SalesOrderHeader h
	JOIN Sales.SalesOrderDetail d
	  ON d.SalesOrderID = h.SalesOrderID
	JOIN Sales.Customer c
	  ON c.CustomerID = h.CustomerID
	JOIN Person.Person p
	  on p.BusinessEntityID = h.SalesPersonID
	JOIN Production.Product prod
	  ON prod.ProductID = d.ProductID
	WHERE h.OrderDate >= '1/1/2006'
	  AND h.OrderDate <  '6/30/2006'
GO

 
/*
Now look at each table
	SalesOrderHeader:	SalesOrderID, OrderDate,ShipDate,SalesPersonID,CustomerID
	SalesOrderDetail:	SalesOrderID, ProductID, LineTotal (Computed: OrderQty*UnitPrice*UnitPriceDiscount)
	Customer:			CustomerID
	Person:				BusinessEntityID, FirstName, LastName
	Product:			ProductID, Name

What indexes are needed for this query?
*/

--check to see if index already exists

/*
CREATE INDEX IDX_SalesOrderHeader_OrderDate ON Sales.SalesOrderHeader(OrderDate) INCLUDE(ShipDate,SalesPersonID,CustomerID)
	WITH (ONLINE=ON, DATA_COMPRESSION = ROW)
GO

CREATE NONCLUSTERED INDEX IX_SalesOrderDetail_ProductID ON Sales.SalesOrderDetail(ProductID ASC) 
	INCLUDE (OrderQty,UnitPrice,UnitPriceDiscount,LineTotal)
	WITH (DROP_EXISTING = ON, ONLINE=ON, DATA_COMPRESSION = ROW)
GO
*/
--Don't need new index for Person since JOIN criteria is PK
--Don't need new index for Customer since JOIN criteria is PK

--now run query above (turn on actual execution plan (CTRL-M) without above indexes
SELECT p.FirstName, p.LastName,h.SalesOrderID,prod.Name ProductName,d.LineTotal, h.ShipDate
	FROM Sales.SalesOrderHeader h
	JOIN Sales.SalesOrderDetail d
	  ON d.SalesOrderID = h.SalesOrderID
	JOIN Sales.Customer c
	  ON c.CustomerID = h.CustomerID
	JOIN Person.Person p
	  on p.BusinessEntityID = h.SalesPersonID
	JOIN Production.Product prod
	  ON prod.ProductID = d.ProductID
	WHERE h.OrderDate >= '1/1/2006'
	  AND h.OrderDate <  '6/30/2006'
GO
--query cost:  1.466
--why no join to Customer???

SELECT * from sys.foreign_keys where name = 'FK_SalesOrderHeader_Customer_CustomerID'
--is_not_trusted = 0 which means that FK is trusted -- don't need join to Customer since no columns needed from it and is trusted

--now apply indexes above

--and rerun the query with above indexes
SELECT p.FirstName, p.LastName,h.SalesOrderID,prod.Name ProductName,d.LineTotal, h.ShipDate
	FROM Sales.SalesOrderHeader h
	JOIN Sales.SalesOrderDetail d
	  ON d.SalesOrderID = h.SalesOrderID
	JOIN Sales.Customer c
	  ON c.CustomerID = h.CustomerID
	JOIN Person.Person p
	  on p.BusinessEntityID = h.SalesPersonID
	JOIN Production.Product prod
	  ON prod.ProductID = d.ProductID
	WHERE h.OrderDate >= '1/1/2006'
	  AND h.OrderDate <  '6/30/2006'
GO
--query cost:  0.903

--still uses CI to SalesOrderDetail rather than covering index -- reason no WHERE clause on 


--Need to use care when Microsoft suggest indexes.  Example below somewhat trivial, but does illustrate
--	Microsoft recommending way too many similar indexes

--current index in Sales.SalesOrderDetail using ProductID
IF EXISTS (SELECT 1 FROM sys.indexes where name = 'IX_SalesOrderDetail_ProductID') DROP INDEX IX_SalesOrderDetail_ProductID ON Sales.SalesOrderDetail
GO
CREATE NONCLUSTERED INDEX IX_SalesOrderDetail_ProductID ON Sales.SalesOrderDetail
	(ProductID ASC) 
GO

--Consider following queries (Missing index scenario)
SELECT *
	FROM Sales.SalesOrderDetail
	WHERE ProductID = 711

SELECT SalesOrderID, CarrierTrackingNumber, ModifiedDate
	FROM Sales.SalesOrderDetail
	WHERE ProductID = 711

SELECT SalesOrderDetailID, OrderQty, ModifiedDate
	FROM Sales.SalesOrderDetail
	WHERE ProductID = 711
GO 12

--now run missing index query
SELECT
  migs.avg_total_user_cost * (migs.avg_user_impact / 100.0) * (migs.user_seeks + migs.user_scans) AS improvement_measure,
  'CREATE INDEX [missing_index_' + CONVERT (varchar, mig.index_group_handle) + '_' + CONVERT (varchar, mid.index_handle)
  + '_' + LEFT (PARSENAME(mid.statement, 1), 32) + ']'
  + ' ON ' + mid.statement
  + ' (' + ISNULL (mid.equality_columns,'')
    + CASE WHEN mid.equality_columns IS NOT NULL AND mid.inequality_columns IS NOT NULL THEN ',' ELSE '' END
    + ISNULL (mid.inequality_columns, '')
  + ')'
  + ISNULL (' INCLUDE (' + mid.included_columns + ')', '') AS create_index_statement,
  migs.*, mid.database_id, mid.[object_id]
FROM sys.dm_db_missing_index_groups mig
INNER JOIN sys.dm_db_missing_index_group_stats migs ON migs.group_handle = mig.index_group_handle
INNER JOIN sys.dm_db_missing_index_details mid ON mig.index_handle = mid.index_handle
WHERE migs.avg_total_user_cost * (migs.avg_user_impact / 100.0) * (migs.user_seeks + migs.user_scans) > 10
ORDER BY migs.avg_total_user_cost * migs.avg_user_impact * (migs.user_seeks + migs.user_scans) DESC
GO


--now look at indexes under create_index_statement
--index 1
CREATE INDEX [missing_index_2_1_SalesOrderDetail] ON [AdventureWorks2012].[Sales].[SalesOrderDetail] ([ProductID]) 
	INCLUDE ([SalesOrderID], [SalesOrderDetailID], [CarrierTrackingNumber], [OrderQty], [SpecialOfferID], [UnitPrice], 
			 [UnitPriceDiscount], [LineTotal], [rowguid], [ModifiedDate])
--index 2
CREATE INDEX [missing_index_4_3_SalesOrderDetail] ON [AdventureWorks2012].[Sales].[SalesOrderDetail] ([ProductID]) 
	INCLUDE ([SalesOrderID], [CarrierTrackingNumber], [ModifiedDate])
--index 3
CREATE INDEX [missing_index_7_6_SalesOrderDetail] ON [AdventureWorks2012].[Sales].[SalesOrderDetail] ([ProductID]) 
	INCLUDE ([SalesOrderDetailID], [OrderQty], [ModifiedDate])

--do we really want Index 1 (even with its improvement_measure)???

--but we can do something with the original index (on ProductID) plus Index 2 and 3
--note that Microsoft includes PK columns even though they are already build into the index (under the covers)

-- so starting with current index, just need to add INCLUDE columns and drop PK references.

--current index in Sales.SalesOrderDetail using ProductId
CREATE NONCLUSTERED INDEX [IX_SalesOrderDetail_ProductID] ON [Sales].[SalesOrderDetail]
	(ProductID ASC) 
	INCLUDE (CarrierTrackingNumber,ModifiedDate,OrderQty)
	WITH (DROP_EXISTING = ON, ONLINE = ON, DATA_COMPRESSION = ROW)  --ONLINE & Data_Compression only good for Enterprise and Standard Edition > 2016 SP1
GO

--now rerun queries above with statistics and include actual execution plan (Ctrl-M)
SET STATISTICS IO,TIME ON
SELECT *
	FROM Sales.SalesOrderDetail
	WHERE ProductID = 711;										--query cost = 1.345; logical reads = 1246
PRINT '*********';
SELECT SalesOrderID, CarrierTrackingNumber, ModifiedDate
	FROM Sales.SalesOrderDetail
	WHERE ProductID = 711;										--query cost = 0.016; logical reads = 16
PRINT '*********';
SELECT SalesOrderDetailID, OrderQty, ModifiedDate
	FROM Sales.SalesOrderDetail
	WHERE ProductID = 711;										--query cost = 0.016; logical reads = 16
SET STATISTICS IO,TIME OFF;
GO
