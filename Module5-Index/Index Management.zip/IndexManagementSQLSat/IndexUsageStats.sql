DECLARE @server_start_time DATETIME
SELECT @server_start_time = MIN(login_time) FROM sys.sysprocesses 

SELECT OBJECT_SCHEMA_NAME(idx.object_id) + '.' + OBJECT_NAME(idx.object_id) 'object_name'
	, idx.name 'index_name' 
	, idx.type_desc 'index_type'
	, ius.user_seeks + ius.system_seeks 'index_seeks'
	, ius.user_scans + ius.system_scans 'index_scans'
	, ius.user_lookups + ius.system_lookups 'index_lookups'
	, ius.user_updates + ius.system_updates 'index_updates'
	, CASE 
		WHEN ISNULL(ius.last_user_seek, '1/1/1753') >= ISNULL(ius.last_system_seek, '1/1/1753') THEN ius.last_user_seek
		WHEN ISNULL(ius.last_system_seek, '1/1/1753') > ISNULL(ius.last_user_seek, '1/1/1753') THEN ius.last_system_seek
	  END 'last_index_seek'
	, CASE 
		WHEN ISNULL(ius.last_user_scan, '1/1/1753') >= ISNULL(ius.last_system_scan, '1/1/1753') THEN ius.last_user_scan
		WHEN ISNULL(ius.last_system_scan, '1/1/1753') > ISNULL(ius.last_user_scan, '1/1/1753') THEN ius.last_system_scan
	  END 'last_index_scan'
	, CASE 
		WHEN ISNULL(ius.last_user_lookup, '1/1/1753') >= ISNULL(ius.last_system_lookup, '1/1/1753') THEN ius.last_user_lookup
		WHEN ISNULL(ius.last_system_lookup, '1/1/1753') > ISNULL(ius.last_user_lookup, '1/1/1753') THEN ius.last_system_lookup
	  END 'last_index_lookup'
	, CASE 
		WHEN ISNULL(ius.last_user_update, '1/1/1753') >= ISNULL(ius.last_system_update, '1/1/1753') THEN ius.last_user_update
		WHEN ISNULL(ius.last_system_update, '1/1/1753') > ISNULL(ius.last_user_update, '1/1/1753') THEN ius.last_system_update
	  END 'last_index_update'
	, @server_start_time 'server_start_time'
FROM sys.indexes idx
	INNER JOIN sys.dm_db_index_usage_stats ius ON idx.object_id = ius.object_id
		AND idx.index_id = ius.index_id
WHERE idx.index_id != 0
ORDER BY 'object_name', idx.index_id