DECLARE 
	@db_id INT
	, @obj_id INT
	, @mode VARCHAR(20)
	
SELECT @db_id = DB_ID()
	, @obj_id = OBJECT_ID('Production.Product')
	, @mode = 'LIMITED'
	--, @mode = 'DETAILED'
	
SELECT idx.name 'index_name'
	, ips.index_type_desc
	, ips.alloc_unit_type_desc
	, ips.index_depth
	, ips.index_level
	, ips.avg_fragmentation_in_percent
	, ips.avg_page_space_used_in_percent
	, ips.page_count
FROM sys.dm_db_index_physical_stats(@db_id, @obj_id, NULL, NULL, @mode) ips
	INNER JOIN sys.indexes idx ON ips.object_id = idx.object_id
		AND ips.index_id = idx.index_id
ORDER BY idx.index_id