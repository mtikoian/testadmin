-- show all indexes in the current database
--
SELECT SCHEMA_NAME(obj.schema_id) + '.' + obj.name AS 'parent_object_name'
	, obj.type_desc AS 'parent_object_type'
	, idx.name AS 'index_name'
	, idx.type_desc AS 'index_type'
	, CASE WHEN idx.is_primary_key = 1 THEN 'PRIMARY KEY' 
		WHEN idx.is_unique_constraint = 1 THEN 'UNIQUE'
		ELSE 'N/A'
		END AS 'constraint_type'
	, CASE idx.has_filter WHEN 1 THEN idx.filter_definition ELSE 'N/A' END AS 'index_filter'
	, CASE idx.fill_factor WHEN 0 THEN 100 ELSE idx.fill_factor END AS 'index_fill_factor'
FROM sys.indexes idx
	INNER JOIN sys.objects obj ON obj.object_id = idx.object_id
WHERE idx.index_id != 0 -- this will suppress heaps
	AND obj.type NOT IN  ('IT','S') -- this will suppress internal and system tables
ORDER BY 'parent_object_name', idx.index_id




-- add index key columns as comma separated list
-- 
SELECT SCHEMA_NAME(obj.schema_id) + '.' + obj.name AS 'parent_object_name'
	, obj.type_desc AS 'parent_object_type'
	, idx.name AS 'index_name'
	, idx.type_desc AS 'index_type'
	, CASE WHEN idx.is_primary_key = 1 THEN 'PRIMARY KEY' 
		WHEN idx.is_unique_constraint = 1 THEN 'UNIQUE'
		ELSE 'N/A'
		END AS 'constraint_type'
	, CASE idx.has_filter WHEN 1 THEN idx.filter_definition ELSE 'N/A' END AS 'index_filter'
	, CASE idx.fill_factor WHEN 0 THEN 100 ELSE idx.fill_factor END AS 'index_fill_factor'
	, SUBSTRING((SELECT ', ' + c.name  
				FROM sys.index_columns ic
				INNER JOIN sys.columns c ON c.object_id = ic.object_id
					AND c.column_id = ic.column_id
				WHERE ic.object_id = idx.object_id
					AND ic.index_id = idx.index_id
				ORDER BY ic.key_ordinal
				FOR XML PATH('')), 3, 2048) AS 'index_key_columns'
FROM sys.indexes idx
	INNER JOIN sys.objects obj ON obj.object_id = idx.object_id
WHERE idx.index_id != 0 
	AND obj.type NOT IN  ('IT','S') 
ORDER BY 'parent_object_name', idx.index_id