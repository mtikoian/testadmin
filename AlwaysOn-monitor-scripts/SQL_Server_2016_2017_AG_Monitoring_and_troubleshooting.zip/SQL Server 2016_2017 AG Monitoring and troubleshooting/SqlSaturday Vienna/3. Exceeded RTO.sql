	-- Switch replicas to synchronous 
	-- Exceeded RTO (blocked REDO thread)
	:Connect SQL2
	USE [DB1]
	GO

	SELECT		[OrderId],
				SUM(CAST([Quantity] AS BIGINT))						    AS Quantity
	FROM		[dbo].[Sales]											 a
	CROSS JOIN	(SELECT number FROM master..spt_values WHERE TYPE = 'P') b
	CROSS JOIN	(SELECT number FROM master..spt_values WHERE TYPE = 'P') c
	CROSS JOIN	(SELECT number FROM master..spt_values WHERE TYPE = 'P') d
	CROSS JOIN	(SELECT number FROM master..spt_values WHERE TYPE = 'P') e
	CROSS JOIN	(SELECT number FROM master..spt_values WHERE TYPE = 'P') f
	GROUP BY	[OrderId]
	OPTION (MAXDOP 1)

	-- Run this query from different session
	:Connect SQL1
	USE [DB1]
	GO
	ALTER INDEX IDX1 ON DB1.dbo.Sales REBUILD WITH (ONLINE = OFF)
	GO 
	
	-- Run this query on secondary from different session
	:Connect SQL2
	SELECT	* 
	FROM	sys.dm_exec_requests 
	WHERE	command = 'DB STARTUP'
	AND		blocking_session_id <> 0

	-- Solution
	KILL session_id


	-- SQLServer Alert
	DECLARE @blocking_session int;
	SELECT	@blocking_session = blocking_session_id from sys.dm_exec_requests er WHERE command = 'DB STARTUP' AND	blocking_session_id <> 0;
	EXEC ('KILL ' + @blocking_session);

	-- XESmartTarget

	DECLARE @blocking_session int;
	SELECT	@blocking_session = blocking_session_id from sys.dm_exec_requests er where er.session_id = CAST({session_id} AS varchar);
	EXEC ('KILL ' + @blocking_session);


