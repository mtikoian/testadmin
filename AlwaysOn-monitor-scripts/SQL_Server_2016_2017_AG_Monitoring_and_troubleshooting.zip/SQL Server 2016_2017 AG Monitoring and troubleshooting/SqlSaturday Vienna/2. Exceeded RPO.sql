	-- Monitor potential data loss

	-- Switch SQL2 to asynchronous replica
	-- Prepare Perfmon with Log Send Queue Counter on SQL2
	-- Prepare to run clumsy

	:Connect SQL1
	CREATE DATABASE DB1;
	GO
	BACKUP DATABASE DB1	TO DISK = 'NUL'
	GO

	:Connect SQL1
	USE [master]
	GO
	ALTER AVAILABILITY GROUP [WideWorldImportersAG] ADD DATABASE [DB1];
	GO

	:Connect SQL2
	ALTER AVAILABILITY GROUP [WideWorldImportersAG] GRANT CREATE ANY DATABASE;
	GO
	
	:Connect SQL1
	USE [DB1]
	GO
--	CREATE TABLE dbo.T1(col1 int Identity(1,1), col2 varchar(10))
--	GO
	CREATE TABLE dbo.[Sales](
				[OrderLineID] [int] NOT NULL,
				[OrderID] [int] NOT NULL,
				[StockItemID] [int] NOT NULL,
				[Description] [nvarchar](100) NOT NULL,
				[PackageTypeID] [int] NOT NULL,
				[Quantity] [int] NOT NULL,
				[UnitPrice] [decimal](18, 2) NULL,
				[TaxRate] [decimal](18, 3) NOT NULL,
				[PickedQuantity] [int] NOT NULL,
				[PickingCompletedWhen] [datetime2](7) NULL,
				[LastEditedBy] [int] NOT NULL,
				[LastEditedWhen] [datetime2](7) NOT NULL
				)
	GO
	CREATE CLUSTERED INDEX IDX1 ON dbo.Sales ([OrderLineID], [OrderID], [StockItemID], [Description], [PackageTypeID], [Quantity], [UnitPrice], [TaxRate], [PickedQuantity], [PickingCompletedWhen], [LastEditedBy], [LastEditedWhen])
	GO

-- Show Dashboard, run clumsy and then run parallel batch script

	SELECT	DB_NAME(database_id) AS 'Database', 
			log_send_queue_size, 
			secondary_lag_seconds
	FROM	sys.dm_hadr_database_replica_states
	WHERE	is_local = 0
	AND		database_id = DB_ID('DB1')


	:Connect SQL2
	ALTER AVAILABILITY GROUP WideWorldImportersAG FORCE_FAILOVER_ALLOW_DATA_LOSS;
	GO
	
	-- Stop clumsy and Resume all db

	-- Create DB1's database snapshot on SQL1
	:Connect SQL1
	USE [master]
	GO

	CREATE DATABASE [DB1_snapshot]
	ON PRIMARY		
	( NAME = N'DB1', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL14.MSSQLSERVER\MSSQL\DATA\DB1_snapshot.ss')
	AS SNAPSHOT OF [DB1] ;
	GO

	-- Resume databases on SQL1
	:Connect SQL1
	ALTER DATABASE [DB1] SET HADR RESUME;
	GO
	ALTER DATABASE WideWorldImporters SET HADR RESUME;
	GO
	
	:Connect SQL1
	SELECT 'Lost Records', count(*) As 'Number of records' FROM [DB1_snapshot].dbo.Sales
	UNION ALL
	SELECT 'Records', count(*) FROM [DB1].dbo.Sales
	GO

	:Connect SQL1
	ALTER AVAILABILITY GROUP WideWorldImportersAG FORCE_FAILOVER_ALLOW_DATA_LOSS
	GO

	:Connect SQL2
	ALTER DATABASE [DB1] SET HADR RESUME;
	GO
	ALTER DATABASE WideWorldImporters SET HADR RESUME;
	GO
	
	-- Create PBM
	-- Customize dashboard
	-- Create Perfmon custom script
	-- Failover to SQL1
	-- Start clumsy on SQL2

	DECLARE @data_loss decimal(10,2);

	SELECT	@data_loss = log_send_queue_size
	FROM	sys.dm_hadr_database_replica_states
	WHERE	is_local = 0
	AND		database_id = DB_ID('DB1');

	exec sp_user_counter1 @data_loss;

	


	:Connect SQL1
	ALTER AVAILABILITY GROUP WideWorldImportersAG FAILOVER
	GO
















