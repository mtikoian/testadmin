:Connect SQL1
USE [master]
GO

IF NOT EXISTS(SELECT * FROM sys.endpoints WHERE name = N'Hadr_endpoint')
BEGIN
	CREATE ENDPOINT [Hadr_endpoint] 
		AS TCP (LISTENER_PORT = 5022)
		FOR DATA_MIRRORING (ROLE = ALL, ENCRYPTION = REQUIRED ALGORITHM AES)
END
GO

IF (SELECT state FROM sys.endpoints WHERE name = N'Hadr_endpoint') <> 0
BEGIN
	ALTER ENDPOINT [Hadr_endpoint] STATE = STARTED
END
GO

GRANT CONNECT ON ENDPOINT::[Hadr_endpoint] TO [SQU\SQLService]
GO

IF NOT EXISTS(SELECT * FROM sys.dm_xe_sessions WHERE name='AlwaysOn_health')
BEGIN
	CREATE EVENT SESSION [AlwaysOn_health] ON SERVER 
	ADD EVENT sqlserver.alwayson_ddl_executed,
	ADD EVENT sqlserver.availability_group_lease_expired,
	ADD EVENT sqlserver.availability_replica_automatic_failover_validation,
	ADD EVENT sqlserver.availability_replica_manager_state_change,
	ADD EVENT sqlserver.availability_replica_state,
	ADD EVENT sqlserver.availability_replica_state_change,
	ADD EVENT sqlserver.error_reported(
		WHERE ([error_number]=(9691) OR [error_number]=(35204) OR [error_number]=(9693) OR [error_number]=(26024) OR [error_number]=(28047) OR [error_number]=(26023) OR [error_number]=(9692) OR [error_number]=(28034) OR [error_number]=(28036) OR [error_number]=(28048) OR [error_number]=(28080) OR [error_number]=(28091) OR [error_number]=(26022) OR [error_number]=(9642) OR [error_number]=(35201) OR [error_number]=(35202) OR [error_number]=(35206) OR [error_number]=(35207) OR [error_number]=(26069) OR [error_number]=(26070) OR [error_number]>(41047) AND [error_number]<(41056) OR [error_number]=(41142) OR [error_number]=(41144) OR [error_number]=(1480) OR [error_number]=(823) OR [error_number]=(824) OR [error_number]=(829) OR [error_number]=(35264) OR [error_number]=(35265) OR [error_number]=(41188) OR [error_number]=(41189))),
	ADD EVENT sqlserver.hadr_db_partner_set_sync_state,
	ADD EVENT sqlserver.lock_redo_blocked
	ADD TARGET package0.event_file(SET filename=N'AlwaysOn_health.xel',max_file_size=(5),max_rollover_files=(4))
	WITH (MAX_MEMORY=4096 KB,EVENT_RETENTION_MODE=ALLOW_SINGLE_EVENT_LOSS,MAX_DISPATCH_LATENCY=30 SECONDS,MAX_EVENT_SIZE=0 KB,MEMORY_PARTITION_MODE=NONE,TRACK_CAUSALITY=OFF,STARTUP_STATE=ON)
END
IF EXISTS(SELECT * FROM sys.server_event_sessions WHERE name='AlwaysOn_health')
BEGIN
  ALTER EVENT SESSION [AlwaysOn_health] ON SERVER STATE=START;
END
GO

:Connect SQL2
USE [master]
GO

IF NOT EXISTS(SELECT * FROM sys.endpoints WHERE name = N'Hadr_endpoint')
BEGIN
	CREATE ENDPOINT [Hadr_endpoint] 
		AS TCP (LISTENER_PORT = 5022)
		FOR DATA_MIRRORING (ROLE = ALL, ENCRYPTION = REQUIRED ALGORITHM AES)
END
GO

IF (SELECT state FROM sys.endpoints WHERE name = N'Hadr_endpoint') <> 0
BEGIN
	ALTER ENDPOINT [Hadr_endpoint] STATE = STARTED
END
GO

GRANT CONNECT ON ENDPOINT::[Hadr_endpoint] TO [SQU\SQLService]
GO

IF NOT EXISTS(SELECT * FROM sys.dm_xe_sessions WHERE name='AlwaysOn_health')
BEGIN
	CREATE EVENT SESSION [AlwaysOn_health] ON SERVER 
	ADD EVENT sqlserver.alwayson_ddl_executed,
	ADD EVENT sqlserver.availability_group_lease_expired,
	ADD EVENT sqlserver.availability_replica_automatic_failover_validation,
	ADD EVENT sqlserver.availability_replica_manager_state_change,
	ADD EVENT sqlserver.availability_replica_state,
	ADD EVENT sqlserver.availability_replica_state_change,
	ADD EVENT sqlserver.error_reported(
		WHERE ([error_number]=(9691) OR [error_number]=(35204) OR [error_number]=(9693) OR [error_number]=(26024) OR [error_number]=(28047) OR [error_number]=(26023) OR [error_number]=(9692) OR [error_number]=(28034) OR [error_number]=(28036) OR [error_number]=(28048) OR [error_number]=(28080) OR [error_number]=(28091) OR [error_number]=(26022) OR [error_number]=(9642) OR [error_number]=(35201) OR [error_number]=(35202) OR [error_number]=(35206) OR [error_number]=(35207) OR [error_number]=(26069) OR [error_number]=(26070) OR [error_number]>(41047) AND [error_number]<(41056) OR [error_number]=(41142) OR [error_number]=(41144) OR [error_number]=(1480) OR [error_number]=(823) OR [error_number]=(824) OR [error_number]=(829) OR [error_number]=(35264) OR [error_number]=(35265) OR [error_number]=(41188) OR [error_number]=(41189))),
	ADD EVENT sqlserver.hadr_db_partner_set_sync_state,
	ADD EVENT sqlserver.lock_redo_blocked
	ADD TARGET package0.event_file(SET filename=N'AlwaysOn_health.xel',max_file_size=(5),max_rollover_files=(4))
	WITH (MAX_MEMORY=4096 KB,EVENT_RETENTION_MODE=ALLOW_SINGLE_EVENT_LOSS,MAX_DISPATCH_LATENCY=30 SECONDS,MAX_EVENT_SIZE=0 KB,MEMORY_PARTITION_MODE=NONE,TRACK_CAUSALITY=OFF,STARTUP_STATE=ON)
END
IF EXISTS(SELECT * FROM sys.server_event_sessions WHERE name='AlwaysOn_health')
BEGIN
  ALTER EVENT SESSION [AlwaysOn_health] ON SERVER STATE=START;
END
GO


:Connect SQL1
USE [master]
GO

CREATE AVAILABILITY GROUP [WideWorldImportersAG]
WITH (AUTOMATED_BACKUP_PREFERENCE = SECONDARY,
DB_FAILOVER = ON,
DTC_SUPPORT = PER_DB,
REQUIRED_SYNCHRONIZED_SECONDARIES_TO_COMMIT = 0)
FOR DATABASE [WideWorldImporters]
REPLICA ON N'SQL1' WITH (ENDPOINT_URL = N'TCP://SQL1.SQU.COM:5022', FAILOVER_MODE = MANUAL, AVAILABILITY_MODE = ASYNCHRONOUS_COMMIT, BACKUP_PRIORITY = 50, SEEDING_MODE = AUTOMATIC, SECONDARY_ROLE(ALLOW_CONNECTIONS = NO)),
	       N'SQL2' WITH (ENDPOINT_URL = N'TCP://SQL2.SQU.COM:5022', FAILOVER_MODE = MANUAL, AVAILABILITY_MODE = ASYNCHRONOUS_COMMIT, BACKUP_PRIORITY = 50, SEEDING_MODE = AUTOMATIC, SECONDARY_ROLE(ALLOW_CONNECTIONS = NO))
LISTENER N'WWI_Listener' (WITH IP ((N'192.168.14.221', N'255.255.255.0')), PORT=1433);
GO


:Connect SQL2
ALTER AVAILABILITY GROUP [WideWorldImportersAG] JOIN;
GO
ALTER AVAILABILITY GROUP [WideWorldImportersAG] GRANT CREATE ANY DATABASE;
GO

