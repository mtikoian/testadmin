	-- Cleanup
	:Connect SQL1
	DROP DATABASE IF EXISTS [DB1_snapshot]
	GO
	DROP AVAILABILITY GROUP [WideWorldImportersAG];
	GO
	EXEC msdb.dbo.sp_delete_database_backuphistory @database_name = N'DB1'
	GO
	DROP DATABASE IF EXISTS [DB1]
	GO
	EXEC msdb.dbo.sp_delete_alert @name=N'RPO'
	GO
	EXEC msdb.dbo.sp_delete_job @job_name=N'Monitor possible data loss', @delete_unused_schedule=1
	GO

	EXEC msdb.dbo.sp_syspolicy_delete_policy @name=N'Estimated Data Loss'
	GO
	EXEC msdb.dbo.sp_syspolicy_delete_object_set @object_set_name=N'Estimated Data Loss'
	GO

	EXEC msdb.dbo.sp_syspolicy_delete_condition @name = N'RPO'
	GO
	EXEC msdb.dbo.sp_syspolicy_delete_condition @name = N'IsPrimaryReplica'
	GO

	
	:Connect SQL2
	DROP DATABASE IF EXISTS [DB1]
	GO
	DROP DATABASE IF EXISTS [WideWorldImporters]
	GO
	EXEC msdb.dbo.sp_delete_alert @name=N'Redo blocked'
	GO
	EXEC msdb.dbo.sp_delete_job @job_name=N'Kill long running read only query', @delete_unused_schedule=1
	GO

