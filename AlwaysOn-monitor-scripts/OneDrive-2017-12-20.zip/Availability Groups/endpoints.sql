select * from sys.database_mirroring_endpoints
select * from sys.tcp_endpoints
select * from sys.availability_replicas
