----Check routing list after setting up the read-only routing list
--select g.name, r1.replica_server_name, l.routing_priority, r2.replica_server_name, r2.read_only_routing_url
--from sys.availability_read_only_routing_lists as l
--join sys.availability_replicas as r1 on l.replica_id = r1.replica_id
--join sys.availability_replicas as r2 on l.read_only_replica_id = r2.replica_id
--join sys.availability_groups as g on r1.group_id = g.group_id
--order by r1.replica_server_name,l.routing_priority, r2.replica_server_name

--Create READ_ONLY_ROUTING for the secondaries to perform read-intent queries.
ALTER AVAILABILITY GROUP [SQL2016AG01]
 MODIFY REPLICA ON
N'SQL2016HANODE1' WITH 
(SECONDARY_ROLE (ALLOW_CONNECTIONS = READ_ONLY));
ALTER AVAILABILITY GROUP [SQL2016AG01]
 MODIFY REPLICA ON
N'SQL2016HANODE1' WITH 
(SECONDARY_ROLE (READ_ONLY_ROUTING_URL = N'tcp://SQL2016HANODE1.DANSDC.DEMOS:1433'));
GO

ALTER AVAILABILITY GROUP [SQL2016AG01]
 MODIFY REPLICA ON
N'SQL2016HANODE2' WITH 
(SECONDARY_ROLE (ALLOW_CONNECTIONS = READ_ONLY));
ALTER AVAILABILITY GROUP [SQL2016AG01]
 MODIFY REPLICA ON
N'SQL2016HANODE2' WITH 
(SECONDARY_ROLE (READ_ONLY_ROUTING_URL = N'tcp://SQL2016HANODE2.DANSDC.DEMOS:1433'));
GO

ALTER AVAILABILITY GROUP [SQL2016AG01] 
MODIFY REPLICA ON
N'SQL2016HANODE1' WITH 
(PRIMARY_ROLE (READ_ONLY_ROUTING_LIST=(('SQL2016HANODE2', 'SQL2016HANODE1'))));
GO

ALTER AVAILABILITY GROUP [SQL2016AG01] 
MODIFY REPLICA ON
N'SQL2016HANODE2' WITH 
(PRIMARY_ROLE (READ_ONLY_ROUTING_LIST=(('SQL2016HANODE1', 'SQL2016HANODE2'))));
GO