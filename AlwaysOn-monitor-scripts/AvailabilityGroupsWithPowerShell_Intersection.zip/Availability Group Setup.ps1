# Enable Always On for the server - Must be done on each one
Enable-SqlAlwaysOn

# This one uses Certificates for authentication, but you can do NTLM as the Authentication
$endpoint = New-SqlHADREndpoint -Certificate "AG Certificate A" -AuthenticationOrder Certificate -Encryption Required -EncryptionAlgorithm Aes -Name "AGEndpoint" -InputObject (Get-Item SQLSERVER:\SQL\WIN16A\S1)

# It is created by default as STOPPED when you use PowerShell. No intrinsic way to start except .Start()
$endpoint.Start()

# Make sure that you have databases to add to the availability group

# Backup my database and its log on the primary  
Backup-SqlDatabase -Database "WideWorldImporters" -CompressionOption On -BackupFile "c:\SQLDATA\WideWorldImporters.bak" -ServerInstance "WIN16A\S1"  
Backup-SqlDatabase -Database "WideWorldImporters" -CompressionOption On -BackupFile "c:\SQLDATA\WideWorldImporters.trn" -ServerInstance "WIN16A\S1" -BackupAction Log   
  
# Restore the database and log on the secondary (using NO RECOVERY)  
Restore-SqlDatabase -Database "WideWorldImporters" -BackupFile "C:\SQLDATA\WideWorldImporters.bak" -ServerInstance "WIN16D" -NoRecovery  
Restore-SqlDatabase -Database "WideWorldImporters" -BackupFile "c:\SQLDATA\WideWorldImporters.trn" -ServerInstance "WIN16D" -RestoreAction Log -NoRecovery  
  
# Create an in-memory representation of the primary replica.  
$primaryReplica = New-SqlAvailabilityReplica -Name "WIN16A\S1" -EndpointURL "TCP://WIN16A.dbaduck.local:5022" -AvailabilityMode "SynchronousCommit" -FailoverMode "Automatic" -Version 13 -AsTemplate  
  
# Create an in-memory representation of the secondary replica.  
$secondaryReplica = New-SqlAvailabilityReplica -Name "WIN16D" -EndpointURL "TCP://WIN16D.dbaduck.local:5022" -AvailabilityMode "SynchronousCommit" -FailoverMode "Automatic" -Version 13 -AsTemplate  
  
# Create the availability group  
New-SqlAvailabilityGroup -Name "MyAG" -Path "SQLSERVER:\SQL\WIN16A\S1" -AvailabilityReplica @($primaryReplica,$secondaryReplica) -Database "WideWorldImporters"   

# Join the secondary replica to the availability group.  
Join-SqlAvailabilityGroup -Path "SQLSERVER:\SQL\WIN16D\DEFAULT" -Name "MyAG"  
  
# Join the secondary database to the availability group.  
Add-SqlAvailabilityDatabase -Path "SQLSERVER:\SQL\WIN16D\DEFAULT\AvailabilityGroups\MyAG" -Database "WideWorldImporters"
