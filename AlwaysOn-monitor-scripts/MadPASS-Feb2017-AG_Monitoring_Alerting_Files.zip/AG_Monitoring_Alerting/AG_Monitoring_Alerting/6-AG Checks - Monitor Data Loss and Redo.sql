/*
AlwaysOn Availability Groups - Monitoring and Alerting

Phil Ekins, copyright 2016

This code is provided as is for demonstration purposes. It may not be suitable for
your environment. Please test this on your own systems. This code may not be republished 
or redistributed by anyone without permission.
You are free to use this code inside of your own organization.

Use SQLCMD Mode

*/

:CONNECT Node1
USE [msdb]

BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0

IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'AG Checks - Monitor Data Loss and Redo', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [1]    Script Date: 4/14/2016 3:20:37 PM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'1', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'DECLARE @log_send_queue_size NUMERIC, @log_send_rate NUMERIC, @redo_queue_size NUMERIC, @redo_rate NUMERIC, @DataLoss NUMERIC, @Redo NUMERIC

SET @DataLoss = 0
SET @Redo = 0

SELECT 
	@log_send_queue_size=COALESCE(log_send_queue_size,0), 
	@log_send_rate=COALESCE(log_send_rate,0), 
	@redo_queue_size=COALESCE(redo_queue_size,0), 
	@redo_rate=COALESCE(redo_rate,0) 
FROM [master].[sys].[dm_hadr_database_replica_states] hdrs
	INNER JOIN [master].[sys].[dm_hadr_name_id_map] hnim ON hdrs.group_id = hnim.[ag_id]
	INNER JOIN [master].[sys].[dm_hadr_availability_replica_cluster_states] arcs ON hdrs.group_id = arcs.[group_id] AND hdrs.replica_id = arcs.replica_id
WHERE [ag_name] = ''AG'' AND is_local = 1 

IF (@log_send_queue_size > 0 AND @log_send_rate > 0)
BEGIN
	SET @DataLoss = @log_send_queue_size / @log_send_rate
END

IF (@redo_queue_size > 0 AND @redo_rate > 0)
BEGIN
	SET @Redo = @redo_queue_size / @redo_rate
END

IF (@DataLoss > 600)
BEGIN
EXEC msdb.dbo.sp_send_dbmail
	@profile_name = ''Default'',
	@recipients = ''yourname@client.com'',
	@subject = ''Node1 : Data Loss has Passed 10 Minute Threshold'',
	@body = ''More Detailed information can be added here.'';
END

IF (@Redo > 300)
BEGIN
EXEC msdb.dbo.sp_send_dbmail
	@profile_name = ''Default'',
	@recipients = ''yourname@client.com'',
	@subject = ''Node1 : Redo Queue has Passed 5 Minute Threshold'',
	@body = ''More Detailed information can be added here.'';
END', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Every 5 mins', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=4, 
		@freq_subday_interval=5, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20160328, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

:CONNECT Node2
USE [msdb]

BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0

IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'AG Checks - Monitor Data Loss and Redo', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [1]    Script Date: 4/14/2016 3:20:37 PM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'1', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'DECLARE @log_send_queue_size NUMERIC, @log_send_rate NUMERIC, @redo_queue_size NUMERIC, @redo_rate NUMERIC, @DataLoss NUMERIC, @Redo NUMERIC

SET @DataLoss = 0
SET @Redo = 0

SELECT 
	@log_send_queue_size=COALESCE(log_send_queue_size,0), 
	@log_send_rate=COALESCE(log_send_rate,0), 
	@redo_queue_size=COALESCE(redo_queue_size,0), 
	@redo_rate=COALESCE(redo_rate,0) 
FROM [master].[sys].[dm_hadr_database_replica_states] hdrs
	INNER JOIN [master].[sys].[dm_hadr_name_id_map] hnim ON hdrs.group_id = hnim.[ag_id]
	INNER JOIN [master].[sys].[dm_hadr_availability_replica_cluster_states] arcs ON hdrs.group_id = arcs.[group_id] AND hdrs.replica_id = arcs.replica_id
WHERE [ag_name] = ''AG'' AND is_local = 1 

IF (@log_send_queue_size > 0 AND @log_send_rate > 0)
BEGIN
	SET @DataLoss = @log_send_queue_size / @log_send_rate
END

IF (@redo_queue_size > 0 AND @redo_rate > 0)
BEGIN
	SET @Redo = @redo_queue_size / @redo_rate
END

IF (@DataLoss > 600)
BEGIN
EXEC msdb.dbo.sp_send_dbmail
	@profile_name = ''Default'',
	@recipients = ''yourname@client.com'',
	@subject = ''Node2 : Data Loss has Passed 10 Minute Threshold'',
	@body = ''More Detailed information can be added here.'';
END

IF (@Redo > 300)
BEGIN
EXEC msdb.dbo.sp_send_dbmail
	@profile_name = ''Default'',
	@recipients = ''yourname@client.com'',
	@subject = ''Node2 : Redo Queue has Passed 5 Minute Threshold'',
	@body = ''More Detailed information can be added here.'';
END', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Every 5 mins', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=4, 
		@freq_subday_interval=5, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20160328, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

:CONNECT Node3
USE [msdb]

BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0

IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'AG Checks - Monitor Data Loss and Redo', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [1]    Script Date: 4/14/2016 3:20:37 PM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'1', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'DECLARE @log_send_queue_size NUMERIC, @log_send_rate NUMERIC, @redo_queue_size NUMERIC, @redo_rate NUMERIC, @DataLoss NUMERIC, @Redo NUMERIC

SET @DataLoss = 0
SET @Redo = 0

SELECT 
	@log_send_queue_size=COALESCE(log_send_queue_size,0), 
	@log_send_rate=COALESCE(log_send_rate,0), 
	@redo_queue_size=COALESCE(redo_queue_size,0), 
	@redo_rate=COALESCE(redo_rate,0) 
FROM [master].[sys].[dm_hadr_database_replica_states] hdrs
	INNER JOIN [master].[sys].[dm_hadr_name_id_map] hnim ON hdrs.group_id = hnim.[ag_id]
	INNER JOIN [master].[sys].[dm_hadr_availability_replica_cluster_states] arcs ON hdrs.group_id = arcs.[group_id] AND hdrs.replica_id = arcs.replica_id
WHERE [ag_name] = ''AG'' AND is_local = 1 

IF (@log_send_queue_size > 0 AND @log_send_rate > 0)
BEGIN
	SET @DataLoss = @log_send_queue_size / @log_send_rate
END

IF (@redo_queue_size > 0 AND @redo_rate > 0)
BEGIN
	SET @Redo = @redo_queue_size / @redo_rate
END

IF (@DataLoss > 600)
BEGIN
EXEC msdb.dbo.sp_send_dbmail
	@profile_name = ''Default'',
	@recipients = ''yourname@client.com'',
	@subject = ''Node3 : Data Loss has Passed 10 Minute Threshold'',
	@body = ''More Detailed information can be added here.'';
END

IF (@Redo > 300)
BEGIN
EXEC msdb.dbo.sp_send_dbmail
	@profile_name = ''Default'',
	@recipients = ''yourname@client.com'',
	@subject = ''Node3 : Redo Queue has Passed 5 Minute Threshold'',
	@body = ''More Detailed information can be added here.'';
END', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Every 5 mins', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=4, 
		@freq_subday_interval=5, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20160328, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO




