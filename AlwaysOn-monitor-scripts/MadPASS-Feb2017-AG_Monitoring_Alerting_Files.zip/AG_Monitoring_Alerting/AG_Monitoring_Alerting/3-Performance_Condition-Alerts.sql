/*
AlwaysOn Availability Groups - Monitoring and Alerting

Phil Ekins, copyright 2016

This code is provided as is for demonstration purposes. It may not be suitable for
your environment. Please test this on your own systems. This code may not be republished 
or redistributed by anyone without permission.
You are free to use this code inside of your own organization.

Use SQLCMD Mode

*/

:CONNECT Node1

USE [msdb]

EXEC msdb.dbo.sp_add_alert @name=N'Log Send Queue > 50000 KB', 
		@message_id=0, 
		@severity=0, 
		@enabled=1, 
		@delay_between_responses=180, 
		@include_event_description_in=1, 
		@category_name=N'[Uncategorized]', 
		@performance_condition=N'Database Replica|Log Send Queue|AdventureWorks2012|>|50000', 
		@job_id=N'00000000-0000-0000-0000-000000000000'

EXEC msdb.dbo.sp_add_notification @alert_name=N'Log Send Queue > 50000 KB', @operator_name=N'SQLAdmin', @notification_method = 1

EXEC msdb.dbo.sp_add_alert @name=N'Recovery Queue > 50000 KB', 
		@message_id=0, 
		@severity=0, 
		@enabled=1, 
		@delay_between_responses=180, 
		@include_event_description_in=1, 
		@category_name=N'[Uncategorized]', 
		@performance_condition=N'Database Replica|Recovery Queue|AdventureWorks2012|>|50000', 
		@job_id=N'00000000-0000-0000-0000-000000000000'

EXEC msdb.dbo.sp_add_notification @alert_name=N'Recovery Queue > 50000 KB', @operator_name=N'SQLAdmin', @notification_method = 1
GO

:CONNECT Node2

USE [msdb]

EXEC msdb.dbo.sp_add_alert @name=N'Log Send Queue > 50000 KB', 
		@message_id=0, 
		@severity=0, 
		@enabled=1, 
		@delay_between_responses=180, 
		@include_event_description_in=1, 
		@category_name=N'[Uncategorized]', 
		@performance_condition=N'Database Replica|Log Send Queue|AdventureWorks2012|>|50000', 
		@job_id=N'00000000-0000-0000-0000-000000000000'

EXEC msdb.dbo.sp_add_notification @alert_name=N'Log Send Queue > 50000 KB', @operator_name=N'SQLAdmin', @notification_method = 1

EXEC msdb.dbo.sp_add_alert @name=N'Recovery Queue > 50000 KB', 
		@message_id=0, 
		@severity=0, 
		@enabled=1, 
		@delay_between_responses=180, 
		@include_event_description_in=1, 
		@category_name=N'[Uncategorized]', 
		@performance_condition=N'Database Replica|Recovery Queue|AdventureWorks2012|>|50000', 
		@job_id=N'00000000-0000-0000-0000-000000000000'

EXEC msdb.dbo.sp_add_notification @alert_name=N'Recovery Queue > 50000 KB', @operator_name=N'SQLAdmin', @notification_method = 1
GO

:CONNECT Node3

USE [msdb]

EXEC msdb.dbo.sp_add_alert @name=N'Log Send Queue > 50000 KB', 
		@message_id=0, 
		@severity=0, 
		@enabled=1, 
		@delay_between_responses=180, 
		@include_event_description_in=1, 
		@category_name=N'[Uncategorized]', 
		@performance_condition=N'Database Replica|Log Send Queue|AdventureWorks2012|>|50000', 
		@job_id=N'00000000-0000-0000-0000-000000000000'

EXEC msdb.dbo.sp_add_notification @alert_name=N'Log Send Queue > 50000 KB', @operator_name=N'SQLAdmin', @notification_method = 1

EXEC msdb.dbo.sp_add_alert @name=N'Recovery Queue > 50000 KB', 
		@message_id=0, 
		@severity=0, 
		@enabled=1, 
		@delay_between_responses=180, 
		@include_event_description_in=1, 
		@category_name=N'[Uncategorized]', 
		@performance_condition=N'Database Replica|Recovery Queue|AdventureWorks2012|>|50000', 
		@job_id=N'00000000-0000-0000-0000-000000000000'

EXEC msdb.dbo.sp_add_notification @alert_name=N'Recovery Queue > 50000 KB', @operator_name=N'SQLAdmin', @notification_method = 1
GO

