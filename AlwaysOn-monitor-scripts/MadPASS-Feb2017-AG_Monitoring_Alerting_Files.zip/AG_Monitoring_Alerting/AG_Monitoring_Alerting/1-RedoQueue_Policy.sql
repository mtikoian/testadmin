/*
AlwaysOn Availability Groups - Monitoring and Alerting

Phil Ekins, copyright 2016

This code is provided as is for demonstration purposes. It may not be suitable for
your environment. Please test this on your own systems. This code may not be republished 
or redistributed by anyone without permission.
You are free to use this code inside of your own organization.

Use SQLCMD Mode

Remeber To Set -

Tools > Options > SQL Server AlwaysOn > Dashboard - Enable user-defined AlwaysOn policy = True

*/

:CONNECT Node1

Declare @condition_id int
EXEC msdb.dbo.sp_syspolicy_add_condition @name=N'RedoQueueSize', @description=N'', @facet=N'DatabaseReplicaState', @expression=N'<Operator>
  <TypeClass>Bool</TypeClass>
  <OpType>LT</OpType>
  <Count>2</Count>
  <Attribute>
    <TypeClass>Numeric</TypeClass>
    <Name>RedoQueueSize</Name>
  </Attribute>
  <Constant>
    <TypeClass>Numeric</TypeClass>
    <ObjType>System.Double</ObjType>
    <Value>100000</Value>
  </Constant>
</Operator>', @is_name_condition=0, @obj_name=N'', @condition_id=@condition_id OUTPUT
Select @condition_id

Declare @object_set_id int
EXEC msdb.dbo.sp_syspolicy_add_object_set @object_set_name=N'Redo Queue Policy_ObjectSet', @facet=N'DatabaseReplicaState', @object_set_id=@object_set_id OUTPUT
Select @object_set_id

Declare @target_set_id int
EXEC msdb.dbo.sp_syspolicy_add_target_set @object_set_name=N'Redo Queue Policy_ObjectSet', @type_skeleton=N'Server/AvailabilityGroup/DatabaseReplicaState', @type=N'DATABASEREPLICASTATE', @enabled=True, @target_set_id=@target_set_id OUTPUT
Select @target_set_id

EXEC msdb.dbo.sp_syspolicy_add_target_set_level @target_set_id=@target_set_id, @type_skeleton=N'Server/AvailabilityGroup/DatabaseReplicaState', @level_name=N'DatabaseReplicaState', @condition_name=N'', @target_set_level_id=0
EXEC msdb.dbo.sp_syspolicy_add_target_set_level @target_set_id=@target_set_id, @type_skeleton=N'Server/AvailabilityGroup', @level_name=N'AvailabilityGroup', @condition_name=N'', @target_set_level_id=0

Declare @policy_id int
EXEC msdb.dbo.sp_syspolicy_add_policy @name=N'Redo Queue Policy', @condition_name=N'RedoQueueSize', @policy_category=N'Availability group errors (any replica role)', @description=N'', @help_text=N'', @help_link=N'', @schedule_uid=N'00000000-0000-0000-0000-000000000000', @execution_mode=0, @is_enabled=False, @policy_id=@policy_id OUTPUT, @root_condition_name=N'', @object_set=N'Redo Queue Policy_ObjectSet'
Select @policy_id
GO

:CONNECT Node2

Declare @condition_id int
EXEC msdb.dbo.sp_syspolicy_add_condition @name=N'RedoQueueSize', @description=N'', @facet=N'DatabaseReplicaState', @expression=N'<Operator>
  <TypeClass>Bool</TypeClass>
  <OpType>LT</OpType>
  <Count>2</Count>
  <Attribute>
    <TypeClass>Numeric</TypeClass>
    <Name>RedoQueueSize</Name>
  </Attribute>
  <Constant>
    <TypeClass>Numeric</TypeClass>
    <ObjType>System.Double</ObjType>
    <Value>100000</Value>
  </Constant>
</Operator>', @is_name_condition=0, @obj_name=N'', @condition_id=@condition_id OUTPUT
Select @condition_id

Declare @object_set_id int
EXEC msdb.dbo.sp_syspolicy_add_object_set @object_set_name=N'Redo Queue Policy_ObjectSet', @facet=N'DatabaseReplicaState', @object_set_id=@object_set_id OUTPUT
Select @object_set_id

Declare @target_set_id int
EXEC msdb.dbo.sp_syspolicy_add_target_set @object_set_name=N'Redo Queue Policy_ObjectSet', @type_skeleton=N'Server/AvailabilityGroup/DatabaseReplicaState', @type=N'DATABASEREPLICASTATE', @enabled=True, @target_set_id=@target_set_id OUTPUT
Select @target_set_id

EXEC msdb.dbo.sp_syspolicy_add_target_set_level @target_set_id=@target_set_id, @type_skeleton=N'Server/AvailabilityGroup/DatabaseReplicaState', @level_name=N'DatabaseReplicaState', @condition_name=N'', @target_set_level_id=0
EXEC msdb.dbo.sp_syspolicy_add_target_set_level @target_set_id=@target_set_id, @type_skeleton=N'Server/AvailabilityGroup', @level_name=N'AvailabilityGroup', @condition_name=N'', @target_set_level_id=0

Declare @policy_id int
EXEC msdb.dbo.sp_syspolicy_add_policy @name=N'Redo Queue Policy', @condition_name=N'RedoQueueSize', @policy_category=N'Availability group errors (any replica role)', @description=N'', @help_text=N'', @help_link=N'', @schedule_uid=N'00000000-0000-0000-0000-000000000000', @execution_mode=0, @is_enabled=False, @policy_id=@policy_id OUTPUT, @root_condition_name=N'', @object_set=N'Redo Queue Policy_ObjectSet'
Select @policy_id
GO

:CONNECT Node3

Declare @condition_id int
EXEC msdb.dbo.sp_syspolicy_add_condition @name=N'RedoQueueSize', @description=N'', @facet=N'DatabaseReplicaState', @expression=N'<Operator>
  <TypeClass>Bool</TypeClass>
  <OpType>LT</OpType>
  <Count>2</Count>
  <Attribute>
    <TypeClass>Numeric</TypeClass>
    <Name>RedoQueueSize</Name>
  </Attribute>
  <Constant>
    <TypeClass>Numeric</TypeClass>
    <ObjType>System.Double</ObjType>
    <Value>100000</Value>
  </Constant>
</Operator>', @is_name_condition=0, @obj_name=N'', @condition_id=@condition_id OUTPUT
Select @condition_id

Declare @object_set_id int
EXEC msdb.dbo.sp_syspolicy_add_object_set @object_set_name=N'Redo Queue Policy_ObjectSet', @facet=N'DatabaseReplicaState', @object_set_id=@object_set_id OUTPUT
Select @object_set_id

Declare @target_set_id int
EXEC msdb.dbo.sp_syspolicy_add_target_set @object_set_name=N'Redo Queue Policy_ObjectSet', @type_skeleton=N'Server/AvailabilityGroup/DatabaseReplicaState', @type=N'DATABASEREPLICASTATE', @enabled=True, @target_set_id=@target_set_id OUTPUT
Select @target_set_id

EXEC msdb.dbo.sp_syspolicy_add_target_set_level @target_set_id=@target_set_id, @type_skeleton=N'Server/AvailabilityGroup/DatabaseReplicaState', @level_name=N'DatabaseReplicaState', @condition_name=N'', @target_set_level_id=0
EXEC msdb.dbo.sp_syspolicy_add_target_set_level @target_set_id=@target_set_id, @type_skeleton=N'Server/AvailabilityGroup', @level_name=N'AvailabilityGroup', @condition_name=N'', @target_set_level_id=0

Declare @policy_id int
EXEC msdb.dbo.sp_syspolicy_add_policy @name=N'Redo Queue Policy', @condition_name=N'RedoQueueSize', @policy_category=N'Availability group errors (any replica role)', @description=N'', @help_text=N'', @help_link=N'', @schedule_uid=N'00000000-0000-0000-0000-000000000000', @execution_mode=0, @is_enabled=False, @policy_id=@policy_id OUTPUT, @root_condition_name=N'', @object_set=N'Redo Queue Policy_ObjectSet'
Select @policy_id
GO
