/*
AlwaysOn Availability Groups - Monitoring and Alerting

Phil Ekins, copyright 2016

This code is provided as is for demonstration purposes. It may not be suitable for
your environment. Please test this on your own systems. This code may not be republished 
or redistributed by anyone without permission.
You are free to use this code inside of your own organization.

*/

use msdb

DECLARE @profile_name sysname,
        @account_name sysname,
		@username NVARCHAR(128),
		@password NVARCHAR(128),
        @SMTP_servername sysname,
        @email_address NVARCHAR(128),
	    @display_name NVARCHAR(128),
		@String NVARCHAR(2000);

SET @profile_name = 'Default';
SET @account_name = 'SQLAdmin';
SET @display_name = @@ServerName;
SET @SMTP_servername = 'smtp.gmail.com'; 
SET @email_address = 'OnCall@email.com';  
SET @username = 'OnCall@email.com';
SET @password = '####';

DECLARE @xp_cmdshell int
exec sp_configure 'show advanced options', 1
RECONFIGURE WITH OVERRIDE

exec sp_configure 'Database Mail XPs', 1 
RECONFIGURE WITH OVERRIDE

exec sp_configure 'Agent XPs',1  
RECONFIGURE WITH OVERRIDE

set @xp_cmdshell = (select cast(value_in_use as int) from sys.configurations where name = 'xp_cmdshell')
IF @xp_cmdshell = 0 
	exec sp_configure 'xp_cmdshell',1 
RECONFIGURE WITH OVERRIDE

IF (SELECT Is_Broker_Enabled FROM master.sys.databases WHERE name = 'msdb') = 0
	BEGIN
		ALTER DATABASE msdb set restricted_user with rollback immediate
		ALTER DATABASE msdb SET ENABLE_BROKER
		ALTER DATABASE msdb set multi_user with rollback immediate
	END

IF (SELECT 1 FROM [msdb].[dbo].[sysmail_account] WHERE name = @account_name) IS NULL
	BEGIN
		EXECUTE msdb.dbo.sysmail_add_account_sp
			@account_name = @account_name,
			@description = 'Default Mail Account',
			@email_address = @email_address,
			@display_name = 'DBA Alerts',
			@replyto_address = @email_address,
			@mailserver_name = @SMTP_servername,
			@Port = 465,
			@username = @username,
			@password = @password,
			@enable_ssl = 1;


		EXECUTE msdb.dbo.sysmail_add_profile_sp
			@profile_name = @profile_name,
			@description = 'Default Profile'

		EXECUTE msdb.dbo.sysmail_add_profileaccount_sp
			@profile_name = @profile_name,
			@account_name = @account_name,
			@sequence_number = 1

		EXECUTE msdb.dbo.sysmail_add_principalprofile_sp
			@profile_name = @profile_name,
			@principal_name = 'public',
			@is_default = 1 
	END

IF NOT EXISTS(SELECT name FROM msdb.dbo.sysoperators WHERE name = @account_name)
BEGIN
	EXEC msdb.dbo.sp_add_operator @name=@account_name, 
		@enabled=1, 
		@weekday_pager_start_time=0, 
		@weekday_pager_end_time=235959, 
		@saturday_pager_start_time=0, 
		@saturday_pager_end_time=235959, 
		@sunday_pager_start_time=0, 
		@sunday_pager_end_time=235959, 
		@pager_days=127, 
		@email_address=@email_address, 
		@pager_address=@email_address, 
		@netsend_address=N''
END



IF (SELECT 1 FROM msdb.dbo.sysobjects WHERE name = 'sp_set_sqlagent_properties') = 1
	BEGIN
		EXEC msdb.dbo.sp_set_sqlagent_properties @databasemail_profile=@profile_name
	END
ELSE
	BEGIN
		EXEC master.dbo.xp_instance_regwrite N'HKEY_LOCAL_MACHINE', N'SOFTWARE\Microsoft\MSSQLServer\SQLServerAgent', N'UseDatabaseMail', N'REG_DWORD', 1
		EXEC master.dbo.xp_instance_regwrite N'HKEY_LOCAL_MACHINE', N'SOFTWARE\Microsoft\MSSQLServer\SQLServerAgent', N'DatabaseMailProfile', N'REG_SZ', @profile_name
		EXEC msdb.dbo.sp_set_sqlagent_properties @email_save_in_sent_folder=1
	END

EXEC master.dbo.sp_MSsetalertinfo @failsafeoperator=@account_name, @notificationmethod=1

IF @xp_cmdshell = 0 
	exec sp_configure 'xp_cmdshell',0 
RECONFIGURE WITH OVERRIDE

