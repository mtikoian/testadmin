/*
AlwaysOn Availability Groups - Monitoring and Alerting

Phil Ekins, copyright 2016

This code is provided as is for demonstration purposes. It may not be suitable for
your environment. Please test this on your own systems. This code may not be republished 
or redistributed by anyone without permission.
You are free to use this code inside of your own organization.

Use SQLCMD Mode

*/

:CONNECT Node1

EXEC msdb.dbo.sp_syspolicy_delete_policy @name=N'Redo Queue Policy'

EXEC msdb.dbo.sp_syspolicy_delete_object_set @object_set_name=N'Redo Queue Policy_ObjectSet'

EXEC msdb.dbo.sp_syspolicy_delete_condition @name=N'RedoQueueSize'
GO

:CONNECT Node2

EXEC msdb.dbo.sp_syspolicy_delete_policy @name=N'Redo Queue Policy'

EXEC msdb.dbo.sp_syspolicy_delete_object_set @object_set_name=N'Redo Queue Policy_ObjectSet'

EXEC msdb.dbo.sp_syspolicy_delete_condition @name=N'RedoQueueSize'
GO

:CONNECT Node3

EXEC msdb.dbo.sp_syspolicy_delete_policy @name=N'Redo Queue Policy'

EXEC msdb.dbo.sp_syspolicy_delete_object_set @object_set_name=N'Redo Queue Policy_ObjectSet'

EXEC msdb.dbo.sp_syspolicy_delete_condition @name=N'RedoQueueSize'
GO

:CONNECT Node1
USE [msdb]

EXEC msdb.dbo.sp_delete_alert @name=N'Severity 01480 - AG Role Change'
EXEC msdb.dbo.sp_delete_alert @name=N'Severity 35264 - AG Data Movement - Suspended'
EXEC msdb.dbo.sp_delete_alert @name=N'Severity 35265 - AG Data Movement - Resumed'
GO

:CONNECT Node2
USE [msdb]

EXEC msdb.dbo.sp_delete_alert @name=N'Severity 01480 - AG Role Change'
EXEC msdb.dbo.sp_delete_alert @name=N'Severity 35264 - AG Data Movement - Suspended'
EXEC msdb.dbo.sp_delete_alert @name=N'Severity 35265 - AG Data Movement - Resumed'
GO

:CONNECT Node3
USE [msdb]

EXEC msdb.dbo.sp_delete_alert @name=N'Severity 01480 - AG Role Change'
EXEC msdb.dbo.sp_delete_alert @name=N'Severity 35264 - AG Data Movement - Suspended'
EXEC msdb.dbo.sp_delete_alert @name=N'Severity 35265 - AG Data Movement - Resumed'
GO

:CONNECT Node1

USE [msdb]

EXEC msdb.dbo.sp_delete_alert @name=N'Log Send Queue > 50000 KB'
EXEC msdb.dbo.sp_delete_alert @name=N'Recovery Queue > 50000 KB'
GO

:CONNECT Node2

USE [msdb]

EXEC msdb.dbo.sp_delete_alert @name=N'Log Send Queue > 50000 KB'
EXEC msdb.dbo.sp_delete_alert @name=N'Recovery Queue > 50000 KB'
GO

:CONNECT Node3

USE [msdb]

EXEC msdb.dbo.sp_delete_alert @name=N'Log Send Queue > 50000 KB'
EXEC msdb.dbo.sp_delete_alert @name=N'Recovery Queue > 50000 KB'
GO

:CONNECT Node1

USE [msdb]

EXEC msdb.dbo.sp_delete_job @job_name=N'AG Checks - Detect Page Repair'
EXEC msdb.dbo.sp_delete_job @job_name=N'AG Checks - Monitor Data Loss and Redo'
EXEC msdb.dbo.sp_delete_job @job_name=N'AG Checks - Monitor FileShareWitness'
GO

:CONNECT Node2

USE [msdb]

EXEC msdb.dbo.sp_delete_job @job_name=N'AG Checks - Detect Page Repair'
EXEC msdb.dbo.sp_delete_job @job_name=N'AG Checks - Monitor Data Loss and Redo'
EXEC msdb.dbo.sp_delete_job @job_name=N'AG Checks - Monitor FileShareWitness'
GO

:CONNECT Node3

USE [msdb]

EXEC msdb.dbo.sp_delete_job @job_name=N'AG Checks - Detect Page Repair'
EXEC msdb.dbo.sp_delete_job @job_name=N'AG Checks - Monitor Data Loss and Redo'
EXEC msdb.dbo.sp_delete_job @job_name=N'AG Checks - Monitor FileShareWitness'
GO