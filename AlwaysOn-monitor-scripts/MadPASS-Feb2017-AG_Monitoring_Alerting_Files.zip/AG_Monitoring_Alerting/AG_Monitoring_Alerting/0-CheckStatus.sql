/*
AlwaysOn Availability Groups - Monitoring and Alerting

Phil Ekins, copyright 2016

This code is provided as is for demonstration purposes. It may not be suitable for
your environment. Please test this on your own systems. This code may not be republished 
or redistributed by anyone without permission.
You are free to use this code inside of your own organization.

Use SQLCMD Mode

*/

:CONNECT Node1

DECLARE @log_send_queue_size NUMERIC, @log_send_rate NUMERIC, @redo_queue_size NUMERIC, @redo_rate NUMERIC, @DataLoss NUMERIC, @Redo NUMERIC

select @@servername 

SET @DataLoss = 0
SET @Redo = 0

SELECT 
	@log_send_queue_size=COALESCE(log_send_queue_size,0), 
	@log_send_rate=COALESCE(log_send_rate,0), 
	@redo_queue_size=COALESCE(redo_queue_size,0), 
	@redo_rate=COALESCE(redo_rate,0) 
FROM [master].[sys].[dm_hadr_database_replica_states] hdrs
	INNER JOIN [master].[sys].[dm_hadr_name_id_map] hnim ON hdrs.group_id = hnim.[ag_id]
	INNER JOIN [master].[sys].[dm_hadr_availability_replica_cluster_states] arcs ON hdrs.group_id = arcs.[group_id] AND hdrs.replica_id = arcs.replica_id
WHERE [ag_name] = 'MyAG' AND is_local = 1 

IF (@log_send_queue_size > 0 AND @log_send_rate > 0)
BEGIN
	SET @DataLoss = @log_send_queue_size / @log_send_rate
END

IF (@redo_queue_size > 0 AND @redo_rate > 0)
BEGIN
	SET @Redo = @redo_queue_size / @redo_rate
END

SELECT @DataLoss AS DataLossInSeconds, @log_send_queue_size AS LogSendQueueKB, @Redo As RedoInSeconds, @redo_queue_size AS RedoQueueSizeKB
GO

:CONNECT Node2

DECLARE @log_send_queue_size NUMERIC, @log_send_rate NUMERIC, @redo_queue_size NUMERIC, @redo_rate NUMERIC, @DataLoss NUMERIC, @Redo NUMERIC

SET @DataLoss = 0
SET @Redo = 0

select @@servername 

SELECT 
	@log_send_queue_size=COALESCE(log_send_queue_size,0), 
	@log_send_rate=COALESCE(log_send_rate,0), 
	@redo_queue_size=COALESCE(redo_queue_size,0), 
	@redo_rate=COALESCE(redo_rate,0) 
FROM [master].[sys].[dm_hadr_database_replica_states] hdrs
	INNER JOIN [master].[sys].[dm_hadr_name_id_map] hnim ON hdrs.group_id = hnim.[ag_id]
	INNER JOIN [master].[sys].[dm_hadr_availability_replica_cluster_states] arcs ON hdrs.group_id = arcs.[group_id] AND hdrs.replica_id = arcs.replica_id
WHERE [ag_name] = 'MyAG' AND is_local = 1 

IF (@log_send_queue_size > 0 AND @log_send_rate > 0)
BEGIN
	SET @DataLoss = @log_send_queue_size / @log_send_rate
END

IF (@redo_queue_size > 0 AND @redo_rate > 0)
BEGIN
	SET @Redo = @redo_queue_size / @redo_rate
END

SELECT @DataLoss AS DataLossInSeconds, @log_send_queue_size AS LogSendQueueKB, @Redo As RedoInSeconds, @redo_queue_size AS RedoQueueSizeKB
GO

:CONNECT Node3
DECLARE @log_send_queue_size NUMERIC, @log_send_rate NUMERIC, @redo_queue_size NUMERIC, @redo_rate NUMERIC, @DataLoss NUMERIC, @Redo NUMERIC

SET @DataLoss = 0
SET @Redo = 0

select @@servername 

SELECT 
	@log_send_queue_size=COALESCE(log_send_queue_size,0), 
	@log_send_rate=COALESCE(log_send_rate,0), 
	@redo_queue_size=COALESCE(redo_queue_size,0), 
	@redo_rate=COALESCE(redo_rate,0) 
FROM [master].[sys].[dm_hadr_database_replica_states] hdrs
	INNER JOIN [master].[sys].[dm_hadr_name_id_map] hnim ON hdrs.group_id = hnim.[ag_id]
	INNER JOIN [master].[sys].[dm_hadr_availability_replica_cluster_states] arcs ON hdrs.group_id = arcs.[group_id] AND hdrs.replica_id = arcs.replica_id
WHERE [ag_name] = 'MyAG' AND is_local = 1 

IF (@log_send_queue_size > 0 AND @log_send_rate > 0)
BEGIN
	SET @DataLoss = @log_send_queue_size / @log_send_rate
END

IF (@redo_queue_size > 0 AND @redo_rate > 0)
BEGIN
	SET @Redo = @redo_queue_size / @redo_rate
END

SELECT @DataLoss AS DataLossInSeconds, @log_send_queue_size AS LogSendQueueKB, @Redo As RedoInSeconds, @redo_queue_size AS RedoQueueSizeKB
GO