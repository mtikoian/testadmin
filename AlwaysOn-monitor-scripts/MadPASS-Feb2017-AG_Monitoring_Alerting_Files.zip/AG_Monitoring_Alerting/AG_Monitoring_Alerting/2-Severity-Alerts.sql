/*
AlwaysOn Availability Groups - Monitoring and Alerting

Phil Ekins, copyright 2016

This code is provided as is for demonstration purposes. It may not be suitable for
your environment. Please test this on your own systems. This code may not be republished 
or redistributed by anyone without permission.
You are free to use this code inside of your own organization.

Use SQLCMD Mode

*/

:CONNECT Node1

USE [msdb]

EXEC msdb.dbo.sp_add_alert @name=N'Severity 01480 - AG Role Change', 
		@message_id=1480, 
		@severity=0, 
		@enabled=1, 
		@delay_between_responses=600, 
		@include_event_description_in=1, 
		@category_name=N'[Uncategorized]', 
		@job_id=N'00000000-0000-0000-0000-000000000000'

EXEC msdb.dbo.sp_add_notification @alert_name=N'Severity 01480 - AG Role Change', @operator_name=N'SQLAdmin', @notification_method = 1

EXEC msdb.dbo.sp_add_alert @name=N'Severity 35264 - AG Data Movement - Suspended', 
		@message_id=35264, 
		@severity=0, 
		@enabled=1, 
		@delay_between_responses=600, 
		@include_event_description_in=1, 
		@category_name=N'[Uncategorized]', 
		@job_id=N'00000000-0000-0000-0000-000000000000'

EXEC msdb.dbo.sp_add_notification @alert_name=N'Severity 35264 - AG Data Movement - Suspended', @operator_name=N'SQLAdmin', @notification_method = 1

EXEC msdb.dbo.sp_add_alert @name=N'Severity 35265 - AG Data Movement - Resumed', 
		@message_id=35265, 
		@severity=0, 
		@enabled=1, 
		@delay_between_responses=600, 
		@include_event_description_in=1, 
		@category_name=N'[Uncategorized]', 
		@job_id=N'00000000-0000-0000-0000-000000000000'

EXEC msdb.dbo.sp_add_notification @alert_name=N'Severity 35265 - AG Data Movement - Resumed', @operator_name=N'SQLAdmin', @notification_method = 1
GO

:CONNECT Node2

USE [msdb]

EXEC msdb.dbo.sp_add_alert @name=N'Severity 01480 - AG Role Change', 
		@message_id=1480, 
		@severity=0, 
		@enabled=1, 
		@delay_between_responses=600, 
		@include_event_description_in=1, 
		@category_name=N'[Uncategorized]', 
		@job_id=N'00000000-0000-0000-0000-000000000000'

EXEC msdb.dbo.sp_add_notification @alert_name=N'Severity 01480 - AG Role Change', @operator_name=N'SQLAdmin', @notification_method = 1

EXEC msdb.dbo.sp_add_alert @name=N'Severity 35264 - AG Data Movement - Suspended', 
		@message_id=35264, 
		@severity=0, 
		@enabled=1, 
		@delay_between_responses=600, 
		@include_event_description_in=1, 
		@category_name=N'[Uncategorized]', 
		@job_id=N'00000000-0000-0000-0000-000000000000'

EXEC msdb.dbo.sp_add_notification @alert_name=N'Severity 35264 - AG Data Movement - Suspended', @operator_name=N'SQLAdmin', @notification_method = 1

EXEC msdb.dbo.sp_add_alert @name=N'Severity 35265 - AG Data Movement - Resumed', 
		@message_id=35265, 
		@severity=0, 
		@enabled=1, 
		@delay_between_responses=600, 
		@include_event_description_in=1, 
		@category_name=N'[Uncategorized]', 
		@job_id=N'00000000-0000-0000-0000-000000000000'

EXEC msdb.dbo.sp_add_notification @alert_name=N'Severity 35265 - AG Data Movement - Resumed', @operator_name=N'SQLAdmin', @notification_method = 1
GO

:CONNECT Node3

USE [msdb]

EXEC msdb.dbo.sp_add_alert @name=N'Severity 01480 - AG Role Change', 
		@message_id=1480, 
		@severity=0, 
		@enabled=1, 
		@delay_between_responses=600, 
		@include_event_description_in=1, 
		@category_name=N'[Uncategorized]', 
		@job_id=N'00000000-0000-0000-0000-000000000000'

EXEC msdb.dbo.sp_add_notification @alert_name=N'Severity 01480 - AG Role Change', @operator_name=N'SQLAdmin', @notification_method = 1

EXEC msdb.dbo.sp_add_alert @name=N'Severity 35264 - AG Data Movement - Suspended', 
		@message_id=35264, 
		@severity=0, 
		@enabled=1, 
		@delay_between_responses=600, 
		@include_event_description_in=1, 
		@category_name=N'[Uncategorized]', 
		@job_id=N'00000000-0000-0000-0000-000000000000'

EXEC msdb.dbo.sp_add_notification @alert_name=N'Severity 35264 - AG Data Movement - Suspended', @operator_name=N'SQLAdmin', @notification_method = 1

EXEC msdb.dbo.sp_add_alert @name=N'Severity 35265 - AG Data Movement - Resumed', 
		@message_id=35265, 
		@severity=0, 
		@enabled=1, 
		@delay_between_responses=600, 
		@include_event_description_in=1, 
		@category_name=N'[Uncategorized]', 
		@job_id=N'00000000-0000-0000-0000-000000000000'

EXEC msdb.dbo.sp_add_notification @alert_name=N'Severity 35265 - AG Data Movement - Resumed', @operator_name=N'SQLAdmin', @notification_method = 1
GO
