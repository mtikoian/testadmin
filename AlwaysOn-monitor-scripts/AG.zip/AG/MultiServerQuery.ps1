﻿function Get-CmsHosts() {
    <#
        .SYNOPSIS
        This function queries a CMS instance and returns a list of instances
        
        Written by Mark Wilkinson @m82labs on Twitter, website m82labs.com

        .PARAMETER cmdHost 
        The CMS host to connect to, this defaults to YODADB

        .PARAMETER searchPattern
        !!NOT INJECTION SAFE!! this parameter simply gets inserted into a wildcard query on the list of
        available instances on the CMS. This parameter accepts a pipe delimeter list of patterns, allowing
        you to match instance names on multiple conditions.

        .PARAMETER version
        The SQL Server version (build number) that should be running on the returned isntances.
        !! This will query each instance to get the build version, use in conjuction with searchPattern !!

        .EXAMPLE
        This will return all instances that start with 'RDU-' and are on SQL 2016 RTM
        Get-CMSHosts -searchPattern 'RDU-' -version '13.0.1605.1'

        .EXAMPLE
        This can be used in a 'ForEach':
        ForEach ( $instance in Get-CMSHosts -searchPattern 'RDU-' -version '13.0.1605.1' ) {
            #Do some stuff
        }
    #>
    param(
        [CmdletBinding()]
        [string]$cmsHost = '',
        [string]$searchPattern = '',
        [string]$instanceList,
        [string]$version
    )
    
    If ( $instanceList -and (Test-Path -Path $instanceList) ) {
        $results = Get-Content -Path $instanceList
    } Else {
        $pattern = ''

        For ( $pat_i = 0; $pat_i -lt ($searchPattern.Split('|')).Count; $pat_i++ ) {
            If ( $pat_i -gt 0 ) { $pattern += " OR " }
            $pattern += "server_name LIKE '$($searchPattern.Split('|')[$pat_i])%'"            
        }

        [string]$query_get_servers = "SELECT DISTINCT server_name FROM msdb.dbo.sysmanagement_shared_registered_servers WHERE {{searchPattern}}"
        $results = (Invoke-SqlCmd -query $query_get_servers.Replace('{{searchPattern}}',$pattern) -ServerInstance $cmsHost).server_name
    }

    If ( $version ) {
        ForEach ( $instance In $results ) {
            Try {
                If ( (Invoke-Sqlcmd -Query "SELECT SERVERPROPERTY('productversion') AS v" -ServerInstance $instance -ConnectionTimeout 1 -QueryTimeout 1 -ErrorAction Stop).v -ne $version) {
                    $results = $results | Where-Object { $_ -notmatch $instance }
                }
            } Catch {
                $connect_error += 1
		        Write-Host "failed: $($_.Exception.Message)" -ForegroundColor White -BackgroundColor Red
                $results = $results | Where-Object { $_ -notmatch $instance }
                continue
            }
        }
    }

    If ( $connect_error ) {
        Write-Host " -[$($connect_error) instance(s) skipped due to connection error]- " -ForegroundColor Red -NoNewline
    }

    return $results
}

function Query-MultipleServers() {
 <#
        .SYNOPSIS
        Queries multiple servers and outputs data to a grid.

        .PARAMETER sqlfile 
        Specifies sql to run against each server.

        .PARAMETER servers
        Array of servers to query.

        .EXAMPLE
        $servers = Get-CMSHosts -cmsHost "CMSServer" -searchPattern 'ST1'
        $servers = Get-CMSHosts -InstanceList 'c:\temp\servers.txt'
        Query-MultipleServers -sqlfile 'C:\temp\ag.sql' -servers $servers | Out-GridView

    #>
    param(
        [CmdletBinding()]
        [string]$sqlfile,
        [array]$servers
    )

    $dt = $null

    ForEach ( $server in $servers ) 
    {
        if ($dt -eq $null)
        {

           Try 
           {
                $dt = Invoke-SQLCMD -InputFile $sqlfile -ServerInstance $Server -database "master" -QueryTimeout 0 -As "DataTable"
           }
           catch 
           {
		        Write-Host "failed $($server): $($_.Exception.Message)" -ForegroundColor White -BackgroundColor Red
                continue
            }
           
        }
        else
        {
           Try 
           {
                $dt2 = Invoke-SQLCMD -InputFile $sqlfile -ServerInstance $Server -database "master" -QueryTimeout 0 -As "DataTable"
           }
           catch 
           {
		        Write-Host "failed $($server): $($_.Exception.Message)" -ForegroundColor White -BackgroundColor Red
                continue
            }
            
            if ($dt2.rows.count -gt 0)
            {
               $dt.Merge($dt2)
            }

        }
    }

    return $dt  
}


#$servers = Get-CMSHosts -cmsHost "YODA.channeladvisor.com" -searchPattern 'RDU-'
$servers = Get-CMSHosts -InstanceList 'c:\temp\servers.txt'
Query-MultipleServers -sqlfile 'C:\temp\ag2.sql' -servers $servers | Out-GridView