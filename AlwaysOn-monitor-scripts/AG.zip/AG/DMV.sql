SELECT *
FROM master.sys.dm_hadr_cluster_members 
WHERE member_type_desc = 'FILE_SHARE_WITNESS'

SELECT * 
FROM master.sys.dm_hadr_auto_page_repair
WHERE modification_time > DateAdd(hh,-1,getDate())

--Run on secondary
SELECT 
	log_send_queue_size, log_send_rate, redo_queue_size, redo_rate
FROM master.sys.dm_hadr_database_replica_states hdrs
	INNER JOIN master.sys.dm_hadr_name_id_map hnim ON hdrs.group_id = hnim.ag_id
	INNER JOIN master.sys.dm_hadr_availability_replica_cluster_states arcs ON hdrs.group_id = arcs.group_id AND hdrs.replica_id = arcs.replica_id
WHERE is_local = 1 