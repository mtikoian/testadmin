DECLARE @PrimaryReplica sysname; 

        SELECT @PrimaryReplica = hags.primary_replica 
        FROM sys.dm_hadr_availability_group_states hags
            INNER JOIN sys.availability_groups ag ON ag.group_id = hags.group_id

IF UPPER(@PrimaryReplica) <>  UPPER(@@SERVERNAME)

    SELECT @@servername,
		ar.replica_server_name, 
		adc.database_name, 
		drs.synchronization_health_desc, 
		drs.log_send_queue_size, 
		drs.log_send_rate, 
		drs.redo_queue_size, 
		drs.redo_rate,
		GETUTCDATE()
	FROM sys.dm_hadr_database_replica_states AS drs
	INNER JOIN sys.availability_databases_cluster AS adc 
		ON drs.group_id = adc.group_id AND 
		drs.group_database_id = adc.group_database_id
	INNER JOIN sys.availability_groups AS ag
		ON ag.group_id = drs.group_id
	INNER JOIN sys.availability_replicas AS ar 
		ON drs.group_id = ar.group_id AND 
		drs.replica_id = ar.replica_id
	WHERE drs.is_primary_replica = 0
	ORDER BY 
		ag.name, 
		ar.replica_server_name, 
		adc.database_name;