CREATE FUNCTION dbo.fnTestHADRPrimary
RETURNS BIT 
AS
DECLARE @PrimaryReplica sysname; 

IF SERVERPROPERTY ('IsHadrEnabled') = 1
BEGIN
	SELECT @PrimaryReplica = RCS.replica_server_name 
	FROM sys.availability_groups_cluster AS AGC
		INNER JOIN sys.dm_hadr_availability_replica_cluster_states AS RCS ON RCS.group_id = AGC.group_id
		INNER JOIN sys.dm_hadr_availability_replica_states AS ARS ON ARS.replica_id = RCS.replica_id
	WHERE ARS.role_desc = 'PRIMARY'
END
ELSE
	BEGIN
		SET @PrimaryReplica = @@SERVERNAME
	END

IF UPPER(@PrimaryReplica) <> UPPER(@@SERVERNAME)
BEGIN
	RETURN 1
END
ELSE
BEGIN
	RETURN 0
END
GO