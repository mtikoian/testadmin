﻿cls
# 1. Run once to show all nodes have a vote.
Import-Module FailoverClusters

Get-ClusterNode | 
    Format-List NodeName, 
     NodeWeight, DynamicWeight

Get-Cluster | 
    Format-List WitnessDynamicWeight
    










# 2. Remove AGDemo2's vote
### Simulate server drop.

(get-clusternode agdemo2).Nodeweight  = 0

# 2.a. Run again to show the recalculation.

Get-ClusterNode | 
    Format-List NodeName, 
     NodeWeight, DynamicWeight

Get-Cluster | 
    Format-List WitnessWeight, 
    WitnessDynamicWeight

# Unsure about the official timeframe.
# Most experts use 2 minutes as a safe number.
# It may not always recalcuate this fast.
Start-Sleep -s 5


Get-ClusterNode | 
    Format-List NodeName, 
     NodeWeight, DynamicWeight

Get-Cluster | 
    Format-List WitnessWeight, 
    WitnessDynamicWeight








    








# 3. Tie-breaker

(get-cluster) | select LowerQuorumPriorityNodeId | fl

write-host "LowerQuorumPriorityNodeId set to AGDemo1 ID: $((get-clusternode AGDemo1).Id)";
(get-cluster).LowerQuorumPriorityNodeId = (get-clusternode AGDemo1).Id

(get-cluster) | select LowerQuorumPriorityNodeId | fl


# 3.a. Test tie-breaker

#### Put AGDemo2's vote back in and
#### remove the witness.

(get-clusternode agdemo2).Nodeweight  = 1

Set-ClusterQuorum -NoWitness | out-null

Start-Sleep -s 5

#### Run again to show AGDemo1 lost its dynamic vote


Get-ClusterNode | 
    Format-List NodeName, 
     NodeWeight, DynamicWeight

Get-Cluster | 
    Format-List WitnessWeight, 
    WitnessDynamicWeight












# 4. Reset

Invoke-Command -ComputerName AGDemo2 `
    -ScriptBlock { start-service clussvc; }

(get-cluster).LowerQuorumPriorityNodeId = 0

if( (get-clusternode agdemo1).Nodeweight -eq 0)
{ (get-clusternode agdemo1).Nodeweight = 1 }

if( (get-clusternode agdemo2).Nodeweight -eq 0)
{ (get-clusternode agdemo2).Nodeweight = 1 }

Set-ClusterQuorum -NoWitness | out-null
Set-ClusterQuorum -FileShareWitness \\ad1\share | out-null

Start-Sleep -s 5

Get-ClusterNode | 
    Format-List NodeName, 
     NodeWeight, DynamicWeight

Get-Cluster | 
    Format-List WitnessWeight, 
    WitnessDynamicWeight



