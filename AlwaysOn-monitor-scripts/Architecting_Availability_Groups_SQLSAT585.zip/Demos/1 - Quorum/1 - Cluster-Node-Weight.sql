
SELECT member_name
	, member_state_desc
	, number_of_quorum_votes
FROM sys.dm_hadr_cluster_members;

