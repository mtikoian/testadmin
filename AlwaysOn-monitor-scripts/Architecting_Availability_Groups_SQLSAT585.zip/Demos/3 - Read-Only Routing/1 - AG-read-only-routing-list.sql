
/**********************************************************/
-- Configure AlwaysOn read-only routing list
/**********************************************************/

USE [master]

--Setup routing URLs
--MAKE SURE NOT TO USE YOUR ENDPOINT PORTS!
ALTER AVAILABILITY GROUP [AGDemo] modify REPLICA ON N'AGDemo1'
WITH 
(SECONDARY_ROLE 
(READ_ONLY_ROUTING_URL = N'TCP://AGDemo1.sqlhammer.demo:1433')
);

ALTER AVAILABILITY GROUP [AGDemo] modify REPLICA ON N'AGDemo2'
WITH 
(SECONDARY_ROLE 
(READ_ONLY_ROUTING_URL = N'TCP://AGDemo2.sqlhammer.demo:1433')
);

--Pick nodes to route to when primary
ALTER AVAILABILITY GROUP [AGDemo] MODIFY REPLICA ON N'AGDemo1' 
WITH 
(PRIMARY_ROLE
(READ_ONLY_ROUTING_LIST=(N'AGDemo2', N'AGDemo1'))
)

ALTER AVAILABILITY GROUP [AGDemo] MODIFY REPLICA ON N'AGDemo2' 
WITH (
PRIMARY_ROLE(READ_ONLY_ROUTING_LIST=(N'AGDemo1', N'AGDemo2'))
)




-- Restart listener for configuration to take effect.

ALTER AVAILABILITY GROUP [AGDemo] RESTART LISTENER 'AGL_Demo';





/**********************************************************/
-- View AG read-only routing list
/**********************************************************/

-- On primary to verify successful configuration.

SELECT re.replica_server_name AS 'when primary'
	, re2.replica_server_name AS 'routed to'
	, re2.read_only_routing_url
	, li.routing_priority
FROM sys.availability_read_only_routing_lists li
INNER JOIN sys.availability_replicas re 
	ON li.replica_id = re.replica_id
INNER JOIN sys.availability_replicas re2 
	ON li.read_only_replica_id = re2.replica_id
ORDER BY re.replica_server_name, li.routing_priority



