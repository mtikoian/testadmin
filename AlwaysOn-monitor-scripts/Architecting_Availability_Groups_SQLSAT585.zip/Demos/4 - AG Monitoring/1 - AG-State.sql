
-- Identifies 
--    - all replicas
--    - which node is primary
--    - availability mode (sync / async)
--    - failover mode (manual / auto)

SELECT replica_server_name
, AG.name AS [AG_Name], HAGS.primary_replica
, availability_mode_desc, failover_mode_desc

FROM sys.availability_replicas AR

INNER JOIN sys.dm_hadr_availability_group_states HAGS
	ON HAGS.group_id = AR.group_id

INNER JOIN sys.availability_groups AG 
	ON AG.group_id = HAGS.group_id;

	
	
	
	
	
	
	
	
-- Identifies synchronization states of your AG databases
--    - NOT SYNCHRONIZING
--    - SYNCHRONIZING
--    - SYNCHRONIZED
--    - REVERTING
--    - INITIALIZING
select AR.replica_server_name
, DB_NAME(database_id) [Database]
, ST.synchronization_state_desc [SyncState]

FROM sys.dm_hadr_database_replica_states ST

INNER JOIN sys.availability_groups AG 
	ON AG.group_id = ST.group_id

INNER JOIN sys.availability_replicas AR 
	ON AR.replica_id = ST.replica_id



