﻿New-NetFirewallRule -DisplayName "Allow pinging" -Direction Inbound -Action Allow -Protocol "ICMPv4" -Description "Allow pinging from outside"

New-NetFirewallRule -DisplayName "SQL Server Access via Port 1433" -Direction Inbound -Action Allow -Protocol TCP –LocalPort 1433 -Description "SQL Server Port access Rule"
New-NetFirewallRule -DisplayName "SQL Server Access via Port 1434" -Direction Inbound -Action Allow -Protocol TCP –LocalPort 1434 -Description "SQL Server Port access Rule"



