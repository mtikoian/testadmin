SELECT net_transport, protocol_type, auth_scheme, local_net_address, local_tcp_port, client_net_address
, s.host_name
FROM sys.[dm_exec_connections] as cn
INNER JOIN sys.dm_exec_sessions s on cn.session_id = s.session_id;
 

