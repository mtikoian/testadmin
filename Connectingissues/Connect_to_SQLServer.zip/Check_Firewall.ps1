﻿cls 
$Direction = "Inbound"  # Options: "Inbound"/"Outbound"
$Action = "Allow"       # Options: "Allow"/"Block"
$Enabled = "True"       # Options: "True"/"False"
$RuleGroup = $Null      # Options:  $Null / Gropup Name
$DisplayName = "*SQL*"  # Option:  "*SQL*" / "*" / Any regular expression

$Firewall = @()
$Rules = Get-NetFirewallRule |`
       where { $_.Direction -eq $Direction} |`
       where { $_.Action -eq $Action} |`
       where { $_.Enabled -eq $Enabled} |`
       where { $_.RuleGroup -eq $RuleGroup} |`
       where { $_.DisplayName -like $DisplayName} |`
       Select DisplayName, RuleGroup, InstanceID, Enabled, Direction, Action
foreach ($App in Get-NetFirewallApplicationFilter | Select Program, InstanceID)
{
       $InstanceID = ($App | Format-Table -Property InstanceID -HideTableHeaders | Out-String).Trim()
       $Rule = $Rules | Where { $_.InstanceID -eq $InstanceID}
       $DisplayName = ($Rule.DisplayName + "").Trim()
       If ($DisplayName -ne ""  -or $DisplayName -like "*SQL*" ) {
              $Program = ($App | Format-Table -Property Program -HideTableHeaders | Out-String).Trim()
              $Ports = Get-NetFirewallPortFilter | Where { $_.InstanceID -eq $InstanceID}

              If ($Ports.Protocol -eq "TCP" -or $Ports.Protocol -eq "UDP" -or $Program -ne "Any") {
                     $Firewall += New-Object -TypeName PSObject -Property @{
                           DisplayName = $DisplayName
                           RuleGroup = $Rule.RuleGroup
                           Direction = $Rule.Direction
                           Action = $Rule.Action
                           Enabled = $Rule.Enabled
                           Protocol = $Ports.Protocol
                           LocalPort = $Ports.LocalPort
                           RemotePort = $Ports.RemotePort
                           RemoteAddress = (Get-NetFirewallAddressFilter | where { $_.InstanceID -eq $InstanceID}).RemoteAddress
                           Program = $Program
                           InstanceID = $InstanceID
                     } 
              }
       }
}
$Firewall | Format-table -AutoSize -Property DisplayName, RuleGroup, Direction, Action, Enabled, Protocol, LocalPort, RemotePort, RemoteAddress, Program