/*
Slava Murygin

Presentation: Connectivity to SQL Server

SQL Saturday #588 New York, NY

2017-05-20

*/

/*
Scenario: Connect to SQL Server.

1. Service is stopped
2. Wrong Server name
3. Wrong Database / no rights to a "current" database

*/

/*
# 1 Try to connect to "SLAVAMOBILE" via SSMS
user: connect2014
Pass: connect2014
*/

/*
TROUBLESHOOTING:

Start Powershell as Admin
*/

/*
A. Pinging:
ping SLAVAMOBILE
ping SLAVAMOBILE -4
*/

/*
B. Verify that SQL Server is installed:
Open SQL Server Configuration Manager as ADMINISTRATOR:
Check

Powershell:
Get-WMIObject win32_service | Where-Object { $_.DisplayName+$_.Name -like "*SQL*" } | Sort-Object state,displayname | Format-Table -Autosize -Property State, Name, DisplayName, StartMode, PathName 

CMD:
sc queryex type= service state= all | find /i "SQL"
*/

/*
C. Verify that SQL Server is up and running 

Open SQL Server Configuration Manager as ADMINISTRATOR
Start service

POWERSHELL:
Start-Service -displayname "SQL Server (SQLEXPRESS)"

CMD:
NET START "SQL Server (SQLEXPRESS)"
*/

/*
2. Try to connect to SLAVAMOBILE\SQLEXPRESS
user: connect
Pass: connect

*/

/*
3. Try to connect to SLAVAMOBILE\SQLEXPRESS
user: connect
Pass: connect

Correct user to "connect2014"
*/

/*
3. Try to connect to SLAVAMOBILE\SQLEXPRESS
user: connect2014
Pass: connect

Correct password to "connect2014"
*/

/*
5. Try to connect to SLAVAMOBILE\SQLEXPRESS
user: connect2014
Pass: connect2014

Change Default Database to "tempdb"
*/
SELECT @@VERSION;
