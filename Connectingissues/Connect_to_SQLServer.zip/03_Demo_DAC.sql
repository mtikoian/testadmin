/*
Slava Murygin

Presentation: Connectivity to SQL Server

SQL Saturday #588 New York, NY

2017-05-20

*/

/*
Scenario: Users can't connect because of too many connections. Saving with DAC.

0. Set DAC.
1. Artificially lower number of DB connections
2. Restart SQL Server
3. Run a batch process to consume all possible connections.
4. Trying to connect via SSMS and get an error
5. Connect with DAC.

*/
/* Look at current parameters */
SELECT * FROM sys.configurations
WHERE name like '%connections%';

/* #0. Allowing Dedicated Admin Connections */
SP_CONFIGURE 'remote admin connections', 1
GO
RECONFIGURE
GO

/* #1. Limiting Number of user connections  */
SP_CONFIGURE 'show advanced options',1
GO
RECONFIGURE
GO
SP_CONFIGURE 'user connections', 3
GO
RECONFIGURE
GO

/* Look at current parameters again */
SELECT * FROM sys.configurations
WHERE name like '%connections%';

/* Check for any opened connections */
SELECT session_id, net_transport, Endpoint_id, Auth_scheme,
Local_Net_Address, Local_TCP_Port, Client_Net_Address
FROM sys.[dm_exec_connections] cn;
GO
/*
Run CMD as Administrator

#2  Restart SQL Server

ReStart-Service -displayname "SQL Server (SQLEXPRESS)"
OR
NET STOP MSSQLSERVER
NET START MSSQLSERVER
*/

/*
#3 Try to run a batch process to consume all possible connections.

FOR /L %G IN (1,1,5) DO START "SQL Runner Window" /min sqlcmd -S localhost -E
*/

/* #4 Try to connect with SSMS */
SELECT session_id, net_transport, Endpoint_id, Auth_scheme,
Local_Net_Address, Local_TCP_Port, Client_Net_Address
FROM sys.[dm_exec_connections] cn;
GO
/*
Try to connect with sqlcmd:

sqlcmd -S localhost -E
*/



/*
# 5 Connect using DAC

admin:192.168.58.1
admin:localhost
admin:localhost,1433
SLAVAMOBILE\SQLEXPRESS,51194
*/

/* Check for any opened connections */
SELECT session_id, net_transport, Endpoint_id, Auth_scheme,
Local_Net_Address, Local_TCP_Port, Client_Net_Address
FROM sys.[dm_exec_connections] cn;
GO
KILL 51;
GO
KILL 54;
GO

/*
Now can establish anoter connection:

sqlcmd -S localhost -E
*/

/*
We will fail if will try to establish another DAC connection

sqlcmd -S localhost -E -A
*/


/* Restore Limit Number of user connections */
SP_CONFIGURE 'user connections', 10
GO
RECONFIGURE
GO
SP_CONFIGURE 'show advanced options',0
GO
RECONFIGURE
GO
SP_CONFIGURE 'remote admin connections', 0
GO
RECONFIGURE
GO

/*
SELECT CAST(value as INT) as value, CAST(value_in_use AS INT) as value_in_use
FROM sys.configurations WHERE name = 'remote admin connections';

SELECT Session_id, Endpoint_id FROM sys.[dm_exec_connections] cn;

*/