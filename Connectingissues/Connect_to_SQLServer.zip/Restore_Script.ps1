#RUN ISE as an administrator

#Get SQL Server Services: 
Get-WMIObject win32_service | Where-Object { $_.DisplayName+$_.Name -like "*SQL*" } | Sort-Object state,displayname | Format-Table -Autosize -Property State, Name, DisplayName, StartMode, PathName 


#Get SQL Server Instance Path:
$SQLService = "SQL Server (SQLEXPRESS)"; 
$SQLInstancePath = "";
$SQLServiceName = ((Get-Service | WHERE { $_.DisplayName -eq $SQLService }).Name).Trim();
If ($SQLServiceName.contains("`$")) { $SQLServiceName = $SQLServiceName.SubString($SQLServiceName.IndexOf("`$")+1,$SQLServiceName.Length-$SQLServiceName.IndexOf("`$")-1) }
foreach ($i in (get-itemproperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server").InstalledInstances)
{
  If ( ((Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL").$i).contains($SQLServiceName) ) 
  { $SQLInstancePath = "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\"+`
  (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL").$i}
} 
$SQLInstancePath

#Enable/Disable network protocols:
$Protocol = "Tcp" # Options: Tcp/Np/Via/Sm
$Enabled = "0"     # Options: "0" - Disabled / "1" - Enabled
(Get-ItemProperty "$SQLInstancePath\MSSQLServer\SuperSocketNetLib\$Protocol").Enabled
Set-ItemProperty -Path "$SQLInstancePath\MSSQLServer\SuperSocketNetLib\$Protocol" -Name "Enabled" -Value $Enabled

$Protocol = "Sm" # Options: Tcp/Np/Via/Sm
$Enabled = "1"     # Options: "0" - Disabled / "1" - Enabled
Set-ItemProperty -Path "$SQLInstancePath\MSSQLServer\SuperSocketNetLib\$Protocol" -Name "Enabled" -Value $Enabled
(Get-ItemProperty "$SQLInstancePath\MSSQLServer\SuperSocketNetLib\$Protocol").Enabled


# Enable/Disable ListenOnAllIPs TCP protocol property:
$Enabled = "0"    # Options: "0" - Disabled / "1" - Enabled
(Get-ItemProperty "$SQLInstancePath\MSSQLServer\SuperSocketNetLib\Tcp").ListenOnAllIPs
Set-ItemProperty -Path "$SQLInstancePath\MSSQLServer\SuperSocketNetLib\Tcp" -Name "ListenOnAllIPs" -Value $Enabled
(Get-ItemProperty "$SQLInstancePath\MSSQLServer\SuperSocketNetLib\Tcp").ListenOnAllIPs


# Set IP protocol's properties:
$IPProtocol="IP4"   # Options: "IPALL"/"IP4"/"IP6"/Etc
$Enabled = "0"            # Options: "0" - Disabled / "1" - Enabled
$Active = "1"              # Options: "0" - Inactive / "1" - Active
$Port = ""                   # Options: "0"/"" (Empty)
$DynamicPort = "0"    # Options: "0"/"" (Empty)
$IPAddress="127.0.0.1"        # There must not be IP Address duplication for any IP Protocol

$SQLTcpPath = "$SQLInstancePath\MSSQLServer\SuperSocketNetLib\Tcp"
Get-ChildItem $SQLTcpPath | ForEach-Object {Get-ItemProperty $_.pspath} `
| Format-Table -Autosize -Property @{N='IPProtocol';E={$_.PSChildName}}, Enabled, Active, TcpPort, TcpDynamicPorts, IpAddress

Set-ItemProperty -Path "$SQLTcpPath\$IPProtocol" -Name "Enabled" -Value $Enabled
Set-ItemProperty -Path "$SQLTcpPath\$IPProtocol" -Name "Active" -Value $Active
Set-ItemProperty -Path "$SQLTcpPath\$IPProtocol" -Name "TcpPort" -Value $Port
Set-ItemProperty -Path "$SQLTcpPath\$IPProtocol" -Name "TcpDynamicPorts" -Value $DynamicPort
Set-ItemProperty -Path "$SQLTcpPath\$IPProtocol" -Name "IPAddress" -Value $IPAddress

$IPProtocol="IPALL"   # Options: "IPALL"/"IP4"/"IP6"/Etc
$Port = ""                   # Options: "0"/"" (Empty)
Set-ItemProperty -Path "$SQLTcpPath\$IPProtocol" -Name "TcpPort" -Value $Port


Get-ChildItem $SQLTcpPath | ForEach-Object {Get-ItemProperty $_.pspath} `
| Format-Table -Autosize -Property @{N='IPProtocol';E={$_.PSChildName}}, Enabled, Active, TcpPort, TcpDynamicPorts, IpAddress


#Stop/Start/Restart SQL Server Service:
Stop-Service -displayname "SQL Server (SQLEXPRESS)"
# Start-Service -displayname "SQL Server (SQLEXPRESS)"

Remove-NetFirewallRule -DisplayName "SQL Server Access via Port 1433"
Remove-NetFirewallRule -DisplayName "SQL Server Access via Port 1434"
Remove-NetFirewallRule -DisplayName "Allow pinging"


