/*
Slava Murygin

Presentation: Connectivity to SQL Server

SQL Saturday #588 New York, NY

2017-05-20

*/


SELECT @@VERSION;

/*
Scenario: Connect to SQL Server via TCP/IP.

1. Try to connect to "SLAVAMOBILE\SQLEXPRESS,1433" via SSMS
2. 

*/

/*
# 1 Try to connect to "SLAVAMOBILE\SQLEXPRESS,1433" via SSMS
user: connect2014
Pass: connect2014

TROUBLESHOOTING:
ERRORLOG does not have "Listening to"

FIX:
In SQL Server Configuration Manager Enable TCP/IP protocol and disable Shared Memory

*/
SELECT @@VERSION;

/*
# 2 Try to connect to "127.0.0.1\SQLEXPRESS,1433" via SSMS
user: connect2014
Pass: connect2014

TROUBLESHOOTING:
ERRORLOG Has: "no TCP listening ports configured"

FIX:
In SQL Server Configuration Manager IN IPv4 change Dynamic port as 1433
+ Turn off Shared Memeory Protocol
+ Restart SQL Server
*/
SELECT @@VERSION;

/*
# 3 Look in the error log for "Listening port"
Try to connect to "127.0.0.1\SQLEXPRESS,XXXX" to that port
user: connect2014
Pass: connect2014

FIX:
In SQL Server Configuration Manager IN IPv4 assign IP address as "192.168.1.2" (current computer IP address)
+ Restart SQL Server
*/
SELECT @@VERSION;

/*

# 4 Try to connect from outside to "<IP ADDRESS>\SQLEXPRESS,1433" via SSMS
user: connect2014
Pass: connect2014

TROUBLESHOOTING:
ERRORLOG Has: "no TCP listening ports configured"

FIX:
In SQL Server Configuration Manager turn ON IPv4 and assign port 1433
*/
SELECT @@VERSION;


/*
For External users:
Run wf.msc as administrator

#5 Firewall: make computer pingable
#6 Firewall: open port 1433

Via Powershell:
New-NetFirewallRule -DisplayName "Allow pinging" -Direction Inbound -Action Allow -Protocol "ICMPv4" -Description "Allow pinging from outside"
New-NetFirewallRule -DisplayName "SQL Server Access via Port 1433" -Direction Inbound -Action Allow -Protocol TCP �LocalPort 1433 -Description "SQL Server Port access Rule"


*/

SELECT @@VERSION;


