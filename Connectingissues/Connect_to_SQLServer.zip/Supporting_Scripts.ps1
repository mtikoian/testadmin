﻿sqlcmd -S "127.0.0.1,1433" -E -Q "SELECT @@VERSION"
sqlcmd -S "127.0.0.1,1434" -E -Q "SELECT @@VERSION"

sqlcmd -S "192.168.1.2,1433" -E -Q "SELECT @@VERSION"

sqlcmd -S "localhost\SQLEXPRESS,1433" -E -Q "SELECT Session_id, Endpoint_id FROM sys.[dm_exec_connections]"

sqlcmd -S "localhost\SQLEXPRESS,1434" -E -Q "SELECT Session_id, Endpoint_id FROM sys.[dm_exec_connections]"
sqlcmd -S "localhost\SQLEXPRESS" -E -Q "SELECT Session_id, Endpoint_id FROM sys.[dm_exec_connections]"

sqlcmd -S "localhost\SQLEXPRESS" -E -Q "SELECT Session_id, Endpoint_id FROM sys.[dm_exec_connections]" -A

sqlcmd -S "localhost\SQLEXPRESS,1433" -d "tempdb" -Q "SELECT @@VERSION" -U connect2014 -P connect2014


Stop-Service -displayname "SQL Server (SQLEXPRESS)"
Start-Service -displayname "SQL Server (SQLEXPRESS)"
ReStart-Service -displayname "SQL Server (SQLEXPRESS)"

IPCONFIG
ping 192.168.1.2
ping 192.168.1.142
