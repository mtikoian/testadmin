Problem Description: 
====================

Intermittent GNE.



Environment:
================
Webservice: 10.90.93.73 
SQLServer: 10.90.77.20


