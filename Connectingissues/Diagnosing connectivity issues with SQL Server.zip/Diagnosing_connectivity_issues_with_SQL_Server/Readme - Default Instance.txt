Filter on 1433 and or TDS to show the SQL traffic.  Explain the stages of the login:
1)  Three-way handshake at the TCP level
2)  Negotiation of TDS version
3)  SSL handshake
4)  Login packets
5)  TDS response showing a successful login