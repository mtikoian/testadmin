SELECT * FROM sys.dm_io_virtual_file_stats (NULL, NULL);
GO