#-----------------------------------------------
# Run upgrade advisor against a bunch of servers
# Craig Purnell
# Upgrade Roadmap: Let's Delve into SQL 2012
#-----------------------------------------------
$servers = Get-Content "c:\UpgradeAdvisor\110\servers.txt"
foreach ($server in $servers)
{
	$str = $server.split("\")
	if ($str.Count -eq 1)
	{
		$instance = 'MSSQLSERVER'
	}
	else
	{	
		$instance = $str[1]
	}
	$hostname = $str[0]
	
	.\UpgradeAdvisorWizardCMD.exe -Server $hostname -Instance $instance
}