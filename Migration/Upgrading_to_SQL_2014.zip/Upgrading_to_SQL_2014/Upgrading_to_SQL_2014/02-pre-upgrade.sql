-----------------------------------------------------
-- Pre-upgrade steps on SQL 2000                   --
-----------------------------------------------------


-- Run Upgrade Advisor and review report
















-- Connect to SQL2k5\MSSQL2000INST01
-- Run CHECKDB 
DBCC 
	CHECKDB (Northwind) 
WITH 
	ALL_ERRORMSGS, -- Displays all reported errors per object. All error messages are displayed by default.
	NO_INFOMSGS ; -- Suppresses all informational messages.





















-- Check and set autogrowth of database and log files
USE [Northwind]
GO

SELECT name,  fileid, filename,filegroup = filegroup_name(groupid),
'size' = convert(nvarchar(15), convert (bigint, size) * 8) + N' KB',
'maxsize' = ( CASE maxsize 
	WHEN -1 THEN N'Unlimited'
	ELSE convert(nvarchar(15), convert (bigint, maxsize) * 8) + N' KB' end),
'growth' = ( CASE status & 0x100000 
		WHEN 0x100000 THEN convert(nvarchar(15), growth) + N'%'
	ELSE convert(nvarchar(15), convert (bigint, growth) * 8) + N' KB' end),
'usage' = (	CASE status & 0x40 WHEN 0x40 THEN 'log only' 
		ELSE 'data only' end)
FROM sysfiles;






















-- Enable auto update stats
ALTER 
	DATABASE [Northwind] 
SET 
	AUTO_UPDATE_STATISTICS ON 
WITH 
	NO_WAIT;
GO


