--use admin
--go
----- Create the following table or results come back empty
--Create Table  DBSpaceUsedFileGroupExclude (
--Databasename sysname,
--FilegroupName sysname
--)

--------------



--Drop procedure DBSpaceUsed 
--go
--create procedure DBSpaceUsed as
set nocount on
Declare @DBName sysname
Declare @CMD varchar(1000)

Create Table #FooTable (
	[DBName]	sysname NULL,
	[FileId]	int,
	[FileGroup]	int,
	[TotalExtents]	int,
	[UsedExtents]	int,
	[DevName]	sysname,
	[FileName]	sysname,
	[FileGroupName]	sysname NULL,
	[LargestObjectSize] int)


Declare DBCursor cursor READ_ONLY FORWARD_ONLY for Select [name] from master.dbo.sysdatabases
--	where [name] in ('SiteData', 'JobAppl')
-- Exclusion now based on table Admin.dbo.DBSpaceUsedFileGroupExclude.  Table contains database and filegroup
-- names that are deleted from the final table.

open DBCursor
Fetch next from DBCursor into @DBName
while 0 = @@Fetch_Status 
	begin
	select @CMD = 'USE [' + @DBName + '] dbcc ShowFileStats with TABLERESULTS'
	insert INTO #FooTable (FileId,
	[FileGroup],
	TotalExtents,
	UsedExtents,
	DevName,
	[FileName]) exec (@CMD)
	update #FooTable set DBName = @DBName
	where DBName is null
	select @CMD = 'USE [' + @DBName + '] Update #FooTable set [FileGroupName] = SFG.GroupName
		from #FooTable FT
		inner join sysfilegroups SFG
		on FT.[FileGroup] = SFG.[GroupID]
	where FT.[FileGroupName] IS NULL'

	exec (@CMD)

	select @CMD = 'USE [' + @DBName + '] Update #FooTable SET [LargestObjectSize] = (		SELECT TOP 1
	 SUM (
			CASE
				WHEN (DPS.index_id < 2) THEN (in_row_data_page_count + lob_used_page_count + row_overflow_used_page_count)
				ELSE lob_used_page_count + row_overflow_used_page_count
			END
			)/ 1024 as ''Pages''			
	FROM sys.dm_db_partition_stats DPS
	GROUP BY DPS.object_id
	ORDER BY Pages DESC ) 
	FROM #FooTable
	WHERE ''' + @DBName + ''' = [DBName]'
	--SELECT @Cmd
	Exec (@CMD)

	Fetch next from DBCursor into @DBName
	END

Close DBCursor
Deallocate DBCursor
--delete from #FooTable 
--	from #FooTable FT
	--inner join Admin.dbo.DBSpaceUsedFileGroupExclude EX
	--	on EX.Databasename = FT.DBName
	--	and EX.FileGroupName = FT.FileGroupName 

--select @@Servername as Server, DBName,         FileGroupName,
--        convert(decimal (5,2), 100 - (sum(TotalExtents)-SUM(UsedExtents)) /(convert(numeric,sum(TotalExtents))) * 100) as PercentFull,
--	(sum(TotalExtents)  * 64) /(1024 ) AS MBTotal,
--	(sum(UsedExtents) * 64) /(1024 ) AS MBUsed,
--	(sum(TotalExtents - UsedExtents) * 64) /(1024 ) AS MBFree,
--	(SUM(SF.size * 64) / 1024) AS "Log Size (MB)"
--        from #FooTable FT
--        INNER JOIN sysdatabases SD
--			ON SD.name = FT.DBName
--		left Join sys.SysAltFiles SF
--			ON SD.dbid = SD.dbid
--			AND SF.groupid = 0		
--	group by DBName, FileGroupName


select @@Servername as Server, DBName,         FileGroupName,
        convert(decimal (5,2), 100 - (sum(TotalExtents)-SUM(UsedExtents)) /(convert(numeric,sum(TotalExtents))) * 100) as PercentFull,
	(sum(TotalExtents)  * 64) /(1024 ) AS 'Total (MB)',
	(sum(UsedExtents) * 64) /(1024 ) AS 'Used (MB)',
	(sum(TotalExtents - UsedExtents) * 64) /(1024 ) AS 'Free (MB)',
	(SUM(SF.size) * 64) / 1024 AS 'Log Size (MB)',
	MAX(FT.	LargestObjectSize) AS 'largestObjectSize (MB)'

	--(SUM(SF.size) * 64) / 1024 AS "Log Size (MB)"
	--		 SUM (
	--		CASE
	--			WHEN (index_id < 2) THEN (in_row_data_page_count + lob_used_page_count + row_overflow_used_page_count)
	--			ELSE lob_used_page_count + row_overflow_used_page_count
	--		END
	--		) as 'Pages',
        from #FooTable FT
        INNER JOIN sys.databases SD
			ON SD.name = FT.DBName
		left Join sys.master_files SF
			ON SD.database_id = SF.database_id
			AND SF.Type = 1
	group by DBName, FileGroupName

drop Table #FooTable


