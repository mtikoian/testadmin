/************************************************************************
 *									*
 *	Title:	Backup File Deletion Procedure				*
 *	Author:	Geoff N. Hiten						*
 *	Purpose: Removes old backup files in a designated folder	*
 *	Date: 08/9/2005							*
 *	Modifications:							*
 *									*
 *	06-22-2001							*
 *		Sample Entry						*
 *									*
 *									*
 ************************************************************************/
USE Admin
GO
if exists (Select * from INFORMATION_SCHEMA.ROUTINES
	where ROUTINE_NAME = 'uspFindMostRecentFile')
DROP PROCEDURE uspFindMostRecentFile
go

CREATE PROCEDURE uspFindMostRecentFile 
	@FilePath varchar(400),
	@FileName varchar (400) OUTPUT
AS

SET NOCOUNT ON

--Debugging variable declaration

Declare @RetainMinutes int
--Declare @FilePath varchar(400)

--SET @RetainMinutes = 11520
--SET @FilePath = '\\SQLData\SQLBackups\A1DSSPD02\Daily'

--END Debugging variable declaration

--Stupidity check
--All Variable declarations in one place
DECLARE @CommandString varchar(4000)
DECLARE @RetCode int

--Raw Directory Import
Create Table #FileListRaw (RawFileName varchar(400))
--Cleaned and parsed file list
Create Table #FileListStruct (
	FileListID int IDENTITY(1,1) NOT NULL,
	FileDateTime datetime NOT NULL,
	FileSize bigint NOT NULL,
	FileNameClean varchar(255) NOT NULL)

--Build Command String to enumerate directory listing
Select @CommandString = 'dir "' + @FilePath + '"'

-- Get the raw directory output into a table
insert into #FileListRaw
	exec @RetCode = master.dbo.xp_cmdshell @CommandString
--Remove anything that is not a file entry from the list. Also removes shortcuts from the list
DELETE #FileListRaw 
	WHERE ISDATE(SUBSTRING(RawFileName,1,10)) = 0 
	OR SUBSTRING (RawFileName,40,1) = '.' 
	OR RawFileName LIKE '%.lnk'

--Parse into the structured table
Insert #FileListStruct (FileDateTime, FileSize, FileNameClean)	
	Select substring (RawFileName,1,20), 
		replace (substring (RawFileName,21,18),',',''),
		substring (RawFileName,40,255)
	from #FileListRaw

Select @FileName = (Select TOP 1 FileNameClean 
	FROM #FileListStruct
	ORDER BY FileDateTime DESC)
	
--Select * from #FileListStruct
--Cleanup temp tables
Drop Table #FileListRaw
drop table #FileListStruct

