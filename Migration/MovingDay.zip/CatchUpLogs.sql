DROP Procedure CatchUpLogs
GO
Create Procedure CatchUpLogs (
		@DBName sysname, 
		@SourceServer sysname)
AS
--Diagnostics
/*declare		@DBName sysname
declare		@SourceServer sysname

select @DBName = 'ResumeData', @SourceServer = 'Lerxst\Lerxst'
*/
Declare @btype char(1)
Declare @LastRestoreDate datetime
Declare @LastDatabaseLSN numeric (25,0)
Declare @LastRestoreUUID uniqueidentifier
Declare @BackupUUID uniqueidentifier
Declare @BackupFileName nvarchar(260)
Declare @RestoreFileName nvarchar(260)
DECLARE @RestoreQuery nvarchar(4000)
DECLARE @RestoreCommand nvarchar(4000)
declare @ErrorNum int
Declare @ErrorText nvarchar(4000)
declare @BeginField nvarchar(50)
DECLARE @ClearCommand nvarchar(4000)

/* Initialize for housekeeping */
Select @ErrorNum = 0, @ErrorText = 'No Errors'

/* Find last restore for designated database */ 
select top 1 @btype = BS.[type], @LastRestoreDate = BRH.restore_date, @LastRestoreUUID = BS.backup_set_UUID
	from 
	msdb.dbo.backupset BS
	inner join msdb.dbo.restorehistory BRH
		on BRH.backup_set_id = BS.backup_set_id
	where BS.database_name = @DBName
		and  BS.server_name = @SourceServer
	order by BRH.restore_date desc
--select 'Last restore = ' +  convert(varchar(30),@LastRestoreUUID)
if @LastRestoreUUID is NUll
	begin
	select @ErrorNum = 1, @ErrorText = 'No last restore for database ' + @DBNAME
	goto Errorhandler
	end
/* Match up the right log */

/* Build Dynamic SQL query string for restore filelist query */
select @RestoreQuery = 
	'select physical_device_name from ['+ @SourceServer + '].msdb.dbo.backupset BS
	inner join ['+ @SourceServer + '].msdb.dbo.backupmediaset BMS
		on BS.media_set_id = BMS.media_set_id
	inner join ['+ @SourceServer + '].msdb.dbo.BackupMediaFamily BMF
		on BS.media_set_id = BMF.media_set_id
	where database_name = ''' + @DBName + '''
	and BS.[type] = ''L'''
/* Match up the right log */
if 'D' = @btype
	Select @RestoreQuery = @RestoreQuery + ' and database_backup_lsn >=
		(select checkpoint_lsn from ['+ @SourceServer + '].msdb.dbo.backupset
		where backup_set_uuid = ''' + convert(varchar(40),@LastRestoreUUID) +''')
		order by backup_finish_date'
else 
	Select @RestoreQuery = @RestoreQuery + ' and backup_start_date > (select backup_start_date from ['+ @SourceServer + '].msdb.dbo.backupset
		where backup_set_uuid = ''' + convert(varchar(40),@LastRestoreUUID) +''')
		order by backup_finish_date'
/* Drop database offline and back online to clear users */
select @ClearCommand = 'Alter Database ' + @DBName + ' Set offline with rollback immediate'
--exec (@ClearCommand)
Select @ClearCommand = 'Alter Database ' + @DBName + ' Set online'
--exec (@ClearCommand)

/* Build and execute cursor containing restore file list */
select @RestoreQuery = 'Declare LogRestoreCursor cursor READ_ONLY FAST_FORWARD	
	for ' +  @RestoreQuery
--select @RestoreQuery
exec (@RestoreQuery)
open LogRestoreCursor
	Fetch next from LogRestoreCursor into @RestoreFileName
	while 0 = @@Fetch_Status and 0 = @ErrorNum
	begin
		Select @RestoreCommand = 'restore log ' + @DBName +
			' FROM DISK = ''' + @RestoreFileName + 
			''' WITH STANDBY = ''D:\MSSQL\Standby\Standby-' + @DBName + '.dat'''
		select @restoreCommand
		exec (@RestoreCommand)
		if @@Error <> 0 
			select @ErrorNum = 1, @ErrorText = 'Unable to execute ' + @RestoreCommand
		Fetch next from LogRestoreCursor into @RestoreFileName
	end

close LogRestoreCursor

deallocate LogRestoreCursor

select @btype, @LastRestoreDate, @LastRestoreUUID

ErrorHandler:
print @ErrorText


GO
