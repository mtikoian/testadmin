
-- Try to select
Select *
From dbo.AllDBs;


-- Query TestContained2 table
Select *
From TestContained2.dbo.AllDBs;


-- Query TestContained2 table after resetting login
Select *
From TestContained2.dbo.AllDBs;


-- What about the other databases?
Select *
From AdventureWorks2016.dbo.DatabaseLog;