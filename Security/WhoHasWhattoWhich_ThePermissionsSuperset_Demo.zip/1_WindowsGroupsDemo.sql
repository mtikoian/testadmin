/*
--Create a local Windows user and a local Windows group and add user to  group. Run the below in a
--command window as Administrator.

-- To create user and group in AD instead of local, add the /DOMAIN flag at end of command and
-- call NET GROUP instead of NET LOCALGROUP

-- Create user named SQLTest1
net user SQLTest1 Pa$$W0rd /ADD

-- Create group called SQLTesters
net localgroup SQLTesters /ADD

-- Add user to group SQLTesters
net localgroup SQLTesters SQLTest1 /ADD

-- Create Group called SQLDev
net localgroup SQLDev /ADD

-- Add user to group SQLDev
net localgroup SQLDev SQLTest1 /ADD

-- Verify that user is in both groups
net user SQLTest1
*/

Use master;

-- Create Logins for both groups
Create Login [SQLMCMLap\SQLTesters] From Windows;
Create Login [SQLMCMLap\SQLDev] From Windows;
Go

Use AdventureWorks2016;

--Create users for both logins
Create User [SQLMCMLap\SQLTesters] For Login [SQLMCMLap\SQLTesters];
Create User [SQLMCMLap\SQLDev] For Login [SQLMCMLap\SQLDev];
Go

-- Add SQLTesters to db_datawriter role
Alter Role db_datawriter Add Member [SQLMCMLap\SQLTesters];

-- Add SQLDev to db_datareader role
Alter Role db_datareader Add Member [SQLMCMLap\SQLDev];
Go

-- Does the SQLTest1 login exist?
Select *
From sys.server_principals
Where name = N'SQLMCMLap\SQLTest1';

-- Even though the login doesn't explicitly exist, it has access through groups
-- Through which groups does it have access?
Exec xp_logininfo N'SQLMCMLap\SQLTest1', N'all';

-- Right now, I'm logged in as myself
Select suser_sname();

-- Switch to context SQLTest1 login
Execute As Login = 'SQLMCMLap\SQLTest1';

-- Prove it's SQLTest1 logged in
Select suser_sname();
Go

-- See, can't access this database
Select *
From imoltp.dbo.sql;

-- Has SELECT perms?
Select HAS_PERMS_BY_NAME(N'dbo.ErrorLog', N'Object', N'SELECT');

-- Has INSERT perms?
Select HAS_PERMS_BY_NAME(N'dbo.ErrorLog', N'Object', N'INSERT');

-- Has UPDATE perms?
Select HAS_PERMS_BY_NAME(N'dbo.ErrorLog', N'Object', N'UPDATE');

-- Has DELETE perms?
Select HAS_PERMS_BY_NAME(N'dbo.ErrorLog', N'Object', N'DELETE');

-- Revert back to previous context
Revert;

-- What if I DENY SELECT on the table to SQLDev?
-- Deny SELECT To SQLDev on dbo.ErrorLog
Deny Select on dbo.ErrorLog To [SQLMCMLap\SQLDev];

-- Switch to context SQLTest1 login
Execute As Login = 'SQLMCMLap\SQLTest1';

-- Has SELECT perms on dbo.ErrorLog?
Select HAS_PERMS_BY_NAME(N'dbo.ErrorLog', N'Object', N'SELECT');

-- Has SELECT perms on other tables?
Select HAS_PERMS_BY_NAME(N'dbo.DatabaseLog', N'Object', N'SELECT');
Select HAS_PERMS_BY_NAME(N'Person.Person', N'Object', N'SELECT');

-- Revert back to previous context
Revert;
Go

Use master;

-- Drop Group logins
Drop Login [SQLMCMLap\SQLTesters];
Drop Login [SQLMCMLap\SQLDev];
Go

-- Create login for SQLTest1
Create Login [SQLMCMLap\SQLTest1] From Windows;
Go

Use AdventureWorks2016;

-- Switch to context SQLTest1 login
Execute As Login = 'SQLMCMLap\SQLTest1';

-- Prove it's SQLTest1 logged in
Select suser_sname();
Go

-- See, can't access this database
Select *
From imoltp.dbo.sql;

-- Has INSERT perms?
Select HAS_PERMS_BY_NAME(N'dbo.ErrorLog', N'Object', N'INSERT');

-- Has UPDATE perms?
Select HAS_PERMS_BY_NAME(N'dbo.ErrorLog', N'Object', N'UPDATE');

-- Has DELETE perms?
Select HAS_PERMS_BY_NAME(N'dbo.ErrorLog', N'Object', N'DELETE');

-- Has SELECT perms on dbo.ErrorLog?
Select HAS_PERMS_BY_NAME(N'dbo.ErrorLog', N'Object', N'SELECT');

-- Has SELECT perms on other tables?
Select HAS_PERMS_BY_NAME(N'dbo.DatabaseLog', N'Object', N'SELECT');
Select HAS_PERMS_BY_NAME(N'Person.Person', N'Object', N'SELECT');

-- Revert back to previous context
Revert;
Go

-- Check login mappings
Exec xp_logininfo N'SQLMCMLap\SQLTest1', N'all';

-- Drop SQLTest1 login
Drop Login [SQLMCMLap\SQLTest1];

-- Switch to context SQLTest1 login
Execute As Login = 'SQLMCMLap\SQLTest1';

-- Prove it's SQLTest1 logged in
Select suser_sname();

Select *
From dbo.DatabaseLog;

Select *
From dbo.ErrorLog;

-- Revert back to previous context
Revert;
Go

-- Try a different database
Use imoltp;

-- Switch to context SQLTest1 login
Execute As Login = 'SQLMCMLap\SQLTest1';

-- Prove it's not SQLTest1 logged in
Select suser_sname();
