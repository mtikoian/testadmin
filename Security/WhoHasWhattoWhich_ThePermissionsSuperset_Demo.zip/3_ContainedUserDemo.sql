Use master;

-- Make sure environment is reset
If db_id('TestContained') Is Not Null
	Drop Database TestContained;
Go

If db_id('TestContained2') Is Not Null
	Drop Database TestContained2;
Go

-- Enable server level containment setting if not enabled
If Not Exists (Select 1 From sys.configurations
	Where name = 'contained database authentication'
	And value_in_use = 1)
  Begin
	Exec sp_configure 'contained database authentication', 1;
	Reconfigure;
  End
Go

-- Create contained database
Create Database TestContained
	Containment = Partial;
Go

Use TestContained;

-- Create SQL Auth contained user
Create User TestCDUser
	With Password = N'12345',
	Default_Schema = dbo;
Go

-- Give contained user some perms
Alter Role db_owner Add Member TestCDUser;
Go

-- Create a table with data
Select * Into dbo.AllDBs
From sys.databases;

-- Pause to test SQL Auth contained user


-- Find our contained users in the database
Select name, sid, authentication_type_desc
From sys.database_principals
Where name = 'TestCDUser';

-- Note sid here: 0x010500000000000903000000F3954CEB14318644AD4F8AA6D2C46780
-- 
Go

-- Create contained database
Create Database TestContained2
	Containment = Partial;
Go

Use TestContained2;

-- Create SQL Auth contained user
Create User TestCDUser
	With Password = N'12345',
	Default_Schema = dbo;
Go

-- Give contained user some perms
Alter Role db_owner Add Member TestCDUser;
Go

-- Create a table with data
Select * Into dbo.AllDBs
From sys.databases;

-- Drop contained user
Drop User TestCDUser;
Go

-- Create SQL Auth contained user
Create User TestCDUser
	With Password = N'12345',
	Default_Schema = dbo,
	sid = 0x010500000000000903000000F3954CEB14318644AD4F8AA6D2C46780;
Go

-- Give contained user some perms
Alter Role db_owner Add Member TestCDUser;
Go

-- Enable Trustworthy
Alter Database TestContained Set Trustworthy On;

-- Cleanup environment
Use master;

If db_id('TestContained') Is Not Null
	Drop Database TestContained;
Go

If db_id('TestContained2') Is Not Null
	Drop Database TestContained2;
Go

If Exists (Select 1 From sys.configurations
		Where name = N'contained database authentication'
		And value_in_use = 1)
 Begin
	Exec sp_configure N'contained database authentication', 0;
	Reconfigure;
 End
Go
