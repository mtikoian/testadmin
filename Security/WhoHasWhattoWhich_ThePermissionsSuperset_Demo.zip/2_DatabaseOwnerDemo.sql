Use master;

-- Create login for SQLTest1
Create Login [SQLMCMLap\SQLTest1] From Windows;
Go

-- Give it create database permissions
Grant Create Database To [SQLMCMLap\SQLTest1];

-- Switch to context SQLTest1 login
Execute As Login = 'SQLMCMLap\SQLTest1';

-- Create a new database
Create Database SQLTest1Owns;
Go

--Switch to SQLTest1Owns
Use SQLTest1Owns;

-- Who owns this database?
Select D.name As DBName, SP.name As OwnerName
From sys.databases As D
Inner Join sys.server_principals As SP On SP.sid = D.owner_sid
Where D.name = db_name();

-- This means SQLTest1 has all perms inside of database
-- Let's prove it by creating a table
Select * Into dbo.AllObjects
From sys.all_objects;

-- Query the table
Select *
From dbo.AllObjects;

-- What else can SQLTest1 do?
-- Change recovery model?
Alter Database SQLTest1Owns Set Recovery Simple;

-- Change page verification options?
Alter Database SQLTest1Owns Set Page_Verify None;

-- Enable auto-shrink or auto-close?
Alter Database SQLTest1Owns Set auto_shrink On;
Alter Database SQLTest1Owns Set auto_close On;

-- Modify the database files
Alter Database SQLTest1Owns 
	Modify File (NAME = N'SQLTest1Owns_log',
				MAXSIZE = UNLIMITED,
				FILEGROWTH = 0);

Alter Database SQLTest1Owns 
	Add File (NAME = N'Log2',
			FILENAME = N'C:\bak\Log2.ldf',
			SIZE = 1024KB,
			FILEGROWTH = 10%);

Alter Database SQLTest1Owns 
	Remove File [Log2];
GO

-- Enable containment?
Alter Database SQLTest1Owns Set Containment = Partial;

-- What if containment is enabled because another database uses it
-- Run in new window as self
If Exists (Select 1 From sys.configurations
		Where name = N'contained database authentication'
		And value_in_use = 0)
 Begin
	Exec sp_configure N'contained database authentication', 1;
	Reconfigure;
 End

-- Enable containment?
Alter Database SQLTest1Owns Set Containment = Partial;

-- Disable containment
-- Run in new window as self
If Exists (Select 1 From sys.configurations
		Where name = N'contained database authentication'
		And value_in_use = 1)
 Begin
	Exec sp_configure N'contained database authentication', 0;
	Reconfigure;
 End

-- Enable Trustworthy?
Alter Database SQLTest1Owns Set Trustworthy On;

Use master;

-- Revert to original login
Revert;

-- Drop login SQLTest1
Drop Login [SQLMCMLap\SQLTest1];

-- Drop user SQLTest1
-- net user SQLTest1 /DELETE

-- Switch to context SQLTest1 login
Execute As Login = 'SQLMCMLap\SQLTest1';

Use master;

-- Drop contained database
Drop Database SQLTest1Owns;
Go

-- Disable containment
-- Run in new window as self
If Exists (Select 1 From sys.configurations
		Where name = N'contained database authentication'
		And value_in_use = 1)
 Begin
	Exec sp_configure N'contained database authentication', 0;
	Reconfigure;
 End
