USE AwDemoRLS;
GO

SELECT * FROM dbo.Sellers;
EXECUTE(N'SELECT * FROM dbo.Sellers;') AS USER = 'Stephen';
EXECUTE(N'SELECT * FROM dbo.Sellers;') AS USER = 'Linda';
GO

CREATE OR ALTER VIEW dbo.vSellers
AS
SELECT * FROM dbo.Sellers
WHERE AccountName = USER_NAME();
GO

GRANT SELECT ON dbo.vSellers TO Stephen;
GRANT SELECT ON dbo.vSellers TO Linda;
GO

SELECT * FROM dbo.vSellers;
EXECUTE(N'SELECT * FROM dbo.vSellers;') AS USER = 'Stephen';
EXECUTE(N'SELECT * FROM dbo.vSellers;') AS USER = 'Linda';
GO

DROP VIEW IF EXISTS dbo.vSellers;
GO

DROP SCHEMA IF EXISTS Security;
GO
CREATE SCHEMA Security;
GO

CREATE OR ALTER FUNCTION Security.ufnBaseSecurityPredicate
	(@AccountName AS sysname)
RETURNS TABLE
WITH SCHEMABINDING
AS
    RETURN SELECT 0 AS access_result
	WHERE @AccountName = USER_NAME();
GO

DROP SECURITY POLICY IF EXISTS Security.SellersPolicy;
GO
CREATE SECURITY POLICY Security.SellersPolicy
	ADD FILTER PREDICATE Security.ufnBaseSecurityPredicate(AccountName) ON dbo.Sellers
WITH (STATE = ON);
GO

SELECT * FROM dbo.Sellers;
EXECUTE(N'SELECT * FROM dbo.Sellers;') AS USER = 'Stephen';
EXECUTE(N'SELECT * FROM dbo.Sellers;') AS USER = 'Linda';
GO

CREATE OR ALTER FUNCTION Security.ufnBaseSecurityPredicate
	(@AccountName AS sysname)
RETURNS TABLE
WITH SCHEMABINDING
AS
    RETURN SELECT 1 AS access_result
	WHERE USER_NAME() = @AccountName
		OR USER_NAME() = 'dbo';
GO

ALTER SECURITY POLICY Security.SellersPolicy
WITH (STATE = OFF);
GO

CREATE OR ALTER FUNCTION Security.ufnBaseSecurityPredicate
	(@AccountName AS sysname)
RETURNS TABLE
WITH SCHEMABINDING
AS
    RETURN SELECT 1 AS access_result
	WHERE USER_NAME() = @AccountName
		OR USER_NAME() = 'dbo';
GO

ALTER SECURITY POLICY Security.SellersPolicy
	DROP FILTER PREDICATE ON dbo.Sellers;
GO

CREATE OR ALTER FUNCTION Security.ufnBaseSecurityPredicate
	(@AccountName AS sysname)
RETURNS TABLE
WITH SCHEMABINDING
AS
    RETURN SELECT 1 AS access_result
	WHERE USER_NAME() = @AccountName
		OR USER_NAME() = 'dbo';
GO

ALTER SECURITY POLICY Security.SellersPolicy
	  ADD FILTER PREDICATE Security.ufnBaseSecurityPredicate(AccountName) ON dbo.Sellers;
ALTER SECURITY POLICY Security.SellersPolicy
WITH (STATE = ON);
GO

SELECT * FROM dbo.Sellers;
EXECUTE(N'SELECT * FROM dbo.Sellers;') AS USER = 'Stephen';
EXECUTE(N'SELECT * FROM dbo.Sellers;') AS USER = 'Linda';
GO

SELECT COUNT(*) FROM dbo.Orders;
EXECUTE(N'SELECT COUNT(*) FROM dbo.Orders;') AS USER = 'Stephen';
EXECUTE(N'SELECT COUNT(*) FROM dbo.Orders;') AS USER = 'Linda';
GO

ALTER SECURITY POLICY Security.SellersPolicy
	  DROP FILTER PREDICATE ON dbo.Sellers;
GO

CREATE OR ALTER VIEW dbo.vOrders
AS
SELECT COUNT(*) OrdersCount
FROM dbo.Sellers s
	INNER JOIN dbo.Orders o ON o.SalesPersonID = s.SalesPersonID
WHERE USER_NAME() = AccountName
	OR USER_NAME() = 'dbo';
GO

GRANT SELECT ON dbo.vOrders TO Stephen;
GRANT SELECT ON dbo.vOrders TO Linda;
GO

SELECT * FROM dbo.vOrders;
EXECUTE(N'SELECT * FROM dbo.vOrders;') AS USER = 'Stephen';
EXECUTE(N'SELECT * FROM dbo.vOrders;') AS USER = 'Linda';

ALTER SECURITY POLICY Security.SellersPolicy
	  ADD FILTER PREDICATE Security.ufnBaseSecurityPredicate(AccountName) ON dbo.Sellers;

SELECT * FROM dbo.vOrders;
EXECUTE(N'SELECT * FROM dbo.vOrders;') AS USER = 'Stephen';
EXECUTE(N'SELECT * FROM dbo.vOrders;') AS USER = 'Linda';
GO

CREATE OR ALTER VIEW dbo.vOrders
AS
SELECT COUNT(*) OrdersCount
FROM dbo.Sellers s
	, dbo.Orders o 
	where o.SalesPersonID = s.SalesPersonID;
GO

SELECT * FROM dbo.vOrders;
EXECUTE(N'SELECT * FROM dbo.vOrders;') AS USER = 'Stephen';
EXECUTE(N'SELECT * FROM dbo.vOrders;') AS USER = 'Linda';
GO

DROP VIEW IF EXISTS dbo.vOrders;
GO

CREATE OR ALTER FUNCTION Security.ufnWrongSecurityPredicate
	(@SalesPersonID AS int)
RETURNS TABLE
WITH SCHEMABINDING
AS
    RETURN SELECT 1 AS access_result
	FROM dbo.Sellers
	WHERE SalesPersonID = @SalesPersonID;
GO

ALTER SECURITY POLICY Security.SellersPolicy
	  ADD FILTER PREDICATE Security.ufnWrongSecurityPredicate(SalesPersonID) ON dbo.Orders;
GO

SELECT COUNT(*) FROM dbo.Orders;
EXECUTE(N'SELECT COUNT(*) FROM dbo.Orders;') AS USER = 'Stephen';
EXECUTE(N'SELECT COUNT(*) FROM dbo.Orders;') AS USER = 'Linda';
GO

ALTER SECURITY POLICY Security.SellersPolicy
	  DROP FILTER PREDICATE ON dbo.Orders;
GO

CREATE OR ALTER FUNCTION Security.ufnOrdersSecurityPredicate
	(@SalesPersonID AS int)
RETURNS TABLE
WITH SCHEMABINDING
AS
    RETURN SELECT 1 AS access_result
	FROM dbo.Sellers
		--WHERE USER_NAME() = AccountName OR USER_NAME() = 'dbo'
		CROSS APPLY Security.ufnBaseSecurityPredicate(AccountName)
	WHERE SalesPersonID = @SalesPersonID;
GO

ALTER SECURITY POLICY Security.SellersPolicy
	  ADD FILTER PREDICATE Security.ufnOrdersSecurityPredicate(SalesPersonID) ON dbo.Orders;
GO

SELECT COUNT(*) FROM dbo.Orders;
EXECUTE(N'SELECT COUNT(*) FROM dbo.Orders;') AS USER = 'Stephen';
EXECUTE(N'SELECT COUNT(*) FROM dbo.Orders;') AS USER = 'Linda';
GO

SELECT COUNT(*) FROM dbo.OrderDetails;
EXECUTE(N'SELECT COUNT(*) FROM dbo.OrderDetails;') AS USER = 'Stephen';
EXECUTE(N'SELECT COUNT(*) FROM dbo.OrderDetails;') AS USER = 'Linda';
GO

CREATE OR ALTER FUNCTION Security.ufnOrderDetailsSecurityPredicate
	(@SalesOrderID AS int)
RETURNS TABLE
WITH SCHEMABINDING
AS
    RETURN SELECT 1 AS access_result
	FROM dbo.Orders o
	WHERE o.SalesOrderID = @SalesOrderID;
GO

ALTER SECURITY POLICY Security.SellersPolicy
	  ADD FILTER PREDICATE Security.ufnOrderDetailsSecurityPredicate(SalesOrderID) ON dbo.OrderDetails;
GO

SELECT COUNT(*) FROM dbo.OrderDetails;
EXECUTE(N'SELECT COUNT(*) FROM dbo.OrderDetails;') AS USER = 'Stephen';
EXECUTE(N'SELECT COUNT(*) FROM dbo.OrderDetails;') AS USER = 'Linda';
GO

ALTER SECURITY POLICY Security.SellersPolicy
	  DROP FILTER PREDICATE ON dbo.OrderDetails;
GO

CREATE OR ALTER FUNCTION Security.ufnOrderDetailsSecurityPredicate
	(@SalesOrderID AS int)
RETURNS TABLE
WITH SCHEMABINDING
AS
    RETURN SELECT 1 AS access_result
	FROM dbo.Orders o
		INNER JOIN dbo.Sellers s ON s.SalesPersonID = o.SalesPersonID
		CROSS APPLY Security.ufnBaseSecurityPredicate(AccountName)
	WHERE o.SalesOrderID = @SalesOrderID;
GO

ALTER SECURITY POLICY Security.SellersPolicy
	  ADD FILTER PREDICATE Security.ufnOrderDetailsSecurityPredicate(SalesOrderID) ON dbo.OrderDetails;
GO

SELECT COUNT(*) FROM dbo.OrderDetails;
EXECUTE(N'SELECT COUNT(*) FROM dbo.OrderDetails;') AS USER = 'Stephen';
EXECUTE(N'SELECT COUNT(*) FROM dbo.OrderDetails;') AS USER = 'Linda';
GO
