USE AwDemoRLS;
GO

SELECT *  FROM sys.security_policies;
SELECT *  FROM sys.security_predicates;
GO

/*
ALTER SECURITY POLICY Security.SellersPolicy
WITH (STATE = ON);
GO
ALTER SECURITY POLICY Security.SellersPolicy
WITH (STATE = OFF);
GO
*/