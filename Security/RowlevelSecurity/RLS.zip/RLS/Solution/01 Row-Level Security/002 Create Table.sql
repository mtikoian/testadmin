USE AwDemoRLS;
GO

DROP TABLE IF EXISTS dbo.OrderDetails;
DROP TABLE IF EXISTS dbo.Orders;
DROP TABLE IF EXISTS dbo.Sellers;

CREATE TABLE dbo.Sellers
(
	  SalesPersonID int NOT NULL
	, ReportsTo int NOT NULL
	, OrganizationNode hierarchyid NULL
	, OrganizationLevel smallint NULL
	, FirstName nvarchar(50) NOT NULL
	, LastName nvarchar(50) NOT NULL
	, JobTitle nvarchar(50) NOT NULL
	, Phone nvarchar(25) NULL
	, PhoneNumberType nvarchar(50) NULL
	, Email nvarchar(50) NULL
	, Address nvarchar(60) NOT NULL
	, PostalCode nvarchar(15) NOT NULL
	, City nvarchar(30) NOT NULL
	, StateProvince nvarchar(50) NOT NULL
	, CountryRegion nvarchar(50) NOT NULL
	, Territory nvarchar(50) NULL
	, TerritoryGroup nvarchar(50) NULL
	, SalesQuota money NULL
	, AccountName sysname NOT NULL
)
GO

INSERT INTO dbo.Sellers
	SELECT
		  e.BusinessEntityID AS SalesPersonID,  m.BusinessEntityID AS ReportsTo
		  , e.OrganizationNode, e.OrganizationLevel
		, FirstName, LastName, e.JobTitle, PhoneNumber AS Phone, PhoneNumberType, EmailAddress AS Email
		, AddressLine1 AS Address, PostalCode, City, StateProvinceName AS StateProvince
		, CountryRegionName AS CountryRegion,TerritoryName AS Territory, TerritoryGroup
		, SalesQuota, CAST(FirstName AS sysname) AS AccountName
	FROM AdventureWorks2014.Sales.vSalesPerson sp
		INNER JOIN AdventureWorks2014.HumanResources.Employee e
			ON sp.BusinessEntityID = e.BusinessEntityID
		INNER JOIN AdventureWorks2014.HumanResources.Employee m
			ON e.OrganizationNode.GetAncestor(1) = m.OrganizationNode;
GO

UPDATE dbo.Sellers
	SET ReportsTo = SalesPersonID
WHERE ReportsTo = 273;
GO

ALTER TABLE dbo.Sellers
	ADD
		CONSTRAINT PK_Sellers_SalesPersonID PRIMARY KEY (SalesPersonID)
	  , CONSTRAINT AK_Sellers_OrganizationNode UNIQUE (OrganizationNode);
GO
CREATE NONCLUSTERED INDEX IX_Sellers_AccountName
	ON dbo.Sellers (AccountName);
GO

DROP TABLE IF EXISTS dbo.OrderDetails;
DROP TABLE IF EXISTS dbo.Orders;
SELECT
	  SalesOrderID
	, OrderDate
	, SalesPersonID
INTO dbo.Orders
FROM AdventureWorks2014.Sales.SalesOrderHeader;
GO

ALTER TABLE dbo.Orders
	ADD
	  CONSTRAINT PK_Orders_SalesOrderID PRIMARY KEY (SalesOrderID)
	, CONSTRAINT FK_Orders_Sellers_SalesPersonID FOREIGN KEY (SalesPersonID)
		REFERENCES dbo.Sellers (SalesPersonID);
GO
CREATE NONCLUSTERED INDEX IX_Orders_SalesPersonID
	ON dbo.Orders (SalesPersonID);
GO

DROP TABLE IF EXISTS dbo.OrderDetails;
SELECT
	  SalesOrderID
	, SalesOrderDetailID
	, OrderQty
	, ProductID
	, UnitPrice
	, UnitPriceDiscount
	, LineTotal
INTO dbo.OrderDetails
FROM AdventureWorks2014.Sales.SalesOrderDetail
GO

ALTER TABLE dbo.OrderDetails
	ADD
	  CONSTRAINT PK_OrderDetails_SalesOrderID_SalesOrderDetailID PRIMARY KEY (SalesOrderID, SalesOrderDetailID)
	, CONSTRAINT FK_OrderDetails_Orders_SalesOrderID FOREIGN KEY (SalesOrderID)
		REFERENCES dbo.Orders (SalesOrderID);
GO

SELECT * FROM dbo.Sellers;
SELECT * FROM dbo.Orders;
SELECT * FROM dbo.OrderDetails;
GO
