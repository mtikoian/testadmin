USE AwDemoRLS;
GO

DROP USER IF EXISTS Stephen;
CREATE USER Stephen WITHOUT LOGIN;

DROP USER IF EXISTS Linda;
CREATE USER Linda WITHOUT LOGIN;
GO

GRANT SELECT ON dbo.Sellers TO Stephen;
GRANT SELECT ON dbo.Sellers TO Linda;
GRANT SELECT ON dbo.Orders TO Stephen;
GRANT SELECT ON dbo.Orders TO Linda;
GRANT SELECT ON dbo.OrderDetails TO Stephen;
GRANT SELECT ON dbo.OrderDetails TO Linda;
GO

GRANT SHOWPLAN TO Stephen;
GRANT SHOWPLAN TO Linda;