USE AwDemoRLS;
GO

CREATE OR ALTER FUNCTION Security.ufnBaseSecurityPredicate
	(@AccountName AS sysname)
RETURNS TABLE
WITH SCHEMABINDING
AS
    RETURN SELECT 1 AS access_result
	FROM dbo.Sellers s1
		INNER JOIN dbo.Sellers s2
			ON s2.OrganizationNode.IsDescendantOf(s1.OrganizationNode) = 1
	WHERE (s2.AccountName = @AccountName AND
		s1.AccountName = USER_NAME())
		OR USER_NAME() = 'dbo';
GO

ALTER SECURITY POLICY Security.SellersPolicy
	  DROP FILTER PREDICATE ON dbo.Sellers
	, DROP FILTER PREDICATE ON dbo.Orders
	, DROP FILTER PREDICATE ON dbo.OrderDetails;
GO

DROP FUNCTION IF EXISTS Security.ufnOrderDetailsSecurityPredicate;
DROP FUNCTION IF EXISTS Security.ufnOrdersSecurityPredicate;
--DROP FUNCTION IF EXISTS Security.ufnBaseSecurityPredicate;
GO

CREATE OR ALTER FUNCTION Security.ufnBaseSecurityPredicate
	(@AccountName AS sysname)
RETURNS TABLE
WITH SCHEMABINDING
AS
    RETURN SELECT 1 AS access_result
	FROM dbo.Sellers s1
		INNER JOIN dbo.Sellers s2
			ON s2.OrganizationNode.IsDescendantOf(s1.OrganizationNode) = 1
	WHERE (s2.AccountName = @AccountName AND
		s1.AccountName = USER_NAME())
		OR USER_NAME() = 'dbo';
GO

CREATE OR ALTER FUNCTION Security.ufnOrdersSecurityPredicate
	(@SalesPersonID AS int)
RETURNS TABLE
WITH SCHEMABINDING
AS
    RETURN SELECT 1 AS access_result
	FROM dbo.Sellers
		CROSS APPLY Security.ufnBaseSecurityPredicate(AccountName)
	WHERE SalesPersonID = @SalesPersonID
		--OR @SalesPersonID IS NULL; -- Internet Sales
GO

CREATE OR ALTER FUNCTION Security.ufnOrderDetailsSecurityPredicate
	(@SalesOrderID AS int)
RETURNS TABLE
WITH SCHEMABINDING
AS
    RETURN SELECT 1 AS access_result
	FROM dbo.Orders o
		INNER JOIN dbo.Sellers s ON s.SalesPersonID = o.SalesPersonID
			--OR o.SalesPersonID IS NULL -- Internet Sales, but this can degrade performance significantly
		CROSS APPLY Security.ufnBaseSecurityPredicate(AccountName)
	WHERE o.SalesOrderID = @SalesOrderID;
GO

ALTER SECURITY POLICY Security.SellersPolicy
	  ADD FILTER PREDICATE Security.ufnBaseSecurityPredicate(AccountName) ON dbo.Sellers
	, ADD FILTER PREDICATE Security.ufnOrdersSecurityPredicate(SalesPersonID) ON dbo.Orders
	, ADD FILTER PREDICATE Security.ufnOrderDetailsSecurityPredicate(SalesOrderID) ON dbo.OrderDetails;
GO

SELECT * FROM dbo.Sellers;
SELECT * FROM dbo.Orders;
SELECT * FROM dbo.OrderDetails;
GO

EXECUTE AS USER = 'Stephen';
	SELECT * FROM dbo.Sellers;
	SELECT * FROM dbo.Orders;
	SELECT * FROM dbo.OrderDetails;
REVERT;
GO

EXECUTE AS USER = 'Linda';
	SELECT * FROM dbo.Sellers;
	SELECT * FROM dbo.Orders;
	SELECT * FROM dbo.OrderDetails;
REVERT;
GO
