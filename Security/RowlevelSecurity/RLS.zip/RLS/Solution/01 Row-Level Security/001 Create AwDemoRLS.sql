USE master;
GO

IF  EXISTS (SELECT name FROM sys.databases WHERE name = N'AwDemoRLS')
	BEGIN
		ALTER DATABASE AwDemoRLS
			SET SINGLE_USER
				WITH ROLLBACK IMMEDIATE;
		DROP DATABASE AwDemoRLS;
	END
GO

CREATE DATABASE AwDemoRLS
ON PRIMARY 
	( NAME = N'AwDemoRLS', FILENAME = N'C:\_Workshops\Databases\AwDemoRLS.mdf'
	, SIZE = 10MB
	, FILEGROWTH = 10% )
LOG ON 
	( NAME = N'AwDemoRLS_log'
	, FILENAME = N'C:\_Workshops\Databases\AwDemoRLS_log.ldf'
	, SIZE = 5MB
	, FILEGROWTH = 10%);
GO

SELECT name--, *
FROM sys.databases
WHERE name = N'AwDemoRLS';
GO
