USE AwDemoRLS;
GO

ALTER SECURITY POLICY Security.SellersPolicy
	  DROP FILTER PREDICATE ON dbo.Sellers
	, DROP FILTER PREDICATE ON dbo.Orders
	--, DROP BLOCK PREDICATE ON dbo.Orders
	, DROP FILTER PREDICATE ON dbo.OrderDetails;
GO

DROP FUNCTION IF EXISTS Security.ufnOrderDetailsSecurityPredicate;
DROP FUNCTION IF EXISTS Security.ufnOrdersSecurityPredicate;
--DROP FUNCTION IF EXISTS Security.ufnBaseSecurityPredicate;
GO

CREATE OR ALTER FUNCTION Security.ufnBaseSecurityPredicate
	(@AccountName AS sysname)
RETURNS TABLE
WITH SCHEMABINDING
AS
    RETURN SELECT 1 AS access_result
	FROM dbo.Sellers s1
		INNER JOIN dbo.Sellers s2
			ON s2.OrganizationNode.IsDescendantOf(s1.OrganizationNode) = 1
	WHERE  (s2.AccountName = @AccountName AND
		(
			s1.AccountName = USER_NAME()
			
			--OR (USER_NAME() = 'ApplicationServiceAccount'  -- same effect as next line
			OR (DATABASE_PRINCIPAL_ID() = DATABASE_PRINCIPAL_ID('ApplicationServiceAccount')  
				AND s1.AccountName = CAST(SESSION_CONTEXT(N'user_name') AS sysname))
		))
		OR USER_NAME() = 'dbo';
GO

CREATE OR ALTER FUNCTION Security.ufnOrdersSecurityPredicate
	(@SalesPersonID AS int)
RETURNS TABLE
WITH SCHEMABINDING
AS
    RETURN SELECT 1 AS access_result
	FROM dbo.Sellers
		CROSS APPLY Security.ufnBaseSecurityPredicate(AccountName)
	WHERE SalesPersonID = @SalesPersonID
		--OR @SalesPersonID IS NULL; -- Internet Sales
GO

CREATE OR ALTER FUNCTION Security.ufnOrderDetailsSecurityPredicate
	(@SalesOrderID AS int)
RETURNS TABLE
WITH SCHEMABINDING
AS
    RETURN SELECT 1 AS access_result
	FROM dbo.Orders o
		INNER JOIN dbo.Sellers s ON s.SalesPersonID = o.SalesPersonID
			--OR o.SalesPersonID IS NULL -- Internet Sales, but this can degrade performance significantly
		CROSS APPLY Security.ufnBaseSecurityPredicate(AccountName)
	WHERE o.SalesOrderID = @SalesOrderID;
GO

ALTER SECURITY POLICY Security.SellersPolicy
	  ADD FILTER PREDICATE Security.ufnBaseSecurityPredicate(AccountName) ON dbo.Sellers
	, ADD FILTER PREDICATE Security.ufnOrdersSecurityPredicate(SalesPersonID) ON dbo.Orders
	, ADD FILTER PREDICATE Security.ufnOrderDetailsSecurityPredicate(SalesOrderID) ON dbo.OrderDetails

	, ADD BLOCK PREDICATE Security.ufnOrdersSecurityPredicate(SalesPersonID) ON dbo.Orders;
GO

SELECT * FROM dbo.Sellers;
SELECT * FROM dbo.Orders;
SELECT * FROM dbo.OrderDetails;
GO

EXECUTE AS USER = 'Stephen';
	SELECT * FROM dbo.Sellers;
	SELECT * FROM dbo.Orders;
	SELECT * FROM dbo.OrderDetails;
REVERT;
GO

EXECUTE AS USER = 'Linda';
	SELECT * FROM dbo.Sellers;
	SELECT * FROM dbo.Orders;
	SELECT * FROM dbo.OrderDetails;
REVERT;
GO

EXECUTE AS USER = 'ApplicationServiceAccount';
	SELECT * FROM dbo.Sellers;

	EXEC sp_set_session_context @key=N'user_name', @value=N'Linda';

	SELECT * FROM dbo.Sellers;

	SELECT * FROM dbo.Orders;

	INSERT INTO dbo.Orders(OrderDate, SalesPersonID)
	VALUES ('2011-06-30', 274);

	SELECT * FROM dbo.Orders WHERE SalesOrderID = 43663;
	UPDATE dbo.Orders
		SET OrderDate = '2011-06-30'
	WHERE SalesOrderID = 43663;
	SELECT * FROM dbo.Orders WHERE SalesOrderID = 43663;

	UPDATE dbo.Orders
		SET SalesPersonID = 274
	WHERE SalesOrderID = 43663;
	SELECT * FROM dbo.Orders WHERE SalesOrderID = 43663;

	DELETE dbo.Orders
	WHERE SalesOrderID = 43659;

	SELECT * FROM dbo.OrderDetails;

	EXEC sp_set_session_context @key=N'user_name', @value=NULL;

	SELECT * FROM dbo.OrderDetails;
REVERT;
GO

SELECT * FROM dbo.Orders WHERE SalesOrderID = 43659;


























/* For Testing from second computer (DW story)
CREATE LOGIN [DEMOS\SPUser] FROM WINDOWS WITH DEFAULT_DATABASE = master
CREATE USER SPUser FOR LOGIN [DEMOS\SPUser] WITH DEFAULT_SCHEMA = dbo

GRANT SELECT, INSERT, UPDATE, DELETE ON dbo.Sellers TO SPUser;

UPDATE dbo.Sellers
	SET AccountName = 'SPUser'
WHERE SalesPersonID = 274;
*/






--CREATE FUNCTION Security.ufnBasePredicate
--	(@SalesPersonID AS int)
--RETURNS TABLE
--WITH SCHEMABINDING
--AS
--RETURN
--	WITH Q1 AS
--	(
--		SELECT SalesPersonID AS ManagerID
--		FROM dbo.Sellers
--		WHERE
--			AccountName = USER_NAME()
	
--			OR USER_NAME() = 'dbo'

--			--OR (USER_NAME() = 'ApplicationServiceAccount'  -- same effect as next line
--			OR (DATABASE_PRINCIPAL_ID() = DATABASE_PRINCIPAL_ID('ApplicationServiceAccount')  
--				AND AccountName = CAST(SESSION_CONTEXT(N'user_name') AS sysname)) 

--		UNION ALL
--		SELECT NULL
--	)
--	SELECT 1 AS access_result
--	FROM dbo.Sellers
--		CROSS JOIN Q1
--	WHERE SalesPersonID = @SalesPersonID
--		AND (SalesPersonID = ManagerID OR ReportsTo = ManagerID)
--	OR (@SalesPersonID IS NULL AND USER_NAME() = 'dbo');
--GO
