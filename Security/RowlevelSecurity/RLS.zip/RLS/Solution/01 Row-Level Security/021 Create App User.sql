USE AwDemoRLS;
GO

IF NOT EXISTS (SELECT 1 FROM master.dbo.syslogins WHERE name = N'ApplicationServiceAccount')
	CREATE LOGIN ApplicationServiceAccount WITH PASSWORD = 'Pa$$w0rd';
CREATE USER ApplicationServiceAccount FOR LOGIN ApplicationServiceAccount;

GRANT SELECT, INSERT, UPDATE, DELETE ON dbo.Sellers TO ApplicationServiceAccount;
GRANT SELECT, INSERT, UPDATE, DELETE ON dbo.Orders TO ApplicationServiceAccount;
GRANT SELECT, INSERT, UPDATE, DELETE ON dbo.OrderDetails TO ApplicationServiceAccount;
GO

GRANT SHOWPLAN TO ApplicationServiceAccount;

-- To set the SESSION_CONTEXT, the application will execute the following each time
--	a connection is opened.  @read_only prevents the value from changing again 
--	until the connection is closed.
EXEC sp_set_session_context @key=N'user_name', @value=N'Linda', @read_only=1;
GO

-- Now, this user name is stored in the SESSION_CONTEXT for the rest of the session
--	(it will be reset when the connection is closed and returned to the connection pool).
SELECT SESSION_CONTEXT(N'user_name')
GO

-- Reset will failed because @read_only=1
EXEC sp_set_session_context @key=N'user_name', @value=NULL
GO
