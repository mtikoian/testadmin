--Generate some audit records
USE AdventureWorks2012
GO
CREATE TABLE AuditTestTable (name varchar(10))
GO
CREATE INDEX ix1 on AuditTestTable(name)
GO
DROP TABLE AuditTestTable
GO


--Review AuditLocator
SELECT * from SQLAudit.dbo.AuditLocator

--Load all active Audit data
exec SQLAudit.dbo.LoadAuditData

--View Audit report
SELECT server_instance_name as [Server], database_name as [Database], a.name as [Action]
	,m.class_type_desc as [Type], server_principal_name as [Login], schema_name as [Schema], object_name as [Object], event_time as [Event Time], statement as [Statement],  audit_name as [Audit Name]
FROM SQLAudit.dbo.AuditRecord r
JOIN sys.dm_audit_actions a on a.action_id = r.action_id
JOIN sys.dm_audit_class_type_map m on m.class_type = r.class_type and a.class_desc = m.securable_class_desc
