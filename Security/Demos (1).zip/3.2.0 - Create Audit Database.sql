
/****** Create the master Audit database ******/
USE [master]
GO

IF DATABASEPROPERTYEX('SQLAudit', 'status') IS NOT NULL
BEGIN
    ALTER DATABASE [SQLAudit] SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
    DROP DATABASE [SQLAudit];
END
GO

CREATE DATABASE [SQLAudit]
 CONTAINMENT = NONE
 ON  PRIMARY 
( NAME = N'SQLAudit', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\SQLAudit.mdf' )
 LOG ON 
( NAME = N'SQLAudit_log', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\SQLAudit_log.ldf' )
GO

 

/****** Create the tables ******/
USE [SQLAudit]
GO

CREATE TABLE [dbo].[AuditRecord](
    [audit_name] [varchar](128) NOT NULL,
    [event_time] [datetime2](7) NOT NULL,
    [sequence_number] [int] NOT NULL,
    [action_id] [varchar](4) NULL,
    [succeeded] [bit] NOT NULL,
    [permission_bitmask] [bigint] NOT NULL,
    [is_column_permission] [bit] NOT NULL,
    [session_id] [smallint] NOT NULL,
    [server_principal_id] [int] NOT NULL,
    [database_principal_id] [int] NOT NULL,
    [target_server_principal_id] [int] NOT NULL,
    [target_database_principal_id] [int] NOT NULL,
    [object_id] [int] NOT NULL,
    [class_type] [varchar](2) NULL,
    [session_server_principal_name] [nvarchar](128) NULL,
    [server_principal_name] [nvarchar](128) NULL,
    [server_principal_sid] [varbinary](85) NULL,
    [database_principal_name] [nvarchar](128) NULL,
    [target_server_principal_name] [nvarchar](128) NULL,
    [target_server_principal_sid] [varbinary](85) NULL,
    [target_database_principal_name] [nvarchar](128) NULL,
    [server_instance_name] [nvarchar](128) NULL,
    [database_name] [nvarchar](128) NULL,
    [schema_name] [nvarchar](128) NULL,
    [object_name] [nvarchar](128) NULL,
    [statement] [nvarchar](4000) NULL,
    [additional_information] [nvarchar](4000) NULL,
    [file_name] [nvarchar](260) NOT NULL,
    [audit_file_offset] [bigint] NOT NULL,
	[user_defined_event_id] [smallint] NOT NULL,
	[user_defined_information] [nvarchar](4000) NULL
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[AuditStage](
    [audit_name] [varchar](128) NOT NULL,
    [event_time] [datetime2](7) NOT NULL,
    [sequence_number] [int] NOT NULL,
    [action_id] [varchar](4) NULL,
    [succeeded] [bit] NOT NULL,
    [permission_bitmask] [bigint] NOT NULL,
    [is_column_permission] [bit] NOT NULL,
    [session_id] [smallint] NOT NULL,
    [server_principal_id] [int] NOT NULL,
    [database_principal_id] [int] NOT NULL,
    [target_server_principal_id] [int] NOT NULL,
    [target_database_principal_id] [int] NOT NULL,
    [object_id] [int] NOT NULL,
    [class_type] [varchar](2) NULL,
    [session_server_principal_name] [nvarchar](128) NULL,
    [server_principal_name] [nvarchar](128) NULL,
    [server_principal_sid] [varbinary](85) NULL,
    [database_principal_name] [nvarchar](128) NULL,
    [target_server_principal_name] [nvarchar](128) NULL,
    [target_server_principal_sid] [varbinary](85) NULL,
    [target_database_principal_name] [nvarchar](128) NULL,
    [server_instance_name] [nvarchar](128) NULL,
    [database_name] [nvarchar](128) NULL,
    [schema_name] [nvarchar](128) NULL,
    [object_name] [nvarchar](128) NULL,
    [statement] [nvarchar](4000) NULL,
    [additional_information] [nvarchar](4000) NULL,
    [file_name] [nvarchar](260) NOT NULL,
    [audit_file_offset] [bigint] NOT NULL,
	[user_defined_event_id] [smallint] NOT NULL,
	[user_defined_information] [nvarchar](4000) NULL
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[AuditLocator](
    [audit_name] [varchar](128) NULL,
    [file_name] [nvarchar](260) NOT NULL,
    [audit_file_offset] [bigint] NOT NULL,
    [file_pattern] [nvarchar](260) NULL,
    [locator_id] int identity(1,1) not null,
    [active] char(1) default 'Y'
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[AuditLoadLog](
    [audit_name] [varchar](128) NULL,
    [staged_count] [int] NOT NULL,
    [saved_count] [int] NOT NULL,
    [run_date] datetime DEFAULT getdate()
) ON [PRIMARY]
GO


CREATE TABLE [dbo].[AuditExclude](
    [InstanceName] [nvarchar](128) NULL,
    [DatabaseName] [varchar](50) NULL,
    [SchemaName] [sysname] NOT NULL,
    [ObjectName] [varchar](50) NULL,
    [ClassType] [varchar](50) NULL,
	[Action] [nvarchar](50) NULL,
	[Statement] [nvarchar](4000) NULL,
    [Reason] [varchar](100) NULL
) ON [PRIMARY]
GO

insert into [dbo].[AuditExclude] values ('%', '%', '%', '%', '%', '%', '%STATISTICS%', 'Routine maintenance')
insert into [dbo].[AuditExclude] values ('%', '%', '%', '%', '%', '%', 'ALTER INDEX%REBUILD%', 'Routine maintenance')
insert into [dbo].[AuditExclude] values ('%', '%', '%', '%', '%', '%', 'ALTER INDEX%REORGANIZE%', 'Routine maintenance')
insert into [dbo].[AuditExclude] values ('ASUS', 'AdventureWorks2012', 'dbo', 'TestExclude', 'TABLE', '%', '%', 'Temp table')
GO

/****** Procedure to load audit files into the database ******/

create procedure LoadAuditData
as
begin
    declare @audit varchar(128),
            @file nvarchar(260),
            @offset bigint,
            @pattern nvarchar(260),
            @staged int,
            @saved int
 
    set nocount on
 
    declare cAudits cursor for
        select audit_name, file_name, audit_file_offset, file_pattern
        from AuditLocator
        where active = 'Y'
    FOR UPDATE

	open cAudits
	fetch cAudits into @audit, @file, @offset, @pattern
	while @@fetch_status = 0
	begin
 
		set @staged = 0
		set @saved = 0
 
		insert into AuditStage
		SELECT 
			@audit
		  ,[event_time]
		  ,[sequence_number]
		  ,[action_id]
		  ,[succeeded]
		  ,[permission_bitmask]
		  ,[is_column_permission]
		  ,[session_id]
		  ,[server_principal_id]
		  ,[database_principal_id]
		  ,[target_server_principal_id]
		  ,[target_database_principal_id]
		  ,[object_id]
		  ,[class_type]
		  ,[session_server_principal_name]
		  ,[server_principal_name]
		  ,[server_principal_sid]
		  ,[database_principal_name]
		  ,[target_server_principal_name]
		  ,[target_server_principal_sid]
		  ,[target_database_principal_name]
		  ,[server_instance_name]
		  ,[database_name]
		  ,[schema_name]
		  ,[object_name]
		  ,[statement]
		  ,[additional_information]
		  ,[file_name]
		  ,[audit_file_offset]
		  ,[user_defined_event_id]
		  ,[user_defined_information] 
		FROM fn_get_audit_file (@pattern, @file,  @offset)
 
		set @staged = @@rowcount
 
		insert into AuditRecord
		SELECT * from AuditStage a
		WHERE NOT EXISTS (SELECT 1 FROM 
			(SELECT distinct ae.InstanceName, ae.DatabaseName, ae.SchemaName, ae.ObjectName, coalesce(cm.class_type,ae.classtype) as Classtype,
			coalesce(aa.action_id, ae.Action) as ActionID, ae.Statement
			FROM dbo.AuditExclude ae 
			left join sys.dm_audit_class_type_map cm on cm.class_type_desc = ae.ClassType
			left join sys.dm_audit_actions aa on aa.name = ae.Action collate SQL_Latin1_General_CP1_CI_AS) ae 
						WHERE
						a.server_instance_name like ae.InstanceName and
						a.database_name like ae.DatabaseName and
						a.schema_name like ae.SchemaName and
						a.object_name like ae.ObjectName and
						a.class_type like ae.classtype and
						a.action_id like ae.actionid and
						a.statement like ae.Statement)

 
		set @saved = @@rowcount
		select top 1 @file=file_name, @offset=audit_file_offset 
			from AuditStage order by event_time desc
 
		update AuditLocator 
			set file_name = @file, audit_file_offset = @offset
			where current of cAudits

		insert into AuditLoadLog (audit_name, staged_count, saved_count) 
			values (@audit, @staged, @saved)
        
		DELETE AuditStage
        
		fetch cAudits into @audit, @file, @offset, @pattern
    end
    close cAudits
    deallocate cAudits
end