USE [master]
GO

/****** Object:  Audit [SecurityAudit]    Script Date: 8/5/2015 4:32:43 PM ******/
CREATE SERVER AUDIT [SecurityAudit]
TO FILE 
(	  FILEPATH = N'C:\Program Files\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\Log'
	, MAXSIZE = 10 MB
	, MAX_FILES = 10
	, RESERVE_DISK_SPACE = OFF
)
WITH
(	  QUEUE_DELAY = 1000
	, ON_FAILURE = CONTINUE
)
ALTER SERVER AUDIT [SecurityAudit] WITH (STATE = ON)
GO


USE [master]
GO

CREATE SERVER AUDIT SPECIFICATION [SecurityAuditSpec]
FOR SERVER AUDIT [SecurityAudit]
ADD (FAILED_LOGIN_GROUP),
ADD (SUCCESSFUL_LOGIN_GROUP),
ADD (LOGOUT_GROUP)
WITH (STATE = ON)
GO

