Add-Type -Path 'C:\Program Files\Microsoft SQL Server\110\SDK\Assemblies\Microsoft.SqlServer.Smo.dll'

Trap {
  $err = $_.Exception
  while ( $err.InnerException )
    {
    $err = $err.InnerException
    write-output $err.Message
    };
    continue
  }

 
$targetInst = 'ASUS'


$auditName = "$($targetInst)_DDLAudit"
$specName = "$($targetInst)_DDLAudit_Spec"

$auditPath = '\\ASUS\AuditLogs'
 
$srv = New-Object ('Microsoft.SqlServer.Management.Smo.Server') -argumentlist $targetInst 
    
#Create the audit object
$newAudit = new-object Microsoft.SqlServer.Management.Smo.Audit($srv, "$($auditName)")
$newAudit.DestinationType = [Microsoft.SqlServer.Management.Smo.AuditDestinationType]::File
$newAudit.FilePath = "$($auditPath)" 
$newAudit.MaximumRolloverFiles = 10
$newAudit.MaximumFileSize = 100
$newAudit.QueueDelay = 1000
$newAudit.Create()
$newAudit.Enable()
    
Write-Host "Audit Object $($AuditName) created."
    
#Create the Audit Specification
$db = New-Object Microsoft.SqlServer.Management.Smo.Database
$db = $srv.Databases.Item($targetDB)
 
## Set audit spec properties
$AuditSpec = new-object Microsoft.SqlServer.Management.Smo.ServerAuditSpecification($srv, "$($specName)")
$AuditSpec.AuditName = "$($auditName)"
 
## Set audit actions
$SpecDetail = new-object Microsoft.SqlServer.Management.Smo.AuditSpecificationDetail("SchemaObjectChangeGroup")
$AuditSpec.AddAuditSpecificationDetail($SpecDetail)
 
## Create and enable audit spec
$AuditSpec.Create()
$AuditSpec.Enable()
 
Write-Host "Server Audit Spec $($specName) created."
 
## Insert a record of the audit into AuditLocator in the audit master db

Start-Sleep -s 3

Write-Host "Updating AuditLocator table..."
	

$conn = new-object system.data.SqlClient.SQLConnection("Data Source=$instance;Integrated Security=True;Initial Catalog=master");	
$query = "declare @initfile nvarchar(260)
		  select @initfile=log_file_path+ log_file_name from sys.server_file_audits where name = '$auditName'
		  set @initfile = STUFF(@initfile,len(@initfile)-charindex('.',reverse(@initfile)), 1, '*')
		  Insert into SQLAudit.dbo.AuditLocator (audit_name, file_name, audit_file_offset, file_pattern)
          SELECT top 1 '$auditName' as audit_name, file_name, audit_file_offset, @initfile as file_pattern
			 FROM fn_get_audit_file (@initfile, default,  default) order by event_time asc"
   
$cmd = new-object system.data.sqlclient.sqlcommand("$query", $conn);
$conn.open();
$cmd.ExecuteNonQuery() |out-null
$conn.close();
    

Write-Host "Done!"
 
