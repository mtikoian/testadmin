
-- Using fn_get_audit_file
SELECT server_principal_name, session_id, action_id, event_time, cast(additional_information as xml) as additional_information
	from fn_get_audit_file ('C:\Presentations\PASS Summit 2015\Demos\Security_Saved.sqlaudit', NULL, NULL)
	where action_id in ('LGIS','LGO')
	order by event_time


-- Login/Logout events and session duration
;WITH XMLNAMESPACES ('http://schemas.microsoft.com/sqlserver/2008/sqlaudit_data' as ns)
, x AS (
  SELECT server_principal_name, session_id, action_id, event_time, Prev = LAG(event_time, 1) OVER (PARTITION BY server_principal_name, session_id ORDER BY event_time)
		, add_info = cast(LAG(additional_information, 1) OVER (PARTITION BY server_principal_name, session_id ORDER BY event_time) as xml)
	from fn_get_audit_file ('C:\Presentations\PASS Summit 2015\Demos\Security_Saved.sqlaudit', NULL, NULL)
	where action_id in ('LGIS','LGO')
)
SELECT server_principal_name, session_id, Prev as [Login], event_time as [Logout], DATEDIFF(SECOND, Prev, event_time) as SecondsConnected
, T.c.value('(ns:address/text())[1]', 'nvarchar(30)') as ClientAddress
FROM x
cross apply add_info.nodes('/ns:action_info') AS T(c) 
WHERE action_id = 'LGO'
order by prev;

-- failed login attempts, list
;WITH XMLNAMESPACES ('http://schemas.microsoft.com/sqlserver/2008/sqlaudit_data' as ns)
, x AS (
  SELECT server_principal_name,  event_time, action_id
		, add_info = cast(additional_information as xml)
	from fn_get_audit_file ('C:\Presentations\PASS Summit 2015\Demos\Security_FailedLogins.sqlaudit', NULL, NULL)
	where action_id in ('LGIF')
)
SELECT server_principal_name, event_time 
, T.c.value('(ns:address/text())[1]', 'nvarchar(30)') as ClientAddress
FROM x
cross apply add_info.nodes('/ns:action_info') AS T(c) 
order by event_time;

--failed login attempts aggregated
;WITH XMLNAMESPACES ('http://schemas.microsoft.com/sqlserver/2008/sqlaudit_data' as ns)
, x AS (
  SELECT server_principal_name,  event_time, action_id
		, add_info = cast(additional_information as xml)
	from fn_get_audit_file ('C:\Presentations\PASS Summit 2015\Demos\Security_FailedLogins.sqlaudit', NULL, NULL)
	where action_id in ('LGIF')
), attempts as (
SELECT server_principal_name, cast(event_time as date) as EventDate, datepart(hh, event_time) as EventHour
, T.c.value('(ns:address/text())[1]', 'nvarchar(30)') as ClientAddress
FROM x
cross apply add_info.nodes('/ns:action_info') AS T(c) 
)
select ClientAddress, EventDate, EventHour, count(*) as FailedLogins, count(distinct server_principal_name) as PrincipalsUsed
from attempts
group by ClientAddress, EventDate, EventHour
