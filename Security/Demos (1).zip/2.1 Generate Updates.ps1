﻿add-type -path "C:\Program Files\Microsoft SQL Server\120\SDK\Assemblies\Microsoft.SqlServer.Smo.dll"
$inst = 'ASUS'
$db = 'AdventureWorks2012'
$s = new-object ('Microsoft.SqlServer.Management.Smo.Server') $inst
$Statement = 'exec Production.ReduceQuantity 363, 1'

$conn_options = ("Data Source=$inst; Initial Catalog=$db;Integrated Security=SSPI")
$conn1 = New-Object System.Data.SqlClient.SqlConnection($conn_options)
$conn1.Open()

$Command = New-Object System.Data.SQLClient.SQLCommand
$Command.Connection = $conn1
$Command.CommandText = "select top 1000 ProductID, LocationID from Production.ProductInventory order by NEWID()"
$Reader = $Command.ExecuteReader()

$intCounter = 0
 while($Reader.Read())
 {
    $productid = $Reader["ProductID"].ToString()    
    $locationid = $Reader["LocationID"].ToString()  
    $Statement = "exec Production.ReduceQuantity $productid, $locationid"
    $conn2 = New-Object System.Data.SqlClient.SqlConnection($conn_options)
    $conn2.Open()
    $cmd = $conn2.CreateCommand()
    $cmd.CommandText = $Statement
    $result = $cmd.ExecuteNonQuery()
    

    $intCounter++
    if ($intCounter%300 -eq 0) 
    {
        $cmd = $conn2.CreateCommand()
        $cmd.CommandText = "exec Production.UpdateLocation $productid, $locationid, 0"
        $result = $cmd.ExecuteNonQuery()
    }

    $conn2.Close()
 }  

