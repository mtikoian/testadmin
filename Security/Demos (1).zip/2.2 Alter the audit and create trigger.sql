
USE AdventureWorks2012
GO

--Disable the existing audit specification
ALTER DATABASE AUDIT SPECIFICATION [ProductInventoryAuditSpec] WITH ( STATE = OFF )
GO

--Alter the audit specification to audit user-defined events
ALTER DATABASE AUDIT SPECIFICATION [ProductInventoryAuditSpec]
DROP (UPDATE ON OBJECT::[Production].[ProductInventory] BY [public])
,ADD (USER_DEFINED_AUDIT_GROUP)
GO

--Enable the audit specification
ALTER DATABASE AUDIT SPECIFICATION [ProductInventoryAuditSpec] WITH ( STATE = ON )
GO

--how to write a user-defined event?  use sp_audit_write!
exec sp_audit_write 
	@user_defined_event_id = 1, 
	@succeeded = 1, 
	@user_defined_information = N'Hey, here is a user-defined event!'
GO


--Create trigger to write to the audit if Bin column is updated
CREATE TRIGGER Production.UpdateProductInventory 
   ON  Production.ProductInventory 
   AFTER UPDATE
AS 
BEGIN
	
	SET NOCOUNT ON;
	declare @message nvarchar(4000)
    
	if 0 < (select count(*) from inserted i 
			join deleted d on i.ProductID = d.ProductID 
			and i.LocationID = d.LocationID 
			and i.Bin <> d.Bin)
	begin

		DECLARE @buffer TABLE (
		EventType nvarchar(30),
		Parameters int,
		EventInfo nvarchar(4000)
		)
		insert @buffer
		exec sp_executesql N'DBCC INPUTBUFFER(@@spid) WITH NO_INFOMSGS'

		select @message = EventInfo from @buffer
	
		exec sp_audit_write @user_defined_event_id = 1, @succeeded = 1, @user_defined_information = @message

	end
END
GO

--Clear the existing audit log
USE master
GO
ALTER SERVER AUDIT [ProductInventoryAudit] WITH (STATE = OFF)
exec xp_cmdshell 'del C:\"Program Files"\"Microsoft SQL Server"\MSSQL12.MSSQLSERVER\MSSQL\Log\ProductInventoryAudit*'
ALTER SERVER AUDIT [ProductInventoryAudit] WITH (STATE = ON)