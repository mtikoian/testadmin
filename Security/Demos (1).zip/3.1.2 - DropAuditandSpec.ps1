Add-Type -Path 'C:\Program Files\Microsoft SQL Server\110\SDK\Assemblies\Microsoft.SqlServer.Smo.dll'


$srv = New-Object ('Microsoft.SqlServer.Management.Smo.Server') -argumentlist 'ASUS'
$db = New-Object Microsoft.SqlServer.Management.Smo.Database
$db = $srv.Databases.Item('AdventureWorks2012')
 
## Delete the audit spec
$auditSpec = $db.DatabaseAuditSpecifications | where {$_.Name -match "DDL_AuditSpec"}
$auditSpec.Disable()
$auditSpec.Drop()
 
## Delete the audit object
$delAudit = $srv.Audits | where {$_.Name -match "DDL_Audit"}
$delAudit.Disable()
$delAudit.Drop()
