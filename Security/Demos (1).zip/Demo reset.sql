
USE [master]
GO

-- restore the database
if exists (select * from sys.databases where name = 'SQLAudit')
BEGIN
	alter database [SQLAudit] set single_user with rollback immediate
	DROP DATABASE [SQLAudit] 
END
GO

-- restore the database
if exists (select * from sys.databases where name = 'AdventureWorks2012')
	alter database [AdventureWorks2012] set single_user with rollback immediate
	RESTORE DATABASE [AdventureWorks2012] FROM  DISK = N'C:\Presentations\PASS Summit 2015\Demos\AdventureWorks2012.bak' WITH  FILE = 1,  NOUNLOAD,  STATS = 5
GO

-- create login for the CEO, Ken Sanchez
if exists (select * from sys.server_principals where name = 'ken_sanchez')
	DROP LOGIN [ken_sanchez]
CREATE LOGIN [ken_sanchez] WITH PASSWORD=N'password', DEFAULT_DATABASE=[AdventureWorks2012], CHECK_EXPIRATION=OFF, CHECK_POLICY=OFF
GO

-- create login for Production Technician, Guy Gilbert
if exists (select * from sys.server_principals where name = 'guy_gilbert')
	DROP LOGIN [guy_gilbert]
CREATE LOGIN [guy_gilbert] WITH PASSWORD=N'password', DEFAULT_DATABASE=[AdventureWorks2012], CHECK_EXPIRATION=OFF, CHECK_POLICY=OFF
GO

USE [AdventureWorks2012]
GO
-- create users and grant read/write permissions
CREATE USER [ken_sanchez] FOR LOGIN [ken_sanchez]
ALTER ROLE [db_datareader] ADD MEMBER [ken_sanchez]
ALTER ROLE [db_datawriter] ADD MEMBER [ken_sanchez]
GO
CREATE USER [guy_gilbert] FOR LOGIN [guy_gilbert]
ALTER ROLE [db_datareader] ADD MEMBER [guy_gilbert]
ALTER ROLE [db_datawriter] ADD MEMBER [guy_gilbert]
GO

USE master
GO

if exists (select * from sys.server_audit_specifications where name = 'SecurityAuditSpec')
begin
	ALTER SERVER AUDIT SPECIFICATION [SecurityAuditSpec] WITH (STATE = OFF)
	DROP SERVER AUDIT SPECIFICATION [SecurityAuditSpec]
end

if exists (select * from sys.server_audits where name = 'SecurityAudit')
begin
	ALTER SERVER AUDIT [SecurityAudit] WITH (STATE = OFF)
	DROP SERVER AUDIT [SecurityAudit]
end

if exists (select * from sys.server_audits where name = 'DDL_Audit')
begin
	ALTER SERVER AUDIT [DDL_Audit] WITH (STATE = OFF)
	DROP SERVER AUDIT [DDL_Audit]
end


if exists (select * from sys.server_audit_specifications where name = 'ASUS_DDLAudit_Spec')
begin
	ALTER SERVER AUDIT SPECIFICATION [ASUS_DDLAudit_Spec] WITH (STATE = OFF)
	DROP SERVER AUDIT SPECIFICATION [ASUS_DDLAudit_Spec]
end

if exists (select * from sys.server_audits where name = 'ASUS_DDLAudit')
begin
	ALTER SERVER AUDIT [ASUS_DDLAudit] WITH (STATE = OFF)
	DROP SERVER AUDIT [ASUS_DDLAudit]
end

if exists (select * from sys.server_audits where name = 'ProductInventoryAudit')
begin
	ALTER SERVER AUDIT [ProductInventoryAudit] WITH (STATE = OFF)
	DROP SERVER AUDIT [ProductInventoryAudit]
end

--Create the initial Demo #2 audit
USE [master]

GO

CREATE SERVER AUDIT [ProductInventoryAudit]
TO FILE 
(	FILEPATH = N'C:\Program Files\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\Log'
	,MAXSIZE = 10 MB
	,MAX_ROLLOVER_FILES = 10
	,RESERVE_DISK_SPACE = OFF
)
WITH
(	QUEUE_DELAY = 0
	,ON_FAILURE = FAIL_OPERATION
)
GO
ALTER SERVER AUDIT [ProductInventoryAudit] WITH (STATE = ON)
GO

USE [AdventureWorks2012]
GO

CREATE DATABASE AUDIT SPECIFICATION [ProductInventoryAuditSpec]
FOR SERVER AUDIT [ProductInventoryAudit]
ADD (UPDATE ON OBJECT::[Production].[ProductInventory] BY [public])
WITH (STATE = ON )
GO

--Create procedure to decrement Inventory Quantity

create procedure Production.ReduceQuantity (
@ProductID int,
@LocationID smallint
)
AS
BEGIN

	declare @NewQuantity smallint

	UPDATE Production.ProductInventory 
	SET @NewQuantity = Quantity = Quantity-1 
	WHERE ProductID = @ProductID
	AND LocationID = @LocationID
	

	--if  @NewQuantity between 50 and 100
	--	UPDATE Production.ProductInventory 
	--	SET Bin = LocationID 
	--	WHERE ProductID = @ProductID
	--	AND LocationID = @LocationID 
END
GO

create procedure Production.UpdateLocation (
@ProductID int,
@LocationID smallint,
@NewLoc smallint
)
AS
BEGIN

	UPDATE Production.ProductInventory 
	SET Bin = @NewLoc 
	WHERE ProductID = @ProductID
	AND LocationID = @LocationID 

END
GO

