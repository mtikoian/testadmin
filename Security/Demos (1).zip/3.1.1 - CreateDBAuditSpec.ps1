Add-Type -Path 'C:\Program Files\Microsoft SQL Server\110\SDK\Assemblies\Microsoft.SqlServer.Smo.dll'

 
$srv = New-Object ('Microsoft.SqlServer.Management.Smo.Server') -argumentlist 'ASUS'
$db = New-Object Microsoft.SqlServer.Management.Smo.Database
$db = $srv.Databases.Item('AdventureWorks2012')
 
## Set audit spec properties
$AuditSpec = new-object Microsoft.SqlServer.Management.Smo.DatabaseAuditSpecification($db, 'DDL_AuditSpec')
$AuditSpec.AuditName = "DDL_Audit"
 
## Set audit actions
$SpecDetail = new-object Microsoft.SqlServer.Management.Smo.AuditSpecificationDetail("SchemaObjectChangeGroup")
$AuditSpec.AddAuditSpecificationDetail($SpecDetail)
 
## Create and enable audit spec
$AuditSpec.Create()
$AuditSpec.Enable()