
-- sp_who2

/*

   -- File Locations \Performance Tuning for Mere Mortals Part I\Demos\

   -- ** SETUP ********************************************************************************************************
    1. Restore AdventureWorks2014 
	   https://msftdbprodsamples.codeplex.com/releases/view/125550

	   "Part I - 1 - Create AdventureWorks Database.sql" -- Edit for location of your BAK file

	   -- Make sure TempDB is on fast disk

    2. Create Large AdventureWorks 
	   Run "Part I - 2 -Create Large AdventureWorks.sql"

    3. Create Blocking Procedure 
	   Run "Part I - 3 - BlockingProcedure.sql"

    4. Create Wait Stats Schema 
	   Run "Part I - 4 - Create Wait Stats Schema.sql"

    5. Clear buffer cache, proc cache and wait stats

	   -- Clear wait stats
	   DBCC SQLPERF('sys.dm_os_wait_stats', CLEAR);
	   DBCC FREEPROCCACHE;
	   DBCC DROPCLEANBUFFERS;



    6. Demonstrate how to create the sp_WhoIsActive schema from sp_WhoIsActive stored procedure "Part I - 3 - Create Schema  sp_WhoIsActive.sql"

	   --- CREATE WhoIsActive table SCHEMA 
	   PRINT 'USE PerfStats'
	   PRINT 'If EXISTS(select * from sys.tables where name = ''WhoIsActive'') DROP TABLE [WhoISActive]'
	   declare @schema VARCHAR(MAX)
	   exec perfstats.dbo.sp_WhoIsActive 
			   @get_plans = 1, 
			   @get_locks = 1, 
			   @get_task_info = 1, 
			   @get_avg_time = 1, 
			   @delta_interval = 1, 
			   @format_output = 0, 
			   @get_outer_command = 1,
			   @find_block_leaders = 1,
			   @return_schema = 1,
			   @schema = @schema OUTPUT
	   SELECT REPLACE(@schema,'<table_name>','WhoIsActive')


    7. Create WhoIsActive Job

	   Run "Part I - 5 - Create WhoIsActive Job.sql"


  --8. Start sp_WhoIsActive job:

	   IF EXISTS(SELECT * FROM msdb.dbo.sysjobs WHERE name like 'sp_WhoIsActive Collection%' and enabled = 0)
	   EXEC msdb.dbo.sp_update_job
		  @job_name = N'sp_WhoIsActive Collection - Stopped',
		  @new_name = N'sp_WhoIsActive Collection - Running',
		  @description = N'Start Collecting.',
		  @enabled = 1 ;
	   GO

  --9.	Start Perf Counters Job   

	   IF EXISTS(SELECT * FROM msdb.dbo.sysjobs WHERE name like 'Perf Counters%' and enabled = 0)
	   EXEC msdb.dbo.sp_update_job
		  @job_name = N'Perf Counters-Stopped',
		  @new_name = N'Perf Counters-Running',
		  @description = N'Start Collecting.',
		  @enabled = 1 ;
	   GO

 --10.	Start Wait Stats Job   

	   IF EXISTS(SELECT * FROM msdb.dbo.sysjobs WHERE name like 'Collect Wait Stats%' and enabled = 0)
	   EXEC msdb.dbo.sp_update_job
		  @job_name = N'Collect Wait Stats-Stopped',
		  @new_name = N'Collect Wait Stats-Running',
		  @description = N'Start Collecting.',
		  @enabled = 1 ;
	   GO

    11. "Dropbox\SQL Saturday\Presentations\
	   Performance Tuning for Mere Mortals Part I\Demos\Scripts\Blocking Demo"

	   Open and execute "Setup - Create User Stored Procedures.sql" to add the demo procedures.

    12. Open and run workload
	   "Dropbox\SQL Saturday\Presentations\
	   Performance Tuning for Mere Mortals Part I\Demos\Scripts\Blocking Demo"
	   Run Workload1.cmd, Workload2.cmd and Workload3.cmd


    13. 
    
	   EXEC sp_who2;     

		  --		Process status....what does it mean?  (Taken from http://msdn.microsoft.com/en-us/library/ms174313.aspx)
		  --
		  --		DORMANT			SQL Server is resetting the session.
		  --		RUNNING			The session is running one or more batches. When Multiple Active Result Sets (MARS) is enabled, a session can run multiple batches. For more information, see Using Multiple Active Result Sets (MARS).
		  --		BACKGROUND		The session is running a background task, such as deadlock detection.
		  --		ROLLBACK		The session has a transaction rollback in process.
		  --		PENDING			The session is waiting for a worker thread to become available.
		  --		RUNNABLE		The session's task is in the runnable queue of a scheduler while waiting to get a time quantum.
		  --		SPINLOOP		The session's task is waiting for a spinlock to become free.
		  --		SUSPENDED		The session is waiting for an event, such as I/O, to complete.
		  --
		  --	But wait...there missing something right?  Don't we see 'sleeping' here on the list?  
		  --
		  --		Sleeping / Awaiting Command means that a connection was established but there is no active query running at the moment.  This is usually good, 
		  --			however know that it is possible to have open transactions and be sleeping / Awaiting command if the client did not submit a commit or a rollback.
		  --
		  --		Interesting side note: EXEC sp_who2 'active'  will filter out any spid that has a status of sleeping or has a last command of AWAITING COMMAND, LAZY WRITER or CHECKPOINT SLEEP.
		  --
		  --  Dynamic Management Views.  In this section we will be looking at numerous DMVs.  What is a DMV?  http://technet.microsoft.com/en-us/library/ms188754.aspx
		  --
		  --		How do I find all of the DMVs?  There are dynamic management 
		  --      functions and views collectively called dynamic management 
		  --      objects but that usually gets confused with distributed 
		  --      management objects so its an accepted practice to call 
		  --      DMFs and DMVs collectively DMVs.
		  --
		  --		This script will list all of the DMVs available to you 
		  --		depending upon what version of SQL Server you are running as to how many there are.
		  --
		  --USE MASTER;
		  --GO
		  --SELECT	[name],
		  --		CASE [type]
		  --			WHEN 'IF' THEN 'DMF'
		  --			WHEN 'V'  THEN 'DMV'
		  --		END AS [DMO Type] 
		  --FROM	sys.sysobjects
		  --WHERE	[name] LIKE 'DM_%'
		  --ORDER BY [name];
		  --GO
		  --
		  -- 
		  --
    14. DMV to get the plan
		  --
		  -- sys.dm_exec_cached_plans http://technet.microsoft.com/en-us/library/ms187404.aspx
		  -- sys.dm_exec_query_plan http://technet.microsoft.com/en-us/library/ms189747.aspx
		  -- sys.dm_exec_sql_text http://technet.microsoft.com/en-us/library/ms181929(v=sql.110).aspx
		  --
	   SELECT   cp.refcounts												-- Number of cache objects that are referencing this cache object.
			 ,cp.usecounts												-- Number of times the cache object has been looked up.
			 ,cp.objtype							
			 ,DB_NAME(st.dbid) AS DBName
			 ,st.objectid
			 ,st.text
			 ,qp.query_plan
		FROM  sys.dm_exec_cached_plans cp
			   CROSS APPLY sys.dm_exec_sql_text(cp.plan_handle) st
			   CROSS APPLY sys.dm_exec_query_plan(cp.plan_handle) qp
		ORDER BY DBName;

		-- GET PLAN by SPID
		SELECT qp.QUERY_PLAN											-- XML QUERY EXECUTION PLAN
			  ,ER.*
		FROM SYS.DM_EXEC_REQUESTS ER									-- BASE DMV
			CROSS APPLY SYS.DM_EXEC_QUERY_PLAN(ER.PLAN_HANDLE) qp		-- LINK TO THE DMF
			WHERE SESSION_ID > 50 
			AND SESSION_ID <> @@SPID;
			GO

			--SELECT qp.query_plan, st.text, er.session_id, es.host_name, db_name(er.database_id) AS 'Database', er.status,
			--	   er.command, er.blocking_session_id AS 'Blocker', er.wait_type, er.wait_time, 
			--	   er.wait_resource, er.percent_complete, er.cpu_time, er.total_elapsed_time, 
			--	   er.total_elapsed_time - er.cpu_time AS 'Signal Time', er.reads, er.writes, 
			--	   er.logical_reads, er.granted_query_memory * 8 AS 'Query Mem KB'
			--FROM sys.dm_exec_requests er
			--JOIN sys.dm_exec_sessions es
			--ON er.session_id = es.session_id
			--CROSS APPLY sys.dm_exec_sql_text(er.sql_handle) st
			--CROSS APPLY sys.dm_exec_query_plan(er.plan_handle) qp
			--WHERE er.session_id > 50
			--AND er.session_id <> @@SPID
			--ORDER BY er.session_id;

    15. Look at sp_WhoIsActive data

	    select * 
	    from [PerfStats].[dbo].[WhoIsActive] 
	    where collection_time in (
		  select TOP 10 collection_time
		  from [PerfStats].[dbo].[WhoIsActive]
		  WHERE blocked_session_count = 1
		  OR blocking_session_id > 0
		  ORDER BY collection_time desc)

    13. Look at Execution Plan

    14. Get the name of the procedure causing the issues, open in SSMS. 

    15. Enable "Include Actual Execution Plan"

	   Parallelism: Threshold for Parallelism

	   Recommendations
	   This option is an advanced option and should be changed only by an experienced database 
	   administrator or certified SQL Server technician.

	   ** Note
	   In certain cases, a parallel plan may be chosen even though the query's cost plan 
	   is less than the current cost threshold for parallelism value. This can happen because 
	   the decision to use a parallel or serial plan is based on a cost estimate provided before 
	   the full optimization is complete.



    16. Examine the output using parameters passed. 

    17. Look at the parameters in properties and view the compiled vs. run parameters.

	   Is this a problem? 

	   Execute with recompile. If it runs in similar time, then probably not a parameter sniffing issue.

    17. Uncomment MAXDOP=1 to remove parallelism for this test. 

    18. HASH MATCH, how do we fix?

    19. Add SalesOrderID to PK before SalesOrderDetailID

    	   USE AdventureWorks2014
	   GO

	   ALTER TABLE [Sales].[SalesOrderDetailEnlarged] DROP CONSTRAINT [PK_SalesOrderDetailEnlarged_SalesOrderID_SalesOrderDetailID]
	   GO



	   ALTER TABLE Sales.SalesOrderDetailEnlarged ADD CONSTRAINT
	    PK_SalesOrderDetailEnlarged_SalesOrderID_SalesOrderDetailID PRIMARY KEY CLUSTERED 
	    (
	    SalesOrderID,
	    SalesOrderDetailID
	    ) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

	   GO

	   -- truncate table perfstats.dbo.WhoIsActive
    

    20. WaitStats collection

    	   SELECT * FROM [PerfStats].[dbo].[WaitStats] 
	   WHERE capture_date >= (
		  select capture_date 
		  from (
			 select top 20 capture_date, row_number() over (order by capture_date desc) as rn
			 from [PerfStats].[dbo].[WaitStats] 
			 group by capture_date
			 order by capture_date desc
			 ) a
			 where rn=10
		  )
	   AND wait_type = 'CXPACKET'

    21. dm_os_performance_counters
	   SELECT * 
	   FROM [PerfStats].[dbo].[dm_os_performance_counters]
	   WHERE [capture_date] = (
		  SELECT MAX([capture_date]) FROM [PerfStats].[dbo].[dm_os_performance_counters]
	   )


    -- Stop Perf Stats Collection  
    IF EXISTS(SELECT * FROM msdb.dbo.sysjobs WHERE name like 'Perf Counters%' and enabled = 1)
    EXEC msdb.dbo.sp_update_job
	   @job_name = N'Perf Counters-Running',
	   @new_name = N'Perf Counters-Stopped',
	   @description = N'Stop Collecting.',
	   @enabled = 0 ;
    GO


    -- Stop Wait Stats Collection  
    IF EXISTS(SELECT * FROM msdb.dbo.sysjobs WHERE name like 'Collect Wait Stats%' and enabled = 1)
    EXEC msdb.dbo.sp_update_job
	   @job_name = N'Collect Wait Stats-Running',
	   @new_name = N'Collect Wait Stats-Stopped',
	   @description = N'Stop Collecting.',
	   @enabled = 0 ;
    GO


    -- Stop Collect sp_WhoIsActive Job
    IF EXISTS(SELECT * FROM msdb.dbo.sysjobs WHERE name like 'sp_WhoIsActive Collection%' and enabled = 1)
    EXEC msdb.dbo.sp_update_job
	   @job_name = N'sp_WhoIsActive Collection - Running',
	   @new_name = N'sp_WhoIsActive Collection - Stopped',
	   @description = N'Stop Collecting.',
	   @enabled = 0 ;
    GO



*/