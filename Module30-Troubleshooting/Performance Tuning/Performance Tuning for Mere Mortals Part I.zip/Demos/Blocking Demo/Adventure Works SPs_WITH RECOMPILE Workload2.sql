/*
	Adventure Works SPs_WITH RECOMPILE Workload.sql
	This script requires four stored procedures to be first created
	in a copy of the AdventureWorks 2012 OLTP database.	
*/

------
USE AdventureWorks2014;
EXECUTE demo.AddDiscountToSalesOrderDetail '01/01/2011', '02/01/2011'
GO
------
