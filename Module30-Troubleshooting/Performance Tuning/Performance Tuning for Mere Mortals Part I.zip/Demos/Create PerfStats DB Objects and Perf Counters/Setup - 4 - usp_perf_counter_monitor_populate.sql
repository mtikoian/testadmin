USE [PerfStats]
GO

IF EXISTS(select * from sys.procedures where name = 'usp_perf_counter_monitor_populate')
DROP PROCEDURE [dbo].[usp_perf_counter_monitor_populate]
GO

/****** Object:  StoredProcedure [dbo].[perf_counter_monitor_populate]    Script Date: 5/4/2014 11:55:04 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[usp_perf_counter_monitor_populate] 

As

/**************************************************************************************
	AUTHOR: Mike Lawell
	Date: 05/10/2014

***************************************************************************************
    Exec dbo.perf_counter_monitor_populate
		
			
			SELECT * FROM dbo.dm_os_performance_counters 
*********************************************************************************/
 
Set NoCount On;
Set XACT_Abort On;
Set Ansi_Padding On;
Set Ansi_Warnings On;
Set ArithAbort On;
Set Concat_Null_Yields_Null On;
Set Numeric_RoundAbort Off;


DECLARE @INSTANCE varchar(255) 
SET @INSTANCE =  'MSSQL$' + CAST(SERVERPROPERTY ('InstanceName') as nvarchar(128)) + ':'

IF @INSTANCE IS NULL
	SET @INSTANCE = 'SQLServer:'
 
Begin


	INSERT INTO dbo.dm_os_performance_counters(capture_date, object_name, counter_name, instance_name, cntr_value, cntr_type)
	SELECT GETDATE(), RTRIM(REPLACE(pc.object_name,@INSTANCE,'')) , pc.counter_name, pc.instance_name, pc.cntr_value, pc.cntr_type
	FROM sys.dm_os_performance_counters pc
	JOIN dbo.perf_counter_monitor_config mc
	ON mc.counter_name = pc.counter_name
	AND (ISNULL(mc.instance_name,'') = ISNULL(pc.instance_name,'') OR mc.instance_name Is NULL)
	AND mc.object_name = RTRIM(REPLACE(pc.object_name,@INSTANCE,''))



  --  Return 0;
End


GO

