

--DBCC SQLPERF('sys.dm_os_wait_stats', CLEAR);
/************************************************************************************************************
***********      Create Table WaitStats   
*************************************************************************************************************/

USE [PerfStats]
GO

IF EXISTS(SELECT * FROM sys.tables WHERE name = 'WaitStats')
DROP TABLE [dbo].[WaitStats]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[WaitStats](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[wait_type] [nvarchar](60) NOT NULL,
	[wait_time_s] [decimal](12, 2) NULL,
	[avg_wait] [numeric](12, 1) NULL,
	[pct] [decimal](12, 2) NULL,
	[running_pct] [decimal](38, 2) NULL,
	[capture_date] [datetime] NOT NULL,
 CONSTRAINT [PK_WaitStats] PRIMARY KEY CLUSTERED 
(
	[capture_date] ASC,
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO



/************************************************************************************************************
***********      Create WaitStatsCollection Procedure   
*************************************************************************************************************/
USE [PerfStats]
GO

IF EXISTS(SELECT * FROM sys.procedures where name = 'WaitStatsCollection')
DROP PROCEDURE [dbo].[WaitStatsCollection]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[WaitStatsCollection]

AS

BEGIN;

    WITH Waits
    AS (SELECT wait_type, 
    wait_time_ms/(waiting_tasks_count*1.0) as avg_wait,

    CAST(wait_time_ms / 1000. AS DECIMAL(12, 2)) AS [wait_time_s],
	    CAST(100. * wait_time_ms / SUM(wait_time_ms) OVER () AS DECIMAL(12,2)) AS [pct],
	    ROW_NUMBER() OVER (ORDER BY wait_time_ms DESC) AS rn
	    FROM sys.dm_os_wait_stats WITH (NOLOCK)
	    WHERE waiting_tasks_count > 0
	    and wait_type NOT IN (N'CLR_SEMAPHORE', N'LAZYWRITER_SLEEP', N'RESOURCE_QUEUE',N'SLEEP_TASK',
							N'SLEEP_SYSTEMTASK', N'SQLTRACE_BUFFER_FLUSH', N'WAITFOR', N'LOGMGR_QUEUE',
							N'CHECKPOINT_QUEUE', N'REQUEST_FOR_DEADLOCK_SEARCH', N'XE_TIMER_EVENT',
							N'BROKER_TO_FLUSH', N'BROKER_TASK_STOP', N'CLR_MANUAL_EVENT', N'CLR_AUTO_EVENT',
							N'DISPATCHER_QUEUE_SEMAPHORE' ,N'FT_IFTS_SCHEDULER_IDLE_WAIT', N'XE_DISPATCHER_WAIT',
							N'XE_DISPATCHER_JOIN', N'SQLTRACE_INCREMENTAL_FLUSH_SLEEP', N'ONDEMAND_TASK_QUEUE',
							N'BROKER_EVENTHANDLER', N'SLEEP_BPOOL_FLUSH', N'SLEEP_DBSTARTUP', N'DIRTY_PAGE_POLL',
							N'HADR_FILESTREAM_IOMGR_IOCOMPLETION',N'SP_SERVER_DIAGNOSTICS_SLEEP',
							    N'QDS_PERSIST_TASK_MAIN_LOOP_SLEEP', N'QDS_CLEANUP_STALE_QUERIES_TASK_MAIN_LOOP_SLEEP',
							    N'WAIT_XTP_HOST_WAIT', N'WAIT_XTP_OFFLINE_CKPT_NEW_LOG', N'WAIT_XTP_CKPT_CLOSE',
							    N'PWAIT_ALL_COMPONENTS_INITIALIZED',N'XE_LIVE_TARGET_TVF')),
    Running_Waits 
    AS (
    SELECT W1.wait_type, wait_time_s, pct,avg_wait,
	    SUM(pct) OVER(ORDER BY pct DESC ROWS UNBOUNDED PRECEDING) AS [running_pct]
	    FROM Waits AS W1)

    INSERT INTO [dbo].[WaitStats] (wait_type, wait_time_s, avg_wait, pct, running_pct, capture_date)
    SELECT wait_type, wait_time_s, CAST(avg_wait as numeric(6,1)) as avg_wait, pct,  running_pct, getdate() as capture_date
    FROM Running_Waits
    WHERE running_pct - pct <= 99
    ORDER BY running_pct
    OPTION (RECOMPILE);

END


GO



/************************************************************************************************************
***********      CREATE Wait Stats Collection Job  
*************************************************************************************************************/
USE [msdb]
GO
DECLARE @job_id varchar(40)
SELECT @job_id = job_id from dbo.sysjobs where name like 'Collect Wait Stats%' 
/****** Object:  Job [Collect Wait Stats-Stopped]    Script Date: 8/8/2014 11:56:20 AM ******/
EXEC msdb.dbo.sp_delete_job @job_id=@job_id, @delete_unused_schedule=1
GO

/****** Object:  Job [Collect Wait Stats-Stopped]    Script Date: 8/8/2014 11:56:20 AM ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 8/8/2014 11:56:20 AM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Collect Wait Stats-Stopped', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'Stop Collecting.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Collect Wait Stats]    Script Date: 8/8/2014 11:56:20 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Collect Wait Stats', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'dbo.WaitStatsCollection', 
		@database_name=N'PerfStats', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Every 30 Seconds', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=2, 
		@freq_subday_interval=30, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20140808, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959, 
		@schedule_uid=N'b9a12a88-0d1f-40b5-a7a4-d7440e2193e5'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

