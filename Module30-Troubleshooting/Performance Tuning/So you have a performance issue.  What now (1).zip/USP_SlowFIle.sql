-- ====================================================================================================
-- Useless comment area...if you are reading this then you are not paying attention to the
-- presentation...if you are an available female DBA then 'How you doing?" in my best Joey Tribbiani
-- (that's from Friends...a TV show for you millenials hey wait why are you in this class shouldn't you 
-- be home watching reruns of Saved by the Bell?)...mmm...Taco Bell...wait..Squirrel...PAY ATTENTION!
-- ====================================================================================================
USE AdventureWorks2012;
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Watson...Ed Watson	
-- Create date: GETDATE()
-- Description:	Bing bada boom baby
-- =============================================

-- Drop Procedure so it doesn't error out when you try to create it again, DUH!
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[USP_SlowFile]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[USP_SlowFile]
GO

CREATE PROCEDURE USP_SlowFile 
	@maximum	INT				-- You can pass in how many records you want to create...one million for example?
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from interfering with SELECT statements. <-- Totally useless MS comment on every SProc created.
	SET NOCOUNT ON;

DECLARE @incr		INT
DECLARE @startdt	DATETIME
DECLARE @enddt		DATETIME

SET @incr	    = 1				-- Why not start at 1?
SELECT @startdt = GETDATE()		-- When did we start?  NOW!

WHILE @incr <= @maximum			-- Loop through as we increment and insert records.
BEGIN TRAN InsertEd				-- Transaction # 1
   INSERT [dbo].[Anakin] VALUES ('Watson...Ed Watson',NULL,NULL,GETDATE(),NULL)  -- Just setting the two fields originally to make this an inefficient process with an update afterwards
   SET @incr = @incr + 1;
END

-- Wait...no where clause?  Oh boy we are UPDATING ALL OF THE RECORDS in the table!!!!  
-- When we run two or three of these we should see some blocking as they each try to compete for records
BEGIN TRAN UpdateEd
	UPDATE [dbo].[Anakin]			
	SET [DoIReallyNeedAnotherVarChar] = 'Shaken not stirred',
		[SeriouslyDudeNotAnotherVarChar] = 'Bond?  Who is that?',
		[DateUpdated] = GetDate();


COMMIT TRAN InsertEd;
COMMIT TRAN UpdateEd;

SELECT @enddt = GETDATE();
SELECT CONVERT(varchar, @enddt - @startdt, 108) AS 'How long?'; -- How long did it take to run this process?
SELECT COUNT([JediID]) AS 'How Many?' FROM Anakin;			   -- How many rows do we have total in the table?

GO
