-- "So You Have a Performance Issue...What Now?"
--
-- Author:		Ed Watson
-- E-mail:		ed@sqlgator.com
-- Twitter:		@SQLGator
--
-- DO NOT RUN ANY OF THIS CODE IN PRODUCTION!!!!
-- 
-- If you have trouble running any of the commands such as SP_WHO you
-- may not have the VIEW SERVER STATE permission.  In order to add it
-- you will need execute the following as an admin: 
--		GRANT VIEW SERVER STATE TO YourLogin
--
--
-- There are essentially four main things to look for when you are
-- diagnosing SQL slowdowns:
--		1. Blocking
--		2. High CPU usage
--		3. High I/O usage
--		4. Parallelism (as depicted by multiple entries for same SPID)
-- =====================================================================
-- 
-- 1.  Add the Anakin table to the AdventureWorks2012 database 
--		Download AdventureWorks2012 from http://msftdbprodsamples.codeplex.com/releases/view/55330
--
USE AdventureWorks2012;
GO

-- Here we are going to clear out the Plan Cache so we get a clean slate for the demo...for more info go to: http://technet.microsoft.com/en-us/library/ms174283.aspx
DBCC FREEPROCCACHE;

IF OBJECT_ID ('dbo.Anakin', 'U') IS NOT NULL
	DROP TABLE dbo.Anakin;
GO

CREATE TABLE [dbo].[Anakin](
	[JediID] [int] IDENTITY(1,1) NOT NULL,
	[ReallyGoofyColumnName] [varchar](50) NULL,
	[DoIReallyNeedAnotherVarChar] [nvarchar](50) NULL,
	[SeriouslyDudeNotAnotherVarChar] [nvarchar](50) NULL,
	[DateInserted] [datetime] NULL,
	[DateUpdated] [datetime] NULL,
 CONSTRAINT [PK_Anakin] PRIMARY KEY CLUSTERED 
(
	[JediID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
--
-- 2.  Open and run USP_SlowFile.SQL to install the sample stored procedure demonstrating a slow stored procedure.  
--     Notice the inefficient UPDATE statement.  This is on purpose, if we execute this stored proc several times concurrently
--	   we should see some blocking.
--
-- 3.  Open and run ExecSProc1.sql, ExecSProc2.sql, ExecSProc3.sql simultaneously.  
--
-- 4.  Run sp_who and look at the data presented.  Concentrate on the SPIDs greater than 50 as those are not system related processes.
--
--		SP_WHO provides information about current users, sessions, and processes in an instance.
--		For more information:  http://technet.microsoft.com/en-us/library/ms174313.aspx
--			SYNTAX:  sp_who [ [ @loginame = ] 'login' | session ID | 'ACTIVE' ]
--
EXEC sp_who;
GO
--
-- 5. Do you see any blocking after refreshing a few times?  If not then run ForceBlocking.sql and run SP_WHO again!
--
EXEC sp_who;
GO
--
-- 6. Now that you see some blocking let's run SP_WHO and SP_WHO2 side by side to see more detail in the differences between the two.
--
--		SP_WHO2 is the unsupported revision of SP_WHO that provides a little bit more information than SP_WHO.
--
--			SYNTAX:  sp_who2 [ [ @loginame = ] 'login' | session ID | 'ACTIVE' ]  
--			
--
EXEC sp_who;
EXEC sp_who2;
GO
--
-- 7. Clear out the Anakin table, if you want especially after you have run this demo several times.  If you do then make sure you run step three (3) at least once more so you can have some data to move forward.
--
-- TRUNCATE TABLE Anakin;
--
-- 8. How do I see what is causing the problem if not for sp_who/sp_who2?  Let's look at the SPID that caused the first problem and then the SPID with the second block
--
-- DBCC INPUTBUFFER diplays the last statement sent from a client to SQL.  http://technet.microsoft.com/en-us/library/ms187730.aspx
-- 
--		SYNTAX:	DBCC INPUTBUFFER ( session_id [ , request_id ]) [WITH NO_INFOMSGS ]
--
-- ** The PROBLEM with DBCC INPUTBUFFER is that if it is called via RPC (remote procedure call) then you will not be able to see any parameters passed into a SProc for example
--
-- Replace 59 and 60 with the SPIDs for the first two blocked processes SPIDs
-- Set results to Text
DBCC INPUTBUFFER(55);
DBCC INPUTBUFFER(58);

-- Can I kill it?  Will it rollback?  How long will it take?  Can I check the progress?  http://technet.microsoft.com/en-us/library/ms173730.aspx
KILL 55;
KILL 55 WITH STATUSONLY;

-- Set results back to grid
--
--
-- 9. I found this Little piece of code a few years ago which is supposed to help find the code using sys.dm_exec_request and it does show the last SQL Statement...as you can see it helps, but not much
--
--		sys.dm_exec_requests: Returns info about each request executing.	http://technet.microsoft.com/en-us/library/ms177648.aspx
--
--		sys.dm_exec_sql_text: Returns the text of the SQL batch that is identified by the specified sql_handle.  http://technet.microsoft.com/en-us/library/ms181929.aspx

SELECT  Session_id, 
		SQLStatement = SUBSTRING
        (EXST.text,
         EXRQ.statement_start_offset/2,
            (CASE WHEN EXRQ.statement_end_offset = -1 THEN LEN(CONVERT(nvarchar(MAX), EXST.text)) * 2 ELSE EXRQ.statement_end_offset END - EXRQ.statement_start_offset)/2)
FROM sys.dm_exec_requests EXRQ
CROSS APPLY sys.dm_exec_sql_text(EXRQ.sql_handle) AS EXST
WHERE EXRQ.session_id > 50	-- You can set this equal to the SPID you identified with SP_WHO2 but since we have two blocking SPIDs in this instance I wanted to see all processes above 50
-- 
--
--
-- 10. Let's get some more detailed information from sys.dm_exec_query_stats which returns aggregate performance statistics for cached query plans.  
--	   When plans are removed from cache they will no longer show in this query.
--
--	   I love the following message on that site "An initial query of sys.dm_exec_query_stats might produce inaccurate results if there is a workload currently executing on the server. More accurate results may be determined by rerunning the query."
--		
--		sys.dm_exec_query_stats: http://msdn.microsoft.com/en-us/library/ms189741.aspx
--		sys.dm_exec_sql_text: Returns the text of the SQL batch that is identified by the specified sql_handle.  http://technet.microsoft.com/en-us/library/ms181929.aspx
--
SELECT   creation_time				-- Time at which the plan was compiled.
        ,last_execution_time		-- Last time at which the plan started executing.
        ,total_physical_reads		-- Total number of physical reads performed by executions of this plan since it was compiled.
        ,total_logical_reads		-- Total number of logical reads performed by executions of this plan since it was compiled.
        ,total_logical_writes		-- Total number of logical writes performed by executions of this plan since it was compiled.
        ,total_rows					-- Total number of rows returned by the query.
		,last_rows					-- Number of rows returned by the last execution of the query. 
        ,execution_count			-- Number of times that the plan has been executed since it was last compiled.
        ,total_worker_time			-- Total amount of CPU time, reported in microseconds (but only accurate to milliseconds), that was consumed by executions of this plan since it was compiled.
        ,total_elapsed_time			-- Total elapsed time, reported in microseconds (but only accurate to milliseconds), for completed executions of this plan.
        ,((total_elapsed_time / execution_count) / 1000000)  AS avg_elapsed_time		-- Let's do the math to calculate the Average Elapsed Time as SECONDS from Microseconds
        ,SUBSTRING(est.text, (eqs.statement_start_offset/2) + 1,	-- Let's grab the statement text
         ((CASE statement_end_offset WHEN -1 THEN DATALENGTH(est.text) ELSE eqs.statement_end_offset END - eqs.statement_start_offset)/2) + 1) AS statement_text
FROM sys.dm_exec_query_stats AS eqs
CROSS APPLY sys.dm_exec_sql_text(eqs.sql_handle) est
ORDER BY total_elapsed_time / execution_count DESC;

-- 
-- 11. Clear the plan cache and watch the query above change after you kick off the ExecSProc1.SQL, ExecSProc2.SQL, ExecSProc3.SQL, and ForceBlocking.SQL
-- 
-- DBCC FREEPROCCACHE 
--
-- 12. Run the same query again.
--
SELECT   creation_time				-- Time at which the plan was compiled.
        ,last_execution_time		-- Last time at which the plan started executing.
        ,total_physical_reads		-- Total number of physical reads performed by executions of this plan since it was compiled.
        ,total_logical_reads		-- Total number of logical reads performed by executions of this plan since it was compiled.
        ,total_logical_writes		-- Total number of logical writes performed by executions of this plan since it was compiled.
        ,total_rows					-- Total number of rows returned by the query.
		,last_rows					-- Number of rows returned by the last execution of the query. 
		,execution_count			-- Number of times that the plan has been executed since it was last compiled.
        ,total_worker_time			-- Total amount of CPU time, reported in microseconds (but only accurate to milliseconds), that was consumed by executions of this plan since it was compiled.
        ,total_elapsed_time			-- Total elapsed time, reported in microseconds (but only accurate to milliseconds), for completed executions of this plan.
        ,((total_elapsed_time / execution_count) / 1000000)  AS avg_elapsed_time		-- Let's do the math to calculate the Average Elapsed Time as SECONDS from Microseconds
        ,SUBSTRING(est.text, (eqs.statement_start_offset/2) + 1,	-- Let's grab the statement text
         ((CASE statement_end_offset WHEN -1 THEN DATALENGTH(est.text) ELSE eqs.statement_end_offset END - eqs.statement_start_offset)/2) + 1) AS statement_text
FROM sys.dm_exec_query_stats AS eqs
CROSS APPLY sys.dm_exec_sql_text(eqs.sql_handle) est
ORDER BY total_elapsed_time / execution_count DESC;

--
-- 13. Some code from Aaron Bertrand http://sqlblog.com/blogs/aaron_bertrand/archive/2008/07/01/sys-dm-exec-requests.aspx
-- Let's look at dm_exec_requests again
-- sys.dm_exec_requests	http://technet.microsoft.com/en-us/library/ms177648.aspx

SELECT * FROM sys.dm_exec_requests;
--
-- Then copy and paste the SQL_HANDLE from the SPID you wanted
--
SELECT * FROM sys.dm_exec_sql_text(< copied sql_handle >);
--
-- Wow that takes a while and what a hassle!
--
-- How about this instead?  It shows our SProc but not what value are passed in....maybe you don't care you just want to find the SProc
--

SELECT	 [spid] = r.[session_id]				-- ID of the session to which this request is related. Is not nullable.
		,[database] = DB_NAME(r.[database_id])	-- ID of the database the request is executing against.
		,r.[start_time]							-- Timestamp when the request arrived
		,r.[status]								-- Status of the request. This can be of the following: Background, Running, Runnable, Sleeping, Suspended 
		,r.[command]							-- Identifies the current type of command that is being processed. Common command types include the following: 
												-- SELECT, INSERT, UPDATE, DELETE, BACKUP LOG, BACKUP DATABASE, DBCC, FOR
												-- The text of the request can be retrieved by using sys.dm_exec_sql_text with the corresponding sql_handle for the request. Internal system processes set the command based on the type of task they perform. Tasks can include the following:
												-- LOCK MONITOR, CHECKPOINTLAZY, WRITER
		/* add other interesting columns here */
		,[obj] = QUOTENAME(OBJECT_SCHEMA_NAME(t.[objectid], t.[dbid])) + '.' + QUOTENAME(OBJECT_NAME(t.[objectid], t.[dbid]))  -- Gives us the stored procedure in this case
		,t.[text]
FROM sys.dm_exec_requests AS r
CROSS APPLY sys.dm_exec_sql_text(r.[sql_handle]) AS t
WHERE r.[session_id] <> @@SPID
  AND r.[session_id]  > 50
/* -- optionally:
  AND r.session_id IN (< list of interesting spids >)
*/
;
--
--
-- 14. The second sample does something similar with transactions and locks.  
--
-- sys.dm_tran_locks	http://technet.microsoft.com/en-us/library/ms190345.aspx
-- sys.dm_exec_requests http://technet.microsoft.com/en-us/library/ms177648.aspx
--
SELECT	 [spid] = r.[session_id]
		,[database] = DB_NAME(r.[database_id])
		,r.[start_time]
		,r.[status]					-- Status of the request. This can be of the following: Background, Running, Runnable, Sleeping, Suspended
		,r.[command]				-- Identifies the current type of command that is being processed.  
		,[obj] = QUOTENAME(OBJECT_NAME(t.resource_associated_entity_id, r.database_id))
		,[request_owner_type]		-- Entity type that owns the request. Lock manager requests can be owned by a variety of entities. Possible values are:
									--TRANSACTION = The request is owned by a transaction.
									--CURSOR = The request is owned by a cursor.
									--SESSION = The request is owned by a user session.
									--SHARED_TRANSACTION_WORKSPACE = The request is owned by the shared part of the transaction workspace.
									--EXCLUSIVE_TRANSACTION_WORKSPACE = The request is owned by the exclusive part of the transaction workspace.
									--NOTIFICATION_OBJECT = The request is owned by an internal SQL Server component. This component has requested the lock manager to notify it when another component is waiting to take the lock. The FileTable feature is a component that uses this value.
		/* add other interesting columns here */
		,t.[request_mode]			-- Mode of the request. For granted requests, this is the granted mode; for waiting requests, this is the mode being requested.
									-- Intent shared (IS), Shared (S), Update (U), Intent exclusive (IX), Shared with intent exclusive (SIX), Exclusive (X)....see: http://technet.microsoft.com/en-us/library/ms186396(v=sql.105).aspx
		,t.[request_type]			-- Request type. The value is LOCK.
		,t.[request_status]			-- Current status of this request. Possible values are GRANTED, CONVERT, or WAIT.
FROM sys.dm_exec_requests AS r
LEFT OUTER JOIN sys.dm_tran_locks AS t ON r.[transaction_id] = t.[request_owner_id]
WHERE t.[request_owner_type] = N'TRANSACTION'
  AND r.[session_id] <> @@SPID
  AND r.[session_id] > 50
/* -- optionally:
  AND r.session_id IN (< list of interesting spids >)
*/
;

--
-- 15. This little piece of code is great as it shows the command that blocks as well as the command that is waiting along with the lock information.
--
-- sys.dm_os_waiting_tasks http://technet.microsoft.com/en-us/library/ms188743.aspx
--
WITH blocking_info AS
(SELECT [blocker] = wait.[blocking_session_id],			-- ID of the session that is blocking the request. If this column is NULL, the request is not blocked, or the session information of the blocking session is not available (or cannot be identified).
														-- -2 = The blocking resource is owned by an orphaned distributed transaction.
														-- -3 = The blocking resource is owned by a deferred recovery transaction.
														-- -4 = Session ID of the blocking latch owner could not be determined due to internal latch state transitions.
        [waiter] = lock.[request_session_id],
        b_handle = br.[sql_handle],
        w_handle = wr.[sql_handle],
        [dbid] = lock.[resource_database_id],
        duration = wait.[wait_duration_ms] / 1000,		-- Total wait time for this wait type, in milliseconds. 
        lock_type = lock.[resource_type],
        lock_mode = block.[request_mode]
FROM sys.dm_tran_locks AS lock
INNER JOIN sys.dm_os_waiting_tasks AS wait ON lock.[lock_owner_address] = wait.[resource_address]
INNER JOIN sys.dm_exec_requests AS br ON wait.[blocking_session_id] = br.[session_id]
INNER JOIN sys.dm_exec_requests AS wr ON lock.[request_session_id] = wr.[session_id]
INNER JOIN sys.dm_tran_locks AS block ON block.[request_session_id] = br.[session_id]
WHERE block.[request_owner_type] = 'TRANSACTION'
)
SELECT	[database] = DB_NAME(bi.[dbid])
		,bi.[blocker]
		,blocker_command = bt.[text]
		,bi.[waiter]
		,waiter_command  = wt.[text]
		,[duration MM:SS] = RTRIM(bi.[duration] / 60) + ':' + RIGHT('0' + RTRIM(bi.[duration] % 60), 2)
		,bi.[lock_type]
		,bi.[lock_mode]
FROM blocking_info AS bi
CROSS APPLY sys.dm_exec_sql_text(bi.[b_handle]) AS bt
CROSS APPLY sys.dm_exec_sql_text(bi.[w_handle]) AS wt;

--SELECT * FROM sys.dm_exec_requests WHERE session_id > 50

--
-- 16.	Now we move on to Adam Machanic's sp_whoisactive which will essentially replace your use of sp_who or sp_who2 because of the additional details it provides using over 15 DMVs in the process.
--		You can download it at http://sqlblog.com/blogs/adam_machanic/archive/2012/03/22/released-who-is-active-v11-11.aspx
--		Adam also wrote a month long blog series detailing everything about sp_whoisactive at: http://sqlblog.com/blogs/adam_machanic/archive/tags/who+is+active/month+of+monitoring/default.aspx

-- The beauty of Adam's stored procedure is that you can grab the problem code and run it in test when there is a problem in prod!!!!!!
-- Also sp_whoisactive does not show sessions that are sleeping like sp_who* which shows *EVERY* session connecting to a SQL Server.  The one exception is the sleeping session that is holding open a transaction. See below instructions on how to see them all.
--
EXEC sp_whoisactive;

--
-- Let's look at sp_who and sp_who2 again in case we forgot what it looked like
--
EXEC sp_who;
EXEC sp_who2;
EXEC sp_whoisactive;

-- One thing to notice is the Open_tran_count as we have nested Begin Transaction blocks inside of our ForceBlocking.sql
--
-- 17. But where did all of the sessions go that we see in sp_who2?  To see all of the sessions, similar to sp_who2:
--
EXEC sp_who2;
EXEC sp_WhoIsActive @show_sleeping_spids = 2, @show_system_spids = 1, @show_own_spid = 1
--

--
--
-- 18.  Let's look at all of the options for sp_whoisactive....there are a ton of them
--
--
--
EXEC sp_whoisactive @get_plans = 1;
EXEC sp_whoisactive @get_locks = 1;

EXEC sp_whoisactive @get_additional_info = 1;
EXEC sp_whoisactive @find_block_leaders = 1, @sort_order = '[blocked_session_count] DESC';

-- We still cannot see the whole piece of code...until NOW!
EXEC sp_WhoIsActive @get_full_inner_text = 1, @get_outer_command = 1, @get_transaction_info = 1

EXEC sp_whoisactive @help = 1;
--@get_plans = 1						Get associated query plans for running tasks, if available
										--If @get_plans = 1, gets the plan based on the request's statement offset
										--If @get_plans = 2, gets the entire plan based on the request's plan_handle
--@get_locks = 1						Gives you the XML that you can click on to see what locks each query owns.  ** This is straight from sys.dm_tran_locks **  This DMV can be seriously slow per Adam.
--@get_additional_info					Gives additional non-performance information in an XML output available from sys.dm_exec_requests: http://sqlblog.com/blogs/adam_machanic/archive/2011/04/18/getting-more-information-a-month-of-activity-monitoring-part-18-of-30.aspx
										--If a SQL Agent job is running, an subnode called agent_info will be populated with some or all of the following: job_id, job_name, step_id, step_name, msdb_query_error (in the event of an error)
										--If @get_task_info is set to 2 and a lock wait is detected, a subnode called block_info will be populated with some or all of the following: lock_type, database_name, object_id, file_id, hobt_id, applock_hash, metadata_resource, metadata_class_id, object_name, schema_name
--@get_task_info = 1 					For parallel queries with CXPACKET waits, see what tasks in the query is waiting on.  In these examples we do not but I included it here for your knowledge!
--@get_task_info = 2					Shows multiple tasks in the results...see  an example at: http://sqlblog.com/blogs/adam_machanic/archive/2011/04/20/the-node-knows-a-month-of-activity-monitoring-part-20-of-30.aspx
										--Level 0 does not pull any task-related information
										--Level 1 is a lightweight mode that pulls the top non-CXPACKET wait, giving preference to blockers
										--Level 2 pulls all available task-based metrics, including: number of active tasks, current wait stats, physical I/O, context switches, and blocker information
--@find_block_leaders = 1				Walk the blocking chain and count the number of total SPIDs blocked all the way down by a given session. Also enables task_info Level 1, if @get_task_info is set to 0
--@sort_order = '[field] asc or desc'	Will let you sort results
--@get_avg_time	= 1						This column reflects the average run time of past runs, if it�s available, of the statement that your request is currently working on. Will be shown as [dd hh:mm:ss.mss (avg)]
--@filter  = '<INSERT FILTER>'			Filters--Both inclusive and exclusive
--@filter_type = 'session'				Session is a session ID, and either 0 or '' can be used to indicate "all" sessions
--@not_filter = '<INSERT FILTER>'		Valid filter types are: session, program, database, login, and host			
--@not_filter_type = 'session'			All other filter types support % or _ as wildcards
--										Example:  EXEC sp_WhoIsActive @filter_type = 'login', @filter = 'SQLGator\Ed'
--@show_own_spid = 1					Retrieve data about the calling session
--@show_system_spids = 1				Retrieve data about system sessions?
--@show_sleeping_spids  = 1				Controls how sleeping SPIDs are handled, based on the idea of levels of interest
										--0 does not pull any sleeping SPIDs
										--1 pulls only those sleeping SPIDs that also have an open transaction
										--2 pulls all sleeping SPIDs
--@get_full_inner_text = 0				If 1, gets the full stored procedure or running batch, when available...If 0, gets only the actual statement that is currently running in the batch or procedure
--@get_outer_command = 0				Get the associated outer ad hoc query or stored procedure call, if available
--@get_transaction_info = 0				Enables pulling transaction log write info and transaction duration
--@delta_interval = 0					Pull deltas on various metrics (Interval in seconds to wait before doing the second data pull)
--@output_column_list = '[dd%][session_id][sql_text][sql_command][login_name][wait_info][tasks][tran_log%][cpu%][temp%][block%][reads%][writes%][context%][physical%][query_plan][locks][%]' 
--@sort_order = '[start_time] ASC'		Must be valid column names
--@format_output = 1					Formats some of the output columns in a more "human readable" form
										--0 disables outfput format
										--1 formats the output for variable-width fonts
										--2 formats the output for fixed-width fonts
--@destination_table = ''				If set to a non-blank value, the script will attempt to insert into the specified destination table. Please note that the script will not verify that the table exists, or that it has the correct schema, before doing the insert. Table can be specified in one, two, or three-part format
--@return_schema = 0					If set to 1, no data collection will happen and no result set will be returned; instead, a CREATE TABLE statement will be returned via the @schema parameter, which will match the schema of the result set that would be returned by using the same collection of the rest of the parameters. The CREATE TABLE statement will have a placeholder token of <table_name> in place of an actual table name.
--@schema = NULL OUTPUT 
--@help = 1								Help! What do I do?




--
-- 19.  Show me some plans please from Jason Strate... http://www.jasonstrate.com/2013/10/can-you-dig-it-find-all-plans-for-a-database/+
--
-- sys.dm_exec_cached_plans http://technet.microsoft.com/en-us/library/ms187404.aspx
-- sys.dm_exec_query_plan http://technet.microsoft.com/en-us/library/ms189747.aspx
-- sys.dm_exec_plan_attributes http://technet.microsoft.com/en-us/library/ms189472.aspx
-- 
-- List all execution plans for a specific database

WITH XMLNAMESPACES(DEFAULT 'http://schemas.microsoft.com/sqlserver/2004/07/showplan')
SELECT cp.usecounts			-- Number of times the cache object has been looked up. Not incremented when parameterized queries find a plan in the cache. Can be incremented multiple times when using showplan.
	  ,cp.size_in_bytes		-- Number of bytes consumed by the cache object.
	  ,cp.cacheobjtype		-- Type of object in the cache. The value can be one of the following: Compiled Plan, Compiled Plan Stub, Parse Tree, Extended Proc, CLR Compiled Func, CLR Compiled Proc
	  ,cp.objtype			-- Type of object. The value can be one of the following: Proc, Prepared, Adhoc, ReplProc, Trigger, View, Default, UsrTab, SysTab, Check, Rule
	  ,pa.attribute			-- Name of the attribute associated with this plan. 
	  ,pa.value				-- Value of the attribute that is associated with this plan.
	  ,pa.is_cache_key		-- Indicates whether the attribute is used as part of the cache lookup key for the plan.
	  ,qp.dbid				-- ID of the context database that was in effect when the Transact-SQL statement corresponding to this plan was compiled. For ad hoc and prepared SQL statements, the ID of the database where the statements were compiled.
	  ,qp.objectid			-- ID of the object (for example, stored procedure or user-defined function) for this query plan. For ad hoc and prepared batches, this column is null.
	  ,qp.number			-- Numbered stored procedure integer. For example, a group of procedures for the orders application may be named orderproc;1, orderproc;2, and so on. For ad hoc and prepared batches, this column is null.
	  ,cp.plan_handle		-- Identifier for the in-memory plan. This identifier is transient and remains constant only while the plan remains in the cache. 
	  ,qp.query_plan		-- Contains the compile-time Showplan representation of the query execution plan that is specified with plan_handle. The Showplan is in XML format. One plan is generated for each batch that contains, for example ad hoc Transact-SQL statements, stored procedure calls, and user-defined function calls.
FROM sys.dm_exec_cached_plans cp
CROSS APPLY sys.dm_exec_plan_attributes(cp.plan_handle) pa
CROSS APPLY sys.dm_exec_query_plan(cp.plan_handle) qp
WHERE attribute = 'dbid'
  AND value = DB_ID()
ORDER BY cp.usecounts DESC

--
-- 20.	Brent Ozar's sp_Blitz http://www.brentozar.com/blitz/
--		This is a server health check script that is top notch provided by Brent Ozar, a SQL Server MCM
--		It's not exactly needed to solve a problem but it is a great script to run BEFORE you have problems.
--
--		There is also a windows app you can run on your desktop without installing the script on all of your servers.  Here is an excerpt from Brent's page:
--		"How the sp_Blitz Windows app works � download and install it on your workstation, not the SQL Server itself. That way you can do health checks against any SQL Server in your shop. Run it, put in a server name, and it creates the sp_Blitz stored procedure temporarily that server�s TempDB. It creates a print-friendly report complete with links to web pages with more information. The Windows app also automatically updates itself with the latest version of sp_Blitz, too."

-- Default run
EXEC sp_Blitz

-- Possible options:
--		@CheckUserDatabaseObjects		1=review user databases for triggers, heaps, etc. Takes more time for more databases and objects.
--		@CheckProcedureCache			1=top 20-50 resource-intensive cache plans and analyze them for common performance issues.
--		@OutputType						''TABLE''=table | ''COUNT''=row with number found | ''SCHEMA''=version and field list
--		@OutputProcedureCache			1=output the top 20-50 resource-intensive plans even if they did not trigger an alarm
--		@CheckProcedureCacheFilter		''CPU'' | ''Reads'' | ''Duration'' | ''ExecCount''
--		@CheckServerInfo				1=show server info like CPUs, memory, virtualization
--		@SkipChecksServer
--		@SkipChecksDatabase
--		@SkipChecksSchema
--		@SkipChecksTable
--		@IgnorePrioritiesBelow
--		@IgnorePrioritiesAbove
--		@OutputDatabaseName
--		@OutputSchemaName
--		@OutputTableName
--		@OutputXMLasNVARCHAR
--		@EmailRecipients
--		@EmailProfile
--		@SummaryMode
--		@Help
--		@Version
--		@VersionDate

-- Brent's sample with the most common parameters
EXEC [master].[dbo].[sp_Blitz]
    @CheckUserDatabaseObjects = 1,			-- 1=review user databases for triggers, heaps, etc. Takes more time for more databases and objects.
    @CheckProcedureCache = 1,				-- 1=top 20-50 resource-intensive cache plans and analyze them for common performance issues.
    @OutputType = 'TABLE',					-- 'TABLE'=table | 'COUNT'=row with number found | 'SCHEMA'=version and field list
--  @OutputType = 'COUNT',
--  @OutputType = 'SCHEMA',
    @OutputProcedureCache = 1,				-- 1=output the top 20-50 resource-intensive plans even if they did not trigger an alarm
    @CheckProcedureCacheFilter = NULL,		-- 'CPU' | 'Reads' | 'Duration' | 'ExecCount'
--	@CheckProcedureCacheFilter = 'CPU',
--	@CheckProcedureCacheFilter = 'Reads',
--	@CheckProcedureCacheFilter = 'Duration',
--	@CheckProcedureCacheFilter = 'ExecCount',
    @CheckServerInfo = 1					-- 1=show server info like CPUs, memory, virtualization

--
--	21.	Brent Ozar's sp_BlitzIndex http://www.brentozar.com/blitzindex/
--
--		Instructions from inside of the script:
--  How to use:
--	Diagnose:
		EXEC dbo.sp_BlitzIndex @DatabaseName='AdventureWorks2012';
--	Return detail for a specific table:
		EXEC dbo.sp_BlitzIndex @DatabaseName='AdventureWorks2012', @SchemaName='Person', @TableName='Person';


--
--	22.	Now the newest toy, sp_AskBrent....hold the applause for your MCM in a box.  http://www.BrentOzar.com/askbrent/
--
--		Checks for things like:
--			* Blocking queries that have been running a long time
--			* Backups, restores, DBCCs
--			* Recently cleared plan cache
--			* Transactions that are rolling back
--
EXEC dbo.sp_AskBrent 

EXEC dbo.sp_AskBrent @ExpertMode = 1;
EXEC dbo.sp_AskBrent @ExpertMode = 0;

-- Proof that Brent does have a sense of humor.
EXEC dbo.sp_AskBrent 'This is a test question';

--
--	23.	The performance dashboard  http://www.microsoft.com/en-us/download/details.aspx?id=29063
--
--		A little more work involved here...
--		Getting Started With the Performance Dashboard Reports
--		1. Each SQL Server instance you plan to monitor must contain the procedures and functions used by the queries in the reports.  Using SQL Server Management Studio (SSMS), open the setup.sql script from your installation directory (default of %ProgramFiles(x86)%\Microsoft SQL Server\110\Tools\Performance Dashboard) and run the script.  Close the query window once it completes.
--		2. In the Object Explorer pane in SSMS, right mouse click on the SQL Server instance node, then choose Reports-Custom Reports.  Browse to the installation directory and open the performance_dashboard_main.rdl file.  Explore the health of your server by clicking on the various charts and hyperlinks in the report.
--		All of the remaining reports are accessed as drill through operations from the main page or one of its children.  For a detailed explanation of all installation requirements and guidance on how to use the reports, please see the help file, PerformanceDashboardHelp.chm.



-- Useful Links
--
-- http://www.brentozar.com/archive/2006/12/dba-101-using-perfmon-for-sql-performance-tuning/
-- http://www.brentozar.com/archive/2012/11/introducing-the-sql-server-plan-cache-and-a-better-sp_blitz/
-- http://www.brentozar.com/sql-server-training-videos/wait-stats-lose-wait-fast/
-- Bob Ward's Wait Types Repository http://blogs.msdn.com/b/psssql/archive/2009/11/03/the-sql-server-wait-type-repository.aspx
-- http://rusanu.com/2014/02/24/how-to-analyse-sql-server-performance/

-- The definitive WHITE PAPER resource for Performance Tuning
-- http://download.microsoft.com/download/4/7/a/47a548b9-249e-484c-abd7-29f31282b04d/Performance_Tuning_Waits_Queues.doc




-- Find Chain of Blockers

SELECT   spid
		,sp.STATUS
		,loginame   = SUBSTRING(loginame, 1, 12)
		,hostname   = SUBSTRING(hostname, 1, 12)
		,blk        = CONVERT(CHAR(3), blocked)
		,open_tran
		,dbname     = SUBSTRING(DB_NAME(sp.dbid),1,10)
		,cmd
		,waittype
		,waittime
		,last_batch
		,SQLStatement       = SUBSTRING(
            qt.text,
            er.statement_start_offset/2,
            (CASE WHEN er.statement_end_offset = -1 THEN LEN(CONVERT(nvarchar(MAX), qt.text)) * 2 ELSE er.statement_end_offset END - er.statement_start_offset)/2
        )
FROM master.dbo.sysprocesses sp
LEFT JOIN sys.dm_exec_requests er ON er.session_id = sp.spid
OUTER APPLY sys.dm_exec_sql_text(er.sql_handle) AS qt
WHERE spid IN (SELECT blocked FROM master.dbo.sysprocesses)
AND blocked = 0