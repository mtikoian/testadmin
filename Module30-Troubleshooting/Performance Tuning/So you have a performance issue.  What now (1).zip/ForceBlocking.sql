-- ========================================================
-- Author:		Watson...Ed Watson	
-- Create date: GETDATE()
-- Description:	Run this to force some blocking
--				THIS IS REALLY BAD DO NOT DO THIS FOR FUN!
-- ========================================================

USE [AdventureWorks2012];
GO
BEGIN TRANSACTION
	BEGIN TRANSACTION -- Two is better than one
		BEGIN TRANSACTION -- Three's a crowd
			BEGIN TRANSACTION -- Four is a party!
	SELECT * FROM Anakin WITH (TABLOCKX, HOLDLOCK)
	WHERE 0 = 1
	WAITFOR DELAY '00:10' -- Ten minutes
ROLLBACK TRANSACTION
-- Use Table Hints (http://technet.microsoft.com/en-us/library/ms187373.aspx) to override the default behavior of the SELECT statement
--
-- TABLOCKX specifies an EXCLUSIVE LOCK on the TABLE, yes that's right I locked the whole table for the purpose of this demonstration
--
-- HOLDLOCK is the same as SERIALIZABLE and it makes the transaction hold the share locks until it is completed
--
-- It is really bad to also do a SELECT *....bad for network performance if you have a large amount of columns and only need a few, bad for indexing and query plan performance when you only need to see a few columns
--

