-- =================================================
-- Author:		Watson...Ed Watson	
-- Create date: GETDATE()
-- Description:	Run this in a few different sessions
--				to generate some blocking
-- =================================================

USE [AdventureWorks2012];
GO


-- Pass in how many records you want to create.
EXEC [dbo].[USP_SlowFile] '2000000'
GO