SELECT CONVERT(char(8), s.[PerfDate], 108) as PerfTime
      ,s.[ServerNm]
      ,i.[InstanceNm]
      ,s.[PctProc]
      ,s.[Memory]
      ,s.[PgFilUse]
      ,s.[DskRdsSec]
      ,s.[DskWrtSec]
      ,s.[ProcQueLn]
      ,i.[FwdRecSec]
      ,i.[PgSpltSec]
      ,i.[BufCchHit]
      ,i.[PgLifeExp]
      ,i.[LogGrwths]
      ,i.[BlkProcs]
      ,i.[BatReqSec]
      ,i.[SQLCompSec]
      ,i.[SQLRcmpSec]
FROM [ServerAnalysis].[Analysis].[ServerStats] s
INNER JOIN [ServerAnalysis].[Analysis].[InstanceStats] i
ON s.[ServerID] = i.[ServerID]
WHERE i.[InstanceNm] = 'INST01'
AND s.[PerfDate] > DATEADD(mi, -60, GETDATE())