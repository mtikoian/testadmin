#simwork.ps1
#Simulate a workload against SQL Server AdventureWorks

function workload {
	$cn = new-object system.data.SqlClient.SqlConnection("Data Source=SQLTBWS\INST01;Integrated Security=SSPI;Initial Catalog=AdventureWorks");
	$cn.Open()
	$q = " SELECT  d.SalesOrderID,"
	$q = $q + "         d.OrderQty,"
	$q = $q + "         h.OrderDate,"
	$q = $q + "         o.Description,"
	$q = $q + "         o.StartDate,"
	$q = $q + "         o.EndDate"
	$q = $q + " FROM    Sales.SalesOrderDetail d"
	$q = $q + "         INNER JOIN Sales.SalesOrderHeader h ON d.SalesOrderID = h.SalesOrderID"
	$q = $q + "         INNER JOIN Sales.SpecialOffer o ON d.SpecialOfferID = o.SpecialOfferID"
	$q = $q + " WHERE   d.SpecialOfferID <> 1"
	$ds = new-object "System.Data.DataSet" "dsConfigData"
	$da = new-object "System.Data.SqlClient.SqlDataAdapter" ($q, $cn)
	$da.SelectCommand.CommandTimeout = 0
	$da.Fill($ds) | out-null
	$cn.Close()

	$cn = new-object system.data.SqlClient.SqlConnection("Data Source=SQLTBWS\INST01;Integrated Security=SSPI;Initial Catalog=AdventureWorks");
	$cn.Open()
	$q = " SELECT TOP 5"
	$q = $q + "         sp.Name,"
	$q = $q + "         st.TaxRate"
	$q = $q + " FROM    Sales.SalesTaxRate st"
	$q = $q + "         JOIN Person.StateProvince sp ON st.StateProvinceID = sp.StateProvinceID"
	$q = $q + " WHERE   sp.CountryRegionCode = 'US'"
	$q = $q + " ORDER BY st.TaxRate desc ;"
	$ds = new-object "System.Data.DataSet" "dsConfigData"
	$da = new-object "System.Data.SqlClient.SqlDataAdapter" ($q, $cn)
	$da.SelectCommand.CommandTimeout = 0
	$da.Fill($ds) | out-null
	$cn.Close()

	$cn = new-object system.data.SqlClient.SqlConnection("Data Source=SQLTBWS\INST01;Integrated Security=SSPI;Initial Catalog=AdventureWorks");
	$cn.Open()
	$q = " EXECUTE dbo.uspGetEmployeeManagers 1"
	$ds = new-object "System.Data.DataSet" "dsConfigData"
	$da = new-object "System.Data.SqlClient.SqlDataAdapter" ($q, $cn)
	$da.SelectCommand.CommandTimeout = 0
	$da.Fill($ds) | out-null
	$cn.Close()

	$cn = new-object system.data.SqlClient.SqlConnection("Data Source=SQLTBWS\INST01;Integrated Security=SSPI;Initial Catalog=AdventureWorks");
	$cn.Open()
	$q = " SELECT  h.SalesOrderID,"
	$q = $q + "         h.OrderDate,"
	$q = $q + "         h.SubTotal,"
	$q = $q + "         p.SalesQuota"
	$q = $q + " FROM    Sales.SalesPerson p"
	$q = $q + "         INNER JOIN Sales.SalesOrderHeader h ON p.SalesPersonID = h.SalesPersonID ;"
	$ds = new-object "System.Data.DataSet" "dsConfigData"
	$da = new-object "System.Data.SqlClient.SqlDataAdapter" ($q, $cn)
	$da.SelectCommand.CommandTimeout = 0
	$da.Fill($ds) | out-null
	$cn.Close()

	$cn = new-object system.data.SqlClient.SqlConnection("Data Source=SQLTBWS\INST01;Integrated Security=SSPI;Initial Catalog=AdventureWorks");
	$cn.Open()
	$q = " SELECT p.[ContactID]"
	$q = $q + "       ,p.[FirstName]"
	$q = $q + "       ,p.[LastName]"
	$q = $q + "       ,a.[AddressLine1]"
	$q = $q + "       ,a.[AddressLine2]"
	$q = $q + "       ,a.[City]"
	$q = $q + "       ,s.[StateProvinceCode]"
	$q = $q + "       ,s.[CountryRegionCode]"
	$q = $q + "       ,a.[PostalCode]"
	$q = $q + "   FROM [Person].[Contact] p"
	$q = $q + "   INNER JOIN [Sales].[CustomerAddress] ca"
	$q = $q + "   ON p.[ContactID] = ca.[CustomerID]"
	$q = $q + "   INNER JOIN [Person].[Address] a"
	$q = $q + "   ON ca.[AddressID] = a.[AddressID]"
	$q = $q + "   INNER JOIN [Person].[StateProvince] s"
	$q = $q + "   ON a.[StateProvinceID] = s.[StateProvinceID]"
	$ds = new-object "System.Data.DataSet" "dsConfigData"
	$da = new-object "System.Data.SqlClient.SqlDataAdapter" ($q, $cn)
	$da.SelectCommand.CommandTimeout = 0
	$da.Fill($ds) | out-null
	$cn.Close()

	$cn = new-object system.data.SqlClient.SqlConnection("Data Source=SQLTBWS\INST01;Integrated Security=SSPI;Initial Catalog=AdventureWorks");
	$cn.Open()
	$q = " SELECT  Name,"
	$q = $q + "         ProductNumber,"
	$q = $q + "         ListPrice AS Price"
	$q = $q + " FROM    Production.Product"
	$q = $q + " WHERE   ProductLine = 'R'"
	$q = $q + "         AND DaysToManufacture < 4"
	$q = $q + " ORDER BY Name ASC ;"
	$ds = new-object "System.Data.DataSet" "dsConfigData"
	$da = new-object "System.Data.SqlClient.SqlDataAdapter" ($q, $cn)
	$da.SelectCommand.CommandTimeout = 0
	$da.Fill($ds) | out-null
	$cn.Close()

	$cn = new-object system.data.SqlClient.SqlConnection("Data Source=SQLTBWS\INST01;Integrated Security=SSPI;Initial Catalog=AdventureWorks");
	$cn.Open()
	$q = " WITH HiringTrendCTE(TheYear, TotalHired)"
	$q = $q + " AS"
	$q = $q + "  (SELECT YEAR(e.HireDate), COUNT(e.EmployeeID) "
	$q = $q + "   FROM HumanResources.Employee AS e"
	$q = $q + "   GROUP BY YEAR(e.HireDate)"
	$q = $q + "   )"
	$q = $q + " SELECT thisYear.*, prevYear.TotalHired AS HiredPrevYear, "
	$q = $q + "  (thisYear.TotalHired - prevYear.TotalHired) AS Diff,"
	$q = $q + "  ((thisYear.TotalHired - prevYear.TotalHired) * 100) / "
	$q = $q + "               prevYear.TotalHired AS DiffPerc"
	$q = $q + " FROM HiringTrendCTE AS thisYear "
	$q = $q + "    LEFT OUTER JOIN "
	$q = $q + "      HiringTrendCTE AS prevYear"
	$q = $q + " ON thisYear.TheYear =  prevYear.TheYear + 1;"
	$ds = new-object "System.Data.DataSet" "dsConfigData"
	$da = new-object "System.Data.SqlClient.SqlDataAdapter" ($q, $cn)
	$da.SelectCommand.CommandTimeout = 0
	$da.Fill($ds) | out-null
	$cn.Close()

	$cn = new-object system.data.SqlClient.SqlConnection("Data Source=SQLTBWS\INST01;Integrated Security=SSPI;Initial Catalog=AdventureWorks");
	$cn.Open()
	$q = " WITH MgrHierarchyCTE(EmployeeID, EmployeeName, ManagerID)"
	$q = $q + " AS"
	$q = $q + " ( SELECT e.EmployeeID, c.FirstName + ' ' + c.LastName, "
	$q = $q + "          e.ManagerID"
	$q = $q + "   FROM HumanResources.Employee AS e"
	$q = $q + "        JOIN Person.Contact AS c"
	$q = $q + "        ON c.ContactID = e.ContactID"
	$q = $q + "   WHERE e.EmployeeID = 111"
	$q = $q + " "
	$q = $q + "   UNION ALL"
	$q = $q + " "
	$q = $q + "   SELECT mgr.EmployeeID, co.FirstName + ' ' + co.LastName, "
	$q = $q + "          mgr.ManagerID"
	$q = $q + "   FROM HumanResources.Employee AS mgr"
	$q = $q + "        JOIN Person.Contact AS co"
	$q = $q + "        ON co.ContactID = mgr.ContactID"
	$q = $q + "        JOIN MgrHierarchyCTE AS cte"
	$q = $q + "        ON cte.ManagerID = mgr.EmployeeID  "
	$q = $q + " )"
	$q = $q + " SELECT * FROM MgrHierarchyCTE;"
	$ds = new-object "System.Data.DataSet" "dsConfigData"
	$da = new-object "System.Data.SqlClient.SqlDataAdapter" ($q, $cn)
	$da.SelectCommand.CommandTimeout = 0
	$da.Fill($ds) | out-null
	$cn.Close()
}

for ($i=1; $i++; $i -lt 10000) {
	workload
	}
