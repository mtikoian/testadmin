/*
http://www.sqlteam.com/article/testing-with-profiler-custom-events-and-database-snapshots
*/

USE AdventureWorks
GO
/*
1. File>>New Trace
2. TSQL
3. Save to file vs Save to table
4. Enable Trace Stop Time
*/
--Execute a handful of times
Select top 5 * from Sales.Customer



--Create a stored procedure
Create procedure dbo.ProfilerTest
as
select 1

--Exec stored procedure
EXEC dbo.ProfilerTest

/*
Stop Trace
1. Check off SP:StmtCompleted & check off duration
2. Add database name as column filter
*/

/*Stop Trace
--User configurable events.

*/

--Create a stored procedure
ALTER PROCEDURE dbo.ProfilerTest
as
Declare @message nvarchar(1000)
select 1
set @message='Select 1 occured: ' + convert(varchar(30),GETDATE(),120)
EXEC sp_trace_generateevent @eventid=82, @userinfo=@message
Select 22
set @message='Select 2 occured: ' + convert(varchar(30),GETDATE(),120)
EXEC sp_trace_generateevent @eventid=83, @userinfo=@message
GO

--GO TO Event SELECTION
--Enable user configurable 0 & 1


--Example Saving To Table
/*
1. File >>Save to table
2. Query for average run time
*/
select * from testing
--Show what's in trace table
select * from mytrace

--Won't run because textdata is ntext data
select * from mytrace where textdata='EXEC dbo.ProfilerTest'
GO

--Convert the text data to varchar(max)
select Min(DURATION) as MINVal,Max(DURATION) as MAXVal,AVG(DURATION) as AVGDuration
			from mytrace where cast(textdata as varchar(max)) LIKE 'SELECT%'
GO

