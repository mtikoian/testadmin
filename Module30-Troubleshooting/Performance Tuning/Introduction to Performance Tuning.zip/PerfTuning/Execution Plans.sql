USE AdventureWorks
GO

--Look at plan for select statement no indexes. Turn on execution plan. (CTRL-K)
Select Lastname, Firstname, phone from Person.Contact where lastname ='Peterson'
Select Lastname, Firstname, phone from Person.Contact where firstname ='Kim'

sp_helpindex N'[Person].[Contact]'

--
	--For example, Yes/No, Male/Female

	--if it is added after the non clustered indexes should be rebuilt
Create index ix_firstname on Person.Contact(firstname)


--Rerun the query Notice that now the first line is 93% of the work bottom has dropped to 7%
Select Lastname, Firstname, phone from Person.Contact where lastname ='Peterson'
--Now shows an index seek and a RID look up. 
--This means it finds the row id in the index and then has to go to the table to retrieve the lastname and phone columns.
Select Lastname, Firstname, phone from Person.Contact where firstname ='Kim'

--So how can we speed it up. Add a covering index.
-- In this example, Lastname and phone.
--Use the include statement. The key colum is firstname, but the leaf contains the values for lastname and phone so no table access required.
Drop index Person.Contact.ix_firstname
GO
Create index ix_firstname on Person.Contact(firstname) INCLUDE (lastname, phone)
GO


--Rerun the query Notice that now the first line is 98% of the work bottom has dropped to 2%
Select Lastname, Firstname, phone from Person.Contact where lastname ='Peterson'
--Now shows an index seek only because all rows were found in the index.
Select Lastname, Firstname, phone from Person.Contact where firstname ='Kim'


--Now lets look at the same setup but this time we'll make it a clustered index.
Drop index Person.Contact.ix_firstname
GO
Create clustered index ixc_firstname on Person.Contact(firstname)

--Rerun our test queries.

--Now, 99% of the load is in the first query and only 1% is in the 2nd query. 
--Also notice that the first query is doing a clustered index SCAN as opposed to a SEEK in the bottom query.
--What we can take away from this is that the covering index acts like a "mini" clustered index.
Select Lastname, Firstname, phone from Person.Contact where lastname ='Peterson'
Select Lastname, Firstname, phone from Person.Contact where firstname ='Kim'
GO

--Now lets fix the top query 
	--Notice that now we have an index seek and a key lookup
	--Remember earlier we said that the non clustered index contains the keys of the clustered index
		--Here we see that it grabbed the keys for the matching lastnames and then went to the clustered index to get it's data because it's data
			--is satisfied by the clustered index.
Create index ix_lastname on Person.Contact(lastname)
GO
Select Lastname, Firstname, phone from Person.Contact where lastname ='Peterson'
Select Lastname, Firstname, phone from Person.Contact where firstname ='Kim'
GO

--Clearing up a myth that I see in some tables
--to see the indexes on a table you can use sp_helpindex
sp_helpindex N'Person.Contact'
GO
Drop index Person.Contact.ix_lastname
GO
Drop index Person.Contact.ixc_firstname
GO
Create clustered index ixc_firstname on Person.Contact(firstname)
GO
Create index ix_firstname on Person.Contact(firstname)
GO
--Notice here that the clustered index is the only one used. Adding a 2nd index is redundent, slows inserts and takes up space.
--Do not duplicate indexes.
Select Lastname, Firstname, phone from Person.Contact where firstname ='Kim'

--How can we tell if the index was used or not? It doesn't appear in index usage stats
Select us.*,OBJECT_NAME(i.[OBJECT_ID]) from sys.dm_db_index_usage_stats us
	INNER JOIN sys.indexes i 
	ON us.index_id=i.index_id
where object_name(i.[object_id])='Person.Contact'

--Clean up again
Drop index Person.Contact.ixc_firstname
Drop index Person.Contact.ix_firstname
Drop index Person.Contact.ix_lastname
GO
sp_helpindex N'[Person].[Contact]'


--Demo saving execution plan
