http://dev.digi-corp.com/2009/05/temporary-tables-vs-table-variables-in-sql-server/
http://www.sqlservercentral.com/articles/Table+Variables/63878/


--Temp tables

--Example: Statistics(set show exec plan on)
--Notice that est # rows is 1
Declare @tempvar as Table(firstname varchar(100))
	INSERT INTO @tempvar 
	select firstname from person.contact

select top 500 * from @tempvar

--Same query with a temp table. Notice est rows is now 500
--drop table #tempvar
Create table #tempvar(firstname varchar(100))
INSERT into #tempvar(firstname)
	select firstname from person.contact
SELECT TOP 500 * FROM #tempvar
DROP TABLE #TEMPVAR


/*
Example 2: Transactions
Even though the insert into the variable was done inside the transaction
It does not participate in the transaction or the rollback.
*/
DECLARE @MsgInfo as table(Msg varchar(1000))
Create Table #MsgInfo(Msg varchar(1000))

Begin Transaction
BEGIN TRY
	Insert into @MsgInfo(Msg) values('About to update firstnames of A in table var')
	Insert into #MsgInfo(Msg) values('About to update firstnames of A in temp table')
	UPDATE CONTACT
		SET FirstName='B.' 
		WHERE FirstName='A.'
		RAISERROR('ERROR RAISED',16,1)
		
	END TRY
	BEGIN CATCH
		ROLLBACK Transaction
		SELECT * FROM @MsgInfo
		SELECT * FROM #MsgInfo
	END CATCH
Drop table #MsgInfo




--Example Storage:
CREATE TABLE #TEMP
(
COL1 INT,
COL2 VARCHAR(30),
COL3 DATETIME DEFAULT GETDATE()
)


GO

--Check to see if table exists in tempdb
USE TEMPDB
GO
select * FROM information_schema.tables
WHERE table_name like '%TEMP%'
USE SQLMonday
GO


--Now load up some data & go look at sys.partitions
INSERT INTO #TEMP(COL1, COL2) VALUES(1,'Decipher');
INSERT INTO #TEMP(COL1, COL2) VALUES(2,'Information')
INSERT INTO #TEMP(COL1, COL2) VALUES(3,'systems');
GO

USE TEMPDB
GO
select * from sys.partitions
	where object_name(object_id) like '%Temp%'
USE SQLMonday
GO

--Clean up
DROP TABLE #TEMP

--The myth that temp variables are all in memory
USE TEMPDB
GO
CREATE TABLE #TempTable (TT_Col1 INT)

DECLARE @TableVariable TABLE (TV_Col1 INT)
--Some information about the temp variable is recorded
SELECT TOP 2 *
FROM tempdb.sys.objects
ORDER BY create_date DESC

--But not as much as with a temp table.
select Object_name(object_id),rows 
	from tempdb.sys.partitions
	where object_name(object_id) like '%Temp%'
DROP TABLE #TempTable
GO