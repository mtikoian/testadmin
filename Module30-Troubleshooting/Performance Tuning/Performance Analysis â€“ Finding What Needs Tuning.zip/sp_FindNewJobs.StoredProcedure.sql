USE DBA
GO
IF EXISTS (SELECT 1 FROM sys.procedures WHERE SCHEMA_NAME(schema_id) = 'dbo' AND name = 'sp_FindNewJobs')
BEGIN
    DROP PROCEDURE dbo.sp_FindNewJobs
END
GO

CREATE PROCEDURE dbo.sp_FindNewJobs @jobname    SYSNAME
AS
DECLARE @message        VARCHAR(2000),
        @subject        VARCHAR(2000),
        @recipients     VARCHAR(1000),
        @cc             VARCHAR(1000),
        @now            DATETIME,
        @newjobs        INT,
        @defaultadmin   VARCHAR(200),
        @defaultmail    VARCHAR(200),
        @defaultprofile VARCHAR(50)

SET @now = GETDATE()
SET @newjobs = 0
SET @defaultadmin = 'DBA@mycompany.com'

--Account for job notifications with custom names such as job step failures within a job
IF NOT EXISTS (SELECT 1 FROM dbo.JobNotifications WHERE JobName = @jobname)
BEGIN
    INSERT INTO dbo.JobNotifications
    (JobName, Threshold, FailMailTo, DateJobAdded)
    VALUES(@jobname, 15, @defaultmail, @now)

    SET @newjobs = @newjobs + @@ROWCOUNT
END    

--Populate table with existing list of jobs and notify of new jobs.
INSERT INTO dbo.JobNotifications
(JobName, Threshold, FailMailTo, DateJobAdded)
SELECT name, 15, @defaultmail, @now
FROM msdb.dbo.sysjobs
WHERE name NOT IN (SELECT JobName FROM dbo.JobNotifications)

SET @newjobs = @newjobs + @@ROWCOUNT

IF @newjobs > 0
BEGIN
    SET @subject = 'Jobs added or modified on Instance: ' + CONVERT(VARCHAR(200), @@SERVERNAME)
    SET @message = 'Jobs have been added or modified since the last notification on Instance: ' + CONVERT(VARCHAR(200), @@SERVERNAME)
            
    EXEC msdb.dbo.sp_send_dbmail @recipients = @defaultadmin, 
        @profile_name = @defaultprofile, 
        @importance = 'HIGH', 
        @subject = @subject, 
        @body = @message
END
GO