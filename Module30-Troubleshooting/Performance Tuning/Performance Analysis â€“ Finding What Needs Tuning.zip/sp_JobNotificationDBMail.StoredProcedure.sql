USE DBA
GO
IF EXISTS (SELECT 1 FROM sys.procedures WHERE SCHEMA_NAME(schema_id) = 'dbo' AND name = 'spJobNotificationDBMail')
BEGIN
    DROP PROCEDURE dbo.spJobNotificationDBMail
END
GO

CREATE PROCEDURE dbo.spJobNotificationDBMail @jobname    SYSNAME
AS
DECLARE @message        VARCHAR(2000),
        @subject        VARCHAR(2000),
        @recipients     VARCHAR(1000),
        @cc             VARCHAR(1000),
        @now            DATETIME,
        @defaultprofile VARCHAR(50)

SET @now = GETDATE()

EXEC dbo.sp_FindNewJobs @jobname

IF EXISTS (SELECT 1 FROM dbo.JobNotifications WHERE JobName = @jobname 
        AND (LastMessageDate IS NULL OR  DATEADD(mi, Threshold, LastMessageDate) <= @now))
BEGIN        
    SET @message = 'Notification of unsuccessful job completion of ' + @jobname + ' on Instance: ' + CONVERT(VARCHAR(200), @@SERVERNAME)
    SET @subject = 'Job Failed - ' + @jobname + ' on Instance: ' + CONVERT(VARCHAR(200), @@SERVERNAME)
    
    SELECT @recipients = FailMailTo, @cc = FailMailCC
    FROM dbo.JobNotifications
    WHERE JobName = @jobname

    EXEC msdb.dbo.sp_send_dbmail @recipients = @recipients, 
        @copy_recipients = @cc,
        @profile_name = @defaultprofile, 
        @importance = 'HIGH', 
        @subject = @subject, 
        @body = @message
	    
	UPDATE dbo.JobNotifications
	SET LastMessageDate = @now
	WHERE JobName = @jobname
END	
GO


