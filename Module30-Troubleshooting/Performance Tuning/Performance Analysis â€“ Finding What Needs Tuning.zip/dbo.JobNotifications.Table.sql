USE DBA
GO
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE SCHEMA_NAME(schema_id) = 'dbo' AND name = 'JobNotifications')
BEGIN
	CREATE TABLE dbo.JobNotifications
	(JobName        SYSNAME         NOT NULL,
	LastMessageDate DATETIME        NULL,
	Threshold       TINYINT         NOT NULL,
	FailMailTo      VARCHAR(1000)   NOT NULL,
	FailMailCC      VARCHAR(1000)   NULL,
	DateJobAdded    DATETIME        NOT NULL)
END
GO