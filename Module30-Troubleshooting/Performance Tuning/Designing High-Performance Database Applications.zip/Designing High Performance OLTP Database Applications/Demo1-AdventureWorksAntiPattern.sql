USE AdventureWorks2012; 
-- or similar AdventureWorks database from http://msftdbprodsamples.codeplex.com/releases/view/93587
GO

--drop out-of-the-box constraints
ALTER TABLE [Sales].[SalesOrderDetail]  
	DROP CONSTRAINT [FK_SalesOrderDetail_SalesOrderHeader_SalesOrderID];

ALTER TABLE [Sales].[SalesOrderDetail]
	DROP CONSTRAINT [PK_SalesOrderDetail_SalesOrderID_SalesOrderDetailID];
--create a clustered primary key on SalesOrderDetailID IDENTITY column alone
ALTER TABLE [Sales].[SalesOrderDetail]
	ADD  CONSTRAINT [PK_SalesOrderDetail_SalesOrderID_SalesOrderDetailID] PRIMARY KEY CLUSTERED 
	(
		[SalesOrderDetailID] ASC
	) ON [PRIMARY];

--recreate foreign key
ALTER TABLE [Sales].[SalesOrderDetail]  
	ADD  CONSTRAINT [FK_SalesOrderDetail_SalesOrderHeader_SalesOrderID] FOREIGN KEY([SalesOrderID])
	REFERENCES [Sales].[SalesOrderHeader] ([SalesOrderID])
	ON DELETE CASCADE
GO

--show execution plan
--scan is required because foreign key is no longer indexed (high-order column of composite primary key)
SELECT
	soh.SalesOrderID
	, soh.SalesPersonID
	, soh.OrderDate
	, soh.AccountNumber
	, sod.ProductID
	, sod.LineTotal
FROM Sales.SalesOrderHeader AS soh
JOIN Sales.SalesOrderDetail AS sod ON
	sod.SalesOrderID = soh.SalesOrderID
WHERE soh.SalesOrderID =  43659;
GO

--create non-clustered index on SalesOrderID foreign key to avoid scan
CREATE INDEX idx_SalesOrderDetail ON Sales.SalesOrderDetail(SalesOrderID);
GO

--show execution plan
--note that we now have a seek, but introduced a key lookup
SELECT
	soh.SalesOrderID
	, soh.SalesPersonID
	, soh.OrderDate
	, soh.AccountNumber
	, sod.ProductID
	, sod.LineTotal
FROM Sales.SalesOrderHeader AS soh
JOIN Sales.SalesOrderDetail AS sod ON
	sod.SalesOrderID = soh.SalesOrderID
WHERE soh.SalesOrderID =  43659;
GO

--recreate orignal out-of-the-box AdventureWorksSales.SalesOrderDetail constraints and indexes
--drop demo constraints and index
DROP INDEX Sales.SalesOrderDetail.idx_SalesOrderDetail;
ALTER TABLE [Sales].[SalesOrderDetail]  
	DROP CONSTRAINT [FK_SalesOrderDetail_SalesOrderHeader_SalesOrderID];
ALTER TABLE [Sales].[SalesOrderDetail]
	DROP CONSTRAINT [PK_SalesOrderDetail_SalesOrderID_SalesOrderDetailID];
ALTER TABLE [Sales].[SalesOrderDetail]
	ADD  CONSTRAINT [PK_SalesOrderDetail_SalesOrderID_SalesOrderDetailID] PRIMARY KEY CLUSTERED 
	(
		[SalesOrderID]
		,[SalesOrderDetailID] ASC
	) ON [PRIMARY];
ALTER TABLE [Sales].[SalesOrderDetail]  
	ADD  CONSTRAINT [FK_SalesOrderDetail_SalesOrderHeader_SalesOrderID] FOREIGN KEY([SalesOrderID])
	REFERENCES [Sales].[SalesOrderHeader] ([SalesOrderID])
	ON DELETE CASCADE
GO

--show execution plan
--more efficient execution plan with custered index seek on both tables
--related SalesOrders are stored together in SalesOrderDetail table (less logical I/O)
--composite primary key here avoids need for separate index on foreign key (less maintenance)
composite primary key is directly related incremental, 
SELECT
	soh.SalesOrderID
	, soh.SalesPersonID
	, soh.OrderDate
	, soh.AccountNumber
	, sod.ProductID
	, sod.LineTotal
FROM Sales.SalesOrderHeader AS soh
JOIN Sales.SalesOrderDetail AS sod ON
	sod.SalesOrderID = soh.SalesOrderID
WHERE soh.SalesOrderID =  43659;
GO
