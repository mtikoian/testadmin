-- CACYK (1)
-- ERNTC (591)
DBCC FREEPROCCACHE
EXEC TestParameterSniffingVar 'ERNTC'
EXEC TestParameterSniffingVar 'CACYK'
GO

DBCC FREEPROCCACHE
EXEC TestParameterSniffingVar 'CACYK'
EXEC TestParameterSniffingVar 'ERNTC'
GO