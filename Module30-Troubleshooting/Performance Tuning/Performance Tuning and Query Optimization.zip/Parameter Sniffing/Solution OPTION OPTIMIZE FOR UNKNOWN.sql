IF OBJECT_ID(N'TestParameterSniffingOptUnknown', N'P') IS NOT NULL 
DROP PROCEDURE TestParameterSniffingOptUnknown;
GO

CREATE PROCEDURE TestParameterSniffingOptUnknown
 @customerid NCHAR(5)
AS
BEGIN

    DBCC DROPCLEANBUFFERS
	DECLARE @start_time DATETIME
    DECLARE @total_time INT

    SET @start_time = CURRENT_TIMESTAMP;

	SELECT orderid, customerid, orderdate, shippeddate
    FROM Orders
    WHERE customerid = @customerid
    OPTION (OPTIMIZE FOR UNKNOWN);

    SET @total_time = DATEDIFF(ms, @start_time, CURRENT_TIMESTAMP);

    SELECT 'Total run time (ms): ' + CAST(@total_time AS VARCHAR(30));

END

GO


-- CACYK (1)
-- ERNTC (591)
DBCC FREEPROCCACHE
-- Test selective
EXEC TestParameterSniffingRec 'CACYK'
-- Test non-selective
EXEC TestParameterSniffingRec 'ERNTC'
GO