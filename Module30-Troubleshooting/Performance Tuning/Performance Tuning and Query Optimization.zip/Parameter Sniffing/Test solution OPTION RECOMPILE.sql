-- CACYK (1)
-- ERNTC (591)
DBCC FREEPROCCACHE
EXEC TestParameterSniffingRec 'ERNTC'
EXEC TestParameterSniffingRec 'CACYK'
GO

DBCC FREEPROCCACHE
EXEC TestParameterSniffingRec 'CACYK'
EXEC TestParameterSniffingRec 'ERNTC'
GO