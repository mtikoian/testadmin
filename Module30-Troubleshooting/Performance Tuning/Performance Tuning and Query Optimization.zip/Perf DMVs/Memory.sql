-- Total amount of memory consumed (including AWE) by the buffer pool
SELECT  SUM(multi_pages_kb + 
            virtual_memory_committed_kb +
            shared_memory_committed_kb +
            awe_allocated_kb) AS 'Used by Buffer Pool (Kb)'
FROM sys.dm_os_memory_clerks
WHERE type = 'MEMORYCLERK_SQLBUFFERPOOL';

-- Identify internal components that are stealing the most pages from buffer pool
SELECT TOP(10) type, 
       SUM(single_pages_kb) AS stolen_mem_kb
FROM sys.dm_os_memory_clerks
GROUP BY type
ORDER BY SUM(single_pages_kb) DESC;

-- Identify the internal components that have allocated memory outside of buffer pool
SELECT type, 
       SUM(multi_pages_kb) AS memory_allocated_KB
FROM sys.dm_os_memory_clerks
WHERE multi_pages_kb != 0
GROUP BY type;
