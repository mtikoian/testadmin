-- Detect CPU pressure is by counting the number of workers in the RUNNABLE state

SELECT COUNT(*) AS workers_waiting_for_cpu, 
       S.scheduler_id
FROM sys.dm_os_workers AS W 
JOIN sys.dm_os_schedulers AS S
  ON W.scheduler_address = S.scheduler_address 
WHERE W.state = 'RUNNABLE' 
  AND S.scheduler_id < 255
GROUP BY S.scheduler_id;