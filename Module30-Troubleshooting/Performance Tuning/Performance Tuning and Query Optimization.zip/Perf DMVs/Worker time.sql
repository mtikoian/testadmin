-- Total worker time; queries taking most CPU
-- Helps identify inefficient query plan
SELECT TOP(10)
       total_worker_time/execution_count AS avg_cpu_cost,
       execution_count,
       query_text
FROM sys.dm_exec_query_stats AS Q
CROSS APPLY (SELECT SUBSTRING(text, statement_start_offset/2 + 1,
                    (CASE WHEN statement_end_offset = -1
                          THEN LEN(CONVERT(NVARCHAR(MAX), text)) * 2
                          ELSE statement_end_offset
                     END - statement_start_offset) / 2)
             FROM sys.dm_exec_sql_text(sql_handle)) AS S(query_text)
ORDER BY [avg_cpu_cost] DESC;

-- Most frequently executed queries
SELECT TOP(10) 
       total_worker_time, 
       plan_handle,execution_count,
      (SELECT SUBSTRING(text, statement_start_offset/2 + 1,
          (CASE WHEN statement_end_offset = -1
                  THEN LEN(CONVERT(NVARCHAR(MAX),text)) * 2
                  ELSE statement_end_offset
           END - statement_start_offset)/2)
       FROM sys.dm_exec_sql_text(sql_handle)) AS query_text
FROM sys.dm_exec_query_stats
ORDER BY execution_count DESC;



