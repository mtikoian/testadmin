-- Locks that have been granted or waited (similarly to the stored procedure sp_lock)
SELECT request_session_id AS spid, 
       resource_type,
       resource_database_id AS db,
      (CASE resource_type
            WHEN 'OBJECT' 
            THEN object_name(resource_associated_entity_id)
            WHEN 'DATABASE' 
            THEN ' '
            ELSE (SELECT object_name(object_id)
                  FROM sys.partitions
                  WHERE hobt_id=resource_associated_entity_id)
       END) AS objname,
       resource_description, 
       request_mode, 
       request_status
FROM sys.dm_tran_locks;

-- Duration of blocks and SQL statement being executed by the blocked transaction
SELECT L.resource_type,
       DB_NAME(resource_database_id) AS db,
       L.resource_associated_entity_id AS blk_object,
       L.request_mode, 
       L.request_session_id,
       T.blocking_session_id,
       T.wait_duration_ms,
      (SELECT SUBSTRING(text, R.statement_start_offset/2 + 1,
             (CASE WHEN R.statement_end_offset = -1
              THEN LEN(CONVERT(NVARCHAR(MAX),text)) * 2
              ELSE R.statement_end_offset
              END - R.statement_start_offset)/2)
       FROM sys.dm_exec_sql_text(sql_handle)) AS query_text,
       T.resource_description
FROM sys.dm_tran_locks AS L
JOIN sys.dm_os_waiting_tasks AS T
  ON L.lock_owner_address = T.resource_address
JOIN sys.dm_exec_requests AS R
  ON L.request_request_id = R.request_id
 AND T.session_id = R.session_id;