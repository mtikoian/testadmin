-- Identify missing indexes and their usefulness

SELECT D.object_id, 
       S.user_seeks, 
       S.user_scans,
       D.equality_columns, 
       D.inequality_columns
FROM sys.dm_db_missing_index_details AS D
JOIN sys.dm_db_missing_index_groups AS G
  ON D.index_handle = G.index_handle
JOIN sys.dm_db_missing_index_group_stats AS S
  ON G.index_group_handle = group_handle
WHERE database_id = DB_ID()
  AND object_id = OBJECT_ID('Customers');