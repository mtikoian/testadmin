-- I/O latch waits
SELECT wait_type, 
       waiting_tasks_count, 
       wait_time_ms, 
       signal_wait_time_ms
FROM sys.dm_os_wait_stats
WHERE wait_type LIKE 'PAGEIOLATCH%'
ORDER BY wait_type;


-- Top queries/batches generating the most I/Os
SELECT TOP(10)
      (total_logical_reads/execution_count) AS avg_logical_reads,
      (total_logical_writes/execution_count) AS avg_logical_writes,
      (total_physical_reads/execution_count) AS avg_phys_reads,
       execution_count,
       plan_handle, 
       query_text
FROM sys.dm_exec_query_stats AS Q
CROSS APPLY (SELECT SUBSTRING(text, statement_start_offset/2 + 1,
                   (CASE WHEN statement_end_offset = -1
                         THEN LEN(CONVERT(NVARCHAR(MAX),text)) * 2
                         ELSE statement_end_offset
                    END - statement_start_offset) / 2)
             FROM sys.dm_exec_sql_text(Q.sql_handle)) AS S(query_text)
ORDER BY (total_logical_reads + total_logical_writes) DESC;
