-- Return trace data with query signature
SELECT
  dbo.fn_SQLSigTSQL(tsql_code, 4000) AS sig,
  duration
FROM dbo.Workload;


SELECT
  dbo.fn_SQLSigTSQL(tsql_code, 4000) AS 'Query Signature',
  SUM(duration) AS Duration,
  CAST(SUM(duration/1000.) AS DECIMAL(12, 2)) AS 'Duration Seconds'
FROM dbo.Workload
GROUP BY dbo.fn_SQLSigTSQL(tsql_code, 4000)
ORDER BY Duration DESC;
