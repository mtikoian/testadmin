DECLARE @dbid INT
DECLARE @tracefile NVARCHAR(254)
DECLARE @traceid INT


-- Create a Queue
DECLARE @rc          AS INT;
DECLARE @maxfilesize AS BIGINT;

SET @maxfilesize = 5;
SET @tracefile = 'C:\Data\Projects\Docs\_Events\Performance\Work\server_side'
SET @dbid = DB_ID('Tuning')

EXEC @rc = sp_trace_create @traceid OUTPUT, 0, @tracefile, @maxfilesize, NULL 

-- Set the events
DECLARE @on AS BIT;
SET @on = 1;

EXEC sp_trace_setevent @traceid, 10, 15, @on;
EXEC sp_trace_setevent @traceid, 10, 8, @on;
EXEC sp_trace_setevent @traceid, 10, 16, @on;
EXEC sp_trace_setevent @traceid, 10, 48, @on;
EXEC sp_trace_setevent @traceid, 10, 1, @on;
EXEC sp_trace_setevent @traceid, 10, 17, @on;
EXEC sp_trace_setevent @traceid, 10, 10, @on;
EXEC sp_trace_setevent @traceid, 10, 18, @on;
EXEC sp_trace_setevent @traceid, 10, 11, @on;
EXEC sp_trace_setevent @traceid, 10, 12, @on;
EXEC sp_trace_setevent @traceid, 10, 13, @on;
EXEC sp_trace_setevent @traceid, 10, 14, @on;
EXEC sp_trace_setevent @traceid, 45, 8, @on;
EXEC sp_trace_setevent @traceid, 45, 16, @on;
EXEC sp_trace_setevent @traceid, 45, 48, @on;
EXEC sp_trace_setevent @traceid, 45, 1, @on;
EXEC sp_trace_setevent @traceid, 45, 17, @on;
EXEC sp_trace_setevent @traceid, 45, 10, @on;
EXEC sp_trace_setevent @traceid, 45, 18, @on;
EXEC sp_trace_setevent @traceid, 45, 11, @on;
EXEC sp_trace_setevent @traceid, 45, 12, @on;
EXEC sp_trace_setevent @traceid, 45, 13, @on;
EXEC sp_trace_setevent @traceid, 45, 14, @on;
EXEC sp_trace_setevent @traceid, 45, 15, @on;
EXEC sp_trace_setevent @traceid, 41, 15, @on;
EXEC sp_trace_setevent @traceid, 41, 8, @on;
EXEC sp_trace_setevent @traceid, 41, 16, @on;
EXEC sp_trace_setevent @traceid, 41, 48, @on;
EXEC sp_trace_setevent @traceid, 41, 1, @on;
EXEC sp_trace_setevent @traceid, 41, 17, @on;
EXEC sp_trace_setevent @traceid, 41, 10, @on;
EXEC sp_trace_setevent @traceid, 41, 18, @on;
EXEC sp_trace_setevent @traceid, 41, 11, @on;
EXEC sp_trace_setevent @traceid, 41, 12, @on;
EXEC sp_trace_setevent @traceid, 41, 13, @on;
EXEC sp_trace_setevent @traceid, 41, 14, @on;

-- Set the Filters
DECLARE @intfilter AS INT;
DECLARE @bigintfilter AS BIGINT;

-- Application name filter
EXEC sp_trace_setfilter @traceid, 10, 0, 7, N'SQL Server Profiler%';
-- Database ID filter
EXEC sp_trace_setfilter @traceid, 3, 0, 0, @dbid;

-- Set the trace status to start
EXEC sp_trace_setstatus @traceid, 1;

-- Wait one minute
WAITFOR DELAY '00:00:30'

-- Stop the trace and remove definition
EXEC sp_trace_setstatus @traceid, 0;
EXEC sp_trace_setstatus @traceid, 2;

-- Read trace
SELECT CAST(TextData AS NVARCHAR(MAX)) AS tsql_code,
       duration
FROM fn_trace_gettable('C:\Data\Projects\Docs\_Events\Performance\Work\server_side.trc', DEFAULT) AS T
WHERE duration IS NOT NULL;

-- Aggregate trace data by query
SELECT CAST(TextData AS NVARCHAR(MAX)) AS tsql_code,
       SUM(duration)
FROM fn_trace_gettable('C:\Data\Projects\Docs\_Events\Performance\Work\server_side.trc', DEFAULT) AS T
WHERE duration IS NOT NULL
GROUP BY CAST(TextData AS NVARCHAR(MAX));

-- Aggregate trace data by query prefix
SELECT SUBSTRING(CAST(TextData AS NVARCHAR(MAX)), 1, 100) AS tsql_code,
       SUM(duration) AS total_duration
FROM fn_trace_gettable('C:\Data\Projects\Docs\_Events\Performance\Work\server_side.trc', DEFAULT) AS T
WHERE duration IS NOT NULL
GROUP BY SUBSTRING(CAST(TextData AS NVARCHAR(MAX)), 1, 100);

