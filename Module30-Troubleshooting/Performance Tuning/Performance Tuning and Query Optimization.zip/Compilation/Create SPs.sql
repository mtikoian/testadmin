IF OBJECT_ID(N'TestCacheNoParameterization', N'P') IS NOT NULL 
DROP PROCEDURE TestCacheNoParameterization;
GO

CREATE PROCEDURE TestCacheNoParameterization
 @company NVARCHAR(40)
AS
BEGIN
  DECLARE @sql NVARCHAR(2000);

  SET @sql = 
N'SELECT CompanyName, ContactName, ContactTitle
  FROM Customers
  WHERE CompanyName = ''' + @company + '''';              

  EXEC(@sql);
END

GO

IF OBJECT_ID(N'TestCacheWithParameterization', N'P') IS NOT NULL 
DROP PROCEDURE TestCacheWithParameterization;
GO

CREATE PROCEDURE TestCachewithParameterization
 @company NVARCHAR(40)
AS
BEGIN
  
  DECLARE @sql NVARCHAR(2000);

  SET @sql = 
N'SELECT CompanyName, ContactName, ContactTitle
  FROM Customers
  WHERE CompanyName = @company_name';

  DECLARE @params NVARCHAR(50); 
 
  SET @params = N'@company_name NVARCHAR(40)';

  EXEC sp_executesql @sql, @params, @company; 
 
END

GO

