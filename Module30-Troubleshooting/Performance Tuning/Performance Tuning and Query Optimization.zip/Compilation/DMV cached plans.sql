-- Cached plans and SQL
SELECT usecounts,
       size_in_bytes,
       cacheobjtype,
       objtype,
       REPLACE(REPLACE([text], CHAR(13), ' '), CHAR(10), ' ') AS sql_text
FROM sys.dm_exec_cached_plans AS P
CROSS APPLY sys.dm_exec_sql_text(P.plan_handle) AS S;

-- Most frequently reused plans
SELECT TOP(10)
       usecounts,
       size_in_bytes,
       cacheobjtype,
       objtype,
       REPLACE(REPLACE([text], CHAR(13), ' '), CHAR(10), ' ') AS sql_text
FROM sys.dm_exec_cached_plans AS P
CROSS APPLY sys.dm_exec_sql_text(P.plan_handle) AS S
ORDER BY usecounts DESC;