-- Sample Queries
SET NOCOUNT ON;
USE Tuning;
GO
SELECT OrderID, CustomerID, EmployeeID, ShipVia, OrderDate
FROM dbo.Orders
WHERE OrderID = 10423;
GO
SELECT OrderID, CustomerID, EmployeeID, ShipVia, OrderDate
FROM dbo.Orders
WHERE OrderID = 10425;
GO
SELECT OrderID, CustomerID, EmployeeID, ShipVia, OrderDate
FROM dbo.Orders
WHERE OrderID = 10427;
GO
SELECT OrderID, CustomerID, EmployeeID, ShipVia, OrderDate
FROM dbo.Orders
WHERE OrderDate = '19960812';
GO
SELECT OrderID, CustomerID, EmployeeID, ShipVia, OrderDate
FROM dbo.Orders
WHERE OrderDate = '19960819';
GO
SELECT OrderID, CustomerID, EmployeeID, ShipVia, OrderDate
FROM dbo.Orders
WHERE OrderDate = '19960828';
GO
SELECT OrderID, CustomerID, EmployeeID, ShipVia, OrderDate
FROM dbo.Orders
WHERE OrderDate >= '19960801'
  AND OrderDate < '19960901';
GO
SELECT OrderID, CustomerID, EmployeeID, ShipVia, OrderDate
FROM dbo.Orders
WHERE OrderDate >= '19960601'
  AND OrderDate < '19960715';
GO
SELECT OrderID, CustomerID, EmployeeID, ShipVia, OrderDate
FROM dbo.Orders
WHERE OrderDate >= '19960901'
  AND OrderDate < '19970301';
GO
SELECT OrderID, CustomerID, EmployeeID, ShipVia, OrderDate
FROM dbo.Orders
WHERE OrderDate >= '19960701'
  AND OrderDate < '19961001';
GO