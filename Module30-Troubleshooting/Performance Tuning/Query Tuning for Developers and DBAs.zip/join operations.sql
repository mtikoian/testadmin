--Merge Join
SELECT states.[Name] FROM [Person].[Address] addy
INNER JOIN [Person].[StateProvince] states ON addy.StateProvinceID = states.StateProvinceID --<-- no predicate forcing merge of both tables

--Nested Loop - indexed outer
SELECT states.[Name] FROM [Person].[Address] addy
INNER JOIN [Person].[StateProvince] states ON addy.StateProvinceID = states.StateProvinceID --<-- this will return one value making it small
WHERE states.StateProvinceID = 1

--Hash Join using a left join
SELECT * FROM [Person].[Address] addy
LEFT JOIN [Person].[StateProvince] states ON addy.StateProvinceID = states.StateProvinceID --<-- this will return one value making it small
