/* reload DB from scratch
IF EXISTS (SELECT 1 FROM sys.databases WHERE [Name] = 'QTuner')
 BEGIN
	DROP DATABASE QTuner
 END
CREATE DATABASE [QTuner]
GO
ALTER DATABASE [QTuner] SET RECOVERY SIMPLE 
GO
USE QTuner
GO
CREATE TABLE [dbo].[TestIndexNow](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[bla1] [varchar](36) NULL,
	[bla2] [varchar](36) NULL,
	[bla3] [varchar](36) NULL,
	[SomeDate] [datetime] NULL
) ON [PRIMARY]
GO
DECLARE @looper BIGINT = 1

WHILE @looper <= 3000000
 BEGIN
  INSERT INTO dbo.TestIndexNow VALUES ('bla1 data ' + CAST(@looper AS varchar(10)),
										 'bla2 data ' + CAST(@looper AS varchar(10)),
										 'bla3 data ' + CAST(@looper AS varchar(10)),
										 GetDate())
 SET @looper += 1
 END
GO
BACKUP DATABASE QTuner TO DISK=N'C:\QTuner.bak'
GO
USE master
GO
RESTORE DATABASE QTuner FROM DISK=N'C:\QTuner.bak' WITH REPLACE
GO
USE QTuner
GO
SELECT COUNT(*) FROM dbo.TestIndexNow

End reload */

SET STATISTICS IO ON
--Table Scan.  Next query is impossible to improve based on no WHERE. Always try to limit returns with a WHERE.  Remember, even an index scan on the clustered index is a table scan
SELECT bla1, bla2 FROM dbo.TestIndexNow 

--Parallelism - how the CPUs on the physical server are used. Should be careful here. test to ensure it really helps. consider DBA involvement on server wide configurations.
SELECT bla1, bla2 FROM dbo.TestIndexNow 
WHERE bla1 LIKE '000D7%'

--No more Parallelism - but was it a problem??
SELECT bla1, bla2 FROM dbo.TestIndexNow 
WHERE bla1 LIKE '000D7%'
OPTION (MAXDOP 1)

--Seek in order to Seek, we need an index :)
CREATE NONCLUSTERED INDEX IDX_COVER_BLA_ASC ON dbo.TestIndexNow (bla1) INCLUDE (bla2)
GO

--base select on the column tht is now indexed
SELECT bla1, bla2 FROM dbo.TestIndexNow 
WHERE bla1 LIKE '000D7%'

--Sorting (consider sorting by use of ORDER BY in the application layer if it is not a consideration in what is returned. 
--sorting
SELECT bla1 FROM dbo.TestIndexNow
WHERE bla1 LIKE '000D7%'
ORDER BY bla2, bla1
--distinct sort
SELECT bla1 FROM dbo.TestIndexNow
WHERE bla1 LIKE '000D7%'
GROUP BY bla2, bla1

--TempDB usage from meory spills
SELECT * FROM sys.dm_io_virtual_file_stats(DB_ID('tempdb'), 1)
SELECT * FROM dbo.TestIndexNow
WHERE id > 999999
ORDER BY bla2, bla1
SELECT * FROM sys.dm_io_virtual_file_stats(DB_ID('tempdb'), 1)

--TempDB usage from meory spills
SELECT * FROM sys.dm_io_virtual_file_stats(DB_ID('tempdb'), 1)
SELECT * FROM dbo.TestIndexNow
WHERE id > 999999
SELECT * FROM sys.dm_io_virtual_file_stats(DB_ID('tempdb'), 1)


--Conversions CONVERT_IMPLICIT
SELECT bla1, bla2 FROM dbo.TestIndexNow 
WHERE bla1 = N'1'

--fixed by means of converting the parameter
SELECT bla1, bla2 FROM dbo.TestIndexNow 
WHERE bla1 = cast(N'1' as varchar(1))

--Sargable - functions never reside on the left side!!
--this is nonsargable
SELECT bla1, bla2 FROM dbo.TestIndexNow 
WHERE LEFT(bla1,1) = '0'
--replace this with a favorable query that can use the index better
SELECT bla1, bla2 FROM dbo.TestIndexNow 
WHERE bla1 LIKE '0%'

--RID KeyLookup - HEAP and best case without a clustered index is a nonclustered index seek still BETTER than HEAP RID LookUp
SELECT bla1, bla2, bla3 FROM dbo.TestIndexNow 
WHERE bla1 LIKE '000D7%'

--HEAP creating a clustered index to rid ourselves of RID
CREATE CLUSTERED INDEX IDX_KEY ON TestIndexNow (id)
GO

--KeyLookup still persists due to not covering the results
SELECT bla1, bla2, bla3 FROM dbo.TestIndexNow 
WHERE bla1 LIKE '000D7%'

--Create a Covering Index
CREATE INDEX IDX_COVER_BLA_ASC ON dbo.TestIndexNow (bla1) INCLUDE (bla2, bla3)
WITH (DROP_EXISTING = ON)
GO
--Test
SELECT bla1, bla2, bla3 FROM dbo.TestIndexNow 
WHERE bla1 LIKE '000D7%'

--drop all the indexes we created to show a common problem of overlapping indexes
drop index IDX_COVER_BLA_ASC on TestIndexNow
drop index IDX_KEY on TestIndexNow

CREATE INDEX IDX_COVER_BLA2_ASC ON dbo.TestIndexNow (bla1,bla2)
GO
CREATE INDEX IDX_COVER_BLA1_ASC ON dbo.TestIndexNow (bla1, bla3)
GO
--check the above queries to show that both get an index seek based on the two indexes we have.  
--Makes sense but can one index work for both and as a index seek oepration?  Yes!
SELECT bla2 FROM dbo.TestIndexNow WHERE bla1 = '000' 
SELECT bla3 FROM dbo.TestIndexNow WHERE bla1 = '000' 
/*
DROP INDEX IDX_COVER_BLA2_ASC ON dbo.TestIndexNow
DROP INDEX IDX_COVER_BLA1_ASC ON dbo.TestIndexNow

CREATE INDEX IDX_COVER_BLA_ASC ON dbo.TestIndexNow (bla1) INCLUDE (bla2,bla3)
GO
*/
--Now put the indexes back and go run the index analysis script by Jason Strate
