USE perfstats
GO

/*
select * 
from [dbo].[perf_counter_monitor_config]


select * from sys.dm_os_performance_counters where counter_name like '%compil%'
*/

DECLARE @INSTANCE varchar(255) 

SET @INSTANCE =  'MSSQL$' + CAST(SERVERPROPERTY ('InstanceName') as nvarchar(128)) + ':'

IF @INSTANCE IS NULL
	SET @INSTANCE = 'SQLServer:'

insert into [dbo].[perf_counter_monitor_config](object_name,counter_name,instance_name )
SELECT 
RTRIM(REPLACE(object_name,@INSTANCE,'')) as object_name,counter_name,instance_name 
FROM sys.dm_os_performance_counters pc
WHERE 
/*
 SELECT * 
 FROM sys.dm_os_performance_counters to see all available performance counters. 
 
 Add the ones you want to the where clause and run it. It will populate the config table.
  */
(
	(object_name like '%Wait Statistics%' and instance_name in ('Average wait time (ms)', 'Cumulative wait time (ms) per second')) OR
	(object_name like '%Buffer Manager%') and instance_name in ('Page reads/sec','Free list stalls/sec','Page writes/sec','Page life expectancy','') OR
	(object_name like '%Databases%')  and (counter_name like '%size%' or counter_name like '%Transactions/sec%') OR
	(object_name like '%Plan Cache%')  and (counter_name like '%Cache Hit%') OR
	(object_name like '%SQL Statistics%')  and (counter_name like '%SQL Compilations/sec%') OR
	(object_name like '%SQL Statistics%')  and (counter_name like '%SQL Re-Compilations/sec%') OR
	(object_name like '%SQL Statistics%')  and (counter_name like '%Batch Requests/sec%') OR
	(object_name like '%Access Methods%')  and (counter_name like '%Page splits/sec%') OR
	(object_name like '%Transactions%')  and (counter_name like '%Free Space%' or counter_name like 'Longest Transaction Running Time%' )

)


AND NOT EXISTS(
	SELECT * 
	FROM [dbo].[perf_counter_monitor_config] 
	WHERE RTRIM(object_name) = RTRIM(REPLACE(pc.object_name,@INSTANCE,'')) 
	AND RTRIM(counter_name) = RTRIM(pc.counter_name)
	AND ISNULL(instance_name,'') = ISNULL(pc.instance_name,'')
)
