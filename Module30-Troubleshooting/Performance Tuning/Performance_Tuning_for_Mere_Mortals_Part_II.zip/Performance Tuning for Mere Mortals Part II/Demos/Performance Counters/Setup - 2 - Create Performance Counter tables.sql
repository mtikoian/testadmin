
USE [PerfStats]
GO

/****** Object:  Table [dbo].[perf_counter_monitor_config]    Script Date: 5/12/2014 3:31:20 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[perf_counter_monitor_config]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[perf_counter_monitor_config](
	[counter_id] [int] IDENTITY(1,1) NOT NULL,
	[object_name] [nvarchar](128) NOT NULL,
	[counter_name] [nvarchar](128) NOT NULL,
	[instance_name] [nvarchar](128) NOT NULL,
 CONSTRAINT [PK_perf_counter_monitor_config] PRIMARY KEY CLUSTERED 
(
	[object_name] ASC,
	[counter_name] ASC,
	[instance_name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO


USE [PerfStats]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dm_os_performance_counters]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[dm_os_performance_counters](
	[counter_id] [int] IDENTITY(1,1) NOT NULL,
	[object_name] [nvarchar](128) NOT NULL,
	[counter_name] [nvarchar](128) NOT NULL,
	[instance_name] [nvarchar](128) NOT NULL,
	[cntr_value] [bigint] NULL,
	[cntr_type] [int] NULL,
	[capture_date] [datetime2](7) NOT NULL,
 CONSTRAINT [PK_dm_os_performance_counters] PRIMARY KEY CLUSTERED 
(
	[counter_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO

IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[DF_dm_os_performance_counters_capture_date]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[dm_os_performance_counters] ADD  CONSTRAINT [DF_dm_os_performance_counters_capture_date]  DEFAULT (getdate()) FOR [capture_date]
END

GO


