/*
	Adventure Works SPs_WITH RECOMPILE Workload.sql
	This script requires four stored procedures to be first created
	in a copy of the AdventureWorks 2012 OLTP database.	
*/

USE AdventureWorks2014;
EXECUTE demo.AddDiscountToSalesOrderDetail '3/01/2012', '06/01/2014 23:59:59'
GO
------
/*
USE AdventureWorks2012;
GO
EXECUTE [AnnualTop5SalesPersonByMonthlyPercent] @Year=2005;
GO
--
USE AdventureWorks2012;
GO
EXECUTE [AnnualTop5SalesPersonByMonthlyPercent] @Year=2006;
GO
--
USE AdventureWorks2012;
GO
EXECUTE [AnnualTop5SalesPersonByMonthlyPercent] @Year=2007;
GO
--
USE AdventureWorks2012;
GO
EXECUTE [AnnualTop5SalesPersonByMonthlyPercent] @Year=2008;
*/