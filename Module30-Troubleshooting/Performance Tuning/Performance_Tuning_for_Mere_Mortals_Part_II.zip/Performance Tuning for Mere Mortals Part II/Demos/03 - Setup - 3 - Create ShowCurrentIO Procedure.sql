USE [PerfStats]
GO

/****** Object:  StoredProcedure [dbo].[ShowCurrentIO]    Script Date: 8/15/2014 11:57:03 AM ******/
DROP PROCEDURE [dbo].[ShowCurrentIO]
GO

/****** Object:  StoredProcedure [dbo].[ShowCurrentIO]    Script Date: 8/15/2014 11:57:03 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


-- dbo.ShowCurrentIO 'SlowLogFile'
CREATE PROCEDURE [dbo].[ShowCurrentIO] (

@DBName sysname = NULL

)

AS


SELECT 
    --virtual file latency
	CASE 
		WHEN [num_of_reads] = 0 
			THEN 0 
		ELSE ([io_stall_read_ms]/[num_of_reads]) 
	END [ReadLatency],
	CASE 
		WHEN [io_stall_write_ms] = 0 
			THEN 0 
		ELSE ([io_stall_write_ms]/[num_of_writes]) 
	END [WriteLatency],
	CASE 
		WHEN ([num_of_reads] = 0 AND [num_of_writes] = 0)
             THEN 0 
		ELSE ([io_stall]/([num_of_reads] + [num_of_writes])) 
	END [Latency],
	--avg bytes per IOP
	CASE 
		WHEN [num_of_reads] = 0 
			THEN 0 
		ELSE ([num_of_bytes_read]/[num_of_reads]) 
	END [AvgBPerRead],
	CASE 
		WHEN [io_stall_write_ms] = 0 
			THEN 0 
		ELSE ([num_of_bytes_written]/[num_of_writes]) 
	END [AvgBPerWrite],
	CASE 
		WHEN ([num_of_reads] = 0 AND [num_of_writes] = 0)
			THEN 0 
		ELSE (([num_of_bytes_read] + [num_of_bytes_written])/([num_of_reads] + [num_of_writes])) 
	END [AvgBPerTransfer],
	LEFT([mf].[physical_name],2) [Drive],
	DB_NAME([vfs].[database_id]) [DB],
	[mf].[physical_name],
	[vfs].[database_id],
	[vfs].[file_id],
	[vfs].[sample_ms],
	[vfs].[num_of_reads],
	[vfs].[num_of_bytes_read],
	[vfs].[io_stall_read_ms],
	[vfs].[num_of_writes],
	[vfs].[num_of_bytes_written],
	[vfs].[io_stall_write_ms],
	[vfs].[io_stall],
	[vfs].[size_on_disk_bytes]/1024/1024. [size_on_disk_MB],
	[vfs].[file_handle]
FROM [sys].[dm_io_virtual_file_stats](NULL,NULL) AS vfs
JOIN [sys].[master_files] [mf] 
    ON [vfs].[database_id] = [mf].[database_id] 
    AND [vfs].[file_id] = [mf].[file_id]
WHERE DB_NAME([vfs].[database_id]) = @DBName OR @DBName IS NULL
ORDER BY [Latency] DESC;


--select * FROM [sys].[dm_io_virtual_file_stats](NULL,NULL)

-- Look at the Wait Stats 

--DBCC SQLPERF('sys.dm_os_wait_stats', CLEAR);
/*

SELECT * FROM [PerfStats].[dbo].[WaitStats] 
WHERE capture_date >= (
    select capture_date 
    from (
	   select top 20 capture_date, row_number() over (order by capture_date desc) as rn
	   from [PerfStats].[dbo].[WaitStats] 
	   group by capture_date
	   order by capture_date desc
	   ) a
	   where rn=10
    )
AND wait_type = 'WRITELOG'


*/
GO


