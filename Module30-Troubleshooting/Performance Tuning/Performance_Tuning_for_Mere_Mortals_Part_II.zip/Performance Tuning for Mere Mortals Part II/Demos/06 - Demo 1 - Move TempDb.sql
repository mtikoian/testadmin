

/** TO H: - SLOW

use master

go

Alter database tempdb modify file (name = tempdev, filename = 'H:\SQLServer\TempDb\tempdb.mdf')

go

Alter database tempdb modify file (name = templog, filename = 'H:\SQLServer\TempDb\templog.ldf')

go

/********** To C: - FAST
use master

go


Alter database tempdb modify file (name = tempdev, filename = 'C:\SQLServer\TempDb\tempdb.mdf')

go

Alter database tempdb modify file (name = templog, filename = 'C:\SQLServer\TempDb\templog.ldf')

go

*/
