


DBCC SQLPERF('sys.dm_os_wait_stats', CLEAR);
-- Start Collect Wait Stats Job

IF EXISTS(SELECT * FROM msdb.dbo.sysjobs WHERE name like 'Collect Wait Stats%' and enabled = 0)
EXEC msdb.dbo.sp_update_job
    @job_name = N'Collect Wait Stats-Stopped',
    @new_name = N'Collect Wait Stats-Running',
    @description = N'Start Collecting.',
    @enabled = 1 ;
GO



/**** Stop Collect Wait Stats Job ***/

IF EXISTS(SELECT * FROM msdb.dbo.sysjobs WHERE name like 'Collect Wait Stats%' and enabled = 1)
EXEC msdb.dbo.sp_update_job
    @job_name = N'Collect Wait Stats-Running',
    @new_name = N'Collect Wait Stats-Stopped',
    @description = N'Stop Collecting.',
    @enabled = 0 ;
GO