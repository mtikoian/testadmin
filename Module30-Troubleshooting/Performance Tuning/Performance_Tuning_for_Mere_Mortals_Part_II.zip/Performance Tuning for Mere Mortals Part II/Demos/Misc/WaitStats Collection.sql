USE PerfStats
GO

CREATE PROCEDURE dbo.WaitStatsCollection

AS

BEGIN;

    WITH Waits
    AS (SELECT wait_type, 
    wait_time_ms/(waiting_tasks_count*1.0) as avg_wait,

    CAST(wait_time_ms / 1000. AS DECIMAL(12, 2)) AS [wait_time_s],
	    CAST(100. * wait_time_ms / SUM(wait_time_ms) OVER () AS DECIMAL(12,2)) AS [pct],
	    ROW_NUMBER() OVER (ORDER BY wait_time_ms DESC) AS rn
	    FROM sys.dm_os_wait_stats WITH (NOLOCK)
	    WHERE waiting_tasks_count > 0
	    and wait_type NOT IN (N'CLR_SEMAPHORE', N'LAZYWRITER_SLEEP', N'RESOURCE_QUEUE',N'SLEEP_TASK',
							N'SLEEP_SYSTEMTASK', N'SQLTRACE_BUFFER_FLUSH', N'WAITFOR', N'LOGMGR_QUEUE',
							N'CHECKPOINT_QUEUE', N'REQUEST_FOR_DEADLOCK_SEARCH', N'XE_TIMER_EVENT',
							N'BROKER_TO_FLUSH', N'BROKER_TASK_STOP', N'CLR_MANUAL_EVENT', N'CLR_AUTO_EVENT',
							N'DISPATCHER_QUEUE_SEMAPHORE' ,N'FT_IFTS_SCHEDULER_IDLE_WAIT', N'XE_DISPATCHER_WAIT',
							N'XE_DISPATCHER_JOIN', N'SQLTRACE_INCREMENTAL_FLUSH_SLEEP', N'ONDEMAND_TASK_QUEUE',
							N'BROKER_EVENTHANDLER', N'SLEEP_BPOOL_FLUSH', N'SLEEP_DBSTARTUP', N'DIRTY_PAGE_POLL',
							N'HADR_FILESTREAM_IOMGR_IOCOMPLETION',N'SP_SERVER_DIAGNOSTICS_SLEEP',
							    N'QDS_PERSIST_TASK_MAIN_LOOP_SLEEP', N'QDS_CLEANUP_STALE_QUERIES_TASK_MAIN_LOOP_SLEEP',
							    N'WAIT_XTP_HOST_WAIT', N'WAIT_XTP_OFFLINE_CKPT_NEW_LOG', N'WAIT_XTP_CKPT_CLOSE',
							    N'PWAIT_ALL_COMPONENTS_INITIALIZED',N'XE_LIVE_TARGET_TVF')),
    Running_Waits 
    AS (
    SELECT W1.wait_type, wait_time_s, pct,avg_wait,
	    SUM(pct) OVER(ORDER BY pct DESC ROWS UNBOUNDED PRECEDING) AS [running_pct]
	    FROM Waits AS W1)

  --  INSERT INTO [dbo].[WaitStats] (wait_type, wait_time_s, avg_wait, pct, running_pct, capture_date)
    SELECT wait_type, wait_time_s, CAST(avg_wait as numeric(12,1)) as avg_wait, pct,  running_pct, getdate() as capture_date
    FROM Running_Waits
    WHERE running_pct - pct <= 99
    ORDER BY running_pct
    OPTION (RECOMPILE);

END

--DBCC SQLPERF('sys.dm_os_wait_stats', CLEAR);

/* WaitStats

--USE [PerfStats]
--GO

--/****** Object:  Table [dbo].[WaitStats]    Script Date: 8/5/2014 4:45:54 PM ******/
--DROP TABLE [dbo].[WaitStats]
--GO

--/****** Object:  Table [dbo].[WaitStats]    Script Date: 8/5/2014 4:45:54 PM ******/
--SET ANSI_NULLS ON
--GO

--SET QUOTED_IDENTIFIER ON
--GO

--CREATE TABLE [dbo].[WaitStats](
--	[ID] [int] IDENTITY(1,1) NOT NULL,
--	[wait_type] [nvarchar](60) NOT NULL,
--	[wait_time_s] [decimal](12, 2) NULL,
--	[avg_wait] [numeric](5, 1) NULL,
--	[pct] [decimal](12, 2) NULL,
--	[running_pct] [decimal](38, 2) NULL,
--	[capture_date] [datetime] NOT NULL,
-- CONSTRAINT [PK_WaitStats] PRIMARY KEY CLUSTERED 
--(
--	[capture_date] ASC,
--	[ID] ASC
--)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
--) ON [PRIMARY]

--GO



*/