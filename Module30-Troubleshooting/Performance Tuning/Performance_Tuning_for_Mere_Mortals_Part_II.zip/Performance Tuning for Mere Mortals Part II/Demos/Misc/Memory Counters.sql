

-- Memory Specific Counters
select *
from sys.dm_os_performance_counters
where 
    (object_name like 'SQLServer:Buffer Manager%'
	   and counter_name in ('Free list stalls/sec','Lazy writes/sec')) OR
    (object_name like 'SQLServer:Memory Node%'
	   and counter_name = 'Free Node Memory (KB)') OR
    (object_name like 'SQLServer:Buffer Node%'
	   and counter_name = 'Page life expectancy') OR
    (object_name like 'SQLServer:Memory Manager%'
	   and counter_name in ('Target Server Memory (KB)','Total Server Memory (KB)','Memory Grants Outstanding','Memory Grants Pending')) OR



    SELECT * FROM PerfStats.dbo.WaitStats WHERE capture_date = (select max(capture_date) from PerfStats.dbo.WaitStats)
    select * from sys.dm_os_wait_stats 

PerfStats.dbo.WaitStatsCollection

SELECT AVG(current_tasks_count) AS [Avg Current Task], 
AVG(runnable_tasks_count) AS [Avg Wait Task]
FROM sys.dm_os_schedulers
WHERE scheduler_id < 255
AND status = 'VISIBLE ONLINE'

