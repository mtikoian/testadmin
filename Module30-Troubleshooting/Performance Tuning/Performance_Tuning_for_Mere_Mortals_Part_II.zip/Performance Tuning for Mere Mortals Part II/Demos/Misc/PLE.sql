select *
from sys.dm_os_performance_counters
where object_name like 'SQLServer:Buffer Node%'
and counter_name = 'Page life expectancy'
