USE [AdventureWorks2014]
GO

IF EXISTS(select * from sys.procedures where name = 'AnnualTop5SalesPersonByMonthlyPercent_New')
DROP PROCEDURE [dbo].[AnnualTop5SalesPersonByMonthlyPercent_New]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/******************************************************************************************
    Author: Mike Lawell
    Date:	  Aug. 16, 2014

    Comments: REwrite Jonathan Kehayias' bad procedure to remove recompiles.

*******************************************************************************************/
CREATE PROCEDURE [dbo].[AnnualTop5SalesPersonByMonthlyPercent_New] (
    @Year int

)

AS

BEGIN;

    WITH cteMonthlyTotals (SalesPersonID, YearMonth, TotalDue)

    AS
    ( 
	    SELECT 
		  [SalesPersonID], 
		  (DATEPART(YEAR, [OrderDate])*100)+DATEPART(MONTH, [OrderDate]) as YearMonth, 
		  SUM([TotalDue]) as TotalDue
	    FROM [Sales].[SalesOrderHeader]
	    WHERE [SalesPersonID] IS NOT NULL
		    AND DATEPART(YEAR, [OrderDate]) = @Year	
	    GROUP BY [SalesPersonID], (DATEPART(YEAR, [OrderDate])*100)+DATEPART(MONTH, [OrderDate])
    )

    SELECT TOP 5 [SalesPersonID],YearMonth as MonthNumber,CAST(TotalDue as decimal(10,2)) as TotalSales,
    CAST(TotalDue/
	   (select sum(TotalDue) 
	    from  cteMonthlyTotals 
	    where YearMonth = mt.YearMonth) as decimal(6,2)) as PercOfMonthTotal
    FROM cteMonthlyTotals mt
    ORDER BY PercOfMonthTotal DESC

END;
	



GO

