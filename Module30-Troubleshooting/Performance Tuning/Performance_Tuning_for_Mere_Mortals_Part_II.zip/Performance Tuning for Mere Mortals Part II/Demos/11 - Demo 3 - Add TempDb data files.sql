USE [master]
GO
ALTER DATABASE [tempdb] ADD FILE ( NAME = N'tempdev2', FILENAME = N'C:\SQLServer\Data\tempdev2.ndf' , SIZE = 262144KB , FILEGROWTH = 131072KB )
GO
ALTER DATABASE [tempdb] ADD FILE ( NAME = N'tempdev3', FILENAME = N'C:\SQLServer\Data\tempdev3.ndf' , SIZE = 262144KB , FILEGROWTH = 131072KB )
GO
ALTER DATABASE [tempdb] ADD FILE ( NAME = N'tempdev4', FILENAME = N'C:\SQLServer\Data\tempdev4.ndf' , SIZE = 262144KB , FILEGROWTH = 131072KB )
GO
ALTER DATABASE [tempdb] ADD FILE ( NAME = N'tempdev5', FILENAME = N'C:\SQLServer\Data\tempdev5.ndf' , SIZE = 262144KB , FILEGROWTH = 131072KB )
GO
ALTER DATABASE [tempdb] ADD FILE ( NAME = N'tempdev6', FILENAME = N'C:\SQLServer\Data\tempdev6.ndf' , SIZE = 262144KB , FILEGROWTH = 131072KB )
GO
ALTER DATABASE [tempdb] ADD FILE ( NAME = N'tempdev7', FILENAME = N'C:\SQLServer\Data\tempdev7.ndf' , SIZE = 262144KB , FILEGROWTH = 131072KB )
GO
ALTER DATABASE [tempdb] ADD FILE ( NAME = N'tempdev8', FILENAME = N'C:\SQLServer\Data\tempdev8.ndf' , SIZE = 262144KB , FILEGROWTH = 131072KB )
GO


/*

-- select * from tempdb.sys.database_files

USE [tempdb]
GO
DBCC SHRINKFILE (tempdev1, EMPTYFILE); 
GO
ALTER DATABASE [tempdb]  REMOVE FILE [tempdev1]
GO
USE [tempdb]
GO
DBCC SHRINKFILE (tempdev2, EMPTYFILE); 
GO
ALTER DATABASE [tempdb]  REMOVE FILE [tempdev2]
GO
USE [tempdb]
GO

DBCC SHRINKFILE (tempdev3, EMPTYFILE); 
GO
ALTER DATABASE [tempdb]  REMOVE FILE [tempdev3]
GO

DBCC SHRINKFILE (tempdev4, EMPTYFILE); 
GO
ALTER DATABASE [tempdb]  REMOVE FILE [tempdev4]
GO


DBCC SHRINKFILE (tempdev5, EMPTYFILE); 
GO
ALTER DATABASE [tempdb]  REMOVE FILE [tempdev5]
GO

DBCC SHRINKFILE (tempdev6, EMPTYFILE); 
GO
ALTER DATABASE [tempdb]  REMOVE FILE [tempdev6]
GO

DBCC SHRINKFILE (tempdev7, EMPTYFILE); 
GO
ALTER DATABASE [tempdb]  REMOVE FILE [tempdev7]
GO


DBCC SHRINKFILE (tempdev8, EMPTYFILE); 
GO
ALTER DATABASE [tempdb]  REMOVE FILE [tempdev8]
GO

*/