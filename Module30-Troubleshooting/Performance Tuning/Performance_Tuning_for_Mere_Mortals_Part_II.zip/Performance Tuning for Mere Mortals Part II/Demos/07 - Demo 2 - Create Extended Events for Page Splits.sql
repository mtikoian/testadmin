
-- Create the Event Session to track LOP_DELETE_SPLIT transaction_log operations in the server
-- From Jonathan Kehayias' blog on SQLSkills
IF EXISTS(SELECT * FROM sys.server_event_sessions where name = 'TrackPageSplits')
DROP EVENT SESSION [TrackPageSplits] ON SERVER
GO

CREATE EVENT SESSION [TrackPageSplits]
ON    SERVER
ADD EVENT sqlserver.transaction_log (
    WHERE operation = 11  -- LOP_DELETE_SPLIT (identified a mid page split)
)
ADD TARGET package0.histogram(
    SET filtering_event_name = 'sqlserver.transaction_log',
        source_type = 0, -- Event Column
        source = 'database_id');
GO

/*
 
CREATE EVENT SESSION [File_Growths] ON SERVER 
ADD EVENT sqlserver.database_file_size_change(
    ACTION(sqlos.task_time,sqlserver.database_name,sqlserver.session_id,sqlserver.sql_text)
    WHERE ([sqlserver].[database_name]=N'AdventureWorks2014'))
WITH (MAX_MEMORY=4096 KB,EVENT_RETENTION_MODE=ALLOW_SINGLE_EVENT_LOSS,MAX_DISPATCH_LATENCY=30 SECONDS,MAX_EVENT_SIZE=0 KB,MEMORY_PARTITION_MODE=NONE,TRACK_CAUSALITY=OFF,STARTUP_STATE=OFF)
GO

*/


