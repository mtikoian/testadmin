
/*
    DBCC FREEPROCCACHE
    DBCC DROPCLEANBUFFERS

   ** Pre Presentation
 -- 1. Create AdventureWorks Database (if it doesn't exist)

	   Restore from https://msftdbprodsamples.codeplex.com/releases/view/125550
 -- 2. Execute "02 - Setup - 2 -Create Large AdventureWorks" (If tables don't already exist)
	   ** Run this at home only  **

 -- 3. Truncate Perf Counters : 
 
	   TRUNCATE TABLE [PerfStats].[dbo].[dm_os_performance_counters]

    	   -- Clear wait stats
	   DBCC SQLPERF('sys.dm_os_wait_stats', CLEAR);

	   -- Start Collect Wait Stats Job

	   --- CREATE WhoIsActive table SCHEMA (Done in Part I)
	   --PRINT 'USE PerfStats'
	   --PRINT 'If EXISTS(select * from sys.tables where name = ''WhoIsActive'') DROP TABLE [WhoISActive]'
	   --declare @schema VARCHAR(MAX)
	   --exec perfstats.dbo.sp_WhoIsActive 
			 --  @get_plans = 1, 
			 --  @get_locks = 1, 
			 --  @get_task_info = 1, 
			 --  @get_avg_time = 1, 
			 --  @delta_interval = 1, 
			 --  @format_output = 0, 
			 --  @get_outer_command = 1,
			 --  @find_block_leaders = 1,
			 --  @return_schema = 1,
			 --  @schema = @schema OUTPUT
	   --SELECT REPLACE(@schema,'<table_name>','WhoIsActive')


--    4. Create WhoIsActive Job (Done in Part I)

	   --Run "Part I - 5 - Create WhoIsActive Job.sql"


  --5. Start sp_WhoIsActive job:

	   IF EXISTS(SELECT * FROM msdb.dbo.sysjobs WHERE name like 'sp_WhoIsActive Collection%' and enabled = 0)
	   EXEC msdb.dbo.sp_update_job
		  @job_name = N'sp_WhoIsActive Collection - Stopped',
		  @new_name = N'sp_WhoIsActive Collection - Running',
		  @description = N'Start Collecting.',
		  @enabled = 1 ;
	   GO

  --6.	Start Perf Counters Job   

	   IF EXISTS(SELECT * FROM msdb.dbo.sysjobs WHERE name like 'Perf Counters%' and enabled = 0)
	   EXEC msdb.dbo.sp_update_job
		  @job_name = N'Perf Counters-Stopped',
		  @new_name = N'Perf Counters-Running',
		  @description = N'Start Collecting.',
		  @enabled = 1 ;
	   GO

 --7.	Start Wait Stats Job   

	   IF EXISTS(SELECT * FROM msdb.dbo.sysjobs WHERE name like 'Collect Wait Stats%' and enabled = 0)
	   EXEC msdb.dbo.sp_update_job
		  @job_name = N'Collect Wait Stats-Stopped',
		  @new_name = N'Collect Wait Stats-Running',
		  @description = N'Start Collecting.',
		  @enabled = 1 ;
	   GO

	   


    ---------------------------------------------------------------------------------------------------------------------------
    Demo 1 - Slow IO
    1. Create database on slow disk 
	   "05 - Demo 1 - Slow IO WRITELOG.sql" --- Leave open for step 7


    2. Show Location in sys.dm_io_virtual_file_stats


	   EXEC PerfStats.dbo.ShowCurrentIO 'SlowLogFile'

    
    3. Go to the scripts for the WRITELOG waits demo
	    \Performance Tuning for Mere Mortals Part II\Demos\02 WRITELOG Waits\Add50Clients.cmd 

	   Run Add50Clients.cmd



    4. SELECT * FROM sys.dm_os_waiting_tasks



    5. 
	   SELECT * FROM [PerfStats].[dbo].[WaitStats] 
	   WHERE capture_date >= (
		  select capture_date 
		  from (
			 select top 20 capture_date, row_number() over (order by capture_date desc) as rn
			 from [PerfStats].[dbo].[WaitStats] 
			 group by capture_date
			 order by capture_date desc
			 ) a
			 where rn=5
		  )
	   AND waittype = 'WRITELOG'




    6. Right Click on CMD window and select "Close All Windows"



    7. Restore SlowLogFile database (** NOTE: ** move log file to fast drive C: by commenting H drive and uncommenting K:)


    8. Show Location in sys.dm_io_virtual_file_stats


	   EXEC PerfStats.dbo.ShowCurrentIO 'SlowLogFile'



    9.  -- Clear wait stats
	   DBCC SQLPERF('sys.dm_os_wait_stats', CLEAR);


    
    10. Re-Run Add50Clients.cmd 


	   
    11. SELECT * FROM sys.dm_os_waiting_tasks



    12. 
	   SELECT * FROM [PerfStats].[dbo].[WaitStats] 
	   WHERE capture_date >= (
		  select capture_date 
		  from (
			 select top 20 capture_date, row_number() over (order by capture_date desc) as rn
			 from [PerfStats].[dbo].[WaitStats] 
			 group by capture_date
			 order by capture_date desc
			 ) a
			 where rn=5
		  )
	   AND waittype = 'WRITELOG'



    13. TempDb? 
    
	   EXEC PerfStats.dbo.ShowCurrentIO 'TempDb'



    14. Move TempDB:
	   "06 - Demo 1 - Move TempDb.sql"


    15. Restart SQL Server Service


    16. Rerun the WRITELOG workload.


    17.	   EXEC PerfStats.dbo.ShowCurrentIO 'TempDb'


   
    ---------------------------------------------------------------------------------------------------------------------------
    Demo 2 - Page Splits

    1. Demo 2 - Create Extended Events for Page Splits
	   "07 - Demo 2 - Create Extended Events for Page Splits.sql"


    2. Identifies bad page splits (mid page vs. end of page)


    3. Run Create TABLES and INDEXES
	   "08 - Demo 2 - Page Splits.sql"


    4. Start Page Split Extended Event session

	   ALTER EVENT SESSION [TrackPageSplits]
	   ON SERVER
	   STATE=START;
	   GO



    5. Run Workload for 10 seconds

	   -- Insert the default values repeatedly into the tables
	   USE AdventureWorks2014;
	   Go

	   WHILE 1=1
	   BEGIN
		  INSERT INTO demo.BadSplitsPK DEFAULT VALUES;
		  INSERT INTO demo.EndSplitsPK DEFAULT VALUES;
		  WAITFOR DELAY '00:00:00.005';
	   END
	   GO

    
    6. Get database_id from sys.databases
	   SELECT database_id, name from sys.databases
ParallelismTest


    7. Look at results in Extended Events session histogram



    8. Stop the XE Session

    	   ALTER EVENT SESSION [TrackPageSplits]
	   ON SERVER
	   STATE=STOP;
	   GO



    9. Set FILLFACTOR

	   USE AdventureWorks2014
	   GO
	   ALTER INDEX PK__BadSplit ON demo.BadSplitsPK REBUILD WITH (FILLFACTOR=60)
	   ALTER INDEX IX_BadSplitsPK_ColVal ON demo.BadSplitsPK REBUILD WITH (FILLFACTOR=60)
	   ALTER INDEX IX_EndSplitsPK_ChangeDate ON demo.EndSplitsPK REBUILD WITH (FILLFACTOR=60)
	   GO



    10. Start TrackPageSplits XE session

	   ALTER EVENT SESSION [TrackPageSplits]
	   ON SERVER
	   STATE=START;
	   GO



    11. Run Workload for 10 seconds 

	   -- Insert the default values repeatedly into the tables
	   WHILE 1=1
	   BEGIN
		  INSERT INTO demo.BadSplitsPK DEFAULT VALUES;
		  INSERT INTO demo.EndSplitsPK DEFAULT VALUES;
		  WAITFOR DELAY '00:00:00.005';
	   END
	   GO



    12. Look at results in Extended Events session histogram and compare to previous

	   
    13. Stop the Extended Event 

       ALTER EVENT SESSION [TrackPageSplits]
	   ON SERVER
	   STATE=STOP;
	   GO

    ---------------------------------------------------------------------------------------------------------------------------
    Demo 3 - TempDb Contention

     A SQL Server DBA myth a day: (12/30) tempdb should always have one data file per processor core
	In 2010, Paul Randal wrote article: >8 cores 8, if contention add more 4 at a time.

    1. Open, explain and run "09 - Demo 3 - TempDb File Contention-setup.sql" to create procedures and functions. Close

    2. Open, explain and execute "10 - Demo 3 - TempDb File Contention.sql" to add extended events

    3. Start XE session

    3. Open folder \Performance Tuning for Mere Mortals Part II\Demos\01 Tempdb Contention

    4. Run Create 50 Clients.cmd file

    5. View histogram

    6. Add TempDb files (twice as many to show TempDb contention may not be resolvable with data files)

	  Open, explain and run "11 - Demo 3 - Add TempDb data files.sql"

    7. Restart SQL Server Services

    8. Start XE session

    	   ALTER EVENT SESSION [MonitorTempDbContention]
	   ON SERVER
	   STATE=START;
	   GO


    9. Run Create 50 Clients.cmd file

    10. View Histogram

    11. Stop XE Session and close workload
    	   
    	   ALTER EVENT SESSION [MonitorTempDbContention]
	   ON SERVER
	   STATE=STOP;
	   GO

    12. Close TempDb Contention Scripts

   
    ---------------------------------------------------------------------------------------------------------------------------
    Demo 5 - Recompiles

    1. Open "14 - Demo 5 - Setup - Recompiles Demo.sql" and run. 
	   Creates XE and Procedures.

	   Open "15 - Demo 5 - Recompiles XE Sessions.sql" and run.
	    

    2. Start XE Session

    
	   ALTER EVENT SESSION [BucketizerTargetDemoRecompiles]
	   ON SERVER
	   STATE=START
	   GO


        
    3.Run the following workload to demonstrate recompiles due to "interleaving" of DML and DDL.
	   USE AdventureWorks2014
	   GO

	   EXECUTE [AnnualTop5SalesPersonByMonthlyPercent] @Year=2011;
	   GO
	   EXECUTE [AnnualTop5SalesPersonByMonthlyPercent] @Year=2012;
	   GO
	   EXECUTE [AnnualTop5SalesPersonByMonthlyPercent] @Year=2013;
	   GO
	   EXECUTE [AnnualTop5SalesPersonByMonthlyPercent] @Year=2014;

    4. Look at the Database ID:   
	   
	   SELECT * from sys.databases	   

    5. Check the Extended Events BucketizerTargetDemoRecompiles.

    6. Open and Execute "17 - Demo 5 - AnnualTop5SalesPersonByMonthlyPercent_New.sql" to add new procedure (describe the logic).


    7. Stop and Start the XE session.

	   ALTER EVENT SESSION [BucketizerTargetDemoRecompiles]
	   ON SERVER
	   STATE=STOP
	   GO

	   ALTER EVENT SESSION [BucketizerTargetDemoRecompiles]
	   ON SERVER
	   STATE=START
	   GO


    8. Execute procedures
	   EXECUTE [AdventureWorks2014].[dbo].[AnnualTop5SalesPersonByMonthlyPercent_New] @Year=2011;
	   EXECUTE [AdventureWorks2014].[dbo].[AnnualTop5SalesPersonByMonthlyPercent_New] @Year=2012;
	   EXECUTE [AdventureWorks2014].[dbo].[AnnualTop5SalesPersonByMonthlyPercent_New] @Year=2013;
	   EXECUTE [AdventureWorks2014].[dbo].[AnnualTop5SalesPersonByMonthlyPercent_New] @Year=2014;


    9. Check the Extended Events BucketizerTargetDemoRecompiles.
    ---------------------------------------------------------------------------------------------------------------------------
    Demo 4 - Parallelism

    EXPLAIN CXPacket Wait

    1. Open and execute "12 - Demo 4 - SetupParallelism.sql" to create schema and data (Execution time :39)

    2. Set Parallelism to default 

	   EXEC sys.sp_configure N'show advanced options', N'1'  RECONFIGURE WITH OVERRIDE
	   GO
	   EXEC sys.sp_configure N'cost threshold for parallelism', N'5'
	   GO
	   EXEC sys.sp_configure N'max degree of parallelism', N'0'
	   GO
	   RECONFIGURE WITH OVERRIDE
	   GO
	   EXEC sys.sp_configure N'show advanced options', N'0'  RECONFIGURE WITH OVERRIDE
	   GO
    
    3. DBCC SQLPERF('sys.dm_os_wait_stats', CLEAR);
    
    4.  Verify Collect Wait Stats is running	 

    	   IF EXISTS(SELECT * FROM msdb.dbo.sysjobs WHERE name like 'Collect Wait Stats%' and enabled = 0)
	   EXEC msdb.dbo.sp_update_job
		  @job_name = N'Collect Wait Stats-Stopped',
		  @new_name = N'Collect Wait Stats-Running',
		  @description = N'Start Collecting.',
		  @enabled = 1 ;
	   GO


    5. Open file "13 - Demo 4 - Parallelism.sql"  AND LEAVE OPEN
    
    6. RUN WITH MAXDOP = 1 Commented out in the file ... Run only once  
	   with While commented out with the Actual Execution Plan Enabled.

    7. Run query and uncomment the While loop.

    8. View Wait Stats

	   SELECT * FROM [PerfStats].[dbo].[WaitStats] 
	   WHERE capture_date >= (
		  select capture_date 
		  from (
			 select top 20 capture_date, row_number() over (order by capture_date desc) as rn
			 from [PerfStats].[dbo].[WaitStats] 
			 group by capture_date
			 order by capture_date desc
			 ) a
			 where rn=5
		  )
	   AND waittype = 'CXPACKET'

    9. Run query 

    	   SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

	   WITH XMLNAMESPACES  
		 (DEFAULT 'http://schemas.microsoft.com/sqlserver/2004/07/showplan') 
	   SELECT 
			 query_plan AS CompleteQueryPlan,
			 n.value('(@StatementText)[1]', 'VARCHAR(4000)') AS StatementText,
			 n.value('(@StatementOptmLevel)[1]', 'VARCHAR(25)') AS StatementOptimizationLevel,
			 n.value('(@StatementSubTreeCost)[1]', 'VARCHAR(128)') AS StatementSubTreeCost,
			 n.query('.') AS ParallelSubTreeXML, 
			 ecp.usecounts,
			 ecp.size_in_bytes
	   FROM sys.dm_exec_cached_plans AS ecp
	   CROSS APPLY sys.dm_exec_query_plan(plan_handle) AS eqp
	   CROSS APPLY query_plan.nodes('/ShowPlanXML/BatchSequence/Batch/Statements/StmtSimple') AS qn(n)
	   WHERE  n.query('.').exist('//RelOp[@PhysicalOp="Parallelism"]') = 1 

    10. Open execution plan and show DOP

       
    11. -- Clear wait stats
	   DBCC SQLPERF('sys.dm_os_wait_stats', CLEAR);


    12. Uncomment MAXDOP = 1 in the file ("13 - Demo 4 - Parallelism.sql") and
	   run only once  with While loop commented out with the Actual Execution 
	   Plan Enabled.
    
    13. Run workload "13 - Demo 4 - Parallelism.sql" and uncomment the While 
	   loop.

    14. View Wait Stats

	   SELECT * FROM [PerfStats].[dbo].[WaitStats] 
	   WHERE capture_date >= (
		  select capture_date 
		  from (
			 select top 20 capture_date, row_number() over (order by capture_date desc) as rn
			 from [PerfStats].[dbo].[WaitStats] 
			 group by capture_date
			 order by capture_date desc
			 ) a
			 where rn=5
		  )
	   AND waittype = 'CXPACKET'


    ---------------------------------------------------------------------------------------------------------------------------
    Demo 6 - SARGable/Implicit Convert Warning


    1. Open 18 - "Demo 6 - Implicit conversion non-SARGable", set "Include 
	  Actual Execution Plan" and run script show warning, and reads 
	  difference, and worktable.
    
    ---------------------------------------------------------------------------------------------------------------------------

    -- CLEANUP


        -- Stop Wait Stats Collection  
    IF EXISTS(SELECT * FROM msdb.dbo.sysjobs WHERE name like 'Collect Wait Stats%' and enabled = 1)
    EXEC msdb.dbo.sp_update_job
	   @job_name = N'Collect Wait Stats-Running',
	   @new_name = N'Collect Wait Stats-Stopped',
	   @description = N'Stop Collecting.',
	   @enabled = 0 ;
    GO



    -- Stop Collect sp_WhoIsActive Job
    IF EXISTS(SELECT * FROM msdb.dbo.sysjobs WHERE name like 'sp_WhoIsActive Collection%' and enabled = 1)
    EXEC msdb.dbo.sp_update_job
	   @job_name = N'sp_WhoIsActive Collection - Running',
	   @new_name = N'sp_WhoIsActive Collection - Stopped',
	   @description = N'Stop Collecting.',
	   @enabled = 0 ;
    GO



     IF EXISTS(SELECT * FROM msdb.dbo.sysjobs WHERE name like 'Perf Counters%' and enabled = 1)
     EXEC msdb.dbo.sp_update_job
	   @job_name = N'Perf Counters-Running',
	   @new_name = N'Perf Counters-Stopped',
	   @description = N'Stop Collecting.',
	   @enabled = 0 ;
    GO


    IF EXISTS(SELECT * FROM sys.server_event_sessions where name = 'BucketizerTargetDemoRecompiles')
    DROP EVENT SESSION [BucketizerTargetDemoRecompiles] ON SERVER 
    GO

    IF EXISTS(SELECT * FROM sys.server_event_sessions where name = 'File_Growths')
    DROP EVENT SESSION [File_Growths] ON SERVER 
    GO

    IF EXISTS(SELECT * FROM sys.server_event_sessions where name = 'MonitorTempdbContention')
    DROP EVENT SESSION [MonitorTempdbContention] ON SERVER 
    GO

    IF EXISTS(SELECT * FROM sys.server_event_sessions where name = 'TrackPageSplits')
    DROP EVENT SESSION [TrackPageSplits] ON SERVER 
    GO

    IF EXISTS(SELECT * FROM sys.server_event_sessions where name = 'Waits')
    DROP EVENT SESSION [Waits] ON SERVER 
    GO






*/




















