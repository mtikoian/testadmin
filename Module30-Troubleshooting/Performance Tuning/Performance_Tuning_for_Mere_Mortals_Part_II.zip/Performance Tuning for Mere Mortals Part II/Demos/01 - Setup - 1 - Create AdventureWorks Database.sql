-- 1 - SetupWorkload
--Restore AdventureWorks2014



USE [master]
GO
If EXISTS(select * from sys.databases where name = 'AdventureWorks2014')
ALTER DATABASE [AdventureWorks2014] SET  SINGLE_USER WITH ROLLBACK IMMEDIATE
GO
USE [master]
GO
/****** Object:  Database [AdventureWorks2014]    Script Date: 7/27/2014 3:09:47 PM ******/
If EXISTS(select * from sys.databases where name = 'AdventureWorks2014')
DROP DATABASE [AdventureWorks2014]
GO


USE [master]
RESTORE DATABASE [AdventureWorks2014] 
FROM  DISK = N'C:\Users\mike.LAWELLTECH\Dropbox\SQL Saturday\Presentations\Performance Tuning for Mere Mortals Part I\AdventureWorks2014.bak' 
WITH  FILE = 1,  
MOVE N'AdventureWorks2014_Data' TO N'C:\SQLServer\Data\AdventureWorks2014.mdf',  
MOVE N'AdventureWorks2014_Log' TO N'C:\SQLServer\Log\AdventureWorks2014.ldf',  NOUNLOAD,  STATS = 5
GO

USE [AdventureWorks2014]
GO
IF NOT EXISTS(SELECT * FROM sys.schemas where name = 'demo')
EXEC('CREATE SCHEMA [demo] AUTHORIZATION [dbo]')
GO
