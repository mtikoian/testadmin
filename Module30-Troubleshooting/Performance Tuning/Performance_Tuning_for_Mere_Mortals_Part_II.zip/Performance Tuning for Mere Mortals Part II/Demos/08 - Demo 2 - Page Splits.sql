
USE [AdventureWorks2014]
GO


IF OBJECT_ID(N'demo.BadSplitsPK') IS NOT NULL
DROP TABLE demo.BadSplitsPK
GO

-- Create a bad splitting clustered index table
CREATE TABLE [demo].[BadSplitsPK](
	[ROWID] [uniqueidentifier] NOT NULL DEFAULT (newid()),
	[ColVal] [int] NOT NULL DEFAULT (rand()*(1000)),
	[ChangeDate] [datetime2](7) NOT NULL DEFAULT (getdate()),
 CONSTRAINT [PK__BadSplit] PRIMARY KEY CLUSTERED 
(
	[ROWID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
CREATE INDEX IX_BadSplitsPK_ColVal ON [demo].BadSplitsPK (ColVal);
GO
--  This index should end-split based on the DEFAULT column value
CREATE INDEX IX_BadSplitsPK_ChangeDate ON [demo].BadSplitsPK (ChangeDate);
GO


IF OBJECT_ID(N'demo.EndSplitsPK') IS NOT NULL
DROP TABLE demo.EndSplitsPK
GO
-- Create a table with an increasing clustered index

CREATE TABLE [demo].[EndSplitsPK](
	[ROWID] [int] IDENTITY(1,1) NOT NULL,
	[ColVal] [int] NOT NULL DEFAULT (rand()*(1000)),
	[ChangeDate] [datetime2](7) NOT NULL DEFAULT (dateadd(minute,rand()*(-1000),getdate())),
 CONSTRAINT [PK__EndSplit] PRIMARY KEY CLUSTERED 
(
	[ROWID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
CREATE INDEX IX_EndSplitsPK_ChangeDate ON [demo].EndSplitsPK (ChangeDate);
GO

