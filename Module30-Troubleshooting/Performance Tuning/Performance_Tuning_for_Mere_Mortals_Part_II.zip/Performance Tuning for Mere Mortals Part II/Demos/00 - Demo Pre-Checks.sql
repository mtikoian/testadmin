-- Demo Checks

/*

    1. Verify SlowIO script puts log file on H 
	  
    2. Verify JOBs Exist 
	   SELECT name, enabled, date_created FROM msdb.dbo.sysjobs where name <> 'syspolicy_purge_history'

    3. Verify TempDB is on H: and only one tempdb data file exists.
	   select * from tempdb.sys.database_files



*/