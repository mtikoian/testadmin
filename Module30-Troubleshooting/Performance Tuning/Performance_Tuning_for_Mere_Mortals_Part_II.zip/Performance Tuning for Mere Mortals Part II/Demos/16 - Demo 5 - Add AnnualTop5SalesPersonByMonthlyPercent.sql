USE [AdventureWorks2014]
GO

/****** Object:  StoredProcedure [dbo].[AnnualTop5SalesPersonByMonthlyPercent]    Script Date: 8/18/2014 11:09:30 PM ******/
DROP PROCEDURE [dbo].[AnnualTop5SalesPersonByMonthlyPercent]
GO

/****** Object:  StoredProcedure [dbo].[AnnualTop5SalesPersonByMonthlyPercent]    Script Date: 8/18/2014 11:09:30 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[AnnualTop5SalesPersonByMonthlyPercent] (@Year int)
AS

BEGIN
	CREATE TABLE [tempdb].[dbo].[MonthlyTotals] 
	([MonthNumber] INT PRIMARY KEY, [TotalSales] DECIMAL(18,2));
	
	INSERT INTO [tempdb].[dbo].[MonthlyTotals] ([MonthNumber], [TotalSales])
	SELECT (DATEPART(YEAR, [OrderDate])*100)+DATEPART(MONTH, [OrderDate]), SUM([TotalDue])
	FROM [Sales].[SalesOrderHeader]
	WHERE [SalesPersonID] IS NOT NULL
		AND DATEPART(YEAR, [OrderDate]) = @Year
	GROUP BY (DATEPART(YEAR, [OrderDate])*100)+DATEPART(MONTH, [OrderDate]);
	
	CREATE TABLE [tempdb].[dbo].[EmpSalesPercentByMonth]
	([SalesPersonID] INT, [MonthNumber] INT, [TotalSales] DECIMAL(18,2), [PercentMonthTotal] DECIMAL(18,2));
	
	INSERT INTO [tempdb].[dbo].[EmpSalesPercentByMonth] ([SalesPersonID], [MonthNumber], [TotalSales])
	SELECT [SalesPersonID], (DATEPART(YEAR, [OrderDate])*100)+DATEPART(MONTH, [OrderDate]), SUM([TotalDue])
	FROM [Sales].[SalesOrderHeader]
	WHERE [SalesPersonID] IS NOT NULL
		AND DATEPART(YEAR, [OrderDate]) = @Year	
	GROUP BY [SalesPersonID], (DATEPART(YEAR, [OrderDate])*100)+DATEPART(MONTH, [OrderDate]);

	CREATE CLUSTERED INDEX [IX_EmpSalesPercentByMonth_MonthNumber] 
	ON [tempdb].[dbo].[EmpSalesPercentByMonth] ([MonthNumber]);

	UPDATE [pbm]
	SET [pbm].[PercentMonthTotal] = [pbm].[TotalSales]/[mt].[TotalSales]
	FROM [tempdb].[dbo].[EmpSalesPercentByMonth] AS pbm
	INNER JOIN [tempdb].[dbo].[MonthlyTotals] AS mt 
		ON [pbm].[MonthNumber] = [mt].[MonthNumber];
	
	DROP TABLE [tempdb].[dbo].[MonthlyTotals];
	
	SELECT TOP 5 * 
	FROM [tempdb].[dbo].[EmpSalesPercentByMonth]
	ORDER BY [PercentMonthTotal] DESC;
	
	DROP TABLE [tempdb].[dbo].[EmpSalesPercentByMonth];
END;


GO


