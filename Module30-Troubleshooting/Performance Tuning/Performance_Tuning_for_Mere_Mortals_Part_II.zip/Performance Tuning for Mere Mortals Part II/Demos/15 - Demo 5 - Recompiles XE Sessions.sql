
IF EXISTS(SELECT * FROM sys.server_event_sessions WHERE name='BucketizerTargetDemoRecompiles')
    DROP EVENT SESSION [BucketizerTargetDemoRecompiles] ON SERVER;
CREATE EVENT SESSION [BucketizerTargetDemoRecompiles]
ON SERVER
ADD EVENT sqlserver.sql_statement_starting		  -- SQL STATEMENT Event
(    ACTION (sqlserver.database_id) -- database_id to bucket on
     WHERE (state=1) -- recompile state from dm_xe_map_values
),
ADD EVENT sqlserver.sp_statement_starting		  -- SP STATEMENT Event
(    ACTION (sqlserver.database_id) -- database_id to bucket on
     WHERE (state=1) -- recompile state from dm_xe_map_values
)
ADD TARGET package0.asynchronous_bucketizer
(     SET source_type=1, -- specifies bucketing on Action 
         source='sqlserver.database_id' -- Action to bucket on
)
WITH (MAX_DISPATCH_LATENCY = 5 SECONDS)
GO

--ALTER EVENT SESSION [BucketizerTargetDemoRecompiles]
--ON SERVER
--STATE=START
--GO


--select *
-- from sys.dm_os_performance_counters 
-- where object_name = 'SQLServer:SQL Statistics'
-- and counter_name like '%compil%'

--                                                                                                  	SQL Re-Compilations/sec                                                                                                         	                                                                                                                                	324	272696576