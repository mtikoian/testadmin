USE [AdventureWorks2014]
GO
SET NOCOUNT ON;
EXECUTE [Person].[GetNextDuplicateCustomerSet] 1;
