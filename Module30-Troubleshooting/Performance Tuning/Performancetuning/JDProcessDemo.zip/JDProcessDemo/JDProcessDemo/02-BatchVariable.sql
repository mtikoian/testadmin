USE TSQL2012
GO
DECLARE @intExample AS int = 5
SELECT @intExample
GO
SELECT @intExample