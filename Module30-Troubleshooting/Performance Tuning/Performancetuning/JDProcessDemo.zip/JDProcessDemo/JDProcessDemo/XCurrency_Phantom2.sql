--SQL Server Concurrency
--Phantom Read - Session 2
USE TSQL2012
BEGIN TRAN
	DELETE FROM Accounting.BankAccounts
	WHERE AcctID IN(3,5,6)
COMMIT TRAN
