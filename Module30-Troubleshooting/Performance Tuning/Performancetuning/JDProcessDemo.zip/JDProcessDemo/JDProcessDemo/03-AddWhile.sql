DECLARE @AcctID AS tinyint = 1

WHILE @AcctID < 10
	BEGIN
		INSERT INTO Accounting.BankAccounts
			(AcctName, Balance, ModifiedDate)
		SELECT lastname, 100 * @AcctID, GETDATE()
			FROM HR.Employees
			WHERE empid = @AcctID
		SET @AcctID += 1
	END






