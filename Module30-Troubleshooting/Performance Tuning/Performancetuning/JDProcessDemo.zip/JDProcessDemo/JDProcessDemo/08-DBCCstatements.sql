SELECT * FROM Accounting.BankAccounts

DBCC TRACEON(3604) 
DBCC PAGE(0, 1, 664, 3)
--DBCC IND(0,'Accounting.BankAccounts',-1)