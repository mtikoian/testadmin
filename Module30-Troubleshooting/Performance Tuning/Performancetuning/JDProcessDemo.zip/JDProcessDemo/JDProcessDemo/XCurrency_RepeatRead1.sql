--SQL Server Concurrency
--Repeatable Read - Session 1
USE TSQL2012
SET TRANSACTION ISOLATION LEVEL
READ COMMITTED -- Before Example
--REPEATABLE READ --Switch for Example
BEGIN TRAN
	SELECT AcctID, ModifiedDate
	FROM Accounting.BankAccounts
WAITFOR DELAY '00:00:10:000'
	SELECT AcctID, ModifiedDate
	FROM Accounting.BankAccounts
COMMIT TRAN