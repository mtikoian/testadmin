--SQL Server Concurrency
--Repeatable Read - Session 2
USE TSQL2012
BEGIN TRAN
	UPDATE Accounting.BankAccounts
	SET ModifiedDate = '12/12/2015' --Reset Date
	--SET ModifiedDate = '11/25/1999' --Run for Example
COMMIT TRAN

SELECT * FROM Accounting.BankAccounts