USE TSQL2012
GO
CREATE SCHEMA Accounting Authorization dbo
CREATE TABLE BankAccounts
 (AcctID int IDENTITY,
  AcctName char(15),
  Balance money,
  ModifiedDate date)
GO
INSERT INTO Accounting.BankAccounts
VALUES('John',500, GETDATE())
INSERT INTO Accounting.BankAccounts
VALUES('Enrique', 750, GETDATE())
