--	SQL Server Concurrency 
-- Lost Update - Session 2
USE TSQL2012
GO
DECLARE @OldBalance int, @NewBalance int
BEGIN TRAN
	SELECT @OldBalance = Balance 
	FROM Accounting.BankAccounts
	WHERE AcctID = 1
	SET @NewBalance = @OldBalance - 400

	UPDATE Accounting.BankAccounts
	SET Balance = @NewBalance
	WHERE AcctID = 1

	SELECT @OldBalance AS OldBalance,
	 AcctID, AcctName, Balance
	FROM Accounting.BankAccounts
	WHERE AcctID = 1
COMMIT TRAN

