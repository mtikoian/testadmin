--Lab 10.2 Code Steps
 
--If no index then all of these will scan.
--If Index then some of these will do seeks.
SELECT *
FROM SalesInvoiceDetail

SELECT *
FROM SalesInvoiceDetail
WHERE InvoiceID = 5

SELECT *
FROM SalesInvoiceDetail
WHERE InvoiceID IN (5,10,60)

SELECT *
FROM SalesInvoiceDetail
WHERE InvoiceID != 5


--What is the ID of JProCo
SELECT DB_ID('JProCo')
SELECT OBJECT_ID('SalesInvoiceDetail')
--DB 9
--Ojbect 28828474

SELECT *
FROM sys.dm_db_index_Usage_Stats
WHERE Database_id = 9
AND [Object_id] = 28828474

--How many seeks and scans have been done?
--Run this again
SELECT *
FROM SalesInvoiceDetail
WHERE InvoiceID != 5
--Notice you have more scans

--Run this again
SELECT *
FROM SalesInvoiceDetail
WHERE InvoiceID = 5
--Notice you have more seeks