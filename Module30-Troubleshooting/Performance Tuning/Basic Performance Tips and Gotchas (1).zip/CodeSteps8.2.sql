SELECT *
FROM dbo.SalesInvoiceDetail
WHERE InvoiceDetailID = 6

SELECT *
FROM dbo.SalesInvoiceDetail
WHERE InvoiceID = 6

--1.) Right click Indexes > New Index
--2.) nci_SalesInvoiceDetail_InvoiceID > Unique

SELECT * 
FROM CurrentProducts
WHERE ProductID = 5  --<< Does a seek (Show plan)

SELECT * 
FROM CurrentProducts
WHERE SupplierID = 1 --<< Does a seek (Show plan)




--These two tables pull out the same record
SELECT * 
FROM HumanResources.Contractor
WHERE ContractorID = 1  --< Seek

SELECT * 
FROM HumanResources.Contractor
WHERE SSN = '222-22-2222' --< Scan 
--You can't create another Clustered Index on the same table

--1.) Right click Indexes > New Index
--2.) nci_Contractor_SSN > Unique
--Now check the execution plan for the SSN query.

