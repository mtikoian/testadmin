
-- index selection

-- uses an index seek
-- note seek predicate
SELECT ProductID, SalesOrderID, SalesOrderDetailID 
FROM Sales.SalesOrderDetail
WHERE ProductID = 771

-- no seek predicate
SELECT ProductID, SalesOrderID, SalesOrderDetailID 
FROM Sales.SalesOrderDetail
WHERE ABS(ProductID) = 771

-- uses an index seek
-- note seek predicate on both
SELECT ProductID, SalesOrderID, SalesOrderDetailID 
FROM Sales.SalesOrderDetail
WHERE ProductID = 771 AND SalesOrderID = 45233

-- uses an index seek
-- but seek predicate on ProductID only
SELECT ProductID, SalesOrderID, SalesOrderDetailID 
FROM Sales.SalesOrderDetail
WHERE ProductID = 771 AND ABS(SalesOrderID) = 45233




