
-- computed columns

SELECT * FROM Sales.SalesOrderDetail
WHERE OrderQty * UnitPrice > 25000

-- 30% guess
SELECT 121317 * .3
-- 36395.1 against 5

ALTER TABLE Sales.SalesOrderDetail
ADD cc AS OrderQty * UnitPrice

-- does not have to use the computed column name
-- just the expression
SELECT * FROM Sales.SalesOrderDetail
WHERE OrderQty * UnitPrice > 25000
-- estimated is now 81.5105

-- unfortunately expression must be the same
SELECT * FROM Sales.SalesOrderDetail
WHERE UnitPrice * OrderQty > 25000

-- index can be created
CREATE INDEX IX_cc on Sales.SalesOrderDetail(cc)

-- and used for an index seek/key lookup plan
SELECT * FROM Sales.SalesOrderDetail
WHERE OrderQty * UnitPrice > 25000

-- or here
SELECT * FROM Sales.SalesOrderDetail
WHERE cc > 25000

-- clean up
DROP INDEX Sales.SalesOrderDetail.IX_cc

ALTER TABLE Sales.SalesOrderDetail 
DROP COLUMN cc

DBCC FREEPROCCACHE






