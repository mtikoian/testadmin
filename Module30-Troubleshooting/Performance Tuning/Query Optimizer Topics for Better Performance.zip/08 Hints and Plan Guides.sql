
-- hints and plan guides

CREATE PROCEDURE test 
AS
SELECT FirstName, LastName 
FROM Person.Contact AS C JOIN Sales.Individual AS I 
ON C.ContactID = I.ContactID

-- verify that it is using a hash join operator
EXEC test

-- create a plan guide to force a nested loops join

EXEC sp_create_plan_guide 
	@name = N'plan_guide_test',
   	@stmt = N'SELECT FirstName, LastName 
	FROM Person.Contact AS C JOIN Sales.Individual AS I 
	ON C.ContactID = I.ContactID',
   	@type = N'OBJECT',
   	@module_or_batch = N'test',
   	@params = NULL,
   	@hints = N'OPTION (LOOP JOIN)';

-- run again to verify
-- it is now using a nested loops join
EXEC test

-- if you decided to stop using the hint
EXEC sp_control_plan_guide N'DROP', N'plan_guide_test';

-- run again to verify
EXEC test

-- clean up
DROP PROCEDURE test






