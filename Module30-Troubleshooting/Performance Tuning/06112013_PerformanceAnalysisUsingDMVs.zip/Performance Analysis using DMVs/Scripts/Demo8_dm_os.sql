USE AdventureWorks2012;
SET NOCOUNT ON;
GO

--discuss columns
SELECT * FROM sys.dm_os_buffer_descriptors;
GO

--aggregation by database is useful to determine cache usage by database
SELECT
	DB_NAME(database_id) AS database_name
	,COUNT(*) AS page_count
	,COUNT(*)*8192 AS total_size
FROM sys.dm_os_buffer_descriptors
GROUP BY
	DB_NAME(database_id)
ORDER BY
	page_count DESC;
GO

--buffer usage by object for current database 
SELECT 
      schema_name
	, object_name
	, index_name
	, COUNT(*) AS cached_pages_count 
FROM sys.dm_os_buffer_descriptors AS bd 
INNER JOIN 
    (
        SELECT
			  SCHEMA_NAME(o.schema_id) AS schema_name
			, OBJECT_NAME(p.object_id) AS object_name
			, i.name AS index_name
			, au.allocation_unit_id
        FROM sys.allocation_units AS au
		JOIN sys.partitions AS p 
			ON au.container_id = p.hobt_id 
            AND au.type IN(1 ,3)
		JOIN sys.objects AS o
			ON o.object_id = p.object_id
		JOIN sys.indexes AS i
			ON i.object_id = p.object_id
				AND i.index_id = p.index_id
        UNION ALL
        SELECT
			  SCHEMA_NAME(o.schema_id) AS schema_name
			, OBJECT_NAME(p.object_id) AS object_name
			, i.name AS index_name
			, au.allocation_unit_id
        FROM sys.allocation_units AS au
            INNER JOIN sys.partitions AS p 
                ON au.container_id = p.partition_id 
                    AND au.type = 2
		JOIN sys.objects AS o
			ON o.object_id = p.object_id
		JOIN sys.indexes AS i
			ON i.object_id = p.object_id
				AND i.index_id = p.index_id
    ) AS obj 
        ON bd.allocation_unit_id = obj.allocation_unit_id
WHERE database_id = db_id()
GROUP BY 
	schema_name
	, object_name
	,index_name
ORDER BY 
	cached_pages_count DESC;
GO

--buffer usage by object for all databases
--note that sys.sp_MSforeachdb is undocumented
IF OBJECT_ID(N'tempdb..#buffer_usage_summary', 'U') IS NOT NULL 
BEGIN
	DROP TABLE #buffer_usage_summary;
END;
CREATE TABLE #buffer_usage_summary (
	  database_name sysname NOT NULL
	, schema_name sysname NOT NULL
	, object_name sysname NOT NULL
	, index_name sysname NULL
	, page_count int NOT NULL
	);

EXEC sys.sp_MSforeachdb
N'USE [?];
INSERT INTO #buffer_usage_summary
SELECT 
	  N''?'' AS database_name
    , schema_name
	, object_name
	, index_name
	, COUNT(*) AS cached_pages_count 
FROM sys.dm_os_buffer_descriptors AS bd 
INNER JOIN 
    (
        SELECT
			  SCHEMA_NAME(o.schema_id) AS schema_name
			, OBJECT_NAME(p.object_id) AS object_name
			, i.name AS index_name
			, au.allocation_unit_id
        FROM sys.allocation_units AS au
		JOIN sys.partitions AS p 
			ON au.container_id = p.hobt_id 
            AND au.type IN(1 ,3)
		JOIN sys.objects AS o
			ON o.object_id = p.object_id
		JOIN sys.indexes AS i
			ON i.object_id = p.object_id
				AND i.index_id = p.index_id
        UNION ALL
        SELECT
			  SCHEMA_NAME(o.schema_id) AS schema_name
			, OBJECT_NAME(p.object_id) AS object_name
			, i.name AS index_name
			, au.allocation_unit_id
        FROM sys.allocation_units AS au
            INNER JOIN sys.partitions AS p 
                ON au.container_id = p.partition_id 
                    AND au.type = 2
		JOIN sys.objects AS o
			ON o.object_id = p.object_id
		JOIN sys.indexes AS i
			ON i.object_id = p.object_id
				AND i.index_id = p.index_id
    ) AS obj 
        ON bd.allocation_unit_id = obj.allocation_unit_id
WHERE database_id = db_id()
GROUP BY 
	schema_name
	, object_name
	,index_name;
	';
SELECT
	  database_name
	, schema_name
	, object_name
	, index_name
	, page_count
FROM #buffer_usage_summary
ORDER BY 
	page_count DESC;
IF OBJECT_ID(N'tempdb..#buffer_usage_summary', 'U') IS NOT NULL 
BEGIN
	DROP TABLE #buffer_usage_summary;
END;
GO

--quick way to get free space and other info for a database volume
SELECT * FROM sys.dm_os_volume_stats(DB_ID(), 1);
GO

--SQL Server pmon counters
--note useful for periodic snapshots
SELECT * FROM sys.dm_os_performance_counters;
GO
