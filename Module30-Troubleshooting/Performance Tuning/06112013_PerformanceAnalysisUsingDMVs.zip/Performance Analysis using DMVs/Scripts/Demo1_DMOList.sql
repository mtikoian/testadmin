SELECT
    SCHEMA_NAME(schema_id) AS SchemaName
    ,name AS ObjectName
    ,type_desc AS Object_type
FROM sys.system_objects
WHERE
    name LIKE 'dm[_]%'
ORDER BY name;
