USE AdventureWorks2012;
SET NOCOUNT ON;
GO

--show available columns
SELECT qs.*
FROM sys.dm_exec_query_stats AS qs;
GO

--run Demo3A application and note duration
GO

--retrieve sql batch, statement text and plans from cache with filters to eliminate noise
--note query with highest total time is query from Demo3A app.
--note query selects single customer by account.
--view execution plan to show non-clustered index scan and the index used is not the unique index on AccountNumber.
--note warnings in query plan - implict conversion of varchar column to nvarchar results in nonsargable expression.
--note plan parameter is declared as nvarchar instead of varchar (to match column data type).
--note data type precidence rules.
SELECT
	st.text
	,SUBSTRING(st.text, (qs.statement_start_offset/2)+1, 
		((CASE qs.statement_end_offset
			WHEN -1 THEN DATALENGTH(st.text)
			ELSE qs.statement_end_offset
		END - qs.statement_start_offset)/2) + 1) AS statement_text
	,total_elapsed_time / execution_count AS average_elapsed_time
	,qp.query_plan
	,qs.*
FROM sys.dm_exec_query_stats AS qs
CROSS APPLY sys.dm_exec_sql_text(qs.plan_handle) as st
CROSS APPLY sys.dm_exec_query_plan(qs.plan_handle) AS qp
WHERE
	st.dbid = DB_ID(N'AdventureWorks2012')
	AND st.text NOT LIKE N'%sys.%'
	AND st.text NOT LIKE N'%sys .%'
	AND st.text NOT LIKE N'%spt[_]values%'
ORDER BY total_elapsed_time DESC;
GO

--retrieve sql batch, statement text and plans from cache with filters to eliminate noise
--filter to include only plans with warnings.
SELECT
	st.text
	,qp.query_plan
FROM sys.dm_exec_cached_plans AS cp
CROSS APPLY sys.dm_exec_sql_text(cp.plan_handle) as st
CROSS APPLY sys.dm_exec_query_plan(cp.plan_handle) AS qp
WHERE
	st.dbid = DB_ID(N'AdventureWorks2012')
	AND st.text NOT LIKE N'%sys.%'
	AND st.text NOT LIKE N'%sys .%'
	AND st.text NOT LIKE N'%spt[_]values%'
	AND qp.query_plan.exist('
		declare default element namespace "http://schemas.microsoft.com/sqlserver/2004/07/showplan";
		//Warnings') = 1;
GO

--retrieve sql batch, statement text and plans from cache with filters to eliminate noise
--filter to include only plans with warnings.
--return addition column with aggregated PlanAffectingConvert warnings.
SELECT
	st.text
	,qp.query_plan
	,STUFF((SELECT DISTINCT ',' + Warnings.PlanAffectingConvert.value('data(@ConvertIssue)', 'varchar(100)')
		FROM qp.query_plan.nodes('
		declare default element namespace "http://schemas.microsoft.com/sqlserver/2004/07/showplan";
		//Warnings/PlanAffectingConvert') AS Warnings(PlanAffectingConvert) FOR XML PATH('')),1,1,'') AS warnings
FROM sys.dm_exec_cached_plans AS cp
CROSS APPLY sys.dm_exec_sql_text(cp.plan_handle) as st
CROSS APPLY sys.dm_exec_query_plan(cp.plan_handle) AS qp
WHERE
	st.dbid = DB_ID(N'AdventureWorks2012')
	AND st.text NOT LIKE N'%sys.%'
	AND st.text NOT LIKE N'%sys .%'
	AND st.text NOT LIKE N'%spt[_]values%'
	AND qp.query_plan.exist('
		declare default element namespace "http://schemas.microsoft.com/sqlserver/2004/07/showplan";
		//Warnings') = 1;
GO

--show Demo3A application source code and mention the perils of implictly typed parameters in app code.
--show Demo3B source code with explict parameter types.
--run Demo3B application and note duration is an order of magnatude faster than Demo3A.
GO

--retrieve sql batch, statement text and plans from cache with filters to eliminate noise
--note performance improvement of Demo3B query is orders of magnatude better for all metrics.
--view execution plan to show non-clustered index seek and key loop using unique index on AccountNumber.
SELECT
	st.text
	,qp.query_plan
FROM sys.dm_exec_cached_plans AS cp
CROSS APPLY sys.dm_exec_sql_text(cp.plan_handle) as st
CROSS APPLY sys.dm_exec_query_plan(cp.plan_handle) AS qp
WHERE
	st.dbid = DB_ID(N'AdventureWorks2012')
	AND st.text NOT LIKE N'%sys.%'
	AND st.text NOT LIKE N'%sys .%'
	AND st.text NOT LIKE N'%spt[_]values%'
GO

--run Demo3C application and note duration
GO


--retrieve sql batch, statement text and plans from with filters to eliminate noise
--include queries with more than one entry with same hash.
--note multiple plans that differ only by parameter length.
--note cache bloat and unneeded query compilations are other reasons to avoid using AddWithValue to define parameters.
--using stored procedures (with properly typed parameters) can avoid incorrectly typed parameters in app code.
WITH
	query_stats_summary AS (
		SELECT qs.query_hash, COUNT(*) AS query_hash_count
		FROM sys.dm_exec_query_stats AS qs
		GROUP BY qs.query_hash
		HAVING COUNT(*) > 1
	)
SELECT qss.*, qsd.*
FROM query_stats_summary AS qss
CROSS APPLY (
		SELECT TOP 10 
			st.text
			,SUBSTRING(st.text, (qs.statement_start_offset/2)+1, 
				((CASE qs.statement_end_offset
					WHEN -1 THEN DATALENGTH(st.text)
					ELSE qs.statement_end_offset
				END - qs.statement_start_offset)/2) + 1) AS statement_text
			,qs.plan_handle
			,qp.query_plan
		FROM sys.dm_exec_query_stats AS qs
		CROSS APPLY sys.dm_exec_sql_text(qs.plan_handle) as st
		CROSS APPLY sys.dm_exec_query_plan(qs.plan_handle) AS qp
		WHERE qs.query_hash = qss.query_hash
	) AS qsd;
GO

--create a proc with multiple statements
CREATE PROC dbo.usp_Demo3
AS
SELECT
	GroupName
	,DepartmentID
	,Name
FROM HumanResources.Department
ORDER BY GroupName
	,Name;

SELECT
	GroupName
	,DepartmentID
	,Name
FROM HumanResources.Department;

RETURN @@ERROR;
GO

EXEC dbo.usp_Demo3;
GO

--show sys.dm_exec_procedure_stats columns
SELECT *
FROM sys.dm_exec_procedure_stats AS ps;
GO

--retrieve proc text, statement text and plans from with filters to eliminate noise
--note each proc statement is returned.
--view plan to note costs are estimates - actual cost can be gleaned form DMV stats
SELECT
	st.text
	,SUBSTRING(st.text, (qs.statement_start_offset/2)+1, 
		((CASE qs.statement_end_offset
			WHEN -1 THEN DATALENGTH(st.text)
			ELSE qs.statement_end_offset
		END - qs.statement_start_offset)/2) + 1) AS statement_text
	,qs.total_elapsed_time * 100.0 / ps.total_elapsed_time AS statement_percent_of_elapsed_time
	,qp.query_plan
FROM sys.dm_exec_procedure_stats AS ps
JOIN sys.dm_exec_query_stats AS qs ON
	qs.plan_handle = ps.plan_handle
CROSS APPLY sys.dm_exec_sql_text(ps.plan_handle) as st
CROSS APPLY sys.dm_exec_query_plan(ps.plan_handle) AS qp
WHERE
	st.dbid = DB_ID(N'AdventureWorks2012')
	AND st.text NOT LIKE N'%sys.%'
	AND st.text NOT LIKE N'%sys .%'
	AND st.text NOT LIKE N'%spt[_]values%'
ORDER BY qs.total_elapsed_time DESC;
GO


