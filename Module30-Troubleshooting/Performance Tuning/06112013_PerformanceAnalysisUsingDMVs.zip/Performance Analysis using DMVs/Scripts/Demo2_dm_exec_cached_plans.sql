USE AdventureWorks2012;
SET NOCOUNT ON;
GO

--start with clean cache
DBCC FREEPROCCACHE;
GO

--show available columns
SELECT cp.*
FROM sys.dm_exec_cached_plans AS cp;
GO

--show use of sys.dm_exec_sql_text with OUTER APPLY
SELECT cp.*,st.*
FROM sys.dm_exec_cached_plans AS cp
OUTER APPLY sys.dm_exec_sql_text(cp.plan_handle) as st;
GO

--show use of sys.dm_exec_query_plan with OUTER APPLY
SELECT cp.*, qp.*
FROM sys.dm_exec_cached_plans AS cp
OUTER APPLY sys.dm_exec_query_plan(cp.plan_handle) AS qp;
GO

--run simple query to show plan in cache with clustered index scan
SELECT
	ProductID
	,Name
	,ProductNumber
FROM Production.Product;
GO

--retrieve sql and plans from cache with filters to eliminate noise
SELECT
	st.text
	,qp.query_plan
	,cp.*
FROM sys.dm_exec_cached_plans AS cp
CROSS APPLY sys.dm_exec_sql_text(cp.plan_handle) as st
CROSS APPLY sys.dm_exec_query_plan(cp.plan_handle) AS qp
WHERE
	cp.pool_id = 2
	AND st.dbid = DB_ID(N'AdventureWorks2012')
	AND st.text NOT LIKE N'%sys.%'
	AND st.text NOT LIKE N'%sys .%'
	AND st.text NOT LIKE N'%spt[_]values%';
GO

--run another query with an index seek operator
SELECT
	ProductID
	,Name
	,ProductNumber
FROM Production.Product
WHERE ProductID = 1;
GO

--retrieve sql and plans from cache with filters to eliminate noise
--note 2 entries added: raw adhoc query and parameterized version
SELECT
	st.text
	,qp.query_plan
	,cp.*
FROM sys.dm_exec_cached_plans AS cp
CROSS APPLY sys.dm_exec_sql_text(cp.plan_handle) as st
CROSS APPLY sys.dm_exec_query_plan(cp.plan_handle) AS qp
WHERE
	cp.pool_id = 2
	AND st.dbid = DB_ID(N'AdventureWorks2012')
	AND st.text NOT LIKE N'%sys.%'
	AND st.text NOT LIKE N'%sys .%'
	AND st.text NOT LIKE N'%spt[_]values%';
GO

--run another query that differs only by ProductID
SELECT
	ProductID
	,Name
	,ProductNumber
FROM Production.Product
WHERE ProductID = 2;
GO

--retrieve sql and plans from cache with filters to eliminate noise
--note 1 entry added: raw adhoc query; parameterized version reused and usecount incremented
SELECT
	st.text
	,qp.query_plan
	,cp.*
FROM sys.dm_exec_cached_plans AS cp
CROSS APPLY sys.dm_exec_sql_text(cp.plan_handle) as st
CROSS APPLY sys.dm_exec_query_plan(cp.plan_handle) AS qp
WHERE
	cp.pool_id = 2
	AND st.dbid = DB_ID(N'AdventureWorks2012')
	AND st.text NOT LIKE N'%sys.%'
	AND st.text NOT LIKE N'%sys .%'
	AND st.text NOT LIKE N'%spt[_]values%';
GO

--run an explictly parameterized version of same query
DECLARE @ProductID int = 1;
EXEC sp_executesql N'
	SELECT
		ProductID
		,Name
		,ProductNumber
	FROM AdventureWorks2012.Production.Product
	WHERE
		ProductID = @ProductID;'
	,N'@ProductID int'
	,@ProductID = @ProductID;
GO

--retrieve sql and plans from cache with filters to eliminate noise
--note 1 entry added: parameterized query
SELECT
	st.text
	,qp.query_plan
	,cp.*
FROM sys.dm_exec_cached_plans AS cp
CROSS APPLY sys.dm_exec_sql_text(cp.plan_handle) as st
CROSS APPLY sys.dm_exec_query_plan(cp.plan_handle) AS qp
WHERE
	cp.pool_id = 2
	AND st.dbid = DB_ID(N'AdventureWorks2012')
	AND st.text NOT LIKE N'%sys.%'
	AND st.text NOT LIKE N'%sys .%'
	AND st.text NOT LIKE N'%spt[_]values%';
GO

--run same parameterized query with different parameter value
DECLARE @ProductID int = 2;
EXEC sp_executesql N'
	SELECT
		ProductID
		,Name
		,ProductNumber
	FROM AdventureWorks2012.Production.Product
	WHERE
		ProductID = @ProductID;'
	,N'@ProductID int'
	,@ProductID = @ProductID;
GO

--retrieve sql and plans from cache with filters to eliminate noise
--note no new cache entry added: explictly parameterized query plan is reused
SELECT
	st.text
	,qp.query_plan
	,cp.*
FROM sys.dm_exec_cached_plans AS cp
CROSS APPLY sys.dm_exec_sql_text(cp.plan_handle) as st
CROSS APPLY sys.dm_exec_query_plan(cp.plan_handle) AS qp
WHERE
	cp.pool_id = 2
	AND st.dbid = DB_ID(N'AdventureWorks2012')
	AND st.text NOT LIKE N'%sys.%'
	AND st.text NOT LIKE N'%sys .%'
	AND st.text NOT LIKE N'%spt[_]values%';
GO

--run another query
SELECT
	ProductID
	,Name
	,ProductNumber
FROM AdventureWorks2012.Production.Product
WHERE
	Name LIKE N'B%';
GO

--retrieve sql and plans from cache with filters to eliminate noise
--note only AdHoc query and plan is added to cache.
--query not auto-parameterized because plan may vary depending on values specified.
--note index seek and key lookup in plan - good with few rows
SELECT
	st.text
	,qp.query_plan
	,cp.*
FROM sys.dm_exec_cached_plans AS cp
CROSS APPLY sys.dm_exec_sql_text(cp.plan_handle) as st
CROSS APPLY sys.dm_exec_query_plan(cp.plan_handle) AS qp
WHERE
	cp.pool_id = 2
	AND st.dbid = DB_ID(N'AdventureWorks2012')
	AND st.text NOT LIKE N'%sys.%'
	AND st.text NOT LIKE N'%sys .%'
	AND st.text NOT LIKE N'%spt[_]values%';
GO

--run same query with different value
SELECT
	ProductID
	,Name
	,ProductNumber
FROM AdventureWorks2012.Production.Product
WHERE
	Name LIKE N'M%';
GO

--retrieve sql and plans from cache with filters to eliminate noise
--again, only AdHoc query and plan is added to cache.
--query not auto-parameterized because plan may vary depending on values specified.
--note clustered index scan - good with many rows
SELECT
	st.text
	,qp.query_plan
	,cp.*
FROM sys.dm_exec_cached_plans AS cp
CROSS APPLY sys.dm_exec_sql_text(cp.plan_handle) as st
CROSS APPLY sys.dm_exec_query_plan(cp.plan_handle) AS qp
WHERE
	cp.pool_id = 2
	AND st.dbid = DB_ID(N'AdventureWorks2012')
	AND st.text NOT LIKE N'%sys.%'
	AND st.text NOT LIKE N'%sys .%'
	AND st.text NOT LIKE N'%spt[_]values%';
GO

--run parameterized version of same query
EXEC sp_executesql N'
	SELECT
		ProductID
		,Name
		,ProductNumber
	FROM AdventureWorks2012.Production.Product
	WHERE
		Name LIKE @NameSearch;'
	,N'@NameSearch nvarchar(50)'
	,@NameSearch = 'B%';
GO

--retrieve sql and plans from cache with filters to eliminate noise
--note parameterized query added to cache.
--note index seek and key lookup in plan - good with few rows
SELECT
	st.text
	,qp.query_plan
	,cp.*
FROM sys.dm_exec_cached_plans AS cp
CROSS APPLY sys.dm_exec_sql_text(cp.plan_handle) as st
CROSS APPLY sys.dm_exec_query_plan(cp.plan_handle) AS qp
WHERE
	cp.pool_id = 2
	AND st.dbid = DB_ID(N'AdventureWorks2012')
	AND st.text NOT LIKE N'%sys.%'
	AND st.text NOT LIKE N'%sys .%'
	AND st.text NOT LIKE N'%spt[_]values%';
GO

--run parameterized version of same query
EXEC sp_executesql N'
	SELECT
		ProductID
		,Name
		,ProductNumber
	FROM AdventureWorks2012.Production.Product
	WHERE
		Name LIKE @NameSearch;'
	,N'@NameSearch nvarchar(50)'
	,@NameSearch = 'M%';
GO

--retrieve sql and plans from cache with filters to eliminate noise
--note parameterized plan is reused.
--note index seek and key lookup in plan - bad with many rows
--note OPTION RECOMPILE might be a good option here
SELECT
	st.text
	,qp.query_plan
	,cp.*
FROM sys.dm_exec_cached_plans AS cp
CROSS APPLY sys.dm_exec_sql_text(cp.plan_handle) as st
CROSS APPLY sys.dm_exec_query_plan(cp.plan_handle) AS qp
WHERE
	cp.pool_id = 2
	AND st.dbid = DB_ID(N'AdventureWorks2012')
	AND st.text NOT LIKE N'%sys.%'
	AND st.text NOT LIKE N'%sys .%'
	AND st.text NOT LIKE N'%spt[_]values%';
GO

