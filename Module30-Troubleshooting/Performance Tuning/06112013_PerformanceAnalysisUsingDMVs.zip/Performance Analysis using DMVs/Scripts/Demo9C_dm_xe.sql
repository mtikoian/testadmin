USE AdventureWorks2012;
SET NOCOUNT ON;
GO

--read row 2 with update lock
BEGIN TRAN;
SELECT
	ProductID
	,Name
	,ProductNumber
FROM Production.Product WITH (SERIALIZABLE, UPDLOCK)
WHERE ProductID = 2;
GO

--read row 1 with update lock - this is blocked by Demo9B session
SELECT
	ProductID
	,Name
	,ProductNumber
FROM Production.Product WITH (SERIALIZABLE, UPDLOCK)
WHERE ProductID = 1;
GO

ROLLBACK;
GO