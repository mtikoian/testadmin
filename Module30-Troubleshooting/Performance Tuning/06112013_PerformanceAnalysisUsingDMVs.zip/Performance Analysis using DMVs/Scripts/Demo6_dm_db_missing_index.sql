USE AdventureWorks2012;
SET NOCOUNT ON;
GO

--run query 1 for demo
SELECT FirstName, LastName, MiddleName, BusinessEntityID, ModifiedDate
FROM Person.Person
WHERE 
	FirstName = 'John'
	AND ModifiedDate > '20080101';
GO

--run query 2 for demo
SELECT FirstName, LastName, MiddleName, BusinessEntityID, ModifiedDate
FROM Person.Person
WHERE FirstName = 'John';
GO

--discuss columns
--note equality columns should be specified as leftmost index columns, usually in order of cardinality
--inequality columns should follow equality columns
--both indexes shouldn't be implemented - probably better to just create the composite key one
--included columns were not suggested here but are an option
SELECT *
FROM sys.dm_db_missing_index_details;
GO

--discuss columns
--note aggregated stats
SELECT
	mid.*
	,migs.*
FROM sys.dm_db_missing_index_details AS mid
INNER JOIN sys.dm_db_missing_index_groups AS mig ON mig.index_handle = mid.index_handle
INNER JOIN sys.dm_db_missing_index_group_stats AS migs ON migs.group_handle = mig.index_group_handle
WHERE database_id = DB_ID();
GO

--note columns can be retrieved individually using sys.dm_db_missing_index_columns
SELECT
	mid.*
	,mic.*
FROM sys.dm_db_missing_index_details AS mid
CROSS APPLY sys.dm_db_missing_index_columns(mid.index_handle) AS mic
WHERE database_id = DB_ID();
GO

--note plan cache also includes MissingIndex element
SELECT
	st.text
	,qp.query_plan
FROM sys.dm_exec_cached_plans AS cp
CROSS APPLY sys.dm_exec_sql_text(cp.plan_handle) as st
CROSS APPLY sys.dm_exec_query_plan(cp.plan_handle) AS qp
WHERE
	st.dbid = DB_ID(N'AdventureWorks2012')
	AND st.text NOT LIKE N'%sys.%'
	AND st.text NOT LIKE N'%sys .%'
	AND st.text NOT LIKE N'%spt[_]values%'
	AND qp.query_plan.exist('
		declare default element namespace "http://schemas.microsoft.com/sqlserver/2004/07/showplan";
		//MissingIndexes') = 1;
GO
