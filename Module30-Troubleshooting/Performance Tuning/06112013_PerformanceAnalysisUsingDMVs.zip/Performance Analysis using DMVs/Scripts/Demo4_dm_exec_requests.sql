USE AdventureWorks2012;
SET NOCOUNT ON;
GO

--show sys.dm_exec_connections columns along with last SQL batch
--note auth_scheme should ideally be kerberos for remote connections
SELECT *
FROM sys.dm_exec_connections AS c
CROSS APPLY sys.dm_exec_sql_text(c.most_recent_sql_handle) as st;
GO

--show sys.dm_exec_requests columns along with current statement and plan
SELECT
	st.text
	,SUBSTRING(st.text, (r.statement_start_offset/2)+1, 
		((CASE r.statement_end_offset
			WHEN -1 THEN DATALENGTH(st.text)
			ELSE r.statement_end_offset
		END - r.statement_start_offset)/2) + 1) AS statement_text
	,qp.query_plan
	,r.*
FROM sys.dm_exec_requests AS r
CROSS APPLY sys.dm_exec_sql_text(r.plan_handle) as st
CROSS APPLY sys.dm_exec_query_plan(r.plan_handle) AS qp;
GO

--show columns/rows of sys.dm_exec_plan_attributes for an arbitrary
--note cache key columns - multiple plans may exist for same query that differ only by connection settings
--useful for troubleshooting a query that runs faster or slower depending the invocation methid (e.g. SSMS vs. SSRS)
SELECT *
FROM sys.dm_exec_plan_attributes(<insert-plan_handle_here>) AS pa;
GO

