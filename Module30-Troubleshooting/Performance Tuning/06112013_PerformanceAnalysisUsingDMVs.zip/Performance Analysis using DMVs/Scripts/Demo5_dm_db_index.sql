USE AdventureWorks2012;
SET NOCOUNT ON;
GO

/*
sys.dm_db_index_operational_stats (
    { database_id | NULL | 0 | DEFAULT }
  , { object_id | NULL | 0 | DEFAULT }
  , { index_id | 0 | NULL | -1 | DEFAULT }
  , { partition_number | NULL | 0 | DEFAULT }
)
*/

--discuss columns
SELECT
	SCHEMA_NAME(o.schema_id) AS schema_name
	,OBJECT_NAME(o.object_id) AS object_name
	,i.name AS index_name
	,ios.*
FROM sys.dm_db_index_operational_stats(DB_ID(), DEFAULT, DEFAULT, DEFAULT) AS ios
JOIN sys.objects AS o ON
	o.object_id = ios.object_id
JOIN sys.indexes AS i ON
	i.object_id = ios.object_id
	AND i.index_id = ios.index_id
WHERE ios.database_id = DB_ID();


/*
  sys.dm_db_index_physical_stats ( 
      { database_id | NULL | 0 | DEFAULT }
    , { object_id | NULL | 0 | DEFAULT }
    , { index_id | NULL | 0 | -1 | DEFAULT }
    , { partition_number | NULL | 0 | DEFAULT }
    , { mode | NULL | DEFAULT }
  )
*/

--discuss columns
--note replaces DBCC SHOWCONTIG
--note performance implications with SAMPLED or DETAILED with large tables
SELECT 
	SCHEMA_NAME(o.schema_id) AS schema_name
	,OBJECT_NAME(o.object_id) AS object_name
	,i.name AS index_name
	,ips.*
FROM sys.dm_db_index_physical_stats(DB_ID(), DEFAULT, DEFAULT, DEFAULT, 'DETAILED') AS ips
JOIN sys.objects AS o ON
	o.object_id = ips.object_id
JOIN sys.indexes AS i ON
	i.object_id = ips.object_id
	AND i.index_id = ips.index_id
WHERE ips.database_id = DB_ID();

--discuss columns
SELECT
	SCHEMA_NAME(o.schema_id) AS schema_name
	,OBJECT_NAME(o.object_id) AS object_name
	,i.name AS index_name
	,ius.*
FROM sys.dm_db_index_usage_stats AS ius
JOIN sys.objects AS o ON
	o.object_id = ius.object_id
JOIN sys.indexes AS i ON
	i.object_id = ius.object_id
	AND i.index_id = ius.index_id
WHERE database_id = DB_ID();

