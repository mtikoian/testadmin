USE AdventureWorks2012;
SET NOCOUNT ON;
GO

--discuss columns
SELECT *
FROM sys.dm_xe_session_targets;
GO

--note xml blob in target data
--note some xml knowledge is useful
--note default SSMS XML size limit
SELECT
	DATALENGTH(xst.target_data) AS data_length
	, CAST(xst.target_data AS xml)
	, xst.*
FROM sys.dm_xe_session_targets AS xst;
GO

--run Demo9B.sql and Demo9C.sql to produce deadlock
GO

--select deadlock events from ring buffer
--note detadlock events are included in system_health - no trace flag needed
--note latency with writing events to ring buffer 
--note events may be overwritten in ring buffer
SELECT
    xed.value('@timestamp', 'datetime2(3)') as CreationDate,
    xed.query('.') AS XEvent
 FROM
 (
    SELECT CAST([target_data] AS XML) AS TargetData
    FROM sys.dm_xe_session_targets AS st
       INNER JOIN sys.dm_xe_sessions AS s
          ON s.address = st.event_session_address
       WHERE s.name = N'system_health'
          AND st.target_name = N'ring_buffer'
 ) AS Data
 CROSS APPLY TargetData.nodes('RingBufferTarget/event[@name="xml_deadlock_report"]') AS XEventData (xed)
 ORDER BY CreationDate DESC;
GO

--select deadlock events from current system health event file
SELECT
	CAST(event_data AS xml) AS event_data
FROM sys.dm_xe_sessions AS xs
JOIN sys.dm_xe_session_targets AS xst
          ON xs.address = xst.event_session_address
CROSS APPLY sys.fn_xe_file_target_read_file ( 
	CAST(xst.target_data AS xml).value('/EventFileTarget[1]/File[1]/@name', 'varchar(255)')
	, DEFAULT, DEFAULT, DEFAULT ) AS xft
WHERE
	xs.name = N'system_health'
	AND xst.target_name = N'event_file'
	AND xft.object_name = 'xml_deadlock_report';
GO

--select deadlock events from all system health event files using wildcard path
SELECT
	object_name
	,CAST(event_data AS xml) AS event_data
FROM sys.fn_xe_file_target_read_file ( 
	'C:\Program Files\Microsoft SQL Server\MSSQL11.MSSQLSERVER\MSSQL\Log\system_health_*.xel'
	, DEFAULT
	, DEFAULT
	, DEFAULT ) AS xft
WHERE
	xft.object_name = 'xml_deadlock_report';;
GO
