USE AdventureWorks2012;
SET NOCOUNT ON;
GO

--discuss columns
SELECT *
FROM sys.dm_io_pending_io_requests;
GO

--discuss columns
SELECT *
FROM sys.dm_io_virtual_file_stats(DEFAULT, DEFAULT);
GO

--show stats with file and filegroup info
SELECT
	ds.name AS file_group_name
	,ds.type_desc
	,df.name AS file_name
	,df.physical_name
	,df.state_desc
	,vfs.*
FROM sys.database_files AS df
LEFT JOIN sys.data_spaces AS ds ON ds.data_space_id = df.data_space_id
CROSS APPLY sys.dm_io_virtual_file_stats(DB_ID(), df.file_id) AS vfs
ORDER BY
	file_group_name
	,vfs.file_id;
GO
