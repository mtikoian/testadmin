USE AdventureWorks2012;
SET NOCOUNT ON;
GO

--read row 1
BEGIN TRAN;
SELECT
	ProductID
	,Name
	,ProductNumber
FROM Production.Product WITH (SERIALIZABLE, UPDLOCK)
WHERE ProductID = 1;
GO

--run Demo9C script
GO

--read row 2 with update lock - already locked by Demo9C session, resulting in deadlock
SELECT
	ProductID
	,Name
	,ProductNumber
FROM Production.Product WITH (SERIALIZABLE, UPDLOCK)
WHERE ProductID = 2;
GO

ROLLBACK; --should aready be rolled back
GO