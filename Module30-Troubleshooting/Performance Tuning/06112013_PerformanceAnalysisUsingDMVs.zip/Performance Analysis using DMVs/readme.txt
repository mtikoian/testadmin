Notes
______________________________________________________________________________________

The AdventureWorks2012 database used for the presentation can be downloaded from
CodePlex (http://msftdbprodsamples.codeplex.com/releases/view/55330).

The presentation was done using on SQL Server 2012 SP1.  Some scripts demo SQL 2012 
enhancements (e.g. PlanAffectingConvert warnings) and will not work with earlier versions.
______________________________________________________________________________________

This folder contains the following files:

- Performance Analysis using DMVs.pptx:  Powerpoint presentation
- showplanxml.xsd.xml:  XML schema for slowplan (downloaded from from http://schemas.microsoft.com/sqlserver/2004/07/showplan" xmlns:shp="http://schemas.microsoft.com/sqlserver/2004/07/showplan).

This folder contains the following subfolders:
-  Scripts:  Demo SQL scripts and SSMS 2012 solution/project
-  Visual Studio Projects:  Visual Studio 2012 C# applications for Demo3 of query cache and plans

