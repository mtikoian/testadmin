﻿using System;
using System.Data;
using System.Diagnostics;
using System.Data.SqlClient;

namespace Demo
{
    class Program
    {
        static void Main(string[] args)
        {
            var sw = Stopwatch.StartNew();
            for (int i = 1; i <= 100; ++i)
            {
                var connection = new SqlConnection(@"Data Source=(local);Initial Catalog=AdventureWorks2012;Integrated Security=SSPI");
                connection.Open();
                var command = new SqlCommand("SELECT * FROM Sales.Customer WHERE AccountNumber = @AccountNumber;", connection);

                command.Parameters.AddWithValue("@AccountNumber", "AW00000001");

                var reader = command.ExecuteReader();
                while (reader.Read()) ;
                reader.Close();
                connection.Close();
            }
            sw.Stop();
            Console.WriteLine("Duration {0} ms.", sw.ElapsedMilliseconds);
            Console.ReadKey();
        }
    }
}

