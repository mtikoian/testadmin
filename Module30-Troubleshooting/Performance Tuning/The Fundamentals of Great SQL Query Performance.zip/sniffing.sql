-- Demo #5 -- Parameter sniffing

DROP PROCEDURE GetRecentSales
GO

CREATE PROCEDURE GetRecentSales (@date datetime) AS
BEGIN
    IF @date IS NULL
		SET @date = dateadd("mm",-3,(SELECT MAX(OrderDate)
									FROM Sales.SalesOrderHeader))

	SELECT * 
	FROM Sales.SalesOrderHeader h
		INNER JOIN Sales.SalesOrderDetail d 
			ON h.SalesOrderID = d.SalesOrderID
	WHERE h.OrderDate > @date
END


EXEC GetRecentSales NULL
GO

EXEC GetRecentSales '4/30/2008'
GO

EXEC GetRecentSales '1/1/2006'
GO

--  Demo #6 -- anti-sniffing techniques

DROP PROCEDURE GetRecentSales

GO

CREATE PROCEDURE GetRecentSales (@date datetime) --WITH RECOMPILE -- 1.  recompilation
AS
BEGIN
-- 2. masking
--		DECLARE @datemask datetime
--		SET @datemask = @date
		 		
	SELECT * 
	FROM Sales.SalesOrderHeader h
		INNER JOIN Sales.SalesOrderDetail d 
			ON h.SalesOrderID = d.SalesOrderID
	WHERE h.OrderDate > @date
	-- WHERE h.OrderDate > @datemask -- 2. masking
	--OPTION (OPTIMIZE FOR (@date = '1/1/2007')) -- 3. OPTIMIZE FOR
	--OPTION (OPTIMIZE FOR UNKNOWN) -- 4. OPTIMIZE FOR UKNOWN
END

GO

EXEC GetRecentSales NULL
GO

EXEC GetRecentSales '4/30/2008'
GO

EXEC GetRecentSales '1/1/2006'
GO

-- 5. Refactoring
GO

DROP PROCEDURE GetRecentSales2
DROP PROCEDURE GetRecentSalesHelper

GO

CREATE PROCEDURE GetRecentSalesHelper (@date datetime) AS
BEGIN
	SELECT * 
	FROM Sales.SalesOrderHeader h
		INNER JOIN Sales.SalesOrderDetail d 
			ON h.SalesOrderID = d.SalesOrderID
	WHERE h.OrderDate > @date
END

GO

CREATE PROCEDURE GetRecentSales2 (@date datetime)  AS
BEGIN
    IF @date IS NULL
		SET @date = dateadd("mm",-3,(SELECT MAX(OrderDATE)
                                     FROM Sales.SalesOrderHeader))
    EXEC GetRecentSalesHelper @date
END

GO


EXEC GetRecentSales2 NULL
GO

EXEC GetRecentSales2 '1/1/2006'
GO