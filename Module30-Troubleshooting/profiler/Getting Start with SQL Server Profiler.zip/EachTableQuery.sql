USe AdventureWorks
Go

sp_msforeachtable 'Select * from ?'

Go 30