If Not Exists(Select * From msdb.dbo.sysjobhistory H Join msdb.dbo.sysjobs J On 
            H.job_id = J.job_Id where h.run_status = 4 And J.name = 'Backup REportServer' )
    Begin
        exec msdb.dbo.sp_start_job @job_name = 'Backup REportServer'
    End

Waitfor Delay '00:00:10'

If Not Exists(Select * From msdb.dbo.sysjobhistory H Join msdb.dbo.sysjobs J On 
            H.job_id = J.job_Id where h.run_status = 4 And J.name = 'MaintenancePlan.Subplan_1' )
    Begin
        exec msdb.dbo.sp_start_job @job_name = 'MaintenancePlan.Subplan_1'
    End
Waitfor Delay '00:00:10'

Go 10