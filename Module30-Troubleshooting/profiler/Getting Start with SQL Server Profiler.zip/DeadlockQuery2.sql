USE AdventureWorks
Go

Begin Transaction
    Update Production.Product
        Set Name = Name + 'Test'
    Where
        ProductId = 317

    WaitFor Delay '00:00:05'

    Update Person.Contact
        Set LastName = LastName + 'Test'
    Where
        ContactID = 11 

Rollback Transaction
