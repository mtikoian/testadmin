USE AdventureWorks
Go

Select
    *
From
    Person.Contact

Go 12
Select 
    ContactID, 
    NameStyle, 
    Title, 
    FirstName, 
    MiddleName, 
    LastName, 
    Suffix, 
    EmailAddress, 
    EmailPromotion, 
    Phone, 
    PasswordHash, 
    PasswordSalt, 
    AdditionalContactInfo, 
    rowguid, 
    ModifiedDate
From
    Person.Contact
Where
    LastName Like 'C%'

WaitFor Delay '00:00:05'

Go 12