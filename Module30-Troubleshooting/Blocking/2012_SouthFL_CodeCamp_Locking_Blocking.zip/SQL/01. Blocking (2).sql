/**********************************************************************
Code Camp South FL 2012

Dmitri Korotkevitch: Locking and Blocking for Developers

Blocking and Deadlock demo
Session 2
**********************************************************************/
use CodeCampSouthFL
go

if exists (
	select * 
	from sys.procedures p join sys.schemas s on
		p.schema_id = s.schema_id
	where s.name = 'dbo' and p.name = 'BlockingProc'
)
	drop proc dbo.BlockingProc
go

create proc dbo.BlockingProc
as
begin
	set nocount on
	set transaction isolation level read committed

	begin tran	
		update dbo.SmallRow set CharField = 'abc' where ID = 1000
		print 'First Update is done'
		
		update dbo.SmallRow set CharField = 'abc' where IntField = 1000
		print 'Second Update is done'
	commit
end
go


sp_configure 'show advanced options', 1
GO
RECONFIGURE
GO
sp_configure 'blocked process threshold', 10
GO
RECONFIGURE
GO

exec dbo.BlockingProc