/**********************************************************************
Code Camp South FL 2012

Dmitri Korotkevitch: Locking and Blocking for Developers

Snapshot isolation behavior
Session 2
**********************************************************************/
use CodeCampSouthFL
go


-- Session 2
set transaction isolation level read committed
begin tran
	update dbo.Colors	
	set
		Color = 'Black'
	where
		Color = 'White'
commit
go

set transaction isolation level snapshot
begin tran
	update dbo.Colors	
	set
		Color = 'Black'
	where
		Color = 'White'
commit
go
