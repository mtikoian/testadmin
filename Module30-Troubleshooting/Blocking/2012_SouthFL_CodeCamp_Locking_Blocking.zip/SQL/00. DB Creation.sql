/**********************************************************************
Code Camp South FL 2012

Dmitri Korotkevitch: 2.5 hours with the guy who barely speaks English

DB Creation script
**********************************************************************/

set nocount on
set xact_abort on
go

use CodeCampSouthFL
go

if exists(
	select * 
	from sys.tables t join sys.schemas s on t.schema_id = s.schema_id
	where s.name = 'dbo' and t.name = 'LargeRow'
)
	drop table dbo.LargeRow
go

create table dbo.LargeRow
(
	ID int not null,
	IntField int not null, 
	CharField char(2000) not null,
	
	constraint PK_LargeRow
	primary key clustered(Id)
)
go


if exists(
	select * 
	from sys.tables t join sys.schemas s on t.schema_id = s.schema_id
	where s.name = 'dbo' and t.name = 'SmallRow'
)
	drop table dbo.SmallRow
go

create table dbo.SmallRow
(
	ID int not null,
	IntField int not null, 
	CharField varchar(2000) not null,
	
	constraint PK_SmallRow
	primary key clustered(Id)
)
go


if exists(
	select * 
	from sys.tables t join sys.schemas s on t.schema_id = s.schema_id
	where s.name = 'dbo' and t.name = 'MainData'
)
	drop table dbo.MainData
go

create table dbo.MainData
(
	ID int not null,
	IntField int not null, 
	
	constraint PK_MainData
	primary key clustered(Id)
)
go


if exists(
	select * 
	from sys.tables t join sys.schemas s on t.schema_id = s.schema_id
	where s.name = 'dbo' and t.name = 'BlobData'
)
	drop table dbo.BlobData
go

create table dbo.BlobData
(
	ID int not null,
	CharField char(2000) not null,
	
	constraint PK_BlobData
	primary key clustered(Id),

	constraint FK_BlobData_MainData
	foreign key(ID) references dbo.MainData(ID)
	on delete cascade
)
go

declare
	@I int = 0
	
begin tran
	while @I < 50000
	begin
		insert into dbo.LargeRow(Id, IntField,CharField) values(@I, @I, 'abc')
		insert into dbo.SmallRow(Id, IntField,CharField) values(@I, @I, 'abc')
		
		insert into dbo.MainData(Id, IntField)	values(@I, @I)
		insert into dbo.BlobData(ID, CharField)	values(@I, 'abc')
		select @I = @I + 1
	end
commit
go


if exists(
	select * 
	from sys.tables t join sys.schemas s on t.schema_id = s.schema_id
	where s.name = 'dbo' and t.name = 'IndexDemo'
)
	drop table dbo.IndexDemo
go

create table dbo.IndexDemo
(
	Id int not null identity(1,1),
	Name char(20) not null,
	Placeholder char(379) not null,

	constraint PK_IndexDemo 
	primary key clustered(id)
)
go

declare
	@First int = 0
	,@Second int
	,@Third int
	,@C char(3)
	,@I int 	
begin tran
	while @First < 26
	begin
		select @Second = 0
		while @Second < 26
		begin
			select @Third = 0
			while @Third < 26
			begin
				select @C = CHAR(65 + @First) + CHAR(65 + @Second) + CHAR(65 + @Third)
				insert into dbo.IndexDemo(Name,Placeholder) 
				values(@C,'a'), (@C,'a'), (@C,'a'), (@C,'a'), (@C,'a')
				select @Third = @Third + 1
			end
			select @Second = @Second + 1
		end
		select @First = @First + 1
	end
commit				 

create index IDX_IndexDemo_Name on dbo.IndexDemo(Name)
go





if not exists (select * from sys.schemas where name = 'Delivery')
	exec sp_executesql N'CREATE SCHEMA [Delivery] AUTHORIZATION [dbo]'
GO

if exists(
	select * 
	from sys.tables t join sys.schemas s on t.schema_id = s.schema_id
	where s.name = 'Delivery' and t.name = 'Customers'
)
	drop table Delivery.Customers
go

create table Delivery.Customers
(
	CustomerID int not null identity(1,1),
	Name varchar(100) not null,
	Phone varchar(20) not null,
	ContactName varchar(100) not null,
	BillingAddress varchar(100) not null,
	BillingCity varchar(40) not null,
	BillingState char(2) not null,
	BillingZip char(5) not null,
	DefaultRatePlan int null,
	DefaultService int null,
	RegionId int not null,
		
	constraint PK_Customers
	primary key clustered(CustomerID)
)
go

if exists(
	select * 
	from sys.tables t join sys.schemas s on t.schema_id = s.schema_id
	where s.name = 'Delivery' and t.name = 'Addresses'
)
	drop table Delivery.Addresses
go

create table Delivery.Addresses
(
	AddressId int not null identity(1,1),
	CustomerId int not null,
	Address varchar(100) not null,
	City varchar(40) not null,
	State char(2) not null,
	Zip char(5) not null,
	Direction varchar(1024) null,	

	constraint PK_Addresses
	primary key clustered(AddressID)
)
go

if exists(
	select * 
	from sys.tables t join sys.schemas s on t.schema_id = s.schema_id
	where s.name = 'Delivery' and t.name = 'Services'
)
	drop table Delivery.Services
go

create table Delivery.Services
(
	ServiceID int not null,
	Name varchar(40) not null,
	
	constraint PK_Services
	primary key clustered(ServiceID)
)
go


if exists(
	select * 
	from sys.tables t join sys.schemas s on t.schema_id = s.schema_id
	where s.name = 'Delivery' and t.name = 'RatePlans'
)
	drop table Delivery.RatePlans
go

create table Delivery.RatePlans
(
	RatePlanID int not null,
	Name varchar(40) not null,
	
	constraint PK_RatePlans
	primary key clustered(RatePlanID)
)
go

if exists(
	select * 
	from sys.tables t join sys.schemas s on t.schema_id = s.schema_id
	where s.name = 'Delivery' and t.name = 'Rates'
)
	drop table Delivery.Rates
go

create table Delivery.Rates
(
	RatePlanID int not null,
	ServiceId int not null,
	Rate smallmoney,
	
	constraint PK_Rates
	primary key clustered(RatePlanID, ServiceId)
)
go

if exists(
	select * 
	from sys.tables t join sys.schemas s on t.schema_id = s.schema_id
	where s.name = 'Delivery' and t.name = 'Drivers'
)
	drop table Delivery.Drivers
go

create table Delivery.Drivers
(
	DriverId int not null identity(1,1),
	Name varchar(40) not null,

	constraint PK_Drivers
	primary key clustered(DriverID)
)
go

if exists(
	select * 
	from sys.tables t join sys.schemas s on t.schema_id = s.schema_id
	where s.name = 'Delivery' and t.name = 'OrderStatuses'
)
	drop table Delivery.OrderStatuses
go

create table Delivery.OrderStatuses
(
	OrderStatusId int not null identity(1,1),
	Name varchar(40) not null,
	
	constraint PK_OrderStatuses
	primary key clustered(OrderStatusID)
)
go

if exists(
	select * 
	from sys.tables t join sys.schemas s on t.schema_id = s.schema_id
	where s.name = 'Delivery' and t.name = 'Orders'
)
	drop table Delivery.Orders
go

create table Delivery.Orders
(
	OrderId int not null identity(1,1),
	OrderDate smalldatetime not null, 
	OrderNum varchar(20) not null,
	Reference varchar(64) null,
	CustomerId int not null,
	PickupAddressId int not null,
	DeliveryAddressId int not null,
	ServiceId int not null,
	RatePlanId int not null,
	OrderStatusId int not null,
	DriverId int null,
	Pieces smallint not null,
	Amount smallmoney not null,
	ModTime datetime2(0) not null
		constraint DEF_Orders_ModTime
		default getDate(),
	PlaceHolder char(100) not null
		constraint DEF_Orders_Placeholder
		default 'Placeholder',
		
	constraint PK_Orders
	primary key clustered(OrderId)
)
go

if exists(
	select * 
	from sys.procedures p join sys.schemas s on p.schema_id = s.schema_id
	where s.name = 'Delivery' and p.name = 'InsertAddress'
)
	drop proc Delivery.InsertAddress
go

create proc Delivery.InsertAddress
(
	@CustomerId int, 
	@AddressId int output
)
as
begin
	set nocount on
	set xact_abort on
	
	begin tran
		insert into Delivery.Addresses(CustomerId,Address,City,State,Zip,Direction) 
		values(@CustomerId, '456 Main Street', 'Tampa', 'FL', '33607', REPLICATE(' ',200));
		select @Addressid = @@identity
	commit
end
go


begin tran
	insert into Delivery.OrderStatuses(Name)
		select 'NEW' union all 
		select 'DISPATCHED' union all
		select 'IN ROUTE' union all
		select 'COMPLETED'
		
	insert into Delivery.Services(ServiceID,Name)
		select 1, 'BASE' union all
		select 2, 'RUSH' union all
		select 3, '2-HOURS' 
		
	insert into Delivery.RatePlans(RatePlanID, Name)
		select 1, 'REGULAR' union all
		select 2, 'CORPORATE' 

	insert into Delivery.Rates(ServiceId, RatePlanID, Rate)
		select 1, 1, 15 union all select 1, 2, 10 union all
		select 2, 1, 25 union all select 2, 2, 20 union all
		select 3, 1, 35 union all select 3, 2, 30
		
	declare
		@CustomerId int
		,@AddressId int
		
	select @CustomerId = 1
	
	while @CustomerId <= 1000
	begin
		insert into Delivery.Customers(Name, Phone, ContactName, 
			BillingAddress, BillingCity, BillingState, BillingZip,
			DefaultRatePlan, DefaultService, RegionId)
		values('Customer # ' + convert(varchar(5), @CustomerId), '813-123-4567',
		'Contact for Customer # ' + convert(varchar(5), @CustomerId),'123 Main Street',
		'Tampa', 'FL','33607',@CustomerId % 3, 1, @CustomerId % 50)
		
		select @AddressId = 0
		while @AddressId < 20
		begin
			insert into Delivery.Addresses(CustomerId,Address,City,State,Zip,Direction)
			values(@CustomerId, '456 Main Street', 'Tampa', 'FL', '33607', REPLICATE(' ',200))
			
			select @AddressId = @AddressId + 1
		end
		select @CustomerId = @CustomerId + 1
	end

	declare
		@DriverId int
		
	select @DriverId = 1
	
	while @DriverId <= 100
	begin
		insert into Delivery.Drivers(Name)
		values('Driver # ' + convert(varchar(5), @DriverId))
		
		select @DriverId = @DriverId + 1
	end
	
	declare
		@OrderId int
		,@Address2 int
		,@OrderDateOffset int
		,@ServiceId int
		,@RatePlanId int
		,@OrderStatusId int
		,@Pieces int
		,@Amount smallmoney
		
	select 
		@OrderId = 0
		
	while @OrderId < 500000
	begin
		select @CustomerId = convert(int,RAND() * 1000.0) + 1

		select @AddressId = (@CustomerId - 1) * 20 + convert(int,RAND() * 20.0) + 1
		select @Address2 = @AddressId
		while @Address2 = @AddressId
		begin
			select @Address2 = (@CustomerId - 1) * 20 + convert(int,RAND() * 20.0) + 1
		end

		select @OrderDateOffset = convert(int,RAND() * 365.0 * 24 * 60)
		select @RatePlanId = convert(int,RAND() * 2) + 1
		select @ServiceId = convert(int,RAND() * 3) + 1
		select @Amount = Rate from Delivery.Rates where ServiceId = @ServiceId and RatePlanID = @RatePlanId
		if @OrderDateOffset > 5 * 24 * 60
			select @OrderStatusId = 4
		else
			select @OrderStatusId = convert(int,RAND() * 4) + 1
		if @OrderStatusId in (1,4)
			select @DriverId = null
		else
			select @DriverId = convert(int,RAND() * 50) + 1
		select @Pieces = convert(int,RAND() * 5) + 1
		
		insert into Delivery.Orders(OrderDate, OrderNum, Reference, CustomerId,
			PickupAddressId, DeliveryAddressId, ServiceId, RatePlanId,
			OrderStatusId, DriverId, Pieces, Amount)
		values(DATEADD(MINUTE, -@OrderDateOffset, GETDATE()),CONVERT(varchar(10),@OrderId),NULL,@CustomerId,
			@AddressId, @Address2, @ServiceId, @RatePlanId,
			@OrderStatusId, @DriverId, @Pieces, @Amount)

		select @OrderId = @OrderId + 1		
	end
commit
go

/* CHECKS */
select count(*) from Delivery.Orders

select OrderStatusId, COUNT(*) from Delivery.Orders group by OrderStatusId

select * from Delivery.Orders o
where exists 
	(
		select * 
		from Delivery.Addresses a 
		where o.DeliveryAddressId = a.AddressId and o.CustomerId <> a.CustomerId
	) or
	exists 
	(
		select * 
		from Delivery.Addresses a 
		where o.PickupAddressId = a.AddressId and o.CustomerId <> a.CustomerId
	)	
go	

	
	