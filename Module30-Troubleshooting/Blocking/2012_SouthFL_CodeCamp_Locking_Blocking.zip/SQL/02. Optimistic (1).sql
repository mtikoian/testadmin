/**********************************************************************
Code Camp South FL 2012

Dmitri Korotkevitch: Locking and Blocking for Developers

Snapshot isolation behavior
Session 1
**********************************************************************/
use CodeCampSouthFL
go


alter database CodeCampSouthFL 
set SINGLE_USER
with rollback immediate
go

alter database CodeCampSouthFL 
set ALLOW_SNAPSHOT_ISOLATION on
go

alter database CodeCampSouthFL 
set MULTI_USER
go


if exists (
	select * 
	from sys.tables t join sys.schemas s on
		t.schema_id = s.schema_id
	where s.name = 'dbo' and t.name = 'Colors'
)
	drop table dbo.Colors
go

create table dbo.Colors
(
	ID int not null,
	Color varchar(32)
)
go

truncate table dbo.Colors
insert into dbo.Colors(ID, Color)
values(1,'White'), (2,'Black')
go

select * from dbo.Colors
go

-- Session 1
set transaction isolation level read committed
begin tran
	update dbo.Colors	
	set
		Color = 'White'
	where
		Color = 'Black'
commit
go

select * from dbo.Colors
go



set transaction isolation level snapshot
begin tran
	update dbo.Colors	
	set
		Color = 'White'
	where
		Color = 'Black'
commit
go

select * from dbo.Colors
go