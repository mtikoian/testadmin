/**********************************************************************
Code Camp South FL 2012

Dmitri Korotkevitch: Locking and Blocking for Developers

Demo and Analysis scripts

**********************************************************************/

use CodeCampSouthFL
go


/*********************** LOCKING & BLOCKING WAITS **********************************/

-- List of locks
select * from sys.dm_tran_locks
go

/*
Shows current locks. Even if it works across all database, ObjectName 
populates for current database only. Could be modified with dynamic SQL if needed

Be careful with Query text for LOCKS with GRANT status. This represents currently active
request for this specific session id which could be different than query which produced locks
It also could be NULL if there are no active requests for this session
*/

select
	TL1.resource_type
	,DB_NAME(TL1.resource_database_id) as [DB Name]
	,CASE TL1.resource_type
		WHEN 'OBJECT' THEN OBJECT_NAME(TL1.resource_associated_entity_id, TL1.resource_database_id)
		WHEN 'DATABASE' THEN 'DB'
		ELSE
			CASE 
				WHEN TL1.resource_database_id = DB_ID() 
				THEN
					(
						select OBJECT_NAME(object_id, TL1.resource_database_id)
						from sys.partitions
						where hobt_id = TL1.resource_associated_entity_id
					)
				ELSE
					'(Run under DB context)'
			END
	END as ObjectName
	,TL1.resource_description
	,TL1.request_session_id
	,TL1.request_mode
	,TL1.request_status
	,WT.wait_duration_ms as [Wait Duration (ms)]
	,(
		select
			SUBSTRING(
				S.Text, 
				(ER.statement_start_offset / 2) + 1,
				((
					CASE 
						ER.statement_end_offset
					WHEN -1 
						THEN DATALENGTH(S.text)
						ELSE ER.statement_end_offset
					END - ER.statement_start_offset) / 2) + 1)		
		from 
			sys.dm_exec_requests ER 
				cross apply sys.dm_exec_sql_text(ER.sql_handle) S
		where
			TL1.request_session_id = ER.session_id
	 ) as [Query]
from
	sys.dm_tran_locks as TL1 left outer join sys.dm_os_waiting_tasks WT on
		TL1.lock_owner_address = WT.resource_address and TL1.request_status = 'WAIT'
where
	TL1.request_session_id <> @@SPID
order by
	TL1.request_session_id
go



/*
Shows blocked and blocking processes. Even if it works across all database, ObjectName 
populates for current database only. Could be modified with dynamic SQL if needed

Be careful with Query text for BLOCKING session. This represents currently active
request for this specific session id which could be different than query which produced locks
It also could be NULL if there are no active requests for this session
*/
select
	TL1.resource_type
	,DB_NAME(TL1.resource_database_id) as [DB Name]
	,CASE TL1.resource_type
		WHEN 'OBJECT' THEN OBJECT_NAME(TL1.resource_associated_entity_id, TL1.resource_database_id)
		WHEN 'DATABASE' THEN 'DB'
		ELSE
			CASE 
				WHEN TL1.resource_database_id = DB_ID() 
				THEN
					(
						select OBJECT_NAME(object_id, TL1.resource_database_id)
						from sys.partitions
						where hobt_id = TL1.resource_associated_entity_id
					)
				ELSE
					'(Run under DB context)'
			END
	END as ObjectName
	,TL1.resource_description
	,TL1.request_session_id
	,TL1.request_mode
	,TL1.request_status
	,WT.wait_duration_ms as [Wait Duration (ms)]
	,(
		select
			SUBSTRING(
				S.Text, 
				(ER.statement_start_offset / 2) + 1,
				((
					CASE 
						ER.statement_end_offset
					WHEN -1 
						THEN DATALENGTH(S.text)
						ELSE ER.statement_end_offset
					END - ER.statement_start_offset) / 2) + 1)		
		from 
			sys.dm_exec_requests ER 
				cross apply sys.dm_exec_sql_text(ER.sql_handle) S
		where
			TL1.request_session_id = ER.session_id
	 ) as [Query]
from
	sys.dm_tran_locks as TL1 join sys.dm_tran_locks TL2 on
		TL1.resource_associated_entity_id = TL2.resource_associated_entity_id
	left outer join sys.dm_os_waiting_tasks WT on
		TL1.lock_owner_address = WT.resource_address and TL1.request_status = 'WAIT'

where
	TL1.request_status <> TL2.request_status and
	(
		TL1.resource_description = TL2.resource_description OR
		(TL1.resource_description is null and TL2.resource_description is null)
	)
go



/* Set blocked process threashold to 5 seconds. Required for Blocked Process event in SQL Profiler */
sp_configure 'show advanced options', 1
GO
RECONFIGURE
GO
sp_configure 'blocked process threshold', 5
GO
RECONFIGURE
GO


/* When you have the handle.. */
declare
	@Start int = ?
	,@End int = ?
	,@H varbinary(64) = ?

select 	
	SUBSTRING(qst.text, (@Start / 2) + 1, (@End - @Start)/2 + 1)
	,qp.query_plan
from 
	sys.dm_exec_sql_text(@H) qst 
	cross join sys.dm_exec_query_stats qs
		outer apply sys.dm_exec_query_plan(qs.plan_handle) qp
where
	qs.sql_handle = @H
	
go

	

/* Write deadlock information into Sql Server log */
DBCC TRACEON (1222, -1)
go

-- Clear wait statistics
DBCC SQLPERF ('sys.dm_os_wait_stats', CLEAR)
go

-- Shows TOP waits in the system
SELECT 
	wait_type, wait_time_ms, 
	convert(decimal(7,4), 100.0 * wait_time_ms / SUM(wait_time_ms) OVER()) AS [Percent]
from 
	 sys.dm_os_wait_stats
where 
	wait_type NOT IN ('CLR_SEMAPHORE','LAZYWRITER_SLEEP','RESOURCE_QUEUE','SLEEP_TASK'
	,'SLEEP_SYSTEMTASK','SQLTRACE_BUFFER_FLUSH','WAITFOR', 'LOGMGR_QUEUE','CHECKPOINT_QUEUE'
	,'REQUEST_FOR_DEADLOCK_SEARCH','XE_TIMER_EVENT','BROKER_TO_FLUSH','BROKER_TASK_STOP',
	'CLR_MANUAL_EVENT','CLR_AUTO_EVENT','DISPATCHER_QUEUE_SEMAPHORE', 'FT_IFTS_SCHEDULER_IDLE_WAIT'
	,'XE_DISPATCHER_WAIT', 'XE_DISPATCHER_JOIN')
order by 
	[Percent] Desc
go

-- Shows Signal wait time (how long worker waits in Runnable queue) vs Total wait time
-- High % of signal waits could indicate CPU starvation
select 
	sum(signal_wait_time_ms) as [Signal Wait Time (ms)]
	,convert(decimal(7,4), 100.0 * sum(signal_wait_time_ms) / sum (wait_time_ms)) as [% Signal waits]
	,sum(wait_time_ms - signal_wait_time_ms) as [Resource Wait Time (ms)]
	,convert(decimal(7,4), 100.0 * sum(wait_time_ms - signal_wait_time_ms) / sum (wait_time_ms)) as [% Resource waits]
from
	sys.dm_os_wait_stats
go

/*********************** Most expensive queries by IO *************************/
SELECT TOP 50 
	SUBSTRING(qt.TEXT, (qs.statement_start_offset/2)+1,
		((
			CASE qs.statement_end_offset
				WHEN -1 THEN DATALENGTH(qt.TEXT)
				ELSE qs.statement_end_offset
			END - qs.statement_start_offset)/2)+1),
	qs.execution_count,
	(qs.total_logical_reads + qs.total_logical_writes) / qs.execution_count as [Avg IO],
	qp.query_plan,
	qs.total_logical_reads, qs.last_logical_reads,
	qs.total_logical_writes, qs.last_logical_writes,
	qs.total_worker_time,
	qs.last_worker_time,
	qs.total_elapsed_time/1000 total_elapsed_time_in_ms,
	qs.last_elapsed_time/1000 last_elapsed_time_in_ms,
	qs.last_execution_time
FROM 
	sys.dm_exec_query_stats qs
		CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle) qt
		CROSS APPLY sys.dm_exec_query_plan(qs.plan_handle) qp
ORDER BY 
	[Avg IO] DESC
go
/*********************** I/O Stalls ****************************************/
Select 
	d.name as [Database Name],
	mf.name as [File Name],
	mf.physical_name,
	mf.type_desc,
	s.*
from 
	sys.databases d join sys.master_files mf on
		mf.database_id = d.database_id
	join sys.dm_io_virtual_file_stats(null, null) s on
		mf.database_id = s.database_id and s.file_id = mf.file_id
go
  
/*********************** PLAN REUSE ****************************************/
select top 50
	qs.sql_handle
	,qs.plan_handle
	,cp.cacheobjtype
	,cp.usecounts
	,cp.size_in_bytes  
	,qs.statement_start_offset
	,qs.statement_end_offset
	,qt.dbid
	,qt.objectid
	,qt.text
	,SUBSTRING(qt.text,qs.statement_start_offset/2, 
	(case 
		when qs.statement_end_offset = -1 
        then len(convert(nvarchar(max), qt.text)) * 2 
        else qs.statement_end_offset 
	end - qs.statement_start_offset)/2) as [Statement]
FROM 
	sys.dm_exec_query_stats qs
		cross apply sys.dm_exec_sql_text(qs.sql_handle) as qt
	join sys.dm_exec_cached_plans as cp on 
		qs.plan_handle=cp.plan_handle
where 
	cp.plan_handle=qs.plan_handle and 
	qt.dbid = db_id()
order by
	[Usecounts] ASC
go

/*********************** INDEX MAINTENANCE **********************************/

/* Usage Statistics */
select t.name as [Table Name], idx.name as [Index Name]
	,st.* 
from 
	sys.tables t join sys.indexes idx on
		t.object_id = idx.object_id
	left outer join sys.dm_db_index_usage_stats st on
		st.index_id = idx.index_id and idx.object_id = st.object_id
order by 
	t.name, idx.Name
go

/* Physical Stats */
/* Latest parameter controls the mode. Be careful with DETAILED mode in production */
select t.name as [Table Name], idx.name as [Index Name]
	,st.* 
from 
	sys.tables t join sys.indexes idx on
		t.object_id = idx.object_id
	left outer join sys.dm_db_index_physical_stats(DB_ID(),null,null,null,'LIMITED') st on
		st.index_id = idx.index_id and idx.object_id = st.object_id
order by 
	t.name, idx.Name
go


/* Operational Stats */
select t.name as [Table Name], idx.name as [Index Name]
	,st.* 
from 
	sys.tables t join sys.indexes idx on
		t.object_id = idx.object_id
	left outer join sys.dm_db_index_operational_stats (DB_ID(),null,null,null) st on
		st.index_id = idx.index_id and idx.object_id = st.object_id
order by 
	t.name, idx.Name
go



/* Missing Indexes */
select 
	d.object_id, d.equality_columns, d.inequality_columns, d.included_columns,  d.statement as [Table]
	,s.user_scans, s.user_seeks, s.last_user_seek, s.avg_user_impact
from 
	sys.dm_db_missing_index_details d join sys.dm_db_missing_index_groups g on 
		d.index_handle = g.index_handle
	join sys.dm_db_missing_index_group_stats s on 
		s.group_handle = g.index_group_handle
where 
	d.database_id = DB_ID() 
order by 
	s.avg_total_user_cost * s.avg_user_impact * (s.user_seeks + s.user_scans) DESC
go



