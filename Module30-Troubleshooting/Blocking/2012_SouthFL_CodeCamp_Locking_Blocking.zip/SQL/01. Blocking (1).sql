/**********************************************************************
Code Camp South FL 2012

Dmitri Korotkevitch: Locking and Blocking for Developers

Blocking and Deadlock demo
Session 1
**********************************************************************/
use CodeCampSouthFL
go

begin tran
	-- Let's place (X) lock on the row
	update dbo.SmallRow set CharField = 'abc' where Id=500

	-- Emulating deadlock
	-- update dbo.SmallRow set CharField = 'abc' where IntField=9999

--rollback

