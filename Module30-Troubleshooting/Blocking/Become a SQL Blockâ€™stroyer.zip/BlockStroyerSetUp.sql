CREATE DATABASE BlockStroyer
ALTER DATABASE BlockStroyer SET RECOVERY SIMPLE
GO
USE BlockStroyer
GO
/*copied from http://sqlmag.com/sql-server/virtual-auxiliary-table-numbers
originally posted by Itzik Ben-Gan*/
IF OBJECT_ID('dbo.GetNums') IS NOT NULL 
    DROP FUNCTION dbo.GetNums;

GO

CREATE FUNCTION dbo.GetNums (@n AS BIGINT)
RETURNS TABLE
AS

RETURN
    WITH    L0
              AS (SELECT    1 AS c
                  UNION ALL
                  SELECT    1),
            L1
              AS (SELECT    1 AS c
                  FROM      L0 AS A
                            CROSS JOIN L0 AS B),
            L2
              AS (SELECT    1 AS c
                  FROM      L1 AS A
                            CROSS JOIN L1 AS B),
            L3
              AS (SELECT    1 AS c
                  FROM      L2 AS A
                            CROSS JOIN L2 AS B),
            L4
              AS (SELECT    1 AS c
                  FROM      L3 AS A
                            CROSS JOIN L3 AS B),
            L5
              AS (SELECT    1 AS c
                  FROM      L4 AS A
                            CROSS JOIN L4 AS B),
            Nums
              AS (SELECT    ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS n
                  FROM      L5)
    SELECT  n
    FROM    Nums
    WHERE   n<=@n;

GO
/*Everything has 5 rows / page*/
CREATE TABLE SimpleBlocking (id INT NOT NULL, filler CHAR(1600) NOT NULL)
CREATE TABLE EscalationBlocking (id INT NOT NULL, filler CHAR(1600) NOT NULL)
CREATE UNIQUE CLUSTERED INDEX IX_EscalationBlocking_1 ON EscalationBlocking (id)
CREATE TABLE SimpleDeadlock (id INT NOT NULL, filler CHAR(1600) NOT NULL)



GO


INSERT INTO SimpleBlocking (id, filler)
SELECT n, n FROM dbo.GetNums (1000)

INSERT INTO EscalationBlocking (id, filler)
SELECT n, n FROM dbo.GetNums(50000)

INSERT INTO SimpleDeadlock (id, filler)
SELECT n, n FROM dbo.GetNums (1000)
