USE master
go
EXEC sp_configure 'show advanced options', 1
go
reconfigure
go
EXEC sp_configure 'blocked process threshold', 10
go
reconfigure
GO
EXEC sp_configure 'show advanced options', 0
go
reconfigure
go
DECLARE @IsBroker tinyint, @IsTrustworthy tinyint

SELECT @IsBroker = is_broker_enabled,
@IsTrustworthy = is_trustworthy_on
FROM sys.databases WHERE name = 'Apparatus_DBA'

IF @IsBroker = 0
	ALTER DATABASE Apparatus_DBA SET ENABLE_BROKER

IF @IsTrustworthy = 0
	ALTER DATABASE Apparatus_DBA SET TRUSTWORTHY ON
GO
USE Apparatus_DBA
GO
IF EXISTS ( SELECT  NAME
            FROM    sys.tables
            WHERE   name = 'BlockedProcessActivationErrors' ) 
    DROP TABLE BlockedProcessActivationErrors
GO
CREATE TABLE BlockedProcessActivationErrors
    (ID INT IDENTITY NOT NULL,
	ErrorDate datetime default (getdate()) NOT NULL,
	ErrorNumber bigint NOT NULL,
	ErrorMessage nvarchar(2048) NULL,
	DatabaseContext sysname NULL,
	PollDate datetime NULL)

	ALTER TABLE BlockedProcessActivationErrors ADD CONSTRAINT PK_BlockedProcessActivationErrors PRIMARY KEY CLUSTERED (ID)
	CREATE NONCLUSTERED INDEX IX_BlockedProcessActiviationErrors_1 ON BlockedProcessActivationErrors (PollDate)
GO
IF EXISTS ( SELECT  NAME
            FROM    sys.tables
            WHERE   name = 'BlockedProcesses' ) 
    DROP TABLE BlockedProcesses
GO
CREATE TABLE BlockedProcesses
(
	ID INT IDENTITY NOT NULL,
	EventMessage XML NULL,
	TransactionID BIGINT NOT NULL,
	InitialEventDate DATETIME DEFAULT (GETDATE()) NOT NULL,
	FinalEventDate DATETIME DEFAULT (GETDATE()) NOT NULL,
	Duration bigint NULL,
	PollDate DATETIME NULL)

ALTER TABLE BlockedProcesses ADD CONSTRAINT PK_BlockedProcesses PRIMARY KEY CLUSTERED (TransactionID)
CREATE NONCLUSTERED INDEX IX_BlockedProcesses1 ON BlockedProcesses (PollDate)
go
IF EXISTS ( SELECT  NAME
            FROM    sys.procedures
            WHERE   name = 'BlockedProcessActivation' ) 
    DROP PROCEDURE BlockedProcessActivation
GO
CREATE PROCEDURE BlockedProcessActivation
AS 
    DECLARE @Message XML,
        @DialogueID UNIQUEIDENTIFIER,
        @ServiceName NVARCHAR(512),
        @DBName sysname,
        @DBID INT,
        @TransactionID BIGINT,
		@Duration bigint

    WHILE 1 = 1
        BEGIN
            BEGIN TRAN
            BEGIN TRY
		
		;
                RECEIVE TOP ( 1 )
			@Message = message_body,
			@DialogueID = conversation_handle,
			@ServiceName = SERVICE_NAME FROM
			dbo.BlockedProcessNotificationQueue
			
                IF @@ROWCOUNT = 0 
                    BEGIN
                        IF @@TRANCOUNT > 0 
                            BEGIN 
                                ROLLBACK ;
                            END  
                        BREAK ;
                    END 

                SELECT  @TransactionID = @Message.value('/EVENT_INSTANCE[1]/TransactionID[1]', 'bigint'),
				@Duration = @Message.value('/EVENT_INSTANCE[1]/Duration[1]', 'bigint')/1000/1000

                IF @TransactionID = 0 
                    SELECT  @TransactionID = @Message.value('/EVENT_INSTANCE[1]/EventSequence[1]', 'bigint') * 10

                IF NOT EXISTS ( SELECT  ID
                                FROM    dbo.BlockedProcesses
                                WHERE   TransactionID = @TransactionID) 
                    BEGIN
                        INSERT  INTO dbo.BlockedProcesses
                                (
                                  EventMessage,
                                  TransactionID,
								  Duration
                                )
                                SELECT  @Message,
                                        @TransactionID,
										@Duration
                                
                /*Include stuff here to raise alerts*/
						DECLARE @subject NVARCHAR(1000), @body NVARCHAR(4000)
						SELECT @subject = 'Blocked Process in '+DB_NAME(@Message.value('/EVENT_INSTANCE[1]/DatabaseID[1]', 'int')),
						@body = CAST(@message AS nvarchar(4000))

						EXEC msdb.dbo.sp_send_dbmail @recipients='Kyle@SQL2012', @subject=@subject, @body=@body
                    

END
                ELSE 
                    BEGIN
                        UPDATE  dbo.BlockedProcesses
                        SET     EventMessage = @Message,
                                FinalEventDate = GETDATE(),
								Duration = @Duration
                        WHERE   TransactionID = @TransactionID
                    END					

                IF @@TRANCOUNT > 0 
                    BEGIN 
                        COMMIT ;
                    END

                /*Include stuff here to raise alerts*/
				
            END TRY
            BEGIN CATCH
                IF @@TRANCOUNT > 0 
                    BEGIN 
                        ROLLBACK ;
                    END
				-- write any error in to the event log
                DECLARE @errorNumber BIGINT,
                    @errorMessage nvarchar(2048),
                    @DatabaseContext sysname
                SELECT  @errorNumber = ERROR_NUMBER(),
                        @errorMessage = ERROR_MESSAGE(),
                        @DatabaseContext = DB_NAME()
				
				INSERT INTO BlockedProcessActivationErrors (ErrorNumber, ErrorMessage, DatabaseContext)
				VALUES (@ErrorNumber, @ErrorMessage, @DatabaseContext)

            END CATCH ;
        END

GO
IF EXISTS ( SELECT  name
            FROM    sys.server_event_notifications
            WHERE   name = 'evtBlockedProcessThresholdExceeded' ) 
    DROP EVENT NOTIFICATION evtBlockedProcessThresholdExceeded ON SERVER
IF EXISTS ( SELECT  NAME
            FROM    sys.services
            WHERE   name = 'BlockedProcessNotificationService' ) 
    DROP SERVICE BlockedProcessNotificationService
IF EXISTS ( SELECT  NAME
            FROM    sys.routes
            WHERE   name = 'BlockedProcessNotificationRoute' ) 
    DROP ROUTE BlockedProcessNotificationRoute
IF EXISTS ( SELECT  NAME
            FROM    sys.objects
            WHERE   name = 'BlockedProcessNotificationQueue'
                    AND type = 'SQ' ) 
    DROP QUEUE dbo.BlockedProcessNotificationQueue 


GO
CREATE QUEUE dbo.BlockedProcessNotificationQueue
    WITH status = ON,
         ACTIVATION ( PROCEDURE_NAME = BlockedProcessActivation, MAX_QUEUE_READERS = 1, EXECUTE AS 'dbo') ;

CREATE SERVICE BlockedProcessNotificationService ON QUEUE dbo.BlockedProcessNotificationQueue ([http://schemas.microsoft.com/SQL/Notifications/PostEventNotification]) ;
CREATE ROUTE BlockedProcessNotificationRoute
    WITH SERVICE_NAME = 'BlockedProcessNotificationService',
         ADDRESS = 'LOCAL' ;

/*Blocked Process Threshold*/         
CREATE EVENT NOTIFICATION evtBlockedProcessThresholdExceeded ON SERVER FOR BLOCKED_PROCESS_REPORT TO SERVICE 'BlockedProcessNotificationService', 'current database' ;
GO
