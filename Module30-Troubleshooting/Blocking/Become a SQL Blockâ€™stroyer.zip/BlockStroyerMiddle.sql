USE BlockStroyer
GO

SELECT resource_type, request_mode
,request_status, request_type,request_session_id
FROM sys.dm_tran_locks
WHERE resource_database_id = DB_ID()
AND resource_type NOT IN ('METADATA', 'DATABASE')
--AND session_id in (53, 54)
ORDER BY request_session_id DESC,
resource_type, request_mode

EXEC sp_whoisactive

