/*fix any snapshot issues*/
ALTER DATABASE BlockStroyer
SET SINGLE_USER WITH ROLLBACK IMMEDIATE


ALTER DATABASE BlockStroyer
SET READ_COMMITTED_SNAPSHOT OFF

ALTER DATABASE BlockStroyer
SET ALLOW_SNAPSHOT_ISOLATION OFF

ALTER DATABASE BlockStroyer
SET MULTI_USER

SET TRANSACTION ISOLATION LEVEL REPEATABLE READ

GO

/*Deadlock 1*/
USE BlockStroyer
SET TRANSACTION ISOLATION LEVEL REPEATABLE READ
BEGIN TRAN
UPDATE SimpleBlocking SET id = id+1 WHERE ID = 1

SELECT * FROM SimpleDeadlock WHERE id = 1

ROLLBACK
GO

/*Mitigation 0 - See blocking Mitigations*/

/*Mitigation 1 - Resequence*/
BEGIN TRAN
UPDATE SimpleBlocking SET id = id+1 WHERE ID = 1

SELECT * FROM SimpleDeadlock WHERE id = 1

ROLLBACK


/*Mitigation 2 - Retry Logic*/
DECLARE @Tries tinyint
SET @Tries = 1
WHILE @Tries <= 3
BEGIN
  BEGIN TRANSACTION
  BEGIN TRY
    UPDATE SimpleBlocking SET id = id+1 WHERE ID = 1
	WAITFOR DELAY '00:00:05'
    UPDATE SimpleDeadlock SET id = id+1 WHERE id = 1
    ROLLBACK--COMMIT
    BREAK
  END TRY
  BEGIN CATCH
    SELECT ERROR_NUMBER() AS ErrorNumber
    ROLLBACK
    SET @Tries = @Tries + 1
    CONTINUE
  END CATCH;
END
SELECT @Tries AS AttemptsMade

/*Mitigation 3 - Deadlock Priority*/
BEGIN TRAN
UPDATE SimpleBlocking SET id = id+1 WHERE ID IN( 1, 2)

SELECT * FROM SimpleDeadlock WHERE id = 1

ROLLBACK

SET DEADLOCK_PRIORITY LOW 
