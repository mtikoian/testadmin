/*Deadlock 1*/
BEGIN TRAN

UPDATE SimpleDeadlock SET id=id+1 WHERE id = 1

SELECT * FROM dbo.SimpleBlocking WHERE ID = 1

ROLLBACK

/*Mitigation 0 - See blocking Mitigations*/

/*Mitigation 1 - Resequence*/
BEGIN TRAN
SELECT * FROM dbo.SimpleBlocking WHERE ID = 1

UPDATE SimpleDeadlock SET id=id+1 WHERE id = 1
ROLLBACK

/*Mitigation 2 - Retry Logic*/
DECLARE @Tries tinyint
SET @Tries = 1
WHILE @Tries <= 3
BEGIN
  BEGIN TRANSACTION
  BEGIN TRY
    UPDATE SimpleDeadlock SET id=id+1 WHERE id = 1
    WAITFOR DELAY '00:00:01'
    UPDATE dbo.SimpleBlocking SET id=id+1 WHERE ID = 1
    ROLLBACK--COMMIT
    BREAK
  END TRY
  BEGIN CATCH
    SELECT ERROR_NUMBER() AS ErrorNumber
    ROLLBACK
    SET @Tries = @Tries + 1
    CONTINUE
  END CATCH;
END
SELECT @Tries AS AttemptsMade

/*Mitigation 3 - Deadlock Priority*/
BEGIN TRAN

UPDATE SimpleDeadlock SET id=id+1 WHERE id = 1

SELECT * FROM dbo.SimpleBlocking WHERE ID = 1

ROLLBACK
