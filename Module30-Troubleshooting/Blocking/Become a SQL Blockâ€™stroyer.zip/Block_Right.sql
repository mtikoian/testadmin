USE BlockStroyer
GO
/*Blocking 1*/
SELECT * FROM dbo.SimpleBlocking WHERE id = 1
GO
/*Mitigation 1*/
SELECT id FROM SimpleBlocking WHERE id = 15

/*Mitigation 2*/
SELECT id FROM EscalationBlocking WHERE id = 6000

/*Mitigation 3*/
BEGIN TRAN
UPDATE EscalationBlocking SET id = id + 50000
WHERE id = 3000

ROLLBACK
GO
/*Mitigation 4*/
SELECT id FROM EscalationBlocking WHERE id = 4000
USE BlockStroyer_SNAP

/*Mitigation 5*/
USE BlockStroyer
SELECT id FROM EscalationBlocking WHERE id = 4000

SET TRANSACTION ISOLATION LEVEL SNAPSHOT

SELECT id FROM EscalationBlocking WHERE id = 4000

BEGIN TRAN
SELECT id FROM EscalationBlocking WHERE id = 4000

UPDATE EscalationBlocking SET id = id + 50000
WHERE id = 5000

UPDATE EscalationBlocking SET id = id + 50000
WHERE id = 4000

/*Mitigation 6*/
SET TRANSACTION ISOLATION LEVEL READ COMMITTED

BEGIN TRAN
SELECT id FROM EscalationBlocking WHERE id = 4000

UPDATE EscalationBlocking SET id = id + 50000
WHERE id = 5000

UPDATE EscalationBlocking SET id = id + 50000
WHERE id = 4000

ROLLBACK TRANSACTION

