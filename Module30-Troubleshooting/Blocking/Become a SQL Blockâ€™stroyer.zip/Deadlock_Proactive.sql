DBCC TRACEON(1222, -1)
EXEC sp_cycle_errorlog

EXEC xp_readerrorlog

/*Profiler,
Extra Files
XML Notepad
Internet Explorer
*/

/*System Health Event Session*/
/*Adapted from orginal posted at 
http://blogs.technet.com/b/mspfe/archive/2012/06/28/how_2d00_to_2d00_monitor_2d00_deadlocks_2d00_in_2d00_sql_2d00_server.aspx
*/

WITH    SystemHealth
          AS (SELECT    CAST(target_data AS XML) AS TargetData
              FROM      sys.dm_xe_session_targets st
                        JOIN sys.dm_xe_sessions s ON s.address=st.event_session_address
              WHERE     name='system_health'
                        AND st.target_name='ring_buffer')
    SELECT  XEventData.XEvent.query('(data/value/deadlock)[1]') AS DeadLockGraph,
            XEventData.XEvent.query('(data/value/deadlock/victim-list)[1]') AS Victims,
            XEventData.XEvent.query('(data/value/deadlock/process-list)[1]') AS Processes,
            XEventData.XEvent.query('(data/value/deadlock/resource-list)[1]') AS Resources
    FROM    SystemHealth
            CROSS APPLY TargetData.nodes('//RingBufferTarget/event') AS XEventData (XEvent)
    WHERE   XEventData.XEvent.value('@name', 'varchar(4000)')='xml_deadlock_report'