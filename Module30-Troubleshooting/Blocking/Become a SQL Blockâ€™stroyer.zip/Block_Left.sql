USE BlockStroyer
GO
/*Blocking 1*/
BEGIN TRAN
UPDATE SimpleBlocking SET id=id+1 WHERE ID = 1



ROLLBACK

GO

/*Mitigation 1*/
SET TRANSACTION ISOLATION LEVEL REPEATABLE READ
BEGIN TRAN
UPDATE SimpleBlocking SET id = id + 1 WHERE ID = 1

ROLLBACK

CREATE INDEX IX_SimpleBlocking_1 ON SimpleBlocking (id)

DROP INDEX SimpleBlocking.IX_SimpleBlocking_1

/*Mitigation 2*/
BEGIN TRAN
UPDATE EscalationBlocking SET id = id + 50000
WHERE id < 5000

ROLLBACK

/*Reduce Batch Size*/
BEGIN TRAN
UPDATE EscalationBlocking SET id = id + 50000
WHERE id < 4500

ROLLBACK

/*Discuss free memory table escalation*/

/*Mitigation 3 - Reduce Isolation Level*/
SET TRANSACTION ISOLATION LEVEL REPEATABLE READ

BEGIN TRAN
SELECT ID FROM dbo.EscalationBlocking 
WHERE id < 5000

UPDATE EscalationBlocking SET id = id + 50000
WHERE id = 4000

ROLLBACK


SET TRANSACTION ISOLATION LEVEL READ COMMITTED

/*Mitigation 4 - Snapshot Database*/
BEGIN TRAN
UPDATE EscalationBlocking SET id = id + 50000
WHERE id = 4000

ROLLBACK

--snapshot database
IF EXISTS(SELECT name FROM sys.databases WHERE name = 'BlockStroyer_SNAP')
	DROP DATABASE BlockStroyer_SNAP

CREATE DATABASE BlockStroyer_SNAP ON (NAME='BlockStroyer', FILENAME='C:\SQL\SQL2012\DATA\BlockStroyer.ss') 
AS SNAPSHOT OF BlockStroyer

/*Mitigation 5 - Snapshot Isolation Mode*/
ALTER DATABASE BlockStroyer
SET SINGLE_USER WITH ROLLBACK IMMEDIATE

ALTER DATABASE BlockStroyer
SET ALLOW_SNAPSHOT_ISOLATION ON

ALTER DATABASE BlockStroyer
SET MULTI_USER

BEGIN TRAN
UPDATE EscalationBlocking SET id = id + 50000
WHERE id = 4000

COMMIT

UPDATE EscalationBlocking SET id = 4000
WHERE id = 54000

/*Mitigation 6 - RCSI*/
ALTER DATABASE BlockStroyer
SET SINGLE_USER WITH ROLLBACK IMMEDIATE

ALTER DATABASE BlockStroyer
SET READ_COMMITTED_SNAPSHOT ON

ALTER DATABASE BlockStroyer
SET MULTI_USER

BEGIN TRAN
UPDATE EscalationBlocking SET id = id + 50000
WHERE id = 4000

COMMIT

UPDATE EscalationBlocking SET id = 4000
WHERE id = 54000
