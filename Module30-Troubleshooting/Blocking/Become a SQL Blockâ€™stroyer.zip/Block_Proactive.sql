/*Blocked Process Threshold
http://msdn.microsoft.com/en-us/library/ms181150.aspx
*/

EXEC sp_configure 'blocked process threshold', 5
RECONFIGURE
GO
/*Profiler
try_convert
Profiler Files
*/

EXEC sp_trace_setstatus 4, 0
EXEC sp_trace_setstatus 4, 2

SELECT try_convert(XML, textdata), * FROM fn_trace_gettable('C:\Temp\Blockstroyer2.trc', 1)


GO

/*xEvents (2012 only)*/
/*Developed with significant assistance from 
http://sqlblog.com/blogs/jonathan_kehayias/archive/2010/12/21/an-xevent-a-day-21-of-31-the-future-tracking-blocking-in-denali.aspx
*/
CREATE EVENT SESSION BlockedProcesses ON SERVER ADD EVENT sqlserver. blocked_process_report ADD TARGET package0.ring_buffer (SET MAX_MEMORY=2048) WITH (MAX_DISPATCH_LATENCY = 5
    SECONDS)
GO
ALTER EVENT SESSION BlockedProcesses
ON SERVER
STATE=START
GO
SELECT  *
FROM    (SELECT x.query('.') AS BlockedProcessReport
         FROM   (SELECT CAST(target_data AS XML) AS target_data
                 FROM   sys.dm_xe_sessions AS xes
                        JOIN sys.dm_xe_session_targets AS xet ON xes.address=xet.event_session_address
                 WHERE  xes.name='BlockedProcesses'
                        AND xet.target_name='ring_buffer') AS rb
                CROSS APPLY target_data.nodes('RingBufferTarget/event') AS X (x)) AS src
GO

SELECT  EventMessage.value('(event/data[@name="duration"]/value)[1]', 'int') AS DatabaseID,
        EventMessage.value('(event/data[@name="blocked_process"]/value)[1]/blocked-process-report[1]/blocking-process[1]/process[1]/inputbuf[1]', 'varchar(255)') AS BlockingStatement,
        EventMessage.value('(event/data[@name="blocked_process"]/value)[1]/blocked-process-report[1]/blocking-process[1]/process[1]/@clientapp', 'varchar(255)') AS BlockingApp,
        EventMessage.value('(event/data[@name="blocked_process"]/value)[1]/blocked-process-report[1]/blocking-process[1]/process[1]/@hostname', 'varchar(255)') AS BlockingHost,
        EventMessage.value('(event/data[@name="blocked_process"]/value)[1]/blocked-process-report[1]/blocking-process[1]/process[1]/@loginname', 'varchar(255)') AS BlockingLogin,
        EventMessage.value('(event/data[@name="blocked_process"]/value)[1]/blocked-process-report[1]/blocked-process[1]/process[1]/inputbuf[1]', 'varchar(255)') AS BlockedStatement,
        EventMessage.value('(event/data[@name="blocked_process"]/value)[1]/blocked-process-report[1]/blocked-process[1]/process[1]/@clientapp', 'varchar(255)') AS BlockedApp,
        EventMessage.value('(event/data[@name="blocked_process"]/value)[1]/blocked-process-report[1]/blocked-process[1]/process[1]/@hostname', 'varchar(255)') AS BlockedHost,
        EventMessage.value('(event/data[@name="blocked_process"]/value)[1]/blocked-process-report[1]/blocked-process[1]/process[1]/@loginname', 'varchar(255)') AS BlockedLogin,
        EventMessage.value('(event/data[@name="duration"]/value)[1]', 'bigint')/1000/1000 AS Duration,
        EventMessage,
        EventMessage.query('(event/data[@name="blocked_process"]/value)[1]/blocked-process-report[1]/blocking-process[1]/process[1]') AS BlockingProcess,
        EventMessage.query('(event/data[@name="blocked_process"]/value)[1]/blocked-process-report[1]/blocked-process[1]/process[1]') AS BlockedProcess
FROM    (SELECT x.query('.') AS EventMessage
         FROM   (SELECT CAST(target_data AS XML) AS target_data
                 FROM   sys.dm_xe_sessions AS xes
                        JOIN sys.dm_xe_session_targets AS xet ON xes.address=xet.event_session_address
                 WHERE  xes.name='BlockedProcesses'
                        AND xet.target_name='ring_buffer') AS rb
                CROSS APPLY target_data.nodes('RingBufferTarget/event') AS X (x)) AS src
GO

