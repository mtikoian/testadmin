
/*Event Notifications*/
SELECT  *
FROM    Apparatus_DBA.dbo.BlockedProcesses
ORDER BY InitialEventDate DESC

/*Show Blocker Event Notification Create Script*/
/*Upsert*/

/*Show smtp4dev*/

SELECT  EventMessage.value('/EVENT_INSTANCE[1]/DatabaseID[1]', 'int') AS DatabaseID,
        EventMessage.query('/EVENT_INSTANCE[1]/TextData[1]/blocked-process-report[1]/blocking-process[1]/process[1]') AS BlockingProcess,
        EventMessage.query('/EVENT_INSTANCE[1]/TextData[1]/blocked-process-report[1]/blocked-process[1]/process[1]') AS BlockedProcess,
        EventMessage.value('/EVENT_INSTANCE[1]/Duration[1]', 'bigint')/1000/1000 AS Duration,
        EventMessage,
        InitialEventDate,
        FinalEventDate
FROM    Apparatus_DBA.dbo.BlockedProcesses
ORDER BY InitialEventDate DESC

SELECT  EventMessage.value('/EVENT_INSTANCE[1]/DatabaseID[1]', 'int') AS DatabaseID,
        EventMessage.value('/EVENT_INSTANCE[1]/TextData[1]/blocked-process-report[1]/blocking-process[1]/process[1]/inputbuf[1]', 'varchar(255)') AS BlockingStatement,
        EventMessage.value('/EVENT_INSTANCE[1]/TextData[1]/blocked-process-report[1]/blocking-process[1]/process[1]/@clientapp', 'varchar(255)') AS BlockingApp,
        EventMessage.value('/EVENT_INSTANCE[1]/TextData[1]/blocked-process-report[1]/blocking-process[1]/process[1]/@hostname', 'varchar(255)') AS BlockingHost,
        EventMessage.value('/EVENT_INSTANCE[1]/TextData[1]/blocked-process-report[1]/blocking-process[1]/process[1]/@loginname', 'varchar(255)') AS BlockingLogin,
        EventMessage.value('/EVENT_INSTANCE[1]/TextData[1]/blocked-process-report[1]/blocked-process[1]/process[1]/inputbuf[1]', 'varchar(255)') AS BlockedStatement,
        EventMessage.value('/EVENT_INSTANCE[1]/TextData[1]/blocked-process-report[1]/blocked-process[1]/process[1]/@clientapp', 'varchar(255)') AS BlockedApp,
        EventMessage.value('/EVENT_INSTANCE[1]/TextData[1]/blocked-process-report[1]/blocked-process[1]/process[1]/@hostname', 'varchar(255)') AS BlockedHost,
        EventMessage.value('/EVENT_INSTANCE[1]/TextData[1]/blocked-process-report[1]/blocked-process[1]/process[1]/@loginname', 'varchar(255)') AS BlockedLogin,
        EventMessage.value('/EVENT_INSTANCE[1]/Duration[1]', 'bigint')/1000/1000 AS Duration,
        InitialEventDate,
        FinalEventDate,
        EventMessage,
        EventMessage.query('/EVENT_INSTANCE[1]/TextData[1]/blocked-process-report[1]/blocking-process[1]/process[1]') AS BlockingProcess,
        EventMessage.query('/EVENT_INSTANCE[1]/TextData[1]/blocked-process-report[1]/blocked-process[1]/process[1]') AS BlockedProcess
FROM    Apparatus_DBA.dbo.BlockedProcesses
ORDER BY InitialEventDate DESC

SELECT  DB_NAME(DatabaseID) AS DBName,
		BlockingStatement,
        AVG(Duration) AS AverageBlockDuration,
		SUM(Duration) AS TotalBlockDuration,
		COUNT(*) AS TotalBlockedProcesses
FROM    (SELECT EventMessage.value('/EVENT_INSTANCE[1]/DatabaseID[1]', 'int') AS DatabaseID,
                EventMessage.value('/EVENT_INSTANCE[1]/Duration[1]', 'bigint')/1000/1000 AS Duration,
				EventMessage.value('/EVENT_INSTANCE[1]/TextData[1]/blocked-process-report[1]/blocking-process[1]/process[1]/inputbuf[1]', 'varchar(255)') AS BlockingStatement
         FROM   Apparatus_DBA.dbo.BlockedProcesses) AS T
GROUP BY DatabaseID, BlockingStatement

GO

/*Deadlock Analysis*/

/*Event Notifications*/
SELECT --EventMessage.value('/EVENT_INSTANCE[1]/TextData[1]/deadlock-list[1]/deadlock[1]/@victim', 'varchar(1000)'),
        EventMessage.query('EVENT_INSTANCE/TextData/deadlock-list/deadlock/process-list/process[@id=/EVENT_INSTANCE[1]/TextData[1]/deadlock-list[1]/deadlock[1]/@victim]') AS VictimProcess,
        EventMessage.query('EVENT_INSTANCE/TextData/deadlock-list/deadlock/process-list/process[@id!=/EVENT_INSTANCE[1]/TextData[1]/deadlock-list[1]/deadlock[1]/@victim]') AS NotVictimProcess,
        EventMessage.query('EVENT_INSTANCE/TextData/deadlock-list/deadlock/resource-list') AS Resources,
        *
FROM    Apparatus_DBA.dbo.Deadlocks
ORDER BY InitialEventDate DESC



