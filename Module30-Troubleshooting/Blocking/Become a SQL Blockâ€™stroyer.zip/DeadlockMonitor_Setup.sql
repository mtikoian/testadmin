DECLARE @IsBroker tinyint, @IsTrustworthy tinyint

SELECT @IsBroker = is_broker_enabled,
@IsTrustworthy = is_trustworthy_on
FROM sys.databases WHERE name = 'Apparatus_DBA'

IF @IsBroker = 0
	ALTER DATABASE Apparatus_DBA SET ENABLE_BROKER

IF @IsTrustworthy = 0
	ALTER DATABASE Apparatus_DBA SET TRUSTWORTHY ON

GO
USE Apparatus_DBA
GO
IF EXISTS ( SELECT  NAME
            FROM    sys.tables
            WHERE   name = 'DeadlockActivationErrors' ) 
    DROP TABLE DeadlockActivationErrors
GO
CREATE TABLE DeadlockActivationErrors
    (ID INT IDENTITY NOT NULL,
	ErrorDate datetime default (getdate()) NOT NULL,
	ErrorNumber bigint NOT NULL,
	ErrorMessage nvarchar(2048) NULL,
	DatabaseContext sysname NULL,
	PollDate datetime NULL)

	ALTER TABLE DeadlockActivationErrors ADD CONSTRAINT PK_DeadlockActivationErrors PRIMARY KEY CLUSTERED (ID)
	CREATE NONCLUSTERED INDEX IX_DeadlockActivationErrors_1 ON DeadlockActivationErrors (PollDate)
GO
IF EXISTS ( SELECT  NAME
            FROM    sys.tables
            WHERE   name = 'Deadlocks' ) 
    DROP TABLE Deadlocks
GO
CREATE TABLE Deadlocks
(
	ID INT IDENTITY NOT NULL,
	EventMessage XML NULL,
	TransactionID BIGINT NOT NULL,
	InitialEventDate DATETIME DEFAULT (GETDATE()) NOT NULL,
	FinalEventDate DATETIME DEFAULT (GETDATE()) NOT NULL,
	PollDate DATETIME NULL)

ALTER TABLE Deadlocks ADD CONSTRAINT PK_Deadlocks PRIMARY KEY CLUSTERED (TransactionID)
CREATE NONCLUSTERED INDEX IX_Deadlocks_1 ON Deadlocks (PollDate)
go
IF EXISTS ( SELECT  NAME
            FROM    sys.procedures
            WHERE   name = 'DeadlockActivation' ) 
    DROP PROCEDURE DeadlockActivation
GO
CREATE PROCEDURE DeadlockActivation
AS 
    DECLARE @Message XML,
        @DialogueID UNIQUEIDENTIFIER,
        @ServiceName NVARCHAR(512),
        @DBName sysname,
        @DBID INT,
        @TransactionID BIGINT

    WHILE 1 = 1
        BEGIN
            BEGIN TRAN
            BEGIN TRY
		
		;
                RECEIVE TOP ( 1 )
			@Message = message_body,
			@DialogueID = conversation_handle,
			@ServiceName = SERVICE_NAME FROM
			dbo.DeadlockNotificationQueue
			
                IF @@ROWCOUNT = 0 
                    BEGIN
                        IF @@TRANCOUNT > 0 
                            BEGIN 
                                ROLLBACK ;
                            END  
                        BREAK ;
                    END 

                SELECT  @TransactionID = @Message.value('/EVENT_INSTANCE[1]/TransactionID[1]', 'bigint')

                IF @TransactionID = 0 
                    SELECT  @TransactionID = @Message.value('/EVENT_INSTANCE[1]/EventSequence[1]', 'bigint') * 10

                IF NOT EXISTS ( SELECT  ID
                                FROM    dbo.Deadlocks
                                WHERE   TransactionID = @TransactionID) 
                    BEGIN
                        INSERT  INTO dbo.Deadlocks
                                (
                                  EventMessage,
                                  TransactionID
                                )
                                SELECT  @Message,
                                        @TransactionID
                                
                    END
                ELSE 
                    BEGIN
                        UPDATE  dbo.Deadlocks
                        SET     EventMessage = @Message,
                                FinalEventDate = GETDATE()
                        WHERE   TransactionID = @TransactionID
                    END					

                IF @@TRANCOUNT > 0 
                    BEGIN 
                        COMMIT ;
                    END

                /*Include stuff here to raise alerts*/
				
            END TRY
            BEGIN CATCH
                IF @@TRANCOUNT > 0 
                    BEGIN 
                        ROLLBACK ;
                    END
				-- write any error in to the event log
                DECLARE @errorNumber BIGINT,
                    @errorMessage nvarchar(2048),
                    @DatabaseContext sysname
                SELECT  @errorNumber = ERROR_NUMBER(),
                        @errorMessage = ERROR_MESSAGE(),
                        @DatabaseContext = DB_NAME()
				
				INSERT INTO DeadlockActivationErrors (ErrorNumber, ErrorMessage, DatabaseContext)
				VALUES (@ErrorNumber, @ErrorMessage, @DatabaseContext)

            END CATCH ;
        END

GO
IF EXISTS ( SELECT  name
            FROM    sys.server_event_notifications
            WHERE   name = 'evtDeadlockGraph' ) 
    DROP EVENT NOTIFICATION evtDeadlockGraph ON SERVER
IF EXISTS ( SELECT  NAME
            FROM    sys.services
            WHERE   name = 'DeadlockNotificationService' ) 
    DROP SERVICE DeadlockNotificationService
IF EXISTS ( SELECT  NAME
            FROM    sys.routes
            WHERE   name = 'DeadlockNotificationRoute' ) 
    DROP ROUTE DeadlockNotificationRoute
IF EXISTS ( SELECT  NAME
            FROM    sys.objects
            WHERE   name = 'DeadlockNotificationQueue'
                    AND type = 'SQ' ) 
    DROP QUEUE dbo.DeadlockNotificationQueue 


GO
CREATE QUEUE dbo.DeadlockNotificationQueue
    WITH status = ON,
         ACTIVATION ( PROCEDURE_NAME = DeadlockActivation, MAX_QUEUE_READERS = 1, EXECUTE AS 'dbo') ;

CREATE SERVICE DeadlockNotificationService ON QUEUE dbo.DeadlockNotificationQueue ([http://schemas.microsoft.com/SQL/Notifications/PostEventNotification]) ;
CREATE ROUTE DeadlockNotificationRoute
    WITH SERVICE_NAME = 'DeadlockNotificationService',
         ADDRESS = 'LOCAL' ;

/*Deadlock Graph*/         
CREATE EVENT NOTIFICATION evtDeadlockGraph ON SERVER FOR DEADLOCK_GRAPH TO SERVICE 'DeadlockNotificationService', 'current database' ;
GO
