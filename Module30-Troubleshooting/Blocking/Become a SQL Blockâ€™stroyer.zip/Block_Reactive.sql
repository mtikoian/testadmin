
/*Activity Monitor*/

SELECT * FROM sys.dm_os_waiting_tasks


SELECT * FROM sys.dm_os_waiting_tasks
WHERE session_id = 64

/*Copy resource description here
ridlock fileid=1 pageid=284 dbid=17 id=lock4786d4980 mode=X associatedObjectId=72057594039042048
*/
DBCC TRACEON(3604)

/*Change to appropriate db, file, page here*/
DBCC PAGE(17, 1, 284, 3)
SELECT * FROM sys.all_objects WHERE object_id = 261575970
/*... or not ...*/
/*
copied from SQL Server Concurrency by Kalen Delaney
Chapter 5 - page 126
*/
SELECT  T.session_id AS waiting_session_id,
        DB_NAME(L.resource_database_id) AS DatabaseName,
        T.wait_duration_ms/60000. AS duration_in_minutes,
        T.waiting_task_address,
        L.request_mode,
        (SELECT SUBSTRING(Q.text, (R.statement_start_offset/2)+1, ((CASE R.statement_end_offset
                                                                      WHEN -1 THEN DATALENGTH(Q.text)
                                                                      ELSE R.statement_end_offset
                                                                    END-R.statement_start_offset)/2)+1)
         FROM   sys.dm_exec_requests AS R
                CROSS APPLY sys.dm_exec_sql_text(R.sql_handle) AS Q
         WHERE  R.session_id=L.request_session_id) AS waiting_query_text,
        L.resource_type,
        L.resource_associated_entity_id,
        T.wait_type,
        T.blocking_session_id,
        T.resource_description AS blocking_resource_description,
        CASE WHEN T.blocking_session_id>0 THEN (SELECT  ST2.text
                                                FROM    sys.sysprocesses AS P
                                                        CROSS APPLY sys.dm_exec_sql_text(P.sql_handle) AS ST2
                                                WHERE   P.spid=T.blocking_session_id)
             ELSE NULL
        END AS blocking_query_text
FROM    sys.dm_os_waiting_tasks AS T
        JOIN sys.dm_tran_locks AS L ON T.resource_address=L.lock_owner_address
WHERE   T.wait_duration_ms>5000
        AND T.session_id>50;


/*sp_WhoIsActive downloaded from Adam Machanic
http://sqlblog.com/blogs/adam_machanic/archive/2012/03/22/released-who-is-active-v11-11.aspx

*/
EXEC sp_whoisactive

EXEC sp_whoisactive @find_block_leaders=1


