use master
go
IF exists(select name from sys.databases where name='StatsUpdate')
begin
	drop database statsUpdate
end
go
CREATE DATABASE statsUpdate
 ON  PRIMARY 

use statsUpdate
go
/*
create student tables
*/
if exists(select name from sys.tables where name='students')
begin
	drop table students
end
go
create table students( 
				studentID int identity(100000,1) 
				,ssn char(9)
				,FirstName varchar(50)
				,MiddileInitial char(1)
				,LastName varchar(100)
				,BirthDate datetime
				,Gender char(1)
				,bio varchar(3000) default 'student bio'
				,constraint pk_students_studentID primary key clustered (studentID)
				)

declare @i int, @x int, @y int, @z int, @firstname varchar(50), @ssn char(9), @mi char(1), @LastName varchar(100),@DOB datetime, @gender char(1),  @date_from DATETIME, @date_to DATETIME
 
SET @date_from = '1992-12-01';
SET @date_to = '1996-1-01';
set @i=0

while(@i<10000)
Begin
begin transaction
	set @x=(select CAST(RAND() * 10 AS INT))
	set @y=(select CAST(RAND() * 10 AS INT))
	set @z=(select CAST(RAND() * 10 AS INT))
	set @ssn=cast((select CAST(RAND() * 1000000000 AS INT)) as char(9))
	set @dob=(SELECT
(@date_from +(ABS(CAST(CAST( NewID() AS BINARY(8) )AS INT))%CAST((@date_to - @date_from)AS INT))))


	select
		@firstname=case @x
			when 1 then  'Michael'
			when 2 then 'Neil'
			when 3 then 'David'
			when 4 then 'Joss'
			when 5 then 'Jorge'
			when 6 then 'Chad'
			when 7 then 'Kathi'
			when 8 then 'Jason'
			when 9 then 'Serenity'
			else 'Roger'
		end
		,@lastname=case @y
			when 1 then  'Jordan'
			when 2 then 'Patrick-Harris'
			when 3 then 'Ball'
			when 4 then 'Whedon'
			when 5 then 'Segarra'
			when 6 then 'Churchwell'
			when 7 then 'Kellenberger'
			when 8 then 'Strate'
			when 9 then 'Elizabeth'
			else 'Wolter'
		end
		,@mi=case @z
			when 1 then  'T'
			when 2 then 'W'
			when 3 then 'X'
			when 4 then 'C'
			when 5 then 'V'
			when 6 then 'H'
			when 7 then 'P'
			when 8 then 'L'
			when 9 then 'B'
			else 'Q'
		end
		,@gender=case 
			when (@x<7) then 'M'
			else 'F'
			end 
			
			if (@i=1)
				begin
					insert into students(ssn,FirstName,MiddileInitial,LastName,BirthDate,Gender)
					values( '111111111', 'Thomas', 'R', 'Bradley', '1/25/1977', 'M')
				end
			insert into students(ssn,FirstName,MiddileInitial,LastName,BirthDate,Gender)
			values( @ssn, @firstname, @mi, @LastName, @dob, @gender)

	set @i=@i+1
commit transaction
end
GO
/*
Create a Non-clustered Index for demo
*/
if exists(select name from sys.indexes where name='nclx_fname_lname_students')
begin
	DROP INDEX [nclx_fname_lname_students] ON [dbo].[students]
end
create index nclx_fname_lname_students on dbo.students(FirstName, LastName)
include([MiddileInitial])

go
select * from sys.indexes
/*
look at our statistics
a couple different ways
*/
sp_helpstats students, 'all'
go
DBCC SHOW_STATISTICS ('dbo.students',pk_students_studentID)
DBCC SHOW_STATISTICS ('dbo.students',nclx_fname_lname_students)
go
SELECT o.name, i.name AS [Index Name],  
      STATS_DATE(i.[object_id], i.index_id) AS [Statistics Date], 
      s.auto_created, s.no_recompute, s.user_created, st.row_count
FROM sys.objects AS o WITH (NOLOCK)
INNER JOIN sys.indexes AS i WITH (NOLOCK)
ON o.[object_id] = i.[object_id]
INNER JOIN sys.stats AS s WITH (NOLOCK)
ON i.[object_id] = s.[object_id] 
AND i.index_id = s.stats_id
INNER JOIN sys.dm_db_partition_stats AS st WITH (NOLOCK)
ON o.[object_id] = st.[object_id]
AND i.[index_id] = st.[index_id]
WHERE o.[type] = 'U'
ORDER BY STATS_DATE(i.[object_id], i.index_id) ASC OPTION (RECOMPILE);  
go
/*
create some Column Level
stats on our clustered index
*/
select
	ssn
from
	dbo.students
where
	ssn like '11%'
go
sp_helpstats students

/*
create stored proc
*/
if exists(select name from sys.procedures where name='p_sel_get_stu_name')
begin
	drop procedure p_sel_get_stu_name
end
go
create procedure p_sel_get_stu_name(@lname varchar(50))
as
begin
	
	select
		s.FirstName
		,s.LastName
		,c.courseName
	from
		dbo.students s
		left join enrollment e
		on s.studentID=e.studentid
		left join courses c
		on e.courseid = c.courseid
	where
			lastname=@lname 
end
go
/*
look at our stats before
*/
sp_helpstats students
go
/*
run our proc
--set actual plan on
*/
set statistics io on 
exec p_sel_get_stu_name 'bradley'

go
/*
look at stats
*/
sp_helpstats students
go
sp_helpstats students, 'all'
go
DBCC SHOW_STATISTICS ('dbo.students',nclx_fname_lname_students)
go
/*
look at our stats using DMV's
*/
SELECT o.name, i.name AS [Index Name],  
      STATS_DATE(i.[object_id], i.index_id) AS [Statistics Date], 
      s.auto_created, s.no_recompute, s.user_created, st.row_count
FROM sys.objects AS o WITH (NOLOCK)
INNER JOIN sys.indexes AS i WITH (NOLOCK)
ON o.[object_id] = i.[object_id]
INNER JOIN sys.stats AS s WITH (NOLOCK)
ON i.[object_id] = s.[object_id] 
AND i.index_id = s.stats_id
INNER JOIN sys.dm_db_partition_stats AS st WITH (NOLOCK)
ON o.[object_id] = st.[object_id]
AND i.[index_id] = st.[index_id]
WHERE o.[type] = 'U'
ORDER BY STATS_DATE(i.[object_id], i.index_id) ASC OPTION (RECOMPILE);  
go
select count(*) from students
/*
500 + 20% of Table
20500
let's update 
2400

--Fireup Extended Event
*/

update dbo.students
set lastName='Bradley'
where studentID between 100000 and 102040
go
/*
set actual plan on
look at out of date statistics
*/
set statistics io on
set statistics profile on
go
p_sel_get_stu_name 'Bradley'
go 
set statistics profile off
/*
Cached plans and bad stats = Parameter sniffing
*/
sp_helpstats students
go
sp_helpstats students, 'all'
DBCC SHOW_STATISTICS ('dbo.students',nclx_fname_lname_students)
go

SELECT o.name, i.name AS [Index Name],  
      STATS_DATE(i.[object_id], i.index_id) AS [Statistics Date], 
      s.auto_created, s.no_recompute, s.user_created, st.row_count
FROM sys.objects AS o WITH (NOLOCK)
INNER JOIN sys.indexes AS i WITH (NOLOCK)
ON o.[object_id] = i.[object_id]
INNER JOIN sys.stats AS s WITH (NOLOCK)
ON i.[object_id] = s.[object_id] 
AND i.index_id = s.stats_id
INNER JOIN sys.dm_db_partition_stats AS st WITH (NOLOCK)
ON o.[object_id] = st.[object_id]
AND i.[index_id] = st.[index_id]
WHERE o.[type] = 'U'
ORDER BY STATS_DATE(i.[object_id], i.index_id) ASC OPTION (RECOMPILE);  
go
update dbo.students
set lastName='Bradley'
where studentID between 102040 and 102500
go
/*
set actual execution plan on
set statistics io on
*/
p_sel_get_stu_name 'bradley'
go
/*
recompile
*/
go
p_sel_get_stu_name 'bradley' with recompile
