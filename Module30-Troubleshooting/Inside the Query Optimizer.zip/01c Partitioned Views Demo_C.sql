/*============================================================
--http://www.SQLBalls.com
--@SQLBalls: SQLBalls@gmail.com
--Partitioning in SQL Server 2012
--

This Sample Code is provided for the purpose of illustration only and is not intended
to be used in a production environment.  THIS SAMPLE CODE AND ANY RELATED INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.

==============================================================*/
use master
go
/*
Create Database
*/
if exists(select name from sys.databases where name='apartments')
begin
	drop database apartments
end
go
create database apartments
go
/*
Create FileGroups
*/
ALTER DATABASE apartments 
ADD FILEGROUP peoria
GO
ALTER DATABASE apartments 
ADD FILE ( 
	NAME = N'peoria' 
	,FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL11.BRADSQL2012\MSSQL\DATA\peoria.ndf' 
	,SIZE = 4096KB 
	,FILEGROWTH = 1024KB ) 
TO FILEGROUP peoria
GO
go
ALTER DATABASE apartments 
ADD FILEGROUP pigeonForge
GO
ALTER DATABASE apartments 
ADD FILE ( 
	NAME = N'pigeonForge' 
	,FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL11.BRADSQL2012\MSSQL\DATA\pigeonForge.ndf' 
	,SIZE = 4096KB 
	,FILEGROWTH = 1024KB ) 
TO FILEGROUP pigeonForge
GO
go
ALTER DATABASE apartments 
ADD FILEGROUP Atlanta
GO
ALTER DATABASE apartments 
ADD FILE ( 
	NAME = N'Atlanta' 
	,FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL11.BRADSQL2012\MSSQL\DATA\Atlanta.ndf' 
	,SIZE = 4096KB 
	,FILEGROWTH = 1024KB ) 
TO FILEGROUP Atlanta
GO
go
ALTER DATABASE apartments 
ADD FILEGROUP NewportNews
GO
ALTER DATABASE apartments 
ADD FILE ( 
	NAME = N'NewportNews' 
	,FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL11.BRADSQL2012\MSSQL\DATA\NewportNews.ndf' 
	,SIZE = 4096KB 
	,FILEGROWTH = 1024KB ) 
TO FILEGROUP NewportNews
GO
/*
Create Peoria Data

NOW WITH CHECK CONSTRAINTS!!!
*/
use apartments
go
if exists(select name from sys.tables where name='city_peoria')
begin
	drop table city_peoria
end
create table city_peoria(
	myid int
	,street_address char(50)
	,city char(50)
	,[state] char(50) constraint CK_stateIL check ([state]='IL')
	,zip char(9))
go
declare @i int
set @i=1234
while(@i<2234)
begin
	insert into city_peoria(myid, street_address, city, [state], zip)
	values(@i, cast(@i as varchar(4))+' echo court', 'Peoria', 'IL', '61607')

	set @i+=100
end
go
create clustered index pk_city_peoria on dbo.city_peoria([state],myid) on peoria
go
/*
Create Pigeon Forge Data

NOW WITH CHECK CONSTRAINTS!!!
*/
if exists(select name from sys.tables where name='city_pigeonForge')
begin
	drop table city_pigeonForge
end
create table city_pigeonForge(
	myid int
	,street_address char(50)
	,city char(50)
	,[state] char(50) constraint CK_stateTN check ([state]='TN')
	,zip char(9))
go
declare @i int
set @i=2334
while(@i<3334)
begin
	insert into city_pigeonForge(myid, street_address, city, [state], zip)
	values(@i, cast(@i as varchar(4))+' Valley View Rd', 'Pigeon Forge', 'TN', '37863')

	set @i+=100
end
go
/*
Create Atlanta Data

NOW WITH CHECK CONSTRAINTS!!!
*/
create clustered index pk_city_pigeonForge on dbo.city_pigeonForge([state],myid) on pigeonForge
go
if exists(select name from sys.tables where name='city_Atlanta')
begin
	drop table city_Atlanta
end
create table city_Atlanta(
	myid int
	,street_address char(50)
	,city char(50)
	,[state] char(50) constraint CK_stateGA check ([state]='GA')
	,zip char(9))
go
declare @i int
set @i=4434
while(@i<5434)
begin
	insert into city_Atlanta(myid, street_address, city, [state], zip)
	values(@i, cast(@i as varchar(4))+' Cleburne Pkwy', 'Dallas', 'GA', '30141')

	set @i+=100
end
go
/*
Create Newport News Data

NOW WITH CHECK CONSTRAINTS!!!
*/
create clustered index pk_city_Atlanta on dbo.city_Atlanta([state],myid) on Atlanta
go
if exists(select name from sys.tables where name='city_NewportNews')
begin
	drop table city_NewportNews
end
create table city_NewportNews(
	myid int
	,street_address char(50)
	,city char(50)
	,[state] char(50) constraint CK_stateVA check ([state]='VA')
	,zip char(9))
go
declare @i int
set @i=5434
while(@i<6534)
begin
	insert into city_NewportNews(myid, street_address, city, [state], zip)
	values(@i, cast(@i as varchar(4))+' Arbor Oaks', 'Newport News', 'VA', '23606')

	set @i+=100
end
create clustered index pk_city_newportNews on dbo.city_NewportNews([state],myid) on newportnews
go
/*
create our view
*/

if exists(select name from sys.objects where name='Rentals')
begin
	drop view rentals
end
go
create view Rentals
as
select
	*
from city_peoria
union all
select
	*
from city_Atlanta
union all
select
	*
from
	city_NewportNews
	union all
select
	*
from
	city_pigeonForge

/*
select from all VA rentals

set show actual execution plan
*/
go
SELECT
	*
FROM
	dbo.Rentals
where
	[state]='va'

/*
Now let's try this by city
*/
SELECT
	*
FROM
	dbo.Rentals
where
	city='Pigeon Forge'

/*
OHHH back to scanning all partitions

hmmm can we fix this
*/
if exists(select name from sys.objects where name='ck_city')
begin
	alter table dbo.city_pigeonForge drop constraint ck_city
end
alter table dbo.city_pigeonForge add constraint ck_city check(city='Pigeon Forge')
go
dbcc dropcleanbuffers
go
SELECT
	*
FROM
	dbo.Rentals
where
	city='Pigeon Forge'
/*
again
*/

if exists(select name from sys.objects where name='ck_city_peoria')
begin
	alter table dbo.city_peoria drop constraint ck_city_peoria
end
alter table dbo.city_peoria add constraint ck_city_peoria check(city='Peoria')
go
dbcc dropcleanbuffers
go
SELECT
	*
FROM
	dbo.Rentals
where
	city='Pigeon Forge'
/*
again
*/
if exists(select name from sys.objects where name='ck_city_atlanta')
begin
	alter table dbo.city_atlanta drop constraint ck_city_atlanta
end
alter table dbo.city_atlanta add constraint ck_city_atlanta check(city='Dallas')
go
SELECT
	*
FROM
	dbo.Rentals
where
	city='Pigeon Forge'


/*
again
*/
if exists(select name from sys.objects where name='ck_city_NewportNews')
begin
	alter table dbo.city_NewportNews drop constraint ck_city_NewportNews
end
alter table dbo.city_NewportNews add constraint ck_city_NewportNews check(city='Newport News')
go
/*
now let's try our query again
*/
dbcc dropcleanbuffers
go
SELECT
	*
FROM
	dbo.Rentals
where
	city='Pigeon Forge'


