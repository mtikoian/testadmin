/*
INPUT TREE Example
*/
Use AdventureWorks2012
go
/*
set Trace Flag 3604 on
*/
dbcc traceon(3604)
go
/*
Write out our Query
*/
select
	p.Name
	,total=sum(inv.Quantity)
from
	production.product as p
	,Production.ProductInventory as inv
where
	inv.ProductID=p.productID
and
	p.Name Like N'[A-G]%'
GROUP BY
	p.Name;
/*
Run our query again
and look at our output tree
*/
select
	p.Name
	,total=sum(inv.Quantity)
from
	production.product as p
	,Production.ProductInventory as inv
where
	inv.ProductID=p.productID
and
	p.Name Like N'[A-G]%'
GROUP BY
	p.Name
option(RECOMPILE,QUERYTRACEON 8605)


/*
Normal Join slighty 
different rule evaluation
*/
select
	p.Name
	,total=sum(inv.Quantity)
from
	production.product as p
	join Production.ProductInventory as inv
	on p.ProductID=inv.ProductID
where
	inv.ProductID=p.productID
and
	p.Name Like N'[A-G]%'
GROUP BY
	p.Name
option(RECOMPILE,QUERYTRACEON 8605)

/*
Change the Tree 
statement with 
and order by
*/
select
	p.Name
	,total=sum(inv.Quantity)
from
	production.product as p
	,Production.ProductInventory as inv
where
	inv.ProductID=p.productID
and
	p.Name Like N'[A-G]%'
GROUP BY
	p.Name
ORDER BY p.name
OPTION (RECOMPILE, QUERYTRACEON 8605);


/*
Expanded Views 
*/

select 
	counter
	,occurrence
from
	sys.dm_exec_query_optimizer_info
where
	counter=N'view reference'
go
with CTEisaView AS
(
	select
		*
	from
		Production.Product
	where 
		name like N'[A-G]%'
	)
select
	CTEisaView.Name
	,Total = Sum(i.Quantity)
from
	CTEisaView
Join
	Production.ProductInventory i 
	on CTEisaView.ProductID=i.ProductID
group by
	CTEisaView.Name
OPTION (RECOMPILE, QUERYTRACEON 8605);
go

select 
	counter
	,occurrence
from
	sys.dm_exec_query_optimizer_info
where
	counter=N'view reference'
/*
What about
Derived Queries
*/
select 
	counter
	,occurrence
from
	sys.dm_exec_query_optimizer_info
where
	counter=N'view reference'


select
	DerivedNotAView.Name
	,Total = Sum(i.Quantity)
from
	(select
		*
	from
		Production.Product
	where 
		name like N'[A-G]%'
		) as DerivedNotAView
	join Production.ProductInventory i
	on DerivedNotAView.ProductID=i.ProductID
group by
	DerivedNotAView.Name
OPTION (RECOMPILE, QUERYTRACEON 8605);



select 
	counter
	,occurrence
from
	sys.dm_exec_query_optimizer_info
where
	counter=N'view reference'

/*
SIMPLIFICATION
*/
--*Constant Folding*
--Make sure show actual execution plan
--is on, show predicate is p.name like 'D%'
SELECT p.Name
FROM Production.Product AS p
WHERE p.Name LIKE SUBSTRING(LEFT(CHAR(ASCII(CHAR(68))), 1) + '%', 1, 2)
OPTION (RECOMPILE, QUERYTRACEON 8605);

--*Domain Simplification*
--Run, then increase 1st where to 
--300 and 401, and an Order By P.ProductID DESC
--and see the tree affect
SELECT TOP (10) * 
FROM Production.Product AS p
WHERE p.ProductID BETWEEN 300 AND 400
AND p.ProductID BETWEEN 200 AND 500
AND p.ProductID BETWEEN 400 AND 600
OPTION (RECOMPILE, QUERYTRACEON 8605);




--*Join Simplification*
--Eliminate unnesicary joins
SELECT
    th.ProductID,
    SUM(th.ActualCost)
FROM Production.TransactionHistory AS th
JOIN Production.Product AS p ON
    p.ProductID = th.ProductID
GROUP BY
    th.ProductID
OPTION (RECOMPILE, QUERYTRACEON 8605);


-- Complex example combining multiple simplifications
WITH Complex AS
(
    SELECT
        pc.ProductCategoryID, pc.Name AS CatName,
        ps.ProductSubcategoryID, ps.Name AS SubCatName,
        p.ProductID, p.Name AS ProductName,
        p.Color, p.ListPrice, p.ReorderPoint,
        pm.Name AS ModelName, pm.ModifiedDate
    FROM Production.ProductCategory AS pc
    FULL JOIN Production.ProductSubcategory AS ps ON
        ps.ProductCategoryID = pc.ProductCategoryID
    FULL JOIN Production.Product AS p ON
        p.ProductSubcategoryID = ps.ProductSubcategoryID
    FULL JOIN Production.ProductModel AS pm ON
        pm.ProductModelID = p.ProductModelID
)
SELECT c.ProductID, c.ProductName
FROM Complex AS c
WHERE c.ProductName LIKE N'G%'
OPTION (RECOMPILE, QUERYTRACEON 8605);



--*Contradiction Detection*
--Run, Then comment out and p.productID <>400
--look at the differences
set statistics io on
set statistics time on

SELECT TOP (10) * 
FROM Production.Product AS p
WHERE p.ProductID BETWEEN 300 AND 400
AND p.ProductID BETWEEN 200 AND 500
AND p.ProductID BETWEEN 400 AND 600
and p.productID <>400
OPTION (RECOMPILE, QUERYTRACEON 8605);

set statistics io off
set statistics time off

/*
Go Back to Slide deck 
return at
TRIVIAL PLAN
*/
-- Trivial plan
SELECT p.ProductID
FROM Production.Product AS p
WHERE p.Name = N'Blade'
OPTION (RECOMPILE, QUERYTRACEON 8605);
GO

select
	*
from
	sys.dm_exec_query_optimizer_info
where counter in('optimizations','trivial plan', 'search 0', 'search 1','search 2')

-- Still trivial
SELECT
    p.Name,
    RowNumber =
        ROW_NUMBER() OVER (
            ORDER BY p.Name)
FROM Production.Product AS p
WHERE p.Name LIKE N'[A-G]%';
GO
-- 'Subquery' prevents a trivial plan
SELECT (SELECT p.ProductID)
FROM Production.Product AS p
WHERE p.Name = N'Blade';
GO
-- Inequality
SELECT p.ProductID
FROM Production.Product AS p
WHERE p.Name <> N'Blade';



--Look at overall plan

USE AdventureWorks2012
GO
SET NOCOUNT ON;
DBCC FREEPROCCACHE;
DBCC TRACEON(3604);
GO
-- Initial memo contents
SELECT
    p.Name,
    Total = SUM(inv.Quantity)
FROM Production.Product AS p
JOIN Production.ProductInventory AS inv ON
    inv.ProductID = p.ProductID
WHERE
    p.Name LIKE N'[A-G]%'
GROUP BY
    p.Name
OPTION (QUERYTRACEON 8608);
