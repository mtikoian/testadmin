use college
go
if exists(select name from sys.objects where name='vw_student_enrollment')
begin
	drop view vw_student_enrollment
end
go
create view vw_student_enrollment
as
select
	s.studentID
	,s.ssn
	,s.FirstName
	,s.MiddileInitial
	,s.LastName
	,s.BirthDate
	,s.Gender
	,s.enrolled
	,e.courseID
	,e.enrollmentID
	,e.enrollmentDate
from
	students s
	 inner join enrollment e
	on s.studentID=e.studentID
go
if exists(select name from sys.objects where name='vw_coures_grade')
begin
	drop view vw_coures_grade
end
go
create view vw_coures_grade
as
select
	c.courseID
	,c.courseName
	,c.creditHours
	,c.islab
	,c.courseDescription
	,g.gradeID
	,g.Grade
	,g.studentID
from
	courses c
	inner join grades g
	on g.courseID=c.courseID
go
if exists(select name from sys.objects where name='vw_student_grade_A')
begin
	drop view vw_student_grade_A 
end
go
create view vw_student_grade_A
as
select
	s.studentID
	,s.ssn
	,s.FirstName
	,s.MiddileInitial
	,s.LastName
	,s.BirthDate
	,s.Gender
	,s.enrolled
	,s.courseID
	,s.enrollmentID
	,s.enrollmentDate
	,g.courseName
	,g.courseDescription
	,g.creditHours
	,g.islab
	,g.grade
	,g.gradeID
from
	vw_student_enrollment s
	join vw_coures_grade g
	on s.studentId=g.studentID and s.courseID=g.courseID
where
	g.grade = 'A'
go
if exists(select name from sys.objects where name='vw_student_grade_b')
begin
	drop view vw_student_grade_b 
end
go
create view vw_student_grade_b
as
select
	s.studentID
	,s.ssn
	,s.FirstName
	,s.MiddileInitial
	,s.LastName
	,s.BirthDate
	,s.Gender
	,s.enrolled
	,s.courseID
	,s.enrollmentID
	,s.enrollmentDate
	,g.courseName
	,g.courseDescription
	,g.creditHours
	,g.islab
	,g.grade
	,g.gradeID
from
	vw_student_enrollment s
	join vw_coures_grade g
	on s.studentId=g.studentID and s.courseID=g.courseID
where
	g.grade = 'B'
go

if exists(select name from sys.objects where name='vw_student_grade_c')
begin
	drop view vw_student_grade_c 
end
go
create view vw_student_grade_c
as
select
	s.studentID
	,s.ssn
	,s.FirstName
	,s.MiddileInitial
	,s.LastName
	,s.BirthDate
	,s.Gender
	,s.enrolled
	,s.courseID
	,s.enrollmentID
	,s.enrollmentDate
	,g.courseName
	,g.courseDescription
	,g.creditHours
	,g.islab
	,g.grade
	,g.gradeID
from
	vw_student_enrollment s
	join vw_coures_grade g
	on s.studentId=g.studentID and s.courseID=g.courseID
where
	g.grade = 'c'
go

if exists(select name from sys.objects where name='vw_student_grade_D')
begin
	drop view vw_student_grade_D
end
go
create view vw_student_grade_D
as
select
	s.studentID
	,s.ssn
	,s.FirstName
	,s.MiddileInitial
	,s.LastName
	,s.BirthDate
	,s.Gender
	,s.enrolled
	,s.courseID
	,s.enrollmentID
	,s.enrollmentDate
	,g.courseName
	,g.courseDescription
	,g.creditHours
	,g.islab
	,g.grade
	,g.gradeID
from
	vw_student_enrollment s
	join vw_coures_grade g
	on s.studentId=g.studentID and s.courseID=g.courseID
where
	g.grade = 'D'
go
if exists(select name from sys.objects where name='vw_student_grade_F')
begin
	drop view vw_student_grade_F
end
go
create view vw_student_grade_F
as
select
	s.studentID
	,s.ssn
	,s.FirstName
	,s.MiddileInitial
	,s.LastName
	,s.BirthDate
	,s.Gender
	,s.enrolled
	,s.courseID
	,s.enrollmentID
	,s.enrollmentDate
	,g.courseName
	,g.courseDescription
	,g.creditHours
	,g.islab
	,g.grade
	,g.gradeID
from
	vw_student_enrollment s
	join vw_coures_grade g
	on s.studentId=g.studentID and s.courseID=g.courseID
where
	g.grade = 'F'
go
if exists(select name from sys.objects where name='vw_Female_student_grades')
begin
	drop view vw_Female_student_grades
end
go
create view vw_Female_student_grades
as
select
	s.studentID
	,s.ssn
	,s.FirstName
	,s.MiddileInitial
	,s.LastName
	,s.BirthDate
	,s.Gender
	,s.enrolled
	,s.courseID
	,s.enrollmentID
	,s.enrollmentDate
	,s.courseName
	,s.courseDescription
	,s.creditHours
	,s.islab
	,s.grade
	,s.gradeID
from
	vw_student_grade_A s
where
	s.Gender='F'
union
select
	s.studentID
	,s.ssn
	,s.FirstName
	,s.MiddileInitial
	,s.LastName
	,s.BirthDate
	,s.Gender
	,s.enrolled
	,s.courseID
	,s.enrollmentID
	,s.enrollmentDate
	,s.courseName
	,s.courseDescription
	,s.creditHours
	,s.islab
	,s.grade
	,s.gradeID
from
	vw_student_grade_B s
where
	s.Gender='F'
union
select
	s.studentID
	,s.ssn
	,s.FirstName
	,s.MiddileInitial
	,s.LastName
	,s.BirthDate
	,s.Gender
	,s.enrolled
	,s.courseID
	,s.enrollmentID
	,s.enrollmentDate
	,s.courseName
	,s.courseDescription
	,s.creditHours
	,s.islab
	,s.grade
	,s.gradeID
from
	vw_student_grade_c s
where
	s.Gender='F'
union
select
	s.studentID
	,s.ssn
	,s.FirstName
	,s.MiddileInitial
	,s.LastName
	,s.BirthDate
	,s.Gender
	,s.enrolled
	,s.courseID
	,s.enrollmentID
	,s.enrollmentDate
	,s.courseName
	,s.courseDescription
	,s.creditHours
	,s.islab
	,s.grade
	,s.gradeID
from
	vw_student_grade_D s
where
	s.Gender='F'
union
select
	s.studentID
	,s.ssn
	,s.FirstName
	,s.MiddileInitial
	,s.LastName
	,s.BirthDate
	,s.Gender
	,s.enrolled
	,s.courseID
	,s.enrollmentID
	,s.enrollmentDate
	,s.courseName
	,s.courseDescription
	,s.creditHours
	,s.islab
	,s.grade
	,s.gradeID
from
	vw_student_grade_F s
where
	s.Gender='F'

go
if exists(select name from sys.objects where name='vw_male_student_grades')
begin
	drop view vw_male_student_grades
end
go
create view vw_male_student_grades
as
select
	s.studentID
	,s.ssn
	,s.FirstName
	,s.MiddileInitial
	,s.LastName
	,s.BirthDate
	,s.Gender
	,s.enrolled
	,s.courseID
	,s.enrollmentID
	,s.enrollmentDate
	,s.courseName
	,s.courseDescription
	,s.creditHours
	,s.islab
	,s.grade
	,s.gradeID
from
	vw_student_grade_A s
where
	s.Gender='M'
union
select
	s.studentID
	,s.ssn
	,s.FirstName
	,s.MiddileInitial
	,s.LastName
	,s.BirthDate
	,s.Gender
	,s.enrolled
	,s.courseID
	,s.enrollmentID
	,s.enrollmentDate
	,s.courseName
	,s.courseDescription
	,s.creditHours
	,s.islab
	,s.grade
	,s.gradeID
from
	vw_student_grade_B s
where
	s.Gender='M'
union
select
	s.studentID
	,s.ssn
	,s.FirstName
	,s.MiddileInitial
	,s.LastName
	,s.BirthDate
	,s.Gender
	,s.enrolled
	,s.courseID
	,s.enrollmentID
	,s.enrollmentDate
	,s.courseName
	,s.courseDescription
	,s.creditHours
	,s.islab
	,s.grade
	,s.gradeID
from
	vw_student_grade_c s
where
	s.Gender='M'
union
select
	s.studentID
	,s.ssn
	,s.FirstName
	,s.MiddileInitial
	,s.LastName
	,s.BirthDate
	,s.Gender
	,s.enrolled
	,s.courseID
	,s.enrollmentID
	,s.enrollmentDate
	,s.courseName
	,s.courseDescription
	,s.creditHours
	,s.islab
	,s.grade
	,s.gradeID
from
	vw_student_grade_D s
where
	s.Gender='M'
union
select
	s.studentID
	,s.ssn
	,s.FirstName
	,s.MiddileInitial
	,s.LastName
	,s.BirthDate
	,s.Gender
	,s.enrolled
	,s.courseID
	,s.enrollmentID
	,s.enrollmentDate
	,s.courseName
	,s.courseDescription
	,s.creditHours
	,s.islab
	,s.grade
	,s.gradeID
from
	vw_student_grade_F s
where
	s.Gender='M'

go
if exists(select name from sys.objects where name='vw_all_fields')
begin
	drop view vw_all_fields
end
go
create view vw_all_fields
as
select
	s.studentID
	,s.ssn
	,s.FirstName
	,s.MiddileInitial
	,s.LastName
	,s.BirthDate
	,s.Gender
	,s.enrolled
	,s.courseID
	,s.enrollmentID
	,s.enrollmentDate
	,s.courseName
	,s.courseDescription
	,s.creditHours
	,s.islab
	,s.grade
	,s.gradeID
from
	vw_Female_student_grades s
union
select
	s.studentID
	,s.ssn
	,s.FirstName
	,s.MiddileInitial
	,s.LastName
	,s.BirthDate
	,s.Gender
	,s.enrolled
	,s.courseID
	,s.enrollmentID
	,s.enrollmentDate
	,s.courseName
	,s.courseDescription
	,s.creditHours
	,s.islab
	,s.grade
	,s.gradeID
from
	vw_male_student_grades s
go
if exists(select name from sys.objects where name='vw_students')
begin
	drop view vw_students
end
go
create view vw_students
as
select
	s.studentID
	,s.ssn
	,s.FirstName
	,s.MiddileInitial
	,s.LastName
	,s.BirthDate
	,s.Gender
	,s.enrolled
from vw_all_fields s
go

if exists(select name from sys.objects where name='vw_Grades')
begin
	drop view vw_Grades 
end
go
create view vw_Grades
as
select
	g.gradeID
	,g.courseID
	,g.studentID
	,g.grade
from
	 vw_all_fields g
go
if exists(select name from sys.objects where name='vw_enrollment')
begin
	drop view vw_enrollment  
end
go
create view vw_enrollment
as
select
	e.enrollmentID
	,e.courseID
	,e.studentID
	,e.enrollmentDate
from
	 vw_all_fields e
go
if exists(select name from sys.objects where name='vw_courses')
begin
	drop view vw_courses  
end
go
create view vw_courses
as
select
	c.courseID
	,c.courseName
	,c.courseDescription
	,c.creditHours
	,c.islab
from
	 vw_all_fields c
go
