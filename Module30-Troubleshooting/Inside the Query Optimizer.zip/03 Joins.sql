use master
go
if exists(select name from sys.databases where name='joins')
begin
	drop database joins
end
go
create database joins
go
use joins
go
/*
Create Our Table
*/
create table Customers (Cust_Id int, Cust_Name varchar(10))
insert Customers values (1, 'Craig')
insert Customers values (2, 'John Doe')
insert Customers values (3, 'Jane Doe')
 
create table Sales (Cust_Id int, Item varchar(10))
insert Sales values (2, 'Camera')
insert Sales values (3, 'Computer')
insert Sales values (3, 'Monitor')
insert Sales values (4, 'Printer')


set statistics profile on
/*
Inner Join
*/
select *
from Sales S inner join Customers C
on S.Cust_Id = C.Cust_Id
option(loop join)
go
/*
Add a clustered Index
*/
create clustered index CI on Sales(Cust_Id)
go
select *
from Sales S inner join Customers C
on S.Cust_Id = C.Cust_Id
option(loop join)
go

/*
Outer Join's
Left & Full
*/
select *
from Sales S left outer join Customers C
on S.Cust_Id = C.Cust_Id


select *
from Sales S full outer join Customers C
on S.Cust_Id = C.Cust_Id

/*
Cross Join
*/
select *
from Sales S cross join Customers C

/*
Cross Apply
*/
create function dbo.fn_Sales(@Cust_Id int)
returns @Sales table (Item varchar(10))
as
begin
  insert @Sales select Item from Sales where Cust_Id = @Cust_Id
  return
end
 
select *
from Customers cross apply dbo.fn_Sales(Cust_Id)

select *
from Customers outer apply dbo.fn_Sales(Cust_Id)

/*
Semi 
*/
select *
from Customers C
where exists (
    select *
    from Sales S
    where S.Cust_Id = C.Cust_Id
)

/*anti*/


select *
from Customers C
where not exists (
    select *
    from Sales S
    where S.Cust_Id = C.Cust_Id
)


/*
Merge
*/
set statistics profile off
go
if exists(select name from sys.tables where name='T1')
begin
	drop table T1
end
create table T1 (a int, b int, x char(200))
go
if exists(select name from sys.tables where name='T2')
begin
	drop table T2
end
create table T2 (a int, b int, x char(200))
go
set nocount on
declare @i int
set @i = 0
while @i < 1000
  begin
    insert T1 values (@i * 2, @i * 5, @i)
    insert T2 values (@i * 3, @i * 7, @i)
    set @i = @i + 1
  end

--run query
set statistics profile on

select *
from T1 join T2 on T1.a = T2.a
option (merge join)

--create cxl and re-run
-- look at executes differences
if exists(select name from sys.indexes where name='T1ab')
begin
	drop index T1ab on dbo.T1
end
go
create unique clustered index T1ab on T1(a, b)
go
--run query
select *
from T1 join T2 on T1.a = T2.a
option (merge join)

--create unique clx on T2a
if exists(select name from sys.indexes where name='T2a')
begin
	drop index T2a on dbo.T2
end
go
create unique clustered index T2a on T2(a)

--run without the hint
select *
from T1 join T2 on T1.a = T2.a

--Two Column Join
select *
from T1 join T2 on T1.a = T2.a and T1.b = T2.b

--Non Equa Join
select *
from T1 join T2 on T1.a = T2.a and T1.b > T2.b

--Full Outer
select *
from T1 full outer join T2 on T1.a = T2.a

--Full Outer with no equa join
select *
from T1 full outer join T2 on T1.a < T2.a


/*
Hash
*/
set statistics profile off
go
if exists(select name from sys.tables where name='T1')
begin
	drop table T1
end
create table T1 (a int, b int, x char(200))
go
if exists(select name from sys.tables where name='T2')
begin
	drop table T2
end
create table T2 (a int, b int, x char(200))
go
if exists(select name from sys.tables where name='T3')
begin
	drop table T3
end
create table T3 (a int, b int, x char(200))
go 
set nocount on
declare @i int
set @i = 0
while @i < 1000
  begin
    insert T1 values (@i * 2, @i * 5, @i)
    set @i = @i + 1
  end
go 
declare @i int
set @i = 0
while @i < 10000
  begin
    insert T2 values (@i * 3, @i * 7, @i)
    set @i = @i + 1
  end
go 
declare @i int
set @i = 0
while @i < 100000
  begin
    insert T3 values (@i * 5, @i * 11, @i)
    set @i = @i + 1
  end
go
--run query 2 t join
select *
from T1 join T2 on T1.a = T2.a 

--run query 3 t join left deep
select *
from (T1 join T2 on T1.a = T2.a)
    join T3 on T1.b = T3.a

--run query predicate on 2 of the 3
--right deep
select *
from (T1 join T2 on T1.a = T2.a)
    join T3 on T1.b = T3.a
where T1.a < 100

