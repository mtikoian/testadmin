use tempdb 
go
if exists(select * from sys.tables where name='t1')
begin
	drop table t1
end
create table T1 (a int, x char(200))
 
set nocount on
declare @i int
set @i = 0
while @i < 1000000
  begin
    insert T1 values(@i, @i)
    set @i = @i + 1
  end

  /*
  We create a parallel query
  */

  select * from T1 where a < 1000
  go
  /*
  parallel and look at the spread across the cpu's
  */
  select * from T1 where a % 2 = 0 or a % 2 = 1
  go