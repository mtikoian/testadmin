--1. Blocked update
USE [AdventureWorks2014]
GO

UPDATE production.product
SET Name = Name
Where ProductID = 1


