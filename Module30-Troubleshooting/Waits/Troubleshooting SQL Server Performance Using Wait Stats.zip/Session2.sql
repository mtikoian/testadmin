--1. Leave transaction open
USE [AdventureWorks2014]
GO

BEGIN TRAN
UPDATE production.product
SET Name = Name
WHERE ProductID = 1

--2. Commit Transaction
COMMIT