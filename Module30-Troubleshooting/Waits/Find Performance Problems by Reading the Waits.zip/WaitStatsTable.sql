
-- Create a separate monitoring database in each instance for tracking these stats.
SET ANSI_NULLS, QUOTED_IDENTIFIER ON
GO
CREATE TABLE dbo.WaitStats(
SampleTime             datetime NOT NULL,
wait_type              nvarchar(60) NOT NULL,
waiting_tasks_count    bigint NOT NULL,
wait_time_ms           bigint NOT NULL,
max_wait_time_ms       bigint NOT NULL, 
signal_wait_time_ms    bigint NOT NULL,
CONSTRAINT pkWaitStats_SampleTime_WaitType PRIMARY KEY CLUSTERED(SampleTime, wait_type)
)

GO
