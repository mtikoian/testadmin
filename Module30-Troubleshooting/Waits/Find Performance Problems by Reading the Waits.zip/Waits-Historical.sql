
;WITH waits
AS
(  SELECT SampleTime, wait_type, waiting_tasks_count, wait_time_ms, signal_wait_time_ms, max_wait_time_ms, 
          DENSE_RANK() OVER (PARTITION BY wait_type ORDER BY wait_type, SampleTime) AS rn
     FROM WorkTableDB.dbo.WaitStats
-- adjust the WHERE clause to look for different SampleTime ranges.  The example below is all sample in previous 90 minutes.
   WHERE SampleTime > dateadd(minute, -90, getdate()) 
          wait_type NOT LIKE '%CLR_%' 
          AND wait_type NOT IN('BROKER_RECEIVE_WAITFOR', 'WAITFOR', 'LAZYWRITER_SLEEP', 'Total', 'WAIT_FOR_RESULTS')
)
SELECT CONVERT(char(19), SampleTime, 0) AS SampleTime, wait_type, waiting_tasks_count,ReqsPerSec, AvgWait
  FROM (
        SELECT SampleTime, wait_type, waiting_tasks_count, CONVERT(decimal(10, 2), waiting_tasks_count / (SampleDuration + 1.00)) AS ReqsPerSec, 
               CONVERT(decimal(10, 2), AvgWait) AS AvgWait
               
          FROM (SELECT t2.SampleTime, t2.wait_type, 
                       t2.waiting_tasks_count - t1.waiting_tasks_count AS waiting_tasks_count,
                       t2.wait_time_ms - t1.wait_time_ms               AS wait_time_ms, 
                       t2.signal_wait_time_ms - t1.signal_wait_time_ms AS signal_wait_time_ms ,
                       DateDiff(s, t1.SampleTime, t2.SampleTime)     AS SampleDuration,
                       (t2.wait_time_ms - t1.wait_time_ms) / (t2.waiting_tasks_count - t1.waiting_tasks_count + 1) AS AvgWait
                  FROM waits t1 INNER JOIN
                       waits t2 ON t1.wait_type = t2.wait_type AND t1.rn = t2.rn - 1 
                                   AND t1.waiting_tasks_count <= t2.waiting_tasks_count
               ) a
         WHERE waiting_tasks_count > 0 
)b
 ORDER BY SampleTime, (waiting_tasks_count / (SampleDuration + 1.00)) DESC
