Supporting scripts for the "Find Performance Problems by Reading the Waits" session by Eddie Wuerch

Thanks for attending the session!
Please feel free to send any questions or comments to eddie@indydba.com

About the scripts:
1. CurrentWaits.sql
   - run this script to see current activity in an instance

-- the rest of the scripts are for historical monitoring and troubleshooting --
2. WaitStatsTable.sql
   - First, create a separate database in each instance for monitoring
   - Use this script to create a table for storing historical wait stats

3. JobStep.sql
   - Create a SQL Agent job to run on schedule (every 30 minutes is a good frequency, 
     you're welcome to use a different schedule)
   - Run the job in the context of the monitoring database
   - Set the job to execute the code contained in the script

4. Waits-Historical.sql
   - Run this script to examine the table created in step #2
   - Modify the WHERE clause to examine different time ranges.  The date/time of
     each sample is contained in the SampleTime field.


