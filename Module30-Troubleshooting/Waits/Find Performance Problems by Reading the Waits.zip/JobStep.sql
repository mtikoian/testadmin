
-- Create a SQL Agent job to run every 30 minutes (or every 15 minutes, or every 60; it's up to you)
-- Execute this job in the context of your monitoring database to collect all of the historical wait stats
-- into the WaitStats table (see the script entitled 'WaitStats.sql')

INSERT dbo.WaitStats(SampleTime, wait_type, waiting_tasks_count, wait_time_ms, max_wait_time_ms, signal_wait_time_ms)
SELECT getdate(), wait_type, waiting_tasks_count, wait_time_ms, max_wait_time_ms, signal_wait_time_ms
  FROM sys.dm_os_wait_stats 

