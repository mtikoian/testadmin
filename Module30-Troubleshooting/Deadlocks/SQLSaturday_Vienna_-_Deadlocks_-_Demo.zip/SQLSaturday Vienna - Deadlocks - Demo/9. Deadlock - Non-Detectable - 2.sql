-- The script was kindly shared by 
-- Erland Sommarskog and Adam Machanic
-- All copyrights are belong to them
-- Connect Ticket: https://connect.microsoft.com/SQLServer/feedback/details/2938118/undetected-deadlock-because-of-execsync-waits

USE AdventureWorks2012
GO

SELECT
p.ProductID,
b0.MaxCost
FROM bigProduct AS p WITH (SERIALIZABLE)
CROSS APPLY
(
SELECT
MAX(bth.ActualCost) AS MaxCost
FROM bigTransactionHistory AS bth 
WHERE
bth.ActualCost BETWEEN p.ListPrice AND p.ListPrice + 10
) AS b0
