-- The script was kindly shared by Paul White. 
-- All copyrights are belong to him.

USE Test
GO

-- Parallel deadlock resolved by exchange spills
DECLARE 
    @a integer,
    @b integer

SELECT
    @a = a, 
    @b = b
FROM    
(
    SELECT TOP (2000000)
        a = T1.id % 80, 
        b = CHECKSUM(REVERSE(T1.padding))
    FROM dbo.Test AS T1
    JOIN dbo.Test AS T2 ON
        T2.id = T1.id
    WHERE
        T1.id BETWEEN 1 AND 200000
    ORDER BY 
        a, b
        
    UNION ALL
    
    SELECT TOP (2000000)
        a = T1.id % 80, 
        b = CHECKSUM(REVERSE(T1.padding))
    FROM dbo.Test AS T1
    JOIN dbo.Test AS T2 ON 
        T2.id = T1.id
    WHERE
        T1.id BETWEEN 1 AND 200000
    ORDER BY 
        a, b
) AS x
ORDER BY 
    x.a;


---- Test table
--CREATE TABLE dbo.Test 
--(
--    id          integer IDENTITY (1, 1) NOT NULL,
--    value       integer NOT NULL,
--    padding     char(999) NOT NULL,

--    CONSTRAINT [PK dbo.Test (id)]
--        PRIMARY KEY CLUSTERED (id),
--);
--GO
---- Add 1,000,000 rows
--INSERT dbo.Test WITH (TABLOCKX)
--    (value, padding)
--SELECT TOP (1000000)
--    value = CONVERT(integer, Data.n),
--    padding = REPLICATE(char(65 + (Data.n % 26)), 999)
--FROM
--(
--    SELECT TOP (1000000)
--        n = ROW_NUMBER() OVER (ORDER BY (SELECT 0))
--    FROM master.sys.columns C1
--    CROSS JOIN master.sys.columns C2
--    CROSS JOIN master.sys.columns C3
--    ORDER BY 
--        n ASC
--) AS Data
--ORDER BY
--    Data.n ASC;
--GO