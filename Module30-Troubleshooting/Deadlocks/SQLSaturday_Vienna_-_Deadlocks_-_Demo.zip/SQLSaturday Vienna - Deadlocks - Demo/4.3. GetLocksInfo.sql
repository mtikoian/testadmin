USE TwitterLight
GO

SELECT l.resource_type, l.resource_description, l.resource_associated_entity_id
     , l.request_mode, l.request_type, l.request_status, OBJECT_NAME(I.object_id) AS TableName
     , i.name AS IndexName, i.type_desc
FROM sys.dm_tran_locks l
INNER JOIN sys.partitions p ON p.partition_id = l.resource_associated_entity_id
INNER JOIN sys.indexes i ON i.object_id = p.object_id AND i.index_id = p.index_id
WHERE l.resource_type = 'KEY'
AND request_mode LIKE 'Range%'
ORDER BY l.request_mode, IndexName

DBCC IND('TwitterLight', 245575913, 4)
GO

DBCC PAGE('TwitterLight', 1, XXX, 3) WITH TABLERESULTS
GO

SELECT %%lockres%% AS LockResource, *
FROM dbo.Users WITH (NOLOCK, INDEX = IX_USERS_COMPANY)
WHERE %%lockres%% = 'XXX'
ORDER BY Company

SELECT Company, Name FROM Users 
ORDER BY Company
