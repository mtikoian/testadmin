USE Twitter2
GO

DROP TABLE FtsIndex
GO

DROP TABLE Terms
GO

DROP PROCEDURE QuickUpdate
GO
