-- The script was kindly shared by 
-- Erland Sommarskog and Adam Machanic
-- All copyrights are belong to them
-- Connect Ticket: https://connect.microsoft.com/SQLServer/feedback/details/2938118/undetected-deadlock-because-of-execsync-waits

USE AdventureWorks2012
GO 

BEGIN TRANSACTION

DELETE TOP (1) FROM bigTransactionHistory

-- Run Second Query

UPDATE TOP (1) bigProduct SET Name = UPPER(Name)

ROLLBACK
