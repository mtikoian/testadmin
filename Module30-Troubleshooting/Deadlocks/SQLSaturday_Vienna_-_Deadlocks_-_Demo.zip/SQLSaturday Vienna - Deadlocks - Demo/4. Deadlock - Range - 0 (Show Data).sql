USE TwitterLight
GO

SELECT * FROM Users
