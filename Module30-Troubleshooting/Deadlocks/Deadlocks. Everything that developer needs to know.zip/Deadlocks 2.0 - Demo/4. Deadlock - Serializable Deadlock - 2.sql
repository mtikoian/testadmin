USE TwitterLight
GO

SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
GO
 
WHILE (1=1)
BEGIN
	BEGIN TRAN
		DELETE FROM Statuses 
		WHERE UserId IN 
		(
			SELECT Id FROM Users
			WHERE Company = 'SQLCentry'
		);

		DELETE FROM Users
		WHERE Company = 'SQLCentry';
	ROLLBACK
END