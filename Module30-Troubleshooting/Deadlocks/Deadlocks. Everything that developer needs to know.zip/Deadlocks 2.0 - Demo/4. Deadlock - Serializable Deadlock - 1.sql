USE TwitterLight
GO

SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
GO

WHILE (1=1)
BEGIN
	BEGIN TRAN
		-- To show RANGE lockbehavior
		--SELECT Company FROM Users WHERE Company = 'SQL Skills';

		UPDATE Users SET Company = 'SQLSkills'
		WHERE Company = 'SQL Skills';

		SELECT * FROM Statuses 
		WHERE UserId IN
		(
			SELECT Id FROM Users
			WHERE Company = 'SQLSkills'
		);
	ROLLBACK
END