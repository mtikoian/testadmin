ALTER DATABASE [Twitter] SET READ_COMMITTED_SNAPSHOT OFF
GO

ALTER DATABASE [Twitter] SET ALLOW_SNAPSHOT_ISOLATION OFF
GO

USE Twitter
GO

SET TRANSACTION ISOLATION LEVEL READ COMMITTED
GO

WHILE (1 = 1)
BEGIN
	UPDATE NewStatuses SET text = '"Tweet" me your wishlist kids! Santa''s ready to block and report your dreams as spam.' WHERE id = 6243104882;
	UPDATE NewStatuses SET text = '"Tweet" me your wishlist kids! Santa''s ready to block your dreams as spam.' WHERE id = 6243104882;
END
GO
