USE TwitterLight
GO

SELECT l.resource_type, l.resource_description, l.resource_associated_entity_id
     , l.request_mode, l.request_type, l.request_status, OBJECT_NAME(I.object_id) AS TableName
     , i.name AS IndexName, i.type_desc
 FROM sys.dm_tran_locks l
 INNER JOIN sys.partitions p ON p.partition_id = l.resource_associated_entity_id
 INNER JOIN sys.indexes i ON i.object_id = p.object_id AND i.index_id = p.index_id
 WHERE l.resource_type = 'KEY'
	AND request_mode LIKE 'Range%'
 ORDER BY l.request_mode, IndexName

SELECT %%lockres%% AS LockResource, *
FROM dbo.Users WITH (NOLOCK, INDEX = IX_USERS_COMPANY)
WHERE Company IN ('SQLSkills', 'SQL Skills', 'SQLCentry')

SELECT %%lockres%% AS LockResource, *
FROM dbo.Statuses WITH (NOLOCK, INDEX = IX_STATUSES_USERID)
WHERE UserId IN (SELECT Id FROM Users WITH (NOLOCK) WHERE Company IN ('SQLSkills', 'SQL Skills', 'SQLCentry'))


