/*
	SELECT * 
	FROM DeadlockGraphQueue
*/
USE msdb;
GO
CREATE PROCEDURE dbo.deadlock_ProcessItems
AS

set nocount on;

while (1=1)
  BEGIN
	-- Process the Event Notification Queue
	DECLARE @deadlockevent XML,
			@deadlock xml,
			@victim varchar(50), 
			@victimplan XML, 
			@contribplan XML,
			@starttime datetime,
			@posttime datetime,
			@servername nvarchar(64);

	BEGIN TRANSACTION;

	-- Handle one message at a time		
	WAITFOR
	( RECEIVE TOP(1) 
			@deadlockevent = CAST(message_body AS XML)
		FROM dbo.DeadlockQueue
	), TIMEOUT 5000;	

	IF (@@ROWCOUNT = 0)
	 BEGIN 
		ROLLBACK TRANSACTION;
		BREAK;
	 END

	SELECT @deadlock = @deadlockevent.query('/EVENT_INSTANCE/TextData/*');

	SELECT
		@starttime = @deadlockevent.value(N'(/EVENT_INSTANCE/StartTime/text())[1]', 'datetime'),
		@posttime = @deadlockevent.value(N'(/EVENT_INSTANCE/PostTime/text())[1]', 'datetime'),
		@servername = @deadlockevent.value(N'(/EVENT_INSTANCE/ServerName/text())[1]', 'varchar(64)');

	-- Determine the victim from the graph		
	SELECT @victim = @deadlock.value('(deadlock-list/deadlock/@victim)[1]', 'varchar(50)');

	-- Get the victim plan
	SELECT @victimplan = [query_plan] 
	FROM sys.dm_exec_query_stats qs
	CROSS APPLY sys.dm_exec_query_plan([plan_handle])
	WHERE [sql_handle] = @deadlock.value('xs:hexBinary(substring((
		deadlock-list/deadlock/process-list/process[@id=sql:variable("@victim")]/executionStack/frame/@sqlhandle)[1], 
		3))', 'varbinary(max)');
		
	-- Get the contributing query plan
	SELECT @contribplan = [query_plan] 
	FROM sys.dm_exec_query_stats qs
	CROSS APPLY sys.dm_exec_query_plan([plan_handle])
	WHERE [sql_handle] = @deadlock.value('xs:hexBinary(substring((
		deadlock-list/deadlock/process-list/process[@id!=sql:variable("@victim")]/executionStack/frame/@sqlhandle)[1],
		 3))', 'varbinary(max)');

	
	IF @deadlock IS NOT NULL
	  BEGIN
		-- Return the result
		INSERT INTO DBA.dbo.DeadlockAnalysis (server_name, start_time, post_time, deadlock_graph, victim_plan, contrib_plan)
		SELECT 
			@servername,
			@starttime, 
			@posttime,
			@deadlock AS DeadlockGraph, 
			@victimplan AS VictimPlan, 
			@contribplan AS ContribPlan;
	  END

	COMMIT TRANSACTION;
END
SET NOCOUNT OFF;

GO
	  
CREATE QUEUE DeadlockQueue
WITH ACTIVATION 
(STATUS=ON,
	PROCEDURE_NAME = dbo.deadlock_ProcessItems,
	MAX_QUEUE_READERS = 5,
	EXECUTE AS SELF
);
GO
--��Create a service broker service receive the events
CREATE SERVICE DeadlockService
ON QUEUE DeadlockQueue ([http://schemas.microsoft.com/SQL/Notifications/PostEventNotification]);
GO
�
-- Create the event notification for deadlock graphs on the service
CREATE EVENT NOTIFICATION CaptureDeadlocks
ON SERVER
WITH FAN_IN
FOR DEADLOCK_GRAPH
TO SERVICE 'DeadlockService', 'current database' ;
GO 

USE DBA;
GO
IF NOT EXISTS(SELECT 1 FROM sys.tables where name = 'DeadlockAnalysis')
  BEGIN
CREATE TABLE dbo.DeadlockAnalysis (
	deadlock_id int not null identity(1,1),
	server_name nvarchar(64),
	start_time datetime,
	post_time datetime,
	deadlock_graph xml,
	victim_plan xml,
	contrib_plan xml,
	CONSTRAINT PK_DeadlockAnalysis_deadlockid PRIMARY KEY CLUSTERED (
		deadlock_id
	)
)
  END

GO








