USE Deadlocks

SELECT * FROM resource1 (NOLOCK)
SELECT * FROM resource2 (NOLOCK)


SELECT	 request_session_id
		,DB_NAME(tl.resource_database_id) AS DBName
		,COALESCE(st.name,st2.name) AS table_name
		,resource_type
		,resource_description
		--,resource_associated_entity_id
		,request_mode
		,request_status
		,er.blocking_session_id
		,er.wait_type
--SELECT tl.*		
FROM sys.dm_tran_locks tl
	LEFT JOIN sys.dm_exec_requests er ON tl.request_session_id = er.session_id AND tl.request_status = 'WAIT' AND er.blocking_session_id <> 0
	LEFT JOIN sys.partitions sp
		JOIN sys.tables st ON sp.[object_id] = st.[object_id]
			ON tl.resource_associated_entity_id = sp.partition_id
	LEFT JOIN sys.tables st2 ON tl.resource_associated_entity_id = st2.[object_id]
WHERE request_session_id IN (54, 53)
ORDER BY request_session_id, COALESCE(st.name,st2.name),resource_type,resource_description



USE Deadlocks
--Basic deadlock 3
BEGIN TRAN
UPDATE resource3 SET Data = 'Connection 3'

UPDATE resource1 SET Data = 'Connection 3'
COMMIT
