USE master
GO
IF EXISTS(SELECT 1 FROM sys.databases WHERE name = 'Deadlocks') 
BEGIN
	ALTER DATABASE Deadlocks SET RESTRICTED_USER WITH ROLLBACK IMMEDIATE
	DROP DATABASE Deadlocks
END
GO
CREATE DATABASE Deadlocks
GO
USE Deadlocks


--table setup
IF OBJECT_ID('resource1') IS NOT NULL DROP TABLE resource1
CREATE TABLE resource1 (ID int IDENTITY(1,1), Data varchar(255))
IF OBJECT_ID('resource2') IS NOT NULL DROP TABLE resource2
CREATE TABLE resource2 (ID int IDENTITY(50,1), Data varchar(255))
GO

INSERT resource1 default values
INSERT resource2 default values

SELECT * FROM resource1
SELECT * FROM resource2

--basic deadlock
BEGIN TRAN
UPDATE resource1 SET Data = 'Connection 1'

UPDATE resource2 SET Data = 'Connection 1'
COMMIT

/* get rid of the trace if it's already there
SELECT * FROM fn_trace_getinfo(NULL)
EXEC sp_trace_setstatus 2, 0
EXEC sp_trace_setstatus 2, 2
*/

SELECT * FROM fn_trace_gettable('C:\Temp\Deadlocktrace.trc',1)
SELECT ObjectID2 FROM fn_trace_gettable('C:\Temp\Deadlocktrace.trc',1)

SELECT sp.partition_id, SCHEMA_NAME(st.[schema_id]), st.name
FROM sys.partitions sp
	JOIN sys.tables st ON sp.[object_id] = st.[object_id]
WHERE sp.partition_id IN(72057594039107584,72057594039042048)



--deadlock with a clustered index
IF OBJECT_ID('resource1') IS NOT NULL DROP TABLE resource1
CREATE TABLE resource1 (ID int IDENTITY(1,1) CONSTRAINT PK_resource1 PRIMARY KEY, Data varchar(255))
IF OBJECT_ID('resource2') IS NOT NULL DROP TABLE resource2
CREATE TABLE resource2 (ID int IDENTITY(50,1) CONSTRAINT PK_resource2 PRIMARY KEY, Data varchar(255))
GO

INSERT resource1 default values
INSERT resource2 default values

BEGIN TRAN
UPDATE resource1 SET Data = 'Connection 1'

UPDATE resource2 SET Data = 'Connection 1'
COMMIT


IF OBJECT_ID('Detail') IS NOT NULL DROP TABLE Detail
IF OBJECT_ID('Header') IS NOT NULL DROP TABLE Header
CREATE TABLE Header (
	ID int IDENTITY(1,1) CONSTRAINT PK_Header PRIMARY KEY WITH (ALLOW_ROW_LOCKS = OFF,ALLOW_PAGE_LOCKS = ON), 
	Data varchar(255)
)

CREATE TABLE Detail (
	ID int IDENTITY(500,1) CONSTRAINT PK_Detail PRIMARY KEY WITH (ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON), 
	Data varchar(255), 
	HeaderID int CONSTRAINT FK_Detail_Header
		FOREIGN KEY REFERENCES Header(ID)
)
GO

INSERT Header default values
GO 50

DECLARE @i int
SET @i = 1
WHILE @i <= 50
BEGIN
	INSERT Detail (HeaderID) VALUES (@i)
	SET @i += 1
END
GO

SELECT * FROM Header
SELECT * FROM Detail

--Conversion deadlocks 1
BEGIN TRAN
--SELECT Data FROM Header WHERE ID = 15
SELECT Data FROM Header (HOLDLOCK) WHERE ID = 15

UPDATE Header SET Data = 'Connection 1' WHERE ID = 15
COMMIT

--Conversion deadlocks (the right way)
BEGIN TRAN
SELECT Data FROM Header (UPDLOCK) WHERE ID = 15

UPDATE Header SET Data = 'Connection 1' WHERE ID = 15
COMMIT

--Conversion deadlocks 2
BEGIN TRAN
SELECT Data FROM Header (HOLDLOCK) WHERE ID = 16

UPDATE Header SET Data = 'Connection 1' WHERE ID = 16
COMMIT



ALTER INDEX PK_Header ON Header SET (ALLOW_ROW_LOCKS = ON)



--Conversion deadlocks 3

BEGIN TRAN
DELETE Detail WHERE HeaderID = 3


DELETE FROM Header WHERE ID = 3
ROLLBACK
GO



CREATE INDEX ix_Detail_HeaderID ON Detail(HeaderID)
--DROP INDEX Detail.ix_Detail_HeaderID



--Basic deadlock 3
IF OBJECT_ID('resource3') IS NOT NULL DROP TABLE resource3
CREATE TABLE resource3 (ID int IDENTITY(1,1) CONSTRAINT PK_Resource3 PRIMARY KEY, Data varchar(255))

INSERT resource3 DEFAULT VALUES

BEGIN TRAN
UPDATE resource1 SET Data = 'Connection 1'

UPDATE resource2 SET Data = 'Connection 1'
COMMIT


--Conversion deadlocks 2 revisited
ALTER INDEX PK_Header ON Header SET (ALLOW_ROW_LOCKS = OFF)





BEGIN TRAN
DECLARE @bind_token varchar(255)
EXEC sp_getbindtoken @bind_token OUTPUT
PRINT @bind_token
SELECT Data FROM Header (HOLDLOCK) WHERE ID = 16

UPDATE Header SET Data = 'New Connection 1' WHERE ID = 16


COMMIT

SELECT Data FROM Header WHERE ID IN (15,16)





USE master
GO
IF EXISTS(SELECT 1 FROM sys.databases WHERE name = 'Deadlocks') 
BEGIN
	ALTER DATABASE Deadlocks SET RESTRICTED_USER WITH ROLLBACK IMMEDIATE
	DROP DATABASE Deadlocks
END
GO
CREATE DATABASE Deadlocks
GO
USE Deadlocks

--Collision deadlocks
--no collision on SQL 2008 R2 - improved hashing
IF OBJECT_ID('t1') IS NOT NULL DROP TABLE t1
CREATE TABLE t1 ([Date] datetime,
				  ID1 tinyint,
				  ID2 smallint,
				  ID3 int,
				  CONSTRAINT PK_t1 PRIMARY KEY ([Date],ID1,ID2,ID3))

GO

TRUNCATE TABLE t1

BEGIN TRAN
INSERT t1 VALUES ('2009-05-19',2,4271,5835066)

INSERT t1 VALUES ('2009-05-19',2,4619,2546652)
COMMIT

SELECT %%lockres%%, * from t1

--Lock escalation deadlocks
IF OBJECT_ID('t1') IS NOT NULL DROP TABLE t1
CREATE TABLE t1 (ID int PRIMARY KEY)
GO
IF OBJECT_ID('t2') IS NOT NULL DROP TABLE t2
CREATE TABLE t2 (ID int PRIMARY KEY)
GO

INSERT t1
SELECT num FROM dbo.Numbers
WHERE num <= 20000
GO

INSERT t2
SELECT num FROM dbo.Numbers
WHERE num <= 20000

SET STATISTICS IO ON
SET STATISTICS TIME ON
--will this cause a deadlock?
BEGIN TRAN
SELECT *
FROM t1 (XLOCK)
WHERE ID BETWEEN 1 AND 5000


SELECT *
FROM t2 (XLOCK)
WHERE ID BETWEEN 1 AND 5000
COMMIT


--what about this?
BEGIN TRAN
SELECT *
FROM t1 (XLOCK)
WHERE ID BETWEEN 1 AND 9999


SELECT *
FROM t2 (XLOCK)
WHERE ID BETWEEN 1 AND 5000
COMMIT







