/********************************************************************************
Michael DeFehr July 2009

This script will create or modify an auxiliary table of numbers to whatever
size specified by @MaxNum as set below

********************************************************************************/

DECLARE @base int, @MaxNum int
SET @MaxNum = 100000

/********************************************************************************/

IF OBJECT_ID('numbers') IS NULL
BEGIN
	CREATE TABLE numbers (
		 num int NOT NULL CONSTRAINT PK_numbers PRIMARY KEY
	)
END
ELSE
BEGIN
	TRUNCATE TABLE numbers
END

SET @base = 1

INSERT numbers VALUES (1)

WHILE @base * 2 <= @MaxNum
BEGIN
	INSERT numbers
	SELECT num + @base 
	FROM numbers
	
	SET @base = @base * 2
END

INSERT numbers
SELECT num + @base 
FROM numbers
WHERE num + @base <= @MaxNum

/*
SELECT COUNT(*) AS NumCount, MAX(num) AS NumMax, MIN(num) AS NumMin FROM numbers
*/

/*
CREATE FUNCTION [dbo].[adm_split_array](@InStr varchar(max), @RowSep char(1))
	RETURNS TABLE
	AS
	RETURN
		SELECT	(num-1) - LEN(REPLACE(LEFT(@InStr,num-1),@RowSep,'')) + 1 AS RowNumber,
				SUBSTRING(@InStr,num,CHARINDEX(@RowSep,@InStr+@RowSep,num)-num) AS RowData
		FROM numbers
		WHERE num <= LEN(@InStr) + 1
			AND SUBSTRING(@RowSep+ @InStr, num, 1) = @RowSep
GO
*/

--SELECT * FROM sys.dm_db_index_physical_stats(DB_ID(),OBJECT_ID('dbo.numbers'),1,NULL,'DETAILED') ddips