USE Deadlocks

--basic deadlock & deadlock with a clustered index
BEGIN TRAN
UPDATE resource2 SET Data = 'Connection 2'

UPDATE resource1 SET Data = 'Connection 2'
COMMIT

SELECT %%lockres%%, * FROM resource1
SELECT %%lockres%%, * FROM resource2



--Conversion deadlocks 1 & 2
BEGIN TRAN
--SELECT Data FROM Header WHERE ID = 15
SELECT Data FROM Header (HOLDLOCK) WHERE ID = 15

UPDATE Header SET Data = 'Connection 2' WHERE ID = 15
COMMIT

SELECT * FROM Header WHERE ID = 15

--Conversion deadlocks 1 (the right way)
BEGIN TRAN
SELECT Data FROM Header (UPDLOCK) WHERE ID = 15

UPDATE Header SET Data = 'Connection 2' WHERE ID = 15
COMMIT

--Conversion deadlocks 3
BEGIN TRAN
DELETE FROM Detail WHERE HeaderID = 14


DELETE FROM Header WHERE ID = 14
ROLLBACK


--Basic deadlock 3
BEGIN TRAN
UPDATE resource2 SET Data = 'Connection 2'

UPDATE resource3 SET Data = 'Connection 2'
COMMIT


--Conversion deadlocks 2 revisited
BEGIN TRAN
EXEC sp_bindsession '>3]K]TWMGagNNC=QIb0=C=5---0kB=--'
SELECT Data FROM Header (HOLDLOCK) WHERE ID = 15

UPDATE Header SET Data = 'New Connection 2' WHERE ID = 15

COMMIT



--Collision deadlocks
USE Deadlocks
GO
BEGIN TRAN
INSERT t1 VALUES ('2009-05-19',3,4245,2651987)

INSERT t1 VALUES ('2009-05-19',3,4657,5744053)
COMMIT


--will this cause a deadlock?
BEGIN TRAN
SELECT *
FROM t2 (XLOCK)
WHERE ID BETWEEN 10001 AND 14999

SELECT *
FROM t1 (XLOCK)
WHERE ID BETWEEN 10001 AND 14999
COMMIT


--what about this?
BEGIN TRAN
SELECT *
FROM t2 (XLOCK)
WHERE ID BETWEEN 10001 AND 19999


SELECT *
FROM t1 (XLOCK)
WHERE ID BETWEEN 10001 AND 14999
COMMIT
