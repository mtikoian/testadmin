/*
 There are four main challenges with SQL Server's plan cache: bloat, suboptimal 
	plan reuse, parameter sniffing, and recompiles.

 BLOAT occurs when SQL Server is forced to keep many variations of a single plan 
	active in the cache, usually caused by coding problems. 
 SUBOPTIMAL PLAN REUSE usually occurs due to stale or missing statistics, cardinality 
	estimate problems, or coding problems such as dynamic queries, execution context,
	object name resolution, and inappropriate hints.
 PARAMETER SNIFFING is a form of suboptimal plan reuse linked to parameters passed
	into a batch, causing the optimizer to make bad optimization choices.
 RECOMPILES not all recompiles are bad. (In fact, some types of batches are never 
	cached, but can still cause recompilations. For example, certain batches containing 
	very long literals might not be cached). Recompilations are only an issue if they 
	happen too frequently and slow down batch executions considerably. Compilation is 
	the process of creating a compiled plan from a query batch. Recompiles occur in SQL
	Server when it goes to execute an already compiled plan, but determins that the plan 
	is either invalid or suboptimal. 
*/

/*
 Plan Cache comprises four main cache stores: Object Plans, SQL Plans, Bound Trees and 
	Extended Stored Procedures.
*/

/* BLOAT

	Ad-hoc Queries and Plan Cache Bloat
	Read more at http://blogs.msdn.com/b/sqlprogrammability/archive/2007/01/09/1-0-structure-of-the-plan-cache-and-types-of-cached-objects.aspx.

	Here's why coding standards are so important.
*/
DBCC FREEPROCCACHE;
DBCC FREESYSTEMCACHE('ALL');
GO

SELECT TOP (1) SalesOrderID FROM Sales.SalesOrderDetail;
GO

SELECT TOP (1) SalesOrderID 
FROM Sales.SalesOrderDetail;
GO
-- single carriage return

GO
SELECT TOP (1)  SalesOrderID FROM Sales.SalesOrderDetail;
GO
---------------^ extra space

GO
SELECT TOP (1) salesorderid FROM sales.salesorderdetail;
GO
-- lower case entity names

GO
select top (1) SalesOrderID from Sales.SalesOrderDetail;
GO

-- lower case keywords
GO

SELECT t.[text], p.size_in_bytes, p.usecounts
FROM sys.dm_exec_cached_plans AS p
CROSS APPLY sys.dm_exec_sql_text(p.plan_handle) AS t
WHERE t.[text] LIKE '%SalesOrder'+'Detail%';



/* SUBOPTIMAL PLANS

	There are lots of reasons as to why SQL Server might choose a suboptimal plan.
	One of the most common reasons is alternate 'execution contexts'. Execution 
	contexts hold the values that are needed for a specific execution of a query plan,
	like user info, parameter values, conditional branching, and certain SET conditions.

*/


/* PARAMETERIZATION

Auto-parameterized queries
	In some cases, SQL Server replaces constant literal values before compiling a 
	query plan. If a subsequent query differs in only the values of the constants, 
	it will match against the auto-parameterized query. In general, SQL Server 
	auto-parameterizes those queries whose parameterized form of the query would 
	result in a trivial plan. A trivial plan exists when the query optimizer 
	determines that only one plan is possible.

	Read more at http://blogs.msdn.com/b/sqlprogrammability/archive/2007/01/11/4-0-query-parameterization.aspx.
*/

SELECT ProductID, SalesOrderID
FROM Sales.SalesOrderDetail
WHERE ProductID > 100
ORDER BY ProductID;

SELECT ProductID, SalesOrderID
FROM Sales.SalesOrderDetail
WHERE ProductID > 200
ORDER BY ProductID;

-- An auto-parameterized version of the above:
-- SELECT [ProductID],[SalesOrderID]
-- FROM [Sales].[SalesOrderDetail]
-- WHERE [ProductID]>@1
-- ORDER BY [ProductID] ASC;

-- NOTE: Use SP_EXECUTESQL where possible instead of EXEC since you must explicitly 
--	identifies the parameters and are much more likely to get good plan reuse. 

/* PARAMETER SNIFFING
	
	When any parameterized batch is first compiled, the values of the parameters supplied 
	in the execution call are used to optimize the statements within that code. This process 
	is known as "parameter sniffing." Whe values are typical, then most calls will benefit. 
	But when the parameter values are atypical, reuse of a poor pre-existing plan is not desirable. 

*/

/* KEEPFIXED PLAN Hint
	To avoid recompilations due to plan optimality-related (statistic update-related) reasons 
*/
SELECT soh.SalesOrderID,soh.DueDate,
       sod.OrderQty,sod.ProductID
FROM Sales.SalesOrderHeader AS soh
INNER JOIN Sales.SalesOrderDetail AS sod
ON soh.SalesOrderID = sod.SalesOrderID
WHERE soh.CustomerID > 30117
OPTION (KEEPFIXED PLAN);

/* OPTIMIZE FOR Query Hint
	The OPTIMIZE FOR query hint helps avoid parameter sniffing problems caused by the 
	first execution of a procedure where atypical parameter values are passed.

	Parameter Sniffing note - If the SELECT statement below was included in a stored procedure, the effectiveness of 
	the query plan produced would be significantly influenced by the value passed to the query on its first execution.
*/

-- 1 row
SELECT soh.SalesOrderID,soh.DueDate,
       sod.OrderQty,sod.ProductID
FROM Sales.SalesOrderHeader AS soh
INNER JOIN Sales.SalesOrderDetail AS sod
ON soh.SalesOrderID = sod.SalesOrderID
WHERE soh.CustomerID > 30117;

-- Lots of rows and a very different query plan
SELECT soh.SalesOrderID,soh.DueDate,
       sod.OrderQty,sod.ProductID
FROM Sales.SalesOrderHeader AS soh
INNER JOIN Sales.SalesOrderDetail AS sod
ON soh.SalesOrderID = sod.SalesOrderID
WHERE soh.CustomerID > 10000;

--OPTION (OPTIMIZE FOR 30117)
--OPTION (OPTIMIZE FOR UNKNOWN)
--OPTION (RECOMPILE)