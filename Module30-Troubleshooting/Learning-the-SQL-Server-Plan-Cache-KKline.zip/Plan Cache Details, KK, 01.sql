-- K.Kline, exploring the plan cache


-- Total buffer usage 
-- Query for the total buffer size, SQL2008
SELECT COUNT(*)AS Cached_Pages_Count -- Buffer Pool Pages
	,COUNT(*) * 8192 / (1024 * 1024) AS Buffer_Pool_MB
FROM sys.dm_os_buffer_descriptors

-- Query for the buffer pages by database
SELECT LEFT(CASE database_id 
        WHEN 32767 THEN 'ResourceDb' 
        ELSE db_name(database_id) 
        END, 20) AS Database_Name
	,COUNT(*)AS Cached_Pages_Count -- Buffer Pool Pages
	,COUNT(*) * 8192 / (1024 * 1024) as Buffer_Pool_MB
FROM sys.dm_os_buffer_descriptors
GROUP BY db_name(database_id) ,database_id
ORDER BY cached_pages_count DESC

-- What is the plan cache?
SELECT  * 
FROM sys.dm_os_memory_cache_counters 
ORDER BY pages_kb DESC

-- How big is the plan cache?
SELECT SUM(pages_kb) AS Cache_KB
	, SUM(pages_kb) / 1024 AS Cache_MB
FROM sys.dm_os_memory_cache_counters  

-- current usage of the plan cache objects 
SELECT
    domcc.name,
    domcc.[type],
    domcc.pages_kb,
    domcc.pages_in_use_kb,
    domcc.entries_count,
    domcc.entries_in_use_count
FROM sys.dm_os_memory_cache_counters AS domcc
WHERE domcc.[type] IN 
(
    N'CACHESTORE_OBJCP',       -- Object Plans
    N'CACHESTORE_SQLCP',       -- SQL Plans
    N'CACHESTORE_PHDR',        -- Bound Trees
    N'CACHESTORE_XPROC',       -- Extended Stored Procedures
    N'CACHESTORE_TEMPTABLES'   -- Temporary Tables & Table Variables
);

-- Current details for the query optimizer
SELECT * FROM sys.dm_exec_query_optimizer_info;

--  Let's look at the Plan Types
SELECT [cacheobjtype] AS [Cache Obj Type], [objtype] AS [Plan Type],
    COUNT(*) AS [# of Plans],
    (SUM(CAST([size_in_bytes] AS BIGINT))/1024)/1024 AS [Size MBs],
    AVG([usecounts]) AS [Use Counts]
FROM sys.dm_exec_cached_plans
    GROUP BY [cacheobjtype], [objtype];

--  See how many plans per bucket
SELECT b.[cacheobjtype] AS [Cache Obj Type], b.[objtype] AS [Plan Type], b.[bucketid], COUNT(*) AS [Totals]
    FROM sys.dm_exec_cached_plans AS b
    GROUP BY b.bucketid, b.[cacheobjtype], b.[objtype]
    ORDER BY [Totals] Desc;
    
--  Look at the plans in a bucket
SELECT b.[cacheobjtype], b.[objtype], b.[refcounts], b.[usecounts]
    , a.[dbid], a.[objectid], b.[size_in_bytes], a.[text]
FROM sys.dm_exec_cached_plans as b
    CROSS APPLY sys.dm_exec_sql_text(b.[plan_handle]) AS a
WHERE bucketid = 331;


--  clear all plans from the plan cache
DBCC FREEPROCCACHE;

--  All currently cached plans using the DMV's
SELECT b.[cacheobjtype], b.[objtype], b.[refcounts], b.[usecounts]
    , DB_NAME(a.[dbid]) AS 'DB', a.[objectid], b.[size_in_bytes], a.[text]
FROM sys.dm_exec_cached_plans as b
    CROSS APPLY sys.dm_exec_sql_text(b.[plan_handle]) AS a
ORDER BY [usecounts] DESC;

-- Most used non-system plans, i.e. filter out stuff that's probably not user generated
SELECT b.[cacheobjtype], b.[objtype], b.[usecounts], a.[text]
FROM sys.dm_exec_cached_plans as b
    CROSS APPLY sys.dm_exec_sql_text(b.[plan_handle]) AS a
WHERE b.[cacheobjtype] IN ('Compiled Plan')  -- ('Compiled Plan','Extended Proc','CLR Compiled Func','CLR Compiled Proc')
    ORDER BY [usecounts] DESC;

--  100 Most used Plans
SELECT top 100 b.[cacheobjtype], b.[objtype], b.[refcounts], b.[usecounts]
    , a.[dbid], a.[objectid], b.[size_in_bytes], a.[text]
FROM sys.dm_exec_cached_plans as b
    CROSS APPLY sys.dm_exec_sql_text(b.[plan_handle]) AS a
WHERE b.[cacheobjtype] IN ('Compiled Plan')
    ORDER BY [usecounts] DESC;

--  100 Least used Plans
SELECT top 100 b.[cacheobjtype], b.[objtype], b.[refcounts], b.[usecounts]
    , a.[dbid], a.[objectid], b.[size_in_bytes], a.[text]
FROM sys.dm_exec_cached_plans as b
    CROSS APPLY sys.dm_exec_sql_text(b.[plan_handle]) AS a
WHERE b.[cacheobjtype] IN ('Compiled Plan')
    ORDER BY [usecounts] ASC;

--  The total size and numbers of plans in the cache
SELECT SUM(CAST(size_in_bytes AS BIGINT)) / 1024 / 1024 AS [Total Size MB]
    FROM sys.dm_exec_cached_plans AS a

--  Cache memory usage
SELECT * 
FROM sys.dm_os_memory_cache_hash_tables 
WHERE type IN ('CACHESTORE_OBJCP', 'CACHESTORE_SQLCP');




/* DETECTING RECOMPILES 
In particular, plan_generation_num indicates the number of times 
the query has recompiled. The following sample query gives you the 
top 25 stored procedures that have been recompiled.
*/

SELECT top 25
    sql_text.text,
    sql_handle,
    plan_generation_num,
    execution_count,
    dbid,
    objectid 
FROM 
    sys.dm_exec_query_stats a
    cross apply sys.dm_exec_sql_text(sql_handle) as sql_text
WHERE 
    plan_generation_num >1
ORDER BY plan_generation_num DESC;
GO

-- SQL Server performance counters.
-- Capture the first counter set
SELECT  CAST(1 AS INT) AS collection_instance ,
        object_name ,
        counter_name ,
        instance_name ,
        cntr_value ,
        cntr_type ,
        CURRENT_TIMESTAMP AS collection_time
FROM    sys.dm_os_performance_counters
WHERE   ( object_name = 'SQLServer:SQL Statistics'
             AND counter_name = 'SQL Re-Compilations/sec'
           )
         OR ( object_name = 'SQLServer:SQL Statistics'
             AND counter_name = 'SQL Compilations/sec'
           );
GO 10