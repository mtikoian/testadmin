USE [msdb]
GO

DECLARE @jobId binary(16)

SELECT @jobId = job_id FROM msdb.dbo.sysjobs 
WHERE (name = N'Ntirety - DMVDataGather')
IF (@jobId IS  NULL)
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0

EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Ntirety - DMVDataGather', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [DMV Query]    Script Date: 7/21/2014 4:05:49 PM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DMV Query', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'/*
Code to gather DMV query data into the Ntirety database

All DMV queries directly from or modified from Glenn
Berry''s excellent code at
https://sqlserverperformance.wordpress.com/2014/04/18/sql-server-diagnostic-information-queries-for-april-2014/

Creates tables in Ntirety database, job, and output folder if they don''t exist

By default the job is set to run every ten minutes at 5 after (12:05, 12:15, etc.)

Andy Galbraith - Ntirety - 2014/07/21
*/

SET NOCOUNT ON 

USE MASTER
GO

----------

/* 
Code to check for folder''s existence modified from
http://sqldbpool.com/2011/07/06/t-sql-script-to-checkcreate-directory/
*/

declare @chkdirectory as nvarchar(4000)
declare @folder_exists as int
     
set @chkdirectory = ''C:\Ntirety\JobOut''
 
declare @file_results table
	(file_exists int,
	file_is_a_directory int,
	parent_directory_exists int
	)
 
insert into @file_results
(file_exists, file_is_a_directory, parent_directory_exists)
exec master.dbo.xp_fileexist @chkdirectory
     
select @folder_exists = file_is_a_directory
from @file_results
       
if @folder_exists = 0
begin
	EXECUTE master.dbo.xp_create_subdir @chkdirectory
end       
GO

----------

/*
Create database if it doesn''t exists
*/

if db_id(''Ntirety'') is null
	CREATE DATABASE [Ntirety]

----------

/*
Create tables if they doesn''t exist
*/

USE [Ntirety]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

----------

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[AdhocPlanCacheGlennQuery40]'') AND type in (N''U''))
BEGIN
CREATE TABLE [dbo].[AdhocPlanCacheGlennQuery40](
   [ID] [int] IDENTITY(1,1) NOT NULL,
	[Datestamp] [datetime] NOT NULL,
	[QueryText] [nvarchar](max) NULL,
	[cacheobjtype] [nvarchar](50) NOT NULL,
	[objtype] [nvarchar](20) NOT NULL,
	[size_in_bytes] [int] NOT NULL
CONSTRAINT [PK_AdhocPlanCacheGlennQuery40] PRIMARY KEY CLUSTERED 
(
    [ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO

IF NOT EXISTS(SELECT * FROM sys.indexes WHERE name = ''IX_AdhocPlanCacheGlennQuery40_Datestamp'' 
	AND object_id = OBJECT_ID(''AdhocPlanCacheGlennQuery40''))
    BEGIN
        CREATE INDEX IX_AdhocPlanCacheGlennQuery40_Datestamp on AdhocPlanCacheGlennQuery40 (Datestamp DESC)
    END

----------

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[BufferPoolByDatabaseGlennQuery29]'') AND type in (N''U''))
BEGIN
CREATE TABLE [dbo].[BufferPoolByDatabaseGlennQuery29](
	 [ID] [int] IDENTITY(1,1) NOT NULL,
	 [DateStamp] [datetime] NOT NULL,
	[Buffer Pool Rank] [bigint] NULL,
	[Database Name] [nvarchar](128) NULL,
	[Cached Size (MB)] [decimal](10, 2) NULL,
	[Buffer Pool Percent] [decimal](5, 2) NULL
CONSTRAINT [PK_BufferPoolByDatabaseGlennQuery29] PRIMARY KEY CLUSTERED 
(
    [ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
) ON [PRIMARY]
END
GO

IF NOT EXISTS(SELECT * FROM sys.indexes WHERE name = ''IX_BufferPoolByDatabaseGlennQuery29_Datestamp'' 
	AND object_id = OBJECT_ID(''BufferPoolByDatabaseGlennQuery29''))
    BEGIN
        CREATE INDEX IX_BufferPoolByDatabaseGlennQuery29_Datestamp on BufferPoolByDatabaseGlennQuery29 (Datestamp DESC)
    END

----------

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[CPUByDatabaseGlennQuery27]'') AND type in (N''U''))
BEGIN
CREATE TABLE [dbo].[CPUByDatabaseGlennQuery27](
   [ID] [int] IDENTITY(1,1) NOT NULL,
   	[DateStamp] [datetime] NOT NULL,
	[CPU Rank] [bigint] NULL,
	[Database Name] [nvarchar](128) NULL,
	[CPU Time (ms)] [bigint] NULL,
	[CPU Percent] [decimal](5, 2) NULL
CONSTRAINT [PK_CPUByDatabaseGlennQuery27] PRIMARY KEY CLUSTERED 
(
    [ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
) ON [PRIMARY]
END
GO

IF NOT EXISTS(SELECT * FROM sys.indexes WHERE name = ''IX_CPUByDatabaseGlennQuery27_Datestamp'' 
	AND object_id = OBJECT_ID(''CPUByDatabaseGlennQuery27''))
    BEGIN
        CREATE INDEX IX_CPUByDatabaseGlennQuery27_Datestamp on CPUByDatabaseGlennQuery27 (Datestamp DESC)
    END

----------

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[IndexReadWritesGlennQuery60]'') AND type in (N''U''))
BEGIN
CREATE TABLE [dbo].[IndexReadWritesGlennQuery60](
   [ID] [int] IDENTITY(1,1) NOT NULL,
	[Datestamp] [datetime] NOT NULL,
	[DatabaseName] [nvarchar](128) NULL,
	[ObjectName] [nvarchar](128) NULL,
	[IndexName] [sysname] NULL,
	[index_id] [int] NOT NULL,
	[Reads] [bigint] NULL,
	[Writes] [bigint] NOT NULL,
	[IndexType] [nvarchar](60) NULL,
	[FillFactor] [tinyint] NOT NULL,
	[has_filter] [bit] NULL,
	[filter_definition] [nvarchar](max) NULL,
	[last_user_scan] [datetime] NULL,
	[last_user_lookup] [datetime] NULL,
	[last_user_seek] [datetime] NULL
CONSTRAINT [PK_IndexReadWritesGlennQuery60] PRIMARY KEY CLUSTERED 
(
    [ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO

IF NOT EXISTS(SELECT * FROM sys.indexes WHERE name = ''IX_IndexReadWritesGlennQuery60_Datestamp'' 
	AND object_id = OBJECT_ID(''IndexReadWritesGlennQuery60''))
    BEGIN
        CREATE INDEX IX_IndexReadWritesGlennQuery60_Datestamp on IndexReadWritesGlennQuery60 (Datestamp DESC)
    END

----------

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[IOByDatabaseGlennQuery28]'') AND type in (N''U''))
BEGIN
CREATE TABLE [dbo].[IOByDatabaseGlennQuery28](
   [ID] [int] IDENTITY(1,1) NOT NULL,
	[DateStamp] [datetime] NOT NULL,
	[I/O Rank] [bigint] NULL,
	[Database Name] [nvarchar](128) NULL,
	[Total I/O (MB)] [decimal](12, 2) NULL,
	[I/O Percent] [decimal](5, 2) NULL
CONSTRAINT [PK_IOByDatabaseGlennQuery28] PRIMARY KEY CLUSTERED 
(
    [ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
) ON [PRIMARY]
END
GO

IF NOT EXISTS(SELECT * FROM sys.indexes WHERE name = ''IX_IOByDatabaseGlennQuery28_Datestamp'' 
	AND object_id = OBJECT_ID(''IOByDatabaseGlennQuery28''))
    BEGIN
        CREATE INDEX IX_IOByDatabaseGlennQuery28_Datestamp on IOByDatabaseGlennQuery28 (Datestamp DESC)
    END

----------

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[IOByFileGlennQuery42]'') AND type in (N''U''))
BEGIN
CREATE TABLE [dbo].[IOByFileGlennQuery42](
   [ID] [int] IDENTITY(1,1) NOT NULL,
	[Datestamp] [datetime] NOT NULL,
	[Database Name] [nvarchar](128) NULL,
	[Logical Name] [sysname] NOT NULL,
	[file_id] [smallint] NOT NULL,
	[Physical Name] [nvarchar](260) NOT NULL,
	[num_of_reads] [bigint] NOT NULL,
	[num_of_writes] [bigint] NOT NULL,
	[io_stall_read_ms] [bigint] NOT NULL,
	[io_stall_write_ms] [bigint] NOT NULL,
	[IO Stall Reads Pct] [decimal](10, 1) NULL,
	[IO Stall Writes Pct] [decimal](10, 1) NULL,
	[Writes + Reads] [bigint] NULL,
	[MB Read] [decimal](10, 2) NULL,
	[MB Written] [decimal](10, 2) NULL,
	[# Reads Pct] [decimal](10, 1) NULL,
	[# Write Pct] [decimal](10, 1) NULL,
	[Read Bytes Pct] [decimal](10, 1) NULL,
	[Written Bytes Pct] [decimal](10, 1) NULL
CONSTRAINT [PK_IOByFileGlennQuery42] PRIMARY KEY CLUSTERED 
(
    [ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
) ON [PRIMARY]
END
GO

IF NOT EXISTS(SELECT * FROM sys.indexes WHERE name = ''IX_IOByFileGlennQuery42_Datestamp'' 
	AND object_id = OBJECT_ID(''IOByFileGlennQuery42''))
    BEGIN
        CREATE INDEX IX_IOByFileGlennQuery42_Datestamp on IOByFileGlennQuery42 (Datestamp DESC)
    END

----------

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[IOBySPGlennQuery51]'') AND type in (N''U''))
BEGIN
CREATE TABLE [dbo].[IOBySPGlennQuery51](
   [ID] [int] IDENTITY(1,1) NOT NULL,
	[Datestamp] [datetime] NOT NULL,
	[DatabaseName] [nvarchar](128) NULL,
	[SP Name] [nvarchar](128) NULL,
	[Avg IO] [bigint] NULL,
	[Execution Count] [bigint] NOT NULL,
	[Query Text] [nvarchar](max) NULL
CONSTRAINT [PK_IOBySPGlennQuery51] PRIMARY KEY CLUSTERED 
(
    [ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO

IF NOT EXISTS(SELECT * FROM sys.indexes WHERE name = ''IX_IOBySPGlennQuery51_Datestamp'' 
	AND object_id = OBJECT_ID(''IOBySPGlennQuery51''))
    BEGIN
        CREATE INDEX IX_IOBySPGlennQuery51_Datestamp on IOBySPGlennQuery51 (Datestamp DESC)
    END

----------

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[LUNVolumeInfoGlennQuery21]'') AND type in (N''U''))
BEGIN
CREATE TABLE [dbo].[LUNVolumeInfoGlennQuery21](
   [ID] [int] IDENTITY(1,1) NOT NULL,
	[DateStamp] [datetime] NOT NULL,
	[volume_mount_point] [nvarchar](256) NULL,
	[file_system_type] [nvarchar](256) NULL,
	[logical_volume_name] [nvarchar](256) NULL,
	[Total Size (GB)] [decimal](18, 2) NULL,
	[Available Size (GB)] [decimal](18, 2) NULL,
	[Space Free %] [decimal](22, 2) NULL
CONSTRAINT [PK_LUNVolumeInfoGlennQuery21] PRIMARY KEY CLUSTERED 
(
    [ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
) ON [PRIMARY]
END
GO

IF NOT EXISTS(SELECT * FROM sys.indexes WHERE name = ''IX_LUNVolumeInfoGlennQuery21_Datestamp'' 
	AND object_id = OBJECT_ID(''LUNVolumeInfoGlennQuery21''))
    BEGIN
        CREATE INDEX IX_LUNVolumeInfoGlennQuery21_Datestamp on LUNVolumeInfoGlennQuery21 (Datestamp DESC)
    END

----------

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[PLEGlennQuery37]'') AND type in (N''U''))
BEGIN
CREATE TABLE [dbo].[PLEGlennQuery37](
   [ID] [int] IDENTITY(1,1) NOT NULL,
	[Datestamp] [datetime] NOT NULL,
	[Server Name] [nvarchar](128) NULL,
	[object_name] [nchar](128) NOT NULL,
	[instance_name] [nchar](128) NULL,
	[Page Life Expectancy] [bigint] NOT NULL
CONSTRAINT [PK_PLEGlennQuery37] PRIMARY KEY CLUSTERED 
(
    [ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
) ON [PRIMARY]
END
GO

IF NOT EXISTS(SELECT * FROM sys.indexes WHERE name = ''IX_PLEGlennQuery37_Datestamp'' 
	AND object_id = OBJECT_ID(''PLEGlennQuery37''))
    BEGIN
        CREATE INDEX IX_PLEGlennQuery37_Datestamp on PLEGlennQuery37 (Datestamp DESC)
    END

----------

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[RecentDiffBackupsGlennQuery62]'') AND type in (N''U''))
BEGIN
CREATE TABLE [dbo].[RecentDiffBackupsGlennQuery62](
   [ID] [int] IDENTITY(1,1) NOT NULL,
	[Datestamp] [datetime] NOT NULL,
	[machine_name] [nvarchar](128) NULL,
	[server_name] [nvarchar](128) NULL,
	[Database Name] [nvarchar](128) NULL,
	[recovery_model] [nvarchar](60) NULL,
	[Backup Elapsed Time (sec)] [int] NULL,
	[Backup Finish Date] [datetime] NULL,
	[Uncompressed Backup Size (MB)] [bigint] NULL,
	[Compressed Backup Size (MB)] [bigint] NULL,
	[Compression Ratio] [numeric](20, 2) NULL
CONSTRAINT [PK_RecentDiffBackupsGlennQuery62] PRIMARY KEY CLUSTERED 
(
    [ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
) ON [PRIMARY]
END
GO

IF NOT EXISTS(SELECT * FROM sys.indexes WHERE name = ''IX_RecentDiffBackupsGlennQuery62_Datestamp'' 
	AND object_id = OBJECT_ID(''RecentDiffBackupsGlennQuery62''))
    BEGIN
        CREATE INDEX IX_RecentDiffBackupsGlennQuery62_Datestamp on RecentDiffBackupsGlennQuery62 (Datestamp DESC)
    END

----------

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[RecentFullBackupsGlennQuery62]'') AND type in (N''U''))
BEGIN
CREATE TABLE [dbo].[RecentFullBackupsGlennQuery62](
   [ID] [int] IDENTITY(1,1) NOT NULL,
	[Datestamp] [datetime] NOT NULL,
	[machine_name] [nvarchar](128) NULL,
	[server_name] [nvarchar](128) NULL,
	[Database Name] [nvarchar](128) NULL,
	[recovery_model] [nvarchar](60) NULL,
	[Backup Elapsed Time (sec)] [int] NULL,
	[Backup Finish Date] [datetime] NULL,
	[Uncompressed Backup Size (MB)] [bigint] NULL,
	[Compressed Backup Size (MB)] [bigint] NULL,
	[Compression Ratio] [numeric](20, 2) NULL
CONSTRAINT [PK_RecentFullBackupsGlennQuery62] PRIMARY KEY CLUSTERED 
(
    [ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
) ON [PRIMARY]
END
GO

IF NOT EXISTS(SELECT * FROM sys.indexes WHERE name = ''IX_RecentFullBackupsGlennQuery62_Datestamp'' 
	AND object_id = OBJECT_ID(''RecentFullBackupsGlennQuery62''))
    BEGIN
        CREATE INDEX IX_RecentFullBackupsGlennQuery62_Datestamp on RecentFullBackupsGlennQuery62 (Datestamp DESC)
    END

----------

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[RecentLogBackupsGlennQuery62]'') AND type in (N''U''))
BEGIN
CREATE TABLE [dbo].[RecentLogBackupsGlennQuery62](
   [ID] [int] IDENTITY(1,1) NOT NULL,
	[Datestamp] [datetime] NOT NULL,
	[machine_name] [nvarchar](128) NULL,
	[server_name] [nvarchar](128) NULL,
	[Database Name] [nvarchar](128) NULL,
	[recovery_model] [nvarchar](60) NULL,
	[Backup Elapsed Time (sec)] [int] NULL,
	[Backup Finish Date] [datetime] NULL,
	[Uncompressed Backup Size (MB)] [bigint] NULL,
	[Compressed Backup Size (MB)] [bigint] NULL,
	[Compression Ratio] [numeric](20, 2) NULL
CONSTRAINT [PK_RecentLogBackupsGlennQuery62] PRIMARY KEY CLUSTERED 
(
    [ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
) ON [PRIMARY]
END
GO

IF NOT EXISTS(SELECT * FROM sys.indexes WHERE name = ''IX_RecentLogBackupsGlennQuery62_Datestamp'' 
	AND object_id = OBJECT_ID(''RecentLogBackupsGlennQuery62''))
    BEGIN
        CREATE INDEX IX_RecentLogBackupsGlennQuery62_Datestamp on RecentLogBackupsGlennQuery62 (Datestamp DESC)
    END

----------

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[SignalWaitsGlennQuery31]'') AND type in (N''U''))
BEGIN
CREATE TABLE [dbo].[SignalWaitsGlennQuery31](
   [ID] [int] IDENTITY(1,1) NOT NULL,
	[DateStamp] [datetime] NOT NULL,
	[% Signal (CPU) Waits] [numeric](20, 2) NULL,
	[% Resource Waits] [numeric](20, 2) NULL
CONSTRAINT [PK_SignalWaitsGlennQuery31] PRIMARY KEY CLUSTERED 
(
    [ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
) ON [PRIMARY]
END
GO

IF NOT EXISTS(SELECT * FROM sys.indexes WHERE name = ''IX_SignalWaitsGlennQuery31_Datestamp'' 
	AND object_id = OBJECT_ID(''SignalWaitsGlennQuery31''))
    BEGIN
        CREATE INDEX IX_SignalWaitsGlennQuery31_Datestamp on SignalWaitsGlennQuery31 (Datestamp DESC)
    END

----------

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[SystemMemoryGlennQuery35]'') AND type in (N''U''))
BEGIN
CREATE TABLE [dbo].[SystemMemoryGlennQuery35](
   [ID] [int] IDENTITY(1,1) NOT NULL,
	[DateStamp] [datetime] NOT NULL,
	[Physical Memory (MB)] [bigint] NULL,
	[Available Memory (MB)] [bigint] NULL,
	[Total Page File (MB)] [bigint] NULL,
	[Available Page File (MB)] [bigint] NULL,
	[System Cache (MB)] [bigint] NULL,
	[System Memory State] [nvarchar](256) NOT NULL
CONSTRAINT [PK_SystemMemoryGlennQuery35] PRIMARY KEY CLUSTERED 
(
    [ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
) ON [PRIMARY]
END
GO

IF NOT EXISTS(SELECT * FROM sys.indexes WHERE name = ''IX_SystemMemoryGlennQuery35_Datestamp'' 
	AND object_id = OBJECT_ID(''SystemMemoryGlennQuery35''))
    BEGIN
        CREATE INDEX IX_SystemMemoryGlennQuery35_Datestamp on SystemMemoryGlennQuery35 (Datestamp DESC)
    END

----------

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[TopWaitsGlennQuery30]'') AND type in (N''U''))
BEGIN
CREATE TABLE [dbo].[TopWaitsGlennQuery30](
   [ID] [int] IDENTITY(1,1) NOT NULL,
	[DateStamp] [datetime] NOT NULL,
	[wait_type] [nvarchar](60) NOT NULL,
	[wait_time_s] [decimal](12, 2) NULL,
	[pct] [decimal](12, 2) NULL,
	[running_pct] [decimal](38, 2) NULL
CONSTRAINT [PK_TopWaitsGlennQuery30] PRIMARY KEY CLUSTERED 
(
    [ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
) ON [PRIMARY]
END
GO

IF NOT EXISTS(SELECT * FROM sys.indexes WHERE name = ''IX_TopWaitsGlennQuery30_Datestamp'' 
	AND object_id = OBJECT_ID(''TopWaitsGlennQuery30''))
    BEGIN
        CREATE INDEX IX_TopWaitsGlennQuery30_Datestamp on TopWaitsGlennQuery30 (Datestamp DESC)
    END

----------

/*
Actual Data Gathering - pulls DMV data and purges data older than one month
*/

USE master
go

INSERT into Ntirety.dbo.LUNVolumeInfoGlennQuery21
-- Volume info for all LUNS that have database files on the current instance (SQL Server 2008 R2 SP1 or greater)  (Query 21) (Volume Info)
SELECT DISTINCT GETDATE() as DateStamp, vs.volume_mount_point, 
vs.file_system_type, 
vs.logical_volume_name, CONVERT(DECIMAL(18,2),vs.total_bytes/1073741824.0) 
AS [Total Size (GB)],
CONVERT(DECIMAL(18,2),vs.available_bytes/1073741824.0) 
AS [Available Size (GB)],  
CAST(CAST(vs.available_bytes AS FLOAT)/ CAST(vs.total_bytes AS FLOAT) 
AS DECIMAL(18,2)) * 100 AS [Space Free %] 
FROM sys.master_files AS f WITH (NOLOCK)
CROSS APPLY sys.dm_os_volume_stats(f.database_id, f.[file_id]) AS vs 
OPTION (RECOMPILE);

DELETE from Ntirety.dbo.LUNVolumeInfoGlennQuery21
WHERE DATESTAMP < DATEADD(month,-1,GETDATE());

/*
SELECT * from  Ntirety.dbo.LUNVolumeInfoGlennQuery21
order by volume_mount_point, DateStamp desc
*/

----------

-- Get CPU utilization by database (Query 27) (CPU Usage by Database)

WITH DB_CPU_Stats
AS
(SELECT DatabaseID, DB_Name(DatabaseID) AS [Database Name], SUM(total_worker_time) AS [CPU_Time_Ms]
 FROM sys.dm_exec_query_stats AS qs
 CROSS APPLY (SELECT CONVERT(int, value) AS [DatabaseID] 
              FROM sys.dm_exec_plan_attributes(qs.plan_handle)
              WHERE attribute = N''dbid'') AS F_DB
 GROUP BY DatabaseID)
INSERT INTO Ntirety.dbo.CPUByDatabaseGlennQuery27
SELECT GETDATE() as DateStamp, ROW_NUMBER() OVER(ORDER BY [CPU_Time_Ms] DESC) AS [CPU Rank],
       [Database Name], [CPU_Time_Ms] AS [CPU Time (ms)], 
       CAST([CPU_Time_Ms] * 1.0 / SUM([CPU_Time_Ms]) OVER() * 100.0 AS DECIMAL(5, 2)) AS [CPU Percent]
FROM DB_CPU_Stats
WHERE DatabaseID <> 32767 -- ResourceDB
ORDER BY [CPU Rank] OPTION (RECOMPILE);

DELETE from Ntirety.dbo.CPUByDatabaseGlennQuery27
WHERE DATESTAMP < DATEADD(month,-1,GETDATE());

/*
SELECT *
from  Ntirety.dbo.CPUByDatabaseGlennQuery27
ORDER by DateStamp DESC, [CPU Rank]
*/

----------

-- Get I/O utilization by database (Query 28) (IO Usage By Database)
WITH Aggregate_IO_Statistics
AS
(SELECT DB_NAME(database_id) AS [Database Name],
CAST(SUM(num_of_bytes_read + num_of_bytes_written)/1048576 AS DECIMAL(12, 2)) AS io_in_mb
FROM sys.dm_io_virtual_file_stats(NULL, NULL) AS [DM_IO_STATS]
GROUP BY database_id)
INSERT INTO Ntirety.dbo.IOByDatabaseGlennQuery28
SELECT GETDATE() as DateStamp,ROW_NUMBER() OVER(ORDER BY io_in_mb DESC) AS [I/O Rank], [Database Name], io_in_mb AS [Total I/O (MB)],
       CAST(io_in_mb/ SUM(io_in_mb) OVER() * 100.0 AS DECIMAL(5,2)) AS [I/O Percent]
FROM Aggregate_IO_Statistics
ORDER BY [I/O Rank] OPTION (RECOMPILE);

DELETE from Ntirety.dbo.IOByDatabaseGlennQuery28
WHERE DATESTAMP < DATEADD(month,-1,GETDATE());

/*
SELECT *
from  Ntirety.dbo.IOByDatabaseGlennQuery28
ORDER by DateStamp DESC, [I/O Rank]
*/

----------

-- Get total buffer usage by database for current instance  (Query 29) (Total Buffer Usage by Database)
WITH AggregateBufferPoolUsage
AS
(SELECT DB_NAME(database_id) AS [Database Name],
CAST(COUNT(*) * 8/1024.0 AS DECIMAL (10,2))  AS [CachedSize]
FROM sys.dm_os_buffer_descriptors WITH (NOLOCK)
WHERE database_id > 4 -- system databases
AND database_id <> 32767 -- ResourceDB
GROUP BY DB_NAME(database_id))
INSERT INTO  Ntirety.dbo.BufferPoolByDatabaseGlennQuery29
SELECT GETDATE() as DateStamp, ROW_NUMBER() OVER(ORDER BY CachedSize DESC) AS [Buffer Pool Rank], [Database Name], CachedSize AS [Cached Size (MB)],
       CAST(CachedSize / SUM(CachedSize) OVER() * 100.0 AS DECIMAL(5,2)) AS [Buffer Pool Percent]
FROM AggregateBufferPoolUsage
ORDER BY [Buffer Pool Rank] OPTION (RECOMPILE);

DELETE from Ntirety.dbo.BufferPoolByDatabaseGlennQuery29
WHERE DATESTAMP < DATEADD(month,-1,GETDATE());

/*
SELECT *
from  Ntirety.dbo.BufferPoolByDatabaseGlennQuery29
ORDER by DateStamp DESC, [Buffer Pool Rank]
*/

----------

-- Isolate top waits for server instance since last restart or statistics clear  (Query 30) (Top Waits)
-- New SQL Server 2012 specific version
-- SLEEP_DBSTARTUP, DIRTY_PAGE_POLL, HADR_FILESTREAM_IOMGR_IOCOMPLETION and 
-- SP_SERVER_DIAGNOSTICS_SLEEP are new for SQL Server 2012

WITH Waits AS
(SELECT wait_type, wait_time_ms / 1000. AS wait_time_s,
100. * wait_time_ms / SUM(wait_time_ms) OVER() AS pct,
ROW_NUMBER() OVER(ORDER BY wait_time_ms DESC) AS rn
FROM sys.dm_os_wait_stats WITH (NOLOCK)
WHERE wait_type NOT IN (N''CLR_SEMAPHORE'',N''LAZYWRITER_SLEEP'',N''RESOURCE_QUEUE'',N''SLEEP_TASK'',
N''SLEEP_SYSTEMTASK'',N''SQLTRACE_BUFFER_FLUSH'',N''WAITFOR'', N''LOGMGR_QUEUE'',N''CHECKPOINT_QUEUE'',
N''REQUEST_FOR_DEADLOCK_SEARCH'',N''XE_TIMER_EVENT'',N''BROKER_TO_FLUSH'',N''BROKER_TASK_STOP'',N''CLR_MANUAL_EVENT'',
N''CLR_AUTO_EVENT'',N''DISPATCHER_QUEUE_SEMAPHORE'', N''FT_IFTS_SCHEDULER_IDLE_WAIT'',
N''XE_DISPATCHER_WAIT'', N''XE_DISPATCHER_JOIN'', N''SQLTRACE_INCREMENTAL_FLUSH_SLEEP'',
N''ONDEMAND_TASK_QUEUE'', N''BROKER_EVENTHANDLER'', N''SLEEP_BPOOL_FLUSH''))
INSERT INTO  Ntirety.dbo.TopWaitsGlennQuery30
SELECT GETDATE() as DateStamp, W1.wait_type, 
CAST(W1.wait_time_s AS DECIMAL(12, 2)) AS wait_time_s,
CAST(W1.pct AS DECIMAL(12, 2)) AS pct,
CAST(SUM(W2.pct) AS DECIMAL(12, 2)) AS running_pct
FROM Waits AS W1
INNER JOIN Waits AS W2
ON W2.rn <= W1.rn
GROUP BY W1.rn, W1.wait_type, W1.wait_time_s, W1.pct
HAVING SUM(W2.pct) - W1.pct < 99 OPTION (RECOMPILE);

DELETE from Ntirety.dbo.TopWaitsGlennQuery30
WHERE DATESTAMP < DATEADD(month,-1,GETDATE());

/*
SELECT *
from  Ntirety.dbo.TopWaitsGlennQuery30
ORDER by DateStamp DESC, pct DESC
*/

----------

-- Signal Waits for instance  (Query 31) (Signal Waits)
INSERT INTO  Ntirety.dbo.SignalWaitsGlennQuery31
SELECT GetDate() as DateStamp, CAST(100.0 * SUM(signal_wait_time_ms) / SUM (wait_time_ms) AS NUMERIC(20,2)) 
AS [% Signal (CPU) Waits],
CAST(100.0 * SUM(wait_time_ms - signal_wait_time_ms) / SUM (wait_time_ms) AS NUMERIC(20,2)) 
AS [% Resource Waits]
FROM sys.dm_os_wait_stats WITH (NOLOCK) OPTION (RECOMPILE);

-- Signal Waits above 15-20% is usually a sign of CPU pressure
-- Resource waits are non-CPU related waits

DELETE from Ntirety.dbo.SignalWaitsGlennQuery31
WHERE DATESTAMP < DATEADD(month,-1,GETDATE());

/*
SELECT *
from  Ntirety.dbo.SignalWaitsGlennQuery31
ORDER by DateStamp DESC
*/

----------

-- Good basic information about OS memory amounts and state  (Query 35) (System Memory)
INSERT INTO  Ntirety.dbo.SystemMemoryGlennQuery35
SELECT GETDATE() as DateStamp, total_physical_memory_kb/1024 AS [Physical Memory (MB)], 
       available_physical_memory_kb/1024 AS [Available Memory (MB)], 
       total_page_file_kb/1024 AS [Total Page File (MB)], 
	   available_page_file_kb/1024 AS [Available Page File (MB)], 
	   system_cache_kb/1024 AS [System Cache (MB)],
       system_memory_state_desc AS [System Memory State]
FROM sys.dm_os_sys_memory WITH (NOLOCK) OPTION (RECOMPILE);

DELETE from Ntirety.dbo.SystemMemoryGlennQuery35
WHERE DATESTAMP < DATEADD(month,-1,GETDATE());

/*
SELECT *
from  Ntirety.dbo.SystemMemoryGlennQuery35
ORDER by DateStamp DESC
*/

---------

-- Page Life Expectancy (PLE) value for each NUMA node in current instance  (Query 37) (PLE by NUMA Node)
INSERT INTO Ntirety.dbo.PLEGlennQuery37
SELECT GETDATE() as Datestamp, @@SERVERNAME AS [Server Name], 
[object_name], instance_name, cntr_value AS [Page Life Expectancy]
FROM sys.dm_os_performance_counters WITH (NOLOCK)
WHERE [object_name] LIKE N''%Buffer Node%'' -- Handles named instances
AND counter_name = N''Page life expectancy'' OPTION (RECOMPILE);

-- PLE is a good measurement of memory pressure.
-- Higher PLE is better. Watch the trend, not the absolute value.
-- This will only return one row for non-NUMA systems.

DELETE from Ntirety.dbo.PLEGlennQuery37
WHERE DATESTAMP < DATEADD(month,-1,GETDATE());

/*
SELECT *
from  Ntirety.dbo.PLEGlennQuery37
ORDER by DateStamp DESC, instance_name DESC
*/

---------

-- Find single-use, ad-hoc and prepared queries that are bloating the plan cache  (Query 40) (Ad hoc Queries)
INSERT into Ntirety.dbo.AdhocPlanCacheGlennQuery40
SELECT TOP(50) GETDATE() as Datestamp, [text] AS [QueryText], cp.cacheobjtype, cp.objtype, cp.size_in_bytes 
FROM sys.dm_exec_cached_plans AS cp WITH (NOLOCK)
CROSS APPLY sys.dm_exec_sql_text(plan_handle) 
WHERE cp.cacheobjtype = N''Compiled Plan'' 
AND cp.objtype IN (N''Adhoc'', N''Prepared'') 
AND cp.usecounts = 1
ORDER BY cp.size_in_bytes DESC OPTION (RECOMPILE);

DELETE from Ntirety.dbo.AdhocPlanCacheGlennQuery40
WHERE DATESTAMP < DATEADD(month,-1,GETDATE());

/*
SELECT *
from  Ntirety.dbo.AdhocPlanCacheGlennQuery40
ORDER by DateStamp DESC, size_in_bytes DESC
*/

----------

-- I/O Statistics by file for the current database  (Query 42) (IO Stats By File)
EXEC sp_msforeachdb 
''use [?];INSERT INTO Ntirety.dbo.IOByFileGlennQuery42 
SELECT GETDATE() as Datestamp,''''?'''' AS [Database Name], 
df.name AS [Logical Name], vfs.[file_id], 
df.physical_name AS [Physical Name], vfs.num_of_reads, 
vfs.num_of_writes, vfs.io_stall_read_ms, vfs.io_stall_write_ms,
CAST(100. * vfs.io_stall_read_ms/(vfs.io_stall_read_ms + vfs.io_stall_write_ms) AS DECIMAL(10,1)) AS [IO Stall Reads Pct],
CAST(100. * vfs.io_stall_write_ms/(vfs.io_stall_write_ms + vfs.io_stall_read_ms) AS DECIMAL(10,1)) AS [IO Stall Writes Pct],
(vfs.num_of_reads + vfs.num_of_writes) AS [Writes + Reads], 
CAST(vfs.num_of_bytes_read/1048576.0 AS DECIMAL(10, 2)) AS [MB Read], 
CAST(vfs.num_of_bytes_written/1048576.0 AS DECIMAL(10, 2)) AS [MB Written],
CAST(100. * vfs.num_of_reads/(vfs.num_of_reads + vfs.num_of_writes) AS DECIMAL(10,1)) AS [# Reads Pct],
CAST(100. * vfs.num_of_writes/(vfs.num_of_reads + vfs.num_of_writes) AS DECIMAL(10,1)) AS [# Write Pct],
CAST(100. * vfs.num_of_bytes_read/(vfs.num_of_bytes_read + vfs.num_of_bytes_written) AS DECIMAL(10,1)) AS [Read Bytes Pct],
CAST(100. * vfs.num_of_bytes_written/(vfs.num_of_bytes_read + vfs.num_of_bytes_written) AS DECIMAL(10,1)) AS [Written Bytes Pct]
FROM sys.dm_io_virtual_file_stats(NULL, NULL) AS vfs
INNER JOIN sys.database_files AS df WITH (NOLOCK)
ON vfs.[file_id]= df.[file_id]
where Database_ID=DB_ID()
OPTION (RECOMPILE)'';

DELETE from Ntirety.dbo.IOByFileGlennQuery42
WHERE DATESTAMP < DATEADD(month,-1,GETDATE());

/*
SELECT *
from  Ntirety.dbo.IOByFileGlennQuery42
ORDER by num_of_reads DESC, Datestamp desc
*/

----------

-- I/O Statistics by file for the current database  (Query 42) (IO Stats By File)
EXEC sp_msforeachdb
/*sp_executesql used to bypass syntax error 
from low compatibility level DBs
AndyG 07/21/2014*/
''use [?]; IF (select compatibility_level from master.sys.databases 
where name = ''''?'''')>90
EXEC sp_executesql  N''''
INSERT INTO Ntirety.dbo.IOBySPGlennQuery51 SELECT TOP(50) GETDATE() as Datestamp, ''''''''?'''''''' as DatabaseName, OBJECT_NAME(qt.objectid, dbid) AS [SP Name],
(qs.total_logical_reads + qs.total_logical_writes) /qs.execution_count AS [Avg IO], qs.execution_count AS [Execution Count],
SUBSTRING(qt.[text],qs.statement_start_offset/2, 
	(CASE 
		WHEN qs.statement_end_offset = -1 
	 THEN LEN(CONVERT(nvarchar(max), qt.[text])) * 2 
		ELSE qs.statement_end_offset 
	 END - qs.statement_start_offset)/2) AS [Query Text]
FROM sys.dm_exec_query_stats AS qs WITH (NOLOCK)
CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle) AS qt
WHERE qt.[dbid] = DB_ID()
ORDER BY [Avg IO] DESC OPTION (RECOMPILE)'''''';

DELETE from Ntirety.dbo.IOBySPGlennQuery51
WHERE DATESTAMP < DATEADD(month,-1,GETDATE());

/*
SELECT *
from  Ntirety.dbo.IOBySPGlennQuery51
ORDER by [Avg IO] DESC, Datestamp desc
*/

----------

--- Index Read/Write stats (all tables in current DB) ordered by Reads  (Query 60) (Overall Index Usage - Reads)
EXEC sp_msforeachdb
''use [?]; INSERT INTO Ntirety.dbo.IndexReadWritesGlennQuery60
SELECT GETDATE() as Datestamp, ''''?'''' as DatabaseName, OBJECT_NAME(s.[object_id]) AS [ObjectName], i.name AS [IndexName], i.index_id,
	   user_seeks + user_scans + user_lookups AS [Reads], s.user_updates AS [Writes],  
	   i.type_desc AS [IndexType], i.fill_factor AS [FillFactor], i.has_filter, i.filter_definition, 
	   s.last_user_scan, s.last_user_lookup, s.last_user_seek
FROM sys.dm_db_index_usage_stats AS s WITH (NOLOCK) 
INNER JOIN sys.indexes AS i WITH (NOLOCK)
ON s.[object_id] = i.[object_id]
WHERE OBJECTPROPERTY(s.[object_id],''''IsUserTable'''') = 1
AND i.index_id = s.index_id
AND s.database_id = DB_ID()
'';

-- Show which indexes in the current database are most active for Reads

DELETE from Ntirety.dbo.IndexReadWritesGlennQuery60
WHERE DATESTAMP < DATEADD(month,-1,GETDATE());

/*
SELECT *
from  Ntirety.dbo.IndexReadWritesGlennQuery60
where DB_ID(DatabaseName)>4
ORDER by Reads DESC, Datestamp desc
*/

-----------

-- Look at recent Full backups for the current database (Query 62) (Recent Full Backups)

EXEC sp_msforeachdb
''use [?]; INSERT INTO Ntirety.dbo.RecentFullBackupsGlennQuery62
SELECT TOP (30) GETDATE() as Datestamp, bs.machine_name, bs.server_name, bs.database_name AS [Database Name], bs.recovery_model, 
DATEDIFF (SECOND, bs.backup_start_date, bs.backup_finish_date) AS [Backup Elapsed Time (sec)],
bs.backup_finish_date AS [Backup Finish Date],
CONVERT (BIGINT, bs.backup_size / 1048576 ) AS [Uncompressed Backup Size (MB)],
CONVERT (BIGINT, bs.compressed_backup_size / 1048576 ) AS [Compressed Backup Size (MB)],
CONVERT (NUMERIC (20,2), (CONVERT (FLOAT, bs.backup_size) /
CONVERT (FLOAT, bs.compressed_backup_size))) AS [Compression Ratio]
FROM msdb.dbo.backupset AS bs WITH (NOLOCK)
WHERE DATEDIFF (SECOND, bs.backup_start_date, bs.backup_finish_date) > 0 
AND bs.backup_size > 0
AND bs.type = ''''D'''' 
AND database_name = DB_NAME(DB_ID())
ORDER BY bs.backup_finish_date DESC OPTION (RECOMPILE)
'';		

-- Are your backup sizes and times changing over time?

DELETE from Ntirety.dbo.RecentFullBackupsGlennQuery62
WHERE DATESTAMP < DATEADD(month,-1,GETDATE());

/*
SELECT server_name, [Database Name], MAX([Backup Finish Date]) as LastBackupDate
from  Ntirety.dbo.RecentFullBackupsGlennQuery62
GROUP BY server_name, [Database Name]
ORDER by [Database Name]
*/

-- Look at recent Diff backups for the current database (Query 62) (Recent Full Backups)

EXEC sp_msforeachdb
''use [?]; INSERT INTO Ntirety.dbo.RecentDiffBackupsGlennQuery62
SELECT TOP (30) GETDATE() as Datestamp, bs.machine_name, bs.server_name, bs.database_name AS [Database Name], bs.recovery_model, 
DATEDIFF (SECOND, bs.backup_start_date, bs.backup_finish_date) AS [Backup Elapsed Time (sec)],
bs.backup_finish_date AS [Backup Finish Date],
CONVERT (BIGINT, bs.backup_size / 1048576 ) AS [Uncompressed Backup Size (MB)],
CONVERT (BIGINT, bs.compressed_backup_size / 1048576 ) AS [Compressed Backup Size (MB)],
CONVERT (NUMERIC (20,2), (CONVERT (FLOAT, bs.backup_size) /
CONVERT (FLOAT, bs.compressed_backup_size))) AS [Compression Ratio]
FROM msdb.dbo.backupset AS bs WITH (NOLOCK)
WHERE DATEDIFF (SECOND, bs.backup_start_date, bs.backup_finish_date) > 0 
AND bs.backup_size > 0
AND bs.type = ''''I'''' 
AND database_name = DB_NAME(DB_ID())
ORDER BY bs.backup_finish_date DESC OPTION (RECOMPILE)
'';		

-- Are your backup sizes and times changing over time?

DELETE from Ntirety.dbo.RecentDiffBackupsGlennQuery62
WHERE DATESTAMP < DATEADD(month,-1,GETDATE());

/*
SELECT server_name, [Database Name], MAX([Backup Finish Date]) as LastBackupDate
from  Ntirety.dbo.RecentDiffBackupsGlennQuery62
GROUP BY server_name, [Database Name]
ORDER by [Database Name]
*/

-- Look at recent Log backups for the current database (Query 62) (Recent Full Backups)

EXEC sp_msforeachdb
''use [?]; INSERT INTO Ntirety.dbo.RecentLogBackupsGlennQuery62
SELECT TOP (30) GETDATE() as Datestamp, bs.machine_name, bs.server_name, bs.database_name AS [Database Name], bs.recovery_model, 
DATEDIFF (SECOND, bs.backup_start_date, bs.backup_finish_date) AS [Backup Elapsed Time (sec)],
bs.backup_finish_date AS [Backup Finish Date],
CONVERT (BIGINT, bs.backup_size / 1048576 ) AS [Uncompressed Backup Size (MB)],
CONVERT (BIGINT, bs.compressed_backup_size / 1048576 ) AS [Compressed Backup Size (MB)],
CONVERT (NUMERIC (20,2), (CONVERT (FLOAT, bs.backup_size) /
CONVERT (FLOAT, bs.compressed_backup_size))) AS [Compression Ratio]
FROM msdb.dbo.backupset AS bs WITH (NOLOCK)
WHERE DATEDIFF (SECOND, bs.backup_start_date, bs.backup_finish_date) > 0 
AND bs.backup_size > 0
AND bs.type = ''''L'''' 
AND database_name = DB_NAME(DB_ID())
ORDER BY bs.backup_finish_date DESC OPTION (RECOMPILE)
'';		

-- Are your backup sizes and times changing over time?

DELETE from Ntirety.dbo.RecentLogBackupsGlennQuery62
WHERE DATESTAMP < DATEADD(month,-1,GETDATE());

/*
SELECT server_name, [Database Name], MAX([Backup Finish Date]) as LastBackupDate
from  Ntirety.dbo.RecentLogBackupsGlennQuery62
GROUP BY server_name, [Database Name]
ORDER by [Database Name]
*/




', 
		@database_name=N'master', 
		@output_file_name=N'C:\Ntirety\JobOut\Ntirety-DMVDataGather_$(ESCAPE_SQUOTE(STRTDT))_$(ESCAPE_SQUOTE(STRTTM)).txt', 
		@flags=4
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Every Ten Minutes', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=4, 
		@freq_subday_interval=10, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20140721, 
		@active_end_date=99991231, 
		@active_start_time=500, 
		@active_end_time=235959, 
		@schedule_uid=N'39408638-7b87-4031-a419-7aedb2ee7f56'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

