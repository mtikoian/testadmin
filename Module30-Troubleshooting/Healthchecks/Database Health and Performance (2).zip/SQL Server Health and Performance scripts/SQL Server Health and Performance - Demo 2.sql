/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
SQL Saturday 
Database Health and Performance Demonstrations

Demo 2 - Query Performance

* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
--Check Query Performance with Statistics IO / Time
use DS2
go

--generate random string so you know I'm not cheating!
declare @alphabet varchar(26) = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
declare @var char(2)

set @var = ( select substring(@alphabet, convert(int, rand()*26), 1) + 
		substring(@alphabet, convert(int, rand()*26), 1) )
print 'Your two-letter randomly generated string is: ' + @var

declare @sql varchar(max)
set @sql = '
SELECT TOP 5
	C.*, ch.ORDERID
FROM
	dbo.CUSTOMERS c
	JOIN dbo.CUST_HIST ch ON c.CUSTOMERID = ch.CUSTOMERID
	JOIN dbo.ORDERS o ON o.ORDERID = ch.ORDERID
	JOIN dbo.ORDERLINES ol ON ol.ORDERID = ch.ORDERID
WHERE
	c.LASTNAME like (''' + @var + '%'')'

print @sql --so we see what is generated

set statistics io on
set statistics time on
exec (@sql)
set statistics time off
set statistics io off
-----------------------------------------------------------------------------------------------
