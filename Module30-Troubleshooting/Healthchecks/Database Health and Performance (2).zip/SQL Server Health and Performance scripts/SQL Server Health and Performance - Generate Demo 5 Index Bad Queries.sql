select * from dummydb.dbo.randomtable
order by stuff asc

select * from dummydb.dbo.randomtable
where stuff like 'AA%'
order by stuff asc


select * from dummydb.dbo.randomtable
where stuff like 'BB%'
order by stuff asc

select * from dummydb.dbo.randomtable
where stuff like 'DA%'
order by stuff asc