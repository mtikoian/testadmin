
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
SQL Saturday 
Database Health and Performance Demonstrations

Indexes - Demonstrate missing indexes

* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
use ds2;
go

set statistics io on
set statistics time on
go
select
	*
from
	dbo.Customers c
	left join dbo.Orders o on o.CustomerID = c.CustomerID
	left join dbo.OrderLines l on l.OrderID = o.OrderID
where
	c.FirstName = 'IVBZNU'
set statistics io off
set statistics time off
go
--Select query and hit Control-L to show estimated execution plan


/* Record stats:
     Logical Reads (approx):
	 Total execution time:
*/

--Look for bad or missing indexes.
--Run the fix index script!

--Let's do this again.
set statistics io on
set statistics time on
go
select
	*
from
	dbo.Customers c
	left join dbo.Orders o on o.CustomerID = c.CustomerID
	left join dbo.OrderLines l on l.OrderID = o.OrderID
where
	--c.FirstName = 'IVBZNU'
	c.LastName = 'QNQVGUGRTZ'
set statistics io off
set statistics time off
go