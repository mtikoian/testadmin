
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
SQL Saturday 
Database Health and Performance Demonstrations

Demo 3 - CPU

* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
-- http://sqlserverperformance.wordpress.com/
-- Signal Waits for instance  (Query 24)
SELECT CAST(100.0 * SUM(signal_wait_time_ms) / SUM (wait_time_ms) AS NUMERIC(20,2)) 
AS [%signal (cpu) waits],
CAST(100.0 * SUM(wait_time_ms - signal_wait_time_ms) / SUM (wait_time_ms) AS NUMERIC(20,2)) 
AS [%resource waits]
FROM sys.dm_os_wait_stats WITH (NOLOCK) OPTION (RECOMPILE);

-----------------------------------------------------------------------------------------------
--plan re-use
--http://androidspeak.wordpress.com/2009/06/10/sql-server-2005-calculating-plan-re-use/
SELECT  CONVERT(varchar, CONVERT(numeric(10,1), (BR.[cntr_value] - SC.[cntr_value])
        / CONVERT(numeric(15,3), BR.[cntr_value]) * 100)) + '%' AS 'Plan re-use'
FROM    sys.dm_os_performance_counters BR
CROSS JOIN  sys.dm_os_performance_counters SC
WHERE   BR.[object_name] LIKE '%SQL Statistics%'
AND     BR.[counter_name] = 'Batch Requests/sec'
AND     SC.[object_name] LIKE '%SQL Statistics%'
AND     SC.[counter_name] = 'SQL Compilations/sec'
GO
--SHOULD be at least 90%
-----------------------------------------------------------------------------------------------
-- Isolate top waits for server instance since last restart or statistics clear  (Query 23)
-- http://sqlserverperformance.wordpress.com/
WITH Waits AS
(SELECT wait_type, wait_time_ms / 1000. AS wait_time_s,
100. * wait_time_ms / SUM(wait_time_ms) OVER() AS pct,
ROW_NUMBER() OVER(ORDER BY wait_time_ms DESC) AS rn
FROM sys.dm_os_wait_stats WITH (NOLOCK)
WHERE wait_type NOT IN (N'CLR_SEMAPHORE',N'LAZYWRITER_SLEEP',N'RESOURCE_QUEUE',
N'SLEEP_TASK',N'SLEEP_SYSTEMTASK',N'SQLTRACE_BUFFER_FLUSH',N'WAITFOR', 
N'LOGMGR_QUEUE',N'CHECKPOINT_QUEUE', N'REQUEST_FOR_DEADLOCK_SEARCH',
N'XE_TIMER_EVENT',N'BROKER_TO_FLUSH',N'BROKER_TASK_STOP',N'CLR_MANUAL_EVENT',
N'CLR_AUTO_EVENT',N'DISPATCHER_QUEUE_SEMAPHORE', N'FT_IFTS_SCHEDULER_IDLE_WAIT',
N'XE_DISPATCHER_WAIT', N'XE_DISPATCHER_JOIN', N'SQLTRACE_INCREMENTAL_FLUSH_SLEEP',
N'ONDEMAND_TASK_QUEUE', N'BROKER_EVENTHANDLER', N'SLEEP_BPOOL_FLUSH',
N'DIRTY_PAGE_POLL', N'HADR_FILESTREAM_IOMGR_IOCOMPLETION', N'SP_SERVER_DIAGNOSTICS_SLEEP'))
SELECT W1.wait_type, 
CAST(W1.wait_time_s AS DECIMAL(12, 2)) AS wait_time_s,
CAST(W1.pct AS DECIMAL(12, 2)) AS pct,
CAST(SUM(W2.pct) AS DECIMAL(12, 2)) AS running_pct
FROM Waits AS W1
INNER JOIN Waits AS W2
ON W2.rn <= W1.rn
GROUP BY W1.rn, W1.wait_type, W1.wait_time_s, W1.pct
HAVING SUM(W2.pct) - W1.pct < 99 OPTION (RECOMPILE); -- percentage threshold
------------------------------------------------------------------------------------------------
--Check CPU bottlenecks - high worker queue
--Query Source: http://blog.sqlauthority.com/2009/08/17/sql-server-measure-cpu-pressure-cpu-business/

SELECT  scheduler_id,  cpu_id,  current_tasks_count, runnable_tasks_count,  current_workers_count,
active_workers_count, work_queue_count,  pending_disk_io_count
FROM sys.dm_os_schedulers
WHERE scheduler_id < 255; 


	