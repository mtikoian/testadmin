declare @alphabet varchar(26) = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
declare @var char(5)

set @var = ( select substring(@alphabet, convert(int, rand()*26), 1) + 
		substring(@alphabet, convert(int, rand()*26), 1) + 
		substring(@alphabet, convert(int, rand()*26), 1) + 
		substring(@alphabet, convert(int, rand()*26), 1) + 
		substring(@alphabet, convert(int, rand()*26), 1) )

insert into dummydb.dbo.randomtable 
(stuff, things, textcol1, datecol2) 
select @var, reverse(@var), getdate(), newid()

go 50000