
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
SQL Saturday 
Database Health and Performance Demonstrations

Demo 4 - Memory and Buffer

* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
--PLE
-- http://sqlserverperformance.wordpress.com/
-- Page Life Expectancy (PLE) value for current instance  (Query 30)
SELECT @@SERVERNAME AS [Server Name], [object_name], cntr_value AS [Page Life Expectancy]
FROM sys.dm_os_performance_counters WITH (NOLOCK)
WHERE [object_name] LIKE N'%Buffer Manager%' -- Handles named instances
AND counter_name = N'Page life expectancy' OPTION (RECOMPILE);

-----------------------------------------------------------------------------------------------
--buffer cache hit ratio
--http://www.sqlserver-dba.com/2011/06/sql-server-buffer-cache-hit-ratio-and-memory-pressure.html
SELECT ROUND(CAST(A.cntr_value1 AS NUMERIC) /
CAST(B.cntr_value2 AS NUMERIC),3) AS Buffer_Cache_Hit_Ratio
FROM ( SELECT cntr_value AS cntr_value1
FROM sys.dm_os_performance_counters
WHERE object_name = 'SQLServer:Buffer Manager' AND counter_name = 'Buffer cache hit ratio'
) AS A,
(SELECT cntr_value AS cntr_value2
FROM sys.dm_os_performance_counters
WHERE object_name = 'SQLServer:Buffer Manager' AND counter_name = 'Buffer cache hit ratio base'
) AS B;
-----------------------------------------------------------------------------------------------
--Returns Lazy writes per second 
SELECT cntr_value AS 'Lazy writes per second' 
FROM sys.dm_os_performance_counters 
WHERE object_name = 'SQLServer:Buffer Manager' 
AND counter_name = 'Lazy writes/sec'  

SELECT cntr_value AS 'Checkpoint pages per second' 
FROM sys.dm_os_performance_counters 
WHERE object_name = 'SQLServer:Buffer Manager' 
AND counter_name = 'Checkpoint pages/sec'  
-----------------------------------------------------------------------------------------------

------------------------------------------------------------------------------------------------
