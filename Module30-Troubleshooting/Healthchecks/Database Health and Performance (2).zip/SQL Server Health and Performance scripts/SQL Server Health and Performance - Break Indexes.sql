
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
SQL Saturday 
Database Health and Performance Demonstrations

Break My Indexes!

* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
use ds2;
go

DROP INDEX [IX_CUST_HIST_CUSTOMERID] ON [dbo].[CUST_HIST]
GO

DROP INDEX [IX_CUST_NAME] ON [dbo].[CUSTOMERS]
GO

DROP INDEX [IX_ORDER_CUSTID] ON [dbo].[ORDERS]
GO

DROP INDEX [IX_PROD_PRODID] ON [dbo].[PRODUCTS]
GO