/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
SQL Saturday
Database Health and Performance Demonstrations

Demo 1 - Instance Settings

* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

--Is snapshot isolation set? TEST this before you move to production!
--READ: http://msdn.microsoft.com/en-us/library/tcbchxcb(v=vs.110).aspx
ALTER DATABASE ds2
SET ALLOW_SNAPSHOT_ISOLATION ON
GO
ALTER DATABASE ds2
SET READ_COMMITTED_SNAPSHOT ON
GO

-----------------------------------------------------------------------------------------------
--Min/max memory settings?
--from Glenn Berry sqlserverperformance.wordpress.com SQL Server 2012 Diagnostic Queries

-- Hardware information from SQL Server 2012  (Query 7) 
-- (Cannot distinguish between HT and multi-core)
SELECT cpu_count AS [Logical CPU Count], hyperthread_ratio AS [Hyperthread Ratio],
cpu_count/hyperthread_ratio AS [Physical CPU Count], 
physical_memory_kb/1024 AS [Physical Memory (MB)], committed_target_kb/1024 AS [Committed Target Memory (MB)],
max_workers_count AS [Max Workers Count], affinity_type_desc AS [Affinity Type], 
sqlserver_start_time AS [SQL Server Start Time], virtual_machine_type_desc AS [Virtual Machine Type]
FROM sys.dm_os_sys_info WITH (NOLOCK) OPTION (RECOMPILE);
--column in question is Committed Target Memory (MB). Should be lower than 
--Physical Memory (MB) and should leave RAM for OS.

-----------------------------------------------------------------------------------------------
--Check for Optimize for Ad-hoc Queries
-- http://sqlserverperformance.wordpress.com/
-- Get configuration values for instance  (Query 13)
SELECT name, value, value_in_use, [description] 
FROM sys.configurations WITH (NOLOCK)
where name like '%for Ad Hoc%'
ORDER BY name OPTION (RECOMPILE);
--should be 1 if enabled.
-----------------------------------------------------------------------------------------------

--TEMPDB - should have more than one data file

-- http://sqlserverperformance.wordpress.com/
-- File Names and Paths for TempDB and all user databases in instance  (Query 16) 
SELECT DB_NAME([database_id])AS [Database Name], 
       [file_id], name, physical_name, type_desc, state_desc, 
       CONVERT( bigint, size/128.0) AS [Total Size in MB]
FROM sys.master_files WITH (NOLOCK)
WHERE DB_NAME([database_id]) = 'tempdb'
AND type_desc = 'ROWS'
ORDER BY DB_NAME([database_id]) OPTION (RECOMPILE);

-----------------------------------------------------------------------------------------------

--Check for high VLF counts

-- http://sqlserverperformance.wordpress.com/
-- Get VLF Counts for all databases on the instance (Query 19)
-- (adapted from Michelle Ufford) 
CREATE TABLE #VLFInfo (RecoveryUnitID int, FileID  int,
					   FileSize bigint, StartOffset bigint,
					   FSeqNo      bigint, [Status]    bigint,
					   Parity      bigint, CreateLSN   numeric(38));
	 
CREATE TABLE #VLFCountResults(DatabaseName sysname, VLFCount int);
	 
EXEC sp_MSforeachdb N'Use [?]; 

				INSERT INTO #VLFInfo 
				EXEC sp_executesql N''DBCC LOGINFO([?])''; 
	 
				INSERT INTO #VLFCountResults 
				SELECT DB_NAME(), COUNT(*) 
				FROM #VLFInfo; 

				TRUNCATE TABLE #VLFInfo;'
	 
SELECT DatabaseName, VLFCount  
FROM #VLFCountResults
ORDER BY VLFCount DESC;
	 
DROP TABLE #VLFInfo;
DROP TABLE #VLFCountResults;

-----------------------------------------------------------------------------------------------