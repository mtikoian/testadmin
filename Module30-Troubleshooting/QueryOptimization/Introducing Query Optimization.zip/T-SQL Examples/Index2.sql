

--DROP INDEX IX_SalesOrderDetail_CDBA1 ON [Sales].[SalesOrderDetail]
CREATE NONCLUSTERED INDEX IX_SalesOrderDetail_CDBA1 ON [Sales].[SalesOrderDetail]
	(UnitPrice, SalesOrderID, ProductID)
	INCLUDE (UnitPriceDiscount)
	WITH (PAD_INDEX=ON, FILLFACTOR=95, DATA_COMPRESSION=PAGE);
