



SELECT d.ProductID
	, d.UnitPrice
	, p.name
	, COUNT(h.SalesOrderID) AS Sales
FROM [Sales].[SalesOrderHeader] h
	INNER JOIN [Sales].[SalesOrderDetail] d ON h.SalesOrderID = d.SalesOrderDetailID
	LEFT JOIN [Production].[Product] p ON d.ProductID = p.ProductID
WHERE d.UnitPrice < 5
GROUP BY d.ProductID
	, d.UnitPrice
	, p.name
ORDER BY d.UnitPrice DESC;

