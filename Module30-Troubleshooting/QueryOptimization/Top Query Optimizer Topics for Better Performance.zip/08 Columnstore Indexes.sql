
USE AdventureWorksDW2012
GO

CREATE TABLE dbo.FactInternetSales_big (
	ProductKey int NOT NULL,
	OrderDateKey int NOT NULL,
	DueDateKey int NOT NULL,
	ShipDateKey int NOT NULL,
	CustomerKey int NOT NULL,
	PromotionKey int NOT NULL,
	CurrencyKey int NOT NULL,
	SalesTerritoryKey int NOT NULL,
	SalesOrderNumber nvarchar(20) NOT NULL,
	SalesOrderLineNumber tinyint NOT NULL,
	RevisionNumber tinyint NOT NULL,
	OrderQuantity smallint NOT NULL,
	UnitPrice money NOT NULL,
	ExtendedAmount money NOT NULL,
	UnitPriceDiscountPct float NOT NULL,
	DiscountAmount float NOT NULL,
	ProductStandardCost money NOT NULL,
	TotalProductCost money NOT NULL,
	SalesAmount money NOT NULL,
	TaxAmt money NOT NULL,
	Freight money NOT NULL,
	CarrierTrackingNumber nvarchar(25) NULL,
	CustomerPONumber nvarchar(25) NULL,
	OrderDate datetime NULL,
	DueDate datetime NULL,
	ShipDate datetime NULL
)

INSERT INTO dbo.FactInternetSales_big WITH(TABLOCK)
SELECT * FROM dbo.FactInternetSales;
GO 332
-- 20,052,136 records

sp_spaceused 'dbo.FactInternetSales_big'


CREATE NONCLUSTERED COLUMNSTORE INDEX csi_FactInternetSales_big 
ON dbo.FactInternetSales_big
(
	ProductKey,
	OrderDateKey,
	DueDateKey,
	ShipDateKey,
	CustomerKey,
	PromotionKey,
	CurrencyKey,
	SalesTerritoryKey,
	SalesOrderNumber,
	SalesOrderLineNumber,
	RevisionNumber,
	OrderQuantity,
	UnitPrice,
	ExtendedAmount,
	UnitPriceDiscountPct,
	DiscountAmount,
	ProductStandardCost,
	TotalProductCost,
	SalesAmount,
	TaxAmt,
	Freight,
	CarrierTrackingNumber,
	CustomerPONumber,
	OrderDate,
	DueDate,
	ShipDate
)
-- it took 18 minutes

-- Errors 8657, 8658, 701, 802  
-- Msg 8658, Level 17, State 1, Line 1
-- Cannot start the columnstore index build because it requires at least 353712 KB, while the maximum memory grant is limited to 
-- 260712 KB per query in workload group 'default' (2) and resource pool 'default' (2). 
-- Retry after modifying columnstore index to contain fewer columns, or after increasing the maximum memory grant limit with Resource Governor.

-- SQL Server Columnstore Index FAQ
-- http://social.technet.microsoft.com/wiki/contents/articles/3540.sql-server-columnstore-index-faq.aspx


ALTER WORKLOAD GROUP [DEFAULT] WITH (REQUEST_MAX_MEMORY_GRANT_PERCENT = 50) -- default is 25
ALTER RESOURCE GOVERNOR RECONFIGURE 
GO 

SELECT d.CalendarYear,
    SUM(SalesAmount) AS TotalSales
FROM dbo.FactInternetSales_big AS f
    JOIN dbo.DimDate AS d
    ON f.OrderDateKey = d.DateKey
WHERE ProductKey = 606
GROUP BY d.CalendarYear
ORDER BY d.CalendarYear


-- Hints

SELECT d.CalendarYear,
    SUM(SalesAmount) AS TotalSales
FROM dbo.FactInternetSales_big AS f
    JOIN dbo.DimDate AS d
    ON f.OrderDateKey = d.DateKey
WHERE ProductKey = 606
GROUP BY d.CalendarYear
ORDER BY d.CalendarYear
OPTION (IGNORE_NONCLUSTERED_COLUMNSTORE_INDEX);
-- 1:42 minutes

SELECT d.CalendarYear,
    SUM(SalesAmount) AS TotalSales
FROM dbo.FactInternetSales_big AS f WITH (INDEX(csi_FactInternetSales_big))
    JOIN dbo.DimDate AS d
    ON f.OrderDateKey = d.DateKey
WHERE ProductKey = 606
GROUP BY d.CalendarYear
ORDER BY d.CalendarYear


