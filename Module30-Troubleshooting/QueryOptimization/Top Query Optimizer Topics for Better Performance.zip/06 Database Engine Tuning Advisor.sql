
-- database engine tuning advisor

SELECT * 
INTO dbo.SalesOrderDetail 
FROM Sales.SalesOrderDetail

-- save in a new file
SELECT * FROM dbo.SalesOrderDetail
WHERE ProductID = 897

-- run dta and profiler

-- show both current and recommended cost
SELECT * FROM msdb..DTA_reports_query

--CREATE CLUSTERED INDEX cix_ProductID ON dbo.SalesOrderDetail(ProductID)
--WITH STATISTICS_ONLY

SELECT * FROM sys.indexes
WHERE object_id = object_id('dbo.SalesOrderDetail')
AND name = 'cix_ProductID'

--DROP INDEX dbo.SalesOrderDetail.cix_ProductID

CREATE CLUSTERED INDEX cix_ProductID ON dbo.SalesOrderDetail(ProductID)

-- clean up
DROP TABLE dbo.SalesOrderDetail

-- drop DTA sessions





