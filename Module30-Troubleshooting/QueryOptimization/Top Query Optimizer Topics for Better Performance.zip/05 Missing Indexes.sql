
-- missing indexes

SELECT * 
INTO dbo.SalesOrderDetail
FROM sales.SalesOrderDetail

-- show trivial plan limitation
SELECT * FROM dbo.SalesOrderDetail
WHERE SalesOrderID = 43670 AND SalesOrderDetailID > 112

-- create unrelated index to avoid trivial plan
CREATE INDEX IX_ProductID ON dbo.SalesOrderDetail(ProductID)

-- run same query again
-- shows table scan 
SELECT * FROM dbo.SalesOrderDetail
WHERE SalesOrderID = 43670 AND SalesOrderDetailID > 112

-- show XML information

CREATE NONCLUSTERED INDEX IX_SalesOrderID_SalesOrderDetailID
ON [dbo].[SalesOrderDetail]([SalesOrderID], [SalesOrderDetailID])

-- run same query again
-- shows index seek 
SELECT * FROM dbo.SalesOrderDetail
WHERE SalesOrderID = 43670 AND SalesOrderDetailID > 112

-- clean up
DROP TABLE dbo.SalesOrderDetail







