
-- parameter sniffing demo

CREATE PROCEDURE test (@pid int)
AS
SELECT * FROM Sales.SalesOrderDetail
WHERE ProductID = @pid

-- uses index seek-key lookup
EXEC test @pid = 898

DBCC SHOW_STATISTICS('Sales.SalesOrderDetail', IX_SalesOrderDetail_ProductID)

SET STATISTICS IO ON
GO
EXEC test @pid = 870
GO

-- logical reads 14075
-- table has only 1,244 pages!

-- data distribution
SELECT ProductID, COUNT(*) AS cnt
FROM Sales.SalesOrderDetail
GROUP BY ProductID
ORDER BY cnt

SELECT * FROM sys.dm_db_partition_stats
WHERE object_id = object_id('Sales.SalesOrderDetail')

-- see the best plan for this parameter
DBCC FREEPROCCACHE
GO
EXEC test @pid = 870
GO
-- show logical reads 1240

DBCC FREEPROCCACHE

-- 1. Optimize for a typical parameter
-- you control the plan on memory
-- avoid optimizations
ALTER PROCEDURE test (@pid int)
AS
SELECT * FROM Sales.SalesOrderDetail
WHERE ProductID = @pid
OPTION (OPTIMIZE FOR (@pid = 898))

EXEC test @pid = 870

-- show XML

-- 2. Optimize for every execution

ALTER PROCEDURE test (@pid int)
AS
SELECT * FROM Sales.SalesOrderDetail
WHERE ProductID = @pid
OPTION (RECOMPILE)

-- uses index seek-key lookup
EXEC test @pid = 898
-- uses table scan
EXEC test @pid = 870

-- removing parameter sniffing
-- Use local variables

DBCC SHOW_STATISTICS('Sales.SalesOrderDetail', IX_SalesOrderDetail_ProductID)

ALTER PROCEDURE test (@pid int)
AS
DECLARE @p int = @pid
SELECT * FROM Sales.SalesOrderDetail
WHERE ProductID = @p

-- Use OPTIMIZE FOR UNKNOWN

ALTER PROCEDURE test (@pid int)
AS
SELECT * FROM Sales.SalesOrderDetail
WHERE ProductID = @pid
OPTION (OPTIMIZE FOR UNKNOWN)

-- value does not matter
-- uses always the same plan
EXEC test @pid = 898

-- it no longer uses the histogram
-- but density which estimates 456.079

-- clean up

DROP PROCEDURE test

-- additional demo

DBCC SHOW_STATISTICS('Sales.SalesOrderDetail', IX_SalesOrderDetail_ProductID)

-- histogram shows 9
EXEC test @pid = 898

-- density shows 456.079
SELECT 121317 * 0.003759399 
-- total rows * density where
-- density is 1 / number of distinct values

SELECT 1.0 / (SELECT COUNT(DISTINCT(ProductID)) FROM Sales.SalesOrderDetail)





























