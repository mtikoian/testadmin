
-- correlated columns

SELECT * FROM Cars 
WHERE Model = 'Camry'
-- estimated 50

SELECT * FROM Cars 
WHERE Color = 'Red'
-- estimated 73

SELECT (50 * 73) / 361.0
-- 10.110803

-- independence assumption is correct here
SELECT * FROM Cars 
WHERE Model = 'Camry' AND Color = 'Red'
-- estimated 10.110803

-- correlated columns
SELECT * FROM Cars 
WHERE Model = 'Camry'
-- estimated 50

SELECT * FROM Cars 
WHERE Make = 'Toyota'
-- estimated 83

-- Query Optimizer will
-- incorrectly estimate this
SELECT (50 * 83) / 361.0
-- 11.4958

SELECT * FROM Cars 
WHERE Make = 'Toyota' AND Model = 'Camry'
-- 11.4958

-- using multicolumn statistics
CREATE STATISTICS multicolumn_statistics ON
cars(make, model)

DBCC FREEPROCCACHE
GO
SELECT * FROM Cars 
WHERE Make = 'Toyota' AND Model = 'Camry'
-- estimated 36.1

--DBCC SHOW_STATISTICS(Cars, multicolumn_statistics)

DROP STATISTICS Cars.multicolumn_statistics

-- using filtered statistics
CREATE STATISTICS filtered_statistics ON Cars(Model)
WHERE Make  = 'Toyota'

-- maybe
CREATE STATISTICS filtered_statistics2 ON Cars(Model)
WHERE Make  = 'Ford'
CREATE STATISTICS filtered_statistics3 ON Cars(Model)
WHERE Make  = 'Honda'

-- now estimated is again 50
DBCC FREEPROCCACHE
GO
SELECT * FROM cars 
WHERE Make = 'Toyota' AND Model = 'Camry'

DBCC SHOW_STATISTICS(Cars, filtered_statistics)

-- clean up
select * from sys.stats
where object_id = object_id('Cars')

drop statistics Cars._WA_Sys_00000003_7E6CC920
drop statistics Cars._WA_Sys_00000002_7E6CC920
drop statistics Cars.multicolumn_statistics
drop statistics Cars._WA_Sys_00000004_7E6CC920
drop statistics Cars.filtered_statistics













