/*
View Expansioin
*/

/*
We want to do a select from our 
Database to find out what courses our
college offers
*/
use college
go
select
	*
from
	dbo.vw_courses 

select
*
from
	dbo.courses
/*
Let's do our query from earlier in the week
*/
select
	s.LastName
	,s.firstname
	,g.Grade
	,count(g.Grade)
from
	dbo.vw_students s, vw_grades g
where
	s.studentID=g.studentID
	and
	g.grade='f'
	and
	s.LastName = 'whedon'
	and s.FirstName='David'
group by s.LastName, s.firstname, g.Grade 

/*
let's dig into this
just select * from vw_students
*/
select
	*
from
	vw_students s
where
	s.LastName = 'whedon'
	and s.FirstName='David'









/*




fix

*/
select
	s.LastName
	,s.firstname
	,g.Grade
	,count(g.Grade)
from
	dbo.students s, grades g
where
	s.studentID=g.studentID
	and
	g.grade='f'
	and
	s.LastName = 'whedon'
	and s.FirstName='David'
group by s.LastName, s.firstname, g.Grade 



	



