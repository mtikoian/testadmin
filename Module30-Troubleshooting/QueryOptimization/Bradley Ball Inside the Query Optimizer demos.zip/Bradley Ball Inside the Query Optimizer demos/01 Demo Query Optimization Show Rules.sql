dbcc traceon(3604)
go
dbcc showonrules
dbcc showoffrules


select * from sys.dm_exec_query_transformation_stats