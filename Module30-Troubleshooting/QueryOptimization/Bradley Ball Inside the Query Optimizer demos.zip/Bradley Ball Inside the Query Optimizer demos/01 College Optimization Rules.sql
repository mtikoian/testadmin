/*
INPUT TREE Example
*/
dbcc traceon(3604)
Use College
go
select
	s.LastName
	,g.Grade
	,count(g.Grade)
from
	dbo.students s
	inner join grades g
	on s.studentID=g.studentID
where
	g.grade='f'
	and
	s.LastName = 'whedon'
	and s.FirstName='paul'
group by s.LastName, g.Grade option(maxdop 1,  RECOMPILE, QUERYTRACEON 8605)

/*
Expanded Views 
*/

select 
	counter
	,occurrence
from
	sys.dm_exec_query_optimizer_info
where
	counter=N'view reference'
go
with CTEisaView AS
(
	select
		*
	from
		dbo.students 
 		
	)
select
	s.LastName
	,g.grade
	,count(*)
from
	CTEisaView s
inner join dbo.grades g
		on s.studentID=g.studentID
group by
	s.LastName, g.grade
OPTION (RECOMPILE, QUERYTRACEON 8605);
go

select 
	counter
	,occurrence
from
	sys.dm_exec_query_optimizer_info
where
	counter=N'view reference'

/*
What about
Derived Queries
*/
select 
	counter
	,occurrence
from
	sys.dm_exec_query_optimizer_info
where
	counter=N'view reference'
go
select
	w.LastName
	,w.grade
	,count(*)

from (	
	select
		s.studentid
		,s.LastName
		,g.gradeID
		,g.grade
	from
		dbo.students s
		inner join dbo.grades g
		on s.studentID=g.studentID	
	) w
group by
	w.LastName, w.grade
OPTION (RECOMPILE, QUERYTRACEON 8605);
go

select 
	counter
	,occurrence
from
	sys.dm_exec_query_optimizer_info
where
	counter=N'view reference'


/*
SIMPLIFICATION
*/
--*Constant Folding*
--Make sure show actual execution plan
--is on, show predicate is p.name like 'K%'
select
	s.LastName
from
	dbo.students s
where
	s.lastname like SUBSTRING(LEFT(CHAR(ASCII(CHAR(75))), 1) + '%', 1, 2)

--*Domain Simplification*
/*
example 1
*/
select
	top(10) *
from dbo.students s
where s.studentid between 100005 and 500000
and s.studentID between 90000 and 300000
and s.studentID between 80000 and 100005






/*
example 2
Join Simplification
*/
select 
	s.LastName
from
	dbo.students s
	left join dbo.enrollment e
	on e.studentID=s.studentID
	left join dbo.courses c
	on e.courseID=c.courseID
group by
	s.LastName
option (maxdop 1, recompile)
	

/*
example 3
more join simplification
*/
Use AdventureWorks2012
go
WITH Complex AS
(
    SELECT
        pc.ProductCategoryID, pc.Name AS CatName,
        ps.ProductSubcategoryID, ps.Name AS SubCatName,
        p.ProductID, p.Name AS ProductName,
        p.Color, p.ListPrice, p.ReorderPoint,
        pm.Name AS ModelName, pm.ModifiedDate
    FROM Production.ProductCategory AS pc
    FULL JOIN Production.ProductSubcategory AS ps ON
        ps.ProductCategoryID = pc.ProductCategoryID
    FULL JOIN Production.Product AS p ON
        p.ProductSubcategoryID = ps.ProductSubcategoryID
    FULL JOIN Production.ProductModel AS pm ON
        pm.ProductModelID = p.ProductModelID
)
SELECT c.ProductID, c.ProductName
FROM Complex AS c
WHERE c.ProductName LIKE N'G%'
OPTION (RECOMPILE, QUERYTRACEON 8605);


/*
example 4
*/
use college
go
set statistics io on
set statistics time on
select
	top(10) *
from dbo.students s
where s.studentid between 100005 and 500000
and s.studentID between 90000 and 300000
and s.studentID between 80000 and 100005
and s.studentID <> 100005

set statistics io off
set statistics time off

/*
TRIVIAL PLAN
*/
-- Trivial plan
select
	*
from
	dbo.students
where
	studentID=100005


/*
trivial tacking using dmv's
*/
select
	*
from
	sys.dm_exec_query_optimizer_info
where counter in('optimizations','trivial plan', 'search 0', 'search 1','search 2')
go
-- Still Trivial
select
	studentID
	,FirstName
	,LastName
	,BirthDate
	,gender
from
	dbo.students
where
	studentID=100031
option(recompile)
go
select
	*
from
	sys.dm_exec_query_optimizer_info
where counter in('optimizations','trivial plan', 'search 0', 'search 1','search 2')

/*
trivial tacking using dmv's
*/
select
	*
from
	sys.dm_exec_query_optimizer_info
where counter in('optimizations','trivial plan', 'search 0', 'search 1','search 2')
go
-- Still Trivial
select
	s.studentID
	,s.FirstName
	,s.LastName
	,s.BirthDate
	,s.gender
	,rownumber = row_number() over (order by s.studentid)
from
	dbo.students s
where
	studentID=100031
option(recompile)
go
select
	*
from
	sys.dm_exec_query_optimizer_info
where counter in('optimizations','trivial plan', 'search 0', 'search 1','search 2')

/*
Now Full because of the subquery
*/
select
	*
from
	sys.dm_exec_query_optimizer_info
where counter in('optimizations','trivial plan', 'search 0', 'search 1','search 2')
go
-- now Full
select
	(select s.studentID)
	,s.FirstName
	,s.LastName
	,s.BirthDate
	,s.gender
from
	dbo.students s
where
	studentID=100031
option(recompile)
go
select
	*
from
	sys.dm_exec_query_optimizer_info
where counter in('optimizations','trivial plan', 'search 0', 'search 1','search 2')

/*
Now Full because of the subquery
*/
select
	*
from
	sys.dm_exec_query_optimizer_info
where counter in('optimizations','trivial plan', 'search 0', 'search 1','search 2')
go
-- now Full
select
	s.studentID
	,s.FirstName
	,s.LastName
	,s.BirthDate
	,s.gender
from
	dbo.students s
where
	studentID<>100031
option(recompile)
go
select
	*
from
	sys.dm_exec_query_optimizer_info
where counter in('optimizations','trivial plan', 'search 0', 'search 1','search 2')
