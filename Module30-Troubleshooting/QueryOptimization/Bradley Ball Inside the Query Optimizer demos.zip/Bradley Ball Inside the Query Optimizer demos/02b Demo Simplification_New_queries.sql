use AdventureWorks2012
--use AdventureWorks2008R2
go
select
	o.customerid
from Test.Orders as o
where exists
	(select c.customerid from test.customers as c
			where
				c.customerid=o.customerid)


/*
turn off the fk constaraint
let's look at how the execution
*/
alter table test.orders  nocheck constraint fkorderscustomers
go

/*
run it again
*/
select
	o.*
from Test.Orders as o
where exists
	(select * from test.customers as c
			where
				c.customerid=o.customerid)

/*
Okay so let's re-enable the check constraint
*/
alter table test.orders check constraint fkorderscustomers

/*
run it again
*/
select
	o.*
from Test.Orders as o
where exists
	(select * from test.customers as c
			where
				c.customerid=o.customerid)

/*
hmmmm we've still got the 2nd bad plan that ignores simplification.
Why?
*/
select
	name
	,is_not_trusted
from
	sys.foreign_keys
where
	name='FKOrdersCustomers';

/*
is_not_trusted = 1 
this is because we didn't check the data after the check had been off
the data is not trusted yet.  Let's fix that.
*/
alter table test.orders with check check constraint fkorderscustomers

/*
now let's check to see it's trusted
*/
select
	name
	,is_not_trusted
from
	sys.foreign_keys
where
	name='FKOrdersCustomers';

/*
now let's look at the old execution plan
*/
select
	o.*
from Test.Orders as o
where exists
	(select * from test.customers as c
			where
				c.customerid=o.customerid)