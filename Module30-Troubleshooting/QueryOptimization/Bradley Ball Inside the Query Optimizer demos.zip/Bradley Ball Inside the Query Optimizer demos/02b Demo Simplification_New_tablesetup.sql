use AdventureWorks2012
--use AdventureWorks2008R2
go
/*
	create schema [test] authorization [dbo];
*/
go
if exists(select name from sys.foreign_keys where name='fkorderscustomers')
begin
	ALTER TABLE [test].[Orders] DROP CONSTRAINT [fkOrdersCustomers]
end
GO
if exists(select t.name from sys.tables t left join sys.schemas s on t.schema_id=s.schema_id where s.name='test' and t.name='Customers')
begin
	drop table test.customers
end
create table test.Customers(
	CustomerID int Primary Key
)
go
if exists(select t.name from sys.tables t left join sys.schemas s on t.schema_id=s.schema_id where s.name='test' and t.name='Orders')
begin
	drop table test.Orders
end
create table test.Orders(
	OrderID int Primary Key
	,CustomerID int not null
	Constraint fkOrdersCustomers references test.Customers(CustomerID)

)

/*
populate
*/
declare @i int
set @i=0

while(@i<10000)
begin
	set @i=@i+1
	insert into test.customers(customerid)
	values(@i)

	insert into test.orders(OrderID, CustomerID)
	values((@i*2), @i)
end
