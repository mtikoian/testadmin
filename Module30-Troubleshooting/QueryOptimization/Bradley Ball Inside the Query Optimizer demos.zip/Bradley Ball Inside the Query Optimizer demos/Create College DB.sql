use master
go
if exists(select name from sys.databases where name='college')
begin
	drop database college
end
go
create database college
go
use College
go
/*
create student tables
*/
if exists(select name from sys.tables where name='students')
begin
	drop table students
end
go
create table students( 
				studentID int identity(100000,1) 
				,ssn char(9)
				,FirstName varchar(50)
				,MiddileInitial char(1)
				,LastName varchar(100)
				,BirthDate datetime
				,Gender char(1)
				,enrolled bit default 0
				,constraint pk_students_studentID primary key clustered (studentID)
				)

declare @i int, @x int, @y int, @z int, @firstname varchar(50), @ssn char(9), @mi char(1), @LastName varchar(100),@DOB datetime, @gender char(1),  @date_from DATETIME, @date_to DATETIME
 
SET @date_from = '1992-12-01';
SET @date_to = '1996-1-01';
set @i=0
begin transaction
while(@i<899999)
Begin

	set @x=(select CAST(RAND() * 10 AS INT))
	set @y=(select CAST(RAND() * 10 AS INT))
	set @z=(select CAST(RAND() * 10 AS INT))
	set @ssn=cast((select CAST(RAND() * 1000000000 AS INT)) as char(9))
	set @dob=(SELECT
(@date_from +(ABS(CAST(CAST( NewID() AS BINARY(8) )AS INT))%CAST((@date_to - @date_from)AS INT))))


	select
		@firstname=case @x
			when 1 then  'Michael'
			when 2 then 'Neil'
			when 3 then 'David'
			when 4 then 'Joss'
			when 5 then 'Jorge'
			when 6 then 'Chad'
			when 7 then 'Kathi'
			when 8 then 'Lisa'
			when 9 then 'Serenity'
			else 'Paul'
		end
		,@lastname=case @y
			when 1 then  'Jordan'
			when 2 then 'Patrick-Harris'
			when 3 then 'Ball'
			when 4 then 'Whedon'
			when 5 then 'Segarra'
			when 6 then 'Churchwell'
			when 7 then 'Kellenburger'
			when 8 then 'Simpson'
			when 9 then 'Elizabeth'
			else 'Randal'
		end
		,@mi=case @z
			when 1 then  'T'
			when 2 then 'W'
			when 3 then 'X'
			when 4 then 'C'
			when 5 then 'V'
			when 6 then 'H'
			when 7 then 'P'
			when 8 then 'L'
			when 9 then 'B'
			else 'Q'
		end
		,@gender=case 
			when (@x<7) then 'M'
			else 'F'
			end 

			insert into students(ssn,FirstName,MiddileInitial,LastName,BirthDate,Gender)
			values( @ssn, @firstname, @mi, @LastName, @dob, @gender)

	set @i=@i+1

end
commit transaction
/*
create courses table
*/
if exists(select name from sys.tables where name='courses')
begin
	drop table courses
end
go
create table courses(
				courseID int identity(1000,1)
				,courseName varchar(100)
				,courseDescription char(1000) default 'more on this later...'
				,creditHours int
				,islab char(1)
				, constraint pk_courses_courseID primary key clustered(courseID)
				)

go
declare @i int, @x int, @y int, @z int, @cname varchar(100), @cname2 varchar(100), @cname3 varchar(100), @fcname varchar(100), @cd varchar(1000), @ch int, @lab char(1)

set @i=0
begin tran
while (@i<8999)
begin
	set @x=(select CAST(RAND() * 10 AS INT))
	set @y=(select CAST(RAND() * 10 AS INT))
	set @z=(select CAST(RAND() * 10 AS INT))

	select
		@cname=case @x
			when 1 then 'Introduction Into '
			when 2 then 'Advanced Algebraic '
			when 3 then 'Deep Dive into '
			when 4 then 'Experimental '
			when 5 then 'Theoretical '
			when 6 then 'Zen Masters Introduction to '
			when 7 then 'The Art of '
			when 8 then 'Practical '
			when 9 then 'Lab '
			else 'The Physical Implimentation of '
		end
		,@cname2=case @y
			when 1 then 'Comic Book Outlines '
			when 2 then 'Trampolines '
			when 3 then 'SQL Server Internals '
			when 4 then 'Defense Against the Dark Arts '
			when 5 then 'Cartoons of the 1980s '
			when 6 then 'Cinematogrophy in 1492 '
			when 7 then 'Corporate Raiding Pirate Style '
			when 8 then 'Philosopy and Physics '
			when 9 then 'Blowing Stuff Up '
			else 'Staring Down your Proffessor '
			end
		,@cname3=case @z
			when 1 then 'For Dummies '
			when 2 then ' 101 '
			when 3 then '501 '
			when 4 then '101-601 '
			when 5 then 'featuring Bill Murry '
			when 6 then 'During the Zombie Apocalypse '
			when 7 then 'While Navigating a Burning Canno '
			when 8 then 'Without a Paddle or a License '
			when 9 then 'In the Field of Battle '
			else 'In the Wild '
			end
			,@ch=case @z
			when 1 then 2
			when 2 then 2
			when 3 then 3
			when 4 then 3
			when 5 then 3
			when 6 then 4
			when 7 then 4
			when 8 then 1
			when 9 then 1
			else 3
			end
			,@lab=case 
			when (@z<7) then 'N'
			else 'Y'
			end


			insert into dbo.courses(courseName,credithours,islab)
			values((@cname+@cname2+@cname3), @ch,@lab)
			set @i=@i+1
end
commit tran
/*
create table enrollment
*/
if exists(select name from sys.tables where name='enrollment')
begin
	drop table enrollment
end
go
create table enrollment
	( enrollmentID int identity(1,1)
	  ,courseID int
	  ,studentID int
	  ,enrollmentDate datetime
	  , constraint pk_enrollment_enrollmentid primary key clustered(enrollmentid)
	  )
declare @i int, @x int, @y int, @z int, @sid int, @cid int, @ed1 datetime, @ed2 datetime, @ed3 datetime,@date_from DATETIME, @date_to DATETIME,@date_from2 DATETIME, @date_to2 DATETIME, @date_from3 DATETIME, @date_to3 DATETIME, @fed datetime

SET @date_from = '2011-09-01';
SET @date_to = '2011-09-24';
SET @date_from2 = '2012-01-05';
SET @date_to2 = '2012-01-24';
SET @date_from3 = '2012-09-01';
SET @date_to3 = '2012-09-24';
set @i=0
begin tran
while (@i<1000000)
begin

	set @x=(select CAST(RAND() * 1000000 AS INT))
	set @y=(select CAST(RAND() * 10000 AS INT))
	set @z=(select CAST(RAND() * 10 AS INT))
set @ed1=(SELECT
(@date_from +(ABS(CAST(CAST( NewID() AS BINARY(8) )AS INT))%CAST((@date_to - @date_from)AS INT))))
set @ed2=(SELECT
(@date_from2 +(ABS(CAST(CAST( NewID() AS BINARY(8) )AS INT))%CAST((@date_to2 - @date_from2)AS INT))))
set @ed3=(SELECT
(@date_from3 +(ABS(CAST(CAST( NewID() AS BINARY(8) )AS INT))%CAST((@date_to3 - @date_from3)AS INT))))

	set @sid=(select studentID from students where studentID=@x)
	set @cid=(select courseID from courses where courseID=@y)
	if ((@sid=''))
	begin
		set @sid=(select top 1 studentID from students)
	end
	if ((@cid=''))
	begin
		set @cid=(select courseID from courses where courseID=@y)
	end

	select
		@fed=case @z
			when 1 then @ed1
			when 2 then @ed1
			when 3 then @ed1
			when 4 then @ed2
			when 5 then @ed2
			when 6 then @ed2
			when 7 then @ed3
			when 8 then @ed3
			when 9 then @ed3
			else @ed3
			end

		insert into dbo.enrollment(courseID,studentID,enrollmentDate)
		values( @cid, @sid, @fed)
		
		update students
		set enrolled=1
		where
			studentID=@sid

	set @i=@i+1

end
	commit transaction
go
/*
take care of nulls
*/
declare @stuid int, @courseid int
set @stuid =(select top(1) studentid from students)
set @courseid=(select min(courseid) from courses)

update enrollment
set studentID=@stuid
where
	studentid is null

update enrollment
set courseID=@courseid
where
	courseID is null
go
/* 
Create Grade Table
*/
if exists(select name from sys.tables where name='Grades')
begin
	drop table Grades
end
go
create table Grades
	( gradeID int identity(1,1) primary key clustered
	  ,courseID int
	  ,studentID int
	  ,Grade char(1)
	  )

insert into dbo.grades(courseid, studentid)
select courseid, studentid from dbo.enrollment where enrollmentDate < '8/30/2012'
go

declare @i int, @x int, @y int, @g char(1)
set @i=0

update grades
set grade='A'
where
	studentid%2=1
go
update grades
set grade='B'
where
	studentid%3=1
go
update grades
set grade='C'
where
	studentid%5=1
go
update grades
set grade='D'
where
	studentid%7=1
go
update grades
set grade='F'
where
	studentid%11=1
go
update grades
set grade='C'
where
	grade is null
 /*
set @x=(select count(*) from dbo.grades)
begin tran
while (@i<@x)
begin
	set @i=@i+1
	set @y=(select CAST(RAND() * 10 AS INT))

	select
		@g=case @y
			when 1 then 'A'
			when 2 then 'A'
			when 3 then 'B'
			when 4 then 'B'
			when 5 then 'C'
			when 6 then 'C'
			when 7 then 'D'
			when 8 then 'D'
			when 9 then 'F'
			else 'W'
		end
		UPDATE DBO.Grades
		SET GRADE=@g
		where gradeID=@i
end
commit tran
*/
/*update nulls*/
declare @stuid int
set @stuid =(select top(1) studentid from students)

update grades
set studentID=@stuid
where
	studentid is null
go


use college
go
if exists(select name from sys.objects where name='vw_student_enrollment')
begin
	drop view vw_student_enrollment
end
go
create view vw_student_enrollment
as
select
	s.studentID
	,s.ssn
	,s.FirstName
	,s.MiddileInitial
	,s.LastName
	,s.BirthDate
	,s.Gender
	,s.enrolled
	,e.courseID
	,e.enrollmentID
	,e.enrollmentDate
from
	students s
	 inner join enrollment e
	on s.studentID=e.studentID
go
if exists(select name from sys.objects where name='vw_coures_grade')
begin
	drop view vw_coures_grade
end
go
create view vw_coures_grade
as
select
	c.courseID
	,c.courseName
	,c.creditHours
	,c.islab
	,c.courseDescription
	,g.gradeID
	,g.Grade
	,g.studentID
from
	courses c
	inner join grades g
	on g.courseID=c.courseID
go
if exists(select name from sys.objects where name='vw_student_grade_A')
begin
	drop view vw_student_grade_A 
end
go
create view vw_student_grade_A
as
select
	s.studentID
	,s.ssn
	,s.FirstName
	,s.MiddileInitial
	,s.LastName
	,s.BirthDate
	,s.Gender
	,s.enrolled
	,s.courseID
	,s.enrollmentID
	,s.enrollmentDate
	,g.courseName
	,g.courseDescription
	,g.creditHours
	,g.islab
	,g.grade
	,g.gradeID
from
	vw_student_enrollment s
	join vw_coures_grade g
	on s.studentId=g.studentID and s.courseID=g.courseID
where
	g.grade = 'A'
go
if exists(select name from sys.objects where name='vw_student_grade_b')
begin
	drop view vw_student_grade_b 
end
go
create view vw_student_grade_b
as
select
	s.studentID
	,s.ssn
	,s.FirstName
	,s.MiddileInitial
	,s.LastName
	,s.BirthDate
	,s.Gender
	,s.enrolled
	,s.courseID
	,s.enrollmentID
	,s.enrollmentDate
	,g.courseName
	,g.courseDescription
	,g.creditHours
	,g.islab
	,g.grade
	,g.gradeID
from
	vw_student_enrollment s
	join vw_coures_grade g
	on s.studentId=g.studentID and s.courseID=g.courseID
where
	g.grade = 'B'
go

if exists(select name from sys.objects where name='vw_student_grade_c')
begin
	drop view vw_student_grade_c 
end
go
create view vw_student_grade_c
as
select
	s.studentID
	,s.ssn
	,s.FirstName
	,s.MiddileInitial
	,s.LastName
	,s.BirthDate
	,s.Gender
	,s.enrolled
	,s.courseID
	,s.enrollmentID
	,s.enrollmentDate
	,g.courseName
	,g.courseDescription
	,g.creditHours
	,g.islab
	,g.grade
	,g.gradeID
from
	vw_student_enrollment s
	join vw_coures_grade g
	on s.studentId=g.studentID and s.courseID=g.courseID
where
	g.grade = 'c'
go

if exists(select name from sys.objects where name='vw_student_grade_D')
begin
	drop view vw_student_grade_D
end
go
create view vw_student_grade_D
as
select
	s.studentID
	,s.ssn
	,s.FirstName
	,s.MiddileInitial
	,s.LastName
	,s.BirthDate
	,s.Gender
	,s.enrolled
	,s.courseID
	,s.enrollmentID
	,s.enrollmentDate
	,g.courseName
	,g.courseDescription
	,g.creditHours
	,g.islab
	,g.grade
	,g.gradeID
from
	vw_student_enrollment s
	join vw_coures_grade g
	on s.studentId=g.studentID and s.courseID=g.courseID
where
	g.grade = 'D'
go
if exists(select name from sys.objects where name='vw_student_grade_F')
begin
	drop view vw_student_grade_F
end
go
create view vw_student_grade_F
as
select
	s.studentID
	,s.ssn
	,s.FirstName
	,s.MiddileInitial
	,s.LastName
	,s.BirthDate
	,s.Gender
	,s.enrolled
	,s.courseID
	,s.enrollmentID
	,s.enrollmentDate
	,g.courseName
	,g.courseDescription
	,g.creditHours
	,g.islab
	,g.grade
	,g.gradeID
from
	vw_student_enrollment s
	join vw_coures_grade g
	on s.studentId=g.studentID and s.courseID=g.courseID
where
	g.grade = 'F'
go
if exists(select name from sys.objects where name='vw_Female_student_grades')
begin
	drop view vw_Female_student_grades
end
go
create view vw_Female_student_grades
as
select
	s.studentID
	,s.ssn
	,s.FirstName
	,s.MiddileInitial
	,s.LastName
	,s.BirthDate
	,s.Gender
	,s.enrolled
	,s.courseID
	,s.enrollmentID
	,s.enrollmentDate
	,s.courseName
	,s.courseDescription
	,s.creditHours
	,s.islab
	,s.grade
	,s.gradeID
from
	vw_student_grade_A s
where
	s.Gender='F'
union
select
	s.studentID
	,s.ssn
	,s.FirstName
	,s.MiddileInitial
	,s.LastName
	,s.BirthDate
	,s.Gender
	,s.enrolled
	,s.courseID
	,s.enrollmentID
	,s.enrollmentDate
	,s.courseName
	,s.courseDescription
	,s.creditHours
	,s.islab
	,s.grade
	,s.gradeID
from
	vw_student_grade_B s
where
	s.Gender='F'
union
select
	s.studentID
	,s.ssn
	,s.FirstName
	,s.MiddileInitial
	,s.LastName
	,s.BirthDate
	,s.Gender
	,s.enrolled
	,s.courseID
	,s.enrollmentID
	,s.enrollmentDate
	,s.courseName
	,s.courseDescription
	,s.creditHours
	,s.islab
	,s.grade
	,s.gradeID
from
	vw_student_grade_c s
where
	s.Gender='F'
union
select
	s.studentID
	,s.ssn
	,s.FirstName
	,s.MiddileInitial
	,s.LastName
	,s.BirthDate
	,s.Gender
	,s.enrolled
	,s.courseID
	,s.enrollmentID
	,s.enrollmentDate
	,s.courseName
	,s.courseDescription
	,s.creditHours
	,s.islab
	,s.grade
	,s.gradeID
from
	vw_student_grade_D s
where
	s.Gender='F'
union
select
	s.studentID
	,s.ssn
	,s.FirstName
	,s.MiddileInitial
	,s.LastName
	,s.BirthDate
	,s.Gender
	,s.enrolled
	,s.courseID
	,s.enrollmentID
	,s.enrollmentDate
	,s.courseName
	,s.courseDescription
	,s.creditHours
	,s.islab
	,s.grade
	,s.gradeID
from
	vw_student_grade_F s
where
	s.Gender='F'

go
if exists(select name from sys.objects where name='vw_male_student_grades')
begin
	drop view vw_male_student_grades
end
go
create view vw_male_student_grades
as
select
	s.studentID
	,s.ssn
	,s.FirstName
	,s.MiddileInitial
	,s.LastName
	,s.BirthDate
	,s.Gender
	,s.enrolled
	,s.courseID
	,s.enrollmentID
	,s.enrollmentDate
	,s.courseName
	,s.courseDescription
	,s.creditHours
	,s.islab
	,s.grade
	,s.gradeID
from
	vw_student_grade_A s
where
	s.Gender='M'
union
select
	s.studentID
	,s.ssn
	,s.FirstName
	,s.MiddileInitial
	,s.LastName
	,s.BirthDate
	,s.Gender
	,s.enrolled
	,s.courseID
	,s.enrollmentID
	,s.enrollmentDate
	,s.courseName
	,s.courseDescription
	,s.creditHours
	,s.islab
	,s.grade
	,s.gradeID
from
	vw_student_grade_B s
where
	s.Gender='M'
union
select
	s.studentID
	,s.ssn
	,s.FirstName
	,s.MiddileInitial
	,s.LastName
	,s.BirthDate
	,s.Gender
	,s.enrolled
	,s.courseID
	,s.enrollmentID
	,s.enrollmentDate
	,s.courseName
	,s.courseDescription
	,s.creditHours
	,s.islab
	,s.grade
	,s.gradeID
from
	vw_student_grade_c s
where
	s.Gender='M'
union
select
	s.studentID
	,s.ssn
	,s.FirstName
	,s.MiddileInitial
	,s.LastName
	,s.BirthDate
	,s.Gender
	,s.enrolled
	,s.courseID
	,s.enrollmentID
	,s.enrollmentDate
	,s.courseName
	,s.courseDescription
	,s.creditHours
	,s.islab
	,s.grade
	,s.gradeID
from
	vw_student_grade_D s
where
	s.Gender='M'
union
select
	s.studentID
	,s.ssn
	,s.FirstName
	,s.MiddileInitial
	,s.LastName
	,s.BirthDate
	,s.Gender
	,s.enrolled
	,s.courseID
	,s.enrollmentID
	,s.enrollmentDate
	,s.courseName
	,s.courseDescription
	,s.creditHours
	,s.islab
	,s.grade
	,s.gradeID
from
	vw_student_grade_F s
where
	s.Gender='M'

go
if exists(select name from sys.objects where name='vw_all_fields')
begin
	drop view vw_all_fields
end
go
create view vw_all_fields
as
select
	s.studentID
	,s.ssn
	,s.FirstName
	,s.MiddileInitial
	,s.LastName
	,s.BirthDate
	,s.Gender
	,s.enrolled
	,s.courseID
	,s.enrollmentID
	,s.enrollmentDate
	,s.courseName
	,s.courseDescription
	,s.creditHours
	,s.islab
	,s.grade
	,s.gradeID
from
	vw_Female_student_grades s
union
select
	s.studentID
	,s.ssn
	,s.FirstName
	,s.MiddileInitial
	,s.LastName
	,s.BirthDate
	,s.Gender
	,s.enrolled
	,s.courseID
	,s.enrollmentID
	,s.enrollmentDate
	,s.courseName
	,s.courseDescription
	,s.creditHours
	,s.islab
	,s.grade
	,s.gradeID
from
	vw_male_student_grades s
go
if exists(select name from sys.objects where name='vw_students')
begin
	drop view vw_students
end
go
create view vw_students
as
select
	s.studentID
	,s.ssn
	,s.FirstName
	,s.MiddileInitial
	,s.LastName
	,s.BirthDate
	,s.Gender
	,s.enrolled
from vw_all_fields s
go

if exists(select name from sys.objects where name='vw_Grades')
begin
	drop view vw_Grades 
end
go
create view vw_Grades
as
select
	g.gradeID
	,g.courseID
	,g.studentID
	,g.grade
from
	 vw_all_fields g
go
if exists(select name from sys.objects where name='vw_enrollment')
begin
	drop view vw_enrollment  
end
go
create view vw_enrollment
as
select
	e.enrollmentID
	,e.courseID
	,e.studentID
	,e.enrollmentDate
from
	 vw_all_fields e
go
if exists(select name from sys.objects where name='vw_courses')
begin
	drop view vw_courses  
end
go
create view vw_courses
as
select
	c.courseID
	,c.courseName
	,c.courseDescription
	,c.creditHours
	,c.islab
from
	 vw_all_fields c
go
