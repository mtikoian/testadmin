/*
Query Plans

Mike DeFehr
mike@defehr.com
*/

--USE AdventureWorks2008R2
USE AdventureWorks2012
GO

/*
Are the secrets hidden?
*/

SET STATISTICS IO ON
GO

--Basic query plan example - table scans

SELECT * 
FROM Production.ProductHeap

SELECT *
FROM Production.Product

--/demo 1

SELECT *
FROM Production.Product
WHERE ReorderPoint = 750
GO

--sp_help 'Production.Product'
--sp_helpindex 'Production.Product'
--sp_sqlskills_SQL2012_helpindex 'Production.Product' --(sqlskills.com | Kimberly Tripp sp_helpindex)

SELECT [ProductNumber], [ProductID]
FROM Production.Product
GO

SELECT [ProductNumber], [ProductID], Color
FROM Production.Product
GO

--/demo



--The tipping point

WITH cte AS
(
SELECT	SUBSTRING(LastName,1,1) NameLetter, 
		CAST(COUNT(*) AS decimal(19,1)) NumNames
FROM Person.Person
GROUP BY SUBSTRING(LastName,1,1)
)
SELECT	*,
		CAST(NumNames / SUM(NumNames) OVER() * 100 AS decimal(19,1)) AS PercentOfTotal
FROM cte
ORDER BY 2 DESC


EXEC sp_sqlskills_SQL2012_helpindex 'Person.Person'
GO

SELECT * 
FROM Person.Person
--WHERE LastName LIKE 'S%'
WHERE LastName LIKE 'Q%'
GO










--Secrets:
--With W: 1075 / 19972.0 (5.38%) Scan
--With A: 911 / 19972.0 (4.56%) Seek
GO

DBCC SHOW_STATISTICS ('Person.Person','IX_Person_LastName_FirstName_MiddleName')

--RANGE_HI_KEY	RANGE_ROWS	EQ_ROWS	DISTINCT_RANGE_ROWS	AVG_RANGE_ROWS
--Anderson		0			85		0					1
--Arthur		9			24		8					1.125

SELECT * 
FROM Person.Person
WHERE LastName = 'Arthur'

SELECT * 
FROM Person.Person
WHERE LastName > 'Anderson'
	AND LastName < 'Arthur'

SELECT *
FROM Person.Person
WHERE LastName = 'Archer'



SET STATISTICS TIME ON

--Estimate vs. Actual (example from Ami Levin)
SELECT	s.SalesOrderID, 
		p.Name, 
		s.OrderQty
FROM Production.Product p
	JOIN Sales.SalesOrderDetail s ON p.ProductID = s.ProductID
WHERE p.DaysToManufacture > 2
	AND p.ListPrice > 1350
	AND	p.StandardCost > 750

--remember:  SQL Server does not generally keep track of what it "did"
	
SELECT	s.SalesOrderID, 
		p.Name, 
		s.OrderQty
FROM Production.Product p
	INNER MERGE JOIN Sales.SalesOrderDetail s ON p.ProductID = s.ProductID
WHERE p.DaysToManufacture > 2
	AND p.ListPrice > 1350
	AND	p.StandardCost > 750
OPTION (MAXDOP 1)


--show some statistics metadata
SELECT ss.name, ss.auto_created, cl.name
FROM sys.stats ss
	JOIN sys.stats_columns sc ON ss.[object_id] = sc.[object_id] AND ss.stats_id = sc.stats_id
	JOIN sys.columns cl ON ss.[object_id] = cl.[object_id] AND sc.column_id = cl.column_id
WHERE ss.[object_id] = object_id('Production.Product')
ORDER BY ss.stats_id


--a query that has a larger plan
SELECT	pp.FirstName,
		sc.AccountNumber,
		soh.PurchaseOrderNumber,
		st.[Group],
		sod.OrderQty,
		prd.Name,
		pc.Name,
		ums.Name,
		umw.Name,
		pa.AddressLine1
FROM Sales.Customer sc
	JOIN Person.Person pp ON sc.CustomerID = pp.BusinessEntityID
	JOIN Sales.SalesOrderHeader soh ON sc.CustomerID = soh.CustomerID
	JOIN sales.SalesTerritory st ON soh.TerritoryID = st.TerritoryID
	JOIN Sales.SalesOrderDetail sod ON soh.SalesOrderID = sod.SalesOrderID
	JOIN Production.Product prd ON sod.ProductID = prd.ProductID
	JOIN Production.ProductSubcategory psc ON prd.ProductSubcategoryID = psc.ProductSubcategoryID
	JOIN Production.ProductCategory pc ON psc.ProductCategoryID = pc.ProductCategoryID
	JOIN Production.UnitMeasure ums ON prd.SizeUnitMeasureCode = ums.UnitMeasureCode
	JOIN Production.UnitMeasure umw ON prd.WeightUnitMeasureCode = umw.UnitMeasureCode
	JOIN Person.[Address] pa ON soh.ShipToAddressID = pa.AddressID
WHERE sc.CustomerID = 15048
