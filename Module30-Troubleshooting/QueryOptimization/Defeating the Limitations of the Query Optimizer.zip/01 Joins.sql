
USE Demo
GO

SET STATISTICS TIME ON
SET STATISTICS IO ON

-- Query 1
SELECT T1.customerName, R.ContactID, R.AggResults
, D.surveyId, D.questionNbr, D.rating, D.verbatim 
FROM
(
SELECT Tab1.customerID, Tab1.customerName, Tab1.StoreOrderTotal, Tab1.InternetOrderTotal
, Tab1.TotalOrders, Tab2.InternetQuoteTotal, Tab2.StoreQuoteTotal, Tab2.TotalQuote
 FROM
(
      SELECT A.customerID, a.customerName, a.orderTotal as InternetOrderTotal, b.orderTotal as StoreOrderTotal,
            TotalOrders = a.orderTotal + b.orderTotal 
      FROM
      (
      SELECT c.customerID, c.customerName,
            SUM(i.orderTotal)as orderTotal
      FROM dbo.Customers c JOIN dbo.InternetOrders i ON c.customerID = i.customerID
      WHERE i.orderDate BETWEEN'2010-01-01'and'2010-12-31 23:59:59.999'
      GROUP BY c.customerID, c.customerName
      HAVING SUM(i.orderTotal)> 10000.00
      ) A
      JOIN
      (
      SELECT c.customerID, c.customerName,
            SUM(s.orderTotal)as orderTotal
      FROM dbo.Customers c JOIN dbo.StoreOrders s ON c.customerID = s.customerID
      WHERE s.orderDate BETWEEN'2010-01-01'and'2010-12-31 23:59:59.999'
      GROUP BY c.customerID, c.customerName
      HAVING SUM(s.orderTotal)> 10000.00
      ) B on A.customerID = B.customerID
      WHERE a.orderTotal + b.orderTotal > 100000.00
) Tab1 JOIN
(
      SELECT A.customerID, a.customerName, a.quoteTotal as InternetQuoteTotal, b.quoteTotal as StoreQuoteTotal,
            TotalQuote = a.quoteTotal + b.quoteTotal 
      FROM
      (
      SELECT c.customerID, c.customerName,
            SUM(i.quoteTotal)as quoteTotal
      FROM dbo.Customers c JOIN dbo.InternetQuotes i ON c.customerID = i.customerID
      WHERE i.quoteDate BETWEEN'2010-01-01'and'2010-12-31 23:59:59.999'
      GROUP BY c.customerID, c.customerName
      HAVING SUM(i.quoteTotal)> 10000.00
      ) A
      JOIN
      (
      SELECT c.customerID, c.customerName,
            SUM(s.quoteTotal)as quoteTotal
      FROM dbo.Customers c JOIN dbo.StoreQuotes s ON c.customerID = s.customerID
      WHERE s.quoteDate BETWEEN'2010-01-01'and'2010-12-31 23:59:59.999'
      GROUP BY c.customerID, c.customerName
      HAVING SUM(s.quoteTotal)> 10000.00
      ) B on A.customerID = B.customerID
      WHERE a.quoteTotal + b.quoteTotal > 100000.00
) Tab2 ON Tab1.customerID = Tab2.customerID
) T1 JOIN
(
SELECT Tab1.customerID, Tab1.customerName, Tab1.StoreOrderTotal, Tab1.InternetOrderTotal
, Tab1.TotalOrders, Tab2.InternetQuoteTotal, Tab2.StoreQuoteTotal, Tab2.TotalQuote
 FROM
(
      SELECT A.customerID, a.customerName, a.orderTotal as InternetOrderTotal, b.orderTotal as StoreOrderTotal,
            TotalOrders = a.orderTotal + b.orderTotal 
      FROM
      (
      SELECT c.customerID, c.customerName,
            SUM(i.orderTotal)as orderTotal
      FROM dbo.Customers c JOIN dbo.TransactionType3 i ON c.customerID = i.customerID
      WHERE i.orderDate BETWEEN'2010-01-01'and'2010-12-31 23:59:59.999'
      GROUP BY c.customerID, c.customerName
      HAVING SUM(i.orderTotal)> 10000.00
      ) A
      JOIN
      (
      SELECT c.customerID, c.customerName,
            SUM(s.orderTotal)as orderTotal
      FROM dbo.Customers c JOIN dbo.TransactionType4 s ON c.customerID = s.customerID
      WHERE s.orderDate BETWEEN'2010-01-01'and'2010-12-31 23:59:59.999'
      GROUP BY c.customerID, c.customerName
      HAVING SUM(s.orderTotal)> 10000.00
      ) B on A.customerID = B.customerID
      WHERE a.orderTotal + b.orderTotal > 100000.00
) Tab1 JOIN
(
      SELECT A.customerID, a.customerName, a.quoteTotal as InternetQuoteTotal, b.quoteTotal as StoreQuoteTotal,
            TotalQuote = a.quoteTotal + b.quoteTotal 
      FROM
      (
      SELECT c.customerID, c.customerName,
            SUM(i.orderTotal)as quoteTotal
      FROM dbo.Customers c JOIN dbo.TransactionType5 i ON c.customerID = i.customerID
      WHERE i.orderDate BETWEEN'2010-01-01'and'2010-12-31 23:59:59.999'
      GROUP BY c.customerID, c.customerName
      HAVING SUM(i.orderTotal)> 10000.00
      ) A
      JOIN
      (
      SELECT c.customerID, c.customerName,
            SUM(s.orderTotal)as quoteTotal
      FROM dbo.Customers c JOIN dbo.TransactionType6 s ON c.customerID = s.customerID
      WHERE s.orderDate BETWEEN'2010-01-01'and'2010-12-31 23:59:59.999'
      GROUP BY c.customerID, c.customerName
      HAVING SUM(s.orderTotal)> 10000.00
      ) B on A.customerID = B.customerID
      WHERE a.quoteTotal + b.quoteTotal > 100000.00
) Tab2 ON Tab1.customerID = Tab2.customerID
) T2 ON T1.customerID = T2.customerID
LEFT OUTER JOIN dbo.SurveyResults R on T1.customerID = R.customerID
LEFT OUTER JOIN dbo.SurveyDetails D on T1.customerID = D.customerID
WHERE T1.TotalOrders > 10000.00 AND T2.TotalQuote > 100000.00

-- Query 2
SELECT T1.customerID, T1.customerName 
INTO #temp
FROM
(
SELECT Tab1.customerID, Tab1.customerName, Tab1.StoreOrderTotal, Tab1.InternetOrderTotal
, Tab1.TotalOrders, Tab2.InternetQuoteTotal, Tab2.StoreQuoteTotal, Tab2.TotalQuote
 FROM
(
      SELECT A.customerID, a.customerName, a.orderTotal as InternetOrderTotal, b.orderTotal as StoreOrderTotal,
            TotalOrders = a.orderTotal + b.orderTotal 
      FROM
      (
      SELECT c.customerID, c.customerName,
            SUM(i.orderTotal)as orderTotal
      FROM dbo.Customers c JOIN dbo.InternetOrders i ON c.customerID = i.customerID
      WHERE i.orderDate BETWEEN'2010-01-01'and'2010-12-31 23:59:59.999'
      GROUP BY c.customerID, c.customerName
      HAVING SUM(i.orderTotal)> 10000.00
      ) A
      JOIN
      (
      SELECT c.customerID, c.customerName,
            SUM(s.orderTotal)as orderTotal
      FROM dbo.Customers c JOIN dbo.StoreOrders s ON c.customerID = s.customerID
      WHERE s.orderDate BETWEEN'2010-01-01'and'2010-12-31 23:59:59.999'
      GROUP BY c.customerID, c.customerName
      HAVING SUM(s.orderTotal)> 10000.00
      ) B on A.customerID = B.customerID
      WHERE a.orderTotal + b.orderTotal > 100000.00
) Tab1 JOIN
(
      SELECT A.customerID, a.customerName, a.quoteTotal as InternetQuoteTotal, b.quoteTotal as StoreQuoteTotal,
            TotalQuote = a.quoteTotal + b.quoteTotal 
      FROM
      (
      SELECT c.customerID, c.customerName,
            SUM(i.quoteTotal)as quoteTotal
      FROM dbo.Customers c JOIN dbo.InternetQuotes i ON c.customerID = i.customerID
      WHERE i.quoteDate BETWEEN'2010-01-01'and'2010-12-31 23:59:59.999'
      GROUP BY c.customerID, c.customerName
      HAVING SUM(i.quoteTotal)> 10000.00
      ) A
      JOIN
      (
      SELECT c.customerID, c.customerName,
            SUM(s.quoteTotal)as quoteTotal
      FROM dbo.Customers c JOIN dbo.StoreQuotes s ON c.customerID = s.customerID
      WHERE s.quoteDate BETWEEN'2010-01-01'and'2010-12-31 23:59:59.999'
      GROUP BY c.customerID, c.customerName
      HAVING SUM(s.quoteTotal)> 10000.00
      ) B on A.customerID = B.customerID
      WHERE a.quoteTotal + b.quoteTotal > 100000.00
) Tab2 ON Tab1.customerID = Tab2.customerID
) T1 JOIN
(
SELECT Tab1.customerID, Tab1.customerName, Tab1.StoreOrderTotal, Tab1.InternetOrderTotal
, Tab1.TotalOrders, Tab2.InternetQuoteTotal, Tab2.StoreQuoteTotal, Tab2.TotalQuote
 FROM
(
      SELECT A.customerID, a.customerName, a.orderTotal as InternetOrderTotal, b.orderTotal as StoreOrderTotal,
            TotalOrders = a.orderTotal + b.orderTotal 
      FROM
      (
      SELECT c.customerID, c.customerName,
            SUM(i.orderTotal)as orderTotal
      FROM dbo.Customers c JOIN dbo.TransactionType3 i ON c.customerID = i.customerID
      WHERE i.orderDate BETWEEN'2010-01-01'and'2010-12-31 23:59:59.999'
      GROUP BY c.customerID, c.customerName
      HAVING SUM(i.orderTotal)> 10000.00
      ) A
      JOIN
      (
      SELECT c.customerID, c.customerName,
            SUM(s.orderTotal)as orderTotal
      FROM dbo.Customers c JOIN dbo.TransactionType4 s ON c.customerID = s.customerID
      WHERE s.orderDate BETWEEN'2010-01-01'and'2010-12-31 23:59:59.999'
      GROUP BY c.customerID, c.customerName
      HAVING SUM(s.orderTotal)> 10000.00
      ) B on A.customerID = B.customerID
      WHERE a.orderTotal + b.orderTotal > 100000.00
) Tab1 JOIN
(
      SELECT A.customerID, a.customerName, a.quoteTotal as InternetQuoteTotal, b.quoteTotal as StoreQuoteTotal,
            TotalQuote = a.quoteTotal + b.quoteTotal 
      FROM
      (
      SELECT c.customerID, c.customerName,
            SUM(i.orderTotal)as quoteTotal
      FROM dbo.Customers c JOIN dbo.TransactionType5 i ON c.customerID = i.customerID
      WHERE i.orderDate BETWEEN'2010-01-01'and'2010-12-31 23:59:59.999'
      GROUP BY c.customerID, c.customerName
      HAVING SUM(i.orderTotal)> 10000.00
      ) A
      JOIN
      (
      SELECT c.customerID, c.customerName,
            SUM(s.orderTotal)as quoteTotal
      FROM dbo.Customers c JOIN dbo.TransactionType6 s ON c.customerID = s.customerID
      WHERE s.orderDate BETWEEN'2010-01-01'and'2010-12-31 23:59:59.999'
      GROUP BY c.customerID, c.customerName
      HAVING SUM(s.orderTotal)> 10000.00
      ) B on A.customerID = B.customerID
      WHERE a.quoteTotal + b.quoteTotal > 100000.00
) Tab2 ON Tab1.customerID = Tab2.customerID
) T2 ON T1.customerID = T2.customerID
WHERE T1.TotalOrders > 10000.00 AND T2.TotalQuote > 100000.00
 
 
SELECT T1.customerName, R.ContactID, R.AggResults, D.surveyId, d.QuestionNbr, D.Rating, D.verbatim FROM #temp T1
LEFT OUTER JOIN dbo.SurveyResults R on T1.customerID = R.customerID
LEFT OUTER JOIN dbo.SurveyDetails D on T1.customerID = D.customerID
 
drop table #temp      

-- index

CREATE NONCLUSTERED INDEX IX_customerID
ON [dbo].[SurveyDetails] ([customerID])
INCLUDE ([surveyID],[questionNbr],[rating],[verbatim])

DROP INDEX [SurveyDetails].IX_customerID


