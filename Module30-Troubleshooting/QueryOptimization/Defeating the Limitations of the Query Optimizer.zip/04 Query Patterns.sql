
-- query patterns demo

-- WHERE a.col1 = @val1 OR a.col1 = @val2 example
-- or WHERE col1 IN (@val1, @val2)

USE Demo
GO

SET STATISTICS IO ON

SELECT e.* FROM dbo.Employee e
WHERE EmployeeId = 10 OR EmployeeId = 107619 OR EmployeeId = 178278

SELECT e.* FROM dbo.Employee e
WHERE EmployeeId IN (10, 107619, 178278)

-- Scan count 3

-- WHERE a.col1 = @val1 OR a.col2 = @val2 example

SELECT e.* FROM dbo.Employee e
WHERE EmployeeId = 10 OR ManagerId = 2


-- WHERE a.col1 = @val1 OR a.col2 IN (SELECT col2 FROM tab2)

CREATE INDEX IX_Title ON dbo.Employee(Title)

SELECT e.* FROM dbo.Employee e
WHERE EmployeeId = 10 OR ManagerId IN (SELECT EmployeeId FROM dbo.Employee e WHERE Title = 'Big Boss')

DROP INDEX dbo.Employee.IX_Title

-- problem
-- WHERE a.col1 = @val1 OR b.col2 = @val2

SELECT e.* FROM dbo.Employee e
LEFT JOIN Adventureworks.Person.Contact c ON e.EmployeeId = c.ContactID
WHERE EmployeeId = 6 OR c.EmailAddress = 'sabria0@adventure-works.com'

-- solution

SELECT e.* FROM dbo.Employee e
LEFT JOIN Adventureworks.Person.Contact c ON e.EmployeeId = c.ContactID
WHERE EmployeeId = 6
UNION
SELECT e.* FROM dbo.Employee e
LEFT JOIN Adventureworks.Person.Contact c ON e.EmployeeId = c.ContactID
WHERE c.EmailAddress = 'sabria0@adventure-works.com'

