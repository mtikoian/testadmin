
-- cardinality estimationmathematical model assumptions
-- uniformity assumption

USE AdventureWorks
GO

DROP PROCEDURE test
GO

CREATE PROCEDURE test (@pid int)
AS
SELECT * FROM Sales.SalesOrderDetail
WHERE ProductID = @pid

DBCC FREEPROCCACHE

-- uses histogram
EXEC test @pid = 831

DBCC SHOW_STATISTICS('Sales.SalesOrderDetail', IX_SalesOrderDetail_ProductID)


ALTER PROCEDURE test (@pid int)
AS
DECLARE @p int = @pid
SELECT * FROM Sales.SalesOrderDetail
WHERE ProductID = @p

-- not able to use histogram
DBCC FREEPROCCACHE
EXEC test @pid = 831
EXEC test @pid = 0

DBCC SHOW_STATISTICS('Sales.SalesOrderDetail', IX_SalesOrderDetail_ProductID)

-- density shows 456.079
SELECT 121317 * 0.003759399 
-- total rows * density where
-- density is 1 / number of distinct values

-- range rows histogram step
DBCC FREEPROCCACHE
EXEC test @pid = 827
EXEC test @pid = 828
-- no records exist!
EXEC test @pid = 829

DBCC SHOW_STATISTICS('Sales.SalesOrderDetail', IX_SalesOrderDetail_ProductID)













