
-- hints

USE AdventureWorks
GO

CREATE PROCEDURE test (@pid int)
AS
SELECT * FROM Sales.SalesOrderDetail
WHERE ProductID = @pid

-- goal-oriented
ALTER PROCEDURE test (@pid int)
AS
SELECT * FROM Sales.SalesOrderDetail
WHERE ProductID = @pid
OPTION (OPTIMIZE FOR (@pid = 898))

EXEC test @pid = 870

-- physical operator hints
SELECT FirstName, LastName
FROM Person.Contact AS C, Sales.Individual AS I, Sales.Customer AS Cu
WHERE I.CustomerID = Cu.CustomerID
AND C.ContactID = I.ContactID
AND Cu.CustomerType = 'I'
OPTION (FORCE ORDER)

