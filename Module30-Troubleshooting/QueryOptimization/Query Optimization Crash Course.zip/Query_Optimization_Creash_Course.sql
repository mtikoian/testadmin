/*
	Ed Pollack
	Last Modified: 4/30/2013
	Query Optimization Crash Course
*/

USE AdventureWorks
GO

SET STATISTICS IO ON
SET STATISTICS TIME ON

/******************************************* COMPLEX JOINS **************************************************
	Beware an OR in any JOIN!  It is often more efficient to create separate SELECTs and put them together
	than to try and do everything in a single statement.  An AND is typically exclusive, restricting and 
	reducing the size of a rowset, whereas an OR will often add to a data set. An OR is not ALWAYS bad,
	but can certainly be the cause of slow queries if its usage was not well thought out. */
SELECT DISTINCT
	PRODUCT.ProductID,
	PRODUCT.Name
FROM Production.Product PRODUCT
INNER JOIN Sales.SalesOrderDetail DETAIL
ON PRODUCT.ProductID = DETAIL.ProductID
OR PRODUCT.rowguid = DETAIL.rowguid

SELECT
	PRODUCT.ProductID,
	PRODUCT.Name
FROM Production.Product PRODUCT
INNER JOIN Sales.SalesOrderDetail DETAIL
ON PRODUCT.ProductID = DETAIL.ProductID
UNION
SELECT
	PRODUCT.ProductID,
	PRODUCT.Name
FROM Production.Product PRODUCT
INNER JOIN Sales.SalesOrderDetail DETAIL
ON PRODUCT.rowguid = DETAIL.rowguid
/************************************** FUNCTION USAGE ON COLUMNS *********************************************
	Never apply functions or complex transforms to the column in a JOIN or WHERE clause.  If SQL Server
	is unable to quickly resolve the function, you will end up with a table scan as it applies it to every row.
	This example uses a custom function that removes non-digits from a string to search for a phone number. */
SELECT
	PERSON.FirstName,
	PERSON.LastName,
	PHONE.PhoneNumber,
	PERSON.BusinessEntityID
FROM Person.PersonPhone PHONE
INNER JOIN Person.Person PERSON
ON PERSON.BusinessEntityID = PHONE.BusinessEntityID
WHERE dbo.fnStripNonDigits(PHONE.PhoneNumber) = '1815550156'

-- One quick fix is to simply force the application to search for a phone number explicitly, without removing
-- non-digits first
SELECT
	PERSON.FirstName,
	PERSON.LastName,
	PHONE.PhoneNumber,
	PERSON.BusinessEntityID
FROM Person.PersonPhone PHONE
INNER JOIN Person.Person PERSON
ON PERSON.BusinessEntityID = PHONE.BusinessEntityID
WHERE PHONE.PhoneNumber = '1815550156'

-- If this is unacceptable, a more complex solution would be to create & populate an additional column
-- that will hold a clean version of the phone number (remember to index it!)

/*
	ALTER TABLE Person.PersonPhone
	ADD PhoneNumberClean NVARCHAR(25)
	
	UPDATE Person.PersonPhone
	SET PhoneNumberClean = dbo.fnStripNonDigits(PhoneNumber)

	CREATE INDEX NCI_PersonPhone_PhoneNumberClean ON Person.PersonPhone
	( PhoneNumberClean ASC )
*/

SELECT
	PERSON.FirstName,
	PERSON.LastName,
	PHONE.PhoneNumber,
	PERSON.BusinessEntityID
FROM Person.PersonPhone PHONE
INNER JOIN Person.Person PERSON
ON PERSON.BusinessEntityID = PHONE.BusinessEntityID
WHERE PHONE.PhoneNumberClean = dbo.fnStripNonDigits('181-555-0156')

/*
	DROP INDEX NCI_PersonPhone_PhoneNumberClean ON Person.PersonPhone

	ALTER TABLE Person.PersonPhone
	DROP COLUMN PhoneNumberClean
	
	UPDATE Person.PersonPhone
	SET PhoneNumber = dbo.fnStripNonDigits(PhoneNumber)
*/

-- A simple example would be to maintain the phone number with only digits in the database, that way we
-- can apply the function to only the scalar input, and not the entire table.  You can possible maintain
-- a phone # format that can be applied later, if needed.
SELECT
	PERSON.FirstName,
	PERSON.LastName,
	PHONE.PhoneNumber,
	PERSON.BusinessEntityID
FROM Person.PersonPhone PHONE
INNER JOIN Person.Person PERSON
ON PERSON.BusinessEntityID = PHONE.BusinessEntityID
WHERE PHONE.PhoneNumber = dbo.fnStripNonDigits('181-555-0156')

/************************************** IMPLICIT CONVERSIONS *********************************************
	Joining or comparing two different data types will force SQL Server to convert the "lower" of the two
	types to match the other.  This will result in an implicit conversion that will cause unnecessary
	index scans.  To fix this, make sure that you change the type of the scalar value to match that of the 
	column. */

SELECT
	EMP.BusinessEntityID,
	EMP.LoginID,
	EMP.JobTitle
FROM HumanResources.Employee EMP
WHERE EMP.NationalIDNumber = 658797903

SELECT
	EMP.BusinessEntityID,
	EMP.LoginID,
	EMP.JobTitle
FROM HumanResources.Employee EMP
WHERE EMP.NationalIDNumber = '658797903'

/************************************** ITERATION vs. SET-BASED OPERATIONS *******************************
	SQL Server operates most efficiently with set-based queries.  Loops and iteration will seem to execute
	fast for each row, but add up the costs associated with many iterations, and it can be prohibitively
	expensive.  This example shows a simple task of increasing vacation hours for 100 employees.  The cost
	for the iterative solution is about 50 times higher. */
	
DECLARE @id INT = (SELECT MIN(BusinessEntityID) FROM HumanResources.Employee)
WHILE @id <= 100
BEGIN
	UPDATE HumanResources.Employee
		SET VacationHours = VacationHours + 4
	WHERE BusinessEntityID = @id
	AND VacationHours < 200
	
	SET @id = @id + 1
END

UPDATE HumanResources.Employee
SET VacationHours = VacationHours + 4
WHERE VacationHours < 200
AND BusinessEntityID <= 100

/* Use a CTE to efficiently compare on row numbers and avoid iteration or other inefficient approach */
SELECT -- This SELECT ranks rows in DatabaseLog for a given Schema/Object and orders by Schema/Object/PostTime
	ROW_NUMBER() OVER (PARTITION BY [Schema], Object ORDER BY [Schema], Object, PostTime),
	[Schema],
	Object,
	PostTime
FROM dbo.DatabaseLog DL
-- Note to Microsoft - never name columns after SQL Server reserved words (Object/Schema)!

-- If we wanted to get the first change for each schema/object, intuitively you would try this:
SELECT
	ROW_NUMBER() OVER (PARTITION BY [Schema], Object ORDER BY [Schema], Object, PostTime),
	[Schema],
	Object,
	PostTime
FROM dbo.DatabaseLog DL
WHERE (ROW_NUMBER() OVER (PARTITION BY [Schema], Object ORDER BY [Schema], Object, PostTime) = 1)
-- ...but SQL Server says: Windowed functions can only appear in the SELECT or ORDER BY clauses.

-- A CTE can allow you to utilize row counts and other derived data in your joins or where clauses.
;WITH CTE_DATABASE_LOG AS
(	SELECT
		ROW_NUMBER() OVER (PARTITION BY [Schema], Object ORDER BY [Schema], Object, PostTime) AS row_id,
		[Schema] AS dl_schema,
		Object AS dl_object,
		PostTime AS post_time
	FROM dbo.DatabaseLog DL   )
SELECT
	*
FROM CTE_DATABASE_LOG
WHERE row_id = 1

/* Quick example of using OUTPUT INSERTED to capture inserted data without resorting to row-by-row
   operations using the SCOPE_IDENTITY() (SQL Server 2005 and later)  */

DECLARE @temp_products TABLE
(productID INT, Name NVARCHAR(50))

INSERT INTO Production.Product
  ( Name ,
	ProductNumber ,
	MakeFlag ,
	FinishedGoodsFlag ,
	Color ,
	SafetyStockLevel ,
	ReorderPoint ,
	StandardCost ,
	ListPrice ,
	Size ,
	SizeUnitMeasureCode ,
	WeightUnitMeasureCode ,
	Weight ,
	DaysToManufacture ,
	ProductLine ,
	Class ,
	Style ,
	ProductSubcategoryID ,
	ProductModelID ,
	SellStartDate ,
	SellEndDate ,
	DiscontinuedDate ,
	rowguid ,
	ModifiedDate)
OUTPUT INSERTED.ProductID, INSERTED.Name
INTO @temp_products
SELECT 
	Name + 'New',
	ProductNumber + '-N',
	MakeFlag ,
	FinishedGoodsFlag ,
	Color ,
	SafetyStockLevel ,
	ReorderPoint ,
	StandardCost ,
	ListPrice ,
	Size ,
	SizeUnitMeasureCode ,
	WeightUnitMeasureCode ,
	Weight ,
	DaysToManufacture ,
	ProductLine ,
	Class ,
	Style ,
	ProductSubcategoryID ,
	ProductModelID ,
	SellStartDate ,
	SellEndDate ,
	DiscontinuedDate ,
	(SELECT NEWID()) ,
	ModifiedDate
FROM Production.Product
WHERE MakeFlag = 1
AND ListPrice > 2000
   
SELECT
	*
FROM @temp_products

/************************************** Encapsulation *****************************************************
	SQL Server is very good at simplifying & optimizing queries to remove unnecessary joins, unneeded data,
	and encapsulation, but it is not perfect.  This simple example compares 2 identical queries: One that
	selects 4 columns from a view with 9 tables, and then the same query rewritten using just the tables
	required.  Keep in mind that rewriting code may potentially create additional maintenance. */
	
SELECT
	BusinessEntityID,
	Title,
	FirstName,
	LastName
FROM HumanResources.vEmployee
WHERE FirstName LIKE 'E%'
	
SELECT 
    e.BusinessEntityID,
    p.Title,
    p.FirstName,
    p.LastName
FROM HumanResources.Employee e
INNER JOIN Person.Person p
ON p.BusinessEntityID = e.BusinessEntityID
WHERE FirstName LIKE 'E%'

/************************************** Temporary Data Storage *******************************************
	This example takes a query and utilizes table variables, temp tables, and direct operations to
	illustrate the benefits and drawbacks of each method.  Always weigh the pros and cons of using any of
	these methods and test thoroughly before implementing! */
----------------------------------------
-- Temp table w/ CREATE
----------------------------------------
CREATE TABLE #EntityData
(	BusinessEntityID INT,
	Name NVARCHAR(150),
	ModifiedDate DATETIME,
	EntityType NVARCHAR(6) )

INSERT INTO #EntityData -- 0.18727 est. subtree cost (58% table insert #EntityData)
(BusinessEntityID, Name, ModifiedDate, EntityType)
SELECT
	BusinessEntityID,
	Name,
	ModifiedDate,
	'Store' AS EntityType
FROM Sales.Store
WHERE ModifiedDate > '1/1/2006'

INSERT INTO #EntityData -- 0.0217371 est. subtree cost (80.6% table insert #EntityData)
(BusinessEntityID, Name, ModifiedDate, EntityType)
SELECT
	BusinessEntityID,
	Name,
	ModifiedDate,
	'Vendor' AS EntityType
FROM Purchasing.Vendor
WHERE ModifiedDate > '1/1/2006'

INSERT INTO #EntityData -- 5.58932 est. subtree cost (48.8% table insert #EntityData)
(BusinessEntityID, Name, ModifiedDate, EntityType)
SELECT
	BusinessEntityID,
	FirstName + ' ' + MiddleName + ' ' + LastName AS NAME,
	ModifiedDate,
	'Person' AS EntityType
FROM Person.Person
WHERE ModifiedDate > '1/1/2006'

SELECT -- 0.636748 est. subtree cost
	ModifiedDate,
	EntityType,
	COUNT(*) AS EntityCount,
	MAX(BusinessEntityID) AS MaxBusinessEntityID,
	MIN(Name) AS MinName
FROM #EntityData
GROUP BY ModifiedDate, EntityType
-- Total: 6.4350751 est. subtree cost

DROP TABLE #EntityData

----------------------------------------
-- Temp table w/ SELECT INTO & UNION ALL
----------------------------------------
SELECT -- 5.77804  est. subtree cost (49% table insert #EntityData)
	BusinessEntityID,
	Name,
	ModifiedDate,
	'Store' AS EntityType
INTO #EntityData
FROM Sales.Store
WHERE ModifiedDate > '1/1/2006'
UNION ALL
SELECT
	BusinessEntityID,
	Name,
	ModifiedDate,
	'Vendor' AS EntityType
FROM Purchasing.Vendor
WHERE ModifiedDate > '1/1/2006'
UNION ALL
SELECT
	BusinessEntityID,
	FirstName + ' ' + MiddleName + ' ' + LastName AS NAME,
	ModifiedDate,
	'Person' AS EntityType
FROM Person.Person
WHERE ModifiedDate > '1/1/2006'

SELECT -- 0.626377 est. subtree cost
	ModifiedDate,
	EntityType,
	COUNT(*) AS EntityCount,
	MAX(BusinessEntityID) AS MaxBusinessEntityID,
	MIN(Name) AS MinName
FROM #EntityData
GROUP BY ModifiedDate, EntityType
-- Total: 6.404417 est. subtree cost

DROP TABLE #EntityData
----------------------------------------
-- Table variable
----------------------------------------
DECLARE @EntityData TABLE
(	BusinessEntityID INT,
	Name NVARCHAR(150),
	ModifiedDate DATETIME,
	EntityType NVARCHAR(6) )

INSERT INTO @EntityData -- 5.79555  est. subtree cost (49% table insert @EntityData)
(BusinessEntityID, Name, ModifiedDate, EntityType)
SELECT
	BusinessEntityID,
	Name,
	ModifiedDate,
	'Store' AS EntityType
FROM Sales.Store
WHERE ModifiedDate > '1/1/2006'
UNION ALL
SELECT
	BusinessEntityID,
	Name,
	ModifiedDate,
	'Vendor' AS EntityType
FROM Purchasing.Vendor
WHERE ModifiedDate > '1/1/2006'
UNION ALL
SELECT
	BusinessEntityID,
	FirstName + ' ' + MiddleName + ' ' + LastName AS NAME,
	ModifiedDate,
	'Person' AS EntityType
FROM Person.Person
WHERE ModifiedDate > '1/1/2006'

SELECT -- 0.0146456
	ModifiedDate,
	EntityType,
	COUNT(*) AS EntityCount,
	MAX(BusinessEntityID) AS MaxBusinessEntityID,
	MIN(Name) AS MinName
FROM @EntityData
GROUP BY ModifiedDate, EntityType
-- Total: 5.8101956 est. subtree cost

----------------------------------------
-- No temp storage at all
----------------------------------------
;WITH CTE_ENTITYDATA AS (
	SELECT
		BusinessEntityID,
		Name,
		ModifiedDate,
		'Store' AS EntityType
	FROM Sales.Store
	WHERE ModifiedDate > '1/1/2006'
	UNION ALL
	SELECT
		BusinessEntityID,
		Name,
		ModifiedDate,
		'Vendor' AS EntityType
	FROM Purchasing.Vendor
	WHERE ModifiedDate > '1/1/2006'
	UNION ALL
	SELECT
		BusinessEntityID,
		FirstName + ' ' + MiddleName + ' ' + LastName AS NAME,
		ModifiedDate,
		'Person' AS EntityType
	FROM Person.Person
	WHERE ModifiedDate > '1/1/2006')
SELECT -- 0.0146456
	ModifiedDate,
	EntityType,
	COUNT(*) AS EntityCount,
	MAX(BusinessEntityID) AS MaxBusinessEntityID,
	MIN(Name) AS MinName
FROM CTE_ENTITYDATA
GROUP BY ModifiedDate, EntityType
-- Total: 3.25565 est. subtree cost

/************************************** Finding Missing Indexes *******************************************
	This query will return a list of indexes generated from the missing index DMVs with an improvement
	measure of at least 10%.  As always, beware of indexes that may not cover frequent queries, those
	that are unnecessarily wide, or those that are on tables that are write-intensive.  Included here are
	very important pieces of information, such as the index create statement, DB & Table names, and the
	# of columns involved in the potential index. */

SELECT	ROW_NUMBER() OVER (ORDER BY MIGS.avg_user_impact) AS id,
		MIGS.avg_total_user_cost * ( MIGS.avg_user_impact / 100.0 )
        * ( MIGS.user_seeks + MIGS.user_scans ) AS [Improvement Measure],
        'CREATE INDEX [missing_index_'
        + CONVERT (VARCHAR, MIG.index_group_handle) + '_'
        + CONVERT (VARCHAR, MID.index_handle) + '_'
        + LEFT(PARSENAME(MID.statement, 1), 32) + ']' + ' ON ' + MID.statement
        + ' (' + ISNULL(MID.equality_columns, '')
        + CASE WHEN MID.equality_columns IS NOT NULL
                    AND MID.inequality_columns IS NOT NULL THEN ','
               ELSE ''
          END + ISNULL(MID.inequality_columns, '') + ')' + ISNULL(' INCLUDE ('
                                                              + MID.included_columns
                                                              + ')', '') AS [Index Create Statement],
        MIGS.unique_compiles AS [Benefiting Compiles],
        MIGS.user_seeks AS [User Seeks],
        MIGS.last_user_seek AS [Last User Seek],
        MIGS.avg_total_user_cost AS [Average Total User Cost],
        MIGS.avg_user_impact AS [Average User Impact],
        SD.name AS [Database Name],
        REVERSE(SUBSTRING(REVERSE(MID.statement), 2, (CHARINDEX('[', REVERSE(MID.statement), 2)) - 2)) AS [Table Name],
        ISNULL((LEN(MID.equality_columns) -  LEN(REPLACE(REPLACE(MID.equality_columns, '[', ''), ']', ''))) / 2, 0) AS equality_column_number,
        ISNULL((LEN(MID.inequality_columns) -  LEN(REPLACE(REPLACE(MID.inequality_columns, '[', ''), ']', ''))) / 2, 0) AS inequality_column_number,
        ISNULL((LEN(MID.included_columns) -  LEN(REPLACE(REPLACE(MID.included_columns, '[', ''), ']', ''))) / 2, 0) AS included_column_number   
FROM    sys.dm_db_missing_index_groups MIG
        INNER JOIN sys.dm_db_missing_index_group_stats MIGS
        ON migs.group_handle = MIG.index_group_handle
        INNER JOIN sys.dm_db_missing_index_details MID
        ON MIG.index_handle = MID.index_handle
        INNER JOIN sys.databases SD
        ON SD.database_id = MID.database_id
WHERE   MIGS.avg_total_user_cost * ( MIGS.avg_user_impact / 100.0 )
        * ( MIGS.user_seeks + MIGS.user_scans ) > 10
ORDER BY MIGS.avg_total_user_cost * MIGS.avg_user_impact * ( MIGS.user_seeks + MIGS.user_scans ) DESC

/************************************** Giving SQL Server a Push *******************************************
	There are many little things you can do in a table to increase the efficiency of the query optimizer,
	allowing it to execute queries faster, and to do so with better estimations & statistics along the way.
	Below are a few examples of how these changes can improve performance. */

-- Foreign Keys
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[Person].[FK_Person_BusinessEntity_BusinessEntityID]') AND parent_object_id = OBJECT_ID(N'[Person].[Person]'))
ALTER TABLE [Person].[Person] DROP CONSTRAINT [FK_Person_BusinessEntity_BusinessEntityID]
GO

SELECT
	PERSON.BusinessEntityID,
	PERSON.FirstName,
	PERSON.LastName
FROM Person.Person PERSON
WHERE PERSON.BusinessEntityID IN
(SELECT BusinessEntityID FROM Person.BusinessEntity)

ALTER TABLE [Person].[Person]  WITH CHECK ADD  CONSTRAINT [FK_Person_BusinessEntity_BusinessEntityID] FOREIGN KEY([BusinessEntityID])
REFERENCES [Person].[BusinessEntity] ([BusinessEntityID])
GO

SELECT
	PERSON.BusinessEntityID,
	PERSON.FirstName,
	PERSON.LastName
FROM Person.Person PERSON
WHERE BusinessEntityID IN
(SELECT BusinessEntityID FROM Person.BusinessEntity)

-- Constraints
IF  EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[Person].[CK_Person_EmailPromotion]') AND parent_object_id = OBJECT_ID(N'[Person].[Person]'))
ALTER TABLE [Person].[Person] DROP CONSTRAINT [CK_Person_EmailPromotion]
GO

SELECT
	*
FROM Person.Person
WHERE EmailPromotion = 3

ALTER TABLE [Person].[Person]  WITH CHECK ADD CONSTRAINT [CK_Person_EmailPromotion] CHECK  (([EmailPromotion]>=(0) AND [EmailPromotion]<=(2)))
GO

SELECT
	*
FROM Person.Person
WHERE EmailPromotion = 3

-- Statistics:
-- 0-2 INT column
DBCC SHOW_STATISTICS ("Person.Person", EmailPromotion) WITH HISTOGRAM;
-- NVARCHAR column
DBCC SHOW_STATISTICS ("Person.Person", FirstName) WITH HISTOGRAM;
-- Index on 3 NVARCHAR columns
DBCC SHOW_STATISTICS ("Person.Person", IX_Person_LastName_FirstName_MiddleName) WITH HISTOGRAM;

SET STATISTICS IO OFF
SET STATISTICS TIME OFF