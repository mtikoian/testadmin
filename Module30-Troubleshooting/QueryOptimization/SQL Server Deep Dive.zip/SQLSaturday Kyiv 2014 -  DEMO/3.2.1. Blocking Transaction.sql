BEGIN TRAN
	
UPDATE bigProduct SET ProductNumber = 'BL-2014-1000'
WHERE Name = 'Blade1000'

ROLLBACK

