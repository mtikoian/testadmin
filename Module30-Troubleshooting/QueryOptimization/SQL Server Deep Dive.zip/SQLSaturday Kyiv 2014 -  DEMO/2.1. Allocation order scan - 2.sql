-- Allocation Ordered Scan
SELECT Id INTO #result 
FROM ##temp WITH (NOLOCK);

-- Check Duplicates
SELECT Id, COUNT(*)  FROM #result
GROUP BY Id
HAVING COUNT(*) > 1

-- When Allocation Ordered Scan used?
SELECT * FROM ##temp -- No
SELECT * FROM ##temp WITH (NOLOCK)  -- Yes
SELECT * FROM ##temp WITH (TABLOCK) -- Yes