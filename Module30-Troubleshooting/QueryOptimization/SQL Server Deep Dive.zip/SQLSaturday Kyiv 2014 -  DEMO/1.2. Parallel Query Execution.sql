USE AdventureWorks2012
GO

-- Speaker Notes:
-- 1) Use Estimated Execution Plan

-- Query with constants (3s)
SELECT * FROM bigTransactionHistory
WHERE TransactionDate BETWEEN '01-01-2005' AND '01-01-2006'
GO

-- Query with user-defined scalar function (1m 41s)
SELECT * FROM bigTransactionHistory
WHERE TransactionDate BETWEEN '01-01-2005' AND dbo.GetPreviousDate('01-01-2006')
GO

-- Query with system scalar function
SELECT * FROM bigTransactionHistory
WHERE TransactionDate BETWEEN '01-01-2005' AND DATEADD(D, -1, '01-01-2006')
GO

-- Query without scalar function in SELECT
SELECT '01-01-2006', * FROM bigTransactionHistory
GO

-- Query with scalar function in SELECT
SELECT dbo.GetPreviousDate('01-01-2006'), * FROM bigTransactionHistory
GO

--CREATE FUNCTION dbo.GetPreviousDate(@date datetime)
--RETURNS datetime
--AS
--BEGIN
--	RETURN DATEADD(D, -1, @date);
--END
--GO
