SELECT * FROM [AdventureWorks2012].[dbo].[bigTransactionHistory]
GO
