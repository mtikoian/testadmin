
-- final demo2

USE Test
GO
DROP TABLE TransactionHistoryArchive

-- bucket count recommended is twice the number of keys
-- but let us test some other scenarios

-- just to test behavior test bucket count same as number of keys
CREATE TABLE TransactionHistoryArchive (
TransactionID int NOT NULL PRIMARY KEY NONCLUSTERED HASH WITH
(BUCKET_COUNT = 65536),
ProductID int NOT NULL,
ReferenceOrderID int NOT NULL,
ReferenceOrderLineID int NOT NULL,
TransactionDate datetime NOT NULL,
TransactionType nchar(1) NOT NULL,
Quantity int NOT NULL,
ActualCost money NOT NULL,
ModifiedDate datetime NOT NULL
) WITH (MEMORY_OPTIMIZED = ON)

-- before inserting data
SELECT * FROM sys.dm_db_xtp_hash_index_stats

DROP TABLE #temp
GO
SELECT TOP 65536 * INTO #temp
FROM AdventureWorks2012.Production.TransactionHistoryArchive
GO
-- insert takes less than a second
INSERT INTO TransactionHistoryArchive
SELECT * FROM #temp

-- poisson distribution
-- 1/3 empty buckets
-- 1/3 buckets 1
-- 1/3 buckets 2
SELECT * FROM sys.dm_db_xtp_hash_index_stats

DROP TABLE TransactionHistoryArchive

-- extreme case #1
-- too many buckets
CREATE TABLE TransactionHistoryArchive (
TransactionID int NOT NULL PRIMARY KEY NONCLUSTERED HASH WITH
(BUCKET_COUNT = 10000000),
ProductID int NOT NULL,
ReferenceOrderID int NOT NULL,
ReferenceOrderLineID int NOT NULL,
TransactionDate datetime NOT NULL,
TransactionType nchar(1) NOT NULL,
Quantity int NOT NULL,
ActualCost money NOT NULL,
ModifiedDate datetime NOT NULL
) WITH (MEMORY_OPTIMIZED = ON)

DROP TABLE #temp
GO
SELECT TOP 65536 * INTO #temp
FROM AdventureWorks2012.Production.TransactionHistoryArchive
GO
INSERT INTO TransactionHistoryArchive
SELECT * FROM #temp

-- performance lookups ok
-- performance table scan extremely poor
SELECT * FROM sys.dm_db_xtp_hash_index_stats

DROP TABLE TransactionHistoryArchive

-- extreme case #2
-- too few buckets
CREATE TABLE TransactionHistoryArchive (
TransactionID int NOT NULL PRIMARY KEY NONCLUSTERED HASH WITH
(BUCKET_COUNT = 8),
ProductID int NOT NULL,
ReferenceOrderID int NOT NULL,
ReferenceOrderLineID int NOT NULL,
TransactionDate datetime NOT NULL,
TransactionType nchar(1) NOT NULL,
Quantity int NOT NULL,
ActualCost money NOT NULL,
ModifiedDate datetime NOT NULL
) WITH (MEMORY_OPTIMIZED = ON)

DROP TABLE #temp
GO
SELECT TOP 65536 * INTO #temp
FROM AdventureWorks2012.Production.TransactionHistoryArchive
GO
INSERT INTO TransactionHistoryArchive
SELECT * FROM #temp
-- insert 6-9 seconds!

-- performance lookups and INSERTs extremely poor
SELECT * FROM sys.dm_db_xtp_hash_index_stats

DROP TABLE TransactionHistoryArchive

-- new indexes behavior

-- hash index the best choice for single lookups
CREATE TABLE TransactionHistoryArchive (
TransactionID int NOT NULL PRIMARY KEY NONCLUSTERED HASH WITH
(BUCKET_COUNT = 131072),
ProductID int NOT NULL,
ReferenceOrderID int NOT NULL,
ReferenceOrderLineID int NOT NULL,
TransactionDate datetime NOT NULL,
TransactionType nchar(1) NOT NULL,
Quantity int NOT NULL,
ActualCost money NOT NULL,
ModifiedDate datetime NOT NULL,
INDEX IX_TransactionID NONCLUSTERED (TransactionID)
) WITH (MEMORY_OPTIMIZED = ON)

DROP TABLE #temp
GO
SELECT TOP 65536 * INTO #temp
FROM AdventureWorks2012.Production.TransactionHistoryArchive
GO
INSERT INTO TransactionHistoryArchive
SELECT * FROM #temp

-- hash index is selected
-- query optimizer does not consider bad bucket count value
SELECT * FROM TransactionHistoryArchive
WHERE TransactionID = 8209

DROP TABLE TransactionHistoryArchive

-- testing both kinds of indexes
CREATE TABLE TransactionHistoryArchive (
TransactionID int NOT NULL PRIMARY KEY NONCLUSTERED HASH WITH
(BUCKET_COUNT = 131072),
ProductID int NOT NULL,
ReferenceOrderID int NOT NULL,
ReferenceOrderLineID int NOT NULL,
TransactionDate datetime NOT NULL,
TransactionType nchar(1) NOT NULL,
Quantity int NOT NULL,
ActualCost money NOT NULL,
ModifiedDate datetime NOT NULL,
INDEX IX_ProductID NONCLUSTERED (ProductID)
) WITH (MEMORY_OPTIMIZED = ON)

DROP TABLE #temp
GO
SELECT TOP 65536 * INTO #temp
FROM AdventureWorks2012.Production.TransactionHistoryArchive
GO
INSERT INTO TransactionHistoryArchive
SELECT * FROM #temp

-- uses hash index
-- show storage memoryoptimized
-- show nonclusteredhash
SELECT * FROM TransactionHistoryArchive
WHERE TransactionID = 8209

-- inequality predicates cannot use hash index
-- it requires an index scan
SELECT * FROM TransactionHistoryArchive
WHERE TransactionID > 8209

-- nonclustered index supports both equality ...
SELECT * FROM TransactionHistoryArchive
WHERE ProductID = 780

-- and inequality predicates
SELECT * FROM TransactionHistoryArchive
WHERE ProductID < 780

-- hash index cannot be used to return sorted data
SELECT * FROM TransactionHistoryArchive
ORDER BY TransactionID

-- nonclustered index supports sorted data
SELECT * FROM TransactionHistoryArchive
ORDER BY ProductID

DROP TABLE TransactionHistoryArchive

-- multi-column index
CREATE TABLE TransactionHistoryArchive (
TransactionID int NOT NULL,
ProductID int NOT NULL,
ReferenceOrderID int NOT NULL,
ReferenceOrderLineID int NOT NULL,
TransactionDate datetime NOT NULL,
TransactionType nchar(1) NOT NULL,
Quantity int NOT NULL,
ActualCost money NOT NULL,
ModifiedDate datetime NOT NULL,
CONSTRAINT PK_TransactionID_ProductID PRIMARY KEY NONCLUSTERED
HASH (TransactionID, ProductID) WITH (BUCKET_COUNT = 100000)
) WITH (MEMORY_OPTIMIZED = ON)

-- add data
DROP TABLE #temp
GO
SELECT TOP 65536 * INTO #temp
FROM AdventureWorks2012.Production.TransactionHistoryArchive
GO
INSERT INTO TransactionHistoryArchive
SELECT * FROM #temp

-- index seek can be used
SELECT * FROM TransactionHistoryArchive
WHERE TransactionID = 7173 AND ProductID = 398

-- index scan is the only choice
SELECT * FROM TransactionHistoryArchive
WHERE TransactionID = 7173

