
-- demo 1
-- execution plans

-- graphical plans
SELECT DISTINCT(City) FROM Person.Address

-- xml plan
SET SHOWPLAN_XML ON
GO
SELECT DISTINCT(City) FROM Person.Address
GO
SET SHOWPLAN_XML OFF

SET SHOWPLAN_TEXT ON
GO 
SELECT DISTINCT(City) FROM Person.Address 
GO 
SET SHOWPLAN_TEXT OFF
GO

-- plan properties

-- StatementOptmLevel 

-- StatementOptmEarlyAbortReason or Reason For Early Termination Of Statement Optimization
-- GoodEnoughPlanFound, TimeOut, and MemoryLimitExceeded

-- GoodEnoughPlanFound example
SELECT pm.ProductModelID, pm.Name, Description, pl.CultureID, cl.Name AS Language 
FROM Production.ProductModel AS pm     
JOIN Production.ProductModelProductDescriptionCulture AS pl
ON pm.ProductModelID = pl.ProductModelID     
JOIN Production.Culture AS cl         
ON cl.CultureID = pl.CultureID     
JOIN Production.ProductDescription AS pd         
ON pd.ProductDescriptionID = pl.ProductDescriptionID ORDER BY pm.ProductModelID

-- warnings
-- ColumnsWithNoStatistics

SELECT * FROM sys.stats
WHERE object_id = OBJECT_ID('HumanResources.Employee')

DROP STATISTICS HumanResources.Employee._WA_Sys_00000005_49C3F6B7

ALTER DATABASE AdventureWorks2012 SET AUTO_CREATE_STATISTICS OFF
 
SELECT * FROM HumanResources.Employee WHERE VacationHours = 48

ALTER DATABASE AdventureWorks2012 SET AUTO_CREATE_STATISTICS ON

-- NoJoinPredicate
-- suppose you intend to run the following query but forgot to include the WHERE clause
-- run without the WHERE clause
SELECT * FROM Sales.SalesOrderHeader soh, Sales.SalesOrderDetail sod 
WHERE soh.SalesOrderID = sod.SalesOrderID

-- you cannot accidentally miss a join predicate if you use the ANSI SQL-92 join syntax 
SELECT * FROM Sales.SalesOrderHeader soh JOIN Sales.SalesOrderDetail sod
-- ON soh.SalesOrderID = sod.SalesOrderID

-- PlanAffectingConvert
-- show XML
DECLARE @code nvarchar(15) 
SET @code = '95555Vi4081' 
SELECT * FROM Sales.SalesOrderHeader WHERE CreditCardApprovalCode = @code

-- run with varchar
DECLARE @code varchar(15) 
SET @code = '95555Vi4081' 
SELECT * FROM Sales.SalesOrderHeader WHERE CreditCardApprovalCode = @code


-- SpillToTempDb
-- see the Sort operator

sp_configure 'max server memory (MB)', 2048
RECONFIGURE

SELECT * FROM Sales.SalesOrderDetail ORDER BY UnitPrice

-- SET STATISTICS TIME/IO ON
-- try a new session to avoid other changes
DBCC FREEPROCCACHE

SET STATISTICS TIME ON
SELECT DISTINCT(CustomerID) FROM Sales.SalesOrderHeader

SET STATISTICS TIME OFF

SET STATISTICS IO ON
DBCC DROPCLEANBUFFERS
SELECT * FROM Sales.SalesOrderDetail WHERE ProductID = 870

SET STATISTICS IO OFF

-- live query statistics
SELECT * FROM Sales.SalesOrderDetail s1 CROSS JOIN
Sales.SalesOrderDetail s2


