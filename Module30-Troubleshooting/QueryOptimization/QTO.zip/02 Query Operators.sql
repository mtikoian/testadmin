
-- demo 3
-- query operators

-- table scan
SELECT * FROM DatabaseLog

-- clustered index scan
SELECT * FROM Person.Address

-- index scan
SELECT AddressID, City, StateProvinceID FROM Person.Address

-- index seek
SELECT AddressID, City, StateProvinceID FROM Person.Address 
WHERE AddressID = 12037

-- bookmark lookup
SELECT AddressID, City, StateProvinceID, ModifiedDate FROM Person.Address 
WHERE StateProvinceID = 32

SET SHOWPLAN_TEXT ON 
GO 
SELECT AddressID, City, StateProvinceID, ModifiedDate FROM Person.Address 
WHERE StateProvinceID = 32 
GO 
SET SHOWPLAN_TEXT OFF 
GO

-- RID lookup
CREATE INDEX IX_Object ON DatabaseLog(Object)
SELECT * FROM DatabaseLog WHERE Object = 'City'
DROP INDEX DatabaseLog.IX_Object

-- aggregations
-- stream aggregate
SELECT AVG(ListPrice) FROM Production.Product

-- hash aggregate
SELECT TerritoryID, COUNT(*) 
FROM Sales.SalesOrderHeader 
GROUP BY TerritoryID

-- joins
-- nested loops join
SELECT e.BusinessEntityID, TerritoryID 
FROM HumanResources.Employee AS e JOIN Sales.SalesPerson AS s 
ON e.BusinessEntityID = s.BusinessEntityID

-- merge join
SELECT h.SalesOrderID, s.SalesOrderDetailID, OrderDate 
FROM Sales.SalesOrderHeader h JOIN Sales.SalesOrderDetail s 
ON h.SalesOrderID = s.SalesOrderID

-- hash join
SELECT h.SalesOrderID, s.SalesOrderDetailID 
FROM Sales.SalesOrderHeader h JOIN Sales.SalesOrderDetail s 
ON h.SalesOrderID = s.SalesOrderID

-- parallelism
SELECT * INTO #temp FROM Sales.SalesOrderDetail 
UNION ALL SELECT * FROM Sales.SalesOrderDetail 
UNION ALL SELECT * FROM Sales.SalesOrderDetail 
UNION ALL SELECT * FROM Sales.SalesOrderDetail 
UNION ALL SELECT * FROM Sales.SalesOrderDetail 
UNION ALL SELECT * FROM Sales.SalesOrderDetail

SELECT IDENTITY(int, 1, 1) AS ID, CarrierTrackingNumber, OrderQty, ProductID, UnitPrice, LineTotal, rowguid, ModifiedDate 
INTO dbo.SalesOrderDetail FROM #temp 

SELECT IDENTITY(int, 1, 1) AS ID, CarrierTrackingNumber, OrderQty, ProductID, UnitPrice, LineTotal, rowguid, ModifiedDate 
INTO dbo.SalesOrderDetail2 FROM #temp DROP TABLE #temp

SELECT ProductID, COUNT(*) 
FROM dbo.SalesOrderDetail 
GROUP BY ProductID

EXEC sp_configure 'cost threshold for parallelism', 10 
GO 
RECONFIGURE 
GO

EXEC sp_configure 'cost threshold for parallelism', 5 
GO 
RECONFIGURE 
GO

CREATE FUNCTION dbo.ufn_test(@ProductID int) 
RETURNS int 
AS 
BEGIN 
RETURN @ProductID 
END 
GO 
-- serial
SELECT dbo.ufn_test(ProductID), COUNT(*) 
FROM dbo.SalesOrderDetail 
GROUP BY ProductID
-- show NonParallelPlanReason

-- parallel
SELECT ProductID, COUNT(*) 
FROM dbo.SalesOrderDetail 
GROUP BY ProductID

-- undocumented trace flag to force a parallel plan
SELECT ProductID, COUNT(*) 
FROM Sales.SalesOrderDetail 
GROUP BY ProductID 
OPTION (QUERYTRACEON 8649)

DROP TABLE dbo.SalesOrderDetail 
DROP TABLE dbo.SalesOrderDetail2 

-- updates
-- simple  plan
INSERT INTO Person.CountryRegion (CountryRegionCode, Name) 
VALUES ('ZZ', 'New Country') 

-- more complicated. why?
DELETE FROM Person.CountryRegion WHERE CountryRegionCode = 'ZZ'











