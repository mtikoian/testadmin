
-- demo
-- data warehouses

USE AdventureWorksDW2012
GO

SELECT TOP 10 p.ModelName, p.EnglishDescription, SUM(f.SalesAmount) AS SalesAmount 
FROM FactResellerSales f JOIN DimProduct p       
ON f.ProductKey = p.ProductKey JOIN DimEmployee e       
ON f.EmployeeKey = e.EmployeeKey WHERE f.OrderDateKey >= 20030601 AND e.SalesTerritoryKey = 1 
GROUP BY p.ModelName, p.EnglishDescription ORDER BY SUM(f.SalesAmount) DESC

-- to simulate a larger table with 100,000 rows and 10,000 pages
--  undocumented, use only for testing
UPDATE STATISTICS dbo.FactResellerSales WITH ROWCOUNT = 100000, PAGECOUNT = 10000

DBCC FREEPROCCACHE

-- run star join query again

-- correct the page and row count 
DBCC UPDATEUSAGE (AdventureWorksDW2012, 'dbo.FactResellerSales') WITH COUNT_ROWS

-- columnstore indexes
CREATE TABLE dbo.FactInternetSales2 (       
ProductKey int NOT NULL,       
OrderDateKey int NOT NULL,       
DueDateKey int NOT NULL,       
ShipDateKey int NOT NULL,       
CustomerKey int NOT NULL,       
PromotionKey int NOT NULL,       
CurrencyKey int NOT NULL,       
SalesTerritoryKey int NOT NULL,       
SalesOrderNumber nvarchar(20) NOT NULL,       
SalesOrderLineNumber tinyint NOT NULL,       
RevisionNumber tinyint NOT NULL,       
OrderQuantity smallint NOT NULL,       
UnitPrice money NOT NULL,       
ExtendedAmount money NOT NULL,       
UnitPriceDiscountPct float NOT NULL,       
DiscountAmount float NOT NULL,       
ProductStandardCost money NOT NULL,       
TotalProductCost money NOT NULL,       
SalesAmount money NOT NULL,       
TaxAmt money NOT NULL,       
Freight money NOT NULL,       
CarrierTrackingNumber nvarchar(25) NULL,       
CustomerPONumber nvarchar(25) NULL,
OrderDate datetime NULL,       
DueDate datetime NULL,       
ShipDate datetime NULL ) 

INSERT INTO dbo.FactInternetSales2 SELECT * FROM AdventureWorksDW2012.dbo.FactInternetSales 
WHERE SalesOrderNumber < 'SO6'

CREATE CLUSTERED COLUMNSTORE INDEX csi_FactInternetSales2 ON dbo.FactInternetSales2

-- columnstore indexes are now updatable
-- this will fail in SQL Server 2012
INSERT INTO dbo.FactInternetSales2 SELECT * FROM AdventureWorksDW2012.dbo.FactInternetSales 
WHERE SalesOrderNumber > 'SO6'

SELECT d.CalendarYear, SUM(SalesAmount) AS SalesTotal 
FROM dbo.FactInternetSales2 AS f 
JOIN dbo.DimDate AS d ON f.OrderDateKey = d.DateKey 
GROUP BY d.CalendarYear ORDER BY d.CalendarYear

-- star join query may not have enough records to produce batch processing
-- just for testing, add more rows
INSERT INTO dbo.FactInternetSales2 SELECT * FROM AdventureWorksDW2012.dbo.FactInternetSales 
GO 20

-- run same query, we have batch processing this time
SELECT d.CalendarYear, SUM(SalesAmount) AS SalesTotal 
FROM dbo.FactInternetSales2 AS f 
JOIN dbo.DimDate AS d ON f.OrderDateKey = d.DateKey 
GROUP BY d.CalendarYear ORDER BY d.CalendarYear

DROP TABLE FactInternetSales2





