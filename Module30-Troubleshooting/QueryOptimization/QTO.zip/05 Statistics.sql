
-- demo
-- statistics

ALTER DATABASE AdventureWorks2012 SET COMPATIBILITY_LEVEL = 120

SELECT * FROM sys.stats WHERE object_id = OBJECT_ID('Sales.SalesOrderDetail')

-- error, statistics object does not exist
DBCC SHOW_STATISTICS ('Sales.SalesOrderDetail', UnitPrice)

-- show auto-create statistics
SELECT * FROM Sales.SalesOrderDetail WHERE UnitPrice = 35

-- show header, density, histogram
DBCC SHOW_STATISTICS ('Sales.SalesOrderDetail', UnitPrice)

-- how they are used by the query optimizer
-- histogram
DBCC SHOW_STATISTICS ('Sales.SalesOrderDetail', IX_SalesOrderDetail_ProductID)

-- uses EQ_ROWS to estimate 198
SELECT * FROM Sales.SalesOrderDetail WHERE ProductID = 831

-- used AVG_RANGE_ROWS to estimate 36.6667
SELECT * FROM Sales.SalesOrderDetail WHERE ProductID = 828

-- density

SELECT ProductID FROM Sales.SalesOrderDetail GROUP BY ProductID
-- estimated 266

DBCC SHOW_STATISTICS ('Sales.SalesOrderDetail', IX_SalesOrderDetail_ProductID)

SELECT 1 / 0.003759399

DECLARE @ProductID int 
SET @ProductID = 921 
SELECT ProductID 
FROM Sales.SalesOrderDetail 
WHERE ProductID = @ProductID
-- estimated 456.079

SELECT 0.003759399 * 121317

-- more on estimations later and on the parameter sniffing session

-- cardinality estimation errors
-- show graphical plan too

SET STATISTICS PROFILE ON
GO
SELECT * FROM Sales.SalesOrderDetail
WHERE OrderQty * UnitPrice > 25000
GO
SET STATISTICS PROFILE OFF
GO

-- the new cardinality estimator
-- the old cardinality estimator is using the original independence assumption
-- the new cardinality estimator is using a new formula, relaxing this assumption, which is now called the exponential backoff
-- this new formula does not assume total correlation either but is better than the original

ALTER DATABASE AdventureWorks2012 SET COMPATIBILITY_LEVEL = 110

SELECT * FROM Person.Address WHERE City = 'Burbank'
-- estimated 196

SELECT * FROM Person.Address WHERE PostalCode = '91502'
-- estimated 194

SELECT * FROM Person.Address WHERE City = 'Burbank' AND PostalCode = '91502'
-- estimated 1.93862
SELECT (196 * 194) / 19614.0

ALTER DATABASE AdventureWorks2012 SET COMPATIBILITY_LEVEL = 120 
GO 
SELECT * FROM Person.Address WHERE City = 'Burbank' AND PostalCode = '91502'
-- estimated 19.3931
-- formula selectivity of most selective filter * SQRT(selectivity of next most selective filter)
SELECT  (194/19614.0) * SQRT(196/19614.0) * 19614.0

-- if you have enabled the new cardinality estimator at the database level 
-- but want to disable it for a specific query to avoid plan regression
-- you can use trace flag 9481
ALTER DATABASE AdventureWorks2012 SET COMPATIBILITY_LEVEL = 120 
GO 
SELECT * FROM Person.Address WHERE City = 'Burbank' AND PostalCode = '91502' 
OPTION (QUERYTRACEON 9481)
-- estimated 1.93862

-- opposite is also possible
-- enable the new cardinality estimator for a specific query
ALTER DATABASE AdventureWorks2012 SET COMPATIBILITY_LEVEL = 110 
GO 
SELECT * FROM Person.Address WHERE City = 'Burbank' AND PostalCode = '91502' 
OPTION (QUERYTRACEON 2312)
-- estimated 19.3931

-- computed columns

SELECT * FROM Sales.SalesOrderDetail
WHERE OrderQty * UnitPrice > 25000

-- 30% guess
SELECT 121317 * .3
-- 36395.1 against 5

ALTER TABLE Sales.SalesOrderDetail
ADD cc AS OrderQty * UnitPrice

-- does not have to use the computed column name
-- just the expression
SELECT * FROM Sales.SalesOrderDetail
WHERE OrderQty * UnitPrice > 25000
-- estimated is now 86.9878

-- or here
SELECT * FROM Sales.SalesOrderDetail
WHERE cc > 25000

-- unfortunately expression must be the same
SELECT * FROM Sales.SalesOrderDetail
WHERE UnitPrice * OrderQty > 25000

-- index can be created
CREATE INDEX IX_cc on Sales.SalesOrderDetail(cc)

-- and used for an index seek/key lookup plan
SELECT * FROM Sales.SalesOrderDetail
WHERE OrderQty * UnitPrice > 25000

-- clean up
DROP INDEX Sales.SalesOrderDetail.IX_cc

ALTER TABLE Sales.SalesOrderDetail 
DROP COLUMN cc

DBCC FREEPROCCACHE

DBCC SHOW_STATISTICS('Sales.SalesOrderDetail', cc)

-- statistics maintenance
SELECT * INTO dbo.SalesOrderDetail FROM Sales.SalesOrderDetail 

SELECT name, auto_created, STATS_DATE(object_id, stats_id) AS update_date FROM sys.stats 
WHERE object_id = OBJECT_ID('dbo.SalesOrderDetail') 

SELECT * FROM dbo.SalesOrderDetail WHERE SalesOrderID = 43670 AND OrderQty = 1 

SELECT name, auto_created, STATS_DATE(object_id, stats_id) AS update_date FROM sys.stats 
WHERE object_id = OBJECT_ID('dbo.SalesOrderDetail') 

CREATE INDEX IX_ProductID ON dbo.SalesOrderDetail(ProductID)

SELECT name, auto_created, STATS_DATE(object_id, stats_id) AS update_date FROM sys.stats 
WHERE object_id = OBJECT_ID('dbo.SalesOrderDetail') 

-- only column statistics are updated
UPDATE STATISTICS dbo.SalesOrderDetail WITH FULLSCAN, COLUMNS

SELECT name, auto_created, STATS_DATE(object_id, stats_id) AS update_date FROM sys.stats 
WHERE object_id = OBJECT_ID('dbo.SalesOrderDetail') 

-- only index statistics are updated
UPDATE STATISTICS dbo.SalesOrderDetail WITH FULLSCAN, INDEX 

SELECT name, auto_created, STATS_DATE(object_id, stats_id) AS update_date FROM sys.stats 
WHERE object_id = OBJECT_ID('dbo.SalesOrderDetail') 

-- both column and index statistics are updated
UPDATE STATISTICS dbo.SalesOrderDetail WITH FULLSCAN 
UPDATE STATISTICS dbo.SalesOrderDetail WITH FULLSCAN, ALL

SELECT name, auto_created, STATS_DATE(object_id, stats_id) AS update_date FROM sys.stats 
WHERE object_id = OBJECT_ID('dbo.SalesOrderDetail') 

-- only index statistics are updated, with fullscan
ALTER INDEX ix_ProductID ON dbo.SalesOrderDetail REBUILD 

SELECT name, auto_created, STATS_DATE(object_id, stats_id) AS update_date FROM sys.stats 
WHERE object_id = OBJECT_ID('dbo.SalesOrderDetail') 

-- no statistics are updated
ALTER INDEX ix_ProductID on dbo.SalesOrderDetail REORGANIZE

SELECT name, auto_created, STATS_DATE(object_id, stats_id) AS update_date FROM sys.stats 
WHERE object_id = OBJECT_ID('dbo.SalesOrderDetail') 

DROP TABLE dbo.SalesOrderDetail































 




















