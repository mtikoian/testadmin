
-- simplification phase demo
-- logical trees
-- trace flags 8606 

-- foreign key join elimination requires this database as schema changed
USE AdventureWorks
GO

DBCC TRACEON(3604)

-- foreign key join elimination
-- join-collapsed tree example
SELECT FirstName, LastName
FROM Person.Contact AS C
JOIN Sales.Individual AS I
ON C.ContactID = I.ContactID
JOIN Sales.Customer AS Cu -- removed
ON I.CustomerID = Cu.CustomerID
OPTION (RECOMPILE, QUERYTRACEON 8606)

DBCC FREEPROCCACHE

-- foreign key definition
ALTER TABLE [Sales].[Individual]  WITH CHECK ADD  
CONSTRAINT [FK_Individual_Customer_CustomerID] FOREIGN KEY([CustomerID])
REFERENCES [Sales].[Customer] ([CustomerID])

-- disable foreign key constraint
ALTER TABLE Sales.Individual NOCHECK CONSTRAINT FK_Individual_Customer_CustomerID

-- enable back check constraint nocheck not trusted
ALTER TABLE Sales.Individual WITH NOCHECK CHECK CONSTRAINT FK_Individual_Customer_CustomerID

-- enable back check constraint trusted
ALTER TABLE Sales.Individual WITH CHECK CHECK CONSTRAINT FK_Individual_Customer_CustomerID

-- optional additional validations
SELECT name, is_disabled, is_not_trusted FROM sys.foreign_keys
WHERE is_disabled = 1 OR is_not_trusted = 1


-- contradiction detection

-- check constraint already enabled
ALTER TABLE [HumanResources].[Employee] WITH CHECK ADD CONSTRAINT [CK_Employee_VacationHours] 
CHECK (([VacationHours]>=(-40) AND [VacationHours]<=(240)))

-- converted tree
SELECT * FROM HumanResources.Employee
WHERE VacationHours > 80
OPTION (RECOMPILE, QUERYTRACEON 8605)

-- simplified tree
SELECT * FROM HumanResources.Employee
WHERE VacationHours > 80
OPTION (RECOMPILE, QUERYTRACEON 8606)

-- simplified tree
SELECT * FROM HumanResources.Employee
WHERE VacationHours > 300
OPTION (RECOMPILE, QUERYTRACEON 8606)

-- output tree
SELECT * FROM HumanResources.Employee
WHERE VacationHours > 300
OPTION (RECOMPILE, QUERYTRACEON 8607)

-- disable check constraint
ALTER TABLE HumanResources.Employee NOCHECK CONSTRAINT CK_Employee_VacationHours

-- enable back check constraint
ALTER TABLE HumanResources.Employee WITH CHECK CHECK CONSTRAINT CK_Employee_VacationHours

SELECT * FROM HumanResources.Employee
WHERE ManagerID > 10 AND ManagerID < 5
OPTION (RECOMPILE, QUERYTRACEON 8606)



