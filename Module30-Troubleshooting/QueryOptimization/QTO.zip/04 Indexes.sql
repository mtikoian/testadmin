
-- primary key creates a clustered index
CREATE TABLE table1 (       
col1 int NOT NULL,       
col2 nchar(10) NULL,       
CONSTRAINT PK_table1 PRIMARY KEY(col1)       
) 

CREATE TABLE table1        (       
col1 int NOT NULL,       
col2 nchar(10) NULL       ) 
GO 
ALTER TABLE table1 ADD CONSTRAINT       
PK_table1 PRIMARY KEY (       col1       )

--
DROP TABLE dbo.SalesOrderDetail

SELECT * INTO dbo.SalesOrderDetail FROM Sales.SalesOrderDetail
 
SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID('dbo.SalesOrderDetail')

CREATE INDEX IX_ProductID ON dbo.SalesOrderDetail(ProductID)

SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID('dbo.SalesOrderDetail')

-- index_id values between 2 and 250 and between 256 and 1005
-- covers the maximum of 999 nonclustered indexes mentioned earlier
-- values between 251 and 255 are reserved.

CREATE CLUSTERED INDEX IX_SalesOrderID_SalesOrderDetailID 
ON dbo.SalesOrderDetail(SalesOrderID, SalesOrderDetailID)

SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID('dbo.SalesOrderDetail')

-- drops index pages
DROP INDEX dbo.SalesOrderDetail.IX_ProductID

SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID('dbo.SalesOrderDetail')

-- will drop the entire table?
DROP INDEX dbo.SalesOrderDetail.IX_SalesOrderID_SalesOrderDetailID

SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID('dbo.SalesOrderDetail')

-- index selection

-- uses an index seek
-- note seek predicate
SELECT ProductID, SalesOrderID, SalesOrderDetailID 
FROM Sales.SalesOrderDetail
WHERE ProductID = 771

-- no seek predicate
SELECT ProductID, SalesOrderID, SalesOrderDetailID 
FROM Sales.SalesOrderDetail
WHERE ABS(ProductID) = 771

-- uses an index seek
-- note seek predicate on both
SELECT ProductID, SalesOrderID, SalesOrderDetailID 
FROM Sales.SalesOrderDetail
WHERE ProductID = 771 AND SalesOrderID = 45233

-- uses an index seek
-- but seek predicate on ProductID only
SELECT ProductID, SalesOrderID, SalesOrderDetailID 
FROM Sales.SalesOrderDetail
WHERE ProductID = 771 AND ABS(SalesOrderID) = 45233


-- missing indexes
-- focus on query optimizer point of view

DROP TABLE  dbo.SalesOrderDetail

SELECT * 
INTO dbo.SalesOrderDetail
FROM sales.SalesOrderDetail

-- show trivial plan limitation
SELECT * FROM dbo.SalesOrderDetail
WHERE SalesOrderID = 43670 AND SalesOrderDetailID > 112

-- create unrelated index to avoid trivial plan
CREATE INDEX IX_ProductID ON dbo.SalesOrderDetail(ProductID)

-- run same query again
-- shows table scan 
SELECT * FROM dbo.SalesOrderDetail
WHERE SalesOrderID = 43670 AND SalesOrderDetailID > 112

-- show XML information

CREATE NONCLUSTERED INDEX IX_SalesOrderID_SalesOrderDetailID
ON [dbo].[SalesOrderDetail]([SalesOrderID], [SalesOrderDetailID])

-- run same query again
-- shows index seek 
SELECT * FROM dbo.SalesOrderDetail
WHERE SalesOrderID = 43670 AND SalesOrderDetailID > 112

-- clean up
DROP TABLE dbo.SalesOrderDetail

-- database engine tuning advisor
-- focus on query optimizer point of view

SELECT * 
INTO dbo.SalesOrderDetail 
FROM Sales.SalesOrderDetail

-- save in a new file
SELECT * FROM dbo.SalesOrderDetail
WHERE ProductID = 897

-- run dta and profiler

-- show both current and recommended cost
SELECT * FROM msdb..DTA_reports_query

--CREATE CLUSTERED INDEX cix_ProductID ON dbo.SalesOrderDetail(ProductID)
--WITH STATISTICS_ONLY

SELECT * FROM sys.indexes
WHERE object_id = object_id('dbo.SalesOrderDetail')
AND name = 'cix_ProductID'

--DROP INDEX dbo.SalesOrderDetail.cix_ProductID

CREATE CLUSTERED INDEX cix_ProductID ON dbo.SalesOrderDetail(ProductID)

-- clean up
DROP TABLE dbo.SalesOrderDetail

-- drop DTA sessions







