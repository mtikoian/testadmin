
-- logical trees
-- trace flags 8605, 8606, 8607 

DBCC TRACEON(3604)

-- query optimizer trees
SELECT * FROM sys.dm_xe_map_values WHERE name = 'query_optimizer_tree_id'

-- converted tree
select ProductID, name from Production.Product
where ProductID = 877
OPTION (RECOMPILE, QUERYTRACEON 8605)

-- relational algebra 
-- projection SELECT
-- selection WHERE

-- input, simplified, before-after project normalization
select ProductID, name from Production.Product
where ProductID = 877
OPTION (RECOMPILE, QUERYTRACEON 8606)

-- output tree, PhyOps
select ProductID, name from Production.Product
OPTION (RECOMPILE, QUERYTRACEON 8607)

-- Query processor logical operator type
SELECT *
FROM sys.dm_xe_map_values
WHERE name = N'qp_logical_operator';

-- Query processor physical operator type
SELECT *
FROM sys.dm_xe_map_values
WHERE name = N'qp_physical_operator';


