
-- transformation rules demo
-- sys.dm_exec_query_transformation_stats DMV
-- DBCC RULEOFF, DBCC RULEON
-- trace flag 2373
-- QUERYRULEOFF

USE AdventureWorks
GO

SELECT * FROM sys.dm_exec_query_transformation_stats

-- example query
SELECT c.CustomerID, COUNT(*)
FROM Sales.Customer c JOIN Sales.SalesOrderHeader o
ON c.CustomerID = o.CustomerID
GROUP BY c.CustomerID

-- optimize these queries now
-- so they do not skew the collected results
GO
SELECT *
INTO before_query_transformation_stats
FROM sys.dm_exec_query_transformation_stats
GO
SELECT *
INTO after_query_transformation_stats
FROM sys.dm_exec_query_transformation_stats
GO
DROP TABLE after_query_transformation_stats
DROP TABLE before_query_transformation_stats
-- real execution starts
GO
SELECT *
INTO before_query_transformation_stats
FROM sys.dm_exec_query_transformation_stats
GO
-- insert your query here
SELECT c.CustomerID, COUNT(*)
FROM Sales.Customer c JOIN Sales.SalesOrderHeader o
ON c.CustomerID = o.CustomerID
GROUP BY c.CustomerID
-- keep this to force a new optimization
OPTION (RECOMPILE)
GO
SELECT *
INTO after_query_transformation_stats
FROM sys.dm_exec_query_transformation_stats
GO
SELECT a.name, (a.promised - b.promised) as promised
FROM before_query_transformation_stats b
JOIN after_query_transformation_stats a
ON b.name = a.name
WHERE b.succeeded <> a.succeeded
DROP TABLE before_query_transformation_stats
DROP TABLE after_query_transformation_stats

-- 
SELECT c.CustomerID, COUNT(*)
FROM Sales.Customer c JOIN Sales.SalesOrderHeader o
ON c.CustomerID = o.CustomerID
GROUP BY c.CustomerID

-- disable "Group By Aggregate Before Join" rule
DBCC RULEOFF('GbAggBeforeJoin')

-- clean up procedure cache
DBCC FREEPROCCACHE

-- disable "Join to Sort Merge Join" rule
DBCC RULEOFF('JNtoSM')

-- disable aggregations
-- produces query optimizer error
DBCC RULEOFF('GbAggToStrm') -- Stream Aggregate
DBCC RULEOFF('GbAggToHS') -- Hash Aggregate

-- enable back rules
DBCC RULEON('JNtoSM')
DBCC RULEON('GbAggBeforeJoin')
DBCC RULEON('GbAggToStrm') 
DBCC RULEON('GbAggToHS')

-- verify no rules are disabled
DBCC TRACEON (3604)
DBCC SHOWOFFRULES

-- similar behavior using a hint
SELECT c.CustomerID, COUNT(*)
FROM Sales.Customer c JOIN Sales.SalesOrderHeader o
ON c.CustomerID = o.CustomerID
GROUP BY c.CustomerID

SELECT c.CustomerID, COUNT(*)
FROM Sales.Customer c JOIN Sales.SalesOrderHeader o
ON c.CustomerID = o.CustomerID
GROUP BY c.CustomerID
OPTION (FORCE ORDER)

DBCC TRACEON (3604)

-- show transformation rules
SELECT c.CustomerID, COUNT(*)
FROM Sales.Customer c JOIN Sales.SalesOrderHeader o
ON c.CustomerID = o.CustomerID
GROUP BY c.CustomerID
OPTION (RECOMPILE, QUERYTRACEON 2373)

-- disable transformation rule for a query
SELECT c.CustomerID, COUNT(*)
FROM Sales.Customer c JOIN Sales.SalesOrderHeader o
ON c.CustomerID = o.CustomerID
GROUP BY c.CustomerID
OPTION (RECOMPILE, QUERYRULEOFF GbAggBeforeJoin)

-- query processor could not produce a query plan 
SELECT c.CustomerID, COUNT(*)
FROM Sales.Customer c JOIN Sales.SalesOrderHeader o
ON c.CustomerID = o.CustomerID
GROUP BY c.CustomerID
OPTION (RECOMPILE, QUERYRULEOFF GbAggToStrm, QUERYRULEOFF GbAggToHS)

-- cleanup
DBCC SHOWOFFRULES
DBCC FREEPROCCACHE



