USE AdventureWorks2008R2;
GO
SET NOCOUNT ON;
DBCC FREEPROCCACHE;
DBCC TRACEON(3604);
GO
--                                        -- 0.0295
--DBCC RULEOFF ('GbAggBeforeJoin');       -- 0.0351
--DBCC RULEOFF ('JNtoIdxLookup');         -- 0.0431
--DBCC RULEOFF ('JNtoSM');                -- 0.0500
--DBCC RULEOFF ('SelIdxToRng');           -- 0.0531
--DBCC RULEOFF ('GetIdxToRng');           -- 0.0598
--DBCC RULEOFF ('SelOnJN');               -- 3.1244
--DBCC RULEOFF ('BuildSpool');            -- 3.5980
--DBCC RULEOFF ('NormalizeGbAgg');        -- 3.5980
GO
SET STATISTICS XML OFF;
GO
SELECT * INTO #q1 FROM sys.dm_exec_query_transformation_stats AS deqts;
GO
SELECT * INTO #q2 FROM sys.dm_exec_query_transformation_stats AS deqts;
GO
DROP TABLE #q1, #q2;
GO
SELECT * INTO #q1 FROM sys.dm_exec_query_transformation_stats AS deqts;
GO
SET SHOWPLAN_XML ON;
GO
-- TEST QUERY
SELECT
    p.Name,
    Total = SUM(inv.Quantity)
FROM Production.Product AS p
JOIN Production.ProductInventory AS inv ON
    inv.ProductID = p.ProductID
WHERE
    p.Name LIKE N'[A-G]%'
GROUP BY
    p.Name;
GO
SET SHOWPLAN_XML OFF;
GO
SELECT * INTO #q2 FROM sys.dm_exec_query_transformation_stats AS deqts;
GO
SELECT
    q.name,
    q.promised,
    q.built_substitute,
    q.succeeded,
    q2.succeeded
FROM #q1 AS q 
JOIN #q2 AS q2 ON
    q.name = q2.name
    AND q.succeeded < q2.succeeded;
GO
DBCC RULEON ('GbAggBeforeJoin');
DBCC RULEON ('JNtoSM');
DBCC RULEON ('JNtoIdxLookup');
DBCC RULEON ('SelOnJN');
DBCC RULEON ('BuildSpool');
DBCC RULEON ('SelIdxToRng');
DBCC RULEON ('GetIdxToRng');
DBCC RULEON ('NormalizeGbAgg');
GO
DROP TABLE #q1, #q2;