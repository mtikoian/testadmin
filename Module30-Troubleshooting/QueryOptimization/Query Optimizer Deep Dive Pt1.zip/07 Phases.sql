USE AdventureWorks2008R2;
GO
SET NOCOUNT ON;
DBCC FREEPROCCACHE;
DBCC TRACEON(3604);
GO
-- Supported DMV
SELECT
    deqoi.[counter],
    deqoi.occurrence
FROM sys.dm_exec_query_optimizer_info AS deqoi
WHERE
    deqoi.[counter] IN
    (
        N'trivial plan',
        N'search 0',
        N'search 1',
        N'search 2'
    );
GO
-- Search 0 (TP)
SELECT
    p.ProductID,
    inv.Shelf,
    inv.Bin,
    l.Name
FROM Production.Product AS p
JOIN Production.ProductInventory AS inv ON
    inv.ProductID = p.ProductID
JOIN Production.Location AS l ON
    l.LocationID = inv.LocationID
WHERE
    p.Name = N'Blade'
OPTION (QUERYTRACEON 8675);
GO
-- Search 1 (QP)
SELECT
    p.Name,
    average_qty = AVG(th.Quantity)
FROM Production.Product AS p
JOIN Production.TransactionHistory AS th ON
    th.ProductID = p.ProductID
GROUP BY
    p.Name
OPTION (QUERYTRACEON 8675);
GO
-- Search 0, then search 1 twice (parallel)
SELECT COUNT_BIG(*)
FROM Production.TransactionHistory AS th
CROSS JOIN Production.TransactionHistory AS th2
CROSS JOIN Production.TransactionHistory AS th3
OPTION (QUERYTRACEON 8675);
GO
-- Search 1 twice (parallel)
SELECT COUNT_BIG(*)
FROM Production.TransactionHistory AS th
CROSS JOIN dbo.bigTransactionHistory AS bth
OPTION (QUERYTRACEON 8675);
GO
-- Time out
SELECT *
FROM HumanResources.vEmployee AS ve
JOIN HumanResources.vEmployeeDepartmentHistory AS vedh ON
    vedh.BusinessEntityID = ve.BusinessEntityID
OPTION (QUERYTRACEON 8675);
GO
-- Search 2
SELECT * FROM HumanResources.vJobCandidate AS vjc
JOIN HumanResources.vEmployeeDepartmentHistory AS vedh ON
    vedh.BusinessEntityID = vjc.BusinessEntityID
OPTION (QUERYTRACEON 8675);
