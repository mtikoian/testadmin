USE AdventureWorks2008R2;
GO
SET NOCOUNT ON;
DBCC FREEPROCCACHE;
DBCC TRACEON(3604);
GO
-- Trivial plan
SELECT p.ProductID
FROM Production.Product AS p
WHERE p.Name = N'Blade';
GO
-- Still trivial
SELECT
    p.Name,
    RowNumber =
        ROW_NUMBER() OVER (
            ORDER BY p.Name)
FROM Production.Product AS p
WHERE p.Name LIKE N'[A-G]%';
GO
-- 'Subquery' prevents a trivial plan
SELECT (SELECT p.ProductID)
FROM Production.Product AS p
WHERE p.Name = N'Blade';
GO
-- Inequality
SELECT p.ProductID
FROM Production.Product AS p
WHERE p.Name <> N'Blade';
GO
-- Cost threshold for parallelism
EXECUTE sys.sp_configure
    @configname = 'show advanced options',
    @configvalue = 1;
RECONFIGURE;

EXECUTE sys.sp_configure
    @configname = 'cost threshold for parallelism',
    @configvalue = 0;
RECONFIGURE;
GO
-- Full optimization
SELECT p.ProductID
FROM Production.Product AS p
WHERE p.Name = N'Blade';
GO
-- Reset to default
EXECUTE sys.sp_configure
    @configname = 'cost threshold for parallelism',
    @configvalue = 5;
RECONFIGURE;
GO
-- Check
SELECT c.[description], c.value_in_use
FROM sys.configurations AS c 
WHERE c.name = N'cost threshold for parallelism';
GO
