USE AdventureWorks2008R2;
GO
SET NOCOUNT ON;
DBCC FREEPROCCACHE;
DBCC TRACEON(3604);
GO
-- Input tree to CBO
SELECT
    p.Name,
    Total = SUM(inv.Quantity)
FROM Production.Product AS p
JOIN Production.ProductInventory AS inv ON
    inv.ProductID = p.ProductID
WHERE
    p.Name LIKE N'[A-G]%'
GROUP BY
    p.Name
OPTION (RECOMPILE, QUERYTRACEON 8606);
GO
SELECT decoded =
    NCHAR(91) +
    NCHAR(65) +
    NCHAR(45) +
    NCHAR(71) +
    NCHAR(93) +
    NCHAR(37);
