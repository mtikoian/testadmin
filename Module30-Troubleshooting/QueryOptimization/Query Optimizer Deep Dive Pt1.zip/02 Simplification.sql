USE AdventureWorks2008R2;
GO
SET NOCOUNT ON;
DBCC FREEPROCCACHE;
DBCC TRACEON(3604);
GO
-- Directly using a constant
SELECT TOP (10) *
FROM Production.Product AS p
WHERE p.ProductID < 30;
GO
-- Constant folding an expression
SELECT p.Name
FROM Production.Product AS p
WHERE p.Name LIKE SUBSTRING(LEFT(CHAR(ASCII(CHAR(68))), 1) + '%', 1, 2)
GO
-- Remove redundancy
SELECT TOP (10) * FROM
(
    SELECT * FROM 
    (
        SELECT * FROM
        (
            SELECT * FROM Production.Product AS p
            WHERE p.ProductID = 400
        ) AS q1
        WHERE q1.ProductID = 400
    ) AS q2
    WHERE q2.ProductID = 400)
AS q3
WHERE q3.ProductID = 400;
GO
-- Simplify domains
SELECT TOP (10) * 
FROM Production.Product AS p
WHERE p.ProductID BETWEEN 300 AND 400
AND p.ProductID BETWEEN 200 AND 500
AND p.ProductID BETWEEN 400 AND 600;
GO
-- Computed column matching
DECLARE @Example AS TABLE
(
    col1 int NULL, 
    col2 int NULL, 
    col3 AS col1 * col2 UNIQUE CLUSTERED
);

SELECT * FROM @Example AS e WHERE col3 = 5;
SELECT * FROM @Example AS e WHERE col1 * col2 = 5;
SELECT * FROM @Example AS e WHERE col2 * col1 = 5;
GO
-- Remove unnecessary joins
SELECT
    th.ProductID,
    SUM(th.ActualCost)
FROM Production.TransactionHistory AS th
JOIN Production.Product AS p ON
    p.ProductID = th.ProductID
GROUP BY
    th.ProductID;
GO
-- Outer join to join (null rejection)
SELECT * 
FROM Production.Product AS p
LEFT JOIN Production.TransactionHistory AS th ON
    th.ProductID = p.ProductID
WHERE th.ProductID < 10;
GO
-- Complex example combining multiple simplifications
WITH Complex AS
(
    SELECT
        pc.ProductCategoryID, pc.Name AS CatName,
        ps.ProductSubcategoryID, ps.Name AS SubCatName,
        p.ProductID, p.Name AS ProductName,
        p.Color, p.ListPrice, p.ReorderPoint,
        pm.Name AS ModelName, pm.ModifiedDate
    FROM Production.ProductCategory AS pc
    FULL JOIN Production.ProductSubcategory AS ps ON
        ps.ProductCategoryID = pc.ProductCategoryID
    FULL JOIN Production.Product AS p ON
        p.ProductSubcategoryID = ps.ProductSubcategoryID
    FULL JOIN Production.ProductModel AS pm ON
        pm.ProductModelID = p.ProductModelID
)
--SELECT * FROM Complex;
SELECT c.ProductID, c.ProductName
FROM Complex AS c
WHERE c.ProductName LIKE N'G%';
