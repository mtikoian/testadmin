USE AdventureWorks2008R2;
GO
SET NOCOUNT ON;
DBCC FREEPROCCACHE;
DBCC TRACEON(3604);
GO
DECLARE @x varchar(30) = 0x444243432052554C454F46462028274275696C644762546F7027293B0000;
EXECUTE (@x);
GO
-- Without segment top
SELECT
    inv.ProductID,
    inv.LocationID,
    inv.Shelf,
    inv.Bin,
    inv.Quantity
FROM Production.ProductInventory AS inv
WHERE inv.Quantity =
(
    SELECT MIN(inv2.Quantity)
    FROM Production.ProductInventory AS inv2
    WHERE inv2.Shelf = inv.Shelf
    AND inv2.Bin = inv.Bin
)
OPTION (RECOMPILE);
GO
DECLARE @x varchar(30) = 0x444243432052554C454F4E2028274275696C644762546F7027293B000000;
EXECUTE (@x);
GO
-- With segment top
SELECT
    inv.ProductID,
    inv.LocationID,
    inv.Shelf,
    inv.Bin,
    inv.Quantity
FROM Production.ProductInventory AS inv
WHERE inv.Quantity =
(
    SELECT MIN(inv2.Quantity)
    FROM Production.ProductInventory AS inv2
    WHERE inv2.Shelf = inv.Shelf
    AND inv2.Bin = inv.Bin
)
OPTION (RECOMPILE);
GO