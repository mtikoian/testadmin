
USE [AdventureWorks2012]
GO

SELECT   
	SQL				=	'DROP INDEX [' + i.name + '] ON [' +  sc.name + '].[' + o.name + '] '
,	[OBJECT NAME]	=	o.name
,	o.create_date	
--select
,	*
FROM     SYS.DM_DB_INDEX_USAGE_STATS s 
         INNER JOIN SYS.INDEXES I 
           ON I.[OBJECT_ID] = S.[OBJECT_ID] 
              AND I.INDEX_ID = S.INDEX_ID 
		 INNER JOIN SYS.OBJECTS o
			ON o.Object_id = s.object_id
		 INNER JOIN SYS.SCHEMAS sc
			ON o.schema_id = sc.schema_id
		 inner join sys.dm_db_partition_stats ps
			on ps.object_id = o.object_id
			and ps.index_id = i.index_id
WHERE    
	OBJECTPROPERTY(S.[OBJECT_ID],'IsUserTable') = 1  
and s.database_id = db_id()
--and o.name = 'spots'
--and s.index_id=0 -- heap (no clustered index)
--and s.index_id=1 -- clustered index
--and user_seeks < 5 
--and user_scans < 5 
--and user_lookups < 5
--and user_updates > 0
--and i.type_desc = 'nonclustered'
--and i.is_unique = 0 
--and s.index_id = 0
order by user_scans desc


