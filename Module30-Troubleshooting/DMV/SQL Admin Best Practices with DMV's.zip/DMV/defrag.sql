
USE [AdventureWorks2012]
GO

--select db_id()

--CREATE TABLE sqlIndexREBUILD (
--	id int IDENTITY(1,1) NOT NULL PRIMARY KEY,
--	SQLString varchar(200) NOT NULL,
--	Fraglevel Decimal(19,3) NOT NULL,
--)
--GO
--CREATE PROCEDURE dbo.spDetectIndexFragmentation
--AS
--
--INSERT INTO sqlIndexRebuild (SQLString, FragLevel)
SELECT DISTINCT
	SQL = 'ALTER INDEX ALL ON ' + x.dbname + '.' + x.schemaname + '.' + x.[table] + ' REBUILD'
--,	FragLevel	=	sum(FragLevel)
,	avg_fragmentation_in_percent	=	avg(avg_fragmentation_in_percent)
,	page_count	=	sum(page_count)
--, * 
FROM 
(
select 
	--[fraglevel] = (power(s.avg_fragmentation_in_percent,2) *page_count)/power(10,7),
	avg_fragmentation_in_percent = s.avg_fragmentation_in_percent
,	page_count = page_count
,	dbname		= db_name(s.database_id)
,	[table]		= o.name
,	schemaname	= sc.name
--, index_name = i.name, s.index_type_desc, alloc_unit_type_desc, s.avg_fragmentation_in_percent, page_count, fragment_count, avg_fragment_size_in_pages
--select *
from sys.dm_db_index_physical_stats (DB_ID(),null,null, null,'limited') s
inner join --select * from
sys.indexes i on s.object_id = i.object_id and s.index_id = i.index_id
inner join  --select * from
sys.objects o on o.object_id = s.object_id
inner join --select * from
sys.schemas sc
on o.schema_id = sc.schema_id

WHERE 
		i.is_disabled = 0
and		i.type_desc = 'CLUSTERED'
and		s.database_id = db_id()
--and page_count > 100
) x
--WHERE avg_fragmentation_in_percent > 70
group by x.dbname , x.schemaname , x.[table]
order by avg_fragmentation_in_percent desc, page_count desc

GO

/*
--before CL
85.3803272792663	310902	Operations	ProposalMaps_ProposalLocations	dbo
17.8630332570219	81246	Operations	ProposalMaps_ProposalLocations	dbo
13.3045808011501	76515	Operations	ProposalMaps_ProposalLocations	dbo
15.6037231424049	132039	Operations	ProposalMaps_ProposalLocations	dbo

--After new CL
0.31663751388481	78323	Operations	ProposalMaps_ProposalLocations	dbo
0.36498294970162	75072	Operations	ProposalMaps_ProposalLocations	dbo
0.0180264246177338	94306	Operations	ProposalMaps_ProposalLocations	dbo


Sparkhound_Powertrak.dbo.pt_app_errors 
ALTER INDEX ALL ON w.dbo.Names REBUILD WITH(ONLINE = ON)

ALTER INDEX ALL ON Surveillance.dbo.ClinicServices REORGANIZE 

ALTER INDEX ALL ON Surveillance.dbo.MedicalClearanceRequestDocumentExpiration REORGANIZE
ALTER INDEX ALL ON Surveillance.dbo.Employee REORGANIZE
ALTER INDEX ALL ON Surveillance.dbo.Demographics_Temp_TableErrors REBUILD
ALTER INDEX ALL ON Surveillance.dbo.Candidate REORGANIZE


ALTER INDEX ALL ON ServerInformation.Threshold.ThresholdCompareStats REBUILD WITH (ONLINE = ON)
ALTER INDEX ALL ON ServerInformation.DiskUsage.DailyAverageDiskUsages REBUILD WITH (ONLINE = ON)
ALTER INDEX ALL ON ServerInformation.dbo.PerformanceCounts REBUILD WITH (ONLINE = ON)
ALTER INDEX ALL ON ServerInformation.dbo.CPUAverage REBUILD WITH (ONLINE = ON)

ALTER INDEX ALL ON Warehouse.dbo.PlayLog_fact_aggregate REBUILD WITH (ONLINE = ON)
ALTER INDEX ALL ON Warehouse_Canon.dbo.MachineDeployment_Fact REBUILD WITH (ONLINE = ON)

--ALTER INDEX ALL ON Operations.dbo.Businesses__auditLog REBUILD	69.2546583850932	30
ALTER INDEX ALL ON Operations.dbo.Businesses__auditLog REBUILD	21.4285714285714	11
ALTER INDEX ALL ON Operations.dbo.Businesses__auditLog REBUILD	25	6

select object_id ('Businesses__auditLog')
*/

