use AdventureWorks2012
go

SELECT
	CommandText			=	'ALTER INDEX ALL ON ' + x.dbname + '.' 
								+ x.schemaname + '.[' + x.[table] + '] REBUILD'
,	tablename			=	x.schemaname + '.[' + x.[table] + ']'
,	FragPercent			=	max(avg_frag_in_percent)
,	page_count			=	sum(page_count)
FROM 
(	
	SELECT DISTINCT 
	avg_frag_in_percent = s.avg_fragmentation_in_percent
,	page_count	= page_count
,	dbname		= db_name(s.database_id)
,	[table]		= o.name
,	schemaname	= sc.name
FROM 	sys.dm_db_index_physical_stats (DB_ID(),null,null, null, 'LIMITED') s --select DB_ID()
inner join 
		sys.indexes i		on s.object_id = i.object_id and s.index_id = i.index_id
inner join 
		sys.objects o		on o.object_id = s.object_id
inner join 
		sys.schemas sc		on o.schema_id = sc.schema_id
WHERE 	i.is_disabled = 0
and		i.type_desc = 'CLUSTERED'
and		alloc_unit_Type_desc <> 'LOB_DATA'
and		s.database_id = DB_ID()
) x
--WHERE avg_frag_in_percent > 50
GROUP BY x.dbname , x.schemaname , x.[table]
ORDER BY max(avg_frag_in_percent) * sum(page_count) DESC


--ALTER INDEX ALL ON w.dbo.[fragemall] REBUILD