use AdventureWorks2012
go
select distinct object_name, counter_name from sys.dm_os_performance_counters where object_name like '%mem%'
go

SELECT
(a.cntr_value * 1.0 / b.cntr_value)
* 100.0 [BufferCacheHitRatio]
FROM
(SELECT
*, 1 x FROM
sys.dm_os_performance_counters
WHERE counter_name = 'Buffer cache hit ratio'
AND object_name = 'MSSQL$SQL2012:Buffer Manager                                                                                                    ') a
INNER JOIN
(SELECT
*, 1 x FROM
sys.dm_os_performance_counters
WHERE counter_name = 'Buffer cache hit ratio base'
and object_name = 'MSSQL$SQL2012:Buffer Manager') b
ON a.x = b.x ;


select counter_name, [cntr_value (mb)] = cntr_value/1024.
 from sys.dm_os_performance_counters
where OBJECT_NAME = 'MSSQL$SQL2012:Memory Manager'
and counter_name in ('Target Server Memory (KB)','Total Server Memory (KB)')


SELECT
[Page Lookups/sec] = (a.cntr_value * 1. / b.cntr_value) --should be <100
FROM (
select * FROM sys.dm_os_performance_counters
where OBJECT_NAME = 'MSSQL$SQL2012:Buffer Manager'
and counter_name = 'Page lookups/sec') a
CROSS APPLY 
(select * FROM sys.dm_os_performance_counters
where OBJECT_NAME = 'MSSQL$SQL2012:SQL Statistics'
and counter_name = 'Batch Requests/sec') b
