use [AdventureWorks2012]
go
--Doesn't work on 2000 databases or databases in 2000 compatability mode.  Need to change the db_id() syntax if so.

select [Database Name] = db_name(), [Table Name] = s.name + '.' + o.name, [Rows]  from 
(	SELECT * FROM 
		sys.objects 
	where type = 'u'
) o
inner join 
	sys.schemas s
on o.schema_id = s.schema_id
inner join 
(	select si.*, i.rows from 
		sys.indexes si
	inner join -- select * from 
		sysindexes i
	on si.object_id = i.id
	and si.index_id = i.indid
	where	type_desc = 'heap'
	and rows >50
) sall
on sall.object_id = o.object_ID
left join 
(	select * from 
		sys.indexes si
	where type_desc = 'CLUSTERED'
) si
on si.object_id = o.object_ID
WHERE
	si.object_id is null
and o.name <> 'dtproperties'
and is_ms_shipped = 0
order by rows desc
go



/*
create table NoClusteredIndex(
	[DepartmentID] [smallint] IDENTITY(1,1) NOT NULL,
	[Name] [dbo].[Name] NOT NULL,
	[GroupName] [dbo].[Name] NOT NULL,
	[ModifiedDate] [datetime] NOT NULL,
 CONSTRAINT [PK_Department_DepartmentID] PRIMARY KEY NONCLUSTERED 
(
	[DepartmentID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

insert into NoClusteredIndex (name, groupname, modifieddate) values ('test','testing group', getdate())
go 50
*/