select * from sys.dm_exec_sessions
--where is_user_process = 1

--see below












go
sp_who2
go