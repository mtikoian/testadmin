
USE [AdventureWorks2012]
GO

----------------

SELECT 
    *
FROM Sales.SalesOrderDetail
inner join 
Sales.SalesOrderHeader
on Sales.SalesOrderDetail.SalesOrderID = Sales.SalesOrderHeader.SalesOrderID
where UnitPrice < 200 and OrderQty > 1
go


--drop index IDX_NC_SalesOrderDetail_OrderQty_UnitPrice on sales.salesorderdetail 
