
USE AdventureWorks
GO
EXEC dbo.uspGetManagerEmployees 140;
GO 100

DECLARE @CheckDate datetime;
SET @CheckDate = GETDATE();
EXEC dbo.uspGetWhereUsedProductID 819, @CheckDate;
GO 10

EXEC dbo.uspGetEmployeeManagers 50;
GO 1

DECLARE @CheckDate DATETIME;
SET @CheckDate = GETDATE();
EXEC [AdventureWorks].[dbo].[uspGetBillOfMaterials] 800, @CheckDate;
GO 17

EXEC TestProc;
GO 

