DBCC FREEPROCCACHE


---------------------------------------------------------------
-- Show stored procedure statistics - Run 2_SP_TSQL_Perf_Query1.sql
---------------------------------------------------------------
SELECT * FROM sys.dm_exec_procedure_stats;



 






















---------------------------------------------------------------
-- Show SP that uses the I/O on Average
---------------------------------------------------------------
SELECT DB_NAME(ps.database_id) [Database Name] 
      , OBJECT_SCHEMA_NAME(ps.object_id,ps.database_id) AS [Schema Name] 
      , OBJECT_NAME(ps.object_id,ps.database_id) AS [Object Name] 
      , execution_count
      , ps.total_worker_time / 1000. AS [Total CPU MS]
	  , (ps.total_worker_time / 1000.) / ps.execution_count  AS [Avg CPU Time MS]
	  , ps.total_logical_reads / ps.execution_count AS [Avg Logical Reads]
	  , ps.total_physical_reads / ps.execution_count AS [Avg Physical Reads]
	  , (ps.total_elapsed_time / 1000.) / ps.execution_count AS [Avg Elapsed Time MS]
FROM sys.dm_exec_procedure_stats ps
ORDER BY ps.total_logical_reads / ps. execution_count DESC














DBCC FREEPROCCACHE
---------------------------------------------------------------
-- Query Statistics -- run  2_SP_TSQL_Perf_Query2.sql
---------------------------------------------------------------
SELECT * 
FROM sys.dm_exec_query_stats 












---------------------------------------------------------------
-- Showing SQL Text  
---------------------------------------------------------------
SELECT * 
FROM sys.dm_exec_query_stats qs
CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle) st












----------------------------------------------------------
--  Find Statement uses most I/Os
----------------------------------------------------------
SELECT DB_NAME(st.dbid) AS DBNAME
    , OBJECT_SCHEMA_NAME(st.objectid,st.dbid) AS [Schema Name] 
    , OBJECT_NAME(st.objectid,st.dbid) AS [Object Name] 
    , SUBSTRING(st.text, CASE WHEN qs.statement_start_offset = 0 
                                OR qs.statement_start_offset IS NULL  
                              THEN 1 ELSE qs.statement_start_offset/2 + 1 END, 
                         CASE WHEN qs.statement_end_offset = 0 
                                OR qs.statement_end_offset = -1  
                                OR qs.statement_end_offset IS NULL  
                              THEN LEN(st.text)ELSE qs.statement_end_offset/2 END -  
                         CASE WHEN qs.statement_start_offset = 0 
                                 OR qs.statement_start_offset IS NULL 
                              THEN 1 ELSE qs.statement_start_offset/2  END + 1 
                  )  AS [Query Text]  
      , execution_count
      , qs.total_logical_reads / qs.execution_count as [AVG Logical I/O's]
      , qs.total_worker_time / 1000. AS [Total CPU MS]
	  , (qs.total_worker_time / 1000.) / qs.execution_count  AS [Avg CPU Time MS]
	  , qs.total_logical_reads / qs.execution_count AS [Avg Logical Reads]
	  , qs.total_physical_reads / qs.execution_count AS [Avg Physical Reads]
	  , (qs.total_elapsed_time / 1000.) / qs.execution_count AS [Avg Elapsed Time MS]
	, st.text
FROM sys.dm_exec_query_stats qs
CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle) st 
ORDER BY qs.total_logical_reads / qs.execution_count DESC -- Avg Logical Reads






----------------------------------------------------------
--  Find Statement in SP "TestProc" That uses most I/Os
----------------------------------------------------------
SELECT DB_NAME(st.dbid) AS DBNAME
    , OBJECT_SCHEMA_NAME(st.objectid,st.dbid) AS [Schema Name] 
    , OBJECT_NAME(st.objectid,st.dbid) AS [Object Name] 
    , SUBSTRING(st.text, CASE WHEN qs.statement_start_offset = 0 
                                OR qs.statement_start_offset IS NULL  
                              THEN 1 ELSE qs.statement_start_offset/2 + 1 END, 
                         CASE WHEN qs.statement_end_offset = 0 
                                OR qs.statement_end_offset = -1  
                                OR qs.statement_end_offset IS NULL  
                              THEN LEN(st.text)ELSE qs.statement_end_offset/2 END -  
                         CASE WHEN qs.statement_start_offset = 0 
                                 OR qs.statement_start_offset IS NULL 
                              THEN 1 ELSE qs.statement_start_offset/2  END + 1 
                  )  AS [Query Text]  
      , execution_count
      , qs.total_logical_reads / qs.execution_count as [AVG Logical I/O's]
      , qs.total_worker_time / 1000. AS [Total CPU MS]
	  , (qs.total_worker_time / 1000.) / qs.execution_count  AS [Avg CPU Time MS]
	  , qs.total_logical_reads / qs.execution_count AS [Avg Logical Reads]
	  , qs.total_physical_reads / qs.execution_count AS [Avg Physical Reads]
	  , (qs.total_elapsed_time / 1000.) / qs.execution_count AS [Avg Elapsed Time MS]
	, st.text
FROM sys.dm_exec_query_stats qs
CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle) st 
WHERE DB_NAME(st.dbid) = 'AdventureWorks'
  AND OBJECT_SCHEMA_NAME(st.objectid,st.dbid) = 'dbo'
  AND OBJECT_NAME(st.objectid,st.dbid) = 'TestProc'
ORDER BY qs.total_logical_reads / qs.execution_count DESC -- Avg Logical Reads

















---------------------------------------------------------------
-- showing execution plan information
---------------------------------------------------------------
SELECT 	qp.*, qs.*
FROM 
(SELECT DISTINCT plan_handle 
    , SUM(s.total_worker_time / 1000.) AS[Total CPU MS]
	, SUM(s.total_worker_time / 1000.) / SUM(s.execution_count)  AS [Avg CPU Time MS]
	, SUM(s.total_logical_reads / s.execution_count) AS [Avg Logical Reads]
	, SUM(s.total_physical_reads / s.execution_count) AS [Avg Physical Reads]
 FROM sys.dm_exec_query_stats s
 GROUP BY plan_handle) qs
CROSS APPLY sys.dm_exec_query_plan (qs.plan_handle) qp













--------------------------------------------------------------- 
-- Finding Queries that do Table and/or Index scans
---------------------------------------------------------------

SELECT 
  CASE WHEN (CAST(qp.query_plan AS NVARCHAR(MAX))LIKE '%TableScan%' 
       AND CAST(qp.query_plan AS NVARCHAR(MAX))LIKE '%IndexScan%' )
          THEN 'TableScan AND IndexScan' 
      WHEN CAST(qp.query_plan AS NVARCHAR(MAX))LIKE '%TableScan%'
          THEN 'TableScan'
          ELSE 'IndexScan' END [Type of Scan Operation]
  , qp.query_plan    
  , DB_NAME(qp.dbid) AS DBNAME
  , OBJECT_SCHEMA_NAME(qp.objectid,qp.dbid) AS [Schema Name] 
  , OBJECT_NAME(qp.objectid,qp.dbid) AS [Object Name] 
FROM 
(SELECT DISTINCT plan_handle    
    , SUM(s.total_worker_time / 1000.) AS[Total CPU MS]
	, SUM(s.total_worker_time / 1000.) / SUM(s.execution_count)  AS [Avg CPU Time MS]
	, SUM(s.total_logical_reads / s.execution_count) AS [Avg Logical Reads]
	, SUM(s.total_physical_reads / s.execution_count) AS [Avg Physical Reads]
  FROM sys.dm_exec_query_stats s
 GROUP BY plan_handle) qs
CROSS APPLY sys.dm_exec_query_plan (qs.plan_handle) qp
WHERE (CAST(qp.query_plan AS NVARCHAR(MAX))LIKE '%TableScan%' 
  OR CAST(qp.query_plan AS NVARCHAR(MAX))LIKE '%IndexScan%' )


















---------------------------------------------------------------
-- Exploring NULL DBID
---------------------------------------------------------------
SELECT st.*,qs.plan_handle 
FROM sys.dm_exec_query_stats qs
CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle) st














---------------------------------------------------------------
-- Exploring Plan Attributes
---------------------------------------------------------------
SELECT pa.*  
FROM sys.dm_exec_query_stats qs
CROSS APPLY sys.dm_exec_plan_attributes(qs.plan_handle) pa 
WHERE qs.plan_handle = 0x06000100BE667537B8202A08000000000000000000000000













---------------------------------------------------------------
-- Exploring Plan Attributes
--------------------------------------------------------------- 
SELECT DB_NAME(CAST(pa.value as INT)) AS [DB_NAME] 
FROM sys.dm_exec_query_stats qs
CROSS APPLY sys.dm_exec_plan_attributes(qs.plan_handle) pa 
WHERE qs.plan_handle = 0x06000100BE667537B8202A08000000000000000000000000
  AND attribute = 'dbid'











---------------------------------------------------------------
-- Expand by Showing Plan Attributes
---------------------------------------------------------------
SELECT COALESCE(DB_NAME(st.dbid), 
                DB_NAME(CAST(pa.value AS INT))+'*') AS [DBNAME]  
      , qp.dbid
      , OBJECT_SCHEMA_NAME(st.objectid,qp.dbid) AS [Schema Name] 
      , OBJECT_NAME(st.objectid,qp.dbid) AS [Object Name]   
      , SUBSTRING(st.text, CASE WHEN qs.statement_start_offset = 0 
                                OR qs.statement_start_offset IS NULL  
                                THEN 1 ELSE qs.statement_start_offset/2 + 1 END, 
                           CASE WHEN qs.statement_end_offset = 0 
                                OR qs.statement_end_offset = -1  
                                OR qs.statement_end_offset IS NULL  
                                THEN LEN(st.text)ELSE qs.statement_end_offset/2 END -  
                           CASE WHEN qs.statement_start_offset = 0 
                                 OR qs.statement_start_offset IS NULL 
                                THEN 1 ELSE qs.statement_start_offset/2  END + 1 
                  )  AS [Query Text]    
	, qs.execution_count 
	, qs.total_worker_time / 1000. AS [Total CPU MS]
	, (qs.total_worker_time / 1000.) / qs.execution_count  AS [Avg CPU Time MS]
	, qs.total_logical_reads / qs.execution_count AS [Avg Logical Reads]
	, qs.total_physical_reads / qs.execution_count AS [Avg Physical Reads]
FROM sys.dm_exec_query_stats qs
CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle) st 
CROSS APPLY sys.dm_exec_query_plan (qs.plan_handle) qp
CROSS APPLY sys.dm_exec_plan_attributes(qs.plan_handle) pa 
WHERE attribute = 'dbid'
ORDER BY qs.total_logical_reads / qs.execution_count DESC







---------------------------------------------------------------
-- Showing how a normal user can get these permissions
---------------------------------------------------------------
EXECUTE AS LOGIN = 'NormalUser'


SELECT *
FROM sys.dm_exec_query_stats qs
CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle) st 
CROSS APPLY sys.dm_exec_query_plan (qs.plan_handle) qp
CROSS APPLY sys.dm_exec_plan_attributes(qs.plan_handle) pa 
WHERE attribute = 'dbid' 
ORDER BY qs.total_logical_reads / qs.execution_count DESC














--------------------------------------------------------------
-- Grant VIEW SERVER STATE to User
---------------------------------------------------------------
REVERT -- Revert back to SysAdmin
 
GRANT VIEW SERVER STATE to NormalUser


-- Try again to see if normal user has permissions
EXECUTE AS LOGIN = 'NormalUser'

SELECT *
FROM sys.dm_exec_query_stats qs
CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle) st 
CROSS APPLY sys.dm_exec_query_plan (qs.plan_handle) qp
CROSS APPLY sys.dm_exec_plan_attributes(qs.plan_handle) pa 
WHERE attribute = 'dbid' 
ORDER BY qs.total_logical_reads / qs.execution_count DESC













---------------------------------------------------------------
-- Revert back to SysAdmin
---------------------------------------------------------------
REVERT
---------------------------------------------------------------
-- Remove VIEW SERVER STATE
---------------------------------------------------------------
REVOKE VIEW SERVER STATE to NormalUser





---------------------------------------------------------------
-- Looking at sys.dm_exec_query_optimizer_info to Show Optimizer Statistics
---------------------------------------------------------------

SELECT *
FROM sys.dm_exec_query_optimizer_info










---------------------------------------------------------------
-- Execute a query that is going to get optimize
---------------------------------------------------------------
SELECT TOP 1 * FROM sys.objects





--------------------------------------------------------------
-- Show new Optimizer Statistics
---------------------------------------------------------------
SELECT *
FROM sys.dm_exec_query_optimizer_info
 
 
 
 
 
 
 
 
 
 
 
 
 
--------------------------------------------------------------- 
-- Show number of INSERT optimizations
---------------------------------------------------------------
SELECT *
FROM sys.dm_exec_query_optimizer_info
WHERE counter = 'insert stmt'



-- Issue Insert statement
INSERT into DEMO.dbo.MyTable values (1, 'dm_exec_query_optimize_info444')

-- Show number of INSERT optimizations
SELECT *
FROM sys.dm_exec_query_optimizer_info
WHERE counter = 'insert stmt'










---------------------------------------------------------------
-- total optimization time 
---------------------------------------------------------------
SELECT occurrence * value AS [Total Optimization in Sec]
FROM sys.dm_exec_query_optimizer_info
WHERE counter = 'elapsed time' 







---------------------------------------------------------------
-- Calculate the Percentage of Optimization Time
---------------------------------------------------------------

-- Get Start Time
DECLARE @SecSinceStartTime BIGINT 
SELECT @SecSinceStartTime  = DATEDIFF(ss,login_time,GETDATE()) 
FROM sys.dm_exec_sessions WHERE session_id = 1

-- Get Seconds spend on optimization
DECLARE @OptimizeSeconds bigint
SELECT @OptimizeSeconds = occurrence * value 
FROM sys.dm_exec_query_optimizer_info
WHERE counter = 'elapsed time'

-- Percentage of optimization time 
SELECT (@OptimizeSeconds * 1.0 / @SecSinceStartTime) * 100 
                 AS [Percentage of Optimization Time]








---------------------------------------------------------------
-- Calculate the Percentage of Optimization Over A Time
---------------------------------------------------------------

-- Get Start Time
DECLARE @StartTime datetime 
SET @StartTime = getdate()

-- Get Seconds spend on optimization
DECLARE @OptimizeSeconds1 bigint
SELECT @OptimizeSeconds1 = occurrence * value 
FROM sys.dm_exec_query_optimizer_info
WHERE counter = 'elapsed time'

-- Wait for 10 Second
WAITFOR DELAY '00:00:10' 

DECLARE @OptimizeSeconds2 bigint
SELECT @OptimizeSeconds2= occurrence * value 
FROM sys.dm_exec_query_optimizer_info
WHERE counter = 'elapsed time'

DECLARE @SecSinceStartTime BIGINT 
SET @SecSinceStartTime=  DATEDIFF(ss,@StartTime ,GETDATE()) 

-- Percentage of optimization time 
SELECT ((@OptimizeSeconds2 - @OptimizeSeconds1) * 1.0 / @SecSinceStartTime) * 100 AS [Percentage of Optimization Time]




