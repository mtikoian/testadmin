---------------------------------------------------------------
-- Using sys.dm_os_performance_counters
---------------------------------------------------------------
SELECT * FROM sys.dm_os_performance_counters;















---------------------------------------------------------------
-- Calculating buffer cache hit ratio using base 
---------------------------------------------------------------
SELECT (a.CNTR_VALUE * 1.0 / b.CNTR_VALUE) * 100.0 [BUFFERCACHEHITRATIO]  
FROM (SELECT *, 1 x FROM sys.dm_os_performance_counters  
                  WHERE counter_name = 'BUFFER CACHE HIT RATIO' 
                    AND object_name = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' 
                                           THEN  'SQLSERVER:BUFFER MANAGER' 
                                           ELSE 'MSSQL$' + RTRIM(@@SERVICENAME) + ':BUFFER MANAGER' END ) a   
             JOIN  
            (SELECT *, 1 x FROM sys.dm_os_performance_counters   
                  WHERE counter_name = 'BUFFER CACHE HIT RATIO BASE' 
                    AND object_name = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' 
                                           THEN  'SQLSERVER:BUFFER MANAGER' 
                                           ELSE 'MSSQL$' + RTRIM(@@SERVICENAME) + ':BUFFER MANAGER' END ) b   
         ON a.X = b.X;
 
 
 
 
 
 
 
 
 
---------------------------------------------------------------
-- Finding the current page life expectancy
---------------------------------------------------------------         
SELECT cntr_value 'Page Life Expectancy'  
FROM sys.dm_os_performance_counters 
WHERE counter_name = 'Page life expectancy ' 
  AND object_name = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' 
                         THEN  'SQLServer:Buffer Manager' 
                         ELSE 'MSSQL$' + rtrim(@@SERVICENAME) + ':Buffer Manager' END
                         














---------------------------------------------------------------
-- Finding Page Reads/sec
---------------------------------------------------------------      
DECLARE @cntr_value int                         
SELECT @cntr_value = cntr_value FROM sys.dm_os_performance_counters  
WHERE counter_name = 'Page reads/sec' 
  AND object_name = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' 
                         THEN  'SQLServer:Buffer Manager' 
                         ELSE 'MSSQL$' + rtrim(@@SERVICENAME) + ':Buffer Manager' END 
                         
WAITFOR DELAY '00:00:10'

SELECT @cntr_value, cntr_value, CASE WHEN (cntr_value - @cntr_value) = 0 
                                     THEN 0
                                     ELSE (cntr_value - @cntr_value) / 10. END [Page reads/sec]
FROM sys.dm_os_performance_counters  
WHERE counter_name = 'Page reads/sec' 
  AND object_name = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' 
                         THEN  'SQLServer:Buffer Manager' 
                         ELSE 'MSSQL$' + rtrim(@@SERVICENAME) + ':Buffer Manager' END 
  
  
  
  
  
                         
---------------------------------------------------------------
-- Wait Statistics 
-- signal_wait_time_ms = Difference between the time the waiting thread was signaled and when it started running. 
-- wait_time_ms = Total wait time for this wait type in milliseconds. This time is inclusive of signal_wait_time_ms.
--------------------------------------------------------------- 
SELECT * FROM sys.dm_os_wait_stats; 






---------------------------------------------------------------
-- %Signal Waits on CPU (above 10%-15% indicates CPU pressure)
----------------------------------------------------------------                          
SELECT CAST(100.0 * SUM(signal_wait_time_ms) / SUM(wait_time_ms)
       AS NUMERIC(20,2)) AS [%signal (cpu) waits],
       CAST(100.0 * SUM(wait_time_ms - signal_wait_time_ms) / SUM(wait_time_ms)
        AS NUMERIC(20,2)) AS [%resource waits for all non-cpu waits]
FROM sys.dm_os_wait_stats
                           







---------------------------------------------------------------
-- %Signal Waits on CPU (above 10%-15% indicates CPU pressure)
----------------------------------------------------------------                          
SELECT CAST(100.0 * SUM(signal_wait_time_ms) / SUM(wait_time_ms)
       AS NUMERIC(20,2)) AS [%signal (cpu) waits],
       CAST(100.0 * SUM(wait_time_ms - signal_wait_time_ms) / SUM(wait_time_ms)
        AS NUMERIC(20,2)) AS [%resource waits for all non-cpu waits]
FROM sys.dm_os_wait_stats
WHERE wait_type not in -- remove system waits   
( 
'KSOURCE_WAKEUP', 'SLEEP_BPOOL_FLUSH', 'BROKER_TASK_STOP',
'XE_TIMER_EVENT', 'XE_DISPATCHER_WAIT', 'FT_IFTS_SCHEDULER_IDLE_WAIT',    
'SQLTRACE_BUFFER_FLUSH', 'CLR_AUTO_EVENT', 'BROKER_EVENTHANDLER',
'LAZYWRITER_SLEEP', 'BAD_PAGE_PROCESS', 'BROKER_TRANSMITTER', 
'CHECKPOINT_QUEUE', 'DBMIRROR_EVENTS_QUEUE', 'LAZYWRITER_SLEEP', 
'ONDEMAND_TASK_QUEUE', 'REQUEST_FOR_DEADLOCK_SEARCH', 'LOGMGR_QUEUE', 
'SLEEP_TASK', 'SQLTRACE_BUFFER_FLUSH', 'CLR_MANUAL_EVENT',
'BROKER_RECEIVE_WAITFOR', 'PREEMPTIVE_OS_GETPROCADDRESS', 
'PREEMPTIVE_OS_AUTHENTICATIONOPS', 'BROKER_TO_FLUSH'
) 

                
                
                
                
---------------------------------------------------------------
-- %Signal Waits  
----------------------------------------------------------------                          
SELECT *
FROM sys.dm_os_wait_stats
WHERE wait_type not in -- remove system waits   
( 
'KSOURCE_WAKEUP', 'SLEEP_BPOOL_FLUSH', 'BROKER_TASK_STOP',
'XE_TIMER_EVENT', 'XE_DISPATCHER_WAIT', 'FT_IFTS_SCHEDULER_IDLE_WAIT',    
'SQLTRACE_BUFFER_FLUSH', 'CLR_AUTO_EVENT', 'BROKER_EVENTHANDLER',
'LAZYWRITER_SLEEP', 'BAD_PAGE_PROCESS', 'BROKER_TRANSMITTER', 
'CHECKPOINT_QUEUE', 'DBMIRROR_EVENTS_QUEUE', 'LAZYWRITER_SLEEP', 
'ONDEMAND_TASK_QUEUE', 'REQUEST_FOR_DEADLOCK_SEARCH', 'LOGMGR_QUEUE', 
'SLEEP_TASK', 'SQLTRACE_BUFFER_FLUSH', 'CLR_MANUAL_EVENT',
'BROKER_RECEIVE_WAITFOR', 'PREEMPTIVE_OS_GETPROCADDRESS', 
'PREEMPTIVE_OS_AUTHENTICATIONOPS', 'BROKER_TO_FLUSH'
) 
ORDER BY signal_wait_time_ms DESC                         
                           
                         
WITH Waits AS
(SELECT wait_type, wait_time_ms / 1000 AS wait_time_s, 
   100. * wait_time_ms / sum(wait_time_ms) OVER () AS pct, 
   ROW_NUMBER() OVER(ORDER BY wait_time_ms DESC) as rn
 FROM sys.dm_os_wait_stats
 WHERE wait_type NOT IN 
 ( 
'KSOURCE_WAKEUP', 'SLEEP_BPOOL_FLUSH', 'BROKER_TASK_STOP',
'XE_TIMER_EVENT', 'XE_DISPATCHER_WAIT', 'FT_IFTS_SCHEDULER_IDLE_WAIT',    
'SQLTRACE_BUFFER_FLUSH', 'CLR_AUTO_EVENT', 'BROKER_EVENTHANDLER',
'LAZYWRITER_SLEEP', 'BAD_PAGE_PROCESS', 'BROKER_TRANSMITTER', 
'CHECKPOINT_QUEUE', 'DBMIRROR_EVENTS_QUEUE', 'LAZYWRITER_SLEEP', 
'ONDEMAND_TASK_QUEUE', 'REQUEST_FOR_DEADLOCK_SEARCH', 'LOGMGR_QUEUE', 
'SLEEP_TASK', 'SQLTRACE_BUFFER_FLUSH', 'CLR_MANUAL_EVENT',
'BROKER_RECEIVE_WAITFOR', 'PREEMPTIVE_OS_GETPROCADDRESS', 
'PREEMPTIVE_OS_AUTHENTICATIONOPS', 'BROKER_TO_FLUSH'
) ) -- Filter out some irrelevant wait types
 SELECT W1.wait_type
       ,CAST(W1.wait_time_s AS DECIMAL(12, 2)) AS wait_time_s
       ,CAST(W1.pct AS DECIMAL(12,2)) AS pct
       ,CAST(SUM(W2.pct) as DECIMAL(12,2)) as running_pct
 FROM Waits AS W1
 INNER JOIN Waits AS W2
 ON W2.rn <= W1.rn
 GROUP BY W1.rn, W1.wait_type, W1.wait_time_s, W1.pct
 HAVING SUM(W2.pct) - W1.pct < 96; -- Percentage threshold for wait     



















--------------------------------------------------------------
-- Show Data Pages Currently In Buffer Pool 
--------------------------------------------------------------
SELECT * FROM sys.dm_os_buffer_descriptors



--------------------------------------------------------------
-- Total page by page_type in Buffer Pool 
--------------------------------------------------------------
SELECT page_type,count(*) [Number of Pages] 
FROM sys.dm_os_buffer_descriptors
GROUP by page_type;


--------------------------------------------------------------
-- Total page by database in Buffer Pool 
--------------------------------------------------------------
SELECT CASE WHEN database_id = 32767 
            THEN 'Resouce'
            ELSE db_name(database_id) END AS [Database Name] 
      ,count(*) [Number of Pages]
      ,count(*) * 8192 / (1024 * 1024) AS [BP Memory MB]
FROM sys.dm_os_buffer_descriptors
GROUP by database_id
ORDER BY count(*) DESC;


-------------------------------------------------------------
-- What objects are in memory for current database
-- 
-- FROM: http://www.sqlteam.com/article/What-data-is-in-sql-server-memory
-------------------------------------------------------------
USE AdventureWorks;
GO
SELECT TOP 25 
	obj.[name],
	i.[name],
	i.[type_desc],
	count(*)AS Buffered_Page_Count ,
	count(*) * 8192 / (1024 * 1024) as Buffer_MB
    -- ,obj.name ,obj.index_id, i.[name]
FROM sys.dm_os_buffer_descriptors AS bd 
    INNER JOIN 
    (
        SELECT object_name(object_id) AS name 
            ,index_id ,allocation_unit_id, object_id
        FROM sys.allocation_units AS au
            INNER JOIN sys.partitions AS p 
                ON au.container_id = p.hobt_id 
                    AND (au.type = 1 OR au.type = 3)
        UNION ALL
        SELECT object_name(object_id) AS name   
            ,index_id, allocation_unit_id, object_id
        FROM sys.allocation_units AS au
            INNER JOIN sys.partitions AS p 
                ON au.container_id = p.hobt_id 
                    AND au.type = 2
    ) AS obj 
        ON bd.allocation_unit_id = obj.allocation_unit_id
LEFT JOIN sys.indexes i on i.object_id = obj.object_id AND i.index_id = obj.index_id
WHERE database_id = db_id()
GROUP BY obj.name, obj.index_id , i.[name],i.[type_desc]
ORDER BY Buffered_Page_Count DESC

---------------------------------------------------------------
-- Show system information with sys.dm_os_sys_info
---------------------------------------------------------------
SELECT * FROM sys.dm_os_sys_info





---------------------------------------------------------------
-- Calculate some additional information using sys.dm_os_sys_info
---------------------------------------------------------------
SELECT DATEADD(ms,ms_ticks * - 1, getdate()) AS WhenComputerStarted
    ,sqlserver_start_time AS WhenSQLStarted  -- new column with SQL 2008
	,cpu_count AS NumOfLogicalCPUs
	,cpu_count/hyperthread_ratio AS NumOfPhyicalCPUs
	,hyperthread_ratio AS NumOfCoresPerCPU
	,physical_memory_in_bytes / (1024*1024*1024) GBofPhysicalMemory
	,CASE WHEN virtual_memory_in_bytes / 1024 / (2048*1024) < 1 
		THEN 'False' 
        ELSE 'True' END AS [3GBSwitchON]
from sys.dm_os_sys_info











---------------------------------------------------------------
-- Memory Usage  
---------------------------------------------------------------
SELECT * FROM
sys.dm_os_memory_clerks 
-- explain different types


---------------------------------------------------------------
-- Memory Usage summorized by type
---------------------------------------------------------------
SELECT sum(*) FROM
sys.dm_os_memory_clerks 

 


---------------------------------------------------------------
-- Memory Usage for Single Pages
---------------------------------------------------------------
SELECT TOP(10) type, SUM(single_pages_kb) as [Memory Usage in KB]
FROM sys.dm_os_memory_clerks
GROUP BY type
ORDER BY SUM(single_pages_kb) DESC;
-- CACHESTORE_SQLCP - sql plans
-- CACHESTORE_OBJCP - object plans
-- CACHESTORE_PHDR  - parsed sql text that resolves table and column names



---------------------------------------------------------------
-- amount of memory consumed by BPool 
---------------------------------------------------------------
select 
    sum(multi_pages_kb  
        + virtual_memory_committed_kb 
        + shared_memory_committed_kb 
        + awe_allocated_kb)  / 1024 as [MB Used by Buffer Pool] 
from  
    sys.dm_os_memory_clerks  
where  
    type = 'MEMORYCLERK_SQLBUFFERPOOL'
    










---------------------------------------------------------------
-- Undocumented sys.dm_os_ring_buffers to Find CPU Utilization in last 60 intervals
---------------------------------------------------------------
select record_id,
	dateadd(ms, -1 * (cpu_ticks /( cpu_ticks / ms_ticks) - timestamp), GetDate())   as EventTime, 
		SQLProcessUtilization [SQL CPU],
		SystemIdle,
		100 - SystemIdle - SQLProcessUtilization as [Other CPU]
	from (
		select 
			record.value('(./Record/@id)[1]', 'int') as record_id,
			record.value('(./Record/SchedulerMonitorEvent/SystemHealth/SystemIdle)[1]', 'int') as SystemIdle,
			record.value('(./Record/SchedulerMonitorEvent/SystemHealth/ProcessUtilization)[1]', 'int') as SQLProcessUtilization,
			timestamp
		from (
			select timestamp, convert(xml, record) as record 
			from sys.dm_os_ring_buffers 
			where ring_buffer_type = N'RING_BUFFER_SCHEDULER_MONITOR'
			and record like '%<SystemHealth>%') as x
		) as y cross join sys.dm_os_sys_info
	order by record_id desc 



