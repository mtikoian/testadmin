USE AdventureWorks;
GO
CREATE PROC TestProc 
AS
DECLARE @ID INT;
SELECT @ID = ProductID FROM Production.Product;
SELECT @ID = PurchaseOrderID FROM Purchasing.PurchaseOrderDetail;
SELECT @ID = PurchaseOrderID FROM Purchasing.PurchaseOrderHeader;
SELECT @ID = A.PurchaseOrderID 
   FROM Purchasing.PurchaseOrderDetail A, 
        Purchasing.PurchaseOrderDetail B;
		
   