---------------------------------------------------------------
-- Using sys.dm_os_performance_counters
---------------------------------------------------------------
SELECT * FROM sys.dm_os_performance_counters;































---------------------------------------------------------------
-- Calculating buffer cache hit ratio using base 
---------------------------------------------------------------
SELECT (a.CNTR_VALUE * 1.0 / b.CNTR_VALUE) * 100.0 [BUFFERCACHEHITRATIO]  
FROM (SELECT *, 1 x FROM sys.dm_os_performance_counters  
         WHERE counter_name = 'BUFFER CACHE HIT RATIO' 
           AND object_name = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' 
                     THEN  'SQLSERVER:BUFFER MANAGER' 
                     ELSE 'MSSQL$' + RTRIM(@@SERVICENAME) + ':BUFFER MANAGER' END ) a   
             JOIN  
            (SELECT *, 1 x FROM sys.dm_os_performance_counters   
                  WHERE counter_name = 'BUFFER CACHE HIT RATIO BASE' 
                    AND object_name = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' 
                     THEN  'SQLSERVER:BUFFER MANAGER' 
                     ELSE 'MSSQL$' + RTRIM(@@SERVICENAME) + ':BUFFER MANAGER' END ) b   
         ON a.X = b.X;
 
 
 
 
 
 
 
 
 
---------------------------------------------------------------
-- Finding the current page life expectancy
---------------------------------------------------------------         
SELECT cntr_value 'Page Life Expectancy'  
FROM sys.dm_os_performance_counters 
WHERE counter_name = 'Page life expectancy ' 
  AND object_name = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' 
                         THEN  'SQLServer:Buffer Manager' 
                         ELSE 'MSSQL$' + rtrim(@@SERVICENAME) + ':Buffer Manager' END
                         














---------------------------------------------------------------
-- Finding Page Reads/sec
---------------------------------------------------------------      
DECLARE @cntr_value int                         
SELECT @cntr_value = cntr_value FROM sys.dm_os_performance_counters  
WHERE counter_name = 'Page reads/sec' 
  AND object_name = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' 
                         THEN  'SQLServer:Buffer Manager' 
                         ELSE 'MSSQL$' + rtrim(@@SERVICENAME) + ':Buffer Manager' END 
                         
WAITFOR DELAY '00:00:10'

SELECT @cntr_value, cntr_value, CASE WHEN (cntr_value - @cntr_value) = 0 
                                     THEN 0
                                     ELSE (cntr_value - @cntr_value) / 10. END [Page reads/sec]
FROM sys.dm_os_performance_counters  
WHERE counter_name = 'Page reads/sec' 
  AND object_name = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' 
                         THEN  'SQLServer:Buffer Manager' 
                         ELSE 'MSSQL$' + rtrim(@@SERVICENAME) + ':Buffer Manager' END 