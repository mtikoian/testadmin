--
-- Gets the general usage statistics for an index
--
SELECT  object_name(i.object_id) TableName,
        i.index_id,
        i.name,
        i.type_desc,
        i.fill_factor,
        s.user_seeks,
        s.user_scans,
        s.user_lookups,
        s.user_updates,
        s.last_user_seek,
        s.last_user_scan,
        s.last_user_lookup,
        s.last_user_update,
        i.is_disabled
	FROM    sys.indexes i
	join sys.objects o on o.object_id = i.object_id
	LEFT JOIN sys.dm_db_index_usage_stats s
		ON      i.object_id = s.object_id
				AND i.index_id = s.index_id
				AND database_id = db_id()
where i.object_id = object_id('person.person')
