SELECT
		SUBSTRING(st.TEXT , ( qs.statement_start_offset / 2 ) + 1 , ( ( CASE qs.statement_end_offset
                                                                      WHEN-1 THEN datalength(st.TEXT)
                                                                      ELSE qs.statement_end_offset
                                                                    END - qs.statement_start_offset ) / 2 ) + 1) AS SQLTEXT,
total_physical_reads + total_logical_reads as total_reads,
	(total_physical_reads + total_logical_reads) / execution_count avg_reads,
	execution_count,
	total_physical_reads,
	last_physical_reads, 
	min_physical_reads,
	max_physical_reads,
	total_logical_reads,
	last_logical_reads, 
	min_logical_reads,
	max_logical_reads,
	creation_time,
	last_execution_time,
	pl.query_plan
FROM
	sys.dm_exec_query_stats qs
	CROSS APPLY sys.dm_exec_sql_text(sql_handle) st
	CROSS APPLY sys.dm_exec_query_plan(plan_handle) pl
where st.text not like '%SCHEMA_NAME%'
ORDER BY avg_reads desc


