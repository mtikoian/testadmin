select s.session_id, s.host_name, s.program_name, s.status, s.last_request_start_time, s.last_request_end_time, r.blocking_session_id, r.status, r.command, r.wait_type, r.wait_resource, r.open_transaction_count,
	SUBSTRING(st.TEXT , ( r.statement_start_offset / 2 ) + 1 , ( ( CASE r.statement_end_offset
																  WHEN-1 THEN datalength(st.TEXT)
																  ELSE r.statement_end_offset
                                                                END - r.statement_start_offset ) / 2 ) + 1) AS SQLTEXT
	from sys.dm_exec_sessions s
	left join sys.dm_exec_requests r on s.session_id = r.session_id
	OUTER APPLY sys.dm_exec_sql_text(sql_handle) st	
	where (r.blocking_session_id is NULL or r.blocking_session_id = 0)
	  and exists (select 1 from sys.dm_exec_requests r1
					where r1.blocking_session_id = s.session_id)
UNION					
select s.session_id, s.host_name, s.program_name, s.status, s.last_request_start_time, s.last_request_end_time, r.blocking_session_id, r.status, r.command, r.wait_type, r.wait_resource, r.open_transaction_count,
	SUBSTRING(st.TEXT , ( r.statement_start_offset / 2 ) + 1 , ( ( CASE r.statement_end_offset
																  WHEN-1 THEN datalength(st.TEXT)
																  ELSE r.statement_end_offset
                                                                END - r.statement_start_offset ) / 2 ) + 1) AS SQLTEXT
    from sys.dm_exec_sessions s
	join sys.dm_exec_requests r on s.session_id = r.session_id
	CROSS APPLY sys.dm_exec_sql_text(sql_handle) st	
	where blocking_session_id <> 0;

select getdate(),
	request_session_id, 
	case resource_type
		when 'OBJECT' THEN object_name(resource_associated_entity_id)
		when 'PAGE' then object_name(p.object_id)
		when 'KEY' then object_name(p.object_id)
		else NULL
	end Object_Name,
	resource_type,
	request_mode,
	request_status,
	count(*) 
	from sys.dm_tran_locks l
	left join sys.partitions p on l.resource_associated_entity_id = p.hobt_id
	where resource_type in ('OBJECT', 'PAGE','KEY')
	group by request_session_id, resource_type, request_mode, request_status,
	 	case resource_type
			when 'OBJECT' THEN object_name(resource_associated_entity_id)
			when 'PAGE' then object_name(p.object_id)
			when 'KEY' then object_name(p.object_id)
			else NULL
		end;
