SELECT TOP 20 wait_type,
        case 
                  when wait_type like N'LCK_M_%' then N'Lock'
                  when wait_type like N'LATCH_%' then N'Latch'
                  when wait_type like N'PAGELATCH_%' then N'Buffer Latch'
                  when wait_type like N'PAGEIOLATCH_%' then N'Buffer IO'
                  when wait_type like N'RESOURCE_SEMAPHORE_%' then N'Compilation'
                  when wait_type = N'SOS_SCHEDULER_YIELD' then N'Scheduler Yield'
                  when wait_type in (N'LOGMGR', N'LOGBUFFER', N'LOGMGR_RESERVE_APPEND', N'LOGMGR_FLUSH', N'WRITELOG') then N'Logging'
                  when wait_type in (N'ASYNC_NETWORK_IO', N'NET_WAITFOR_PACKET') then N'Network IO'
                  when wait_type in (N'CXPACKET', N'EXCHANGE') then N'Parallelism'
                  when wait_type in (N'RESOURCE_SEMAPHORE', N'CMEMTHREAD', N'SOS_RESERVEDMEMBLOCKLIST') then N'Memory'
                  when wait_type like N'CLR_%' 
                    or wait_type like N'SQLCLR%' then N'CLR'
                  when wait_type like N'DBMIRROR%' 
                    or wait_type = N'MIRROR_SEND_MESSAGE' then N'Mirroring'
                  when wait_type like N'XACT%' 
                    or wait_type like N'DTC_%' 
                    or wait_type like N'TRAN_MARKLATCH_%' 
                    or wait_type like N'MSQL_XACT_%' 
                    or wait_type = N'TRANSACTION_MUTEX' then N'Transaction'
                  when wait_type like N'SLEEP_%' 
                    or wait_type in(N'LAZYWRITER_SLEEP', N'SQLTRACE_BUFFER_FLUSH', N'WAITFOR', N'WAIT_FOR_RESULTS') then N'Sleep'
                  else N'Other'
            end AS wait_category,
        waiting_tasks_count AS num_waits,
        wait_time_ms AS wait_time,
        (wait_time_ms / waiting_tasks_count) as wait_time_avg,
        cast(100. * wait_time_ms / SUM(wait_time_ms) OVER() as float) AS PctTime     -- Added this column
FROM          sys.dm_os_wait_stats e
WHERE         waiting_tasks_count > 0
              AND (wait_type NOT like N'SLEEP_%' 
                     AND wait_type NOT in(N'LAZYWRITER_SLEEP', N'SQLTRACE_BUFFER_FLUSH', N'WAITFOR', N'WAIT_FOR_RESULTS'))
--ORDER BY      PctTime DESC;
ORDER BY num_waits desc