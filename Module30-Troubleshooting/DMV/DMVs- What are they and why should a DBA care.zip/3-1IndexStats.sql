SELECT object_name(i.object_id) 'Table Name', 
		i.name as 'Index Name',
		index_type_desc,
		alloc_unit_type_desc,
		index_depth,
		avg_fragmentation_in_percent,
		page_count,
		fill_factor,
		record_count,
		min_record_size_in_bytes,
		max_record_size_in_bytes,
		avg_fragment_size_in_pages
	FROM sys.dm_db_index_physical_stats(db_id(), NULL, NULL, NULL , 'SAMPLED') ips					--Limited, Sampled, Detailed
	JOIN sys.indexes i on i.object_id = ips.object_id and i.index_id = ips.index_id
	where index_type_desc in ('CLUSTERED INDEX', 'NONCLUSTERED INDEX')
	  and avg_fragmentation_in_percent > 10
      and page_count > 1
	  and i.object_id > 100
    order by avg_fragmentation_in_percent desc
