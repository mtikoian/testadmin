select s.session_id, 
	s.login_name, 
	s.status,
	r.command, 
	r.blocking_session_id, 
	r.wait_type,
	r.wait_time,
	r.wait_resource,
	r.open_transaction_count, 
	t.is_user_transaction,
	substring(st.TEXT , ( r.statement_start_offset / 2 ) + 1 , ( ( CASE r.statement_end_offset
                                                                      WHEN-1 THEN datalength(st.TEXT)
                                                                      ELSE r.statement_end_offset
                                                                    END - r.statement_start_offset ) / 2 ) + 1) AS SQLTEXT,
	p.query_plan
	from sys.dm_exec_connections c
	left outer JOIN sys.dm_exec_sessions s on c.session_id = s.session_id
	left outer JOIN sys.dm_exec_requests r on s.session_id = r.session_id
	left outer join sys.dm_tran_session_transactions t on c.session_id = t.session_id
	outer apply sys.dm_exec_query_plan (r.plan_handle) p
	outer apply sys.dm_exec_sql_text(r.sql_handle) st


Create Table LockSessionInfo (
	Timestamp		datetime,
	ServerName		sysname,
	ServiceName		sysname,
	SessionsID		smallint,
	LoginName		nvarchar(128),
	Status			nvarchar(30),
	Command			nvarchar(16),
	BlockingSID		smallint,
	WaitType		nvarchar(60),
	WaitTime		int,
	WaitResource	nvarchar(256),
	OpenTranCnt		int,
	UserTransactin	bit,
	SQLText			nvarchar(max),
	SQLPlan			xml
	CONSTRAINT pk_LockSessionInfo PRIMARY KEY (Timestamp, Servername, ServiceName, SessionsID)) 
	
insert into LockSessionInfo	
select GETDATE(), 
	@@SERVERNAME,
	@@SERVICENAME,
	s.session_id,
	s.login_name, 
	s.status,
	r.command, 
	r.blocking_session_id, 
	r.wait_type,
	r.wait_time,
	r.wait_resource,
	r.open_transaction_count, 
	t.is_user_transaction,
	substring(st.TEXT , ( r.statement_start_offset / 2 ) + 1 , ( ( CASE r.statement_end_offset
                                                                      WHEN-1 THEN datalength(st.TEXT)
                                                                      ELSE r.statement_end_offset
                                                                    END - r.statement_start_offset ) / 2 ) + 1) AS SQLTEXT,
	p.query_plan
	from sys.dm_exec_connections c
	left outer JOIN sys.dm_exec_sessions s on c.session_id = s.session_id
	left outer JOIN sys.dm_exec_requests r on s.session_id = r.session_id
	left outer join sys.dm_tran_session_transactions t on c.session_id = t.session_id
	outer apply sys.dm_exec_query_plan (r.plan_handle) p
	outer apply sys.dm_exec_sql_text(r.sql_handle) st


select ServerName, ServiceName, Timestamp, COUNT(*)
	from LockSessionInfo
	where (BlockingSID is not NULL and BlockingSID <> 0)
	group by ServerName, ServiceName, Timestamp
	order by ServerName, ServiceName, Timestamp
