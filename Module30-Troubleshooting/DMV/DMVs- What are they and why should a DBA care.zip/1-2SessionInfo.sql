select s.session_id, 
	s.login_name, 
	s.cpu_time, 
	s.reads tot_reads, 
	s.writes tot_writes,
	r.reads cur_reads,
	r.writes cur_writes,
	r.statement_start_offset, 
	r.statement_end_offset,
	substring(st.TEXT , ( r.statement_start_offset / 2 ) + 1 , ( ( CASE r.statement_end_offset
                                                                      WHEN-1 THEN datalength(st.TEXT)
                                                                      ELSE r.statement_end_offset
                                                                    END - r.statement_start_offset ) / 2 ) + 1) AS SQLTEXT,
	p.query_plan
	from sys.dm_exec_connections c
	left outer JOIN sys.dm_exec_sessions s on c.session_id = s.session_id
	left outer JOIN sys.dm_exec_requests r on s.session_id = r.session_id
	outer apply sys.dm_exec_query_plan (r.plan_handle) p
	outer apply sys.dm_exec_sql_text(r.sql_handle) st
	where s.session_id <> @@SPID
	


