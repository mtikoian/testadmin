USE AdventureWorks -- Or AdventureWorks2008 or AdventureWorks2012
GO
------------------------------------------------------------------------------------------------------------------------
--------------------------------------------How Many DMVs are There?----------------------------------------------------
------------------------------------------------------------------------------------------------------------------------
-- How many DMVs are there?
SELECT name, type, type_desc FROM sys.system_objects WHERE name LIKE 'dm_%' ORDER BY name
------------------------------------------------------------------------------------------------------------------------
--------------------------------------------Operating System DMV Examples-----------------------------------------------
------------------------------------------------------------------------------------------------------------------------

-- View current waits by wait_type.  Gives aggregated # of waits and wait time for each type of wait.
-- dm_os_wait_stats is cumulative since SQL Server last restarted
-- Waits with zeroes in all columns can be ignored as they have not taken place since SQL Server was started up.
SELECT
*
FROM sys.dm_os_wait_stats

-- Example query that will show the total % wait time for each wait type since last restart
-- A query later in this file shows how to get a list of current waits.
;WITH Waits AS 
( 
SELECT  
	wait_type,  
	wait_time_ms / 1000. AS wait_time_s, 
	100. * wait_time_ms / SUM(wait_time_ms) OVER() AS PCNT, 
	ROW_NUMBER() OVER(ORDER BY wait_time_ms DESC) AS ROWNUM 
FROM sys.dm_os_wait_stats 
WHERE wait_type  
NOT IN 
('CLR_SEMAPHORE', 'LAZYWRITER_SLEEP', 'RESOURCE_QUEUE', 
'SLEEP_TASK', 'SLEEP_SYSTEMTASK', 'SQLTRACE_BUFFER_FLUSH', 'WAITFOR', 
'CLR_AUTO_EVENT', 'CLR_MANUAL_EVENT') 
) -- filter out irrelevant waits 
SELECT W1.wait_type, 
CAST(W1.wait_time_s AS DECIMAL(12, 2)) AS wait_time_s, 
CAST(W1.PCNT AS DECIMAL(12, 2)) AS pct, 
CAST(SUM(W2.PCNT) AS DECIMAL(12, 2)) AS running_pct 
FROM Waits AS W1 
INNER JOIN Waits AS W2 ON W2.ROWNUM <= W1.ROWNUM 
GROUP BY W1.ROWNUM,  
W1.wait_type,  
W1.wait_time_s,  
W1.PCNT 
HAVING SUM(W2.PCNT) - W1.PCNT < 99; -- percentage threshold;

-- Operating system details---very simple!
-- This view is new as of SQL Server 2008R2 Service Pack 1
SELECT
	*
FROM sys.dm_os_windows_info

-- A single row view with a ton of data about the SQL Server host as well as resources that are being used
-- by SQL Server itself.
SELECT
	*
FROM sys.dm_os_sys_info

-- Returns a row for every performance counter that the server maintains, providing the current value.
-- This perfmon data is current and needs to be saved in order to be trended/analyzed.  Perfmon
-- counters are ONLY available for instance-level metrics, not host level (if you're running a cluster).
SELECT
	* 
FROM sys.dm_os_performance_counters

-- This DMV provides quick access to all registry settings for the locally installed SQL Server.  This allows you to verify system 
-- settings that might be otherwise inconvenient to locate information about.
-- This view is new as of SQL Server 2008R2 Service Pack 1
SELECT
	*
FROM sys.dm_server_registry

-- Example of using the perfmon DMV to get the buffer cache hit ratio.  The server name before the colon
-- is the name of the SQL server instance
SELECT
	ROUND(CAST(A.cntr_value1 AS NUMERIC) / CAST(B.cntr_value2 AS NUMERIC), 3) AS Buffer_Cache_Hit_Ratio
FROM
(
	SELECT
		cntr_value AS cntr_value1
	FROM sys.dm_os_performance_counters
	WHERE object_name = 'MSSQL$EDSQLSERVER:Buffer Manager'
	AND counter_name = 'Buffer cache hit ratio'
) AS A,
(
	SELECT
		cntr_value AS cntr_value2
	FROM sys.dm_os_performance_counters
	WHERE object_name = 'MSSQL$EDSQLSERVER:Buffer Manager'
	AND counter_name = 'Buffer cache hit ratio base'
) AS B;

-- How to grab a static value perfmon counter.  The server name before the colon
-- is the name of the SQL server instance.  This can be a great way to get CPU & memory data
-- for individual SQL instances in a clustered environment.
SELECT
	* 
FROM sys.dm_os_performance_counters
WHERE object_name = 'MSSQL$EDSQLSERVER:General Statistics'
AND (counter_name = 'User Connections'
OR counter_name = 'Logical Connections')

-- We can verify those numbers with sp_who:
EXEC sp_who

-- sys.dm_os_volume_stats was added in SQL Server 2008 R2 SP1, and is available in all versions since.
-- This can be used to get a cross of DB sizes AND drive space, the latter of which can be annoying to
-- get via TSQL otherwise:
SELECT
	DB_NAME(f.database_id) DatabaseName,
	f.FILE_ID,
	f.name,
	f.physical_name,
	size DBSize,
	file_system_type,
	volume_mount_point,
	total_bytes,
	available_bytes
FROM sys.master_files AS f
CROSS APPLY sys.dm_os_volume_stats(f.database_id, f.FILE_ID)

-- Show only the data for the mount point of the current database that you are connected to
SELECT 
	database_id,
	f.file_id,
	volume_mount_point,
	total_bytes,
	available_bytes
FROM sys.database_files AS f
CROSS APPLY sys.dm_os_volume_stats(DB_ID(), f.file_id);

------------------------------------------------------------------------------------------------------------------------
--------------------------------------------Index DMV Examples----------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------
-- Index Stats DMV that provides raw index usage data for all indexes on the SQL instance.
-- These views are populated cumulatively since your last server restart, so in order to effectively use them,
-- you must store this data and track/trend it over time.
SELECT
* 
FROM sys.dm_db_index_usage_stats -- This DMV returns indexes for the entire server (all databases)

SELECT -- You can't do this!  Requires parameters!
*
FROM sys.dm_db_index_physical_stats

SELECT -- Returns some physical index stats for AdventureWorks w/ detailed mode
	* -- Be sure to filter as much as possible...this can return a lot of data if you don't filter by database and table.
FROM sys.dm_db_index_physical_stats(db_id('AdventureWorks'), OBJECT_ID(N'Production.ProductInventory'), NULL, NULL , 'DETAILED') IPS
INNER JOIN sys.indexes SI
ON SI.index_id = IPS.index_id
INNER JOIN sys.objects SO
ON SO.object_id = SI.object_id
AND IPS.object_id = SO.object_id
WHERE SI.name = 'PK_ProductInventory_ProductID_LocationID'

-- Returns fragmentation stats for AdventureWorks - only for user objects, not MS system objects.
-- Sorts by table name and then index name.
SELECT object_name(IPS.object_id) AS [TableName], 
   SI.name AS [IndexName], 
   IPS.Index_type_desc, 
   IPS.avg_fragmentation_in_percent, 
   IPS.avg_fragment_size_in_pages, 
   IPS.avg_page_space_used_in_percent, 
   IPS.record_count, 
   IPS.ghost_record_count,
   IPS.fragment_count, 
   IPS.avg_fragment_size_in_pages
FROM sys.dm_db_index_physical_stats(db_id('AdventureWorks'), NULL, NULL, NULL , 'DETAILED') IPS
   INNER JOIN sys.tables ST
   ON IPS.object_id = ST.object_id
   INNER JOIN sys.indexes SI
   ON IPS.object_id = SI.object_id 
   AND IPS.index_id = SI.index_id
WHERE ST.is_ms_shipped = 0 -- non-system tables only
ORDER BY object_name(IPS.object_id), SI.name

SELECT -- All operational stats for AdventureWorks
*
FROM sys.dm_db_index_operational_stats (db_id('AdventureWorks2012'), NULL, NULL, NULL)

-- Returns latching index details for all non-system tables in AdventureWorks
SELECT 
	object_schema_name(IOS.object_id) + '.' + object_name(IOS.object_id) as objectName,
    SI.name,
	CASE WHEN is_unique = 1 then 'UNIQUE ' ELSE '' END + SI.type_desc AS index_type,
    page_latch_wait_count,
	page_io_latch_wait_count
FROM sys.dm_db_index_operational_stats(db_id(),null,null,null) AS IOS
     INNER join sys.indexes SI
     ON SI.object_id = IOS.object_id
     AND SI.index_id = IOS.index_id
	 INNER JOIN sys.tables ST -- Join this just so we can get the is_ms_shipped column
	 ON ST.object_id = SI.object_id
	 WHERE ST.is_ms_shipped = 0 -- non-system tables only
ORDER BY page_latch_wait_count + page_io_latch_wait_count DESC

-- These DMVs store data on missing indexes.  If a query is run and it could benefit from an index that is not
-- currently implemented, then rows will be added to these DMVs describing the missing indexes and their potential impact.
-- BEWARE: Microsft suggests lots of indexes---many are not very helpful or generic enough to be useful.  Always
-- test and gauge a new index thoroughly to determine if it is needed, and if the form suggested makes sense.
SELECT
*
FROM sys.dm_db_missing_index_groups
SELECT
*
FROM sys.dm_db_missing_index_group_stats
SELECT
*
FROM sys.dm_db_missing_index_details 
SELECT
*
FROM sys.dm_db_missing_index_columns(1) -- Needs a parameter of an index_handle

SELECT -- Get a row-by-row column list for all missing indexes
*
FROM sys.dm_db_missing_index_details
CROSS APPLY sys.dm_db_missing_index_columns(index_handle)

-- This query uses data from 3 DMVs as well as sys.databases to create a very useful view of where indexes may
-- be missing in production.  Beware wide indexes or those that do not help frequently.
SELECT
		ROW_NUMBER() OVER (ORDER BY MIGS.avg_user_impact) AS id,
		MIGS.avg_total_user_cost * ( MIGS.avg_user_impact / 100.0 )
        * ( MIGS.user_seeks + MIGS.user_scans ) AS [Improvement Measure],
        'CREATE INDEX [missing_index_'
        + CONVERT (VARCHAR, MIG.index_group_handle) + '_'
        + CONVERT (VARCHAR, MID.index_handle) + '_'
        + LEFT(PARSENAME(MID.statement, 1), 32) + ']' + ' ON ' + MID.statement
        + ' (' + ISNULL(MID.equality_columns, '')
        + CASE WHEN MID.equality_columns IS NOT NULL
                    AND MID.inequality_columns IS NOT NULL THEN ','
               ELSE ''
          END + ISNULL(MID.inequality_columns, '') + ')' + ISNULL(' INCLUDE ('
                                                              + MID.included_columns
                                                              + ')', '') AS [Index Create Statement],
        MIGS.unique_compiles AS [Benefiting Compiles],
        MIGS.user_seeks AS [User Seeks],
        MIGS.last_user_seek AS [Last User Seek],
        MIGS.avg_total_user_cost AS [Average Total User Cost],
        MIGS.avg_user_impact AS [Average User Impact],
        SD.name AS [Database Name],
        REVERSE(SUBSTRING(REVERSE(MID.statement), 2, (CHARINDEX('[', REVERSE(MID.statement), 2)) - 2)) AS [Table Name],
        ISNULL((LEN(MID.equality_columns) -  LEN(REPLACE(REPLACE(MID.equality_columns, '[', ''), ']', ''))) / 2, 0) AS equality_column_number,
        ISNULL((LEN(MID.inequality_columns) -  LEN(REPLACE(REPLACE(MID.inequality_columns, '[', ''), ']', ''))) / 2, 0) AS inequality_column_number,
        ISNULL((LEN(MID.included_columns) -  LEN(REPLACE(REPLACE(MID.included_columns, '[', ''), ']', ''))) / 2, 0) AS included_column_number 
FROM    sys.dm_db_missing_index_groups MIG
        INNER JOIN sys.dm_db_missing_index_group_stats MIGS
        ON migs.group_handle = MIG.index_group_handle
        INNER JOIN sys.dm_db_missing_index_details MID
        ON MIG.index_handle = MID.index_handle
        INNER JOIN sys.databases SD
        ON SD.database_id = MID.database_id
WHERE   MIGS.avg_total_user_cost * ( MIGS.avg_user_impact / 100.0 )
        * ( MIGS.user_seeks + MIGS.user_scans ) > 10
ORDER BY MIGS.avg_total_user_cost * MIGS.avg_user_impact * ( MIGS.user_seeks + MIGS.user_scans ) DESC

-- Query to see index usage stats with index/table name
SELECT 
	ST.name AS [table_name],
	SI.name AS [index_name],
	IUS.user_seeks,
	IUS.user_scans,
	IUS.user_lookups,
	IUS.user_updates,
	IUS.last_user_seek,
	IUS.last_user_scan,
	IUS.last_user_lookup,
	IUS.last_user_update
FROM sys.dm_db_index_usage_stats IUS
INNER JOIN sys.indexes SI
ON SI.object_id = IUS.object_id
AND SI.index_id = IUS.index_id
LEFT JOIN sys.tables ST
ON ST.object_id = SI.object_id

-- Example of a query & schema to collect usage data on a regular basis
-- This creates schema to store index data.  If your work is on a single database, then the cursor can be eliminated
-- and the SQL updated to just return data on a single database, rather than iterating through sys.databases.
IF NOT EXISTS (SELECT * FROM sys.objects WHERE type = 'U' AND name = 'db_index_usage_stats_sample_id')
BEGIN
	CREATE TABLE AdventureWorks.dbo.db_index_usage_stats_sample_id
	(
		sample_id INT IDENTITY(1,1),
		sample_date DATETIME
	)
END

INSERT INTO AdventureWorks.dbo.db_index_usage_stats_sample_id
(
	sample_date 
) VALUES
(
	GETDATE()
)
	
IF NOT EXISTS (SELECT * FROM sys.objects WHERE type = 'U' AND name = 'db_index_usage_stats')
BEGIN
	CREATE TABLE AdventureWorks.dbo.db_index_usage_stats
	(
		sample_id INT,
		database_name VARCHAR(250),
		table_name VARCHAR(250),
		index_name VARCHAR(250) ,
		user_seeks BIGINT,
		user_scans BIGINT,
		user_lookups BIGINT,
		user_updates BIGINT,
		last_user_seek DATETIME,
		last_user_scan DATETIME,
		last_user_lookup DATETIME,
		last_user_update DATETIME
	)
END

DECLARE @CMD VARCHAR(MAX)
DECLARE @database VARCHAR(100)

DECLARE dbcursor CURSOR FOR
SELECT SD.name FROM sys.databases SD
WHERE SD.name NOT IN
(
	'master',
	'tempdb',
	'model',
	'msdb'
)
OPEN dbcursor
FETCH NEXT FROM dbcursor INTO @database

WHILE @@FETCH_STATUS = 0
BEGIN
	SET @CMD = 'USE ' + @database + '
	INSERT INTO AdventureWorks.dbo.db_index_usage_stats
		    (   sample_id ,
		        database_name ,
		        table_name ,
		        index_name ,
		        user_seeks ,
		        user_scans ,
		        user_lookups ,
		        user_updates ,
		        last_user_seek ,
		        last_user_scan ,
		        last_user_lookup ,
		        last_user_update
		    )
	SELECT 
		(SELECT MAX(SSID.sample_id) FROM AdventureWorks.dbo.db_index_usage_stats_sample_id SSID),
		'''+ @database  + ''' AS [database_name],
		ST.name AS [table_name],
		SI.name AS [index_name],
		IUS.user_seeks,
		IUS.user_scans,
		IUS.user_lookups,
		IUS.user_updates,
		IUS.last_user_seek,
		IUS.last_user_scan,
		IUS.last_user_lookup,
		IUS.last_user_update
	FROM ' + @database + '.sys.dm_db_index_usage_stats IUS
	INNER JOIN ' + @database + '.sys.indexes SI
	ON SI.object_id = IUS.object_id
	AND SI.index_id = IUS.index_id
	LEFT JOIN ' + @database + '.sys.tables ST
	ON ST.object_id = SI.object_id
	WHERE IUS.database_id = (SELECT DB_ID(''' + @database + '''))
	'
	EXEC (@CMD)
	FETCH NEXT FROM dbcursor INTO @database
END
CLOSE dbcursor
DEALLOCATE dbcursor

-- View collected data:
SELECT * FROM AdventureWorks.dbo.db_index_usage_stats_sample_id -- 1 row for each data collection run
SELECT * FROM AdventureWorks.dbo.db_index_usage_stats -- 1 row per index per data collection run
-- From here you can aggregate, compare, and trend index usage over time and determine:
-- 1. Unused indexes (few or no seeks/scans/lookups)
-- 2. Misused indexes (lots of scans, few/no seeks)
-- 3. Underused indexes (ratio of reads to writes is low)
-- 4. Overall index activity & how often a table is read/written.
------------------------------------------------------------------------------------------------------------------------
--------------------------------------------I/O Related DMVs------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------
-- View file I/O stats for AdventureWorks with corresponding master file data
SELECT
*
FROM sys.dm_io_virtual_file_stats(DB_ID(N'AdventureWorks'), NULL) VFS
INNER JOIN sys.master_files MF
ON MF.file_id = VFS.file_id
AND MF.database_id = DB_ID(N'AdventureWorks')

-- View pending I/O requests for SQL Server
SELECT 
* 
FROM sys.dm_io_pending_io_requests IOR
INNER JOIN sys.dm_io_virtual_file_stats (DB_ID(), NULL) VFS
ON (VFS.file_handle = IOR.io_handle)
INNER JOIN sys.database_files DF ON (DF.FILE_ID = VFS.FILE_ID)

-- Returns any cluster shared drives associated with this SQL Server, or an empty rowset if not clustered.
SELECT
	*
FROM sys.dm_io_cluster_shared_drives
------------------------------------------------------------------------------------------------------------------------
--------------------------------------------Query Stat DMVs-------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------

-- Presents the current waits on the database instance with quite a bit of useful data
SELECT     
	GETDATE() sample_Time,     
	SP.spid,     
	SP.blocked AS blocking,     
	db_name(SP.dbid) as DatabaseName,     
	SP.waittime,     
	SUBSTRING(SP.waitresource,1,20) as waitresrc,     
	SP.lastwaittype,     
	SUBSTRING(SP.hostname,1,20) As hostname,     
	LEFT(SP.program_name, 20) AS program,     
	SUBSTRING(SP.loginame,1,30) AS login_name,     
	SP.cmd  ,     
	SP.SQL_Handle AS [sql_handle],
	Substring(ST.text, 1, 4000) AS sql_text,  
	CASE    
	WHEN st.text LIKE '%CREATE PROCEDURE%'     
	THEN '/* PROC: */ ' + SUBSTRING(st.text, CHARINDEX('CREATE PROCEDURE ', st.text) + 17, 60) + ' ... '    
	ELSE SUBSTRING(st.text, 1, 60) + ' ...'   
	END AS Begin_SQL,    
	CASE    
	WHEN st.text LIKE '%CREATE PROCEDURE%' THEN '/* PROC - SEE SOURCE CODE */'    
	ELSE RTRIM(st.text)
	END AS Whole_Script,      
	Substring(     
	SUBSTRING(st.text, (req.statement_start_offset/2)+1,     
	((CASE req.statement_end_offset    
	WHEN -1 THEN DATALENGTH(st.text)    
	ELSE req.statement_end_offset    
	END - req.statement_start_offset)/2) + 1)     
	, 1, 8000)         
	AS Wait_SQL     
FROM master.dbo.SYSPROCESSES SP    
OUTER APPLY master.sys.dm_exec_sql_text(SP.sql_handle) ST    
LEFT JOIN master.sys.dm_exec_requests req on SP.sql_handle = req.sql_handle      
WHERE     
SP.SPID >50 AND     
SP.waittime>0 and     
SP.status <> 'background'
AND SP.LastWaitType != 'TRACEWRITE'    
AND SP.LastWaitType NOT LIKE '%WAITFOR%'     
ORDER BY SP.SPID

-- Contents of dm_exec_query_stats (only shows query stats for what is currently 
SELECT
*
FROM sys.dm_exec_query_stats

-- Query stats, joined together and sorted by logical reads.
SELECT TOP 20
	DB_NAME(qt.dbid) AS [Database_Name],
	SUBSTRING(qt.text, (qs.statement_start_offset/2)+1,
	((CASE qs.statement_end_offset
	WHEN -1 THEN DATALENGTH(qt.TEXT)
	ELSE qs.statement_end_offset
	END - qs.statement_start_offset)/2)+1) AS [Query_Text],
	qs.execution_count AS [Execution_Count],
	qs.total_logical_reads AS [Total_Logical_Reads],
	qs.last_logical_reads AS [Last_Logical_Reads],
	qs.total_logical_writes AS [Total_Logical_Writes],
	qs.last_logical_writes AS [Last_Logical_Writes],
	qs.total_worker_time AS [Total_Worker_Time],
	qs.last_worker_time AS [Last_Worker_Time],
	qs.total_elapsed_time/1000000 AS [Total_Elapsed_Time_In_S],
	qs.last_elapsed_time/1000000 AS [Last_Elapsed_Time_In_S],
	qs.last_execution_time AS [Last_Execution_Time],
	qp.query_plan AS [Query_Plan],
	tqp.query_plan AS [Text_Query_Plan],
	pa.*
FROM sys.dm_exec_query_stats qs
CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle) qt
CROSS APPLY sys.dm_exec_query_plan(qs.plan_handle) qp
CROSS APPLY sys.dm_exec_text_query_plan(qs.plan_handle, 0, -1) tqp
CROSS APPLY sys.dm_exec_plan_attributes (qs.plan_handle) pa
WHERE pa.attribute = 'hits_exec_context'
ORDER BY qs.total_logical_reads DESC -- logical reads
--ORDER BY qs.total_worker_time DESC -- CPU time
--ORDER BY qs.total_logical_writes DESC -- logical writes
--ORDER BY qs.execution_count DESC -- execution count
------------------------------------------------------------------------------------------------------------------------
--------------------------------------------Query Optimizer DMV---------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------
-- Return current query optimizer info
SELECT * FROM sys.dm_exec_query_optimizer_info

-- Return the before & after query optimizer info in order to get a diff
-- This allows for a direct analysis of how the specific query was optimized

-- Have these SELECT statements appear here so they are optimized
-- now and do not pollute stats later
SELECT
*
INTO after_query_optimizer_info
FROM sys.dm_exec_query_optimizer_info
GO
SELECT
*
INTO before_query_optimizer_info
FROM sys.dm_exec_query_optimizer_info
GO
DROP TABLE before_query_optimizer_info
GO
DROP TABLE after_query_optimizer_info
GO

SELECT
*
INTO before_query_optimizer_info
FROM sys.dm_exec_query_optimizer_info
GO

-- This is our test query to be optimized and analyzed
SELECT
	LastName,
	FirstName,
	MiddleName
FROM Person.Person
WHERE EmailPromotion = 2
OR LastName LIKE 'S%'
OPTION (RECOMPILE) -- Force a new execution plan to be compiled
GO

SELECT
*
INTO after_query_optimizer_info
FROM sys.dm_exec_query_optimizer_info
GO

SELECT
	after.counter,
	(after.occurrence - before.occurrence) AS occurrence,
	(after.occurrence * after.value - before.occurrence * before.value) AS value
FROM before_query_optimizer_info before
INNER JOIN after_query_optimizer_info after
ON before.counter = after.counter
WHERE before.occurrence <> after.occurrence -- Don't include counters that didn't change!
GO

DROP TABLE before_query_optimizer_info
DROP TABLE after_query_optimizer_info
GO

------------------------------------------------------------------------------------------------------------------------
---------------------------------------------Query Transformation Stats DMV---------------------------------------------
------------------------------------------------------------------------------------------------------------------------
-- These DMVs are not documented.  Google at your own risk!

-- View current query optimizer transformational stats
SELECT * FROM sys.dm_exec_query_transformation_stats

-- Return the before & after query transformation stats in order to get a diff
-- This allows for a direct analysis of the transformation rules that were
-- used in the optimization of the query

-- Have these SELECT statements appear here so they are optimized
-- now and do not pollute stats later
SELECT
*
INTO before_query_transformation_stats
FROM sys.dm_exec_query_transformation_stats
GO
SELECT
*
INTO after_query_transformation_stats
FROM sys.dm_exec_query_transformation_stats
GO
DROP TABLE after_query_transformation_stats
DROP TABLE before_query_transformation_stats

GO
SELECT
*
INTO before_query_transformation_stats
FROM sys.dm_exec_query_transformation_stats
GO
-- This is our test query to be optimized and analyzed
SELECT
	LastName,
	FirstName,
	MiddleName
FROM Person.Person
WHERE EmailPromotion = 2
OR LastName LIKE 'S%'
OPTION (RECOMPILE) -- Force a new execution plan to be compiled

SELECT
*
INTO after_query_transformation_stats
FROM sys.dm_exec_query_transformation_stats
GO

SELECT
after.name,
(after.promised - before.promised) as promised
FROM before_query_transformation_stats before
JOIN after_query_transformation_stats after
ON before.name = after.name
WHERE before.succeeded <> after.succeeded

DROP TABLE before_query_transformation_stats
DROP TABLE after_query_transformation_stats
------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------