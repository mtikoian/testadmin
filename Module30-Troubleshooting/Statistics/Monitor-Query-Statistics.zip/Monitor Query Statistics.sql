-- Create the "C:\QueryStatistics" folder to hold the database files

USE
	master;
GO


EXECUTE sys.sp_configure
	@configname		= 'show advanced options' ,
	@configvalue	= 1;
GO


RECONFIGURE;
GO


EXECUTE sys.sp_configure
	@configname		= 'xp_cmdshell' ,
	@configvalue	= 1;
GO


RECONFIGURE;
GO


EXECUTE sys.xp_cmdshell
	N'md C:\QueryStatistics' ,
	no_output;
GO


EXECUTE sys.sp_configure
	@configname		= 'xp_cmdshell' ,
	@configvalue	= 0;
GO


RECONFIGURE;
GO


EXECUTE sys.sp_configure
	@configname		= 'show advanced options' ,
	@configvalue	= 0;
GO


RECONFIGURE;
GO


-- Create the "QueryStatistics" database

IF
	DB_ID (N'QueryStatistics') IS NOT NULL
BEGIN

	ALTER DATABASE
		QueryStatistics
	SET
		SINGLE_USER
	WITH
		ROLLBACK IMMEDIATE;

	DROP DATABASE
		QueryStatistics;

END;
GO


CREATE DATABASE
	QueryStatistics
ON PRIMARY
(
	NAME		= N'QueryStatistics_Data' ,
	FILENAME	= N'C:\QueryStatistics\QueryStatistics_Data.mdf' ,
	SIZE		= 10GB ,
	FILEGROWTH	= 10%
)
LOG ON
(
	NAME		= N'QueryStatistics_Log' ,
	FILENAME	= N'C:\QueryStatistics\QueryStatistics_Log.ldf' ,
	SIZE		= 1GB ,
	FILEGROWTH	= 10%
);
GO


ALTER DATABASE
	QueryStatistics
SET RECOVERY
	SIMPLE;
GO


USE
	QueryStatistics;
GO


-- Create the "Execution" schema

CREATE SCHEMA
	Execution;
GO


-- The following statement creates a function that returns the SQL text of a
-- statement within a batch according to the sql_handle, statement_start_offest
-- and statement_end_offset.

CREATE FUNCTION
	Execution.udf_s_StatementLevelText
(
	@inSQLHandle			AS VARBINARY(64) ,
	@inStatementStartOffset	AS INT ,
	@inStatementEndOffset	AS INT
)
RETURNS
	NVARCHAR(MAX)
AS
BEGIN

	DECLARE @nvcResult AS NVARCHAR(MAX);

	SELECT
		@nvcResult = SUBSTRING
						(
							[text] ,
							@inStatementStartOffset / 2 ,
							(
								CASE @inStatementEndOffset
									WHEN -1 THEN LEN ([text])
									ELSE @inStatementEndOffset / 2
								END
								- @inStatementStartOffset / 2
							)
							+ 1
						)
	FROM
		sys.dm_exec_sql_text (@inSQLHandle);

	RETURN @nvcResult;

END;
GO


-- Create a sequence object in order to generate row IDs

CREATE SEQUENCE
	Execution.RowIDs
AS
	BIGINT
START WITH
	1
INCREMENT BY
	1
MINVALUE
	1
NO MAXVALUE
CYCLE
CACHE;
GO


-- The following table stores the IDs of the query statistics snapshots

CREATE TABLE
	Execution.QueryStatsSnapshots
(
	qssId		BIGINT			NOT NULL ,
	qssDateTime	DATETIME2(0)	NOT NULL ,

	CONSTRAINT
		pk_QueryStatsSnapshots_c_Id
	PRIMARY KEY CLUSTERED
		(qssId ASC)
);
GO


-- The following table stores the query statistics snapshots data

CREATE TABLE
	Execution.QueryStatsSnapshotsData
(
	qssdId									BIGINT			NOT NULL ,
	qssdSnapshotId							BIGINT			NOT NULL ,
	qssdSQLHandle							VARBINARY(64)	NOT NULL ,
	qssdStatementStartOffset				INT				NOT NULL ,
	qssdStatementEndOffset					INT				NOT NULL ,
	qssdQueryText							NVARCHAR(MAX)	NOT NULL ,
	qssdPlanHandle							VARBINARY(64)	NOT NULL ,
	qssdQueryPlan							XML				NULL ,
	qssdPlanGenerationNumber				BIGINT			NOT NULL ,
	qssdCreationDateTime					DATETIME		NOT NULL ,
	qssdLastExecutionDateTime				DATETIME		NOT NULL ,
	qssdExecutionCount						BIGINT			NOT NULL ,
	qssdTotalWorkerTimeInMicroseconds		BIGINT			NOT NULL ,
	qssdLastWorkerTimeInMicroseconds		BIGINT			NOT NULL ,
	qssdMinWorkerTimeInMicroseconds			BIGINT			NOT NULL ,
	qssdMaxWorkerTimeInMicroseconds			BIGINT			NOT NULL ,
	qssdTotalPhysicalReads					BIGINT			NOT NULL ,
	qssdLastPhysicalReads					BIGINT			NOT NULL ,
	qssdMinPhysicalReads					BIGINT			NOT NULL ,
	qssdMaxPhysicalReads					BIGINT			NOT NULL ,
	qssdTotalLogicalWrites					BIGINT			NOT NULL ,
	qssdLastLogicalWrites					BIGINT			NOT NULL ,
	qssdMinLogicalWrites					BIGINT			NOT NULL ,
	qssdMaxLogicalWrites					BIGINT			NOT NULL ,
	qssdTotalLogicalReads					BIGINT			NOT NULL ,
	qssdLastLogicalReads					BIGINT			NOT NULL ,
	qssdMinLogicalReads						BIGINT			NOT NULL ,
	qssdMaxLogicalReads						BIGINT			NOT NULL ,
	qssdTotalElapsedTimeInMicroseconds		BIGINT			NOT NULL ,
	qssdLastElapsedTimeInMicroseconds		BIGINT			NOT NULL ,
	qssdMinElapsedTimeInMicroseconds		BIGINT			NOT NULL ,
	qssdMaxElapsedTimeInMicroseconds		BIGINT			NOT NULL ,
	qssdTotalRowCount						BIGINT			NOT NULL ,
	qssdLastRowCount						BIGINT			NOT NULL ,
	qssdMinRowCount							BIGINT			NOT NULL ,
	qssdMaxRowCount							BIGINT			NOT NULL ,

	CONSTRAINT
		pk_QueryStatsSnapshotsData_c_Id
	PRIMARY KEY CLUSTERED
		(qssdId ASC) ,

	CONSTRAINT
		fk_QueryStatsSnapshotsData_SnapshotId_QueryStatsSnapshots
	FOREIGN KEY
		(qssdSnapshotId)
	REFERENCES
		Execution.QueryStatsSnapshots (qssId)
);
GO


CREATE NONCLUSTERED INDEX
	ix_QueryStatsSnapshotsData_nc_nu_qssdSnapshotId
ON
	Execution.QueryStatsSnapshotsData (qssdSnapshotId ASC);
GO


-- The following stored procedure takes a snapshot of query statistics data

CREATE PROCEDURE
	Execution.usp_TakeQueryStatsSnapshot
AS

DECLARE
	@biSnapshotId AS BIGINT = NEXT VALUE FOR Execution.RowIDs;

INSERT INTO
	Execution.QueryStatsSnapshots
(
	qssId ,
	qssDateTime
)
SELECT
	qssId		= @biSnapshotId ,
	qssDateTime	= SYSDATETIME ();

INSERT INTO
	Execution.QueryStatsSnapshotsData
(
	qssdId ,
	qssdSnapshotId ,
	qssdSQLHandle ,
	qssdStatementStartOffset ,
	qssdStatementEndOffset ,
	qssdQueryText ,
	qssdPlanHandle ,
	qssdQueryPlan ,
	qssdPlanGenerationNumber ,
	qssdCreationDateTime ,
	qssdLastExecutionDateTime ,
	qssdExecutionCount ,
	qssdTotalWorkerTimeInMicroseconds ,
	qssdLastWorkerTimeInMicroseconds ,
	qssdMinWorkerTimeInMicroseconds ,
	qssdMaxWorkerTimeInMicroseconds ,
	qssdTotalPhysicalReads ,
	qssdLastPhysicalReads ,
	qssdMinPhysicalReads ,
	qssdMaxPhysicalReads ,
	qssdTotalLogicalWrites ,
	qssdLastLogicalWrites ,
	qssdMinLogicalWrites ,
	qssdMaxLogicalWrites ,
	qssdTotalLogicalReads ,
	qssdLastLogicalReads ,
	qssdMinLogicalReads ,
	qssdMaxLogicalReads ,
	qssdTotalElapsedTimeInMicroseconds ,
	qssdLastElapsedTimeInMicroseconds ,
	qssdMinElapsedTimeInMicroseconds ,
	qssdMaxElapsedTimeInMicroseconds ,
	qssdTotalRowCount ,
	qssdLastRowCount ,
	qssdMinRowCount ,
	qssdMaxRowCount
)
SELECT
	qssdId								= NEXT VALUE FOR Execution.RowIDs ,
	qssdSnapshotId						= @biSnapshotId ,
	qssdSQLHandle						= QueryStats.[sql_handle] ,
	qssdStatementStartOffset			= QueryStats.statement_start_offset ,
	qssdStatementEndOffset				= QueryStats.statement_end_offset ,
	qssdQueryText						= Execution.udf_s_StatementLevelText (QueryStats.[sql_handle] , QueryStats.statement_start_offset , QueryStats.statement_end_offset) ,
	qssdPlanHandle						= QueryStats.plan_handle ,
	qssdQueryPlan						= CAST (QueryPlans.query_plan AS XML) ,
	qssdPlanGenerationNumber			= QueryStats.plan_generation_num ,
	qssdCreationDateTime				= QueryStats.creation_time ,
	qssdLastExecutionDateTime			= QueryStats.last_execution_time ,
	qssdExecutionCount					= QueryStats.execution_count ,
	qssdTotalWorkerTimeInMicroseconds	= QueryStats.total_worker_time ,
	qssdLastWorkerTimeInMicroseconds	= QueryStats.last_worker_time ,
	qssdMinWorkerTimeInMicroseconds		= QueryStats.min_worker_time ,
	qssdMaxWorkerTimeInMicroseconds		= QueryStats.max_worker_time ,
	qssdTotalPhysicalReads				= QueryStats.total_physical_reads ,
	qssdLastPhysicalReads				= QueryStats.last_physical_reads ,
	qssdMinPhysicalReads				= QueryStats.min_physical_reads ,
	qssdMaxPhysicalReads				= QueryStats.max_physical_reads ,
	qssdTotalLogicalWrites				= QueryStats.total_logical_writes ,
	qssdLastLogicalWrites				= QueryStats.last_logical_writes ,
	qssdMinLogicalWrites				= QueryStats.min_logical_writes ,
	qssdMaxLogicalWrites				= QueryStats.max_logical_writes ,
	qssdTotalLogicalReads				= QueryStats.total_logical_reads ,
	qssdLastLogicalReads				= QueryStats.last_logical_reads ,
	qssdMinLogicalReads					= QueryStats.min_logical_reads ,
	qssdMaxLogicalReads					= QueryStats.max_logical_reads ,
	qssdTotalElapsedTimeInMicroseconds	= QueryStats.total_elapsed_time ,
	qssdLastElapsedTimeInMicroseconds	= QueryStats.last_elapsed_time ,
	qssdMinElapsedTimeInMicroseconds	= QueryStats.min_elapsed_time ,
	qssdMaxElapsedTimeInMicroseconds	= QueryStats.max_elapsed_time ,
	qssdTotalRowCount					= QueryStats.total_rows ,
	qssdLastRowCount					= QueryStats.last_rows ,
	qssdMinRowCount						= QueryStats.min_rows ,
	qssdMaxRowCount						= QueryStats.max_rows
FROM
	sys.dm_exec_query_stats AS QueryStats
CROSS APPLY
	sys.dm_exec_text_query_plan (QueryStats.plan_handle , QueryStats.statement_start_offset , QueryStats.statement_end_offset) AS QueryPlans;
GO


-- Create a job that runs every 10 minutes and takes a snapshot of query statistics by executing
-- the "Execution.usp_TakeQueryStatsSnapshot" stored procedure

USE
	msdb;
GO


-- Delete the job if it already exists

IF
	EXISTS
		(
			SELECT
				NULL
			FROM
				dbo.sysjobs
			WHERE
				name = N'TakeQueryStatsSnapshot'
		)
BEGIN

	EXECUTE dbo.sp_delete_job
		@job_name				= N'TakeQueryStatsSnapshot' ,
		@delete_history			= 1 ,
		@delete_unused_schedule	= 1;

END;
GO


-- Create the job

EXECUTE dbo.sp_add_job
	@job_name				= N'TakeQueryStatsSnapshot' ,
	@enabled				= 1 ,
	@start_step_id			= 1 ,
	@notify_level_eventlog	= 0 ,
	@notify_level_email		= 2 ,
	@notify_level_netsend	= 2 ,
	@notify_level_page		= 2 ,
	@delete_level			= 0 ,
	@description			= N'This job runs every minute and takes a snapshot of the query statistics from "sys.dm_exec_query_stats"' ,
	@category_name			= N'[Uncategorized (Local)]' ,
	@owner_login_name		= N'sa' ,
	@job_id					= NULL;
GO


-- Add the local server as the target server for the job

EXECUTE dbo.sp_add_jobserver
	@job_name		= N'TakeQueryStatsSnapshot' ,
	@server_name	= N'(LOCAL)';
GO


-- Add the job step

EXECUTE dbo.sp_add_jobstep
	@job_name				= N'TakeQueryStatsSnapshot' ,
	@step_name				= N'TakeQueryStatsSnapshot' ,
	@step_id				= 1 ,
	@cmdexec_success_code	= 0 ,
	@on_success_action		= 1 ,
	@on_fail_action			= 2 ,
	@retry_attempts			= 0 ,
	@retry_interval			= 0 ,
	@os_run_priority		= 0 ,
	@subsystem				= N'TSQL' ,
	@command				= N'EXECUTE Execution.usp_TakeQueryStatsSnapshot;' ,
	@database_name			= N'QueryStatistics' ,
	@flags					= 0;
GO


-- Add the job schedule - EveryTenMinutes

DECLARE @intActiveStartDate AS INT;

SET @intActiveStartDate = CAST (CONVERT (NCHAR(8) , SYSDATETIME () , 112) AS INT);

EXECUTE dbo.sp_add_jobschedule
	@job_name				= N'TakeQueryStatsSnapshot' ,
	@name					= N'EveryTenMinutes' ,
	@enabled				= 1 ,
	@freq_type				= 4 ,
	@freq_interval			= 1 ,
	@freq_subday_type		= 4 ,
	@freq_subday_interval	= 10 ,
	@freq_relative_interval	= 0 ,
	@freq_recurrence_factor	= 1 ,
	@active_start_date		= @intActiveStartDate ,
	@active_end_date		= 99991231 ,
	@active_start_time		= 0 ,
	@active_end_time		= 235959 ,
	@schedule_id			= NULL;
GO


-- The following function retrieves query statistics for a specific range between two snapshots

USE
	QueryStatistics;
GO


CREATE FUNCTION
	Execution.udf_il_GetQueryStatistics
(
	@dt2FirstSnapshotDateTime	AS DATETIME2(0) ,
	@dt2SecondSnapshotDateTime	AS DATETIME2(0)
)
RETURNS
	TABLE
AS

RETURN
(
	SELECT
		QueryText							= QueryText ,
		QueryPlan							= QueryPlan ,
		CompilationCount					= CompilationCount ,
		CreationDateTime					= CreationDateTime ,
		LastExecutionDateTime				= LastExecutionDateTime ,
		ExecutionCount						= ExecutionCount ,
		ExecutionsPerSecond					= CAST ((CAST (ExecutionCount AS DECIMAL(19,2)) / CAST (DATEDIFF (SECOND , MinExecutionIntervalDateTime , @dt2SecondSnapshotDateTime) AS DECIMAL(19,2))) AS DECIMAL(19,2)) ,
		TotalWorkerTimeInMicroseconds		= TotalWorkerTimeInMicroseconds ,
		LastWorkerTimeInMicroseconds		= LastWorkerTimeInMicroseconds ,
		MinWorkerTimeInMicroseconds			= MinWorkerTimeInMicroseconds ,
		MaxWorkerTimeInMicroseconds			= MaxWorkerTimeInMicroseconds ,
		TotalPhysicalReads					= TotalPhysicalReads ,
		LastPhysicalReads					= LastPhysicalReads ,
		MinPhysicalReads					= MinPhysicalReads ,
		MaxPhysicalReads					= MaxPhysicalReads ,
		TotalLogicalWrites					= TotalLogicalWrites ,
		LastLogicalWrites					= LastLogicalWrites ,
		MinLogicalWrites					= MinLogicalWrites ,
		MaxLogicalWrites					= MaxLogicalWrites ,
		TotalLogicalReads					= TotalLogicalReads ,
		LastLogicalReads					= LastLogicalReads ,
		MinLogicalReads						= MinLogicalReads ,
		MaxLogicalReads						= MaxLogicalReads ,
		TotalElapsedTimeInMicroseconds		= TotalElapsedTimeInMicroseconds ,
		LastElapsedTimeInMicroseconds		= LastElapsedTimeInMicroseconds ,
		MinElapsedTimeInMicroseconds		= MinElapsedTimeInMicroseconds ,
		MaxElapsedTimeInMicroseconds		= MaxElapsedTimeInMicroseconds ,
		AverageElapsedTimeInMicroseconds	= CAST ((CAST (TotalElapsedTimeInMicroseconds AS DECIMAL(19,2)) / CAST (ExecutionCount AS DECIMAL(19,2))) AS DECIMAL(19,2)) ,
		TotalRowCount						= TotalRowCount ,
		LastRowCount						= LastRowCount ,
		MinRowCount							= MinRowCount ,
		MaxRowCount							= MaxRowCount
	FROM
		(
			SELECT
				QueryText							= SecondSnapshot.qssdQueryText ,
				QueryPlan							= SecondSnapshot.qssdQueryPlan ,
				CompilationCount					= SecondSnapshot.qssdPlanGenerationNumber - ISNULL (FirstSnapshot.qssdPlanGenerationNumber , 0) ,
				CreationDateTime					= SecondSnapshot.qssdCreationDateTime ,
				LastExecutionDateTime				= SecondSnapshot.qssdLastExecutionDateTime ,
				ExecutionCount						=	CASE
															WHEN SecondSnapshot.qssdPlanGenerationNumber = FirstSnapshot.qssdPlanGenerationNumber	THEN	SecondSnapshot.qssdExecutionCount - FirstSnapshot.qssdExecutionCount
															ELSE																							SecondSnapshot.qssdExecutionCount
														END ,
				MinExecutionIntervalDateTime		=	CASE
															WHEN SecondSnapshot.qssdCreationDateTime > @dt2FirstSnapshotDateTime	THEN	SecondSnapshot.qssdCreationDateTime
															ELSE																			@dt2FirstSnapshotDateTime
														END ,
				TotalWorkerTimeInMicroseconds		=	CASE
															WHEN SecondSnapshot.qssdPlanGenerationNumber = FirstSnapshot.qssdPlanGenerationNumber	THEN	SecondSnapshot.qssdTotalWorkerTimeInMicroseconds - FirstSnapshot.qssdTotalWorkerTimeInMicroseconds
															ELSE																							SecondSnapshot.qssdTotalWorkerTimeInMicroseconds
														END ,
				LastWorkerTimeInMicroseconds		= SecondSnapshot.qssdLastWorkerTimeInMicroseconds ,
				MinWorkerTimeInMicroseconds			= SecondSnapshot.qssdMinWorkerTimeInMicroseconds ,
				MaxWorkerTimeInMicroseconds			= SecondSnapshot.qssdMaxWorkerTimeInMicroseconds ,
				TotalPhysicalReads					=	CASE
															WHEN SecondSnapshot.qssdPlanGenerationNumber = FirstSnapshot.qssdPlanGenerationNumber	THEN	SecondSnapshot.qssdTotalPhysicalReads - FirstSnapshot.qssdTotalPhysicalReads
															ELSE																							SecondSnapshot.qssdTotalPhysicalReads
														END ,
				LastPhysicalReads					= SecondSnapshot.qssdLastPhysicalReads ,
				MinPhysicalReads					= SecondSnapshot.qssdMinPhysicalReads ,
				MaxPhysicalReads					= SecondSnapshot.qssdMaxPhysicalReads ,
				TotalLogicalWrites					=	CASE
															WHEN SecondSnapshot.qssdPlanGenerationNumber = FirstSnapshot.qssdPlanGenerationNumber	THEN	SecondSnapshot.qssdTotalLogicalWrites - FirstSnapshot.qssdTotalLogicalWrites
															ELSE																							SecondSnapshot.qssdTotalLogicalWrites
														END ,
				LastLogicalWrites					= SecondSnapshot.qssdLastLogicalWrites ,
				MinLogicalWrites					= SecondSnapshot.qssdMinLogicalWrites ,
				MaxLogicalWrites					= SecondSnapshot.qssdMaxLogicalWrites ,
				TotalLogicalReads					=	CASE
															WHEN SecondSnapshot.qssdPlanGenerationNumber = FirstSnapshot.qssdPlanGenerationNumber	THEN	SecondSnapshot.qssdTotalLogicalReads - FirstSnapshot.qssdTotalLogicalReads
															ELSE																							SecondSnapshot.qssdTotalLogicalReads
														END ,
				LastLogicalReads					= SecondSnapshot.qssdLastLogicalReads ,
				MinLogicalReads						= SecondSnapshot.qssdMinLogicalReads ,
				MaxLogicalReads						= SecondSnapshot.qssdMaxLogicalReads ,
				TotalElapsedTimeInMicroseconds		=	CASE
															WHEN SecondSnapshot.qssdPlanGenerationNumber = FirstSnapshot.qssdPlanGenerationNumber	THEN	SecondSnapshot.qssdTotalElapsedTimeInMicroseconds - FirstSnapshot.qssdTotalElapsedTimeInMicroseconds
															ELSE																							SecondSnapshot.qssdTotalElapsedTimeInMicroseconds
														END ,
				LastElapsedTimeInMicroseconds		= SecondSnapshot.qssdLastElapsedTimeInMicroseconds ,
				MinElapsedTimeInMicroseconds		= SecondSnapshot.qssdMinElapsedTimeInMicroseconds ,
				MaxElapsedTimeInMicroseconds		= SecondSnapshot.qssdMaxElapsedTimeInMicroseconds ,
				TotalRowCount						=	CASE
															WHEN SecondSnapshot.qssdPlanGenerationNumber = FirstSnapshot.qssdPlanGenerationNumber	THEN	SecondSnapshot.qssdTotalRowCount - FirstSnapshot.qssdTotalRowCount
															ELSE																							SecondSnapshot.qssdTotalRowCount
														END ,
				LastRowCount						= SecondSnapshot.qssdLastRowCount ,
				MinRowCount							= SecondSnapshot.qssdMinRowCount ,
				MaxRowCount							= SecondSnapshot.qssdMaxRowCount
			FROM
				Execution.QueryStatsSnapshotsData AS SecondSnapshot
			LEFT OUTER JOIN
				Execution.QueryStatsSnapshotsData AS FirstSnapshot
			ON
				SecondSnapshot.qssdSQLHandle = FirstSnapshot.qssdSQLHandle
			AND
				SecondSnapshot.qssdStatementStartOffset = FirstSnapshot.qssdStatementStartOffset
			AND
				SecondSnapshot.qssdStatementEndOffset = FirstSnapshot.qssdStatementEndOffset
			AND
				SecondSnapshot.qssdPlanHandle = FirstSnapshot.qssdPlanHandle
			AND
				FirstSnapshot.qssdSnapshotId =
					(
						SELECT
							MAX (qssId)
						FROM
							Execution.QueryStatsSnapshots
						WHERE
							qssDateTime <= @dt2FirstSnapshotDateTime
					)
			WHERE
				SecondSnapshot.qssdSnapshotId =
					(
						SELECT
							MAX (qssId)
						FROM
							Execution.QueryStatsSnapshots
						WHERE
							qssDateTime <= @dt2SecondSnapshotDateTime
					)
		)
		AS
			QueryStatsBetweenSnapshots
	WHERE
		ExecutionCount > 0
);
GO


-- Retrieve query statistics for the past 24 hours ordered by the average elapsed time

DECLARE
	@dt2FirstSnapshotDateTime	AS DATETIME2(0) ,
	@dt2SecondSnapshotDateTime	AS DATETIME2(0);

SET @dt2SecondSnapshotDateTime	= SYSDATETIME ();
SET @dt2FirstSnapshotDateTime	= DATEADD (HOUR , -24 , @dt2SecondSnapshotDateTime);

SELECT
	QueryText ,
	QueryPlan ,
	CompilationCount ,
	CreationDateTime ,
	LastExecutionDateTime ,
	ExecutionCount ,
	ExecutionsPerSecond ,
	TotalWorkerTimeInMicroseconds ,
	LastWorkerTimeInMicroseconds ,
	MinWorkerTimeInMicroseconds ,
	MaxWorkerTimeInMicroseconds ,
	TotalPhysicalReads ,
	LastPhysicalReads ,
	MinPhysicalReads ,
	MaxPhysicalReads ,
	TotalLogicalWrites ,
	LastLogicalWrites ,
	MinLogicalWrites ,
	MaxLogicalWrites ,
	TotalLogicalReads ,
	LastLogicalReads ,
	MinLogicalReads ,
	MaxLogicalReads ,
	TotalElapsedTimeInMicroseconds ,
	LastElapsedTimeInMicroseconds ,
	MinElapsedTimeInMicroseconds ,
	MaxElapsedTimeInMicroseconds ,
	AverageElapsedTimeInMicroseconds ,
	TotalRowCount ,
	LastRowCount ,
	MinRowCount ,
	MaxRowCount
FROM
	Execution.udf_il_GetQueryStatistics (@dt2FirstSnapshotDateTime , @dt2SecondSnapshotDateTime) AS QueryStatistics
ORDER BY
	AverageElapsedTimeInMicroseconds DESC;
GO
