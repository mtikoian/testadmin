-- Script Name:		Statement-Level Query Statistics
-- Description:		This script creates two function and a view that returns query statistcis based on
--					sys.dm_exec_query_stats at the statement level
-- Author:			Guy Glantser, Madeira
-- Last Updated On:	20/12/2009


-- The following statements create a function, that returns the SQL text of a
-- statement within a batch according to the sql_handle, statement_start_offest
-- and statement_end_offset.

IF
	OBJECT_ID ('dbo.udf_StatementLevelText') IS NOT NULL
BEGIN

	DROP FUNCTION
		dbo.udf_StatementLevelText;

END;
GO


CREATE FUNCTION
	dbo.udf_StatementLevelText
(
	@SQL_Handle				AS VARBINARY(64) ,
	@Statement_Start_Offset	AS INT ,
	@Statement_End_Offset	AS INT
)
RETURNS NVARCHAR(MAX)
AS
BEGIN

	DECLARE @Result AS NVARCHAR(MAX);

	SELECT
		@Result = SUBSTRING
					(
						[text] ,
						@Statement_Start_Offset / 2 ,
						(
							CASE @Statement_End_Offset
								WHEN -1 THEN LEN ([text])
								ELSE @Statement_End_Offset / 2
							END
							- @Statement_Start_Offset / 2
						)
						+ 1
					)
	FROM
		sys.dm_exec_sql_text (@SQL_Handle);

	RETURN @Result;

END;
GO


-- The following statements create a function, that returns the execution plan
-- of a statement within a batch according to the plan_handle and the statement text.

IF
	OBJECT_ID ('dbo.udf_StatementLevelPlan') IS NOT NULL
BEGIN

	DROP FUNCTION
		dbo.udf_StatementLevelPlan;

END;
GO


CREATE FUNCTION
	dbo.udf_StatementLevelPlan
(
	@Plan_Handle	AS VARBINARY(64) ,
	@Statement_Text	AS NVARCHAR(MAX)
)
RETURNS XML
AS
BEGIN

	DECLARE @Result AS XML;

	SELECT
		@Result = StatementPlan
	FROM
		(
			SELECT
				StatementText				= C.value ('(./@StatementText)' , 'nvarchar(max)') ,
				StatementPlan				= C.query
												(
													'declare namespace PLN="http://schemas.microsoft.com/sqlserver/2004/07/showplan";
													if (./PLN:QueryPlan or ./PLN:Condition/PLN:QueryPlan)
													then
														<PLN:ShowPlanXML><PLN:BatchSequence><PLN:Batch><PLN:Statements><PLN:StmtSimple>
															{ ./attribute::* }
															{ ./descendant::PLN:QueryPlan[1] }
														</PLN:StmtSimple></PLN:Statements></PLN:Batch></PLN:BatchSequence></PLN:ShowPlanXML>
													else ()'
												)
			FROM
				sys.dm_exec_query_plan (@Plan_Handle)
			CROSS APPLY
				query_plan.nodes
					(
						'declare namespace PLN="http://schemas.microsoft.com/sqlserver/2004/07/showplan";
						/PLN:ShowPlanXML/PLN:BatchSequence/PLN:Batch/PLN:Statements/descendant::*[attribute::StatementText]'
					)
					AS T(C)
		)
		AS SubQuery
	WHERE
		StatementText LIKE '%' + REPLACE (LEFT (@Statement_Text , 3000) , '[' , '[[]') + '%'

	RETURN @Result;

END;
GO


-- This query returns statistics information for queries currently in the procedure
-- cache. Each row represents a single statement.

SELECT
	QueryText				= dbo.udf_StatementLevelText ([sql_handle] , statement_start_offset , statement_end_offset) ,
	QueryPlan				= dbo.udf_StatementLevelPlan (plan_handle , dbo.udf_StatementLevelText ([sql_handle] , statement_start_offset , statement_end_offset)) ,
	PlanGenerationNumber	= plan_generation_num ,
	CreationDateTime		= creation_time ,
	LastExecutionDateTime	= last_execution_time ,
	ExecutionCount			= execution_count ,
	TotalWorkerTime			= total_worker_time ,
	LastWorkerTime			= last_worker_time ,
	MinWorkerTime			= min_worker_time ,
	MaxWorkerTime			= max_worker_time ,
	TotalPhysicalReads		= total_physical_reads ,
	LastPhysicalReads		= last_physical_reads ,
	MinPhysicalReads		= min_physical_reads ,
	MaxPhysicalReads		= max_physical_reads ,
	TotalLogicalWrites		= total_logical_writes ,
	LastLogicalWrites		= last_logical_writes ,
	MinLogicalWrites		= min_logical_writes ,
	MaxLogicalWrites		= max_logical_writes ,
	TotalLogicalReads		= total_logical_reads ,
	LastLogicalReads		= last_logical_reads ,
	MinLogicalReads			= min_logical_reads ,
	MaxLogicalReads			= max_logical_reads ,
	TotalElapsedTime		= total_elapsed_time ,
	LastElapsedTime			= last_elapsed_time ,
	MinElapsedTime			= min_elapsed_time ,
	MaxElapsedTime			= max_elapsed_time ,
	AverageElapsedTime		= total_elapsed_time / execution_count
FROM
	sys.dm_exec_query_stats
ORDER BY
	AverageElapsedTime DESC;
GO
