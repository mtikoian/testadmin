USE Beer

--Make sure that we're using a clean version of the database
USE [master]
ALTER DATABASE [Beer] SET SINGLE_USER WITH ROLLBACK IMMEDIATE
RESTORE DATABASE [Beer] FROM  DISK = N'D:\SQL Sentry\abstracts\Houston2016\beers.bak' WITH  FILE = 1,  NOUNLOAD,  REPLACE,  STATS = 5
ALTER DATABASE [Beer] SET MULTI_USER

use Beer

--View current statistics - note the difference using the ALL argument

EXEC sp_helpstats N'Beers', 'ALL'

--Add indexes to Beers table
CREATE NONCLUSTERED INDEX [Brewery] ON [dbo].[Beers]
(
	[Brewery] ASC,
	[BeerName] ASC,
	[Style] ASC
)

CREATE NONCLUSTERED INDEX [Style_Brewery] ON [dbo].[Beers]
(
	[Style] ASC,
	[Brewery] ASC	
)


EXEC sp_helpstats N'Beers', 'ALL'

--Viewing statistics from the sys.stats catalog view
--STATS_DATE works on SQL Server 2008+
SELECT object_id, name, stats_id, auto_created, user_created, no_recompute, has_filter, filter_definition, is_temporary
, STATS_DATE(object_id, stats_id) as Stats_Date
FROM sys.stats
WHERE name LIKE '%beer%' 


--Viewing statisics using sys.dm_db_stats_properties
--Available after 2008R2 SP2
SELECT sp.stats_id, name, filter_definition, last_updated, rows, rows_sampled, steps, unfiltered_rows, modification_counter 
FROM sys.stats AS stat 
CROSS APPLY sys.dm_db_stats_properties(stat.object_id, stat.stats_id) AS sp
WHERE stat.object_id = object_id('Beers');

--Viewing the stats blob using DBCC SHOW_STATISTICS

DBCC SHOW_STATISTICS (N'Beers', Brewery)

--Statistics are used to determine the optimal execution plan
--Is the predicate selective enough for a index scan + bookmark lookup or will it do a clustered index scan?

SELECT *
FROM Beers
WHERE Style  = 'IPA'

SELECT *
FROM Beers
WHERE Style = 'Quadrupel(Quad)'

--Create a set of statistics based on a predicate

SELECT *
FROM beers
WHERE BeerName like 'Amber Ale%'

--View new column based statistics
EXEC sp_helpstats N'Beers','All' 

----Here is the distribution of names within the column
--SELECT BeerName,
--       count(BeerName)
--FROM Beers
--GROUP BY BeerName
--ORDER BY BeerName

--View the new statistics using DBCC SHOW_STATISTICS
DBCC SHOW_STATISTICS ('Beers', _WA_Sys_00000005_47DBAE45) 


--Can we prove that the numbers in the histogram are accurate?
SELECT 'Abita Brewing Company',
       count(*)
FROM beers
WHERE brewery = 'Abita Brewing Company'

SELECT 'Alaskan Brewing',
       count(*)
  FROM beers WHERE Brewery = 'Alaskan Brewing'

SELECT DISTINCT Brewery,
                count(Brewery)
  FROM Beers 
  WHERE Brewery > 'Abita Brewing Company'
  AND Brewery <'Alaskan Brewing'
  GROUP BY Brewery 
  
DBCC SHOW_STATISTICS (N'Beers', Brewery) WITH HISTOGRAM

--So what happens when statistics are out of date?

--We'll update the Beers table with 150 Quads
--Note - this isn't enough of a change to kick off the auto-update
UPDATE Beers
SET Style = 'Quadrupel(Quad)'
WHERE Style = 'IPA'
AND BeerId % 2 = 0

--Now let's look at the query plan when we query for Style after the new records.  
--Did we get a new execution plan?

SELECT *
FROM Beers
WHERE Style = 'Quadrupel(Quad)'


--Here's a good example of the modification counter
SELECT sp.stats_id, name, filter_definition, last_updated, rows, rows_sampled, steps, unfiltered_rows, modification_counter 
FROM sys.stats AS stat 
CROSS APPLY sys.dm_db_stats_properties(stat.object_id, stat.stats_id) AS sp
WHERE stat.object_id = object_id('Beers');

--Now let's rebuild the Style_Brewery index which will also update the statistics 
USE [Beer]
GO
ALTER INDEX [Style_Brewery] ON [dbo].[Beers] REBUILD 

--show that the statistic has been rebuilt
DBCC SHOW_STATISTICS ('Beers', Style_Brewery)

--Does this give us a better execution plan?
SELECT *
FROM Beers
WHERE Style = 'Quadrupel(Quad)'


