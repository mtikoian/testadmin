/*******************************************************************************
Filename: 6_DensityInfo.sql
Author: (C) 04/30/2012, Erin Stellato
Summary: This script was used in support of a session given by Erin Stellato
Feedback: mailto:erin@erinstellato.com

This script and information herein are provided "as is" without warranty
of any kind, either expressed or implied.

*******************************************************************************/

USE AdventureWorks
GO

IF EXISTS (SELECT COUNT(*) FROM sys.objects WHERE name = '#StatsHeader')
	DROP TABLE #StatsHeader
	
IF EXISTS (SELECT COUNT(*) FROM sys.objects WHERE name = '#DensityVector')
	DROP TABLE #DensityVector

IF EXISTS (SELECT COUNT(*) FROM sys.objects WHERE name = '#IndexDensities')
	DROP TABLE #IndexDensities

CREATE TABLE #DensityVector (
	density			decimal(18, 10),
	cols_length		int,
	index_cols		varchar(1000)
)

CREATE TABLE #StatsHeader (
	statname		varchar(1000),
	updateddate		datetime,	
	numrows			bigint,
	numrowssampled	bigint,
	steps			tinyint,
	density			decimal(18,10),
	avgkeylength	int,
	stringindex		varchar(5),
	filterexp		varchar(1000),
	unfilteredrows	bigint
)

CREATE TABLE #IndexDensities (
	schemaname		varchar(256),
	tablename		varchar(256),
	indexname		varchar(256),
	density			decimal(18,10),
	cols_length		int,
	index_cols		varchar(1000),
	numrows			int	
	)



SET NOCOUNT ON
DECLARE @schemaname varchar(256)
DECLARE @tablename varchar(256)
DECLARE @indexname varchar(256)
DECLARE @string varchar(5000)


DECLARE IndexList CURSOR FOR
SELECT ss.name, so.name, si.name
FROM sys.objects so
JOIN sys.indexes si ON so.object_id=si.object_id
JOIN sys.schemas ss on so.schema_id=ss.schema_id
WHERE si.index_id > 0
and so.type = 'U'
ORDER BY so.name, si.name


BEGIN
	OPEN IndexList 

	FETCH NEXT FROM IndexList 
	INTO @schemaname, @tablename, @indexname

	WHILE @@FETCH_STATUS = 0

	BEGIN

		SET @string = 'dbcc show_statistics ("' + @schemaname + '.' + @tablename + '",' + @indexname + ') with density_vector'
		
		INSERT #DensityVector EXECUTE (@string)

		--INSERT #DensityVector EXECUTE ('dbcc show_statistics ("Person.Address",AK_Address_rowguid) with density_vector')

		SET @string = 'dbcc show_statistics ("' + @schemaname + '.' + @tablename + '",' + @indexname + ') with stat_header'
		
		INSERT #StatsHeader EXECUTE (@string)

		--INSERT #StatsHeader EXECUTE ('dbcc show_statistics ("Person.Address",AK_Address_rowguid) with stat_header')		

		INSERT #IndexDensities 
		(schemaname, tablename, indexname, density, cols_length, index_cols)
		SELECT @schemaname,@tablename, @indexname, d.density, d.cols_length, d.index_cols
		FROM #DensityVector d
		
		UPDATE #IndexDensities
		SET numrows = s.numrows
		FROM #StatsHeader s
		WHERE #IndexDensities.schemaname=@schemaname
		and #IndexDensities.tablename=@tablename
		and #IndexDensities.indexname=@indexname
		
		--INSERT #IndexDensities 
		--(schemaname, tablename, indexname, density, cols_length, index_cols, numrows)
		--SELECT 'Person','Address', 'AK_Address_rowguid', d.density, d.cols_length, d.index_cols, s.numrows
		--FROM #DensityVector d, #StatsHeader s
		
		TRUNCATE TABLE #StatsHeader
		TRUNCATE TABLE #DensityVector
				
		FETCH NEXT FROM IndexList 
		INTO @schemaname, @tablename, @indexname
	END

CLOSE IndexList 
DEALLOCATE IndexList 
		
END

/*
	check output
*/
SELECT * FROM #IndexDensities ORDER BY density DESC, numrows DESC


/*
	look at tables with specific density value and number of rows
*/
SELECT 'dbcc show_statistics ("' +schemaname + '.' + tablename + '",' + indexname + ')', density, numrows
FROM #IndexDensities 
WHERE density > .001
and numrows > 1000
ORDER BY density desc

/*
	sample of table with skewed distribution
*/
dbcc show_statistics ("Sales.Customer",IX_Customer_TerritoryID)

