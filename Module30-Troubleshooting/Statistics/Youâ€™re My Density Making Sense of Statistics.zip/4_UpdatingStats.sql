/*******************************************************************************
Filename: 4_UpdatingStats.sql
Author: (C) 04/30/2012, Erin Stellato
Summary: This script was used in support of a session given by Erin Stellato
Feedback: mailto:erin@erinstellato.com

This script and information herein are provided "as is" without warranty
of any kind, either expressed or implied.

*******************************************************************************/

USE AdventureWorks;
GO

sp_dboption AdventureWorks, 'auto create statistics', 'on'
GO
sp_dboption AdventureWorks, 'auto update statistics', 'on'
GO

IF EXISTS (SELECT * FROM sys.tables WHERE name = 'PersonContact')
	DROP TABLE dbo.PersonContact

/* 
	create dbo.PersonContact as a COPY of Person.Contact 
*/
SELECT TOP 1 * INTO dbo.PersonContact FROM Person.Contact
TRUNCATE TABLE dbo.PersonContact

/*
	create a clustered and non-clustered index for the table
*/
CREATE UNIQUE CLUSTERED INDEX CI_ContactID ON dbo.PersonContact(ContactID)
CREATE NONCLUSTERED INDEX IX_PersonContact_LastName_FirstName ON dbo.PersonContact (LastName,FirstName)


/*
	manually create a column statistic
*/
CREATE STATISTICS US_Name ON dbo.PersonContact (rowguid) WITH FULLSCAN


/*
	load some data
*/
INSERT INTO dbo.PersonContact
           ([NameStyle]
           ,[Title]
           ,[FirstName]
           ,[MiddleName]
           ,[LastName]
           ,[Suffix]
           ,[EmailAddress]
           ,[EmailPromotion]
           ,[Phone]
           ,[PasswordHash]
           ,[PasswordSalt]
           ,[AdditionalContactInfo]
           ,[rowguid]
           ,[ModifiedDate])
SELECT
			[NameStyle]
           ,[Title]
           ,[FirstName]
           ,[MiddleName]
           ,[LAStName]
           ,[Suffix]
           ,[EmailAddress]
           ,[EmailPromotion]
           ,[Phone]
           ,[PasswordHash]
           ,[PasswordSalt]
           ,[AdditionalContactInfo]
           ,[rowguid]
           ,[ModifiedDate]
FROM Person.Contact
GO

/*
	check statistics 
*/
DBCC SHOW_STATISTICS ("dbo.PersonContact", CI_ContactID)

DBCC SHOW_STATISTICS ("dbo.PersonContact", IX_PersonContact_LastName_FirstName)

DBCC SHOW_STATISTICS ("dbo.PersonContact", US_Name)


/*
	rebuild index, stats get updated
*/
ALTER INDEX CI_ContactID ON dbo.PersonContact REBUILD


/*
	check statistics again - column stats not updated (even if rebuild all indexes)
*/
DBCC SHOW_STATISTICS ("dbo.PersonContact", CI_ContactID)

DBCC SHOW_STATISTICS ("dbo.PersonContact", US_Name)



/*
	clear cache, enable execution plan, run query
	note estimated and actual rows
*/

DBCC FREEPROCCACHE

SELECT FirstName, LastName
FROM dbo.PersonContact
WHERE LastName = N'Zimmerman'


/*
	check what statistics exist for the table
*/
SELECT name AS "Statistics Name", auto_created AS "Auto Created?", user_created AS "User Created?", has_filter AS "Filtered?", filter_definition AS "Filter", no_recompute AS "Recompute"
FROM sys.stats 
WHERE object_id = object_id(N'dbo.PersonContact')


/*
	update statistics
*/
UPDATE STATISTICS dbo.PersonContact IX_PersonContact_LastName_FirstName WITH FULLSCAN


/*
	check statistics 
*/
DBCC SHOW_STATISTICS ("dbo.PersonContact", IX_PersonContact_LastName_FirstName)


/*
	value we would expect for estimated value
*/
SELECT 2543/13


/*
	run query again
*/

DBCC FREEPROCCACHE

SELECT FirstName, LastName
FROM dbo.PersonContact
WHERE LastName = N'Zimmerman'


/*
	what if the value is ouside the histogram?
*/

SELECT FirstName, LastName
FROM dbo.PersonContact
WHERE LastName = N'Zygler'


/*
	clean up
*/
DROP TABLE dbo.PersonContact;
GO