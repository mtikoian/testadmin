/*******************************************************************************
Filename: 3_WhereStatsExist.sql
Author: (C) 04/30/2012, Erin Stellato
Summary: This script was used in support of a session given by Erin Stellato
Feedback: mailto:erin@erinstellato.com

This script and information herein are provided "as is" without warranty
of any kind, either expressed or implied.

*******************************************************************************/
 
/*
	drop table if it exists, then create it 
*/

USE AdventureWorks
GO

IF EXISTS (SELECT * FROM sys.tables WHERE name = 'StatsLastUpdated')
	DROP TABLE dbo.StatsLastUpdated

CREATE TABLE dbo.StatsLastUpdated (
	SchemaName VARCHAR(250),
	TableName VARCHAR(250),
	Statistic VARCHAR(250),
	LastUpdated DATETIME2,
	NumRows BIGINT,
	AutoCreated VARCHAR(50),
	UserCreated VARCHAR(50),
	No_Recompute VARCHAR(50)
	)

/*
	roll through tables to get stats for each
*/
SET NOCOUNT ON

DECLARE @schemaname AS VARCHAR(100)
DECLARE @tablename AS VARCHAR(100)
DECLARE @sqlstring AS VARCHAR(8000)


DECLARE TableList CURSOR FOR
SELECT ss.name, so.name 
FROM sys.objects so
JOIN sys.schemas ss ON so.schema_id=ss.schema_id
WHERE TYPE = 'U'
AND parent_object_id=0
ORDER BY ss.name, so.name

BEGIN

	OPEN TableList
	
	FETCH NEXT FROM TableList
	INTO @schemaname, @tablename
	
	WHILE @@FETCH_STATUS = 0
	
		BEGIN
			SET @sqlstring = '
				INSERT INTO dbo.StatsLastUpdated
				(SchemaName, TableName, Statistic, LastUpdated, NumRows, AutoCreated, UserCreated, No_Recompute)
				SELECT 
				SCHEMA_NAME(so.SCHEMA_ID) AS "SchemaName",
				OBJECT_NAME(si.OBJECT_ID) AS "TableName", 
				ss.name AS "Statistic",  
				STATS_DATE(ss.OBJECT_ID, ss.stats_id) AS "Statistics Last Updated",
				p.rows AS "NumRows",
				CASE ss.auto_created
				WHEN 0 THEN ''No''
				WHEN 1 THEN ''Auto Created''
				END AS "AutoCreated?",
				CASE ss.user_created
				WHEN 0 THEN ''No''
				WHEN 1 THEN ''User Created''
				END AS "UserCreated?",
				CASE ss.no_recompute
				WHEN 0 THEN ''YES''
				WHEN 1 THEN ''NO''
				END AS "Recompute?"
				FROM sys.stats ss
				JOIN sys.indexes si ON ss.OBJECT_ID=si.OBJECT_ID
				JOIN sys.partitions p ON si.OBJECT_ID = p.OBJECT_ID AND si.index_id = p.index_id
				JOIN sys.objects so ON si.OBJECT_ID = so.OBJECT_ID
				JOIN sys.schemas s ON so.schema_id = s.schema_id
				WHERE ss.OBJECT_ID = OBJECT_ID(''' + @schemaname + '.' + @tablename + ''')
				AND si.OBJECT_ID = OBJECT_ID(''' + @schemaname + '.' + @tablename + ''') AND si.index_id <= 1
				ORDER BY ss.name'
		EXEC (@sqlstring)
		
		
		FETCH NEXT FROM TableList
		INTO @schemaname, @tablename
	
	END
	
CLOSE TableList
DEALLOCATE TableList

END

/*
	list output, ordered by oldest stats
*/
SELECT * 
FROM dbo.StatsLastUpdated 
ORDER BY CAST(DATEPART(MM, LastUpdated) AS VARCHAR(2)) + '/' + CAST(DATEPART(MM, LastUpdated) AS VARCHAR(2)) + '/' + CAST(DATEPART(YYYY, LastUpdated) AS VARCHAR(4)) ASC, NumRows DESC
