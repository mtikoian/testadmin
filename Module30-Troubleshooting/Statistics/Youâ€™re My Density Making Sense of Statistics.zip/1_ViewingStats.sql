/*******************************************************************************
Filename: 1_ViewingStats.sql
Author: (C) 04/30/2012, Erin Stellato
Summary: This script was used in support of a session given by Erin Stellato
Feedback: mailto:erin@erinstellato.com

This script and information herein are provided "as is" without warranty
of any kind, either expressed or implied.

*******************************************************************************/

USE AdventureWorks;
GO

DBCC SHOW_STATISTICS ( table_name | view_name , target ) 
[ WITH [ NO_INFOMSGS ] < option > [ , n ] ]
< option > :: =
    STAT_HEADER | DENSITY_VECTOR | HISTOGRAM
 
--DBCC SHOW_STATISTICS does not provide statistics for spatial indexes.


/*
	Note that IX_SalesOrderDetail_ProductID is on one column, ProductID
*/
sp_helpindex "Sales.SalesOrderDetail"



DBCC SHOW_STATISTICS ("Sales.SalesOrderDetail",IX_SalesOrderDetail_ProductID) 



DBCC SHOW_STATISTICS ("Sales.SalesOrderDetail",IX_SalesOrderDetail_ProductID) WITH STAT_HEADER
/*
Density - this information is not used by the Optimizer
String Index - Yes indicates that the statistics contain a string summary index 
to support estimation of result set sizes for LIKE conditions. 
A string index is only created on the first key column when it is of data type 
char, varchar, nchar, nvarchar, varchar(max), nvarchar(max), text, or ntext.
Unfiltered Rows - Total number of rows in the table before applying the filter 
expression. If Filter Expression is NULL, Unfiltered Rows is equal to the Rows header value.
*/


DBCC SHOW_STATISTICS ("Sales.SalesOrderDetail",IX_SalesOrderDetail_ProductID) WITH DENSITY_VECTOR
GO
/* note this includes density for SalesOrderID and SalesOrderDetailID because
even though they are not in the index, they are the clustering key and
are in the leaf level of the index
*/



/*
	get a count of the number of rows
*/
SELECT COUNT(*) AS "Number of Rows in Table" FROM Sales.SalesOrderDetail


/*
	get a count of the number of unique rows
*/
SELECT COUNT(DISTINCT ProductID) AS "Distinct Number of ProductIDs" FROM Sales.SalesOrderDetail


/*
	manually calculate density for ProductID
*/
SELECT (1.0/(SELECT COUNT(DISTINCT ProductID) AS "ProductID density" FROM Sales.SalesOrderDetail)) 


/*
	manually calculate density for ProductID + SalesOrderID + SalesOrderDetailID combination
*/
SELECT (1.0/(SELECT COUNT(DISTINCT cast(ProductID as varchar(255)) + ' ' + cast(SalesOrderID as varchar(255)) + ' ' + cast(SalesOrderDetailID as varchar(255))) AS "ProductID + SalesOrderID + SalesOrderDetailID Density" FROM Sales.SalesOrderDetail)) 



/*
Density (1/distinct_rows) is calculated for each prefix of columns in the 
statistics object. Density includes the distinct rows from all of the sampled 
rows, including the rows with histogram boundary points. The results display one 
row for each density.

*/

DBCC SHOW_STATISTICS ("Sales.SalesOrderDetail",IX_SalesOrderDetail_ProductID)  WITH HISTOGRAM
GO

/*
	For value 738, RANGE_ROWS = 296, DISTINCT_RANGE_ROWS = 3
*/
SELECT 296/3

/*
	Are there really 296 values for those 3 ProductTypes?
*/
SELECT ProductID, COUNT(*) 
FROM Sales.SalesOrderDetail 
WHERE ProductID BETWEEN 731 AND 737
GROUP BY ProductID
ORDER BY ProductID

SELECT (130+44+110)

SELECT (130+44+110)/3
