/*******************************************************************************
Filename: 5_CaptureStatsUpdates.sql
Author: (C) 04/30/2012, Erin Stellato
Summary: This script was used in support of a session given by Erin Stellato
Feedback: mailto:erin@erinstellato.com

This script and information herein are provided "as is" without warranty
of any kind, either expressed or implied.

*******************************************************************************/

USE AdventureWorks
GO

/*	
	remove unique constraint for data load later
*/
DROP INDEX Sales.SalesOrderDetail.AK_SalesOrderDetail_rowguid


sp_dboption AdventureWorks

sp_dboption AdventureWorks, 'auto create statistics', 'on'
GO
sp_dboption AdventureWorks, 'auto update statistics', 'on'
GO

select name as "Statistics Name", auto_created as "Auto Created?", user_created as "User Created?", has_filter as "Filtered?", filter_definition as "Filter"
from sys.stats 
where object_id = object_id(N'Person.Address')


/********* RUN PROFILER ************/

/*
	Check stats for an index 
*/
DBCC SHOW_STATISTICS ("Person.Address",AK_Address_rowguid)

/* 
	rebuild the index to udpate stats with 100% sample 
*/
ALTER INDEX AK_Address_rowguid ON Person.Address REBUILD


/*
	Check stats for another index 
*/
DBCC SHOW_STATISTICS ("Person.Address",IX_Address_StateProvinceID)


/*
	update stats manually
*/
UPDATE STATISTICS Person.Address IX_Address_StateProvinceID WITH FULLSCAN


/*
	create a column statistic
*/
create statistics US_StateProvinceID on Person.Address (StateProvinceID) with fullscan


/*
	force auto-created stat by selecting against a column...
*/
select * from Person.Address WHERE city = 'Cleveland'




/*
	force auto-created stat by selecting against a column...
*/
SELECT SalesOrderID FROM Sales.SalesOrderDetail WHERE UnitPriceDiscount > 5000


/* Check stats for Sales.SalesOrderDetail */

sp_help "Sales.SalesOrderDetail" 

CREATE NONCLUSTERED INDEX IX_SalesOrderDetailID ON Sales.SalesOrderDetail (SalesOrderDetailID)

DBCC SHOW_STATISTICS ("Sales.SalesOrderDetail", IX_SalesOrderDetailID)


sp_dboption AdventureWorks, 'auto update statistics', 'on'


/* load in some data */
BULK INSERT AdventureWorks.Sales.SalesOrderDetail
FROM 'C:\SQLStuff\Dropbox\Statistics\Data\sod.txt'
WITH
(
	DATAFILETYPE = 'native',
	TABLOCK
)

/* stats haven't been updated... */
DBCC SHOW_STATISTICS ("Sales.SalesOrderDetail", IX_SalesOrderDetailID)


/*
	update one row... 
*/

UPDATE Sales.SalesOrderDetail SET OrderQty = 8 WHERE SalesOrderDetailID = 121317



/*
	show stats that have changed (if load Profiler data into a table)	
*/
SELECT 
	DB_NAME(st.DatabaseID) AS "Database", 
	OBJECT_NAME(st.ObjectID) AS "Table", 
	st.TextData AS "Statistic and Change", 
	st.Duration AS "Duration", 
	st.LoginName AS "LoginName"
FROM dbo.statsdata st
WHERE ObjectID > 100



/*
	optional clean up...
*/
DELETE FROM Sales.SalesOrderDetail WHERE SalesOrderDetailID > 121317
DROP TABLE dbo.statsdata


