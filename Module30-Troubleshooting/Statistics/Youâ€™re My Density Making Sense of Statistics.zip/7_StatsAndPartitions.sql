/*******************************************************************************
Filename: 7_StatsAndParitions.sql
Author: (C) 04/30/2012, Erin Stellato
Summary: This script was used in support of a session given by Erin Stellato
Feedback: mailto:erin@erinstellato.com

This script and information herein are provided "as is" without warranty
of any kind, either expressed or implied.

*******************************************************************************/

USE AdventureWorks
GO

/* add filesgroups */
ALTER DATABASE AdventureWorks
ADD FILEGROUP [FG1]

ALTER DATABASE AdventureWorks
ADD FILEGROUP [FG2]

ALTER DATABASE AdventureWorks
ADD FILEGROUP [FG3]

ALTER DATABASE AdventureWorks
ADD FILEGROUP [FG4]

ALTER DATABASE AdventureWorks
ADD FILEGROUP [FG5]

/* add files */
ALTER DATABASE AdventureWorks
ADD FILE 
  (NAME = N'2005',
  FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL10.SQL2008\MSSQL\DATA\2005.ndf',
  SIZE = 1MB,
  MAXSIZE = 100MB,
  FILEGROWTH = 1MB)
TO FILEGROUP [FG1]

ALTER DATABASE AdventureWorks
ADD FILE 
  (NAME = N'2006',
  FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL10.SQL2008\MSSQL\DATA\2006.ndf',
  SIZE = 1MB,
  MAXSIZE = 100MB,
  FILEGROWTH = 1MB)
TO FILEGROUP [FG2]

ALTER DATABASE AdventureWorks
ADD FILE 
  (NAME = N'2007',
  FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL10.SQL2008\MSSQL\DATA\2007.ndf',
  SIZE = 1MB,
  MAXSIZE = 100MB,
  FILEGROWTH = 1MB)
TO FILEGROUP [FG3]

ALTER DATABASE AdventureWorks
ADD FILE 
  (NAME = N'2008',
  FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL10.SQL2008\MSSQL\DATA\2008.ndf',
  SIZE = 1MB,
  MAXSIZE = 100MB,
  FILEGROWTH = 1MB)
TO FILEGROUP [FG4]

ALTER DATABASE AdventureWorks
ADD FILE 
  (NAME = N'2009',
  FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL10.SQL2008\MSSQL\DATA\2009.ndf',
  SIZE = 1MB,
  MAXSIZE = 100MB,
  FILEGROWTH = 1MB)
TO FILEGROUP [FG5]

/* define the partition function */
CREATE PARTITION FUNCTION OrderDateRangePFN(datetime)
AS 
RANGE LEFT FOR VALUES (
            '20051231 23:59:59.997', --everything in 2005
            '20061231 23:59:59.997', --everything in 2006
            '20071231 23:59:59.997', --everything in 2007
            '20081231 23:59:59.997', --everything in 2008
			'20091231 23:59:59.997') --everything in 2009
GO

            

/* create the parition scheme */
CREATE PARTITION SCHEME [OrderDateRangePScheme]
AS 
PARTITION OrderDateRangePFN TO 
( [FG1], [FG2], [FG3], [FG4], [FG5], [PRIMARY] )
GO


/* create the tables */
CREATE TABLE AdventureWorks.[dbo].[Orders]  
(
   [PurchaseOrderID] [int] NOT NULL,
   [EmployeeID] [int] NULL,
   [VendorID] [int] NULL,
   [TaxAmt] [money] NULL,
   [Freight] [money] NULL,
   [SubTotal] [money] NULL,
   [Status] [tinyint] NOT NULL,
   [RevisionNumber] [tinyint] NULL,
   [ModifiedDate] [datetime] NULL,
   [ShipMethodID]   tinyint NULL,
   [ShipDate] [datetime] NOT NULL, 
   [OrderDate] [datetime] NOT NULL, 
   [TotalDue] [money] NULL
) ON OrderDateRangePScheme(OrderDate)
GO

 
/* load 2005 - 2009 data */
INSERT dbo.[Orders]
   SELECT o.[PurchaseOrderID] 
         , o.[EmployeeID]
         , o.[VendorID]
         , o.[TaxAmt]
         , o.[Freight] 
         , o.[SubTotal] 
         , o.[Status] 
         , o.[RevisionNumber] 
         , o.[ModifiedDate] 
         , o.[ShipMethodID] 
         , o.[ShipDate] 
         , o.[OrderDate] 
         , o.[TotalDue] 
   FROM AdventureWorks.Purchasing.PurchaseOrderHeader AS o
      WHERE ([OrderDate] >= '20050101'
             AND [OrderDate] < '20100101')
GO



/* Determine the partition on which the data will reside. The following query returns the following information about each partition that contains data: 
how many rows exist within each partition, and the minimum and maximum OrderDate. 
A partition that does not contain rows will not be returned by this query. */
SELECT $partition.OrderDateRangePFN(o.OrderDate) 
         AS [Partition Number]
   , min(o.OrderDate) AS [Min Order Date]
   , max(o.OrderDate) AS [Max Order Date]
   , count(*) AS [Rows In Partition]
FROM dbo.Orders AS o
GROUP BY $partition.OrderDateRangePFN(o.OrderDate)
ORDER BY [Partition Number]
GO



/* add the clustered indexes */
ALTER TABLE Orders
ADD CONSTRAINT OrdersPK
   PRIMARY KEY CLUSTERED (OrderDate, PurchaseOrderID)
   ON OrderDateRangePScheme(OrderDate)
GO

/*
	check stats
*/
DBCC SHOW_STATISTICS ("dbo.Orders",OrdersPK)



/* create staging table */
CREATE TABLE AdventureWorks.[dbo].[Orders2010]  
(
   [PurchaseOrderID] [int] NOT NULL,
   [EmployeeID] [int] NULL,
   [VendorID] [int] NULL,
   [TaxAmt] [money] NULL,
   [Freight] [money] NULL,
   [SubTotal] [money] NULL,
   [Status] [tinyint] NOT NULL,
   [RevisionNumber] [tinyint] NULL,
   [ModifiedDate] [datetime] NULL,
   [ShipMethodID] [tinyint] NULL,
   [ShipDate] [datetime] NOT NULL, 
   [OrderDate] [datetime] NOT NULL, 
   [TotalDue] [money] NULL
) ON [FG1]
GO

/* load 2010 data */
INSERT dbo.[Orders2010]
   SELECT o.[PurchaseOrderID] 
         , o.[EmployeeID]
         , o.[VendorID]
         , o.[TaxAmt]
         , o.[Freight] 
         , o.[SubTotal] 
         , o.[Status] 
         , o.[RevisionNumber] 
         , o.[ModifiedDate] 
         , o.[ShipMethodID] 
         , o.[ShipDate] 
         , o.[OrderDate] 
         , o.[TotalDue] 
   FROM AdventureWorks.Purchasing.PurchaseOrderHeader AS o
      WHERE ([OrderDate] >= '20100101'
             AND [OrderDate] < '20110101')
GO


/* add clustered index to the staging table */
ALTER TABLE [Orders2010]
ADD CONSTRAINT Orders2010PK 
PRIMARY KEY CLUSTERED (OrderDate, PurchaseOrderID)
ON [FG1]
GO



/*
	check stats
*/
DBCC SHOW_STATISTICS ("dbo.Orders2010",Orders2010PK)


/* create a second staging table which is empty and will hold the partition's data when it is switched out. */

CREATE TABLE AdventureWorks.[dbo].[Orders2005]  
(
   [PurchaseOrderID] [int] NOT NULL,
   [EmployeeID] [int] NULL,
   [VendorID] [int] NULL,
   [TaxAmt] [money] NULL,
   [Freight] [money] NULL,
   [SubTotal] [money] NULL,
   [Status] [tinyint] NOT NULL,
   [RevisionNumber] [tinyint] NULL,
   [ModifiedDate] [datetime] NULL,
   [ShipMethodID] [tinyint] NULL,
   [ShipDate] [datetime] NOT NULL, 
   [OrderDate] [datetime] NOT NULL, 
   [TotalDue] [money] NULL
) ON [FG1]
GO

/* add clustered index to the staging table (it must have the same clustered index as the table in which it will become a partition (and the partition will become this table)). */

ALTER TABLE [Orders2005]
ADD CONSTRAINT Orders2005PK 
PRIMARY KEY CLUSTERED (OrderDate, PurchaseOrderID)
ON [FG1]
GO

DBCC SHOW_STATISTICS ("dbo.Orders2005",Orders2005PK)

/* Switch the old data out�into the second staging table. */

ALTER TABLE Orders
SWITCH PARTITION 1
TO Orders2005
GO


/*
	check stats
*/
DBCC SHOW_STATISTICS ("dbo.Orders2005",Orders2005PK)

UPDATE STATISTICS dbo.Orders2005


/* Alter the partition function to remove the boundary point for 2005. */

ALTER PARTITION FUNCTION OrderDateRangePFN()
MERGE RANGE ('20051231 23:59:59.997')
GO


/* This also removes the association between the filegroup and the partition scheme. 
Specifically, FG1 is no longer a part of the partition scheme. 
Since we will roll the new data through the same existing 5 partitions, 
we need to make FG1 the "next used" partition which will be the next partition 
to use for a split.*/

ALTER PARTITION SCHEME OrderDateRangePScheme 
              NEXT USED [FG1]
GO

/* Alter the partition function to add the new boundary point for 2010. */
ALTER PARTITION FUNCTION OrderDateRangePFN() 
SPLIT RANGE ('20101231 23:59:59.997')
GO



/* New code from KT */
ALTER TABLE dbo.Orders2010
ADD CONSTRAINT Orders2010CK
        CHECK ([OrderDate] >= '20100101 00:00:00.000' AND [OrderDate] <= '20101231 23:59:59.997')
GO

        
/* Switch the new data in from the first staging table. */

ALTER TABLE dbo.Orders2010
SWITCH TO dbo.Orders PARTITION 5;
GO

/*
	check stats again...
*/
DBCC SHOW_STATISTICS ("dbo.Orders",OrdersPK)


/*
	Look at data in the table
*/
SELECT $partition.OrderDateRangePFN(o.OrderDate) 
         AS [Partition Number]
   , min(o.OrderDate) AS [Min Order Date]
   , max(o.OrderDate) AS [Max Order Date]
   , count(*) AS [Rows In Partition]
FROM dbo.Orders AS o
GROUP BY $partition.OrderDateRangePFN(o.OrderDate)
ORDER BY [Partition Number]
GO



SET STATISTICS IO ON


--UPDATE STATISTICS dbo.Orders WITH FULLSCAN


CREATE STATISTICS US_Orders_2006 ON dbo.Orders (OrderDate) 
	WHERE OrderDate >'2006-01-01' AND OrderDate < '2006-12-31'
	WITH FULLSCAN


DBCC SHOW_STATISTICS ("dbo.Orders",US_Orders_2006)


CREATE STATISTICS US_Orders_2007 ON dbo.Orders (OrderDate) 
	WHERE OrderDate >'2007-01-01' AND OrderDate < '2007-12-31'
	WITH FULLSCAN


CREATE STATISTICS US_Orders_2008 ON dbo.Orders (OrderDate) 
	WHERE OrderDate >'2008-01-01' AND OrderDate < '2008-12-31'
	WITH FULLSCAN


CREATE STATISTICS US_Orders_2009 ON dbo.Orders (OrderDate) 
	WHERE OrderDate >'2009-01-01' AND OrderDate < '2009-12-31'
	WITH FULLSCAN

CREATE STATISTICS US_Orders_2010 ON dbo.Orders (OrderDate) 
	WHERE OrderDate >'2010-01-01' AND OrderDate < '2010-12-31'
	WITH FULLSCAN

DBCC SHOW_STATISTICS ("dbo.Orders",US_Orders_2007)

DBCC SHOW_STATISTICS ("dbo.Orders",US_Orders_2008)

DBCC SHOW_STATISTICS ("dbo.Orders",US_Orders_2009)

DBCC SHOW_STATISTICS ("dbo.Orders",US_Orders_2010)



/* Drop the staging tables 
Because all of the data is archived in the next, and final step, the staging data is not needed. A table drop is the fastest way to remove these tables.
*/

DROP TABLE dbo.Orders2010
GO
DROP TABLE dbo.Orders2005
GO

