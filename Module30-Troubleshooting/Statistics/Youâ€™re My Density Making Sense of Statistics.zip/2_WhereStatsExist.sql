/*******************************************************************************
Filename: 2_WhereStatsExist.sql
Author: (C) 04/30/2012, Erin Stellato
Summary: This script was used in support of a session given by Erin Stellato
Feedback: mailto:erin@erinstellato.com

This script and information herein are provided "as is" without warranty
of any kind, either expressed or implied.

*******************************************************************************/

USE AdventureWorks;
GO

/* 
	create dbo.PersonContact as a COPY of Person.Contact 
*/
SELECT TOP 1 * INTO dbo.PersonContact FROM Person.Contact
TRUNCATE TABLE dbo.PersonContact

/*	
	sys.stats is the easist way to see statistics for a table
*/
SELECT name AS "Statistics Name" 
FROM sys.stats 
WHERE object_id = object_id(N'dbo.PersonContact')

/*
	create a clustered index for the table
*/
CREATE UNIQUE CLUSTERED INDEX CI_ContactID ON dbo.PersonContact(ContactID)


/*
	check statistics
*/
DBCC SHOW_STATISTICS ("dbo.PersonContact", CI_ContactID)


/*
	load some data
*/
INSERT INTO dbo.PersonContact
           ([NameStyle]
           ,[Title]
           ,[FirstName]
           ,[MiddleName]
           ,[LAStName]
           ,[Suffix]
           ,[EmailAddress]
           ,[EmailPromotion]
           ,[Phone]
           ,[PasswordHash]
           ,[PasswordSalt]
           ,[AdditionalContactInfo]
           ,[rowguid]
           ,[ModifiedDate])
SELECT
			[NameStyle]
           ,[Title]
           ,[FirstName]
           ,[MiddleName]
           ,[LAStName]
           ,[Suffix]
           ,[EmailAddress]
           ,[EmailPromotion]
           ,[Phone]
           ,[PasswordHash]
           ,[PasswordSalt]
           ,[AdditionalContactInfo]
           ,[rowguid]
           ,[ModifiedDate]
FROM Person.Contact
GO

/*
	check statistics again
*/
DBCC SHOW_STATISTICS ("dbo.PersonContact", CI_ContactID)


/*
	create a non-clustered index for the table
*/
CREATE NONCLUSTERED INDEX IX_PersonContact_LastName_FirstName ON dbo.PersonContact (LastName,FirstName)

/*
	check statistics
*/
DBCC SHOW_STATISTICS ("dbo.PersonContact", IX_PersonContact_LastName_FirstName)


/*
	re-run sys.stats query
*/
SELECT name AS "Statistics Name" 
FROM sys.stats 
WHERE object_id = object_id(N'dbo.PersonContact')


/*
	check to see if auto-create statistics is enabled 
*/
sp_dboption AdventureWorks


/*
	enable auto-create statistics
*/
sp_dboption AdventureWorks, 'auto create statistics', 'on'


/*
	select against some column
*/
SELECT FirstName, LastName FROM  dbo.PersonContact WHERE MiddleName IS NULL


/*
	re-run sys.stats query
*/
SELECT name AS "Statistics Name", auto_created AS "Auto Created?"
FROM sys.stats 
WHERE object_id = object_id(N'dbo.PersonContact')


/*
	manually create a column statistic
*/

CREATE STATISTICS US_Name ON dbo.PersonContact (rowguid) WITH FULLSCAN

/*
	re-run sys.stats query
*/
SELECT name AS "Statistics Name", auto_created AS "Auto Created?", user_created AS "User Created?"
FROM sys.stats 
WHERE object_id = object_id(N'dbo.PersonContact')



/*`
	create filtered statistic 
*/
CREATE STATISTICS US_Filtered_NameStyle ON dbo.PersonContact (NameStyle) 
	WHERE NameStyle > 0
	WITH FULLSCAN


/*
	re-run sys.stats query
*/
SELECT name AS "Statistics Name", auto_created AS "Auto Created?", user_created AS "User Created?", has_filter AS "Filtered?", filter_definition AS "Filter", no_recompute AS "Recompute"
FROM sys.stats 
WHERE object_id = object_id(N'dbo.PersonContact')

/*
	old way...it's deprecated
*/
sp_helpstats 'dbo.PersonContact'


/*
	Still need a query that shows all stats and their columns...
*/

sp_helpindex "dbo.PersonContact"

sp_SQLskills_SQL2008_helpindex "dbo.PersonContact"

/*
	reset
*/
DROP TABLE dbo.PersonContact;
GO
sp_dboption AdventureWorks, 'auto create statistics', 'off'

