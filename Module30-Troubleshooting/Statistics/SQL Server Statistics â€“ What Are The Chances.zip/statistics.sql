USE EdwardsVeterinary

--Make sure that we're using a clean version of the database
USE [master]
ALTER DATABASE [EdwardsVeterinary] SET SINGLE_USER WITH ROLLBACK IMMEDIATE
RESTORE DATABASE [EdwardsVeterinary] FROM  DISK = N'D:\SQL Sentry\abstracts\stats\edvet.bak' WITH  FILE = 1,  NOUNLOAD,  REPLACE,  STATS = 5
ALTER DATABASE [EdwardsVeterinary] SET MULTI_USER

use EdwardsVeterinary

--View current statistics - note the difference using the ALL argument

EXEC sp_helpstats N'Pet', 'ALL'

--Add index to Pet table on PetType and PetBreed columns
CREATE NONCLUSTERED INDEX [PetType] ON [dbo].[Pet]
(
	[PetType] ASC,
	[PetBreed] ASC
)

EXEC sp_helpstats N'Pet', 'ALL'

--Viewing statistics from the sys.stats catalog view
--STATS_DATE works on SQL Server 2008+
SELECT object_id, name, stats_id, auto_created, user_created, no_recompute, has_filter, filter_definition, is_temporary
, STATS_DATE(object_id, stats_id) as Stats_Date
FROM sys.stats
WHERE name LIKE '%pet%' 


--Viewing statisics using sys.dm_db_stats_properties
--Available after 2008R2 SP2
SELECT sp.stats_id, name, filter_definition, last_updated, rows, rows_sampled, steps, unfiltered_rows, modification_counter 
FROM sys.stats AS stat 
CROSS APPLY sys.dm_db_stats_properties(stat.object_id, stat.stats_id) AS sp
WHERE stat.object_id = object_id('Pet');

--Viewing the stats blob using DBCC SHOW_STATISTICS

DBCC SHOW_STATISTICS (N'Pet', PetType)

--Statistics are used to determine the optimal execution plan
--Is the predicate selective enough for a index scan + bookmark lookup or will it do a clustered index scan?

SELECT *
FROM Pet
WHERE PetType = 'Dog'

SELECT *
FROM Pet
WHERE PetType = 'Reptile'

--Create a set of statistics based on a predicate

SELECT *
FROM Pet
WHERE PetName like 'Abb%'

--View new column based statistics
EXEC sp_helpstats N'Pet','All' 

--Here is the distribution of names within the column
SELECT petname,
       count(petname)
FROM pet
GROUP BY petname
ORDER BY petname

--View the new statistics using DBCC SHOW_STATISTICS
DBCC SHOW_STATISTICS ('Pet', _WA_Sys_00000004_21B6055D) 

select 28770 * 0.001121076

--Can we prove that the numbers in the histogram are accurate?
SELECT 'Alexander the Great Dane',
       count(*)
FROM pet
WHERE petname = 'Alexander the Great Dane'

SELECT 'Ann',
       count(*)
  FROM pet WHERE petname = 'Ann'

SELECT DISTINCT petname,
                count(petname)
  FROM pet 
  WHERE petname > 'Alexander the great dane'
  AND petname <'Ann'
  GROUP BY petname 
  
DBCC SHOW_STATISTICS (N'Pet', _WA_Sys_00000004_21B6055D)

 --PetBreed is part of the PetType index, but not the highest value column
--Are the statistics from PetType enough to gather good plans for PetBreed?

SELECT *
  FROM Pet
  WHERE PetBreed = 'Gecko'

SELECT *
  FROM Pet 
  WHERE PetBreed = 'Ferret'

SELECT *
  FROM Pet 
  WHERE PetBreed = 'Beagle' 
  
--View the new statistic
EXEC sp_helpstats N'Pet','All' 

--So what happens when statistics are out of date?

--We'll update the Pet table with 100 Geckos named Tom
--Note - this isn't enough of a change to kick off the auto-update
DECLARE @count INT
SET @count = 100

WHILE @count > 0
	BEGIN
	INSERT INTO Pet(PetType, PetBreed, PetName, OwnerId)
	VALUES('Reptile', 'Gecko', 'Tom', 100)
	SET @count = @count - 1
	END

--Now let's look at the query plan when we query for reptiles
SELECT *
FROM Pet
WHERE PetType = 'Reptile'


--Here's a good example of the modification counter
SELECT sp.stats_id, name, filter_definition, last_updated, rows, rows_sampled, steps, unfiltered_rows, modification_counter 
FROM sys.stats AS stat 
CROSS APPLY sys.dm_db_stats_properties(stat.object_id, stat.stats_id) AS sp
WHERE stat.object_id = object_id('Pet');

--Now let's rebuild the PetType index which will also update the statistics 
USE [EdwardsVeterinary]
GO
ALTER INDEX [PetType] ON [dbo].[Pet] REBUILD 

--show that the statistic has been rebuilt
DBCC SHOW_STATISTICS ('Pet', PetType)

--Does this give us a better execution plan?
SELECT *
FROM Pet
WHERE PetType = 'Reptile'


