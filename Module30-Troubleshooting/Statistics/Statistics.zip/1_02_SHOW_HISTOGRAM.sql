/*
Demo Script #1(b)

SQL Saturday #445, Raleigh

October 10th, 2015

Statistics are hidden treasure. 

Slava Murygin

Statistics' graphical representation.

*/

use [Test_Statistics]
GO
DECLARE @Table varchar(100) = 'Person.Person';
DECLARE @Statistic SYSNAME = 'IX_Person_LastName_FirstName_MiddleName';
-- DECLARE @Statistic SYSNAME = '_WA_Sys_00000002_693CA210';
DECLARE @SQL VARCHAR(MAX) = 'DBCC SHOW_STATISTICS (''' + @Table + ''', ' + @Statistic + ') WITH HISTOGRAM ';

CREATE TABLE #tbl_Statistic_Histogram(
	[RANGE_HI_KEY] sql_VARIANT
,   [RANGE_ROWS] INT
,   [EQ_ROWS] INT
,   [DISTINCT_RANGE_ROWS]  INT
,   [AVG_RANGE_ROWS] NUMERIC
,   [TOTAL_ROWS] AS [RANGE_ROWS] + [EQ_ROWS]
,	[STEP_ID] TINYINT IDENTITY (1,1) PRIMARY KEY
)

INSERT INTO #tbl_Statistic_Histogram EXEC (@SQL);

DECLARE @c TINYINT = (SELECT MAX(STEP_ID) FROM #tbl_Statistic_Histogram); -- Number of histogram steps
DECLARE @MRange BIGINT = (SELECT MAX(TOTAL_ROWS) FROM #tbl_Statistic_Histogram); -- Max Number of items in range
DECLARE @CSize FLOAT = 100;
DECLARE @FSize FLOAT = @CSize * 1.1;
DECLARE @HRate FLOAT = (@FSize * @c / 1.5) / @MRange; -- Dimensions 1x2
DECLARE @Diagram VARCHAR(MAX)=''

SELECT STEP_ID, CAST(RANGE_HI_KEY as VARCHAR) AS RANGE_HI_KEY,
	RANGE_ROWS, EQ_ROWS, DISTINCT_RANGE_ROWS, AVG_RANGE_ROWS, TOTAL_ROWS, 
	CONVERT(GEOMETRY, 'POLYGON((' + CONVERT(VARCHAR,(STEP_ID-1) * @FSize) + ' 0' + 
		+ ',' + CONVERT(VARCHAR,(STEP_ID-1) * @FSize + @CSize) + ' 0' + 
		+ ',' + CONVERT(VARCHAR,(STEP_ID-1) * @FSize + @CSize) + ' ' + CONVERT(VARCHAR,TOTAL_ROWS * @HRate)
		+ ',' + CONVERT(VARCHAR,(STEP_ID-1) * @FSize) + ' ' + CONVERT(VARCHAR,TOTAL_ROWS * @HRate) 
		+ ',' + CONVERT(VARCHAR,(STEP_ID-1) * @FSize) + ' 0' + '))') AS TOTAL_ROWS_BAR,
	CONVERT(GEOMETRY, 'POLYGON((' + CONVERT(VARCHAR,(STEP_ID-1) * @FSize) + ' 0' + 
		+ ',' + CONVERT(VARCHAR,(STEP_ID-1) * @FSize + @CSize) + ' 0' + 
		+ ',' + CONVERT(VARCHAR,(STEP_ID-1) * @FSize + @CSize) + ' ' + CONVERT(VARCHAR,DISTINCT_RANGE_ROWS * @HRate)
		+ ',' + CONVERT(VARCHAR,(STEP_ID-1) * @FSize) + ' ' + CONVERT(VARCHAR,DISTINCT_RANGE_ROWS * @HRate) 
		+ ',' + CONVERT(VARCHAR,(STEP_ID-1) * @FSize) + ' 0' + '))') AS DISTINCT_RANGE_BAR
FROM #tbl_Statistic_Histogram ORDER BY STEP_ID;

DROP TABLE #tbl_Statistic_Histogram