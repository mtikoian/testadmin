/*
Demo Script #2

SQL Saturday #445, Raleigh

October 10th, 2015

Statistics are hidden treasure. 

Slava Murygin

Database Options.
Case of Statistics Auto Update.

*/
USE [Test_Statistics]
GO
ALTER DATABASE [Test_Statistics] SET AUTO_CREATE_STATISTICS ON;
GO
ALTER DATABASE [Test_Statistics] SET AUTO_UPDATE_STATISTICS ON;
GO
/* Check Staitstics before the update */
SELECT s.[stats_id], s.[name] AS [StatisticName]
	, sp.last_updated AS [StatisticUpdateDate]
	, s.auto_created
	, s.user_created
	, sp.rows
	, sp.rows_sampled
	, sp.steps
	, sp.modification_counter
FROM [sys].[stats] AS [s]
	OUTER APPLY sys.dm_db_stats_properties ([s].[object_id],[s].[stats_id]) AS [sp]
WHERE [s].[object_id] = OBJECT_ID(N'Person.Person')
ORDER BY s.[stats_id]
OPTION (RECOMPILE);
GO
/*
# of records = 19972

Rule #3: 500 + 20% = 4494 records' updates will trigger Statistic Auto Update
*/
/* Modify one less record to do not trigger auto-update */
;WITH PP AS (SELECT TOP 4493 * FROM Person.Person)
UPDATE PP SET PersonType = PersonType;
GO
SELECT s.[stats_id], s.[name] AS [StatisticName]
	, sp.last_updated AS [StatisticUpdateDate]
	, s.auto_created
	, s.user_created
	, sp.rows
	, sp.rows_sampled
	, sp.steps
	, sp.modification_counter
FROM [sys].[stats] AS [s]
	OUTER APPLY sys.dm_db_stats_properties ([s].[object_id],[s].[stats_id]) AS [sp]
WHERE [s].[object_id] = OBJECT_ID(N'Person.Person')
ORDER BY s.[stats_id]
OPTION (RECOMPILE);
GO
/* In Order to Auto-Update statistics we have to run query to use it */
SELECT TOP 1 * FROM Person.Person WHERE PersonType = 'EM';
GO
SELECT s.[stats_id], s.[name] AS [StatisticName]
	, sp.last_updated AS [StatisticUpdateDate]
	, s.auto_created
	, s.user_created
	, sp.rows
	, sp.rows_sampled
	, sp.steps
	, sp.modification_counter
FROM [sys].[stats] AS [s]
	OUTER APPLY sys.dm_db_stats_properties ([s].[object_id],[s].[stats_id]) AS [sp]
WHERE [s].[object_id] = OBJECT_ID(N'Person.Person')
ORDER BY s.[stats_id]
OPTION (RECOMPILE);
GO
/* Statisticas are not updated yet */
/* Will do one mor update */
;WITH PP AS (SELECT TOP 1 * FROM Person.Person)
UPDATE PP SET PersonType = PersonType
OPTION (RECOMPILE);
GO
SELECT s.[stats_id], s.[name] AS [StatisticName]
	, sp.last_updated AS [StatisticUpdateDate]
	, s.auto_created
	, s.user_created
	, sp.rows
	, sp.rows_sampled
	, sp.steps
	, sp.modification_counter
FROM [sys].[stats] AS [s]
	OUTER APPLY sys.dm_db_stats_properties ([s].[object_id],[s].[stats_id]) AS [sp]
WHERE [s].[object_id] = OBJECT_ID(N'Person.Person')
ORDER BY s.[stats_id]
OPTION (RECOMPILE);
GO
/* Will run the query again */
SELECT TOP 1 * FROM Person.Person WHERE PersonType = 'EM';
GO
SELECT s.[stats_id], s.[name] AS [StatisticName]
	, sp.last_updated AS [StatisticUpdateDate]
	, s.auto_created
	, s.user_created
	, sp.rows
	, sp.rows_sampled
	, sp.steps
	, sp.modification_counter
FROM [sys].[stats] AS [s]
	OUTER APPLY sys.dm_db_stats_properties ([s].[object_id],[s].[stats_id]) AS [sp]
WHERE [s].[object_id] = OBJECT_ID(N'Person.Person')
ORDER BY s.[stats_id]
OPTION (RECOMPILE);
GO
/* Statistics ARE updated!!! */
