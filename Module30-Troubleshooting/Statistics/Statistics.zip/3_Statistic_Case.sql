/*
Demo Script #3

SQL Saturday #445, Raleigh

October 10th, 2015

Statistics are hidden treasure. 

Slava Murygin

Update of statistics takes time and invalidates Good Execution plan.

CASE:
Big retail company, which has hundreds of departments and managers who monitor their orders.
Application sends requests to the database every 15 seconds for each manager.

*/
USE [Test_Statistics]
GO
CREATE INDEX IX_SalesOrderHeader_Date ON Sales.SalesOrderHeader (OrderDate)
GO
DBCC FREEPROCCACHE
GO


/* Weekly statistic Update procedure */
UPDATE STATISTICS Sales.SalesOrderHeader; 
GO 
/* Mr. Martin is coming to work pretty early on Monday and executes his query first */
DECLARE @SQL NVARCHAR(1000) = '
     SELECT h.AccountNumber FROM Sales.SalesOrderHeader AS h
	 INNER JOIN Person.Person AS p ON h.CustomerID = p.BusinessEntityID
     WHERE p.LastName = @LastName and h.OrderDate >= @OrderDate;';
DECLARE @LastName NVARCHAR(100) = N'Martin';
DECLARE @OrderDate DATETIME = '2014-07-01';

SET STATISTICS IO ON
EXECUTE sp_executesql @SQL,  
     N'@LastName NVARCHAR(100), @OrderDate DATETIME',
     @LastName = @LastName, @OrderDate = @OrderDate;
SET STATISTICS IO OFF 
/*
Table 'Worktable'. Scan count 0, logical reads 0, physical reads 0, read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.
Table 'SalesOrderHeader'. Scan count 1, logical reads 2, physical reads 0, read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.
*/
GO

/*
Why that plan was chosen?
Look at statistics for two used indexes:
*/
DBCC SHOW_STATISTICS ('Person.Person','IX_Person_LastName_FirstName_MiddleName') WITH HISTOGRAM;
GO
DBCC SHOW_STATISTICS ('Sales.SalesOrderHeader','IX_SalesOrderHeader_Date') WITH HISTOGRAM;
GO
/*
Expected number of rows for "LastName = 'Martin'" is 171 with density 0.008561
Expected number of rows for "OrderDate = '2014-07-01'" is 0 with 0 density!
*/

/* During the day there were added some new data */
INSERT INTO Sales.SalesOrderHeader(
    RevisionNumber, OrderDate, DueDate, ShipDate, Status,
    OnlineOrderFlag, PurchaseOrderNumber,
    AccountNumber, CustomerID, SalesPersonID, TerritoryID,
    BillToAddressID, ShipToAddressID, ShipMethodID,
    CreditCardID, CreditCardApprovalCode, CurrencyRateID,
    SubTotal, TaxAmt, Freight, Comment,
    rowguid, ModifiedDate)
SELECT     RevisionNumber
    , DATEADD(DAY, 92,OrderDate)
    , DATEADD(DAY, 92,DueDate)
    , DATEADD(DAY, 92,ShipDate)
    , Status, OnlineOrderFlag, PurchaseOrderNumber,
    AccountNumber, CustomerID, SalesPersonID, TerritoryID,
    BillToAddressID, ShipToAddressID, ShipMethodID,
    CreditCardID, CreditCardApprovalCode, CurrencyRateID,
    SubTotal, TaxAmt, Freight, Comment,
    NewId(), ModifiedDate
FROM Sales.SalesOrderHeader
WHERE OrderDate = '2014-03-31'; 
/*
-- Restore to previous state
DELETE FROM Sales.SalesOrderHeader
WHERE OrderDate = '2014-07-01';
*/

GO

/* By the end of the day Mr. Martin and everybody else are experiencing delays */
DECLARE @SQL NVARCHAR(1000) = '
     SELECT h.AccountNumber FROM Sales.SalesOrderHeader AS h
	 INNER JOIN Person.Person AS p ON h.CustomerID = p.BusinessEntityID
     WHERE p.LastName = @LastName and h.OrderDate >= @OrderDate;';
DECLARE @LastName NVARCHAR(100) = N'Martin';
DECLARE @OrderDate DATETIME = '2014-07-01';

SET STATISTICS IO ON
EXECUTE sp_executesql @SQL,  
     N'@LastName NVARCHAR(100), @OrderDate DATETIME',
     @LastName = @LastName, @OrderDate = @OrderDate;
SET STATISTICS IO OFF 
/*
Table 'Person'. Scan count 0, logical reads 813, physical reads 0, read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.
Table 'SalesOrderHeader'. Scan count 1, logical reads 815, physical reads 0, read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.

IO consumption increased in 814 times!!!
*/
GO

/* EMERGENCY Statistic Update */
UPDATE STATISTICS Sales.SalesOrderHeader; 
GO 
/* Some more new data came */
INSERT INTO Sales.SalesOrderHeader(
    RevisionNumber, OrderDate, DueDate, ShipDate, Status,
    OnlineOrderFlag, PurchaseOrderNumber,
    AccountNumber, CustomerID, SalesPersonID, TerritoryID,
    BillToAddressID, ShipToAddressID, ShipMethodID,
    CreditCardID, CreditCardApprovalCode, CurrencyRateID,
    SubTotal, TaxAmt, Freight, Comment,
    rowguid, ModifiedDate)
SELECT TOP 1 RevisionNumber
    , DATEADD(DAY, 92,OrderDate)
    , DATEADD(DAY, 92,DueDate)
    , DATEADD(DAY, 92,ShipDate)
    , Status, OnlineOrderFlag, PurchaseOrderNumber,
    AccountNumber, CustomerID, SalesPersonID, TerritoryID,
    BillToAddressID, ShipToAddressID, ShipMethodID,
    CreditCardID, CreditCardApprovalCode, CurrencyRateID,
    SubTotal, TaxAmt, Freight, Comment,
    NewId(), ModifiedDate
FROM Sales.SalesOrderHeader
WHERE OrderDate = '2014-03-31'; 

/* Now Mr. Martin and everybody else are OK */
DECLARE @SQL NVARCHAR(1000) = '
     SELECT h.AccountNumber FROM Sales.SalesOrderHeader AS h
	 INNER JOIN Person.Person AS p ON h.CustomerID = p.BusinessEntityID
     WHERE p.LastName = @LastName and h.OrderDate >= @OrderDate;';
DECLARE @LastName NVARCHAR(100) = N'Martin';
DECLARE @OrderDate DATETIME = '2014-07-01';

SET STATISTICS IO ON
EXECUTE sp_executesql @SQL,  
     N'@LastName NVARCHAR(100), @OrderDate DATETIME',
     @LastName = @LastName, @OrderDate = @OrderDate;
SET STATISTICS IO OFF 
GO
/*
Table 'SalesOrderHeader'. Scan count 1, logical reads 695, physical reads 0, read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.
Table 'Person'. Scan count 1, logical reads 5, physical reads 0, read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.
*/


/* THE NEXT DAY */ 

/* Newly implemented nightly Statistic Update */
UPDATE STATISTICS Sales.SalesOrderHeader; 
GO 

/* Mr. Martin is coming to work pretty early on Monday and executes his query first */
DECLARE @SQL NVARCHAR(1000) = '
     SELECT h.AccountNumber FROM Sales.SalesOrderHeader AS h
	 INNER JOIN Person.Person AS p ON h.CustomerID = p.BusinessEntityID
     WHERE p.LastName = @LastName and h.OrderDate >= @OrderDate;';
DECLARE @LastName NVARCHAR(100) = N'Martin';
DECLARE @OrderDate DATETIME = '2014-07-02';

SET STATISTICS IO ON
EXECUTE sp_executesql @SQL,  
     N'@LastName NVARCHAR(100), @OrderDate DATETIME',
     @LastName = @LastName, @OrderDate = @OrderDate;
SET STATISTICS IO OFF 
GO