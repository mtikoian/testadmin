/*
Demo Script #1(a)

SQL Saturday #445, Raleigh

October 10th, 2015

Statistics are hidden treasure. 

Slava Murygin

- Initial Setup.
- Create, Update, Drop.
- Statistics� Internals
- Use of Statistics.

*/

use master;
GO
/*
BACKUP DATABASE [AdventureWorks2014]
	TO  DISK = N'c:\temp\AdventureWorks2014.bak' 
WITH NOFORMAT, COMPRESSION,	NOINIT, NAME = N'AdventureWorks2014-Full Database Backup', SKIP, STATS = 10;
*/
GO
IF  EXISTS (SELECT name FROM sys.databases WHERE name = N'Test_Statistics')
BEGIN
	ALTER DATABASE [Test_Statistics] SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
	DROP DATABASE [Test_Statistics]
END
GO
RESTORE DATABASE [Test_Statistics] 
FROM  DISK = N'C:\SS2014\Backup\AdventureWorks2014_2.bak' WITH  FILE = 1,  
MOVE N'AdventureWorks2014_Data' TO N'C:\SS2014\Data\Test_Statistics_Data.mdf',  
MOVE N'AdventureWorks2014_Log' TO N'C:\SS2014\Data\Test_Statistics_Log.ldf',  
NOUNLOAD,  REPLACE,  STATS = 5;
GO
use [Test_Statistics];
GO
/* *********************************************************************************************************************** */
/* In the beginning there are statistics ONLY for Indexes */

SELECT s.[stats_id], s.[name] AS [StatisticName]
	, STATS_DATE(s.[object_id], s.[stats_id]) AS [StatisticUpdateDate]
	, s.auto_created
	, s.user_created
	, i.rowmodctr
FROM sys.stats as s
 LEFT JOIN sys.sysindexes as i 	ON s.object_id = i.id and s.name = i.name
WHERE s.object_id = OBJECT_ID('Person.Person')
ORDER BY s.[stats_id];
GO
/* There are two ways to gather Stat info. We will use the second way because it is little bit faster */
SELECT s.[stats_id], s.[name] AS [StatisticName]
	, sp.last_updated AS [StatisticUpdateDate]
	, s.auto_created
	, s.user_created
	, sp.rows
	, sp.rows_sampled
	, sp.steps
	, sp.modification_counter
FROM [sys].[stats] AS [s]
	OUTER APPLY sys.dm_db_stats_properties ([s].[object_id],[s].[stats_id]) AS [sp]
WHERE [s].[object_id] = OBJECT_ID(N'Person.Person')
ORDER BY s.[stats_id];
GO
/* Way-1. Auto Creation of Statistics */
SELECT * FROM Person.Person
WHERE PersonType = 'EM';
GO
/* After using a column in where clause or Join SS will create statistics for that column */
SELECT s.[stats_id], s.[name] AS [StatisticName]
	, sp.last_updated AS [StatisticUpdateDate]
	, s.auto_created
	, s.user_created
	, sp.rows
	, sp.rows_sampled
	, sp.steps
	, sp.modification_counter
FROM [sys].[stats] AS [s]
	OUTER APPLY sys.dm_db_stats_properties ([s].[object_id],[s].[stats_id]) AS [sp]
WHERE [s].[object_id] = OBJECT_ID(N'Person.Person')
ORDER BY s.[stats_id];
GO
/* 
What does it mean?
_WA_Sys_00000002_693CA210

_WA - Washington State (where MS is locating)?
_Sys - Statistic has been created by the system?
_00000002 - Column ID for auto created statistic 
_693CA210 - Object ID in Binary format
*/
SELECT column_id, name, object_id, CAST(object_id as VARBINARY) as object_id_bin
FROM sys.columns
WHERE object_id = OBJECT_ID('Person.Person') and name = 'PersonType';
GO

/* Way-2. Can create statistics with any name */
CREATE STATISTICS Person_NameStyle on Person.Person (NameStyle) WITH FULLSCAN;
GO
SELECT s.[stats_id], s.[name] AS [StatisticName]
	, sp.last_updated AS [StatisticUpdateDate]
	, s.auto_created
	, s.user_created
	, sp.rows
	, sp.rows_sampled
	, sp.steps
	, sp.modification_counter
FROM [sys].[stats] AS [s]
	OUTER APPLY sys.dm_db_stats_properties ([s].[object_id],[s].[stats_id]) AS [sp]
WHERE [s].[object_id] = OBJECT_ID(N'Person.Person')
ORDER BY s.[stats_id];
GO
/*Can Update one or all statistics or Delete Statistics */
UPDATE STATISTICS Person.Person Person_NameStyle WITH SAMPLE 10 PERCENT;
GO
UPDATE STATISTICS Person.Person;
GO
SELECT s.[stats_id], s.[name] AS [StatisticName]
	, sp.last_updated AS [StatisticUpdateDate]
	, s.auto_created
	, s.user_created
	, sp.rows
	, sp.rows_sampled
	, sp.steps
	, sp.modification_counter
FROM [sys].[stats] AS [s]
	OUTER APPLY sys.dm_db_stats_properties ([s].[object_id],[s].[stats_id]) AS [sp]
WHERE [s].[object_id] = OBJECT_ID(N'Person.Person')
ORDER BY s.[stats_id];
GO
DROP STATISTICS Person.Person.Person_NameStyle;
/* Little inconsistancy between UPDATE/DROP syntax */
GO

/* Get statistic information */
/* First - from SSMS */
DBCC SHOW_STATISTICS('Person.Person','_WA_Sys_00000002_693CA210');
GO
DBCC SHOW_STATISTICS('Person.Person','_WA_Sys_00000002_693CA210') WITH STAT_HEADER;
/*
- Name
- Last Updated
- Rows in the dataset
- Rows Sampled
- Steps in the Histogram (Max=200)
- Desity - depreceated
- Average length
- Is it string?
- Filter...
*/
GO
DBCC SHOW_STATISTICS('Person.Person','_WA_Sys_00000002_693CA210') WITH DENSITY_VECTOR;
/* For auto-created statistics and statistics for one column - only one row
- Density = 
SELECT 1./COUNT(DISTINCT PersonType) FROM Person.Person;

- Avg Length Columns in statistic
*/
GO
/* For indexes with multiple columns it will retutn more columns */
DBCC SHOW_STATISTICS('Person.Person','IX_Person_LastName_FirstName_MiddleName') WITH DENSITY_VECTOR;
GO

/* For very dense index/column there will be just few rows */
DBCC SHOW_STATISTICS('Person.Person','_WA_Sys_00000002_693CA210') WITH HISTOGRAM;
GO
UPDATE STATISTICS Person.Person;
GO
/* For diverse column/index it can be up to 200 rows */
DBCC SHOW_STATISTICS('Person.Person','IX_Person_LastName_FirstName_MiddleName') WITH HISTOGRAM;
/* Note that only the first column is really used by statistics 
RANGE_HI_KEY	- Upper bound column value for a histogram step
RANGE_ROWS		- Estimated number of rows whose column value falls within a histogram step, excluding the upper bound.
EQ_ROWS			- Estimated number of rows whose column value equals the upper bound of the histogram step.
DISTINCT_RANGE_ROWS - Estimated number of rows with a distinct column value within a histogram step, excluding the upper bound.
AVG_RANGE_ROWS	- Average number of rows with duplicate column values within a histogram step, excluding the upper bound (RANGE_ROWS / DISTINCT_RANGE_ROWS for DISTINCT_RANGE_ROWS > 0).
*/
GO
/*
DBCC FREEPROCCACHE;
*/
GO
/* Row Estimation = 93.43908 REsult = 86 */
SELECT COUNT(*) FROM Person.Person WHERE LastName = 'Adams'
OPTION (RECOMPILE);
GO
/* Row Estimation = 2.776603 */
SELECT COUNT(*) FROM Person.Person WHERE 1=1 and LastName = 'Acabas'
OPTION (RECOMPILE);
GO
/* ------------------------------------------------------------------------- */
/* Repeate */
DBCC SHOW_STATISTICS('Person.Person','IX_Person_LastName_FirstName_MiddleName') WITH HISTOGRAM;
GO
/*
RANGE_HI_KEY	RANGE_ROWS	EQ_ROWS		DISTINCT_RANGE_ROWS	AVG_RANGE_ROWS
Alexander		28			123			15					1.866667
Alexander		18.59723	124.5854	4					4.626774
*/
SELECT *, AVG_RANGE_ROWS = RANGE_ROWS*1./DISTINCT_RANGE_ROWS FROM (
	SELECT RANGE_HI_KEY = 'Alexander'
	, RANGE_ROWS = (SELECT COUNT(*) FROM Person.Person WHERE LastName > 'Adams' and LastName < 'Alexander')
	, EQ_ROWS = (SELECT COUNT(*) FROM Person.Person WHERE LastName = 'Alexander')
	, DISTINCT_RANGE_ROWS = (SELECT COUNT(DISTINCT LastName) FROM Person.Person WHERE LastName > 'Adams' and LastName < 'Alexander')
) as a
GO
/* Does not match? */
DBCC SHOW_STATISTICS('Person.Person','IX_Person_LastName_FirstName_MiddleName') WITH HISTOGRAM;
GO
/* Do a full rebuild */
UPDATE STATISTICS Person.Person IX_Person_LastName_FirstName_MiddleName WITH FULLSCAN;
GO
/* Now it should be fine */
DBCC SHOW_STATISTICS('Person.Person','IX_Person_LastName_FirstName_MiddleName') WITH HISTOGRAM;
GO
/* Update ALL Statistics */
/*
Do not Forget to turn off execution plans
EXEC sp_updatestats;
*/