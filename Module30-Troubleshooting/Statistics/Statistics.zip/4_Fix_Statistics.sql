/*
Demo Script #4

SQL Saturday #445, Raleigh

October 10th, 2015

Statistics are hidden treasure. 

Slava Murygin

Fixing statistics' issue by Replacing it using UNDOCUMENTED option STATS_STREAM

CASE:
Replacing statistics for Index "IX_SalesOrderHeader_Date" on Column "OrderDate" in "Sales.SalesOrderHeader" Table

STATS_STREAM 7 Rules:
1. If statistic is on an index then fake statistic also must be on an index.
2. If table with statistic has clustered index then Fake table also must have clustered index.
3. Column order as long as types, sizes and nullability must be exactly the same for all columns within clustered index and regular index
4. Number of records in Fake table does not matter.
5. Name of Fake table and fake index/statistic does not matter.
6. Row sample size on Fake statistic does not matter
7. Fake clustered index uniquiness does not matter
*/

USE [Test_Statistics]
GO
/* 
Step 1: Initial Preparation 
*/
IF Exists (
	SELECT TOP 1 1 FROM tempdb.sys.tables
	WHERE object_id = OBJECT_ID('tempdb.dbo.#tmp_stat')
) DROP TABLE #tmp_stat;
GO
CREATE TABLE #tmp_stat(a VARBINARY(MAX), b BIGINT, c bigint);
GO
IF Exists (
	SELECT TOP 1 1 FROM sys.tables
	WHERE object_id = OBJECT_ID('tbl_Fake_Statistics')
) DROP TABLE tbl_Fake_Statistics
GO
------------------------------------------------------------
/*
Step 2: Generating fake dataset:
*/
GO
/* Create a table with exacly the column types, sizes and nullability we have in original table. */
CREATE TABLE tbl_Fake_Statistics(
	SalesOrderID INT NOT NULL,
	OrderDate DATETIME NOT NULL
)
GO
/* 
Fill 65K records for 256 days and 256 records per day 
Starting 2014-06-01
*/
;WITH t1 as (SELECT 1 as F1 UNION SELECT 2),              -- 2 Records
t2 AS (SELECT a1.F1*a2.F1 as F1 FROM t1 as a1, t1 as a2), -- 4 Records
t3 AS (SELECT a1.F1*a2.F1 as F1 FROM t2 as a1, t2 as a2), -- 16 Records
t4 AS (SELECT a1.F1*a2.F1 as F1 FROM t3 as a1, t3 as a2), -- 256 Records
t5 as (SELECT ROW_NUMBER() OVER (ORDER BY F1) AS 'RowNumber' FROM t4)
INSERT INTO tbl_Fake_Statistics(SalesOrderID, OrderDate)
SELECT CAST(RowNumber as INT), DATEADD(DAY, RowNumber, CAST('2014-05-31' AS DATETIME))
FROM t4, t5;
GO
/* Mimic Clustered and regular index from the original table */
CREATE CLUSTERED INDEX CLIX_Fake_Statistics ON tbl_Fake_Statistics (SalesOrderID);
GO
CREATE INDEX IX_Fake_Statistics ON tbl_Fake_Statistics (OrderDate);
GO
------------------------------------------------------------
/*
Step 3: Replacing the statistics
*/
GO
/* Update statistics on original table/column/index to Capture the original picture */
UPDATE STATISTICS Sales.SalesOrderHeader IX_SalesOrderHeader_Date;
GO
DBCC SHOW_STATISTICS ('Sales.SalesOrderHeader','IX_SalesOrderHeader_Date') WITH HISTOGRAM;
GO
DECLARE @SQL NVARCHAR(MAX);

/* Getting STATS_STREAM from Fake statistics */
SELECT @SQL = N'DBCC SHOW_STATISTICS ("tbl_Fake_Statistics","IX_Fake_Statistics") WITH STATS_STREAM';
INSERT INTO #tmp_stat
exec (@SQL);

/* Replacing STATS_STREAM for target Table/column/index */
/* 
New statistic is updated with NORECOMPUTE option.
That means it won't be updated automatically
*/
SELECT @SQL = N'UPDATE STATISTICS Sales.SalesOrderHeader IX_SalesOrderHeader_Date WITH NORECOMPUTE, STATS_STREAM = ' 
+ CAST(sys.fn_varbintohexsubstring(1,a,1,DATALENGTH(a)) AS NVARCHAR(MAX)) FROM #tmp_stat
exec (@SQL);
GO
/* Verifying changes */
DBCC SHOW_STATISTICS ('Sales.SalesOrderHeader','IX_SalesOrderHeader_Date') WITH HISTOGRAM;
GO
/* Cleanup */
DROP TABLE #tmp_stat, tbl_Fake_Statistics;
GO
/* THE END */



