/*============================================================================
  File:     1_WhereStatsExist.sql

  SQL Server Versions: 2005 onwards
------------------------------------------------------------------------------
  Written by Erin Stellato, SQLskills.com
  
  (c) 2013, SQLskills.com. All rights reserved.

  For more scripts and sample code, check out 
    http://www.SQLskills.com

  You may alter this code for your own *non-commercial* purposes. You may
  republish altered code as long as you include this copyright and give due
  credit, but you must obtain prior permission before blogging this code.
  
  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
  TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
  PARTICULAR PURPOSE.
============================================================================*/

USE AdventureWorks;
GO

/* 
	create dbo.PersonContact as a COPY of Person.Contact 
*/
SELECT TOP 1 * INTO dbo.PersonContact FROM Person.Contact;
TRUNCATE TABLE dbo.PersonContact;


/*	
	sys.stats is the easist way to see statistics for a table
*/
SELECT name AS "Statistics Name" 
FROM sys.stats 
WHERE object_id = object_id(N'dbo.PersonContact');


/*
	create a clustered index for the table
*/
CREATE UNIQUE CLUSTERED INDEX CI_ContactID ON dbo.PersonContact(ContactID);


/*
	check to see what statistics exist
*/
SELECT name AS "Statistics Name" 
FROM sys.stats 
WHERE object_id = object_id(N'dbo.PersonContact');
GO

sp_helpindex "dbo.PersonContact"
GO

sp_helpstats "dbo.PersonContact", 'ALL'
GO


/*
	load some data
*/
INSERT INTO dbo.PersonContact
           ([NameStyle]
           ,[Title]
           ,[FirstName]
           ,[MiddleName]
           ,[LAStName]
           ,[Suffix]
           ,[EmailAddress]
           ,[EmailPromotion]
           ,[Phone]
           ,[PasswordHash]
           ,[PasswordSalt]
           ,[AdditionalContactInfo]
           ,[rowguid]
           ,[ModifiedDate])
SELECT
			[NameStyle]
           ,[Title]
           ,[FirstName]
           ,[MiddleName]
           ,[LAStName]
           ,[Suffix]
           ,[EmailAddress]
           ,[EmailPromotion]
           ,[Phone]
           ,[PasswordHash]
           ,[PasswordSalt]
           ,[AdditionalContactInfo]
           ,[rowguid]
           ,[ModifiedDate]
FROM Person.Contact
GO


/*
	create a non-clustered index for the table
*/
CREATE NONCLUSTERED INDEX IX_PersonContact_LastName_FirstName ON dbo.PersonContact (LastName,FirstName)


/*
	check to see what statistics exist again
*/
SELECT name AS "Statistics Name" 
FROM sys.stats 
WHERE object_id = object_id(N'dbo.PersonContact');
GO

sp_helpindex "dbo.PersonContact"
GO

sp_helpstats "dbo.PersonContact", 'ALL'
GO


/*
	check to see if auto-create statistics is enabled 
*/
sp_dboption AdventureWorks --does not work in 2012

SELECT database_id,name, is_auto_create_stats_on, is_auto_update_stats_on, is_auto_update_stats_async_on
FROM sys.databases
WHERE name = 'AdventureWorks';



/*
	enable auto-create statistics
*/
sp_dboption AdventureWorks, 'auto create statistics', 'on'  --does not work in 2012

ALTER DATABASE AdventureWorks SET AUTO_CREATE_STATISTICS ON;


/*
	select against some column
*/
SELECT FirstName, LastName FROM  dbo.PersonContact WHERE MiddleName IS NULL;


/*
	check to see what statistics exist again
*/
SELECT name AS "Statistics Name" 
FROM sys.stats 
WHERE object_id = object_id(N'dbo.PersonContact');
GO

sp_helpindex "dbo.PersonContact"
GO

sp_helpstats "dbo.PersonContact", 'ALL'
GO


/*
	manually create a column statistic
*/
CREATE STATISTICS US_Name ON dbo.PersonContact (rowguid) WITH FULLSCAN;


/*
	check to see what statistics exist again
*/
SELECT name AS "Statistics Name" 
FROM sys.stats 
WHERE object_id = object_id(N'dbo.PersonContact');
GO

sp_helpindex "dbo.PersonContact"
GO

sp_helpstats "dbo.PersonContact",'ALL'
GO



/*
	create filtered statistic 
*/
CREATE STATISTICS US_Filtered_NameStyle ON dbo.PersonContact (NameStyle) 
	WHERE NameStyle > 0
	WITH FULLSCAN;


/*
	check to see what statistics exist again
*/
SELECT name AS "Statistics Name" 
FROM sys.stats 
WHERE object_id = object_id(N'dbo.PersonContact');
GO

sp_helpindex "dbo.PersonContact"
GO

sp_helpstats "dbo.PersonContact",'ALL'
GO



/*
	if you don't have this SP, download it from
	http://www.sqlskills.com/blogs/kimberly/category/sp_helpindex-rewrites.aspx
*/
sp_SQLskills_SQL2008_helpindex "dbo.PersonContact"
GO

SELECT  [sch].[name] + '.' + [so].[name] AS [TableName] ,
        [si].[index_id] AS [Index ID] ,
        [ss].[name] AS [Statistic] ,
        STUFF(( SELECT  ', ' + [c].[name]
                FROM    [sys].[stats_columns] [sc]
                        JOIN [sys].[columns] [c]
                         ON [c].[column_id] = [sc].[column_id]
                            AND [c].[object_id] = [sc].[OBJECT_ID]
                WHERE   [sc].[object_id] = [ss].[object_id]
                        AND [sc].[stats_id] = [ss].[stats_id]
                ORDER BY [sc].[stats_column_id]
              FOR
                XML PATH('')
              ), 1, 2, '') AS [ColumnsInStatistic] ,
        [ss].[auto_Created] AS [WasAutoCreated] ,
        [ss].[user_created] AS [WasUserCreated] ,
        [ss].[has_filter] AS [IsFiltered] ,
        [ss].[filter_definition] AS [FilterDefinition] ,
        [ss].[is_temporary] AS [IsTemporary]
FROM    [sys].[stats] [ss]
        JOIN [sys].[objects] AS [so] ON [ss].[object_id] = [so].[object_id]
        JOIN [sys].[schemas] AS [sch] ON [so].[schema_id] = [sch].[schema_id]
        LEFT OUTER JOIN [sys].[indexes] AS [si]
              ON [so].[object_id] = [si].[object_id]
                 AND [ss].[name] = [si].[name]
WHERE   [so].[object_id] = OBJECT_ID(N'dbo.PersonContact')
ORDER BY [ss].[user_created] ,
        [ss].[auto_created] ,
        [ss].[has_filter];
GO


/*
	reset
*/
USE AdventureWorks;
GO
DROP TABLE dbo.PersonContact;
GO
ALTER DATABASE AdventureWorks SET AUTO_CREATE_STATISTICS OFF;
