/*============================================================================
  File:     6_UsingStatistics.sql

  Summary:  This script shows statistics for a table, and how
			the information is used by the optimizer.

  SQL Server Versions: 2005 onwards
------------------------------------------------------------------------------
  Written by Erin Stellato, SQLskills.com
  
  (c) 2012, SQLskills.com. All rights reserved.

  For more scripts and sample code, check out 
    http://www.SQLskills.com

  You may alter this code for your own *non-commercial* purposes. You may
  republish altered code as long as you include this copyright and give due
  credit, but you must obtain prior permission before blogging this code.
  
  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
  TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
  PARTICULAR PURPOSE.
============================================================================*/

USE AdventureWorks;
GO

ALTER DATABASE AdventureWorks SET AUTO_CREATE_STATISTICS ON;
GO
ALTER DATABASE AdventureWorks SET AUTO_UPDATE_STATISTICS ON;
GO

IF EXISTS (SELECT * FROM sys.tables WHERE name = 'PersonContact')
	DROP TABLE dbo.PersonContact;

/* 
	create dbo.PersonContact as a COPY of Person.Contact 
*/
SELECT TOP 1 * INTO dbo.PersonContact FROM Person.Contact;
TRUNCATE TABLE dbo.PersonContact;

/*
	create a clustered and non-clustered index for the table
*/
CREATE UNIQUE CLUSTERED INDEX CI_ContactID ON dbo.PersonContact(ContactID);
CREATE NONCLUSTERED INDEX IX_PersonContact_LastName_FirstName ON dbo.PersonContact (LastName,FirstName);

/*
	load some data
*/
INSERT INTO dbo.PersonContact
           ([NameStyle]
           ,[Title]
           ,[FirstName]
           ,[MiddleName]
           ,[LastName]
           ,[Suffix]
           ,[EmailAddress]
           ,[EmailPromotion]
           ,[Phone]
           ,[PasswordHash]
           ,[PasswordSalt]
           ,[AdditionalContactInfo]
           ,[rowguid]
           ,[ModifiedDate])
SELECT
			[NameStyle]
           ,[Title]
           ,[FirstName]
           ,[MiddleName]
           ,[LAStName]
           ,[Suffix]
           ,[EmailAddress]
           ,[EmailPromotion]
           ,[Phone]
           ,[PasswordHash]
           ,[PasswordSalt]
           ,[AdditionalContactInfo]
           ,[rowguid]
           ,[ModifiedDate]
FROM Person.Contact;
GO


/*
	rebuild clustered index on the table, stats get updated for indexes
*/
ALTER INDEX CI_ContactID ON dbo.PersonContact REBUILD;


/*
	update statistics for NCI on the table
*/
UPDATE STATISTICS dbo.PersonContact IX_PersonContact_LastName_FirstName;
GO

DBCC SHOW_STATISTICS ("dbo.PersonContact", IX_PersonContact_LastName_FirstName);
GO


/*
	based on density, how many rows returned for a given value...
	888
*/
SELECT 1019972 * 0.0008826125


/*
	View just the histogram
*/
DBCC SHOW_STATISTICS ("dbo.PersonContact", IX_PersonContact_LastName_FirstName) WITH HISTOGRAM
GO

/*
	Are there really 2473 values for those 6 LastNames?
*/
SELECT LastName, COUNT(*) AS "Count"
FROM dbo.PersonContact 
WHERE LastName > 'Arroyo'
AND LastName < 'Avila'
GROUP BY LastName
ORDER BY LastName;


SELECT (24+58+30+998+2+1009+1008+1+989+1+1090) AS "Actual number of rows in range";

/*
	For value Avila, RANGE_ROWS = 4861, DISTINCT_RANGE_ROWS = 9
*/
SELECT 4861/9 AS "Actual average number of rows per value"


/*
	clear cache, enable execution plan, verify auto update on, run query
	note estimated and actual rows
*/

DBCC FREEPROCCACHE;
GO

SET STATISTICS IO ON;
GO

SELECT FirstName, LastName
FROM dbo.PersonContact
WHERE LastName = N'Ashton';


/*
	update statistics
*/
UPDATE STATISTICS dbo.PersonContact IX_PersonContact_LastName_FirstName WITH FULLSCAN;


/*
	check statistics 
*/
DBCC SHOW_STATISTICS ("dbo.PersonContact", IX_PersonContact_LastName_FirstName)

/*
	run query again
*/
SELECT FirstName, LastName
FROM dbo.PersonContact
WHERE LastName = N'Ashton';

/*
	plan didn't change
	let's free procedure cache and re-run
*/
DBCC FREEPROCCACHE;
GO


/*
	run query again - the plan changed
*/
SELECT FirstName, LastName
FROM dbo.PersonContact
WHERE LastName = N'Ashton';


/*
	let's "reset"
	update stats with default sample
	free procedure cache
*/
UPDATE STATISTICS dbo.PersonContact IX_PersonContact_LastName_FirstName;
GO
DBCC FREEPROCCACHE;
GO

/*
	check statistics 
*/
DBCC SHOW_STATISTICS ("dbo.PersonContact", IX_PersonContact_LastName_FirstName)

/*
	run query again
*/
SELECT FirstName, LastName
FROM dbo.PersonContact
WHERE LastName = N'Ashton';


/*
	update one row...
*/
UPDATE dbo.PersonContact 
	SET LastName = 'Potter', FirstName = 'Harry'
	WHERE ContactID = 52868



/*
	update statistics
*/
UPDATE STATISTICS dbo.PersonContact IX_PersonContact_LastName_FirstName WITH FULLSCAN;


/*
	check statistics 
*/
DBCC SHOW_STATISTICS ("dbo.PersonContact", IX_PersonContact_LastName_FirstName);

/*
	run query again
*/
SELECT FirstName, LastName
FROM dbo.PersonContact
WHERE LastName = N'Ashton';



/*
	what if the value is ouside the histogram?
*/

SELECT FirstName, LastName
FROM dbo.PersonContact
WHERE LastName = N'Zygler'


/*
	clean up
*/
DROP TABLE dbo.PersonContact;
GO