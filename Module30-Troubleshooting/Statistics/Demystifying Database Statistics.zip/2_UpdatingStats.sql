/*============================================================================
  File:     2_UpdatingStats.sql

  SQL Server Versions: 2005 onwards
------------------------------------------------------------------------------
  Written by Erin Stellato, SQLskills.com
  
  (c) 2013, SQLskills.com. All rights reserved.

  For more scripts and sample code, check out 
    http://www.SQLskills.com

  You may alter this code for your own *non-commercial* purposes. You may
  republish altered code as long as you include this copyright and give due
  credit, but you must obtain prior permission before blogging this code.
  
  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
  TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
  PARTICULAR PURPOSE.
============================================================================*/

USE AdventureWorks;
GO

ALTER DATABASE AdventureWorks SET AUTO_CREATE_STATISTICS ON;
GO
ALTER DATABASE AdventureWorks SET AUTO_UPDATE_STATISTICS OFF;
GO

IF EXISTS (SELECT * FROM sys.tables WHERE name = 'PersonContact')
	DROP TABLE dbo.PersonContact;

/* 
	create dbo.PersonContact as a COPY of Person.Contact 
*/
SELECT TOP 1 * INTO dbo.PersonContact FROM Person.Contact;
TRUNCATE TABLE dbo.PersonContact;

/*
	create a clustered and non-clustered index for the table
*/
CREATE UNIQUE CLUSTERED INDEX CI_ContactID ON dbo.PersonContact(ContactID);
CREATE NONCLUSTERED INDEX IX_PersonContact_LastName_FirstName ON dbo.PersonContact (LastName,FirstName);


/*
	manually create a column statistic
*/
CREATE STATISTICS US_Name ON dbo.PersonContact (rowguid) WITH FULLSCAN;


/*
	load some data
*/
INSERT INTO dbo.PersonContact
           ([NameStyle]
           ,[Title]
           ,[FirstName]
           ,[MiddleName]
           ,[LastName]
           ,[Suffix]
           ,[EmailAddress]
           ,[EmailPromotion]
           ,[Phone]
           ,[PasswordHash]
           ,[PasswordSalt]
           ,[AdditionalContactInfo]
           ,[rowguid]
           ,[ModifiedDate])
SELECT
			[NameStyle]
           ,[Title]
           ,[FirstName]
           ,[MiddleName]
           ,[LAStName]
           ,[Suffix]
           ,[EmailAddress]
           ,[EmailPromotion]
           ,[Phone]
           ,[PasswordHash]
           ,[PasswordSalt]
           ,[AdditionalContactInfo]
           ,[rowguid]
           ,[ModifiedDate]
FROM Person.Contact;
GO

/*
	check statistics 
*/
DBCC SHOW_STATISTICS ("dbo.PersonContact", CI_ContactID) WITH STAT_HEADER;
GO

DBCC SHOW_STATISTICS ("dbo.PersonContact", IX_PersonContact_LastName_FirstName) WITH STAT_HEADER;
GO

DBCC SHOW_STATISTICS ("dbo.PersonContact", US_Name) WITH STAT_HEADER;
GO

/*
	rebuild clustered index on the table, stats get updated for CI index
*/
ALTER INDEX CI_ContactID ON dbo.PersonContact REBUILD;


/*
	check statistics again - column stats not updated (even if rebuild all indexes)
*/
DBCC SHOW_STATISTICS ("dbo.PersonContact", CI_ContactID) WITH STAT_HEADER;
GO

DBCC SHOW_STATISTICS ("dbo.PersonContact", IX_PersonContact_LastName_FirstName) WITH STAT_HEADER;
GO

DBCC SHOW_STATISTICS ("dbo.PersonContact", US_Name) WITH STAT_HEADER;
GO


/*
	update statistics manually
*/
UPDATE STATISTICS dbo.PersonContact IX_PersonContact_LastName_FirstName WITH FULLSCAN;

UPDATE STATISTICS dbo.PersonContact US_Name WITH SAMPLE 50 PERCENT;



/*
	check statistics again 
*/
DBCC SHOW_STATISTICS ("dbo.PersonContact", CI_ContactID) WITH STAT_HEADER;
GO

DBCC SHOW_STATISTICS ("dbo.PersonContact", IX_PersonContact_LastName_FirstName) WITH STAT_HEADER;
GO

DBCC SHOW_STATISTICS ("dbo.PersonContact", US_Name) WITH STAT_HEADER;
GO