/*============================================================================
  File:     5_WhatAreStats.sql

  SQL Server Versions: 2005 onwards
------------------------------------------------------------------------------
  Written by Erin Stellato, SQLskills.com
  
  (c) 2012, SQLskills.com. All rights reserved.

  For more scripts and sample code, check out 
    http://www.SQLskills.com

  You may alter this code for your own *non-commercial* purposes. You may
  republish altered code as long as you include this copyright and give due
  credit, but you must obtain prior permission before blogging this code.
  
  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
  TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
  PARTICULAR PURPOSE.
============================================================================*/


USE AdventureWorks;
GO

DBCC SHOW_STATISTICS ( table_name | view_name , target ) 
[ WITH [ NO_INFOMSGS ] < option > [ , n ] ]
< option > :: =
    STAT_HEADER | DENSITY_VECTOR | HISTOGRAM
 
--DBCC SHOW_STATISTICS does not provide statistics for spatial indexes.


/*
	Note that IX_SalesOrderDetail_ProductID is on one column, ProductID
*/
sp_helpindex "Sales.SalesOrderDetail"

CREATE NONCLUSTERED INDEX FIX_SalesOrderDetail_OrderQty ON Sales.SalesOrderDetail (OrderQty) WHERE OrderQty > 25;

DBCC SHOW_STATISTICS ("Sales.SalesOrderDetail",IX_SalesOrderDetail_ProductID);



DBCC SHOW_STATISTICS ("Sales.SalesOrderDetail",IX_SalesOrderDetail_ProductID) WITH STAT_HEADER;
GO
DBCC SHOW_STATISTICS ("Sales.SalesOrderDetail",FIX_SalesOrderDetail_OrderQty) WITH STAT_HEADER;
GO


/*
Density - this information is not used by the Optimizer
String Index - Yes indicates that the statistics contain a string summary index 
to support estimation of result set sizes for LIKE conditions. 
A string index is only created on the first key column when it is of data type 
char, varchar, nchar, nvarchar, varchar(max), nvarchar(max), text, or ntext.
Unfiltered Rows - Total number of rows in the table before applying the filter 
expression. If Filter Expression is NULL, Unfiltered Rows is equal to the Rows header value.
*/



/*
	verify stats which exist
*/
SELECT name AS "Statistics Name", auto_created AS "Auto Created?", user_created AS "User Created?", has_filter AS "Filtered?", filter_definition AS "Filter", no_recompute AS "Recompute"
FROM sys.stats 
WHERE object_id = object_id(N'Sales.SalesOrderDetail');

/*
	need object_id
*/
SELECT *
FROM sys.stats 
WHERE object_id IN 
	(SELECT object_id FROM sys.objects WHERE name = 'SalesOrderDetail')

/*
	DMF only exists in 2008 R2 SP2 and 2012 SP1
*/
SELECT * FROM sys.dm_db_stats_properties(642101328, 1)



SELECT
    sch.name + '.' + so.name AS "Table",
    ss.name AS "Statistic",
	ss.auto_Created AS "Auto Created?",
	ss.user_created AS "User Created?",
	ss.has_filter AS "Filtered?", 
    ss.filter_definition AS "Filter Definition", 
    sp.last_updated AS "Stats Last Updated", 
    sp.rows AS "Rows in Table", 
    sp.rows_sampled AS "Rows Sampled", 
    sp.unfiltered_rows AS "Unfiltered Rows",
	sp.modification_counter AS "Row Modifications",
	sp.steps AS "Histogram Steps"
FROM sys.stats ss
JOIN sys.objects so ON ss.object_id = so.object_id
JOIN sys.schemas sch ON so.schema_id = sch.schema_id
CROSS APPLY sys.dm_db_stats_properties(so.object_id, ss.stats_id) AS sp
WHERE so.object_id = object_id('Sales.SalesOrderDetail')
ORDER BY ss.user_created, ss.auto_created, ss.has_filter;



DBCC SHOW_STATISTICS ("Sales.SalesOrderDetail",IX_SalesOrderDetail_ProductID) WITH DENSITY_VECTOR;
GO
/* 
Density (1/distinct_rows) is calculated for each prefix of columns in the 
statistics object. Density includes the distinct rows from all of the sampled 
rows, including the rows with histogram boundary points. The results display one 
row for each density.

Note this includes density for SalesOrderID and SalesOrderDetailID because
even though they are not in the index, they are the clustering key and
are in the leaf level of the index
*/


/*
	get a count of the number of rows
*/
SELECT COUNT(*) AS "Number of Rows in Table" FROM Sales.SalesOrderDetail;


/*
	get a count of the number of unique rows
*/
SELECT COUNT(DISTINCT ProductID) AS "Distinct Number of ProductIDs" FROM Sales.SalesOrderDetail;


/*
	manually calculate density for ProductID
*/
SELECT (1.0/(SELECT COUNT(DISTINCT ProductID) FROM Sales.SalesOrderDetail)) AS "ProductID Density";


/*
	manually calculate density for ProductID + SalesOrderID + SalesOrderDetailID combination
*/
SELECT (1.0/(SELECT COUNT(DISTINCT cast(ProductID as varchar(255)) + ' ' + cast(SalesOrderID as varchar(255)) + ' ' + cast(SalesOrderDetailID as varchar(255))) FROM Sales.SalesOrderDetail))  AS "ProductID + SalesOrderID + SalesOrderDetailID Density";


/*
	manually calculate how many rows would be returned for any given value
*/
SELECT (SELECT COUNT(*) AS "Number of Rows in Table" FROM Sales.SalesOrderDetail) * 
		(SELECT (1.0/(SELECT COUNT(DISTINCT ProductID) FROM Sales.SalesOrderDetail)) AS "ProductID Density")
		AS "Estimated number of rows for any one value";



DBCC SHOW_STATISTICS ("Sales.SalesOrderDetail",IX_SalesOrderDetail_ProductID)  WITH HISTOGRAM;
GO

/*
	For value 736, RANGE_ROWS = 204, DISTINCT_RANGE_ROWS = 3
*/
SELECT 204/3 AS "Average number of rows per value"

/*
	Are there really 296 values for those 3 ProductTypes?
*/
SELECT ProductID, COUNT(*) AS "Count"
FROM Sales.SalesOrderDetail 
WHERE ProductID BETWEEN 733 AND 735
GROUP BY ProductID
ORDER BY ProductID

SELECT (88+55+48) AS "Actual number of rows in range"



