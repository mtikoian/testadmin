/*============================================================================
  File:     3_ViewingStatsUpdates.sql

  SQL Server Versions: 2005 onwards
------------------------------------------------------------------------------
  Written by Erin Stellato, SQLskills.com
  
  (c) 2012, SQLskills.com. All rights reserved.

  For more scripts and sample code, check out 
    http://www.SQLskills.com

  You may alter this code for your own *non-commercial* purposes. You may
  republish altered code as long as you include this copyright and give due
  credit, but you must obtain prior permission before blogging this code.
  
  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
  TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
  PARTICULAR PURPOSE.
============================================================================*/

USE AdventureWorks
GO

/*	
	remove unique constraint for data load later
*/
DROP INDEX Sales.SalesOrderDetail.AK_SalesOrderDetail_rowguid


ALTER DATABASE AdventureWorks SET AUTO_CREATE_STATISTICS ON;
GO
ALTER DATABASE AdventureWorks SET AUTO_UPDATE_STATISTICS ON;
GO

SELECT name AS "Statistics Name", auto_created AS "Auto Created?", user_created AS "User Created?", has_filter AS "Filtered?", filter_definition AS "Filter"
FROM sys.stats 
WHERE object_id = object_id(N'Person.Address')


/********* RUN Profiler ************/
/********* RUN XEvents  ************/

/* 
	rebuild the index to udpate stats with 100% sample 
*/
ALTER INDEX AK_Address_rowguid ON Person.Address REBUILD;


/*
	update stats manually
*/
UPDATE STATISTICS Person.Address IX_Address_StateProvinceID WITH FULLSCAN;


/*
	create a column statistic
*/
CREATE STATISTICS US_StateProvinceID ON Person.Address (StateProvinceID) WITH FULLSCAN;


/*
	force auto-created stat by selecting against a column...
*/
SELECT * FROM Person.Address WHERE city = 'Cleveland';


/*
	force auto-created stat by selecting against a column (different table)...
*/
SELECT SalesOrderID FROM Sales.SalesOrderDetail WHERE UnitPriceDiscount > 5000;


/* 
	Check what stats exist for Sales.SalesOrderDetail 
*/

SELECT name AS "Statistics Name", auto_created AS "Auto Created?", user_created AS "User Created?", has_filter AS "Filtered?", filter_definition AS "Filter"
FROM sys.stats 
WHERE object_id = object_id(N'Sales.SalesOrderDetail')

CREATE NONCLUSTERED INDEX IX_SalesOrderDetailID ON Sales.SalesOrderDetail (SalesOrderDetailID);

/*
	check stats for the new index
*/
DBCC SHOW_STATISTICS ("Sales.SalesOrderDetail", IX_SalesOrderDetailID);



/* load in some data */
BULK INSERT AdventureWorks.Sales.SalesOrderDetail
FROM 'C:\SQLStuff\Dropbox\Statistics\Data\sod.txt'
WITH
(
	DATAFILETYPE = 'native',
	TABLOCK
);

/* 
	stats haven't been updated... 
*/
DBCC SHOW_STATISTICS ("Sales.SalesOrderDetail", IX_SalesOrderDetailID);


/*
	update one row... 
*/

UPDATE Sales.SalesOrderDetail SET OrderQty = 8 WHERE SalesOrderDetailID = 121317;



/*
	show stats that have changed
*/
DBCC SHOW_STATISTICS ("Sales.SalesOrderDetail", IX_SalesOrderDetailID);


/*
	run if load Profiler data into a table
*/
SELECT 
	DB_NAME(st.DatabaseID) AS "Database", 
	OBJECT_NAME(st.ObjectID) AS "Table", 
	st.TextData AS "Statistic and Change", 
	st.Duration AS "Duration", 
	st.LoginName AS "LoginName"
FROM dbo.statsdata st
WHERE ObjectID > 100



/*
	optional clean up...
*/
DELETE FROM Sales.SalesOrderDetail WHERE SalesOrderDetailID > 121317



