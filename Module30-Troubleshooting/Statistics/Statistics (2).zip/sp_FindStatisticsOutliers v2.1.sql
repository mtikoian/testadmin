USE master;
GO

SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
GO

IF OBJECT_ID('dbo.sp_FindStatisticsOutliers', N'P') IS NULL
BEGIN
	EXEC('CREATE PROC dbo.sp_FindStatisticsOutliers AS RETURN 0;');
END;
GO

ALTER PROCEDURE dbo.sp_FindStatisticsOutliers
	@DatabaseName sysname = NULL,
	@SchemaName sysname = NULL,
	@TableName sysname = NULL,
	@ColumnName sysname = NULL,
	@DebugFlag bit = 0
AS

/**************************************************

Written by G. Vern Rabe, of RabeData, LLC

You are free to use and distribute this stored procedure with no limitations,
as long as this comment header remains intact, and you agree to send any
suggestions or bug discoveries to vern@rabedata.com. Thank you

For every statistics object for the specified
@SchemaName and/or @TableName and/or @ColumnName,
read the minimum and maximum RANGE_HI_KEY values,
then query the table and look for outliers.

-- must have this table to store (and query) results
CREATE TABLE Utility.dbo.StatisticsOutliers (
	DatabaseName sysname NULL,
	SchemaName sysname NULL,
	TableName sysname NULL,
	ColumnName sysname NULL,
	BelowCount bigint NULL,
	AboveCount bigint NULL,
	StatisticsName sysname NULL,
	MinStatsValue sql_variant NULL,
	MaxStatsValue sql_variant NULL,
	StatisticsLastUpdateTimestamp datetime2(7) NULL,
	ModificationCount bigint NULL,
	CreateTimestamp datetime2(7) DEFAULT SYSDATETIME());

2016-02-28 gvr Initial (v1.0)
2016-03-29 gvr v2.0 Convert to using dynamic SQL to
	execute in a different database.
2016-05-29 gvr v2.1 Fix typo in syntax help
**************************************************/

SET NOCOUNT ON;
SET ARITHABORT ON;

DECLARE @SQL nvarchar(4000),
	@ErrMsg varchar(1000),
	@Retry int = 3,
	@StatisticsName sysname,
	@StatisticsLastUpdateTimestamp datetime2(7),
	@ModificationCount bigint;

-- if @DatabaseName is not supplied, display syntax and abort
IF @Databasename IS NULL
BEGIN;
	-- return help info
	SET @ErrMsg = 'Populates the Utility.dbo.StatisticsOutliers table with columns
containing data outside of the statistics histogram range.
These outliers could result in the optimizer making sub-optimal plan choices.

Usage: EXEC dbo.sp_FindStatisticsOutliers
	@DatabaseName = DatabaseName,
	@SchemaName = SchemaName,
	@TableName = TableName,
	@ColumnName = ColumnName;

The @DatabaseName input parameter is required, but all other input parameters are optional.

Example, for only one column:
EXEC dbo.sp_FindStatisticsOutliers
	@DatabaseName = ''AdventureWorks2014'',
	@SchemaName = ''Sales'',
	@TableName = ''SalesOrderDetail'',
	@ColumnName = ''ModifiedDate'';

Example, for entire database:
EXEC dbo.sp_FindStatisticsOutliers
	@DatabaseName = ''AdventureWorks2014'';

'
	RAISERROR(@ErrMsg, 9, 1);

	RETURN;
END;

WHILE @Retry > 0
BEGIN
	BEGIN TRY
		IF @DatabaseName <> DB_NAME()
		BEGIN
			-- need to call from dynamic SQL, executing in the specified database
			SET @SQL = 'USE ' + @DatabaseName + ';
EXEC sp_FindStatisticsOutliers
		@DatabaseName = ''' + @DatabaseName + ''',
		@SchemaName = ' + COALESCE('''' + @SchemaName + '''', 'NULL') + ',
		@TableName = ' + COALESCE('''' + @TableName + '''', 'NULL') + ',
		@ColumnName = ' + COALESCE('''' + @ColumnName + '''', 'NULL') + ',
		@DebugFlag = ' + COALESCE(CAST(@DebugFlag AS nvarchar(1)), 'NULL') + ';';

			IF @DebugFlag = 1
			BEGIN
				PRINT @SQL;
			END
			ELSE
			BEGIN
				EXEC(@SQL);
			END;
		END
		ELSE
		BEGIN
			IF OBJECT_ID('tempdb..#Histogram', N'U') IS NOT NULL DROP TABLE #Histogram;
			IF OBJECT_ID('tempdb..#Boundaries', N'U') IS NOT NULL DROP TABLE #Boundaries;

			CREATE TABLE #Histogram (RANGE_HI_KEY sql_variant,
				RANGE_ROWS bigint,
				EQ_ROWS bigint,
				DISTINCT_RANGE_ROWS bigint,
				AVG_RANGE_ROWS bigint);

			CREATE TABLE #Boundaries (SchemaName sysname,
				TableName sysname,
				ColumnName sysname,
				StatisticsName sysname,
				MinValue sql_variant,
				MaxValue sql_variant);

			DELETE Utility.dbo.StatisticsOutliers
				WHERE DatabaseName = @DatabaseName
				AND SchemaName = COALESCE(@SchemaName, SchemaName)
				AND TableName = COALESCE(@TableName, TableName)
				AND ColumnName = COALESCE(@ColumnName, ColumnName);

			DECLARE icur CURSOR LOCAL FOR
				SELECT SCHEMA_NAME(o.[schema_id]) AS SchemaName,
					OBJECT_NAME(s.[object_id]) AS TableName,
					C.[name] AS ColumnName,
					s.[name] AS StatisticsName,
					SP.last_updated,
					SP.modification_counter
					FROM sys.stats AS s
					CROSS APPLY sys.dm_db_stats_properties(s.[object_id], s.stats_id) AS SP
					JOIN sys.stats_columns AS sc
						ON s.stats_id = sc.stats_id
						AND s.[object_id] = sc.[object_id]
					JOIN sys.columns AS C
						ON C.[object_id] = SC.[object_id]
						AND C.column_id = SC.column_id
					JOIN sys.objects AS O
						ON s.[object_id] = O.[object_id]
					JOIN sys.partitions AS P
						ON s.[object_id] = P.[object_id]
						AND P.index_id IN (0, 1)
					LEFT OUTER JOIN sys.indexes AS I
						ON I.[object_id] = S.[object_id]
						AND I.[name] = S.[name]
					LEFT OUTER JOIN sys.index_columns AS IC
						ON I.[object_id] = IC.[object_id]
						AND I.index_id = IC.index_id
					WHERE P.rows > 200
					AND SCHEMA_NAME(o.[schema_id]) = COALESCE(@SchemaName, SCHEMA_NAME(o.[schema_id]))
					AND OBJECT_NAME(s.[object_id]) = COALESCE(@TableName, OBJECT_NAME(s.[object_id]))
					AND C.[name] = COALESCE(@ColumnName, C.[name])
					AND SC.column_id = COALESCE(IC.column_id, SC.column_id)
					AND COALESCE(IC.key_ordinal, 1) = 1
					AND SCHEMA_NAME(o.[schema_id]) NOT IN ('guest','INFORMATION_SCHEMA','sys')
					AND (I.[object_id] IS NULL
						OR (I.type_desc <> 'HEAP'
							AND I.type_desc NOT LIKE '%COLUMNSTORE%'))
					AND COALESCE(c.max_length, 0) <> -1 -- MAX data types aren't compatible with sql_variant
					AND sc.stats_column_id = 1 -- the histogram is only for the first column
					AND c.system_type_id NOT IN (240) -- hierarchyid data types aren't compatible with sql_variant
					ORDER BY SCHEMA_NAME(o.[schema_id]), OBJECT_NAME(s.[object_id]), C.[name];
			OPEN icur;
			FETCH NEXT FROM icur INTO @SchemaName, @TableName, @ColumnName, @StatisticsName, @StatisticsLastUpdateTimestamp, @ModificationCount;
			WHILE @@FETCH_STATUS = 0
			BEGIN
				DELETE #Histogram;
				DELETE #Boundaries;

				SET @SQL = 'DBCC SHOW_STATISTICS ([' + @SchemaName + '.' + @TableName + '], [' + @StatisticsName + ']) WITH NO_INFOMSGS, HISTOGRAM;';

				INSERT INTO #Histogram EXEC (@SQL);

				INSERT INTO #Boundaries
					(SchemaName,
					TableName,
					ColumnName,
					StatisticsName,
					MinValue,
					MaxValue)
				SELECT @SchemaName,
					@TableName,
					@ColumnName,
					@StatisticsName,
					MIN(H.RANGE_HI_KEY) AS MinValue,
					MAX(H.RANGE_HI_KEY) AS MaxValue
					FROM #Histogram AS H
					WHERE H.RANGE_HI_KEY IS NOT NULL;

				SET @SQL = '
				SELECT ''' + @DatabaseName + ''',
					''' + @SchemaName + ''',
					''' + @TableName + ''',
					''' + @ColumnName + ''',
					''' + @StatisticsName + ''',
					B.MinValue,
					B.MaxValue,
					SUM(CASE WHEN T.[' + @ColumnName + '] < B.MinValue THEN 1 ELSE 0 END) AS BelowCount,
					SUM(CASE WHEN T.[' + @ColumnName + '] > B.MaxValue THEN 1 ELSE 0 END) AS AboveCount,
					''' + CAST(@StatisticsLastUpdateTimestamp AS varchar(40)) + ''',
					' + CAST(@ModificationCount AS varchar(15)) + '
					FROM ' + @DatabaseName + '.[' + @SchemaName + '].[' + @TableName + '] AS T
					CROSS JOIN #Boundaries AS B
					GROUP BY B.MinValue, B.MaxValue
					HAVING SUM(CASE WHEN T.[' + @ColumnName + '] < B.MinValue THEN 1 ELSE 0 END) + SUM(CASE WHEN T.[' + @ColumnName + '] > B.MaxValue THEN 1 ELSE 0 END) > 0;';
				IF @DebugFlag = 1
				BEGIN
					PRINT @SQL;
				END
				ELSE
				BEGIN
					INSERT INTO Utility.dbo.StatisticsOutliers (DatabaseName,
						SchemaName,
						TableName,
						ColumnName,
						StatisticsName,
						MinStatsValue,
						MaxStatsValue,
						BelowCount,
						AboveCount,
						StatisticsLastUpdateTimestamp,
						ModificationCount)
					EXEC (@SQL);
				END;

				FETCH NEXT FROM icur INTO @SchemaName, @TableName, @ColumnName, @StatisticsName, @StatisticsLastUpdateTimestamp, @ModificationCount;
			END;
			DEALLOCATE icur;
		END; -- ELSE part of IF @DatabaseName <> DB_NAME()

		SET @Retry = 0;
	END TRY
	BEGIN CATCH
		IF XACT_STATE() <> 0 ROLLBACK;
		-- if a deadlock victim, reduce the @Retry variable
		IF ERROR_NUMBER() = 1205 AND @Retry > 1
		BEGIN;
			SET @Retry = @Retry - 1;

			IF CURSOR_STATUS('local','icur') > -2 DEALLOCATE icur;
		END
		ELSE
		BEGIN;
			THROW;
			RETURN 1;
		END;
	END CATCH;
END;

RETURN 0;
GO

EXEC sp_MS_Marksystemobject sp_FindStatisticsOutliers;
GO

GRANT EXECUTE ON OBJECT::dbo.sp_FindStatisticsOutliers TO PUBLIC;
GO