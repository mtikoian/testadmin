
------------------------------------ Begin Setup ------------------------------------

-- don't allow execution of entire script
SET NOEXEC ON;

/****

SET NOEXEC OFF;

****/

USE master;
GO

IF @@SERVERNAME <> 'SURFACEBOOK' SET NOEXEC ON;

IF EXISTS(SELECT * FROM sys.databases
		WHERE [name] = 'AdventureWorks2014')
BEGIN
	EXEC ('USE AdventureWorks2014;
		ALTER DATABASE AdventureWorks2014 SET SINGLE_USER WITH ROLLBACK IMMEDIATE;');
	USE master;
	DROP DATABASE AdventureWorks2014;
END;
GO

IF NOT EXISTS(SELECT * FROM sys.databases
		WHERE [name] = 'AdventureWorks2014')
BEGIN
	-- change source and destinations as necessary
	RESTORE DATABASE AdventureWorks2014
		FROM  DISK = N'C:\Downloads\AdventureWorks\AdventureWorks2014.bak'
		WITH  FILE = 1,
		MOVE N'AdventureWorks2014_Data' TO N'C:\MSSQL\Data\AdventureWorks2014_Data.mdf',
		MOVE N'AdventureWorks2014_Log' TO N'C:\\MSSQL\Log\AdventureWorks2014_Log.ldf',
		NOUNLOAD,  STATS = 10;

	ALTER DATABASE AdventureWorks2014 SET MULTI_USER;
END;
GO

IF NOT EXISTS(SELECT * FROM sys.databases AS D
		WHERE [name] = 'Utility')
BEGIN
	CREATE DATABASE Utility
		CONTAINMENT = NONE
		ON PRIMARY
		( NAME = N'Utility', FILENAME = N'C:\MSSQL2016\Data\Utility.mdf' , SIZE = 5000000KB , MAXSIZE = UNLIMITED, FILEGROWTH = 500000KB )
		LOG ON 
		( NAME = N'Utility_log', FILENAME = N'C:\MSSQL2016\Log\Utility_log.ldf' , SIZE = 5000000KB , MAXSIZE = UNLIMITED, FILEGROWTH = 500000KB)

	ALTER DATABASE Utility SET RECOVERY SIMPLE;
END;
GO -- 1 minute

USE Utility;
GO

-- create Utility.dbo.StatisticsOutliers table

SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
SET ANSI_PADDING ON;
SET NOCOUNT ON;
GO

IF OBJECT_ID('dbo.Numbers', N'U') IS NULL
BEGIN
	CREATE TABLE dbo.Numbers (Number int NOT NULL);

	WITH
		L0   AS(SELECT 1 AS c UNION ALL SELECT 1),
		L1   AS(SELECT 1 AS c FROM L0 AS A CROSS JOIN L0 AS B),
		L2   AS(SELECT 1 AS c FROM L1 AS A CROSS JOIN L1 AS B),
		L3   AS(SELECT 1 AS c FROM L2 AS A CROSS JOIN L2 AS B),
		L4   AS(SELECT 1 AS c FROM L3 AS A CROSS JOIN L3 AS B),
		L5   AS(SELECT 1 AS c FROM L4 AS A CROSS JOIN L4 AS B),
		Nums AS(SELECT ROW_NUMBER() OVER(ORDER BY (SELECT NULL)) AS n FROM L5)
	INSERT INTO dbo.Numbers (Number)
		SELECT n FROM Nums
		WHERE n <= 20000000;

	ALTER TABLE dbo.Numbers ADD  CONSTRAINT XPKNumbers PRIMARY KEY CLUSTERED
		( Number ASC );
END;
GO

USE AdventureWorks2014;
GO

-- this query creates statistics on ModifiedDate
SELECT COUNT(*) FROM Sales.SalesOrderDetail
	WHERE ModifiedDate = '2014-06-30';
GO

IF OBJECT_ID('dbo.Person', N'U') IS NOT NULL
BEGIN
	DROP TABLE dbo.Person;
END;
GO

CREATE TABLE dbo.Person (PersonID int IDENTITY NOT NULL,
	FirstName varchar(50) NOT NULL,
	LastName varchar(50) NOT NULL,
	BirthDate date NOT NULL,
	DeathDate date NULL,
	CONSTRAINT PK_dboPerson PRIMARY KEY (PersonID));
GO

-- insert ~ 700K rows
INSERT INTO dbo.Person (FirstName,
	LastName,
	BirthDate,
	DeathDate)
SELECT CASE N1.Number % 10
		WHEN 0 THEN 'John'
		WHEN 1 THEN 'Sally'
		WHEN 2 THEN 'Bob'
		WHEN 3 THEN 'Debby'
		WHEN 4 THEN 'George'
		WHEN 5 THEN 'Betty'
		WHEN 6 THEN 'Curt'
		WHEN 7 THEN 'Allison'
		WHEN 8 THEN 'Dan'
		WHEN 9 THEN 'Sara'
		END AS FirstName,
	CASE N2.Number % 10
		WHEN 0 THEN 'Jones'
		WHEN 1 THEN 'Smith'
		WHEN 2 THEN 'Peterson'
		WHEN 3 THEN 'Rupp'
		WHEN 4 THEN 'Mercier'
		WHEN 5 THEN 'Pond'
		WHEN 6 THEN 'Snyder'
		WHEN 7 THEN 'Kennedy'
		WHEN 8 THEN 'Einstein'
		WHEN 9 THEN 'Burger'
		END AS LastName,
	DATEADD(DAY, 2 * N3.Number, '1941-12-07') AS BirthDate,
	CASE N4.Number % 10
		WHEN 0 THEN DATEADD(DAY, N4.Number, DATEADD(DAY, N3.Number, '1941-12-07'))
		END AS DeathDate
	FROM Utility.dbo.Numbers AS N1
	CROSS JOIN Utility.dbo.Numbers AS N2
	CROSS JOIN Utility.dbo.Numbers AS N3
	CROSS JOIN Utility.dbo.Numbers AS N4
	WHERE N1.Number < 30
	AND N2.Number < 30
	AND N3.Number < 30
	AND N4.Number < 30;
GO

UPDATE STATISTICS dbo.Person WITH SAMPLE 50 PERCENT;
GO

-- START ZoomIt

-- Set background of Selected Text and Inactive Selected Text to 200:200:0

------------------------------------ End Setup ------------------------------------

/************************************************
Simple Query
************************************************/
USE AdventureWorks2014;
GO

-- show actual execution plan

SELECT P.FirstName, P.LastName
	FROM Person.Person AS P
	JOIN Person.PersonPhone AS PP
		ON P.BusinessEntityID = PP.BusinessEntityID
	WHERE PP.PhoneNumber LIKE '304%';
GO

/************************************************
DBCC SHOW_STATISTICS
************************************************/
USE AdventureWorks2014;
GO

-- turn off actual execution plan

-- show statistics in ObjectExplorer, then...

DBCC SHOW_STATISTICS ([Sales.SalesOrderDetail], PK_SalesOrderDetail_SalesOrderID_SalesOrderDetailID);
GO

DBCC SHOW_STATISTICS ([Sales.SalesOrderDetail], _WA_Sys_00000006_44CA3770);
GO

/************************************************
WITH HISTOGRAM
************************************************/
USE AdventureWorks2014;
GO

-- turn off actual execution plan

DBCC SHOW_STATISTICS ([Sales.SalesOrderDetail], PK_SalesOrderDetail_SalesOrderID_SalesOrderDetailID) WITH HISTOGRAM;
GO

/************************************************
sp_autostats
************************************************/
USE AdventureWorks2014;
GO

-- turn off actual execution plan

EXEC sp_autostats 'Sales.SalesOrderDetail';
GO

/************************************************
sys.stats
************************************************/
USE AdventureWorks2014;
GO

SELECT S.* FROM sys.stats AS S
	WHERE S.[object_id] = OBJECT_ID('Sales.SalesOrderDetail');
GO

/************************************************
sys.stats_columns
************************************************/
USE AdventureWorks2014;
GO

SELECT OBJECT_NAME(C.[object_id]), C.*
	FROM sys.stats_columns AS C
	WHERE C.[object_id] = OBJECT_ID('Sales.SalesOrderDetail');
GO

/************************************************
sys.dm_db_stats_properties
************************************************/
USE AdventureWorks2014;
GO

-- the second parameter is the stats_id, in this case the PK
SELECT * FROM sys.dm_db_stats_properties(OBJECT_ID('Sales.SalesOrderDetail'), 1);
GO

/************************************************
DBCC TRACEON 3604, 2363
************************************************/
USE AdventureWorks2014;
GO

-- turn off actual execution plan

DBCC FREEPROCCACHE;
DBCC TRACEON (3604);
DBCC TRACEON (2363);
GO

-- statistic object listed on 11th line
SELECT COUNT(*) FROM Sales.SalesOrderDetail WHERE ModifiedDate > '2014-01-01';
GO

DBCC TRACEOFF (3604);
DBCC TRACEOFF (2363);
GO

/************************************************
AUTO_CREATE_STATISTICS
************************************************/
USE AdventureWorks2014;
GO

-- show that the only "column" statistics are for the SpecialOfferID and ModifiedDate columns
SELECT OBJECT_NAME(S.[object_id]) AS TableName,
	C.[name] AS ColumnName
	FROM sys.stats AS S
	JOIN sys.stats_columns AS SC
		ON S.stats_id = SC.stats_id
		AND SC.[object_id] = OBJECT_ID('Sales.SalesOrderDetail')
	JOIN sys.columns AS C
		ON SC.column_id = C.column_id
		AND C.[object_id] = OBJECT_ID('Sales.SalesOrderDetail')
	WHERE S.[object_id] = OBJECT_ID('Sales.SalesOrderDetail')
	AND S.auto_created = 1;
GO

SELECT * FROM Sales.SalesOrderHeader AS H
	JOIN Sales.SalesOrderDetail AS D
		ON H.SalesOrderID = D.SalesOrderID
	WHERE D.OrderQty = 25;
GO

-- refresh ObjectExplorer
-- note that there are now statistics on the OrderQty column

-- show that now there are statistics on the OrderQty column
SELECT OBJECT_NAME(S.[object_id]) AS TableName,
	C.[name] AS ColumnName
	FROM sys.stats AS S
	JOIN sys.stats_columns AS SC
		ON S.stats_id = SC.stats_id
		AND SC.[object_id] = OBJECT_ID('Sales.SalesOrderDetail')
	JOIN sys.columns AS C
		ON SC.column_id = C.column_id
		AND C.[object_id] = OBJECT_ID('Sales.SalesOrderDetail')
	WHERE S.[object_id] = OBJECT_ID('Sales.SalesOrderDetail')
	AND S.auto_created = 1;
GO

DBCC SHOW_STATISTICS ([Sales.SalesOrderDetail], _WA_Sys_00000004_44CA3770) WITH HISTOGRAM;
GO

/************************************************
UPDATE STATISTICS
************************************************/
USE AdventureWorks2014;
GO

-- notice Updated (timestamp) and Rows Sampled
DBCC SHOW_STATISTICS ([Sales.SalesOrderDetail], [_WA_Sys_0000000B_44CA3770])
GO

UPDATE STATISTICS Sales.SalesOrderDetail [_WA_Sys_0000000B_44CA3770] WITH FULLSCAN;
GO

DBCC SHOW_STATISTICS ([Sales.SalesOrderDetail], [_WA_Sys_0000000B_44CA3770])
GO

/************************************************
What Can Go Wrong? Bad Sample
************************************************/
USE AdventureWorks2014;
GO

-- bad statistics on Sales.SalesOrderDetail.OrderQty!!
DBCC SHOW_STATISTICS ([Sales.SalesOrderDetail], _WA_Sys_00000004_44CA3770) WITH HISTOGRAM;
GO

-- show that the histogram blip is inaccurate
SELECT SOD.OrderQty, COUNT(*)
	FROM Sales.SalesOrderDetail AS SOD
	WHERE SOD.OrderQty BETWEEN 23 AND 27
	GROUP BY SOD.OrderQty
	ORDER BY SOD.OrderQty;
GO

--Include Actual Execution Plan
SET STATISTICS IO ON;
GO

-- Notice Actual Execution Plan and IO
SELECT * FROM Sales.SalesOrderHeader AS H
	JOIN Sales.SalesOrderDetail AS D
		ON H.SalesOrderID = D.SalesOrderID
	WHERE D.OrderQty = 25
	OPTION (RECOMPILE);
GO

-- update stats with FULLSCAN, then try again
UPDATE STATISTICS Sales.SalesOrderDetail([_WA_Sys_00000004_44CA3770]) WITH FULLSCAN;
GO

DBCC SHOW_STATISTICS ([Sales.SalesOrderDetail], _WA_Sys_00000004_44CA3770) WITH HISTOGRAM;
GO

 -- execute same query again, Include Actual Execution Plan
 -- compare execution plans and logical reads - 1863 vs. 1297 - ~30% IO improvement
SELECT * FROM Sales.SalesOrderHeader AS H
	JOIN Sales.SalesOrderDetail AS D
		ON H.SalesOrderID = D.SalesOrderID
	WHERE D.OrderQty = 25
	OPTION (RECOMPILE);
GO

/************************************************
What Can Go Wrong? Ascending Keys
************************************************/
USE AdventureWorks2014;
GO

SET STATISTICS IO OFF;
GO

-- note the highest RANGE_HIGH_KEY for ModifiedDate
DBCC SHOW_STATISTICS([Sales.SalesOrderDetail], [_WA_Sys_0000000B_44CA3770]) WITH HISTOGRAM;
GO

INSERT INTO Sales.SalesOrderHeader (
	RevisionNumber, OrderDate, DueDate, ShipDate, Status, OnlineOrderFlag, PurchaseOrderNumber, AccountNumber, CustomerID, SalesPersonID, TerritoryID, BillToAddressID, ShipToAddressID, ShipMethodID, CreditCardID, CreditCardApprovalCode, CurrencyRateID, SubTotal, TaxAmt, Freight, Comment)
SELECT TOP 2000 RevisionNumber,
	DATEADD(YEAR, 4, OrderDate),
	DATEADD(YEAR, 4, DueDate),
	DATEADD(YEAR, 4, ShipDate),
	Status, OnlineOrderFlag,
	PurchaseOrderNumber,
	AccountNumber, CustomerID, SalesPersonID, TerritoryID,
	BillToAddressID, ShipToAddressID, ShipMethodID, CreditCardID,
	CreditCardApprovalCode, CurrencyRateID, SubTotal, TaxAmt, Freight, Comment
	FROM Sales.SalesOrderHeader;
GO

INSERT INTO Sales.SalesOrderDetail (
	SalesOrderID, CarrierTrackingNumber, OrderQty, ProductID, SpecialOfferID, UnitPrice, UnitPriceDiscount)
SELECT H.SalesOrderID, N'4911-403C-98', 2, 776, 1, 23.45, 0
	FROM Sales.SalesOrderHeader AS H
	WHERE H.ShipDate > '2015-01-01';
GO 2

-- note the highest RANGE_HIGH_KEY for ModifiedDate
DBCC SHOW_STATISTICS([Sales.SalesOrderDetail], [_WA_Sys_0000000B_44CA3770]) WITH HISTOGRAM;
GO

-- also note that last time the statistics were updated
-- 5 is the stats_id for the statistics on the ShipDate column
SELECT * FROM sys.dm_db_stats_properties(OBJECT_ID('Sales.SalesOrderDetail'), 5);
GO

SELECT COUNT(*) FROM Sales.SalesOrderDetail
	WHERE ModifiedDate > '2014-06-30 00:00:00.000';
GO

ALTER DATABASE AdventureWorks2014
	SET COMPATIBILITY_LEVEL = 110; -- 2012 compatibility
GO

-- look at estimated vs. actual from SalesOrderDetail
SELECT H.DueDate, COUNT(*)
	FROM Sales.SalesOrderHeader AS H
	JOIN Sales.SalesOrderDetail AS D
		ON H.SalesOrderID = D.SalesOrderID
	WHERE D.ModifiedDate > '2016-01-01'
	GROUP BY H.DueDate
	OPTION (RECOMPILE);
GO

ALTER DATABASE AdventureWorks2014
	SET COMPATIBILITY_LEVEL = 120; -- 2014 compatibility
GO

-- look at estimated vs. actual from SalesOrderDetail
SELECT H.DueDate, COUNT(*)
	FROM Sales.SalesOrderHeader AS H
	JOIN Sales.SalesOrderDetail AS D
		ON H.SalesOrderID = D.SalesOrderID
	WHERE D.ModifiedDate > '2016-01-01'
	GROUP BY H.DueDate
	OPTION (RECOMPILE);
GO

UPDATE STATISTICS Sales.SalesOrderDetail WITH FULLSCAN;
GO

-- note the highest RANGE_HIGH_KEY for ModifiedDate
DBCC SHOW_STATISTICS([Sales.SalesOrderDetail], [_WA_Sys_0000000B_44CA3770]) WITH HISTOGRAM;
GO

ALTER DATABASE AdventureWorks2014
	SET COMPATIBILITY_LEVEL = 110; -- 2012 compatibility
GO

-- look at estimated vs. actual from SalesOrderDetail
SELECT H.DueDate, COUNT(*)
	FROM Sales.SalesOrderHeader AS H
	JOIN Sales.SalesOrderDetail AS D
		ON H.SalesOrderID = D.SalesOrderID
	WHERE D.ModifiedDate > '2016-01-01'
	GROUP BY H.DueDate
	OPTION (RECOMPILE);
GO

ALTER DATABASE AdventureWorks2014
	SET COMPATIBILITY_LEVEL = 120; -- 2014 compatibility
GO

-- look at estimated vs. actual from SalesOrderDetail
SELECT H.DueDate, COUNT(*)
	FROM Sales.SalesOrderHeader AS H
	JOIN Sales.SalesOrderDetail AS D
		ON H.SalesOrderID = D.SalesOrderID
	WHERE D.ModifiedDate > '2016-01-01'
	GROUP BY H.DueDate
	OPTION (RECOMPILE);
GO

/************************************************
sp_FindStatisticsOutliers
************************************************/
USE AdventureWorks2014;
GO

-- turn off Actual Execution Plan
SET STATISTICS IO OFF;
GO

EXEC sp_FindStatisticsOutliers;
GO

EXEC sp_FindStatisticsOutliers
	@DatabaseName = 'AdventureWorks2014';
GO

SELECT DO.SchemaName + '.' + DO.TableName + '.' + DO.ColumnName AS Col,
	DO.BelowCount,
	DO.AboveCount,
	DO.*
	FROM Utility.dbo.StatisticsOutliers AS DO
	ORDER BY DO.BelowCount + DO.AboveCount DESC;
GO

------------------------------------ Begin Cleanup ------------------------------------

USE AdventureWorks2014;
GO

IF OBJECT_ID('dbo.Person', N'U') IS NOT NULL
BEGIN
	DROP TABLE dbo.Person;
END;
GO

------------------------------------ End Cleanup ------------------------------------

