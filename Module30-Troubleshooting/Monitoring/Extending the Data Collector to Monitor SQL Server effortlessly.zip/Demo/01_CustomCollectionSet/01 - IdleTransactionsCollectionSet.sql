BEGIN TRANSACTION

BEGIN TRY
	DECLARE @collection_set_id_1 INT
	DECLARE @collection_set_uid_2 UNIQUEIDENTIFIER

	EXEC [msdb].[dbo].[sp_syscollector_create_collection_set] @name = N'Transactions info'
		,@collection_mode = 0
		,@description = N'Collects data about transactions'
		,@logging_level = 0
		,@days_until_expiration = 30
		,@schedule_name = N'CollectorSchedule_Every_15min'
		,@collection_set_id = @collection_set_id_1 OUTPUT
		,@collection_set_uid = @collection_set_uid_2 OUTPUT

	SELECT @collection_set_id_1
		,@collection_set_uid_2

	DECLARE @collector_type_uid_3 UNIQUEIDENTIFIER

	SELECT @collector_type_uid_3 = collector_type_uid
	FROM [msdb].[dbo].[syscollector_collector_types]
	WHERE NAME = N'Generic T-SQL Query Collector Type';

	DECLARE @collection_item_id_4 INT

	EXEC [msdb].[dbo].[sp_syscollector_create_collection_item] @name = N'Idle_Transactions'
		,@parameters = 
		N'<ns:TSQLQueryCollector xmlns:ns="DataCollectorType"><Query><Value>
			SELECT 
				CAST(SERVERPROPERTY(''ServerName'') AS sysname) AS ServerName
				,s.session_id
				,s.status
				,s.login_time
				,s.host_name
				,s.program_name
				,s.host_process_id
				,s.original_login_name
				,s.last_request_end_time
				,CAST(t.text AS nvarchar(4000)) AS [text]
				,CAST(s.context_info AS varchar(128)) AS [context_info]
			FROM sys.dm_exec_sessions AS s
			INNER JOIN sys.dm_exec_connections AS c
				ON s.session_id = c.session_id
			CROSS APPLY (
				SELECT MAX(DB_NAME(dt.database_id)) AS database_name
				FROM sys.dm_tran_session_transactions AS st
				INNER JOIN sys.dm_tran_database_transactions AS dt
						ON st.transaction_id = dt.transaction_id
				WHERE is_user_transaction = 1
				GROUP BY st.session_id
				HAVING s.session_id = st.session_id      
			) AS trans
			CROSS APPLY sys.dm_exec_sql_text(most_recent_sql_handle) AS t
			WHERE s.session_id NOT IN (
						SELECT session_id
						FROM sys.dm_exec_requests
				)
				AND s.session_id IN (
						SELECT request_session_id
						FROM sys.dm_tran_locks
						WHERE request_status = ''GRANT''
				)
				AND STATUS = ''sleeping''
				AND is_user_process = 1
				AND program_name NOT LIKE ''%SQLAgent - Job Manager%''
			</Value><OutputTable>IdleTransactions</OutputTable></Query><Databases><Database>master</Database></Databases></ns:TSQLQueryCollector>'
		,@collection_item_id = @collection_item_id_4 OUTPUT
		,@frequency = 60
		,@collection_set_id = @collection_set_id_1
		,@collector_type_uid = @collector_type_uid_3

	SELECT @collection_item_id_4

	COMMIT TRANSACTION;
END TRY

BEGIN CATCH
	ROLLBACK TRANSACTION;

	DECLARE @ErrorMessage NVARCHAR(4000);
	DECLARE @ErrorSeverity INT;
	DECLARE @ErrorState INT;
	DECLARE @ErrorNumber INT;
	DECLARE @ErrorLine INT;
	DECLARE @ErrorProcedure NVARCHAR(200);

	SELECT @ErrorLine = ERROR_LINE()
		,@ErrorSeverity = ERROR_SEVERITY()
		,@ErrorState = ERROR_STATE()
		,@ErrorNumber = ERROR_NUMBER()
		,@ErrorMessage = ERROR_MESSAGE()
		,@ErrorProcedure = ISNULL(ERROR_PROCEDURE(), '-');

	RAISERROR (
			14684
			,@ErrorSeverity
			,1
			,@ErrorNumber
			,@ErrorSeverity
			,@ErrorState
			,@ErrorProcedure
			,@ErrorLine
			,@ErrorMessage
			);
END CATCH;
GO


