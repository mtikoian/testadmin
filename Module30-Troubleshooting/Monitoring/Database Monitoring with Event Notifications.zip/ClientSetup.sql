/* Phil Brammer - This script is under free use.  No restrictions.  Feedback appreciated. */

CREATE DATABASE [Client]
GO

USE [Client]
GO

CREATE QUEUE [dbo].[NotificationsQueue] 
WITH STATUS = ON , 
RETENTION = OFF
GO

CREATE SERVICE [NotificationsService]  
AUTHORIZATION [dbo]  
ON QUEUE [dbo].[NotificationsQueue] ([http://schemas.microsoft.com/SQL/Notifications/PostEventNotification])
GO

CREATE ROUTE [NotificationsRoute]   
AUTHORIZATION [dbo]   
WITH SERVICE_NAME  = N'NotificationsService' ,  
     ADDRESS  = N'LOCAL' 
GO



CREATE EVENT NOTIFICATION NotificationEvent
ON SERVER 
FOR BLOCKED_PROCESS_REPORT, DEADLOCK_GRAPH, DDL_TABLE_EVENTS  
TO SERVICE 'NotificationsService',
           'current database';
GO

/* Test it out */
CREATE TABLE dbo.SQLSaturday91 (col1 INT);

SELECT *
  FROM dbo.NotificationsQueue
  
DROP TABLE dbo.SQLSaturday91;  

/* Set it up to push data to repository */

/* Set it up to push data to repository */

CREATE TABLE [dbo].[AuditErrors](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[ErrorProcedure] [nvarchar](128) NULL,
	[ErrorLine] [int] NULL,
	[ErrorNumber] [int] NULL,
	[ErrorMessage] [nvarchar](max) NULL,
	[ErrorSeverity] [int] NULL,
	[ErrorState] [int] NULL,
	[AuditedData] [xml] NULL,
	[ErrorDate] [datetime] NULL,
 CONSTRAINT [PKAuditErrors] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON, FILLFACTOR = 80) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[AuditErrors] ADD  CONSTRAINT [DFErrorDateGetUTCDate]  DEFAULT (getutcdate()) FOR [ErrorDate]
GO


CREATE TABLE [dbo].[SessionConversations](
	[SPID] [int] NOT NULL,
	[FromService] [sysname] NOT NULL,
	[ToService] [sysname] NOT NULL,
	[OnContract] [sysname] NOT NULL,
	[Handle] [uniqueidentifier] NOT NULL,
	[CreateTime] [datetime] NOT NULL,
 CONSTRAINT [PK_SessionConversations] PRIMARY KEY CLUSTERED 
(
	[SPID] ASC,
	[FromService] ASC,
	[ToService] ASC,
	[OnContract] ASC,
	[Handle] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
	[Handle] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[SessionConversations] ADD  DEFAULT (getdate()) FOR [CreateTime]
GO



CREATE PROCEDURE [dbo].[prcSendAuditData]
(
        @AuditedData XML
)
AS
BEGIN
   
        BEGIN TRY
                BEGIN TRANSACTION
                DECLARE @dlgId              UNIQUEIDENTIFIER,
                        @ServiceName        NVARCHAR(500),
                        @BeginDialog        NVARCHAR(1500),
                        @errorId            BIGINT,
                        @dbName             NVARCHAR(128),
                        --@ParmDefinition     NVARCHAR(128),
                        @ErrorMessage       VARCHAR(4000),
                        @ErrorNumber        INT,
                        @ErrorSeverity      INT,
                        @ErrorState         INT,
                        @ErrorLine          INT,
                        @Setting            INT 
                        
                --SET @ParmDefinition = '@dlgId UNIQUEIDENTIFIER OUTPUT'

                SET @Setting = 300;  -- seconds

                SET @ServiceName = '';
                SELECT @ServiceName = [name]
                  FROM [sys].[services]
                 WHERE [name] LIKE '%AuditDataSender';

                -- Check if our database already has a dialog id that was previously used
                -- if it does reuse the conversation
                SELECT @dlgId = Handle
                  FROM dbo.[SessionConversations] WITH (UPDLOCK)
                 WHERE SPID = @@SPID
                   AND FromService = @ServiceName
                   AND ToService = 'AuditDataWriter'
                   AND OnContract = 'AuditDataContract'
                   AND CreateTime < DATEADD(SECOND, 275, GETDATE());  /* Don't reuse a conversation if we are within 15 seconds of it expiring */

                IF @dlgId IS NULL
                BEGIN
                        -- Need to start a new conversation for the current @@spid
                        BEGIN DIALOG CONVERSATION @dlgId
                                FROM SERVICE @ServiceName
                                TO SERVICE 'AuditDataWriter'
                                ON CONTRACT [AuditDataContract]
                                WITH ENCRYPTION = OFF;
                                
                        -- Set an one hour timer on the conversation
                        BEGIN CONVERSATION TIMER (@dlgId) TIMEOUT = @Setting; -- seconds
                        
                        -- Insert data into the SessionConversations table for reuse
                        INSERT INTO [SessionConversations]
                                (SPID, FromService, ToService, OnContract, Handle)
                                VALUES
                                (@@SPID, @ServiceName, 'AuditDataWriter', 'AuditDataContract', @dlgId);
                END;

                -- Send our data to be audited
                ;SEND ON CONVERSATION @dlgId    
                MESSAGE TYPE [AuditData] (@AuditedData)

                IF @@TRANCOUNT > 0
                    COMMIT TRANSACTION;
        END TRY
        BEGIN CATCH             
                SET @ErrorLine      = ERROR_LINE();
                SET @ErrorNumber    = ERROR_NUMBER();
                SET @ErrorMessage   = ERROR_MESSAGE();
                SET @ErrorSeverity  = ERROR_SEVERITY();
                SET @ErrorState     = ERROR_STATE();
            
                IF @@TRANCOUNT > 0
                    ROLLBACK;

                INSERT INTO [AuditErrors] ( [ErrorProcedure], [ErrorLine], [ErrorNumber], [ErrorMessage], [ErrorSeverity], [ErrorState], [AuditedData])
                    VALUES ('prcSendAuditData', 50, -1, @ServiceName, @Setting, -1, @AuditedData);

                INSERT INTO [AuditErrors] ([ErrorProcedure], [ErrorLine], [ErrorNumber], [ErrorMessage], [ErrorSeverity], [ErrorState], [AuditedData])
                    VALUES ('prcSendAuditData', @ErrorLine, @ErrorNumber, @ErrorMessage, @ErrorSeverity, @ErrorState, @AuditedData);
        END CATCH;
END;


GO

CREATE PROCEDURE [dbo].[prcProcessNotification] 
AS
    DECLARE @msgBody XML    
    DECLARE @dlgId UNIQUEIDENTIFIER
    DECLARE @messageTypeName sysname

    WHILE(1=1)
    BEGIN
        BEGIN TRY        
            -- receive messages from the queue one by one            
            ;RECEIVE TOP(1) 
                    @msgBody    = message_body,
                    @dlgId        = conversation_handle,
                    @messageTypeName = message_type_name
            FROM    dbo.NotificationsQueue
            
            -- exit when the whole queue has been processed
            IF @@ROWCOUNT = 0
            BEGIN
                IF @@TRANCOUNT > 0
                BEGIN 
                    ROLLBACK;
                END  
                BREAK; -- out of loop
            END 
            IF @messageTypeName = N'http://schemas.microsoft.com/SQL/ServiceBroker/EndDialog'
            BEGIN
		        END CONVERSATION @dlgId
            END
            IF @messageTypeName = N'http://schemas.microsoft.com/SQL/Notifications/EventNotification'
            BEGIN
		/* Send to remote server */
		EXEC dbo.prcSendAuditData @msgBody
		/* end send */          
	    END
            
        END TRY
        BEGIN CATCH
            INSERT INTO AuditErrors (
                            ErrorProcedure, ErrorLine, ErrorNumber, ErrorMessage, 
                            ErrorSeverity, ErrorState, AuditedData)
            SELECT      'prcProcessNotification', ERROR_LINE(), ERROR_NUMBER(), ERROR_MESSAGE(), 
                            ERROR_SEVERITY(), ERROR_STATE(), @msgBody
            BREAK; -- out of loop
        END CATCH;
    END

GO


CREATE PROCEDURE [dbo].[prcProcessSenderAuditQueue]
AS
BEGIN
        DECLARE @handle UNIQUEIDENTIFIER;
        DECLARE @messageTypeName SYSNAME;
        DECLARE @messageBody VARBINARY(MAX);
        BEGIN TRANSACTION;
        RECEIVE TOP(1)
                @handle = conversation_handle,
                @messageTypeName = message_type_name,
                @messageBody = message_body
                FROM [SenderAuditQueue];
        IF @handle IS NOT NULL
        BEGIN
                -- Delete the message from the [SessionConversations] table
                -- before sending the [EndOfTimer] message. The order is
                -- important to avoid deadlocks. Strictly speaking, we should
                -- only delete if the message type is timer or error, but is
                -- simpler and safer to just delete always
                --
                DELETE FROM [SessionConversations]
                        WHERE [Handle] = @handle;
                IF @messageTypeName = N'http://schemas.microsoft.com/SQL/ServiceBroker/DialogTimer'
                BEGIN
                        SEND ON CONVERSATION @handle 
                                MESSAGE TYPE [EndOfTimer];
                END
                ELSE IF @messageTypeName = N'http://schemas.microsoft.com/SQL/ServiceBroker/EndDialog'
                BEGIN
                        END CONVERSATION @handle;
                END
                ELSE IF @messageTypeName = N'http://schemas.microsoft.com/SQL/ServiceBroker/Error'
                BEGIN
                        END CONVERSATION @handle;
                        -- Insert your error handling here. Could send a notification or
                        -- store the error in a table for further inspection
                        -- We�re gonna log the error into the ERRORLOG and Eventvwr.exe
                        --
                        DECLARE @error INT;
                        DECLARE @description NVARCHAR(4000);
                        WITH XMLNAMESPACES ('http://schemas.microsoft.com/SQL/ServiceBroker/Error' AS ssb)
                        SELECT
                                @error = CAST(@messageBody AS XML).value(
                                        '(//ssb:Error/ssb:Code)[1]', 'INT'),
                                @description = CAST(@messageBody AS XML).value(
                                        '(//ssb:Error/ssb:Description)[1]', 'NVARCHAR(4000)')
                        RAISERROR(N'Received error Code:%i Description:"%s"',
                                 16, 1, @error, @description) WITH LOG;
                END;
        END
        COMMIT;
END


GO

CREATE MESSAGE TYPE [AuditData] AUTHORIZATION [dbo] VALIDATION = NONE
GO
CREATE MESSAGE TYPE [EndOfTimer] AUTHORIZATION [dbo] VALIDATION = NONE
GO
CREATE CONTRACT [AuditDataContract] AUTHORIZATION [dbo] ([AuditData] SENT BY INITIATOR,
[EndOfTimer] SENT BY INITIATOR)
GO

CREATE QUEUE [dbo].[SenderAuditQueue] 
WITH STATUS = ON , 
    RETENTION = OFF , 
    ACTIVATION (  STATUS = ON , 
                  PROCEDURE_NAME = [dbo].[prcProcessSenderAuditQueue] , 
                  MAX_QUEUE_READERS = 1 , 
                  EXECUTE AS OWNER  ) ON [PRIMARY] 
GO

/* Service name below contains the IP address of the client */
CREATE SERVICE [tcp://172.16.104.135:10050/AuditDataSender]  AUTHORIZATION [dbo]  ON QUEUE [dbo].[SenderAuditQueue] 
GO

GRANT SEND ON SERVICE::[tcp://172.16.104.135:10050/AuditDataSender] TO [public] AS [dbo]
GO

/* Route below has the IP address of the repository */
CREATE ROUTE [AuditDataSender]   AUTHORIZATION [dbo]   WITH  SERVICE_NAME  = N'AuditDataWriter' ,  ADDRESS  = N'tcp://172.16.104.136:10050' 
GO

USE [master]
GO

CREATE ENDPOINT [AuditEndPoint]
  AUTHORIZATION [WIN-TOJ19KPPCTB\Phil Brammer]
  STATE=STARTED
  AS TCP (LISTENER_PORT=10050, LISTENER_IP=ALL)
  FOR SERVICE_BROKER (MESSAGE_FORWARDING = DISABLED,
                      MESSAGE_FORWARD_SIZE = 10,
                      AUTHENTICATION = WINDOWS NTLM,
                      ENCRYPTION = REQUIRED ALGORITHM RC4)
GO


GRANT CONNECT ON ENDPOINT::AuditEndPoint TO PUBLIC;

USE Client
GO

ALTER QUEUE [dbo].[NotificationsQueue] 
WITH STATUS = ON , 
     RETENTION = OFF , 
     ACTIVATION (  STATUS = ON , 
                   PROCEDURE_NAME = [dbo].[prcProcessNotification] , 
                   MAX_QUEUE_READERS = 50 , 
                   EXECUTE AS N'dbo'  )

