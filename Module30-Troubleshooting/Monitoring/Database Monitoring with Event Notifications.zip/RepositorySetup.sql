CREATE DATABASE Repository
GO

USE Repository
GO

/* Create Tables */
CREATE USER [AuditOwner] WITHOUT LOGIN WITH DEFAULT_SCHEMA=[Audit]
GO

CREATE SCHEMA [Audit] AUTHORIZATION [AuditOwner]
GO

CREATE PARTITION FUNCTION [upfAuditData](nvarchar(128)) AS RANGE LEFT FOR VALUES (N'ADD_ROLE_MEMBER', N'ADD_SERVER_ROLE_MEMBER', N'ADD_SIGNATURE', N'ADD_SIGNATURE_SCHEMA_OBJECT', N'ALTER_APPLICATION_ROLE', N'ALTER_ASSEMBLY', N'ALTER_ASYMMETRIC_KEY', N'ALTER_AUTHORIZATION_DATABASE', N'ALTER_AUTHORIZATION_SERVER', N'ALTER_BROKER_PRIORITY', N'ALTER_CERTIFICATE', N'ALTER_CREDENTIAL', N'ALTER_CRYPTOGRAPHIC_PROVIDER', N'ALTER_DATABASE', N'ALTER_DATABASE_AUDIT_SPECIFICATION', N'ALTER_DATABASE_ENCRYPTION_KEY', N'ALTER_ENDPOINT', N'ALTER_EVENT_SESSION', N'ALTER_EXTENDED_PROPERTY', N'ALTER_FULLTEXT_CATALOG', N'ALTER_FULLTEXT_INDEX', N'ALTER_FULLTEXT_STOPLIST', N'ALTER_FUNCTION', N'ALTER_INDEX', N'ALTER_INSTANCE', N'ALTER_LINKED_SERVER', N'ALTER_LOGIN', N'ALTER_MASTER_KEY', N'ALTER_MESSAGE', N'ALTER_MESSAGE_TYPE', N'ALTER_PARTITION_FUNCTION', N'ALTER_PARTITION_SCHEME', N'ALTER_PLAN_GUIDE', N'ALTER_PROCEDURE', N'ALTER_QUEUE', N'ALTER_REMOTE_SERVER', N'ALTER_REMOTE_SERVICE_BINDING', N'ALTER_RESOURCE_GOVERNOR_CONFIG', N'ALTER_RESOURCE_POOL', N'ALTER_ROLE', N'ALTER_ROUTE', N'ALTER_SCHEMA', N'ALTER_SERVER_AUDIT', N'ALTER_SERVER_AUDIT_SPECIFICATION', N'ALTER_SERVICE', N'ALTER_SERVICE_MASTER_KEY', N'ALTER_SYMMETRIC_KEY', N'ALTER_TABLE', N'ALTER_TRIGGER', N'ALTER_USER', N'ALTER_VIEW', N'ALTER_WORKLOAD_GROUP', N'ALTER_XML_SCHEMA_COLLECTION', N'ASSEMBLY_LOAD', N'AUDIT_ADD_DB_USER_EVENT', N'AUDIT_ADD_LOGIN_TO_SERVER_ROLE_EVENT', N'AUDIT_ADD_MEMBER_TO_DB_ROLE_EVENT', N'AUDIT_ADD_ROLE_EVENT', N'AUDIT_ADDLOGIN_EVENT', N'AUDIT_APP_ROLE_CHANGE_PASSWORD_EVENT', N'AUDIT_BACKUP_RESTORE_EVENT', N'AUDIT_CHANGE_AUDIT_EVENT', N'AUDIT_CHANGE_DATABASE_OWNER', N'AUDIT_DATABASE_MANAGEMENT_EVENT', N'AUDIT_DATABASE_OBJECT_ACCESS_EVENT', N'AUDIT_DATABASE_OBJECT_GDR_EVENT', N'AUDIT_DATABASE_OBJECT_MANAGEMENT_EVENT', N'AUDIT_DATABASE_OBJECT_TAKE_OWNERSHIP_EVENT', N'AUDIT_DATABASE_OPERATION_EVENT', N'AUDIT_DATABASE_PRINCIPAL_IMPERSONATION_EVENT', N'AUDIT_DATABASE_PRINCIPAL_MANAGEMENT_EVENT', N'AUDIT_DATABASE_SCOPE_GDR_EVENT', N'AUDIT_DBCC_EVENT', N'AUDIT_FULLTEXT', N'AUDIT_LOGIN', N'AUDIT_LOGIN_CHANGE_PASSWORD_EVENT', N'AUDIT_LOGIN_CHANGE_PROPERTY_EVENT', N'AUDIT_LOGIN_FAILED', N'AUDIT_LOGIN_GDR_EVENT', N'AUDIT_LOGOUT', N'AUDIT_SCHEMA_OBJECT_ACCESS_EVENT', N'AUDIT_SCHEMA_OBJECT_GDR_EVENT', N'AUDIT_SCHEMA_OBJECT_MANAGEMENT_EVENT', N'AUDIT_SCHEMA_OBJECT_TAKE_OWNERSHIP_EVENT', N'AUDIT_SERVER_ALTER_TRACE_EVENT', N'AUDIT_SERVER_OBJECT_GDR_EVENT', N'AUDIT_SERVER_OBJECT_MANAGEMENT_EVENT', N'AUDIT_SERVER_OBJECT_TAKE_OWNERSHIP_EVENT', N'AUDIT_SERVER_OPERATION_EVENT', N'AUDIT_SERVER_PRINCIPAL_IMPERSONATION_EVENT', N'AUDIT_SERVER_PRINCIPAL_MANAGEMENT_EVENT', N'AUDIT_SERVER_SCOPE_GDR_EVENT', N'BIND_DEFAULT', N'BIND_RULE', N'BITMAP_WARNING', N'BLOCKED_PROCESS_REPORT', N'BROKER_QUEUE_DISABLED', N'CPU_THRESHOLD_EXCEEDED', N'CREATE_APPLICATION_ROLE', N'CREATE_ASSEMBLY', N'CREATE_ASYMMETRIC_KEY', N'CREATE_BROKER_PRIORITY', N'CREATE_CERTIFICATE', N'CREATE_CONTRACT', N'CREATE_CREDENTIAL', N'CREATE_CRYPTOGRAPHIC_PROVIDER', N'CREATE_DATABASE', N'CREATE_DATABASE_AUDIT_SPECIFICATION', N'CREATE_DATABASE_ENCRYPTION_KEY', N'CREATE_DEFAULT', N'CREATE_ENDPOINT', N'CREATE_EVENT_NOTIFICATION', N'CREATE_EVENT_SESSION', N'CREATE_EXTENDED_PROCEDURE', N'CREATE_EXTENDED_PROPERTY', N'CREATE_FULLTEXT_CATALOG', N'CREATE_FULLTEXT_INDEX', N'CREATE_FULLTEXT_STOPLIST', N'CREATE_FUNCTION', N'CREATE_INDEX', N'CREATE_LINKED_SERVER', N'CREATE_LINKED_SERVER_LOGIN', N'CREATE_LOGIN', N'CREATE_MASTER_KEY', N'CREATE_MESSAGE', N'CREATE_MESSAGE_TYPE', N'CREATE_PARTITION_FUNCTION', N'CREATE_PARTITION_SCHEME', N'CREATE_PLAN_GUIDE', N'CREATE_PROCEDURE', N'CREATE_QUEUE', N'CREATE_REMOTE_SERVER', N'CREATE_REMOTE_SERVICE_BINDING', N'CREATE_RESOURCE_POOL', N'CREATE_ROLE', N'CREATE_ROUTE', N'CREATE_RULE', N'CREATE_SCHEMA', N'CREATE_SERVER_AUDIT', N'CREATE_SERVER_AUDIT_SPECIFICATION', N'CREATE_SERVICE', N'CREATE_SPATIAL_INDEX', N'CREATE_STATISTICS', N'CREATE_SYMMETRIC_KEY', N'CREATE_SYNONYM', N'CREATE_TABLE', N'CREATE_TRIGGER', N'CREATE_TYPE', N'CREATE_USER', N'CREATE_VIEW', N'CREATE_WORKLOAD_GROUP', N'CREATE_XML_INDEX', N'CREATE_XML_SCHEMA_COLLECTION', N'DATA_FILE_AUTO_GROW', N'DATA_FILE_AUTO_SHRINK', N'DATABASE_MIRRORING_STATE_CHANGE', N'DATABASE_SUSPECT_DATA_PAGE', N'DDL_APPLICATION_ROLE_EVENTS', N'DDL_ASSEMBLY_EVENTS', N'DDL_ASYMMETRIC_KEY_EVENTS', N'DDL_AUTHORIZATION_DATABASE_EVENTS', N'DDL_AUTHORIZATION_SERVER_EVENTS', N'DDL_BROKER_PRIORITY_EVENTS', N'DDL_CERTIFICATE_EVENTS', N'DDL_CONTRACT_EVENTS', N'DDL_CREDENTIAL_EVENTS', N'DDL_CRYPTO_SIGNATURE_EVENTS', N'DDL_CRYPTOGRAPHIC_PROVIDER_EVENTS', N'DDL_DATABASE_AUDIT_SPECIFICATION_EVENTS', N'DDL_DATABASE_ENCRYPTION_KEY_EVENTS', N'DDL_DATABASE_EVENTS', N'DDL_DATABASE_LEVEL_EVENTS', N'DDL_DATABASE_SECURITY_EVENTS', N'DDL_DEFAULT_EVENTS', N'DDL_ENDPOINT_EVENTS', N'DDL_EVENT_NOTIFICATION_EVENTS', N'DDL_EVENT_SESSION_EVENTS', N'DDL_EVENTS', N'DDL_EXTENDED_PROCEDURE_EVENTS', N'DDL_EXTENDED_PROPERTY_EVENTS', N'DDL_FULLTEXT_CATALOG_EVENTS', N'DDL_FULLTEXT_STOPLIST_EVENTS', N'DDL_FUNCTION_EVENTS', N'DDL_GDR_DATABASE_EVENTS', N'DDL_GDR_SERVER_EVENTS', N'DDL_INDEX_EVENTS', N'DDL_LINKED_SERVER_EVENTS', N'DDL_LINKED_SERVER_LOGIN_EVENTS', N'DDL_LOGIN_EVENTS', N'DDL_MASTER_KEY_EVENTS', N'DDL_MESSAGE_EVENTS', N'DDL_MESSAGE_TYPE_EVENTS', N'DDL_PARTITION_EVENTS', N'DDL_PARTITION_FUNCTION_EVENTS', N'DDL_PARTITION_SCHEME_EVENTS', N'DDL_PLAN_GUIDE_EVENTS', N'DDL_PROCEDURE_EVENTS', N'DDL_QUEUE_EVENTS', N'DDL_REMOTE_SERVER_EVENTS', N'DDL_REMOTE_SERVICE_BINDING_EVENTS', N'DDL_RESOURCE_GOVERNOR_EVENTS', N'DDL_RESOURCE_POOL', N'DDL_ROLE_EVENTS', N'DDL_ROUTE_EVENTS', N'DDL_RULE_EVENTS', N'DDL_SCHEMA_EVENTS', N'DDL_SERVER_AUDIT_EVENTS', N'DDL_SERVER_AUDIT_SPECIFICATION_EVENTS', N'DDL_SERVER_LEVEL_EVENTS', N'DDL_SERVER_SECURITY_EVENTS', N'DDL_SERVICE_EVENTS', N'DDL_SERVICE_MASTER_KEY_EVENTS', N'DDL_SSB_EVENTS', N'DDL_STATISTICS_EVENTS', N'DDL_SYMMETRIC_KEY_EVENTS', N'DDL_SYNONYM_EVENTS', N'DDL_TABLE_EVENTS', N'DDL_TABLE_VIEW_EVENTS', N'DDL_TRIGGER_EVENTS', N'DDL_TYPE_EVENTS', N'DDL_USER_EVENTS', N'DDL_VIEW_EVENTS', N'DDL_WORKLOAD_GROUP', N'DDL_XML_SCHEMA_COLLECTION_EVENTS', N'DEADLOCK_GRAPH', N'DENY_DATABASE', N'DENY_SERVER', N'DEPRECATION_ANNOUNCEMENT', N'DEPRECATION_FINAL_SUPPORT', N'DROP_APPLICATION_ROLE', N'DROP_ASSEMBLY', N'DROP_ASYMMETRIC_KEY', N'DROP_BROKER_PRIORITY', N'DROP_CERTIFICATE', N'DROP_CONTRACT', N'DROP_CREDENTIAL', N'DROP_CRYPTOGRAPHIC_PROVIDER', N'DROP_DATABASE', N'DROP_DATABASE_AUDIT_SPECIFICATION', N'DROP_DATABASE_ENCRYPTION_KEY', N'DROP_DEFAULT', N'DROP_ENDPOINT', N'DROP_EVENT_NOTIFICATION', N'DROP_EVENT_SESSION', N'DROP_EXTENDED_PROCEDURE', N'DROP_EXTENDED_PROPERTY', N'DROP_FULLTEXT_CATALOG', N'DROP_FULLTEXT_INDEX', N'DROP_FULLTEXT_STOPLIST', N'DROP_FUNCTION', N'DROP_INDEX', N'DROP_LINKED_SERVER', N'DROP_LINKED_SERVER_LOGIN', N'DROP_LOGIN', N'DROP_MASTER_KEY', N'DROP_MESSAGE', N'DROP_MESSAGE_TYPE', N'DROP_PARTITION_FUNCTION', N'DROP_PARTITION_SCHEME', N'DROP_PLAN_GUIDE', N'DROP_PROCEDURE', N'DROP_QUEUE', N'DROP_REMOTE_SERVER', N'DROP_REMOTE_SERVICE_BINDING', N'DROP_RESOURCE_POOL', N'DROP_ROLE', N'DROP_ROLE_MEMBER', N'DROP_ROUTE', N'DROP_RULE', N'DROP_SCHEMA', N'DROP_SERVER_AUDIT', N'DROP_SERVER_AUDIT_SPECIFICATION', N'DROP_SERVER_ROLE_MEMBER', N'DROP_SERVICE', N'DROP_SIGNATURE', N'DROP_SIGNATURE_SCHEMA_OBJECT', N'DROP_STATISTICS', N'DROP_SYMMETRIC_KEY', N'DROP_SYNONYM', N'DROP_TABLE', N'DROP_TRIGGER', N'DROP_TYPE', N'DROP_USER', N'DROP_VIEW', N'DROP_WORKLOAD_GROUP', N'DROP_XML_SCHEMA_COLLECTION', N'ERRORLOG', N'EVENTLOG', N'EXCEPTION', N'EXCHANGE_SPILL_EVENT', N'EXECUTION_WARNINGS', N'FT_CRAWL_ABORTED', N'FT_CRAWL_STARTED', N'FT_CRAWL_STOPPED', N'GRANT_DATABASE', N'GRANT_SERVER', N'HASH_WARNING', N'LOCK_DEADLOCK', N'LOCK_DEADLOCK_CHAIN', N'LOCK_ESCALATION', N'LOG_FILE_AUTO_GROW', N'LOG_FILE_AUTO_SHRINK', N'MISSING_COLUMN_STATISTICS', N'MISSING_JOIN_PREDICATE', N'MOUNT_TAPE', N'OBJECT_ALTERED', N'OBJECT_CREATED', N'OBJECT_DELETED', N'OLEDB_CALL_EVENT', N'OLEDB_DATAREAD_EVENT', N'OLEDB_ERRORS', N'OLEDB_PROVIDER_INFORMATION', N'OLEDB_QUERYINTERFACE_EVENT', N'QN__DYNAMICS', N'QN__PARAMETER_TABLE', N'QN__SUBSCRIPTION', N'QN__TEMPLATE', N'QUEUE_ACTIVATION', N'RENAME', N'REVOKE_DATABASE', N'REVOKE_SERVER', N'SERVER_MEMORY_CHANGE', N'SHOWPLAN_ALL_FOR_QUERY_COMPILE', N'SHOWPLAN_XML', N'SHOWPLAN_XML_FOR_QUERY_COMPILE', N'SHOWPLAN_XML_STATISTICS_PROFILE', N'SORT_WARNINGS', N'SP_CACHEINSERT', N'SP_CACHEMISS', N'SP_CACHEREMOVE', N'SP_RECOMPILE', N'SQL_STMTRECOMPILE', N'TRACE_FILE_CLOSE', N'TRC_ALL_EVENTS', N'TRC_CLR', N'TRC_DATABASE', N'TRC_DEPRECATION', N'TRC_ERRORS_AND_WARNINGS', N'TRC_FULL_TEXT', N'TRC_LOCKS', N'TRC_OBJECTS', N'TRC_OLEDB', N'TRC_PERFORMANCE', N'TRC_QUERY_NOTIFICATIONS', N'TRC_SECURITY_AUDIT', N'TRC_SERVER', N'TRC_STORED_PROCEDURES', N'TRC_TSQL', N'TRC_USER_CONFIGURABLE', N'UNBIND_DEFAULT', N'UNBIND_RULE', N'UPDATE_STATISTICS', N'USER_ERROR_MESSAGE', N'USERCONFIGURABLE_0', N'USERCONFIGURABLE_1', N'USERCONFIGURABLE_2', N'USERCONFIGURABLE_3', N'USERCONFIGURABLE_4', N'USERCONFIGURABLE_5', N'USERCONFIGURABLE_6', N'USERCONFIGURABLE_7', N'USERCONFIGURABLE_8', N'USERCONFIGURABLE_9', N'XQUERY_STATIC_TYPE')
GO

CREATE PARTITION SCHEME [upsAuditData] AS PARTITION [upfAuditData] ALL TO ([PRIMARY]);
GO

CREATE TABLE [Audit].[AuditData](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[EventMsg] [xml] NULL,
	[EventDate] [datetime] NULL,
	[EventType] [sysname] NULL,
	[ServerName] [sysname] NULL
) ON [upsAuditData]([EventType])
WITH
(
DATA_COMPRESSION = PAGE
)
GO

CREATE UNIQUE CLUSTERED INDEX [idxucEventDateId] ON [Audit].[AuditData] 
(
	[Id] ASC,
	[EventType] ASC,
	[EventDate] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON, FILLFACTOR = 80, DATA_COMPRESSION = PAGE) ON [upsAuditData]([EventType])
GO

CREATE NONCLUSTERED INDEX [idx_server_name] ON [Audit].[AuditData] 
(
	[ServerName] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON, FILLFACTOR = 80, DATA_COMPRESSION = PAGE) ON [PRIMARY]
GO

ALTER TABLE [Audit].[AuditData] SET (LOCK_ESCALATION = DISABLE)
GO

ALTER TABLE [Audit].[AuditData] ADD  CONSTRAINT [DF_EventDate_GetDate]  DEFAULT (getdate()) FOR [EventDate]
GO

CREATE TABLE [Audit].[AuditErrors](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[ErrorProcedure] [nvarchar](128) NULL,
	[ErrorLine] [int] NULL,
	[ErrorNumber] [int] NULL,
	[ErrorMessage] [nvarchar](max) NULL,
	[ErrorSeverity] [int] NULL,
	[ErrorState] [int] NULL,
	[AuditedData] [xml] NULL,
	[ErrorDate] [datetime] NULL,
 CONSTRAINT [PKAuditErrors] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON, FILLFACTOR = 80) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [Audit].[AuditErrors] ADD  CONSTRAINT [DFErrorDateGetUTCDate]  DEFAULT (getutcdate()) FOR [ErrorDate]
GO


/* Set up Service Broker */

CREATE MESSAGE TYPE [AuditData] AUTHORIZATION [dbo] VALIDATION = NONE
GO

CREATE MESSAGE TYPE [EndOfTimer] AUTHORIZATION [dbo] VALIDATION = NONE
GO

CREATE CONTRACT [AuditDataContract] AUTHORIZATION [dbo] ([AuditData] SENT BY INITIATOR, [EndOfTimer] SENT BY INITIATOR)
GO


CREATE PROCEDURE [Audit].[prcWriteAuditData]
AS
BEGIN

        DECLARE @msgBody XML;
        DECLARE @msgTypeName SYSNAME;
        DECLARE @dlgId uniqueidentifier;
        DECLARE @conversation_group_id UNIQUEIDENTIFIER ;
        DECLARE @tableCount INT;
        DECLARE @endConversation BIT;
        DECLARE @ReceiveCount INT;

        DECLARE @tableMessages TABLE 
        (
          message_body          XML,
          message_type_name     SYSNAME,
          conversation_handle   UNIQUEIDENTIFIER,
          conversation_group_id UNIQUEIDENTIFIER,
          queuing_order         BIGINT
        );

        SET @endConversation = 0; -- initially set to 0.  Will set to 1 if we need to later.


        WHILE(1=1)
        BEGIN
                BEGIN TRANSACTION       
                BEGIN TRY               

                        ;WAITFOR (
                           GET CONVERSATION GROUP @conversation_group_id
                          FROM dbo.TargetAuditQueue
                        ), TIMEOUT 1000 ;

                        IF @conversation_group_id IS NOT NULL
                        BEGIN

                                -- insert messages into audit table one message at a time
                                RECEIVE message_body,      
                                        message_type_name,
                                        conversation_handle,
                                        conversation_group_id,
                                        queuing_order

                                   FROM dbo.TargetAuditQueue

                                   INTO @tableMessages

                                  WHERE conversation_group_id = @conversation_group_id
                                
                                SELECT @tableCount = COUNT(*)
                                  FROM @tableMessages;


                                -- exit when the whole queue has been processed
                                IF @tableCount = 0
                                BEGIN
                                        IF @@TRANCOUNT > 0
                                        BEGIN 
                                                ROLLBACK;
                                        END  
                                        BREAK;
                                END 

                                INSERT INTO Audit.AuditData(EventMsg, EventType, ServerName)
                                SELECT message_body, 
                                       message_body.value('(EVENT_INSTANCE/EventType)[1]','sysname'), 
                                       message_body.value('(EVENT_INSTANCE/ServerName)[1]','sysname')
                                  FROM @tableMessages 
                                 WHERE message_type_name NOT IN (N'EndOfTimer',N'http://schemas.microsoft.com/SQL/ServiceBroker/Error')

                                IF EXISTS (SELECT NULL
                                             FROM @tableMessages
                                            WHERE message_type_name = N'EndOfTimer')
                                SET @endConversation = 1;


                                IF EXISTS (SELECT NULL
                                             FROM @tableMessages
                                            WHERE message_type_name = N'http://schemas.microsoft.com/SQL/ServiceBroker/Error')
                                SET @endConversation = 1;

                                IF @endConversation = 1
                                BEGIN
                                  WHILE EXISTS (SELECT DISTINCT conversation_handle 
                                                  FROM @tableMessages 
                                                 WHERE conversation_group_id = @conversation_group_id
                                                   AND message_type_name IN (N'EndOfTimer',N'http://schemas.microsoft.com/SQL/ServiceBroker/Error'))
                                  BEGIN
                                    DECLARE @conversation_handle2 uniqueidentifier
                                    
                                    SELECT DISTINCT @conversation_handle2 = conversation_handle
                                      FROM @tableMessages
                                     WHERE conversation_group_id = @conversation_group_id
                                       AND message_type_name IN (N'EndOfTimer',N'http://schemas.microsoft.com/SQL/ServiceBroker/Error');
                                      
                                    END CONVERSATION @conversation_handle2;
                                    
                                    DELETE FROM @tableMessages 
                                     WHERE conversation_handle = @conversation_handle2;
                                  END
                                END     
                                
                                SET @endConversation = 0;
                                SET @conversation_group_id = NULL;
                                DELETE FROM @tableMessages;

                                IF @@TRANCOUNT > 0
                                BEGIN 
                                        COMMIT;
                                END

                        END; -- End the IF @conversation_group_id is not null loop
                        ELSE 
                        BEGIN
                            IF @@TRANCOUNT > 0
                            BEGIN 
                                    COMMIT;
                            END
                           --SELECT 1;
                           BREAK; -- No conversation group, so exit loop
                        END
                        
                END TRY
                BEGIN CATCH
                        IF @@TRANCOUNT > 0
                        BEGIN 
                                ROLLBACK;
                        END
                        -- insert error into the AuditErrors table
                        INSERT INTO Audit.AuditErrors (       
                                        ErrorProcedure, ErrorLine, ErrorNumber, ErrorMessage, 
                                        ErrorSeverity, ErrorState, AuditedData)
                        SELECT  ERROR_PROCEDURE(), ERROR_LINE(), ERROR_NUMBER(), ERROR_MESSAGE(), 
                                        ERROR_SEVERITY(), ERROR_STATE(), @msgBody
                                                
                        DECLARE @errorId BIGINT, @dbName nvarchar(128)
                        SELECT  @errorId = scope_identity(), @dbName = DB_NAME()

                        RAISERROR (N'Error while receiving Service Broker message. Error info can be found in ''%s.Audit.AuditErrors'' table with id: %I64d', 16, 1, @dbName, @errorId) WITH LOG;
                END CATCH;
        END     
END
GO


CREATE QUEUE [dbo].[TargetAuditQueue] 
 WITH STATUS = ON , 
      RETENTION = OFF , 
      ACTIVATION (  STATUS = ON , 
                    PROCEDURE_NAME = [Audit].[prcWriteAuditData] , 
                    MAX_QUEUE_READERS = 50 , 
                    EXECUTE AS N'dbo'  ) ON [PRIMARY] 
GO

CREATE SERVICE [AuditDataWriter]  AUTHORIZATION [dbo]  ON QUEUE [dbo].[TargetAuditQueue] ([AuditDataContract])
GO

GRANT SEND ON SERVICE::[AuditDataWriter] TO [public] AS [dbo]
GO

CREATE ROUTE [AuditRoute]  AUTHORIZATION [dbo]  WITH  ADDRESS  = N'TRANSPORT' 
GO

USE master;
GO

CREATE ENDPOINT AuditEndPoint
	-- set endpoint to actively listen for connections
	STATE = STARTED
	-- set it for TCP traffic only since service broker supports only TCP protocol
	-- by convention, 4022 is used but any number between 1024 and 32767 is valid.
	AS TCP (LISTENER_PORT = 10050)
	FOR SERVICE_BROKER 
	(
		-- authenticate connections with our NTLM
		AUTHENTICATION = WINDOWS NTLM
	);
GO

GRANT CONNECT ON ENDPOINT::AuditEndPoint TO PUBLIC;
GO






