USE [master]
GO

DROP DATABASE [Repository];
GO

DROP ENDPOINT AuditEndPoint;
GO
