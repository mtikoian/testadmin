USE Presents

SELECT b.[name], a.*
FROM sys.dm_db_index_usage_stats AS a
    INNER JOIN sys.indexes AS b ON a.[object_id] = b.[object_id] AND 
    a.[index_id] = b.[index_id]
WHERE a.[database_id] = DB_ID()
 AND a.[object_id] > 1000 AND b.[name] IS NOT NULL;

SELECT * FROM customers WHERE Companyname = 'Let''s Stop N Shop'

SELECT Companyname FROM customers WHERE Companyname = 'Let''s Stop N Shop'

SELECT Companyname, ContactName FROM customers WHERE Companyname = 'Let''s Stop N Shop'

SELECT Companyname, customerID FROM customers WHERE Companyname = 'Let''s Stop N Shop'

SELECT * FROM customers WHERE customerID = 'LETSS'

SELECT * FROM customers 

exec sp_helpindex customers

SELECT b.[name], a.*
FROM sys.dm_db_index_usage_stats AS a
    INNER JOIN sys.indexes AS b ON a.[object_id] = b.[object_id] AND 
    a.[index_id] = b.[index_id]
WHERE a.[database_id] = DB_ID()
 AND a.[object_id] > 1000 AND b.[name] IS NOT NULL;

