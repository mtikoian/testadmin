--  Find unused indexes

DECLARE @dbid int 

SET @dbid = db_id() 

SELECT OBJECT_NAME(s.[object_id]) AS [Object Name] 
    , s.[object_id] AS [Object ID]
    , i.[name] AS [Index Name] 
    , i.[index_id] AS [Index ID]
    , user_seeks 
    , user_scans 
    , user_lookups 
    , user_updates 
FROM sys.dm_db_index_usage_stats AS s 
    INNER JOIN  sys.indexes AS i 
        ON i.[object_id] = s.[object_id] 
            AND i.index_id = s.index_id 
WHERE database_id = @dbid 
    AND OBJECTPROPERTY(s.[object_id] , 'IsUserTable') = 1 
ORDER BY (user_seeks + user_scans + user_lookups + user_updates) ASC 

