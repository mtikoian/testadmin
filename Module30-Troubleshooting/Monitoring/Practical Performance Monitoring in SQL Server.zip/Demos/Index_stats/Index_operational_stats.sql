USE [Presents]
GO

SELECT b.[name], a.*
FROM sys.dm_db_index_operational_stats(NULL, NULL, NULL, NULL) AS a
    INNER JOIN sys.indexes AS b ON a.[object_id] = b.[object_id] AND 
    a.[index_id] = b.[index_id]
WHERE a.[database_id] = DB_ID()
    AND b.[name] LIKE '%customers%'
    AND a.[object_id] > 1000;


DELETE FROM [dbo].[customers] WHERE [customerID] = 'PMDB1'
DELETE FROM [dbo].[customers] WHERE [customerID] = 'PMDB2'
DELETE FROM [dbo].[customers] WHERE [customerID] = 'PMDB3'

INSERT INTO [Presents].[dbo].[customers]
    ([customerID],[CompanyName],[ContactName],[ContactTitle],[Address],[City],
    [Region],[PostalCode],[Country],[Phone],[Fax])
VALUES
   ('PMDB1','Solid Quality Mentors','Andrew J. Kelly','MVP','Somewhere','Plaistow',
    'NA','03865','USA','1234567899','1234567899')


SELECT * FROM [dbo].[customers] WHERE [customerID] = 'PMDB1'

UPDATE [dbo].[customers] SET [Region] = 'None' WHERE [customerID] = 'PMDB1'

INSERT INTO [Presents].[dbo].[customers]
    ([customerID],[CompanyName],[ContactName],[ContactTitle],[Address],[City],
    [Region],[PostalCode],[Country],[Phone],[Fax])
VALUES
   ('PMDB2','Solid Quality Mentors','Andrew J. Kelly','MVP','Somewhere','Plaistow',
    'NA','03865','USA','1234567899','1234567899')

SELECT * FROM [dbo].[customers] WHERE [customerID] = 'PMDB2'


INSERT INTO [Presents].[dbo].[customers]
    ([customerID],[CompanyName],[ContactName],[ContactTitle],[Address],[City],
    [Region],[PostalCode],[Country],[Phone],[Fax])
VALUES
   ('PMDB3','Solid Quality Mentors','Andrew J. Kelly','MVP','Somewhere','Plaistow',
    'NA','03865','USA','1234567899','1234567899')


SELECT * FROM [dbo].[customers] WHERE [customerID] = 'PMDB3'


SELECT b.[name], a.*
FROM sys.dm_db_index_operational_stats(NULL, NULL, NULL, NULL) AS a
    INNER JOIN sys.indexes AS b ON a.[object_id] = b.[object_id] AND 
    a.[index_id] = b.[index_id]
WHERE a.[database_id] = DB_ID()
    AND b.[name] LIKE '%customers%'
    AND a.[object_id] > 1000;

-- Rebuild the index
ALTER INDEX [IX_customers_customerID] ON [dbo].[customers] REBUILD

ALTER INDEX [IX_customers_CompanyName] ON [dbo].[customers] REBUILD


SELECT b.[name], a.*
FROM sys.dm_db_index_operational_stats(NULL, NULL, NULL, NULL) AS a
    INNER JOIN sys.indexes AS b ON a.[object_id] = b.[object_id] AND 
    a.[index_id] = b.[index_id]
WHERE a.[database_id] = DB_ID()
    AND b.[name] LIKE '%customers%'
    AND a.[object_id] > 1000;

--SELECT * FROM [sys].[dm_db_index_operational_stats](NULL,NULL,NULL,NULL)
--    WHERE [row_lock_wait_in_ms] > 0 OR [page_lock_wait_in_ms] > 0
--        ORDER BY [row_lock_wait_in_ms] DESC
