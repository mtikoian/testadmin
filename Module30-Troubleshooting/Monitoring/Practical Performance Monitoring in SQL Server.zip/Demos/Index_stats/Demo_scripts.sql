-- Tracks from last database startup. If db is closed stats are cleared out for that db.
-- Take the DB OFF LINE to clear the stats
USE master;
GO
ALTER DATABASE AdventureWorks SET SINGLE_USER WITH ROLLBACK IMMEDIATE; 
GO
ALTER DATABASE AdventureWorks SET OFFLINE;
GO
ALTER DATABASE AdventureWorks SET ONLINE;
GO
ALTER DATABASE AdventureWorks SET MULTI_USER; 
GO
USE AdventureWorks

SELECT * FROM sys.dm_db_index_usage_stats
    WHERE [database_id] = DB_ID('AdventureWorks')
        AND [object_id] = OBJECT_ID('[Sales].[SalesOrderHeader]')
ORDER BY [index_id] ;

GO
SELECT TOP 1000 * FROM [Sales].[SalesOrderHeader]  --  1000 rows, Index ID 1 Scan
SELECT * FROM [Sales].[SalesOrderHeader] WHERE [SalesOrderID] BETWEEN 67205 AND 67304  --  100 Rows, Index ID 1 Seek
SELECT * FROM [Sales].[SalesOrderHeader] WHERE [rowguid] = '5602C304-853C-43D7-9E79-76E320D476CF'  -- Index ID 2, 1 Row Seek
SELECT * FROM [Sales].[SalesOrderHeader] WHERE [SalesOrderNumber] = 'SO43693'  --  1 Row, Index ID 3 Seek
GO
SELECT * FROM sys.dm_db_index_usage_stats
    WHERE [database_id] = DB_ID('AdventureWorks')
        AND [object_id] = OBJECT_ID('[Sales].[SalesOrderHeader]')
ORDER BY [index_id] ;

--  *****Rebuilding indexes with REBUILD will show as a clustered index system_scan. One for each index.


sp_helpindex 'sales.SalesOrderHeader' ;

ALTER INDEX ALL ON sales.SalesOrderHeader REBUILD ;

SELECT * FROM sys.dm_db_index_usage_stats
    WHERE [database_id] = DB_ID('AdventureWorks')
        AND [object_id] = OBJECT_ID('[Sales].[SalesOrderHeader]')
ORDER BY [index_id] ;


--  Un-used indexes
SELECT OBJECT_NAME(i.[object_id]) AS [Object Name], i.[name] AS [Index Name], i.index_id AS [Index ID]
    FROM sys.indexes AS i INNER JOIN sys.objects AS o 
        ON i.[object_id] = o.[object_id]
    WHERE NOT EXISTS( SELECT * FROM sys.dm_db_index_usage_stats AS u 
            WHERE u.[object_id] = i.[object_id] AND u.[index_id] = i.[index_id] 
            AND (u.[user_seeks] = 0 AND u.[user_scans] = 0 AND u.[user_lookups] = 0) )
                    AND OBJECTPROPERTY(o.[object_id],'IsUserTable') = 1
ORDER BY [Object Name], [Index ID] ASC


