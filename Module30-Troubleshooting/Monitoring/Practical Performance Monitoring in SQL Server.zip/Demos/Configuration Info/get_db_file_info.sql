-- -- CREATE PROCEDURE [dbo].[get_db_file_info]
-- -- 
-- -- AS

SET NOCOUNT ON

IF OBJECT_ID('tempdb.dbo.#files') IS NOT NULL
    DROP TABLE #Files

CREATE TABLE #Files (
    [Server_Name] VARCHAR(50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
    [DB_Name] VARCHAR(50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[File_ID] [int] NOT NULL ,
	[Group_ID] [int] NOT NULL ,
	[Size] VARCHAR(20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[Max_Size] VARCHAR(20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[Growth] VARCHAR(20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[State] VARCHAR(20) NOT NULL ,
	[Name] [nvarchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[FileName] [nvarchar] (260) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL 
)


DECLARE @DBName VARCHAR(100), @Sql VARCHAR(1000), @Server VARCHAR(50)
SET @Server = @@SERVERNAME

DECLARE curDBs CURSOR STATIC 
FOR SELECT [name] 
        FROM [sys].[databases]

OPEN curDBs

FETCH NEXT FROM curDBs INTO @DBName

WHILE @@FETCH_STATUS = 0
BEGIN


    SET @Sql = ' INSERT INTO #Files ([Server_Name], [DB_Name],[File_ID] ,[Group_ID] ,[Size],[Max_Size],[Growth],[State],[Name] ,[FileName]) ' + 
                ' SELECT ''' + @Server + ''',''' + @DBName + ''', [file_id] ,[data_space_id] ,CAST((CONVERT(BIGINT,[size]) * (8192/1024)/1024) AS VARCHAR(20)) AS [Size] , ' +
                ' CASE [max_size] WHEN 0 THEN ''FIXED'' WHEN -1 THEN ''Unlimited'' ELSE CAST((CONVERT(BIGINT,[max_size]) * (8192/1024)/1024) AS VARCHAR(20)) END AS [Max_Size], ' +
                'CASE WHEN [is_percent_growth] = 0 THEN  CAST((CONVERT(INT,[growth]) * (8192/1024)/1024) AS VARCHAR(20)) + '' MB'' ELSE CAST([growth] AS VARCHAR(20)) + ''%''  END AS [Growth],[state_desc],[name] ,[physical_name] FROM [' + @DBName + '].[sys].[database_files]'

    EXEC(@Sql)



    FETCH NEXT FROM curDBs INTO @DBName

END

CLOSE curDBs
DEALLOCATE curDBs

SELECT * FROM #Files

