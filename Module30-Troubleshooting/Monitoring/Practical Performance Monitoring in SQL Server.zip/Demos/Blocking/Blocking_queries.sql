--  Session 1
SELECT TOP 100 * FROM Sales.SalesOrderDetail ORDER BY SalesOrderDetailID ;


USE AdventureWorks ;
GO

BEGIN TRAN ;

UPDATE Sales.SalesOrderDetail 
    SET OrderQty = 2 
        WHERE SalesOrderDetailID = 55 ;


ROLLBACK TRAN ;

--  Session 2
USE AdventureWorks ;

SELECT TOP 100 * 
    FROM Sales.SalesOrderDetail 
        ORDER BY SalesOrderDetailID ;



SELECT 
        t1.resource_type,
        t1.resource_database_id,
        t1.resource_associated_entity_id,
        t1.request_mode,
        t1.request_session_id,
        t2.blocking_session_id
    FROM sys.dm_tran_locks AS t1
    INNER JOIN sys.dm_os_waiting_tasks AS t2
        ON t1.lock_owner_address = t2.resource_address;




SELECT
      Blocked.Session_ID AS [Blocked_Session_ID]
    , Blocked_SQL.[text] AS [Blocked_SQL]
    , waits.wait_type AS [Blocked_Resource]
    , Blocking.Session_ID AS [Blocking_Session_ID]
    , Blocking_SQL.[text] AS [Blocking_SQL]
    , waits.[wait_duration_ms] AS [ms Waiting]
FROM sys.dm_exec_connections AS [Blocking] INNER JOIN sys.dm_exec_requests AS [Blocked]
    ON Blocked.Blocking_Session_ID = Blocking.Session_ID
CROSS APPLY
    (
     SELECT * FROM sys.dm_exec_sql_text(Blocking.[most_recent_sql_handle])
    ) AS [Blocking_SQL]
CROSS APPLY
    (
     SELECT * FROM sys.dm_exec_sql_text(Blocked.[sql_handle])
    ) AS [Blocked_SQL]
INNER JOIN sys.dm_os_waiting_tasks AS waits 
    ON waits.Session_ID = Blocked.Session_ID ;


SELECT * FROM sys.dm_os_waiting_tasks
WHERE session_id > 50 ;
SELECT * FROM  sys.dm_exec_requests
WHERE session_id > 50 ;
SELECT * FROM sys.dm_exec_connections
WHERE session_id > 50 ;


--  Find indexes that had waits on them
SELECT * 
    FROM [sys].[dm_db_index_operational_stats](NULL,NULL,NULL,NULL)
    WHERE database_id = DB_ID() 
          AND ( [row_lock_wait_in_ms]  > 0 OR [page_lock_wait_in_ms] > 0 )
    ORDER BY [row_lock_wait_in_ms] DESC ;



