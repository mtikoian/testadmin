IF OBJECT_ID('dbo.fn_SQLSigCLR') IS NOT NULL
    DROP FUNCTION dbo.fn_SQLSigCLR
GO
CREATE FUNCTION dbo.fn_SQLSigCLR(
  @querystring AS NVARCHAR(MAX)
)
RETURNS NVARCHAR(MAX)

WITH RETURNS NULL ON NULL INPUT
    EXTERNAL NAME SQLSignature.SQLSignature.fn_SQLSigCLR ;

GO
IF OBJECT_ID('dbo.fn_RegexReplace') IS NOT NULL
    DROP FUNCTION dbo.fn_RegexReplace
GO
CREATE FUNCTION dbo.fn_RegexReplace(
  @input AS NVARCHAR(MAX)
, @pattern AS NVARCHAR(MAX)
, @replacement AS NVARCHAR(MAX)
)
RETURNS NVARCHAR(MAX)

WITH RETURNS NULL ON NULL INPUT
    EXTERNAL NAME SQLSignature.SQLSignature.fn_RegexReplace ;

GO

