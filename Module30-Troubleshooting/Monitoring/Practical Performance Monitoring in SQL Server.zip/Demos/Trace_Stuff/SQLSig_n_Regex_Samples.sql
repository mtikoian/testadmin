USE RML_Utils
GO

IF OBJECT_ID('[dbo].[SQL_Signature]',N'FN') IS NOT NULL
    DROP FUNCTION [dbo].[SQL_Signature]

GO
-- Create the SQL_Signature function
IF OBJECT_ID('[dbo].[SQL_Signature]',N'FN') IS NOT NULL
    DROP FUNCTION [dbo].[SQL_Signature]
GO
CREATE FUNCTION dbo.SQL_Signature 
	(@p1 nVarchar(MAX), @ParseLength int = 4000)
RETURNS nvarchar(4000)

AS
BEGIN 
	DECLARE @pos as INT
	DECLARE @mode as CHAR(10)
	DECLARE @maxlength as INT
	DECLARE @p2 as NCHAR(4000)
	DECLARE @currchar as CHAR(1), @nextchar as CHAR(1)
	DECLARE @p2len as INT

	SET @maxlength = len(rtrim(substring(@p1,1,4000)));
	SET @maxlength = case when @maxlength > @parselength 
			then @parselength else @maxlength end
	SET @pos = 1;
	SET @p2 = '';
	SET @p2len = 0;
	SET @currchar = ''
	set @nextchar = ''
	SET @mode = 'command';

	WHILE (@pos <= @maxlength) BEGIN
		SET @currchar = substring(@p1,@pos,1)
		SET @nextchar = substring(@p1,@pos+1,1)
		IF @mode = 'command' BEGIN
			SET @p2 = left(@p2,@p2len) + @currchar
			SET @p2len = @p2len + 1 
			IF @currchar in (',','(',' ','=','<','>','!') and
			   @nextchar between '0' and '9' BEGIN
				set @mode = 'number'
				SET @p2 = left(@p2,@p2len) + '#'
				SET @p2len = @p2len + 1
				END 
			IF @currchar = '''' BEGIN
				set @mode = 'literal'
				SET @p2 = left(@p2,@p2len) + '#'''
				SET @p2len = @p2len + 2 
				END
			END
		ELSE IF @mode = 'number' and @nextchar in (',',')',' ','=','<','>','!')
			SET @mode= 'command'
		ELSE IF @mode = 'literal' and @currchar = ''''
			SET @mode= 'command'

		SET @pos = @pos + 1
	END
	RETURN @p2 

END
GO



--  Show how SQL_Signature parses a typical TSQL string
SELECT dbo.SQL_Signature('select * from orders where orderid = 10255 AND MyDate = ''2006-01-01''',1000)

--  Parse a file the TSQL set based way
SELECT dbo.SQL_Signature([TextData],1000) AS [Text]
  FROM ::FN_TRACE_GETTABLE('C:\Perflogs\MiniTrace.trc', DEFAULT)

-- See how many were in the same query class
SELECT dbo.SQL_Signature([TextData],1000) AS [Text], COUNT(*) AS [Totals]
  FROM ::FN_TRACE_GETTABLE('C:\Perflogs\MiniTrace.trc', DEFAULT)
GROUP BY dbo.SQL_Signature([TextData],1000)
ORDER BY COUNT(*) DESC

-- Order by Text
SELECT dbo.SQL_Signature([TextData],1000) AS [Text], COUNT(*) AS [Totals]
  FROM ::FN_TRACE_GETTABLE('C:\Perflogs\MiniTrace.trc', DEFAULT)
GROUP BY dbo.SQL_Signature([TextData],1000)
ORDER BY [Text]




--  Now see how to do this a lot more effeciently with the CLR

-- Enable the CLR
EXEC sp_configure 'clr enable', 1 ;
RECONFIGURE ;
GO

USE RML_Utils ;
GO
IF OBJECT_ID('dbo.fn_SQLSigCLR','FS') IS NOT NULL
    DROP FUNCTION dbo.fn_SQLSigCLR
GO
IF OBJECT_ID('dbo.fn_SQLSignature','FS') IS NOT NULL
    DROP FUNCTION dbo.fn_SQLSignature
GO
IF OBJECT_ID('dbo.fn_RegexReplace','FS') IS NOT NULL
    DROP FUNCTION dbo.fn_RegexReplace
GO
IF EXISTS(SELECT * FROM sys.assemblies WHERE [name] = N'SQLSignature')
    DROP ASSEMBLY SQLSignature

GO
CREATE ASSEMBLY SQLSignature
    FROM 'C:\Presentations\NESQL\RML_Utils\SQLSignature.dll' ;

GO
--  Create the CLR functions that references the dll
IF OBJECT_ID('dbo.fn_SQLSigCLR') IS NOT NULL
    DROP FUNCTION dbo.fn_SQLSigCLR
GO
CREATE FUNCTION dbo.fn_SQLSigCLR(
  @querystring AS NVARCHAR(MAX)
)
RETURNS NVARCHAR(MAX)

WITH RETURNS NULL ON NULL INPUT
    EXTERNAL NAME SQLSignature.SQLSignature.fn_SQLSigCLR ;

GO
IF OBJECT_ID('dbo.fn_RegexReplace') IS NOT NULL
    DROP FUNCTION dbo.fn_RegexReplace
GO
CREATE FUNCTION dbo.fn_RegexReplace(
  @input AS NVARCHAR(MAX)
, @pattern AS NVARCHAR(MAX)
, @replacement AS NVARCHAR(MAX)
)
RETURNS NVARCHAR(MAX)

WITH RETURNS NULL ON NULL INPUT
    EXTERNAL NAME SQLSignature.SQLSignature.fn_RegexReplace ;

GO

--  The same sql statement parsed now with the CLR functions
SELECT dbo.fn_SQLSigCLR('select * from orders where orderid = 10255 AND MyDate = ''2006-01-01''')

SELECT dbo.fn_RegexReplace('select * from orders where orderid = 10255 AND MyDate = ''2006-01-01''',
   N'([\s,(=<>!](?![^\]]+[\]]))(?:(?:(?:(?#    expression coming
     )(?:([N])?('')(?:[^'']|'''')*(''))(?#      character
     )|(?:0x[\da-fA-F]*)(?#                     binary
     )|(?:[-+]?(?:(?:[\d]*\.[\d]*|[\d]+)(?#     precise number
     )(?:[eE]?[\d]*)))(?#                       imprecise number
     )|(?:[~]?[-+]?(?:[\d]+))(?#                integer
     ))(?:[\s]?[\+\-\*\/\%\&\|\^][\s]?)?)+(?#   operators
     ))', N'$1$2$3#$4')


--  Parse a file the CLR way
SELECT dbo.fn_SQLSigCLR([TextData]) AS [Text]
  FROM ::FN_TRACE_GETTABLE('C:\Perflogs\MiniTrace.trc', DEFAULT)
WHERE [TextData] IS NOT NULL
ORDER BY [Text]

-- Notice that Regex doesn't treat the text inside the dynamic sql the same way
SELECT dbo.fn_RegexReplace([TextData],
   N'([\s,(=<>!](?![^\]]+[\]]))(?:(?:(?:(?#    expression coming
     )(?:([N])?('')(?:[^'']|'''')*(''))(?#      character
     )|(?:0x[\da-fA-F]*)(?#                     binary
     )|(?:[-+]?(?:(?:[\d]*\.[\d]*|[\d]+)(?#     precise number
     )(?:[eE]?[\d]*)))(?#                       imprecise number
     )|(?:[~]?[-+]?(?:[\d]+))(?#                integer
     ))(?:[\s]?[\+\-\*\/\%\&\|\^][\s]?)?)+(?#   operators
     ))', N'$1$2$3#$4') AS [Text]
  FROM ::FN_TRACE_GETTABLE('C:\Perflogs\MiniTrace.trc', DEFAULT)
WHERE [TextData] IS NOT NULL
ORDER BY [Text]



SELECT dbo.fn_SQLSigCLR([TextData]) AS [Text], COUNT(*) AS [Totals]
    FROM ::FN_TRACE_GETTABLE('C:\Perflogs\MiniTrace.trc', DEFAULT)
GROUP BY dbo.fn_SQLSigCLR([TextData])
ORDER BY [Text]

--   Group by the Query Class
SELECT  dbo.fn_RegexReplace([TextData],
   N'([\s,(=<>!](?![^\]]+[\]]))(?:(?:(?:(?#    expression coming
     )(?:([N])?('')(?:[^'']|'''')*(''))(?#      character
     )|(?:0x[\da-fA-F]*)(?#                     binary
     )|(?:[-+]?(?:(?:[\d]*\.[\d]*|[\d]+)(?#     precise number
     )(?:[eE]?[\d]*)))(?#                       imprecise number
     )|(?:[~]?[-+]?(?:[\d]+))(?#                integer
     ))(?:[\s]?[\+\-\*\/\%\&\|\^][\s]?)?)+(?#   operators
     ))', N'$1$2$3#$4') AS [Text], COUNT(*) AS [Totals]
  FROM ::FN_TRACE_GETTABLE('C:\Perflogs\MiniTrace.trc', DEFAULT)
GROUP BY dbo.fn_RegexReplace([TextData],
   N'([\s,(=<>!](?![^\]]+[\]]))(?:(?:(?:(?#    expression coming
     )(?:([N])?('')(?:[^'']|'''')*(''))(?#      character
     )|(?:0x[\da-fA-F]*)(?#                     binary
     )|(?:[-+]?(?:(?:[\d]*\.[\d]*|[\d]+)(?#     precise number
     )(?:[eE]?[\d]*)))(?#                       imprecise number
     )|(?:[~]?[-+]?(?:[\d]+))(?#                integer
     ))(?:[\s]?[\+\-\*\/\%\&\|\^][\s]?)?)+(?#   operators
     ))', N'$1$2$3#$4')
ORDER BY [Text]
