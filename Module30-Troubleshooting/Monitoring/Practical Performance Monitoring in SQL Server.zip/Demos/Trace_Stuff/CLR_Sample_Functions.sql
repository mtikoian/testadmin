using System.Text;
using Microsoft.SqlServer.Server;
using System.Data.SqlTypes;
using System.Text.RegularExpressions;

public partial class SQLSignature
{
        // SQL Signature
    [SqlFunction(IsDeterministic = true, DataAccess = DataAccessKind.None)]
    public static SqlString fn_SQLSignature(SqlString inpRawString,
      SqlInt32 inpParseLength)
    {
        if (inpRawString.IsNull)
            return SqlString.Null;
        int pos = 0;
        string mode = "command";
        string RawString = inpRawString.Value;
        int maxlength = RawString.Length;
        StringBuilder p2 = new StringBuilder();
        string currchar = "";
        string nextchar = "";
        int ParseLength = RawString.Length;
        if (!inpParseLength.IsNull)
            ParseLength = inpParseLength.Value;
        if (RawString.Length > ParseLength)
        {
            maxlength = ParseLength;
        }
        while (pos < maxlength)
        {
            currchar = RawString.Substring(pos, 1);
            if (pos < maxlength - 1)
            {
                nextchar = RawString.Substring(pos + 1, 1);
            }

            else
            {
                nextchar = RawString.Substring(pos, 1);
            }
            if (mode == "command")
            {
                p2.Append(currchar.ToString());
                if ((currchar.ToString() == "," | currchar.ToString() == "(" |
                     currchar.ToString() == " " | currchar.ToString() == "=" |
                     currchar.ToString() == "<" | currchar.ToString() == ">" |
                     currchar.ToString() == "!")
                   &&
                    (nextchar.ToString() == "0" | nextchar.ToString() == "1" |
                     nextchar.ToString() == "2" | nextchar.ToString() == "3" |
                     nextchar.ToString() == "4" | nextchar.ToString() == "5" |
                     nextchar.ToString() == "6" | nextchar.ToString() == "7" |
                     nextchar.ToString() == "8" | nextchar.ToString() == "9"))
                {
                    mode = "number";
                    p2.Append('#');
                }
                if (currchar.ToString() == "'")
                {
                    mode = "literal";
                    p2.Append("#'");
                }
            }
            else if ((mode == "number")
                      &&
                     (nextchar.ToString() == "," |
                      nextchar.ToString() == "(" |
                      nextchar.ToString() == " " |
                      nextchar.ToString() == "=" |
                      nextchar.ToString() == "<" |
                      nextchar.ToString() == ">" |
                      nextchar.ToString() == "!"))
            {
                mode = "command";
            }
            else if ((mode == "literal") && (currchar.ToString() == "'"))
            {
                mode = "command";
            }
            pos++;
        }
        return p2.ToString();
    }


    // fn_SQLSigCLR
    [SqlFunction(IsDeterministic = true, DataAccess = DataAccessKind.None)]
    public static SqlString fn_SQLSigCLR(SqlString querystring)
    {
        return (SqlString)Regex.Replace(
            querystring.Value,
            @"([\s,(=<>!])(([\d]*\.[\d]*)|([\d]+)|((').*(')))",
            @"$1$6#$7");
    }


    // fn_SQLSigCLR_EX
    [SqlFunction(IsDeterministic = true, DataAccess = DataAccessKind.None)]
    public static SqlString fn_SQLSigCLR_EX(SqlString querystring)
    {
        return (SqlString)Regex.Replace(
            querystring.Value,
        @"([\s,(=<>!](?![^\]]+[\]]))(?:(?:(?:(?#
             )(?:([N])?('')(?:[^'']|'''')*(''))(?#
             )|(?:0x[\da-fA-F]*)(?#
             )|(?:[-+]?(?:(?:[\d]*\.[\d]*|[\d]+)(?#
             )(?:[eE]?[\d]*)))(?#
             )|(?:[~]?[-+]?(?:[\d]+))(?#
             ))(?:[\s]?[\+\-\*\/\%\&\|\^][\s]?)?)+(?#
             ))", @"$1$2$3#$4");
        
    }

    // fn_RegexReplace - for generic use of RegEx-based replace
    [SqlFunction(IsDeterministic = true, DataAccess = DataAccessKind.None)]
    public static SqlString fn_RegexReplace(
        SqlString input, SqlString pattern, SqlString replacement)
    {
        return (SqlString)Regex.Replace(
            input.Value, pattern.Value, replacement.Value);
    }
}
