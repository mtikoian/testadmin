
--  List the current traces.  SQL2000 way
SELECT * FROM fn_trace_getinfo(DEFAULT) 

--  SQL 2005 way
SELECT * FROM sys.traces

--  Stop the trace
EXEC sp_trace_setstatus 2,0

--  Close and Remove the trace definition
EXEC sp_trace_setstatus 2,2




--  Gets all Events for a given trace or all if 0, null or default is passed. Actually a bug requires the actual trace id
SELECT a.[EventID], b.[name] AS [Even Name], a.[ColumnID], 
       c.[name] AS [Column Name], d.[name] AS [Category]
FROM fn_trace_geteventinfo(1) AS a INNER JOIN sys.trace_events AS b
    ON a.EventID = b.Trace_Event_ID
INNER JOIN sys.trace_columns AS c
    ON a.ColumnID = c.Trace_Column_ID
INNER JOIN sys.trace_categories AS d
    ON b.Category_ID = d.Category_ID
ORDER BY a.[EventID], a.[ColumnID]

--  This will return any filter conditions
SELECT * FROM fn_trace_getfilterinfo(2)

SELECT a.[ColumnID], c.[name], a.[value], c.*
FROM fn_trace_getfilterinfo( 2 ) AS a INNER JOIN sys.trace_columns AS c
    ON a.ColumnID = c.Trace_Column_ID
ORDER BY a.[ColumnID]

-- List all the trace categories
SELECT * FROM sys.trace_categories




SELECT *
  FROM ::FN_TRACE_GETTABLE('C:\Perflogs\DemoTrace.trc', DEFAULT)
  








--  Get the data from the trace file(s) as a rowset
SELECT [EventClass], [TextData], [Duration], [Reads], [Writes], [CPU], [DatabaseID], [StartTime], [NTUserName], 
    [ClientProcessID], [ApplicationName], [LoginName], [SPID],  [Severity], [ServerName]
--INTO [dbo].[TraceTable]
    FROM fn_trace_gettable('C:\Perflogs\DemoTrace.trc', DEFAULT)
ORDER BY EventClass


