USE Presents
GO
SET NOCOUNT ON
GO
DBCC FREEPROCCACHE
DBCC DROPCLEANBUFFERS

GO
IF OBJECT_ID('[dbo].[cp_test1]',N'P') IS NOT NULL
    DROP PROCEDURE [dbo].[cp_test1]
GO
CREATE PROCEDURE [dbo].[cp_test1]
@ID INT
AS

SELECT * FROM [dbo].[OrderHeader] WHERE [OrderHeader].[CustomerID] = @ID
Go
IF OBJECT_ID('[dbo].[cp_test2]',N'P') IS NOT NULL
    DROP PROCEDURE [dbo].[cp_test2]
GO
CREATE PROCEDURE [dbo].[cp_test2]
@ID INT
AS

SELECT * FROM [dbo].[OrderHeader] WHERE [OrderHeader].[CustomerID] = @ID
Go
IF OBJECT_ID('[dbo].[cp_test3]',N'P') IS NOT NULL
    DROP PROCEDURE [dbo].[cp_test3]
GO
CREATE PROCEDURE [dbo].[cp_test3]
@ID INT
AS

SELECT * FROM [dbo].[OrderHeader] WHERE [OrderHeader].[CustomerID] = @ID
Go
IF OBJECT_ID('[dbo].[cp_test4]',N'P') IS NOT NULL
    DROP PROCEDURE [dbo].[cp_test4]
GO
CREATE PROCEDURE [dbo].[cp_test4]
@ID INT
AS

SELECT * FROM [dbo].[OrderHeader] WHERE [OrderHeader].[CustomerID] = @ID
Go

IF OBJECT_ID('Fred') IS NOT NULL
    DROP TABLE Fred
GO
CREATE TABLE FRED (F1 INT, F2 VARCHAR(20))
GO
CREATE CLUSTERED INDEX IX_Fred_Fred ON Fred (F1)
GO
CREATE INDEX IX_Fred_F2 ON Fred (F2)
GO


INSERT INTO Fred (F1,F2) VALUES (1,'1233')
INSERT INTO Fred (F1,F2) VALUES (2,'22222')
INSERT INTO Fred (F1,F2) VALUES (3,'33333')
INSERT INTO Fred (F1,F2) VALUES (4,'44444')
GO
UPDATE Fred SET F2 = 'JJJJ' WHERE F1 = 2
GO
DELETE FROM Fred WHERE F1 = 1
GO

SELECT TOP 10 * FROM [dbo].[OrderDetail] AS a INNER JOIN [dbo].[OrderHeader] AS b
ON [a].[SalesOrderID] = [b].[SalesOrderID]
GO
SELECT TOP 1000 * FROM [dbo].[OrderDetail] AS a INNER JOIN [dbo].[OrderHeader] AS b
ON [a].[SalesOrderID] = [b].[SalesOrderID]
GO
SELECT * FROM [dbo].[OrderHeader] WHERE [OrderHeader].[CustomerID] = 397
GO
SELECT * FROM [dbo].[OrderHeader] WHERE [OrderHeader].[CustomerID] = 301
GO
SELECT * FROM [dbo].[OrderHeader] WHERE [OrderHeader].[CustomerID] = 302
GO
SELECT * FROM [dbo].[OrderHeader] WHERE [OrderHeader].[CustomerID] = 303
GO
SELECT * FROM [dbo].[OrderHeader] WHERE [OrderHeader].[SalesPersonID] = 279
GO
SELECT * FROM [dbo].[OrderHeader] WHERE [OrderHeader].[SalesPersonID] = 240
GO
SELECT * FROM [dbo].[OrderHeader] WHERE [OrderHeader].[SalesPersonID] = 250
GO
SELECT TOP 100 * FROM [dbo].[OrderHeader] WHERE [OrderHeader].[OrderDate] BETWEEN '20040719' AND '20040720'
GO
EXECUTE [dbo].[cp_test1] 70
go
EXECUTE [dbo].[cp_test2] 71
go
EXECUTE [dbo].[cp_test3] 72
go
EXECUTE [dbo].[cp_test4] 73
go
SELECT b.* FROM [dbo].[Customer] AS b
GO
SELECT b.* FROM [dbo].[Customer] AS b WHERE [b].[CustomerID] = 70
go
SELECT * FROM [dbo].[Customer] WHERE [Customer].[CustomerID] = 70
GO
SELECT TOP 2 * FROM [dbo].[Customer] WHERE [Customer].[CustomerID] = 13264
GO
SELECT * FROM [dbo].[Customer] WHERE [Customer].[AccountNumber] = 'AW00000008'
GO
SELECT * FROM [dbo].[Customer] WHERE [Customer].[AccountNumber] = 'AW00026655'
GO
SELECT * FROM [dbo].[Customer] WHERE [Customer].[AccountNumber] = 'AW00011111'
GO
SELECT * FROM [dbo].[Customer] WHERE [Customer].[AccountNumber] = 'AW00034565'
GO
SELECT * FROM [dbo].[Customer] WHERE [Customer].[AccountNumber] LIKE 'AW00026%'
go
SELECT * FROM [dbo].[Customer] WHERE [Customer].[TerritoryID] = 4 AND  [Customer].[CustomerType] = 'S'
go
SELECT * FROM [dbo].[Address] WHERE [Address].[AddressLine1] LIKE '51%'
GO
SELECT * FROM [dbo].[Address] WHERE [Address].[PostalCode] = '90210'
GO
SELECT * FROM [dbo].[Address] WHERE [Address].[PostalCode] = '90394'
GO
SELECT * FROM [dbo].[Address] WHERE [Address].[AddressID] = 11882
go
EXEC('SELECT * FROM [dbo].[OrderHeader] WHERE CustomerID = 397')
GO
EXEC('SELECT * FROM [dbo].[OrderHeader] WHERE CustomerID = 398')
GO
EXEC('SELECT * FROM [dbo].[OrderHeader] WHERE CustomerID = 398')
go
EXEC sp_executesql N'SELECT * FROM [dbo].[OrderHeader] WHERE CustomerID = @x',N'@x int',@x = 12350
GO

