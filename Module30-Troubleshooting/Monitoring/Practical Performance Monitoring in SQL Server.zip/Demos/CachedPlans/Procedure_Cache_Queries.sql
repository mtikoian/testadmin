
DBCC FREEPROCCACHE


select a.* from [Presents].[dbo].[customers] as a where customerID = 'ALFKI' and City = 'Berlin'

SELECT * FROM master..syscacheobjects


SELECT b.[bucketid], b.[cacheobjtype], b.[objtype], b.[refcounts], b.[usecounts]
    , a.[dbid], a.[objectid], b.[size_in_bytes], a.[text]
FROM sys.dm_exec_cached_plans as b
CROSS APPLY sys.dm_exec_sql_text(b.[plan_handle]) AS a
ORDER BY [usecounts] DESC


SELECT (SELECT SUBSTRING(a.[text],1,500)
    FROM sys.dm_exec_sql_text(b.[sql_handle]) AS a) AS [query_text], b.*
FROM sys.dm_exec_query_stats AS b
