SELECT * from sys.dm_exec_cached_plans 
 
select * from sys.dm_exec_plan_attributes(0x06000500F56DC201B841B115000000000000000000000000)

select * from sys.dm_exec_sql_text(0x06000500F56DC201B841B115000000000000000000000000)

SELECT b.*,a.*
FROM sys.dm_exec_cached_plans as a
CROSS APPLY sys.dm_exec_sql_text(a.[plan_handle]) AS b


SELECT b.[bucketid], b.[cacheobjtype], b.[objtype], b.[refcounts], b.[usecounts]
    , a.[dbid], a.[objectid], b.[size_in_bytes], a.[text]
FROM sys.dm_exec_cached_plans as b
CROSS APPLY sys.dm_exec_sql_text(b.[plan_handle]) AS a
ORDER BY [usecounts] DESC


SELECT (SELECT SUBSTRING(a.[text],1,500)
    FROM sys.dm_exec_sql_text(b.[sql_handle]) AS a) AS [query_text], b.*
FROM sys.dm_exec_query_stats AS b



 



