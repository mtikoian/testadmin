

/*
ReadTrace 
    �IC:\Path\TraceFile.trc 
    �oc:\Output_Folder\ 
    �SServer\Instance 
    �dDataBase
*/

--  Make sure to enter SQLCmd mode
!!dir


--  Run ReadTrace
!!"C:\Program Files\Microsoft Corporation\RMLUtils\ReadTrace.exe" �IC:\Perflogs\SampleTrace.trc �oc:\Junk �Slaptop_ibm\sql2008dev �dRML_Utils



/*
exec ReadTrace.usp_BuildTimeIntervals 300 /* # of seconds for each time interval */
exec ReadTrace.usp_BuildPartialAggs
*/



