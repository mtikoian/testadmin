USE Presents ;
GO

DECLARE @X INT ;
SET @X = 0 ;
SET NOCOUNT ON

WHILE @X < 15
BEGIN

    DBCC DROPCLEANBUFFERS ;

    SELECT *
        FROM dbo.Orderdetail ;

--    SELECT SUM(OrderQty) AS [Totals]
--        FROM dbo.Orderdetail ;
    
    SET @X = @X + 1
END ;

