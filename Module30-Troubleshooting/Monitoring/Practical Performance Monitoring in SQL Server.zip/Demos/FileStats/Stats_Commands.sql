/*
--  Clear & Gather Stats
exec dbo.gather_wait_stats_2008 1
exec dbo.gather_file_stats_2008 1

*/

--  Gather Stats
exec dbo.gather_wait_stats_2008
exec dbo.gather_file_stats_2008



/*
--   Report stats
exec dbo.report_wait_stats_2008

exec dbo.report_file_stats_2008

*/

