
/*
--  Clear & Gather Stats
exec dbo.gather_wait_stats_2008 1
exec dbo.gather_file_stats_2008 1

--  Gather Stats
exec dbo.gather_wait_stats_2008
exec dbo.gather_file_stats_2008

*/

/*
--   Report stats
exec dbo.report_wait_stats_2008

exec dbo.report_file_stats_2008
*/


--  List the current traces
SELECT event_count,* FROM sys.traces 


/*

--  Stop the trace
EXEC sp_trace_setstatus 2,0

--  Close and Remove the trace
EXEC sp_trace_setstatus 2,2

*/

/*

SELECT  [EventClass], [TextData], [Duration], [Reads], [Writes], [CPU], [DatabaseID], [StartTime], [NTUserName], 
    [ClientProcessID], [ApplicationName], [LoginName], [SPID],  [Severity], [ServerName]
INTO [dbo].[TraceTable]
    FROM ::fn_trace_gettable('Path\FileName.trc', default)
*/
