USE Trace_Junk
/*
DROP TABLE DisplayToID
DROP TABLE CounterDetails
DROP TABLE CounterData
*/

SELECT * FROM DisplayToID
SELECT * FROM CounterDetails
SELECT * FROM CounterData


