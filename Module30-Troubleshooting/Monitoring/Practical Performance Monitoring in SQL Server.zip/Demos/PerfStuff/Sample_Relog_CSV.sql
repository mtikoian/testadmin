/********** 
* Relog Perfmon .csv files script 
* Greg Linwood 
* Jan 30th, 2006 
* 
* Strips (Relogs) a specific performance counter from a directory 
* of perfmon .csv files & loads them to a permanent table.. 
**********/ 

set nocount on 

/* 
* SETUP 
*/ 

--create a permanent table to store your counters 
--create table tempdb..mycounters (countertime datetime, counterval decimal (15, 3)) 
--truncate table tempdb..mycounters 

--user configurable variables 
declare 
@perfdir varchar(255) -- directory containing .csv perfmon files 
, @archivedir varchar(255) -- archive directory for processed files 
, @counter varchar(1000) -- counter name to be re-logged 

-- alter this to point to your perfmon .csv file diretory 
set @perfdir = 'C:\PerfmonLogFiles\' 
-- alter this to point wherever you want processed files to be archived (you might need to add this dir) 
set @archivedir = 'C:\PerfmonLogFiles\Archive\' 
-- alter this to be the counter name you want re-logged 
set @counter = '\\PRODSQL1\SQLServer:Buffer Manager\Page life expectancy' 

/* 
* RUN 
*/ 

-- run-time variables (don't change) 
declare 
@filename varchar(200) -- filename variable for cursor 
, @sql varchar (1000) -- dynamic sql variable 

-- temp table to list .csv perfmon files to work through on 
create table #files(filename varchar(200), d int, f int) 
-- staging table within cursor to bulk load re-logged counter values 
create table #counters (dt varchar(50), val varchar(50)) 

--populate #files via call to xp_dirtree 
insert #files execute master.dbo.xp_dirtree @perfdir, 1, 1 
delete from #files where f != 1 

--for every file to be re-logged... 
declare cr cursor for 
select filename from #files order by filename 
open cr 
fetch next from cr into @filename 
while @@fetch_status = 0 
begin 
--relog counters out to tempout.csv file 
set @sql = 'exec master..xp_cmdshell ''relog ' 
set @sql = @sql + @perfdir + '' + @filename + ' -c "' 
set @sql = @sql + @counter + '" -o ' + @perfdir + 'tempout.csv -f CSV''' 
exec(@sql) 

--bulk load counters from tempout.csv to #counters staging table 
set @sql = 'bulk insert #counters from ''' + @perfdir + 'tempout.csv'' ' 
set @sql = @sql + 'with (FIELDTERMINATOR = '','', FIRSTROW = 2)' 
exec(@sql) 

--delete tempout.csv file 
set @sql = 'exec master..xp_cmdshell ''del ' + @perfdir + 'tempout.csv''' 
exec(@sql) 

--move this perfmon .csv file to the archive dir 
set @sql = 'exec master..xp_cmdshell ''move ' + @perfdir + '' 
set @sql = @sql + @filename + ' ' + @archivedir + @filename + '''' 
exec(@sql) 

--strip any double quotes from counter datetimes / values 
update #counters set dt = replace(dt, '"', ''), val = replace(val, '"', '') 

--move re-logged counters to your permanent table 
insert into tempdb..mycounters 
select convert(datetime, dt) as dt 
, convert(decimal(15, 3), val) as val 
from #counters where isnumeric(val) = 1 

--truncate #counters staging table for next cursor iteration 
truncate table #counters 

fetch next from cr into @filename 
end 
go 
--cleanup cursor 
close cr 
deallocate cr 
go 
--cleanup temporary tables 
if object_id('tempdb..#files') > 0 drop table #files; 
if object_id('tempdb..#counters') > 0 drop table #counters; 
go 
--output some sample results 
select top 20 * from tempdb..mycounters 
