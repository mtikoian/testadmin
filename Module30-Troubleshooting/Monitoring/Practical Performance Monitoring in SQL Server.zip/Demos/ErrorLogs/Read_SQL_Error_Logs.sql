 
USE tempdb
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID('[dbo].[read_sql_error_logs]',N'P') IS NOT NULL
    DROP PROCEDURE [dbo].[read_sql_error_logs]
GO
CREATE PROCEDURE [dbo].[read_sql_error_logs]
 @DT DATETIME
,@Ignore_Logins TINYINT = 1  -- Ignore any Logon type events

AS

SET NOCOUNT ON ;

DECLARE @x INT, @Total INT ;
SET @x = 1 ;

CREATE TABLE #Elogs ([Archive #] VARCHAR(10), [Date] VARCHAR(20), [Log File Size (Byte)] VARCHAR(20)) ;

CREATE TABLE [dbo].[#ErrorLogs] ([LogDate] DATETIME NULL, [ProcessInfo] VARCHAR(20) NULL, [Text] VARCHAR(MAX) NULL ) ;

--  Get the names of the SQL Error logs
INSERT INTO #Elogs ([Archive #], [Date], [Log File Size (Byte)]) EXEC master..sp_enumerrorlogs 1;
SET @Total = @@ROWCOUNT ;
 
--    Add code to decide from sp_enumerrorlogs which logs are dated outside our range and ignore them.
INSERT INTO #ErrorLogs ([LogDate], [ProcessInfo], [Text]) EXEC [master].[dbo].[sp_readerrorlog] 0, 1;

--  Loop through the rest of the error logs and get all the info
WHILE @x < @Total
BEGIN

    INSERT INTO #ErrorLogs ([LogDate], [ProcessInfo], [Text]) EXEC [master].[dbo].[sp_readerrorlog] @x, 1 ;

    IF @@ROWCOUNT = 0
        BREAK ;

    --  If the log is past when we read from the last time stop here
    IF EXISTS (SELECT * FROM #ErrorLogs
                            WHERE [LogDate] < @DT) 
        BREAK ;

    SET @x = @x + 1 ;

END ;

DELETE FROM #ErrorLogs WHERE [LogDate] IS NULL OR [LogDate] < @DT ;

--  Remove mundane log entries
DELETE FROM #ErrorLogs 
    WHERE ([ProcessInfo] = 'Backup' AND [Text] LIKE '%backed up%') OR
            ([Text] LIKE '%DBCC TRACE%208%') OR ([TEXT] = '') OR ([TEXT] LIKE '-----------%');

IF @Ignore_Logins = 1
    DELETE FROM #ErrorLogs 
        WHERE ([ProcessInfo] = 'Logon') ;  

SELECT [ProcessInfo] AS [Source], [Text] AS [ErrorText], [LogDate] AS [DateAdded] 
    FROM #ErrorLogs 
        ORDER BY [DateAdded] ;

GO


EXEC [dbo].[read_sql_error_logs] @DT = '20090101', @Ignore_Logins = 0



