 
USE tempdb
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID('[dbo].[read_agent_error_logs]',N'P') IS NOT NULL
    DROP PROCEDURE [dbo].[read_agent_error_logs]
GO
CREATE PROCEDURE [dbo].[read_agent_error_logs]
 @DT DATETIME

AS

SET NOCOUNT ON ;

DECLARE @x INT, @Total INT ;
SET @x = 1 ;

CREATE TABLE #Elogs ([Archive #] VARCHAR(10), [Date] VARCHAR(20), [Log File Size (Byte)] VARCHAR(20)) ;

CREATE TABLE [dbo].[#ErrorLogs] ([LogDate] DATETIME NULL, [ErrorLevel] VARCHAR(20) NULL, [Text] VARCHAR(MAX) NULL ) ;

--  Get the names of the SQL Agent logs
INSERT INTO #Elogs ([Archive #], [Date], [Log File Size (Byte)]) EXEC master..sp_enumerrorlogs 2 ;
SET @Total = @@ROWCOUNT ;
 
--    Add code to decide from sp_enumerrorlogs which logs are dated outside our range and ignore them.
INSERT INTO #ErrorLogs ([LogDate], [ErrorLevel], [Text]) EXEC [master].[dbo].[sp_readerrorlog] 0, 2 ;

--  Loop through the rest of the error logs and get all the info
WHILE @x < @Total
BEGIN

    INSERT INTO #ErrorLogs ([LogDate], [ErrorLevel], [Text]) EXEC [master].[dbo].[sp_readerrorlog] @x ;

    IF @@ROWCOUNT = 0
        BREAK ;

    --  If the log is past when we read from the last time stop here
    IF EXISTS (SELECT * FROM #ErrorLogs
                            WHERE [LogDate] < @DT) 
        BREAK ;

    SET @x = @x + 1 ;

END ;

DELETE FROM #ErrorLogs WHERE [LogDate] IS NULL OR [LogDate] < @DT ;

--  Remove mundane log entries
----DELETE FROM #ErrorLogs 
----    WHERE ([ErrorLevel] = 3 ;
    
SELECT [ErrorLevel], [Text] AS [ErrorText], [LogDate] AS [DateAdded] 
    FROM #ErrorLogs 
        ORDER BY [DateAdded] ;

GO


EXEC [dbo].[read_agent_error_logs] @DT = '20090101'




