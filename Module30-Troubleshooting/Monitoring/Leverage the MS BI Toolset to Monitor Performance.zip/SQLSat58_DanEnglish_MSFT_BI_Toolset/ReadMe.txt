
SQL Saturday 58 Minnesota - Leveraging the Microsoft BI Toolset to Monitor Performance 10/29/2010

Don't forget to verify all data source connections and PPS web service URL references if
you are going to try and reuse any of these samples.


Database info:

used the Adventure Works 2008 samples 
http://msftdbprodsamples.codeplex.com/releases/view/37109

The name I gave my SSAS database when I deployed it was 'Adventure Works 2008'


SSRS:

I used Report Builder 2.0 to create both reports. I created a line chart for the sparkline and simply
removed the chart title, legend, X and Y axis names, and removed displaying the X and Y axis on the chart.
I then simply placed the sales metric in the data and the fiscal year on the category and drag and
dropped this into a additional column I added outside of the fiscal year column group.


Excel:

1) Don't forget to setup the cells for the filters as Defined Names to be able to use as Parameters
when deployed to SharePoint.  These will then be used as endpoints when linking up the filters
in the dashboard.  Only select a single value before deploying, otherwise it will not show up
in the Dashboard Designer when you reference the Excel Services file.  More info can be found here:

http://denglishbi.wordpress.com/2010/01/24/using-excel-services-reports-with-performancepoint-server-pps/


2) I use Conditional Formatting for the Heat Map and Data Bar visualizations in the PivotTable


Dashboard:

1) for my Order Quantity Target I used the following MDX forumla:

Case
    When IsEmpty
         (
           ParallelPeriod
           (
             
[Date].[Fiscal].[Fiscal Year],
             1,
             
[Date].[Fiscal].CurrentMember
           )
         )
    
Then [Measures].[Order Quantity]              
    
Else 1.15 *
         ( 
           [Measures].[Order Quantity],
           
ParallelPeriod
           (
             [Date].[Fiscal].[Fiscal Year],
             
1,
             [Date].[Fiscal].CurrentMember
           )
         )
End

2) in the Properties for each of the KPIs I created I added a custom property called 'MeasureName' and
    this is what I use to link to the Analytical Chart to swap out the measure being displayed.

3) the link to the SSRS matrix report uses the Display Name instead of Member UniqueName and that is
   because it is a relational database, not a multi-dimensional database report. 

4) I have also included the dashboard.master page that I use which simply has the left hand navigation
   section commented out to provide more space for viewing but still keepts the top site navigation.
