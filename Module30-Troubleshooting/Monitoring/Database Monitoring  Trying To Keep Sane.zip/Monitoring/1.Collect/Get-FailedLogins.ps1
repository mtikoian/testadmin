
function FuncMail {
    param( $To, $From, $Subject, $Body, $smtpServer)
    $msg = new-object Net.Mail.MailMessage
    $smtp = new-object Net.Mail.SmtpClient($smtpServer)
    #$smtp.UseDefaultCredentials = 1
    #$smtp.EnableSsl = 1
    
    $smtp.UseDefaultCredentials = $true
 
    $msg.From = $From
    $msg.To.Add( $To)
    $msg.Subject = $Subject
    $msg.IsBodyHtml = 1
    $msg.body = $Body
    $smtp.Send($msg)
}




function AlertOnFailedLogins {
  #param( $ServerName )
  
  $ToEmail = "tjay.belt@ImagineLearning.com"
  $FromEmail = "DBMGR1@ImagineLearning.com"
  $SMTPServer = "smtp.smtp.com"
  $Subject = "Failed Logins Detected"
                  
  $a = "<style>"
  $a = $a + "BODY{}"
  $a = $a + "TABLE{border-width: 1px;border-style: solid;border-color: black;border-collapse: collapse;}"
  $a = $a + "TH{border-width: 1px;padding: 0px;border-style: solid;border-color: black;}"
  $a = $a + "TD{border-width: 1px;padding: 0px;border-style: solid;border-color: black;}"
  $a = $a + "</style>"  

  $GetData=invoke-sqlcmd -query "select count(*) as [Count] from FailedLoginsHistory where [Date] >= convert( [date], GetDate())" -ServerInstance $DESTINATION -database $DESTINATIONDB
  
  if ($GetData.Count -gt 0)
  {
    [int]$Count = $GetData.Count
  
    $SqlConnection = 
    $SqlConnection = New-Object System.Data.SqlClient.SqlConnection
    $SqlConnection.ConnectionString = "Server=$DBMGR1;Database=$DESTINATIONDB;Integrated Security=True"
   
    $SqlCmd = New-Object System.Data.SqlClient.SqlCommand
    $SqlCmd.Connection = $SqlConnection
    $SqlCmd.CommandTimeout = 0
    $SqlCmd.Connection.Open()
   
    $SqlCmd.CommandText = "exec DatabaseMonitoring.dbo.spFailedLoginsHistory"
                           
    $SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
    $SqlAdapter.SelectCommand = $SqlCmd
    $DataSet = New-Object System.Data.DataSet
    $SqlAdapter.Fill($DataSet)
    $Data = $DataSet.Tables[0] | select Date,ServerName,LogDate,ProcessInfo,Text | convertto-html -head $a
    $Body = "$Count failed Logins were collected from the SQL Server Error Logs.<br>
             This occurred via a Powershell job executed on DBMGR1<br><br>
             Please investigate these and determine a course of action<br><br><br>
             $Data<br><br><br><br>
             &nbsp;&nbsp;--Run these on DBMGR1.PROD.LOCAL to get more information<br>
             &nbsp;&nbsp;exec DatabaseMonitoring.dbo.spFailedLoginsHistory<br><br>
             &nbsp;&nbsp;exec DatabaseMonitoring.dbo.spFailedLoginsHistoryDetail<br><br><br><br>"

  
    FuncMail `
      -To $ToEmail `
      -From $FromEmail  `
      -Subject $Subject `
      -Body $Body `
      -smtpServer $SMTPServer
  }

}

$DESTINATION = "DBMGR1"
$DESTINATIONDB = "DATABASEMONITORING"
$DESTINATIONTABLE = "FailedLogins"


$DBServerName = 'DB1.PROD.LOCAL'
$GetData=invoke-sqlcmd -query "EXEC sp_readerrorlog 0, 1, 'Login failed'" -ServerInstance DB1.PROD.LOCAL -database MASTER
Write-DataTable -ServerInstance $DESTINATION -Database $DESTINATIONDB -TableName $DESTINATIONTABLE -Data $GetData
invoke-sqlcmd -query "exec spProcessFailedLogins '$DBServerName'" -ServerInstance $DESTINATION -database $DESTINATIONDB 

$DBServerName = 'DB2.PROD.LOCAL'
$GetData=invoke-sqlcmd -query "EXEC sp_readerrorlog 0, 1, 'Login failed'" -ServerInstance DB2.PROD.LOCAL -database MASTER
Write-DataTable -ServerInstance $DESTINATION -Database $DESTINATIONDB -TableName $DESTINATIONTABLE -Data $GetData
invoke-sqlcmd -query "exec spProcessFailedLogins '$DBServerName'" -ServerInstance $DESTINATION -database $DESTINATIONDB 

$DBServerName = 'DBMGR1.PROD.LOCAL'
$GetData=invoke-sqlcmd -query "EXEC sp_readerrorlog 0, 1, 'Login failed'" -ServerInstance DB2.PROD.LOCAL -database MASTER
Write-DataTable -ServerInstance $DESTINATION -Database $DESTINATIONDB -TableName $DESTINATIONTABLE -Data $GetData
invoke-sqlcmd -query "exec spProcessFailedLogins '$DBServerName'" -ServerInstance $DESTINATION -database $DESTINATIONDB 


AlertOnFailedLogins

