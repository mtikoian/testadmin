cd "C:\Users\tjay.belt.ILPROD\Documents\WindowsPowerShell\PoSh\Load"
. ./Get-DataUnits.ps1


Get-DataUnits 