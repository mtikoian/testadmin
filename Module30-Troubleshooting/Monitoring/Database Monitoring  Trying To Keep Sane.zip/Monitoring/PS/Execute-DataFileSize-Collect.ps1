cd "C:\Users\tjay.belt.ILPROD\Documents\WindowsPowerShell\PoSh\Load"
. ./Write-DataTable.ps1


$DESTINATION="Report"

$ArchiveData=invoke-sqlcmd -query "INSERT INTO DatabaseSizesHistory SELECT * FROM DatabaseSizes; TRUNCATE TABLE DatabaseSizes

" -ServerInstance REPORT -database DATABASEMONITORING 

$GetData=invoke-sqlcmd -query "EXEC sp_GetDatabaseSizesWithResults" -ServerInstance COLLECTION -database MASTER
Write-DataTable -ServerInstance $DESTINATION -Database DATABASEMONITORING -TableName DatabaseSizes -Data $GetData
$UpdateDate=invoke-sqlcmd -query "update DATABASEMONITORING.dbo.DatabaseSizes
  set [Datetime] = GetDate()
  where ServerName = 'COLLECTION'" -ServerInstance Report -database DATABASEMONITORING

$GetData2=invoke-sqlcmd -query "exec sp_GetDatabaseSizesWithResults" -ServerInstance REPORT -database MASTER
Write-DataTable -ServerInstance $DESTINATION -Database DATABASEMONITORING -TableName DatabaseSizes -Data $GetData2
$UpdateDate2=invoke-sqlcmd -query "update DATABASEMONITORING.dbo.DatabaseSizes
  set [Datetime] = GetDate()
  where ServerName = 'REPORT'" -ServerInstance Report -database DATABASEMONITORING

#------------------------------------------------------------------------------------------------------------------------------------------------------------------------

