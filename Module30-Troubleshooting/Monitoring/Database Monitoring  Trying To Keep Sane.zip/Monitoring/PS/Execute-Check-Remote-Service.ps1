Import-Module SQLServer
import-module SQLPS

cd C:\Users\tjay.belt\Documents\WindowsPowerShell\PoSh\Load
. ./Check-Remote-Service.ps1


$computer = Get-WmiObject -Class Win32_ComputerSystem
if ( $computer.domain -eq "imaginelearning.local")
{
  Check-Remote-Service il1dbmgr1 "MonitorBaseDeploymentServiceLocal"
}
else 
{
  Check-Remote-Service SDP "Imagine Data Collection Service" -RestartService $True
  Check-Remote-Service SDP "ImagineDataCollectionCumulative" -RestartService $True
  Check-Remote-Service ELP "Imagine Error Log Service" -RestartService $True
}



