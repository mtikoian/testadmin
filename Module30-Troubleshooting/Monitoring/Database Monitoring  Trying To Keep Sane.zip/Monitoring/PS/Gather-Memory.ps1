###################################################################################################
###      THIS TASKS IS PERFORMED FROM SQL JOB WITH INDIVIDUAL STEPS. NOT FROM THIS SCRIPT
###################################################################################################



import-module sqlps 

cd c:\WindowsPowerShell\PoSh\Load
. ./Write-DataTable.ps1

$DESTINATION = "REPORT"
$DESTINATION = "VOO1DBMGR1"
$DESTINATIONDB = "DATABASEMONITORING"
$DESTINATIONTABLE = "GatherMemory"


<#
$GetData=invoke-sqlcmd -query "EXEC sp_GatherMemory" -ServerInstance COLLECTION -database MASTER
Write-DataTable -ServerInstance $DESTINATION -Database $DESTINATIONDB -TableName $DESTINATIONTABLE -Data $GetData

$GetData=invoke-sqlcmd -query "EXEC sp_GatherMemory" -ServerInstance REPORT -database MASTER
Write-DataTable -ServerInstance $DESTINATION -Database $DESTINATIONDB -TableName $DESTINATIONTABLE -Data $GetData
#>

$GetData=invoke-sqlcmd -query "EXEC sp_GatherMemory" -ServerInstance SALES-DEV -database MASTER
Write-DataTable -ServerInstance $DESTINATION -Database $DESTINATIONDB -TableName $DESTINATIONTABLE -Data $GetData


$GetData=invoke-sqlcmd -query "EXEC sp_GatherMemory" -ServerInstance VOO1DB1.ILPROD.LOCAL -database MASTER
Write-DataTable -ServerInstance $DESTINATION -Database $DESTINATIONDB -TableName $DESTINATIONTABLE -Data $GetData

$GetData=invoke-sqlcmd -query "EXEC sp_GatherMemory" -ServerInstance VOO1DB2.ILPROD.LOCAL -database MASTER
Write-DataTable -ServerInstance $DESTINATION -Database $DESTINATIONDB -TableName $DESTINATIONTABLE -Data $GetData



