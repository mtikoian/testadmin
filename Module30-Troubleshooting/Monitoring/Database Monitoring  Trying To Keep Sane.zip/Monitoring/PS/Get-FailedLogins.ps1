
import-module sqlps 

cd c:\WindowsPowerShell\PoSh\Load
. ./Write-DataTable.ps1

function FuncMail {
    param( $To, $From, $Subject, $Body, $smtpServer)
    $msg = new-object Net.Mail.MailMessage
    $smtp = new-object Net.Mail.SmtpClient($smtpServer)
    #$smtp.UseDefaultCredentials = 1
    #$smtp.EnableSsl = 1
    
    $smtp.UseDefaultCredentials = $true
 
    $msg.From = $From
    $msg.To.Add( $To)
    $msg.Subject = $Subject
    $msg.IsBodyHtml = 1
    $msg.body = $Body
    $smtp.Send($msg)
}




function AlertOnFailedLogins {
  param( $ServerName )
  
  $ToEmail = "DBAlerts@ImagineLearning.com"
  #$ToEmail = "tjay.belt@ImagineLearning.com"
  $FromEmail = "VOO1DBMGR1@ImagineLearning.com"
  $SMTPServer = "smtp.voonami.com"
  $Subject = "Failed Logins Detected on $ServerName"
  
  $GetData=invoke-sqlcmd -query "select count(*) as [Count] from FailedLoginsHistory where [Date] >= convert( [date], GetDate()) and ServerName = '$ServerName'" -ServerInstance $DESTINATION -database $DESTINATIONDB
  
  if ($GetData.Count -gt 0)
  {
    [int]$Count = $GetData.Count
    $Body = "$Count failed Logins were collected from the Error Log on server $ServerName.<br>
               This occurred via a Powershell job executed on VOO1DBMGR1<br><br>
               Please investigate these and determine a course of action<br><br><br>
               &nbsp;&nbsp;--Run this on VOO1DBMGR1.ILPROD.LOCAL<br>
               &nbsp;&nbsp;select * <br>
               &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;from DatabaseMonitoring.dbo.FailedLoginsHistory <br>
               &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;where [Date] >= convert( [date], GetDate()) <br>
               &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ORDER BY LogDate desc<br>
		<br><br><br><br>
               &nbsp;&nbsp;  --Run this on VOO1DBMGR1.ILPROD.LOCAL<br>
               &nbsp;&nbsp;DECLARE @Client TABLE ( [Client] VARCHAR(25), [DESCRIPTION] VARCHAR(255))<br>
               &nbsp;&nbsp;INSERT INTO @Client VALUES ( '10.10.100.44', 'Sales-Dev')<br>
               &nbsp;&nbsp;INSERT INTO @Client VALUES ( '10.10.101.38', 'il2tfs')<br>
               &nbsp;&nbsp;INSERT INTO @Client VALUES ( '10.10.104.55', 'gibby')<br>
               &nbsp;&nbsp;INSERT INTO @Client VALUES ( '10.10.2.15', 'davidv-2010a');<br>
               &nbsp;&nbsp;<br>
               &nbsp;&nbsp;WITH cteData ( [Count], [Client])<br>
               &nbsp;&nbsp;AS(  <br>
               &nbsp;&nbsp;&nbsp;&nbsp;SELECT<br>
               &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;COUNT(*) AS [Count] ,<br>
               &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;LTRIM(REPLACE(SUBSTRING(Text,CHARINDEX('client',Text)+7,15),']','')) AS [Client]<br>
               &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;from DatabaseMonitoring.dbo.FailedLoginsHistory <br>
               &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;where [Date] > DATEADD(day,-4,convert( [date], GetDate()) )<br>
               &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;GROUP BY LTRIM(REPLACE(SUBSTRING(Text,CHARINDEX('client',Text)+7,15),']',''))<br>
               &nbsp;&nbsp;&nbsp;&nbsp;)<br>
               &nbsp;&nbsp;<br>
               &nbsp;&nbsp;SELECT <br>
               &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;d.[Count],<br>
               &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;d.[Client],<br>
               &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;c.[Description]<br>
               &nbsp;&nbsp;&nbsp;&nbsp;FROM cteData d  <br>
               &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;LEFT OUTER JOIN @Client c ON c.[Client] = d.[Client]
	    "
  
    FuncMail `
      -To $ToEmail `
      -From $FromEmail  `
      -Subject $Subject `
      -Body $Body `
      -smtpServer $SMTPServer
  }

}

$DESTINATION = "VOO1DBMGR1"
$DESTINATIONDB = "DATABASEMONITORING"
$DESTINATIONTABLE = "FailedLogins"

<#
$DBServerName = 'Sales-Dev'
$GetData=invoke-sqlcmd -query "EXEC sp_readerrorlog 0, 1, 'Login failed'" -ServerInstance SALES-DEV -database MASTER
Write-DataTable -ServerInstance $DESTINATION -Database $DESTINATIONDB -TableName $DESTINATIONTABLE -Data $GetData
invoke-sqlcmd -query "exec spProcessFailedLogins 'Sales-Dev'" -ServerInstance $DESTINATION -database $DESTINATIONDB 
#>


$DBServerName = 'VOO1DB1.ILPROD.LOCAL'
$GetData=invoke-sqlcmd -query "EXEC sp_readerrorlog 0, 1, 'Login failed'" -ServerInstance VOO1DB1.ILPROD.LOCAL -database MASTER
Write-DataTable -ServerInstance $DESTINATION -Database $DESTINATIONDB -TableName $DESTINATIONTABLE -Data $GetData
invoke-sqlcmd -query "exec spProcessFailedLogins '$DBServerName'" -ServerInstance $DESTINATION -database $DESTINATIONDB 
AlertOnFailedLogins -ServerName $DBServerName

$DBServerName = 'VOO1DB2.ILPROD.LOCAL'
$GetData=invoke-sqlcmd -query "EXEC sp_readerrorlog 0, 1, 'Login failed'" -ServerInstance VOO1DB2.ILPROD.LOCAL -database MASTER
Write-DataTable -ServerInstance $DESTINATION -Database $DESTINATIONDB -TableName $DESTINATIONTABLE -Data $GetData
invoke-sqlcmd -query "exec spProcessFailedLogins '$DBServerName'" -ServerInstance $DESTINATION -database $DESTINATIONDB 
AlertOnFailedLogins -ServerName $DBServerName

$DBServerName = 'VOO1DBMGR1.ILPROD.LOCAL'
$GetData=invoke-sqlcmd -query "EXEC sp_readerrorlog 0, 1, 'Login failed'" -ServerInstance VOO1DB2.ILPROD.LOCAL -database MASTER
Write-DataTable -ServerInstance $DESTINATION -Database $DESTINATIONDB -TableName $DESTINATIONTABLE -Data $GetData
invoke-sqlcmd -query "exec spProcessFailedLogins '$DBServerName'" -ServerInstance $DESTINATION -database $DESTINATIONDB 
AlertOnFailedLogins -ServerName $DBServerName




<#

$DBServerName = 'VOO1DB1.ILPROD.LOCAL'
AlertOnFailedLogins -ServerName $DBServerName

$DBServerName = 'VOO1DB2.ILPROD.LOCAL'
AlertOnFailedLogins -ServerName $DBServerName

$DBServerName = 'VOO1DBMGR1.ILPROD.LOCAL'
AlertOnFailedLogins -ServerName $DBServerName

#>
