
$DESTINATION="VOO1DBMGR1"
$DESTINATIONDB="DATABASEMONITORING"
 
  $allfiles = (Get-ChildItem \\sdp\ProcessedDataUnits$ -recurse -filter "*.zip")
  $Count  = ($allfiles).Count
  $Size   = ($allfiles | Measure-Object -property length -sum).sum / 1MB
  $oldest = ($allfiles | sort lastwritetime | Select -first 1).LastWriteTime
  $newest = ($allfiles | sort lastwritetime | Select -last 1).LastWriteTime

  if ( $Count -eq $null )
  {
    $Count = 0
  }

  $query = "insert into ProcessedDataUnits ( [Count],[Size],[Oldest],[Newest] ) values ( " + $Count + ", '" + $Size + "', '" + $Oldest + "', '" + $Newest + "') " 
  invoke-sqlcmd -query $query -ServerInstance $DESTINATION -database $DESTINATIONDB


