import-module sqlps 


$DESTINATION = "REPORT"
$DESTINATION = "VOO1DBMGR1"

$DESTINATIONDB = "DATABASEMONITORING"




function FuncMail {
    param( $To, $From, $Subject, $Body, $smtpServer)
    $msg = new-object Net.Mail.MailMessage
    $smtp = new-object Net.Mail.SmtpClient($smtpServer)
    #$smtp.UseDefaultCredentials = 1
    #$smtp.EnableSsl = 1
    
    $smtp.UseDefaultCredentials = $true
 
    $msg.From = $From
    $msg.To.Add( $To)
    $msg.Subject = $Subject
    $msg.IsBodyHtml = 1
    $msg.body = $Body
    $smtp.Send($msg)
}



Function Check-Remote-Service
{ 
  param
  ( 
    [string]$ServerName, 
    [string]$ServiceName, 
    [bool]$PositiveConfirmation,
    [bool]$RestartService = $False,
    [string]$ToEmail = "DBAlerts@ImagineLearning.com",
    [string]$FromEmail = "ServiceAlerts@ImagineLearning.com"
  )

  $serviceArray = Get-WmiObject `
                    -class Win32_Service `
                    -computerName $servername `
                    -filter "name = '$ServiceName'"

  [switch]$VisualConfirmation = $True
  [switch]$SendEmail = $False


  foreach ($Service in $serviceArray ) 
  {

    #### Gather the Status of the service
    [string]$State = $Service.State
    if ($State -ne "Running")
    {
      [string]$Status = "is not running"
    }
    else 
    {
      [string]$Status = "is running"
    }


    #### Collect PositiveConfirmation
    if ( $PositiveConfirmation -eq $True)
    {
        $SendEmail = $True
    }
    else
    { 
      if ($State -ne "Running")
      {
        $SendEmail = $True
      }
      else
      {
        $SendEmail = $False
      }
    }

    #### Collect VisialConfirmation
    [switch]$VisualConfirmation = $True


    #### 
    #### Perform Whichever operation is needed
    #### 


    #### Load this information into the Historical Database
    $query = "insert into CheckServiceResults ( [ServerName], [ServiceName], [Status] ) values ( '" + $ServerName + "', '" + $ServiceName + "', '" + $Status + "') " 
    invoke-sqlcmd -query $query -ServerInstance $DESTINATION -database $DESTINATIONDB


    #### Gather values for Email
    $Subject = "Server ($ServerName) : Service ($ServiceName) : Status ($Status)"
    $Body =    "Server ($ServerName) <br>Service ($ServiceName) <br>Status ($Status)"


    #### Check if its this domain, or that, and change SMTP server appropriately
    $computer = Get-WmiObject -Class Win32_ComputerSystem
    if ( $computer.domain -eq "imaginelearning.local")
    {
      $SMTPServer = "mail.imaginelearning.local"
    }
    else 
    {
      $SMTPServer = "smtp.voonami.com"
    }


    #### Send Email
    if ( $SendEmail -eq $True)
    {

      FuncMail `
        -To $ToEmail `
        -From $FromEmail  `
        -Subject $Subject `
        -Body $Body `
        -smtpServer $SMTPServer
    }

    #### Restart Service ?
    if ( ($RestartService -eq $True) -and ($State -ne "Running") )
    { 
  
      try 
      { 
        $myservice = Get-WmiObject -Class Win32_Service -ComputerName $ServerName -Filter "name = '$ServiceName'" #-Credential $credential 
        $myservice.startservice()  
      } 
      catch 
      { 
          $ex = $_.Exception 
          Write-Error ""$ex.Message"" 
          continue 
      } 

      #### Insert this action into our history table
      $query = "insert into CheckServiceResults ( [ServerName], [ServiceName], [Status] ) values ( '" + $ServerName + "', '" + $ServiceName + "', 'Restarted') " 
      invoke-sqlcmd -query $query -ServerInstance $DESTINATION -database $DESTINATIONDB

      #### Gather values for Email
      $Subject = "Server ($ServerName) : Service ($ServiceName) : Restarted"
      $Body =    "Server ($ServerName) <br>Service ($ServiceName) <br>Restarted"

      FuncMail `
        -To $ToEmail `
        -From $FromEmail  `
        -Subject $Subject `
        -Body $Body `
        -smtpServer $SMTPServer

    }


    #### Visually Display Status
    if ( $VisualConfirmation -eq $True)
    {
      $Subject 
    }

    " "
    " "

  }
  
} 
