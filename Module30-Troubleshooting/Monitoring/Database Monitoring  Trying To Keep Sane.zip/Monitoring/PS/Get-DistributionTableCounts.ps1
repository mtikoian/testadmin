

import-module sqlps 

cd c:\WindowsPowerShell\PoSh\Load
. ./Write-DataTable.ps1

$DESTINATION = "REPORT"
$DESTINATION = "VOO1DBMGR1"
$DESTINATIONDB = "DATABASEMONITORING"
$DESTINATIONTABLE = "DistributionTableCounts"
$Query = "SELECT 
	      o.name AS [Name],
	      i.rowcnt AS [Count]
	    FROM distribution.dbo.sysobjects o
	      JOIN distribution.dbo.sysindexes i ON i.id = o.id AND indid IN(0,1)
	    WHERE xtype = 'u'
	      and o.name IN ( 'MSrepl_commands','MSrepl_transactions','MSdistribution_history','MSlogreader_history','MSrepl_errors')
	    order by i.rowcnt desc"

$GetData=invoke-sqlcmd -query $Query -ServerInstance COLLECTION -database distribution
Write-DataTable -ServerInstance $DESTINATION -Database $DESTINATIONDB -TableName $DESTINATIONTABLE -Data $GetData

