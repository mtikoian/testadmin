
-- parameterization

-- autoparameterization
SELECT * FROM Person.Address
WHERE AddressID = 12

SELECT * FROM Person.Address
WHERE AddressID = 37

-- not parameterized, not safe
-- gets a table scan
SELECT * FROM Person.Address
WHERE StateProvinceID = 79

-- gets an index seek
SELECT * FROM Person.Address
WHERE StateProvinceID = 59

-- forced parameterization
ALTER DATABASE AdventureWorks SET PARAMETERIZATION FORCED
ALTER DATABASE AdventureWorks SET PARAMETERIZATION SIMPLE

DBCC FREEPROCCACHE;

-- taken from Kalen Delaney's Internals book
-- shell queries do not contain the full execution plan
-- but only a pointer to the full plan
SELECT usecounts, cacheobjtype, objtype, [text]
FROM sys.dm_exec_cached_plans P
CROSS APPLY sys.dm_exec_sql_text (plan_handle)
WHERE cacheobjtype = 'Compiled Plan'
AND [text] NOT LIKE '%dm_exec_cached_plans%';

-- stored procedures
CREATE PROCEDURE test (@pid int)
AS
SELECT * FROM Sales.SalesOrderDetail
WHERE ProductID = @pid


