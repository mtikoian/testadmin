
-- parameter sniffing demo

CREATE PROCEDURE test (@pid int)
AS
SELECT * FROM Sales.SalesOrderDetail
WHERE ProductID = @pid

-- uneven data distribution
SELECT ProductID, COUNT(*) AS cnt FROM Sales.SalesOrderDetail
GROUP BY ProductID
ORDER BY cnt

-- uses index seek-key lookup
EXEC test @pid = 898

-- show EQ_ROWS 9
DBCC SHOW_STATISTICS('Sales.SalesOrderDetail', IX_SalesOrderDetail_ProductID)

SET STATISTICS IO ON
GO
EXEC test @pid = 870
GO

-- logical reads 14075
-- table has only 1,245 pages!

SELECT * FROM sys.dm_db_partition_stats
WHERE object_id = object_id('Sales.SalesOrderDetail')

-- see the best plan for this parameter
DBCC FREEPROCCACHE
GO
EXEC test @pid = 870
GO
-- show logical reads 1241

-- show EQ_ROWS 4688
DBCC SHOW_STATISTICS('Sales.SalesOrderDetail', IX_SalesOrderDetail_ProductID)

DBCC FREEPROCCACHE

-- 1. Optimize for a typical parameter
-- you control the plan on memory
-- avoid optimizations
ALTER PROCEDURE test (@pid int)
AS
SELECT * FROM Sales.SalesOrderDetail
WHERE ProductID = @pid
OPTION (OPTIMIZE FOR (@pid = 898))

EXEC test @pid = 870

-- show XML

-- 2. Optimize for every execution

ALTER PROCEDURE test (@pid int)
AS
SELECT * FROM Sales.SalesOrderDetail
WHERE ProductID = @pid
OPTION (RECOMPILE)

-- uses index seek-key lookup
EXEC test @pid = 898
-- uses table scan
EXEC test @pid = 870

-- removing parameter sniffing
-- Use local variables

ALTER PROCEDURE test (@pid int)
AS
DECLARE @p int = @pid
SELECT * FROM Sales.SalesOrderDetail
WHERE ProductID = @p

-- Use OPTIMIZE FOR UNKNOWN

ALTER PROCEDURE test (@pid int)
AS
SELECT * FROM Sales.SalesOrderDetail
WHERE ProductID = @pid
OPTION (OPTIMIZE FOR UNKNOWN)

-- value does not matter
-- always uses the same plan
EXEC test @pid = 898

DBCC SHOW_STATISTICS('Sales.SalesOrderDetail', IX_SalesOrderDetail_ProductID)

-- it no longer uses the histogram
-- but density which estimates 456.079
select 121317 * 0.003759399
select 121317 / 266.0

-- how is density itself estimated
-- 1 / number of distinct values
select 1.0 / count(distinct(ProductID)) from  Sales.SalesOrderDetail

-- clean up

DROP PROCEDURE test

 



























