
USE	[AdventureWorks2012]
SET	STATISTICS IO ON
DBCC FREEPROCCACHE

--Lets look at parameter sniffing in general

ALTER	PROCEDURE	spGetPersonByType
	@PersonType		NCHAR(2)  -- Types IN (18484), EM(273), SP(17), SC(753), VC(156), GC(289)
AS
BEGIN
	SELECT	p.[FirstName],
			p.[LastName],
			p.[PersonType],
			e.[EmailAddress]
	FROM	[Person].[Person] p
			INNER JOIN [Person].[EmailAddress] e 
				ON e.[BusinessEntityID] = p.[BusinessEntityID]
	WHERE	p.[PersonType] = @PersonType
END

DBCC FREEPROCCACHE

EXEC	[dbo].[spGetPersonByType] @PersonType = N'sp' -- small return set 17 rows
-- Nested Loop Plan;    
--EmailAddress Scan Count 17, reads 34 ;    
--Person Scan Count 1, reads 3820

EXEC	[dbo].[spGetPersonByType] @PersonType = N'in' -- large return 18484 rows
-- EmailAddress Scan Count 18484,  37428 reads;   
-- Person  Scan Count 1, reads 3820-  


DBCC FREEPROCCACHE

EXEC	[dbo].[spGetPersonByType] @PersonType = N'in' 
--Merge Join Plan
-- EmailAddress Scan Count 1,  251 reads;   
-- Person  Scan Count 1, reads 3820-  

EXEC	[dbo].[spGetPersonByType] @PersonType = N'sp'
-- EmailAddress Scan Count 1,  6 reads;   
-- Person  Scan Count 1, reads 3820 

DBCC FREEPROCCACHE


----------Local Variable---------------

ALTER PROCEDURE spGetPersonByType
	@PersonType		NCHAR(2)  -- Types IN (18,484), EM(273), SP(17), SC(753), VC(156), GC(289)
AS
BEGIN
	DECLARE @Ptype	NCHAR(2)

	SET	@Ptype = @PersonType   -- This is is here to remove parameter sniffing.


	SELECT	p.[FirstName],
			p.[LastName],
			p.[PersonType],
			e.[EmailAddress]
	FROM	[Person].[Person] p
			INNER JOIN [Person].[EmailAddress] e ON e.[BusinessEntityID] = p.[BusinessEntityID]
	WHERE	p.[PersonType] = @Ptype
END

DBCC FREEPROCCACHE

EXEC	[dbo].[spGetPersonByType] @PersonType = N'in' 
--Merge Join Plan
-- EmailAddress Scan Count 1,  251 reads;   
-- Person  Scan Count 1, reads 3820 

EXEC	[dbo].[spGetPersonByType] @PersonType = N'sp' 
-- EmailAddress Scan Count 1,  6 reads;   
-- Person  Scan Count 1, reads 3820-





-- OPTIMIZE For UNKNOWN


ALTER 	PROCEDURE	spGetPersonByType
	@PersonType		NCHAR(2)  -- Types IN (18,484), EM(273), SP(17), SC(753), VC(156), GC(289)
AS
BEGIN
	SELECT	p.[FirstName],
			p.[LastName],
			p.[PersonType],
			e.[EmailAddress]
	FROM	[Person].[Person] p
			INNER JOIN [Person].[EmailAddress] e ON e.[BusinessEntityID] = p.[BusinessEntityID]
	WHERE	p.[PersonType] = @PersonType 
			OPTION (OPTIMIZE FOR (@PersonType UNKNOWN))
END

DBCC FREEPROCCACHE

EXEC	[dbo].[spGetPersonByType] @PersonType = N'in' 
--Merge Join Plan
-- EmailAddress Scan Count 1,  251 reads;   
-- Person  Scan Count 1, reads 3820 

EXEC	[dbo].[spGetPersonByType] @PersonType = N'sp' 
-- EmailAddress Scan Count 1,  6 reads;   
-- Person  Scan Count 1, reads 3820-




---   OPTIMIZE <VALUE>-----------------------------------------------

ALTER 	PROCEDURE	spGetPersonByType
	@PersonType		NCHAR(2)  -- Types IN (18,484), EM(273), SP(17), SC(753), VC(156), GC(289)
AS
BEGIN
	SELECT	p.[FirstName],
			p.[LastName],
			p.[PersonType],
			e.[EmailAddress]
	FROM	[Person].[Person] p
			INNER JOIN [Person].[EmailAddress] e ON e.[BusinessEntityID] = p.[BusinessEntityID]
	WHERE	p.[PersonType] = @PersonType 
			OPTION (OPTIMIZE FOR (@PersonType = 'in'))
END

DBCC FREEPROCCACHE

EXEC	[dbo].[spGetPersonByType] @PersonType = N'sp'
--Merge Join Plan 
-- EmailAddress Scan Count 1,  6 reads;   
-- Person  Scan Count 1, reads 3820-

EXEC	[dbo].[spGetPersonByType] @PersonType = N'in' 
-- EmailAddress Scan Count 1,  251 reads;   
-- Person  Scan Count 1, reads 3820 







-- Option RECOMPILE --------------------------------

ALTER 	PROCEDURE	spGetPersonByType
	@PersonType		NCHAR(2)  -- Types IN (18,484), EM(273), SP(17), SC(753), VC(156), GC(289)
AS
BEGIN
	SELECT	p.[FirstName],
			p.[LastName],
			p.[PersonType],
			e.[EmailAddress]
	FROM	[Person].[Person] p
			INNER JOIN [Person].[EmailAddress] e ON e.[BusinessEntityID] = p.[BusinessEntityID]
	WHERE	p.[PersonType] = @PersonType 
			OPTION (RECOMPILE)
END

DBCC FREEPROCCACHE

EXEC	[dbo].[spGetPersonByType] @PersonType = N'in' 
--Merge Join Plan
-- EmailAddress Scan Count 1,  251 reads;   
-- Person  Scan Count 1, reads 3820 

EXEC	[dbo].[spGetPersonByType] @PersonType = N'sp'
-- Nested Loop Plan;    
--EmailAddress Scan Count 17, reads 34 ;    
--Person Scan Count 1, reads 3820






-- Plan Guides

ALTER 	PROCEDURE	spGetPersonByType
	@PersonType		NCHAR(2)  -- Types IN (18,484), EM(273), SP(17), SC(753), VC(156), GC(289)
AS
BEGIN
	SELECT	p.[FirstName],
			p.[LastName],
			p.[PersonType],
			e.[EmailAddress]
	FROM	[Person].[Person] p
			INNER JOIN [Person].[EmailAddress] e ON e.[BusinessEntityID] = p.[BusinessEntityID]
	WHERE	p.[PersonType] = @PersonType
END

EXEC sp_create_plan_guide 
@name = N'Sniff_Fix',
@stmt = N'SELECT	p.[FirstName],
			p.[LastName],
			p.[PersonType],
			e.[EmailAddress]
	FROM	[Person].[Person] p
			INNER JOIN [Person].[EmailAddress] e ON e.[BusinessEntityID] = p.[BusinessEntityID]
	WHERE	p.[PersonType] = @PersonType',
@type = N'OBJECT',
@module_or_batch = N'dbo.spGetPersonByType' ,
@params = NULL,
@hints = N'OPTION(OPTIMIZE FOR (@PersonType = ''in''))'


EXEC	[dbo].[spGetPersonByType] @PersonType = N'in'

EXEC	[dbo].[spGetPersonByType] @PersonType = N'sp'

select *
from sys.plan_guides

EXEC sp_control_plan_guide N'DROP ALL';