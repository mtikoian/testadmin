USE	[AdventureWorks2012]
SET STATISTICS IO ON
SET STATISTICS TIME ON


ALTER PROCEDURE	spGetFireHose
	@PersonType				NCHAR(2)  = NULL,
	@CountryRegionCode		NVARCHAR(3) = NULL,
	@StateProvinceID		INT	 = NULL

AS

SELECT	
		soh.SalesOrderID,
		soh.OrderDate,
		soh.ShipDate,
		soh.TotalDue,
		sod.OrderQty,
		sod.UnitPrice,
		sohsr.SalesReasonID,
		sr.Name AS [ReasonName],
		p.ProductID,
		p.Name AS [ProductName],
		pp.LargePhoto,
		ps.Name [ProductSubCatName],
		SUM(pri.Quantity) AS [Inventory],
		MIN(pch.StandardCost) AS [MinCost],
		MAX(pch.StandardCost) AS [MaxCost],
		pev.LastName +', '+pev.FirstName AS VendorName,
		cp.LastName +', ' + cp.FirstName AS CustomerName,
		pph.PhoneNumber AS CustomerPhone,
		a.AddressID,
		stp.StateProvinceID,
		cr.CountryRegionCode
FROM	Sales.SalesOrderHeader soh
		JOIN Sales.SalesOrderDetail sod on sod.SalesOrderID = soh.SalesOrderID
		join Sales.SalesOrderHeaderSalesReason sohsr on soh.SalesOrderID = sohsr.SalesOrderID
		join Sales.SalesReason sr on sr.SalesReasonID = sohsr.SalesReasonID
		join Production.Product p on sod.ProductID = p.ProductID
		join Production.ProductCostHistory pch on pch.ProductID =p.ProductID
		join Production.ProductProductPhoto ppp on ppp.ProductID = p.ProductID
		join Production.ProductPhoto pp on pp.ProductPhotoID = ppp.ProductPhotoID
		join Production.ProductSubcategory ps on ps.ProductSubcategoryID = p.ProductSubcategoryID
		join Production.ProductInventory pri on pri.ProductID = p.ProductID
		join Purchasing.ProductVendor pv on pv.ProductID = p.ProductID
		left outer join Person.Person pev on pev.BusinessEntityID = pv.BusinessEntityID
		join Sales.Customer c on c.CustomerID = soh.CustomerID
		join Person.Person cp on c.CustomerID = cp.BusinessEntityID
		join Person.BusinessEntityAddress bea on bea.BusinessEntityID = cp.BusinessEntityID
		join Person.Address a on a.AddressID = bea.AddressID
		join Person.StateProvince stp on a.StateProvinceID = stp.StateProvinceID
		join Person.CountryRegion cr on stp.CountryRegionCode = cr.CountryRegionCode
		join Person.PersonPhone pph on cp.BusinessEntityID = pph.BusinessEntityID
WHERE	(cp.PersonType = @PersonType or @PersonType IS NULL)
		AND (cr.CountryRegionCode = @CountryRegionCode or @CountryRegionCode IS NULL)
		AND (stp.StateProvinceID = @StateProvinceID OR @StateProvinceID IS NULL)
group by a.AddressID,
		stp.StateProvinceID,
		cr.CountryRegionCode,
		soh.SalesOrderID,
		soh.OrderDate,
		soh.ShipDate,
		sod.OrderQty,
		sod.UnitPrice,
		sohsr.SalesReasonID,
		soh.TotalDue,
		sr.Name ,
		p.ProductID,
		p.Name,
		pp.LargePhoto,
		ps.Name ,
		--pri.Quantity,
		pev.LastName,
		pev.FirstName,
		cp.LastName,
		 cp.FirstName,
		pph.PhoneNumber
GO



DBCC FREEPROCCACHE

EXEC spGetFireHose @PersonType = 'in', @CountryRegionCode = 'US', @StateProvinceID = 54
EXEC spGetFireHose @PersonType = 'in', @CountryRegionCode = 'US'
EXEC spGetFireHose @PersonType = 'in'



DBCC FREEPROCCACHE

EXEC spGetFireHose @PersonType = 'in'
EXEC spGetFireHose @PersonType = 'in', @CountryRegionCode = 'US'
EXEC spGetFireHose @PersonType = 'in', @CountryRegionCode = 'US', @StateProvinceID = 54


DBCC FREEPROCCACHE