
-- plans and SET options

CREATE DATABASE Test
GO

USE Test
GO

SELECT * 
INTO dbo.SalesOrderDetail
FROM AdventureWorks2012.Sales.SalesOrderDetail

DROP PROC test

CREATE PROCEDURE test (@pid int)
AS
SELECT * FROM dbo.SalesOrderDetail
WHERE ProductID = @pid

-- run app with 870

-- must be executed from the required database
SELECT plan_handle, usecounts, pvt.set_options
FROM (
    SELECT plan_handle, usecounts, epa.attribute, epa.value 
    FROM sys.dm_exec_cached_plans 
        OUTER APPLY sys.dm_exec_plan_attributes(plan_handle) AS epa
    WHERE cacheobjtype = 'Compiled Plan') AS ecpa 
PIVOT (MAX(ecpa.value) FOR ecpa.attribute IN ("set_options", "objectid")) AS pvt
where pvt.objectid = object_id('dbo.test');

-- suppose optimal plan uses index seek/key lookup
-- and table scan is a bad plan 
-- first app execution uses parameter 870
-- later app executions use parameter 898

-- SSMS uses parameter 898
EXEC test @pid = 898

sp_recompile test
-- show plan cache

-- sqlcmd
-- sqlcmd -d Test -Q "exec test @pid = 897"

-- obtain plan from the cache 
select * from sys.dm_exec_query_plan()

-- test for 251 and 4347
declare @set_options int = 251
if ((1 & @set_options) = 1) print 'ANSI_PADDING'
if ((4 & @set_options) = 4) print 'FORCEPLAN'
if ((8 & @set_options) = 8) print 'CONCAT_NULL_YIELDS_NULL'
if ((16 & @set_options) = 16) print 'ANSI_WARNINGS'
if ((32 & @set_options) = 32) print 'ANSI_NULLS'
if ((64 & @set_options) = 64) print 'QUOTED_IDENTIFIER'
if ((128 & @set_options) = 128) print 'ANSI_NULL_DFLT_ON'
if ((256 & @set_options) = 256) print 'ANSI_NULL_DFLT_OFF'
if ((512 & @set_options) = 512) print 'NoBrowseTable'
if ((4096 & @set_options) = 4096) print 'ARITH_ABORT'
if ((8192 & @set_options) = 8192) print 'NUMERIC_ROUNDABORT'
if ((16384 & @set_options) = 16384) print 'DATEFIRST'
if ((32768 & @set_options) = 32768) print 'DATEFORMAT'
if ((65536 & @set_options) = 65536) print 'LanguageID'

-- clean up
DROP PROCEDURE test












