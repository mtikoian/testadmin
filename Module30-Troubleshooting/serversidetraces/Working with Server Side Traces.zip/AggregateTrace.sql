USE ProcessTraceFiles;
GO

SET NOCOUNT ON;
GO

/*Put trace data into a temp table for processing.  TextData needs to be converted to a VARCHAR(max) before PATINDEX AND CHARINDEX can be used. */

SELECT [RowNumber] ,CAST([TextData]AS VARCHAR(MAX)) AS TextData
      ,[BinaryData] ,[DatabaseID],[TransactionID],[LineNumber],[NTUserName]
      ,[NTDomainName],[HostName],[ClientProcessID],[ApplicationName],[LoginName]
      ,[SPID] ,[Duration],[StartTime],[EndTime],[Reads],[Writes],[CPU],[Permissions]
      ,[Severity],[EventSubClass],[ObjectID],[Success],[IndexID],[IntegerData],[ServerName]
      ,[EventClass] ,[ObjectType] ,[NestLevel] ,[State] ,[Error],[Mode] ,[Handle]
      ,[ObjectName] ,[DatabaseName],[FileName],[OwnerName],[RoleName],[TargetUserName]
      ,[DBUserName] ,[LoginSid] ,[TargetLoginName] ,[TargetLoginSid],[ColumnPermissions]
      ,[LinkedServerName],[ProviderName],[MethodName],[RowCounts],[RequestID]
      ,[XactSequence],[EventSequence] ,[BigintData1] ,[BigintData2] ,[GUID] ,[IntegerData2]
      ,[ObjectID2],[Type],[OwnerID],[ParentName],[IsSystem],[Offset] ,[SourceDatabaseID]
      ,[SqlHandle] ,[SessionLoginName],[PlanHandle] ,[GroupID]
INTO #TestTable

 /* ---------------------------------------------------------
  
  Change the table name, the dbRevision, and the runNumber 
  
 --------------------------------------------------------- */

  FROM ManagerLoad_201108161527;
 
DECLARE @DBRevision AS SMALLINT = 10195
DECLARE @RunNumber AS SMALLINT = 3
/* --------------------------------------------------------- */


 
DECLARE @RunDate AS DATETIME
SELECT  @RunDate = MIN(StartTime)

FROM   #TestTable

/* Display Run information for reference */

PRINT @RunDate

/* Extract stored procedure calls */

INSERT  INTO AggregatedData
        ( [DBRevision] ,
          [RunDate] ,
          [PartialText] ,
          [Duration] ,
          [Reads] ,
          [Writes] ,
          [CPU] ,
		  [RowCounts],
          RunNumber 
        )
        SELECT  @DBRevision AS DBRevision ,
                @RunDate AS RunDate ,
                SUBSTRING(TextData, ( PATINDEX('%EXEC sp%', textData) ),
                          ( CHARINDEX(CHAR(32), TextData,
                                      ( PATINDEX('%EXEC sp%', textData) ) + 5) )
                          - ( PATINDEX('%EXEC sp%', textData) )) AS PartialText ,
                COALESCE(duration, 0) AS duration ,
                COALESCE(reads, 0) AS reads ,
                COALESCE(writes, 0) AS writes ,
                COALESCE(cpu, 0) AS cpu ,
				 COALESCE(RowCounts, 0) AS RowCounts ,
                @RunNumber AS DBRevision
        
        FROM    #TestTable

        WHERE   PATINDEX('%EXEC sp%', TextData) > 0
                AND EventClass IN ( 10, 12 )
               
                 
/* Extract BULK INSERTS and Adhoc SQL */

INSERT  INTO AggregatedData
        ( [DBRevision] ,
          [RunDate] ,
          [PartialText] ,
          [Duration] ,
          [Reads] ,
          [Writes] ,
          [CPU] ,
		  [RowCounts],
          RunNumber 
        )
        SELECT  @DBRevision AS DBRevision ,
                @RunDate AS RunDate ,
                 SUBSTRING(TextData, 0,100) AS PartialText ,
                COALESCE(duration, 0) AS duration ,
                COALESCE(reads, 0) AS reads ,
                COALESCE(writes, 0) AS writes ,
                COALESCE(cpu, 0) AS cpu ,
				COALESCE(RowCounts, 0) AS RowCounts ,
                @RunNumber AS DBRevision

        FROM    #TestTable
        WHERE   PATINDEX('%EXEC sp%', TextData) = 0
                AND EventClass IN ( 10, 12 )

/* Extract sp_executesql */

INSERT  INTO AggregatedData
        ( 
          [DBRevision] ,
          [RunDate] ,
          [PartialText] ,
          [Duration] ,
          [Reads] ,
          [Writes] ,
          [CPU] ,
		  [RowCounts],
          RunNumber 
        )
        SELECT   @DBRevision AS DBRevision ,
                @RunDate AS RunDate ,
                 SUBSTRING(TextData, 0,100) AS PartialText ,
                COALESCE(duration, 0) AS duration ,
                COALESCE(reads, 0) AS reads ,
                COALESCE(writes, 0) AS writes ,
                COALESCE(cpu, 0) AS cpu ,
				COALESCE(RowCounts, 0) AS RowCounts ,
                @RunNumber AS DBRevision

        FROM    #TestTable
        WHERE   PATINDEX('%sp_executesql%', TextData) > 0
                AND EventClass IN ( 10, 12 )                 


/* Create Hash Column for Grouping */

UPDATE  AggregatedData
SET     HashText = ( HASHBYTES('MD5', PartialText) )
WHERE   RunNumber = @RunNumber ;


/* Clean Up */
DROP TABLE #TestTable;
