SELECT  PartialText
      , ISNULL(MAX([1]),0) AS exeRun1
      , ISNULL(MAX([11]),0) AS avgRun1
      , ISNULL(MAX([21]),0) AS maxRun1
      --, '' as c1
      
      --, ISNULL(MAX([2]),0) AS exeRun2
      --, ISNULL(MAX([12]),0) AS avgRun2
      --, ISNULL(MAX([22]),0) AS maxRun2
      --, '' as c2
      
      --, ISNULL(MAX([3]),0) AS exeRun3
      --, ISNULL(MAX([13]),0) AS avgRun3
      --, ISNULL(MAX([23]),0) AS maxRun3
      -- , '' as c3
       
      --, ISNULL(MAX([4]),0) AS exeRun4
      --, ISNULL(MAX([14]),0) AS avgRun4
      --, ISNULL(MAX([24]),0) AS maxRun4
      -- , '' as c4
       
      --, ISNULL(MAX([5]),0) AS exeRun5
      --, ISNULL(MAX([15]),0) AS avgRun5
      --, ISNULL(MAX([25]),0) AS maxRun5
      -- , '' as c5
      
      --, ISNULL(MAX([6]),0) AS exeRun6
      --, ISNULL(MAX([16]),0) AS avgRun6
      --, ISNULL(MAX([26]),0) AS maxRun6
      -- , '' as c6
       
     
      --, ISNULL(MAX([7]),0) AS exeRun7
      --, ISNULL(MAX([17]),0) AS avgRun7
      --, ISNULL(MAX([27]),0) AS maxRun7
      -- , '' as col7
      
      --, ISNULL(MAX([8]),0) AS exeRun8
      --, ISNULL(MAX([18]),0) AS avgRun8
      --, ISNULL(MAX([28]),0) AS maxRun8
      
FROM    (SELECT SUBSTRING(NormalizedTextData, 0,75) as PartialText
              , TraceID
              , TraceID + 10 AS TraceID2
              , TraceID + 20 AS TraceID3
              , COUNT(RowID) as Executions
              , CAST(AVG(Duration/1000.0) AS DECIMAL(10,2)) as avgDuration_MS
              , CAST(MAX(Duration/1000.0) AS DECIMAL(10,2)) AS maxDuration_MS
         FROM   CTTraceSummary
		 INNER JOIN CTTextData on CTTraceSummary.TextDataHashCode = CTTextData.TextDataHashCode
         WHERE TraceID = 3
		 GROUP BY SUBSTRING(NormalizedTextData, 0,75), TraceID) AS T 
         

			  PIVOT ( SUM(Executions) FOR TraceID IN ([1], [2], [3], [4], [5],[6], [7], [8]) ) AS P0
              PIVOT ( SUM(avgDuration_MS) FOR TraceID2 IN ([11], [12], [13], [14],[15], [16], [17], [18]) ) AS P1              PIVOT ( SUM(maxDuration_MS) FOR TraceID3 IN ([21], [22], [23], [24],[25], [26], [27], [28]) ) AS P2
		
GROUP BY PartialText ;
