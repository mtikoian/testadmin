SELECT 
  trace_column_id
, name
FROM sys.trace_columns