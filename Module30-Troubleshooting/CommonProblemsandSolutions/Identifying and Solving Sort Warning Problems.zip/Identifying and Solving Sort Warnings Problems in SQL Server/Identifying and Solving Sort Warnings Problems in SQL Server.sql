
-- SQL Saturday 188 Lisbon, 16.03.2013
-- Session: Identifying and Solving Sort Warnings Problems in SQL Server
-- Code Samples
-- Dipl.-Ing. Milos Radivojevic, Database Developer - bwin, Vienna, Austria
-- Milos.Radivojevic@bwinparty.com
-- http://www.bwinparty.com

-----------------------------------------------------
--Sort Warnings Examples
-----------------------------------------------------

-----------------------------------------------------
--Sort Warnings - Wrong Cardinality Estimation
-----------------------------------------------------

--Choose option Include Actual Execution Plan in order to show the execution plan
USE AdventureWorks2012;
GO

--A sample query with sort operator
SELECT SalesOrderID, OrderDate, DueDate, ShipDate, TotalDue 
FROM Sales.SalesOrderHeader
WHERE SalesOrderID < 50000
ORDER BY OrderDate;
GO


--Wrong cardinality estimation: comparison operators between different columns of the same table
SELECT * FROM Sales.SalesOrderHeader
WHERE DueDate > ShipDate
ORDER BY OrderDate;
GO

--Wrong cardinality estimation: local variable sniffing
DECLARE @OrderDate AS DATETIME ='20010101';
SELECT * FROM Sales.SalesOrderHeader
WHERE OrderDate > @OrderDate
ORDER BY DueDate;
GO
--with the date 20040301 there is no sort warnings
DECLARE @OrderDate AS DATETIME = '20070301';
SELECT * FROM Sales.SalesOrderHeader 
WHERE OrderDate > @OrderDate 
ORDER BY DueDate;
GO

-----------------------------------------------------
--Sort Warnings - Parameter Sniffing
-----------------------------------------------------

--Create a sample stored procedure
IF OBJECT_ID ('dbo.GetSalesOrderHeader', 'P') IS NOT NULL DROP PROCEDURE dbo.GetSalesOrderHeader;
GO
CREATE PROCEDURE dbo.GetSalesOrderHeader(@OrderDate DATETIME)
AS
BEGIN
	SET NOCOUNT ON;
	SELECT * FROM Sales.SalesOrderHeader
	WHERE OrderDate > @OrderDate
	ORDER BY DueDate;
END
--First invocation (high selectivity)
EXEC dbo.GetSalesOrderHeader '20090101';
GO
--Second invocation (low selectivity)
EXEC dbo.GetSalesOrderHeader '20010101';
GO


---------------------------------------------------------------------------
--Identifying Sort Warnings in SQL Server 2008 (batch granularity)
--Credits to Herbert Albert, Mentor with SolidQ
---------------------------------------------------------------------------

USE AdventureWorks;
GO
--Create a table to collect sort warnings data
IF OBJECT_ID (N'dbo.sort_warnings', N'U') IS NOT NULL
  DROP TABLE dbo.sort_warnings;
GO
CREATE TABLE dbo.sort_warnings
(
	MessageBody XML,
	PostTime DATETIME,
	Spid INT,
	SqlText NVARCHAR(MAX)
);
GO

--Create a procedure which is started whenever a message enters the queue
IF OBJECT_ID (N'dbo.process_sort_warning_event', N'P') IS NOT NULL
	DROP PROCEDURE dbo.process_sort_warning_event;
GO
CREATE PROCEDURE dbo.process_sort_warning_event
WITH EXECUTE AS OWNER
AS
BEGIN
	DECLARE	@messageTypeName NVARCHAR(256),
			@messageBody XML;
	RECEIVE TOP(1) 
			@messageTypeName = message_type_name,
			@messageBody = message_body
	FROM dbo.SortWarningsQueue;

	IF @@ROWCOUNT = 0
		RETURN;

	DECLARE @posttime NVARCHAR(24);
	DECLARE @spid INT;
	DECLARE @sql NVARCHAR(MAX);
	SET @posttime = CONVERT(DATETIME,CONVERT(NVARCHAR(24),@messagebody.query('data(//PostTime)')));
	SET @spid = CONVERT(INT,CONVERT(NVARCHAR(6),@messagebody.query('data(//SPID)')));

	SELECT  @sql = COALESCE(txt.text,'not found')   
	FROM sys.dm_exec_connections con
	CROSS APPLY sys.dm_exec_sql_text (con.most_recent_sql_handle) AS txt
	WHERE session_id = @spid;

	INSERT INTO dbo.sort_warnings(MessageBody, PostTime, Spid, SqlText)
	VALUES(@messageBody, @posttime, @spid, @sql);
END;
GO

USE AdventureWorks;
--Enable Service Broker
ALTER DATABASE AdventureWorks SET ENABLE_BROKER;
--Ensure we can execute queries against DMVs
ALTER DATABASE Adventureworks SET TRUSTWORTHY ON;
GO
--Create a queue to collect events
CREATE QUEUE dbo.SortWarningsQueue
WITH STATUS=ON,	
ACTIVATION 
			(
				PROCEDURE_NAME = dbo.process_sort_warning_event,
				MAX_QUEUE_READERS = 5,
				EXECUTE AS OWNER
			);
GO

--Create a service on the queue that references the Event Notifications contract
CREATE SERVICE SortWarningsService
ON QUEUE dbo.SortWarningsQueue
(
    [http://schemas.microsoft.com/SQL/Notifications/PostEventNotification]
);
GO

--Create the database event notification
CREATE EVENT NOTIFICATION NotifySort_Warnings
ON SERVER
FOR SORT_WARNINGS
TO SERVICE 'SortWarningsService','current database';
GO

--Execute some statements causing sort warnings
USE AdventureWorks;
GO
SELECT * FROM Sales.SalesOrderHeader
WHERE DueDate > ShipDate
ORDER BY OrderDate;
GO

--Query the dbo.sort_warnings table
SELECT * FROM dbo.sort_warnings;
--Results
/*
<EVENT_INSTANCE><EventType>SORT_WARNINGS</EventType>...	2012-02-19 00:00:00.000	55	SELECT * FROM Sales.SalesOrderHeader  WHERE DueDate > ShipDate  ORDER BY OrderDate;  
*/

--Cleanup Script
DROP EVENT NOTIFICATION NotifySort_Warnings ON SERVER;
DROP SERVICE SortWarningsService;
DROP QUEUE dbo.SortWarningsQueue;
DROP PROCEDURE dbo.process_sort_warning_event;
DROP TABLE dbo.sort_warnings;
GO

---------------------------------------------------------------------------
--Identifying Sort Warnings in SQL Server 2008 (statement granularity)
---------------------------------------------------------------------------
USE AdventureWorks;
GO
--Create a table to collect sort warnings data
IF OBJECT_ID (N'dbo.sort_warnings', N'U') IS NOT NULL
  DROP TABLE dbo.sort_warnings;
GO
CREATE TABLE dbo.sort_warnings
(
	MessageBody XML,
	PostTime DATETIME,
	Spid INT,
	SqlText NVARCHAR(MAX)
);
GO

--Create a procedure which is started whenever a message enters the queue
IF OBJECT_ID (N'dbo.process_sort_warning_event', N'P') IS NOT NULL
	DROP PROCEDURE dbo.process_sort_warning_event;
GO
CREATE PROCEDURE dbo.process_sort_warning_event
WITH EXECUTE AS OWNER
AS
BEGIN
	DECLARE	@messageTypeName NVARCHAR(256),
			@messageBody XML;
	RECEIVE TOP(1) 
			@messageTypeName = message_type_name,
			@messageBody = message_body
	FROM dbo.SortWarningsQueue;

	IF @@ROWCOUNT = 0
		RETURN;

	DECLARE @posttime NVARCHAR(24);
	DECLARE @spid INT;
	DECLARE @sql NVARCHAR(MAX);
	SET @posttime = CONVERT(DATETIME,CONVERT(NVARCHAR(24),@messagebody.query('data(//PostTime)')));
	SET @spid = CONVERT(INT,CONVERT(NVARCHAR(6),@messagebody.query('data(//SPID)')));

	SELECT  @sql = SUBSTRING(txt.text, (req.statement_start_offset/2)+1, 
				(
					(CASE req.statement_end_offset WHEN -1 THEN DATALENGTH(txt.text) ELSE req.statement_end_offset END - req.statement_start_offset)/2) 
				+ 1
				) 
  
	FROM sys.dm_exec_requests req
	CROSS APPLY sys.dm_exec_sql_text (req.sql_handle) AS txt
	WHERE session_id = @spid;

	INSERT INTO dbo.sort_warnings(MessageBody, PostTime, Spid, SqlText)
	VALUES(@messageBody, @posttime, @spid, @sql);
END;
GO

--Enable service broker
USE AdventureWorks;
--Enable Service Broker
ALTER DATABASE AdventureWorks SET ENABLE_BROKER;
--Ensure we can execute queries against DMVs
ALTER DATABASE Adventureworks SET TRUSTWORTHY ON;
GO
--Create a queue to collect events
CREATE QUEUE dbo.SortWarningsQueue
WITH STATUS=ON,	
ACTIVATION 
			(
				PROCEDURE_NAME = dbo.process_sort_warning_event,
				MAX_QUEUE_READERS = 5,
				EXECUTE AS OWNER
			);
GO

--Create a service on the queue that references the Event Notifications contract
CREATE SERVICE SortWarningsService
ON QUEUE dbo.SortWarningsQueue
(
    [http://schemas.microsoft.com/SQL/Notifications/PostEventNotification]
);
GO

--Create the database event notification
CREATE EVENT NOTIFICATION NotifySort_Warnings
ON SERVER
FOR SORT_WARNINGS
TO SERVICE 'SortWarningsService','current database';
GO

--Execute some statements causing sort warnings
USE AdventureWorks;
GO
SELECT * FROM Sales.SalesOrderHeader
WHERE DueDate > ShipDate
ORDER BY OrderDate;
GO

--Query the dbo.sort_warnings table
SELECT * FROM dbo.sort_warnings;
--Results
/*
<EVENT_INSTANCE><EventType>SORT_WARNINGS</EventType>...	2012-02-19 00:00:00.000	55	SELECT * FROM Sales.SalesOrderHeader  WHERE DueDate > ShipDate  ORDER BY OrderDate;  
*/

--Cleanup Script
DROP EVENT NOTIFICATION NotifySort_Warnings ON SERVER;
DROP SERVICE SortWarningsService;
DROP QUEUE dbo.SortWarningsQueue;
DROP PROCEDURE dbo.process_sort_warning_event;
DROP TABLE dbo.sort_warnings;
GO


---------------------------------------------------------------------------
--Identifying Sort Warnings in SQL Server 2012  (batch granularity)
---------------------------------------------------------------------------

--Create an Event Session
IF EXISTS(SELECT 1 FROM sys.dm_xe_sessions WHERE name=N'SQLU_SortWarningsDemo')
	DROP EVENT SESSION SQLU_SortWarningsDemo ON SERVER;
GO
CREATE EVENT SESSION SQLU_SortWarningsDemo ON SERVER 
ADD EVENT sqlserver.sort_warning
(
    ACTION (sqlserver.sql_text)
	WHERE (sqlserver.database_id = 5)--db_id from AdventureWorks2012
)
ADD TARGET package0.event_file(SET filename = N'C:\Temp\SQLU_SortWarningsDemo.xel', max_file_size=(50))
WITH 
(
	MAX_MEMORY=4096 KB,
	EVENT_RETENTION_MODE=ALLOW_SINGLE_EVENT_LOSS,
	MAX_DISPATCH_LATENCY=1 SECONDS,
	STARTUP_STATE=ON
);

--Start the session
ALTER EVENT SESSION SQLU_SortWarningsDemo ON SERVER STATE = START;
GO

--Execute some statements causing sort warnings
USE AdventureWorks2012;
GO
SELECT * FROM Sales.SalesOrderHeader
WHERE DueDate > ShipDate
ORDER BY OrderDate;
GO

--Query the target
WITH cte AS
(
	SELECT object_name, CAST(event_data AS XML) AS event_data
	FROM sys.fn_xe_file_target_read_file('C:\Temp\SQLU_SortWarningsDemo*.xel',NULL, NULL, NULL)
)
SELECT
event_data.value('(event/@timestamp)[1]', 'DATETIME') AS timestamp,
event_data.value('(event/data[@name="sort_warning_type"]/text)[1]', 'VARCHAR(20)') AS sort_warning_type,
event_data.value('(event/action[@name="sql_text"]/value)[1]', 'VARCHAR(MAX)') AS sql_text
FROM cte;
GO
 
--Remove the session
DROP EVENT SESSION SQLU_SortWarningsDemo ON SERVER;
GO
 

---------------------------------------------------------------------------
--Identifying Sort Warnings in SQL Server 2012  (statement granularity)
---------------------------------------------------------------------------

--Create an Event Session
IF EXISTS(SELECT 1 FROM sys.dm_xe_sessions WHERE name=N'SQLU_SortWarningsDemo')
	DROP EVENT SESSION SQLU_SortWarningsDemo ON SERVER;
GO
CREATE EVENT SESSION SQLU_SortWarningsDemo ON SERVER 
ADD EVENT sqlserver.sort_warning
(
    ACTION (sqlserver.sql_text,sqlserver.tsql_frame)
	WHERE (sqlserver.database_id = 5)--db_id from AdventureWorks2012
)
ADD TARGET package0.event_file(SET filename = N'C:\Temp\SQLU_SortWarningsDemo.xel', max_file_size=(50))
WITH 
(
	MAX_MEMORY=4096 KB,
	EVENT_RETENTION_MODE=ALLOW_SINGLE_EVENT_LOSS,
	MAX_DISPATCH_LATENCY=30 SECONDS,
	STARTUP_STATE=ON
);

--Start the session
ALTER EVENT SESSION SQLU_SortWarningsDemo ON SERVER STATE = START;
GO


--Execute some statements causing sort warnings
USE AdventureWorks2012;
GO
SELECT * FROM Sales.SalesOrderHeader
WHERE DueDate > ShipDate ORDER BY OrderDate;
SELECT * FROM Sales.SalesOrderHeader
WHERE DueDate > ShipDate ORDER BY DueDate;

GO

--Query the target
SELECT
event_data.value('(event/@timestamp)[1]', 'DATETIME') AS timestamp,
event_data.value('(event/data[@name="sort_warning_type"]/text)[1]', 'VARCHAR(20)') AS sort_warning_type,
event_data.value('(event/action[@name="sql_text"]/value)[1]', 'VARCHAR(MAX)') AS sql_text,
SUBSTRING(st.text, (frame_data.value('./@offsetStart','INT')/2)+1,
((CASE frame_data.value('./@offsetEnd','INT')
WHEN -1 THEN DATALENGTH(st.text)
ELSE frame_data.value('./@offsetEnd','INT')
END - frame_data.value('./@offsetStart','INT'))/2) + 1) AS sort_warning_statement
FROM (SELECT object_name, CAST(event_data AS XML) AS event_data
FROM sys.fn_xe_file_target_read_file('C:\Temp\SQLU_SortWarningsDemo*.xel',null,null,null)) x
CROSS APPLY x.event_data.nodes('event/action[@name="tsql_frame"]/value/frame') Frame(frame_data)
OUTER APPLY sys.dm_exec_sql_text(CONVERT(VARBINARY(MAX), frame_data.value('./@handle','varchar(max)'),1)) st;
GO
 
--Remove the session
DROP EVENT SESSION SQLU_SortWarningsDemo ON SERVER;
GO


---------------------------------------------------------------------------
--Solutions for Sort Warnings Problems
---------------------------------------------------------------------------

--Local Variable - solution is OPTION (RECOMPILE)
DECLARE @OrderDate AS DATETIME = '20010101';
SELECT * FROM Sales.SalesOrderHeader 
WHERE OrderDate > @OrderDate 
ORDER BY DueDate
OPTION (RECOMPILE);
GO

--Parameter Sniffing - solution is OPTION (RECOMPILE)
IF OBJECT_ID ('dbo.GetSalesOrderHeaderRecompile', 'P') IS NOT NULL  DROP PROCEDURE dbo.GetSalesOrderHeaderRecompile;
GO
CREATE PROCEDURE dbo.GetSalesOrderHeaderRecompile (@OrderDate DATETIME)
AS
BEGIN
	SET NOCOUNT ON;
	SELECT *
	FROM Sales.SalesOrderHeader
	WHERE OrderDate > @OrderDate
	ORDER BY DueDate
	OPTION (RECOMPILE);
END
GO

--Wrong cardinality estimation - Create a computed column
ALTER TABLE Sales.SalesOrderHeader ADD CompCol AS DATEDIFF(day,ShipDate,DueDate);
GO
--rewrite the query
SELECT * FROM Sales.SalesOrderHeader
WHERE DATEDIFF(day,ShipDate,DueDate) > 0
ORDER BY OrderDate;
GO



---------------------------------------------------------------------------
--Solutions for Sort Warnings Problems with large tables
---------------------------------------------------------------------------
USE ABC
GO

SELECT * FROM dbo.Logs WHERE user_id=162  ORDER BY log_date OPTION (RECOMPILE);
--Estimated Number of Rows 50,5
--Actual Number of Rows 5.576 (100x more!)

DBCC SHOW_STATISTICS('dbo.Logs',ix876)

SELECT DISTINCT user_id FROM dbo.Logs WHERE user_id>1 AND user_id<185;

SELECT * FROM dbo.Logs WHERE user_id=14  ORDER BY log_date OPTION (RECOMPILE);
--Estimated Number of Rows 50,5
--Actual Number of Rows 10
--Estimated Number of Rows is 50,5 for user_id's from the range 1 - 185 

--Solution:
CREATE STATISTICS Logs_Milos ON dbo.Logs (user_id) WHERE user_id>1 AND user_id<185;

SELECT * FROM dbo.Logs WHERE user_id=162  ORDER BY log_date OPTION (RECOMPILE);
--Estimated Number of Rows 5767,4
--Actual Number of Rows 5.576 and No Sort Warning

--We still have Sort Warnings in other intervals

SELECT * FROM dbo.Logs WHERE user_id=1252  ORDER BY log_date OPTION (RECOMPILE);
--Estimated Number of Rows 57,7
--Actual Number of Rows 5.437

--Cleanup
DROP STATISTICS dbo.Logs.Logs_Milos 
GO