USE tempdb
GO

--Add some files
ALTER DATABASE tempdb 
	MODIFY FILE (NAME = tempdev, FILENAME = 'C:\Data\tempdb\tempdb.mdf')
GO

ALTER DATABASE tempdb
ADD FILE (NAME = tempdev2, FILENAME = 'C:\Data\tempdb\tempdb2.ndf', SIZE = 1000MB);
ALTER DATABASE tempdb
ADD FILE (NAME = tempdev3, FILENAME = 'C:\Data\tempdb\tempdb3.ndf', SIZE = 1000MB);
ALTER DATABASE tempdb
ADD FILE (NAME = tempdev4, FILENAME = 'C:\Data\tempdb\tempdb4.ndf', SIZE = 1000MB);
ALTER DATABASE tempdb
ADD FILE (NAME = tempdev5, FILENAME = 'C:\Data\tempdb\tempdb5.ndf', SIZE = 1000MB);
ALTER DATABASE tempdb
ADD FILE (NAME = tempdev6, FILENAME = 'C:\Data\tempdb\tempdb6.ndf', SIZE = 1000MB);
GO

ALTER DATABASE tempdb 
	MODIFY FILE (NAME = templog, FILENAME = 'C:\Data\tempdb\tempdb.ldf')
GO

--Going back to bad
USE tempdb
GO

DBCC SHRINKFILE (tempdev2, EMPTYFILE); -- to empty "tempdev2" data file
GO

ALTER DATABASE tempdb
REMOVE FILE tempdev2;
GO

USE tempdb
GO

DBCC SHRINKFILE (tempdev3, EMPTYFILE); -- to empty "tempdev3" data file
GO

ALTER DATABASE tempdb
REMOVE FILE tempdev3;
GO

USE tempdb
GO

DBCC SHRINKFILE (tempdev4, EMPTYFILE); -- to empty "tempdev4" data file
GO

ALTER DATABASE tempdb
REMOVE FILE tempdev4;
GO

USE tempdb
GO

DBCC SHRINKFILE (tempdev5, EMPTYFILE); -- to empty "tempdev5" data file
GO

ALTER DATABASE tempdb
REMOVE FILE tempdev5;
GO

USE tempdb
GO

DBCC SHRINKFILE (tempdev6, EMPTYFILE); -- to empty "tempdev6" data file
GO

ALTER DATABASE tempdb
REMOVE FILE tempdev6;
GO

DBCC SHRINKFILE (tempdev, 1);
GO