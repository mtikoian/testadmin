SELECT
	dt.session_id,
	dt.wait_type,
	dt.wait_duration_ms,
	dt.blocking_session_id,
	dt.resource_description,
	dt.ResourceType
FROM
	(SELECT 
		session_id,
		wait_type,
		wait_duration_ms,
		blocking_session_id,
		resource_description,
		ResourceType = 
		CASE
			WHEN Charindex('2', resource_description, 0) != 1 Then 'Not Used'
			WHEN Cast(Right(resource_description, Len(resource_description) - Charindex(':', resource_description, 3)) As Int) - 1 % 8088 = 0 Then 'Is PFS Page'
			WHEN Cast(Right(resource_description, Len(resource_description) - Charindex(':', resource_description, 3)) As Int) - 2 % 511232 = 0 Then 'Is GAM Page'
			WHEN Cast(Right(resource_description, Len(resource_description) - Charindex(':', resource_description, 3)) As Int) - 3 % 511232 = 0 Then 'Is SGAM Page'
			ELSE NULL
		END
	FROM
		sys.dm_os_waiting_tasks
	WHERE
		wait_type Like 'PAGE%LATCH_%'
		AND resource_description Like '2:%') dt
WHERE
	ResourceType IS NOT NULL
	ORDER BY wait_duration_ms DESC
