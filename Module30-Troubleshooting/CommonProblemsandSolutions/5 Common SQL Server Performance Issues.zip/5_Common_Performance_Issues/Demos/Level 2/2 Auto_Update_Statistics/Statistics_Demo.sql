USE [AdventureWorks2012]
GO
--Thanks to Erin Stellato @ sqlskills.com

--CREATE NONCLUSTERED INDEX IX_DemoData_UnitPrice ON Sales.SalesOrderDetail(UnitPrice)

--Check last statistics updated time first
--2014-01-15 15:07:44.3530000

-- How many is 10%?
SELECT COUNT(*) * .10 from Sales.SalesOrderDetail

--Let's update 10%
UPDATE Sales.SalesOrderDetail
SET UnitPrice += 1.00
FROM Sales.SalesOrderDetail
JOIN 
	(SELECT TOP 12132
		* 
	 FROM 
		Sales.SalesOrderDetail) demo ON
	demo.SalesOrderID = Sales.SalesOrderDetail.SalesOrderID
	AND demo.SalesOrderDetailID = Sales.SalesOrderDetail.SalesOrderDetailID
	AND demo.ProductID = Sales.SalesOrderDetail.ProductID

--Check last statistics updated time again
--2014-01-15 15:07:44.3530000

--How many is 20%?
SELECT COUNT(*) * .20 from Sales.SalesOrderDetail

--Let's update just enough to get over 20% to fire the auto statistics update
UPDATE Sales.SalesOrderDetail
SET UnitPrice += 1.00
FROM Sales.SalesOrderDetail
JOIN 
	(SELECT TOP 24265
		* 
	 FROM 
		Sales.SalesOrderDetail) demo ON
	demo.SalesOrderID = Sales.SalesOrderDetail.SalesOrderID
	AND demo.SalesOrderDetailID = Sales.SalesOrderDetail.SalesOrderDetailID
	AND demo.ProductID = Sales.SalesOrderDetail.ProductID

--Check last statistics updated time again
--2014-01-15 15:07:44.3530000

SELECT TOP 500 * FROM Sales.SalesOrderDetail WHERE UnitPrice > 1
ORDER BY ProductID

--Check last statistics updated final time
--2014-01-16 14:19:42.1900000