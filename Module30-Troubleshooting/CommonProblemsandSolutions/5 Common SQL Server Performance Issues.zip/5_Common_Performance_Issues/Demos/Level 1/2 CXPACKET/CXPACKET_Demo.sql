USE [AdventureWorks2012]
GO

--DROP INDEX Sales.SalesOrderJason.IX_DemoData_UnitPrice
--CREATE NONCLUSTERED INDEX IX_DemoData_UnitPrice ON Sales.SalesOrderJason(UnitPrice)

GO

DBCC FREEPROCCACHE
DBCC SETCPUWEIGHT(1000)
GO

select
	count_big(*)
from
	Sales.SalesOrderJason
where
	UnitPrice >= 1.00
	and UnitPrice <= 2400.00
GO


DBCC SETCPUWEIGHT(1)
DBCC FREEPROCCACHE