SELECT
    i.name									as IndexName,
	STATS_DATE(i.object_id, i.index_id)		as StatsUpdated,
	SCHEMA_NAME(i.object_id)				as SchemaName,
	OBJECT_NAME(i.object_id)				as ObjectName,
    SUM(s.page_count * 8 / 1024)			as SizeMBs,
	SUM(s.record_count)						as RecordCount
FROM sys.dm_db_index_physical_stats(
    db_id(), object_id('dbo.TableName'), NULL, NULL, 'SAMPLED') AS s
JOIN sys.indexes AS i
ON s.[object_id] = i.[object_id] AND s.index_id = i.index_id
WHERE
	STATS_DATE(i.object_id, i.index_id)	<= DATEADD(HOUR, -1, getdate())
GROUP BY 
    i.name,
	STATS_DATE(i.object_id, i.index_id),
	SCHEMA_NAME(i.object_id),
	OBJECT_NAME(i.object_id)
HAVING
	SUM(page_count * 8 / 1024) > 10
ORDER BY 
	RecordCount DESC,
	SizeMBs DESC,
	StatsUpdated DESC

UPDATE STATISTICS ProductVersionLog
UPDATE STATISTICS Users