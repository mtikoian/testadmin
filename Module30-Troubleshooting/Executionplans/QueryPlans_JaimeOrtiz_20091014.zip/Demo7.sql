/* 

Analyzing Query Plans - User group meeting NWA
by: Jaime Ortiz

*/

DBCC FREEPROCCACHE
GO

SELECT * FROM sys.syscacheobjects
GO

SELECT * FROM dbo.Members
WHERE memberid = 664851
GO

SELECT * FROM sys.syscacheobjects
GO

SELECT * FROM dbo.Members
WHERE memberid = 664852
GO

SELECT * FROM sys.syscacheobjects
GO

DECLARE @IntVariable int;
DECLARE @SQLString nvarchar(500);
DECLARE @ParmDefinition nvarchar(500);

/* Build the SQL string one time.*/
SET @SQLString =
     N'	SELECT * FROM dbo.Members
		WHERE memberid = @MemberID';
SET @ParmDefinition = N'@MemberID int';
/* Execute the string with the first parameter value. */
SET @IntVariable = 664852;
EXECUTE sp_executesql @SQLString, @ParmDefinition,
                      @MemberID = @IntVariable;
GO

SELECT * FROM sys.syscacheobjects
GO