/* 

Analyzing Query Plans - User group meeting NWA
by: Jaime Ortiz

*/

DBCC FREEPROCCACHE
GO

SELECT * FROM sys.syscacheobjects
GO


USE NWAUserGroup
GO

/* Text Plan Example - Memebers Table with no indexes (HEAP) 1,000,000 rows */
SET SHOWPLAN_TEXT ON
GO

SELECT * FROM dbo.Members
WHERE memberid = 664851
GO

SET SHOWPLAN_TEXT OFF
GO

/* Show plan_all example - Members Table with no indexes (HEAP) 1,000,0000 rows */
/* This does not execute the query until it is set to OFF*/
SET SHOWPLAN_ALL ON
GO

SELECT * FROM dbo.Members
WHERE memberid = 664851
GO

SET SHOWPLAN_ALL OFF
GO

