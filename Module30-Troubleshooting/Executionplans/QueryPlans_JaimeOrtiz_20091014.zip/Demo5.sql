/*
Analyzing Query Plans - User group meeting NWA
by: Jaime Ortiz

*/
USE NWAUserGroup
GO


/* Drop all indexes if exists*/
IF  EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[MemberSales]') AND name = N'NC_MemberID')
DROP INDEX [MemberSales].[NC_MemberID]
GO

IF  EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[MemberSales]') AND name = N'CI_MemberidProdID')
DROP INDEX [MemberSales].[CI_MemberidProdID]
GO

SET STATISTICS PROFILE ON
SET STATISTICS IO ON
SET STATISTICS TIME ON
GO


/*Table scan on table MemberSales because there is not an index*/
SELECT * FROM dbo.MemberSales
WHERE memberid = 664851
GO

SET STATISTICS PROFILE OFF
SET STATISTICS IO OFF
SET STATISTICS TIME OFF
GO


/*Let's create a nonclustered index on memberid for the membersales table*/
CREATE NONCLUSTERED INDEX [NC_MemberID] ON [MemberSales] 
(
	[memberid] ASC
)WITH FILLFACTOR = 85 ON [PRIMARY]
GO

SET STATISTICS PROFILE ON
SET STATISTICS IO ON
SET STATISTICS TIME ON
GO

/*Table scan on table MemberSales because there is not an index*/
SELECT * FROM dbo.MemberSales
WHERE memberid = 664851
GO

SET STATISTICS PROFILE OFF
SET STATISTICS IO OFF
SET STATISTICS TIME OFF
GO

/* Let's create a clustered index on memberid */
CREATE CLUSTERED INDEX [CI_MemberidProdID] ON [dbo].[MemberSales] 
(
	[memberid] ASC
	
)WITH (STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO

SET STATISTICS PROFILE ON
SET STATISTICS IO ON
SET STATISTICS TIME ON
GO

/*Table scan on table MemberSales because there is not an index*/
SELECT * FROM dbo.MemberSales
WHERE memberid = 664851
GO

SET STATISTICS PROFILE OFF
SET STATISTICS IO OFF
SET STATISTICS TIME OFF
GO