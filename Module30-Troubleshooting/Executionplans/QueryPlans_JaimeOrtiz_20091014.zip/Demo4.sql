/* 

Analyzing Query Plans - User group meeting NWA
by: Jaime Ortiz

*/
USE NWAUserGroup
GO

/*	You cannot run the following statement with other statements */
/*	Msg 1067, Level 15, State 2, Line 1
	The SET SHOWPLAN statements must be the only statements in the batch.
*/
SET SHOWPLAN_XML ON
GO
SET STATISTICS XML ON
GO

SELECT * FROM dbo.Members
WHERE memberid  = 664851
GO

SET SHOWPLAN_XML OFF
GO

SET STATISTICS XML OFF
GO