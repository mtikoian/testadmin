/* 

Analyzing Query Plans - User group meeting NWA
by: Jaime Ortiz

*/

DBCC FREEPROCCACHE
GO

SELECT * FROM sys.syscacheobjects
GO


USE NWAUserGroup
GO


SELECT * FROM dbo.Members
WHERE memberid = 664851
GO

SELECT * FROM sys.syscacheobjects
GO

SELECT * FROM dbo.Members
WHERE memberid = 664852
GO


