/*
------------------------------------------------------
-- SQL Saturday #38 
-- Jacksonville, FL
-- 08 May 2010
-- Eric Wisdahl
--
-- Reading Plans 02 - Stored Procedures
-- Version 1.0 05/01/2010
-- 
-- Just running some stored procs to see what the
-- output plans look like.
------------------------------------------------------
*/

USE AdventureWorks2014;
GO

DECLARE @myCheckDate datetime;
DECLARE @myStartProductID int;

SELECT 
 @myStartProductID = MAX(ProductID) 
FROM 
 [Production].[Product]
;

SET @myCheckDate = GETDATE();


EXECUTE [AdventureWorks2014].[dbo].[uspGetBillOfMaterials] 
   @StartProductID = @myStartProductID
  ,@CheckDate = @myCheckDate
GO


EXECUTE [AdventureWorks2014].[dbo].[uspSearchCandidateResumes] 
   @searchString = 'Resume'
  ,@useInflectional = 1
  ,@useThesaurus = 1
GO

EXECUTE [AdventureWorks2014].[dbo].[uspGetEmployeeManagers] 
   @BusinessEntityID = 2
GO


