/*
------------------------------------------------------
-- Example Scripts used for "An Introductory Look at 
-- Execution Plans".
-- 
-- SQL Saturday #38 
-- Jacksonville, FL
-- 08 May 2010
-- Eric Wisdahl
------------------------------------------------------
*/


USE AdventureWorks2014;
GO

/*
------------------------------------------------------
-- Statistics Time returns information relating to the 
-- cpu time and elapsed time for execution as well as
-- parse and compile times.
------------------------------------------------------
*/
SET STATISTICS TIME ON;
GO

SELECT
 Title
 , FirstName
 , MiddleName
 , LastName
FROM
 Person.Person
;
GO

SET STATISTICS TIME OFF;
GO

/*
------------------------------------------------------
-- Statistics IO returns information relating to the 
-- amount of disk activity generate by the t-sql 
-- statement.
------------------------------------------------------
--Table 
-- Name of Table
--Scan Count 
-- Number of Index or Table scans performed
--Logical Reads 
-- Number of pages read from the data cache
--Physical Reads 
-- Number fo pages read from the disk
--Read-Ahead Reads 
-- Number of pages placed into the cache for the 
-- query
--LOB Logical Reads 
-- Number of text, ntext, image or LOB pages read 
-- from the data cache
--LOB Physical Reads 
-- Number of text, ntext, image or LOB pages read 
-- from disk
--LOB Read-Ahead Reads 
-- Number of text, ntext, image or LOB pages placed 
-- into the cache from the query
----------------------------------------------------
*/
SET STATISTICS IO ON;
GO

SELECT
 Title
 , FirstName
 , MiddleName
 , LastName
FROM
 Person.Person
;
GO

SET STATISTICS IO OFF;
GO


