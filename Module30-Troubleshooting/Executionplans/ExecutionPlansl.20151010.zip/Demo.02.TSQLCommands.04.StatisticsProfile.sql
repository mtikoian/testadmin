/*
------------------------------------------------------
-- SQL Saturday #38 
-- Jacksonville, FL
-- 08 May 2010
-- Eric Wisdahl
--
-- T-SQL Commands Demo 01 - STATISTICS PROFILE
-- Version 1.0 05/01/2010
-- 
-- Use the statistics profile command to output the 
-- results, along with the execution plan from the query.
--
-- Statistics PROFILE returns the "actual" execution plan 
-- in Text-based record-set format.
--
-- Note that the text plan option will be removed in 
-- a future version.
------------------------------------------------------
*/

USE AdventureWorks2014;
GO

SET STATISTICS PROFILE ON;
GO

SELECT
 Title
 , FirstName
 , MiddleName
 , LastName
FROM
 Person.Person
Where
 LastName = 'Smith'
;
GO

SET STATISTICS PROFILE OFF;
GO
