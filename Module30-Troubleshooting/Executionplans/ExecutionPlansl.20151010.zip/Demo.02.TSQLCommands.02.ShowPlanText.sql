/*
------------------------------------------------------
-- SQL Saturday #38 
-- Jacksonville, FL
-- 08 May 2010
-- Eric Wisdahl
--
-- T-SQL Commands Demo 01 - SHOWPLAN TEXT
-- Version 1.0 05/01/2010
-- 
-- Use the showplan text command to output the 
-- execution plan from the query.
--
-- Note that this returns two distinct result sets,
-- neither of which conveys the extra information conveyed
-- by the SHOWPLAN_ALL command (i.e. estimated row
-- size, estimated IO, estimated CPU, etc)
------------------------------------------------------
*/

USE AdventureWorks2014;
GO

SET SHOWPLAN_TEXT ON;
GO

SELECT
 Title
 , FirstName
 , MiddleName
 , LastName
FROM
 Person.Person
Where
 LastName = 'Smith'
;
GO

SET SHOWPLAN_TEXT OFF;
GO
