/*
------------------------------------------------------
-- SQL Saturday #38 
-- Jacksonville, FL
-- 08 May 2010
-- Eric Wisdahl
--
-- Reading Plans 03 - Views vs Queries
-- Version 1.0 05/01/2010
-- 
-- Show that the execution plans are the same for 
-- a view and the query, assuming that there are 
-- no indexes on the view (i.e. materialized view).
------------------------------------------------------
*/
USE AdventureWorks2014;
GO

SELECT 
 [BusinessEntityID]
 , [Title]
 , [FirstName]
 , [MiddleName]
 , [LastName]
 , [Suffix]
 , [Shift]
 , [Department]
 , [GroupName]
 , [StartDate]
 , [EndDate]
FROM 
 [HumanResources].[vEmployeeDepartmentHistory]
;


SELECT 
    [Employee].[BusinessEntityID] 
    ,[Person].[Title] 
    ,[Person].[FirstName] 
    ,[Person].[MiddleName] 
    ,[Person].[LastName] 
    ,[Person].[Suffix] 
    ,[Shift].[Name] AS [Shift]
    ,[Department].[Name] AS [Department] 
    ,[Department].[GroupName] 
    ,[EmployeeDepartmentHistory].[StartDate] 
    ,[EmployeeDepartmentHistory].[EndDate]
FROM 
 [HumanResources].[Employee]
INNER JOIN 
 [Person].[Person]
ON 
 [Person].[BusinessEntityID] = [Employee].[BusinessEntityID]
INNER JOIN 
 [HumanResources].[EmployeeDepartmentHistory]
ON 
 [Employee].[BusinessEntityID] = [EmployeeDepartmentHistory].[BusinessEntityID] 
INNER JOIN 
 [HumanResources].[Department]
ON 
 [EmployeeDepartmentHistory].[DepartmentID] = [Department].[DepartmentID] 
INNER JOIN 
 [HumanResources].[Shift]
ON 
 [Shift].[ShiftID] = [EmployeeDepartmentHistory].[ShiftID]
;
