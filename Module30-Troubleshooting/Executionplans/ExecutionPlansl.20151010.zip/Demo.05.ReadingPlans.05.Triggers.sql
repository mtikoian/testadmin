/*
------------------------------------------------------
-- SQL Saturday #38 
-- Jacksonville, FL
-- 08 May 2010
-- Eric Wisdahl
--
-- Reading Plans 05 - Triggers
-- Version 1.0 05/01/2010
-- 
-- Show the estimated execution plan for inserting into
-- the workorder table.  Now show the actual plan.
-- Note that there is an extra query, namely the insert
-- into the transaction history table which is instigated
-- by the trigger on the work order table.
------------------------------------------------------
*/
USE AdventureWorks2014;
GO

BEGIN TRANSACTION myTestWorkOrderInsert;
GO

--Select * from sys.triggers;

INSERT INTO 
 [Production].[WorkOrder]
(
 [ProductID]
 , [OrderQty]
 , [ScrappedQty]
 , [StartDate]
 , [EndDate]
 , [DueDate]
 , [ScrapReasonID]
)
VALUES
(
 1
 , 10
 , 1
 , GETDATE()
 , DateAdd(dd, 2, GETDATE())
 , DATEADD(dd, 3, GetDate())
 , 1
)
GO

ROLLBACK TRANSACTION myTestWorkOrderInsert;
GO

