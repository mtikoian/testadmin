/*
------------------------------------------------------
-- SQL Saturday #38 
-- Jacksonville, FL
-- 08 May 2010
-- Eric Wisdahl
--
-- T-SQL Commands Demo 01 - SHOWPLAN ALL
-- Version 1.0 05/01/2010
-- 
-- SHOWPLAN_ALL returns the "estimated" execution plan 
-- in Text-based record-set format.
--
-- Use the showplan all command to output the 
-- execution plan from the query.
------------------------------------------------------
*/

USE AdventureWorks2014;
GO

SET SHOWPLAN_ALL ON;
GO

SELECT
 Title
 , FirstName
 , MiddleName
 , LastName
FROM
 Person.Person
Where
 LastName = 'Smith'
;
GO

SET SHOWPLAN_ALL OFF;
GO
