/*
------------------------------------------------------
-- SQL Saturday #38 
-- Jacksonville, FL
-- 08 May 2010
-- Eric Wisdahl
--
-- Reading Plans 01 - Simple Plans
-- Version 1.0 05/01/2010
-- 
------------------------------------------------------
*/

USE AdventureWorks2014;
GO

/*
------------------------------------------------------
-- Uses NonClustered Index Only (Covering)
------------------------------------------------------
*/
Select
 Person.FirstName
 , Person.LastName
From
 Person.Person
Where
 LastName = 'Smith'
;

/*
------------------------------------------------------
-- Uses NonClustered Index Only and Key Lookup
------------------------------------------------------
*/
Select
 Person.FirstName
 , Person.LastName
 , Person.NameStyle
From
 Person.Person
Where
 LastName = 'Smith'
;

/*
------------------------------------------------------
-- Uses NonClustered Index, with Seek
------------------------------------------------------
*/
Select
 Person.FirstName
 , Person.LastName
From
 Person.Person
Where
 LastName like 'Smith%'
;

/*
------------------------------------------------------
-- Uses NonClustered Index, with Scan
------------------------------------------------------
*/
Select
 Person.FirstName
 , Person.LastName
From
 Person.Person
Where
 LastName like '%Smith%'
;

/*
------------------------------------------------------
-- Uses NonClustered Index, with Scan
------------------------------------------------------
*/
Select
 Person.FirstName
 , Person.LastName
 , Person.Title
From
 Person.Person
Where
 LastName like '%Smith%'
;
GO