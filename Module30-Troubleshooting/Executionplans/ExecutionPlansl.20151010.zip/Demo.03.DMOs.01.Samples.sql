/*
------------------------------------------------------
-- SQL Saturday #38 
-- Jacksonville, FL
-- 08 May 2010
-- Eric Wisdahl
--
-- DMOs Demo 01 - Various DMOs.
-- Version 1.0 05/01/2010
-- 
-- ----------------------------
-- sys.dm_exec_requests
-- ----------------------------
-- Returns one row for each request executing within SQL Server. The 
-- sys.dm_exec_connections, sys.dm_exec_sessions, and sys.dm_exec_requests 
-- server scope dynamic management views map to the sys.sysprocesses system 
-- view (previously system table).
--
-- ----------------------------
-- sys.dm_exec_cached_plans
-- ----------------------------
-- Returns a row for each query plan that is cached by SQL 
-- Server for faster query execution. You can use this dynamic 
-- management view to find cached query plans, cached query 
-- text, the amount of memory taken by cached plans, and 
-- the reuse count of the cached plans.
--
-- ----------------------------
-- sys.dm_exec_query_plan
-- ----------------------------
-- Returns the Showplan in XML format for the batch specified by 
-- the plan handle. The plan specified by the plan handle can 
-- either be cached or currently executing.
--
-- ----------------------------
-- sys.dm_exec_query_stats
-- ----------------------------
-- Returns aggregate performance statistics for cached query plans. 
-- The view contains one row per query statement within the cached 
-- plan, and the lifetime of the rows are tied to the plan itself. 
-- When a plan is removed from the cache, the corresponding rows 
-- are eliminated from this view.
--
-- ----------------------------
-- sys.dm_exec_plan_attributes
-- ----------------------------
-- Returns one row per plan attribute for the plan specified by the 
-- plan handle. You can use this table-valued function to get details 
-- about a particular plan, such as the cache key values or the number of 
-- current simultaneous executions of the plan.
--
-- ----------------------------
-- sys.dm_exec_sql_text
-- ----------------------------
-- Returns the text of the SQL batch that is identified by the specified 
-- sql_handle. This table-valued function replaces the system function 
-- fn_get_sql.
--
-- ----------------------------
-- sys.dm_exec_text_query_plan
-- ----------------------------
-- Returns the Showplan in text format for a Transact-SQL batch or for a 
-- specific statement within the batch. The query plan specified by the plan 
-- handle can either be cached or currently executing. This table-valued 
-- function is similar to sys.dm_exec_query_plan, but has the following 
-- differences: 
-- The output of the query plan is returned in text format.
-- The output of the query plan is not limited in size.
-- Individual statements within the batch can be specified.
--
------------------------------------------------------
*/

USE AdventureWorks2014;
GO

Select
 sys.dm_exec_sql_text.Text
 , sys.dm_exec_cached_plans.usecounts
 , sys.dm_exec_cached_plans.size_in_bytes
 , sys.dm_exec_cached_plans.objtype
 , sys.dm_exec_query_plan.query_plan
From
 sys.dm_exec_cached_plans
CROSS APPLY
 sys.dm_exec_query_plan (sys.dm_exec_cached_plans.plan_handle)
CROSS APPLY
 sys.dm_exec_sql_text (sys.dm_exec_cached_plans.plan_handle)
Where
 DB_NAME(dm_exec_sql_text.dbid) = 'AdventureWorks2014'
 OR sys.dm_exec_cached_plans.objtype = 'Adhoc'
;

Select
 sys.dm_exec_sql_text.Text
 , sys.dm_exec_query_plan.query_plan
 , sys.dm_exec_requests.blocking_session_id
 , sys.dm_exec_requests.wait_type
 , sys.dm_exec_requests.wait_time
 , sys.dm_exec_requests.last_wait_type
From
 sys.dm_exec_requests
CROSS APPLY
 sys.dm_exec_query_plan (dm_exec_requests.plan_handle)
CROSS APPLY
 sys.dm_exec_sql_text (dm_exec_requests.sql_handle)
;