/*
------------------------------------------------------
-- SQL Saturday #38 
-- Jacksonville, FL
-- 08 May 2010
-- Eric Wisdahl
--
-- T-SQL Commands Demo 01 - SHOWPLAN XML
-- Version 1.0 05/01/2010
-- 
-- Use the showplan xml command to output the 
-- estimated execution plan from the query.
--
-- Note that this returns the XML version of the 
-- execution plan, which can be clicked to load
-- as the graphical plan.
------------------------------------------------------
*/

USE AdventureWorks2014;
GO

SET SHOWPLAN_XML ON;
GO

SELECT
 Title
 , FirstName
 , MiddleName
 , LastName
FROM
 Person.Person
Where
 LastName = 'Smith'
;
GO

SET SHOWPLAN_XML OFF;
GO
