/*
------------------------------------------------------
-- SQL Saturday #38 
-- Jacksonville, FL
-- 08 May 2010
-- Eric Wisdahl
--
-- SSMS GUI Execution Plan Elements
-- Version 1.0 05/01/2010
-- 
-- Show the Toolbar button for display actual
-- Show the Toolbar button for display estimated
-- Show the Shortcuts - Control 'M' and Control 'L'
-- Show the query menu options for display actual / estimated
-- Show the right click on the query window for display actual / estimated
--
-- Show the difference between actual and estimated plans
-- (i.e. no USE AdventureWorks2014 statement)
------------------------------------------------------
*/

USE AdventureWorks2014;
GO

/*
------------------------------------------------------
-- Clustered Index Scan
-- About 00:00:07 for approximately 20K rows.
------------------------------------------------------
*/
Select
 [BusinessEntityID]
 , [PersonType]
 , [NameStyle]
 , [Title]
 , [FirstName]
 , [MiddleName]
 , [LastName]
 , [Suffix]
 , [EmailPromotion]
 , [AdditionalContactInfo]
 , [Demographics]
 , [rowguid]
 , [ModifiedDate]
From
 Person.Person
;

GO