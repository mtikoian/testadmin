/*
------------------------------------------------------
-- SQL Saturday #38 
-- Jacksonville, FL
-- 08 May 2010
-- Eric Wisdahl
--
-- DMOs Demo 02 - Clear Cache and Run DMOs again.
-- Version 1.0 05/01/2010
-- 
-- In this demo we will simply free the processing
-- cache and then run the last demo again to show
-- that most of the information is no longer present.
------------------------------------------------------
*/

USE AdventureWorks2014;
GO

CHECKPOINT
GO

DBCC DROPCLEANBUFFERS
GO

DBCC FREEPROCCACHE
GO