/*
------------------------------------------------------
-- SQL Saturday #38 
-- Jacksonville, FL
-- 08 May 2010
-- Eric Wisdahl
--
-- T-SQL Commands Demo 01 - STATISTICS XML
-- Version 1.0 05/01/2010
-- 
-- Use the statistics xml command to output the 
-- results, along with the execution plan from the query.
--
-- Statistics XML returns the "actual" execution plan 
-- in xml format.  This can be "clicked" on to produce
-- the graphical plan.
------------------------------------------------------
*/

USE AdventureWorks2014;
GO

SET STATISTICS XML ON;
GO

SELECT
 Title
 , FirstName
 , MiddleName
 , LastName
FROM
 Person.Person
Where
 LastName = 'Smith'
;
GO

SET STATISTICS XML OFF;
GO
