/*
------------------------------------------------------
-- SQL Saturday #38 
-- Jacksonville, FL
-- 08 May 2010
-- Eric Wisdahl
--
-- Profiler
-- Version 1.0 05/01/2010
-- 
------------------------------------------------------
*/

-- Just a side note that we are not really putting anything in here.
-- we will run the profiler demo through the profiler GUI.
-- However, you CAN use the trace scripts to retrieve the same type of
-- information from the engine and write it out to disk / table.

