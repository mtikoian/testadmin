/*
------------------------------------------------------
-- SQL Saturday #38 
-- Jacksonville, FL
-- 08 May 2010
-- Eric Wisdahl
--
-- Reading Plans 05 - Joins
-- Version 1.0 05/01/2010
-- 
-- The Code and Explanations for the differences in
-- join conditions are from Craig Freedman's post
-- "Summary of Join Properties" 
-- http://blogs.msdn.com/craigfr/archive/2006/08/16/702828.aspx
--
------------------------------------------------------
*/

USE AdventureWorks2014;
GO

/*
------------------------------------------------------
-- Nested Loop Joins
------------------------------------------------------
-- Best For: 
	Relatively small inputs with an index on the inner 
	table on the join key.
-- Concurrency:
	Supports large numbers of concurrent users.
-- Stop And Go:
	No
-- Equijoin Required:
	No
-- Outer and Semi-Joins:
	Left Joins Only (Full outer joins via transformation)
-- Uses Memory:
	No
-- Uses Tempdb:
	No
-- Requires Order:
	No
-- Preserves Order:
	Yes (outer input only)
------------------------------------------------------
*/

/*
------------------------------------------------------
-- Merge Joins
------------------------------------------------------
-- Best For: 
	Medium to large inputs with indexes to provide order 
	on the equijoin keys and/or where we require order 
	after the join.
-- Concurrency:
	Many-to-one join with indexes to provide order supports 
	large numbers of concurrent users.
-- Stop And Go:
	No
-- Equijoin Required:
	Yes (Except for Full Outer Join)
-- Outer and Semi-Joins:
	All join types
-- Uses Memory:
	No (may require sorts which use memory)
-- Uses Tempdb:
	Yes (many - to - many join only)
-- Requires Order:
	Yes
-- Preserves Order:
	Yes
------------------------------------------------------
*/

/*
------------------------------------------------------
-- Hash Joins
------------------------------------------------------
-- Best For: 
	DW queries with medium to large inputs.  Parallel 
	execution that scales linearly.
-- Concurrency:
	Best for small numbers of concurrent users with 
	high throughput requirements.
-- Stop And Go:
	Yes (build input only)
-- Equijoin Required:
	Yes
-- Outer and Semi-Joins:
	All join types
-- Uses Memory:
	Yes
-- Uses Tempdb:
	Yes (if join runs out of memory and spills)
-- Requires Order:
	No
-- Preserves Order:
	No
------------------------------------------------------
*/

BEGIN TRANSACTION JoinDemo;
GO



/*
------------------------------------------------------
-- Create two tables with 100 records each
------------------------------------------------------
*/
create table T1 (a int, b int, x char(200));

create table T2 (a int, b int, x char(200));

set nocount on

declare @i int

set @i = 0

while @i < 1000

  begin

    insert T1 values (@i * 2, @i * 5, @i)

    insert T2 values (@i * 3, @i * 7, @i)

    set @i = @i + 1

  end

/*
------------------------------------------------------
-- Add another table, this one much larger than the 
-- first two.
------------------------------------------------------
*/
create table T3 (a int, b int, x char(200));

set @i = 0

while @i < 100000
  begin
    insert T3 values (@i * 5, @i * 11, @i)
    set @i = @i + 1
  end

/*
------------------------------------------------------
-- Set up the Statistics XML to show the plans
------------------------------------------------------
*/

SET STATISTICS XML ON;
GO

/*
------------------------------------------------------
-- Simple join will result in Hash Join
------------------------------------------------------
*/
Select
 *
From
 T1
JOIN
 T2
ON
 T1.a = T2.a
;

/*
------------------------------------------------------
-- If we want the first 10 records only, results in 
-- Nested Loop Join
------------------------------------------------------
*/
select top 10 
 * 
from 
 T1 
join 
 T2 
on 
 T1.a = T2.a
;

/*
------------------------------------------------------
-- If we want the first 100 records the query becomes
-- to expensive for a Nested Loop Join and instead 
-- shifts to a Merge Join
------------------------------------------------------
*/
select top 10 
 * 
from 
 T1 
join 
 T2 
on 
 T1.a = T2.a
;

/*
------------------------------------------------------
-- We now create a clustered index on T1 to show
-- the difference having the index (and sort order)
-- will have on some of the queries.
------------------------------------------------------
*/
create unique clustered index T1a on T1(a)

/*
------------------------------------------------------
-- Try the Original Query one more time (the first
-- resulted in a Hash Join).  Since the first table
-- is already sorted, the optimizer thinks it is cheaper
-- to sort the second table and perform a MERGE JOIN.
------------------------------------------------------
*/
Select
 *
From
 T1
JOIN
 T2
ON
 T1.a = T2.a
;

/*
------------------------------------------------------
-- Try the Original Query one more time, this time with
-- a where clause (not on the clustered index key).  
--
-- The merge join plan needs to sort all 1000 rows of 
-- T1 while the hash join plan only needs to build a 
-- hash table on the 20 rows of T1 that match the 
-- predicate T1.b < 100.  Thus, the hash join plan needs 
-- less memory and is less likely to spill.
------------------------------------------------------
*/
Select
 *
From
 T1
JOIN
 T2
ON
 T1.a = T2.a
WHERE
 T1.b < 100
;


/*
------------------------------------------------------
-- Try the Original Query one more time, this time with
-- a where clause (not on the clustered index key) and
-- a sort order.  
--
-- Due to the sort order, we are back to the MERGE JOIN.
-- Recall that the merge join preserves order so we do 
-- not need to do a final sort to sastify the order by 
-- clause of the query.  Hash join does not preserve 
-- order so we would need an extra sort.  With the hash 
-- join, we would need two memory consuming operators.  
-- 
-- Note that one memory consuming operator is not 
-- necessarily better than two.  It really depends on 
-- how much memory the operators need.
------------------------------------------------------
*/
Select
 *
From
 T1
JOIN
 T2
ON
 T1.a = T2.a
WHERE
 T1.b < 100
ORDER BY
 T1.a
;


/*
------------------------------------------------------
-- Try the query with the predicate on the scan of T2.
--
-- By reducing the cardinality of T2 an index loops join
-- is now the best choice.
------------------------------------------------------
*/
Select
 *
From
 T1
JOIN
 T2
ON
 T1.a = T2.a
WHERE
 T2.b < 100
;

/*
------------------------------------------------------
-- Even though we have an index on T1, we still choose 
-- a hash join.  Recall that the join of T1 and T2 which 
-- were similarly sized used a merge join.  To do a 
-- merge join, we need sorted order on both T1 and T3.  
-- The hash join needs enough memory to build a hash 
-- table on T1 or 1000 rows while a merge join would 
-- need enough memory to sort all of T3 or 100,000 rows.  
-- Thus, the hash join saves memory.
------------------------------------------------------
*/
Select
 *
From
 T1
JOIN
 T3
ON
 T1.a = T3.a
;

SET STATISTICS XML OFF;
GO

 
ROLLBACK TRANSACTION JoinDemo;
GO
