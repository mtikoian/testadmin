-- The unique identitier for an execution plan in cache is the plan handle.
-- This is a VARBINARY(64) value.

-- There are several ways to get a plan handle.
-- Here are two:
SELECT
  R.Session_id,
  R.Plan_Handle
FROM sys.dm_exec_requests AS R
JOIN sys.dm_exec_sessions AS S
  ON S.Session_id = R.session_id 
WHERE S.is_user_process = 1

SELECT
  S.plan_handle
FROM sys.dm_exec_procedure_stats AS S
WHERE S.database_id = DB_ID(N'AdventureWorks2014')
  AND S.[object_id] = OBJECT_ID(N'AdventureWorks2014.dbo.System_Info_Get');

