-You can download the full backup of the �AdventureWorks2014� database here: https://msftdbprodsamples.codeplex.com/releases/view/125550



-The stored procedures are standalone and can be created in any database.  The demo scripts assume they exist in the �AdventureWorks2014� database.
--Execution_Plan_XML_From_Plan_Cache_By_Plan_Handle_Get.sql
--Execution_Plans_From_Cache_By_Ad_Hoc_SQL_Text_Get.sql
--Execution_Plans_From_Cache_Grouped_By_Similar_Ad_Hoc_SQL_Text_Get.sql
--Plan_Cache_Worst_Batches_Get.sql
--Plan_Cache_Worst_Plans_Get.sql
--Plan_Cache_Worst_Sprocs_Get.sql
--Plan_Cache_Worst_Statements_Get.sql
--Statements_By_Reads_Per_Minute_Get.sql



-The "Setup and Populate Plan Cache.sql" creates a few objects and indexes in AdventureWorks2014 and runs some queries to populate the plan cache.  This is just to make sure there is interesting information in the cache to query and not terribly important.  Some of the demos search for execution plans of objects created in this script.



-The demos all run in the "AdventureWorks2014" database.
--1 - dm_exec_cached_plans - Plan aggregates - Single use plans.sql
--2 - Find similar plans - Ad-hoc bloat.sql
--3 - dm_exec_procedure_stats - Plan for a specified object.sql
--4 - dm_exec_query_stats - worst offenders.sql
--5 - dm_exec_request - Get plans of executing queries.sql
--6 - Exec Product_Data_Export.sql
--6.1 - recompile Product_Data_Export.sql
--6.2 - Get cached plan for Product_Data_Export.sql
--6.3 - Get plan for single session.sql
--7 - Index Usage.sql
--Appendix 1.1 - Create sample stored procedure.sql
--Appendix 1.2 - Get plan handle.sql
--Appendix 1.3 - Get execution plan - most of the time.sql
--Appendix 1.4 - Get execution plan - 99.9 percent of the time.sql



-All of the dynamic management views and functions used in the demo scripts and stored procedures will work as far back as SQL Server 2008 (possibly 2005 but I haven�t verified them all).  However, there are a couple places that use TRY_CONVERT() which wasn�t introduced until SQL Server 2012.  Simply comment this code out to use it in an older system.

