USE AdventureWorks2014;

DECLARE
  @Database SYSNAME = N'AdventureWorks2014',
  @Schema_Name SYSNAME = N'dbo',
  @Procedure_Name SYSNAME = N'uspGetManagerEmployees';

SELECT
  DB_NAME(P.database_id) AS [Database_Name],
  OBJECT_NAME(P.[object_id], P.database_id) AS Obj_Name,
  
  TRY_CONVERT(XML, QP.query_Plan) AS Query_Plan_XML,
  
  QP.query_plan

FROM sys.dm_exec_procedure_stats AS P
OUTER APPLY sys.dm_exec_text_query_plan(P.plan_handle, DEFAULT, DEFAULT) AS QP
WHERE P.database_id = DB_ID(@Database)
  AND P.[object_id] = OBJECT_ID(@Database + N'.' + @Schema_Name + N'.' + @Procedure_Name);

SELECT
  ROW_NUMBER() OVER 
  (
    PARTITION BY 
      QS.Plan_Handle 
    ORDER BY 
      QS.Statement_Start_Offset
  ) AS Statement_Num,
  DB_NAME(QT.[dbid]) AS [DB_Name],
  SUBSTRING
  (
    SUBSTRING
    (
      QT.[text],
      (QS.statement_start_offset / 2) + 1,
      (
        CASE 
          WHEN QS.statement_end_offset = -1 THEN LEN(CONVERT(NVARCHAR(MAX), QT.[text])) * 2 
          ELSE QS.statement_end_offset 
        END - QS.statement_start_offset
      ) / 2
    ),
    1,
    75
  ) AS [Statement],
  QS.total_logical_reads  / QS.execution_count AS Avg_Reads,
  QS.total_logical_reads AS Total_Reads,
  QS.last_logical_reads AS Last_Reads,
  QS.max_logical_reads AS Max_Reads,
  (QS.total_worker_time / 1000) / QS.execution_count AS Avg_CPU,
  (QS.total_worker_time / 1000) AS Total_CPU,
  QS.Execution_Count,
  QS.Creation_Time
FROM sys.dm_exec_procedure_stats AS P
JOIN sys.dm_exec_query_stats AS QS
  ON QS.[sql_handle] = P.[sql_handle]
  AND QS.plan_handle = P.plan_handle
CROSS APPLY sys.dm_exec_sql_text(qs.[sql_handle]) AS QT
WHERE P.database_id = DB_ID(@Database)
  AND P.[object_id] = OBJECT_ID(@Database + N'.' + @Schema_Name + N'.' + @Procedure_Name)
ORDER BY
  QS.Statement_Start_Offset;