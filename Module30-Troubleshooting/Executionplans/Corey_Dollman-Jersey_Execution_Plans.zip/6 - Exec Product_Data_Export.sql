USE AdventureWorks2014;

EXEC dbo.Product_Data_Export;