DECLARE
  @Plan_Handle VARBINARY(64);

SELECT
  @Plan_Handle = S.plan_handle
FROM sys.dm_exec_procedure_stats AS S
WHERE S.database_id = DB_ID(N'AdventureWorks2014')
  --AND S.[object_id] = OBJECT_ID(N'AdventureWorks2014.dbo.Has_8k_String_Literal');
  AND S.[object_id] = OBJECT_ID(N'AdventureWorks2014.dbo.System_Info_Get');

SELECT
  @Plan_Handle AS Plan_Handle;

-- https://msdn.microsoft.com/en-us/library/ms189747.aspx
SELECT
  PH.Query_Plan
FROM sys.dm_exec_query_plan(@Plan_Handle) AS PH;

SELECT
  PH.Query_Plan
  
  --, CONVERT(XML, PH.Query_Plan)
FROM sys.dm_exec_text_query_plan(@Plan_Handle, DEFAULT, DEFAULT) AS PH;

SELECT
  ROW_NUMBER() OVER 
  (
    ORDER BY
      QS.statement_start_offset
  ),
  P.query_plan, 
  LEFT
  (
    SUBSTRING
    (
      ST.[text], 
      QS.statement_start_offset / 2 + 1,
      (
        (
          CASE 
            WHEN QS.statement_end_offset = -1 THEN DATALENGTH(ST.[text])
            ELSE QS.statement_end_offset 
          END - QS.statement_start_offset
        ) / 2
      ) + 1
    ), 
    5000
  )
  AS Statement_SQL
FROM sys.dm_exec_query_stats AS QS
CROSS APPLY sys.dm_exec_Text_query_plan(QS.Plan_Handle, QS.Statement_Start_Offset, QS.Statement_End_Offset) AS P
CROSS APPLY sys.dm_exec_sql_text(QS.[SQL_Handle]) AS ST
WHERE QS.plan_handle = @Plan_Handle