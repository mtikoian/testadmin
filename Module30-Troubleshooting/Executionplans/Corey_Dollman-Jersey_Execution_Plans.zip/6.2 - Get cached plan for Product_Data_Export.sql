USE AdventureWorks2014;

SELECT
  TRY_CONVERT(XML, QP.query_plan) AS Query_Plan_XML,
  QP.query_plan
FROM sys.dm_exec_procedure_stats AS P
CROSS APPLY sys.dm_exec_text_query_plan(P.plan_handle, DEFAULT, DEFAULT) AS QP
WHERE P.database_id = DB_ID(N'AdventureWorks2014')
  AND P.object_id = OBJECT_ID(N'Product_Data_Export');