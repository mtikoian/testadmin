USE AdventureWorks2014;

-- ** Sorting ** 
-- 1 = Avg_Reads
-- 2 = Total_Reads
-- 3 = Last_Reads
-- 4 = Avg_CPU
-- 5 = Total_CPU
-- 6 = Last_CPU
-- 7 = Wait_Time
-- 8 = Execution_Count
-- 9 = Last_Execution

-- Worst offenders by Total CPU.
EXEC dbo.Plan_Cache_Worst_Batches_Get 5;
EXEC dbo.Plan_Cache_Worst_Plans_Get 5;
EXEC dbo.Plan_Cache_Worst_Sprocs_Get 5;
EXEC dbo.Plan_Cache_Worst_Statements_Get 5;

-- Worst offenders by execution count.
EXEC dbo.Plan_Cache_Worst_Batches_Get 8;
EXEC dbo.Plan_Cache_Worst_Plans_Get 8;
EXEC dbo.Plan_Cache_Worst_Sprocs_Get 8;
EXEC dbo.Plan_Cache_Worst_Statements_Get 8;


EXEC dbo.Statements_By_Reads_Per_Minute_Get 50, 'AdventureWorks2014', 0, 0;