USE AdventureWorks2014;

EXEC dbo.Execution_Plans_From_Cache_Grouped_By_Similar_Ad_Hoc_SQL_Text_Get 50, 2, 'AdventureWorks2014'

EXEC dbo.Execution_Plans_From_Cache_By_Ad_Hoc_SQL_Text_Get 'SELECT * FROM Production.Product', 'AdventureWorks2014'
