USE AdventureWorks2014;

DECLARE
  @Plan_Handle VARBINARY(64),
  @Plan_XML NVARCHAR(MAX);

SELECT
  @Plan_Handle = S.plan_handle
FROM sys.dm_exec_procedure_stats AS S
WHERE S.database_id = DB_ID(N'AdventureWorks2014')
  AND S.[object_id] = OBJECT_ID(N'AdventureWorks2014.dbo.System_Info_Get');

SELECT
  @Plan_Handle AS Plan_Handle;

EXEC dbo.Execution_Plan_XML_From_Plan_Cache_By_Plan_Handle_Get
  @Plan_Handle,
  @Plan_XML OUTPUT;

SELECT
  @Plan_XML AS Plan_XML

  , CAST(@Plan_XML AS XML);