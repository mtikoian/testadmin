-- Create a basic procedure that we can run on any server.
-- We will then grab it's execution plan out of cache.
USE AdventureWorks2014;
GO
IF OBJECT_ID(N'System_Info_Get') IS NOT NULL
BEGIN
  DROP PROCEDURE dbo.System_Info_Get;
END;
GO
CREATE PROCEDURE dbo.System_Info_Get
(
  @Include_Up_Time BIT
)
AS

SET NOCOUNT ON;
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

CREATE TABLE dbo.#System_Info
(
  Name NVARCHAR(40) NOT NULL,
  Value NVARCHAR(4000) NULL
);

INSERT dbo.#System_Info
(
  Name,
  Value
) 
VALUES
(
  N'@@VERSION',
  @@VERSION
),
(
  N'MACHINENAME',
  CAST(SERVERPROPERTY(N'MACHINENAME') AS NVARCHAR(4000))
),
(
  N'INSTANCENAME',
  CAST(SERVERPROPERTY(N'INSTANCENAME') AS NVARCHAR(4000))
)

IF @Include_Up_Time = 1
BEGIN
  INSERT dbo.#System_Info
  (
    Name,
    Value
  )
  SELECT
    N'Up time in minutes',
    CAST(DATEDIFF(MINUTE, D.Create_Date, GETDATE()) AS NVARCHAR(4000))
  FROM sys.databases AS D
  WHERE D.name = N'tempdb';
END;

SELECT
  SI.Name,
  SI.Value
FROM dbo.#System_Info AS SI;

DROP TABLE dbo.#System_Info;

RETURN;
GO
EXEC dbo.System_Info_Get 0;
GO
IF OBJECT_ID('dbo.Has_8k_String_Literal') IS NOT NULL
BEGIN
  DROP PROCEDURE dbo.Has_8k_String_Literal;
END;
GO
CREATE PROCEDURE dbo.Has_8k_String_Literal
AS

--SELECT TOP(150)
--  'CROSS JOIN sys.' + T.Name 
--FROM sys.all_Objects AS T
--WHERE T.[schema_Id] = 4
--  AND T.name NOT LIKE '%pdw%'
--  AND T.type_desc = 'VIEW'
--ORDER BY
--  T.name

SELECT
  TOP(1) *
FROM sys.all_objects AS A
CROSS JOIN sys.all_columns
CROSS JOIN sys.all_objects
CROSS JOIN sys.all_parameters
CROSS JOIN sys.all_sql_modules
CROSS JOIN sys.all_views
CROSS JOIN sys.allocation_units
CROSS JOIN sys.assemblies
CROSS JOIN sys.assembly_files
CROSS JOIN sys.assembly_modules
CROSS JOIN sys.assembly_references
CROSS JOIN sys.assembly_types
CROSS JOIN sys.asymmetric_keys
CROSS JOIN sys.backup_devices
CROSS JOIN sys.certificates
CROSS JOIN sys.change_tracking_databases
CROSS JOIN sys.change_tracking_tables
CROSS JOIN sys.check_constraints
CROSS JOIN sys.column_type_usages
CROSS JOIN sys.column_xml_schema_collection_usages
CROSS JOIN sys.columns
CROSS JOIN sys.computed_columns
CROSS JOIN sys.configurations
CROSS JOIN sys.conversation_endpoints
CROSS JOIN sys.conversation_groups
CROSS JOIN sys.conversation_priorities
CROSS JOIN sys.credentials
CROSS JOIN sys.crypt_properties
CROSS JOIN sys.cryptographic_providers
CROSS JOIN sys.data_spaces
CROSS JOIN sys.database_audit_specification_details
CROSS JOIN sys.database_audit_specifications
CROSS JOIN sys.database_files
CROSS JOIN sys.database_mirroring
CROSS JOIN sys.database_mirroring_endpoints
CROSS JOIN sys.database_mirroring_witnesses
CROSS JOIN sys.database_permissions
CROSS JOIN sys.database_principals
CROSS JOIN sys.database_recovery_status
CROSS JOIN sys.database_role_members
CROSS JOIN sys.databases
CROSS JOIN sys.default_constraints
CROSS JOIN sys.destination_data_spaces
CROSS JOIN sys.dm_audit_actions
CROSS JOIN sys.dm_audit_class_type_map
CROSS JOIN sys.dm_broker_activated_tasks
CROSS JOIN sys.dm_broker_connections
CROSS JOIN sys.dm_broker_forwarded_messages
CROSS JOIN sys.dm_broker_queue_monitors
CROSS JOIN sys.dm_cdc_errors
CROSS JOIN sys.dm_cdc_log_scan_sessions
CROSS JOIN sys.dm_clr_appdomains
CROSS JOIN sys.dm_clr_loaded_assemblies
CROSS JOIN sys.dm_clr_properties
CROSS JOIN sys.dm_clr_tasks
CROSS JOIN sys.dm_cryptographic_provider_properties
CROSS JOIN sys.dm_database_encryption_keys
CROSS JOIN sys.dm_db_file_space_usage
CROSS JOIN sys.dm_db_index_usage_stats
CROSS JOIN sys.dm_db_mirroring_auto_page_repair
CROSS JOIN sys.dm_db_mirroring_connections
CROSS JOIN sys.dm_db_mirroring_past_actions
CROSS JOIN sys.dm_db_missing_index_details
CROSS JOIN sys.dm_db_missing_index_group_stats
CROSS JOIN sys.dm_db_missing_index_groups
CROSS JOIN sys.dm_db_partition_stats
CROSS JOIN sys.dm_db_persisted_sku_features
CROSS JOIN sys.dm_db_script_level
CROSS JOIN sys.dm_db_session_space_usage
CROSS JOIN sys.dm_db_task_space_usage
CROSS JOIN sys.dm_exec_background_job_queue
CROSS JOIN sys.dm_exec_background_job_queue_stats
CROSS JOIN sys.dm_exec_cached_plans
CROSS JOIN sys.dm_exec_connections
CROSS JOIN sys.dm_exec_procedure_stats
CROSS JOIN sys.dm_exec_query_memory_grants
CROSS JOIN sys.dm_exec_query_optimizer_info
CROSS JOIN sys.dm_exec_query_resource_semaphores
CROSS JOIN sys.dm_exec_query_stats
CROSS JOIN sys.dm_exec_query_transformation_stats
CROSS JOIN sys.dm_exec_requests
CROSS JOIN sys.dm_exec_sessions
CROSS JOIN sys.dm_exec_trigger_stats
CROSS JOIN sys.dm_filestream_file_io_handles
CROSS JOIN sys.dm_filestream_file_io_requests
CROSS JOIN sys.dm_fts_active_catalogs
CROSS JOIN sys.dm_fts_fdhosts
CROSS JOIN sys.dm_fts_index_population
CROSS JOIN sys.dm_fts_memory_buffers
CROSS JOIN sys.dm_fts_memory_pools
CROSS JOIN sys.dm_fts_outstanding_batches
CROSS JOIN sys.dm_fts_population_ranges
CROSS JOIN sys.dm_io_backup_tapes
CROSS JOIN sys.dm_io_cluster_shared_drives
CROSS JOIN sys.dm_io_pending_io_requests
CROSS JOIN sys.dm_os_buffer_descriptors
CROSS JOIN sys.dm_os_child_instances
CROSS JOIN sys.dm_os_cluster_nodes
CROSS JOIN sys.dm_os_dispatcher_pools
CROSS JOIN sys.dm_os_dispatchers
CROSS JOIN sys.dm_os_hosts
CROSS JOIN sys.dm_os_latch_stats
CROSS JOIN sys.dm_os_loaded_modules
CROSS JOIN sys.dm_os_memory_allocations
CROSS JOIN sys.dm_os_memory_brokers
CROSS JOIN sys.dm_os_memory_cache_clock_hands
CROSS JOIN sys.dm_os_memory_cache_counters
CROSS JOIN sys.dm_os_memory_cache_entries
CROSS JOIN sys.dm_os_memory_cache_hash_tables
CROSS JOIN sys.dm_os_memory_clerks
CROSS JOIN sys.dm_os_memory_node_access_stats
CROSS JOIN sys.dm_os_memory_nodes
CROSS JOIN sys.dm_os_memory_objects
CROSS JOIN sys.dm_os_memory_pools
CROSS JOIN sys.dm_os_nodes
CROSS JOIN sys.dm_os_performance_counters
CROSS JOIN sys.dm_os_process_memory
CROSS JOIN sys.dm_os_ring_buffers
CROSS JOIN sys.dm_os_schedulers
CROSS JOIN sys.dm_os_spinlock_stats
CROSS JOIN sys.dm_os_stacks
CROSS JOIN sys.dm_os_sublatches
CROSS JOIN sys.dm_os_sys_info
CROSS JOIN sys.dm_os_sys_memory
CROSS JOIN sys.dm_os_tasks
CROSS JOIN sys.dm_os_threads
CROSS JOIN sys.dm_os_virtual_address_dump
CROSS JOIN sys.dm_os_wait_stats
CROSS JOIN sys.dm_os_waiting_tasks
CROSS JOIN sys.dm_os_worker_local_storage
CROSS JOIN sys.dm_os_workers
CROSS JOIN sys.dm_qn_subscriptions
CROSS JOIN sys.dm_repl_articles
CROSS JOIN sys.dm_repl_schemas
CROSS JOIN sys.dm_repl_tranhash
CROSS JOIN sys.dm_repl_traninfo
CROSS JOIN sys.dm_resource_governor_configuration
CROSS JOIN sys.dm_resource_governor_resource_pools
CROSS JOIN sys.dm_resource_governor_workload_groups
CROSS JOIN sys.dm_server_audit_status
CROSS JOIN sys.dm_tran_active_snapshot_database_transactions
CROSS JOIN sys.dm_tran_active_transactions
CROSS JOIN sys.dm_tran_commit_table
CROSS JOIN sys.dm_tran_current_snapshot
CROSS JOIN sys.dm_tran_current_transaction
CROSS JOIN sys.dm_tran_database_transactions
CROSS JOIN sys.dm_tran_locks
CROSS JOIN sys.dm_tran_session_transactions
CROSS JOIN sys.dm_tran_top_version_generators
CROSS JOIN sys.dm_tran_transactions_snapshot;


SELECT
  D.name,
  D.state_desc,


--#region Big String

DATALENGTH(
N'This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.
') AS String_Length

--#endregion

FROM sys.databases AS D
WHERE 'This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.  
This is a really big string literal.
' LIKE '%%';
GO
EXEC dbo.Has_8k_String_Literal