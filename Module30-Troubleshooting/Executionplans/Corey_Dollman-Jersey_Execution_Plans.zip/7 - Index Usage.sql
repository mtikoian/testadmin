USE [master];

SET NOCOUNT ON;
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

-- Created: Plex Systems, Inc.  (Plex.com)
-- Purpose: Examine the plan cache for plans that are currently using the specified index.

DECLARE
  @Database_Name VARCHAR(50) = 'AdventureWorks2014',
  @Table_Name VARCHAR(150) = 'ProductInventory',
  --@Index_Name VARCHAR(200) = 'PK_ProductInventory_ProductID_LocationID'
  @Index_Name VARCHAR(200) = 'IX_ProductId';

DECLARE
  @SQL NVARCHAR(MAX);

SET @SQL = 
'
;WITH XMLNAMESPACES
(
  DEFAULT ''http://schemas.microsoft.com/sqlserver/2004/07/showplan''
),
Plan_Text_Filter AS
(
  SELECT
	  DB_NAME(ET.dbid) AS Database_Name,
	  OBJECT_NAME(ET.objectid, ET.dbid) AS [Object_Name],
	  P.cacheobjtype AS Cache_Obj_Type,
	  P.objtype AS Object_Type,
	  P.refcounts AS Number_Of_Plan_References,
	  P.usecounts AS Number_Of_Plan_Uses,
	  P.plan_handle AS Plan_Handle
  FROM sys.dm_exec_cached_plans AS P
  CROSS APPLY sys.dm_exec_text_query_plan(P.plan_handle, DEFAULT, DEFAULT) AS ET
  WHERE CHARINDEX(N''' + @Index_Name + ''', ET.Query_Plan) > 0
)
SELECT
	PTF.Database_Name,
	PTF.[Object_Name],
	PTF.Cache_Obj_Type,
	PTF.Object_Type,
	PTF.Number_Of_Plan_References,
	PTF.Number_Of_Plan_Uses,
	PTF.Plan_Handle,
	T.Statement_Text
FROM Plan_Text_Filter AS PTF

CROSS APPLY sys.dm_exec_query_plan(PTF.plan_handle) AS E
CROSS APPLY 
(
  SELECT
    N.Statement_Text_Node.value(''@StatementText[1]'', ''nvarchar(4000)'') AS Statement_Text
  FROM E.query_plan.nodes(''(//StmtSimple[.//Object/@Index=''''[' + @Index_Name + ']'''' and .//Object/@Table=''''[' + @Table_Name + ']''''  and .//Object/@Database=''''[' + @Database_Name + ']''''])'') AS N
  (
    Statement_Text_Node
  )
) AS T
WHERE E.query_plan.exist(''//*[@Index=''''[' + @Index_Name + ']'''' and @Table=''''[' + @Table_Name + ']'''' and @Database=''''[' + @Database_Name + ']'''']'') = 1;
';
  
EXEC sys.sp_executesql
  @SQL,
  N'/*<adhoc>Index_Usage</adhoc>*/';