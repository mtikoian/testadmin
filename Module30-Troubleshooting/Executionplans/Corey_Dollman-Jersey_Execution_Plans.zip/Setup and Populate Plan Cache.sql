USE AdventureWorks2014;

DBCC FREEPROCCACHE;

GO

IF NOT EXISTS
(
  SELECT
    *
  FROM sys.indexes AS I
  WHERE I.name = 'IX_ModifiedDate'
    AND I.object_id = OBJECT_ID('Production.ProductInventory')
)
BEGIN
  CREATE NONCLUSTERED INDEX IX_ModifiedDate
    ON Production.ProductInventory
    (
      ModifiedDate
    )
    INCLUDE
    (
      Quantity
    )
    ON [PRIMARY];
END;

IF NOT EXISTS
(
  SELECT
    *
  FROM sys.indexes AS I
  WHERE I.name = 'IX_ProductId'
    AND I.object_id = OBJECT_ID('Production.ProductInventory')
)
BEGIN
  CREATE NONCLUSTERED INDEX IX_ProductId
    ON Production.ProductInventory
    (
      ProductId
    )
    INCLUDE
    (
      Quantity
    )
    ON [PRIMARY];
END;

GO

DECLARE
  @SQL NVARCHAR(MAX),
  @Counter INT = 1,
  @Limit INT;

SELECT TOP(1)
  @Limit = P.ProductID
FROM Production.Product AS P
ORDER BY
  P.ProductID DESC;

-- Create a bunch of unparameterized queries that will appear as a one-time-use plan.
WHILE @Counter <= @Limit
BEGIN
  SET @SQL = 'SELECT * FROM Production.Product AS P OUTER APPLY dbo.ufnGetStock_SSTV(P.ProductId) AS S WHERE P.ProductId = ' + CAST(@Counter AS VARCHAR(10)) + ';';

  EXEC sys.sp_executesql @SQL;

  SET @Counter += 1 + CAST(RAND() * 3 AS INT);
END;

SET @Counter = 1

-- Create a bunch of parameterized queries that will generate multiple plans.
WHILE @Counter <= @Limit
BEGIN
  SET @SQL = 'SELECT * FROM Production.Product AS P OUTER APPLY dbo.ufnGetStock_SSTV(P.ProductId) AS S WHERE ' + REPLICATE(' ', RAND() * 10.0) + 'P.ProductId = @ProductId;';

  EXEC sys.sp_executesql 
    @SQL, 
    N'@ProductId INT',
    @Counter;

  SET @Counter += 1 + CAST(RAND() * 3.0 AS INT);
END;

GO
IF OBJECT_ID('dbo.ufnGetStock') IS NOT NULL
BEGIN
  DROP FUNCTION dbo.ufnGetStock;
END;

IF OBJECT_ID('dbo.ufnGetStock_MSTV') IS NOT NULL
BEGIN
  DROP FUNCTION dbo.ufnGetStock_MSTV;
END;

IF OBJECT_ID('dbo.ufnGetStock_SSTV') IS NOT NULL
BEGIN
  DROP FUNCTION dbo.ufnGetStock_SSTV;
END;
GO
CREATE FUNCTION [dbo].[ufnGetStock](@ProductID [int])
RETURNS [int] 
AS 
BEGIN
DECLARE @ret int;

SELECT @ret = SUM(p.[Quantity]) 
FROM [Production].[ProductInventory] p 
WHERE p.[ProductID] = @ProductID;

IF (@ret IS NULL) 
SET @ret = 0

RETURN @ret
END;
GO
CREATE FUNCTION [dbo].[ufnGetStock_MSTV](@ProductID [int])
RETURNS @Stock TABLE
(
  Stock [int] 
)
AS 
BEGIN
  INSERT @Stock
  (
    Stock
  )
  SELECT 
    ISNULL(SUM(p.[Quantity]), 0) 
  FROM [Production].[ProductInventory] p 
  WHERE p.[ProductID] = @ProductID ;
  
  RETURN;
END;
GO
CREATE FUNCTION [dbo].[ufnGetStock_SSTV](@ProductID [int])
RETURNS TABLE

RETURN
  SELECT 
    ISNULL(SUM(p.[Quantity]), 0) AS Stock
  FROM [Production].[ProductInventory] p 
  WHERE p.[ProductID] = @ProductID;
GO
IF OBJECT_ID('dbo.uspStock_Get1') IS NOT NULL
BEGIN
  DROP PROCEDURE dbo.uspStock_Get1;
END;

IF OBJECT_ID('dbo.uspStock_Get2') IS NOT NULL
BEGIN
  DROP PROCEDURE dbo.uspStock_Get2;
END;

IF OBJECT_ID('dbo.uspStock_Get3') IS NOT NULL
BEGIN
  DROP PROCEDURE dbo.uspStock_Get3;
END;
GO
CREATE PROCEDURE dbo.uspStock_Get1
AS

SELECT 
  P.ProductID,
  P.Name,
  dbo.ufnGetStock(P.ProductID) AS Stock
FROM Production.Product AS P;

GO
CREATE PROCEDURE dbo.uspStock_Get2
AS

SELECT 
  P.ProductID,
  P.Name,
  PS.Stock
FROM Production.Product AS P
CROSS APPLY dbo.ufnGetStock_MSTV(P.ProductId) AS PS;

GO
CREATE PROCEDURE dbo.uspStock_Get3
AS

SELECT 
  P.ProductID,
  P.Name,
  PS.Stock
FROM Production.Product AS P
CROSS APPLY dbo.ufnGetStock_SSTV(P.ProductId) AS PS;

GO
EXEC dbo.uspStock_Get1;
EXEC dbo.uspStock_Get2;
EXEC dbo.uspStock_Get3;

EXEC dbo.uspStock_Get1;
EXEC dbo.uspStock_Get2;
EXEC dbo.uspStock_Get3;

GO
DECLARE
  @BusinessEntityId INT,
  @Counter INT = 0;

WHILE @Counter <= 20
BEGIN
  SELECT TOP(1)
    @BusinessEntityId = E.BusinessEntityID
  FROM HumanResources.Employee AS E
  ORDER BY
    NEWID();

  EXEC dbo.uspGetEmployeeManagers @BusinessEntityId;
  EXEC dbo.uspGetManagerEmployees @BusinessEntityId;

  SET @Counter += 1;
END;
GO
IF OBJECT_ID('dbo.Product_Data_Export') IS NOT NULL
BEGIN
  DROP PROCEDURE dbo.Product_Data_Export;
END;
GO
CREATE PROCEDURE dbo.Product_Data_Export
(
  @Product_Count INT = NULL OUTPUT
)
AS

SET NOCOUNT ON;
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

-- Lots of columns and lots of data.  
-- Only 1 CPU allowed.
SELECT
  *
FROM Sales.SalesOrderHeader AS SOH
JOIN Sales.SalesOrderDetail AS SOD
  ON SOD.SalesOrderID = SOH.SalesOrderID
JOIN Sales.SpecialOfferProduct AS SOP
  ON SOP.SpecialOfferID = SOD.SpecialOfferID
  AND SOP.ProductID = SOD.ProductID
JOIN Sales.SpecialOffer AS SO
  ON SO.SpecialOfferID = SOP.SpecialOfferID
JOIN Production.Product AS P
  ON P.ProductID = SOP.ProductID
JOIN Production.ProductInventory AS PIN
  ON PIN.ProductID = P.ProductID
JOIN Purchasing.PurchaseOrderDetail AS POD
  ON POD.ProductID = P.ProductID
JOIN Purchasing.PurchaseOrderHeader AS POH
  ON POH.PurchaseOrderID = POD.PurchaseOrderID
ORDER BY
  P.ProductNumber,
  POH.PurchaseOrderID,
  SOH.PurchaseOrderNumber
OPTION (MAXDOP 1);
GO
