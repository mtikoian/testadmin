USE AdventureWorks2014;

SELECT
  R.session_id,
  R.start_time,
  --R.[sql_handle],
  --R.plan_handle,
  
  TRY_CONVERT(XML, QP.query_plan) AS query_plan_As_XML,
  
  QP.query_plan,

  DB_NAME(QP.[dbid]) AS [Database_Name],
  OBJECT_NAME(QP.objectid, QP.[dbid]) AS Obj_Name
FROM sys.dm_exec_requests AS R
JOIN sys.dm_exec_sessions AS S
  ON S.session_id = R.session_id

OUTER APPLY sys.dm_exec_text_query_plan(R.plan_handle, R.statement_start_offset, R.statement_end_offset) AS QP
WHERE S.is_user_process = 1;