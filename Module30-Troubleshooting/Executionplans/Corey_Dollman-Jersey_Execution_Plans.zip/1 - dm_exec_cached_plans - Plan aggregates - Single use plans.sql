USE AdventureWorks2014;

SELECT
  C.cacheobjtype,
  C.objtype,
  COUNT(*) AS Object_Count,
  SUM(C.size_in_bytes) / 1024.0 AS Total_Size_In_KB,
  SUM
  (
    CASE
      WHEN C.usecounts = 1 THEN 1
      ELSE 0
    END
  ) AS Objects_With_One_Use
FROM sys.dm_exec_cached_plans AS C
GROUP BY
  C.cacheobjtype,
  C.objtype
ORDER BY
  C.cacheobjtype,
  C.objtype;
