USE AdventureWorks2014;

EXEC sys.sp_recompile 'Product_Data_Export'