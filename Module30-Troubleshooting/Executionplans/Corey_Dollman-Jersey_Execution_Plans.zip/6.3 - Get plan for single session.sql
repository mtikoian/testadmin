USE AdventureWorks2014;

SELECT
  S.session_id,
  R.Plan_Handle,
  TRY_CONVERT(XML, P.query_plan) AS Query_Plan
FROM sys.dm_exec_requests AS R
JOIN sys.dm_exec_sessions AS S
  ON S.session_id = R.session_id
OUTER APPLY sys.dm_exec_text_query_plan(R.plan_handle, R.statement_start_offset, R.statement_end_offset) AS P
WHERE S.is_user_process = 1
  AND S.session_id = 54;