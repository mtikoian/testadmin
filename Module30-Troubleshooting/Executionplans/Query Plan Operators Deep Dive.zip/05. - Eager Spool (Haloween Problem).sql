use TEST

if object_id('dbo.salary', 'u') is not null
	drop table dbo.salary

create table dbo.salary (
	id int identity(1, 1) primary key,
	person_name varchar(50),
	pay_rate money
)

insert into dbo.salary (person_name, pay_rate)
values
	('John', rand(checksum(newid())) * 50000.00)
go 50000

select sum(rows) from sys.partitions where object_id = object_id('dbo.salary')

create nonclustered index ix_salary on dbo.salary (pay_rate)

update dbo.salary
set pay_rate = pay_rate * 1.1
where pay_rate < 25000.00
