use [AdventureWorks2012];
go

-- Table Scan
select [DatabaseLogID], [PostTime], [DatabaseUser],
	[Event], [Schema], [Object], [TSQL], [XmlEvent]
from [dbo].[DatabaseLog];
go

-- Clustered Index Scan (Ordered = False)
select
	[AddressID],
	[AddressLine1],
	[AddressLine2],
	[City],
	[StateProvinceID],
	[PostalCode],
	[SpatialLocation],
	[rowguid],
	[ModifiedDate]
from [Person].[Address];
go

-- Clustered Index Scan (Ordered = True)
select
	[AddressID],
	[AddressLine1],
	[AddressLine2],
	[City],
	[StateProvinceID],
	[PostalCode],
	[SpatialLocation],
	[rowguid],
	[ModifiedDate]
from [Person].[Address]
order by [AddressID];
go


-- Clustered Index Seek (Seek vs. Scan)
select
	[AddressID],
	[AddressLine1],
	[AddressLine2],
	[City],
	[StateProvinceID],
	[PostalCode],
	[SpatialLocation],
	[rowguid],
	[ModifiedDate]
from [Person].[Address]
where [AddressID] > 0;
go

-- Implicit Conversion
create nonclustered index [IX_NC_CreditCardApprovalCode]
	on [Sales].[SalesOrderHeader]
(
	[CreditCardApprovalCode] asc
)
include ( [OrderDate] );
go

select [OrderDate]
from [Sales].[SalesOrderHeader]
where [CreditCardApprovalCode] = N'328188Vi69299';
go

drop index [IX_NC_CreditCardApprovalCode]
	on [Sales].[SalesOrderHeader];
go

-- Nonclustered Index Scan
select [StateProvinceID]
from [Person].[Address]
go

-- Nonclustered Index Seek
select [StateProvinceID]
from [Person].[Address]
where [AddressID] = 1;
go

-- Bookmark Lookup
select [DatabaseLogID], [PostTime], [TSQL]
from [dbo].[DatabaseLog]
where [DatabaseLogID] = 1;
go

-- Key Lookup
select [PostalCode]
from [Person].[Address]
where [StateProvinceID] = 1;
go

/*

Scans are not always bad as well as seeks are not always good.

*/