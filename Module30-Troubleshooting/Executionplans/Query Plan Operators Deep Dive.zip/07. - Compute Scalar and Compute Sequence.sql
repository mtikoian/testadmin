use [AdventureWorks2012];
go

-- Compute Scalar
select * from Sales.SalesOrderHeader soh;
go

-- Sequence Project
select [DatabaseLogID], [PostTime], [DatabaseUser],
	[Event], [Schema], [Object], [TSQL], [XmlEvent],
	row_number() over (order by (SELECT 0)) as rn
from [dbo].[DatabaseLog];
go


-- Example with scalar function.
use TEST;
go

-- Generate some data
if object_id('dbo.MyBigTable', 'U') is not null
	drop table dbo.MyBigTable;
go

create table dbo.MyBigTable (
	keyval int not null primary key, 
	dataval int not null check (dataval between 1 and 10)
);
go

-- Insert 100000 rows
with digits
as (select d from (values (0),(1),(2),(3),(4),(5),(6),(7),(8),(9)) as d(d)) 
insert into dbo.mybigtable(keyval, dataval) 
select 10000 * tt.d + 1000 * st.d 
     + 100 * h.d + 10 * t.d + s.d + 1, 
       10 * rand(checksum(newid())) + 1 
from   digits as s,  digits as t,  digits as h, 
       digits as st, digits as tt;
go

-- Create my test function
if OBJECT_ID('dbo.fn_addone', N'FN') is not null
	drop function dbo.fn_addone;
go

create function dbo.fn_addone(@in int)
returns int
as
begin
  return @in + 1;
end
go

-- Include actual query plan: Ctrl+M
set statistics time on

select dbo.fn_addone(dataval) as val
from   dbo.MyBigTable;

select dataval + 1 as val
from   dbo.MyBigTable;

-- Actual plan is lying, let's see estimated plan
select dbo.fn_addone(dataval) as val
from   dbo.MyBigTable;