use [AdventureWorks2012];
go

-- Top Operator
select top (100) [DatabaseLogID], [PostTime], [DatabaseUser],
	[Event], [Schema], [Object], [TSQL], [XmlEvent]
from [dbo].[DatabaseLog];
go
