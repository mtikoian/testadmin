use TEST

if object_id('dbo.payments', 'u') is not null
	drop table dbo.payments

create table dbo.payments (
	client_id int,
	payment money,
	dt datetime default (getutcdate())
)

insert into dbo.payments (client_id, payment)
select cast(rand(checksum(newid())) * 5 as int), rand(checksum(newid())) * 50000
go 1000

select p1.client_id	, p1.payment, p1.dt
from dbo.payments p1
where p1.payment < (
	select avg(p2.payment)
	from dbo.payments p2
	where p2.client_id = p1.client_id
)

