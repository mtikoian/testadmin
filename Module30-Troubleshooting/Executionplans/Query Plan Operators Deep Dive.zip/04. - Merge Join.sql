use [AdventureWorks2012];
go

-- Merge Join + Compute Scalar
select *
from Sales.SalesOrderHeader soh
inner join Sales.SalesOrderDetail sod on sod.SalesOrderID = soh.SalesOrderID;
go

-- Merge Join + Sort
select *
from Sales.Customer c
inner join Sales.SalesOrderHeader soh on soh.CustomerID = c.CustomerID
option (merge join)
go

-- Example with no compute scalar
set statistics time on
select *
from Sales.SalesOrderHeader soh
inner join Sales.SalesOrderDetail sod on sod.SalesOrderID = soh.SalesOrderID;
go

select soh.SalesOrderID, sod.SalesOrderID
from Sales.SalesOrderHeader soh
inner join Sales.SalesOrderDetail sod on sod.SalesOrderID = soh.SalesOrderID;
go

-- Merge Join - Many to Many
set statistics time off
set statistics io off
set nocount on

create table T1 (a int, b int, x char(200));
create table T2 (a int, b int, x char(200));
create table T3 (a int, b int, x char(200));
create table T4 (a int, b int, x char(200));

declare @i int;
set @i = 0;
while @i < 500
begin
	insert T1 values (@i * 2, @i * 5, @i);
	insert T2 values (@i * 3, @i * 7, @i);
	insert T3 values (1, @i * 7, @i);
	insert T4 values (1, @i * 7, @i);
	set @i = @i + 1;
end

set statistics io on

select a from T1 order by a;
select a from T2 order by a;

-- Worktable
select *
from T1 join T2 on T1.a = T2.a
option (merge join);
go

-- Worktable large logical reads + large data flow after merge join
select *
from T3 join T4 on T3.a = T4.a
option (merge join);
go

drop table T1;
drop table T2;
drop table T3;
drop table T4;
go
