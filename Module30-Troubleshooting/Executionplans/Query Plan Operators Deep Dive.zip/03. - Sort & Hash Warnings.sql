USE [AdventureWorks2012];
GO

SET STATISTICS IO ON
SET STATISTICS TIME ON

-- Set Max Server Memory to 1000 Mb (easy value to play).
EXEC sp_configure 'show advanced options', 1
RECONFIGURE
EXEC sp_configure 'max server memory', 1000
RECONFIGURE
GO

-- Include Actual Execution Plan or Ctrl + M

-- Sorting, memory grant > 200%
SELECT vfs.*
FROM sys.master_files AS mf
INNER JOIN sys.dm_io_virtual_file_stats(NULL, NULL) AS vfs ON (mf.database_id = vfs.database_id AND mf.file_id = vfs.file_id)
WHERE mf.type = 0 AND mf.database_id = 2
GO

SELECT *
FROM (
	SELECT TOP (100000) *
		FROM [Production].[bigTransactionHistory]
) AS [tmp]
ORDER BY [ActualCost]
OPTION ( MAXDOP 1 )
GO

SELECT vfs.*
FROM sys.master_files AS mf
INNER JOIN sys.dm_io_virtual_file_stats(NULL, NULL) AS vfs ON (mf.database_id = vfs.database_id AND mf.file_id = vfs.file_id)
WHERE mf.type = 0 AND mf.database_id = 2
GO

-- Sort Spill example
SELECT vfs.*
FROM sys.master_files AS mf
INNER JOIN sys.dm_io_virtual_file_stats(NULL, NULL) AS vfs ON (mf.database_id = vfs.database_id AND mf.file_id = vfs.file_id)
WHERE mf.type = 0 AND mf.database_id = 2
GO

DECLARE @batch_size int = 10000

SELECT *
FROM (
	SELECT TOP (@batch_size) *
	FROM [Production].[bigTransactionHistory]
) AS [tmp]
ORDER BY [ActualCost]
OPTION ( MAXDOP 1, OPTIMIZE FOR ( @batch_size = 1 ) )

SELECT vfs.*
FROM sys.master_files AS mf
INNER JOIN sys.dm_io_virtual_file_stats(NULL, NULL) AS vfs ON (mf.database_id = vfs.database_id AND mf.file_id = vfs.file_id)
WHERE mf.type = 0 AND mf.database_id = 2
GO

-- Hash Bailout example
SELECT vfs.*
FROM sys.master_files AS mf
INNER JOIN sys.dm_io_virtual_file_stats(NULL, NULL) AS vfs ON (mf.database_id = vfs.database_id AND mf.file_id = vfs.file_id)
WHERE mf.type = 0 AND mf.database_id = 2
GO

DECLARE @batch_size1 int = 10000
DECLARE @batch_size2 int = 100000

SELECT *
FROM (
	SELECT TOP (@batch_size1) *
	FROM [Production].[bigTransactionHistory]
) AS [tmp1]
INNER HASH JOIN
(
	SELECT TOP (@batch_size2) *
	FROM [Production].[bigTransactionHistory]
) AS [tmp2] ON [tmp1].[TransactionID] = [tmp2].[TransactionID]
OPTION (OPTIMIZE FOR ( @batch_size1 = 1, @batch_size2 = 1 ))
--OPTION (RECOMPILE)
GO

SELECT vfs.*
FROM sys.master_files AS mf
INNER JOIN sys.dm_io_virtual_file_stats(NULL, NULL) AS vfs ON (mf.database_id = vfs.database_id AND mf.file_id = vfs.file_id)
WHERE mf.type = 0 AND mf.database_id = 2
GO

-- Memory Fractions
SELECT TOP (2000) *
FROM (
	SELECT TOP (5000) *
	FROM (
		SELECT TOP (10000) *
		FROM
		(
			SELECT TOP (10000) *
			FROM [Production].[bigTransactionHistory]
		) AS [tmp]
		ORDER BY [ActualCost] ASC
	) AS [tmp]
	ORDER BY [ActualCost] DESC
) AS [tmp]
ORDER BY [ActualCost] ASC
GO
