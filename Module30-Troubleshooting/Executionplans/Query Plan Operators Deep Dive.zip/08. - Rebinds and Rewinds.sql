-- Example with scalar function.
use TEST;
go

if object_id('dbo.RewindsRebindsExample', 'U') is not null
	drop table dbo.RewindsRebindsExample;

create table dbo.RewindsRebindsExample (
	id int not null identity (1, 1) primary key,
	n int not null
);
go

insert into dbo.RewindsRebindsExample (n) values (1), (1), (1), (2);

select n, (select count(*) from dbo.MyBigTable where dataval = n) as cnt
from dbo.RewindsRebindsExample;
go


/*
Nonclustered Index Spool 
Remote Query
Row Count Spool
Sort 
Table Spool 
Table-Valued Function
*/
