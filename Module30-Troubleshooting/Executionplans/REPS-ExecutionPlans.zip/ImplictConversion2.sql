/*
Turn actual execution plan on
*/
USE TestDB
GO

EXEC WillItQuery N'Arthur'

















/*
Using the correct data type in our query:
*/
    SELECT * from DemoConversion
    WHERE Names = 'Arthur'