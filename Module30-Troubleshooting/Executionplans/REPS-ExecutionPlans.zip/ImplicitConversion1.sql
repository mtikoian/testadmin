/*
DROP DATABASE testDB
*/
USE Master
GO

Create database testDB
GO


USE TestDB
GO

Create table DemoConversion (Names varchar(100))
GO

INSERT INTO DemoConversion
SELECT name
from sys.columns
GO

   Create Procedure WillItQuery @Parameter nvarchar(100) as
	   BEGIN
		  SELECT * from DemoConversion
		  WHERE Names = @Parameter
	   END
GO


    Create Nonclustered Index IX_SearchColumn ON DemoConversion (Names)