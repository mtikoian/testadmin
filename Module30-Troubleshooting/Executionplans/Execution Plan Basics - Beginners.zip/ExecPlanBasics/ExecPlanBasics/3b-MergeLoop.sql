USE AdventureWorks2012
GO

/*
DBCC FREEPROCCACHE
DBCC DROPCLEANBUFFERS
*/

-- Residual predicates

-- Look at properties and Ordered = True
-- Show Cluster Index on both tables

SELECT *
	FROM Sales.SalesOrderHeader soh
		INNER JOIN Sales.SalesOrderDetail sod
			ON sod.SalesOrderID = soh.SalesOrderID


-- FORCE NESTED LOOP
SELECT *
	FROM Sales.SalesOrderHeader soh
		INNER LOOP JOIN Sales.SalesOrderDetail sod
			ON sod.SalesOrderID = soh.SalesOrderID
-- Do not use, bad example


-- product of Detail
SELECT sod.SalesOrderID,
		p.ProductID, p.Name
	FROM Production.Product p
		INNER JOIN Sales.SalesOrderDetail sod
			ON sod.ProductID = p.ProductID	

-- Add order qty
-- cannot use merge join
-- shows problem with SELECT * - do not use unless you have to 

SET STATISTICS IO ON
SET STATISTICS TIME ON

SELECT sod.SalesOrderID, sod.OrderQty, 
		p.ProductID, p.Name
	FROM Production.Product p
		INNER JOIN Sales.SalesOrderDetail sod
			ON sod.ProductID = p.ProductID	

-- Also, see how Product is on AK_ProductName non-clustered index - because clustered index is in non-cluster index

-- Force Merge join
SELECT sod.SalesOrderID, sod.OrderQty, 
		p.ProductID, p.Name
	FROM Production.Product p
		INNER MERGE JOIN Sales.SalesOrderDetail sod
			ON sod.ProductID = p.ProductID	


-- COMPARE THE TWO TO SHOW HOW OPTIMIZER IS SMARTER THAN US