USE AdventureWorks2012
GO

SET STATISTICS IO ON
SET STATISTICS TIME ON
GO

-- Nested Loop

-- Simple Nested Loop
-- Seek on cust CustomerID, seek on soh CustomerID
-- No clustered index seek becuase clustered index column(s) is in the non-clustered index


-- TYPE FROM FOLLOWING SELECT
/* Customer Sales Count
-- 11091 28			-- 30095 12			-- 30099 1			*/
/*	SELECT cust.CustomerID, soh.SalesOrderID
		FROM Sales.Customer cust
			INNER JOIN Sales.SalesOrderHeader soh
				ON soh.CustomerID = cust.CustomerID
		WHERE cust.CustomerID = 11091
*/


-- Add additional soh column needs lookup
	-- Added an Index Seek with Key Lookup
-- ADD MORE COLUMNS - , soh.AccountNumber, soh.OrderDate


-- no longer covering
-- still uses the CustomerID index



-- Add Covering Index to get rid of Key Lookup
/*

IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[Sales].[SalesOrderHeader]') 
	AND name = N'idxSalesOrderHeader_CustomerID_IncludeAccountNumberOrderDate')

DROP INDEX [idxSalesOrderHeader_CustomerID_IncludeAccountNumberOrderDate] ON [Sales].[SalesOrderHeader]
GO
	CREATE NONCLUSTERED INDEX idxSalesOrderHeader_CustomerID_IncludeAccountNumberOrderDate
		ON [Sales].[SalesOrderHeader] ([CustomerID])
		INCLUDE (AccountNumber, OrderDate)
GO
*/


-- COPY SAME QUERY AND RUN AGAIN


-- ADD ORDER BY      ORDER BY AccountNumber



-- ADD IN CLAUSE     WHERE cust.CustomerID IN ( 11091, 30095, 30099)



