USE [AdventureWorks2012]
GO

SET SHOWPLAN_TEXT ON
GO
-- Select all columns
SELECT [DatabaseLogID]      ,[PostTime]      ,[DatabaseUser]      ,[Event]
      ,[Schema]      ,[Object]      ,[TSQL]      ,[XmlEvent]
  FROM [dbo].[DatabaseLog]

SELECT [SalesOrderID]      ,[RevisionNumber]      ,[OrderDate]      ,[DueDate]      ,[ShipDate]
      ,[Status]      ,[SubTotal]      ,[TaxAmt]      ,[Freight]      ,[TotalDue]
  FROM [Sales].[SalesOrderHeader]
  WHERE SubTotal < 100

SET SHOWPLAN_TEXT OFF
GO


-- Graphical and Missing index
SELECT [SalesOrderID]      ,[RevisionNumber]      ,[OrderDate]      ,[DueDate]      ,[ShipDate]
      ,[Status]      ,[SubTotal]      ,[TaxAmt]      ,[Freight]      ,[TotalDue]
  FROM [Sales].[SalesOrderHeader]
  WHERE SubTotal < 100


-- Delete created Index
DROP INDEX idxDelete1 ON [Sales].[SalesOrderHeader] 


-- 2012 new features
declare @SOID int
SET @SOID = 897

-- Warning about convertion
-- Look at Properties of SELECT statement
	-- New Memory Grant
	-- New Warnings

SELECT soh.CustomerID, soh.SalesOrderNumber, soh.OrderDate
		, sod.ProductID
		, (SELECT Name FROM Production.Product p WHERE p.ProductID = sod.ProductID)
		, sod.OrderQty, sod.LineTotal
	FROM Sales.SalesOrderHeader soh
		INNER JOIN Sales.SalesOrderDetail sod
			ON sod.SalesOrderID = soh.SalesOrderID
	WHERE sod.ProductID = @SOID
