USE [AdventureWorks2012]
GO
-- use where clause
SET STATISTICS IO ON
GO

DBCC FREEPROCCACHE
GO

-- Drop Primary key Cluster and nonlcustered if exists

/****** Object:  Index [idxDatabaseLog_DatabaseUser]    Script Date: 10/02/2010 11:10:08 ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DatabaseLog]') AND name = N'idxDatabaseLog_DatabaseUser')
DROP INDEX [idxDatabaseLog_DatabaseUser] ON [dbo].[DatabaseLog] WITH ( ONLINE = OFF )
GO
/****** Object:  Index [PK_DatabaseLog]    Script Date: 10/02/2010 11:01:57 ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DatabaseLog]') AND name = N'PK_DatabaseLog')
ALTER TABLE [dbo].[DatabaseLog] DROP CONSTRAINT [PK_DatabaseLog]
GO
/****** Object:  Index [PK_DatabaseLog_DatabaseLogID]    Script Date: 10/02/2010 11:01:57 ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DatabaseLog]') AND name = N'PK_DatabaseLog_DatabaseLogID')
ALTER TABLE [dbo].[DatabaseLog] DROP CONSTRAINT [PK_DatabaseLog_DatabaseLogID]
GO

/****** Object:  Index [idxDatabaseLog_DatabaseUserScehmaObject]    Script Date: 10/02/2010 11:10:37 ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DatabaseLog]') AND name = N'idxDatabaseLog_DatabaseUserScehmaObject')
DROP INDEX [idxDatabaseLog_DatabaseUserScehmaObject] ON [dbo].[DatabaseLog] WITH ( ONLINE = OFF )
GO
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DatabaseLog]') 
	AND name = N'idxDatabaseLog_DatabaseUser_CoverColumns')
DROP INDEX [idxDatabaseLog_DatabaseUser_CoverColumns] ON [dbo].[DatabaseLog] WITH ( ONLINE = OFF )
GO
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[Person].[Address]') 
	AND name = N'idxPersonAddress_City')
DROP INDEX [idxPersonAddress_City] ON [Person].[Address] WITH ( ONLINE = OFF )
GO
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[HumanResources].[Employee]') 
	AND name = N'idxEmployeeTitleContactID')
DROP INDEX [idxEmployeeTitleContactID] ON [HumanResources].[Employee] WITH ( ONLINE = OFF )
GO



-- 1 display estimated plan
-- 2 - Graphical plan, then flow

-- Select all columns
SELECT [DatabaseLogID]      ,[PostTime]      ,[DatabaseUser]      ,[Event]
      ,[Schema]      ,[Object]      ,[TSQL]      ,[XmlEvent]
  FROM [dbo].[DatabaseLog]

-- Display Table Columns, key and indexes to show no indexes or clustered index


-- demo table scan with no where
-- then with where

SELECT [DatabaseLogID]      ,[PostTime]      ,[DatabaseUser]      ,[Event]
      ,[Schema]      ,[Object]      ,[TSQL]      ,[XmlEvent]
  FROM [dbo].[DatabaseLog]
WHERE [DatabaseUser] = N'sys'




-- add primary key clusters


/****** Object:  Index [PK_DimAccount]    Script Date: 10/02/2010 11:00:19 ******/
ALTER TABLE [dbo].[DatabaseLog] 
	ADD  CONSTRAINT [PK_DatabaseLog] 
		PRIMARY KEY CLUSTERED 
		([DatabaseLogID] ASC) 

-- Select all columns
SELECT [DatabaseLogID]      ,[PostTime]      ,[DatabaseUser]      ,[Event]
      ,[Schema]      ,[Object]      ,[TSQL]      ,[XmlEvent]
  FROM [dbo].[DatabaseLog]

-- use where clause and limit columns
-- still clustered index scan
SELECT [DatabaseLogID], [PostTime], [Schema], [Object]      ,[TSQL]
  FROM [dbo].[DatabaseLog]
WHERE [DatabaseUser] = N'sys'

-- Cost 0.42


-- NonClustered Index Scan

CREATE NONCLUSTERED INDEX [idxDatabaseLog_DatabaseUserScehmaObject] 
	ON [dbo].[DatabaseLog]
(	[DatabaseUser], [Schema], [Object] )


-- what is the cost
 -- Cover Index Seek, Nested Loop & Key Lookup Properties
SELECT [DatabaseLogID], [PostTime], [Schema], [Object]      ,[TSQL]
  FROM [dbo].[DatabaseLog]
 WHERE [DatabaseUser] = N'sys'

-- Show what happens with more dense data
SELECT [DatabaseLogID], [PostTime], [Schema], [Object]      ,[TSQL]
  FROM [dbo].[DatabaseLog]
  WHERE [DatabaseUser] = N'dbo'


-- see COUNT for SYS versus DBO
SELECT [DatabaseUser], COUNT(1)
	FROM [dbo].[DatabaseLog]
	GROUP BY [DatabaseUser]



-- test 3 column query
SELECT [DatabaseUser], [Schema], [Object]
  FROM [dbo].[DatabaseLog]


-- WHY NOT TO DO SELECT *
SELECT *
  FROM [dbo].[DatabaseLog]


-- LOOK AT STATISTICS IO Difference


-- test query plan Non-Clustered Index Seek
 

SELECT [DatabaseUser], [Schema], [Object]
  FROM [dbo].[DatabaseLog]
WHERE [DatabaseUser] = N'dbo'


-- Non Clustered index seek with Lookup
-- NonClustered Index seek w/ Key Lookup

-- Review Tool Tip and Lookup columns

SELECT [PostTime], [Schema], [Object]      ,[TSQL]
  FROM [dbo].[DatabaseLog]
WHERE [DatabaseUser] = N'sys'


-- Why a index seek even though DatabaseLogID not in index (create statement)
SELECT [DatabaseLogID], [Schema], [Object]
  FROM [dbo].[DatabaseLog]
WHERE [DatabaseUser] = 'sys'

/*
CREATE NONCLUSTERED INDEX [idxDatabaseLog_DatabaseUserScehmaObject] 
	ON [dbo].[DatabaseLog]
(	[DatabaseUser], [Schema], [Object] )
*/

-- show statistics determine scan versus seek
DBCC FREEPROCCACHE
DBCC DROPCLEANBUFFERS 


SET STATISTICS IO ON
SET STATISTICS TIME ON
GO


-- See Index Seek/Scan with Lookup
	-- Then create covering index

SELECT [DatabaseLogID], [PostTime], [DatabaseUser], [Event], [Schema], [Object]      
  FROM [dbo].[DatabaseLog]
WHERE [DatabaseUser] = 'sys'


-- look at index with no include columns

CREATE NONCLUSTERED INDEX [idxDatabaseLog_DatabaseUser_CoverColumns] 
	ON [dbo].[DatabaseLog]
(	[DatabaseUser] ASC )
INCLUDE ([PostTime], [Event], [Schema], [Object])


-- Remove Key Lookup with Covering Index
SELECT [DatabaseLogID], [PostTime], [DatabaseUser], [Event], [Schema], [Object]      
  FROM [dbo].[DatabaseLog]
WHERE [DatabaseUser] = 'sys'





-- Remove Cluster index and show RID lookup
/****** Object:  Index [PK_DatabaseLog]    Script Date: 10/02/2010 11:01:57 ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DatabaseLog]') AND name = N'PK_DatabaseLog')
ALTER TABLE [dbo].[DatabaseLog] DROP CONSTRAINT [PK_DatabaseLog]
GO
-- test query plan - AND LOB lookups
SELECT [DatabaseLogID], [PostTime], [Schema], [Object]      ,[TSQL]
  FROM [dbo].[DatabaseLog]
WHERE [DatabaseUser] = 'sys'
