USE [AdventureWorks2012]
GO

DBCC FREEPROCCACHE
DBCC DROPCLEANBUFFERS
-- Cleanup database

IF  EXISTS 
	(SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[Sales].[SalesOrderHeader]') 
		AND name = N'idxSalesOrderHeader_CustomerID_IncludeAccountNumberOrderDate')
DROP INDEX [idxSalesOrderHeader_CustomerID_IncludeAccountNumberOrderDate] ON [Sales].[SalesOrderHeader]
GO
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[Sales].[SalesOrderHeader]') 
	AND name = N'idxSalesOrderHeader_CustomerID_IncludeAccountNumberOrderDate')

DROP INDEX [idxSalesOrderHeader_CustomerID_IncludeAccountNumberOrderDate] ON [Sales].[SalesOrderHeader]
GO

IF  EXISTS 
	(SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[Sales].[SalesOrderHeader]') 
		AND name = N'idxSalesOrderHeader_ShipDate_IncludeOrderDate')
DROP INDEX [idxSalesOrderHeader_ShipDate_IncludeOrderDate] ON [Sales].[SalesOrderHeader]
GO
IF  EXISTS 
	(SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[Sales].[SalesOrderHeader]') 
		AND name = N'idxSalesOrderHeader_ShipDate')
DROP INDEX [idxSalesOrderHeader_ShipDate] ON [Sales].[SalesOrderHeader]
GO
IF  EXISTS 
	(SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[Sales].[SalesOrderHeader]') 
		AND name = N'idxSalesOrderHeader_ShipDate_IncludeSalesOrderIDOrderDate')
DROP INDEX [idxSalesOrderHeader_ShipDate_IncludeSalesOrderIDOrderDate] ON [Sales].[SalesOrderHeader]
GO
IF  EXISTS 
	(SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[Sales].[SalesOrderHeader]') 
		AND name = N'idxSalesOrderHeader_OrderDate_IncludeShipDate')
DROP INDEX [idxSalesOrderHeader_OrderDate_IncludeShipDate] ON [Sales].[SalesOrderHeader]
GO



IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[Production].[bigTransactionHistory]') 
		AND name = N'idxbigTransactionHistory_ProductID_IncludeTransDateActualCost')
DROP INDEX [idxbigTransactionHistory_ProductID_IncludeTransDateActualCost] ON [Production].[bigTransactionHistory]
GO
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[Production].[bigTransactionHistory]') 
		AND name = N'idxbigTransactionHistory_ProductIDActualCost')
DROP INDEX [idxbigTransactionHistory_ProductIDActualCost] ON [Production].[bigTransactionHistory]
GO
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[Production].[bigTransactionHistory]') 
		AND name = N'idxbigTransactionHistory_TranDate_IncludeProdIDActCost')
DROP INDEX [idxbigTransactionHistory_TranDate_IncludeProdIDActCost] ON [Production].[bigTransactionHistory]
GO
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[Production].[bigTransactionHistory]') 
		AND name = N'idxbigTransactionHistory_ActualCost_IncludeProductID')
DROP INDEX [idxbigTransactionHistory_ActualCost_IncludeProductID] ON [Production].[bigTransactionHistory]
GO


IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[Sales].[SalesOrderDetail]') AND name = N'idxDeleteAfteruse')
DROP INDEX [idxDeleteAfteruse] ON [Sales].[SalesOrderDetail]
GO


IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[Production].[mediumTransactionHistory]') 
	AND name = N'idxmediumTransactionHistory_ProductID_IncludeTransDateActualCost')
DROP INDEX idxmediumTransactionHistory_ProductID_IncludeTransDateActualCost ON [Production].[mediumTransactionHistory]
GO
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[Production].[mediumTransactionHistory]') 
	AND name = N'idxmediumTransactionHistory_ActualCode_Include_ProductID')
DROP INDEX idxmediumTransactionHistory_ActualCode_Include_ProductID ON [Production].[mediumTransactionHistory]
GO
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[Production].[mediumTransactionHistory]') 
	AND name = N'idxmediumTransactionHistory_ProductIDActualCost')
DROP INDEX [idxmediumTransactionHistory_ProductIDActualCost] ON [Production].[mediumTransactionHistory]
GO

USE [AdventureWorksDW]
IF  EXISTS 
	(SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[Sales].[dimCustomer]') 
		AND name = N'idxDimcustomerDelete')
DROP INDEX [idxDimcustomerDelete] ON [dbo].[dimCustomer]
GO

