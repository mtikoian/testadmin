USE AdventureWorks2012
GO

SET STATISTICS IO ON
SET STATISTICS TIME ON
GO


-- Scaler Compute LName + FName
-- See Properties of Scaler
SELECT e.NationalIDNumber
		, p.[LastName] + ', ' + p.[FirstName] AS EmployeeName
		, p.Title
	FROM HumanResources.Employee e
		INNER JOIN Person.Person p ON p.BusinessEntityID = e.BusinessEntityID
			INNER JOIN Person.BusinessEntityAddress bea ON bea.BusinessEntityID = p.BusinessEntityID AND bea.AddressTypeID = 2
				INNER JOIN Person.[Address] pa ON pa.AddressID = bea.AddressID


-- Add order by
SELECT  p.Title
		, pa.City
		,p.[LastName] + ', ' + p.[FirstName] AS EmployeeName
	FROM HumanResources.Employee e
		INNER JOIN Person.Person p ON p.BusinessEntityID = e.BusinessEntityID
			INNER JOIN Person.BusinessEntityAddress bea ON bea.BusinessEntityID = p.BusinessEntityID AND bea.AddressTypeID = 2
				INNER JOIN Person.[Address] pa ON pa.AddressID = bea.AddressID
	ORDER BY pa.City, p.Title

-- another simple sort
SELECT ProductID, Shelf, Bin, Quantity
FROM [Production].[ProductInventory]
ORDER BY [Shelf]

-- Stream Aggregate
SELECT  P.Name, total_qty = SUM(I.Quantity), Avg_qty = AVG(I.Quantity)
	FROM Production.Product P
		JOIN Production.ProductInventory I  ON  I.ProductID = P.ProductID
	GROUP BY P.Name


-- 870 (lots)
-- 897 (2)

SELECT soh.CustomerID, soh.SalesOrderNumber, soh.OrderDate
		, sod.ProductID
		, (SELECT Name FROM Production.Product p WHERE p.ProductID = sod.ProductID)
		, sod.OrderQty, sod.LineTotal
	FROM Sales.SalesOrderHeader soh
		INNER JOIN Sales.SalesOrderDetail sod
			ON sod.SalesOrderID = soh.SalesOrderID
	WHERE sod.ProductID = 870

SELECT soh.CustomerID, soh.SalesOrderNumber, soh.OrderDate
		, sod.ProductID
		, (SELECT Name FROM Production.Product p WHERE p.ProductID = sod.ProductID)
		, sod.OrderQty, sod.LineTotal
	FROM Sales.SalesOrderHeader soh
		INNER JOIN Sales.SalesOrderDetail sod
			ON sod.SalesOrderID = soh.SalesOrderID
	WHERE sod.ProductID = 897

--- ***** Save XML and display in PlanExplorer




-- Spools the table (Products) because it has to use it over and over again
-- Product table is on the bottom of the Nested loop
SELECT soh.CustomerID, soh.SalesOrderNumber, soh.OrderDate
		, sod.ProductID
		, (SELECT Name FROM Production.Product p WHERE p.ProductID = sod.ProductID)
		, sod.OrderQty, sod.LineTotal
	FROM Sales.SalesOrderHeader soh
		INNER JOIN Sales.SalesOrderDetail sod
			ON sod.SalesOrderID = soh.SalesOrderID
	WHERE sod.ProductID = 870

-- proper join removes Table Spool
-- see how the product table is now on the top of the Nested loop
SELECT soh.CustomerID, soh.SalesOrderNumber, soh.OrderDate
		, sod.ProductID
		, Name AS ProductName
		, sod.OrderQty, sod.LineTotal
	FROM Sales.SalesOrderHeader soh
		INNER JOIN Sales.SalesOrderDetail sod
			ON sod.SalesOrderID = soh.SalesOrderID
		  INNER JOIN Production.Product p 
			ON p.ProductID = sod.ProductID
	WHERE sod.ProductID = 870
