USE [AdventureWorks2008R2]
GO
-- Include Execution Plan
-- run and look at messages

SELECT TOP 100 *
	FROM Sales.SalesOrderHeader

-- Logical and Physical IO calls (per Data Page 8k data page
SET STATISTICS IO ON
GO

SELECT TOP 100 *
	FROM Sales.SalesOrderHeader


-- Time in CPU and Actual time to execute
SET STATISTICS TIME ON
GO

SELECT TOP 100 *
	FROM Sales.SalesOrderHeader

DBCC FREEPROCCACHE
DBCC DROPCLEANBUFFERS 


-- TotalDue Computed Column

SELECT [SalesOrderID]      ,[RevisionNumber]      ,[OrderDate]      ,[DueDate]      ,[ShipDate]
      ,[Status]      ,[SubTotal]      ,[TaxAmt]      ,[Freight]      ,[TotalDue]
  FROM [Sales].[SalesOrderHeader]
  WHERE SubTotal < 100
  

/*

Scalar Operator
	(isnull([AdventureWorks2008R2].[Sales].[SalesOrderHeader].[SubTotal]
	+
	[AdventureWorks2008R2].[Sales].[SalesOrderHeader].[TaxAmt]
	+
	[AdventureWorks2008R2].[Sales].[SalesOrderHeader].[Freight],($0.0000)))



*/


-- show estimated text plan, query is not executed
SET SHOWPLAN_ALL ON;
GO

SELECT [SalesOrderID]      ,[RevisionNumber]      ,[OrderDate]      ,[DueDate]      ,[ShipDate]
      ,[Status]      ,[SubTotal]      ,[TaxAmt]      ,[Freight]      --,[TotalDue]
  FROM [Sales].[SalesOrderHeader]
  WHERE SubTotal < 100

-- Control T for Text
-- run again
SELECT [SalesOrderID]      ,[RevisionNumber]      ,[OrderDate]      ,[DueDate]      ,[ShipDate]
      ,[Status]      ,[SubTotal]      ,[TaxAmt]      ,[Freight]      --,[TotalDue]
  FROM [Sales].[SalesOrderHeader]
  WHERE SubTotal < 100


-- turn off 
-- Output to grid
SET SHOWPLAN_ALL OFF;
GO

SELECT [SalesOrderID]      ,[RevisionNumber]      ,[OrderDate]      ,[DueDate]      ,[ShipDate]
      ,[Status]      ,[SubTotal]      ,[TaxAmt]      ,[Freight]      --,[TotalDue]
  FROM [Sales].[SalesOrderHeader]
  WHERE SubTotal < 100


-- Show actual query plan
SET STATISTICS PROFILE ON
GO

SELECT [SalesOrderID]      ,[RevisionNumber]      ,[OrderDate]      ,[DueDate]      ,[ShipDate]
      ,[Status]      ,[SubTotal]      ,[TaxAmt]      ,[Freight]      --,[TotalDue]
  FROM [Sales].[SalesOrderHeader]
  WHERE SubTotal < 100


-- Turn Off
SET STATISTICS PROFILE OFF
GO


-- Right click and tunr off Include Execution Plan
-- Show Actual XML Plan

-- Show Missing Index feature

SET STATISTICS XML ON
GO

SELECT [SalesOrderID]      ,[RevisionNumber]      ,[OrderDate]      ,[DueDate]      ,[ShipDate]
      ,[Status]      ,[SubTotal]      ,[TaxAmt]      ,[Freight]      --,[TotalDue]
  FROM [Sales].[SalesOrderHeader]
  WHERE SubTotal < 100

SET STATISTICS XML OFF
GO

SET SHOWPLAN_XML ON;
GO

SELECT *
FROM [dbo].[DatabaseLog];

SET SHOWPLAN_XML OFF;
GO