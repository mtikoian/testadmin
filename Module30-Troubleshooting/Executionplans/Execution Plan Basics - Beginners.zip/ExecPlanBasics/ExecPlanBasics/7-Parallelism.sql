-- Insert that has to update indexes
USE [AdventureWorks2012]
GO
-- Statistics

sp_helpstats 'Sales.SalesOrderDetail', 'ALL'

DBCC SHOW_STATISTICS('Sales.SalesOrderDetail', IX_SalesOrderDetail_ProductID)

DBCC FREEPROCCACHE
DBCC DROPCLEANBUFFERS 


;
With CTETerritory
As
(   Select cr.Name as CountryName, CustomerID, 
                Sum(TotalDue) As TotalAmt
   From Sales.SalesOrderHeader soh 
	  inner join Sales.SalesTerritory ter on soh.TerritoryID=ter.TerritoryID
   inner join Person.CountryRegion cr  on cr.CountryRegionCode=ter.CountryRegionCode
   Group By cr.Name, CustomerID
)
Select *, Rank() Over (Order by TotalAmt DESC) as OverallRank,
Rank() Over
     (Partition By CountryName Order By TotalAmt DESC,
            CustomerID DESC) As NationalRank
From CTETerritory
 OPTION (MAXDOP 2)
 