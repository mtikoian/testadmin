USE AdventureWorks2012
GO
DBCC FREEPROCCACHE
DBCC DROPCLEANBUFFERS

SET STATISTICS IO ON
GO

-- Most popular product is 870

SELECT p.ProductID, sod.SalesOrderID, sod.OrderQty
	FROM Production.Product p
		INNER JOIN Sales.SalesOrderDetail sod
			ON sod.ProductID = p.ProductID
	WHERE p.ProductID = 870


-- Add a second product
-- Distribution of statistics gives optimizer and idea and what to do
SELECT p.ProductID, sod.SalesOrderID, sod.OrderQty
	FROM Production.Product p
		INNER JOIN Sales.SalesOrderDetail sod
			ON sod.ProductID = p.ProductID
	WHERE p.ProductID IN ( 870, 871)

SELECT p.ProductID, sod.SalesOrderID, sod.OrderQty
	FROM Production.Product p
		INNER LOOP JOIN Sales.SalesOrderDetail sod WITH (INDEX(0))
			ON sod.ProductID = p.ProductID
	WHERE p.ProductID IN ( 870, 871)

-- It takes the full set from both and hashes together


-- less dense products
SELECT p.ProductID, sod.SalesOrderID, sod.OrderQty
	FROM Production.Product p
		INNER JOIN Sales.SalesOrderDetail sod
			ON sod.ProductID = p.ProductID
	WHERE p.ProductID IN ( 897, 942, 943)

-- Show Actual versus Estimated number of rows on pipe
-- Show statistics 

DBCC SHOW_STATISTICS ("Sales.SalesOrderDetail", IX_SalesOrderDetail_ProductID)
	WITH HISTOGRAM

-- Try a range search
SELECT p.ProductID, sod.SalesOrderID, sod.OrderQty
	FROM Production.Product p
		INNER JOIN Sales.SalesOrderDetail sod
			ON sod.ProductID = p.ProductID
	WHERE p.ProductID > 869 and p.ProductID < 872


-- Compare
SELECT p.ProductID, sod.SalesOrderID, sod.OrderQty
	FROM Production.Product p
		INNER JOIN Sales.SalesOrderDetail sod
			ON sod.ProductID = p.ProductID
	WHERE p.ProductID IN ( 870, 871)
