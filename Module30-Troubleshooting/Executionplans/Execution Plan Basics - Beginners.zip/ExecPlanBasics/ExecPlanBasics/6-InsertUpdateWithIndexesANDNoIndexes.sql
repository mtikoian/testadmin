-- Insert that has to update indexes
USE [AdventureWorks2012]
GO

/****** Object:  Index [idxDatabaseLog_DatabaseUser]    Script Date: 10/02/2010 11:10:08 ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DatabaseLog]') AND name = N'idxDatabaseLog_DatabaseUser')
DROP INDEX [idxDatabaseLog_DatabaseUser] ON [dbo].[DatabaseLog] WITH ( ONLINE = OFF )
GO
/****** Object:  Index [PK_DatabaseLog]    Script Date: 10/02/2010 11:01:57 ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DatabaseLog]') AND name = N'PK_DatabaseLog')
ALTER TABLE [dbo].[DatabaseLog] DROP CONSTRAINT [PK_DatabaseLog]
GO
/****** Object:  Index [idxDatabaseLog_DatabaseUserScehmaObject]    Script Date: 10/02/2010 11:10:37 ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DatabaseLog]') AND name = N'idxDatabaseLog_DatabaseUserScehmaObject')
DROP INDEX [idxDatabaseLog_DatabaseUserScehmaObject] ON [dbo].[DatabaseLog] WITH ( ONLINE = OFF )
GO
/****** Object:  Index [idxDatabaseLog_DatabaseUserScehmaObject]    Script Date: 10/02/2010 11:10:37 ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DatabaseLog]') 
	AND name = N'idxDatabaseLog_DatabaseUser_CoverColumns')
DROP INDEX [idxDatabaseLog_DatabaseUser_CoverColumns] ON [dbo].[DatabaseLog] WITH ( ONLINE = OFF )
GO

SET STATISTICS IO ON
SET STATISTICS TIME ON
GO

INSERT INTO [dbo].[DatabaseLog]
	([PostTime], [DatabaseUser], [Event] ,[Schema] ,[Object]
      ,[TSQL], [XmlEvent])
 VALUES (GETDATE(), 'dbo', 'CRATE STATISTICS', 'Sales', 'SalesOrderHeader', 'EXECUTE...', '')
GO

-- copy statistics 
/*

*/

-- add indexes
ALTER TABLE [dbo].[DatabaseLog] 
	ADD  CONSTRAINT [PK_DatabaseLog] 
		PRIMARY KEY CLUSTERED 
		([DatabaseLogID] ASC) 
GO
CREATE NONCLUSTERED INDEX [idxDatabaseLog_DatabaseUserScehmaObject] 
	ON [dbo].[DatabaseLog]
(	[DatabaseUser], [Schema], [Object] )
GO
CREATE NONCLUSTERED INDEX [idxDatabaseLog_DatabaseUser] 
	ON [dbo].[DatabaseLog]
(	[DatabaseUser] ASC )
GO
CREATE NONCLUSTERED INDEX [idxDatabaseLog_DatabaseUser_CoverColumns] 
	ON [dbo].[DatabaseLog]
(	[DatabaseUser] ASC )
INCLUDE ([Schema], [Object])
GO

INSERT INTO [dbo].[DatabaseLog]
	([PostTime], [DatabaseUser], [Event] ,[Schema] ,[Object]
      ,[TSQL], [XmlEvent])
 VALUES (GETDATE(), 'dbo', 'CRATE STATISTICS', 'Sales', 'SalesOrderHeader', 'EXECUTE...', '')
GO


-- Update statement
BEGIN TRANSACTION

UPDATE [dbo].[DatabaseLog]
	SET [DatabaseUser] = 'dbo'
	WHERE [DatabaseUser] = 'sys'
	
-- ROLLBACK TRANSACTION