/*
	6/19/2014: Ed Pollack
	
	Diving into Query Excecution Plans

	This SQL provides query examples that are used to illustrate a variety of query execution
	plans and how to use this information to improve your ability to optimize queries and
	understand what is happening when a SQL statement is executed.
*/
USE AdventureWorks
GO

SET STATISTICS IO ON
SET NOCOUNT ON

/*****************************************************************************************************************
*********************************************Using Execution Plans************************************************
******************************************************************************************************************/

CREATE STATISTICS STATS_TEST_MODEL_NAME ON Production.ProductModel (Name)

DBCC SHOW_STATISTICS ("Production.ProductModel", STATS_TEST_MODEL_NAME)

-- The first example: a simple select from one table
SELECT
	TOP 1 *
FROM Production.ProductModel

-- Example of a query with more steps
SELECT
	*
FROM Production.Product PRODUCT
LEFT JOIN Production.UnitMeasure UNITS
ON PRODUCT.SizeUnitMeasureCode = UNITS.UnitMeasureCode
INNER JOIN Production.ProductModel MODEL
ON PRODUCT.ProductModelID = MODEL.ProductModelID
WHERE MODEL.Name LIKE 'C%'

-- Query execution plans that get too large to fit on the screen should be analyzed in sections, rather than as individual steps.
-- SQL Sentry Plan Explorer (or a similar free/paid tool) can greatly help with visualizing a large execution plan:
SELECT TOP 25
	*
FROM HumanResources.vJobCandidateEducation

DROP STATISTICS Production.ProductModel.STATS_TEST_MODEL_NAME

/*****************************************************************************************************************
*************************************************Table Access*****************************************************
******************************************************************************************************************/
-- This example shows a table scan on a heap
CREATE TABLE test_table
(	id INT,
	my_data VARCHAR(25),
	another_id INT)
INSERT INTO test_table (id, my_data, another_id) VALUES (1, '', 64)
INSERT INTO test_table (id, my_data, another_id) VALUES (2, 'some stuff', 121)
INSERT INTO test_table (id, my_data, another_id) VALUES (3, NULL, 1024)

SELECT
	my_data
FROM test_table
WHERE id = 2

DROP TABLE test_table

-- This example shows a clustered index scan:
SELECT
	TOP 1 *
FROM person.person

-- This example shows an index seek
SELECT
	CUSTOMER.CustomerID,
	CUSTOMER.AccountNumber
FROM sales.Customer CUSTOMER
WHERE CUSTOMER.AccountNumber LIKE 'AW0001%'

-- This is a query that illustrates a key lookup
SELECT
	NationalIDNumber,
	HireDate,
	MaritalStatus
FROM HumanResources.Employee
WHERE NationalIDNumber = 14417807
GO

-- To get rid of the key lookup, you can alter the query to retrieve different data...
-- ...or create a covering index that includes these columns:
CREATE NONCLUSTERED INDEX NCI_HumanResources_Employee_Covering ON HumanResources.Employee
(	NationalIDNumber	)
INCLUDE
(	HireDate, MaritalStatus)

-- Now we get an index seek and faster performance, BUT at the cost of adding an index.
SELECT
	NationalIDNumber,
	HireDate,
	MaritalStatus
FROM HumanResources.Employee
WHERE NationalIDNumber = '14417807'
GO

DROP INDEX NCI_HumanResources_Employee_Covering ON HumanResources.Employee

/*****************************************************************************************************************
*****************************************************Joins********************************************************
******************************************************************************************************************/
/*
	Different data sets will be joined using one of three types of joins: MERGE JOIN, NESTED LOOP JOIN, and HASH JOIN.
	If the wrong join is used in a particular case, due to outdated statistics, missing indexes, or another problem,
	this could lead to very inefficient query execution.
*/

-- This is an example of a nested loops join.  
SELECT
	Employee.BusinessEntityID,
	Employee.HireDate,
	Person.AdditionalContactInfo
FROM HumanResources.Employee
INNER JOIN Person.Person
ON Employee.BusinessEntityID = Person.BusinessEntityID

-- This is an example of a hash join.  Since the UnitMeasure table is very small, it's efficient to create a hash table on
-- it and sort through the Product table using it.  Note that a worktable was created to handle the hash process.
SELECT
	Product.Name,
	product.ProductID,
	UnitMeasure.Name
FROM Production.Product
INNER JOIN production.UnitMeasure
ON Production.UnitMeasure.UnitMeasureCode = Product.SizeUnitMeasureCode

-- This is an example of a simple merge join.  Since both inputs of the join are indexed (sorted), they can be quickly lined up and
-- joined together without the need for any additional temporary storage or row-by-row work.  Note that no worktable is needed here.
SELECT
	*
FROM Production.ProductModel
LEFT JOIN Production.ProductModelIllustration
ON Production.ProductModelIllustration.ProductModelID = Production.ProductModel.ProductModelID -- These are both clustered indexes on each table.
WHERE ProductModel.Instructions IS NOT NULL

/*****************************************************************************************************************
************************************************Display Options***************************************************
******************************************************************************************************************/
SET SHOWPLAN_ALL ON
GO
SELECT
	*
FROM Production.ProductModel
LEFT JOIN Production.ProductModelIllustration
ON Production.ProductModelIllustration.ProductModelID = Production.ProductModel.ProductModelID -- These are both clustered indexes on each table.
WHERE ProductModel.Instructions IS NOT NULL
GO
SET SHOWPLAN_ALL OFF
GO

SET SHOWPLAN_TEXT ON
GO
SELECT
	*
FROM Production.ProductModel
LEFT JOIN Production.ProductModelIllustration
ON Production.ProductModelIllustration.ProductModelID = Production.ProductModel.ProductModelID -- These are both clustered indexes on each table.
WHERE ProductModel.Instructions IS NOT NULL
GO
SET SHOWPLAN_TEXT OFF
GO

SET STATISTICS PROFILE ON;
SELECT
	*
FROM Production.ProductModel
LEFT JOIN Production.ProductModelIllustration
ON Production.ProductModelIllustration.ProductModelID = Production.ProductModel.ProductModelID -- These are both clustered indexes on each table.
WHERE ProductModel.Instructions IS NOT NULL
SET STATISTICS PROFILE OFF;

SET STATISTICS IO ON;
SELECT
	*
FROM Production.ProductModel
LEFT JOIN Production.ProductModelIllustration
ON Production.ProductModelIllustration.ProductModelID = Production.ProductModel.ProductModelID -- These are both clustered indexes on each table.
WHERE ProductModel.Instructions IS NOT NULL

SET SHOWPLAN_XML ON
GO
SELECT
	*
FROM Production.ProductModel
LEFT JOIN Production.ProductModelIllustration
ON Production.ProductModelIllustration.ProductModelID = Production.ProductModel.ProductModelID -- These are both clustered indexes on each table.
WHERE ProductModel.Instructions IS NOT NULL
GO
SET SHOWPLAN_XML OFF
GO

SET STATISTICS XML ON;
SELECT
	*
FROM Production.ProductModel
LEFT JOIN Production.ProductModelIllustration
ON Production.ProductModelIllustration.ProductModelID = Production.ProductModel.ProductModelID -- These are both clustered indexes on each table.
WHERE ProductModel.Instructions IS NOT NULL
SET STATISTICS XML OFF;

/*****************************************************************************************************************
***************************************************Recompiles*****************************************************
******************************************************************************************************************/
/*
	Recompiles can harm query performance as additional time and resources are being consumed in order to optimize
	a query each time this happens.
*/
-- Simple query to find the top queries being recompiled.
SELECT TOP 25
      sql_text.text,
      sql_handle,
      plan_generation_num,
      execution_count,
      dbid,
      objectid 
FROM sys.dm_exec_query_stats
CROSS APPLY sys.dm_exec_sql_text(sql_handle) AS sql_text
WHERE plan_generation_num > 1 -- This is the number of times a query has been recompiled
ORDER BY plan_generation_num DESC

-- This clears the entire plan cache.  Never do this in production unless you truly mean it!
-- This removes all execution plans from memory, meaning that all queries going forward
-- will need to be optmized from scratch, which on a busy server can mean immense resource consumption for a while.
-- Can be used in a dev environment to test queries over and over with no interference from the query cache.
DBCC FREEPROCCACHE
