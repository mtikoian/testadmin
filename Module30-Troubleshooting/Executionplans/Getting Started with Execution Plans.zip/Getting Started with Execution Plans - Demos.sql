/*
Getting Started with Execution Plans - Demos
Written By: Jason Kassay - 2013
Copyright: Under Creative Commons License (http://creativecommons.org/licenses/by-nc-nd/3.0/us/)
*/

USE AdventureWorks2008R2;
GO

/*
Use I/O and Execution Time in conjunction with execution plan
to see what is going on from multiple angles.
*/
SET STATISTICS IO ON;
SET STATISTICS TIME ON;

/*
Displaying a Graphical Execution Plan
--------------------------------------------------------
- Estimated Execution Plan: Icon found on "SQL Editor" toolbar 
(to the right of the checkmark) or key combination CTRL+L
- Actual Execution Plan: 3 icons to the right of the Estimated 
Execution Plan or key combination CTRL+M
*/


--Table Scan
/*
- Table is a HEAP (does not have a Clustered Index)
- Majority/All rows being selected, no/little filtering
*/
SELECT *
FROM dbo.DatabaseLog
;

--Clustered Index Scan
/*
- Table has a Clustered Index, so not a HEAP
- Majority/All rows being selected, so faster to do a scan
*/
SELECT *
FROM HumanResources.Department
;

--Non-Clustered Index Scan
/*
- Non-Clustered Index satisfies query
- Majority/All rows requested
*/
SELECT
	d.DepartmentID,
	d.[Name]
FROM HumanResources.Department AS d
;

--Clustered Index Seek
/*
- When requesting a small amount of rows
- WHERE clause helps filter
- Other indexes cannot satisfy query
*/
SELECT *
FROM HumanResources.Department
WHERE DepartmentID = 10
;

--Non-Clustered Index Seek
/*
- Non-Clustered Index satisfies query
- When requesting a small amount of rows
- WHERE clause helps filter
*/
SELECT
	d.DepartmentID,
	d.[Name]
FROM HumanResources.Department AS d
WHERE [Name] LIKE 'Prod%'
;

--Key Lookup
/*
- When a Non-Clustered Index cannot fully satisfy (cover) query
- Columns not present in Index, have to go to Clustered Index
- Will always see a JOIN operator
*/

--Make sure the index does not exist so the Key Lookup occurs
IF EXISTS (SELECT * FROM sys.indexes where sys.indexes.name = 'ncindex_Department_Name_INCLUDE_GroupName')
BEGIN
	DROP INDEX ncindex_Department_Name_INCLUDE_GroupName ON HumanResources.Department;
	PRINT 'Index: ncindex_Department_Name_INCLUDE_GroupName DROPPED.';
END
ELSE
BEGIN
	PRINT 'Index: ncindex_Department_Name_INCLUDE_GroupName does not exist, no action taken.'
END

SELECT
	d.DepartmentID,
	d.[Name],
	d.GroupName
FROM HumanResources.Department AS d
WHERE d.[Name] = 'Quality Assurance'
;

--After creating this index rerun the query above to see the Key Lookup replaced
CREATE NONCLUSTERED INDEX ncindex_Department_Name_INCLUDE_GroupName
ON HumanResources.Department (Name)
INCLUDE (GroupName)
;

--RID Lookup
/*
- Exactly the same as a Key Lookup except only on HEAP's
- will always see a Nested Loops Join operator
*/
SELECT
	dbl.DatabaseLogID,
	dbl.[Event]
FROM dbo.DatabaseLog AS dbl
WHERE DatabaseLogID = 226
;

/*
Joins (Nested, Merge, Hash)
------------------------------------------------------
- Nested good for smaller sets of data
- Merge good for medium sets of data
- Hash good for larger sets of data
*/

--Nested Loops (Inner Join)
/*
- Outer Table (top operator) compared once per row against Inner Table (bottom operator)
- Good when top table is small
- Outer Input Table: HumanResources.EmployeeDepartmentHistory
- Inner Input Table: HumanResources.Employee
- Cost is proportional to # of rows from input multiplied by # of rows from output
*/
SELECT
	e.BusinessEntityID,
	e.NationalIDNumber,
	edh.DepartmentID,
	edh.StartDate
FROM 
	HumanResources.Employee AS e
	INNER JOIN HumanResources.EmployeeDepartmentHistory AS edh
		ON e.BusinessEntityID = edh.BusinessEntityID
WHERE edh.DepartmentID = 6
;

--Merge Join
/*
- Happens when joined columns are sorted
- If not sorted, an extra Sort operator is used or a Hash Match is used
- Person.BusinessEntityAddress Primary Key (PK_BusinessEntityAddress_BusinessEntityID_AddressID_AddressTypeID) 
sorted by BuisnessEntityID ASC
- Person.BusinessEntity Primary Key (PK_BusinessEntity_BusinessEntityID)
sorted by BusinessEntityID ASC
- Cost is proportional to # of rows from both tables added together
*/
SELECT *
FROM
	Person.BusinessEntityAddress AS bea
	INNER JOIN Person.BusinessEntity AS be
		ON bea.BusinessEntityID = be.BusinessEntityID
;

--Hash Match (Inner Join)
/*
- Smaller Table Used for Hash: Sales.Currency (105 Rows)
- Comparing Table Against Hash Table (using hashing function): Sales.CurrencyRate (13,532 Rows)
- done in tempDB, if this operator exceeds the memory grant for the query
- when data sets are large
*/
SELECT *
FROM
	Sales.Currency AS c
	INNER JOIN Sales.CurrencyRate AS cr
		ON c.CurrencyCode = cr.FromCurrencyCode
;

--Sort
/*
- If data not already ordered by Index
- If the memory grant for the query is exceeded by the sort operation,
  it then moves to tempdb
*/
SELECT *
FROM HumanResources.Department
ORDER BY GroupName
;

--Compute Scalar
/*
- When manipulating column value
*/
SELECT LEN([Description]) 
FROM Production.ProductDescription
;

SELECT sod.OrderQty * sod.UnitPrice
FROM Sales.SalesOrderDetail as sod
;

--Stream Aggregate
/*
- Occurs when a GROUP BY is present in the query
- The rows are grouped and then the aggregations are performed against the columns
*/
SELECT
	LastName,
	COUNT(*)
FROM Person.Person
GROUP BY
	LastName
;


--Putting It All Together
/*
- Try running with and without the WHERE clause to see how the execution plan changes
- Multiple Operators Present (Sort, Hash Match, Compute Scalar, Stream Aggregate,
  Clustered Index Scan/Seek, Nested Loops, and Filter)

Without WHERE Clause
------------------------------------------------
- Elapsed Time is 112 ms
- Over 900 logical reads
- Reason for Early Termination: Time Out
- Estimated Subtree Cost: 0.2574460
- Memory Grant: 2,288 KB

With WHERE Clause
------------------------------------------------
- Elapsed Time is 3 ms
- Just over 50 logical reads
- Reason for Early Termination: Good Enough Plan Found
- Estimated Subtree Cost: 0.1038000
- Memory Grant: 1,088 KB
*/

SELECT
	emp.BusinessEntityID,
	emp.JobTitle,
	per.LastName,
	per.FirstName,
	CASE WHEN emp.SalariedFlag = 1 THEN 'Salaried' ELSE 'Hourly' END AS PayStatus,
	CAST((emp.VacationHours + emp.SickLeaveHours) / 40.0 AS NUMERIC(36, 2)) AS WeeksOfPTO,
	ph.RateChanges as NumberOfRateChanges
FROM
	HumanResources.Employee as emp
	INNER JOIN Person.Person as per
		on emp.BusinessEntityID = per.BusinessEntityID
	LEFT JOIN
	(
		SELECT
			BusinessEntityID,
			COUNT(Rate) AS RateChanges
		FROM HumanResources.EmployeePayHistory
		GROUP BY
			BusinessEntityID
	) AS ph ON emp.BusinessEntityID = ph.BusinessEntityID
ORDER BY per.LastName
;

SELECT
	emp.BusinessEntityID,
	emp.JobTitle,
	per.LastName,
	per.FirstName,
	CASE WHEN emp.SalariedFlag = 1 THEN 'Salaried' ELSE 'Hourly' END AS PayStatus,
	CAST((emp.VacationHours + emp.SickLeaveHours) / 40.0 AS NUMERIC(36, 2)) AS WeeksOfPTO,
	ph.RateChanges as NumberOfRateChanges
FROM
	HumanResources.Employee as emp
	INNER JOIN Person.Person as per
		on emp.BusinessEntityID = per.BusinessEntityID
	LEFT JOIN
	(
		SELECT
			BusinessEntityID,
			COUNT(Rate) AS RateChanges
		FROM HumanResources.EmployeePayHistory
		GROUP BY
			BusinessEntityID
	) AS ph ON emp.BusinessEntityID = ph.BusinessEntityID
WHERE 
	ph.RateChanges > 1
	AND
	emp.JobTitle LIKE ('Production%')
ORDER BY per.LastName
;


--Filter (in above query with WHERE clause)
/*
- Returns only those rows that match the given filter
- In the query above, the Filter is where the ph.RateChanges > 1. The
  Filter operator reduces the set of 290 rows found in the subquery
  down to only 13, before joining against the BusinessEntityID
*/