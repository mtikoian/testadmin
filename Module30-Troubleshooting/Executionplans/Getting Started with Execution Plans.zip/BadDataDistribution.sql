/*
Getting Started with Execution Plans - Demos
Written By: Jason Kassay - 2013
Copyright: Under Creative Commons License (http://creativecommons.org/licenses/by-nc-nd/3.0/us/)
*/

--Make sure the Country table doesn't already exist
IF EXISTS (SELECT * FROM sys.tables where sys.tables.name = 'Country')
BEGIN
	DROP TABLE Country;
	PRINT 'Table: Country DROPPED.';
END
ELSE
BEGIN
	PRINT 'Table: Country does not exist, no action taken.'
END

--Setup the Country table with 2 countries
CREATE TABLE Country
(
	CountryID INT NOT NULL IDENTITY(1,1) PRIMARY KEY CLUSTERED,
	CountryAbbr CHAR(3) NOT NULL,
	CountryName VARCHAR(30) NOT NULL
);
GO

INSERT Country (CountryAbbr, CountryName)
VALUES 
	('USA', 'United States'), 
	('AUS', 'Australia')
;
GO

--Make sure the Customer table doesn't already exist
IF EXISTS (SELECT * FROM sys.tables where sys.tables.name = 'Customer')
BEGIN
	DROP TABLE Customer;
	PRINT 'Table: Customer DROPPED.';
END
ELSE
BEGIN
	PRINT 'Table: Customer does not exist, no action taken.'
END

--Setup the Customer table with 2 customers
CREATE TABLE Customer
(
	CustomerID INT NOT NULL IDENTITY(1,1) PRIMARY KEY CLUSTERED,
	FirstName VARCHAR(30) NOT NULL,
	LastName VARCHAR(30) NOT NULL
);
GO

INSERT Customer (FirstName, LastName)
VALUES
	('John', 'Doe'),
	('Jane', 'Smith')
;
GO

--Make sure the Orders table doesn't already exist
IF EXISTS (SELECT * FROM sys.tables where sys.tables.name = 'Orders')
BEGIN
	DROP TABLE Orders;
	PRINT 'Table: Orders DROPPED.';
END
ELSE
BEGIN
	PRINT 'Table: Orders does not exist, no action taken.'
END

--Create the Orders table
CREATE TABLE Orders
(
	OrderID INT NOT NULL IDENTITY(1,1) PRIMARY KEY CLUSTERED,
	CustomerID INT NOT NULL
		FOREIGN KEY (CustomerID)
		REFERENCES Customer (CustomerID),
	CountryID INT NOT NULL
		FOREIGN KEY (CountryID)
		REFERENCES Country (CountryID),
	Quantity INT NOT NULL
);
GO

/*
- Create non-uniform distribution of data.
- One country gets 100,000 rows and the other only 2
*/ 
INSERT Orders (CustomerID, CountryID, Quantity)
VALUES (1, 1, 20);
GO 100000

INSERT Orders (CustomerID, CountryID, Quantity)
VALUES 
	(1, 2, 10),
	(2, 2, 15)
;
GO

--Make sure the stored procedure doesn't already exist
IF EXISTS (SELECT * FROM sys.procedures where sys.procedures.name = 'GetOrdersByCountry')
BEGIN
	DROP TABLE GetOrdersByCountry;
	PRINT 'Table: GetOrdersByCountry DROPPED.';
END
ELSE
BEGIN
	PRINT 'Table: GetOrdersByCountry does not exist, no action taken.'
END

--Create stored procedure to look up orders by country
CREATE PROCEDURE GetOrdersByCountry
(
	@CountryID INT
)

AS

SELECT
	c.FirstName,
	c.LastName,
	o.OrderID,
	o.Quantity
FROM 
	Orders AS o
	INNER JOIN Customer AS c
		ON o.CustomerID = c.CustomerID
WHERE o.CountryID = @CountryID
;
GO

/*
- 1st time stored procedure is executed, execution plan is stored in the
  plan cache based on the parameters supplied.
- If statistics are off or if the data is not evenly distributed, the plan
  generated will work great for one set of parameters, and for other
  parameters it will be mediocre or terrible.
*/


/*
- Try first using the country with only 2 rows
- Notice the Nested Loop Join. Makes sense, very small data sets
*/
EXECUTE GetOrdersByCountry @CountryID = 2;

/*
- Now run the stored procedure again but for the country with 100,000 rows
- A Nested Loop Join??? Only one plan is stored for the procedure.
  Due to the poorly distributed data a Nested Loop Join is a bad
  choice.
*/
EXECUTE GetOrdersByCountry @CountryID = 1;

-- Clear the stored execution plan out of the plan cache
EXECUTE sys.sp_recompile @objname = N'GetOrdersByCountry';

/*
Fix - Option 1
------------------------
- Execute the stored procedure with the more common used parameters
- This time around you get a Merge Join, which makes sense for
  the data set sizes for the larger country
- The smaller country ends up with a Merge Join. Would prefer to
  be a Nested Loop Join. So in this case the plan for the smaller
  country is not horrible, just mediocre. 
*/
EXECUTE GetOrdersByCountry @CountryID = 1;
EXECUTE GetOrdersByCountry @CountryID = 2;

/*
Fix - Option 2
-------------------------
- Tell the stored procedure to optimize for a particular parameter
- Problem with this approach is you have to remember that you
  are using query hints
*/
ALTER PROCEDURE GetOrdersByCountry
(
	@CountryID INT
)

AS

SELECT
	c.FirstName,
	c.LastName,
	o.OrderID,
	o.Quantity
FROM 
	Orders AS o
	INNER JOIN Customer AS c
		ON o.CustomerID = c.CustomerID
WHERE o.CountryID = @CountryID
OPTION (OPTIMIZE FOR (@CountryID = 1))
;
GO

EXECUTE sys.sp_recompile @objname = N'GetOrdersByCountry';
EXECUTE GetOrdersByCountry @CountryID = 1;
EXECUTE GetOrdersByCountry @CountryID = 2;

/*
Fix - Option 3
----------------------------------------------
- Tell the optimizer to come up with a new execution plan
  every time the stored procedure is executed
- Good when the query/stored procedure is not executed
  a large amount of times in a small time frame
- Like OPTIMIZE FOR, have to remember you are using
  a query hint
*/
ALTER PROCEDURE GetOrdersByCountry
(
	@CountryID INT
)

AS

SELECT
	c.FirstName,
	c.LastName,
	o.OrderID,
	o.Quantity
FROM 
	Orders AS o
	INNER JOIN Customer AS c
		ON o.CustomerID = c.CustomerID
WHERE o.CountryID = @CountryID
OPTION (RECOMPILE)
;
GO

EXECUTE sys.sp_recompile @objname = N'GetOrdersByCountry';
EXECUTE GetOrdersByCountry @CountryID = 1;
EXECUTE GetOrdersByCountry @CountryID = 2;