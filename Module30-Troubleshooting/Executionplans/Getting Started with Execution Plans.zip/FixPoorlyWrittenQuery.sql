/*
Getting Started with Execution Plans - Demos
Written By: Jason Kassay - 2013
Copyright: Under Creative Commons License (http://creativecommons.org/licenses/by-nc-nd/3.0/us/)
*/

--Fixing poorly written query

--Find records we want to change
SELECT *
FROM Person.Address as a
WHERE 
	a.StateProvinceID = 7
	AND 
	a.City = 'Oak Bay'
;

SET STATISTICS IO ON;
SET STATISTICS TIME ON;

/*
Row By Row
-----------------------------------------------------------------
*/

--temp table variable to hold all address ID's to process
DECLARE @tblRecordsToChange TABLE
(
	AddressID INT
);

--get all address ID's to process
INSERT @tblRecordsToChange (AddressID)
SELECT AddressID
FROM Person.Address as a
WHERE
	a.StateProvinceID = 7
	AND
	a.City = 'Oak Bay'
;

--Process each address ID one at a time in a loop
DECLARE @currentAddressID INT;
WHILE EXISTS (SELECT * FROM @tblRecordsToChange)
BEGIN
	--Get the next record to process
	SELECT TOP (1) @currentAddressID = AddressID
	FROM @tblRecordsToChange;
	
	--Change the City Name
	UPDATE Person.Address
	SET City = 'Oakbay'
	WHERE AddressID = @currentAddressID;
	
	--Remove the processed record
	DELETE @tblRecordsToChange
	WHERE AddressID = @currentAddressID;
END


/*
Set Based
-----------------------------------------------------------------
*/

--Reset the data from the Row by Row processing
UPDATE Person.Address
SET City = 'Oak Bay'
WHERE
	StateProvinceID = 7
	AND
	City = 'Oakbay'
;


--Update records we want to change
UPDATE Person.Address
SET City = 'Oakbay'
WHERE
	StateProvinceID = 7
	AND
	City = 'Oak Bay'
;


SET STATISTICS IO OFF;
SET STATISTICS TIME OFF;