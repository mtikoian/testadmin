/*
  Author: Fabiano Neves Amorim
  E-Mail: fabiano_amorim@bol.com.br
  http://blogfabiano.com | twitter: @mcflyamorim
  http://www.simple-talk.com/author/fabiano-amorim/
*/

USE Northwind
GO

SET NOCOUNT ON;
IF OBJECT_ID('TabTest') IS NOT NULL
  DROP TABLE TabTest
GO
CREATE TABLE TabTest(ID Int Identity(1,1) Primary Key,
                     ContactName VarChar(200) NOT NULL,
                     Value Int NOT NULL)
GO
BEGIN TRAN
DECLARE @i INT
SET @i = 0 
WHILE (@i < 100000)
BEGIN
  INSERT INTO TabTest(ContactName, Value)
  VALUES(NEWID(), ABS(CHECKSUM(NEWID()) / 1000000) + 1)
  SET @i = @i + 1 
END;
COMMIT TRAN
GO
-- Only 500 rows with value 0
INSERT INTO TabTest(ContactName, Value) VALUES(NEWID(), 0)
GO 500
GO
CREATE NONCLUSTERED INDEX ix_Value ON TabTest(Value);
GO

SELECT * FROM TabTest
GO

IF OBJECT_ID('st_ProcTest', 'P') IS NOT NULL
  DROP PROC st_ProcTest
GO
CREATE PROCEDURE dbo.st_ProcTest @Value Int
AS
BEGIN
  DECLARE @i Int
  -- Dynamic search conditions
  SELECT @i = Count(*)
    FROM TabTest
   WHERE (Value <= @Value OR @Value IS NULL)

  SELECT @i "Count result"
END
GO

-- Test Proc
-- Seek = no no no
EXEC dbo.st_ProcTest @Value = 0
GO

-- What about option(recompile)? It should fix this issue...
IF OBJECT_ID('st_ProcTest', 'P') IS NOT NULL
  DROP PROC st_ProcTest
GO
CREATE PROCEDURE dbo.st_ProcTest @Value Int
AS
BEGIN
  DECLARE @i Int
  SELECT @i = Count(*)
    FROM TabTest
   WHERE (Value <= @Value OR @Value IS NULL)
  OPTION (RECOMPILE)

  SELECT @i "Count result"
END
GO

-- What now? Seek = yes yes yes? ...
EXEC dbo.st_ProcTest @Value = 0
GO


















-- "gap in the functionality" when setting value to variables
-- Here is a workarround
IF OBJECT_ID('st_ProcTest', 'P') IS NOT NULL
  DROP PROC st_ProcTest
GO
CREATE PROCEDURE dbo.st_ProcTest @Value Int
AS
BEGIN
  DECLARE @i Int

  SELECT i = Count(*)
    INTO #TMP
    FROM TabTest
   WHERE (Value <= @Value OR @Value IS NULL)
  OPTION (RECOMPILE)

  SELECT @i = i 
    FROM #TMP

  SELECT @i "Count result"
END
GO

-- Now what?
EXEC dbo.st_ProcTest @Value = 0
GO



