EXEC sp_control_plan_guide @operation = 'DROP ALL', @name = 'PlanGuide1'
GO


sp_create_plan_guide 
@name = N'PlanGuide1', 
@stmt = N'SELECT MAX(OrderDate) FROM vw_1;
', 
@type = N'SQL', 
@module_or_batch = NULL, 
@params = NULL, 
@hints = 
N'
OPTION (USE PLAN N'' 
<ShowPlanXML xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" Version="1.5" Build="13.0.1100.288" xmlns="http://schemas.microsoft.com/sqlserver/2004/07/showplan">
  <BatchSequence>
    <Batch>
      <Statements>
        <StmtSimple StatementCompId="1" StatementEstRows="1" StatementId="1" StatementOptmLevel="FULL" StatementOptmEarlyAbortReason="GoodEnoughPlanFound" CardinalityEstimationModelVersion="130" StatementSubTreeCost="0.0098585" StatementText="SELECT MAX(OrderDate)&#xD;&#xA;  FROM vw_1&#xD;&#xA;OPTION (QueryTraceON 3604&#xD;&#xA;--,QueryTraceON 8677 -- disable &quot;search 1&quot;/quickplan&#xD;&#xA;,QueryTraceON 8750 -- disable search 0/TP Plan&#xD;&#xA;,QueryTraceON 8675 -- show optimization stages&#xD;&#xA;)" StatementType="SELECT" QueryHash="0xDA0A51E3BE8BBA9C" QueryPlanHash="0x5F229BCB5CEC2828" RetrievedFromCache="true" SecurityPolicyApplied="false">
          <StatementSetOptions ANSI_NULLS="true" ANSI_PADDING="true" ANSI_WARNINGS="true" ARITHABORT="true" CONCAT_NULL_YIELDS_NULL="true" NUMERIC_ROUNDABORT="false" QUOTED_IDENTIFIER="true" />
          <QueryPlan DegreeOfParallelism="1" CachedPlanSize="32" CompileTime="1" CompileCPU="1" CompileMemory="288">
            <MemoryGrantInfo SerialRequiredMemory="0" SerialDesiredMemory="0" />
            <OptimizerHardwareDependentProperties EstimatedAvailableMemoryGrant="26214" EstimatedPagesCached="13107" EstimatedAvailableDegreeOfParallelism="4" />
            <RelOp AvgRowSize="10" EstimateCPU="7.7E-06" EstimateIO="0" EstimateRebinds="0" EstimateRewinds="0" EstimatedExecutionMode="Row" EstimateRows="1" LogicalOp="Aggregate" NodeId="0" Parallel="false" PhysicalOp="Stream Aggregate" EstimatedTotalSubtreeCost="0.0098585">
              <OutputList>
                <ColumnReference Column="Expr1010" />
              </OutputList>
              <RunTimeInformation>
                <RunTimeCountersPerThread Thread="0" ActualRows="1" Batches="0" ActualEndOfScans="1" ActualExecutions="1" ActualExecutionMode="Row" ActualElapsedms="0" ActualCPUms="0" />
              </RunTimeInformation>
              <StreamAggregate>
                <DefinedValues>
                  <DefinedValue>
                    <ColumnReference Column="Expr1010" />
                    <ScalarOperator ScalarString="MAX([partialagg1011])">
                      <Aggregate AggType="MAX" Distinct="false">
                        <ScalarOperator>
                          <Identifier>
                            <ColumnReference Column="partialagg1011" />
                          </Identifier>
                        </ScalarOperator>
                      </Aggregate>
                    </ScalarOperator>
                  </DefinedValue>
                </DefinedValues>
                <RelOp AvgRowSize="10" EstimateCPU="1.2E-06" EstimateIO="0" EstimateRebinds="0" EstimateRewinds="0" EstimatedExecutionMode="Row" EstimateRows="12" LogicalOp="Concatenation" NodeId="1" Parallel="false" PhysicalOp="Concatenation" EstimatedTotalSubtreeCost="0.0098508">
                  <OutputList>
                    <ColumnReference Column="partialagg1011" />
                  </OutputList>
                  <RunTimeInformation>
                    <RunTimeCountersPerThread Thread="0" ActualRows="3" Batches="0" ActualEndOfScans="1" ActualExecutions="1" ActualExecutionMode="Row" ActualElapsedms="0" ActualCPUms="0" />
                  </RunTimeInformation>
                  <Concat>
                    <DefinedValues>
                      <DefinedValue>
                        <ColumnReference Column="partialagg1011" />
                        <ColumnReference Database="[Northwind]" Schema="[dbo]" Table="[OrdersBig1]" Column="OrderDate" />
                        <ColumnReference Database="[Northwind]" Schema="[dbo]" Table="[OrdersBig2]" Column="OrderDate" />
                        <ColumnReference Database="[Northwind]" Schema="[dbo]" Table="[OrdersBig3]" Column="OrderDate" />
                      </DefinedValue>
                    </DefinedValues>
                    <RelOp AvgRowSize="10" EstimateCPU="1E-07" EstimateIO="0" EstimateRebinds="0" EstimateRewinds="0" EstimatedExecutionMode="Row" EstimateRows="1" LogicalOp="Top" NodeId="3" Parallel="false" PhysicalOp="Top" EstimatedTotalSubtreeCost="0.0032832">
                      <OutputList>
                        <ColumnReference Database="[Northwind]" Schema="[dbo]" Table="[OrdersBig1]" Column="OrderDate" />
                      </OutputList>
                      <RunTimeInformation>
                        <RunTimeCountersPerThread Thread="0" ActualRows="1" Batches="0" ActualEndOfScans="1" ActualExecutions="1" ActualExecutionMode="Row" ActualElapsedms="0" ActualCPUms="0" />
                      </RunTimeInformation>
                      <Top RowCount="false" IsPercent="false" WithTies="false">
                        <TopExpression>
                          <ScalarOperator ScalarString="(1)">
                            <Const ConstValue="(1)" />
                          </ScalarOperator>
                        </TopExpression>
                        <RelOp AvgRowSize="10" EstimateCPU="0.019957" EstimateIO="0.0238657" EstimateRebinds="0" EstimateRewinds="0" EstimatedExecutionMode="Row" EstimateRows="1" LogicalOp="Index Scan" NodeId="4" Parallel="false" PhysicalOp="Index Scan" EstimatedTotalSubtreeCost="0.0032831" TableCardinality="18000">
                          <OutputList>
                            <ColumnReference Database="[Northwind]" Schema="[dbo]" Table="[OrdersBig1]" Column="OrderDate" />
                          </OutputList>
                          <RunTimeInformation>
                            <RunTimeCountersPerThread Thread="0" ActualRows="1" ActualRowsRead="1" Batches="0" ActualEndOfScans="0" ActualExecutions="1" ActualExecutionMode="Row" ActualElapsedms="0" ActualCPUms="0" ActualScans="1" ActualLogicalReads="2" ActualPhysicalReads="0" ActualReadAheads="0" ActualLobLogicalReads="0" ActualLobPhysicalReads="0" ActualLobReadAheads="0" />
                          </RunTimeInformation>
                          <IndexScan Ordered="true" ScanDirection="BACKWARD" ForcedIndex="false" ForceSeek="false" ForceScan="false" NoExpandHint="false" Storage="RowStore">
                            <DefinedValues>
                              <DefinedValue>
                                <ColumnReference Database="[Northwind]" Schema="[dbo]" Table="[OrdersBig1]" Column="OrderDate" />
                              </DefinedValue>
                            </DefinedValues>
                            <Object Database="[Northwind]" Schema="[dbo]" Table="[OrdersBig1]" Index="[ixOrderDate]" IndexKind="NonClustered" Storage="RowStore" />
                          </IndexScan>
                        </RelOp>
                      </Top>
                    </RelOp>
                    <RelOp AvgRowSize="10" EstimateCPU="1E-07" EstimateIO="0" EstimateRebinds="0" EstimateRewinds="0" EstimatedExecutionMode="Row" EstimateRows="1" LogicalOp="Top" NodeId="10" Parallel="false" PhysicalOp="Top" EstimatedTotalSubtreeCost="0.0032832">
                      <OutputList>
                        <ColumnReference Database="[Northwind]" Schema="[dbo]" Table="[OrdersBig2]" Column="OrderDate" />
                      </OutputList>
                      <RunTimeInformation>
                        <RunTimeCountersPerThread Thread="0" ActualRows="1" Batches="0" ActualEndOfScans="1" ActualExecutions="1" ActualExecutionMode="Row" ActualElapsedms="0" ActualCPUms="0" />
                      </RunTimeInformation>
                      <Top RowCount="false" IsPercent="false" WithTies="false">
                        <TopExpression>
                          <ScalarOperator ScalarString="(1)">
                            <Const ConstValue="(1)" />
                          </ScalarOperator>
                        </TopExpression>
                        <RelOp AvgRowSize="10" EstimateCPU="0.019957" EstimateIO="0.0238657" EstimateRebinds="0" EstimateRewinds="0" EstimatedExecutionMode="Row" EstimateRows="1" LogicalOp="Index Scan" NodeId="11" Parallel="false" PhysicalOp="Index Scan" EstimatedTotalSubtreeCost="0.0032831" TableCardinality="18000">
                          <OutputList>
                            <ColumnReference Database="[Northwind]" Schema="[dbo]" Table="[OrdersBig2]" Column="OrderDate" />
                          </OutputList>
                          <RunTimeInformation>
                            <RunTimeCountersPerThread Thread="0" ActualRows="1" ActualRowsRead="1" Batches="0" ActualEndOfScans="0" ActualExecutions="1" ActualExecutionMode="Row" ActualElapsedms="0" ActualCPUms="0" ActualScans="1" ActualLogicalReads="2" ActualPhysicalReads="0" ActualReadAheads="0" ActualLobLogicalReads="0" ActualLobPhysicalReads="0" ActualLobReadAheads="0" />
                          </RunTimeInformation>
                          <IndexScan Ordered="true" ScanDirection="BACKWARD" ForcedIndex="false" ForceSeek="false" ForceScan="false" NoExpandHint="false" Storage="RowStore">
                            <DefinedValues>
                              <DefinedValue>
                                <ColumnReference Database="[Northwind]" Schema="[dbo]" Table="[OrdersBig2]" Column="OrderDate" />
                              </DefinedValue>
                            </DefinedValues>
                            <Object Database="[Northwind]" Schema="[dbo]" Table="[OrdersBig2]" Index="[ixOrderDate]" IndexKind="NonClustered" Storage="RowStore" />
                          </IndexScan>
                        </RelOp>
                      </Top>
                    </RelOp>
                    <RelOp AvgRowSize="10" EstimateCPU="1E-07" EstimateIO="0" EstimateRebinds="0" EstimateRewinds="0" EstimatedExecutionMode="Row" EstimateRows="1" LogicalOp="Top" NodeId="17" Parallel="false" PhysicalOp="Top" EstimatedTotalSubtreeCost="0.0032832">
                      <OutputList>
                        <ColumnReference Database="[Northwind]" Schema="[dbo]" Table="[OrdersBig3]" Column="OrderDate" />
                      </OutputList>
                      <RunTimeInformation>
                        <RunTimeCountersPerThread Thread="0" ActualRows="1" Batches="0" ActualEndOfScans="1" ActualExecutions="1" ActualExecutionMode="Row" ActualElapsedms="0" ActualCPUms="0" />
                      </RunTimeInformation>
                      <Top RowCount="false" IsPercent="false" WithTies="false">
                        <TopExpression>
                          <ScalarOperator ScalarString="(1)">
                            <Const ConstValue="(1)" />
                          </ScalarOperator>
                        </TopExpression>
                        <RelOp AvgRowSize="10" EstimateCPU="0.019957" EstimateIO="0.0238657" EstimateRebinds="0" EstimateRewinds="0" EstimatedExecutionMode="Row" EstimateRows="1" LogicalOp="Index Scan" NodeId="18" Parallel="false" PhysicalOp="Index Scan" EstimatedTotalSubtreeCost="0.0032831" TableCardinality="18000">
                          <OutputList>
                            <ColumnReference Database="[Northwind]" Schema="[dbo]" Table="[OrdersBig3]" Column="OrderDate" />
                          </OutputList>
                          <RunTimeInformation>
                            <RunTimeCountersPerThread Thread="0" ActualRows="1" ActualRowsRead="1" Batches="0" ActualEndOfScans="0" ActualExecutions="1" ActualExecutionMode="Row" ActualElapsedms="0" ActualCPUms="0" ActualScans="1" ActualLogicalReads="2" ActualPhysicalReads="0" ActualReadAheads="0" ActualLobLogicalReads="0" ActualLobPhysicalReads="0" ActualLobReadAheads="0" />
                          </RunTimeInformation>
                          <IndexScan Ordered="true" ScanDirection="BACKWARD" ForcedIndex="false" ForceSeek="false" ForceScan="false" NoExpandHint="false" Storage="RowStore">
                            <DefinedValues>
                              <DefinedValue>
                                <ColumnReference Database="[Northwind]" Schema="[dbo]" Table="[OrdersBig3]" Column="OrderDate" />
                              </DefinedValue>
                            </DefinedValues>
                            <Object Database="[Northwind]" Schema="[dbo]" Table="[OrdersBig3]" Index="[ixOrderDate]" IndexKind="NonClustered" Storage="RowStore" />
                          </IndexScan>
                        </RelOp>
                      </Top>
                    </RelOp>
                  </Concat>
                </RelOp>
              </StreamAggregate>
            </RelOp>
          </QueryPlan>
        </StmtSimple>
      </Statements>
    </Batch>
  </BatchSequence>
</ShowPlanXML>
'') 
' 
GO