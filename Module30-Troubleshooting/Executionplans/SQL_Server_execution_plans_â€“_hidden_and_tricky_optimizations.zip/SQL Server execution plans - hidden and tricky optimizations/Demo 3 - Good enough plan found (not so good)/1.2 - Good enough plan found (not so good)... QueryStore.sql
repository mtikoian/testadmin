USE master
GO
--ALTER DATABASE Northwind SET QUERY_STORE = OFF;
--GO
ALTER DATABASE Northwind SET QUERY_STORE = ON;
GO
-- ALTER DATABASE Northwind SET QUERY_STORE CLEAR;
--GO
USE Northwind
GO

-- First of all run the optimized query to have its plan on query Store... (if SQL2016)
DBCC FREEPROCCACHE()
GO
DBCC TRACEON(8750)
GO
-- Version with good plan
SELECT MAX(OrderDate) FROM vw_1;
GO
DBCC TRACEOFF(8750)
GO

DBCC FREEPROCCACHE()
GO
-- Version with bad plan
SELECT MAX(OrderDate) FROM vw_1;
GO

-- should return two plans for same query_hash...
SELECT Txt.query_text_id, Txt.query_sql_text, Pl.plan_id, Qry.*
FROM sys.query_store_plan AS Pl
JOIN sys.query_store_query AS Qry
    ON Pl.query_id = Qry.query_id
JOIN sys.query_store_query_text AS Txt
    ON Qry.query_text_id = Txt.query_text_id
ORDER BY query_hash
GO

SELECT * FROM sys.query_context_settings
GO