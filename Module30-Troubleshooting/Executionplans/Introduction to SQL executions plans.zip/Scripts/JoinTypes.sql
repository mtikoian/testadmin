----------------------------------------------
------ Show examples of each join type -------
----------------------------------------------

-- Nested loop - small inputs, may not be sorted
select * from Person.Person p
join Person.EmailAddress e
  on p.BusinessEntityID = e.BusinessEntityID
where p.FirstName = 'John'
  

-- Merge - we're walking the indexes and it's already sorted
select *
  from Sales.SalesOrderHeader h
  join Sales.SalesOrderDetail d
    on h.SalesOrderID = d.SalesOrderID

-- Hash match - larger inputs    
select *
  from Sales.Customer c
  join Sales.SalesOrderHeader soh
    on c.CustomerID = soh.CustomerID
    
    
----------------------------------------------
-- Compare same query with three join types --
----------------------------------------------

select * from Sales.Customer c
left join Sales.SalesOrderHeader soh on c.CustomerID = soh.CustomerID

select * from Sales.Customer c
left join Sales.SalesOrderHeader soh on c.CustomerID = soh.CustomerID
option (merge join)

select * from Sales.Customer c
left join Sales.SalesOrderHeader soh on c.CustomerID = soh.CustomerID
option (loop join)