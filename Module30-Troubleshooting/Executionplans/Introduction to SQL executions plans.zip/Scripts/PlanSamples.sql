USE AdventureWorks2012

----------------------------------------------
---------------- SHOWPLAN_XML ----------------
------ Gives you the plan in XML format ------
---- without actually executing the query ----
----------------------------------------------

SET SHOWPLAN_XML ON

SELECT TOP 50 *
  FROM Person.Person
 WHERE LastName LIKE 'G%'

 SET SHOWPLAN_XML OFF

----------------------------------------------
---------------- SHOWPLAN_ALL ----------------
-- Gives you the plan in text format        --
-- without actually executing the query     --
-- Also illustrates index tipping point     --
----------------------------------------------

SET SHOWPLAN_ALL ON

SELECT TOP 50 *
  FROM Person.Person
 WHERE LastName LIKE 'G%'

SELECT TOP 50 *
  FROM Person.Person
 WHERE LastName LIKE 'Z%'

 SET SHOWPLAN_ALL OFF

----------------------------------------------
---------- SET STATISTICS TIME ON ------------
-- Causes the query engine to return time   --
-- taken for each step - parse, compile,    --
-- and execute - for each query             --
----------------------------------------------

SET STATISTICS TIME ON

SELECT *
  FROM Person.Person
 WHERE LastName LIKE 'G%'

SELECT *
  FROM Person.Person
 WHERE LastName LIKE 'Z%'

 -- Clear procedure cache - causes statement recompile.
-- Don't do this in production!
DBCC FREEPROCCACHE

SELECT *
  FROM Person.Person
 WHERE LastName LIKE 'G%'
 
----------------------------------------------
-- Show additional details in Plan Explorer --
----------------------------------------------

SELECT p.FirstName, p.LastName, a.City, sp.StateProvinceCode
  FROM Person.Person p
  JOIN Person.BusinessEntityAddress ba
    on p.BusinessEntityID = ba.BusinessEntityID
  JOIN person.Address a
    ON ba.AddressID = a.AddressID
  JOIN person.StateProvince sp
    ON a.StateProvinceID = sp.StateProvinceID

SET STATISTICS TIME OFF