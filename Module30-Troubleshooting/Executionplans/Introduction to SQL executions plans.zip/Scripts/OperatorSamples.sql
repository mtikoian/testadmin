----------------------------------------------
------ Seeks (small ranges of values) --------
----------------------------------------------

-- Index seek
select p.BusinessEntityID
  from person.Person p
 where LastName = 'Smith'
 
 -- Clustered index seek
 select p.BusinessEntityID
  from person.Person p
 where BusinessEntityID = 10


----------------------------------------------
----- Index Scan (not leading in index) ------
----------------------------------------------

-- Index scan
select p.BusinessEntityID
  from person.Person p
 where FirstName = 'Ralph'
    
    
----------------------------------------------
----------- Table/Clustered scan  ------------
----------------------------------------------

-- Table scan
select *
  from DatabaseLog

-- Clustered index scan
select *
  from person.Person p
 where ModifiedDate >= '2005-10-10'

----------------------------------------------
------------------ Lookups -------------------
----------------------------------------------

-- Key lookup (clustered table)
select *
  from person.Person p
 where LastName = 'Smith'

-- RID Lookup (unclustered table)
select *
  from DatabaseLog
 where DatabaseLogID = 50

----------------------------------------------
-------------- Filter and sort ---------------
----------------------------------------------

-- Filter is a result of the HAVING
-- Sort cased by ORDER BY
-- Stream Aggregate would also have Sort if index wasn't already sorted
select lastname, count(*)
  from person.Person
 where len(lastname) > 5
 group by lastname
having count(*) > 2
order by count(*) DESC