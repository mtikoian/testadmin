-- Clean up first
IF EXISTS (SELECT * FROM sys.objects where name = 'NewOrders')
drop table NewOrders

-- Ensure that auto-update stats is on to begin with 
ALTER DATABASE AdventureWorks2012
  SET AUTO_UPDATE_STATISTICS ON

-- Create and populate the NewOrders table
-- and create a supporting index
SELECT *
INTO    NewOrders
FROM    Sales.SalesOrderDetail
GO
CREATE INDEX IX_NewOrders_ProductID on NewOrders ( ProductID )
GO


-- Execute a sample lookup
-- Uses a nested loop
SELECT [OrderQty]
       ,[CarrierTrackingNumber]
FROM    NewOrders
WHERE   [ProductID] = 897


-- Now, what happens if we set autoupdatestats off
-- and then make a large data change?
ALTER DATABASE AdventureWorks2012
  SET AUTO_UPDATE_STATISTICS OFF

-- So we can easily roll back
BEGIN TRAN

-- Update the orders table dramatically
UPDATE  NewOrders
SET     [ProductID] = 897
WHERE   [ProductID] between 700 and 900
GO

-- Now, execute the same lookup query
-- It still wants to use the nested loop
-- But look at the estimated vs. actual rows
SELECT [OrderQty]
       ,[CarrierTrackingNumber]
FROM    NewOrders
WHERE   [ProductID] = 897


-- Update the stats on that table to fix the query
UPDATE STATISTICS NewOrders


-- Then try the same query again - it's now using
-- a table scan to get results
SELECT [OrderQty]
       ,[CarrierTrackingNumber]
FROM    NewOrders
WHERE   [ProductID] = 897


-- Autoupdatestats are still off - let's rollback
-- and try the query again
ROLLBACK TRAN

-- Query still uses a full table scan
-- It doesn't know the data is back the way
-- it used to be before our update!
SELECT [OrderQty]
       ,[CarrierTrackingNumber]
FROM    NewOrders
WHERE   [ProductID] = 897


-- Turn autoupdatestats back up
-- but this won't refresh anything
ALTER DATABASE AdventureWorks2012
  SET AUTO_UPDATE_STATISTICS ON


-- Run the query again - still using
-- the old table scan query plan
  SELECT [OrderQty]
       ,[CarrierTrackingNumber]
FROM    NewOrders
WHERE   [ProductID] = 897


-- Manually update stats - this will
-- restore the previous query plan
UPDATE STATISTICS NewOrders


-- We may also need to dump the
-- old query plan from memory
dbcc freeproccache


-- Back to the optimal plan!
  SELECT [OrderQty]
       ,[CarrierTrackingNumber]
FROM    NewOrders
WHERE   [ProductID] = 897