USE [master]
GO
/****** Object:  StoredProcedure [dbo].[sp_dba_gather_scan_stats]    Script Date: 3/8/2017 11:42:25 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[sp_dba_gather_scan_stats] (@Clear INT = 0)

AS BEGIN

SET NOCOUNT ON ;

DECLARE @DT DATETIME ;
DECLARE @DBN sysname ;

SELECT @DT = GETDATE() ;

--  If 1 the clear out the table
IF @Clear = 1

BEGIN
    TRUNCATE TABLE [MonitorXX].[dbo].[scan_stats]
END

SELECT @DBN = DB_NAME()

INSERT INTO [SQLMEMON_PROD].[dbo].[scan_stats]
   ([database_id],
	[database_name],
	[table_object_id],
    [table_object_type],
	[table_object_name],
	[table_index_id],
	[table_index_name],
	[disabled],
	[filtered],
	[num_user_seeks],
	[num_user_scans],
	[num_user_lookups],
	[num_user_updates],
	[last_user_seek_time],
    [last_user_scan_time],
    [last_user_lookup_time],
    [last_user_update_time],
    [num_system_seeks],
	[num_system_scans],
	[num_system_lookups],
	[num_system_updates],
	[last_system_seek_time],
    [last_system_scan_time],
    [last_system_lookup_time],
    [last_system_update_time],
	[last_stats_update_time],
    [index_create_date],
	[index_modify_date],
	[total_rows],
    [capture_time])
SELECT DB_ID() AS [database_id],
       DB_NAME() AS [database_name],
       o.[object_id] AS [table_object_id],
       o.[type] AS [table_object_type], 
       o.[name] AS [table_name],
       i.[index_id] AS [table_index_id],		
       i.[name] AS [table_index_name],
	   i.[is_disabled] AS [disabled],
	   i.[has_filter] AS [filtered],
       0 AS [num_user_seeks],
       0 AS [num_user_scans],
       0 AS [num_user_lookups],
       0 AS [num_user_updates],
    NULL AS [last_user_seek_time],
    NULL AS [last_user_scan_time],
    NULL AS [last_user_lookup_time],
    NULL AS [last_user_update_time],
       0 AS [num_system_seeks],
       0 AS [num_system_scans],
       0 AS [num_system_lookups],
       0 AS [num_system_updates],
    NULL AS [last_system_seek_time],
    NULL AS [last_system_scan_time],
    NULL AS [last_system_lookup_time],
    NULL AS [last_system_update_time],
       STATS_DATE(i.[object_id], i.[index_id]) AS [last_stats_update_time],
       o.[create_date] AS [index_create_date],
       o.[modify_date] AS [index_modify_date],
       -999 AS [total_rows],
       @DT
FROM   sys.indexes as i
       INNER JOIN sys.objects as o on i.[object_id] = o.[object_id]
WHERE  i.[index_id] NOT IN ( SELECT ddius.index_id
			   FROM   sys.dm_db_index_usage_stats as ddius
			   WHERE ddius.[object_id] = i.[object_id]
				 AND i.[index_id] = ddius.[index_id]
			     AND database_id = DB_ID() )		
				 AND o.[type] IN ('U', 'V')
ORDER BY o.[object_id] ASC

INSERT INTO [MonitorXX].[dbo].[scan_stats]
   ([database_id],
	[database_name],
	[table_object_id],
    [table_object_type],
	[table_object_name],
	[table_index_id],
	[table_index_name],
	[disabled],
	[filtered],
	[num_user_seeks],
	[num_user_scans],
	[num_user_lookups],
	[num_user_updates],
	[last_user_seek_time],
    [last_user_scan_time],
    [last_user_lookup_time],
    [last_user_update_time],
    [num_system_seeks],
	[num_system_scans],
	[num_system_lookups],
	[num_system_updates],
	[last_system_seek_time],
    [last_system_scan_time],
    [last_system_lookup_time],
    [last_system_update_time],
	[last_stats_update_time],
    [index_create_date],
	[index_modify_date],
	[total_rows],
    [capture_time])
SELECT  ddius.[database_id] AS [database_id],
        DB_NAME() AS [database_name],
	o.[object_id] AS [table_object_id],
    o.[type] AS [table_object_type],
	o.[name] AS [table_name],
	i.[index_id] as [index_id],
	i.[name] AS [index_name],
	i.[is_disabled] AS [disabled],
	i.[has_filter] AS [filtered],
	ddius.[user_seeks] AS [num_user_seeks],
	ddius.[user_scans] AS [num_user_scan],
    ddius.[user_lookups] AS [num_user_lookups],
	ddius.[user_updates] AS [num_user_updates],
	ddius.[last_user_seek] as [last_user_seek_time],
    ddius.[last_user_scan] as [last_user_scan_time],
    ddius.[last_user_lookup] as [last_user_lookup_time],
    ddius.[last_user_update] as [last_user_update_time],
    ddius.[system_seeks] AS [num_system_seeks],
	ddius.[system_scans] AS [num_system_scan],
    ddius.[system_lookups] AS [num_system_lookups],
	ddius.[system_updates] AS [num_system_updates],
	ddius.[last_system_seek] as [last_system_seek_time],
    ddius.[last_system_scan] as [last_system_scan_time],
    ddius.[last_system_lookup] as [last_system_lookup_time],
    ddius.[last_system_update] as [last_system_update_time],
	STATS_DATE(i.[object_id], i.[index_id]) AS [last_stats_update_time],
    o.[create_date] AS [index_create_date],
    o.[modify_date] AS [index_modify_date],
	SUM(SP.rows) AS [total_rows],
    @DT
FROM    sys.dm_db_index_usage_stats ddius
	INNER JOIN sys.indexes i on ddius.[object_id] = i.[object_id]
				AND i.[index_id] = ddius.[index_id]
	INNER JOIN sys.partitions SP on ddius.[object_id] = SP.[object_id]
				AND SP.[index_id] = ddius.[index_id]
	INNER JOIN sys.objects o on ddius.[object_id] = o.[object_id]
	INNER JOIN sys.sysusers su ON o.[schema_id] = su.[uid]
	WHERE ddius.[database_id] = DB_ID()
	AND o.[type] IN ('U', 'V')
	GROUP BY su.[name],
      ddius.[database_id],
	  o.[object_id],
      o.[type],
      o.[name],
      i.[index_id],
      i.[name], 
	  i.[is_disabled],
	  i.[has_filter],
      ddius.[user_seeks],
      ddius.[user_scans],
      ddius.[user_lookups],
      ddius.[user_updates],
      ddius.[last_user_seek],
      ddius.[last_user_scan],
      ddius.[last_user_lookup],
      ddius.[last_user_update],
      ddius.[system_seeks],
      ddius.[system_scans],
      ddius.[system_lookups],
      ddius.[system_updates],
      ddius.[last_system_seek],
      ddius.[last_system_scan],
      ddius.[last_system_lookup],
      ddius.[last_system_update],
      o.[create_date],
      o.[modify_date],	
      i.[object_id]
ORDER BY o.[object_id] ASC

SET NOCOUNT OFF

END 