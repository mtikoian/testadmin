USE [master]
GO

/****** Object:  StoredProcedure [dbo].[sp_dba_GatherSeekConversionPlans]    Script Date: 2017-03-09 1:45:00 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO





CREATE PROCEDURE [dbo].[sp_dba_GatherSeekConversionPlans]

AS 
SET NOCOUNT ON;
DECLARE @DT datetime;
SELECT @DT = GETDATE();
WITH XMLNAMESPACES 
   (DEFAULT 'http://schemas.microsoft.com/sqlserver/2004/07/showplan')
INSERT INTO MonitorXX.dbo.sp_query_plans
SELECT 
       OBJECT_NAME(CAST(pa.value AS INT),qp.dbid) AS proc_name, query_plan, usecounts, size_in_bytes, cp.plan_handle, qs.cached_time, dbid, 1, @DT
FROM sys.dm_exec_cached_plans AS cp
    CROSS APPLY sys.dm_exec_plan_attributes(cp.plan_handle) pa 
	CROSS APPLY sys.dm_exec_query_plan(plan_handle) AS qp
	JOIN sys.dm_exec_procedure_stats AS qs ON qp.objectid = qs.object_id 
WHERE qp.query_plan.exist('//PlanAffectingConvert[@ConvertIssue="Seek Plan"]') = 1
AND cp.objtype = 'Proc'
AND cp.plan_handle = qs.plan_handle
AND qp.dbid = qs.database_id
AND OBJECT_NAME(CAST(pa.value AS INT),qp.dbid) IS NOT NULL
AND OBJECT_NAME(CAST(pa.value AS INT),qp.dbid) NOT LIKE 'sys%'
AND qp.dbid > 4
AND qp.dbid < 32767;


GO