USE AdventureWorks;
GO

-- Reference: Chapter 2 of Grant Fritchey's book "SQL Server Execution Plans"

------------------------------------------------------------------------------------
-- Demo 0 - How can we "turn on" ESTIMATED and ACTUAL graphical query plans?
--
--		ESTIMATED PLANS =	ICON or RIGHT CLICK ==> Display Est Plan OR CTRL-L
--		ACTUAL PLANS =		ICON or RIGHT CLICK ==> Include Act Query Plan or CTRL-M
-------------------------------------------------------------------------------------
SELECT	*
FROM	HumanResources.Department;

----------------------------------------------------------------------------
-- Demo 1 -	Show the general layout of a graphical execution plan.
-------------------------------------------------------------------------

SET STATISTICS TIME ON;

-- Start out with a large table and demonstrate the following points:

--	1.  Iterators and language elements.
--	2.	The use of a plus sign to navigate the plan.
--	3.	Relative cost of the line widths
--	4.  Relative cost of each node
--	5.	Hover over iterator to bring up details.
--		a.  Logical and physical operators
--		b.	Relative cost of io vs cpu
--		c.	Subtree cost
--		d.	Read indexes: Predicates, output list, object.
--	6.	Properties: What is the optimization level of the select language element?

SELECT	s.salespersonid,
		c.firstname,
		c.middlename,
	    c.lastname,
		e.title AS jobtitle,
		--c.phone,
		c.emailaddress,
		a.addressline1,
		a.city,
		sp.name AS stateprovince,
		a.postalcode,
		cr.name AS countryregion,
		s.salesytd,
		s.saleslastyear
FROM		sales.salesperson s
		INNER JOIN humanresources.employee e 
			ON e.employeeid = s.salespersonid
		LEFT OUTER JOIN sales.salesterritory st 
			ON st.territoryid = s.territoryid
		INNER JOIN demo.contact c 
			ON c.contactid = e.contactid
		INNER JOIN humanresources.employeeaddress ea 
			ON e.employeeid = ea.employeeid 
		INNER JOIN person.[address] a 
			ON ea.addressid = a.addressid
		INNER JOIN person.stateprovince sp 
			ON sp.stateprovinceid = a.stateprovinceid
		INNER JOIN person.countryregion cr 
			ON cr.countryregioncode = sp.countryregioncode;
			
---------------------------------------------------------------------------
---- Demo 2 - Show how the plan is actually stored in the procedure cache.
---------------------------------------------------------------------------

--USE master;
--GO
----DBCC FREEPROCCACHE;
----DBCC DROPCLEANBUFFERS;

--SELECT * 
--FROM		sys.dm_exec_cached_plans cp
--		CROSS APPLY sys.dm_exec_query_plan(cp.plan_handle);
--GO

-------------------------------------------------------------------
-- Demo 3 - Clustered Index Scan
-------------------------------------------------------------------
-- There is a plan for even the simplest query.
-- IOI:	Clustered index scan == table scan
--		What is the SELECT subtree cost?
--		What optimization level is the plan running at?
SELECT	*
FROM	demo.Contact c;

SELECT	TOP 50 *
FROM	demo.contact c;

-------------------------------------------------------------------
-- Demo 4 - TRIVIAL vs. FULL Plans
--			CLUSTERED INDEX SCAN
-------------------------------------------------------------------
-- 450k = trivial; 475k = full
-- 460k = trivial; 465k = full
-- 462.5 = triv; 663k = trivial
-- 464k = FULL; 463.5k = trivial; 
-- 463.75k = triv; 463.9 = full
-- 463.8 = triv; 463.85k = triv;
-- 463.875 = triv; 463.890 = triv;
-- 463.891 = full;
SELECT	TOP 463891 *
FROM	demo.contact c;

-------------------------------------------------------------------
-- Demo 5 - CLUSTERED INDEX SEEK
-------------------------------------------------------------------
-- What is the SELECT subtree cost?
SELECT	*
FROM	Person.contact c
WHERE	c.ContactID = 1957;

SELECT	*
FROM	demo.contact c
WHERE	c.ContactID = 1957;

-------------------------------------------------------------------
-- Demo 6 - Non-CLUSTERED INDEX SEEK / Missing Index
-------------------------------------------------------------------
SELECT	ContactID
FROM	person.contact c
WHERE	c.EmailAddress LIKE 'mike%';

SELECT	ContactID
FROM	demo.contact c
WHERE	c.EmailAddress LIKE 'mike%';

-- Add suggested index
CREATE NONCLUSTERED INDEX idx_nc_demo_emailaddress
	ON [demo].[Contact] ([EmailAddress])
	INCLUDE ([ContactID]);
	
SELECT	ContactID
FROM	demo.contact c
WHERE	c.EmailAddress LIKE 'mike%';

DROP INDEX demo.contact.idx_nc_demo_emailaddress;

-------------------------------------------------------------
-- Demo 7 - Bookmarks: KEY vs. RID Lookups
-------------------------------------------------------------

--DROP INDEX demo.contact.idx_nc_demo_emailaddress;

-- Add suggested index, minus the INCLUDE
CREATE NONCLUSTERED INDEX idx_nc_demo_emailaddress
	ON [demo].[Contact] ([EmailAddress]);
	--INCLUDE ([ContactID]);
	
SELECT	ContactID
FROM	demo.contact c
WHERE	c.EmailAddress LIKE 'mike%';
	
-- Why do we get an index seek with or without the INCLUDE?
-- Reference:	Kalen Delaney
--				Inside Microsoft SQL Server 2005: The Storage Engine
--				p253 Context: Discussion on non-clustered indexes.
--					"the leaf level ... contains a bookmark that tells
--					SQL Server where to find the data row...
--					If the table has a clustered index, the bookmark is
--					the clustered index key for the corresponding
--					data row."

-- What if we need a few more columns?
-- Notice the difference in spread in the cost of the key lookup.
-- Why is the nested loops join used?
-- When is a nested loops join advantageous? 
-- Reference: http://msdn.microsoft.com/en-us/library/ms191318.aspx
-- 1.  Small input sets. (naive nested loops join)
-- 2.  Indexed input sets (index nested loops join)
-- 3.  Builds an index on the fly (temporary index nested loops join)
SELECT	ContactID,
		FirstName,
		LastName
FROM	person.contact c
WHERE	c.EmailAddress LIKE 'mike%';

SELECT	ContactID,
		FirstName,
		LastName
FROM	demo.contact c
WHERE	c.EmailAddress LIKE 'mike%';

-- What happens if our wild card goes wild?
SELECT	ContactID,
		FirstName,
		LastName
FROM	AdventureWorks.demo.contact c
WHERE	c.EmailAddress LIKE 'm%';

SELECT	ContactID,
		FirstName,
		LastName
FROM	AdventureWorks.demo.contact c
WHERE	c.EmailAddress LIKE 'mi%';

SELECT	ContactID,
		FirstName,
		LastName
FROM	AdventureWorks.demo.contact c
WHERE	c.EmailAddress LIKE 'mik%';

---- How can we tell what type of nested loop join is it?
---- Advanced Class
--SET SHOWPLAN_XML ON;
--GO

--SELECT	ContactID,
--		FirstName,
--		LastName
--FROM	AdventureWorks.demo.contact c
--WHERE	c.EmailAddress LIKE 'mike%';

--SET SHOWPLAN_XML OFF;
--GO

-- How can we get rid of that expensive KEY LOOKUP?
DROP INDEX person.contact.idx_demo_key_lookup;

CREATE NONCLUSTERED INDEX idx_demo_key_lookup
	ON	person.contact (emailaddress)
	INCLUDE (firstname, lastname);
	
CREATE NONCLUSTERED INDEX idx_demo_key_lookup
	ON	person.contact (emailaddress, firstname, lastname);
	
SELECT	ContactID,
		FirstName,
		LastName,
		phone
FROM	person.contact c
WHERE	c.EmailAddress LIKE 'mike%';

DROP INDEX person.contact.idx_demo_key_lookup;

-------------------------------------------------------------
-- Demo 8 - TABLE SCAN
-------------------------------------------------------------
-- What happens if we are missing an index altogether?
SELECT	 *
INTO	dbo.tmp_contact
FROM	Person.Contact;

SELECT	ContactID,
		FirstName,
		LastName
FROM	tmp_contact c
WHERE	c.EmailAddress LIKE 'mike%';

-------------------------------------------------------------
-- Demo 9 - RID Bookmarks
-- Let's see if we can replicate that KEY LOOKUP again?
-------------------------------------------------------------
CREATE NONCLUSTERED INDEX idx_demo_key_lookup
	ON	tmp_contact (emailaddress);
	
SELECT	ContactID,
		FirstName,
		LastName
FROM	tmp_contact c
WHERE	c.EmailAddress LIKE 'mike%';

-- What is a RID?

DROP TABLE dbo.tmp_contact;

----------------------------------------------------------------------
----------------------------------------------------------------------
----------------------------------------------------------------------

--------------------------------------------------------------
-- DEMO 10 - How to VOID the use of an INDEX
--------------------------------------------------------------
-- What happens when we don't look at the entire date,
-- just a part of it?
SELECT	c.firstname,
		c.lastname
FROM	person.contact c
WHERE	YEAR(c.modifieddate) = 2003;

-- So add an index on modifieddate
CREATE NONCLUSTERED INDEX idx_contact_moddate
	ON person.contact (modifieddate)
	INCLUDE (firstname,lastname);
	
SELECT	c.firstname,
		c.lastname
FROM	person.contact c
WHERE	YEAR(c.modifieddate) = 2003;

-- What can we do to get our performance back?
-- Still not any better.  Why not?
SELECT	c.firstname,
		c.lastname
FROM	person.contact c
WHERE	c.modifieddate BETWEEN '20030101' AND '20031231';

DROP INDEX person.contact.idx_contact_moddate;

-------------------------------------------------------------------
-- DEMO 11
-- Let's look at the 3 different join types: Nested, Merge and Hash Match
-- Reference BOL: 
-- Nested Loops : http://blogs.msdn.com/craigfr/archive/2006/07/26/679319.aspx
SELECT	c.FirstName,
		c.LastName,
		e.BirthDate,
		CAST ((DATEDIFF(day,	
						e.birthdate, 
						CURRENT_TIMESTAMP) / 365.0 ) 
				AS NUMERIC(5, 2)) AS Age
FROM		Person.Contact c
		INNER JOIN HumanResources.Employee e
			ON	e.ContactID = c.ContactID
WHERE	DATEDIFF(day,	e.birthdate, 
						CURRENT_TIMESTAMP) / 365.0 > 21.0;
						
-----------------------------------------------
-- Merge Join: http://blogs.msdn.com/craigfr/archive/2006/08/03/687584.aspx
-----------------------------------------------
SELECT	c.customerid
FROM		Sales.SalesOrderDetail sod
		INNER JOIN Sales.SalesOrderHeader soh
			ON	soh.SalesOrderID = sod.SalesOrderID
		INNER JOIN Sales.Customer c 
			ON	c.CustomerID = soh.CustomerID;

--------------------------------
-- Hash: http://msdn.microsoft.com/en-us/library/ms189313.aspx
--		http://blogs.msdn.com/craigfr/archive/2006/08/10/687630.aspx
-- What happens if the where clause is added?
--------------------------------
SELECT	c.FirstName,
		c.LastName,
		e.BirthDate,
		a.city,
		CAST ((DATEDIFF(day,	
						e.birthdate, 
						CURRENT_TIMESTAMP) / 365.0 ) 
				AS NUMERIC(5, 2)) AS Age
FROM		Person.Contact c
		INNER JOIN HumanResources.Employee e
			ON	e.ContactID = c.ContactID
		INNER JOIN HumanResources.EmployeeAddress ea
			ON	ea.EmployeeID =e.EmployeeID
		INNER JOIN Person.[Address] a
			ON	a.AddressID = ea.AddressID
--WHERE	DATEDIFF(day,	e.birthdate, 
--						CURRENT_TIMESTAMP) / 365.0 > 21.0;
--If you are getting a hash match can you add a WHERE?


			
-----------------------------------------------------------------
-- DEMO 12: SORT, FILTER
-----------------------------------------------------------------

-- Let's sort the output...
SELECT	c.FirstName,
		c.LastName,
		e.BirthDate,
		a.city,
		CAST ((DATEDIFF(day,	
						e.birthdate, 
						CURRENT_TIMESTAMP) / 365.0 ) 
				AS NUMERIC(5, 2)) AS Age
FROM		Person.Contact c
		INNER JOIN HumanResources.Employee e
			ON	e.ContactID = c.ContactID
		INNER JOIN HumanResources.EmployeeAddress ea
			ON	ea.EmployeeID =e.EmployeeID
		INNER JOIN Person.[Address] a
			ON	a.AddressID = ea.AddressID
WHERE	DATEDIFF(day,	e.birthdate, 
						CURRENT_TIMESTAMP) / 365.0 > 21.0
ORDER BY c.lastname,
		c.firstname;
		
-- What happens if we sort by the contactid?
SELECT	c.FirstName,
		c.LastName,
		e.BirthDate,
		a.city,
		CAST ((DATEDIFF(day,	
						e.birthdate, 
						CURRENT_TIMESTAMP) / 365.0 ) 
				AS NUMERIC(5, 2)) AS Age
FROM		Person.Contact c
		INNER JOIN HumanResources.Employee e
			ON	e.ContactID = c.ContactID
		INNER JOIN HumanResources.EmployeeAddress ea
			ON	ea.EmployeeID =e.EmployeeID
		INNER JOIN Person.[Address] a
			ON	a.AddressID = ea.AddressID
WHERE	DATEDIFF(day,	e.birthdate, 
						CURRENT_TIMESTAMP) / 365.0 > 21.0
ORDER BY c.ContactID;

-- What happens when we add a HAVING clause?
SELECT	city,
		COUNT(*) as [city_cnt]
FROM		Person.[address]
GROUP BY City
HAVING COUNT(*) > 1
ORDER BY City;

---- Use of the HASH MATCH (Aggregate)
--SELECT	city,
--		COUNT(*) as [city_cnt]
--FROM		Person.[address]
--GROUP BY City;

---- Use of the HASH MATCH (Aggregate)
--SELECT	city,
--		COUNT(*) as [city_cnt]
--FROM		Person.[address]
--GROUP BY City
--ORDER BY City;



---- Let's look at a query and re-write it a few different ways.
---- Which one looks the best?
--SELECT	c.FirstName,
--		c.LastName,
--		e.BirthDate,
--		DATEDIFF(day, e.birthdate, CURRENT_TIMESTAMP) / 365.0
--FROM		Person.Contact c
--		INNER JOIN HumanResources.Employee e
--			ON	e.ContactID = c.ContactID
--WHERE	DATEDIFF(day, e.birthdate, CURRENT_TIMESTAMP) / 365.0 > 21.0;

--SELECT	c.FirstName,
--		c.LastName,
--		e.BirthDate,
--		DATEDIFF(day, e.birthdate, CURRENT_TIMESTAMP) / 365.0
--FROM		Person.Contact c
--		INNER JOIN HumanResources.Employee e
--			ON	e.ContactID = c.ContactID AND
--				DATEDIFF(day,	e.birthdate, 
--								CURRENT_TIMESTAMP) / 365.0 > 21.0;

------ How does the age calc in a function work?			
----CREATE FUNCTION	dbo.udf_calc_age ( @birthdate datetime )
----	RETURNS numeric (5, 2)
----AS
----BEGIN
----	RETURN DATEDIFF(day, @birthdate, CURRENT_TIMESTAMP) / 365.0;
----END

--SELECT	c.FirstName,
--		c.LastName,
--		e.BirthDate,
--		dbo.udf_calc_age (e.BirthDate)
--FROM		Person.Contact c
--		INNER JOIN HumanResources.Employee e
--			ON	e.ContactID = c.ContactID
--WHERE	dbo.udf_calc_age (e.BirthDate) > 21.0;

--SELECT	c.FirstName,
--		c.LastName,
--		e.BirthDate,
--		dbo.udf_calc_age (e.BirthDate)
--FROM		Person.Contact c
--		INNER JOIN HumanResources.Employee e
--			ON	e.ContactID = c.ContactID AND
--				dbo.udf_calc_age (e.BirthDate) > 21.0;

---- What happens if we parameterize the query?
--DECLARE	@contactid	int;
--SET	@contactid = 1957;

--SELECT	*
--FROM	person.contact c
--WHERE	c.ContactID = @contactid;


















-- What index are we using?
SELECT	c.emailaddress
FROM	person.contact c;

-- What index are we using?  Why?
SELECT	c.contactid
FROM	person.contact c;

-- Clear procedure cache.
DBCC FREEPROCCACHE;
DBCC DROPCLEANBUFFERS;

-- What index are we using now?  Why?
SELECT	c.contactid
FROM	person.contact c;

-- Now lets add a WHERE clause
SELECT	c.firstname,
		c.lastname
FROM	person.contact c
WHERE	c.modifieddate > '20010501';

-- Now what does the plan look like?

SELECT	*
FROM	Person.Contact c
WHERE	c.EmailAddress LIKE 'dave%';

SELECT	FirstName, 
		LastName,
		emailaddress
FROM	Person.Contact c
WHERE	c.EmailAddress LIKE 'dave%';

SELECT	emailaddress
FROM	Person.Contact c
WHERE	c.EmailAddress LIKE 'dave%';

-- What about that include clause...  
-- What happens if we drop it?

---- What happens when we don't look at the entire date,
---- just a part of it?
--SELECT	c.firstname,
--		c.lastname
--FROM	person.contact c
--WHERE	YEAR(c.modifieddate) = 2003;

---- So add an index on modifieddate
--CREATE NONCLUSTERED INDEX idx_contact_moddate
--	ON person.contact (modifieddate);
--	--INCLUDE (firstname,lastname);
	
--SELECT	c.firstname,
--		c.lastname
--FROM	person.contact c
--WHERE	YEAR(c.modifieddate) = 2003;

---- What can we do to get our performance back?
---- Still not any better.  Why not?
--SELECT	c.firstname,
--		c.lastname
--FROM	person.contact c
--WHERE	c.modifieddate BETWEEN '20030101' AND '20031231';

---- So add an index on modifieddate
--DROP INDEX person.contact.idx_contact_moddate;

--CREATE NONCLUSTERED INDEX idx_contact_moddate
--	ON person.contact (modifieddate)
--	INCLUDE (firstname,lastname);
	
--SELECT	c.firstname,
--		c.lastname
--FROM	person.contact c
--WHERE	c.modifieddate BETWEEN '20030101' AND '20031231';

---- So add an index on modifieddate
--DROP INDEX person.contact.idx_contact_moddate;

-- What about ordering the output?
SELECT	c.firstname,
		c.lastname
FROM	person.contact c
WHERE	c.modifieddate BETWEEN '20030101' AND '20031231'
ORDER BY c.lastname,
		c.firstname;
		
---- Why is the estimated size of the row 113B?
---- What size is the row for this query?
--SELECT	c.firstname AS firstname,
--		c.lastname AS lastname
--FROM	person.contact c
--WHERE	c.modifieddate BETWEEN '20030101' AND '20031231'
--ORDER BY c.lastname,
--		c.firstname;
		
--SELECT	CAST(c.firstname AS CHAR(100)), --AS firstname,
--		CAST(c.lastname AS CHAR(100)) --AS lastname
--FROM	person.contact c
--WHERE	c.modifieddate BETWEEN '20030101' AND '20031231'
--ORDER BY c.lastname,
--		c.firstname;
		
--SELECT	soh.*
--FROM	sales.salesorderheader soh;

--SELECT	soh.salesorderid,
--		soh.revisionnumber,
--		soh.salesordernumber
--FROM	sales.salesorderheader soh;

--DBCC FREEPROCCACHE;
--DBCC DROPCLEANBUFFERS
--GO

--SELECT	customerid, 
--		YEAR(orderdate) AS orderyear, 
--		COUNT(*) AS numorders
--FROM	sales.salesorderheader
--WHERE	customerid = 676
--GROUP BY customerid, 
--		YEAR(orderdate)
--HAVING	COUNT(*) > 1
--ORDER BY customerid, 
--		orderyear;





DBCC FREEPROCCACHE;
DBCC DROPCLEANBUFFERS;

---- How do we know if statistics are set for the database?
--SELECT DATABASEPROPERTYEX('adventureworks', 'isautoupdatestatistics');

--ALTER DATABASE adventureworks
--	SET AUTOUPDATESTATISTICS OFF;


--CREATE TABLE [Person].[demoContact](
--	[ContactID] [int] IDENTITY(1,1) NOT FOR REPLICATION NOT NULL,
--	[FirstName] [dbo].[Name] NOT NULL,
--	[MiddleName] [dbo].[Name] NULL,
--	[LastName] [dbo].[Name] NOT NULL,
--	[EmailAddress] [nvarchar](50) NULL,
-- CONSTRAINT [PK_demoContact_ContactID] PRIMARY KEY CLUSTERED 
--(
--	[ContactID] ASC
--)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
--) ON [PRIMARY];

--INSERT INTO Person.demoContact (	FirstName,
--									MiddleName,
--									LastName,
--									EmailAddress )
--	SELECT	FirstName,
--			MiddleName,
--			LastName,
--			EmailAddress
--	FROM		Person.Contact;
	
---- What is the stats on the pkey index?

---- So let's create some fragmentation
--DELETE	FROM Person.demoContact
--WHERE	ContactID % 3 = 0;

--select * from Person.demoContact
--where ContactID % 3 = 0

--DROP TABLE person.democontact;

--ALTER DATABASE adventureworks
--	SET AUTOUPDATESTATISTICS ON;