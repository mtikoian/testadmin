
/* Demo 1 - Basic Execution Plan*/
SELECT emp.*, lnkadd.*, addr.AddressLine1, addr.City, addr.PostalCode
FROM HumanResources.Employee emp
LEFT JOIN HumanResources.EmployeeAddress lnkadd ON emp.EmployeeID = lnkadd.EmployeeID
LEFT JOIN Person.Address addr ON lnkadd.AddressID = addr.AddressID

/* Demo 2 - Stored Execution Plans */
SELECT [cp].[refcounts]
   ,[cp].[usecounts]
   ,[cp].[objtype]
   ,[st].[dbid]
   ,[st].[objectid]
   ,[st].[text]
   ,[qp].[query_plan]
FROM sys.dm_exec_cached_plans cp
CROSS APPLY sys.dm_exec_sql_text(cp.plan_handle) st
CROSS APPLY sys.dm_exec_query_plan(cp.plan_handle)
qp;

/* Demo 3 - Index Seek vs. Index Scan */

-- Scan
SELECT emp.*, lnkadd.*, addr.AddressLine1, addr.City, addr.PostalCode
FROM HumanResources.Employee emp
LEFT JOIN HumanResources.EmployeeAddress lnkadd ON emp.EmployeeID = lnkadd.EmployeeID
LEFT JOIN Person.Address addr ON lnkadd.AddressID = addr.AddressID

-- Seek
SELECT emp.*, lnkadd.*, addr.AddressLine1, addr.City, addr.PostalCode
FROM HumanResources.Employee emp
LEFT JOIN HumanResources.EmployeeAddress lnkadd ON emp.EmployeeID = lnkadd.EmployeeID
LEFT JOIN Person.Address addr ON lnkadd.AddressID = addr.AddressID
WHERE emp.EmployeeID IN (5,35)

/* Demo 4 - Rebind and Rewind */
/* Query by Gary Fritchey -  bit.ly/P7EUv3 */
SELECT  sod.SalesOrderDetailID 
FROM    Sales.SalesOrderDetail AS sod 
WHERE   LineTotal < (SELECT AVG(dos.LineTotal) 
                     FROM   Sales.SalesOrderDetail AS dos 
                     WHERE  dos.ModifiedDate < sod.ModifiedDate 
                    ) 
