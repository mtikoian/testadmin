/***********************************************************

Pre-Session Set Up
	
	1. Set up Make sure show actual execution plan is on
	2. Start ZoomIt application
	3. Start Activity Monitor
	4. Open a plan in Plan Explorer
	5. Open CompareEP.sqlPlan in SSMS
	6. Required Databases 
			[AdventureWorks2016], [AdventureWorks2014], [ConvertExample]

			  
***********************************************************/


/****************************

	Demo #1 - Enable Plans to appear and Demo #2 - Tool Tips

		1.  Demo how to turn on Actual and Estimated execution plans in SQL Server Management Studio
		2.  Show how to get the tools tips to show up


*****************************/

--Confirm Display Actual Execution plan is turned off

--Demo #1 and #2
		
	USE [AdventureWorks2016]


	SELECT * 
	FROM [HumanResources].[Department]

	

/*****************************

	Demo #3 - Index Scan vs Index Seek vs Table Scan

		1.  Show how a table scan, Index Scan and Index seek differ

******************************/

	USE ConvertExample

	--Table Scan - No Index on table
	SELECT  [ProductID]
		  ,[ProductName]
		  ,[QtyInStock]
		  ,[CategoryID]
	  FROM [ConvertExample].[dbo].[ProductIndex]
	  Where productid = 1

	--Index Seek

	SELECT  [ProductID]
		  ,[ProductName]
		  ,[QtyInStock]
		  ,[CategoryID]
	FROM [ConvertExample].[dbo].[Product]
	WHERE productid = 1

	--Index Scan

	SELECT  [ProductID]
		  ,[ProductName]
		  ,[QtyInStock]
		  ,[CategoryID]
	FROM [ConvertExample].[dbo].[Product]

/*****************************

	Demo #4 - Join physical operators

		1.  Show how the physical operator can impact performance
		3.  Run all three at the same time

******************************/

	USE AdventureWorks2016

	 --Merge Join
	SELECT * 
	FROM Sales.Customer AS c
		INNER JOIN Sales.Customer AS ca 
			ON c.CustomerID = ca.CustomerID
	WHERE ca.TerritoryID = 5  

	--Nested Loop
	SELECT * 
	FROM Sales.Customer AS c
		INNER JOIN Sales.Customer AS ca 
			ON c.CustomerID = ca.CustomerID
	WHERE ca.TerritoryID = 5  
	OPTION (LOOP JOIN);

	--Hash Join
	SELECT * 
	FROM Sales.Customer AS c
		INNER JOIN Sales.Customer AS ca 
			ON c.CustomerID = ca.CustomerID
	WHERE ca.TerritoryID = 5  
	OPTION (HASH JOIN);


/*****************************

	Demo #5 - Parallelism

	

******************************/


	USE [AdventureWorks2016]

	SELECT  *
	FROM Sales.SalesOrderDetail
	ORDER BY ProductID

	--No Parallelism

	SELECT  *
	FROM Sales.SalesOrderDetail
	ORDER BY ProductID
	OPTION (MAXDOP 1)
	GO

/*****************************

	Demo #6 - Hidden processing

******************************/

	--Hidden use of a Cursor
	 EXECUTE master.sys.sp_MSforeachdb 'USE [?]; EXEC sp_spaceused'

	 --Scalar Funtions due to calculated columns
	 SELECT *
		FROM Sales.SalesOrderHeader
		WHERE DueDate > ShipDate
		ORDER BY OrderDate;
/*****************************

	Demo #7 - Implicit Conversion

******************************/

	USE ConvertExample


	DECLARE @Category INT
	SELECT @Category = 2

	SELECT PC.CategoryName,
		 P.ProductID,
		 P.ProductName
	FROM ProductCategory PC
		 INNER JOIN Product P 
			ON P.CategoryID = PC.CategoryID
	WHERE PC.CategoryID = @Category;



/*****************************/

	--Demo #8 - 
		--Two calculated columns in the table
	USE [AdventureWorks2016]
	SELECT *
	FROM [Sales].[SalesOrderHeader]

/************************************/

--Demo 9

--See Execution Plan
 
			SELECT [h].[SalesOrderID], [d].[SalesOrderDetailID], [h].[CustomerID]
			FROM [Sales].[SalesOrderDetail] [d],
			[Sales].[SalesOrderHeader] [h]
			WHERE [d].[ProductID] = 897;


 
			-- Columns with no statistics
			USE [AdventureWorks2014]
			SELECT [BusinessEntityID], [NationalIDNumber], [JobTitle], [HireDate], [ModifiedDate]
			FROM [HumanResources].[Employee]
			WHERE [HireDate] >= '2013-01-01';
			GO

--See Data from Extended Events Session

				-- Create XML variable to hold Target Data
				DECLARE @target_data XML
				SELECT @target_data = 
					CAST(target_data AS XML)
				FROM master.sys.dm_xe_sessions AS s 
				JOIN master.sys.dm_xe_session_targets AS t 
					ON t.event_session_address = s.address
				WHERE s.name = 'FindExecutionPlanWarnings'
				  AND t.target_name = 'ring_buffer'


				---- Query the XML variable to get the Target Data

				SELECT 

					DATEADD(hh, 
							DATEDIFF(hh, GETUTCDATE(), CURRENT_TIMESTAMP), 
							n.value('(event/@timestamp)[1]', 'datetime2')) AS [timestamp],
							n.value('(event/action[@name="username"]/value)[1]', 'varchar(100)') as UserName,
							n.value('(event/action[@name="client_hostname"]/value)[1]', 'varchar(100)') as client_hostname,
							n.value('(event/action[@name="client_app_name"]/value)[1]', 'varchar(100)') as client_app_name,
							n.value('(event/action[@name="offset"]/value)[1]', 'varchar(100)') as Offset,
							n.value('(event/action[@name="database_name"]/value)[1]', 'varchar(100)') as Databasename,
							n.value('(event/action[@name="sql_text"]/value)[1]', 'varchar(max)') as sql_text ,
							n.value('(event/data[@name="statement"]/value)[1]', 'varchar(max)') as statement ,
							n.value('(event/data[@name="column_list"]/value)[1]', 'varchar(max)') as ColumnListMissingColumnsStats,
							n.value('(event/data[@name="unmatched_table_name"]/value)[1]', 'varchar(max)') as UnmatchedTableName,
							n.value('(event/data[@name="unmatched_index_name"]/value)[1]', 'varchar(max)') as UnmatchedIndexName,
							n.value('(event/data[@name="unmatched_database_name"]/value)[1]', 'varchar(max)') as UnmatchedDBName,
							n.value('(event/data[@name="expression"]/value)[1]', 'varchar(max)') as PlanConvert
				FROM
				(    SELECT td.query('.') as n
				FROM @target_data.nodes('//RingBufferTarget/event') AS q(td)
				) as tab
				
				ORDER BY 1 desc
				GO

/******************************/
--Demo #10
--Turn on Live Statistics
Use [AdventureWorks2016]
SELECT * FROM Production.TransactionHistory th
INNER JOIN Production.TransactionHistoryArchive tha ON th.Quantity = tha.Quantity

/******************************/

--Examining SQL Server processes

--Now let�s examine what is happening in our system. 
--The query below can help in finding the currently executing queries in SQL Server:If a SQL Server process is consuming high CPU, 
--then executing the above query can help in finding the various requests currently getting executed inside SQL Server.

SELECT
r.session_id
	,st.TEXT AS batch_text
	,SUBSTRING(st.TEXT, statement_start_offset / 2 + 1, (
			(
				CASE 
					WHEN r.statement_end_offset = - 1
						THEN (LEN(CONVERT(NVARCHAR(max), st.TEXT)) * 2)
					ELSE r.statement_end_offset
					END
				) - r.statement_start_offset
			) / 2 + 1) AS statement_text
	,qp.query_plan AS 'XML Plan'
	,r.*
FROM sys.dm_exec_requests r
CROSS APPLY sys.dm_exec_sql_text(r.sql_handle) AS st
CROSS APPLY sys.dm_exec_query_plan(r.plan_handle) AS qp
ORDER BY cpu_time DESC



/*****************************

	Code for "First Look at Execution Plan" slide

******************************/

USE [AdventureWorksDW2016]

GO


SELECT TOP 5
		[SalesOrderNumber]
		,[SalesOrderLineNumber]
		,[RevisionNumber]
		,[SalesAmount]
		,[TaxAmt]
		,[CustomerPONumber]
		, p.EnglishDescription + ' ' + p.EnglishProductName
  FROM [dbo].[FactInternetSales] FI
				INNER JOIN [dbo].[FactFinance]  FF 
					ON FI.DueDateKey = FF.DateKey
				INNER JOIN dimproduct p 
					ON fi.productkey = p.productkey
  WHERE MONTH([DueDate]) = 02
  ORDER BY 3

/*********************************************************

These two statements produces exactly the same plan


*********************************************************/


	--Exists
	SELECT a.FirstName
			, a.LastName
	FROM Person.Person AS a
	WHERE EXISTS
		(SELECT * 
			FROM HumanResources.Employee AS b
			WHERE a.BusinessEntityID = b.BusinessEntityID
				AND a.LastName = 'Johnson');

	--IN
	SELECT a.FirstName
			, a.LastName
	FROM Person.Person AS a
	WHERE a.LastName IN
		(SELECT a.LastName
			FROM HumanResources.Employee AS b
			WHERE a.BusinessEntityID = b.BusinessEntityID
				AND a.LastName = 'Johnson');

/*********************************************************

Code for [ConvertExample] database

Make sure to create the database first

The code for the tables in the demo that end in Index use 
		the same code, just add Index to the end of the table name

Code obtained from BrentOzar.com
*********************************************************/


CREATE TABLE ProductCategory
(
     CategoryID INT Primary Key,
     CategoryName VARCHAR(50)
);
CREATE TABLE Product
(
     ProductID INT Primary Key,
     ProductName VARCHAR(100),
     QtyInStock INT,
     CategoryID VARCHAR(10)
) ;

INSERT INTO ProductCategory (CategoryID, CategoryName)
VALUES (1, 'Ale'),
(2, 'Lager'),
(3, 'N/A');

INSERT INTO Product (ProductID, ProductName, QtyInStock, CategoryID)
VALUES (1, 'Spotted Cow', 8966, '1'),
(2, 'Fat Squirrel', 7643, '1'),
(3, 'Moon Man', 339, '1'),
(4, 'Two Women', 1224, '2'),
(5, 'Home Town Blonde', 564, '2'),
(6, 'Ginger Ale', 899, '3');

/**********************************************

How to get the worst performing queries

**********************************************/

SELECT TOP 20 SUBSTRING(qt.text, (qs.statement_start_offset/2)+1, 
        ((CASE qs.statement_end_offset
          WHEN -1 THEN DATALENGTH(qt.text)
         ELSE qs.statement_end_offset
         END - qs.statement_start_offset)/2)+1) 
		, qs.execution_count
		, qs.total_logical_reads
		, qs.last_logical_reads
		, qs.min_logical_reads
		, qs.max_logical_reads
		, qs.total_elapsed_time
		, qs.last_elapsed_time
		, qs.min_elapsed_time
		, qs.max_elapsed_time
		, qs.last_execution_time
		, qp.query_plan
FROM sys.dm_exec_query_stats qs
	CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle) qt
		CROSS APPLY sys.dm_exec_query_plan(qs.plan_handle) qp
WHERE qt.encrypted=0
ORDER BY qs.total_logical_reads DESC

/**********************************************

Find the top 100 plans in cache by useage count

**********************************************/
SELECT TOP 100
        cacheobjtype
       ,objtype
       ,p.size_in_bytes
       ,LEFT([sql].[text], 100) AS [text]
       ,plan_handle
	   , p.*
 FROM  sys.dm_exec_cached_plans p
    OUTER APPLY sys.dm_exec_sql_text(p.plan_handle) sql
 ORDER BY usecounts DESC 


 /*********************************************************

 Remove a Table Spool

 *********************************************************/
         --Initial table
DECLARE @logins TABLE
(
         login_id INT IDENTITY(1,1) PRIMARY KEY
       , [user_id] INT
       , login_date DATETIME
)
INSERT INTO @logins ([user_id], login_date)
VALUES
       (1, '20130911 14:33:29'), (1, '20130912 15:36:39'),
       (2, '20130914 14:13:03'), (2, '20130917 05:56:18'),
       (3, '20130910 16:30:29'), (1, '20130908 18:25:39')


DELETE FROM @logins
WHERE login_id NOT IN (
       SELECT MAX(login_id)
       FROM @logins
       GROUP BY [user_id]
)

--Same query but uses the Row_Number function
DELETE t FROM (
       SELECT rn = ROW_NUMBER() OVER (
                                 PARTITION BY [user_id]
                                 ORDER BY login_date DESC
                           )
       FROM @logins
) t
WHERE t.rn > 1

SELECT * FROM @logins