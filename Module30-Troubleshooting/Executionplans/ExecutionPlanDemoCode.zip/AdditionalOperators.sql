Select *
from [Sales].[SalesOrderHeader]

Select *
from [Sales].[SalesOrderHeader]
order by SalesOrderID desc

Select *
from [Sales].[SalesOrderHeader]
order by SalesPersonID

Select *
from [Sales].[SalesOrderHeader]
where DueDate > '01/01/2015'
order by SalesPersonID

Select Count(*), avg(Taxamt)
from [Sales].[SalesOrderHeader]

Select Count(*)
from [Sales].[SalesOrderHeader]
