-- Create XML variable to hold Target Data
DECLARE @target_data XML
SELECT @target_data = 
    CAST(target_data AS XML)
FROM master.sys.dm_xe_sessions AS s 
JOIN master.sys.dm_xe_session_targets AS t 
    ON t.event_session_address = s.address
WHERE s.name = 'FindExecutionPlanWarnings'
  AND t.target_name = 'ring_buffer'


---- Query the XML variable to get the Target Data

SELECT 

    DATEADD(hh, 
            DATEDIFF(hh, GETUTCDATE(), CURRENT_TIMESTAMP), 
            n.value('(event/@timestamp)[1]', 'datetime2')) AS [timestamp],
			n.value('(event/action[@name="username"]/value)[1]', 'varchar(100)') as UserName,
			n.value('(event/action[@name="client_hostname"]/value)[1]', 'varchar(100)') as client_hostname,
			n.value('(event/action[@name="client_app_name"]/value)[1]', 'varchar(100)') as client_app_name,
			n.value('(event/action[@name="offset"]/value)[1]', 'varchar(100)') as Offset,
			n.value('(event/action[@name="database_name"]/value)[1]', 'varchar(100)') as Databasename,
			n.value('(event/action[@name="sql_text"]/value)[1]', 'varchar(max)') as sql_text ,
			n.value('(event/data[@name="statement"]/value)[1]', 'varchar(max)') as statement ,
			n.value('(event/data[@name="column_list"]/value)[1]', 'varchar(max)') as ColumnListMissingColumnsStats,
			n.value('(event/data[@name="unmatched_table_name"]/value)[1]', 'varchar(max)') as UnmatchedTableName,
			n.value('(event/data[@name="unmatched_index_name"]/value)[1]', 'varchar(max)') as UnmatchedIndexName,
			n.value('(event/data[@name="unmatched_database_name"]/value)[1]', 'varchar(max)') as UnmatchedDBName,
			n.value('(event/data[@name="expression"]/value)[1]', 'varchar(max)') as PlanConvert
FROM
(    SELECT td.query('.') as n
FROM @target_data.nodes('//RingBufferTarget/event') AS q(td)
) as tab
				
ORDER BY 1 desc
GO