﻿<#
    First we prepare the environment for the demo

#>
Import-Module SQLPS -DisableNameChecking
Import-Module SQLServer
Import-Module PSFTP

set-location d:\

# Dot-source our Functions we will use
. "D:\Data\Dropbox\Documents\Presentations\SQL Saturday 222\LogShipping\Logship.ps1"

<#
    Finished preparing the environment
    You can have these in a profile or load them
    on demand as you need them for your automation
#>

Start-SQLLogShipping -sqlserver 'localhost\I12' -DBName DemoDB `
    -BackupDirectory 'D:\Demos\SQLSAT222\Outgoing'

Send-FilesToFTP -FTPDestination 192.168.255.137 `
    -FTPSession "LogShip2" -Credential (Get-Credential)

Backup-SqlDatabase -ServerInstance 'localhost\I12' -Database DemoDB `
     -BackupAction Log -BackupFile 'D:\Demos\SQLSAT222\Outgoing\firsttest.trn' `
     -CompressionOption On

Send-FilesToFTP -FTPDestination 192.168.255.134 `
    -FTPSession "LogShip2" -Credential (Get-Credential)
