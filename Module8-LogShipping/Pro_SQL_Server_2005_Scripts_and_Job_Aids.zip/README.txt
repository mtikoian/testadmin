Thank you for purchasing my book Pro SQL Server 2005 High Availability. I hope
you are enjoying it.

This ZIP file contains the scripts mentioned throughout the book and 
are broken down by chapter. There are also some additional scripts and job aids 
not mentioned.

You can check each chapter's directory for specific information relating 
to the code provided, and you can also check each script for execution
parameters and instruction text.

The Microsoft AIT scripts can be found in Chapter 3's folder. Remember that there
are more scripts that can be used besides the backup and restore ones.