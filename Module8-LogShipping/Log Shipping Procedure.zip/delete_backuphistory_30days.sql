USE MSDB
GO
declare @day30 datetime
declare @current_date datetime

select @current_date = getdate()

select @day30 = DATEADD(mm,-1,@current_date)
print @day30

EXEC sp_delete_backuphistory @day30