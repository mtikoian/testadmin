/****************************************************************************/
/* INSTLOG.SQL                                                              */
/*                                                                          */
/* Location: \\manuva3\public                                               */
/*                                                                          */
/*                                                                          */
/* Creates tables and SPs for setting up log shipping on SQL Server 7       */
/*                                                                          */
/* Copyright Microsoft, Inc. 1996 - 1998.                                   */
/* All Rights Reserved.                                                     */
/*                                                                          */
/* Microsoft, Inc. One Microsoft Way, Redmond WA. 98052.                    */
/****************************************************************************/

USE msdb
GO
SET QUOTED_IDENTIFIER OFF
GO
/****************************************************************************/
/*   Drop all tables                                                        */
/****************************************************************************/
IF (EXISTS (SELECT *
            FROM sysobjects
            WHERE (name = N'backup_movement_plan_history') AND (type = 'U')))
BEGIN
  PRINT ''
  PRINT 'Dropping table backup_movement_plan_history...'
  DROP TABLE backup_movement_plan_history
END

IF (EXISTS (SELECT *
            FROM sysobjects
            WHERE (name = N'backup_movement_plan_databases') AND (type = 'U')))
BEGIN
  PRINT ''
  PRINT 'Dropping table backup_movement_plan_databases...'
  DROP TABLE backup_movement_plan_databases
END

IF (EXISTS (SELECT *
            FROM sysobjects
            WHERE (name = N'backup_movement_plans') AND (type = 'U')))
BEGIN
  PRINT ''
  PRINT 'Dropping table backup_movement_plans...'
  DROP TABLE backup_movement_plans
END

/****************************************************************************/
/*   Create the tables                                                      */
/****************************************************************************/

PRINT ''
PRINT 'Creating table backup_movement_plans...'

CREATE TABLE backup_movement_plans
(
  plan_id         UNIQUEIDENTIFIER NOT NULL PRIMARY KEY CLUSTERED,
  plan_name       sysname          NULL,
  source_dir      NVARCHAR(256)    NOT NULL,
  destination_dir NVARCHAR(256)    NOT NULL,
  database_subdir BIT              NOT NULL DEFAULT (1)
)

PRINT ''
PRINT 'Creating table backup_movement_plan_databases...'

CREATE TABLE backup_movement_plan_databases
(
  plan_id              UNIQUEIDENTIFIER NOT NULL FOREIGN KEY REFERENCES backup_movement_plans(plan_id),
  source_database      sysname          NOT NULL,
  destination_database sysname          NOT NULL,
  source_server        sysname          NOT NULL DEFAULT (@@servername),
  load_delay           INT              NOT NULL DEFAULT(0),  -- In minutes
  load_all             BIT              NOT NULL DEFAULT(1),
  retention_period     INT              NOT NULL DEFAULT(48), -- In hours
  last_file_copied     NVARCHAR(256)    NULL,
  date_last_copied     DATETIME         NULL,
  last_file_loaded     NVARCHAR(256)    NULL,
  date_last_loaded     DATETIME         NULL
)

PRINT ''
PRINT 'Creating table backup_movement_plan_history...'

CREATE TABLE backup_movement_plan_history
(
  sequence_id          INT              NOT NULL IDENTITY UNIQUE CLUSTERED,
  plan_id              UNIQUEIDENTIFIER NOT NULL DEFAULT ('00000000-0000-0000-0000-000000000000'),
  plan_name            sysname          NOT NULL DEFAULT ('All ad-hoc plans'),
  destination_server   sysname          NOT NULL DEFAULT (@@servername),
  -- server_name          sysname          NOT NULL DEFAULT (@@servername), -- Will be regressed out -- Fianlly regressed out
  source_server        sysname          NOT NULL DEFAULT (@@servername),
  source_database      sysname          NOT NULL,
  destination_database sysname          NOT NULL,
  activity             BIT              NOT NULL DEFAULT (0),
  succeeded            BIT              NOT NULL DEFAULT (1),
  num_files            INT              NOT NULL DEFAULT (0),
  last_file            NVARCHAR(256)    NULL,
  end_time             DATETIME         NOT NULL DEFAULT (GETDATE()),
  duration             INT              NULL     DEFAULT (0),
  error_number         INT              NOT NULL DEFAULT (0),
  message              NVARCHAR(512)    NULL
)  

GO

/****************************************************************************/
/*   Create a sp for creating new plans                                     */
/****************************************************************************/
IF (EXISTS (SELECT *
            FROM msdb.dbo.sysobjects
            WHERE (name = N'sp_create_backup_movement_plan')
              AND (type = 'P')))
  DROP PROCEDURE sp_create_backup_movement_plan
GO

CREATE PROCEDURE sp_create_backup_movement_plan
    @name          sysname,
    @source_dir    VARCHAR(256),
    @dest_dir      VARCHAR(256),
    @sub_dir       BIT = 1, -- Each database has it's own sub-directory?
    @load_job_freq INT = 5, -- In Minutes
    @copy_job_freq INT = 5  -- In Minutes
AS
BEGIN

BEGIN TRANSACTION
  SET       NOCOUNT             ON
  SET       QUOTED_IDENTIFIER   OFF
  SET       ANSI_NULLS          ON 

  DECLARE   @PlanID        uniqueidentifier
  DECLARE   @CopyJobName   sysname
  DECLARE   @LoadJobName   sysname
  DECLARE   @CopyCommand   VARCHAR(500)
  DECLARE   @LoadCommand   VARCHAR(500)
  DECLARE   @ReturnCode    INT

  -- Create a GUID for the plan
  SELECT    @PlanID        = NEWID()
    
  -- Check if a plan with the same name exists
  IF (EXISTS (SELECT * 
              FROM   msdb.dbo.backup_movement_plans
              WHERE  plan_name = @name ) )
  BEGIN
    RAISERROR('A backup movement plan with the same name already exists. Specify a differnt name.', 16, 1)
    GOTO QuitWithRollback
  END

  -- Insert plan in the table
  INSERT   msdb.dbo.backup_movement_plans 
           (plan_id, plan_name, source_dir, destination_dir, database_subdir)
  VALUES
           (@PlanID, @name, @source_dir, @dest_dir, @sub_dir)


  SELECT @CopyJobName = N'Copy Job For ' + @name
  SELECT @LoadJobName = N'Load Job For ' + @name
  SELECT @CopyCommand = N'EXECUTE master.dbo.xp_sqlmaint ''-CopyPlanName "' + @name + '" '' '
  SELECT @LoadCommand = N'EXECUTE master.dbo.xp_sqlmaint ''-LoadPlanName "' + @name + '" '' '

  /*****************************************************************************/
  /* Create the Load Job                                                       */
  EXECUTE @ReturnCode = msdb.dbo.sp_add_job @job_name = @LoadJobName
  IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

  EXECUTE @ReturnCode = msdb.dbo.sp_add_jobstep @job_name = @LoadJobName, @step_id=1, @step_name = N'step1', 
     @command = @LoadCommand, @subsystem = N'TSQL', @on_success_step_id = 0, @on_success_action = 1, 
     @on_fail_step_id = 0, @on_fail_action = 2, @flags = 4
  IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback 

  EXECUTE @ReturnCode = msdb.dbo.sp_add_jobschedule @job_name = @LoadJobName, 
     @freq_subday_interval = @load_job_freq, 
     @name = N'sch1', @enabled = 1, @freq_type = 4, @active_start_date = 19980402, 
     @active_start_time = 0, @freq_interval = 1, @freq_subday_type = 4, @freq_relative_interval = 0, 
     @freq_recurrence_factor = 0, @active_end_date = 99991231, @active_end_time = 235959
  IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback 

  EXECUTE @ReturnCode = msdb.dbo.sp_add_jobserver @job_name = @LoadJobName, @server_name = N'(local)' 
  IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback 

  /*****************************************************************************/
  /* Create the Copy Job                                                       */
  EXECUTE @ReturnCode = msdb.dbo.sp_add_job @job_name = @CopyJobName
  IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback 

  EXECUTE @ReturnCode = msdb.dbo.sp_add_jobstep @job_name = @CopyJobName, @step_id = 1, @step_name = N'step1', 
     @command = @CopyCommand, @subsystem = N'TSQL', @on_success_step_id = 0, @on_success_action = 1, 
     @on_fail_step_id = 0, @on_fail_action = 2, @flags = 4
  IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback 

  EXECUTE @ReturnCode = msdb.dbo.sp_add_jobschedule @job_name = @CopyJobName, 
     @freq_subday_interval = @copy_job_freq, 
     @name = N'sch1', @enabled = 1, @freq_type = 4, @active_start_date = 19980402, 
     @active_start_time = 0, @freq_interval = 1, @freq_subday_type = 4, @freq_relative_interval = 0, 
     @freq_recurrence_factor = 0, @active_end_date = 99991231, @active_end_time = 235959
  IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback 

  EXECUTE @ReturnCode = msdb.dbo.sp_add_jobserver @job_name = @CopyJobName, @server_name = N'(local)' 
  IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback 

COMMIT TRANSACTION          
GOTO   EndSave              
QuitWithRollback:
 IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION 
EndSave: 
END 

GO

/*****************************************************************************/
/*   Create a sp for adding a database to an plan                            */
/*****************************************************************************/
IF (EXISTS (SELECT *
            FROM msdb.dbo.sysobjects
            WHERE (name = N'sp_add_db_to_backup_movement_plan')
              AND (type = 'P')))
  DROP PROCEDURE sp_add_db_to_backup_movement_plan

GO
CREATE PROCEDURE sp_add_db_to_backup_movement_plan
    @plan_id       uniqueidentifier   = NULL,
    @plan_name     sysname            = NULL,
    @source_db     sysname,
    @dest_db       sysname,
    @load_delay    INT                = 0,            -- In Minutes
    @load_all      BIT                = 1,
    @source_server sysname            = @@servername, -- just information: carried over to the history table
    @retention_period INT             = 48            -- In Hours. 0 implies do not delete files 
AS
BEGIN
    SET       NOCOUNT             ON
    SET       QUOTED_IDENTIFIER   OFF
    SET       ANSI_NULLS          ON 
    DECLARE   @PlanID             uniqueidentifier

    if((@plan_id IS NULL) AND (@plan_name IS NULL))
    BEGIN
      RAISERROR('You must supply the plan name or the plan id.', 16, 1)
      RETURN(1)
    END

    IF (@plan_id IS NULL)
    BEGIN        
        IF (NOT EXISTS (SELECT * 
                        FROM   msdb.dbo.backup_movement_plans
                        WHERE  plan_name = @plan_name ) )
        BEGIN
          RAISERROR('Backup movement plan with this name was not found.', 16, 1)
          RETURN(1)
        END

        IF (SELECT COUNT(*) 
            FROM   msdb.dbo.backup_movement_plans
            WHERE  plan_name = @plan_name) > 1
        BEGIN
          RAISERROR('There are more than one backup movement plans with this name.', 16, 1)
          RETURN(1)
        END

        SELECT @PlanID = plan_id 
        FROM   msdb.dbo.backup_movement_plans
        WHERE  plan_name = @plan_name
    END
    ELSE
    BEGIN
        SELECT @PlanID = @plan_id 
        IF (NOT EXISTS (SELECT * 
                        FROM   msdb.dbo.backup_movement_plans
                        WHERE  plan_id = @plan_id ) )
        BEGIN
          RAISERROR('Backup movement plan with this id.', 16, 1)
          RETURN(1)
        END

        IF (SELECT COUNT(*) 
            FROM   msdb.dbo.backup_movement_plans
            WHERE  plan_id = @plan_id) > 1
        BEGIN
          RAISERROR('There are more than one backup movement plans with this id.', 16, 1)
          RETURN(1)
        END
    END

    if(EXISTS ( SELECT   *
                FROM     msdb.dbo.backup_movement_plan_databases
                WHERE    plan_id = @PlanID AND source_database = @source_db AND destination_database = @dest_db ))
    BEGIN
      RAISERROR('These databases are already included in this plan.', 16, 1)
      RETURN(1)
    END
        
    INSERT msdb.dbo.backup_movement_plan_databases
	      (plan_id, source_database, destination_database, load_delay, load_all, source_server, retention_period)
    VALUES
          (@PlanID, @source_db, @dest_db, @load_delay, @load_all, @source_server, @retention_period)
END
    
GO

IF (EXISTS (SELECT *
            FROM msdb.dbo.sysobjects
            WHERE (name = N'sp_create_jobs_for_backup_movement_plan')
              AND (type = 'P')))
  DROP PROCEDURE sp_create_jobs_for_backup_movement_plan
/*****************************************************************************/
