
if exists (select * from sysobjects where id = object_id('log_ship_status') and sysstat & 0xf = 4)
	BEGIN
	  PRINT ''
	  PRINT 'Dropping log_ship_status procedure...'
	  DROP PROCEDURE log_ship_status
	END

GO

/*
*****************************************************************************************
File:	log_ship_sprocs.sql
Name:	log_ship_status

Description:
	This sproc displays the time delta between the primary and secondard database 
	of a log shipping entity pair.
	Must be run on the secondary server where the logs are loaded..
	Since the dumptrdate column no longer exists in SQL 7.0, we determine the 
	equivalent information by obtaining the BackupStartDate from msdb..backupset 
	for the last transaction log loaded into each secondary database.

Depends On:
	Log shipping must be installed.

Notes:
	Installation should check to see if log shipping has been installed.  
	If not present, sproc shoudl not install.  Not implemented.

	log_ship_status will not work (as written) on a rollup server as the
	BackupStartDate value is not on the rollup server.

Installation:	
	Install in MSDB on secondary server.
	
Processing Steps:
	

Tables Used:
	msdb..backup_movement_plan_databases
	msdb..restorehistory
	
Parameters:
	Optional parameters: 'primary server', 'primary database'
	No longer accepts secondary server or secondary database. The 'secondary server' is 
	not stored in the table.  
	If no parameters are supplied, display  log shipping status information for all 
	entities on the secondary server.

Return Value:
	None
Called By:
	None
Calls:
	None

Change History:
	Date:	 Author		 Description
	-----    -------         --------------------------------------------------------
	5/98			Initial script creation to support log shipping.
	10/98			BORK update, fixed case sensitive vars

	Copyright Microsoft, Inc. 1996 - 1998.                                   
	All Rights Reserved.                                                     
                                                                         
	Microsoft, Inc. One Microsoft Way, Redmond WA. 98052. 

*****************************************************************************************
*/



CREATE PROCEDURE dbo.log_ship_status
	@p_svr         varchar( 30 ) = NULL,
	@p_db          varchar( 30 )= NULL

AS
Begin

set nocount on
DECLARE @dest_db char(30),
	@history_id int,
	@time_delta int

CREATE TABLE #table (	destination_db  CHAR(30),
			time_delta	INT)

-- 	Walk through each secondary database defined in msdb..backup_movement_plan_databases
--	and calculate the time delta ('current time' - 'creation time of last t-log loaded')
--	and populate the temp table #table.

DECLARE log_ship_cursor CURSOR
	FOR SELECT destination_database 
	from backup_movement_plan_databases

OPEN log_ship_cursor

FETCH NEXT FROM log_ship_cursor 
	into @dest_db

	WHILE @@FETCH_STATUS = 0
	BEGIN
		set nocount on

--		determine last tlog loaded into destination (secondary) database	

		select	@history_id = (select	max(restore_history_id)
					from	restorehistory
					where	destination_database_name = @dest_db)
--		Determine time delta

		select 	@time_delta = (select datediff(mi, (select backup_start_date from backupset
					where backup_set_id = (
						select	backup_set_id
						from	restorehistory
						where	restore_history_id = @history_id)),
					getdate()))


		INSERT INTO #table VALUES( @dest_db, @time_delta)
		FETCH NEXT from log_ship_cursor into @dest_db
	end


close log_ship_cursor
DEALLOCATE log_ship_cursor


/***************************************************************/
/*	Format the output 					*/


SELECT	"Primary Srv" = CONVERT(char(30),source_server),
	"Primary DB" = CONVERT(char(30),source_database),
	"Secondary DB" = CONVERT(char(30),destination_database),
	"Delta" = time_delta,
	"Load All" = CASE WHEN (load_all = 0) THEN "No" ELSE "Yes" end,
	"Load Delay" = load_delay,
	"Save Period" = retention_period,
	"Last File Copied" = CONVERT(char(75),last_file_copied),
	"Copy Logged Time" = date_last_copied,
	"Last File Loaded" = CONVERT(char(75),last_file_loaded),
	"Load Logged Time" = date_last_loaded

FROM 	msdb..backup_movement_plan_databases,
	#table

WHERE	(@p_svr is NULL or source_server like @p_svr)
AND	(@p_db is NULL or source_database like @p_db)
AND	destination_database = destination_db

drop table #table
end

go

/***************************************************************************/

if exists (select * from sysobjects where id = object_id('log_ship_entity_log') and sysstat & 0xf = 4)
	BEGIN
	  PRINT ''
	  PRINT 'Dropping log_ship_entity_log procedure...'
	  DROP PROCEDURE log_ship_entity_log
	END

GO

/*
*****************************************************************************************
File:	log_ship_sprocs.sql
Name:	log_ship_entity_log

Description:
	This sproc displays copy and load job status messages for a specified log 
	shipping entity.
	Must be run on the secondary server where the logs are loaded.
	If a rollup server is utilized, this sproc can be run there.

Depends On:
	Log shipping must be installed.
	If this is run on the rollup server, the rollup server must be defined (in the 
	registry - HKLM\software\microsoft\mssqlserver\itg\historyserver:reg_sz:)
	on each secondary server.  See doc's for details.

Notes:
	Installation should check to see if log shipping has been installed.  If not 
	present, sproc should not install.  Not implemented.

	The history table needs to be purged (oldest rows delted).  Implemented via a 
	sql agent delete job calling msdb..log_ship_history_purge.

Installation:	
	Install in MSDB
	
Processing Steps:
	

Tables Used:
	msdb..backup_movement_plan_history
	
Parameters:
	Optional parameters: 'Primary server', 'primary database','secondary server',
		'secondary database', hours_delta
	hours_delta specifies in hours, how much history information to return.  
	If not supplied, 1 hour is default.


Return Value:
	None
Called By:
	None
Calls:
	None

Change History:
	Date:	 Author		 Description
	-----    -------         --------------------------------------------------------
	5/98			Initial script creation to support log shipping.
	10/98			BORK update, fixed case sensitive vars
	
	Copyright Microsoft, Inc. 1996 - 1998.                                   
	All Rights Reserved.                                                     
                                                                         
	Microsoft, Inc. One Microsoft Way, Redmond WA. 98052. 

*****************************************************************************************
*/



CREATE PROCEDURE dbo.log_ship_entity_log
@p_svr         varchar( 30 ) = NULL,
@p_db          varchar( 30 ) = NULL,
@s_svr         varchar( 30 ) = NULL,
@s_db          varchar( 30 ) = NULL,
@hours_delta   int = NULL


AS
Begin

DECLARE  @time DATETIME


--	Convert hours_delta to minutes

SELECT @time = getdate()

IF @hours_delta is not NULL and @hours_delta != 0
	BEGIN
		IF @hours_delta > 0 
			SELECT @hours_delta  = 0 - @hours_delta
		SELECT   @time = dateadd(mi, @hours_delta*60, @time)
	END
ELSE
--	Default value, 60 minutes / 1-hour
	SELECT @time = dateadd(mi, -60, @time)

--	Format the output

SELECT	"Logged Date" = end_time,
	Type = CASE WHEN activity = 0 THEN "Copy" ELSE "Load" end,
	Success = CASE WHEN succeeded= 0 THEN "No" ELSE "Yes" END,
	"Num Files" = CONVERT(char(4),num_files),
	"Last File"  = LEFT(last_file,75),
	Message = message

FROM 	msdb..backup_movement_plan_history

WHERE	(@p_svr is NULL or source_server like @p_svr)
AND	(@s_svr is NULL or destination_server like @s_svr)
AND	(@p_db is NULL or source_database like @p_db)
AND	(@s_db is NULL or destination_database like @s_db)
AND	end_time > @time
ORDER BY end_time desc

end

go

/******************************************************************************/


if exists (select * from sysobjects where id = object_id('log_ship_history_purge') and sysstat & 0xf = 4)
	BEGIN
	  PRINT ''
	  PRINT 'Dropping log_ship_history_purge procedure...'
	  DROP PROCEDURE log_ship_history_purge
	END

GO

/*
*****************************************************************************************
File:	log_ship_sprocs.sql
Name:	log_ship_history_purge

Description:
	This sproc purges rows from the table msdb..backup_movement_plan_history on secondary 
	and rollup servers.  This table is populated by the log shipping copy and load jobs.  
	This table will fill very rapidly on a central rollup server.

	The procedure can be run manually or scheduled via a sql agent job.

Depends On:
	Log shipping must be installed.

Notes:
	Installation should check to see if log shipping has been installed.  If 
	not present, sproc should not install.  Not implemented.
	
	To minimize the chance of filling the tran log during a purge operation, we 
	delete 1000 rows at a time.  


Installation:	
	Install in MSDB
	
Processing Steps:
	

Tables Used:
	msdb..backup_movement_plan_history

	
Parameters:
	parameters: @days_to_keep, required.  Must be greater than 1

Return Value:

Called By:
	
Calls:
	None

Change History:
	Date:	 Author		 Description
	-----    -------         --------------------------------------------------------
	7/98			Initial script creation to support log shipping.
	10/98			BORK update, case sensitive var's
	
	Copyright Microsoft, Inc. 1996 - 1998.                                   
	All Rights Reserved.                                                     
                                                                         
	Microsoft, Inc. One Microsoft Way, Redmond WA. 98052. 

*****************************************************************************************
*/

CREATE PROCEDURE dbo.log_ship_history_purge
	@days_to_keep	int

AS
Begin


DECLARE @limit int



If @days_to_keep < 1
	BEGIN
		PRINT "Days to keep must be positive and greater than 1"
		RETURN
	END
		
select @limit = 1000

while (select count(*) 
	from msdb..backup_movement_plan_history 
	where end_time < dateadd(dd,-@days_to_keep,getdate()))
	>= @limit	

	begin
		set rowcount @limit
		delete 
			from msdb..backup_movement_plan_history 
			where end_time < dateadd(dd,-@days_to_keep,getdate())
	end


end

go

/*****************************************************************************/

if exists (select * from sysobjects where id = object_id('log_ship_alert') and sysstat & 0xf = 4)
	BEGIN
	  PRINT ''
	  PRINT 'Dropping log_ship_alert procedure...'
	  DROP PROCEDURE log_ship_alert
	END

GO

/*
*****************************************************************************************
File:	log_ship_sprocs.sql
Name:	log_ship_alert

Description:
	This sproc generates a RAISERROR if the 'time delta' exceeds a threshold, which 
	is passed as aparameter.
	Must be run on the secondary server where the logs are loaded, won't work on a
	rollup server.
	Since the dumptrdate column no longer exists in SQL 7.0, we determine the 
	equivalent information by obtaining the BackupStartDate from msdb..backupset for 
	the last transaction log loaded into each secondary database.


Depends On:
	Log shipping must be installed.
	Requires user defiend sysmessage:
	exec sp_addmessage 90051, 17, "Log Shipping OOS: Database: %s, DELTA: %d", 
		null, TRUE, REPLACE
	User needs to implement means for responding to this Event (create sql agent alert,etc)
Notes:
	Installation should check to see if log shipping has been installed.  If not 
	present, sproc should not install.  Not implemented.

	uses the same method as log_ship_status for calculating the time delta.

	This sproc will generally be called from a SQL Agent job (on the secondary) which 
	will execute periodically, probably once every 30 minutes. 


Installation:	
	Install in MSDB
	
Processing Steps:
	For each entity, calculate the time delta, if it exceeds the 'threshold' generate 
	an alert (RAISERROR)	

Tables Used:
	msdb..backup_movement_plan_databases
	msdb..restorehistory
	
Parameters:
	Require parameter: 'Alert Threshold' in minutes.  If 'time delta' + load_delay
	exceeds 'alert threshold'  issue a RAISERROR.

Return Value:

Called By:
	
Calls:
	None

Change History:
	Date:	 Author		 Description
	-----    -------         --------------------------------------------------------
	5/98			Initial script creation to support log shipping.
	10/98			added support for load_delay, BORK check

	Copyright Microsoft, Inc. 1996 - 1998.                                   
	All Rights Reserved.                                                     
                                                                         
	Microsoft, Inc. One Microsoft Way, Redmond WA. 98052. 

*****************************************************************************************
*/

CREATE PROCEDURE dbo.log_ship_alert
	@alert_delta		int

AS
Begin

set nocount on
DECLARE @dest_db varchar(30),
	@history_id int,
	@time_delta int,
	@load_delay int


-- 	Walk through each secondary database defined in msdb..backup_movement_plan_databases
--	and calculate the time delta ('current time' - 'creation time of last t-log loaded')
--	and populate the temp table #table.

DECLARE log_ship_cursor CURSOR
	FOR SELECT destination_database,load_delay
	from backup_movement_plan_databases

OPEN log_ship_cursor

FETCH NEXT FROM log_ship_cursor 
	into @dest_db, @load_delay

	WHILE @@FETCH_STATUS = 0
	BEGIN
		set nocount on

--		determine last tlog loaded into destination (secondary) database	

		select	@history_id = (select	max(restore_history_id)
					from	restorehistory
					where	destination_database_name = @dest_db)
--		Determine time delta

		select 	@time_delta = (select datediff(mi, (select backup_start_date from backupset
					where backup_set_id = (
						select	backup_set_id
						from	restorehistory
						where	restore_history_id = @history_id)),
					getdate()))

--		If time delta + load_delay exceeds threshold, RAISERROR

		If @time_delta > @alert_delta + @load_delay
			BEGIN
	
			        RAISERROR (90051,17,1,@dest_db,@time_delta) WITH LOG
                	END                                                                    


		FETCH NEXT from log_ship_cursor into @dest_db,@load_delay

	end
	
	close log_ship_cursor
	DEALLOCATE log_ship_cursor

end



