create table #Files
(
  lname varchar(128),
  pname VARCHAR(128),
  type varchar(10),
  fgroup varchar(128),
  size varchar(50),
  maxsize varchar(50),
  FileId varchar(10),
  CreateLSN varchar(20),
  DropLSN varchar(20),
  UniqueId varchar(128),
  ReadOnlyLSN varchar(20),
  ReadWriteLSN varchar(20),
  BackupSizeInBytes varchar(20),
  SourceBlockSize varchar(20),
  FileGroupId varchar(10),
  LogGroupGUID varchar(128),
  DifferentialBaseLSN varchar(20),
  DifferentialBaseGUID varchar(128),
  IsReadOnly varchar(10),
  IsPresent varchar(10)
)