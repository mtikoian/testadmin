--DEMO #4 Build up a send queue by reindexing
USE [Megadata]
GO
ALTER INDEX [ix1] ON dbo.testtable REBUILD; 
GO
ALTER INDEX [ix2] ON dbo.testtable REBUILD;
GO 
ALTER INDEX [ix3] ON dbo.testtable REBUILD;
GO
--Query the windows performance counters exposed by SQL Server
--paste into another window 
SELECT * FROM sys.dm_os_performance_counters
 WHERE OBJECT_NAME = 'MSSQL$I1:Database Mirroring' and instance_name = 'Megadata'
GO 
--built in SQL Server stored proc (T-SQL version of mirroring monitor) 
EXEC [msdb].[sys].[sp_dbmmonitorresults] @database_name = 'Megadata', @mode = 9
-- WHERE: 
--@database_name	sysname,	-- name of database
--    @mode	int = 0,			-- 0 = last row, 1 last two hours, 2 last four, 3 last eight, 4 last day
--								-- 5 last two days, 6 last 100, 7 last 500, 8 last 1000, 9 all.
--	@update_table	int = 0		-- if 1, then generate a row in the base table and then return.  
--								-- Going to leave this as an int.  Could be bit, but this is more flexible.



 
