--I2 clean up script for demo #1

ALTER DATABASE [Adventureworks] SET PARTNER OFF;
DROP DATABASE [Megadata];
drop endpoint [Mirroring];  
drop login [CONTESO\serverb_I1SQL];

DROP DATABASE [Adventureworks];
