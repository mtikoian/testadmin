--Demo #1
-- Run this on SERVERB\I2
--*************************************************************************
-- SETUP
--*************************************************************************
--#1 map the I1 service account into I2
CREATE LOGIN [CONTESO\serverb_I1SQL] FROM WINDOWS WITH DEFAULT_DATABASE=[master], 
DEFAULT_LANGUAGE=[us_english]
GO

--#2 CREATE THE ENDPOINT ON I2

--note no encryption
CREATE ENDPOINT [Mirroring] 
	AUTHORIZATION [CONTESO\serverb_I2SQL]
	STATE=STARTED
	AS TCP (LISTENER_PORT = 5023, LISTENER_IP = ALL)
	FOR DATA_MIRRORING (ROLE = PARTNER, AUTHENTICATION = WINDOWS NEGOTIATE
, ENCRYPTION = DISABLED)
GO
 
-- Grant connect on the endpoint to the I1 service account on I2
GRANT CONNECT ON ENDPOINT::Mirroring TO [CONTESO\serverb_I1SQL];
GO
SELECT e.name, e.protocol_desc, e.type_desc, e.role_desc, e.state_desc,
t.port, e.is_encryption_enabled, e.encryption_algorithm_desc, e.connection_auth_desc
FROM   sys.database_mirroring_endpoints e
JOIN sys.tcp_endpoints t 
ON  e.endpoint_id = t.endpoint_id 


--*************************************************************************
-- END SETUP
--*************************************************************************
-- #4 restore megadata on to I2
RESTORE DATABASE [Megadata] FROM disk = 'c:\demo\Megadata.bak' with
MOVE 'MEGADATA' to 'C:\Program Files\Microsoft SQL Server\MSSQL10_50.I2\MSSQL\DATA\MEGADATA.mdf',
MOVE 'MEGADATA_log' to 'C:\Program Files\Microsoft SQL Server\MSSQL10_50.I2\MSSQL\DATA\MEGADATA_log.ldf'
 ,NORECOVERY, stats=10, checksum 
GO 
RESTORE LOG Megadata FROM disk = 'c:\demo\Megadata.trn' with NORECOVERY,
stats=10, checksum 
GO 
--
-- #5 on the MIRROR server...pre activate the mirroring 
ALTER DATABASE [MEGADATA] SET PARTNER = 'tcp://SERVERB.conteso.com:5022';
-- now go and issue the partner command on I1
