--DEMO #3 Prep Northwind and Pubs on SERVERB\I1
ALTER DATABASE [Northwind] SET PARTNER OFF;
ALTER DATABASE [PUBS] SET PARTNER OFF;
GO 
DROP DATABASE [Northwind]; 
GO
DROP DATABASE [Pubs]; 
GO
RESTORE DATABASE [Northwind] FROM disk = 'c:\demo\Northwind.bak' with
MOVE 'Northwind' to 'C:\Program Files\Microsoft SQL Server\MSSQL10_50.I1\MSSQL\DATA\Northwind.mdf',
MOVE 'Northwind_log' to 'C:\Program Files\Microsoft SQL Server\MSSQL10_50.I1\MSSQL\DATA\Northwind_log.ldf'
 ,NORECOVERY, stats=10, checksum 
GO 
RESTORE LOG [Northwind] FROM disk = 'c:\demo\Northwind.trn' with NORECOVERY,
stats=10, checksum 
GO 
RESTORE DATABASE [Pubs] FROM disk = 'c:\demo\Pubs.bak' with
MOVE 'Pubs' to 'C:\Program Files\Microsoft SQL Server\MSSQL10_50.I1\MSSQL\DATA\Pubs.mdf',
MOVE 'Pubs_log' to 'C:\Program Files\Microsoft SQL Server\MSSQL10_50.I1\MSSQL\DATA\Pubs_log.ldf'
 ,NORECOVERY, stats=10, checksum; 
GO 
RESTORE LOG [Pubs] FROM disk = 'c:\demo\Pubs.trn' with NORECOVERY,
stats=10, checksum; 
GO
-- 
IF  EXISTS (SELECT * FROM sys.server_principals WHERE name = N'CONTESO\serveraSQL')
DROP LOGIN [CONTESO\serveraSQL]
GO
CREATE LOGIN [CONTESO\serveraSQL] FROM WINDOWS WITH DEFAULT_DATABASE=[master], DEFAULT_LANGUAGE=[us_english]
GO
GRANT CONNECT ON ENDPOINT::[Mirroring] TO [CONTESO\serveraSQL];
GO
--must initiate from the mirror first.
ALTER DATABASE [Northwind] SET PARTNER = 'tcp://SERVERA.conteso.com:5022';
ALTER DATABASE [Pubs] SET PARTNER = 'tcp://SERVERA.conteso.com:5022';
GO 
--now go and run the partner commands on ServerA