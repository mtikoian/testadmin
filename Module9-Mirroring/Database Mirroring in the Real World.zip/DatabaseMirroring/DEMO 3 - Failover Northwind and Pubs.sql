-- DEMO #3 Failing over from SQL 2005 to SQL 2008 R2

--run this on the SQL 2005 box
--
-- must put the database into full safety mode (Synchronous) FIRST
ALTER DATABASE [Northwind] SET SAFETY FULL;
GO
ALTER DATABASE [Northwind] SET PARTNER FAILOVER;
GO 
-- try and run both batches at the same time - you can't!
ALTER DATABASE [Pubs] SET SAFETY FULL;
GO
ALTER DATABASE [Pubs] SET PARTNER FAILOVER;
GO 

--  From the ERRORLOG:
--    Error: 948, Severity: 20, State: 2.
--    The database 'Northwind' cannot be opened because it is version 661. This server supports version 612 and earlier. A downgrade path is not supported.
--    Error: 1454, Severity: 16, State: 1.
--    While acting as a mirroring partner for database 'Northwind', server instance 'SERVERB\I1' encountered error 948, status 2, severity 20. Database mirroring will be suspended.  Try to resolve the error and resume mirroring.
--    
--    Error: 948, Severity: 20, State: 2.
--    The database 'pubs' cannot be opened because it is version 661. This server supports version 612 and earlier. A downgrade path is not supported.
--    Error: 1454, Severity: 16, State: 1.
--    While acting as a mirroring partner for database 'pubs', server instance 'SERVERB\I1' encountered error 948, status 2, severity 20. Database mirroring will be suspended.  Try to resolve the error and resume mirroring.

-- this is because of the on disk structure upgrades from SQL 2005->SQL 2008R2 preclude
-- going back. Always have a recovery plan in place. 
--