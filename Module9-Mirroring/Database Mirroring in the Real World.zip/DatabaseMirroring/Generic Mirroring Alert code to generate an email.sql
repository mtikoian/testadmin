--Core code from Mirroring Monitoring SQL Agent Job
--Typically, for each principal you want to monitor, you would 
--Add another openrowset with the hard coded server in there.
--There are much better ways to do this (i.e., Powershell)	
--
-- The best approach is to run this every 1-2 hours. You don't get an 
-- email unless there is a database that is running behind (send queue).

CREATE TABLE [##mirroringstatus](
Instance NVARCHAR(20),
[Database] NVARCHAR(120),
[Send Queue (KB)] BIGINT,
Mirroring_state_desc NVARCHAR(120));
GO 
--repeat below for each server/instance you want to monitor.
INSERT [##mirroringstatus] 
SELECT * 
FROM OPENROWSET('SQLNCLI','SERVER=YOURSQLSERVERHERE;UID=username;PWD=password','
	SELECT @@SERVERNAME AS [Instance],
	 pm.instance_name AS [Database], 
	 pm.cntr_value AS [Send Queue(KB)],
	 ms.mirroring_state_desc AS [Desc] 
	 FROM sys.dm_os_performance_counters pm
	 INNER JOIN sys.databases dbs ON pm.instance_name = dbs.NAME
	 LEFT OUTER JOIN sys.database_mirroring ms ON (dbs.database_id = ms.database_id)
	WHERE  
	pm.object_name = ''SQLServer:Database Mirroring''
	AND pm.counter_name = ''Log Send Queue KB'' 
	AND pm.[instance_name] <> ''_Total'' 
	AND pm.cntr_value > 0
	AND ms.mirroring_guid IS NOT NULL')		
	--note above that pm.object_name will change if it's a named instance.
		
DECLARE @cnt SMALLINT
SELECT @cnt = COUNT(*) FROM [##mirroringstatus] WHERE [Send Queue (KB)] > 2048; -- note hard coded value here
IF (@cnt > 0)
BEGIN
	DECLARE @body NVARCHAR(MAX)
	SET @body = N'<head></head><body>'
	SET @body = N'<b>Mirroring Status</b><table border=1>'
	SET @body = @body + N'<tr><th>Instance</th><th>Database</th><th>Send Queue (KB)</th><th>Desc</th>'
	SET @body = @body + ISNULL(CAST((SELECT instance AS 'td','',[database] AS 'td','', [Send Queue (KB)] AS 'td', '', Mirroring_state_desc as 'td' 
		FROM ##mirroringstatus WHERE [Send Queue (KB)] > 2048  FOR XML PATH ('tr'), ELEMENTS) AS NVARCHAR(MAX)),'')
	SET @body = @body + N'</table></body>'	
	EXEC msdb.dbo.sp_send_dbmail 
		  @profile_name = 'Default Database Mail Profile'
		, @importance = 'NORMAL'
		, @recipients = 'YOU@YOURDOMAIN.COM' 
		, @subject = 'MIRRORING STATUS' 
		,@body_format = 'HTML'
		,@body = @body 
END