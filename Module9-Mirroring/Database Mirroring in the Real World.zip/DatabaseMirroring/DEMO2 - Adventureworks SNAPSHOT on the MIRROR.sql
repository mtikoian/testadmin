--DEMO #2 - run this against the mirror
SELECT * FROM [Adventureworks].[Person].[Contact]
GO
-- now let's create a snapshot on the mirror
CREATE DATABASE ADVENTUREWORKS_SNAP ON
( NAME = AdventureWorks_Data, FILENAME = 
'C:\Program Files\Microsoft SQL Server\MSSQL10_50.I1\MSSQL\DATA\AdventureWorks_data.ss' )
 AS SNAPSHOT OF ADVENTUREWORKS;
 GO 
 --...and query the snapshot
SELECT * FROM [Adventureworks_snap].[Person].[Contact]
GO
--clean up
DROP DATABASE [ADVENTUREWORKS_SNAP]
 


