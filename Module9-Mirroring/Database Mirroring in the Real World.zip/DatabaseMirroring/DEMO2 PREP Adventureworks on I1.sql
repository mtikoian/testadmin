--
-- DEMO2 prep Adventureworks
-- run this on I1

backup database [Adventureworks] to disk = 'c:\demo\Adventureworks.bak' with init,
stats=10, checksum 
GO 
backup LOG [Adventureworks] to disk = 'c:\demo\Adventureworks.trn' with init,
stats=10, checksum 
GO 