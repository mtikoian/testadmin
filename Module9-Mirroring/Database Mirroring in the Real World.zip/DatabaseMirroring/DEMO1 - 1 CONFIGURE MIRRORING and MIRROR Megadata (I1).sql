--Demo #1
-- Run this on SERVERB\I1
--*************************************************************************
-- SETUP
--*************************************************************************
-- #1 map the I2 service account into I1
CREATE LOGIN [CONTESO\serverb_I2SQL] FROM WINDOWS WITH DEFAULT_DATABASE=[master], 
DEFAULT_LANGUAGE=[us_english]
GO

--CREATE THE ENDPOINT
--
-- ENCRYPTION
--CREATE ENDPOINT [Mirroring] 
--  AUTHORIZATION [CONTESO\administrator]	
--	STATE=STARTED
--	AS TCP (LISTENER_PORT = 5022, LISTENER_IP = ALL)
--	FOR DATA_MIRRORING (ROLE = PARTNER, AUTHENTICATION = WINDOWS NEGOTIATE
--, ENCRYPTION = REQUIRED ALGORITHM RC4)

--no encryption
IF  EXISTS (SELECT * FROM sys.endpoints e WHERE e.name = N'Mirroring') 
DROP ENDPOINT [Mirroring]
GO
CREATE ENDPOINT [Mirroring] 
	AUTHORIZATION [CONTESO\serverb_I1SQL]
	STATE=STARTED
	AS TCP (LISTENER_PORT = 5022, LISTENER_IP = ALL)
	FOR DATA_MIRRORING (ROLE = PARTNER, AUTHENTICATION = WINDOWS NEGOTIATE
, ENCRYPTION = DISABLED)
GO
-- Grant connect on the endpoint to the I2 service account on I1
GRANT CONNECT ON ENDPOINT::[Mirroring] TO [CONTESO\serverb_I2SQL];
GO

-- show endpoints dmv's  
SELECT e.name, e.protocol_desc, e.type_desc, e.role_desc, e.state_desc,
t.port, e.is_encryption_enabled, e.encryption_algorithm_desc, e.connection_auth_desc
FROM   sys.database_mirroring_endpoints e
JOIN sys.tcp_endpoints t 
ON  e.endpoint_id = t.endpoint_id 

SELECT d.name, d.database_id, m.mirroring_role_desc, m.mirroring_state_desc,
m.mirroring_safety_level_desc, m.mirroring_partner_name, mirroring_partner_instance, 
m.mirroring_witness_name, m.mirroring_witness_state_desc 
FROM sys.database_mirroring m 
JOIN sys.databases d
ON     m.database_id = d.database_id 
WHERE  mirroring_state_desc IS NOT NULL 

Select * from sys.dm_db_mirroring_connections

--*************************************************************************
-- END SETUP
--*************************************************************************
--#3 Backup Megadata - Run this on I1
backup database Megadata to disk = 'c:\demo\Megadata.bak' with init,
stats=10, checksum 
GO 
backup LOG Megadata to disk = 'c:\demo\Megadata.trn' with init,
stats=10, checksum 
GO 
--#6 establish mirroring connection on I1 (final step)
ALTER DATABASE [MEGADATA] SET PARTNER = 'tcp://SERVERB.conteso.com:5023';
--#6A turn on async mirroring (optional)
ALTER DATABASE [MEGADATA] SET SAFETY OFF;

--Last, run this to prep for demo#3 
GRANT CONNECT ON ENDPOINT::[Mirroring] TO [CONTESO\serveraSQL];
GO