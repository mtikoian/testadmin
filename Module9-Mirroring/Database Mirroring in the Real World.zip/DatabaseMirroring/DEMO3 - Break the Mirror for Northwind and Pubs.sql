-- DEMO #3 Failover Northwind and Pubs
--
--******************************************************************
-- note that the databases are now in suspended mode
--
--Error: 1479, Severity: 16, State: 2.
--The mirroring connection to "tcp://SERVERA.conteso.com:5022" has timed out for database "Northwind" after 10 seconds without a response.  Check the service and network connections.
-- Error: 1453, Severity: 16, State: 1.
--'tcp://SERVERA.conteso.com:5022', the remote mirroring partner for database 'Northwind', encountered error 948, status 2, severity 20. Database mirroring has been suspended.  Resolve the error on the remote server and resume mirroring, or remove mirroring and re-establish the mirror server instance.

-- run this on the SQL2008 R2 box
-- (breaks the mirror)
ALTER DATABASE [Northwind] SET PARTNER OFF;
ALTER DATABASE [Pubs] SET PARTNER OFF;
GO 
-- now upgrade the db compat level.
ALTER DATABASE [Northwind] SET COMPATIBILITY_LEVEL = 100
GO
ALTER DATABASE [Pubs] SET COMPATIBILITY_LEVEL = 100
GO
--after upgrading , it is recommended that you run a checkdb
DBCC CHECKDB (Northwind)
GO 
DBCC CHECKDB (Pubs)
GO 

