--
-- DEMO2 prep Adventureworks
-- run this on I2

RESTORE DATABASE [Adventureworks] FROM disk = 'c:\demo\Adventureworks.bak' with
MOVE 'Adventureworks_Data' to 'C:\Program Files\Microsoft SQL Server\MSSQL10_50.I2\MSSQL\DATA\Adventureworks.mdf',
MOVE 'Adventureworks_log' to 'C:\Program Files\Microsoft SQL Server\MSSQL10_50.I2\MSSQL\DATA\Adventureworks_log.ldf'
 ,NORECOVERY, stats=10, CHECKSUM 
GO 
RESTORE LOG [Adventureworks] FROM disk = 'c:\demo\Adventureworks.trn' with NORECOVERY,
stats=10, CHECKSUM 
GO 
-- now show mirroring initiation via the GUI