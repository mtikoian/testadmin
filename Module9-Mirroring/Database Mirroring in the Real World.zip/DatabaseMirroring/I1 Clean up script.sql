--clean up script for demo #1
--remove mirroring 
ALTER DATABASE [megadata] SET PARTNER OFF;
DROP ENDPOINT [Mirroring]; 
DROP LOGIN [CONTESO\serverb_I2SQL];
GO 

ALTER DATABASE [Adventureworks] SET PARTNER OFF;

drop database megadata 
drop database Adventureworks 

-- clean up for demo #3
DROP DATABASE [Northwind];
DROP DATABASE [Pubs];

-- run on I2
drop database megadata 
drop database Adventureworks 