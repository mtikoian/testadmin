If Exists (Select 1 From Information_schema.Routines
			Where Routine_Name = 'dba_FailoverMirrorToOriginalPrincipal'
			And Routine_Schema = 'dbo'
			And Routine_Type = 'Procedure')
	Drop Procedure dbo.dba_FailoverMirrorToOriginalPrincipal
Go

Create Procedure dbo.dba_FailoverMirrorToOriginalPrincipal
	-- database to fail back; all applicable databases if null
	@DBName sysname = Null,
	-- 0 = Execute it, 1 = Output SQL that would be executed
	@Debug bit = 0
As
Declare @SQL nvarchar(200),
	@MaxID int,
	@CurrID int
Declare @MirrDBs Table (MirrDBID int identity(1, 1) not null primary key,
						DBName sysname not null)

Set NoCount On

-- If database is in the principal role
-- and is in a synchronized state,
-- fail database back to original principal

Insert Into @MirrDBs (DBName)
Select DB_NAME(database_id)
From sys.database_mirroring
Where mirroring_role = 1 -- Principal partner
And mirroring_state = 4 -- Synchronized
And (database_id = DB_ID(@DBName)
	Or @DBName Is Null) 

Select @MaxID = MAX(MirrDBID)
From @MirrDBs

While @CurrID <= @MaxID
  Begin
	Select @DBName = DBName
	From @MirrDBs
	Where MirrDBID = @CurrID
	
	Set @SQL = 'Alter Database ' + quotename(@DBName) + ' Set Partner Failover;'

	If @Debug = 1
	  Begin
		Exec sp_executesql @SQL;
	  End
	Else
	  Begin
		Print @SQL;
	  End
	
	Set @CurrID = @CurrID + 1
  End

Set NoCount Off
