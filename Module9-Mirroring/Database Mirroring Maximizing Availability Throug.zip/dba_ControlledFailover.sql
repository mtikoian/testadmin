If Exists (Select 1 From Information_schema.Routines
			Where Routine_Name = 'dba_ControlledFailover'
			And Routine_Schema = 'dbo'
			And Routine_Type = 'Procedure')
	Drop Procedure dbo.dba_ControlledFailover;
Go

Create Procedure dbo.dba_ControlledFailover
	-- database to fail back; all applicable databases if null
	@DBName sysname = Null,
	-- @MaxCounter = max # of loops, each loop = 5 seconds
	-- 60 loops = 5 minutes
	@MaxCounter int = 60,
	-- 0 = Execute it, 1 = Output SQL that would be executed
	@Debug bit = 0
As
Declare @SQL nvarchar(1000),
	@MaxID int,
	@CurrID int,
	@DMState int,
	@SafeCounter int,
	@PartnerServer sysname,
	@SafetyLevel int,
	@TrustWorthyOn bit,
	@DBOwner sysname,
	@Results int,
	@ErrMsg varchar(500),
	@Print nvarchar(1000)
Declare @Databases Table (DatabaseID int identity(1, 1) not null primary key,
						DatabaseName sysname not null,
						PartnerServer sysname not null,
						SafetyLevel int not null,
						TrustWorthyOn bit not null,
						DBOwner sysname null)

Set NoCount On

Insert Into @Databases (DatabaseName,
	PartnerServer,
	SafetyLevel,
	TrustWorthyOn,
	DBOwner)
Select D.name,
	DM.mirroring_partner_instance,
	DM.mirroring_safety_level,
	D.is_trustworthy_on,
	SP.name
From sys.database_mirroring DM
Inner Join sys.databases D
	On D.database_id = DM.database_id
Left Join sys.server_principals SP
	On SP.sid = D.owner_sid
Where DM.mirroring_role = 1 -- Principal role
And DM.mirroring_state In (2, 4) -- Synchronizing, Synchronized
And (D.name = @DBName
	Or @DBName Is Null)

If Not Exists (Select 1 From @Databases) And @DBName Is Null
  Begin
	RaisError ('There were no mirroring principals found on this server.', 1, 1);
  End

If Not Exists (Select 1 From @Databases) And @DBName Is Not Null
  Begin
	RaisError ('Database [%s] was not found or is not a mirroring principal on this server.', 1, 1, @DBName);
  End

Select @MaxID = Max(DatabaseID), @CurrID = 1
From @Databases

-- Set Safety to Full on all databases first, if needed
While @CurrID <= @MaxID
  Begin
	Select @DBName = DatabaseName,
	@PartnerServer = PartnerServer,
	@SafetyLevel = SafetyLevel
	From @Databases
	Where DatabaseID = @CurrID
	
	-- Make sure linked server to mirror exists
	Exec @Results = dbo.dba_ManageLinkedServer
                @ServerName = @PartnerServer,
                @Action = 'create'

	If @Results <> 0
	  Begin
		RaisError ('Failed to create linked server to mirror instance [%s].', 1, 1, @PartnerServer);
	  End

	If @SafetyLevel = 1
	  Begin
		Set @SQL = 'Alter Database ' + quotename(@DBName) + ' Set Partner Safety Full;'
		
		Set @Print = 'Setting Safety on for database ' + quotename(@DBName) + '.';
		
		If @Debug = 0
		  Begin
			Print @Print
			Exec sp_executesql @SQL
		  End
		Else
		  Begin
			Print '-- ' + @Print
			Print @SQL;
		  End
	  End

	Set @CurrID = @CurrID + 1
  End

-- Reset @CurrID to 1
Set @CurrID = 1

-- Pause momentarily
WaitFor Delay '0:00:03';

-- Failover all databases
While @CurrID <= @MaxID
  Begin
	Select @DBName = DatabaseName,
		@DMState = DM.mirroring_state,
		@SafeCounter = 0,
		@SafetyLevel = SafetyLevel
	From @Databases D
	Inner Join sys.database_mirroring DM
		On DM.database_id = DB_ID(D.DatabaseName)
	Where DatabaseID = @CurrID	
	
	While @DMState = 2 -- Synchronizing
		And @SafeCounter < @MaxCounter
	  Begin
		WaitFor Delay '0:00:05';

		Select @DMState = mirroring_state,
			@SafeCounter = @SafeCounter + 1
		From sys.database_mirroring 
		Where database_id = DB_ID(@DBName)
	  End

	If @DMState = 2 And @SafeCounter = @MaxCounter
	  Begin
		RaisError('Synchronization timed out for database [%s]. Please check and failover manually.', 1, 1, @DBName);
		
		If @SafetyLevel = 1
		  Begin
			Set @SQL = 'Alter Database ' + quotename(@DBName) + ' Set Partner Safety Full;'
			
			Set @Print = 'Setting Safety Full for database ' + quotename(@DBName) + '.';
			
			If @Debug = 0
			  Begin
				Print @Print
				Exec sp_executesql @SQL
			  End
			Else
			  Begin
				Print '-- ' + @Print
				Print @SQL;
			  End
		  End
	  End
	Else
	  Begin
		Set @SQL = 'Alter Database ' + quotename(@DBName) + ' Set Partner Failover;'

		Set @Print = 'Failing over database ' + quotename(@DBName) + '.';
		
		If @Debug = 0
		  Begin
			Print @Print
			Exec sp_executesql @SQL
		  End
		Else
		  Begin
			Print '-- ' + @Print
			Print @SQL;
		  End
	  End

	Set @CurrID = @CurrID + 1
  End

-- Reset @CurrID to 1
Set @CurrID = 1

-- Pause momentarily
WaitFor Delay '0:00:03';

-- Set safety level and db owner on failed over databases
While @CurrID <= @MaxID
  Begin
	Select @DBName = DatabaseName,
	@PartnerServer = PartnerServer,
	@SafetyLevel = SafetyLevel,
	@TrustWorthyOn = TrustWorthyOn,
	@DBOwner = DBOwner,
	@DMState = DM.mirroring_state,
	@SafeCounter = 0
	From @Databases D
	Inner Join sys.database_mirroring DM
		On DM.database_id = DB_ID(D.DatabaseName)
	Where DatabaseID = @CurrID
	
	-- Make sure linked server to mirror exists
	Exec @Results = dbo.dba_ManageLinkedServer
                @ServerName = @PartnerServer,
                @Action = 'create'
	
	While @DMState = 2 -- Synchronizing
		And @SafeCounter < @MaxCounter
	  Begin
		WaitFor Delay '0:00:05';

		Select @DMState = mirroring_state,
			@SafeCounter = @SafeCounter + 1
		From sys.database_mirroring 
		Where database_id = DB_ID(@DBName)
	  End
	
	If @DMState = 2 And @SafeCounter = @MaxCounter
	  Begin
		RaisError('Synchronization timed out for database [%s] after failover. Please check and set database options manually.', 1, 1, @DBName);
	  End
	Else
	  Begin
		-- Turn safety off if it was originally off
		If @SafetyLevel = 1
		  Begin
			Set @SQL = 'Alter Database ' + quotename(@DBName) + ' Set Partner Safety Off;'
			Set @SQL = 'Exec ' + quotename(@PartnerServer) +
					'.master.sys.sp_executesql N''' + @SQL + ''';';
			
			Set @Print = 'Setting Safety off for database ' + quotename(@DBName) +
					' on server ' + quotename(@PartnerServer) + '.';
			
			If @Debug = 0
			  Begin
				Print @Print
				Exec sp_executesql @SQL
			  End
			Else
			  Begin
				Print '-- ' + @Print
				Print @SQL;
			  End
		  End
		
		-- Set TrustWorthy property on if it was originally on
		If @TrustWorthyOn = 1
		  Begin
			Set @SQL = 'Alter Database ' + quotename(@DBName) + ' Set TrustWorthy On;'
			Set @SQL = 'Exec ' + quotename(@PartnerServer) +
					'.master.sys.sp_executesql N''' + @SQL + ''';';
			
			Set @Print = 'Setting TrustWorthy On for database ' + quotename(@DBName) +
					' on server ' + quotename(@PartnerServer) + '.';
			
			If @Debug = 0
			  Begin
				Print @Print
				Exec sp_executesql @SQL
			  End
			Else
			  Begin
				Print '-- ' + @Print
				Print @SQL;
			  End
		  End
		
		-- Change database owner if different than original
		Set @SQL = 'If Exists (Select 1 From sys.databases D' + char(10) + char(9) +
				'Left Join sys.server_principals P On P.sid = D.owner_sid' + char(10) + char(9) +
				'Where P.name Is Null' + char(10) + char(9) +
				'Or P.name <> ''' + @DBOwner + ''')' + char(10) + char(9) +
				'Exec ' + quotename(@DBName) + '..sp_changedbowner ''' + @DBOwner + ''';'
		Set @SQL = Replace(@SQL, '''', '''''')
		Set @SQL = 'Exec ' + quotename(@PartnerServer) +
				'.master.sys.sp_executesql N''' + @SQL + ''';';
		
		Set @Print = 'Changing Database owner to ' + quotename(@DBOwner) +
				' for database ' + quotename(@DBName) +
				' on server ' + quotename(@PartnerServer) + '.';
		
		If @Debug = 0
		  Begin
			Print @Print
			Exec sp_executesql @SQL
		  End
		Else
		  Begin
			Print '-- ' + @Print
			Print @SQL;
		  End
	  End

	Set @CurrID = @CurrID + 1
  End

Set NoCount Off
