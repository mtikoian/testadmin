Use master;
Go

If Exists (Select 1 From INFORMATION_SCHEMA.ROUTINES
			Where ROUTINE_NAME = 'dba_ManageLinkedServer'
			And ROUTINE_SCHEMA = 'dbo')
	Drop Procedure dbo.dba_ManageLinkedServer
Go

SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
GO
Create Procedure dbo.dba_ManageLinkedServer
	@ServerName sysname,
	@Action varchar(10) = 'create'
As
If @ServerName = @@ServerName
	Return

If @Action = 'create'
 Begin
	If Not Exists (Select 1 From sys.servers 
					Where name = @ServerName
					And is_linked = 1)
	  Begin
		EXEC master.dbo.sp_addlinkedserver @server = @ServerName,
									@srvproduct = N'SQL Server';
		EXEC master.dbo.sp_serveroption @server = @ServerName,
									@optname = N'collation compatible',
									@optvalue = N'false';
		EXEC master.dbo.sp_serveroption @server = @ServerName,
									@optname = N'data access',
									@optvalue = N'true';
		EXEC master.dbo.sp_serveroption @server = @ServerName,
									@optname = N'dist',
									@optvalue = N'false';
		EXEC master.dbo.sp_serveroption @server = @ServerName,
									@optname = N'pub',
									@optvalue = N'false';
		EXEC master.dbo.sp_serveroption @server = @ServerName,
									@optname = N'rpc',
									@optvalue = N'true';
		EXEC master.dbo.sp_serveroption @server = @ServerName,
									@optname = N'rpc out',
									@optvalue = N'true';
		EXEC master.dbo.sp_serveroption @server = @ServerName,
									@optname = N'sub',
									@optvalue = N'false';
		EXEC master.dbo.sp_serveroption @server = @ServerName,
									@optname = N'connect timeout',
									@optvalue = N'0';
		EXEC master.dbo.sp_serveroption @server = @ServerName,
									@optname = N'collation name',
									@optvalue = null;
		EXEC master.dbo.sp_serveroption @server = @ServerName,
									@optname = N'lazy schema validation',
									@optvalue = N'false';
		EXEC master.dbo.sp_serveroption @server = @ServerName,
									@optname = N'query timeout',
									@optvalue = N'0';
		EXEC master.dbo.sp_serveroption @server = @ServerName,
									@optname = N'use remote collation',
									@optvalue = N'true';
		EXEC master.dbo.sp_addlinkedsrvlogin @rmtsrvname = @ServerName,
									@locallogin = NULL ,
									@useself = N'True';
	  End
  End
Else If @Action = 'drop'
 Begin
	If Exists (Select 1 From sys.servers 
				Where name = @ServerName
				And is_linked = 1)
	  Begin
		Exec master.dbo.sp_dropserver @server = @ServerName,
									@droplogins = Null
	  End
  End
GO
