Use master;
Go

If Exists (Select 1 From INFORMATION_SCHEMA.ROUTINES
			Where ROUTINE_NAME = 'dba_CheckLogins'
			And ROUTINE_SCHEMA = 'dbo')
	Drop Procedure dbo.dba_CheckLogins
Go

SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
GO

Create Procedure dbo.dba_CheckLogins
	@Server1 sysname,
	@Server2 sysname = Null,
	@EPName sysname,
	@Debug bit = 0
As

Declare @SQLServAcct sysname,
	@Domain sysname,
	@SQL nvarchar(500)
Declare @LoginConfig Table (Name sysname,
							ConfigValue sysname)

Set NoCount On

Insert Into @LoginConfig
Exec xp_loginconfig 'default domain'

Select @Domain = ConfigValue
From @LoginConfig

Exec xp_instance_regread N'HKEY_LOCAL_MACHINE', 
				N'System\CurrentControlSet\Services\MSSQLSERVER', 
				N'ObjectName',
				@SQLServAcct OUTPUT,
				N'no_output'

If @SQLServAcct = 'NT AUTHORITY\NetworkService'
	Set @SQLServAcct = @Domain + '\' + CAST(ServerProperty('MachineName') as sysname) + '$'

-- Server 1
Set @SQL = 'If Not Exists (Select 1' + CHAR(10) +
			'From ' + quotename(@Server1) + '.master.sys.server_principals' +
			CHAR(10) + 'Where name = ''' + @SQLServAcct + ''')' + CHAR(10) + CHAR(9) +
			'Create Login ' + QUOTENAME(@SQLServAcct) + ' From Windows;'

If @Debug = 1
  Begin
	Print @SQL;
  End
Else
  Begin
	Exec sp_executesql @SQL;
  End

Set @SQL = 'If Not Exists (Select 1' + CHAR(10) +
			'From ' + quotename(@Server1) + '.master.sys.server_principals P' + CHAR(10) +
			'Inner Join ' + quotename(@Server1) + '.master.sys.server_permissions SP ' +
			char(9) + 'On SP.grantee_principal_id = P.principal_id' + char(10) +
			'Inner Join ' + quotename(@Server1) + '.master.sys.database_mirroring_endpoints E' +
			CHAR(10) + CHAR(9) + 'On E.name = Object_Name(SP.major_id)' + CHAR(10) +
			'Where SP.permission_type = ''CO''' + CHAR(10) +
			'And SP.state = ''G'')' + CHAR(10) + CHAR(9) +
			'Grant Connect On EndPoint::' + QUOTENAME(@EPName) +
			' To ' + QUOTENAME(@SQLServAcct) + ';';

If @Debug = 1
  Begin
	Print @SQL;
  End
Else
  Begin
	Exec sp_executesql @SQL;
  End

-- Server 2
If @Server2 Is Not Null
  Begin
	Set @SQL = 'If Not Exists (Select 1' + CHAR(10) +
				'From ' + quotename(@Server2) + '.master.sys.server_principals' +
				CHAR(10) + 'Where name = ''' + @SQLServAcct + ''')' + CHAR(10) + CHAR(9) +
				'Create Login ' + QUOTENAME(@SQLServAcct) + ' From Windows;'

	If @Debug = 1
	  Begin
		Print @SQL;
	  End
	Else
	  Begin
		Exec sp_executesql @SQL;
	  End

	Set @SQL = 'If Not Exists (Select 1' + CHAR(10) +
				'From ' + quotename(@Server2) + '.master.sys.server_principals P' + CHAR(10) +
				'Inner Join ' + quotename(@Server2) + '.master.sys.server_permissions SP ' +
				char(9) + 'On SP.grantee_principal_id = P.principal_id' + char(10) +
				'Inner Join ' + quotename(@Server2) + '.master.sys.database_mirroring_endpoints E' +
				CHAR(10) + CHAR(9) + 'On E.name = Object_Name(SP.major_id)' + CHAR(10) +
				'Where SP.permission_type = ''CO''' + CHAR(10) +
				'And SP.state = ''G'')' + CHAR(10) + CHAR(9) +
				'Grant Connect On EndPoint::' + QUOTENAME(@EPName) +
				' To ' + QUOTENAME(@SQLServAcct) + ';';

	If @Debug = 1
	  Begin
		Print @SQL;
	  End
	Else
	  Begin
		Exec sp_executesql @SQL;
	  End
  End

Set NoCount On
