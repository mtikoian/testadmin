/******************************************************
Code Camp South FL 2012

Dmitri Korotkevitch: DB Design for Non-database Developers

Design Pattern to remove BLOBs

Good when:
Table has a lot of data
Blobs are rarely accessed
System has a lot of queries which scan large # of rows in the table

Enable "Include Actual Execution Plan" option
********************************************************/

set nocount on
go

use CodeCampSouthFL
go

if exists(
	select * 
	from sys.views v join sys.schemas s on v.schema_id = s.schema_id
	where s.name = 'dbo' and v.name = 'vMainAndBlobData'
)
	drop view dbo.vMainAndBlobData
go

-- needs to use outer join
create view dbo.vMainAndBlobData(ID, IntField, CharField)
as
	select md.ID, md.IntField, bd.CharField 
	from 
		dbo.MainData md left outer join dbo.BlobData bd
			on md.ID = bd.ID
go
		
/* When you need blob field.. */
select * 
from dbo.vMainAndBlobData
where ID = 5
go

/* Select does not require CharField - Original data */
dbcc dropcleanbuffers
dbcc freeproccache
go

set statistics io on
go

declare 
	@StartTime datetime = getDate()

select 	COUNT(*) from dbo.LargeRow where IntField % 2 = 0
select datediff(millisecond,@StartTime,getDate())
go

/* vMainAndBlobData */
dbcc dropcleanbuffers
dbcc freeproccache
go

set statistics io on
go

declare 
	@StartTime datetime = getDate()

select 	COUNT(*) from dbo.vMainAndBlobData where IntField % 2 = 0
select datediff(millisecond,@StartTime,getDate())
go
