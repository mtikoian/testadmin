/**********************************************************************
Code Camp South FL 2012

Dmitri Korotkevitch: DB Design for Non-database Developers

How Row Size Affects Performance
**********************************************************************/

set nocount on
go

use CodeCampSouthFL
go


-- checking # of the pages in the both tables
select page_count, * from sys.dm_db_index_physical_stats(DB_ID(),OBJECT_ID(N'LargeRow'),null, null, 'DETAILED')
select page_count, * from sys.dm_db_index_physical_stats(DB_ID(),OBJECT_ID(N'SmallRow'),null, null, 'DETAILED')
go

/* performance */
dbcc dropcleanbuffers
dbcc freeproccache
go

set statistics io on
go


declare 
	@StartTime datetime = getDate()

select COUNT(*) from dbo.LargeRow where IntField % 2 = 0
select datediff(millisecond,@StartTime,getDate()) as [Exec Time]
go

dbcc dropcleanbuffers
dbcc freeproccache
go

set statistics io on
go

declare 
	@StartTime datetime = getDate()

select 	COUNT(*) from dbo.SmallRow where IntField % 2 = 0
select datediff(millisecond,@StartTime,getDate()) as [Exec Time]
go