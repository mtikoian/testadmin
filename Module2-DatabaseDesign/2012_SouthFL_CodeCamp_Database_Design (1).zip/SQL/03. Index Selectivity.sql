/******************************************************
Code Camp South FL 2012

Dmitri Korotkevitch: DB Design for Non-database Developers

This demo shows how usage of non-clustered index
depends on the selectivity of the index.
******************************************************/

set nocount on
go

use CodeCampSouthFL
go

/* DATA is 5 triples of letters from A..Z each */

select 26*26*26*5
select count(*) from dbo.IndexDemo
go


select page_count, * from sys.dm_db_index_physical_stats(DB_ID(),OBJECT_ID(N'IndexDemo'),null, null, 'DETAILED')
go

-- Clustered index = 4,626 pages = 
-- Non Clustered index = 294 pages = 87880 / 294 = ~298 rows per page


set statistics io on
go

-- 5 rows. SQL uses non-clustered index
-- 1 Triple only 
select * from dbo.IndexDemo where Name like 'ABC%'
go

-- 5 * 26 = 130 rows. SQL uses non-clustered index
select * from dbo.IndexDemo where Name like 'AB%'
go

-- 5 * 26 * 26 = 3380 rows - SQL uses clustered index scan 4644 reads
select * from dbo.IndexDemo where Name like 'A%'
go

-- 10375 reads - more than 3 times more expensive than with clustered index scan
select * from dbo.IndexDemo with (index = IDX_IndexDemo_Name)  where Name like 'A%'
go

