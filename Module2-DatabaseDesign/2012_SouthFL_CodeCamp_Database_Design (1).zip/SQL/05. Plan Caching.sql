/********************************************************************************
Code Camp South FL 2012

Dmitri Korotkevitch: DB Design for Non-database Developers

Ad-hoc SQL & Plan Cache Demo

********************************************************************************/

use CodeCampSouthFL
go

set nocount on
go

-- Clear plan cache
dbcc freeproccache
go

-- Creating 1000 ad-hoc queries
declare 
	@SQL nvarchar(max), 
	@I int = 0

while @I < 1000
begin
	select @SQL = N'declare @C int;select @C=ID from dbo.SmallRow where ID=' + CONVERT(nvarchar(10),@I)
	exec sp_executesql @SQL
	select @I += 1
end	
go

select 
	p.usecounts, p.cacheobjtype, p.objtype, p.size_in_bytes,
	t.[text] 
from 
	sys.dm_exec_cached_plans p
		cross apply sys.dm_exec_sql_text(p.plan_handle) t
where 
	p.cacheobjtype = 'Compiled Plan' and 
	t.[text] like '%dbo.SmallRow%'
order by
	p.objtype desc