/******************************************************
Code Camp South FL 2012

Dmitri Korotkevitch: DB Design for Non-database Developers

Context_Info
******************************************************/

use CodeCampSouthFL
go

delete from dbo.LargeRow where ID < 0
go

if exists
(
	select  * 
	from sys.triggers  tr
	where tr.name = 'trgContextInfo'
)
	drop trigger dbo.trgContextInfo
go

create trigger dbo.trgContextInfo
on dbo.LargeRow
after insert
as
begin
	set nocount on
	
	if CONVERT(varchar(8),context_info()) = 'NO AUDIT'
		print 'Do Whatever You Want'
	else begin
		print 'I''ll log your action'
		print 'Or, perhaps, rollback transaction'
	end
end
go

declare
	@ContextInfo varbinary(128) 
	
select @ContextInfo = CONVERT(varbinary(128),'NO AUDIT')

set context_info @ContextInfo

insert into dbo.LargeRow(Id, IntField, CharField)
values(-1,-1,'aaa')
go

declare
	@ContextInfo varbinary(128) 

select @ContextInfo = 0x00

set context_info @ContextInfo

insert into dbo.LargeRow(Id, IntField, CharField)
values(-2,-1,'aaa')
go


