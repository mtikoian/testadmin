use RelXmlDemo
go


--------------------------------------------------
-- Spot the non-relational parts...


if exists (select * from sys.tables where [name] = 'UserProfile') drop table dbo.UserProfile;
go

create table dbo.UserProfile (
	UserID int identity(1,1) primary key,
	UserName varchar(128) not null,
	PasswordHash binary(8) not null,
	LastLogin datetime null,
	-- *****
	SystemPreferences xml null
	-- *****
);
go









insert	dbo.UserProfile (UserName, PasswordHash, SystemPreferences)
values	( 'fred', 0x1234567890123456,
			'<Modules><HR><KeepAlive>true</KeepAlive><DefaultPage>Employee Summary</DefaultPage></HR></Modules>' );

insert	dbo.UserProfile (UserName, PasswordHash, SystemPreferences)
values	( 'rosy', 0x6789012345678901, null );

insert	dbo.UserProfile (UserName, PasswordHash, SystemPreferences)
values	( 'hank', 0x5627495627829657,
			'<RememberMe>true</RememberMe><Modules><HR active="false"/></Modules>' );
go






update	dbo.UserProfile
set		SystemPreferences = '<RememberMe>false</RememberMe><Modules><HR active="false"/></Modules>'
where	UserName = 'hank';





select	UserName, SystemPreferences
from	dbo.UserProfile
where	SystemPreferences is not null;







-- BUT...

select	UserName, SystemPreferences
from	dbo.UserProfile
where	SystemPreferences.exist('//RememberMe') = 'true';


-- This last case is non-relational. (Why?)
