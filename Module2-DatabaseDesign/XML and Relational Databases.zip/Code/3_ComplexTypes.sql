use AdventureWorks
go



--------------------------------------------------
-- How do we define a "complex" type? Versus "scalar" types?

select top 10 *
from HumanResources.Employee

-- Usual ideas:
--	a. not "decomposable"
--	b. comparable / sortable
--		(We can say 10:38:08 is "after" 07:30...)
--	c. "simple"
--		But what is "simple"






-- Is "LoginID" in 1NF?
select top 10
		LoginID
	,	left(LoginID,charindex('\',LoginID)-1) as DomainName
	,	substring(LoginID,charindex('\',LoginID)+1,len(LoginID)) as UserName
from HumanResources.Employee


-- Revisit:
select top 10 *
from HumanResources.Employee

-- What about Title?
--	... "Production Technician - WC60"
--	... What's the "WC60" mean? Is the hyphen important?

-- What about BirthDate?

-- People with birthdays this month:
select	top 10
		c.LastName + ', ' + c.FirstName as FullName -- FullName "scalar"?
	,	datepart(dd, e.BirthDate) as Birthday		-- Birthdate "scalar"?
from	HumanResources.Employee e
		inner join Person.Contact c on (e.ContactID = c.ContactID)
where	datepart(mm,e.BirthDate) = datepart(mm,getdate())
order by 1




--------------------------------------------------
-- Conclusion: we already deal with complex types.
-- XML is just another one. (Or *set* of them!)
--------------------------------------------------
