Code samples accompany the PowerPoint slides.

There are small green "circle-arrow" symbols with numbers on slides where a
code-sample applies. The numbers show which script is related.