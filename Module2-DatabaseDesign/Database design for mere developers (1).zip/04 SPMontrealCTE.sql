use SQLRecursion
go
IF EXISTS (SELECT * FROM SYSOBJECTS 
WHERE NAME ='MONTREALCTE' AND TYPE='p')
DROP PROCEDURE dbo.MONTREALCTE
GO
CREATE PROCEDURE dbo.MONTREALCTE AS
------------------------------------------------
--USING CTE'S
--LETS FIRST UPDATE ALL THE LEAF LEVEL Funds
--with their marketvalue
-------------------------------------------------
SET NOCOUNT ON
--
--First let us update all the leaf SUBTOTALS with the MARKET VALUE
--
update c
set subtotal = ISNULL(i.subtotal,0)
from FundParentFund c
left join (
SELECT 
 Fund, SUM(MARKETVALUE)as subtotal
 FROM LotLevelData
 GROUP BY FUND) i
 on i.fund = c.fund
 
--SELECT * FROM FundParentFund
--
--Generate the fund levels relationsh for each composite fund chain using a CTE
--
DECLARE @output TABLE(lvl INT,Fund Char(4),ParentFund char(4))
;with cte as (
Select 0 as lvl, Fund, ParentFund
from FundParentFund where PARENTFUND IS NULL
UNION ALL
SELECT p.lvl + 1, c.Fund,c.parentfund
from FundParentFund c
INNER JOIN CTE P ON P.FUND = C.PARENTFUND
)
INSERT INTO @output (lvl,Fund,ParentFund)

SELECT lvl,Fund,parentfund from cte OPTION(MAXRECURSION 0)
--
--SELECT * FROM @OUTPUT
-- This part does the update to the table.
-- We will start updating subtotal field from the bottom most COMPOSITE  of the funds
-- AAAA has a baby BBBB who has baby CCCC .We shall start with CCCC and work our way back up to AAAA.
--
DECLARE @lvl int
SELECT @lvl = MAX(lvl) from @output
 WHILE (@lvl >= 0) 
  BEGIN
       UPDATE FundParentFund set
 --Add the prior subtotal (c.subtotal) to the current loop subototal
 --(o.subtotal)
       SUBTOTAL = O.SUBTOTAL + C.SUBTOTAL
       FROM FundParentFund C
       INNER JOIN
       (
       SELECT c.parentfund as fund,
       SUM(c.subTotal) as subtotal
       from @output o
       inner join FundParentFund c
       on c.FUND = o.fund
       where lvl = @lvl
       GROUP BY c.PARENTFUND )
       o on o.fund = C.FUND
       SELECT @lvl = @lvl -1
  END
      
