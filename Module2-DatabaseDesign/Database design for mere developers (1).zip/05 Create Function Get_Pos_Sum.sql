USE DAL
GO
if exists (select * from sysobjects where name = 'Get_Pos_Sum_FDR_OTC')
DROP FUNCTION Get_Pos_Sum_FDR_OTC
GO
CREATE FUNCTION Get_Pos_Sum_FDR_OTC
 (@fundlist varchar(500) = '',
  @assetlist varchar(900)='',
  @startdate char(10) = '',
  @enddate char(10) = ''
)
RETURNS @resultset TABLE
( 	
FUND_ID	VARCHAR (8 )	NULL,
CALEN_DT	DATE	NULL,
ASSET_ID	VARCHAR (9 )	NULL,
POS_INT_RT	DECIMAL (31,11)	NULL,
POS_MTRTY_DT	DATE	NULL,
ASSET_GRP_CD	VARCHAR (1 )	NULL,
POS_TYPE_CD	VARCHAR (1 )	NULL,
ACCRL_IND	VARCHAR (1 )	NULL,
ACCRD_BTL	DECIMAL (31,11)	NULL,
ACCRD_LTL	DECIMAL (31,11)	NULL,
ACRU_PRIOR_BTL	DECIMAL (31,11)	NULL,
ACRU_PRIOR_LTL	DECIMAL (31,11)	NULL,
AGNT_BANK_FINS_NUM	VARCHAR (5 )	NULL,
ALT_BBE_ID	VARCHAR (20 )	NULL,
ALT_BBG_ID	VARCHAR (20 )	NULL,
ALT_COM_ID	VARCHAR (9 )	NULL,
ALT_ISIN_ID	VARCHAR (12 )	NULL,
ALT_PPN_ID	VARCHAR (20 )	NULL,
ALT_RIC_ID	VARCHAR (25 )	NULL,
ALT_SEDOL_ID	VARCHAR (7 )	NULL,
ALT_TKR_ID	VARCHAR (20 )	NULL,
ALT_VALOREN_ID	VARCHAR (9 )	NULL,
ALT_WPK_ID	VARCHAR (6 )	NULL,
AMTZD_BTL	DECIMAL (31,11)	NULL,
AMTZD_LTL	DECIMAL (31,11)	NULL,
AMRTZN_TYPE_CD	VARCHAR (1 )	NULL,
ASSET_GRP_NM	VARCHAR (40 )	NULL,
AVGCST_BTL	DECIMAL	NULL,
AVGCST_LTL	DECIMAL	NULL,
AVGCST_ORG_BTL	DECIMAL	NULL,
AVGCST_ORG_LTL	DECIMAL	NULL,
ASSET_CLS_CD	CHAR (2 )	NULL,
BASE_CNTRY_CD	VARCHAR (2 )	NULL,
BASIS_CD	VARCHAR (1 )	NULL,
BNFCY_TAX_ID	VARCHAR (9 )	NULL,
CALL_PUT_IND	VARCHAR (1 )	NULL,
CAP_ISSUE_AMT	DECIMAL (31,11)	NULL,
CAP_ISSUE_DT	DATE	NULL,
CASH_DUE_ATMAT_BTL	DECIMAL (31,11)	NULL,
CASH_DUE_ATMAT_LTL	DECIMAL (31,11)	NULL,
CLIENT_ACCT_NUM	VARCHAR (12 )	NULL,
CLIENT_FUND_NUM	VARCHAR (4 )	NULL,
CONTRACTS_QTY	DECIMAL (31,11)	NULL,
CRNCY_CD_BASE	VARCHAR (3 )	NULL,
CRNCY_CD_LOC	VARCHAR (3 )	NULL,
CRNCY_STATUS_IND	VARCHAR (1 )	NULL,
CRNT_MLTPLR_NUM	DECIMAL (31,11)	NULL,
CRNT_DT	DATE	NULL,
CRNT_STRIKE_PRC	DECIMAL (31,11)	NULL,
CRNT_XCHRT	DECIMAL (31,11)	NULL,
CRNTEXCH_RT_SRC_CD	VARCHAR (4 )	NULL,
CST_MTHD_CD	VARCHAR (1 )	NULL,
CST_BTL	DECIMAL	NULL,
CST_LTL	DECIMAL	NULL,
CST_ORG_BTL	DECIMAL	NULL,
CST_ORG_LTL	DECIMAL	NULL,
CST_RESTRD_BTL	DECIMAL (31,11)	NULL,
CST_RESTRD_LTL	DECIMAL (31,11)	NULL,
DATED_DT	DATE	NULL,
DAYS_TOMAT_CNT	DECIMAL (10)	NULL,
DELAY_DAYS	DECIMAL (3)	NULL,
DENOM_CRNCY_CD	VARCHAR (3 )	NULL,
DEPT_ID	VARCHAR (2 )	NULL,
DICT_OWNER_ID	VARCHAR (4 )	NULL,
DTC_ELIG_IND	VARCHAR (1 )	NULL,
DUMMY_ASSET_IND	VARCHAR (1 )	NULL,
END_OF_PERIOD_EFF_DT	DATE	NULL,
END_OF_PERIOD_EVENT_TS	DATE	NULL,
ETD_SENDER_ID	VARCHAR (8 )	NULL,
EURO_AMER_STYLE_CD	VARCHAR (1 )	NULL,
EURO_HIST_FLG	VARCHAR (1 )	NULL,
EURO_RDNMN_FLG	VARCHAR (1 )	NULL,
EXER_FROM_DT	DATE	NULL,
EXER_TO_DT	DATE	NULL,
EXPIRE_DT	DATE	NULL,
FASB115_ELIG_IND	VARCHAR (1 )	NULL,
FASPRC_SRC_CD	VARCHAR (8 )	NULL,
FFC_FLG	VARCHAR (1 )	NULL,
FGN_IND	VARCHAR (1 )	NULL,
FGN_XCHRT	DECIMAL (31,11)	NULL,
FIRST_INCM_DT	VARCHAR (5 )	NULL,
FIRST_PYMNT_DT	DATE	NULL,
FISC_YE_DT	VARCHAR (4 )	NULL,
FOF_DAY_LAG_IND	VARCHAR (1 )	NULL,
FOF_ISSUE_CLS_CD	VARCHAR (2 )	NULL,
FOF_NAV_DT	DATE	NULL,
FOF_SUBTYPE_CD	VARCHAR (6 )	NULL,
FUND_ASSET_CLS_CD	VARCHAR (2 )	NULL,
FUND_ASSET_CLS_NM	VARCHAR (16 )	NULL,
FUND_ASSET_TYPE_CD	VARCHAR (2 )	NULL,
FUND_ASSET_TYPE_NM	VARCHAR (12 )	NULL,
FUND_NM	VARCHAR (30 )	NULL,
FUND_NOMIN_TAX_ID	VARCHAR (9 )	NULL,
FUND_NOMIN_TAX_NM	VARCHAR (30 )	NULL,
FUND_TYPE_CD	VARCHAR (1 )	NULL,
GL_ASSET_CLS_CD	VARCHAR (3 )	NULL,
GOVT_FCTR_RT	DECIMAL	NULL,
GOVT_POOL_NUM	VARCHAR (6 )	NULL,
GOVT_POOL_SFX_CD	VARCHAR (1 )	NULL,
IDCST_BTL	DECIMAL	NULL,
IDCST_LTL	DECIMAL	NULL,
IDCST_ORG_BTL	DECIMAL	NULL,
IDCST_ORG_LTL	DECIMAL	NULL,
INCM_CRNCY_CD	VARCHAR (3 )	NULL,
INCM_FREQ_CD	VARCHAR (2 )	NULL,
INCORP_CNTRY_CD	VARCHAR (2 )	NULL,
INT_RT	DECIMAL (31,11)	NULL,
INVADV_CD	VARCHAR (5 )	NULL,
INVADV_NM	VARCHAR (40 )	NULL,
INVEST_TYPE_CD	VARCHAR (2 )	NULL,
ISSUE_CLS_CD	VARCHAR (2 )	NULL,
ISSUE_CLS_NM	VARCHAR (45 )	NULL,
ISSUE_CNTRY_CD	VARCHAR (2 )	NULL,
ISSUE_DT	DATE	NULL,
ISSUE_LONG_NM	VARCHAR (61 )	NULL,
ISSUE_SHORT_NM	VARCHAR (30 )	NULL,
ISSUER_NUM	VARCHAR (6 )	NULL,
JOIN_ASSET_ID	VARCHAR (9 )	NULL,
JOIN_ASSET_INT_RT	DECIMAL	NULL,
--JOIN_ASSET_MAT_DT	DATE	NULL,
LDGR_CMPSE_FUND_CD	VARCHAR (8 )	NULL,
MARGIN_VRTN_BTL	DECIMAL (31,11)	NULL,
MARGIN_VRTN_LTL	DECIMAL (31,11)	NULL,
MAT_DT	DATE	NULL,
MGMT_CMPNY_NM	VARCHAR (40 )	NULL,
MKTPRC_CRNCY_CD	VARCHAR (3 )	NULL,
MKTPRC_BAM	DECIMAL	NULL,
MKTPRC_DT	DATE	NULL,
MKTPRC_EAM	DECIMAL (31,11)	NULL,
MKTPRC_CRNCYCD_EUR	VARCHAR (3 )	NULL,
MKTPRC_LAM	DECIMAL	NULL,
MKTPRC_SRC_CD	VARCHAR (30 )	NULL,
MKT_VAL_CD	VARCHAR (1 )	NULL,
MKTVAL_BTL	DECIMAL	NULL,
MKTVAL_LTL	DECIMAL	NULL,
MOODY_RTG	VARCHAR (5 )	NULL,
NRATAX_CNTRY_CD	VARCHAR (2 )	NULL,
NTNL_ACM_GNLS_PREV_BTL	DECIMAL (31,11)	NULL,
NTNL_ACM_GNLS_PREV_LTL	DECIMAL (31,11)	NULL,
NTNL_VAL_PREV_BTL	DECIMAL (31,11)	NULL,
NTNL_VAL_PREV_LTL	DECIMAL (31,11)	NULL,
OEICS_UT_FUND_CD	VARCHAR (1 )	NULL,
OLD_ASSET_ID	VARCHAR (9 )	NULL,
ORG_FACE_POS_QTY	DECIMAL (31,11)	NULL,
ORG_MLTPLR_NUM	DECIMAL (31,11)	NULL,
ORG_STRIKE_PRC	DECIMAL (31,11)	NULL,
PAR_CRNCY_CD	VARCHAR (3 )	NULL,
POOL_TYPE_CD	VARCHAR (2 )	NULL,
PRC_CARRY_FLG	VARCHAR (1 )	NULL,
PREPAY_MTHD_CD	VARCHAR (3 )	NULL,
PRICE_C_D_IND	VARCHAR (1 )	NULL,
PRIOR_DT	DATE	NULL,
PRIOR_PRIOR_DT	DATE	NULL,
PRVPLMNT_IND	VARCHAR (1 )	NULL,
ROOT_TICKER_SYMB	VARCHAR (6 )	NULL,
RPT_BASE_CASH_FLG	VARCHAR (1 )	NULL,
RPT_CLS_CD	VARCHAR (2 )	NULL,
SHRPAR_QTY	DECIMAL (31,11)	NULL,
SHRPAR_CLTL_QTY	DECIMAL (31,11)	NULL,
SHRPAR_RESTRD_QTY	DECIMAL (31,11)	NULL,
SNP_RTG	VARCHAR (5 )	NULL,
SPLIT_CASH_FLG	VARCHAR (1 )	NULL,
SPREAD_AMT	VARCHAR (8 )	NULL,
STALE_PRC_FLG	VARCHAR (1 )	NULL,
STATE_CD	VARCHAR (2 )	NULL,
SW_ACCT_SYSTEM	VARCHAR (5 )	NULL,
TAX_STATUS_IND	VARCHAR (1 )	NULL,
TICKER_SYMB	VARCHAR (6 )	NULL,
TRD_CNTRY_CD	VARCHAR (2 )	NULL,
TRD_CRNCY_CD	VARCHAR (3 )	NULL,
UNDRLNG_ASSET_ID	VARCHAR (9 )	NULL,
UNDRLNG_DESC_LONG_NM	VARCHAR (61 )	NULL,
UNDRLNG_DESC_NM	VARCHAR (35 )	NULL,
UNTCST_BTL	DECIMAL (31,11)	NULL,
UNTCST_LTL	DECIMAL (31,11)	NULL,
UNRLZD_GNLS_BTL	DECIMAL	NULL,
UNRLZD_GNLS_LTL	DECIMAL	NULL,
VAR_RT_FLG	VARCHAR (1 )	NULL,
VAR_RT_FREQ_CD	VARCHAR (2 )	NULL,
XCHRT_EFF_DT	DATE	NULL,
XCHRT_ME_SRC_CD	VARCHAR (4 )	NULL,
XCHRT_PRC_SRC_CD	VARCHAR (4 )	NULL,
XCHRT_SRC_CD	VARCHAR (4 )	NULL,
XCH_CD	VARCHAR (6 )	NULL,
XCH_TICKER_SYMB	VARCHAR (20 )	NULL,
LAST_UPDATED_ID	VARCHAR (30 )	NULL,
LOAD_TIME_STAMP	DATE	NULL,
[SYSTEM] VARCHAR(10)
	)AS
BEGIN
declare @otc varchar(2)
set @otc ='B'
declare @fundlist1 varchar(500)
set @fundlist1 = @fundlist
declare @assetlist1 varchar(500)
set @assetlist1 = @assetlist
INSERT @resultset
  SELECT psd.fund_id AS fund_id, 
		  psd.cal_dt AS calen_dt,
          psd.asset_id AS asset_id, 
          psd.int_rt AS pos_int_rt,
          CASE
             WHEN psd.fund_asset_cls_cd IN
                                    ('OP', 'OW', 'FL', 'FS')
                THEN rsm.e_expire_dt
             ELSE psd.mtrty_dt
          END AS pos_mtrty_dt,
          psd.asset_grp_cd AS asset_grp_cd,
          psd.pos_type_cd AS pos_type_cd,
          psd.acrd_cd AS accrl_ind, 
          psd.acrd_tot_bam AS accrd_btl,
          psd.acrd_tot_lam AS accrd_ltl,
          psd.acr_prior_bam AS acru_prior_btl,
          psd.acr_prior_lam AS acru_prior_ltl,
          dhr.agnt_bnk_fins AS agnt_bank_fins_num, 
          rsm.bbe AS alt_bbe_id,
          rsm.bbg AS alt_bbg_id, 
          rsm.common_code AS alt_com_id,
          rsm.isin_number AS alt_isin_id, 
          rsm.private_placement AS alt_ppn_id,
          rsm.ric AS alt_ric_id,
          rsm.sedol AS alt_sedol_id,
          rsm.tkr AS alt_tkr_id, 
          rsm.valoren AS alt_valoren_id,
          rsm.wpk_number AS alt_wpk_id,
          psd.amrtz_tot_bam AS amtzd_btl,
          psd.amrtz_tot_lam AS amtzd_ltl, 
          psd.amrtz_type_cd AS amrtzn_type_cd,
          psd.asset_grp_nm AS asset_grp_nm,
          CASE
             WHEN psd.asset_grp_cd = 'F'
                THEN psd.ntnl_cst_bam
             ELSE psd.cst_avg_bam
          END AS avgcst_btl,
          CASE
             WHEN psd.asset_grp_cd = 'F'
                THEN psd.ntnl_cst_lam
             ELSE psd.cst_avg_lam
          END AS avgcst_ltl,
          CASE
             WHEN psd.asset_grp_cd = 'F'
                THEN psd.ntnl_cst_bam
             ELSE psd.cst_avg_orig_bam
          END AS avgcst_org_btl,
          CASE
             WHEN psd.asset_grp_cd = 'F'
                THEN psd.ntnl_cst_lam
             ELSE psd.cst_avg_orig_lam
          END AS avgcst_org_ltl,
          CASE
             WHEN rsm.gl_asset_class = '001'
                THEN CASE
                       WHEN rsm.investment_type = 'FC'
                          THEN 'FC'
                       ELSE 'FI'
                    END
             WHEN rsm.gl_asset_class = '003'
                THEN 'ST'
             WHEN rsm.gl_asset_class = '004'
                THEN 'EQ'
             WHEN rsm.gl_asset_class = '005'
                THEN 'PS'
             WHEN rsm.gl_asset_class = '006'
                THEN 'OP'
             WHEN rsm.gl_asset_class = '007'
                THEN 'FT'
          END AS asset_cls_cd,
          dhr.residence_country_code AS base_cntry_cd,
          rsm.basis_code AS basis_cd, 
          dhr.beneficial_tax_id AS bnfcy_tax_id,
         /* fdr_get_issue_class_data ('CALTN_DT_CD',
                                    psd.fund_id,
                                    dhr.client,
                                    psd.issue_cls_cd
                                   ) AS calc_dt_ind,*/
          rsm.e_call_put AS call_put_ind, 
          rsm.tot_cap_issue AS cap_issue_amt,
          rsm.tot_cap_issue_date AS cap_issue_dt,
          psd.csh_due_at_mat_bam AS cash_due_atmat_btl,
          psd.csh_due_at_mat_lam AS cash_due_atmat_ltl,
          dhr.client_account_num AS client_acct_num,
          dhr.client_fund AS client_fund_num,
          psd.contracts_qty AS contracts_qty,
          psd.base_curr_cd AS crncy_cd_base,
          psd.local_curr_cd AS crncy_cd_loc,
          psd.curr_stat_cd AS crncy_status_ind,
          rsm.e_multiplier_curr AS crnt_mltplr_num,
          rfs.crnt_per_eff_dt AS crnt_dt,
          rsm.e_strike_price AS crnt_strike_prc, 
          psd.xchg_rt AS crnt_xchrt,
          psd.xchg_rt_src_cd AS crntexch_rt_src_cd,
          CASE
             WHEN psd.asset_grp_cd = 'M'
                THEN dhr.sw_cash_costing_code
             ELSE dhr.cost_method
          END AS cst_mthd_cd,
          CASE
             WHEN psd.asset_grp_cd = 'F'
                THEN psd.ntnl_cst_bam
             ELSE psd.cst_mthd_bam
          END AS cst_btl,
          CASE
             WHEN psd.asset_grp_cd = 'F'
                THEN psd.ntnl_cst_lam
             ELSE psd.cst_mthd_lam
          END AS cst_ltl,
          CASE
             WHEN psd.asset_grp_cd = 'F'
                THEN psd.ntnl_cst_bam
             ELSE psd.cst_mthd_orig_bam
          END AS cst_org_btl,
          CASE
             WHEN psd.asset_grp_cd = 'F'
                THEN psd.ntnl_cst_lam
             ELSE psd.cst_mthd_orig_lam
          END AS cst_org_ltl,
          psd.cst_restrd_bam AS cst_restrd_btl,
          psd.cst_restrd_lam AS cst_restrd_ltl, 
          rsm.dated_date AS dated_dt,
          psd.day_to_mtrty_cnt AS days_tomat_cnt,
          rsm.delay_days AS delay_days,
          rsm.denomin_currency AS denom_crncy_cd,
          dhr.department_ind AS dept_id,
         /* fdr_get_drc (psd.fund_id,
                       dhr.client,
                       psd.asset_id,
                       rsm.investment_type,
                       psd.cal_dt,
                       dhr.sw_acct_system,
                       psd.asset_grp_cd,
                       NULL,                                        --trade id
                       NULL,                                        --basis cd
                       NULL,                                      --anchor flg
                       NULL,                                       --prod type
                       NULL /*prod family*/
                      ) AS deriv_risk_catg_nm,*/
          /*fdr_get_deriv_info ('DERIVATIVE',
                              rsm.investment_type,
                              rsm.issue_name,
                              NULL,
                              NULL
                             ) AS deriv_type_cd,*/
          dhr.dict_name_trans AS dict_owner_id,
          rsm.dtc_elig_flag AS dtc_elig_ind,
          rsm.cusip_dummy_sw AS dummy_asset_ind,
          rfs.end_of_period_eff_dt AS end_of_period_eff_dt,
          rfs.end_of_period_event_ts AS end_of_period_event_ts,
          dhr.etd_sender_id AS etd_sender_id,
          rsm.e_euro_amer_style_cd AS euro_amer_style_cd,
          rsm.euro_hist_sw AS euro_hist_flg, rsm.redenom_sw AS euro_rdnmn_flg,
          rsm.e_exer_from_dt AS exer_from_dt, rsm.e_exer_to_dt AS exer_to_dt,
          rsm.e_expire_dt AS expire_dt,
          dhr.fasb115_elig_ind AS fasb115_elig_ind,
          psd.fasprc_src_cd AS fasprc_src_cd, dhr.mid_day_ldgr AS ffc_flg,
          rsm.fgn_ind AS fgn_ind, psd.xchg_fgn_rt AS fgn_xchrt,
          CASE
             WHEN rsm.first_income_dt_code IN
                                          ('0000', '00-00')
                THEN NULL
             ELSE rsm.first_income_dt_code
          END AS first_incm_dt,
          rsm.first_pymnt_dt AS first_pymnt_dt, dhr.fisc_ye AS fisc_ye_dt,
       /*   fdr_get_flex_cat ('FLEX_CAT_CODE',
                            psd.fund_id,
                            psd.asset_id,
                            psd.cal_dt,
                 --         LPAD (rsm.investment_type, 2, '0'),
                            rsm.investment_type,
                            psd.nra_tax_cntry_cd,
                            psd.incorp_cntry_cd,
                            psd.trd_cntry_cd,
                            psd.issue_cntry_cd,
                            NULL,
                            NULL
                           ) AS flex_cat_cd,*/
     /*     fdr_get_flex_cat ('FLEX_CAT_DESC',
                            psd.fund_id,
                            psd.asset_id,
                            psd.cal_dt,
                  --          LPAD (rsm.investment_type, 2, '0'),
                            rsm.investment_type,
                            psd.nra_tax_cntry_cd,
                            psd.incorp_cntry_cd,
                            psd.trd_cntry_cd,
                            psd.issue_cntry_cd,
                            NULL,
                            NULL
                           ) AS flex_cat_nm,*/
    /*      fdr_get_flex_cat ('FLEX_CAT_SORT_SEQ',
                            psd.fund_id,
                            psd.asset_id,
                            psd.cal_dt,
                    --        LPAD (rsm.investment_type, 2, '0'),
                            rsm.investment_type,
                            psd.nra_tax_cntry_cd,
                            psd.incorp_cntry_cd,
                            psd.trd_cntry_cd,
                            psd.issue_cntry_cd,
                            NULL,
                            NULL
                           ) AS flex_cat_sort_seq,*/
          CASE
             WHEN psd.asset_grp_cd = 'S'
                THEN psd.fof_day_lag_ind
             ELSE NULL
          END AS fof_day_lag_ind,
          CASE
             WHEN psd.asset_grp_cd = 'S'
                THEN psd.fof_issue_cls_cd
             ELSE NULL
          END AS fof_issue_cls_cd,
          CASE
             WHEN psd.asset_grp_cd = 'S'
                THEN psd.fof_nav_dt
             ELSE NULL
          END AS fof_nav_dt,
          CASE
             WHEN psd.asset_grp_cd = 'S'
                THEN psd.fof_subtype_cd
             ELSE NULL
          END AS fof_subtype_cd,
          psd.fund_asset_cls_cd AS fund_asset_cls_cd,
          psd.fund_asset_cls_nm AS fund_asset_cls_nm,
          psd.fund_asset_type_cd AS fund_asset_type_cd,
          psd.fund_asset_type_nm AS fund_asset_type_nm,
          dhr.fund_name AS fund_nm,
          dhr.fund_nomin_tax_id AS fund_nomin_tax_id,
          dhr.nominee_name AS fund_nomin_tax_nm,
          dhr.fund_type_cd AS fund_type_cd,
 /*       fdr_get_fvm_cd (psd.fund_id,
                          dhr.client,
                          psd.fasprc_src_cd,
                          psd.asset_id,
                          rsm.investment_type,
                          psd.cal_dt,
                          dhr.sw_acct_system,
                          NULL,
                          'Y',
                          psd.asset_grp_cd,
                          NULL,                                  --in_trade_id
                          psd.trd_cntry_cd,                    --in_country_cd
                          psd.trd_curr_cd,                        --in_cuur_cd
                          psd.local_curr_cd,                --in_local_curr_cd
                          psd.base_curr_cd                   --in_base_curr_cd
                         ) AS fvm_cd,*/
          rsm.gl_asset_class AS gl_asset_cls_cd,
          CASE
             WHEN (rsm.smac_rate > 0)
                THEN rsm.smac_rate
             WHEN (rsm.bond_buyer_rt > 0)
                THEN rsm.bond_buyer_rt
             ELSE 1
          END AS govt_fctr_rt,
          rsm.govt_pool_num AS govt_pool_num,
          rsm.govt_pool_sfx_cd AS govt_pool_sfx_cd,
          CASE
             WHEN psd.asset_grp_cd = 'F'
                THEN psd.ntnl_cst_bam
             ELSE psd.cst_id_bam
          END AS idcst_btl,
          CASE
             WHEN psd.asset_grp_cd = 'F'
                THEN psd.ntnl_cst_lam
             ELSE psd.cst_id_lam
          END AS idcst_ltl,
          CASE
             WHEN psd.asset_grp_cd = 'F'
                THEN psd.ntnl_cst_bam
             ELSE psd.cst_id_orig_bam
          END AS idcst_org_btl,
          CASE
             WHEN psd.asset_grp_cd = 'F'
                THEN psd.ntnl_cst_lam
             ELSE psd.cst_id_orig_lam
          END AS idcst_org_ltl,
          rsm.income_currency AS incm_crncy_cd,
          psd.incm_freq_id AS incm_freq_cd,
          rsm.e_incorp_country AS incorp_cntry_cd, rsm.rsm_rate AS int_rt,
          dhr.inst_fins AS invadv_cd, dhr.investment_adv_name AS invadv_nm,
   --       LPAD (rsm.investment_type, 2, '0') AS invest_type_cd,
          rsm.investment_type AS invest_type_cd,
      /*    fdr_get_ref_code ('INVEST_TYPE_NM',
                            rsm.investment_type
                           ) AS invest_type_nm,*/
       --   LPAD (RTRIM (psd.issue_cls_cd), 2, '0') AS issue_cls_cd,
          psd.issue_cls_cd AS issue_cls_cd,
          psd.issue_cls_nm AS issue_cls_nm,
          rsm.issue_country AS issue_cntry_cd, psd.issue_dt AS issue_dt,
       CASE
             WHEN rsm.gl_asset_class = '006'
                THEN (rsm.issue_name +
             (' ' + rsm.issue_description))
       ELSE (rsm.issue_name + (' ' + rsm.issue_descript2))
       END AS issue_long_nm,  
/*     CASE
             WHEN rsm.gl_asset_class = '006'
                THEN CONCAT (rsm.issue_name,
                             CONCAT (' ', rsm.issue_description))
       ELSE CONCAT (rsm.issue_name, CONCAT (' ', rsm.issue_descript2))
       END AS issue_long_nm,*/
          
          rsm.issue_name AS issue_short_nm,
          SUBSTRING (rsm.cusip, 1, 6) AS issuer_num, 
          rsm.cusip AS join_asset_id,
          ISNULL(rsm.rate, 0) AS join_asset_int_rt,
  --        ISNULL(rsm.maturity_date,'1900-01-01') join_asset_mat_dt,
          dhr.comp_fund_id AS ldgr_cmpse_fund_cd,
          psd.margin_vrtn_bam AS margin_vrtn_btl,
          psd.margin_vrtn_lam AS margin_vrtn_ltl,
          rsm.rsm_maturity_date AS mat_dt,
        /*  fdr_get_dict ('MAJOR_CODE',
                        dhr.dict_name_trans,
                        rsm.cusip,
                        psd.fund_id,
                        psd.local_curr_cd
                       ) AS mjr_indsty_cd,*/
       /*   fdr_get_dict ('MAJOR_CODE_DESC',
                        dhr.dict_name_trans,
                        rsm.cusip,
                        psd.fund_id,
                        psd.local_curr_cd
                       ) AS mjr_indsty_nm,*/
 /*         fdr_get_dict ('MINOR_CODE',
                        dhr.dict_name_trans,
                        rsm.cusip,
                        psd.fund_id,
                        psd.local_curr_cd
                       ) AS mnr_indsty_cd,*/
   /*       fdr_get_dict ('MINOR_CODE_DESC',
                        dhr.dict_name_trans,
                        rsm.cusip,
                        psd.fund_id,
                        psd.local_curr_cd
                       ) AS mnr_indsty_nm,*/
          dhr.mgmt_name AS mgmt_cmpny_nm,
          psd.mkt_prc_curr_cd AS mktprc_crncy_cd,
          CASE
             WHEN (psd.asset_grp_cd = 'C' AND psd.mkt_val_cd = 'C'
                  )
             AND psd.shr_par_qty != 0
             AND psdtc.xchg_rt != 0
                THEN ROUND ((  ROUND ((  (psd.mkt_val_lam / psd.shr_par_qty)
                                       * 100
                                      ),
                                      6
                                     )
                             / psdtc.xchg_rt
                            ),
                            6
                           )
             ELSE psd.mkt_prc_bam
          END AS mktprc_bam,
          psd.mkt_prc_dt AS mktprc_dt, psd.mkt_prc_eam AS mktprc_eam,
          psd.mkt_prc_eur_curr_cd AS mktprc_crncycd_eur,
          CASE
             WHEN (psd.asset_grp_cd = 'C' AND psd.mkt_val_cd = 'C'
                  )
             AND psd.shr_par_qty != 0
                THEN ROUND (((psd.mkt_val_lam / psd.shr_par_qty) * 100), 6)
             ELSE psd.mkt_prc_lam
          END AS mktprc_lam,
          psd.mkt_prc_src_cd AS mktprc_src_cd, psd.mkt_val_cd AS mkt_val_cd,
          CASE
             WHEN psd.asset_grp_cd = 'F'
                THEN psd.ntnl_val_bam
             ELSE psd.mkt_val_bam
          END AS mktval_btl,
          CASE
             WHEN psd.asset_grp_cd = 'F'
                THEN psd.ntnl_val_lam
             ELSE psd.mkt_val_lam
          END AS mktval_ltl,
          rsm.e_moodys_ratings AS moody_rtg,
          rsm.nra_tax_country AS nratax_cntry_cd,
          psd.ntnl_acm_gnls_prev_bam AS ntnl_acm_gnls_prev_btl,
          psd.ntnl_acm_gnls_prev_lam AS ntnl_acm_gnls_prev_ltl,
          psd.ntnl_val_prev_bam AS ntnl_val_prev_btl,
          psd.ntnl_val_prev_lam AS ntnl_val_prev_ltl,
          dhr.oeics_ut_fund AS oeics_ut_fund_cd,
          rsm.old_cusip AS old_asset_id,
          psd.orig_face_pos_qty AS org_face_pos_qty,
          rsm.e_multiplier_orig AS org_mltplr_num,
          rsm.e_org_strike_price AS org_strike_prc,
          rsm.par_currency AS par_crncy_cd, rsm.pool_type_cd AS pool_type_cd,
          psd.prc_carry_flg AS prc_carry_flg,
          dhr.prepay_mthd_cd AS prepay_mthd_cd,
          psd.price_c_d_ind AS price_c_d_ind,
          rfs.prior_per_eff_dt AS prior_dt,
          rfs.pr_pr_per_eff_dt AS prior_prior_dt,
          rsm.prvplmnt_ind AS prvplmnt_ind,
 /*         fdr_get_dict ('COUNTRY_OF_RISK',
                        dhr.dict_name_trans,
                        rsm.cusip,
                        psd.fund_id,
                        psd.local_curr_cd
                       ) AS risk_cntry_cd,*/
          rsm.root_ticker AS root_ticker_symb,
          dhr.report_base_cash_flag AS rpt_base_cash_flg,
          psd.rpt_cls_cd AS rpt_cls_cd, psd.shr_par_qty AS shrpar_qty,
          psd.shr_par_cltl_qty AS shrpar_cltl_qty,
          psd.shr_par_restrd_qty AS shrpar_restrd_qty,
          rsm.e_snp_ratings AS snp_rtg, dhr.split_cash AS split_cash_flg,
          psd.spread_amt AS spread_amt, psd.stale_price_flg AS stale_prc_flg,
          rsm.state_cd AS state_cd, dhr.sw_acct_system AS sw_acct_system,
          psd.tax_status_ind AS tax_status_ind, rsm.ticker6 AS ticker_symb,
          rsm.trade_country AS trd_cntry_cd,
          rsm.trade_currency AS trd_crncy_cd,
          rsm.e_undly_security AS undrlng_asset_id,
          rsm.undly_issue_long_nm AS undrlng_desc_long_nm,
          rsm.e_undly_description AS undrlng_desc_nm,
          psd.unit_cst_bam AS untcst_btl, psd.unit_cst_lam AS untcst_ltl,
          CASE
             WHEN psd.asset_grp_cd = 'F'
                THEN psd.ntnl_acm_gnls_bam
             ELSE psd.unrld_gnls_bam
          END AS unrlzd_gnls_btl,
          CASE
             WHEN psd.asset_grp_cd = 'F'
                THEN psd.ntnl_acm_gnls_lam
             ELSE psd.unrld_gnls_lam
          END AS unrlzd_gnls_ltl,
          /* fdr_get_datefromchar (psd.vrble_rt_chg_dt) AS var_rt_chg_dt,*/
          rsm.var_rate AS var_rt_flg, psd.vrble_rt_freq_cd AS var_rt_freq_cd,
          CASE
             WHEN psd.base_curr_cd = psd.local_curr_cd
                THEN psd.cal_dt
             ELSE psdtc.xchg_rt_eff_dt
          END AS xchrt_eff_dt,
          dhr.me_xrte_source_code AS xchrt_me_src_cd,
          dhr.pr_xrte_source_code AS xchrt_prc_src_cd,
          dhr.exchange_rate_source AS xchrt_src_cd, rsm.e_exchange AS xch_cd,
          rsm.e_xch_ticker_symb AS xch_ticker_symb,
          psd.last_updated_id AS last_updated_id,
          psd.last_updated_ts AS load_time_stamp,
          psd.[SYSTEM]
     FROM pos_sum_dly psd,
          pos_sum_dly_tot psdtc,
          pos_sum_dly_tot psdtt,
          ref_fund_status rfs,
          dhr_t dhr,
          rsm rsm
    WHERE psd.fund_id = psdtt.fund_id
      AND psd.cal_dt = psdtt.cal_dt
      AND psdtt.fnd_tot_typ_cd = 'T'
      AND psd.base_curr_cd = psdtt.fnd_tot_curr_cd
      AND psd.fund_id = psdtc.fund_id
      AND psd.cal_dt = psdtc.cal_dt
      AND psd.local_curr_cd = psdtc.fnd_tot_curr_cd
      AND psdtc.fnd_tot_typ_cd = 'C'
      AND psd.fund_id = rfs.fund_id
      AND dhr.ssb_fund = rfs.fund_id
      AND rfs.period_ind_cd = 'D'
      AND psd.fund_id = dhr.ssb_fund
      AND psd.security_id = rsm.rsm_instance
      AND (psd.shr_par_qty <> 0 OR psd.cst_mthd_lam <> 0) 
      and psd.cal_dt >= CASE WHEN @startdate = ' ' then convert(char(10),'1935-01-01')    
                        else convert(char(10),@startdate,120) end  
      and psd.cal_dt <= CASE WHEN @enddate = ' ' then convert(char(10),'2035-01-01')    
                        else convert(char(10),@enddate,120) end 
--        and  CHARINDEX(psd.fund_id,@fundlist1,1) >0
--        and  CHARINDEX(psd.asset_id,@assetlist1,1) >0
--      and  CHARINDEX(psd.fund_id,@fundlist1,1) >0
--Check to see if fund id's have been passed
        and  ((1 = CASE
              WHEN @fundlist =''
                 THEN 1 ELSE 2
              END) or CHARINDEX(psd.fund_id,@fundlist1,1) >0 )        
        
--      and  CHARINDEX(psd.asset_id,@assetlist1,1) >0

--Check to see if asset id's have been passed
        and  ((1 = CASE
              WHEN @assetlist =''
                 THEN 1 ELSE 2
              END) or CHARINDEX(psd.asset_id,@assetlist1,1) >0 )        
       
-- steve    
   UNION ALL
   SELECT psdh.fund_id AS fund_id, psdh.cal_dt AS calen_dt,
          psdh.asset_id AS asset_id, psdh.int_rt AS pos_int_rt,
          CASE
             WHEN psdh.fund_asset_cls_cd IN
                                    ('OP', 'OW', 'FL', 'FS')
                THEN rsm.e_expire_dt
             ELSE psdh.mtrty_dt
          END AS pos_mtrty_dt,
          psdh.asset_grp_cd AS asset_grp_cd, psdh.pos_type_cd AS pos_type_cd,
          psdh.acrd_cd AS accrl_ind, psdh.acrd_tot_bam AS accrd_btl,
          psdh.acrd_tot_lam AS accrd_ltl,
          psdh.acr_prior_bam AS acru_prior_btl,
          psdh.acr_prior_lam AS acru_prior_ltl,
          dhr.agnt_bnk_fins AS agnt_bank_fins_num, rsm.bbe AS alt_bbe_id,
          rsm.bbg AS alt_bbg_id, rsm.common_code AS alt_com_id,
          rsm.isin_number AS alt_isin_id, rsm.private_placement AS alt_ppn_id,
          rsm.ric AS alt_ric_id, rsm.sedol AS alt_sedol_id,
          rsm.tkr AS alt_tkr_id, rsm.valoren AS alt_valoren_id,
          rsm.wpk_number AS alt_wpk_id, psdh.amrtz_tot_bam AS amtzd_btl,
          psdh.amrtz_tot_lam AS amtzd_ltl,
          psdh.amrtz_type_cd AS amrtzn_type_cd,
          psdh.asset_grp_nm AS asset_grp_nm,
          CASE
             WHEN psdh.asset_grp_cd = 'F'
                THEN psdh.ntnl_cst_bam
             ELSE psdh.cst_avg_bam
          END AS avgcst_btl,
          CASE
             WHEN psdh.asset_grp_cd = 'F'
                THEN psdh.ntnl_cst_lam
             ELSE psdh.cst_avg_lam
          END AS avgcst_ltl,
          CASE
             WHEN psdh.asset_grp_cd = 'F'
                THEN psdh.ntnl_cst_bam
             ELSE psdh.cst_avg_orig_bam
          END AS avgcst_org_btl,
          CASE
             WHEN psdh.asset_grp_cd = 'F'
                THEN psdh.ntnl_cst_lam
             ELSE psdh.cst_avg_orig_lam
          END AS avgcst_org_ltl,
          CASE
             WHEN rsm.gl_asset_class = '001'
                THEN CASE
                       WHEN rsm.investment_type = 'FC'
                          THEN 'FC'
                       ELSE 'FI'
                    END
             WHEN rsm.gl_asset_class = '003'
                THEN 'ST'
             WHEN rsm.gl_asset_class = '004'
                THEN 'EQ'
             WHEN rsm.gl_asset_class = '005'
                THEN 'PS'
             WHEN rsm.gl_asset_class = '006'
                THEN 'OP'
             WHEN rsm.gl_asset_class = '007'
                THEN 'FT'
          END AS asset_cls_cd,
          dhr.residence_country_code AS base_cntry_cd,
          rsm.basis_code AS basis_cd, dhr.beneficial_tax_id AS bnfcy_tax_id,
    /*      fdr_get_issue_class_data ('CALTN_DT_CD',
                                    psdh.fund_id,
                                    dhr.client,
                                    psdh.issue_cls_cd
                                   ) AS calc_dt_ind,*/
          rsm.e_call_put AS call_put_ind, rsm.tot_cap_issue AS cap_issue_amt,
          rsm.tot_cap_issue_date AS cap_issue_dt,
          psdh.csh_due_at_mat_bam AS cash_due_atmat_btl,
          psdh.csh_due_at_mat_lam AS cash_due_atmat_ltl,
          dhr.client_account_num AS client_acct_num,
          dhr.client_fund AS client_fund_num,
          psdh.contracts_qty AS contracts_qty,
          psdh.base_curr_cd AS crncy_cd_base,
          psdh.local_curr_cd AS crncy_cd_loc,
          psdh.curr_stat_cd AS crncy_status_ind,
          rsm.e_multiplier_curr AS crnt_mltplr_num,
          rfs.crnt_per_eff_dt AS crnt_dt,
          rsm.e_strike_price AS crnt_strike_prc, psdh.xchg_rt AS crnt_xchrt,
          psdh.xchg_rt_src_cd AS crntexch_rt_src_cd,
          CASE
             WHEN psdh.asset_grp_cd = 'M'
                THEN dhr.sw_cash_costing_code
             ELSE dhr.cost_method
          END AS cst_mthd_cd,
          CASE
             WHEN psdh.asset_grp_cd = 'F'
                THEN psdh.ntnl_cst_bam
             ELSE psdh.cst_mthd_bam
          END AS cst_btl,
          CASE
             WHEN psdh.asset_grp_cd = 'F'
                THEN psdh.ntnl_cst_lam
             ELSE psdh.cst_mthd_lam
          END AS cst_ltl,
          CASE
             WHEN psdh.asset_grp_cd = 'F'
                THEN psdh.ntnl_cst_bam
             ELSE psdh.cst_mthd_orig_bam
          END AS cst_org_btl,
          CASE
             WHEN psdh.asset_grp_cd = 'F'
                THEN psdh.ntnl_cst_lam
             ELSE psdh.cst_mthd_orig_lam
          END AS cst_org_ltl,
          psdh.cst_restrd_bam AS cst_restrd_btl,
          psdh.cst_restrd_lam AS cst_restrd_ltl, rsm.dated_date AS dated_dt,
          psdh.day_to_mtrty_cnt AS days_tomat_cnt,
          rsm.delay_days AS delay_days,
          rsm.denomin_currency AS denom_crncy_cd,
          dhr.department_ind AS dept_id,
         /* fdr_get_drc (psdh.fund_id,
                       dhr.client,
                       psdh.asset_id,
                       rsm.investment_type,
                       psdh.cal_dt,
                       dhr.sw_acct_system,
                       psdh.asset_grp_cd,
                       NULL,                                        --trade id
                       NULL,                                        --basis cd
                       NULL,                                      --anchor flg
                       NULL,                                       --prod type
                       NULL /*prod family*/
                      ) AS deriv_risk_catg_nm,*/
          /*fdr_get_deriv_info ('DERIVATIVE',
                              rsm.investment_type,
                              rsm.issue_name,
                              NULL,
                              NULL
                             ) AS deriv_type_cd,*/
          dhr.dict_name_trans AS dict_owner_id,
          rsm.dtc_elig_flag AS dtc_elig_ind,
          rsm.cusip_dummy_sw AS dummy_asset_ind,
          rfs.end_of_period_eff_dt AS end_of_period_eff_dt,
          rfs.end_of_period_event_ts AS end_of_period_event_ts,
          dhr.etd_sender_id AS etd_sender_id,
          rsm.e_euro_amer_style_cd AS euro_amer_style_cd,
          rsm.euro_hist_sw AS euro_hist_flg, rsm.redenom_sw AS euro_rdnmn_flg,
          rsm.e_exer_from_dt AS exer_from_dt, rsm.e_exer_to_dt AS exer_to_dt,
          rsm.e_expire_dt AS expire_dt,
          dhr.fasb115_elig_ind AS fasb115_elig_ind,
          psdh.fasprc_src_cd AS fasprc_src_cd, dhr.mid_day_ldgr AS ffc_flg,
          rsm.fgn_ind AS fgn_ind, psdh.xchg_fgn_rt AS fgn_xchrt,
          CASE
             WHEN rsm.first_income_dt_code IN
                                          ('0000', '00-00')
                THEN NULL
             ELSE rsm.first_income_dt_code
          END AS first_incm_dt,
          rsm.first_pymnt_dt AS first_pymnt_dt, dhr.fisc_ye AS fisc_ye_dt,
   /*       fdr_get_flex_cat ('FLEX_CAT_CODE',
                            psdh.fund_id,
                            psdh.asset_id,
                            psdh.cal_dt,
                        --  LPAD (rsm.investment_type, 2, '0'),
                            rsm.investment_type, 
                            rsm.nra_tax_country,
                            rsm.e_incorp_country,
                            rsm.trade_country,
                            rsm.issue_country,
                            NULL,
                            NULL
                           ) AS flex_cat_cd,*/
        /*fdr_get_flex_cat ('FLEX_CAT_DESC',
                            psdh.fund_id,
                            psdh.asset_id,
                            psdh.cal_dt,
       --                   LPAD (rsm.investment_type, 2, '0'),
                            rsm.investment_type,
                            rsm.nra_tax_country,
                            rsm.e_incorp_country,
                            rsm.trade_country,
                            rsm.issue_country,
                            NULL,
                            NULL
                           ) AS flex_cat_nm,*/
     /*   fdr_get_flex_cat ('FLEX_CAT_SORT_SEQ',
                            psdh.fund_id,
                            psdh.asset_id,
                            psdh.cal_dt,
              --            LPAD (rsm.investment_type, 2, '0'),
                            rsm.investment_type,                            
                            rsm.nra_tax_country,
                            rsm.e_incorp_country,
                            rsm.trade_country,
                            rsm.issue_country,
                            NULL,
                            NULL
                           ) AS flex_cat_sort_seq,*/
          CASE
             WHEN psdh.asset_grp_cd = 'S'
                THEN psdh.fof_day_lag_ind
             ELSE NULL
          END AS fof_day_lag_ind,
          CASE
             WHEN psdh.asset_grp_cd = 'S'
                THEN psdh.fof_issue_cls_cd
             ELSE NULL
          END AS fof_issue_cls_cd,
          CASE
             WHEN psdh.asset_grp_cd = 'S'
                THEN psdh.fof_nav_dt
             ELSE NULL
          END AS fof_nav_dt,
          CASE
             WHEN psdh.asset_grp_cd = 'S'
                THEN psdh.fof_subtype_cd
             ELSE NULL
          END AS fof_subtype_cd,
          psdh.fund_asset_cls_cd AS fund_asset_cls_cd,
          psdh.fund_asset_cls_nm AS fund_asset_cls_nm,
          psdh.fund_asset_type_cd AS fund_asset_type_cd,
          psdh.fund_asset_type_nm AS fund_asset_type_nm,
          dhr.fund_name AS fund_nm,
          dhr.fund_nomin_tax_id AS fund_nomin_tax_id,
          dhr.nominee_name AS fund_nomin_tax_nm,
          dhr.fund_type_cd AS fund_type_cd,
     /*     fdr_get_fvm_cd (psdh.fund_id,
                          dhr.client,
                          psdh.fasprc_src_cd,
                          psdh.asset_id,
                          rsm.investment_type,
                          psdh.cal_dt,
                          dhr.sw_acct_system,
                          NULL,
                          'Y',
                          psdh.asset_grp_cd,
                          NULL,                                  --in_trade_id
                          rsm.trade_country,                   --in_country_cd
                          rsm.trade_currency,                     --in_curr_cd
                          psdh.local_curr_cd,               --in_local_curr_cd
                          psdh.base_curr_cd                  --in_base_curr_cd
                         ) AS fvm_cd, */
          rsm.gl_asset_class AS gl_asset_cls_cd,
          CASE
             WHEN (rsm.smac_rate > 0)
                THEN rsm.smac_rate
             WHEN (rsm.bond_buyer_rt > 0)
                THEN rsm.bond_buyer_rt
             ELSE 1
          END AS govt_fctr_rt,
          rsm.govt_pool_num AS govt_pool_num,
          rsm.govt_pool_sfx_cd AS govt_pool_sfx_cd,
          CASE
             WHEN psdh.asset_grp_cd = 'F'
                THEN psdh.ntnl_cst_bam
             ELSE psdh.cst_id_bam
          END AS idcst_btl,
          CASE
             WHEN psdh.asset_grp_cd = 'F'
                THEN psdh.ntnl_cst_lam
             ELSE psdh.cst_id_lam
          END AS idcst_ltl,
          CASE
             WHEN psdh.asset_grp_cd = 'F'
                THEN psdh.ntnl_cst_bam
             ELSE psdh.cst_id_orig_bam
          END AS idcst_orig_btl,
          CASE
             WHEN psdh.asset_grp_cd = 'F'
                THEN psdh.ntnl_cst_lam
             ELSE psdh.cst_id_orig_lam
          END AS idcst_orig_ltl,
          rsm.income_currency AS incm_crncy_cd,
          psdh.incm_freq_id AS incm_freq_cd,
          rsm.e_incorp_country AS incorp_cntry_cd, rsm.rsm_rate AS int_rt,
          dhr.inst_fins AS invadv_cd, dhr.investment_adv_name AS invadv_nm,
--          LPAD (rsm.investment_type, 2, '0') AS invest_type_cd,
          rsm.investment_type AS invest_type_cd,
  /*        fdr_get_ref_code ('INVEST_TYPE_NM',
                            rsm.investment_type
                           ) AS invest_type_nm,*/
--        LPAD (RTRIM (psdh.issue_cls_cd), 2, '0') AS issue_cls_cd,
          psdh.issue_cls_cd AS issue_cls_cd,
          psdh.issue_cls_nm AS issue_cls_nm,
          rsm.issue_country AS issue_cntry_cd, psdh.issue_dt AS issue_dt,
/*         CASE
             WHEN rsm.gl_asset_class = '006'
                THEN CONCAT (rsm.issue_name,
                             CONCAT (' ', rsm.issue_description)
                            )
             ELSE CONCAT (rsm.issue_name, CONCAT (' ', rsm.issue_descript2))
          END AS issue_long_nm,*/         
         
       CASE
             WHEN rsm.gl_asset_class = '006'
                THEN (rsm.issue_name +
             (' ' + rsm.issue_description))
       ELSE (rsm.issue_name + (' ' + rsm.issue_descript2))
       END AS issue_long_nm, 
          
          
          rsm.issue_name AS issue_short_nm,
          SUBSTRING (rsm.cusip, 1, 6) AS issuer_num, rsm.cusip AS join_asset_id,
          ISNULL(rsm.rate, 0)AS join_asset_int_rt,
    --      ISNULL(rsm.maturity_date, CONVERT(VARCHAR(10),'01011900',101))AS join_asset_int_rt,

/*            NVL (rsm.maturity_date,
               TO_DATE ('01/01/1900', 'mm/dd/yyyy')
              ) AS join_asset_mat_dt,*/          
          
          
--          NVL (rsm.rate, 0) AS join_asset_int_rt,
/*            NVL (rsm.maturity_date,
               TO_DATE ('01/01/1900', 'mm/dd/yyyy')
              ) AS join_asset_mat_dt,*/
          dhr.comp_fund_id AS ldgr_cmpse_fund_cd,
          psdh.margin_vrtn_bam AS margin_vrtn_btl,
          psdh.margin_vrtn_lam AS margin_vrtn_ltl,
          rsm.rsm_maturity_date AS mat_dt,
  /*        fdr_get_dict ('MAJOR_CODE',
                        dhr.dict_name_trans,
                        rsm.cusip,
                        psdh.fund_id,
                        psdh.local_curr_cd
                       ) AS mjr_indsty_cd,*/
 /*         fdr_get_dict ('MAJOR_CODE_DESC',
                        dhr.dict_name_trans,
                        rsm.cusip,
                        psdh.fund_id,
                        psdh.local_curr_cd
                       ) AS mjr_indsty_nm,*/
   /*       fdr_get_dict ('MINOR_CODE',
                        dhr.dict_name_trans,
                        rsm.cusip,
                        psdh.fund_id,
                        psdh.local_curr_cd
                       ) AS mnr_indsty_cd,*/
  /*        fdr_get_dict ('MINOR_CODE_DESC',
                        dhr.dict_name_trans,
                        rsm.cusip,
                        psdh.fund_id,
                        psdh.local_curr_cd
                       ) AS mnr_indsty_nm,*/
          dhr.mgmt_name AS mgmt_cmpny_nm,
          psdh.mkt_prc_curr_cd AS mktprc_crncy_cd,
          CASE
             WHEN (psdh.asset_grp_cd = 'C' AND psdh.mkt_val_cd = 'C'
                  )
             AND psdh.shr_par_qty != 0
             AND psdtc.xchg_rt != 0
                THEN ROUND ((  ROUND ((  (psdh.mkt_val_lam / psdh.shr_par_qty
                                         )
                                       * 100
                                      ),
                                      6
                                     )
                             / psdtc.xchg_rt
                            ),
                            6
                           )
             ELSE psdh.mkt_prc_bam
          END AS mktprc_bam,
          psdh.mkt_prc_dt AS mktprc_dt, psdh.mkt_prc_eam AS mktprc_eam,
          psdh.mkt_prc_eur_curr_cd AS mktprc_crncycd_eur,
          CASE
             WHEN (psdh.asset_grp_cd = 'C' AND psdh.mkt_val_cd = 'C'
                  )
             AND psdh.shr_par_qty != 0
                THEN ROUND (((psdh.mkt_val_lam / psdh.shr_par_qty) * 100), 6)
             ELSE psdh.mkt_prc_lam
          END AS mktprc_lam,
          psdh.mkt_prc_src_cd AS mktprc_src_cd, psdh.mkt_val_cd AS mkt_val_cd,
          CASE
             WHEN psdh.asset_grp_cd = 'F'
                THEN psdh.ntnl_val_bam
             ELSE psdh.mkt_val_bam
          END AS mktval_btl,
          CASE
             WHEN psdh.asset_grp_cd = 'F'
                THEN psdh.ntnl_val_lam
             ELSE psdh.mkt_val_lam
          END AS mktval_ltl,
          rsm.e_moodys_ratings AS moody_rtg,
          rsm.nra_tax_country AS nratax_cntry_cd,
          psdh.ntnl_acm_gnls_prev_bam AS ntnl_acm_gnls_prev_btl,
          psdh.ntnl_acm_gnls_prev_lam AS ntnl_acm_gnls_prev_ltl,
          psdh.ntnl_val_prev_bam AS ntnl_val_prev_btl,
          psdh.ntnl_val_prev_lam AS ntnl_val_prev_ltl,
          dhr.oeics_ut_fund AS oeics_ut_fund_cd,
          rsm.old_cusip AS old_asset_id,
          psdh.orig_face_pos_qty AS org_face_pos_qty,
          rsm.e_multiplier_orig AS org_mltplr_num,
          rsm.e_org_strike_price AS org_strike_prc,
          rsm.par_currency AS par_crncy_cd, rsm.pool_type_cd AS pool_type_cd,
          psdh.prc_carry_flg AS prc_carry_flg,
          dhr.prepay_mthd_cd AS prepay_mthd_cd,
          psdh.price_c_d_ind AS price_c_d_ind,
          rfs.prior_per_eff_dt AS prior_dt,
          rfs.pr_pr_per_eff_dt AS prior_prior_dt,
          rsm.prvplmnt_ind AS prvplmnt_ind,
   /*       fdr_get_dict ('COUNTRY_OF_RISK',
                        dhr.dict_name_trans,
                        rsm.cusip,
                        psdh.fund_id,
                        psdh.local_curr_cd
                       ) AS risk_cntry_cd,*/
          rsm.root_ticker AS root_ticker_symb,
          dhr.report_base_cash_flag AS rpt_base_cash_flg,
          psdh.rpt_cls_cd AS rpt_cls_cd, psdh.shr_par_qty AS shrpar_qty,
          psdh.shr_par_cltl_qty AS shrpar_cltl_qty,
          psdh.shr_par_restrd_qty AS shrpar_restrd_qty,
          rsm.e_snp_ratings AS snp_rtg, dhr.split_cash AS split_cash_flg,
          psdh.spread_amt AS spread_amt,
          psdh.stale_price_flg AS stale_prc_flg, rsm.state_cd AS state_cd,
          dhr.sw_acct_system AS sw_acct_system,
          psdh.tax_status_ind AS tax_status_ind, rsm.ticker6 AS ticker_symb,
          rsm.trade_country AS trd_cntry_cd,
          rsm.trade_currency AS trd_crncy_cd,
          rsm.e_undly_security AS undrlng_asset_id,
          rsm.undly_issue_long_nm AS undrlng_desc_long_nm,
          rsm.e_undly_description AS undrlng_desc_nm,
          psdh.unit_cst_bam AS untcst_btl, psdh.unit_cst_lam AS untcst_ltl,
          CASE
             WHEN psdh.asset_grp_cd = 'F'
                THEN psdh.ntnl_acm_gnls_bam
             ELSE psdh.unrld_gnls_bam
          END AS unrlzd_gnls_btl,
          CASE
             WHEN psdh.asset_grp_cd = 'F'
                THEN psdh.ntnl_acm_gnls_lam
             ELSE psdh.unrld_gnls_lam
          END AS unrlzd_gnls_ltl,
      /*    fdr_get_datefromchar (psdh.vrble_rt_chg_dt) AS var_rt_chg_dt,*/
          rsm.var_rate AS var_rt_flg, psdh.vrble_rt_freq_cd AS var_rt_freq_cd,
          CASE
             WHEN psdh.base_curr_cd = psdh.local_curr_cd
                THEN psdh.cal_dt
             ELSE psdtc.xchg_rt_eff_dt
          END AS xchrt_eff_dt,
          dhr.me_xrte_source_code AS xchrt_me_src_cd,
          dhr.pr_xrte_source_code AS xchrt_prc_src_cd,
          dhr.exchange_rate_source AS xchrt_src_cd, rsm.e_exchange AS xch_cd,
          rsm.e_xch_ticker_symb AS xch_ticker_symb,
          psdh.last_updated_id AS last_updated_id,
          psdh.last_updated_ts AS load_time_stamp,
          psdh.[SYSTEM]
     FROM pos_sum_dly_hist psdh,
          rsm rsm,
          dhr_t dhr,
          pos_sum_dly_tot psdtc,
          pos_sum_dly_tot psdtt,
          ref_fund_status rfs
    WHERE psdh.fund_id = dhr.ssb_fund
      AND psdh.fund_id = psdtt.fund_id
      AND psdh.cal_dt = psdtt.cal_dt
      AND psdtt.fnd_tot_typ_cd = 'T'
      AND psdh.base_curr_cd = psdtt.fnd_tot_curr_cd
      AND psdh.fund_id = psdtc.fund_id
      AND psdh.cal_dt = psdtc.cal_dt
      AND psdh.local_curr_cd = psdtc.fnd_tot_curr_cd
      AND psdtc.fnd_tot_typ_cd = 'C'
      AND psdh.fund_id = rfs.fund_id
      AND dhr.ssb_fund = rfs.fund_id         -- For Performance 03/08/07 - JMM
      AND rfs.period_ind_cd = 'D'
      AND psdh.security_id = rsm.rsm_instance
      AND (psdh.shr_par_qty <> 0 OR psdh.cst_mthd_lam <> 0)
      and psdh.cal_dt >= CASE WHEN @startdate = ' ' then convert(char(10),'1935-01-01')    
                        else convert(char(10),@startdate,120) end  
      and psdh.cal_dt <= CASE WHEN @enddate = ' ' then convert(char(10),'2035-01-01')    
                        else convert(char(10),@enddate,120) end 
--       and  CHARINDEX(psdh.fund_id,@fundlist1,1) >0
--       and  CHARINDEX(psdh.asset_id,@assetlist1,1) >0
--      and  CHARINDEX(psd.fund_id,@fundlist1,1) >0
--Check to see if fund id's have been passed
        and  ((1 = CASE
              WHEN @fundlist =''
                 THEN 1 ELSE 2
              END) or CHARINDEX(psdh.fund_id,@fundlist1,1) >0 )        
        
--      and  CHARINDEX(psd.asset_id,@assetlist1,1) >0

--Check to see if asset id's have been passed
        and  ((1 = CASE
              WHEN @assetlist =''
                 THEN 1 ELSE 2
              END) or CHARINDEX(psdh.asset_id,@assetlist1,1) >0 )
       
       --simon
UNION ALL
   SELECT psdotc.fund_id AS fund_id, psdotc.cal_dt AS calen_dt,
          psdotc.asset_id AS asset_id, psdotc.int_rt AS pos_int_rt,
          CASE
             WHEN psdotc.fund_asset_cls_cd IN
                                    ('OP', 'OW', 'FL', 'FS')
                THEN rsm.e_expire_dt
             ELSE psdotc.mtrty_dt
          END AS pos_mtrty_dt,
          psdotc.asset_grp_cd AS asset_grp_cd, psdotc.pos_type_cd AS pos_type_cd,
          psdotc.acrd_cd AS accrl_ind, psdotc.acrd_tot_bam AS accrd_btl,
          psdotc.acrd_tot_lam AS accrd_ltl,
          psdotc.acr_prior_bam AS acru_prior_btl,
          psdotc.acr_prior_lam AS acru_prior_ltl,
          dhr.agnt_bnk_fins AS agnt_bank_fins_num, rsm.bbe AS alt_bbe_id,
          rsm.bbg AS alt_bbg_id, rsm.common_code AS alt_com_id,
          rsm.isin_number AS alt_isin_id, rsm.private_placement AS alt_ppn_id,
          rsm.ric AS alt_ric_id, rsm.sedol AS alt_sedol_id,
          rsm.tkr AS alt_tkr_id, rsm.valoren AS alt_valoren_id,
          rsm.wpk_number AS alt_wpk_id, psdotc.amrtz_tot_bam AS amtzd_btl,
          psdotc.amrtz_tot_lam AS amtzd_ltl,
          psdotc.amrtz_type_cd AS amrtzn_type_cd,
          psdotc.asset_grp_nm AS asset_grp_nm,
          CASE
             WHEN psdotc.asset_grp_cd = 'F'
                THEN psdotc.ntnl_cst_bam
             ELSE psdotc.cst_avg_bam
          END AS avgcst_btl,
          CASE
             WHEN psdotc.asset_grp_cd = 'F'
                THEN psdotc.ntnl_cst_lam
             ELSE psdotc.cst_avg_lam
          END AS avgcst_ltl,
          CASE
             WHEN psdotc.asset_grp_cd = 'F'
                THEN psdotc.ntnl_cst_bam
             ELSE psdotc.cst_avg_orig_bam
          END AS avgcst_org_btl,
          CASE
             WHEN psdotc.asset_grp_cd = 'F'
                THEN psdotc.ntnl_cst_lam
             ELSE psdotc.cst_avg_orig_lam
          END AS avgcst_org_ltl,
          CASE
             WHEN rsm.gl_asset_class = '001'
                THEN CASE
                       WHEN rsm.investment_type = 'FC'
                          THEN 'FC'
                       ELSE 'FI'
                    END
             WHEN rsm.gl_asset_class = '003'
                THEN 'ST'
             WHEN rsm.gl_asset_class = '004'
                THEN 'EQ'
             WHEN rsm.gl_asset_class = '005'
                THEN 'PS'
             WHEN rsm.gl_asset_class = '006'
                THEN 'OP'
             WHEN rsm.gl_asset_class = '007'
                THEN 'FT'
          END AS asset_cls_cd,
          dhr.residence_country_code AS base_cntry_cd,
          rsm.basis_code AS basis_cd, dhr.beneficial_tax_id AS bnfcy_tax_id,
    /*      fdr_get_issue_class_data ('CALTN_DT_CD',
                                    psdotc.fund_id,
                                    dhr.client,
                                    psdotc.issue_cls_cd
                                   ) AS calc_dt_ind,*/
          rsm.e_call_put AS call_put_ind, rsm.tot_cap_issue AS cap_issue_amt,
          rsm.tot_cap_issue_date AS cap_issue_dt,
          psdotc.csh_due_at_mat_bam AS cash_due_atmat_btl,
          psdotc.csh_due_at_mat_lam AS cash_due_atmat_ltl,
          dhr.client_account_num AS client_acct_num,
          dhr.client_fund AS client_fund_num,
          psdotc.contracts_qty AS contracts_qty,
          psdotc.base_curr_cd AS crncy_cd_base,
          psdotc.local_curr_cd AS crncy_cd_loc,
          psdotc.curr_stat_cd AS crncy_status_ind,
          rsm.e_multiplier_curr AS crnt_mltplr_num,
          rfs.crnt_per_eff_dt AS crnt_dt,
          rsm.e_strike_price AS crnt_strike_prc, psdotc.xchg_rt AS crnt_xchrt,
          psdotc.xchg_rt_src_cd AS crntexch_rt_src_cd,
          CASE
             WHEN psdotc.asset_grp_cd = 'M'
                THEN dhr.sw_cash_costing_code
             ELSE dhr.cost_method
          END AS cst_mthd_cd,
          CASE
             WHEN psdotc.asset_grp_cd = 'F'
                THEN psdotc.ntnl_cst_bam
             ELSE psdotc.cst_mthd_bam
          END AS cst_btl,
          CASE
             WHEN psdotc.asset_grp_cd = 'F'
                THEN psdotc.ntnl_cst_lam
             ELSE psdotc.cst_mthd_lam
          END AS cst_ltl,
          CASE
             WHEN psdotc.asset_grp_cd = 'F'
                THEN psdotc.ntnl_cst_bam
             ELSE psdotc.cst_mthd_orig_bam
          END AS cst_org_btl,
          CASE
             WHEN psdotc.asset_grp_cd = 'F'
                THEN psdotc.ntnl_cst_lam
             ELSE psdotc.cst_mthd_orig_lam
          END AS cst_org_ltl,
          psdotc.cst_restrd_bam AS cst_restrd_btl,
          psdotc.cst_restrd_lam AS cst_restrd_ltl, rsm.dated_date AS dated_dt,
          psdotc.day_to_mtrty_cnt AS days_tomat_cnt,
          rsm.delay_days AS delay_days,
          rsm.denomin_currency AS denom_crncy_cd,
          dhr.department_ind AS dept_id,
         /* fdr_get_drc (psdotc.fund_id,
                       dhr.client,
                       psdotc.asset_id,
                       rsm.investment_type,
                       psdotc.cal_dt,
                       dhr.sw_acct_system,
                       psdotc.asset_grp_cd,
                       NULL,                                        --trade id
                       NULL,                                        --basis cd
                       NULL,                                      --anchor flg
                       NULL,                                       --prod type
                       NULL /*prod family*/
                      ) AS deriv_risk_catg_nm,*/
          /*fdr_get_deriv_info ('DERIVATIVE',
                              rsm.investment_type,
                              rsm.issue_name,
                              NULL,
                              NULL
                             ) AS deriv_type_cd,*/
          dhr.dict_name_trans AS dict_owner_id,
          rsm.dtc_elig_flag AS dtc_elig_ind,
          rsm.cusip_dummy_sw AS dummy_asset_ind,
          rfs.end_of_period_eff_dt AS end_of_period_eff_dt,
          rfs.end_of_period_event_ts AS end_of_period_event_ts,
          dhr.etd_sender_id AS etd_sender_id,
          rsm.e_euro_amer_style_cd AS euro_amer_style_cd,
          rsm.euro_hist_sw AS euro_hist_flg, rsm.redenom_sw AS euro_rdnmn_flg,
          rsm.e_exer_from_dt AS exer_from_dt, rsm.e_exer_to_dt AS exer_to_dt,
          rsm.e_expire_dt AS expire_dt,
          dhr.fasb115_elig_ind AS fasb115_elig_ind,
          psdotc.fasprc_src_cd AS fasprc_src_cd, dhr.mid_day_ldgr AS ffc_flg,
          rsm.fgn_ind AS fgn_ind, psdotc.xchg_fgn_rt AS fgn_xchrt,
          CASE
             WHEN rsm.first_income_dt_code IN
                                          ('0000', '00-00')
                THEN NULL
             ELSE rsm.first_income_dt_code
          END AS first_incm_dt,
          rsm.first_pymnt_dt AS first_pymnt_dt, dhr.fisc_ye AS fisc_ye_dt,
   /*       fdr_get_flex_cat ('FLEX_CAT_CODE',
                            psdotc.fund_id,
                            psdotc.asset_id,
                            psdotc.cal_dt,
                        --  LPAD (rsm.investment_type, 2, '0'),
                            rsm.investment_type, 
                            rsm.nra_tax_country,
                            rsm.e_incorp_country,
                            rsm.trade_country,
                            rsm.issue_country,
                            NULL,
                            NULL
                           ) AS flex_cat_cd,*/
        /*fdr_get_flex_cat ('FLEX_CAT_DESC',
                            psdotc.fund_id,
                            psdotc.asset_id,
                            psdotc.cal_dt,
       --                   LPAD (rsm.investment_type, 2, '0'),
                            rsm.investment_type,
                            rsm.nra_tax_country,
                            rsm.e_incorp_country,
                            rsm.trade_country,
                            rsm.issue_country,
                            NULL,
                            NULL
                           ) AS flex_cat_nm,*/
     /*   fdr_get_flex_cat ('FLEX_CAT_SORT_SEQ',
                            psdotc.fund_id,
                            psdotc.asset_id,
                            psdotc.cal_dt,
              --            LPAD (rsm.investment_type, 2, '0'),
                            rsm.investment_type,                            
                            rsm.nra_tax_country,
                            rsm.e_incorp_country,
                            rsm.trade_country,
                            rsm.issue_country,
                            NULL,
                            NULL
                           ) AS flex_cat_sort_seq,*/
          CASE
             WHEN psdotc.asset_grp_cd = 'S'
                THEN psdotc.fof_day_lag_ind
             ELSE NULL
          END AS fof_day_lag_ind,
          CASE
             WHEN psdotc.asset_grp_cd = 'S'
                THEN psdotc.fof_issue_cls_cd
             ELSE NULL
          END AS fof_issue_cls_cd,
          CASE
             WHEN psdotc.asset_grp_cd = 'S'
                THEN psdotc.fof_nav_dt
             ELSE NULL
          END AS fof_nav_dt,
          CASE
             WHEN psdotc.asset_grp_cd = 'S'
                THEN psdotc.fof_subtype_cd
             ELSE NULL
          END AS fof_subtype_cd,
          psdotc.fund_asset_cls_cd AS fund_asset_cls_cd,
          psdotc.fund_asset_cls_nm AS fund_asset_cls_nm,
          psdotc.fund_asset_type_cd AS fund_asset_type_cd,
          psdotc.fund_asset_type_nm AS fund_asset_type_nm,
          dhr.fund_name AS fund_nm,
          dhr.fund_nomin_tax_id AS fund_nomin_tax_id,
          dhr.nominee_name AS fund_nomin_tax_nm,
          dhr.fund_type_cd AS fund_type_cd,
     /*     fdr_get_fvm_cd (psdotc.fund_id,
                          dhr.client,
                          psdotc.fasprc_src_cd,
                          psdotc.asset_id,
                          rsm.investment_type,
                          psdotc.cal_dt,
                          dhr.sw_acct_system,
                          NULL,
                          'Y',
                          psdotc.asset_grp_cd,
                          NULL,                                  --in_trade_id
                          rsm.trade_country,                   --in_country_cd
                          rsm.trade_currency,                     --in_curr_cd
                          psdotc.local_curr_cd,               --in_local_curr_cd
                          psdotc.base_curr_cd                  --in_base_curr_cd
                         ) AS fvm_cd, */
          rsm.gl_asset_class AS gl_asset_cls_cd,
          CASE
             WHEN (rsm.smac_rate > 0)
                THEN rsm.smac_rate
             WHEN (rsm.bond_buyer_rt > 0)
                THEN rsm.bond_buyer_rt
             ELSE 1
          END AS govt_fctr_rt,
          rsm.govt_pool_num AS govt_pool_num,
          rsm.govt_pool_sfx_cd AS govt_pool_sfx_cd,
          CASE
             WHEN psdotc.asset_grp_cd = 'F'
                THEN psdotc.ntnl_cst_bam
             ELSE psdotc.cst_id_bam
          END AS idcst_btl,
          CASE
             WHEN psdotc.asset_grp_cd = 'F'
                THEN psdotc.ntnl_cst_lam
             ELSE psdotc.cst_id_lam
          END AS idcst_ltl,
          CASE
             WHEN psdotc.asset_grp_cd = 'F'
                THEN psdotc.ntnl_cst_bam
             ELSE psdotc.cst_id_orig_bam
          END AS idcst_orig_btl,
          CASE
             WHEN psdotc.asset_grp_cd = 'F'
                THEN psdotc.ntnl_cst_lam
             ELSE psdotc.cst_id_orig_lam
          END AS idcst_orig_ltl,
          rsm.income_currency AS incm_crncy_cd,
          psdotc.incm_freq_id AS incm_freq_cd,
          rsm.e_incorp_country AS incorp_cntry_cd, rsm.rsm_rate AS int_rt,
          dhr.inst_fins AS invadv_cd, dhr.investment_adv_name AS invadv_nm,
--          LPAD (rsm.investment_type, 2, '0') AS invest_type_cd,
          rsm.investment_type AS invest_type_cd,
  /*        fdr_get_ref_code ('INVEST_TYPE_NM',
                            rsm.investment_type
                           ) AS invest_type_nm,*/
--        LPAD (RTRIM (psdotc.issue_cls_cd), 2, '0') AS issue_cls_cd,
          psdotc.issue_cls_cd AS issue_cls_cd,
          psdotc.issue_cls_nm AS issue_cls_nm,
          rsm.issue_country AS issue_cntry_cd, psdotc.issue_dt AS issue_dt,
/*         CASE
             WHEN rsm.gl_asset_class = '006'
                THEN CONCAT (rsm.issue_name,
                             CONCAT (' ', rsm.issue_description)
                            )
             ELSE CONCAT (rsm.issue_name, CONCAT (' ', rsm.issue_descript2))
          END AS issue_long_nm,*/         
         
       CASE
             WHEN rsm.gl_asset_class = '006'
                THEN (rsm.issue_name +
             (' ' + rsm.issue_description))
       ELSE (rsm.issue_name + (' ' + rsm.issue_descript2))
       END AS issue_long_nm, 
          
          
          rsm.issue_name AS issue_short_nm,
          SUBSTRING (rsm.cusip, 1, 6) AS issuer_num, rsm.cusip AS join_asset_id,
          ISNULL(rsm.rate, 0)AS join_asset_int_rt,
    --      ISNULL(rsm.maturity_date, CONVERT(VARCHAR(10),'01011900',101))AS join_asset_int_rt,

/*            NVL (rsm.maturity_date,
               TO_DATE ('01/01/1900', 'mm/dd/yyyy')
              ) AS join_asset_mat_dt,*/          
          
          
--          NVL (rsm.rate, 0) AS join_asset_int_rt,
/*            NVL (rsm.maturity_date,
               TO_DATE ('01/01/1900', 'mm/dd/yyyy')
              ) AS join_asset_mat_dt,*/
          dhr.comp_fund_id AS ldgr_cmpse_fund_cd,
          psdotc.margin_vrtn_bam AS margin_vrtn_btl,
          psdotc.margin_vrtn_lam AS margin_vrtn_ltl,
          rsm.rsm_maturity_date AS mat_dt,
  /*        fdr_get_dict ('MAJOR_CODE',
                        dhr.dict_name_trans,
                        rsm.cusip,
                        psdotc.fund_id,
                        psdotc.local_curr_cd
                       ) AS mjr_indsty_cd,*/
 /*         fdr_get_dict ('MAJOR_CODE_DESC',
                        dhr.dict_name_trans,
                        rsm.cusip,
                        psdotc.fund_id,
                        psdotc.local_curr_cd
                       ) AS mjr_indsty_nm,*/
   /*       fdr_get_dict ('MINOR_CODE',
                        dhr.dict_name_trans,
                        rsm.cusip,
                        psdotc.fund_id,
                        psdotc.local_curr_cd
                       ) AS mnr_indsty_cd,*/
  /*        fdr_get_dict ('MINOR_CODE_DESC',
                        dhr.dict_name_trans,
                        rsm.cusip,
                        psdotc.fund_id,
                        psdotc.local_curr_cd
                       ) AS mnr_indsty_nm,*/
          dhr.mgmt_name AS mgmt_cmpny_nm,
          psdotc.mkt_prc_curr_cd AS mktprc_crncy_cd,
          CASE
             WHEN (psdotc.asset_grp_cd = 'C' AND psdotc.mkt_val_cd = 'C'
                  )
             AND psdotc.shr_par_qty != 0
             AND psdtc.xchg_rt != 0
                THEN ROUND ((  ROUND ((  (psdotc.mkt_val_lam / psdotc.shr_par_qty
                                         )
                                       * 100
                                      ),
                                      6
                                     )
                             / psdtc.xchg_rt
                            ),
                            6
                           )
             ELSE psdotc.mkt_prc_bam
          END AS mktprc_bam,
          psdotc.mkt_prc_dt AS mktprc_dt, psdotc.mkt_prc_eam AS mktprc_eam,
          psdotc.mkt_prc_eur_curr_cd AS mktprc_crncycd_eur,
          CASE
             WHEN (psdotc.asset_grp_cd = 'C' AND psdotc.mkt_val_cd = 'C'
                  )
             AND psdotc.shr_par_qty != 0
                THEN ROUND (((psdotc.mkt_val_lam / psdotc.shr_par_qty) * 100), 6)
             ELSE psdotc.mkt_prc_lam
          END AS mktprc_lam,
          psdotc.mkt_prc_src_cd AS mktprc_src_cd, psdotc.mkt_val_cd AS mkt_val_cd,
          CASE
             WHEN psdotc.asset_grp_cd = 'F'
                THEN psdotc.ntnl_val_bam
             ELSE psdotc.mkt_val_bam
          END AS mktval_btl,
          CASE
             WHEN psdotc.asset_grp_cd = 'F'
                THEN psdotc.ntnl_val_lam
             ELSE psdotc.mkt_val_lam
          END AS mktval_ltl,
          rsm.e_moodys_ratings AS moody_rtg,
          rsm.nra_tax_country AS nratax_cntry_cd,
          psdotc.ntnl_acm_gnls_prev_bam AS ntnl_acm_gnls_prev_btl,
          psdotc.ntnl_acm_gnls_prev_lam AS ntnl_acm_gnls_prev_ltl,
          psdotc.ntnl_val_prev_bam AS ntnl_val_prev_btl,
          psdotc.ntnl_val_prev_lam AS ntnl_val_prev_ltl,
          dhr.oeics_ut_fund AS oeics_ut_fund_cd,
          rsm.old_cusip AS old_asset_id,
          psdotc.orig_face_pos_qty AS org_face_pos_qty,
          rsm.e_multiplier_orig AS org_mltplr_num,
          rsm.e_org_strike_price AS org_strike_prc,
          rsm.par_currency AS par_crncy_cd, rsm.pool_type_cd AS pool_type_cd,
          psdotc.prc_carry_flg AS prc_carry_flg,
          dhr.prepay_mthd_cd AS prepay_mthd_cd,
          psdotc.price_c_d_ind AS price_c_d_ind,
          rfs.prior_per_eff_dt AS prior_dt,
          rfs.pr_pr_per_eff_dt AS prior_prior_dt,
          rsm.prvplmnt_ind AS prvplmnt_ind,
   /*       fdr_get_dict ('COUNTRY_OF_RISK',
                        dhr.dict_name_trans,
                        rsm.cusip,
                        psdotc.fund_id,
                        psdotc.local_curr_cd
                       ) AS risk_cntry_cd,*/
          rsm.root_ticker AS root_ticker_symb,
          dhr.report_base_cash_flag AS rpt_base_cash_flg,
          psdotc.rpt_cls_cd AS rpt_cls_cd, psdotc.shr_par_qty AS shrpar_qty,
          psdotc.shr_par_cltl_qty AS shrpar_cltl_qty,
          psdotc.shr_par_restrd_qty AS shrpar_restrd_qty,
          rsm.e_snp_ratings AS snp_rtg, dhr.split_cash AS split_cash_flg,
          psdotc.spread_amt AS spread_amt,
          psdotc.stale_price_flg AS stale_prc_flg, rsm.state_cd AS state_cd,
          dhr.sw_acct_system AS sw_acct_system,
          psdotc.tax_status_ind AS tax_status_ind, rsm.ticker6 AS ticker_symb,
          rsm.trade_country AS trd_cntry_cd,
          rsm.trade_currency AS trd_crncy_cd,
          rsm.e_undly_security AS undrlng_asset_id,
          rsm.undly_issue_long_nm AS undrlng_desc_long_nm,
          rsm.e_undly_description AS undrlng_desc_nm,
          psdotc.unit_cst_bam AS untcst_btl, psdotc.unit_cst_lam AS untcst_ltl,
          CASE
             WHEN psdotc.asset_grp_cd = 'F'
                THEN psdotc.ntnl_acm_gnls_bam
             ELSE psdotc.unrld_gnls_bam
          END AS unrlzd_gnls_btl,
          CASE
             WHEN psdotc.asset_grp_cd = 'F'
                THEN psdotc.ntnl_acm_gnls_lam
             ELSE psdotc.unrld_gnls_lam
          END AS unrlzd_gnls_ltl,
      /*    fdr_get_datefromchar (psdotc.vrble_rt_chg_dt) AS var_rt_chg_dt,*/
          rsm.var_rate AS var_rt_flg, psdotc.vrble_rt_freq_cd AS var_rt_freq_cd,
          CASE
             WHEN psdotc.base_curr_cd = psdotc.local_curr_cd
                THEN psdotc.cal_dt
             ELSE psdtc.xchg_rt_eff_dt
          END AS xchrt_eff_dt,
          dhr.me_xrte_source_code AS xchrt_me_src_cd,
          dhr.pr_xrte_source_code AS xchrt_prc_src_cd,
          dhr.exchange_rate_source AS xchrt_src_cd, rsm.e_exchange AS xch_cd,
          rsm.e_xch_ticker_symb AS xch_ticker_symb,
          psdotc.last_updated_id AS last_updated_id,
          psdotc.last_updated_ts AS load_time_stamp,
          psdotc.[SYSTEM]
     FROM pos_sum_dly_otc psdotc,
          rsm rsm,
          dhr_t dhr,
          pos_sum_dly_tot psdtc,
          pos_sum_dly_tot psdtt,
          ref_fund_status rfs
    WHERE psdotc.fund_id = dhr.ssb_fund
      AND psdotc.fund_id = psdtt.fund_id
      AND psdotc.cal_dt = psdtt.cal_dt
      AND psdtt.fnd_tot_typ_cd = 'T'
      AND psdotc.base_curr_cd = psdtt.fnd_tot_curr_cd
      AND psdotc.fund_id = psdtc.fund_id
      AND psdotc.cal_dt = psdtc.cal_dt
      AND psdotc.local_curr_cd = psdtc.fnd_tot_curr_cd
      AND psdtc.fnd_tot_typ_cd = 'C'
      AND psdotc.fund_id = rfs.fund_id
      AND dhr.ssb_fund = rfs.fund_id         -- For Performance 03/08/07 - JMM
      AND rfs.period_ind_cd = 'D'
      AND psdotc.security_id = rsm.rsm_instance
      AND (psdotc.shr_par_qty <> 0 OR psdotc.cst_mthd_lam <> 0)
      and psdotc.cal_dt >= CASE WHEN @startdate = ' ' then convert(char(10),'1935-01-01')    
                        else convert(char(10),@startdate,120) end  
      and psdotc.cal_dt <= CASE WHEN @enddate = ' ' then convert(char(10),'2035-01-01')    
                        else convert(char(10),@enddate,120) end 
 --      and  CHARINDEX(psdotc.fund_id,@fundlist1,1) >0
 --      and  CHARINDEX(psdotc.asset_id,@assetlist1,1) >0       
      --      and  CHARINDEX(psd.fund_id,@fundlist1,1) >0
--Check to see if fund id's have been passed
        and  ((1 = CASE
              WHEN @fundlist =''
                 THEN 1 ELSE 2
              END) or CHARINDEX(psdotc.fund_id,@fundlist1,1) >0 )        
        
--      and  CHARINDEX(psd.asset_id,@assetlist1,1) >0

--Check to see if asset id's have been passed
        and  ((1 = CASE
              WHEN @assetlist =''
                 THEN 1 ELSE 2
              END) or CHARINDEX(psdotc.asset_id,@assetlist1,1) >0 ) 
       
       
       
	RETURN
	END