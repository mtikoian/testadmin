use DAL
go
DBCC FREESESSIONCACHE WITH NO_INFOMSGS;
go 
select 
p.Active, 
a.fund_id, a.asset_id, a.CALEN_DT, a.CAP_ISSUE_AMT from
(SELECT fund_id, asset_id, CALEN_DT, CAP_ISSUE_AMT 
FROM Get_Pos_Sum('','203900105|IEP,857477103',
'2006-01-01','2008-12-31')) a
inner join ActiveOrClosed p
on a.fund_id = p.FUND_ID
group by a.fund_id, a.asset_id, a.CALEN_DT,p.Active,a.CAP_ISSUE_AMT

 


