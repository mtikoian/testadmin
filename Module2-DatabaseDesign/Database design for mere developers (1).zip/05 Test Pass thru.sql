use DAL
go
SELECT fund_id, asset_id, CALEN_DT,[SYSTEM]
FROM Get_Pos_Sum_fdr_otc('m1te|fdr1|pat2','203900105|IEP','2006-01-01','2008-12-31') 
