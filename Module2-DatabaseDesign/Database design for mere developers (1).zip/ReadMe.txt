Hi All,
Thanks ever so much for attending my presentation.
My apologies for NOT have spent more time on explaining the recursion model. Trying to fit all the concepts in one 1hr presentation
is very tough.
Should you wish to discuss any of the concepts that I covered, PLEASE contact me at steve.simon@sqlpass.org

The DAL database is 99MB large and not optimal for zipping. Should you wish the raw data please let me know and
I shall get the database to you somehow. I have however included the code INCLUDING that filter that I discussed.
Have a look at 05 create function Get_Pos_Sum and do a search for --steve   . You will find that 'case ' filter there.

regards Steve
