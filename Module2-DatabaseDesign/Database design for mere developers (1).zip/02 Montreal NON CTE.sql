USE SQLRecursion1
GO

------------------------------------------------
--LETS FIRST UPDATE ALL THE LEAF LEVEL Funds
--with their marketvalue
-------------------------------------------------
SET NOCOUNT ON
--
update c
set subtotal = ISNULL(i.subtotal,0)
from FundParentFund c
left join (
SELECT 
 Fund, SUM(MARKETVALUE)as subtotal
 FROM LotLevelData
 GROUP BY FUND) i
 on i.fund = c.fund
 --select * from FundParentFund
 --select Fund, SUM(marketvalue) from LotLevelData 
 --where fund between '0001' and '0013'
 --group by FUND
 --order by fund
 --------------------------------------------------------
 --Next let's generate the fund relationship chain
 --using custom logic. We shall create a memory table as a 
 --customized stack.
 --------------------------------------------------------
 
 --stack table
 DECLARE @stack TABLE( AutoID int identity, lvl int, Fund char(4),
 parentFund char(4))
 
 --output table
 DECLARE @output TABLE (lvl int, fund char(4), ParentFund char(4))
 
 --Populate the output table with root funds
 INSERT INTO @output (lvl,fund,ParentFund)
 select 0, fund, parentfund from FundParentFund where PARENTFUND IS NULL
 --Populate stack with the rootlevel funds
 insert into @stack(lvl,Fund,parentFund)
 Select 0,fund, parentfund from fundParentfund where parentfund is null
 
--select * from @stack
 
 --Now generate the fund relationship chain
 DECLARE @ID int, @lvl INT
 WHILE EXISTS(SELECT * FROM @stack ) 
 BEGIN
 -- take the last row from the stack
 SELECT TOP 1
 @ID = Fund,
 @lvl = LVL
 FROM @stack 
 ORDER BY AutoID DESC
 --Delete this row from the stack
 DELETE FROM @stack where Fund = @ID
 
 --process the matching rows and insert into the output 
 --table. These are the children of the 0001 in this case.
 INSERT INTO @output(lvl,fund,ParentFund)
 Select @lvl + 1, Fund, parentfund from FundParentFund
 where PARENTFUND = @ID

-- Add it to stack as well.These are the children of the 0001 in this case.

INSERT INTO @stack(lvl,fund,ParentFund)
 Select @lvl + 1, Fund, parentfund from FundParentFund
 where PARENTFUND = @ID  
 END 
 -- END WHILE
--select * from @output
 ------------------------------------------------------
 --This part does the actual update of the subtotal field
 --The previous section generated the levels of the funds.
 --We shall start updating from the fund at the bottom most
 --position.
 ------------------------------------------------------
 SELECT @lvl = MAX(lvl) from @output
 WHILE (@lvl >= 0) 
  BEGIN
       UPDATE FundParentFund set
 --Add the subtotal (c.subtotal) of all children of the current fund to parent fund
 --(o.subtotal)
       SUBTOTAL = O.SUBTOTAL + C.SUBTOTAL
       FROM FundParentFund C
       INNER JOIN
       (
       SELECT c.parentfund as fund,
       SUM(c.subTotal) as subtotal
       from @output o
       inner join FundParentFund c
       on c.FUND = o.fund
       where lvl = @lvl
       GROUP BY c.PARENTFUND )
       o on o.fund = C.FUND
       SELECT @lvl = @lvl -1
  END
       
              
 
  
 