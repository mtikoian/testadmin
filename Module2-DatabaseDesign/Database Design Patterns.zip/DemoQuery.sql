--get the 1st Monday of the month

--declare @getdate datetime = getdate()

SELECT *
FROM   Sales.SalesOrder
WHERE  utility.udf_nthWeekDay(1,'MON',year(OrderDate),
							month(OrderDate)) = OrderDate

--select datediff(millisecond,@getdate,getdate())
go
--declare @getdate datetime = getdate()


SELECT SalesOrder.*
FROM   Sales.SalesOrder
		 JOIN Utility.Calendar
			on SalesOrder.OrderDate = Calendar.DateValue
			   and Calendar.DayName = 'Monday'
			       and DayInMonthCount = 1			  
			   --and FederalHolidayName = 'Memorial Day' 
--select datediff(millisecond,@getdate,getdate())

