--The nth day of the month function can be retrieved from Michael Coles' blog here:
--http://sqlblog.com/blogs/michael_coles/archive/2010/02/25/calculating-holidays-in-sql.aspx

--The calendarId is an integer that represents the date in YYYYMMDD format. 
--it allows me to use this as a key, rather than the date value.
--it doesn't save space, but it doesn't have the time, which can be troublesome
--for using a calendar table. 

drop table utility.calendar
 go
create table utility.calendar
(
        calendarId int NOT NULL CONSTRAINT PKdate_dim PRIMARY KEY ,
        dateValue datetime NOT NULL CONSTRAINT AKdate_dim__dateValue UNIQUE ,        
        dayName varchar(10) NOT NULL,
        monthName varchar(10) NOT NULL,
        year varchar(60) NOT NULL,
        day tinyint NOT NULL,
        dayOfTheYear smallint NOT NULL,
        month smallint NOT NULL,
        quarter tinyint NOT NULL,
        weekendFlag bit not null, 
        dayInMonthCount tinyint not null,

        --start of fiscal year configurable in the load process, currently 
        --only supports fiscal months that match the calendar months.
        fiscalYear smallint NOT NULL,
        fiscalMonth tinyint NULL,
        fiscalQuarter tinyint NOT NULL, 

        --used to give relative positioning, such as the previous 10 months
        --which can be annoying due to month boundries
        relativeDayCount int NOT NULL,
        relativeWeekCount int NOT NULL,
        relativeMonthCount int NOT NULL,
        
        federalHolidayName varchar(40) NOT NULL,
        federalHolidayFlag bit NOT NULL
) 
go
;with digits (i) as(
        select 1 as i union all select 2 as i union all select 3 union all
        select 4 union all select 5 union all select 6 union all select 7 
        union all select 8 union all select 9 union all select 0)
,sequence (i) as (
        SELECT D1.i + (10*D2.i) + (100*D3.i) + (1000*D4.i) + (10000*D5.i)
        FROM digits AS D1 CROSS JOIN digits AS D2 CROSS JOIN digits AS D3 CROSS JOIN digits AS D4
        CROSS JOIN digits AS D5) 
,dates (newDateValue) as (
        select dateadd(day,i,'17530101') as newDateValue
        from sequence
)
insert utility.calendar
        (calendarId ,dateValue ,dayName
        ,monthName ,year ,day
        ,dayOfTheYear ,month ,quarter
        ,weekendFlag ,dayInMonthCount, fiscalYear ,fiscalMonth
        ,fiscalQuarter ,relativeDayCount,relativeWeekCount
        ,relativeMonthCount, federalHolidayName, federalHolidayFlag)
select 
        cast(convert(varchar(10),dates.newDateValue,112) as int) as calendarId,
        dates.newDateValue as dateValue,
        datename (dw,dates.newDateValue) as dayName,
        datename (mm,dates.newDateValue) as monthName,
        datename (yy,dates.newDateValue) as year,
        datepart(day,dates.newDateValue) as day,
        datepart(dy,dates.newDateValue) as dayOfTheYear,
        datepart(m,dates.newDateValue) as month,
        case
                when month ( dates.newDateValue) <= 3 then 1 
                when month ( dates.newDateValue) <= 6 then 2 
                when month ( dates.newDateValue) <= 9 then 3 
        else 4 end as quarter, 

        case when datename (dw,dates.newDateValue) in ('Saturday','Sunday') 
                then 1 
                else 0 
        end as weekendFlag, 
        ((datepart(day,dates.newDateValue) - 1)/ 7) + 1 as dayInMonthCount,

        ------------------------------------------------
        --the next three blocks assume a fiscal year starting in July. 
        --replace if your fiscal periods are different
        ------------------------------------------------
        case
                when month(dates.newDateValue) <= 6 
                then year(dates.newDateValue) 
                else year (dates.newDateValue) + 1 
        end as fiscalYear, 

        case 
                when month(dates.newDateValue) <= 6 
                then month(dates.newDateValue) + 6
                else month(dates.newDateValue) - 6 
         end as fiscalMonth, 

        case 
                when month(dates.newDateValue) <= 3 then 3
                when month(dates.newDateValue) <= 6 then 4 
                when month(dates.newDateValue) <= 9 then 1 
        else 2 end as fiscalQuarter, 

        ------------------------------------------------
        --end of fiscal quarter = july
        ------------------------------------------------ 

        --these values can be anything, as long as they provide contiguous values
        --on year and month boundries
        datediff(day,'17530101',dates.newDateValue) as full_day_count,
        datediff(week,'17530101',dates.newDateValue) as full_week_count, 
        datediff(month,'17530101',dates.newDateValue) as full_month_count,
        CASE 
			WHEN datepart(day,newDateValue) = 1 and datepart(month,newDateValue) = 1 then 'New Year''s Day'
			WHEN utility.udf_nthWeekDay(3,'MON',year(newDateValue),1) = newDateValue then 'Martin Luther King, Jr Birthdate'
			WHEN utility.udf_nthWeekDay(3,'MON',year(newDateValue),2) = newDateValue then 'President''s Day'
			WHEN utility.udf_lastWeekDay('MON',year(newDateValue),5) = newDateValue then 'Memorial Day'
			WHEN datepart(day,newDateValue) = 4 and datepart(month,newDateValue) = 7 then 'Independence Day'
			WHEN utility.udf_nthWeekDay(1,'MON',year(newDateValue),9) = newDateValue then 'Labor Day'
			WHEN utility.udf_nthWeekDay(2,'MON',year(newDateValue),10) = newDateValue then 'Columbus Day'
			WHEN datepart(day,newDateValue) = 11 and datepart(month,newDateValue) = 11 then 'Veteran''s Day'
			WHEN utility.udf_nthWeekDay(4,'THU',year(newDateValue),11) = newDateValue then 'Thanksgiving Day'
			WHEN datepart(day,newDateValue) = 25 and datepart(month,newDateValue) = 12 then 'Christmas Day'
			ELSE '' END AS federalHolidayName ,
        CASE 
			WHEN datepart(day,newDateValue) = 1 and datepart(month,newDateValue) = 1 then 1
			WHEN utility.udf_nthWeekDay(3,'MON',year(newDateValue),1) = newDateValue then 1
			WHEN utility.udf_nthWeekDay(3,'MON',year(newDateValue),2) = newDateValue then 1
			WHEN utility.udf_lastWeekDay('MON',year(newDateValue),5) = newDateValue then 1
			WHEN datepart(day,newDateValue) = 4 and datepart(month,newDateValue) = 7 then 1
			WHEN utility.udf_nthWeekDay(1,'MON',year(newDateValue),9) = newDateValue then 1
			WHEN utility.udf_nthWeekDay(2,'MON',year(newDateValue),10) = newDateValue then 1
			WHEN datepart(day,newDateValue) = 11 and datepart(month,newDateValue) = 11 then 1
			WHEN utility.udf_nthWeekDay(4,'THU',year(newDateValue),11) = newDateValue then 1
			WHEN datepart(day,newDateValue) = 25 and datepart(month,newDateValue) = 12 then 1

			ELSE '' END AS federalHolidayFlag --then bit
from    dates
where  dates.newDateValue between '20000101' and '20150101' --set the date range
order  by datevalue 
go
select FederalHolidayName,*
from  utility.calendar
--where federalHolidayName = 'Memorial Day'
where FederalHolidayFlag = 1
  and dateValue between '20100101' and '20101231'


--The next block can be substituted for the previous text used to set the fiscal period information if you are not using a July fiscal period..

/* 
------------------------------------------------
--the next three blocks can be used for a fiscal year starting in April. 
------------------------------------------------
        case 
                when month(dates.newDateValue) <= 3 
                then year(dates.newDateValue) 
                else year(dates.newDateValue) + 1 
         end as fiscalYear, 

        case 
                when month(dates.newDateValue) <= 3 
                then month(dates.newDateValue) + 9
                else month(dates.newDateValue) - 3 
         end as fiscalMonth, 

        case 
                when month(dates.newDateValue) <= 3 then 4
                when month(dates.newDateValue) <= 6 then 1 
                when month(dates.newDateValue) <= 9 then 2 
        else 3 end as fiscalQuarter, 

        ------------------------------------------------
        --end of fiscal quarter = april
        ------------------------------------------------ 
*/

