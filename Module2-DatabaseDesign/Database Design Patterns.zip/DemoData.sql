CREATE SCHEMA Sales
go
SELECT cast(OrderDate AS DATE) AS OrderDate, SalesOrderNumber, 
		SalesOrderHeader.AccountNumber
		,SalesOrderHeader.CustomerID
INTO   Sales.SalesOrder
FROM   AdventureWorks.Sales.SalesOrderHeader