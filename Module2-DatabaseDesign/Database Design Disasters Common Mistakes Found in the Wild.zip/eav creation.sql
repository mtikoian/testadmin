
CREATE SCHEMA eav
GO

/* 
 * TABLE: Attribute 
 */

CREATE TABLE eav.Person_Attribute(
    Attribute_Id         int             IDENTITY(1,1),
    Person_ID            int             NOT NULL,
    Attribute_Type_ID    int             NOT NULL,
    Value                varchar(max)    NULL,
    CONSTRAINT PK9 PRIMARY KEY CLUSTERED (Attribute_Id)
)
go



IF OBJECT_ID('Attribute') IS NOT NULL
    PRINT '<<< CREATED TABLE Attribute >>>'
ELSE
    PRINT '<<< FAILED CREATING TABLE Attribute >>>'
go

/* 
 * TABLE: Attribute_Type 
 */

CREATE TABLE eav.Attribute_Type(
    Attribute_Type_ID    int            IDENTITY(1,1),
    Attribute_Name       varchar(50)    NULL,
    CONSTRAINT PK10 PRIMARY KEY CLUSTERED (Attribute_Type_ID)
)
go



IF OBJECT_ID('Attribute_Type') IS NOT NULL
    PRINT '<<< CREATED TABLE Attribute_Type >>>'
ELSE
    PRINT '<<< FAILED CREATING TABLE Attribute_Type >>>'
go

/* 
 * TABLE: Entity 
 */

CREATE TABLE eav.[Person](
    Person_ID    int    IDENTITY(1,1),
    Name         VARCHAR(50) NOT NULL
    CONSTRAINT PK8 PRIMARY KEY CLUSTERED (Person_ID)
)
go


IF OBJECT_ID('Entity') IS NOT NULL
    PRINT '<<< CREATED TABLE Entity >>>'
ELSE
    PRINT '<<< FAILED CREATING TABLE Entity >>>'
go



ALTER TABLE eav.Person_Attribute ADD CONSTRAINT FK_Person_Attribute__Attribute_Type_ID 
    FOREIGN KEY (Attribute_Type_ID)
    REFERENCES eav.Attribute_Type(Attribute_Type_ID)
go

ALTER TABLE eav.Person_Attribute ADD CONSTRAINT FK_Person_Attribute__Person_ID 
    FOREIGN KEY (Person_ID)
    REFERENCES eav.[Person](Person_ID)
go


INSERT INTO eav.Attribute_Type (Attribute_Name) VALUES ('Birthdate')
INSERT INTO eav.Attribute_Type (Attribute_Name) VALUES ('Age')
INSERT INTO eav.Attribute_Type (Attribute_Name) VALUES ('Phone_Number')
GO

INSERT INTO eav.[Person]  (Name) VALUES ('Cecil Phillip')
INSERT INTO eav.[Person]  (Name) VALUES ('Dave Nicholas')
GO


INSERT INTO eav.Person_Attribute (Attribute_Type_ID, Person_ID, Value) VALUES (1, 1, '2/9/1982')
INSERT INTO eav.Person_Attribute (Attribute_Type_ID, Person_ID, Value) VALUES (2, 1, '30')
INSERT INTO eav.Person_Attribute (Attribute_Type_ID, Person_ID, Value) VALUES (3, 1, '305-555-9607')
GO
INSERT INTO eav.Person_Attribute (Attribute_Type_ID, Person_ID, Value) VALUES (1, 2, '9/2/1983')
INSERT INTO eav.Person_Attribute (Attribute_Type_ID, Person_ID, Value) VALUES (2, 2, '29')
GO
