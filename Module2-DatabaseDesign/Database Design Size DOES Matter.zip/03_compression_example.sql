--row/page compression example
USE [AdventureWorks2012]
GO

/*
CREATE TABLE [dbo].[TestCompression](
	[m_id] [int]  NULL,
	[text] [nvarchar](3000) NULL
) ON [PRIMARY]

INSERT INTO [dbo].[TestCompression] 
	SELECT message_id, text from sys.messages

*/

SET STATISTICS IO ON
SELECT m_id, text
FROM dbo.TestCompression
SET STATISTICS IO OFF

--Turn on row compression 
USE [AdventureWorks2012] 
ALTER TABLE dbo.TestCompression REBUILD PARTITION = ALL 
WITH  
(DATA_COMPRESSION = ROW) 
GO 

SET STATISTICS IO ON
SELECT m_id, text
FROM dbo.TestCompression
SET STATISTICS IO OFF

--Turn on page compression 
USE [AdventureWorks2012] 
ALTER TABLE dbo.TestCompression REBUILD PARTITION = ALL 
WITH  
(DATA_COMPRESSION = PAGE) 
GO 

SET STATISTICS IO ON
SELECT m_id, text
FROM dbo.TestCompression
SET STATISTICS IO OFF


--Turn off compression 
USE [AdventureWorks2012] 
ALTER TABLE dbo.TestCompression REBUILD PARTITION = ALL 
WITH  
(DATA_COMPRESSION = NONE) 
GO 

SET STATISTICS IO ON
SELECT m_id, text
FROM dbo.TestCompression
SET STATISTICS IO OFF
