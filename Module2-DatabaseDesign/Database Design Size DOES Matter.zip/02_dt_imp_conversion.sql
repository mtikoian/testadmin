USE [AdventureWorks2012]
GO
SET STATISTICS IO ON
GO

/*
	[NationalIDNumber] [nvarchar](15) NOT NULL,
*/

SELECT NationalIDNumber, LoginID
FROM HumanResources.Employee
WHERE NationalIDNumber = 112457891
GO

SELECT NationalIDNumber, LoginID
FROM HumanResources.Employee
WHERE NationalIDNumber = '112457891'
GO