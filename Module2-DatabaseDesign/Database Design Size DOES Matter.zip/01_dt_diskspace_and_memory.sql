/* initialize, create a blank database*/
USE [master]
GO

IF DB_ID('testdt') IS NOT NULL
	DROP DATABASE [testdt]
GO

CREATE DATABASE [testdt]
GO

USE [testdt]
GO

/*create table to store smalldatetime value*/
IF OBJECT_ID('[dbo].[smd]') IS NOT NULL
   DROP TABLE [dbo].[smd]
GO

CREATE TABLE [dbo].[smd](
	[d] [smalldatetime] NULL,
	[v] [bigint] NULL
) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [cix_d] ON [dbo].[smd]
(
	[d] ASC
)
GO

SET NOCOUNT ON
DECLARE @i int = 1, @date SMALLDATETIME
SELECT @date = GETDATE()
WHILE @i < 20000
BEGIN
	SET @date = DATEADD(dd, 1, @date)
	--SELECT @i, @date
	INSERT INTO dbo.[smd] (d, v) VALUES (@date, @i)
	SET @i = @i + 1
END

/*what is the LIO for this query? -- 55 logical reads*/
SET STATISTICS IO ON
SELECT d, v
FROM dbo.[smd]	
WHERE d < '2034-07-24 14:00:00'
SET STATISTICS IO OFF

/*what is the size of the database?
reserved	data	index_size	unused
2944 KB		1232 KB	1464 KB		248 KB

*/
EXEC sp_spaceused
GO

/*ok, let's do this again, but with datetime*/
/* initialize, create a blank database*/
USE [master]
GO

IF DB_ID('testdt') IS NOT NULL
	DROP DATABASE [testdt]
GO

CREATE DATABASE [testdt]
GO

USE [testdt]
GO

/*create table to store datetime value*/
IF OBJECT_ID('[dbo].[dt]') IS NOT NULL
   DROP TABLE [dbo].[dt]
GO

CREATE TABLE [dbo].[dt](
	[d] [datetime] NULL,
	[v] [bigint] NULL
) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [cix_d] ON [dbo].[dt]
(
	[d] ASC
)
GO

SET NOCOUNT ON
DECLARE @i int = 1, @date DATETIME
SELECT @date = GETDATE()
WHILE @i < 20000
BEGIN
	SET @date = DATEADD(dd, 1, @date)
	--SELECT @i, @date
	INSERT INTO dbo.[dt] (d, v) VALUES (@date, @i)
	SET @i = @i + 1
END

/*what is the LIO for this query? -- 65 logical reads*/
SET STATISTICS IO ON
SELECT d, v
FROM dbo.[dt]	
WHERE d < '2034-07-24 14:00:00'
SET STATISTICS IO OFF

/*what is the size of the database?
it was:

reserved	data	index_size	unused
2944 KB		1232 KB	1464 KB		248 KB

and now:
reserved	data	index_size	unused
3048 KB		1264 KB	1544 KB		240 KB
*/
EXEC sp_spaceused
GO







--BACKUP DATABASE [testdt] TO  DISK = N'C:\test1.bak' 
--WITH INIT
--GO





