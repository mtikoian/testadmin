USE AdventureWorks2012;
GO

SET STATISTICS IO ON
SELECT ProductID 
FROM Sales.SalesOrderDetail 
WHERE ProductID = 870
GO

-- Looks for an existing filtered index named "FIDX_SalesOrderDetail_ProductID"
-- and deletes it from the table Sales.SalesOrderDetail if found. 
IF EXISTS (SELECT name FROM sys.indexes
    WHERE name = N'FIDX_SalesOrderDetail_ProductID'
    AND object_id = OBJECT_ID (N'Sales.SalesOrderDetail'))
DROP INDEX FIDX_SalesOrderDetail_ProductID
    ON Sales.SalesOrderDetail
GO

CREATE INDEX FIDX_SalesOrderDetail_ProductID 
ON Sales.SalesOrderDetail (ProductID) 
WHERE ProductID = 870


SET STATISTICS IO ON
SELECT ProductID 
FROM Sales.SalesOrderDetail 
WHERE ProductID = 870


DECLARE @ProductID INT 
SET @ProductID = 870  
SELECT ProductID 
FROM Sales.SalesOrderDetail 
WHERE ProductID = @ProductID

DECLARE @SQL NVARCHAR(MAX)
SET @SQL = N'SELECT ProductID 
FROM Sales.SalesOrderDetail 
WHERE ProductID = @ProductID'
execute sp_executesql @SQL, N'@ProductID INT', @ProductID = 870
GO

DECLARE @SQL NVARCHAR(MAX)
SET @SQL = N'SELECT ProductID 
FROM Sales.SalesOrderDetail  WITH(INDEX=FIDX_SAlesOrderDetail_ProductID)
WHERE ProductID = @ProductID'
execute sp_executesql @SQL, N'@ProductID INT', @ProductID = 870
GO

