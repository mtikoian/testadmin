use AdventureWorks2012;
go 

select msrepl_tran_version, * from AdventureWorks2012.Sales.SpecialOffer
go

select msrepl_tran_version, * from AdventureWorks2012Replica.Sales.SpecialOffer
go



update AdventureWorks2012.Sales.SpecialOffer
    set Description = 'I was Updated in AdventureWorks2012'
where SpecialOfferId = 1;




update AdventureWorks2012Replica.Sales.SpecialOffer
    set Description = 'I was Updated in AdventureWorks2012Replica'
where SpecialOfferId = 1;
go

-- select * from AdventureWorks2012.Sales.[conflict_SpecialOffer_Sales.SpecialOffer];
