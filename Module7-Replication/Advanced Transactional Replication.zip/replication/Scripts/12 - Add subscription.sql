use AdventureWorks2012;
go


sp_addsubscription
    @publication = 'AdventureWorks2012', 
    @article = 'all', 
    @subscriber = 'ebdbalt002\jwf', 
    @destination_db = 'AdventureWorks2012Replica', 
    @subscription_type = 'Push', 
    @sync_type = 'automatic', 
    @status = 'subscribed',            -- This subscription will need to be initialized.
    @update_mode = 'read only', 
    @subscriber_type = 0;



