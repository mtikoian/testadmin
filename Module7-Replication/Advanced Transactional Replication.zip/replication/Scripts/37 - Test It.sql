use AdventureWorks2012;
go

select * from AdventureWorks2012.Sales.OnlineOrderSourceCode;

select * from AdventureWorks2012Replica.Sales.OnlineOrderSourceCode;




select top 10 OnlineOrderSourceCodeId, * from AdventureWorks2012.Sales.SalesOrderHeader;

select top 10 OnlineOrderSourceCodeId, * from AdventureWorks2012Replica.Sales.SalesOrderHeader;

