use master;
go


if  exists (select name from sys.databases where name = 'AdventureWorks2012Replica')
begin
    alter database AdventureWorks2012Replica set  single_user with rollback immediate;

    drop database AdventureWorks2012Replica;
end
go


-- restore filelistonly from disk = 'c:\SQLData\jwf\backup\AdventureWorks2012Replica.bak';

restore database AdventureWorks2012Replica
    from disk = 'c:\SQLData\jwf\backup\AdventureWorks2012Replica.bak'
    with
        move 'AdventureWorks2012_Data' to 'c:\SQLData\jwf\Data\AdventureWorks2012Replica_Data.mdf',
        move 'Trans2005Q3' to 'c:\SQLData\jwf\data\TransReplica2005Q3.ndf',
        move 'Trans2005Q4' to 'c:\SQLData\jwf\data\TransReplica2005Q4.ndf',
        move 'Trans2006Q1' to 'c:\SQLData\jwf\data\TransReplica2006Q1.ndf',
        move 'Trans2006Q2' to 'c:\SQLData\jwf\data\TransReplica2006Q2.ndf',
        move 'Trans2006Q3' to 'c:\SQLData\jwf\data\TransReplica2006Q3.ndf',
        move 'Trans2006Q4' to 'c:\SQLData\jwf\data\TransReplica2006Q4.ndf',
        move 'Trans2007Q1' to 'c:\SQLData\jwf\data\TransReplica2007Q1.ndf',
        move 'Trans2007Q2' to 'c:\SQLData\jwf\data\TransReplica2007Q2.ndf',
        move 'Trans2007Q3' to 'c:\SQLData\jwf\data\TransReplica2007Q3.ndf',
        move 'Trans2007Q4' to 'c:\SQLData\jwf\data\TransReplica2007Q4.ndf',
        move 'Trans2008Q1' to 'c:\SQLData\jwf\data\TransReplica2008Q1.ndf',
        move 'Trans2008Q2' to 'c:\SQLData\jwf\data\TransReplica2008Q2.ndf',
        move 'Trans2008Q3' to 'c:\SQLData\jwf\data\TransReplica2008Q3.ndf',
        move 'TransFuture' to 'c:\SQLData\jwf\data\TransReplicaFuture.ndf',
        move 'AdventureWorks2012_Log' to 'c:\SQLData\jwf\TransactionLog\AdventureWorks2012Replica_Log.ldf';
go

use AdventureWorks2012Replica;
go

sp_changedbowner 'sa';                           -- Very important in replication.  Make sure the DB owner is sa.
go                                               -- http://social.msdn.microsoft.com/Forums/en-US/sqlreplication/thread/b662bab0-ece9-452c-9089-e67b6801b7ff


sp_MSforeachtable @command1="alter table ? disable trigger all";  -- http://blogs.msdn.com/b/repltalk/archive/2010/12/06/how-to-initialize-a-transactional-subscription-from-a-backup-with-multiple-backup-files.aspx
go

   
         