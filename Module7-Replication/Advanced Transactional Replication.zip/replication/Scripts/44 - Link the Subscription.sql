use AdventureWorks2012Replica;
go

-- The below covers the price of admission.  :)
-- You do not need to execute sp_subscription_cleanup the first time you are setting up the subscription.  BUT - if you take down the publication 
-- for what ever reason (SAN reorg, SQL Upgrade) and want to reestablish it - you will not be able to until you run this.  And it is buried DEEP in books 
-- online.  Guess how I discovered this.  :(
-- Since it does not hurt to run it the first time - I include it here:

exec sp_subscription_cleanup 
    @publisher = 'ebdbalt002\jwf',
    @publisher_db =  'AdventureWorks2012',
    @publication = 'SpecialOffer';
go

exec sp_link_publication 
     @publisher = 'ebdbalt002\jwf', 
     @publisher_db = 'AdventureWorks2012', 
     @publication = 'AdventureWorks2012', 
     @distributor = 'ebdbalt002\jwf', 
     @security_mode = 2;
go

