use master;
go

--restore filelistonly from disk = 'c:\SQLData\jwf\backup\AdventureWorks2012.bak' 


if  exists (select name from sys.databases where name = 'AdventureWorks2012')
begin
    alter database AdventureWorks2012 set  single_user with rollback immediate;

    drop database AdventureWorks2012;
end
go

if  exists (select name from sys.databases where name = 'AdventureWorks2012Replica')
begin
    alter database AdventureWorks2012Replica set  single_user with rollback immediate;

    drop database AdventureWorks2012Replica;
end
go

restore database AdventureWorks2012
    from disk = 'c:\SQLData\jwf\backup\AdventureWorks2012.bak' 
    with move 'AdventureWorks2012_Data' to 'c:\SQLData\jwf\Data\AdventureWorks2012_Data.mdf',
         move 'AdventureWorks2012_Log' to 'c:\SQLData\jwf\TransactionLog\AdventureWorks2012_Log.ldf';
go         
         
use AdventureWorks2012;
go

sp_changedbowner 'sa';                           -- Very important in replication.  Make sure the DB owner is sa.
go                                               -- http://social.msdn.microsoft.com/Forums/en-US/sqlreplication/thread/b662bab0-ece9-452c-9089-e67b6801b7ff

     
         