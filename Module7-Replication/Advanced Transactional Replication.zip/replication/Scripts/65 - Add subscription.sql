use AdventureWorks2012;
go


sp_addsubscription
    @publication = 'AdventureWorks2012', 
    @article = 'all', 
    @subscriber = 'ebdbalt002\jwf', 
    @destination_db = 'AdventureWorks2012Replica', 
    ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    @sync_type = 'initialize with backup', 
    ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    @status = 'active',
    @update_mode = 'read only', 
    @offloadagent = 0, 
    @dts_package_location = 'distributor',
    @backupdevicetype = 'disk',
    @backupdevicename = 'c:\SQLData\jwf\backup\AdventureWorks2012Replica.bak';




