use master;
go

backup database AdventureWorks2012
    to disk = 'c:\SQLData\jwf\backup\AdventureWorks2012Replica.bak'
    with format, compression;
    
     
