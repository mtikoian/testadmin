use AdventureWorks2012;
go 

select * from HumanResources.Department;
go

select * from AdventureWorks2012Replica.HumanResources.Department;
go


update AdventureWorks2012.HumanResources.Department
    set IncludeInLayoffs = 0 
where Name = 'Human Resources';          -- Those S.O.B.s

