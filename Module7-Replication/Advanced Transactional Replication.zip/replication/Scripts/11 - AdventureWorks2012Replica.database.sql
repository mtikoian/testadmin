use master;
go


if  exists (select name from sys.databases where name = 'AdventureWorks2012Replica')
begin
    alter database AdventureWorks2012Replica set  single_user with rollback immediate;

    drop database AdventureWorks2012Replica;
end
go

create database AdventureWorks2012Replica on
    primary                 (name= 'AdventureWorks2012Replica', filename = 'c:\SQLData\jwf\data\AdventureWorks2012Replica.mdf', size = 200MB, maxsize = unlimited, filegrowth = 5MB), 
    filegroup Trans2005Q3  (name= 'Trans2005Q3', filename = 'c:\SQLData\jwf\data\Trans2005Q3r.ndf', size = 1mb,  maxsize = unlimited, filegrowth = 500kb), 
    filegroup Trans2005Q4  (name= 'Trans2005Q4', filename = 'c:\SQLData\jwf\data\Trans2005Q4r.ndf', size = 1mb,  maxsize = unlimited, filegrowth = 500kb), 
    filegroup Trans2006Q1  (name= 'Trans2006Q1', filename = 'c:\SQLData\jwf\data\Trans2006Q1r.ndf', size = 1mb,  maxsize = unlimited, filegrowth = 500kb), 
    filegroup Trans2006Q2  (name= 'Trans2006Q2', filename = 'c:\SQLData\jwf\data\Trans2006Q2r.ndf', size = 1mb,  maxsize = unlimited, filegrowth = 500kb), 
    filegroup Trans2006Q3  (name= 'Trans2006Q3', filename = 'c:\SQLData\jwf\data\Trans2006Q3r.ndf', size = 2mb,  maxsize = unlimited, filegrowth = 500kb), 
    filegroup Trans2006Q4  (name= 'Trans2006Q4', filename = 'c:\SQLData\jwf\data\Trans2006Q4r.ndf', size = 2mb,  maxsize = unlimited, filegrowth = 500kb), 
    filegroup Trans2007Q1  (name= 'Trans2007Q1', filename = 'c:\SQLData\jwf\data\Trans2007Q1r.ndf', size = 2mb,  maxsize = unlimited, filegrowth = 500kb), 
    filegroup Trans2007Q2  (name= 'Trans2007Q2', filename = 'c:\SQLData\jwf\data\Trans2007Q2r.ndf', size = 2mb,  maxsize = unlimited, filegrowth = 500kb), 
    filegroup Trans2007Q3  (name= 'Trans2007Q3', filename = 'c:\SQLData\jwf\data\Trans2007Q3r.ndf', size = 4mb,  maxsize = unlimited, filegrowth = 500kb), 
    filegroup Trans2007Q4  (name= 'Trans2007Q4', filename = 'c:\SQLData\jwf\data\Trans2007Q4r.ndf', size = 5mb,  maxsize = unlimited, filegrowth = 500kb), 
    filegroup Trans2008Q1  (name= 'Trans2008Q1', filename = 'c:\SQLData\jwf\data\Trans2008Q1r.ndf', size = 4mb,  maxsize = unlimited, filegrowth = 500kb), 
    filegroup Trans2008Q2  (name= 'Trans2080Q2', filename = 'c:\SQLData\jwf\data\Trans2008Q2r.ndf', size = 5mb,  maxsize = unlimited, filegrowth = 500kb), 
    filegroup Trans2008Q3  (name= 'Trans2008Q3', filename = 'c:\SQLData\jwf\data\Trans2008Q3r.ndf', size = 10mb,  maxsize = unlimited, filegrowth = 500kb), 
    filegroup TransFuture  (name= 'TransFuture', filename = 'c:\SQLData\jwf\data\TransFuturer.ndf', size = 4mb,  maxsize = unlimited, filegrowth = 500kb) 
    log on                  (name= 'AdventureWorks2012ReplicaLog', filename = 'c:\SQLData\jwf\TransactionLog\Translog.ldf',size = 5mb, maxsize = unlimited, filegrowth = 5mb);
go

exec dbo.sp_dbcmptlevel @dbname='AdventureWorks2012Replica', @new_cmptlevel=110;
go



alter database AdventureWorks2012Replica set ansi_null_default off; 
go
alter database AdventureWorks2012Replica set ansi_nulls off; 
go
alter database AdventureWorks2012Replica set ansi_padding off; 
go
alter database AdventureWorks2012Replica set ansi_warnings off; 
go
alter database AdventureWorks2012Replica set arithabort off; 
go
alter database AdventureWorks2012Replica set auto_close off; 
go
alter database AdventureWorks2012Replica set auto_create_statistics on; 
go
alter database AdventureWorks2012Replica set auto_shrink off; 
go
alter database AdventureWorks2012Replica set auto_update_statistics on; 
go
alter database AdventureWorks2012Replica set cursor_close_on_commit off; 
go
alter database AdventureWorks2012Replica set cursor_default  global; 
go
alter database AdventureWorks2012Replica set concat_null_yields_null off; 
go
alter database AdventureWorks2012Replica set numeric_roundabort off; 
go
alter database AdventureWorks2012Replica set quoted_identifier off; 
go
alter database AdventureWorks2012Replica set recursive_triggers off; 
go
alter database AdventureWorks2012Replica set  enable_broker; 
go
alter database AdventureWorks2012Replica set auto_update_statistics_async off; 
go
alter database AdventureWorks2012Replica set date_correlation_optimization off; 
go
alter database AdventureWorks2012Replica set trustworthy off; 
go
alter database AdventureWorks2012Replica set allow_snapshot_isolation off; 
go
alter database AdventureWorks2012Replica set parameterization simple; 
go
alter database AdventureWorks2012Replica set  read_write; 
go
alter database AdventureWorks2012Replica set recovery simple; 
go
alter database AdventureWorks2012Replica set  multi_user; 
go
alter database AdventureWorks2012Replica set page_verify checksum;

alter database AdventureWorks2012Replica set db_chaining off;
 
---------------------------------------------------------------------------------------------------------------------------------------------------------------

use AdventureWorks2012Replica;
go


if  exists (select * from sys.partition_schemes where name = 'psQuarterly')
    drop partition scheme psQuarterly;
go

if  exists (select * from sys.partition_functions where name = 'pfQuarterly')
     drop partition function pfQuarterly;
go


-- Note:  One less entry in the function relative to the scheme.  The scheme maps the partitions.
-- The function defines the boarders between the partitions.

create partition function pfQuarterly(datetime) as range left for values 
(
                                                          '2005-09-30 23:59:59.997', '2005-12-31 23:59:59.997', 
    '2006-03-31 23:59:59.997', '2006-06-30 23:59:59.997', '2006-09-30 23:59:59.997', '2006-12-31 23:59:59.997', 
    '2007-03-31 23:59:59.997', '2007-06-30 23:59:59.997', '2007-09-30 23:59:59.997', '2007-12-31 23:59:59.997', 
    '2008-03-31 23:59:59.997', '2008-06-30 23:59:59.997', '2008-09-30 23:59:59.997' 
);
go

create partition scheme psQuarterly as partition pfQuarterly to 
(
                              Trans2005Q3, Trans2005Q4,
    Trans2006Q1, Trans2006Q2, Trans2006Q3, Trans2006Q4, 
    Trans2007Q1, Trans2007Q2, Trans2007Q3, Trans2007Q4,
    Trans2008Q1, Trans2008Q2, Trans2008Q3, TransFuture  --<<-- The last entry - rage left - has no corresponding entry in the function
);
go



-- Very Important - Create the schemas you will need.

create schema HumanResources authorization dbo;
go

create schema Person authorization dbo;
go

create schema Production authorization dbo;
go

create schema Purchasing authorization dbo;
go

create schema Sales authorization dbo;
go


-- And any functions as well.....


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



CREATE FUNCTION [dbo].[ufnLeadingZeros](
    @Value int
) 
RETURNS varchar(8) 
WITH SCHEMABINDING 
AS 
BEGIN
    DECLARE @ReturnValue varchar(8);

    SET @ReturnValue = CONVERT(varchar(8), @Value);
    SET @ReturnValue = REPLICATE('0', 8 - DATALENGTH(@ReturnValue)) + @ReturnValue;

    RETURN (@ReturnValue);
END;

GO






CREATE FUNCTION [dbo].[ufnGetAccountingEndDate]()
RETURNS [datetime] 
AS 
BEGIN
    RETURN DATEADD(millisecond, -2, CONVERT(datetime, '20040701', 112));
END;

GO




CREATE FUNCTION [dbo].[ufnGetAccountingStartDate]()
RETURNS [datetime] 
AS 
BEGIN
    RETURN CONVERT(datetime, '20030701', 112);
END;

GO




CREATE FUNCTION [dbo].[ufnGetDocumentStatusText](@Status [tinyint])
RETURNS [nvarchar](16) 
AS 
-- Returns the sales order status text representation for the status value.
BEGIN
    DECLARE @ret [nvarchar](16);

    SET @ret = 
        CASE @Status
            WHEN 1 THEN N'Pending approval'
            WHEN 2 THEN N'Approved'
            WHEN 3 THEN N'Obsolete'
            ELSE N'** Invalid **'
        END;
    
    RETURN @ret
END;

GO












