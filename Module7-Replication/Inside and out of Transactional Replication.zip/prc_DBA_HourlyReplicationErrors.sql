USE DBOPS
GO
IF (OBJECT_ID('dbo.prc_DBA_HourlyReplicationErrors') IS NULL)
BEGIN
	EXEC('create procedure dbo.prc_DBA_HourlyReplicationErrors  as raiserror(''Empty Stored Procedure!!'', 16, 1) with seterror')
	IF (@@error = 0)
		PRINT 'Successfully created empty stored procedure dbo.prc_DBA_HourlyReplicationErrors.'
	ELSE
	BEGIN
		PRINT 'FAILED to create stored procedure dbo.prc_DBA_HourlyReplicationErrors.'
	END
END
GO

PRINT 'Altering Procedure: dbo.prc_DBA_HourlyReplicationErrors'
GO
/*************************************************************************************************
**
**  File: prc_DBA_HourlyReplicationErrors
**
**	Desc: Find latest replication errors and send email.
**  
**
**	Created by: Chuck Lathrope 1-2-2010
**  11/1/2010	Chuck Lathrope	Added more error tables to capture non-errors, but true issues.
**  11/23/2010  Chuck Lathrope  Bug fix for sections that have 0 rows becomes a NULL in email.
*************************************************************************************************/

ALTER PROCEDURE dbo.prc_DBA_HourlyReplicationErrors 
	@NotificationEmailAddress varchar(100) = 'AlertDBA@yourdomain.com'
AS
BEGIN

SET NOCOUNT ON;

--Put this as a job step on your distributor.
DECLARE @tableHTML  NVARCHAR(MAX), @subjectMsg varchar(150), @ErrorText varchar(max), @BadJobStatus varchar(max),
	@orphanedErrors varchar(max), @PushedPublications varchar(max)
    
select @subjectMsg = 'Hourly Replication Errors Reported on ' + convert(varchar(25),getdate())  + ' by server  ' + @@servername 

SET @ErrorText =  
	N'<HTML><H2>' + @subjectMsg + '</H2>' + 
    N'<table border="1" cellpadding="0" cellspacing="2">' +      
    N'<th>PublisherDB-Subscriber</th><th>subscriber_db</th><th>StatusDesc</th><th>LastSynchronized</th><th>Comments</th><th>Query to get more info</th></tr>' + 
CAST ( ( 
		--See all errors from today in table form:
		select td = replace(left(mda.name,len(mda.name)-CHARINDEX('-',REVERSE(name),1)),'VENOMDB1-',''), '',
			td = mda.subscriber_db,  '',
			td = CASE 
			 WHEN mdh.runstatus =  '1' THEN 'Start'
			 WHEN mdh.runstatus =  '2' THEN 'Succeed/Stopped'
			 WHEN mdh.runstatus =  '3' THEN 'InProgress'
			 WHEN mdh.runstatus =  '4' THEN 'Idle'
			 WHEN mdh.runstatus =  '5' THEN 'Retry'
			 WHEN mdh.runstatus =  '6' THEN 'Failure'
			END, '',
			td = mdh.time, '',
			td = mdh.comments, '',
			td = 'select * from distribution.dbo.msrepl_errors (nolock) where id = ' + CAST(mdh.error_id as varchar(8))
		FROM distribution.dbo.MSdistribution_agents mda (nolock)
		JOIN distribution.dbo.MSdistribution_history mdh (nolock) ON mdh.agent_id = mda.id
		JOIN (Select agent_id, max(error_id) as MaxError_id FROM distribution.dbo.MSdistribution_history mdh (nolock)
			Where start_time > DateADD(hh,-1,getdate())
			group by agent_id
		) as MaxErrorID on MaxErrorID.agent_id = mda.id and MaxErrorID.MaxError_id = mdh.error_id
		Where start_time > DateADD(hh,-1,getdate())
		and error_id <> 0
		FOR XML PATH('tr')
) AS NVARCHAR(MAX) ) +  N'</table><br />'  

-- Add another table that shows all the recent errors that can contain errors from orphaned agent jobs.
Set @orphanedErrors = N'<table border="0" cellpadding="0" cellspacing="2">' +        
    N'<th><H3>Last Hours Logged Replication Errors</H3></th></tr>' + 
CAST ( ( 
  select distinct cast(error_text as varchar(200)) as td
		from distribution.dbo.msrepl_errors (nolock)
		Where time > DateADD(hh,-1,getdate())
		and source_type_id <> 1 --Not very helpful typically. Does show path.
		FOR XML PATH('tr')
) AS NVARCHAR(MAX) ) +  N'</table><br />' 
   

-- Add another table that shows all the jobs that in a bad job state.
Set @BadJobStatus = N'<table border="0" cellpadding="0" cellspacing="2">' +        
	N'<th>Agent Name</th><th>History Comment</th><th>Job Status</th><th>Time Recorded</th></tr>' +
CAST ( (   
  select td = a.Name,'', 
  td = Comments, '',
  td = CASE   
    WHEN runstatus =  '1' THEN 'Start'  
    WHEN runstatus =  '2' THEN 'Succeed/Stopped'  
    WHEN runstatus =  '3' THEN 'InProgress'  
    WHEN runstatus =  '4' THEN 'Idle'  
    WHEN runstatus =  '5' THEN 'Retry'  
    WHEN runstatus =  '6' THEN 'Failure'  
   END, '',
   td = [time] 
		From distribution.dbo.MSdistribution_agents a
		join distribution.dbo.MSdistribution_history h on h.agent_id=a.id
		join   (select max(time) MaxTimeValue, name
				From distribution.dbo.MSdistribution_agents a
				join distribution.dbo.MSdistribution_history h on h.agent_id=a.id
				where runstatus NOT IN (3,4)
				and time > DateADD(hh,-1,getdate())
				group by name) x on x.MaxTimeValue = h.Time and x.name = a.name
		where runstatus NOT IN (1,3,4)
		FOR XML PATH('tr')
) AS NVARCHAR(MAX) ) + N'</table><br />'


--Find push publications
Set @PushedPublications = N'<table border="0" cellpadding="0" cellspacing="2">' +        
	N'<th>Agent Name</th><th>Subscription Type (Should only be Pull)</th><th>Date Created</th></tr>' +
CAST ( (  
		Select 	mda.name, 
			CASE 
				WHEN mda.subscription_type =  '0' THEN 'Push'
				WHEN mda.subscription_type =  '2' THEN 'Anonymous'
			END ,
			creation_date
		FROM distribution.dbo.MSdistribution_agents mda
		WHERE mda.subscription_type <> '1'
		FOR XML PATH('tr')
) AS NVARCHAR(MAX) ) + N'</table></HTML>'

Set @tableHTML = ISNULL(@ErrorText,'') + ISNULL(@BadJobStatus,'') + ISNULL(@orphanedErrors,'') + ISNULL(@PushedPublications,'')


If @tableHTML is not null and @tableHTML <> ''
	exec dbops.dbo.prc_internalsendmail 
	@HighPriority=1, @address=@NotificationEmailAddress, 
	@subject=@subjectMsg, @body=@tableHTML, @HTML=1


END --Proc creation.

GO
