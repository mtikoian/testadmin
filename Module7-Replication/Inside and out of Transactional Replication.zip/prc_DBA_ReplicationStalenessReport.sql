USE DBOPS
GO
IF (OBJECT_ID('dbo.prc_DBA_ReplicationStalenessReport') IS NULL)
BEGIN
	EXEC('create procedure dbo.prc_DBA_ReplicationStalenessReport  as raiserror(''Empty Stored Procedure!!'', 16, 1) with seterror')
	IF (@@error = 0)
		PRINT 'Successfully created empty stored procedure dbo.prc_DBA_ReplicationStalenessReport.'
	ELSE
	BEGIN
		PRINT 'FAILED to create stored procedure dbo.prc_DBA_ReplicationStalenessReport.'
	END
END
GO

PRINT 'Altering Procedure: dbo.prc_DBA_ReplicationStalenessReport'
GO
/*************************************************************************************************
**
**  File: prc_DBA_ReplicationStalenessReport
**
**	Desc: Create HTML email report of all subscriptions that are greater than @UndelivCmdsInDistDB rows behind publisher.
**  
**
**	Created by: Chuck Lathrope 1-2-2010
**  Altered 11/1/2010	Chuck Lathrope	Utilized MSdistribution_status table
*************************************************************************************************/

ALTER PROCEDURE dbo.prc_DBA_ReplicationStalenessReport 
	@UndelivCmdsInDistDB  int = 1000,
	@NotificationEmailAddress varchar(100) = 'AlertDBA@yourdomain.com'
AS
BEGIN

SET NOCOUNT ON;

--Put this as a job step on your distributor.
DECLARE @tableHTML  NVARCHAR(MAX), @subjectMsg varchar(150), @HighPriority bit

Select @subjectMsg = 'Hourly Replication Status ' + convert(varchar(25),getdate())  + ' ' + @@servername 

--Final data select statement:
SET @tableHTML =    
    N'<H2>' + @subjectMsg + '</H2>' + 
    N'<table border="1" cellpadding="0" cellspacing="2">' +    
    N'<tr><th>Status Code</th><th>Last Synchronized</th>' +
    N'<th>PublisherDB-Subscriber</th><th>Undelivered Cmds</th><th>Subscriber DB</th><th>Subscription Type</th></tr>' + 
	CAST ( ( SELECT
		td = CASE 
		 WHEN mdh.runstatus = '1' THEN 'Start'
		 WHEN mdh.runstatus = '2' THEN 'Succeed'
		 WHEN mdh.runstatus = '3' THEN 'InProgress'
		 WHEN mdh.runstatus = '4' THEN 'Idle'
		 WHEN mdh.runstatus = '5' THEN 'Retry'
		 WHEN mdh.runstatus = '6' THEN 'Fail'
		 WHEN mdh.runstatus = '0' AND mda.subscription_type = '0' THEN 'PushPublication'
		END, '',
	td = convert(varchar(25),mdh.[time]), '',
	td = replace(left(mda.name,len(mda.name)-CHARINDEX('-',REVERSE(mda.name),1)),'VENOMDB1-',''), '',
	td = und.UndelivCmdsInDistDB, '',
	td = mda.subscriber_db, '',
	td = CASE 
		 WHEN mda.subscription_type =  '0' THEN 'Push'
		 WHEN mda.subscription_type =  '1' THEN 'Pull'
		 WHEN mda.subscription_type =  '2' THEN 'Anonymous'
		END 
	FROM distribution.dbo.MSdistribution_agents mda
	JOIN distribution.dbo.MSdistribution_history mdh ON mdh.agent_id = mda.id
	JOIN (
		select max(time) MaxTimeValue, name
		From distribution.dbo.msdistribution_agents a
		join distribution.dbo.MSdistribution_history h on h.agent_id=a.id
		group by name) x on x.MaxTimeValue = mdh.Time and x.name = mda.name
	Join (		
			SELECT st.agent_id, SUM(st.UndelivCmdsInDistDB) as UndelivCmdsInDistDB
			FROM distribution.dbo.MSdistribution_status st
			GROUP BY st.agent_id 
		) und on mda.id = und.agent_id
	Where UndelivCmdsInDistDB > @UndelivCmdsInDistDB
		FOR XML PATH('tr')
) AS NVARCHAR(MAX) ) +    
    N'</table></HTML>'

If @tableHTML LIKE '%Fail%'
	Set @HighPriority = 1

If @tableHTML is not null
	exec dbops.dbo.prc_internalsendmail 
	@HighPriority=@HighPriority, @address=@NotificationEmailAddress, 
	@subject=@subjectMsg, @body=@tableHTML, @HTML=1

END --Proc creation.

GO
