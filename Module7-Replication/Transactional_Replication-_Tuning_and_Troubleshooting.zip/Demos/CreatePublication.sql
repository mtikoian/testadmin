USE [AdventureWorks2012]
EXEC sp_replicationdboption @dbname = N'Pub', @optname = N'publish',
    @value = N'true'
GO

-- Adding the transactional publication
USE [AdventureWorks2012]
EXEC sp_addpublication @publication = N'Sample_Pub',
    @description = N'Transactional publication of database ''Pub'' from Publisher ''WIN-0SJ7BQVONBS''.',
    @sync_method = N'concurrent', @retention = 0, @allow_push = N'true',
    @allow_pull = N'true', @allow_anonymous = N'false',
    @enabled_for_internet = N'false', @snapshot_in_defaultfolder = N'true',
    @compress_snapshot = N'false', @ftp_port = 21,
    @allow_subscription_copy = N'false', @add_to_active_directory = N'false',
    @repl_freq = N'continuous', @status = N'active',
    @independent_agent = N'true', @immediate_sync = N'false',
    @allow_sync_tran = N'false', @allow_queued_tran = N'false',
    @allow_dts = N'false', @replicate_ddl = 1,
    @allow_initialize_from_backup = N'false', @enabled_for_p2p = N'false',
    @enabled_for_het_sub = N'false'
GO


EXEC sp_addpublication_snapshot @publication = N'Sample_Pub',
    @frequency_type = 1, @frequency_interval = 1,
    @frequency_relative_interval = 1, @frequency_recurrence_factor = 0,
    @frequency_subday = 8, @frequency_subday_interval = 1,
    @active_start_time_of_day = 0, @active_end_time_of_day = 235959,
    @active_start_date = 0, @active_end_date = 0, @job_login = NULL,
    @job_password = NULL, @publisher_security_mode = 1


USE [AdventureWorks2012]
EXEC sp_addarticle @publication = N'Sample_Pub', 
@article = N'Item',
    @source_owner = N'dbo', @source_object = N'Item', 
    @type = N'logbased',
    @description = NULL, @creation_script = NULL, 
    @pre_creation_cmd = N'drop',
    @schema_option = 0x000000000803509F,
    @identityrangemanagementoption = N'manual', 
    @destination_table = N'Item',
    @destination_owner = N'dbo', 
    @vertical_partition = N'true',
    @ins_cmd = N'CALL sp_MSins_dboItem', 
    @del_cmd = N'CALL sp_MSdel_dboItem',
    @upd_cmd = N'SCALL sp_MSupd_dboItem'

-- Adding the article's partition column(s)
EXEC sp_articlecolumn @publication = N'Sample_Pub', @article = N'Item',
    @column = N'Item_ID', @operation = N'add', @force_invalidate_snapshot = 1,
    @force_reinit_subscription = 1
EXEC sp_articlecolumn @publication = N'Sample_Pub', @article = N'Item',
    @column = N'Model', @operation = N'add', @force_invalidate_snapshot = 1,
    @force_reinit_subscription = 1
EXEC sp_articlecolumn @publication = N'Sample_Pub', @article = N'Item',
    @column = N'Manufacturer', @operation = N'add',
    @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
EXEC sp_articlecolumn @publication = N'Sample_Pub', @article = N'Item',
    @column = N'Price', @operation = N'add', @force_invalidate_snapshot = 1,
    @force_reinit_subscription = 1
EXEC sp_articlecolumn @publication = N'Sample_Pub', @article = N'Item',
    @column = N'Name', @operation = N'add', @force_invalidate_snapshot = 1,
    @force_reinit_subscription = 1
EXEC sp_articlecolumn @publication = N'Sample_Pub', @article = N'Item',
    @column = N'Buy_URL', @operation = N'add', @force_invalidate_snapshot = 1,
    @force_reinit_subscription = 1
EXEC sp_articlecolumn @publication = N'Sample_Pub', @article = N'Item',
    @column = N'Image_URL', @operation = N'add',
    @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
EXEC sp_articlecolumn @publication = N'Sample_Pub', @article = N'Item',
    @column = N'Vendor_SKU', @operation = N'add',
    @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
EXEC sp_articlecolumn @publication = N'Sample_Pub', @article = N'Item',
    @column = N'Vendor_ID', @operation = N'add',
    @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
EXEC sp_articlecolumn @publication = N'Sample_Pub', @article = N'Item',
    @column = N'Datasheet_URL', @operation = N'add',
    @force_invalidate_snapshot = 1, @force_reinit_subscription = 1

-- Adding the article synchronization object
EXEC sp_articleview @publication = N'Sample_Pub', @article = N'Item',
    @view_name = N'SYNC_Item_1__55', @filter_clause = NULL,
    @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
GO




USE [AdventureWorks2012]
EXEC sp_addarticle @publication = N'Sample_Pub', @article = N'Vendor',
    @source_owner = N'dbo', @source_object = N'Vendor', @type = N'logbased',
    @description = NULL, @creation_script = NULL, @pre_creation_cmd = N'drop',
    @schema_option = 0x000000000803509F,
    @identityrangemanagementoption = N'manual', @destination_table = N'Vendor',
    @destination_owner = N'dbo', @vertical_partition = N'false',
    @ins_cmd = N'CALL sp_MSins_dboVendor',
    @del_cmd = N'CALL sp_MSdel_dboVendor',
    @upd_cmd = N'SCALL sp_MSupd_dboVendor',
    @filter_clause = N'[Vendor_Status] < 3'

-- Adding the article filter
EXEC sp_articlefilter @publication = N'Sample_Pub', @article = N'Vendor',
    @filter_name = N'FLTR_Vendor_1__55',
    @filter_clause = N'[Vendor_Status] < 3', @force_invalidate_snapshot = 1,
    @force_reinit_subscription = 1

-- Adding the article synchronization object
EXEC sp_articleview @publication = N'Sample_Pub', @article = N'Vendor',
    @view_name = N'SYNC_Vendor_1__55', @filter_clause = N'[Vendor_Status] < 3',
    @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
GO




USE [AdventureWorks2012]
EXEC sp_addarticle @publication = N'Sample_Pub',
    @article = N'Vendor_Update_Status_By_Type', @source_owner = N'dbo',
    @source_object = N'Vendor_Update_Status_By_Type', @type = N'proc exec',
    @description = N'', @creation_script = NULL, @pre_creation_cmd = N'drop',
    @schema_option = 0x0000000008000001,
    @destination_table = N'Vendor_Update_Status_By_Type',
    @destination_owner = N'dbo'
GO




USE [AdventureWorks2012]
--EXEC sp_addarticle @publication = N'Sample_Pub', @article = N'ItemsByVendor',
--    @source_owner = N'dbo', @source_object = N'ItemsByVendor',
--    @type = N'indexed view schema only', @description = N'',
--    @creation_script = NULL, @pre_creation_cmd = N'drop',
--    @schema_option = 0x0000000008000001, @destination_table = N'ItemsByVendor',
--    @destination_owner = N'dbo'

EXEC sp_addarticle @publication = N'Sample_Pub', @article = N'ItemsByVendor',
    @source_owner = N'dbo', @source_object = N'ItemsByVendor',
    @type = N'indexed view logbased', @description = N'',
    @creation_script = NULL, @pre_creation_cmd = N'drop',
    @schema_option = 0x0000000008000001, @destination_table = N'ItemsByVendor',
    @destination_owner = N'dbo'
GO




