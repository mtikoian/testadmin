-- Troubleshooting: Rows missing from subscriber

-- Run on subscriber
USE [AdventureWorks2012Sub]
GO
DELETE FROM Vendor
WHERE Vendor_ID = 14752397




-- Run on publisher
USE [AdventureWorks2012]
GO
UPDATE Vendor
SET Vendor_Status = 2
WHERE Vendor_ID = 14752397


-- Run on distributor
USE distribution
GO
sp_browsereplcmds @xact_seqno_start = '0x0000002600000111000C00000000'
    , @xact_seqno_end = '0x0000002600000111000C00000000'
    , @publisher_database_id = 1
    , @command_id = 1



-- Get the value for @publisher_database_id 
SELECT  DISTINCT
        subscriptions.publisher_database_id
FROM    sys.servers AS [publishers]
        INNER JOIN distribution.dbo.MSpublications AS [publications] ON publishers.server_id = publications.publisher_id
        INNER JOIN distribution.dbo.MSarticles AS [articles] ON publications.publication_id = articles.publication_id
        INNER JOIN distribution.dbo.MSsubscriptions AS [subscriptions] ON articles.article_id = subscriptions.article_id
                                                              AND articles.publication_id = subscriptions.publication_id
                                                              AND articles.publisher_db = subscriptions.publisher_db
                                                              AND articles.publisher_id = subscriptions.publisher_id
        INNER JOIN sys.servers AS [subscribers] ON subscriptions.subscriber_id = subscribers.server_id
WHERE   publishers.name = 'WIN-0SJ7BQVONBS'
        AND publications.publication = 'Sample_Pub'
        AND subscribers.name = 'WIN-0SJ7BQVONBS'
