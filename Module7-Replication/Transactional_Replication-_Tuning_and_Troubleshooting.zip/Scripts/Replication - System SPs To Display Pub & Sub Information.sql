/*********************************************************************************************
Replication: System SPs To Display Pub & Sub Information

Feedback: mailto:kendal.vandyke@gmail.com

Note: 
	Execute this query on the DISTRIBUTOR
	
*********************************************************************************************/
USE distribution
GO

-- These are useful for viewing the state of replication on the distributor
EXEC sp_helppublication @publication = '%'
EXEC sp_helparticle @publication = 'Sample_Pub'
EXEC sp_replcounters
EXEC sp_MSenum_logreader @name = '%',  @show_distdb = 0
EXEC sp_MSenum_distribution @name = '%', @show_distdb = 0, @exclude_anonymous = 0

DBCC SQLPERF(LOGSPACE)
