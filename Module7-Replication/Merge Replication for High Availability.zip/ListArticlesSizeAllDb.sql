/* 

List merge replication articles and their size


*/


DECLARE @Pub TABLE
(
ServerName nvarchar(250)
,DatabaseName nvarchar(250)
,SchemaName nvarchar(250)
,ArticleName nvarchar(250)
,ObjectSizeKB bigint
,ObjectRowCount bigint
)
;

DECLARE 
@SQL			NVARCHAR(MAX)



SET @SQL = N'
IF EXISTS (SELECT name from master.sys.databases where name = ''?'' and is_merge_published = 1)
SELECT DISTINCT 
@@ServerName,''?''
,OBJECT_SCHEMA_NAME (objid, DB_ID(''?'')) AS SchemaName
, m.name AS OjbectName
,SUM (  
CASE  
	WHEN (index_id < 2) THEN (in_row_data_page_count + lob_used_page_count + row_overflow_used_page_count)  
	ELSE lob_used_page_count + row_overflow_used_page_count  
END  
) * 8 AS ObjectSizeKB
,SUM (  
CASE  
	WHEN (index_id < 2) THEN row_count  
    ELSE 0  
END  
) AS ObjectRowCount 
FROM [?].[dbo].[sysmergeextendedarticlesview] m 
INNER JOIN [?].[sys].[dm_db_partition_stats] p WITH (NOLOCK) ON p.object_id = m.objid
GROUP BY 
OBJECT_SCHEMA_NAME (objid, DB_ID(''?''))
,m.name 
ORDER BY 
OBJECT_SCHEMA_NAME (objid, DB_ID(''?''))
,m.name 
'
	
	
INSERT INTO @Pub	
EXEC sp_MSforeachdb @command1=@SQL


/* List by database and article */
SELECT ServerName, DatabaseName, SchemaName, ArticleName, ObjectSizeKB,ObjectRowCount 
FROM @Pub 
ORDER BY ServerName,DatabaseName, SchemaName, ArticleName


/* List by most rows */
SELECT ServerName, DatabaseName, SchemaName, ArticleName, ObjectSizeKB,ObjectRowCount 
FROM @Pub 
ORDER BY ObjectRowCount desc


