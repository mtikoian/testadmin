/*

Change the merge agent default profile query timeout

The next time the job stops and starts,
the new QueryTimeout value will be in effect for the agent profile


agent_type
1	Snapshot Agent
2	Log Reader Agent
3	Distribution Agent
4	Merge Agent
9	Queue Reader Agent

*/

DECLARE 
@CurrentAgentType INT
,@ChangeProfile_id INT
,@Changeprofile_name NVARCHAR(250)
,@NewParameter_value INT


SELECT 
@CurrentAgentType = 4
,@Changeprofile_name = 'Default agent profile'
,@NewParameter_value = 7200

SELECT @ChangeProfile_id = 
(select profile_id from msdb.dbo.MSagent_profiles
	where agent_type = 4 and profile_name = @Changeprofile_name
)

PRINT @ChangeProfile_id
/*Result: 6*/

EXEC sp_change_agent_parameter @profile_id = @ChangeProfile_id, @parameter_name = N'-QueryTimeout', 
	@parameter_value = @NewParameter_value;
	
select * 
	from msdb.dbo.MSagent_parameters  
	where profile_id = 6 and parameter_name = 
	N'-QueryTimeout'
/*		Result: 6	-QueryTimeout	7200  */

