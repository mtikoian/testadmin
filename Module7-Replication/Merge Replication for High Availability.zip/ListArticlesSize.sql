/* 

List merge replication articles and their size

Enter database name into '<Mydatabasename>'

*/

DECLARE 
@DatabaseName	NVARCHAR (500),
@SQL			NVARCHAR(4000)

SET @DatabaseName = '<Mydatabasename>'

SET @SQL = N'
SELECT DISTINCT 
OBJECT_SCHEMA_NAME (objid, DB_ID(''' + @DatabaseName  + ''')) AS SchemaName
, m.name AS ObjectName
,SUM (  
CASE  
	WHEN (index_id < 2) THEN (in_row_data_page_count + lob_used_page_count + row_overflow_used_page_count)  
	ELSE lob_used_page_count + row_overflow_used_page_count  
END  
) * 8 AS ObjectSizeKB
,SUM (  
CASE  
	WHEN (index_id < 2) THEN row_count  
    ELSE 0  
END  
) AS ObjectRowCount
FROM [' + @DatabaseName + '].[dbo].[sysmergeextendedarticlesview] m
INNER JOIN [' + @DatabaseName + '].[sys].[dm_db_partition_stats] p WITH (NOLOCK) ON p.object_id = m.objid
GROUP BY 
OBJECT_SCHEMA_NAME (objid, DB_ID(''' + @DatabaseName  + '''))
,m.name 
ORDER BY 
OBJECT_SCHEMA_NAME (objid, DB_ID(''' + @DatabaseName  + '''))
,m.name 
'

PRINT @SQL

EXECUTE (@SQL)

