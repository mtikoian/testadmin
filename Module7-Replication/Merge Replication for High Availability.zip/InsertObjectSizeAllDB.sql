/*

Insert size of objects into ObjectSize for all databases

*/

USE MyAdminDB
GO



DECLARE
@sql	NVARCHAR(4000),
@DatabaseName	NVARCHAR(500)

	
DECLARE DatabaseLoop CURSOR
FOR
SELECT name from master.dbo.sysdatabases
WHERE name not in ('tempdb','master','msdb','distribution','ReportServer','ReportServerTempDB')
ORDER BY name

OPEN DatabaseLoop

FETCH NEXT FROM DatabaseLoop
INTO @DatabaseName

/* Loop through the databases */
WHILE @@FETCH_STATUS = 0
BEGIN

	PRINT  'Database: ' + @DatabaseName

	/* Insert size of objects into ObjectSize */
	exec [MyAdminDB].[dbo].[InsertObjectSize] @DatabaseName


	FETCH NEXT FROM DatabaseLoop
	INTO @DatabaseName

END --Loop through the databases

CLOSE DatabaseLoop
DEALLOCATE DatabaseLoop

