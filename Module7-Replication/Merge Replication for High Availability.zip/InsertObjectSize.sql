USE MyAdminDB
GO


IF OBJECT_ID('InsertObjectSize') IS NOT NULL 
    DROP PROCEDURE [dbo].[InsertObjectSize]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



CREATE PROCEDURE [dbo].[InsertObjectSize]
@DatabaseName NVARCHAR(256) = NULL

/*

Run daily to save object sizes in the table [dbo].[ObjectSize].
Then compare between days, weeks, etc to find active objects.

exec [MyAdminDB].[dbo].[InsertObjectSize] <MyDB>

Insert object space data into the ObjectSize table:

CREATE TABLE [MyAdminDB].[dbo].[ObjectSize]
(
DatabaseName NVARCHAR(256),
SchemaName NVARCHAR(256),
ObjectName	NVARCHAR(256),
NumberOfRows	BIGINT,
DataSizeKB	BIGINT,
IsObjMergeReplication	SMALLINT,
SizeDate Datetime
)
GO
CREATE CLUSTERED INDEX ix_ObjectSize
ON [MyAdminDB].[dbo].[ObjectSize]
(DatabaseName,SchemaName, ObjectName,SizeDate)
GO

*/

AS

DECLARE
@SQL NVARCHAR(4000),
@cnt	INT,
@SchemaName NVARCHAR(256),
@ObjectName NVARCHAR(256),
@ObjectID INT,
@IsDBMergeReplication	SMALLINT,  -- 0 = fales, 1 = true
@IsObjMergeReplication	SMALLINT,  -- 0 = fales, 1 = true
@ObjectRows BIGINT,
@ObjectSizeKB BIGINT,
@IntVariable INT,
@VarcharVariable NVARCHAR(500),
@ParmDefinition NVARCHAR(500),
@pages BIGINT,
@rowCount BIGINT,
@SizeDate DATETIME


DECLARE @Check TABLE
(
MyCheck NVARCHAR(max)
)


--DROP TABLE #ObjectID
CREATE TABLE #ObjectID
(
ObjectID INT
)

--DROP TABLE #ObjectSize
CREATE TABLE #ObjectSize
(
ObjectSizeKB BIGINT,
ObjectRowCount BIGINT
--,IsMergeReplication	SMALLINT
)

--DROP TABLE #ObjectList
CREATE TABLE #ObjectList
(
ObjectID	BIGINT,
SchemaName	NVARCHAR(256),
ObjectName	NVARCHAR(256),
IsObjMergeReplication SMALLINT
)

SET @IsDBMergeReplication= 0  -- Default false = 0
SET @cnt = 0


SET @SQL = 
'SELECT object_id, SCHEMA_NAME(schema_id), name, NULL 
FROM [' + @DatabaseName + '].[sys].[objects] o
WHERE type IN (''U'') AND name NOT LIKE ''dt%''
AND is_ms_shipped = 0
ORDER BY name
'
--PRINT @SQL


INSERT INTO #ObjectList
EXEC (@SQL)

--SELECT * FROM #ObjectList


/*  Check this database for merge replication  */
SET @SQL =
N'SELECT count(*) 
FROM [' + @DatabaseName + '].sys.sysobjects 
WHERE name like ''sysmergeextendedarticlesview'''
--PRINT @SQL
	
DELETE FROM @Check

INSERT INTO @Check 
EXEC (@SQL)

SET @CNT = (SELECT CONVERT(INT, MyCheck) FROM @Check )

/* If the database uses merge replication, flag each article (object) */
IF @cnt > 0
	BEGIN
		SET @IsDBMergeReplication = 1
		
		SET @SQL = N'
		UPDATE #ObjectList
		SET IsObjMergeReplication = 1
		FROM [' + @DatabaseName + '].[dbo].[sysmergeextendedarticlesview] m
		WHERE m.objid = ObjectID
		'

		PRINT @SQL

		EXEC (@SQL)

		SELECT * FROM #ObjectList

	END


--PRINT '@IsDBMergeReplication' + CONVERT(VARCHAR(50),@IsDBMergeReplication) 


DECLARE LoopObject CURSOR
FOR
SELECT ObjectID, SchemaName, ObjectName, IsObjMergeReplication
FROM #ObjectList

OPEN LoopObject

FETCH NEXT FROM LoopObject
INTO @ObjectID, @SchemaName, @ObjectName, @IsObjMergeReplication


WHILE @@FETCH_STATUS = 0
BEGIN

	SET @SQL = 
	N'select 
	SUM (  
	CASE  
		WHEN (index_id < 2) THEN (in_row_data_page_count + lob_used_page_count + row_overflow_used_page_count)  
		ELSE lob_used_page_count + row_overflow_used_page_count  
	END  
	) * 8,  
	SUM (  
	CASE  
		WHEN (index_id < 2) THEN row_count  
	    ELSE 0  
	END  
	)  
	FROM [' + @DatabaseName + '].[sys].[dm_db_partition_stats]  WITH (NOLOCK)
	WHERE object_id = ' + CONVERT(VARCHAR(50), @ObjectID) + ';
	'


	TRUNCATE TABLE #ObjectSize

	INSERT INTO #ObjectSize
	EXECUTE (@SQL)
	

	INSERT INTO [dbo].[ObjectSize]
	(DatabaseName,SchemaName,ObjectName,NumberOfRows,DataSizeKB,IsObjMergeReplication,SizeDate)
	SELECT @DatabaseName, @SchemaName, @ObjectName, ObjectRowCount, ObjectSizeKB, @IsObjMergeReplication, GetDate()
	FROM #ObjectSize


	FETCH NEXT FROM LoopObject
	INTO @ObjectID, @SchemaName, @ObjectName, @IsObjMergeReplication


END

CLOSE LoopObject
DEALLOCATE LoopObject




