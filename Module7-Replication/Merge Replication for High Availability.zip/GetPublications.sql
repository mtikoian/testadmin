/*
List databases that are published
*/
select name 
from master.sys.databases 
where is_merge_published = 1 order by name

/*
List the publications
*/
SELECT publisher_db, publication
FROM distribution.dbo.MSpublications



