/*

Get the replication status and error messages

When @mergesession ErrorID is null, select @mergesession LastMessage, because there is no error.
Otherwise select distribution.dbo.MSrepl_errors.error_text to list the errors.

Connect to the instance being checked.

Agent run status:
	1 = Start
	2 = Succeed
	3 = In progress
	4 = Idle
	5 = Retry
	6 = Fail

*/


DECLARE 
@Status INT,
@ErrorID INT,
@AgentName NVARCHAR(500)


DECLARE @mergesession TABLE
(
session_id			int
,status				bit
,startTime			datetime
,EndTime			datetime
,Duration			int
,UploadedCommands	int
,DownloadedCommands	int
,ErrorMessages		int
,ErrorID			int
,PercentageDone		decimal (10,2)
,TimeRemaining		decimal (10,2)
,CurrentPhase		int
,LastMessage		varchar(max)
,IsSpidActive		bit
)


DECLARE @AgentMessages TABLE
(
session_id				INT
,status					BIT
, Agentid				INT
, AgentName				NVARCHAR(500)
, PublisherInstance		NVARCHAR(250)
, publisher_db			NVARCHAR(250)
, publication			NVARCHAR(500)
, SubscriberInstance	NVARCHAR(250)
, subscriber_db			NVARCHAR(250)
, error_time				DATETIME
, start_time			DATETIME
, end_time				DATETIME
, errorid				INT
, error_text			NVARCHAR(MAX)
)


/*
Loop on distribution.dbo.MSmerge_agents.name
*/



DECLARE cAgent CURSOR
FOR
SELECT name
FROM distribution.dbo.MSmerge_agents

OPEN cAgent

FETCH NEXT FROM cAgent
INTO @AgentName

WHILE @@FETCH_STATUS = 0
BEGIN

	DELETE FROM @mergesession

	INSERT INTO @mergesession
	exec [distribution].sys.sp_replmonitorhelpmergesession @agent_name = @AgentName, @hours = -1, @session_type = 1

	SELECT TOP 1
	@ErrorID = ErrorID
	,@Status = Status
	FROM @mergesession
	
	PRINT '@ErrorID'
	PRINT @ErrorID
	PRINT '@Status'
	PRINT @Status

	-- Lists merge agent, pulisher, subscriber and error messages.
	-- joins by merga agent id and session id
	IF @ErrorID IS NULL
		BEGIN

			-- Includes "last message" from [distribution].sys.sp_replmonitorhelpmergesession
			INSERT INTO @AgentMessages
			select TOP 1
			ms.session_id
			,@Status
			, ma.id as Agentid
			, ma.name as AgentName 
			,@@servername as PublisherInstance
			,ma.publisher_db
			, ma.publication
			, ma.subscriber_name as SubscriberInstance
			, ma.subscriber_db
			, NULL
			, ms.start_time
			, ms.end_time
			, NULL
			, s.LastMessage
			from distribution.dbo.MSmerge_agents ma with (nolock)
			JOIN distribution.dbo.MSmerge_sessions ms  with (nolock) on ms.agent_id = ma.id
			JOIN @mergesession s on s.session_id = ms.session_id
			ORDER BY ms.start_time DESC
		END
	ELSE
		BEGIN

			--Includes error messages from distribution.dbo.MSrepl_errors
			INSERT INTO @AgentMessages
			select 
			ms.session_id
			,@Status
			, ma.id as Agentid
			, ma.name as AgentName 
			,@@servername as PublisherInstance
			,ma.publisher_db
			, ma.publication
			, ma.subscriber_name as SubscriberInstance
			, ma.subscriber_db
			, me.time
			, ms.start_time
			, ms.end_time
			, me.id as errorid
			, me.error_text 
			from distribution.dbo.MSmerge_agents ma with (nolock)
			JOIN distribution.dbo.MSmerge_sessions ms with (nolock) ON ms.agent_id = ma.id
			JOIN distribution.dbo.MSrepl_errors me with (nolock) on me.session_id = ms.session_id
			JOIN @mergesession s ON s.ErrorID = me.id and s.session_id = me.session_id

	END -- @ErrorID IS NULL


FETCH NEXT FROM cAgent
INTO @AgentName

END

CLOSE cAgent
DEALLOCATE cAgent


/*
List subscriptions that have an error
*/
SELECT 
'Has error' ErrorStatus
,Status
,PublisherInstance
, publication
, publisher_db
,  SubscriberInstance
, subscriber_db
, errorid
, max(error_time) errortime
, 'Has errors' as errormessage
FROM @AgentMessages
WHERE errorid IS NOT NULL
OR error_text LIKE '%fail%'
GROUP BY
Status
,PublisherInstance
, publication
, publisher_db
,  SubscriberInstance
, subscriber_db
, errorid
ORDER BY 
  PublisherInstance
, publisher_db
, publication

/*
List subscriptions that are not synchronizing
*/
SELECT 
'Not synchronizing' as SynchStatus
,Status
,PublisherInstance
, publication
, publisher_db
,  SubscriberInstance
, subscriber_db
, max(error_time) as errortime
, 'cancelled' as message
FROM @AgentMessages
WHERE 
Status <> 1
GROUP BY
Status
,PublisherInstance
, publication
, publisher_db
,  SubscriberInstance
, subscriber_db



/* List all messages */
SELECT
session_id as SPID
--, Agentid
--, AgentName
, Status
, publication
, PublisherInstance
, publisher_db
, SubscriberInstance
, subscriber_db
, start_time
, end_time
, errorid
, error_text as message
FROM @AgentMessages
ORDER BY 
  PublisherInstance
, publisher_db



