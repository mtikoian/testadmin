/*
-- Prepare SalesOrderHeader and SalesOrderDetail Tables
-- for Replication
-- 1. DROP most FK constraints
-- 2. Set SalesOrderDetail IDENTITY column to NOT FOR REPLICATION
-- 3. Disable triggers on SalesOrderHeader and SalesOrderDetail

*/

USE AdventureWorks2012;
GO

ALTER TABLE Sales.SalesOrderHeader
DROP CONSTRAINT FK_SalesOrderHeader_Address_BillToAddressID,
				FK_SalesOrderHeader_Address_ShipToAddressID,
				FK_SalesOrderHeader_CreditCard_CreditCardID,
				FK_SalesOrderHeader_CurrencyRate_CurrencyRateID,
				-- leave enabled FK for Customer.CustomerID
				-- leave enabled FK for SalesPerson.BusinessEntityID
				FK_SalesOrderHeader_SalesTerritory_TerritoryID,
				FK_SalesOrderHeader_ShipMethod_ShipMethodID;
GO

-- IN TABLE Sales.SalesOrderDetail
-- leave enabled FK for SalesOrderHeader.SalesOrderID
-- and drop      FK for (SpecialOfferID, ProductID)

-- FKs that are left enabled will be turned off when enabling
--     replication (to illustrate that action), except for
--     FK_SalesOrderDetail_SalesOrderHeader_SalesOrderID
--     because both of those tables will be replicated.

ALTER TABLE Sales.SalesOrderDetail
DROP CONSTRAINT FK_SalesOrderDetail_SpecialOfferProduct_SpecialOfferIDProductID;
GO

ALTER TABLE Sales.SalesOrderDetail
ALTER COLUMN SalesOrderDetailID  ADD NOT FOR REPLICATION;
GO

DISABLE TRIGGER uSalesOrderHeader
ON Sales.SalesOrderHeader;
DISABLE TRIGGER iduSalesOrderDetail
ON Sales.SalesOrderDetail;
GO

USE master;
GO
