/*
Create Stored Proc to simulate
adding an order to AdventureWorks
(adds to tables SalesOrderHeader
 and SalesOrderDetails)

*/

USE AdventureWorks2012;
GO

IF OBJECT_ID ('Sales.AddOrder', 'P') IS NOT NULL
   DROP PROCEDURE Sales.AddOrder;
GO

CREATE PROCEDURE Sales.AddOrder
   @Debug bit = 0
AS

DECLARE @SalesOrderID int;
SELECT @SalesOrderID = RAND() * (75123 - 43659) + 43659;

SELECT *
INTO #SOH
FROM Sales.SalesOrderHeader
WHERE SalesOrderID = @SalesOrderID;
--SELECT * FROM #SOH;

SELECT * 
INTO #SOD
FROM Sales.SalesOrderDetail
WHERE SalesOrderID = @SalesOrderID;
--SELECT * FROM #SOD;

DECLARE @date date;
SELECT @date = (SELECT MAX(OrderDate) FROM Sales.SalesOrderHeader);
IF (SELECT COUNT(OrderDate) FROM Sales.SalesOrderHeader
       WHERE OrderDate = @date) >= 50
   SET @date = DATEADD(dd, +1, @date);
--SELECT @date as MaxDate;

DECLARE @OrderDate				datetime;
DECLARE @OnlineOrderFlag		bit;
DECLARE @PurchaseOrderNumber	nvarchar(25);
DECLARE @AccountNumber			nvarchar(15);
DECLARE @CustomerID				int;
DECLARE @SalesPersonID			int;
DECLARE @TerritoryID			int;
DECLARE @BillToAddressID		int;
DECLARE @ShipToAddressID		int;
DECLARE @ShipMethodID			int;
DECLARE @CreditCardID			int;
DECLARE @CreditCardApprovalCode varchar(15);
DECLARE @CurrencyRateID			int;
DECLARE @Subtotal				money;
DECLARE @TaxAmt					money;
DECLARE @Freight				money;
DECLARE @Comment				nvarchar(128);

SET @OrderDate = @Date;
SET @OnlineOrderFlag =		(SELECT OnlineOrderFlag FROM #SOH);
SET @PurchaseOrderNumber =	(SELECT PurchaseOrderNumber FROM #SOH);
SET @AccountNumber =		(SELECT AccountNumber FROM #SOH);
SET @CustomerID =			(SELECT CustomerID FROM #SOH);
SET @SalesPersonID =		(SELECT SalesPersonID FROM #SOH);
SET @TerritoryID =			(SELECT TerritoryID FROM #SOH);
SET @BillToAddressID =		(SELECT BillToAddressID FROM #SOH);
SET @ShipToAddressID =		(SELECT ShipToAddressID FROM #SOH);
SET @ShipMethodID =			(SELECT ShipMethodID FROM #SOH);
SET @CreditCardID =			(SELECT CreditCardID FROM #SOH);
SET @CreditCardApprovalCode=(SELECT CreditCardApprovalCode FROM #SOH);
SET @CurrencyRateID =		(SELECT CurrencyRateID FROM #SOH);
SET @Subtotal =				(SELECT Subtotal FROM #SOH);
SET @TaxAmt =				(SELECT TaxAmt FROM #SOH);
SET @Freight =				(SELECT Freight FROM #SOH);
SET @Comment =				(SELECT Comment FROM #SOH);

INSERT Sales.SalesOrderHeader  
	( RevisionNumber
	, OrderDate
	, DueDate
	, ShipDate
	, [Status]
	, OnlineOrderFlag
	--, SalesOrderNumber		-- **
	, PurchaseOrderNumber
	, AccountNumber
	, CustomerID  
	, SalesPersonID 
	, TerritoryID 
	, BillToAddressID 
	, ShipToAddressID 
	, ShipMethodID 
	, CreditCardID 
	, CreditCardApprovalCode 
	, CurrencyRateID
	, Subtotal
	, TaxAmt
	, Freight 
	--, TotalDue				-- **
	, Comment 
	, rowguid 
	, ModifiedDate
	)
VALUES 
	( 5 
	, @OrderDate
	, DATEADD (day, 7, @OrderDate)
	, DATEADD (day, 5, @OrderDate)
	, 5 
	, @OnlineOrderFlag 
	--, @SalesOrderNumber		-- **
	, @PurchaseOrderNumber 
	, @AccountNumber 
	, @CustomerID 
	, @SalesPersonID 
	, @TerritoryID 
	, @BillToAddressID 
	, @ShipToAddressID 
	, @ShipMethodID 
	, @CreditCardID 
	, @CreditCardApprovalCode 
	, @CurrencyRateID 
	, @Subtotal 
	, @TaxAmt 
	, @Freight
	--, @TotalDue				-- **
	, @Comment 
	, newid()
	, getdate()
	);


DECLARE @SOid					int;
SET @SOid = SCOPE_IDENTITY();
DECLARE @SODid					int;
DECLARE @CarrierTrackingNumber	nvarchar(25);
DECLARE @OrderQty				smallint;
DECLARE @ProductID				int;
DECLARE @SpecialOfferID			int;
DECLARE @UnitPrice				money;
DECLARE @UnitPriceDiscount		money;
--DECLARE @LineTotal				money;

DECLARE @n						int;
SET @n = (SELECT COUNT(SalesOrderID) FROM #SOD);
DECLARE @i						int;
SET @i = 1
DECLARE @SODidMIN				int;

WHILE @i <= @n
  BEGIN  -- WHILE @i
    
	SET @SODidMIN =				(SELECT MIN(SalesOrderDetailID) FROM #SOD)
	SET @CarrierTrackingNumber=	(SELECT CarrierTrackingNumber FROM #SOD WHERE SalesOrderDetailID = @SODidMIN)
	SET @OrderQty =				(SELECT OrderQty FROM #SOD WHERE SalesOrderDetailID = @SODidMIN)
	SET @ProductID =			(SELECT ProductID FROM #SOD WHERE SalesOrderDetailID = @SODidMIN)
	SET @SpecialOfferID =		(SELECT SpecialOfferID FROM #SOD WHERE SalesOrderDetailID = @SODidMIN)
	SET @UnitPrice =			(SELECT UnitPrice FROM #SOD WHERE SalesOrderDetailID = @SODidMIN)
	SET @UnitPriceDiscount =	(SELECT UnitPriceDiscount FROM #SOD WHERE SalesOrderDetailID = @SODidMIN)
--	SET @LineTotal =			(SELECT LineTotal FROM #SOD WHERE SalesOrderDetailID = @SODidMIN)

	INSERT Sales.SalesOrderDetail 
		( SalesOrderID 
		, CarrierTrackingNumber 
		, OrderQty 
		, ProductID 
		, SpecialOfferID 
		, UnitPrice 
		, UnitPriceDiscount 
		--, LineTotal			          -- **
		, rowguid 
		, ModifiedDate 
		)
	VALUES 
		( @SOid 
		, @CarrierTrackingNumber 
		, @OrderQty 
		, @ProductID 
		, @SpecialOfferID 
		, @UnitPrice 
		, @UnitPriceDiscount 
		--, @LineTotal					-- **
		, newid() 
		, getdate()
		)

    SET @i = @i + 1
	DELETE #SOD WHERE SalesOrderDetailID = @SODidMIN
  END    -- WHILE @i

-- SELECT * FROM #SOD2

DROP TABLE #SOD;
DROP TABLE #SOH;

GO

USE master;
GO
