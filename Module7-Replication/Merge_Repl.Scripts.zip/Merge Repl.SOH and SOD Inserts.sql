/*

Code to look at inserted rows and execute Sales.AddOrder

*/

USE AdventureWorks2012;
GO

SELECT TOP(5) *  FROM Sales.SalesOrderHeader
ORDER BY SalesOrderID DESC;

SELECT TOP(8) *  FROM Sales.SalesOrderDetail
ORDER BY SalesOrderDetailID DESC;

EXEC Sales.AddOrder;


/*
-- Code to revert to state of not having added any rows
--   to SOH and SOD
--   (Does not change merge repl IDENTITY history.)

DELETE Sales.SalesOrderDetail WHERE SalesOrderDetailID > 121317;
DELETE Sales.SalesOrderHeader WHERE SalesOrderID > 75123;
DBCC CHECKIDENT ("Sales.SalesOrderDetail", RESEED, 121317);
DBCC CHECKIDENT ("Sales.SalesOrderHeader", RESEED, 75123);

*/
