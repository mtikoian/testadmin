-- Code to update a field
-- For demo of conflict resolution

USE AdventureWorks2012;
GO


UPDATE Sales.SalesOrderHeader
SET RevisionNumber = 6
WHERE SalesOrderID = 75124;


UPDATE Sales.SalesOrderHeader
SET [Status] = 6
WHERE SalesOrderID = 75124;


SELECT SalesOrderID, RevisionNumber, [Status]
FROM Sales.SalesOrderHeader
WHERE SalesOrderID = 75124;


