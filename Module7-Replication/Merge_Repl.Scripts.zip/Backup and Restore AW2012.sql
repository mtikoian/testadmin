BACKUP DATABASE AdventureWorks2012
TO DISK = 'D:\DD\MSTEACH\SQL Saturday\Merge Replication 389\AW2012_Orig.bak';

/*
USE master;
RESTORE DATABASE AdventureWorks2012
FROM DISK = 'D:\DD\MSTEACH\SQL Saturday\Merge Replication 389\AW2012_Orig.bak';

*/

