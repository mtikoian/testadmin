-- This forces row by row updates to occur on subscriber
USE Pub
GO
UPDATE Vendor
SET Vendor_Status = 2
WHERE Vendor_Type = 3


-- This replicates the execution of the stored procedure
EXEC Vendor_Update_Status_By_Type @Vendor_Status = 1, @Vendor_Type = 3





-- These are useful for viewing the state of replication on the PUBLISHER
USE Pub
GO
EXEC sp_helppublication @publication = '%'
EXEC sp_helparticle @publication = 'Sample_Pub'
EXEC sp_replcounters


-- These are useful for viewing the state of replication on the DISTRIBUTOR
USE distribution
GO
EXEC sp_MSenum_logreader @name = '%',  @show_distdb = 0
EXEC sp_MSenum_distribution @name = '%', @show_distdb = 0, @exclude_anonymous = 0


-- Good for seeing transaction log space usage
DBCC SQLPERF(LOGSPACE)
