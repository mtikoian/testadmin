/*Get server information */
SELECT ServerName = serverproperty('machinename') ,
	   InstanceName = serverproperty('instancename') ,
	   Version = serverproperty('productversion') , 
	   ServicePack = SERVERPROPERTY('productlevel') , 
	   Edition = SERVERPROPERTY('edition') , 
	   ServerCollation = SERVERPROPERTY('collation') , 
	   IsIntegratedSecurity = SERVERPROPERTY('isintegratedsecurityonly');
	   

/*Service accounts, Port No, Program File Dir, Error Log Path
NOTE: If you're documenting a named instance, be sure do notate that. e.g. 'SYSTEM\ControlSet001\Services\MSSQLServer$namedinstance'*/
DECLARE @SQLService  	VARCHAR(60),
		@AgentService  VARCHAR(60),
		@port			varchar(5),
		@errorlogpath	sql_variant,
		@SmoRoot		nvarchar(512)

SET @errorlogpath = (SELECT ServerProperty('ErrorLogFileName'))
EXEC master.dbo.xp_instance_regread 'HKEY_LOCAL_MACHINE', 'SYSTEM\ControlSet001\Services\MSSQLServer', 'ObjectName', @SQLService OUTPUT;
EXEC master.dbo.xp_instance_regread 'HKEY_LOCAL_MACHINE', 'SYSTEM\ControlSet001\Services\SQLSERVERAGENT', 'ObjectName', @AgentService OUTPUT;
EXEC master.dbo.xp_regread 'HKEY_LOCAL_MACHINE','SOFTWARE\Microsoft\MSSQLServer\MSSQLServer\SuperSocketNetLib\Tcp','TcpPort',@port OUTPUT;
EXEC master.dbo.xp_instance_regread N'HKEY_LOCAL_MACHINE', N'SOFTWARE\Microsoft\MSSQLServer\Setup', N'SQLPath', @SmoRoot OUTPUT;
SELECT  @SQLService AS 'SQL Service Account', @AgentService AS 'SQL Agent Account', @port as 'PortNo',
		@smoroot as 'SQL Server Directory', @errorlogpath as 'Error Log Path';

/*Default data directory, log directory, backup directory
	The reason behind grabbing the two values for data and log files is that they're not always populated correctly :) */

DECLARE @DefaultData nvarchar(512),
		@DefaultLog nvarchar(512),
		@DefaultBackup nvarchar(512),
		@MasterData nvarchar(512),
		@MasterLog nvarchar(512)

EXEC master.dbo.xp_instance_regread N'HKEY_LOCAL_MACHINE', N'Software\Microsoft\MSSQLServer\MSSQLServer', N'DefaultData', @DefaultData OUTPUT;
EXEC master.dbo.xp_instance_regread N'HKEY_LOCAL_MACHINE', N'Software\Microsoft\MSSQLServer\MSSQLServer', N'DefaultLog', @DefaultLog OUTPUT;
EXEC master.dbo.xp_instance_regread N'HKEY_LOCAL_MACHINE', N'Software\Microsoft\MSSQLServer\MSSQLServer', N'BackupDirectory', @DefaultBackup OUTPUT;
EXEC master.dbo.xp_instance_regread N'HKEY_LOCAL_MACHINE', N'Software\Microsoft\MSSQLServer\MSSQLServer\Parameters', N'SqlArg0', @MasterData OUTPUT;
SELECT @MasterData=substring(@MasterData, 3, 255);
SELECT @MasterData=substring(@MasterData, 1, len(@MasterData) - charindex('\', reverse(@MasterData)));
EXEC master.dbo.xp_instance_regread N'HKEY_LOCAL_MACHINE', N'Software\Microsoft\MSSQLServer\MSSQLServer\Parameters', N'SqlArg2', @MasterLog OUTPUT;
SELECT @MasterLog=substring(@MasterLog, 3, 255);
SELECT @MasterLog=substring(@MasterLog, 1, len(@MasterLog) - charindex('\', reverse(@MasterLog)));

SELECT DefaultData = isnull(@DefaultData, @MasterData), 
	   DefaultLog = isnull(@DefaultLog, @MasterLog),
	   DefaultBackup = @DefaultBackup;


/*Get server configurations 
There are a number of configurations that can be viewed this way - https://msdn.microsoft.com/en-us/library/ms189631.aspx */

SELECT Name, ConfiguredValue = value, RunningValue = value_in_use, Description, Is_Dynamic, Is_Advanced
FROM sys.configurations
WHERE name IN 
('Ad Hoc Distributed Queries',
'backup compression default',
'clr enabled',
'cost threshold for parallelism',
'fill factor (%)',
'max degree of parallelism',
'max server memory (MB)',
'min server memory (MB)',
'nested triggers',
'network packet size (B)',
'Ole Automation Procedures',
'optimize for ad hoc workloads',
'remote access',
'remote admin connections',
'remote login timeout (s)',
'xp_cmdshell')
ORDER BY name ASC;

/* Get all trace flags enabled globally and per session */
DBCC TRACESTATUS();

/* Get database level info */
SELECT	DatabaseName = d.name, 
		FileName = m.name, 
		FilePath = m.physical_name, 
		Collation = d.collation_name,
		m.Size, 
		m.Growth, 
		amt = CASE m.is_percent_growth 
			WHEN 0 
				THEN 'MB' 
				ELSE '%' 
			end, 
		RecoveryModel = d.recovery_model_desc, 
		AutoCreateStats = d.Is_auto_create_stats_on, 
		AutoUpdateStats = d.is_auto_update_stats_on, 
		AutoUpdateStatsAsync = d.is_auto_update_stats_async_on, 
		AutoClose = d.is_auto_close_on, 
		AutoShrink = d.is_auto_shrink_on
FROM sys.databases d INNER JOIN sys.master_files m
ON d.database_id = m.database_id;

/*Get enabled SQL Agent Alerts */
SELECT  ErrorNumber = message_id, Severity, Name
	FROM    msdb.dbo.sysalerts
	WHERE enabled = 1;

/*Get last backup date */
SELECT  DISTINCT d.Name, 
		RecoveryModel = d.recovery_model_desc,
		LastBackupType = CASE b.type WHEN 'L' THEN 'Log' WHEN 'I' THEN 'Diff' WHEN 'D' THEN 'Full' ELSE 'Never' end ,  
		LastBackupDate = MAX(b.backup_finish_date) 
FROM    master.sys.databases d
        LEFT OUTER JOIN msdb.dbo.backupset b ON d.name = b.database_name AND b.server_name = @@SERVERNAME 
WHERE   d.database_id <> 2  
        AND d.state <> 6 
        AND d.is_in_standby = 0 
        AND d.source_database_id IS NULL 
GROUP BY d.name, b.type, d.recovery_model_desc
ORDER BY d.name;
