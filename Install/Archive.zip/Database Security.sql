/****** Object:  Table [dbo].[SecurityAudit]    Script Date: 3/21/2014 11:06:42 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[SecurityAudit](
	[SecurityAudit_ID] [int] IDENTITY(1,1) NOT NULL,
	[ServerName] [varchar](128) NULL,
	[DatabaseName] [varchar](128) NULL,
	[PrincipalID] [int] NOT NULL,
	[UserName] [sysname] NOT NULL,
	[MemberOfRole] [sysname] NULL,
	[Class] [varchar](60) NULL,
	[PermissionName] [varchar](128) NULL,
	[State] [varchar](60) NULL,
	[Schema] [sysname] NULL,
	[ObjectName] [varchar](128) NULL,
	[type_desc] [varchar](60) NULL,
	[default_schema_name] [sysname] NULL,
	[OwnerName] [sysname] NULL,
	[GrantorName] [sysname] NOT NULL,
 CONSTRAINT [PK_SecurityAudit] PRIMARY KEY CLUSTERED 
(
	[SecurityAudit_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO


truncate table securityaudit;

insert into dbo.securityaudit (servername, databasename, principalid, username, memberofrole, class, permissionname, [state], [schema], objectname, type_desc, default_schema_name, ownername, grantorname)
EXEC sp_MSforeachdb 'use [?] 
SELECT
	@@servername ''ServerName'', 
	db_name() ''?'', 
	grantee.principal_id ''PrincipalID'', 
	grantee.name ''UserName'', 
	ru.name ''MemberOfRole'',
	dp.class_desc ''Class'', 
	dp.permission_name ''PermissionName'', 
	dp.state_desc ''State'',
	s.name ''Schema'',
	ObjectName = OBJECT_NAME(dp.major_id), 
	grantee.type_desc, 
	grantee.default_schema_name, 
	ou.name ''OwnerName'',
	GrantorName = grantor.name
FROM 
	sys.database_permissions dp
	JOIN sys.database_principals grantee 
		on dp.grantee_principal_id = grantee.principal_id
	JOIN sys.database_principals grantor 
		on dp.grantor_principal_id = grantor.principal_id
	LEFT JOIN sys.schemas s 
		on dp.major_id = s.schema_id
	LEFT JOIN sys.database_principals ou
		on grantee.owning_principal_id = ou.principal_id
	LEFT JOIN sys.database_role_members rm
		on grantee.principal_id = member_principal_id
	LEFT JOIN sys.database_principals ru
		on rm.role_principal_id = ru.principal_id
WHERE
	grantee.name <> ''public''
	and LEFT(grantee.name, 1) <> ''#''
	and grantee.name <> ''RSExecRole''
ORDER BY
	grantee.name, dp.class_desc, dp.permission_name, dp.state_desc, OBJECT_NAME(dp.major_id)
';


/****** Script for SelectTopNRows command from SSMS  ******/
SELECT TOP 1000 [SecurityAudit_ID]
      ,[ServerName]
      ,[DatabaseName]
      ,[PrincipalID]
      ,[UserName]
      ,[MemberOfRole]
      ,[Class]
      ,[PermissionName]
      ,[State]
      ,[Schema]
      ,[ObjectName]
      ,[type_desc]
      ,[default_schema_name]
      ,[OwnerName]
      ,[GrantorName]
  FROM [dbo].[SecurityAudit]
