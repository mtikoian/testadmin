USE [master]
GO

/****** Object:  DdlTrigger [PreventDropDatabaseAndTable]    Script Date: 3/21/2014 10:55:30 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO




CREATE TRIGGER [PreventDropDatabaseAndTable]
ON ALL SERVER
FOR DROP_DATABASE, DROP_TABLE
AS
PRINT 'Databases/Tables cannot be dropped.  Please contact the database administrator.';
ROLLBACK;



GO

SET ANSI_NULLS OFF
GO

SET QUOTED_IDENTIFIER OFF
GO

ENABLE TRIGGER [PreventDropDatabaseAndTable] ON ALL SERVER
GO


