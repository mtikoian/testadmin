USE [msdb]
GO

/****** Object:  Alert [019 - Fatal Error in Resource]    Script Date: 4/18/2012 9:00:26 AM ******/
EXEC msdb.dbo.sp_add_alert @name=N'019 - Fatal Error in Resource', 
		@message_id=0, 
		@severity=19, 
		@enabled=1, 
		@delay_between_responses=0, 
		@include_event_description_in=1, 
		@category_name=N'[Uncategorized]', 
		@job_id=N'00000000-0000-0000-0000-000000000000'
GO

/****** Object:  Alert [020 - Fatal Error in Current Process]    Script Date: 4/18/2012 9:00:26 AM ******/
EXEC msdb.dbo.sp_add_alert @name=N'020 - Fatal Error in Current Process', 
		@message_id=0, 
		@severity=20, 
		@enabled=1, 
		@delay_between_responses=0, 
		@include_event_description_in=1, 
		@category_name=N'[Uncategorized]', 
		@job_id=N'00000000-0000-0000-0000-000000000000'
GO

/****** Object:  Alert [021 - Fatal Error in Database Processes]    Script Date: 4/18/2012 9:00:26 AM ******/
EXEC msdb.dbo.sp_add_alert @name=N'021 - Fatal Error in Database Processes', 
		@message_id=0, 
		@severity=21, 
		@enabled=1, 
		@delay_between_responses=0, 
		@include_event_description_in=1, 
		@category_name=N'[Uncategorized]', 
		@job_id=N'00000000-0000-0000-0000-000000000000'
GO

/****** Object:  Alert [022 - Fatal Error: Table Integrity Suspect]    Script Date: 4/18/2012 9:00:26 AM ******/
EXEC msdb.dbo.sp_add_alert @name=N'022 - Fatal Error: Table Integrity Suspect', 
		@message_id=0, 
		@severity=22, 
		@enabled=1, 
		@delay_between_responses=0, 
		@include_event_description_in=1, 
		@category_name=N'[Uncategorized]', 
		@job_id=N'00000000-0000-0000-0000-000000000000'
GO

/****** Object:  Alert [023 - Fatal Error: Database Integrity Suspect]    Script Date: 4/18/2012 9:00:26 AM ******/
EXEC msdb.dbo.sp_add_alert @name=N'023 - Fatal Error: Database Integrity Suspect', 
		@message_id=0, 
		@severity=23, 
		@enabled=1, 
		@delay_between_responses=0, 
		@include_event_description_in=1, 
		@category_name=N'[Uncategorized]', 
		@job_id=N'00000000-0000-0000-0000-000000000000'
GO

/****** Object:  Alert [024 - Fatal Error: Hardware Error]    Script Date: 4/18/2012 9:00:26 AM ******/
EXEC msdb.dbo.sp_add_alert @name=N'024 - Fatal Error: Hardware Error', 
		@message_id=0, 
		@severity=24, 
		@enabled=1, 
		@delay_between_responses=0, 
		@include_event_description_in=1, 
		@category_name=N'[Uncategorized]', 
		@job_id=N'00000000-0000-0000-0000-000000000000'
GO

/****** Object:  Alert [025 - Fatal Error]    Script Date: 4/18/2012 9:00:26 AM ******/
EXEC msdb.dbo.sp_add_alert @name=N'025 - Fatal Error', 
		@message_id=0, 
		@severity=25, 
		@enabled=1, 
		@delay_between_responses=0, 
		@include_event_description_in=1, 
		@category_name=N'[Uncategorized]', 
		@job_id=N'00000000-0000-0000-0000-000000000000'
GO

/****** Object:  Alert [823 - Corruption: Hard I/O]    Script Date: 4/18/2012 9:00:27 AM ******/
EXEC msdb.dbo.sp_add_alert @name=N'823 - Corruption: Hard I/O', 
		@message_id=823, 
		@severity=0, 
		@enabled=1, 
		@delay_between_responses=0, 
		@include_event_description_in=1, 
		@notification_message=N'This is where SQL Server has asked the OS to read the page but it just cant', 
		@category_name=N'[Uncategorized]', 
		@job_id=N'00000000-0000-0000-0000-000000000000'
GO

/****** Object:  Alert [824 - Corruption: Soft I/O]    Script Date: 4/18/2012 9:00:27 AM ******/
EXEC msdb.dbo.sp_add_alert @name=N'824 - Corruption: Soft I/O', 
		@message_id=824, 
		@severity=0, 
		@enabled=1, 
		@delay_between_responses=0, 
		@include_event_description_in=5, 
		@notification_message=N'This is where the OS could read the page but SQL Server decided that the page was corrupt - for example with a page checksum failure', 
		@category_name=N'[Uncategorized]', 
		@job_id=N'00000000-0000-0000-0000-000000000000'
GO

/****** Object:  Alert [825 - Corruption: Read/Retry]    Script Date: 4/18/2012 9:00:27 AM ******/
EXEC msdb.dbo.sp_add_alert @name=N'825 - Corruption: Read/Retry', 
		@message_id=825, 
		@severity=0, 
		@enabled=1, 
		@delay_between_responses=600, 
		@include_event_description_in=5, 
		@notification_message=N'This is where either an 823 or 824 occured, SQL server retried the IO automatically and it succeeded. This error is written to the errorlog only - you need to be aware of these as they''re a sign of your IO subsystem going awry. There''s no way to turn off read-retry and force SQL Server to ''fail-fast'' - whether this behavior is a good or bad thing can be argued both ways - personally I don''t like it', 
		@category_name=N'[Uncategorized]', 
		@job_id=N'00000000-0000-0000-0000-000000000000'
GO

/****** Object:  Alert [9100 - Error: Index Corruption]    Script Date: 4/18/2012 9:00:27 AM ******/
EXEC msdb.dbo.sp_add_alert @name=N'9100 - Error: Index Corruption', 
		@message_id=9100, 
		@severity=0, 
		@enabled=1, 
		@delay_between_responses=180, 
		@include_event_description_in=7, 
		@category_name=N'[Uncategorized]', 
		@job_id=N'00000000-0000-0000-0000-000000000000'
GO

EXEC msdb.dbo.sp_add_notification @alert_name=N'019 - Fatal Error in Resource', @operator_name=N'DBA', @notification_method = 1
GO
EXEC msdb.dbo.sp_add_notification @alert_name=N'020 - Fatal Error in Current Process', @operator_name=N'DBA', @notification_method = 1
GO
EXEC msdb.dbo.sp_add_notification @alert_name=N'021 - Fatal Error in Database Processes', @operator_name=N'DBA', @notification_method = 1
GO
EXEC msdb.dbo.sp_add_notification @alert_name=N'022 - Fatal Error: Table Integrity Suspect', @operator_name=N'DBA', @notification_method = 1
GO
EXEC msdb.dbo.sp_add_notification @alert_name=N'023 - Fatal Error: Database Integrity Suspect', @operator_name=N'DBA', @notification_method = 1
GO
EXEC msdb.dbo.sp_add_notification @alert_name=N'024 - Fatal Error: Hardware Error', @operator_name=N'DBA', @notification_method = 1
GO
EXEC msdb.dbo.sp_add_notification @alert_name=N'025 - Fatal Error', @operator_name=N'DBA', @notification_method = 1
GO
EXEC msdb.dbo.sp_add_notification @alert_name=N'823 - Corruption: Hard I/O', @operator_name=N'DBA', @notification_method = 1
GO
EXEC msdb.dbo.sp_add_notification @alert_name=N'824 - Corruption: Soft I/O', @operator_name=N'DBA', @notification_method = 1
GO
EXEC msdb.dbo.sp_add_notification @alert_name=N'825 - Corruption: Read/Retry', @operator_name=N'DBA', @notification_method = 1
GO
EXEC msdb.dbo.sp_add_notification @alert_name=N'9100 - Error: Index Corruption', @operator_name=N'DBA', @notification_method = 1
GO

