

-- This script imports a filtered view of the current SQL Error Log and then queries it for interesting data  

Use Tempdb

drop table errorlog;
go 
create table errorLog (LogDate DateTime, Processinfo VARCHAR(25), message varchar(500));
insert into errorlog exec sp_readerrorlog 0, 1, 'login failed';
ALTER TABLE ErrorLog Add PK INT NOT NULL IDENTITY PRIMARY KEY; 
go 


select * from errorlog

-- most recent attack
select max(logdate) from errorlog;

-- total count of attacks
select count(*) from errorlog;


-- analyzing attacks by IP, sorted by most recent attack
WITH IP as (select pk, charindex('[', message, 0) as IPStart, charindex(']', message, 0) as IPend from  errorlog)
  SELECT SubString(message, IPStart + 8, IPEnd-IPStart -8) as IP, count(*) as Count, min(logDate) attackstart, max(logDate) attackend, datediff(n, min(logdate), max(logDate)) as attackduration
    FROM errorlog 
      join  IP on errorlog.pk = ip.pk
    GROUP BY SubString(message, IPStart + 8, IPEnd-IPStart -8)
    ORDER BY max(logDate) DESC;


-- analyzing attacks by Login 
WITH IP as (select pk, charindex('user ''', message, 0) as LoginStart, charindex('''', message, 24) as Loginend from  errorlog)
  SELECT SubString(message, LoginStart + 6, LoginEnd - LoginStart - 6) as IP, count(*) as Count
    FROM errorlog 
      join  IP on errorlog.pk = ip.pk
    GROUP BY SubString(message, LoginStart + 6, LoginEnd-LoginStart - 6)
    ORDER BY Count(*) DESC;


-- count of attacks by day
select left(LogDate, 11 ), count(*) from ErrorLog group by Left(LogDate, 11) order by count(*) desc;



