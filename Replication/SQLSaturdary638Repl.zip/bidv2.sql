USE master
GO
IF EXISTS(SELECT * FROM sys.databases WHERE name='BIDINodeA')
BEGIN
EXEC sp_removedbreplication 'BIDINodeA'
ALTER DATABASE BIDINodeA SET SINGLE_USER WITH ROLLBACK IMMEDIATE
DROP DATABASE BIDINodeA
END
GO
IF EXISTS(SELECT * FROM sys.databases WHERE name='BIDINodeB')
BEGIN
EXEC sp_removedbreplication 'BIDINodeB'
ALTER DATABASE BIDINodeB SET SINGLE_USER WITH ROLLBACK IMMEDIATE
DROP DATABASE BIDINodeB
END
CREATE DATABASE BIDINodeA
GO
EXEC sp_replicationdboption 'BIDINodeA', 'publish', true
GO
CREATE DATABASE BIDINodeB
GO
EXEC sp_replicationdboption 'BIDINodeB', 'publish', true
GO
USE BIDiNodeA
GO
IF exists(SELECT * FROM sys.objects WHERE type='u' AND name='Table1')
DROP TABLE Table1
GO
CREATE TABLE Table1(PK INT IDENTITY (1,2) NOT FOR REPLICATION CONSTRAINT Table1PK PRIMARY KEY, Charcol VARCHAR(20), originatingDB sysname DEFAULT db_name(), dtstamp DATETIME DEFAULT GETDATE())
GO
sp_addpublication 'BIDINodeA', @Status=ACTIVE,@snapshot_in_defaultfolder=false,@alt_snapshot_folder='c:\temp'
GO
sp_addpublication_snapshot 'BIDINodeA'
Go
EXEC sp_addarticle 'BIDINodeA', @article='Table1',@source_object='Table1' ,@identityrangemanagementoption='manual'
GO
EXEC sp_addsubscription 'BIDINodeA','ALL', @@ServerName, 'BIDINodeB', 'Replication support only', @loopback_detection='true'
GO
sp_startpublication_snapshot BIDINodeA
GO
USE BIDiNodeB
GO
IF exists(SELECT * FROM sys.objects WHERE type='u' AND name='Table1')
DROP TABLE Table1
GO
CREATE TABLE Table1(PK INT IDENTITY (2,2) NOT FOR REPLICATION CONSTRAINT Table1PK PRIMARY KEY, Charcol VARCHAR(20), originatingDB sysname DEFAULT db_name(), dtstamp DATETIME DEFAULT GETDATE())
GO
sp_addpublication 'BIDINodeB', @Status=ACTIVE,@snapshot_in_defaultfolder=false,@alt_snapshot_folder='c:\temp'
GO
sp_addpublication_snapshot 'BIDINodeB'
GO
sp_addarticle 'BIDINodeB', @article='Table1',@source_object='Table1', @identityrangemanagementoption='manual'
GO
sp_addsubscription 'BIDINodeB','ALL', @@ServerName, 'BIDINodeA', 'Replication support only', @loopback_detection='true'
GO
sp_startpublication_snapshot BIDINodeB
GO

USE BIDINodeA
GO
DECLARE @counter INT
SET @counter=1
WHILE @counter<=10
BEGIN
INSERT INTO BIDINodeA.dbo.Table1(Charcol) VALUES('test')
SELECT @counter=@counter+1
END
GO
USE BIDINodeB
GO
DECLARE @counter INT
SET @counter=1
WHILE @counter<=10
BEGIN
INSERT INTO BIDINodeB.dbo.Table1(Charcol) VALUES('test')
SELECT @counter=@counter+1
END
GO

SELECT *from BIDINodeA.dbo.Table1
GO
SELECT *from BIDINodeB.dbo.Table1
GO
waitfor delay '00:01'
GO
SELECT *from BIDINodeA.dbo.Table1
GO
SELECT *from BIDINodeB.dbo.Table1
GO
