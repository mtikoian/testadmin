use master
GO
sp_replicationdboption 'Arrival',publish,false
GO
create database Arrival
GO
use Arrival
GO
sp_replicationdboption Arrival, publish, true
go
create table InsertLog(PK int identity primary key, charcol char(20), logged datetime default getdate())
GO
create table ArrivedLog(PK int identity not for replication primary key , charcol char(20), logged datetime default getdate(), replicated datetime default getdate())
GO
create table ArrivedDownstreamLog(PK int identity primary key, charcol char(20), logged datetime default getdate(), replicated datetime default getdate())
GO
sp_addpublication First, @status=active, @snapshot_in_defaultfolder=false, @alt_snapshot_folder='c:\temp'
GO
sp_addpublication_snapshot First 
GO
create view InsertLogView with schemabinding
as
select PK, charcol ,NULL dtstamp from dbo.InsertLog
GO
Create unique clustered index InsertLogCL on InsertLogView (PK)
GO
sp_addarticle First,@article='InsertLogView', @destination_Table=InsertLogViewNew, 
@source_object=InsertLogView, 
@sync_object='InsertLogView', @creation_script='c:\temp\InsertLogNew.sql' , 
@type='indexed view logbased', @schema_option=0x00
GO
sp_addsubscription First, 'ALL',@Subscriber=@@Servername,@sync_type='replication support only'
GO
sp_startpublication_snapshot First
GO
select *from 
declare @counter int=1
while @counter<10
begin
insert into InsertLog(charcol) values(REPLICATE('X',20))
select @counter=@counter+1
end
select * from InsertLogViewNew