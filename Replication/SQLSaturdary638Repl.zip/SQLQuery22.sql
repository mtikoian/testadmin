create database Traces 
use traces
create table testTable(PK int identity primary key, charcol char(20))
declare @counter int=1
declare @rowcounter int
while @counter<=1000
begin
insert into testTable(Charcol) values(REPLICATE('X',20))
select @counter=@counter+1
end
GO
exec sp_replicationdboption traces,publish,true
GO
exec sp_addpublication test, @status=active, @alt_snapshot_folder='c:\temp', @snapshot_in_defaultfolder=false 
GO
exec sp_addpublication_snapshot test
GO
exec sp_addarticle test, testtable, @source_object=testtable, @destination_table=testtaableNew
GO
exec sp_addsubscription test, 'ALL', @Subscriber=@@Servername 
GO
exec sp_startpublication_snapshot test 
GO
waitfor delay '00:01'
GO
select * from testtaableNew
