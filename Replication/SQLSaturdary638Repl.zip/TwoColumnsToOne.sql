use master
GO
declare @job_id binary(16)
select @job_id =job_id from distribution.dbo.mslogreader_agents  where publisher_db='TwoColumnsToOne'
exec msdb.dbo.sp_stop_job @job_id =@job_id 
if exists(select * from sys.databases where name='TwoColumnsToOne')
begin
exec sp_replicationdboption TwoColumnsToOne, publish, false
alter database TwoColumnsToOne set single_user with rollback immediate
/*
Msg 18752, Level 16, State 1, Procedure sp_replcmds, Line 1 [Batch Start Line 0]
Only one Log Reader Agent or log-related procedure (sp_repldone, sp_replcmds, and sp_replshowcmds) can connect to a database at a time. If you executed a log-related procedure, drop the connection over which the procedure was executed or execute sp_replflush over that connection before starting the Log Reader Agent or executing another log-related procedure.
Msg 18752, Level 16, State 1, Procedure sp_replcmds, Line 1 [Batch Start Line 0]
Only one Log Reader Agent or log-related procedure (sp_repldone, sp_replcmds, and sp_replshowcmds) can connect to a database at a time. If you executed a log-related procedure, drop the connection over which the procedure was executed or execute sp_replflush over that connection before starting the Log Reader Agent or executing another log-related procedure.
Msg 3702, Level 16, State 3, Line 5
Cannot drop database "TwoColumnsToOne" because it is currently in use.
Msg 1801, Level 16, State 3, Line 7
Database 'TwoColumnsToOne' already exists. Choose a different database name.
*/
drop database TwoColumnsToOne 
end
create database TwoColumnsToOne
GO
sp_replicationdboption TwoColumnsToOne, publish, true
GO
use TwoColumnsToOne
GO
sp_addpublication TwoColumnsToOne, @status=active,@snapshot_in_defaultfolder=false, @alt_snapshot_folder='c:\temp\'
GO
sp_addpublication_snapshot TwoColumnsToOne
GO
create table NameTable(PK int identity primary key, firstname sysname, lastname sysname)
GO
insert into  NameTable(firstname, lastname) 
select FirstName, LastName  from AdventureWorks2014.Person.Person
select *from NameTable
GO
--create sync object
--create creation script
/*
create table Consolidatedtable(PK int identity NOT FOR REPLICATION primary key, Name sysname)
*/
create view MySyncObject with schemabinding 
as
select pk, LastName+', '+FirstName Name from dbo.NameTable
GO
create unique clustered index MySyncObjectCL on MySyncObject(PK)
GO

sp_addarticle TwoColumnsToOne, MySyncObject , @source_object=MySyncObject ,
@type='indexed view logbased', @destination_table=ConsolidatedTable,@pre_creation_cmd =none,
@sync_object=MySyncObject,@creation_script='c:\temp\Consolidatedtable.sql',@schema_option=0x0
--generates the stored procedures

GO
sp_addsubscription TwoColumnsToOne, 'ALL', @Subscriber=@@servername
GO
sp_startpublication_snapshot TwoColumnsToOne
GO
WAITFOR DELAY '00:01'
GO
select * from ConsolidatedTable where name like '%, Kim'

/*
update nametable set firstname ='Kimberly' where firstname='Kim'
select * from ConsolidatedTable where name like '%, Kim%'

*/