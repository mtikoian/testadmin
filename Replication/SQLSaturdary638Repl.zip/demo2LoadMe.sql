use Tranny
GO
DECLARE @counter INT=1
WHILE @counter<1000
BEGIN
INSERT INTO table1(charcol) VALUES('test')
SET @counter  += 1
END
