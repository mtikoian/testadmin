if exists(select * from sys.databases where name='IndexedView')
begin
exec sp_replicationdboption IndexedView, publish, false
drop database IndexedView
end
create database IndexedView
GO
exec sp_replicationdboption IndexedView, publish, true
GO
use IndexedView
GO
create table Table1(PK int identity primary key, charcol varchar(20))
GO
create table Table2(PK int identity primary key, charcol varchar(20), FK int 
constraint FK_Table1 foreign key (FK) references Table1(PK))
GO
declare @counter int=1
while @counter<1000
begin
insert into table1(charcol) values(replicate('X',20))
insert into table2(charcol,FK) values(replicate('Y',20), @counter)
select @counter=@counter+1
end 
GO
create view IndexedView with schemabinding
as
select table1.PK , table1.charcol, table2.charcol [table2.charcol] from dbo.Table1 
join dbo.Table2 on Table1.PK=Table2.FK
GO
create unique clustered index IndexViewCL on IndexedView(PK)
GO
sp_Addpublication IndexedView, @status=active, @snapshot_in_defaultfolder=false, 
@Alt_snapshot_folder='c:\temp'
GO
sp_addpublication_snapshot IndexedView
GO
sp_addarticle indexedView, IndexedView, @source_object=IndexedView, @destination_table=Destination,@type ='Indexed view LogBased'
GO
sp_addsubscription IndexedView, indexedView, @subscriber=@@servername
GO
sp_startpublication_snapshot IndexedView