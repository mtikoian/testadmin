USE master
GO
IF EXISTS (SELECT * FROM sys.databases WHERE name='TRANNY')
BEGIN
exec sp_removedbreplication 'tranny'
exec sp_replicationdboption 'tranny', publish, false
ALTER DATABASE tranny SET SINGLE_USER WITH ROLLBACK IMMEDIATE 
DROP DATABASE tranny
END
GO
CREATE DATABASE Tranny
GO
IF EXISTS (SELECT * FROM sys.databases WHERE name='TrannySub')
BEGIN
exec sp_removedbreplication 'TrannySub'
exec sp_replicationdboption 'TrannySub', publish, false
ALTER DATABASE TrannySub SET SINGLE_USER WITH ROLLBACK IMMEDIATE 
DROP DATABASE TrannySub
END
GO
CREATE DATABASE TrannySub
GO
USE Tranny
GO
EXEC sp_replicationdboption tranny,publish, true 
GO
EXEC sp_addpublication Tranny, @status=ACTIVE, @alt_snapshot_folder='c:\temp', @snapshot_in_defaultfolder=false
GO
EXEC sp_addpublication_snapshot Tranny
GO
CREATE TABLE Table1(PK INT IDENTITY PRIMARY KEY, charcol CHAR(20))
GO
DECLARE @counter INT=1
WHILE @counter<1000
BEGIN
INSERT INTO table1(charcol) VALUES('test')
SET @counter  += 1
END
EXEC sp_addarticle Tranny, Table1, @source_object='Table1'
GO
EXEC sp_addarticle Tranny, Table2, @source_object='Table1', @destination_table=table2
GO
EXEC sp_addsubscription Tranny, Table1, @@ServerName, TrannySUB
GO
EXEC sp_addsubscription Tranny, Table2, @@ServerName, Tranny
GO
EXEC sp_startpublication_snapshot Tranny
GO
WAITFOR DELAY '00:00:30'
GO
SELECT *  FROM Tranny.dbo.table1
SELECT *  FROM TrannySub.dbo.table1
SELECT *  FROM Tranny.dbo.table2 
