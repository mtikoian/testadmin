USE P2P1
GO
DECLARE @counter INT=10001
WHILE @counter<11000
BEGIN
INSERT INTO table1(pk,col1) VALUES(@counter, 'test')
SELECT @counter+=1
END
USE P2P2
GO
DECLARE @counter INT=20001
WHILE @counter<21000
BEGIN
INSERT INTO table1(pk,col1) VALUES(@counter, 'test')
SELECT @counter+=1
END
USE P2P3
GO
DECLARE @counter INT=30001
WHILE @counter<31000
BEGIN
INSERT INTO table1(pk,col1) VALUES(@counter, 'test')
SELECT @counter+=1
end