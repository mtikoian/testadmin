use Master 
GO
if exists(select * From sys.databases where name='Chris')
begin
exec sp_removedbreplication 'Chris'
exec sp_replicationdboption 'Chris','publish',false
alter database Chris set single_user with rollback immediate
drop database Chris
end
Create Database Chris
GO
if exists(select * From sys.databases where name='ChrisSub')
begin
exec sp_removedbreplication 'ChrisSub'
exec sp_replicationdboption 'ChrisSub','publish',false
alter database ChrisSub set single_user with rollback immediate
drop database ChrisSub
end
Create Database ChrisSub
GO
use Chris
GO
Create Table Test1(PK INT IDENTITY PRIMARY KEY, charcol varchar(20))
GO
declare @counter int
set @counter=1
while @counter<=100
begin
insert into Test1(Charcol) values('test')
select @counter=@counter+1
end
exec sp_configure 'show advanced options',1
reconfigure with override
exec sp_configure 'xp_cmdshell',1
reconfigure with override
exec xp_cmdshell 'md c:\temp'
GO
exec sp_replicationdboption Chris, publish, true
GO
exec sp_addpublication Chris, @status='active', @snapshot_in_defaultfolder='false',@alt_snapshot_folder='c:\temp', @allow_initialize_from_backup='true', @allow_pull=true
GO
exec sp_addpublication_snapshot Chris
GO
exec sp_addarticle chris, test1, @Source_Object=test1
GO
backup database Chris to disk='c:\temp\Chris.bak' with init
GO
exec xp_cmdshell 'md c:\temp1'
GO
--moving the database backup to a new location
exec xp_cmdshell 'md c:\temp1'
GO
exec xp_cmdshell 'copy c:\temp\Chris.bak c:\temp1\Chris.bak'
GO
--NOTE HERE I PASS MY SUBCSRIBER NAME!
exec  sp_addsubscription Chris, 'ALL',@@SERVERNAME, ChrisSub,  @backupdevicetype=disk, @backupdevicename='c:\temp1\Chris.bak', @sync_type='initialize with backup', 
@subscription_type = 'pull' 
GO
