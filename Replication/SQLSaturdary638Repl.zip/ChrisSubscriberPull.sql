use master
GO
if exists(select * From sys.databases where name='ChrisSub')
begin
exec sp_removedbreplication 'ChrisSub'
exec sp_replicationdboption 'ChrisSub','publish',false
alter database ChrisSub set single_user with rollback immediate
drop database ChrisSub
end
Create Database ChrisSub
GO
Use ChrisSub
GO
exec sp_addpullsubscription @publisher = @@SERVERNAME, @publication = 'Chris', @publisher_db = 'Chris', @subscription_type = 'pull' 
GO
exec sp_addpullsubscription_agent @publisher = @@SERVERNAME, @publisher_db = N'Chris', @publication = N'Chris', @distributor = N'WINDOWS7\SQL2005A', @distributor_security_mode = 0, 
--this is a login on the publisher which is in the db_owner role in the publicaton and distribution database and the public role in the master database.
@distributor_login = 'sa', @distributor_password = N'password', 
@subscriber_security_mode = 0, @subscriber_login = 'sa', @subscriber_password = N'password', 
@alt_snapshot_folder = N'c:\temp1'
GO
