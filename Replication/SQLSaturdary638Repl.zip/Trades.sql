use master
GO
if exists(select * From sys.databases where name='Trades')
begin
exec sp_replicationdboption Trades , publish, false 
alter database Trades  set single_user with rollback immediate
drop database Trades
end
GO
create database Trades
GO
use Trades
GO
if exists(select * from sys.objects where name='Trades')
drop table Trades 
create table Trades(TransactionID int identity primary key, Stock varchar(20), TradePrice money, dtstamp datetime default getdate())
GO
if exists(select * from sys.objects where name='TradeAggregates')
drop table TradeAggregates
GO
create table TradeAggregates( TradeAggregatesID int identity primary key, Stock varchar(20), Opening money, High Money, Low Money, TradeTime datetime )
GO

insert into Trades(Stock, TradePrice, dtstamp) values('MSFT',1.05, getdate()-2)
waitfor delay '00:00:01'
insert into Trades(Stock, TradePrice, dtstamp) values('MSFT',1.10, getdate()-2)
waitfor delay '00:00:01'
insert into Trades(Stock, TradePrice, dtstamp) values('MSFT',2.10, getdate()-2)
waitfor delay '00:00:01'
insert into Trades(Stock, TradePrice, dtstamp) values('MSFT',1.04, getdate()-1)
waitfor delay '00:00:01'
insert into Trades(Stock, TradePrice, dtstamp) values('MSFT',1.10, getdate()-1)
waitfor delay '00:00:01'
insert into Trades(Stock, TradePrice, dtstamp) values('MSFT',3.10, getdate()-1)
waitfor delay '00:00:01'
insert into Trades(Stock, TradePrice, dtstamp) values('MSFT',1, getdate())
waitfor delay '00:00:01'
insert into Trades(Stock, TradePrice, dtstamp) values('MSFT',1.10, getdate())
waitfor delay '00:00:01'
insert into Trades(Stock, TradePrice, dtstamp) values('MSFT',.10, getdate())

waitfor delay '00:00:01'
GO
Create view CustomSyncObject
as
select Trades.TransactionID, X.Stock, Low, high, OpeningTime, TradePrice OpeningPrice from Trades
join (
select Stock, min(tradeprice) Low, max(tradeprice) High, min(dtstamp) OpeningTime, 
convert(date,min(dtstamp)) [Date]
From trades
group by Stock, convert(date, convert(varchar(16),  dtstamp, 120))) as X
on X.Stock=Trades.Stock and X.OpeningTime=Trades.dtstamp
GO
select * from CustomSyncObject
GO
exec sp_replicationdboption 'Trades', 'publish',true
GO
if exists(select * from syspublications where name='Trades')
exec sp_droppublication trades 
GO
exec sp_addpublication Trades, 
@status=active, @snapshot_in_defaultfolder=false,@independent_agent=true,@alt_snapshot_folder='c:\temp',
@sync_method=character
GO
--using character as we want to look at the snapshot files to ensure that they are in order
exec sp_addpublication_snapshot trades
GO
/* must precreate a script called TradeAggregates.sql which contains this.

CREATE TABLE [dbo].[TradeAggregates](
	TransactionID int primary key,
	[Stock] [varchar](20) NULL,
	[Low] [money] NULL,
	[high] [money] NULL,
	[OpeningTime] [datetime] NULL,
	[OpeningPrice] [money] NULL
) ON [PRIMARY]
GO


*/

exec sp_addarticle Trades,'Trades',@source_object=trades, 
@sync_Object=CustomSyncObject, @destination_table=  TradeAggregates,
@type = N'logbased', @creation_script='c:\temp\TradeAggregates.sql',@schema_option=0x0,
@ins_cmd = N'CALL [sp_MSins_dboTradesCustom]', @del_cmd = N'XCALL [sp_MSdel_dboTradesCustom]', @upd_cmd = N'SCALL [sp_MSupd_dboTradesCustom]'
GO
exec sp_addsubscription Trades,'ALL', @@ServerName 
GO
exec sp_startpublication_snapshot 'Trades'
GO
WAITFOR DELAY '00:01'
GO
exec sp_addpushsubscription_agent 'Trades' ,@@SERVERNAME
GO 
select * from TradeAggregates
--need to generate the custom stored procedures!
GO
sp_scriptpublicationcustomprocs trades
GO
--no result
--need to create a dummy pub
exec sp_addpublication dummy 
GO
exec sp_addarticle dummy, trades, @source_object =trades 
GO
sp_scriptpublicationcustomprocs dummy
GO
